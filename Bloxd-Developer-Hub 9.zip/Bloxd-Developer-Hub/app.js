const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let entries=[],buildIndex=[],buildState={},activeEntry=null,dbPage=0,texPage=0,dbFiltered=[],texFiltered=[],loadedCode="",currentCodeFile="",codeMatches=[];
let ASSET_ROOT="public";
const asset=u=>{if(!u)return u;if(/^(https?:)?\/\//.test(u))return u;const p=u.replace(/^\/+/,"");return ASSET_ROOT?ASSET_ROOT+"/"+p:p};
// Hosts differ: some serve the project root (data lives in public/), others serve the public folder itself (data lives in data/).
async function detectRoot(){for(const root of ["public",""]){try{const r=await fetch((root?root+"/":"")+"data/build-index.json");if(r.ok&&Array.isArray(await r.json())){ASSET_ROOT=root;return}}catch{}}}
const PAGE=60, fmt=n=>Number(n||0).toLocaleString(), esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const entryName=e=>e?.displayName?.text||e?.name||"Unknown";
const texture=e=>e?._texture?asset(e._texture):null;
const pretty=v=>typeof v==="object"?JSON.stringify(v):String(v);
async function getJSON(url){const r=await fetch(url);if(!r.ok)throw Error("Could not load "+url+" ("+r.status+")");return r.json()}
async function getText(url){const r=await fetch(url);if(!r.ok)throw Error("Could not load "+url);return r.text()}
function toast(msg){const el=document.createElement("div");el.className="toast";el.textContent=msg;document.body.append(el);setTimeout(()=>el.remove(),2600)}
function go(view){$$(".view").forEach(x=>x.classList.toggle("active",x.id==="view-"+view));$$(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.view===view));$("#crumbName").textContent=({overview:"Overview",database:"Block database",textures:"Texture viewer",inspector:"Item inspector",finder:"ID finder",mobs:"Mobs",codeapi:"Code API changes",history:"Build history",compare:"Build comparison",code:"Code explorer"})[view]||view;$("#sidebar").classList.remove("open");if(view==="database")renderDB();if(view==="mobs")renderMobList();if(view==="textures")renderTextures();if(view==="codeapi"&&!monInit.codeapi)initMonitor("codeapi");
  if(view==="code"){if(!$("#codeFile").options.length)setupCode();requestAnimationFrame(()=>{measureChar();renderEditor()})}}
$$(".nav-item").forEach(b=>b.addEventListener("click",()=>go(b.dataset.view)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
async function init(){
 try{
  await detectRoot();
  [entries,buildIndex,buildState]=await Promise.all([getJSON(asset("data/catalog.json")),getJSON(asset("data/build-index.json")),getJSON(asset("data/build-state.json"))]);
  const base=entries.filter(e=>!e.meta);const texCount=entries.filter(e=>texture(e)).length;
  $("#statEntries").textContent=fmt(entries.length);$("#statTextures").textContent=fmt(texCount);$("#statFiles").textContent=fmt(buildIndex.length);const first=Object.values(buildState)[0]||{};$("#heroBuild").textContent=first.build||"—";$("#heroChecked").textContent=(first.checked_at||"—").slice(0,10);$("#side-version").textContent=Object.values(buildState)[0]?.build||"Archive";
  $("#dbCount").textContent=fmt(entries.length)+" entries";$("#textureCount").textContent=fmt(texCount)+" textures";$("#codeFileCount").textContent=fmt(buildIndex.length)+" files";
  dbFiltered=entries;texFiltered=entries.filter(e=>texture(e));renderDB();renderTextures();setupHistory();setupCompare();setupCode();
  try{mobData=await getJSON(asset("data/mobs.json"));setupMobs()}catch(err){console.warn("Mob list unavailable",err)}
 }catch(e){$("#content").insertAdjacentHTML("afterbegin",`<div class="notice error"><span>!</span><div><b>The archive data could not be loaded.</b><p>${esc(e.message)}. Deploy the complete project folder (including the <code>public</code> folder) and open the site through a web server, not by double-clicking index.html.</p></div></div>`)}
}
function keyProperty(e){let fields=e.kind==="item"?["type","damage","attackRange","weight","harvests"]:["harvestType","ttb","model","solid"];for(const f of fields)if(e[f]!==undefined)return f+": "+pretty(e[f]);return e.description?.text||e.textureInfo||"—"}
function renderDB(){
 const q=$("#dbSearch").value.trim().toLowerCase(),kind=$("#dbKind").value,sort=$("#dbSort").value;
 dbFiltered=entries.filter(e=>(kind==="all"||e.kind===kind)&&(!q||[e.id,e.name,entryName(e),e.textureInfo,e.type,e.harvestType,e.rootMetaDesc].join(" ").toLowerCase().includes(q)));
 if(sort==="name")dbFiltered.sort((a,b)=>entryName(a).localeCompare(entryName(b)));else dbFiltered.sort((a,b)=>a.id-b.id);
 const pages=Math.max(1,Math.ceil(dbFiltered.length/PAGE));dbPage=Math.min(dbPage,pages-1);
 $("#dbCount").textContent=fmt(dbFiltered.length)+" results";
 $("#dbRows").innerHTML=dbFiltered.slice(dbPage*PAGE,(dbPage+1)*PAGE).map(e=>`<tr><td><div class="entry-cell">${texture(e)?`<img class="mini-thumb" loading="lazy" src="${texture(e)}">`:`<span class="mini-thumb"></span>`}<span>${esc(entryName(e))}${e.meta?` <small class="muted">variant</small>`:""}</span></div></td><td><code>${e.id}</code></td><td><span class="kind ${e.kind==="item"?"item":""}">${esc(e.kind||"—")}</span></td><td>${esc(keyProperty(e))}</td><td><button class="row-action" data-entry="${entries.indexOf(e)}">Inspect</button></td></tr>`).join("")||`<tr><td colspan="5">No matching entries found.</td></tr>`;
 $("#dbPageInfo").textContent=`Showing ${dbFiltered.length?dbPage*PAGE+1:0}–${Math.min((dbPage+1)*PAGE,dbFiltered.length)} of ${fmt(dbFiltered.length)}`;
 $("#dbPrev").disabled=dbPage===0;$("#dbNext").disabled=dbPage>=pages-1;
}
["dbSearch","dbKind","dbSort"].forEach(id=>$("#"+id).addEventListener(id==="dbSearch"?"input":"change",()=>{dbPage=0;renderDB()}));
$("#dbPrev").onclick=()=>{dbPage--;renderDB()};$("#dbNext").onclick=()=>{dbPage++;renderDB()};
function renderTextures(){
 const q=$("#texSearch").value.trim().toLowerCase(),kind=$("#texKind").value,sort=$("#texSort").value;
 texFiltered=entries.filter(e=>texture(e)&&(kind==="all"||e.kind===kind)&&(!q||[e.id,e.name,entryName(e),e.textureInfo].join(" ").toLowerCase().includes(q)));
 if(sort==="name")texFiltered.sort((a,b)=>entryName(a).localeCompare(entryName(b)));else texFiltered.sort((a,b)=>a.id-b.id);
 const pages=Math.max(1,Math.ceil(texFiltered.length/PAGE));texPage=Math.min(texPage,pages-1);
 $("#textureGrid").innerHTML=texFiltered.slice(texPage*PAGE,(texPage+1)*PAGE).map(e=>`<button class="texture-card" data-entry="${entries.indexOf(e)}"><div class="texture-img"><img loading="lazy" src="${texture(e)}" alt=""></div><b>${esc(entryName(e))}</b><small>#${e.id} · ${e.kind}</small></button>`).join("")||`<div class="empty-state">No textures match your search.</div>`;
 $("#texPageInfo").textContent=`Showing ${texFiltered.length?texPage*PAGE+1:0}–${Math.min((texPage+1)*PAGE,texFiltered.length)} of ${fmt(texFiltered.length)}`;$("#texPrev").disabled=texPage===0;$("#texNext").disabled=texPage>=pages-1;
}
["texSearch","texKind","texSort"].forEach(id=>$("#"+id).addEventListener(id==="texSearch"?"input":"change",()=>{texPage=0;renderTextures()}));
$("#texPrev").onclick=()=>{texPage--;renderTextures()};$("#texNext").onclick=()=>{texPage++;renderTextures()};
function props(e){const preferred=e.kind==="item"?["type","weight","damage","attackRange","secondaryDamage","armourReduction","knockbackReduction","eatable","eatHealAmt","fireRate","reloadTime","clipSize","chargeTime","harvests","multiplier","level","dashImpulse"]:["ttb","harvestType","harvestLevel","solid","model","damage","soundType","stoodOnSpeedMultiplier","drops","textureInfo","atlasIdx"];return preferred.filter(k=>e[k]!==undefined).map(k=>`<div class="property"><small>${esc(k)}</small><b>${esc(pretty(e[k]))}</b></div>`).join("")}
function showEntry(e,modal=false){
 if(!e)return;activeEntry=e;
 const im=texture(e)?`<img src="${texture(e)}" alt="${esc(entryName(e))}">`:`<div class="no-image">◈</div>`;
 const meta=e.meta?`<p>Variant of ${esc(e.meta.rootName||"base entry")} · ${esc(e.meta.metaStr||"")}</p>`:"";
 const html=`<div class="detail-layout"><div class="detail-visual">${im}</div><div class="detail-content"><h2>${esc(entryName(e))}</h2><div class="subline">ID ${e.id} · ${esc(e.kind||"unknown")} · ${e.name!==entryName(e)?esc(e.name):"Canonical name"}</div>${meta}<div class="property-grid">${props(e)||`<div class="property"><small>Registry</small><b>No additional properties recorded</b></div>`}</div><div class="subline record-label">Full registry record</div><pre class="json-block">${esc(JSON.stringify(e,null,2))}</pre></div></div>`;
 if(modal){$("#modalBody").innerHTML=`<h2>${esc(entryName(e))}</h2><p>Registry entry details</p>${html}`;$("#detailModal").classList.add("open")}
 else $("#itemDetail").innerHTML=html;
}
document.addEventListener("click",ev=>{const b=ev.target.closest("[data-entry]");if(b){const e=entries[Number(b.dataset.entry)];if($("#view-textures").classList.contains("active"))showEntry(e,true);else showEntry(e,true)}});
$("#closeModal").onclick=()=>$("#detailModal").classList.remove("open");$("#detailModal").addEventListener("click",e=>{if(e.target.id==="detailModal")$("#detailModal").classList.remove("open")});
$("#itemSearch").addEventListener("input",()=>{
 const q=$("#itemSearch").value.trim().toLowerCase(),box=$("#itemSuggestions");if(!q){box.classList.remove("show");return}
 const found=entries.filter(e=>e.kind==="item"&&[e.id,e.name,entryName(e),e.type].join(" ").toLowerCase().includes(q)).slice(0,12);
 box.innerHTML=found.map(e=>`<button class="suggestion" data-pick="${entries.indexOf(e)}"><span>${esc(entryName(e))}</span><small>#${e.id} · ${esc(e.type||"Item")}</small></button>`).join("")||`<div class="suggestion">No items found</div>`;box.classList.add("show");
});
$("#itemSuggestions").addEventListener("click",e=>{const b=e.target.closest("[data-pick]");if(!b)return;const item=entries[+b.dataset.pick];$("#itemSearch").value=entryName(item);$("#itemSuggestions").classList.remove("show");showEntry(item)});
$("#findId").onclick=()=>{const id=Number($("#idInput").value),e=entries.find(x=>x.id===id);$("#finderResult").innerHTML="";if(!$("#idInput").value.trim()||!Number.isInteger(id)){toast("Enter a valid whole-number ID");return}if(!e){$("#finderResult").innerHTML=`<div class="empty-state">No entry with ID ${id} exists in this archive.</div>`;return}$("#finderResult").innerHTML=`<div class="finder-result" id="foundDetail"></div>`;$("#itemDetail");$("#foundDetail").innerHTML=`<div class="detail-layout"><div class="detail-visual">${texture(e)?`<img src="${texture(e)}">`:`<div class="no-image">◈</div>`}</div><div class="detail-content"><h2>${esc(entryName(e))}</h2><div class="subline">ID ${e.id} · ${e.kind}</div><div class="property-grid">${props(e)}</div><button class="row-action" id="openFound">Open full record</button></div></div>`;$("#openFound").onclick=()=>showEntry(e,true)};
$("#idInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("#findId").click()});
async function setupHistory(){
 const states=Object.entries(buildState);$("#buildTag").textContent=states[0]?.[1]?.build||"No build";
 $("#buildSummary").innerHTML=states.map(([env,s])=>`<div class="env-card"><small>${esc(env.toUpperCase())}</small><h3>${esc(s.build||"Unknown build")}</h3><p>Checked: ${esc(s.checked_at||"—")}<br>Bundle: ${fmt(s.bundle_size)} bytes<br>Files in manifest: ${fmt((s.files||[]).length+2)}</p><code>${esc((s.bundle_sha256||"").slice(0,28))}…</code></div>`).join("");
 $("#monitorChanges").textContent=await getText(asset("changelogs/monitor-changes.md")).catch(e=>e.message);
 $("#entryChanges").textContent=await getText(asset("changelogs/entries-changes.md")).catch(e=>e.message);
}
function normalizedManifest(s){const arr=(s.files||[]).map(f=>({identity:f.identity||f.path,path:f.path,sha256:f.sha256,size:f.size}));arr.push({identity:"main.js",path:s.bundle_path,sha256:s.bundle_sha256,size:s.bundle_size});arr.push({identity:"main.css",path:s.css_path,sha256:s.css_sha256,size:s.css_size});return arr}
function setupCompare(){
 $("#compareBtn").onclick=()=>{
 const a=buildState[$("#envA").value],b=buildState[$("#envB").value];if(!a||!b)return;
 const A=normalizedManifest(a),B=normalizedManifest(b),am=new Map(A.map(x=>[x.identity,x])),bm=new Map(B.map(x=>[x.identity,x])),keys=new Set([...am.keys(),...bm.keys()]);
 const added=[],removed=[],changed=[],same=[];
 for(const k of keys){const x=am.get(k),y=bm.get(k);if(!x)added.push(y);else if(!y)removed.push(x);else if(x.sha256!==y.sha256)changed.push({identity:k,a:x,b:y});else same.push(k)}
 $("#compareResult").innerHTML=`<div class="compare-kpis"><div class="compare-kpi"><b>${changed.length}</b><small>Changed files</small></div><div class="compare-kpi"><b>${added.length}</b><small>Added files</small></div><div class="compare-kpi"><b>${removed.length}</b><small>Removed files</small></div></div><div class="panel result-panel"><h3>Comparison result</h3><p class="muted">${esc($("#envA").value)} (${esc(a.build)}) vs ${esc($("#envB").value)} (${esc(b.build)})</p><div class="property-grid"><div class="property"><small>Unchanged</small><b>${fmt(same.length)} files</b></div><div class="property"><small>Different bundle</small><b>${a.bundle_sha256===b.bundle_sha256?"No":"Yes"}</b></div><div class="property"><small>Build identifiers</small><b>${a.build===b.build?"Identical":"Different"}</b></div></div>${changed.length?`<h4>Changed</h4><pre class="json-block">${esc(changed.map(x=>x.identity).join("\n"))}</pre>`:"<p class='muted'>No file differences were found between these two supplied environment snapshots.</p>"}</div>`;
 };
 $("#compareBtn").click();
}
function setupCode(){
 const select=$("#codeFile");if(select.options.length)return;
 const files=buildIndex.filter(f=>f.type==="js"||f.type==="css").sort((a,b)=>a.path.localeCompare(b.path));
 select.innerHTML=files.map(f=>`<option value="${esc(f.url)}">${esc(f.path)} · ${fmt(f.size)} B</option>`).join("");
 loadCode();
}
/* ---------- Code viewer (read-only, virtualised, syntax coloured) ---------- */
const ED_LH=20,ED_PADT=10,ED_PADL=14,ED_LONG=4000;
let edLines=[],edCharW=7.5,edScrollRaf=0,edType="js",findPos=0,findQuery="";
const JS_KW=new Set("break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new of return super switch throw try typeof var void while with yield async await static get set from as".split(" "));
const JS_LIT=new Set(["true","false","null","undefined","this","NaN","Infinity"]);
const JS_RE=/(\/\/.*|\/\*.*?(?:\*\/|$))|("(?:[^"\\]|\\.)*(?:"|$)|'(?:[^'\\]|\\.)*(?:'|$)|`(?:[^`\\]|\\.)*(?:`|$))|(\b0[xX][0-9a-fA-F]+\b|\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b)|([A-Za-z_$][\w$]*)(?=\s*\()|([A-Za-z_$][\w$]*)/g;
const CSS_RE=/(\/\*.*?(?:\*\/|$))|("(?:[^"\\]|\\.)*(?:"|$)|'(?:[^'\\]|\\.)*(?:'|$))|(@[\w-]+)|(#[0-9a-fA-F]{3,8}\b)|(-?\d*\.?\d+(?:px|em|rem|%|vh|vw|s|ms|deg|fr)?)|([\w-]+)(?=\s*:)|(url\([^)]*\))/g;
function hlJS(s){let out="",last=0,m;JS_RE.lastIndex=0;
 while((m=JS_RE.exec(s))){if(m.index>last)out+=esc(s.slice(last,m.index));const t=m[0];let cls=null;
  if(m[1])cls="c";else if(m[2])cls="s";else if(m[3])cls="n";else if(m[4])cls=JS_KW.has(t)?"k":"f";else if(m[5])cls=JS_KW.has(t)?"k":JS_LIT.has(t)?"l":null;
  out+=cls?`<i class="t${cls}">${esc(t)}</i>`:esc(t);last=JS_RE.lastIndex;if(t.length===0)JS_RE.lastIndex++}
 return out+esc(s.slice(last))}
function hlCSS(s){let out="",last=0,m;CSS_RE.lastIndex=0;
 while((m=CSS_RE.exec(s))){if(m.index>last)out+=esc(s.slice(last,m.index));const t=m[0];let cls="n";
  if(m[1])cls="c";else if(m[2]||m[7])cls="s";else if(m[3])cls="k";else if(m[6])cls="p";
  out+=`<i class="t${cls}">${esc(t)}</i>`;last=CSS_RE.lastIndex;if(t.length===0)CSS_RE.lastIndex++}
 return out+esc(s.slice(last))}
function measureChar(){const body=$("#edBody");if(!body)return;const t=document.createElement("span");t.className="ed-measure";t.textContent="M".repeat(200);body.appendChild(t);const w=t.getBoundingClientRect().width/200;t.remove();if(w>0)edCharW=w}
function renderEditor(){
 const ta=$("#edText");if(!ta||!edLines.length)return;
 const H=ta.clientHeight,W=ta.clientWidth,st=ta.scrollTop,sl=ta.scrollLeft;if(!H)return;
 const first=Math.max(0,Math.floor((st-ED_PADT)/ED_LH)-2),last=Math.min(edLines.length-1,Math.ceil((st+H-ED_PADT)/ED_LH)+2);
 const hl=edType==="css"?hlCSS:hlJS;let rows="",gut="";
 for(let i=first;i<=last;i++){
  const top=ED_PADT+i*ED_LH-st,line=edLines[i];let body;
  if(line.length>ED_LONG){const c0=Math.max(0,Math.floor(sl/edCharW)-60),c1=c0+Math.ceil(W/edCharW)+160;body=`<span class="lt" style="margin-left:${ED_PADL-sl+c0*edCharW}px">${hl(line.slice(c0,c1))}</span>`}
  else body=`<span class="lt" style="margin-left:${ED_PADL-sl}px">${hl(line)}</span>`;
  rows+=`<div class="erow" style="top:${top}px">${body}</div>`;
  gut+=`<div class="grow" style="top:${top}px"><span class="gn">${i+1}</span></div>`;
 }
 $("#edRows").innerHTML=rows;$("#edGutRows").innerHTML=gut;
}
async function loadCode(){
 const sel=$("#codeFile"),url=sel.value;if(!url)return;
 currentCodeFile=url;$("#codeMeta").textContent="Loading archived source…";$("#codeResults").textContent="";findPos=0;
 try{
  const text=await getText(asset(url));if(url!==sel.value)return;
  const f=buildIndex.find(x=>x.url===url);loadedCode=text;edLines=text.split("\n");edType=/\.css$/i.test(f.path)?"css":"js";
  const ta=$("#edText");ta.value=text;ta.scrollTop=0;ta.scrollLeft=0;measureChar();renderEditor();
  $("#codeMeta").textContent=`${f.path} · ${fmt(f.size)} bytes · ${fmt(edLines.length)} lines · SHA-256 ${f.sha256.slice(0,18)}…`;
 }catch(e){$("#codeMeta").textContent=e.message}
}
function findInCode(){
 const q=$("#codeSearch").value,ta=$("#edText");if(!q||!ta.value)return;
 if(q!==findQuery){findQuery=q;findPos=0}
 const hay=ta.value,low=hay.toLowerCase(),ql=q.toLowerCase();
 let idx=low.indexOf(ql,findPos);if(idx<0)idx=low.indexOf(ql,0);
 if(idx<0){$("#codeResults").textContent="No match in this file.";return}
 let total=0,i=-1;while((i=low.indexOf(ql,i+1))>=0&&total<100000)total++;
 findPos=idx+1;const line=hay.slice(0,idx).split("\n").length,col=idx-(hay.lastIndexOf("\n",idx-1)+1);
 $("#codeResults").textContent=`Line ${fmt(line)} · ${fmt(total)}${total>=100000?"+":""} match${total===1?"":"es"} in this file (press Find or Enter for the next one)`;
 ta.focus();ta.setSelectionRange(idx,idx+q.length);
 ta.scrollTop=Math.max(0,(line-1)*ED_LH-ta.clientHeight/3);ta.scrollLeft=Math.max(0,col*edCharW-ta.clientWidth/3);renderEditor();
}
function downloadCode(){
 const f=buildIndex.find(x=>x.url===currentCodeFile);if(!f)return;
 const name=f.path.split("/").pop();
 const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([loadedCode],{type:"text/plain;charset=utf-8"}));a.download=name;document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(a.href),3000);toast("Downloading "+name);
}
(function wireViewer(){
 const ta=$("#edText");
 ta.addEventListener("scroll",()=>{if(edScrollRaf)return;edScrollRaf=requestAnimationFrame(()=>{edScrollRaf=0;renderEditor()})});
 ta.addEventListener("keydown",e=>{if(e.key==="Escape")ta.blur()});
 $("#codeDownload").onclick=downloadCode;
 window.addEventListener("resize",()=>renderEditor());
 if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>{measureChar();renderEditor()});
})();
$("#searchCode").onclick=findInCode;$("#codeSearch").addEventListener("keydown",e=>{if(e.key==="Enter")findInCode()});
$("#codeFile").addEventListener("change",loadCode);
const globalBtn=document.createElement("button");globalBtn.className="secondary";globalBtn.textContent="Search all JS";globalBtn.id="globalSearch";$("#code-toolbar")?.append(globalBtn); // toolbar is selected below
const toolbar=document.querySelector(".code-toolbar");if(toolbar&&!$("#globalSearch")){globalBtn.id="globalSearch";toolbar.append(globalBtn)}
globalBtn.onclick=async()=>{
 const q=$("#codeSearch").value.trim().toLowerCase();if(!q){toast("Enter text to search");return}
 const files=buildIndex.filter(f=>f.type==="js");let hits=[],checked=0;$("#codeResults").textContent="Scanning archived JavaScript…";
 for(const f of files){try{const txt=f.url===currentCodeFile?$("#edText").value:await getText(asset(f.url));const idx=txt.toLowerCase().indexOf(q);if(idx>=0){const line=txt.slice(0,idx).split("\n").length;hits.push({path:f.path,line,snippet:txt.slice(Math.max(0,idx-70),Math.min(txt.length,idx+120)).replace(/\s+/g," ")});if(hits.length>=80)break}}catch{}checked++;if(checked%30===0)$("#codeResults").textContent=`Scanned ${checked}/${files.length} files · ${hits.length} matches…`}
 $("#codeResults").innerHTML=`<div class="hit-head">${hits.length?`${hits.length} matching files/snippets`:"No matches found"} · scanned ${checked} files</div>`+hits.map(h=>`<div class="hit"><b>${esc(h.path)}</b> <span class="muted">line ${h.line}</span><div class="hit-snippet">${esc(h.snippet)}</div></div>`).join("");
};
init();

/* ---------- Mobs ---------- */
const MOB_API="https://bloxd-mcp.bloxd-data-fetcher.workers.dev/api";
const MOB_KEY_STATS=[["maxHealth","Max health"],["attackDamage","Attack damage"],["secondaryAttackDamage","Secondary damage"],["attackInterval","Attack interval"],["attackRadius","Attack range"],["chaseRadius","Chase radius"],["baseWalkingSpeed","Walking speed"],["baseRunningSpeed","Running speed"],["knockbackReceivedMultiplier","Knockback taken"],["healthRegen","Health regen"]];
let mobData={mobs:[],settings:[]},mobSelected=null,mobToken=0;const mobCache=new Map();
const humanize=s=>s.replace(/([A-Z])/g," $1").replace(/^./,c=>c.toUpperCase());
function unwrapMob(j,setting){
 if(j===null||j===undefined)return undefined;
 if(typeof j!=="object")return j;
 if(setting&&Object.prototype.hasOwnProperty.call(j,setting))return j[setting];
 for(const k of ["value","data","result","settings"])if(k in j)return unwrapMob(j[k],setting);
 return j;
}
const fmtMobVal=v=>v===undefined||v===null?"—":typeof v==="number"?String(Math.round(v*1000)/1000):typeof v==="object"?JSON.stringify(v):String(v);
async function fetchMob(name,setting){
 const key=name+"|"+(setting||"");if(mobCache.has(key))return mobCache.get(key);
 const url=MOB_API+"/mobs?mob="+encodeURIComponent(name)+(setting?"&setting="+encodeURIComponent(setting):"");
 const r=await fetch(url);if(!r.ok)throw Error("HTTP "+r.status);
 const t=await r.text();let j;try{j=JSON.parse(t)}catch{j=t.trim()}
 const v=unwrapMob(j,setting);mobCache.set(key,v);return v;
}
function setupMobs(){
 $("#mobCount").textContent=fmt(mobData.mobs.length)+" mobs";
 $("#mobSearch").addEventListener("input",renderMobList);
 renderMobList();
}
function renderMobList(){
 const q=($("#mobSearch")?.value||"").toLowerCase().trim();
 const list=mobData.mobs.filter(m=>!q||m.name.toLowerCase().includes(q)).sort((a,b)=>a.name.localeCompare(b.name));
 $("#mobList").innerHTML=list.length?list.map(m=>`<button class="mob-item${m.name===mobSelected?" active":""}" data-mob="${esc(m.name)}"><span class="mob-initial">${esc(m.name.trim()[0]||"?")}</span><span class="mob-name">${esc(m.name)}</span><small>${m.variations.length} var.</small></button>`).join(""):`<div class="empty-state"><p>No mobs match “${esc(q)}”.</p></div>`;
 $$("#mobList .mob-item").forEach(b=>b.onclick=()=>selectMob(b.dataset.mob));
}
async function selectMob(name){
 mobSelected=name;renderMobList();
 const m=mobData.mobs.find(x=>x.name===name);if(!m)return;
 const token=++mobToken;
 $("#mobDetail").innerHTML=`<div class="detail-content"><h2>${esc(m.name)}</h2><div class="subline">${m.variations.length} variation${m.variations.length===1?"":"s"}</div><div class="tag-row">${m.variations.map(v=>`<span class="tag">${esc(v)}</span>`).join("")}</div><div class="subline record-label">Stats</div><div id="mobStats" class="muted">Loading stats…</div><div id="mobMore"></div></div>`;
 const res=await Promise.allSettled(MOB_KEY_STATS.map(([k])=>fetchMob(name,k)));
 if(token!==mobToken)return;
 const ok=res.filter(r=>r.status==="fulfilled"&&r.value!==undefined).length;
 if(!ok){
  const why=res.find(r=>r.status==="rejected")?.reason?.message||"no data returned";
  $("#mobStats").innerHTML=`<div class="notice error inline"><span>!</span><div><b>Live stats could not be loaded.</b><p>${esc(why)}. The stats come from the Bloxd data API at <code>${esc(MOB_API)}</code>; check that it is online and allows requests from this site.</p></div></div>`;
 }else{
  $("#mobStats").className="";
  $("#mobStats").innerHTML=`<div class="property-grid">${MOB_KEY_STATS.map(([k,label],i)=>`<div class="property"><small>${esc(label)}</small><b>${esc(fmtMobVal(res[i].status==="fulfilled"?res[i].value:undefined))}</b></div>`).join("")}</div>`;
  $("#mobMore").innerHTML=`<button class="secondary more-btn" id="mobAll">Load all ${mobData.settings.length} settings</button>`;
  $("#mobAll").onclick=()=>loadAllMobSettings(name,token);
 }
}
async function loadAllMobSettings(name,token){
 const btn=$("#mobAll");btn.disabled=true;btn.textContent="Loading…";
 let rows=null;
 try{const all=await fetchMob(name,"");if(all&&typeof all==="object"&&!Array.isArray(all)&&mobData.settings.some(s=>s in all))rows=mobData.settings.filter(s=>s in all).map(s=>[s,all[s]])}catch{}
 if(!rows){
  rows=[];let i=0;const todo=mobData.settings.filter(s=>s!=="name"&&s!=="variation");
  await Promise.all(Array.from({length:6},async()=>{while(i<todo.length){const s=todo[i++];try{const v=await fetchMob(name,s);if(v!==undefined&&v!==null)rows.push([s,v])}catch{}}}));
  rows.sort((a,b)=>mobData.settings.indexOf(a[0])-mobData.settings.indexOf(b[0]));
 }
 if(token!==mobToken)return;
 $("#mobMore").innerHTML=rows.length?`<div class="subline record-label">All settings (${rows.length})</div><div class="table-wrap"><table><thead><tr><th>Setting</th><th>Value</th></tr></thead><tbody>${rows.map(([k,v])=>`<tr><td>${esc(humanize(k))}</td><td><code>${esc(fmtMobVal(v))}</code></td></tr>`).join("")}</tbody></table></div>`:`<p class="muted">No additional settings were returned for this mob.</p>`;
}

/* ---------- Repository change monitor (GitHub commits and diffs) ---------- */
const GH_API="https://api.github.com";
const MONITORS={
 codeapi:{owner:"Bloxdy",repo:"code-api",branch:"main",root:"#codeApiMonitor",label:"Code API"}
};
var monInit={},monState={};
const MON_TTL=10*60*1000,ghCache=new Map();
const lsGet=k=>{try{const v=JSON.parse(localStorage.getItem("bhub:"+k)||"null");if(v&&Date.now()-v.t<MON_TTL)return v.d}catch{}return null};
const lsSet=(k,d)=>{try{localStorage.setItem("bhub:"+k,JSON.stringify({t:Date.now(),d}))}catch{}};
const lsClear=()=>{try{Object.keys(localStorage).filter(x=>x.startsWith("bhub:/repos/")).forEach(x=>localStorage.removeItem(x))}catch{}};
async function ghGet(path,persist){
 if(ghCache.has(path))return ghCache.get(path);
 if(persist){const hit=lsGet(path);if(hit){ghCache.set(path,hit);return hit}}
 const r=await fetch(GH_API+path,{headers:{Accept:"application/vnd.github+json"}});
 if(r.status===403||r.status===429){const reset=+r.headers.get("x-ratelimit-reset");const e=Error("GitHub's request limit was reached"+(reset?` — try again after ${new Date(reset*1000).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}`:""));throw e}
 if(r.status===404)throw Error("Repository or commit not found on GitHub");
 if(!r.ok)throw Error("GitHub returned status "+r.status);
 const out={json:await r.json(),link:r.headers.get("link")||""};ghCache.set(path,out);if(persist)lsSet(path,out);return out;
}
const lastPage=l=>{const m=/[?&]page=(\d+)[^>]*>;\s*rel="last"/.exec(l||"");return m?+m[1]:0};
function timeAgo(iso){const s=Math.max(0,(Date.now()-new Date(iso))/1000);if(s<60)return"just now";const m=s/60;if(m<60)return Math.floor(m)+" min ago";const h=m/60;if(h<24)return Math.floor(h)+" hr ago";const d=h/24;if(d<30)return Math.floor(d)+" d ago";const mo=d/30;if(mo<12)return Math.floor(mo)+" mo ago";return Math.floor(d/365)+" yr ago"}
/* common prefix/suffix between two lines: gives the changed middle and per-line character counts */
function lineDelta(o,n){let p=0;const m=Math.min(o.length,n.length);while(p<m&&o.charCodeAt(p)===n.charCodeAt(p))p++;let s=0;while(s<m-p&&o.charCodeAt(o.length-1-s)===n.charCodeAt(n.length-1-s))s++;return{p,s}}
function markLine(text,p,s){const mid=text.length-p-s;if(mid<=0||(p===0&&s===0&&false))return esc(text);return esc(text.slice(0,p))+"<mark>"+esc(text.slice(p,text.length-s))+"</mark>"+esc(text.slice(text.length-s))}
function parsePatch(patch){
 const lines=patch.split("\n"),out=[];let o=0,n=0,i=0;
 while(i<lines.length){
  const L=lines[i];
  if(L.startsWith("@@")){const m=/@@ -(\d+)(?:,\d+)? \+(\d+)/.exec(L);o=m?+m[1]:0;n=m?+m[2]:0;out.push({t:"h",text:L});i++;continue}
  if(L[0]==="\\"||(L===""&&i===lines.length-1)){i++;continue}
  if(L[0]==="-"||L[0]==="+"){
   const dels=[],adds=[];
   while(i<lines.length&&lines[i][0]==="-"){dels.push(lines[i].slice(1));i++}
   while(i<lines.length&&lines[i][0]==="+"){adds.push(lines[i].slice(1));i++}
   dels.forEach((t,k)=>out.push({t:"d",o:o+k,text:t,pair:k<adds.length?adds[k]:null}));
   adds.forEach((t,k)=>out.push({t:"a",n:n+k,text:t,pair:k<dels.length?dels[k]:null}));
   o+=dels.length;n+=adds.length;continue;
  }
  out.push({t:"c",o:o++,n:n++,text:L.slice(1)});i++;
 }
 return out;
}
function diffRowHTML(r){
 if(r.t==="h")return`<div class="dl dh"><span class="dn"></span><span class="dn"></span><span class="dc">${esc(r.text)}</span><span class="dk"></span></div>`;
 if(r.t==="c")return`<div class="dl"><span class="dn">${r.o}</span><span class="dn">${r.n}</span><span class="dc">${esc(r.text)}</span><span class="dk"></span></div>`;
 let body,count;
 if(r.pair!==null){const d=r.t==="d"?lineDelta(r.text,r.pair):lineDelta(r.pair,r.text);body=markLine(r.text,d.p,d.s);count=r.text.length-d.p-d.s}
 else{body=esc(r.text);count=r.text.length}
 return r.t==="d"
  ?`<div class="dl del"><span class="dn">${r.o}</span><span class="dn"></span><span class="dc"><i class="sg">−</i>${body}</span><span class="dk">−${fmt(count)}</span></div>`
  :`<div class="dl add"><span class="dn"></span><span class="dn">${r.n}</span><span class="dc"><i class="sg">+</i>${body}</span><span class="dk">+${fmt(count)}</span></div>`;
}
const MON_ROWS=400;
function fileCardHTML(f,idx,open,commitUrl){
 const st=f.status==="added"?"new":f.status==="removed"?"deleted":f.status==="renamed"?"renamed":"modified";
 const name=f.status==="renamed"&&f.previous_filename?`${esc(f.previous_filename)} → ${esc(f.filename)}`:esc(f.filename);
 let body;
 if(!f.patch)body=`<div class="mon-note">The diff is too large or not text, so GitHub did not include it. <a href="${esc(commitUrl)}" target="_blank" rel="noreferrer">Open the commit on GitHub ↗</a></div>`;
 else{const rows=parsePatch(f.patch);const shown=rows.slice(0,MON_ROWS).map(diffRowHTML).join("");
  body=`<div class="diff" data-file="${idx}">${shown}</div>${rows.length>MON_ROWS?`<button class="mon-more" data-more="${idx}">Show ${fmt(rows.length-MON_ROWS)} more lines</button>`:""}`}
 return`<section class="mon-file${open?" open":""}"><header class="mon-file-head" data-toggle><span class="chev">▸</span><b>${name}</b><span class="mon-status ${st}">${st}</span><span class="pm"><span class="ga">+${fmt(f.additions||0)}</span><span class="gr">−${fmt(f.deletions||0)}</span></span></header><div class="mon-file-body">${body}</div></section>`;
}
function commitSummary(c){const msg=(c.commit.message||"").split("\n");return{title:msg[0]||"(no message)",body:msg.slice(1).join("\n").trim()}}
function commitHeaderHTML(c,detail){
 const {title}=commitSummary(c),sha=c.sha.slice(0,12),who=c.author?.login||c.commit.author?.name||"unknown";
 const st=detail?.stats;
 return`<header class="mon-commit-head"><div><h3>${esc(title)}</h3><div class="subline">${timeAgo(c.commit.author.date)} · <a href="${esc(c.html_url)}" target="_blank" rel="noreferrer">${sha}</a> · ${esc(who)}</div></div>${st?`<div class="pm big"><span class="ga">+${fmt(st.additions)}</span><span class="gr">−${fmt(st.deletions)}</span></div>`:""}</header>`;
}
function commitDetailHTML(c,detail){
 const files=detail.files||[];const total=files.reduce((a,f)=>a+(f.patch?f.patch.split("\n").length:0),0);
 const cards=files.map((f,i)=>fileCardHTML(f,i,files.length===1||total<=500||i===0,c.html_url)).join("");
 const more=detail.files&&detail.files.length>=300?`<div class="mon-note">GitHub lists at most 300 files per commit.</div>`:"";
 return`<div class="mon-files">${cards||'<div class="mon-note">This commit changed no files.</div>'}${more}</div>`;
}
function wireDiffs(scope,detailFiles){
 scope.querySelectorAll("[data-toggle]").forEach(h=>h.onclick=()=>h.parentElement.classList.toggle("open"));
 scope.querySelectorAll("[data-more]").forEach(b=>b.onclick=()=>{const idx=+b.dataset.more,box=b.previousElementSibling;box.innerHTML=parsePatch(detailFiles[idx].patch).map(diffRowHTML).join("");b.remove()});
}
async function initMonitor(key,force){
 const cfg=MONITORS[key],root=$(cfg.root);if(!root)return;monInit[key]=true;
 if(force){ghCache.clear();lsClear()}
 root.innerHTML=`<div class="mon-loading">Loading the latest ${esc(cfg.label)} changes…</div>`;
 const base=`/repos/${cfg.owner}/${cfg.repo}`;
 try{
  const [list,one]=await Promise.all([ghGet(`${base}/commits?sha=${cfg.branch}&per_page=30`,true),ghGet(`${base}/commits?sha=${cfg.branch}&per_page=1`,true)]);
  const commits=list.json;if(!commits.length)throw Error("No commits were returned for this repository");
  const total=lastPage(one.link)||commits.length;
  monState[key]={commits,total,tab:"last",details:new Map()};
  const latest=(await ghGet(`${base}/commits/${commits[0].sha}`)).json;monState[key].details.set(commits[0].sha,latest);
  renderMonitor(key);
 }catch(e){
  root.innerHTML=`<div class="notice error"><span>!</span><div><b>The ${esc(cfg.label)} changes could not be loaded.</b><p>${esc(e.message)}. This view reads commits live from GitHub (<code>${esc(cfg.owner)}/${esc(cfg.repo)}</code>), so it needs an internet connection and is subject to GitHub's public request limit.</p><button class="secondary mon-retry">Try again</button></div></div>`;
  root.querySelector(".mon-retry").onclick=()=>initMonitor(key,true);
 }
}
function renderMonitor(key){
 const cfg=MONITORS[key],st=monState[key],root=$(cfg.root),latest=st.commits[0],ld=st.details.get(latest.sha);
 root.innerHTML=`<div class="mon-stats"><div class="stat-card"><div class="stat-value">${fmt(st.total)}</div><div class="stat-label">Commits tracked</div><div class="stat-foot">${esc(cfg.owner)}/${esc(cfg.repo)}</div></div><div class="stat-card"><div class="stat-value">${timeAgo(latest.commit.author.date)}</div><div class="stat-label">Last change</div><div class="stat-foot">${esc(latest.sha.slice(0,12))}</div></div><div class="stat-card"><div class="stat-value">${ld?fmt((ld.files||[]).length):"—"}</div><div class="stat-label">Files in last change</div><div class="stat-foot">${ld?`+${fmt(ld.stats.additions)} −${fmt(ld.stats.deletions)} lines`:""}</div></div></div>
  <div class="mon-tabs"><button class="mon-tab active" data-tab="last">Last change</button><button class="mon-tab" data-tab="hist">History <span class="count-chip">${fmt(Math.min(st.total,st.commits.length))}</span></button><button class="secondary mon-refresh">Refresh</button></div><div class="mon-body"></div>`;
 root.querySelectorAll(".mon-tab").forEach(b=>b.onclick=()=>{st.tab=b.dataset.tab;root.querySelectorAll(".mon-tab").forEach(x=>x.classList.toggle("active",x===b));renderMonitorBody(key)});
 root.querySelector(".mon-refresh").onclick=()=>initMonitor(key,true);
 renderMonitorBody(key);
}
function renderMonitorBody(key){
 const cfg=MONITORS[key],st=monState[key],body=$(cfg.root+" .mon-body");
 if(st.tab==="last"){
  const c=st.commits[0],d=st.details.get(c.sha);
  body.innerHTML=`<article class="mon-commit">${commitHeaderHTML(c,d)}${commitDetailHTML(c,d)}</article>`;wireDiffs(body,d.files||[]);return;
 }
 body.innerHTML=`<div class="mon-history">${st.commits.map((c,i)=>{const {title}=commitSummary(c);return`<article class="mon-hist" data-sha="${c.sha}"><button class="mon-hist-head"><span class="chev">▸</span><span class="mon-hist-title">${esc(title)}</span><span class="subline">${timeAgo(c.commit.author.date)} · ${esc(c.sha.slice(0,12))}</span></button><div class="mon-hist-body"></div></article>`}).join("")}</div><p class="muted mon-foot">Showing the ${st.commits.length} most recent commits. Open one to load its changes.</p>`;
 body.querySelectorAll(".mon-hist").forEach(el=>{el.querySelector(".mon-hist-head").onclick=async()=>{
  const open=el.classList.toggle("open"),box=el.querySelector(".mon-hist-body");if(!open||box.dataset.loaded)return;
  const sha=el.dataset.sha,c=st.commits.find(x=>x.sha===sha);box.innerHTML='<div class="mon-loading">Loading changes…</div>';
  try{let d=st.details.get(sha);if(!d){d=(await ghGet(`/repos/${cfg.owner}/${cfg.repo}/commits/${sha}`)).json;st.details.set(sha,d)}
   box.innerHTML=commitHeaderHTML(c,d)+commitDetailHTML(c,d);box.dataset.loaded="1";wireDiffs(box,d.files||[])}
  catch(e){box.innerHTML=`<div class="mon-note">${esc(e.message)}</div>`}
 }});
}
