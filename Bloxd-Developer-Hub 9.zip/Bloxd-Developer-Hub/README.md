# Bloxd Developer Hub

A static, mobile-friendly research workspace built from the two supplied repositories:

- **Bloxd-Entries-Data** — extracted Bloxd block/item registry records and PNG textures.
- **Bloxd-Build-Monitor** — archived production, preproduction and staging build manifests, JavaScript/CSS bundles, and change reports.

## Features

- **Block database** — searchable registry with ID, kind, key properties, pagination and full JSON record inspection.
- **Texture viewer** — browse the extracted PNG textures and inspect their associated entries.
- **Item inspector** — search item records and inspect available combat, tool, armour, food and special properties.
- **ID finder** — exact numeric ID lookup.
- **Build history** — displays the archived environment build metadata and included change reports.
- **Build comparison** — compares the supplied environment manifests using file identity and SHA-256 values.
- **Code explorer** — browse archived production JavaScript/CSS files, search the selected file, or search across archived JavaScript files.

## Data included

- 10,080 registry JSON records, including state variants.
- 10,068 PNG textures.
- Production build bundle files and chunks.
- Full manifest metadata for `bloxd.io`, `preprod.bloxd.io`, and `staging.bloxd.io`.
- Source updater/monitor scripts and workflow files in `sources/`.

The entry catalog is consolidated into `public/data/catalog.json` to avoid shipping thousands of individual JSON requests. Each record retains the original extracted fields and adds `_texture`, a relative path to its corresponding PNG when one exists.

## Run locally

Use any static web server. For example:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

Do not open `index.html` directly with a `file://` URL because the application fetches its JSON and archive assets.

## Deploy to Vercel

1. Upload this project folder to a GitHub repository (keep the `public/` folder inside it).
2. In Vercel, import that repository.
3. Leave the framework as **Other** and the build command empty. The included `vercel.json` already sets the output directory to `.`.
4. Deploy.

All asset paths (`public/data/...`, `public/textures/...`, `public/builds/...`) are relative, so the site also works from any static host or sub-folder.

## Data and archive limitations

- This site is an explorer for the supplied snapshots, not a live Bloxd client or a live game API.
- The supplied Build Monitor archive contains the snapshot identified in its manifest. It does not contain a full chronological set of prior game bundle snapshots. The UI therefore reports only what the archive actually provides.
- Environment comparisons are based on the three manifests included in the uploaded archive. The bundled source snapshot currently reports matching build IDs and hashes for all three environments.
- The Code Explorer reads the included archived files. It does not execute game code.
- The archive itself is a static snapshot and does not update itself. The exception is the **Code API changes** page, which reads commits live from GitHub in the visitor's browser (public GitHub API, subject to its request limit). The repository is set in the `MONITORS` constant at the bottom of `app.js`. The original monitor and entries updater source files are retained under `sources/` for a developer to configure separately.
- Data is provided as a research snapshot. Verify the source repositories' current terms and licenses before redistributing extracted game assets or bundles publicly.

## Source repositories

- Entries data: the supplied `Bloxd-Entries-Data-main` archive; its README does not declare a canonical repository URL.

The Build Monitor's original license is included in `sources/monitor-LICENSE`. The Entries repository's source documentation and updater files are retained under `sources/`.

## Project layout

```text
Bloxd-Developer-Hub/
├── index.html
├── styles.css
├── app.js
├── public/
│   ├── data/
│   │   ├── catalog.json
│   │   ├── build-index.json
│   │   └── build-state.json
│   ├── textures/
│   ├── builds/bloxd.io/
│   └── changelogs/
├── sources/
│   ├── entries/
│   └── monitor/
└── README.md
```
