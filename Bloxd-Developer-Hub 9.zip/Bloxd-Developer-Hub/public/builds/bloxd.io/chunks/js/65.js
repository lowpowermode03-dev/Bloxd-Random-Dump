export const id = 65;
export const ids = [65];
export const modules = {
  35520: (OO, KO, pO) => {
    if (pO.d(KO, {
        c: () => CO,
        e: () => bK,
        h: () => lO,
        j: () => eO,
        n: () => dO,
        q: () => QO
      }), 35 == pO.j) var XO = pO(35526);
    const bK = ["Wood", "Stone", "Iron", "Gold", "Diamond", "Moonstone", "Magmasteel", "Sanguine", "Astral"],
      eO = ["Blade", "Guard", "Handle"],
      lO = {
        Wood: {
          material: "Wood",
          baseSword: "Wood Sword",
          value: 1,
          epithet: "Timber",
          palette: ["#b88a52", "#7d5a32", "#3d2a14"],
          trait: null,
          bladeDamage: 0,
          guardReduction: 0,
          handleCooldown: 1,
          handleKnockback: 0,
          handleReach: 0
        },
        Stone: {
          material: "Stone",
          baseSword: "Stone Sword",
          value: 1,
          epithet: "Flint",
          palette: ["#a3a3a3", "#6e6e6e", "#333333"],
          trait: null,
          bladeDamage: .03,
          guardReduction: .02,
          handleCooldown: .98,
          handleKnockback: .05,
          handleReach: 0
        },
        Iron: {
          material: "Iron",
          baseSword: "Iron Sword",
          value: 2,
          epithet: "Ironclad",
          palette: ["#e6e6e6", "#a8a8a8", "#444444"],
          trait: "defence",
          bladeDamage: .06,
          guardReduction: .05,
          handleCooldown: .95,
          handleKnockback: .1,
          handleReach: 0
        },
        Gold: {
          material: "Gold",
          baseSword: "Gold Sword",
          value: 2,
          epithet: "Gilded",
          palette: ["#ffe766", "#e0a91d", "#6b4a07"],
          trait: "coins",
          bladeDamage: .07,
          guardReduction: .04,
          handleCooldown: .94,
          handleKnockback: .05,
          handleReach: 0
        },
        Diamond: {
          material: "Diamond",
          baseSword: "Diamond Sword",
          value: 4,
          epithet: "Brilliant",
          palette: ["#8ff5ec", "#2fbcb0", "#0d4f4a"],
          trait: "crit",
          bladeDamage: .12,
          guardReduction: .07,
          handleCooldown: .92,
          handleKnockback: .1,
          handleReach: 0
        },
        Moonstone: {
          material: "Moonstone",
          baseSword: "Moonstone Sword",
          value: 4,
          epithet: "Moonlit",
          palette: ["#d9d2ff", "#8f7fe0", "#352a73"],
          trait: "bossBane",
          bladeDamage: .15,
          guardReduction: .08,
          handleCooldown: .9,
          handleKnockback: .1,
          handleReach: .25
        },
        Magmasteel: {
          material: "Magmasteel",
          baseSword: "Magmasteel Sword",
          value: 8,
          epithet: "Molten",
          palette: ["#ffb347", "#e0461b", "#4f1208"],
          trait: "firePool",
          bladeDamage: .29,
          guardReduction: .1,
          handleCooldown: .88,
          handleKnockback: .2,
          handleReach: .35
        },
        Sanguine: {
          material: "Sanguine",
          baseSword: "Sanguine Sword",
          value: 8,
          epithet: "Crimson",
          palette: ["#ff6b7a", "#b0172f", "#45040f"],
          trait: "lifesteal",
          bladeDamage: .29,
          guardReduction: .1,
          handleCooldown: .87,
          handleKnockback: .15,
          handleReach: .35
        },
        Astral: {
          material: "Astral",
          baseSword: "Astral Sword",
          value: 10,
          epithet: "Starforged",
          palette: ["#9fd8ff", "#5a6bff", "#1c1550"],
          trait: "starfall",
          bladeDamage: .4,
          guardReduction: .12,
          handleCooldown: .83,
          handleKnockback: .2,
          handleReach: .5
        }
      },
      vK = 4,
      CO = "Coal",
      hO = {
        Blade: 1,
        Guard: .6,
        Handle: .4
      },
      DO = 1.15,
      MO = 1.35,
      aK = .06,
      oO = {
        defence: {
          name: "Bulwark",
          amount: .06,
          describe: OO => `${IO(.06*OO)} less damage taken`
        },
        coins: {
          name: "Midas",
          amount: 4,
          describe: OO => `Mobs you slay drop ${Math.round(4*OO)}+ extra coins`
        },
        crit: {
          name: "Keen Edge",
          chance: .12,
          amount: .6,
          describe: OO => `${IO(.12*OO)} chance to strike for +60% damage`
        },
        bossBane: {
          name: "Bossbane",
          amount: .2,
          describe: OO => `+${IO(.2*OO)} damage to bosses`
        },
        firePool: {
          name: "Magma Pool",
          chance: .15,
          amount: .12,
          cooldownMs: 3e3,
          describe: OO => `${IO(.15*OO)} chance to leave a fire pool under the mob that burns for 3s`
        },
        lifesteal: {
          name: "Bloodthirst",
          amount: .06,
          describe: OO => `Heal ${IO(.06*OO)} of the damage you deal`
        },
        starfall: {
          name: "Starfall",
          chance: .1,
          amount: .6,
          cooldownMs: 4e3,
          describe: OO => `${IO(.1*OO)} chance to call a falling star that hits nearby mobs and slows them`
        }
      },
      FO = {
        eclipseField: {
          name: "Eclipse Field",
          description: "Right-click: slow every mob within 6 blocks for 3s",
          cooldownMs: 25e3
        },
        starfall: {
          name: "Meteor Shower",
          description: "Right-click: call five falling stars around you",
          cooldownMs: 3e4
        },
        magmaWave: {
          name: "Magma Wave",
          description: "Right-click: lay a line of fire pools ahead of you",
          cooldownMs: 2e4
        },
        bloodPact: {
          name: "Blood Pact",
          description: "Right-click: heal 30% of your health",
          cooldownMs: 4e4
        },
        moonDash: {
          name: "Moon Dash",
          description: "Right-click: dash forward, striking mobs you pass",
          cooldownMs: 12e3
        },
        warcry: {
          name: "Warcry",
          description: "Right-click: deal 30% more damage for 8s",
          cooldownMs: 35e3
        },
        quake: {
          name: "Quake",
          description: "Right-click: slam the ground, hurling mobs within 5 blocks",
          cooldownMs: 18e3
        },
        gildedEdge: {
          name: "Gilded Edge",
          description: "Right-click: your next 5 hits deal 50% more damage",
          cooldownMs: 25e3
        }
      },
      VO = 35 == pO.j ? XO.e : null,
      LO = "skyblock:forged:";

    function QO(OO, KO) {
      return `${OO} ${KO}`
    }
    bK.flatMap((OO => eO.map((KO => QO(OO, KO)))));

    function zK(OO) {
      let {
        blade: KO,
        guard: pO,
        handle: XO
      } = OO;
      return `${LO}${KO.toLowerCase()}-${pO.toLowerCase()}-${XO.toLowerCase()}`
    }

    function AO(OO) {
      if (! function(OO) {
          return "string" === typeof OO && OO.startsWith(LO)
        }(OO)) return null;
      const KO = OO.slice(LO.length).split("-").map((OO => bK.find((KO => KO.toLowerCase() === OO))));
      return 3 !== KO.length || KO.includes(void 0) ? null : {
        blade: KO[0],
        guard: KO[1],
        handle: KO[2]
      }
    }
    const fO = new Map;

    function dO(OO) {
      var KO;
      let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : VO;
      const XO = "string" === typeof OO ? AO(OO) : OO;
      if (null === XO) return null;
      const bK = zK(XO),
        CO = pO === VO ? fO.get(bK) : void 0;
      if (void 0 !== CO) return CO;
      const LO = function(OO, KO) {
        var pO, XO, bK, CO, VO, LO, QO, AO, fO;
        const {
          blade: dO,
          guard: gK,
          handle: uO
        } = OO, EO = lO, jK = dO === gK && gK === uO, YO = NO((1 + EO[dO].bladeDamage) * (jK ? 1 + aK : 1)), wO = null !== (pO = KO.damageMultiplier) && void 0 !== pO ? pO : YO, iK = null !== (XO = KO.cooldownMultiplier) && void 0 !== XO ? XO : EO[uO].handleCooldown, rK = null !== (bK = KO.knockbackMultiplier) && void 0 !== bK ? bK : NO(1 + EO[uO].handleKnockback), PO = null !== (CO = KO.reachBonus) && void 0 !== CO ? CO : EO[uO].handleReach, mK = null !== (VO = KO.damageReduction) && void 0 !== VO ? VO : EO[gK].guardReduction, sO = null !== (LO = KO.traits) && void 0 !== LO ? LO : function(OO) {
          const KO = {},
            pO = {};
          for (const vK of eO) {
            var XO, bK;
            const eO = lO[TO(OO, vK)].trait;
            null !== eO && (KO[eO] = (null !== (XO = KO[eO]) && void 0 !== XO ? XO : 0) + hO[vK], pO[eO] = (null !== (bK = pO[eO]) && void 0 !== bK ? bK : 0) + 1)
          }
          for (const eO of Object.keys(KO)) {
            const OO = 3 === pO[eO] ? MO : 2 === pO[eO] ? DO : 1;
            KO[eO] = NO(KO[eO] * OO)
          }
          return KO
        }(OO), HO = null !== (QO = KO.ability) && void 0 !== QO ? QO : null, RO = void 0 !== KO.name, SO = null !== (AO = KO.name) && void 0 !== AO ? AO : jK ? `Pure ${dO} Sword` : `${EO[gK].epithet} ${dO} Sword`, JO = null !== (fO = KO.lore) && void 0 !== fO ? fO : `Forged by the Forge Mother from a ${dO.toLowerCase()} blade, ${gK.toLowerCase()} guard and ${uO.toLowerCase()} handle.`, cK = function(OO) {
          let {
            blade: KO,
            guard: pO,
            handle: XO
          } = OO;
          const bK = lO;
          return vK * (bK[KO].value + bK[pO].value + bK[XO].value)
        }(OO), BO = EO[dO].value + EO[gK].value + EO[uO].value, ZO = RO ? "Tier 5" : BO <= 4 ? "Tier 1" : BO <= 8 ? "Tier 2" : BO <= 14 ? "Tier 3" : BO <= 22 ? "Tier 4" : "Tier 5", GO = [];
        1 !== wO && GO.push(`${yK(wO-1)} damage`);
        1 !== iK && GO.push(`${IO(1/iK-1)} faster strikes`);
        1 !== rK && GO.push(`${yK(rK-1)} knockback`);
        PO > 0 && GO.push(`+${PO} reach`);
        mK > 0 && GO.push(`${IO(mK)} less damage taken while held`);
        const qK = [];
        for (const eO of Object.keys(sO)) qK.push(`${oO[eO].name}: ${oO[eO].describe(sO[eO])}`);
        null !== HO && qK.push(`${FO[HO].name}: ${FO[HO].description}`);
        return GO.push(...qK), {
          id: zK(OO),
          parts: OO,
          baseSword: EO[dO].baseSword,
          displayName: SO,
          lore: JO,
          properties: GO,
          effects: qK,
          named: RO,
          damageMultiplier: wO,
          cooldownMultiplier: iK,
          knockbackMultiplier: rK,
          reachBonus: PO,
          damageReduction: mK,
          traits: sO,
          ability: HO,
          coalCost: cK,
          enchantmentTier: ZO,
          powerMultiplier: NO(wO / iK)
        }
      }(XO, null !== (KO = pO[bK]) && void 0 !== KO ? KO : {});
      return pO === VO && fO.set(bK, LO), LO
    }

    function TO(OO, KO) {
      return "Blade" === KO ? OO.blade : "Guard" === KO ? OO.guard : OO.handle
    }

    function NO(OO) {
      return Math.round(100 * OO) / 100
    }

    function IO(OO) {
      return `${Math.round(100*OO)}%`
    }

    function yK(OO) {
      return `${OO>=0?"+":""}${IO(OO)}`
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);