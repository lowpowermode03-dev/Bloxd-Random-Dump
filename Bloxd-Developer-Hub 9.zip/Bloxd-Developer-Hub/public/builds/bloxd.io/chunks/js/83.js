/*! For license information please see vjxd5n.83.f853dbbd.chunk.js.LICENSE.txt */
export const id = 83;
export const ids = [83];
export const modules = {
  3992: (OO, KO, pO) => {
    var XO;
    ! function() {
      var bK = function() {
        this.init()
      };
      bK.prototype = {
        init: function() {
          var OO = this || eO;
          return OO._counter = 1e3, OO._html5AudioPool = [], OO.html5PoolSize = 10, OO._codecs = {}, OO._howls = [], OO._muted = !1, OO._volume = 1, OO._canPlayEvent = "canplaythrough", OO._navigator = "undefined" !== typeof window && window.navigator ? window.navigator : null, OO.masterGain = null, OO.noAudio = !1, OO.usingWebAudio = !0, OO.autoSuspend = !0, OO.ctx = null, OO.autoUnlock = !0, OO._setup(), OO
        },
        volume: function(OO) {
          var KO = this || eO;
          if (OO = parseFloat(OO), KO.ctx || oO(), "undefined" !== typeof OO && OO >= 0 && OO <= 1) {
            if (KO._volume = OO, KO._muted) return KO;
            KO.usingWebAudio && KO.masterGain.gain.setValueAtTime(OO, eO.ctx.currentTime);
            for (var pO = 0; pO < KO._howls.length; pO++)
              if (!KO._howls[pO]._webAudio)
                for (var XO = KO._howls[pO]._getSoundIds(), bK = 0; bK < XO.length; bK++) {
                  var lO = KO._howls[pO]._soundById(XO[bK]);
                  lO && lO._node && (lO._node.volume = lO._volume * OO)
                }
            return KO
          }
          return KO._volume
        },
        mute: function(OO) {
          var KO = this || eO;
          KO.ctx || oO(), KO._muted = OO, KO.usingWebAudio && KO.masterGain.gain.setValueAtTime(OO ? 0 : KO._volume, eO.ctx.currentTime);
          for (var pO = 0; pO < KO._howls.length; pO++)
            if (!KO._howls[pO]._webAudio)
              for (var XO = KO._howls[pO]._getSoundIds(), bK = 0; bK < XO.length; bK++) {
                var lO = KO._howls[pO]._soundById(XO[bK]);
                lO && lO._node && (lO._node.muted = !!OO || lO._muted)
              }
          return KO
        },
        stop: function() {
          for (var OO = this || eO, KO = 0; KO < OO._howls.length; KO++) OO._howls[KO].stop();
          return OO
        },
        unload: function() {
          for (var OO = this || eO, KO = OO._howls.length - 1; KO >= 0; KO--) OO._howls[KO].unload();
          return OO.usingWebAudio && OO.ctx && "undefined" !== typeof OO.ctx.close && (OO.ctx.close(), OO.ctx = null, oO()), OO
        },
        codecs: function(OO) {
          return (this || eO)._codecs[OO.replace(/^x-/, "")]
        },
        _setup: function() {
          var OO = this || eO;
          if (OO.state = OO.ctx && OO.ctx.state || "suspended", OO._autoSuspend(), !OO.usingWebAudio)
            if ("undefined" !== typeof Audio) try {
              "undefined" === typeof(new Audio).oncanplaythrough && (OO._canPlayEvent = "canplay")
            } catch (KO) {
              OO.noAudio = !0
            } else OO.noAudio = !0;
          try {
            (new Audio).muted && (OO.noAudio = !0)
          } catch (KO) {}
          return OO.noAudio || OO._setupCodecs(), OO
        },
        _setupCodecs: function() {
          var OO = this || eO,
            KO = null;
          try {
            KO = "undefined" !== typeof Audio ? new Audio : null
          } catch (DO) {
            return OO
          }
          if (!KO || "function" !== typeof KO.canPlayType) return OO;
          var pO = KO.canPlayType("audio/mpeg;").replace(/^no$/, ""),
            XO = OO._navigator ? OO._navigator.userAgent : "",
            bK = XO.match(/OPR\/([0-6].)/g),
            lO = bK && parseInt(bK[0].split("/")[1], 10) < 33,
            vK = -1 !== XO.indexOf("Safari") && -1 === XO.indexOf("Chrome"),
            CO = XO.match(/Version\/(.*?) /),
            hO = vK && CO && parseInt(CO[1], 10) < 15;
          return OO._codecs = {
            mp3: !(lO || !pO && !KO.canPlayType("audio/mp3;").replace(/^no$/, "")),
            mpeg: !!pO,
            opus: !!KO.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/, ""),
            ogg: !!KO.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, ""),
            oga: !!KO.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, ""),
            wav: !!(KO.canPlayType('audio/wav; codecs="1"') || KO.canPlayType("audio/wav")).replace(/^no$/, ""),
            aac: !!KO.canPlayType("audio/aac;").replace(/^no$/, ""),
            caf: !!KO.canPlayType("audio/x-caf;").replace(/^no$/, ""),
            m4a: !!(KO.canPlayType("audio/x-m4a;") || KO.canPlayType("audio/m4a;") || KO.canPlayType("audio/aac;")).replace(/^no$/, ""),
            m4b: !!(KO.canPlayType("audio/x-m4b;") || KO.canPlayType("audio/m4b;") || KO.canPlayType("audio/aac;")).replace(/^no$/, ""),
            mp4: !!(KO.canPlayType("audio/x-mp4;") || KO.canPlayType("audio/mp4;") || KO.canPlayType("audio/aac;")).replace(/^no$/, ""),
            weba: !(hO || !KO.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/, "")),
            webm: !(hO || !KO.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/, "")),
            dolby: !!KO.canPlayType('audio/mp4; codecs="ec-3"').replace(/^no$/, ""),
            flac: !!(KO.canPlayType("audio/x-flac;") || KO.canPlayType("audio/flac;")).replace(/^no$/, "")
          }, OO
        },
        _unlockAudio: function() {
          var OO = this || eO;
          if (!OO._audioUnlocked && OO.ctx) {
            OO._audioUnlocked = !1, OO.autoUnlock = !1, OO._mobileUnloaded || 44100 === OO.ctx.sampleRate || (OO._mobileUnloaded = !0, OO.unload()), OO._scratchBuffer = OO.ctx.createBuffer(1, 1, 22050);
            var KO = function(pO) {
              for (; OO._html5AudioPool.length < OO.html5PoolSize;) try {
                var XO = new Audio;
                XO._unlocked = !0, OO._releaseHtml5Audio(XO)
              } catch (pO) {
                OO.noAudio = !0;
                break
              }
              for (var bK = 0; bK < OO._howls.length; bK++)
                if (!OO._howls[bK]._webAudio)
                  for (var eO = OO._howls[bK]._getSoundIds(), lO = 0; lO < eO.length; lO++) {
                    var vK = OO._howls[bK]._soundById(eO[lO]);
                    vK && vK._node && !vK._node._unlocked && (vK._node._unlocked = !0, vK._node.load())
                  }
              OO._autoResume();
              var CO = OO.ctx.createBufferSource();
              CO.buffer = OO._scratchBuffer, CO.connect(OO.ctx.destination), "undefined" === typeof CO.start ? CO.noteOn(0) : CO.start(0), "function" === typeof OO.ctx.resume && OO.ctx.resume(), CO.onended = function() {
                CO.disconnect(0), OO._audioUnlocked = !0, document.removeEventListener("touchstart", KO, !0), document.removeEventListener("touchend", KO, !0), document.removeEventListener("click", KO, !0), document.removeEventListener("keydown", KO, !0);
                for (var pO = 0; pO < OO._howls.length; pO++) OO._howls[pO]._emit("unlock")
              }
            };
            return document.addEventListener("touchstart", KO, !0), document.addEventListener("touchend", KO, !0), document.addEventListener("click", KO, !0), document.addEventListener("keydown", KO, !0), OO
          }
        },
        _obtainHtml5Audio: function() {
          var OO = this || eO;
          if (OO._html5AudioPool.length) return OO._html5AudioPool.pop();
          var KO = (new Audio).play();
          return KO && "undefined" !== typeof Promise && (KO instanceof Promise || "function" === typeof KO.then) && KO.catch((function() {
            console.warn("HTML5 Audio pool exhausted, returning potentially locked audio object.")
          })), new Audio
        },
        _releaseHtml5Audio: function(OO) {
          var KO = this || eO;
          return OO._unlocked && KO._html5AudioPool.push(OO), KO
        },
        _autoSuspend: function() {
          var OO = this;
          if (OO.autoSuspend && OO.ctx && "undefined" !== typeof OO.ctx.suspend && eO.usingWebAudio) {
            for (var KO = 0; KO < OO._howls.length; KO++)
              if (OO._howls[KO]._webAudio)
                for (var pO = 0; pO < OO._howls[KO]._sounds.length; pO++)
                  if (!OO._howls[KO]._sounds[pO].YL) return OO;
            return OO._suspendTimer && clearTimeout(OO._suspendTimer), OO._suspendTimer = setTimeout((function() {
              if (OO.autoSuspend) {
                OO._suspendTimer = null, OO.state = "suspending";
                var KO = function() {
                  OO.state = "suspended", OO._resumeAfterSuspend && (delete OO._resumeAfterSuspend, OO._autoResume())
                };
                OO.ctx.suspend().then(KO, KO)
              }
            }), 3e4), OO
          }
        },
        _autoResume: function() {
          var OO = this;
          if (OO.ctx && "undefined" !== typeof OO.ctx.resume && eO.usingWebAudio) return "running" === OO.state && "interrupted" !== OO.ctx.state && OO._suspendTimer ? (clearTimeout(OO._suspendTimer), OO._suspendTimer = null) : "suspended" === OO.state || "running" === OO.state && "interrupted" === OO.ctx.state ? (OO.ctx.resume().then((function() {
            OO.state = "running";
            for (var KO = 0; KO < OO._howls.length; KO++) OO._howls[KO]._emit("resume")
          })), OO._suspendTimer && (clearTimeout(OO._suspendTimer), OO._suspendTimer = null)) : "suspending" === OO.state && (OO._resumeAfterSuspend = !0), OO
        }
      };
      var eO = new bK,
        lO = function(OO) {
          OO.src && 0 !== OO.src.length ? this.init(OO) : console.error("An array of source files must be passed with any new Howl.")
        };
      lO.prototype = {
        init: function(OO) {
          var KO = this;
          return eO.ctx || oO(), KO._autoplay = OO.autoplay || !1, KO._format = "string" !== typeof OO.format ? OO.format : [OO.format], KO._html5 = OO.html5 || !1, KO._muted = OO.mute || !1, KO._loop = OO.loop || !1, KO._pool = OO.pool || 5, KO._preload = "boolean" !== typeof OO.preload && "metadata" !== OO.preload || OO.preload, KO._rate = OO.rate || 1, KO._sprite = OO.sprite || {}, KO._src = "string" !== typeof OO.src ? OO.src : [OO.src], KO._volume = void 0 !== OO.volume ? OO.volume : 1, KO._xhr = {
            method: OO.xhr && OO.xhr.method ? OO.xhr.method : "GET",
            headers: OO.xhr && OO.xhr.headers ? OO.xhr.headers : null,
            withCredentials: !(!OO.xhr || !OO.xhr.withCredentials) && OO.xhr.withCredentials
          }, KO._duration = 0, KO._state = "unloaded", KO._sounds = [], KO._endTimers = {}, KO._queue = [], KO._playLock = !1, KO._onend = OO.onend ? [{
            oX: OO.onend
          }] : [], KO._onfade = OO.onfade ? [{
            oX: OO.onfade
          }] : [], KO._onload = OO.onload ? [{
            oX: OO.onload
          }] : [], KO._onloaderror = OO.onloaderror ? [{
            oX: OO.onloaderror
          }] : [], KO._onplayerror = OO.onplayerror ? [{
            oX: OO.onplayerror
          }] : [], KO._onpause = OO.onpause ? [{
            oX: OO.onpause
          }] : [], KO._onplay = OO.onplay ? [{
            oX: OO.onplay
          }] : [], KO._onstop = OO.onstop ? [{
            oX: OO.onstop
          }] : [], KO._onmute = OO.onmute ? [{
            oX: OO.onmute
          }] : [], KO._onvolume = OO.onvolume ? [{
            oX: OO.onvolume
          }] : [], KO._onrate = OO.onrate ? [{
            oX: OO.onrate
          }] : [], KO._onseek = OO.onseek ? [{
            oX: OO.onseek
          }] : [], KO._onunlock = OO.onunlock ? [{
            oX: OO.onunlock
          }] : [], KO._onresume = [], KO._webAudio = eO.usingWebAudio && !KO._html5, "undefined" !== typeof eO.ctx && eO.ctx && eO.autoUnlock && eO._unlockAudio(), eO._howls.push(KO), KO._autoplay && KO._queue.push({
            event: "play",
            action: function() {
              KO.play()
            }
          }), KO._preload && "none" !== KO._preload && KO.load(), KO
        },
        load: function() {
          var OO = this,
            KO = null;
          if (eO.noAudio) OO._emit("loaderror", null, "No audio support.");
          else {
            "string" === typeof OO._src && (OO._src = [OO._src]);
            for (var pO = 0; pO < OO._src.length; pO++) {
              var XO, bK;
              if (OO._format && OO._format[pO]) XO = OO._format[pO];
              else {
                if ("string" !== typeof(bK = OO._src[pO])) {
                  OO._emit("loaderror", null, "Non-string found in selected audio sources - ignoring.");
                  continue
                }(XO = /^data:audio\/([^;,]+);/i.exec(bK)) || (XO = /\.([^.]+)$/.exec(bK.split("?", 1)[0])), XO && (XO = XO[1].toLowerCase())
              }
              if (XO || console.warn('No file extension was found. Consider using the "format" property or specify an extension.'), XO && eO.codecs(XO)) {
                KO = OO._src[pO];
                break
              }
            }
            if (KO) return OO._src = KO, OO._state = "loading", "https:" === window.location.protocol && "http:" === KO.slice(0, 5) && (OO._html5 = !0, OO._webAudio = !1), new vK(OO), OO._webAudio && hO(OO), OO;
            OO._emit("loaderror", null, "No codec support for selected audio sources.")
          }
        },
        play: function(OO, KO) {
          var pO = this,
            XO = null;
          if ("number" === typeof OO) XO = OO, OO = null;
          else {
            if ("string" === typeof OO && "loaded" === pO._state && !pO._sprite[OO]) return null;
            if ("undefined" === typeof OO && (OO = "__default", !pO._playLock)) {
              for (var bK = 0, lO = 0; lO < pO._sounds.length; lO++) pO._sounds[lO].YL && !pO._sounds[lO]._ended && (bK++, XO = pO._sounds[lO]._id);
              1 === bK ? OO = null : XO = null
            }
          }
          var vK = XO ? pO._soundById(XO) : pO._inactiveSound();
          if (!vK) return null;
          if (XO && !OO && (OO = vK._sprite || "__default"), "loaded" !== pO._state) {
            vK._sprite = OO, vK._ended = !1;
            var CO = vK._id;
            return pO._queue.push({
              event: "play",
              action: function() {
                pO.play(CO)
              }
            }), CO
          }
          if (XO && !vK.YL) return KO || pO._loadQueue("play"), vK._id;
          pO._webAudio && eO._autoResume();
          var hO = Math.max(0, vK._seek > 0 ? vK._seek : pO._sprite[OO][0] / 1e3),
            DO = Math.max(0, (pO._sprite[OO][0] + pO._sprite[OO][1]) / 1e3 - hO),
            MO = 1e3 * DO / Math.abs(vK._rate),
            aK = pO._sprite[OO][0] / 1e3,
            oO = (pO._sprite[OO][0] + pO._sprite[OO][1]) / 1e3;
          vK._sprite = OO, vK._ended = !1;
          var FO = function() {
            vK.YL = !1, vK._seek = hO, vK._start = aK, vK._stop = oO, vK._loop = !(!vK._loop && !pO._sprite[OO][2])
          };
          if (!(hO >= oO)) {
            var VO = vK._node;
            if (pO._webAudio) {
              var LO = function() {
                pO._playLock = !1, FO(), pO._refreshBuffer(vK);
                var OO = vK._muted || pO._muted ? 0 : vK._volume;
                VO.gain.setValueAtTime(OO, eO.ctx.currentTime), vK._playStart = eO.ctx.currentTime, "undefined" === typeof VO.bufferSource.start ? vK._loop ? VO.bufferSource.noteGrainOn(0, hO, 86400) : VO.bufferSource.noteGrainOn(0, hO, DO) : vK._loop ? VO.bufferSource.start(0, hO, 86400) : VO.bufferSource.start(0, hO, DO), MO !== 1 / 0 && (pO._endTimers[vK._id] = setTimeout(pO._ended.bind(pO, vK), MO)), KO || setTimeout((function() {
                  pO._emit("play", vK._id), pO._loadQueue()
                }), 0)
              };
              "running" === eO.state && "interrupted" !== eO.ctx.state ? LO() : (pO._playLock = !0, pO.once("resume", LO), pO._clearTimer(vK._id))
            } else {
              var QO = function() {
                VO.currentTime = hO, VO.muted = vK._muted || pO._muted || eO._muted || VO.muted, VO.volume = vK._volume * eO.volume(), VO.playbackRate = vK._rate;
                try {
                  var XO = VO.play();
                  if (XO && "undefined" !== typeof Promise && (XO instanceof Promise || "function" === typeof XO.then) ? (pO._playLock = !0, FO(), XO.then((function() {
                      pO._playLock = !1, VO._unlocked = !0, KO ? pO._loadQueue() : pO._emit("play", vK._id)
                    })).catch((function() {
                      pO._playLock = !1, pO._emit("playerror", vK._id, "Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction."), vK._ended = !0, vK.YL = !0
                    }))) : KO || (pO._playLock = !1, FO(), pO._emit("play", vK._id)), VO.playbackRate = vK._rate, VO.paused) return void pO._emit("playerror", vK._id, "Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.");
                  "__default" !== OO || vK._loop ? pO._endTimers[vK._id] = setTimeout(pO._ended.bind(pO, vK), MO) : (pO._endTimers[vK._id] = function() {
                    pO._ended(vK), VO.removeEventListener("ended", pO._endTimers[vK._id], !1)
                  }, VO.addEventListener("ended", pO._endTimers[vK._id], !1))
                } catch (bK) {
                  pO._emit("playerror", vK._id, bK)
                }
              };
              "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA" === VO.src && (VO.src = pO._src, VO.load());
              var zK = window && window.ejecta || !VO.readyState && eO._navigator.isCocoonJS;
              if (VO.readyState >= 3 || zK) QO();
              else {
                pO._playLock = !0, pO._state = "loading";
                var AO = function() {
                  pO._state = "loaded", QO(), VO.removeEventListener(eO._canPlayEvent, AO, !1)
                };
                VO.addEventListener(eO._canPlayEvent, AO, !1), pO._clearTimer(vK._id)
              }
            }
            return vK._id
          }
          pO._ended(vK)
        },
        pause: function(OO) {
          var KO = this;
          if ("loaded" !== KO._state || KO._playLock) return KO._queue.push({
            event: "pause",
            action: function() {
              KO.pause(OO)
            }
          }), KO;
          for (var pO = KO._getSoundIds(OO), XO = 0; XO < pO.length; XO++) {
            KO._clearTimer(pO[XO]);
            var bK = KO._soundById(pO[XO]);
            if (bK && !bK.YL && (bK._seek = KO.seek(pO[XO]), bK._rateSeek = 0, bK.YL = !0, KO._stopFade(pO[XO]), bK._node))
              if (KO._webAudio) {
                if (!bK._node.bufferSource) continue;
                "undefined" === typeof bK._node.bufferSource.stop ? bK._node.bufferSource.noteOff(0) : bK._node.bufferSource.stop(0), KO._cleanBuffer(bK._node)
              } else isNaN(bK._node.duration) && bK._node.duration !== 1 / 0 || bK._node.pause();
            arguments[1] || KO._emit("pause", bK ? bK._id : null)
          }
          return KO
        },
        stop: function(OO, KO) {
          var pO = this;
          if ("loaded" !== pO._state || pO._playLock) return pO._queue.push({
            event: "stop",
            action: function() {
              pO.stop(OO)
            }
          }), pO;
          for (var XO = pO._getSoundIds(OO), bK = 0; bK < XO.length; bK++) {
            pO._clearTimer(XO[bK]);
            var eO = pO._soundById(XO[bK]);
            eO && (eO._seek = eO._start || 0, eO._rateSeek = 0, eO.YL = !0, eO._ended = !0, pO._stopFade(XO[bK]), eO._node && (pO._webAudio ? eO._node.bufferSource && ("undefined" === typeof eO._node.bufferSource.stop ? eO._node.bufferSource.noteOff(0) : eO._node.bufferSource.stop(0), pO._cleanBuffer(eO._node)) : isNaN(eO._node.duration) && eO._node.duration !== 1 / 0 || (eO._node.currentTime = eO._start || 0, eO._node.pause(), eO._node.duration === 1 / 0 && pO._clearSound(eO._node))), KO || pO._emit("stop", eO._id))
          }
          return pO
        },
        mute: function(OO, KO) {
          var pO = this;
          if ("loaded" !== pO._state || pO._playLock) return pO._queue.push({
            event: "mute",
            action: function() {
              pO.mute(OO, KO)
            }
          }), pO;
          if ("undefined" === typeof KO) {
            if ("boolean" !== typeof OO) return pO._muted;
            pO._muted = OO
          }
          for (var XO = pO._getSoundIds(KO), bK = 0; bK < XO.length; bK++) {
            var lO = pO._soundById(XO[bK]);
            lO && (lO._muted = OO, lO._interval && pO._stopFade(lO._id), pO._webAudio && lO._node ? lO._node.gain.setValueAtTime(OO ? 0 : lO._volume, eO.ctx.currentTime) : lO._node && (lO._node.muted = !!eO._muted || OO), pO._emit("mute", lO._id))
          }
          return pO
        },
        volume: function() {
          var OO, KO, pO, XO = this,
            bK = arguments;
          if (0 === bK.length) return XO._volume;
          if (1 === bK.length || 2 === bK.length && "undefined" === typeof bK[1] ? XO._getSoundIds().indexOf(bK[0]) >= 0 ? KO = parseInt(bK[0], 10) : OO = parseFloat(bK[0]) : bK.length >= 2 && (OO = parseFloat(bK[0]), KO = parseInt(bK[1], 10)), !("undefined" !== typeof OO && OO >= 0 && OO <= 1)) return (pO = KO ? XO._soundById(KO) : XO._sounds[0]) ? pO._volume : 0;
          if ("loaded" !== XO._state || XO._playLock) return XO._queue.push({
            event: "volume",
            action: function() {
              XO.volume.apply(XO, bK)
            }
          }), XO;
          "undefined" === typeof KO && (XO._volume = OO), KO = XO._getSoundIds(KO);
          for (var lO = 0; lO < KO.length; lO++)(pO = XO._soundById(KO[lO])) && (pO._volume = OO, bK[2] || XO._stopFade(KO[lO]), XO._webAudio && pO._node && !pO._muted ? pO._node.gain.setValueAtTime(OO, eO.ctx.currentTime) : pO._node && !pO._muted && (pO._node.volume = OO * eO.volume()), XO._emit("volume", pO._id));
          return XO
        },
        fade: function(OO, KO, pO, XO) {
          var bK = this;
          if ("loaded" !== bK._state || bK._playLock) return bK._queue.push({
            event: "fade",
            action: function() {
              bK.fade(OO, KO, pO, XO)
            }
          }), bK;
          OO = Math.min(Math.max(0, parseFloat(OO)), 1), KO = Math.min(Math.max(0, parseFloat(KO)), 1), pO = parseFloat(pO), bK.volume(OO, XO);
          for (var lO = bK._getSoundIds(XO), vK = 0; vK < lO.length; vK++) {
            var CO = bK._soundById(lO[vK]);
            if (CO) {
              if (XO || bK._stopFade(lO[vK]), bK._webAudio && !CO._muted) {
                var hO = eO.ctx.currentTime,
                  DO = hO + pO / 1e3;
                CO._volume = OO, CO._node.gain.setValueAtTime(OO, hO), CO._node.gain.linearRampToValueAtTime(KO, DO)
              }
              bK._startFadeInterval(CO, OO, KO, pO, lO[vK], "undefined" === typeof XO)
            }
          }
          return bK
        },
        _startFadeInterval: function(OO, KO, pO, XO, bK, eO) {
          var lO = this,
            vK = KO,
            CO = pO - KO,
            hO = Math.abs(CO / .01),
            DO = Math.max(4, hO > 0 ? XO / hO : XO),
            MO = Date.now();
          OO._fadeTo = pO, OO._interval = setInterval((function() {
            var bK = (Date.now() - MO) / XO;
            MO = Date.now(), vK += CO * bK, vK = Math.round(100 * vK) / 100, vK = CO < 0 ? Math.max(pO, vK) : Math.min(pO, vK), lO._webAudio ? OO._volume = vK : lO.volume(vK, OO._id, !0), eO && (lO._volume = vK), (pO < KO && vK <= pO || pO > KO && vK >= pO) && (clearInterval(OO._interval), OO._interval = null, OO._fadeTo = null, lO.volume(pO, OO._id), lO._emit("fade", OO._id))
          }), DO)
        },
        _stopFade: function(OO) {
          var KO = this,
            pO = KO._soundById(OO);
          return pO && pO._interval && (KO._webAudio && pO._node.gain.cancelScheduledValues(eO.ctx.currentTime), clearInterval(pO._interval), pO._interval = null, KO.volume(pO._fadeTo, OO), pO._fadeTo = null, KO._emit("fade", OO)), KO
        },
        loop: function() {
          var OO, KO, pO, XO = this,
            bK = arguments;
          if (0 === bK.length) return XO._loop;
          if (1 === bK.length) {
            if ("boolean" !== typeof bK[0]) return !!(pO = XO._soundById(parseInt(bK[0], 10))) && pO._loop;
            OO = bK[0], XO._loop = OO
          } else 2 === bK.length && (OO = bK[0], KO = parseInt(bK[1], 10));
          for (var eO = XO._getSoundIds(KO), lO = 0; lO < eO.length; lO++)(pO = XO._soundById(eO[lO])) && (pO._loop = OO, XO._webAudio && pO._node && pO._node.bufferSource && (pO._node.bufferSource.loop = OO, OO && (pO._node.bufferSource.loopStart = pO._start || 0, pO._node.bufferSource.loopEnd = pO._stop, XO.playing(eO[lO]) && (XO.pause(eO[lO], !0), XO.play(eO[lO], !0)))));
          return XO
        },
        rate: function() {
          var OO, KO, pO, XO = this,
            bK = arguments;
          if (0 === bK.length) KO = XO._sounds[0]._id;
          else if (1 === bK.length) {
            XO._getSoundIds().indexOf(bK[0]) >= 0 ? KO = parseInt(bK[0], 10) : OO = parseFloat(bK[0])
          } else 2 === bK.length && (OO = parseFloat(bK[0]), KO = parseInt(bK[1], 10));
          if ("number" !== typeof OO) return (pO = XO._soundById(KO)) ? pO._rate : XO._rate;
          if ("loaded" !== XO._state || XO._playLock) return XO._queue.push({
            event: "rate",
            action: function() {
              XO.rate.apply(XO, bK)
            }
          }), XO;
          "undefined" === typeof KO && (XO._rate = OO), KO = XO._getSoundIds(KO);
          for (var lO = 0; lO < KO.length; lO++)
            if (pO = XO._soundById(KO[lO])) {
              XO.playing(KO[lO]) && (pO._rateSeek = XO.seek(KO[lO]), pO._playStart = XO._webAudio ? eO.ctx.currentTime : pO._playStart), pO._rate = OO, XO._webAudio && pO._node && pO._node.bufferSource ? pO._node.bufferSource.playbackRate.setValueAtTime(OO, eO.ctx.currentTime) : pO._node && (pO._node.playbackRate = OO);
              var vK = XO.seek(KO[lO]),
                CO = 1e3 * ((XO._sprite[pO._sprite][0] + XO._sprite[pO._sprite][1]) / 1e3 - vK) / Math.abs(pO._rate);
              !XO._endTimers[KO[lO]] && pO.YL || (XO._clearTimer(KO[lO]), XO._endTimers[KO[lO]] = setTimeout(XO._ended.bind(XO, pO), CO)), XO._emit("rate", pO._id)
            } return XO
        },
        seek: function() {
          var OO, KO, pO = this,
            XO = arguments;
          if (0 === XO.length) pO._sounds.length && (KO = pO._sounds[0]._id);
          else if (1 === XO.length) {
            pO._getSoundIds().indexOf(XO[0]) >= 0 ? KO = parseInt(XO[0], 10) : pO._sounds.length && (KO = pO._sounds[0]._id, OO = parseFloat(XO[0]))
          } else 2 === XO.length && (OO = parseFloat(XO[0]), KO = parseInt(XO[1], 10));
          if ("undefined" === typeof KO) return 0;
          if ("number" === typeof OO && ("loaded" !== pO._state || pO._playLock)) return pO._queue.push({
            event: "seek",
            action: function() {
              pO.seek.apply(pO, XO)
            }
          }), pO;
          var bK = pO._soundById(KO);
          if (bK) {
            if (!("number" === typeof OO && OO >= 0)) {
              if (pO._webAudio) {
                var lO = pO.playing(KO) ? eO.ctx.currentTime - bK._playStart : 0,
                  vK = bK._rateSeek ? bK._rateSeek - bK._seek : 0;
                return bK._seek + (vK + lO * Math.abs(bK._rate))
              }
              return bK._node.currentTime
            }
            var CO = pO.playing(KO);
            CO && pO.pause(KO, !0), bK._seek = OO, bK._ended = !1, pO._clearTimer(KO), pO._webAudio || !bK._node || isNaN(bK._node.duration) || (bK._node.currentTime = OO);
            var hO = function() {
              CO && pO.play(KO, !0), pO._emit("seek", KO)
            };
            if (CO && !pO._webAudio) {
              var DO = function() {
                pO._playLock ? setTimeout(DO, 0) : hO()
              };
              setTimeout(DO, 0)
            } else hO()
          }
          return pO
        },
        playing: function(OO) {
          var KO = this;
          if ("number" === typeof OO) {
            var pO = KO._soundById(OO);
            return !!pO && !pO.YL
          }
          for (var XO = 0; XO < KO._sounds.length; XO++)
            if (!KO._sounds[XO].YL) return !0;
          return !1
        },
        duration: function(OO) {
          var KO = this,
            pO = KO._duration,
            XO = KO._soundById(OO);
          return XO && (pO = KO._sprite[XO._sprite][1] / 1e3), pO
        },
        state: function() {
          return this._state
        },
        unload: function() {
          for (var OO = this, KO = OO._sounds, pO = 0; pO < KO.length; pO++) KO[pO].YL || OO.stop(KO[pO]._id), OO._webAudio || (OO._clearSound(KO[pO]._node), KO[pO]._node.removeEventListener("error", KO[pO]._errorFn, !1), KO[pO]._node.removeEventListener(eO._canPlayEvent, KO[pO]._loadFn, !1), KO[pO]._node.removeEventListener("ended", KO[pO]._endFn, !1), eO._releaseHtml5Audio(KO[pO]._node)), delete KO[pO]._node, OO._clearTimer(KO[pO]._id);
          var XO = eO._howls.indexOf(OO);
          XO >= 0 && eO._howls.splice(XO, 1);
          var bK = !0;
          for (pO = 0; pO < eO._howls.length; pO++)
            if (eO._howls[pO]._src === OO._src || OO._src.indexOf(eO._howls[pO]._src) >= 0) {
              bK = !1;
              break
            } return CO && bK && delete CO[OO._src], eO.noAudio = !1, OO._state = "unloaded", OO._sounds = [], OO = null, null
        },
        on: function(OO, KO, pO, XO) {
          var bK = this["_on" + OO];
          return "function" === typeof KO && bK.push(XO ? {
            id: pO,
            oX: KO,
            once: XO
          } : {
            id: pO,
            oX: KO
          }), this
        },
        off: function(OO, KO, pO) {
          var XO = this,
            bK = XO["_on" + OO],
            eO = 0;
          if ("number" === typeof KO && (pO = KO, KO = null), KO || pO)
            for (eO = 0; eO < bK.length; eO++) {
              var lO = pO === bK[eO].id;
              if (KO === bK[eO].oX && lO || !KO && lO) {
                bK.splice(eO, 1);
                break
              }
            } else if (OO) XO["_on" + OO] = [];
            else {
              var vK = Object.keys(XO);
              for (eO = 0; eO < vK.length; eO++) 0 === vK[eO].indexOf("_on") && Array.isArray(XO[vK[eO]]) && (XO[vK[eO]] = [])
            } return XO
        },
        once: function(OO, KO, pO) {
          return this.on(OO, KO, pO, 1), this
        },
        _emit: function(OO, KO, pO) {
          for (var XO = this, bK = XO["_on" + OO], eO = bK.length - 1; eO >= 0; eO--) bK[eO].id && bK[eO].id !== KO && "load" !== OO || (setTimeout(function(OO) {
            OO.call(this, KO, pO)
          }.bind(XO, bK[eO].oX), 0), bK[eO].once && XO.off(OO, bK[eO].oX, bK[eO].id));
          return XO._loadQueue(OO), XO
        },
        _loadQueue: function(OO) {
          var KO = this;
          if (KO._queue.length > 0) {
            var pO = KO._queue[0];
            pO.event === OO && (KO._queue.shift(), KO._loadQueue()), OO || pO.action()
          }
          return KO
        },
        _ended: function(OO) {
          var KO = this,
            pO = OO._sprite;
          if (!KO._webAudio && OO._node && !OO._node.paused && !OO._node.ended && OO._node.currentTime < OO._stop) return setTimeout(KO._ended.bind(KO, OO), 100), KO;
          var XO = !(!OO._loop && !KO._sprite[pO][2]);
          if (KO._emit("end", OO._id), !KO._webAudio && XO && KO.stop(OO._id, !0).play(OO._id), KO._webAudio && XO) {
            KO._emit("play", OO._id), OO._seek = OO._start || 0, OO._rateSeek = 0, OO._playStart = eO.ctx.currentTime;
            var bK = 1e3 * (OO._stop - OO._start) / Math.abs(OO._rate);
            KO._endTimers[OO._id] = setTimeout(KO._ended.bind(KO, OO), bK)
          }
          return KO._webAudio && !XO && (OO.YL = !0, OO._ended = !0, OO._seek = OO._start || 0, OO._rateSeek = 0, KO._clearTimer(OO._id), KO._cleanBuffer(OO._node), eO._autoSuspend()), KO._webAudio || XO || KO.stop(OO._id, !0), KO
        },
        _clearTimer: function(OO) {
          var KO = this;
          if (KO._endTimers[OO]) {
            if ("function" !== typeof KO._endTimers[OO]) clearTimeout(KO._endTimers[OO]);
            else {
              var pO = KO._soundById(OO);
              pO && pO._node && pO._node.removeEventListener("ended", KO._endTimers[OO], !1)
            }
            delete KO._endTimers[OO]
          }
          return KO
        },
        _soundById: function(OO) {
          for (var KO = this, pO = 0; pO < KO._sounds.length; pO++)
            if (OO === KO._sounds[pO]._id) return KO._sounds[pO];
          return null
        },
        _inactiveSound: function() {
          var OO = this;
          OO._drain();
          for (var KO = 0; KO < OO._sounds.length; KO++)
            if (OO._sounds[KO]._ended) return OO._sounds[KO].reset();
          return new vK(OO)
        },
        _drain: function() {
          var OO = this,
            KO = OO._pool,
            pO = 0,
            XO = 0;
          if (!(OO._sounds.length < KO)) {
            for (XO = 0; XO < OO._sounds.length; XO++) OO._sounds[XO]._ended && pO++;
            for (XO = OO._sounds.length - 1; XO >= 0; XO--) {
              if (pO <= KO) return;
              OO._sounds[XO]._ended && (OO._webAudio && OO._sounds[XO]._node && OO._sounds[XO]._node.disconnect(0), OO._sounds.splice(XO, 1), pO--)
            }
          }
        },
        _getSoundIds: function(OO) {
          if ("undefined" === typeof OO) {
            for (var KO = [], pO = 0; pO < this._sounds.length; pO++) KO.push(this._sounds[pO]._id);
            return KO
          }
          return [OO]
        },
        _refreshBuffer: function(OO) {
          return OO._node.bufferSource = eO.ctx.createBufferSource(), OO._node.bufferSource.buffer = CO[this._src], OO._panner ? OO._node.bufferSource.connect(OO._panner) : OO._node.bufferSource.connect(OO._node), OO._node.bufferSource.loop = OO._loop, OO._loop && (OO._node.bufferSource.loopStart = OO._start || 0, OO._node.bufferSource.loopEnd = OO._stop || 0), OO._node.bufferSource.playbackRate.setValueAtTime(OO._rate, eO.ctx.currentTime), this
        },
        _cleanBuffer: function(OO) {
          var KO = eO._navigator && eO._navigator.vendor.indexOf("Apple") >= 0;
          if (eO._scratchBuffer && OO.bufferSource && (OO.bufferSource.onended = null, OO.bufferSource.disconnect(0), KO)) try {
            OO.bufferSource.buffer = eO._scratchBuffer
          } catch (pO) {}
          return OO.bufferSource = null, this
        },
        _clearSound: function(OO) {
          /MSIE |Trident\//.test(eO._navigator && eO._navigator.userAgent) || (OO.src = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA")
        }
      };
      var vK = function(OO) {
        this._parent = OO, this.init()
      };
      vK.prototype = {
        init: function() {
          var OO = this,
            KO = OO._parent;
          return OO._muted = KO._muted, OO._loop = KO._loop, OO._volume = KO._volume, OO._rate = KO._rate, OO._seek = 0, OO.YL = !0, OO._ended = !0, OO._sprite = "__default", OO._id = ++eO._counter, KO._sounds.push(OO), OO.create(), OO
        },
        create: function() {
          var OO = this,
            KO = OO._parent,
            pO = eO._muted || OO._muted || OO._parent._muted ? 0 : OO._volume;
          return KO._webAudio ? (OO._node = "undefined" === typeof eO.ctx.createGain ? eO.ctx.createGainNode() : eO.ctx.createGain(), OO._node.gain.setValueAtTime(pO, eO.ctx.currentTime), OO._node.paused = !0, OO._node.connect(eO.masterGain)) : eO.noAudio || (OO._node = eO._obtainHtml5Audio(), OO._errorFn = OO._errorListener.bind(OO), OO._node.addEventListener("error", OO._errorFn, !1), OO._loadFn = OO._loadListener.bind(OO), OO._node.addEventListener(eO._canPlayEvent, OO._loadFn, !1), OO._endFn = OO._endListener.bind(OO), OO._node.addEventListener("ended", OO._endFn, !1), OO._node.src = KO._src, OO._node.preload = !0 === KO._preload ? "auto" : KO._preload, OO._node.volume = pO * eO.volume(), OO._node.load()), OO
        },
        reset: function() {
          var OO = this,
            KO = OO._parent;
          return OO._muted = KO._muted, OO._loop = KO._loop, OO._volume = KO._volume, OO._rate = KO._rate, OO._seek = 0, OO._rateSeek = 0, OO.YL = !0, OO._ended = !0, OO._sprite = "__default", OO._id = ++eO._counter, OO
        },
        _errorListener: function() {
          var OO = this;
          OO._parent._emit("loaderror", OO._id, OO._node.error ? OO._node.error.code : 0), OO._node.removeEventListener("error", OO._errorFn, !1)
        },
        _loadListener: function() {
          var OO = this,
            KO = OO._parent;
          KO._duration = Math.ceil(10 * OO._node.duration) / 10, 0 === Object.keys(KO._sprite).length && (KO._sprite = {
            __default: [0, 1e3 * KO._duration]
          }), "loaded" !== KO._state && (KO._state = "loaded", KO._emit("load"), KO._loadQueue()), OO._node.removeEventListener(eO._canPlayEvent, OO._loadFn, !1)
        },
        _endListener: function() {
          var OO = this,
            KO = OO._parent;
          KO._duration === 1 / 0 && (KO._duration = Math.ceil(10 * OO._node.duration) / 10, KO._sprite.__default[1] === 1 / 0 && (KO._sprite.__default[1] = 1e3 * KO._duration), KO._ended(OO)), OO._node.removeEventListener("ended", OO._endFn, !1)
        }
      };
      var CO = {},
        hO = function(OO) {
          var KO = OO._src;
          if (CO[KO]) return OO._duration = CO[KO].duration, void aK(OO);
          if (/^data:[^;]+;base64,/.test(KO)) {
            for (var pO = atob(KO.split(",")[1]), XO = new Uint8Array(pO.length), bK = 0; bK < pO.length; ++bK) XO[bK] = pO.charCodeAt(bK);
            MO(XO.buffer, OO)
          } else {
            var eO = new XMLHttpRequest;
            eO.open(OO._xhr.method, KO, !0), eO.withCredentials = OO._xhr.withCredentials, eO.responseType = "arraybuffer", OO._xhr.headers && Object.keys(OO._xhr.headers).forEach((function(KO) {
              eO.setRequestHeader(KO, OO._xhr.headers[KO])
            })), eO.onload = function() {
              var KO = (eO.status + "")[0];
              "0" === KO || "2" === KO || "3" === KO ? MO(eO.response, OO) : OO._emit("loaderror", null, "Failed loading audio file with status: " + eO.status + ".")
            }, eO.onerror = function() {
              OO._webAudio && (OO._html5 = !0, OO._webAudio = !1, OO._sounds = [], delete CO[KO], OO.load())
            }, DO(eO)
          }
        },
        DO = function(OO) {
          try {
            OO.send()
          } catch (KO) {
            OO.onerror()
          }
        },
        MO = function(OO, KO) {
          var pO = function() {
              KO._emit("loaderror", null, "Decoding audio data failed.")
            },
            XO = function(OO) {
              OO && KO._sounds.length > 0 ? (CO[KO._src] = OO, aK(KO, OO)) : pO()
            };
          "undefined" !== typeof Promise && 1 === eO.ctx.decodeAudioData.length ? eO.ctx.decodeAudioData(OO).then(XO).catch(pO) : eO.ctx.decodeAudioData(OO, XO, pO)
        },
        aK = function(OO, KO) {
          KO && !OO._duration && (OO._duration = KO.duration), 0 === Object.keys(OO._sprite).length && (OO._sprite = {
            __default: [0, 1e3 * OO._duration]
          }), "loaded" !== OO._state && (OO._state = "loaded", OO._emit("load"), OO._loadQueue())
        },
        oO = function() {
          if (eO.usingWebAudio) {
            try {
              "undefined" !== typeof AudioContext ? eO.ctx = new AudioContext : "undefined" !== typeof webkitAudioContext ? eO.ctx = new webkitAudioContext : eO.usingWebAudio = !1
            } catch (bK) {
              eO.usingWebAudio = !1
            }
            eO.ctx || (eO.usingWebAudio = !1);
            var OO = /iP(hone|od|ad)/.test(eO._navigator && eO._navigator.platform),
              KO = eO._navigator && eO._navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/),
              pO = KO ? parseInt(KO[1], 10) : null;
            if (OO && pO && pO < 9) {
              var XO = /safari/.test(eO._navigator && eO._navigator.userAgent.toLowerCase());
              eO._navigator && !XO && (eO.usingWebAudio = !1)
            }
            eO.usingWebAudio && (eO.masterGain = "undefined" === typeof eO.ctx.createGain ? eO.ctx.createGainNode() : eO.ctx.createGain(), eO.masterGain.gain.setValueAtTime(eO._muted ? 0 : eO._volume, eO.ctx.currentTime), eO.masterGain.connect(eO.ctx.destination)), eO._setup()
          }
        };
      void 0 === (XO = function() {
        return {
          Howler: eO,
          Howl: lO
        }
      }.apply(KO, [])) || (OO.exports = XO), KO.Howler = eO, KO.Howl = lO, "undefined" !== typeof pO.g ? (pO.g.HowlerGlobal = bK, pO.g.Howler = eO, pO.g.Howl = lO, pO.g.Sound = vK) : "undefined" !== typeof window && (window.HowlerGlobal = bK, window.Howler = eO, window.Howl = lO, window.Sound = vK)
    }(),
    function() {
      var OO;
      HowlerGlobal.prototype._pos = [0, 0, 0], HowlerGlobal.prototype._orientation = [0, 0, -1, 0, 1, 0], HowlerGlobal.prototype.stereo = function(OO) {
        var KO = this;
        if (!KO.ctx || !KO.ctx.listener) return KO;
        for (var pO = KO._howls.length - 1; pO >= 0; pO--) KO._howls[pO].stereo(OO);
        return KO
      }, HowlerGlobal.prototype.pos = function(OO, KO, pO) {
        var XO = this;
        return XO.ctx && XO.ctx.listener ? (KO = "number" !== typeof KO ? XO._pos[1] : KO, pO = "number" !== typeof pO ? XO._pos[2] : pO, "number" !== typeof OO ? XO._pos : (XO._pos = [OO, KO, pO], "undefined" !== typeof XO.ctx.listener.positionX ? (XO.ctx.listener.positionX.setTargetAtTime(XO._pos[0], Howler.ctx.currentTime, .1), XO.ctx.listener.positionY.setTargetAtTime(XO._pos[1], Howler.ctx.currentTime, .1), XO.ctx.listener.positionZ.setTargetAtTime(XO._pos[2], Howler.ctx.currentTime, .1)) : XO.ctx.listener.setPosition(XO._pos[0], XO._pos[1], XO._pos[2]), XO)) : XO
      }, HowlerGlobal.prototype.orientation = function(OO, KO, pO, XO, bK, eO) {
        var lO = this;
        if (!lO.ctx || !lO.ctx.listener) return lO;
        var vK = lO._orientation;
        return KO = "number" !== typeof KO ? vK[1] : KO, pO = "number" !== typeof pO ? vK[2] : pO, XO = "number" !== typeof XO ? vK[3] : XO, bK = "number" !== typeof bK ? vK[4] : bK, eO = "number" !== typeof eO ? vK[5] : eO, "number" !== typeof OO ? vK : (lO._orientation = [OO, KO, pO, XO, bK, eO], "undefined" !== typeof lO.ctx.listener.forwardX ? (lO.ctx.listener.forwardX.setTargetAtTime(OO, Howler.ctx.currentTime, .1), lO.ctx.listener.forwardY.setTargetAtTime(KO, Howler.ctx.currentTime, .1), lO.ctx.listener.forwardZ.setTargetAtTime(pO, Howler.ctx.currentTime, .1), lO.ctx.listener.upX.setTargetAtTime(XO, Howler.ctx.currentTime, .1), lO.ctx.listener.upY.setTargetAtTime(bK, Howler.ctx.currentTime, .1), lO.ctx.listener.upZ.setTargetAtTime(eO, Howler.ctx.currentTime, .1)) : lO.ctx.listener.setOrientation(OO, KO, pO, XO, bK, eO), lO)
      }, Howl.prototype.init = (OO = Howl.prototype.init, function(KO) {
        var pO = this;
        return pO._orientation = KO.orientation || [1, 0, 0], pO._stereo = KO.stereo || null, pO._pos = KO.pos || null, pO._pannerAttr = {
          coneInnerAngle: "undefined" !== typeof KO.coneInnerAngle ? KO.coneInnerAngle : 360,
          coneOuterAngle: "undefined" !== typeof KO.coneOuterAngle ? KO.coneOuterAngle : 360,
          coneOuterGain: "undefined" !== typeof KO.coneOuterGain ? KO.coneOuterGain : 0,
          distanceModel: "undefined" !== typeof KO.distanceModel ? KO.distanceModel : "inverse",
          maxDistance: "undefined" !== typeof KO.maxDistance ? KO.maxDistance : 1e4,
          panningModel: "undefined" !== typeof KO.panningModel ? KO.panningModel : "HRTF",
          refDistance: "undefined" !== typeof KO.refDistance ? KO.refDistance : 1,
          rolloffFactor: "undefined" !== typeof KO.rolloffFactor ? KO.rolloffFactor : 1
        }, pO._onstereo = KO.onstereo ? [{
          oX: KO.onstereo
        }] : [], pO._onpos = KO.onpos ? [{
          oX: KO.onpos
        }] : [], pO._onorientation = KO.onorientation ? [{
          oX: KO.onorientation
        }] : [], OO.call(this, KO)
      }), Howl.prototype.stereo = function(OO, pO) {
        var XO = this;
        if (!XO._webAudio) return XO;
        if ("loaded" !== XO._state) return XO._queue.push({
          event: "stereo",
          action: function() {
            XO.stereo(OO, pO)
          }
        }), XO;
        var bK = "undefined" === typeof Howler.ctx.createStereoPanner ? "spatial" : "stereo";
        if ("undefined" === typeof pO) {
          if ("number" !== typeof OO) return XO._stereo;
          XO._stereo = OO, XO._pos = [OO, 0, 0]
        }
        for (var eO = XO._getSoundIds(pO), lO = 0; lO < eO.length; lO++) {
          var vK = XO._soundById(eO[lO]);
          if (vK) {
            if ("number" !== typeof OO) return vK._stereo;
            vK._stereo = OO, vK._pos = [OO, 0, 0], vK._node && (vK._pannerAttr.panningModel = "equalpower", vK._panner && vK._panner.pan || KO(vK, bK), "spatial" === bK ? "undefined" !== typeof vK._panner.positionX ? (vK._panner.positionX.setValueAtTime(OO, Howler.ctx.currentTime), vK._panner.positionY.setValueAtTime(0, Howler.ctx.currentTime), vK._panner.positionZ.setValueAtTime(0, Howler.ctx.currentTime)) : vK._panner.setPosition(OO, 0, 0) : vK._panner.pan.setValueAtTime(OO, Howler.ctx.currentTime)), XO._emit("stereo", vK._id)
          }
        }
        return XO
      }, Howl.prototype.pos = function(OO, pO, XO, bK) {
        var eO = this;
        if (!eO._webAudio) return eO;
        if ("loaded" !== eO._state) return eO._queue.push({
          event: "pos",
          action: function() {
            eO.pos(OO, pO, XO, bK)
          }
        }), eO;
        if (pO = "number" !== typeof pO ? 0 : pO, XO = "number" !== typeof XO ? -.5 : XO, "undefined" === typeof bK) {
          if ("number" !== typeof OO) return eO._pos;
          eO._pos = [OO, pO, XO]
        }
        for (var lO = eO._getSoundIds(bK), vK = 0; vK < lO.length; vK++) {
          var CO = eO._soundById(lO[vK]);
          if (CO) {
            if ("number" !== typeof OO) return CO._pos;
            CO._pos = [OO, pO, XO], CO._node && (CO._panner && !CO._panner.pan || KO(CO, "spatial"), "undefined" !== typeof CO._panner.positionX ? (CO._panner.positionX.setValueAtTime(OO, Howler.ctx.currentTime), CO._panner.positionY.setValueAtTime(pO, Howler.ctx.currentTime), CO._panner.positionZ.setValueAtTime(XO, Howler.ctx.currentTime)) : CO._panner.setPosition(OO, pO, XO)), eO._emit("pos", CO._id)
          }
        }
        return eO
      }, Howl.prototype.orientation = function(OO, pO, XO, bK) {
        var eO = this;
        if (!eO._webAudio) return eO;
        if ("loaded" !== eO._state) return eO._queue.push({
          event: "orientation",
          action: function() {
            eO.orientation(OO, pO, XO, bK)
          }
        }), eO;
        if (pO = "number" !== typeof pO ? eO._orientation[1] : pO, XO = "number" !== typeof XO ? eO._orientation[2] : XO, "undefined" === typeof bK) {
          if ("number" !== typeof OO) return eO._orientation;
          eO._orientation = [OO, pO, XO]
        }
        for (var lO = eO._getSoundIds(bK), vK = 0; vK < lO.length; vK++) {
          var CO = eO._soundById(lO[vK]);
          if (CO) {
            if ("number" !== typeof OO) return CO._orientation;
            CO._orientation = [OO, pO, XO], CO._node && (CO._panner || (CO._pos || (CO._pos = eO._pos || [0, 0, -.5]), KO(CO, "spatial")), "undefined" !== typeof CO._panner.orientationX ? (CO._panner.orientationX.setValueAtTime(OO, Howler.ctx.currentTime), CO._panner.orientationY.setValueAtTime(pO, Howler.ctx.currentTime), CO._panner.orientationZ.setValueAtTime(XO, Howler.ctx.currentTime)) : CO._panner.setOrientation(OO, pO, XO)), eO._emit("orientation", CO._id)
          }
        }
        return eO
      }, Howl.prototype.pannerAttr = function() {
        var OO, pO, XO, bK = this,
          eO = arguments;
        if (!bK._webAudio) return bK;
        if (0 === eO.length) return bK._pannerAttr;
        if (1 === eO.length) {
          if ("object" !== typeof eO[0]) return (XO = bK._soundById(parseInt(eO[0], 10))) ? XO._pannerAttr : bK._pannerAttr;
          OO = eO[0], "undefined" === typeof pO && (OO.pannerAttr || (OO.pannerAttr = {
            coneInnerAngle: OO.coneInnerAngle,
            coneOuterAngle: OO.coneOuterAngle,
            coneOuterGain: OO.coneOuterGain,
            distanceModel: OO.distanceModel,
            maxDistance: OO.maxDistance,
            refDistance: OO.refDistance,
            rolloffFactor: OO.rolloffFactor,
            panningModel: OO.panningModel
          }), bK._pannerAttr = {
            coneInnerAngle: "undefined" !== typeof OO.pannerAttr.coneInnerAngle ? OO.pannerAttr.coneInnerAngle : bK._coneInnerAngle,
            coneOuterAngle: "undefined" !== typeof OO.pannerAttr.coneOuterAngle ? OO.pannerAttr.coneOuterAngle : bK._coneOuterAngle,
            coneOuterGain: "undefined" !== typeof OO.pannerAttr.coneOuterGain ? OO.pannerAttr.coneOuterGain : bK._coneOuterGain,
            distanceModel: "undefined" !== typeof OO.pannerAttr.distanceModel ? OO.pannerAttr.distanceModel : bK._distanceModel,
            maxDistance: "undefined" !== typeof OO.pannerAttr.maxDistance ? OO.pannerAttr.maxDistance : bK._maxDistance,
            refDistance: "undefined" !== typeof OO.pannerAttr.refDistance ? OO.pannerAttr.refDistance : bK._refDistance,
            rolloffFactor: "undefined" !== typeof OO.pannerAttr.rolloffFactor ? OO.pannerAttr.rolloffFactor : bK._rolloffFactor,
            panningModel: "undefined" !== typeof OO.pannerAttr.panningModel ? OO.pannerAttr.panningModel : bK._panningModel
          })
        } else 2 === eO.length && (OO = eO[0], pO = parseInt(eO[1], 10));
        for (var lO = bK._getSoundIds(pO), vK = 0; vK < lO.length; vK++)
          if (XO = bK._soundById(lO[vK])) {
            var CO = XO._pannerAttr;
            CO = {
              coneInnerAngle: "undefined" !== typeof OO.coneInnerAngle ? OO.coneInnerAngle : CO.coneInnerAngle,
              coneOuterAngle: "undefined" !== typeof OO.coneOuterAngle ? OO.coneOuterAngle : CO.coneOuterAngle,
              coneOuterGain: "undefined" !== typeof OO.coneOuterGain ? OO.coneOuterGain : CO.coneOuterGain,
              distanceModel: "undefined" !== typeof OO.distanceModel ? OO.distanceModel : CO.distanceModel,
              maxDistance: "undefined" !== typeof OO.maxDistance ? OO.maxDistance : CO.maxDistance,
              refDistance: "undefined" !== typeof OO.refDistance ? OO.refDistance : CO.refDistance,
              rolloffFactor: "undefined" !== typeof OO.rolloffFactor ? OO.rolloffFactor : CO.rolloffFactor,
              panningModel: "undefined" !== typeof OO.panningModel ? OO.panningModel : CO.panningModel
            };
            var hO = XO._panner;
            hO ? (hO.coneInnerAngle = CO.coneInnerAngle, hO.coneOuterAngle = CO.coneOuterAngle, hO.coneOuterGain = CO.coneOuterGain, hO.distanceModel = CO.distanceModel, hO.maxDistance = CO.maxDistance, hO.refDistance = CO.refDistance, hO.rolloffFactor = CO.rolloffFactor, hO.panningModel = CO.panningModel) : (XO._pos || (XO._pos = bK._pos || [0, 0, -.5]), KO(XO, "spatial"))
          } return bK
      }, Sound.prototype.init = function(OO) {
        return function() {
          var KO = this,
            pO = KO._parent;
          KO._orientation = pO._orientation, KO._stereo = pO._stereo, KO._pos = pO._pos, KO._pannerAttr = pO._pannerAttr, OO.call(this), KO._stereo ? pO.stereo(KO._stereo) : KO._pos && pO.pos(KO._pos[0], KO._pos[1], KO._pos[2], KO._id)
        }
      }(Sound.prototype.init), Sound.prototype.reset = function(OO) {
        return function() {
          var KO = this,
            pO = KO._parent;
          return KO._orientation = pO._orientation, KO._stereo = pO._stereo, KO._pos = pO._pos, KO._pannerAttr = pO._pannerAttr, KO._stereo ? pO.stereo(KO._stereo) : KO._pos ? pO.pos(KO._pos[0], KO._pos[1], KO._pos[2], KO._id) : KO._panner && (KO._panner.disconnect(0), KO._panner = void 0, pO._refreshBuffer(KO)), OO.call(this)
        }
      }(Sound.prototype.reset);
      var KO = function(OO, KO) {
        "spatial" === (KO = KO || "spatial") ? (OO._panner = Howler.ctx.createPanner(), OO._panner.coneInnerAngle = OO._pannerAttr.coneInnerAngle, OO._panner.coneOuterAngle = OO._pannerAttr.coneOuterAngle, OO._panner.coneOuterGain = OO._pannerAttr.coneOuterGain, OO._panner.distanceModel = OO._pannerAttr.distanceModel, OO._panner.maxDistance = OO._pannerAttr.maxDistance, OO._panner.refDistance = OO._pannerAttr.refDistance, OO._panner.rolloffFactor = OO._pannerAttr.rolloffFactor, OO._panner.panningModel = OO._pannerAttr.panningModel, "undefined" !== typeof OO._panner.positionX ? (OO._panner.positionX.setValueAtTime(OO._pos[0], Howler.ctx.currentTime), OO._panner.positionY.setValueAtTime(OO._pos[1], Howler.ctx.currentTime), OO._panner.positionZ.setValueAtTime(OO._pos[2], Howler.ctx.currentTime)) : OO._panner.setPosition(OO._pos[0], OO._pos[1], OO._pos[2]), "undefined" !== typeof OO._panner.orientationX ? (OO._panner.orientationX.setValueAtTime(OO._orientation[0], Howler.ctx.currentTime), OO._panner.orientationY.setValueAtTime(OO._orientation[1], Howler.ctx.currentTime), OO._panner.orientationZ.setValueAtTime(OO._orientation[2], Howler.ctx.currentTime)) : OO._panner.setOrientation(OO._orientation[0], OO._orientation[1], OO._orientation[2])) : (OO._panner = Howler.ctx.createStereoPanner(), OO._panner.pan.setValueAtTime(OO._stereo, Howler.ctx.currentTime)), OO._panner.connect(OO._node), OO.YL || OO._parent.pause(OO._id, !0).play(OO._id, !0)
      }
    }()
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);