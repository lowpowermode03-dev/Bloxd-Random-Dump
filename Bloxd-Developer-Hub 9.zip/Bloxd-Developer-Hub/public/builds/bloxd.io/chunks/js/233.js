export const id = 233;
export const ids = [233];
export const modules = {
  38216: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK,
      d: () => VO,
      f: () => hO,
      j: () => CO
    });
    var XO = pO(37987),
      bK = pO(37061),
      eO = pO(38136),
      lO = pO(38031);
    class vK {
      get FhO() {
        return this._isDisposed
      }
      constructor(OO, KO, pO) {
        let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
          eO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
          vK = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
          CO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
          hO = arguments.length > 7 ? arguments[7] : void 0,
          DO = arguments.length > 8 ? arguments[8] : void 0;
        this._isAlreadyOwned = !1, this._isDisposed = !1, (0, lO.d)(), OO && OO.JKO ? this._engine = OO.JKO().qb() : this._engine = OO, this._updatable = pO, this._instanced = vK, this._divisor = hO || 1, this._label = DO, KO instanceof XO.c ? (this._data = null, this._buffer = KO) : (this._data = KO, this._buffer = null), this.byteStride = CO ? bK : bK * Float32Array.BYTES_PER_ELEMENT, eO || this.create()
      }
      createVertexBuffer(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
          lO = arguments.length > 6 ? arguments[6] : void 0;
        const vK = eO ? KO : KO * Float32Array.BYTES_PER_ELEMENT,
          hO = XO ? eO ? XO : XO * Float32Array.BYTES_PER_ELEMENT : this.byteStride;
        return new CO(this._engine, this, OO, this._updatable, !0, hO, void 0 === bK ? this._instanced : bK, vK, pO, void 0, void 0, !0, this._divisor || lO)
      }
      isUpdatable() {
        return this._updatable
      }
      getData() {
        return this._data
      }
      getBuffer() {
        return this._buffer
      }
      getStrideSize() {
        return this.byteStride / Float32Array.BYTES_PER_ELEMENT
      }
      create() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        !OO && this._buffer || (OO = OO || this._data, OO && (this._buffer ? this._updatable && (this._engine.updateDynamicVertexBuffer(this._buffer, OO), this._data = OO) : this._updatable ? (this._buffer = this._engine.createDynamicVertexBuffer(OO, this._label), this._data = OO) : this._buffer = this._engine.createVertexBuffer(OO, void 0, this._label)))
      }
      _rebuild() {
        if (this._data) this._buffer = null, this.create(this._data);
        else {
          if (!this._buffer) return;
          if (this._buffer.YO > 0) return void(this._updatable ? this._buffer = this._engine.createDynamicVertexBuffer(this._buffer.YO, this._label) : this._buffer = this._engine.createVertexBuffer(this._buffer.YO, void 0, this._label));
          bK.b.Warn(`Missing data for buffer "${this._label}" ${this._buffer?"(uniqueId: "+this._buffer.uniqueId+")":""}. Buffer reconstruction failed.`), this._buffer = null
        }
      }
      update(OO) {
        this.create(OO)
      }
      updateDirectly(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        this._buffer && this._updatable && (this._engine.updateDynamicVertexBuffer(this._buffer, OO, XO ? KO : KO * Float32Array.BYTES_PER_ELEMENT, pO ? pO * this.byteStride : void 0), this._data = 0 === KO && void 0 === pO ? OO : null)
      }
      _increaseReferences() {
        this._buffer && (this._isAlreadyOwned ? this._buffer.references++ : this._isAlreadyOwned = !0)
      }
      dispose() {
        this._buffer && this._engine._releaseBuffer(this._buffer) && (this._isDisposed = !0, this._data = null, this._buffer = null)
      }
    }
    class CO {
      get FhO() {
        return this._isDisposed
      }
      get instanceDivisor() {
        return this._instanceDivisor
      }
      set instanceDivisor(OO) {
        const KO = 0 != OO;
        this._instanceDivisor = OO, KO !== this._instanced && (this._instanced = KO, this._computeHashCode())
      }
      get _maxVerticesCount() {
        const OO = this.getData();
        return OO ? Array.isArray(OO) ? OO.length / (this.byteStride / 4) - this.byteOffset / 4 : (OO.byteLength - this.byteOffset) / this.byteStride : 0
      }
      constructor(OO, KO, pO, XO, bK, lO, MO, aK, oO, FO) {
        let VO, LO = arguments.length > 10 && void 0 !== arguments[10] && arguments[10],
          QO = arguments.length > 11 && void 0 !== arguments[11] && arguments[11],
          zK = arguments.length > 12 && void 0 !== arguments[12] ? arguments[12] : 1,
          AO = arguments.length > 13 && void 0 !== arguments[13] && arguments[13];
        if (this._isDisposed = !1, this.engine = OO, "object" === typeof XO && null !== XO ? (VO = XO.updatable ?? !1, bK = XO.postponeInternalCreation, lO = XO.stride, MO = XO.instanced, aK = XO.offset, oO = XO.size, FO = XO.type, LO = XO.normalized ?? !1, QO = XO.useBytes ?? !1, zK = XO.divisor ?? 1, AO = XO.takeBufferOwnership ?? !1, this._label = XO.label) : VO = !!XO, KO instanceof vK ? (this._buffer = KO, this._ownsBuffer = AO) : (this._buffer = new vK(OO, KO, VO, lO, bK, MO, QO, zK, this._label), this._ownsBuffer = !0), this.uniqueId = CO._Counter++, this._kind = pO, void 0 === FO) {
          const OO = this.getData();
          this.type = OO ? DO(OO) : CO.FLOAT
        } else this.type = FO;
        const fO = (0, eO.r)(this.type);
        QO ? (this._size = oO || (lO ? lO / fO : hO(pO)), this.byteStride = lO || this._buffer.byteStride || this._size * fO, this.byteOffset = aK || 0) : (this._size = oO || lO || hO(pO), this.byteStride = lO ? lO * fO : this._buffer.byteStride || this._size * fO, this.byteOffset = (aK || 0) * fO), this.normalized = LO, this._instanced = void 0 !== MO && MO, this._instanceDivisor = MO ? zK : 0, this._alignBuffer(), this._computeHashCode()
      }
      static _GetTypeHashIndex(OO) {
        switch (OO) {
          case CO.BYTE:
            return 0;
          case CO.UNSIGNED_BYTE:
            return 1;
          case CO.SHORT:
            return 2;
          case CO.UNSIGNED_SHORT:
            return 3;
          case CO.INT:
            return 4;
          case CO.UNSIGNED_INT:
            return 5;
          case CO.FLOAT:
            return 6;
          case CO.HALF_FLOAT:
            return 7;
          default:
            throw new Error(`Invalid vertex buffer type '${OO}'`)
        }
      }
      _computeHashCode() {
        this.hashCode = (CO._GetTypeHashIndex(this.type) | 0) + ((this.normalized ? 1 : 0) << 3) + (this._size - 1 << 4) + ((this._instanced ? 1 : 0) << 6) + (this.byteStride << 12)
      }
      _rebuild() {
        this._buffer?._rebuild()
      }
      getKind() {
        return this._kind
      }
      isUpdatable() {
        return this._buffer.isUpdatable()
      }
      getData() {
        return this._buffer.getData()
      }
      getFloatData(OO, KO) {
        const pO = this.getData();
        return pO ? (0, eO.n)(pO, this._size, this.type, this.byteOffset, this.byteStride, this.normalized, OO, KO) : null
      }
      getBuffer() {
        return this._buffer.getBuffer()
      }
      getWrapperBuffer() {
        return this._buffer
      }
      getStrideSize() {
        return this.byteStride / (0, eO.r)(this.type)
      }
      XhO() {
        return this.byteOffset / (0, eO.r)(this.type)
      }
      getSize() {
        return arguments.length > 0 && void 0 !== arguments[0] && arguments[0] ? this._size * (0, eO.r)(this.type) : this._size
      }
      getIsInstanced() {
        return this._instanced
      }
      getInstanceDivisor() {
        return this._instanceDivisor
      }
      create(OO) {
        this._buffer.create(OO), this._alignBuffer()
      }
      update(OO) {
        this._buffer.update(OO), this._alignBuffer()
      }
      updateDirectly(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        this._buffer.updateDirectly(OO, KO, void 0, pO), this._alignBuffer()
      }
      dispose() {
        this._ownsBuffer && this._buffer.dispose(), this._isDisposed = !0
      }
      forEach(OO, KO) {
        (0, eO.h)(this._buffer.getData(), this.byteOffset, this.byteStride, this._size, this.type, OO, this.normalized, ((OO, pO) => {
          for (let XO = 0; XO < this._size; XO++) KO(OO[XO], pO + XO)
        }))
      }
      _alignBuffer() {}
    }

    function hO(OO) {
      switch (OO) {
        case CO.UVKind:
        case CO.UV2Kind:
        case CO.UV3Kind:
        case CO.UV4Kind:
        case CO.UV5Kind:
        case CO.UV6Kind:
          return 2;
        case CO.NormalKind:
        case CO.PositionKind:
          return 3;
        case CO.ColorKind:
        case CO.ColorInstanceKind:
        case CO.MatricesIndicesKind:
        case CO.MatricesIndicesExtraKind:
        case CO.MatricesWeightsKind:
        case CO.MatricesWeightsExtraKind:
        case CO.TangentKind:
          return 4;
        default:
          throw new Error("Invalid kind '" + OO + "'")
      }
    }

    function DO(OO) {
      return OO instanceof Int8Array ? CO.BYTE : OO instanceof Uint8Array ? CO.UNSIGNED_BYTE : OO instanceof Int16Array ? CO.SHORT : OO instanceof Uint16Array ? CO.UNSIGNED_SHORT : OO instanceof Int32Array ? CO.INT : OO instanceof Uint32Array ? CO.UNSIGNED_INT : CO.FLOAT
    }

    function MO(OO) {
      return (0, eO.r)(OO)
    }

    function aK(OO, KO, pO, XO, bK, lO, vK, CO) {
      (0, eO.h)(OO, KO, pO, XO, bK, lO, vK, ((OO, KO) => {
        for (let pO = 0; pO < XO; pO++) CO(OO[pO], KO + pO)
      }))
    }

    function oO(OO, KO, pO, XO, bK, lO, vK, CO) {
      return (0, eO.n)(OO, KO, pO, XO, bK, lO, vK, CO)
    }
    CO._Counter = 0, CO.BYTE = 5120, CO.UNSIGNED_BYTE = 5121, CO.SHORT = 5122, CO.UNSIGNED_SHORT = 5123, CO.INT = 5124, CO.UNSIGNED_INT = 5125, CO.FLOAT = 5126, CO.HALF_FLOAT = 5131, CO.PositionKind = "position", CO.NormalKind = "normal", CO.TangentKind = "tangent", CO.UVKind = "uv", CO.UV2Kind = "uv2", CO.UV3Kind = "uv3", CO.UV4Kind = "uv4", CO.UV5Kind = "uv5", CO.UV6Kind = "uv6", CO.ColorKind = "color", CO.ColorInstanceKind = "instanceColor", CO.MatricesIndicesKind = "matricesIndices", CO.MatricesWeightsKind = "matricesWeights", CO.MatricesIndicesExtraKind = "matricesIndicesExtra", CO.MatricesWeightsExtraKind = "matricesWeightsExtra";
    let FO = !1;

    function VO() {
      FO || (FO = !0, CO.DeduceStride = hO, CO.GetDataType = DO, CO.GetTypeByteLength = MO, CO.ForEach = aK, CO.GetFloatData = oO)
    }
  },
  37987: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO
    });
    class XO {
      get underlyingResource() {
        return null
      }
      constructor() {
        this.references = 0, this.YO = 0, this.is32Bits = !1, this.uniqueId = XO._Counter++
      }
    }
    XO._Counter = 0
  },
  38209: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO
    });
    var XO = pO(35632),
      bK = pO(38216);
    class eO {
      constructor() {
        this.hit = !1, this.distance = 0, this.pickedPoint = null, this.pickedMesh = null, this.bu = 0, this.bv = 0, this.faceId = -1, this.subMeshFaceId = -1, this.subMeshId = 0, this.pickedSprite = null, this.thinInstanceIndex = -1, this.ray = null, this.originMesh = null, this.aimTransform = null, this.gripTransform = null
      }
      getNormal() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (!this.pickedMesh || KO && !this.pickedMesh.isVerticesDataPresent(bK.j.NormalKind)) return null;
        let pO, eO = this.pickedMesh.rFO();
        0 === eO?.length && (eO = null);
        const lO = XO.j.WX[0],
          vK = XO.j.WX[1],
          CO = XO.j.WX[2];
        if (KO) {
          const OO = this.pickedMesh.getVerticesData(bK.j.NormalKind);
          let KO = eO ? XO.o.FromArrayToRef(OO, 3 * eO[3 * this.faceId], lO) : lO.rvO(OO[3 * this.faceId * 3], OO[3 * this.faceId * 3 + 1], OO[3 * this.faceId * 3 + 2]),
            hO = eO ? XO.o.FromArrayToRef(OO, 3 * eO[3 * this.faceId + 1], vK) : vK.rvO(OO[3 * (3 * this.faceId + 1)], OO[3 * (3 * this.faceId + 1) + 1], OO[3 * (3 * this.faceId + 1) + 2]),
            DO = eO ? XO.o.FromArrayToRef(OO, 3 * eO[3 * this.faceId + 2], CO) : CO.rvO(OO[3 * (3 * this.faceId + 2)], OO[3 * (3 * this.faceId + 2) + 1], OO[3 * (3 * this.faceId + 2) + 2]);
          KO = KO.scale(this.bu), hO = hO.scale(this.bv), DO = DO.scale(1 - this.bu - this.bv), pO = new XO.o(KO.x + hO.x + DO.x, KO.y + hO.y + DO.y, KO.z + hO.z + DO.z)
        } else {
          const OO = this.pickedMesh.getVerticesData(bK.j.PositionKind),
            KO = eO ? XO.o.FromArrayToRef(OO, 3 * eO[3 * this.faceId], lO) : lO.rvO(OO[3 * this.faceId * 3], OO[3 * this.faceId * 3 + 1], OO[3 * this.faceId * 3 + 2]),
            hO = eO ? XO.o.FromArrayToRef(OO, 3 * eO[3 * this.faceId + 1], vK) : vK.rvO(OO[3 * (3 * this.faceId + 1)], OO[3 * (3 * this.faceId + 1) + 1], OO[3 * (3 * this.faceId + 1) + 2]),
            DO = eO ? XO.o.FromArrayToRef(OO, 3 * eO[3 * this.faceId + 2], CO) : CO.rvO(OO[3 * (3 * this.faceId + 2)], OO[3 * (3 * this.faceId + 2) + 1], OO[3 * (3 * this.faceId + 2) + 2]),
            MO = KO.subtract(hO),
            aK = DO.subtract(hO);
          pO = XO.o.Cross(MO, aK)
        }
        const hO = (OO, KO) => {
          if (-1 !== this.thinInstanceIndex) {
            const pO = OO._thinInstanceDataStorage.matrixData,
              bK = this.thinInstanceIndex << 4;
            if (pO && pO.length > bK) {
              const OO = XO.j.Matrix[0];
              XO.c.FromArrayToRef(pO, bK, OO), XO.o.TransformNormalToRef(KO, OO, KO)
            }
          }
          let pO = OO.getWorldMatrix();
          OO.nonUniformScaling && (XO.j.Matrix[0].NhO(pO), pO = XO.j.Matrix[0], pO.setTranslationFromFloats(0, 0, 0), pO.invert(), pO.transposeToRef(XO.j.Matrix[1]), pO = XO.j.Matrix[1]), XO.o.TransformNormalToRef(KO, pO, KO)
        };
        if (OO && hO(this.pickedMesh, pO), this.ray) {
          const KO = XO.j.WX[0].NhO(pO);
          OO || hO(this.pickedMesh, KO), XO.o.Dot(KO, this.ray.direction) > 0 && pO.negateInPlace()
        }
        return pO.normalize(), pO
      }
      getTextureCoordinates() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : bK.j.UVKind;
        if (!this.pickedMesh || !this.pickedMesh.isVerticesDataPresent(OO)) return null;
        const KO = this.pickedMesh.rFO();
        if (!KO) return null;
        const pO = this.pickedMesh.getVerticesData(OO);
        if (!pO) return null;
        let eO = XO.m.FromArray(pO, 2 * KO[3 * this.faceId]),
          lO = XO.m.FromArray(pO, 2 * KO[3 * this.faceId + 1]),
          vK = XO.m.FromArray(pO, 2 * KO[3 * this.faceId + 2]);
        return eO = eO.scale(this.bu), lO = lO.scale(this.bv), vK = vK.scale(1 - this.bu - this.bv), new XO.m(eO.x + lO.x + vK.x, eO.y + lO.y + vK.y)
      }
    }
  },
  38031: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(37899);
    let bK = !1;

    function eO() {
      bK || (bK = !0, XO.ThinEngine.prototype.updateDynamicIndexBuffer = function(OO, KO) {
        let pO;
        this._currentBoundBuffer[this._gl.ELEMENT_ARRAY_BUFFER] = null, this.bindIndexBuffer(OO), pO = OO.is32Bits ? KO instanceof Uint32Array ? KO : new Uint32Array(KO) : KO instanceof Uint16Array ? KO : new Uint16Array(KO), this._gl.bufferData(this._gl.ELEMENT_ARRAY_BUFFER, pO, this._gl.DYNAMIC_DRAW), this._resetIndexBufferBinding()
      }, XO.ThinEngine.prototype.updateDynamicVertexBuffer = function(OO, KO, pO, XO) {
        this.bindArrayBuffer(OO), void 0 === pO && (pO = 0);
        const bK = KO.byteLength || KO.length;
        void 0 === XO || XO >= bK && 0 === pO ? KO instanceof Array ? this._gl.bufferSubData(this._gl.ARRAY_BUFFER, pO, new Float32Array(KO)) : this._gl.bufferSubData(this._gl.ARRAY_BUFFER, pO, KO) : KO instanceof Array ? this._gl.bufferSubData(this._gl.ARRAY_BUFFER, pO, new Float32Array(KO).subarray(0, XO / 4)) : (KO = ArrayBuffer.isView(KO) ? new Uint8Array(KO.buffer, KO.byteOffset, XO) : new Uint8Array(KO, 0, XO), this._gl.bufferSubData(this._gl.ARRAY_BUFFER, pO, KO)), this._resetVertexBufferBinding()
      })
    }
  },
  38001: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO
    });
    class XO {
      get underlyingResource() {
        return this._webGLTexture
      }
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
          KO = arguments.length > 1 ? arguments[1] : void 0;
        if (this._MSAARenderBuffers = null, this._context = KO, !OO && (OO = KO.createTexture(), !OO)) throw new Error("Unable to create webGL texture");
        this.set(OO)
      }
      setUsage() {}
      set(OO) {
        this._webGLTexture = OO
      }
      reset() {
        this._webGLTexture = null, this._MSAARenderBuffers = null
      }
      addMSAARenderBuffer(OO) {
        this._MSAARenderBuffers || (this._MSAARenderBuffers = []), this._MSAARenderBuffers.push(OO)
      }
      releaseMSAARenderBuffers() {
        if (this._MSAARenderBuffers) {
          for (const OO of this._MSAARenderBuffers) this._context.deleteRenderbuffer(OO);
          this._MSAARenderBuffers = null
        }
      }
      getMSAARenderBuffer() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return this._MSAARenderBuffers?.[OO] ?? null
      }
      release() {
        this.releaseMSAARenderBuffers(), this._webGLTexture && this._context.deleteTexture(this._webGLTexture), this.reset()
      }
    }
  },
  37962: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => zK
    });
    var XO = pO(35660),
      bK = pO(37902),
      eO = pO(35653),
      lO = pO(37061),
      vK = pO(35644),
      CO = pO(37966);
    class hO {
      constructor() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        this._isDepthTestDirty = !1, this._isDepthMaskDirty = !1, this._isDepthFuncDirty = !1, this._isCullFaceDirty = !1, this._isCullDirty = !1, this._isZOffsetDirty = !1, this._isFrontFaceDirty = !1, OO && this.reset()
      }
      get isDirty() {
        return this._isDepthFuncDirty || this._isDepthTestDirty || this._isDepthMaskDirty || this._isCullFaceDirty || this._isCullDirty || this._isZOffsetDirty || this._isFrontFaceDirty
      }
      get zOffset() {
        return this._zOffset
      }
      set zOffset(OO) {
        this._zOffset !== OO && (this._zOffset = OO, this._isZOffsetDirty = !0)
      }
      get zOffsetUnits() {
        return this._zOffsetUnits
      }
      set zOffsetUnits(OO) {
        this._zOffsetUnits !== OO && (this._zOffsetUnits = OO, this._isZOffsetDirty = !0)
      }
      get cullFace() {
        return this._cullFace
      }
      set cullFace(OO) {
        this._cullFace !== OO && (this._cullFace = OO, this._isCullFaceDirty = !0)
      }
      get cull() {
        return this._cull
      }
      set cull(OO) {
        this._cull !== OO && (this._cull = OO, this._isCullDirty = !0)
      }
      get depthFunc() {
        return this._depthFunc
      }
      set depthFunc(OO) {
        this._depthFunc !== OO && (this._depthFunc = OO, this._isDepthFuncDirty = !0)
      }
      get depthMask() {
        return this._depthMask
      }
      set depthMask(OO) {
        this._depthMask !== OO && (this._depthMask = OO, this._isDepthMaskDirty = !0)
      }
      get depthTest() {
        return this._depthTest
      }
      set depthTest(OO) {
        this._depthTest !== OO && (this._depthTest = OO, this._isDepthTestDirty = !0)
      }
      get frontFace() {
        return this._frontFace
      }
      set frontFace(OO) {
        this._frontFace !== OO && (this._frontFace = OO, this._isFrontFaceDirty = !0)
      }
      reset() {
        this._depthMask = !0, this._depthTest = !0, this._depthFunc = null, this._cullFace = null, this._cull = null, this._zOffset = 0, this._zOffsetUnits = 0, this._frontFace = null, this._isDepthTestDirty = !0, this._isDepthMaskDirty = !0, this._isDepthFuncDirty = !1, this._isCullFaceDirty = !1, this._isCullDirty = !1, this._isZOffsetDirty = !0, this._isFrontFaceDirty = !1
      }
      apply(OO) {
        this.isDirty && (this._isCullDirty && (this.cull ? OO.enable(OO.CULL_FACE) : OO.disable(OO.CULL_FACE), this._isCullDirty = !1), this._isCullFaceDirty && (OO.cullFace(this.cullFace), this._isCullFaceDirty = !1), this._isDepthMaskDirty && (OO.depthMask(this.depthMask), this._isDepthMaskDirty = !1), this._isDepthTestDirty && (this.depthTest ? OO.enable(OO.DEPTH_TEST) : OO.disable(OO.DEPTH_TEST), this._isDepthTestDirty = !1), this._isDepthFuncDirty && (OO.depthFunc(this.depthFunc), this._isDepthFuncDirty = !1), this._isZOffsetDirty && (this.zOffset || this.zOffsetUnits ? (OO.enable(OO.POLYGON_OFFSET_FILL), OO.polygonOffset(this.zOffset, this.zOffsetUnits)) : OO.disable(OO.POLYGON_OFFSET_FILL), this._isZOffsetDirty = !1), this._isFrontFaceDirty && (OO.frontFace(this.frontFace), this._isFrontFaceDirty = !1))
      }
    }
    class DO {
      get isDirty() {
        return this._isStencilTestDirty || this._isStencilMaskDirty || this._isStencilFuncDirty || this._isStencilOpDirty
      }
      get func() {
        return this._func
      }
      set func(OO) {
        this._func !== OO && (this._func = OO, this._isStencilFuncDirty = !0)
      }
      get backFunc() {
        return this._func
      }
      set backFunc(OO) {
        this._backFunc !== OO && (this._backFunc = OO, this._isStencilFuncDirty = !0)
      }
      get funcRef() {
        return this._funcRef
      }
      set funcRef(OO) {
        this._funcRef !== OO && (this._funcRef = OO, this._isStencilFuncDirty = !0)
      }
      get funcMask() {
        return this._funcMask
      }
      set funcMask(OO) {
        this._funcMask !== OO && (this._funcMask = OO, this._isStencilFuncDirty = !0)
      }
      get opStencilFail() {
        return this._opStencilFail
      }
      set opStencilFail(OO) {
        this._opStencilFail !== OO && (this._opStencilFail = OO, this._isStencilOpDirty = !0)
      }
      get opDepthFail() {
        return this._opDepthFail
      }
      set opDepthFail(OO) {
        this._opDepthFail !== OO && (this._opDepthFail = OO, this._isStencilOpDirty = !0)
      }
      get opStencilDepthPass() {
        return this._opStencilDepthPass
      }
      set opStencilDepthPass(OO) {
        this._opStencilDepthPass !== OO && (this._opStencilDepthPass = OO, this._isStencilOpDirty = !0)
      }
      get backOpStencilFail() {
        return this._backOpStencilFail
      }
      set backOpStencilFail(OO) {
        this._backOpStencilFail !== OO && (this._backOpStencilFail = OO, this._isStencilOpDirty = !0)
      }
      get backOpDepthFail() {
        return this._backOpDepthFail
      }
      set backOpDepthFail(OO) {
        this._backOpDepthFail !== OO && (this._backOpDepthFail = OO, this._isStencilOpDirty = !0)
      }
      get backOpStencilDepthPass() {
        return this._backOpStencilDepthPass
      }
      set backOpStencilDepthPass(OO) {
        this._backOpStencilDepthPass !== OO && (this._backOpStencilDepthPass = OO, this._isStencilOpDirty = !0)
      }
      get mask() {
        return this._mask
      }
      set mask(OO) {
        this._mask !== OO && (this._mask = OO, this._isStencilMaskDirty = !0)
      }
      get enabled() {
        return this._enabled
      }
      set enabled(OO) {
        this._enabled !== OO && (this._enabled = OO, this._isStencilTestDirty = !0)
      }
      constructor() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        this._isStencilTestDirty = !1, this._isStencilMaskDirty = !1, this._isStencilFuncDirty = !1, this._isStencilOpDirty = !1, this.useStencilGlobalOnly = !1, OO && this.reset()
      }
      reset() {
        this.stencilMaterial = void 0, this.stencilGlobal?.reset(), this._isStencilTestDirty = !0, this._isStencilMaskDirty = !0, this._isStencilFuncDirty = !0, this._isStencilOpDirty = !0
      }
      apply(OO) {
        if (!OO) return;
        const KO = !this.useStencilGlobalOnly && !!this.stencilMaterial?.enabled;
        this.enabled = KO ? this.stencilMaterial.enabled : this.stencilGlobal.enabled, this.func = KO ? this.stencilMaterial.func : this.stencilGlobal.func, this.backFunc = KO ? this.stencilMaterial.backFunc : this.stencilGlobal.backFunc, this.funcRef = KO ? this.stencilMaterial.funcRef : this.stencilGlobal.funcRef, this.funcMask = KO ? this.stencilMaterial.funcMask : this.stencilGlobal.funcMask, this.opStencilFail = KO ? this.stencilMaterial.opStencilFail : this.stencilGlobal.opStencilFail, this.opDepthFail = KO ? this.stencilMaterial.opDepthFail : this.stencilGlobal.opDepthFail, this.opStencilDepthPass = KO ? this.stencilMaterial.opStencilDepthPass : this.stencilGlobal.opStencilDepthPass, this.backOpStencilFail = KO ? this.stencilMaterial.backOpStencilFail : this.stencilGlobal.backOpStencilFail, this.backOpDepthFail = KO ? this.stencilMaterial.backOpDepthFail : this.stencilGlobal.backOpDepthFail, this.backOpStencilDepthPass = KO ? this.stencilMaterial.backOpStencilDepthPass : this.stencilGlobal.backOpStencilDepthPass, this.mask = KO ? this.stencilMaterial.mask : this.stencilGlobal.mask, this.isDirty && (this._isStencilTestDirty && (this.enabled ? OO.enable(OO.STENCIL_TEST) : OO.disable(OO.STENCIL_TEST), this._isStencilTestDirty = !1), this._isStencilMaskDirty && (OO.stencilMask(this.mask), this._isStencilMaskDirty = !1), this._isStencilFuncDirty && (OO.stencilFuncSeparate(OO.FRONT, this.func, this.funcRef, this.funcMask), OO.stencilFuncSeparate(OO.BACK, this.backFunc, this.funcRef, this.funcMask), this._isStencilFuncDirty = !1), this._isStencilOpDirty && (OO.stencilOpSeparate(OO.FRONT, this.opStencilFail, this.opDepthFail, this.opStencilDepthPass), OO.stencilOpSeparate(OO.BACK, this.backOpStencilFail, this.backOpDepthFail, this.backOpStencilDepthPass), this._isStencilOpDirty = !1))
      }
    }
    class MO {
      constructor() {
        this.reset()
      }
      reset() {
        this.enabled = !1, this.mask = 255, this.funcRef = 1, this.funcMask = 255, this.func = MO.ALWAYS, this.opStencilFail = MO.KEEP, this.opDepthFail = MO.KEEP, this.opStencilDepthPass = MO.REPLACE, this.backFunc = MO.ALWAYS, this.backOpStencilFail = MO.KEEP, this.backOpDepthFail = MO.KEEP, this.backOpStencilDepthPass = MO.REPLACE
      }
      get stencilFunc() {
        return this.func
      }
      set stencilFunc(OO) {
        this.func = OO
      }
      get stencilBackFunc() {
        return this.backFunc
      }
      set stencilBackFunc(OO) {
        this.backFunc = OO
      }
      get stencilFuncRef() {
        return this.funcRef
      }
      set stencilFuncRef(OO) {
        this.funcRef = OO
      }
      get stencilFuncMask() {
        return this.funcMask
      }
      set stencilFuncMask(OO) {
        this.funcMask = OO
      }
      get stencilOpStencilFail() {
        return this.opStencilFail
      }
      set stencilOpStencilFail(OO) {
        this.opStencilFail = OO
      }
      get stencilOpDepthFail() {
        return this.opDepthFail
      }
      set stencilOpDepthFail(OO) {
        this.opDepthFail = OO
      }
      get stencilOpStencilDepthPass() {
        return this.opStencilDepthPass
      }
      set stencilOpStencilDepthPass(OO) {
        this.opStencilDepthPass = OO
      }
      get stencilBackOpStencilFail() {
        return this.backOpStencilFail
      }
      set stencilBackOpStencilFail(OO) {
        this.backOpStencilFail = OO
      }
      get stencilBackOpDepthFail() {
        return this.backOpDepthFail
      }
      set stencilBackOpDepthFail(OO) {
        this.backOpDepthFail = OO
      }
      get stencilBackOpStencilDepthPass() {
        return this.backOpStencilDepthPass
      }
      set stencilBackOpStencilDepthPass(OO) {
        this.backOpStencilDepthPass = OO
      }
      get stencilMask() {
        return this.mask
      }
      set stencilMask(OO) {
        this.mask = OO
      }
      get stencilTest() {
        return this.enabled
      }
      set stencilTest(OO) {
        this.enabled = OO
      }
    }
    MO.ALWAYS = 519, MO.KEEP = 7680, MO.REPLACE = 7681;
    var aK = pO(37972),
      oO = pO(37938),
      FO = pO(37889),
      VO = pO(37918),
      LO = pO(37930);

    function QO(OO, KO) {
      if (KO) {
        const {
          requestAnimationFrame: pO
        } = KO;
        if ("function" === typeof pO) return pO(OO)
      }
      if ((0, VO.n)()) {
        const {
          requestAnimationFrame: pO
        } = KO || window;
        if ("function" === typeof pO) return pO(OO)
      } else if ("function" === typeof requestAnimationFrame) return requestAnimationFrame(OO);
      return setTimeout(OO, 16)
    }
    class zK {
      get frameId() {
        return this._frameId
      }
      get isWebGPU() {
        return this._isWebGPU
      }
      _getShaderProcessor(OO) {
        return this._shaderProcessor
      }
      _resetAlphaMode() {
        this._alphaMode.fill(-1), this._alphaEquation.fill(-1)
      }
      get shaderPlatformName() {
        return this._shaderPlatformName
      }
      _clearEmptyResources() {
        this._emptyTexture = null, this._emptyCubeTexture = null, this._emptyTexture3D = null, this._emptyTexture2DArray = null
      }
      get BhO() {
        return this._useReverseDepthBuffer
      }
      set BhO(OO) {
        OO !== this._useReverseDepthBuffer && (this._useReverseDepthBuffer = OO, this._depthCullingState.depthFunc = OO ? 518 : 515)
      }
      setColorWrite(OO) {
        OO !== this._colorWrite && (this._colorWriteChanged = !0, this._colorWrite = OO)
      }
      getColorWrite() {
        return this._colorWrite
      }
      get depthCullingState() {
        return this._depthCullingState
      }
      get alphaState() {
        return this._alphaState
      }
      get stencilState() {
        return this._stencilState
      }
      get stencilStateComposer() {
        return this._stencilStateComposer
      }
      _getGlobalDefines(OO) {
        if (OO) return this.isNDCHalfZRange ? OO.IS_NDC_HALF_ZRANGE = "" : delete OO.IS_NDC_HALF_ZRANGE, this.BhO ? OO.USE_REVERSE_DEPTHBUFFER = "" : delete OO.USE_REVERSE_DEPTHBUFFER, void(this.useExactSrgbConversions ? OO.USE_EXACT_SRGB_CONVERSIONS = "" : delete OO.USE_EXACT_SRGB_CONVERSIONS);
        {
          let OO = "";
          return this.isNDCHalfZRange && (OO += "#define IS_NDC_HALF_ZRANGE"), this.BhO && (OO && (OO += "\n"), OO += "#define USE_REVERSE_DEPTHBUFFER"), this.useExactSrgbConversions && (OO && (OO += "\n"), OO += "#define USE_EXACT_SRGB_CONVERSIONS"), OO
        }
      }
      _rebuildInternalTextures() {
        const OO = this._internalTexturesCache.slice();
        for (const KO of OO) KO._rebuild()
      }
      _rebuildRenderTargetWrappers() {
        const OO = this._renderTargetWrapperCache.slice();
        for (const KO of OO) KO.textures?.some((OO => 15 === OO.source)) || KO._rebuild()
      }
      _rebuildEffects() {
        for (const OO in this._compiledEffects) {
          const KO = this._compiledEffects[OO];
          KO._pipelineContext = null, KO._prepareEffect()
        }
        bK.e.ResetCache()
      }
      _rebuildGraphicsResources() {
        this.wipeCaches(!0), this._rebuildEffects(), this._rebuildComputeEffects?.(), this._rebuildBuffers(), this._rebuildInternalTextures(), this._rebuildTextures(), this._rebuildRenderTargetWrappers(), this.wipeCaches(!0)
      }
      _flagContextRestored() {
        lO.b.Warn(this.name + " context successfully restored."), this.onContextRestoredObservable.notifyObservers(this), this._contextWasLost = !1
      }
      _restoreEngineAfterContextLost(OO) {
        setTimeout((() => {
          this._clearEmptyResources();
          const KO = this._depthCullingState.depthTest,
            pO = this._depthCullingState.depthFunc,
            XO = this._depthCullingState.depthMask,
            bK = this._stencilState.stencilTest;
          OO(), this._rebuildGraphicsResources(), this._depthCullingState.depthTest = KO, this._depthCullingState.depthFunc = pO, this._depthCullingState.depthMask = XO, this._stencilState.stencilTest = bK, this._flagContextRestored()
        }), 0)
      }
      get FhO() {
        return this._isDisposed
      }
      get snapshotRendering() {
        return !1
      }
      set snapshotRendering(OO) {}
      get snapshotRenderingMode() {
        return 0
      }
      set snapshotRenderingMode(OO) {}
      getClassName() {
        return "AbstractEngine"
      }
      get emptyTexture() {
        return this._emptyTexture || (this._emptyTexture = this.createRawTexture(new Uint8Array(4), 1, 1, 5, !1, !1, 1)), this._emptyTexture
      }
      get emptyTexture3D() {
        return this._emptyTexture3D || (this._emptyTexture3D = this.createRawTexture3D(new Uint8Array(4), 1, 1, 1, 5, !1, !1, 1)), this._emptyTexture3D
      }
      get emptyTexture2DArray() {
        return this._emptyTexture2DArray || (this._emptyTexture2DArray = this.createRawTexture2DArray(new Uint8Array(4), 1, 1, 1, 5, !1, !1, 1)), this._emptyTexture2DArray
      }
      get emptyCubeTexture() {
        if (!this._emptyCubeTexture) {
          const OO = new Uint8Array(4),
            KO = [OO, OO, OO, OO, OO, OO];
          this._emptyCubeTexture = this.createRawCubeTexture(KO, 1, 5, 0, !1, !1, 1)
        }
        return this._emptyCubeTexture
      }
      set framebufferDimensionsObject(OO) {
        this._framebufferDimensionsObject = OO
      }
      get activeRenderLoops() {
        return this._activeRenderLoops
      }
      stopRenderLoop(OO) {
        if (!OO) return this._activeRenderLoops.length = 0, void this._cancelFrame();
        const KO = this._activeRenderLoops.indexOf(OO);
        KO >= 0 && (this._activeRenderLoops.splice(KO, 1), 0 == this._activeRenderLoops.length && this._cancelFrame())
      }
      _cancelFrame() {
        if (this.customAnimationFrameRequester) {
          if (0 !== this._frameHandler) {
            this._frameHandler = 0;
            const {
              cancelAnimationFrame: OO
            } = this.customAnimationFrameRequester;
            OO && OO(this.customAnimationFrameRequester.tb), delete this.customAnimationFrameRequester.tb
          }
        } else if (0 !== this._frameHandler) {
          const OO = this._frameHandler;
          if (this._frameHandler = 0, (0, VO.n)()) {
            const {
              cancelAnimationFrame: KO
            } = this.getHostWindow() || window;
            if ("function" === typeof KO) return KO(OO)
          } else if ("function" === typeof cancelAnimationFrame) return cancelAnimationFrame(OO);
          return clearTimeout(OO)
        }
      }
      uL() {
        this.onBeginFrameObservable.notifyObservers(this)
      }
      EL() {
        this._frameId++, this.onEndFrameObservable.notifyObservers(this)
      }
      get maxFPS() {
        return this._maxFPS
      }
      set maxFPS(OO) {
        this._maxFPS = OO, void 0 !== OO && (this._minFrameTime = OO <= 0 ? Number.MAX_VALUE : 1e3 / OO)
      }
      _isOverFrameTime(OO) {
        if (!OO || void 0 === this._maxFPS) return !1;
        const KO = OO - this._lastFrameTime;
        return this._lastFrameTime = OO, this._renderAccumulator += KO, this._renderAccumulator < this._minFrameTime || (this._renderAccumulator -= this._minFrameTime, this._renderAccumulator > this._minFrameTime && (this._renderAccumulator = this._minFrameTime), !1)
      }
      _processFrame(OO) {
        if (this._frameHandler = 0, !this._contextWasLost && !this._isOverFrameTime(OO)) {
          let OO = !0;
          (this.FhO || !this.renderEvenInBackground && this._windowIsBackground) && (OO = !1), OO && (this.uL(), this.skipFrameRender || this._renderViews() || this._renderFrame(), this.EL())
        }
      }
      _renderLoop(OO) {
        this._processFrame(OO), this._activeRenderLoops.length > 0 && 0 === this._frameHandler && this._queueNewFrameForRenderLoop()
      }
      _renderFrame() {
        for (let OO = 0; OO < this._activeRenderLoops.length; OO++) {
          (0, this._activeRenderLoops[OO])()
        }
      }
      _renderViews() {
        return !1
      }
      _queueNewFrame(OO, KO) {
        return QO(OO, KO)
      }
      _queueNewFrameForRenderLoop() {
        this.customAnimationFrameRequester ? (this.customAnimationFrameRequester.tb = this._queueNewFrame(this.customAnimationFrameRequester.renderFunction || this._boundRenderFunction, this.customAnimationFrameRequester), this._frameHandler = this.customAnimationFrameRequester.tb) : this._frameHandler = this._queueNewFrame(this._boundRenderFunction, this.getHostWindow())
      }
      runRenderLoop(OO) {
        -1 === this._activeRenderLoops.indexOf(OO) && (this._activeRenderLoops.push(OO), 1 === this._activeRenderLoops.length && 0 === this._frameHandler && this._queueNewFrameForRenderLoop())
      }
      getDepthBuffer() {
        return this._depthCullingState.depthTest
      }
      setDepthBuffer(OO) {
        this._depthCullingState.depthTest = OO
      }
      setZOffset(OO) {
        this._depthCullingState.zOffset = this.BhO ? -OO : OO
      }
      getZOffset() {
        const OO = this._depthCullingState.zOffset;
        return this.BhO ? -OO : OO
      }
      setZOffsetUnits(OO) {
        this._depthCullingState.zOffsetUnits = this.BhO ? -OO : OO
      }
      getZOffsetUnits() {
        const OO = this._depthCullingState.zOffsetUnits;
        return this.BhO ? -OO : OO
      }
      getHostWindow() {
        return (0, VO.n)() ? this._renderingCanvas && this._renderingCanvas.ownerDocument && this._renderingCanvas.ownerDocument.defaultView ? this._renderingCanvas.ownerDocument.defaultView : window : null
      }
      get compatibilityMode() {
        return this._compatibilityMode
      }
      set compatibilityMode(OO) {
        this._compatibilityMode = !0
      }
      _rebuildTextures() {
        for (const OO of this.scenes) OO._rebuildTextures();
        for (const OO of this._virtualScenes) OO._rebuildTextures()
      }
      _releaseRenderTargetWrapper(OO) {
        const KO = this._renderTargetWrapperCache.indexOf(OO); - 1 !== KO && this._renderTargetWrapperCache.splice(KO, 1)
      }
      get currentViewport() {
        return this._cachedViewport
      }
      setViewport(OO, KO, pO) {
        const XO = KO || this.getRenderWidth(),
          bK = pO || this.getRenderHeight(),
          eO = OO.x || 0,
          lO = OO.y || 0;
        this._cachedViewport = OO, this._viewport(eO * XO, lO * bK, XO * OO.width, bK * OO.height)
      }
      createCanvasImage() {
        return document.createElement("img")
      }
      createCanvasPath2D(OO) {
        return new Path2D(OO)
      }
      get description() {
        let OO = this.name + this.version;
        return this._caps.parallelShaderCompile && (OO += " - Parallel shader compilation"), OO
      }
      _createTextureBase(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 3,
          vK = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
          CO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null,
          hO = arguments.length > 7 ? arguments[7] : void 0,
          DO = arguments.length > 8 ? arguments[8] : void 0,
          MO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : null,
          aK = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : null,
          oO = arguments.length > 11 && void 0 !== arguments[11] ? arguments[11] : null,
          VO = arguments.length > 12 && void 0 !== arguments[12] ? arguments[12] : null,
          LO = arguments.length > 13 ? arguments[13] : void 0,
          QO = arguments.length > 14 ? arguments[14] : void 0,
          AO = arguments.length > 15 ? arguments[15] : void 0;
        const fO = "data:" === (OO = OO || "").substring(0, 5),
          dO = "blob:" === OO.substring(0, 5),
          TO = fO && -1 !== OO.indexOf(";base64,"),
          NO = aK || new FO.e(this, 1);
        NO !== aK && (NO.label = OO.substring(0, 60));
        const IO = OO;
        !this._transformTextureUrl || TO || aK || MO || (OO = this._transformTextureUrl(OO)), IO !== OO && (NO._originalUrl = IO);
        const yK = OO.lastIndexOf(".");
        let gK = VO || (yK > -1 ? OO.substring(yK).toLowerCase() : "");
        gK.indexOf("?") > -1 && (gK = gK.split("?")[0]);
        const uO = zK.GetCompatibleTextureLoader(gK, LO);
        XO && XO.addPendingData(NO), NO.url = OO, NO.generateMipMaps = !KO, NO.samplingMode = bK, NO.invertY = pO, NO._useSRGBBuffer = this._getUseSRGBBuffer(!!AO, KO), this._doNotHandleContextLost || (NO._buffer = MO);
        let EO = null;
        vK && !aK && (EO = NO.onLoadedObservable.add(vK)), aK || this._internalTexturesCache.push(NO);
        const jK = (pO, aK) => {
          XO && XO.removePendingData(NO), OO === IO ? (EO && NO.onLoadedObservable.remove(EO), eO.c.UseFallbackTexture && OO !== eO.c.FallbackTexture && this._createTextureBase(eO.c.FallbackTexture, KO, NO.invertY, XO, bK, null, CO, hO, DO, MO, NO), pO = (pO || "Unknown error") + (eO.c.UseFallbackTexture ? " - Fallback texture was used" : ""), NO.onErrorObservable.notifyObservers({
            message: pO,
            exception: aK
          }), CO && CO(pO, aK)) : (lO.b.Warn(`Failed to load ${OO}, falling back to ${IO}`), this._createTextureBase(IO, KO, NO.invertY, XO, bK, vK, CO, hO, DO, MO, NO, oO, VO, LO, QO, AO))
        };
        if (uO) {
          const KO = async OO => {
            (await uO).loadData(OO, NO, ((OO, KO, pO, eO, lO, vK) => {
              vK ? jK("TextureLoader failed to load data") : hO(NO, gK, XO, {
                width: OO,
                height: KO
              }, NO.invertY, !pO, eO, (() => (lO(), !1)), bK)
            }), QO)
          };
          if (MO) {
            const OO = async OO => {
              try {
                await KO(OO)
              } catch (pO) {
                jK("Failed to parse texture data", pO)
              }
            };
            MO instanceof ArrayBuffer ? OO(new Uint8Array(MO)) : ArrayBuffer.isView(MO) ? OO(MO) : CO && CO("Unable to load: only ArrayBuffer or ArrayBufferView is supported", null)
          } else this._loadFile(OO, (async OO => {
            try {
              await KO(new Uint8Array(OO))
            } catch (pO) {
              jK("Failed to parse texture data", pO)
            }
          }), void 0, XO ? XO.offlineProvider : void 0, !0, ((OO, KO) => {
            jK("Unable to load " + (OO && OO.responseURL, KO))
          }))
        } else {
          const pO = OO => {
            dO && !this._doNotHandleContextLost && (NO._buffer = OO), hO(NO, gK, XO, OO, NO.invertY, KO, !1, DO, bK)
          };
          !fO || TO ? MO && ("string" === typeof MO.decoding || MO.close) ? pO(MO) : zK._FileToolsLoadImage(OO || "", pO, jK, XO ? XO.offlineProvider : null, LO, NO.invertY && this._features.needsInvertingBitmap ? {
            imageOrientation: "flipY"
          } : void 0, this) : "string" === typeof MO || MO instanceof ArrayBuffer || ArrayBuffer.isView(MO) || MO instanceof Blob ? zK._FileToolsLoadImage(MO, pO, jK, XO ? XO.offlineProvider : null, LO, NO.invertY && this._features.needsInvertingBitmap ? {
            imageOrientation: "flipY"
          } : void 0, this) : MO && pO(MO)
        }
        return NO
      }
      _rebuildBuffers() {
        for (const OO of this._uniformBuffers) OO._rebuildAfterContextLost()
      }
      get _shouldUseHighPrecisionShader() {
        return !(!this._caps.highPrecisionShaderSupported || !this._highPrecisionShadersAllowed)
      }
      getHostDocument() {
        return this._renderingCanvas && this._renderingCanvas.ownerDocument ? this._renderingCanvas.ownerDocument : (0, VO.g)() ? document : null
      }
      getLoadedTexturesCache() {
        return this._internalTexturesCache
      }
      clearInternalTexturesCache() {
        this._internalTexturesCache.length = 0
      }
      getCaps() {
        return this._caps
      }
      resetTextureCache() {
        for (const OO in this._boundTexturesCache) Object.prototype.hasOwnProperty.call(this._boundTexturesCache, OO) && (this._boundTexturesCache[OO] = null);
        this._currentTextureChannel = -1
      }
      get name() {
        return this._name
      }
      set name(OO) {
        this._name = OO
      }
      static get NpmPackage() {
        return "babylonjs@9.28.0"
      }
      static get Version() {
        return "9.28.0"
      }
      getRenderingCanvas() {
        return this._renderingCanvas
      }
      getAudioContext() {
        return this._audioContext
      }
      getAudioDestination() {
        return this._audioDestination
      }
      setHardwareScalingLevel(OO) {
        this._hardwareScalingLevel = OO, this.resize()
      }
      getHardwareScalingLevel() {
        return this._hardwareScalingLevel
      }
      get doNotHandleContextLost() {
        return this._doNotHandleContextLost
      }
      set doNotHandleContextLost(OO) {
        this._doNotHandleContextLost = OO
      }
      get isStencilEnable() {
        return this._isStencilEnable
      }
      getCreationOptions() {
        return this._creationOptions
      }
      constructor(OO, KO, pO) {
        this._colorWrite = !0, this._colorWriteChanged = !0, this._depthCullingState = new hO, this._stencilStateComposer = new DO, this._stencilState = new MO, this._alphaState = new aK.c(!1), this._alphaMode = Array(8).fill(-1), this._alphaEquation = Array(8).fill(-1), this._activeRequests = [], this._badOS = !1, this._badDesktopOS = !1, this._compatibilityMode = !0, this._internalTexturesCache = new Array, this._currentRenderTarget = null, this._boundTexturesCache = {}, this._activeChannel = 0, this._currentTextureChannel = -1, this._viewportCached = {
          x: 0,
          y: 0,
          z: 0,
          w: 0
        }, this._isWebGPU = !1, this._enableGPUDebugMarkers = !1, this.onCanvasBlurObservable = new XO.e, this.onCanvasFocusObservable = new XO.e, this.onNewSceneAddedObservable = new XO.e, this.onResizeObservable = new XO.e, this.onCanvasPointerOutObservable = new XO.e, this.onEffectErrorObservable = new XO.e, this.disablePerformanceMonitorInBackground = !1, this.disableVertexArrayObjects = !1, this._frameId = 0, this.hostInformation = {
          isMobile: !1
        }, this.isFullscreen = !1, this.enableOfflineSupport = !1, this.disableManifestCheck = !1, this.disableContextMenu = !0, this.currentRenderPassId = 0, this.isPointerLock = !1, this.postProcesses = [], this.canvasTabIndex = 1, this._contextWasLost = !1, this._useReverseDepthBuffer = !1, this.isNDCHalfZRange = !1, this.hasOriginBottomLeft = !0, this._renderTargetWrapperCache = new Array, this._compiledEffects = {}, this._isDisposed = !1, this.scenes = [], this._virtualScenes = new Array, this.onBeforeTextureInitObservable = new XO.e, this.renderEvenInBackground = !0, this.preventCacheWipeBetweenFrames = !1, this._frameHandler = 0, this._activeRenderLoops = new Array, this.customAnimationFrameRequester = null, this._windowIsBackground = !1, this._boundRenderFunction = OO => this._renderLoop(OO), this._lastFrameTime = 0, this._renderAccumulator = 0, this.skipFrameRender = !1, this.onBeforeShaderCompilationObservable = new XO.e, this.onAfterShaderCompilationObservable = new XO.e, this.onBeginFrameObservable = new XO.e, this.onEndFrameObservable = new XO.e, this._transformTextureUrl = null, this._uniformBuffers = new Array, this._storageBuffers = new Array, this._highPrecisionShadersAllowed = !0, this.onContextLostObservable = new XO.e, this.onContextRestoredObservable = new XO.e, this._name = "", this.premultipliedAlpha = !0, this.adaptToDeviceRatio = !1, this._lastDevicePixelRatio = 1, this._doNotHandleContextLost = !1, this.cullBackFaces = null, this._renderPassNames = ["main"], this._onReleaseRenderPassObservable = null, this._fps = 60, this._deltaTime = 0, this._deterministicLockstep = !1, this._lockstepMaxSteps = 4, this._timeStep = 1 / 60, this.cpO = new XO.e, this.onReleaseEffectsObservable = new XO.e, eO.c.Instances.push(this), this.startTime = CO.d.Now, this._stencilStateComposer.stencilGlobal = this._stencilState, vK.b.SetMatrixPrecision(!!KO.useLargeWorldRendering || !!KO.useHighPrecisionMatrix), (0, VO.k)() && navigator.userAgent && (this._badOS = /iPad/i.test(navigator.userAgent) || /iPhone/i.test(navigator.userAgent), this._badDesktopOS = /^((?!chrome|android).)*safari/i.test(navigator.userAgent)), KO.antialias = OO ?? KO.antialias, KO.deterministicLockstep = KO.deterministicLockstep ?? !1, KO.lockstepMaxSteps = KO.lockstepMaxSteps ?? 4, KO.timeStep = KO.timeStep ?? 1 / 60, KO.stencil = KO.stencil ?? !0, this._audioContext = KO.audioEngineOptions?.audioContext ?? null, this._audioDestination = KO.audioEngineOptions?.audioDestination ?? null, this.premultipliedAlpha = KO.premultipliedAlpha ?? !0, this._doNotHandleContextLost = !!KO.doNotHandleContextLost, this._isStencilEnable = !!KO.stencil, this.useExactSrgbConversions = KO.useExactSrgbConversions ?? !1, this.canvasTabIndex = KO.canvasTabIndex ?? this.canvasTabIndex;
        const bK = (0, VO.n)() && window.devicePixelRatio || 1,
          lO = KO.limitDeviceRatio || bK;
        pO = pO || KO.adaptToDeviceRatio || !1, this.adaptToDeviceRatio = pO, this._hardwareScalingLevel = pO ? 1 / Math.min(lO, bK) : 1, this._lastDevicePixelRatio = bK, this._creationOptions = KO
      }
      resize() {
        let OO, KO, pO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        if (this.adaptToDeviceRatio) {
          const OO = (0, VO.n)() && window.devicePixelRatio || 1,
            KO = this._lastDevicePixelRatio / OO;
          this._lastDevicePixelRatio = OO, this._hardwareScalingLevel *= KO
        }
        if ((0, VO.n)() && (0, VO.g)())
          if (this._renderingCanvas) {
            const pO = this._renderingCanvas.getBoundingClientRect?.();
            OO = this._renderingCanvas.clientWidth || pO?.width || this._renderingCanvas.width * this._hardwareScalingLevel || 100, KO = this._renderingCanvas.clientHeight || pO?.height || this._renderingCanvas.height * this._hardwareScalingLevel || 100
          } else OO = window.innerWidth, KO = window.innerHeight;
        else OO = this._renderingCanvas ? this._renderingCanvas.width : 100, KO = this._renderingCanvas ? this._renderingCanvas.height : 100;
        this.setSize(OO / this._hardwareScalingLevel, KO / this._hardwareScalingLevel, pO)
      }
      setSize(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (!this._renderingCanvas) return !1;
        if (OO |= 0, KO |= 0, !pO && this._renderingCanvas.width === OO && this._renderingCanvas.height === KO) return !1;
        if (this._renderingCanvas.width = OO, this._renderingCanvas.height = KO, this.scenes) {
          for (let OO = 0; OO < this.scenes.length; OO++) {
            const KO = this.scenes[OO];
            for (let OO = 0; OO < KO.cameras.length; OO++) {
              KO.cameras[OO]._currentRenderId = 0
            }
          }
          this.onResizeObservable.hasObservers() && this.onResizeObservable.notifyObservers(this)
        }
        return !0
      }
      createRawTexture(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO) {
        throw (0, oO.j)("engine.rawTexture")
      }
      createRawCubeTexture(OO, KO, pO, XO, bK, eO, lO, vK) {
        throw (0, oO.j)("engine.rawTexture")
      }
      createRawTexture3D(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
        throw (0, oO.j)("engine.rawTexture")
      }
      createRawTexture2DArray(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO) {
        throw (0, oO.j)("engine.rawTexture")
      }
      _sharedInit(OO) {
        this._renderingCanvas = OO
      }
      _setupMobileChecks() {
        navigator && navigator.userAgent && (this._checkForMobile = () => {
          const OO = navigator.userAgent;
          this.hostInformation.isMobile = -1 !== OO.indexOf("Mobile") || -1 !== OO.indexOf("Mac") && (0, VO.g)() && "ontouchend" in document
        }, this._checkForMobile(), (0, VO.n)() && window.addEventListener("resize", this._checkForMobile))
      }
      createVideoElement(OO) {
        return document.createElement("video")
      }
      _reportDrawCall() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
        this._drawCalls?.addCount(OO, !1)
      }
      getFps() {
        return this._fps
      }
      getDeltaTime() {
        return this._deltaTime
      }
      isDeterministicLockStep() {
        return this._deterministicLockstep
      }
      getLockstepMaxSteps() {
        return this._lockstepMaxSteps
      }
      getTimeStep() {
        return 1e3 * this._timeStep
      }
      _createImageBitmapFromSource(OO, KO) {
        throw new Error("createImageBitmapFromSource is not implemented")
      }
      createImageBitmap(OO, KO) {
        return createImageBitmap(OO, KO)
      }
      resizeImageBitmap(OO, KO, pO) {
        throw new Error("resizeImageBitmap is not implemented")
      }
      getFontOffset(OO) {
        throw new Error("getFontOffset is not implemented")
      }
      static _CreateCanvas(OO, KO) {
        if ("undefined" === typeof document) return new OffscreenCanvas(OO, KO);
        const pO = document.createElement("canvas");
        return pO.width = OO, pO.height = KO, pO
      }
      createCanvas(OO, KO) {
        return zK._CreateCanvas(OO, KO)
      }
      static _FileToolsLoadImage(OO, KO, pO, XO, bK, eO, lO) {
        if (!LO.e.loadImage) throw (0, oO.j)("FileTools");
        return LO.e.loadImage(OO, KO, pO, XO, bK, eO, lO)
      }
      _loadFile(OO, KO, pO, XO, bK, eO) {
        const lO = (0, LO.l)(OO, KO, pO, XO, bK, eO);
        return this._activeRequests.push(lO), lO.onCompleteObservable.add((() => {
          const OO = this._activeRequests.indexOf(lO); - 1 !== OO && this._activeRequests.splice(OO, 1)
        })), lO
      }
      static _FileToolsLoadFile(OO, KO, pO, XO, bK, eO) {
        if (LO.e.loadFile) return LO.e.loadFile(OO, KO, pO, XO, bK, eO);
        throw (0, oO.j)("FileTools")
      }
      dispose() {
        for (this.releaseEffects(), this._isDisposed = !0, this.stopRenderLoop(), this._emptyTexture && (this._releaseTexture(this._emptyTexture), this._emptyTexture = null), this._emptyCubeTexture && (this._releaseTexture(this._emptyCubeTexture), this._emptyCubeTexture = null), this._renderingCanvas = null, this.onBeforeTextureInitObservable && this.onBeforeTextureInitObservable.clear(); this.postProcesses.length;) this.postProcesses[0].dispose();
        for (; this.scenes.length;) this.scenes[0].dispose();
        for (; this._virtualScenes.length;) this._virtualScenes[0].dispose();
        this.releaseComputeEffects?.(), bK.e.ResetCache();
        for (const KO of this._activeRequests) KO.abort();
        this._boundRenderFunction = null, this.cpO.notifyObservers(this), this.cpO.clear(), this.onResizeObservable.clear(), this.onCanvasBlurObservable.clear(), this.onCanvasFocusObservable.clear(), this.onCanvasPointerOutObservable.clear(), this.onNewSceneAddedObservable.clear(), this.onEffectErrorObservable.clear(), (0, VO.n)() && window.removeEventListener("resize", this._checkForMobile);
        const OO = eO.c.Instances.indexOf(this);
        OO >= 0 && eO.c.Instances.splice(OO, 1), eO.c.Instances.length || (eO.c.OnEnginesDisposedObservable.notifyObservers(this), eO.c.OnEnginesDisposedObservable.clear()), this.onBeginFrameObservable.clear(), this.onEndFrameObservable.clear(), this._onReleaseRenderPassObservable?.clear(), this._onReleaseRenderPassObservable = null
      }
      static DefaultLoadingScreenFactory(OO) {
        throw (0, oO.j)("LoadingScreen")
      }
      static MarkAllMaterialsAsDirty(OO, KO) {
        for (let pO = 0; pO < eO.c.Instances.length; pO++) {
          const XO = eO.c.Instances[pO];
          for (let pO = 0; pO < XO.scenes.length; pO++) XO.scenes[pO].markAllMaterialsAsDirty(OO, KO)
        }
      }
      static GetCompatibleTextureLoader(OO, KO) {
        return null
      }
    }
    zK._RenderPassIdCounter = 0, zK._RescalePostProcessFactory = null, zK.CollisionsEpsilon = .001, zK.QueueNewFrame = QO
  },
  37907: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      static GetShadersRepository() {
        return 0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0) ? XO.ShadersRepository : XO.ShadersRepositoryWGSL
      }
      static GetShadersStore() {
        return 0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0) ? XO.ShadersStore : XO.ShadersStoreWGSL
      }
      static GetIncludesShadersStore() {
        return 0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0) ? XO.IncludesShadersStore : XO.IncludesShadersStoreWGSL
      }
    }
    XO.ShadersRepository = "src/Shaders/", XO.ShadersStore = {}, XO.IncludesShadersStore = {}, XO.ShadersRepositoryWGSL = "src/ShadersWGSL/", XO.ShadersStoreWGSL = {}, XO.IncludesShadersStoreWGSL = {}
  },
  37921: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => aK,
      c: () => AO,
      g: () => FO,
      h: () => oO,
      l: () => VO,
      p: () => zK,
      q: () => MO,
      s: () => hO,
      v: () => DO,
      w: () => CO,
      A: () => vK
    });
    class XO {
      constructor() {
        this._valueCache = {}, this._matrixValueCache = {}, this.vertexCompilationError = null, this.fragmentCompilationError = null, this.programLinkError = null, this.programValidationError = null, this._isDisposed = !1
      }
      get isAsync() {
        return this.isParallelCompiled
      }
      get isReady() {
        return !!this.program && (!this.isParallelCompiled || this.engine._isRenderingStateCompiled(this))
      }
      _handlesSpectorRebuildCallback(OO) {
        OO && this.program && OO(this.program)
      }
      setEngine(OO) {
        this.engine = OO
      }
      _fillEffectInformation(OO, KO, pO, XO, bK, eO, lO, vK) {
        const CO = this.engine;
        if (CO.supportsUniformBuffers)
          for (const DO in KO) OO.bindUniformBlock(DO, KO[DO]);
        let hO;
        for (this.engine.getUniforms(this, pO).forEach(((OO, KO) => {
            XO[pO[KO]] = OO
          })), this._uniforms = XO, hO = 0; hO < bK.length; hO++) {
          null == OO.getUniform(bK[hO]) && (bK.splice(hO, 1), hO--)
        }
        bK.forEach(((OO, KO) => {
          eO[OO] = KO
        }));
        for (const DO of CO.getAttributes(this, lO)) vK.push(DO)
      }
      dispose() {
        this._uniforms = {}, this._isDisposed = !0
      }
      _cacheMatrix(OO, KO) {
        const pO = this._valueCache[OO],
          XO = KO.updateFlag;
        if (void 0 !== pO && pO === XO) return !1;
        const bK = KO.WhO();
        let eO = this._matrixValueCache[OO];
        if (void 0 !== pO && null !== pO && void 0 !== eO) {
          let KO = !0;
          for (let OO = 15; OO >= 0; OO--)
            if (eO[OO] !== bK[OO]) {
              KO = !1;
              break
            } if (KO) return this._valueCache[OO] = XO, !1
        }
        return void 0 === eO && (eO = this._matrixValueCache[OO] = new Float32Array(16)), eO.set(bK), this._valueCache[OO] = XO, !0
      }
      _cacheFloat2(OO, KO, pO) {
        let XO = this._valueCache[OO];
        if (!XO || 2 !== XO.length) return XO = [KO, pO], this._valueCache[OO] = XO, !0;
        let bK = !1;
        return XO[0] !== KO && (XO[0] = KO, bK = !0), XO[1] !== pO && (XO[1] = pO, bK = !0), bK
      }
      _cacheFloat3(OO, KO, pO, XO) {
        let bK = this._valueCache[OO];
        if (!bK || 3 !== bK.length) return bK = [KO, pO, XO], this._valueCache[OO] = bK, !0;
        let eO = !1;
        return bK[0] !== KO && (bK[0] = KO, eO = !0), bK[1] !== pO && (bK[1] = pO, eO = !0), bK[2] !== XO && (bK[2] = XO, eO = !0), eO
      }
      _cacheFloat4(OO, KO, pO, XO, bK) {
        let eO = this._valueCache[OO];
        if (!eO || 4 !== eO.length) return eO = [KO, pO, XO, bK], this._valueCache[OO] = eO, !0;
        let lO = !1;
        return eO[0] !== KO && (eO[0] = KO, lO = !0), eO[1] !== pO && (eO[1] = pO, lO = !0), eO[2] !== XO && (eO[2] = XO, lO = !0), eO[3] !== bK && (eO[3] = bK, lO = !0), lO
      }
      setInt(OO, KO) {
        const pO = this._valueCache[OO];
        void 0 !== pO && pO === KO || this.engine.setInt(this._uniforms[OO], KO) && (this._valueCache[OO] = KO)
      }
      setInt2(OO, KO, pO) {
        this._cacheFloat2(OO, KO, pO) && (this.engine.setInt2(this._uniforms[OO], KO, pO) || (this._valueCache[OO] = null))
      }
      setInt3(OO, KO, pO, XO) {
        this._cacheFloat3(OO, KO, pO, XO) && (this.engine.setInt3(this._uniforms[OO], KO, pO, XO) || (this._valueCache[OO] = null))
      }
      setInt4(OO, KO, pO, XO, bK) {
        this._cacheFloat4(OO, KO, pO, XO, bK) && (this.engine.setInt4(this._uniforms[OO], KO, pO, XO, bK) || (this._valueCache[OO] = null))
      }
      setIntArray(OO, KO) {
        this._valueCache[OO] = null, this.engine.setIntArray(this._uniforms[OO], KO)
      }
      setIntArray2(OO, KO) {
        this._valueCache[OO] = null, this.engine.setIntArray2(this._uniforms[OO], KO)
      }
      setIntArray3(OO, KO) {
        this._valueCache[OO] = null, this.engine.setIntArray3(this._uniforms[OO], KO)
      }
      setIntArray4(OO, KO) {
        this._valueCache[OO] = null, this.engine.setIntArray4(this._uniforms[OO], KO)
      }
      setUInt(OO, KO) {
        const pO = this._valueCache[OO];
        void 0 !== pO && pO === KO || this.engine.setUInt(this._uniforms[OO], KO) && (this._valueCache[OO] = KO)
      }
      setUInt2(OO, KO, pO) {
        this._cacheFloat2(OO, KO, pO) && (this.engine.setUInt2(this._uniforms[OO], KO, pO) || (this._valueCache[OO] = null))
      }
      setUInt3(OO, KO, pO, XO) {
        this._cacheFloat3(OO, KO, pO, XO) && (this.engine.setUInt3(this._uniforms[OO], KO, pO, XO) || (this._valueCache[OO] = null))
      }
      setUInt4(OO, KO, pO, XO, bK) {
        this._cacheFloat4(OO, KO, pO, XO, bK) && (this.engine.setUInt4(this._uniforms[OO], KO, pO, XO, bK) || (this._valueCache[OO] = null))
      }
      setUIntArray(OO, KO) {
        this._valueCache[OO] = null, this.engine.setUIntArray(this._uniforms[OO], KO)
      }
      setUIntArray2(OO, KO) {
        this._valueCache[OO] = null, this.engine.setUIntArray2(this._uniforms[OO], KO)
      }
      setUIntArray3(OO, KO) {
        this._valueCache[OO] = null, this.engine.setUIntArray3(this._uniforms[OO], KO)
      }
      setUIntArray4(OO, KO) {
        this._valueCache[OO] = null, this.engine.setUIntArray4(this._uniforms[OO], KO)
      }
      setArray(OO, KO) {
        this._valueCache[OO] = null, this.engine.setArray(this._uniforms[OO], KO)
      }
      setArray2(OO, KO) {
        this._valueCache[OO] = null, this.engine.setArray2(this._uniforms[OO], KO)
      }
      setArray3(OO, KO) {
        this._valueCache[OO] = null, this.engine.setArray3(this._uniforms[OO], KO)
      }
      setArray4(OO, KO) {
        this._valueCache[OO] = null, this.engine.setArray4(this._uniforms[OO], KO)
      }
      setMatrices(OO, KO) {
        KO && (this._valueCache[OO] = null, this.engine.setMatrices(this._uniforms[OO], KO))
      }
      setMatrix(OO, KO) {
        this._cacheMatrix(OO, KO) && (this.engine.setMatrices(this._uniforms[OO], KO.WhO()) || (this._valueCache[OO] = null))
      }
      setMatrix3x3(OO, KO) {
        this._valueCache[OO] = null, this.engine.setMatrix3x3(this._uniforms[OO], KO)
      }
      setMatrix2x2(OO, KO) {
        this._valueCache[OO] = null, this.engine.setMatrix2x2(this._uniforms[OO], KO)
      }
      setFloat(OO, KO) {
        const pO = this._valueCache[OO];
        void 0 !== pO && pO === KO || this.engine.setFloat(this._uniforms[OO], KO) && (this._valueCache[OO] = KO)
      }
      setVector2(OO, KO) {
        this._cacheFloat2(OO, KO.x, KO.y) && (this.engine.setFloat2(this._uniforms[OO], KO.x, KO.y) || (this._valueCache[OO] = null))
      }
      setFloat2(OO, KO, pO) {
        this._cacheFloat2(OO, KO, pO) && (this.engine.setFloat2(this._uniforms[OO], KO, pO) || (this._valueCache[OO] = null))
      }
      setVector3(OO, KO) {
        this._cacheFloat3(OO, KO.x, KO.y, KO.z) && (this.engine.setFloat3(this._uniforms[OO], KO.x, KO.y, KO.z) || (this._valueCache[OO] = null))
      }
      setFloat3(OO, KO, pO, XO) {
        this._cacheFloat3(OO, KO, pO, XO) && (this.engine.setFloat3(this._uniforms[OO], KO, pO, XO) || (this._valueCache[OO] = null))
      }
      setVector4(OO, KO) {
        this._cacheFloat4(OO, KO.x, KO.y, KO.z, KO.w) && (this.engine.setFloat4(this._uniforms[OO], KO.x, KO.y, KO.z, KO.w) || (this._valueCache[OO] = null))
      }
      setQuaternion(OO, KO) {
        this._cacheFloat4(OO, KO.x, KO.y, KO.z, KO.w) && (this.engine.setFloat4(this._uniforms[OO], KO.x, KO.y, KO.z, KO.w) || (this._valueCache[OO] = null))
      }
      setFloat4(OO, KO, pO, XO, bK) {
        this._cacheFloat4(OO, KO, pO, XO, bK) && (this.engine.setFloat4(this._uniforms[OO], KO, pO, XO, bK) || (this._valueCache[OO] = null))
      }
      setColor3(OO, KO) {
        this._cacheFloat3(OO, KO.r, KO.g, KO.b) && (this.engine.setFloat3(this._uniforms[OO], KO.r, KO.g, KO.b) || (this._valueCache[OO] = null))
      }
      setColor4(OO, KO, pO) {
        this._cacheFloat4(OO, KO.r, KO.g, KO.b, pO) && (this.engine.setFloat4(this._uniforms[OO], KO.r, KO.g, KO.b, pO) || (this._valueCache[OO] = null))
      }
      setDirectColor4(OO, KO) {
        this._cacheFloat4(OO, KO.r, KO.g, KO.b, KO.a) && (this.engine.setFloat4(this._uniforms[OO], KO.r, KO.g, KO.b, KO.a) || (this._valueCache[OO] = null))
      }
      _getVertexShaderCode() {
        return this.vertexShader ? this.engine._getShaderSource(this.vertexShader) : null
      }
      _getFragmentShaderCode() {
        return this.fragmentShader ? this.engine._getShaderSource(this.fragmentShader) : null
      }
    }
    var bK = pO(37930);
    const eO = new WeakMap,
      lO = {
        _webGLVersion: 2,
        cachedPipelines: {}
      };

    function vK(OO) {
      let KO = eO.get(OO);
      if (!KO) {
        if (!OO) return lO;
        KO = {
          _webGLVersion: OO.TEXTURE_BINDING_3D ? 2 : 1,
          _context: OO,
          parallelShaderCompile: OO.getExtension("KHR_parallel_shader_compile") || void 0,
          cachedPipelines: {}
        }, eO.set(OO, KO)
      }
      return KO
    }

    function CO(OO) {
      eO.delete(OO)
    }

    function hO(OO, KO, pO, XO, bK, eO) {
      const lO = vK(XO);
      eO || (eO = lO._createShaderProgramInjection ?? aK);
      return eO(OO, QO(KO, "vertex", XO, lO._contextWasLost), QO(pO, "fragment", XO, lO._contextWasLost), XO, bK, lO.validateShaderPrograms)
    }

    function DO(OO, KO, pO, XO, bK) {
      let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
        lO = arguments.length > 6 ? arguments[6] : void 0;
      const CO = vK(bK);
      lO || (lO = CO._createShaderProgramInjection ?? aK);
      const hO = CO._webGLVersion > 1 ? "#version 300 es\n#define WEBGL2 \n" : "";
      return lO(OO, LO(KO, "vertex", XO, hO, bK, CO._contextWasLost), LO(pO, "fragment", XO, hO, bK, CO._contextWasLost), bK, eO, CO.validateShaderPrograms)
    }

    function MO(OO, KO) {
      const pO = new XO,
        bK = vK(OO);
      return bK.parallelShaderCompile && !bK.disableParallelShaderCompile && (pO.isParallelCompiled = !0), pO.context = bK._context, pO
    }

    function aK(OO, KO, pO, XO) {
      let bK = arguments.length > 5 ? arguments[5] : void 0;
      const eO = XO.createProgram();
      if (OO.program = eO, !eO) throw new Error("Unable to create program");
      return XO.attachShader(eO, KO), XO.attachShader(eO, pO), XO.linkProgram(eO), OO.context = XO, OO.vertexShader = KO, OO.fragmentShader = pO, OO.isParallelCompiled || FO(OO, XO, bK), eO
    }

    function oO(OO, KO, pO) {
      const XO = OO;
      if (XO._isDisposed) return !1;
      const bK = vK(KO);
      return !!(bK && bK.parallelShaderCompile && bK.parallelShaderCompile.COMPLETION_STATUS_KHR && XO.program && KO.getProgramParameter(XO.program, bK.parallelShaderCompile.COMPLETION_STATUS_KHR)) && (FO(XO, KO, pO), !0)
    }

    function FO(OO, KO, pO) {
      const XO = OO.context,
        bK = OO.vertexShader,
        eO = OO.fragmentShader,
        lO = OO.program;
      if (!XO.getProgramParameter(lO, XO.LINK_STATUS)) {
        if (!KO.getShaderParameter(bK, KO.COMPILE_STATUS)) {
          const pO = KO.getShaderInfoLog(bK);
          if (pO) throw OO.vertexCompilationError = pO, new Error("VERTEX SHADER " + pO)
        }
        if (!KO.getShaderParameter(eO, KO.COMPILE_STATUS)) {
          const pO = KO.getShaderInfoLog(eO);
          if (pO) throw OO.fragmentCompilationError = pO, new Error("FRAGMENT SHADER " + pO)
        }
        const pO = XO.getProgramInfoLog(lO);
        if (pO) throw OO.programLinkError = pO, new Error(pO)
      }
      if (pO) {
        XO.validateProgram(lO);
        if (!XO.getProgramParameter(lO, XO.VALIDATE_STATUS)) {
          const KO = XO.getProgramInfoLog(lO);
          if (KO) throw OO.programValidationError = KO, new Error(KO)
        }
      }
      XO.deleteShader(bK), XO.deleteShader(eO), OO.vertexShader = void 0, OO.fragmentShader = void 0, OO.onCompiled && (OO.onCompiled(), OO.onCompiled = void 0)
    }

    function VO(OO, KO, pO, XO, bK, eO, lO, CO, MO) {
      let aK = arguments.length > 10 ? arguments[10] : void 0,
        oO = arguments.length > 11 ? arguments[11] : void 0,
        FO = arguments.length > 12 ? arguments[12] : void 0;
      const VO = vK(OO.context);
      oO || (oO = VO.createRawShaderProgramInjection ?? hO), FO || (FO = VO.createShaderProgramInjection ?? DO);
      const LO = OO;
      LO.program = XO ? oO(LO, KO, pO, LO.context, MO) : FO(LO, KO, pO, CO, LO.context, MO), LO.program.__SPECTOR_rebuildProgram = lO, aK()
    }

    function LO(OO, KO, pO, XO, eO, lO) {
      return QO((0, bK.i)(OO, pO, XO), KO, eO, lO)
    }

    function QO(OO, KO, pO, XO) {
      const bK = pO.createShader("vertex" === KO ? pO.VERTEX_SHADER : pO.FRAGMENT_SHADER);
      if (!bK) {
        let OO, bK = pO.NO_ERROR;
        for (;
          (OO = pO.getError()) !== pO.NO_ERROR;) bK = OO;
        throw new Error(`Something went wrong while creating a gl ${KO} shader object. gl error=${bK}, gl isContextLost=${pO.isContextLost()}, _contextWasLost=${XO}`)
      }
      return pO.shaderSource(bK, OO), pO.compileShader(bK), bK
    }

    function zK(OO, KO) {
      KO.useProgram(OO)
    }

    function AO(OO, KO) {
      const pO = OO;
      if (!pO.isParallelCompiled) return void KO(OO);
      const XO = pO.onCompiled;
      pO.onCompiled = () => {
        XO?.(), KO(OO)
      }
    }
  },
  37899: (OO, KO, pO) => {
    pO.d(KO, {
      ThinEngine: () => dO
    });
    var XO = pO(37902),
      bK = pO(37921),
      eO = pO(37962),
      lO = pO(37978),
      vK = pO(37061),
      CO = pO(37918);
    class hO {
      constructor() {
        this.shaderLanguage = 0
      }
      postProcessor(OO, KO, pO, XO, bK) {
        if (bK.drawBuffersExtensionDisabled) {
          const KO = /#extension.+GL_EXT_draw_buffers.+(enable|require)/g;
          OO = OO.replace(KO, "")
        }
        return OO
      }
    }
    const DO = /(flat\s)?\s*varying\s*.*/;
    class MO {
      constructor() {
        this.shaderLanguage = 0
      }
      attributeProcessor(OO) {
        return OO.replace("attribute", "in")
      }
      varyingCheck(OO, KO) {
        return DO.test(OO)
      }
      varyingProcessor(OO, KO) {
        return OO.replace("varying", KO ? "in" : "out")
      }
      postProcessor(OO, KO, pO) {
        const XO = -1 !== OO.search(/#extension.+GL_EXT_draw_buffers.+require/);
        if (OO = (OO = OO.replace(/#extension.+(GL_OVR_multiview2|GL_OES_standard_derivatives|GL_EXT_shader_texture_lod|GL_EXT_frag_depth|GL_EXT_draw_buffers).+(enable|require)/g, "")).replace(/texture2D\s*\(/g, "texture("), pO) {
          const pO = -1 !== OO.search(/layout *\(location *= *0\) *out/g),
            bK = -1 !== KO.indexOf("#define DUAL_SOURCE_BLENDING"),
            eO = bK ? "layout(location = 0, index = 0) out vec4 glFragColor;\nlayout(location = 0, index = 1) out vec4 glFragColor2;\n" : "layout(location = 0) out vec4 glFragColor;\n";
          bK && (OO = "#extension GL_EXT_blend_func_extended : require\n" + OO), OO = (OO = (OO = (OO = (OO = (OO = (OO = OO.replace(/texture2DLodEXT\s*\(/g, "textureLod(")).replace(/textureCubeLodEXT\s*\(/g, "textureLod(")).replace(/textureCube\s*\(/g, "texture(")).replace(/gl_FragDepthEXT/g, "gl_FragDepth")).replace(/gl_FragColor/g, "glFragColor")).replace(/gl_FragData/g, "glFragData")).replace(/void\s+?main\s*\(/g, (XO || pO ? "" : eO) + "void main(")
        } else {
          KO.indexOf("#define VERTEXOUTPUT_INVARIANT") >= 0 && (OO = "invariant gl_Position;\n" + OO);
          if (-1 !== KO.indexOf("#define MULTIVIEW")) return "#extension GL_OVR_multiview2 : require\nlayout (num_views = 2) in;\n" + OO
        }
        return OO
      }
    }
    var aK = pO(37984),
      oO = pO(37996),
      FO = pO(38001),
      VO = pO(37889),
      LO = pO(37930),
      QO = pO(37912),
      zK = pO(38004),
      AO = pO(37972);
    class fO {}
    class dO extends eO.e {
      get name() {
        return this._name
      }
      set name(OO) {
        this._name = OO
      }
      get version() {
        return this._webGLVersion
      }
      static get ShadersRepository() {
        return XO.e.ShadersRepository
      }
      static set ShadersRepository(OO) {
        XO.e.ShadersRepository = OO
      }
      get supportsUniformBuffers() {
        return this.ye > 1 && !this.disableUniformBuffers
      }
      get needPOTTextures() {
        return this._webGLVersion < 2 || this.forcePOTTextures
      }
      get _supportsHardwareTextureRescaling() {
        return !1
      }
      snapshotRenderingReset() {
        this.snapshotRendering = !1
      }
      constructor(OO, KO, pO, XO) {
        if (pO = pO || {}, super(KO ?? pO.antialias, pO, XO), this._name = "WebGL", this.forcePOTTextures = !1, this.validateShaderPrograms = !1, this.disableUniformBuffers = !1, this._webGLVersion = 1, this._integerMRTAttachmentsMask = 0, this._vertexAttribArraysEnabled = [], this._uintIndicesCurrentlySet = !1, this._currentBoundBuffer = new Array, this._currentFramebuffer = null, this._dummyFramebuffer = null, this._currentBufferPointers = new Array, this._currentInstanceLocations = new Array, this._currentInstanceBuffers = new Array, this._vaoRecordInProgress = !1, this._mustWipeVertexAttributes = !1, this._nextFreeTextureSlots = new Array, this._maxSimultaneousTextures = 0, this._maxMSAASamplesOverride = null, this._unpackFlipYCached = null, this.enableUnpackFlipYCached = !0, this._boundUniforms = {}, !OO) return;
        let eO;
        if (OO.getContext) {
          if (eO = OO, void 0 === pO.preserveDrawingBuffer && (pO.preserveDrawingBuffer = !1), void 0 === pO.xrCompatible && (pO.xrCompatible = !1), navigator && navigator.userAgent) {
            this._setupMobileChecks();
            const OO = navigator.userAgent;
            for (const KO of dO.ExceptionList) {
              const XO = KO.key,
                bK = KO.targets;
              if (new RegExp(XO).test(OO)) {
                if (KO.capture && KO.captureConstraint) {
                  const pO = KO.capture,
                    XO = KO.captureConstraint,
                    bK = new RegExp(pO).exec(OO);
                  if (bK && bK.length > 0) {
                    if (parseInt(bK[bK.length - 1]) >= XO) continue
                  }
                }
                for (const OO of bK) switch (OO) {
                  case "uniformBuffer":
                    this.disableUniformBuffers = !0;
                    break;
                  case "vao":
                    this.disableVertexArrayObjects = !0;
                    break;
                  case "antialias":
                    pO.antialias = !1;
                    break;
                  case "maxMSAASamples":
                    this._maxMSAASamplesOverride = 1
                }
              }
            }
          }
          if (this._doNotHandleContextLost ? this._onContextLost = () => {
              (0, bK.w)(this._gl)
            } : (this._onContextLost = OO => {
              OO.preventDefault(), this._contextWasLost = !0, (0, bK.w)(this._gl), vK.b.Warn("WebGL context lost."), this.onContextLostObservable.notifyObservers(this)
            }, this._onContextRestored = () => {
              this._restoreEngineAfterContextLost((() => this._initGLContext()))
            }, eO.addEventListener("webglcontextrestored", this._onContextRestored, !1), pO.powerPreference = pO.powerPreference || "high-performance"), eO.addEventListener("webglcontextlost", this._onContextLost, !1), this._badDesktopOS && (pO.xrCompatible = !1), !pO.disableWebGL2Support) try {
            this._gl = eO.getContext("webgl2", pO) || eO.getContext("experimental-webgl2", pO), this._gl && (this._webGLVersion = 2, this._shaderPlatformName = "WEBGL2", this._gl.deleteQuery || (this._webGLVersion = 1, this._shaderPlatformName = "WEBGL1"))
          } catch (DO) {}
          if (!this._gl) {
            if (!eO) throw new Error("The provided canvas is null or undefined.");
            try {
              this._gl = eO.getContext("webgl", pO) || eO.getContext("experimental-webgl", pO)
            } catch (DO) {
              throw new Error("WebGL not supported", {
                cause: DO
              })
            }
          }
          if (!this._gl) throw new Error("WebGL not supported")
        } else {
          this._gl = OO, eO = this._gl.canvas, this._gl.renderbufferStorageMultisample ? (this._webGLVersion = 2, this._shaderPlatformName = "WEBGL2") : this._shaderPlatformName = "WEBGL1";
          const KO = this._gl.getContextAttributes();
          KO && (pO.stencil = KO.stencil)
        }
        this._sharedInit(eO), this._gl.pixelStorei(this._gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, this._gl.NONE), void 0 !== pO.useHighPrecisionFloats && (this._highPrecisionShadersAllowed = pO.useHighPrecisionFloats), this.resize(), this._initGLContext(), this._initFeatures();
        for (let bK = 0; bK < this._caps.maxVertexAttribs; bK++) this._currentBufferPointers[bK] = new fO;
        this._shaderProcessor = this.ye > 1 ? new MO : new hO;
        const lO = `Babylon.js v${dO.Version}`;
        vK.b.Log(lO + ` - ${this.description}`), this._renderingCanvas && this._renderingCanvas.setAttribute && this._renderingCanvas.setAttribute("data-engine", lO);
        const CO = (0, bK.A)(this._gl);
        CO.validateShaderPrograms = this.validateShaderPrograms, CO.parallelShaderCompile = this._caps.parallelShaderCompile
      }
      _clearEmptyResources() {
        this._dummyFramebuffer = null, super._clearEmptyResources()
      }
      _getShaderProcessingContext(OO) {
        return null
      }
      areAllEffectsReady() {
        for (const OO in this._compiledEffects) {
          if (!this._compiledEffects[OO].isReady()) return !1
        }
        return !0
      }
      _initGLContext() {
        this._caps = {
          maxTexturesImageUnits: this._gl.getParameter(this._gl.MAX_TEXTURE_IMAGE_UNITS),
          maxCombinedTexturesImageUnits: this._gl.getParameter(this._gl.MAX_COMBINED_TEXTURE_IMAGE_UNITS),
          maxVertexTextureImageUnits: this._gl.getParameter(this._gl.MAX_VERTEX_TEXTURE_IMAGE_UNITS),
          maxTextureSize: this._gl.getParameter(this._gl.MAX_TEXTURE_SIZE),
          maxSamples: this._webGLVersion > 1 ? this._gl.getParameter(this._gl.MAX_SAMPLES) : 1,
          maxCubemapTextureSize: this._gl.getParameter(this._gl.MAX_CUBE_MAP_TEXTURE_SIZE),
          maxRenderTextureSize: this._gl.getParameter(this._gl.MAX_RENDERBUFFER_SIZE),
          maxVertexAttribs: this._gl.getParameter(this._gl.MAX_VERTEX_ATTRIBS),
          maxVaryingVectors: this._gl.getParameter(this._gl.MAX_VARYING_VECTORS),
          maxFragmentUniformVectors: this._gl.getParameter(this._gl.MAX_FRAGMENT_UNIFORM_VECTORS),
          maxVertexUniformVectors: this._gl.getParameter(this._gl.MAX_VERTEX_UNIFORM_VECTORS),
          shaderFloatPrecision: 0,
          parallelShaderCompile: this._gl.getExtension("KHR_parallel_shader_compile") || void 0,
          standardDerivatives: this._webGLVersion > 1 || null !== this._gl.getExtension("OES_standard_derivatives"),
          maxAnisotropy: 1,
          astc: this._gl.getExtension("WEBGL_compressed_texture_astc") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_astc"),
          bptc: this._gl.getExtension("EXT_texture_compression_bptc") || this._gl.getExtension("WEBKIT_EXT_texture_compression_bptc"),
          s3tc: this._gl.getExtension("WEBGL_compressed_texture_s3tc") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc"),
          s3tc_srgb: this._gl.getExtension("WEBGL_compressed_texture_s3tc_srgb") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc_srgb"),
          pvrtc: this._gl.getExtension("WEBGL_compressed_texture_pvrtc") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc"),
          etc1: this._gl.getExtension("WEBGL_compressed_texture_etc1") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_etc1"),
          etc2: this._gl.getExtension("WEBGL_compressed_texture_etc") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_etc") || this._gl.getExtension("WEBGL_compressed_texture_es3_0"),
          textureAnisotropicFilterExtension: this._gl.getExtension("EXT_texture_filter_anisotropic") || this._gl.getExtension("WEBKIT_EXT_texture_filter_anisotropic") || this._gl.getExtension("MOZ_EXT_texture_filter_anisotropic"),
          uintIndices: this._webGLVersion > 1 || null !== this._gl.getExtension("OES_element_index_uint"),
          fragmentDepthSupported: this._webGLVersion > 1 || null !== this._gl.getExtension("EXT_frag_depth"),
          highPrecisionShaderSupported: !1,
          timerQuery: this._gl.getExtension("EXT_disjoint_timer_query_webgl2") || this._gl.getExtension("EXT_disjoint_timer_query"),
          supportOcclusionQuery: this._webGLVersion > 1,
          canUseTimestampForTimerQuery: !1,
          drawBuffersExtension: !1,
          maxMSAASamples: 1,
          colorBufferFloat: !!(this._webGLVersion > 1 && this._gl.getExtension("EXT_color_buffer_float")),
          blendFloat: null !== this._gl.getExtension("EXT_float_blend"),
          supportFloatTexturesResolve: !1,
          rg11b10ufColorRenderable: !1,
          colorBufferHalfFloat: !!(this._webGLVersion > 1 && this._gl.getExtension("EXT_color_buffer_half_float")),
          textureFloat: !!(this._webGLVersion > 1 || this._gl.getExtension("OES_texture_float")),
          textureHalfFloat: !!(this._webGLVersion > 1 || this._gl.getExtension("OES_texture_half_float")),
          textureHalfFloatRender: !1,
          textureFloatLinearFiltering: !1,
          textureFloatRender: !1,
          textureHalfFloatLinearFiltering: !1,
          vertexArrayObject: !1,
          instancedArrays: !1,
          textureLOD: !!(this._webGLVersion > 1 || this._gl.getExtension("EXT_shader_texture_lod")),
          texelFetch: 1 !== this._webGLVersion,
          blendMinMax: !1,
          multiview: this._gl.getExtension("OVR_multiview2"),
          oculusMultiview: this._gl.getExtension("OCULUS_multiview"),
          depthTextureExtension: !1,
          canUseGLInstanceID: this._webGLVersion > 1,
          canUseGLVertexID: this._webGLVersion > 1,
          supportComputeShaders: !1,
          supportSRGBBuffers: !1,
          supportTransformFeedbacks: this._webGLVersion > 1,
          textureMaxLevel: this._webGLVersion > 1,
          texture2DArrayMaxLayerCount: this._webGLVersion > 1 ? this._gl.getParameter(this._gl.MAX_ARRAY_TEXTURE_LAYERS) : 128,
          disableMorphTargetTexture: !1,
          textureNorm16: !!this._gl.getExtension("EXT_texture_norm16"),
          blendParametersPerTarget: !1,
          dualSourceBlending: !1,
          supportReadWriteStorageTextures: !1
        }, this._caps.supportFloatTexturesResolve = this._caps.colorBufferFloat, this._caps.rg11b10ufColorRenderable = this._caps.colorBufferFloat, this._glVersion = this._gl.getParameter(this._gl.VERSION);
        const OO = this._gl.getExtension("WEBGL_debug_renderer_info");
        null != OO && (this._glRenderer = this._gl.getParameter(OO.UNMASKED_RENDERER_WEBGL), this._glVendor = this._gl.getParameter(OO.UNMASKED_VENDOR_WEBGL)), this._glVendor || (this._glVendor = this._gl.getParameter(this._gl.VENDOR) || "Unknown vendor"), this._glRenderer || (this._glRenderer = this._gl.getParameter(this._gl.RENDERER) || "Unknown renderer"), 36193 !== this._gl.HALF_FLOAT_OES && (this._gl.HALF_FLOAT_OES = 36193), 34842 !== this._gl.RGBA16F && (this._gl.RGBA16F = 34842), 34836 !== this._gl.RGBA32F && (this._gl.RGBA32F = 34836), 35056 !== this._gl.DEPTH24_STENCIL8 && (this._gl.DEPTH24_STENCIL8 = 35056), this._caps.timerQuery && (1 === this._webGLVersion && (this._gl.getQuery = this._caps.timerQuery.getQueryEXT.bind(this._caps.timerQuery)), this._caps.canUseTimestampForTimerQuery = (this._gl.getQuery(this._caps.timerQuery.TIMESTAMP_EXT, this._caps.timerQuery.QUERY_COUNTER_BITS_EXT) ?? 0) > 0), this._caps.maxAnisotropy = this._caps.textureAnisotropicFilterExtension ? this._gl.getParameter(this._caps.textureAnisotropicFilterExtension.MAX_TEXTURE_MAX_ANISOTROPY_EXT) : 0, this._caps.textureFloatLinearFiltering = !(!this._caps.textureFloat || !this._gl.getExtension("OES_texture_float_linear")), this._caps.textureFloatRender = !(!this._caps.textureFloat || !this._canRenderToFloatFramebuffer()), this._caps.textureHalfFloatLinearFiltering = !!(this._webGLVersion > 1 || this._caps.textureHalfFloat && this._gl.getExtension("OES_texture_half_float_linear")), this._caps.textureNorm16 && (this._gl.R16_EXT = 33322, this._gl.RG16_EXT = 33324, this._gl.RGB16_EXT = 32852, this._gl.RGBA16_EXT = 32859, this._gl.R16_SNORM_EXT = 36760, this._gl.RG16_SNORM_EXT = 36761, this._gl.RGB16_SNORM_EXT = 36762, this._gl.RGBA16_SNORM_EXT = 36763);
        const KO = this._gl.getExtension("OES_draw_buffers_indexed");
        if (this._caps.blendParametersPerTarget = !!KO, this._alphaState = new AO.c(this._caps.blendParametersPerTarget), KO && (this._gl.blendEquationSeparateIndexed = KO.blendEquationSeparateiOES.bind(KO), this._gl.blendEquationIndexed = KO.blendEquationiOES.bind(KO), this._gl.blendFuncSeparateIndexed = KO.blendFuncSeparateiOES.bind(KO), this._gl.blendFuncIndexed = KO.blendFunciOES.bind(KO), this._gl.colorMaskIndexed = KO.colorMaskiOES.bind(KO), this._gl.disableIndexed = KO.disableiOES.bind(KO), this._gl.enableIndexed = KO.enableiOES.bind(KO)), this._caps.dualSourceBlending = !!this._gl.getExtension("WEBGL_blend_func_extended"), this._caps.astc && (this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR), this._caps.bptc && (this._gl.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT = this._caps.bptc.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT), this._caps.s3tc_srgb && (this._gl.COMPRESSED_SRGB_S3TC_DXT1_EXT = this._caps.s3tc_srgb.COMPRESSED_SRGB_S3TC_DXT1_EXT, this._gl.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT = this._caps.s3tc_srgb.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT, this._gl.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT = this._caps.s3tc_srgb.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT), this._caps.etc2 && (this._gl.COMPRESSED_SRGB8_ETC2 = this._caps.etc2.COMPRESSED_SRGB8_ETC2, this._gl.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC = this._caps.etc2.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC), this._webGLVersion > 1 && 5131 !== this._gl.HALF_FLOAT_OES && (this._gl.HALF_FLOAT_OES = 5131), this._caps.textureHalfFloatRender = this._caps.textureHalfFloat && this._canRenderToHalfFloatFramebuffer(), this._webGLVersion > 1) this._caps.drawBuffersExtension = !0, this._caps.maxMSAASamples = null !== this._maxMSAASamplesOverride ? this._maxMSAASamplesOverride : this._gl.getParameter(this._gl.MAX_SAMPLES), this._caps.maxDrawBuffers = this._gl.getParameter(this._gl.MAX_DRAW_BUFFERS);
        else {
          const OO = this._gl.getExtension("WEBGL_draw_buffers");
          if (null !== OO) {
            this._caps.drawBuffersExtension = !0, this._gl.drawBuffers = OO.drawBuffersWEBGL.bind(OO), this._caps.maxDrawBuffers = this._gl.getParameter(OO.MAX_DRAW_BUFFERS_WEBGL), this._gl.DRAW_FRAMEBUFFER = this._gl.FRAMEBUFFER;
            for (let KO = 0; KO < 16; KO++) this._gl["COLOR_ATTACHMENT" + KO + "_WEBGL"] = OO["COLOR_ATTACHMENT" + KO + "_WEBGL"]
          }
        }
        if (this._webGLVersion > 1) this._caps.depthTextureExtension = !0;
        else {
          const OO = this._gl.getExtension("WEBGL_depth_texture");
          null != OO && (this._caps.depthTextureExtension = !0, this._gl.UNSIGNED_INT_24_8 = OO.UNSIGNED_INT_24_8_WEBGL)
        }
        if (this.disableVertexArrayObjects) this._caps.vertexArrayObject = !1;
        else if (this._webGLVersion > 1) this._caps.vertexArrayObject = !0;
        else {
          const OO = this._gl.getExtension("OES_vertex_array_object");
          null != OO && (this._caps.vertexArrayObject = !0, this._gl.createVertexArray = OO.createVertexArrayOES.bind(OO), this._gl.bindVertexArray = OO.bindVertexArrayOES.bind(OO), this._gl.deleteVertexArray = OO.deleteVertexArrayOES.bind(OO))
        }
        if (this._webGLVersion > 1) this._caps.instancedArrays = !0;
        else {
          const OO = this._gl.getExtension("ANGLE_instanced_arrays");
          null != OO ? (this._caps.instancedArrays = !0, this._gl.drawArraysInstanced = OO.drawArraysInstancedANGLE.bind(OO), this._gl.drawElementsInstanced = OO.drawElementsInstancedANGLE.bind(OO), this._gl.vertexAttribDivisor = OO.vertexAttribDivisorANGLE.bind(OO)) : this._caps.instancedArrays = !1
        }
        if (this._gl.getShaderPrecisionFormat) {
          const OO = this._gl.getShaderPrecisionFormat(this._gl.VERTEX_SHADER, this._gl.HIGH_FLOAT),
            KO = this._gl.getShaderPrecisionFormat(this._gl.FRAGMENT_SHADER, this._gl.HIGH_FLOAT);
          if (OO && KO && (this._caps.highPrecisionShaderSupported = 0 !== OO.precision && 0 !== KO.precision, this._caps.shaderFloatPrecision = Math.min(OO.precision, KO.precision)), !this._shouldUseHighPrecisionShader) {
            const OO = this._gl.getShaderPrecisionFormat(this._gl.VERTEX_SHADER, this._gl.MEDIUM_FLOAT),
              KO = this._gl.getShaderPrecisionFormat(this._gl.FRAGMENT_SHADER, this._gl.MEDIUM_FLOAT);
            OO && KO && (this._caps.shaderFloatPrecision = Math.min(OO.precision, KO.precision))
          }
          this._caps.shaderFloatPrecision < 10 && (this._caps.shaderFloatPrecision = 10)
        }
        if (this._webGLVersion > 1) this._caps.blendMinMax = !0;
        else {
          const OO = this._gl.getExtension("EXT_blend_minmax");
          null != OO && (this._caps.blendMinMax = !0, this._gl.MAX = OO.MAX_EXT, this._gl.MIN = OO.MIN_EXT)
        }
        if (!this._caps.supportSRGBBuffers) {
          if (this._webGLVersion > 1) this._caps.supportSRGBBuffers = !0, this._glSRGBExtensionValues = {
            SRGB: WebGL2RenderingContext.SRGB,
            SRGB8: WebGL2RenderingContext.SRGB8,
            SRGB8_ALPHA8: WebGL2RenderingContext.SRGB8_ALPHA8
          };
          else {
            const OO = this._gl.getExtension("EXT_sRGB");
            null != OO && (this._caps.supportSRGBBuffers = !0, this._glSRGBExtensionValues = {
              SRGB: OO.SRGB_EXT,
              SRGB8: OO.SRGB_ALPHA_EXT,
              SRGB8_ALPHA8: OO.SRGB_ALPHA_EXT
            })
          }
          if (this._creationOptions) {
            const OO = this._creationOptions.forceSRGBBufferSupportState;
            void 0 !== OO && (this._caps.supportSRGBBuffers = this._caps.supportSRGBBuffers && OO)
          }
        }
        this._depthCullingState.depthTest = !0, this._depthCullingState.depthFunc = this._gl.LEQUAL, this._depthCullingState.depthMask = !0, this._maxSimultaneousTextures = this._caps.maxCombinedTexturesImageUnits;
        for (let pO = 0; pO < this._maxSimultaneousTextures; pO++) this._nextFreeTextureSlots.push(pO);
        "Mali-G72" === this._glRenderer && (this._caps.disableMorphTargetTexture = !0)
      }
      _initFeatures() {
        this._features = {
          forceBitmapOverHTMLImageElement: "undefined" === typeof HTMLImageElement,
          supportRenderAndCopyToLodForFloatTextures: 1 !== this._webGLVersion,
          supportDepthStencilTexture: 1 !== this._webGLVersion,
          supportShadowSamplers: 1 !== this._webGLVersion,
          uniformBufferHardCheckMatrix: !1,
          allowTexturePrefiltering: 1 !== this._webGLVersion,
          trackUbosInFrame: !1,
          checkUbosContentBeforeUpload: !1,
          supportCSM: 1 !== this._webGLVersion,
          basisNeedsPOT: 1 === this._webGLVersion,
          support3DTextures: 1 !== this._webGLVersion,
          needTypeSuffixInShaderConstants: 1 !== this._webGLVersion,
          supportMSAA: 1 !== this._webGLVersion,
          supportSSAO2: 1 !== this._webGLVersion,
          supportIBLShadows: 1 !== this._webGLVersion,
          supportExtendedTextureFormats: 1 !== this._webGLVersion,
          supportSwitchCaseInShader: 1 !== this._webGLVersion,
          supportSyncTextureRead: !0,
          needsInvertingBitmap: !0,
          useUBOBindingCache: !0,
          needShaderCodeInlining: !1,
          needToAlwaysBindUniformBuffers: !1,
          supportRenderPasses: !1,
          supportSpriteInstancing: !0,
          forceVertexBufferStrideAndOffsetMultiple4Bytes: !1,
          _checkNonFloatVertexBuffersDontRecreatePipelineContext: !1
        }
      }
      get ye() {
        return this._webGLVersion
      }
      getClassName() {
        return "ThinEngine"
      }
      _prepareWorkingCanvas() {
        if (this._workingCanvas) return;
        this._workingCanvas = this.createCanvas(1, 1);
        const OO = this._workingCanvas.getContext("2d");
        OO && (this._workingContext = OO)
      }
      getInfo() {
        return this.getGlInfo()
      }
      getGlInfo() {
        return {
          vendor: this._glVendor,
          renderer: this._glRenderer,
          version: this._glVersion
        }
      }
      extractDriverInfo() {
        const OO = this.getGlInfo();
        return OO && OO.renderer ? OO.renderer : ""
      }
      getRenderWidth() {
        return !(arguments.length > 0 && void 0 !== arguments[0] && arguments[0]) && this._currentRenderTarget ? this._currentRenderTarget.width : this._framebufferDimensionsObject ? this._framebufferDimensionsObject.framebufferWidth : this._gl.drawingBufferWidth
      }
      getRenderHeight() {
        return !(arguments.length > 0 && void 0 !== arguments[0] && arguments[0]) && this._currentRenderTarget ? this._currentRenderTarget.height : this._framebufferDimensionsObject ? this._framebufferDimensionsObject.framebufferHeight : this._gl.drawingBufferHeight
      }
      clear(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0;
        const eO = this.stencilStateComposer.useStencilGlobalOnly;
        this.stencilStateComposer.useStencilGlobalOnly = !0, this.applyStates(), this.stencilStateComposer.useStencilGlobalOnly = eO;
        let lO = 0;
        if (KO && OO) {
          let KO = !0;
          if (this._currentRenderTarget) {
            const pO = this._currentRenderTarget.texture?.format;
            if (void 0 !== pO && (0, zK.j)(pO)) {
              const pO = this._currentRenderTarget.texture?.type;
              void 0 !== pO && (0, zK.k)(pO) ? (dO._TempClearColorUint32[0] = 255 * OO.r, dO._TempClearColorUint32[1] = 255 * OO.g, dO._TempClearColorUint32[2] = 255 * OO.b, dO._TempClearColorUint32[3] = 255 * OO.a, this._gl.clearBufferuiv(this._gl.COLOR, 0, dO._TempClearColorUint32), KO = !1) : (dO._TempClearColorInt32[0] = 255 * OO.r, dO._TempClearColorInt32[1] = 255 * OO.g, dO._TempClearColorInt32[2] = 255 * OO.b, dO._TempClearColorInt32[3] = 255 * OO.a, this._gl.clearBufferiv(this._gl.COLOR, 0, dO._TempClearColorInt32), KO = !1)
            }
          }
          KO && (this._gl.clearColor(OO.r, OO.g, OO.b, void 0 !== OO.a ? OO.a : 1), lO |= this._gl.COLOR_BUFFER_BIT)
        }
        pO && (this.BhO ? (this._depthCullingState.depthFunc = this._gl.GEQUAL, this._gl.clearDepth(0)) : this._gl.clearDepth(1), lO |= this._gl.DEPTH_BUFFER_BIT), XO && (this._gl.clearStencil(bK), lO |= this._gl.STENCIL_BUFFER_BIT), this._gl.clear(lO)
      }
      _clearColorAttachment(OO, KO, pO, XO) {
        if ((0, zK.j)(pO)) {
          const pO = (0, zK.k)(XO),
            bK = pO ? dO._TempClearColorUint32 : dO._TempClearColorInt32;
          return bK[0] = KO.r, bK[1] = KO.g, bK[2] = KO.b, bK[3] = KO.a, void(pO ? this._gl.clearBufferuiv(this._gl.COLOR, OO, bK) : this._gl.clearBufferiv(this._gl.COLOR, OO, bK))
        }
        dO._TempClearColorFloat32[0] = KO.r, dO._TempClearColorFloat32[1] = KO.g, dO._TempClearColorFloat32[2] = KO.b, dO._TempClearColorFloat32[3] = KO.a, this._gl.clearBufferfv(this._gl.COLOR, OO, dO._TempClearColorFloat32)
      }
      _viewport(OO, KO, pO, XO) {
        OO === this._viewportCached.x && KO === this._viewportCached.y && pO === this._viewportCached.z && XO === this._viewportCached.w || (this._viewportCached.x = OO, this._viewportCached.y = KO, this._viewportCached.z = pO, this._viewportCached.w = XO, this._gl.viewport(OO, KO, pO, XO))
      }
      EL() {
        super.EL(), this._badOS && this.flushFramebuffer()
      }
      get performanceMonitor() {
        throw new Error("Not Supported by ThinEngine")
      }
      bindFramebuffer(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0,
          bK = arguments.length > 4 ? arguments[4] : void 0,
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
          lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0;
        const CO = OO;
        this._currentRenderTarget && this._resolveAndGenerateMipMapsFramebuffer(this._currentRenderTarget), this._currentRenderTarget = OO, this._integerMRTAttachmentsMask = !OO.isMulti && OO.texture && (0, zK.j)(OO.texture.format) ? 1 : 0, this._bindUnboundFramebuffer(CO._framebuffer);
        const hO = this._gl;
        OO.isMulti || (OO.is2DArray || OO.is3D ? (hO.framebufferTextureLayer(hO.FRAMEBUFFER, hO.COLOR_ATTACHMENT0, OO.texture._hardwareTexture?.underlyingResource, eO, lO), CO._currentLOD = eO) : OO.isCube ? hO.framebufferTexture2D(hO.FRAMEBUFFER, hO.COLOR_ATTACHMENT0, hO.TEXTURE_CUBE_MAP_POSITIVE_X + KO, OO.texture._hardwareTexture?.underlyingResource, eO) : CO._currentLOD !== eO && (hO.framebufferTexture2D(hO.FRAMEBUFFER, hO.COLOR_ATTACHMENT0, hO.TEXTURE_2D, OO.texture._hardwareTexture?.underlyingResource, eO), CO._currentLOD = eO));
        const DO = OO._depthStencilTexture;
        if (DO) {
          OO.is3D && (OO.texture.width === DO.width && OO.texture.height === DO.height && OO.texture.depth === DO.depth || vK.b.Warn("Depth/Stencil attachment for 3D target must have same dimensions as color attachment"));
          const pO = OO._depthStencilTextureWithStencil ? hO.DEPTH_STENCIL_ATTACHMENT : hO.DEPTH_ATTACHMENT;
          OO.is2DArray || OO.is3D ? hO.framebufferTextureLayer(hO.FRAMEBUFFER, pO, DO._hardwareTexture?.underlyingResource, eO, lO) : OO.isCube ? hO.framebufferTexture2D(hO.FRAMEBUFFER, pO, hO.TEXTURE_CUBE_MAP_POSITIVE_X + KO, DO._hardwareTexture?.underlyingResource, eO) : hO.framebufferTexture2D(hO.FRAMEBUFFER, pO, hO.TEXTURE_2D, DO._hardwareTexture?.underlyingResource, eO)
        }
        CO._MSAAFramebuffer && this._bindUnboundFramebuffer(CO._MSAAFramebuffer), this._cachedViewport && !bK ? this.setViewport(this._cachedViewport, pO, XO) : (pO || (pO = OO.width, eO && (pO /= Math.pow(2, eO))), XO || (XO = OO.height, eO && (XO /= Math.pow(2, eO))), this._viewport(0, 0, pO, XO)), this.wipeCaches()
      }
      setStateCullFaceType(OO, KO) {
        const pO = this.cullBackFaces ?? OO ?? 1 ? this._gl.BACK : this._gl.FRONT;
        (this._depthCullingState.cullFace !== pO || KO) && (this._depthCullingState.cullFace = pO)
      }
      setState(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          bK = arguments.length > 4 ? arguments[4] : void 0,
          eO = arguments.length > 5 ? arguments[5] : void 0,
          lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0;
        (this._depthCullingState.cull !== OO || pO) && (this._depthCullingState.cull = OO), this.setStateCullFaceType(bK, pO), this.setZOffset(KO), this.setZOffsetUnits(lO);
        const vK = XO ? this._gl.CW : this._gl.CCW;
        (this._depthCullingState.frontFace !== vK || pO) && (this._depthCullingState.frontFace = vK), this._stencilStateComposer.stencilMaterial = eO
      }
      _resolveAndGenerateMipMapsFramebuffer(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        OO.disableAutomaticMSAAResolve || (OO.isMulti ? this.resolveMultiFramebuffer(OO) : this.resolveFramebuffer(OO)), KO || (OO.isMulti ? this.generateMipMapsMultiFramebuffer(OO) : this.generateMipMapsFramebuffer(OO))
      }
      _bindUnboundFramebuffer(OO) {
        this._currentFramebuffer !== OO && (this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, OO), this._currentFramebuffer = OO)
      }
      _currentFrameBufferIsDefaultFrameBuffer() {
        return null === this._currentFramebuffer
      }
      generateMipmaps(OO) {
        const KO = this._getTextureTarget(OO);
        this._bindTextureDirectly(KO, OO, !0), this._gl.generateMipmap(KO), this._bindTextureDirectly(KO, null)
      }
      unBindFramebuffer(OO, KO, pO) {
        const XO = OO;
        this._currentRenderTarget = null, this._integerMRTAttachmentsMask = 0, this._resolveAndGenerateMipMapsFramebuffer(OO, KO), pO && (XO._MSAAFramebuffer && this._bindUnboundFramebuffer(XO._framebuffer), pO()), this._bindUnboundFramebuffer(null)
      }
      generateMipMapsFramebuffer(OO) {
        OO.isMulti || !OO.texture?.generateMipMaps || OO.isCube || this.generateMipmaps(OO.texture)
      }
      resolveFramebuffer(OO) {
        const KO = OO,
          pO = this._gl;
        if (!KO._MSAAFramebuffer || KO.isMulti) return;
        let XO = KO.resolveMSAAColors ? pO.COLOR_BUFFER_BIT : 0;
        XO |= KO._generateDepthBuffer && KO.resolveMSAADepth ? pO.DEPTH_BUFFER_BIT : 0, XO |= KO._generateStencilBuffer && KO.resolveMSAAStencil ? pO.STENCIL_BUFFER_BIT : 0, pO.bindFramebuffer(pO.READ_FRAMEBUFFER, KO._MSAAFramebuffer), pO.bindFramebuffer(pO.DRAW_FRAMEBUFFER, KO._framebuffer), pO.blitFramebuffer(0, 0, OO.width, OO.height, 0, 0, OO.width, OO.height, XO, pO.NEAREST)
      }
      flushFramebuffer() {
        this._gl.flush()
      }
      restoreDefaultFramebuffer() {
        this._currentRenderTarget ? this.unBindFramebuffer(this._currentRenderTarget) : this._bindUnboundFramebuffer(null), this._cachedViewport && this.setViewport(this._cachedViewport), this.wipeCaches()
      }
      _resetVertexBufferBinding() {
        this.bindArrayBuffer(null), this._cachedVertexBuffers = null
      }
      createVertexBuffer(OO, KO, pO) {
        return this._createVertexBuffer(OO, this._gl.STATIC_DRAW)
      }
      _createVertexBuffer(OO, KO) {
        const pO = this._gl.createBuffer();
        if (!pO) throw new Error("Unable to create vertex buffer");
        const XO = new aK.e(pO);
        return this.bindArrayBuffer(XO), "number" !== typeof OO ? OO instanceof Array ? (this._gl.bufferData(this._gl.ARRAY_BUFFER, new Float32Array(OO), KO), XO.YO = 4 * OO.length) : (this._gl.bufferData(this._gl.ARRAY_BUFFER, OO, KO), XO.YO = OO.byteLength) : (this._gl.bufferData(this._gl.ARRAY_BUFFER, new Uint8Array(OO), KO), XO.YO = OO), this._resetVertexBufferBinding(), XO.references = 1, XO
      }
      createDynamicVertexBuffer(OO, KO) {
        return this._createVertexBuffer(OO, this._gl.DYNAMIC_DRAW)
      }
      _resetIndexBufferBinding() {
        this.bindIndexBuffer(null), this._cachedIndexBuffer = null
      }
      createIndexBuffer(OO, KO, pO) {
        const XO = this._gl.createBuffer(),
          bK = new aK.e(XO);
        if (!XO) throw new Error("Unable to create index buffer");
        this.bindIndexBuffer(bK);
        const eO = this._normalizeIndexData(OO);
        return this._gl.bufferData(this._gl.ELEMENT_ARRAY_BUFFER, eO, KO ? this._gl.DYNAMIC_DRAW : this._gl.STATIC_DRAW), this._resetIndexBufferBinding(), bK.references = 1, bK.is32Bits = 4 === eO.BYTES_PER_ELEMENT, bK
      }
      _normalizeIndexData(OO) {
        if (2 === OO.BYTES_PER_ELEMENT) return OO;
        if (this._caps.uintIndices) {
          if (OO instanceof Uint32Array) return OO;
          for (let KO = 0; KO < OO.length; KO++)
            if (OO[KO] >= 65535) return new Uint32Array(OO);
          return new Uint16Array(OO)
        }
        return new Uint16Array(OO)
      }
      bindArrayBuffer(OO) {
        this._vaoRecordInProgress || this._unbindVertexArrayObject(), this._bindBuffer(OO, this._gl.ARRAY_BUFFER)
      }
      bindUniformBlock(OO, KO, pO) {
        const XO = OO.program,
          bK = this._gl.getUniformBlockIndex(XO, KO);
        this._gl.uniformBlockBinding(XO, bK, pO)
      }
      bindIndexBuffer(OO) {
        this._vaoRecordInProgress || this._unbindVertexArrayObject(), this._bindBuffer(OO, this._gl.ELEMENT_ARRAY_BUFFER)
      }
      _bindBuffer(OO, KO) {
        (this._vaoRecordInProgress || this._currentBoundBuffer[KO] !== OO) && (this._gl.bindBuffer(KO, OO ? OO.underlyingResource : null), this._currentBoundBuffer[KO] = OO)
      }
      updateArrayBuffer(OO) {
        this._gl.bufferSubData(this._gl.ARRAY_BUFFER, 0, OO)
      }
      _vertexAttribPointer(OO, KO, pO, XO, bK, eO, lO) {
        const vK = this._currentBufferPointers[KO];
        if (!vK) return;
        let CO = !1;
        vK.active ? (vK.buffer !== OO && (vK.buffer = OO, CO = !0), vK.size !== pO && (vK.size = pO, CO = !0), vK.type !== XO && (vK.type = XO, CO = !0), vK.normalized !== bK && (vK.normalized = bK, CO = !0), vK.stride !== eO && (vK.stride = eO, CO = !0), vK.offset !== lO && (vK.offset = lO, CO = !0)) : (CO = !0, vK.active = !0, vK.index = KO, vK.size = pO, vK.type = XO, vK.normalized = bK, vK.stride = eO, vK.offset = lO, vK.buffer = OO), (CO || this._vaoRecordInProgress) && (this.bindArrayBuffer(OO), XO === this._gl.UNSIGNED_INT || XO === this._gl.INT ? this._gl.vertexAttribIPointer(KO, pO, XO, eO, lO) : this._gl.vertexAttribPointer(KO, pO, XO, bK, eO, lO))
      }
      _bindIndexBufferWithCache(OO) {
        null != OO && this._cachedIndexBuffer !== OO && (this._cachedIndexBuffer = OO, this.bindIndexBuffer(OO), this._uintIndicesCurrentlySet = OO.is32Bits)
      }
      _bindVertexBuffersAttributes(OO, KO, pO) {
        const XO = KO.getAttributesNames();
        this._vaoRecordInProgress || this._unbindVertexArrayObject(), this.unbindAllAttributes();
        for (let bK = 0; bK < XO.length; bK++) {
          const eO = KO.getAttributeLocation(bK);
          if (eO >= 0) {
            const KO = XO[bK];
            let lO = null;
            if (pO && (lO = pO[KO]), lO || (lO = OO[KO]), !lO) continue;
            this._gl.enableVertexAttribArray(eO), this._vaoRecordInProgress || (this._vertexAttribArraysEnabled[eO] = !0);
            const vK = lO.getBuffer();
            vK && (this._vertexAttribPointer(vK, eO, lO.getSize(), lO.type, lO.normalized, lO.byteStride, lO.byteOffset), lO.getIsInstanced() && (this._gl.vertexAttribDivisor(eO, lO.getInstanceDivisor()), this._vaoRecordInProgress || (this._currentInstanceLocations.push(eO), this._currentInstanceBuffers.push(vK))))
          }
        }
      }
      recordVertexArrayObject(OO, KO, pO, XO) {
        const bK = this._gl.createVertexArray();
        if (!bK) throw new Error("Unable to create VAO");
        return this._vaoRecordInProgress = !0, this._gl.bindVertexArray(bK), this._mustWipeVertexAttributes = !0, this._bindVertexBuffersAttributes(OO, pO, XO), this.bindIndexBuffer(KO), this._vaoRecordInProgress = !1, this._gl.bindVertexArray(null), bK
      }
      bindVertexArrayObject(OO, KO) {
        this._cachedVertexArrayObject !== OO && (this._cachedVertexArrayObject = OO, this._gl.bindVertexArray(OO), this._cachedVertexBuffers = null, this._cachedIndexBuffer = null, this._uintIndicesCurrentlySet = null != KO && KO.is32Bits, this._mustWipeVertexAttributes = !0)
      }
      bindBuffersDirectly(OO, KO, pO, XO, bK) {
        if (this._cachedVertexBuffers !== OO || this._cachedEffectForVertexBuffers !== bK) {
          this._cachedVertexBuffers = OO, this._cachedEffectForVertexBuffers = bK;
          const KO = bK.getAttributesCount();
          this._unbindVertexArrayObject(), this.unbindAllAttributes();
          let eO = 0;
          for (let lO = 0; lO < KO; lO++)
            if (lO < pO.length) {
              const KO = bK.getAttributeLocation(lO);
              KO >= 0 && (this._gl.enableVertexAttribArray(KO), this._vertexAttribArraysEnabled[KO] = !0, this._vertexAttribPointer(OO, KO, pO[lO], this._gl.FLOAT, !1, XO, eO)), eO += 4 * pO[lO]
            }
        }
        this._bindIndexBufferWithCache(KO)
      }
      _unbindVertexArrayObject() {
        this._cachedVertexArrayObject && (this._cachedVertexArrayObject = null, this._gl.bindVertexArray(null))
      }
      bindBuffers(OO, KO, pO, XO) {
        this._cachedVertexBuffers === OO && this._cachedEffectForVertexBuffers === pO || (this._cachedVertexBuffers = OO, this._cachedEffectForVertexBuffers = pO, this._bindVertexBuffersAttributes(OO, pO, XO)), this._bindIndexBufferWithCache(KO)
      }
      unbindInstanceAttributes() {
        let OO;
        for (let KO = 0, pO = this._currentInstanceLocations.length; KO < pO; KO++) {
          const pO = this._currentInstanceBuffers[KO];
          OO != pO && pO.references && (OO = pO, this.bindArrayBuffer(pO));
          const XO = this._currentInstanceLocations[KO];
          this._gl.vertexAttribDivisor(XO, 0)
        }
        this._currentInstanceBuffers.length = 0, this._currentInstanceLocations.length = 0
      }
      releaseVertexArrayObject(OO) {
        this._gl.deleteVertexArray(OO)
      }
      _releaseBuffer(OO) {
        return OO.references--, 0 === OO.references && (this._deleteBuffer(OO), !0)
      }
      _deleteBuffer(OO) {
        this._gl.deleteBuffer(OO.underlyingResource)
      }
      updateAndBindInstancesBuffer(OO, KO, pO) {
        if (this.bindArrayBuffer(OO), KO && this._gl.bufferSubData(this._gl.ARRAY_BUFFER, 0, KO), void 0 !== pO[0].index) this.bindInstancesBuffer(OO, pO, !0);
        else
          for (let XO = 0; XO < 4; XO++) {
            const KO = pO[XO];
            this._vertexAttribArraysEnabled[KO] || (this._gl.enableVertexAttribArray(KO), this._vertexAttribArraysEnabled[KO] = !0), this._vertexAttribPointer(OO, KO, 4, this._gl.FLOAT, !1, 64, 16 * XO), this._gl.vertexAttribDivisor(KO, 1), this._currentInstanceLocations.push(KO), this._currentInstanceBuffers.push(OO)
          }
      }
      bindInstancesBuffer(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        this.bindArrayBuffer(OO);
        let XO = 0;
        if (pO)
          for (let bK = 0; bK < KO.length; bK++) {
            XO += 4 * KO[bK].attributeSize
          }
        for (let bK = 0; bK < KO.length; bK++) {
          const pO = KO[bK];
          void 0 === pO.index && (pO.index = this._currentEffect.getAttributeLocationByName(pO.attributeName)), pO.index < 0 || (this._vertexAttribArraysEnabled[pO.index] || (this._gl.enableVertexAttribArray(pO.index), this._vertexAttribArraysEnabled[pO.index] = !0), this._vertexAttribPointer(OO, pO.index, pO.attributeSize, pO.attributeType || this._gl.FLOAT, pO.normalized || !1, XO, pO.offset), this._gl.vertexAttribDivisor(pO.index, void 0 === pO.divisor ? 1 : pO.divisor), this._currentInstanceLocations.push(pO.index), this._currentInstanceBuffers.push(OO))
        }
      }
      disableInstanceAttributeByName(OO) {
        if (!this._currentEffect) return;
        const KO = this._currentEffect.getAttributeLocationByName(OO);
        this.disableInstanceAttribute(KO)
      }
      disableInstanceAttribute(OO) {
        let KO, pO = !1;
        for (; - 1 !== (KO = this._currentInstanceLocations.indexOf(OO));) this._currentInstanceLocations.splice(KO, 1), this._currentInstanceBuffers.splice(KO, 1), pO = !0;
        pO && (this._gl.vertexAttribDivisor(OO, 0), this.disableAttributeByIndex(OO))
      }
      disableAttributeByIndex(OO) {
        this._gl.disableVertexAttribArray(OO), this._vertexAttribArraysEnabled[OO] = !1, this._currentBufferPointers[OO].active = !1
      }
      draw(OO, KO, pO, XO) {
        this.drawElementsType(OO ? 0 : 1, KO, pO, XO)
      }
      drawPointClouds(OO, KO, pO) {
        this.drawArraysType(2, OO, KO, pO)
      }
      drawUnIndexed(OO, KO, pO, XO) {
        this.drawArraysType(OO ? 0 : 1, KO, pO, XO)
      }
      drawElementsType(OO, KO, pO, XO) {
        this.applyStates(), this._reportDrawCall();
        const bK = this._drawMode(OO),
          eO = this._uintIndicesCurrentlySet ? this._gl.UNSIGNED_INT : this._gl.UNSIGNED_SHORT,
          lO = this._uintIndicesCurrentlySet ? 4 : 2;
        XO ? this._gl.drawElementsInstanced(bK, pO, eO, KO * lO, XO) : this._gl.drawElements(bK, pO, eO, KO * lO)
      }
      drawArraysType(OO, KO, pO, XO) {
        this.applyStates(), this._reportDrawCall();
        const bK = this._drawMode(OO);
        XO ? this._gl.drawArraysInstanced(bK, KO, pO, XO) : this._gl.drawArrays(bK, KO, pO)
      }
      _drawMode(OO) {
        switch (OO) {
          case 0:
          default:
            return this._gl.TRIANGLES;
          case 2:
          case 3:
            return this._gl.POINTS;
          case 1:
          case 4:
            return this._gl.LINES;
          case 5:
            return this._gl.LINE_LOOP;
          case 6:
            return this._gl.LINE_STRIP;
          case 7:
            return this._gl.TRIANGLE_STRIP;
          case 8:
            return this._gl.TRIANGLE_FAN
        }
      }
      _releaseEffect(OO) {
        this._compiledEffects[OO._key] && delete this._compiledEffects[OO._key];
        const KO = OO.getPipelineContext();
        KO && this._deletePipelineContext(KO)
      }
      _deletePipelineContext(OO) {
        const KO = OO;
        KO && KO.program && (KO.program.__SPECTOR_rebuildProgram = null, (0, QO.m)(KO), this._gl && (this._currentProgram === KO.program && this._setProgram(null), this._gl.deleteProgram(KO.program)))
      }
      _getGlobalDefines(OO) {
        return (0, LO.j)(OO, this.isNDCHalfZRange, this.BhO, this.useExactSrgbConversions)
      }
      createEffect(OO, KO, pO, eO, lO, vK, CO, hO, DO) {
        let MO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0,
          aK = arguments.length > 10 ? arguments[10] : void 0;
        const oO = "string" === typeof OO ? OO : OO.vertexToken || OO.vertexSource || OO.vertexElement || OO.vertex,
          FO = "string" === typeof OO ? OO : OO.fragmentToken || OO.fragmentSource || OO.fragmentElement || OO.fragment,
          VO = this._getGlobalDefines(),
          LO = void 0 !== KO.attributes;
        let QO = lO ?? KO.defines ?? "";
        VO && (QO += VO);
        const zK = oO + "+" + FO + "@" + QO;
        if (this._compiledEffects[zK]) {
          const OO = this._compiledEffects[zK];
          return CO && OO.isReady() && CO(OO), OO._refCount++, OO
        }
        this._gl && (0, bK.A)(this._gl);
        const AO = new XO.e(OO, KO, LO ? this : pO, eO, this, lO, vK, CO, hO, DO, zK, KO.shaderLanguage ?? MO, KO.extraInitializationsAsync ?? aK);
        return this._compiledEffects[zK] = AO, AO
      }
      _getShaderSource(OO) {
        return this._gl.getShaderSource(OO)
      }
      createRawShaderProgram(OO, KO, pO, XO) {
        let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
        const lO = (0, bK.A)(this._gl);
        return lO._contextWasLost = this._contextWasLost, lO.validateShaderPrograms = this.validateShaderPrograms, (0, bK.s)(OO, KO, pO, XO || this._gl, eO)
      }
      createShaderProgram(OO, KO, pO, XO, eO) {
        let lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null;
        const vK = (0, bK.A)(this._gl);
        return vK._contextWasLost = this._contextWasLost, vK.validateShaderPrograms = this.validateShaderPrograms, (0, bK.v)(OO, KO, pO, XO, eO || this._gl, lO)
      }
      inlineShaderCode(OO) {
        return OO
      }
      createPipelineContext(OO) {
        if (this._gl) {
          (0, bK.A)(this._gl).parallelShaderCompile = this._caps.parallelShaderCompile
        }
        const KO = (0, bK.q)(this._gl, OO);
        return KO.engine = this, KO
      }
      createMaterialContext() {}
      createDrawContext() {}
      _finalizePipelineContext(OO) {
        return (0, bK.g)(OO, this._gl, this.validateShaderPrograms)
      }
      _preparePipelineContextAsync(OO, KO, pO, XO, eO, lO, vK, CO, hO, DO, MO) {
        const aK = (0, bK.A)(this._gl);
        return aK._contextWasLost = this._contextWasLost, aK.validateShaderPrograms = this.validateShaderPrograms, aK._createShaderProgramInjection = this._createShaderProgram.bind(this), aK.createRawShaderProgramInjection = this.createRawShaderProgram.bind(this), aK.createShaderProgramInjection = this.createShaderProgram.bind(this), aK.loadFileInjection = this._loadFile.bind(this), (0, bK.l)(OO, KO, pO, XO, eO, lO, vK, CO, hO, DO, MO)
      }
      _createShaderProgram(OO, KO, pO, XO) {
        let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
        return (0, bK.b)(OO, KO, pO, XO, eO)
      }
      _isRenderingStateCompiled(OO) {
        return !this._isDisposed && (0, bK.h)(OO, this._gl, this.validateShaderPrograms)
      }
      _executeWhenRenderingStateIsCompiled(OO, KO) {
        (0, bK.c)(OO, KO)
      }
      getUniforms(OO, KO) {
        const pO = new Array,
          XO = OO;
        for (let bK = 0; bK < KO.length; bK++) pO.push(this._gl.getUniformLocation(XO.program, KO[bK]));
        return pO
      }
      getAttributes(OO, KO) {
        const pO = [],
          XO = OO;
        for (let eO = 0; eO < KO.length; eO++) try {
          pO.push(this._gl.getAttribLocation(XO.program, KO[eO]))
        } catch (bK) {
          pO.push(-1)
        }
        return pO
      }
      enableEffect(OO) {
        (OO = null !== OO && (0, lO.e)(OO) ? OO.effect : OO) && OO !== this._currentEffect && (this._stencilStateComposer.stencilMaterial = void 0, this.bindSamplers(OO), this._currentEffect = OO, OO.onBind && OO.onBind(OO), OO._onBindObservable && OO._onBindObservable.notifyObservers(OO))
      }
      setInt(OO, KO) {
        return !!OO && (this._gl.uniform1i(OO, KO), !0)
      }
      setInt2(OO, KO, pO) {
        return !!OO && (this._gl.uniform2i(OO, KO, pO), !0)
      }
      setInt3(OO, KO, pO, XO) {
        return !!OO && (this._gl.uniform3i(OO, KO, pO, XO), !0)
      }
      setInt4(OO, KO, pO, XO, bK) {
        return !!OO && (this._gl.uniform4i(OO, KO, pO, XO, bK), !0)
      }
      setIntArray(OO, KO) {
        return !!OO && (this._gl.uniform1iv(OO, KO), !0)
      }
      setIntArray2(OO, KO) {
        return !(!OO || KO.length % 2 !== 0) && (this._gl.uniform2iv(OO, KO), !0)
      }
      setIntArray3(OO, KO) {
        return !(!OO || KO.length % 3 !== 0) && (this._gl.uniform3iv(OO, KO), !0)
      }
      setIntArray4(OO, KO) {
        return !(!OO || KO.length % 4 !== 0) && (this._gl.uniform4iv(OO, KO), !0)
      }
      setUInt(OO, KO) {
        return !!OO && (this._gl.uniform1ui(OO, KO), !0)
      }
      setUInt2(OO, KO, pO) {
        return !!OO && (this._gl.uniform2ui(OO, KO, pO), !0)
      }
      setUInt3(OO, KO, pO, XO) {
        return !!OO && (this._gl.uniform3ui(OO, KO, pO, XO), !0)
      }
      setUInt4(OO, KO, pO, XO, bK) {
        return !!OO && (this._gl.uniform4ui(OO, KO, pO, XO, bK), !0)
      }
      setUIntArray(OO, KO) {
        return !!OO && (this._gl.uniform1uiv(OO, KO), !0)
      }
      setUIntArray2(OO, KO) {
        return !(!OO || KO.length % 2 !== 0) && (this._gl.uniform2uiv(OO, KO), !0)
      }
      setUIntArray3(OO, KO) {
        return !(!OO || KO.length % 3 !== 0) && (this._gl.uniform3uiv(OO, KO), !0)
      }
      setUIntArray4(OO, KO) {
        return !(!OO || KO.length % 4 !== 0) && (this._gl.uniform4uiv(OO, KO), !0)
      }
      setArray(OO, KO) {
        return !!OO && (!(KO.length < 1) && (this._gl.uniform1fv(OO, KO), !0))
      }
      setArray2(OO, KO) {
        return !(!OO || KO.length % 2 !== 0) && (this._gl.uniform2fv(OO, KO), !0)
      }
      setArray3(OO, KO) {
        return !(!OO || KO.length % 3 !== 0) && (this._gl.uniform3fv(OO, KO), !0)
      }
      setArray4(OO, KO) {
        return !(!OO || KO.length % 4 !== 0) && (this._gl.uniform4fv(OO, KO), !0)
      }
      setMatrices(OO, KO) {
        return !!OO && (this._gl.uniformMatrix4fv(OO, !1, KO), !0)
      }
      setMatrix3x3(OO, KO) {
        return !!OO && (this._gl.uniformMatrix3fv(OO, !1, KO), !0)
      }
      setMatrix2x2(OO, KO) {
        return !!OO && (this._gl.uniformMatrix2fv(OO, !1, KO), !0)
      }
      setFloat(OO, KO) {
        return !!OO && (this._gl.uniform1f(OO, KO), !0)
      }
      setFloat2(OO, KO, pO) {
        return !!OO && (this._gl.uniform2f(OO, KO, pO), !0)
      }
      setFloat3(OO, KO, pO, XO) {
        return !!OO && (this._gl.uniform3f(OO, KO, pO, XO), !0)
      }
      setFloat4(OO, KO, pO, XO, bK) {
        return !!OO && (this._gl.uniform4f(OO, KO, pO, XO, bK), !0)
      }
      _applyColorWriteState() {
        if (this._colorWriteChanged) {
          this._colorWriteChanged = !1;
          const OO = this._colorWrite;
          this._gl.colorMask(OO, OO, OO, OO)
        }
      }
      applyStates() {
        this._depthCullingState.apply(this._gl), this._stencilStateComposer.apply(this._gl), this._alphaState.apply(this._gl, this._currentRenderTarget && this._currentRenderTarget.textures ? this._currentRenderTarget.textures.length : 1, this._integerMRTAttachmentsMask), this._applyColorWriteState()
      }
      wipeCaches(OO) {
        this.preventCacheWipeBetweenFrames && !OO || (this._currentEffect = null, this._viewportCached.x = 0, this._viewportCached.y = 0, this._viewportCached.z = 0, this._viewportCached.w = 0, this._unbindVertexArrayObject(), OO && (this._currentProgram = null, this.resetTextureCache(), this._stencilStateComposer.reset(), this._depthCullingState.reset(), this._depthCullingState.depthFunc = this._gl.LEQUAL, this._alphaState.reset(), this._resetAlphaMode(), this._colorWrite = !0, this._colorWriteChanged = !0, this._unpackFlipYCached = null, this._gl.pixelStorei(this._gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, this._gl.NONE), this._gl.pixelStorei(this._gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, 0), this._mustWipeVertexAttributes = !0, this.unbindAllAttributes()), this._resetVertexBufferBinding(), this._cachedIndexBuffer = null, this._cachedEffectForVertexBuffers = null, this.bindIndexBuffer(null))
      }
      _getSamplingParameters(OO, KO) {
        const pO = this._gl;
        let XO = pO.NEAREST,
          bK = pO.NEAREST,
          eO = !1;
        switch (OO) {
          case 11:
            XO = pO.LINEAR, bK = KO ? pO.LINEAR_MIPMAP_NEAREST : pO.LINEAR;
            break;
          case 3:
            XO = pO.LINEAR, eO = !0, bK = KO ? pO.LINEAR_MIPMAP_LINEAR : pO.LINEAR;
            break;
          case 8:
            eO = !0, XO = pO.NEAREST, bK = KO ? pO.NEAREST_MIPMAP_LINEAR : pO.NEAREST;
            break;
          case 4:
            XO = pO.NEAREST, bK = KO ? pO.NEAREST_MIPMAP_NEAREST : pO.NEAREST;
            break;
          case 5:
            XO = pO.NEAREST, bK = KO ? pO.LINEAR_MIPMAP_NEAREST : pO.LINEAR;
            break;
          case 6:
            eO = !0, XO = pO.NEAREST, bK = KO ? pO.LINEAR_MIPMAP_LINEAR : pO.LINEAR;
            break;
          case 7:
            XO = pO.NEAREST, bK = pO.LINEAR;
            break;
          case 1:
            XO = pO.NEAREST, bK = pO.NEAREST;
            break;
          case 9:
            XO = pO.LINEAR, bK = KO ? pO.NEAREST_MIPMAP_NEAREST : pO.NEAREST;
            break;
          case 10:
            eO = !0, XO = pO.LINEAR, bK = KO ? pO.NEAREST_MIPMAP_LINEAR : pO.NEAREST;
            break;
          case 2:
            XO = pO.LINEAR, bK = pO.LINEAR;
            break;
          case 12:
            XO = pO.LINEAR, bK = pO.NEAREST
        }
        return {
          min: bK,
          mag: XO,
          hasMipMaps: eO
        }
      }
      _createTexture() {
        const OO = this._gl.createTexture();
        if (!OO) throw new Error("Unable to create texture");
        return OO
      }
      _createHardwareTexture() {
        return new FO.c(this._createTexture(), this._gl)
      }
      _createInternalTexture(OO, KO) {
        let pO, XO, bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
          eO = !1,
          lO = 0,
          CO = 3,
          hO = 5,
          DO = !1,
          MO = 1,
          aK = !1,
          oO = 0,
          FO = !1;
        void 0 !== KO && "object" === typeof KO ? (pO = !!KO.generateMipMaps, eO = !!KO.createMipMaps, lO = void 0 === KO.type ? 0 : KO.type, CO = void 0 === KO.samplingMode ? 3 : KO.samplingMode, hO = void 0 === KO.format ? 5 : KO.format, DO = void 0 !== KO.useSRGBBuffer && KO.useSRGBBuffer, MO = KO.samples ?? 1, XO = KO.label, aK = !!KO.createMSAATexture, oO = KO.comparisonFunction || 0, FO = !!KO.isCube) : pO = !!KO, DO && (DO = this._caps.supportSRGBBuffers && (this.ye > 1 || this.isWebGPU)), (1 !== lO || this._caps.textureFloatLinearFiltering) && (2 !== lO || this._caps.textureHalfFloatLinearFiltering) || (CO = 1), 1 !== lO || this._caps.textureFloat || (lO = 0, vK.b.Warn("Float textures are not supported. Type forced to TEXTURETYPE_UNSIGNED_BYTE"));
        const LO = (0, zK.g)(hO),
          QO = (0, zK.d)(hO),
          AO = this._gl,
          fO = new VO.e(this, bK),
          dO = OO.width || OO,
          TO = OO.height || OO,
          NO = OO.depth || 0,
          IO = OO.layers || 0,
          yK = this._getSamplingParameters(CO, (pO || eO) && !LO),
          gK = 0 !== IO ? AO.TEXTURE_2D_ARRAY : 0 !== NO ? AO.TEXTURE_3D : FO ? AO.TEXTURE_CUBE_MAP : AO.TEXTURE_2D,
          uO = LO ? this._getInternalFormatFromDepthTextureFormat(hO, !0, QO) : this._getRGBABufferInternalSizedFormat(lO, hO, DO),
          EO = LO ? QO ? AO.DEPTH_STENCIL : AO.DEPTH_COMPONENT : this._getInternalFormat(hO),
          jK = LO ? this._getWebGLTextureTypeFromDepthTextureFormat(hO) : this._getWebGLTextureType(lO);
        if (this._bindTextureDirectly(gK, fO), 0 !== IO) fO.is2DArray = !0, AO.texImage3D(gK, 0, uO, dO, TO, IO, 0, EO, jK, null);
        else if (0 !== NO) fO.is3D = !0, AO.texImage3D(gK, 0, uO, dO, TO, NO, 0, EO, jK, null);
        else if (FO) {
          fO.isCube = !0;
          for (let OO = 0; OO < 6; OO++) AO.texImage2D(AO.TEXTURE_CUBE_MAP_POSITIVE_X + OO, 0, uO, dO, TO, 0, EO, jK, null)
        } else AO.texImage2D(gK, 0, uO, dO, TO, 0, EO, jK, null);
        if (AO.texParameteri(gK, AO.TEXTURE_MAG_FILTER, yK.mag), AO.texParameteri(gK, AO.TEXTURE_MIN_FILTER, yK.min), AO.texParameteri(gK, AO.TEXTURE_WRAP_S, AO.CLAMP_TO_EDGE), AO.texParameteri(gK, AO.TEXTURE_WRAP_T, AO.CLAMP_TO_EDGE), LO && this.ye > 1 && (0 === oO ? (AO.texParameteri(gK, AO.TEXTURE_COMPARE_FUNC, 515), AO.texParameteri(gK, AO.TEXTURE_COMPARE_MODE, AO.NONE)) : (AO.texParameteri(gK, AO.TEXTURE_COMPARE_FUNC, oO), AO.texParameteri(gK, AO.TEXTURE_COMPARE_MODE, AO.COMPARE_REF_TO_TEXTURE))), (pO || eO) && this._gl.generateMipmap(gK), this._bindTextureDirectly(gK, null), fO._useSRGBBuffer = DO, fO.baseWidth = dO, fO.baseHeight = TO, fO.width = dO, fO.height = TO, fO.depth = IO || NO, fO.isReady = !0, fO.samples = MO, fO.generateMipMaps = pO, fO.samplingMode = CO, fO.type = lO, fO.format = hO, fO.label = XO, fO.comparisonFunction = oO, this._internalTexturesCache.push(fO), aK) {
          let OO;
          if (OO = (0, zK.g)(fO.format) ? this._setupFramebufferDepthAttachments((0, zK.d)(fO.format), 19 !== fO.format, fO.width, fO.height, MO, fO.format, !0) : this._createRenderBuffer(fO.width, fO.height, MO, -1, this._getRGBABufferInternalSizedFormat(fO.type, fO.format, fO._useSRGBBuffer), -1), !OO) throw new Error("Unable to create render buffer");
          fO._autoMSAAManagement = !0;
          let KO = fO._hardwareTexture;
          KO || (KO = fO._hardwareTexture = this._createHardwareTexture()), KO.addMSAARenderBuffer(OO)
        }
        return fO
      }
      _getUseSRGBBuffer(OO, KO) {
        return OO && this._caps.supportSRGBBuffers && (this.ye > 1 || KO)
      }
      createTexture(OO, KO, pO, XO) {
        var bK = this;
        let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 3,
          lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
          vK = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null,
          CO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
          hO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : null,
          DO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : null,
          MO = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : null,
          aK = arguments.length > 11 ? arguments[11] : void 0,
          oO = arguments.length > 12 ? arguments[12] : void 0,
          FO = arguments.length > 13 ? arguments[13] : void 0,
          LO = arguments.length > 14 ? arguments[14] : void 0;
        return this._createTextureBase(OO, KO, pO, XO, eO, lO, vK, (function() {
          for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
          return bK._prepareWebGLTexture(...KO, DO)
        }), ((OO, KO, pO, bK, eO, lO) => {
          const vK = this._gl,
            CO = pO.width === OO && pO.height === KO;
          eO._creationFlags = FO ?? 0;
          const hO = this._getTexImageParametersForCreateTexture(eO.format, eO._useSRGBBuffer);
          if (CO) return vK.texImage2D(vK.TEXTURE_2D, 0, hO.internalFormat, hO.format, hO.type, pO), !1;
          const DO = this._caps.maxTextureSize;
          if (pO.width > DO || pO.height > DO || !this._supportsHardwareTextureRescaling) return this._prepareWorkingCanvas(), !(!this._workingCanvas || !this._workingContext) && (this._workingCanvas.width = OO, this._workingCanvas.height = KO, this._workingContext.drawImage(pO, 0, 0, pO.width, pO.height, 0, 0, OO, KO), vK.texImage2D(vK.TEXTURE_2D, 0, hO.internalFormat, hO.format, hO.type, this._workingCanvas), eO.width = OO, eO.height = KO, !1);
          {
            const OO = new VO.e(this, 2);
            this._bindTextureDirectly(vK.TEXTURE_2D, OO, !0), vK.texImage2D(vK.TEXTURE_2D, 0, hO.internalFormat, hO.format, hO.type, pO), this._rescaleTexture(OO, eO, XO, hO.format, (() => {
              this._releaseTexture(OO), this._bindTextureDirectly(vK.TEXTURE_2D, eO, !0), lO()
            }))
          }
          return !0
        }), CO, hO, DO, MO, aK, oO, LO)
      }
      _getTexImageParametersForCreateTexture(OO, KO) {
        let pO, XO;
        return 1 === this.ye ? (pO = this._getInternalFormat(OO, KO), XO = pO) : (pO = this._getInternalFormat(OO, !1), XO = this._getRGBABufferInternalSizedFormat(0, OO, KO)), {
          internalFormat: XO,
          format: pO,
          type: this._gl.UNSIGNED_BYTE
        }
      }
      _rescaleTexture(OO, KO, pO, XO, bK) {}
      _unpackFlipY(OO) {
        this._unpackFlipYCached !== OO && (this._gl.pixelStorei(this._gl.UNPACK_FLIP_Y_WEBGL, OO ? 1 : 0), this.enableUnpackFlipYCached && (this._unpackFlipYCached = OO))
      }
      _getUnpackAlignement() {
        return this._gl.getParameter(this._gl.UNPACK_ALIGNMENT)
      }
      _getTextureTarget(OO) {
        return OO.isCube ? this._gl.TEXTURE_CUBE_MAP : OO.is3D ? this._gl.TEXTURE_3D : OO.is2DArray || OO.isMultiview ? this._gl.TEXTURE_2D_ARRAY : this._gl.TEXTURE_2D
      }
      updateTextureSamplingMode(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = this._getTextureTarget(KO),
          bK = this._getSamplingParameters(OO, KO.useMipMaps || pO);
        this._setTextureParameterInteger(XO, this._gl.TEXTURE_MAG_FILTER, bK.mag, KO), this._setTextureParameterInteger(XO, this._gl.TEXTURE_MIN_FILTER, bK.min), pO && bK.hasMipMaps && (KO.generateMipMaps = !0, this._gl.generateMipmap(XO)), this._bindTextureDirectly(XO, null), KO.samplingMode = OO
      }
      updateTextureDimensions(OO, KO, pO) {}
      updateTextureWrappingMode(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        const bK = this._getTextureTarget(OO);
        null !== KO && (this._setTextureParameterInteger(bK, this._gl.TEXTURE_WRAP_S, this._getTextureWrapMode(KO), OO), OO._cachedWrapU = KO), null !== pO && (this._setTextureParameterInteger(bK, this._gl.TEXTURE_WRAP_T, this._getTextureWrapMode(pO), OO), OO._cachedWrapV = pO), (OO.is2DArray || OO.is3D) && null !== XO && (this._setTextureParameterInteger(bK, this._gl.TEXTURE_WRAP_R, this._getTextureWrapMode(XO), OO), OO._cachedWrapR = XO), this._bindTextureDirectly(bK, null)
      }
      _uploadCompressedDataToTextureDirectly(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
          lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0;
        const vK = this._gl;
        let CO = vK.TEXTURE_2D;
        if (OO.isCube && (CO = vK.TEXTURE_CUBE_MAP_POSITIVE_X + eO), OO._useSRGBBuffer) switch (KO) {
          case 37492:
          case 36196:
            this._caps.etc2 ? KO = vK.COMPRESSED_SRGB8_ETC2 : OO._useSRGBBuffer = !1;
            break;
          case 37496:
            this._caps.etc2 ? KO = vK.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC : OO._useSRGBBuffer = !1;
            break;
          case 36492:
            KO = vK.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT;
            break;
          case 37808:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR;
            break;
          case 37809:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR;
            break;
          case 37810:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR;
            break;
          case 37811:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR;
            break;
          case 37812:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR;
            break;
          case 37813:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR;
            break;
          case 37814:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR;
            break;
          case 37815:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR;
            break;
          case 37816:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR;
            break;
          case 37817:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR;
            break;
          case 37818:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR;
            break;
          case 37819:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR;
            break;
          case 37820:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR;
            break;
          case 37821:
            KO = vK.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR;
            break;
          case 33776:
            this._caps.s3tc_srgb ? KO = vK.COMPRESSED_SRGB_S3TC_DXT1_EXT : OO._useSRGBBuffer = !1;
            break;
          case 33777:
            this._caps.s3tc_srgb ? KO = vK.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT : OO._useSRGBBuffer = !1;
            break;
          case 33779:
            this._caps.s3tc_srgb ? KO = vK.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT : OO._useSRGBBuffer = !1;
            break;
          default:
            OO._useSRGBBuffer = !1
        }
        if (OO.generateMipMaps) {
          const eO = OO._hardwareTexture;
          eO.memoryAllocated || (vK.texStorage2D(OO.isCube ? vK.TEXTURE_CUBE_MAP : vK.TEXTURE_2D, Math.floor(Math.log2(Math.max(pO, XO))) + 1, KO, OO.width, OO.height), eO.memoryAllocated = !0), this._gl.compressedTexSubImage2D(CO, lO, 0, 0, pO, XO, KO, bK)
        } else this._gl.compressedTexImage2D(CO, lO, KO, pO, XO, 0, bK)
      }
      _uploadDataToTextureDirectly(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
          bK = arguments.length > 4 ? arguments[4] : void 0,
          eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
        const lO = this._gl,
          vK = this._getWebGLTextureType(OO.type),
          CO = this._getInternalFormat(OO.format),
          hO = void 0 === bK ? this._getRGBABufferInternalSizedFormat(OO.type, OO.format, OO._useSRGBBuffer) : this._getInternalFormat(bK, OO._useSRGBBuffer);
        this._unpackFlipY(OO.invertY);
        let DO = lO.TEXTURE_2D;
        OO.isCube && (DO = lO.TEXTURE_CUBE_MAP_POSITIVE_X + pO);
        const MO = Math.round(Math.log(OO.width) * Math.LOG2E),
          aK = Math.round(Math.log(OO.height) * Math.LOG2E),
          oO = eO ? OO.width : Math.pow(2, Math.max(MO - XO, 0)),
          FO = eO ? OO.height : Math.pow(2, Math.max(aK - XO, 0));
        lO.texImage2D(DO, XO, hO, oO, FO, 0, CO, vK, KO)
      }
      updateTextureData(OO, KO, pO, XO, bK, eO) {
        let lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0,
          vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0,
          CO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8];
        const hO = this._gl,
          DO = this._getWebGLTextureType(OO.type),
          MO = this._getInternalFormat(OO.format);
        this._unpackFlipY(OO.invertY);
        let aK = hO.TEXTURE_2D,
          oO = hO.TEXTURE_2D;
        OO.isCube && (oO = hO.TEXTURE_CUBE_MAP_POSITIVE_X + lO, aK = hO.TEXTURE_CUBE_MAP), this._bindTextureDirectly(aK, OO, !0), hO.texSubImage2D(oO, vK, pO, XO, bK, eO, MO, DO, KO), CO && this._gl.generateMipmap(oO), this._bindTextureDirectly(aK, null)
      }
      _uploadArrayBufferViewToTexture(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        const bK = this._gl,
          eO = OO.isCube ? bK.TEXTURE_CUBE_MAP : bK.TEXTURE_2D;
        this._bindTextureDirectly(eO, OO, !0), this._uploadDataToTextureDirectly(OO, KO, pO, XO), this._bindTextureDirectly(eO, null, !0)
      }
      _prepareWebGLTextureContinuation(OO, KO, pO, XO, bK) {
        const eO = this._gl;
        if (!eO) return;
        const lO = this._getSamplingParameters(bK, !pO);
        eO.texParameteri(eO.TEXTURE_2D, eO.TEXTURE_MAG_FILTER, lO.mag), eO.texParameteri(eO.TEXTURE_2D, eO.TEXTURE_MIN_FILTER, lO.min), pO || XO || eO.generateMipmap(eO.TEXTURE_2D), this._bindTextureDirectly(eO.TEXTURE_2D, null), KO && KO.removePendingData(OO), OO.onLoadedObservable.notifyObservers(OO), OO.onLoadedObservable.clear()
      }
      _prepareWebGLTexture(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
        const DO = this.getCaps().maxTextureSize,
          MO = Math.min(DO, this.needPOTTextures ? (0, oO.i)(XO.width, DO) : XO.width),
          aK = Math.min(DO, this.needPOTTextures ? (0, oO.i)(XO.height, DO) : XO.height),
          FO = this._gl;
        FO && (OO._hardwareTexture ? (this._bindTextureDirectly(FO.TEXTURE_2D, OO, !0), this._unpackFlipY(void 0 === bK || !!bK), OO.baseWidth = XO.width, OO.baseHeight = XO.height, OO.width = MO, OO.height = aK, OO.isReady = !0, OO.type = -1 !== OO.type ? OO.type : 0, OO.format = -1 !== OO.format ? OO.format : hO ?? (".jpg" !== KO || OO._useSRGBBuffer ? 5 : 4), vK(MO, aK, XO, KO, OO, (() => {
          this._prepareWebGLTextureContinuation(OO, pO, eO, lO, CO)
        })) || this._prepareWebGLTextureContinuation(OO, pO, eO, lO, CO)) : pO && pO.removePendingData(OO))
      }
      _getInternalFormatFromDepthTextureFormat(OO, KO, pO) {
        const XO = this._gl;
        if (!KO) return XO.STENCIL_INDEX8;
        let bK = pO ? XO.DEPTH_STENCIL : XO.DEPTH_COMPONENT;
        return this.ye > 1 ? 15 === OO ? bK = XO.DEPTH_COMPONENT16 : 16 === OO ? bK = XO.DEPTH_COMPONENT24 : 17 === OO || 13 === OO ? bK = pO ? XO.DEPTH24_STENCIL8 : XO.DEPTH_COMPONENT24 : 14 === OO ? bK = XO.DEPTH_COMPONENT32F : 18 === OO && (bK = pO ? XO.DEPTH32F_STENCIL8 : XO.DEPTH_COMPONENT32F) : bK = XO.DEPTH_COMPONENT16, bK
      }
      _getWebGLTextureTypeFromDepthTextureFormat(OO) {
        const KO = this._gl;
        let pO = KO.UNSIGNED_INT;
        return 15 === OO ? pO = KO.UNSIGNED_SHORT : 17 === OO || 13 === OO ? pO = KO.UNSIGNED_INT_24_8 : 14 === OO ? pO = KO.FLOAT : 18 === OO ? pO = KO.FLOAT_32_UNSIGNED_INT_24_8_REV : 19 === OO && (pO = KO.UNSIGNED_BYTE), pO
      }
      _setupFramebufferDepthAttachments(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
          eO = arguments.length > 5 ? arguments[5] : void 0,
          lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
        const vK = this._gl;
        eO = eO ?? (OO ? 13 : 14);
        const CO = this._getInternalFormatFromDepthTextureFormat(eO, KO, OO);
        return OO && KO ? this._createRenderBuffer(pO, XO, bK, vK.DEPTH_STENCIL, CO, lO ? -1 : vK.DEPTH_STENCIL_ATTACHMENT) : KO ? this._createRenderBuffer(pO, XO, bK, CO, CO, lO ? -1 : vK.DEPTH_ATTACHMENT) : OO ? this._createRenderBuffer(pO, XO, bK, CO, CO, lO ? -1 : vK.STENCIL_ATTACHMENT) : null
      }
      _createRenderBuffer(OO, KO, pO, XO, bK, eO) {
        let lO = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6];
        const vK = this._gl.createRenderbuffer();
        return this._updateRenderBuffer(vK, OO, KO, pO, XO, bK, eO, lO)
      }
      _updateRenderBuffer(OO, KO, pO, XO, bK, eO, lO) {
        let vK = !(arguments.length > 7 && void 0 !== arguments[7]) || arguments[7];
        const CO = this._gl;
        return CO.bindRenderbuffer(CO.RENDERBUFFER, OO), XO > 1 && CO.renderbufferStorageMultisample ? CO.renderbufferStorageMultisample(CO.RENDERBUFFER, XO, eO, KO, pO) : CO.renderbufferStorage(CO.RENDERBUFFER, bK, KO, pO), -1 !== lO && CO.framebufferRenderbuffer(CO.FRAMEBUFFER, lO, CO.RENDERBUFFER, OO), vK && CO.bindRenderbuffer(CO.RENDERBUFFER, null), OO
      }
      _releaseTexture(OO) {
        this._deleteTexture(OO._hardwareTexture), this.unbindAllTextures();
        const KO = this._internalTexturesCache.indexOf(OO); - 1 !== KO && this._internalTexturesCache.splice(KO, 1), OO._lodTextureHigh && OO._lodTextureHigh.dispose(), OO._lodTextureMid && OO._lodTextureMid.dispose(), OO._lodTextureLow && OO._lodTextureLow.dispose(), OO._irradianceTexture && OO._irradianceTexture.dispose()
      }
      _deleteTexture(OO) {
        OO?.release()
      }
      _setProgram(OO) {
        this._currentProgram !== OO && ((0, bK.p)(OO, this._gl), this._currentProgram = OO)
      }
      bindSamplers(OO) {
        const KO = OO.getPipelineContext();
        this._setProgram(KO.program);
        const pO = OO.getSamplers();
        for (let XO = 0; XO < pO.length; XO++) {
          const KO = OO.getUniform(pO[XO]);
          KO && (this._boundUniforms[XO] = KO)
        }
        this._currentEffect = null
      }
      _activateCurrentTexture() {
        this._currentTextureChannel !== this._activeChannel && (this._gl.activeTexture(this._gl.TEXTURE0 + this._activeChannel), this._currentTextureChannel = this._activeChannel)
      }
      _bindTextureDirectly(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          bK = !1;
        const eO = KO && KO._associatedChannel > -1;
        pO && eO && (this._activeChannel = KO._associatedChannel);
        if (this._boundTexturesCache[this._activeChannel] !== KO || XO) {
          if (this._activateCurrentTexture(), KO && KO.isMultiview) throw vK.b.Error(["_bindTextureDirectly called with a multiview texture!", OO, KO]), "_bindTextureDirectly called with a multiview texture!";
          this._gl.bindTexture(OO, KO?._hardwareTexture?.underlyingResource ?? null), this._boundTexturesCache[this._activeChannel] = KO, KO && (KO._associatedChannel = this._activeChannel)
        } else pO && (bK = !0, this._activateCurrentTexture());
        return eO && !pO && this._bindSamplerUniformToChannel(KO._associatedChannel, this._activeChannel), bK
      }
      _bindTexture(OO, KO, pO) {
        if (void 0 === OO) return;
        KO && (KO._associatedChannel = OO), this._activeChannel = OO;
        const XO = KO ? this._getTextureTarget(KO) : this._gl.TEXTURE_2D;
        this._bindTextureDirectly(XO, KO)
      }
      unbindAllTextures() {
        for (let OO = 0; OO < this._maxSimultaneousTextures; OO++) this._activeChannel = OO, this._bindTextureDirectly(this._gl.TEXTURE_2D, null), this._bindTextureDirectly(this._gl.TEXTURE_CUBE_MAP, null), this.ye > 1 && (this._bindTextureDirectly(this._gl.TEXTURE_3D, null), this._bindTextureDirectly(this._gl.TEXTURE_2D_ARRAY, null))
      }
      setTexture(OO, KO, pO, XO) {
        void 0 !== OO && (KO && (this._boundUniforms[OO] = KO), this._setTexture(OO, pO))
      }
      _bindSamplerUniformToChannel(OO, KO) {
        const pO = this._boundUniforms[OO];
        pO && pO._currentState !== KO && (this._gl.uniform1i(pO, KO), pO._currentState = KO)
      }
      _getTextureWrapMode(OO) {
        switch (OO) {
          case 1:
            return this._gl.REPEAT;
          case 0:
            return this._gl.CLAMP_TO_EDGE;
          case 2:
            return this._gl.MIRRORED_REPEAT
        }
        return this._gl.REPEAT
      }
      _setTexture(OO, KO) {
        let pO, XO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          bK = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        if (!KO) return null != this._boundTexturesCache[OO] && (this._activeChannel = OO, this._bindTextureDirectly(this._gl.TEXTURE_2D, null), this._bindTextureDirectly(this._gl.TEXTURE_CUBE_MAP, null), this.ye > 1 && (this._bindTextureDirectly(this._gl.TEXTURE_3D, null), this._bindTextureDirectly(this._gl.TEXTURE_2D_ARRAY, null))), !1;
        if (KO.video) {
          this._activeChannel = OO;
          const pO = KO.getInternalTexture();
          pO && (pO._associatedChannel = OO), KO.update()
        } else if (4 === KO.delayLoadState) return KO.delayLoad(), !1;
        pO = bK ? KO.depthStencilTexture : KO.isReady() ? KO.getInternalTexture() : KO.isCube ? this.emptyCubeTexture : KO.is3D ? this.emptyTexture3D : KO.is2DArray ? this.emptyTexture2DArray : this.emptyTexture, !XO && pO && (pO._associatedChannel = OO);
        let eO = !0;
        this._boundTexturesCache[OO] === pO && (XO || this._bindSamplerUniformToChannel(pO._associatedChannel, OO), eO = !1), this._activeChannel = OO;
        const lO = this._getTextureTarget(pO);
        if (eO && this._bindTextureDirectly(lO, pO, XO), pO && !pO.isMultiview) {
          if (pO.isCube && pO._cachedCoordinatesMode !== KO.coordinatesMode) {
            pO._cachedCoordinatesMode = KO.coordinatesMode;
            const OO = 3 !== KO.coordinatesMode && 5 !== KO.coordinatesMode ? 1 : 0;
            KO.wrapU = OO, KO.wrapV = OO
          }
          pO._cachedWrapU !== KO.wrapU && (pO._cachedWrapU = KO.wrapU, this._setTextureParameterInteger(lO, this._gl.TEXTURE_WRAP_S, this._getTextureWrapMode(KO.wrapU), pO)), pO._cachedWrapV !== KO.wrapV && (pO._cachedWrapV = KO.wrapV, this._setTextureParameterInteger(lO, this._gl.TEXTURE_WRAP_T, this._getTextureWrapMode(KO.wrapV), pO)), pO.is3D && pO._cachedWrapR !== KO.wrapR && (pO._cachedWrapR = KO.wrapR, this._setTextureParameterInteger(lO, this._gl.TEXTURE_WRAP_R, this._getTextureWrapMode(KO.wrapR), pO)), this._setAnisotropicLevel(lO, pO, KO.anisotropicFilteringLevel)
        }
        return !0
      }
      setTextureArray(OO, KO, pO, XO) {
        if (void 0 !== OO && KO) {
          this._textureUnits && this._textureUnits.length === pO.length || (this._textureUnits = new Int32Array(pO.length));
          for (let KO = 0; KO < pO.length; KO++) {
            const XO = pO[KO].getInternalTexture();
            XO ? (this._textureUnits[KO] = OO + KO, XO._associatedChannel = OO + KO) : this._textureUnits[KO] = -1
          }
          this._gl.uniform1iv(KO, this._textureUnits);
          for (let OO = 0; OO < pO.length; OO++) this._setTexture(this._textureUnits[OO], pO[OO], !0)
        }
      }
      _setAnisotropicLevel(OO, KO, pO) {
        const XO = this._caps.textureAnisotropicFilterExtension;
        11 !== KO.samplingMode && 3 !== KO.samplingMode && 2 !== KO.samplingMode && (pO = 1), XO && KO._cachedAnisotropicFilteringLevel !== pO && (this._setTextureParameterFloat(OO, XO.TEXTURE_MAX_ANISOTROPY_EXT, Math.min(pO, this._caps.maxAnisotropy), KO), KO._cachedAnisotropicFilteringLevel = pO)
      }
      _setTextureParameterFloat(OO, KO, pO, XO) {
        this._bindTextureDirectly(OO, XO, !0, !0), this._gl.texParameterf(OO, KO, pO)
      }
      _setTextureParameterInteger(OO, KO, pO, XO) {
        XO && this._bindTextureDirectly(OO, XO, !0, !0), this._gl.texParameteri(OO, KO, pO)
      }
      unbindAllAttributes() {
        if (this._mustWipeVertexAttributes) {
          this._mustWipeVertexAttributes = !1;
          for (let OO = 0; OO < this._caps.maxVertexAttribs; OO++) this.disableAttributeByIndex(OO)
        } else
          for (let OO = 0, KO = this._vertexAttribArraysEnabled.length; OO < KO; OO++) OO >= this._caps.maxVertexAttribs || !this._vertexAttribArraysEnabled[OO] || this.disableAttributeByIndex(OO)
      }
      releaseEffects() {
        this._compiledEffects = {}, this.onReleaseEffectsObservable.notifyObservers(this)
      }
      dispose() {
        (0, CO.n)() && this._renderingCanvas && (this._renderingCanvas.removeEventListener("webglcontextlost", this._onContextLost), this._onContextRestored && this._renderingCanvas.removeEventListener("webglcontextrestored", this._onContextRestored)), super.dispose(), this._dummyFramebuffer && this._gl.deleteFramebuffer(this._dummyFramebuffer), this.unbindAllAttributes(), this._boundUniforms = {}, this._workingCanvas = null, this._workingContext = null, this._currentBufferPointers.length = 0, this._currentProgram = null, this._creationOptions.loseContextOnDispose && this._gl.getExtension("WEBGL_lose_context")?.loseContext(), (0, bK.w)(this._gl)
      }
      attachContextLostEvent(OO) {
        this._renderingCanvas && this._renderingCanvas.addEventListener("webglcontextlost", OO, !1)
      }
      attachContextRestoredEvent(OO) {
        this._renderingCanvas && this._renderingCanvas.addEventListener("webglcontextrestored", OO, !1)
      }
      getError() {
        return this._gl.getError()
      }
      _canRenderToFloatFramebuffer() {
        return this._webGLVersion > 1 ? this._caps.colorBufferFloat : this._canRenderToFramebuffer(1)
      }
      _canRenderToHalfFloatFramebuffer() {
        return this._webGLVersion > 1 ? this._caps.colorBufferFloat : this._canRenderToFramebuffer(2)
      }
      _canRenderToFramebuffer(OO) {
        const KO = this._gl;
        for (; KO.getError() !== KO.NO_ERROR;);
        let pO = !0;
        const XO = KO.createTexture();
        KO.bindTexture(KO.TEXTURE_2D, XO), KO.texImage2D(KO.TEXTURE_2D, 0, this._getRGBABufferInternalSizedFormat(OO), 1, 1, 0, KO.RGBA, this._getWebGLTextureType(OO), null), KO.texParameteri(KO.TEXTURE_2D, KO.TEXTURE_MIN_FILTER, KO.NEAREST), KO.texParameteri(KO.TEXTURE_2D, KO.TEXTURE_MAG_FILTER, KO.NEAREST);
        const bK = KO.createFramebuffer();
        KO.bindFramebuffer(KO.FRAMEBUFFER, bK), KO.framebufferTexture2D(KO.FRAMEBUFFER, KO.COLOR_ATTACHMENT0, KO.TEXTURE_2D, XO, 0);
        const eO = KO.checkFramebufferStatus(KO.FRAMEBUFFER);
        if (pO = pO && eO === KO.FRAMEBUFFER_COMPLETE, pO = pO && KO.getError() === KO.NO_ERROR, pO && (KO.clear(KO.COLOR_BUFFER_BIT), pO = pO && KO.getError() === KO.NO_ERROR), pO) {
          KO.bindFramebuffer(KO.FRAMEBUFFER, null);
          const OO = KO.RGBA,
            XO = KO.UNSIGNED_BYTE,
            bK = new Uint8Array(4);
          KO.readPixels(0, 0, 1, 1, OO, XO, bK), pO = pO && KO.getError() === KO.NO_ERROR
        }
        for (KO.deleteTexture(XO), KO.deleteFramebuffer(bK), KO.bindFramebuffer(KO.FRAMEBUFFER, null); !pO && KO.getError() !== KO.NO_ERROR;);
        return pO
      }
      _getWebGLTextureType(OO) {
        if (1 === this._webGLVersion) {
          switch (OO) {
            case 1:
              return this._gl.FLOAT;
            case 2:
              return this._gl.HALF_FLOAT_OES;
            case 0:
              return this._gl.UNSIGNED_BYTE;
            case 8:
              return this._gl.UNSIGNED_SHORT_4_4_4_4;
            case 9:
              return this._gl.UNSIGNED_SHORT_5_5_5_1;
            case 10:
              return this._gl.UNSIGNED_SHORT_5_6_5
          }
          return this._gl.UNSIGNED_BYTE
        }
        switch (OO) {
          case 3:
            return this._gl.BYTE;
          case 0:
            return this._gl.UNSIGNED_BYTE;
          case 4:
            return this._gl.SHORT;
          case 5:
            return this._gl.UNSIGNED_SHORT;
          case 6:
            return this._gl.INT;
          case 7:
            return this._gl.UNSIGNED_INT;
          case 1:
            return this._gl.FLOAT;
          case 2:
            return this._gl.HALF_FLOAT;
          case 8:
            return this._gl.UNSIGNED_SHORT_4_4_4_4;
          case 9:
            return this._gl.UNSIGNED_SHORT_5_5_5_1;
          case 10:
            return this._gl.UNSIGNED_SHORT_5_6_5;
          case 11:
            return this._gl.UNSIGNED_INT_2_10_10_10_REV;
          case 12:
            return this._gl.UNSIGNED_INT_24_8;
          case 13:
            return this._gl.UNSIGNED_INT_10F_11F_11F_REV;
          case 14:
            return this._gl.UNSIGNED_INT_5_9_9_9_REV;
          case 15:
            return this._gl.FLOAT_32_UNSIGNED_INT_24_8_REV
        }
        return this._gl.UNSIGNED_BYTE
      }
      _getInternalFormat(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = KO ? this._glSRGBExtensionValues.SRGB8_ALPHA8 : this._gl.RGBA;
        switch (OO) {
          case 0:
            pO = this._gl.ALPHA;
            break;
          case 1:
            pO = this._gl.LUMINANCE;
            break;
          case 2:
            pO = this._gl.LUMINANCE_ALPHA;
            break;
          case 6:
          case 33322:
          case 36760:
            pO = this._gl.RED;
            break;
          case 7:
          case 33324:
          case 36761:
            pO = this._gl.RG;
            break;
          case 4:
          case 32852:
          case 36762:
            pO = KO ? this._glSRGBExtensionValues.SRGB : this._gl.RGB;
            break;
          case 5:
          case 32859:
          case 36763:
            pO = KO ? this._glSRGBExtensionValues.SRGB8_ALPHA8 : this._gl.RGBA
        }
        if (this._webGLVersion > 1) switch (OO) {
          case 8:
            pO = this._gl.RED_INTEGER;
            break;
          case 9:
            pO = this._gl.RG_INTEGER;
            break;
          case 10:
            pO = this._gl.RGB_INTEGER;
            break;
          case 11:
            pO = this._gl.RGBA_INTEGER
        }
        return pO
      }
      _getRGBABufferInternalSizedFormat(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (1 === this._webGLVersion) {
          if (void 0 !== KO) switch (KO) {
            case 0:
              return this._gl.ALPHA;
            case 1:
              return this._gl.LUMINANCE;
            case 2:
              return this._gl.LUMINANCE_ALPHA;
            case 4:
              return pO ? this._glSRGBExtensionValues.SRGB : this._gl.RGB
          }
          return this._gl.RGBA
        }
        switch (OO) {
          case 3:
            switch (KO) {
              case 6:
                return this._gl.R8_SNORM;
              case 7:
                return this._gl.RG8_SNORM;
              case 4:
                return this._gl.RGB8_SNORM;
              case 8:
                return this._gl.R8I;
              case 9:
                return this._gl.RG8I;
              case 10:
                return this._gl.RGB8I;
              case 11:
                return this._gl.RGBA8I;
              default:
                return this._gl.RGBA8_SNORM
            }
          case 0:
            switch (KO) {
              case 6:
                return this._gl.R8;
              case 7:
                return this._gl.RG8;
              case 4:
                return pO ? this._glSRGBExtensionValues.SRGB8 : this._gl.RGB8;
              case 5:
                return pO ? this._glSRGBExtensionValues.SRGB8_ALPHA8 : this._gl.RGBA8;
              case 8:
                return this._gl.R8UI;
              case 9:
                return this._gl.RG8UI;
              case 10:
                return this._gl.RGB8UI;
              case 11:
                return this._gl.RGBA8UI;
              case 0:
                return this._gl.ALPHA;
              case 1:
                return this._gl.LUMINANCE;
              case 2:
                return this._gl.LUMINANCE_ALPHA;
              default:
                return this._gl.RGBA8
            }
          case 4:
            switch (KO) {
              case 8:
                return this._gl.R16I;
              case 36760:
                return this._gl.R16_SNORM_EXT;
              case 36761:
                return this._gl.RG16_SNORM_EXT;
              case 36762:
                return this._gl.RGB16_SNORM_EXT;
              case 36763:
                return this._gl.RGBA16_SNORM_EXT;
              case 9:
                return this._gl.RG16I;
              case 10:
                return this._gl.RGB16I;
              default:
                return this._gl.RGBA16I
            }
          case 5:
            switch (KO) {
              case 8:
                return this._gl.R16UI;
              case 33322:
                return this._gl.R16_EXT;
              case 33324:
                return this._gl.RG16_EXT;
              case 32852:
                return this._gl.RGB16_EXT;
              case 32859:
                return this._gl.RGBA16_EXT;
              case 9:
                return this._gl.RG16UI;
              case 10:
                return this._gl.RGB16UI;
              default:
                return this._gl.RGBA16UI
            }
          case 6:
            switch (KO) {
              case 8:
                return this._gl.R32I;
              case 9:
                return this._gl.RG32I;
              case 10:
                return this._gl.RGB32I;
              default:
                return this._gl.RGBA32I
            }
          case 7:
            switch (KO) {
              case 8:
                return this._gl.R32UI;
              case 9:
                return this._gl.RG32UI;
              case 10:
                return this._gl.RGB32UI;
              default:
                return this._gl.RGBA32UI
            }
          case 1:
            switch (KO) {
              case 6:
                return this._gl.R32F;
              case 7:
                return this._gl.RG32F;
              case 4:
                return this._gl.RGB32F;
              default:
                return this._gl.RGBA32F
            }
          case 2:
            switch (KO) {
              case 6:
                return this._gl.R16F;
              case 7:
                return this._gl.RG16F;
              case 4:
                return this._gl.RGB16F;
              default:
                return this._gl.RGBA16F
            }
          case 10:
            return this._gl.RGB565;
          case 13:
            return this._gl.R11F_G11F_B10F;
          case 14:
            return this._gl.RGB9_E5;
          case 8:
            return this._gl.RGBA4;
          case 9:
            return this._gl.RGB5_A1;
          case 11:
            switch (KO) {
              case 5:
              default:
                return this._gl.RGB10_A2;
              case 11:
                return this._gl.RGB10_A2UI
            }
        }
        return pO ? this._glSRGBExtensionValues.SRGB8_ALPHA8 : this._gl.RGBA8
      }
      readPixels(OO, KO, pO, XO) {
        let bK = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
          eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
          lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null;
        const CO = bK ? 4 : 3,
          hO = bK ? this._gl.RGBA : this._gl.RGB,
          DO = pO * XO * CO;
        if (lO) {
          if (lO.length < DO) return vK.b.Error(`Data buffer is too small to store the read pixels (${lO.length} should be more than ${DO})`), Promise.resolve(lO)
        } else lO = new Uint8Array(DO);
        return eO && this.flushFramebuffer(), this._gl.readPixels(OO, KO, pO, XO, hO, this._gl.UNSIGNED_BYTE, lO), Promise.resolve(lO)
      }
      static get IsSupportedAsync() {
        return Promise.resolve(this.isSupported())
      }
      static get IsSupported() {
        return this.isSupported()
      }
      static isSupported() {
        if (null !== this._HasMajorPerformanceCaveat) return !this._HasMajorPerformanceCaveat;
        if (null === this._IsSupported) try {
          const OO = eO.e._CreateCanvas(1, 1),
            KO = OO.getContext("webgl") || OO.getContext("experimental-webgl");
          this._IsSupported = null != KO && !!globalThis.WebGLRenderingContext
        } catch (OO) {
          this._IsSupported = !1
        }
        return this._IsSupported
      }
      static get HasMajorPerformanceCaveat() {
        if (null === this._HasMajorPerformanceCaveat) try {
          const OO = eO.e._CreateCanvas(1, 1),
            KO = OO.getContext("webgl", {
              failIfMajorPerformanceCaveat: !0
            }) || OO.getContext("experimental-webgl", {
              failIfMajorPerformanceCaveat: !0
            });
          this._HasMajorPerformanceCaveat = !KO
        } catch (OO) {
          this._HasMajorPerformanceCaveat = !1
        }
        return this._HasMajorPerformanceCaveat
      }
    }
    dO._TempClearColorUint32 = new Uint32Array(4), dO._TempClearColorInt32 = new Int32Array(4), dO._TempClearColorFloat32 = new Float32Array(4), dO.ExceptionList = [{
      key: "Chrome/63.0",
      capture: "63\\.0\\.3239\\.(\\d+)",
      captureConstraint: 108,
      targets: ["uniformBuffer"]
    }, {
      key: "Firefox/58",
      capture: null,
      captureConstraint: null,
      targets: ["uniformBuffer"]
    }, {
      key: "Firefox/59",
      capture: null,
      captureConstraint: null,
      targets: ["uniformBuffer"]
    }, {
      key: "Chrome/72.+?Mobile",
      capture: null,
      captureConstraint: null,
      targets: ["vao"]
    }, {
      key: "Chrome/73.+?Mobile",
      capture: null,
      captureConstraint: null,
      targets: ["vao"]
    }, {
      key: "Chrome/74.+?Mobile",
      capture: null,
      captureConstraint: null,
      targets: ["vao"]
    }, {
      key: "Mac OS.+Chrome/71",
      capture: null,
      captureConstraint: null,
      targets: ["vao"]
    }, {
      key: "Mac OS.+Chrome/72",
      capture: null,
      captureConstraint: null,
      targets: ["vao"]
    }, {
      key: "Mac OS.+Chrome",
      capture: null,
      captureConstraint: null,
      targets: ["uniformBuffer"]
    }, {
      key: "Chrome/12\\d\\..+?Mobile",
      capture: null,
      captureConstraint: null,
      targets: ["uniformBuffer"]
    }, {
      key: ".*AppleWebKit.*(15.4).*Safari",
      capture: null,
      captureConstraint: null,
      targets: ["antialias", "maxMSAASamples"]
    }, {
      key: ".*(15.4).*AppleWebKit.*Safari",
      capture: null,
      captureConstraint: null,
      targets: ["antialias", "maxMSAASamples"]
    }], dO._ConcatenateShader = LO.i, dO._IsSupported = null, dO._HasMajorPerformanceCaveat = null
  },
  38266: (OO, KO, pO) => {
    var XO;
    pO.d(KO, {
        e: () => bK
      }),
      function(OO) {
        OO[OO.PointerMove = 0] = "PointerMove", OO[OO.PointerDown = 1] = "PointerDown", OO[OO.PointerUp = 2] = "PointerUp"
      }(XO || (XO = {}));
    class bK {}
    bK.DOM_DELTA_PIXEL = 0, bK.DOM_DELTA_LINE = 1, bK.DOM_DELTA_PAGE = 2
  },
  38258: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      f: () => eO,
      g: () => bK
    });
    class XO {}
    XO.KEYDOWN = 1, XO.KEYUP = 2;
    class bK {
      constructor(OO, KO) {
        this.type = OO, this.event = KO
      }
    }
    class eO extends bK {
      get skipOnPointerObservable() {
        return this.skipOnKeyboardObservable
      }
      set skipOnPointerObservable(OO) {
        this.skipOnKeyboardObservable = OO
      }
      constructor(OO, KO) {
        super(OO, KO), this.type = OO, this.event = KO, this.skipOnKeyboardObservable = !1
      }
    }
  },
  38254: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      d: () => lO,
      e: () => vK
    });
    var XO = pO(35632);
    class bK {}
    bK.POINTERDOWN = 1, bK.POINTERUP = 2, bK.POINTERMOVE = 4, bK.POINTERWHEEL = 8, bK.POINTERPICK = 16, bK.POINTERTAP = 32, bK.POINTERDOUBLETAP = 64;
    class eO {
      constructor(OO, KO) {
        this.type = OO, this.event = KO
      }
    }
    class lO extends eO {
      constructor(OO, KO, pO, bK) {
        super(OO, KO), this.ray = null, this.originalPickingInfo = null, this.skipOnPointerObservable = !1, this.localPosition = new XO.m(pO, bK)
      }
    }
    class vK extends eO {
      get pickInfo() {
        return this._pickInfo || this._generatePickInfo(), this._pickInfo
      }
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        super(OO, KO), this._pickInfo = pO, this._inputManager = XO
      }
      _generatePickInfo() {
        this._inputManager && (this._pickInfo = this._inputManager._pickMove(this.event), this._inputManager._setRayOnPointerInfo(this._pickInfo, this.event), this._inputManager = null)
      }
    }
  },
  38275: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    class XO {
      static CompareLightsPriority(OO, KO) {
        return OO.shadowEnabled !== KO.shadowEnabled ? (KO.shadowEnabled ? 1 : 0) - (OO.shadowEnabled ? 1 : 0) : KO.renderPriority - OO.renderPriority
      }
    }
    XO.FALLOFF_DEFAULT = 0, XO.FALLOFF_PHYSICAL = 1, XO.FALLOFF_GLTF = 2, XO.FALLOFF_STANDARD = 3, XO.LIGHTMAP_DEFAULT = 0, XO.LIGHTMAP_SPECULAR = 1, XO.LIGHTMAP_SHADOWSONLY = 2, XO.INTENSITYMODE_AUTOMATIC = 0, XO.INTENSITYMODE_LUMINOUSPOWER = 1, XO.INTENSITYMODE_LUMINOUSINTENSITY = 2, XO.INTENSITYMODE_ILLUMINANCE = 3, XO.INTENSITYMODE_LUMINANCE = 4, XO.LIGHTTYPEID_POINTLIGHT = 0, XO.LIGHTTYPEID_DIRECTIONALLIGHT = 1, XO.LIGHTTYPEID_SPOTLIGHT = 2, XO.LIGHTTYPEID_HEMISPHERICLIGHT = 3, XO.LIGHTTYPEID_RECT_AREALIGHT = 4, XO.LIGHTTYPEID_CLUSTERED_CONTAINER = 5
  },
  37889: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO, bK = pO(35660),
      eO = pO(37896);
    ! function(OO) {
      OO[OO.Unknown = 0] = "Unknown", OO[OO.Url = 1] = "Url", OO[OO.Temp = 2] = "Temp", OO[OO.Raw = 3] = "Raw", OO[OO.Dynamic = 4] = "Dynamic", OO[OO.RenderTarget = 5] = "RenderTarget", OO[OO.MultiRenderTarget = 6] = "MultiRenderTarget", OO[OO.Cube = 7] = "Cube", OO[OO.CubeRaw = 8] = "CubeRaw", OO[OO.CubePrefiltered = 9] = "CubePrefiltered", OO[OO.Raw3D = 10] = "Raw3D", OO[OO.Raw2DArray = 11] = "Raw2DArray", OO[OO.DepthStencil = 12] = "DepthStencil", OO[OO.CubeRawRGBD = 13] = "CubeRawRGBD", OO[OO.Depth = 14] = "Depth", OO[OO.External = 15] = "External"
    }(XO || (XO = {}));
    class lO extends eO.e {
      get useMipMaps() {
        return null === this._useMipMaps ? this.generateMipMaps : this._useMipMaps
      }
      set useMipMaps(OO) {
        this._useMipMaps = OO
      }
      get uniqueId() {
        return this._uniqueId
      }
      _setUniqueId(OO) {
        this._uniqueId = OO
      }
      qb() {
        return this._engine
      }
      get source() {
        return this._source
      }
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        super(), this.isReady = !1, this.isCube = !1, this.is3D = !1, this.is2DArray = !1, this.isMultiview = !1, this.url = "", this.generateMipMaps = !1, this._useMipMaps = null, this.mipLevelCount = 1, this.samples = 0, this.type = -1, this.format = -1, this.onLoadedObservable = new bK.e, this.onErrorObservable = new bK.e, this.onRebuildCallback = null, this.width = 0, this.height = 0, this.depth = 0, this.baseWidth = 0, this.baseHeight = 0, this.baseDepth = 0, this.invertY = !1, this._invertVScale = !1, this._associatedChannel = -1, this._source = 0, this._buffer = null, this._bufferView = null, this._bufferViewArray = null, this._bufferViewArrayArray = null, this._size = 0, this._extension = "", this._files = null, this._workingCanvas = null, this._workingContext = null, this._cachedCoordinatesMode = null, this._isDisabled = !1, this._compression = null, this._sphericalPolynomial = null, this._sphericalPolynomialPromise = null, this._sphericalPolynomialComputed = !1, this._lodGenerationScale = 0, this._lodGenerationOffset = 0, this._useSRGBBuffer = !1, this._creationFlags = 0, this._lodTextureHigh = null, this._lodTextureMid = null, this._lodTextureLow = null, this._isRGBD = !1, this._linearSpecularLOD = !1, this._irradianceTexture = null, this._hardwareTexture = null, this._maxLodLevel = null, this._references = 1, this._gammaSpace = null, this._premulAlpha = !1, this._dynamicTextureSource = null, this._autoMSAAManagement = !1, this._engine = OO, this._source = KO, this._uniqueId = lO._Counter++, pO || (this._hardwareTexture = OO._createHardwareTexture())
      }
      incrementReferences() {
        this._references++
      }
      updateSize(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
        this._engine.updateTextureDimensions(this, OO, KO, pO), this.width = OO, this.height = KO, this.depth = pO, this.baseWidth = OO, this.baseHeight = KO, this.baseDepth = pO, this._size = OO * KO * pO
      }
      _rebuild() {
        if (this.isReady = !1, this._cachedCoordinatesMode = null, this._cachedWrapU = null, this._cachedWrapV = null, this._cachedWrapR = null, this._cachedAnisotropicFilteringLevel = null, this.onRebuildCallback) {
          const OO = this.onRebuildCallback(this),
            KO = KO => {
              KO._swapAndDie(this, !1), this.isReady = OO.isReady
            };
          return void(OO.isAsync ? OO.proxy.then(KO) : KO(OO.proxy))
        }
        let OO;
        switch (this.source) {
          case 2:
          case 12:
          case 14:
          case 15:
            break;
          case 1:
            return void(OO = this._engine.createTexture(this._originalUrl ?? this.url, !this.generateMipMaps, this.invertY, null, this.samplingMode, (OO => {
              OO._swapAndDie(this, !1), this.isReady = !0
            }), null, this._buffer, void 0, this.format, this._extension, void 0, void 0, void 0, this._useSRGBBuffer));
          case 3:
            if (OO = this._engine.createRawTexture(this._bufferView, this.baseWidth, this.baseHeight, this.format, this.generateMipMaps, this.invertY, this.samplingMode, this._compression, this.type, this._creationFlags, this._useSRGBBuffer, this.mipLevelCount), OO._swapAndDie(this, !1), this._bufferViewArray)
              for (let OO = 0; OO < this._bufferViewArray.length; OO++) {
                const KO = this._bufferViewArray[OO];
                KO && this._engine.updateRawTexture(this, KO, this.format, this.invertY, this._compression, this.type, this._useSRGBBuffer, OO)
              }
            this.isReady = !0;
            break;
          case 10:
            OO = this._engine.createRawTexture3D(this._bufferView, this.baseWidth, this.baseHeight, this.baseDepth, this.format, this.generateMipMaps, this.invertY, this.samplingMode, this._compression, this.type), OO._swapAndDie(this, !1), this.isReady = !0;
            break;
          case 11:
            if (OO = this._engine.createRawTexture2DArray(this._bufferView, this.baseWidth, this.baseHeight, this.baseDepth, this.format, this.generateMipMaps, this.invertY, this.samplingMode, this._compression, this.type, this._creationFlags, this.mipLevelCount), OO._swapAndDie(this, !1), this._bufferViewArray)
              for (let OO = 0; OO < this._bufferViewArray.length; OO++) {
                const KO = this._bufferViewArray[OO];
                KO && this._engine.updateRawTexture2DArray(this, KO, this.format, this.invertY, this._compression, this.type, OO)
              }
            this.isReady = !0;
            break;
          case 4:
            OO = this._engine.createDynamicTexture(this.baseWidth, this.baseHeight, this.generateMipMaps, this.samplingMode), OO._swapAndDie(this, !1), this._dynamicTextureSource && this._engine.updateDynamicTexture(this, this._dynamicTextureSource, this.invertY, this._premulAlpha, this.format, !0);
            break;
          case 7:
            return void(OO = this._engine.createCubeTexture(this.url, null, this._files, !this.generateMipMaps, (() => {
              OO._swapAndDie(this, !1), this.isReady = !0
            }), null, this.format, this._extension, !1, 0, 0, null, void 0, this._useSRGBBuffer, ArrayBuffer.isView(this._buffer) ? this._buffer : null));
          case 8:
            OO = this._engine.createRawCubeTexture(this._bufferViewArray, this.width, this._originalFormat ?? this.format, this.type, this.generateMipMaps, this.invertY, this.samplingMode, this._compression), OO._swapAndDie(this, !1), this.isReady = !0;
            break;
          case 13:
            return;
          case 9:
            return OO = this._engine.createPrefilteredCubeTexture(this.url, null, this._lodGenerationScale, this._lodGenerationOffset, (OO => {
              OO && OO._swapAndDie(this, !1), this.isReady = !0
            }), null, this.format, this._extension, void 0, ArrayBuffer.isView(this._buffer) ? this._buffer : null), void(OO._sphericalPolynomial = this._sphericalPolynomial)
        }
      }
      _swapAndDie(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        this._hardwareTexture?.setUsage(OO._source, this.generateMipMaps, this.is2DArray, this.isCube, this.is3D, this.width, this.height, this.depth), OO._hardwareTexture = this._hardwareTexture, OO._setUniqueId(lO._Counter++), KO && (OO._isRGBD = this._isRGBD), this._lodTextureHigh && (OO._lodTextureHigh && OO._lodTextureHigh.dispose(), OO._lodTextureHigh = this._lodTextureHigh), this._lodTextureMid && (OO._lodTextureMid && OO._lodTextureMid.dispose(), OO._lodTextureMid = this._lodTextureMid), this._lodTextureLow && (OO._lodTextureLow && OO._lodTextureLow.dispose(), OO._lodTextureLow = this._lodTextureLow), this._irradianceTexture && (OO._irradianceTexture && OO._irradianceTexture.dispose(), OO._irradianceTexture = this._irradianceTexture);
        const pO = this._engine.getLoadedTexturesCache();
        let XO = pO.indexOf(this); - 1 !== XO && pO.splice(XO, 1), XO = pO.indexOf(OO), -1 === XO && pO.push(OO)
      }
      dispose() {
        this._references--, 0 === this._references && (this.onLoadedObservable.clear(), this.onErrorObservable.clear(), this._engine._releaseTexture(this), this._hardwareTexture = null, this._dynamicTextureSource = null)
      }
    }
    lO._Counter = 0
  },
  38004: (OO, KO, pO) => {
    function XO(OO) {
      return 13 === OO || 14 === OO || 15 === OO || 16 === OO || 17 === OO || 18 === OO || 19 === OO
    }

    function bK(OO) {
      return 8 === OO || 9 === OO || 10 === OO || 11 === OO
    }

    function eO(OO) {
      return 0 === OO || 5 === OO || 7 === OO || 11 === OO
    }

    function lO(OO) {
      return 13 === OO || 17 === OO || 18 === OO || 19 === OO
    }
    pO.d(KO, {
      d: () => lO,
      g: () => XO,
      j: () => bK,
      k: () => eO
    })
  },
  37896: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    class XO {
      get wrapU() {
        return this._cachedWrapU
      }
      set wrapU(OO) {
        this._cachedWrapU = OO
      }
      get wrapV() {
        return this._cachedWrapV
      }
      set wrapV(OO) {
        this._cachedWrapV = OO
      }
      get wrapR() {
        return this._cachedWrapR
      }
      set wrapR(OO) {
        this._cachedWrapR = OO
      }
      get anisotropicFilteringLevel() {
        return this._cachedAnisotropicFilteringLevel
      }
      set anisotropicFilteringLevel(OO) {
        this._cachedAnisotropicFilteringLevel = OO
      }
      get comparisonFunction() {
        return this._comparisonFunction
      }
      set comparisonFunction(OO) {
        this._comparisonFunction = OO
      }
      get useMipMaps() {
        return this._useMipMaps
      }
      set useMipMaps(OO) {
        this._useMipMaps = OO
      }
      constructor() {
        this.samplingMode = -1, this._useMipMaps = !0, this._cachedWrapU = null, this._cachedWrapV = null, this._cachedWrapR = null, this._cachedAnisotropicFilteringLevel = null, this._comparisonFunction = 0
      }
      setParameters() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 2,
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0;
        return this._cachedWrapU = OO, this._cachedWrapV = KO, this._cachedWrapR = pO, this._cachedAnisotropicFilteringLevel = XO, this.samplingMode = bK, this._comparisonFunction = eO, this
      }
      compareSampler(OO) {
        return this._cachedWrapU === OO._cachedWrapU && this._cachedWrapV === OO._cachedWrapV && this._cachedWrapR === OO._cachedWrapR && this._cachedAnisotropicFilteringLevel === OO._cachedAnisotropicFilteringLevel && this.samplingMode === OO.samplingMode && this._comparisonFunction === OO._comparisonFunction && this._useMipMaps === OO._useMipMaps
      }
    }
  },
  38193: (OO, KO, pO) => {
    function XO(OO) {
      OO.push("vCameraColorCurveNeutral", "vCameraColorCurvePositive", "vCameraColorCurveNegative")
    }
    pO.d(KO, {
      d: () => XO
    })
  },
  37978: (OO, KO, pO) => {
    function XO(OO) {
      return void 0 === OO.getPipelineContext
    }
    pO.d(KO, {
      e: () => XO
    })
  },
  38416: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(37955);
    class bK {
      static GetEffect(OO) {
        return void 0 === OO.getPipelineContext ? OO.effect : OO
      }
      constructor(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        this._wasPreviouslyReady = !1, this._forceRebindOnNextCall = !0, this._wasPreviouslyUsingInstances = null, this.effect = null, this.defines = null, this.drawContext = OO.createDrawContext(), KO && (this.materialContext = OO.createMaterialContext())
      }
      setEffect(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        pO || this.effect === OO || this.drawContext?._releaseUniformBufferSlots?.(), this.effect = OO, void 0 !== KO && (this.defines = KO), pO && this.drawContext?.reset()
      }
      dispose() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        if (this.effect) {
          const KO = this.effect;
          OO ? KO.dispose() : XO.c.SetImmediate((() => {
            KO.qb().onEndFrameObservable.addOnce((() => {
              KO.dispose()
            }))
          })), this.effect = null
        }
        this.drawContext?.dispose()
      }
    }
  },
  37912: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => MO,
      f: () => oO,
      j: () => hO,
      m: () => DO
    });
    var XO = pO(37918),
      bK = pO(37921),
      eO = pO(37907),
      lO = pO(37061),
      vK = pO(37947),
      CO = pO(37930);

    function hO(OO, KO) {
      return (0, bK.A)(KO).cachedPipelines[OO]
    }

    function DO(OO) {
      const KO = OO._name,
        pO = OO.context;
      if (KO && pO) {
        const OO = (0, bK.A)(pO),
          XO = OO.cachedPipelines[KO];
        XO?.dispose(), delete OO.cachedPipelines[KO]
      }
    }

    function MO(OO, KO, pO, bK, eO, lO, CO) {
      let hO, DO;
      const MO = (0, XO.n)() ? lO?.getHostDocument() : null;
      hO = "string" === typeof KO ? KO : "string" === typeof KO.vertexSource ? "source:" + KO.vertexSource : "string" === typeof KO.vertexElement ? MO?.getElementById(KO.vertexElement) || KO.vertexElement : KO.vertex || KO, DO = "string" === typeof KO ? KO : "string" === typeof KO.fragmentSource ? "source:" + KO.fragmentSource : "string" === typeof KO.fragmentElement ? MO?.getElementById(KO.fragmentElement) || KO.fragmentElement : KO.fragment || KO;
      const oO = [void 0, void 0],
        FO = () => {
          if (oO[0] && oO[1]) {
            const [XO, hO] = oO;
            (0, vK.f)(OO), (0, vK.h)(XO, OO, ((XO, DO) => {
              CO && (CO._vertexSourceCodeBeforeMigration = DO), pO && (XO = pO("vertex", XO)), OO.isFragment = !0, (0, vK.h)(hO, OO, ((lO, hO) => {
                CO && (CO._fragmentSourceCodeBeforeMigration = hO), pO && (lO = pO("fragment", lO));
                const DO = (0, vK.e)(XO, lO, OO);
                OO = null;
                const MO = function(OO, KO, pO, XO) {
                  if (pO) {
                    return {
                      vertexSourceCode: (1 === XO ? "//" : "") + "#define SHADER_NAME vertex:" + (pO.vertexElement || pO.vertex || pO.spectorName || pO) + "\n" + OO,
                      fragmentSourceCode: (1 === XO ? "//" : "") + "#define SHADER_NAME fragment:" + (pO.fragmentElement || pO.fragment || pO.spectorName || pO) + "\n" + KO
                    }
                  }
                  return {
                    vertexSourceCode: OO,
                    fragmentSourceCode: KO
                  }
                }(DO.vertexCode, DO.fragmentCode, KO, eO);
                bK?.(MO.vertexSourceCode, MO.fragmentSourceCode)
              }), lO)
            }), lO)
          }
        };
      aK(hO, "Vertex", "", (OO => {
        CO && (CO._rawVertexSourceCode = OO), oO[0] = OO, FO()
      }), eO), aK(DO, "Fragment", "Pixel", (OO => {
        CO && (CO._rawFragmentSourceCode = OO), oO[1] = OO, FO()
      }), eO)
    }

    function aK(OO, KO, pO, bK, lO, vK) {
      if ("undefined" !== typeof HTMLElement && OO instanceof HTMLElement) {
        return void bK((0, XO.e)(OO))
      }
      if ("source:" === OO.substring(0, 7)) return void bK(OO.substring(7));
      if ("base64:" === OO.substring(0, 7)) {
        return void bK(window.atob(OO.substring(7)))
      }
      const hO = eO.b.GetShadersStore(lO);
      if (hO[OO + KO + "Shader"]) return void bK(hO[OO + KO + "Shader"]);
      if (pO && hO[OO + pO + "Shader"]) return void bK(hO[OO + pO + "Shader"]);
      let DO;
      if (DO = "." === OO[0] || "/" === OO[0] || OO.indexOf("http") > -1 ? OO : eO.b.GetShadersRepository(lO) + OO, !(vK = vK || CO.l)) throw new Error("loadFileInjection is not defined");
      vK(DO + "." + KO.toLowerCase() + ".fx", bK)
    }
    const oO = (OO, KO, pO, XO) => {
      try {
        const eO = OO.context ? (0, bK.A)(OO.context) : null;
        eO && (eO.disableParallelShaderCompile = OO.disableParallelCompilation);
        const lO = OO.existingPipelineContext || KO(OO.shaderProcessingContext);
        return lO._name = OO.name, OO.name && eO && (eO.cachedPipelines[OO.name] = lO), pO(lO, OO.vertex, OO.fragment, !!OO.createAsRaw, "", "", OO.rebuildRebind, OO.defines, OO.transformFeedbackVaryings, "", (() => {
          XO(lO, (() => {
            OO.onRenderingStateCompiled?.(lO)
          }))
        })), lO
      } catch (eO) {
        throw lO.b.Error("Error compiling effect"), eO
      }
    }
  },
  37902: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => CO
    });
    var XO = pO(35660),
      bK = pO(37061),
      eO = pO(37907),
      lO = pO(37912),
      vK = pO(37955);
    class CO {
      static get ShadersRepository() {
        return eO.b.ShadersRepository
      }
      static set ShadersRepository(OO) {
        eO.b.ShadersRepository = OO
      }
      get FhO() {
        return this._isDisposed
      }
      get onBindObservable() {
        return this._onBindObservable || (this._onBindObservable = new XO.e), this._onBindObservable
      }
      get shaderLanguage() {
        return this._shaderLanguage
      }
      constructor(OO, KO, pO) {
        let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
          eO = arguments.length > 4 ? arguments[4] : void 0,
          vK = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
          hO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null,
          DO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
          MO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : null,
          aK = arguments.length > 9 ? arguments[9] : void 0,
          oO = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : "",
          FO = arguments.length > 11 && void 0 !== arguments[11] ? arguments[11] : 0,
          VO = arguments.length > 12 ? arguments[12] : void 0;
        this.defines = "", this.onCompiled = null, this.onError = null, this.onBind = null, this.uniqueId = 0, this.onCompileObservable = new XO.e, this.onErrorObservable = new XO.e, this._onBindObservable = null, this._isDisposed = !1, this._refCount = 1, this._bonesComputationForcedToCPU = !1, this._uniformBuffersNames = {}, this._multiTarget = !1, this._samplers = {}, this._isReady = !1, this._compilationError = "", this._allFallbacksProcessed = !1, this._uniforms = {}, this._key = "", this._fallbacks = null, this._vertexSourceCodeOverride = "", this._fragmentSourceCodeOverride = "", this._transformFeedbackVaryings = null, this._disableParallelShaderCompilation = !1, this._pipelineContext = null, this._vertexSourceCode = "", this._fragmentSourceCode = "", this._vertexSourceCodeBeforeMigration = "", this._fragmentSourceCodeBeforeMigration = "", this._rawVertexSourceCode = "", this._rawFragmentSourceCode = "", this._processCodeAfterIncludes = void 0, this._processFinalCode = null, this._onReleaseEffectsObserver = null, this.name = OO, this._key = oO;
        const LO = this._key.replace(/\r/g, "").replace(/\n/g, "|");
        let QO;
        if (KO.attributes) {
          const OO = KO;
          if (this._engine = pO, this._attributesNames = OO.attributes, this._uniformsNames = OO.uniformsNames.concat(OO.samplers), this._samplerList = OO.samplers.slice(), this.defines = OO.defines, this.onError = OO.onError, this.onCompiled = OO.onCompiled, this._fallbacks = OO.fallbacks, this._indexParameters = OO.indexParameters, this._transformFeedbackVaryings = OO.transformFeedbackVaryings || null, this._multiTarget = !!OO.multiTarget, this._shaderLanguage = OO.shaderLanguage ?? 0, this._disableParallelShaderCompilation = !!OO.disableParallelShaderCompilation, OO.uniformBuffersNames) {
            this._uniformBuffersNamesList = OO.uniformBuffersNames.slice();
            for (let KO = 0; KO < OO.uniformBuffersNames.length; KO++) this._uniformBuffersNames[OO.uniformBuffersNames[KO]] = KO
          }
          this._processFinalCode = OO.processFinalCode ?? null, this._processCodeAfterIncludes = OO.processCodeAfterIncludes ?? void 0, VO = OO.extraInitializationsAsync, QO = OO.existingPipelineContext
        } else this._engine = eO, this.defines = null == vK ? "" : vK, this._uniformsNames = pO.concat(bK), this._samplerList = bK ? bK.slice() : [], this._attributesNames = KO, this._uniformBuffersNamesList = [], this._shaderLanguage = FO, this.onError = MO, this.onCompiled = DO, this._indexParameters = aK, this._fallbacks = hO;
        "WEBGL2" === this._engine.shaderPlatformName && (QO = (0, lO.j)(LO, this._engine._gl) ?? QO), this._attributeLocationByName = {}, this.uniqueId = CO._UniqueIdSeed++, QO ? (this._pipelineContext = QO, this._pipelineContext.setEngine(this._engine), this._onRenderingStateCompiled(this._pipelineContext), this._pipelineContext.program && (this._pipelineContext.program.__SPECTOR_rebuildProgram = this._rebuildProgram.bind(this))) : this._processShaderCodeAsync(null, !1, null, VO).catch((OO => {
          const KO = OO?.message ?? String(OO),
            pO = new Error(`Effect async shader preparation failed for "${String(this.name)}": ${KO}`);
          OO && "string" === typeof OO.stack && (pO.stack = `${pO.message}\nCaused by: ${OO.stack}`), this._processCompilationErrors(pO)
        })), this._onReleaseEffectsObserver = this._engine.onReleaseEffectsObservable.addOnce((() => {
          this._onReleaseEffectsObserver = null, this.FhO || this.dispose(!0)
        }))
      }
      async _processShaderCodeAsync() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        XO && await XO(), this._processingContext = pO || this._engine._getShaderProcessingContext(this._shaderLanguage, !1);
        const bK = {
          defines: this.defines.split("\n"),
          indexParameters: this._indexParameters,
          isFragment: !1,
          shouldUseHighPrecisionShader: this._engine._shouldUseHighPrecisionShader,
          processor: OO ?? this._engine._getShaderProcessor(this._shaderLanguage),
          supportsUniformBuffers: this._engine.supportsUniformBuffers,
          shadersRepository: eO.b.GetShadersRepository(this._shaderLanguage),
          includesShadersStore: eO.b.GetIncludesShadersStore(this._shaderLanguage),
          version: (100 * this._engine.version).toString(),
          platformName: this._engine.shaderPlatformName,
          processingContext: this._processingContext,
          isNDCHalfZRange: this._engine.isNDCHalfZRange,
          BhO: this._engine.BhO,
          processCodeAfterIncludes: this._processCodeAfterIncludes
        };
        (0, lO.b)(bK, this.name, this._processFinalCode, ((OO, pO) => {
          this._vertexSourceCode = OO, this._fragmentSourceCode = pO, this._prepareEffect(KO)
        }), this._shaderLanguage, this._engine, this)
      }
      get key() {
        return this._key
      }
      isReady() {
        try {
          return this._isReadyInternal()
        } catch {
          return !1
        }
      }
      _isReadyInternal() {
        return !!this._engine.FhO || (!!this._isReady || !!this._pipelineContext && this._pipelineContext.isReady)
      }
      qb() {
        return this._engine
      }
      getPipelineContext() {
        return this._pipelineContext
      }
      getAttributesNames() {
        return this._attributesNames
      }
      getAttributeLocation(OO) {
        return this._attributes[OO]
      }
      getAttributeLocationByName(OO) {
        return this._attributeLocationByName[OO]
      }
      getAttributesCount() {
        return this._attributes.length
      }
      getUniformIndex(OO) {
        return this._uniformsNames.indexOf(OO)
      }
      getUniform(OO) {
        return this._uniforms[OO]
      }
      getSamplers() {
        return this._samplerList
      }
      getUniformNames() {
        return this._uniformsNames
      }
      getUniformBuffersNames() {
        return this._uniformBuffersNamesList
      }
      getIndexParameters() {
        return this._indexParameters
      }
      getCompilationError() {
        return this._compilationError
      }
      allFallbacksProcessed() {
        return this._allFallbacksProcessed
      }
      async whenCompiledAsync() {
        return await new Promise((OO => {
          this.executeWhenCompiled(OO)
        }))
      }
      executeWhenCompiled(OO) {
        this.isReady() ? OO(this) : (this.onCompileObservable.add((KO => {
          OO(KO)
        })), this._pipelineContext && !this._pipelineContext.isAsync || this._checkIsReady(null))
      }
      _checkIsReady(OO) {
        (0, vK.e)((() => this._isReadyInternal() || this._isDisposed), (() => {}), (KO => {
          this._processCompilationErrors(KO, OO)
        }), 16, 12e4, !0, ` - Effect: ${"string"===typeof this.name?this.name:this.key}`)
      }
      get vertexSourceCode() {
        return this._vertexSourceCodeOverride && this._fragmentSourceCodeOverride ? this._vertexSourceCodeOverride : this._pipelineContext?._getVertexShaderCode() ?? this._vertexSourceCode
      }
      get fragmentSourceCode() {
        return this._vertexSourceCodeOverride && this._fragmentSourceCodeOverride ? this._fragmentSourceCodeOverride : this._pipelineContext?._getFragmentShaderCode() ?? this._fragmentSourceCode
      }
      get vertexSourceCodeBeforeMigration() {
        return this._vertexSourceCodeBeforeMigration
      }
      get fragmentSourceCodeBeforeMigration() {
        return this._fragmentSourceCodeBeforeMigration
      }
      get rawVertexSourceCode() {
        return this._rawVertexSourceCode
      }
      get rawFragmentSourceCode() {
        return this._rawFragmentSourceCode
      }
      getPipelineGenerationOptions() {
        return {
          platformName: this._engine.shaderPlatformName,
          shaderLanguage: this._shaderLanguage,
          shaderNameOrContent: this.name,
          key: this._key,
          defines: this.defines.split("\n"),
          addGlobalDefines: !1,
          extendedProcessingOptions: {
            indexParameters: this._indexParameters,
            isNDCHalfZRange: this._engine.isNDCHalfZRange,
            BhO: this._engine.BhO,
            supportsUniformBuffers: this._engine.supportsUniformBuffers
          },
          extendedCreatePipelineOptions: {
            transformFeedbackVaryings: this._transformFeedbackVaryings,
            createAsRaw: !(!this._vertexSourceCodeOverride || !this._fragmentSourceCodeOverride)
          }
        }
      }
      _rebuildProgram(OO, KO, pO, XO) {
        this._isReady = !1, this._vertexSourceCodeOverride = OO, this._fragmentSourceCodeOverride = KO, this.onError = (OO, KO) => {
          XO && XO(KO)
        }, this.onCompiled = () => {
          const OO = this.qb().scenes;
          if (OO)
            for (let KO = 0; KO < OO.length; KO++) OO[KO].markAllMaterialsAsDirty(127);
          this._pipelineContext._handlesSpectorRebuildCallback?.(pO)
        }, this._fallbacks = null, this._prepareEffect()
      }
      _onRenderingStateCompiled(OO) {
        if (this._pipelineContext = OO, this._pipelineContext.setEngine(this._engine), this._attributes = [], this._pipelineContext._fillEffectInformation(this, this._uniformBuffersNames, this._uniformsNames, this._uniforms, this._samplerList, this._samplers, this._attributesNames, this._attributes), this._attributesNames)
          for (let KO = 0; KO < this._attributesNames.length; KO++) {
            const OO = this._attributesNames[KO];
            this._attributeLocationByName[OO] = this._attributes[KO]
          }
        this._engine.bindSamplers(this), this._compilationError = "", this._isReady = !0, this.onCompiled && this.onCompiled(this), this.onCompileObservable.notifyObservers(this), this.onCompileObservable.clear(), this._fallbacks && this._fallbacks.unBindMesh(), CO.AutomaticallyClearCodeCache && this.clearCodeCache()
      }
      _prepareEffect() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = this._pipelineContext;
        this._isReady = !1;
        try {
          const pO = !(!this._vertexSourceCodeOverride || !this._fragmentSourceCodeOverride),
            XO = pO ? null : this.defines,
            bK = pO ? this._vertexSourceCodeOverride : this._vertexSourceCode,
            eO = pO ? this._fragmentSourceCodeOverride : this._fragmentSourceCode,
            vK = this._engine;
          this._pipelineContext = (0, lO.f)({
            existingPipelineContext: OO ? KO : null,
            vertex: bK,
            fragment: eO,
            context: "WEBGL2" === vK.shaderPlatformName || "WEBGL1" === vK.shaderPlatformName ? vK._gl : void 0,
            rebuildRebind: (OO, KO, pO, XO) => this._rebuildProgram(OO, KO, pO, XO),
            defines: XO,
            transformFeedbackVaryings: this._transformFeedbackVaryings,
            name: this._key.replace(/\r/g, "").replace(/\n/g, "|"),
            createAsRaw: pO,
            disableParallelCompilation: this._disableParallelShaderCompilation,
            shaderProcessingContext: this._processingContext,
            onRenderingStateCompiled: pO => {
              KO && !OO && this._engine._deletePipelineContext(KO), pO && this._onRenderingStateCompiled(pO)
            }
          }, this._engine.createPipelineContext.bind(this._engine), this._engine._preparePipelineContextAsync.bind(this._engine), this._engine._executeWhenRenderingStateIsCompiled.bind(this._engine)), this._pipelineContext.isAsync && this._checkIsReady(KO)
        } catch (pO) {
          this._processCompilationErrors(pO, KO)
        }
      }
      _getShaderCodeAndErrorLine(OO, KO, pO) {
        const XO = pO ? /FRAGMENT SHADER ERROR: 0:(\d+?):/ : /VERTEX SHADER ERROR: 0:(\d+?):/;
        let bK = null;
        if (KO && OO) {
          const eO = KO.match(XO);
          if (eO && 2 === eO.length) {
            const KO = parseInt(eO[1]),
              XO = OO.split("\n", -1);
            XO.length >= KO && (bK = `Offending line [${KO}] in ${pO?"fragment":"vertex"} code: ${XO[KO-1]}`)
          }
        }
        return [OO, bK]
      }
      _processCompilationErrors(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        this._compilationError = "string" === typeof OO?.stack ? OO.stack : OO?.message ?? String(OO);
        const pO = this._attributesNames,
          XO = this._fallbacks;
        if (bK.b.Error("Unable to compile effect:"), bK.b.Error(`Uniforms: ${this._uniformsNames.join(" ")}`), bK.b.Error(`Attributes: ${pO.join(" ")}`), bK.b.Error("Defines:\n" + this.defines), CO.LogShaderCodeOnCompilationError) {
          let OO, KO = null,
            pO = null;
          this._pipelineContext?._getVertexShaderCode() && ([OO, KO] = this._getShaderCodeAndErrorLine(this._pipelineContext._getVertexShaderCode(), this._compilationError, !1), OO && (bK.b.Error("Vertex code:"), bK.b.Error(OO))), this._pipelineContext?._getFragmentShaderCode() && ([OO, pO] = this._getShaderCodeAndErrorLine(this._pipelineContext?._getFragmentShaderCode(), this._compilationError, !0), OO && (bK.b.Error("Fragment code:"), bK.b.Error(OO))), KO && bK.b.Error(KO), pO && bK.b.Error(pO)
        }
        bK.b.Error("Error: " + this._compilationError);
        const eO = () => {
          this.onError && this.onError(this, this._compilationError), this.onErrorObservable.notifyObservers(this), this._engine.onEffectErrorObservable.notifyObservers({
            effect: this,
            errors: this._compilationError
          })
        };
        KO && (this._pipelineContext = KO, this._isReady = !0, eO()), XO ? (this._pipelineContext = null, XO.hasMoreFallbacks ? (this._allFallbacksProcessed = !1, bK.b.Error("Trying next fallback."), this.defines = XO.reduce(this.defines, this), this._prepareEffect()) : (this._allFallbacksProcessed = !0, eO(), this.onErrorObservable.clear(), this._fallbacks && this._fallbacks.unBindMesh())) : (this._allFallbacksProcessed = !0, KO || eO())
      }
      get isSupported() {
        return "" === this._compilationError
      }
      _bindTexture(OO, KO) {
        this._engine._bindTexture(this._samplers[OO], KO, OO)
      }
      setTexture(OO, KO) {
        this._engine.setTexture(this._samplers[OO], this._uniforms[OO], KO, OO)
      }
      setTextureArray(OO, KO) {
        const pO = OO + "Ex";
        if (-1 === this._samplerList.indexOf(pO + "0")) {
          const XO = this._samplerList.indexOf(OO);
          for (let OO = 1; OO < KO.length; OO++) {
            const KO = pO + (OO - 1).toString();
            this._samplerList.splice(XO + OO, 0, KO)
          }
          let bK = 0;
          for (const OO of this._samplerList) this._samplers[OO] = bK, bK += 1
        }
        this._engine.setTextureArray(this._samplers[OO], this._uniforms[OO], KO, OO)
      }
      bindUniformBuffer(OO, KO) {
        const pO = this._uniformBuffersNames[KO];
        void 0 === pO || CO._BaseCache[pO] === OO && this._engine._features.useUBOBindingCache || (CO._BaseCache[pO] = OO, this._engine.bindUniformBufferBase(OO, pO, KO))
      }
      bindUniformBlock(OO, KO) {
        this._engine.bindUniformBlock(this._pipelineContext, OO, KO)
      }
      setInt(OO, KO) {
        return this._pipelineContext.setInt(OO, KO), this
      }
      setInt2(OO, KO, pO) {
        return this._pipelineContext.setInt2(OO, KO, pO), this
      }
      setInt3(OO, KO, pO, XO) {
        return this._pipelineContext.setInt3(OO, KO, pO, XO), this
      }
      setInt4(OO, KO, pO, XO, bK) {
        return this._pipelineContext.setInt4(OO, KO, pO, XO, bK), this
      }
      setIntArray(OO, KO) {
        return this._pipelineContext.setIntArray(OO, KO), this
      }
      setIntArray2(OO, KO) {
        return this._pipelineContext.setIntArray2(OO, KO), this
      }
      setIntArray3(OO, KO) {
        return this._pipelineContext.setIntArray3(OO, KO), this
      }
      setIntArray4(OO, KO) {
        return this._pipelineContext.setIntArray4(OO, KO), this
      }
      setUInt(OO, KO) {
        return this._pipelineContext.setUInt(OO, KO), this
      }
      setUInt2(OO, KO, pO) {
        return this._pipelineContext.setUInt2(OO, KO, pO), this
      }
      setUInt3(OO, KO, pO, XO) {
        return this._pipelineContext.setUInt3(OO, KO, pO, XO), this
      }
      setUInt4(OO, KO, pO, XO, bK) {
        return this._pipelineContext.setUInt4(OO, KO, pO, XO, bK), this
      }
      setUIntArray(OO, KO) {
        return this._pipelineContext.setUIntArray(OO, KO), this
      }
      setUIntArray2(OO, KO) {
        return this._pipelineContext.setUIntArray2(OO, KO), this
      }
      setUIntArray3(OO, KO) {
        return this._pipelineContext.setUIntArray3(OO, KO), this
      }
      setUIntArray4(OO, KO) {
        return this._pipelineContext.setUIntArray4(OO, KO), this
      }
      setFloatArray(OO, KO) {
        return this._pipelineContext.setArray(OO, KO), this
      }
      setFloatArray2(OO, KO) {
        return this._pipelineContext.setArray2(OO, KO), this
      }
      setFloatArray3(OO, KO) {
        return this._pipelineContext.setArray3(OO, KO), this
      }
      setFloatArray4(OO, KO) {
        return this._pipelineContext.setArray4(OO, KO), this
      }
      setArray(OO, KO) {
        return this._pipelineContext.setArray(OO, KO), this
      }
      setArray2(OO, KO) {
        return this._pipelineContext.setArray2(OO, KO), this
      }
      setArray3(OO, KO) {
        return this._pipelineContext.setArray3(OO, KO), this
      }
      setArray4(OO, KO) {
        return this._pipelineContext.setArray4(OO, KO), this
      }
      setMatrices(OO, KO) {
        return this._pipelineContext.setMatrices(OO, KO), this
      }
      setMatrix(OO, KO) {
        return this._pipelineContext.setMatrix(OO, KO), this
      }
      setMatrix3x3(OO, KO) {
        return this._pipelineContext.setMatrix3x3(OO, KO), this
      }
      setMatrix2x2(OO, KO) {
        return this._pipelineContext.setMatrix2x2(OO, KO), this
      }
      setFloat(OO, KO) {
        return this._pipelineContext.setFloat(OO, KO), this
      }
      setBool(OO, KO) {
        return this._pipelineContext.setInt(OO, KO ? 1 : 0), this
      }
      setVector2(OO, KO) {
        return this._pipelineContext.setVector2(OO, KO), this
      }
      setFloat2(OO, KO, pO) {
        return this._pipelineContext.setFloat2(OO, KO, pO), this
      }
      setVector3(OO, KO) {
        return this._pipelineContext.setVector3(OO, KO), this
      }
      setFloat3(OO, KO, pO, XO) {
        return this._pipelineContext.setFloat3(OO, KO, pO, XO), this
      }
      setVector4(OO, KO) {
        return this._pipelineContext.setVector4(OO, KO), this
      }
      setQuaternion(OO, KO) {
        return this._pipelineContext.setQuaternion(OO, KO), this
      }
      setFloat4(OO, KO, pO, XO, bK) {
        return this._pipelineContext.setFloat4(OO, KO, pO, XO, bK), this
      }
      setColor3(OO, KO) {
        return this._pipelineContext.setColor3(OO, KO), this
      }
      setColor4(OO, KO, pO) {
        return this._pipelineContext.setColor4(OO, KO, pO), this
      }
      setDirectColor4(OO, KO) {
        return this._pipelineContext.setDirectColor4(OO, KO), this
      }
      clearCodeCache() {
        this._vertexSourceCode = "", this._fragmentSourceCode = "", this._fragmentSourceCodeBeforeMigration = "", this._vertexSourceCodeBeforeMigration = ""
      }
      dispose() {
        if (arguments.length > 0 && void 0 !== arguments[0] && arguments[0]) this._refCount = 0;
        else {
          if (CO.PersistentMode) return;
          this._refCount--
        }
        this._refCount > 0 || this._isDisposed || (this._onReleaseEffectsObserver && (this._engine.onReleaseEffectsObservable.remove(this._onReleaseEffectsObserver), this._onReleaseEffectsObserver = null), this._pipelineContext && (0, lO.m)(this._pipelineContext), this._engine._releaseEffect(this), this.clearCodeCache(), this._isDisposed = !0)
      }
      static RegisterShader(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        KO && (eO.b.GetShadersStore(XO)[`${OO}PixelShader`] = KO), pO && (eO.b.GetShadersStore(XO)[`${OO}VertexShader`] = pO)
      }
      static ResetCache() {
        CO._BaseCache = {}
      }
    }
    CO.LogShaderCodeOnCompilationError = !0, CO.PersistentMode = !1, CO.AutomaticallyClearCodeCache = !1, CO._UniqueIdSeed = 0, CO._BaseCache = {}, CO.ShadersStore = eO.b.ShadersStore, CO.IncludesShadersStore = eO.b.IncludesShadersStore
  },
  38231: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => DO,
      g: () => NO,
      h: () => TO
    });
    var XO = pO(37902),
      bK = pO(35632),
      eO = pO(35668),
      lO = pO(38206);
    const vK = new bK.c,
      CO = new bK.c,
      hO = new bK.c,
      DO = {
        JKO: () => {},
        eyeAtCamera: !0
      };

    function MO(OO, KO, pO) {
      const XO = pO.WhO(),
        bK = KO.WhO();
      for (let eO = 0; eO < 16; eO++) XO[eO] = bK[eO];
      return XO[12] -= OO.x, XO[13] -= OO.y, XO[14] -= OO.z, pO.markAsUpdated(), pO
    }

    function aK(OO, KO, pO) {
      return (0, eO.d)(KO, CO), MO(OO, CO, hO), (0, eO.d)(hO, pO), pO
    }

    function oO(OO, KO, pO) {
      if (!DO.eyeAtCamera) return aK(OO, KO, pO);
      const XO = pO.WhO(),
        bK = KO.WhO();
      for (let eO = 0; eO < 16; eO++) XO[eO] = bK[eO];
      return XO[12] = 0, XO[13] = 0, XO[14] = 0, pO.markAsUpdated(), pO
    }

    function FO(OO, KO, pO, XO) {
      return (0, eO.m)(oO(OO, KO, XO), pO, XO), XO
    }

    function VO(OO, KO, pO, XO) {
      return (0, eO.d)(pO, CO), (0, eO.m)(KO, CO, hO), MO(OO, hO, CO), oO(OO, pO, hO), (0, eO.m)(CO, hO, XO), XO
    }

    function LO(OO, KO, pO, XO, bK, lO) {
      return (0, eO.d)(pO, CO), (0, eO.m)(KO, CO, hO), MO(OO, hO, CO), FO(OO, XO, bK, hO), (0, eO.m)(CO, hO, lO), lO
    }

    function QO(OO, KO) {
      const pO = DO.JKO();
      if (!pO || vK === KO) return KO;
      vK.updateFlag = KO.updateFlag;
      const XO = pO.floatingOriginOffset;
      switch (OO) {
        case "world":
          return MO(XO, KO, vK);
        case "view":
          return oO(XO, KO, vK);
        case "worldView":
          return VO(XO, KO, pO.getViewMatrix(), vK);
        case "viewProjection":
          return FO(XO, pO.getViewMatrix(), pO.getProjectionMatrix(), vK);
        case "worldViewProjection":
          return LO(XO, KO, pO.getTransformMatrix(), pO.getViewMatrix(), pO.getProjectionMatrix(), vK);
        default:
          if (OO.startsWith("u_")) {
            const bK = OO.toLowerCase();
            if (bK.startsWith("u_worldviewprojection")) return LO(XO, KO, pO.getTransformMatrix(), pO.getViewMatrix(), pO.getProjectionMatrix(), vK);
            if (bK.startsWith("u_viewprojection")) return FO(XO, pO.getViewMatrix(), pO.getProjectionMatrix(), vK);
            if (bK.startsWith("u_worldview")) return VO(XO, KO, pO.getViewMatrix(), vK);
            if (bK.startsWith("u_world")) return MO(XO, KO, vK);
            if (bK.startsWith("u_view")) return oO(XO, KO, vK)
          }
          return KO
      }
    }
    const zK = lO.d,
      AO = XO.e,
      fO = zK.prototype._updateMatrixForUniform,
      dO = XO.e.prototype.setMatrix;

    function TO() {
      XO.e.prototype.setMatrix = dO, AO._setMatrixOverride = void 0, zK.prototype._updateMatrixForUniform = fO, zK.prototype._updateMatrixForUniformOverride = void 0
    }

    function NO() {
      AO.prototype._setMatrixOverride = dO, AO.prototype.setMatrix = function(OO, KO) {
        return this._setMatrixOverride(OO, QO(OO, KO)), this
      }, zK.prototype._updateMatrixForUniformOverride = fO, zK.prototype._updateMatrixForUniform = function(OO, KO) {
        this._updateMatrixForUniformOverride(OO, QO(OO, KO))
      }
    }
  },
  38202: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      g: () => bK
    });
    var XO = pO(38193);

    function bK(OO, KO) {
      KO.WHITEBALANCE && OO.push("whiteBalanceMatrix"), KO.EXPOSURE && OO.push("exposureLinear"), KO.CONTRAST && OO.push("contrast"), KO.COLORGRADING && OO.push("colorTransformSettings"), (KO.VIGNETTE || KO.DITHER) && OO.push("vInverseScreenSize"), KO.VIGNETTE && (OO.push("vignetteSettings1"), OO.push("vignetteSettings2")), KO.COLORCURVES && (0, XO.d)(OO), KO.DITHER && OO.push("ditherIntensity")
    }

    function eO(OO, KO) {
      KO.COLORGRADING && OO.push("txColorTransform")
    }
  },
  38191: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => EO,
      f: () => wO
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35660),
      lO = pO(35688),
      vK = pO(35664),
      CO = pO(35632);
    const hO = [
        [0, .18006, .26352, -.24341],
        [10, .18066, .26589, -.25479],
        [20, .18133, .26846, -.26876],
        [30, .18208, .27119, -.28539],
        [40, .18293, .27407, -.3047],
        [50, .18388, .27709, -.32675],
        [60, .18494, .28021, -.35156],
        [70, .18611, .28342, -.37915],
        [80, .1874, .28668, -.40955],
        [90, .1888, .28997, -.44278],
        [100, .19032, .29326, -.47888],
        [125, .19462, .30141, -.58204],
        [150, .19962, .30921, -.70471],
        [175, .20525, .31647, -.84901],
        [200, .21142, .32312, -1.0182],
        [225, .21807, .32909, -1.2168],
        [250, .22511, .33439, -1.4512],
        [275, .23247, .33904, -1.7298],
        [300, .2401, .34308, -2.0637],
        [325, .24792, .34655, -2.4681],
        [350, .25591, .34951, -2.9641],
        [375, .264, .352, -3.5814],
        [400, .27218, .35407, -4.3633],
        [425, .28039, .35577, -5.3762],
        [450, .28863, .35714, -6.7262],
        [475, .29685, .35823, -8.5955],
        [500, .30505, .35907, -11.324],
        [525, .3132, .35968, -15.628],
        [550, .32129, .36011, -23.325],
        [575, .32931, .36038, -40.77],
        [600, .33724, .36051, -116.45]
      ],
      DO = 1e6 / hO[hO.length - 1][0],
      MO = 150;

    function aK(OO, KO) {
      const pO = Number.isNaN(OO) ? DO : Math.max(OO, DO),
        XO = (0, vK.Clamp)(1e6 / pO, hO[0][0], hO[hO.length - 1][0]);
      let bK = 0,
        eO = hO.length - 1;
      for (; eO - bK > 1;) {
        const OO = bK + eO >> 1;
        hO[OO][0] <= XO ? bK = OO : eO = OO
      }
      const lO = bK,
        [aK, oO, FO, VO] = hO[lO],
        [LO, QO, zK, AO] = hO[lO + 1],
        fO = (XO - aK) / (LO - aK),
        dO = CO.m.Lerp(new CO.m(oO, FO), new CO.m(QO, zK), fO),
        TO = CO.m.Normalize(new CO.m(1, VO)),
        NO = CO.m.Normalize(new CO.m(1, AO)),
        IO = CO.m.Normalize(CO.m.Lerp(TO, NO, fO)),
        yK = (0, vK.Clamp)(KO, -150, MO);
      dO.oDO(IO.scale(yK / 3e3));
      const gK = 2 * dO.x - 8 * dO.y + 4,
        uO = 3 * dO.x / gK,
        EO = 2 * dO.y / gK;
      return new CO.o(uO / EO, 1, (1 - uO - EO) / EO)
    }
    const oO = CO.c.FromArray([.8951, -.7502, .0389, 0, .2664, 1.7135, -.0685, 0, -.1614, .0367, 1.0296, 0, 0, 0, 0, 1]),
      FO = CO.c.Invert(oO);

    function VO(OO, KO) {
      const pO = KO > 0 ? OO / KO : 10;
      return (0, vK.Clamp)(pO, .1, 10)
    }

    function LO(OO, KO) {
      const pO = CO.o.TransformNormal(OO, oO),
        XO = CO.o.TransformNormal(KO, oO),
        bK = CO.c.FromArray([VO(XO.x, pO.x), 0, 0, 0, 0, VO(XO.y, pO.y), 0, 0, 0, 0, VO(XO.z, pO.z), 0, 0, 0, 0, 1]);
      return oO.multiply(bK).multiply(FO)
    }
    const QO = new CO.o(.95047, 1, 1.08883),
      zK = CO.c.FromArray([.4124564, .2126729, .0193339, 0, .3575761, .7151522, .119192, 0, .1804375, .072175, .9503041, 0, 0, 0, 0, 1]).multiply(LO(QO, aK(6500, 0))),
      AO = CO.c.Invert(zK),
      fO = CO.o.TransformNormal(new CO.o(1, 1, 1), zK);
    var dO = pO(38077),
      TO = pO(38193);
    let NO = (() => {
      var OO;
      let KO, pO, eO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO = [],
        QO = [],
        zK = [],
        AO = [],
        fO = [],
        NO = [],
        IO = [],
        yK = [],
        gK = [],
        uO = [],
        EO = [],
        jK = [],
        YO = [],
        wO = [],
        iK = [],
        rK = [],
        PO = [],
        mK = [],
        sO = [],
        HO = [],
        RO = [],
        SO = [],
        JO = [],
        cK = [];
      return OO = class {
        constructor() {
          this._dirty = !0, this._tempColor = new lO.g(0, 0, 0, 0), this._globalCurve = new lO.g(0, 0, 0, 0), this._highlightsCurve = new lO.g(0, 0, 0, 0), this._midtonesCurve = new lO.g(0, 0, 0, 0), this._shadowsCurve = new lO.g(0, 0, 0, 0), this._positiveCurve = new lO.g(0, 0, 0, 0), this._negativeCurve = new lO.g(0, 0, 0, 0), this._globalHue = (0, XO.i)(this, LO, 30), this._globalDensity = ((0, XO.i)(this, QO), (0, XO.i)(this, zK, 0)), this._globalSaturation = ((0, XO.i)(this, AO), (0, XO.i)(this, fO, 0)), this._globalExposure = ((0, XO.i)(this, NO), (0, XO.i)(this, IO, 0)), this._highlightsHue = ((0, XO.i)(this, yK), (0, XO.i)(this, gK, 30)), this._highlightsDensity = ((0, XO.i)(this, uO), (0, XO.i)(this, EO, 0)), this._highlightsSaturation = ((0, XO.i)(this, jK), (0, XO.i)(this, YO, 0)), this._highlightsExposure = ((0, XO.i)(this, wO), (0, XO.i)(this, iK, 0)), this._midtonesHue = ((0, XO.i)(this, rK), (0, XO.i)(this, PO, 30)), this._midtonesDensity = ((0, XO.i)(this, mK), (0, XO.i)(this, sO, 0)), this._midtonesSaturation = ((0, XO.i)(this, HO), (0, XO.i)(this, RO, 0)), this._midtonesExposure = ((0, XO.i)(this, SO), (0, XO.i)(this, JO, 0)), this._shadowsHue = ((0, XO.i)(this, cK), 30), this._shadowsDensity = 0, this._shadowsSaturation = 0, this._shadowsExposure = 0
        }
        get globalHue() {
          return this._globalHue
        }
        set globalHue(OO) {
          this._globalHue = OO, this._dirty = !0
        }
        get globalDensity() {
          return this._globalDensity
        }
        set globalDensity(OO) {
          this._globalDensity = OO, this._dirty = !0
        }
        get globalSaturation() {
          return this._globalSaturation
        }
        set globalSaturation(OO) {
          this._globalSaturation = OO, this._dirty = !0
        }
        get globalExposure() {
          return this._globalExposure
        }
        set globalExposure(OO) {
          this._globalExposure = OO, this._dirty = !0
        }
        get highlightsHue() {
          return this._highlightsHue
        }
        set highlightsHue(OO) {
          this._highlightsHue = OO, this._dirty = !0
        }
        get highlightsDensity() {
          return this._highlightsDensity
        }
        set highlightsDensity(OO) {
          this._highlightsDensity = OO, this._dirty = !0
        }
        get highlightsSaturation() {
          return this._highlightsSaturation
        }
        set highlightsSaturation(OO) {
          this._highlightsSaturation = OO, this._dirty = !0
        }
        get highlightsExposure() {
          return this._highlightsExposure
        }
        set highlightsExposure(OO) {
          this._highlightsExposure = OO, this._dirty = !0
        }
        get midtonesHue() {
          return this._midtonesHue
        }
        set midtonesHue(OO) {
          this._midtonesHue = OO, this._dirty = !0
        }
        get midtonesDensity() {
          return this._midtonesDensity
        }
        set midtonesDensity(OO) {
          this._midtonesDensity = OO, this._dirty = !0
        }
        get midtonesSaturation() {
          return this._midtonesSaturation
        }
        set midtonesSaturation(OO) {
          this._midtonesSaturation = OO, this._dirty = !0
        }
        get midtonesExposure() {
          return this._midtonesExposure
        }
        set midtonesExposure(OO) {
          this._midtonesExposure = OO, this._dirty = !0
        }
        get shadowsHue() {
          return this._shadowsHue
        }
        set shadowsHue(OO) {
          this._shadowsHue = OO, this._dirty = !0
        }
        get shadowsDensity() {
          return this._shadowsDensity
        }
        set shadowsDensity(OO) {
          this._shadowsDensity = OO, this._dirty = !0
        }
        get shadowsSaturation() {
          return this._shadowsSaturation
        }
        set shadowsSaturation(OO) {
          this._shadowsSaturation = OO, this._dirty = !0
        }
        get shadowsExposure() {
          return this._shadowsExposure
        }
        set shadowsExposure(OO) {
          this._shadowsExposure = OO, this._dirty = !0
        }
        getClassName() {
          return "ColorCurves"
        }
        _getColorGradingDataToRef(KO, pO, XO, bK, eO) {
          null != KO && (KO = OO._Clamp(KO, 0, 360), pO = OO._Clamp(pO, -100, 100), XO = OO._Clamp(XO, -100, 100), bK = OO._Clamp(bK, -100, 100), pO = OO._ApplyColorGradingSliderNonlinear(pO), pO *= .5, bK = OO._ApplyColorGradingSliderNonlinear(bK), pO < 0 && (pO *= -1, KO = (KO + 180) % 360), OO._FromHSBToRef(KO, pO, 50 + .25 * bK, eO), eO.scaleToRef(2, eO), eO.a = 1 + .01 * XO)
        }
        static _ApplyColorGradingSliderNonlinear(OO) {
          OO /= 100;
          let KO = Math.abs(OO);
          return KO = Math.pow(KO, 2), OO < 0 && (KO *= -1), KO *= 100, KO
        }
        static _FromHSBToRef(KO, pO, XO, bK) {
          let eO = OO._Clamp(KO, 0, 360);
          const lO = OO._Clamp(pO / 100, 0, 1),
            vK = OO._Clamp(XO / 100, 0, 1);
          if (0 === lO) bK.r = vK, bK.g = vK, bK.b = vK;
          else {
            eO /= 60;
            const OO = Math.floor(eO),
              KO = eO - OO,
              pO = vK * (1 - lO),
              XO = vK * (1 - lO * KO),
              CO = vK * (1 - lO * (1 - KO));
            switch (OO) {
              case 0:
                bK.r = vK, bK.g = CO, bK.b = pO;
                break;
              case 1:
                bK.r = XO, bK.g = vK, bK.b = pO;
                break;
              case 2:
                bK.r = pO, bK.g = vK, bK.b = CO;
                break;
              case 3:
                bK.r = pO, bK.g = XO, bK.b = vK;
                break;
              case 4:
                bK.r = CO, bK.g = pO, bK.b = vK;
                break;
              default:
                bK.r = vK, bK.g = pO, bK.b = XO
            }
          }
          bK.a = 1
        }
        static _Clamp(OO, KO, pO) {
          return Math.min(Math.max(OO, KO), pO)
        }
        clone() {
          return dO.c.Clone((() => new OO), this)
        }
        serialize() {
          return dO.c.Serialize(this)
        }
        _bind(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "vCameraColorCurvePositive",
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "vCameraColorCurveNeutral",
            XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "vCameraColorCurveNegative";
          this._dirty && (this._dirty = !1, this._getColorGradingDataToRef(this._globalHue, this._globalDensity, this._globalSaturation, this._globalExposure, this._globalCurve), this._getColorGradingDataToRef(this._highlightsHue, this._highlightsDensity, this._highlightsSaturation, this._highlightsExposure, this._tempColor), this._tempColor.multiplyToRef(this._globalCurve, this._highlightsCurve), this._getColorGradingDataToRef(this._midtonesHue, this._midtonesDensity, this._midtonesSaturation, this._midtonesExposure, this._tempColor), this._tempColor.multiplyToRef(this._globalCurve, this._midtonesCurve), this._getColorGradingDataToRef(this._shadowsHue, this._shadowsDensity, this._shadowsSaturation, this._shadowsExposure, this._tempColor), this._tempColor.multiplyToRef(this._globalCurve, this._shadowsCurve), this._highlightsCurve.subtractToRef(this._midtonesCurve, this._positiveCurve), this._midtonesCurve.subtractToRef(this._shadowsCurve, this._negativeCurve)), OO && (OO.setFloat4(KO, this._positiveCurve.r, this._positiveCurve.g, this._positiveCurve.b, this._positiveCurve.a), OO.setFloat4(pO, this._midtonesCurve.r, this._midtonesCurve.g, this._midtonesCurve.b, this._midtonesCurve.a), OO.setFloat4(XO, this._negativeCurve.r, this._negativeCurve.g, this._negativeCurve.b, this._negativeCurve.a))
        }
      }, (() => {
        const lO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], eO = [(0, bK.M)()], vK = [(0, bK.M)()], CO = [(0, bK.M)()], hO = [(0, bK.M)()], DO = [(0, bK.M)()], MO = [(0, bK.M)()], aK = [(0, bK.M)()], oO = [(0, bK.M)()], FO = [(0, bK.M)()], VO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "_globalHue",
          static: !1,
          private: !1,
          access: {
            has: OO => "_globalHue" in OO,
            get: OO => OO._globalHue,
            set: (OO, KO) => {
              OO._globalHue = KO
            }
          },
          metadata: lO
        }, LO, QO), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "_globalDensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "_globalDensity" in OO,
            get: OO => OO._globalDensity,
            set: (OO, KO) => {
              OO._globalDensity = KO
            }
          },
          metadata: lO
        }, zK, AO), (0, XO.f)(null, null, eO, {
          kind: "field",
          name: "_globalSaturation",
          static: !1,
          private: !1,
          access: {
            has: OO => "_globalSaturation" in OO,
            get: OO => OO._globalSaturation,
            set: (OO, KO) => {
              OO._globalSaturation = KO
            }
          },
          metadata: lO
        }, fO, NO), (0, XO.f)(null, null, vK, {
          kind: "field",
          name: "_globalExposure",
          static: !1,
          private: !1,
          access: {
            has: OO => "_globalExposure" in OO,
            get: OO => OO._globalExposure,
            set: (OO, KO) => {
              OO._globalExposure = KO
            }
          },
          metadata: lO
        }, IO, yK), (0, XO.f)(null, null, CO, {
          kind: "field",
          name: "_highlightsHue",
          static: !1,
          private: !1,
          access: {
            has: OO => "_highlightsHue" in OO,
            get: OO => OO._highlightsHue,
            set: (OO, KO) => {
              OO._highlightsHue = KO
            }
          },
          metadata: lO
        }, gK, uO), (0, XO.f)(null, null, hO, {
          kind: "field",
          name: "_highlightsDensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "_highlightsDensity" in OO,
            get: OO => OO._highlightsDensity,
            set: (OO, KO) => {
              OO._highlightsDensity = KO
            }
          },
          metadata: lO
        }, EO, jK), (0, XO.f)(null, null, DO, {
          kind: "field",
          name: "_highlightsSaturation",
          static: !1,
          private: !1,
          access: {
            has: OO => "_highlightsSaturation" in OO,
            get: OO => OO._highlightsSaturation,
            set: (OO, KO) => {
              OO._highlightsSaturation = KO
            }
          },
          metadata: lO
        }, YO, wO), (0, XO.f)(null, null, MO, {
          kind: "field",
          name: "_highlightsExposure",
          static: !1,
          private: !1,
          access: {
            has: OO => "_highlightsExposure" in OO,
            get: OO => OO._highlightsExposure,
            set: (OO, KO) => {
              OO._highlightsExposure = KO
            }
          },
          metadata: lO
        }, iK, rK), (0, XO.f)(null, null, aK, {
          kind: "field",
          name: "_midtonesHue",
          static: !1,
          private: !1,
          access: {
            has: OO => "_midtonesHue" in OO,
            get: OO => OO._midtonesHue,
            set: (OO, KO) => {
              OO._midtonesHue = KO
            }
          },
          metadata: lO
        }, PO, mK), (0, XO.f)(null, null, oO, {
          kind: "field",
          name: "_midtonesDensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "_midtonesDensity" in OO,
            get: OO => OO._midtonesDensity,
            set: (OO, KO) => {
              OO._midtonesDensity = KO
            }
          },
          metadata: lO
        }, sO, HO), (0, XO.f)(null, null, FO, {
          kind: "field",
          name: "_midtonesSaturation",
          static: !1,
          private: !1,
          access: {
            has: OO => "_midtonesSaturation" in OO,
            get: OO => OO._midtonesSaturation,
            set: (OO, KO) => {
              OO._midtonesSaturation = KO
            }
          },
          metadata: lO
        }, RO, SO), (0, XO.f)(null, null, VO, {
          kind: "field",
          name: "_midtonesExposure",
          static: !1,
          private: !1,
          access: {
            has: OO => "_midtonesExposure" in OO,
            get: OO => OO._midtonesExposure,
            set: (OO, KO) => {
              OO._midtonesExposure = KO
            }
          },
          metadata: lO
        }, JO, cK), lO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: lO
        })
      })(), OO.PrepareUniforms = TO.d, OO
    })();

    function IO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "vCameraColorCurvePositive",
        XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "vCameraColorCurveNeutral",
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "vCameraColorCurveNegative";
      OO._bind(KO, pO, XO, bK)
    }
    var yK = pO(37996),
      gK = pO(38202),
      uO = pO(35676);
    let EO = (() => {
        var OO;
        let KO, pO, hO, oO, FO, VO, QO, TO, uO, EO, jK, YO, wO, iK, rK, PO, mK, sO, HO, RO, SO, JO, cK, BO, ZO, GO, qK, xK, nO = [],
          WO = [],
          tK = [],
          kK = [],
          UO = [],
          OK = [],
          KK = [],
          pK = [],
          XK = [],
          bp = [],
          eK = [],
          lK = [],
          vp = [],
          CK = [],
          hK = [],
          DK = [],
          MK = [],
          ap = [],
          oK = [],
          FK = [],
          VK = [],
          LK = [],
          QK = [],
          zp = [],
          AK = [],
          fK = [],
          dK = [],
          TK = [],
          NK = [],
          IK = [],
          yp = [],
          gp = [],
          uK = [],
          EK = [],
          jp = [],
          YK = [],
          wK = [],
          ip = [],
          rp = [],
          PK = [],
          mp = [],
          sK = [],
          HK = [],
          RK = [],
          SK = [],
          JK = [],
          cp = [],
          BK = [],
          ZK = [],
          GK = [],
          qp = [],
          xp = [],
          nK = [],
          WK = [],
          tp = [],
          kp = [];
        return OO = class {
          constructor() {
            this.colorCurves = (0, XO.i)(this, nO, new NO), this._colorCurvesEnabled = ((0, XO.i)(this, WO), (0, XO.i)(this, tK, !1)), this._colorGradingTexture = ((0, XO.i)(this, kK), (0, XO.i)(this, UO, void 0)), this._colorGradingEnabled = ((0, XO.i)(this, OK), (0, XO.i)(this, KK, !1)), this._colorGradingWithGreenDepth = ((0, XO.i)(this, pK), (0, XO.i)(this, XK, !0)), this._colorGradingBGR = ((0, XO.i)(this, bp), (0, XO.i)(this, eK, !0)), this._exposure = ((0, XO.i)(this, lK), (0, XO.i)(this, vp, 1)), this._toneMappingEnabled = ((0, XO.i)(this, CK), (0, XO.i)(this, hK, !1)), this._toneMappingType = ((0, XO.i)(this, DK), (0, XO.i)(this, MK, OO.TONEMAPPING_STANDARD)), this._contrast = ((0, XO.i)(this, ap), (0, XO.i)(this, oK, 1)), this._whiteBalanceEnabled = ((0, XO.i)(this, FK), (0, XO.i)(this, VK, !1)), this._temperature = ((0, XO.i)(this, LK), (0, XO.i)(this, QK, 6500)), this._tint = ((0, XO.i)(this, zp), (0, XO.i)(this, AK, 0)), this._whiteBalanceMatrix = ((0, XO.i)(this, fK), null), this._whiteBalanceMatrixTemperature = null, this._whiteBalanceMatrixTint = null, this.vignetteStretch = (0, XO.i)(this, dK, 0), this.vignetteCenterX = ((0, XO.i)(this, TK), (0, XO.i)(this, NK, 0)), this.vignetteCenterY = ((0, XO.i)(this, IK), (0, XO.i)(this, yp, 0)), this.vignetteWeight = ((0, XO.i)(this, gp), (0, XO.i)(this, uK, 1.5)), this.vignetteColor = ((0, XO.i)(this, EK), (0, XO.i)(this, jp, new lO.g(0, 0, 0, 0))), this.vignetteCameraFov = ((0, XO.i)(this, YK), (0, XO.i)(this, wK, .5)), this._vignetteBlendMode = ((0, XO.i)(this, ip), (0, XO.i)(this, rp, OO.VIGNETTEMODE_MULTIPLY)), this._vignetteEnabled = ((0, XO.i)(this, PK), (0, XO.i)(this, mp, !1)), this._ditheringEnabled = ((0, XO.i)(this, sK), (0, XO.i)(this, HK, !1)), this._ditheringIntensity = ((0, XO.i)(this, RK), (0, XO.i)(this, SK, 1 / 255)), this._skipFinalColorClamp = ((0, XO.i)(this, JK), (0, XO.i)(this, cp, !1)), this._applyByPostProcess = ((0, XO.i)(this, BK), (0, XO.i)(this, ZK, !1)), this._isEnabled = ((0, XO.i)(this, GK), (0, XO.i)(this, qp, !0)), this.outputTextureWidth = ((0, XO.i)(this, xp), (0, XO.i)(this, nK, 0)), this.outputTextureHeight = ((0, XO.i)(this, WK), (0, XO.i)(this, tp, 0)), this.onUpdateParameters = ((0, XO.i)(this, kp), new eO.e)
          }
          get colorCurvesEnabled() {
            return this._colorCurvesEnabled
          }
          set colorCurvesEnabled(OO) {
            this._colorCurvesEnabled !== OO && (this._colorCurvesEnabled = OO, this._updateParameters())
          }
          get colorGradingTexture() {
            return this._colorGradingTexture
          }
          set colorGradingTexture(OO) {
            this._colorGradingTexture !== OO && (this._colorGradingTexture = OO, this._updateParameters())
          }
          get colorGradingEnabled() {
            return this._colorGradingEnabled
          }
          set colorGradingEnabled(OO) {
            this._colorGradingEnabled !== OO && (this._colorGradingEnabled = OO, this._updateParameters())
          }
          get colorGradingWithGreenDepth() {
            return this._colorGradingWithGreenDepth
          }
          set colorGradingWithGreenDepth(OO) {
            this._colorGradingWithGreenDepth !== OO && (this._colorGradingWithGreenDepth = OO, this._updateParameters())
          }
          get colorGradingBGR() {
            return this._colorGradingBGR
          }
          set colorGradingBGR(OO) {
            this._colorGradingBGR !== OO && (this._colorGradingBGR = OO, this._updateParameters())
          }
          get exposure() {
            return this._exposure
          }
          set exposure(OO) {
            this._exposure !== OO && (this._exposure = OO, this._updateParameters())
          }
          get toneMappingEnabled() {
            return this._toneMappingEnabled
          }
          set toneMappingEnabled(OO) {
            this._toneMappingEnabled !== OO && (this._toneMappingEnabled = OO, this._updateParameters())
          }
          get toneMappingType() {
            return this._toneMappingType
          }
          set toneMappingType(OO) {
            this._toneMappingType !== OO && (this._toneMappingType = OO, this._updateParameters())
          }
          get contrast() {
            return this._contrast
          }
          set contrast(OO) {
            this._contrast !== OO && (this._contrast = OO, this._updateParameters())
          }
          get whiteBalanceEnabled() {
            return this._whiteBalanceEnabled
          }
          set whiteBalanceEnabled(OO) {
            this._whiteBalanceEnabled !== OO && (this._whiteBalanceEnabled = OO, this._updateParameters())
          }
          get temperature() {
            return this._temperature
          }
          set temperature(OO) {
            OO = Number.isNaN(OO) ? DO : Math.max(OO, DO), this._temperature !== OO && (this._temperature = OO, this._updateParameters())
          }
          get tint() {
            return this._tint
          }
          set tint(OO) {
            OO = (0, vK.Clamp)(OO, -150, MO), this._tint !== OO && (this._tint = OO, this._updateParameters())
          }
          _getWhiteBalanceMatrix() {
            return null !== this._whiteBalanceMatrix && this._whiteBalanceMatrixTemperature === this._temperature && this._whiteBalanceMatrixTint === this._tint || (this._whiteBalanceMatrixTemperature = this._temperature, this._whiteBalanceMatrixTint = this._tint, this._whiteBalanceMatrix = function(OO, KO) {
              const pO = LO(aK(OO, KO), fO),
                XO = zK.multiply(pO).multiply(AO);
              return CO.c.GetAsMatrix3x3(XO)
            }(this._temperature, this._tint)), this._whiteBalanceMatrix
          }
          get vignetteCentreY() {
            return this.vignetteCenterY
          }
          set vignetteCentreY(OO) {
            this.vignetteCenterY = OO
          }
          get vignetteCentreX() {
            return this.vignetteCenterX
          }
          set vignetteCentreX(OO) {
            this.vignetteCenterX = OO
          }
          get vignetteBlendMode() {
            return this._vignetteBlendMode
          }
          set vignetteBlendMode(OO) {
            this._vignetteBlendMode !== OO && (this._vignetteBlendMode = OO, this._updateParameters())
          }
          get vignetteEnabled() {
            return this._vignetteEnabled
          }
          set vignetteEnabled(OO) {
            this._vignetteEnabled !== OO && (this._vignetteEnabled = OO, this._updateParameters())
          }
          get ditheringEnabled() {
            return this._ditheringEnabled
          }
          set ditheringEnabled(OO) {
            this._ditheringEnabled !== OO && (this._ditheringEnabled = OO, this._updateParameters())
          }
          get ditheringIntensity() {
            return this._ditheringIntensity
          }
          set ditheringIntensity(OO) {
            this._ditheringIntensity !== OO && (this._ditheringIntensity = OO, this._updateParameters())
          }
          get skipFinalColorClamp() {
            return this._skipFinalColorClamp
          }
          set skipFinalColorClamp(OO) {
            this._skipFinalColorClamp !== OO && (this._skipFinalColorClamp = OO, this._updateParameters())
          }
          get applyByPostProcess() {
            return this._applyByPostProcess
          }
          set applyByPostProcess(OO) {
            this._applyByPostProcess !== OO && (this._applyByPostProcess = OO, this._updateParameters())
          }
          get isEnabled() {
            return this._isEnabled
          }
          set isEnabled(OO) {
            this._isEnabled !== OO && (this._isEnabled = OO, this._updateParameters())
          }
          _updateParameters() {
            this.onUpdateParameters.notifyObservers(this)
          }
          getClassName() {
            return "ImageProcessingConfiguration"
          }
          prepareDefines(KO) {
            if ((arguments.length > 1 && void 0 !== arguments[1] && arguments[1]) !== this.applyByPostProcess || !this._isEnabled) return KO.WHITEBALANCE = !1, KO.VIGNETTE = !1, KO.TONEMAPPING = 0, KO.CONTRAST = !1, KO.EXPOSURE = !1, KO.COLORCURVES = !1, KO.COLORGRADING = !1, KO.COLORGRADING3D = !1, KO.DITHER = !1, KO.IMAGEPROCESSING = !1, KO.SKIPFINALCOLORCLAMP = this.skipFinalColorClamp, void(KO.IMAGEPROCESSINGPOSTPROCESS = this.applyByPostProcess && this._isEnabled);
            if (KO.WHITEBALANCE = this._whiteBalanceEnabled, KO.VIGNETTE = this.vignetteEnabled, KO.VIGNETTEBLENDMODEMULTIPLY = this.vignetteBlendMode === OO._VIGNETTEMODE_MULTIPLY, KO.VIGNETTEBLENDMODEOPAQUE = !KO.VIGNETTEBLENDMODEMULTIPLY, this._toneMappingEnabled) switch (this._toneMappingType) {
              case OO.TONEMAPPING_KHR_PBR_NEUTRAL:
                KO.TONEMAPPING = 3;
                break;
              case OO.TONEMAPPING_ACES:
                KO.TONEMAPPING = 2;
                break;
              default:
                KO.TONEMAPPING = 1
            } else KO.TONEMAPPING = 0;
            KO.CONTRAST = 1 !== this.contrast, KO.EXPOSURE = 1 !== this.exposure, KO.COLORCURVES = this.colorCurvesEnabled && !!this.colorCurves, KO.COLORGRADING = this.colorGradingEnabled && !!this.colorGradingTexture, KO.COLORGRADING ? KO.COLORGRADING3D = this.colorGradingTexture.is3D : KO.COLORGRADING3D = !1, KO.SAMPLER3DGREENDEPTH = this.colorGradingWithGreenDepth, KO.SAMPLER3DBGRMAP = this.colorGradingBGR, KO.DITHER = this._ditheringEnabled, KO.IMAGEPROCESSINGPOSTPROCESS = this.applyByPostProcess, KO.SKIPFINALCOLORCLAMP = this.skipFinalColorClamp, KO.IMAGEPROCESSING = KO.WHITEBALANCE || KO.VIGNETTE || !!KO.TONEMAPPING || KO.CONTRAST || KO.EXPOSURE || KO.COLORCURVES || KO.COLORGRADING || KO.DITHER
          }
          isReady() {
            return !this.colorGradingEnabled || !this.colorGradingTexture || this.colorGradingTexture.isReady()
          }
          bind(OO, KO) {
            if (this._whiteBalanceEnabled && OO.setMatrix3x3("whiteBalanceMatrix", this._getWhiteBalanceMatrix()), this._colorCurvesEnabled && this.colorCurves && IO(this.colorCurves, OO), this._vignetteEnabled || this._ditheringEnabled) {
              const pO = 1 / (this.outputTextureWidth || OO.qb().getRenderWidth()),
                XO = 1 / (this.outputTextureHeight || OO.qb().getRenderHeight());
              if (OO.setFloat2("vInverseScreenSize", pO, XO), this._ditheringEnabled && OO.setFloat("ditherIntensity", .5 * this._ditheringIntensity), this._vignetteEnabled) {
                const bK = null != KO ? KO : XO / pO;
                let eO = Math.tan(.5 * this.vignetteCameraFov),
                  lO = eO * bK;
                const vK = Math.sqrt(lO * eO);
                lO = (0, yK.l)(lO, vK, this.vignetteStretch), eO = (0, yK.l)(eO, vK, this.vignetteStretch), OO.setFloat4("vignetteSettings1", lO, eO, -lO * this.vignetteCenterX, -eO * this.vignetteCenterY);
                const CO = -2 * this.vignetteWeight;
                OO.setFloat4("vignetteSettings2", this.vignetteColor.r, this.vignetteColor.g, this.vignetteColor.b, CO)
              }
            }
            if (OO.setFloat("exposureLinear", this.exposure), OO.setFloat("contrast", this.contrast), this.colorGradingTexture) {
              OO.setTexture("txColorTransform", this.colorGradingTexture);
              const KO = this.colorGradingTexture.getSize().height;
              OO.setFloat4("colorTransformSettings", (KO - 1) / KO, .5 / KO, KO, this.colorGradingTexture.level)
            }
          }
          clone() {
            return dO.c.Clone((() => new OO), this)
          }
          serialize() {
            return dO.c.Serialize(this)
          }
          static get VIGNETTEMODE_MULTIPLY() {
            return this._VIGNETTEMODE_MULTIPLY
          }
          static get VIGNETTEMODE_OPAQUE() {
            return this._VIGNETTEMODE_OPAQUE
          }
        }, (() => {
          const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          KO = [(0, bK.p)()], pO = [(0, bK.M)()], hO = [(0, bK.I)("colorGradingTexture")], oO = [(0, bK.M)()], FO = [(0, bK.M)()], VO = [(0, bK.M)()], QO = [(0, bK.M)()], TO = [(0, bK.M)()], uO = [(0, bK.M)()], EO = [(0, bK.M)()], jK = [(0, bK.M)()], YO = [(0, bK.M)()], wO = [(0, bK.M)()], iK = [(0, bK.M)()], rK = [(0, bK.M)()], PO = [(0, bK.M)()], mK = [(0, bK.M)()], sO = [(0, bK.v)()], HO = [(0, bK.M)()], RO = [(0, bK.M)()], SO = [(0, bK.M)()], JO = [(0, bK.M)()], cK = [(0, bK.M)()], BO = [(0, bK.M)()], ZO = [(0, bK.M)()], GO = [(0, bK.M)()], qK = [(0, bK.M)()], xK = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "colorCurves",
            static: !1,
            private: !1,
            access: {
              has: OO => "colorCurves" in OO,
              get: OO => OO.colorCurves,
              set: (OO, KO) => {
                OO.colorCurves = KO
              }
            },
            metadata: eO
          }, nO, WO), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "_colorCurvesEnabled",
            static: !1,
            private: !1,
            access: {
              has: OO => "_colorCurvesEnabled" in OO,
              get: OO => OO._colorCurvesEnabled,
              set: (OO, KO) => {
                OO._colorCurvesEnabled = KO
              }
            },
            metadata: eO
          }, tK, kK), (0, XO.f)(null, null, hO, {
            kind: "field",
            name: "_colorGradingTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_colorGradingTexture" in OO,
              get: OO => OO._colorGradingTexture,
              set: (OO, KO) => {
                OO._colorGradingTexture = KO
              }
            },
            metadata: eO
          }, UO, OK), (0, XO.f)(null, null, oO, {
            kind: "field",
            name: "_colorGradingEnabled",
            static: !1,
            private: !1,
            access: {
              has: OO => "_colorGradingEnabled" in OO,
              get: OO => OO._colorGradingEnabled,
              set: (OO, KO) => {
                OO._colorGradingEnabled = KO
              }
            },
            metadata: eO
          }, KK, pK), (0, XO.f)(null, null, FO, {
            kind: "field",
            name: "_colorGradingWithGreenDepth",
            static: !1,
            private: !1,
            access: {
              has: OO => "_colorGradingWithGreenDepth" in OO,
              get: OO => OO._colorGradingWithGreenDepth,
              set: (OO, KO) => {
                OO._colorGradingWithGreenDepth = KO
              }
            },
            metadata: eO
          }, XK, bp), (0, XO.f)(null, null, VO, {
            kind: "field",
            name: "_colorGradingBGR",
            static: !1,
            private: !1,
            access: {
              has: OO => "_colorGradingBGR" in OO,
              get: OO => OO._colorGradingBGR,
              set: (OO, KO) => {
                OO._colorGradingBGR = KO
              }
            },
            metadata: eO
          }, eK, lK), (0, XO.f)(null, null, QO, {
            kind: "field",
            name: "_exposure",
            static: !1,
            private: !1,
            access: {
              has: OO => "_exposure" in OO,
              get: OO => OO._exposure,
              set: (OO, KO) => {
                OO._exposure = KO
              }
            },
            metadata: eO
          }, vp, CK), (0, XO.f)(null, null, TO, {
            kind: "field",
            name: "_toneMappingEnabled",
            static: !1,
            private: !1,
            access: {
              has: OO => "_toneMappingEnabled" in OO,
              get: OO => OO._toneMappingEnabled,
              set: (OO, KO) => {
                OO._toneMappingEnabled = KO
              }
            },
            metadata: eO
          }, hK, DK), (0, XO.f)(null, null, uO, {
            kind: "field",
            name: "_toneMappingType",
            static: !1,
            private: !1,
            access: {
              has: OO => "_toneMappingType" in OO,
              get: OO => OO._toneMappingType,
              set: (OO, KO) => {
                OO._toneMappingType = KO
              }
            },
            metadata: eO
          }, MK, ap), (0, XO.f)(null, null, EO, {
            kind: "field",
            name: "_contrast",
            static: !1,
            private: !1,
            access: {
              has: OO => "_contrast" in OO,
              get: OO => OO._contrast,
              set: (OO, KO) => {
                OO._contrast = KO
              }
            },
            metadata: eO
          }, oK, FK), (0, XO.f)(null, null, jK, {
            kind: "field",
            name: "_whiteBalanceEnabled",
            static: !1,
            private: !1,
            access: {
              has: OO => "_whiteBalanceEnabled" in OO,
              get: OO => OO._whiteBalanceEnabled,
              set: (OO, KO) => {
                OO._whiteBalanceEnabled = KO
              }
            },
            metadata: eO
          }, VK, LK), (0, XO.f)(null, null, YO, {
            kind: "field",
            name: "_temperature",
            static: !1,
            private: !1,
            access: {
              has: OO => "_temperature" in OO,
              get: OO => OO._temperature,
              set: (OO, KO) => {
                OO._temperature = KO
              }
            },
            metadata: eO
          }, QK, zp), (0, XO.f)(null, null, wO, {
            kind: "field",
            name: "_tint",
            static: !1,
            private: !1,
            access: {
              has: OO => "_tint" in OO,
              get: OO => OO._tint,
              set: (OO, KO) => {
                OO._tint = KO
              }
            },
            metadata: eO
          }, AK, fK), (0, XO.f)(null, null, iK, {
            kind: "field",
            name: "vignetteStretch",
            static: !1,
            private: !1,
            access: {
              has: OO => "vignetteStretch" in OO,
              get: OO => OO.vignetteStretch,
              set: (OO, KO) => {
                OO.vignetteStretch = KO
              }
            },
            metadata: eO
          }, dK, TK), (0, XO.f)(null, null, rK, {
            kind: "field",
            name: "vignetteCenterX",
            static: !1,
            private: !1,
            access: {
              has: OO => "vignetteCenterX" in OO,
              get: OO => OO.vignetteCenterX,
              set: (OO, KO) => {
                OO.vignetteCenterX = KO
              }
            },
            metadata: eO
          }, NK, IK), (0, XO.f)(null, null, PO, {
            kind: "field",
            name: "vignetteCenterY",
            static: !1,
            private: !1,
            access: {
              has: OO => "vignetteCenterY" in OO,
              get: OO => OO.vignetteCenterY,
              set: (OO, KO) => {
                OO.vignetteCenterY = KO
              }
            },
            metadata: eO
          }, yp, gp), (0, XO.f)(null, null, mK, {
            kind: "field",
            name: "vignetteWeight",
            static: !1,
            private: !1,
            access: {
              has: OO => "vignetteWeight" in OO,
              get: OO => OO.vignetteWeight,
              set: (OO, KO) => {
                OO.vignetteWeight = KO
              }
            },
            metadata: eO
          }, uK, EK), (0, XO.f)(null, null, sO, {
            kind: "field",
            name: "vignetteColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "vignetteColor" in OO,
              get: OO => OO.vignetteColor,
              set: (OO, KO) => {
                OO.vignetteColor = KO
              }
            },
            metadata: eO
          }, jp, YK), (0, XO.f)(null, null, HO, {
            kind: "field",
            name: "vignetteCameraFov",
            static: !1,
            private: !1,
            access: {
              has: OO => "vignetteCameraFov" in OO,
              get: OO => OO.vignetteCameraFov,
              set: (OO, KO) => {
                OO.vignetteCameraFov = KO
              }
            },
            metadata: eO
          }, wK, ip), (0, XO.f)(null, null, RO, {
            kind: "field",
            name: "_vignetteBlendMode",
            static: !1,
            private: !1,
            access: {
              has: OO => "_vignetteBlendMode" in OO,
              get: OO => OO._vignetteBlendMode,
              set: (OO, KO) => {
                OO._vignetteBlendMode = KO
              }
            },
            metadata: eO
          }, rp, PK), (0, XO.f)(null, null, SO, {
            kind: "field",
            name: "_vignetteEnabled",
            static: !1,
            private: !1,
            access: {
              has: OO => "_vignetteEnabled" in OO,
              get: OO => OO._vignetteEnabled,
              set: (OO, KO) => {
                OO._vignetteEnabled = KO
              }
            },
            metadata: eO
          }, mp, sK), (0, XO.f)(null, null, JO, {
            kind: "field",
            name: "_ditheringEnabled",
            static: !1,
            private: !1,
            access: {
              has: OO => "_ditheringEnabled" in OO,
              get: OO => OO._ditheringEnabled,
              set: (OO, KO) => {
                OO._ditheringEnabled = KO
              }
            },
            metadata: eO
          }, HK, RK), (0, XO.f)(null, null, cK, {
            kind: "field",
            name: "_ditheringIntensity",
            static: !1,
            private: !1,
            access: {
              has: OO => "_ditheringIntensity" in OO,
              get: OO => OO._ditheringIntensity,
              set: (OO, KO) => {
                OO._ditheringIntensity = KO
              }
            },
            metadata: eO
          }, SK, JK), (0, XO.f)(null, null, BO, {
            kind: "field",
            name: "_skipFinalColorClamp",
            static: !1,
            private: !1,
            access: {
              has: OO => "_skipFinalColorClamp" in OO,
              get: OO => OO._skipFinalColorClamp,
              set: (OO, KO) => {
                OO._skipFinalColorClamp = KO
              }
            },
            metadata: eO
          }, cp, BK), (0, XO.f)(null, null, ZO, {
            kind: "field",
            name: "_applyByPostProcess",
            static: !1,
            private: !1,
            access: {
              has: OO => "_applyByPostProcess" in OO,
              get: OO => OO._applyByPostProcess,
              set: (OO, KO) => {
                OO._applyByPostProcess = KO
              }
            },
            metadata: eO
          }, ZK, GK), (0, XO.f)(null, null, GO, {
            kind: "field",
            name: "_isEnabled",
            static: !1,
            private: !1,
            access: {
              has: OO => "_isEnabled" in OO,
              get: OO => OO._isEnabled,
              set: (OO, KO) => {
                OO._isEnabled = KO
              }
            },
            metadata: eO
          }, qp, xp), (0, XO.f)(null, null, qK, {
            kind: "field",
            name: "outputTextureWidth",
            static: !1,
            private: !1,
            access: {
              has: OO => "outputTextureWidth" in OO,
              get: OO => OO.outputTextureWidth,
              set: (OO, KO) => {
                OO.outputTextureWidth = KO
              }
            },
            metadata: eO
          }, nK, WK), (0, XO.f)(null, null, xK, {
            kind: "field",
            name: "outputTextureHeight",
            static: !1,
            private: !1,
            access: {
              has: OO => "outputTextureHeight" in OO,
              get: OO => OO.outputTextureHeight,
              set: (OO, KO) => {
                OO.outputTextureHeight = KO
              }
            },
            metadata: eO
          }, tp, kp), eO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: eO
          })
        })(), OO.TONEMAPPING_STANDARD = 0, OO.TONEMAPPING_ACES = 1, OO.TONEMAPPING_KHR_PBR_NEUTRAL = 2, OO.PrepareUniforms = gK.g, OO.PrepareSamplers = gK.d, OO._VIGNETTEMODE_MULTIPLY = 0, OO._VIGNETTEMODE_OPAQUE = 1, OO
      })(),
      jK = !1;

    function YO(OO) {
      const KO = dO.c.Parse((() => new EO), OO, null, null);
      return void 0 !== OO.vignetteCentreX && (KO.vignetteCenterX = OO.vignetteCentreX), void 0 !== OO.vignetteCentreY && (KO.vignetteCenterY = OO.vignetteCentreY), KO
    }

    function wO() {
      jK || (jK = !0, EO.Parse = YO, dO.c._ImageProcessingConfigurationParser = YO, (0, uO.h)("BABYLON.ImageProcessingConfiguration", EO))
    }
  },
  38206: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(37061),
      bK = pO(38172);
    class eO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 ? arguments[3] : void 0,
          bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
          eO = arguments.length > 5 ? arguments[5] : void 0;
        this._uniformNames = [], this._valueCache = {}, this._engine = OO, this._noUBO = !OO.supportsUniformBuffers || bK, this._dynamic = pO, this._name = XO ?? "no-name", this._data = KO || [], this._uniformLocations = {}, this._uniformSizes = {}, this._uniformArraySizes = {}, this._uniformLocationPointer = 0, this._needSync = !1, this._dataGeneration = 0, this._trackUBOsInFrame = !1, (void 0 === eO && this._engine._features.trackUbosInFrame || !0 === eO) && (this._buffers = [], this._bufferIndex = -1, this._bufferUpdatedLastFrame = !1, this._createBufferOnWrite = !1, this._currentFrameId = 0, this._trackUBOsInFrame = !0, this._resetOwnerSlots()), this._noUBO ? (this.updateMatrix3x3 = this._updateMatrix3x3ForEffect, this.updateMatrix2x2 = this._updateMatrix2x2ForEffect, this.updateFloat = this._updateFloatForEffect, this.updateFloat2 = this._updateFloat2ForEffect, this.updateFloat3 = this._updateFloat3ForEffect, this.updateFloat4 = this._updateFloat4ForEffect, this.updateFloatArray = this._updateFloatArrayForEffect, this.updateArray = this._updateArrayForEffect, this.updateIntArray = this._updateIntArrayForEffect, this.updateUIntArray = this._updateUIntArrayForEffect, this.AlO = this._updateMatrixForEffect, this.updateMatrices = this._updateMatricesForEffect, this.updateVector3 = this._updateVector3ForEffect, this.updateVector4 = this._updateVector4ForEffect, this.updateColor3 = this._updateColor3ForEffect, this.updateColor4 = this._updateColor4ForEffect, this.updateDirectColor4 = this._updateDirectColor4ForEffect, this.updateInt = this._updateIntForEffect, this.updateInt2 = this._updateInt2ForEffect, this.updateInt3 = this._updateInt3ForEffect, this.updateInt4 = this._updateInt4ForEffect, this.updateUInt = this._updateUIntForEffect, this.updateUInt2 = this._updateUInt2ForEffect, this.updateUInt3 = this._updateUInt3ForEffect, this.updateUInt4 = this._updateUInt4ForEffect) : (this._engine._uniformBuffers.push(this), this.updateMatrix3x3 = this._updateMatrix3x3ForUniform, this.updateMatrix2x2 = this._updateMatrix2x2ForUniform, this.updateFloat = this._updateFloatForUniform, this.updateFloat2 = this._updateFloat2ForUniform, this.updateFloat3 = this._updateFloat3ForUniform, this.updateFloat4 = this._updateFloat4ForUniform, this.updateFloatArray = this._updateFloatArrayForUniform, this.updateArray = this._updateArrayForUniform, this.updateIntArray = this._updateIntArrayForUniform, this.updateUIntArray = this._updateUIntArrayForUniform, this.AlO = this._updateMatrixForUniform, this.updateMatrices = this._updateMatricesForUniform, this.updateVector3 = this._updateVector3ForUniform, this.updateVector4 = this._updateVector4ForUniform, this.updateColor3 = this._updateColor3ForUniform, this.updateColor4 = this._updateColor4ForUniform, this.updateDirectColor4 = this._updateDirectColor4ForUniform, this.updateInt = this._updateIntForUniform, this.updateInt2 = this._updateInt2ForUniform, this.updateInt3 = this._updateInt3ForUniform, this.updateInt4 = this._updateInt4ForUniform, this.updateUInt = this._updateUIntForUniform, this.updateUInt2 = this._updateUInt2ForUniform, this.updateUInt3 = this._updateUInt3ForUniform, this.updateUInt4 = this._updateUInt4ForUniform)
      }
      get useUbo() {
        return !this._noUBO
      }
      get isSync() {
        return !this._needSync
      }
      isDynamic() {
        return this._dynamic
      }
      getData() {
        return this._bufferData
      }
      getBuffer() {
        return this._buffer
      }
      getUniformNames() {
        return this._uniformNames
      }
      _fillAlignment(OO) {
        let KO;
        if (KO = OO <= 2 ? OO : 4, this._uniformLocationPointer % KO !== 0) {
          const OO = this._uniformLocationPointer;
          this._uniformLocationPointer += KO - this._uniformLocationPointer % KO;
          const pO = this._uniformLocationPointer - OO;
          for (let KO = 0; KO < pO; KO++) this._data.push(0)
        }
      }
      addUniform(OO, KO) {
        let pO, XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        if (XO > 0 && "number" === typeof KO && (this._uniformArraySizes[OO] = {
            strideSize: KO,
            arraySize: XO
          }), void 0 === this._uniformLocations[OO] && (this._uniformNames.push(OO), !this._noUBO)) {
          if (XO > 0) {
            if (KO instanceof Array) throw "addUniform should not be use with Array in UBO: " + OO;
            if (this._fillAlignment(4), 16 == KO) KO *= XO;
            else {
              KO = KO * XO + (4 - KO) * XO
            }
            pO = [];
            for (let OO = 0; OO < KO; OO++) pO.push(0)
          } else {
            if (KO instanceof Array) pO = KO, KO = pO.length;
            else {
              pO = [];
              for (let OO = 0; OO < KO; OO++) pO.push(0)
            }
            this._fillAlignment(KO)
          }
          this._uniformSizes[OO] = KO, this._uniformLocations[OO] = this._uniformLocationPointer, this._uniformLocationPointer += KO;
          for (let OO = 0; OO < KO; OO++) this._data.push(pO[OO]);
          this._needSync = !0
        }
      }
      addMatrix(OO, KO) {
        this.addUniform(OO, Array.prototype.slice.call(KO.WhO()))
      }
      addFloat2(OO, KO, pO) {
        const XO = [KO, pO];
        this.addUniform(OO, XO)
      }
      addFloat3(OO, KO, pO, XO) {
        const bK = [KO, pO, XO];
        this.addUniform(OO, bK)
      }
      addColor3(OO, KO) {
        const pO = [KO.r, KO.g, KO.b];
        this.addUniform(OO, pO)
      }
      addColor4(OO, KO, pO) {
        const XO = [KO.r, KO.g, KO.b, pO];
        this.addUniform(OO, XO)
      }
      addVector3(OO, KO) {
        const pO = [KO.x, KO.y, KO.z];
        this.addUniform(OO, pO)
      }
      addMatrix3x3(OO) {
        this.addUniform(OO, 12)
      }
      addMatrix2x2(OO) {
        this.addUniform(OO, 8)
      }
      create() {
        this._noUBO || this._buffer || (this._fillAlignment(4), this._bufferData = new Float32Array(this._data), this._dataGeneration++, this._rebuild(), this._needSync = !0)
      }
      _getNamesDebug() {
        const OO = [];
        let KO = 0;
        for (const pO in this._uniformLocations)
          if (OO.push(pO), 10 === ++KO) break;
        return OO.join(",")
      }
      _rebuild() {
        !this._noUBO && this._bufferData && (this._dynamic ? this._buffer = this._engine.createDynamicUniformBuffer(this._bufferData, this._name + "_UniformList:" + this._getNamesDebug()) : this._buffer = this._engine.createUniformBuffer(this._bufferData, this._name + "_UniformList:" + this._getNamesDebug()), this._trackUBOsInFrame && (this._buffers.push([this._buffer, this._engine._features.checkUbosContentBeforeUpload ? this._bufferData.slice() : void 0]), this._bufferIndex = this._buffers.length - 1, this._createBufferOnWrite = !1))
      }
      _rebuildAfterContextLost() {
        this._trackUBOsInFrame && (this._buffers = [], this._currentFrameId = 0, this._resetOwnerSlots()), this._rebuild()
      }
      _resetOwnerSlots() {
        if (this._ownerListsBySlot)
          for (const OO of this._ownerListsBySlot.values()) this._removeOwnerBacklink(OO);
        this._ownerListsBySlot = new Map, this._slotByOwner = new WeakMap, this._slotFrameId = [], this._ownerCount = 0, this._freeSlots = [], this._slotGeneration = []
      }
      get _numBuffers() {
        return this._buffers.length
      }
      get _indexBuffer() {
        return this._bufferIndex
      }
      get name() {
        return this._name
      }
      set name(OO) {
        this._name = OO
      }
      get currentEffect() {
        return this._currentEffect
      }
      _buffersEqual(OO, KO) {
        for (let pO = 0; pO < OO.length; ++pO)
          if (OO[pO] !== KO[pO]) return !1;
        return !0
      }
      _copyBuffer(OO, KO) {
        for (let pO = 0; pO < OO.length; ++pO) KO[pO] = OO[pO]
      }
      update() {
        if (!this._noUBO)
          if (this.bindUniformBuffer(), this._buffer)
            if (this._dynamic || this._needSync) {
              if (this._buffers && this._buffers.length > 1 && this._buffers[this._bufferIndex][1]) {
                if (this._buffersEqual(this._bufferData, this._buffers[this._bufferIndex][1])) return this._needSync = !1, void(this._createBufferOnWrite = this._trackUBOsInFrame);
                this._copyBuffer(this._bufferData, this._buffers[this._bufferIndex][1])
              }
              this._bufferUpdatedLastFrame = !0, this._engine.updateUniformBuffer(this._buffer, this._bufferData), this._needSync = !1, this._createBufferOnWrite = this._trackUBOsInFrame
            } else this._createBufferOnWrite = this._trackUBOsInFrame;
        else this.create()
      }
      _updateOwnerKeyed(OO) {
        if (this._noUBO || !this._trackUBOsInFrame) return void this.update();
        this._buffer || this.create(), this._checkNewFrame();
        let KO = this._slotByOwner.get(OO);
        if (void 0 === KO && (KO = 0 === this._ownerCount && 1 === this._buffers.length && 0 === this._freeSlots.length ? 0 : this._takeFreeSlot(!0), this._slotByOwner.set(OO, KO), this._ownerCount++, OO._uniformBuffersWithOwnedSlot || (OO._uniformBuffersWithOwnedSlot = []), OO._uniformBuffersWithOwnedSlot.push(this), this._ownerListsBySlot.set(KO, OO._uniformBuffersWithOwnedSlot)), this._slotGeneration[KO] === this._dataGeneration) return this._bufferIndex = KO, this._buffer = this._buffers[KO][0], this.bindUniformBuffer(), this._slotFrameId[KO] = this._currentFrameId, this._needSync = !1, void(this._createBufferOnWrite = !1);
        const pO = this._buffers[KO][1];
        this._slotFrameId[KO] === this._currentFrameId && pO && !this._buffersEqual(this._bufferData, pO) && (KO = this._takeFreeSlot(!1)), this._bufferIndex = KO, this._buffer = this._buffers[KO][0], this.bindUniformBuffer();
        const XO = this._buffers[KO][1];
        XO && this._buffersEqual(this._bufferData, XO) || (XO && this._copyBuffer(this._bufferData, XO), this._bufferUpdatedLastFrame = !0, this._engine.updateUniformBuffer(this._buffer, this._bufferData)), this._slotFrameId[KO] = this._currentFrameId, this._slotGeneration[KO] = this._dataGeneration, this._needSync = !1, this._createBufferOnWrite = !1
      }
      _takeFreeSlot(OO) {
        for (let pO = 0; pO < this._freeSlots.length; ++pO) {
          const KO = this._freeSlots[pO];
          if (this._slotFrameId[KO] !== this._currentFrameId) return OO && (this._freeSlots[pO] = this._freeSlots[this._freeSlots.length - 1], this._freeSlots.pop()), KO
        }
        this._rebuild();
        const KO = this._buffers.length - 1;
        return OO || this._freeSlots.push(KO), KO
      }
      _releaseOwnerSlot(OO) {
        const KO = this._slotByOwner?.get(OO);
        if (void 0 === KO) return;
        this._slotByOwner.delete(OO);
        const pO = this._ownerListsBySlot.get(KO);
        pO && (this._removeOwnerBacklink(pO), this._ownerListsBySlot.delete(KO)), this._ownerCount--, this._freeSlots.push(KO)
      }
      _removeOwnerBacklink(OO) {
        const KO = OO.indexOf(this); - 1 !== KO && (OO[KO] = OO[OO.length - 1], OO.pop())
      }
      _createNewBuffer() {
        this._bufferIndex + 1 < this._buffers.length ? (this._bufferIndex++, this._buffer = this._buffers[this._bufferIndex][0], this._createBufferOnWrite = !1, this._needSync = !0) : this._rebuild()
      }
      _checkNewFrame() {
        this._trackUBOsInFrame && this._currentFrameId !== this._engine.frameId && (this._currentFrameId = this._engine.frameId, this._createBufferOnWrite = !1, this._buffers && this._buffers.length > 0 ? (1 === this._buffers.length ? this._needSync = !this._bufferUpdatedLastFrame : this._needSync = 0 !== this._bufferIndex, this._bufferIndex = 0, this._buffer = this._buffers[this._bufferIndex][0]) : this._bufferIndex = -1)
      }
      updateUniform(OO, KO, pO) {
        this._checkNewFrame();
        let bK = this._uniformLocations[OO];
        if (void 0 === bK) {
          if (this._buffer) return void XO.b.Error("Cannot add an uniform after UBO has been created. uniformName=" + OO);
          this.addUniform(OO, pO), bK = this._uniformLocations[OO]
        }
        if (this._buffer || this.create(), this._dynamic) {
          for (let OO = 0; OO < pO; OO++) this._bufferData[bK + OO] = KO[OO];
          this._dataGeneration++
        } else {
          let OO = !1;
          for (let XO = 0; XO < pO; XO++)(16 === pO && !this._engine._features.uniformBufferHardCheckMatrix || this._bufferData[bK + XO] !== Math.fround(KO[XO])) && (OO = !0, this._createBufferOnWrite && this._createNewBuffer(), this._bufferData[bK + XO] = KO[XO]);
          this._needSync = this._needSync || OO, OO && this._dataGeneration++
        }
      }
      updateUniformArray(OO, KO, pO) {
        this._checkNewFrame();
        const eO = this._uniformLocations[OO];
        if (void 0 === eO) return void XO.b.Error("Cannot add an uniform Array dynamically. Please, add it using addUniform and make sure that uniform buffers are supported by the current engine.");
        this._buffer || this.create();
        const lO = this._uniformArraySizes[OO];
        if (this._dynamic) {
          for (let OO = 0; OO < pO; OO++) this._bufferData[eO + OO] = KO[OO];
          this._dataGeneration++
        } else {
          let OO = !1,
            XO = 0,
            vK = 0;
          for (let CO = 0; CO < pO; CO++)
            if (this._bufferData[eO + 4 * vK + XO] !== bK.k.FloatRound(KO[CO]) && (OO = !0, this._createBufferOnWrite && this._createNewBuffer(), this._bufferData[eO + 4 * vK + XO] = KO[CO]), XO++, XO === lO.strideSize) {
              for (; XO < 4; XO++) this._bufferData[eO + 4 * vK + XO] = 0;
              XO = 0, vK++
            } this._needSync = this._needSync || OO, OO && this._dataGeneration++
        }
      }
      _cacheMatrix(OO, KO) {
        this._checkNewFrame();
        const pO = this._valueCache[OO],
          XO = KO.updateFlag;
        return (void 0 === pO || pO !== XO) && (this._valueCache[OO] = XO, !0)
      }
      _updateMatrix3x3ForUniform(OO, KO) {
        for (let pO = 0; pO < 3; pO++) eO._TempBuffer[4 * pO] = KO[3 * pO], eO._TempBuffer[4 * pO + 1] = KO[3 * pO + 1], eO._TempBuffer[4 * pO + 2] = KO[3 * pO + 2], eO._TempBuffer[4 * pO + 3] = 0;
        this.updateUniform(OO, eO._TempBuffer, 12)
      }
      _updateMatrix3x3ForEffect(OO, KO) {
        this._currentEffect.setMatrix3x3(OO, KO)
      }
      _updateMatrix2x2ForEffect(OO, KO) {
        this._currentEffect.setMatrix2x2(OO, KO)
      }
      _updateMatrix2x2ForUniform(OO, KO) {
        for (let pO = 0; pO < 2; pO++) eO._TempBuffer[4 * pO] = KO[2 * pO], eO._TempBuffer[4 * pO + 1] = KO[2 * pO + 1], eO._TempBuffer[4 * pO + 2] = 0, eO._TempBuffer[4 * pO + 3] = 0;
        this.updateUniform(OO, eO._TempBuffer, 8)
      }
      _updateFloatForEffect(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
        this._currentEffect.setFloat(OO + pO, KO)
      }
      _updateFloatForUniform(OO, KO) {
        eO._TempBuffer[0] = KO, this.updateUniform(OO, eO._TempBuffer, 1)
      }
      _updateFloat2ForEffect(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
        this._currentEffect.setFloat2(OO + XO, KO, pO)
      }
      _updateFloat2ForUniform(OO, KO, pO) {
        eO._TempBuffer[0] = KO, eO._TempBuffer[1] = pO, this.updateUniform(OO, eO._TempBuffer, 2)
      }
      _updateFloat3ForEffect(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "";
        this._currentEffect.setFloat3(OO + bK, KO, pO, XO)
      }
      _updateFloat3ForUniform(OO, KO, pO, XO) {
        eO._TempBuffer[0] = KO, eO._TempBuffer[1] = pO, eO._TempBuffer[2] = XO, this.updateUniform(OO, eO._TempBuffer, 3)
      }
      _updateFloat4ForEffect(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "";
        this._currentEffect.setFloat4(OO + eO, KO, pO, XO, bK)
      }
      _updateFloat4ForUniform(OO, KO, pO, XO, bK) {
        eO._TempBuffer[0] = KO, eO._TempBuffer[1] = pO, eO._TempBuffer[2] = XO, eO._TempBuffer[3] = bK, this.updateUniform(OO, eO._TempBuffer, 4)
      }
      _updateFloatArrayForEffect(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
        switch (this._uniformArraySizes[OO]?.strideSize) {
          case 2:
            this._currentEffect.setFloatArray2(OO + pO, KO);
            break;
          case 3:
            this._currentEffect.setFloatArray3(OO + pO, KO);
            break;
          case 4:
            this._currentEffect.setFloatArray4(OO + pO, KO);
            break;
          default:
            this._currentEffect.setFloatArray(OO + pO, KO)
        }
      }
      _updateFloatArrayForUniform(OO, KO) {
        this.updateUniformArray(OO, KO, KO.length)
      }
      _updateArrayForEffect(OO, KO) {
        this._currentEffect.setArray(OO, KO)
      }
      _updateArrayForUniform(OO, KO) {
        this.updateUniformArray(OO, KO, KO.length)
      }
      _updateIntArrayForEffect(OO, KO) {
        this._currentEffect.setIntArray(OO, KO)
      }
      _updateIntArrayForUniform(OO, KO) {
        eO._TempBufferInt32View.set(KO), this.updateUniformArray(OO, eO._TempBuffer, KO.length)
      }
      _updateUIntArrayForEffect(OO, KO) {
        this._currentEffect.setUIntArray(OO, KO)
      }
      _updateUIntArrayForUniform(OO, KO) {
        eO._TempBufferUInt32View.set(KO), this.updateUniformArray(OO, eO._TempBuffer, KO.length)
      }
      _updateMatrixForEffect(OO, KO) {
        this._currentEffect.setMatrix(OO, KO)
      }
      _updateMatrixForUniform(OO, KO) {
        this._cacheMatrix(OO, KO) && this.updateUniform(OO, KO.WhO(), 16)
      }
      _updateMatricesForEffect(OO, KO) {
        this._currentEffect.setMatrices(OO, KO)
      }
      _updateMatricesForUniform(OO, KO) {
        this.updateUniform(OO, KO, KO.length)
      }
      _updateVector3ForEffect(OO, KO) {
        this._currentEffect.setVector3(OO, KO)
      }
      _updateVector3ForUniform(OO, KO) {
        eO._TempBuffer[0] = KO.x, eO._TempBuffer[1] = KO.y, eO._TempBuffer[2] = KO.z, this.updateUniform(OO, eO._TempBuffer, 3)
      }
      _updateVector4ForEffect(OO, KO) {
        this._currentEffect.setVector4(OO, KO)
      }
      _updateVector4ForUniform(OO, KO) {
        eO._TempBuffer[0] = KO.x, eO._TempBuffer[1] = KO.y, eO._TempBuffer[2] = KO.z, eO._TempBuffer[3] = KO.w, this.updateUniform(OO, eO._TempBuffer, 4)
      }
      _updateColor3ForEffect(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
        this._currentEffect.setColor3(OO + pO, KO)
      }
      _updateColor3ForUniform(OO, KO) {
        eO._TempBuffer[0] = KO.r, eO._TempBuffer[1] = KO.g, eO._TempBuffer[2] = KO.b, this.updateUniform(OO, eO._TempBuffer, 3)
      }
      _updateColor4ForEffect(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
        this._currentEffect.setColor4(OO + XO, KO, pO)
      }
      _updateDirectColor4ForEffect(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
        this._currentEffect.setDirectColor4(OO + pO, KO)
      }
      _updateColor4ForUniform(OO, KO, pO) {
        eO._TempBuffer[0] = KO.r, eO._TempBuffer[1] = KO.g, eO._TempBuffer[2] = KO.b, eO._TempBuffer[3] = pO, this.updateUniform(OO, eO._TempBuffer, 4)
      }
      _updateDirectColor4ForUniform(OO, KO) {
        eO._TempBuffer[0] = KO.r, eO._TempBuffer[1] = KO.g, eO._TempBuffer[2] = KO.b, eO._TempBuffer[3] = KO.a, this.updateUniform(OO, eO._TempBuffer, 4)
      }
      _updateIntForEffect(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
        this._currentEffect.setInt(OO + pO, KO)
      }
      _updateIntForUniform(OO, KO) {
        eO._TempBufferInt32View[0] = KO, this.updateUniform(OO, eO._TempBuffer, 1)
      }
      _updateInt2ForEffect(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
        this._currentEffect.setInt2(OO + XO, KO, pO)
      }
      _updateInt2ForUniform(OO, KO, pO) {
        eO._TempBufferInt32View[0] = KO, eO._TempBufferInt32View[1] = pO, this.updateUniform(OO, eO._TempBuffer, 2)
      }
      _updateInt3ForEffect(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "";
        this._currentEffect.setInt3(OO + bK, KO, pO, XO)
      }
      _updateInt3ForUniform(OO, KO, pO, XO) {
        eO._TempBufferInt32View[0] = KO, eO._TempBufferInt32View[1] = pO, eO._TempBufferInt32View[2] = XO, this.updateUniform(OO, eO._TempBuffer, 3)
      }
      _updateInt4ForEffect(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "";
        this._currentEffect.setInt4(OO + eO, KO, pO, XO, bK)
      }
      _updateInt4ForUniform(OO, KO, pO, XO, bK) {
        eO._TempBufferInt32View[0] = KO, eO._TempBufferInt32View[1] = pO, eO._TempBufferInt32View[2] = XO, eO._TempBufferInt32View[3] = bK, this.updateUniform(OO, eO._TempBuffer, 4)
      }
      _updateUIntForEffect(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
        this._currentEffect.setUInt(OO + pO, KO)
      }
      _updateUIntForUniform(OO, KO) {
        eO._TempBufferUInt32View[0] = KO, this.updateUniform(OO, eO._TempBuffer, 1)
      }
      _updateUInt2ForEffect(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
        this._currentEffect.setUInt2(OO + XO, KO, pO)
      }
      _updateUInt2ForUniform(OO, KO, pO) {
        eO._TempBufferUInt32View[0] = KO, eO._TempBufferUInt32View[1] = pO, this.updateUniform(OO, eO._TempBuffer, 2)
      }
      _updateUInt3ForEffect(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "";
        this._currentEffect.setUInt3(OO + bK, KO, pO, XO)
      }
      _updateUInt3ForUniform(OO, KO, pO, XO) {
        eO._TempBufferUInt32View[0] = KO, eO._TempBufferUInt32View[1] = pO, eO._TempBufferUInt32View[2] = XO, this.updateUniform(OO, eO._TempBuffer, 3)
      }
      _updateUInt4ForEffect(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "";
        this._currentEffect.setUInt4(OO + eO, KO, pO, XO, bK)
      }
      _updateUInt4ForUniform(OO, KO, pO, XO, bK) {
        eO._TempBufferUInt32View[0] = KO, eO._TempBufferUInt32View[1] = pO, eO._TempBufferUInt32View[2] = XO, eO._TempBufferUInt32View[3] = bK, this.updateUniform(OO, eO._TempBuffer, 4)
      }
      setTexture(OO, KO) {
        this._currentEffect.setTexture(OO, KO)
      }
      setTextureArray(OO, KO) {
        this._currentEffect.setTextureArray(OO, KO)
      }
      bindTexture(OO, KO) {
        this._currentEffect._bindTexture(OO, KO)
      }
      updateUniformDirectly(OO, KO) {
        this.updateUniform(OO, KO, KO.length), this.update()
      }
      bindToEffect(OO, KO) {
        this._currentEffect = OO, this._currentEffectName = KO
      }
      bindUniformBuffer() {
        !this._noUBO && this._buffer && this._currentEffect && this._currentEffect.bindUniformBuffer(this._buffer, this._currentEffectName)
      }
      unbindEffect() {
        this._currentEffect = void 0, this._currentEffectName = void 0
      }
      setDataBuffer(OO) {
        if (!this._buffers) return this._buffer === OO;
        for (let KO = 0; KO < this._buffers.length; ++KO) {
          if (this._buffers[KO][0] === OO) return this._bufferIndex = KO, this._buffer = OO, this._createBufferOnWrite = !1, this._currentEffect = void 0, this._buffers.length > 1 && this._buffers[KO][1] && (this._bufferData.set(this._buffers[KO][1]), this._dataGeneration++), this._valueCache = {}, this._currentFrameId = this._engine.frameId, !0
        }
        return !1
      }
      has(OO) {
        return void 0 !== this._uniformLocations[OO]
      }
      dispose() {
        if (this._noUBO) return;
        const OO = this._engine._uniformBuffers,
          KO = OO.indexOf(this);
        if (-1 !== KO && (OO[KO] = OO[OO.length - 1], OO.pop()), this._trackUBOsInFrame && this._buffers) {
          this._resetOwnerSlots();
          for (let OO = 0; OO < this._buffers.length; ++OO) {
            const KO = this._buffers[OO][0];
            this._engine._releaseBuffer(KO)
          }
          this._buffers = [], this._buffer = null, this._bufferIndex = -1
        } else this._buffer && this._engine._releaseBuffer(this._buffer) && (this._buffer = null)
      }
    }
    eO._MAX_UNIFORM_SIZE = 256, eO._TempBuffer = new Float32Array(eO._MAX_UNIFORM_SIZE), eO._TempBufferInt32View = new Int32Array(eO._TempBuffer.buffer), eO._TempBufferUInt32View = new Uint32Array(eO._TempBuffer.buffer)
  },
  37984: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(37987);
    class bK extends XO.c {
      constructor(OO) {
        super(), this._buffer = OO
      }
      get underlyingResource() {
        return this._buffer
      }
    }
  },
  38068: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO,
      f: () => hO
    });
    const XO = "__bjs_serializable__",
      bK = new WeakMap;

    function eO(OO, KO) {
      return Object.prototype.hasOwnProperty.call(OO, KO)
    }
    const lO = function() {
      let OO = Symbol.metadata;
      return OO || (OO = Symbol("Symbol.metadata"), Object.defineProperty(Symbol, "metadata", {
        configurable: !0,
        writable: !0,
        value: OO
      })), OO
    }();

    function vK(OO) {
      return "function" === typeof OO ? OO : OO?.constructor
    }

    function CO(OO) {
      if (!OO) throw new Error(`Decorator metadata is unavailable; the Symbol.metadata (${String(lO)}) polyfill must run before decorated classes are evaluated.`);
      return eO(OO, XO) || (OO[XO] = {}), OO[XO]
    }

    function hO(OO) {
      const KO = vK(OO),
        pO = KO ? KO[lO] : void 0;
      if (!pO) return {};
      const CO = bK.get(pO);
      if (CO) return CO;
      const hO = {},
        DO = [];
      let MO = pO;
      for (; MO;) DO.push(MO), MO = Object.getPrototypeOf(MO);
      for (const bK of DO)
        if (eO(bK, XO)) {
          const OO = bK[XO];
          for (const KO in OO) hO[KO] = OO[KO]
        } return bK.set(pO, hO), hO
    }
  },
  38066: (OO, KO, pO) => {
    pO.d(KO, {
      D: () => aK,
      E: () => VO,
      I: () => vK,
      J: () => DO,
      L: () => MO,
      M: () => lO,
      e: () => AO,
      h: () => eO,
      l: () => zK,
      p: () => oO,
      r: () => CO,
      v: () => FO,
      y: () => hO,
      z: () => LO
    });
    var XO = pO(38068);

    function bK(OO, KO) {
      return (pO, bK) => {
        if (!bK.metadata) return;
        const eO = String(bK.name),
          lO = (0, XO.d)(bK.metadata);
        lO[eO] || (lO[eO] = {
          type: OO,
          sourceName: KO
        })
      }
    }

    function eO(OO) {
      return function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        return (pO, XO) => {
          const bK = KO || "_" + String(XO.name);
          return {
            init(OO) {
              return void 0 === OO && bK in this || (this[bK] = OO), OO
            },
            get() {
              return this[bK]
            },
            set(KO) {
              "function" === typeof this[bK]?.equals && this[bK].equals(KO) || this[bK] !== KO && (this[bK] = KO, this[OO]())
            }
          }
        }
      }(OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null)
    }

    function lO(OO) {
      return bK(0, OO)
    }

    function vK(OO) {
      return bK(1, OO)
    }

    function CO(OO) {
      return bK(2, OO)
    }

    function hO(OO) {
      return bK(3, OO)
    }

    function DO(OO) {
      return bK(4, OO)
    }

    function MO(OO) {
      return bK(5, OO)
    }

    function aK(OO) {
      return bK(6, OO)
    }

    function oO(OO) {
      return bK(7, OO)
    }

    function FO(OO) {
      return bK(8, OO)
    }

    function VO(OO) {
      return bK(10, OO)
    }

    function LO(OO) {
      return bK(12, OO)
    }

    function QO(OO, KO, pO) {
      const XO = String(KO.name);
      let bK = null;
      const eO = function() {
        if (null === bK) {
          bK = OO, "undefined" !== typeof _native && _native[XO] && (bK = pO(_native[XO], OO));
          const lO = this && (KO.static ? this : Object.getPrototypeOf(this));
          lO?.[XO] === eO && (lO[XO] = bK)
        }
        for (var lO = arguments.length, vK = new Array(lO), CO = 0; CO < lO; CO++) vK[CO] = arguments[CO];
        return bK.apply(this, vK)
      };
      return eO
    }

    function zK(OO, KO) {
      return QO(OO, KO, (OO => OO))
    }

    function AO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      return (pO, XO) => {
        const bK = KO || "_" + String(XO.name);
        return {
          get() {
            return this[bK]?.value
          },
          set(KO) {
            "function" === typeof this[bK]?.value?.equals && this[bK].value.equals(KO) || this[bK].value !== KO && (this[bK].value = KO, this[OO]())
          }
        }
      }
    }
    zK.filter = function(OO) {
      return (KO, pO) => QO(KO, pO, ((KO, pO) => function() {
        for (var XO = arguments.length, bK = new Array(XO), eO = 0; eO < XO; eO++) bK[eO] = arguments[eO];
        return OO(...bK) ? KO(...bK) : pO.apply(this, bK)
      }))
    }
  },
  38077: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => hO
    });
    var XO = pO(37938),
      bK = pO(38085),
      eO = pO(35688),
      lO = pO(35632),
      vK = pO(38068);
    const CO = function(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
      const eO = OO();
      bK.b && bK.b.HasTags(KO) && bK.b.AddTagsTo(eO, bK.b.GetTags(KO, !0));
      const lO = (0, vK.f)(eO),
        CO = {};
      for (const bK in lO) {
        const OO = lO[bK],
          vK = KO[bK],
          DO = OO.type;
        if (void 0 !== vK && null !== vK && ("uniqueId" !== bK || hO.AllowLoadingUniqueId)) switch (DO) {
          case 0:
          case 6:
          case 9:
          case 11:
            "function" === typeof vK.slice ? eO[bK] = vK.slice() : eO[bK] = vK;
            break;
          case 1:
            XO.cloneTexturesOnlyOnce && CO[vK.uniqueId] ? eO[bK] = CO[vK.uniqueId] : (eO[bK] = pO || vK.isRenderTarget ? vK : vK.clone(), CO[vK.uniqueId] = eO[bK]);
            break;
          case 2:
          case 3:
          case 4:
          case 5:
          case 7:
          case 8:
          case 10:
          case 12:
          case 13:
            eO[bK] = pO ? vK : vK.clone()
        }
      }
      return eO
    };
    class hO {
      static AppendSerializedAnimations(OO, KO) {
        if (OO.animations) {
          KO.animations = [];
          for (let pO = 0; pO < OO.animations.length; pO++) {
            const XO = OO.animations[pO];
            KO.animations.push(XO.serialize())
          }
        }
      }
      static Serialize(OO, KO) {
        KO || (KO = {}), bK.b && (KO.tags = bK.b.GetTags(OO));
        const pO = (0, vK.f)(OO);
        for (const XO in pO) {
          const bK = pO[XO],
            eO = bK.sourceName || XO,
            lO = bK.type,
            vK = OO[XO];
          if (void 0 !== vK && null !== vK && ("uniqueId" !== XO || hO.AllowLoadingUniqueId)) switch (lO) {
            case 0:
              Array.isArray(vK) ? KO[eO] = vK.slice() : KO[eO] = vK;
              break;
            case 1:
            case 3:
            case 7:
            case 9:
              KO[eO] = vK.serialize();
              break;
            case 2:
            case 4:
            case 5:
            case 8:
            case 10:
            case 12:
            case 13:
              KO[eO] = vK.WhO();
              break;
            case 6:
            case 11:
              KO[eO] = vK.id
          }
        }
        return KO
      }
      static ParseProperties(OO, KO, pO, XO) {
        XO || (XO = "");
        const bK = (0, vK.f)(KO);
        for (const vK in bK) {
          const CO = bK[vK],
            DO = OO[CO.sourceName || vK],
            MO = CO.type;
          if (void 0 !== DO && null !== DO && ("uniqueId" !== vK || hO.AllowLoadingUniqueId)) {
            const OO = KO;
            switch (MO) {
              case 0:
                OO[vK] = DO;
                break;
              case 1:
                pO && (OO[vK] = hO._TextureParser(DO, pO, XO));
                break;
              case 2:
                OO[vK] = eO.e.FromArray(DO);
                break;
              case 3:
                OO[vK] = hO._FresnelParametersParser(DO);
                break;
              case 4:
                OO[vK] = lO.m.FromArray(DO);
                break;
              case 5:
                OO[vK] = lO.o.FromArray(DO);
                break;
              case 6:
                pO && (OO[vK] = pO.getLastMeshById(DO));
                break;
              case 7:
                OO[vK] = hO._ColorCurvesParser(DO);
                break;
              case 8:
                OO[vK] = eO.g.FromArray(DO);
                break;
              case 9:
                OO[vK] = hO._ImageProcessingConfigurationParser(DO);
                break;
              case 10:
                OO[vK] = lO.g.FromArray(DO);
                break;
              case 11:
                pO && (OO[vK] = pO.getCameraById(DO));
                break;
              case 12:
                OO[vK] = lO.c.FromArray(DO);
                break;
              case 13:
                OO[vK] = lO.s.FromArray(DO)
            }
          }
        }
      }
      static Parse(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        const eO = OO();
        return bK.b && bK.b.AddTagsTo(eO, KO.tags), hO.ParseProperties(KO, eO, pO, XO), eO
      }
      static Clone(OO, KO) {
        return CO(OO, KO, !1, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {})
      }
      static Instanciate(OO, KO) {
        return CO(OO, KO, !0)
      }
    }
    hO.AllowLoadingUniqueId = !1, hO._ImageProcessingConfigurationParser = OO => {
      throw (0, XO.j)("ImageProcessingConfiguration")
    }, hO._FresnelParametersParser = OO => {
      throw (0, XO.j)("FresnelParameters")
    }, hO._ColorCurvesParser = OO => {
      throw (0, XO.j)("ColorCurves")
    }, hO._TextureParser = (OO, KO, pO) => {
      throw (0, XO.j)("Texture")
    }
  },
  38011: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(37966);
    class bK {
      get min() {
        return this._min
      }
      get max() {
        return this._max
      }
      get average() {
        return this._average
      }
      get lastSecAverage() {
        return this._lastSecAverage
      }
      get current() {
        return this._current
      }
      get total() {
        return this._totalAccumulated
      }
      get count() {
        return this._totalValueCount
      }
      constructor() {
        this._startMonitoringTime = 0, this._min = 0, this._max = 0, this._hasResult = !1, this._hasCurrentValue = !1, this._average = 0, this._lastSecAverage = 0, this._current = 0, this._totalValueCount = 0, this._totalAccumulated = 0, this._lastSecAccumulated = 0, this._lastSecTime = 0, this._lastSecValueCount = 0
      }
      fetchNewFrame() {
        this._totalValueCount++, this._current = 0, this._hasCurrentValue = bK.Enabled, this._lastSecValueCount++
      }
      addCount(OO, KO) {
        bK.Enabled && (this._current += OO, this._hasCurrentValue = !0, KO && this._fetchResult())
      }
      beginMonitoring() {
        bK.Enabled && (this._startMonitoringTime = XO.d.Now)
      }
      endMonitoring() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        if (!bK.Enabled) return;
        OO && this.fetchNewFrame();
        const KO = XO.d.Now;
        this._current = KO - this._startMonitoringTime, this._hasCurrentValue = !0, OO && this._fetchResult()
      }
      EL() {
        this._fetchResult()
      }
      _fetchResult() {
        if (!this._hasCurrentValue) return;
        this._totalAccumulated += this._current, this._lastSecAccumulated += this._current, this._hasResult ? (this._min = Math.min(this._min, this._current), this._max = Math.max(this._max, this._current)) : (this._min = this._current, this._max = this._current, this._hasResult = !0), this._average = this._totalAccumulated / this._totalValueCount;
        const OO = XO.d.Now;
        OO - this._lastSecTime > 1e3 && (this._lastSecAverage = this._lastSecAccumulated / this._lastSecValueCount, this._lastSecTime = OO, this._lastSecAccumulated = 0, this._lastSecValueCount = 0)
      }
    }
    bK.Enabled = !0
  },
  38186: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      e: () => XO
    });
    class XO {
      constructor(OO) {
        this.length = 0, this.data = new Array(OO), this._id = XO._GlobalId++
      }
      push(OO) {
        this.data[this.length++] = OO, this.length > this.data.length && (this.data.length *= 2)
      }
      forEach(OO) {
        for (let KO = 0; KO < this.length; KO++) OO(this.data[KO])
      }
      sort(OO) {
        this.data.sort(OO)
      }
      reset() {
        this.length = 0
      }
      dispose() {
        this.reset(), this.data && (this.data.length = 0)
      }
      concat(OO) {
        if (0 !== OO.length) {
          this.length + OO.length > this.data.length && (this.data.length = 2 * (this.length + OO.length));
          for (let KO = 0; KO < OO.length; KO++) this.data[this.length++] = (OO.data || OO)[KO]
        }
      }
      indexOf(OO) {
        const KO = this.data.indexOf(OO);
        return KO >= this.length ? -1 : KO
      }
      contains(OO) {
        return -1 !== this.indexOf(OO)
      }
    }
    XO._GlobalId = 0;
    class bK extends XO {
      constructor() {
        super(...arguments), this._duplicateId = 0
      }
      push(OO) {
        super.push(OO), OO.__smartArrayFlags || (OO.__smartArrayFlags = {}), OO.__smartArrayFlags[this._id] = this._duplicateId
      }
      pushNoDuplicate(OO) {
        return (!OO.__smartArrayFlags || OO.__smartArrayFlags[this._id] !== this._duplicateId) && (this.push(OO), !0)
      }
      reset() {
        super.reset(), this._duplicateId++
      }
      concatWithNoDuplicate(OO) {
        if (0 !== OO.length) {
          this.length + OO.length > this.data.length && (this.data.length = 2 * (this.length + OO.length));
          for (let KO = 0; KO < OO.length; KO++) {
            const pO = (OO.data || OO)[KO];
            this.pushNoDuplicate(pO)
          }
        }
      }
    }
  },
  38085: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK
    });
    class XO {
      static Eval(OO, KO) {
        return "true" === (OO = OO.match(/\([^()]*\)/g) ? OO.replace(/\([^()]*\)/g, (OO => (OO = OO.slice(1, OO.length - 1), XO._HandleParenthesisContent(OO, KO)))) : XO._HandleParenthesisContent(OO, KO)) || "false" !== OO && XO.Eval(OO, KO)
      }
      static _HandleParenthesisContent(OO, KO) {
        let pO;
        KO = KO || (OO => "true" === OO);
        const bK = OO.split("||");
        for (const eO in bK)
          if (Object.prototype.hasOwnProperty.call(bK, eO)) {
            let OO = XO._SimplifyNegation(bK[eO].trim());
            const lO = OO.split("&&");
            if (lO.length > 1)
              for (let bK = 0; bK < lO.length; ++bK) {
                const eO = XO._SimplifyNegation(lO[bK].trim());
                if (pO = "true" !== eO && "false" !== eO ? "!" === eO[0] ? !KO(eO.substring(1)) : KO(eO) : "true" === eO, !pO) {
                  OO = "false";
                  break
                }
              }
            if (pO || "true" === OO) {
              pO = !0;
              break
            }
            pO = "true" !== OO && "false" !== OO ? "!" === OO[0] ? !KO(OO.substring(1)) : KO(OO) : "true" === OO
          } return pO ? "true" : "false"
      }
      static _SimplifyNegation(OO) {
        return "!true" === (OO = (OO = OO.replace(/^[\s!]+/, (OO => (OO = OO.replace(/[\s]/g, (() => ""))).length % 2 ? "!" : ""))).trim()) ? OO = "false" : "!false" === OO && (OO = "true"), OO
      }
    }
    class bK {
      static EnableFor(OO) {
        OO._tags = OO._tags || {}, OO.hasTags = () => bK.HasTags(OO), OO.addTags = KO => bK.AddTagsTo(OO, KO), OO.removeTags = KO => bK.RemoveTagsFrom(OO, KO), OO.matchesTagsQuery = KO => bK.MatchesQuery(OO, KO)
      }
      static DisableFor(OO) {
        delete OO._tags, delete OO.hasTags, delete OO.addTags, delete OO.removeTags, delete OO.matchesTagsQuery
      }
      static HasTags(OO) {
        if (!OO._tags) return !1;
        const KO = OO._tags;
        for (const pO in KO)
          if (Object.prototype.hasOwnProperty.call(KO, pO)) return !0;
        return !1
      }
      static GetTags(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (!OO._tags) return null;
        if (KO) {
          const KO = [];
          for (const pO in OO._tags) Object.prototype.hasOwnProperty.call(OO._tags, pO) && !0 === OO._tags[pO] && KO.push(pO);
          return KO.join(" ")
        }
        return OO._tags
      }
      static AddTagsTo(OO, KO) {
        if (!KO) return;
        if ("string" !== typeof KO) return;
        const pO = KO.split(" ");
        for (const XO of pO) bK._AddTagTo(OO, XO)
      }
      static _AddTagTo(OO, KO) {
        "" !== (KO = KO.trim()) && "true" !== KO && "false" !== KO && (KO.match(/[\s]/) || KO.match(/^([!]|([|]|[&]){2})/) || (bK.EnableFor(OO), OO._tags[KO] = !0))
      }
      static RemoveTagsFrom(OO, KO) {
        if (!bK.HasTags(OO)) return;
        const pO = KO.split(" ");
        for (const XO in pO) bK._RemoveTagFrom(OO, pO[XO])
      }
      static _RemoveTagFrom(OO, KO) {
        delete OO._tags[KO]
      }
      static MatchesQuery(OO, KO) {
        return void 0 === KO || ("" === KO ? bK.HasTags(OO) : XO.Eval(KO, (KO => bK.HasTags(OO) && OO._tags[KO])))
      }
    }
  },
  38225: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO
    });
    var XO = pO(38216),
      bK = pO(35660);
    class eO {
      constructor(OO) {
        this._vertexBuffers = {}, this._activePostProcesses = [], this.onBeforeRenderObservable = new bK.e, this._scene = OO
      }
      _prepareBuffers() {
        if (this._vertexBuffers[XO.j.PositionKind]) return;
        const OO = [];
        OO.push(1, 1), OO.push(-1, 1), OO.push(-1, -1), OO.push(1, -1), this._vertexBuffers[XO.j.PositionKind] = new XO.j(this._scene.qb(), OO, XO.j.PositionKind, !1, !1, 2), this._buildIndexBuffer()
      }
      _buildIndexBuffer() {
        const OO = [];
        OO.push(0), OO.push(1), OO.push(2), OO.push(0), OO.push(2), OO.push(3), this._indexBuffer = this._scene.qb().createIndexBuffer(OO)
      }
      _getActivePostProcesses(OO) {
        const KO = this._activePostProcesses;
        KO.length = 0;
        for (let pO = 0; pO < OO.length; pO++) {
          const XO = OO[pO];
          XO && KO.push(XO)
        }
        return KO
      }
      _rebuild() {
        const OO = this._vertexBuffers[XO.j.PositionKind];
        OO && (OO._rebuild(), this._buildIndexBuffer())
      }
      _prepareFrame() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        const pO = this._scene.activeCamera;
        return !!pO && (KO = KO || this._getActivePostProcesses(pO._postProcesses), !(!KO || 0 === KO.length || !this._scene.postProcessesEnabled) && (KO[0].activate(pO, OO, null !== KO && void 0 !== KO), !0))
      }
      directRender(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
          eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
          lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : OO.length;
        const vK = this._scene.qb();
        for (let CO = 0; CO < lO; CO++) {
          CO < OO.length - 1 ? OO[CO + 1].activate(this._scene.activeCamera || this._scene, KO?.texture) : (KO ? vK.bindFramebuffer(KO, XO, void 0, void 0, pO, bK) : eO || vK.restoreDefaultFramebuffer(), vK._debugInsertMarker?.(`post process ${OO[CO].name} output`));
          const lO = OO[CO],
            hO = lO.apply();
          hO && (lO.onBeforeRenderObservable.notifyObservers(hO), this._prepareBuffers(), vK.bindBuffers(this._vertexBuffers, this._indexBuffer, hO), vK.drawElementsType(0, 0, 6), lO.onAfterRenderObservable.notifyObservers(hO))
        }
        vK.setDepthBuffer(!0), vK.setDepthWrite(!0)
      }
      _finalizeFrame(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        const eO = this._scene.activeCamera;
        if (!eO) return;
        if (this.onBeforeRenderObservable.notifyObservers(this), 0 === (XO = XO || this._getActivePostProcesses(eO._postProcesses)).length || !this._scene.postProcessesEnabled) return;
        const lO = this._scene.qb();
        for (let vK = 0, CO = XO.length; vK < CO; vK++) {
          const hO = XO[vK];
          if (vK < CO - 1 ? hO._outputTexture = XO[vK + 1].activate(eO, KO?.texture) : (KO ? (lO.bindFramebuffer(KO, pO, void 0, void 0, bK), hO._outputTexture = KO) : (lO.restoreDefaultFramebuffer(), hO._outputTexture = null), lO._debugInsertMarker?.(`post process ${XO[vK].name} output`)), OO) break;
          const DO = hO.apply();
          DO && (hO.onBeforeRenderObservable.notifyObservers(DO), this._prepareBuffers(), lO.bindBuffers(this._vertexBuffers, this._indexBuffer, DO), lO.drawElementsType(0, 0, 6), hO.onAfterRenderObservable.notifyObservers(DO))
        }
        lO.setDepthBuffer(!0), lO.setDepthWrite(!0), lO.setAlphaMode(0)
      }
      dispose() {
        const OO = this._vertexBuffers[XO.j.PositionKind];
        OO && (OO.dispose(), this._vertexBuffers[XO.j.PositionKind] = null), this._indexBuffer && (this._scene.qb()._releaseBuffer(this._indexBuffer), this._indexBuffer = null)
      }
    }
  },
  38243: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(38186),
      bK = pO(35632);
    class eO {
      set opaqueSortCompareFn(OO) {
        this._opaqueSortCompareFn = OO || eO.PainterSortCompare, this._renderOpaque = this._renderOpaqueSorted
      }
      set alphaTestSortCompareFn(OO) {
        this._alphaTestSortCompareFn = OO || eO.PainterSortCompare, this._renderAlphaTest = this._renderAlphaTestSorted
      }
      set transparentSortCompareFn(OO) {
        this._transparentSortCompareFn = OO || eO.defaultTransparentSortCompare, this._renderTransparent = this._renderTransparentSorted
      }
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
          eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
        this.index = OO, this._opaqueSubMeshes = new XO.e(256), this._transparentSubMeshes = new XO.e(256), this._alphaTestSubMeshes = new XO.e(256), this._depthOnlySubMeshes = new XO.e(256), this._particleSystems = new XO.e(256), this._spriteManagers = new XO.e(256), this._empty = !0, this._edgesRenderers = new XO.d(16), this.disableDepthPrePass = !1, this._scene = KO, this.opaqueSortCompareFn = pO, this.alphaTestSortCompareFn = bK, this.transparentSortCompareFn = eO
      }
      render(OO, KO, pO, XO) {
        let bK = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
          eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
          lO = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6],
          vK = !(arguments.length > 7 && void 0 !== arguments[7]) || arguments[7],
          CO = arguments.length > 8 ? arguments[8] : void 0;
        if (OO) return void OO(this._opaqueSubMeshes, this._alphaTestSubMeshes, this._transparentSubMeshes, this._depthOnlySubMeshes);
        const hO = this._scene.qb();
        bK && 0 !== this._depthOnlySubMeshes.length && (hO.setColorWrite(!1), this._renderAlphaTest(this._depthOnlySubMeshes), hO.setColorWrite(!0)), eO && 0 !== this._opaqueSubMeshes.length && this._renderOpaque(this._opaqueSubMeshes), lO && 0 !== this._alphaTestSubMeshes.length && this._renderAlphaTest(this._alphaTestSubMeshes);
        const DO = hO.getStencilBuffer();
        if (hO.setStencilBuffer(!1), KO && this._renderSprites(), pO && this._renderParticles(XO), this.onBeforeTransparentRendering && this.onBeforeTransparentRendering(), vK && (CO || 0 !== this._transparentSubMeshes.length || this._scene.useOrderIndependentTransparency)) {
          if (hO.setStencilBuffer(DO), CO) CO(this._transparentSubMeshes, this);
          else if (this._scene.useOrderIndependentTransparency) {
            const OO = this._scene.depthPeelingRenderer.render(this._transparentSubMeshes);
            OO.length && this._renderTransparent(OO)
          } else this._renderTransparent(this._transparentSubMeshes);
          hO.setAlphaMode(0)
        }
        if (hO.setStencilBuffer(!1), eO && this._edgesRenderers.length) {
          for (let OO = 0; OO < this._edgesRenderers.length; OO++) this._edgesRenderers.data[OO].render();
          hO.setAlphaMode(0)
        }
        hO.setStencilBuffer(DO)
      }
      _renderOpaqueSorted(OO) {
        eO._RenderSorted(OO, this._opaqueSortCompareFn, this._scene.activeCamera, !1, this.disableDepthPrePass)
      }
      _renderAlphaTestSorted(OO) {
        eO._RenderSorted(OO, this._alphaTestSortCompareFn, this._scene.activeCamera, !1, this.disableDepthPrePass)
      }
      _renderTransparentSorted(OO) {
        eO._RenderSorted(OO, this._transparentSortCompareFn, this._scene.activeCamera, !0, this.disableDepthPrePass)
      }
      static _RenderSorted(OO, KO, pO, XO, lO) {
        let vK, CO = 0;
        const hO = pO ? pO.globalPosition : eO._ZeroVector;
        if (XO && KO !== eO.PainterSortCompare)
          for (; CO < OO.length; CO++) vK = OO.data[CO], vK._alphaIndex = vK.getMesh().alphaIndex, vK._distanceToCamera = bK.o.Distance(vK.hpO().QDO.centerWorld, hO);
        const DO = OO.length === OO.data.length ? OO.data : OO.data.slice(0, OO.length);
        KO && DO.sort(KO);
        const MO = DO[0].getMesh().JKO();
        for (CO = 0; CO < DO.length; CO++) {
          if (vK = DO[CO], MO._activeMeshesFrozenButKeepClipping && !vK.isInFrustum(MO._frustumPlanes)) continue;
          let OO = !1;
          if (XO) {
            const KO = vK.UX();
            if (KO && KO.needDepthPrePass && !lO) {
              OO = !0;
              const pO = KO.JKO().qb();
              pO.setColorWrite(!1), pO.setAlphaMode(0), vK.render(!1), pO.setColorWrite(!0)
            }
          }
          const KO = vK._renderingMesh;
          !OO && KO._renderRunFollower(vK, XO) || vK.render(XO)
        }
      }
      static defaultTransparentSortCompare(OO, KO) {
        return OO._alphaIndex > KO._alphaIndex ? 1 : OO._alphaIndex < KO._alphaIndex ? -1 : eO.backToFrontSortCompare(OO, KO)
      }
      static backToFrontSortCompare(OO, KO) {
        return OO._distanceToCamera < KO._distanceToCamera ? 1 : OO._distanceToCamera > KO._distanceToCamera ? -1 : 0
      }
      static frontToBackSortCompare(OO, KO) {
        return OO._distanceToCamera < KO._distanceToCamera ? -1 : OO._distanceToCamera > KO._distanceToCamera ? 1 : 0
      }
      static PainterSortCompare(OO, KO) {
        const pO = OO.getMesh(),
          XO = KO.getMesh();
        return pO.material && XO.material ? pO.material.uniqueId - XO.material.uniqueId : pO.uniqueId - XO.uniqueId
      }
      prepare() {
        this._opaqueSubMeshes.reset(), this._transparentSubMeshes.reset(), this._alphaTestSubMeshes.reset(), this._depthOnlySubMeshes.reset(), this._particleSystems.reset(), this.prepareSprites(), this._edgesRenderers.reset(), this._empty = !0
      }
      prepareSprites() {
        this._spriteManagers.reset()
      }
      dispose() {
        this._opaqueSubMeshes.dispose(), this._transparentSubMeshes.dispose(), this._alphaTestSubMeshes.dispose(), this._depthOnlySubMeshes.dispose(), this._particleSystems.dispose(), this._spriteManagers.dispose(), this._edgesRenderers.dispose()
      }
      dispatch(OO, KO, pO) {
        void 0 === KO && (KO = OO.getMesh()), void 0 === pO && (pO = OO.UX()), null !== pO && void 0 !== pO && (pO.needAlphaBlendingForMesh(KO) ? this._transparentSubMeshes.push(OO) : pO.needAlphaTestingForMesh(KO) ? (pO.needDepthPrePass && !this.disableDepthPrePass && this._depthOnlySubMeshes.push(OO), this._alphaTestSubMeshes.push(OO)) : (pO.needDepthPrePass && !this.disableDepthPrePass && this._depthOnlySubMeshes.push(OO), this._opaqueSubMeshes.push(OO)), KO._renderingGroup = this, KO._edgesRenderer && KO.isEnabled() && KO.isVisible && KO._edgesRenderer.isEnabled && this._edgesRenderers.pushNoDuplicate(KO._edgesRenderer), this._empty = !1)
      }
      dispatchSprites(OO) {
        this._spriteManagers.push(OO), this._empty = !1
      }
      dispatchParticles(OO) {
        this._particleSystems.push(OO), this._empty = !1
      }
      _renderParticles(OO) {
        if (0 === this._particleSystems.length) return;
        const KO = this._scene.activeCamera;
        this._scene.onBeforeParticlesRenderingObservable.notifyObservers(this._scene);
        for (let pO = 0; pO < this._particleSystems.length; pO++) {
          const XO = this._particleSystems.data[pO];
          if (0 === (KO && KO.layerMask & XO.layerMask)) continue;
          const bK = XO.emitter;
          bK.position && OO && -1 === OO.indexOf(bK) || this._scene._activeParticles.addCount(XO.render(), !1)
        }
        this._scene.onAfterParticlesRenderingObservable.notifyObservers(this._scene)
      }
      _renderSprites() {
        if (!this._scene.spritesEnabled || 0 === this._spriteManagers.length) return;
        const OO = this._scene.activeCamera;
        this._scene.onBeforeSpritesRenderingObservable.notifyObservers(this._scene);
        for (let KO = 0; KO < this._spriteManagers.length; KO++) {
          const pO = this._spriteManagers.data[KO];
          0 !== (OO && OO.layerMask & pO.layerMask) && pO.render()
        }
        this._scene.onAfterSpritesRenderingObservable.notifyObservers(this._scene)
      }
    }
    eO._ZeroVector = bK.o.Zero()
  },
  38235: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO
    });
    var XO = pO(38243);
    class bK {}
    class eO {
      get disableDepthPrePass() {
        return this._disableDepthPrePass
      }
      set disableDepthPrePass(OO) {
        this._disableDepthPrePass = OO;
        for (const KO of this._renderingGroups) KO.disableDepthPrePass = OO
      }
      get maintainStateBetweenFrames() {
        return this._maintainStateBetweenFrames
      }
      set maintainStateBetweenFrames(OO) {
        OO !== this._maintainStateBetweenFrames && (this._maintainStateBetweenFrames = OO, this._maintainStateBetweenFrames || this.restoreDispachedFlags())
      }
      restoreDispachedFlags() {
        for (const OO of this._scene.meshes)
          if (OO.au)
            for (const KO of OO.au) KO._wasDispatched = !1;
        if (this._scene.spriteManagers)
          for (const OO of this._scene.spriteManagers) OO._wasDispatched = !1;
        for (const OO of this._scene.ku) OO._wasDispatched = !1
      }
      constructor(OO) {
        this._useSceneAutoClearSetup = !1, this._disableDepthPrePass = !1, this._renderingGroups = new Array, this._autoClearDepthStencil = {}, this._customOpaqueSortCompareFn = {}, this._customAlphaTestSortCompareFn = {}, this._customTransparentSortCompareFn = {}, this._renderingGroupInfo = new bK, this._maintainStateBetweenFrames = !1, this._scene = OO;
        for (let KO = eO.MIN_RENDERINGGROUPS; KO < eO.MAX_RENDERINGGROUPS; KO++) this._autoClearDepthStencil[KO] = {
          autoClear: !0,
          depth: !0,
          stencil: !0
        }
      }
      get renderingGroups() {
        return this._renderingGroups
      }
      getRenderingGroup(OO) {
        const KO = OO || 0;
        return this._prepareRenderingGroup(KO), this._renderingGroups[KO]
      }
      _clearDepthStencilBuffer() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
          KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        this._depthStencilBufferAlreadyCleaned || (this._scene.qb().clear(null, !1, OO, KO), this._depthStencilBufferAlreadyCleaned = !0)
      }
      render(OO, KO, pO, XO) {
        let bK = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
          lO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
          vK = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6],
          CO = !(arguments.length > 7 && void 0 !== arguments[7]) || arguments[7],
          hO = arguments.length > 8 ? arguments[8] : void 0,
          DO = arguments.length > 9 ? arguments[9] : void 0;
        const MO = this._renderingGroupInfo;
        MO.Ce = this._scene, MO.camera = this._scene.activeCamera, MO.renderingManager = this;
        const aK = DO ?? this._scene.spriteManagers;
        if (aK && XO)
          for (let eO = 0; eO < aK.length; eO++) {
            const OO = aK[eO];
            this.dispatchSprites(OO)
          }
        for (let oO = eO.MIN_RENDERINGGROUPS; oO < eO.MAX_RENDERINGGROUPS; oO++) {
          this._depthStencilBufferAlreadyCleaned = oO === eO.MIN_RENDERINGGROUPS;
          const DO = this._renderingGroups[oO];
          if (!DO || DO._empty) continue;
          const aK = 1 << oO;
          if (MO.renderingGroupId = oO, this._scene.onBeforeRenderingGroupObservable.notifyObservers(MO, aK), eO.AUTOCLEAR) {
            const OO = this._useSceneAutoClearSetup ? this._scene.getAutoClearDepthStencilSetup(oO) : this._autoClearDepthStencil[oO];
            OO && OO.autoClear && this._clearDepthStencilBuffer(OO.depth, OO.stencil)
          }
          for (let OO = 0, KO = this._scene._beforeRenderingGroupDrawStage; OO < KO.length; OO++) {
            KO[OO].action(oO)
          }
          DO.render(OO, XO, pO, KO, bK, lO, vK, CO, hO);
          for (let OO = 0, KO = this._scene._afterRenderingGroupDrawStage; OO < KO.length; OO++) {
            KO[OO].action(oO)
          }
          this._scene.onAfterRenderingGroupObservable.notifyObservers(MO, aK)
        }
      }
      reset() {
        if (!this.maintainStateBetweenFrames)
          for (let OO = eO.MIN_RENDERINGGROUPS; OO < eO.MAX_RENDERINGGROUPS; OO++) {
            const KO = this._renderingGroups[OO];
            KO && KO.prepare()
          }
      }
      resetSprites() {
        if (!this.maintainStateBetweenFrames)
          for (let OO = eO.MIN_RENDERINGGROUPS; OO < eO.MAX_RENDERINGGROUPS; OO++) {
            const KO = this._renderingGroups[OO];
            KO && KO.prepareSprites()
          }
      }
      dispose() {
        this.freeRenderingGroups(), this._renderingGroups.length = 0, this._renderingGroupInfo = null
      }
      freeRenderingGroups() {
        for (let OO = eO.MIN_RENDERINGGROUPS; OO < eO.MAX_RENDERINGGROUPS; OO++) {
          const KO = this._renderingGroups[OO];
          KO && KO.dispose()
        }
      }
      _prepareRenderingGroup(OO) {
        void 0 === this._renderingGroups[OO] && (this._renderingGroups[OO] = new XO.d(OO, this._scene, this._customOpaqueSortCompareFn[OO], this._customAlphaTestSortCompareFn[OO], this._customTransparentSortCompareFn[OO]), this._renderingGroups[OO].disableDepthPrePass = this._disableDepthPrePass)
      }
      dispatchSprites(OO) {
        this.maintainStateBetweenFrames && OO._wasDispatched || (OO._wasDispatched = !0, this.getRenderingGroup(OO.renderingGroupId).dispatchSprites(OO))
      }
      dispatchParticles(OO) {
        this.maintainStateBetweenFrames && OO._wasDispatched || (OO._wasDispatched = !0, this.getRenderingGroup(OO.renderingGroupId).dispatchParticles(OO))
      }
      dispatch(OO, KO, pO) {
        void 0 === KO && (KO = OO.getMesh()), this.maintainStateBetweenFrames && OO._wasDispatched || (OO._wasDispatched = !0, this.getRenderingGroup(KO.renderingGroupId).dispatch(OO, KO, pO))
      }
      setRenderingOrder(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        if (this._customOpaqueSortCompareFn[OO] = KO, this._customAlphaTestSortCompareFn[OO] = pO, this._customTransparentSortCompareFn[OO] = XO, this._renderingGroups[OO]) {
          const KO = this._renderingGroups[OO];
          KO.opaqueSortCompareFn = this._customOpaqueSortCompareFn[OO], KO.alphaTestSortCompareFn = this._customAlphaTestSortCompareFn[OO], KO.transparentSortCompareFn = this._customTransparentSortCompareFn[OO]
        }
      }
      setRenderingAutoClearDepthStencil(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
          XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        this._autoClearDepthStencil[OO] = {
          autoClear: KO,
          depth: pO,
          stencil: XO
        }
      }
      getAutoClearDepthStencilSetup(OO) {
        return this._autoClearDepthStencil[OO]
      }
    }
    eO.MAX_RENDERINGGROUPS = 4, eO.MIN_RENDERINGGROUPS = 0, eO.AUTOCLEAR = !0
  },
  37972: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO
    });
    class XO {
      constructor(OO) {
        this._supportBlendParametersPerTarget = OO, this._blendFunctionParameters = new Array(32), this._blendEquationParameters = new Array(16), this._blendConstants = new Array(4), this._isBlendConstantsDirty = !1, this._alphaBlend = Array(8).fill(!1), this._numTargetEnabled = 0, this._isAlphaBlendDirty = !1, this._isBlendFunctionParametersDirty = !1, this._isBlendEquationParametersDirty = !1, this._blendDisabledTargetsMask = 0, this._numTargets = 1, this.reset()
      }
      get isDirty() {
        return this._isAlphaBlendDirty || this._isBlendFunctionParametersDirty || this._isBlendEquationParametersDirty
      }
      get alphaBlend() {
        return this._numTargetEnabled > 0
      }
      set alphaBlend(OO) {
        this.setAlphaBlend(OO)
      }
      setAlphaBlend(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        this._alphaBlend[KO] !== OO && (OO ? this._numTargetEnabled++ : this._numTargetEnabled--, this._alphaBlend[KO] = OO, this._isAlphaBlendDirty = !0)
      }
      setAlphaBlendConstants(OO, KO, pO, XO) {
        this._blendConstants[0] === OO && this._blendConstants[1] === KO && this._blendConstants[2] === pO && this._blendConstants[3] === XO || (this._blendConstants[0] = OO, this._blendConstants[1] = KO, this._blendConstants[2] = pO, this._blendConstants[3] = XO, this._isBlendConstantsDirty = !0)
      }
      setAlphaBlendFunctionParameters(OO, KO, pO, XO) {
        const bK = 4 * (arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0);
        this._blendFunctionParameters[bK + 0] === OO && this._blendFunctionParameters[bK + 1] === KO && this._blendFunctionParameters[bK + 2] === pO && this._blendFunctionParameters[bK + 3] === XO || (this._blendFunctionParameters[bK + 0] = OO, this._blendFunctionParameters[bK + 1] = KO, this._blendFunctionParameters[bK + 2] = pO, this._blendFunctionParameters[bK + 3] = XO, this._isBlendFunctionParametersDirty = !0)
      }
      setAlphaEquationParameters(OO, KO) {
        const pO = 2 * (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0);
        this._blendEquationParameters[pO + 0] === OO && this._blendEquationParameters[pO + 1] === KO || (this._blendEquationParameters[pO + 0] = OO, this._blendEquationParameters[pO + 1] = KO, this._isBlendEquationParametersDirty = !0)
      }
      reset() {
        this._alphaBlend.fill(!1), this._numTargetEnabled = 0, this._blendFunctionParameters.fill(null), this._blendEquationParameters.fill(null), this._blendConstants[0] = null, this._blendConstants[1] = null, this._blendConstants[2] = null, this._blendConstants[3] = null, this._isAlphaBlendDirty = !0, this._isBlendFunctionParametersDirty = !1, this._isBlendEquationParametersDirty = !1, this._isBlendConstantsDirty = !1, this._blendDisabledTargetsMask = 0, this._numTargets = 1
      }
      apply(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        if (this._numTargets !== KO && (this._numTargets = KO, this._isAlphaBlendDirty = !0), this._blendDisabledTargetsMask !== pO && (this._blendDisabledTargetsMask = pO, this._isAlphaBlendDirty = !0), !this.isDirty) return;
        if (this._isBlendConstantsDirty && (OO.blendColor(this._blendConstants[0], this._blendConstants[1], this._blendConstants[2], this._blendConstants[3]), this._isBlendConstantsDirty = !1), 1 === KO || !this._supportBlendParametersPerTarget) {
          if (this._isAlphaBlendDirty) {
            if (KO > 1 && 0 !== pO && this.alphaBlend) throw new Error("AlphaState: blending with integer MRT attachments requires per-target blend parameters");
            this._alphaBlend[0] && 0 === (1 & pO) ? OO.enable(OO.BLEND) : OO.disable(OO.BLEND), this._isAlphaBlendDirty = !1
          }
          return this._isBlendFunctionParametersDirty && (OO.blendFuncSeparate(this._blendFunctionParameters[0], this._blendFunctionParameters[1], this._blendFunctionParameters[2], this._blendFunctionParameters[3]), this._isBlendFunctionParametersDirty = !1), void(this._isBlendEquationParametersDirty && (OO.blendEquationSeparate(this._blendEquationParameters[0], this._blendEquationParameters[1]), this._isBlendEquationParametersDirty = !1))
        }
        const XO = OO;
        if (this._isAlphaBlendDirty) {
          for (let bK = 0; bK < KO; bK++) {
            const KO = bK < this._numTargetEnabled ? bK : 0;
            this._alphaBlend[KO] && 0 === (pO & 1 << bK) ? XO.enableIndexed(OO.BLEND, bK) : XO.disableIndexed(OO.BLEND, bK)
          }
          this._isAlphaBlendDirty = !1
        }
        if (this._isBlendFunctionParametersDirty) {
          for (let OO = 0; OO < KO; OO++) {
            const KO = OO < this._numTargetEnabled ? 4 * OO : 0;
            XO.blendFuncSeparateIndexed(OO, this._blendFunctionParameters[KO + 0], this._blendFunctionParameters[KO + 1], this._blendFunctionParameters[KO + 2], this._blendFunctionParameters[KO + 3])
          }
          this._isBlendFunctionParametersDirty = !1
        }
        if (this._isBlendEquationParametersDirty) {
          for (let OO = 0; OO < KO; OO++) {
            const KO = OO < this._numTargetEnabled ? 2 * OO : 0;
            XO.blendEquationSeparateIndexed(OO, this._blendEquationParameters[KO + 0], this._blendEquationParameters[KO + 1])
          }
          this._isBlendEquationParametersDirty = !1
        }
      }
      setAlphaMode(OO, KO) {
        let pO = 32774;
        switch (OO) {
          case 0:
            break;
          case 7:
            this.setAlphaBlendFunctionParameters(1, 771, 1, 1, KO);
            break;
          case 8:
          case 14:
            this.setAlphaBlendFunctionParameters(1, 771, 1, 771, KO);
            break;
          case 2:
            this.setAlphaBlendFunctionParameters(770, 771, 1, 1, KO);
            break;
          case 6:
            this.setAlphaBlendFunctionParameters(1, 1, 0, 1, KO);
            break;
          case 1:
            this.setAlphaBlendFunctionParameters(770, 1, 0, 1, KO);
            break;
          case 3:
            this.setAlphaBlendFunctionParameters(0, 769, 1, 1, KO);
            break;
          case 4:
            this.setAlphaBlendFunctionParameters(774, 0, 1, 1, KO);
            break;
          case 5:
            this.setAlphaBlendFunctionParameters(770, 769, 1, 1, KO);
            break;
          case 9:
            this.setAlphaBlendFunctionParameters(32769, 32770, 32771, 32772, KO);
            break;
          case 10:
            this.setAlphaBlendFunctionParameters(1, 769, 1, 771, KO);
            break;
          case 11:
            this.setAlphaBlendFunctionParameters(1, 1, 1, 1, KO);
            break;
          case 12:
            this.setAlphaBlendFunctionParameters(772, 1, 0, 0, KO);
            break;
          case 13:
            this.setAlphaBlendFunctionParameters(775, 769, 773, 771, KO);
            break;
          case 15:
            this.setAlphaBlendFunctionParameters(1, 1, 1, 0, KO);
            break;
          case 16:
            this.setAlphaBlendFunctionParameters(775, 769, 0, 1, KO);
            break;
          case 17:
            this.setAlphaBlendFunctionParameters(770, 771, 1, 771, KO);
            break;
          case 18:
            this.setAlphaBlendFunctionParameters(1, 1, 1, 1, KO), pO = 32775;
            break;
          case 19:
            this.setAlphaBlendFunctionParameters(1, 1, 1, 1, KO), pO = 32776;
            break;
          case 20:
            this.setAlphaBlendFunctionParameters(1, 35065, 0, 1, KO);
            break;
          case 21:
            this.setAlphaBlendFunctionParameters(1, 0, 1, 771, KO)
        }
        this.setAlphaEquationParameters(pO, pO, KO)
      }
    }
  },
  38269: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {}
    XO._IsPickingAvailable = !1
  },
  38170: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vX,
      e: () => ep
    });
    var XO = pO(38172),
      bK = pO(37955),
      eO = pO(37966),
      lO = pO(35660),
      vK = pO(38186);
    class CO {
      constructor() {
        this._count = 0, this._data = {}
      }
      NhO(OO) {
        this.clear(), OO.forEach(((OO, KO) => this.add(OO, KO)))
      }
      get(OO) {
        const KO = this._data[OO];
        if (void 0 !== KO) return KO
      }
      getOrAddWithFactory(OO, KO) {
        let pO = this.get(OO);
        return void 0 !== pO || (pO = KO(OO), pO && this.add(OO, pO)), pO
      }
      getOrAdd(OO, KO) {
        const pO = this.get(OO);
        return void 0 !== pO ? pO : (this.add(OO, KO), KO)
      }
      contains(OO) {
        return void 0 !== this._data[OO]
      }
      add(OO, KO) {
        return void 0 === this._data[OO] && (this._data[OO] = KO, ++this._count, !0)
      }
      set(OO, KO) {
        return void 0 !== this._data[OO] && (this._data[OO] = KO, !0)
      }
      getAndRemove(OO) {
        const KO = this.get(OO);
        return void 0 !== KO ? (delete this._data[OO], --this._count, KO) : null
      }
      remove(OO) {
        return !!this.contains(OO) && (delete this._data[OO], --this._count, !0)
      }
      clear() {
        this._data = {}, this._count = 0
      }
      get count() {
        return this._count
      }
      forEach(OO) {
        for (const KO in this._data) {
          OO(KO, this._data[KO])
        }
      }
      first(OO) {
        for (const KO in this._data) {
          const pO = OO(KO, this._data[KO]);
          if (pO) return pO
        }
        return null
      }
    }
    var hO = pO(38085),
      DO = pO(35632),
      MO = pO(38191),
      aK = pO(38206),
      oO = pO(38209);
    class FO {
      constructor(OO, KO, pO, XO, bK, eO) {
        this.source = OO, this.pointerX = KO, this.pointerY = pO, this.meshUnderPointer = XO, this.sourceEvent = bK, this.additionalData = eO
      }
      static CreateNew(OO, KO, pO) {
        const XO = OO.JKO();
        return new FO(OO, XO.pointerX, XO.pointerY, XO.meshUnderPointer || OO, KO, pO)
      }
      static CreateNewFromSprite(OO, KO, pO, XO) {
        return new FO(OO, KO.pointerX, KO.pointerY, KO.meshUnderPointer, pO, XO)
      }
      static CreateNewFromScene(OO, KO) {
        return new FO(null, OO.pointerX, OO.pointerY, OO.meshUnderPointer, KO)
      }
      static CreateNewFromPrimitive(OO, KO, pO, XO) {
        return new FO(OO, KO.x, KO.y, null, pO, XO)
      }
    }
    var VO = pO(38225),
      LO = pO(38231),
      QO = pO(38235),
      zK = pO(38250),
      AO = pO(37918),
      fO = pO(35653),
      dO = pO(37938),
      TO = pO(38254);
    class NO {
      constructor() {
        this.hoverCursor = "", this.actions = [], this.isRecursive = !1, this.disposeWhenUnowned = !0
      }
      static get HasTriggers() {
        for (const OO in NO.Triggers)
          if (Object.prototype.hasOwnProperty.call(NO.Triggers, OO)) return !0;
        return !1
      }
      static get HasPickTriggers() {
        for (const OO in NO.Triggers)
          if (Object.prototype.hasOwnProperty.call(NO.Triggers, OO)) {
            const KO = parseInt(OO);
            if (KO >= 1 && KO <= 7) return !0
          } return !1
      }
      static HasSpecificTrigger(OO) {
        for (const KO in NO.Triggers)
          if (Object.prototype.hasOwnProperty.call(NO.Triggers, KO)) {
            if (parseInt(KO) === OO) return !0
          } return !1
      }
    }
    NO.Triggers = {};
    var IO, yK, gK, uO, EO, jK, YO, wO = pO(38258);
    ! function(OO) {
      OO[OO.Generic = 0] = "Generic", OO[OO.Keyboard = 1] = "Keyboard", OO[OO.Mouse = 2] = "Mouse", OO[OO.Touch = 3] = "Touch", OO[OO.DualShock = 4] = "DualShock", OO[OO.Xbox = 5] = "Xbox", OO[OO.Switch = 6] = "Switch", OO[OO.DualSense = 7] = "DualSense"
    }(IO || (IO = {})),
    function(OO) {
      OO[OO.Horizontal = 0] = "Horizontal", OO[OO.Vertical = 1] = "Vertical", OO[OO.LeftClick = 2] = "LeftClick", OO[OO.MiddleClick = 3] = "MiddleClick", OO[OO.RightClick = 4] = "RightClick", OO[OO.BrowserBack = 5] = "BrowserBack", OO[OO.BrowserForward = 6] = "BrowserForward", OO[OO.MouseWheelX = 7] = "MouseWheelX", OO[OO.MouseWheelY = 8] = "MouseWheelY", OO[OO.MouseWheelZ = 9] = "MouseWheelZ", OO[OO.Move = 12] = "Move"
    }(yK || (yK = {})),
    function(OO) {
      OO[OO.Horizontal = 0] = "Horizontal", OO[OO.Vertical = 1] = "Vertical", OO[OO.LeftClick = 2] = "LeftClick", OO[OO.MiddleClick = 3] = "MiddleClick", OO[OO.RightClick = 4] = "RightClick", OO[OO.BrowserBack = 5] = "BrowserBack", OO[OO.BrowserForward = 6] = "BrowserForward", OO[OO.MouseWheelX = 7] = "MouseWheelX", OO[OO.MouseWheelY = 8] = "MouseWheelY", OO[OO.MouseWheelZ = 9] = "MouseWheelZ", OO[OO.DeltaHorizontal = 10] = "DeltaHorizontal", OO[OO.DeltaVertical = 11] = "DeltaVertical"
    }(gK || (gK = {})),
    function(OO) {
      OO[OO.Cross = 0] = "Cross", OO[OO.Circle = 1] = "Circle", OO[OO.Square = 2] = "Square", OO[OO.Triangle = 3] = "Triangle", OO[OO.L1 = 4] = "L1", OO[OO.R1 = 5] = "R1", OO[OO.L2 = 6] = "L2", OO[OO.R2 = 7] = "R2", OO[OO.Share = 8] = "Share", OO[OO.Options = 9] = "Options", OO[OO.L3 = 10] = "L3", OO[OO.R3 = 11] = "R3", OO[OO.DPadUp = 12] = "DPadUp", OO[OO.DPadDown = 13] = "DPadDown", OO[OO.DPadLeft = 14] = "DPadLeft", OO[OO.DPadRight = 15] = "DPadRight", OO[OO.Home = 16] = "Home", OO[OO.TouchPad = 17] = "TouchPad", OO[OO.LStickXAxis = 18] = "LStickXAxis", OO[OO.LStickYAxis = 19] = "LStickYAxis", OO[OO.RStickXAxis = 20] = "RStickXAxis", OO[OO.RStickYAxis = 21] = "RStickYAxis"
    }(uO || (uO = {})),
    function(OO) {
      OO[OO.Cross = 0] = "Cross", OO[OO.Circle = 1] = "Circle", OO[OO.Square = 2] = "Square", OO[OO.Triangle = 3] = "Triangle", OO[OO.L1 = 4] = "L1", OO[OO.R1 = 5] = "R1", OO[OO.L2 = 6] = "L2", OO[OO.R2 = 7] = "R2", OO[OO.Create = 8] = "Create", OO[OO.Options = 9] = "Options", OO[OO.L3 = 10] = "L3", OO[OO.R3 = 11] = "R3", OO[OO.DPadUp = 12] = "DPadUp", OO[OO.DPadDown = 13] = "DPadDown", OO[OO.DPadLeft = 14] = "DPadLeft", OO[OO.DPadRight = 15] = "DPadRight", OO[OO.Home = 16] = "Home", OO[OO.TouchPad = 17] = "TouchPad", OO[OO.LStickXAxis = 18] = "LStickXAxis", OO[OO.LStickYAxis = 19] = "LStickYAxis", OO[OO.RStickXAxis = 20] = "RStickXAxis", OO[OO.RStickYAxis = 21] = "RStickYAxis"
    }(EO || (EO = {})),
    function(OO) {
      OO[OO.A = 0] = "A", OO[OO.B = 1] = "B", OO[OO.X = 2] = "X", OO[OO.Y = 3] = "Y", OO[OO.LB = 4] = "LB", OO[OO.RB = 5] = "RB", OO[OO.LT = 6] = "LT", OO[OO.RT = 7] = "RT", OO[OO.Back = 8] = "Back", OO[OO.Start = 9] = "Start", OO[OO.LS = 10] = "LS", OO[OO.RS = 11] = "RS", OO[OO.DPadUp = 12] = "DPadUp", OO[OO.DPadDown = 13] = "DPadDown", OO[OO.DPadLeft = 14] = "DPadLeft", OO[OO.DPadRight = 15] = "DPadRight", OO[OO.Home = 16] = "Home", OO[OO.LStickXAxis = 17] = "LStickXAxis", OO[OO.LStickYAxis = 18] = "LStickYAxis", OO[OO.RStickXAxis = 19] = "RStickXAxis", OO[OO.RStickYAxis = 20] = "RStickYAxis"
    }(jK || (jK = {})),
    function(OO) {
      OO[OO.B = 0] = "B", OO[OO.A = 1] = "A", OO[OO.Y = 2] = "Y", OO[OO.X = 3] = "X", OO[OO.L = 4] = "L", OO[OO.R = 5] = "R", OO[OO.ZL = 6] = "ZL", OO[OO.ZR = 7] = "ZR", OO[OO.Minus = 8] = "Minus", OO[OO.Plus = 9] = "Plus", OO[OO.LS = 10] = "LS", OO[OO.RS = 11] = "RS", OO[OO.DPadUp = 12] = "DPadUp", OO[OO.DPadDown = 13] = "DPadDown", OO[OO.DPadLeft = 14] = "DPadLeft", OO[OO.DPadRight = 15] = "DPadRight", OO[OO.Home = 16] = "Home", OO[OO.Capture = 17] = "Capture", OO[OO.LStickXAxis = 18] = "LStickXAxis", OO[OO.LStickYAxis = 19] = "LStickYAxis", OO[OO.RStickXAxis = 20] = "RStickXAxis", OO[OO.RStickYAxis = 21] = "RStickYAxis"
    }(YO || (YO = {}));
    var iK = pO(38266);
    class rK {
      static CreateDeviceEvent(OO, KO, pO, XO, bK, eO, lO) {
        switch (OO) {
          case IO.Keyboard:
            return this._CreateKeyboardEvent(pO, XO, bK, eO);
          case IO.Mouse:
            if (pO === yK.MouseWheelX || pO === yK.MouseWheelY || pO === yK.MouseWheelZ) return this._CreateWheelEvent(OO, KO, pO, XO, bK, eO);
          case IO.Touch:
            return this._CreatePointerEvent(OO, KO, pO, XO, bK, eO, lO);
          default:
            throw `Unable to generate event for device ${IO[OO]}`
        }
      }
      static _CreatePointerEvent(OO, KO, pO, XO, bK, eO, lO) {
        const vK = this._CreateMouseEvent(OO, KO, pO, XO, bK, eO);
        OO === IO.Mouse ? (vK.deviceType = IO.Mouse, vK.pointerId = 1, vK.pointerType = "mouse") : (vK.deviceType = IO.Touch, vK.pointerId = lO ?? KO, vK.pointerType = "touch");
        let CO = 0;
        return CO += bK.pollInput(OO, KO, yK.LeftClick), CO += 2 * bK.pollInput(OO, KO, yK.RightClick), CO += 4 * bK.pollInput(OO, KO, yK.MiddleClick), vK.buttons = CO, pO === yK.Move ? vK.type = "pointermove" : pO >= yK.LeftClick && pO <= yK.RightClick && (vK.type = 1 === XO ? "pointerdown" : "pointerup", vK.button = pO - 2), vK
      }
      static _CreateWheelEvent(OO, KO, pO, XO, bK, eO) {
        const lO = this._CreateMouseEvent(OO, KO, pO, XO, bK, eO);
        switch (lO.pointerId = 1, lO.type = "wheel", lO.deltaMode = iK.e.DOM_DELTA_PIXEL, lO.deltaX = 0, lO.deltaY = 0, lO.deltaZ = 0, pO) {
          case yK.MouseWheelX:
            lO.deltaX = XO;
            break;
          case yK.MouseWheelY:
            lO.deltaY = XO;
            break;
          case yK.MouseWheelZ:
            lO.deltaZ = XO
        }
        return lO
      }
      static _CreateMouseEvent(OO, KO, pO, XO, bK, eO) {
        const lO = this._CreateEvent(eO),
          vK = bK.pollInput(OO, KO, yK.Horizontal),
          CO = bK.pollInput(OO, KO, yK.Vertical);
        return eO ? (lO.movementX = 0, lO.movementY = 0, lO.offsetX = lO.movementX - eO.getBoundingClientRect().x, lO.offsetY = lO.movementY - eO.getBoundingClientRect().y) : (lO.movementX = bK.pollInput(OO, KO, 10), lO.movementY = bK.pollInput(OO, KO, 11), lO.offsetX = 0, lO.offsetY = 0), this._CheckNonCharacterKeys(lO, bK), lO.clientX = vK, lO.clientY = CO, lO.x = vK, lO.y = CO, lO.deviceType = OO, lO.deviceSlot = KO, lO.inputIndex = pO, lO
      }
      static _CreateKeyboardEvent(OO, KO, pO, XO) {
        const bK = this._CreateEvent(XO);
        return this._CheckNonCharacterKeys(bK, pO), bK.deviceType = IO.Keyboard, bK.deviceSlot = 0, bK.inputIndex = OO, bK.type = 1 === KO ? "keydown" : "keyup", bK.key = String.fromCharCode(OO), bK.keyCode = OO, bK
      }
      static _CheckNonCharacterKeys(OO, KO) {
        const pO = KO.isDeviceAvailable(IO.Keyboard),
          XO = pO && 1 === KO.pollInput(IO.Keyboard, 0, 18),
          bK = pO && 1 === KO.pollInput(IO.Keyboard, 0, 17),
          eO = pO && (1 === KO.pollInput(IO.Keyboard, 0, 91) || 1 === KO.pollInput(IO.Keyboard, 0, 92) || 1 === KO.pollInput(IO.Keyboard, 0, 93)),
          lO = pO && 1 === KO.pollInput(IO.Keyboard, 0, 16);
        OO.altKey = XO, OO.ctrlKey = bK, OO.metaKey = eO, OO.shiftKey = lO
      }
      static _CreateEvent(OO) {
        const KO = {
          preventDefault: () => {}
        };
        return KO.target = OO, KO
      }
    }
    class PO {
      constructor(OO, KO, pO) {
        this._nativeInput = _native.DeviceInputSystem ? new _native.DeviceInputSystem(OO, KO, ((OO, KO, XO, bK) => {
          const eO = rK.CreateDeviceEvent(OO, KO, XO, bK, this);
          pO(OO, KO, eO)
        })) : this._createDummyNativeInput()
      }
      pollInput(OO, KO, pO) {
        return this._nativeInput.pollInput(OO, KO, pO)
      }
      isDeviceAvailable(OO) {
        return OO === IO.Mouse || OO === IO.Touch
      }
      dispose() {
        this._nativeInput.dispose()
      }
      _createDummyNativeInput() {
        return {
          pollInput: () => 0,
          isDeviceAvailable: () => !1,
          dispose: () => {}
        }
      }
    }
    const mK = Object.keys(yK).length / 2;
    class sO {
      constructor(OO, KO, pO, bK) {
        this._inputs = [], this._keyboardActive = !1, this._pointerActive = !1, this._usingSafari = XO.k.IsSafari(), this._usingMacOs = (0, AO.k)() && /(Mac|iPhone|iPod|iPad)/i.test(navigator.platform), this._keyboardDownEvent = OO => {}, this._keyboardUpEvent = OO => {}, this._keyboardBlurEvent = OO => {}, this._pointerMoveEvent = OO => {}, this._pointerDownEvent = OO => {}, this._pointerUpEvent = OO => {}, this._pointerCancelEvent = OO => {}, this._pointerCancelTouch = OO => {}, this._pointerLeaveEvent = OO => {}, this._pointerWheelEvent = OO => {}, this._pointerBlurEvent = OO => {}, this._pointerMacOsChromeOutEvent = OO => {}, this._eventsAttached = !1, this._mouseId = -1, this._isUsingFirefox = (0, AO.k)() && navigator.userAgent && -1 !== navigator.userAgent.indexOf("Firefox"), this._isUsingChromium = (0, AO.k)() && navigator.userAgent && -1 !== navigator.userAgent.indexOf("Chrome"), this._maxTouchPoints = 0, this._pointerInputClearObserver = null, this._gamepadConnectedEvent = OO => {}, this._gamepadDisconnectedEvent = OO => {}, this._eventPrefix = XO.k.GetPointerPrefix(OO), this._engine = OO, this._onDeviceConnected = KO, this._onDeviceDisconnected = pO, this._onInputChanged = bK, this._mouseId = this._isUsingFirefox ? 0 : 1, this._enableEvents(), this._usingMacOs && (this._metaKeys = []), this._engine._onEngineViewChanged || (this._engine._onEngineViewChanged = () => {
          this._enableEvents()
        })
      }
      pollInput(OO, KO, pO) {
        const bK = this._inputs[OO][KO];
        if (!bK) throw `Unable to find device ${IO[OO]}`;
        OO >= IO.DualShock && OO <= IO.DualSense && this._updateDevice(OO, KO, pO);
        const eO = bK[pO];
        if (void 0 === eO) throw `Unable to find input ${pO} for device ${IO[OO]} in slot ${KO}`;
        return pO === yK.Move && XO.k.Warn("Unable to provide information for PointerInput.Move.  Try using PointerInput.Horizontal or PointerInput.Vertical for move data."), eO
      }
      isDeviceAvailable(OO) {
        return void 0 !== this._inputs[OO]
      }
      dispose() {
        this._onDeviceConnected = () => {}, this._onDeviceDisconnected = () => {}, this._onInputChanged = () => {}, delete this._engine._onEngineViewChanged, this._elementToAttachTo && this._disableEvents()
      }
      _enableEvents() {
        const OO = this?._engine.getInputElement();
        if (OO && (!this._eventsAttached || this._elementToAttachTo !== OO)) {
          if (this._disableEvents(), this._inputs)
            for (const OO of this._inputs)
              if (OO)
                for (const KO in OO) {
                  const pO = OO[+KO];
                  if (pO)
                    for (let OO = 0; OO < pO.length; OO++) pO[OO] = 0
                }
          this._elementToAttachTo = OO, this._elementToAttachTo.tabIndex = -1 !== this._elementToAttachTo.tabIndex ? this._elementToAttachTo.tabIndex : this._engine.canvasTabIndex, this._handleKeyActions(), this._handlePointerActions(), this._handleGamepadActions(), this._eventsAttached = !0, this._checkForConnectedDevices()
        }
      }
      _disableEvents() {
        this._elementToAttachTo && (this._elementToAttachTo.removeEventListener("blur", this._keyboardBlurEvent), this._elementToAttachTo.removeEventListener("blur", this._pointerBlurEvent), this._elementToAttachTo.removeEventListener("keydown", this._keyboardDownEvent), this._elementToAttachTo.removeEventListener("keyup", this._keyboardUpEvent), this._elementToAttachTo.removeEventListener(this._eventPrefix + "move", this._pointerMoveEvent), this._elementToAttachTo.removeEventListener(this._eventPrefix + "down", this._pointerDownEvent), this._elementToAttachTo.removeEventListener(this._eventPrefix + "up", this._pointerUpEvent), this._elementToAttachTo.removeEventListener(this._eventPrefix + "cancel", this._pointerCancelEvent), this._elementToAttachTo.removeEventListener(this._eventPrefix + "DX", this._pointerLeaveEvent), this._elementToAttachTo.removeEventListener(this._wheelEventName, this._pointerWheelEvent), this._usingMacOs && this._isUsingChromium && this._elementToAttachTo.removeEventListener("lostpointercapture", this._pointerMacOsChromeOutEvent), window.removeEventListener("gamepadconnected", this._gamepadConnectedEvent), window.removeEventListener("gamepaddisconnected", this._gamepadDisconnectedEvent)), this._pointerInputClearObserver && this._engine.onEndFrameObservable.remove(this._pointerInputClearObserver), this._eventsAttached = !1
      }
      _checkForConnectedDevices() {
        if (navigator.getGamepads) {
          const OO = navigator.getGamepads();
          for (const KO of OO) KO && this._addGamePad(KO)
        }
        "function" === typeof matchMedia && matchMedia("(pointer:fine)").matches && this._addPointerDevice(IO.Mouse, 0, 0, 0)
      }
      _addGamePad(OO) {
        const KO = this._getGamepadDeviceType(OO.id),
          pO = OO.index;
        this._gamepads = this._gamepads || new Array(OO.index + 1), this._registerDevice(KO, pO, OO.buttons.length + OO.axes.length), this._gamepads[pO] = KO
      }
      _addPointerDevice(OO, KO, pO, XO) {
        this._pointerActive || (this._pointerActive = !0), this._registerDevice(OO, KO, mK);
        const bK = this._inputs[OO][KO];
        bK[0] = pO, bK[1] = XO
      }
      _registerDevice(OO, KO, pO) {
        if (void 0 === KO) throw `Unable to register device ${IO[OO]} to undefined slot.`;
        if (this._inputs[OO] || (this._inputs[OO] = {}), !this._inputs[OO][KO]) {
          const XO = new Array(pO);
          XO.fill(0), this._inputs[OO][KO] = XO, this._onDeviceConnected(OO, KO)
        }
      }
      _unregisterDevice(OO, KO) {
        this._inputs[OO][KO] && (delete this._inputs[OO][KO], this._onDeviceDisconnected(OO, KO))
      }
      _handleKeyActions() {
        this._keyboardDownEvent = OO => {
          this._keyboardActive || (this._keyboardActive = !0, this._registerDevice(IO.Keyboard, 0, 255));
          const KO = this._inputs[IO.Keyboard][0];
          if (KO) {
            KO[OO.keyCode] = 1;
            const pO = OO;
            pO.inputIndex = OO.keyCode, this._usingMacOs && OO.metaKey && "Meta" !== OO.key && (this._metaKeys.includes(OO.keyCode) || this._metaKeys.push(OO.keyCode)), this._onInputChanged(IO.Keyboard, 0, pO)
          }
        }, this._keyboardUpEvent = OO => {
          this._keyboardActive || (this._keyboardActive = !0, this._registerDevice(IO.Keyboard, 0, 255));
          const KO = this._inputs[IO.Keyboard][0];
          if (KO) {
            KO[OO.keyCode] = 0;
            const pO = OO;
            if (pO.inputIndex = OO.keyCode, this._usingMacOs && "Meta" === OO.key && this._metaKeys.length > 0) {
              for (const OO of this._metaKeys) {
                const pO = rK.CreateDeviceEvent(IO.Keyboard, 0, OO, 0, this, this._elementToAttachTo);
                KO[OO] = 0, this._onInputChanged(IO.Keyboard, 0, pO)
              }
              this._metaKeys.splice(0, this._metaKeys.length)
            }
            this._onInputChanged(IO.Keyboard, 0, pO)
          }
        }, this._keyboardBlurEvent = () => {
          if (this._keyboardActive) {
            const OO = this._inputs[IO.Keyboard][0];
            for (let KO = 0; KO < OO.length; KO++)
              if (0 !== OO[KO]) {
                OO[KO] = 0;
                const pO = rK.CreateDeviceEvent(IO.Keyboard, 0, KO, 0, this, this._elementToAttachTo);
                this._onInputChanged(IO.Keyboard, 0, pO)
              } this._usingMacOs && this._metaKeys.splice(0, this._metaKeys.length)
          }
        }, this._elementToAttachTo.addEventListener("keydown", this._keyboardDownEvent), this._elementToAttachTo.addEventListener("keyup", this._keyboardUpEvent), this._elementToAttachTo.addEventListener("blur", this._keyboardBlurEvent)
      }
      _handlePointerActions() {
        this._maxTouchPoints = (0, AO.k)() && navigator.maxTouchPoints || 2, this._activeTouchIds || (this._activeTouchIds = new Array(this._maxTouchPoints));
        for (let XO = 0; XO < this._maxTouchPoints; XO++) this._activeTouchIds[XO] = -1;
        this._pointerMoveEvent = OO => {
          const KO = this._getPointerType(OO);
          let pO = KO === IO.Mouse ? 0 : this._activeTouchIds.indexOf(OO.pointerId);
          if (KO === IO.Touch && -1 === pO) {
            if (0 === OO.buttons) return;
            const bK = this._activeTouchIds.indexOf(-1);
            if (!(bK >= 0)) return void XO.k.Warn(`Max number of touches exceeded.  Ignoring touches in excess of ${this._maxTouchPoints}`);
            pO = bK, this._activeTouchIds[bK] = OO.pointerId, this._onDeviceConnected(KO, pO)
          }
          this._inputs[KO] || (this._inputs[KO] = {}), this._inputs[KO][pO] || this._addPointerDevice(KO, pO, OO.clientX, OO.clientY);
          const bK = this._inputs[KO][pO];
          if (bK) {
            const XO = OO;
            XO.inputIndex = yK.Move, bK[yK.Horizontal] = OO.clientX, bK[yK.Vertical] = OO.clientY, KO === IO.Touch && 0 === bK[yK.LeftClick] && (bK[yK.LeftClick] = 1), void 0 === OO.pointerId && (OO.pointerId = this._mouseId), this._onInputChanged(KO, pO, XO), this._usingSafari || -1 === OO.button || (XO.inputIndex = OO.button + 2, bK[OO.button + 2] = bK[OO.button + 2] ? 0 : 1, this._onInputChanged(KO, pO, XO))
          }
        }, this._pointerDownEvent = OO => {
          const KO = this._getPointerType(OO);
          let pO = KO === IO.Mouse ? 0 : OO.pointerId;
          if (KO === IO.Touch) {
            let KO = this._activeTouchIds.indexOf(OO.pointerId);
            if (-1 === KO && (KO = this._activeTouchIds.indexOf(-1)), !(KO >= 0)) return void XO.k.Warn(`Max number of touches exceeded.  Ignoring touches in excess of ${this._maxTouchPoints}`);
            pO = KO, this._activeTouchIds[KO] = OO.pointerId
          }
          this._inputs[KO] || (this._inputs[KO] = {}), this._inputs[KO][pO] ? KO === IO.Touch && this._onDeviceConnected(KO, pO) : this._addPointerDevice(KO, pO, OO.clientX, OO.clientY);
          const bK = this._inputs[KO][pO];
          if (bK) {
            const XO = bK[yK.Horizontal],
              lO = bK[yK.Vertical];
            if (KO === IO.Mouse) {
              if (void 0 === OO.pointerId && (OO.pointerId = this._mouseId), !document.pointerLockElement) try {
                this._elementToAttachTo.setPointerCapture(this._mouseId)
              } catch (eO) {}
            } else if (OO.pointerId && !document.pointerLockElement) try {
              this._elementToAttachTo.setPointerCapture(OO.pointerId)
            } catch (eO) {}
            bK[yK.Horizontal] = OO.clientX, bK[yK.Vertical] = OO.clientY, bK[OO.button + 2] = 1;
            const vK = OO;
            vK.inputIndex = OO.button + 2, this._onInputChanged(KO, pO, vK), XO === OO.clientX && lO === OO.clientY || (vK.inputIndex = yK.Move, this._onInputChanged(KO, pO, vK))
          }
        }, this._pointerUpEvent = OO => {
          const KO = this._getPointerType(OO),
            pO = KO === IO.Mouse ? 0 : this._activeTouchIds.indexOf(OO.pointerId);
          if (KO === IO.Touch) {
            if (-1 === pO) return;
            this._activeTouchIds[pO] = -1
          }
          const XO = this._inputs[KO]?.[pO];
          let bK = OO.button,
            eO = XO && 0 !== XO[bK + 2];
          if (!eO && this._isUsingFirefox && this._usingMacOs && XO && (bK = 2 === bK ? 0 : 2, eO = 0 !== XO[bK + 2]), eO) {
            const eO = XO[yK.Horizontal],
              lO = XO[yK.Vertical];
            XO[yK.Horizontal] = OO.clientX, XO[yK.Vertical] = OO.clientY, XO[bK + 2] = 0;
            const vK = OO;
            void 0 === OO.pointerId && (OO.pointerId = this._mouseId), eO === OO.clientX && lO === OO.clientY || (vK.inputIndex = yK.Move, this._onInputChanged(KO, pO, vK)), vK.inputIndex = bK + 2, KO === IO.Mouse && this._mouseId >= 0 && this._elementToAttachTo.hasPointerCapture?.(this._mouseId) ? this._elementToAttachTo.releasePointerCapture(this._mouseId) : OO.pointerId && this._elementToAttachTo.hasPointerCapture?.(OO.pointerId) && this._elementToAttachTo.releasePointerCapture(OO.pointerId), this._onInputChanged(KO, pO, vK), KO === IO.Touch && this._onDeviceDisconnected(KO, pO)
          }
        }, this._pointerCancelTouch = OO => {
          const KO = this._activeTouchIds.indexOf(OO);
          if (-1 === KO) return;
          this._elementToAttachTo.hasPointerCapture?.(OO) && this._elementToAttachTo.releasePointerCapture(OO), this._inputs[IO.Touch][KO][yK.LeftClick] = 0;
          const pO = rK.CreateDeviceEvent(IO.Touch, KO, yK.LeftClick, 0, this, this._elementToAttachTo, OO);
          this._onInputChanged(IO.Touch, KO, pO), this._activeTouchIds[KO] = -1, this._onDeviceDisconnected(IO.Touch, KO)
        }, this._pointerCancelEvent = OO => {
          if ("mouse" === OO.pointerType) {
            const OO = this._inputs[IO.Mouse][0];
            this._mouseId >= 0 && this._elementToAttachTo.hasPointerCapture?.(this._mouseId) && this._elementToAttachTo.releasePointerCapture(this._mouseId);
            for (let KO = yK.LeftClick; KO <= yK.BrowserForward; KO++)
              if (1 === OO[KO]) {
                OO[KO] = 0;
                const pO = rK.CreateDeviceEvent(IO.Mouse, 0, KO, 0, this, this._elementToAttachTo);
                this._onInputChanged(IO.Mouse, 0, pO)
              }
          } else this._pointerCancelTouch(OO.pointerId)
        }, this._pointerLeaveEvent = OO => {
          "pen" === OO.pointerType && this._pointerCancelTouch(OO.pointerId)
        }, this._wheelEventName = "onwheel" in document.createElement("div") ? "wheel" : void 0 !== document.onmousewheel ? "mousewheel" : "DOMMouseScroll";
        let OO = !1;
        const KO = function() {};
        try {
          const pO = Object.defineProperty({}, "passive", {
            get: function() {
              OO = !0
            }
          });
          this._elementToAttachTo.addEventListener("test", KO, pO), this._elementToAttachTo.removeEventListener("test", KO, pO)
        } catch (pO) {}
        this._pointerBlurEvent = () => {
          if (this.isDeviceAvailable(IO.Mouse)) {
            const OO = this._inputs[IO.Mouse][0];
            this._mouseId >= 0 && this._elementToAttachTo.hasPointerCapture?.(this._mouseId) && this._elementToAttachTo.releasePointerCapture(this._mouseId);
            for (let KO = yK.LeftClick; KO <= yK.BrowserForward; KO++)
              if (1 === OO[KO]) {
                OO[KO] = 0;
                const pO = rK.CreateDeviceEvent(IO.Mouse, 0, KO, 0, this, this._elementToAttachTo);
                this._onInputChanged(IO.Mouse, 0, pO)
              }
          }
          if (this.isDeviceAvailable(IO.Touch)) {
            const OO = this._inputs[IO.Touch];
            for (let KO = 0; KO < this._activeTouchIds.length; KO++) {
              const pO = this._activeTouchIds[KO];
              if (this._elementToAttachTo.hasPointerCapture?.(pO) && this._elementToAttachTo.releasePointerCapture(pO), -1 !== pO && 1 === OO[KO]?.[yK.LeftClick]) {
                OO[KO][yK.LeftClick] = 0;
                const XO = rK.CreateDeviceEvent(IO.Touch, KO, yK.LeftClick, 0, this, this._elementToAttachTo, pO);
                this._onInputChanged(IO.Touch, KO, XO), this._activeTouchIds[KO] = -1, this._onDeviceDisconnected(IO.Touch, KO)
              }
            }
          }
        }, this._pointerWheelEvent = OO => {
          const KO = IO.Mouse;
          this._inputs[KO] || (this._inputs[KO] = []), this._inputs[KO][0] || (this._pointerActive = !0, this._registerDevice(KO, 0, mK));
          const pO = this._inputs[KO][0];
          if (pO) {
            pO[yK.MouseWheelX] = OO.deltaX || 0, pO[yK.MouseWheelY] = OO.deltaY || OO.wheelDelta || 0, pO[yK.MouseWheelZ] = OO.deltaZ || 0;
            const XO = OO;
            void 0 === OO.pointerId && (OO.pointerId = this._mouseId), 0 !== pO[yK.MouseWheelX] && (XO.inputIndex = yK.MouseWheelX, this._onInputChanged(KO, 0, XO)), 0 !== pO[yK.MouseWheelY] && (XO.inputIndex = yK.MouseWheelY, this._onInputChanged(KO, 0, XO)), 0 !== pO[yK.MouseWheelZ] && (XO.inputIndex = yK.MouseWheelZ, this._onInputChanged(KO, 0, XO))
          }
        }, this._usingMacOs && this._isUsingChromium && (this._pointerMacOsChromeOutEvent = OO => {
          OO.buttons > 1 && this._pointerCancelEvent(OO)
        }, this._elementToAttachTo.addEventListener("lostpointercapture", this._pointerMacOsChromeOutEvent)), this._elementToAttachTo.addEventListener(this._eventPrefix + "move", this._pointerMoveEvent), this._elementToAttachTo.addEventListener(this._eventPrefix + "down", this._pointerDownEvent), this._elementToAttachTo.addEventListener(this._eventPrefix + "up", this._pointerUpEvent), this._elementToAttachTo.addEventListener(this._eventPrefix + "cancel", this._pointerCancelEvent), this._elementToAttachTo.addEventListener(this._eventPrefix + "DX", this._pointerLeaveEvent), this._elementToAttachTo.addEventListener("blur", this._pointerBlurEvent), this._elementToAttachTo.addEventListener(this._wheelEventName, this._pointerWheelEvent, !!OO && {
          passive: !1
        }), this._pointerInputClearObserver = this._engine.onEndFrameObservable.add((() => {
          if (this.isDeviceAvailable(IO.Mouse)) {
            const OO = this._inputs[IO.Mouse][0];
            OO[yK.MouseWheelX] = 0, OO[yK.MouseWheelY] = 0, OO[yK.MouseWheelZ] = 0
          }
        }))
      }
      _handleGamepadActions() {
        this._gamepadConnectedEvent = OO => {
          this._addGamePad(OO.gamepad)
        }, this._gamepadDisconnectedEvent = OO => {
          if (this._gamepads) {
            const KO = this._getGamepadDeviceType(OO.gamepad.id),
              pO = OO.gamepad.index;
            this._unregisterDevice(KO, pO), delete this._gamepads[pO]
          }
        }, window.addEventListener("gamepadconnected", this._gamepadConnectedEvent), window.addEventListener("gamepaddisconnected", this._gamepadDisconnectedEvent)
      }
      _updateDevice(OO, KO, pO) {
        const XO = navigator.getGamepads()[KO];
        if (XO && OO === this._gamepads[KO]) {
          const bK = this._inputs[OO][KO];
          pO >= XO.buttons.length ? bK[pO] = XO.axes[pO - XO.buttons.length].valueOf() : bK[pO] = XO.buttons[pO].value
        }
      }
      _getGamepadDeviceType(OO) {
        return -1 !== OO.indexOf("054c") ? -1 !== OO.indexOf("0ce6") ? IO.DualSense : IO.DualShock : -1 !== OO.indexOf("Xbox One") || -1 !== OO.search("Xbox 360") || -1 !== OO.search("xinput") || -1 !== OO.indexOf("045e") && -1 === OO.indexOf("Surface Dock") ? IO.Xbox : -1 !== OO.indexOf("057e") ? IO.Switch : IO.Generic
      }
      _getPointerType(OO) {
        let KO = IO.Mouse;
        return ("touch" === OO.pointerType || "pen" === OO.pointerType || OO.touches) && (KO = IO.Touch), KO
      }
    }
    class HO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        this.deviceType = KO, this.deviceSlot = pO, this.onInputChangedObservable = new lO.e, this._deviceInputSystem = OO
      }
      getInput(OO) {
        return this._deviceInputSystem.pollInput(this.deviceType, this.deviceSlot, OO)
      }
    }
    class RO {
      constructor(OO) {
        this._registeredManagers = new Array, this._refCount = 0, this.registerManager = OO => {
          for (let KO = 0; KO < this._devices.length; KO++) {
            const pO = this._devices[KO];
            for (const XO in pO) {
              const pO = +XO;
              OO._addDevice(new HO(this._deviceInputSystem, KO, pO))
            }
          }
          this._registeredManagers.push(OO)
        }, this.unregisterManager = OO => {
          const KO = this._registeredManagers.indexOf(OO);
          KO > -1 && this._registeredManagers.splice(KO, 1)
        };
        const KO = Object.keys(IO).length / 2;
        this._devices = new Array(KO);
        const pO = (OO, KO) => {
            this._devices[OO] || (this._devices[OO] = new Array), this._devices[OO][KO] || (this._devices[OO][KO] = KO);
            for (const pO of this._registeredManagers) {
              const XO = new HO(this._deviceInputSystem, OO, KO);
              pO._addDevice(XO)
            }
          },
          XO = (OO, KO) => {
            this._devices[OO]?.[KO] && delete this._devices[OO][KO];
            for (const pO of this._registeredManagers) pO._removeDevice(OO, KO)
          },
          bK = (OO, KO, pO) => {
            if (pO)
              for (const XO of this._registeredManagers) XO._onInputChanged(OO, KO, pO)
          };
        "undefined" !== typeof _native ? this._deviceInputSystem = new PO(pO, XO, bK) : this._deviceInputSystem = new sO(OO, pO, XO, bK)
      }
      dispose() {
        this._deviceInputSystem.dispose()
      }
    }
    class SO {
      getDeviceSource(OO, KO) {
        if (void 0 === KO) {
          if (void 0 === this._firstDevice[OO]) return null;
          KO = this._firstDevice[OO]
        }
        return this._devices[OO] && void 0 !== this._devices[OO][KO] ? this._devices[OO][KO] : null
      }
      getDeviceSources(OO) {
        return this._devices[OO] ? this._devices[OO].filter((OO => !!OO)) : []
      }
      constructor(OO) {
        const KO = Object.keys(IO).length / 2;
        this._devices = new Array(KO), this._firstDevice = new Array(KO), this._engine = OO, this._engine._deviceSourceManager || (this._engine._deviceSourceManager = new RO(OO)), this._engine._deviceSourceManager._refCount++, this.onDeviceConnectedObservable = new lO.e((OO => {
          for (const KO of this._devices)
            if (KO)
              for (const pO of KO) pO && this.onDeviceConnectedObservable.notifyObserver(OO, pO)
        })), this.onDeviceDisconnectedObservable = new lO.e, this._engine._deviceSourceManager.registerManager(this), this._onDisposeObserver = OO.cpO.add((() => {
          this.dispose()
        }))
      }
      dispose() {
        this.onDeviceConnectedObservable.clear(), this.onDeviceDisconnectedObservable.clear(), this._engine._deviceSourceManager && (this._engine._deviceSourceManager.unregisterManager(this), --this._engine._deviceSourceManager._refCount < 1 && (this._engine._deviceSourceManager.dispose(), delete this._engine._deviceSourceManager)), this._engine.cpO.remove(this._onDisposeObserver)
      }
      _addDevice(OO) {
        this._devices[OO.deviceType] || (this._devices[OO.deviceType] = []), this._devices[OO.deviceType][OO.deviceSlot] || (this._devices[OO.deviceType][OO.deviceSlot] = OO, this._updateFirstDevices(OO.deviceType)), this.onDeviceConnectedObservable.notifyObservers(OO)
      }
      _removeDevice(OO, KO) {
        const pO = this._devices[OO]?.[KO];
        this.onDeviceDisconnectedObservable.notifyObservers(pO), this._devices[OO]?.[KO] && delete this._devices[OO][KO], this._updateFirstDevices(OO)
      }
      _onInputChanged(OO, KO, pO) {
        this._devices[OO]?.[KO]?.onInputChangedObservable.notifyObservers(pO)
      }
      _updateFirstDevices(OO) {
        switch (OO) {
          case IO.Keyboard:
          case IO.Mouse:
            this._firstDevice[OO] = 0;
            break;
          case IO.Touch:
          case IO.DualSense:
          case IO.DualShock:
          case IO.Xbox:
          case IO.Switch:
          case IO.Generic: {
            delete this._firstDevice[OO];
            const KO = this._devices[OO];
            if (KO)
              for (let pO = 0; pO < KO.length; pO++)
                if (KO[pO]) {
                  this._firstDevice[OO] = pO;
                  break
                } break
          }
        }
      }
    }
    var JO = pO(38269);
    class cK {
      constructor() {
        this._singleClick = !1, this._doubleClick = !1, this._hasSwiped = !1, this._ignore = !1
      }
      get singleClick() {
        return this._singleClick
      }
      get nC() {
        return this._doubleClick
      }
      get hasSwiped() {
        return this._hasSwiped
      }
      get ignore() {
        return this._ignore
      }
      set singleClick(OO) {
        this._singleClick = OO
      }
      set nC(OO) {
        this._doubleClick = OO
      }
      set hasSwiped(OO) {
        this._hasSwiped = OO
      }
      set ignore(OO) {
        this._ignore = OO
      }
    }
    class BO {
      constructor(OO) {
        this._alreadyAttached = !1, this._meshPickProceed = !1, this._currentPickResult = null, this._previousPickResult = null, this._activePointerIds = new Array, this._activePointerIdsCount = 0, this._doubleClickOccured = !1, this._isSwiping = !1, this._swipeButtonPressed = -1, this._skipPointerTap = !1, this._isMultiTouchGesture = !1, this._pointerX = 0, this._pointerY = 0, this._startingPointerPosition = new DO.m(0, 0), this._previousStartingPointerPosition = new DO.m(0, 0), this._startingPointerTime = 0, this._previousStartingPointerTime = 0, this._pointerCaptures = {}, this._meshUnderPointerId = {}, this._movePointerInfo = null, this._latestPointerMoveEvents = new Map, this._cameraObserverCount = 0, this._delayedClicks = [null, null, null, null, null], this._deviceSourceManager = null, this._scene = OO || fO.c.LastCreatedScene, this._scene
      }
      get meshUnderPointer() {
        return this._movePointerInfo && (this._movePointerInfo._generatePickInfo(), this._movePointerInfo = null), this._pointerOverMesh
      }
      getMeshUnderPointerByPointerId(OO) {
        return this._meshUnderPointerId[OO] || null
      }
      get unTranslatedPointer() {
        return new DO.m(this._unTranslatedPointerX, this._unTranslatedPointerY)
      }
      get pointerX() {
        return this._pointerX
      }
      set pointerX(OO) {
        this._pointerX = OO
      }
      get pointerY() {
        return this._pointerY
      }
      set pointerY(OO) {
        this._pointerY = OO
      }
      _updatePointerPosition(OO) {
        const KO = this._scene.qb().getInputElementClientRect();
        KO && (this._pointerX = OO.clientX - KO.left, this._pointerY = OO.clientY - KO.top, this._unTranslatedPointerX = this._pointerX, this._unTranslatedPointerY = this._pointerY)
      }
      _processPointerMove(OO, KO) {
        const pO = this._scene,
          XO = pO.qb(),
          bK = XO.getInputElement();
        bK && (bK.tabIndex = XO.canvasTabIndex, pO.doNotHandleCursors || (bK.style.cursor = pO.defaultCursor)), this._setCursorAndPointerOverMesh(OO, KO, pO);
        for (const vK of pO._pointerMoveStage) {
          OO = OO || this._pickMove(KO);
          const pO = !!OO?.pickedMesh;
          OO = vK.action(this._unTranslatedPointerX, this._unTranslatedPointerY, OO, pO, bK)
        }
        const eO = KO.inputIndex >= yK.MouseWheelX && KO.inputIndex <= yK.MouseWheelZ ? TO.c.POINTERWHEEL : TO.c.POINTERMOVE;
        let lO;
        pO.onPointerMove && (OO = OO || this._pickMove(KO), pO.onPointerMove(KO, OO, eO)), OO ? (lO = new TO.e(eO, KO, OO), this._setRayOnPointerInfo(OO, KO)) : (lO = new TO.e(eO, KO, null, this), this._movePointerInfo = lO), pO.onPointerObservable.hasObservers() && pO.onPointerObservable.notifyObservers(lO, eO)
      }
      _setRayOnPointerInfo(OO, KO) {
        const pO = this._scene;
        OO && JO.b._IsPickingAvailable && (OO.ray || (OO.ray = pO.createPickingRay(KO.offsetX, KO.offsetY, DO.c.Identity(), pO.activeCamera)))
      }
      _addCameraPointerObserver(OO, KO) {
        return this._cameraObserverCount++, this._scene.onPointerObservable.add(OO, KO)
      }
      _removeCameraPointerObserver(OO) {
        return this._cameraObserverCount--, this._scene.onPointerObservable.remove(OO)
      }
      _checkForPicking() {
        return !!(this._scene.onPointerObservable.observers.length > this._cameraObserverCount || this._scene.onPointerPick)
      }
      _checkPrePointerObservable(OO, KO, pO) {
        const XO = this._scene,
          bK = new TO.d(pO, KO, this._unTranslatedPointerX, this._unTranslatedPointerY);
        return OO && (bK.originalPickingInfo = OO, bK.ray = OO.ray, "xr-near" === KO.pointerType && OO.originMesh && (bK.nearInteractionPickingInfo = OO)), XO.onPrePointerObservable.notifyObservers(bK, pO), !!bK.skipOnPointerObservable
      }
      _pickMove(OO) {
        const KO = this._scene,
          pO = KO.Kp(this._unTranslatedPointerX, this._unTranslatedPointerY, KO.pointerMovePredicate, KO.pointerMoveFastCheck, KO.cameraToUseForPointers, KO.pointerMoveTrianglePredicate);
        return this._setCursorAndPointerOverMesh(pO, OO, KO), pO
      }
      _updateMeshUnderPointer() {
        const OO = this._scene;
        if (!OO.constantlyUpdateMeshUnderPointer || 0 === this._latestPointerMoveEvents.size || OO.skipPointerMovePicking || !OO.cameraToUseForPointers && !OO.activeCamera) return;
        this._ensurePointerMovePredicate();
        const KO = this._pointerX,
          pO = this._pointerY,
          XO = this._unTranslatedPointerX,
          bK = this._unTranslatedPointerY;
        for (const eO of this._latestPointerMoveEvents.values()) this._pointerX = eO.pointerX, this._pointerY = eO.pointerY, this._unTranslatedPointerX = eO.unTranslatedPointerX, this._unTranslatedPointerY = eO.unTranslatedPointerY, this._pickMove(eO.event);
        this._pointerX = KO, this._pointerY = pO, this._unTranslatedPointerX = XO, this._unTranslatedPointerY = bK
      }
      _ensurePointerMovePredicate() {
        const OO = this._scene;
        OO.pointerMovePredicate || (OO.pointerMovePredicate = KO => (KO._isPointerMovePickable ?? KO.De) && KO.isVisible && KO.isReady() && KO.isEnabled() && (KO.enablePointerMoveEvents || OO.constantlyUpdateMeshUnderPointer || null !== KO._getActionManagerForTrigger()) && (!OO.cameraToUseForPointers || 0 !== (OO.cameraToUseForPointers.layerMask & KO.layerMask)))
      }
      _setCursorAndPointerOverMesh(OO, KO, pO) {
        const XO = pO.qb().getInputElement();
        if (OO?.pickedMesh) {
          if (this.setPointerOverMesh(OO.pickedMesh, KO.pointerId, OO, KO), !pO.doNotHandleCursors && XO && this._pointerOverMesh) {
            const OO = this._pointerOverMesh._getActionManagerForTrigger();
            OO && OO.hasPointerTriggers && (XO.style.cursor = OO.hoverCursor || pO.hoverCursor)
          }
        } else this.setPointerOverMesh(null, KO.pointerId, OO, KO)
      }
      simulatePointerMove(OO, KO) {
        const pO = new PointerEvent("pointermove", KO);
        pO.inputIndex = yK.Move, this._checkPrePointerObservable(OO, pO, TO.c.POINTERMOVE) || this._processPointerMove(OO, pO)
      }
      simulatePointerDown(OO, KO) {
        const pO = new PointerEvent("pointerdown", KO);
        pO.inputIndex = pO.button + 2, this._checkPrePointerObservable(OO, pO, TO.c.POINTERDOWN) || this._processPointerDown(OO, pO)
      }
      _processPointerDown(OO, KO) {
        const pO = this._scene;
        if (OO?.pickedMesh) {
          this._pickedDownMesh = OO.pickedMesh;
          const XO = OO.pickedMesh._getActionManagerForTrigger();
          if (XO) {
            if (XO.hasPickTriggers) switch (XO.processTrigger(5, new FO(OO.pickedMesh, pO.pointerX, pO.pointerY, OO.pickedMesh, KO, OO)), KO.button) {
              case 0:
                XO.processTrigger(2, new FO(OO.pickedMesh, pO.pointerX, pO.pointerY, OO.pickedMesh, KO, OO));
                break;
              case 1:
                XO.processTrigger(4, new FO(OO.pickedMesh, pO.pointerX, pO.pointerY, OO.pickedMesh, KO, OO));
                break;
              case 2:
                XO.processTrigger(3, new FO(OO.pickedMesh, pO.pointerX, pO.pointerY, OO.pickedMesh, KO, OO))
            }
            XO.hasSpecificTrigger(8) && window.setTimeout((() => {
              const OO = pO.Kp(this._unTranslatedPointerX, this._unTranslatedPointerY, (OO => OO.De && OO.isVisible && OO.isReady() && OO.actionManager && OO.actionManager.hasSpecificTrigger(8) && OO === this._pickedDownMesh), !1, pO.cameraToUseForPointers);
              OO?.pickedMesh && XO && 0 !== this._activePointerIdsCount && Date.now() - this._startingPointerTime > BO.LongPressDelay && !this._isPointerSwiping() && (this._startingPointerTime = 0, XO.processTrigger(8, FO.CreateNew(OO.pickedMesh, KO)))
            }), BO.LongPressDelay)
          }
        } else
          for (const eO of pO._pointerDownStage) OO = eO.action(this._unTranslatedPointerX, this._unTranslatedPointerY, OO, KO, !1);
        let XO;
        const bK = TO.c.POINTERDOWN;
        OO ? (pO.onPointerDown && pO.onPointerDown(KO, OO, bK), XO = new TO.e(bK, KO, OO), this._setRayOnPointerInfo(OO, KO)) : XO = new TO.e(bK, KO, null, this), pO.onPointerObservable.hasObservers() && pO.onPointerObservable.notifyObservers(XO, bK)
      }
      _isPointerSwiping() {
        return this._isSwiping
      }
      simulatePointerUp(OO, KO, pO) {
        const XO = new PointerEvent("pointerup", KO);
        XO.inputIndex = yK.Move;
        const bK = new cK;
        pO ? bK.nC = !0 : bK.singleClick = !0, this._checkPrePointerObservable(OO, XO, TO.c.POINTERUP) || this._processPointerUp(OO, XO, bK)
      }
      _processPointerUp(OO, KO, pO) {
        const XO = this._scene;
        if (OO?.pickedMesh) {
          if (this._pickedUpMesh = OO.pickedMesh, this._pickedDownMesh === this._pickedUpMesh && (XO.onPointerPick && XO.onPointerPick(KO, OO), pO.singleClick && !pO.ignore && XO.onPointerObservable.observers.length > this._cameraObserverCount)) {
            const pO = TO.c.POINTERPICK,
              bK = new TO.e(pO, KO, OO);
            this._setRayOnPointerInfo(OO, KO), XO.onPointerObservable.notifyObservers(bK, pO)
          }
          const bK = OO.pickedMesh._getActionManagerForTrigger();
          if (bK && !pO.ignore) {
            bK.processTrigger(7, FO.CreateNew(OO.pickedMesh, KO, OO)), !pO.hasSwiped && pO.singleClick && bK.processTrigger(1, FO.CreateNew(OO.pickedMesh, KO, OO));
            const XO = OO.pickedMesh._getActionManagerForTrigger(6);
            pO.nC && XO && XO.processTrigger(6, FO.CreateNew(OO.pickedMesh, KO, OO))
          }
        } else if (!pO.ignore)
          for (const bK of XO._pointerUpStage) OO = bK.action(this._unTranslatedPointerX, this._unTranslatedPointerY, OO, KO, pO.nC);
        if (this._pickedDownMesh && this._pickedDownMesh !== this._pickedUpMesh) {
          const OO = this._pickedDownMesh._getActionManagerForTrigger(16);
          OO && OO.processTrigger(16, FO.CreateNew(this._pickedDownMesh, KO))
        }
        if (!pO.ignore) {
          const bK = new TO.e(TO.c.POINTERUP, KO, OO);
          if (this._setRayOnPointerInfo(OO, KO), XO.onPointerObservable.notifyObservers(bK, TO.c.POINTERUP), XO.onPointerUp && XO.onPointerUp(KO, OO, TO.c.POINTERUP), !pO.hasSwiped && !this._skipPointerTap && !this._isMultiTouchGesture) {
            let bK = 0;
            if (pO.singleClick ? bK = TO.c.POINTERTAP : pO.nC && (bK = TO.c.POINTERDOUBLETAP), bK) {
              const pO = new TO.e(bK, KO, OO);
              XO.onPointerObservable.hasObservers() && XO.onPointerObservable.hasSpecificMask(bK) && XO.onPointerObservable.notifyObservers(pO, bK)
            }
          }
        }
      }
      isPointerCaptured() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return this._pointerCaptures[OO]
      }
      attachControl() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
          KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        const bK = this._scene,
          eO = bK.qb();
        XO || (XO = eO.getInputElement()), this._alreadyAttached && this.detachControl(), XO && (this._alreadyAttachedTo = XO), this._deviceSourceManager = new SO(eO), this._initActionManager = OO => {
          if (!this._meshPickProceed) {
            const KO = bK.skipPointerUpPicking || 0 === bK._registeredActions && !this._checkForPicking() && !bK.onPointerUp ? null : bK.Kp(this._unTranslatedPointerX, this._unTranslatedPointerY, bK.pointerUpPredicate, bK.pointerUpFastCheck, bK.cameraToUseForPointers, bK.pointerUpTrianglePredicate);
            this._currentPickResult = KO, KO && (OO = KO.hit && KO.pickedMesh ? KO.pickedMesh._getActionManagerForTrigger() : null), this._meshPickProceed = !0
          }
          return OO
        }, this._delayedSimpleClick = (OO, KO, pO) => {
          if ((Date.now() - this._previousStartingPointerTime > BO.DoubleClickDelay && !this._doubleClickOccured || OO !== this._previousButtonPressed) && (this._doubleClickOccured = !1, KO.singleClick = !0, KO.ignore = !1, this._delayedClicks[OO])) {
            const KO = this._delayedClicks[OO].evt,
              pO = TO.c.POINTERTAP,
              XO = new TO.e(pO, KO, this._currentPickResult);
            bK.onPointerObservable.hasObservers() && bK.onPointerObservable.hasSpecificMask(pO) && bK.onPointerObservable.notifyObservers(XO, pO), this._delayedClicks[OO] = null
          }
        }, this._initClickEvent = (OO, KO, pO, XO) => {
          const bK = new cK;
          this._currentPickResult = null;
          let eO = null,
            lO = OO.hasSpecificMask(TO.c.POINTERPICK) || KO.hasSpecificMask(TO.c.POINTERPICK) || OO.hasSpecificMask(TO.c.POINTERTAP) || KO.hasSpecificMask(TO.c.POINTERTAP) || OO.hasSpecificMask(TO.c.POINTERDOUBLETAP) || KO.hasSpecificMask(TO.c.POINTERDOUBLETAP);
          !lO && NO && (eO = this._initActionManager(eO, bK), eO && (lO = eO.hasPickTriggers));
          let vK = !1;
          if (lO = lO && !this._isMultiTouchGesture, lO) {
            const lO = pO.button;
            if (bK.hasSwiped = this._isPointerSwiping(), !bK.hasSwiped) {
              let CO = !BO.ExclusiveDoubleClickMode;
              if (CO || (CO = !OO.hasSpecificMask(TO.c.POINTERDOUBLETAP) && !KO.hasSpecificMask(TO.c.POINTERDOUBLETAP), CO && !NO.HasSpecificTrigger(6) && (eO = this._initActionManager(eO, bK), eO && (CO = !eO.hasSpecificTrigger(6)))), CO)(Date.now() - this._previousStartingPointerTime > BO.DoubleClickDelay || lO !== this._previousButtonPressed) && (bK.singleClick = !0, XO(bK, this._currentPickResult), vK = !0);
              else {
                const OO = {
                  evt: pO,
                  clickInfo: bK,
                  timeoutId: window.setTimeout(this._delayedSimpleClick.bind(this, lO, bK, XO), BO.DoubleClickDelay)
                };
                this._delayedClicks[lO] = OO
              }
              let hO = OO.hasSpecificMask(TO.c.POINTERDOUBLETAP) || KO.hasSpecificMask(TO.c.POINTERDOUBLETAP);
              !hO && NO.HasSpecificTrigger(6) && (eO = this._initActionManager(eO, bK), eO && (hO = eO.hasSpecificTrigger(6))), hO && (lO === this._previousButtonPressed && Date.now() - this._previousStartingPointerTime < BO.DoubleClickDelay && !this._doubleClickOccured ? (bK.hasSwiped || this._isPointerSwiping() ? (this._doubleClickOccured = !1, this._previousStartingPointerTime = this._startingPointerTime, this._previousStartingPointerPosition.x = this._startingPointerPosition.x, this._previousStartingPointerPosition.y = this._startingPointerPosition.y, this._previousButtonPressed = lO, BO.ExclusiveDoubleClickMode ? (this._delayedClicks[lO] && (clearTimeout(this._delayedClicks[lO]?.timeoutId), this._delayedClicks[lO] = null), XO(bK, this._previousPickResult)) : XO(bK, this._currentPickResult)) : (this._previousStartingPointerTime = 0, this._doubleClickOccured = !0, bK.nC = !0, bK.ignore = !1, BO.ExclusiveDoubleClickMode && this._delayedClicks[lO] && (clearTimeout(this._delayedClicks[lO]?.timeoutId), this._delayedClicks[lO] = null), XO(bK, this._currentPickResult)), vK = !0) : (this._doubleClickOccured = !1, this._previousStartingPointerTime = this._startingPointerTime, this._previousStartingPointerPosition.x = this._startingPointerPosition.x, this._previousStartingPointerPosition.y = this._startingPointerPosition.y, this._previousButtonPressed = lO))
            }
          }
          vK || XO(bK, this._currentPickResult)
        }, this._onPointerMove = OO => {
          if (this._updatePointerPosition(OO), this._latestPointerMoveEvents.set(OO.pointerId, {
              event: OO,
              pointerX: this._pointerX,
              pointerY: this._pointerY,
              unTranslatedPointerX: this._unTranslatedPointerX,
              unTranslatedPointerY: this._unTranslatedPointerY
            }), this._isSwiping || -1 === this._swipeButtonPressed || (this._isSwiping = Math.abs(this._startingPointerPosition.x - this._pointerX) > BO.DragMovementThreshold || Math.abs(this._startingPointerPosition.y - this._pointerY) > BO.DragMovementThreshold), eO.isPointerLock && eO._verifyPointerLock(), this._checkPrePointerObservable(null, OO, OO.inputIndex >= yK.MouseWheelX && OO.inputIndex <= yK.MouseWheelZ ? TO.c.POINTERWHEEL : TO.c.POINTERMOVE)) return;
          if (!bK.cameraToUseForPointers && !bK.activeCamera) return;
          if (bK.skipPointerMovePicking) return void this._processPointerMove(new oO.c, OO);
          this._ensurePointerMovePredicate();
          const KO = bK._registeredActions > 0 || bK.constantlyUpdateMeshUnderPointer ? this._pickMove(OO) : null;
          this._processPointerMove(KO, OO)
        }, this._onPointerDown = OO => {
          const KO = this._activePointerIds.indexOf(-1);
          if (-1 === KO ? this._activePointerIds.push(OO.pointerId) : this._activePointerIds[KO] = OO.pointerId, this._activePointerIdsCount++, this._pickedDownMesh = null, this._meshPickProceed = !1, BO.ExclusiveDoubleClickMode)
            for (let XO = 0; XO < this._delayedClicks.length; XO++)
              if (this._delayedClicks[XO])
                if (OO.button === XO) clearTimeout(this._delayedClicks[XO]?.timeoutId);
                else {
                  const OO = this._delayedClicks[XO].clickInfo;
                  this._doubleClickOccured = !1, OO.singleClick = !0, OO.ignore = !1;
                  const KO = this._delayedClicks[XO].evt,
                    pO = TO.c.POINTERTAP,
                    eO = new TO.e(pO, KO, this._currentPickResult);
                  bK.onPointerObservable.hasObservers() && bK.onPointerObservable.hasSpecificMask(pO) && bK.onPointerObservable.notifyObservers(eO, pO), this._delayedClicks[XO] = null
                } if (this._updatePointerPosition(OO), -1 === this._swipeButtonPressed && (this._swipeButtonPressed = OO.button), bK.preventDefaultOnPointerDown && XO && (OO.preventDefault(), XO.focus()), this._startingPointerPosition.x = this._pointerX, this._startingPointerPosition.y = this._pointerY, this._startingPointerTime = Date.now(), this._checkPrePointerObservable(null, OO, TO.c.POINTERDOWN)) return;
          if (!bK.cameraToUseForPointers && !bK.activeCamera) return;
          let pO;
          this._pointerCaptures[OO.pointerId] = !0, bK.pointerDownPredicate || (bK.pointerDownPredicate = OO => OO.De && OO.isVisible && OO.isReady() && OO.isEnabled() && (!bK.cameraToUseForPointers || 0 !== (bK.cameraToUseForPointers.layerMask & OO.layerMask))), this._pickedDownMesh = null, pO = bK.skipPointerDownPicking || 0 === bK._registeredActions && !this._checkForPicking() && !bK.onPointerDown ? new oO.c : bK.Kp(this._unTranslatedPointerX, this._unTranslatedPointerY, bK.pointerDownPredicate, bK.pointerDownFastCheck, bK.cameraToUseForPointers, bK.pointerDownTrianglePredicate), this._processPointerDown(pO, OO)
        }, this._onPointerUp = OO => {
          const KO = this._activePointerIds.indexOf(OO.pointerId); - 1 !== KO && (this._activePointerIds[KO] = -1, this._activePointerIdsCount--, "touch" === OO.pointerType && this._latestPointerMoveEvents.delete(OO.pointerId), this._pickedUpMesh = null, this._meshPickProceed = !1, this._updatePointerPosition(OO), bK.preventDefaultOnPointerUp && XO && (OO.preventDefault(), XO.focus()), this._initClickEvent(bK.onPrePointerObservable, bK.onPointerObservable, OO, ((KO, pO) => {
            if (bK.onPrePointerObservable.hasObservers() && (this._skipPointerTap = !1, !KO.ignore)) {
              if (this._checkPrePointerObservable(null, OO, TO.c.POINTERUP)) return this._swipeButtonPressed === OO.button && (this._isSwiping = !1, this._swipeButtonPressed = -1), void(0 === OO.buttons && (this._pointerCaptures[OO.pointerId] = !1));
              KO.hasSwiped || (KO.singleClick && bK.onPrePointerObservable.hasSpecificMask(TO.c.POINTERTAP) && this._checkPrePointerObservable(null, OO, TO.c.POINTERTAP) && (this._skipPointerTap = !0), KO.nC && bK.onPrePointerObservable.hasSpecificMask(TO.c.POINTERDOUBLETAP) && this._checkPrePointerObservable(null, OO, TO.c.POINTERDOUBLETAP) && (this._skipPointerTap = !0))
            }
            this._pointerCaptures[OO.pointerId] ? (0 === OO.buttons && (this._pointerCaptures[OO.pointerId] = !1), (bK.cameraToUseForPointers || bK.activeCamera) && (bK.pointerUpPredicate || (bK.pointerUpPredicate = OO => OO.De && OO.isVisible && OO.isReady() && OO.isEnabled() && (!bK.cameraToUseForPointers || 0 !== (bK.cameraToUseForPointers.layerMask & OO.layerMask))), !this._meshPickProceed && (NO && NO.HasTriggers || this._checkForPicking() || bK.onPointerUp) && this._initActionManager(null, KO), pO || (pO = this._currentPickResult), this._processPointerUp(pO, OO, KO), this._previousPickResult = this._currentPickResult, this._swipeButtonPressed === OO.button && (this._isSwiping = !1, this._swipeButtonPressed = -1))) : this._swipeButtonPressed === OO.button && (this._isSwiping = !1, this._swipeButtonPressed = -1)
          })))
        }, this._onKeyDown = OO => {
          const KO = wO.d.KEYDOWN;
          if (bK.onPreKeyboardObservable.hasObservers()) {
            const pO = new wO.f(KO, OO);
            if (bK.onPreKeyboardObservable.notifyObservers(pO, KO), pO.skipOnKeyboardObservable) return
          }
          if (bK.onKeyboardObservable.hasObservers()) {
            const pO = new wO.g(KO, OO);
            bK.onKeyboardObservable.notifyObservers(pO, KO)
          }
          bK.actionManager && bK.actionManager.processTrigger(14, FO.CreateNewFromScene(bK, OO))
        }, this._onKeyUp = OO => {
          const KO = wO.d.KEYUP;
          if (bK.onPreKeyboardObservable.hasObservers()) {
            const pO = new wO.f(KO, OO);
            if (bK.onPreKeyboardObservable.notifyObservers(pO, KO), pO.skipOnKeyboardObservable) return
          }
          if (bK.onKeyboardObservable.hasObservers()) {
            const pO = new wO.g(KO, OO);
            bK.onKeyboardObservable.notifyObservers(pO, KO)
          }
          bK.actionManager && bK.actionManager.processTrigger(15, FO.CreateNewFromScene(bK, OO))
        }, this._deviceSourceManager.onDeviceConnectedObservable.add((XO => {
          XO.deviceType === IO.Mouse ? XO.onInputChangedObservable.add((bK => {
            this._originMouseEvent = bK, bK.inputIndex === yK.LeftClick || bK.inputIndex === yK.MiddleClick || bK.inputIndex === yK.RightClick || bK.inputIndex === yK.BrowserBack || bK.inputIndex === yK.BrowserForward ? KO && 1 === XO.getInput(bK.inputIndex) ? this._onPointerDown(bK) : OO && 0 === XO.getInput(bK.inputIndex) && this._onPointerUp(bK) : pO && (bK.inputIndex === yK.Move ? this._onPointerMove(bK) : bK.inputIndex !== yK.MouseWheelX && bK.inputIndex !== yK.MouseWheelY && bK.inputIndex !== yK.MouseWheelZ || this._onPointerMove(bK))
          })) : XO.deviceType === IO.Touch ? XO.onInputChangedObservable.add((bK => {
            bK.inputIndex === yK.LeftClick && (KO && 1 === XO.getInput(bK.inputIndex) ? (this._onPointerDown(bK), this._activePointerIdsCount > 1 && (this._isMultiTouchGesture = !0)) : OO && 0 === XO.getInput(bK.inputIndex) && (this._onPointerUp(bK), 0 === this._activePointerIdsCount && (this._isMultiTouchGesture = !1))), pO && bK.inputIndex === yK.Move && this._onPointerMove(bK)
          })) : XO.deviceType === IO.Keyboard && XO.onInputChangedObservable.add((OO => {
            "keydown" === OO.type ? this._onKeyDown(OO) : "keyup" === OO.type && this._onKeyUp(OO)
          }))
        })), this._alreadyAttached = !0
      }
      detachControl() {
        this._alreadyAttached && (this._deviceSourceManager.dispose(), this._deviceSourceManager = null, this._alreadyAttachedTo && !this._scene.doNotHandleCursors && (this._alreadyAttachedTo.style.cursor = this._scene.defaultCursor), this._alreadyAttached = !1, this._alreadyAttachedTo = null, this._latestPointerMoveEvents.clear())
      }
      setPointerOverMesh(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        if (this._meshUnderPointerId[KO] === OO && (!OO || !OO._internalAbstractMeshDataInfo._pointerOverDisableMeshTesting)) return;
        const bK = this._meshUnderPointerId[KO];
        let eO;
        bK && (eO = bK._getActionManagerForTrigger(10), eO && eO.processTrigger(10, new FO(bK, this._pointerX, this._pointerY, OO, XO, {
          pointerId: KO
        }))), OO ? (this._meshUnderPointerId[KO] = OO, this._pointerOverMesh = OO, eO = OO._getActionManagerForTrigger(9), eO && eO.processTrigger(9, new FO(OO, this._pointerX, this._pointerY, OO, XO, {
          pointerId: KO,
          pickResult: pO
        }))) : (delete this._meshUnderPointerId[KO], this._pointerOverMesh = null), this._scene.onMeshUnderPointerUpdatedObservable.hasObservers() && this._scene.onMeshUnderPointerUpdatedObservable.notifyObservers({
          mesh: OO,
          pointerId: KO
        })
      }
      getPointerOverMesh() {
        return this.meshUnderPointer
      }
      _invalidateMesh(OO) {
        this._pointerOverMesh === OO && (this._pointerOverMesh = null), this._pickedDownMesh === OO && (this._pickedDownMesh = null), this._pickedUpMesh === OO && (this._pickedUpMesh = null);
        for (const KO in this._meshUnderPointerId) this._meshUnderPointerId[KO] === OO && delete this._meshUnderPointerId[KO]
      }
    }
    BO.DragMovementThreshold = 10, BO.LongPressDelay = 500, BO.DoubleClickDelay = 300, BO.ExclusiveDoubleClickMode = !1;
    var ZO = pO(38011),
      GO = pO(35688),
      qK = pO(36142);
    class xK {
      static get UniqueId() {
        const OO = this._UniqueIdCounter;
        return this._UniqueIdCounter++, OO
      }
    }
    xK._UniqueIdCounter = 1;
    var nO = pO(38104),
      WO = pO(38275),
      tK = pO(35641);
    class kK {
      constructor() {
        this.pointerDownFastCheck = !1, this.pointerUpFastCheck = !1, this.pointerMoveFastCheck = !1, this.skipPointerMovePicking = !1, this.skipPointerDownPicking = !1, this.skipPointerUpPicking = !1
      }
    }
    var UO, OK, KK, pK, XK, bp, eK, lK, vp, CK, hK, DK, MK, ap, oK, FK, VK, LK, QK, zp, AK, fK, dK, TK, NK, IK, yp, gp, uK, EK, jp, YK, wK, ip, rp, PK, mp, sK, HK, RK, SK, JK, cp, BK, ZK, GK, qp, xp, nK, WK, tp, kp, UK, Op = pO(37061),
      Kp = pO(35676);
    const pp = new DO.s,
      Xp = new DO.s;
    var bX;
    ! function(OO) {
      OO[OO.BackwardCompatible = 0] = "BackwardCompatible", OO[OO.Intermediate = 1] = "Intermediate", OO[OO.Aggressive = 2] = "Aggressive"
    }(bX || (bX = {}));
    class ep {
      static DefaultMaterialFactory(OO) {
        throw (0, dO.j)("StandardMaterial")
      }
      static CollisionCoordinatorFactory() {
        throw (0, dO.j)("DefaultCollisionCoordinator")
      }
      get clearColor() {
        return this._clearColor
      }
      set clearColor(OO) {
        OO !== this._clearColor && (this._clearColor = OO, this.onClearColorChangedObservable.notifyObservers(this._clearColor))
      }
      get imageProcessingConfiguration() {
        return this._imageProcessingConfiguration
      }
      get performancePriority() {
        return this._performancePriority
      }
      set performancePriority(OO) {
        if (OO !== this._performancePriority) {
          switch (this._performancePriority = OO, OO) {
            case 0:
              this.skipFrustumClipping = !1, this._renderingManager.maintainStateBetweenFrames = !1, this.skipPointerMovePicking = !1, this.autoClear = !0;
              break;
            case 1:
              this.skipFrustumClipping = !1, this._renderingManager.maintainStateBetweenFrames = !1, this.skipPointerMovePicking = !0, this.autoClear = !1;
              break;
            case 2:
              this.skipFrustumClipping = !0, this._renderingManager.maintainStateBetweenFrames = !0, this.skipPointerMovePicking = !0, this.autoClear = !1
          }
          this.onScenePerformancePriorityChangedObservable.notifyObservers(OO)
        }
      }
      set forceWireframe(OO) {
        this._forceWireframe !== OO && (this._forceWireframe = OO, this.markAllMaterialsAsDirty(16))
      }
      get forceWireframe() {
        return this._forceWireframe
      }
      set skipFrustumClipping(OO) {
        this._skipFrustumClipping !== OO && (this._skipFrustumClipping = OO)
      }
      get skipFrustumClipping() {
        return this._skipFrustumClipping
      }
      set forcePointsCloud(OO) {
        this._forcePointsCloud !== OO && (this._forcePointsCloud = OO, this.markAllMaterialsAsDirty(16))
      }
      get forcePointsCloud() {
        return this._forcePointsCloud
      }
      get environmentTexture() {
        return this._environmentTexture
      }
      set environmentTexture(OO) {
        this._environmentTexture !== OO && (this._environmentTexture = OO, this.onEnvironmentTextureChangedObservable.notifyObservers(OO), this.markAllMaterialsAsDirty(1))
      }
      getNodes() {
        let OO = [];
        OO = OO.concat(this.meshes), OO = OO.concat(this.lights), OO = OO.concat(this.cameras), OO = OO.concat(this.transformNodes);
        for (const KO of this.skeletons) OO = OO.concat(KO.bones);
        return OO
      }
      get animationPropertiesOverride() {
        return this._animationPropertiesOverride
      }
      set animationPropertiesOverride(OO) {
        this._animationPropertiesOverride = OO
      }
      set onDispose(OO) {
        this._onDisposeObserver && this.cpO.remove(this._onDisposeObserver), this._onDisposeObserver = this.cpO.add(OO)
      }
      set beforeRender(OO) {
        this._onBeforeRenderObserver && this.onBeforeRenderObservable.remove(this._onBeforeRenderObserver), OO && (this._onBeforeRenderObserver = this.onBeforeRenderObservable.add(OO))
      }
      set afterRender(OO) {
        this._onAfterRenderObserver && this.onAfterRenderObservable.remove(this._onAfterRenderObserver), OO && (this._onAfterRenderObserver = this.onAfterRenderObservable.add(OO))
      }
      set beforeCameraRender(OO) {
        this._onBeforeCameraRenderObserver && this.onBeforeCameraRenderObservable.remove(this._onBeforeCameraRenderObserver), this._onBeforeCameraRenderObserver = this.onBeforeCameraRenderObservable.add(OO)
      }
      set afterCameraRender(OO) {
        this._onAfterCameraRenderObserver && this.onAfterCameraRenderObservable.remove(this._onAfterCameraRenderObserver), this._onAfterCameraRenderObserver = this.onAfterCameraRenderObservable.add(OO)
      }
      get pointerDownPredicate() {
        return this._pointerPickingConfiguration.pointerDownPredicate
      }
      set pointerDownPredicate(OO) {
        this._pointerPickingConfiguration.pointerDownPredicate = OO
      }
      get pointerUpPredicate() {
        return this._pointerPickingConfiguration.pointerUpPredicate
      }
      set pointerUpPredicate(OO) {
        this._pointerPickingConfiguration.pointerUpPredicate = OO
      }
      get pointerMovePredicate() {
        return this._pointerPickingConfiguration.pointerMovePredicate
      }
      set pointerMovePredicate(OO) {
        this._pointerPickingConfiguration.pointerMovePredicate = OO
      }
      get pointerDownFastCheck() {
        return this._pointerPickingConfiguration.pointerDownFastCheck
      }
      set pointerDownFastCheck(OO) {
        this._pointerPickingConfiguration.pointerDownFastCheck = OO
      }
      get pointerUpFastCheck() {
        return this._pointerPickingConfiguration.pointerUpFastCheck
      }
      set pointerUpFastCheck(OO) {
        this._pointerPickingConfiguration.pointerUpFastCheck = OO
      }
      get pointerMoveFastCheck() {
        return this._pointerPickingConfiguration.pointerMoveFastCheck
      }
      set pointerMoveFastCheck(OO) {
        this._pointerPickingConfiguration.pointerMoveFastCheck = OO
      }
      get skipPointerMovePicking() {
        return this._pointerPickingConfiguration.skipPointerMovePicking
      }
      set skipPointerMovePicking(OO) {
        this._pointerPickingConfiguration.skipPointerMovePicking = OO
      }
      get skipPointerDownPicking() {
        return this._pointerPickingConfiguration.skipPointerDownPicking
      }
      set skipPointerDownPicking(OO) {
        this._pointerPickingConfiguration.skipPointerDownPicking = OO
      }
      get skipPointerUpPicking() {
        return this._pointerPickingConfiguration.skipPointerUpPicking
      }
      set skipPointerUpPicking(OO) {
        this._pointerPickingConfiguration.skipPointerUpPicking = OO
      }
      get unTranslatedPointer() {
        return this._inputManager.unTranslatedPointer
      }
      static get DragMovementThreshold() {
        return BO.DragMovementThreshold
      }
      static set DragMovementThreshold(OO) {
        BO.DragMovementThreshold = OO
      }
      static get LongPressDelay() {
        return BO.LongPressDelay
      }
      static set LongPressDelay(OO) {
        BO.LongPressDelay = OO
      }
      static get DoubleClickDelay() {
        return BO.DoubleClickDelay
      }
      static set DoubleClickDelay(OO) {
        BO.DoubleClickDelay = OO
      }
      static get ExclusiveDoubleClickMode() {
        return BO.ExclusiveDoubleClickMode
      }
      static set ExclusiveDoubleClickMode(OO) {
        BO.ExclusiveDoubleClickMode = OO
      }
      get _eyePosition() {
        return this._forcedViewPosition ?? this.activeCamera?.globalPosition ?? DO.o.ZeroReadOnly
      }
      bindEyePosition(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "vEyePosition",
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = this._eyePosition,
          bK = this.useRightHandedSystem === (null != this._mirroredCameraPosition),
          eO = this.floatingOriginOffset,
          lO = pp.set(XO.x, XO.y, XO.z, bK ? -1 : 1),
          vK = lO.subtractFromFloatsToRef(eO.x, eO.y, eO.z, 0, Xp);
        return OO && (pO ? OO.setFloat3(KO, vK.x, vK.y, vK.z) : OO.setVector4(KO, vK)), lO
      }
      finalizeSceneUbo() {
        const OO = this.getSceneUniformBuffer(),
          KO = this.bindEyePosition(null),
          pO = this.floatingOriginOffset;
        return OO.updateFloat4("vEyePosition", KO.x - pO.x, KO.y - pO.y, KO.z - pO.z, KO.w), OO.update(), OO
      }
      set useRightHandedSystem(OO) {
        this._useRightHandedSystem !== OO && (this._useRightHandedSystem = OO, this.markAllMaterialsAsDirty(16))
      }
      get useRightHandedSystem() {
        return this._useRightHandedSystem
      }
      setStepId(OO) {
        this._currentStepId = OO
      }
      getStepId() {
        return this._currentStepId
      }
      getInternalStep() {
        return this._currentInternalStep
      }
      set fogEnabled(OO) {
        this._fogEnabled !== OO && (this._fogEnabled = OO, this.markAllMaterialsAsDirty(16))
      }
      get fogEnabled() {
        return this._fogEnabled
      }
      set fogMode(OO) {
        this._fogMode !== OO && (this._fogMode = OO, this.markAllMaterialsAsDirty(16))
      }
      get fogMode() {
        return this._fogMode
      }
      get prePass() {
        return !!this.prePassRenderer && this.prePassRenderer.defaultRT.enabled
      }
      set shadowsEnabled(OO) {
        this._shadowsEnabled !== OO && (this._shadowsEnabled = OO, this.markAllMaterialsAsDirty(2))
      }
      get shadowsEnabled() {
        return this._shadowsEnabled
      }
      set lightsEnabled(OO) {
        this._lightsEnabled !== OO && (this._lightsEnabled = OO, this.markAllMaterialsAsDirty(2))
      }
      get lightsEnabled() {
        return this._lightsEnabled
      }
      get activeCameras() {
        return this._activeCameras
      }
      set activeCameras(OO) {
        this._unObserveActiveCameras && (this._unObserveActiveCameras(), this._unObserveActiveCameras = null), OO && (this._unObserveActiveCameras = (0, tK.g)(OO, (() => {
          this.onActiveCamerasChanged.notifyObservers(this)
        }))), this._activeCameras = OO
      }
      get activeCamera() {
        return this._activeCamera
      }
      set activeCamera(OO) {
        OO !== this._activeCamera && (this._activeCamera = OO, this.onActiveCameraChanged.notifyObservers(this))
      }
      get _hasDefaultMaterial() {
        return ep.DefaultMaterialFactory !== ep._OriginalDefaultMaterialFactory
      }
      get defaultMaterial() {
        return this._defaultMaterial || (this._defaultMaterial = ep.DefaultMaterialFactory(this)), this._defaultMaterial
      }
      set defaultMaterial(OO) {
        this._defaultMaterial = OO
      }
      set texturesEnabled(OO) {
        this._texturesEnabled !== OO && (this._texturesEnabled = OO, this.markAllMaterialsAsDirty(1))
      }
      get texturesEnabled() {
        return this._texturesEnabled
      }
      get frameGraph() {
        return this._frameGraph
      }
      set frameGraph(OO) {
        if (this._frameGraph) return this._frameGraph = OO, void(OO || (this.customRenderFunction = this._currentCustomRenderFunction));
        this._frameGraph = OO, OO && (this._currentCustomRenderFunction = this.customRenderFunction, this.customRenderFunction = this._renderWithFrameGraph, this.activeCamera = null)
      }
      set skeletonsEnabled(OO) {
        this._skeletonsEnabled !== OO && (this._skeletonsEnabled = OO, this.markAllMaterialsAsDirty(8))
      }
      get skeletonsEnabled() {
        return this._skeletonsEnabled
      }
      get collisionCoordinator() {
        return this._collisionCoordinator || (this._collisionCoordinator = ep.CollisionCoordinatorFactory(), this._collisionCoordinator.init(this)), this._collisionCoordinator
      }
      get renderingManager() {
        return this._renderingManager
      }
      get frustumPlanes() {
        return this._frustumPlanes
      }
      _registerTransientComponents() {
        if (this._transientComponents.length > 0) {
          for (const OO of this._transientComponents) OO.register();
          this._transientComponents.length = 0
        }
      }
      cDO(OO) {
        this._components.push(OO), this._transientComponents.push(OO);
        const KO = OO;
        KO.addFromContainer && KO.serialize && this._serializableComponents.push(KO)
      }
      _getComponent(OO) {
        for (const KO of this._components)
          if (KO.name === OO) return KO;
        return null
      }
      get uniqueId() {
        return this._uniqueId
      }
      constructor(OO, KO) {
        this._inputManager = new BO(this), this.cameraToUseForPointers = null, this._isScene = !0, this._blockEntityCollection = !1, this.autoClear = !0, this.autoClearDepthAndStencil = !0, this._clearColor = new GO.g(.2, .2, .3, 1), this.onClearColorChangedObservable = new lO.e, this.ambientColor = new GO.e(0, 0, 0), this.environmentIntensity = 1, this.iblIntensity = 1, this._performancePriority = 0, this.onScenePerformancePriorityChangedObservable = new lO.e, this._forceWireframe = !1, this._skipFrustumClipping = !1, this._forcePointsCloud = !1, this.rootNodes = [], this.cameras = [], this.lights = [], this.meshes = [], this.skeletons = [], this.ku = [], this.animations = [], this.animationGroups = [], this.multiMaterials = [], this.materials = [], this.morphTargetManagers = [], this.geometries = [], this.transformNodes = [], this.actionManagers = [], this.objectRenderers = [], this.textures = [], this._environmentTexture = null, this.postProcesses = [], this.effectLayers = [], this.sounds = null, this.layers = [], this.lensFlareSystems = [], this.proceduralTextures = [], this.animationsEnabled = !0, this._animationPropertiesOverride = null, this.useConstantAnimationDeltaTime = !1, this.constantlyUpdateMeshUnderPointer = !1, this.hoverCursor = "pointer", this.defaultCursor = "", this.doNotHandleCursors = !1, this.preventDefaultOnPointerDown = !0, this.preventDefaultOnPointerUp = !0, this.metadata = null, this.reservedDataStore = null, this.disableOfflineSupportExceptionRules = [], this.cpO = new lO.e, this._onDisposeObserver = null, this.onBeforeRenderObservable = new lO.e, this._onBeforeRenderObserver = null, this.onAfterRenderObservable = new lO.e, this.onAfterRenderCameraObservable = new lO.e, this._onAfterRenderObserver = null, this.onBeforeAnimationsObservable = new lO.e, this.onAfterAnimationsObservable = new lO.e, this.onBeforeDrawPhaseObservable = new lO.e, this.onAfterDrawPhaseObservable = new lO.e, this.onReadyObservable = new lO.e, this.onBeforeCameraRenderObservable = new lO.e, this._onBeforeCameraRenderObserver = null, this.onAfterCameraRenderObservable = new lO.e, this._onAfterCameraRenderObserver = null, this.onBeforeActiveMeshesEvaluationObservable = new lO.e, this.onAfterActiveMeshesEvaluationObservable = new lO.e, this.onBeforeParticlesRenderingObservable = new lO.e, this.onAfterParticlesRenderingObservable = new lO.e, this.onDataLoadedObservable = new lO.e, this.onNewCameraAddedObservable = new lO.e, this.onCameraRemovedObservable = new lO.e, this.onNewLightAddedObservable = new lO.e, this.onLightRemovedObservable = new lO.e, this.onNewGeometryAddedObservable = new lO.e, this.onGeometryRemovedObservable = new lO.e, this.onNewTransformNodeAddedObservable = new lO.e, this.onTransformNodeRemovedObservable = new lO.e, this.onNewMeshAddedObservable = new lO.e, this.onMeshRemovedObservable = new lO.e, this.onNewSkeletonAddedObservable = new lO.e, this.onSkeletonRemovedObservable = new lO.e, this.onNewParticleSystemAddedObservable = new lO.e, this.onParticleSystemRemovedObservable = new lO.e, this.onNewAnimationGroupAddedObservable = new lO.e, this.onAnimationGroupRemovedObservable = new lO.e, this.onNewMaterialAddedObservable = new lO.e, this.onNewMultiMaterialAddedObservable = new lO.e, this.onMaterialRemovedObservable = new lO.e, this.onMultiMaterialRemovedObservable = new lO.e, this.onNewTextureAddedObservable = new lO.e, this.onTextureRemovedObservable = new lO.e, this.onNewFrameGraphAddedObservable = new lO.e, this.onFrameGraphRemovedObservable = new lO.e, this.onNewObjectRendererAddedObservable = new lO.e, this.onObjectRendererRemovedObservable = new lO.e, this.onNewPostProcessAddedObservable = new lO.e, this.onPostProcessRemovedObservable = new lO.e, this.onNewEffectLayerAddedObservable = new lO.e, this.onEffectLayerRemovedObservable = new lO.e, this.onBeforeRenderTargetsRenderObservable = new lO.e, this.onAfterRenderTargetsRenderObservable = new lO.e, this.onBeforeStepObservable = new lO.e, this.onAfterStepObservable = new lO.e, this.onActiveCameraChanged = new lO.e, this.onActiveCamerasChanged = new lO.e, this.onBeforeRenderingGroupObservable = new lO.e, this.onAfterRenderingGroupObservable = new lO.e, this.onMeshImportedObservable = new lO.e, this.onAnimationFileImportedObservable = new lO.e, this.onEnvironmentTextureChangedObservable = new lO.e, this.onMeshUnderPointerUpdatedObservable = new lO.e, this._registeredForLateAnimationBindings = new vK.d(256), this._pointerPickingConfiguration = new kK, this.onPrePointerObservable = new lO.e, this.onPointerObservable = new lO.e, this.onPreKeyboardObservable = new lO.e, this.onKeyboardObservable = new lO.e, this._useRightHandedSystem = !1, this._timeAccumulator = 0, this._currentStepId = 0, this._currentInternalStep = 0, this._fogEnabled = !0, this._fogMode = ep.FOGMODE_NONE, this.fogColor = new GO.e(.2, .2, .3), this.fogDensity = .1, this.fogStart = 0, this.fogEnd = 1e3, this.needsPreviousWorldMatrices = !1, this._shadowsEnabled = !0, this._lightsEnabled = !0, this._unObserveActiveCameras = null, this._texturesEnabled = !0, this._frameGraph = null, this.frameGraphs = [], this.RpO = !0, this.particlesEnabled = !0, this.spritesEnabled = !0, this._skeletonsEnabled = !0, this.lensFlaresEnabled = !0, this.collisionsEnabled = !0, this.gravity = new DO.o(0, -9.807, 0), this.postProcessesEnabled = !0, this.renderTargetsEnabled = !0, this.dumpNextRenderTargets = !1, this.customRenderTargets = [], this.importedMeshesFiles = [], this.probesEnabled = !0, this._meshesForIntersections = new vK.d(256), this.proceduralTexturesEnabled = !0, this._totalVertices = new ZO.c, this._activeIndices = new ZO.c, this._activeParticles = new ZO.c, this._activeBones = new ZO.c, this._animationTime = 0, this.animationTimeScale = 1, this._renderId = 0, this._frameId = 0, this._renderingMeshEvaluationDepth = 0, this._executeWhenReadyTimeoutId = null, this._intermediateRendering = !1, this._defaultFrameBufferCleared = !1, this._viewUpdateFlag = -1, this._projectionUpdateFlag = -1, this._toBeDisposed = new Array(256), this._activeRequests = new Array, this._delayedFileRequests = null, this._pendingData = [], this._isDisposed = !1, this._isDisposing = !1, this._isReadyChecks = [], this.dispatchAllSubMeshesOfActiveMeshes = !1, this._activeMeshes = new vK.e(256), this._processedMaterials = new vK.e(256), this._renderTargets = new vK.d(256), this._materialsRenderTargets = new vK.d(256), this._activeParticleSystems = new vK.e(256), this._activeSkeletons = new vK.d(32), this._softwareSkinnedMeshes = new vK.d(32), this._activeAnimatables = new Array, this._animationWrites = new Array, this._animationWriteCount = 0, this._animationStepWriteCount = 0, this._animationStepEvaluated = !1, this._transformMatrix = DO.c.Zero(), this.requireLightSorting = !1, this._components = [], this._serializableComponents = [], this._transientComponents = [], this._beforeCameraUpdateStage = zK.e.Create(), this._beforeClearStage = zK.e.Create(), this._beforeRenderTargetClearStage = zK.e.Create(), this._gatherRenderTargetsStage = zK.e.Create(), this._gatherActiveCameraRenderTargetsStage = zK.e.Create(), this._isReadyForMeshStage = zK.e.Create(), this._beforeEvaluateActiveMeshStage = zK.e.Create(), this._evaluateSubMeshStage = zK.e.Create(), this._preActiveMeshStage = zK.e.Create(), this._cameraDrawRenderTargetStage = zK.e.Create(), this._beforeCameraDrawStage = zK.e.Create(), this._beforeRenderTargetDrawStage = zK.e.Create(), this._beforeRenderingGroupDrawStage = zK.e.Create(), this._beforeRenderingMeshStage = zK.e.Create(), this._afterRenderingMeshStage = zK.e.Create(), this._afterRenderingGroupDrawStage = zK.e.Create(), this._afterCameraDrawStage = zK.e.Create(), this._afterCameraPostProcessStage = zK.e.Create(), this._afterRenderTargetDrawStage = zK.e.Create(), this._afterRenderTargetPostProcessStage = zK.e.Create(), this._afterRenderStage = zK.e.Create(), this._pointerMoveStage = zK.e.Create(), this._pointerDownStage = zK.e.Create(), this._pointerUpStage = zK.e.Create(), this._geometriesByUniqueId = null, this._uniqueId = 0, this._defaultMeshCandidates = {
          data: [],
          length: 0
        }, this._defaultSubMeshCandidates = {
          data: [],
          length: 0
        }, this.onReadyTimeoutObservable = new lO.e, this.onReadyTimeoutDuration = 12e4, this._timeoutChecksStartTime = 0, this._floatingOriginScene = void 0, this._preventFreeActiveMeshesAndRenderingGroups = !1, this._activeMeshesFrozen = !1, this._activeMeshesFrozenButKeepClipping = !1, this._skipEvaluateActiveMeshesCompletely = !1, this._freezeActiveMeshesCancel = null, this._useCurrentFrameBuffer = !1, this._allowPostProcessClearColor = !0, this.getDeterministicFrameTime = () => this._engine.getTimeStep(), this._getFloatingOriginScene = () => this._floatingOriginScene, this._registeredActions = 0, this._blockMaterialDirtyMechanism = !1, this._perfCollector = null, this.activeCameras = [], this._uniqueId = this.getUniqueId();
        const pO = {
          useGeometryUniqueIdsMap: !0,
          useMaterialMeshMap: !0,
          useClonedMeshMap: !0,
          virtual: !1,
          defaultCameraLayerMask: 268435455,
          defaultRenderableLayerMask: 268435455,
          ...KO
        };
        this.defaultCameraLayerMask = pO.defaultCameraLayerMask, this.defaultRenderableLayerMask = pO.defaultRenderableLayerMask, OO = this._engine = OO || fO.c.LastCreatedEngine, pO.virtual ? OO._virtualScenes.push(this) : (fO.c._LastCreatedScene = this, OO.scenes.push(this)), (OO.getCreationOptions().useLargeWorldRendering || KO?.useFloatingOrigin) && ((0, LO.g)(), this._floatingOriginScene = this, LO.c.JKO = this._getFloatingOriginScene), this._uid = null, this._renderingManager = new QO.b(this), VO.b && (this.postProcessManager = new VO.b(this)), (0, AO.n)() && this.attachControl(), this._createUbo(), MO.d && (this._imageProcessingConfiguration = new MO.d), this.setDefaultCandidateProviders(), pO.useGeometryUniqueIdsMap && (this._geometriesByUniqueId = {}), this.useMaterialMeshMap = pO.useMaterialMeshMap, this.useClonedMeshMap = pO.useClonedMeshMap, KO && KO.virtual || OO.onNewSceneAddedObservable.notifyObservers(this)
      }
      getClassName() {
        return "Scene"
      }
      _getDefaultMeshCandidates() {
        return this._defaultMeshCandidates.data = this.meshes, this._defaultMeshCandidates.length = this.meshes.length, this._defaultMeshCandidates
      }
      _getDefaultSubMeshCandidates(OO) {
        return this._defaultSubMeshCandidates.data = OO.au, this._defaultSubMeshCandidates.length = OO.au.length, this._defaultSubMeshCandidates
      }
      setDefaultCandidateProviders() {
        this.getActiveMeshCandidates = () => this._getDefaultMeshCandidates(), this.getActiveSubMeshCandidates = OO => this._getDefaultSubMeshCandidates(OO), this.getIntersectingSubMeshCandidates = (OO, KO) => this._getDefaultSubMeshCandidates(OO), this.getCollidingSubMeshCandidates = (OO, KO) => this._getDefaultSubMeshCandidates(OO)
      }
      get meshUnderPointer() {
        return this._inputManager.meshUnderPointer
      }
      get pointerX() {
        return this._inputManager.pointerX
      }
      set pointerX(OO) {
        this._inputManager.pointerX = OO
      }
      get pointerY() {
        return this._inputManager.pointerY
      }
      set pointerY(OO) {
        this._inputManager.pointerY = OO
      }
      getCachedMaterial() {
        return this._cachedMaterial
      }
      getCachedEffect() {
        return this._cachedEffect
      }
      getCachedVisibility() {
        return this._cachedVisibility
      }
      isCachedMaterialInvalid(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
        return this._cachedEffect !== KO || this._cachedMaterial !== OO || this._cachedVisibility !== pO
      }
      qb() {
        return this._engine
      }
      getTotalVertices() {
        return this._totalVertices.current
      }
      get totalVerticesPerfCounter() {
        return this._totalVertices
      }
      getActiveIndices() {
        return this._activeIndices.current
      }
      get totalActiveIndicesPerfCounter() {
        return this._activeIndices
      }
      getActiveParticles() {
        return this._activeParticles.current
      }
      get activeParticlesPerfCounter() {
        return this._activeParticles
      }
      getActiveBones() {
        return this._activeBones.current
      }
      get activeBonesPerfCounter() {
        return this._activeBones
      }
      getActiveMeshes() {
        return this._activeMeshes
      }
      getAnimationRatio() {
        return void 0 !== this._animationRatio ? this._animationRatio : 1
      }
      getRenderId() {
        return this._renderId
      }
      getFrameId() {
        return this._frameId
      }
      incrementRenderId() {
        this._renderId++
      }
      _createUbo() {
        this.setSceneUniformBuffer(this.createSceneUniformBuffer())
      }
      simulatePointerMove(OO, KO) {
        return this._inputManager.simulatePointerMove(OO, KO), this
      }
      simulatePointerDown(OO, KO) {
        return this._inputManager.simulatePointerDown(OO, KO), this
      }
      simulatePointerUp(OO, KO, pO) {
        return this._inputManager.simulatePointerUp(OO, KO, pO), this
      }
      isPointerCaptured() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return this._inputManager.isPointerCaptured(OO)
      }
      attachControl() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
          KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        this._inputManager.attachControl(OO, KO, pO)
      }
      detachControl() {
        this._inputManager.detachControl()
      }
      isReady() {
        let OO, KO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        if (this._isDisposed) return !1;
        const pO = this.qb(),
          XO = pO.currentRenderPassId;
        pO.currentRenderPassId = this.activeCamera?.renderPassId ?? XO;
        let bK = !0;
        for (this._pendingData.length > 0 && (bK = !1), this.prePassRenderer?.update(), this.useOrderIndependentTransparency && this.depthPeelingRenderer && bK && (bK = this.depthPeelingRenderer.isReady()), KO && (this._processedMaterials.reset(), this._materialsRenderTargets.reset()), OO = 0; OO < this.meshes.length; OO++) {
          const XO = this.meshes[OO];
          if (!XO.au || 0 === XO.au.length) continue;
          if (!XO.isReady(!0)) {
            bK = !1;
            continue
          }
          const eO = XO.hasThinInstances || "InstancedMesh" === XO.getClassName() || "InstancedLinesMesh" === XO.getClassName() || pO.getCaps().instancedArrays && XO.instances.length > 0;
          for (let OO = 0, KO = this._isReadyForMeshStage; OO < KO.length; OO++) {
            KO[OO].action(XO, eO) || (bK = !1)
          }
          if (!KO) continue;
          const lO = XO.material || this.defaultMaterial;
          if (lO)
            if (lO._storeEffectOnSubMeshes)
              for (const OO of XO.au) {
                const KO = OO.UX();
                KO && KO.hasRenderTargetTextures && null != KO.getRenderTargetTextures && -1 === this._processedMaterials.indexOf(KO) && (this._processedMaterials.push(KO), this._materialsRenderTargets.concatWithNoDuplicate(KO.getRenderTargetTextures()))
              } else lO.hasRenderTargetTextures && null != lO.getRenderTargetTextures && -1 === this._processedMaterials.indexOf(lO) && (this._processedMaterials.push(lO), this._materialsRenderTargets.concatWithNoDuplicate(lO.getRenderTargetTextures()))
        }
        if (KO) {
          for (OO = 0; OO < this._materialsRenderTargets.length; ++OO) {
            this._materialsRenderTargets.data[OO].isReadyForRendering() || (bK = !1)
          }
          for (OO = 0; OO < this.customRenderTargets.length; ++OO) {
            this.customRenderTargets[OO].isReadyForRendering() || (bK = !1)
          }
        }
        for (OO = 0; OO < this.geometries.length; OO++) {
          2 === this.geometries[OO].delayLoadState && (bK = !1)
        }
        if (this.activeCameras && this.activeCameras.length > 0)
          for (const eO of this.activeCameras) eO.isReady(!0) || (bK = !1);
        else this.activeCamera && (this.activeCamera.isReady(!0) || (bK = !1));
        for (const eO of this.ku) eO.isReady() || (bK = !1);
        if (this.proceduralTexturesEnabled)
          for (const eO of this.proceduralTextures) eO.isReady() || (bK = !1);
        if (this.layers)
          for (const eO of this.layers) eO.isReady() || (bK = !1);
        if (this.effectLayers)
          for (const eO of this.effectLayers) eO.isLayerReady() || (bK = !1);
        for (const eO of this._isReadyChecks) eO.isReady() || (bK = !1);
        return pO.areAllEffectsReady() || (bK = !1), pO.currentRenderPassId = XO, bK
      }
      resetCachedMaterial() {
        this._cachedMaterial = null, this._cachedEffect = null, this._cachedVisibility = null
      }
      registerBeforeRender(OO) {
        this.onBeforeRenderObservable.add(OO)
      }
      unregisterBeforeRender(OO) {
        this.onBeforeRenderObservable.removeCallback(OO)
      }
      registerAfterRender(OO) {
        this.onAfterRenderObservable.add(OO)
      }
      unregisterAfterRender(OO) {
        this.onAfterRenderObservable.removeCallback(OO)
      }
      _executeOnceBeforeRender(OO) {
        const KO = () => {
          OO(), setTimeout((() => {
            this.unregisterBeforeRender(KO)
          }))
        };
        this.registerBeforeRender(KO)
      }
      executeOnceBeforeRender(OO, KO) {
        void 0 !== KO ? setTimeout((() => {
          this._executeOnceBeforeRender(OO)
        }), KO) : this._executeOnceBeforeRender(OO)
      }
      addPendingData(OO) {
        this._pendingData.push(OO)
      }
      removePendingData(OO) {
        const KO = this.isLoading,
          pO = this._pendingData.indexOf(OO); - 1 !== pO && this._pendingData.splice(pO, 1), KO && !this.isLoading && this.onDataLoadedObservable.notifyObservers(this)
      }
      getWaitingItemsCount() {
        return this._pendingData.length
      }
      get isLoading() {
        return this._pendingData.length > 0
      }
      addIsReadyCheck(OO) {
        -1 === this._isReadyChecks.indexOf(OO) && this._isReadyChecks.push(OO)
      }
      removeIsReadyCheck(OO) {
        const KO = this._isReadyChecks.indexOf(OO); - 1 !== KO && this._isReadyChecks.splice(KO, 1)
      }
      executeWhenReady(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        this.onReadyObservable.addOnce(OO), null === this._executeWhenReadyTimeoutId && this._checkIsReady(KO)
      }
      async whenReadyAsync() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        return await new Promise((KO => {
          this.executeWhenReady((() => {
            KO()
          }), OO)
        }))
      }
      _clearReadynessChecksData() {
        this._timeoutChecksStartTime = 0, this.onReadyTimeoutObservable.clear(), this.onReadyObservable.clear(), this._executeWhenReadyTimeoutId = null
      }
      _checkIsReady() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        if (this._registerTransientComponents(), 0 === this._timeoutChecksStartTime) this._timeoutChecksStartTime = eO.d.Now;
        else if (this.onReadyTimeoutDuration > 0 && eO.d.Now - this._timeoutChecksStartTime > this.onReadyTimeoutDuration) return this.onReadyTimeoutObservable.notifyObservers(this), void this._clearReadynessChecksData();
        if (this.isReady(OO)) return this.onReadyObservable.notifyObservers(this), void this._clearReadynessChecksData();
        this._isDisposed ? this._clearReadynessChecksData() : this._executeWhenReadyTimeoutId = setTimeout((() => {
          this.incrementRenderId(), this._checkIsReady(OO)
        }), 100)
      }
      get animatables() {
        return this._activeAnimatables
      }
      resetLastAnimationTimeFrame() {
        this._animationTimeLast = eO.d.Now
      }
      getViewMatrix() {
        return this._viewMatrix
      }
      getProjectionMatrix() {
        return this._projectionMatrix
      }
      getInverseProjectionMatrix() {
        return this._inverseProjectionMatrix
      }
      getTransformMatrix() {
        return this._transformMatrix
      }
      setTransformMatrix(OO, KO, pO, XO) {
        this._multiviewSceneUboIsActive = !!(pO && XO && this._multiviewSceneUbo), this._viewUpdateFlag === OO.updateFlag && this._projectionUpdateFlag === KO.updateFlag || (this._viewUpdateFlag = OO.updateFlag, this._projectionUpdateFlag = KO.updateFlag, this._viewMatrix = OO, this._projectionMatrix = KO, this._inverseProjectionMatrix || (this._inverseProjectionMatrix = new DO.c), this._projectionMatrix.invertToRef(this._inverseProjectionMatrix), this._viewMatrix.multiplyToRef(this._projectionMatrix, this._transformMatrix), this._frustumPlanes ? qK.e.GetPlanesToRef(this._transformMatrix, this._frustumPlanes) : this._frustumPlanes = qK.e.GetPlanes(this._transformMatrix), this._multiviewSceneUboIsActive && this._multiviewSceneUbo.useUbo ? this._updateMultiviewUbo(pO, XO) : this._sceneUbo.useUbo && (this._sceneUbo.AlO("viewProjection", this._transformMatrix), this._sceneUbo.AlO("view", this._viewMatrix), this._sceneUbo.AlO("projection", this._projectionMatrix), this._sceneUbo.AlO("inverseProjection", this._inverseProjectionMatrix)))
      }
      getSceneUniformBuffer() {
        return this._multiviewSceneUboIsActive && this._multiviewSceneUbo ? this._multiviewSceneUbo : this._sceneUbo
      }
      createSceneUniformBuffer(OO, KO) {
        const pO = "boolean" === typeof KO ? KO : KO?.trackUBOsInFrame,
          XO = new aK.d(this._engine, void 0, !1, OO ?? "Ce", void 0, pO);
        return XO.addUniform("viewProjection", 16), XO.addUniform("view", 16), XO.addUniform("projection", 16), XO.addUniform("vEyePosition", 4), XO.addUniform("inverseProjection", 16), XO
      }
      setSceneUniformBuffer(OO) {
        this._sceneUbo = OO, this._viewUpdateFlag = -1, this._projectionUpdateFlag = -1
      }
      get floatingOriginMode() {
        return void 0 !== this._floatingOriginScene
      }
      get floatingOriginOffset() {
        return this.floatingOriginMode ? this._eyePosition : DO.o.ZeroReadOnly
      }
      getUniqueId() {
        return xK.UniqueId
      }
      GhO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (!this._blockEntityCollection && (this.meshes.push(OO), OO._resyncLightSources(), OO.parent || OO._addToSceneRootNodes(), bK.c.SetImmediate((() => {
            this.onNewMeshAddedObservable.notifyObservers(OO)
          })), KO)) {
          const KO = OO.getChildMeshes();
          for (const OO of KO) this.GhO(OO)
        }
      }
      nKO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = this.meshes.indexOf(OO);
        if (-1 !== pO && (this.meshes.splice(pO, 1), OO.parent || OO._removeFromSceneRootNodes()), this._inputManager._invalidateMesh(OO), this.onMeshRemovedObservable.notifyObservers(OO), KO) {
          const KO = OO.getChildMeshes();
          for (const OO of KO) this.nKO(OO)
        }
        return pO
      }
      addTransformNode(OO) {
        this._blockEntityCollection || OO.JKO() === this && -1 !== OO._indexInSceneTransformNodesArray || (OO._indexInSceneTransformNodesArray = this.transformNodes.length, this.transformNodes.push(OO), OO.parent || OO._addToSceneRootNodes(), this.onNewTransformNodeAddedObservable.notifyObservers(OO))
      }
      removeTransformNode(OO) {
        const KO = OO._indexInSceneTransformNodesArray;
        if (-1 !== KO) {
          if (KO !== this.transformNodes.length - 1) {
            const OO = this.transformNodes[this.transformNodes.length - 1];
            this.transformNodes[KO] = OO, OO._indexInSceneTransformNodesArray = KO
          }
          OO._indexInSceneTransformNodesArray = -1, this.transformNodes.pop(), OO.parent || OO._removeFromSceneRootNodes()
        }
        return this.onTransformNodeRemovedObservable.notifyObservers(OO), KO
      }
      removeSkeleton(OO) {
        const KO = this.skeletons.indexOf(OO);
        return -1 !== KO && (this.skeletons.splice(KO, 1), this.onSkeletonRemovedObservable.notifyObservers(OO), this._executeActiveContainerCleanup(this._activeSkeletons)), KO
      }
      removeMorphTargetManager(OO) {
        const KO = this.morphTargetManagers.indexOf(OO);
        return -1 !== KO && this.morphTargetManagers.splice(KO, 1), KO
      }
      removeLight(OO) {
        const KO = this.lights.indexOf(OO);
        if (-1 !== KO) {
          for (const KO of this.meshes) KO._removeLightSource(OO, !1);
          this.lights.splice(KO, 1), this.sortLightsByPriority(), OO.parent || OO._removeFromSceneRootNodes(), this.onLightRemovedObservable.notifyObservers(OO)
        }
        return KO
      }
      removeCamera(OO) {
        const KO = this.cameras.indexOf(OO);
        if (-1 !== KO && (this.cameras.splice(KO, 1), OO.parent || OO._removeFromSceneRootNodes()), this.activeCameras) {
          const KO = this.activeCameras.indexOf(OO); - 1 !== KO && this.activeCameras.splice(KO, 1)
        }
        return this.activeCamera === OO && (this.cameras.length > 0 ? this.activeCamera = this.cameras[0] : this.activeCamera = null), this.onCameraRemovedObservable.notifyObservers(OO), KO
      }
      removeParticleSystem(OO) {
        const KO = this.ku.indexOf(OO);
        return -1 !== KO && (this.ku.splice(KO, 1), this._executeActiveContainerCleanup(this._activeParticleSystems)), this.onParticleSystemRemovedObservable.notifyObservers(OO), KO
      }
      removeAnimation(OO) {
        const KO = this.animations.indexOf(OO);
        return -1 !== KO && this.animations.splice(KO, 1), KO
      }
      stopAnimation(OO, KO, pO) {}
      removeAnimationGroup(OO) {
        const KO = this.animationGroups.indexOf(OO);
        return -1 !== KO && this.animationGroups.splice(KO, 1), this.onAnimationGroupRemovedObservable.notifyObservers(OO), KO
      }
      removeMultiMaterial(OO) {
        const KO = this.multiMaterials.indexOf(OO);
        return -1 !== KO && this.multiMaterials.splice(KO, 1), this.onMultiMaterialRemovedObservable.notifyObservers(OO), KO
      }
      removeMaterial(OO) {
        const KO = OO._indexInSceneMaterialArray;
        if (-1 !== KO && KO < this.materials.length) {
          if (KO !== this.materials.length - 1) {
            const OO = this.materials[this.materials.length - 1];
            this.materials[KO] = OO, OO._indexInSceneMaterialArray = KO
          }
          OO._indexInSceneMaterialArray = -1, this.materials.pop()
        }
        return this.onMaterialRemovedObservable.notifyObservers(OO), KO
      }
      removeActionManager(OO) {
        const KO = this.actionManagers.indexOf(OO);
        return -1 !== KO && this.actionManagers.splice(KO, 1), KO
      }
      removeTexture(OO) {
        const KO = this.textures.indexOf(OO);
        return -1 !== KO && this.textures.splice(KO, 1), this.onTextureRemovedObservable.notifyObservers(OO), KO
      }
      removeFrameGraph(OO) {
        const KO = this.frameGraphs.indexOf(OO);
        return -1 !== KO && this.frameGraphs.splice(KO, 1), this.onFrameGraphRemovedObservable.notifyObservers(OO), KO
      }
      removeObjectRenderer(OO) {
        const KO = this.objectRenderers.indexOf(OO);
        return -1 !== KO && this.objectRenderers.splice(KO, 1), this.onObjectRendererRemovedObservable.notifyObservers(OO), KO
      }
      removePostProcess(OO) {
        const KO = this.postProcesses.indexOf(OO);
        return -1 !== KO && this.postProcesses.splice(KO, 1), this.onPostProcessRemovedObservable.notifyObservers(OO), KO
      }
      removeEffectLayer(OO) {
        const KO = this.effectLayers.indexOf(OO);
        return -1 !== KO && this.effectLayers.splice(KO, 1), this.onEffectLayerRemovedObservable.notifyObservers(OO), KO
      }
      addLight(OO) {
        if (!this._blockEntityCollection) {
          this.lights.push(OO), this.sortLightsByPriority(), OO.parent || OO._addToSceneRootNodes();
          for (const KO of this.meshes) - 1 === KO.lightSources.indexOf(OO) && (KO.lightSources.push(OO), KO._resyncLightSources());
          bK.c.SetImmediate((() => {
            this.onNewLightAddedObservable.notifyObservers(OO)
          }))
        }
      }
      sortLightsByPriority() {
        this.requireLightSorting && this.lights.sort(WO.e.CompareLightsPriority)
      }
      addCamera(OO) {
        this._blockEntityCollection || (this.cameras.push(OO), bK.c.SetImmediate((() => {
          this.onNewCameraAddedObservable.notifyObservers(OO)
        })), OO.parent || OO._addToSceneRootNodes())
      }
      addSkeleton(OO) {
        this._blockEntityCollection || (this.skeletons.push(OO), bK.c.SetImmediate((() => {
          this.onNewSkeletonAddedObservable.notifyObservers(OO)
        })))
      }
      addParticleSystem(OO) {
        this._blockEntityCollection || (this.ku.push(OO), bK.c.SetImmediate((() => {
          this.onNewParticleSystemAddedObservable.notifyObservers(OO)
        })))
      }
      addAnimation(OO) {
        this._blockEntityCollection || this.animations.push(OO)
      }
      addAnimationGroup(OO) {
        this._blockEntityCollection || (this.animationGroups.push(OO), bK.c.SetImmediate((() => {
          this.onNewAnimationGroupAddedObservable.notifyObservers(OO)
        })))
      }
      addMultiMaterial(OO) {
        this._blockEntityCollection || (this.multiMaterials.push(OO), bK.c.SetImmediate((() => {
          this.onNewMultiMaterialAddedObservable.notifyObservers(OO)
        })))
      }
      addMaterial(OO) {
        this._blockEntityCollection || OO.JKO() === this && -1 !== OO._indexInSceneMaterialArray || (OO._indexInSceneMaterialArray = this.materials.length, this.materials.push(OO), bK.c.SetImmediate((() => {
          this.onNewMaterialAddedObservable.notifyObservers(OO)
        })))
      }
      addMorphTargetManager(OO) {
        this._blockEntityCollection || this.morphTargetManagers.push(OO)
      }
      addGeometry(OO) {
        this._blockEntityCollection || (this._geometriesByUniqueId && (this._geometriesByUniqueId[OO.uniqueId] = this.geometries.length), this.geometries.push(OO))
      }
      addActionManager(OO) {
        this.actionManagers.push(OO)
      }
      addTexture(OO) {
        this._blockEntityCollection || (this.textures.push(OO), this.onNewTextureAddedObservable.notifyObservers(OO))
      }
      addFrameGraph(OO) {
        this.frameGraphs.push(OO), bK.c.SetImmediate((() => {
          this.onNewFrameGraphAddedObservable.notifyObservers(OO)
        }))
      }
      addObjectRenderer(OO) {
        this.objectRenderers.push(OO), bK.c.SetImmediate((() => {
          this.onNewObjectRendererAddedObservable.notifyObservers(OO)
        }))
      }
      addPostProcess(OO) {
        this._blockEntityCollection || (this.postProcesses.push(OO), bK.c.SetImmediate((() => {
          this.onNewPostProcessAddedObservable.notifyObservers(OO)
        })))
      }
      addEffectLayer(OO) {
        this._blockEntityCollection || (this.effectLayers.push(OO), bK.c.SetImmediate((() => {
          this.onNewEffectLayerAddedObservable.notifyObservers(OO)
        })))
      }
      switchActiveCamera(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        this._engine.getInputElement() && (this.activeCamera && this.activeCamera.detachControl(), this.activeCamera = OO, KO && OO.attachControl())
      }
      setActiveCameraById(OO) {
        const KO = this.getCameraById(OO);
        return KO ? (this.activeCamera = KO, KO) : null
      }
      setActiveCameraByName(OO) {
        const KO = this.getCameraByName(OO);
        return KO ? (this.activeCamera = KO, KO) : null
      }
      getAnimationGroupByName(OO) {
        for (let KO = 0; KO < this.animationGroups.length; KO++)
          if (this.animationGroups[KO].name === OO) return this.animationGroups[KO];
        return null
      }
      _getMaterial(OO, KO) {
        for (let pO = 0; pO < this.materials.length; pO++) {
          const OO = this.materials[pO];
          if (KO(OO)) return OO
        }
        if (OO)
          for (let pO = 0; pO < this.multiMaterials.length; pO++) {
            const OO = this.multiMaterials[pO];
            if (KO(OO)) return OO
          }
        return null
      }
      getMaterialByUniqueID(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return this.getMaterialByUniqueId(OO, KO)
      }
      getMaterialByUniqueId(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return this._getMaterial(KO, (KO => KO.uniqueId === OO))
      }
      getMaterialById(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return this._getMaterial(KO, (KO => KO.id === OO))
      }
      getMaterialByName(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return this._getMaterial(KO, (KO => KO.name === OO))
      }
      getLastMaterialById(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        for (let pO = this.materials.length - 1; pO >= 0; pO--)
          if (this.materials[pO].id === OO) return this.materials[pO];
        if (KO)
          for (let pO = this.multiMaterials.length - 1; pO >= 0; pO--)
            if (this.multiMaterials[pO].id === OO) return this.multiMaterials[pO];
        return null
      }
      getTextureByUniqueId(OO) {
        for (let KO = 0; KO < this.textures.length; KO++)
          if (this.textures[KO].uniqueId === OO) return this.textures[KO];
        return null
      }
      getTextureByName(OO) {
        for (let KO = 0; KO < this.textures.length; KO++)
          if (this.textures[KO].name === OO) return this.textures[KO];
        return null
      }
      getCameraById(OO) {
        for (let KO = 0; KO < this.cameras.length; KO++)
          if (this.cameras[KO].id === OO) return this.cameras[KO];
        return null
      }
      getCameraByUniqueId(OO) {
        for (let KO = 0; KO < this.cameras.length; KO++)
          if (this.cameras[KO].uniqueId === OO) return this.cameras[KO];
        return null
      }
      getCameraByName(OO) {
        for (let KO = 0; KO < this.cameras.length; KO++)
          if (this.cameras[KO].name === OO) return this.cameras[KO];
        return null
      }
      getBoneById(OO) {
        for (let KO = 0; KO < this.skeletons.length; KO++) {
          const pO = this.skeletons[KO];
          for (let KO = 0; KO < pO.bones.length; KO++)
            if (pO.bones[KO].id === OO) return pO.bones[KO]
        }
        return null
      }
      getBoneByName(OO) {
        for (let KO = 0; KO < this.skeletons.length; KO++) {
          const pO = this.skeletons[KO];
          for (let KO = 0; KO < pO.bones.length; KO++)
            if (pO.bones[KO].name === OO) return pO.bones[KO]
        }
        return null
      }
      getLightByName(OO) {
        for (let KO = 0; KO < this.lights.length; KO++)
          if (this.lights[KO].name === OO) return this.lights[KO];
        return null
      }
      getLightById(OO) {
        for (let KO = 0; KO < this.lights.length; KO++)
          if (this.lights[KO].id === OO) return this.lights[KO];
        return null
      }
      getLightByUniqueId(OO) {
        for (let KO = 0; KO < this.lights.length; KO++)
          if (this.lights[KO].uniqueId === OO) return this.lights[KO];
        return null
      }
      getParticleSystemById(OO) {
        for (let KO = 0; KO < this.ku.length; KO++)
          if (this.ku[KO].id === OO) return this.ku[KO];
        return null
      }
      getGeometryById(OO) {
        for (let KO = 0; KO < this.geometries.length; KO++)
          if (this.geometries[KO].id === OO) return this.geometries[KO];
        return null
      }
      _getGeometryByUniqueId(OO) {
        if (this._geometriesByUniqueId) {
          const KO = this._geometriesByUniqueId[OO];
          if (void 0 !== KO) return this.geometries[KO]
        } else
          for (let KO = 0; KO < this.geometries.length; KO++)
            if (this.geometries[KO].uniqueId === OO) return this.geometries[KO];
        return null
      }
      getFrameGraphByName(OO) {
        for (let KO = 0; KO < this.frameGraphs.length; KO++)
          if (this.frameGraphs[KO].name === OO) return this.frameGraphs[KO];
        return null
      }
      pushGeometry(OO, KO) {
        return !(!KO && this._getGeometryByUniqueId(OO.uniqueId)) && (this.addGeometry(OO), bK.c.SetImmediate((() => {
          this.onNewGeometryAddedObservable.notifyObservers(OO)
        })), !0)
      }
      removeGeometry(OO) {
        let KO;
        if (this._geometriesByUniqueId) {
          if (KO = this._geometriesByUniqueId[OO.uniqueId], void 0 === KO) return !1
        } else if (KO = this.geometries.indexOf(OO), KO < 0) return !1;
        if (KO !== this.geometries.length - 1) {
          const OO = this.geometries[this.geometries.length - 1];
          OO && (this.geometries[KO] = OO, this._geometriesByUniqueId && (this._geometriesByUniqueId[OO.uniqueId] = KO))
        }
        return this._geometriesByUniqueId && (this._geometriesByUniqueId[OO.uniqueId] = void 0), this.geometries.pop(), this.onGeometryRemovedObservable.notifyObservers(OO), !0
      }
      getGeometries() {
        return this.geometries
      }
      getMeshById(OO) {
        for (let KO = 0; KO < this.meshes.length; KO++)
          if (this.meshes[KO].id === OO) return this.meshes[KO];
        return null
      }
      getMeshesById(OO) {
        return this.meshes.filter((function(KO) {
          return KO.id === OO
        }))
      }
      getTransformNodeById(OO) {
        for (let KO = 0; KO < this.transformNodes.length; KO++)
          if (this.transformNodes[KO].id === OO) return this.transformNodes[KO];
        return null
      }
      getTransformNodeByUniqueId(OO) {
        for (let KO = 0; KO < this.transformNodes.length; KO++)
          if (this.transformNodes[KO].uniqueId === OO) return this.transformNodes[KO];
        return null
      }
      getTransformNodesById(OO) {
        return this.transformNodes.filter((function(KO) {
          return KO.id === OO
        }))
      }
      getMeshByUniqueId(OO) {
        for (let KO = 0; KO < this.meshes.length; KO++)
          if (this.meshes[KO].uniqueId === OO) return this.meshes[KO];
        return null
      }
      getLastMeshById(OO) {
        for (let KO = this.meshes.length - 1; KO >= 0; KO--)
          if (this.meshes[KO].id === OO) return this.meshes[KO];
        return null
      }
      getLastTransformNodeById(OO) {
        for (let KO = this.transformNodes.length - 1; KO >= 0; KO--)
          if (this.transformNodes[KO].id === OO) return this.transformNodes[KO];
        return null
      }
      getLastEntryById(OO) {
        let KO;
        for (KO = this.meshes.length - 1; KO >= 0; KO--)
          if (this.meshes[KO].id === OO) return this.meshes[KO];
        for (KO = this.transformNodes.length - 1; KO >= 0; KO--)
          if (this.transformNodes[KO].id === OO) return this.transformNodes[KO];
        for (KO = this.cameras.length - 1; KO >= 0; KO--)
          if (this.cameras[KO].id === OO) return this.cameras[KO];
        for (KO = this.lights.length - 1; KO >= 0; KO--)
          if (this.lights[KO].id === OO) return this.lights[KO];
        for (KO = this.skeletons.length - 1; KO >= 0; KO--) {
          const pO = this.skeletons[KO];
          for (let KO = pO.bones.length - 1; KO >= 0; KO--)
            if (pO.bones[KO].id === OO) return pO.bones[KO]
        }
        return null
      }
      getNodeById(OO) {
        const KO = this.getMeshById(OO);
        if (KO) return KO;
        const pO = this.getTransformNodeById(OO);
        if (pO) return pO;
        const XO = this.getLightById(OO);
        if (XO) return XO;
        const bK = this.getCameraById(OO);
        if (bK) return bK;
        const eO = this.getBoneById(OO);
        return eO || null
      }
      getNodeByName(OO) {
        const KO = this.getMeshByName(OO);
        if (KO) return KO;
        const pO = this.getTransformNodeByName(OO);
        if (pO) return pO;
        const XO = this.getLightByName(OO);
        if (XO) return XO;
        const bK = this.getCameraByName(OO);
        if (bK) return bK;
        const eO = this.getBoneByName(OO);
        return eO || null
      }
      getMeshByName(OO) {
        for (let KO = 0; KO < this.meshes.length; KO++)
          if (this.meshes[KO].name === OO) return this.meshes[KO];
        return null
      }
      getTransformNodeByName(OO) {
        for (let KO = 0; KO < this.transformNodes.length; KO++)
          if (this.transformNodes[KO].name === OO) return this.transformNodes[KO];
        return null
      }
      getLastSkeletonById(OO) {
        for (let KO = this.skeletons.length - 1; KO >= 0; KO--)
          if (this.skeletons[KO].id === OO) return this.skeletons[KO];
        return null
      }
      getSkeletonByUniqueId(OO) {
        for (let KO = 0; KO < this.skeletons.length; KO++)
          if (this.skeletons[KO].uniqueId === OO) return this.skeletons[KO];
        return null
      }
      getSkeletonById(OO) {
        for (let KO = 0; KO < this.skeletons.length; KO++)
          if (this.skeletons[KO].id === OO) return this.skeletons[KO];
        return null
      }
      getSkeletonByName(OO) {
        for (let KO = 0; KO < this.skeletons.length; KO++)
          if (this.skeletons[KO].name === OO) return this.skeletons[KO];
        return null
      }
      getMorphTargetManagerById(OO) {
        for (let KO = 0; KO < this.morphTargetManagers.length; KO++)
          if (this.morphTargetManagers[KO].uniqueId === OO) return this.morphTargetManagers[KO];
        return null
      }
      getMorphTargetById(OO) {
        for (let KO = 0; KO < this.morphTargetManagers.length; ++KO) {
          const pO = this.morphTargetManagers[KO];
          for (let KO = 0; KO < pO.numTargets; ++KO) {
            const XO = pO.getTarget(KO);
            if (XO.id === OO) return XO
          }
        }
        return null
      }
      getMorphTargetByName(OO) {
        for (let KO = 0; KO < this.morphTargetManagers.length; ++KO) {
          const pO = this.morphTargetManagers[KO];
          for (let KO = 0; KO < pO.numTargets; ++KO) {
            const XO = pO.getTarget(KO);
            if (XO.name === OO) return XO
          }
        }
        return null
      }
      getPostProcessByName(OO) {
        for (let KO = 0; KO < this.postProcesses.length; ++KO) {
          const pO = this.postProcesses[KO];
          if (pO.name === OO) return pO
        }
        return null
      }
      isActiveMesh(OO) {
        return -1 !== this._activeMeshes.indexOf(OO)
      }
      get uid() {
        return this._uid || (this._uid = XO.k.RandomId()), this._uid
      }
      addExternalData(OO, KO) {
        return this._externalData || (this._externalData = new CO), this._externalData.add(OO, KO)
      }
      getExternalData(OO) {
        return this._externalData ? this._externalData.get(OO) : null
      }
      getOrAddExternalDataWithFactory(OO, KO) {
        return this._externalData || (this._externalData = new CO), this._externalData.getOrAddWithFactory(OO, KO)
      }
      removeExternalData(OO) {
        return this._externalData.remove(OO)
      }
      _evaluateSubMesh(OO, KO, pO, XO) {
        if (XO || OO.isInFrustum(this._frustumPlanes)) {
          for (let XO = 0, bK = this._evaluateSubMeshStage; XO < bK.length; XO++) {
            bK[XO].action(KO, OO)
          }
          const pO = OO.UX();
          null !== pO && void 0 !== pO && (pO.hasRenderTargetTextures && null != pO.getRenderTargetTextures && -1 === this._processedMaterials.indexOf(pO) && (this._processedMaterials.push(pO), this._materialsRenderTargets.concatWithNoDuplicate(pO.getRenderTargetTextures())), this._renderingManager.dispatch(OO, KO, pO))
        }
      }
      freeProcessedMaterials() {
        this._processedMaterials.dispose()
      }
      get blockfreeActiveMeshesAndRenderingGroups() {
        return this._preventFreeActiveMeshesAndRenderingGroups
      }
      set blockfreeActiveMeshesAndRenderingGroups(OO) {
        this._preventFreeActiveMeshesAndRenderingGroups !== OO && (OO && (this.freeActiveMeshes(), this.freeRenderingGroups()), this._preventFreeActiveMeshesAndRenderingGroups = OO)
      }
      freeActiveMeshes() {
        if (!this.blockfreeActiveMeshesAndRenderingGroups && (this._activeMeshes.dispose(), this.activeCamera && this.activeCamera._activeMeshes && this.activeCamera._activeMeshes.dispose(), this.activeCameras))
          for (let OO = 0; OO < this.activeCameras.length; OO++) {
            const KO = this.activeCameras[OO];
            KO && KO._activeMeshes && KO._activeMeshes.dispose()
          }
      }
      freeRenderingGroups() {
        if (!this.blockfreeActiveMeshesAndRenderingGroups && (this._renderingManager && this._renderingManager.freeRenderingGroups(), this.textures))
          for (let OO = 0; OO < this.textures.length; OO++) {
            const KO = this.textures[OO];
            KO && KO.renderList && KO.freeRenderingGroups()
          }
      }
      _isInIntermediateRendering() {
        return this._intermediateRendering
      }
      _isInRenderingMeshEvaluation() {
        return this._renderingMeshEvaluationDepth > 0
      }
      freezeActiveMeshes() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
          eO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        if (this.frameGraph) {
          this._renderWithFrameGraph(!0, !1, !0);
          const lO = this.frameGraph.getTasksByClassName(["FrameGraphObjectRendererTask", "FrameGraphGeometryRendererTask"]);
          for (const OO of lO) OO.objectRenderer._freezeActiveMeshes(XO);
          return this._freezeActiveMeshesCancel = (0, bK.e)((() => {
            let OO = !0,
              KO = !0;
            for (const pO of lO) OO && (OO = pO.objectRenderer._isFrozen), KO && (KO = null !== pO.objectRenderer._freezeActiveMeshesCancel);
            if (OO) return !0;
            if (!KO) throw new Error("Freezing active meshes was cancelled");
            return !1
          }), (() => {
            this._freezeActiveMeshesCancel = null, this._activeMeshesFrozen = !0, this._activeMeshesFrozenButKeepClipping = eO, this._skipEvaluateActiveMeshesCompletely = OO, KO?.()
          }), ((OO, KO) => {
            if (this._freezeActiveMeshesCancel = null, this.unfreezeActiveMeshes(), KO) {
              const KO = "Scene: Timeout while waiting for meshes to be frozen.";
              pO ? pO(KO) : (Op.b.Error(KO), OO && Op.b.Error(OO))
            } else {
              const KO = "Scene: An unexpected error occurred while trying to freeze active meshes.";
              pO ? pO(KO) : (Op.b.Error(KO), OO && (Op.b.Error(OO), OO.stack && Op.b.Error(OO.stack)))
            }
          })), this
        }
        return this.executeWhenReady((() => {
          if (this.activeCamera) {
            if (this._frustumPlanes || this.updateTransformMatrix(), this._evaluateActiveMeshes(), this._activeMeshesFrozen = !0, this._activeMeshesFrozenButKeepClipping = eO, this._skipEvaluateActiveMeshesCompletely = OO, XO)
              for (let OO = 0; OO < this._activeMeshes.length; OO++) this._activeMeshes.data[OO]._freeze();
            KO && KO()
          } else pO && pO("No active camera found")
        })), this
      }
      unfreezeActiveMeshes() {
        for (let OO = 0; OO < this.meshes.length; OO++) {
          const KO = this.meshes[OO];
          KO._internalAbstractMeshDataInfo && (KO._internalAbstractMeshDataInfo._isActive = !1)
        }
        if (this._freezeActiveMeshesCancel?.(), this._freezeActiveMeshesCancel = null, this.frameGraph) {
          const OO = this.frameGraph.getTasksByClassName(["FrameGraphObjectRendererTask", "FrameGraphGeometryRendererTask"]);
          for (const KO of OO) KO.objectRenderer._unfreezeActiveMeshes()
        } else
          for (let OO = 0; OO < this._activeMeshes.length; OO++) this._activeMeshes.data[OO]._unFreeze();
        return this._activeMeshesFrozen = !1, this
      }
      _executeActiveContainerCleanup(OO) {
        (!this._engine.snapshotRendering || 1 !== this._engine.snapshotRenderingMode) && this._activeMeshesFrozen && this._activeMeshes.length || this.onBeforeRenderObservable.addOnce((() => OO.dispose()))
      }
      _evaluateActiveMeshes() {
        if (this._engine.snapshotRendering && 1 === this._engine.snapshotRenderingMode) return void(this._activeMeshes.length > 0 && (this.activeCamera?._activeMeshes.reset(), this._activeMeshes.reset(), this._renderingManager.reset(), this._processedMaterials.reset(), this._activeParticleSystems.reset(), this._activeSkeletons.reset(), this._softwareSkinnedMeshes.reset()));
        if (this._activeMeshesFrozen && this._activeMeshes.length) {
          if (!this._skipEvaluateActiveMeshesCompletely) {
            const OO = this._activeMeshes.length;
            for (let KO = 0; KO < OO; KO++) {
              this._activeMeshes.data[KO].computeWorldMatrix()
            }
          }
          if (this._activeParticleSystems) {
            const OO = this._activeParticleSystems.length;
            for (let KO = 0; KO < OO; KO++) this._activeParticleSystems.data[KO].animate()
          }
          return void this._renderingManager.resetSprites()
        }
        if (!this.activeCamera) return;
        this.onBeforeActiveMeshesEvaluationObservable.notifyObservers(this), this.activeCamera._activeMeshes.reset(), this._activeMeshes.reset(), this._renderingManager.reset(), this._processedMaterials.reset(), this._activeParticleSystems.reset(), this._activeSkeletons.reset(), this._softwareSkinnedMeshes.reset(), this._materialsRenderTargets.reset();
        for (let bK = 0, eO = this._beforeEvaluateActiveMeshStage; bK < eO.length; bK++) {
          eO[bK].action()
        }
        const OO = this.getActiveMeshCandidates(),
          KO = OO.length,
          pO = ZO.c.Enabled,
          XO = this.customLODSelector;
        for (let bK = 0; bK < KO; bK++) {
          const KO = OO.data[bK],
            eO = !XO && !KO.BKO && !KO._internalMeshDataInfo?._LODLevels.length;
          let lO, vK;
          if ((eO || (lO = KO._internalAbstractMeshDataInfo._currentLOD.get(this.activeCamera), lO ? lO[1] = -1 : (lO = [KO, -1], KO._internalAbstractMeshDataInfo._currentLOD.set(this.activeCamera, lO))), !KO.isBlocked) && (pO && this._totalVertices.addCount(KO.getTotalVertices(), !1), KO.isReady() && KO.isEnabled() && !KO.ol.hasAZeroComponent)) {
            if (KO.computeWorldMatrix(), KO.actionManager && KO.actionManager.hasSpecificTriggers2(12, 13) && this._meshesForIntersections.pushNoDuplicate(KO), eO) vK = KO;
            else if (vK = XO ? XO(KO, this.activeCamera) : KO.getLOD(this.activeCamera), lO[0] = vK, lO[1] = this._frameId, void 0 === vK || null === vK) continue;
            if (vK !== KO && 0 !== vK.billboardMode && vK.computeWorldMatrix(), KO._preActivate(), KO.isVisible && KO.visibility > 0 && 0 !== (KO.layerMask & this.activeCamera.layerMask) && (this._skipFrustumClipping || KO.xb || KO.isInFrustum(this._frustumPlanes))) {
              this._activeMeshes.push(KO), this.activeCamera._activeMeshes.push(KO), vK !== KO && vK._activate(this._renderId, !1);
              for (let OO = 0, pO = this._preActiveMeshStage; OO < pO.length; OO++) {
                pO[OO].action(KO)
              }
              KO._activate(this._renderId, !1) && (KO.BKO ? KO._internalAbstractMeshDataInfo._actAsRegularMesh && (vK = KO) : vK._internalAbstractMeshDataInfo._onlyForInstances = !1, vK._internalAbstractMeshDataInfo._isActive = !0, this._activeMesh(KO, vK)), KO._postActivate()
            }
          }
        }
        if (this.onAfterActiveMeshesEvaluationObservable.notifyObservers(this), this.particlesEnabled) {
          this.onBeforeParticlesRenderingObservable.notifyObservers(this);
          for (let OO = 0; OO < this.ku.length; OO++) {
            const KO = this.ku[OO];
            if (!KO.isStarted() || !KO.emitter) continue;
            const pO = KO.emitter;
            pO.position && !pO.isEnabled() || (this._activeParticleSystems.push(KO), KO.animate(), this._renderingManager.dispatchParticles(KO))
          }
          this.onAfterParticlesRenderingObservable.notifyObservers(this)
        }
      }
      _prepareSkeleton(OO) {
        this._skeletonsEnabled && OO.skeleton && (this._activeSkeletons.pushNoDuplicate(OO.skeleton) && (OO.skeleton.prepare(), this._activeBones.addCount(OO.skeleton.bones.length, !1)), OO.computeBonesUsingShaders || this._softwareSkinnedMeshes.pushNoDuplicate(OO) && this.frameGraph && OO.applySkeleton(OO.skeleton))
      }
      _activeMesh(OO, KO) {
        this._prepareSkeleton(KO);
        let pO = OO.RDO || OO.BKO || this.dispatchAllSubMeshesOfActiveMeshes || this._skipFrustumClipping || KO.xb;
        if (KO && KO.au && KO.au.length > 0) {
          const XO = this.getActiveSubMeshCandidates(KO),
            bK = XO.length;
          pO = pO || 1 === bK;
          for (let eO = 0; eO < bK; eO++) {
            const bK = XO.data[eO];
            this._evaluateSubMesh(bK, KO, OO, pO)
          }
        }
      }
      updateTransformMatrix(OO) {
        const KO = this.activeCamera;
        if (KO)
          if (KO._renderingMultiview) {
            const pO = KO._rigCameras[0],
              XO = KO._rigCameras[1];
            this.setTransformMatrix(pO.getViewMatrix(), pO.getProjectionMatrix(OO), XO.getViewMatrix(), XO.getProjectionMatrix(OO))
          } else this.setTransformMatrix(KO.getViewMatrix(), KO.getProjectionMatrix(OO))
      }
      _bindFrameBuffer(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        this._useCurrentFrameBuffer || (OO && OO._multiviewTexture ? OO._multiviewTexture._bindFrameBuffer() : OO && OO.outputRenderTarget ? OO.outputRenderTarget._bindFrameBuffer() : this._engine._currentFrameBufferIsDefaultFrameBuffer() || this._engine.restoreDefaultFramebuffer()), KO && this._clearFrameBuffer(OO)
      }
      _clearFrameBuffer(OO) {
        if (OO && OO._multiviewTexture);
        else if (OO && OO.outputRenderTarget && !OO._renderingMultiview) {
          const KO = OO.outputRenderTarget;
          KO.onClearObservable.hasObservers() ? KO.onClearObservable.notifyObservers(this._engine) : KO.skipInitialClear || OO.isRightCamera || (this.autoClear && this._engine.clear(KO.clearColor || this._clearColor, !KO._cleared, !0, !0), KO._cleared = !0)
        } else this._defaultFrameBufferCleared ? this._engine.clear(null, !1, !0, !0) : (this._defaultFrameBufferCleared = !0, this._clear())
      }
      _renderForCamera(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        if (OO && OO._skipRendering) return;
        const bK = this._engine;
        if (this._activeCamera = OO, !this.activeCamera) throw new Error("Active camera not set");
        if (bK.setViewport(this.activeCamera.viewport), this.resetCachedMaterial(), this._renderId++, !this.prePass && pO) {
          let KO = !0;
          OO._renderingMultiview && OO.outputRenderTarget && (KO = OO.outputRenderTarget.skipInitialClear, this.autoClear && (this._defaultFrameBufferCleared = !1, OO.outputRenderTarget.skipInitialClear = !1)), this._bindFrameBuffer(this._activeCamera), OO._renderingMultiview && OO.outputRenderTarget && (OO.outputRenderTarget.skipInitialClear = KO)
        }
        this.updateTransformMatrix(), this.onBeforeCameraRenderObservable.notifyObservers(this.activeCamera), this._engine.currentRenderPassId = OO.outputRenderTarget?.renderPassId ?? OO.renderPassId ?? 0, this._evaluateActiveMeshes();
        for (let XO = 0; XO < this._softwareSkinnedMeshes.length; XO++) {
          const OO = this._softwareSkinnedMeshes.data[XO];
          OO.applySkeleton(OO.skeleton)
        }
        this.onBeforeRenderTargetsRenderObservable.notifyObservers(this), this._renderTargets.concatWithNoDuplicate(this._materialsRenderTargets), OO.customRenderTargets && OO.customRenderTargets.length > 0 && this._renderTargets.concatWithNoDuplicate(OO.customRenderTargets), KO && KO.customRenderTargets && KO.customRenderTargets.length > 0 && this._renderTargets.concatWithNoDuplicate(KO.customRenderTargets), this.environmentTexture && this.environmentTexture.isRenderTarget && this._renderTargets.pushNoDuplicate(this.environmentTexture);
        for (let XO = 0, vK = this._gatherActiveCameraRenderTargetsStage; XO < vK.length; XO++) {
          vK[XO].action(this._renderTargets)
        }
        let eO = !1;
        if (this.renderTargetsEnabled) {
          let OO;
          if (this._intermediateRendering = !0, this._renderTargets.length > 0) {
            XO.k.StartPerformanceCounter("Render targets", this._renderTargets.length > 0);
            const KO = this.getBoundingBoxRenderer?.();
            for (let pO = 0; pO < this._renderTargets.length; pO++) {
              const XO = this._renderTargets.data[pO];
              if (XO._shouldRender()) {
                this._renderId++;
                const pO = XO.activeCamera && XO.activeCamera !== this.activeCamera;
                KO && !OO && (OO = KO.renderList.length > 0 ? KO.renderList.data.slice() : [], OO.length = KO.renderList.length), XO.render(pO, this.dumpNextRenderTargets), eO = !0
              }
            }
            KO && OO && (KO.renderList.data = OO, KO.renderList.length = OO.length), XO.k.EndPerformanceCounter("Render targets", this._renderTargets.length > 0), this._renderId++
          }
          if (this._cameraDrawRenderTargetStage.length > 0) {
            const KO = this.getBoundingBoxRenderer?.();
            KO && !OO && (OO = KO.renderList.length > 0 ? KO.renderList.data.slice() : [], OO.length = KO.renderList.length);
            for (let OO = 0, pO = this._cameraDrawRenderTargetStage; OO < pO.length; OO++) {
              eO = pO[OO].action(this.activeCamera) || eO
            }
            KO && OO && (KO.renderList.data = OO, KO.renderList.length = OO.length)
          }
          this._intermediateRendering = !1
        }
        eO && !this.prePass && (this._bindFrameBuffer(this._activeCamera, !1), this.updateTransformMatrix()), this.onAfterRenderTargetsRenderObservable.notifyObservers(this), !this.postProcessManager || OO._multiviewTexture || this.prePass || this.postProcessManager._prepareFrame();
        for (let XO = 0, vK = this._beforeCameraDrawStage; XO < vK.length; XO++) {
          vK[XO].action(this.activeCamera)
        }
        this.onBeforeDrawPhaseObservable.notifyObservers(this);
        const lO = bK.snapshotRendering && 1 === bK.snapshotRenderingMode;
        lO && this.finalizeSceneUbo(), this._renderingManager.render(null, null, !0, !lO), this.onAfterDrawPhaseObservable.notifyObservers(this);
        for (let XO = 0, vK = this._afterCameraDrawStage; XO < vK.length; XO++) {
          vK[XO].action(this.activeCamera)
        }
        if (this.postProcessManager && !OO._multiviewTexture) {
          const KO = OO.outputRenderTarget ? OO.outputRenderTarget.renderTarget : void 0;
          this.postProcessManager._finalizeFrame(OO.isIntermediate, KO)
        }
        for (let XO = 0, vK = this._afterCameraPostProcessStage; XO < vK.length; XO++) {
          vK[XO].action(this.activeCamera)
        }
        this._renderTargets.reset(), this.onAfterCameraRenderObservable.notifyObservers(this.activeCamera)
      }
      _processSubCameras(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (0 === OO.cameraRigMode || OO._renderingMultiview) return OO._renderingMultiview && !this._multiviewSceneUbo && this._createMultiviewUbo(), this._renderForCamera(OO, void 0, KO), void this.onAfterRenderCameraObservable.notifyObservers(OO);
        if (OO._useMultiviewToSingleView) this._renderMultiviewToSingleView(OO);
        else {
          this.onBeforeCameraRenderObservable.notifyObservers(OO);
          for (let KO = 0; KO < OO._rigCameras.length; KO++) this._renderForCamera(OO._rigCameras[KO], OO)
        }
        this._activeCamera = OO, this.updateTransformMatrix(), this.onAfterRenderCameraObservable.notifyObservers(OO)
      }
      _checkIntersections() {
        for (let OO = 0; OO < this._meshesForIntersections.length; OO++) {
          const KO = this._meshesForIntersections.data[OO];
          if (KO.actionManager)
            for (let OO = 0; KO.actionManager && OO < KO.actionManager.actions.length; OO++) {
              const pO = KO.actionManager.actions[OO];
              if (12 === pO.trigger || 13 === pO.trigger) {
                const OO = pO.getTriggerParameter(),
                  XO = OO.mesh ? OO.mesh : OO,
                  bK = XO.iMO(KO, OO.usePreciseIntersection),
                  eO = KO._intersectionsInProgress.indexOf(XO);
                bK && -1 === eO ? 12 === pO.trigger ? (pO._executeCurrent(FO.CreateNew(KO, void 0, XO)), KO._intersectionsInProgress.push(XO)) : 13 === pO.trigger && KO._intersectionsInProgress.push(XO) : !bK && eO > -1 && (13 === pO.trigger && pO._executeCurrent(FO.CreateNew(KO, void 0, XO)), KO.actionManager.hasSpecificTrigger(13, (OO => {
                  const KO = OO.mesh ? OO.mesh : OO;
                  return XO === KO
                })) && 13 !== pO.trigger || KO._intersectionsInProgress.splice(eO, 1))
              }
            }
        }
      }
      _advancePhysicsEngineStep(OO) {}
      _animate(OO) {}
      animate() {
        if (this._engine.isDeterministicLockStep()) {
          let OO = Math.max(ep.MinDeltaTime, Math.min(this._engine.getDeltaTime(), ep.MaxDeltaTime)) + this._timeAccumulator;
          const KO = this._engine.getTimeStep(),
            pO = 1e3 / KO / 1e3;
          let XO = 0;
          const bK = this._engine.getLockstepMaxSteps();
          let eO = Math.floor(OO / KO);
          for (eO = Math.min(eO, bK); OO > 0 && XO < eO;) this.onBeforeStepObservable.notifyObservers(this), this._animationRatio = KO * pO, this._animate(KO), this.onAfterAnimationsObservable.notifyObservers(this), this.RpO && this._advancePhysicsEngineStep(KO), this.onAfterStepObservable.notifyObservers(this), this._currentStepId++, XO++, OO -= KO;
          this._timeAccumulator = OO < 0 ? 0 : OO
        } else {
          const OO = this.useConstantAnimationDeltaTime ? 16 : Math.max(ep.MinDeltaTime, Math.min(this._engine.getDeltaTime(), ep.MaxDeltaTime));
          this._animationRatio = .06 * OO, this._animate(), this.onAfterAnimationsObservable.notifyObservers(this), this.RpO && this._advancePhysicsEngineStep(OO)
        }
      }
      _clear() {
        (this.autoClearDepthAndStencil || this.autoClear) && this._engine.clear(this._clearColor, this.autoClear || this.forceWireframe || this.forcePointsCloud, this.autoClearDepthAndStencil, this.autoClearDepthAndStencil)
      }
      _checkCameraRenderTarget(OO) {
        if (OO?.outputRenderTarget && !OO?.isRigCamera && (OO.outputRenderTarget._cleared = !1), OO?.rigCameras?.length)
          for (let KO = 0; KO < OO.rigCameras.length; ++KO) {
            const pO = OO.rigCameras[KO].outputRenderTarget;
            pO && (pO._cleared = !1)
          }
      }
      resetDrawCache(OO) {
        if (this.meshes)
          for (const KO of this.meshes) KO.resetDrawCache(OO)
      }
      _renderWithFrameGraph() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
          KO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (this.activeCamera = null, this.activeCameras = null, OO)
          for (const pO of this.cameras)
            if (pO.update(), 0 !== pO.cameraRigMode)
              for (let OO = 0; OO < pO._rigCameras.length; OO++) pO._rigCameras[OO].update();
        this.onBeforeRenderObservable.notifyObservers(this), this._renderingMeshEvaluationDepth++;
        try {
          this._renderWithFrameGraphAfterBeforeRender(KO)
        } finally {
          this._renderingMeshEvaluationDepth--
        }
      }
      _renderWithFrameGraphAfterBeforeRender(OO) {
        this.onBeforeRenderTargetsRenderObservable.notifyObservers(this), this._renderTargets.reset();
        const KO = this._frameGraph?.findMainCamera() ?? null;
        if (this.renderTargetsEnabled) {
          this.environmentTexture && this.environmentTexture.isRenderTarget && this._renderTargets.pushNoDuplicate(this.environmentTexture), this._renderTargets.concatWithNoDuplicate(this.customRenderTargets), XO.k.StartPerformanceCounter("Custom render targets", this._renderTargets.length > 0);
          for (let OO = 0; OO < this._renderTargets.length; OO++) {
            const pO = this._renderTargets.data[OO],
              XO = pO.activeCamera || KO;
            this._renderRenderTarget(pO, XO, !0, this.dumpNextRenderTargets)
          }
          XO.k.EndPerformanceCounter("Custom render targets", this._renderTargets.length > 0), this._renderId++
        }
        this.onAfterRenderTargetsRenderObservable.notifyObservers(this);
        for (let pO = 0, XO = this._beforeClearStage; pO < XO.length; pO++) {
          XO[pO].action()
        }
        if (this._engine.snapshotRendering && 1 === this._engine.snapshotRenderingMode) this._activeParticleSystems.reset(), this._activeSkeletons.reset(), this._softwareSkinnedMeshes.reset();
        else {
          const KO = this.getActiveMeshCandidates(),
            pO = KO.length;
          if (this._activeMeshesFrozen) {
            if (!this._skipEvaluateActiveMeshesCompletely)
              for (let OO = 0; OO < pO; OO++) {
                const pO = KO.data[OO];
                pO._internalAbstractMeshDataInfo._wasActiveLastFrame && pO.computeWorldMatrix()
              }
            if (this.particlesEnabled) {
              const OO = this._activeParticleSystems.length;
              for (let KO = 0; KO < OO; KO++) this._activeParticleSystems.data[KO].animate()
            }
          } else {
            this._activeParticleSystems.reset(), this._activeSkeletons.reset(), this._softwareSkinnedMeshes.reset();
            for (let XO = 0; XO < pO; XO++) {
              const pO = KO.data[XO];
              pO._internalAbstractMeshDataInfo._wasActiveLastFrame = !1, pO.isBlocked || (this._totalVertices.addCount(pO.getTotalVertices(), !1), pO.isReady() && pO.isEnabled() && !pO.ol.hasAZeroComponent && (pO.computeWorldMatrix(OO), pO.actionManager && pO.actionManager.hasSpecificTriggers2(12, 13) && this._meshesForIntersections.pushNoDuplicate(pO)))
            }
            if (this.particlesEnabled)
              for (let OO = 0; OO < this.ku.length; OO++) {
                const KO = this.ku[OO];
                if (!KO.isStarted() || !KO.emitter) continue;
                const pO = KO.emitter;
                pO.position && !pO.isEnabled() || (this._activeParticleSystems.push(KO), KO.animate())
              }
          }
        }
        this.frameGraph?.execute()
      }
      _renderRenderTarget(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        if (this._intermediateRendering = !0, OO._shouldRender()) {
          if (this._renderId++, this.activeCamera = KO, !this.activeCamera) throw new Error("Active camera not set");
          this._engine.setViewport(this.activeCamera.viewport), this.updateTransformMatrix(), OO.render(pO, XO)
        }
        this._intermediateRendering = !1
      }
      render() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (this.FhO) return;
        const pO = this._renderingMeshEvaluationDepth;
        try {
          this._renderFrame(OO, KO)
        } finally {
          this._renderingMeshEvaluationDepth = pO
        }
      }
      _renderFrame(OO, KO) {
        if (this.onReadyObservable.hasObservers() && null === this._executeWhenReadyTimeoutId && this._checkIsReady(), LO.c.JKO = this._getFloatingOriginScene, this._frameId++, this._defaultFrameBufferCleared = !1, this._checkCameraRenderTarget(this.activeCamera), this.activeCameras?.length)
          for (const pO of this.activeCameras) this._checkCameraRenderTarget(pO);
        this._registerTransientComponents(), this._activeParticles.fetchNewFrame(), this._totalVertices.fetchNewFrame(), this._activeIndices.fetchNewFrame(), this._activeBones.fetchNewFrame(), this._meshesForIntersections.reset(), this.resetCachedMaterial(), this.onBeforeAnimationsObservable.notifyObservers(this), this.actionManager && this.actionManager.processTrigger(11), KO || this.animate();
        for (let pO = 0, XO = this._beforeCameraUpdateStage; pO < XO.length; pO++) {
          XO[pO].action()
        }
        if (OO)
          if (this.activeCameras && this.activeCameras.length > 0)
            for (let pO = 0; pO < this.activeCameras.length; pO++) {
              const OO = this.activeCameras[pO];
              if (OO.update(), 0 !== OO.cameraRigMode)
                for (let KO = 0; KO < OO._rigCameras.length; KO++) OO._rigCameras[KO].update()
            } else if (this.activeCamera && (this.activeCamera.update(), 0 !== this.activeCamera.cameraRigMode))
              for (let pO = 0; pO < this.activeCamera._rigCameras.length; pO++) this.activeCamera._rigCameras[pO].update();
        if (this.customRenderFunction) this._renderId++, this._engine.currentRenderPassId = 0, this._renderingMeshEvaluationDepth++, this.customRenderFunction(OO, KO);
        else {
          this.onBeforeRenderObservable.notifyObservers(this), this._renderingMeshEvaluationDepth++, this.onBeforeRenderTargetsRenderObservable.notifyObservers(this);
          const OO = this.activeCameras?.length ? this.activeCameras[0] : this.activeCamera;
          if (this.renderTargetsEnabled) {
            XO.k.StartPerformanceCounter("Custom render targets", this.customRenderTargets.length > 0);
            for (let KO = 0; KO < this.customRenderTargets.length; KO++) {
              const pO = this.customRenderTargets[KO],
                XO = pO.activeCamera || this.activeCamera;
              this._renderRenderTarget(pO, XO, OO !== XO, this.dumpNextRenderTargets)
            }
            XO.k.EndPerformanceCounter("Custom render targets", this.customRenderTargets.length > 0), this._renderId++
          }
          this._engine.currentRenderPassId = OO?.renderPassId ?? 0, this.activeCamera = OO, this._activeCamera && 22 !== this._activeCamera.cameraRigMode && !this.prePass && this._bindFrameBuffer(this._activeCamera, !1), this.onAfterRenderTargetsRenderObservable.notifyObservers(this);
          for (let KO = 0, pO = this._beforeClearStage; KO < pO.length; KO++) {
            pO[KO].action()
          }
          this._clearFrameBuffer(this.activeCamera);
          for (let KO = 0, pO = this._gatherRenderTargetsStage; KO < pO.length; KO++) {
            pO[KO].action(this._renderTargets)
          }
          if (this.activeCameras && this.activeCameras.length > 0)
            for (let KO = 0; KO < this.activeCameras.length; KO++) this._processSubCameras(this.activeCameras[KO], KO > 0);
          else {
            if (!this.activeCamera) throw new Error("No camera defined");
            this._processSubCameras(this.activeCamera, !!this.activeCamera.outputRenderTarget)
          }
        }
        this._inputManager._updateMeshUnderPointer(), this._checkIntersections();
        for (let pO = 0, XO = this._afterRenderStage; pO < XO.length; pO++) {
          XO[pO].action()
        }
        if (this.afterRender && this.afterRender(), this.onAfterRenderObservable.notifyObservers(this), this._toBeDisposed.length) {
          for (let OO = 0; OO < this._toBeDisposed.length; OO++) {
            const KO = this._toBeDisposed[OO];
            KO && KO.dispose()
          }
          this._toBeDisposed.length = 0
        }
        this.dumpNextRenderTargets && (this.dumpNextRenderTargets = !1), this._activeBones.addCount(0, !0), this._activeIndices.addCount(0, !0), this._activeParticles.addCount(0, !0), this._engine.restoreDefaultFramebuffer()
      }
      freezeMaterials() {
        for (let OO = 0; OO < this.materials.length; OO++) this.materials[OO].freeze()
      }
      unfreezeMaterials() {
        for (let OO = 0; OO < this.materials.length; OO++) this.materials[OO].unfreeze()
      }
      dispose() {
        if (this.FhO) return;
        if (this._isDisposing = !0, this.beforeRender = null, this.afterRender = null, this.metadata = null, this.skeletons.length = 0, this.morphTargetManagers.length = 0, this._transientComponents.length = 0, this._isReadyForMeshStage.clear(), this._beforeEvaluateActiveMeshStage.clear(), this._evaluateSubMeshStage.clear(), this._preActiveMeshStage.clear(), this._cameraDrawRenderTargetStage.clear(), this._beforeCameraDrawStage.clear(), this._beforeRenderTargetDrawStage.clear(), this._beforeRenderingGroupDrawStage.clear(), this._beforeRenderingMeshStage.clear(), this._afterRenderingMeshStage.clear(), this._afterRenderingGroupDrawStage.clear(), this._afterCameraDrawStage.clear(), this._afterRenderTargetDrawStage.clear(), this._afterRenderStage.clear(), this._beforeCameraUpdateStage.clear(), this._beforeClearStage.clear(), this._gatherRenderTargetsStage.clear(), this._gatherActiveCameraRenderTargetsStage.clear(), this._pointerMoveStage.clear(), this._pointerDownStage.clear(), this._pointerUpStage.clear(), this._isReadyChecks.length = 0, this.importedMeshesFiles = [], this._activeAnimatables && (0, dO.b)(this.stopAllAnimations)) {
          for (const OO of this._activeAnimatables) OO.onAnimationEndObservable.clear(), OO.onAnimationEnd = null;
          this.stopAllAnimations()
        }
        this.resetCachedMaterial(), this.activeCamera && (this.activeCamera._activeMeshes.dispose(), this.activeCamera = null), this.activeCameras = null, this._activeMeshes.dispose(), this._renderingManager.dispose(), this._processedMaterials.dispose(), this._activeParticleSystems.dispose(), this._activeSkeletons.dispose(), this._softwareSkinnedMeshes.dispose(), this._renderTargets.dispose(), this._materialsRenderTargets.dispose(), this._registeredForLateAnimationBindings.dispose(), this._animationWrites.length = 0, this._animationWriteCount = 0, this._animationStepWriteCount = 0, this._meshesForIntersections.dispose(), this._toBeDisposed.length = 0;
        const OO = this._activeRequests.slice();
        for (const eO of OO) eO.abort();
        this._activeRequests.length = 0;
        try {
          this.cpO.notifyObservers(this)
        } catch (bK) {
          Op.b.Error("An error occurred while calling onDisposeObservable!", bK)
        }
        this.detachControl();
        const KO = this._engine.getInputElement?.();
        if (KO)
          for (let eO = 0; eO < this.cameras.length; eO++) this.cameras[eO].detachControl();
        this._disposeList(this.animationGroups), this._disposeList(this.lights), this._defaultMaterial && this._defaultMaterial.dispose(), this._disposeList(this.multiMaterials), this._disposeList(this.materials), this._disposeList(this.meshes, (OO => OO.dispose(!0))), this._disposeList(this.transformNodes, (OO => OO.dispose(!0)));
        const pO = this.cameras;
        this._disposeList(pO), this._disposeList(this.ku), this._disposeList(this.postProcesses), this._disposeList(this.textures), this._disposeList(this.morphTargetManagers), this._disposeList(this.frameGraphs), this._sceneUbo.dispose(), this._multiviewSceneUbo && this._multiviewSceneUbo.dispose(), this.postProcessManager.dispose(), this._disposeList(this._components);
        let XO = this._engine.scenes.indexOf(this);
        if (XO > -1 && this._engine.scenes.splice(XO, 1), this._floatingOriginScene = void 0, 0 === this._engine.scenes.length && (0, LO.h)(), fO.c._LastCreatedScene === this) {
          fO.c._LastCreatedScene = null;
          let OO = fO.c.Instances.length - 1;
          for (; OO >= 0;) {
            const KO = fO.c.Instances[OO];
            if (KO.scenes.length > 0) {
              fO.c._LastCreatedScene = KO.scenes[this._engine.scenes.length - 1];
              break
            }
            OO--
          }
        }
        XO = this._engine._virtualScenes.indexOf(this), XO > -1 && this._engine._virtualScenes.splice(XO, 1), this._engine.wipeCaches(!0), this.cpO.clear(), this.onBeforeRenderObservable.clear(), this.onAfterRenderObservable.clear(), this.onBeforeRenderTargetsRenderObservable.clear(), this.onAfterRenderTargetsRenderObservable.clear(), this.onAfterStepObservable.clear(), this.onBeforeStepObservable.clear(), this.onBeforeActiveMeshesEvaluationObservable.clear(), this.onAfterActiveMeshesEvaluationObservable.clear(), this.onBeforeParticlesRenderingObservable.clear(), this.onAfterParticlesRenderingObservable.clear(), this.onBeforeDrawPhaseObservable.clear(), this.onAfterDrawPhaseObservable.clear(), this.onBeforeAnimationsObservable.clear(), this.onAfterAnimationsObservable.clear(), this.onDataLoadedObservable.clear(), this.onBeforeRenderingGroupObservable.clear(), this.onAfterRenderingGroupObservable.clear(), this.onMeshImportedObservable.clear(), this.onBeforeCameraRenderObservable.clear(), this.onAfterCameraRenderObservable.clear(), this.onAfterRenderCameraObservable.clear(), this.onReadyObservable.clear(), this.onNewCameraAddedObservable.clear(), this.onCameraRemovedObservable.clear(), this.onNewLightAddedObservable.clear(), this.onLightRemovedObservable.clear(), this.onNewGeometryAddedObservable.clear(), this.onGeometryRemovedObservable.clear(), this.onNewTransformNodeAddedObservable.clear(), this.onTransformNodeRemovedObservable.clear(), this.onNewMeshAddedObservable.clear(), this.onMeshRemovedObservable.clear(), this.onNewSkeletonAddedObservable.clear(), this.onSkeletonRemovedObservable.clear(), this.onNewMaterialAddedObservable.clear(), this.onNewMultiMaterialAddedObservable.clear(), this.onMaterialRemovedObservable.clear(), this.onMultiMaterialRemovedObservable.clear(), this.onNewTextureAddedObservable.clear(), this.onTextureRemovedObservable.clear(), this.onNewFrameGraphAddedObservable.clear(), this.onFrameGraphRemovedObservable.clear(), this.onNewObjectRendererAddedObservable.clear(), this.onObjectRendererRemovedObservable.clear(), this.onPrePointerObservable.clear(), this.onPointerObservable.clear(), this.onPreKeyboardObservable.clear(), this.onKeyboardObservable.clear(), this.onActiveCameraChanged.clear(), this.onScenePerformancePriorityChangedObservable.clear(), this.onClearColorChangedObservable.clear(), this.onEnvironmentTextureChangedObservable.clear(), this.onMeshUnderPointerUpdatedObservable.clear(), this._isDisposed = !0
      }
      _disposeList(OO, KO) {
        const pO = OO.slice(0);
        KO = KO ?? (OO => OO.dispose());
        for (const XO of pO) KO(XO);
        OO.length = 0
      }
      get FhO() {
        return this._isDisposed
      }
      clearCachedVertexData() {
        for (let OO = 0; OO < this.meshes.length; OO++) {
          const KO = this.meshes[OO].geometry;
          KO && KO.clearCachedData()
        }
      }
      cleanCachedTextureBuffer() {
        for (const OO of this.textures) {
          OO._buffer && (OO._buffer = null)
        }
      }
      getWorldExtends(OO) {
        const KO = new DO.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE),
          pO = new DO.o(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE);
        OO = OO || (() => !0);
        const XO = this.meshes.filter(OO);
        for (const bK of XO) {
          if (bK.computeWorldMatrix(!0), !bK.au || 0 === bK.au.length || bK.infiniteDistance) continue;
          const OO = bK.hpO(),
            XO = OO.boundingBox.minimumWorld,
            eO = OO.boundingBox.maximumWorld;
          DO.o.CheckExtends(XO, KO, pO), DO.o.CheckExtends(eO, KO, pO)
        }
        return KO.x === Number.MAX_VALUE ? {
          min: DO.o.Zero(),
          max: DO.o.Zero()
        } : {
          min: KO,
          max: pO
        }
      }
      createPickingRay(OO, KO, pO, XO) {
        throw (0, dO.j)("Ray")
      }
      createPickingRayToRef(OO, KO, pO, XO, bK) {
        throw (0, dO.j)("Ray")
      }
      createPickingRayInCameraSpace(OO, KO, pO) {
        throw (0, dO.j)("Ray")
      }
      createPickingRayInCameraSpaceToRef(OO, KO, pO, XO) {
        throw (0, dO.j)("Ray")
      }
      Kp(OO, KO, pO, XO, bK, eO) {
        const lO = (0, dO.j)("Ray", !0);
        return lO && Op.b.Warn(lO), new oO.c
      }
      pickWithBoundingInfo(OO, KO, pO, XO, bK) {
        const eO = (0, dO.j)("Ray", !0);
        return eO && Op.b.Warn(eO), new oO.c
      }
      pickWithRay(OO, KO, pO, XO) {
        throw (0, dO.j)("Ray")
      }
      multiPick(OO, KO, pO, XO, bK) {
        throw (0, dO.j)("Ray")
      }
      multiPickWithRay(OO, KO, pO) {
        throw (0, dO.j)("Ray")
      }
      setPointerOverMesh(OO, KO, pO) {
        this._inputManager.setPointerOverMesh(OO, KO, pO)
      }
      getPointerOverMesh() {
        return this._inputManager.getPointerOverMesh()
      }
      _rebuildGeometries() {
        for (const OO of this.geometries) OO._rebuild();
        for (const OO of this.meshes) OO._rebuild();
        this.postProcessManager && this.postProcessManager._rebuild();
        for (const OO of this._components) OO.rebuild();
        for (const OO of this.ku) OO.rebuild();
        if (this.spriteManagers)
          for (const OO of this.spriteManagers) OO.rebuild()
      }
      _rebuildTextures() {
        for (const OO of this.textures) OO._rebuild(!0);
        this.markAllMaterialsAsDirty(1)
      }
      _getByTags(OO, KO, pO) {
        if (void 0 === KO) return OO;
        const XO = [];
        for (const bK in OO) {
          const eO = OO[bK];
          hO.b && hO.b.MatchesQuery(eO, KO) && (!pO || pO(eO)) && XO.push(eO)
        }
        return XO
      }
      getMeshesByTags(OO, KO) {
        return this._getByTags(this.meshes, OO, KO)
      }
      getCamerasByTags(OO, KO) {
        return this._getByTags(this.cameras, OO, KO)
      }
      getLightsByTags(OO, KO) {
        return this._getByTags(this.lights, OO, KO)
      }
      getMaterialByTags(OO, KO) {
        return this._getByTags(this.materials, OO, KO).concat(this._getByTags(this.multiMaterials, OO, KO))
      }
      getTransformNodesByTags(OO, KO) {
        return this._getByTags(this.transformNodes, OO, KO)
      }
      setRenderingOrder(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        this._renderingManager.setRenderingOrder(OO, KO, pO, XO)
      }
      setRenderingAutoClearDepthStencil(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
          XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        this._renderingManager.setRenderingAutoClearDepthStencil(OO, KO, pO, XO)
      }
      getAutoClearDepthStencilSetup(OO) {
        return this._renderingManager.getAutoClearDepthStencilSetup(OO)
      }
      _forceBlockMaterialDirtyMechanism(OO) {
        this._blockMaterialDirtyMechanism = OO
      }
      get blockMaterialDirtyMechanism() {
        return this._blockMaterialDirtyMechanism
      }
      set blockMaterialDirtyMechanism(OO) {
        this._blockMaterialDirtyMechanism !== OO && (this._blockMaterialDirtyMechanism = OO, OO || this.markAllMaterialsAsDirty(127))
      }
      markAllMaterialsAsDirty(OO, KO) {
        if (!this._blockMaterialDirtyMechanism)
          for (const pO of this.materials) KO && !KO(pO) || pO.jhO(OO)
      }
      _loadFile(OO, KO, pO, XO, bK, eO, lO) {
        const vK = (0, nO.o)(OO, KO, pO, XO ? this.offlineProvider : void 0, bK, eO, lO);
        return this._activeRequests.push(vK), vK.onCompleteObservable.add((OO => {
          this._activeRequests.splice(this._activeRequests.indexOf(OO), 1)
        })), vK
      }
      async _loadFileAsync(OO, KO, pO, XO, bK) {
        return await new Promise(((eO, lO) => {
          this._loadFile(OO, (OO => {
            eO(OO)
          }), KO, pO, XO, ((OO, KO) => {
            lO(KO)
          }), bK)
        }))
      }
      async _loadDelayedFileAsync(OO, KO, pO) {
        this._delayedFileRequests || (this._delayedFileRequests = new Map);
        const XO = `${OO}|${KO?"binary":"string"}`;
        let bK = this._delayedFileRequests.get(XO);
        if (!bK) {
          bK = KO ? this._loadFileAsync(OO, void 0, pO, !0) : this._loadFileAsync(OO, void 0, pO, !1);
          const eO = bK;
          (async () => {
            try {
              await eO
            } catch {}
            this._delayedFileRequests?.delete(XO)
          })(), this._delayedFileRequests.set(XO, bK)
        }
        return await bK
      }
      _requestFile(OO, KO, pO, XO, bK, eO, lO) {
        const vK = (0, nO.z)(OO, KO, pO, XO ? this.offlineProvider : void 0, bK, eO, lO);
        return this._activeRequests.push(vK), vK.onCompleteObservable.add((OO => {
          this._activeRequests.splice(this._activeRequests.indexOf(OO), 1)
        })), vK
      }
      async _requestFileAsync(OO, KO, pO, XO, bK) {
        return await new Promise(((eO, lO) => {
          this._requestFile(OO, (OO => {
            eO(OO)
          }), KO, pO, XO, (OO => {
            lO(OO)
          }), bK)
        }))
      }
      _readFile(OO, KO, pO, XO, bK) {
        const eO = (0, nO.u)(OO, KO, pO, XO, bK);
        return this._activeRequests.push(eO), eO.onCompleteObservable.add((OO => {
          this._activeRequests.splice(this._activeRequests.indexOf(OO), 1)
        })), eO
      }
      async _readFileAsync(OO, KO, pO) {
        return await new Promise(((XO, bK) => {
          this._readFile(OO, (OO => {
            XO(OO)
          }), KO, pO, (OO => {
            bK(OO)
          }))
        }))
      }
      getPerfCollector() {
        throw (0, dO.j)("performanceViewerSceneExtension")
      }
      setActiveCameraByID(OO) {
        return this.setActiveCameraById(OO)
      }
      getMaterialByID(OO) {
        return this.getMaterialById(OO)
      }
      getLastMaterialByID(OO) {
        return this.getLastMaterialById(OO)
      }
      getTextureByUniqueID(OO) {
        return this.getTextureByUniqueId(OO)
      }
      getCameraByID(OO) {
        return this.getCameraById(OO)
      }
      getCameraByUniqueID(OO) {
        return this.getCameraByUniqueId(OO)
      }
      getBoneByID(OO) {
        return this.getBoneById(OO)
      }
      getLightByID(OO) {
        return this.getLightById(OO)
      }
      getLightByUniqueID(OO) {
        return this.getLightByUniqueId(OO)
      }
      getParticleSystemByID(OO) {
        return this.getParticleSystemById(OO)
      }
      getGeometryByID(OO) {
        return this.getGeometryById(OO)
      }
      getMeshByID(OO) {
        return this.getMeshById(OO)
      }
      getMeshByUniqueID(OO) {
        return this.getMeshByUniqueId(OO)
      }
      getLastMeshByID(OO) {
        return this.getLastMeshById(OO)
      }
      getMeshesByID(OO) {
        return this.getMeshesById(OO)
      }
      getTransformNodeByID(OO) {
        return this.getTransformNodeById(OO)
      }
      getTransformNodeByUniqueID(OO) {
        return this.getTransformNodeByUniqueId(OO)
      }
      getTransformNodesByID(OO) {
        return this.getTransformNodesById(OO)
      }
      getNodeByID(OO) {
        return this.getNodeById(OO)
      }
      getLastEntryByID(OO) {
        return this.getLastEntryById(OO)
      }
      getLastSkeletonByID(OO) {
        return this.getLastSkeletonById(OO)
      }
    }
    ep.FOGMODE_NONE = 0, ep.FOGMODE_EXP = 1, ep.FOGMODE_EXP2 = 2, ep.FOGMODE_LINEAR = 3, ep.MinDeltaTime = 1, ep.MaxDeltaTime = 1e3, ep._OriginalDefaultMaterialFactory = ep.DefaultMaterialFactory;
    let lp = !1;

    function vX() {
      lp || (lp = !0, (0, Kp.h)("BABYLON.Scene", ep))
    }(UO = ep.prototype).sortActiveAnimatables ?? (UO.sortActiveAnimatables = (0, dO.h)("Scene", "sortActiveAnimatables")), (OK = ep.prototype).beginWeightedAnimation ?? (OK.beginWeightedAnimation = (0, dO.h)("Scene", "beginWeightedAnimation")), (KK = ep.prototype).beginAnimation ?? (KK.beginAnimation = (0, dO.h)("Scene", "beginAnimation")), (pK = ep.prototype).beginHierarchyAnimation ?? (pK.beginHierarchyAnimation = (0, dO.h)("Scene", "beginHierarchyAnimation")), (XK = ep.prototype).beginDirectAnimation ?? (XK.beginDirectAnimation = (0, dO.h)("Scene", "beginDirectAnimation")), (bp = ep.prototype).beginDirectHierarchyAnimation ?? (bp.beginDirectHierarchyAnimation = (0, dO.h)("Scene", "beginDirectHierarchyAnimation")), (eK = ep.prototype).getAnimatableByTarget ?? (eK.getAnimatableByTarget = (0, dO.h)("Scene", "getAnimatableByTarget")), (lK = ep.prototype).getAllAnimatablesByTarget ?? (lK.getAllAnimatablesByTarget = (0, dO.h)("Scene", "getAllAnimatablesByTarget")), (vp = ep.prototype).stopAllAnimations ?? (vp.stopAllAnimations = (0, dO.h)("Scene", "stopAllAnimations")), (CK = ep.prototype).getSoundByName ?? (CK.getSoundByName = (0, dO.h)("Scene", "getSoundByName")), (hK = ep.prototype).createOrUpdateSelectionOctree ?? (hK.createOrUpdateSelectionOctree = (0, dO.h)("Scene", "createOrUpdateSelectionOctree")), (DK = ep.prototype).createDefaultLight ?? (DK.createDefaultLight = (0, dO.h)("Scene", "createDefaultLight")), (MK = ep.prototype).createDefaultCamera ?? (MK.createDefaultCamera = (0, dO.h)("Scene", "createDefaultCamera")), (ap = ep.prototype).createDefaultCameraOrLight ?? (ap.createDefaultCameraOrLight = (0, dO.h)("Scene", "createDefaultCameraOrLight")), (oK = ep.prototype).createDefaultSkybox ?? (oK.createDefaultSkybox = (0, dO.h)("Scene", "createDefaultSkybox")), (FK = ep.prototype).createDefaultEnvironment ?? (FK.createDefaultEnvironment = (0, dO.h)("Scene", "createDefaultEnvironment")), (VK = ep.prototype).createDefaultVRExperience ?? (VK.createDefaultVRExperience = (0, dO.h)("Scene", "createDefaultVRExperience")), (LK = ep.prototype).createDefaultXRExperienceAsync ?? (LK.createDefaultXRExperienceAsync = (0, dO.h)("Scene", "createDefaultXRExperienceAsync")), (QK = ep.prototype).getGlowLayerByName ?? (QK.getGlowLayerByName = (0, dO.h)("Scene", "getGlowLayerByName")), (zp = ep.prototype).getHighlightLayerByName ?? (zp.getHighlightLayerByName = (0, dO.h)("Scene", "getHighlightLayerByName")), (AK = ep.prototype).getSelectionOutlineLayerByName ?? (AK.getSelectionOutlineLayerByName = (0, dO.h)("Scene", "getSelectionOutlineLayerByName")), (fK = ep.prototype).removeLensFlareSystem ?? (fK.removeLensFlareSystem = (0, dO.h)("Scene", "removeLensFlareSystem")), (dK = ep.prototype).addLensFlareSystem ?? (dK.addLensFlareSystem = (0, dO.h)("Scene", "addLensFlareSystem")), (TK = ep.prototype).getLensFlareSystemByName ?? (TK.getLensFlareSystemByName = (0, dO.h)("Scene", "getLensFlareSystemByName")), (NK = ep.prototype).getLensFlareSystemByID ?? (NK.getLensFlareSystemByID = (0, dO.h)("Scene", "getLensFlareSystemByID")), (IK = ep.prototype).getLensFlareSystemById ?? (IK.getLensFlareSystemById = (0, dO.h)("Scene", "getLensFlareSystemById")), (yp = ep.prototype).getPhysicsEngine ?? (yp.getPhysicsEngine = (0, dO.h)("Scene", "getPhysicsEngine")), (gp = ep.prototype).enablePhysics ?? (gp.enablePhysics = (0, dO.h)("Scene", "enablePhysics")), (uK = ep.prototype).disablePhysicsEngine ?? (uK.disablePhysicsEngine = (0, dO.h)("Scene", "disablePhysicsEngine")), (EK = ep.prototype).isPhysicsEnabled ?? (EK.isPhysicsEnabled = (0, dO.h)("Scene", "isPhysicsEnabled")), (jp = ep.prototype).deleteCompoundImpostor ?? (jp.deleteCompoundImpostor = (0, dO.h)("Scene", "deleteCompoundImpostor")), (YK = ep.prototype).removeReflectionProbe ?? (YK.removeReflectionProbe = (0, dO.h)("Scene", "removeReflectionProbe")), (wK = ep.prototype).addReflectionProbe ?? (wK.addReflectionProbe = (0, dO.h)("Scene", "addReflectionProbe")), (ip = ep.prototype).getBoundingBoxRenderer ?? (ip.getBoundingBoxRenderer = (0, dO.h)("Scene", "getBoundingBoxRenderer")), (rp = ep.prototype).enableDepthRenderer ?? (rp.enableDepthRenderer = (0, dO.h)("Scene", "enableDepthRenderer")), (PK = ep.prototype).disableDepthRenderer ?? (PK.disableDepthRenderer = (0, dO.h)("Scene", "disableDepthRenderer")), (mp = ep.prototype).enableFluidRenderer ?? (mp.enableFluidRenderer = (0, dO.h)("Scene", "enableFluidRenderer")), (sK = ep.prototype).disableFluidRenderer ?? (sK.disableFluidRenderer = (0, dO.h)("Scene", "disableFluidRenderer")), (HK = ep.prototype).enableGeometryBufferRenderer ?? (HK.enableGeometryBufferRenderer = (0, dO.h)("Scene", "enableGeometryBufferRenderer")), (RK = ep.prototype).disableGeometryBufferRenderer ?? (RK.disableGeometryBufferRenderer = (0, dO.h)("Scene", "disableGeometryBufferRenderer")), (SK = ep.prototype).enableIblCdfGenerator ?? (SK.enableIblCdfGenerator = (0, dO.h)("Scene", "enableIblCdfGenerator")), (JK = ep.prototype).disableIblCdfGenerator ?? (JK.disableIblCdfGenerator = (0, dO.h)("Scene", "disableIblCdfGenerator")), (cp = ep.prototype).getOutlineRenderer ?? (cp.getOutlineRenderer = (0, dO.h)("Scene", "getOutlineRenderer")), (BK = ep.prototype).enablePrePassRenderer ?? (BK.enablePrePassRenderer = (0, dO.h)("Scene", "enablePrePassRenderer")), (ZK = ep.prototype).disablePrePassRenderer ?? (ZK.disablePrePassRenderer = (0, dO.h)("Scene", "disablePrePassRenderer")), (GK = ep.prototype).enableSubSurfaceForPrePass ?? (GK.enableSubSurfaceForPrePass = (0, dO.h)("Scene", "enableSubSurfaceForPrePass")), (qp = ep.prototype).disableSubSurfaceForPrePass ?? (qp.disableSubSurfaceForPrePass = (0, dO.h)("Scene", "disableSubSurfaceForPrePass")), (xp = ep.prototype).pickSprite ?? (xp.pickSprite = (0, dO.h)("Scene", "pickSprite")), (nK = ep.prototype).pickSpriteWithRay ?? (nK.pickSpriteWithRay = (0, dO.h)("Scene", "pickSpriteWithRay")), (WK = ep.prototype).multiPickSprite ?? (WK.multiPickSprite = (0, dO.h)("Scene", "multiPickSprite")), (tp = ep.prototype).multiPickSpriteWithRay ?? (tp.multiPickSpriteWithRay = (0, dO.h)("Scene", "multiPickSpriteWithRay")), (kp = ep.prototype).setPointerOverSprite ?? (kp.setPointerOverSprite = (0, dO.h)("Scene", "setPointerOverSprite")), (UK = ep.prototype).getPointerOverSprite ?? (UK.getPointerOverSprite = (0, dO.h)("Scene", "getPointerOverSprite")), Object.getOwnPropertyDescriptor(ep.prototype, "mainSoundTrack") || Object.defineProperty(ep.prototype, "mainSoundTrack", (0, dO.e)("Scene", "mainSoundTrack")), Object.getOwnPropertyDescriptor(ep.prototype, "soundTracks") || Object.defineProperty(ep.prototype, "soundTracks", (0, dO.e)("Scene", "soundTracks")), Object.getOwnPropertyDescriptor(ep.prototype, "audioEnabled") || Object.defineProperty(ep.prototype, "audioEnabled", (0, dO.e)("Scene", "audioEnabled")), Object.getOwnPropertyDescriptor(ep.prototype, "headphone") || Object.defineProperty(ep.prototype, "headphone", (0, dO.e)("Scene", "headphone")), Object.getOwnPropertyDescriptor(ep.prototype, "audioListenerPositionProvider") || Object.defineProperty(ep.prototype, "audioListenerPositionProvider", (0, dO.e)("Scene", "audioListenerPositionProvider")), Object.getOwnPropertyDescriptor(ep.prototype, "audioListenerRotationProvider") || Object.defineProperty(ep.prototype, "audioListenerRotationProvider", (0, dO.e)("Scene", "audioListenerRotationProvider")), Object.getOwnPropertyDescriptor(ep.prototype, "audioPositioningRefreshRate") || Object.defineProperty(ep.prototype, "audioPositioningRefreshRate", (0, dO.e)("Scene", "audioPositioningRefreshRate")), Object.getOwnPropertyDescriptor(ep.prototype, "selectionOctree") || Object.defineProperty(ep.prototype, "selectionOctree", (0, dO.e)("Scene", "selectionOctree")), Object.getOwnPropertyDescriptor(ep.prototype, "debugLayer") || Object.defineProperty(ep.prototype, "debugLayer", (0, dO.e)("Scene", "debugLayer")), Object.getOwnPropertyDescriptor(ep.prototype, "gamepadManager") || Object.defineProperty(ep.prototype, "gamepadManager", (0, dO.e)("Scene", "gamepadManager")), Object.getOwnPropertyDescriptor(ep.prototype, "simplificationQueue") || Object.defineProperty(ep.prototype, "simplificationQueue", (0, dO.e)("Scene", "simplificationQueue")), Object.getOwnPropertyDescriptor(ep.prototype, "onBeforePhysicsObservable") || Object.defineProperty(ep.prototype, "onBeforePhysicsObservable", (0, dO.e)("Scene", "onBeforePhysicsObservable")), Object.getOwnPropertyDescriptor(ep.prototype, "onAfterPhysicsObservable") || Object.defineProperty(ep.prototype, "onAfterPhysicsObservable", (0, dO.e)("Scene", "onAfterPhysicsObservable")), Object.getOwnPropertyDescriptor(ep.prototype, "reflectionProbes") || Object.defineProperty(ep.prototype, "reflectionProbes", (0, dO.e)("Scene", "reflectionProbes")), Object.getOwnPropertyDescriptor(ep.prototype, "forceShowBoundingBoxes") || Object.defineProperty(ep.prototype, "forceShowBoundingBoxes", (0, dO.e)("Scene", "forceShowBoundingBoxes")), Object.getOwnPropertyDescriptor(ep.prototype, "depthPeelingRenderer") || Object.defineProperty(ep.prototype, "depthPeelingRenderer", (0, dO.e)("Scene", "depthPeelingRenderer")), Object.getOwnPropertyDescriptor(ep.prototype, "useOrderIndependentTransparency") || Object.defineProperty(ep.prototype, "useOrderIndependentTransparency", (0, dO.e)("Scene", "useOrderIndependentTransparency")), Object.getOwnPropertyDescriptor(ep.prototype, "fluidRenderer") || Object.defineProperty(ep.prototype, "fluidRenderer", (0, dO.e)("Scene", "fluidRenderer")), Object.getOwnPropertyDescriptor(ep.prototype, "geometryBufferRenderer") || Object.defineProperty(ep.prototype, "geometryBufferRenderer", (0, dO.e)("Scene", "geometryBufferRenderer")), Object.getOwnPropertyDescriptor(ep.prototype, "iblCdfGenerator") || Object.defineProperty(ep.prototype, "iblCdfGenerator", (0, dO.e)("Scene", "iblCdfGenerator")), Object.getOwnPropertyDescriptor(ep.prototype, "prePassRenderer") || Object.defineProperty(ep.prototype, "prePassRenderer", (0, dO.e)("Scene", "prePassRenderer")), Object.getOwnPropertyDescriptor(ep.prototype, "subSurfaceConfiguration") || Object.defineProperty(ep.prototype, "subSurfaceConfiguration", (0, dO.e)("Scene", "subSurfaceConfiguration")), Object.getOwnPropertyDescriptor(ep.prototype, "spriteManagers") || Object.defineProperty(ep.prototype, "spriteManagers", (0, dO.e)("Scene", "spriteManagers")), Object.getOwnPropertyDescriptor(ep.prototype, "onBeforeSpritesRenderingObservable") || Object.defineProperty(ep.prototype, "onBeforeSpritesRenderingObservable", (0, dO.e)("Scene", "onBeforeSpritesRenderingObservable")), Object.getOwnPropertyDescriptor(ep.prototype, "onAfterSpritesRenderingObservable") || Object.defineProperty(ep.prototype, "onAfterSpritesRenderingObservable", (0, dO.e)("Scene", "onAfterSpritesRenderingObservable"))
  },
  38250: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      e: () => bK
    });
    class XO {}
    XO.NAME_EFFECTLAYER = "EffectLayer", XO.NAME_LAYER = "Layer", XO.NAME_LENSFLARESYSTEM = "LensFlareSystem", XO.NAME_BOUNDINGBOXRENDERER = "BoundingBoxRenderer", XO.NAME_PARTICLESYSTEM = "ParticleSystem", XO.NAME_GAMEPAD = "Gamepad", XO.NAME_SIMPLIFICATIONQUEUE = "SimplificationQueue", XO.NAME_GEOMETRYBUFFERRENDERER = "GeometryBufferRenderer", XO.NAME_PREPASSRENDERER = "PrePassRenderer", XO.NAME_DEPTHRENDERER = "DepthRenderer", XO.NAME_DEPTHPEELINGRENDERER = "DepthPeelingRenderer", XO.NAME_POSTPROCESSRENDERPIPELINEMANAGER = "PostProcessRenderPipelineManager", XO.NAME_SPRITE = "Sprite", XO.NAME_SUBSURFACE = "SubSurface", XO.NAME_OUTLINERENDERER = "Outline", XO.NAME_PROCEDURALTEXTURE = "ProceduralTexture", XO.NAME_SHADOWGENERATOR = "ShadowGenerator", XO.NAME_OCTREE = "XDO", XO.NAME_PHYSICSENGINE = "PhysicsEngine", XO.NAME_AUDIO = "Audio", XO.NAME_FLUIDRENDERER = "FluidRenderer", XO.NAME_IBLCDFGENERATOR = "iblCDFGenerator", XO.NAME_CLUSTEREDLIGHTING = "ClusteredLighting", XO.STEP_ISREADYFORMESH_EFFECTLAYER = 0, XO.STEP_ISREADYFORMESH_DEPTHRENDERER = 1, XO.STEP_BEFOREEVALUATEACTIVEMESH_BOUNDINGBOXRENDERER = 0, XO.STEP_EVALUATESUBMESH_BOUNDINGBOXRENDERER = 0, XO.STEP_PREACTIVEMESH_BOUNDINGBOXRENDERER = 0, XO.STEP_CAMERADRAWRENDERTARGET_EFFECTLAYER = 1, XO.STEP_BEFORECAMERADRAW_PREPASS = 0, XO.STEP_BEFORECAMERADRAW_EFFECTLAYER = 1, XO.STEP_BEFORECAMERADRAW_LAYER = 2, XO.STEP_BEFORERENDERTARGETDRAW_PREPASS = 0, XO.STEP_BEFORERENDERTARGETDRAW_LAYER = 1, XO.STEP_BEFORERENDERINGMESH_PREPASS = 0, XO.STEP_BEFORERENDERINGMESH_OUTLINE = 1, XO.STEP_AFTERRENDERINGMESH_PREPASS = 0, XO.STEP_AFTERRENDERINGMESH_OUTLINE = 1, XO.STEP_AFTERRENDERINGGROUPDRAW_EFFECTLAYER_DRAW = 0, XO.STEP_AFTERRENDERINGGROUPDRAW_BOUNDINGBOXRENDERER = 1, XO.STEP_BEFORECAMERAUPDATE_SIMPLIFICATIONQUEUE = 0, XO.STEP_BEFORECLEAR_PROCEDURALTEXTURE = 0, XO.STEP_BEFORECLEAR_PREPASS = 1, XO.STEP_BEFORERENDERTARGETCLEAR_PREPASS = 0, XO.STEP_AFTERRENDERTARGETDRAW_PREPASS = 0, XO.STEP_AFTERRENDERTARGETDRAW_LAYER = 1, XO.STEP_AFTERCAMERADRAW_PREPASS = 0, XO.STEP_AFTERCAMERADRAW_EFFECTLAYER = 1, XO.STEP_AFTERCAMERADRAW_LENSFLARESYSTEM = 2, XO.STEP_AFTERCAMERADRAW_EFFECTLAYER_DRAW = 3, XO.STEP_AFTERCAMERADRAW_LAYER = 4, XO.STEP_AFTERCAMERADRAW_FLUIDRENDERER = 5, XO.STEP_AFTERCAMERAPOSTPROCESS_LAYER = 0, XO.STEP_AFTERRENDERTARGETPOSTPROCESS_LAYER = 0, XO.STEP_AFTERRENDER_AUDIO = 0, XO.STEP_GATHERRENDERTARGETS_DEPTHRENDERER = 0, XO.STEP_GATHERRENDERTARGETS_GEOMETRYBUFFERRENDERER = 1, XO.STEP_GATHERRENDERTARGETS_SHADOWGENERATOR = 2, XO.STEP_GATHERRENDERTARGETS_POSTPROCESSRENDERPIPELINEMANAGER = 3, XO.STEP_GATHERACTIVECAMERARENDERTARGETS_DEPTHRENDERER = 0, XO.STEP_GATHERACTIVECAMERARENDERTARGETS_FLUIDRENDERER = 1, XO.STEP_GATHERACTIVECAMERARENDERTARGETS_CLUSTEREDLIGHTING = 2, XO.STEP_POINTERMOVE_SPRITE = 0, XO.STEP_POINTERDOWN_SPRITE = 0, XO.STEP_POINTERUP_SPRITE = 0;
    class bK extends Array {
      constructor(OO) {
        super(...OO)
      }
      static Create() {
        return Object.create(bK.prototype)
      }
      registerStep(OO, KO, pO) {
        let XO, bK = 0;
        for (; bK < this.length; bK++) {
          if (XO = this[bK].index, OO < XO) break
        }
        this.splice(bK, 0, {
          index: OO,
          component: KO,
          action: pO.bind(KO)
        })
      }
      clear() {
        this.length = 0
      }
    }
  },
  38063: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO,
      e: () => vK,
      f: () => XO,
      i: () => bK,
      l: () => eO
    });

    function XO(OO, KO, pO, XO, bK, eO) {
      function lO(OO) {
        if (void 0 !== OO && "function" !== typeof OO) throw new TypeError("Function expected");
        return OO
      }
      for (var vK, CO = XO.kind, hO = "getter" === CO ? "get" : "setter" === CO ? "set" : "value", DO = !KO && OO ? XO.static ? OO : OO.prototype : null, MO = KO || (DO ? Object.getOwnPropertyDescriptor(DO, XO.name) : {}), aK = !1, oO = pO.length - 1; oO >= 0; oO--) {
        var FO = {};
        for (var VO in XO) FO[VO] = "access" === VO ? {} : XO[VO];
        for (var VO in XO.access) FO.access[VO] = XO.access[VO];
        FO.addInitializer = function(OO) {
          if (aK) throw new TypeError("Cannot add initializers after decoration has completed");
          eO.push(lO(OO || null))
        };
        var LO = (0, pO[oO])("accessor" === CO ? {
          get: MO.get,
          set: MO.set
        } : MO[hO], FO);
        if ("accessor" === CO) {
          if (void 0 === LO) continue;
          if (null === LO || "object" !== typeof LO) throw new TypeError("Object expected");
          (vK = lO(LO.get)) && (MO.get = vK), (vK = lO(LO.set)) && (MO.set = vK), (vK = lO(LO.init)) && bK.unshift(vK)
        } else(vK = lO(LO)) && ("field" === CO ? bK.unshift(vK) : MO[hO] = vK)
      }
      DO && Object.defineProperty(DO, XO.name, MO), aK = !0
    }

    function bK(OO, KO, pO) {
      for (var XO = arguments.length > 2, bK = 0; bK < KO.length; bK++) pO = XO ? KO[bK].call(OO, pO) : KO[bK].call(OO);
      return XO ? pO : void 0
    }

    function eO(OO, KO, pO) {
      return "symbol" === typeof KO && (KO = KO.description ? "[".concat(KO.description, "]") : ""), Object.defineProperty(OO, "name", {
        configurable: !0,
        value: pO ? "".concat(pO, " ", KO) : KO
      })
    }
    Object.create;
    Object.create;

    function lO(OO, KO, pO, XO) {
      if ("a" === pO && !XO) throw new TypeError("Private accessor was defined without a getter");
      if ("function" === typeof KO ? OO !== KO || !XO : !KO.has(OO)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
      return "m" === pO ? XO : "a" === pO ? XO.call(OO) : XO ? XO.value : KO.get(OO)
    }

    function vK(OO, KO, pO, XO, bK) {
      if ("m" === XO) throw new TypeError("Private method is not writable");
      if ("a" === XO && !bK) throw new TypeError("Private accessor was defined without a setter");
      if ("function" === typeof KO ? OO !== KO || !bK : !KO.has(OO)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
      return "a" === XO ? bK.call(OO, pO) : bK ? bK.value = pO : KO.set(OO, pO), pO
    }
    "function" === typeof SuppressedError && SuppressedError
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);