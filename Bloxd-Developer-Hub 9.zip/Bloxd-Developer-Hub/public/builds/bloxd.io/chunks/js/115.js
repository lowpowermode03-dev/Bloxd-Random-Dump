export const id = 115;
export const ids = [115];
export const modules = {
  39133: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      ShaderPackCategory: () => wO
    });
    var XO = pO(63),
      bK = pO(1355),
      eO = pO(1271),
      lO = pO(1344),
      vK = pO(1051),
      CO = pO(94),
      hO = pO(22),
      DO = pO(1441),
      MO = pO(5739),
      aK = pO(233),
      oO = pO(5791),
      FO = pO(5786),
      VO = pO(5800),
      LO = pO(5674),
      QO = pO(4120),
      zK = pO(5715),
      AO = pO(5730),
      fO = pO(2677);

    function dO(OO, KO) {
      const pO = (0, oO.storedPackOutcome)(OO, KO);
      return "none" !== pO.kind || "noCompiler" === pO.reason
    }
    var TO = pO(918),
      NO = pO.n(TO),
      IO = pO(5721),
      yK = pO(933),
      gK = pO(5711),
      uO = pO(976);
    const EO = {
      ready: "shaderPack:statusReady",
      readyAfterReload: "shaderPack:statusReadyAfterReload",
      noWebGpu: "shaderPack:statusNoWebGpu",
      offNoWebGpu: "shaderPack:statusOffNoWebGpu",
      failed: "shaderPack:statusFailed",
      failedRecheck: "shaderPack:statusFailedRecheck",
      wrongApiVersion: "shaderPack:statusWrongApiVersion",
      checking: "shaderPack:statusChecking",
      unchecked: "shaderPack:statusUnchecked",
      noCompiler: "shaderPack:statusNoCompiler"
    };

    function jK(OO, KO) {
      return "failedRecheck" === OO && KO.listing ? "shaderPack:statusFailedRecheckListed" : EO[OO]
    }

    function YO(OO) {
      let {
        stored: KO,
        checking: pO,
        webGpuUsable: XO,
        changePending: bK,
        compiler: eO,
        t: lO
      } = OO;
      const vK = function(OO, KO, pO, XO, bK) {
          const eO = (0, oO.storedPackOutcome)(OO, bK);
          return "none" === eO.kind ? "noCompiler" === eO.reason ? KO ? "checking" : "noCompiler" : "otherApiVersion" === eO.reason ? "wrongApiVersion" : "failed" : (0, fO.f)() ? "harnessBuild" : "blocked" === eO.kind ? (0, oO.shaderPackNeedsCheck)(OO, bK) ? KO ? "checking" : !1 === pO ? "noWebGpu" : "unchecked" : "failedRecheck" : !1 === pO ? "offNoWebGpu" : XO ? "readyAfterReload" : "ready"
        }(KO, pO, XO, bK, eO),
        CO = "failed" === vK || "failedRecheck" === vK,
        hO = CO || "wrongApiVersion" === vK || "noCompiler" === vK,
        DO = "ready" === vK || "readyAfterReload" === vK ? KO.validation.offInStrict : [];
      return (0, uO.jsxs)(uO.Fragment, {
        children: [(0, uO.jsxs)("div", {
          className: NO()("ShaderPackStatus", {
            Ready: "ready" === vK,
            Failed: hO
          }),
          children: ["ready" === vK && (0, uO.jsx)(yK.d, {
            name: "circle-check"
          }), hO && (0, uO.jsx)(yK.d, {
            name: "triangle-exclamation"
          }), "harnessBuild" === vK ? (0, fO.d)() : lO(jK(vK, KO), {
            packVersion: String(KO.manifest.apiVersion),
            version: String(IO.b)
          })]
        }), CO && (0, uO.jsx)(gK.c, {
          diagnostics: KO.validation.errors,
          more: KO.validation.moreErrors,
          t: lO
        }), DO.length > 0 && (0, uO.jsxs)(uO.Fragment, {
          children: [(0, uO.jsxs)("div", {
            className: "ShaderPackStatus OffInStrict",
            children: [(0, uO.jsx)(yK.d, {
              name: "triangle-exclamation"
            }), lO("shaderPack:offInStrict")]
          }), (0, uO.jsx)(gK.c, {
            diagnostics: DO,
            t: lO
          })]
        })]
      })
    }

    function wO(OO) {
      let {
        setApplySettingsCallback: KO
      } = OO;
      const {
        t: pO
      } = (0, vK.D)(), [bK, lO] = (0, XO.useState)(null), [hO, DO] = (0, XO.useState)(null), [fO, TO] = (0, XO.useState)(null), [NO] = (0, XO.useState)(aK.e), [IO, yK] = (0, XO.useState)(!0), [gK, EO] = (0, XO.useState)(!1), {
        loading: jK,
        error: wO,
        setError: rK,
        onFiles: PO
      } = (0, AO.h)((async OO => {
        const KO = await (0, MO.loadPageShaderPackCompiler)();
        if (!KO) return void rK(pO("shaderPack:compilerUnavailable"));
        DO(KO);
        const XO = (0, oO.toStoredShaderPack)(OO, await (0, FO.f)(KO, OO.files));
        await (0, oO.saveShaderPack)(XO, KO) ? (lO(XO), mK(bK, XO, KO)) : rK(pO("shaderPack:saveFailed"))
      }));

      function mK(OO, pO, XO) {
        (function(OO, KO, pO, XO) {
          return pO || dO(OO, XO) || dO(KO, XO)
        })(OO, pO, (0, oO.isShaderPackChangePending)(), XO) && ((0, oO.markShaderPackChangePending)(), KO((() => QO.j)))
      }
      return (0, XO.useEffect)((() => {
        let OO = !1;
        return async function() {
          const KO = (0, CO.hasUsableWebGpuAdapter)(),
            pO = await (0, VO.h)();
          if (OO) return;
          lO(pO), EO(!0), yK(!1);
          const XO = null !== pO ? (0, MO.loadPageShaderPackCompiler)() : null,
            bK = await KO;
          if (OO) return;
          TO(bK);
          const eO = await XO;
          if (!OO && (DO(eO), null !== pO && bK && null !== eO && (0, oO.shaderPackNeedsCheck)(pO, eO))) {
            const KO = await (0, FO.e)(pO, eO);
            OO || lO((OO => OO === pO ? KO : OO))
          }
        }().catch((KO => {
          console.error("Failed to load the stored shader pack", KO), OO || rK(pO("shaderPack:unexpectedError"))
        })).finally((() => {
          OO || (yK(!1), EO(!1))
        })), () => {
          OO = !0
        }
      }), []), (0, uO.jsxs)("div", {
        className: "ShaderPackCategory SettingsMenuRightInner",
        children: [(0, uO.jsx)("div", {
          className: "ShaderPackIntro",
          children: pO("shaderPack:intro")
        }), (0, uO.jsx)(iK, {
          to: LO.S,
          className: "ShaderPackBrowseLink",
          children: (0, uO.jsx)(eO.m, {
            className: "ShaderPackBrowseButton",
            children: pO("shaderPackListing:browse")
          })
        }), !1 === fO && (0, uO.jsx)("div", {
          className: "SettingsBoxWarning",
          children: pO(NO ? "shaderPack:needsWebGpuDisabledUntilRestart" : "shaderPack:needsWebGpu")
        }), null !== wO && (0, uO.jsxs)("div", {
          className: "ShaderPackCategoryError",
          children: [pO("general:error"), ": ", wO]
        }), bK && (0, uO.jsxs)("div", {
          className: "SettingBox ShaderPackSummary",
          children: [(0, uO.jsxs)("div", {
            className: "ShaderPackSummaryHeader",
            children: [(0, uO.jsxs)("div", {
              children: [(0, uO.jsx)("div", {
                className: "ShaderPackName",
                children: bK.manifest.name
              }), bK.manifest.author && (0, uO.jsx)("div", {
                className: "ShaderPackAuthor",
                children: (0, zK.i)(pO, "shaderPack:byAuthor", {
                  author: bK.manifest.author
                })
              }), bK.manifest.description && (0, uO.jsx)("div", {
                className: "ShaderPackDescription",
                children: bK.manifest.description
              }), bK.listing && (0, uO.jsx)("div", {
                className: "ShaderPackAuthor",
                children: (0, uO.jsx)(iK, {
                  to: (0, LO.Y)(bK.listing.packId),
                  className: "ShaderPackListingLink",
                  children: pO("shaderPackListing:openPackPage")
                })
              })]
            }), (0, uO.jsx)(eO.M, {
              disabled: IO || jK,
              onClick: async function() {
                yK(!0), rK(null), await (0, oO.removeShaderPack)(), lO(null), yK(!1), mK(bK, null, hO)
              },
              children: pO("shaderPack:removePack")
            })]
          }), (0, uO.jsx)(YO, {
            stored: bK,
            checking: gK,
            webGpuUsable: fO,
            changePending: (0, oO.isShaderPackChangePending)(),
            compiler: hO,
            t: pO
          })]
        }), (0, uO.jsx)(AO.e, {
          busy: IO || jK || gK,
          disabled: IO || jK || gK || !0 !== fO,
          onFiles: PO
        })]
      })
    }

    function iK(OO) {
      let {
        to: KO,
        className: pO,
        children: XO
      } = OO;
      const {
        gameState: eO
      } = (0, hO.l)(["gameState"]), {
        pathname: vK,
        search: CO
      } = (0, bK.p)(), MO = "landingPage" !== eO && "studio" !== eO;
      return (0, uO.jsx)(lO.LinkPreserveSearch, {
        to: KO,
        className: pO,
        target: MO ? "_blank" : void 0,
        onClick: () => {
          MO || ((0, LO.G)(`${vK}${CO}`), (0, DO.e)())
        },
        children: XO
      })
    }
  },
  5674: (OO, KO, pO) => {
    pO.d(KO, {
      $: () => rK,
      B: () => QO,
      C: () => uO,
      G: () => DO,
      I: () => jK,
      M: () => VO,
      O: () => HO,
      Q: () => mK,
      S: () => lO,
      V: () => sO,
      Y: () => CO,
      _: () => vK,
      bb: () => PO,
      cb: () => AO,
      db: () => EO,
      e: () => zK,
      g: () => yK,
      h: () => LO,
      i: () => aK,
      k: () => MO,
      n: () => YO,
      r: () => oO,
      v: () => wO,
      w: () => RO,
      z: () => FO
    });
    var XO = pO(5678),
      bK = pO(149),
      eO = pO(3738);
    const lO = "/shader-packs",
      vK = `${lO}/publish`;

    function CO(OO) {
      return `${lO}/${encodeURIComponent(OO)}`
    }
    let hO = null;

    function DO(OO) {
      hO = OO
    }

    function MO() {
      return hO
    }

    function aK() {
      hO = null
    }

    function oO(OO) {
      return OO.playerHasRank("developer") || OO.playerHasRank("admin")
    }
    const FO = ["terrain", "water", "models", "sunShadows", "strict"],
      VO = {
        terrain: "shaderPackListing:filterTerrain",
        water: "shaderPackListing:filterWater",
        models: "shaderPackListing:filterModels",
        sunShadows: "shaderPackListing:filterShadows",
        strict: "shaderPackListing:filterAllGames"
      };

    function LO(OO, KO) {
      return OO.withFeatures.includes(KO) ? "with" : OO.withoutFeatures.includes(KO) ? "without" : null
    }

    function QO(OO) {
      return null === OO ? "with" : "with" === OO ? "without" : null
    }

    function zK(OO) {
      return "with" === OO ? "only" : null === OO ? "include" : void 0
    }

    function AO(OO, KO) {
      const pO = LO(OO, KO),
        XO = OO => OO.filter((OO => OO !== KO));
      return {
        withFeatures: null === pO ? [...OO.withFeatures, KO] : XO(OO.withFeatures),
        withoutFeatures: "with" === pO ? [...OO.withoutFeatures, KO] : XO(OO.withoutFeatures)
      }
    }
    const fO = "section",
      dO = "sort",
      TO = "filters",
      NO = "q",
      IO = "banned",
      yK = "popular",
      gK = "strict";

    function uO(OO) {
      var KO, pO, bK;
      const lO = OO.get(fO),
        vK = (null !== (KO = OO.get(TO)) && void 0 !== KO ? KO : gK).split(","),
        CO = OO.get(IO);
      return {
        section: "favourites" === lO || "mine" === lO ? lO : "explore",
        sort: null !== (pO = XO.v.find((KO => KO === OO.get(dO)))) && void 0 !== pO ? pO : yK,
        withFeatures: FO.filter((OO => vK.includes(OO) && !vK.includes(`-${OO}`))),
        withoutFeatures: FO.filter((OO => vK.includes(`-${OO}`))),
        searchQuery: (null === (bK = OO.get(NO)) || void 0 === bK ? void 0 : bK.slice(0, XO.E)) || null,
        pageNumber: (0, eO.f)(OO.get(eO.d)),
        banned: "only" === CO ? "with" : "include" === CO ? null : "without"
      }
    }

    function EO(OO, KO) {
      var pO;
      const XO = iK(KO);
      (0, eO.g)(OO, fO, "explore" === KO.section ? null : KO.section), (0, eO.g)(OO, dO, KO.sort === yK ? null : KO.sort), (0, eO.g)(OO, TO, XO === gK ? null : XO), (0, eO.g)(OO, NO, KO.searchQuery), (0, eO.g)(OO, IO, null !== (pO = zK(KO.banned)) && void 0 !== pO ? pO : null), (0, eO.k)(OO, KO.pageNumber)
    }

    function jK(OO) {
      const KO = new URLSearchParams;
      return EO(KO, {
        section: "explore",
        sort: yK,
        withFeatures: "strict" === OO ? [OO] : [OO, "strict"],
        withoutFeatures: [],
        searchQuery: null,
        pageNumber: 1,
        banned: "without"
      }), `${lO}?${KO.toString()}`
    }

    function YO(OO) {
      return iK(OO) === gK
    }

    function wO(OO) {
      return null !== OO.searchQuery || "with" === OO.banned || iK(OO) !== gK
    }

    function iK(OO) {
      return FO.flatMap((KO => {
        const pO = LO(OO, KO);
        return "with" === pO ? [KO] : "without" === pO ? [`-${KO}`] : []
      })).join(",")
    }
    const rK = {
        popular: "shaderPackListing:sortPopular",
        updated: "shaderPackListing:sortUpdated",
        newest: "shaderPackListing:sortNewest"
      },
      PO = {
        forest: "shaderPackListing:viewForest",
        desert: "shaderPackListing:viewDesert",
        water: "shaderPackListing:viewWater",
        night: "shaderPackListing:viewNight",
        cave: "shaderPackListing:viewCave"
      };

    function mK(OO) {
      return Math.round(100 * Math.max(0, 1 - 1 / OO))
    }

    function sO(OO, KO, pO, bK) {
      const eO = [];
      OO.isBanned && eO.push({
        tone: "warning",
        text: bK("shaderPackListing:ownerBanned"),
        detail: null
      });
      const {
        pending: lO
      } = OO;
      if (null === OO.brokenError || lO && !lO.error || eO.push({
          tone: "warning",
          text: bK("shaderPackListing:ownerBroken"),
          detail: OO.brokenError
        }), null !== lO && void 0 !== lO && lO.error) eO.push({
        tone: "warning",
        text: bK(KO ? "shaderPackListing:ownerUpdateFailed" : "shaderPackListing:ownerFirstFailed"),
        detail: (0, XO.m)(lO.error) ? null : lO.error
      });
      else if (lO) {
        const OO = null === lO.renderNotBefore ? 0 : lO.renderNotBefore - pO,
          XO = String(Math.ceil(OO / 6e4)),
          vK = bK(KO ? OO > 0 ? "shaderPackListing:ownerUpdateWaiting" : "shaderPackListing:ownerUpdateSoon" : OO > 0 ? "shaderPackListing:ownerFirstWaiting" : "shaderPackListing:ownerFirstSoon", {
            minutes: XO
          });
        eO.push({
          tone: "info",
          text: vK,
          detail: null
        })
      }
      return OO.listed || eO.push({
        tone: "info",
        text: bK("shaderPackListing:ownerUnlisted"),
        detail: null
      }), eO
    }

    function HO(OO) {
      return Math.max(1, Math.round(OO / 1024))
    }

    function RO(OO, KO, pO) {
      return OO instanceof bK.b && OO.errorMessageForUser ? OO.errorMessageForUser : KO(pO)
    }
  },
  5678: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => aK,
      E: () => DO,
      F: () => AO,
      G: () => MO,
      H: () => hO,
      d: () => oO,
      g: () => VO,
      i: () => FO,
      m: () => zK,
      o: () => dO,
      s: () => CO,
      t: () => bK,
      u: () => fO,
      v: () => eO,
      w: () => vK,
      x: () => lO,
      y: () => XO
    });
    const XO = ["forest", "desert", "water", "night", "cave"];
    const bK = {
        full: {
          width: 3840,
          height: 2160
        },
        large: {
          width: 1920,
          height: 1080
        },
        thumb: {
          width: 640,
          height: 360
        }
      },
      eO = ["popular", "updated", "newest"],
      lO = 3,
      vK = 32,
      CO = 300;

    function hO(OO, KO) {
      return OO.slice(0, KO).replace(/[\uD800-\uDBFF]$/, "")
    }
    const DO = 64,
      MO = 512,
      aK = 18e5;
    const oO = "Bloxdhub",
      FO = "https://bloxdhub.com/shaders";

    function VO(OO) {
      return `https://bloxdhub.com/workshop/${encodeURIComponent(OO)}`
    }
    const LO = "Screenshot generation failed.",
      QO = "Its screenshots couldn't be generated:";

    function zK(OO) {
      var KO;
      return OO === LO || null !== (KO = null === OO || void 0 === OO ? void 0 : OO.startsWith(QO)) && void 0 !== KO && KO
    }

    function AO(OO, KO) {
      return `shaderPacks/${OO}/${KO}.json`
    }

    function fO(OO, KO, pO, XO) {
      return null === KO.renderId ? dO(OO, KO.baselineVersion, pO, XO) : `${OO}/${function(OO,KO,pO,XO){return`shaderPacks/${OO}/${KO}/${pO}-${XO}.webp`}(KO.packId,KO.renderId,pO,XO)}`
    }

    function dO(OO, KO, pO, XO) {
      return `${OO}/${function(OO,KO,pO){return`shaderPacks/baseline/${OO}/${KO}-${pO}.webp`}(KO,pO,XO)}`
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);