export const id = 82;
export const ids = [80, 82];
export const modules = {
  35220: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      h: () => FO
    });
    var XO = pO(63),
      bK = pO(2332),
      eO = pO(1263),
      lO = pO(1583),
      vK = pO(35157),
      CO = pO(533),
      hO = pO(918),
      DO = pO.n(hO),
      MO = pO(976);
    const aK = {},
      oO = (0, XO.memo)((function() {
        const OO = (0, bK.b)();
        return (0, eO.f)("damagedByOtherPlayer", (KO => {
          let {
            A7: pO,
            direction: XO
          } = KO;
          const bK = pO || "nonDirectional";
          if (aK[bK]) {
            const KO = aK[bK];
            clearTimeout(KO.timeout), KO.direction = XO, KO.timeout = setTimeout((() => {
              delete aK[bK], OO()
            }), 800)
          } else aK[bK] = {
            direction: XO,
            wpO: null,
            timeout: setTimeout((() => {
              delete aK[bK], OO()
            }), 800)
          };
          OO()
        })), (0, lO.b)("kill", (KO => {
          let {
            killer: pO,
            victim: XO
          } = KO;
          const bK = XO.id;
          pO.local && bK && bK in aK && (clearTimeout(aK[bK].timeout), delete aK[bK], OO())
        })), (0, XO.useEffect)((() => {
          const OO = (0, vK.f)("turnDamageIndicators", FO);
          return () => {
            OO();
            for (const OO in aK) clearTimeout(aK[OO].timeout), delete aK[OO]
          }
        }), []), (0, MO.jsx)("div", {
          className: "DirectionalDamage",
          children: Object.entries(aK).map((OO => {
            let [KO, pO] = OO;
            const XO = (0, CO.I)(pO.direction);
            return (0, MO.jsx)("div", {
              ref: OO => {
                aK[KO] && (aK[KO].wpO = OO)
              },
              className: DO()("DamageIndicator", {
                DamageIndicatorFullCircle: XO
              })
            }, KO)
          }))
        })
      }));

    function FO(OO) {
      for (const KO in aK) {
        const {
          direction: pO,
          wpO: XO
        } = aK[KO];
        if ((0, CO.I)(pO)) continue;
        const bK = pO - OO;
        XO.style.rotate = `${bK}rad`
      }
    }
  },
  35122: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO,
      f: () => hO
    });
    const XO = .1,
      bK = .35,
      eO = .85,
      lO = .06,
      vK = .22;

    function CO(OO) {
      if (OO < XO) return 0;
      if (OO < bK) {
        const KO = (OO - XO) / (bK - XO);
        return lO + (vK - lO) * KO * KO
      }
      return OO < eO ? vK + (1 - vK) * (OO - bK) / (eO - bK) : 1
    }

    function hO(OO) {
      return OO.touchEdgeGuard && OO.touchSpeedCurve
    }
  },
  35151: (OO, KO, pO) => {
    function XO(OO, KO, pO, XO) {
      return !(pO && !OO.aimable) && (!KO || OO.gun && "head" !== XO)
    }

    function bK(OO) {
      return Math.max(.1 * OO, 1)
    }
    pO.d(KO, {
      e: () => bK,
      g: () => XO
    })
  },
  35157: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      f: () => lO
    });
    let XO = null;
    const bK = {
        crosshairAccuracy: [],
        turnDamageIndicators: []
      },
      eO = {
        crosshairAccuracy: OO => {
          const KO = bK.crosshairAccuracy.at(-1);
          KO ? KO.hook(OO) : XO = OO
        },
        turnDamageIndicators: OO => {
          var KO;
          null === (KO = bK.turnDamageIndicators.at(-1)) || void 0 === KO || KO.hook(OO)
        }
      };

    function lO(OO, KO) {
      const pO = {
          hook: KO
        },
        lO = bK[OO];
      if (lO.push(pO), "crosshairAccuracy" === OO && null !== XO) {
        const OO = XO;
        XO = null, eO.crosshairAccuracy(OO)
      }
      return () => {
        const OO = lO.indexOf(pO); - 1 !== OO && lO.splice(OO, 1)
      }
    }

    function vK() {
      return eO
    }
  },
  35162: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      h: () => bK
    });
    var XO = pO(22);

    function bK(OO, KO) {
      return OO && !KO
    }

    function eO() {
      return bK(XO.d.get("isTouchScreen"), XO.d.get("clientEscMenuOptions").touchActionButtons)
    }
  },
  38764: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      startPadGameplay: () => fO
    });
    pO(38642);
    var XO = pO(38644),
      bK = pO(3006),
      eO = pO(22),
      lO = pO(37454),
      vK = pO(2931),
      CO = pO(37460),
      hO = pO(26),
      DO = pO(2231),
      MO = pO(36826),
      aK = pO(7935),
      oO = pO(38648);
    const FO = {
      yawRadPerSec: 0,
      pitchRadPerSec: 0
    };
    var VO = pO(38662),
      LO = pO(7913);
    const QO = OO => OO.padSneakToggled || !!eO.d.get("clientEscMenuOptions").crouchIsToggle && OO.crouchToggled,
      zK = () => {
        const OO = (() => {
          const OO = (0, aK.e)();
          let KO = FO;
          const pO = new oO.c;
          let XO = !1,
            bK = 0;
          const eO = () => {
            const pO = performance.now(),
              eO = 0 === bK ? 0 : pO - bK;
            if (bK = pO, !XO) return OO.discardPending(), null;
            const lO = (0, oO.m)(KO, eO),
              vK = OO.drainLookDelta(),
              CO = (0, MO.m)();
            return {
              wKO: (lO.wKO + vK.wKO) * CO,
              ipO: (lO.ipO + vK.ipO) * CO
            }
          };
          return {
            update: (OO, bK, lO, vK) => {
              OO.camera.zeO !== eO && (OO.camera.zeO = eO), XO = !0, KO = (0, oO.n)(pO, bK, lO, vK, performance.now())
            },
            release: () => {
              XO = !1, KO = FO, pO.reset()
            },
            uninstall: OO => {
              OO.camera.zeO === eO && (OO.camera.zeO = null)
            }
          }
        })();
        return {
          update: (KO, pO, XO) => {
            OO.update((0, DO.d)(), KO, pO, XO)
          },
          release: OO.release,
          uninstall: () => {
            const KO = (0, DO.d)();
            KO && OO.uninstall(KO)
          }
        }
      };
    var AO = pO(38658);
    pO(36048), pO(7789);
    pO(7806).d;
    const fO = () => {
      const OO = (0, AO.e)((() => {
          const OO = {
            x: 0,
            y: 0,
            magnitude: 0,
            headingOffset: 0,
            jumpHeld: !1,
            jumpPressedSinceTick: !1,
            crouchHeld: !1,
            running: !1,
            sprintHeld: !1
          };
          return {
            bodies: () => (0, lO.b)(),
            look: zK(),
            move: (KO, pO) => {
              const XO = (0, DO.d)(),
                bK = XO.tL.JCO();
              if (OO.x = KO.x, OO.y = KO.y, OO.magnitude = KO.magnitude, OO.headingOffset = KO.headingOffset, OO.jumpHeld = KO.jumpHeld, KO.jumpPressed && (OO.jumpPressedSinceTick = !0), OO.running = KO.running, OO.sprintHeld = KO.sprintHeld, pO) {
                const KO = (0, VO.g)({
                  ...pO,
                  descending: XO.tL.qCO(XO.CpO).shouldIgnoreCrouchingSpeedReduction(),
                  canCrouch: !!XO.JV.canCrouch,
                  toggled: QO(bK)
                });
                OO.crouchHeld = KO.crouchHeld, bK.padSneakToggled = KO.toggled, bK.crouchToggled = !1, (0, LO.i)(KO.toggled)
              }
              bK.gamepad = OO
            },
            stopMoving: () => {
              var KO;
              Object.assign(OO, {
                x: 0,
                y: 0,
                magnitude: 0,
                headingOffset: 0,
                jumpHeld: !1,
                jumpPressedSinceTick: !1,
                crouchHeld: !1,
                running: !1,
                sprintHeld: !1
              });
              const pO = null === (KO = (0, DO.d)()) || void 0 === KO ? void 0 : KO.tL.JCO();
              (null === pO || void 0 === pO ? void 0 : pO.gamepad) === OO && (pO.gamepad = null)
            },
            uninstall: () => {},
            deviceChanged: OO => {
              const KO = (0, DO.d)(),
                pO = null === KO || void 0 === KO ? void 0 : KO.tL.JCO();
              "touch" === OO ? ((0, LO.i)(!1), null !== pO && void 0 !== pO && pO.padSneakToggled && (pO.padSneakToggled = !1, pO.isTouchscreen && !pO.gamepad && KO.tL.oCO(KO.CpO).setCrouching(!!KO.JV.canCrouch && pO.touchCrouch))) : "gamepad" === OO && pO && (0, LO.i)(QO(pO))
            },
            hasPlayer: () => {
              var OO;
              return !(null === (OO = (0, DO.d)()) || void 0 === OO || !OO.CpO)
            },
            isPlayerDead: () => {
              var OO;
              const KO = (0, DO.d)();
              return !1 === (null === (OO = KO.tL.rhO(KO.CpO)) || void 0 === OO ? void 0 : OO.isAlive)
            },
            isReplayMode: () => {
              var OO, KO;
              return !(null === (OO = (0, DO.b)()) || void 0 === OO || null === (KO = OO.client) || void 0 === KO || !KO.isReplayMode())
            },
            isFreeCameraOn: () => {
              var OO, KO, pO;
              return !(null === (OO = (0, DO.b)()) || void 0 === OO || null === (KO = OO.client) || void 0 === KO || null === (pO = KO.freeCameraController) || void 0 === pO || !pO.isEnabled())
            },
            targetsBlock: () => !!(0, DO.d)().zCO,
            selectedSlotEmpty: () => {
              var OO;
              const KO = (0, DO.d)();
              return !(null !== (OO = KO.tL.VCO(KO.CpO)) && void 0 !== OO && OO.getItemAtSelectedSlot())
            },
            pickBlockAllowed: () => {
              const OO = (0, DO.d)().JV;
              return !!OO.creative && !!OO.canPickBlocks
            },
            scrollHotbar: OO => {
              hO.i.pl("ScrollInventorySlot", OO)
            },
            hasFullInventory: () => (0, CO.d)((0, DO.d)()),
            hasLobbyLeaderboard: () => !!(0, DO.d)().JV.lobbyLeaderboardInfo,
            contextActionInputs: () => {
              var OO, KO, pO, XO;
              const bK = (0, DO.d)();
              return {
                holdingGun: !(null === (OO = bK.tL.PCO(bK.CpO)) || void 0 === OO || null === (KO = OO.XE) || void 0 === KO || !KO.isGun()),
                customButtons: null !== (pO = bK.JV.customButtons) && void 0 !== pO ? pO : null,
                touchscreenActionButton: null !== (XO = bK.JV.touchscreenActionButton) && void 0 !== XO ? XO : null
              }
            },
            pressTouchButton: OO => {
              (0, vK.sendColyMessage)(bK.mj, OO)
            }
          }
        })()),
        KO = (0, XO.d)(),
        pO = null,
        eO = null;
      return () => {
        OO(), KO(), null === pO || void 0 === pO || pO(), null === eO || void 0 === eO || eO()
      }
    }
  },
  35139: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => zK,
      c: () => eO,
      f: () => VO,
      i: () => LO,
      m: () => vK,
      n: () => aK,
      q: () => QO,
      s: () => MO,
      u: () => AO,
      y: () => FO
    });
    var XO = pO(22),
      bK = pO(26);
    const eO = "clientGameInventoryButtonsChanged",
      lO = new Map;

    function vK() {
      return [...lO.values()].sort(((OO, KO) => {
        var pO, XO;
        return (null !== (pO = OO.order) && void 0 !== pO ? pO : 0) - (null !== (XO = KO.order) && void 0 !== XO ? XO : 0)
      }))
    }
    let CO = null;

    function hO(OO) {
      CO = OO
    }
    let DO = !1;

    function MO(OO) {
      DO = !0;
      try {
        OO.onClick()
      } finally {
        DO = !1
      }
      OO.panel && "clientGame" === XO.d.get("openInGameMenuName") && hO(OO.id)
    }

    function aK() {
      return DO
    }

    function oO() {
      return vK().filter((OO => OO.panel && !OO.disabled))
    }

    function FO(OO) {
      const KO = oO(),
        pO = KO.findIndex((OO => OO.id === CO));
      return !(pO < 0 || KO.length < 2) && (MO(KO[(pO + OO + KO.length) % KO.length]), !0)
    }

    function VO() {
      return null !== CO && oO().length > 1
    }

    function LO() {
      hO(null)
    }

    function QO() {
      "inventory" !== XO.d.get("openInGameMenuName") && hO(null)
    }

    function zK() {
      const OO = CO;
      return hO(null), OO
    }

    function AO(OO) {
      return lO.set(OO.id, OO), bK.i.pl(eO, vK(), !0), () => {
        lO.get(OO.id) === OO && (lO.delete(OO.id), bK.i.pl(eO, vK()))
      }
    }
  },
  35137: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      g: () => LO,
      j: () => QO,
      k: () => aK,
      l: () => hO,
      o: () => VO,
      p: () => oO,
      q: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(1136),
      lO = pO(35139);
    const vK = "clientGameUiChanged";
    let CO = null;

    function hO() {
      return CO
    }

    function DO(OO, KO) {
      const pO = {
        content: OO,
        menu: KO
      };
      return CO = pO, bK.i.pl(vK, CO, !0), () => {
        CO === pO && (CO = null, FO = !1, LO(), bK.i.pl(vK, null))
      }
    }
    let MO = null;

    function aK() {
      return MO
    }

    function oO(OO) {
      return MO = OO, () => {
        MO === OO && (MO = null)
      }
    }
    let FO = !1;

    function VO() {
      const OO = XO.d.get("openInGameMenuName");
      "clientGame" !== OO && (FO = "inventory" === OO), (0, lO.n)() || (0, lO.i)(), (0, eO.k)("InGameMenu"), XO.d.set({
        openInGameMenuName: "clientGame",
        openEverythingMenuName: null
      })
    }

    function LO() {
      zK(!1)
    }

    function QO() {
      zK(FO)
    }

    function zK(OO) {
      "clientGame" === XO.d.get("openInGameMenuName") && XO.d.set({
        openInGameMenuName: OO ? "inventory" : null
      }), OO || (0, lO.i)(), FO = !1
    }
  },
  35017: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO
    });
    var XO = pO(243),
      bK = pO(22),
      eO = pO(35020),
      lO = pO(1441),
      vK = pO(1591);

    function CO(OO, KO) {
      var pO, CO, hO;
      if (!bK.d.get("isKeydownEnabled") || OO.repeat) return;
      const DO = OO.code;
      "Escape" === OO.key ? (0, lO.f)(OO) : null !== (pO = vK.s.OpenSettings) && void 0 !== pO && pO.includes(DO) ? (0, lO.p)(OO, XO.o.SETTINGS) : null !== (CO = vK.s.OpenCharacterCustomization) && void 0 !== CO && CO.includes(DO) ? (0, eO.c)() || (0, lO.p)(OO, XO.o.CUSTOMISATION, KO()) : null !== (hO = vK.s.ShowDebugOverlay) && void 0 !== hO && hO.includes(DO) && bK.d.set({
        showDebugOverlay: !bK.d.get("showDebugOverlay")
      })
    }
  },
  35069: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO,
      f: () => DO,
      h: () => hO,
      j: () => CO
    });
    const XO = 45,
      bK = 6,
      eO = 4;
    let lO = null,
      vK = !1;

    function CO() {
      return vK || (window.addEventListener("resize", hO), vK = !0), lO ??= function() {
        const OO = getComputedStyle(document.documentElement),
          KO = parseFloat(OO.fontSize),
          pO = parseFloat(OO.getPropertyValue("--touch-hotbar-row-reach")) || KO * eO;
        return Math.max(10, 50 - (KO * bK + pO) / window.innerHeight * 100)
      }(), lO
    }

    function hO() {
      lO = null
    }

    function DO(OO, KO, pO, XO) {
      const bK = Math.min(Math.abs(OO) > .001 ? pO / Math.abs(OO) : 1 / 0, Math.abs(KO) > .001 ? XO / Math.abs(KO) : 1 / 0);
      return {
        x: 50 + OO * bK,
        y: 50 + KO * bK
      }
    }
  },
  3988: (OO, KO, pO) => {
    pO.d(KO, {
      Howl: () => XO.Howl,
      b: () => XO.Howler
    });
    var XO = pO(3992);
    XO.Howler._mobileUnloaded = !0
  },
  35011: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => LO,
      g: () => QO
    });
    var XO = pO(886),
      bK = pO(536),
      eO = pO(256),
      lO = pO(888),
      vK = pO(554),
      CO = pO(3710),
      hO = pO(94),
      DO = pO(142),
      MO = pO(1481),
      aK = pO(107),
      oO = pO(35015),
      FO = pO(36),
      VO = pO(959);

    function LO() {
      var OO, KO;
      return [...null !== (OO = navigator.languages) && void 0 !== OO ? OO : [null !== (KO = navigator.language) && void 0 !== KO ? KO : "none"], "En-GB"]
    }

    function QO(OO, KO, pO, QO, zK) {
      const AO = (0, XO.k)(KO) ? (0, XO.o)(KO) : null,
        fO = {
          cookies: (0, MO.getAllCookiesForGameNameWithVariation)(KO),
          isMobile: (0, hO.isMobile)(),
          isUsingCustomGameTexturePack: null !== AO && zK(AO),
          generalCookies: {
            joinDiscord: !!FO.e.getItem("DiscordPressed"),
            newGo: CO.d,
            ...OO.getMetricsCookies(),
            trafficCode: QO,
            compliance: hO.compliance
          },
          browserInfo: {
            ua: window.navigator.userAgent,
            name: (0, hO.getBrowserName)(),
            version: (0, hO.getBrowserVersion)(),
            platform: navigator.platform,
            platformType: (0, hO.getPlatformType)(),
            deviceType: (0, aK.c)()
          },
          isLoggedIn: OO.isLoggedIn(),
          lobbyName: pO,
          languages: LO(),
          version: bK.e,
          siteUsed: DO.t,
          subsiteUsed: DO.A,
          playSessionId: (0, oO.l)(KO),
          visitSessionId: (0, VO.b)(),
          clientReason: vK.i.reason
        };
      return null !== AO && (0, eO.xc)(AO) ? (fO.lobbyName = (0, XO.g)(AO, (0, XO.l)(KO), pO), {
        roomName: `classic_${lO.f}`,
        joinOptions: fO
      }) : {
        roomName: KO,
        joinOptions: fO
      }
    }
  },
  35279: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO,
      e: () => bK,
      g: () => XO
    });

    function XO(OO) {
      return OO.replace(/[_\-\s]*\d+$/, "") || OO
    }

    function bK(OO, KO, pO) {
      return pO <= 0 ? 0 : OO * pO / Math.max(KO, pO)
    }

    function eO(OO, KO) {
      const pO = OO.getDurationMs();
      return pO > 0 ? OO.loudness * Math.max(0, 1 - (KO - OO.startMs) / pO) : 0
    }
    class lO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 24,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 6;
        this.maxVoices = OO, this.maxPerGroup = KO, this.voices = []
      }
      admit(OO) {
        if (this.voices = this.voices.filter((OO => OO.isAlive())), null !== OO.group) {
          const KO = this.voices.filter((KO => KO.group === OO.group));
          if (KO.length >= this.maxPerGroup && !this.dropLeastWorth(KO, OO)) return !1
        }
        return !(this.voices.length >= this.maxVoices && !this.dropLeastWorth(this.voices, OO)) && (this.voices.push(OO), !0)
      }
      dropLeastWorth(OO, KO) {
        let pO = null,
          XO = 1 / 0;
        for (const bK of OO) {
          if (!bK.canStop()) continue;
          const OO = eO(bK, KO.startMs);
          OO < XO && (pO = bK, XO = OO)
        }
        return !(!pO || KO.loudness < XO) && (this.voices.splice(this.voices.indexOf(pO), 1), pO.stop(), !0)
      }
    }
  },
  35290: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      d: () => lO,
      f: () => XO
    });
    class XO {
      constructor(OO) {
        this.multipliers = {}, this._onUpdate = void 0, this._onUpdate = OO
      }
      setMultiplierType(OO, KO) {
        var pO;
        this.multipliers[OO] = KO, null === (pO = this._onUpdate) || void 0 === pO || pO.call(this)
      }
      removeMultiplier(OO) {
        var KO;
        delete this.multipliers[OO], null === (KO = this._onUpdate) || void 0 === KO || KO.call(this)
      }
      getMultiplierType(OO) {
        return this.multipliers[OO]
      }
      getTotalMultipliedVal() {
        let OO = 1;
        for (const KO in this.multipliers) OO *= this.multipliers[KO];
        return OO
      }
    }
    class bK {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        this.booleans = {}, this._onUpdate = void 0, this._onUpdate = OO
      }
      setBooleanType(OO, KO) {
        const pO = this._getTotalBooleanVal();
        this.booleans[OO] = !!KO;
        const XO = this.getTotalBooleanVal();
        var bK;
        XO !== pO && (null === (bK = this._onUpdate) || void 0 === bK || bK.call(this, XO, this.booleans));
        return XO
      }
      removeBoolean(OO) {
        const KO = this._getTotalBooleanVal();
        delete this.booleans[OO];
        const pO = this._getTotalBooleanVal();
        var XO;
        null !== pO && pO !== KO && (null === (XO = this._onUpdate) || void 0 === XO || XO.call(this, pO, this.booleans));
        return null !== pO && void 0 !== pO && pO
      }
      getBooleanType(OO) {
        return this.booleans[OO]
      }
      getTotalBooleanVal() {
        throw new Error("This is an abstract class, use BooleanAndCombinator")
      }
      forceUpdate() {
        var OO;
        null === (OO = this._onUpdate) || void 0 === OO || OO.call(this, this.getTotalBooleanVal(), this.booleans)
      }
      _getTotalBooleanVal() {
        throw new Error("This is an abstract class, use BooleanAndCombinator")
      }
    }
    class eO extends bK {
      getTotalBooleanVal() {
        const OO = this._getTotalBooleanVal();
        if (null === OO) throw new Error("Should not be gotten before at least 1 type has been initialised");
        return OO
      }
      _getTotalBooleanVal() {
        let OO = !1,
          KO = !0;
        for (const pO in this.booleans) OO = !0, KO &&= this.booleans[pO];
        return OO ? KO : null
      }
    }
    class lO extends bK {
      getTotalBooleanVal() {
        const OO = this._getTotalBooleanVal();
        if (null === OO) throw new Error("Should not be gotten before at least 1 type has been initialised");
        return OO
      }
      _getTotalBooleanVal() {
        let OO = !1,
          KO = !1;
        for (const pO in this.booleans) OO = !0, KO ||= this.booleans[pO];
        return OO ? KO : null
      }
    }
  },
  35287: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      g: () => XO,
      h: () => bK
    });
    const XO = 15,
      bK = 3,
      eO = 30
  },
  37470: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      f: () => eO
    });
    var XO = pO(3357);
    let bK = null;

    function eO(OO) {
      return null !== bK && OO === bK
    }

    function lO() {
      this.PXO = !1, this.stopPropagation = !1, this.mbO = !1, this.disabled = !1
    }
    class vK {
      constructor(OO, KO) {
        this.version = "0.7.0";
        var pO = Object.assign({}, new lO, KO || {});
        this.element = OO || document, this.PXO = !!pO.PXO, this.stopPropagation = !!pO.stopPropagation, this.mbO = !!pO.mbO, this.disabled = !!pO.disabled, this.filterEvents = (OO, KO) => !0, this.down = new XO.EventEmitter, this.up = new XO.EventEmitter, this.state = {}, this.HXO = {
          dx: 0,
          dy: 0,
          tCO: 0,
          kCO: 0,
          UvO: 0
        }, this.pressCount = {}, this.releaseCount = {}, this._keyBindmap = {}, this._keyStates = {}, this._bindPressCount = {}, this._touches = {
          lastX: 0,
          lastY: 0,
          currID: null
        }, "loading" !== document.readyState ? hO(this) : document.addEventListener("DOMContentLoaded", (OO => {
          hO(this)
        }), {
          once: !0
        })
      }
      bind(OO) {
        for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
        pO.forEach((KO => {
          var pO = this._keyBindmap[KO] || [];
          pO.includes(OO) || (pO.push(OO), this._keyBindmap[KO] = pO)
        })), this.state[OO] = !!this.state[OO], this.pressCount[OO] = this.pressCount[OO] || 0, this.releaseCount[OO] = this.releaseCount[OO] || 0
      }
      unbind(OO) {
        for (var KO in this._keyBindmap) {
          var pO = this._keyBindmap[KO],
            XO = pO.indexOf(OO);
          XO > -1 && pO.splice(XO, 1)
        }
      }
      getBindings() {
        var OO = {};
        for (var KO in this._keyBindmap) {
          this._keyBindmap[KO].forEach((pO => {
            OO[pO] = OO[pO] || [], OO[pO].push(KO)
          }))
        }
        return OO
      }
      KK() {
        CO(this.HXO), CO(this.pressCount), CO(this.releaseCount)
      }
    }

    function CO(OO) {
      for (var KO in OO) OO[KO] = 0
    }

    function hO(OO) {
      window.addEventListener("keydown", LO.bind(null, OO, !0), !1), window.addEventListener("keyup", LO.bind(null, OO, !1), !1);
      var KO = {
        passive: !0
      };
      OO.element.addEventListener("touchstart", oO.bind(void 0, OO), {
        passive: !1
      }), OO.element.addEventListener("touchend", VO.bind(void 0, OO), KO), OO.element.addEventListener("mousedown", QO.bind(null, OO, !0), KO), window.document.addEventListener("mouseup", QO.bind(null, OO, !1), KO), OO.element.addEventListener("touchmove", zK.bind(null, OO), KO), OO.element.addEventListener("mousemove", zK.bind(null, OO), KO), window.PointerEvent, OO.element.addEventListener("wheel", AO.bind(null, OO), KO), OO.element.addEventListener("contextmenu", fO.bind(null, OO), !1), window.addEventListener("blur", NO.bind(null, OO), !1)
    }
    var DO = 0,
      MO = 0,
      aK = null;

    function oO(OO, KO) {
      KO.preventDefault(), FO(KO)
    }

    function FO(OO) {
      let KO = !1;
      for (let pO = 0; pO < OO.touches.length; ++pO)
        if (OO.touches[pO].identifier === aK) {
          KO = !0;
          break
        } if (!KO) {
        const KO = OO.changedTouches[0];
        DO = KO.clientX, MO = KO.clientY, aK = KO.identifier
      }
    }

    function VO(OO, KO) {
      for (var pO = KO.changedTouches, XO = 0; XO < pO.length; ++XO) pO[XO].identifier === aK && (aK = null)
    }

    function LO(OO, KO, pO) {
      try {
        IO(OO, pO), KO && pO.isTrusted && !pO.repeat && OO._keyStates[pO.code] && yK(OO, pO.code)
      } finally {
        gK(pO.code, KO, OO, pO)
      }
    }

    function QO(OO, KO, pO) {
      try {
        IO(OO, pO)
      } finally {
        ! function(OO, KO, pO) {
          if ("pointerId" in pO)
            if (KO) {
              if (null !== OO._touches.currID) return;
              OO._touches.currID = pO.pointerId
            } else {
              if (OO._touches.currID !== pO.pointerId) return;
              OO._touches.currID = null
            } var XO = "button" in pO ? pO.button + 1 : 1;
          gK("Mouse" + XO, KO, OO, pO)
        }(OO, KO, pO)
      }
    }

    function zK(OO, KO) {
      var pO = KO.movementX || KO.mozMovementX || 0,
        XO = KO.movementY || KO.mozMovementY || 0;
      if (KO.touches && 0 === (pO | XO)) {
        var bK = function(OO) {
          FO(OO);
          for (let KO = 0; KO < OO.changedTouches.length; ++KO)
            if (OO.changedTouches[KO].identifier == aK) {
              const pO = OO.changedTouches[KO],
                XO = [pO.clientX - DO, pO.clientY - MO];
              return DO = pO.clientX, MO = pO.clientY, XO
            } return console.error(`Did not find touch id ${aK}`), [0, 0]
        }(KO);
        pO = bK[0], XO = bK[1]
      }
      OO.HXO.dx += pO, OO.HXO.dy += XO
    }

    function AO(OO, KO) {
      IO(OO, KO);
      var pO = 1;
      switch (KO.deltaMode) {
        case 0:
          pO = 1;
          break;
        case 1:
          pO = 12;
          break;
        case 2:
          pO = OO.element.clientHeight || window.innerHeight
      }
      OO.HXO.tCO += (KO.deltaX || 0) * pO, OO.HXO.kCO += (KO.deltaY || 0) * pO, OO.HXO.UvO += (KO.deltaZ || 0) * pO
    }

    function fO(OO, KO) {
      if (!OO.mbO) return KO.preventDefault(), !1
    }
    var dO = {
      AltLeft: "altKey",
      AltRight: "altKey",
      ControlLeft: "ctrlKey",
      ControlRight: "ctrlKey",
      ShiftLeft: "shiftKey",
      ShiftRight: "shiftKey",
      MetaLeft: "metaKey",
      MetaRight: "metaKey"
    };

    function TO(OO, KO) {
      return !!OO[dO[KO]] || ("AltRight" === KO || "ControlLeft" === KO) && "function" === typeof OO.getModifierState && !0 === OO.getModifierState("AltGraph")
    }

    function NO(OO, KO) {
      for (var pO in OO._modifiersHeldThroughBlur = {}, dO) OO._keyStates[pO] && (OO._modifiersHeldThroughBlur[pO] = !0);
      KO && KO.isTrusted && function() {
        try {
          return window.self !== window.top
        } catch (OO) {
          return !0
        }
      }() && (clearTimeout(OO._blurRelease), OO._blurRelease = setTimeout((function() {
        if (!document.hasFocus())
          for (var KO in OO._modifiersHeldThroughBlur = {}, OO._keyStates) OO._keyStates[KO] && !/^Mouse\d/.test(KO) && yK(OO, KO)
      }), 0))
    }

    function IO(OO, KO) {
      var pO = OO._modifiersHeldThroughBlur;
      if (pO && KO.isTrusted && document.hasFocus())
        for (var XO in pO) delete pO[XO], OO._keyStates[XO] && XO !== KO.code && (TO(KO, XO) || yK(OO, XO))
    }

    function yK(OO, KO) {
      const pO = {
          code: KO,
          preventDefault: () => {},
          stopPropagation: () => {}
        },
        XO = bK;
      bK = pO;
      try {
        gK(KO, !1, OO, pO)
      } finally {
        bK = XO
      }
    }

    function gK(OO, KO, pO, XO) {
      var bK = pO._keyBindmap[OO];
      bK && (uO(pO._keyStates[OO], KO) && (pO._keyStates[OO] = KO, bK.forEach((OO => {
        (!pO.filterEvents || pO.filterEvents(XO, OO)) && function(OO, KO, pO, XO) {
          var bK = KO ? pO.pressCount : pO.releaseCount;
          bK[OO] = (bK[OO] || 0) + 1;
          var eO = pO._bindPressCount[OO] || 0;
          (eO += KO ? 1 : -1) < 0 && (eO = 0);
          pO._bindPressCount[OO] = eO;
          var lO = pO.state[OO];
          if (uO(lO, eO)) {
            pO.state[OO] = eO > 0;
            var vK = KO ? pO.down : pO.up;
            pO.disabled || vK.emit(OO, XO)
          }
        }(OO, KO, pO, XO)
      }))), "button" in XO || (pO.PXO && !XO.defaultPrevented && XO.preventDefault(), pO.stopPropagation && XO.stopPropagation()))
    }

    function uO(OO, KO) {
      return OO ? !KO : KO
    }
  },
  37410: (OO, KO, pO) => {
    function XO(OO, KO, pO, XO, bK) {
      var eO = {};
      return Object.keys(XO).forEach((function(OO) {
        eO[OO] = XO[OO]
      })), eO.enumerable = !!eO.enumerable, eO.configurable = !!eO.configurable, ("value" in eO || eO.initializer) && (eO.writable = !0), eO = pO.slice().reverse().reduce((function(pO, XO) {
        return XO(OO, KO, pO) || pO
      }), eO), bK && void 0 !== eO.initializer && (eO.value = eO.initializer ? eO.initializer.call(bK) : void 0, eO.initializer = void 0), void 0 === eO.initializer && (Object.defineProperty(OO, KO, eO), eO = null), eO
    }
    pO.d(KO, {
      c: () => XO
    })
  },
  37402: (OO, KO, pO) => {
    function XO(OO, KO, pO, XO) {
      pO && Object.defineProperty(OO, KO, {
        enumerable: pO.enumerable,
        configurable: pO.configurable,
        writable: pO.writable,
        value: pO.initializer ? pO.initializer.call(XO) : void 0
      })
    }
    pO.d(KO, {
      e: () => XO
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);