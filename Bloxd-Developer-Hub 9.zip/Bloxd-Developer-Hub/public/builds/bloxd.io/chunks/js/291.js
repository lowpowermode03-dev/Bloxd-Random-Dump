export const id = 291;
export const ids = [291];
export const modules = {
  39833: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => QO
    });
    var XO = pO(35660),
      bK = pO(35632),
      eO = pO(38580),
      lO = pO(38225),
      vK = pO(37996),
      CO = pO(37061),
      hO = pO(38206),
      DO = pO(38235),
      MO = pO(35641),
      aK = pO(37955),
      oO = pO(38186),
      FO = pO(38275);
    class VO {
      get renderList() {
        return this._renderList
      }
      set renderList(OO) {
        this._renderList !== OO && (this._unObserveRenderList && (this._unObserveRenderList(), this._unObserveRenderList = null), OO && (this._unObserveRenderList = (0, MO.g)(OO, this._renderListHasChanged)), this._renderList = OO)
      }
      get disableImageProcessing() {
        return this._disableImageProcessing
      }
      set disableImageProcessing(OO) {
        OO !== this._disableImageProcessing && (this._disableImageProcessing = OO, this._scene.markAllMaterialsAsDirty(64))
      }
      get disableDepthPrePass() {
        return this._disableDepthPrePass
      }
      set disableDepthPrePass(OO) {
        this._disableDepthPrePass = OO, this._renderingManager.disableDepthPrePass = OO
      }
      get name() {
        return this._name
      }
      set name(OO) {
        if (this._name !== OO) {
          if (this._name = OO, this._sceneUBOs)
            for (let OO = 0; OO < this._sceneUBOs.length; ++OO) this._sceneUBOs[OO].name = `Scene ubo #${OO} for ${this.name}`;
          if (this._scene)
            for (let OO = 0; OO < this._renderPassIds.length; ++OO) {
              const KO = this._renderPassIds[OO];
              this._engine._renderPassNames[KO] = `${this._name}#${OO}`
            }
        }
      }
      get renderPassIds() {
        return this._renderPassIds
      }
      get currentRefreshId() {
        return this._currentRefreshId
      }
      getActiveMeshes() {
        return this._activeMeshes
      }
      setMaterialForRendering(OO, KO) {
        let pO;
        pO = Array.isArray(OO) ? OO : [OO];
        for (let XO = 0; XO < pO.length; ++XO)
          for (let OO = 0; OO < this.options.numPasses; ++OO) {
            let bK = pO[XO];
            pO[XO].BKO && (bK = pO[XO].SDO), bK.setMaterialForRenderPass(this._renderPassIds[OO], void 0 !== KO ? Array.isArray(KO) ? KO[OO] : KO : void 0)
          }
      }
      _freezeActiveMeshes(OO) {
        this._freezeActiveMeshesCancel = (0, aK.e)((() => this._checkReadiness()), (() => {
          if (this._freezeActiveMeshesCancel = null, OO)
            for (let OO = 0; OO < this._activeMeshes.length; OO++) this._activeMeshes.data[OO]._freeze();
          this._prepareRenderingManager(0, !0), this._isFrozen = !0
        }), ((OO, KO) => {
          this._freezeActiveMeshesCancel = null, KO ? (CO.b.Error("ObjectRenderer: Timeout while waiting for the renderer to be ready."), OO && CO.b.Error(OO)) : (CO.b.Error("ObjectRenderer: An unexpected error occurred while waiting for the renderer to be ready."), OO && (CO.b.Error(OO), OO.stack && CO.b.Error(OO.stack)))
        }))
      }
      _unfreezeActiveMeshes() {
        this._freezeActiveMeshesCancel?.(), this._freezeActiveMeshesCancel = null;
        for (let OO = 0; OO < this._activeMeshes.length; OO++) this._activeMeshes.data[OO]._unFreeze();
        this._isFrozen = !1
      }
      constructor(OO, KO, pO) {
        this._unObserveRenderList = null, this._renderListHasChanged = (OO, KO) => {
          const pO = this._renderList ? this._renderList.length : 0;
          if (0 === KO && pO > 0 || 0 === pO)
            for (const XO of this._scene.meshes) XO._markSubMeshesAsLightDirty()
        }, this.particleSystemList = null, this.spriteManagerList = null, this.getCustomRenderList = null, this.renderMeshes = !0, this.renderDepthOnlyMeshes = !0, this.renderOpaqueMeshes = !0, this.renderAlphaTestMeshes = !0, this.renderTransparentMeshes = !0, this.renderParticles = !0, this.renderSprites = !1, this.forceLayerMaskCheck = !1, this.enableBoundingBoxRendering = !1, this.enableOutlineRendering = !0, this._disableImageProcessing = !1, this.dontSetTransformationMatrix = !1, this._disableDepthPrePass = !1, this.onBeforeRenderObservable = new XO.e, this.onAfterRenderObservable = new XO.e, this.onBeforeRenderingManagerRenderObservable = new XO.e, this.onAfterRenderingManagerRenderObservable = new XO.e, this.onInitRenderingObservable = new XO.e, this.onFinishRenderingObservable = new XO.e, this.onFastPathRenderObservable = new XO.e, this._currentRefreshId = -1, this._refreshRate = 1, this._currentApplyByPostProcessSetting = !1, this._activeMeshes = new oO.e(256), this._activeBoundingBoxes = new oO.e(32), this._currentFrameId = -1, this._currentSceneUBOIndex = 0, this._isFrozen = !1, this._freezeActiveMeshesCancel = null, this._currentSceneCamera = null, this.name = OO, this._scene = KO, this._engine = this._scene.qb(), this._useUBO = this._engine.supportsUniformBuffers, this.renderList = [], this._renderPassIds = [], this.options = {
          numPasses: 1,
          doNotChangeAspectRatio: !0,
          enableClusteredLights: !1,
          ...pO
        }, this._createRenderPassId(), this.renderPassId = this._renderPassIds[0], this._renderingManager = new DO.b(KO), this._renderingManager._useSceneAutoClearSetup = !0, this.options.enableClusteredLights && this.onInitRenderingObservable.add((() => {
          for (const OO of this._scene.lights) OO.getTypeID() === FO.e.LIGHTTYPEID_CLUSTERED_CONTAINER && OO.isSupported && OO._updateBatches(this.activeCamera).render()
        })), this._scene.addObjectRenderer(this)
      }
      _releaseRenderPassId() {
        for (let OO = 0; OO < this.options.numPasses; ++OO) this._engine.releaseRenderPassId(this._renderPassIds[OO]);
        this._renderPassIds.length = 0
      }
      _createRenderPassId() {
        this._releaseRenderPassId();
        for (let OO = 0; OO < this.options.numPasses; ++OO) this._renderPassIds[OO] = this._engine.createRenderPassId(`${this.name}#${OO}`)
      }
      _createSceneUBO(OO, KO) {
        const pO = this._scene.qb(),
          XO = new hO.d(pO, void 0, KO, OO, void 0, !1);
        return XO.addUniform("viewProjection", 16), KO && XO.addUniform("viewProjectionR", 16), XO.addUniform("view", 16), XO.addUniform("projection", 16), XO.addUniform("vEyePosition", 4), XO.addUniform("inverseProjection", 16), XO
      }
      _getSceneUBO() {
        this._currentFrameId !== this._engine.frameId && (this._currentSceneUBOIndex = 0, this._currentFrameId = this._engine.frameId), this._sceneUBOs || (this._sceneUBOs = [], this._sceneUBOIsMultiview = []);
        const OO = this._engine._currentRenderTarget,
          KO = !(!OO || !OO.texture?.isMultiview) || !!this._scene._multiviewSceneUboIsActive;
        if (this._currentSceneUBOIndex >= this._sceneUBOs.length) {
          const OO = this._sceneUBOs.length;
          this._sceneUBOs.push(this._createSceneUBO(`Scene ubo #${OO} for ${this.name}`, KO)), this._sceneUBOIsMultiview.push(KO)
        } else this._sceneUBOIsMultiview[this._currentSceneUBOIndex] !== KO && (this._sceneUBOs[this._currentSceneUBOIndex].dispose(), this._sceneUBOs[this._currentSceneUBOIndex] = this._createSceneUBO(`Scene ubo #${this._currentSceneUBOIndex} for ${this.name}`, KO), this._sceneUBOIsMultiview[this._currentSceneUBOIndex] = KO);
        const pO = this._sceneUBOs[this._currentSceneUBOIndex++];
        return pO.unbindEffect(), pO
      }
      resetRefreshCounter() {
        this._currentRefreshId = -1
      }
      get refreshRate() {
        return this._refreshRate
      }
      set refreshRate(OO) {
        this._refreshRate = OO, this.resetRefreshCounter()
      }
      shouldRender() {
        return !!this._engine.snapshotRendering || (-1 === this._currentRefreshId || this.refreshRate === this._currentRefreshId ? (this._currentRefreshId = 1, !0) : (this._currentRefreshId++, !1))
      }
      isReadyForRendering(OO, KO) {
        this.prepareRenderList(), this.initRender(OO, KO);
        const pO = this._checkReadiness();
        return this.finishRender(), pO
      }
      prepareRenderList() {
        const OO = this._scene;
        if (this._waitingRenderList) {
          if (!this.renderListPredicate) {
            this.renderList = [];
            for (let KO = 0; KO < this._waitingRenderList.length; KO++) {
              const pO = this._waitingRenderList[KO],
                XO = OO.getMeshById(pO);
              XO && this.renderList.push(XO)
            }
          }
          this._waitingRenderList = void 0
        }
        if (this.renderListPredicate) {
          this.renderList ? this.renderList.length = 0 : this.renderList = [];
          const OO = this._scene.meshes;
          for (let KO = 0; KO < OO.length; KO++) {
            const pO = OO[KO];
            this.renderListPredicate(pO) && this.renderList.push(pO)
          }
        }
        this._currentApplyByPostProcessSetting = this._scene.imageProcessingConfiguration.applyByPostProcess, this._disableImageProcessing && (this._scene.imageProcessingConfiguration._applyByPostProcess = this._disableImageProcessing)
      }
      initRender(OO, KO) {
        const pO = this.activeCamera ?? this._scene.activeCamera;
        this._currentSceneCamera = this._scene.activeCamera, this._useUBO && (this._currentSceneUBO = this._scene.getSceneUniformBuffer(), this._currentSceneUBO.unbindEffect(), this._scene.setSceneUniformBuffer(this._getSceneUBO())), this.onInitRenderingObservable.notifyObservers(this), pO && (this.dontSetTransformationMatrix || this._scene.setTransformMatrix(pO.getViewMatrix(), pO.getProjectionMatrix(!0)), this._scene._activeCamera = pO, this._engine.setViewport(pO.rigParent ? pO.rigParent.viewport : pO.viewport, OO, KO)), this._useUBO && this._scene.finalizeSceneUbo(), this._defaultRenderListPrepared = !1
      }
      finishRender() {
        const OO = this._scene;
        this._useUBO && this._scene.setSceneUniformBuffer(this._currentSceneUBO), this._disableImageProcessing && (OO.imageProcessingConfiguration._applyByPostProcess = this._currentApplyByPostProcessSetting), OO._activeCamera = this._currentSceneCamera, this._currentSceneCamera && (this.activeCamera && this.activeCamera !== OO.activeCamera && OO.setTransformMatrix(this._currentSceneCamera.getViewMatrix(), this._currentSceneCamera.getProjectionMatrix(!0)), this._engine.setViewport(this._currentSceneCamera.viewport)), OO.resetCachedMaterial(), this.onFinishRenderingObservable.notifyObservers(this)
      }
      render() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = this._engine.currentRenderPassId;
        this._engine.currentRenderPassId = this._renderPassIds[OO], this.onBeforeRenderObservable.notifyObservers(OO);
        if (this._engine.snapshotRendering && 1 === this._engine.snapshotRenderingMode) this.onFastPathRenderObservable.notifyObservers(OO);
        else {
          const KO = this._prepareRenderingManager(OO),
            pO = this._scene.getOutlineRenderer?.(),
            XO = pO?.enabled;
          pO && (pO.enabled = this.enableOutlineRendering), this.onBeforeRenderingManagerRenderObservable.notifyObservers(OO), this._renderingManager.render(this.customRenderFunction, KO, this.renderParticles, this.renderSprites, this.renderDepthOnlyMeshes, this.renderOpaqueMeshes, this.renderAlphaTestMeshes, this.renderTransparentMeshes, this.customRenderTransparentSubMeshes, this.spriteManagerList), this.onAfterRenderingManagerRenderObservable.notifyObservers(OO), pO && (pO.enabled = XO)
        }
        KO || this.onAfterRenderObservable.notifyObservers(OO), this._engine.currentRenderPassId = pO
      }
      _checkReadiness() {
        const OO = this._scene,
          KO = this._engine.currentRenderPassId;
        let pO = !0;
        OO.getViewMatrix() || OO.updateTransformMatrix();
        const XO = this.options.numPasses;
        for (let bK = 0; bK < XO && pO; bK++) {
          const KO = this.renderList ? this.renderList : OO.frameGraph ? OO.meshes : OO.getActiveMeshes().data,
            eO = this.renderList || OO.frameGraph ? KO.length : OO.getActiveMeshes().length;
          this._engine.currentRenderPassId = this._renderPassIds[bK], this.onBeforeRenderObservable.notifyObservers(bK);
          let lO = null,
            vK = eO;
          this.getCustomRenderList && (lO = this.getCustomRenderList(bK, KO, eO), lO && (vK = lO.length)), lO || (lO = KO), this.options.doNotChangeAspectRatio || OO.updateTransformMatrix(!0);
          for (let OO = 0; OO < vK && pO; ++OO) {
            const KO = lO[OO];
            if (!KO.isEnabled() || KO.isBlocked || !KO.isVisible || !KO.au) continue;
            if (this.customIsReadyFunction) {
              if (!this.customIsReadyFunction(KO, this.refreshRate, !0)) {
                pO = !1;
                continue
              }
            } else if (!KO.isReady(!0)) {
              pO = !1;
              continue
            }
            let XO = KO._edgesRenderer,
              bK = KO.hasThinInstances;
            if (KO.BKO) {
              const OO = KO.SDO;
              OO.edgesShareWithInstances && OO._edgesRenderer?.isEnabled && (XO = OO._edgesRenderer, bK = !0)
            } else KO.RDO && KO.edgesShareWithInstances && (bK = !0);
            !this.customRenderFunction && this.renderOpaqueMeshes && XO?.isEnabled && (XO.isReady(bK) || (pO = !1))
          }
          if (this.renderParticles && OO.particlesEnabled) {
            const KO = this.particleSystemList || OO.ku;
            for (const OO of KO) OO.isReady() || (pO = !1)
          }
          if (this.renderSprites && OO.spritesEnabled) {
            const KO = this.spriteManagerList || OO.spriteManagers;
            if (KO)
              for (const XO of KO) OO.activeCamera && 0 === (XO.layerMask & OO.activeCamera.layerMask) || XO.isReady && !XO.isReady() && (pO = !1)
          }
          this.onAfterRenderObservable.notifyObservers(bK), XO > 1 && (OO.incrementRenderId(), OO.resetCachedMaterial())
        }
        return this._engine.currentRenderPassId = KO, pO
      }
      _prepareRenderingManager() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = this._scene;
        let XO, bK, eO = null;
        const lO = this.renderList ? this.renderList : pO.frameGraph ? pO.meshes : pO.getActiveMeshes().data,
          vK = this.renderList || pO.frameGraph ? lO.length : pO.getActiveMeshes().length;
        if (this.getCustomRenderList && (eO = this.getCustomRenderList(OO, lO, vK)), eO) XO = eO.length, bK = this.forceLayerMaskCheck;
        else {
          if (this._defaultRenderListPrepared && !KO && !this._engine.isWebGPU) return lO;
          this._defaultRenderListPrepared = !0, eO = lO, XO = vK, bK = !this.renderList || this.forceLayerMaskCheck
        }
        const CO = pO.activeCamera,
          hO = this.cameraForLOD ?? CO,
          DO = pO.getBoundingBoxRenderer?.();
        if (pO._activeMeshesFrozen && this._isFrozen) {
          if (this._renderingManager.resetSprites(), this.enableBoundingBoxRendering && DO) {
            DO.reset();
            for (let OO = 0; OO < this._activeBoundingBoxes.length; OO++) {
              const KO = this._activeBoundingBoxes.data[OO];
              DO.renderList.push(KO)
            }
          }
          return eO
        }
        if (this._renderingManager.reset(), this._activeMeshes.reset(), this._activeBoundingBoxes.reset(), DO && DO.reset(), this.renderMeshes) {
          const OO = pO.getRenderId(),
            KO = pO.getFrameId();
          for (let lO = 0; lO < XO; lO++) {
            const XO = eO[lO];
            if (XO && !XO.isBlocked) {
              if (this.customIsReadyFunction) {
                if (!this.customIsReadyFunction(XO, this.refreshRate, !1)) {
                  this.resetRefreshCounter();
                  continue
                }
              } else if (!XO.isReady(0 === this.refreshRate)) {
                this.resetRefreshCounter();
                continue
              }
              let eO, lO;
              if (hO) {
                const OO = XO._internalAbstractMeshDataInfo._currentLOD.get(hO);
                OO && OO[1] === KO ? eO = OO[0] : (eO = pO.customLODSelector ? pO.customLODSelector(XO, hO) : XO.getLOD(hO), OO ? (OO[0] = eO, OO[1] = KO) : XO._internalAbstractMeshDataInfo._currentLOD.set(hO, [eO, KO]))
              } else eO = XO;
              if (!eO) continue;
              if (eO !== XO && 0 !== eO.billboardMode && eO.computeWorldMatrix(), eO._preActivateForIntermediateRendering(OO), lO = !(!bK || !CO) && 0 === (XO.layerMask & CO.layerMask), XO.isEnabled() && XO.isVisible && XO.au && !lO) {
                if (this._activeMeshes.push(XO), eO._internalAbstractMeshDataInfo._wasActiveLastFrame = !0, eO !== XO && eO._activate(OO, !0), this.enableBoundingBoxRendering && DO && DO._preActiveMesh(XO), XO._activate(OO, !0) && XO.au.length) {
                  XO.BKO ? XO._internalAbstractMeshDataInfo._actAsRegularMesh && (eO = XO) : eO._internalAbstractMeshDataInfo._onlyForInstancesIntermediate = !1, eO._internalAbstractMeshDataInfo._isActiveIntermediate = !0, pO._prepareSkeleton(eO);
                  for (let OO = 0; OO < eO.au.length; OO++) {
                    const KO = eO.au[OO];
                    this.enableBoundingBoxRendering && DO && DO._evaluateSubMesh(XO, KO), this._renderingManager.dispatch(KO, eO)
                  }
                }
                XO._postActivate()
              }
            }
          }
        }
        if (this.enableBoundingBoxRendering && DO && KO)
          for (let MO = 0; MO < DO.renderList.length; MO++) {
            const OO = DO.renderList.data[MO];
            this._activeBoundingBoxes.push(OO)
          }
        if (this._scene.particlesEnabled && this.renderParticles) {
          this._scene.onBeforeParticlesRenderingObservable.notifyObservers(this._scene);
          const OO = this.particleSystemList || pO.ku;
          for (let KO = 0; KO < OO.length; KO++) {
            const pO = OO[KO],
              XO = pO.emitter;
            pO.isStarted() && XO && (!XO.position || XO.isEnabled()) && this._renderingManager.dispatchParticles(pO)
          }
          this._scene.onAfterParticlesRenderingObservable.notifyObservers(this._scene)
        }
        return eO
      }
      get renderingManager() {
        return this._renderingManager
      }
      setRenderingOrder(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        this._renderingManager.setRenderingOrder(OO, KO, pO, XO)
      }
      setRenderingAutoClearDepthStencil(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
          XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        this._renderingManager.setRenderingAutoClearDepthStencil(OO, KO, pO, XO), this._renderingManager._useSceneAutoClearSetup = !1
      }
      clone() {
        const OO = new VO(this.name, this._scene, this.options);
        return this.renderList && (OO.renderList = this.renderList.slice(0)), OO
      }
      dispose() {
        const OO = this.renderList ? this.renderList : this._scene.getActiveMeshes().data,
          KO = this.renderList ? this.renderList.length : this._scene.getActiveMeshes().length;
        for (let pO = 0; pO < KO; pO++) {
          const KO = OO[pO];
          KO && void 0 !== KO.getMaterialForRenderPass(this.renderPassId) && KO.setMaterialForRenderPass(this.renderPassId, void 0)
        }
        if (this.onInitRenderingObservable.clear(), this.onFinishRenderingObservable.clear(), this.onBeforeRenderObservable.clear(), this.onAfterRenderObservable.clear(), this.onBeforeRenderingManagerRenderObservable.clear(), this.onAfterRenderingManagerRenderObservable.clear(), this.onFastPathRenderObservable.clear(), this._releaseRenderPassId(), this.renderList = null, this._sceneUBOs)
          for (const pO of this._sceneUBOs) pO.dispose();
        this._sceneUBOs = void 0, this._scene.removeObjectRenderer(this)
      }
      _rebuild() {
        this.refreshRate === VO.REFRESHRATE_RENDER_ONCE && (this.refreshRate = VO.REFRESHRATE_RENDER_ONCE)
      }
      freeRenderingGroups() {
        this._renderingManager && this._renderingManager.freeRenderingGroups()
      }
    }
    VO.REFRESHRATE_RENDER_ONCE = 0, VO.REFRESHRATE_RENDER_ONEVERYFRAME = 1, VO.REFRESHRATE_RENDER_ONEVERYTWOFRAMES = 2;
    var LO = pO(37938);
    class QO extends eO.e {
      get renderListPredicate() {
        return this._objectRenderer.renderListPredicate
      }
      set renderListPredicate(OO) {
        this._objectRenderer.renderListPredicate = OO
      }
      get renderList() {
        return this._objectRenderer.renderList
      }
      set renderList(OO) {
        this._objectRenderer.renderList = OO
      }
      get particleSystemList() {
        return this._objectRenderer.particleSystemList
      }
      set particleSystemList(OO) {
        this._objectRenderer.particleSystemList = OO
      }
      get getCustomRenderList() {
        return this._objectRenderer.getCustomRenderList
      }
      set getCustomRenderList(OO) {
        this._objectRenderer.getCustomRenderList = OO
      }
      get renderParticles() {
        return this._objectRenderer.renderParticles
      }
      set renderParticles(OO) {
        this._objectRenderer.renderParticles = OO
      }
      get renderSprites() {
        return this._objectRenderer.renderSprites
      }
      set renderSprites(OO) {
        this._objectRenderer.renderSprites = OO
      }
      get enableBoundingBoxRendering() {
        return this._objectRenderer.enableBoundingBoxRendering
      }
      set enableBoundingBoxRendering(OO) {
        this._objectRenderer.enableBoundingBoxRendering = OO
      }
      get enableOutlineRendering() {
        return this._objectRenderer.enableOutlineRendering
      }
      set enableOutlineRendering(OO) {
        this._objectRenderer.enableOutlineRendering = OO
      }
      get forceLayerMaskCheck() {
        return this._objectRenderer.forceLayerMaskCheck
      }
      set forceLayerMaskCheck(OO) {
        this._objectRenderer.forceLayerMaskCheck = OO
      }
      get activeCamera() {
        return this._objectRenderer.activeCamera
      }
      set activeCamera(OO) {
        this._objectRenderer.activeCamera = OO
      }
      get cameraForLOD() {
        return this._objectRenderer.cameraForLOD
      }
      set cameraForLOD(OO) {
        this._objectRenderer.cameraForLOD = OO
      }
      get disableImageProcessing() {
        return this._objectRenderer.disableImageProcessing
      }
      set disableImageProcessing(OO) {
        this._objectRenderer.disableImageProcessing = OO
      }
      get customIsReadyFunction() {
        return this._objectRenderer.customIsReadyFunction
      }
      set customIsReadyFunction(OO) {
        this._objectRenderer.customIsReadyFunction = OO
      }
      get customRenderFunction() {
        return this._objectRenderer.customRenderFunction
      }
      set customRenderFunction(OO) {
        this._objectRenderer.customRenderFunction = OO
      }
      get postProcesses() {
        return this._postProcesses
      }
      get _prePassEnabled() {
        return !!this._prePassRenderTarget && this._prePassRenderTarget.enabled
      }
      set onAfterUnbind(OO) {
        this._onAfterUnbindObserver && this.onAfterUnbindObservable.remove(this._onAfterUnbindObserver), this._onAfterUnbindObserver = this.onAfterUnbindObservable.add(OO)
      }
      get onBeforeRenderObservable() {
        return this._objectRenderer.onBeforeRenderObservable
      }
      set onBeforeRender(OO) {
        this._onBeforeRenderObserver && this.onBeforeRenderObservable.remove(this._onBeforeRenderObserver), this._onBeforeRenderObserver = this.onBeforeRenderObservable.add(OO)
      }
      get onAfterRenderObservable() {
        return this._objectRenderer.onAfterRenderObservable
      }
      set onAfterRender(OO) {
        this._onAfterRenderObserver && this.onAfterRenderObservable.remove(this._onAfterRenderObserver), this._onAfterRenderObserver = this.onAfterRenderObservable.add(OO)
      }
      set onClear(OO) {
        this._onClearObserver && this.onClearObservable.remove(this._onClearObserver), this._onClearObserver = this.onClearObservable.add(OO)
      }
      get _waitingRenderList() {
        return this._objectRenderer._waitingRenderList
      }
      set _waitingRenderList(OO) {
        this._objectRenderer._waitingRenderList = OO
      }
      get renderPassId() {
        return this._objectRenderer.renderPassId
      }
      get renderPassIds() {
        return this._objectRenderer.renderPassIds
      }
      get currentRefreshId() {
        return this._objectRenderer.currentRefreshId
      }
      setMaterialForRendering(OO, KO) {
        this._objectRenderer.setMaterialForRendering(OO, KO)
      }
      get isMulti() {
        return this._renderTarget?.isMulti ?? !1
      }
      get renderTargetOptions() {
        return this._renderTargetOptions
      }
      get renderTarget() {
        return this._renderTarget
      }
      _onRatioRescale() {
        this._sizeRatio && this.resize(this._initialSizeParameter)
      }
      set boundingBoxSize(OO) {
        if (this._boundingBoxSize && this._boundingBoxSize.equals(OO)) return;
        this._boundingBoxSize = OO;
        const KO = this.JKO();
        KO && KO.markAllMaterialsAsDirty(1)
      }
      get boundingBoxSize() {
        return this._boundingBoxSize
      }
      get depthStencilTexture() {
        return this._renderTarget?._depthStencilTexture ?? null
      }
      constructor(OO, KO, pO) {
        let lO, vK, hO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          DO = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
          MO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
          aK = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
          oO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : eO.e.TRILINEAR_SAMPLINGMODE,
          FO = !(arguments.length > 8 && void 0 !== arguments[8]) || arguments[8],
          LO = arguments.length > 9 && void 0 !== arguments[9] && arguments[9],
          QO = arguments.length > 10 && void 0 !== arguments[10] && arguments[10],
          zK = arguments.length > 11 && void 0 !== arguments[11] ? arguments[11] : 5,
          AO = arguments.length > 12 && void 0 !== arguments[12] && arguments[12],
          fO = arguments.length > 13 ? arguments[13] : void 0,
          dO = arguments.length > 14 ? arguments[14] : void 0,
          TO = arguments.length > 15 && void 0 !== arguments[15] && arguments[15],
          NO = arguments.length > 16 && void 0 !== arguments[16] && arguments[16],
          IO = !0,
          yK = !1;
        if ("object" === typeof hO) {
          const OO = hO;
          hO = !!OO.generateMipMaps, DO = OO.doNotChangeAspectRatio ?? !0, MO = OO.type ?? 0, aK = !!OO.isCube, oO = OO.samplingMode ?? eO.e.TRILINEAR_SAMPLINGMODE, FO = OO.generateDepthBuffer ?? !0, LO = !!OO.generateStencilBuffer, QO = !!OO.isMulti, zK = OO.format ?? 5, AO = !!OO.delayAllocation, fO = OO.samples, dO = OO.creationFlags, TO = !!OO.noColorAttachment, NO = !!OO.useSRGBBuffer, lO = OO.colorAttachment, IO = OO.gammaSpace ?? IO, vK = OO.existingObjectRenderer, yK = !!OO.enableClusteredLights
        }
        if (super(null, pO, !hO, void 0, oO, void 0, void 0, void 0, void 0, zK), this.ignoreCameraViewport = !1, this.onBeforeBindObservable = new XO.e, this.onAfterUnbindObservable = new XO.e, this.onClearObservable = new XO.e, this.onResizeObservable = new XO.e, this._cleared = !1, this.skipInitialClear = !1, this._samples = 1, this._canRescale = !0, this._renderTarget = null, this._dontDisposeObjectRenderer = !1, this.boundingBoxPosition = bK.o.Zero(), this._disableEngineStages = !1, this._dumpToolsLoading = !1, !(pO = this.JKO())) return;
        const gK = this.JKO().qb();
        this._gammaSpace = IO, this._coordinatesMode = eO.e.PROJECTION_MODE, this.name = OO, this.isRenderTarget = !0, this._initialSizeParameter = KO, this._dontDisposeObjectRenderer = !!vK, this._processSizeParameter(KO), this._objectRenderer = vK ?? new VO(OO, pO, {
          numPasses: aK ? 6 : this.getRenderLayers() || 1,
          doNotChangeAspectRatio: DO,
          enableClusteredLights: yK
        }), this._onBeforeRenderingManagerRenderObserver = this._objectRenderer.onBeforeRenderingManagerRenderObservable.add((() => {
          const OO = this._scene;
          if (!this._disableEngineStages)
            for (const KO of OO._beforeRenderTargetClearStage) KO.action(this, this._currentFaceIndex, this._currentLayer);
          if (this.onClearObservable.hasObservers() ? this.onClearObservable.notifyObservers(gK) : this.skipInitialClear || gK.clear(this.clearColor ?? OO.clearColor, !0, !0, !0), this._doNotChangeAspectRatio || OO.updateTransformMatrix(!0), !this._disableEngineStages)
            for (const KO of OO._beforeRenderTargetDrawStage) KO.action(this, this._currentFaceIndex, this._currentLayer);
          gK._debugPushGroup && gK._debugPushGroup(`Render to ${this.name} (face #${this._currentFaceIndex} layer #${this._currentLayer})`)
        })), this._onAfterRenderingManagerRenderObserver = this._objectRenderer.onAfterRenderingManagerRenderObservable.add((() => {
          if (gK._debugPopGroup && gK._debugPopGroup(), !this._disableEngineStages)
            for (const KO of this._scene._afterRenderTargetDrawStage) KO.action(this, this._currentFaceIndex, this._currentLayer);
          const OO = this._texture?.generateMipMaps ?? !1;
          if (this._texture && (this._texture.generateMipMaps = !1), this._postProcessManager ? this._postProcessManager._finalizeFrame(!1, this._renderTarget ?? void 0, this._currentFaceIndex, this._postProcesses, this.ignoreCameraViewport) : this._currentUseCameraPostProcess && this._scene.postProcessManager._finalizeFrame(!1, this._renderTarget ?? void 0, this._currentFaceIndex), !this._disableEngineStages)
            for (const KO of this._scene._afterRenderTargetPostProcessStage) KO.action(this, this._currentFaceIndex, this._currentLayer);
          this._texture && (this._texture.generateMipMaps = OO), this._doNotChangeAspectRatio || this._scene.updateTransformMatrix(!0), this._currentDumpForDebug && (this._dumpTools ? this._dumpTools.DumpFramebuffer(this.getRenderWidth(), this.getRenderHeight(), gK) : CO.b.Error("dumpTools module is still being loaded. To speed up the process import dump tools directly in your project"))
        })), this._onFastPathRenderObserver = this._objectRenderer.onFastPathRenderObservable.add((() => {
          this.onClearObservable.hasObservers() ? this.onClearObservable.notifyObservers(gK) : this.skipInitialClear || gK.clear(this.clearColor || this._scene.clearColor, !0, !0, !0)
        })), this._resizeObserver = gK.onResizeObservable.add((() => {})), this._generateMipMaps = !!hO, this._doNotChangeAspectRatio = DO, QO || (this._renderTargetOptions = {
          generateMipMaps: hO,
          type: MO,
          format: this._format ?? void 0,
          samplingMode: this.samplingMode,
          generateDepthBuffer: FO,
          generateStencilBuffer: LO,
          samples: fO,
          creationFlags: dO,
          noColorAttachment: TO,
          useSRGBBuffer: NO,
          colorAttachment: lO,
          label: this.name
        }, this.samplingMode === eO.e.NEAREST_SAMPLINGMODE && (this.wrapU = eO.e.CLAMP_ADDRESSMODE, this.wrapV = eO.e.CLAMP_ADDRESSMODE), AO || (aK ? (this._renderTarget = pO.qb().createRenderTargetCubeTexture(this.getRenderSize(), this._renderTargetOptions), this.coordinatesMode = eO.e.INVCUBIC_MODE, this._textureMatrix = bK.c.Identity()) : this._renderTarget = pO.qb().createRenderTargetTexture(this._size, this._renderTargetOptions), this._texture = this._renderTarget.texture, void 0 !== fO && (this.samples = fO)))
      }
      createDepthStencilTexture() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 14,
          eO = arguments.length > 5 ? arguments[5] : void 0;
        this._renderTarget?.createDepthStencilTexture(OO, KO, pO, XO, bK, eO)
      }
      _processSizeParameter(OO) {
        if (OO.ratio) {
          this._sizeRatio = OO.ratio;
          const KO = this._getEngine();
          this._size = {
            width: this._bestReflectionRenderTargetDimension(KO.getRenderWidth(), this._sizeRatio),
            height: this._bestReflectionRenderTargetDimension(KO.getRenderHeight(), this._sizeRatio)
          }
        } else this._size = OO
      }
      get samples() {
        return this._renderTarget?.samples ?? this._samples
      }
      set samples(OO) {
        this._renderTarget && (this._samples = this._renderTarget.setSamples(OO))
      }
      addPostProcess(OO) {
        if (!this._postProcessManager) {
          const OO = this.JKO();
          if (!OO) return;
          this._postProcessManager = new lO.b(OO), this._postProcesses = new Array
        }
        this._postProcesses.push(OO), this._postProcesses[0].autoClear = !1
      }
      clearPostProcesses() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        if (this._postProcesses) {
          if (OO)
            for (const OO of this._postProcesses) OO.dispose();
          this._postProcesses = []
        }
      }
      removePostProcess(OO) {
        if (!this._postProcesses) return;
        const KO = this._postProcesses.indexOf(OO); - 1 !== KO && (this._postProcesses.splice(KO, 1), this._postProcesses.length > 0 && (this._postProcesses[0].autoClear = !1))
      }
      resetRefreshCounter() {
        this._objectRenderer.resetRefreshCounter()
      }
      get refreshRate() {
        return this._objectRenderer.refreshRate
      }
      set refreshRate(OO) {
        this._objectRenderer.refreshRate = OO
      }
      _shouldRender() {
        return this._objectRenderer.shouldRender()
      }
      getRenderSize() {
        return this.getRenderWidth()
      }
      getRenderWidth() {
        return this._size.width ? this._size.width : this._size
      }
      getRenderHeight() {
        return this._size.width ? this._size.height : this._size
      }
      getRenderLayers() {
        const OO = this._size.layers;
        if (OO) return OO;
        const KO = this._size.depth;
        return KO || 0
      }
      disableRescaling() {
        this._canRescale = !1
      }
      get canRescale() {
        return this._canRescale
      }
      scale(OO) {
        const KO = Math.max(1, this.getRenderSize() * OO);
        this.resize(KO)
      }
      getReflectionTextureMatrix() {
        return this.isCube ? this._textureMatrix : super.getReflectionTextureMatrix()
      }
      resize(OO) {
        const KO = this.isCube;
        this._renderTarget?.dispose(), this._renderTarget = null;
        const pO = this.JKO();
        pO && (this._processSizeParameter(OO), this._renderTarget = KO ? pO.qb().createRenderTargetCubeTexture(this.getRenderSize(), this._renderTargetOptions) : pO.qb().createRenderTargetTexture(this._size, this._renderTargetOptions), this._texture = this._renderTarget.texture, void 0 !== this._renderTargetOptions.samples && (this.samples = this._renderTargetOptions.samples), this.onResizeObservable.hasObservers() && this.onResizeObservable.notifyObservers(this))
      }
      render() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        this._render(OO, KO)
      }
      isReadyForRendering() {
        this._dumpToolsLoading || (this._dumpToolsLoading = !0, Promise.resolve().then((() => pO(39846))).then((OO => this._dumpTools = OO))), this._objectRenderer.prepareRenderList(), this.onBeforeBindObservable.notifyObservers(this), this._objectRenderer.initRender(this.getRenderWidth(), this.getRenderHeight());
        const OO = this._objectRenderer._checkReadiness();
        return this.onAfterUnbindObservable.notifyObservers(this), this._objectRenderer.finishRender(), OO
      }
      _render() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = this.JKO();
        if (!pO) return;
        void 0 !== this.useCameraPostProcesses && (OO = this.useCameraPostProcesses);
        const XO = pO.qb();
        if (XO._debugPushGroup && XO._debugPushGroup(`Render to ${this.name}`), this._objectRenderer.prepareRenderList(), this.onBeforeBindObservable.notifyObservers(this), this._objectRenderer.initRender(this.getRenderWidth(), this.getRenderHeight()), !this.is2DArray && !this.is3D || this.isMulti)
          if (this.isCube && !this.isMulti)
            for (let bK = 0; bK < 6; bK++) this._renderToTarget(bK, OO, KO), pO.incrementRenderId(), pO.resetCachedMaterial();
          else this._renderToTarget(0, OO, KO);
        else
          for (let bK = 0; bK < this.getRenderLayers(); bK++) this._renderToTarget(0, OO, KO, bK), pO.incrementRenderId(), pO.resetCachedMaterial();
        this.onAfterUnbindObservable.notifyObservers(this), this._objectRenderer.finishRender(), XO._debugPopGroup && XO._debugPopGroup()
      }
      _bestReflectionRenderTargetDimension(OO, KO) {
        const pO = OO * KO,
          XO = (0, vK.o)(pO + 16384 / (128 + pO));
        return Math.min((0, vK.e)(OO), XO)
      }
      _bindFrameBuffer() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        const pO = this.JKO();
        if (!pO) return;
        const XO = pO.qb();
        this._renderTarget && XO.bindFramebuffer(this._renderTarget, this.isCube ? OO : void 0, void 0, void 0, this.ignoreCameraViewport, 0, KO)
      }
      _unbindFrameBuffer(OO, KO) {
        this._renderTarget && OO.unBindFramebuffer(this._renderTarget, this.isCube, (() => {
          this.onAfterRenderObservable.notifyObservers(KO)
        }))
      }
      _prepareFrame(OO, KO, pO, XO) {
        this._postProcessManager ? this._prePassEnabled || this._postProcessManager._prepareFrame(this._texture, this._postProcesses) || this._bindFrameBuffer(KO, pO) : XO && OO.postProcessManager._prepareFrame(this._texture) || this._bindFrameBuffer(KO, pO)
      }
      _renderToTarget(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        const bK = this.JKO();
        if (!bK) return;
        const eO = bK.qb();
        this._currentFaceIndex = OO, this._currentLayer = XO, this._currentUseCameraPostProcess = KO, this._currentDumpForDebug = pO, this._prepareFrame(bK, OO, XO, KO), this._objectRenderer.render(OO + XO, !0), this._unbindFrameBuffer(eO, OO), this._texture && this.isCube && 5 === OO && eO.generateMipMapsForCubemap(this._texture, !0)
      }
      setRenderingOrder(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        this._objectRenderer.setRenderingOrder(OO, KO, pO, XO)
      }
      setRenderingAutoClearDepthStencil(OO, KO) {
        this._objectRenderer.setRenderingAutoClearDepthStencil(OO, KO)
      }
      clone() {
        const OO = this.getSize(),
          KO = new QO(this.name, OO, this.JKO(), this._renderTargetOptions.generateMipMaps, this._doNotChangeAspectRatio, this._renderTargetOptions.type, this.isCube, this._renderTargetOptions.samplingMode, this._renderTargetOptions.generateDepthBuffer, this._renderTargetOptions.generateStencilBuffer, void 0, this._renderTargetOptions.format, void 0, this._renderTargetOptions.samples);
        return KO.hasAlpha = this.hasAlpha, KO.level = this.level, KO.coordinatesMode = this.coordinatesMode, this.renderList && (KO.renderList = this.renderList.slice(0)), KO
      }
      serialize() {
        if (!this.name) return null;
        const OO = super.serialize();
        if (OO.renderTargetSize = this.getRenderSize(), OO.renderList = [], this.renderList)
          for (let KO = 0; KO < this.renderList.length; KO++) OO.renderList.push(this.renderList[KO].id);
        return OO
      }
      disposeFramebufferObjects() {
        this._renderTarget?.dispose(!0)
      }
      releaseInternalTexture() {
        this._renderTarget?.releaseTextures(), this._texture = null
      }
      dispose() {
        this.onResizeObservable.clear(), this.onClearObservable.clear(), this.onAfterUnbindObservable.clear(), this.onBeforeBindObservable.clear(), this._postProcessManager && (this._postProcessManager.dispose(), this._postProcessManager = null), this._prePassRenderTarget && this._prePassRenderTarget.dispose(), this._objectRenderer.onBeforeRenderingManagerRenderObservable.remove(this._onBeforeRenderingManagerRenderObserver), this._objectRenderer.onAfterRenderingManagerRenderObservable.remove(this._onAfterRenderingManagerRenderObserver), this._objectRenderer.onFastPathRenderObservable.remove(this._onFastPathRenderObserver), this._dontDisposeObjectRenderer || this._objectRenderer.dispose(), this.clearPostProcesses(!0), this._resizeObserver && (this.JKO().qb().onResizeObservable.remove(this._resizeObserver), this._resizeObserver = null);
        const OO = this.JKO();
        if (!OO) return;
        let KO = OO.customRenderTargets.indexOf(this);
        KO >= 0 && OO.customRenderTargets.splice(KO, 1);
        for (const pO of OO.cameras) KO = pO.customRenderTargets.indexOf(this), KO >= 0 && pO.customRenderTargets.splice(KO, 1);
        this._renderTarget?.dispose(), this._renderTarget = null, this._texture = null, super.dispose()
      }
      _rebuild() {
        this._objectRenderer._rebuild(), this._postProcessManager && this._postProcessManager._rebuild()
      }
      freeRenderingGroups() {
        this._objectRenderer.freeRenderingGroups()
      }
      getViewCount() {
        return 1
      }
    }
    QO.REFRESHRATE_RENDER_ONCE = VO.REFRESHRATE_RENDER_ONCE, QO.REFRESHRATE_RENDER_ONEVERYFRAME = VO.REFRESHRATE_RENDER_ONEVERYFRAME, QO.REFRESHRATE_RENDER_ONEVERYTWOFRAMES = VO.REFRESHRATE_RENDER_ONEVERYTWOFRAMES;
    Object.getOwnPropertyDescriptor(QO.prototype, "noPrePassRenderer") || Object.defineProperty(QO.prototype, "noPrePassRenderer", (0, LO.e)("RenderTargetTexture", "noPrePassRenderer"))
  },
  39819: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO,
      e: () => DO
    });
    var XO = pO(38216),
      bK = pO(36513),
      eO = pO(35660),
      lO = pO(37902),
      vK = pO(38416);
    const CO = {
      positions: [1, 1, -1, 1, -1, -1, 1, -1],
      indices: [0, 1, 2, 0, 2, 3]
    };
    class hO {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : CO;
        this._fullscreenViewport = new bK.d(0, 0, 1, 1);
        const pO = KO.positions ?? CO.positions,
          eO = KO.indices ?? CO.indices;
        this.engine = OO, this._vertexBuffers = {
          [XO.j.PositionKind]: new XO.j(OO, pO, XO.j.PositionKind, !1, !1, 2)
        }, this._indexBuffer = OO.createIndexBuffer(eO), this._indexBufferLength = eO.length, this._onContextRestoredObserver = OO.onContextRestoredObservable.add((() => {
          this._indexBuffer = OO.createIndexBuffer(eO);
          for (const OO in this._vertexBuffers) {
            this._vertexBuffers[OO]._rebuild()
          }
        }))
      }
      setViewport() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._fullscreenViewport;
        this.engine.setViewport(OO)
      }
      bindBuffers(OO) {
        this.engine.bindBuffers(this._vertexBuffers, this._indexBuffer, OO)
      }
      applyEffectWrapper(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        this.engine.setState(!0), this.engine.depthCullingState.depthTest = KO, this.engine.stencilState.stencilTest = pO, this.engine.enableEffect(OO.drawWrapper), this.bindBuffers(OO.effect), OO.onApplyObservable.notifyObservers({})
      }
      saveStates() {
        this._savedStateDepthTest = this.engine.depthCullingState.depthTest, this._savedStateStencilTest = this.engine.stencilState.stencilTest
      }
      restoreStates() {
        this.engine.depthCullingState.depthTest = this._savedStateDepthTest, this.engine.stencilState.stencilTest = this._savedStateStencilTest
      }
      draw() {
        this.engine.drawElementsType(0, 0, this._indexBufferLength)
      }
      _isRenderTargetTexture(OO) {
        return void 0 !== OO.renderTarget
      }
      render(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        if (!OO.effect.isReady()) return;
        this.saveStates(), this.setViewport();
        const pO = null === KO ? null : this._isRenderTargetTexture(KO) ? KO.renderTarget : KO;
        pO && this.engine.bindFramebuffer(pO), this.applyEffectWrapper(OO), this.draw(), pO && this.engine.unBindFramebuffer(pO), this.restoreStates()
      }
      dispose() {
        const OO = this._vertexBuffers[XO.j.PositionKind];
        OO && (OO.dispose(), delete this._vertexBuffers[XO.j.PositionKind]), this._indexBuffer && this.engine._releaseBuffer(this._indexBuffer), this._onContextRestoredObserver && (this.engine.onContextRestoredObservable.remove(this._onContextRestoredObserver), this._onContextRestoredObserver = null)
      }
    }
    class DO {
      static RegisterShaderCodeProcessing(OO, KO) {
        KO ? DO._CustomShaderCodeProcessing[OO ?? ""] = KO : delete DO._CustomShaderCodeProcessing[OO ?? ""]
      }
      static _GetShaderCodeProcessing(OO) {
        return DO._CustomShaderCodeProcessing[OO] ?? DO._CustomShaderCodeProcessing[""]
      }
      get name() {
        return this.options.name
      }
      set name(OO) {
        this.options.name = OO
      }
      isReady() {
        return this._drawWrapper.effect?.isReady() ?? !1
      }
      get drawWrapper() {
        return this._drawWrapper
      }
      get effect() {
        return this._drawWrapper.effect
      }
      set effect(OO) {
        this._drawWrapper.effect = OO
      }
      constructor(OO) {
        this.alphaMode = 0, this.onEffectCreatedObservable = new eO.e(void 0, !0), this.onApplyObservable = new eO.e, this._shadersLoaded = !1, this._webGPUReady = !1, this._importPromises = [], this.options = {
          ...OO,
          name: OO.name || "effectWrapper",
          engine: OO.engine,
          uniforms: OO.uniforms || OO.uniformNames || [],
          uniformNames: void 0,
          samplers: OO.samplers || OO.samplerNames || [],
          samplerNames: void 0,
          attributeNames: OO.attributeNames || ["position"],
          uniformBuffers: OO.uniformBuffers || [],
          defines: OO.defines || "",
          useShaderStore: OO.useShaderStore || !1,
          vertexUrl: OO.vertexUrl || OO.vertexShader || "postprocess",
          vertexShader: void 0,
          fragmentShader: OO.fragmentShader || "pass",
          indexParameters: OO.indexParameters,
          blockCompilation: OO.blockCompilation || !1,
          shaderLanguage: OO.shaderLanguage || 0,
          onCompiled: OO.onCompiled || void 0,
          extraInitializations: OO.extraInitializations || void 0,
          extraInitializationsAsync: OO.extraInitializationsAsync || void 0,
          useAsPostProcess: OO.useAsPostProcess ?? !1,
          allowEmptySourceTexture: OO.allowEmptySourceTexture ?? !1
        }, this.options.uniformNames = this.options.uniforms, this.options.samplerNames = this.options.samplers, this.options.vertexShader = this.options.vertexUrl, this.options.useAsPostProcess && (this.options.allowEmptySourceTexture || -1 !== this.options.samplers.indexOf("textureSampler") || this.options.samplers.push("textureSampler"), -1 === this.options.uniforms.indexOf("scale") && this.options.uniforms.push("scale")), OO.vertexUrl || OO.vertexShader ? this._shaderPath = {
          vertexSource: this.options.vertexShader
        } : (this.options.useAsPostProcess || (this.options.uniforms.push("scale"), this.onApplyObservable.add((() => {
          this.effect.setFloat2("scale", 1, 1)
        }))), this._shaderPath = {
          vertex: this.options.vertexShader
        }), this._shaderPath.fragmentSource = this.options.fragmentShader, this._shaderPath.spectorName = this.options.name, this.options.useShaderStore && (this._shaderPath.fragment = this._shaderPath.fragmentSource, this._shaderPath.vertex || (this._shaderPath.vertex = this._shaderPath.vertexSource), delete this._shaderPath.fragmentSource, delete this._shaderPath.vertexSource), this.onApplyObservable.add((() => {
          this.bind()
        })), this.options.useShaderStore || (this._onContextRestoredObserver = this.options.engine.onContextRestoredObservable.add((() => {
          this.effect._pipelineContext = null, this.effect._prepareEffect()
        }))), this._drawWrapper = new vK.c(this.options.engine), this._webGPUReady = 1 === this.options.shaderLanguage;
        const KO = Array.isArray(this.options.defines) ? this.options.defines.join("\n") : this.options.defines;
        this._postConstructor(this.options.blockCompilation, KO, this.options.extraInitializations)
      }
      _gatherImports() {}
      _postConstructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          XO = arguments.length > 2 ? arguments[2] : void 0,
          bK = arguments.length > 3 ? arguments[3] : void 0;
        this._importPromises.length = 0, bK && this._importPromises.push(...bK);
        const eO = this.options.engine.isWebGPU && !DO.ForceGLSL;
        this._gatherImports(eO, this._importPromises), this.options.useShaderStore && "postprocess" === this._shaderPath.vertex && this._importPromises.push(eO && this._webGPUReady ? pO.e(344).then((() => pO(59286))) : pO.e(333).then((() => pO(59068)))), void 0 !== XO && XO(eO, this._importPromises), eO && this._webGPUReady && (this.options.shaderLanguage = 1), OO || this.updateEffect(KO)
      }
      updateEffect() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          XO = arguments.length > 3 ? arguments[3] : void 0,
          bK = arguments.length > 4 ? arguments[4] : void 0,
          eO = arguments.length > 5 ? arguments[5] : void 0,
          vK = arguments.length > 6 ? arguments[6] : void 0,
          CO = arguments.length > 7 ? arguments[7] : void 0;
        const hO = DO._GetShaderCodeProcessing(this.name);
        if (hO?.defineCustomBindings) {
          const XO = KO?.slice() ?? [];
          XO.push(...this.options.uniforms);
          const bK = pO?.slice() ?? [];
          bK.push(...this.options.samplers), OO = hO.defineCustomBindings(this.name, OO, XO, bK), KO = XO, pO = bK
        }
        this.options.defines = OO || "";
        const MO = this._shadersLoaded || 0 === this._importPromises.length ? void 0 : async () => {
          await Promise.all(this._importPromises), this._shadersLoaded = !0
        };
        let aK;
        aK = this.options.extraInitializationsAsync ? async () => {
          await (MO?.()), await this.options.extraInitializationsAsync()
        }: MO, this.options.useShaderStore ? this._drawWrapper.effect = this.options.engine.createEffect({
          vertex: vK ?? this._shaderPath.vertex,
          fragment: CO ?? this._shaderPath.fragment
        }, {
          attributes: this.options.attributeNames,
          uniformsNames: KO || this.options.uniforms,
          uniformBuffersNames: this.options.uniformBuffers,
          samplers: pO || this.options.samplers,
          defines: null !== OO ? OO : "",
          fallbacks: null,
          onCompiled: bK ?? this.options.onCompiled,
          onError: eO ?? null,
          indexParameters: XO || this.options.indexParameters,
          processCodeAfterIncludes: hO?.processCodeAfterIncludes ? (OO, KO) => hO.processCodeAfterIncludes(this.name, OO, KO) : null,
          processFinalCode: hO?.processFinalCode ? (OO, KO) => hO.processFinalCode(this.name, OO, KO) : null,
          shaderLanguage: this.options.shaderLanguage,
          extraInitializationsAsync: aK
        }, this.options.engine) : this._drawWrapper.effect = new lO.e(this._shaderPath, this.options.attributeNames, KO || this.options.uniforms, pO || this.options.samplerNames, this.options.engine, OO, void 0, bK || this.options.onCompiled, void 0, void 0, void 0, this.options.shaderLanguage, aK), this.onEffectCreatedObservable.notifyObservers(this._drawWrapper.effect)
      }
      bind() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        this.options.useAsPostProcess && !OO && (this.options.engine.setAlphaMode(this.alphaMode), this.drawWrapper.effect.setFloat2("scale", 1, 1)), DO._GetShaderCodeProcessing(this.name)?.bindCustomBindings?.(this.name, this._drawWrapper.effect)
      }
      dispose() {
        this._onContextRestoredObserver && (this.effect.qb().onContextRestoredObservable.remove(this._onContextRestoredObserver), this._onContextRestoredObserver = null), this.onEffectCreatedObservable.clear(), this._drawWrapper.dispose(!0)
      }
    }
    DO.ForceGLSL = !1, DO._CustomShaderCodeProcessing = {}
  },
  39846: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      Dispose: () => zK,
      DumpData: () => QO,
      DumpDataAsync: () => LO,
      DumpFramebuffer: () => VO,
      DumpTools: () => AO,
      EncodeImageAsync: () => FO,
      RegisterDumpTools: () => dO
    });
    var XO = pO(38063),
      bK = pO(39819),
      eO = pO(38172),
      lO = pO(35664),
      vK = pO(35653),
      CO = pO(37061),
      hO = pO(38129),
      DO = pO(38066);
    let MO = null;
    async function aK() {
      return MO || (MO = async function() {
        const OO = vK.c.LastCreatedEngine?.createCanvas(100, 100) ?? new OffscreenCanvas(100, 100);
        OO instanceof OffscreenCanvas && CO.b.Warn("DumpData: OffscreenCanvas will be used for dumping data. This may result in lossy alpha values.");
        const {
          ThinEngine: KO
        } = await Promise.resolve().then((() => pO(37899)));
        if (!KO.IsSupported) throw new Error("DumpData: No WebGL context available. Cannot dump data.");
        const XO = new KO(OO, !1, {
          preserveDrawingBuffer: !0,
          depth: !1,
          stencil: !1,
          alpha: !0,
          premultipliedAlpha: !1,
          antialias: !1,
          failIfMajorPerformanceCaveat: !1
        });
        vK.c.Instances.pop(), vK.c.OnEnginesDisposedObservable.add((OO => {
          XO && OO !== XO && !XO.FhO && 0 === vK.c.Instances.length && zK()
        })), XO.getCaps().parallelShaderCompile = void 0;
        const eO = new bK.b(XO),
          {
            passPixelShader: lO
          } = await pO.e(352).then((() => pO(59336))),
          hO = new bK.e({
            engine: XO,
            name: lO.name,
            fragmentShader: lO.shader,
            samplerNames: ["textureSampler"]
          });
        return {
          canvas: OO,
          dumpEngine: {
            engine: XO,
            renderer: eO,
            wrapper: hO
          }
        }
      }()), await MO
    }
    let oO = (() => {
      var OO;
      let KO, pO = [];
      return OO = class {
        static async EncodeImageAsync(OO, KO, pO, XO, bK, lO) {
          const vK = await aK(),
            CO = vK.dumpEngine;
          CO.engine.setSize(KO, pO, !0);
          const hO = CO.engine.createRawTexture(OO, KO, pO, 5, !1, !bK, 1);
          return CO.renderer.setViewport(), CO.renderer.applyEffectWrapper(CO.wrapper), CO.wrapper.effect._bindTexture("textureSampler", hO), CO.renderer.draw(), hO.dispose(), await new Promise(((OO, KO) => {
            eO.k.ToBlob(vK.canvas, (pO => {
              pO ? OO(pO) : KO(new Error("EncodeImageAsync: Failed to convert canvas to blob."))
            }), XO, lO)
          }))
        }
      }, (() => {
        const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [DO.l], (0, XO.f)(OO, null, KO, {
          kind: "method",
          name: "EncodeImageAsync",
          static: !0,
          private: !1,
          access: {
            has: OO => "EncodeImageAsync" in OO,
            get: OO => OO.EncodeImageAsync
          },
          metadata: bK
        }, null, pO), bK && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: bK
        }), (0, XO.i)(OO, pO)
      })(), OO
    })();
    const FO = oO.EncodeImageAsync;
    async function VO(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "image/png",
        eO = arguments.length > 5 ? arguments[5] : void 0,
        lO = arguments.length > 6 ? arguments[6] : void 0;
      const vK = await pO.readPixels(0, 0, OO, KO);
      QO(OO, KO, new Uint8Array(vK.buffer), XO, bK, eO, !0, void 0, lO)
    }
    async function LO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "image/png",
        bK = arguments.length > 4 ? arguments[4] : void 0,
        vK = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
        DO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
        MO = arguments.length > 7 ? arguments[7] : void 0;
      if (pO instanceof Float32Array) {
        const OO = new Uint8Array(pO.length);
        let KO = pO.length;
        for (; KO--;) {
          const XO = pO[KO];
          OO[KO] = Math.round(255 * (0, lO.Clamp)(XO))
        }
        pO = OO
      }
      const aK = await oO.EncodeImageAsync(pO, OO, KO, XO, vK, MO);
      void 0 !== bK && eO.k.DownloadBlob(aK, bK), aK.type !== XO && CO.b.Warn(`DumpData: The requested mimeType '${XO}' is not supported. The result has mimeType '${aK.type}' instead.`);
      const FO = await aK.arrayBuffer();
      return DO ? FO : `data:${XO};base64,${(0,hO.k)(FO)}`
    }

    function QO(OO, KO, pO, XO) {
      let bK = arguments.length > 5 ? arguments[5] : void 0;
      void 0 !== bK || XO || (bK = ""), LO(OO, KO, pO, arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "image/png", bK, arguments.length > 6 && void 0 !== arguments[6] && arguments[6], arguments.length > 7 && void 0 !== arguments[7] && arguments[7], arguments.length > 8 ? arguments[8] : void 0).then((OO => {
        XO && XO(OO)
      }))
    }

    function zK() {
      MO && (MO?.then((OO => {
        OO.canvas instanceof HTMLCanvasElement && OO.canvas.remove(), OO.dumpEngine && (OO.dumpEngine.engine.dispose(), OO.dumpEngine.renderer.dispose(), OO.dumpEngine.wrapper.dispose())
      })), MO = null)
    }
    const AO = {
      DumpData: QO,
      DumpDataAsync: LO,
      DumpFramebuffer: VO,
      Dispose: zK
    };
    let fO = !1;

    function dO() {
      if (fO) return;
      fO = !0;
      eO.k.DumpData = QO, eO.k.DumpDataAsync = LO, eO.k.DumpFramebuffer = VO
    }
  },
  39827: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      h: () => FO,
      i: () => VO
    });
    var XO = pO(38580),
      bK = pO(39833),
      eO = pO(38063),
      lO = pO(39812),
      vK = pO(38077),
      CO = pO(39841),
      hO = pO(38066);
    class DO extends lO.d {
      getClassName() {
        return "PassPostProcess"
      }
      constructor(OO, KO) {
        let pO = arguments.length > 4 ? arguments[4] : void 0;
        const XO = {
          size: "number" === typeof KO ? KO : void 0,
          camera: arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          samplingMode: arguments.length > 3 ? arguments[3] : void 0,
          engine: pO,
          reusable: arguments.length > 5 ? arguments[5] : void 0,
          textureType: arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0,
          blockCompilation: arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
          ...KO
        };
        super(OO, CO.f.FragmentUrl, {
          effectWrapper: "number" !== typeof KO && KO.effectWrapper ? void 0 : new CO.f(OO, pO, XO),
          ...XO
        })
      }
      static _Parse(OO, KO, pO, XO) {
        return vK.c.Parse((() => new DO(OO.name, OO.options, KO, OO.renderTargetSamplingMode, OO._engine, OO.reusable)), OO, pO, XO)
      }
    }(() => {
      var OO;
      let KO, pO = lO.d,
        XO = [];
      OO = class extends pO {
        get face() {
          return this._effectWrapper.face
        }
        set face(OO) {
          this._effectWrapper.face = OO
        }
        getClassName() {
          return "PassCubePostProcess"
        }
        constructor(OO, KO) {
          let pO = arguments.length > 4 ? arguments[4] : void 0;
          const bK = {
            size: "number" === typeof KO ? KO : void 0,
            camera: arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
            samplingMode: arguments.length > 3 ? arguments[3] : void 0,
            engine: pO,
            reusable: arguments.length > 5 ? arguments[5] : void 0,
            textureType: arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0,
            blockCompilation: arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
            ...KO
          };
          super(OO, CO.f.FragmentUrl, {
            effectWrapper: "number" !== typeof KO && KO.effectWrapper ? void 0 : new CO.c(OO, pO, bK),
            ...bK
          }), (0, eO.i)(this, XO)
        }
        static _Parse(KO, pO, XO, bK) {
          return vK.c.Parse((() => new OO(KO.name, KO.options, pO, KO.renderTargetSamplingMode, KO._engine, KO.reusable)), KO, XO, bK)
        }
      }, (() => {
        const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(pO[Symbol.metadata] ?? null) : void 0;
        KO = [(0, hO.M)()], (0, eO.f)(OO, null, KO, {
          kind: "getter",
          name: "face",
          static: !1,
          private: !1,
          access: {
            has: OO => "face" in OO,
            get: OO => OO.face
          },
          metadata: bK
        }, null, XO), bK && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: bK
        })
      })()
    })();
    var MO = pO(35664),
      aK = pO(38140);

    function oO(OO, KO, pO, XO, bK, eO, vK, CO) {
      const hO = KO.qb();
      return KO.isReady = !1, bK = bK ?? KO.samplingMode, XO = XO ?? KO.type, eO = eO ?? KO.format, vK = vK ?? KO.width, CO = CO ?? KO.height, -1 === XO && (XO = 0), new Promise((DO => {
        const MO = new lO.d("postprocess", OO, null, null, 1, null, bK, hO, !1, void 0, XO, void 0, null, !1, eO);
        MO.externalTextureSamplerBinding = !0;
        const aK = hO.createRenderTargetTexture({
          width: vK,
          height: CO
        }, {
          generateDepthBuffer: !1,
          generateMipMaps: !1,
          generateStencilBuffer: !1,
          samplingMode: bK,
          type: XO,
          format: eO
        });
        MO.onEffectCreatedObservable.addOnce((OO => {
          OO.executeWhenCompiled((() => {
            MO.onApply = OO => {
              OO._bindTexture("textureSampler", KO), OO.setFloat2("scale", 1, 1)
            }, pO.postProcessManager.directRender([MO], aK, !0), hO.restoreDefaultFramebuffer(), hO._releaseTexture(KO), MO && MO.dispose(), aK._swapAndDie(KO), KO.type = XO, KO.format = 5, KO.isReady = !0, DO(KO)
          }))
        }))
      }))
    }
    async function FO(OO, KO, eO) {
      let vK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
        CO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
        hO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
        DO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0;
      await async function(OO) {
        if (OO.isReady()) return;
        if (OO.loadingError) throw new Error(OO.errorObject?.message || `Texture ${OO.name} errored while loading.`);
        const KO = OO.onLoadObservable;
        if (KO) return await new Promise((OO => KO.addOnce((() => OO()))));
        const pO = OO._texture?.onLoadedObservable;
        if (pO) return await new Promise((OO => pO.addOnce((() => OO()))));
        throw new Error(`Cannot determine readiness of texture ${OO.name}.`)
      }(OO);
      const aK = OO.getInternalTexture(),
        oO = OO.is3D || !!aK?.is3D,
        {
          width: FO,
          height: VO
        } = OO.getSize(),
        LO = KO ?? FO,
        QO = eO ?? VO;
      if (hO || oO || function(OO) {
          switch (OO) {
            case 36492:
            case 36493:
            case 36495:
            case 36494:
            case 33779:
            case 35919:
            case 33778:
            case 35918:
            case 33777:
            case 33776:
            case 35917:
            case 35916:
            case 37808:
            case 37809:
            case 37810:
            case 37811:
            case 37812:
            case 37813:
            case 37814:
            case 37815:
            case 37816:
            case 37817:
            case 37818:
            case 37819:
            case 37820:
            case 37821:
            case 37840:
            case 37841:
            case 37842:
            case 37843:
            case 37844:
            case 37845:
            case 37846:
            case 37847:
            case 37848:
            case 37849:
            case 37850:
            case 37851:
            case 37852:
            case 37853:
            case 36196:
            case 37492:
            case 37493:
            case 37494:
            case 37495:
            case 37496:
            case 37497:
              return !0;
            default:
              return !1
          }
        }(OO.textureFormat) || LO !== FO || QO !== VO) {
        if (OO.is2DArray) throw new Error(`Reading pixels from 2D array textures with ${hO?"RTT":"compression"} is not supported.`);
        return await async function(OO, KO, eO, vK, CO) {
          let hO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0;
          const DO = OO.JKO(),
            MO = DO.qb(),
            aK = OO.getInternalTexture(),
            oO = OO.is3D || !!aK?.is3D;
          let FO;
          if (MO.isWebGPU ? oO ? await pO.e(348).then((() => pO(59321))) : OO.isCube ? await pO.e(349).then((() => pO(59325))) : await pO.e(350).then((() => pO(59327))) : oO ? await pO.e(345).then((() => pO(59308))) : OO.isCube ? await pO.e(346).then((() => pO(59311))) : await pO.e(347).then((() => pO(59313))), oO) FO = new lO.d("lod3D", "lod3D", {
            uniforms: ["lod", "gamma", "slice"],
            samplingMode: XO.e.NEAREST_NEAREST_MIPNEAREST,
            engine: MO,
            shaderLanguage: MO.isWebGPU ? 1 : 0
          });
          else if (OO.isCube) {
            const OO = ["#define POSITIVEX", "#define NEGATIVEX", "#define POSITIVEY", "#define NEGATIVEY", "#define POSITIVEZ", "#define NEGATIVEZ"];
            FO = new lO.d("lodCube", "lodCube", {
              uniforms: ["lod", "gamma"],
              samplingMode: XO.e.NEAREST_NEAREST_MIPNEAREST,
              engine: MO,
              defines: OO[vK],
              shaderLanguage: MO.isWebGPU ? 1 : 0
            })
          } else FO = new lO.d("lod", "lod", {
            uniforms: ["lod", "gamma"],
            samplingMode: XO.e.NEAREST_NEAREST_MIPNEAREST,
            engine: MO,
            shaderLanguage: MO.isWebGPU ? 1 : 0
          });
          await new Promise((OO => {
            FO.onEffectCreatedObservable.addOnce((KO => {
              KO.executeWhenCompiled((() => {
                OO(0)
              }))
            }))
          }));
          const VO = new bK.e("temp", {
            width: KO,
            height: eO
          }, DO, !1);
          FO.onApply = function(KO) {
            KO.setTexture("textureSampler", OO), KO.setFloat("lod", CO), KO.setInt("gamma", OO.gammaSpace ? 1 : 0), oO && KO.setFloat("slice", hO)
          };
          try {
            if (VO.renderTarget && aK) {
              const pO = aK.samplingMode;
              0 !== CO ? OO.updateSamplingMode(XO.e.NEAREST_NEAREST_MIPNEAREST) : OO.updateSamplingMode(XO.e.NEAREST_NEAREST), DO.postProcessManager.directRender([FO], VO.renderTarget, !0), OO.updateSamplingMode(pO);
              const bK = await MO.readPixels(0, 0, KO, eO),
                lO = new Uint8Array(bK.buffer, bK.byteOffset, bK.byteLength);
              return MO.unBindFramebuffer(VO.renderTarget), lO
            }
            throw Error("Render to texture failed.")
          } finally {
            VO.dispose(), FO.dispose()
          }
        }(OO, LO, QO, vK, CO, DO)
      }
      let zK = await OO.readPixels(vK, CO);
      if (!zK) throw new Error(`Failed to read pixels from texture ${OO.name}.`);
      if (zK instanceof Float32Array) {
        const OO = new Uint8Array(zK.length);
        let KO = zK.length;
        for (; KO--;) {
          const pO = zK[KO];
          OO[KO] = Math.round(255 * (0, MO.Clamp)(pO))
        }
        zK = OO
      }
      const AO = LO * QO,
        fO = 4 * AO;
      if (zK.length !== fO) {
        const OO = 0 === AO ? 0 : zK.length / AO;
        if (1 === OO || 2 === OO || 3 === OO) {
          const KO = new Uint8Array(fO);
          for (let pO = 0, XO = 0, bK = 0; pO < AO; pO++, bK += 4) {
            const pO = zK[XO++];
            if (1 === OO) {
              KO[bK] = pO, KO[bK + 1] = pO, KO[bK + 2] = pO, KO[bK + 3] = 255;
              continue
            }
            const eO = zK[XO++];
            2 !== OO ? (KO[bK] = pO, KO[bK + 1] = eO, KO[bK + 2] = zK[XO++], KO[bK + 3] = 255) : (KO[bK] = pO, KO[bK + 1] = eO, KO[bK + 2] = 0, KO[bK + 3] = 255)
          }
          return KO
        }
      }
      return zK
    }
    const VO = {
      CreateResizedCopy: function(OO, KO, pO) {
        let eO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        const lO = OO.JKO(),
          vK = lO.qb(),
          CO = new bK.e("resized" + OO.name, {
            width: KO,
            height: pO
          }, lO, !OO.noMipmap, !0, OO._texture.type, !1, OO.samplingMode, !1);
        CO.wrapU = OO.wrapU, CO.wrapV = OO.wrapV, CO.uOffset = OO.uOffset, CO.vOffset = OO.vOffset, CO.uScale = OO.uScale, CO.vScale = OO.vScale, CO.uAng = OO.uAng, CO.vAng = OO.vAng, CO.wAng = OO.wAng, CO.coordinatesIndex = OO.coordinatesIndex, CO.level = OO.level, CO.anisotropicFilteringLevel = OO.anisotropicFilteringLevel, CO._texture.isReady = !1, OO.wrapU = XO.e.CLAMP_ADDRESSMODE, OO.wrapV = XO.e.CLAMP_ADDRESSMODE;
        const hO = new DO("pass", 1, null, eO ? XO.e.BILINEAR_SAMPLINGMODE : XO.e.NEAREST_SAMPLINGMODE, vK, !1, 0);
        return hO.externalTextureSamplerBinding = !0, hO.onEffectCreatedObservable.addOnce((KO => {
          KO.executeWhenCompiled((() => {
            hO.onApply = function(KO) {
              KO.setTexture("textureSampler", OO)
            };
            const KO = CO.renderTarget;
            KO && (lO.postProcessManager.directRender([hO], KO), vK.unBindFramebuffer(KO), CO.disposeFramebufferObjects(), hO.dispose(), CO.getInternalTexture().isReady = !0)
          }))
        })), CO
      },
      ApplyPostProcess: oO,
      ToHalfFloat: aK.i,
      FromHalfFloat: aK.d,
      GetTextureDataAsync: FO
    }
  },
  39812: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => FO
    });
    var XO = pO(38063),
      bK = pO(38186),
      eO = pO(35660),
      lO = pO(35632),
      vK = pO(37902),
      CO = pO(38066),
      hO = pO(38077),
      DO = pO(35676),
      MO = pO(37962),
      aK = pO(37996),
      oO = pO(39819);
    let FO = (() => {
        var OO;
        let KO, vK, MO, FO, VO, QO, zK, AO, fO, dO, TO, NO, IO, yK, gK, uO, EO = [],
          jK = [],
          YO = [],
          wO = [],
          iK = [],
          rK = [],
          PO = [],
          mK = [],
          sO = [],
          HO = [],
          RO = [],
          SO = [],
          JO = [],
          cK = [],
          BO = [],
          ZO = [],
          GO = [],
          qK = [],
          xK = [],
          nO = [],
          WO = [],
          tK = [],
          kK = [],
          UO = [],
          OK = [],
          KK = [],
          pK = [],
          XK = [],
          bp = [];
        return OO = class {
          static get ForceGLSL() {
            return oO.e.ForceGLSL
          }
          static set ForceGLSL(OO) {
            oO.e.ForceGLSL = OO
          }
          static RegisterShaderCodeProcessing(OO, KO) {
            oO.e.RegisterShaderCodeProcessing(OO, KO)
          }
          get name() {
            return this._effectWrapper.name
          }
          set name(OO) {
            this._effectWrapper.name = OO
          }
          get alphaMode() {
            return this._effectWrapper.alphaMode
          }
          set alphaMode(OO) {
            this._effectWrapper.alphaMode = OO
          }
          get samples() {
            return this._samples
          }
          set samples(OO) {
            this._samples = Math.min(OO, this._engine.getCaps().maxMSAASamples), this._textures.forEach((OO => {
              OO.setSamples(this._samples)
            }))
          }
          get shaderLanguage() {
            return this._shaderLanguage
          }
          getEffectName() {
            return this._fragmentUrl
          }
          set onActivate(OO) {
            this._onActivateObserver && this.onActivateObservable.remove(this._onActivateObserver), OO && (this._onActivateObserver = this.onActivateObservable.add(OO))
          }
          set onSizeChanged(OO) {
            this._onSizeChangedObserver && this.onSizeChangedObservable.remove(this._onSizeChangedObserver), this._onSizeChangedObserver = this.onSizeChangedObservable.add(OO)
          }
          set onApply(OO) {
            this._onApplyObserver && this.onApplyObservable.remove(this._onApplyObserver), this._onApplyObserver = this.onApplyObservable.add(OO)
          }
          set onBeforeRender(OO) {
            this._onBeforeRenderObserver && this.onBeforeRenderObservable.remove(this._onBeforeRenderObserver), this._onBeforeRenderObserver = this.onBeforeRenderObservable.add(OO)
          }
          set onAfterRender(OO) {
            this._onAfterRenderObserver && this.onAfterRenderObservable.remove(this._onAfterRenderObserver), this._onAfterRenderObserver = this.onAfterRenderObservable.add(OO)
          }
          get inputTexture() {
            return this._textures.data[this._currentRenderTextureInd]
          }
          set inputTexture(OO) {
            this._forcedOutputTexture = OO
          }
          restoreDefaultInputTexture() {
            this._forcedOutputTexture && (this._forcedOutputTexture = null, this.markTextureDirty())
          }
          getCamera() {
            return this.ZbO
          }
          get texelSize() {
            return this._shareOutputWithPostProcess ? this._shareOutputWithPostProcess.texelSize : (this._forcedOutputTexture && this._texelSize.rvO(1 / this._forcedOutputTexture.width, 1 / this._forcedOutputTexture.height), this._texelSize)
          }
          constructor(KO, pO, vK, CO, hO, DO) {
            let MO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 1,
              aK = arguments.length > 7 ? arguments[7] : void 0,
              FO = arguments.length > 8 ? arguments[8] : void 0,
              VO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : null,
              QO = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : 0,
              zK = arguments.length > 11 && void 0 !== arguments[11] ? arguments[11] : "postprocess",
              AO = arguments.length > 12 ? arguments[12] : void 0,
              fO = arguments.length > 13 && void 0 !== arguments[13] && arguments[13],
              dO = arguments.length > 14 && void 0 !== arguments[14] ? arguments[14] : 5,
              TO = arguments.length > 15 ? arguments[15] : void 0,
              NO = arguments.length > 16 ? arguments[16] : void 0;
            this._parentContainer = ((0, XO.i)(this, EO), null), this.uniqueId = (0, XO.i)(this, jK, void 0), this.width = ((0, XO.i)(this, YO), (0, XO.i)(this, wO, -1)), this.height = ((0, XO.i)(this, iK), (0, XO.i)(this, rK, -1)), this.nodeMaterialSource = ((0, XO.i)(this, PO), null), this._outputTexture = null, this.renderTargetSamplingMode = (0, XO.i)(this, mK, void 0), this.clearColor = ((0, XO.i)(this, sO), (0, XO.i)(this, HO, void 0)), this.autoClear = ((0, XO.i)(this, RO), (0, XO.i)(this, SO, !0)), this.forceAutoClearInAlphaMode = ((0, XO.i)(this, JO), (0, XO.i)(this, cK, !1)), this.alphaConstants = ((0, XO.i)(this, BO), (0, XO.i)(this, ZO, void 0)), this.animations = ((0, XO.i)(this, GO), []), this.enablePixelPerfectMode = (0, XO.i)(this, qK, !1), this.forceFullscreenViewport = ((0, XO.i)(this, xK), (0, XO.i)(this, nO, !0)), this.inspectableCustomProperties = (0, XO.i)(this, WO), this.scaleMode = (0, XO.i)(this, tK, 1), this.alwaysForcePOT = ((0, XO.i)(this, kK), (0, XO.i)(this, UO, !1)), this._samples = ((0, XO.i)(this, OK), (0, XO.i)(this, KK, 1)), this.adaptScaleToCurrentViewport = ((0, XO.i)(this, pK), (0, XO.i)(this, XK, !1)), this.doNotSerialize = ((0, XO.i)(this, bp), !1), this._webGPUReady = !1, this._reusable = !1, this._renderId = 0, this.externalTextureSamplerBinding = !1, this._textures = new bK.e(2), this._textureCache = [], this._currentRenderTextureInd = 0, this._scaleRatio = new lO.m(1, 1), this._texelSize = lO.m.Zero(), this.onActivateObservable = new eO.e, this.onSizeChangedObservable = new eO.e, this.onApplyObservable = new eO.e, this.onBeforeRenderObservable = new eO.e, this.onAfterRenderObservable = new eO.e, this.cpO = new eO.e, LO();
            let IO, yK = 1,
              gK = null;
            if (vK && !Array.isArray(vK)) {
              const OO = vK;
              vK = OO.uniforms ?? null, CO = OO.samplers ?? null, yK = OO.size ?? 1, DO = OO.camera ?? null, MO = OO.samplingMode ?? 1, aK = OO.engine, FO = OO.reusable, VO = Array.isArray(OO.defines) ? OO.defines.join("\n") : OO.defines ?? null, QO = OO.textureType ?? 0, zK = OO.vertexUrl ?? "postprocess", AO = OO.indexParameters, fO = OO.blockCompilation ?? !1, dO = OO.textureFormat ?? 5, TO = OO.shaderLanguage ?? 0, gK = OO.uniformBuffers ?? null, NO = OO.extraInitializations, IO = OO.effectWrapper
            } else hO && (yK = "number" === typeof hO ? hO : {
              width: hO.width,
              height: hO.height
            });
            if (this._useExistingThinPostProcess = !!IO, this._effectWrapper = IO ?? new oO.e({
                name: KO,
                useShaderStore: !0,
                useAsPostProcess: !0,
                fragmentShader: pO,
                engine: aK || DO?.JKO().qb(),
                uniforms: vK,
                samplers: CO,
                uniformBuffers: gK,
                defines: VO,
                vertexUrl: zK,
                indexParameters: AO,
                blockCompilation: !0,
                shaderLanguage: TO,
                extraInitializations: void 0
              }), this.name = KO, this.onEffectCreatedObservable = this._effectWrapper.onEffectCreatedObservable, null != DO ? (this.ZbO = DO, this._scene = DO.JKO(), DO.attachPostProcess(this), this._engine = this._scene.qb(), this._scene.addPostProcess(this), this.uniqueId = this._scene.getUniqueId()) : aK && (this._engine = aK, this._engine.postProcesses.push(this)), this._options = yK, this.renderTargetSamplingMode = MO || 1, this._reusable = FO || !1, this._textureType = QO, this._textureFormat = dO, this._shaderLanguage = TO || 0, this._samplers = CO || [], -1 === this._samplers.indexOf("textureSampler") && this._samplers.push("textureSampler"), this._fragmentUrl = pO, this._vertexUrl = zK, this._parameters = vK || [], -1 === this._parameters.indexOf("scale") && this._parameters.push("scale"), this._uniformBuffers = gK || [], this._indexParameters = AO, !this._useExistingThinPostProcess) {
              this._webGPUReady = 1 === this._shaderLanguage;
              const KO = [];
              this._gatherImports(this._engine.isWebGPU && !OO.ForceGLSL, KO), this._effectWrapper._webGPUReady = this._webGPUReady, this._effectWrapper._postConstructor(fO, VO, NO, KO)
            }
          }
          _gatherImports() {
            let OO = arguments.length > 1 ? arguments[1] : void 0;
            arguments.length > 0 && void 0 !== arguments[0] && arguments[0] && this._webGPUReady ? OO.push(Promise.all([pO.e(344).then((() => pO(59286)))])) : OO.push(Promise.all([pO.e(333).then((() => pO(59068)))]))
          }
          getClassName() {
            return "PostProcess"
          }
          qb() {
            return this._engine
          }
          getEffect() {
            return this._effectWrapper.drawWrapper.effect
          }
          shareOutputWith(OO) {
            return this._disposeTextures(), this._shareOutputWithPostProcess = OO, this
          }
          useOwnOutput() {
            0 == this._textures.length && (this._textures = new bK.e(2)), this._shareOutputWithPostProcess = null
          }
          updateEffect() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
              KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
              pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
              XO = arguments.length > 3 ? arguments[3] : void 0,
              bK = arguments.length > 4 ? arguments[4] : void 0,
              eO = arguments.length > 5 ? arguments[5] : void 0,
              lO = arguments.length > 6 ? arguments[6] : void 0,
              vK = arguments.length > 7 ? arguments[7] : void 0;
            this._effectWrapper.updateEffect(OO, KO, pO, XO, bK, eO, lO, vK), this._postProcessDefines = Array.isArray(this._effectWrapper.options.defines) ? this._effectWrapper.options.defines.join("\n") : this._effectWrapper.options.defines
          }
          isReusable() {
            return this._reusable
          }
          markTextureDirty() {
            this.width = -1
          }
          _createRenderTargetTexture(OO, KO) {
            let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
            for (let bK = 0; bK < this._textureCache.length; bK++)
              if (this._textureCache[bK].texture.width === OO.width && this._textureCache[bK].texture.height === OO.height && this._textureCache[bK].postProcessChannel === pO && this._textureCache[bK].texture._generateDepthBuffer === KO.generateDepthBuffer && this._textureCache[bK].texture.samples === KO.samples) return this._textureCache[bK].texture;
            const XO = this._engine.createRenderTargetTexture(OO, KO);
            return this._textureCache.push({
              texture: XO,
              postProcessChannel: pO,
              lastUsedRenderId: -1
            }), XO
          }
          _flushTextureCache() {
            const OO = this._renderId;
            for (let KO = this._textureCache.length - 1; KO >= 0; KO--)
              if (OO - this._textureCache[KO].lastUsedRenderId > 100) {
                let OO = !1;
                for (let pO = 0; pO < this._textures.length; pO++)
                  if (this._textures.data[pO] === this._textureCache[KO].texture) {
                    OO = !0;
                    break
                  } OO || (this._textureCache[KO].texture.dispose(), this._textureCache.splice(KO, 1))
              }
          }
          resize(OO, KO) {
            let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
              XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
              bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
            this._textures.length > 0 && this._textures.reset(), this.width = OO, this.height = KO;
            let eO = null;
            if (pO)
              for (let CO = 0; CO < pO._postProcesses.length; CO++)
                if (null !== pO._postProcesses[CO]) {
                  eO = pO._postProcesses[CO];
                  break
                } const lO = {
                width: this.width,
                height: this.height
              },
              vK = {
                generateMipMaps: XO,
                generateDepthBuffer: bK || eO === this,
                generateStencilBuffer: (bK || eO === this) && this._engine.isStencilEnable,
                samplingMode: this.renderTargetSamplingMode,
                type: this._textureType,
                format: this._textureFormat,
                samples: this._samples,
                label: "PostProcessRTT-" + this.name
              };
            this._textures.push(this._createRenderTargetTexture(lO, vK, 0)), this._reusable && this._textures.push(this._createRenderTargetTexture(lO, vK, 1)), this._texelSize.rvO(1 / this.width, 1 / this.height), this.onSizeChangedObservable.notifyObservers(this)
          }
          _getTarget() {
            let OO;
            if (this._shareOutputWithPostProcess) OO = this._shareOutputWithPostProcess.inputTexture;
            else if (this._forcedOutputTexture) OO = this._forcedOutputTexture, this.width = this._forcedOutputTexture.width, this.height = this._forcedOutputTexture.height;
            else {
              let KO;
              OO = this.inputTexture;
              for (let pO = 0; pO < this._textureCache.length; pO++)
                if (this._textureCache[pO].texture === OO) {
                  KO = this._textureCache[pO];
                  break
                } KO && (KO.lastUsedRenderId = this._renderId)
            }
            return OO
          }
          activate(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
              pO = arguments.length > 2 ? arguments[2] : void 0;
            const XO = null === OO || void 0 !== OO.cameraRigMode ? OO || this.ZbO : null,
              bK = XO?.JKO() ?? OO,
              eO = bK.qb(),
              lO = eO.getCaps().maxTextureSize,
              vK = (KO ? KO.width : this._engine.getRenderWidth(!0)) * this._options | 0,
              CO = (KO ? KO.height : this._engine.getRenderHeight(!0)) * this._options | 0;
            let hO = this._options.width || vK,
              DO = this._options.height || CO;
            const MO = 7 !== this.renderTargetSamplingMode && 1 !== this.renderTargetSamplingMode && 2 !== this.renderTargetSamplingMode;
            let oO = null;
            if (!this._shareOutputWithPostProcess && !this._forcedOutputTexture) {
              if (this.adaptScaleToCurrentViewport) {
                const OO = eO.currentViewport;
                OO && (hO *= OO.width, DO *= OO.height)
              }(MO || this.alwaysForcePOT) && (this._options.width || (hO = eO.needPOTTextures ? (0, aK.i)(hO, lO, this.scaleMode) : hO), this._options.height || (DO = eO.needPOTTextures ? (0, aK.i)(DO, lO, this.scaleMode) : DO)), this.width === hO && this.height === DO && (oO = this._getTarget()) || this.resize(hO, DO, XO, MO, pO), this._textures.forEach((OO => {
                OO.samples !== this.samples && this._engine.updateRenderTargetTextureSampleCount(OO, this.samples)
              })), this._flushTextureCache(), this._renderId++
            }
            return oO || (oO = this._getTarget()), this.enablePixelPerfectMode ? (this._scaleRatio.rvO(vK / hO, CO / DO), this._engine.bindFramebuffer(oO, 0, vK, CO, this.forceFullscreenViewport)) : (this._scaleRatio.rvO(1, 1), this._engine.bindFramebuffer(oO, 0, void 0, void 0, this.forceFullscreenViewport)), this._engine._debugInsertMarker?.(`post process ${this.name} input`), this.onActivateObservable.notifyObservers(XO), this.autoClear && (0 === this.alphaMode || this.forceAutoClearInAlphaMode) && this._engine.clear(this.clearColor ? this.clearColor : bK.clearColor, bK._allowPostProcessClearColor, !0, !0), this._reusable && (this._currentRenderTextureInd = (this._currentRenderTextureInd + 1) % 2), oO
          }
          get isSupported() {
            return this._effectWrapper.drawWrapper.effect.isSupported
          }
          get aspectRatio() {
            return this._shareOutputWithPostProcess ? this._shareOutputWithPostProcess.aspectRatio : this._forcedOutputTexture ? this._forcedOutputTexture.width / this._forcedOutputTexture.height : this.width / this.height
          }
          isReady() {
            return this._effectWrapper.isReady()
          }
          apply() {
            if (!this._effectWrapper.isReady()) return null;
            let OO;
            return this._engine.enableEffect(this._effectWrapper.drawWrapper), this._engine.setState(!1), this._engine.setDepthBuffer(!1), this._engine.setDepthWrite(!1), this.alphaConstants && this.qb().setAlphaConstants(this.alphaConstants.r, this.alphaConstants.g, this.alphaConstants.b, this.alphaConstants.a), this._engine.setAlphaMode(this.alphaMode), OO = this._shareOutputWithPostProcess ? this._shareOutputWithPostProcess.inputTexture : this._forcedOutputTexture ? this._forcedOutputTexture : this.inputTexture, this.externalTextureSamplerBinding || this._effectWrapper.drawWrapper.effect._bindTexture("textureSampler", OO?.texture), this._effectWrapper.drawWrapper.effect.setVector2("scale", this._scaleRatio), this.onApplyObservable.notifyObservers(this._effectWrapper.drawWrapper.effect), this._effectWrapper.bind(!0), this._effectWrapper.drawWrapper.effect
          }
          _disposeTextures() {
            this._shareOutputWithPostProcess || this._forcedOutputTexture ? this._disposeTextureCache() : (this._disposeTextureCache(), this._textures.dispose())
          }
          _disposeTextureCache() {
            for (let OO = this._textureCache.length - 1; OO >= 0; OO--) this._textureCache[OO].texture.dispose();
            this._textureCache.length = 0
          }
          setPrePassRenderer(OO) {
            return !!this._prePassEffectConfiguration && (this._prePassEffectConfiguration = OO.addEffectConfiguration(this._prePassEffectConfiguration), this._prePassEffectConfiguration.enabled = !0, !0)
          }
          dispose(OO) {
            let KO;
            if (OO = OO || this.ZbO, this._useExistingThinPostProcess || this._effectWrapper.dispose(), this._disposeTextures(), this._scene && this._scene.removePostProcess(this), this._parentContainer && (KO = this._parentContainer.postProcesses.indexOf(this), KO > -1 && this._parentContainer.postProcesses.splice(KO, 1), this._parentContainer = null), KO = this._engine.postProcesses.indexOf(this), -1 !== KO && this._engine.postProcesses.splice(KO, 1), this.cpO.notifyObservers(), OO) {
              if (OO.detachPostProcess(this), KO = OO._postProcesses.indexOf(this), 0 === KO && OO._postProcesses.length > 0) {
                const OO = this.ZbO._getFirstPostProcess();
                OO && OO.markTextureDirty()
              }
              this.onActivateObservable.clear(), this.onAfterRenderObservable.clear(), this.onApplyObservable.clear(), this.onBeforeRenderObservable.clear(), this.onSizeChangedObservable.clear(), this.onEffectCreatedObservable.clear()
            }
          }
          serialize() {
            const OO = hO.c.Serialize(this),
              KO = this.getCamera() || this._scene && this._scene.activeCamera;
            return OO.customType = "BABYLON." + this.getClassName(), OO.cameraId = KO ? KO.id : null, OO.reusable = this._reusable, OO.textureType = this._textureType, OO.fragmentUrl = this._fragmentUrl, OO.parameters = this._parameters, OO.samplers = this._samplers, OO.uniformBuffers = this._uniformBuffers, OO.options = this._options, OO.defines = this._postProcessDefines, OO.textureFormat = this._textureFormat, OO.vertexUrl = this._vertexUrl, OO.indexParameters = this._indexParameters, OO
          }
          clone() {
            const KO = this.serialize();
            KO._engine = this._engine, KO.cameraId = null;
            const pO = OO.Parse(KO, this._scene, "");
            return pO ? (pO.onActivateObservable = this.onActivateObservable.clone(), pO.onSizeChangedObservable = this.onSizeChangedObservable.clone(), pO.onApplyObservable = this.onApplyObservable.clone(), pO.onBeforeRenderObservable = this.onBeforeRenderObservable.clone(), pO.onAfterRenderObservable = this.onAfterRenderObservable.clone(), pO._prePassEffectConfiguration = this._prePassEffectConfiguration, pO) : null
          }
          static Parse(OO, KO, pO) {
            const XO = (0, DO.e)(OO.customType);
            if (!XO || !XO._Parse) return null;
            const bK = KO ? KO.getCameraById(OO.cameraId) : null;
            return XO._Parse(OO, bK, KO, pO)
          }
          static _Parse(KO, pO, XO, bK) {
            return hO.c.Parse((() => new OO(KO.name, KO.fragmentUrl, KO.parameters, KO.samplers, KO.options, pO, KO.renderTargetSamplingMode, KO._engine, KO.reusable, KO.defines, KO.textureType, KO.vertexUrl, KO.indexParameters, !1, KO.textureFormat)), KO, XO, bK)
          }
        }, (() => {
          const pO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          KO = [(0, CO.M)()], vK = [(0, CO.M)()], MO = [(0, CO.M)()], FO = [(0, CO.M)()], VO = [(0, CO.M)()], QO = [(0, CO.v)()], zK = [(0, CO.M)()], AO = [(0, CO.M)()], fO = [(0, CO.M)()], dO = [(0, CO.M)()], TO = [(0, CO.M)()], NO = [(0, CO.M)()], IO = [(0, CO.M)()], yK = [(0, CO.M)()], gK = [(0, CO.M)("samples")], uO = [(0, CO.M)()], (0, XO.f)(OO, null, vK, {
            kind: "getter",
            name: "name",
            static: !1,
            private: !1,
            access: {
              has: OO => "name" in OO,
              get: OO => OO.name
            },
            metadata: pO
          }, null, EO), (0, XO.f)(OO, null, fO, {
            kind: "getter",
            name: "alphaMode",
            static: !1,
            private: !1,
            access: {
              has: OO => "alphaMode" in OO,
              get: OO => OO.alphaMode
            },
            metadata: pO
          }, null, EO), (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "uniqueId",
            static: !1,
            private: !1,
            access: {
              has: OO => "uniqueId" in OO,
              get: OO => OO.uniqueId,
              set: (OO, KO) => {
                OO.uniqueId = KO
              }
            },
            metadata: pO
          }, jK, YO), (0, XO.f)(null, null, MO, {
            kind: "field",
            name: "width",
            static: !1,
            private: !1,
            access: {
              has: OO => "width" in OO,
              get: OO => OO.width,
              set: (OO, KO) => {
                OO.width = KO
              }
            },
            metadata: pO
          }, wO, iK), (0, XO.f)(null, null, FO, {
            kind: "field",
            name: "height",
            static: !1,
            private: !1,
            access: {
              has: OO => "height" in OO,
              get: OO => OO.height,
              set: (OO, KO) => {
                OO.height = KO
              }
            },
            metadata: pO
          }, rK, PO), (0, XO.f)(null, null, VO, {
            kind: "field",
            name: "renderTargetSamplingMode",
            static: !1,
            private: !1,
            access: {
              has: OO => "renderTargetSamplingMode" in OO,
              get: OO => OO.renderTargetSamplingMode,
              set: (OO, KO) => {
                OO.renderTargetSamplingMode = KO
              }
            },
            metadata: pO
          }, mK, sO), (0, XO.f)(null, null, QO, {
            kind: "field",
            name: "clearColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "clearColor" in OO,
              get: OO => OO.clearColor,
              set: (OO, KO) => {
                OO.clearColor = KO
              }
            },
            metadata: pO
          }, HO, RO), (0, XO.f)(null, null, zK, {
            kind: "field",
            name: "autoClear",
            static: !1,
            private: !1,
            access: {
              has: OO => "autoClear" in OO,
              get: OO => OO.autoClear,
              set: (OO, KO) => {
                OO.autoClear = KO
              }
            },
            metadata: pO
          }, SO, JO), (0, XO.f)(null, null, AO, {
            kind: "field",
            name: "forceAutoClearInAlphaMode",
            static: !1,
            private: !1,
            access: {
              has: OO => "forceAutoClearInAlphaMode" in OO,
              get: OO => OO.forceAutoClearInAlphaMode,
              set: (OO, KO) => {
                OO.forceAutoClearInAlphaMode = KO
              }
            },
            metadata: pO
          }, cK, BO), (0, XO.f)(null, null, dO, {
            kind: "field",
            name: "alphaConstants",
            static: !1,
            private: !1,
            access: {
              has: OO => "alphaConstants" in OO,
              get: OO => OO.alphaConstants,
              set: (OO, KO) => {
                OO.alphaConstants = KO
              }
            },
            metadata: pO
          }, ZO, GO), (0, XO.f)(null, null, TO, {
            kind: "field",
            name: "enablePixelPerfectMode",
            static: !1,
            private: !1,
            access: {
              has: OO => "enablePixelPerfectMode" in OO,
              get: OO => OO.enablePixelPerfectMode,
              set: (OO, KO) => {
                OO.enablePixelPerfectMode = KO
              }
            },
            metadata: pO
          }, qK, xK), (0, XO.f)(null, null, NO, {
            kind: "field",
            name: "forceFullscreenViewport",
            static: !1,
            private: !1,
            access: {
              has: OO => "forceFullscreenViewport" in OO,
              get: OO => OO.forceFullscreenViewport,
              set: (OO, KO) => {
                OO.forceFullscreenViewport = KO
              }
            },
            metadata: pO
          }, nO, WO), (0, XO.f)(null, null, IO, {
            kind: "field",
            name: "scaleMode",
            static: !1,
            private: !1,
            access: {
              has: OO => "scaleMode" in OO,
              get: OO => OO.scaleMode,
              set: (OO, KO) => {
                OO.scaleMode = KO
              }
            },
            metadata: pO
          }, tK, kK), (0, XO.f)(null, null, yK, {
            kind: "field",
            name: "alwaysForcePOT",
            static: !1,
            private: !1,
            access: {
              has: OO => "alwaysForcePOT" in OO,
              get: OO => OO.alwaysForcePOT,
              set: (OO, KO) => {
                OO.alwaysForcePOT = KO
              }
            },
            metadata: pO
          }, UO, OK), (0, XO.f)(null, null, gK, {
            kind: "field",
            name: "_samples",
            static: !1,
            private: !1,
            access: {
              has: OO => "_samples" in OO,
              get: OO => OO._samples,
              set: (OO, KO) => {
                OO._samples = KO
              }
            },
            metadata: pO
          }, KK, pK), (0, XO.f)(null, null, uO, {
            kind: "field",
            name: "adaptScaleToCurrentViewport",
            static: !1,
            private: !1,
            access: {
              has: OO => "adaptScaleToCurrentViewport" in OO,
              get: OO => OO.adaptScaleToCurrentViewport,
              set: (OO, KO) => {
                OO.adaptScaleToCurrentViewport = KO
              }
            },
            metadata: pO
          }, XK, bp), pO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: pO
          })
        })(), OO
      })(),
      VO = !1;

    function LO() {
      VO || (VO = !0, MO.e.prototype.setTextureFromPostProcess = function(OO, KO, pO) {
        let XO = null;
        KO && (KO._forcedOutputTexture ? XO = KO._forcedOutputTexture : KO._textures.data[KO._currentRenderTextureInd] && (XO = KO._textures.data[KO._currentRenderTextureInd])), this._bindTexture(OO, XO?.texture ?? null, pO)
      }, MO.e.prototype.setTextureFromPostProcessOutput = function(OO, KO, pO) {
        this._bindTexture(OO, KO?._outputTexture?.texture ?? null, pO)
      }, vK.e.prototype.setTextureFromPostProcess = function(OO, KO) {
        this._engine.setTextureFromPostProcess(this._samplers[OO], KO, OO)
      }, vK.e.prototype.setTextureFromPostProcessOutput = function(OO, KO) {
        this._engine.setTextureFromPostProcessOutput(this._samplers[OO], KO, OO)
      }, (0, DO.h)("BABYLON.PostProcess", FO))
    }
  },
  39841: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      f: () => eO
    });
    var XO = pO(39819),
      bK = pO(35653);
    class eO extends XO.e {
      _gatherImports(OO, KO) {
        OO ? (this._webGPUReady = !0, KO.push(Promise.all([pO.e(351).then((() => pO(59329)))]))) : KO.push(Promise.all([pO.e(352).then((() => pO(59336)))])), super._gatherImports(OO, KO)
      }
      constructor(OO) {
        let KO = arguments.length > 2 ? arguments[2] : void 0;
        const pO = {
          name: OO,
          engine: (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null) || bK.c.LastCreatedEngine,
          useShaderStore: !0,
          useAsPostProcess: !0,
          fragmentShader: eO.FragmentUrl,
          ...KO
        };
        pO.engine || (pO.engine = bK.c.LastCreatedEngine), super(pO)
      }
    }
    eO.FragmentUrl = "pass";
    class lO extends XO.e {
      _gatherImports(OO, KO) {
        OO ? (this._webGPUReady = !0, KO.push(Promise.all([pO.e(353).then((() => pO(59345)))]))) : KO.push(Promise.all([pO.e(354).then((() => pO(59350)))])), super._gatherImports(OO, KO)
      }
      constructor(OO) {
        super({
          ...arguments.length > 2 ? arguments[2] : void 0,
          name: OO,
          engine: (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null) || bK.c.LastCreatedEngine,
          useShaderStore: !0,
          useAsPostProcess: !0,
          fragmentShader: lO.FragmentUrl,
          defines: "#define POSITIVEX"
        }), this._face = 0
      }
      get face() {
        return this._face
      }
      set face(OO) {
        if (!(OO < 0 || OO > 5)) switch (this._face = OO, this._face) {
          case 0:
            this.updateEffect("#define POSITIVEX");
            break;
          case 1:
            this.updateEffect("#define NEGATIVEX");
            break;
          case 2:
            this.updateEffect("#define POSITIVEY");
            break;
          case 3:
            this.updateEffect("#define NEGATIVEY");
            break;
          case 4:
            this.updateEffect("#define POSITIVEZ");
            break;
          case 5:
            this.updateEffect("#define NEGATIVEZ")
        }
      }
    }
    lO.FragmentUrl = "passCube"
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);