export const id = 52;
export const ids = [52];
export const modules = {
  35463: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      h: () => bK
    });
    const XO = "data-replay-ui-active",
      bK = [{
        group: "middleTextTop",
        dataAttr: "data-replay-hide-middle-text-top",
        label: "Middle text top"
      }, {
        group: "middleTextUpper",
        dataAttr: "data-replay-hide-middle-text-upper",
        label: "Middle text upper"
      }, {
        group: "middleTextLower",
        dataAttr: "data-replay-hide-middle-text-lower",
        label: "Middle text lower"
      }, {
        group: "rightInfoText",
        dataAttr: "data-replay-hide-right-info-text",
        label: "Right info text"
      }, {
        group: "crosshair",
        dataAttr: "data-replay-hide-crosshair",
        label: "Crosshair"
      }, {
        group: "flyingMiddleText",
        dataAttr: "data-replay-hide-flying-middle-text",
        label: "Flying middle text"
      }, {
        group: "hotbar",
        dataAttr: "data-replay-hide-hotbar",
        label: "Hotbar (shop, inventory, item name)"
      }, {
        group: "auraBar",
        dataAttr: "data-replay-hide-aura-bar",
        label: "Aura XP bar"
      }, {
        group: "healthAndShield",
        dataAttr: "data-replay-hide-health-and-shield",
        label: "Health bar and shield bar"
      }, {
        group: "effectInfo",
        dataAttr: "data-replay-hide-effect-info",
        label: "Effect info"
      }, {
        group: "nametag",
        dataAttr: null,
        label: "Nametags"
      }, {
        group: "everythingElse",
        dataAttr: "data-replay-hide-everything-else",
        label: "Everything else"
      }]
  },
  35470: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => hO,
      g: () => MO,
      k: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(35463);

    function lO() {
      const OO = {};
      for (const {
          group: KO
        }
        of eO.h) OO[KO] = !0;
      return OO
    }
    let vK = lO();

    function CO() {
      bK.i.pl("replayViewer|uiVisibilityChanged")
    }

    function hO() {
      return vK
    }

    function DO(OO, KO) {
      vK[OO] !== KO && (vK = {
        ...vK,
        [OO]: KO
      }, "nametag" === OO && XO.d.set({
        areNametagsHidden: !KO
      }), CO())
    }

    function MO() {
      vK = lO(), XO.d.set({
        areNametagsHidden: !1
      }), CO()
    }
  },
  40653: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      HOLD_TIMEOUT_MS: () => vK,
      ReplayViewer: () => hO
    });
    var XO = pO(35454),
      bK = pO(35470),
      eO = pO(3934),
      lO = pO(40618);
    const vK = 1e4,
      CO = new Set(["hX"]);
    class hO {
      constructor(OO) {
        var KO;
        this.deps = OO, this.id = 0, this.fileName = null, this.fileHandle = null, this.unsavedChanges = !1, this.suggestSaveAs = !1, this.playback = !1, this.opening = !1, this.loadingOpens = 0, this.epoch = 0, this.holds = new Map, this.seekAsked = !1, this.cropAsked = !1, this.cropRunning = !1, this.settleFrames = 0, this.pendingSave = null, this.pendingOpen = null, this.saveRefused = !1, this.edits = 0, this.editsAtSave = null, this.lastView = null, this.now = void 0, this.now = null !== (KO = OO.now) && void 0 !== KO ? KO : () => performance.now()
      }
      get inPlayback() {
        return this.playback
      }
      get view() {
        return this.lastView
      }
      get isOpen() {
        return null !== this.lastView && this.lastView.state !== eO.cd.None
      }
      get keyframes() {
        return this.deps.client.keyframes()
      }
      get JK() {
        return [...this.holds.keys()]
      }
      get savePending() {
        return null !== this.pendingSave
      }
      get saveRefusal() {
        return this.cropping ? XO.b.cropBusy.text : null
      }
      get cropping() {
        return this.cropAsked || this.cropRunning
      }
      async open(OO, KO) {
        var pO, bK, lO, vK;
        const {
          client: CO
        } = this.deps;
        if (!this.playback) {
          if (!CO.setPlayback(!0)) throw new Error(XO.b.cantOpen.text);
          this.playback = !0
        }
        this.hold("opening"), this.loadingOpens++;
        const hO = this.epoch;
        let DO;
        try {
          DO = await CO.open(OO)
        } finally {
          this.loadingOpens--
        }
        if (hO !== this.epoch) throw new Error(XO.b.coreStopped.text);
        if ("opening" !== DO) {
          this.opening || 0 !== this.loadingOpens || this.release("opening");
          const OO = function(OO) {
            switch (OO) {
              case "reloading":
                return null;
              case "stopped":
              case eO.Sc.ModuleTrap:
                return XO.b.coreStopped;
              case eO.Sc.ModuleLoad:
                return XO.b.viewerLoadFailed;
              case eO.Sc.TooLarge:
                return XO.b.cantOpen
            }
          }(DO);
          if (null === OO) return;
          throw new Error(OO.text)
        }
        return this.rejectSave(new Error(XO.b.saveClosed.text)), this.fileName = null !== (pO = null !== (bK = KO.fileName) && void 0 !== bK ? bK : null === (lO = KO.fileHandle) || void 0 === lO ? void 0 : lO.name) && void 0 !== pO ? pO : null, this.fileHandle = null !== (vK = KO.fileHandle) && void 0 !== vK ? vK : null, this.unsavedChanges = !1, this.suggestSaveAs = !1, this.opening = !0, this.cropAsked = !1, this.cropRunning = !1, this.seekAsked = !1, this.hold("opening"), this.id++, this.deps.onChange(), this.settleOpen(null), new Promise(((OO, KO) => {
          this.pendingOpen = {
            resolve: OO,
            reject: KO
          }
        }))
      }
      play() {
        this.holds.has("hX") || this.deps.client.play()
      }
      pause() {
        this.deps.client.pause()
      }
      holdForShaderPackFailure() {
        this.isOpen && this.pause(), this.hold("hX")
      }
      seek(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = this.lastView;
        null !== pO && (KO || OO < pO.KK) && (this.seekAsked = !0, this.hold("seek")), this.deps.client.seek(OO, KO)
      }
      setSpeed(OO) {
        this.deps.client.setSpeed(OO)
      }
      setCameraMode(OO) {
        this.deps.client.setCameraMode(OO)
      }
      cycleCameraMode() {
        const OO = this.lastView;
        null !== OO && OO.state !== eO.cd.None && this.setCameraMode(lO.d[(lO.d.indexOf(OO.cameraMode) + 1) % lO.d.length])
      }
      addKeyframe() {
        this.edited(this.deps.client.addKeyframe())
      }
      setKeyframe(OO) {
        this.edited(this.deps.client.setKeyframe(OO))
      }
      moveKeyframe(OO, KO) {
        this.edited(this.deps.client.moveKeyframe(OO, KO))
      }
      deleteKeyframes(OO, KO) {
        this.edited(this.deps.client.deleteKeyframes(OO, KO))
      }
      setMark(OO) {
        this.edited(this.deps.client.setMark(OO))
      }
      crop(OO, KO) {
        return !(KO <= OO) && (null !== this.pendingSave ? (this.deps.notify(XO.b.saveBusy), !1) : !!this.deps.client.crop(OO, KO) && (this.cropAsked = !0, this.hold("crop"), !0))
      }
      save() {
        return null !== this.pendingSave ? Promise.reject(new Error(XO.b.saveBusy.text)) : new Promise(((OO, KO) => {
          const pO = {
            resolve: OO,
            reject: KO
          };
          this.pendingSave = pO, this.editsAtSave = this.edits, this.deps.client.save((0, lO.g)()).then((OO => {
            this.pendingSave === pO && this.saveStarted(OO)
          }), (OO => {
            this.pendingSave === pO && this.rejectSave(OO instanceof Error ? OO : new Error(String(OO)))
          }))
        }))
      }
      saveStarted(OO) {
        switch (OO) {
          case "sealing":
            return;
          case "busy":
            return void this.saveFailed(!0);
          case "refused":
            return void(this.saveRefused = !0);
          case "tooLarge":
            return void this.saveFailed(!1)
        }
      }
      markSaved(OO, KO) {
        var pO, XO;
        this.fileHandle = OO, this.fileName = null !== (pO = null !== (XO = null === OO || void 0 === OO ? void 0 : OO.name) && void 0 !== XO ? XO : KO) && void 0 !== pO ? pO : this.fileName, this.unsavedChanges = null !== this.editsAtSave && this.edits !== this.editsAtSave, this.editsAtSave = null, this.suggestSaveAs = !1, this.deps.onChange()
      }
      end() {
        this.epoch++, this.resetInFlight(), this.releaseAll(), this.settleOpen(new Error(XO.b.coreStopped.text)), this.rejectSave(new Error(XO.b.saveClosed.text)), this.lastView = null, this.deps.onChange()
      }
      afterFrame() {
        var OO, KO, pO;
        const XO = this.deps.client.view(),
          lO = XO !== this.lastView;
        this.lastView = XO, this.opening && null !== XO && XO.state !== eO.cd.None && XO.totalTicks > 0 && (this.opening = !1, this.settleFrames = 2, this.settleOpen(null), (0, bK.g)()), this.cropAsked ? (this.cropAsked = !1, null !== XO && XO.state === eO.cd.Cropping ? this.cropRunning = !0 : this.cropped()) : this.cropRunning && null !== XO && XO.state !== eO.cd.Cropping && (this.cropRunning = !1, this.cropped()), this.seekAsked && (this.seekAsked = !1, this.settleFrames = 2), this.settleFrames > 0 && this.settleFrames--;
        const hO = 0 === this.settleFrames && 0 === (null !== (OO = null === (KO = (pO = this.deps).meshPending) || void 0 === KO ? void 0 : KO.call(pO)) && void 0 !== OO ? OO : 0);
        this.holds.has("opening") && !this.opening && 0 === this.loadingOpens && hO && this.release("opening"), this.holds.has("seek") && hO && this.release("seek"), this.holds.has("crop") && !this.cropRunning && hO && this.release("crop");
        const DO = this.now();
        for (const [bK, eO] of this.holds) !CO.has(bK) && DO - eO >= vK && (this.release(bK), "opening" === bK && (this.opening = !1, this.settleOpen(null)));
        this.saveRefused && !this.cropping && this.saveFailed(!1), lO && this.deps.onChange()
      }
      cropped() {
        (0, bK.g)(), this.id++, this.unsavedChanges = !0, this.suggestSaveAs = null !== this.fileHandle || null !== this.fileName, this.settleFrames = 2
      }
      onFailed(OO) {
        switch (OO.reason) {
          case eO.Sc.TooLarge:
            break;
          case eO.Sc.Open:
          case eO.Sc.NothingStaged:
            this.opening = !1, this.release("opening"), null === this.pendingOpen && this.deps.notify(XO.b.cantOpen), this.settleOpen(new Error(XO.b.cantOpen.text));
            break;
          case eO.Sc.Crop:
            if (OO.code === eO.Qc.Busy) {
              this.cropBusy();
              break
            }
            if (!this.cropping && this.saveRefused) {
              this.saveFailed(!1);
              break
            }
            this.cropAsked = !1, this.cropRunning = !1, this.release("crop"), this.deps.notify(XO.b.cropFailed);
            break;
          case eO.Sc.ModuleTrap:
          case eO.Sc.ModuleLoad:
          case eO.Sc.Port:
            this.moduleEnded(OO.reason === eO.Sc.ModuleTrap ? XO.b.coreStopped : XO.b.cantOpen);
            break;
          case eO.Sc.NotLive:
            console.warn("[bloxd-wasm-client] the core refused a recorder command in playback");
            break;
          default:
            console.warn(`[bloxd-wasm-client] the replay module refused a command (ReplayFailed ${OO.reason})`), this.seekAsked = !1, this.release("seek")
        }
        this.deps.onChange()
      }
      moduleEnded(OO) {
        this.resetInFlight(), this.release("opening"), this.release("seek"), this.release("crop"), null === this.pendingOpen && this.deps.notify(OO), this.settleOpen(new Error(OO.text))
      }
      saveDone(OO) {
        const KO = this.pendingSave;
        this.pendingSave = null, this.saveRefused = !1, null === KO || void 0 === KO || KO.resolve(OO)
      }
      saveFailed(OO) {
        this.rejectSave(new Error(OO ? XO.b.saveBusy.text : "The replay couldn't be saved"))
      }
      edited(OO) {
        OO && !this.cropping && (this.edits++, this.unsavedChanges = !0, this.deps.onChange())
      }
      cropBusy() {
        null !== this.pendingSave && this.saveRefused ? this.rejectSave(new Error(XO.b.cropBusy.text)) : this.deps.notify(XO.b.cropBusy)
      }
      resetInFlight() {
        this.opening = !1, this.seekAsked = !1, this.cropAsked = !1, this.cropRunning = !1, this.settleFrames = 0
      }
      settleOpen(OO) {
        const KO = this.pendingOpen;
        this.pendingOpen = null, null === OO ? null === KO || void 0 === KO || KO.resolve() : null === KO || void 0 === KO || KO.reject(OO)
      }
      rejectSave(OO) {
        const KO = this.pendingSave;
        this.pendingSave = null, this.saveRefused = !1, null === KO || void 0 === KO || KO.reject(OO)
      }
      hold(OO) {
        const KO = 0 === this.holds.size;
        this.holds.set(OO, this.now()), KO && this.deps.setHoldDraws(!0)
      }
      release(OO) {
        this.holds.delete(OO) && 0 === this.holds.size && this.deps.setHoldDraws(!1)
      }
      releaseAll() {
        this.holds.size > 0 && (this.holds.clear(), this.deps.setHoldDraws(!1))
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);