export const id = 179;
export const ids = [44, 179];
export const modules = {
  36932: (OO, KO, pO) => {
    var XO = {
      "./combat_1.png": 36941,
      "./dungeon_crumbling_crypt.png": 36949,
      "./dungeon_frozen_hollow.png": 36958,
      "./dungeon_wildwood_grove.png": 36960,
      "./dungeons.png": 36962,
      "./farming_1.png": 36969,
      "./fishing_1.png": 36973,
      "./hub.png": 36982,
      "./island.png": 36985,
      "./mining_1.png": 36991,
      "./mining_1_bridge.png": 36997,
      "./mining_1_gallery.png": 37002,
      "./mining_1_hollow.png": 37008,
      "./mining_1_village.png": 37012
    };

    function bK(OO) {
      var KO = eO(OO);
      return pO(KO)
    }

    function eO(OO) {
      if (!pO.o(XO, OO)) {
        var KO = new Error("Cannot find module '" + OO + "'");
        throw KO.code = "MODULE_NOT_FOUND", KO
      }
      return XO[OO]
    }
    bK.keys = function() {
      return Object.keys(XO)
    }, bK.resolve = eO, OO.exports = bK, bK.id = 36932
  },
  37020: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      e: () => eO
    });
    const XO = new WeakMap;

    function bK(OO, KO) {
      return XO.set(OO, KO), OO
    }

    function eO(OO) {
      var KO;
      return null !== (KO = XO.get(OO)) && void 0 !== KO ? KO : null
    }
  },
  36921: (OO, KO, pO) => {
    function XO(OO, KO, pO) {
      var XO;
      const {
        width: bK,
        height: eO
      } = pO, lO = null !== (XO = OO.text) && void 0 !== XO ? XO : OO, vK = (lO.x / 100 - .5) * bK, CO = (lO.y / 100 - .5) * eO, hO = bK / 2 - KO.x;
      if (null !== OO.text && Math.abs(vK) <= hO && CO >= KO.top - eO / 2 && CO <= eO / 2 - KO.bottom) return {
        x: lO.x,
        y: lO.y
      };
      const DO = Math.min(0 === vK ? 1 / 0 : hO / Math.abs(vK), CO > 0 ? (eO / 2 - KO.bottom) / CO : CO < 0 ? (KO.top - eO / 2) / CO : 1 / 0);
      return !Number.isFinite(DO) || DO < 0 ? {
        x: 50,
        y: 50
      } : {
        x: 50 + vK * DO / bK * 100,
        y: 50 + CO * DO / eO * 100
      }
    }
    pO.d(KO, {
      c: () => XO
    })
  },
  37022: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      SkyblockEntityFacing: () => vK,
      needsSkyblockEntityFacing: () => lO
    });
    var XO = pO(36928),
      bK = pO(3520),
      eO = pO(37025);

    function lO(OO, KO) {
      if (OO.metaInfo === XO.n || "Iron Guardian" === OO.type || "Gold Guardian" === OO.type) return !0;
      if ("Pig" === OO.type) return "sitting" === OO.pose;
      if ("Person" !== OO.meshKind || void 0 === OO.meshOpts) return !1;
      let pO = null === KO || void 0 === KO ? void 0 : KO.get(OO.meshOpts);
      if (void 0 === pO) {
        var eO, lO;
        const XO = (0, bK.f)(OO);
        pO = !1, "pig_napoleon" === (null === XO || void 0 === XO || null === (eO = XO.opts.textures) || void 0 === eO ? void 0 : eO.head) ? pO = !0 : "npc_pig_head" === (null === XO || void 0 === XO || null === (lO = XO.opts.textures) || void 0 === lO ? void 0 : lO.head) && (pO = "sitting" === XO.opts.pose || "sitting"), KO && (KO.size >= 256 && KO.clear(), KO.set(OO.meshOpts, pO))
      }
      return "sitting" === pO ? "sitting" === OO.pose : pO
    }(0, eO.h)("skyblock", ((OO, KO) => {
      KO.setFacingTolerance(lO(OO) ? 0 : null)
    }));
    class vK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        this.api = OO, this.alsoVisit = KO, this.facing = new Set, this.nextFacing = new Set, this.meshFacingCache = new Map, this.visit = OO => {
          var KO;
          const pO = this.api.getEntityInfo(OO);
          pO && (lO(pO, this.meshFacingCache) && (this.api.setFacingTolerance(OO, 0), this.nextFacing.add(OO)), null === (KO = this.alsoVisit) || void 0 === KO || KO.call(this, OO, pO))
        }
      }
      KK() {
        const {
          api: OO
        } = this, KO = this.nextFacing;
        OO.forEachEntity(this.visit);
        for (const pO of this.facing) KO.has(pO) || OO.setFacingTolerance(pO, null);
        this.facing.clear(), this.nextFacing = this.facing, this.facing = KO
      }
      dispose() {
        for (const OO of this.facing) this.api.setFacingTolerance(OO, null);
        this.facing.clear(), this.meshFacingCache.clear()
      }
    }
  },
  36913: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => pC
    });
    const XO = "island";
    var bK = pO(256);
    const eO = (0, bK.wb)([0, 0, -1]),
      lO = [{
        name: "S",
        bearing: (0, bK.wb)([0, 0, 1])
      }, {
        name: "E",
        bearing: (0, bK.wb)([-1, 0, 0])
      }, {
        name: "N",
        bearing: eO
      }, {
        name: "W",
        bearing: (0, bK.wb)([1, 0, 0])
      }];

    function vK(OO, KO, pO) {
      return [100 * (pO.mapMaxX - OO) / (pO.mapMaxX - pO.mapMinX), 100 * (KO - pO.mapMinZ) / (pO.mapMaxZ - pO.mapMinZ)]
    }

    function CO(OO, KO, pO) {
      const bK = "local" === KO,
        eO = OO.background,
        lO = KO => eO ? vK(KO[0] - OO.mapOrigin[0], KO[2] - OO.mapOrigin[2], eO.bounds) : [50, 50],
        CO = (OO.insideDungeon ? [] : OO.landmarks).map((OO => {
          var KO, XO;
          return {
            id: OO.id,
            name: pO(OO.visited && OO.nameKey ? null !== (KO = OO.mapLabelKey) && void 0 !== KO ? KO : OO.nameKey : "skyblockGame:mapUnknown"),
            icon: OO.visited && null !== (XO = OO.icon) && void 0 !== XO ? XO : "unknown",
            visited: OO.visited,
            current: !1,
            position: lO(OO.position),
            travelKind: "landmark",
            travelId: OO.id
          }
        })),
        DO = OO.zones.map((KO => {
          var XO;
          return {
            id: KO.id,
            name: pO(KO.visited && KO.nameKey ? KO.nameKey : "skyblockGame:mapUnknown"),
            icon: KO.visited && null !== (XO = KO.icon) && void 0 !== XO ? XO : "unknown",
            visited: KO.visited,
            current: KO.id === OO.zoneId,
            position: KO.position,
            thumbnail: KO.visited ? KO.id : void 0,
            travelKind: "zone",
            travelId: KO.id
          }
        })),
        MO = OO.insideDungeon || !eO ? [] : OO.portals.map((OO => {
          var KO;
          return {
            id: OO.id,
            name: pO(null !== (KO = OO.nameKey) && void 0 !== KO ? KO : "skyblockGame:mapUnknown"),
            icon: OO.visited ? "dungeons" === OO.destination ? "portal_orange" : "portal" : "unknown",
            visited: OO.visited,
            current: !1,
            position: lO(OO.position),
            colour: OO.colour,
            travelKind: "zone",
            travelId: OO.destination
          }
        })),
        aK = bK ? CO : DO,
        oO = aK.filter((OO => OO.visited)).length,
        FO = eO ? (eO.bounds.mapMaxX - eO.bounds.mapMinX) / (eO.bounds.mapMaxZ - eO.bounds.mapMinZ) : 2,
        VO = eO ? JSON.stringify([eO.bounds, OO.mapOrigin]) : "";
      return {
        local: bK,
        points: aK,
        portals: bK ? MO : [],
        progress: aK.length ? pO("skyblockGame:mapDiscovered", {
          current: String(oO),
          total: String(aK.length)
        }) : null,
        percent: aK.length ? 100 * oO / aK.length : 0,
        canTravel: [...aK, ...bK ? MO : []].some((OO => OO.visited && !OO.current)),
        noLandmarks: bK && !OO.insideDungeon && 0 === CO.length,
        background: eO ? {
          imageKey: eO.imageKey,
          fallbackImageKey: OO.zoneId,
          geometryKey: VO,
          label: pO(eO.labelKey),
          colour: eO.backgroundColour,
          ratio: FO
        } : null,
        connections: hO(OO.zones),
        minimap: eO ? {
          imageKey: eO.imageKey,
          fallbackImageKey: OO.zoneId,
          geometryKey: VO,
          label: pO(eO.labelKey),
          colour: eO.backgroundColour,
          caption: pO(OO.zoneId === XO ? "skyblockGame:zoneIsland" : eO.labelKey),
          width: (eO.bounds.mapMaxX - eO.bounds.mapMinX) / eO.minimapSpan * 100 + "%",
          height: (eO.bounds.mapMaxZ - eO.bounds.mapMinZ) / eO.minimapSpan * 100 + "%",
          markers: [...CO, ...MO]
        } : null
      }
    }

    function hO(OO) {
      const KO = new Set;
      return OO.flatMap((pO => pO.connections.flatMap((XO => {
        const bK = OO.find((OO => OO.id === XO)),
          eO = [pO.id, XO].sort().join("|");
        return !bK || KO.has(eO) ? [] : (KO.add(eO), [{
          id: `${pO.id}-${XO}`,
          start: pO.position,
          end: bK.position,
          explored: pO.visited && bK.visited
        }])
      }))))
    }
    class DO {
      constructor(OO, KO, pO) {
        this.pl = OO, this.beforeOpen = KO, this.afterClose = pO, this.open = !1, this.YX = !1, this.snapshot = void 0, this.getSnapshot = () => this.snapshot, this.show = () => {
          this.isEnabled() && !this.YX && (this.open = !0, this.beforeOpen(), this.emit())
        }, this.close = () => {
          this.closePanel(!1)
        }, this.dismiss = () => {
          this.closePanel(!0)
        }
      }
      isOpen() {
        return this.open
      }
      closePanel(OO) {
        this.open = !1, this.onClosed(), this.emit(), this.afterClose(OO)
      }
      onClosed() {}
      dispose() {
        this.open = !1, this.emit(), this.YX = !0
      }
      emit() {
        this.YX || (this.snapshot = this.buildSnapshot(), this.pl(this.snapshot))
      }
    }
    const MO = "skyblockMapView";
    class aK extends DO {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : () => {},
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : () => {},
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : Date.now;
        super(OO, XO, bK), this.requestTravel = KO, this.translate = pO, this.now = eO, this.entities = [], this.map = null, this.tab = "local", this.pending = null, this.nextRequestId = 0, this.feedbackKey = "", this.snapshot = {
          presentation: null,
          enabled: !1,
          open: !1,
          tab: "local",
          map: null,
          pending: !1,
          feedback: ""
        }, this.showLocal = () => {
          this.selectTab("local"), this.show()
        }, this.selectTab = OO => {
          this.tab = OO, this.feedbackKey = "", this.emit()
        }, this.travel = (OO, KO) => {
          if (!this.map || this.pending || this.YX) return;
          const pO = ("zone" === OO ? this.map.zones : this.map.landmarks).find((OO => OO.id === KO));
          if (pO) {
            if (this.map.insideDungeon) this.feedbackKey = "skyblockGame:mapDungeonTravelDisabled";
            else if ("fastTravelEnabled" in pO && !pO.fastTravelEnabled) this.feedbackKey = "skyblockGame:mapLandmarkTravelDisabled";
            else if (pO.visited)
              if ("zone" === OO && KO === this.map.zoneId) this.feedbackKey = "skyblockGame:mapAlreadyHere";
              else {
                const pO = ++this.nextRequestId;
                this.pending = {
                  requestId: pO,
                  expiresAt: this.now() + 1e4
                }, this.feedbackKey = "skyblockGame:mapTravelling", this.requestTravel({
                  kind: OO,
                  id: KO,
                  requestId: pO
                })
              }
            else this.feedbackKey = "skyblockGame:mapVisitFirst";
            this.emit()
          }
        }
      }
      getEntities() {
        return this.entities
      }
      setTranslator(OO) {
        this.translate = OO, this.emit()
      }
      PX(OO) {
        var KO;
        if (!this.YX)
          if ("entities" !== OO.kind)
            if ("open" !== OO.kind) {
              var pO, XO;
              if ("snapshot" === OO.kind)(null === (pO = OO.snapshot) || void 0 === pO ? void 0 : pO.zoneId) !== (null === (XO = this.map) || void 0 === XO ? void 0 : XO.zoneId) && (this.pending = null, this.feedbackKey = ""), this.map = OO.snapshot, !this.map && this.open && this.close();
              else if ("travelQueued" === OO.kind) {
                var bK;
                OO.requestId === (null === (bK = this.pending) || void 0 === bK ? void 0 : bK.requestId) && (this.pending.expiresAt = 1 / 0, this.close())
              } else if (OO.requestId === (null === (KO = this.pending) || void 0 === KO ? void 0 : KO.requestId)) {
                var eO;
                this.pending = null, this.feedbackKey = null !== (eO = OO.errorKey) && void 0 !== eO ? eO : "", null === OO.errorKey && this.close()
              }
              this.emit()
            } else this.show();
        else this.entities = OO.entities
      }
      KK() {
        this.pending && this.now() >= this.pending.expiresAt && (this.pending = null, this.feedbackKey = "skyblockGame:mapTravelTimeout", this.emit())
      }
      dispose() {
        this.map = null, this.pending = null, super.dispose()
      }
      isEnabled() {
        return null !== this.map
      }
      buildSnapshot() {
        return {
          presentation: this.map ? CO(this.map, this.tab, this.translate) : null,
          enabled: this.isEnabled(),
          open: this.open,
          tab: this.tab,
          map: this.map,
          pending: null !== this.pending,
          feedback: this.feedbackKey ? this.translate(this.feedbackKey) : ""
        }
      }
    }
    const oO = 67.5 * Math.PI / 180;

    function FO(OO, KO) {
      const pO = Math.abs(OO);
      if (pO > oO || KO.trackHalfWidth <= 0) return null;
      const XO = KO.trackHalfWidth,
        bK = KO.screenHalfWidth / (KO.tanHalfFovX * Math.max(.5, Math.cos(KO.pitch))),
        eO = Math.min(Math.atan(.6 * XO / bK), .75 * oO),
        lO = bK * Math.tan(eO);
      let vK;
      if (pO <= eO) vK = bK * Math.tan(pO);
      else {
        const OO = oO - eO,
          KO = Math.max(0, bK * OO / (Math.cos(eO) ** 2 * (XO - lO)) - 1),
          CO = (pO - eO) / OO;
        vK = lO + (XO - lO) * (1 + KO) * CO / (1 + KO * CO)
      }
      return 50 + Math.sign(OO) * vK * 50 / XO
    }
    class VO {
      constructor(OO, KO) {
        this.map = OO, this.visited = KO, this.id = void 0, this.enabled = !0, this.range = 96, this.limit = 40, this.id = KO ? "landmarks" : "unknownLandmarks"
      }
      getPoints() {
        const OO = this.map.getSnapshot().map;
        return !OO || OO.insideDungeon ? [] : OO.landmarks.filter((OO => OO.visited === this.visited)).map((OO => {
          var KO, pO;
          return {
            id: `landmark:${OO.id}`,
            position: OO.position,
            icon: null !== (KO = OO.icon) && void 0 !== KO ? KO : "unknown",
            nameKey: null !== (pO = OO.nameKey) && void 0 !== pO ? pO : "skyblockGame:compassUnknown",
            kind: this.visited ? "landmark" : "unknown"
          }
        }))
      }
    }
    class LO {
      constructor(OO, KO, pO, XO) {
        this.map = OO, this.kind = KO, this.position = pO, this.alive = XO, this.id = void 0, this.enabled = !0, this.range = void 0, this.limit = void 0, this.id = KO, this.range = "enemy" === KO ? 48 : 64, this.limit = 12
      }
      fV(OO) {
        if ("enemy" !== this.kind || this.alive(OO.Om)) return this.position(OO.Om)
      }
      getPoints() {
        const OO = [];
        for (const XO of this.map.getEntities()) {
          if (XO.kind !== this.kind || "enemy" === this.kind && !this.alive(XO.compassEntityId)) continue;
          const bK = this.position(XO.compassEntityId);
          var KO, pO;
          if (bK) OO.push({
            id: `${this.kind}:${XO.compassEntityId}`,
            Om: XO.compassEntityId,
            kind: this.kind,
            icon: null !== (KO = XO.icon) && void 0 !== KO ? KO : XO.npcSkin ? `npc_${XO.npcSkin}` : this.kind,
            displayName: XO.displayName,
            position: bK,
            nameKey: null !== (pO = XO.nameKey) && void 0 !== pO ? pO : "enemy" === this.kind ? "skyblockGame:compassEnemy" : "skyblockGame:compassNpc"
          })
        }
        return OO
      }
    }
    class QO {
      constructor(OO) {
        this.map = OO, this.id = "portals", this.enabled = !0, this.range = 96, this.limit = 12
      }
      getPoints() {
        const OO = this.map.getSnapshot().map;
        return !OO || OO.insideDungeon ? [] : OO.portals.map((OO => {
          var KO;
          return {
            id: "portal:" + OO.id,
            kind: "portal",
            position: OO.position,
            nameKey: null !== (KO = OO.nameKey) && void 0 !== KO ? KO : "skyblockGame:compassUnvisitedZone",
            icon: OO.visited ? "dungeons" === OO.destination ? "portal_orange" : "portal" : "unknown",
            colour: OO.colour
          }
        }))
      }
    }
    class zK {
      constructor(OO) {
        this.target = OO, this.id = "quest", this.enabled = !0, this.range = 1 / 0, this.limit = 1
      }
      getPoints() {
        const OO = this.target();
        return OO ? [{
          id: "quest",
          kind: "quest",
          icon: "quest",
          position: OO.position,
          nameKey: OO.nameKey
        }] : []
      }
    }

    function AO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : OO.position;
      const eO = XO[0] - KO[0],
        lO = XO[2] - KO[2];
      return {
        ...OO,
        position: XO,
        offset: bK.e.computeShortestRotation(pO, (0, bK.wb)([eO, 0, lO])),
        distance: Math.hypot(eO, XO[1] - KO[1], lO)
      }
    }
    let fO;

    function dO(OO, KO) {
      var pO;
      return (null === (pO = fO) || void 0 === pO ? void 0 : pO.locale) !== KO && (fO = {
        locale: KO,
        near: new Intl.NumberFormat(KO, {
          minimumFractionDigits: 1,
          maximumFractionDigits: 1
        }),
        far: new Intl.NumberFormat(KO, {
          minimumFractionDigits: 0,
          maximumFractionDigits: 0
        })
      }), (OO < 10 ? fO.near : fO.far).format(OO)
    }
    class TO {
      constructor() {
        this.providers = new Map, this.candidates = [], this.refreshAt = 0
      }
      register(OO) {
        return this.providers.set(OO.id, OO), this.refreshAt = 0, () => {
          this.providers.get(OO.id) === OO && (this.providers.delete(OO.id), this.refreshAt = 0)
        }
      }
      frame(OO, KO, pO) {
        if (pO >= this.refreshAt) {
          this.refreshAt = pO + 200, this.candidates = [];
          for (const KO of this.providers.values()) {
            if (!KO.enabled) continue;
            const pO = KO.getPoints().map((KO => {
              const pO = KO.position;
              return {
                point: KO,
                distance: Math.hypot(pO[0] - OO[0], pO[1] - OO[1], pO[2] - OO[2])
              }
            })).filter((OO => OO.distance <= KO.range)).sort(((OO, KO) => OO.distance - KO.distance)).slice(0, KO.limit);
            for (const {
                point: OO
              }
              of pO) this.candidates.push({
              provider: KO,
              point: OO
            })
          }
        }
        const XO = [];
        for (const {
            point: bK,
            provider: eO
          }
          of this.candidates) {
          if (!eO.enabled) continue;
          const pO = eO.fV ? eO.fV(bK) : bK.position;
          if (pO) {
            const eO = AO(bK, OO, KO, pO);
            Math.abs(eO.offset) <= oO && XO.push(eO)
          }
        }
        return XO
      }
      dispose() {
        this.providers.clear(), this.candidates = []
      }
    }
    var NO = pO(35139),
      IO = pO(63);
    const yK = [{
        dailyRewardCoins: 1e3,
        dailyRewardItems: []
      }, {
        dailyRewardCoins: 3e3,
        dailyRewardItems: []
      }, {
        dailyRewardCoins: 4e3,
        dailyRewardItems: []
      }, {
        dailyRewardCoins: 5500,
        dailyRewardItems: []
      }, {
        dailyRewardCoins: 7e3,
        dailyRewardItems: []
      }, {
        dailyRewardCoins: 9e3,
        dailyRewardItems: [{
          dailyRewardItemName: "Gold Bar",
          dailyRewardItemAmount: 2
        }]
      }, {
        dailyRewardCoins: 25e3,
        dailyRewardItems: [{
          dailyRewardItemName: "Gold Bar",
          dailyRewardItemAmount: 3
        }, {
          dailyRewardItemName: "Diamond",
          dailyRewardItemAmount: 1
        }]
      }],
      gK = yK.length;

    function uO(OO) {
      return OO >= gK ? 1 : OO + 1
    }
    const EO = "skyblockQuests";
    var jK = pO(36928);
    const YO = "devquests",
      wO = "none",
      iK = {
        hub: {
          farming_1: {
            min: [4, 16, 90],
            max: [4, 18, 91],
            unlockedBlock: "Yellow Portal"
          },
          mining_1: {
            min: [95, 16, 2],
            max: [97, 18, 2],
            unlockedBlock: "Cyan Portal"
          },
          combat_1: {
            min: [207, 36, 49],
            max: [208, 38, 49],
            unlockedBlock: "Red Portal"
          },
          fishing_1: {
            min: [6, 20, 149],
            max: [6, 22, 150],
            unlockedBlock: "Blue Portal"
          }
        },
        combat_1: {
          tower_roof: {
            min: [202, 69, 151],
            max: [203, 71, 151],
            unlockedBlock: "Red Portal",
            lockedBlock: "Grey Portal"
          },
          tower_exit: {
            min: [202, 80, 133],
            max: [203, 82, 133],
            unlockedBlock: "Red Portal",
            lockedBlock: "Grey Portal"
          }
        }
      },
      rK = "Compressed Messy Stone",
      PO = {
        "Grass Block": "Useless Soil",
        "Pine Grass Block": "Useless Soil",
        "Jungle Grass Block": "Useless Soil",
        "Dry Grass Block": "Useless Soil",
        "Overgrown Grass Block": "Useless Soil",
        "Overgrown Pine Grass Block": "Useless Soil",
        "Overgrown Jungle Grass Block": "Useless Soil",
        "Overgrown Dry Grass Block": "Useless Soil",
        Dirt: "Messy Dirt",
        Sand: "Sandstone",
        Gravel: "Smooth Andesite"
      },
      mK = ["Stone", "Diorite", "Andesite", "Granite"],
      sO = new Set(mK),
      HO = (Object.keys(PO), {
        "Pure Coal Ore": "Coal Ore",
        "Pure Iron Ore": "Iron Ore",
        "Pure Gold Ore": "Gold Ore",
        "Pure Diamond Ore": "Diamond Ore",
        "Pure Moonstone Ore": "Moonstone Ore"
      });
    const RO = ["Magmasteel Helmet", "Magmasteel Chestplate", "Magmasteel Gauntlets", "Magmasteel Leggings", "Magmasteel Boots"];

    function SO(OO, KO) {
      const pO = Math.floor(5 * OO / (2 * KO + 1));
      return Math.min(4, Math.max(0, pO))
    }
    var JO = pO(1098);
    var cK = pO(34952);
    var BO = pO(35137),
      ZO = pO(26),
      GO = pO(7952);
    const qK = ["foraging", "combat", "mining", "farming", "fishing", "exploration"],
      xK = 1e3;

    function nO(OO) {
      return Math.max(0, OO)
    }

    function WO(OO) {
      return 1 + .01 * nO(OO)
    }

    function tK(OO) {
      return 1 + .005 * nO(OO)
    }

    function kK(OO) {
      return 1 + .005 * nO(OO)
    }

    function UO(OO) {
      return .01 * nO(OO)
    }

    function OK(OO) {
      return 150 / (150 + nO(OO))
    }

    function KK(OO) {
      return 1 + .002 * nO(OO)
    }

    function pK(OO) {
      return Math.round(10 * OO) / 10
    }

    function XK(OO, KO) {
      switch (OO) {
        case "foraging":
          return {
            translationKey: "skyblockGame:foragingBenefit", percent: pK(100 * (tK(KO) - 1))
          };
        case "combat":
          return {
            translationKey: "skyblockGame:combatBenefit", percent: pK(100 * (WO(KO) - 1))
          };
        case "mining":
          return {
            translationKey: "skyblockGame:miningBenefit", percent: pK(100 * (kK(KO) - 1))
          };
        case "farming":
          return {
            translationKey: "skyblockGame:farmingBenefit", percent: pK(100 * UO(KO))
          };
        case "fishing":
          return {
            translationKey: "skyblockGame:fishingBenefit", percent: pK(100 * (1 - OK(KO)))
          };
        case "exploration":
          return {
            translationKey: "skyblockGame:explorationBenefit", percent: pK(100 * (KK(KO) - 1))
          }
      }
    }

    function bp(OO) {
      return "farming" === OO ? 200 : 100
    }

    function eK(OO, KO) {
      if (!Number.isSafeInteger(OO) || OO < 0) throw new Error("Skill XP must be a non-negative safe integer");
      const pO = bp(KO),
        XO = OO => function(OO, KO) {
          return bp(OO) * KO * (KO + 1) / 2
        }(KO, OO);
      let bK = Math.min(xK, Math.floor((Math.sqrt(8 * OO / pO + 1) - 1) / 2));
      return bK < xK && XO(bK + 1) <= OO ? bK++ : XO(bK) > OO && bK--, {
        totalXp: OO,
        level: bK,
        xpIntoLevel: OO - XO(bK),
        xpForNextLevel: bK === xK ? null : pO * (bK + 1)
      }
    }
    const lK = new Set(["Apple Block", "Plum Block", "Coconut Block", "Pear Block", "Cherry Block", "Mango Block", "Banana Block"]);

    function vp(OO) {
      return lK.has(OO)
    }
    const CK = new Set(bK.lb);

    function hK(OO) {
      return CK.has(OO)
    }
    new Set(["Watermelon", "Melon", "Wheat|FreshlyGrown", "Rice|FreshlyGrown", "Corn Plant|FreshlyGrown", "Chili Pepper Plant|FreshlyGrown", "Chili Pepper Plant|Lava|FreshlyGrown", "Tomato Plant|FreshlyGrown", "Tomato Plant|Top|FreshlyGrown", "Carrot Plant|FreshlyGrown", "Potato Plant|FreshlyGrown", "Sugar Cane Plant|FreshlyGrown", "Sugar Cane Plant|Top|FreshlyGrown", "Coffee Plant|FreshlyGrown", "Lettuce Plant|FreshlyGrown", "Cauliflower Plant|FreshlyGrown", "Parsnip Plant|FreshlyGrown", "Red Cabbage Plant|FreshlyGrown", "Beetroot Plant|FreshlyGrown"]);
    const DK = {
        "Maple Log": 10,
        "Pine Log": 10,
        "Plum Log": 10,
        "Cedar Log": 10,
        "Aspen Log": 10,
        "Jungle Log": 10,
        "Palm Log": 10,
        "Pear Log": 10,
        "Cherry Log": 10,
        "Spectral Log": 10,
        "Mango Log": 10
      },
      MK = {
        Stone: 2,
        Diorite: 18,
        Granite: 18,
        Andesite: 18,
        "Coal Ore": 10,
        "Iron Ore": 15,
        "Gold Ore": 20,
        "Diamond Ore": 30,
        "Moonstone Ore": 40,
        "Block of Coal": 15,
        "Block of Gold": 30
      },
      ap = {
        ...MK,
        ...Object.fromEntries(Object.entries(HO).map((OO => {
          let [KO, pO] = OO;
          return [KO, 9 * MK[pO]]
        })))
      },
      oK = {
        Watermelon: 10,
        Melon: 10,
        "Wheat|FreshlyGrown": 10,
        "Rice|FreshlyGrown": 10,
        "Corn Plant|FreshlyGrown": 10,
        "Chili Pepper Plant|FreshlyGrown": 10,
        "Chili Pepper Plant|Lava|FreshlyGrown": 10,
        "Tomato Plant|FreshlyGrown": 10,
        "Tomato Plant|Top|FreshlyGrown": 10,
        "Carrot Plant|FreshlyGrown": 10,
        "Potato Plant|FreshlyGrown": 10,
        "Sugar Cane Plant|FreshlyGrown": 10,
        "Sugar Cane Plant|Top|FreshlyGrown": 10,
        "Coffee Plant|FreshlyGrown": 10,
        "Lettuce Plant|FreshlyGrown": 10,
        "Cauliflower Plant|FreshlyGrown": 10,
        "Parsnip Plant|FreshlyGrown": 10,
        "Red Cabbage Plant|FreshlyGrown": 10,
        "Beetroot Plant|FreshlyGrown": 10
      },
      FK = {
        Wheatfish: 25,
        Darter: 25,
        "Sunset Minnow": 25,
        "Root Flounder": 25,
        "Greenfin Loach": 25,
        "Red Strongfish": 30,
        "Green Strongfish": 30,
        "Boomerang Fish": 30,
        Seahorse: 30,
        "Spined Stickleback": 30,
        "Moon Strongfish": 40,
        "Boulder Bass": 40,
        "Grass Snapper": 40,
        "Crystalized Wheatfish": 55,
        "Moonstone Pupfish": 55,
        "Reedglass Minnow": 35,
        "Mangrove Herring": 35,
        "Mudline Perch": 35,
        "Coastal Mullet": 35,
        "Reef Sardine": 35,
        "Root Perch": 40,
        "Aether Minnow": 40,
        "Driftwood Catfish": 45,
        "Tri-Pointed Needlefish": 70,
        "Threadfin Bream": 40,
        "Mudbelly Tilapia": 40,
        "Rotslab Eel": 40,
        "Polarflash Electron": 45,
        Hatchetfish: 45,
        "Mireback Carp": 50,
        "Blackwater Bream": 50,
        "Stone Grouper": 55,
        "Shadeback Ray": 60,
        "Glacial Silverfish": 60,
        "Moonlit Boomerang Fish": 90,
        "Murkborne Ray": 90,
        "Bamboo Catfish": 50,
        "Mossback Arapaima": 60,
        "Murk Stingray": 65,
        "Channel Sawfish": 70,
        "Boned Sturgeon": 75,
        Oarfish: 90,
        Snakehead: 160,
        "Eldertide Leviathan": 250,
        Pithead: 50,
        "Electric Eel": 60,
        "Shadow Darter": 60,
        "Abyss Carp": 65,
        "Nomai Moray": 75,
        "Silver Dragonfish": 80,
        "Giant Moray": 100,
        Coelacanth: 250,
        "Frost Herring": 60,
        "Permafrost Halibut": 70,
        "Glacial Lanternfish": 80,
        "Frozen Grenadier": 85,
        "Blackfin Icefish": 100,
        Moonfish: 120,
        "Alpha Moon Strongfish": 140,
        "Deepwater Lanternfish": 300,
        "Pearlescent Moonfish": 300,
        "Game Dev Fish": 50
      };
    const VK = {
        foraging: "Iron Axe",
        combat: "Iron Sword",
        mining: "Iron Pickaxe",
        farming: "Iron Hoe",
        fishing: "Rusty Rod",
        exploration: "Compass"
      },
      LK = {
        foraging: [80, 220, 100],
        combat: [240, 70, 70],
        mining: [60, 220, 240],
        farming: [245, 220, 60],
        fishing: [70, 120, 245],
        exploration: [255, 180, 70]
      };

    function QK(OO) {
      return `rgb(${LK[OO].join(", ")})`
    }

    function zp(OO, KO, pO) {
      if (!pO) return OO(KO);
      const XO = {};
      for (const [bK, eO] of Object.entries(pO)) XO[bK] = "string" === typeof eO ? eO : OO(eO.translationKey);
      return OO(KO, XO)
    }
    class AK {
      constructor(OO, KO) {
        this.now = OO, this.getJournal = KO, this.pending = [], this.current = null, this.followUp = null, this.shownAt = 0, this.expiresAt = 0, this.token = 0, this.JK = !1, this.onShown = () => {}
      }
      enqueue(OO) {
        const KO = fK(OO);
        if (KO) this.pending.push(OO);
        else {
          const KO = this.pending.findIndex(fK);
          this.pending.splice(-1 === KO ? this.pending.length : KO, 0, OO)
        }
        return (null === this.current || null !== this.followUp && !KO) && (this.advance(), !0)
      }
      setHeld(OO) {
        return this.JK = OO, !OO && null === this.current && this.pending.length > 0 && (this.advance(), !0)
      }
      KK() {
        const OO = this.getJournal(),
          KO = this.followUp;
        if (null !== this.current && this.now() >= this.expiresAt) return this.showFollowUp(null === KO ? this.findFollowUp(this.current) : null), !0;
        if ("explore" === (null === KO || void 0 === KO ? void 0 : KO.kind) && OO && OO.active.length > 0) return this.showFollowUp(this.findFollowUp(this.current)), !0;
        if ("step" === (null === KO || void 0 === KO ? void 0 : KO.kind)) {
          const OO = this.findFollowUp(this.current);
          if ("step" !== (null === OO || void 0 === OO ? void 0 : OO.kind) || OO.questId !== KO.questId || OO.step.id !== KO.step.id) return this.showFollowUp(OO, this.expiresAt), !0
        }
        return !1
      }
      clear() {
        this.pending = [], this.current = null, this.followUp = null, this.expiresAt = 0
      }
      getView(OO, KO, pO) {
        var XO, bK, eO, lO;
        if (null === this.current) return null;
        if ("skillLevel" === this.current.questCompletionKind) return this.getSkillLevelView(this.current, OO, pO);
        if ("landmark" === this.current.questCompletionKind) return this.getLandmarkView(this.current, OO);
        if ("npcNote" === this.current.questCompletionKind) return this.getNpcNoteView(this.current, OO, KO);
        const {
          questCompletionKind: vK,
          questCompletionNameKey: CO
        } = this.current, hO = "step" === this.current.questCompletionKind ? this.current.questCompletionNameParams : void 0, DO = "quest" === this.current.questCompletionKind ? this.current.questCompletionCoins : 0, MO = "step" === (null === (XO = this.followUp) || void 0 === XO ? void 0 : XO.kind) ? this.followUp : null, aK = "explore" === (null === (bK = this.followUp) || void 0 === bK ? void 0 : bK.kind);
        let oO;
        return oO = aK ? OO("skyblockGame:questExploreTitle") : null !== MO ? "quest" === vK ? OO("skyblockGame:questNextQuestTitle", {
          quest: OO(MO.questNameKey)
        }) : OO("skyblockGame:questNextStepTitle") : OO("started" === vK ? "skyblockGame:questStartedTitle" : "quest" === vK ? "skyblockGame:questCompletedTitle" : "skyblockGame:subquestCompletedTitle"), {
          token: this.token,
          kind: null === this.followUp ? vK : "step",
          phase: null === this.followUp ? "completion" : "next",
          title: oO,
          name: aK ? KO("skyblockGame:questExploreName") : null !== MO ? zp(KO, MO.step.nameKey, MO.step.nameParams) : zp(KO, CO, hO),
          description: aK ? KO("skyblockGame:questExploreDescription") : null === MO ? null : zp(KO, MO.step.descriptionKey, MO.step.descriptionParams),
          reward: null === this.followUp && DO > 0 ? KO("skyblockGame:questCoinRewardSuffix", {
            amount: DO.toLocaleString(pO)
          }) : null,
          iconItem: null !== (eO = null === MO || void 0 === MO ? void 0 : MO.step.questIconItem) && void 0 !== eO ? eO : null,
          accent: null,
          durationMs: this.expiresAt - this.shownAt,
          waypointNameKey: null !== MO && (null === (lO = this.getJournal()) || void 0 === lO ? void 0 : lO.trackedQuestId) === MO.questId ? MO.step.nameKey : null
        }
      }
      getSkillLevelView(OO, KO, pO) {
        let {
          skill: XO,
          beforeLevel: bK,
          level: eO
        } = OO;
        const lO = XK(XO, bK),
          vK = XK(XO, eO);
        return {
          token: this.token,
          kind: "skillLevel",
          phase: "completion",
          title: KO(`skyblockGame:${XO}`),
          name: KO("skyblockGame:skillLevelUp", {
            to: eO.toLocaleString(pO)
          }),
          description: lO.percent === vK.percent ? null : KO(`${vK.translationKey}Change`, {
            before: lO.percent.toLocaleString(pO),
            after: vK.percent.toLocaleString(pO)
          }),
          reward: null,
          iconItem: VK[XO],
          accent: QK(XO),
          durationMs: this.expiresAt - this.shownAt,
          waypointNameKey: null
        }
      }
      getLandmarkView(OO, KO) {
        let {
          landmarkNameKey: pO
        } = OO;
        return {
          token: this.token,
          kind: "landmark",
          phase: "completion",
          title: KO("skyblockGame:landmarkDiscovered"),
          name: KO(pO),
          description: null,
          reward: null,
          iconItem: null,
          accent: null,
          durationMs: this.expiresAt - this.shownAt,
          waypointNameKey: null
        }
      }
      getNpcNoteView(OO, KO, pO) {
        let {
          titleKey: XO,
          textKey: bK,
          params: eO = {},
          nameKeys: lO = {},
          iconItem: vK = null
        } = OO;
        const CO = {
          ...eO
        };
        for (const [hO, DO] of Object.entries(lO)) CO[hO] = KO(DO);
        return {
          token: this.token,
          kind: "npcNote",
          phase: "completion",
          title: KO(XO),
          name: pO(bK, CO),
          description: null,
          reward: null,
          iconItem: vK,
          accent: null,
          durationMs: this.expiresAt - this.shownAt,
          waypointNameKey: null
        }
      }
      durationMs() {
        var OO;
        if (null !== this.followUp) return 5600;
        switch (null === (OO = this.current) || void 0 === OO ? void 0 : OO.questCompletionKind) {
          case "quest":
            return 4800;
          case "started":
            return 4e3;
          case "skillLevel":
            return 3e3;
          case "landmark":
            return 3500;
          case "npcNote":
            return 8e3;
          default:
            return 2400
        }
      }
      showFollowUp(OO, KO) {
        null === OO || this.JK ? this.advance() : (this.followUp = OO, this.token++, this.shownAt = this.now(), this.expiresAt = null !== KO && void 0 !== KO ? KO : this.shownAt + this.durationMs())
      }
      findFollowUp(OO) {
        var KO;
        const pO = this.getJournal();
        if (!pO || this.hasPendingQuestPopup() || fK(OO)) return null;
        const XO = "started" === OO.questCompletionKind ? pO.active.some((KO => KO.id === OO.questCompletionQuestId)) : "quest" === OO.questCompletionKind ? pO.completed.some((KO => KO.id === OO.questCompletionQuestId)) : [...pO.active, ...pO.completed].some((KO => KO.id === OO.questCompletionQuestId && KO.subquests.some((KO => KO.id === OO.questCompletionStepId && "completed" === KO.status))));
        if (!XO) return null;
        if ("quest" === OO.questCompletionKind && 0 === pO.active.length && !this.hasPendingQuestPopup()) return {
          kind: "explore"
        };
        const bK = pO.active.find((OO => OO.id === pO.trackedQuestId)),
          eO = null !== (KO = null === bK || void 0 === bK ? void 0 : bK.subquests.find((OO => "ready" === OO.status))) && void 0 !== KO ? KO : null === bK || void 0 === bK ? void 0 : bK.subquests.find((OO => "active" === OO.status));
        return eO ? {
          kind: "step",
          questId: bK.id,
          questNameKey: bK.nameKey,
          step: eO
        } : null
      }
      hasPendingQuestPopup() {
        return this.pending.some((OO => !fK(OO)))
      }
      advance() {
        var OO;
        this.current = this.JK ? null : null !== (OO = this.pending.shift()) && void 0 !== OO ? OO : null, this.followUp = null, null !== this.current && (this.token++, this.shownAt = this.now(), this.expiresAt = this.shownAt + this.durationMs(), this.onShown(this.current.questCompletionKind))
      }
    }

    function fK(OO) {
      return dK(OO.questCompletionKind)
    }

    function dK(OO) {
      return "skillLevel" === OO || "landmark" === OO || "npcNote" === OO
    }
    var TK = pO(36921);
    const NK = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAP0lEQVR4nGNgoAD8h2L8Cqz6T4IxLsVwyZwTb+CYAZ9imCI5Gx+cisEK73/7jYLRFcKtxqcIwzPE+BymgXwAABikVOyJwpyoAAAAAElFTkSuQmCC",
      IK = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAUUlEQVR4nGNgIAP8x4FRwH8w+OqOim+LYyiGSLzQR8G/DipgKgy2Vvqfc+INmEZm4zQRphCniTA3wRXeFseuECQIwlfbmMEYxsfqc2KChyAAANDbei83hMJpAAAAAElFTkSuQmCC",
      yp = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAVElEQVR4nGNgIAP8x4FRwH8QePfuFQq+dO44hmKwxOMHN1Hw4b3bMRW6unv/zznxBkwjs3GaCFOI00SYm2AKQWysCkGCILxm6TwwhvGx+pyY4CEIAG45h2BiJfmeAAAAAElFTkSuQmCC",
      gp = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAASElEQVR4nGNgIAP8x4FRwP9sF+X/XVEGKDjbRRlDMVjww44uFHyyKw5TIUjC2n4BXBGIjVMh0SaSpHBBkC0Y41IIVkxM8BAEAGLKe3rsiWx2AAAAAElFTkSuQmCC",
      uK = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAW0lEQVR4nGNgIAP8J0bs//M750GCKPg5Qgyh8OT2Vf870vxR8MntqzAVysnL/wcBmCIQAIlhVQjCMIUwPobCjAC7/+XZSSgYJIZVoZGWKlwRiI1NISwosGHSAAAPvV+9cOwRMQAAAABJRU5ErkJggg==",
      EK = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAT0lEQVR4nGNgIAP8h2JcfDD4X2lg/D9RRhQmCWbnq6piKAYrRMf52BSCTHAU54QrArGRbEA18ev3X3CFIDZOq2GmwkzDqxAdY/U5DkwaAACgalVtqFSm5wAAAABJRU5ErkJggg==",
      jp = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAf0lEQVR4nO3VsQkEIRCG0ek/MbwWbMXk4u1kOBi4bWANhA0U3oM/9zOZCAAAAAAm8lf/Nza+1+NiNym4BKfgEjxOCR6Th7ZPX9rsI2I3Q/AluAnugvOU4Fw8M6vnKnaTgkvwEFyC8/TgtniWZovdpOAS3AR3we2UYAAAAIDYxQ2IeNNWBgNQ/AAAAABJRU5ErkJggg==";
    const YK = pO.p + "static/media/quest_search.b4f00072d5f134fdf189ecb8a48edc99.svg";
    const wK = pO.p + "static/media/quest_talk.7d2326c7bdb6bc060cc0cde294f4fa89.svg",
      ip = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAANklEQVR4nGNgIBP8R8NYwX8QuH7nGRwzYFEMVwQzDcSetXgHdsXEKIIrJkYRusn4FVHdRJwAALfWRnO5uwepAAAAAElFTkSuQmCC";
    var rp = pO(17473),
      PK = pO(19647),
      mp = pO(22027),
      sK = pO(23532),
      HK = pO(25141);
    const RK = {
      ashen_fort: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAUElEQVR4nGNgIAP8R6PR2RCBzRu2/kemQbirvQ/GRlUIwyAFIJyUkIFbobyUHhjjVAiSgCmM1p9HWCFI0YKYD/gVgjDMapAibAphQYENkwYAeH1pEdiBhHAAAAAASUVORK5CYII=",
      auction: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAR0lEQVR4nGNgoAD8h2K84P+kApf/vw4qEFT8H6SoJsr8/5quIMKKg62VwIrxmfx/apEbWBKkCOQMbArhimB8YhThBUQpIggAQqYxE90Y9BMAAAAASUVORK5CYII=",
      bank: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAR0lEQVR4nGNgIBP8R8NYwX8w+OoOwbfFcSr+/+ugAhi/X8zz/0gVD1aFCNNui6Ow0RWDBWGmIbPJVwhzFwgjs7G6EwcmDQAAuONyKxIgH/AAAAAASUVORK5CYII=",
      carrot: rp,
      castle: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAVUlEQVR4nGNgoAD8R8I4wf+pRW7/n2nrgzEDDsX/YQrxmfr/yIHdYAkQDWNP6uvDUAxXAMIgBSCcm5mJqRAkAVIUbK0ExgQV1kSZgzEuhXDPYMGkAQC0sV3YpEV43gAAAABJRU5ErkJggg==",
      cinderfall: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAATUlEQVR4nGNgoAD8h2K84P//N/5gjE/x/78dLHCFIDYuxWDJxqys/362tjgVwhXBFOJS/P+yCROKImNNbbAYhkJ000AKQRir9TgwaQAA9pxTDDdv+r4AAAAASUVORK5CYII=",
      combat_1: PK,
      cow: uK,
      craft: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAPklEQVR4nGNgIAH8JxIz/L+2JA2Mp6VZYGUzwBSCBPFhBphCYq0GKy7w0kARwCGGIgjHhBTiNxHdLTjECAMAZEReU1MzQpcAAAAASUVORK5CYII=",
      dungeons: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAQUlEQVR4nGNgIBP8R8NYwf++KbPhOKewHKtiuAJ5KT0wBinEphis6L+1AVwhiA0Sw6oQpgiGKVdIjBvBinFg0gAAOOVdfOFyr7kAAAAASUVORK5CYII=",
      emberwatch: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAATElEQVR4nGNgoAD8h2L8Cv6/8f//t4PlPy4N/48c2A2WACm6bMIEZk/q68NQDFYIwyAFIJybmYnbVJCJ+BTBFRIyjSSFcJ8TE0Q4AQDqiVfWwMcDkgAAAABJRU5ErkJggg==",
      enemy: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAU0lEQVR4nGNgIBP8R8NYwf///W3/n3r4wjEDFsUYikB4s4o2hmKwhDY3L1wRiI1ToQgLK1whiI1TIQjnCYqBMUgRNoVgxSAJmCIQjdfnxAQPXgAAraZYPXKBMfkAAAAASUVORK5CYII=",
      farm: pO(25158),
      farming_1: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAR0lEQVR4nGNgoAD8h2K84P+nbP//87SU8Cr+D1J0w1H///9LXjgV/4cpQsbYFIMlPjw+hILxKqyJMv8fbK1EuUKwYhyYNAAAbaVgzAUMTa8AAAAASUVORK5CYII=",
      fishing: NK,
      fishing_1: NK,
      forest: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAASElEQVR4nGNgIBP8R8NYwf+c/TZgbN+jA8YMWBRjKAJhg3JlDMUoikAKQFgxWgi7qcQogiuuiTL/H2ythFcRSQrBiolRhBMAAJ9tQRoOB1rEAAAAAElFTkSuQmCC",
      guardian_gold: IK,
      guardian_iron: yp,
      hub: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAWElEQVR4nGNgoAL4T5SirGUf/uNTDJa0r78GxjpRK7Aq/v8p2x8s8eHxIThGVwhWdMNR//88LSWwgv+XvLArhJlwcnMXfhNBgjVR5nCFIDY2hXCPYMGkAQDGNGSEX91FFwAAAABJRU5ErkJggg==",
      island: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAUElEQVR4nGNgoAD8h2K84L//OlcwxqcYrECvyQKOGXAohkn870pxgLMxFC17FgfGOfut4Ni7Xwe74u60ADDO8rIC03jdCVIEwkT5nBhFOAEAI1k9HXZqyYAAAAAASUVORK5CYII=",
      melon: mp,
      mines: sK,
      mining_1: sK,
      npc: gp,
      npc_beaver_lumberjack: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAASUlEQVR4nGNgIAP8h2JcfDD4XxQVCMYwBSB2nJsbhmKwhJKyMlwDiI1TYUVyMFgBCIPYeBX+/3zt/6vbJ6moEBljUwhWjAOTBgAZSmJ9XCb2zAAAAABJRU5ErkJggg==",
      npc_chef: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAW0lEQVR4nGNgIBP8R8NYwf+v33/B8f1nH7AqRlEEU3gfi+L/RVGB/y/feQlXAGKDxLAqlJDX//9pfycYg9g4FYIUxLm5gfHJvgz8Cl9vaQFjkEIQxuohHJg0AACncHuimGgHPgAAAABJRU5ErkJggg==",
      npc_cow: uK,
      npc_draugr_warper: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAb0lEQVR4nGNgIBIwIrH/41PDCFPU+/IzVlXF4rxgdSwwgUV33oFpXh42MP35yy+sVv///x9is8GxR2D6gpUcRAEjxGYmZF2nvv/BygYBuNUwk0BASoKHIe38M+wKQZLIAMa/iOZGsDuxehtVDWEAAHwCHXf9ctZjAAAAAElFTkSuQmCC",
      npc_dwarf_blue_hair: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAUElEQVR4nGNgIBP8R8NYwf//51lRMAMWxf/TM0r+/z/AjoLTM0owFENMeSCBirGY+l+r/SpY8OGmBjBGFkNR6DD9FVwRDIPEyFYIVowDkwYAEBZzAwnUgyIAAAAASUVORK5CYII=",
      npc_dwarf_braided_hair: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAASElEQVR4nGNgIBP8R8NYwX9deRUUzIBFMYYiXIr/h5rqYMUYCr9+/wUWjLE2AGNkMRSF6Q6mcEUwDBLDUIiuCNlkDA/hwKQBAPnYUUW1+JaKAAAAAElFTkSuQmCC",
      npc_dwarf_child: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAATklEQVR4nGNgIBP8R8NYwX8lZeX/6hoaYAxiY1P8f1trHlbMgKb4/5qGDKwYQ+HX77/+q0jKwxWA2CAxDIVEW32gqwRDEUgMq4dwYNIAAP19arcJQ+nsAAAAAElFTkSuQmCC",
      npc_dwarf_forked_beard: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAUElEQVR4nGNgIBP8R8NYwX91DQ0UzIBFMVhick4EXBGMja74f1tKAFaMofDr91//VSTlwSaBMIgNEsOqEN2NWBWCTFFSVkbBIDGsHsKBSQMAnGRas5Ev2yIAAAAASUVORK5CYII=",
      npc_dwarf_ginger_beard: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAYElEQVR4nGNgIBP8R8NYwf//B9hRMAMWxf//n2f9//+BBCo+z4qh+P/dFd0YGKvCr99//WfQ8/z/dNMUMAaxwWLoCt/umPn/ZaMLCgaJYSgEmfK4wgEFg03G5iEcmDQAAGl2d4woNRHRAAAAAElFTkSuQmCC",
      npc_dwarf_grey_beard: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAQklEQVR4nGNgIBP8R8NYwX8vUxsUzIBFMYYiXIr/O+mbYcUYCr9+//VfRVIebhKIDRLDUJiSkoIVk60QrBgHJg0AAIrsWQuZyZ2qAAAAAElFTkSuQmCC",
      npc_dwarf_hair_buns: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAVklEQVR4nGNgIBP8R8NYwX8tRXkUzIBF8X81OZn/ilKSYBqZzYCmGCw4JTsarhDGxlD49fsvsOC8omQwRhZDUbisLBOuCIZBYhgK0RUhm4zhIRyYNAAAK2NaB/Me8/sAAAAASUVORK5CYII=",
      npc_dwarf_purple_beard: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAR0lEQVR4nGNgIBP8R8NYwX8bw8D/LqYRYAxiY1P8/+TEQqyYAU3x/z2tWVgxhsKv33+BBZFNgomhKIS5DR2TrRCsGAcmDQAAxtNi2UvD/ZAAAAAASUVORK5CYII=",
      npc_dwarf_red_hair: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAXUlEQVR4nGNgIBP8R8NYwf//DyT+/3cqhOAHElgV/y8urv///zwrCi4ursdQDJEEmYiMz7NiKpxiZvXfUEnr/7npBWAMYoPEsCqEKQLhDdUR/5uNTchXCFaMA5MGAHoVbT+3iic1AAAAAElFTkSuQmCC",
      npc_dwarf_short_beard: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAATklEQVR4nGNgIBP8R8NYwX91DQ0UzIBF8f9trXlYMQOa4v9rGjKwYgyFX7//AgsimwQTQ1F4oKsEw40gMQyFIFOUlJVRMDY3ghXjwKQBAAoPYHs6ybo9AAAAAElFTkSuQmCC",
      npc_farmer_gill: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAWUlEQVR4nGNgIBP8R8NYwf+bW0v+b53gD8cMOBT/X2cfgYIZsChEMQmfqf/PXrr1X0Je///rLS1gDGKDxLAq/LS/E67wZF/G/2XrdmFXCFOETyFYMQ5MGgAAx9NujhmsqqEAAAAASUVORK5CYII=",
      npc_fire_mage: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAUElEQVR4nGNgIBP8R8NYwf8jtqZwvNJMH6tiFEX4FP//v5EDK8ZQ+PX7r/8WQuz/1+YFgjGIDRLDULi9LAKuCIZBYhgKJ+nJYcVYPYQDkwYAY/ZlGR1JAIkAAAAASUVORK5CYII=",
      npc_forge_mother: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAXklEQVR4nGNgIAP8x4FRwP+vzy+AJSKd7MEYWQxF4avbJ8EYphDGx1D49fsvTBOhYigKfS0s/l9dPAsFg8SwKpyYkAVXBGLjVPj/POv//x+0Ifg8K1aFYMXEBA9BAACWKnGnkFHGrQAAAABJRU5ErkJggg==",
      npc_goblin_goggles: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAgklEQVR4nGNkQAX/0fiMGAyQIhMPGxRVZ3YcgathwqUIBKBi/2Gq//tMzWDw4HBkwAZ2/NjPsCV7Btzq/1+//2LQ1dFkSMgoBQssmNHNcPnKdQZuTjawgXCFTd0zsJpYV5oBVsgCEzj+7wRWhTAA8wwcPNt2A4zRAUrw4DAMWQ1hAADlHCXxWLGl2AAAAABJRU5ErkJggg==",
      npc_goblin_mad_scientist: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAV0lEQVR4nGNgIBP8R8NYwX/PzoT/qpZGYAxiY1P8//8DCayYAU3x/7OXboEFkRXAxFAUfv3+67+SsvL//+dZwRjEBolhKIQpQMcYCkGOx4axeggHJg0AAFKzbFf/ov6kAAAAAElFTkSuQmCC",
      npc_gold_guardian: IK,
      npc_gold_watermelon_stag: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAWElEQVR4nGNgIAP8R6KR2Sjg/5sH4f9hNDKbAZ9ifIoYQIKfV6nAFSKxURVt8jH7f1+R9//ZVH8wBrFBYuiKwZIgiS27w8AYxAaJ4TQVWSEuN4IVo2HSAQCFHFiN1+WGFAAAAABJRU5ErkJggg==",
      npc_head_8_0: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAdElEQVR4nGNgIBIwIrH/41PDCFO06sIzMMNbQ5Jh643ncFVhBlJgdXCFSnJqDBJiMgwvXj1BMe7eo1tghSzIgrPqMlAU+eXUwNlMyBINs7gYZJTkwBjERgYoCud0iGBlYygEgStrdoAxVq/DPIQhi6mGMAAAMzccpadovTMAAAAASUVORK5CYII=",
      npc_human_archer: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAc0lEQVR4nGNkQID/DNgBI5wAKTqwtAOrKofoCrA6FmTBvinLUBQV5UTB2SgKf//5i8N2BoTVX7//YuC2VmfwZOYCC2z/+43h69GbDNycbGB1cIWHXBywmmS35wBYIRNOu9AA3I1ffnzFqxBmNdh6ItQQBgAsaRzpv2C9aQAAAABJRU5ErkJggg==",
      npc_human_desert_guard: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAfklEQVR4nGNkQID/DNgBI5wAKfpxdztWVRzKnmB1LDCBdReZGUSEhVAUvXn7Ds6GKwSB23MnoigUDIiFs5lgDH9PB4Zll+7DJUBskBiKQ0FunBoXy/D9xw8UEzk5OBiyFy1GdSPHpTMM+rw8KApvfv6CaTUhALMabD0RaggDACCpH2oXfV//AAAAAElFTkSuQmCC",
      npc_human_sentry: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAYUlEQVR4nGNgIBIwIrH/41PDCFOkqamJVdX169fB6liQBXNMTVAUTTl9BkPj/6/ff4Gs/j81LhaMkcVQrO4JC2Xg5OBA0f39xw+GklWrUa2edvYcTh+DABNeWSRAdPAQDQAzViKkGPwLjwAAAABJRU5ErkJggg==",
      npc_iron_guardian: yp,
      npc_jackal_priest: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAdklEQVR4nGNgQID/UIyVzwQT1NTUZBAWFoYrALFBYjDFjDCF/zdyMGADjP4/wBQLTODVVXkGh8UwCyDgQOw/BgaGmyhWg8GZcxexsjEUmhjpM3z79g2MQWxkALcaBP79/cvAwc4OZyO8gGYiPoDQghqGuNQQBgAoCCX1U3QMRQAAAABJRU5ErkJggg==",
      npc_minotaur: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAaklEQVR4nGNgIAP8R6KR2Sjg/9fnF8AKMgJ8wBhZDEXhq9snwRimEMbHUPj1+6//DBYBCBMtAiBi6ApBkhMTsv5fXTwLjEHsODc37Ar/n2eFKwSxcSp8sGHO//8ftMEYxMamEKwYByYNAABmXHNFjN9ucgAAAABJRU5ErkJggg==",
      npc_minotaur_elder: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAg0lEQVR4nGNgIBIwIrH/41PDBFP09fkFMKMuJxWMQQAq9h9ZIcPXLz8ZXt0+CTcGxAaJwQBcIbeMIYOYqjlcAsQGiaG78X9ZajxDvJ01iuMWHjrK0DV7IVgd3EQQ2LMX4k50NgiwIHPy8mczMCiqgdlaOrcYyqdFYVgN9x0WgKyGMAAArq0oYNR0jFIAAAAASUVORK5CYII=",
      npc_minotaur_warrior: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAjUlEQVR4nGNkQAX/0fiMGAyQooWVjiiq4tv3o6th+P/q9sn//z9oo+BXt0/+h9nCgmLE/VuoFvMgmHCF3DKGDIycvxmq3XzA/G137jHwcediKuwLDme4ungWXCKKgYFh3fLtDAcvQ/hMyDbt2XsBKxtF4Y8/vxn8A4wYuHmZwBjEBolhDR5Un2BVQxgAAJW+Nj/Gsfy4AAAAAElFTkSuQmCC",
      npc_monster_hunter_lorenzo: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAVElEQVR4nGNgIAP8x4FRwH9NLa3/ru5eYBoZM6AphkvsrU0BY5wKv37/9d/awAauEMQGiWEoPNmaDVcEw7PigjAVIlsHw3gVIrsRm0KwYmKChyAAAIfVZAdaM2LxAAAAAElFTkSuQmCC",
      npc_npc_pig_head: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAXklEQVR4nGNgIAP8h2JcfDD4/3Lyjv9fe3bCJMHsl5N3YCj+/3/HfQjecAWOX2JVuOHKfwZ1U7giEBunQpB1yBinwkJta7giEBurwrOXbv3/+v0XCgaJYfU5DkwaAADzDIUDTIstKgAAAABJRU5ErkJggg==",
      npc_painter_spencer: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAgklEQVR42mNgIBIwovH/45JHVvj/XZc7w+/vfxme3GViYGBgYDBetAuuBqbw/+MKB6xWynYcYGBgYGCEK/z6/ReDsoYpg5OsMAMDAwPDvsdvGe7eOM3AzcmGqjDFyZPh26+fKKZ9+/mDYcPpYwwMDAyMTMT6Gq4Q3TR8wfOfyCDEDwAFFSX0ZxYXtAAAAABJRU5ErkJggg==",
      npc_pig: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAARklEQVR4nGNgIAP8x4FRwP/3x87A8ds9R+CYAU0xiiQMP1y0FlOhu7YJhkKQGFYTQSYgY5xWg0yAKYKxyXYjWDExwUMQAABoKIoUBfmEPAAAAABJRU5ErkJggg==",
      npc_pig_napoleon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAYElEQVR4nGNgoAD8h2K84L++ofF/V3dvvIr/gxRtszH9//X7LzCbAYvi///Ps/6Xk5dHwSAxdMX//2+48p9B3RRMw9gvJ+/ArvBrz04UjFNhobY1XBGIjU0hWDEOTBoAAIrnYG/Xae9eAAAAAElFTkSuQmCC",
      npc_pig_worker: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAYElEQVR4nGNgIAP8R8NYwf/YhDQ4dnb1xKnhP0gSHesbGmMo/v9/w5X/DOqmYBrGfjl5B3aFhdrW/7/27ARjEBunQpAEOsZQGGLn+L8oKvD/1++/wBjEBolh9RAOTBoAAGcEbivle0KRAAAAAElFTkSuQmCC",
      npc_piggy_banker: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAXElEQVR4nGNgIBP8R8NYwX9Xd+//2jq6cMyAQ/F/OXn5//8fSPz/f54VzGbAohAsgQ2jK/7/f8OV/wzqpmAaxn45eQd2hV97dqJgnAoLta3hikBsbArBinFg0gAAgophxWZsQvAAAAAASUVORK5CYII=",
      npc_portal_mage: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAYUlEQVR4nGNgIBP8R8NYwX+GDVNRMQOm4v8MC9qxYwZUxf//b+T4//8A+///51khGMTeyIGp8Nz0gv8MDoFgGsbeUB2BXeHESHcUjFNhR4Dj/zp3OzAGsbEphHgIOyYNAACzzGY5JF2GbAAAAABJRU5ErkJggg==",
      npc_rabbit_aristocrat: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAXklEQVR4nGNgIAP8h2JcfDD4P3fB+v/3csphkmB2S/tUDMX/+yYuIE7h3AXrwYqRMU4TlZSV4YpAbJwKYe4EYRC7prYLU6GLocX/ODe3/1+//wJjEBskhtXnODBpAAD3lm2BX81XrwAAAABJRU5ErkJggg==",
      npc_smuglyn: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAASklEQVR42mNgIAP8x4FRFWlqamLF6IrBgj1hoSgYq8Kv33/9txBi/z81LhaMQWyQGIbC5VmZcEUwDBLDUIiuCIRB1pOtkOjgIQgAhutlSTAZTWcAAAAASUVORK5CYII=",
      npc_tentacle_boy: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAiElEQVR4nGNkQID/DNgBI5wAKXJw8Wb48vkjhqozJ4+A1bHABKI0arEad+akBdzY/ybmNgw/f/3CqpCdjQ1sKthEM4scHM5DsZ7hf23T3v9fv//6z8srAmaj80FqmGC6JMSkUExB54Ot1ubgYSgoXQkWuHXrKpiG8UFyMAA3HkbjEIMoRqMxxABOskezGUlSqQAAAABJRU5ErkJggg==",
      npc_tentacle_girl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAgklEQVR4nGNgwA3+QzEYMOGQ/H9viS7Dp4N+MDEGFmRFO8PqGYTFRBjevnrDwMCwjuHN4/twSRZsikD07U1BUKnLKArBQExYAIxh7OvX78DlUNzoMbEWKxtDYb11MFY2htXPPr5nOH7mApiW4hdECxAkX/fbJIGDYqV3MYwND0eiAQAf4TQGGrZ+tQAAAABJRU5ErkJggg==",
      npc_tentacle_guy: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAYElEQVR4nGNgIBIwovH/45JnRFaUGN+Comr+whq4GiZ0RVycnGAMAlAxsC0sMN2fvn9DodEBzEQGdUV5hvNnV4JpGJuPkwtTIQh4umZhZWMonDqjGCsbHcCCBkQjs0kDAPeaHpfX1eroAAAAAElFTkSuQmCC",
      npc_tentacle_guy_fisherman: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAVElEQVR4nGNgIBP8R8NYwX9XD7//JuY2cMyARTFcUtfQDIxxKf4fHFaFgRPjWzAVVpXP/K+krAymYWycCrMzeuEKQWycCmE0jI1NIVgxEo3MJg0AAIJsWIj/ilEbAAAAAElFTkSuQmCC",
      npc_wolf_in_suit: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAVUlEQVR4nGNgIAP8h2JcfDD47+0X/N/a1gEmCWY7u3piKAYrRMfOuBQqKSvDFYHYOBV+/f4LbCUIg9g4FYIUgEwCYbxu/P/5GtxEEBubQrBiHJg0AAB07Vx5G7sqWQAAAABJRU5ErkJggg==",
      npc_wolf_security: EK,
      player: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAQElEQVR4nGNgoAD8h2K84D8M4FP8/9HLz3CFIDYuxUQpBEugK8SmGCy4cttpmASYjVUhkiJ8YhAJbO7GGT64AACb2mXTEt92cwAAAABJRU5ErkJggg==",
      portal: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAU0lEQVR4nGNgIAP8x4FRwP9YmzYwtlOJAWMYG10xWOL7zz9wfPLcDdwKQZL901eAMUixrowDpkKQbphJMFPxKoSZCMI4FYIkQBiZjdXnxAQPQQAAOtFywhRvXJwAAAAASUVORK5CYII=",
      portal_orange: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAVUlEQVR4nGNgIAP8x4FRwP9YmzYwtlOJAWMYG10xWOLzJAs4/tSkglshSPJjldT/D4UCYMW6Mg6YCkG6YSbBTMWrEGQiDONUCJIAYWQ2Vp8TEzwEAQAA6GVEbqZ9DwAAAABJRU5ErkJggg==",
      quest: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAMElEQVR4nGNgoAD8h2K84P//Xwf+/35tSFDxf+or/P3a8P/nVSrEuZMoRVQ3EScAAIINMAfVJxmxAAAAAElFTkSuQmCC",
      quest_search: YK,
      quest_talk: wK,
      scorched_flats: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAUUlEQVR4nGNgIBP8R8NYwf8HT+6jYAYsisES/vIicEUg9t4TuzAUY5gGUoRNIVwxSBJGY1W0wF0LjKuMFcAYxsewGiYJchtMAzaFYMU4MGkAADMzb36mUd86AAAAAElFTkSuQmCC",
      scorp_pit: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAASElEQVR4nGNgoAD8R8I4wf//l6rA+MUCG5yK/z/T1kc27T8uxeiCWBXCrUQ2cUOCHHYTQRIgU2BuxKYQxUSYApwmIgmi08QDAPP+Ttl2n8EbAAAAAElFTkSuQmCC",
      shooting_gallery: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAASElEQVR4nGNgIBP8x4IxwP9n2vpw/P+SFxijK4ZIIoGaKHP8CkE0WNH///83q2jjVwhj41WIDLAphCsGScIwLl+DFRMKGoIAAPFdcuGHeG5wAAAAAElFTkSuQmCC",
      smelt: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAP0lEQVR4nGNgIBH8J4DB4P+8efPwYgaoYjCnoKAAK56HTSG6lXgV/n5t+P9zhQphhSBFeBUS4xmwYmKChygAADFjjqm4UTd5AAAAAElFTkSuQmCC",
      talk: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAANElEQVR4nGNgIBH8x4Ph4D8+wICkGC6Ai2Yg2cRdx67hxBjuhGnA5xkUk3FJYphKSBFBAACXuoGa4rCq3AAAAABJRU5ErkJggg==",
      tower_of_doom: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAPUlEQVR4nGNgIAP8J0bsf1VBG0gQBduaucHYmAr/X/L6/9/aAKdCBpjiqKAkMMaliPoKwYrQFeJUjAOTBgBhWEzjnMiaVwAAAABJRU5ErkJggg==",
      unknown: ip,
      watermelon: HK
    };

    function SK(OO, KO) {
      const pO = document.createElement("img");
      return pO.className = KO, pO.src = OO, pO.alt = "", pO.draggable = !1, pO
    }

    function JK(OO) {
      var KO;
      const pO = null !== (KO = RK[OO]) && void 0 !== KO ? KO : OO.startsWith("npc_") ? gp : ip;
      if ("portal" !== OO) return SK(pO, "SkyblockMapIcon");
      const XO = document.createElement("span");
      XO.className = "SkyblockMapIcon Portal";
      const bK = document.createElement("span");
      return bK.className = "SkyblockMapIconTint", bK.style.maskImage = bK.style.webkitMaskImage = `url("${jp}")`, XO.append(SK(pO, "SkyblockMapIconLayer"), bK, SK(jp, "SkyblockMapIconLayer SkyblockMapIconShade")), XO
    }
    var cp = pO(36902),
      BK = pO(3525);
    const ZK = [{
      lobes: [3, 4],
      amount: [.04, .055]
    }, {
      lobes: [5, 6, 7],
      amount: [.025, .035]
    }];

    function GK(OO) {
      const KO = new BK.e(OO);
      return {
        radius: 45,
        squareness: 3,
        wobbles: ZK.map((OO => {
          let {
            lobes: pO,
            amount: XO
          } = OO;
          return {
            lobes: pO[Math.floor(KO.next() * pO.length)],
            amount: XO[0] + KO.next() * (XO[1] - XO[0]),
            phase: 2 * KO.next() * Math.PI
          }
        })),
        samples: 160
      }
    }

    function qp(OO) {
      let {
        radius: KO,
        squareness: pO,
        wobbles: XO,
        samples: bK
      } = OO;
      const eO = [];
      for (let lO = 0; lO < bK; lO++) {
        const OO = 2 * Math.PI * lO / bK,
          vK = Math.cos(OO),
          CO = Math.sin(OO),
          hO = KO * (Math.abs(vK) ** pO + Math.abs(CO) ** pO) ** (-1 / pO) * XO.reduce(((KO, pO) => {
            let {
              lobes: XO,
              amount: bK,
              phase: eO
            } = pO;
            return KO + bK * Math.sin(XO * OO + eO)
          }), 1);
        eO.push(`${(50+hO*vK).toFixed(2)} ${(50+hO*CO).toFixed(2)}`)
      }
      return `M${eO.join("L")}Z`
    }
    const xp = ".InGameHeaderContainer, .TopRightElementsLeft > *, .TopRightElementsRight > *, .MiddleTextTopContainer";
    class nK {
      constructor() {
        this.compassSpacing = 1, this.compassSize = {
          trackHalfWidth: 0,
          screenHalfWidth: 0
        }, this.compass = null, this.terrain = null, this.searchAreaPath = {
          seed: "",
          d: ""
        }, this.searchAreas = {
          minimap: null,
          map: null
        }, this.player = null, this.waypoint = null, this.markerIcon = null, this.waypointMarkerSize = {
          width: 0,
          height: 0
        }, this.waypointInset = {
          x: 8,
          top: 8,
          bottom: 8
        }, this.viewport = {
          width: 0,
          height: 0
        }, this.stopLayout = null, this.stopWaypoint = null, this.stopWaypointOrigin = null, this.waypointOriginToken = null, this.waypointLaunch = null, this.markers = new Map, this.cardinals = [], this.frame = null, this.YX = !1, this.mountCompass = OO => {
          var KO;
          if (null === (KO = this.stopLayout) || void 0 === KO || KO.call(this), this.stopLayout = null, this.markers.clear(), this.cardinals = [], this.compass = null, !OO || this.YX) return;
          const pO = OO.querySelector(".SkyblockCompassTrack");
          this.compass = {
            root: OO,
            track: pO,
            label: OO.querySelector(".SkyblockCompassLabel")
          }, pO.replaceChildren();
          for (let bK = 0; bK < 4; bK++) {
            const OO = document.createElement("span");
            OO.className = "SkyblockCompassCardinal", pO.appendChild(OO), this.cardinals.push(OO)
          }
          const XO = (0, cp.d)(xp, [OO], this.layout);
          this.stopLayout = () => {
            XO(), pO.replaceChildren()
          }, this.render(this.frame)
        }, this.mountTerrain = OO => {
          this.terrain = this.YX ? null : OO, this.render(this.frame)
        }, this.mountMinimapSearchArea = OO => {
          this.mountSearchArea("minimap", OO)
        }, this.mountMapSearchArea = OO => {
          this.mountSearchArea("map", OO)
        }, this.mountPlayer = OO => {
          this.player = this.YX ? null : OO, this.render(this.frame)
        }, this.mountWaypoint = OO => {
          var KO, pO;
          if (null === (KO = this.stopWaypoint) || void 0 === KO || KO.call(this), this.stopWaypoint = null, this.waypoint = null, this.markerIcon = null, !OO || this.YX) return;
          const XO = OO.querySelector(".SkyblockQuestWaypointMarker");
          XO.replaceChildren(JK("quest")), this.markerIcon = "quest", this.waypoint = {
            root: OO,
            marker: XO,
            clip: OO.querySelector(".SkyblockQuestWaypointTextClip"),
            text: OO.querySelector(".SkyblockQuestWaypointText"),
            label: OO.querySelector(".SkyblockQuestWaypointLabel"),
            distance: OO.querySelector(".SkyblockQuestWaypointDistance"),
            hint: OO.querySelector(".SkyblockQuestWaypointHint")
          };
          const bK = () => {
              this.waypointMarkerSize = {
                width: XO.offsetWidth,
                height: XO.offsetHeight
              }, this.waypointInset = {
                x: XO.offsetWidth / 2 + 8,
                top: XO.offsetHeight + 8,
                bottom: 8
              }
            },
            eO = new ResizeObserver((() => {
              bK(), this.render(this.frame)
            }));
          eO.observe(XO, {
            box: "border-box"
          });
          const lO = () => {
            this.viewport = {
              width: window.innerWidth,
              height: window.innerHeight
            }
          };
          window.addEventListener("resize", lO), null === (pO = window.visualViewport) || void 0 === pO || pO.addEventListener("resize", lO), this.stopWaypoint = () => {
            var OO;
            eO.disconnect(), window.removeEventListener("resize", lO), null === (OO = window.visualViewport) || void 0 === OO || OO.removeEventListener("resize", lO)
          }, lO(), bK(), this.render(this.frame)
        }, this.mountWaypointOrigin = OO => {
          var KO;
          if (null === (KO = this.stopWaypointOrigin) || void 0 === KO || KO.call(this), this.stopWaypointOrigin = null, this.waypointLaunch = null, this.waypointOriginToken = OO && !this.YX ? Number(OO.dataset.notificationToken) : null, OO && !this.YX && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
            const KO = {
              nameKey: OO.dataset.waypointNameKey,
              x: 0,
              y: 0,
              startedAt: null
            };
            this.waypointLaunch = KO;
            const pO = () => {
                const pO = OO.getBoundingClientRect();
                KO.x = (pO.left + pO.width / 2) / window.innerWidth * 100, KO.y = (pO.top + pO.height / 2) / window.innerHeight * 100
              },
              XO = new ResizeObserver(pO);
            XO.observe(OO.parentElement), XO.observe(OO), window.addEventListener("resize", pO), this.stopWaypointOrigin = () => {
              XO.disconnect(), window.removeEventListener("resize", pO)
            }, pO()
          }
          this.render(this.frame)
        }, this.layout = () => {
          if (!this.compass) return;
          const OO = this.compass.root,
            KO = getComputedStyle(OO),
            pO = getComputedStyle(document.documentElement),
            XO = parseFloat(pO.fontSize),
            bK = parseFloat(KO.getPropertyValue("--compass-icon-size")) * XO,
            eO = "1" === KO.getPropertyValue("--compass-fit-top").trim(),
            lO = eO ? 1 : 8,
            vK = Array.from(document.querySelectorAll(xp), (OO => {
              var KO;
              return (null !== (KO = OO.querySelector(".MiddleTextTop")) && void 0 !== KO ? KO : OO).getBoundingClientRect()
            })).filter((OO => OO.width > 0 && OO.height > 0));
          let CO = (parseFloat(pO.getPropertyValue("--notchTop")) || 0) + lO,
            hO = "";
          if (eO) {
            const KO = window.innerWidth / 2,
              pO = OO.getBoundingClientRect().height,
              eO = [CO, ...vK.map((OO => Math.max(CO, OO.bottom + lO)))].sort(((OO, KO) => OO - KO));
            for (const OO of eO) {
              let eO = KO - 8;
              for (const XO of vK) XO.bottom + lO <= OO || XO.top >= OO + pO + lO || (eO = Math.min(eO, XO.right <= KO ? KO - XO.right - 8 : XO.left - KO - 8));
              const DO = 2 * eO - bK;
              if (DO >= 16 * XO) {
                hO = `${DO}px`, CO = OO;
                break
              }
            }
          }
          OO.style.maxWidth !== hO && (OO.style.maxWidth = hO);
          const DO = OO.getBoundingClientRect(),
            MO = this.compassSize.trackHalfWidth;
          if (DO.width > 0) {
            const OO = this.compass.track.getBoundingClientRect();
            this.compassSize = {
              trackHalfWidth: OO.width / 2,
              screenHalfWidth: window.innerWidth / 2
            }, this.compassSpacing = 4 * bK / OO.width
          }
          if (!hO)
            for (const aK of vK) aK.right > DO.left - 8 && aK.left < DO.right + 8 && (CO = Math.max(CO, aK.bottom + lO));
          OO.style.top = `${CO}px`, this.compassSize.trackHalfWidth !== MO && this.render(this.frame)
        }
      }
      mountSearchArea(OO, KO) {
        this.searchAreas[OO] = this.YX ? null : KO, this.render(this.frame)
      }
      render(OO) {
        if (this.YX) return;
        if (this.frame = OO, this.compass && (WK(this.compass.root, !OO), OO)) {
          const KO = this.compassSize.trackHalfWidth / 50;
          OO.compass.cardinals.forEach(((OO, pO) => {
            const XO = this.cardinals[pO];
            XO.textContent !== OO.name && (XO.textContent = OO.name), WK(XO, OO.hidden), XO.style.translate = OO.left * KO + "px"
          }));
          const pO = new Set;
          OO.compass.markers.forEach(((XO, bK) => {
            var eO;
            pO.add(XO.id);
            let lO = this.markers.get(XO.id);
            lO || (lO = document.createElement("span"), lO.className = "SkyblockCompassMarker", this.markers.set(XO.id, lO), this.compass.track.appendChild(lO)), lO.dataset.icon !== XO.icon && (lO.dataset.icon = XO.icon, lO.replaceChildren(JK(XO.icon))), lO.style.color = null !== (eO = XO.colour) && void 0 !== eO ? eO : "", lO.style.translate = XO.left * KO + "px", lO.style.zIndex = String(OO.compass.markers.length - bK), lO.title !== XO.name && (lO.title = XO.name)
          }));
          for (const [OO, XO] of this.markers) pO.has(OO) || (XO.remove(), this.markers.delete(OO));
          this.compass.label.textContent !== OO.compass.label && (this.compass.label.textContent = OO.compass.label)
        }
        this.terrain && (WK(this.terrain, !(null !== OO && void 0 !== OO && OO.minimap)), null !== OO && void 0 !== OO && OO.minimap && (this.terrain.style.transform = OO.minimap.transform, this.terrain.style.setProperty("--minimap-icon-rotation", OO.minimap.iconRotation)));
        const KO = null === OO || void 0 === OO ? void 0 : OO.searchArea;
        for (const pO of [this.searchAreas.minimap, this.searchAreas.map])
          if (pO && (WK(pO, !KO), KO)) {
            if (this.searchAreaPath.seed !== KO.shapeSeed && (this.searchAreaPath = {
                seed: KO.shapeSeed,
                d: qp(GK(KO.shapeSeed))
              }), pO.dataset.shapeSeed !== KO.shapeSeed) {
              pO.dataset.shapeSeed = KO.shapeSeed;
              for (const OO of pO.querySelectorAll("path")) OO.setAttribute("d", this.searchAreaPath.d)
            }
            pO.style.left = `${KO.left}%`, pO.style.top = `${KO.top}%`, pO.style.width = `${KO.width}%`, pO.style.height = `${KO.height}%`
          } if (this.player && (WK(this.player, !(null !== OO && void 0 !== OO && OO.player) || OO.player.hidden), null !== OO && void 0 !== OO && OO.player && (this.player.style.left = `${OO.player.left}%`, this.player.style.top = `${OO.player.top}%`, this.player.style.setProperty("--map-player-rotation", OO.player.rotation))), this.waypoint) {
          const {
            root: KO,
            marker: pO,
            clip: XO,
            text: bK,
            label: eO,
            distance: lO,
            hint: vK
          } = this.waypoint, CO = !(null !== OO && void 0 !== OO && OO.waypoint) || null !== OO.waypoint.popupToken && OO.waypoint.popupToken !== this.waypointOriginToken;
          WK(KO, CO);
          let hO = 1;
          const DO = this.waypointLaunch;
          if (!CO && DO && OO.waypoint.nameKey === DO.nameKey) {
            const OO = performance.now();
            DO.startedAt ??= OO, hO = Math.min(1, Math.max(0, (OO - DO.startedAt - 450) / 1e3)), pO.style.opacity = String(Math.min(1, (OO - DO.startedAt) / 150)), 1 === hO && (this.waypointLaunch = null)
          } else pO.style.opacity = "", DO && null !== DO.startedAt && (this.waypointLaunch = null);
          if (KO.classList.toggle("Launching", hO < 1), null !== OO && void 0 !== OO && OO.waypoint) {
            const KO = this.waypointInset,
              CO = "quest_talk" === OO.waypoint.markerIcon ? function(OO, KO, pO) {
                if (!OO.text || null === OO.blockHeight || 0 === OO.nearness) return OO;
                const XO = OO.blockHeight / 100 * pO.height,
                  bK = -OO.nearness * (tp * XO + KO.width / 2),
                  eO = OO.nearness * (kp * XO + KO.height / 2);
                return {
                  ...OO,
                  text: {
                    x: OO.text.x + bK / pO.width * 100,
                    y: OO.text.y + eO / pO.height * 100
                  }
                }
              }(OO.waypoint, this.waypointMarkerSize, this.viewport) : OO.waypoint,
              MO = (0, TK.c)(CO, KO, this.viewport),
              aK = hO * hO * (3 - 2 * hO),
              oO = hO < 1 ? DO.x + (MO.x - DO.x) * aK : MO.x,
              FO = hO < 1 ? DO.y + (MO.y - DO.y) * aK : MO.y;
            pO.style.translate = `${oO}vw ${FO}vh`, XO.style.clipPath = `inset(${KO.top}px ${KO.x}px ${KO.bottom}px)`, WK(bK, hO < 1 || !OO.waypoint.text), bK.style.opacity = String(1 - OO.waypoint.nearness), OO.waypoint.text && (bK.style.translate = `${OO.waypoint.text.x}vw ${OO.waypoint.text.y}vh`), eO.textContent !== OO.waypoint.name && (eO.textContent = OO.waypoint.name), this.markerIcon !== OO.waypoint.markerIcon && (this.markerIcon = OO.waypoint.markerIcon, pO.replaceChildren(JK(this.markerIcon))), lO.textContent !== OO.waypoint.distance && (lO.textContent = OO.waypoint.distance), WK(vK, null === OO.waypoint.hint), null !== OO.waypoint.hint && vK.textContent !== OO.waypoint.hint && (vK.textContent = OO.waypoint.hint)
          }
        }
      }
      dispose() {
        var OO, KO;
        this.mountWaypointOrigin(null), this.render(null), null === (OO = this.stopLayout) || void 0 === OO || OO.call(this), this.stopLayout = null, null === (KO = this.stopWaypoint) || void 0 === KO || KO.call(this), this.stopWaypoint = null, this.compass = null, this.terrain = null, this.searchAreas = {
          minimap: null,
          map: null
        }, this.player = null, this.waypoint = null, this.markers.clear(), this.cardinals = [], this.YX = !0
      }
    }

    function WK(OO, KO) {
      OO.hidden !== KO && (OO.hidden = KO)
    }
    const tp = .55,
      kp = .6;
    const UK = {
      talk: "quest_talk",
      search: "quest_search"
    };
    class Op {
      constructor(OO, KO, pO, XO) {
        this.map = OO, this.quests = KO, this.compass = pO, this.display = new nK, this.translate = void 0, this.locale = "en-GB", this.metresFormat = new Intl.NumberFormat(this.locale), this.YX = !1, this.snapshot = null, this.texts = new Map, this.translate = XO
      }
      setTranslator(OO, KO) {
        this.translate = OO, this.locale = KO, this.metresFormat = new Intl.NumberFormat(KO), this.texts.clear()
      }
      translateCached(OO, KO) {
        const pO = void 0 === KO ? OO : `${OO} ${KO}`;
        let XO = this.texts.get(pO);
        return void 0 === XO && (this.texts.size >= 500 && this.texts.clear(), XO = this.translate(OO, void 0 === KO ? void 0 : {
          distance: KO
        }), this.texts.set(pO, XO)), XO
      }
      getSnapshot() {
        return this.snapshot
      }
      afterRender(OO, KO, pO) {
        if (this.YX) return;
        if (!OO) return this.snapshot = null, void this.display.render(null);
        const XO = this.map.getSnapshot().map,
          CO = pO.cameraHeading,
          hO = {
            ...this.display.compassSize,
            tanHalfFovX: pO.tanHalfFovX,
            pitch: pO.cameraPitch
          },
          DO = [];
        if (XO)
          for (const bK of this.compass.frame(OO, CO, KO)) {
            const OO = FO(bK.offset, hO);
            null !== OO && DO.push({
              ...bK,
              left: OO
            })
          }
        const MO = function(OO, KO) {
            const pO = [],
              XO = OO => "quest" === OO.kind ? OO.distance - 1 : OO.distance,
              bK = [...OO].sort(((OO, KO) => XO(OO) - XO(KO) || OO.id.localeCompare(KO.id)));
            for (const eO of bK) {
              let OO = !1;
              if ("quest" !== eO.kind)
                for (const XO of pO)
                  if (Math.abs(XO.left - eO.left) < KO) {
                    OO = !0;
                    break
                  } OO || pO.push(eO)
            }
            return pO
          }(DO, this.display.compassSpacing),
          aK = function(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Math.PI / 36,
              pO = null;
            for (const XO of OO) Math.abs(XO.offset) <= KO && (!pO || XO.distance < pO.distance || XO.distance === pO.distance && Math.abs(XO.offset) < Math.abs(pO.offset)) && (pO = XO);
            return pO
          }(MO),
          oO = OO => {
            var KO;
            return null !== (KO = OO.displayName) && void 0 !== KO ? KO : this.translateCached(OO.nameKey)
          },
          VO = {
            compass: {
              markers: MO.map((OO => ({
                id: OO.id,
                icon: OO.icon,
                colour: OO.colour,
                name: oO(OO),
                left: OO.left
              }))),
              cardinals: lO.map((OO => {
                let {
                  name: KO,
                  bearing: pO
                } = OO;
                const XO = FO(bK.e.computeShortestRotation(CO, pO), hO);
                return {
                  name: KO,
                  left: null !== XO && void 0 !== XO ? XO : 0,
                  hidden: null === XO
                }
              })),
              label: aK ? `${oO(aK)} \xb7 ${this.translateCached("skyblockGame:waypointDistance",dO(aK.distance,this.locale))}` : ""
            },
            minimap: null,
            searchArea: null,
            player: null,
            waypoint: null
          };
        if (null !== XO && void 0 !== XO && XO.background) {
          const KO = OO[0] - XO.mapOrigin[0],
            pO = OO[2] - XO.mapOrigin[2],
            {
              rotation: bK,
              transform: lO
            } = function(OO, KO, pO, XO) {
              const [bK, lO] = vK(OO, KO, XO), CO = eO - pO;
              return {
                rotation: CO,
                transform: `rotate(${CO}rad) translate(-${bK}%, -${lO}%)`
              }
            }(KO, pO, CO, XO.background.bounds);
          VO.minimap = {
            transform: lO,
            iconRotation: -bK + "rad"
          };
          const [hO, DO] = vK(KO, pO, XO.background.bounds);
          VO.player = {
            left: hO,
            top: DO,
            hidden: hO < 0 || DO < 0 || hO > 100 || DO > 100,
            rotation: -bK + "rad"
          }
        }
        const {
          waypoint: LO
        } = this.quests.getSnapshot();
        if ("search" === (null === LO || void 0 === LO ? void 0 : LO.questMarkerIcon) && null !== XO && void 0 !== XO && XO.background) {
          const {
            bounds: OO
          } = XO.background, [KO, pO] = vK(LO.position[0] - XO.mapOrigin[0], LO.position[2] - XO.mapOrigin[2], OO);
          VO.searchArea = {
            left: KO,
            top: pO,
            width: 6400 / (OO.mapMaxX - OO.mapMinX),
            height: 6400 / (OO.mapMaxZ - OO.mapMinZ),
            shapeSeed: LO.nameKey
          }
        }
        const QO = this.quests.getNotificationSnapshot(),
          zK = "completion" === (null === QO || void 0 === QO ? void 0 : QO.phase) && !dK(QO.kind);
        if (LO && !zK) {
          const KO = Math.hypot(...LO.position.map(((KO, pO) => KO - OO[pO]))),
            XO = Math.round(KO),
            bK = "talk" === LO.questMarkerIcon ? Math.min(1, Math.max(0, (10 - KO) / 5)) : 0,
            eO = pO.projectWorldPosToViewport(LO.position),
            lO = eO && pO.projectWorldPosToViewport([LO.position[0], LO.position[1] - 1, LO.position[2]]);
          VO.waypoint = {
            ...pO.projectWorldPosToScreenPos(LO.position),
            text: eO,
            nearness: bK * bK * (3 - 2 * bK),
            blockHeight: eO && lO ? lO.y - eO.y : null,
            name: this.translateCached(LO.nameKey),
            nameKey: LO.nameKey,
            markerIcon: LO.questMarkerIcon ? UK[LO.questMarkerIcon] : "quest",
            popupToken: (null === QO || void 0 === QO ? void 0 : QO.waypointNameKey) === LO.nameKey ? QO.token : null,
            distance: this.translateCached("skyblockGame:waypointDistance", this.metresFormat.format(XO)),
            hint: "search" === LO.questMarkerIcon && Math.hypot(LO.position[0] - OO[0], LO.position[2] - OO[2]) <= 32 ? this.translateCached("skyblockGame:waypointSearchHint") : null
          }
        }
        this.snapshot = VO, this.display.render(VO)
      }
      dispose() {
        this.YX = !0, this.snapshot = null, this.display.dispose()
      }
    }
    const Kp = "skyblockSkillsView";
    class pp extends DO {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now,
          pO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : OO => OO,
          XO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "en-GB",
          bK = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : OO => OO;
        super(OO, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => {}, arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : () => {}), this.now = KO, this.translate = pO, this.locale = XO, this.itemName = bK, this.progress = null, this.selected = "foraging", this.pending = new Map, this.recent = null, this.nextLevelUpToken = 0, this.onLevelUp = () => {}, this.skillText = new Map, this.sourceText = new Map, this.snapshot = {
          enabled: !1,
          open: !1,
          skills: [],
          detail: null,
          overallLevel: null,
          hud: null
        }, this.select = OO => {
          this.selected = OO, this.emit()
        }
      }
      setTranslator(OO, KO, pO) {
        this.translate = OO, this.locale = KO, this.itemName = pO, this.skillText.clear(), this.sourceText.clear(), this.emit()
      }
      text(OO) {
        let KO = this.skillText.get(OO);
        return KO || (KO = {
          label: this.translate(`skyblockGame:${OO}`),
          description: this.translate(`skyblockGame:${OO}Description`)
        }, this.skillText.set(OO, KO)), KO
      }
      sources(OO) {
        if ("mining" === OO || "fishing" === OO) return this.buildSources(OO);
        let KO = this.sourceText.get(OO);
        return KO || (KO = this.buildSources(OO), this.sourceText.set(OO, KO)), KO
      }
      buildSources(OO) {
        const KO = this.translate;
        return "exploration" === OO ? [KO("skyblockGame:explorationZoneSource", {
          xp: this.number(100)
        }), KO("skyblockGame:explorationLandmarkSource", {
          xp: this.number(50)
        })] : "foraging" === OO ? [KO("skyblockGame:logSource", {
          xp: this.number(DK["Maple Log"])
        })] : "combat" === OO ? [KO("skyblockGame:creatureKillSource"), KO("skyblockGame:noEnvironmentalXp")] : "farming" === OO ? [KO("skyblockGame:cropSource", {
          xp: this.number(oK["Wheat|FreshlyGrown"])
        }), KO("skyblockGame:terrainFarmingSource", {
          xp: this.number(2)
        }), KO("skyblockGame:noYoungCropXp")] : Object.entries("mining" === OO ? ap : FK).map((OO => {
          let [pO, XO] = OO;
          return KO("skyblockGame:itemXpSource", {
            item: this.itemName(pO),
            xp: this.number(XO)
          })
        }))
      }
      number(OO) {
        return OO.toLocaleString(this.locale)
      }
      benefit(OO, KO) {
        const pO = XK(OO, KO);
        return this.translate(pO.translationKey, {
          bonus: this.number(pO.percent)
        })
      }
      PX(OO) {
        if (!this.YX) {
          if ("snapshot" === OO.kind) this.progress = OO.progress, this.pending.clear(), this.recent = null;
          else if ("award" === OO.kind && this.progress) {
            const {
              award: KO
            } = OO;
            this.progress = {
              ...this.progress,
              [KO.skill]: KO.after
            };
            for (const [OO, XO] of this.pending) XO.skill === KO.skill && this.pending.delete(OO);
            const pO = KO.after.level > KO.before.level;
            this.recordGain(KO.skill, KO.amount, pO ? ++this.nextLevelUpToken : null), pO && this.onLevelUp({
              questCompletionKind: "skillLevel",
              skill: KO.skill,
              beforeLevel: KO.before.level,
              level: KO.after.level
            })
          } else {
            if ("rejectBlock" === OO.kind) return void this.rejectBlock(OO.position);
            if ("open" === OO.kind) return void this.show()
          }
          this.emit()
        }
      }
      predictBlock(OO, KO, pO) {
        if (!this.progress || this.YX || pO) return;
        const XO = function(OO, KO) {
          const pO = OO.split("|")[0];
          return "Air" === KO || KO === `Barkless ${OO}` ? Object.hasOwn(DK, pO) ? {
            skill: "foraging",
            amount: DK[pO]
          } : "Air" !== KO ? null : Object.hasOwn(ap, OO) ? {
            skill: "mining",
            amount: ap[OO]
          } : vp(OO) ? {
            skill: "farming",
            amount: 10
          } : hK(OO) ? {
            skill: "foraging",
            amount: 2
          } : Object.hasOwn(oK, OO) ? {
            skill: "farming",
            amount: oK[OO]
          } : Object.hasOwn(PO, OO) ? {
            skill: "farming",
            amount: 2
          } : null : null
        }(KO, "Air");
        if (!XO) return;
        const bK = OO.join(",");
        if (this.pending.has(bK)) return;
        const eO = this.predictedProgress(XO.skill).totalXp + XO.amount;
        Number.isSafeInteger(eO) && (this.pending.set(bK, {
          ...XO,
          expires: this.now() + 2e3
        }), this.recordGain(XO.skill, 0), this.emit())
      }
      rejectBlock(OO) {
        this.pending.delete(OO.join(",")) && this.emit()
      }
      KK() {
        if (this.YX) return;
        let OO = !1;
        for (const [KO, pO] of this.pending) pO.expires <= this.now() && (this.pending.delete(KO), OO = !0);
        this.recent && this.recent.expires <= this.now() && (this.recent = null, OO = !0), OO && this.emit()
      }
      dispose() {
        this.progress = null, this.pending.clear(), this.recent = null, super.dispose()
      }
      recordGain(OO, KO) {
        var pO, XO;
        let bK = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        const eO = (null === (pO = this.recent) || void 0 === pO ? void 0 : pO.skill) === OO && this.recent.expires > this.now() ? this.recent.confirmed : 0,
          lO = (null === (XO = this.recent) || void 0 === XO ? void 0 : XO.skill) === OO && this.recent.expires > this.now() ? this.recent.levelUpToken : null;
        this.recent = {
          skill: OO,
          confirmed: eO + KO,
          expires: this.now() + 3e3,
          levelUpToken: null !== bK && void 0 !== bK ? bK : lO
        }
      }
      pendingXp(OO) {
        let KO = 0;
        for (const pO of this.pending.values()) pO.skill === OO && (KO += pO.amount);
        return KO
      }
      predictedProgress(OO) {
        const KO = this.progress[OO],
          pO = this.pendingXp(OO);
        return pO ? eK(KO.totalXp + pO, OO) : KO
      }
      isEnabled() {
        return null !== this.progress
      }
      buildSnapshot() {
        var OO, KO, pO;
        const XO = this.progress ? qK.map((OO => {
            const KO = this.predictedProgress(OO);
            return {
              ...this.text(OO),
              icon: VK[OO],
              benefit: this.benefit(OO, KO.level),
              sources: this.sources(OO),
              id: OO,
              selected: OO === this.selected,
              level: this.translate("skyblockGame:level", {
                level: this.number(KO.level)
              }),
              xp: null === KO.xpForNextLevel ? this.translate("skyblockGame:max") : this.translate("skyblockGame:xpProgress", {
                current: this.number(KO.xpIntoLevel),
                target: this.number(KO.xpForNextLevel)
              }),
              percent: null === KO.xpForNextLevel ? 100 : Math.min(100, KO.xpIntoLevel / KO.xpForNextLevel * 100)
            }
          })) : [],
          bK = XO.find((OO => {
            var KO;
            return OO.id === (null === (KO = this.recent) || void 0 === KO ? void 0 : KO.skill)
          })),
          eO = this.recent ? this.recent.confirmed + this.pendingXp(this.recent.skill) : 0;
        return {
          enabled: this.isEnabled(),
          open: this.open,
          skills: XO,
          detail: null !== (OO = XO.find((OO => OO.selected))) && void 0 !== OO ? OO : null,
          overallLevel: this.progress ? qK.reduce(((OO, KO) => OO + this.predictedProgress(KO).level), 0) : null,
          hud: bK && eO > 0 ? {
            skill: bK,
            gain: this.translate("skyblockGame:xpGain", {
              xp: this.number(eO)
            }),
            levelUpToken: null !== (KO = null === (pO = this.recent) || void 0 === pO ? void 0 : pO.levelUpToken) && void 0 !== KO ? KO : null,
            colour: QK(bK.id)
          } : null
        }
      }
    }
    const Xp = Math.max(1600, 600, 950) + 400,
      bX = {
        "--quest-step-flash": "1600ms",
        "--quest-step-pop": "600ms",
        "--quest-step-unlock": "500ms",
        "--quest-step-unlock-delay": "450ms"
      },
      ep = "skyblockQuestsView",
      lp = "skyblockQuestNotificationView";
    class vX extends DO {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : () => {},
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : Date.now,
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "en-GB",
          lO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : () => {};
        super(OO, XO, arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : () => {}), this.requestTracking = KO, this.translate = pO, this.now = bK, this.locale = eO, this.publishNotification = lO, this.notifications = void 0, this.notificationSnapshot = null, this.authoritative = null, this.receivedAt = 0, this.selected = null, this.completedExpanded = !1, this.trackAvailableAt = 0, this.waitingForTrack = !1, this.compassTarget = null, this.waypoint = null, this.trackedSteps = null, this.trackedStepPulse = 0, this.trackedChange = null, this.onTrackedStepFinished = () => {}, this.onViewDialogue = null, this.translateWithIcons = null, this.snapshot = {
          enabled: !1,
          open: !1,
          active: [],
          completed: [],
          completedExpanded: !1,
          detail: null,
          tracked: null,
          trackedStepPulse: 0,
          waypoint: null,
          compassTarget: null
        }, this.getNotificationSnapshot = () => this.notificationSnapshot, this.showTracked = () => {
          var OO, KO;
          this.selected = null !== (OO = null === (KO = this.authoritative) || void 0 === KO ? void 0 : KO.trackedQuestId) && void 0 !== OO ? OO : null, this.show()
        }, this.select = OO => {
          this.selected = OO, this.emit()
        }, this.toggleCompleted = () => {
          this.completedExpanded = !this.completedExpanded, this.emit()
        }, this.trackSelected = () => {
          const OO = this.snapshot.detail;
          !this.YX && null !== OO && void 0 !== OO && OO.canTrack && this.now() >= this.trackAvailableAt && (this.trackAvailableAt = this.now() + 2500, this.waitingForTrack = !0, this.requestTracking(OO.id), this.emit())
        }, this.viewDialogue = () => {
          const OO = this.snapshot.detail;
          var KO;
          OO && (null === (KO = this.onViewDialogue) || void 0 === KO || KO.call(this, OO.id))
        }, this.notifications = new AK(bK, (() => this.authoritative))
      }
      getTrackedQuestId() {
        var OO, KO;
        return null !== (OO = null === (KO = this.authoritative) || void 0 === KO ? void 0 : KO.trackedQuestId) && void 0 !== OO ? OO : null
      }
      notify(OO) {
        !this.YX && this.notifications.enqueue(OO) && this.emitNotification()
      }
      setNotificationsHeld(OO) {
        (this.notifications.setHeld(OO) || OO) && this.emitNotification()
      }
      KK() {
        var OO, KO;
        if (this.YX) return;
        this.notifications.KK() && this.emitNotification();
        let pO = !1;
        this.trackAvailableAt && this.now() >= this.trackAvailableAt && (this.trackAvailableAt = 0, this.waitingForTrack = !1, pO = !0), this.trackedChange && this.now() >= this.trackedChange.expiresAt && (this.trackedChange = null, pO = !0);
        const XO = Cp(this.authoritative);
        null !== XO && void 0 !== XO && null !== (OO = XO.questClock) && void 0 !== OO && OO.running && this.clockText(XO) !== (null === (KO = this.snapshot.tracked) || void 0 === KO ? void 0 : KO.clock) && (pO = !0), pO && this.emit()
      }
      setTranslator(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.locale;
        this.translate = OO, this.locale = KO, this.emitNotification(), this.emit()
      }
      PX(OO) {
        if (!this.YX)
          if ("completion" === OO.kind) this.notify(OO.questCompletion);
          else if ("landmark" === OO.kind) this.notify({
          questCompletionKind: "landmark",
          landmarkNameKey: OO.landmarkDiscoveredNameKey
        });
        else if ("npcNote" === OO.kind) {
          var KO, pO, XO;
          this.notify({
            questCompletionKind: "npcNote",
            titleKey: OO.npcNoteTitleKey,
            textKey: OO.npcNoteTextKey,
            params: null !== (KO = OO.npcNoteParams) && void 0 !== KO ? KO : {},
            nameKeys: null !== (pO = OO.npcNoteNameKeys) && void 0 !== pO ? pO : {},
            iconItem: null !== (XO = OO.npcNoteIconItem) && void 0 !== XO ? XO : null
          })
        } else if ("open" === OO.kind) this.show();
        else if ("guidance" === OO.kind) this.waypoint = OO.waypoint, this.compassTarget = OO.compassTarget, this.snapshot = {
          ...this.snapshot,
          waypoint: this.waypoint,
          compassTarget: this.compassTarget
        };
        else if ("snapshot" === OO.kind) {
          this.authoritative = OO.snapshot, this.notifications.KK() && this.emitNotification(), this.receivedAt = this.now(), this.waitingForTrack = !1;
          const KO = this.trackedStepPulse;
          this.updateTrackedStepPulse(OO.snapshot), this.emit(), this.trackedStepPulse > KO && this.onTrackedStepFinished()
        }
      }
      dispose() {
        this.notifications.clear(), this.emitNotification(), this.authoritative = null, this.selected = null, this.completedExpanded = !1, this.trackAvailableAt = 0, this.waitingForTrack = !1, this.waypoint = null, this.compassTarget = null, this.trackedSteps = null, this.trackedStepPulse = 0, this.trackedChange = null, super.dispose()
      }
      emitNotification() {
        this.YX || (this.notificationSnapshot = this.notifications.getView(this.translate, this.questTextTranslator(), this.locale), this.publishNotification(this.notificationSnapshot))
      }
      questTextTranslator() {
        var OO;
        return null !== (OO = this.translateWithIcons) && void 0 !== OO ? OO : this.translate
      }
      clockText(OO) {
        const KO = OO.questClock;
        if (!KO) return null;
        const pO = KO.elapsedMs + (KO.running ? this.now() - this.receivedAt : 0);
        return void 0 === KO.countdownFromMs ? (0, jK.o)(pO, !1) : (0, jK.o)(1e3 * Math.ceil(Math.max(0, KO.countdownFromMs - pO) / 1e3), !1)
      }
      updateTrackedStepPulse(OO) {
        var KO, pO, XO;
        const bK = Cp(OO);
        if (!bK) return this.trackedSteps = null, this.trackedStepPulse = 0, void(this.trackedChange = null);
        const eO = OO => bK.subquests.filter((KO => OO(KO.status))).map((OO => OO.id)),
          lO = eO((OO => "completed" === OO || "skipped" === OO)),
          vK = eO((OO => "locked" !== OO)),
          CO = (null === (KO = this.trackedSteps) || void 0 === KO ? void 0 : KO.questId) === bK.id && bK.progress >= this.trackedSteps.progress ? this.trackedSteps : null;
        if (CO) {
          const OO = lO.filter((OO => !CO.finished.has(OO))),
            KO = eO((OO => "active" === OO || "ready" === OO)).filter((OO => !CO.unlocked.has(OO)));
          OO.length > 0 && this.trackedStepPulse++, (OO.length > 0 || KO.length > 0) && (this.trackedChange = {
            finished: new Set(OO),
            unlocked: new Set(KO),
            expiresAt: this.now() + Xp
          })
        } else {
          var hO;
          this.trackedStepPulse = (null === (hO = this.trackedSteps) || void 0 === hO ? void 0 : hO.questId) === bK.id ? this.trackedStepPulse : 0, this.trackedChange = null
        }
        this.trackedSteps = {
          questId: bK.id,
          progress: bK.progress,
          finished: new Set([...null !== (pO = null === CO || void 0 === CO ? void 0 : CO.finished) && void 0 !== pO ? pO : [], ...lO]),
          unlocked: new Set([...null !== (XO = null === CO || void 0 === CO ? void 0 : CO.unlocked) && void 0 !== XO ? XO : [], ...vK])
        }
      }
      entry(OO, KO) {
        var pO, XO;
        const bK = OO.id === (null === (pO = this.authoritative) || void 0 === pO ? void 0 : pO.trackedQuestId),
          eO = this.now() < this.trackAvailableAt,
          lO = this.questTextTranslator(),
          vK = OO.subquests.map((KO => {
            var pO, XO, eO, vK, CO, hO;
            const DO = null !== (pO = KO.handInNpcName) && void 0 !== pO ? pO : OO.giverName,
              MO = this.translate("skyblockGame:progress", {
                current: KO.progress.toLocaleString(this.locale),
                target: KO.target.toLocaleString(this.locale)
              }),
              aK = {
                active: null,
                locked: "skyblockGame:subquestLocked",
                ready: DO ? "skyblockGame:subquestReady" : "skyblockGame:subquestReadyNoNpc",
                completed: "skyblockGame:completed",
                skipped: "skyblockGame:subquestSkipped"
              } [KO.status],
              oO = "active" === KO.status || "ready" === KO.status;
            return {
              id: KO.id,
              name: zp(lO, KO.nameKey, KO.nameParams),
              description: zp(lO, KO.descriptionKey, KO.descriptionParams),
              progress: MO,
              status: KO.status,
              statusLabel: aK ? this.translate(aK, {
                npc: DO
              }) : MO,
              iconItem: oO && null !== (XO = KO.questIconItem) && void 0 !== XO ? XO : null,
              barPercent: "active" === KO.status && KO.showsProgressBar ? Math.min(100, 100 * KO.progress / KO.target) : null,
              justFinished: bK && null !== (eO = null === (vK = this.trackedChange) || void 0 === vK ? void 0 : vK.finished.has(KO.id)) && void 0 !== eO && eO,
              justUnlocked: bK && null !== (CO = null === (hO = this.trackedChange) || void 0 === hO ? void 0 : hO.unlocked.has(KO.id)) && void 0 !== CO && CO
            }
          }));
        return {
          id: OO.id,
          name: zp(lO, OO.nameKey, OO.nameParams),
          description: zp(lO, OO.descriptionKey, OO.descriptionParams),
          progress: KO ? this.translate("skyblockGame:completed") : this.translate("skyblockGame:stepsProgress", {
            current: OO.progress.toLocaleString(this.locale),
            target: OO.target.toLocaleString(this.locale)
          }),
          completed: KO,
          tracked: bK,
          selected: OO.id === this.selected,
          canTrack: !KO && !bK && !eO,
          trackLabel: this.translate(bK ? "skyblockGame:trackingQuest" : this.waitingForTrack ? "skyblockGame:updating" : eO ? "skyblockGame:pleaseWait" : "skyblockGame:trackQuest"),
          canViewDialogue: null !== this.onViewDialogue && "dungeon_run" !== OO.id,
          subquests: vK,
          focusStep: null !== (XO = vK.find((OO => null !== OO.barPercent))) && void 0 !== XO ? XO : null,
          clock: this.clockText(OO)
        }
      }
      isEnabled() {
        return null !== this.authoritative
      }
      buildSnapshot() {
        var OO, KO, pO, XO, bK, eO, lO, vK, CO, hO;
        const DO = [...null !== (OO = null === (KO = this.authoritative) || void 0 === KO ? void 0 : KO.active) && void 0 !== OO ? OO : [], ...null !== (pO = null === (XO = this.authoritative) || void 0 === XO ? void 0 : XO.completed) && void 0 !== pO ? pO : []];
        var MO, aK, oO, FO;
        DO.some((OO => OO.id === this.selected)) || (this.selected = null !== (MO = null !== (aK = null === (oO = this.authoritative) || void 0 === oO ? void 0 : oO.trackedQuestId) && void 0 !== aK ? aK : null === (FO = DO[0]) || void 0 === FO ? void 0 : FO.id) && void 0 !== MO ? MO : null);
        const VO = null !== (bK = null === (eO = this.authoritative) || void 0 === eO ? void 0 : eO.active.map((OO => this.entry(OO, !1)))) && void 0 !== bK ? bK : [];
        VO.sort(((OO, KO) => Number(KO.tracked) - Number(OO.tracked)));
        const LO = null !== (lO = null === (vK = this.authoritative) || void 0 === vK ? void 0 : vK.completed.map((OO => this.entry(OO, !0)))) && void 0 !== lO ? lO : [];
        return {
          enabled: this.isEnabled(),
          open: this.open,
          active: VO,
          completed: LO,
          completedExpanded: this.completedExpanded,
          detail: null !== (CO = [...VO, ...LO].find((OO => OO.selected))) && void 0 !== CO ? CO : null,
          tracked: null !== (hO = VO.find((OO => OO.tracked))) && void 0 !== hO ? hO : null,
          trackedStepPulse: this.trackedStepPulse,
          waypoint: this.waypoint,
          compassTarget: this.compassTarget
        }
      }
    }

    function Cp(OO) {
      var KO;
      return null !== (KO = null === OO || void 0 === OO ? void 0 : OO.active.find((KO => KO.id === OO.trackedQuestId))) && void 0 !== KO ? KO : null
    }
    const hp = "skyblockDungeonsView";
    class Dp extends DO {
      constructor(OO, KO) {
        let pO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "en-GB",
          XO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : () => {};
        super(OO, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => {}, arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : () => {}), this.translate = KO, this.locale = pO, this.requestEnter = XO, this.authoritative = null, this.selected = null, this.pickerDungeonId = null, this.pageIndex = 0, this.snapshot = {
          enabled: !1,
          open: !1,
          dungeons: [],
          detail: null,
          picker: null
        }, this.select = OO => {
          this.selected = OO, this.emit()
        }, this.previous = () => {
          this.turnTo(this.pageIndex - 1)
        }, this.next = () => {
          this.turnTo(this.pageIndex + 1)
        }, this.enter = () => {
          const OO = this.pickerEntry(),
            KO = null === OO || void 0 === OO ? void 0 : OO.difficulties[this.pageIndex];
          void 0 !== KO && null !== KO.unlockedBoss && (this.close(), this.requestEnter(OO.id, KO.difficulty))
        }
      }
      setTranslator(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.locale;
        this.translate = OO, this.locale = KO, this.emit()
      }
      PX(OO) {
        var KO, pO;
        if (!this.YX) return "open" === OO.kind ? (this.pickerDungeonId = null, void this.show()) : void("choose" !== OO.kind ? "snapshot" === OO.kind && (this.authoritative = OO.snapshot, this.pageIndex = Math.min(this.pageIndex, Math.max(0, (null !== (KO = null === (pO = this.pickerEntry()) || void 0 === pO ? void 0 : pO.difficulties.length) && void 0 !== KO ? KO : 1) - 1)), null === OO.snapshot && this.open ? this.close() : this.emit()) : this.choose(OO.chooseDungeonId))
      }
      dispose() {
        this.authoritative = null, this.selected = null, this.pickerDungeonId = null, super.dispose()
      }
      onClosed() {
        this.pickerDungeonId = null
      }
      choose(OO) {
        var KO;
        const pO = null === (KO = this.authoritative) || void 0 === KO ? void 0 : KO.dungeons.find((KO => KO.id === OO));
        void 0 !== pO ? this.open && this.pickerDungeonId === OO || (this.pickerDungeonId = OO, this.pageIndex = Math.max(0, pO.difficulties.findLastIndex((OO => null !== OO.unlockedBoss))), this.open ? this.emit() : this.show()) : console.warn(`Skyblock dungeons: asked to choose a boss in unknown dungeon ${OO}`)
      }
      turnTo(OO) {
        var KO, pO;
        const XO = null !== (KO = null === (pO = this.pickerEntry()) || void 0 === pO ? void 0 : pO.difficulties.length) && void 0 !== KO ? KO : 0;
        OO < 0 || OO >= XO || OO === this.pageIndex || (this.pageIndex = OO, this.emit())
      }
      pickerEntry() {
        var OO, KO;
        return null !== (OO = null === (KO = this.authoritative) || void 0 === KO ? void 0 : KO.dungeons.find((OO => OO.id === this.pickerDungeonId))) && void 0 !== OO ? OO : null
      }
      difficulty(OO) {
        const KO = OO.completions > 0,
          pO = null === OO.bestMs ? null : (0, jK.o)(OO.bestMs);
        return {
          difficulty: OO.difficulty,
          label: this.translate(jK.d[OO.difficulty]),
          colour: jK.g[OO.difficulty],
          beaten: KO,
          bestTime: pO,
          completions: OO.completions,
          summary: KO ? [null === pO ? null : this.translate("skyblockGame:dungeonBestTime", {
            time: pO
          }), this.translate("skyblockGame:dungeonCompletions", {
            completions: OO.completions.toLocaleString(this.locale)
          })].filter((OO => null !== OO)).join(" \xb7 ") : this.translate("skyblockGame:dungeonNotCompleted")
        }
      }
      entry(OO) {
        const KO = OO.difficulties.map((OO => this.difficulty(OO))),
          pO = KO.filter((OO => OO.beaten)).length;
        return {
          id: OO.id,
          name: this.translate(OO.nameKey),
          selected: OO.id === this.selected,
          beatenSummary: `${pO} / ${KO.length}`,
          difficulties: KO
        }
      }
      picker() {
        const OO = this.pickerEntry();
        if (null === OO || 0 === OO.difficulties.length) return null;
        const KO = OO.difficulties.map(((KO, pO) => {
          var XO, bK, eO, lO;
          const vK = KO.unlockedBoss,
            CO = null === vK ? this.lockedHint(OO, pO) : null;
          return {
            ...this.difficulty(KO),
            unlocked: null !== vK,
            bossName: null === vK ? null : this.translate(vK.bossNameKey),
            bossMobType: null !== (XO = null === vK || void 0 === vK ? void 0 : vK.bossMobType) && void 0 !== XO ? XO : null,
            bossMobVariation: null !== (bK = null === vK || void 0 === vK ? void 0 : vK.bossMobVariation) && void 0 !== bK ? bK : null,
            lockedHint: null !== (eO = null === CO || void 0 === CO ? void 0 : CO.text) && void 0 !== eO ? eO : null,
            lockedHintHighlight: null !== (lO = null === CO || void 0 === CO ? void 0 : CO.highlight) && void 0 !== lO ? lO : null,
            current: pO === this.pageIndex
          }
        }));
        return {
          dungeonName: this.translate(OO.nameKey),
          pages: KO,
          page: KO[this.pageIndex],
          canPrevious: this.pageIndex > 0,
          canNext: this.pageIndex < KO.length - 1
        }
      }
      lockedHint(OO, KO) {
        var pO, XO, bK;
        if (0 === KO && "number" === typeof OO.combatLevelLock) {
          const KO = this.translate("skyblockGame:dungeonBossLockedCombatLevel", {
            level: OO.combatLevelLock
          });
          return this.hintHighlighting("skyblockGame:dungeonBossLockedCombat", {}, "skill", {
            name: KO,
            colour: QK("combat"),
            icon: VK.combat
          })
        }
        const eO = null !== (pO = null === (XO = this.authoritative) || void 0 === XO ? void 0 : XO.dungeons) && void 0 !== pO ? pO : [],
          lO = KO > 0 ? OO : null !== (bK = eO[eO.indexOf(OO) - 1]) && void 0 !== bK ? bK : null,
          vK = KO > 0 ? OO.difficulties[KO - 1] : null === lO || void 0 === lO ? void 0 : lO.difficulties[0];
        if (null === lO || void 0 === vK) return null;
        const CO = this.translate(lO.nameKey);
        if (null === vK.unlockedBoss) return lO === OO ? this.hintNamingDifficulty("skyblockGame:dungeonBossLockedUnseen", {}, vK.difficulty) : this.hintNamingDifficulty("skyblockGame:dungeonBossLockedUnseenElsewhere", {
          dungeon: CO
        }, vK.difficulty);
        const hO = this.translate(vK.unlockedBoss.bossNameKey);
        return lO === OO ? this.hintNamingDifficulty("skyblockGame:dungeonBossLocked", {
          boss: hO
        }, vK.difficulty) : {
          text: this.translate("skyblockGame:dungeonBossLockedElsewhere", {
            boss: hO,
            dungeon: CO
          }),
          highlight: null
        }
      }
      hintNamingDifficulty(OO, KO, pO) {
        return this.hintHighlighting(OO, KO, "difficulty", {
          name: this.translate(jK.d[pO]),
          colour: jK.g[pO],
          icon: null
        })
      }
      hintHighlighting(OO, KO, pO, XO) {
        let {
          name: bK,
          colour: eO,
          icon: lO
        } = XO;
        const vK = this.translate(OO, {
          ...KO,
          [pO]: "\x01"
        }).split("\x01");
        return {
          text: this.translate(OO, {
            ...KO,
            [pO]: bK
          }),
          highlight: 2 === vK.length ? {
            before: vK[0],
            name: bK,
            after: vK[1],
            colour: eO,
            icon: lO
          } : null
        }
      }
      isEnabled() {
        return null !== this.authoritative
      }
      buildSnapshot() {
        var OO, KO, pO;
        const XO = null !== (OO = null === (KO = this.authoritative) || void 0 === KO ? void 0 : KO.dungeons) && void 0 !== OO ? OO : [];
        var bK, eO;
        XO.some((OO => OO.id === this.selected)) || (this.selected = null !== (bK = null === (eO = XO[0]) || void 0 === eO ? void 0 : eO.id) && void 0 !== bK ? bK : null);
        const lO = XO.map((OO => this.entry(OO)));
        return {
          enabled: this.isEnabled(),
          open: this.open,
          dungeons: lO,
          detail: null !== (pO = lO.find((OO => OO.selected))) && void 0 !== pO ? pO : null,
          picker: null === this.pickerDungeonId ? null : this.picker()
        }
      }
    }
    const Mp = ["mining", "farming", "foraging", "fishing", "combat"],
      aX = [25, 50, 100, 200, 400, 750, 1250, 2e3, 3e3],
      op = [20, 40, 80, 150, 300, 500, 800, 1200, 2e3];

    function Fp() {
      for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
      return KO.map(((OO, KO) => ({
        amount: OO,
        coins: aX[KO],
        xp: op[KO]
      })))
    }
    const Vp = Fp(100, 250, 500, 1e3, 2500, 5e3, 1e4, 25e3, 5e4),
      Lp = Fp(50, 100, 250, 1e3, 2500, 5e3, 1e4, 25e3),
      Qp = Fp(50, 100, 250, 500, 1e3, 2500, 5e3),
      zX = Fp(25, 50, 100, 250, 500, 1e3),
      Ap = Fp(10, 25, 50, 100, 250, 500, 1e3),
      fp = Fp(1, 5, 10, 25, 50);

    function dp(OO, KO) {
      return {
        id: OO,
        category: "fishing",
        item: KO,
        drops: [KO],
        tiers: arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Ap
      }
    }
    const Tp = [{
        id: "coal",
        category: "mining",
        item: "Coal",
        blocks: {
          "Coal Ore": 1,
          "Pure Coal Ore": 9,
          "Block of Coal": 3
        },
        tiers: Lp
      }, {
        id: "iron",
        category: "mining",
        item: "Raw Iron",
        blocks: {
          "Iron Ore": 1,
          "Pure Iron Ore": 9
        },
        tiers: Qp
      }, {
        id: "gold",
        category: "mining",
        item: "Raw Gold",
        blocks: {
          "Gold Ore": 1,
          "Pure Gold Ore": 9
        },
        tiers: Qp
      }, {
        id: "diamond",
        category: "mining",
        item: "Diamond",
        blocks: {
          "Diamond Ore": 1,
          "Pure Diamond Ore": 9
        },
        tiers: zX
      }, {
        id: "moonstone",
        category: "mining",
        item: "Moonstone",
        blocks: {
          "Moonstone Ore": 1,
          "Pure Moonstone Ore": 9
        },
        tiers: zX
      }, {
        id: "stone",
        category: "mining",
        item: "Stone",
        blocks: {
          Stone: 1
        },
        tiers: Lp
      }, {
        id: "wheat",
        category: "farming",
        item: "Wheat",
        blocks: {
          "Wheat|FreshlyGrown": 1
        },
        tiers: Vp
      }, {
        id: "carrot",
        category: "farming",
        item: "Carrot",
        blocks: {
          "Carrot Plant|FreshlyGrown": 1
        },
        tiers: Vp
      }, {
        id: "potato",
        category: "farming",
        item: "Raw Potato",
        blocks: {
          "Potato Plant|FreshlyGrown": 1
        },
        tiers: Vp
      }, {
        id: "beetroot",
        category: "farming",
        item: "Beetroot",
        blocks: {
          "Beetroot Plant|FreshlyGrown": 1
        },
        tiers: Qp
      }, {
        id: "melon",
        category: "farming",
        item: "Melon",
        blocks: {
          Melon: 1
        },
        tiers: Lp
      }, {
        id: "watermelon",
        category: "farming",
        item: "Watermelon",
        blocks: {
          Watermelon: 1
        },
        tiers: Lp
      }, {
        id: "maple_log",
        category: "foraging",
        item: "Maple Log",
        blocks: {
          "Maple Log": 1
        },
        tiers: Lp
      }, {
        id: "pear_log",
        category: "foraging",
        item: "Pear Log",
        blocks: {
          "Pear Log": 1
        },
        tiers: Qp
      }, {
        id: "palm_log",
        category: "foraging",
        item: "Palm Log",
        blocks: {
          "Palm Log": 1
        },
        tiers: Qp
      }, dp("wheatfish", "Wheatfish"), dp("darter", "Darter"), dp("sunset_minnow", "Sunset Minnow"), dp("root_flounder", "Root Flounder"), dp("greenfin_loach", "Greenfin Loach"), dp("red_strongfish", "Red Strongfish"), dp("green_strongfish", "Green Strongfish"), dp("boomerang_fish", "Boomerang Fish"), dp("seahorse", "Seahorse"), dp("spined_stickleback", "Spined Stickleback"), dp("moon_strongfish", "Moon Strongfish"), dp("boulder_bass", "Boulder Bass"), dp("grass_snapper", "Grass Snapper"), dp("crystal_wheatfish", "Crystalized Wheatfish", fp), dp("moonstone_pupfish", "Moonstone Pupfish", fp), dp("reedglass_minnow", "Reedglass Minnow"), dp("mangrove_herring", "Mangrove Herring"), dp("mudline_perch", "Mudline Perch"), dp("coastal_mullet", "Coastal Mullet"), dp("reef_sardine", "Reef Sardine"), dp("root_perch", "Root Perch"), dp("driftwood_catfish", "Driftwood Catfish"), dp("aether_minnow", "Aether Minnow"), dp("needlefish", "Tri-Pointed Needlefish"), dp("threadfin_bream", "Threadfin Bream"), dp("mudbelly_tilapia", "Mudbelly Tilapia"), dp("rotslab_eel", "Rotslab Eel"), dp("polarflash_electron", "Polarflash Electron"), dp("mireback_carp", "Mireback Carp"), dp("blackwater_bream", "Blackwater Bream"), dp("stone_grouper", "Stone Grouper"), dp("shadeback_ray", "Shadeback Ray"), dp("glacial_silverfish", "Glacial Silverfish"), dp("hatchetfish", "Hatchetfish"), dp("moonlit_boomerang", "Moonlit Boomerang Fish"), dp("murkborne_ray", "Murkborne Ray"), dp("bamboo_catfish", "Bamboo Catfish"), dp("mossback_arapaima", "Mossback Arapaima"), dp("murk_stingray", "Murk Stingray"), dp("channel_sawfish", "Channel Sawfish"), dp("boned_sturgeon", "Boned Sturgeon"), dp("oarfish", "Oarfish"), dp("snakehead", "Snakehead", fp), dp("eldertide_leviathan", "Eldertide Leviathan", fp), dp("pithead", "Pithead"), dp("electric_eel", "Electric Eel"), dp("shadow_darter", "Shadow Darter"), dp("abyss_carp", "Abyss Carp"), dp("nomai_moray", "Nomai Moray"), dp("silver_dragonfish", "Silver Dragonfish"), dp("giant_moray", "Giant Moray"), dp("coelacanth", "Coelacanth", fp), dp("frost_herring", "Frost Herring"), dp("permafrost_halibut", "Permafrost Halibut"), dp("glacial_lanternfish", "Glacial Lanternfish"), dp("frozen_grenadier", "Frozen Grenadier"), dp("blackfin_icefish", "Blackfin Icefish"), dp("moonfish", "Moonfish"), dp("alpha_strongfish", "Alpha Moon Strongfish"), dp("deep_lanternfish", "Deepwater Lanternfish", fp), dp("pearlescent_moonfish", "Pearlescent Moonfish", fp), {
        id: "rotten_flesh",
        category: "combat",
        item: "Rotten Flesh",
        drops: ["Rotten Flesh"],
        tiers: Lp
      }, {
        id: "rotten_brain",
        category: "combat",
        item: "Rotten Brain",
        drops: ["Rotten Brain"],
        tiers: zX
      }, {
        id: "iron_fragment",
        category: "combat",
        item: "Iron Fragment",
        drops: ["Iron Fragment"],
        tiers: zX
      }],
      Np = (new Map(Tp.map((OO => [OO.id, OO]))), new Map),
      Ip = new Map;
    for (const XC of Tp) {
      for (const [OO, KO] of Object.entries(null !== (yX = XC.blocks) && void 0 !== yX ? yX : {})) {
        var yX;
        Np.set(OO, {
          collection: XC,
          amount: KO
        })
      }
      for (const OO of null !== (gX = XC.drops) && void 0 !== gX ? gX : []) {
        var gX;
        Ip.set(OO, XC)
      }
    }

    function upO(OO, KO) {
      let pO = 0;
      for (; pO < OO.tiers.length && KO >= OO.tiers[pO].amount;) pO++;
      return pO
    }
    const Ep = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"];

    function jX(OO) {
      return Ep[OO - 1]
    }
    const Yp = "skyblockCollectionsView";
    class wp extends DO {
      constructor(OO, KO) {
        let pO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "en-GB",
          XO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : OO => OO;
        super(OO, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => {}, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : () => {}), this.translate = KO, this.locale = pO, this.itemName = XO, this.counts = null, this.category = "mining", this.selected = Tp[0].id, this.snapshot = {
          enabled: !1,
          open: !1,
          categories: [],
          collections: [],
          detail: null,
          tiersUnlocked: ""
        }, this.selectCategory = OO => {
          this.category = OO, this.selected = this.inCategory(OO)[0].id, this.emit()
        }, this.select = OO => {
          this.selected = OO, this.emit()
        }
      }
      setTranslator(OO, KO, pO) {
        this.translate = OO, this.locale = KO, this.itemName = pO, this.emit()
      }
      PX(OO) {
        if (!this.YX)
          if ("collOpen" !== OO.kind) {
            (OO.collFull || null === this.counts) && (this.counts = new Map);
            for (const [KO, pO] of OO.collCounts) this.counts.set(KO, pO);
            this.emit()
          } else this.show()
      }
      dispose() {
        this.counts = null, super.dispose()
      }
      isEnabled() {
        return null !== this.counts
      }
      buildSnapshot() {
        var OO;
        if (null === this.counts) return {
          enabled: !1,
          open: this.open,
          categories: [],
          collections: [],
          detail: null,
          tiersUnlocked: ""
        };
        const KO = this.inCategory(this.category).map((OO => this.collectionView(OO))),
          pO = Tp.reduce(((OO, KO) => OO + this.tierOf(KO)), 0);
        return {
          enabled: !0,
          open: this.open,
          categories: Mp.map((OO => this.categoryView(OO))),
          collections: KO,
          detail: null !== (OO = KO.find((OO => OO.selected))) && void 0 !== OO ? OO : null,
          tiersUnlocked: this.translate("skyblockGame:collectionTiersUnlocked", {
            count: this.number(pO)
          })
        }
      }
      categoryView(OO) {
        const KO = this.inCategory(OO),
          pO = KO.reduce(((OO, KO) => OO + this.tierOf(KO)), 0),
          XO = KO.reduce(((OO, KO) => OO + KO.tiers.length), 0);
        return {
          id: OO,
          label: this.translate(`skyblockGame:${OO}`),
          icon: VK[OO],
          tiers: this.translate("skyblockGame:collectionProgress", {
            current: this.number(pO),
            target: this.number(XO)
          }),
          selected: OO === this.category
        }
      }
      collectionView(OO) {
        var KO, pO;
        const XO = null !== (KO = this.counts.get(OO.id)) && void 0 !== KO ? KO : 0,
          bK = upO(OO, XO),
          eO = null !== (pO = OO.tiers[bK]) && void 0 !== pO ? pO : null,
          lO = 0 === bK ? 0 : OO.tiers[bK - 1].amount;
        return {
          id: OO.id,
          name: this.itemName(OO.item),
          icon: OO.item,
          selected: OO.id === this.selected,
          locked: 0 === XO,
          count: this.translate("skyblockGame:collectionCount", {
            count: this.number(XO)
          }),
          tier: 0 === bK ? this.translate("skyblockGame:collectionNoTier") : this.tierLabel(bK),
          percent: null === eO ? 100 : Math.min(100, (XO - lO) / (eO.amount - lO) * 100),
          progress: null === eO ? this.translate("skyblockGame:max") : this.translate("skyblockGame:collectionProgress", {
            current: this.number(XO),
            target: this.number(eO.amount)
          }),
          nextReward: null === eO ? null : this.reward(OO, eO.coins, eO.xp)
        }
      }
      reward(OO, KO, pO) {
        return this.translate("skyblockGame:collectionReward", {
          coins: this.number(KO),
          xp: this.number(pO),
          skill: this.translate(`skyblockGame:${OO.category}`)
        })
      }
      tierLabel(OO) {
        return this.translate("skyblockGame:collectionTier", {
          tier: jX(OO)
        })
      }
      tierOf(OO) {
        var KO;
        return upO(OO, null !== (KO = this.counts.get(OO.id)) && void 0 !== KO ? KO : 0)
      }
      inCategory(OO) {
        return Tp.filter((KO => KO.category === OO))
      }
      number(OO) {
        return OO.toLocaleString(this.locale)
      }
    }
    const iX = "skyblockPortalTransitView",
      rX = "skyblockPortalArrival";
    class Pp {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Date.now;
        this.pl = OO, this.storage = KO, this.now = pO, this.view = null, this.token = 0, this.hideTimer = null
      }
      getSnapshot() {
        return this.view
      }
      PX(OO) {
        const KO = {
          zoneNameKey: OO.transitZoneNameKey,
          variation: OO.transitZoneVariation,
          colour: OO.transitColour,
          departedAt: this.now()
        };
        this.storage.setItem(rX, KO), this.show("departure", KO.zoneNameKey, KO.colour, OO.transitDurationMs, OO.transitDurationMs + 1500, (() => {
          this.storage.removeItem(rX)
        }))
      }
      resumeArrival(OO) {
        const KO = this.storage.getItem(rX);
        this.storage.removeItem(rX), null === KO || KO.variation !== OO || this.now() - KO.departedAt > 3e4 || this.show("arrival", KO.zoneNameKey, KO.colour, 3200, 2e4)
      }
      finishArrival(OO) {
        var KO;
        "arrival" === (null === (KO = this.view) || void 0 === KO ? void 0 : KO.phase) && this.view.token === OO && (this.clearTimer(), this.view = null, this.pl(null))
      }
      dispose() {
        this.clearTimer()
      }
      show(OO, KO, pO, XO, bK, eO) {
        this.clearTimer(), this.view = {
          token: ++this.token,
          phase: OO,
          zoneNameKey: KO,
          colour: pO,
          durationMs: XO
        }, this.pl(this.view), this.hideTimer = setTimeout((() => {
          this.hideTimer = null, this.view = null, this.pl(null), null === eO || void 0 === eO || eO()
        }), bK)
      }
      clearTimer() {
        null !== this.hideTimer && (clearTimeout(this.hideTimer), this.hideTimer = null)
      }
    }
    const mX = "skyblockDailyRewardView",
      sp = "skyblockDailyRewardCoin";
    class Hp {
      constructor(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : () => {},
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : () => {},
          lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : () => {},
          vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : () => {},
          CO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : performance.now.bind(performance);
        this.pl = OO, this.isBusy = KO, this.holdQuestPopups = pO, this.onHeldCoinsChanged = XO, this.onCoinLanded = bK, this.onStarted = eO, this.onFinished = lO, this.onItemLanded = vK, this.now = CO, this.JK = [], this.queue = [], this.playing = null, this.token = 0
      }
      getSnapshot() {
        var OO, KO;
        return null !== (OO = null === (KO = this.playing) || void 0 === KO ? void 0 : KO.view) && void 0 !== OO ? OO : null
      }
      getHeldCoins() {
        var OO, KO;
        let pO = 0;
        for (const XO of this.JK) pO += XO.coins;
        return pO - (null !== (OO = null === (KO = this.playing) || void 0 === KO ? void 0 : KO.released) && void 0 !== OO ? OO : 0)
      }
      PX(OO) {
        "dailyRewardClaimed" !== OO.kind ? (this.queue.push(OO), this.KK()) : this.JK.push({
          coins: OO.dailyRewardCoins,
          receivedAt: this.now()
        })
      }
      KK() {
        const OO = this.now();
        if (null === this.playing) return this.releaseUnshown(OO), void this.startNext(OO);
        const KO = this.playing,
          pO = OO - KO.startedAt,
          XO = KO.view.flyingCoins,
          bK = function(OO, KO) {
            let pO = 0;
            for (; pO < KO && Sp(pO, KO) <= OO;) pO++;
            return pO
          }(pO, XO);
        if (bK !== KO.landed) {
          for (let OO = bK - KO.landed > 2 ? bK - 1 : KO.landed; OO < bK; OO++) this.onCoinLanded(OO, XO);
          KO.landed = bK, KO.released = Math.round(KO.view.coins * bK / XO), this.onHeldCoinsChanged()
        }
        for (; KO.itemsLanded < KO.view.items.length && 2e3 + 160 * KO.itemsLanded + 630 <= pO;) this.onItemLanded(KO.itemsLanded), KO.itemsLanded++;
        pO >= KO.view.durationMs && (this.finish(), this.startNext(OO))
      }
      dispose() {
        null !== this.playing && this.holdQuestPopups(!1), this.playing = null, this.queue = [], this.JK = [], this.pl(null)
      }
      startNext(OO) {
        if (0 === this.queue.length || this.isBusy()) return;
        const KO = this.queue.shift();
        this.token++;
        const pO = {
          token: this.token,
          day: KO.dailyRewardDay,
          coins: KO.dailyRewardCoins,
          items: KO.dailyRewardItems,
          durationMs: 5e3,
          flyingCoins: KO.dailyRewardDay === gK ? 24 : 14
        };
        this.playing = {
          view: pO,
          startedAt: OO,
          landed: 0,
          released: 0,
          itemsLanded: 0
        }, this.holdQuestPopups(!0), this.pl(pO), this.onStarted(pO)
      }
      finish() {
        this.JK.shift(), this.playing = null, this.holdQuestPopups(!1), this.pl(null), this.onHeldCoinsChanged(), this.onFinished()
      }
      releaseUnshown(OO) {
        if (this.queue.length > 0 || 0 === this.JK.length) return;
        const KO = this.JK.length;
        this.JK = this.JK.filter((KO => OO - KO.receivedAt < 6e4)), this.JK.length !== KO && this.onHeldCoinsChanged()
      }
    }

    function Rp(OO, KO) {
      return 450 + 715 * OO / (KO - 1)
    }

    function Sp(OO, KO) {
      return Rp(OO, KO) + 650
    }
    const Jp = "skyblockMailboxView";
    class cX {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => {},
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : performance.now.bind(performance);
        this.pl = OO, this.isBusy = KO, this.onStarted = pO, this.now = XO, this.waiting = [], this.playing = null, this.token = 0, this.itemName = OO => OO
      }
      getSnapshot() {
        var OO, KO;
        return null !== (OO = null === (KO = this.playing) || void 0 === KO ? void 0 : KO.view) && void 0 !== OO ? OO : null
      }
      setItemName(OO) {
        this.itemName = OO
      }
      PX(OO) {
        this.waiting.push(...OO.mailLetters), this.KK()
      }
      KK() {
        const OO = this.now();
        null !== this.playing && OO - this.playing.startedAt >= this.playing.view.durationMs && (this.playing = null, this.pl(null)), null === this.playing && this.waiting.length > 0 && !this.isBusy() && this.start(OO)
      }
      dispose() {
        this.playing = null, this.waiting = [], this.pl(null)
      }
      start(OO) {
        const KO = this.waiting.slice(0, 3);
        this.token++;
        const pO = {
          token: this.token,
          letters: KO.map((OO => this.toView(OO))),
          more: this.waiting.length - KO.length,
          durationMs: 4500 + 700 * KO.length
        };
        this.waiting = [], this.playing = {
          view: pO,
          startedAt: OO
        }, this.pl(pO), this.onStarted(pO)
      }
      toView(OO) {
        return {
          coins: OO.mailCoins,
          items: OO.mailItems.map((OO => {
            var KO;
            return {
              itemName: OO.mailItemName,
              amount: OO.mailItemAmount,
              label: null !== (KO = OO.mailItemLabel) && void 0 !== KO ? KO : this.itemName(OO.mailItemName)
            }
          })),
          reasonKey: OO.mailReasonKey,
          reasonParams: OO.mailReasonParams
        }
      }
    }
    const Bp = "skyblockQuestGraphView",
      Zp = "skyblockDevQuestJump";

    function Gp(OO) {
      if (0 === OO.length) return "";
      const KO = [`M ${OO[0].x} ${OO[0].y}`];
      for (let XO = 1; XO < OO.length - 1; XO++) {
        const pO = OO[XO + 1];
        KO.push(`Q ${OO[XO].x} ${OO[XO].y} ${(OO[XO].x+pO.x)/2} ${(OO[XO].y+pO.y)/2}`)
      }
      const pO = OO[OO.length - 1];
      return KO.push(`L ${pO.x} ${pO.y}`), KO.join(" ")
    }

    function qX(OO, KO) {
      return OO < KO ? `${OO}|${KO}` : `${KO}|${OO}`
    }
    class xX extends DO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => {},
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : () => {},
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : () => {},
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : () => {},
          lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {}
          },
          vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : Date.now;
        super(OO, pO, XO), this.translate = KO, this.requestJump = bK, this.requestArrive = eO, this.storage = lO, this.now = vK, this.layout = null, this.hoveredId = null, this.graphCount = 0, this.snapshot = {
          enabled: !1,
          open: !1,
          width: 0,
          height: 0,
          nodes: [],
          edges: [],
          planning: !1
        }, this.hover = OO => {
          OO !== this.hoveredId && (this.hoveredId = OO, this.emit())
        }, this.jump = OO => {
          this.close(), this.requestJump(OO)
        }
      }
      PX(OO) {
        if (!this.YX)
          if ("graph" !== OO.kind) {
            if ("jumping" === OO.kind) {
              const KO = {
                questId: OO.graphQuestId,
                variation: OO.graphVariation,
                completes: OO.graphCompletesOnArrival,
                departedAt: this.now()
              };
              this.storage.setItem(Zp, KO)
            }
          } else {
            const KO = ++this.graphCount;
            pO.e(102).then((() => pO(5583))).then((pO => {
              let {
                default: XO
              } = pO;
              this.YX || KO !== this.graphCount || (this.layout = function(OO, KO, pO) {
                var XO, bK;
                const eO = new OO.graphlib.Graph;
                eO.setGraph({
                  rankdir: "LR",
                  ranksep: 70,
                  nodesep: 14,
                  marginx: 24,
                  marginy: 24
                }), eO.setDefaultEdgeLabel((() => ({})));
                const lO = new Set;
                for (const DO of KO) lO.add(DO.graphQuestId), eO.setNode(DO.graphQuestId, {
                  width: 190,
                  height: 52
                });
                const vK = pO.filter((OO => lO.has(OO.graphFromId) && lO.has(OO.graphToId) && OO.graphFromId !== OO.graphToId)),
                  CO = new Map;
                for (const DO of [...vK].sort(((OO, KO) => Number("awaits" === OO.graphEdgeKind) - Number("awaits" === KO.graphEdgeKind)))) {
                  const OO = qX(DO.graphFromId, DO.graphToId);
                  CO.has(OO) || (CO.set(OO, DO), eO.setEdge(DO.graphFromId, DO.graphToId))
                }
                OO.layout(eO);
                const hO = eO.graph();
                return {
                  width: Math.ceil(null !== (XO = hO.width) && void 0 !== XO ? XO : 0),
                  height: Math.ceil(null !== (bK = hO.height) && void 0 !== bK ? bK : 0),
                  nodes: KO.map((OO => {
                    var KO, pO;
                    const XO = eO.node(OO.graphQuestId);
                    return {
                      node: OO,
                      left: (null !== (KO = XO.x) && void 0 !== KO ? KO : 0) - 95,
                      top: (null !== (pO = XO.y) && void 0 !== pO ? pO : 0) - 26
                    }
                  })),
                  edges: vK.map((OO => {
                    var KO;
                    const pO = CO.get(qX(OO.graphFromId, OO.graphToId)),
                      XO = null !== (KO = eO.edge(pO.graphFromId, pO.graphToId).points) && void 0 !== KO ? KO : [];
                    return {
                      edge: OO,
                      key: `${OO.graphFromId}|${OO.graphToId}|${OO.graphEdgeKind}`,
                      path: Gp(pO.graphFromId === OO.graphFromId ? XO : [...XO].reverse())
                    }
                  })),
                  plans: new Map(KO.map((OO => [OO.graphQuestId, new Set([OO.graphQuestId, ...OO.graphPlanIds])])))
                }
              }(XO, OO.graphNodes, OO.graphEdges), this.show())
            })).catch((OO => {
              console.error("The quest graph could not be laid out", OO)
            }))
          }
      }
      resumeJump(OO) {
        const KO = this.storage.getItem(Zp);
        this.storage.removeItem(Zp), null === KO || KO.variation !== OO || this.now() - KO.departedAt > 6e4 || this.requestArrive(KO.questId, KO.completes)
      }
      setTranslator(OO) {
        this.translate = OO, this.emit()
      }
      dispose() {
        this.layout = null, this.hoveredId = null, super.dispose()
      }
      onClosed() {
        this.hoveredId = null
      }
      isEnabled() {
        return null !== this.layout
      }
      getPlan() {
        var OO, KO;
        return null !== (OO = null === this.hoveredId || null === (KO = this.layout) || void 0 === KO ? void 0 : KO.plans.get(this.hoveredId)) && void 0 !== OO ? OO : new Set
      }
      buildSnapshot() {
        const OO = this.layout;
        if (null === OO) return {
          enabled: !1,
          open: this.open,
          width: 0,
          height: 0,
          nodes: [],
          edges: [],
          planning: !1
        };
        const KO = this.getPlan();
        return {
          enabled: !0,
          open: this.open,
          width: OO.width,
          height: OO.height,
          nodes: OO.nodes.map((OO => {
            let {
              node: pO,
              left: XO,
              top: bK
            } = OO;
            return {
              id: pO.graphQuestId,
              name: this.translate(pO.graphNameKey),
              detail: null === pO.graphGiverName ? pO.graphZoneId : `${pO.graphGiverName} \xb7 ${pO.graphZoneId}`,
              state: pO.graphState,
              left: XO,
              top: bK,
              inPlan: KO.has(pO.graphQuestId),
              hovered: pO.graphQuestId === this.hoveredId
            }
          })),
          edges: OO.edges.map((OO => {
            let {
              edge: pO,
              key: XO,
              path: bK
            } = OO;
            return {
              key: XO,
              kind: pO.graphEdgeKind,
              path: bK,
              inPlan: KO.has(pO.graphFromId) && KO.has(pO.graphToId)
            }
          })),
          planning: KO.size > 0
        }
      }
    }
    var np = pO(35520);
    const Wp = 250,
      tX = 2150,
      kX = -2.8,
      Up = 2.2,
      OX = -27,
      KX = {
        zeta: .34,
        period: .7,
        lead: .1,
        rush: .04
      },
      pX = {
        zeta: .45,
        period: .55,
        delay: .12,
        to: 1.25
      },
      XX = Math.round(50 + 1e3 * (pX.delay + pX.period / 2)),
      bb = "\u16a0\u16a2\u16a6\u16a8\u16b1\u16b2\u16b7\u16b9\u16ba\u16be\u16c1\u16c3\u16c7\u16c8\u16c9\u16ca\u16cf\u16d2\u16d6\u16d7\u16da\u16dc\u16de\u16df",
      eX = Array.from({
        length: 26
      }, ((OO, KO) => {
        const pO = 2.39996 * KO,
          XO = .5 + .618034 * KO % 1 * .23,
          bK = KO % 3 !== 2;
        return {
          rune: bK ? bb[7 * KO % 24] : "",
          style: {
            "--from-x": `calc(var(--sword-size) * ${(Math.cos(pO)*XO).toFixed(3)})`,
            "--from-y": `calc(var(--sword-size) * ${(Math.sin(pO)*XO).toFixed(3)})`,
            "--spin": 40 * (KO % 5 - 2) + "deg",
            "--size": (bK ? 1 + KO % 4 * .2 : .3 + KO % 2 * .15) + "rem",
            "--duration": `${(1.8+7*KO%5*.35).toFixed(2)}s`,
            "--delay": `${(-.83*KO%3).toFixed(2)}s`
          }
        }
      }));

    function lX(OO, KO) {
      return Array.from({
        length: 30 + 3 * OO + (KO ? 10 : 0)
      }, ((OO, KO) => {
        const pO = KO < 4,
          XO = pO ? "#fff" : Math.random() < .25 ? "#ff922b" : "#ffe08a",
          bK = pO ? 7 + 3 * Math.random() : 3.5 + 5 * Math.random(),
          eO = pO ? 2.2 : .6 + Math.random(),
          lO = pO ? .3 : Math.random() < .5 ? .16 : .24,
          vK = pO ? 600 + 100 * Math.random() : 280 + 280 * Math.random();
        return {
          "--c": XO,
          "--angle": `${Math.round(220*(Math.random()-.5)+15)}deg`,
          "--distance": `${bK.toFixed(2)}rem`,
          "--length": `${eO.toFixed(2)}rem`,
          "--width": `${lO}rem`,
          "--duration": `${Math.round(vK)}ms`,
          "--delay": `${Math.round(40*Math.random())}ms`,
          "--fall": `${(1+Math.random()).toFixed(2)}rem`
        }
      }))
    }

    function vb(OO) {
      let {
        zeta: KO,
        period: pO
      } = OO;
      const XO = 2 * Math.PI / pO;
      return {
        w: XO,
        decay: KO * XO / Math.sqrt(1 - KO * KO)
      }
    }
    let CX = !1;

    function hX() {
      if (CX) return;
      CX = !0;
      const OO = document.createElement("style");
      OO.textContent = function() {
        const OO = vb(KX),
          KO = vb(pX),
          pO = KO => Math.exp(-OO.decay * KO) * Math.sin(OO.w * KO),
          XO = pO(Math.atan(OO.w / OO.decay) / OO.w),
          bK = .25,
          eO = 2.15,
          lO = Math.round(215),
          vK = [];
        for (let CO = 0; CO <= lO; CO++) {
          const OO = CO / lO * eO;
          let hO = Math.sin(Math.min(OO, bK) / bK * Math.PI / 2) ** 2,
            DO = 0,
            MO = 1,
            aK = 1 - .2 * hO,
            oO = 1;
          if (OO >= bK) {
            const lO = OO - bK,
              vK = Math.max(0, lO - .05);
            hO = Math.exp(-vK / .05), DO = pO(vK + KX.lead * (1 - Math.exp(-vK / KX.rush))) / XO;
            const CO = vK - pX.delay,
              FO = CO <= 0 ? 0 : 1 - Math.exp(-KO.decay * CO) * (Math.cos(KO.w * CO) + KO.decay / KO.w * Math.sin(KO.w * CO)),
              VO = Math.max(0, (OO - 1.77) / (eO - 1.77));
            MO = (1 + (pX.to - 1) * FO) * (1 + .08 * VO), aK = 1.1 + 1.5 * Math.exp(-lO / .07) + .3 * Math.exp(-(((1e3 * lO - XX) / 100) ** 2)) + .8 * VO, oO = 1 - VO ** 1.5
          }
          const FO = .15 * hO + kX * DO,
            VO = -.1 * hO + Up * DO,
            LO = 3 * hO + OX * DO;
          vK.push(`${(CO/lO*100).toFixed(3)}% { opacity: ${oO.toFixed(3)}; transform: translate(${FO.toFixed(3)}rem, ${VO.toFixed(3)}rem) rotate(${LO.toFixed(2)}deg) scale(${MO.toFixed(3)}); filter: brightness(${aK.toFixed(2)}) drop-shadow(0 0 0.8rem color-mix(in srgb, var(--tier) 55%, transparent)); }`)
        }
        return `@keyframes SkyblockForgeSwordBurst { ${vK.join(" ")} }`
      }(), document.head.append(OO)
    }
    const DX = "skyblockForgeView",
      MX = {
        Blade: "skyblockGame:forgeSlotBlade",
        Guard: "skyblockGame:forgeSlotGuard",
        Handle: "skyblockGame:forgeSlotHandle"
      };
    class ab extends DO {
      constructor(OO, KO, pO, XO, bK) {
        super(OO, pO, XO), this.translate = KO, this.requestForge = bK, this.snapshot = void 0, this.owned = {}, this.coal = 0, this.received = !1, this.awaitingReply = !1, this.pacing = null, this.replyTimeout = null, this.status = null, this.forging = null, this.forgeId = 0, this.arriving = null, this.selected = {
          Blade: null,
          Guard: null,
          Handle: null
        }, this.onForgeStarted = null, this.onPartSelected = null, this.select = (OO, KO) => {
          var pO, XO;
          null !== this.forging || (null !== (pO = this.owned[(0, np.q)(KO, OO)]) && void 0 !== pO ? pO : 0) <= 0 || (this.selected[OO] = this.selected[OO] === KO ? null : KO, this.status = null, null === (XO = this.onPartSelected) || void 0 === XO || XO.call(this), this.emit())
        }, this.forge = OO => {
          var KO, pO;
          const XO = this.selectedParts();
          if (null === XO || this.isPending() || !this.open) return;
          const bK = (0, np.n)(XO);
          if (null === bK || bK.coalCost > this.coal) return;
          const eO = this.preview(bK),
            lO = null !== (KO = null === (pO = this.onForgeStarted) || void 0 === pO ? void 0 : pO.call(this, eO.tier, eO.named, OO)) && void 0 !== KO ? KO : () => {};
          if (this.dropArrival(), OO) {
            const OO = {
              id: ++this.forgeId,
              preview: eO,
              timers: [],
              stopSounds: lO,
              landed: !1,
              reply: null
            };
            OO.timers.push(setTimeout((() => {
              OO.landed = !0, null !== OO.reply && (this.apply(OO.reply), OO.reply = null, this.emit())
            }), Wp), setTimeout((() => {
              this.finishForge(OO)
            }), tX)), this.forging = OO
          }
          this.awaitingReply = !0, this.pacing = setTimeout((() => {
            this.pacing = null, this.emit()
          }), 2500), this.replyTimeout = setTimeout((() => {
            this.replyTimeout = null, this.awaitingReply = !1, this.emit()
          }), 8e3), this.emit(), this.requestForge(XO)
        }, this.snapshot = this.buildSnapshot()
      }
      PX(OO) {
        if (this.received = !0, this.awaitingReply = !1, this.clearReplyTimeout(), "open" === OO.forgeMessageKind) return this.dropForge(), this.apply(OO), this.status = null, void this.show();
        const KO = this.forging;
        if (null !== KO && null !== OO.forgeRefusalKey) this.dropForge();
        else if (null !== KO && !KO.landed) return void(KO.reply = OO);
        this.apply(OO), this.emit()
      }
      apply(OO) {
        if (this.owned = OO.forgeOwnedParts, this.coal = OO.forgeCoalOwned, this.keepSelectionOwned("open" === OO.forgeMessageKind), null !== OO.forgeForgedSwordId) {
          var KO;
          const pO = (0, np.n)(OO.forgeForgedSwordId);
          this.status = {
            tone: "forged",
            key: "skyblockGame:forgeForged",
            params: {
              sword: null !== (KO = null === pO || void 0 === pO ? void 0 : pO.displayName) && void 0 !== KO ? KO : ""
            }
          }
        } else null !== OO.forgeRefusalKey && (this.status = {
          tone: "refused",
          key: OO.forgeRefusalKey,
          params: {}
        })
      }
      setTranslator(OO) {
        this.translate = OO, this.emit()
      }
      isEnabled() {
        return this.received
      }
      onClosed() {
        this.dropForge(), this.dropArrival(), this.status = null, this.awaitingReply = !1, this.clearReplyTimeout()
      }
      finishForge(OO) {
        var KO;
        this.forging = null;
        const pO = this.selectedParts(),
          XO = setTimeout((() => {
            this.arriving = null, this.emit()
          }), 400);
        this.arriving = {
          id: OO.id,
          sameSword: null !== pO && (null === (KO = (0, np.n)(pO)) || void 0 === KO ? void 0 : KO.displayName) === OO.preview.name,
          timer: XO
        }, this.emit()
      }
      dropForge() {
        const OO = this.forging;
        if (null !== OO) {
          this.forging = null;
          for (const KO of OO.timers) clearTimeout(KO);
          OO.stopSounds(), null !== OO.reply && this.apply(OO.reply)
        }
      }
      dropArrival() {
        null !== this.arriving && (clearTimeout(this.arriving.timer), this.arriving = null)
      }
      isPending() {
        return this.awaitingReply || null !== this.pacing
      }
      clearReplyTimeout() {
        null !== this.replyTimeout && (clearTimeout(this.replyTimeout), this.replyTimeout = null)
      }
      buildSnapshot() {
        var OO, KO, pO;
        const XO = this.selectedParts(),
          bK = null === XO ? null : (0, np.n)(XO),
          eO = null !== (OO = null === (KO = this.forging) || void 0 === KO ? void 0 : KO.preview) && void 0 !== OO ? OO : null === bK ? null : this.preview(bK);
        return {
          enabled: this.received,
          open: this.open,
          slots: np.j.map((OO => ({
            kind: OO,
            label: this.translate(MX[OO]),
            parts: this.partsFor(OO)
          }))),
          coalOwned: this.coal,
          preview: eO,
          unformedSword: np.h[null !== (pO = this.selected.Blade) && void 0 !== pO ? pO : "Iron"].baseSword,
          anyParts: Object.values(this.owned).some((OO => OO > 0)),
          canForge: null !== eO && !eO.coalShort && !this.isPending(),
          status: null === this.status ? null : {
            tone: this.status.tone,
            text: this.translate(this.status.key, this.status.params)
          },
          forging: null === this.forging ? null : {
            id: this.forging.id,
            preview: this.forging.preview
          },
          arriving: null === this.arriving ? null : {
            id: this.arriving.id,
            sameSword: this.arriving.sameSword
          }
        }
      }
      preview(OO) {
        return {
          name: OO.displayName,
          lore: OO.lore,
          baseSword: OO.baseSword,
          enchantmentTier: OO.enchantmentTier,
          tier: Number(OO.enchantmentTier.slice(-1)),
          named: OO.named,
          stats: this.stats(OO),
          effects: OO.effects,
          coalCost: OO.coalCost,
          coalShort: null === this.forging && OO.coalCost > this.coal
        }
      }
      partsFor(OO) {
        const KO = [];
        for (const XO of np.e) {
          var pO;
          const bK = (0, np.q)(XO, OO),
            eO = null !== (pO = this.owned[bK]) && void 0 !== pO ? pO : 0;
          eO > 0 && KO.push({
            material: XO,
            itemName: bK,
            owned: eO,
            selected: this.selected[OO] === XO,
            placeholder: !1
          })
        }
        if (0 === KO.length) {
          const pO = np.e[0];
          KO.push({
            material: pO,
            itemName: (0, np.q)(pO, OO),
            owned: 0,
            selected: !1,
            placeholder: !0
          })
        }
        return KO
      }
      stats(OO) {
        const KO = [{
          label: this.translate("skyblockGame:forgeStatPower"),
          value: `\xd7${OO.powerMultiplier.toFixed(2)}`,
          better: OO.powerMultiplier > 1
        }, {
          label: this.translate("skyblockGame:forgeStatDamage"),
          value: `\xd7${OO.damageMultiplier.toFixed(2)}`,
          better: OO.damageMultiplier > 1
        }, {
          label: this.translate("skyblockGame:forgeStatSpeed"),
          value: `\xd7${(1/OO.cooldownMultiplier).toFixed(2)}`,
          better: OO.cooldownMultiplier < 1
        }, {
          label: this.translate("skyblockGame:forgeStatKnockback"),
          value: `\xd7${OO.knockbackMultiplier.toFixed(2)}`,
          better: OO.knockbackMultiplier > 1
        }];
        return OO.reachBonus > 0 && KO.push({
          label: this.translate("skyblockGame:forgeStatReach"),
          value: `+${OO.reachBonus.toFixed(1)}`,
          better: !0
        }), OO.damageReduction > 0 && KO.push({
          label: this.translate("skyblockGame:forgeStatDefence"),
          value: `${Math.round(100*OO.damageReduction)}%`,
          better: !0
        }), KO
      }
      selectedParts() {
        const {
          Blade: OO,
          Guard: KO,
          Handle: pO
        } = this.selected;
        return null === OO || null === KO || null === pO ? null : {
          blade: OO,
          guard: KO,
          handle: pO
        }
      }
      keepSelectionOwned(OO) {
        for (const pO of np.j) {
          var KO;
          const XO = this.selected[pO];
          if (null !== XO && (null !== (KO = this.owned[(0, np.q)(XO, pO)]) && void 0 !== KO ? KO : 0) > 0) continue;
          if (!OO) {
            this.selected[pO] = null;
            continue
          }
          const bK = [...np.e].reverse().find((OO => {
            var KO;
            return (null !== (KO = this.owned[(0, np.q)(OO, pO)]) && void 0 !== KO ? KO : 0) > 0
          }));
          this.selected[pO] = null !== bK && void 0 !== bK ? bK : null
        }
      }
      dispose() {
        this.received = !1, this.dropForge(), this.dropArrival(), this.clearReplyTimeout(), null !== this.pacing && (clearTimeout(this.pacing), this.pacing = null), super.dispose()
      }
    }
    const oX = "skyblockSmugglerView",
      FX = {
        "Red Firecracker Pebble": "skyblockGame:mortarStrike",
        "Purple Firecracker Pebble": "skyblockGame:interdimensionalStrike"
      };
    class VX extends DO {
      constructor(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : Date.now;
        super(OO, pO, XO), this.translate = KO, this.requestBuy = bK, this.now = eO, this.snapshot = void 0, this.day = 0, this.deals = [], this.rivets = 0, this.crests = 0, this.soldOut = new Set, this.rotatesAtMs = 0, this.received = !1, this.awaitingReply = !1, this.pacing = null, this.replyTimeout = null, this.countdown = null, this.status = null, this.boughtSlot = null, this.boughtCount = 0, this.itemName = OO => OO, this.onBought = null, this.buy = OO => {
          const KO = this.deals[OO];
          void 0 !== KO && !this.isPending() && this.open && !this.soldOut.has(OO) && this.canAfford(KO) && (this.awaitingReply = !0, this.pacing = setTimeout((() => {
            this.pacing = null, this.emit()
          }), 2500), this.replyTimeout = setTimeout((() => {
            this.replyTimeout = null, this.awaitingReply = !1, this.emit()
          }), 8e3), this.emit(), this.requestBuy(this.day, OO))
        }, this.snapshot = this.buildSnapshot()
      }
      PX(OO) {
        if (this.received = !0, this.day = OO.smugglerDay, this.deals = OO.smugglerDeals, this.rivets = OO.smugglerRivetsOwned, this.crests = OO.smugglerCrestsOwned, this.soldOut = new Set(OO.smugglerSoldOutSlots), this.rotatesAtMs = this.now() + OO.smugglerRotatesInMs, this.awaitingReply = !1, this.clearReplyTimeout(), "open" === OO.smugglerMessageKind) return this.status = null, this.boughtSlot = null, this.show(), void this.startCountdown();
        if (this.boughtSlot = OO.smugglerBoughtSlot, null !== OO.smugglerBoughtSlot) {
          var KO, pO;
          const XO = this.deals[OO.smugglerBoughtSlot];
          this.status = {
            tone: "bought",
            key: "skyblockGame:smugglerBought",
            params: {
              item: void 0 === XO ? "" : this.dealName(XO),
              amount: String(null !== (KO = null === XO || void 0 === XO ? void 0 : XO.smugglerDealAmount) && void 0 !== KO ? KO : 0)
            }
          }, this.boughtCount++, null === (pO = this.onBought) || void 0 === pO || pO.call(this)
        } else null !== OO.smugglerRefusalKey && (this.status = {
          tone: "refused",
          key: OO.smugglerRefusalKey,
          params: {}
        });
        this.emit()
      }
      setTranslator(OO, KO, pO) {
        this.translate = OO, void 0 !== pO && (this.itemName = pO), this.emit()
      }
      isEnabled() {
        return this.received
      }
      onClosed() {
        this.status = null, this.boughtSlot = null, this.awaitingReply = !1, this.clearReplyTimeout(), this.stopCountdown(), this.boughtCount = 0
      }
      dealName(OO) {
        if (null !== OO.smugglerDealUniqueName) return OO.smugglerDealUniqueName;
        const KO = FX[OO.smugglerDealItem];
        return void 0 === KO ? this.itemName(OO.smugglerDealItem) : this.translate(KO)
      }
      canAfford(OO) {
        return OO.smugglerDealRivets <= this.rivets && OO.smugglerDealCrests <= this.crests
      }
      isPending() {
        return this.awaitingReply || null !== this.pacing
      }
      startCountdown() {
        this.stopCountdown(), this.countdown = setInterval((() => {
          this.emit()
        }), 15e3)
      }
      stopCountdown() {
        null !== this.countdown && (clearInterval(this.countdown), this.countdown = null)
      }
      clearReplyTimeout() {
        null !== this.replyTimeout && (clearTimeout(this.replyTimeout), this.replyTimeout = null)
      }
      rotatesText() {
        const OO = Math.ceil((this.rotatesAtMs - this.now()) / 6e4);
        return OO <= 0 ? this.translate("skyblockGame:smugglerRotatesSoon") : OO < 60 ? this.translate("skyblockGame:smugglerRotatesMinutes", {
          minutes: String(OO)
        }) : this.translate("skyblockGame:smugglerRotatesHours", {
          hours: String(Math.floor(OO / 60)),
          minutes: String(OO % 60)
        })
      }
      buildSnapshot() {
        return {
          enabled: this.received,
          open: this.open,
          deals: this.deals.map(((OO, KO) => ({
            slot: KO,
            itemName: OO.smugglerDealItem,
            displayName: this.dealName(OO),
            enchantmentTier: OO.smugglerDealEnchantmentTier,
            amount: OO.smugglerDealAmount,
            rivets: OO.smugglerDealRivets,
            crests: OO.smugglerDealCrests,
            affordable: this.canAfford(OO),
            soldOut: this.soldOut.has(KO),
            justBought: this.boughtSlot === KO
          }))),
          rivetsOwned: this.rivets,
          crestsOwned: this.crests,
          rotatesText: this.received ? this.rotatesText() : "",
          pending: this.isPending(),
          status: null === this.status ? null : {
            tone: this.status.tone,
            text: this.translate(this.status.key, this.status.params)
          },
          boughtCount: this.boughtCount
        }
      }
      dispose() {
        this.received = !1, this.clearReplyTimeout(), this.stopCountdown(), null !== this.pacing && (clearTimeout(this.pacing), this.pacing = null), super.dispose()
      }
    }
    const LX = "skyblockPassageView",
      QX = {
        new: "skyblockGame:passagePhaseNew",
        waxing: "skyblockGame:passagePhaseWaxing",
        full: "skyblockGame:passagePhaseFull",
        waning: "skyblockGame:passagePhaseWaning"
      };

    function zb(OO, KO) {
      return OO(QX[KO])
    }

    function AX(OO, KO, pO, XO) {
      const bK = Math.ceil((pO - XO) / 864e5),
        eO = zb(OO, KO);
      return bK > 1 ? OO("skyblockGame:passageNextDays", {
        phase: eO,
        days: String(bK)
      }) : OO("skyblockGame:passageNextSoon", {
        phase: eO
      })
    }
    class fX extends DO {
      constructor(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : Date.now;
        super(OO, pO, XO), this.translate = KO, this.now = bK, this.snapshot = void 0, this.message = null, this.receivedAtMs = 0, this.itemName = OO => OO, this.toggle = () => {
          this.open ? this.dismiss() : this.show()
        }, this.snapshot = this.buildSnapshot()
      }
      PX(OO) {
        this.message = OO, this.receivedAtMs = this.now(), this.emit()
      }
      setTranslator(OO, KO, pO) {
        this.translate = OO, void 0 !== pO && (this.itemName = pO), this.emit()
      }
      isEnabled() {
        return null !== this.message
      }
      describe(OO) {
        return {
          itemName: OO.passageFish,
          displayName: this.itemName(OO.passageFish),
          where: this.translate("skyblockGame:passageInWater", {
            water: this.translate(OO.passageFishWaterKey)
          })
        }
      }
      buildSnapshot() {
        const OO = this.message;
        return null === OO ? {
          enabled: !1,
          open: !1,
          phase: "new",
          phaseName: "",
          visitors: [],
          resting: null,
          nextPhase: "waxing",
          next: ""
        } : {
          enabled: !0,
          open: this.open,
          phase: OO.passagePhase,
          phaseName: zb(this.translate, OO.passagePhase),
          visitors: OO.passageVisitors.map((OO => this.describe(OO))),
          resting: this.describe(OO.passageResting),
          nextPhase: OO.passageNextPhase,
          next: AX(this.translate, OO.passageNextPhase, OO.passageTurnsInMs, this.now() - this.receivedAtMs)
        }
      }
      dispose() {
        this.message = null, super.dispose()
      }
    }
    class dX {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 4,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 12e3,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1e3,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : Date.now;
        this.limit = OO, this.windowMs = KO, this.spacingMs = pO, this.now = XO, this.sent = [], this.lastSentAt = -1 / 0, this.timer = null, this.listeners = new Set, this.priority = new Set
      }
      isPacing() {
        return !this.canSendPriority() || this.isPriorityWaiting()
      }
      canSendPriority() {
        return this.prune(), this.sent.length < this.limit && this.now() - this.lastSentAt >= this.spacingMs
      }
      tryStart() {
        for (const OO of this.priority) OO.flush();
        return !this.isPacing() && (this.start(), !0)
      }
      start() {
        this.prune();
        const OO = this.now();
        this.sent.push(OO), this.lastSentAt = OO, this.schedule(), this.notify()
      }
      addPriority(OO) {
        return this.priority.add(OO), () => {
          this.priority.delete(OO)
        }
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      dispose() {
        this.clearTimer(), this.sent = [], this.listeners.clear(), this.priority.clear()
      }
      isPriorityWaiting() {
        for (const OO of this.priority)
          if (OO.waiting()) return !0;
        return !1
      }
      prune() {
        const OO = this.now() - this.windowMs;
        for (; this.sent.length > 0 && this.sent[0] <= OO;) this.sent.shift()
      }
      schedule() {
        this.clearTimer();
        const OO = this.now(),
          KO = this.lastSentAt + this.spacingMs,
          pO = Math.min(KO > OO ? KO : 1 / 0, this.sent.length > 0 ? this.sent[0] + this.windowMs : 1 / 0);
        pO !== 1 / 0 && (this.timer = setTimeout((() => {
          this.timer = null, this.prune(), this.schedule(), this.notify()
        }), Math.max(0, pO - OO)))
      }
      notify() {
        for (const OO of this.listeners) OO()
      }
      clearTimer() {
        null !== this.timer && (clearTimeout(this.timer), this.timer = null)
      }
    }
    const TX = "skyblockKeepersChairView";
    class NX extends DO {
      constructor(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : Date.now,
          lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : new dX;
        super(OO, pO, XO), this.translate = KO, this.requestAim = bK, this.now = eO, this.pacer = lO, this.snapshot = void 0, this.islands = [], this.favoured = null, this.received = !1, this.awaitingReply = !1, this.unsubscribePacer = void 0, this.replyTimeout = null, this.status = null, this.aimedCount = 0, this.passage = null, this.passageReceivedAtMs = 0, this.atChair = !0, this.itemName = OO => OO, this.aim = OO => {
          !this.awaitingReply && this.open && this.atChair && OO !== this.favoured && (null === OO || this.islands.some((KO => KO.keepersChairIslandId === OO && KO.keepersChairIslandRelit))) && this.pacer.tryStart() && (this.awaitingReply = !0, this.replyTimeout = setTimeout((() => {
            this.replyTimeout = null, this.awaitingReply = !1, this.emit()
          }), 8e3), this.emit(), this.requestAim(null !== OO && void 0 !== OO ? OO : "none"))
        }, this.snapshot = this.buildSnapshot(), this.unsubscribePacer = lO.subscribe((() => {
          this.emit()
        }))
      }
      PX(OO) {
        var KO, pO;
        this.received = !0;
        const XO = this.favoured,
          bK = this.atChair;
        var eO;
        return this.islands = OO.keepersChairIslands, this.favoured = OO.keepersChairFavoured, this.passage = null !== (KO = OO.keepersChairPassage) && void 0 !== KO ? KO : null, this.passageReceivedAtMs = this.now(), this.atChair = null === (pO = OO.keepersChairAtChair) || void 0 === pO || pO, "place" === OO.keepersChairMessageKind ? (!bK && this.atChair && "refused" === (null === (eO = this.status) || void 0 === eO ? void 0 : eO.tone) && (this.status = null), void this.emit()) : (this.awaitingReply = !1, this.clearReplyTimeout(), "open" === OO.keepersChairMessageKind ? (this.status = null, void this.show()) : void(this.open ? (null !== OO.keepersChairRefusalKey ? this.status = {
          tone: "refused",
          key: OO.keepersChairRefusalKey,
          island: null
        } : this.favoured !== XO && (this.status = null === this.favoured ? {
          tone: "aimed",
          key: "skyblockGame:keepersChairRestedStatus",
          island: null
        } : {
          tone: "aimed",
          key: "skyblockGame:keepersChairAimedStatus",
          island: this.favoured
        }, this.aimedCount++), this.emit()) : this.emit()))
      }
      isAtChair() {
        return this.atChair
      }
      receivePassage(OO) {
        this.received && (this.passage = OO, this.passageReceivedAtMs = this.now(), this.emit())
      }
      setTranslator(OO, KO, pO) {
        this.translate = OO, void 0 !== pO && (this.itemName = pO), this.emit()
      }
      isEnabled() {
        return this.received
      }
      onClosed() {
        this.status = null, this.awaitingReply = !1, this.clearReplyTimeout(), this.aimedCount = 0
      }
      isPending() {
        return this.awaitingReply || this.pacer.isPacing()
      }
      clearReplyTimeout() {
        null !== this.replyTimeout && (clearTimeout(this.replyTimeout), this.replyTimeout = null)
      }
      islandName(OO) {
        const KO = this.islands.find((KO => KO.keepersChairIslandId === OO));
        return void 0 === KO ? OO : this.translate(KO.keepersChairIslandNameKey)
      }
      buildSnapshot() {
        const OO = this.atChair ? this.status : {
            tone: "refused",
            key: "skyblockGame:keepersChairTooFar",
            island: null
          },
          KO = this.passage;
        return {
          enabled: this.received,
          open: this.open,
          islands: this.islands.map((OO => {
            const KO = OO.keepersChairFeaturedFish;
            return {
              id: OO.keepersChairIslandId,
              name: this.translate(OO.keepersChairIslandNameKey),
              relit: OO.keepersChairIslandRelit,
              featuredFish: null === KO ? null : {
                itemName: KO,
                displayName: this.itemName(KO)
              },
              favoured: OO.keepersChairIslandId === this.favoured
            }
          })),
          aimed: null !== this.favoured,
          canAim: this.atChair && !this.isPending(),
          status: null === OO ? null : {
            tone: OO.tone,
            text: this.translate(OO.key, null === OO.island ? void 0 : {
              island: this.islandName(OO.island)
            })
          },
          aimedCount: this.aimedCount,
          almanac: null === KO ? null : {
            phase: KO.keepersChairPassagePhase,
            phaseName: zb(this.translate, KO.keepersChairPassagePhase),
            nextPhase: KO.keepersChairPassageNextPhase,
            next: AX(this.translate, KO.keepersChairPassageNextPhase, KO.keepersChairPassageTurnsInMs, this.now() - this.passageReceivedAtMs)
          }
        }
      }
      dispose() {
        this.received = !1, this.passage = null, this.atChair = !0, this.clearReplyTimeout(), this.unsubscribePacer(), super.dispose()
      }
    }
    const IX = "skyblockReachLogView",
      yb = ["skyblockGame:reachLogBronze", "skyblockGame:reachLogSilver", "skyblockGame:reachLogGold"],
      gb = "Caught Fish",
      uX = [1, 2, 4];

    function EX(OO, KO) {
      return OO.map((OO => ({
        ...OO,
        reachLogPageFish: OO.reachLogPageFish.map((OO => ({
          ...OO,
          reachLogFishFresh: KO(OO)
        })))
      })))
    }
    class jb extends DO {
      constructor(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : new dX;
        super(OO, pO, XO), this.translate = KO, this.requestOpen = bK, this.pacer = eO, this.snapshot = void 0, this.pages = [], this.pagesCurrent = !1, this.serverFresh = 0, this.passagePhase = null, this.heldFresh = new Set, this.shown = !1, this.received = !1, this.selected = null, this.letGoShown = !1, this.awaitingReply = !1, this.replyTimeout = null, this.newsToken = 0, this.news = !1, this.pageViews = null, this.newsTimeout = null, this.unsubscribePacer = void 0, this.itemName = OO => OO, this.ask = () => {
          !this.received || this.open || this.awaitingReply || (this.pagesCurrent && 0 === this.serverFresh ? this.showPages() : this.pacer.tryStart() && (this.awaitingReply = !0, this.replyTimeout = setTimeout((() => {
            this.replyTimeout = null, this.awaitingReply = !1, this.emit()
          }), 8e3), this.emit(), this.requestOpen()))
        }, this.selectPage = OO => {
          this.pages.some((KO => KO.reachLogIslandId === OO)) && (this.selected = OO, this.emit())
        }, this.snapshot = this.buildSnapshot(), this.unsubscribePacer = eO.subscribe((() => {
          this.emit()
        }))
      }
      PX(OO) {
        if (this.received = !0, "status" === OO.reachLogMessageKind) return !0 === OO.reachLogNews && this.markNews(), this.serverFresh = OO.reachLogFreshCount, this.pagesCurrent = !1, void this.emit();
        const KO = this.awaitingReply;
        if (this.awaitingReply = !1, this.clearReplyTimeout(), "unavailable" !== OO.reachLogMessageKind)
          if (this.pageViews = null, this.pages = EX(OO.reachLogPages, (OO => OO.reachLogFishFresh || this.heldFresh.has(OO.reachLogFishItem))), this.letGoShown = OO.reachLogLetGoRibbonShown, this.pagesCurrent = !0, this.serverFresh = 0, KO) this.showPages();
          else {
            for (const OO of this.pages)
              for (const KO of OO.reachLogPageFish) KO.reachLogFishFresh && this.heldFresh.add(KO.reachLogFishItem);
            this.emit()
          }
        else this.emit()
      }
      setTranslator(OO, KO, pO) {
        this.translate = OO, this.pageViews = null, void 0 !== pO && (this.itemName = pO), this.emit()
      }
      isEnabled() {
        return this.received
      }
      onClosed() {
        this.shown && (this.shown = !1, this.pageViews = null, this.pages = EX(this.pages, (() => !1)))
      }
      showPages() {
        this.heldFresh.clear(), this.selected = this.pickPage(), this.show(), this.shown = this.isOpen()
      }
      pickPage() {
        var OO, KO, pO, XO;
        const bK = this.pages.find((OO => OO.reachLogPageFish.some((OO => OO.reachLogFishFresh))));
        if (void 0 !== bK) return bK.reachLogIslandId;
        if (null !== this.selected && this.pages.some((OO => OO.reachLogIslandId === this.selected))) return this.selected;
        return null !== (OO = null !== (KO = null === (pO = this.pages.filter((OO => OO.reachLogIslandAwake)).at(-1)) || void 0 === pO ? void 0 : pO.reachLogIslandId) && void 0 !== KO ? KO : null === (XO = this.pages[0]) || void 0 === XO ? void 0 : XO.reachLogIslandId) && void 0 !== OO ? OO : null
      }
      markNews() {
        this.newsToken++, this.news = !0, this.clearNewsTimeout(), this.newsTimeout = setTimeout((() => {
          this.newsTimeout = null, this.news = !1, this.emit()
        }), 1200)
      }
      clearNewsTimeout() {
        null !== this.newsTimeout && (clearTimeout(this.newsTimeout), this.newsTimeout = null)
      }
      clearReplyTimeout() {
        null !== this.replyTimeout && (clearTimeout(this.replyTimeout), this.replyTimeout = null)
      }
      buildSnapshot() {
        return {
          enabled: this.received,
          open: this.open,
          pending: this.awaitingReply || this.pacer.isPacing(),
          freshCount: this.serverFresh + this.heldFresh.size,
          news: this.news,
          newsToken: this.newsToken,
          selected: this.selected,
          letGoShown: this.letGoShown,
          pages: this.pageViews ??= this.buildPages()
        }
      }
      buildPages() {
        return this.pages.map((OO => {
          var KO;
          return {
            id: OO.reachLogIslandId,
            name: this.translate(OO.reachLogIslandNameKey),
            awake: OO.reachLogIslandAwake,
            gold: OO.reachLogPageGold,
            caught: OO.reachLogPageFish.filter((OO => OO.reachLogFishCaught && !OO.reachLogFishVisitor)).length,
            total: OO.reachLogPageFish.filter((OO => !OO.reachLogFishVisitor)).length,
            fish: OO.reachLogPageFish.map((OO => {
              const KO = OO.reachLogFishBestKg;
              return {
                itemName: OO.reachLogFishItem,
                name: OO.reachLogFishCaught ? this.itemName(OO.reachLogFishItem) : this.translate("skyblockGame:reachLogUnknownFish"),
                caught: OO.reachLogFishCaught,
                chance: this.translate("skyblockGame:reachLogChance", {
                  count: Math.max(1, Math.round(1 / OO.reachLogFishChance))
                }),
                best: OO.reachLogFishCaught ? null === KO ? this.translate("skyblockGame:reachLogNoSize") : this.translate("skyblockGame:reachLogBest", {
                  kg: KO.toFixed(1)
                }) : this.translate("skyblockGame:reachLogNotCaught"),
                marks: OO.reachLogFishMarks,
                ribbons: uX.map((KO => 0 !== (OO.reachLogFishRibbons & KO))),
                glimmer: 0 !== (8 & OO.reachLogFishRibbons),
                halo: 0 !== (32 & OO.reachLogFishRibbons),
                fresh: OO.reachLogFishFresh,
                visitor: OO.reachLogFishVisitor
              }
            })),
            returner: this.buildReturner(null !== (KO = OO.reachLogPageReturner) && void 0 !== KO ? KO : null)
          }
        }))
      }
      buildReturner(OO) {
        return null === OO ? null : {
          itemName: OO.reachLogReturnerFishItem,
          line: this.translate(OO.reachLogReturnerLineKey, {
            name: this.translate(OO.reachLogReturnerNameKey),
            trinket: this.translate(OO.reachLogReturnerTrinketKey)
          }),
          back: OO.reachLogReturnerBack
        }
      }
      receivePassagePhase(OO) {
        null !== this.passagePhase && this.passagePhase !== OO && (this.pagesCurrent = !1), this.passagePhase = OO
      }
      dispose() {
        this.received = !1, this.pagesCurrent = !1, this.passagePhase = null, this.heldFresh.clear(), this.clearReplyTimeout(), this.clearNewsTimeout(), this.unsubscribePacer(), super.dispose()
      }
    }
    const YX = "skyblockLampLightView";
    class wX {
      constructor(OO, KO, pO, XO) {
        this.pl = OO, this.translate = KO, this.requestCommand = pO, this.pacer = XO, this.snapshot = void 0, this.message = null, this.shop = null, this.situation = "open", this.awaitingTag = null, this.awaitingOff = !1, this.offQueued = !1, this.offTag = null, this.lastTag = 0, this.replyTimeout = null, this.offTimeout = null, this.refusalKey = null, this.gainedCount = 0, this.lastGained = 0, this.atChair = !0, this.sparkle = null, this.locale = "en", this.YX = !1, this.unsubscribePacer = void 0, this.removePriority = void 0, this.getSnapshot = () => this.snapshot, this.setRelease = OO => {
          OO ? this.send("release on") : this.awaitingOff || (this.awaitingOff = !0, this.offQueued = !0, this.sendQueuedOff(), this.emit())
        }, this.buy = OO => {
          this.send(`buy ${OO}`)
        }, this.socket = OO => {
          this.send(`socket ${null!==OO&&void 0!==OO?OO:wO}`)
        }, this.wearTint = OO => {
          this.send(`tint ${null!==OO&&void 0!==OO?OO:wO}`)
        }, this.setSituation = OO => {
          this.situation = OO, this.emit()
        }, this.snapshot = this.buildSnapshot(), this.unsubscribePacer = XO.subscribe((() => {
          this.sendQueuedOff(), this.emit()
        })), this.removePriority = XO.addPriority({
          waiting: () => this.offQueued,
          flush: () => {
            this.sendQueuedOff()
          }
        })
      }
      PX(OO) {
        if (this.message = OO, null !== OO.lampLightShop && (this.shop = OO.lampLightShop), "open" === OO.lampLightKind && (this.refusalKey = null), "reply" === OO.lampLightKind) {
          var KO;
          const bK = null !== (KO = OO.lampLightReplyTag) && void 0 !== KO ? KO : null,
            eO = null !== bK && bK === this.offTag;
          var pO, XO;
          if (eO ? this.settleOff() : null !== bK && bK !== this.awaitingTag || this.settleReply(), this.refusalKey = OO.lampLightRefusalKey, null !== OO.lampLightBought && !eO) this.sparkle = {
            id: OO.lampLightBought,
            count: (null !== (pO = null === (XO = this.sparkle) || void 0 === XO ? void 0 : XO.count) && void 0 !== pO ? pO : 0) + 1
          }
        }
        OO.lampLightReleasing || (this.settleOff(), this.gainedCount = 0), "released" === OO.lampLightKind && (this.lastGained = OO.lampLightGained, this.gainedCount++), this.emit()
      }
      setAtChair(OO) {
        OO !== this.atChair && (this.atChair = OO, OO && (this.refusalKey = null), this.emit())
      }
      setTranslator(OO, KO) {
        this.translate = OO, this.locale = null !== KO && void 0 !== KO ? KO : this.locale, this.emit()
      }
      onChairClosed() {
        this.refusalKey = null, this.emit()
      }
      dispose() {
        this.clearReplyTimeout(), this.settleOff(), this.unsubscribePacer(), this.removePriority(), this.message = null, this.shop = null, this.emit(), this.YX = !0
      }
      send(OO) {
        var KO;
        if (null !== this.awaitingTag || "ready" !== (null === (KO = this.message) || void 0 === KO ? void 0 : KO.lampLightStatus) || !this.atChair) return;
        if (this.sendQueuedOff(), this.offQueued || !this.pacer.tryStart()) return;
        const pO = this.nextTag();
        this.awaitingTag = pO, this.replyTimeout = setTimeout((() => {
          this.replyTimeout = null, this.awaitingTag = null, this.emit()
        }), 8e3), this.requestCommand(`lamplight-${OO} ${pO}`), this.emit()
      }
      sendQueuedOff() {
        if (!this.offQueued || !this.pacer.canSendPriority()) return;
        this.offQueued = !1;
        const OO = this.nextTag();
        this.offTag = OO, this.pacer.start(), this.offTimeout = setTimeout((() => {
          this.offTimeout = null, this.awaitingOff = !1, this.offTag = null, this.emit()
        }), 8e3), this.requestCommand(`lamplight-release off ${OO}`)
      }
      nextTag() {
        return this.lastTag = this.lastTag % 999999 + 1, this.lastTag
      }
      settleOff() {
        this.awaitingOff = !1, this.offQueued = !1, this.offTag = null, null !== this.offTimeout && (clearTimeout(this.offTimeout), this.offTimeout = null)
      }
      settleReply() {
        this.awaitingTag = null, this.clearReplyTimeout()
      }
      isPending() {
        return null !== this.awaitingTag || this.offQueued || this.pacer.isPacing()
      }
      clearReplyTimeout() {
        null !== this.replyTimeout && (clearTimeout(this.replyTimeout), this.replyTimeout = null)
      }
      emit() {
        this.YX || (this.snapshot = this.buildSnapshot(), this.pl(this.snapshot))
      }
      formatLight(OO) {
        return Math.floor(OO).toLocaleString(this.locale)
      }
      formatPercent(OO) {
        const KO = 100 * OO;
        return KO >= 10 ? Math.round(KO).toLocaleString(this.locale) : KO.toLocaleString(this.locale, {
          maximumFractionDigits: 1
        })
      }
      formatOdds(OO, KO) {
        if ("bite" === OO) return this.translate("skyblockGame:lampLightBite", {
          seconds: (KO.lampLightBiteMs / 1e3).toLocaleString(this.locale, {
            maximumFractionDigits: 1
          })
        });
        if ("rare" === OO) return this.translate("skyblockGame:lampLightRare", {
          percent: this.formatPercent(KO.lampLightRareChance)
        });
        if ("notice" === OO) return null === KO.lampLightNoticeChance ? null : this.translate("skyblockGame:lampLightNotice", {
          percent: this.formatPercent(KO.lampLightNoticeChance)
        });
        const pO = "meter" === OO ? KO.lampLightMeterCatches : KO.lampLightBloomCatches;
        return null === pO ? null : this.translate("meter" === OO ? "skyblockGame:lampLightMeter" : "skyblockGame:lampLightBloomLasts", {
          catches: String(Math.round(pO))
        })
      }
      oddsLines(OO, KO) {
        const pO = (OO, KO) => {
            var pO;
            return null !== (pO = {
              bite: KO.lampLightBiteMs,
              rare: KO.lampLightRareChance,
              meter: KO.lampLightMeterCatches,
              bloom: KO.lampLightBloomCatches,
              notice: KO.lampLightNoticeChance
            } [OO]) && void 0 !== pO ? pO : 0
          },
          XO = {
            bite: !0,
            rare: !1,
            meter: !0,
            bloom: !1,
            notice: !1
          },
          bK = [];
        for (const eO of ["bite", "rare", "meter", "bloom", "notice"]) {
          const lO = this.formatOdds(eO, OO),
            vK = this.formatOdds(eO, KO);
          if (null === lO || null === vK || "bite" !== eO && "rare" !== eO && lO === vK) continue;
          const CO = pO(eO, KO) - pO(eO, OO),
            hO = XO[eO] ? CO < 0 : CO > 0;
          bK.push({
            label: eO,
            before: lO,
            after: vK,
            tone: lO === vK ? "same" : hO ? "better" : "worse"
          })
        }
        return bK
      }
      charmView(OO, KO, pO) {
        const XO = OO.lampLightCharmId.charAt(0).toUpperCase() + OO.lampLightCharmId.slice(1),
          bK = "bloom" === this.situation;
        return {
          id: OO.lampLightCharmId,
          name: this.translate(`skyblockGame:lampLightCharm${XO}`),
          effect: this.translate(`skyblockGame:lampLightCharm${XO}Effect`),
          cost: this.translate("skyblockGame:lampLightCost", {
            light: this.formatLight(OO.lampLightCharmCost)
          }),
          owned: OO.lampLightCharmOwned,
          affordable: pO >= OO.lampLightCharmCost,
          socketed: KO.lampLightSocketed === OO.lampLightCharmId,
          lines: this.oddsLines(bK ? KO.lampLightBareBloom : KO.lampLightBareOpen, bK ? OO.lampLightCharmBloom : OO.lampLightCharmOpen)
        }
      }
      buildSnapshot() {
        var OO, KO, pO, XO;
        const bK = this.message,
          eO = "ready" === (null === bK || void 0 === bK ? void 0 : bK.lampLightStatus) ? this.shop : null,
          lO = null !== (OO = null === bK || void 0 === bK ? void 0 : bK.lampLightBalance) && void 0 !== OO ? OO : 0,
          vK = this.atChair,
          CO = "loading" === (null === bK || void 0 === bK ? void 0 : bK.lampLightStatus) ? "skyblockGame:lampLightLoading" : "unreadable" === (null === bK || void 0 === bK ? void 0 : bK.lampLightStatus) ? "skyblockGame:lampLightUnreadable" : null,
          hO = "ready" !== (null === bK || void 0 === bK ? void 0 : bK.lampLightStatus) || vK ? null !== (KO = this.refusalKey) && void 0 !== KO ? KO : CO : "skyblockGame:lampLightTooFar";
        return {
          enabled: null !== bK && "locked" !== bK.lampLightStatus,
          status: null !== (pO = null === bK || void 0 === bK ? void 0 : bK.lampLightStatus) && void 0 !== pO ? pO : "loading",
          balance: this.translate("skyblockGame:lampLightBalance", {
            light: this.formatLight(lO)
          }),
          releasing: null !== (XO = null === bK || void 0 === bK ? void 0 : bK.lampLightReleasing) && void 0 !== XO && XO,
          gained: null === bK || 0 === this.gainedCount ? null : {
            text: this.translate("skyblockGame:lampLightGained", {
              light: this.formatLight(this.lastGained)
            }),
            count: this.gainedCount
          },
          canCommand: "ready" === (null === bK || void 0 === bK ? void 0 : bK.lampLightStatus) && vK && !this.isPending(),
          situation: this.situation,
          shop: null === eO ? null : {
            oddsFor: this.translate("skyblockGame:lampLightOddsFor", {
              rod: eO.lampLightOddsRod,
              island: this.translate(eO.lampLightIslandNameKey)
            }),
            heldRod: null !== eO.lampLightHeldRod,
            charms: eO.lampLightCharms.map((OO => this.charmView(OO, eO, lO))),
            tints: eO.lampLightTints.map((OO => {
              const KO = OO.lampLightTintId,
                [pO, XO, bK] = OO.lampLightTintColour;
              return {
                id: KO,
                name: this.translate(`skyblockGame:lampLightTint${KO.charAt(0).toUpperCase()}${KO.slice(1)}`),
                cost: this.translate("skyblockGame:lampLightCost", {
                  light: this.formatLight(OO.lampLightTintCost)
                }),
                owned: OO.lampLightTintOwned,
                affordable: lO >= OO.lampLightTintCost,
                wearing: eO.lampLightTint === KO,
                colour: `rgb(${pO}, ${XO}, ${bK})`
              }
            })),
            wearingIslandColours: null === eO.lampLightTint
          },
          notice: null === hO ? null : this.translate(hO),
          sparkle: this.sparkle
        }
      }
    }
    const ib = "skyblockMagmawardView";
    class rb {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now;
        this.pl = OO, this.now = KO, this.snapshot = null, this.pulseToken = 0, this.pulseAt = -1 / 0, this.flareToken = 0, this.flareAt = -1 / 0, this.setLitToken = 0, this.setLitAt = -1 / 0, this.wornTokens = RO.map((() => 0)), this.wornAt = RO.map((() => -1 / 0))
      }
      getSnapshot() {
        return this.snapshot
      }
      PX(OO) {
        var KO, pO;
        const XO = RO.map(((KO, pO) => !0 === OO.magmawardPiecesWorn[pO]));
        if (!XO.includes(!0)) return this.snapshot = null, void this.pl(null);
        const bK = this.now(),
          eO = this.snapshot;
        null === eO && (this.wornTokens.fill(0), this.wornAt.fill(-1 / 0), this.setLitAt = -1 / 0);
        const lO = OO.magmawardFuelCarried,
          vK = !XO.includes(!1);
        let CO = null !== (KO = null === eO || void 0 === eO ? void 0 : eO.pulse) && void 0 !== KO ? KO : null,
          hO = null !== (pO = null === eO || void 0 === eO ? void 0 : eO.flare) && void 0 !== pO ? pO : null;
        OO.magmawardFuelBurned ? (CO = "burn", hO = "burn", this.pulseToken++, this.flareToken++, this.pulseAt = bK, this.flareAt = bK) : null !== eO && lO > eO.fuel && (CO = "gain", this.pulseToken++, this.pulseAt = bK), vK && null !== eO && !eO.fullSet && (hO = "fullSet", this.flareToken++, this.setLitToken++, this.flareAt = bK, this.setLitAt = bK);
        const DO = RO.map(((OO, KO) => (XO[KO] && null !== eO && !eO.pieces[KO].worn && (this.wornTokens[KO]++, this.wornAt[KO] = bK), {
          itemName: OO,
          worn: XO[KO],
          wornToken: this.wornTokens[KO],
          justWorn: XO[KO] && this.isPlaying(this.wornAt[KO], bK)
        })));
        this.snapshot = {
          pieces: DO,
          wornCount: XO.filter(Boolean).length,
          fullSet: vK,
          fuel: lO,
          fuelState: lO <= 0 ? "empty" : lO <= 3 ? "low" : "ok",
          pulse: this.isPlaying(this.pulseAt, bK) ? CO : null,
          pulseToken: this.pulseToken,
          flare: this.isPlaying(this.flareAt, bK) ? hO : null,
          flareToken: this.flareToken,
          setLit: vK && this.isPlaying(this.setLitAt, bK),
          setLitToken: this.setLitToken
        }, this.pl(this.snapshot)
      }
      dispose() {
        this.snapshot = null, this.pl(null)
      }
      isPlaying(OO, KO) {
        return KO - OO < 1200
      }
    }
    const PX = "skyblockGlowtideView";
    class mb {
      constructor(OO) {
        this.pl = OO, this.bloom = null, this.snapshot = null, this.inRangeToken = 0, this.arrow = null, this.arrowTurn = NaN, this.mountArrow = OO => {
          this.arrow = OO, this.arrowTurn = NaN
        }
      }
      getSnapshot() {
        return this.snapshot
      }
      PX(OO) {
        this.bloom = OO.glowtideBloom, null === this.bloom && null !== this.snapshot && (this.snapshot = null, this.pl(null))
      }
      afterRender(OO, KO) {
        const pO = this.bloom;
        if (null === pO || null === OO) return;
        const XO = pO.glowtideBloomX - OO[0],
          eO = pO.glowtideBloomZ - OO[2],
          lO = Math.hypot(XO, eO),
          vK = this.snapshot,
          CO = null !== vK && void 0 !== vK && vK.inRange ? 1 : 0,
          hO = lO <= 12.5 + CO && OO[1] - pO.glowtideBloomY <= 10 + CO;
        !hO || null !== vK && void 0 !== vK && vK.inRange || this.inRangeToken++;
        const DO = {
          colour: pO.glowtideBloomColour,
          inRange: hO,
          distance: Math.round(lO),
          inRangeToken: this.inRangeToken
        };
        (null === vK || DO.colour !== vK.colour || DO.inRange !== vK.inRange || !hO && DO.distance !== vK.distance) && (this.snapshot = DO, this.pl(DO));
        const MO = bK.e.computeShortestRotation(KO, (0, bK.wb)([XO, 0, eO]));
        null === this.arrow || Math.abs(MO - this.arrowTurn) < .01 || (this.arrow.style.transform = `rotate(${MO}rad)`, this.arrowTurn = MO)
      }
      dispose() {
        this.bloom = null, this.arrow = null, this.snapshot = null, this.pl(null)
      }
    }
    const sX = "skyblockGlowMeterView";
    class HX {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now;
        this.pl = OO, this.now = KO, this.snapshot = null, this.fullToken = 0, this.fullAt = -1 / 0, this.burstToken = 0, this.burstAt = -1 / 0, this.gainToken = 0, this.gainAt = -1 / 0
      }
      getSnapshot() {
        return this.snapshot
      }
      PX(OO) {
        const KO = this.now(),
          {
            glowMeterFill: pO,
            glowMeterCapacity: XO
          } = OO,
          bK = pO >= XO,
          eO = this.snapshot;
        null !== eO && (bK && !eO.full && (this.fullToken++, this.fullAt = KO), eO.full && !bK ? (this.burstToken++, this.burstAt = KO) : pO > eO.fill && (this.gainToken++, this.gainAt = KO)), this.snapshot = {
          fill: pO,
          YO: XO,
          ratio: Math.min(1, Math.max(0, pO / XO)),
          full: bK,
          rares: OO.glowMeterRares,
          ready: bK && this.isPlaying(this.fullAt, KO),
          fullToken: this.fullToken,
          burst: this.isPlaying(this.burstAt, KO),
          burstToken: this.burstToken,
          gained: this.isPlaying(this.gainAt, KO),
          gainToken: this.gainToken
        }, this.pl(this.snapshot)
      }
      dispose() {
        this.snapshot = null, this.pl(null)
      }
      isPlaying(OO, KO) {
        return KO - OO < 2e3
      }
    }
    const RX = "skyblockHushWaitView";
    class SX {
      constructor(OO) {
        this.pl = OO, this.snapshot = null, this.token = 0, this.timers = []
      }
      getSnapshot() {
        return this.snapshot
      }
      PX(OO) {
        let {
          hushWaitMs: KO,
          hushWaitTotalMs: pO,
          hushWaitLines: XO
        } = OO;
        if (this.clearTimers(), this.token++, 0 === XO.length) return console.warn("Skyblock: a Hush wait message came without a line"), void this.show(null);
        if (KO <= 0) return this.show({
          token: this.token,
          phase: "abandoned",
          waitMs: 3500,
          elapsedMs: 0,
          line: XO[0],
          lineIndex: 0
        }), void this.later(3500, (() => {
          this.show(null)
        }));
        const bK = Math.max(null !== pO && void 0 !== pO ? pO : KO, KO),
          eO = bK - KO,
          lO = OO => bK * OO / XO.length,
          vK = OO => {
            this.show({
              token: this.token,
              phase: "waiting",
              waitMs: bK,
              elapsedMs: eO,
              line: XO[OO],
              lineIndex: OO
            })
          };
        let CO = 0;
        for (; CO + 1 < XO.length && lO(CO + 1) <= eO;) CO++;
        vK(CO);
        for (let hO = CO + 1; hO < XO.length; hO++) this.later(lO(hO) - eO, (() => {
          vK(hO)
        }));
        this.later(KO, (() => {
          this.show(null)
        }))
      }
      dispose() {
        this.clearTimers(), this.show(null)
      }
      show(OO) {
        this.snapshot = OO, this.pl(OO)
      }
      later(OO, KO) {
        this.timers.push(setTimeout(KO, OO))
      }
      clearTimers() {
        for (const OO of this.timers) clearTimeout(OO);
        this.timers = []
      }
    }
    const JX = "skyblockTideChartsView",
      cb = 36e5,
      BX = 864e5;

    function ZX(OO, KO, pO) {
      const [XO, bK, eO, lO] = OO.tideChartArea, vK = Math.floor(KO), CO = Math.floor(pO);
      return vK >= XO && vK <= eO && CO >= bK && CO <= lO
    }

    function GX(OO, KO, pO) {
      const [XO, bK, eO, lO] = OO.tideChartWater;
      return function(OO, KO, pO, XO, bK, eO) {
        const lO = 4 - SO(Math.floor(bK) - (OO - pO), pO);
        return 5 * SO(Math.floor(eO) - (KO - XO), XO) + lO
      }(XO, bK, eO, lO, KO, pO)
    }

    function qb(OO, KO, pO) {
      const XO = OO.tideCharts;
      for (let bK = 0; bK < XO.length; bK++)
        if (ZX(XO[bK], KO, pO)) return XO[bK];
      return null
    }

    function xb(OO, KO, pO) {
      const XO = Math.max(0, KO - pO);
      return XO > BX ? OO("skyblockGame:tideChartsTurnDays", {
        days: String(Math.ceil(XO / BX))
      }) : XO > cb ? OO("skyblockGame:tideChartsTurnHours", {
        hours: String(Math.ceil(XO / cb))
      }) : OO("skyblockGame:tideChartsTurnSoon")
    }
    class nX extends DO {
      constructor(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : Date.now;
        super(OO, pO, XO), this.translate = KO, this.now = bK, this.snapshot = void 0, this.message = null, this.receivedAtMs = 0, this.hereIsland = null, this.hereCell = -1, this.lastX = Number.NaN, this.lastZ = Number.NaN, this.picked = null, this.lastIsland = null, this.pulse = {
          island: "",
          cells: 0,
          token: 0,
          atMs: 0
        }, this.cast = null, this.castToken = 0, this.turnsCheckedAtMs = 0, this.toggle = () => {
          this.open ? this.dismiss() : (this.picked = null, this.show())
        }, this.Kp = OO => {
          this.picked = OO, this.emit()
        }, this.snapshot = this.buildSnapshot()
      }
      PX(OO) {
        const KO = this.message;
        if (null !== KO)
          for (const XO of OO.tideCharts) {
            var pO;
            const OO = KO.tideCharts.find((OO => OO.tideChartIsland === XO.tideChartIsland)),
              bK = XO.tideChartLit & ~(null !== (pO = null === OO || void 0 === OO ? void 0 : OO.tideChartLit) && void 0 !== pO ? pO : 0);
            void 0 !== OO && 0 !== bK && (this.pulse = {
              island: XO.tideChartIsland,
              cells: bK,
              token: this.pulse.token + 1,
              atMs: this.now()
            })
          }
        this.message = OO, this.receivedAtMs = this.now(), this.locate(this.lastX, this.lastZ), this.emit()
      }
      locate(OO, KO) {
        var pO;
        const XO = null === this.message || Number.isNaN(OO) ? null : qb(this.message, OO, KO),
          bK = null !== (pO = null === XO || void 0 === XO ? void 0 : XO.tideChartIsland) && void 0 !== pO ? pO : null,
          eO = null === XO ? -1 : function(OO, KO, pO) {
            const [XO, bK, eO, lO] = OO.tideChartWater;
            return function(OO, KO, pO, XO, bK, eO, lO) {
              return ((bK - OO) / (pO + lO)) ** 2 + ((eO - KO) / (XO + lO)) ** 2 <= 1
            }(XO, bK, eO, lO, KO, pO, 2) ? GX(OO, KO, pO) : -1
          }(XO, OO, KO);
        return (bK !== this.hereIsland || eO !== this.hereCell) && (this.hereIsland = bK, this.hereCell = eO, null !== bK && (this.lastIsland = bK), !0)
      }
      afterRender(OO) {
        if (null === this.message) return;
        this.lastX = null === OO ? Number.NaN : OO[0], this.lastZ = null === OO ? Number.NaN : OO[2];
        const KO = this.locate(this.lastX, this.lastZ),
          pO = this.expirePulses();
        (KO || pO || this.turnsChanged()) && this.emit()
      }
      turnsChanged() {
        const OO = this.now();
        return !(!this.open || OO - this.turnsCheckedAtMs < 3e4 || null === this.message) && (this.turnsCheckedAtMs = OO, xb(this.translate, this.message.tideChartTurnsInMs, OO - this.receivedAtMs) !== this.snapshot.turnsText)
      }
      castLanded(OO, KO) {
        const pO = null === this.message ? null : qb(this.message, OO, KO);
        if (null === pO) return;
        const XO = GX(pO, OO, KO);
        0 === (pO.tideChartPreBlank & 1 << XO) && (this.cast = {
          island: pO.tideChartIsland,
          cell: XO,
          token: ++this.castToken,
          atMs: this.now()
        }, this.emit())
      }
      expirePulses() {
        const OO = this.now();
        let KO = !1;
        return 0 !== this.pulse.cells && OO - this.pulse.atMs >= 1500 && (this.pulse = {
          ...this.pulse,
          cells: 0
        }, KO = !0), null !== this.cast && OO - this.cast.atMs >= 1500 && (this.cast = null, KO = !0), KO
      }
      setTranslator(OO) {
        this.translate = OO, this.emit()
      }
      isEnabled() {
        return null !== this.message && this.message.tideCharts.length > 0
      }
      onClosed() {
        this.picked = null
      }
      findChart(OO, KO) {
        var pO;
        return null !== (pO = OO.tideCharts.find((OO => OO.tideChartIsland === KO))) && void 0 !== pO ? pO : null
      }
      describe(OO) {
        var KO, pO, XO;
        const bK = OO.tideChartIsland,
          eO = [];
        for (let oO = 0; oO < 25; oO++) {
          const KO = 1 << oO;
          0 !== (OO.tideChartLit & KO) ? eO.push("lit") : 0 !== (OO.tideChartClear & KO) ? eO.push("clear") : 0 !== (OO.tideChartPreBlank & KO) ? eO.push("shore") : eO.push("water")
        }
        const lO = function(OO) {
            let KO = 0;
            for (let pO = OO >>> 0; 0 !== pO; pO &= pO - 1) KO++;
            return KO
          }(OO.tideChartLit),
          vK = OO.tideChartInkCount,
          CO = this.translate(OO.tideChartIslandNameKey),
          hO = this.translate("skyblockGame:tideChartsLit", {
            lit: String(lO),
            ink: String(vK)
          }),
          DO = null === OO.tideChartPictureNameKey ? null : this.translate(OO.tideChartPictureNameKey),
          MO = this.hereIsland === bK && -1 !== this.hereCell ? this.hereCell : null,
          aK = [`${CO}: ${hO}.`];
        if (null !== DO && aK.push(this.translate("skyblockGame:tideChartsPictureRevealed", {
            picture: DO
          })), null !== MO) {
          const OO = Math.floor(MO / 5) + 1,
            KO = MO % 5 + 1;
          aK.push(this.translate("skyblockGame:tideChartsHereCell", {
            row: String(OO),
            column: String(KO)
          }))
        }
        return {
          island: bK,
          islandName: CO,
          cells: eO,
          hereCell: MO,
          lit: lO,
          ink: vK,
          litText: hO,
          pictureName: DO,
          gridLabel: aK.join(" "),
          pulseCells: this.pulse.island === bK ? this.pulse.cells : 0,
          pulseToken: this.pulse.token,
          castCell: (null === (KO = this.cast) || void 0 === KO ? void 0 : KO.island) === bK ? this.cast.cell : null,
          castToken: null !== (pO = null === (XO = this.cast) || void 0 === XO ? void 0 : XO.token) && void 0 !== pO ? pO : 0
        }
      }
      buildSnapshot() {
        var OO, KO, pO;
        const XO = this.message;
        if (null === XO || 0 === XO.tideCharts.length) return {
          enabled: !1,
          open: !1,
          chip: null,
          card: null,
          turnsText: "",
          bookText: "",
          tabs: []
        };
        const bK = this.findChart(XO, this.hereIsland),
          eO = null !== (OO = null !== (KO = null !== (pO = this.findChart(XO, this.open ? this.picked : null)) && void 0 !== pO ? pO : bK) && void 0 !== KO ? KO : this.findChart(XO, this.lastIsland)) && void 0 !== OO ? OO : XO.tideCharts[0],
          lO = null === bK ? null : this.describe(bK);
        return this.turnsCheckedAtMs = this.now(), {
          enabled: !0,
          open: this.open,
          chip: lO,
          card: eO === bK ? lO : this.describe(eO),
          turnsText: xb(this.translate, XO.tideChartTurnsInMs, this.now() - this.receivedAtMs),
          bookText: this.translate("skyblockGame:tideChartsBook", {
            count: String(XO.tideChartBookCount)
          }),
          tabs: XO.tideCharts.map((OO => ({
            island: OO.tideChartIsland,
            name: this.translate(OO.tideChartIslandNameKey),
            selected: OO.tideChartIsland === eO.tideChartIsland
          })))
        }
      }
      dispose() {
        this.message = null, this.hereIsland = null, this.hereCell = -1, this.cast = null, super.dispose()
      }
    }
    const WX = "skyblockRegularsView",
      tb = {
        goal: "skyblockGame:regularsGiftTint",
        given: "skyblockGame:regularsGiftTint",
        owed: "skyblockGame:regularsGiftTintOwed"
      },
      kb = {
        goal: "skyblockGame:regularsCharmGoal",
        given: "skyblockGame:regularsCharmGiven",
        owed: "skyblockGame:regularsCharmOwed"
      };

    function UX(OO, KO) {
      return "given" === OO ? KO.given : "owed" === OO ? KO.owed : KO.goal
    }
    class Ob extends DO {
      constructor(OO, KO, pO, XO) {
        super(OO, pO, XO), this.translate = KO, this.snapshot = void 0, this.message = null, this.selected = "", this.openedFromReachLog = !1, this.itemName = OO => OO, this.openIsland = OO => {
          this.selected = OO, this.openedFromReachLog = !0, this.show()
        }, this.selectIsland = OO => {
          this.selected = OO, this.emit()
        }, this.snapshot = this.buildSnapshot()
      }
      PX(OO) {
        this.message = OO, this.emit()
      }
      isOverReachLog() {
        return this.open && this.openedFromReachLog
      }
      takeReturnToReachLog() {
        const OO = this.openedFromReachLog;
        return this.openedFromReachLog = !1, OO
      }
      setTranslator(OO, KO, pO) {
        this.translate = OO, void 0 !== pO && (this.itemName = pO), this.emit()
      }
      isEnabled() {
        return null !== this.message
      }
      describeGift(OO, KO, pO) {
        return {
          text: this.translate(UX(OO, KO), pO),
          given: "given" === OO
        }
      }
      describeRegular(OO, KO) {
        const pO = this.translate,
          XO = null !== OO.regularKg,
          bK = OO.regularMeetings,
          eO = XO ? 0 === bK ? pO("skyblockGame:regularsNotMet") : 1 === bK ? pO("skyblockGame:regularsMeetingsOne") : pO("skyblockGame:regularsMeetings", {
            count: bK
          }) : "";
        return {
          id: OO.regularId,
          name: pO(OO.regularNameKey),
          line: pO(OO.regularLineKey),
          itemName: OO.regularFishItem,
          fishName: this.itemName(OO.regularFishItem),
          tagged: XO,
          size: null === OO.regularKg ? pO("skyblockGame:regularsNotTagged") : pO("skyblockGame:regularsSize", {
            kg: OO.regularKg.toFixed(1)
          }),
          meetings: eO,
          chance: pO("skyblockGame:regularsChance", {
            count: OO.regularOneInCasts
          }),
          resting: OO.regularRestingToday,
          gifts: [{
            text: pO("skyblockGame:regularsGiftFlare"),
            given: bK >= 3
          }, this.describeGift(OO.regularTintGift, tb, {
            tint: pO(OO.regularTintNameKey)
          })],
          history: [...OO.regularHistory].reverse().map((OO => {
            const XO = OO.regularMeetingKg.toFixed(1),
              bK = KO - OO.regularMeetingDay;
            return bK <= 0 ? pO("skyblockGame:regularsToday", {
              kg: XO
            }) : pO("skyblockGame:regularsDaysAgo", {
              days: bK,
              kg: XO
            })
          }))
        }
      }
      describeIsland(OO, KO) {
        return {
          id: OO.regularsIslandId,
          name: this.translate(OO.regularsIslandNameKey),
          charm: this.describeGift(OO.regularsCharmGift, kb, {
            charm: this.translate(OO.regularsCharmNameKey)
          }),
          regulars: OO.regularsList.map((OO => this.describeRegular(OO, KO)))
        }
      }
      buildSnapshot() {
        var OO, KO, pO, XO;
        const bK = this.message;
        if (null === bK) return {
          enabled: !1,
          open: !1,
          selected: "",
          islands: []
        };
        const eO = bK.regularsIslands.map((OO => this.describeIsland(OO, bK.regularsToday))),
          lO = null !== (OO = null !== (KO = null === (pO = eO.find((OO => OO.id === this.selected))) || void 0 === pO ? void 0 : pO.id) && void 0 !== KO ? KO : null === (XO = eO[0]) || void 0 === XO ? void 0 : XO.id) && void 0 !== OO ? OO : "";
        return {
          enabled: !0,
          open: this.open,
          selected: lO,
          islands: eO
        }
      }
      dispose() {
        this.message = null, super.dispose()
      }
    }
    const Kb = "skyblockHiddenWatersView";
    class pb {
      constructor(OO) {
        this.pl = OO, this.snapshot = null
      }
      getSnapshot() {
        return this.snapshot
      }
      PX(OO) {
        this.snapshot = function(OO) {
          const [KO, pO] = OO.hiddenWatersMapSize, XO = (OO, XO) => ({
            left: 1 - OO / KO,
            top: XO / pO
          }), bK = new Map;
          for (const [lO, vK] of OO.hiddenWatersGlimpses) {
            var eO;
            const OO = null !== (eO = bK.get(lO)) && void 0 !== eO ? eO : [];
            OO.push(vK), bK.set(lO, OO)
          }
          return {
            found: OO.hiddenWatersFound,
            total: OO.hiddenWatersTotal,
            aspect: pO / KO,
            pins: OO.hiddenWatersPins.map((OO => {
              let [KO, pO] = OO;
              return XO(KO, pO)
            })),
            islands: OO.hiddenWatersIslands.map((OO => {
              let [bK, eO, lO, vK] = OO;
              const {
                left: CO,
                top: hO
              } = XO(lO + 1, eO);
              return {
                left: CO,
                top: hO,
                width: (lO + 1 - bK) / KO,
                height: (vK + 1 - eO) / pO
              }
            })),
            glimpses: bK
          }
        }(OO), this.pl(this.snapshot)
      }
    }
    const Xb = "skyblockDialogueView";
    class be extends DO {
      constructor(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : Date.now;
        super(OO, pO, XO), this.translate = KO, this.requestDialogue = bK, this.now = eO, this.snapshot = void 0, this.enabled = !1, this.scripts = [], this.speakers = new Map, this.received = !1, this.selection = {
          kind: "character",
          npcId: null
        }, this.requestAvailableAt = 0, this.showCharacters = () => {
          this.selection = {
            kind: "character",
            npcId: "character" === this.selection.kind ? this.selection.npcId : null
          }, this.request(), this.show()
        }, this.showQuest = OO => {
          this.selection = {
            kind: "quest",
            questId: OO
          }, this.request(), this.show()
        }, this.selectCharacter = OO => {
          this.selection = {
            kind: "character",
            npcId: OO
          }, this.emit()
        }, this.snapshot = this.buildSnapshot()
      }
      PX(OO) {
        this.received = !0, this.scripts = OO.questDialogueScripts, this.speakers = new Map(OO.questDialogueSpeakers.map((OO => [OO.dialogueSpeakerId, OO]))), this.emit()
      }
      setTranslator(OO) {
        this.translate = OO, this.emit()
      }
      isEnabled() {
        return this.enabled
      }
      request() {
        const OO = this.now();
        OO >= this.requestAvailableAt && (this.requestAvailableAt = OO + 3e3, this.requestDialogue())
      }
      buildSnapshot() {
        var OO;
        const KO = {
          enabled: this.enabled,
          open: this.open,
          loading: !this.received,
          completedLabel: this.translate("skyblockDialogue:completed")
        };
        if (!this.open) return {
          ...KO,
          characters: [],
          questFocus: null,
          conversations: []
        };
        const pO = this.selection;
        if ("quest" === pO.kind) {
          const OO = this.scripts.find((OO => OO.dialogueQuestId === pO.questId));
          return {
            ...KO,
            characters: [],
            questFocus: pO.questId,
            conversations: OO ? [this.conversation(OO)] : []
          }
        }
        const XO = [];
        for (let eO = this.scripts.length - 1; eO >= 0; eO--) {
          const OO = this.scripts[eO].dialogueLines;
          for (let KO = OO.length - 1; KO >= 0; KO--) XO.includes(OO[KO].dialogueSpeakerId) || XO.push(OO[KO].dialogueSpeakerId)
        }
        const bK = null !== pO.npcId && XO.includes(pO.npcId) ? pO.npcId : null !== (OO = XO[0]) && void 0 !== OO ? OO : null;
        return {
          ...KO,
          characters: XO.map((OO => {
            var KO, pO;
            return {
              id: OO,
              styling: null !== (KO = null === (pO = this.speakers.get(OO)) || void 0 === pO ? void 0 : pO.dialogueSpeakerStyling) && void 0 !== KO ? KO : OO,
              selected: OO === bK
            }
          })),
          questFocus: null,
          conversations: this.scripts.filter((OO => OO.dialogueLines.some((OO => OO.dialogueSpeakerId === bK)))).map((OO => this.conversation(OO))).reverse()
        }
      }
      conversation(OO) {
        let KO = null;
        return {
          questId: OO.dialogueQuestId,
          questName: this.translate(OO.dialogueQuestNameKey),
          completed: OO.dialogueQuestCompleted,
          lines: OO.dialogueLines.map(((OO, pO) => {
            var XO;
            const bK = OO.dialogueSpeakerId === KO || null === (XO = this.speakers.get(OO.dialogueSpeakerId)) || void 0 === XO ? void 0 : XO.dialogueSpeakerStyling;
            return KO = OO.dialogueSpeakerId, {
              key: pO,
              display: {
                line: {
                  translationKey: OO.dialogueLineKey,
                  params: this.params(OO.dialogueLineParams)
                },
                speakerName: bK,
                animateIn: !1
              }
            }
          }))
        }
      }
      params(OO) {
        if (void 0 !== OO) return Object.fromEntries(Object.entries(OO).map((OO => {
          let [KO, pO] = OO;
          return [KO, "string" === typeof pO ? pO : this.translate(pO.translationKey)]
        })))
      }
    }
    var eb = pO(512),
      lb = pO(1123),
      ve = pO(94);
    const Cb = "skyblockAutographsView";

    function hb(OO) {
      const KO = eb.l[OO];
      return {
        label: KO.chatTag.map((OO => OO.str)).join(""),
        icon: KO.icon,
        colour: KO.mainRGB
      }
    }
    class Db extends DO {
      constructor(OO) {
        let KO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "en-GB";
        super(OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => {}, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => {}), this.locale = KO, this.signatures = null, this.snapshot = {
          enabled: !1,
          open: !1,
          entries: [],
          total: 0,
          rankTotal: 0
        }
      }
      PX(OO) {
        this.signatures = OO.autographSignatures, OO.autographOpen ? this.show() : this.emit()
      }
      setTranslator(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.locale;
        this.locale = KO, this.emit()
      }
      dispose() {
        this.signatures = null, super.dispose()
      }
      isEnabled() {
        return null !== this.signatures
      }
      buildSnapshot() {
        var OO;
        const KO = null !== (OO = this.signatures) && void 0 !== OO ? OO : [],
          pO = new Intl.DateTimeFormat(this.locale, {
            dateStyle: "medium"
          }),
          XO = [...KO].sort(((OO, KO) => Number(null !== KO.autographRank) - Number(null !== OO.autographRank) || KO.autographSignedAtMs - OO.autographSignedAtMs)).map((OO => ({
            key: `${OO.autographSignedAtMs}|${OO.autographSignerName}`,
            name: (0, lb.c)(OO.autographSignerName, !ve.featureFlags.canSeeRealPlayerNames),
            rank: null === OO.autographRank ? null : hb(OO.autographRank),
            signedOn: pO.format(OO.autographSignedAtMs)
          })));
        return {
          enabled: this.isEnabled(),
          open: this.open,
          entries: XO,
          total: XO.length,
          rankTotal: XO.filter((OO => null !== OO.rank)).length
        }
      }
    }
    const Mb = "skyblockHudView",
      ae = () => {},
      ob = {
        getItem: () => null,
        setItem: ae,
        removeItem: ae
      };
    class Fb {
      constructor(OO) {
        let {
          translate: KO,
          translateWithIcons: pO,
          setMenuOpen: XO = ae,
          dismissMenu: bK = () => {
            XO(!1)
          },
          publishSkills: eO = ae,
          publishQuests: lO = ae,
          publishQuestNotification: vK = ae,
          publishDungeons: CO = ae,
          publishCollections: hO = ae,
          publishMap: DO = ae,
          publishHud: MO = ae,
          publishPortalTransit: oO = ae,
          publishDailyReward: FO = ae,
          publishMailbox: VO = ae,
          publishQuestGraph: LO = ae,
          publishForge: QO = ae,
          publishSmuggler: zK = ae,
          publishKeepersChair: AO = ae,
          publishReachLog: fO = ae,
          publishLampLight: dO = ae,
          publishMagmaward: NO = ae,
          publishGlowtide: IO = ae,
          publishGlowMeter: yK = ae,
          publishHushWait: gK = ae,
          publishPassage: uO = ae,
          publishTideCharts: EO = ae,
          publishRegulars: jK = ae,
          publishHiddenWaters: YO = ae,
          publishDialogue: wO = ae,
          publishAutographs: iK = ae,
          isLoadingScreenUp: rK = () => !1,
          onDailyRewardCoinLanded: PO = ae,
          onDailyRewardStarted: mK = ae,
          onDailyRewardFinished: sO = ae,
          onDailyRewardItemLanded: HO = ae,
          onMailboxStarted: RO = ae,
          journeyStorage: SO = ob,
          requestTracking: JO = ae,
          requestTravel: cK = ae,
          requestDungeonEnter: BO = ae,
          requestQuestJump: ZO = ae,
          requestQuestArrive: GO = ae,
          requestForge: qK = ae,
          requestSmuggle: xK = ae,
          requestKeepersChairAim: nO = ae,
          requestReachLogOpen: WO = ae,
          requestLampLight: tK = ae,
          requestDialogue: kK = ae
        } = OO;
        this.navigation = void 0, this.map = void 0, this.compass = new TO, this.skills = void 0, this.quests = void 0, this.dungeons = void 0, this.collections = void 0, this.questGraph = void 0, this.forge = void 0, this.smuggler = void 0, this.keepersChair = void 0, this.reachLog = void 0, this.lampLight = void 0, this.commandPacer = new dX, this.passage = void 0, this.tideCharts = void 0, this.regulars = void 0, this.hiddenWaters = void 0, this.autographs = void 0, this.portalTransit = void 0, this.dailyReward = void 0, this.mailbox = void 0, this.magmaward = void 0, this.glowtide = void 0, this.glowMeter = void 0, this.hushWait = void 0, this.dialogue = void 0, this.panels = void 0, this.setMenuOpen = void 0, this.hudSnapshot = null, this.openingPanel = null, this.publishHud = void 0, this.resolveItemName = OO => OO, this.close = () => {
          for (const OO of this.panels) OO.close()
        }, this.setMenuOpen = XO, this.publishHud = MO, this.portalTransit = new Pp(oO, SO), this.magmaward = new rb(NO), this.glowtide = new mb(IO), this.glowMeter = new HX(yK), this.hushWait = new SX(gK), this.dailyReward = new Hp(FO, (() => rK() || null !== this.portalTransit.getSnapshot() || null !== this.quests.getNotificationSnapshot() || null !== this.mailbox.getSnapshot()), (OO => {
          this.quests.setNotificationsHeld(OO)
        }), (() => {
          null !== this.hudSnapshot && this.publishHud(this.getHudSnapshot())
        }), PO, mK, sO, HO);
        const UO = OO => {
          this.panels.some((OO => OO.isOpen())) || (OO ? bK() : this.setMenuOpen(!1))
        };
        this.skills = new pp(eO, Date.now, (() => {
          this.beforePanelOpen(this.skills)
        }), KO, void 0, void 0, UO), this.quests = new vX(lO, JO, KO, (() => {
          this.beforePanelOpen(this.quests)
        }), void 0, void 0, UO, vK), this.dungeons = new Dp(CO, KO, (() => {
          this.beforePanelOpen(this.dungeons)
        }), void 0, UO, BO), this.collections = new wp(hO, KO, (() => {
          this.beforePanelOpen(this.collections)
        }), UO), this.map = new aK(DO, cK, KO, (() => {
          this.beforePanelOpen(this.map)
        }), UO), this.questGraph = new xX(LO, KO, (() => {
          this.beforePanelOpen(this.questGraph)
        }), UO, ZO, GO, SO), this.forge = new ab(QO, KO, (() => {
          this.beforePanelOpen(this.forge)
        }), UO, qK), this.smuggler = new VX(zK, KO, (() => {
          this.beforePanelOpen(this.smuggler)
        }), UO, xK), this.lampLight = new wX(dO, KO, tK, this.commandPacer), this.keepersChair = new NX(AO, KO, (() => {
          this.beforePanelOpen(this.keepersChair)
        }), (OO => {
          this.lampLight.onChairClosed(), UO(OO)
        }), nO, Date.now, this.commandPacer), this.reachLog = new jb(fO, KO, (() => {
          this.beforePanelOpen(this.reachLog)
        }), UO, WO, this.commandPacer), this.passage = new fX(uO, KO, (() => {
          this.beforePanelOpen(this.passage)
        }), UO), this.tideCharts = new nX(EO, KO, (() => {
          this.beforePanelOpen(this.tideCharts)
        }), UO), this.regulars = new Ob(jK, KO, (() => {
          this.beforePanelOpen(this.regulars)
        }), (OO => {
          this.regulars.takeReturnToReachLog() && !OO && null === this.openingPanel && this.reachLog.isOpen() && this.reachLog.close(), UO(OO)
        })), this.hiddenWaters = new pb(YO), this.dialogue = new be(wO, KO, (() => {
          this.beforePanelOpen(this.dialogue)
        }), UO, kK), this.autographs = new Db(iK, (() => {
          this.beforePanelOpen(this.autographs)
        }), UO), this.mailbox = new cX(VO, (() => rK() || null !== this.portalTransit.getSnapshot() || null !== this.dailyReward.getSnapshot()), RO), this.quests.translateWithIcons = null !== pO && void 0 !== pO ? pO : null, this.skills.onLevelUp = OO => {
          this.quests.notify(OO)
        }, this.panels = [this.map, this.skills, this.quests, this.dungeons, this.collections, this.questGraph, this.forge, this.smuggler, this.keepersChair, this.reachLog, this.passage, this.tideCharts, this.regulars, this.dialogue, this.autographs], this.navigation = new Op(this.map, this.quests, this.compass, KO)
      }
      getHudSnapshot() {
        const OO = this.hudSnapshot,
          KO = this.dailyReward.getHeldCoins();
        return null === OO || KO <= 0 || !("hudPurseCoins" in OO) ? OO : {
          ...OO,
          hudPurseCoins: Math.max(0, OO.hudPurseCoins - KO)
        }
      }
      receiveHud(OO) {
        this.hudSnapshot = OO, this.publishHud(this.getHudSnapshot())
      }
      beforePanelOpen(OO) {
        this.setMenuOpen(!0);
        const KO = OO === this.regulars && this.regulars.isOverReachLog();
        this.openingPanel = OO;
        for (const pO of this.panels) pO === OO || KO && pO === this.reachLog || pO.close();
        this.openingPanel = null
      }
      setTranslator(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : KO => this.resolveItemName(KO, OO);
        this.quests.translateWithIcons = null !== pO && void 0 !== pO ? pO : null, this.navigation.setTranslator(OO, KO), this.lampLight.setTranslator(OO, KO), this.mailbox.setItemName(XO);
        for (const bK of this.panels) bK.setTranslator(OO, KO, XO)
      }
      dispose() {
        this.navigation.dispose(), this.compass.dispose(), this.portalTransit.dispose(), this.dailyReward.dispose(), this.mailbox.dispose(), this.magmaward.dispose(), this.glowtide.dispose(), this.glowMeter.dispose(), this.hushWait.dispose(), this.lampLight.dispose(), this.commandPacer.dispose();
        for (const OO of this.panels) OO.dispose()
      }
    }
    var Vb = pO(918),
      Lb = pO.n(Vb),
      Qb = pO(22),
      ze = pO(35130),
      Ab = pO(35232),
      fb = pO(1546),
      db = pO(1533),
      Tb = pO(8333),
      Nb = pO(1051),
      Ib = pO(1263),
      ye = pO(976);

    function ge(OO) {
      let {
        controller: KO,
        minimap: pO,
        children: XO
      } = OO;
      const eO = (0, Ib.h)(Mb, KO.getHudSnapshot()),
        [lO, vK] = (0, IO.useState)(KO.skills.getSnapshot().overallLevel);
      (0, Ib.f)(Kp, (OO => {
        vK(OO.overallLevel)
      }));
      const CO = (0, IO.useRef)(null);
      (0, Ib.f)(sp, (OO => {
        ! function(OO, KO) {
          if (null === OO || "function" !== typeof OO.animate) return;
          const pO = KO ? 1.35 : 1.15;
          OO.animate([{
            transform: "scale(1)"
          }, {
            transform: `scale(${pO})`
          }, {
            transform: "scale(1)"
          }], {
            duration: KO ? 320 : 160,
            easing: "ease-out"
          }), OO.classList.toggle("Receiving", !KO), KO && (OO.classList.remove("Shine"), OO.offsetWidth, OO.classList.add("Shine"))
        }(CO.current, OO)
      }));
      const {
        t: hO
      } = (0, Nb.D)(), {
        isTouchScreen: DO
      } = (0, Qb.l)(["isTouchScreen"]), [MO, aK] = (0, IO.useState)(null);
      return (0, Ab.f)(MO, ".SkyblockRightHud"), null !== eO || pO ? (0, ye.jsx)(ze.h, {
        placement: "topRight",
        children: (0, ye.jsxs)("div", {
          className: Lb()("SkyblockRightHud", {
            TouchScreen: DO
          }),
          children: [pO, null !== eO && (0, ye.jsxs)("div", {
            ref: aK,
            className: "SkyblockRightHudCard",
            children: ["hudHelpText" in eO ? (0, ye.jsx)("div", {
              className: "SkyblockHudHelp",
              children: eO.hudHelpText
            }) : (0, ye.jsxs)(ye.Fragment, {
              children: [(0, ye.jsxs)("div", {
                className: "SkyblockHudStatus",
                children: [(0, ye.jsxs)("span", {
                  className: "SkyblockHudIdentity",
                  children: [(0, ye.jsx)("strong", {
                    style: {
                      color: bK.J.cyanUiText
                    },
                    children: hO(eO.hudZoneNameKey)
                  }), null !== lO && (0, ye.jsx)("span", {
                    style: {
                      color: bK.J.goldUiText
                    },
                    children: hO("skyblockGame:level", {
                      level: (0, Tb.e)(lO)
                    })
                  })]
                }), (0, ye.jsxs)("span", {
                  className: "SkyblockHudCoins",
                  ref: CO,
                  children: [(0, ye.jsx)("span", {
                    "aria-hidden": "true",
                    children: (0, ye.jsx)(fb.b, {
                      itemName: "Gold Coin",
                      amount: 0
                    })
                  }), (0, Tb.e)(eO.hudPurseCoins)]
                })]
              }), eO.hudClockText.length > 0 && (0, ye.jsx)("div", {
                className: "SkyblockHudClock",
                children: (0, ye.jsx)(db.d, {
                  text: eO.hudClockText
                })
              })]
            }), XO, "hudZoneNameKey" in eO && (0, ye.jsx)("div", {
              className: "SkyblockHudAddress",
              children: "www.bloxd.io"
            })]
          })]
        })
      }) : null
    }

    function ub(OO) {
      let {
        icon: KO
      } = OO;
      const pO = (0, IO.useCallback)((OO => {
        null === OO || void 0 === OO || OO.replaceChildren(JK(KO))
      }), [KO]);
      return (0, ye.jsx)("span", {
        className: "SkyblockMapIconSlot",
        ref: pO
      })
    }

    function Eb(OO) {
      let {
        controller: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)();
      return (0, ye.jsx)("div", {
        className: "SkyblockMapPlayer",
        ref: KO.display.mountPlayer,
        title: pO("skyblockGame:mapYouAreHere"),
        children: (0, ye.jsx)(ub, {
          icon: "player"
        })
      })
    }
    const je = pO(36932),
      Yb = Object.fromEntries(je.keys().map((OO => [OO.replace(/^\.\/(.*)\.png$/, "$1"), je(OO)])));

    function wb(OO, KO) {
      var pO;
      return null !== (pO = Yb[OO]) && void 0 !== pO ? pO : Yb[KO]
    }

    function ie(OO) {
      let {
        imageKey: KO,
        fallbackImageKey: pO,
        geometryKey: XO,
        alt: bK,
        className: eO
      } = OO;
      const [lO, vK] = (0, IO.useState)((() => function(OO, KO) {
        return [{
          id: 0,
          imageKey: OO,
          geometryKey: KO,
          phase: "shown"
        }]
      }(KO, XO))), CO = function(OO, KO, pO) {
        const XO = OO[OO.length - 1];
        if (XO.imageKey === KO && XO.geometryKey === pO) return OO;
        const bK = {
          id: XO.id + 1,
          imageKey: KO,
          geometryKey: pO,
          phase: "entering"
        };
        return XO.geometryKey === pO ? [{
          ...XO,
          phase: "leaving"
        }, bK] : [bK]
      }(lO, KO, XO);
      return CO !== lO && vK(CO), (0, ye.jsx)(ye.Fragment, {
        children: CO.map((OO => (0, ye.jsx)("img", {
          className: Lb()("SkyblockMapTerrainImage", eO, {
            Entering: "entering" === OO.phase,
            Leaving: "leaving" === OO.phase
          }),
          src: wb(OO.imageKey, pO),
          alt: "leaving" === OO.phase ? "" : bK,
          onAnimationEnd: () => {
            vK((KO => function(OO, KO) {
              return OO.flatMap((OO => OO.id !== KO ? [OO] : "leaving" === OO.phase ? [] : [{
                ...OO,
                phase: "shown"
              }]))
            }(KO, OO.id)))
          }
        }, OO.id)))
      })
    }
    var re = pO(3719),
      Pb = pO(1271);

    function me(OO) {
      if ("Tab" !== OO.key) return;
      const KO = Array.from(OO.currentTarget.querySelectorAll('[role="button"][tabindex="0"], button:not(:disabled)')),
        pO = KO.indexOf(document.activeElement);
      var XO;
      if (OO.shiftKey && pO <= 0) OO.preventDefault(), null === (XO = KO.at(-1)) || void 0 === XO || XO.focus();
      else if (!OO.shiftKey && (-1 === pO || pO === KO.length - 1)) {
        var bK;
        OO.preventDefault(), null === (bK = KO[0]) || void 0 === bK || bK.focus()
      }
    }

    function sb() {
      const OO = (0, IO.useRef)(null);
      return (0, IO.useCallback)((KO => {
        var pO;
        KO ? (OO.current = document.activeElement, KO.focus()) : null === (pO = OO.current) || void 0 === pO || pO.focus()
      }), [])
    }

    function Hb(OO) {
      let {
        percent: KO,
        label: pO,
        levelUpToken: XO,
        colour: bK
      } = OO;
      return (0, ye.jsxs)("div", {
        className: "SkillProgressBar",
        role: "progressbar",
        "aria-label": pO,
        "aria-valuemin": 0,
        "aria-valuemax": 100,
        "aria-valuenow": KO,
        "aria-valuetext": pO,
        children: [(0, ye.jsx)("div", {
          className: "SkillProgressBarFill",
          style: {
            transform: `scaleX(${KO/100})`
          }
        }), null !== XO && void 0 !== XO && (0, ye.jsx)("div", {
          className: "SkillProgressBarLevelUp",
          style: {
            "--skill-colour": bK
          }
        }, XO)]
      })
    }

    function Rb(OO) {
      let {
        mount: KO
      } = OO;
      return (0, ye.jsx)("div", {
        className: "SkyblockSearchArea",
        ref: KO,
        hidden: !0,
        children: (0, ye.jsxs)("svg", {
          viewBox: "0 0 100 100",
          preserveAspectRatio: "none",
          children: [(0, ye.jsx)("path", {
            className: "SkyblockSearchAreaShadow"
          }), (0, ye.jsx)("path", {
            className: "SkyblockSearchAreaDashes"
          })]
        })
      })
    }

    function Sb(OO, KO, pO, XO) {
      (0, IO.useLayoutEffect)((() => {
        const bK = OO.current;
        if (!pO || null === KO || void 0 === KO || !KO.local || !bK) return;
        const eO = Array.from(bK.querySelectorAll(".SkyblockMapNode")),
          lO = [...KO.points, ...KO.portals],
          vK = () => {
            const OO = bK.clientWidth,
              pO = bK.clientHeight,
              vK = eO.map(((bK, eO) => {
                const vK = lO[eO];
                return {
                  id: vK.id,
                  portal: eO >= KO.points.length,
                  x: vK.position[0] * OO / 100,
                  y: vK.position[1] * pO / 100,
                  width: bK.offsetWidth / XO,
                  height: bK.offsetHeight / XO
                }
              })),
              CO = new Map(lO.map(((OO, KO) => [OO.id, eO[KO]])));
            for (const KO of function(OO, KO, pO) {
                const XO = [],
                  bK = [...OO].sort(((OO, KO) => Number(KO.portal) - Number(OO.portal) || OO.id.localeCompare(KO.id)));
                for (const eO of bK) {
                  const OO = OO => Math.max(eO.width / 2, Math.min(KO - eO.width / 2, OO)),
                    bK = OO => Math.max(eO.height / 2, Math.min(pO - eO.height / 2, OO)),
                    lO = [OO(eO.x)],
                    vK = [bK(eO.y)];
                  for (const KO of XO) lO.push(OO(KO.x - (KO.width + eO.width) / 2 - 4), OO(KO.x + (KO.width + eO.width) / 2 + 4)), vK.push(bK(KO.y - (KO.height + eO.height) / 2 - 4), bK(KO.y + (KO.height + eO.height) / 2 + 4));
                  let CO = {
                      ...eO,
                      x: lO[0],
                      y: vK[0]
                    },
                    hO = 1 / 0,
                    DO = 1 / 0;
                  for (const KO of new Set(lO))
                    for (const OO of new Set(vK)) {
                      let pO = 0;
                      for (const lO of XO) pO += Math.max(0, (eO.width + lO.width) / 2 + 4 - Math.abs(KO - lO.x)) * Math.max(0, (eO.height + lO.height) / 2 + 4 - Math.abs(OO - lO.y));
                      const bK = (KO - eO.x) ** 2 + (OO - eO.y) ** 2;
                      (pO < hO || pO === hO && bK < DO) && (CO = {
                        ...eO,
                        x: KO,
                        y: OO
                      }, hO = pO, DO = bK)
                    }
                  XO.push(CO)
                }
                return XO
              }(vK, OO, pO)) {
              const OO = CO.get(KO.id);
              OO.style.left = `${KO.x}px`, OO.style.top = `${KO.y}px`
            }
          };
        vK();
        const CO = new ResizeObserver(vK);
        CO.observe(bK);
        for (const OO of eO) CO.observe(OO);
        return () => {
          CO.disconnect()
        }
      }), [OO, KO, pO, XO])
    }
    const Jb = {
        zoom: 1,
        x: 0,
        y: 0
      },
      ce = {
        x0: 0,
        y0: 0,
        x1: 1,
        y1: 1
      };

    function Bb(OO, KO, pO) {
      return Math.min(pO, Math.max(KO, OO))
    }

    function Zb(OO, KO, pO) {
      const XO = Math.min(1, pO * KO / OO),
        bK = Math.min(1, OO / (pO * KO));
      return {
        x0: (1 - XO) / 2,
        y0: (1 - bK) / 2,
        x1: (1 + XO) / 2,
        y1: (1 + bK) / 2
      }
    }

    function Gb(OO, KO, pO, XO) {
      const bK = KO * (XO - pO);
      if (bK <= 1) return .5 - KO * (pO + XO) / 2;
      const eO = .45 * Math.min(1, bK - 1);
      return Bb(OO, 1 - KO * XO - eO, eO - KO * pO)
    }

    function qe(OO, KO) {
      const pO = Bb(OO.zoom, 1, 12);
      return {
        zoom: pO,
        x: Gb(OO.x, pO, KO.x0, KO.x1),
        y: Gb(OO.y, pO, KO.y0, KO.y1)
      }
    }

    function xe(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : ce;
      const eO = Bb(OO.zoom * KO, 1, 12),
        lO = eO / OO.zoom;
      return qe({
        zoom: eO,
        x: pO - (pO - OO.x) * lO,
        y: XO - (XO - OO.y) * lO
      }, bK)
    }

    function nb(OO, KO, pO, XO) {
      const [bK, eO] = (0, IO.useState)(Jb);
      (0, IO.useEffect)((() => {
        eO(Jb)
      }), [pO]), (0, IO.useEffect)((() => {
        const pO = OO.current;
        if (!KO || !pO) return;
        const bK = () => Zb(pO.clientWidth, pO.clientHeight, XO),
          lO = OO => {
            const KO = pO.getBoundingClientRect();
            return {
              x: (OO.clientX - KO.left) / KO.width,
              y: (OO.clientY - KO.top) / KO.height
            }
          },
          vK = new Map;
        let CO = {
            x: 0,
            y: 0
          },
          hO = !1,
          DO = 0;
        const MO = OO => {
            OO.preventDefault();
            const KO = OO.deltaMode === WheelEvent.DOM_DELTA_LINE ? 16 * OO.deltaY : OO.deltaY,
              pO = lO(OO);
            eO((OO => xe(OO, Math.exp(.0015 * -KO), pO.x, pO.y, bK())))
          },
          aK = OO => {
            "mouse" === OO.pointerType && 0 !== OO.button || (vK.set(OO.pointerId, lO(OO)), 1 === vK.size && (CO = {
              x: OO.clientX,
              y: OO.clientY
            }, hO = !1), DO = 0)
          },
          oO = OO => {
            const KO = vK.get(OO.pointerId);
            if (!KO) return;
            const XO = lO(OO);
            if (vK.set(OO.pointerId, XO), 2 === vK.size) {
              const [OO, KO] = [...vK.values()], pO = Math.hypot(OO.x - KO.x, OO.y - KO.y);
              if (DO > 0) {
                const XO = pO / DO;
                eO((pO => xe(pO, XO, (OO.x + KO.x) / 2, (OO.y + KO.y) / 2, bK())))
              }
              return DO = pO, void(hO = !0)
            }!hO && Math.hypot(OO.clientX - CO.x, OO.clientY - CO.y) < 4 || (hO || (hO = !0, pO.setPointerCapture(OO.pointerId)), eO((OO => function(OO, KO, pO) {
              let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : ce;
              return qe({
                zoom: OO.zoom,
                x: OO.x + KO,
                y: OO.y + pO
              }, XO)
            }(OO, XO.x - KO.x, XO.y - KO.y, bK()))))
          },
          FO = OO => {
            vK.delete(OO.pointerId), DO = 0
          },
          VO = OO => {
            hO && (OO.stopPropagation(), OO.preventDefault(), hO = !1)
          },
          LO = new ResizeObserver((() => {
            eO((OO => qe(OO, bK())))
          }));
        return LO.observe(pO), pO.addEventListener("wheel", MO, {
          passive: !1
        }), pO.addEventListener("pointerdown", aK), pO.addEventListener("pointermove", oO), pO.addEventListener("pointerup", FO), pO.addEventListener("pointercancel", FO), pO.addEventListener("click", VO, !0), () => {
          LO.disconnect(), pO.removeEventListener("wheel", MO), pO.removeEventListener("pointerdown", aK), pO.removeEventListener("pointermove", oO), pO.removeEventListener("pointerup", FO), pO.removeEventListener("pointercancel", FO), pO.removeEventListener("click", VO, !0)
        }
      }), [OO, KO, pO, XO]);
      return {
        view: bK,
        zoomBy: KO => {
          const pO = OO.current;
          pO && eO((OO => xe(OO, KO, .5, .5, Zb(pO.clientWidth, pO.clientHeight, XO))))
        }
      }
    }

    function Wb(OO) {
      var KO, pO, XO, bK;
      let {
        controller: eO,
        navigation: lO
      } = OO;
      const vK = (0, Ib.h)(MO, eO.getSnapshot()),
        {
          t: CO
        } = (0, Nb.D)(),
        hO = sb(),
        DO = vK.presentation,
        aK = (0, IO.useRef)(null),
        oO = (0, IO.useRef)(null),
        FO = Boolean(vK.open && (null === DO || void 0 === DO ? void 0 : DO.local) && DO.background),
        VO = nb(aK, FO, `${vK.open}|${vK.tab}|${null===DO||void 0===DO||null===(KO=DO.background)||void 0===KO?void 0:KO.geometryKey}`, null !== (pO = null === DO || void 0 === DO || null === (XO = DO.background) || void 0 === XO ? void 0 : XO.ratio) && void 0 !== pO ? pO : 2);
      if (Sb(oO, DO, vK.open, VO.view.zoom), !DO || !vK.open) return null;
      const LO = DO.local ? DO.background : null,
        QO = {
          "--map-ratio": String(null !== (bK = null === LO || void 0 === LO ? void 0 : LO.ratio) && void 0 !== bK ? bK : 2),
          backgroundColor: null === LO || void 0 === LO ? void 0 : LO.colour
        },
        zK = {
          "--map-zoom": String(VO.view.zoom),
          transform: `translate(${100*VO.view.x}%, ${100*VO.view.y}%) scale(${VO.view.zoom})`
        };
      return (0, ye.jsx)(re.d, {
        show: vK.open,
        close: eO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockMapPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockMapTitle",
          tabIndex: -1,
          ref: hO,
          onKeyDown: me,
          children: [(0, ye.jsxs)("header", {
            className: "SkyblockSkillsHeader",
            children: [(0, ye.jsxs)("div", {
              className: "SkyblockMapTitle",
              children: [(0, ye.jsx)("h2", {
                id: "skyblockMapTitle",
                children: CO("skyblockGame:map")
              }), DO.minimap && (0, ye.jsx)("p", {
                children: DO.minimap.caption
              })]
            }), (0, ye.jsx)("div", {
              className: "SkyblockMapTabs",
              "data-pad-tabs": "1",
              children: ["local", "world"].map((OO => (0, ye.jsx)("button", {
                type: "button",
                "data-pad-tab": !0,
                "data-pad-selected": OO === vK.tab ? "true" : void 0,
                className: Lb()({
                  Selected: OO === vK.tab
                }),
                "aria-pressed": OO === vK.tab,
                onClick: () => {
                  eO.selectTab(OO)
                },
                children: CO("local" === OO ? "skyblockGame:mapLocal" : "skyblockGame:mapWorld")
              }, OO)))
            }), (0, ye.jsx)(Pb.i, {
              padIgnore: !0,
              onClick: eO.dismiss
            })]
          }), (0, ye.jsx)("div", {
            className: "SkyblockMapBody",
            children: (0, ye.jsxs)("div", {
              ref: aK,
              className: Lb()("SkyblockMapCanvas", {
                Local: DO.local,
                Overview: !DO.local,
                Zoomed: VO.view.zoom > 1
              }),
              style: QO,
              children: [(0, ye.jsx)("div", {
                className: "SkyblockMapZoomLayer",
                style: FO ? zK : void 0,
                children: (0, ye.jsxs)("div", {
                  className: "SkyblockMapArea",
                  ref: oO,
                  children: [LO && (0, ye.jsx)(ie, {
                    className: "SkyblockMapTerrain",
                    imageKey: LO.imageKey,
                    fallbackImageKey: LO.fallbackImageKey,
                    geometryKey: LO.geometryKey,
                    alt: LO.label
                  }), DO.local && (0, ye.jsx)(Rb, {
                    mount: lO.display.mountMapSearchArea
                  }), !DO.local && (0, ye.jsx)("svg", {
                    className: "SkyblockMapConnections",
                    viewBox: "0 0 100 100",
                    preserveAspectRatio: "none",
                    "aria-hidden": "true",
                    children: DO.connections.map((OO => (0, ye.jsx)("line", {
                      className: Lb()({
                        Explored: OO.explored
                      }),
                      x1: OO.start[0],
                      y1: OO.start[1],
                      x2: OO.end[0],
                      y2: OO.end[1]
                    }, OO.id)))
                  }), DO.points.map((OO => {
                    const KO = !DO.local && OO.thumbnail ? Yb[OO.thumbnail] : void 0;
                    return (0, ye.jsxs)("div", {
                      className: Lb()("SkyblockMapNode", {
                        Current: OO.current
                      }),
                      style: {
                        left: `${OO.position[0]}%`,
                        top: `${OO.position[1]}%`
                      },
                      children: [(0, ye.jsxs)(Pb.d, {
                        className: Lb()("SkyblockMapPin", {
                          Unknown: !OO.visited,
                          Current: OO.current
                        }),
                        disabled: vK.pending,
                        onClick: () => {
                          eO.travel(OO.travelKind, OO.travelId)
                        },
                        children: [KO && (0, ye.jsx)("img", {
                          className: "SkyblockMapZoneThumbnail",
                          src: KO,
                          alt: ""
                        }), !KO && (0, ye.jsx)("span", {
                          className: "SkyblockMapPinSymbol",
                          "aria-hidden": "true",
                          children: (0, ye.jsx)(ub, {
                            icon: OO.icon
                          })
                        }), (0, ye.jsx)("span", {
                          className: "SkyblockMapPinName",
                          children: OO.name
                        })]
                      }), OO.current && (0, ye.jsx)("span", {
                        className: Lb()("SkyblockMapHereBadge", {
                          Above: OO.position[1] > 50
                        }),
                        children: CO("skyblockGame:mapYouAreHere")
                      })]
                    }, OO.id)
                  })), DO.portals.map((OO => (0, ye.jsx)("div", {
                    className: "SkyblockMapNode",
                    style: {
                      left: `clamp(3rem, ${OO.position[0]}%, calc(100% - 3rem))`,
                      top: `clamp(2rem, ${OO.position[1]}%, calc(100% - 2rem))`
                    },
                    children: (0, ye.jsxs)(Pb.d, {
                      className: "SkyblockMapPin",
                      disabled: vK.pending,
                      onClick: () => {
                        eO.travel(OO.travelKind, OO.travelId)
                      },
                      children: [(0, ye.jsx)("span", {
                        className: "SkyblockMapPinSymbol",
                        style: {
                          color: OO.colour
                        },
                        "aria-hidden": "true",
                        children: (0, ye.jsx)(ub, {
                          icon: OO.icon
                        })
                      }), (0, ye.jsx)("span", {
                        className: "SkyblockMapPinName",
                        children: OO.name
                      })]
                    })
                  }, OO.id))), DO.local && (0, ye.jsx)(Eb, {
                    controller: lO
                  })]
                })
              }), FO && (0, ye.jsxs)("div", {
                className: "SkyblockMapZoomControls",
                children: [(0, ye.jsx)("button", {
                  type: "button",
                  "aria-label": CO("skyblockGame:mapZoomIn"),
                  disabled: VO.view.zoom >= 12,
                  onClick: () => {
                    VO.zoomBy(1.5)
                  },
                  children: "+"
                }), (0, ye.jsx)("button", {
                  type: "button",
                  "aria-label": CO("skyblockGame:mapZoomOut"),
                  disabled: VO.view.zoom <= 1,
                  onClick: () => {
                    VO.zoomBy(1 / 1.5)
                  },
                  children: "\u2212"
                })]
              }), (0, ye.jsx)("div", {
                className: "SkyblockMapFeedback",
                role: "status",
                "aria-live": "polite",
                children: vK.feedback
              })]
            })
          }), (0, ye.jsxs)("footer", {
            className: "SkyblockMapFooter",
            children: [DO.progress && (0, ye.jsxs)("div", {
              className: "SkyblockMapProgress",
              children: [(0, ye.jsx)("span", {
                children: DO.progress
              }), (0, ye.jsx)(Hb, {
                percent: DO.percent,
                label: DO.progress
              })]
            }), DO.noLandmarks && (0, ye.jsx)("span", {
              children: CO("skyblockGame:mapNoLandmarks")
            }), DO.canTravel && (0, ye.jsx)("span", {
              className: "SkyblockMapHint",
              children: CO("skyblockGame:mapTravelHint")
            })]
          })]
        })
      })
    }

    function te(OO) {
      let {
        view: KO,
        controller: pO,
        navigation: XO
      } = OO;
      const {
        t: bK
      } = (0, Nb.D)(), {
        isTouchScreen: eO
      } = (0, Qb.l)(["isTouchScreen"]);
      return (0, ye.jsxs)("aside", {
        className: "SkyblockMinimap",
        "aria-label": bK("skyblockGame:mapLocal"),
        children: [eO && (0, ye.jsx)(Pb.d, {
          className: "SkyblockMinimapOpen",
          onClick: pO.showLocal,
          children: bK("skyblockGame:map")
        }), (0, ye.jsxs)("div", {
          className: "SkyblockMinimapFrame",
          style: {
            backgroundColor: KO.colour
          },
          children: [(0, ye.jsxs)("div", {
            className: "SkyblockMinimapTerrain",
            ref: XO.display.mountTerrain,
            style: {
              width: KO.width,
              height: KO.height
            },
            children: [(0, ye.jsx)(ie, {
              imageKey: KO.imageKey,
              fallbackImageKey: KO.fallbackImageKey,
              geometryKey: KO.geometryKey,
              alt: KO.label
            }), (0, ye.jsx)(Rb, {
              mount: XO.display.mountMinimapSearchArea
            }), KO.markers.map((OO => (0, ye.jsx)("span", {
              className: "SkyblockMinimapLandmark",
              style: {
                left: `${OO.position[0]}%`,
                top: `${OO.position[1]}%`,
                color: OO.colour
              },
              title: OO.name,
              children: (0, ye.jsx)(ub, {
                icon: OO.icon
              })
            }, OO.id)))]
          }), (0, ye.jsx)("div", {
            className: "SkyblockMinimapPlayer",
            title: bK("skyblockGame:mapYouAreHere"),
            children: (0, ye.jsx)(ub, {
              icon: "player"
            })
          })]
        }), (0, ye.jsx)("div", {
          className: "SkyblockMinimapCaption",
          children: KO.caption
        })]
      })
    }

    function ke(OO) {
      let {
        controller: KO
      } = OO;
      return (0, ye.jsxs)("div", {
        className: "SkyblockCompass",
        ref: KO.display.mountCompass,
        children: [(0, ye.jsx)("span", {
          className: "SkyblockCompassArrow",
          "aria-hidden": "true",
          children: "\u25bc"
        }), (0, ye.jsx)("div", {
          className: "SkyblockCompassTrack",
          "aria-hidden": "true"
        }), (0, ye.jsx)("div", {
          className: "SkyblockCompassLabel"
        })]
      })
    }

    function Ub(OO) {
      let {
        controller: KO,
        surface: pO
      } = OO;
      const {
        t: XO
      } = (0, Nb.D)(), bK = (0, Ib.h)(Kp, KO.getSnapshot()), eO = sb();
      return bK.enabled ? (0, ye.jsxs)(ye.Fragment, {
        children: ["hud" === pO && (0, ye.jsx)(ze.h, {
          placement: "statBars",
          children: bK.hud && (0, ye.jsxs)("div", {
            className: "SkyblockSkillsHudCompact",
            style: {
              "--skill-colour": bK.hud.colour
            },
            children: [(0, ye.jsx)(Hb, {
              percent: bK.hud.skill.percent,
              label: bK.hud.skill.xp,
              levelUpToken: bK.hud.levelUpToken,
              colour: bK.hud.colour
            }), (0, ye.jsxs)("div", {
              className: "SkyblockSkillsHudCompactText SmallTextBold",
              children: [(0, ye.jsxs)("span", {
                children: [bK.hud.skill.label, " \xb7 ", bK.hud.skill.level]
              }), (0, ye.jsx)("span", {
                children: bK.hud.gain
              })]
            })]
          })
        }), "hud" === pO && (0, ye.jsx)(ze.h, {
          children: bK.hud && (0, ye.jsxs)("div", {
            className: "SkyblockSkillsHud",
            children: [(0, ye.jsxs)("div", {
              className: "SkyblockSkillsHudHeading",
              children: [(0, ye.jsx)("strong", {
                children: bK.hud.skill.label
              }), (0, ye.jsx)("span", {
                children: bK.hud.gain
              })]
            }), (0, ye.jsx)(Hb, {
              percent: bK.hud.skill.percent,
              label: bK.hud.skill.xp,
              levelUpToken: bK.hud.levelUpToken,
              colour: bK.hud.colour
            }), (0, ye.jsxs)("div", {
              className: "SkyblockSkillsHudProgress",
              children: [(0, ye.jsx)("span", {
                children: bK.hud.skill.level
              }), (0, ye.jsx)("span", {
                children: bK.hud.skill.xp
              })]
            })]
          })
        }), "menu" === pO && (0, ye.jsx)(re.d, {
          show: bK.open,
          close: KO.dismiss,
          togglePointerLock: !1,
          className: "SkyblockSkillsOverlay",
          children: (0, ye.jsxs)("section", {
            className: "SkyblockSkillsPanel",
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": "skyblockSkillsTitle",
            tabIndex: -1,
            ref: eO,
            onKeyDown: me,
            children: [(0, ye.jsxs)("header", {
              className: "SkyblockSkillsHeader",
              children: [(0, ye.jsxs)("div", {
                children: [(0, ye.jsx)("h2", {
                  id: "skyblockSkillsTitle",
                  children: XO("skyblockGame:skills")
                }), (0, ye.jsx)("p", {
                  children: XO("skyblockGame:skillsIntro")
                })]
              }), (0, ye.jsx)(Pb.i, {
                padIgnore: !0,
                onClick: KO.dismiss
              })]
            }), (0, ye.jsxs)("div", {
              className: "SkyblockSkillsBody",
              children: [(0, ye.jsx)("div", {
                className: "SkyblockSkillsList",
                "data-pad-select-on-focus": !0,
                children: bK.skills.map((OO => (0, ye.jsxs)(Pb.d, {
                  className: Lb()("SkyblockSkillCard", {
                    Selected: OO.selected
                  }),
                  ariaPressed: OO.selected,
                  onClick: () => {
                    KO.select(OO.id)
                  },
                  children: [(0, ye.jsx)("div", {
                    className: "SkyblockSkillIcon",
                    children: (0, ye.jsx)(fb.b, {
                      itemName: OO.icon,
                      amount: 0
                    })
                  }), (0, ye.jsxs)("div", {
                    className: "SkyblockSkillSummary",
                    children: [(0, ye.jsxs)("div", {
                      className: "SkyblockSkillTitle",
                      children: [(0, ye.jsx)("strong", {
                        children: OO.label
                      }), (0, ye.jsx)("span", {
                        children: OO.level
                      })]
                    }), (0, ye.jsx)(Hb, {
                      percent: OO.percent,
                      label: `${OO.label}: ${OO.xp}`
                    }), (0, ye.jsx)("span", {
                      className: "SkyblockSkillXp",
                      children: OO.xp
                    })]
                  })]
                }, OO.id)))
              }), bK.detail && (0, ye.jsxs)("div", {
                className: "SkyblockSkillDetail",
                children: [(0, ye.jsx)("div", {
                  className: "SkyblockSkillDetailIcon",
                  children: (0, ye.jsx)(fb.b, {
                    itemName: bK.detail.icon,
                    amount: 0
                  })
                }), (0, ye.jsx)("h3", {
                  children: bK.detail.label
                }), (0, ye.jsx)("strong", {
                  className: "SkyblockSkillDetailLevel",
                  children: bK.detail.level
                }), (0, ye.jsx)("p", {
                  children: bK.detail.description
                }), (0, ye.jsxs)("div", {
                  className: "SkyblockSkillBenefit",
                  children: [(0, ye.jsx)("strong", {
                    children: XO("skyblockGame:currentBenefit")
                  }), (0, ye.jsx)("span", {
                    children: bK.detail.benefit
                  })]
                }), (0, ye.jsx)(Hb, {
                  percent: bK.detail.percent,
                  label: bK.detail.xp
                }), (0, ye.jsx)("p", {
                  children: bK.detail.xp
                }), (0, ye.jsx)("h4", {
                  children: XO("skyblockGame:earnXp")
                }), (0, ye.jsx)("ul", {
                  children: bK.detail.sources.map((OO => (0, ye.jsx)("li", {
                    children: OO
                  }, OO)))
                })]
              })]
            })]
          })
        })]
      }) : null
    }
    var Oe = pO(1195),
      Ke = pO(3969),
      pe = pO(243);

    function Xe(OO) {
      let {
        item: KO
      } = OO;
      return (0, ye.jsx)("span", {
        className: "SkyblockQuestStepIcon",
        "aria-hidden": "true",
        children: (0, ye.jsx)(fb.b, {
          itemName: KO,
          amount: 0
        })
      })
    }

    function bl(OO) {
      let {
        name: KO,
        percent: pO,
        progress: XO
      } = OO;
      return (0, ye.jsxs)("span", {
        className: "SkyblockQuestStepBar",
        children: [(0, ye.jsx)(Hb, {
          percent: pO,
          label: `${(0,pe.qb)(KO)}: ${XO}`
        }), (0, ye.jsx)("span", {
          className: "SkyblockQuestStepBarLabel",
          children: XO
        })]
      })
    }

    function ee(OO) {
      let {
        subquests: KO,
        showDescriptions: pO = !1
      } = OO;
      return (0, ye.jsx)("ul", {
        className: "SkyblockQuestChecklist",
        children: KO.map((OO => {
          const KO = pO && "completed" === OO.status,
            XO = (0, ye.jsxs)("li", {
              className: Lb()("SkyblockQuestStep", OO.status, {
                JustFinished: OO.justFinished,
                JustUnlocked: OO.justUnlocked
              }),
              tabIndex: KO ? 0 : void 0,
              children: [null !== OO.iconItem && (0, ye.jsx)(Xe, {
                item: OO.iconItem
              }), null === OO.iconItem && (0, ye.jsx)("span", {
                className: "SkyblockQuestStepMark",
                "aria-hidden": "true",
                children: "completed" === OO.status ? "\u2713" : "skipped" === OO.status ? "\u2212" : "\u25cb"
              }), (0, ye.jsxs)("span", {
                className: "SkyblockQuestStepBody",
                children: [(0, ye.jsx)("strong", {
                  children: (0, ye.jsx)(Ke.b, {
                    text: OO.name
                  })
                }), pO && !KO && (0, ye.jsx)("span", {
                  children: (0, ye.jsx)(Ke.b, {
                    text: OO.description
                  })
                }), null !== OO.barPercent && (0, ye.jsx)(bl, {
                  name: OO.name,
                  percent: OO.barPercent,
                  progress: OO.progress
                }), null === OO.barPercent && !KO && (0, ye.jsx)("span", {
                  className: "SkyblockQuestStepStatus",
                  children: OO.statusLabel
                })]
              })]
            }, OO.id);
          return KO ? (0, ye.jsx)(Oe.g, {
            delayShow: 200,
            tooltipInner: (0, ye.jsxs)("div", {
              className: "SkyblockQuestStepTooltip",
              children: [(0, ye.jsx)("span", {
                children: (0, ye.jsx)(Ke.b, {
                  text: OO.description
                })
              }), (0, ye.jsx)("strong", {
                children: OO.statusLabel
              })]
            }),
            children: XO
          }, OO.id) : XO
        }))
      })
    }

    function le(OO) {
      let {
        quest: KO,
        select: pO
      } = OO;
      const {
        t: XO
      } = (0, Nb.D)(), bK = KO.focusStep;
      return (0, ye.jsxs)(Pb.d, {
        className: Lb()("SkyblockQuestCard", {
          Selected: KO.selected,
          Tracked: KO.tracked
        }),
        onClick: () => {
          pO(KO.id)
        },
        children: [(0, ye.jsxs)("div", {
          className: "SkyblockQuestCardTitle",
          children: [(0, ye.jsx)("strong", {
            children: (0, ye.jsx)(Ke.b, {
              text: KO.name
            })
          }), KO.tracked && (0, ye.jsx)("span", {
            className: "SkyblockQuestTrackingBadge",
            children: XO("skyblockGame:currentQuest")
          })]
        }), bK && (0, ye.jsxs)("div", {
          className: "SkyblockQuestCardStep",
          children: [null !== bK.iconItem && (0, ye.jsx)(Xe, {
            item: bK.iconItem
          }), (0, ye.jsx)(bl, {
            name: bK.name,
            percent: bK.barPercent,
            progress: bK.progress
          })]
        }), (0, ye.jsx)("span", {
          className: "SkyblockQuestProgress",
          children: KO.progress
        })]
      })
    }

    function vl(OO) {
      let {
        controller: KO,
        surface: pO
      } = OO;
      const XO = (0, Ib.h)(ep, KO.getSnapshot()),
        {
          t: bK
        } = (0, Nb.D)(),
        eO = sb();
      return XO.enabled ? (0, ye.jsxs)(ye.Fragment, {
        children: ["hud" === pO && (0, ye.jsx)(ye.Fragment, {
          children: XO.tracked && (0, ye.jsx)("div", {
            className: "SkyblockQuestTracker",
            style: bX,
            children: (0, ye.jsxs)("div", {
              className: "SkyblockQuestTrackerBody",
              children: [XO.trackedStepPulse > 0 && (0, ye.jsx)("span", {
                className: "SkyblockQuestTrackerPulse",
                "aria-hidden": "true"
              }, XO.trackedStepPulse), (0, ye.jsx)("span", {
                className: "SkyblockQuestEyebrow",
                children: bK("skyblockGame:currentQuest")
              }), (0, ye.jsxs)("span", {
                className: "SkyblockQuestTrackerTitle",
                children: [(0, ye.jsx)("strong", {
                  children: (0, ye.jsx)(Ke.b, {
                    text: XO.tracked.name
                  })
                }), null !== XO.tracked.clock && (0, ye.jsx)("span", {
                  className: "SkyblockQuestClock",
                  children: XO.tracked.clock
                })]
              }), (0, ye.jsx)(ee, {
                subquests: XO.tracked.subquests
              })]
            })
          })
        }), "menu" === pO && (0, ye.jsx)(re.d, {
          show: XO.open,
          close: KO.dismiss,
          togglePointerLock: !1,
          className: "SkyblockSkillsOverlay",
          children: (0, ye.jsxs)("section", {
            className: "SkyblockSkillsPanel SkyblockQuestsPanel",
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": "skyblockQuestsTitle",
            tabIndex: -1,
            ref: eO,
            onKeyDown: me,
            children: [(0, ye.jsxs)("header", {
              className: "SkyblockSkillsHeader",
              children: [(0, ye.jsx)("div", {
                children: (0, ye.jsx)("h2", {
                  id: "skyblockQuestsTitle",
                  children: bK("skyblockGame:quests")
                })
              }), (0, ye.jsx)(Pb.i, {
                padIgnore: !0,
                onClick: KO.dismiss
              })]
            }), (0, ye.jsxs)("div", {
              className: "SkyblockSkillsBody SkyblockQuestsBody",
              children: [(0, ye.jsxs)("div", {
                className: "SkyblockQuestList",
                children: [(0, ye.jsx)("h3", {
                  children: bK("skyblockGame:current")
                }), 0 === XO.active.length && (0, ye.jsx)("p", {
                  className: "SkyblockQuestEmpty",
                  children: bK("skyblockGame:noActiveQuests")
                }), XO.active.map((OO => (0, ye.jsx)(le, {
                  quest: OO,
                  select: KO.select
                }, OO.id))), (0, ye.jsx)("h3", {
                  children: (0, ye.jsxs)("button", {
                    type: "button",
                    className: Lb()("SkyblockQuestSectionToggle", {
                      Expanded: XO.completedExpanded
                    }),
                    "aria-expanded": XO.completedExpanded,
                    onClick: KO.toggleCompleted,
                    children: [(0, ye.jsx)("span", {
                      className: "SkyblockQuestSectionCaret",
                      "aria-hidden": "true"
                    }), bK("skyblockGame:completed"), (0, ye.jsx)("span", {
                      className: "SkyblockQuestSectionCount",
                      children: XO.completed.length
                    })]
                  })
                }), XO.completedExpanded && 0 === XO.completed.length && (0, ye.jsx)("p", {
                  className: "SkyblockQuestEmpty",
                  children: bK("skyblockGame:noCompletedQuests")
                }), XO.completedExpanded && XO.completed.map((OO => (0, ye.jsx)(le, {
                  quest: OO,
                  select: KO.select
                }, OO.id)))]
              }), XO.detail && (0, ye.jsxs)("div", {
                className: "SkyblockQuestDetail",
                children: [XO.detail.completed && (0, ye.jsx)("span", {
                  className: "SkyblockQuestEyebrow",
                  children: bK("skyblockGame:completedQuest")
                }), (0, ye.jsx)("h3", {
                  children: (0, ye.jsx)(Ke.b, {
                    text: XO.detail.name
                  })
                }), (0, ye.jsx)("p", {
                  className: "SkyblockQuestDescription",
                  children: (0, ye.jsx)(Ke.b, {
                    text: XO.detail.description
                  })
                }), (0, ye.jsxs)("p", {
                  className: "SkyblockQuestProgress",
                  children: [XO.detail.progress, null !== XO.detail.clock && (0, ye.jsx)("span", {
                    className: "SkyblockQuestClock",
                    children: XO.detail.clock
                  })]
                }), (0, ye.jsx)(ee, {
                  subquests: XO.detail.subquests,
                  showDescriptions: !0
                }), XO.detail.tracked && (0, ye.jsx)("p", {
                  className: "SkyblockQuestTrackingStatus",
                  children: XO.detail.trackLabel
                }), !XO.detail.completed && !XO.detail.tracked && (0, ye.jsx)(Pb.m, {
                  onClick: KO.trackSelected,
                  disabled: !XO.detail.canTrack,
                  children: XO.detail.trackLabel
                }), XO.detail.canViewDialogue && (0, ye.jsx)(Pb.d, {
                  className: "SkyblockQuestViewDialogue",
                  onClick: KO.viewDialogue,
                  children: bK("skyblockDialogue:viewDialogue")
                })]
              })]
            })]
          })
        })]
      }) : null
    }
    var Ce = pO(933),
      he = pO(2085);

    function De(OO, KO, pO, XO, bK) {
      const eO = OO => "linear" === bK ? OO : {
          U6: bK,
          point: OO
        },
        lO = {};
      for (const [vK, CO] of XO)
        for (const [KO, pO] of Object.entries(OO(vK, CO, eO))) lO[KO] ??= {
          timeline: []
        }, lO[KO].timeline.push(pO);
      return {
        w6: KO,
        loop: pO,
        r4: lO
      }
    }
    const Me = .547,
      al = .022,
      oe = {
        drop: -.03,
        torso: -.28,
        nod: -.4,
        arms: -2.85,
        spread: .18
      },
      Fe = {
        drop: .22,
        torso: .7,
        nod: -.25,
        legs: [-.35, .25],
        arms: -1.05,
        spread: .12
      };

    function Ve(OO, KO, pO) {
      const {
        drop: XO = 0,
        shift: bK = 0,
        torso: eO = 0,
        nod: lO = 0,
        tilt: vK = 0,
        legs: CO = [0, 0],
        arms: hO = 0,
        spread: DO = 0
      } = KO, MO = Me * Math.cos(eO) - al * Math.sin(eO), aK = Me * Math.sin(eO) + al * Math.cos(eO), oO = pO([0, -XO, bK]);
      return {
        LowerBody: {
          timeFraction: OO,
          position: oO,
          rotation: pO([0, 0, 0])
        },
        UpperBody: {
          timeFraction: OO,
          position: oO,
          rotation: pO([eO, 0, vK])
        },
        HeadMesh: {
          timeFraction: OO,
          position: pO([0, MO - Me - XO, aK - al + bK]),
          rotation: pO([eO + lO, 0, vK])
        },
        LegLeftMesh: {
          timeFraction: OO,
          rotation: pO([CO[0], 0, 0])
        },
        LegRightMesh: {
          timeFraction: OO,
          rotation: pO([CO[1], 0, 0])
        },
        ArmLeftMesh: {
          timeFraction: OO,
          rotation: pO([hO, 0, DO])
        },
        ArmRightMesh: {
          timeFraction: OO,
          rotation: pO([hO, 0, -DO])
        }
      }
    }

    function Le(OO, KO, pO) {
      return De(Ve, OO, KO, pO, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "linear")
    }

    function Qe(OO) {
      return "number" === typeof OO ? [OO, OO] : OO
    }

    function zl(OO, KO, pO) {
      const {
        rise: XO = 0,
        shift: bK = 0,
        torso: eO = 0,
        twist: lO = 0,
        tilt: vK = 0,
        nod: CO = 0,
        cock: hO = 0,
        arms: DO = 0,
        spread: MO = 0
      } = KO, [aK, oO] = Qe(DO), [FO, VO] = Qe(MO);
      return {
        TorsoNode: {
          timeFraction: OO,
          position: pO([0, XO, bK]),
          rotation: pO([eO, lO, vK])
        },
        HeadMesh: {
          timeFraction: OO,
          rotation: pO([CO, 0, hO])
        },
        ArmLeftMesh: {
          timeFraction: OO,
          rotation: pO([aK, 0, FO])
        },
        ArmRightMesh: {
          timeFraction: OO,
          rotation: pO([oO, 0, -VO])
        }
      }
    }
    const Ae = [1.0625, -1, 0];

    function fe(OO) {
      return "number" === typeof OO ? [OO, OO] : OO
    }

    function de(OO, KO, pO) {
      const {
        drop: XO = 0,
        shift: bK = 0,
        torso: eO = 0,
        tilt: lO = 0,
        nod: vK = 0,
        cock: CO = 0,
        legs: hO = [0, 0],
        arms: DO = 0,
        spread: MO = 0
      } = KO, [aK, oO] = fe(DO), [FO, VO] = fe(MO), LO = -eO, QO = -lO, [zK, AO, fO] = function(OO, KO) {
        const [pO, XO, bK] = [-Ae[0], Ae[1], -Ae[2]], eO = pO * Math.cos(KO) - XO * Math.sin(KO), lO = pO * Math.sin(KO) + XO * Math.cos(KO);
        return [eO - pO, -(lO * Math.cos(OO) - bK * Math.sin(OO) - XO), lO * Math.sin(OO) + bK * Math.cos(OO) - bK]
      }(LO, QO), dO = pO([0, -XO, bK]);
      return {
        TorsoNode: {
          timeFraction: OO,
          position: pO([zK, AO - XO, fO + bK]),
          rotation: pO([LO, 0, QO])
        },
        HeadMesh: {
          timeFraction: OO,
          rotation: pO([-vK, 0, -CO])
        },
        ArmLeftMesh: {
          timeFraction: OO,
          rotation: pO([-aK, 0, -FO])
        },
        ArmRightMesh: {
          timeFraction: OO,
          rotation: pO([-oO, 0, VO])
        },
        LegLeftMesh: {
          timeFraction: OO,
          position: dO,
          rotation: pO([-hO[0], 0, 0])
        },
        LegRightMesh: {
          timeFraction: OO,
          position: dO,
          rotation: pO([-hO[1], 0, 0])
        }
      }
    }
    var Te = pO(35966),
      Ne = pO(36873),
      Ie = pO(37020);

    function yl(OO, KO, pO) {
      var XO, bK;
      const eO = function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
          return OO + ((arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0) - OO) * pO
        },
        [lO, vK] = null !== (XO = OO.legs) && void 0 !== XO ? XO : [0, 0],
        [CO, hO] = null !== (bK = KO.legs) && void 0 !== bK ? bK : [0, 0];
      return {
        drop: eO(OO.drop, KO.drop),
        shift: eO(OO.shift, KO.shift),
        torso: eO(OO.torso, KO.torso),
        nod: eO(OO.nod, KO.nod),
        tilt: eO(OO.tilt, KO.tilt),
        legs: [eO(lO, CO), eO(vK, hO)],
        arms: eO(OO.arms, KO.arms),
        spread: eO(OO.spread, KO.spread)
      }
    }
    const gl = {
        drop: .1,
        torso: .22,
        nod: -.32,
        legs: [-.2, .18],
        arms: -.75,
        spread: .32
      },
      ue = Le(4400, !0, [
        [0, gl],
        [.16, {
          ...gl,
          drop: .06,
          torso: .16,
          arms: -.85
        }],
        [.3, gl],
        [.44, {
          ...gl,
          drop: .06,
          torso: .16,
          arms: -.85
        }],
        [.56, yl(gl, oe, .7)],
        [.66, yl(gl, oe, .78)],
        [.74, yl(gl, Fe, .65)],
        [.86, {
          ...gl,
          drop: .14
        }],
        [1, gl]
      ], "catmull-rom-spline"),
      Ee = {
        ...gl,
        drop: .14,
        torso: .3,
        spread: .4
      },
      jl = {
        rise: .15,
        torso: .15,
        nod: -.25,
        arms: -.6,
        spread: .35
      },
      Ye = {
        drop: .06,
        torso: .18,
        nod: -.25,
        legs: [-.12, .1],
        arms: -.45,
        spread: .45
      },
      we = {
        caveGolem: ue,
        magmaGolem: Le(3600, !0, [
          [0, Ee],
          [.12, {
            ...Ee,
            tilt: .08,
            drop: .11
          }],
          [.26, {
            ...Ee,
            tilt: -.08
          }],
          [.4, {
            ...Ee,
            tilt: .06,
            drop: .11
          }],
          [.52, yl(Ee, oe, .9)],
          [.62, yl(Ee, Fe, .8)],
          [.7, yl(Ee, Fe, .45)],
          [.78, yl(Ee, Fe, .85)],
          [.9, {
            ...Ee,
            drop: .17
          }],
          [1, Ee]
        ], "catmull-rom-spline"),
        frostWraith: function(OO, KO, pO) {
          return De(zl, OO, KO, pO, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "linear")
        }(4800, !0, [
          [0, jl],
          [.14, {
            ...jl,
            rise: .25,
            tilt: .06
          }],
          [.28, {
            ...jl,
            rise: .12,
            tilt: -.04
          }],
          [.42, {
            ...jl,
            rise: .24,
            tilt: .04
          }],
          [.54, {
            ...jl,
            rise: .22,
            twist: .2,
            arms: [-.3, -1.6],
            spread: [.4, .05]
          }],
          [.64, {
            ...jl,
            rise: .26,
            twist: .2,
            torso: .05,
            arms: [-.3, -1.9],
            spread: [.4, .05]
          }],
          [.72, {
            ...jl,
            rise: .1,
            twist: .22,
            torso: .35,
            nod: -.1,
            arms: [-.25, -1.1],
            spread: [.4, -.05]
          }],
          [.86, {
            ...jl,
            rise: .16,
            tilt: -.04
          }],
          [1, jl]
        ], "catmull-rom-spline"),
        tikiTerror: function(OO, KO, pO) {
          return De(de, OO, KO, pO, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "linear")
        }(4400, !0, [
          [0, Ye],
          [.16, {
            ...Ye,
            drop: .02,
            torso: .12,
            arms: -.55,
            spread: .52
          }],
          [.3, Ye],
          [.44, {
            ...Ye,
            drop: .02,
            torso: .12,
            arms: -.55,
            spread: .52
          }],
          [.56, {
            drop: -.03,
            torso: -.28,
            nod: -.48,
            legs: [-.12, .12],
            arms: -1.45,
            spread: 1.1
          }],
          [.64, {
            drop: -.03,
            torso: -.32,
            tilt: .05,
            nod: -.52,
            legs: [-.12, .12],
            arms: -1.5,
            spread: 1.2
          }],
          [.72, {
            drop: -.03,
            torso: -.28,
            tilt: -.05,
            nod: -.48,
            legs: [-.12, .12],
            arms: -1.45,
            spread: 1.1
          }],
          [.86, {
            ...Ye,
            drop: .1
          }],
          [1, Ye]
        ], "catmull-rom-spline")
      },
      il = {
        golem: "caveGolem",
        wraith: "frostWraith",
        tiki: "tikiTerror"
      },
      rl = {
        "Cave Golem": "caveGolem",
        "Magma Golem": "magmaGolem"
      },
      Pe = Object.fromEntries(Object.entries(we).map((OO => {
        let [KO, pO] = OO;
        return [KO, (0, Ie.d)((0, Te.g)(pO), KO)]
      })));

    function ml(OO) {
      const KO = function(OO) {
        var KO;
        const pO = (0, Ne.c)(OO).poseRig;
        return null !== (KO = rl[OO]) && void 0 !== KO ? KO : void 0 === pO ? null : il[pO]
      }(OO);
      return null === KO ? null : Pe[KO]
    }

    function se(OO) {
      return {
        "--difficulty-colour": OO
      }
    }
    const He = (0, IO.lazy)((() => (0, he.b)(pO.e(203).then((() => pO(39548))), (OO => OO.MobPreview))));

    function Re(OO) {
      var KO, pO, XO;
      let {
        picker: bK,
        controller: eO
      } = OO;
      const {
        t: lO
      } = (0, Nb.D)(), vK = sb(), {
        page: CO
      } = bK;
      return (0, ye.jsxs)("section", {
        className: "SkyblockSkillsPanel SkyblockBossPicker",
        role: "dialog",
        "aria-modal": "true",
        "aria-labelledby": "skyblockBossPickerTitle",
        tabIndex: -1,
        ref: vK,
        onKeyDown: OO => {
          "ArrowLeft" === OO.key ? (OO.preventDefault(), OO.stopPropagation(), eO.previous()) : "ArrowRight" === OO.key ? (OO.preventDefault(), OO.stopPropagation(), eO.next()) : me(OO)
        },
        style: se(CO.colour),
        children: [(0, ye.jsxs)("header", {
          className: "SkyblockSkillsHeader",
          children: [(0, ye.jsx)("h2", {
            id: "skyblockBossPickerTitle",
            children: bK.dungeonName
          }), (0, ye.jsx)(Pb.i, {
            padIgnore: !0,
            onClick: eO.dismiss
          })]
        }), (0, ye.jsxs)("div", {
          className: "SkyblockBossPickerBody",
          children: [(0, ye.jsxs)("div", {
            className: "SkyblockBossPickerStage",
            children: [(0, ye.jsx)(Pb.d, {
              className: "SkyblockBossPickerTurn Previous",
              disabled: !bK.canPrevious,
              onClick: eO.previous,
              children: (0, ye.jsx)("span", {
                className: "SkyblockBossPickerChevron",
                children: (0, ye.jsx)(Ce.d, {
                  name: "angle-up"
                })
              })
            }), (0, ye.jsxs)("div", {
              className: Lb()("SkyblockBossPickerBoss", {
                Locked: !CO.unlocked
              }),
              children: [null !== CO.bossMobType && (0, ye.jsx)(IO.Suspense, {
                fallback: (0, ye.jsx)("div", {
                  className: "SkyblockBossPickerModel"
                }),
                children: (0, ye.jsx)(He, {
                  className: "SkyblockBossPickerModel",
                  mobType: CO.bossMobType,
                  variation: CO.bossMobVariation,
                  animation: null !== (KO = ml(CO.bossMobType)) && void 0 !== KO ? KO : void 0
                })
              }), null === CO.bossMobType && (0, ye.jsx)("div", {
                className: "SkyblockBossPickerModel SkyblockBossPickerUnknown",
                "aria-hidden": "true",
                children: "?"
              })]
            }), (0, ye.jsx)(Pb.d, {
              className: "SkyblockBossPickerTurn Next",
              disabled: !bK.canNext,
              onClick: eO.next,
              children: (0, ye.jsx)("span", {
                className: "SkyblockBossPickerChevron",
                children: (0, ye.jsx)(Ce.d, {
                  name: "angle-up"
                })
              })
            })]
          }), (0, ye.jsxs)("div", {
            className: "SkyblockBossPickerCaption",
            children: [(0, ye.jsxs)("span", {
              className: "SkyblockBossPickerDifficulty",
              children: [CO.beaten && (0, ye.jsx)("span", {
                "aria-hidden": "true",
                children: "\u2713 "
              }), CO.label]
            }), (0, ye.jsx)("strong", {
              className: "SkyblockBossPickerName",
              children: null !== (pO = CO.bossName) && void 0 !== pO ? pO : "???"
            }), (0, ye.jsxs)("span", {
              className: Lb()("SkyblockBossPickerRecord", {
                Locked: null !== CO.lockedHint
              }),
              children: [null !== CO.lockedHintHighlight && (0, ye.jsxs)(ye.Fragment, {
                children: [CO.lockedHintHighlight.before, (0, ye.jsxs)("span", {
                  className: "SkyblockDifficulty",
                  style: se(CO.lockedHintHighlight.colour),
                  children: [null !== CO.lockedHintHighlight.icon && (0, ye.jsx)("span", {
                    className: "SkyblockBossPickerHintIcon",
                    "aria-hidden": "true",
                    children: (0, ye.jsx)(fb.b, {
                      itemName: CO.lockedHintHighlight.icon,
                      amount: 0
                    })
                  }), CO.lockedHintHighlight.name]
                }), CO.lockedHintHighlight.after]
              }), null === CO.lockedHintHighlight && (null !== (XO = CO.lockedHint) && void 0 !== XO ? XO : CO.summary)]
            })]
          }), (0, ye.jsx)("div", {
            className: "SkyblockBossPickerDots",
            "aria-hidden": "true",
            children: bK.pages.map((OO => (0, ye.jsx)("span", {
              className: Lb()("SkyblockBossPickerDot", {
                Current: OO.current,
                Locked: !OO.unlocked
              }),
              style: se(OO.colour)
            }, OO.difficulty)))
          }), (0, ye.jsx)(Pb.s, {
            className: "SkyblockBossPickerFight",
            disabled: !CO.unlocked,
            onClick: eO.enter,
            children: lO("skyblockGame:dungeonFight")
          })]
        })]
      })
    }

    function Se(OO) {
      let {
        dungeon: KO,
        select: pO
      } = OO;
      return (0, ye.jsxs)(Pb.d, {
        className: Lb()("SkyblockDungeonCard", {
          Selected: KO.selected
        }),
        onClick: () => {
          pO(KO.id)
        },
        children: [(0, ye.jsxs)("div", {
          className: "SkyblockDungeonCardTitle",
          children: [(0, ye.jsx)("strong", {
            children: KO.name
          }), (0, ye.jsx)("span", {
            children: KO.beatenSummary
          })]
        }), (0, ye.jsx)("div", {
          className: "SkyblockDungeonChips",
          children: KO.difficulties.map((OO => (0, ye.jsxs)("span", {
            className: Lb()("SkyblockDungeonChip", "SkyblockDifficulty", {
              Beaten: OO.beaten
            }),
            style: se(OO.colour),
            title: OO.summary,
            children: [OO.beaten && (0, ye.jsx)("span", {
              "aria-hidden": "true",
              children: "\u2713 "
            }), OO.label]
          }, OO.difficulty)))
        })]
      })
    }

    function Je(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(hp, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)(),
        bK = sb();
      return pO.enabled ? (0, ye.jsxs)(re.d, {
        show: pO.open,
        close: KO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: [pO.picker && (0, ye.jsx)(Re, {
          picker: pO.picker,
          controller: KO
        }), !pO.picker && (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockDungeonsPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockDungeonsTitle",
          tabIndex: -1,
          ref: bK,
          onKeyDown: me,
          children: [(0, ye.jsxs)("header", {
            className: "SkyblockSkillsHeader",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockDungeonsTitle",
                children: XO("skyblockGame:dungeons")
              }), (0, ye.jsx)("p", {
                children: XO("skyblockGame:dungeonsIntro")
              })]
            }), (0, ye.jsx)(Pb.i, {
              padIgnore: !0,
              onClick: KO.dismiss
            })]
          }), (0, ye.jsxs)("div", {
            className: "SkyblockSkillsBody SkyblockDungeonsBody",
            children: [(0, ye.jsx)("div", {
              className: "SkyblockDungeonList",
              children: pO.dungeons.map((OO => (0, ye.jsx)(Se, {
                dungeon: OO,
                select: KO.select
              }, OO.id)))
            }), pO.detail && (0, ye.jsxs)("div", {
              className: "SkyblockDungeonDetail",
              children: [(0, ye.jsx)("h3", {
                children: pO.detail.name
              }), (0, ye.jsx)("ul", {
                className: "SkyblockDungeonRecords",
                children: pO.detail.difficulties.map((OO => (0, ye.jsxs)("li", {
                  className: Lb()("SkyblockDungeonRecord", {
                    Beaten: OO.beaten
                  }),
                  children: [(0, ye.jsxs)("span", {
                    className: "SkyblockDungeonRecordName SkyblockDifficulty",
                    style: se(OO.colour),
                    children: [OO.beaten && (0, ye.jsx)("span", {
                      "aria-hidden": "true",
                      children: "\u2713 "
                    }), OO.label]
                  }), (0, ye.jsx)("span", {
                    className: "SkyblockDungeonRecordSummary",
                    children: OO.summary
                  })]
                }, OO.difficulty)))
              })]
            })]
          })]
        })]
      }) : null
    }

    function cl(OO) {
      let {
        collection: KO,
        select: pO
      } = OO;
      return (0, ye.jsxs)(Pb.d, {
        className: Lb()("SkyblockSkillCard", "SkyblockCollectionCard", {
          Selected: KO.selected,
          Locked: KO.locked
        }),
        ariaPressed: KO.selected,
        onClick: () => {
          pO(KO.id)
        },
        children: [(0, ye.jsx)("div", {
          className: "SkyblockSkillIcon",
          children: (0, ye.jsx)(fb.b, {
            itemName: KO.icon,
            amount: 0
          })
        }), (0, ye.jsxs)("div", {
          className: "SkyblockSkillSummary",
          children: [(0, ye.jsxs)("div", {
            className: "SkyblockSkillTitle",
            children: [(0, ye.jsx)("strong", {
              children: KO.name
            }), (0, ye.jsx)("span", {
              children: KO.tier
            })]
          }), (0, ye.jsx)(Hb, {
            percent: KO.percent,
            label: `${KO.name}: ${KO.progress}`
          }), (0, ye.jsx)("span", {
            className: "SkyblockSkillXp",
            children: KO.progress
          })]
        })]
      })
    }

    function Be(OO) {
      let {
        collection: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)();
      return (0, ye.jsxs)("div", {
        className: "SkyblockSkillDetail SkyblockCollectionDetail",
        children: [(0, ye.jsx)("div", {
          className: "SkyblockSkillDetailIcon",
          children: (0, ye.jsx)(fb.b, {
            itemName: KO.icon,
            amount: 0
          })
        }), (0, ye.jsx)("h3", {
          children: KO.name
        }), (0, ye.jsx)("strong", {
          className: "SkyblockSkillDetailLevel",
          children: KO.tier
        }), (0, ye.jsx)("p", {
          children: KO.locked ? pO("skyblockGame:collectionLocked") : KO.count
        }), null !== KO.nextReward && (0, ye.jsxs)("div", {
          className: "SkyblockSkillBenefit",
          children: [(0, ye.jsx)("strong", {
            children: pO("skyblockGame:collectionNextReward")
          }), (0, ye.jsx)("span", {
            children: KO.nextReward
          })]
        }), (0, ye.jsx)(Hb, {
          percent: KO.percent,
          label: KO.progress
        }), (0, ye.jsx)("p", {
          children: KO.progress
        })]
      })
    }

    function Ze(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(Yp, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)(),
        bK = sb();
      return pO.enabled ? (0, ye.jsx)(re.d, {
        show: pO.open,
        close: KO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockCollectionsPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockCollectionsTitle",
          tabIndex: -1,
          ref: bK,
          onKeyDown: me,
          children: [(0, ye.jsxs)("header", {
            className: "SkyblockSkillsHeader",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockCollectionsTitle",
                children: XO("skyblockGame:collections")
              }), (0, ye.jsxs)("p", {
                children: [XO("skyblockGame:collectionsIntro"), " ", pO.tiersUnlocked]
              })]
            }), (0, ye.jsx)(Pb.i, {
              padIgnore: !0,
              onClick: KO.dismiss
            })]
          }), (0, ye.jsx)("div", {
            className: "SkyblockCollectionCategories",
            "data-pad-tabs": "1",
            children: pO.categories.map((OO => (0, ye.jsxs)(Pb.d, {
              className: Lb()("SkyblockCollectionCategory", {
                Selected: OO.selected
              }),
              ariaPressed: OO.selected,
              padTabSelected: OO.selected,
              onClick: () => {
                KO.selectCategory(OO.id)
              },
              children: [(0, ye.jsx)("span", {
                className: "SkyblockCollectionCategoryIcon",
                children: (0, ye.jsx)(fb.b, {
                  itemName: OO.icon,
                  amount: 0
                })
              }), (0, ye.jsxs)("span", {
                className: "SkyblockCollectionCategoryText",
                children: [(0, ye.jsx)("strong", {
                  children: OO.label
                }), (0, ye.jsx)("span", {
                  children: OO.tiers
                })]
              })]
            }, OO.id)))
          }), (0, ye.jsxs)("div", {
            className: "SkyblockSkillsBody",
            children: [(0, ye.jsx)("div", {
              className: "SkyblockSkillsList",
              "data-pad-select-on-focus": !0,
              children: pO.collections.map((OO => (0, ye.jsx)(cl, {
                collection: OO,
                select: KO.select
              }, OO.id)))
            }), pO.detail && (0, ye.jsx)(Be, {
              collection: pO.detail
            })]
          })]
        })
      }) : null
    }
    const Ge = ["completed", "active", "available", "locked"],
      ql = ["prerequisite", "acceptFirst", "sends", "awaits"];

    function xl(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(Bp, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)(),
        bK = sb();
      return pO.enabled ? (0, ye.jsx)(re.d, {
        show: pO.open,
        close: KO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockQuestGraphPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockQuestGraphTitle",
          tabIndex: -1,
          ref: bK,
          onKeyDown: me,
          children: [(0, ye.jsxs)("header", {
            className: "SkyblockSkillsHeader",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockQuestGraphTitle",
                children: XO("skyblockDevQuests:title")
              }), (0, ye.jsx)("p", {
                children: XO("skyblockDevQuests:intro")
              })]
            }), (0, ye.jsx)(Pb.i, {
              onClick: KO.dismiss
            })]
          }), (0, ye.jsxs)("div", {
            className: "SkyblockQuestGraphLegend",
            children: [Ge.map((OO => (0, ye.jsx)("span", {
              className: Lb()("SkyblockQuestGraphLegendState", OO),
              children: XO(`skyblockDevQuests:state_${OO}`)
            }, OO))), ql.map((OO => (0, ye.jsxs)("span", {
              className: "SkyblockQuestGraphLegendEdge",
              children: [(0, ye.jsx)("svg", {
                width: "28",
                height: "8",
                "aria-hidden": "true",
                children: (0, ye.jsx)("line", {
                  className: Lb()("SkyblockQuestGraphEdge", OO),
                  x1: "0",
                  y1: "4",
                  x2: "28",
                  y2: "4"
                })
              }), XO(`skyblockDevQuests:edge_${OO}`)]
            }, OO)))]
          }), (0, ye.jsx)("div", {
            className: "SkyblockQuestGraphScroll",
            children: (0, ye.jsxs)("div", {
              className: Lb()("SkyblockQuestGraphCanvas", {
                Planning: pO.planning
              }),
              style: {
                width: pO.width,
                height: pO.height
              },
              children: [(0, ye.jsxs)("svg", {
                className: "SkyblockQuestGraphEdges",
                width: pO.width,
                height: pO.height,
                "aria-hidden": "true",
                children: [(0, ye.jsx)("defs", {
                  children: (0, ye.jsx)("marker", {
                    id: "skyblockQuestGraphArrow",
                    viewBox: "0 0 8 8",
                    refX: "7",
                    refY: "4",
                    markerWidth: "6",
                    markerHeight: "6",
                    orient: "auto-start-reverse",
                    children: (0, ye.jsx)("path", {
                      className: "SkyblockQuestGraphArrow",
                      d: "M 0 0 L 8 4 L 0 8 z"
                    })
                  })
                }), pO.edges.map((OO => (0, ye.jsx)("path", {
                  className: Lb()("SkyblockQuestGraphEdge", OO.kind, {
                    InPlan: OO.inPlan
                  }),
                  d: OO.path,
                  markerEnd: "url(#skyblockQuestGraphArrow)"
                }, OO.key)))]
              }), pO.nodes.map((OO => (0, ye.jsxs)("button", {
                type: "button",
                className: Lb()("SkyblockQuestGraphNode", OO.state, {
                  InPlan: OO.inPlan,
                  Hovered: OO.hovered
                }),
                style: {
                  left: OO.left,
                  top: OO.top,
                  width: 190,
                  height: 52
                },
                title: OO.id,
                onMouseEnter: () => {
                  KO.hover(OO.id)
                },
                onMouseLeave: () => {
                  KO.hover(null)
                },
                onFocus: () => {
                  KO.hover(OO.id)
                },
                onBlur: () => {
                  KO.hover(null)
                },
                onClick: () => {
                  KO.jump(OO.id)
                },
                children: [(0, ye.jsx)("strong", {
                  children: OO.name
                }), (0, ye.jsx)("span", {
                  children: OO.detail
                })]
              }, OO.id)))]
            })
          })]
        })
      }) : null
    }
    const ne = ["skyblockGame:forgeStatPower", "skyblockGame:forgeStatDamage", "skyblockGame:forgeStatSpeed", "skyblockGame:forgeStatKnockback"],
      We = {
        "--impact": "250ms",
        "--hold": "50ms",
        "--pop-at": `${XX}ms`,
        "--forge-duration": "2150ms"
      },
      tl = Array.from({
        length: 18
      }, ((OO, KO) => ({
        "--ember-left": `${(4+92*(.618034*KO%1)).toFixed(1)}%`,
        "--ember-size": 3 + KO % 3 * 2 + "px",
        "--ember-drift": 14 * (KO % 5 - 2) + "px",
        "--ember-duration": `${(5.5+7*KO%5*.9).toFixed(1)}s`,
        "--ember-delay": `${(-1.37*KO%8).toFixed(2)}s`
      })));

    function kl(OO) {
      if (OO.style.removeProperty("--part-size"), null === OO.parentElement || "wrap" === getComputedStyle(OO.parentElement).flexWrap) return;
      const KO = [...OO.children],
        pO = getComputedStyle(OO),
        XO = parseFloat(pO.getPropertyValue("--part-size")) * parseFloat(getComputedStyle(document.documentElement).fontSize),
        bK = (OO.clientHeight - parseFloat(pO.rowGap) * (KO.length - 1)) / KO.length,
        eO = KO.map((OO => {
          const KO = getComputedStyle(OO),
            pO = OO.querySelector("h3"),
            eO = OO.querySelector(".SkyblockForgeParts");
          if (null === pO || null === eO) return XO;
          const lO = bK - parseFloat(KO.paddingTop) - parseFloat(KO.paddingBottom) - pO.offsetHeight - parseFloat(getComputedStyle(pO).marginBottom),
            vK = parseFloat(getComputedStyle(eO).columnGap),
            CO = eO.children.length;
          let hO = 0;
          for (let XO = 1; XO <= CO; XO++) {
            const OO = Math.ceil(CO / XO);
            hO = Math.max(hO, Math.min((eO.clientWidth - vK * (XO - 1)) / XO, (lO - vK * (OO - 1)) / OO))
          }
          return hO
        }));
      OO.style.setProperty("--part-size", `${Math.floor(Math.max(XO,Math.min(...eO)))}px`)
    }

    function Ue(OO) {
      var KO, pO, XO, eO, lO;
      let {
        controller: vK
      } = OO;
      const CO = (0, Ib.h)(DX, vK.getSnapshot()),
        {
          t: hO
        } = (0, Nb.D)(),
        DO = sb(),
        MO = function() {
          const OO = (0, IO.useRef)(null),
            KO = (0, IO.useRef)(null);
          return (0, IO.useLayoutEffect)((() => {
            null !== OO.current && kl(OO.current)
          })), (0, IO.useCallback)((pO => {
            var XO;
            null === (XO = KO.current) || void 0 === XO || XO.disconnect(), KO.current = null, OO.current = pO, null !== pO && (KO.current = new ResizeObserver((() => {
              kl(pO)
            })), KO.current.observe(pO))
          }), [])
        }(),
        aK = function(OO) {
          const KO = (0, IO.useRef)(null);
          return (0, IO.useLayoutEffect)((() => {
            const OO = KO.current;
            if (null !== OO) {
              OO.style.removeProperty("font-size");
              for (let KO = 1.7; KO > 1.1 && OO.scrollWidth > OO.clientWidth; KO -= .1) OO.style.fontSize = KO - .1 + "rem"
            }
          }), [OO]), (0, IO.useCallback)((OO => {
            KO.current = OO
          }), [])
        }(null === (KO = CO.preview) || void 0 === KO ? void 0 : KO.name),
        oO = (0, IO.useRef)(null),
        FO = (0, IO.useRef)({}),
        VO = CO.forging,
        LO = null !== (pO = null === VO || void 0 === VO ? void 0 : VO.preview.tier) && void 0 !== pO ? pO : 0,
        QO = null !== (XO = null === VO || void 0 === VO ? void 0 : VO.preview.named) && void 0 !== XO && XO,
        zK = (0, IO.useMemo)((() => {
          return null === VO ? null : {
            flames: (OO = LO, KO = QO, Array.from({
              length: 26 + 6 * OO + (KO ? 20 : 0)
            }, ((OO, KO) => {
              const pO = KO < 6,
                XO = Math.random() * Math.PI * 2,
                bK = pO ? 5 + 3 * Math.random() : 6 + Math.random() ** 1.3 * 8,
                eO = Math.cos(XO) * bK,
                lO = Math.sin(XO) * bK - 2 - 3 * Math.random(),
                vK = Math.random(),
                [CO, hO, DO] = pO ? ["var(--ember-glow)", .8 + .2 * Math.random(), 1100 + 200 * Math.random()] : vK < .15 ? ["#fff6c2", .3 + .2 * Math.random(), 350 + 150 * Math.random()] : vK < .45 ? ["var(--tier)", .35 + .45 * Math.random(), 500 + 300 * Math.random()] : [vK < .7 ? "var(--ember)" : "var(--ember-glow)", .35 + .5 * Math.random(), 500 + 300 * Math.random()];
              return {
                "--c": CO,
                "--x0": `${(.15*eO).toFixed(2)}rem`,
                "--y0": `${(.15*lO).toFixed(2)}rem`,
                "--x": `${eO.toFixed(2)}rem`,
                "--y": `${lO.toFixed(2)}rem`,
                "--spin": `${Math.round(360*(Math.random()-.5))}deg`,
                "--size": `${hO.toFixed(2)}rem`,
                "--duration": `${Math.round(DO)}ms`,
                "--delay": `${Math.round(80*Math.random())}ms`
              }
            }))),
            sparks: lX(LO, QO)
          };
          var OO, KO
        }), [null === VO || void 0 === VO ? void 0 : VO.id]);
      if (!CO.enabled) return null;
      const AO = CO.preview,
        fO = CO.arriving,
        dO = null !== fO && !fO.sameSword,
        TO = null !== AO && (0, ye.jsx)(fb.b, {
          itemName: AO.baseSword,
          amount: 0,
          enchantmentTier: AO.enchantmentTier
        });
      return (0, ye.jsx)(re.d, {
        show: CO.open,
        close: vK.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockForgePanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockForgeTitle",
          tabIndex: -1,
          ref: DO,
          onKeyDown: me,
          children: [(0, ye.jsx)("div", {
            className: "SkyblockForgeEmbers",
            "aria-hidden": "true",
            children: tl.map(((OO, KO) => (0, ye.jsx)("span", {
              style: OO
            }, KO)))
          }), (0, ye.jsxs)("header", {
            className: "SkyblockSkillsHeader",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockForgeTitle",
                children: hO("skyblockGame:forgeTitle")
              }), (0, ye.jsx)("p", {
                children: hO("skyblockGame:forgeIntro")
              })]
            }), (0, ye.jsx)(Pb.i, {
              onClick: vK.dismiss
            })]
          }), (0, ye.jsxs)("div", {
            className: "SkyblockForgeBody",
            children: [(0, ye.jsx)("div", {
              ref: MO,
              className: Lb()("SkyblockForgeSlots", {
                Locked: null !== VO
              }),
              children: CO.slots.map((OO => (0, ye.jsxs)("div", {
                className: "SkyblockForgeSlot",
                children: [(0, ye.jsx)("h3", {
                  children: OO.label
                }), (0, ye.jsx)("div", {
                  className: "SkyblockForgeParts",
                  children: OO.parts.map((KO => (0, ye.jsx)("button", {
                    type: "button",
                    className: Lb()("SkyblockForgePart", {
                      Selected: KO.selected,
                      Missing: KO.placeholder
                    }),
                    disabled: KO.placeholder,
                    title: KO.placeholder ? hO("skyblockGame:forgePickParts") : KO.itemName,
                    "aria-pressed": KO.selected,
                    onClick: () => {
                      vK.select(OO.kind, KO.material)
                    },
                    children: (0, ye.jsx)(fb.b, {
                      itemName: KO.itemName,
                      amount: KO.owned
                    })
                  }, KO.material)))
                })]
              }, OO.kind)))
            }), (0, ye.jsxs)("div", {
              className: Lb()("SkyblockForgeAnvil", {
                Named: null === AO || void 0 === AO ? void 0 : AO.named
              }),
              style: {
                "--tier": null === AO ? "transparent" : bK.hb[AO.enchantmentTier]
              },
              children: [(0, ye.jsxs)("div", {
                className: Lb()("SkyblockForgeAltar", {
                  Forging: null !== VO
                }),
                style: null === VO ? void 0 : We,
                children: [(0, ye.jsxs)("div", {
                  className: Lb()("SkyblockForgeMount", {
                    Arrive: null !== fO
                  }),
                  children: [null === AO && (0, ye.jsx)("div", {
                    className: "SkyblockForgeSword Unformed",
                    children: (0, ye.jsx)(fb.b, {
                      itemName: CO.unformedSword,
                      amount: 0
                    })
                  }), null !== AO && (0, ye.jsx)("div", {
                    className: "SkyblockForgeGlow"
                  }), null !== AO && null === VO && (0, ye.jsx)("div", {
                    ref: oO,
                    className: "SkyblockForgeFloat",
                    children: (0, ye.jsx)("div", {
                      className: "SkyblockForgeSword",
                      children: TO
                    })
                  }), null !== AO && (0, ye.jsx)("div", {
                    className: "SkyblockForgeAura",
                    "aria-hidden": "true",
                    children: eX.map(((OO, KO) => (0, ye.jsx)("span", {
                      className: Lb()({
                        Rune: "" !== OO.rune
                      }),
                      style: OO.style,
                      children: OO.rune
                    }, KO)))
                  }), null !== VO && null !== zK && (0, ye.jsxs)(ye.Fragment, {
                    children: [(0, ye.jsx)("div", {
                      className: "SkyblockForgeFlash"
                    }), (0, ye.jsx)("div", {
                      className: "SkyblockForgeFlames",
                      children: zK.flames.map(((OO, KO) => (0, ye.jsx)("span", {
                        style: OO
                      }, KO)))
                    }), (0, ye.jsx)("div", {
                      className: "SkyblockForgeSettle",
                      style: FO.current,
                      children: (0, ye.jsx)("div", {
                        className: "SkyblockForgeSword",
                        children: TO
                      })
                    }), (0, ye.jsx)("div", {
                      className: "SkyblockForgeHitFlash"
                    }), (0, ye.jsx)("div", {
                      className: "SkyblockForgeShock"
                    }), (LO >= 4 || QO) && (0, ye.jsx)("div", {
                      className: "SkyblockForgeShock Echo"
                    }), (0, ye.jsx)("div", {
                      className: "SkyblockForgeSparks",
                      children: zK.sparks.map(((OO, KO) => (0, ye.jsx)("span", {
                        style: OO
                      }, KO)))
                    }), (0, ye.jsx)("div", {
                      className: "SkyblockForgeSwing"
                    })]
                  })]
                }), (0, ye.jsx)("p", {
                  className: Lb()("SkyblockForgeStatus", null === (eO = CO.status) || void 0 === eO ? void 0 : eO.tone),
                  children: null === (lO = CO.status) || void 0 === lO ? void 0 : lO.text
                })]
              }), null === AO && (0, ye.jsx)("p", {
                className: Lb()("SkyblockForgeName Waiting", {
                  ArriveText: dO
                }),
                children: hO(CO.anyParts ? "skyblockGame:forgePickToPreview" : "skyblockGame:forgePickParts")
              }), null !== AO && (0, ye.jsx)("h3", {
                ref: aK,
                className: Lb()("SkyblockForgeName", {
                  ArriveText: dO
                }),
                title: AO.name,
                children: AO.name
              }), (null === AO || void 0 === AO ? void 0 : AO.named) && (0, ye.jsx)("span", {
                className: "SkyblockForgeSecret",
                children: hO("skyblockGame:forgeSecret")
              }), (0, ye.jsxs)(Pb.s, {
                className: "SkyblockForgeButton",
                disabled: !CO.canForge,
                title: null === AO ? void 0 : hO("skyblockGame:forgeCoalOwned", {
                  owned: String(CO.coalOwned)
                }),
                onClick: () => {
                  FO.current = function(OO) {
                    const KO = null === OO ? "none" : getComputedStyle(OO).transform,
                      pO = new DOMMatrixReadOnly("none" === KO ? void 0 : KO);
                    return {
                      "--settle-y": `${pO.f.toFixed(2)}px`,
                      "--settle-turn": `${(180*Math.atan2(pO.b,pO.a)/Math.PI).toFixed(2)}deg`
                    }
                  }(oO.current), hX(), vK.forge(!window.matchMedia("(prefers-reduced-motion: reduce)").matches)
                },
                children: [hO("skyblockGame:forgeButton"), null !== AO && (0, ye.jsxs)("span", {
                  className: Lb()("SkyblockForgeCost", {
                    Short: AO.coalShort
                  }),
                  children: [(0, ye.jsx)("span", {
                    className: "SkyblockForgeCoal",
                    children: (0, ye.jsx)(fb.b, {
                      itemName: np.c,
                      amount: 0
                    })
                  }), AO.coalCost]
                })]
              })]
            }), (0, ye.jsxs)("div", {
              className: Lb()("SkyblockForgeDetails", {
                Named: null === AO || void 0 === AO ? void 0 : AO.named
              }),
              children: [(0, ye.jsx)("p", {
                className: Lb()("SkyblockForgeLore", {
                  ArriveText: dO
                }),
                title: null === AO || void 0 === AO ? void 0 : AO.lore,
                children: null === AO || void 0 === AO ? void 0 : AO.lore
              }), (0, ye.jsxs)("dl", {
                className: Lb()("SkyblockForgeStats", {
                  ArriveText: dO
                }),
                children: [null === AO && ne.map((OO => (0, ye.jsxs)("div", {
                  className: "SkyblockForgeStat Empty",
                  children: [(0, ye.jsx)("dt", {
                    children: hO(OO)
                  }), (0, ye.jsx)("dd", {
                    children: "\u2013"
                  })]
                }, OO))), null === AO || void 0 === AO ? void 0 : AO.stats.map((OO => (0, ye.jsxs)("div", {
                  className: Lb()("SkyblockForgeStat", {
                    Better: OO.better
                  }),
                  children: [(0, ye.jsx)("dt", {
                    children: OO.label
                  }), (0, ye.jsx)("dd", {
                    children: OO.value
                  })]
                }, OO.label)))]
              }), (0, ye.jsx)("ul", {
                className: Lb()("SkyblockForgeEffects", {
                  ArriveText: dO
                }),
                children: null === AO || void 0 === AO ? void 0 : AO.effects.map((OO => (0, ye.jsx)("li", {
                  children: OO
                }, OO)))
              })]
            })]
          })]
        })
      })
    }
    const Ol = "Doom Rivet",
      Kl = "Doom Crest";

    function pl(OO) {
      let {
        itemName: KO,
        amount: pO,
        owned: XO
      } = OO;
      return (0, ye.jsxs)("span", {
        className: Lb()("SkyblockSmugglerPrice", {
          Short: pO > XO
        }),
        children: [(0, ye.jsx)("span", {
          className: "SkyblockSmugglerPriceIcon",
          children: (0, ye.jsx)(fb.b, {
            itemName: KO,
            amount: 0
          })
        }), (0, ye.jsx)("span", {
          children: pO
        })]
      })
    }

    function Xl(OO) {
      return OO.justBought ? "skyblockGame:smugglerJustBought" : OO.soldOut ? "skyblockGame:smugglerSoldOut" : "skyblockGame:smugglerBuy"
    }

    function bv(OO) {
      let {
        deal: KO,
        view: pO,
        buy: XO
      } = OO;
      const {
        t: bK
      } = (0, Nb.D)();
      return (0, ye.jsxs)("div", {
        className: Lb()("SkyblockSmugglerPocket", {
          Bought: KO.justBought,
          Unaffordable: !KO.affordable,
          SoldOut: KO.soldOut && !KO.justBought
        }),
        children: [(0, ye.jsx)("span", {
          className: "SkyblockSmugglerBuckle",
          "aria-hidden": "true"
        }), (0, ye.jsxs)("div", {
          className: "SkyblockSmugglerGoods",
          children: [(0, ye.jsx)(fb.b, {
            itemName: KO.itemName,
            amount: 0,
            enchantmentTier: KO.enchantmentTier
          }), KO.amount > 1 && (0, ye.jsx)("span", {
            className: "SkyblockSmugglerAmount",
            children: bK("skyblockGame:smugglerAmount", {
              amount: KO.amount
            })
          })]
        }), (0, ye.jsx)("h3", {
          children: KO.displayName
        }), (0, ye.jsxs)("div", {
          className: "SkyblockSmugglerDeal",
          children: [(0, ye.jsxs)("div", {
            className: "SkyblockSmugglerPrices",
            children: [KO.rivets > 0 && (0, ye.jsx)(pl, {
              itemName: Ol,
              amount: KO.rivets,
              owned: pO.rivetsOwned
            }), KO.crests > 0 && (0, ye.jsx)(pl, {
              itemName: Kl,
              amount: KO.crests,
              owned: pO.crestsOwned
            })]
          }), (0, ye.jsx)(Pb.d, {
            className: "SkyblockSmugglerBuy",
            disabled: KO.soldOut || !KO.affordable || pO.pending,
            onClick: () => {
              XO(KO.slot)
            },
            children: bK(Xl(KO))
          })]
        })]
      }, KO.justBought ? pO.boughtCount : 0)
    }

    function el(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(oX, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)(),
        bK = sb();
      return pO.enabled ? (0, ye.jsx)(re.d, {
        show: pO.open,
        close: KO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockSmugglerPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockSmugglerTitle",
          tabIndex: -1,
          ref: bK,
          onKeyDown: me,
          children: [(0, ye.jsx)("span", {
            className: "SkyblockSmugglerStrap Left",
            "aria-hidden": "true"
          }), (0, ye.jsx)("span", {
            className: "SkyblockSmugglerStrap Right",
            "aria-hidden": "true"
          }), (0, ye.jsxs)("header", {
            className: "SkyblockSmugglerFlap",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockSmugglerTitle",
                children: XO("skyblockGame:smugglerTitle")
              }), (0, ye.jsx)("p", {
                children: XO("skyblockGame:smugglerIntro")
              })]
            }), (0, ye.jsxs)("div", {
              className: "SkyblockSmugglerFlapActions",
              children: [(0, ye.jsxs)("div", {
                className: "SkyblockSmugglerWallet",
                children: [(0, ye.jsx)(pl, {
                  itemName: Ol,
                  amount: pO.rivetsOwned,
                  owned: pO.rivetsOwned
                }), (0, ye.jsx)(pl, {
                  itemName: Kl,
                  amount: pO.crestsOwned,
                  owned: pO.crestsOwned
                })]
              }), (0, ye.jsx)(Pb.i, {
                onClick: KO.dismiss
              })]
            })]
          }), (0, ye.jsx)("div", {
            className: "SkyblockSmugglerPockets",
            children: pO.deals.map((OO => (0, ye.jsx)(bv, {
              deal: OO,
              view: pO,
              buy: KO.buy
            }, OO.slot)))
          }), (0, ye.jsxs)("footer", {
            className: "SkyblockSmugglerBedroll",
            children: [(0, ye.jsx)("span", {
              className: "SkyblockSmugglerRotates",
              children: pO.rotatesText
            }), null !== pO.status && (0, ye.jsx)("span", {
              className: Lb()("SkyblockSmugglerStatus", pO.status.tone),
              children: pO.status.text
            })]
          })]
        })
      }) : null
    }

    function ll(OO) {
      let {
        phase: KO,
        className: pO
      } = OO;
      return (0, ye.jsx)("span", {
        className: Lb()("SkyblockMoon", `Moon-${KO}`, pO),
        "aria-hidden": "true"
      })
    }

    function vv(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(LX, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)();
      return pO.enabled ? (0, ye.jsx)(ze.h, {
        placement: "statBars",
        children: (0, ye.jsx)("button", {
          type: "button",
          tabIndex: -1,
          className: Lb()("SkyblockPassageChip", pO.open && "Open"),
          "aria-label": XO("skyblockGame:passageChipLabel", {
            phase: pO.phaseName
          }),
          title: XO("skyblockGame:passageChipLabel", {
            phase: pO.phaseName
          }),
          onMouseDown: OO => {
            OO.preventDefault()
          },
          onClick: KO.toggle,
          children: (0, ye.jsx)(ll, {
            phase: pO.phase
          }, pO.phase)
        })
      }) : null
    }

    function Cl(OO) {
      let {
        fish: KO
      } = OO;
      return (0, ye.jsxs)("li", {
        className: "SkyblockPassageFish",
        children: [(0, ye.jsx)("span", {
          className: "SkyblockPassageFishIcon",
          children: (0, ye.jsx)(fb.b, {
            itemName: KO.itemName,
            amount: 0
          })
        }), (0, ye.jsxs)("span", {
          className: "SkyblockPassageFishText",
          children: [(0, ye.jsx)("span", {
            className: "SkyblockPassageFishName",
            children: KO.displayName
          }), (0, ye.jsx)("span", {
            className: "SkyblockPassageFishWhere",
            children: KO.where
          })]
        })]
      })
    }

    function hl(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(LX, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)(),
        bK = sb();
      return pO.enabled ? (0, ye.jsx)(re.d, {
        show: pO.open,
        close: KO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockPassagePanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockPassageTitle",
          tabIndex: -1,
          ref: bK,
          onKeyDown: me,
          children: [(0, ye.jsxs)("header", {
            className: "SkyblockPassageHeader",
            children: [(0, ye.jsx)(ll, {
              phase: pO.phase,
              className: "SkyblockPassageHeaderMoon"
            }), (0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockPassageTitle",
                children: XO("skyblockGame:passageTitle")
              }), (0, ye.jsx)("p", {
                className: "SkyblockPassagePhase",
                children: pO.phaseName
              })]
            }), (0, ye.jsx)(Pb.i, {
              padIgnore: !0,
              onClick: KO.dismiss
            })]
          }), (0, ye.jsx)("p", {
            className: "SkyblockPassageIntro",
            children: XO("skyblockGame:passageIntro")
          }), (0, ye.jsxs)("div", {
            className: "SkyblockPassageBody",
            children: [(0, ye.jsxs)("section", {
              className: "SkyblockPassageColumn",
              children: [(0, ye.jsx)("h3", {
                children: XO("skyblockGame:passageVisiting")
              }), (0, ye.jsx)("ul", {
                className: "SkyblockPassageList",
                children: pO.visitors.map((OO => (0, ye.jsx)(Cl, {
                  fish: OO
                }, OO.itemName)))
              })]
            }), (0, ye.jsxs)("section", {
              className: "SkyblockPassageColumn",
              children: [null !== pO.resting && (0, ye.jsxs)(ye.Fragment, {
                children: [(0, ye.jsx)("h3", {
                  children: XO("skyblockGame:passageResting")
                }), (0, ye.jsx)("ul", {
                  className: "SkyblockPassageList Resting",
                  children: (0, ye.jsx)(Cl, {
                    fish: pO.resting
                  })
                })]
              }), (0, ye.jsxs)("p", {
                className: "SkyblockPassageNext",
                children: [(0, ye.jsx)(ll, {
                  phase: pO.nextPhase
                }), (0, ye.jsx)("span", {
                  children: pO.next
                })]
              })]
            })]
          })]
        })
      }) : null
    }

    function Dl() {
      return (0, ye.jsx)("span", {
        className: "SkyblockLampLightSparkle",
        "aria-hidden": "true",
        children: [0, 1, 2, 3, 4, 5].map((OO => (0, ye.jsx)("i", {
          style: {
            "--sparkle-index": OO
          }
        }, OO)))
      })
    }

    function Ml(OO) {
      var KO;
      let {
        charm: pO,
        view: XO,
        controller: bK
      } = OO;
      const {
        t: eO
      } = (0, Nb.D)(), lO = XO.shop, vK = (null === (KO = XO.sparkle) || void 0 === KO ? void 0 : KO.id) === pO.id;
      return (0, ye.jsxs)("li", {
        className: Lb()("SkyblockLampLightCharm", pO.owned && "Owned", pO.socketed && "Socketed"),
        children: [vK && (0, ye.jsx)(Dl, {}, XO.sparkle.count), (0, ye.jsx)("h4", {
          children: pO.name
        }), (0, ye.jsx)("p", {
          className: "SkyblockLampLightEffect",
          children: pO.effect
        }), (0, ye.jsx)("ul", {
          className: "SkyblockLampLightOdds",
          children: pO.lines.map((OO => (0, ye.jsxs)("li", {
            className: Lb()("SkyblockLampLightOddsLine", "better" === OO.tone ? "Better" : "worse" === OO.tone ? "Worse" : "Same"),
            children: [(0, ye.jsx)("span", {
              className: "Before",
              children: OO.before
            }), (0, ye.jsx)("span", {
              className: "Arrow",
              children: "\u2192"
            }), (0, ye.jsx)("span", {
              className: "After",
              children: OO.after
            })]
          }, OO.label)))
        }), (0, ye.jsx)("div", {
          className: "SkyblockLampLightCharmAction",
          children: pO.owned ? pO.socketed ? (0, ye.jsxs)(ye.Fragment, {
            children: [(0, ye.jsx)("span", {
              className: "SkyblockLampLightBadge",
              children: eO("skyblockGame:lampLightSocketed")
            }), (0, ye.jsx)(Pb.S, {
              disabled: !XO.canCommand,
              ariaLabel: eO("skyblockGame:lampLightRemoveLabel", {
                charm: pO.name
              }),
              onClick: () => {
                bK.socket(null)
              },
              children: eO("skyblockGame:lampLightRemove")
            })]
          }) : (0, ye.jsx)(Pb.d, {
            disabled: !XO.canCommand || !lO.heldRod,
            ariaLabel: eO("skyblockGame:lampLightSocketLabel", {
              charm: pO.name
            }),
            onClick: () => {
              bK.socket(pO.id)
            },
            children: eO("skyblockGame:lampLightSocket")
          }) : (0, ye.jsx)(Pb.d, {
            disabled: !XO.canCommand || !pO.affordable,
            ariaLabel: eO("skyblockGame:lampLightBuyLabel", {
              item: pO.name,
              cost: pO.cost
            }),
            onClick: () => {
              bK.buy(pO.id)
            },
            children: pO.cost
          })
        })]
      })
    }

    function av(OO) {
      var KO;
      let {
        tint: pO,
        view: XO,
        controller: bK
      } = OO;
      const {
        t: eO
      } = (0, Nb.D)();
      return (0, ye.jsxs)("li", {
        className: Lb()("SkyblockLampLightTint", pO.wearing && "Wearing"),
        style: {
          "--tint-colour": pO.colour
        },
        children: [(null === (KO = XO.sparkle) || void 0 === KO ? void 0 : KO.id) === pO.id && (0, ye.jsx)(Dl, {}, XO.sparkle.count), (0, ye.jsx)("span", {
          className: "SkyblockLampLightSwatch",
          "aria-hidden": "true"
        }), (0, ye.jsx)("span", {
          className: "SkyblockLampLightTintName",
          children: pO.name
        }), pO.wearing ? (0, ye.jsx)("span", {
          className: "SkyblockLampLightBadge",
          children: eO("skyblockGame:lampLightWearing")
        }) : (0, ye.jsx)(Pb.d, {
          disabled: !XO.canCommand || !pO.owned && !pO.affordable,
          ariaLabel: pO.owned ? eO("skyblockGame:lampLightWearLabel", {
            tint: pO.name
          }) : eO("skyblockGame:lampLightBuyLabel", {
            item: pO.name,
            cost: pO.cost
          }),
          onClick: () => {
            pO.owned ? bK.wearTint(pO.id) : bK.buy(pO.id)
          },
          children: pO.owned ? eO("skyblockGame:lampLightWear") : pO.cost
        })]
      })
    }

    function ol(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(YX, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)(),
        bK = pO.shop;
      return (0, ye.jsxs)("div", {
        className: "SkyblockLampLightTab",
        children: [(0, ye.jsxs)("div", {
          className: "SkyblockLampLightTop",
          children: [(0, ye.jsx)("span", {
            className: "SkyblockLampLightBalance",
            children: pO.balance
          }), (0, ye.jsxs)("button", {
            type: "button",
            role: "switch",
            "aria-checked": pO.releasing,
            className: Lb()("SkyblockLampLightSwitch", pO.releasing && "On"),
            disabled: pO.releasing ? "ready" !== pO.status : !pO.canCommand,
            onClick: () => {
              KO.setRelease(!pO.releasing)
            },
            children: [(0, ye.jsx)("span", {
              className: "SkyblockLampLightSwitchTrack",
              "aria-hidden": "true",
              children: (0, ye.jsx)("span", {
                className: "SkyblockLampLightSwitchKnob"
              })
            }), XO("skyblockGame:lampLightRelease")]
          }), (0, ye.jsx)("span", {
            className: "SkyblockLampLightHint",
            children: XO("skyblockGame:lampLightReleaseHint")
          })]
        }), null !== pO.notice && (0, ye.jsx)("p", {
          className: "SkyblockLampLightNotice",
          role: "status",
          children: pO.notice
        }), null !== bK && (0, ye.jsxs)(ye.Fragment, {
          children: [(0, ye.jsxs)("div", {
            className: "SkyblockLampLightSectionHead",
            children: [(0, ye.jsx)("h3", {
              children: XO("skyblockGame:lampLightCharms")
            }), (0, ye.jsx)("span", {
              className: "SkyblockLampLightOddsFor",
              children: bK.oddsFor
            }), (0, ye.jsx)("div", {
              className: "SkyblockLampLightSituations",
              role: "group",
              children: ["open", "bloom"].map((OO => (0, ye.jsx)("button", {
                type: "button",
                "aria-pressed": pO.situation === OO,
                className: Lb()("SkyblockLampLightSituation", pO.situation === OO && "Selected"),
                onClick: () => {
                  KO.setSituation(OO)
                },
                children: XO("open" === OO ? "skyblockGame:lampLightOpenWater" : "skyblockGame:lampLightInBloom")
              }, OO)))
            })]
          }), !bK.heldRod && (0, ye.jsx)("p", {
            className: "SkyblockLampLightHoldRod",
            children: XO("skyblockGame:lampLightHoldRod")
          }), (0, ye.jsx)("ul", {
            className: "SkyblockLampLightCharms",
            children: bK.charms.map((OO => (0, ye.jsx)(Ml, {
              charm: OO,
              view: pO,
              controller: KO
            }, OO.id)))
          }), (0, ye.jsx)("div", {
            className: "SkyblockLampLightSectionHead",
            children: (0, ye.jsx)("h3", {
              children: XO("skyblockGame:lampLightTints")
            })
          }), (0, ye.jsxs)("ul", {
            className: "SkyblockLampLightTints",
            children: [(0, ye.jsxs)("li", {
              className: Lb()("SkyblockLampLightTint", "Islands", bK.wearingIslandColours && "Wearing"),
              children: [(0, ye.jsx)("span", {
                className: "SkyblockLampLightSwatch",
                "aria-hidden": "true"
              }), (0, ye.jsx)("span", {
                className: "SkyblockLampLightTintName",
                children: XO("skyblockGame:lampLightIslandColours")
              }), bK.wearingIslandColours ? (0, ye.jsx)("span", {
                className: "SkyblockLampLightBadge",
                children: XO("skyblockGame:lampLightWearing")
              }) : (0, ye.jsx)(Pb.d, {
                disabled: !pO.canCommand,
                ariaLabel: XO("skyblockGame:lampLightWearLabel", {
                  tint: XO("skyblockGame:lampLightIslandColours")
                }),
                onClick: () => {
                  KO.wearTint(null)
                },
                children: XO("skyblockGame:lampLightWear")
              })]
            }), bK.tints.map((OO => (0, ye.jsx)(av, {
              tint: OO,
              view: pO,
              controller: KO
            }, OO.id)))]
          })]
        })]
      })
    }

    function Fl(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(YX, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)();
      return pO.releasing ? (0, ye.jsx)(ze.h, {
        children: (0, ye.jsxs)("button", {
          type: "button",
          className: "SkyblockLampLightPill",
          onClick: () => {
            KO.setRelease(!1)
          },
          children: [(0, ye.jsx)("span", {
            className: "SkyblockLampLightPillOrb",
            "aria-hidden": "true"
          }), (0, ye.jsxs)("span", {
            className: "SkyblockLampLightPillText SmallTextBold",
            children: [XO("skyblockGame:lampLightReleasing"), " \xb7 ", pO.balance]
          }), (0, ye.jsx)("span", {
            className: "SkyblockLampLightPillStop SmallTextBold",
            children: XO("skyblockGame:lampLightKeepCatches")
          }), null !== pO.gained && (0, ye.jsx)("span", {
            className: "SkyblockLampLightPillGain SmallTextBold",
            "aria-hidden": "true",
            children: pO.gained.text
          }, pO.gained.count)]
        })
      }) : null
    }

    function Vl(OO) {
      let {
        island: KO,
        view: pO,
        aim: XO
      } = OO;
      const {
        t: bK
      } = (0, Nb.D)(), eO = KO.featuredFish;
      return (0, ye.jsxs)("li", {
        className: Lb()("SkyblockKeepersChairIsland", `Island-${KO.id}`, KO.favoured && "Aimed", !KO.relit && "Dark"),
        children: [(0, ye.jsx)("h3", {
          children: KO.name
        }), KO.relit && null !== eO ? (0, ye.jsxs)("div", {
          className: "SkyblockKeepersChairNotice",
          children: [(0, ye.jsx)("span", {
            className: "SkyblockKeepersChairNoticeLabel",
            children: bK("skyblockGame:keepersChairTideNotice")
          }), (0, ye.jsx)("span", {
            className: "SkyblockKeepersChairFish",
            children: (0, ye.jsx)(fb.b, {
              itemName: eO.itemName,
              amount: 0
            })
          }), (0, ye.jsx)("span", {
            className: "SkyblockKeepersChairFishName",
            children: eO.displayName
          })]
        }) : (0, ye.jsx)("div", {
          className: "SkyblockKeepersChairNotice",
          children: (0, ye.jsx)("span", {
            className: "SkyblockKeepersChairDarkLens",
            children: bK("skyblockGame:keepersChairDark")
          })
        }), KO.relit && (KO.favoured ? (0, ye.jsx)("span", {
          className: "SkyblockKeepersChairAimedBadge",
          children: bK("skyblockGame:keepersChairAimed")
        }) : (0, ye.jsx)(Pb.d, {
          className: "SkyblockKeepersChairAim",
          disabled: !pO.canAim,
          ariaLabel: bK("skyblockGame:keepersChairAimLabel", {
            island: KO.name
          }),
          onClick: () => {
            XO(KO.id)
          },
          children: bK("skyblockGame:keepersChairAim")
        }))]
      }, KO.favoured ? pO.aimedCount : 0)
    }

    function Ll(OO) {
      let {
        controller: KO,
        lampLight: pO
      } = OO;
      const XO = (0, Ib.h)(TX, KO.getSnapshot()),
        bK = (0, Ib.h)(YX, pO.getSnapshot()),
        [eO, lO] = (0, IO.useState)("lamp"),
        {
          t: vK
        } = (0, Nb.D)(),
        CO = sb();
      if (!XO.enabled) return null;
      const hO = "light" === eO && bK.enabled;
      return (0, ye.jsx)(re.d, {
        show: XO.open,
        close: KO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: Lb()("SkyblockSkillsPanel", "SkyblockKeepersChairPanel", hO && "OnLampLight"),
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockKeepersChairTitle",
          tabIndex: -1,
          ref: CO,
          onKeyDown: me,
          children: [(0, ye.jsxs)("header", {
            className: "SkyblockKeepersChairHeader",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockKeepersChairTitle",
                children: vK("skyblockGame:keepersChairTitle")
              }), (0, ye.jsx)("p", {
                children: vK(hO ? "skyblockGame:keeperWickLampLightWelcome" : "skyblockGame:keeperWickKeepersChairWelcome")
              })]
            }), (0, ye.jsx)(Pb.i, {
              padIgnore: !0,
              ariaLabel: vK("skyblockGame:keepersChairClose"),
              onClick: KO.dismiss
            })]
          }), bK.enabled && (0, ye.jsx)("div", {
            className: "SkyblockKeepersChairTabs",
            role: "tablist",
            "data-pad-tabs": "1",
            children: ["lamp", "light"].map((OO => (0, ye.jsxs)("button", {
              type: "button",
              role: "tab",
              "aria-selected": "light" === OO === hO,
              "data-pad-tab": !0,
              "data-pad-selected": "light" === OO === hO ? "true" : void 0,
              className: Lb()("SkyblockKeepersChairTab", "light" === OO === hO && "Selected"),
              onClick: () => {
                lO(OO)
              },
              children: [vK("lamp" === OO ? "skyblockGame:lampLightChairTab" : "skyblockGame:lampLightTab"), "light" === OO && (0, ye.jsx)("span", {
                className: "SkyblockKeepersChairTabBalance",
                children: bK.balance
              })]
            }, OO)))
          }), hO ? (0, ye.jsx)(ol, {
            controller: pO
          }) : (0, ye.jsx)(Ql, {
            view: XO,
            controller: KO
          })]
        })
      })
    }

    function Ql(OO) {
      let {
        view: KO,
        controller: pO
      } = OO;
      const {
        t: XO
      } = (0, Nb.D)();
      return (0, ye.jsxs)(ye.Fragment, {
        children: [(0, ye.jsx)("ul", {
          className: "SkyblockKeepersChairIslands",
          children: KO.islands.map((OO => (0, ye.jsx)(Vl, {
            island: OO,
            view: KO,
            aim: pO.aim
          }, OO.id)))
        }), null !== KO.almanac && (0, ye.jsxs)("div", {
          className: "SkyblockKeepersChairAlmanac",
          children: [(0, ye.jsx)("span", {
            className: "SkyblockKeepersChairAlmanacLabel",
            children: XO("skyblockGame:passageTitle")
          }), (0, ye.jsxs)("span", {
            className: "SkyblockKeepersChairAlmanacWeek",
            children: [(0, ye.jsx)(ll, {
              phase: KO.almanac.phase
            }), KO.almanac.phaseName]
          }), (0, ye.jsxs)("span", {
            className: "SkyblockKeepersChairAlmanacWeek Next",
            children: [(0, ye.jsx)(ll, {
              phase: KO.almanac.nextPhase
            }), KO.almanac.next]
          })]
        }), (0, ye.jsxs)("footer", {
          className: "SkyblockKeepersChairFooter",
          children: [(0, ye.jsx)("span", {
            className: "SkyblockKeepersChairFavour",
            children: XO("skyblockGame:keepersChairFavour")
          }), KO.aimed && (0, ye.jsx)(Pb.S, {
            className: "SkyblockKeepersChairRest",
            disabled: !KO.canAim,
            onClick: () => {
              pO.aim(null)
            },
            children: XO("skyblockGame:keepersChairRest")
          })]
        }), null !== KO.status && (0, ye.jsx)("p", {
          className: Lb()("SkyblockKeepersChairStatus", "refused" === KO.status.tone ? "Refused" : "Shines"),
          role: "status",
          children: KO.status.text
        })]
      })
    }

    function zv(OO) {
      let {
        controller: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)(), XO = (0, Ib.h)(IX, KO.getSnapshot());
      if (!XO.enabled) return null;
      const bK = XO.freshCount > 0 ? pO("skyblockGame:reachLogOpenNews", {
        count: XO.freshCount
      }) : pO("skyblockGame:reachLogOpen");
      return (0, ye.jsx)(ze.h, {
        placement: "statBars",
        children: (0, ye.jsxs)("button", {
          type: "button",
          className: Lb()("SkyblockReachLogButton", XO.freshCount > 0 && "HasNews", XO.pending && "Pending"),
          "aria-label": bK,
          title: bK,
          onClick: KO.ask,
          children: [XO.news && (0, ye.jsx)("span", {
            className: "SkyblockReachLogPulse",
            "aria-hidden": "true"
          }, `pulse:${XO.newsToken}`), (0, ye.jsx)("span", {
            className: Lb()("SkyblockReachLogIcon", XO.news && "Jump"),
            "aria-hidden": "true",
            children: (0, ye.jsx)(fb.b, {
              itemName: gb,
              amount: 0
            })
          }, `icon:${XO.newsToken}`), XO.freshCount > 0 && (0, ye.jsx)("span", {
            className: "SkyblockReachLogBadge",
            children: XO.freshCount
          })]
        })
      })
    }

    function Al(OO) {
      let {
        gift: KO
      } = OO;
      return (0, ye.jsx)("li", {
        className: Lb()("SkyblockRegularsGift", KO.given && "Given"),
        children: KO.text
      })
    }

    function fl(OO) {
      let {
        regular: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)();
      return (0, ye.jsxs)("li", {
        className: Lb()("SkyblockRegularsCard", KO.tagged ? "Tagged" : "Untagged", KO.resting && "Resting"),
        children: [(0, ye.jsxs)("div", {
          className: "SkyblockRegularsCardTop",
          children: [(0, ye.jsx)("span", {
            className: "SkyblockRegularsIcon",
            title: KO.fishName,
            children: (0, ye.jsx)(fb.b, {
              itemName: KO.itemName,
              amount: 0
            })
          }), (0, ye.jsxs)("div", {
            className: "SkyblockRegularsNames",
            children: [(0, ye.jsx)("h3", {
              children: KO.name
            }), (0, ye.jsx)("span", {
              className: "SkyblockRegularsFish",
              children: KO.fishName
            })]
          })]
        }), (0, ye.jsx)("p", {
          className: "SkyblockRegularsLine",
          children: KO.line
        }), (0, ye.jsxs)("p", {
          className: "SkyblockRegularsStats",
          children: [(0, ye.jsx)("span", {
            className: "SkyblockRegularsSize",
            children: KO.size
          }), KO.tagged && (0, ye.jsx)("span", {
            className: "SkyblockRegularsMeetings",
            children: KO.resting ? pO("skyblockGame:regularsResting") : KO.meetings
          })]
        }), (0, ye.jsx)("p", {
          className: "SkyblockRegularsChance",
          children: KO.chance
        }), (0, ye.jsx)("ul", {
          className: "SkyblockRegularsGifts",
          children: KO.gifts.map((OO => (0, ye.jsx)(Al, {
            gift: OO
          }, OO.text)))
        }), KO.history.length > 0 && (0, ye.jsx)("ul", {
          className: "SkyblockRegularsHistory",
          children: KO.history.map(((OO, KO) => (0, ye.jsx)("li", {
            children: OO
          }, KO)))
        })]
      })
    }

    function dl(OO) {
      let {
        controller: KO,
        island: pO
      } = OO;
      const {
        t: XO
      } = (0, Nb.D)(), bK = (0, Ib.h)(WX, KO.getSnapshot()), eO = bK.islands.find((OO => OO.id === pO));
      if (!bK.enabled || void 0 === eO) return null;
      const lO = XO("skyblockGame:regularsOpen");
      return (0, ye.jsxs)("button", {
        type: "button",
        className: "SkyblockRegularsStrip",
        "aria-label": lO,
        title: lO,
        onClick: () => {
          KO.openIsland(pO)
        },
        children: [(0, ye.jsx)("span", {
          className: "SkyblockRegularsStripTitle",
          children: XO("skyblockGame:regularsTitle")
        }), eO.regulars.map((OO => (0, ye.jsx)("span", {
          className: Lb()("SkyblockRegularsStripIcon", OO.tagged && "Tagged"),
          title: OO.name,
          children: (0, ye.jsx)(fb.b, {
            itemName: OO.itemName,
            amount: 0
          })
        }, OO.id)))]
      })
    }

    function Tl(OO) {
      var KO;
      let {
        controller: pO
      } = OO;
      const XO = (0, Ib.h)(WX, pO.getSnapshot()),
        {
          t: bK
        } = (0, Nb.D)(),
        eO = sb();
      if (!XO.enabled) return null;
      const lO = null !== (KO = XO.islands.find((OO => OO.id === XO.selected))) && void 0 !== KO ? KO : null;
      return (0, ye.jsx)(re.d, {
        show: XO.open,
        close: pO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockReachLogPanel SkyblockRegularsPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockRegularsTitle",
          tabIndex: -1,
          ref: eO,
          onKeyDown: me,
          children: [(0, ye.jsxs)("header", {
            className: "SkyblockReachLogHeader",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockRegularsTitle",
                children: bK("skyblockGame:regularsTitle")
              }), (0, ye.jsx)("p", {
                children: bK("skyblockGame:pimRegularsLedgerWelcome")
              })]
            }), (0, ye.jsx)(Pb.i, {
              padIgnore: !0,
              onClick: pO.dismiss
            })]
          }), (0, ye.jsx)("nav", {
            className: "SkyblockReachLogTabs",
            role: "tablist",
            "data-pad-tabs": "1",
            children: XO.islands.map((OO => {
              const KO = OO.id === XO.selected;
              return (0, ye.jsx)("button", {
                type: "button",
                role: "tab",
                "aria-selected": KO,
                "data-pad-tab": !0,
                "data-pad-selected": KO ? "true" : void 0,
                className: Lb()("SkyblockReachLogTab", `Island-${OO.id}`, KO && "Selected", OO.charm.given && "GoldPage"),
                onClick: () => {
                  pO.selectIsland(OO.id)
                },
                children: (0, ye.jsx)("span", {
                  className: "SkyblockReachLogTabName",
                  children: OO.name
                })
              }, OO.id)
            }))
          }), (0, ye.jsxs)("div", {
            className: Lb()("SkyblockRegularsPage", null !== lO && `Island-${lO.id}`),
            role: "tabpanel",
            children: [(0, ye.jsx)("p", {
              className: "SkyblockRegularsHow",
              children: bK("skyblockGame:regularsHow")
            }), null !== lO && (0, ye.jsx)("ul", {
              className: "SkyblockRegularsGrid",
              children: lO.regulars.map((OO => (0, ye.jsx)(fl, {
                regular: OO
              }, OO.id)))
            })]
          }), null !== lO && (0, ye.jsx)("footer", {
            className: "SkyblockRegularsFooter",
            children: (0, ye.jsx)("span", {
              className: Lb()("SkyblockRegularsCharm", lO.charm.given && "Given"),
              children: lO.charm.text
            })
          })]
        })
      })
    }
    const Nl = [{
        "--left": "12%",
        "--tilt": "14deg",
        "--duration": "11s",
        "--delay": "-3s"
      }, {
        "--left": "62%",
        "--tilt": "-10deg",
        "--duration": "14s",
        "--delay": "-9s"
      }],
      Il = Array.from({
        length: 6
      }, ((OO, KO) => ({
        "--x": `${(88*(.618034*KO%1)).toFixed(1)}%`,
        "--y": `${(10+37*KO%70).toFixed(1)}%`,
        "--size": 7 + KO % 3 * 3 + "rem",
        "--drift-x": 3 * (KO % 3 - 1) + "rem",
        "--drift-y": 2 * (KO % 2 === 0 ? -1 : 1) + "rem",
        "--duration": 14 + KO % 4 * 3 + "s",
        "--delay": 2.5 * -KO + "s"
      }))),
      yv = Array.from({
        length: 14
      }, ((OO, KO) => ({
        "--left": `${(3+94*((.618034*KO+.3)%1)).toFixed(1)}%`,
        "--size": 4 + KO % 4 * 2 + "px",
        "--sway": KO % 3 * 3 + 3 + "px",
        "--duration": `${(8+7*KO%6*1.1).toFixed(1)}s`,
        "--delay": `${(-1.73*KO%12).toFixed(2)}s`
      }))),
      gv = (0, IO.memo)((function(OO) {
        let {
          island: KO
        } = OO;
        return (0, ye.jsxs)("div", {
          className: Lb()("SkyblockReachLogDepths", null !== KO && `Island-${KO}`),
          "aria-hidden": "true",
          children: [Nl.map(((OO, KO) => (0, ye.jsx)("span", {
            className: "SkyblockReachLogShaft",
            style: OO
          }, `shaft${KO}`))), Il.map(((OO, KO) => (0, ye.jsx)("span", {
            className: Lb()("SkyblockReachLogMote", KO % 2 === 1 && "Violet"),
            style: OO
          }, `mote${KO}`))), yv.map(((OO, KO) => (0, ye.jsx)("span", {
            className: "SkyblockReachLogBubble",
            style: OO
          }, `bubble${KO}`)))]
        })
      })),
      ul = 100;

    function El(OO) {
      let {
        view: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)();
      if (null === KO || 0 === KO.total) return null;
      const XO = ul * KO.aspect,
        bK = pO("skyblockGame:hiddenWatersCount", {
          found: KO.found,
          total: KO.total
        });
      return (0, ye.jsxs)("div", {
        className: "SkyblockHiddenWatersStrip",
        title: `${pO("skyblockGame:hiddenWatersTitle")}: ${bK}`,
        children: [(0, ye.jsxs)("svg", {
          className: "SkyblockHiddenWatersOutline",
          viewBox: `0 0 100 ${XO}`,
          "aria-hidden": "true",
          children: [KO.islands.map(((OO, KO) => (0, ye.jsx)("ellipse", {
            className: "SkyblockHiddenWatersIsland",
            cx: (OO.left + OO.width / 2) * ul,
            cy: (OO.top + OO.height / 2) * XO,
            rx: OO.width / 2 * ul,
            ry: OO.height / 2 * XO
          }, KO))), KO.pins.map(((OO, KO) => (0, ye.jsx)("circle", {
            className: "SkyblockHiddenWatersPin",
            cx: OO.left * ul,
            cy: OO.top * XO,
            r: 13
          }, KO)))]
        }), (0, ye.jsxs)("span", {
          className: "SkyblockHiddenWatersText",
          children: [(0, ye.jsx)("span", {
            className: "SkyblockHiddenWatersTitle",
            children: pO("skyblockGame:hiddenWatersTitle")
          }), (0, ye.jsx)("span", {
            className: KO.found === KO.total ? "SkyblockHiddenWatersCount AllFound" : "SkyblockHiddenWatersCount",
            children: bK
          })]
        })]
      })
    }

    function jv(OO) {
      let {
        view: KO,
        island: pO
      } = OO;
      const {
        t: XO
      } = (0, Nb.D)(), bK = null === KO || void 0 === KO ? void 0 : KO.glimpses.get(pO);
      return void 0 === bK || 0 === bK.length ? null : (0, ye.jsxs)("div", {
        className: "SkyblockHiddenWatersGlimpses",
        children: [(0, ye.jsx)("span", {
          className: "SkyblockHiddenWatersGlimpsesTitle",
          children: XO("skyblockGame:hiddenWatersGlimpsed")
        }), (0, ye.jsx)("span", {
          className: "SkyblockHiddenWatersGlimpsesRow",
          children: bK.map((OO => (0, ye.jsx)("span", {
            className: "SkyblockHiddenWatersSilhouette",
            "aria-hidden": "true",
            children: (0, ye.jsx)(fb.b, {
              itemName: OO,
              amount: 0
            })
          }, OO)))
        })]
      })
    }
    const Yl = ["Bronze", "Silver", "Gold"],
      wl = [{
        className: "Bloom",
        titleKey: "skyblockGame:reachLogRibbonBloomTitle",
        legendKey: "skyblockGame:reachLogLegendBloom"
      }, {
        className: "Chart",
        titleKey: "skyblockGame:reachLogRibbonChartTitle",
        legendKey: "skyblockGame:reachLogLegendChart"
      }, {
        className: "LetGo",
        titleKey: "skyblockGame:reachLogRibbonLetGoTitle",
        legendKey: "skyblockGame:reachLogLegendLetGo"
      }],
      iv = wl.slice(0, 2);

    function rv(OO) {
      return OO ? wl : iv
    }

    function Pl(OO) {
      let {
        fish: KO,
        letGoShown: pO
      } = OO;
      const {
        t: XO
      } = (0, Nb.D)();
      return (0, ye.jsxs)("span", {
        className: "SkyblockReachLogMarks",
        children: [Yl.map(((OO, pO) => {
          const bK = pO < KO.marks;
          return (0, ye.jsx)("span", {
            className: Lb()("SkyblockReachLogPip", OO, bK && "Earned", bK && KO.fresh && pO === KO.marks - 1 && "Newest"),
            title: XO(yb[pO])
          }, OO)
        })), (0, ye.jsx)("span", {
          className: "SkyblockReachLogDivider"
        }), rv(pO).map(((OO, pO) => (0, ye.jsx)("span", {
          className: Lb()("SkyblockReachLogRibbon", OO.className, !0 === KO.ribbons[pO] && "Earned"),
          title: XO(OO.titleKey)
        }, OO.className)))]
      })
    }

    function mv(OO) {
      let {
        letGoShown: KO,
        haloShown: pO
      } = OO;
      const {
        t: XO
      } = (0, Nb.D)();
      return (0, ye.jsxs)("span", {
        className: "SkyblockReachLogLegend",
        children: [(0, ye.jsxs)("span", {
          className: "SkyblockReachLogLegendItem",
          title: XO("skyblockGame:reachLogMarks"),
          children: [(0, ye.jsx)("span", {
            className: "SkyblockReachLogPip Gold Earned"
          }), XO("skyblockGame:reachLogLegendMarks")]
        }), rv(KO).map((OO => (0, ye.jsxs)("span", {
          className: "SkyblockReachLogLegendItem",
          title: XO(OO.titleKey),
          children: [(0, ye.jsx)("span", {
            className: Lb()("SkyblockReachLogRibbon", OO.className, "Earned")
          }), XO(OO.legendKey)]
        }, OO.className))), (0, ye.jsxs)("span", {
          className: "SkyblockReachLogLegendItem",
          title: XO("skyblockGame:reachLogGlimmerTitle"),
          children: [(0, ye.jsx)("span", {
            className: "SkyblockReachLogGlimmer"
          }), XO("skyblockGame:reachLogLegendGlimmer")]
        }), pO && (0, ye.jsxs)("span", {
          className: "SkyblockReachLogLegendItem",
          title: XO("skyblockGame:reachLogHaloTitle"),
          children: [(0, ye.jsx)("span", {
            className: "SkyblockReachLogHalo"
          }), XO("skyblockGame:reachLogLegendHalo")]
        })]
      })
    }

    function sl(OO) {
      let {
        returner: KO
      } = OO;
      return (0, ye.jsxs)("div", {
        className: Lb()("SkyblockReachLogReturner", KO.back && "Back"),
        children: [(0, ye.jsx)("span", {
          className: "SkyblockReachLogReturnerIcon",
          "aria-hidden": "true",
          children: (0, ye.jsx)(fb.b, {
            itemName: KO.itemName,
            amount: 0
          })
        }), (0, ye.jsx)("span", {
          className: "SkyblockReachLogReturnerLine",
          children: KO.line
        })]
      })
    }

    function Hl(OO) {
      let {
        fish: KO,
        letGoShown: pO
      } = OO;
      const {
        t: XO
      } = (0, Nb.D)();
      return (0, ye.jsxs)("li", {
        className: Lb()("SkyblockReachLogCard", KO.caught ? "Caught" : "Unknown", KO.marks >= 3 && "GoldCard", KO.fresh && "Fresh", KO.visitor && "Visitor"),
        children: [KO.visitor && (0, ye.jsx)("span", {
          className: "SkyblockReachLogVisitorTag",
          children: XO("skyblockGame:reachLogVisitor")
        }), KO.fresh && Array.from({
          length: 4
        }, ((OO, KO) => (0, ye.jsx)("span", {
          className: "SkyblockReachLogSparkle"
        }, KO))), (0, ye.jsxs)("span", {
          className: "SkyblockReachLogFishIcon",
          "aria-hidden": "true",
          children: [KO.halo && (0, ye.jsx)("span", {
            className: "SkyblockReachLogHalo",
            title: XO("skyblockGame:reachLogHaloTitle")
          }), (0, ye.jsx)(fb.b, {
            itemName: KO.itemName,
            amount: 0
          }), KO.glimmer && (0, ye.jsx)("span", {
            className: "SkyblockReachLogGlimmer",
            title: XO("skyblockGame:reachLogGlimmerTitle")
          })]
        }), (0, ye.jsx)("span", {
          className: "SkyblockReachLogFishName",
          children: KO.name
        }), (0, ye.jsx)("span", {
          className: "SkyblockReachLogFishChance",
          children: KO.chance
        }), (0, ye.jsx)("span", {
          className: "SkyblockReachLogFishBest",
          children: KO.best
        }), (0, ye.jsx)(Pl, {
          fish: KO,
          letGoShown: pO
        })]
      })
    }

    function Rl(OO) {
      let {
        page: KO,
        letGoShown: pO,
        hiddenWaters: XO
      } = OO;
      const {
        t: bK
      } = (0, Nb.D)();
      return KO.awake ? (0, ye.jsx)("ul", {
        className: "SkyblockReachLogGrid",
        children: KO.fish.map((OO => (0, ye.jsx)(Hl, {
          fish: OO,
          letGoShown: pO
        }, OO.itemName)))
      }) : (0, ye.jsxs)(ye.Fragment, {
        children: [(0, ye.jsx)("p", {
          className: "SkyblockReachLogAsleep",
          children: bK("skyblockGame:reachLogAsleep")
        }), (0, ye.jsx)(jv, {
          view: XO,
          island: KO.id
        })]
      })
    }

    function Sl(OO) {
      var KO, pO;
      let {
        controller: XO,
        regulars: bK,
        hiddenWaters: eO
      } = OO;
      const lO = (0, Ib.h)(IX, XO.getSnapshot()),
        vK = function(OO) {
          return (0, Ib.h)(Kb, OO.getSnapshot())
        }(eO),
        CO = (0, Ib.h)(WX, bK.getSnapshot()),
        {
          t: hO
        } = (0, Nb.D)(),
        DO = sb();
      if (!lO.enabled) return null;
      const MO = null !== (KO = lO.pages.find((OO => OO.id === lO.selected))) && void 0 !== KO ? KO : null;
      return (0, ye.jsx)(re.d, {
        show: lO.open,
        close: XO.dismiss,
        togglePointerLock: !1,
        className: Lb()("SkyblockSkillsOverlay", CO.open && "SkyblockReachLogUnderLedger"),
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockReachLogPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockReachLogTitle",
          tabIndex: -1,
          ref: DO,
          onKeyDown: me,
          children: [(0, ye.jsx)(gv, {
            island: null !== (pO = null === MO || void 0 === MO ? void 0 : MO.id) && void 0 !== pO ? pO : null
          }), (0, ye.jsxs)("header", {
            className: "SkyblockReachLogHeader",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockReachLogTitle",
                children: hO("skyblockGame:reachLogTitle")
              }), (0, ye.jsx)("p", {
                children: hO("skyblockGame:keeperWickReachLogWelcome")
              })]
            }), (0, ye.jsx)(El, {
              view: vK
            }), (0, ye.jsx)(Pb.i, {
              padIgnore: !0,
              onClick: XO.dismiss
            })]
          }), (0, ye.jsx)("nav", {
            className: "SkyblockReachLogTabs",
            role: "tablist",
            "data-pad-tabs": "1",
            children: lO.pages.map((OO => {
              const KO = OO.id === lO.selected,
                pO = OO.fish.some((OO => OO.fresh));
              return (0, ye.jsxs)("button", {
                type: "button",
                role: "tab",
                "aria-selected": KO,
                "data-pad-tab": !0,
                "data-pad-selected": KO ? "true" : void 0,
                className: Lb()("SkyblockReachLogTab", `Island-${OO.id}`, KO && "Selected", !OO.awake && "Asleep", OO.gold && "GoldPage", pO && "HasNews"),
                onClick: () => {
                  XO.selectPage(OO.id)
                },
                children: [(0, ye.jsx)("span", {
                  className: "SkyblockReachLogTabName",
                  children: OO.name
                }), OO.awake && (0, ye.jsx)("span", {
                  className: "SkyblockReachLogTabCount",
                  children: hO("skyblockGame:reachLogCaughtCount", {
                    caught: OO.caught,
                    total: OO.total
                  })
                })]
              }, OO.id)
            }))
          }), (0, ye.jsxs)("div", {
            className: Lb()("SkyblockReachLogPage", null !== MO && `Island-${MO.id}`),
            role: "tabpanel",
            children: [null !== MO && (0, ye.jsx)(Rl, {
              page: MO,
              letGoShown: lO.letGoShown,
              hiddenWaters: vK
            }), !0 === (null === MO || void 0 === MO ? void 0 : MO.awake) && null !== MO.returner && (0, ye.jsx)(sl, {
              returner: MO.returner
            }), !0 === (null === MO || void 0 === MO ? void 0 : MO.awake) && (0, ye.jsx)(dl, {
              controller: bK,
              island: MO.id
            })]
          }), (0, ye.jsx)("footer", {
            className: Lb()("SkyblockReachLogFooter", null !== MO && `Island-${MO.id}`, !0 === (null === MO || void 0 === MO ? void 0 : MO.gold) && "GoldPage"),
            children: !0 === (null === MO || void 0 === MO ? void 0 : MO.gold) ? (0, ye.jsx)("span", {
              className: "SkyblockReachLogGoldLine",
              children: hO("skyblockGame:keeperWickReachLogPageGold")
            }) : (0, ye.jsxs)(ye.Fragment, {
              children: [(0, ye.jsx)(mv, {
                letGoShown: lO.letGoShown,
                haloShown: !0 === (null === MO || void 0 === MO ? void 0 : MO.fish.some((OO => OO.halo)))
              }), (0, ye.jsx)("span", {
                className: "SkyblockReachLogReward",
                children: hO("skyblockGame:reachLogPageReward")
              })]
            })
          })]
        })
      })
    }
    var Jl = pO(3967);

    function cv(OO) {
      let {
        conversation: KO,
        completedLabel: pO
      } = OO;
      return (0, ye.jsxs)("article", {
        className: "SkyblockDialogueConversation",
        children: [(0, ye.jsxs)("header", {
          children: [(0, ye.jsx)("h3", {
            children: KO.questName
          }), KO.completed && (0, ye.jsx)("span", {
            className: "SkyblockDialogueCompleted",
            children: pO
          })]
        }), KO.lines.map((OO => (0, ye.jsx)(Jl.e, {
          display: OO.display
        }, OO.key)))]
      })
    }

    function Bl(OO) {
      let {
        controller: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)(), XO = (0, Ib.h)(Xb, KO.getSnapshot()), bK = sb();
      if (!XO.enabled) return null;
      const eO = !XO.loading && 0 === XO.conversations.length;
      return (0, ye.jsx)(re.d, {
        show: XO.open,
        close: KO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockDialoguePanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockDialogueTitle",
          tabIndex: -1,
          ref: bK,
          onKeyDown: me,
          children: [(0, ye.jsxs)("header", {
            className: "SkyblockSkillsHeader",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockDialogueTitle",
                children: pO("skyblockDialogue:title")
              }), (0, ye.jsx)("p", {
                children: pO("skyblockDialogue:intro")
              })]
            }), (0, ye.jsx)(Pb.i, {
              padIgnore: !0,
              onClick: KO.dismiss
            })]
          }), (0, ye.jsxs)("div", {
            className: Lb()("SkyblockDialogueBody", {
              SingleColumn: null !== XO.questFocus || 0 === XO.characters.length
            }),
            children: [null === XO.questFocus && XO.characters.length > 0 && (0, ye.jsx)("nav", {
              className: "SkyblockDialogueCharacters",
              children: XO.characters.map((OO => (0, ye.jsx)(Pb.d, {
                className: Lb()("SkyblockDialogueCharacter", {
                  Selected: OO.selected
                }),
                onClick: () => {
                  KO.selectCharacter(OO.id)
                },
                children: (0, ye.jsx)(db.d, {
                  text: OO.styling
                })
              }, OO.id)))
            }), (0, ye.jsxs)("div", {
              className: "SkyblockDialogueConversations",
              children: [null !== XO.questFocus && (0, ye.jsx)(Pb.d, {
                className: "SkyblockDialogueBack",
                onClick: KO.showCharacters,
                children: pO("skyblockDialogue:allCharacters")
              }), XO.loading && (0, ye.jsx)("p", {
                className: "SkyblockDialogueEmpty",
                children: pO("skyblockDialogue:loading")
              }), eO && (0, ye.jsx)("p", {
                className: "SkyblockDialogueEmpty",
                children: pO(null === XO.questFocus ? "skyblockDialogue:empty" : "skyblockDialogue:questEmpty")
              }), XO.conversations.map((OO => (0, ye.jsx)(cv, {
                conversation: OO,
                completedLabel: XO.completedLabel
              }, OO.questId)))]
            })]
          })]
        })
      })
    }

    function Zl(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(Cb, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)(),
        bK = sb();
      return pO.enabled ? (0, ye.jsx)(re.d, {
        show: pO.open,
        close: KO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockAutographsPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockAutographsTitle",
          tabIndex: -1,
          ref: bK,
          onKeyDown: me,
          children: [(0, ye.jsxs)("header", {
            className: "SkyblockSkillsHeader",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockAutographsTitle",
                children: XO("skyblockGame:autographBook")
              }), (0, ye.jsx)("p", {
                children: XO("skyblockGame:autographBookIntro")
              })]
            }), (0, ye.jsx)(Pb.i, {
              padIgnore: !0,
              onClick: KO.dismiss
            })]
          }), (0, ye.jsxs)("div", {
            className: "SkyblockAutographsBody",
            children: [(0, ye.jsxs)("div", {
              className: "SkyblockAutographTotals",
              children: [(0, ye.jsxs)("div", {
                className: "SkyblockAutographTotal",
                children: [(0, ye.jsx)("strong", {
                  children: pO.total
                }), (0, ye.jsx)("span", {
                  children: XO("skyblockGame:autographTotal")
                })]
              }), (0, ye.jsxs)("div", {
                className: "SkyblockAutographTotal Ranked",
                children: [(0, ye.jsx)("strong", {
                  children: pO.rankTotal
                }), (0, ye.jsx)("span", {
                  children: XO("skyblockGame:autographRankTotal")
                })]
              })]
            }), 0 === pO.entries.length ? (0, ye.jsx)("p", {
              className: "SkyblockAutographsEmpty",
              children: XO("skyblockGame:autographBookEmpty")
            }) : (0, ye.jsx)("ul", {
              className: "SkyblockAutographList",
              children: pO.entries.map((OO => (0, ye.jsxs)("li", {
                className: Lb()("SkyblockAutograph", {
                  Ranked: null !== OO.rank
                }),
                style: null === OO.rank ? void 0 : {
                  color: OO.rank.colour
                },
                children: [null !== OO.rank && (0, ye.jsx)(Ce.d, {
                  className: "SkyblockAutographRankIcon",
                  name: OO.rank.icon,
                  kit: (0, Ce.g)(OO.rank.icon)
                }), (0, ye.jsxs)("div", {
                  className: "SkyblockAutographText",
                  children: [(0, ye.jsx)("span", {
                    className: "SkyblockAutographName",
                    children: OO.name
                  }), (0, ye.jsxs)("span", {
                    className: "SkyblockAutographDetails",
                    children: [null !== OO.rank && (0, ye.jsx)("span", {
                      className: "SkyblockAutographRank",
                      children: OO.rank.label
                    }), (0, ye.jsx)("span", {
                      className: "SkyblockAutographDate",
                      children: OO.signedOn
                    })]
                  })]
                })]
              }, OO.key)))
            })]
          })]
        })
      }) : null
    }
    const Gl = (0, IO.memo)((function(OO) {
        let {
          controller: KO
        } = OO;
        return (0, ye.jsxs)("div", {
          className: "SkyblockQuestWaypoint",
          ref: KO.display.mountWaypoint,
          children: [(0, ye.jsx)("div", {
            className: "SkyblockQuestWaypointMarker"
          }), (0, ye.jsx)("div", {
            className: "SkyblockQuestWaypointTextClip",
            children: (0, ye.jsxs)("div", {
              className: "SkyblockQuestWaypointText",
              children: [(0, ye.jsx)("span", {
                className: "SkyblockQuestWaypointLabel"
              }), (0, ye.jsx)("span", {
                className: "SkyblockQuestWaypointDistance"
              }), (0, ye.jsx)("span", {
                className: "SkyblockQuestWaypointHint",
                hidden: !0
              })]
            })
          })]
        })
      })),
      qv = {
        started: "!",
        quest: "\u2605",
        step: "\u2713",
        skillLevel: "\u25b2",
        landmark: "\u25c6",
        npcNote: "\u2709\ufe0e"
      };

    function xv(OO) {
      return "next" === OO.phase ? "\u2192" : qv[OO.kind]
    }
    const nl = (0, IO.memo)((function(OO) {
      let {
        controller: KO,
        display: pO
      } = OO;
      const XO = (0, Ib.h)(lp, KO.getNotificationSnapshot()),
        [bK, eO] = (0, IO.useState)(!1);
      return (0, Ib.f)("qteStateUpdated", (OO => {
        eO(OO.isActive)
      })), (0, ye.jsxs)("div", {
        className: "SkyblockQuestNotificationAnchor" + (bK ? " UnderQte" : ""),
        role: "status",
        "aria-live": "polite",
        "aria-atomic": "true",
        children: [XO && (0, ye.jsxs)("div", {
          className: `SkyblockQuestNotification ${XO.kind} ${XO.phase}`,
          style: {
            "--quest-notification-duration": `${XO.durationMs}ms`,
            ...XO.accent && {
              "--quest-notification-accent": XO.accent
            }
          },
          children: [(0, ye.jsxs)("div", {
            className: "SkyblockQuestNotificationSymbols" + (XO.iconItem ? " WithIcon" : ""),
            "aria-hidden": "true",
            children: [(0, ye.jsx)("span", {
              className: "SkyblockQuestNotificationMark",
              children: xv(XO)
            }), XO.iconItem && (0, ye.jsx)("span", {
              className: "SkyblockQuestNotificationIcon",
              children: (0, ye.jsx)(fb.b, {
                itemName: XO.iconItem,
                amount: 0
              })
            })]
          }), (0, ye.jsxs)("div", {
            className: "SkyblockQuestNotificationText",
            children: [(0, ye.jsx)("span", {
              className: "SkyblockQuestNotificationTitle",
              children: XO.title
            }), (0, ye.jsx)("strong", {
              className: "SkyblockQuestNotificationName",
              children: (0, ye.jsx)(Ke.b, {
                text: XO.name
              })
            }), XO.description && (0, ye.jsx)("span", {
              className: "SkyblockQuestNotificationDescription",
              children: (0, ye.jsx)(Ke.b, {
                text: XO.description
              })
            }), XO.reward && (0, ye.jsx)("span", {
              className: "SkyblockQuestNotificationReward",
              children: (0, ye.jsx)(Ke.b, {
                text: XO.reward
              })
            })]
          })]
        }, XO.token), (null === XO || void 0 === XO ? void 0 : XO.waypointNameKey) && (0, ye.jsx)("div", {
          className: "SkyblockQuestNotificationWaypointOrigin",
          "data-waypoint-name-key": XO.waypointNameKey,
          "data-notification-token": XO.token,
          ref: pO.mountWaypointOrigin,
          "aria-hidden": "true"
        }, `waypoint-${XO.token}`)]
      })
    }));

    function Wl(OO) {
      const KO = parseInt(OO.replace("#", ""), 16);
      return `${KO>>16&255}, ${KO>>8&255}, ${255&KO}`
    }
    const tv = (0, IO.memo)((function(OO) {
      let {
        controller: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)(), XO = (0, Ib.h)(iX, KO.getSnapshot());
      if (!XO) return null;
      const bK = "arrival" === XO.phase;
      return (0, ye.jsxs)("div", {
        className: Lb()("SkyblockPortalTransit", {
          Departure: !bK,
          Arrival: bK
        }),
        style: {
          "--portal-rgb": Wl(XO.colour),
          "--portal-duration": `${XO.durationMs}ms`
        },
        role: "status",
        "aria-live": "polite",
        children: [(0, ye.jsx)("div", {
          className: "SkyblockPortalTransitVeil",
          "aria-hidden": "true"
        }), (0, ye.jsx)("div", {
          className: "SkyblockPortalTransitRim",
          "aria-hidden": "true",
          onAnimationEnd: () => {
            KO.finishArrival(XO.token)
          }
        }), (0, ye.jsxs)("div", {
          className: "SkyblockPortalTransitTitle",
          children: [(0, ye.jsx)("div", {
            className: "SkyblockPortalTransitBand",
            "aria-hidden": "true"
          }), !bK && (0, ye.jsx)("span", {
            className: "SkyblockPortalTransitEyebrow",
            children: pO("skyblockGame:portalTransitHeading")
          }), (0, ye.jsx)("strong", {
            className: "SkyblockPortalTransitZone",
            children: pO(XO.zoneNameKey)
          })]
        })]
      }, XO.token)
    }));

    function kv() {
      return window.matchMedia("(prefers-reduced-motion: reduce)").matches
    }

    function Ul() {
      const OO = document.querySelector(".SkyblockHudCoins"),
        KO = null === OO || void 0 === OO ? void 0 : OO.getBoundingClientRect();
      return KO && KO.width > 0 ? {
        x: KO.left + Math.min(KO.width, 24) / 2,
        y: KO.top + KO.height / 2
      } : {
        x: window.innerWidth - 48,
        y: 48
      }
    }

    function Ov(OO) {
      return {
        x: OO.left + OO.width / 2,
        y: OO.top + OO.height / 2
      }
    }

    function Kv() {
      var OO;
      const KO = null === (OO = document.querySelector(".HotBar")) || void 0 === OO ? void 0 : OO.getBoundingClientRect();
      return KO && KO.width > 0 ? Ov(KO) : {
        x: window.innerWidth / 2,
        y: window.innerHeight - 40
      }
    }

    function pv(OO) {
      let {
        items: KO,
        origins: pO,
        target: XO
      } = OO;
      return (0, ye.jsx)("div", {
        className: "SkyblockDailyRewardFlyingItems",
        children: KO.map(((OO, KO) => {
          const bK = pO[KO];
          return (0, ye.jsx)("span", {
            className: "SkyblockDailyRewardFlyingItem",
            style: {
              left: `${bK.x}px`,
              top: `${bK.y}px`,
              "--item-dx": XO.x - bK.x + "px",
              "--item-dy": XO.y - bK.y + "px",
              "--item-delay": 2e3 + 160 * KO + "ms",
              "--item-flight": "700ms"
            },
            children: (0, ye.jsx)(fb.b, {
              itemName: OO.dailyRewardItemName,
              amount: 0
            })
          }, OO.dailyRewardItemName)
        }))
      })
    }

    function Xv(OO, KO) {
      const pO = -Math.PI / 2 + 1.25 * (OO / (KO - 1) * 2 - 1),
        XO = 70 + OO % 3 * 22;
      return {
        x: Math.cos(pO) * XO,
        y: Math.sin(pO) * XO * .7
      }
    }

    function bC(OO) {
      let {
        origin: KO,
        target: pO,
        count: XO
      } = OO;
      const bK = [];
      for (let eO = 0; eO < XO; eO++) {
        const OO = Xv(eO, XO);
        bK.push((0, ye.jsx)("span", {
          className: "SkyblockDailyRewardCoin",
          style: {
            left: `${KO.x}px`,
            top: `${KO.y}px`,
            "--coin-bx": `${OO.x}px`,
            "--coin-by": `${OO.y}px`,
            "--coin-dx": pO.x - KO.x + "px",
            "--coin-dy": pO.y - KO.y + "px",
            "--coin-delay": `${Rp(eO,XO)}ms`,
            "--coin-flight": "650ms"
          },
          children: (0, ye.jsx)(fb.b, {
            itemName: "Gold Coin",
            amount: 0
          })
        }, eO))
      }
      return (0, ye.jsx)("div", {
        className: "SkyblockDailyRewardCoins",
        children: bK
      })
    }

    function ev(OO) {
      let {
        day: KO
      } = OO;
      const pO = yK[KO - 1];
      return (0, ye.jsxs)(ye.Fragment, {
        children: [(0, ye.jsxs)("span", {
          className: "SkyblockDailyRewardFooterReward",
          children: [(0, ye.jsx)(fb.b, {
            itemName: "Gold Coin",
            amount: 0
          }), (0, Tb.e)(pO.dailyRewardCoins)]
        }), pO.dailyRewardItems.map((OO => (0, ye.jsxs)("span", {
          className: "SkyblockDailyRewardFooterReward",
          children: [(0, ye.jsx)(fb.b, {
            itemName: OO.dailyRewardItemName,
            amount: 0
          }), "\xd7", OO.dailyRewardItemAmount]
        }, OO.dailyRewardItemName)))]
      })
    }

    function lv(OO) {
      let {
        day: KO
      } = OO;
      const pO = uO(KO);
      return (0, ye.jsx)("ol", {
        className: "SkyblockDailyRewardStrip",
        children: yK.map(((OO, XO) => {
          const bK = XO + 1;
          return (0, ye.jsxs)("li", {
            className: Lb()("SkyblockDailyRewardTile", {
              Claimed: bK < KO && bK !== pO,
              Today: bK === KO,
              Tomorrow: bK === pO,
              Jackpot: bK === gK
            }),
            children: [(0, ye.jsx)("span", {
              className: "SkyblockDailyRewardTileDay",
              children: bK
            }), (0, ye.jsxs)("span", {
              className: "SkyblockDailyRewardTileReward SkyblockDailyRewardTileCoins",
              children: [(0, ye.jsx)(fb.b, {
                itemName: "Gold Coin",
                amount: 0
              }), (0, Tb.e)(OO.dailyRewardCoins)]
            }), OO.dailyRewardItems.map((OO => (0, ye.jsxs)("span", {
              className: "SkyblockDailyRewardTileReward",
              children: [(0, ye.jsx)(fb.b, {
                itemName: OO.dailyRewardItemName,
                amount: 0
              }), "\xd7", OO.dailyRewardItemAmount]
            }, OO.dailyRewardItemName)))]
          }, bK)
        }))
      })
    }

    function vC(OO) {
      let {
        view: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)(), XO = (0, IO.useRef)(null), bK = (0, IO.useRef)(null), [eO, lO] = (0, IO.useState)(null);
      (0, IO.useLayoutEffect)((() => {
        var OO;
        const KO = null === (OO = XO.current) || void 0 === OO ? void 0 : OO.getBoundingClientRect();
        if (KO) {
          var pO, eO;
          const OO = Array.from(null !== (pO = null === (eO = bK.current) || void 0 === eO ? void 0 : eO.children) && void 0 !== pO ? pO : [], (OO => Ov(OO.getBoundingClientRect())));
          lO({
            origin: Ov(KO),
            target: Ul(),
            itemOrigins: OO,
            itemTarget: Kv()
          })
        }
      }), []);
      const vK = uO(KO.day),
        CO = function(OO, KO) {
          const [pO, XO] = (0, IO.useState)((() => kv() ? OO : 0));
          return (0, IO.useEffect)((() => {
            if (kv()) return;
            const pO = performance.now();
            let bK = 0;
            const eO = lO => {
              const vK = Math.min(Math.max((lO - pO) / KO, 0), 1);
              XO(Math.round(OO * (1 - (1 - vK) ** 3))), vK < 1 && (bK = requestAnimationFrame(eO))
            };
            return bK = requestAnimationFrame(eO), () => {
              cancelAnimationFrame(bK)
            }
          }), [OO, KO]), pO
        }(KO.coins, 450);
      return (0, ye.jsxs)("div", {
        className: Lb()("SkyblockDailyReward", {
          Jackpot: KO.day === gK
        }),
        style: {
          "--daily-duration": `${KO.durationMs}ms`
        },
        role: "status",
        "aria-live": "polite",
        children: [(0, ye.jsx)("div", {
          className: "SkyblockDailyRewardGlow",
          "aria-hidden": "true"
        }), (0, ye.jsxs)("div", {
          className: "SkyblockDailyRewardCard",
          children: [(0, ye.jsxs)("div", {
            className: "SkyblockDailyRewardHeading",
            children: [(0, ye.jsx)("span", {
              className: "SkyblockDailyRewardTitle",
              children: pO("skyblockGame:dailyRewardTitle")
            }), (0, ye.jsx)("span", {
              className: "SkyblockDailyRewardDay",
              children: pO("skyblockGame:dailyRewardDay", {
                day: String(KO.day)
              })
            })]
          }), (0, ye.jsxs)("div", {
            className: "SkyblockDailyRewardAmount",
            ref: XO,
            children: [(0, ye.jsx)(fb.b, {
              itemName: "Gold Coin",
              amount: 0
            }), (0, ye.jsxs)("span", {
              children: ["+", (0, Tb.e)(CO)]
            })]
          }), KO.items.length > 0 && (0, ye.jsx)("div", {
            className: "SkyblockDailyRewardItems",
            ref: bK,
            children: KO.items.map((OO => (0, ye.jsxs)("span", {
              className: "SkyblockDailyRewardItem",
              children: [(0, ye.jsx)(fb.b, {
                itemName: OO.dailyRewardItemName,
                amount: 0
              }), "\xd7", OO.dailyRewardItemAmount]
            }, OO.dailyRewardItemName)))
          }), (0, ye.jsx)(lv, {
            day: KO.day
          }), (0, ye.jsxs)("div", {
            className: "SkyblockDailyRewardFooter",
            children: [pO("skyblockGame:dailyRewardComeBack"), (0, ye.jsx)(ev, {
              day: vK
            })]
          })]
        }), null !== eO && (0, ye.jsx)(bC, {
          origin: eO.origin,
          target: eO.target,
          count: KO.flyingCoins
        }), null !== eO && eO.itemOrigins.length === KO.items.length && (0, ye.jsx)(pv, {
          items: KO.items,
          origins: eO.itemOrigins,
          target: eO.itemTarget
        })]
      })
    }
    const Cv = (0, IO.memo)((function(OO) {
        let {
          controller: KO
        } = OO;
        const pO = (0, Ib.h)(mX, KO.getSnapshot());
        return pO ? (0, ye.jsx)(vC, {
          view: pO
        }, pO.token) : null
      })),
      hv = "Gold Coin";

    function Dv(OO) {
      return 650 + 220 * OO
    }

    function Mv(OO) {
      return {
        "--letter-delay": `${Dv(OO)}ms`,
        "--letter-land": `${Dv(OO)+300}ms`
      }
    }

    function aC(OO) {
      let {
        letterCount: KO
      } = OO;
      return (0, ye.jsxs)("div", {
        className: "SkyblockMailboxArt",
        "aria-hidden": "true",
        children: [(0, ye.jsx)("img", {
          className: "SkyblockMailboxFrame",
          src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAPUlEQVR4nGNgGBTgPxbMgKHoU7Y/Cr7hqI9VMVji8yqV//8veYHxPC0l7ApBEugYp/UgXBNljteN6BrIBwC4hzWhsgbVSgAAAABJRU5ErkJggg==",
          alt: ""
        }), (0, ye.jsx)("img", {
          className: "SkyblockMailboxFrame SkyblockMailboxFrameFlag",
          src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAATElEQVR4nGNgIBP8h2L8iv5f8gJjQor/f16lAlOEU/H/T9n+YIUgGoRvOOpjVQyWACkE0SA8T0sJu0KQBDrGaT0I10SZ43UjugbyAQAsw0ABFINz6QAAAABJRU5ErkJggg==",
          alt: ""
        }), (0, ye.jsx)("img", {
          className: "SkyblockMailboxFrame SkyblockMailboxFrameOpen",
          src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAW0lEQVR4nGNgIBP8h2L8iv5f8gJjQor/f16lAlOEjBlQFH3K9gcrBNEgHGyt9P//rwMYiv/fcNQHKwTRIPzh8SEwxlA4T0sJBYNMBJmM1XoQrokyx+tGdA3kAwD3jUzPjfodhAAAAABJRU5ErkJggg==",
          alt: ""
        }), Array.from({
          length: KO
        }, ((OO, KO) => (0, ye.jsx)("img", {
          className: "SkyblockMailboxFlyingLetter",
          style: Mv(KO),
          src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAP0lEQVR4nGNgoCX4jwOjgP//fx1AwZ+y/f/fcNTHUPz/w+NDKBikaJ6WEnaFa7qCwBhZA0ETcSkEKybGM9QDAOtbYxX7UuH5AAAAAElFTkSuQmCC",
          alt: ""
        }, KO)))]
      })
    }

    function ov(OO) {
      var KO, pO, XO;
      let {
        letter: bK,
        index: eO
      } = OO;
      const {
        t: lO
      } = (0, Nb.D)(), vK = null !== (KO = null === (pO = bK.items[0]) || void 0 === pO ? void 0 : pO.itemName) && void 0 !== KO ? KO : hv;
      return (0, ye.jsxs)("li", {
        className: "SkyblockMailboxLetter",
        style: Mv(eO),
        children: [(0, ye.jsx)("div", {
          className: "SkyblockMailboxStamp",
          "aria-hidden": "true",
          children: (0, ye.jsx)(fb.b, {
            itemName: vK,
            amount: 0
          })
        }), (0, ye.jsx)("div", {
          className: "SkyblockMailboxReason",
          children: lO(bK.reasonKey, null !== (XO = bK.reasonParams) && void 0 !== XO ? XO : void 0)
        }), (0, ye.jsxs)("div", {
          className: "SkyblockMailboxContents",
          children: [bK.coins > 0 && (0, ye.jsxs)("span", {
            className: "SkyblockMailboxGift SkyblockMailboxCoins",
            children: [(0, ye.jsx)(fb.b, {
              itemName: hv,
              amount: 0
            }), "+", (0, Tb.e)(bK.coins)]
          }), bK.items.map(((OO, KO) => (0, ye.jsxs)("span", {
            className: "SkyblockMailboxGift",
            children: [(0, ye.jsx)(fb.b, {
              itemName: OO.itemName,
              amount: 0
            }), OO.label, " \xd7", OO.amount]
          }, KO)))]
        })]
      })
    }

    function Fv(OO) {
      let {
        view: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)();
      return (0, ye.jsx)("div", {
        className: "SkyblockMailbox",
        style: {
          "--mail-duration": `${KO.durationMs}ms`,
          "--flag-up": "300ms",
          "--door-open": "500ms",
          "--more-land": `${Dv(KO.letters.length)+300}ms`
        },
        role: "status",
        "aria-live": "polite",
        children: (0, ye.jsxs)("div", {
          className: "SkyblockMailboxCard",
          children: [(0, ye.jsxs)("div", {
            className: "SkyblockMailboxHeading",
            children: [(0, ye.jsx)(aC, {
              letterCount: KO.letters.length
            }), (0, ye.jsx)("span", {
              className: "SkyblockMailboxTitle",
              children: pO("skyblockGame:mailboxTitle")
            })]
          }), (0, ye.jsx)("ol", {
            className: "SkyblockMailboxLetters",
            children: KO.letters.map(((OO, KO) => (0, ye.jsx)(ov, {
              letter: OO,
              index: KO
            }, KO)))
          }), KO.more > 0 && (0, ye.jsx)("div", {
            className: "SkyblockMailboxMore",
            children: pO("skyblockGame:mailboxMore", {
              count: String(KO.more)
            })
          })]
        })
      })
    }
    const Vv = (0, IO.memo)((function(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(Jp, KO.getSnapshot());
      return pO ? (0, ye.jsx)(Fv, {
        view: pO
      }, pO.token) : null
    }));

    function Lv(OO) {
      let {
        controller: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)(), XO = (0, Ib.h)(ib, KO.getSnapshot());
      if (null === XO) return null;
      const bK = XO.fullSet ? "empty" === XO.fuelState ? {
        text: pO("skyblockGame:magmawardHudNoFuel"),
        tone: "empty"
      } : null : {
        text: pO("skyblockGame:magmawardHudFullSet", {
          worn: String(XO.wornCount)
        }),
        tone: "partial"
      };
      return (0, ye.jsx)(ze.h, {
        placement: "statBars",
        children: (0, ye.jsxs)("div", {
          className: Lb()("SkyblockMagmawardHud", `SkyblockMagmawardHud-${XO.fuelState}`, {
            "SkyblockMagmawardHud-partial": !XO.fullSet,
            "SkyblockMagmawardHud-armed": XO.fullSet && "empty" !== XO.fuelState
          }),
          children: [null !== XO.flare && (0, ye.jsx)("div", {
            className: `SkyblockMagmawardFlare SkyblockMagmawardFlare-${XO.flare}`
          }, `flare:${XO.flareToken}`), (0, ye.jsx)("div", {
            className: Lb()("SkyblockMagmawardPieces", {
              SkyblockMagmawardPiecesComplete: XO.setLit
            }),
            children: XO.pieces.map(((OO, KO) => (0, ye.jsx)("div", {
              className: Lb()("SkyblockMagmawardPiece", {
                SkyblockMagmawardPieceWorn: OO.worn,
                SkyblockMagmawardPieceJustWorn: OO.justWorn
              }),
              children: (0, ye.jsx)(fb.b, {
                itemName: OO.itemName,
                amount: 0
              })
            }, `${KO}:${OO.wornToken}`)))
          }, `pieces:${XO.setLitToken}`), (0, ye.jsxs)("div", {
            className: "SkyblockMagmawardFuel",
            children: [(0, ye.jsx)("div", {
              className: "SkyblockMagmawardLowGlow"
            }), (0, ye.jsxs)("div", {
              className: Lb()("SkyblockMagmawardFuelCounter", XO.pulse && `SkyblockMagmawardFuelCounter-${XO.pulse}`),
              children: [(0, ye.jsx)("div", {
                className: "SkyblockMagmawardFuelIcon",
                children: (0, ye.jsx)(fb.b, {
                  itemName: "Magmaward Fuel",
                  amount: 0
                })
              }), (0, ye.jsx)("span", {
                className: "SkyblockMagmawardFuelCount SmallTextBold",
                children: XO.fuel
              })]
            }, `counter:${XO.pulseToken}`), "burn" === XO.pulse && (0, ye.jsx)("span", {
              className: "SkyblockMagmawardEmber SmallTextBold",
              children: "-1"
            }, `ember:${XO.pulseToken}`)]
          }), bK && (0, ye.jsx)("div", {
            className: `SkyblockMagmawardCaption SkyblockMagmawardCaption-${bK.tone} SmallTextBold`,
            children: bK.text
          })]
        })
      })
    }

    function Qv(OO) {
      let {
        controller: KO
      } = OO;
      const {
        t: pO,
        selectedLanguage: XO
      } = (0, Nb.D)(), bK = (0, Ib.h)(PX, KO.getSnapshot());
      return null === bK ? null : (0, ye.jsx)(ze.h, {
        placement: "statBars",
        children: (0, ye.jsxs)("div", {
          className: Lb()("SkyblockGlowtideChip", {
            SkyblockGlowtideChipInRange: bK.inRange
          }),
          style: {
            "--glowtide-colour": bK.colour
          },
          "aria-label": pO("skyblockGame:glowtideChipLabel"),
          children: [(0, ye.jsx)("div", {
            className: "SkyblockGlowtideChipOrb"
          }), bK.inRange ? (0, ye.jsx)("span", {
            className: "SkyblockGlowtideChipCall SmallTextBold",
            children: pO("skyblockGame:glowtideChipInRange")
          }, `call:${bK.inRangeToken}`) : (0, ye.jsxs)(ye.Fragment, {
            children: [(0, ye.jsx)("div", {
              ref: KO.mountArrow,
              className: "SkyblockGlowtideChipArrow"
            }), (0, ye.jsx)("span", {
              className: "SkyblockGlowtideChipDistance SmallTextBold",
              children: pO("skyblockGame:waypointDistance", {
                distance: dO(bK.distance, XO.code)
              })
            })]
          })]
        })
      })
    }

    function zC(OO) {
      let {
        controller: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)(), XO = (0, Ib.h)(sX, KO.getSnapshot());
      return null === XO ? null : (0, ye.jsx)(ze.h, {
        placement: "statBars",
        children: (0, ye.jsxs)("div", {
          className: Lb()("SkyblockGlowMeter", {
            SkyblockGlowMeterFull: XO.full
          }),
          "aria-label": pO("skyblockGame:glowMeterLabel", {
            fill: String(XO.fill),
            YO: String(XO.YO)
          }),
          children: [XO.burst && (0, ye.jsx)("div", {
            className: "SkyblockGlowMeterBurst"
          }, `burst:${XO.burstToken}`), (0, ye.jsxs)("div", {
            className: "SkyblockGlowMeterVial",
            children: [(0, ye.jsx)("div", {
              className: "SkyblockGlowMeterLiquid",
              style: {
                transform: `scaleX(${XO.ratio})`
              }
            }), XO.gained && (0, ye.jsx)("div", {
              className: "SkyblockGlowMeterGlint"
            }, `gain:${XO.gainToken}`), XO.full && Array.from({
              length: 5
            }, ((OO, KO) => (0, ye.jsx)("span", {
              className: "SkyblockGlowMeterSparkle"
            }, KO)))]
          }), XO.full && XO.rares.map((OO => (0, ye.jsx)("div", {
            className: "SkyblockGlowMeterRare",
            children: (0, ye.jsx)(fb.b, {
              itemName: OO,
              amount: 0
            })
          }, OO))), XO.ready && (0, ye.jsx)("div", {
            className: "SkyblockGlowMeterReady SmallTextBold",
            children: (0, ye.jsx)("span", {
              children: pO("skyblockGame:glowMeterReady")
            })
          }, `ready:${XO.fullToken}`)]
        })
      })
    }

    function Av(OO) {
      let {
        controller: KO
      } = OO;
      const {
        t: pO
      } = (0, Nb.D)(), XO = (0, Ib.h)(RX, KO.getSnapshot());
      if (null === XO) return null;
      const bK = "waiting" === XO.phase,
        eO = {
          animationDuration: `${XO.waitMs}ms`,
          animationDelay: -XO.elapsedMs + "ms"
        },
        lO = bK ? void 0 : {
          animationDuration: `${XO.waitMs}ms`
        };
      return (0, ye.jsxs)("div", {
        className: bK ? "SkyblockHushWait" : "SkyblockHushWait SkyblockHushWaitAbandoned",
        children: [bK && (0, ye.jsxs)("div", {
          className: "SkyblockHushWaitRing",
          children: [Array.from({
            length: 3
          }, ((OO, KO) => (0, ye.jsx)("span", {
            className: "SkyblockHushWaitRipple"
          }, KO))), (0, ye.jsx)("span", {
            className: "SkyblockHushWaitClosing",
            style: eO
          }), (0, ye.jsxs)("svg", {
            className: "SkyblockHushWaitProgress",
            viewBox: "0 0 100 100",
            children: [(0, ye.jsx)("circle", {
              className: "SkyblockHushWaitTrack",
              cx: "50",
              cy: "50",
              r: 46
            }), (0, ye.jsx)("circle", {
              className: "SkyblockHushWaitArc",
              cx: "50",
              cy: "50",
              r: 46,
              pathLength: 100,
              style: eO
            })]
          }), (0, ye.jsx)("span", {
            className: "SkyblockHushWaitMoon"
          })]
        }), (0, ye.jsx)("div", {
          className: "SkyblockHushWaitLine SmallTextBold",
          style: lO,
          children: pO(XO.line)
        }, XO.lineIndex)]
      }, XO.token)
    }

    function fv(OO) {
      let {
        chart: KO,
        showHere: pO,
        className: XO
      } = OO;
      return (0, ye.jsx)("div", {
        className: Lb()("SkyblockTideChartGrid", XO, null !== KO.pictureName && "Complete"),
        "aria-hidden": "true",
        children: KO.cells.map(((OO, XO) => {
          const bK = 0 !== (KO.pulseCells & 1 << XO),
            eO = KO.castCell === XO;
          return (0, ye.jsx)("span", {
            className: Lb()("SkyblockTideChartCell", `Cell-${OO}`, bK && "Pulse", eO && "Cast", pO && KO.hereCell === XO && "Here")
          }, `${XO}:${bK?`p${KO.pulseToken}`:""}:${eO?`c${KO.castToken}`:""}`)
        }))
      })
    }

    function dv(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(JX, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)(),
        bK = pO.chip;
      if (!pO.enabled || null === bK) return null;
      const eO = XO("skyblockGame:tideChartsChipLabel", {
        island: bK.islandName,
        lit: String(bK.lit),
        ink: String(bK.ink)
      });
      return (0, ye.jsx)(ze.h, {
        placement: "statBars",
        children: (0, ye.jsxs)("button", {
          type: "button",
          tabIndex: -1,
          className: Lb()("SkyblockTideChartsChip", pO.open && "Open", null !== bK.pictureName && "Complete"),
          "aria-label": eO,
          title: eO,
          onMouseDown: OO => {
            OO.preventDefault()
          },
          onClick: KO.toggle,
          children: [(0, ye.jsx)(fv, {
            chart: bK,
            showHere: !1,
            className: "Mini"
          }), (0, ye.jsxs)("span", {
            className: "SkyblockTideChartsChipCount SmallTextBold",
            children: [bK.lit, "/", bK.ink]
          })]
        })
      })
    }

    function Tv(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, Ib.h)(JX, KO.getSnapshot()),
        {
          t: XO
        } = (0, Nb.D)(),
        bK = sb(),
        eO = pO.card;
      return pO.enabled && null !== eO ? (0, ye.jsx)(re.d, {
        show: pO.open,
        close: KO.dismiss,
        togglePointerLock: !1,
        className: "SkyblockSkillsOverlay",
        children: (0, ye.jsxs)("section", {
          className: "SkyblockSkillsPanel SkyblockTideChartsPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "skyblockTideChartsTitle",
          tabIndex: -1,
          ref: bK,
          onKeyDown: me,
          children: [(0, ye.jsxs)("header", {
            className: "SkyblockTideChartsHeader",
            children: [(0, ye.jsxs)("div", {
              children: [(0, ye.jsx)("h2", {
                id: "skyblockTideChartsTitle",
                children: XO("skyblockGame:tideChartsTitle")
              }), (0, ye.jsx)("p", {
                className: "SkyblockTideChartsIntro",
                children: XO("skyblockGame:tideChartsIntro")
              })]
            }), (0, ye.jsx)(Pb.i, {
              padIgnore: !0,
              ariaLabel: XO("skyblockGame:tideChartsClose"),
              onClick: KO.dismiss
            })]
          }), pO.tabs.length > 1 && (0, ye.jsx)("div", {
            className: "SkyblockTideChartsTabs",
            role: "group",
            "aria-label": XO("skyblockGame:tideChartsIslands"),
            children: pO.tabs.map((OO => (0, ye.jsx)("button", {
              type: "button",
              className: Lb()("SkyblockTideChartsTab", OO.selected && "Selected"),
              "aria-pressed": OO.selected,
              onClick: () => {
                KO.Kp(OO.island)
              },
              children: OO.name
            }, OO.island)))
          }), (0, ye.jsxs)("div", {
            className: "SkyblockTideChartsBody",
            children: [(0, ye.jsx)("div", {
              className: "SkyblockTideChartsMap",
              role: "img",
              "aria-label": eO.gridLabel,
              children: (0, ye.jsx)(fv, {
                chart: eO,
                showHere: !0,
                className: "Large"
              })
            }), (0, ye.jsxs)("div", {
              className: "SkyblockTideChartsInfo",
              children: [(0, ye.jsx)("h3", {
                children: eO.islandName
              }), (0, ye.jsx)("p", {
                className: "SkyblockTideChartsLit",
                children: eO.litText
              }), null === eO.pictureName ? (0, ye.jsx)("p", {
                className: "SkyblockTideChartsPicture",
                children: XO("skyblockGame:tideChartsPictureHidden")
              }) : (0, ye.jsx)("p", {
                className: "SkyblockTideChartsPicture Revealed",
                children: XO("skyblockGame:tideChartsPictureRevealed", {
                  picture: eO.pictureName
                })
              }, eO.pictureName), (0, ye.jsxs)("ul", {
                className: "SkyblockTideChartsLegend",
                "aria-hidden": "true",
                children: [(0, ye.jsxs)("li", {
                  children: [(0, ye.jsx)("span", {
                    className: "SkyblockTideChartCell Cell-lit"
                  }), XO("skyblockGame:tideChartsLegendLit")]
                }), (0, ye.jsxs)("li", {
                  children: [(0, ye.jsx)("span", {
                    className: "SkyblockTideChartCell Cell-clear"
                  }), XO("skyblockGame:tideChartsLegendClear")]
                }), null !== eO.hereCell && (0, ye.jsxs)("li", {
                  children: [(0, ye.jsx)("span", {
                    className: "SkyblockTideChartCell Cell-water Here"
                  }), XO("skyblockGame:tideChartsLegendHere")]
                })]
              }), (0, ye.jsxs)("p", {
                className: "SkyblockTideChartsFooter",
                children: [(0, ye.jsx)("span", {
                  children: pO.turnsText
                }), (0, ye.jsx)("span", {
                  children: pO.bookText
                })]
              })]
            })]
          })]
        })
      }) : null
    }

    function Nv(OO) {
      var KO;
      let {
        controller: pO
      } = OO;
      const {
        selectedLanguage: XO
      } = (0, Nb.D)(), bK = XO.code;
      (0, IO.useEffect)((() => {
        pO.setTranslator(((OO, KO) => (0, Nb.z)(bK, OO, KO)), bK, ((OO, KO) => (0, Nb.s)(bK, OO, KO)))
      }), [pO, bK]);
      const eO = (0, Ib.h)(MO, pO.map.getSnapshot()),
        {
          openInGameMenuName: lO
        } = (0, Qb.l)(["openInGameMenuName"]);
      return (0, ye.jsxs)(ye.Fragment, {
        children: [(0, ye.jsx)(nl, {
          controller: pO.quests,
          display: pO.navigation.display
        }), eO.enabled && !lO && (0, ye.jsx)(ke, {
          controller: pO.navigation
        }), (0, ye.jsx)(ge, {
          controller: pO,
          minimap: eO.enabled && (null === (KO = eO.presentation) || void 0 === KO ? void 0 : KO.minimap) && (0, ye.jsx)(te, {
            view: eO.presentation.minimap,
            navigation: pO.navigation,
            controller: pO.map
          }),
          children: (0, ye.jsx)(vl, {
            controller: pO.quests,
            surface: "hud"
          })
        }), (0, ye.jsx)(Gl, {
          controller: pO.navigation
        }), (0, ye.jsx)(tv, {
          controller: pO.portalTransit
        }), (0, ye.jsx)(Cv, {
          controller: pO.dailyReward
        }), (0, ye.jsx)(Vv, {
          controller: pO.mailbox
        }), (0, ye.jsx)(Lv, {
          controller: pO.magmaward
        }), (0, ye.jsx)(Qv, {
          controller: pO.glowtide
        }), (0, ye.jsx)(vv, {
          controller: pO.passage
        }), (0, ye.jsx)(dv, {
          controller: pO.tideCharts
        }), (0, ye.jsx)(zC, {
          controller: pO.glowMeter
        }), (0, ye.jsx)(zv, {
          controller: pO.reachLog
        }), (0, ye.jsx)(Av, {
          controller: pO.hushWait
        }), (0, ye.jsx)(Fl, {
          controller: pO.lampLight
        }), (0, ye.jsx)(Ub, {
          controller: pO.skills,
          surface: "hud"
        })]
      })
    }

    function Iv(OO) {
      let {
        controller: KO
      } = OO;
      return (0, ye.jsxs)(ye.Fragment, {
        children: [(0, ye.jsx)(Wb, {
          controller: KO.map,
          navigation: KO.navigation
        }), (0, ye.jsx)(Ub, {
          controller: KO.skills,
          surface: "menu"
        }), (0, ye.jsx)(vl, {
          controller: KO.quests,
          surface: "menu"
        }), (0, ye.jsx)(Je, {
          controller: KO.dungeons
        }), (0, ye.jsx)(Ze, {
          controller: KO.collections
        }), (0, ye.jsx)(xl, {
          controller: KO.questGraph
        }), (0, ye.jsx)(Ue, {
          controller: KO.forge
        }), (0, ye.jsx)(el, {
          controller: KO.smuggler
        }), (0, ye.jsx)(Ll, {
          controller: KO.keepersChair,
          lampLight: KO.lampLight
        }), (0, ye.jsx)(Sl, {
          controller: KO.reachLog,
          regulars: KO.regulars,
          hiddenWaters: KO.hiddenWaters
        }), (0, ye.jsx)(Tl, {
          controller: KO.regulars
        }), (0, ye.jsx)(hl, {
          controller: KO.passage
        }), (0, ye.jsx)(Tv, {
          controller: KO.tideCharts
        }), (0, ye.jsx)(Bl, {
          controller: KO.dialogue
        }), (0, ye.jsx)(Zl, {
          controller: KO.autographs
        })]
      })
    }
    var yC = pO(35264);
    const gC = Wp + XX;

    function uv(OO, KO, pO, XO, bK) {
      const eO = [],
        lO = [],
        vK = pO => {
          const XO = OO.playSound(KO, pO.sound, pO.volume, pO.rate);
          XO && (lO.push(XO), void 0 !== pO.cutAfter && eO.push(setTimeout((() => {
            XO.fade(XO.getVolume(), 0, 300)
          }), pO.cutAfter)))
        };
      for (const CO of function(OO, KO) {
          const pO = [{
            sound: "rpgKnifeSlice1",
            beat: Wp,
            lead: 260,
            volume: .5,
            rate: 1
          }, {
            sound: "sweep6",
            beat: Wp,
            lead: 140,
            volume: .35,
            rate: .85
          }, {
            sound: "rpgMetalPot1",
            beat: Wp,
            lead: 100,
            volume: 1,
            rate: .78 + .04 * Math.random()
          }, {
            sound: "hit1",
            beat: Wp,
            lead: 0,
            volume: .8,
            rate: .7
          }, {
            sound: "lowDrum1",
            beat: Wp,
            lead: 60,
            volume: .6,
            rate: 1
          }, {
            sound: "zapAccent1",
            beat: 360,
            lead: 60,
            volume: .3,
            rate: 1.3
          }, {
            sound: (0, yC.d)("firecracker"),
            beat: 420,
            lead: 160,
            volume: .25,
            rate: 1.4,
            cutAfter: 500
          }, {
            sound: "fireBurn",
            beat: gC + 150,
            lead: 400,
            volume: .6,
            rate: 1.2
          }, {
            sound: (0, yC.d)("bigDrumSwish"),
            beat: gC + 80,
            lead: 480,
            volume: .35,
            rate: 1,
            cutAfter: 1400
          }, {
            sound: "magicAccent2",
            beat: gC + 60,
            lead: 180,
            volume: .5 + .06 * OO,
            rate: .82 + .07 * OO
          }];
          return OO >= 4 && pO.push({
            sound: "exp_levelup",
            beat: gC + 120,
            lead: 60,
            volume: .35,
            rate: 1
          }), KO && pO.push({
            sound: "trumpetFlare",
            beat: gC + 40,
            lead: 20,
            volume: .8,
            rate: 1
          }), pO.push({
            sound: "harp_pling",
            beat: tX,
            lead: 40,
            volume: .2,
            rate: 1.5
          }), pO
        }(pO, XO)) bK ? eO.push(setTimeout((() => {
        vK(CO)
      }), Math.max(0, CO.beat - CO.lead / CO.rate))) : CO.beat !== Wp && "magicAccent2" !== CO.sound && "trumpetFlare" !== CO.sound || vK(CO);
      return () => {
        for (const OO of eO) clearTimeout(OO);
        for (const OO of lO) OO.fade(OO.getVolume(), 0, 120)
      }
    }
    class Ev {
      constructor(OO) {
        this.deps = OO, this.pending = new Map, this.localHook = null
      }
      hookWaiting(OO, KO) {
        this.pending.delete(OO);
        const pO = this.deps.now();
        if (null === KO) {
          var XO;
          if ((null === (XO = this.localHook) || void 0 === XO ? void 0 : XO.hookId) === OO) {
            const OO = pO >= this.localHook.biteAtMs - 300;
            this.localHook = null, this.deps.onLocalWaitEnded(OO)
          }
          return
        }
        const bK = pO + KO;
        this.settle(OO, bK) || (this.pending.size >= 16 && this.pending.delete(this.pending.keys().next().value), this.pending.set(OO, {
          untilMs: pO + 1e3,
          biteAtMs: bK
        }))
      }
      getLocalHook() {
        var OO, KO;
        return null !== (OO = null === (KO = this.localHook) || void 0 === KO ? void 0 : KO.hookId) && void 0 !== OO ? OO : null
      }
      afterRender() {
        if (0 === this.pending.size) return;
        const OO = this.deps.now();
        for (const [KO, {
            untilMs: pO,
            biteAtMs: XO
          }] of this.pending)(this.settle(KO, XO) || OO > pO) && this.pending.delete(KO)
      }
      dispose() {
        this.pending.clear(), this.localHook = null
      }
      settle(OO, KO) {
        const pO = this.deps.getLineOwner(OO);
        if (null === pO) return !1;
        if (!this.deps.isLocalPlayer(pO)) return !0;
        if (this.localHook = {
            hookId: OO,
            biteAtMs: KO
          }, !this.deps.isHushWaiting()) {
          const [KO, pO] = this.deps.getHookPosition(OO);
          this.deps.onCastLanded(KO, pO)
        }
        return this.deps.onLocalHookSettled(), !0
      }
    }
    var jC = pO(3520);
    const Yv = {
        0: [15],
        1: [40, 60, 40],
        2: [40, 60, 40, 60, 60],
        3: [30, 50, 30, 50, 90]
      },
      wv = {
        1: {
          count: 24,
          rise: 2.5,
          colour: [79, 237, 237]
        },
        2: {
          count: 40,
          rise: 3.5,
          colour: [245, 209, 66]
        },
        3: {
          count: 64,
          rise: 5,
          colour: [206, 145, 206]
        }
      };
    class iC {
      constructor(OO) {
        this.deps = OO, this.tell = null
      }
      receiveTell(OO) {
        let {
          biteTellTier: KO
        } = OO;
        this.tell = {
          tier: KO,
          atMs: this.deps.now(),
          burst: !1
        }, this.burstAtHook()
      }
      onLocalHookSettled() {
        null !== this.tell && this.deps.now() - this.tell.atMs <= 500 && this.burstAtHook()
      }
      onLocalWaitEnded(OO) {
        const KO = this.tell;
        if (this.tell = null, !OO) return;
        const pO = null !== KO && this.deps.now() - KO.atMs <= 3e3 ? KO.tier : 0;
        this.deps.vibrate(Yv[pO])
      }
      burstAtHook() {
        const OO = this.tell,
          KO = this.deps.getLocalHookPosition();
        null === OO || OO.burst || null === KO || (OO.burst = !0, this.deps.playParticles(function(OO, KO) {
          let [pO, XO, bK] = KO;
          const {
            count: eO,
            rise: lO,
            colour: vK
          } = wv[OO], [CO, hO, DO] = vK;
          return {
            texture: "glint",
            pos1: [pO - .3, XO, bK - .3],
            pos2: [pO + .3, XO + .2, bK + .3],
            dir1: [-.6, lO, -.6],
            dir2: [.6, 1.4 * lO, .6],
            minLifeTime: .5,
            maxLifeTime: .9,
            minEmitPower: 1,
            maxEmitPower: 1.6,
            minSize: .12,
            maxSize: .3,
            manualEmitCount: eO,
            gravity: [0, -4, 0],
            velocityGradients: [{
              timeFraction: 0,
              factor: 1,
              factor2: 1
            }, {
              timeFraction: 1,
              factor: .2,
              factor2: .2
            }],
            colorGradients: [{
              timeFraction: 0,
              minColor: [CO, hO, DO, 1],
              maxColor: [255, 255, 255, 1]
            }, {
              timeFraction: 1,
              minColor: [CO, hO, DO, 0],
              maxColor: [CO, hO, DO, 0]
            }],
            blendMode: jC.d.Add,
            hideDist: 48
          }
        }(OO.tier, KO)))
      }
    }
    var rC = pO(1109),
      Pv = pO(1558),
      mC = pO(36);

    function sv(OO, KO) {
      return [{
        timeFraction: 0,
        minColor: [255 * OO[0], 255 * OO[1], 255 * OO[2], 1],
        maxColor: [255 * KO[0], 255 * KO[1], 255 * KO[2], 1]
      }, {
        timeFraction: 1,
        minColor: [0, 0, 0, 1]
      }]
    }
    const Hv = [0, 0, 0],
      Rv = {
        texture: "glint",
        mipmaps: !1,
        YO: 24,
        minLifeTime: .18,
        maxLifeTime: .35,
        minSize: .07,
        maxSize: .14,
        minEmitPower: 0,
        maxEmitPower: 0,
        emitRate: 12,
        dir1: Hv,
        dir2: Hv,
        blendMode: jC.d.OneOne
      },
      Sv = {
        ...Rv,
        colorGradients: sv([1, .88, .38], [1, .65, .15])
      },
      Jv = {
        ...Rv,
        colorGradients: sv([.55, .95, 1], [.9, 1, 1])
      },
      cC = [.5, .5, .5],
      Bv = {
        texture: "glint",
        mipmaps: !1,
        YO: 24,
        minLifeTime: .2,
        maxLifeTime: .4,
        minSize: .12,
        maxSize: .22,
        minEmitPower: .5,
        maxEmitPower: 1.5,
        emitRate: 0,
        colorGradients: sv([1, .12, .12], [1, .35, .2]),
        blendMode: jC.d.OneOne
      };
    class Zv {
      constructor() {
        this.drops = new Map
      }
      PX(OO, KO) {
        if ("overflowFlash" === KO.kind) {
          const [pO, XO, bK] = KO.position, eO = OO.createParticles(Bv, {
            pos: [pO, XO, bK],
            half: cC
          });
          return eO.emit(18), void eO.stop()
        }
        this.drops.has(KO.itemId) || this.drops.set(KO.itemId, {
          owner: KO.owner,
          cosmetic: KO.cosmetic,
          pickupDelayCleared: !1,
          seen: !1,
          markedAt: performance.now(),
          lastMovingAt: 0,
          lastPosition: [0, 0, 0],
          particles: null
        })
      }
      KK(OO) {
        if (0 === this.drops.size) return;
        const KO = performance.now(),
          pO = OO.getCameraPosition();
        let XO = 0;
        for (const eO of this.drops.values()) null !== eO.particles && XO++;
        for (const [eO, lO] of this.drops) {
          const vK = OO.getPositionView(eO);
          if (null === vK) {
            var bK;
            if (lO.seen || KO - lO.markedAt > 5e3) null !== lO.particles && XO--, null === (bK = lO.particles) || void 0 === bK || bK.stop(), this.drops.delete(eO);
            continue
          }
          lO.cosmetic || !OO.isLocalPlayer(lO.owner) || lO.pickupDelayCleared || (OO.clearPickupDelay(eO), lO.pickupDelayCleared = !0);
          const CO = lO.lastPosition,
            hO = lO.seen && (vK[0] - CO[0]) ** 2 + (vK[1] - CO[1]) ** 2 + (vK[2] - CO[2]) ** 2 > 4e-4,
            DO = (vK[0] - pO[0]) ** 2 + (vK[1] - pO[1]) ** 2 + (vK[2] - pO[2]) ** 2 < 2025;
          lO.seen = !0, CO[0] = vK[0], CO[1] = vK[1], CO[2] = vK[2], hO && (lO.lastMovingAt = KO), null !== lO.particles && (!DO || KO - lO.lastMovingAt > 500) && (lO.particles.stop(), lO.particles = null, XO--), hO && DO && null === lO.particles && XO < 32 && (lO.particles = OO.createParticles(lO.cosmetic ? Jv : Sv, {
            pos: vK
          }), XO++), null !== lO.particles && (lO.particles.moveTo(vK), lO.particles.setEmitRate(hO ? 12 : 0)), !hO && null === lO.particles && KO - Math.max(lO.lastMovingAt, lO.markedAt) > 2e3 && this.drops.delete(eO)
        }
      }
      dispose() {
        for (const KO of this.drops.values()) {
          var OO;
          null === (OO = KO.particles) || void 0 === OO || OO.stop()
        }
        this.drops.clear()
      }
    }
    var Gv = pO(171);
    const qC = Gv.h.uD * Gv.h.playerEyeToHeightRatio;
    class xC {
      constructor(OO) {
        this.host = OO, this.lava = [], this.loop = null, this.nextUpdateAt = 0
      }
      PX(OO) {
        this.lava = OO, this.nextUpdateAt = 0
      }
      KK() {
        var OO;
        const KO = this.host.now();
        if (KO < this.nextUpdateAt) return;
        this.nextUpdateAt = KO + 250;
        const pO = this.host.playerPosition(),
          XO = pO && this.findNearest([pO[0], pO[1] + qC, pO[2]]);
        if (!XO || XO.distance >= 40) return void this.stop();
        const bK = .5 * Math.min(1, (40 - XO.distance) / 8);
        this.loop ? this.loop.setRelativeVolume(bK) : this.loop = this.host.play("lavaFlow", bK, XO.position, 40 + qC, 9, !0), null === (OO = this.loop) || void 0 === OO || OO.setPosition(XO.position)
      }
      dispose() {
        this.stop(), this.lava = []
      }
      stop() {
        var OO;
        null === (OO = this.loop) || void 0 === OO || OO.stop(), this.loop = null
      }
      findNearest(OO) {
        let KO = -1,
          pO = 1 / 0;
        for (let XO = 0; XO < this.lava.length; XO += 3) {
          const bK = this.lava[XO] - OO[0],
            eO = this.lava[XO + 1] - OO[1],
            lO = this.lava[XO + 2] - OO[2],
            vK = bK * bK + eO * eO + lO * lO;
          vK < pO && (pO = vK, KO = XO)
        }
        return KO < 0 ? null : {
          position: [this.lava[KO], this.lava[KO + 1], this.lava[KO + 2]],
          distance: Math.sqrt(pO)
        }
      }
    }
    var nv = pO(1541),
      Wv = pO(37022);
    const tC = {
      "Grey Portal": "Gray"
    };
    for (const XC of bK.Bc) tC[`${XC} Portal`] = XC;
    const kC = Object.keys(tC),
      Uv = Object.fromEntries(kC.map((OO => [OO, (0, bK.S)(bK.J[`${(0,bK.ke)(tC[OO])}Team`])])));
    Object.fromEntries(kC.map((OO => [OO, bK.J[`${(0,bK.ke)(tC[OO])}UiText`]])));
    class OC {
      constructor(OO, KO) {
        this.presentation = OO, this.portal = KO, this.unlocked = void 0
      }
      PX(OO) {
        const KO = !1 === this.unlocked && OO;
        this.unlocked = OO, this.KK();
        const {
          min: pO,
          max: XO,
          unlockedBlock: bK
        } = this.portal;
        if (KO && this.presentation.hasChunk(...pO)) {
          const [OO, KO, eO] = Uv[bK];
          this.presentation.playParticles({
            pos1: [...pO],
            pos2: XO.map((OO => OO + 1)),
            dir1: [-1, 0, -1],
            dir2: [1, 1, 1],
            texture: "glint",
            minLifeTime: .4,
            maxLifeTime: 1.2,
            minEmitPower: .5,
            maxEmitPower: 1.5,
            minSize: .12,
            maxSize: .25,
            manualEmitCount: 80,
            hideDist: 64,
            gravity: [0, .5, 0],
            colorGradients: [{
              timeFraction: 0,
              minColor: [OO, KO, eO, 1],
              maxColor: [Math.min(255, OO + 55), Math.min(255, KO + 55), Math.min(255, eO + 90), 1]
            }],
            velocityGradients: [{
              timeFraction: 0,
              factor: 1,
              factor2: 1
            }],
            blendMode: 1
          })
        }
      }
      KK() {
        var OO;
        const KO = this.unlocked ? this.portal.unlockedBlock : null !== (OO = this.portal.lockedBlock) && void 0 !== OO ? OO : "Light Gray Portal",
          {
            min: pO,
            max: XO
          } = this.portal;
        for (let bK = pO[0]; bK <= XO[0]; bK++)
          for (let OO = pO[1]; OO <= XO[1]; OO++)
            for (let eO = pO[2]; eO <= XO[2]; eO++) this.presentation.hasChunk(bK, OO, eO) && this.presentation.ZF(bK, OO, eO) !== KO && this.presentation.EKO(bK, OO, eO, KO)
      }
    }
    const KC = {
        farming_1: {
          raises: OO => "NPC" === OO.type && "chef" === OO.variation,
          rise: .4
        },
        fishing_1: {
          raises: OO => "Draugr Warper" === OO.type,
          rise: .4
        }
      },
      pC = (OO, KO, pO, eO) => {
        let {
          localPlayerId: lO
        } = eO;
        const vK = new Fb({
          translate: (OO, KO) => (0, Nb.z)(rC.f.get().getCurrentLanguageCode(), OO, KO),
          translateWithIcons: (OO, KO) => (0, Nb.s)(rC.f.get().getCurrentLanguageCode(), OO, KO),
          setMenuOpen: OO => {
            OO ? (0, BO.o)() : (0, BO.g)()
          },
          dismissMenu: BO.j,
          publishSkills: OO => {
            ZO.i.pl(Kp, OO, !0)
          },
          publishQuests: OO => {
            ZO.i.pl(ep, OO, !0)
          },
          publishQuestNotification: OO => {
            ZO.i.pl(lp, OO, !0)
          },
          publishDungeons: OO => {
            ZO.i.pl(hp, OO, !0)
          },
          publishCollections: OO => {
            ZO.i.pl(Yp, OO, !0)
          },
          publishMap: OO => {
            ZO.i.pl(MO, OO, !0)
          },
          publishHud: OO => {
            ZO.i.pl(Mb, OO, !0)
          },
          publishPortalTransit: OO => {
            ZO.i.pl(iX, OO, !0)
          },
          isLoadingScreenUp: () => Qb.d.get("loadingOverlayVisible"),
          publishDailyReward: OO => {
            ZO.i.pl(mX, OO, !0)
          },
          publishMailbox: OO => {
            ZO.i.pl(Jp, OO, !0)
          },
          publishQuestGraph: OO => {
            ZO.i.pl(Bp, OO, !0)
          },
          publishForge: OO => {
            ZO.i.pl(DX, OO, !0)
          },
          publishSmuggler: OO => {
            ZO.i.pl(oX, OO, !0)
          },
          publishKeepersChair: OO => {
            ZO.i.pl(TX, OO, !0)
          },
          publishReachLog: OO => {
            ZO.i.pl(IX, OO, !0)
          },
          publishLampLight: OO => {
            ZO.i.pl(YX, OO, !0)
          },
          publishMagmaward: OO => {
            ZO.i.pl(ib, OO, !0)
          },
          publishGlowtide: OO => {
            ZO.i.pl(PX, OO, !0)
          },
          publishGlowMeter: OO => {
            ZO.i.pl(sX, OO, !0)
          },
          publishHushWait: OO => {
            ZO.i.pl(RX, OO, !0)
          },
          publishPassage: OO => {
            ZO.i.pl(LX, OO, !0)
          },
          publishTideCharts: OO => {
            ZO.i.pl(JX, OO, !0)
          },
          publishRegulars: OO => {
            ZO.i.pl(WX, OO, !0)
          },
          publishHiddenWaters: OO => {
            ZO.i.pl(Kb, OO, !0)
          },
          publishDialogue: OO => {
            ZO.i.pl(Xb, OO, !0)
          },
          publishAutographs: OO => {
            ZO.i.pl(Cb, OO, !0)
          },
          onDailyRewardStarted: OO => {
            RO.playSound(lO, OO.day === gK ? "trumpetFlare" : "chestOpen", .8, 1)
          },
          onDailyRewardCoinLanded: (OO, KO) => {
            RO.playSound(lO, "exp_collect", .35, 1 + .6 * OO / (KO - 1)), ZO.i.pl(sp, OO === KO - 1)
          },
          onDailyRewardItemLanded: OO => {
            RO.playSound(lO, "pickUp", .6, 1 + .15 * OO)
          },
          onMailboxStarted: () => {
            RO.playSound(lO, "rpgMetalClick", .6, 1), RO.playSound(lO, "rpgBookFlip1", .7, 1)
          },
          onDailyRewardFinished: () => {
            RO.sendCommand("skyblockDailyRewardDone")
          },
          journeyStorage: mC.h,
          requestTracking: OO => {
            RO.sendCommand(`quests track ${OO}`)
          },
          requestDungeonEnter: (OO, KO) => {
            RO.sendCommand(`${jK.l}${OO} ${KO}`)
          },
          requestQuestJump: OO => {
            RO.sendCommand(`${YO} jump ${OO}`)
          },
          requestQuestArrive: (OO, KO) => {
            const pO = `${YO} arrive ${OO}`;
            RO.sendCommand(KO ? `${pO} complete` : pO)
          },
          requestForge: OO => {
            let {
              blade: KO,
              guard: pO,
              handle: XO
            } = OO;
            RO.sendCommand(`forge ${KO} ${pO} ${XO}`)
          },
          requestDialogue: () => {
            RO.sendCommand("quests dialogue")
          },
          requestSmuggle: (OO, KO) => {
            RO.sendCommand(`smuggle ${OO} ${KO}`)
          },
          requestKeepersChairAim: OO => {
            RO.sendCommand(`keeperschair-aim ${OO}`)
          },
          requestReachLogOpen: () => {
            RO.sendCommand("reachlog-open")
          },
          requestLampLight: OO => {
            RO.sendCommand(`${OO}`)
          },
          requestTravel: OO => {
            RO.sendCommand(`map travel ${OO.kind} ${OO.id} ${OO.requestId}`)
          }
        });
        let CO, hO, DO, aK, oO, FO, AO, fO, dO, TO, yK, uO, wO;
        const mK = new Zv;
        let RO, SO = null;
        const qK = KC[null !== pO && void 0 !== pO ? pO : ""],
          xK = (OO, KO) => {
            null !== qK && void 0 !== qK && qK.raises(KO) && RO.setNametagOffset(OO, qK.rise)
          },
          nO = new iC({
            getLocalHookPosition: () => {
              const OO = WO.getLocalHook();
              return null !== OO && RO.checkValid(OO) ? RO.fV(OO) : null
            },
            playParticles: OO => {
              RO.playParticleEffect(OO)
            },
            vibrate: OO => {
              GO.f.play("fishBite", OO)
            },
            now: () => performance.now()
          }),
          WO = new Ev({
            getLineOwner: OO => RO.checkValid(OO) ? RO.getLineOwner(OO) : null,
            isLocalPlayer: OO => RO.isLocalPlayer(OO),
            getHookPosition: OO => {
              const [KO, , pO] = RO.fV(OO);
              return [KO, pO]
            },
            isHushWaiting: () => {
              var OO;
              return "waiting" === (null === (OO = vK.hushWait.getSnapshot()) || void 0 === OO ? void 0 : OO.phase)
            },
            onCastLanded: (OO, KO) => {
              vK.tideCharts.castLanded(OO, KO)
            },
            onLocalHookSettled: () => {
              nO.onLocalHookSettled()
            },
            onLocalWaitEnded: OO => {
              nO.onLocalWaitEnded(OO)
            },
            now: () => performance.now()
          }),
          tK = new xC({
            now: () => performance.now(),
            playerPosition: () => RO.checkValid(lO) ? RO.fV(lO) : null,
            play: (OO, KO, pO, XO, bK, eO) => RO.playSound(lO, OO, KO, 1, {
              I9: pO,
              maxHearDist: XO,
              refDistance: bK
            }, eO)
          }),
          kK = new Map;
        let UO;
        return {
          onCreate: OO => {
            if (RO = OO, SO = new Wv.SkyblockEntityFacing(OO, qK ? xK : null), vK.portalTransit.resumeArrival(null !== pO && void 0 !== pO ? pO : null), (null !== pO && void 0 !== pO ? pO : XO) === XO) {
              let OO = -1 / 0;
              UO = ZO.i.subscribe("toggleMenu", (KO => {
                const pO = performance.now();
                "inventory|Workbench" !== KO || "cross_to_hub" !== vK.quests.getTrackedQuestId() || pO - OO < 1e4 || (OO = pO, RO.sendCommand("skyblockWorkbenchOpened"))
              }))
            }
            for (const [XO, bK] of Object.entries(null !== (KO = iK[null !== pO && void 0 !== pO ? pO : ""]) && void 0 !== KO ? KO : {})) {
              var KO;
              kK.set(XO, new OC({
                hasChunk: (KO, pO, XO) => OO.isBlockInLoadedChunk(KO, pO, XO),
                ZF: (KO, pO, XO) => OO.blockIdToBlockName(OO.getBlockId(KO, pO, XO)),
                EKO: (KO, pO, XO, bK) => {
                  OO.EKO(KO, pO, XO, bK)
                },
                playParticles: KO => {
                  OO.playParticleEffect(KO)
                }
              }, bK))
            }
            wO = (0, nv.g)((OO => function(OO) {
              return Object.hasOwn(RK, OO) || OO.startsWith("npc_")
            }(OO) ? JK(OO) : null)), vK.resolveItemName = (KO, pO) => {
              const XO = OO.getItemStat(lO, KO, "displayName");
              return XO && "object" === typeof XO && "translationKey" in XO ? pO(XO.translationKey, (0, Nb.q)(XO.params, Pv.c.shown)) : "string" === typeof XO ? pO(XO) : KO
            }, vK.quests.notifications.onShown = OO => {
              "quest" === OO ? RO.playSound(lO, "magicAccent1", 1, 1) : "skillLevel" === OO ? RO.playSound(lO, "magicAccent1", 1, .6) : "landmark" === OO ? RO.playSound(lO, "trumpetFlare", 1, .6) : "npcNote" === OO ? RO.playSound(lO, "magicAccent2", .8, 1.1) : "started" === OO ? RO.playSound(lO, (0, yC.d)("bigDrumSwish"), 1, 1) : RO.playSound(lO, (0, yC.d)("rpgHandleSmallLeather"), 1, 1)
            }, vK.forge.onPartSelected = () => {
              RO.playSound(lO, "rpgMetalClick", .6, .9 + .2 * Math.random())
            }, vK.forge.onForgeStarted = (KO, pO, XO) => uv(OO, lO, KO, pO, XO), vK.smuggler.onBought = () => {
              RO.playSound(lO, (0, yC.d)("rpgHandleSmallLeather"), 1, 1), RO.playSound(lO, "chestOpen", .6, 1)
            }, vK.compass.register(new VO(vK.map, !0)), vK.compass.register(new VO(vK.map, !1)), vK.compass.register(new QO(vK.map)), vK.compass.register(new zK((() => vK.quests.getSnapshot().compassTarget)));
            for (const pO of ["enemy", "npc"]) vK.compass.register(new LO(vK.map, pO, (KO => OO.checkValid(KO) ? OO.fV(KO) : void 0), (KO => OO.isAlive(KO))))
          },
          onAfterRender: (OO, KO) => {
            const pO = RO.checkValid(lO) ? RO.fV(lO) : null;
            vK.navigation.afterRender(pO, performance.now(), KO), vK.glowtide.afterRender(pO, KO.cameraHeading), vK.tideCharts.afterRender(pO), WO.afterRender()
          },
          onClose: () => {
            var OO, KO, pO, XO, bK, eO, lO, MO, FO, VO, LO, QO, zK, NO, IO;
            UO && ZO.i.unsubscribe(UO), null === (OO = wO) || void 0 === OO || OO(), mK.dispose(), tK.dispose(), null === (KO = SO) || void 0 === KO || KO.dispose(), WO.dispose(), vK.dispose(), null === (pO = CO) || void 0 === pO || pO(), null === (XO = hO) || void 0 === XO || XO(), null === (bK = DO) || void 0 === bK || bK(), null === (eO = aK) || void 0 === eO || eO(), null === (lO = oO) || void 0 === lO || lO(), null === (MO = AO) || void 0 === MO || MO(), null === (FO = undefined) || void 0 === FO || FO(), null === (VO = fO) || void 0 === VO || VO(), null === (LO = dO) || void 0 === LO || LO(), null === (QO = TO) || void 0 === QO || QO(), null === (zK = yK) || void 0 === zK || zK(), null === (NO = undefined) || void 0 === NO || NO(), null === (IO = uO) || void 0 === IO || IO()
          },
          onPlayerChangeBlock: (OO, KO, XO, eO, CO, hO) => {
            if (OO === lO && "Air" === hO) {
              const OO = RO.getClientOption(lO, "creative");
              vK.skills.predictBlock([KO, XO, eO], CO, OO);
              const hO = function(OO, KO) {
                  if ("hub" === KO || "farming_1" === KO || "mining_1" === KO) return !sO.has(OO) || "hub" !== KO && "mining_1" !== KO ? Object.hasOwn(PO, OO) ? PO[OO] : void 0 : rK
                }(CO, pO),
                DO = ("hub" === pO || "mining_1" === pO) && (bK.$c.some((OO => OO === CO)) || Object.hasOwn(HO, CO) || "mining_1" === pO && "Block of Coal" === CO);
              OO || void 0 === hO && !DO || RO.EKO(KO, XO, eO, null !== hO && void 0 !== hO ? hO : rK)
            }
          },
          onPlayerAttackEntity: (OO, KO) => {
            if (OO !== lO || "Player" !== RO.getEntityType(KO)) return;
            const [pO, XO, bK] = RO.fV(KO);
            RO.burstParticlePreset("critical", [pO, XO + 1, bK], 10)
          },
          onChangeBlockFail: OO => {
            for (const {
                cKO: KO
              }
              of OO) vK.skills.rejectBlock(KO)
          },
          onReceivedMessageFromServer: (OO, KO) => {
            if ("skyblockGatedPortal" === OO) {
              var pO;
              const [OO, XO] = KO;
              return void(null === (pO = kK.get(OO)) || void 0 === pO || pO.PX(XO))
            }
            if ("skyblockDailyReward" === OO) return void vK.dailyReward.PX(KO);
            if ("skyblockMailbox" === OO) return void vK.mailbox.PX(KO);
            if ("skyblockPortalTransit" === OO) return void vK.portalTransit.PX(KO);
            if ("skyblockLoot" === OO) return void mK.PX(RO, KO);
            if ("skyblockLava" === OO) return void tK.PX(KO);
            if ("skyblockForge" === OO) return void vK.forge.PX(KO);
            if ("skyblockMagmaward" === OO) return void vK.magmaward.PX(KO);
            if ("skyblockGlowtide" === OO) return void vK.glowtide.PX(KO);
            if ("skyblockGlowMeter" === OO) return void vK.glowMeter.PX(KO);
            if ("skyblockHushWait" === OO) return void vK.hushWait.PX(KO);
            if ("skyblockPassage" === OO) {
              const OO = KO;
              return vK.passage.PX(OO), vK.reachLog.receivePassagePhase(OO.passagePhase), TO ??= (0, NO.u)({
                id: "skyblockPassage",
                order: 5,
                labelKey: "skyblockGame:passageButton",
                icon: {
                  kind: "item",
                  name: "Moonfish"
                },
                panel: !0,
                onClick: vK.passage.show
              }), void vK.keepersChair.receivePassage({
                keepersChairPassagePhase: OO.passagePhase,
                keepersChairPassageNextPhase: OO.passageNextPhase,
                keepersChairPassageTurnsInMs: OO.passageTurnsInMs
              })
            }
            if ("skyblockTideCharts" === OO) {
              const OO = KO;
              return vK.tideCharts.PX(OO), void(OO.tideCharts.length > 0 && (yK ??= (0, NO.u)({
                id: "skyblockTideCharts",
                order: 8,
                labelKey: "skyblockGame:tideChartsTitle",
                icon: {
                  kind: "item",
                  name: "Chunk Map"
                },
                panel: !0,
                onClick: vK.tideCharts.show
              })))
            }
            if (OO === JO.C) {
              var XO;
              const {
                hookId: OO,
                waiting: pO
              } = KO;
              return void WO.hookWaiting(OO, null !== (XO = null === pO || void 0 === pO ? void 0 : pO.remainingMs) && void 0 !== XO ? XO : null)
            }
            if ("skyblockBiteTell" === OO) return void nO.receiveTell(KO);
            if ("skyblockSmuggler" === OO) return void vK.smuggler.PX(KO);
            if ("skyblockKeepersChair" === OO) return vK.keepersChair.PX(KO), void vK.lampLight.setAtChair(vK.keepersChair.isAtChair());
            if ("skyblockLampLight" === OO) {
              const OO = KO;
              var bK;
              if (vK.lampLight.PX(OO), OO.lampLightReleasing) dO ??= (0, NO.u)({
                id: "skyblockLampLightKeepCatches",
                order: 7,
                labelKey: "skyblockGame:lampLightKeepCatches",
                icon: {
                  kind: "item",
                  name: "Bucket"
                },
                onClick: () => {
                  vK.lampLight.setRelease(!1)
                }
              });
              else null === (bK = dO) || void 0 === bK || bK(), dO = void 0;
              return
            }
            if ("skyblockRegulars" === OO) return void vK.regulars.PX(KO);
            if ("skyblockHiddenWaters" === OO) return void vK.hiddenWaters.PX(KO);
            if ("skyblockReachLog" === OO) return vK.reachLog.PX(KO), void(fO ??= (0, NO.u)({
              id: "skyblockReachLog",
              order: 6,
              labelKey: "skyblockGame:reachLogTitle",
              icon: {
                kind: "item",
                name: gb
              },
              onClick: vK.reachLog.ask
            }));
            if ("skyblockBurrowDoor" === OO) {
              for (const [OO, pO, XO, bK] of KO) RO.EKO(OO, pO, XO, bK);
              return
            }
            if ("skyblockHud" === OO) vK.receiveHud(KO);
            else if ("skyblockMap" === OO) vK.map.PX(KO);
            else if (OO === cK.f) vK.skills.PX(KO);
            else if (OO === EO && "dialogue" === KO.kind) vK.dialogue.PX(KO);
            else if (OO === EO) vK.quests.PX(KO);
            else if (OO === jK.k) vK.dungeons.PX(KO);
            else if ("sbCollections" === OO) vK.collections.PX(KO);
            else if ("skyblockQuestGraph" === OO) vK.questGraph.PX(KO);
            else {
              if ("skyblockAutographs" !== OO) return;
              vK.autographs.PX(KO)
            }
            if (!hO && vK.map.getSnapshot().enabled) {
              const OO = (0, NO.u)({
                  id: "skyblockMap",
                  order: 3,
                  labelKey: "skyblockGame:map",
                  icon: {
                    kind: "item",
                    name: "Compass"
                  },
                  panel: !0,
                  onClick: vK.map.show
                }),
                KO = (0, BO.p)(vK.map.show);
              hO = () => {
                OO(), KO()
              }
            }!DO && vK.skills.getSnapshot().enabled && (DO = (0, NO.u)({
              id: "skyblockSkills",
              order: 0,
              labelKey: "skyblockGame:skills",
              icon: {
                kind: "item",
                name: "Iron Sword"
              },
              panel: !0,
              onClick: vK.skills.show
            })), !AO && vK.collections.getSnapshot().enabled && (AO = (0, NO.u)({
              id: "skyblockCollections",
              order: 2.5,
              labelKey: "skyblockGame:collections",
              icon: {
                kind: "item",
                name: "Coal"
              },
              panel: !0,
              onClick: vK.collections.show
            })), !aK && vK.quests.getSnapshot().enabled && (aK = (0, NO.u)({
              id: "skyblockQuests",
              order: 1,
              labelKey: "skyblockGame:quests",
              icon: {
                kind: "item",
                name: "Book"
              },
              panel: !0,
              onClick: vK.quests.show
            })), !uO && vK.autographs.getSnapshot().enabled && (uO = (0, NO.u)({
              id: "skyblockAutographs",
              order: 5,
              labelKey: "skyblockGame:autographs",
              icon: {
                kind: "item",
                name: "Name Tag"
              },
              panel: !0,
              onClick: vK.autographs.show
            }));
            const eO = vK.dungeons.getSnapshot().enabled;
            var lO;
            (DO || aK || eO) && FO !== eO && (FO = eO, null === (lO = oO) || void 0 === lO || lO(), oO = (0, NO.u)({
              id: "skyblockDungeons",
              order: 2,
              labelKey: "skyblockGame:dungeons",
              icon: {
                kind: "image",
                src: EK
              },
              disabled: !eO,
              panel: !0,
              onClick: vK.dungeons.show
            }));
            CO || (CO = (0, BO.q)((0, IO.createElement)(Nv, {
              controller: vK
            }), {
              content: (0, IO.createElement)(Iv, {
                controller: vK
              }),
              onClose: vK.close
            }))
          },
          KK: () => {
            var OO;
            for (const KO of kK.values()) KO.KK();
            mK.KK(RO), tK.KK(), null === (OO = SO) || void 0 === OO || OO.KK(), vK.skills.KK(), vK.quests.KK(), vK.dailyReward.KK(), vK.mailbox.KK(), vK.map.KK()
          }
        }
      }
  },
  36928: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      g: () => vK,
      k: () => XO,
      l: () => eO,
      n: () => bK,
      o: () => CO
    });
    const XO = "skyblockDungeons",
      bK = "skyblockHeldBoss",
      eO = "dungeonEnter ",
      lO = Object.freeze({
        easy: "skyblockGame:difficultyEasy",
        medium: "skyblockGame:difficultyMedium",
        hard: "skyblockGame:difficultyHard",
        insane: "skyblockGame:difficultyInsane"
      }),
      vK = Object.freeze({
        easy: "#77b326",
        medium: "#eac03d",
        hard: "#df7622",
        insane: "#e74d4d"
      });

    function CO(OO) {
      let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      const pO = Math.max(0, Math.floor(OO)),
        XO = Math.floor(pO % 1e3 / 100),
        bK = Math.floor(pO / 1e3),
        eO = bK % 60,
        lO = Math.floor(bK / 60),
        vK = lO % 60,
        CO = Math.floor(lO / 60),
        hO = OO => OO < 10 ? `0${OO}` : String(OO),
        DO = KO ? `.${XO}` : "";
      return CO > 0 ? `${CO}:${hO(vK)}:${hO(eO)}${DO}` : `${vK}:${hO(eO)}${DO}`
    }
  },
  34952: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      f: () => XO
    });
    const XO = "skyblockSkills",
      bK = "skills_test_gym"
  },
  8333: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => lO
    });
    const XO = [{
      threshold: 10n ** 180n,
      suffix: "NoQig"
    }, {
      threshold: 10n ** 177n,
      suffix: "OcQig"
    }, {
      threshold: 10n ** 174n,
      suffix: "SpQig"
    }, {
      threshold: 10n ** 171n,
      suffix: "SQig"
    }, {
      threshold: 10n ** 168n,
      suffix: "QiQig"
    }, {
      threshold: 10n ** 165n,
      suffix: "QaQig"
    }, {
      threshold: 10n ** 162n,
      suffix: "TQig"
    }, {
      threshold: 10n ** 159n,
      suffix: "DQig"
    }, {
      threshold: 10n ** 156n,
      suffix: "UQig"
    }, {
      threshold: 10n ** 153n,
      suffix: "Qig"
    }, {
      threshold: 10n ** 150n,
      suffix: "NoQag"
    }, {
      threshold: 10n ** 147n,
      suffix: "OcQag"
    }, {
      threshold: 10n ** 144n,
      suffix: "SpQag"
    }, {
      threshold: 10n ** 141n,
      suffix: "SQag"
    }, {
      threshold: 10n ** 138n,
      suffix: "QiQag"
    }, {
      threshold: 10n ** 135n,
      suffix: "QaQag"
    }, {
      threshold: 10n ** 132n,
      suffix: "TQag"
    }, {
      threshold: 10n ** 129n,
      suffix: "DQag"
    }, {
      threshold: 10n ** 126n,
      suffix: "UQag"
    }, {
      threshold: 10n ** 123n,
      suffix: "Qag"
    }, {
      threshold: 10n ** 120n,
      suffix: "NoTg"
    }, {
      threshold: 10n ** 117n,
      suffix: "OcTg"
    }, {
      threshold: 10n ** 114n,
      suffix: "SpTg"
    }, {
      threshold: 10n ** 111n,
      suffix: "STg"
    }, {
      threshold: 10n ** 108n,
      suffix: "QiTg"
    }, {
      threshold: 10n ** 105n,
      suffix: "QaTg"
    }, {
      threshold: 10n ** 102n,
      suffix: "TTg"
    }, {
      threshold: 10n ** 99n,
      suffix: "DTg"
    }, {
      threshold: 10n ** 96n,
      suffix: "UTg"
    }, {
      threshold: 10n ** 93n,
      suffix: "Tg"
    }, {
      threshold: 10n ** 90n,
      suffix: "NoVg"
    }, {
      threshold: 10n ** 87n,
      suffix: "OcVg"
    }, {
      threshold: 10n ** 84n,
      suffix: "SpVg"
    }, {
      threshold: 10n ** 81n,
      suffix: "SVg"
    }, {
      threshold: 10n ** 78n,
      suffix: "QiVg"
    }, {
      threshold: 10n ** 75n,
      suffix: "QaVg"
    }, {
      threshold: 10n ** 72n,
      suffix: "TVg"
    }, {
      threshold: 10n ** 69n,
      suffix: "DVg"
    }, {
      threshold: 10n ** 66n,
      suffix: "UVg"
    }, {
      threshold: 10n ** 63n,
      suffix: "Vg"
    }, {
      threshold: 10n ** 60n,
      suffix: "NoD"
    }, {
      threshold: 10n ** 57n,
      suffix: "OcD"
    }, {
      threshold: 10n ** 54n,
      suffix: "SpD"
    }, {
      threshold: 10n ** 51n,
      suffix: "SD"
    }, {
      threshold: 10n ** 48n,
      suffix: "QiD"
    }, {
      threshold: 10n ** 45n,
      suffix: "QaD"
    }, {
      threshold: 10n ** 42n,
      suffix: "TD"
    }, {
      threshold: 10n ** 39n,
      suffix: "DD"
    }, {
      threshold: 10n ** 36n,
      suffix: "UD"
    }, {
      threshold: 10n ** 33n,
      suffix: "D"
    }, {
      threshold: 10n ** 30n,
      suffix: "No"
    }, {
      threshold: 10n ** 27n,
      suffix: "Oc"
    }, {
      threshold: 10n ** 24n,
      suffix: "Sep"
    }, {
      threshold: 10n ** 21n,
      suffix: "S"
    }, {
      threshold: 10n ** 18n,
      suffix: "Qi"
    }, {
      threshold: 10n ** 15n,
      suffix: "Qa"
    }, {
      threshold: 10n ** 12n,
      suffix: "T"
    }, {
      threshold: 10n ** 9n,
      suffix: "B"
    }, {
      threshold: 10n ** 6n,
      suffix: "M"
    }, {
      threshold: 1000n,
      suffix: "K"
    }];

    function bK(OO) {
      let KO, pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 3;
      if ("number" === typeof OO) {
        if (!Number.isFinite(OO)) return "0";
        if (Math.abs(OO) < 100) {
          const KO = OO < 0 ? "-" : "",
            pO = Math.abs(OO);
          return pO >= 10 ? `${KO}${pO.toFixed(1).replace(/\.0$/,"")}` : `${KO}${pO.toFixed(2).replace(/\.?0+$/,"")}`
        }
        KO = BigInt(Math.floor(OO))
      } else KO = OO;
      const bK = KO < 0n ? -KO : KO,
        eO = KO < 0n ? "-" : "",
        lO = bK.toString();
      if (lO.length <= pO) return `${eO}${lO}`;
      const vK = 3 * Math.floor((lO.length - 1) / 3);
      if (vK < 3) return `${eO}${lO}`;
      if (vK > 3 * XO.length) {
        const OO = lO[0],
          KO = lO.slice(1, 3).replace(/0+$/, "");
        return `${eO}${KO?`${OO}.${KO}`:OO}e${lO.length-1}`
      }
      const {
        threshold: CO,
        suffix: hO
      } = XO[XO.length - vK / 3], DO = bK / CO, MO = Number(1000n * (bK % CO) / CO), aK = Number(DO) + MO / 1e3;
      let oO;
      return oO = aK >= 100 ? Math.floor(aK).toString() : aK >= 10 ? aK.toFixed(1).replace(/\.0$/, "") : aK.toFixed(2).replace(/\.?0+$/, ""), `${eO}${oO}${hO}`
    }
    const eO = XO.map((OO => {
      let {
        threshold: KO,
        suffix: pO
      } = OO;
      return {
        threshold: Number(KO),
        suffix: pO
      }
    })).filter((OO => {
      let {
        threshold: KO
      } = OO;
      return Number.isFinite(KO)
    }));

    function lO(OO) {
      const KO = Math.abs(OO),
        pO = OO < 0 ? "-" : "";
      for (const {
          threshold: XO,
          suffix: bK
        }
        of eO)
        if (KO >= XO) {
          const OO = KO / XO;
          if (OO >= 1e3) return `${pO}${KO.toExponential(2).replace("e+","e")}`;
          let eO;
          return eO = OO >= 100 ? Math.floor(OO).toString() : OO >= 10 ? OO.toFixed(1).replace(/\.0$/, "") : OO.toFixed(2).replace(/\.?0+$/, ""), `${pO}${eO}${bK}`
        } return `${pO}${KO}`
    }
  },
  36941: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/combat_1.72ac23641446e4f80923.png"
  },
  36949: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/dungeon_crumbling_crypt.39389aef74bd36e64180.png"
  },
  36958: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/dungeon_frozen_hollow.042bf06d2cfd2c68c7e6.png"
  },
  36960: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/dungeon_wildwood_grove.d5115bf7a4d3fc811ff4.png"
  },
  36962: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/dungeons.6836b40c30687755a545.png"
  },
  36969: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/farming_1.08302e28e41bf98474fe.png"
  },
  36973: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/fishing_1.c63e97744abce5bb9af7.png"
  },
  36982: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/hub.8b20a64678134496251d.png"
  },
  36985: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/island.113e20c7bd7db93fe1ce.png"
  },
  36991: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/mining_1.68cac4bdadc5ef809ae5.png"
  },
  36997: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/mining_1_bridge.56ff82ba845db0b52726.png"
  },
  37002: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/mining_1_gallery.4e799e6329dbc66249ce.png"
  },
  37008: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/mining_1_hollow.82ed2e9c753519918230.png"
  },
  37012: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/mining_1_village.c2a625c1c4541a1fbe65.png"
  },
  17473: OO => {
    OO.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAFT2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS41LjAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIgogICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iCiAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIKICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIKICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgZXhpZjpQaXhlbFhEaW1lbnNpb249IjEwIgogICBleGlmOlBpeGVsWURpbWVuc2lvbj0iMTAiCiAgIGV4aWY6Q29sb3JTcGFjZT0iMSIKICAgdGlmZjpJbWFnZVdpZHRoPSIxMCIKICAgdGlmZjpJbWFnZUxlbmd0aD0iMTAiCiAgIHRpZmY6UmVzb2x1dGlvblVuaXQ9IjIiCiAgIHRpZmY6WFJlc29sdXRpb249IjcyLzEiCiAgIHRpZmY6WVJlc29sdXRpb249IjcyLzEiCiAgIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiCiAgIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSIKICAgeG1wOk1vZGlmeURhdGU9IjIwMjUtMDktMTFUMDY6MDg6MTMtMDQ6MDAiCiAgIHhtcDpNZXRhZGF0YURhdGU9IjIwMjUtMDktMTFUMDY6MDg6MTMtMDQ6MDAiPgogICA8ZGM6dGl0bGU+CiAgICA8cmRmOkFsdD4KICAgICA8cmRmOmxpIHhtbDpsYW5nPSJ4LWRlZmF1bHQiPlBsYW5rczwvcmRmOmxpPgogICAgPC9yZGY6QWx0PgogICA8L2RjOnRpdGxlPgogICA8eG1wTU06SGlzdG9yeT4KICAgIDxyZGY6U2VxPgogICAgIDxyZGY6bGkKICAgICAgc3RFdnQ6YWN0aW9uPSJwcm9kdWNlZCIKICAgICAgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWZmaW5pdHkgRGVzaWduZXIgMS4xMC42IgogICAgICBzdEV2dDp3aGVuPSIyMDI1LTA5LTExVDA2OjA4OjEzLTA0OjAwIi8+CiAgICA8L3JkZjpTZXE+CiAgIDwveG1wTU06SGlzdG9yeT4KICA8L3JkZjpEZXNjcmlwdGlvbj4KIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cjw/eHBhY2tldCBlbmQ9InIiPz5RDOytAAABgWlDQ1BzUkdCIElFQzYxOTY2LTIuMQAAKJF1kbtLA0EQhz9PxTcRtLAQDKJWKlEhaGOR4AvUIp7gq0kul0RI4nEXkWAr2AoKoo2vQv8CbQVrQVAUQay1VbTRcM7lAhExs8zOt7/dGXZnQVGTWsqq8EEqnTFDYwHv3PyCt+qVGuqoRaEtrFnG1MyoSkn7vKfMibc9Tq3S5/61uqhuaVBWLTysGWZGeFx4ci1jOLwj3KwlwlHhM+FuUy4ofOfoEZdfHI67/O2wqYaCoDQKe+O/OPKLtYSZEpaX05FKrmqF+zgvqdfTszMS28VbsQgxRgAvE4wQxE8fQzL76aGfXllRIt+Xz59mRXI1mQ2ymCwTJ0GGblFXpbouMSa6LiNJ1un/375asYF+t3p9ACqfbfu9E6q2Ibdl219Htp07hvInuEwX81cOYfBD9K2i1nEAng04vypqkV242ISWRyNshvNSubgSi8HbKTTMQ9MN1C66PSvsc/IA6rp81TXs7UOXnPcs/QAlUWfIbV2y+QAAAAlwSFlzAAALEwAACxMBAJqcGAAAAG9JREFUGJVjYKAQ/IdiOGDEpqh6jiYDAwMDQ2vKdbgaJnzG5nSqwEzHUPj/1WJThpZPDxg+vv2N212vFpv+/9/H+f9yFi/MjXB3wtz4/38fJwMDAwPDlTssDLrTPmO4nwXGuHIHwsSmCMVELGLkAQBi0iUZsdoC/wAAAABJRU5ErkJggg=="
  },
  19647: OO => {
    OO.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAABgWlDQ1BzUkdCIElFQzYxOTY2LTIuMQAAKJF1kc8rRFEUxz9miMYIsbCweGlYDflREymLmRgKizHKYPPmmTejZsbrvZFkq2wVJTZ+LfgL2CprpYiUbFkTG/ScZ6Zmkjm3c8/nfu89p3vPBVc0rWWsym7IZHNmJBxUZmKzSvUzNbTSyCAeVbOMiamRKGXt444KJ950OrXKn/vXahcSlgYVNcJDmmHmhEeFx1dyhsPbws1aSl0QPhX2m3JB4VtHj+f5xeFknr8cNqORELgahJVkCcdLWEuZGWF5Ob5Melkr3Md5iTeRnZ6S2CbeikWEMEEUxhgmRIAeBmQO0EkvXbKiTH73b/4kS5KryWywiskiSVLk8Iu6LNUTEnXREzLSrDr9/9tXS+/rzVf3BqHqybbf2qF6C743bfvz0La/j8D9CBfZYv7SAfS/i75Z1Hz7UL8OZ5dFLb4D5xvQ8mCopvorucVdug6vJ1AXg6Zr8Mzle1bY5/geomvyVVewuwcdcr5+/gejEmgBy3n7uAAAAGRJREFUGJWVkDEOgCAMRZ+Eu5iQeBtu6MpRnNkYuUZhULQwKP7lN+n7bVOY1HJ5+eJsq8q+AiA5ARCDALAdpxsdk5yIQYhBcL5rPWCDmka4j73oBscJzptug9UpDWsIfrxn9kQqJZUnE6phAjUAAAAASUVORK5CYII="
  },
  22027: OO => {
    OO.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAAXNSR0IArs4c6QAAAGtJREFUGJVjYKAC+A/FDAwMDAxMuBR9fr6D4esduAasCv9/fr6D4cX7yyiC6Ar/f36+g4GBgYFBQlAXp0K4InTTGBgYGBjRrYOZxPTVg4FbBUUNROHXO6iYgYHhv3eYEHafImMXfz6siggCADC+M1RlDaxOAAAAAElFTkSuQmCC"
  },
  23532: OO => {
    OO.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAAXNSR0IArs4c6QAAAE9JREFUGJVjYCASMKLx/+OSR1b4/z9PMqqqL3OxGcbwHxl3MXj9/8+T/B+LLQgNNVHm/6E24FT4f2qRG9xUXAqRFTHgUoiuCNnNWD1COQAAFWcvZJ927BwAAAAASUVORK5CYII="
  },
  25141: OO => {
    OO.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAAXNSR0IArs4c6QAAAH1JREFUGJVjYKAC+A/FDAwMDAxMuBSdyDdkWLzBGKYBq8L/J+wNGR4se4IiiK7w/wl7QwYGBgYGBS0ZnArhih5cQzUNWeH/E/mGcAUKWjIMtwuZGGIDzjIwMDAwwgkGBob/UIfDQWzAWQbvMCHGraveYXoCGbv482HxJxEAAJssJtLET2YfAAAAAElFTkSuQmCC"
  },
  25158: OO => {
    OO.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAAXNSR0IArs4c6QAAAItJREFUGJVjYKAA/Ifh3nJb/Arv7E79X+Mp+p+BgeH/1EYX7Ir299n8v7M79f/+PhuYyQwMDAwMTOgqZXU1GR5fvs4gq6vJcGd3KswpDCzoCmGKHl++zrB3901UybBACwYGBob/NZ6icLfBMFSOgRHJbQwMDAwMjkVHGMICLRiRDVq1/gTCE+gmkA0A4Aw5D/wQUU0AAAAASUVORK5CYII="
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);