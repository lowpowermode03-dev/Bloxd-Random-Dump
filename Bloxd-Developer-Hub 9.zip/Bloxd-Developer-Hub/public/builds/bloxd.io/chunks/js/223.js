export const id = 223;
export const ids = [223, 227];
export const modules = {
  37456: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      f: () => lO
    });
    var XO = pO(26);
    let bK = !1;

    function eO() {
      return bK
    }

    function lO(OO) {
      bK !== OO && (bK = OO, XO.i.pl("replayViewer|videoExportChanged"))
    }
  },
  37345: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(26),
      bK = pO(1569);

    function eO(OO) {
      let {
        taskId: KO,
        progress: pO
      } = OO;
      const XO = bK.c.get("_tasks");
      null !== XO && void 0 !== XO && XO[KO] && bK.c.apply({
        _tasks: {
          ...XO,
          [KO]: {
            ...XO[KO],
            progress: pO
          }
        }
      })
    }
    XO.i.subscribe("clientTaskProgress", (OO => {
      eO(OO)
    }))
  },
  37340: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => sK,
      d: () => PK,
      e: () => mp
    });
    var XO = pO(2931),
      bK = pO(171),
      eO = pO(536),
      lO = pO(36),
      vK = pO(2231),
      CO = pO(3006),
      hO = pO(2988),
      DO = pO(1077);
    const MO = new WeakMap;
    class aK {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
          rQO: !0
        };
        this.callbacks = KO, this.options = pO, this.VhO = void 0, this.sessionId = void 0, this.pY = [], this.PLO = !1, this.YX = !1, this.mQO = void 0, this.mY = 0, this.vaO = 0, this.sLO = (OO, KO) => {
          if (this.YX) return;
          const pO = Number(OO);
          this.PLO ? this.HLO(pO, KO) : this.pY.push({
            id: pO,
            payload: KO
          })
        }, this.dispose = () => {
          this.YX || (this.YX = !0, MO.delete(this), this.pY.length = 0, this.mQO())
        }, this.VhO = OO, this.sessionId = OO.sessionId, MO.set(this, []), this.mQO = this.RLO()
      }
      SLO(OO) {
        this.mQO(), this.VhO = OO, this.sessionId = OO.sessionId, this.mY = 0, this.vaO = 0, this.mQO = this.RLO()
      }
      get ZE() {
        return this.vaO
      }
      RLO() {
        const OO = this.VhO.YV("*", this.sLO);
        return this.options.rQO && this.VhO.wV(this.dispose), OO
      }
      HLO(OO, KO) {
        try {
          (0, CO.ic)(OO) && (KO = (0, CO.e)(OO, hO.jb.from(KO)));
          const pO = MO.get(this)[OO];
          if ("function" !== typeof pO) {
            if (this.callbacks.JLO) return void this.callbacks.JLO(OO, KO);
            throw new Error(`No onMessage handler registered for message id ${OO}`)
          }
          pO(KO)
        } catch (pO) {
          this.callbacks.cQO(`Error in onMessage ${OO} with payload ${JSON.stringify(KO)}`, pO)
        } finally {
          this.mY++
        }
      }
      BLO() {
        for (const {
            id: OO,
            payload: KO
          }
          of this.pY) {
          if (this.YX) break;
          this.HLO(OO, KO)
        }
        this.pY.length = 0
      }
      FhO() {
        return this.YX
      }
      ZLO() {
        if (this.PLO || this.YX) throw new Error("Trying to getOnMessageRegistrationHandler after registration finished");
        return {
          YV: (OO, KO) => {
            if (this.PLO || this.YX) throw new Error("Trying to call onMessage after registration finished");
            this.YV(OO, KO)
          },
          finishRegistration: () => {
            if (this.YX) throw new Error("Cannot finish message registration after disposal");
            this.PLO = !0, this.BLO()
          }
        }
      }
      YV(OO, KO) {
        var pO, XO;
        null === (pO = (XO = this.callbacks).GLO) || void 0 === pO || pO.call(XO);
        const bK = MO.get(this);
        for (; OO > bK.length;) bK[bK.length] = null;
        bK[OO] = KO
      }
      send(OO, KO) {
        this.qQO(), (0, DO.A)(KO) ? this.VhO.wY(OO, KO) : this.VhO.send(OO, KO)
      }
      qQO() {
        var OO, KO;
        (this.vaO++, 5 === oO++) && (null === (OO = (KO = this.callbacks).GLO) || void 0 === OO || OO.call(KO), oO = 0)
      }
      BC() {
        this.dispose(), this.VhO.BC()
      }
      DX() {
        this.dispose(), this.VhO.DX()
      }
    }
    let oO = 0;
    var FO = pO(2945);
    class VO extends aK {
      constructor(OO) {
        super(OO, {
          GLO: () => {
            (0, lO.l)(!0) && (0, XO.QE)()
          },
          cQO: (OO, KO) => {
            var pO;
            null === (pO = (0, vK.d)()) || void 0 === pO || pO.ce(OO, KO)
          }
        }, {
          rQO: !1
        }), (0, FO.g)(OO)
      }
      VY(OO, KO) {
        return !!(0, FO.l)((0, FO.c)(), this.VhO, OO, KO) && (this.qQO(), !0)
      }
      SLO(OO) {
        this.xQO(), super.SLO(OO), (0, FO.g)(OO)
      }
      BC() {
        super.BC(), this.xQO()
      }
      xQO() {
        this.VhO.ZC.be.mpO = void 0
      }
    }
    var LO = pO(26),
      QO = pO(1569),
      zK = pO(1481),
      AO = pO(35011);

    function fO(OO, KO, pO, XO, bK) {
      let eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
      if (!OO.tL.FCO(OO.CpO)) return console.log("Got resync inven but don't have inven component"), void KO.acknowledge(XO);
      eO && console.error("Had to sync inven"), KO.ivO(XO, bK) && pO.pl("chestToggleFromServer", !1, !0), pO.pl("syncedInvenFromServer")
    }
    var dO = pO(37345),
      TO = pO(37353),
      NO = pO(36419),
      IO = pO(36173),
      yK = pO(533),
      gK = pO(36801);

    function uO(OO, KO, pO) {
      const XO = function(OO) {
          const KO = new Int32Array(OO.length * gK.g);
          return OO.forEach(((OO, pO) => {
            const XO = pO * gK.g;
            if (4 === OO.length) {
              const [pO, bK, eO, lO] = OO;
              KO.set([pO, bK, eO, pO, bK, eO, lO], XO)
            } else {
              const [pO, bK, eO, lO, vK, CO, hO] = OO;
              KO.set([pO, eO, vK, bK, lO, CO, hO], XO)
            }
          })), KO
        }(pO),
        bK = (KO, pO, XO, bK) => {
          OO.setBlockNoMulti(KO, pO, XO, bK, !0)
        };
      OO.client.gameRecorder.isCapturing() ? (0, gK.ub)(XO, (0, gK.tb)(XO), bK) : OO.ap.lK.FXO(XO, {
        zbO: bK,
        isHookId: KO => OO.blockChangeHasHooks(KO),
        watched: () => function(OO, KO, pO) {
          const XO = [],
            bK = (OO, KO, pO) => {
              XO.push(OO, KO, pO)
            },
            eO = new Set;
          for (let lO = 0; lO < pO.length; lO += gK.g)
            for (let KO = (0, yK.P)(pO[lO]); KO <= (0, yK.P)(pO[lO + 3]); KO++)
              for (let XO = (0, yK.P)(pO[lO + 1]); XO <= (0, yK.P)(pO[lO + 4]); XO++)
                for (let vK = (0, yK.P)(pO[lO + 2]); vK <= (0, yK.P)(pO[lO + 5]); vK++) {
                  const pO = `${KO}|${XO}|${vK}`;
                  eO.has(pO) || (eO.add(pO), OO.blockDataOwner.forEachDataCell(KO, XO, vK, bK))
                }
          return KO.forEachCell(bK), Int32Array.from(XO)
        }(OO, KO, XO)
      }), OO.ap.fvO()
    }
    var EO = pO(35955),
      jK = pO(37356),
      YO = pO(37359),
      wO = pO(886),
      iK = pO(1575);
    var rK = pO(3701);

    function PO(OO) {
      const KO = OO.lK;
      let pO = 0,
        eO = -1,
        lO = -1 / 0,
        vK = null,
        hO = !0;
      const DO = () => {
        if (++pO % 10 !== 0) return;
        const DO = (0, XO.getLastReceivedPacketId)();
        if (DO <= eO) return;
        const [MO, aK, oO] = OO.tL.fV(OO.CpO), FO = ! function(OO) {
          var KO;
          let pO = null === (KO = OO.tL.thO(OO.CpO)) || void 0 === KO ? void 0 : KO.dX;
          if (void 0 === pO) return !1;
          const XO = new Set;
          for (; void 0 !== pO && !XO.has(pO);) {
            var bK;
            XO.add(pO);
            const KO = OO.tL.getState(pO, "smoothToServerPos"),
              eO = Array.isArray(KO) ? null : null === KO || void 0 === KO ? void 0 : KO.serverPosition;
            if (eO) {
              const KO = OO.tL.fV(pO);
              if (Math.abs(KO[0] - eO[0]) > 10 || Math.abs(KO[1] - eO[1]) > 10 || Math.abs(KO[2] - eO[2]) > 10) return !0
            }
            pO = null === (bK = OO.tL.thO(pO)) || void 0 === bK ? void 0 : bK.dX
          }
          return !1
        }(OO) && function(OO, KO, pO, XO) {
          const eO = bK.h.SX;
          for (let bK = 0; bK < OO.length; bK++) {
            const lO = OO[bK];
            if (!(0, rK.f)(KO, pO, XO, lO[0] * eO, lO[1] * eO, lO[2] * eO)) return !1
          }
          return !0
        }(KO.Ae.wX, MO, aK, oO), VO = null === vK || Math.abs(MO - vK[0]) > 8 || Math.abs(aK - vK[1]) > 8 || Math.abs(oO - vK[2]) > 8, LO = !hO || VO || performance.now() - lO >= 1e4;
        hO = FO, FO && LO && (eO = DO, lO = performance.now(), vK = [MO, aK, oO], (0, XO.sendColyMessage)(CO.eg, {
          XB: DO
        }))
      };
      return OO.on("KK", DO), () => {
        OO.off("KK", DO)
      }
    }
    var mK = pO(35273),
      sO = pO(266),
      HO = pO.n(sO),
      RO = pO(5628),
      SO = pO(36438),
      JO = pO(36155),
      cK = pO(36136),
      BO = pO(3710),
      ZO = pO(36516),
      GO = pO(36283),
      qK = pO(35743),
      xK = pO(36048),
      nO = pO(37365),
      WO = pO(35259),
      tK = pO(35264),
      kK = pO(37373),
      UO = pO(37378),
      OK = pO(2905),
      KK = pO(1344),
      pK = pO(2224),
      XK = pO(2302),
      bp = pO(36652),
      eK = pO(35534),
      lK = pO(3916),
      vp = pO(37419),
      CK = pO(36507),
      hK = pO(3500),
      DK = pO(35959),
      MK = pO(35599),
      ap = pO(36521),
      oK = pO(37382),
      FK = pO(37393),
      VK = pO(35741);
    class LK {
      constructor(OO, KO, pO, XO) {
        this.gameNameWithVariation = OO, this.ap = pO, this.connectionResume = XO, this.stateReplicationHandler = void 0, this.stopChunkReports = () => {}, this.replayResume = null, this.stateReplicationHandler = new FK.b(KO, this.ap)
      }
      setupStateReplicationHandlers() {
        this.stateReplicationHandler.setup(), (0, XO.onGameResetOnce)((() => {
          this.stateReplicationHandler.dispose()
        }))
      }
      SLO(OO) {
        this.stateReplicationHandler.dispose(), this.stateReplicationHandler = new FK.b(OO, this.ap), this.stateReplicationHandler.setup()
      }
      clearBlockRules() {
        const OO = this.ap.lK;
        OO.ehO = new Set, OO.ChO = new Set, OO.lhO = new Set, OO.hhO = new Set, OO.vDO = [], OO.DhO = [], OO.kXO = new Set, OO.g6 = [], OO.UpO = []
      }
      clearUiRequestsAndQTEs() {
        lK.e.reset(), (0, TO.d)()
      }
      startChunkReports() {
        const OO = function(OO) {
            let KO = null,
              pO = -1 / 0,
              bK = null;
            const eO = () => {
                bK = null;
                const eO = Math.ceil(OO.zpO[0]),
                  lO = Math.ceil(OO.zpO[1]);
                KO && KO[0] === eO && KO[1] === lO || (KO = [eO, lO], pO = performance.now(), (0, XO.sendColyMessage)(CO.ag, {
                  wq: eO,
                  Rq: lO
                }))
              },
              lO = () => {
                null === bK && (bK = setTimeout(eO, Math.max(0, pO + 250 - performance.now())))
              };
            return eO(), OO.on("addRemoveDistanceChanged", lO), () => {
              OO.off("addRemoveDistanceChanged", lO), null !== bK && (clearTimeout(bK), bK = null)
            }
          }(this.ap.lK),
          KO = PO(this.ap);
        this.stopChunkReports = () => {
          OO(), KO()
        }
      }
      restartChunkStreaming() {
        (0, xK.m)(this.ap, (0, vK.b)().recentChunkEdits.chunksEditedSince(this.connectionResume.getDroppedAt() - nO.e)), this.startChunkReports()
      }
      setupOnMessageListeners(OO, KO) {
        const pO = this.ap,
          bK = this.gameNameWithVariation;
        OO.YV(CO.qc, (OO => {
          let {
            n_: KO,
            U_: XO,
            K3: bK,
            X3: eO,
            o3: lO,
            A3: vK,
            I3: CO,
            B3: hO,
            U3: DO
          } = OO;
          if (!pO.tL.gCO(KO, "itemState")) return void(0, JO.q)(pO, KO, [lO, vK, CO], XO, {
            amount: bK,
            attributes: JSON.parse(eO),
            B3: hO,
            size: DO
          });
          const MO = pO.tL.getState(KO, "itemState");
          MO.amount = bK, MO.B3 = hO, MO.creationTime = Date.now(), (0, cK.setServerPosition)(pO.tL.getState(KO, "smoothToServerPos"), lO, vK, CO)
        })), OO.YV(CO.kb, (OO => {
          (0, EO.e)(pO).setCantPickUp(OO, !0), pO.tL.gCO(OO, "itemState") && (pO.tL.getState(OO, "itemState").B3 = !0)
        })), OO.YV(CO.Kd, (OO => {
          (0, EO.e)(pO).setCantPickUp(OO, !1), pO.tL.gCO(OO, "itemState") && (pO.tL.getState(OO, "itemState").B3 = !1)
        })), OO.YV(CO.Hc, (OO => {
          QO.c.applyNewClientOptions(OO)
        })), OO.YV(CO.Kc, (OO => {
          let {
            eId: KO,
            settings: XO
          } = OO;
          (0, MK.h)(KO);
          for (const pO in XO)(0, MK.e)(KO, pO, XO[pO]);
          if ("canSee" in XO && pO.tL.gCO(KO, "hidingMeshManager")) {
            const OO = pO.tL.getState(KO, "hidingMeshManager");
            OO.canSee = (0, ap.b)("canSee", XO.canSee), OO._forceUpdate = !0
          }
        })), OO.YV(CO.Te, (OO => {
          let {
            U1: KO,
            o5: bK,
            I5: eO,
            Y5: lO
          } = OO;
          const vK = [bK, eO, lO];
          pO.tL.setPosition(pO.CpO, vK), (0, XO.sendColyMessage)(CO.Dg, {
            ZH: KO,
            xR: BO.e
          }), LO.i.pl("localPlayerTeleported", {
            pos: vK,
            isCorrection: !1
          })
        })), OO.YV(CO.Xc, (OO => {
          let {
            W9: KO,
            tOO: pO,
            kOO: XO,
            KOO: bK
          } = OO;
          this.stateReplicationHandler.setUpIfQueued(KO);
          const eO = [pO, XO, bK];
          LO.i.pl(`otherPlayerTeleported|${KO}`, {
            pos: eO
          })
        })), OO.YV(CO.md, (OO => {
          let {
            Hk: KO,
            Rk: bK,
            Zk: eO,
            Wk: lO,
            kU: vK,
            KU: hO,
            pU: DO,
            dU: MO,
            hU: aK,
            WU: oO
          } = OO;
          const FO = [bK, eO, lO];
          pO.tL.setPosition(pO.CpO, FO);
          const VO = pO.tL.qCO(pO.CpO),
            QO = pO.tL.XXO(pO.CpO);
          HO().set(QO.cXO, 0, 0, 0), HO().set(QO.BpO, 0, 0, 0), HO().set(QO.ul, vK, hO, DO), QO.ZpO(), VO._flying = null !== oO, oO ? (VO.flyAccel.K8 = oO.K8, VO.flyAccel.Q8 = oO.Q8) : VO.flyAccel.reset(), MO && VO.movementType === RO.o.GLIDING && (VO.IU = MO.IU, HO().copy(VO.PU, MO.PU)), (0, XO.sendColyMessage)(CO.Dg, {
            ZH: KO,
            xR: BO.e
          }), LO.i.pl("localPlayerTeleported", {
            pos: FO,
            isCorrection: !0
          })
        }));

        function eO() {
          return pO.tL.VCO(pO.CpO)
        }
        OO.YV(CO.vb, (OO => {
          let {
            chatMsgId: KO,
            content: pO,
            chatterEId: XO
          } = OO;
          LO.i.pl("chat", {
            serverChatMsgId: KO,
            content: pO,
            chatterEId: XO
          }, !0)
        })), OO.YV(CO.bd, (OO => {
          pK.b.onReceiveColyseusPing(OO)
        })), OO.YV(CO.ue, (OO => {
          let {
            key: KO,
            value: pO
          } = OO;
          (0, zK.setCookie)(bK, KO, pO)
        })), OO.YV(CO.ze, (OO => {
          LO.i.pl("setDiscordReportKey", OO)
        })), (0, XO.onGameResetOnce)((() => {
          this.stopChunkReports()
        })), OO.YV(CO.kc, (KO => {
          const {
            kKO: bK,
            UOO: eO
          } = KO;
          if ((0, XO.setAdjustment)(eO), this.connectionResume.onInitialInfo(KO.OKO, KO.kv), XO.offlineInputReplay.WE(KO.KKO), this.connectionResume.isResuming()) {
            console.log("Resumed the connection as eId", bK);
            try {
              null === KO.pKO && (0, vK.b)().client.inventoryPrediction.dropPending(), this.stopChunkReports(), this.clearBlockRules(), QO.c.apply({
                shopInfo: null,
                _shopVersion: iK.e
              });
              const XO = pO.tL.LCO(pO.CpO);
              XO.qKO && (XO.chestClosed(), LO.i.pl("chestToggleFromServer", !1, !0)), this.clearUiRequestsAndQTEs(), LO.i.pl("initInfoReceived", OO)
            } finally {
              const OO = null === KO.pKO ? null : {
                sync: null,
                endSeq: null
              };
              this.replayResume = OO, this.connectionResume.onResumeInitialInfo(KO.pKO, (() => {
                OO.endSeq = (0, vK.b)().client.inventoryPrediction.lastActionSeq
              })), null === OO && this.restartChunkStreaming()
            }
          } else console.log("Local client is eId", bK), LO.i.pl("loadingScreenState", "loadingPage:loadingWorld"), pO.jCO = bK, pO.tL.gCO(pO.CpO, pO.tL.names.entityName) && pO.tL.OpO(pO.CpO, pO.tL.names.entityName), (0, vK.b)().setEntityName(pO.jCO, (0, vK.b)().getRawEntityName(pO.CpO)), pO.vXO[pO.jCO] = {}, pO.tL.UKO(pO.CpO, pO.tL.names.entityName), LO.i.pl("initInfoReceived", OO), this.startChunkReports(), lO.client.onServerConnectionFinalised()
        })), OO.YV(CO.de, (() => {
          this.connectionResume.isResuming() ? this.connectionResume.onResumed((() => {
            const OO = this.replayResume;
            if (this.replayResume = null, !OO) return;
            this.restartChunkStreaming();
            const {
              inventoryPrediction: KO
            } = (0, vK.b)().client, {
              sync: bK
            } = OO, eO = new Set(XO.offlineInputReplay.takeDroppedActions());
            if (bK) {
              var lO;
              const XO = null !== (lO = OO.endSeq) && void 0 !== lO ? lO : KO.lastActionSeq;
              KO.forget((OO => OO > bK.Jm && OO <= XO || eO.has(OO))), fO(pO, KO, LO.i, bK.Jm, bK.load)
            } else KO.dropPending(), KO.askForSnapshot()
          })) : console.warn("ResumeComplete arrived without a resume")
        })), OO.YV(CO.Xe, (OO => {
          LO.i.pl("TopRightHelper", OO, !0)
        })), OO.YV(CO.qd, (OO => {
          let {
            type: KO,
            location1: pO,
            location2: XO,
            location3: bK,
            score: eO
          } = OO;
          (0, XK.u)({
            type: KO,
            location1: pO,
            location2: XO,
            location3: bK,
            score: eO
          })
        })), OO.YV(CO.ae, (OO => {
          let {
            type: KO,
            resourceType: pO,
            amount: XO,
            category: bK,
            itemName: eO
          } = OO;
          (0, XK.w)({
            type: KO,
            resourceType: pO,
            amount: XO,
            category: bK,
            itemName: eO
          })
        })), OO.YV(CO.Y, (OO => {
          pO.lK.ehO.add(OO), pO.lK.ChO.delete(OO)
        })), OO.YV(CO.cb, (OO => {
          pO.lK.ChO.add(OO), pO.lK.ehO.delete(OO)
        })), OO.YV(CO.Od, (OO => {
          pO.lK.ChO.delete(OO), pO.lK.ehO.delete(OO)
        })), OO.YV(CO.ab, (OO => {
          pO.lK.lhO.add(OO), pO.lK.hhO.delete(OO)
        })), OO.YV(CO.hb, (OO => {
          pO.lK.hhO.add(OO), pO.lK.lhO.delete(OO)
        })), OO.YV(CO.Td, (OO => {
          pO.lK.hhO.delete(OO), pO.lK.lhO.delete(OO)
        })), OO.YV(CO._, (OO => {
          (0, DO.db)(OO, pO.lK.DhO), (0, DO.db)(OO, pO.lK.vDO), pO.lK.vDO.push(OO)
        })), OO.YV(CO.db, (OO => {
          (0, DO.db)(OO, pO.lK.vDO), (0, DO.db)(OO, pO.lK.DhO), pO.lK.DhO.push(OO)
        })), OO.YV(CO.Qd, (OO => {
          (0, DO.db)(OO, pO.lK.vDO), (0, DO.db)(OO, pO.lK.DhO)
        })), OO.YV(CO.lf, (OO => {
          let {
            gKO: KO,
            uOO: XO
          } = OO;
          XO ? pO.lK.kXO.delete(KO) : pO.lK.kXO.add(KO)
        })), OO.YV(CO.kf, (OO => {
          let {
            g6: KO,
            i6: XO
          } = OO;
          lO.updateWalkThroughRect(pO.CpO, KO, XO)
        })), (0, XO.onGameResetOnce)((() => {
          this.clearBlockRules()
        })), OO.YV(CO.Pe, (OO => {
          (0, dO.e)(OO)
        })), OO.YV(CO.cc, (OO => {
          NO.e.applyServerUpdate(OO)
        })), OO.YV(CO.nb, (OO => {
          lO.applyServerBlocks((() => {
            ! function(OO, KO) {
              for (const {
                  cKO: pO,
                  BOO: XO
                }
                of KO) {
                const KO = IO.e[XO];
                if (KO) {
                  const {
                    compX: XO,
                    compY: bK,
                    compZ: eO,
                    mainMultiblock: lO
                  } = KO;
                  OO.EKO(pO[0] - XO, pO[1] - bK, pO[2] - eO, lO)
                }
              }
              for (const {
                  cKO: pO,
                  BOO: XO,
                  ZOO: bK
                }
                of KO) OO.setBlockNoMulti(pO[0], pO[1], pO[2], XO, !0), OO.blockDataOwner.setBlockData(pO[0], pO[1], pO[2], null === bK ? void 0 : JSON.parse(bK)), OO.blockAdded(pO[0], pO[1], pO[2], XO)
            }(lO, OO)
          })), LO.i.pl("changeBlockFail", OO), lO.client.triggerGameCallback("onChangeBlockFail", OO), LO.i.pl("EditBoard", {
            pos: null
          }), LO.i.pl("EditCodeBlock", {
            pos: null,
            canChangePos: null
          })
        })), OO.YV(CO.ad, (OO => {
          let {
            pickUpItems: KO,
            pickUpAckSeq: pO
          } = OO;
          for (const {
              name: XO,
              amount: bK,
              attributes: lO
            }
            of KO) eO().pickUpItem({
            name: XO,
            amount: bK,
            typeObj: JO.G[XO],
            attributes: lO
          });
          (0, vK.b)().client.inventoryPrediction.serverChangeApplied(pO)
        })), OO.YV(CO.Ce, (OO => {
          let {
            index: KO,
            name: XO,
            amount: bK,
            attributes: eO,
            setSlotAckSeq: lO
          } = OO;
          const CO = pO.tL.LCO(pO.CpO);
          (KO < CO.playerInventory.numSlots || CO.qKO || CO.inCreative) && CO.setItemSlot(KO, XO, bK, eO), (0, vK.b)().client.inventoryPrediction.serverChangeApplied(lO)
        })), OO.YV(CO.Oe, (OO => {
          let {
            GOO: KO,
            tKO: XO,
            Jm: bK
          } = OO;
          const {
            inventoryPrediction: eO
          } = (0, vK.b)().client, lO = () => {
            pO.tL.LCO(pO.CpO).loadFromString(KO)
          };
          this.replayResume && (this.replayResume.sync = {
            Jm: bK,
            load: lO
          }), fO(pO, eO, LO.i, bK, lO, XO)
        })), OO.YV(CO.oc, (OO => {
          (0, vK.b)().client.inventoryPrediction.acknowledge(OO)
        })), OO.YV(CO.D, (OO => {
          let {
            Ow: KO,
            aU: pO,
            okO: XO,
            Fk: bK
          } = OO;
          (0, vK.b)().client.itemDropPrediction.onActionItemDrops(KO, pO, XO, bK)
        })), OO.YV(CO.Cb, (OO => {
          eO().clearInventory(), (0, vK.b)().client.inventoryPrediction.serverChangeApplied(OO)
        })), OO.YV(CO.xc, (OO => {
          let {
            leaveEventType: KO,
            category: pO,
            subCategory: XO,
            value: bK
          } = OO;
          (0, XK.H)({
            leaveEventType: KO,
            category: pO,
            subCategory: XO,
            value: bK
          })
        })), OO.YV(CO.Lb, (OO => {
          let {
            cat1: KO,
            cat2: pO,
            cat3: XO,
            value: bK
          } = OO;
          (0, XK.s)({
            cat1: KO,
            cat2: pO,
            cat3: XO,
            value: bK
          })
        }));
        const lO = (0, vK.b)();
        OO.YV(CO.Jb, (OO => {
          lO.applyServerBlocks((() => {
            uO(lO, NO.e, OO)
          }))
        })), OO.YV(CO.Fe, (OO => {
          LO.i.pl("setSelectedInventorySlotI", OO, !0)
        })), OO.YV(CO.uc, (OO => {
          let {
            category: KO,
            timeframe: pO,
            data: XO
          } = OO;
          LO.i.pl("leaderboardResponse", {
            category: KO,
            timeframe: pO,
            data: XO
          })
        })), OO.YV(CO.U, (OO => {
          let {
            Tk: KO,
            qX: pO
          } = OO;
          this.stateReplicationHandler.setUpIfQueued(KO), KO = (0, mK.e)(KO), (0, vK.b)().client.gameRecorder.recordBulletShot(KO, pO), LO.i.pl(`bulletShot|${KO}`, {
            bulletDirections: pO
          })
        })), OO.YV(CO.ec, (OO => {
          let {
            A7: KO,
            N7: pO
          } = OO;
          LO.i.pl("damagedByOtherPlayer", {
            A7: KO,
            direction: pO
          }, !0)
        })), OO.YV(CO.id, (OO => {
          LO.i.pl("playerKilled", OO, !0), (0, vK.b)().client.gameRecorder.recordPlayerKilled(OO.deadEId, OO.killerEId, OO.withItem, OO.killstreak)
        })), OO.YV(CO.Mb, (OO => {
          LO.i.pl("customKillfeed", OO, !0), (0, vK.b)().client.gameRecorder.recordCustomKillfeed(OO.killer, OO.victim, OO.withItem)
        })), OO.YV(CO.sd, (OO => {
          let {
            Vk: KO,
            Lk: XO
          } = OO;
          this.stateReplicationHandler.setUpIfQueued(KO);
          const bK = pO.tL.mhO(KO);
          null !== bK && void 0 !== bK && bK.isGun() && bK.reload(Date.now(), XO)
        })), OO.YV(CO.Le, (() => {
          LO.i.pl("showShopTutorial", null, !0)
        })), OO.YV(CO.pd, (OO => {
          LO.i.pl("progressBarUpdate", OO, !0)
        })), OO.YV(CO.nc, (OO => {
          LO.i.pl("middleScreenBarInitiate", {
            duration: OO.bOO,
            vOO: OO.vOO,
            horizBarRemOffset: OO.aOO
          }, !0)
        })), OO.YV(CO.Bd, (() => {
          LO.i.pl("middleScreenBarRemove", !0)
        })), OO.YV(CO.je, (OO => {
          let {
            qOO: KO,
            jsO: XO
          } = OO;
          const bK = XO ? (0, CK.g)(pO, XO) : void 0;
          LO.i.pl("sendHitmarker", {
            qOO: KO,
            screenPos: bK
          }, !0)
        })), OO.YV(CO.ye, (OO => {
          let {
            id: KO,
            position: pO,
            style: XO,
            text: bK,
            Dk: eO
          } = OO;
          LO.i.pl("setDirectionArrow", {
            id: KO,
            position: pO,
            style: XO,
            text: (0, CO.t)(bK),
            Dk: eO
          }, !0)
        })), OO.YV(CO.Ab, (OO => {
          let {
            id: KO
          } = OO;
          LO.i.pl("clearDirectionArrow", {
            id: KO
          }, !0)
        })), OO.YV(CO.G, (OO => {
          let {
            Om: KO,
            R7: XO,
            animationScript: bK,
            J7: eO,
            B7: lO,
            M6: CO,
            f6: hO
          } = OO;
          KO = (0, mK.e)(KO);
          const DO = null === bK && null !== CO ? (0, jK.e)(CO, hO) : bK;
          (0, vK.b)().client.gameRecorder.recordAnimateEntity(KO, XO, DO, eO, lO), (0, EO.e)(pO).animations.animateEntity(KO, XO, bK, eO, lO, CO, hO), null !== bK || KO === pO.CpO && XO === DK.f.Emote && (0, vK.b)().client.cameraController.endTemporaryThirdPerson()
        })), OO.YV(CO.ef, (OO => {
          let {
            B5: KO,
            K9: pO
          } = OO;
          if (lO.cbO(KO[0], KO[1], KO[2])) {
            const OO = (0, vK.b)().ZF(KO[0], KO[1], KO[2]);
            (0, vK.b)().updateMailboxContents(KO[0], KO[1], KO[2], OO, pO)
          }
        })), OO.YV(CO.wb, (OO => {
          let {
            VOO: KO,
            LOO: XO,
            QOO: bK,
            hiO: eO,
            zKO: lO,
            AOO: CO,
            fOO: hO,
            dOO: DO
          } = OO;
          const MO = pO.tL.LCO(pO.CpO);
          if (CO) {
            const {
              Rm: OO,
              Jm: KO
            } = DO;
            return (0, vK.b)().client.inventoryPrediction.ivO(KO, (() => {
              MO.chestRefreshed(XO, bK, eO, hO, OO)
            })) && LO.i.pl("chestToggleFromServer", !1, !0), void LO.i.pl("chestRefreshedFromServer")
          }(KO || MO.qKO) && (KO ? (MO.chestOpened(XO, bK, eO, lO, hO), null !== lO && (0, vK.b)().client.ironChestPasskeyCache.onChestOpened(eO, lO)) : MO.chestClosed(), LO.i.pl("chestToggleFromServer", KO, !0))
        })), OO.YV(CO.Ob, (OO => {
          let {
            craftingRecipeItemName: KO,
            recipesForItem: XO
          } = OO;
          KO ? lO.craftingManager.editRecipesForPlayer(pO.CpO, KO, XO) : lO.craftingManager.resetAllPlayerRecipes(pO.CpO), LO.i.pl("craftingRecipesEdited", {
            itemName: KO,
            recipesForItem: XO
          })
        })), OO.YV(CO.He, (OO => {
          let {
            vehicleEId: KO,
            overrides: pO
          } = OO;
          (0, vK.b)().applyRiddenVehicleSettingOverrides(KO, pO)
        })), OO.YV(CO.gf, (OO => {
          let {
            Zx: KO,
            lnO: XO,
            yb: bK
          } = OO;
          const eO = pO.tL.qCO(pO.CpO).physicsState.type === RO.p.SLEEPING && KO === RO.p.DEFAULT;
          (0, vK.b)().updatePositionAndPhysics(pO.CpO, {
            type: KO,
            tier: XO
          }, !0, bK), eO && (0, vK.b)().updateHeldVehicleStatus()
        })), OO.YV(CO.pb, (OO => {
          let {
            pose: KO,
            xOO: XO
          } = OO;
          pO.tL.oCO(pO.CpO).setPose(KO, XO)
        })), OO.YV(CO.he, (OO => {
          (0, oK.b)(OO)
        })), OO.YV(CO.hd, (OO => {
          for (const KO of OO)(0, ZO.y)(KO);
          LO.i.pl("playerCosmeticsUpdated", OO, !0)
        })), OO.YV(CO.J, (OO => {
          for (const KO of OO)(0, eK.f)(pO, KO)
        })), OO.YV(CO.zc, (OO => {
          let {
            jKO: KO,
            YOO: XO,
            iKO: bK,
            rKO: eO,
            POO: vK,
            mKO: CO,
            sOO: hO
          } = OO;
          this.stateReplicationHandler.setUpIfQueued(KO), KO = (0, mK.e)(KO);
          const DO = pO.tL.ECO(KO);
          if (DO && (DO.lastHurtTime = performance.now()), (0, SO.playRigHurt)(pO, KO, CO), LO.i.pl("lifeformHurt", {
              eId: KO,
              sOO: hO
            }), XO) {
            const OO = (0, CK.g)(pO, XO.jsO);
            LO.i.pl("yourAttackHit", {
              qOO: eO,
              screenPos: OO,
              hitSelf: KO === pO.CpO
            })
          }
          KO === pO.CpO && (lO.shakePlayerCamera(KO, vK / 40, 200), LO.i.pl("closeShopOnDamaged", null), LO.i.pl("damagedByOtherPlayer", {
            A7: null,
            direction: CO,
            POO: vK
          }, !0));
          const MO = pO.tL.fV(KO);
          if (MO && (bK || eO)) {
            const OO = [MO[0], MO[1] + 1, MO[2]];
            bK && (0, GO.l)(pO, GO.A, OO, 15), eO && (0, GO.l)(pO, GO.r, OO, 10)
          }
        })), OO.YV(CO.yc, (OO => {
          let {
            eId: KO,
            j_: XO,
            i_: bK
          } = OO;
          (0, EO.e)(pO).setHealthFrac((0, mK.e)(KO), bK), LO.i.pl("lifeformHealthChanged", {
            eId: (0, mK.e)(KO),
            j_: XO,
            i_: bK
          })
        })), OO.YV(CO.M, (OO => {
          let {
            Yk: KO,
            rU: XO
          } = OO;
          (0, vK.b)().playerAttacked(pO.CpO, KO, XO)
        })), OO.YV(CO.tc, (OO => {
          (0, vK.b)().client.leaveGameUnwanted({
            reason: OO,
            requiresRefresh: !1,
            canReconnect: !1,
            automaticallyReconnect: !1
          }), (0, KK.navigatePreserveSearch)("/")
        })), OO.YV(CO.xd, (OO => {
          let {
            nW: KO,
            UW: pO,
            zk: XO
          } = OO;
          eO().removeItemName(KO, pO), (0, vK.b)().client.inventoryPrediction.serverChangeApplied(XO)
        })), OO.YV(CO.se, (OO => {
          const {
            Fl: KO,
            xhO: XO
          } = (0, qK.e)([OO[0], OO[1], OO[2]]);
          VK.e.setLookDirection(pO, KO, XO), (0, xK.p)(KO, XO);
          const bK = pO.tL.oCO(pO.CpO);
          bK && (bK.heading = KO)
        })), OO.YV(CO.te, (OO => {
          lO.client.cameraController.setCameraZoom(OO)
        })), OO.YV(CO.Ke, (OO => {
          let {
            NOO: KO,
            yKO: XO
          } = OO;
          lO.shakePlayerCamera(pO.CpO, KO, XO)
        })), OO.YV(CO.Kb, (OO => {
          (0, OK.onCosmeticPackGranted)(OO)
        })), OO.YV(CO.me, (OO => {
          LO.i.pl("serverUpdating", Date.now() + OO, !0)
        })), OO.YV(CO.Ec, YO.d), OO.YV(CO.Sc, (OO => {
          let {
            id: KO,
            r_: pO
          } = OO;
          const {
            type: bK,
            params: eO
          } = (0, vp.c)(pO), lO = {
            ...eO
          };
          for (const XO of vp.b) XO in lO && lO[XO] && (lO[XO] = (0, CO.t)(lO[XO]));
          lK.e.queueQTE(KO, bK, lO).getResult().then((OO => {
            "boolean" === typeof OO && (0, XO.sendColyMessage)(CO._h, {
              qteId: KO,
              qteResponse: OO
            })
          }))
        })), OO.YV(CO.Fd, (OO => {
          lK.e.cancelQTE(OO)
        })), (0, XO.onGameResetOnce)((() => {
          lK.e.reset()
        })), OO.YV(CO.Tc, (OO => {
          let {
            id: KO,
            clientParameters: pO
          } = OO;
          (0, TO.e)(KO, pO)
        })), OO.YV(CO.Id, (OO => {
          (0, TO.i)(OO)
        })), OO.YV(CO.af, (OO => {
          let {
            text: KO,
            id: pO
          } = OO;
          (0, TO.m)(pO, KO, (OO => {
            (0, XO.sendColyMessage)(CO.oj, {
              lY: pO,
              hY: OO,
              FY: 5
            })
          }))
        })), OO.YV(CO.Sb, (OO => {
          let {
            Qm: KO,
            Am: pO,
            Tm: XO,
            v_: bK,
            Q0: eO,
            y_: lO
          } = OO;
          KO = (0, mK.e)(KO), (0, vK.b)().client.updateEffect(KO, pO, {
            displayName: XO,
            icon: bK,
            duration: eO,
            level: lO
          })
        })), OO.YV(CO.ud, (OO => {
          let {
            Qm: KO,
            Am: pO
          } = OO;
          KO = (0, mK.e)(KO), (0, vK.b)().client.removeEffect(KO, pO)
        })), OO.YV(CO.rc, (OO => {
          pO.tL.oCO(pO.CpO).jumpMultiplier.setMultiplierType("jumpEffectAmount", OO)
        })), OO.YV(CO.Ye, (OO => {
          LO.i.pl("ttbEffectMultiplier", OO)
        })), (0, XO.onGameResetOnce)((() => {
          pO.tL.oCO(pO.CpO).jumpMultiplier.setMultiplierType("jumpEffectAmount", 1)
        })), OO.YV(CO.Oc, (OO => {
          (0, GO.p)(pO, (0, DO.t)(OO))
        })), OO.YV(CO.Qc, (OO => {
          hK.f[OO.bKO] ? (0, GO.p)(pO, {
            ...hK.f[OO.bKO],
            pos1: OO.pos1,
            pos2: OO.pos2
          }) : console.error(`Unknown preset id: ${OO.bKO}`)
        })), OO.YV(CO.ed, (OO => {
          var KO, pO;
          let {
            o9: XO,
            soundVolume: bK,
            zOO: eO,
            N9: lO
          } = OO, {
            yOO: CO,
            gOO: hO
          } = null !== lO && void 0 !== lO ? lO : {};
          const {
            I9: DO
          } = null !== lO && void 0 !== lO ? lO : {};
          CO = null !== (KO = CO) && void 0 !== KO ? KO : void 0, hO = null !== (pO = hO) && void 0 !== pO ? pO : void 0, "string" === typeof DO && this.stateReplicationHandler.setUpIfQueued(DO), (0, vK.b)().client.gameRecorder.recordPlaySound(XO, bK, eO, lO), WO.c.play((0, tK.d)(XO), bK, DO, CO, hO).rate(eO)
        })), OO.YV(CO.qe, (OO => {
          let {
            pos: KO,
            data: pO
          } = OO;
          lO.blockDataOwner.setBlockData(KO[0], KO[1], KO[2], pO), lO.blockAdded(KO[0], KO[1], KO[2], lO.ZF(KO[0], KO[1], KO[2]))
        })), OO.YV(CO._c, (OO => {
          let {
            info: KO
          } = OO;
          LO.i.pl("overShopInfo", KO, !0)
        })), OO.YV(CO.$b, (OO => {
          let {
            pW: XO,
            DW: bK
          } = OO;
          KO.openShop(pO.CpO, XO, bK)
        })), OO.YV(CO.H, (OO => {
          pO.tL.XXO(pO.CpO).applyImpulse(OO)
        })), OO.YV(CO.Ie, (OO => {
          const KO = pO.tL.XXO(pO.CpO);
          HO().set(KO.cXO, 0, 0, 0), HO().set(KO.BpO, 0, 0, 0), HO().copy(KO.ul, OO), KO.ZpO()
        })), OO.YV(CO.Ac, (OO => {
          console.error(`[logErrorToConsole]: ${OO}`)
        })), OO.YV(CO.Yb, (OO => {
          let {
            HOO: KO,
            ROO: pO,
            SOO: XO
          } = OO;
          LO.i.pl("flyingMiddleMessage", {
            content: (0, CO.t)(KO),
            ROO: pO,
            SOO: XO
          }, !0)
        })), OO.YV(CO.nf, (OO => {
          const KO = OO === wO.f ? null : {
            message: `Currently loaded as variation: ${OO}`,
            type: "Warning"
          };
          LO.i.pl("showPermanentBottomMessage", KO, !0)
        })), OO.YV(CO.ac, (OO => {
          let {
            messageType: KO,
            data: pO
          } = OO;
          (0, kK.i)(KO) ? (0, kK.e)(KO, pO) : ("freeCamPerms" === KO && lO.client.freeCameraController.setPerms(pO.key, pO.value), lO.client.triggerGameCallback("onReceivedMessageFromServer", KO, pO))
        })), OO.YV(CO.rb, (() => {
          const OO = pO.tL.mhO(pO.CpO);
          null !== OO && void 0 !== OO && OO.isChargeable() && OO.finishCharging(!1, Date.now())
        })), OO.YV(CO.vd, (OO => {
          let {
            P5: KO
          } = OO;
          lO.craftingManager.removeRecipes(pO.CpO, KO), LO.i.pl("craftingRecipesEdited", {
            itemName: KO,
            recipesForItem: []
          })
        })), OO.YV(CO.ff, (OO => {
          for (const KO in OO) {
            const pO = OO[KO];
            for (const OO in pO) lO.client.meshCreator.handleParticleSystemUpdate(KO, OO, pO[OO])
          }
        })), (0, XO.onGameResetOnce)((() => {
          (0, bp.setFloatingYValue)(pO.tL.getState(pO.CpO, "physics"), pO.tL.beO(pO.CpO), null)
        })), OO.YV(CO.Vb, (OO => {
          let {
            E8: KO,
            W8: XO,
            b_: bK
          } = OO;
          const eO = (0, mK.e)(KO);
          if (eO === pO.CpO) {
            const OO = pO.tL.beO(pO.CpO).position;
            bK ??= Math.floor(OO[1]) - 1, (0, bp.setFloatingYValue)(pO.tL.getState(pO.CpO, "physics"), pO.tL.beO(pO.CpO), XO ? bK : null)
          }(0, EO.e)(pO).setFloating(eO, XO, bK);
          const lO = pO.tL.getState(eO, "floating");
          lO && (lO.isFloating = XO, lO.b_ = XO ? bK : null)
        })), OO.YV(CO.Fb, UO.g)
      }
    }
    window.addEventListener("beforeunload", (() => {}));
    var QK = pO(37427),
      zp = pO(37435),
      AK = pO(959),
      fK = pO(2516);
    class dK {
      constructor(OO, KO, pO, XO) {
        this.msgHandler = pO, this.listener = XO, this.session = void 0, this.attachedRoom = null, this.detachRoomListeners = null, this.suspended = !1, this.droppedAt = 0, this.session = new QK.e({
          reconnect: OO,
          isLive: () => XO.isLive(),
          onReconnected: OO => {
            this.resumeOnRoom(OO)
          },
          onGaveUp: (OO, KO) => {
            XO.onGaveUp(OO, KO)
          },
          freeze: KO,
          releaseSeat: KO => {
            OO(KO).then((OO => {
              OO.DX(!0)
            }), (OO => {
              console.warn("Couldn't release the held seat of a game left while reconnecting", OO)
            }))
          }
        })
      }
      onInitialInfo(OO, KO) {
        this.session.onInitialInfo(OO, KO)
      }
      isResuming() {
        return this.session.isResuming()
      }
      getDroppedAt() {
        return this.droppedAt
      }
      onResumeInitialInfo(OO, KO) {
        if (this.session.onResuming(), null === OO) {
          try {
            (0, vK.b)().client.itemDropPrediction.reset()
          } catch (pO) {
            console.error("Error dropping the item drop predictions on resuming", pO)
          }
          return XO.offlineInputReplay.discard(), void this.setSuspended(!1)
        }(0, vK.b)().client.itemDropPrediction.onResumeReplayOffered(), XO.offlineInputReplay.replayFrom(OO.bpO, KO)
      }
      onResumed(OO) {
        this.setSuspended(!1), (0, XO.resendBeacons)();
        try {
          OO()
        } catch (KO) {
          console.error("Error completing the resume", KO)
        } finally {
          this.session.onResumed()
        }
      }
      attachRoom(OO) {
        const KO = (0, AK.c)((() => OO.connection.isOpen));
        OO.wV(KO);
        const pO = new zp.c((() => {
          this.session.canHoldSeat() && this.listener.isLive() && (console.warn("The game server went silent, reconnecting"), this.onConnectionDropped(OO, "silent"), OO.DX(!1))
        }));
        OO.onStateChange((() => {
          pO.heard()
        }));
        const XO = KO => {
          KO.persisted || OO.DX(!0)
        };
        window.addEventListener("pagehide", XO), OO.wV(((KO, pO) => {
          if (OO === this.attachedRoom && this.listener.isLive()) return (0, bK.j)(KO) && this.session.canHoldSeat() ? (console.warn(`Connection to the game server dropped with code ${KO}, reconnecting`), this.listener.onDropped(KO, pO), void this.onConnectionDropped(OO, String(KO))) : void this.listener.onRoomLeft(KO, pO)
        })), this.attachedRoom = OO, this.detachRoomListeners = () => {
          KO(), pO.dispose(), window.removeEventListener("pagehide", XO)
        }
      }
      dispose() {
        this.detachRoom(), this.session.DX(), this.setSuspended(!1)
      }
      setSuspended(OO) {
        OO !== this.suspended && (this.suspended = OO, (0, XO.setConnectionSuspended)(OO), (0, vK.b)().client.itemDropPrediction.setSuspended(OO))
      }
      detachRoom() {
        var OO;
        null === (OO = this.detachRoomListeners) || void 0 === OO || OO.call(this), this.detachRoomListeners = null, this.attachedRoom = null
      }
      onConnectionDropped(OO, KO) {
        (0, fK.i)("disconnect", "Left room", KO), this.isResuming() || (this.droppedAt = Date.now()), this.detachRoom(), XO.offlineInputReplay.onConnectionLost(), this.setSuspended(!0), this.session.onConnectionLost(OO.reconnectionToken)
      }
      resumeOnRoom(OO) {
        if (!this.listener.isLive()) return console.warn("Left the game while reconnecting, leaving the resumed room"), OO.DX(!0), void this.dispose();
        console.log("Reconnected to the game server, waiting for the game to resume"), (0, oK.p)(), XO.offlineInputReplay.onConnectionReplaced(), this.msgHandler.SLO(OO), this.listener.onReconnected(OO), this.attachRoom(OO)
      }
    }
    var TK = pO(2716),
      NK = pO(2718),
      IK = pO(1163),
      yp = pO(3846),
      gp = pO(2446),
      uK = pO(951),
      EK = pO(36074),
      jp = pO(37444),
      YK = pO(37450),
      wK = pO(5632);

    function ip(OO) {
      var KO, pO;
      if ("object" !== typeof OO || null === OO) return {
        errType: typeof OO
      };
      const XO = OO;
      return {
        errType: null !== (KO = null === (pO = OO.constructor) || void 0 === pO ? void 0 : pO.name) && void 0 !== KO ? KO : "",
        errName: "string" === typeof XO.name ? XO.name : "",
        eventType: "string" === typeof XO.type ? XO.type : "",
        errStack: "string" === typeof XO.stack ? XO.stack.split("\n").slice(1).join(" | ") : ""
      }
    }

    function rp(OO) {
      if ("undefined" !== typeof ProgressEvent && OO instanceof ProgressEvent) return !0;
      if (!(OO instanceof Error)) return !1;
      const KO = OO.code;
      return "ServerError" === OO.name && void 0 === KO || "AbortError" === OO.name || "seat reservation expired." === OO.message || "early_leave" === OO.message
    }(0, FO.m)((OO => {
      (0, fK.i)("wasm_net", OO)
    }));
    let PK = !0;

    function mp() {
      PK = !1
    }
    class sK {
      constructor(OO) {
        this.gameNameWithVariation = void 0, this.lobbyName = void 0, this.colyClient = void 0, this.userContext = void 0, this.joinedAt = null, this.checkSendPath = () => {}, this.ap = void 0, this.connectionResume = void 0, this.incomingMsgInitialisor = void 0, this.gameNameWithVariation = OO.gameNameWithVariation, this.lobbyName = OO.lobbyName, this.colyClient = OO.colyClient, this.userContext = OO.userContext
      }
      async connectToServer(OO, KO, pO) {
        QO.c.reset(), OO.vXO = {
          [OO.CpO]: {}
        }, OO.jCO = void 0, (0, oK.p)(), (0, vK.b)().removeAllEntityNames(), (0, vK.b)().setEntityName(OO.CpO, this.userContext.getPlayerName()), (0, IK.q)({
          lobbyName: this.lobbyName
        }), console.log("Waiting for clientConnection passed promise to resolve"), console.log("joining server with game", this.gameNameWithVariation, "lobbyName", this.lobbyName);
        const eO = performance.now(),
          lO = (0, YK.h)(this.userContext, (() => {
            const {
              roomName: OO,
              joinOptions: XO
            } = (0, AO.g)(this.userContext, this.gameNameWithVariation, this.lobbyName, KO, (OO => gp.c.isUsingCustomGameTexturePack(OO)));
            return (0, jp.c)((() => this.colyClient.joinOrCreate(OO, XO)), pO)
          }));
        return LO.i.pl("loadingScreenState", "loadingPage:joiningLobby"), await lO.then((KO => {
          this.joinedAt = performance.now(), this.ap = OO;
          const pO = new VO(KO);
          this.connectionResume = new dK((OO => this.colyClient.reconnect(OO)), (KO => {
            OO.QKO(KO)
          }), pO, {
            isLive: () => (0, vK.b)().client.getMsgHandler() === pO,
            onDropped: (OO, KO) => {
              (0, NK.j)(OO) || this.logUnrecognisedConnectionLoss(OO, void 0, {
                site: "drop",
                closeReason: null !== KO && void 0 !== KO ? KO : "",
                sinceJoined: this.sinceJoined()
              })
            },
            onRoomLeft: (OO, KO) => {
              this.onRoomLeft(OO, KO)
            },
            onReconnected: OO => {
              this.incomingMsgInitialisor.SLO(OO), this.checkSendPath = (0, EK.f)(pO, OO, FO.q)
            },
            onGaveUp: (OO, KO) => {
              this.onResumeGaveUp(OO, KO)
            }
          }), this.connectionResume.attachRoom(KO), (0, XO.onGameResetOnce)((() => {
            this.connectionResume.dispose()
          }));
          const bK = pO.send,
            eO = pO.YV,
            lO = pO.VhO.send,
            CO = pO.VhO.YV,
            hO = pO.HLO;
          this.checkSendPath = (0, EK.f)(pO, KO, FO.q);
          const DO = setInterval((() => {
            bK === pO.send && eO === pO.YV && lO === pO.VhO.send && CO === pO.VhO.YV && hO === pO.HLO || mp(), this.checkSendPath()
          }), 1e4);
          return (0, XO.onGameResetOnce)((() => {
            clearInterval(DO)
          })), {
            success: !0,
            successDetails: pO
          }
        })).catch((KO => {
          if (pO.aborted && KO === (0, wK.c)(pO)) return {
            success: !1,
            failDetails: {
              reason: "Left the game while it loaded",
              requiresRefresh: !1,
              canReconnect: !1
            }
          };
          OO.ce(`Failed to connect to bloxd room, check your internet connection. lobbyName: ${this.lobbyName}, gameNameWithVariation: ${this.gameNameWithVariation} code: ${KO.code}\n`, KO);
          const XO = KO.code;
          return XO === bK.e.serverUpdating.code ? (this.goToUpdateWaiting(), {
            success: !1,
            failDetails: {
              reason: bK.e.serverUpdating.text,
              requiresRefresh: !1,
              canReconnect: !0,
              goesToUpdateWaiting: !0
            }
          }) : {
            success: !1,
            failDetails: this.onConnectionToServerLost(XO, KO.message, {
              site: "join",
              sinceJoinStart: (0, NK.e)(performance.now() - eO),
              ...ip(KO)
            }, rp(KO))
          }
        }))
      }
      setupServerListeners(OO, KO, pO) {
        LO.i.pl("loadingScreenState", "loadingPage:loadingPlayerInfo"), this.incomingMsgInitialisor = new LK(this.gameNameWithVariation, KO.VhO, OO, this.connectionResume), this.incomingMsgInitialisor.setupStateReplicationHandlers();
        const bK = KO.ZLO();
        this.incomingMsgInitialisor.setupOnMessageListeners(bK, pO), (0, XO.onConnectionToServerReady)(bK, KO), bK.finishRegistration()
      }
      dispose() {
        this.connectionResume.dispose()
      }
      onResumeGaveUp(OO, KO) {
        (0, uK.Zb)(new Error("Reconnect failed"), {
          ...(0, TK.j)(KO),
          game: this.gameNameWithVariation
        }), (0, fK.i)("disconnect", "Reconnect failed", KO.reason), (0, vK.b)().client.leaveGameUnwanted({
          reason: {
            translationKey: "general:lostConnection"
          },
          canReconnect: !OO,
          canPlayAgain: OO,
          requiresRefresh: !1,
          automaticallyReconnect: !1
        }), (0, KK.navigatePreserveSearch)("/")
      }
      sinceJoined() {
        return null === this.joinedAt ? "" : (0, NK.e)(performance.now() - this.joinedAt)
      }
      onRoomLeft(OO, KO) {
        var pO;
        if (OO === bK.e.gameOrPluginKick.code) return;
        if (console.log(`Left room with code ${OO}`), OO === bK.e.serverUpdating.code) return (0, fK.i)("disconnect", "Left room", "serverUpdating"), (0, vK.b)().client.leaveGame(this.getUpdateWaitingUrl()), void this.goToUpdateWaiting();
        this.ap.ce(`Kicked from server with code ${OO}`, new Error);
        const XO = Object.keys(bK.e).find((KO => bK.e[KO].code === OO));
        (0, fK.i)("disconnect", "Left room", null !== XO && void 0 !== XO ? XO : String(OO));
        const eO = this.onConnectionToServerLost(OO, void 0, {
          site: "DX",
          closeReason: null !== KO && void 0 !== KO ? KO : "",
          sinceJoined: this.sinceJoined()
        });
        (0, vK.b)().client.leaveGameUnwanted({
          reason: `You have disconnected from the server.\n${eO.reason}`,
          canReconnect: eO.canReconnect,
          requiresRefresh: eO.requiresRefresh,
          automaticallyReconnect: null !== (pO = eO.automaticallyReconnect) && void 0 !== pO && pO
        }), (0, KK.navigatePreserveSearch)("/")
      }
      getUpdateWaitingUrl() {
        return (0, yp.x)(this.gameNameWithVariation, this.lobbyName)
      }
      goToUpdateWaiting() {
        (0, KK.navigatePreserveSearch)(this.getUpdateWaitingUrl())
      }
      onConnectionToServerLost(OO, KO, pO) {
        var XO;
        let lO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        if (null !== (XO = KO) && void 0 !== XO && XO.endsWith(bK.n) && (this.userContext.invalidateTrafficCode(), KO = KO.replace(bK.n, "")), OO === bK.e.outdatedVersion.code) return console.error("Outdated client with version ", eO.e, ", refreshing page"), (0, zK.reloadBloxd)(), {
          reason: "Outdated client",
          requiresRefresh: !0,
          canReconnect: !1
        };
        if (OO === bK.e.loadRecaptchaError.code) return console.error("Load recaptcha error, refreshing page"), (0, zK.reloadBloxd)(), {
          reason: "Failed to load recaptcha",
          requiresRefresh: !0,
          canReconnect: !1
        };
        for (const eO in bK.e) {
          const {
            code: pO,
            text: XO,
            canReconnect: lO
          } = bK.e[eO];
          if (pO === OO) {
            console.log("matched known error", OO, "leaving game");
            return {
              reason: "" === XO ? KO : XO,
              requiresRefresh: !1,
              canReconnect: lO,
              automaticallyReconnect: pO === bK.e.customGameUpdated.code || pO === bK.e.duplicateLobbyNameError.code
            }
          }
        }
        return console.log("Didn't match known error, leaving game"), (0, NK.g)(OO) || lO ? console.warn("Connection lost", OO, KO) : this.logUnrecognisedConnectionLoss(OO, KO, pO), {
          reason: `Either your internet isn't working or this is a bug.\nCode: ${OO}`,
          requiresRefresh: !1,
          canReconnect: !1
        }
      }
      logUnrecognisedConnectionLoss(OO, KO, pO) {
        (0, uK.Zb)(new Error("Unrecognised connection loss"), {
          code: String(OO),
          cause: null !== KO && void 0 !== KO ? KO : "",
          ...pO,
          game: this.gameNameWithVariation,
          ...(0, NK.m)()
        })
      }
    }
  },
  37393: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => qX,
      d: () => Up
    });
    var XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO, QO, zK, AO, fO, dO, TO, NO, IO, yK, gK, uO, EO, jK, YO, wO, iK, rK, PO, mK, sO, HO, RO, SO, JO, cK, BO, ZO, GO, qK, xK, nO, WO, tK, kK, UO, OK, KK, pK, XK, bp, eK, lK, vp, CK, hK, DK, MK, ap, oK, FK, VK, LK, QK, zp, AK, fK, dK, TK, NK, IK, yp, gp, uK, EK, jp, YK, wK, ip, rp, PK, mp, sK, HK, RK, SK, JK, cp, BK, ZK, GK, qp, xp, nK, WK, tp, kp = pO(26),
      UK = pO(35955),
      Op = pO(37402),
      Kp = pO(37410),
      pp = pO(8153),
      Xp = pO(524),
      bX = pO(518),
      ep = pO(35287);
    let lp = (XO = (0, pp.type)("number"), bK = (0, pp.type)("number"), eO = (0, pp.type)("number"), lO = (0, pp.type)("number"), vK = (0, pp.type)("number"), CO = (0, pp.type)("number"), hO = (0, pp.type)("string"), DO = class extends pp.Schema {
        constructor() {
          super(...arguments), (0, Op.e)(this, "id", MO, this), (0, Op.e)(this, "amount", aK, this), (0, Op.e)(this, "x", oO, this), (0, Op.e)(this, "y", FO, this), (0, Op.e)(this, "z", VO, this), (0, Op.e)(this, "size", LO, this), (0, Op.e)(this, "attributes", QO, this)
        }
      }, MO = (0, Kp.c)(DO.prototype, "id", [XO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), aK = (0, Kp.c)(DO.prototype, "amount", [bK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), oO = (0, Kp.c)(DO.prototype, "x", [eO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), FO = (0, Kp.c)(DO.prototype, "y", [lO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), VO = (0, Kp.c)(DO.prototype, "z", [vK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), LO = (0, Kp.c)(DO.prototype, "size", [CO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 1
        }
      }), QO = (0, Kp.c)(DO.prototype, "attributes", [hO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return "{}"
        }
      }), DO),
      vX = (zK = (0, pp.type)("string"), AO = (0, pp.type)("string"), fO = class extends pp.Schema {
        constructor() {
          super(...arguments), (0, Op.e)(this, "itemName", dO, this), (0, Op.e)(this, "enchantmentTier", TO, this)
        }
      }, dO = (0, Kp.c)(fO.prototype, "itemName", [zK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: null
      }), TO = (0, Kp.c)(fO.prototype, "enchantmentTier", [AO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: null
      }), fO),
      Cp = (NO = (0, pp.type)("string"), IO = (0, pp.type)("string"), yK = (0, pp.type)("number"), gK = (0, pp.type)("number"), uO = (0, pp.type)("number"), EO = (0, pp.type)("float32"), jK = (0, pp.type)("float32"), YO = (0, pp.type)("float32"), wO = (0, pp.type)("string"), iK = (0, pp.type)(["number"]), rK = (0, pp.type)("boolean"), PO = class extends pp.Schema {
        constructor() {
          super(...arguments), (0, Op.e)(this, "type", mK, this), (0, Op.e)(this, "name", sO, this), (0, Op.e)(this, "x", HO, this), (0, Op.e)(this, "y", RO, this), (0, Op.e)(this, "z", SO, this), (0, Op.e)(this, "xRotation", JO, this), (0, Op.e)(this, "yRotation", cK, this), (0, Op.e)(this, "zRotation", BO, this), (0, Op.e)(this, "followingEId", ZO, this), (0, Op.e)(this, "followingOffset", GO, this), (0, Op.e)(this, "shouldMatchFollowingEntityRotation", qK, this)
        }
      }, mK = (0, Kp.c)(PO.prototype, "type", [NO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: null
      }), sO = (0, Kp.c)(PO.prototype, "name", [IO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return ""
        }
      }), HO = (0, Kp.c)(PO.prototype, "x", [yK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), RO = (0, Kp.c)(PO.prototype, "y", [gK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), SO = (0, Kp.c)(PO.prototype, "z", [uO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), JO = (0, Kp.c)(PO.prototype, "xRotation", [EO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), cK = (0, Kp.c)(PO.prototype, "yRotation", [jK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), BO = (0, Kp.c)(PO.prototype, "zRotation", [YO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), ZO = (0, Kp.c)(PO.prototype, "followingEId", [wO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: null
      }), GO = (0, Kp.c)(PO.prototype, "followingOffset", [iK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return new pp.ArraySchema(0, 0, 0)
        }
      }), qK = (0, Kp.c)(PO.prototype, "shouldMatchFollowingEntityRotation", [rK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return !0
        }
      }), PO),
      hp = (xK = (0, pp.type)("float32"), nO = (0, pp.type)("float32"), WO = (0, pp.type)("boolean"), tK = (0, pp.type)("boolean"), kK = (0, pp.type)("float32"), UO = (0, pp.type)("boolean"), OK = (0, pp.type)("string"), KK = (0, pp.type)("string"), pK = (0, pp.type)("string"), XK = (0, pp.type)("string"), bp = (0, pp.type)(["number"]), eK = (0, pp.type)("number"), lK = (0, pp.type)({
        map: vX
      }), vp = class extends Cp {
        constructor() {
          super(...arguments), (0, Op.e)(this, "scale", CK, this), (0, Op.e)(this, "speed", hK, this), (0, Op.e)(this, "jumping", DK, this), (0, Op.e)(this, "crouching", MK, this), (0, Op.e)(this, "cameraPitch", ap, this), (0, Op.e)(this, "armSwinging", oK, this), (0, Op.e)(this, "heldItemName", FK, this), (0, Op.e)(this, "heldItemEnchantmentTier", VK, this), (0, Op.e)(this, "pose", LK, this), (0, Op.e)(this, "ridingVehicleEId", QK, this), (0, Op.e)(this, "meshOffset", zp, this), (0, Op.e)(this, "baseRenderHeading", AK, this), (0, Op.e)(this, "armour", fK, this)
        }
      }, CK = (0, Kp.c)(vp.prototype, "scale", [xK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 1
        }
      }), hK = (0, Kp.c)(vp.prototype, "speed", [nO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), DK = (0, Kp.c)(vp.prototype, "jumping", [WO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return !1
        }
      }), MK = (0, Kp.c)(vp.prototype, "crouching", [tK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return !1
        }
      }), ap = (0, Kp.c)(vp.prototype, "cameraPitch", [kK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), oK = (0, Kp.c)(vp.prototype, "armSwinging", [UO], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return !1
        }
      }), FK = (0, Kp.c)(vp.prototype, "heldItemName", [OK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: null
      }), VK = (0, Kp.c)(vp.prototype, "heldItemEnchantmentTier", [KK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: null
      }), LK = (0, Kp.c)(vp.prototype, "pose", [pK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return "standing"
        }
      }), QK = (0, Kp.c)(vp.prototype, "ridingVehicleEId", [XK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return null
        }
      }), zp = (0, Kp.c)(vp.prototype, "meshOffset", [bp], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return new pp.ArraySchema(0, 0, 0)
        }
      }), AK = (0, Kp.c)(vp.prototype, "baseRenderHeading", [eK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), fK = (0, Kp.c)(vp.prototype, "armour", [lK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return new pp.MapSchema
        }
      }), vp),
      Dp = (dK = (0, pp.type)("string"), TK = (0, pp.type)("string"), NK = (0, pp.type)("string"), IK = (0, pp.type)("uint8"), yp = class extends hp {
        constructor() {
          super(...arguments), (0, Op.e)(this, "variation", gp, this), (0, Op.e)(this, "ownerDbId", uK, this), (0, Op.e)(this, "metaInfo", EK, this), (0, Op.e)(this, "aiState", jp, this)
        }
      }, gp = (0, Kp.c)(yp.prototype, "variation", [dK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return "default"
        }
      }), uK = (0, Kp.c)(yp.prototype, "ownerDbId", [TK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return null
        }
      }), EK = (0, Kp.c)(yp.prototype, "metaInfo", [NK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return ""
        }
      }), jp = (0, Kp.c)(yp.prototype, "aiState", [IK], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function() {
          return 0
        }
      }), yp);
    YK = (0, pp.type)("string"), wK = (0, pp.type)("string"), ip = (0, pp.type)("string"), rp = (0, pp.type)("string"), PK = class extends Cp {
      constructor() {
        super(...arguments), (0, Op.e)(this, "meshKind", mp, this), (0, Op.e)(this, "meshOpts", sK, this), (0, Op.e)(this, "pose", HK, this), (0, Op.e)(this, "leaderboardTop", RK, this)
      }
    }, mp = (0, Kp.c)(PK.prototype, "meshKind", [YK], {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      initializer: null
    }), sK = (0, Kp.c)(PK.prototype, "meshOpts", [wK], {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      initializer: null
    }), HK = (0, Kp.c)(PK.prototype, "pose", [ip], {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      initializer: null
    }), RK = (0, Kp.c)(PK.prototype, "leaderboardTop", [rp], {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      initializer: null
    });

    function Mp(OO) {
      return Object.keys(pp.Metadata.getFields(OO))
    }
    const aX = Mp(Dp);
    for (const OX of Xp.p)
      if (!aX.includes(OX)) throw new Error(`Mob Schema is missing a networked property: "${OX}"`);
    const op = Mp((SK = (0, pp.type)("string"), JK = (0, pp.type)("float32"), cp = (0, pp.type)("float32"), BK = (0, pp.type)("float32"), ZK = (0, pp.type)("float32"), GK = class extends Cp {
      constructor() {
        super(...arguments), (0, Op.e)(this, "soundName", qp, this), (0, Op.e)(this, "volume", xp, this), (0, Op.e)(this, "refDistance", nK, this), (0, Op.e)(this, "maxHearDist", WK, this), (0, Op.e)(this, "rate", tp, this)
      }
    }, qp = (0, Kp.c)(GK.prototype, "soundName", [SK], {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      initializer: function() {
        return ""
      }
    }), xp = (0, Kp.c)(GK.prototype, "volume", [JK], {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      initializer: function() {
        return 1
      }
    }), nK = (0, Kp.c)(GK.prototype, "refDistance", [cp], {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      initializer: function() {
        return ep.h
      }
    }), WK = (0, Kp.c)(GK.prototype, "maxHearDist", [BK], {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      initializer: function() {
        return ep.c
      }
    }), tp = (0, Kp.c)(GK.prototype, "rate", [ZK], {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      initializer: function() {
        return 1
      }
    }), GK));
    for (const OX of bX.f)
      if (!op.includes(OX)) throw new Error(`AudioEntity Schema is missing a replicated property: "${OX}"`);
    var Fp = pO(36832),
      Vp = pO(1098),
      Lp = pO(533),
      Qp = pO(36607),
      zX = pO(3520),
      Ap = pO(256),
      fp = pO(35680),
      dp = pO(36516),
      Tp = pO(1803),
      Np = pO(35599),
      Ip = pO(36866),
      yX = pO(35730),
      gX = pO(266),
      upO = pO.n(gX),
      Ep = pO(36306),
      jX = pO(35537),
      Yp = pO(36443),
      wp = pO(36527);
    class iX {
      constructor(OO, KO) {
        this.bloxd = OO, this.eId = KO, this.ap = void 0, this.colyseusEntity = void 0, this.canSeeSub = void 0, this.canAttackSub = void 0, this.interactableSub = void 0, this.overlayColourSub = void 0, this.opacitySub = void 0, this.zIndexSub = void 0, this.multilineTextBoxSub = void 0, this.previousHidingMeshManagerState = void 0, this.meshKind = void 0, this.meshOpts = void 0, this.leaderboardTop = void 0, this.meshRebuildQueued = !1, this.YX = !1, this.ap = OO.ap
      }
      initClient(OO) {
        var KO, pO, XO;
        this.colyseusEntity = OO, this.meshKind = OO.meshKind, this.meshOpts = OO.meshOpts, this.leaderboardTop = OO.leaderboardTop, this.ap.tL.add([OO.x, OO.y, OO.z], 1, 1, null, null, !1, !1, this.eId), this.ap.tL.UKO(this.eId, "smoothToServerPos");
        const bK = "Person" === this.meshKind;
        this.ap.tL.UKO(this.eId, "meshRotation", {
          isServerControlled: !0,
          ...bK ? {
            defaultRotationsPerSecond: .5
          } : {},
          childrenNodeParams: bK ? [{
            nodeName: "HeadMesh",
            softTolerance: Ip.i,
            hardTolerance: null
          }] : []
        }), this.updateHidingMeshMgr(), this.canSeeSub = kp.i.subscribe(`otherEntitySettings|${this.eId}|canSee`, (OO => {
          this.updateHidingMeshMgr()
        }));
        const eO = () => {
          const OO = this.ap.tL.lCO(this.eId);
          if (!OO) return;
          const KO = (0, yX.j)(this.eId);
          if ("number" === typeof OO.GKO) {
            var pO, XO, bK, eO;
            const lO = null === (pO = (0, Tp.j)("head", null === (bK = this.getSpec()) || void 0 === bK || null === (eO = bK.opts.textures) || void 0 === eO ? void 0 : eO.head)) || void 0 === pO || null === (XO = pO.personModel) || void 0 === XO ? void 0 : XO.fullBody;
            return this.ap.Lb.ZKO.setPickable(OO.GKO, KO && !lO), void(0, jX.updatePersonAttachmentPickability)(this.ap, this.eId, KO)
          }
          const lO = OO.mesh;
          if (lO)
            for (const vK of [lO, ...lO.getChildMeshes(!1)]) "De" in vK && !vK.name.startsWith("Cape|") && (vK.De = KO)
        };
        this.canAttackSub = kp.i.subscribe(`otherEntitySettings|${this.eId}|canAttack`, eO), this.interactableSub = kp.i.subscribe(`otherEntitySettings|${this.eId}|interactable`, eO), this.overlayColourSub = kp.i.subscribe(`otherEntitySettingsClientifiedEId|${this.eId}|overlayColour`, (OO => {
          this.updateOverlayColour(OO)
        })), this.opacitySub = kp.i.subscribe(`otherEntitySettingsClientifiedEId|${this.eId}|opacity`, (OO => {
          this.updateOpacity(OO)
        })), this.zIndexSub = kp.i.subscribe(`otherEntitySettingsClientifiedEId|${this.eId}|zIndex`, (OO => {
          this.updateZIndex(OO)
        }));
        const lO = this.ap.vXO[this.ap.CpO][this.eId];
        this.updateOverlayColour(null !== (KO = null === lO || void 0 === lO ? void 0 : lO.overlayColour) && void 0 !== KO ? KO : null), this.updateOpacity(null !== (pO = null === lO || void 0 === lO ? void 0 : lO.opacity) && void 0 !== pO ? pO : 1), this.updateZIndex(null !== (XO = null === lO || void 0 === lO ? void 0 : lO.zIndex) && void 0 !== XO ? XO : 0), this.multilineTextBoxSub = (0, Np.w)(this.ap, this.eId)
      }
      onChangeClient(OO, KO) {
        if ("xRotation" === OO || "yRotation" === OO || "zRotation" === OO)(0, Np.A)(this.ap, this.eId, OO, KO);
        else if ("pose" === OO) {
          const OO = this.ap.tL.oCO(this.eId);
          OO && (OO.pose = KO || "standing")
        } else "meshKind" === OO || "meshOpts" === OO ? (this[OO] = KO, this.queueMeshRebuild()) : "name" === OO && "" !== KO ? this.updateHidingMeshMgr() : "leaderboardTop" === OO && (this.leaderboardTop = KO, kp.i.pl(`leaderboardTop|${this.eId}`, KO))
      }
      disposeClient() {
        this.YX = !0, this.ap.tL.deleteEntity(this.eId), kp.i.unsubscribe(this.canSeeSub), kp.i.unsubscribe(this.canAttackSub), kp.i.unsubscribe(this.interactableSub), kp.i.unsubscribe(this.overlayColourSub), kp.i.unsubscribe(this.opacitySub), kp.i.unsubscribe(this.zIndexSub), kp.i.unsubscribe(this.multilineTextBoxSub)
      }
      getCurrentHidingMeshMgrState() {
        var OO, KO;
        return {
          canSee: null !== (OO = null === (KO = this.ap.vXO[this.ap.CpO][this.eId]) || void 0 === KO ? void 0 : KO.canSee) && void 0 !== OO && OO,
          name: this.colyseusEntity.name,
          meshKind: this.meshKind,
          meshOpts: this.meshOpts
        }
      }
      updateHidingMeshMgr() {
        var OO, KO, pO;
        const {
          ap: XO
        } = this, {
          tL: bK
        } = XO, eO = this.getCurrentHidingMeshMgrState();
        if ((0, Ap.Sd)(this.previousHidingMeshManagerState, eO)) return;
        if (this.previousHidingMeshManagerState = eO, bK.OpO(this.eId, "hidingMeshManager"), null === (OO = XO.vXO[XO.CpO][this.eId]) || void 0 === OO || !OO.canSee) return;
        const lO = this.getSpec();
        if (!lO) return;
        const {
          type: vK,
          opts: CO
        } = lO;
        "Person" === vK && (CO.textures = (0, Tp.s)(CO.textures)), CO.eId = this.eId, bK.UKO(this.eId, "hidingMeshManager", {
          addMeshComponent: () => {
            var OO, KO, pO;
            "Leaderboard" === vK && (CO.leaderboardTop = this.leaderboardTop);
            const eO = this.bloxd.client.meshCreator.getEntityMesh(vK, CO, (OO => {
              var KO, pO;
              if ("number" === typeof OO) {
                var bK, eO, lO;
                const KO = XO.Lb.ZKO;
                KO.setEntityId(OO, this.eId);
                const pO = "Person" === vK && (null === (bK = (0, Tp.j)("head", null === (lO = CO.textures) || void 0 === lO ? void 0 : lO.head)) || void 0 === bK || null === (eO = bK.personModel) || void 0 === eO ? void 0 : eO.fullBody);
                return void KO.setPickable(OO, (0, yX.j)(this.eId) && !pO)
              }
              const hO = OO;
              for (const vK of [hO, ...hO.getChildMeshes(!1)]) void 0 === vK.De || vK.name.startsWith("Cape|") || (vK.De = (0, yX.j)(this.eId), vK.metadata ??= new XO.Lb.Me, vK.metadata.eId = this.eId);
              this.updateOpacity(null !== (KO = null === (pO = XO.vXO[XO.CpO][this.eId]) || void 0 === pO ? void 0 : pO.opacity) && void 0 !== KO ? KO : 1)
            }));
            if (!eO) return;
            const {
              GKO: lO,
              mesh: hO,
              meshOffset: DO,
              nameYOffset: MO,
              modelLoaded: aK
            } = eO;
            null === aK || void 0 === aK || aK.then((() => {
              var OO;
              (null === (OO = bK.lCO(this.eId)) || void 0 === OO ? void 0 : OO.mesh) === hO && (this.previousHidingMeshManagerState = null, this.updateHidingMeshMgr())
            }));
            const oO = null === lO ? null : XO.Lb.ZKO.ZhO(lO, 0);
            if (bK.UKO(this.eId, bK.names.mesh, {
                GKO: lO,
                dhO: oO,
                mesh: hO,
                pFO: !1,
                IhO: "Leaderboard" !== vK,
                offset: DO.slice(),
                VFO: "ParticleEmitter" === vK && CO.followTargetMeshOffset ? OO => {
                  var KO;
                  upO().copy(OO, DO);
                  const pO = null === (KO = bK.thO(this.eId)) || void 0 === KO ? void 0 : KO.dX,
                    XO = void 0 === pO ? null : bK.oCO(pO);
                  if (XO) {
                    var eO, lO;
                    const KO = this.bloxd.getEntityHeading(null !== (eO = XO.ridingVehicleEId) && void 0 !== eO ? eO : pO, !0),
                      bK = Math.sin(KO),
                      vK = Math.cos(KO);
                    OO[0] += XO.meshOffset[0] * vK + XO.meshOffset[2] * bK, OO[1] += XO.meshOffset[1], OO[2] += XO.meshOffset[2] * vK - XO.meshOffset[0] * bK;
                    const CO = null !== (lO = XO.ridingVehicleEId) && void 0 !== lO ? lO : null;
                    null !== CO && (0, wp.c)(this.ap, CO, OO)
                  }
                } : null
              }), "Person" === vK) {
              var FO, VO, LO, QO;
              bK.UKO(this.eId, bK.names.meshAttachments, {
                personFullBody: null !== (FO = null === (VO = (0, Tp.j)("head", null === (QO = CO.textures) || void 0 === QO ? void 0 : QO.head)) || void 0 === VO || null === (LO = VO.personModel) || void 0 === LO ? void 0 : LO.fullBody) && void 0 !== FO && FO
              });
              for (const OO of Vp.w) {
                var zK, AO, fO;
                const KO = null === (zK = CO.textures) || void 0 === zK ? void 0 : zK[OO];
                KO && null !== (AO = (0, Tp.j)(OO, KO)) && void 0 !== AO && null !== (fO = AO.attachments) && void 0 !== fO && fO.length && dp.b.Player.meshApi.updatePlayerCosmetic(this.eId, lO, OO, KO)
              }
              bK.UKO(this.eId, bK.names.moveState), bK.UKO(this.eId, "updateWalkingState", {
                GKO: lO,
                dhO: oO,
                walkingLegSwingDuration: Ip.p
              }), bK.UKO(this.eId, "humanoidMesh", {
                GKO: lO,
                dhO: oO,
                heldItemPositionParams: {},
                maxWalkingAngleOverride: null
              }), bK.UKO(this.eId, "animator", {
                GKO: lO,
                dhO: oO,
                modelLifeformType: "Player"
              }), Yp.e.hasAnimation("Person") && bK.UKO(this.eId, "rigAnimation", {
                target: "Person",
                GKO: lO
              }), bK.oCO(this.eId).pose = this.colyseusEntity.pose || "standing"
            } else if ("BloxdBlock" === vK && null !== lO) {
              bK.UKO(this.eId, "animator", {
                GKO: lO,
                dhO: oO,
                modelLifeformType: null
              });
              const OO = (0, Qp.q)(CO.blockName);
              null !== OO && bK.UKO(this.eId, "rigAnimation", {
                target: OO,
                GKO: lO
              })
            }
            bK.FFO(this.eId, "entityName", {
              name: this.colyseusEntity.name,
              nameYOffset: MO
            }), this.bloxd.setEntityName(this.eId, this.colyseusEntity.name), !0 === CO.autoRotate && (bK.OpO(this.eId, "meshRotation"), bK.UKO(this.eId, "autoRotate"));
            const {
              lineToEId: dO
            } = CO;
            (0, Lp.I)(dO) || bK.UKO(this.eId, "lineToEntity", {
              lineToEId: dO
            });
            const TO = XO.vXO[XO.CpO][this.eId];
            this.updateOverlayColour(null !== (OO = null === TO || void 0 === TO ? void 0 : TO.overlayColour) && void 0 !== OO ? OO : null), this.updateOpacity(null !== (KO = null === TO || void 0 === TO ? void 0 : TO.opacity) && void 0 !== KO ? KO : 1), this.updateZIndex(null !== (pO = null === TO || void 0 === TO ? void 0 : TO.zIndex) && void 0 !== pO ? pO : 0)
          },
          removeMeshComponent: () => {
            "Person" !== vK && "BloxdBlock" !== vK || bK.OpO(this.eId, "rigAnimation"), bK.OpO(this.eId, bK.names.mesh), bK.gCO(this.eId, bK.names.meshAttachments) && bK.OpO(this.eId, bK.names.meshAttachments), bK.OpO(this.eId, "entityName"), bK.OpO(this.eId, "autoRotate"), bK.OpO(this.eId, "lineToEntity"), "Person" === vK ? (bK.OpO(this.eId, bK.names.moveState), bK.OpO(this.eId, "updateWalkingState"), bK.OpO(this.eId, "humanoidMesh"), bK.OpO(this.eId, "animator")) : "BloxdBlock" === vK && bK.OpO(this.eId, "animator")
          },
          hideDist: null !== (KO = CO.hideDist) && void 0 !== KO ? KO : 80,
          movingHideDist: null !== (pO = CO.hideDist) && void 0 !== pO ? pO : 120,
          displayOutsideLoadedChunk: CO.hideDist > 100,
          immediatelyUpdate: !0,
          Iq: "BloxdBlock" === vK ? CO.blockName : vK
        })
      }
      queueMeshRebuild() {
        this.meshRebuildQueued || (this.meshRebuildQueued = !0, queueMicrotask((() => {
          this.meshRebuildQueued = !1, this.YX || this.updateHidingMeshMgr()
        })))
      }
      getSpec() {
        return (0, zX.f)({
          meshKind: this.meshKind,
          meshOpts: this.meshOpts
        })
      }
      updateOverlayColour(OO) {
        var KO, pO;
        if ("Person" !== this.meshKind) return;
        let XO = new fp.c(0, 0, 0, 0);
        if (null !== OO) {
          const KO = (0, Ap.S)(OO);
          XO = new fp.c(KO[0] / 255, KO[1] / 255, KO[2] / 255, .5)
        }
        const bK = null !== (KO = null === (pO = this.ap.tL.lCO(this.eId)) || void 0 === pO ? void 0 : pO.GKO) && void 0 !== KO ? KO : null;
        null !== bK && dp.b.Player.meshApi.updateMeshOverlayColour(bK, XO)
      }
      updateZIndex(OO) {
        var KO;
        if ("Person" !== this.meshKind) return;
        const pO = null === (KO = this.ap.tL.lCO(this.eId)) || void 0 === KO ? void 0 : KO.GKO;
        "number" === typeof pO && this.ap.Lb.ZKO.setRenderingGroupId(pO, OO)
      }
      updateOpacity(OO) {
        const KO = this.ap.tL.lCO(this.eId);
        KO && ("number" !== typeof KO.GKO ? KO.mesh && "ParticleEmitter" !== this.meshKind && (0, Ep.e)(KO.mesh, OO) : dp.b.Player.meshApi.updateMeshOpacity(KO.GKO, OO))
      }
    }
    var rX = pO(37396);
    class Pp {
      constructor(OO, KO) {
        this.eId = KO, this.ap = void 0, this.schema = void 0, this.ap = OO.ap
      }
      initClient(OO) {
        this.schema = OO, this.ap.tL.add([OO.x, OO.y, OO.z], .1, .1, null, null, !1, !1, this.eId), this.ap.tL.UKO(this.eId, "smoothToServerPos"), rX.e.add(this.eId, this.copyOpts())
      }
      onChangeClient(OO) {
        bX.f.includes(OO) && rX.e.update(this.eId, this.copyOpts())
      }
      disposeClient() {
        rX.e.remove(this.eId), this.ap.tL.deleteEntity(this.eId)
      }
      copyOpts() {
        const {
          soundName: OO,
          volume: KO,
          refDistance: pO,
          maxHearDist: XO,
          rate: bK
        } = this.schema;
        return {
          soundName: OO,
          volume: KO,
          refDistance: pO,
          maxHearDist: XO,
          rate: bK
        }
      }
    }
    var mX = pO(2931),
      sp = pO(35273),
      Hp = pO(5628),
      Rp = pO(36155),
      Sp = pO(2231),
      Jp = pO(36553),
      cX = pO(8116),
      Bp = pO(36881),
      Zp = pO(36136),
      Gp = pO(2516);
    class qX {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 4,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : () => performance.now();
        this.VhO = OO, this.ap = KO, this.setupBudgetMs = pO, this.now = XO, this.createStateCallbacks = void 0, this.roomStateCallbacks = void 0, this.allItems = {}, this.detachers = new Map, this.deferredSetups = new Map, this.queuedSetups = new Map, this.promotedSetups = new Set, this.setupBudgetLeftMs = void 0, this.lastRefillMs = void 0, this.roomState = void 0, this.YX = !1, this.onFrame = () => {
          this.setUpQueuedEntities(!0)
        }, this.xV = () => {
          this.setUpQueuedEntities(this.now() - this.lastRefillMs > 100)
        }, this.setUpPromoted = () => {
          for (const OO of this.promotedSetups) {
            this.promotedSetups.delete(OO);
            const KO = this.queuedSetups.get(OO);
            KO && (this.queuedSetups.delete(OO), this.timedSetup(KO, OO))
          }
        }, this.createStateCallbacks = (0, cX.getStateCallbacks)(OO), this.roomStateCallbacks = this.createStateCallbacks(OO.state), this.roomState = OO.state, this.setupBudgetLeftMs = pO, this.lastRefillMs = XO()
      }
      setup() {
        this.setupEntityHandlers(), this.setupItemHandlers(), this.VhO.onStateChange(this.setUpPromoted), this.ap.on("beforeInputs", this.onFrame), this.ap.on("KK", this.xV)
      }
      setUpQueuedEntities(OO) {
        var KO;
        if ((null === (KO = (0, Sp.b)().client.getMsgHandler()) || void 0 === KO ? void 0 : KO.VhO) !== this.VhO) return this.ap.off("beforeInputs", this.onFrame), this.ap.off("KK", this.xV), this.queuedSetups.clear(), void this.promotedSetups.clear();
        if (OO && (this.setupBudgetLeftMs = this.setupBudgetMs, this.lastRefillMs = this.now()), this.setUpPromoted(), 0 !== this.queuedSetups.size)
          for (upO().copy(xX, this.ap.tL.fV(this.ap.CpO)); this.setupBudgetLeftMs > 0;) {
            const OO = this.nearestQueued(xX);
            if (null === OO) return;
            this.setUpIfQueued(OO), this.setUpPromoted()
          }
      }
      nearestQueued(OO) {
        let KO = null,
          pO = 1 / 0;
        return this.queuedSetups.forEach(((XO, bK) => {
          const eO = function(OO, KO) {
            return (KO.x - OO[0]) ** 2 + (KO.y - OO[1]) ** 2 + (KO.z - OO[2]) ** 2
          }(OO, XO);
          (null === KO || eO < pO) && (KO = bK, pO = eO)
        })), KO
      }
      setUpOrQueue(OO, KO) {
        0 === this.queuedSetups.size && this.setupBudgetLeftMs > 0 || this.mustSetUpNow(OO, KO) ? this.timedSetup(OO, KO) : this.queuedSetups.set(KO, OO)
      }
      mustSetUpNow(OO, KO) {
        const pO = this.ap.jCO;
        if (KO === pO) return !0;
        const XO = this.roomState.entities.get(pO);
        return !(!XO || XO.ridingVehicleEId !== KO && XO.followingEId !== KO) || (np(OO.type) === Fp.b || (0, Sp.b)().getFollowingEntities(KO).length > 0)
      }
      setUpIfQueued(OO) {
        const KO = this.queuedSetups.get(OO);
        KO && (this.queuedSetups.delete(OO), this.timedSetup(KO, OO))
      }
      promoteIfQueued(OO) {
        null !== OO && this.queuedSetups.has(OO) && this.promotedSetups.add(OO)
      }
      timedSetup(OO, KO) {
        const pO = this.now();
        this.setupEntity(OO, KO), this.setupBudgetLeftMs -= this.now() - pO
      }
      setupEntityHandlers() {
        this.roomStateCallbacks.entities.qL(((OO, KO) => {
          this.ap.jCO ? this.setUpOrQueue(OO, KO) : this.deferEntitySetupUntilInitInfo(OO, KO)
        })), this.roomStateCallbacks.entities.ypO(((OO, KO) => {
          const pO = this.deferredSetups.get(KO);
          pO && (kp.i.unsubscribe(pO), this.deferredSetups.delete(KO)), this.queuedSetups.delete(KO), this.detach(KO), (0, Sp.b)().client.disposeEntity(KO)
        }))
      }
      deferEntitySetupUntilInitInfo(OO, KO) {
        const pO = kp.i.RC("initInfoReceived", (() => {
          this.deferredSetups.delete(KO), this.setUpOrQueue(OO, KO)
        }));
        this.deferredSetups.set(KO, pO), (0, mX.onGameResetOnce)((() => {
          this.deferredSetups.get(KO) === pO && (kp.i.unsubscribe(pO), this.deferredSetups.delete(KO)), (0, Sp.b)().updatePositionAndPhysics(this.ap.CpO, {
            type: Hp.p.DEFAULT,
            tier: null
          }, !0), (0, Sp.b)().takeHeldPlayerBodySize(this.ap.CpO);
          const OO = this.ap.tL.qCO(this.ap.CpO);
          OO && (OO.movementType = Hp.o.NORMAL)
        }))
      }
      setupEntity(OO, KO) {
        const pO = KO === this.ap.jCO;
        if (pO)(0, Sp.b)().client.XbO(this.ap.CpO, null, null);
        else {
          const {
            type: pO
          } = OO, XO = np(pO);
          if (void 0 === XO) return void
          function(OO, KO) {
            const pO = String(OO);
            if (Wp.has(pO)) return;
            Wp.add(pO);
            const XO = pO.length > 80 ? `${pO.slice(0,80)}...` : pO,
              bK = `No client handler for entity type ${JSON.stringify(XO)}, so entity ${KO} is not set up`;
            console.warn(bK), (0, Gp.i)("uncaught", bK, "unknown_entity_type")
          }(pO, KO);
          (0, Sp.b)().client.XbO(KO, OO, new XO((0, Sp.b)(), KO, pO))
        }
        const XO = this.createStateCallbacks(OO);
        if (pO) return this.setupMapSchemaCallbacks(KO, OO, XO, "armour"), this.setupScalarField(KO, OO, XO, "scale"), this.setupScalarField(KO, OO, XO, "ridingVehicleEId"), this.setupScalarField(KO, OO, XO, "followingEId"), this.setupScalarField(KO, OO, XO, "followingOffset"), void this.setupScalarField(KO, OO, XO, "shouldMatchFollowingEntityRotation");
        for (const bK of Mp(OO.constructor)) OO[bK] instanceof pp.MapSchema ? this.setupMapSchemaCallbacks(KO, OO, XO, bK) : this.setupScalarField(KO, OO, XO, bK)
      }
      setupMapSchemaCallbacks(OO, KO, pO, XO) {
        const bK = pO[XO],
          eO = new Map;
        bK.qL(((pO, bK) => {
          if (this.onEntityFieldChange(OO, KO, XO, {
              key: bK,
              value: pO
            }), !(pO instanceof pp.Schema)) return;
          const lO = this.createStateCallbacks(pO),
            vK = [];
          for (const eO of Mp(pO.constructor)) vK.push(this.listenForFutureChanges(lO, eO, (() => {
            this.onEntityFieldChange(OO, KO, XO, {
              key: bK,
              value: pO
            })
          })));
          eO.set(bK, (() => {
            for (const OO of vK) OO()
          }))
        })), bK.ypO(((pO, bK) => {
          var lO;
          null === (lO = eO.get(bK)) || void 0 === lO || lO(), eO.delete(bK), this.onEntityFieldChange(OO, KO, XO, {
            key: bK,
            value: null
          })
        })), this.addDetacher(OO, (() => {
          for (const OO of eO.values()) OO();
          eO.clear()
        }))
      }
      setupScalarField(OO, KO, pO, XO) {
        this.onEntityFieldChange(OO, KO, XO, KO[XO]);
        const bK = this.listenForFutureChanges(pO, XO, (pO => {
          this.onEntityFieldChange(OO, KO, XO, pO)
        }));
        this.addDetacher(OO, bK)
      }
      addDetacher(OO, KO) {
        let pO = this.detachers.get(OO);
        pO || (pO = [], this.detachers.set(OO, pO)), pO.push(KO)
      }
      detach(OO) {
        for (const pO of null !== (KO = this.detachers.get(OO)) && void 0 !== KO ? KO : []) {
          var KO;
          pO()
        }
        this.detachers.delete(OO)
      }
      listenForFutureChanges(OO, KO, pO) {
        return OO.listen(KO, pO, !1)
      }
      onEntityFieldChange(OO, KO, pO, XO) {
        switch (pO) {
          case "ridingVehicleEId": {
            this.promoteIfQueued(XO);
            const KO = this.ap.tL.oCO((0, sp.e)(OO));
            KO && (KO.ridingVehicleEId = XO);
            break
          }
          case "armour":
            this.handleArmourChange(OO, XO);
            break;
          case "followingEId":
            this.promoteIfQueued(XO), this.handleFollowingEIdChange(OO, KO, XO);
            break;
          case "xRotation":
          case "yRotation":
          case "zRotation":
            this.handleRotationChange(OO, pO, XO);
            break;
          case "scale":
            this.handleScaleChange(OO, XO);
            break;
          case "baseRenderHeading":
            this.handleBaseRenderHeadingChange(OO, XO);
            break;
          case "followingOffset":
            this.handleFollowingOffsetChange(OO, XO);
            break;
          case "shouldMatchFollowingEntityRotation":
            this.handleShouldMatchFollowingEntityRotationChange(OO, XO);
            break;
          case "x":
          case "y":
          case "z":
            return void this.handlePositionChange(OO, pO, XO)
        }(0, Sp.b)().client.updateEntityField(OO, pO, XO)
      }
      handleArmourChange(OO, KO) {
        var pO, XO;
        const {
          key: bK,
          value: eO
        } = KO;
        (0, dp.v)(OO, bK, null !== (pO = null === eO || void 0 === eO ? void 0 : eO.itemName) && void 0 !== pO ? pO : null, null !== (XO = null === eO || void 0 === eO ? void 0 : eO.enchantmentTier) && void 0 !== XO ? XO : null)
      }
      handleFollowingEIdChange(OO, KO, pO) {
        const XO = (0, sp.e)(OO),
          bK = XO === this.ap.CpO;
        if (this.ap.tL.OpO(XO, this.ap.tL.names.lE), pO) this.ap.tL.OpO(XO, "smoothToServerPos"), this.ap.tL.UKO(XO, this.ap.tL.names.lE, {
          dX: (0, sp.e)(pO),
          offset: Array.from(KO.followingOffset),
          khO: KO.shouldMatchFollowingEntityRotation,
          phO: !0,
          XhO: (OO, XO) => {
            if (upO().copy(OO, KO.followingOffset), KO.ridingVehicleEId === pO) {
              const KO = (0, sp.e)(pO),
                bK = (0, Sp.b)().getEntityHeading(KO, XO);
              upO().Ml(OO, OO, upO().ZERO, bK)
            }
          }
        });
        else if (!bK) {
          this.ap.tL.gCO(XO, "smoothToServerPos") || this.ap.tL.UKO(XO, "smoothToServerPos");
          const OO = this.ap.tL.getState(XO, "smoothToServerPos"),
            KO = this.ap.tL.beO(XO).position;
          (0, Zp.setServerPosition)(OO, KO[0], KO[1], KO[2])
        }
      }
      handleRotationChange(OO, KO, pO) {
        const XO = "xRotation" === KO ? 0 : "yRotation" === KO ? 1 : 2;
        for (const bK of (0, Sp.b)().getFollowingEntities(OO)) {
          const OO = this.ap.tL.getState(bK, "meshRotation"),
            KO = this.ap.tL.thO(bK);
          OO && KO.khO && (OO.serverSetRotation[XO] = pO)
        }
      }
      handleScaleChange(OO, KO) {
        const pO = (0, sp.e)(OO);
        if (kp.i.pl(`entityScale|${pO}`, KO), pO === this.ap.CpO) {
          var XO;
          (0, Sp.b)().removeFromEyeHeightCache(pO);
          const OO = this.ap.tL.qCO(this.ap.CpO),
            KO = null !== (XO = null === OO || void 0 === OO ? void 0 : OO.physicsState) && void 0 !== XO ? XO : {
              type: Hp.p.DEFAULT,
              tier: null
            };
          return void(0, Sp.b)().updatePositionAndPhysics(this.ap.CpO, KO, !1)
        }
        const bK = (0, Sp.b)().getLifeformType(pO);
        if (null === bK) return;
        const {
          physicsBodyWidth: eO,
          physicsBodyHeight: lO
        } = (0, Bp.g)(KO, bK);
        this.ap.tL.nCO(pO, eO, lO, eO)
      }
      handleBaseRenderHeadingChange(OO, KO) {
        const pO = this.ap.tL.getState(OO, "meshRotation");
        pO && (pO.baseRenderRotation[1] = KO);
        for (const XO of (0, Sp.b)().getFollowingEntities(OO)) {
          const OO = this.ap.tL.getState(XO, "meshRotation"),
            pO = this.ap.tL.thO(XO);
          OO && pO.khO && (OO.baseRenderRotation[1] = KO)
        }
      }
      handleFollowingOffsetChange(OO, KO) {
        const pO = this.ap.tL.thO((0, sp.e)(OO));
        if (pO && pO.offset) {
          const OO = KO ? Array.from(KO) : upO().ZERO;
          pO.offset[0] = OO[0], pO.offset[1] = OO[1], pO.offset[2] = OO[2]
        }
      }
      handleShouldMatchFollowingEntityRotationChange(OO, KO) {
        const pO = this.ap.tL.thO((0, sp.e)(OO));
        pO && (pO.khO = null === KO || void 0 === KO || KO)
      }
      handlePositionChange(OO, KO, pO) {
        if (this.ap.tL.gCO(OO, "smoothToServerPos")) {
          const XO = this.ap.tL.getState(OO, "smoothToServerPos");
          (0, Zp.setServerPositionAxis)(XO, tX[KO], pO)
        }
      }
      setupItemHandlers() {
        this.roomStateCallbacks.items.qL(((OO, KO) => {
          this.allItems[KO] = OO, (0, Rp.q)(this.ap, KO, [OO.x, OO.y, OO.z], OO.id, {
            amount: OO.amount,
            attributes: JSON.parse(OO.attributes),
            B3: (0, UK.e)(this.ap).cantPickUpItem(KO),
            size: OO.size,
            predictedAt: (0, Sp.b)().client.itemDropPrediction.onServerItemAdded(KO)
          });
          const pO = this.createStateCallbacks(OO);
          for (const XO of Mp(lp)) this.onItemFieldChange(KO, XO, OO[XO]), this.addDetacher(KO, this.listenForFutureChanges(pO, XO, (OO => {
            this.onItemFieldChange(KO, XO, OO)
          })))
        })), this.roomStateCallbacks.items.ypO(((OO, KO) => {
          delete this.allItems[KO], this.detach(KO), (0, Sp.b)().client.itemDropPrediction.onServerItemRemoved(KO), this.ap.tL.gCO(KO, this.ap.tL.names.itemState) && this.ap.tL.deleteEntity(KO), (0, UK.e)(this.ap).disposeEntity(KO)
        }))
      }
      onItemFieldChange(OO, KO, pO) {
        if (KO in tX) {
          if (this.ap.tL.gCO(OO, "itemState")) {
            const XO = this.ap.tL.getState(OO, "smoothToServerPos");
            (0, Zp.setServerPositionAxis)(XO, tX[KO], pO), (0, Sp.b)().client.itemDropPrediction.onServerItemMoved(OO)
          }
          return
        }
        if (!this.ap.tL.gCO(OO, "itemState")) return;
        const XO = this.ap.tL.getState(OO, "itemState");
        "amount" === KO && pO !== XO.amount && (XO.creationTime = Date.now()), XO[KO] = "attributes" === KO ? JSON.parse(pO) : pO
      }
      dispose() {
        if (!this.YX) {
          this.YX = !0, this.ap.off("beforeInputs", this.onFrame), this.ap.off("KK", this.xV), this.queuedSetups.clear(), this.promotedSetups.clear();
          for (const OO of this.deferredSetups.values()) kp.i.unsubscribe(OO);
          this.deferredSetups.clear(), this.ap.tL.OpO(this.ap.CpO, this.ap.tL.names.lE);
          for (const OO in this.allItems) this.ap.tL.deleteEntity(OO), delete this.allItems[OO];
          for (const OO of [...this.detachers.keys()]) this.detach(OO);
          (0, UK.e)(this.ap).clear();
          for (const OO of (0, Sp.b)().client.iterateEntityIds())(0, Sp.b)().client.disposeEntity(OO)
        }
      }
    }
    const xX = [0, 0, 0];

    function np(OO) {
      if ("string" !== typeof OO) return;
      const KO = OO.indexOf("|"),
        pO = -1 === KO ? OO : OO.slice(0, KO),
        XO = Up();
      return Object.hasOwn(XO, pO) ? XO[pO] : void 0
    }
    const Wp = new Set;
    const tX = {
      x: 0,
      y: 1,
      z: 2
    };
    let kX = null;

    function Up() {
      return null !== kX || (kX = {
        ...Object.fromEntries(bX.h.map((OO => {
          const {
            Iq: KO
          } = (0, Jp.d)(OO);
          return [OO, KO]
        }))),
        Pebble: Fp.b,
        Snowball: Fp.b,
        "Snowball Launcher": Fp.b,
        "Reinforced Pebble": Fp.b,
        Bullet: Fp.b,
        "Reinforced Ball": Fp.b,
        Ball: Fp.b,
        Mango: Fp.b,
        "Moonstone Orb": Fp.b,
        ...Object.fromEntries(Xp.s.map((OO => [(0, Ap.Tb)(OO), Fp.b]))),
        Arrow: Fp.b,
        "Arrow of Speed": Fp.b,
        "Arrow of Poison": Fp.b,
        "Arrow of Slowness": Fp.b,
        "Arrow of Weakness": Fp.b,
        "Arrow of Knockback": Fp.b,
        "Arrow of Strength": Fp.b,
        "Arrow of Invisibility": Fp.b,
        "Arrow of Jumping": Fp.b,
        "Arrow of Defense": Fp.b,
        "Arrow of Instant Healing": Fp.b,
        "Arrow of Instant Damage": Fp.b,
        "Arrow of Regeneration": Fp.b,
        "Arrow of Haste": Fp.b,
        "Arrow of Shield": Fp.b,
        "Arrow of Double Jump": Fp.b,
        "Arrow of Heat Resistance": Fp.b,
        "Arrow of X-Ray Vision": Fp.b,
        "Arrow of Mining Yield": Fp.b,
        "Arrow of Brain Rot": Fp.b,
        "Arrow of Milk": Fp.b,
        Fireball: Fp.b,
        "Bouncy Bomb": Fp.b,
        RPG: Fp.b,
        "Obby RPG": Fp.b,
        "Super RPG": Fp.b,
        "Grenade Launcher": Fp.b,
        Iceball: Fp.b,
        Coconut: Fp.b,
        "Splash Speed Potion": Fp.b,
        "Splash Defense Potion": Fp.b,
        "Splash Strength Potion": Fp.b,
        "Splash Invisibility Potion": Fp.b,
        "Splash Jump Potion": Fp.b,
        "Splash Knockback Potion": Fp.b,
        "Splash Poison Potion": Fp.b,
        "Splash Speed Potion II": Fp.b,
        "Splash Defense Potion II": Fp.b,
        "Splash Strength Potion II": Fp.b,
        "Splash Jump Potion II": Fp.b,
        "Splash Knockback Potion II": Fp.b,
        "Splash Poison Potion II": Fp.b,
        "Splash Slowness Potion": Fp.b,
        "Splash Slowness Potion II": Fp.b,
        "Splash Weakness Potion": Fp.b,
        "Splash Weakness Potion II": Fp.b,
        "Splash Milk Potion": Fp.b,
        "Splash Instant Damage Potion": Fp.b,
        "Splash Instant Damage Potion II": Fp.b,
        "Splash Instant Healing Potion": Fp.b,
        "Splash Instant Healing Potion II": Fp.b,
        "Splash Regeneration Potion": Fp.b,
        "Splash Regeneration Potion II": Fp.b,
        "Splash Haste Potion": Fp.b,
        "Splash Haste Potion II": Fp.b,
        "Splash Shield Potion": Fp.b,
        "Splash Shield Potion II": Fp.b,
        "Splash Double Jump Potion": Fp.b,
        "Splash Heat Resistance Potion": Fp.b,
        "Splash X-Ray Vision Potion": Fp.b,
        "Splash Mining Yield Potion": Fp.b,
        "Splash Mining Yield Potion II": Fp.b,
        "Splash Brain Rot Potion": Fp.b,
        "Yellow Paintball Gun": Fp.b,
        "White Paintball Gun": Fp.b,
        "Red Paintball Gun": Fp.b,
        "Purple Paintball Gun": Fp.b,
        "Pink Paintball Gun": Fp.b,
        "Orange Paintball Gun": Fp.b,
        "Magenta Paintball Gun": Fp.b,
        "Lime Paintball Gun": Fp.b,
        "Light Gray Paintball Gun": Fp.b,
        "Light Blue Paintball Gun": Fp.b,
        "Green Paintball Gun": Fp.b,
        "Gray Paintball Gun": Fp.b,
        "Cyan Paintball Gun": Fp.b,
        "Brown Paintball Gun": Fp.b,
        "Blue Paintball Gun": Fp.b,
        "Black Paintball Gun": Fp.b,
        "Yellow Heavy Paintball Gun": Fp.b,
        "White Heavy Paintball Gun": Fp.b,
        "Red Heavy Paintball Gun": Fp.b,
        "Purple Heavy Paintball Gun": Fp.b,
        "Pink Heavy Paintball Gun": Fp.b,
        "Orange Heavy Paintball Gun": Fp.b,
        "Magenta Heavy Paintball Gun": Fp.b,
        "Lime Heavy Paintball Gun": Fp.b,
        "Light Gray Heavy Paintball Gun": Fp.b,
        "Light Blue Heavy Paintball Gun": Fp.b,
        "Green Heavy Paintball Gun": Fp.b,
        "Gray Heavy Paintball Gun": Fp.b,
        "Cyan Heavy Paintball Gun": Fp.b,
        "Brown Heavy Paintball Gun": Fp.b,
        "Blue Heavy Paintball Gun": Fp.b,
        "Black Heavy Paintball Gun": Fp.b,
        "Toxin Ball": Fp.b,
        "Splash Aura XP Potion": Fp.b,
        "Splash Aura XP Potion II": Fp.b,
        "Arrow of Aura XP": Fp.b,
        Firecracker: Fp.b,
        "Rainbow Firecracker": Fp.b,
        "White Firecracker": Fp.b,
        "Orange Firecracker": Fp.b,
        "Magenta Firecracker": Fp.b,
        "Light Blue Firecracker": Fp.b,
        "Yellow Firecracker": Fp.b,
        "Lime Firecracker": Fp.b,
        "Pink Firecracker": Fp.b,
        "Gray Firecracker": Fp.b,
        "Light Gray Firecracker": Fp.b,
        "Cyan Firecracker": Fp.b,
        "Purple Firecracker": Fp.b,
        "Blue Firecracker": Fp.b,
        "Brown Firecracker": Fp.b,
        "Green Firecracker": Fp.b,
        "Red Firecracker": Fp.b,
        "Black Firecracker": Fp.b,
        "Firecracker Pebble": Fp.b,
        "Rainbow Firecracker Pebble": Fp.b,
        "White Firecracker Pebble": Fp.b,
        "Orange Firecracker Pebble": Fp.b,
        "Magenta Firecracker Pebble": Fp.b,
        "Light Blue Firecracker Pebble": Fp.b,
        "Yellow Firecracker Pebble": Fp.b,
        "Lime Firecracker Pebble": Fp.b,
        "Pink Firecracker Pebble": Fp.b,
        "Gray Firecracker Pebble": Fp.b,
        "Light Gray Firecracker Pebble": Fp.b,
        "Cyan Firecracker Pebble": Fp.b,
        "Purple Firecracker Pebble": Fp.b,
        "Blue Firecracker Pebble": Fp.b,
        "Brown Firecracker Pebble": Fp.b,
        "Green Firecracker Pebble": Fp.b,
        "Red Firecracker Pebble": Fp.b,
        "Black Firecracker Pebble": Fp.b,
        "Blinding Pebble": Fp.b,
        Poop: Fp.b,
        "Wood Boomerang": Fp.b,
        "Stone Boomerang": Fp.b,
        "Iron Boomerang": Fp.b,
        "Gold Boomerang": Fp.b,
        "Diamond Boomerang": Fp.b,
        "Amethite Boomerang": Fp.b,
        "Magmasteel Boomerang": Fp.b,
        "Rubellite Boomerang": Fp.b,
        "Serpentite Boomerang": Fp.b,
        "Moonstone Boomerang": Fp.b,
        "67 Base Projectile": Fp.b,
        "67 Boosted Projectile": Fp.b,
        "Capitano Grenade": Fp.b,
        "Scatter Pellet": Fp.b,
        "Lucky Bomb": Fp.b,
        "Unlucky Bomb": Fp.b,
        "Swap Orb": Fp.b,
        Mesh: iX,
        AudioEntity: Pp
      }), kX
    }
  },
  37365: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      h: () => lO
    });
    var XO = pO(533),
      bK = pO(36102);
    const eO = 4e4;
    class lO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Date.now;
        this.now = OO, this.editedAt = new Map, this.lastChunkX = NaN, this.lastChunkY = NaN, this.lastChunkZ = NaN, this.lastChunkId = ""
      }
      noteEdit(OO, KO, pO) {
        const eO = (0, XO.P)(OO),
          lO = (0, XO.P)(KO),
          vK = (0, XO.P)(pO),
          CO = this.now();
        if (eO !== this.lastChunkX || lO !== this.lastChunkY || vK !== this.lastChunkZ) {
          this.lastChunkX = eO, this.lastChunkY = lO, this.lastChunkZ = vK, this.lastChunkId = (0, bK.b)(eO, lO, vK), this.editedAt.delete(this.lastChunkId), this.editedAt.set(this.lastChunkId, CO);
          for (const [OO, KO] of this.editedAt) {
            if (KO >= CO - 3e5) break;
            this.editedAt.delete(OO)
          }
        } else this.editedAt.set(this.lastChunkId, CO)
      }
      chunksEditedSince(OO) {
        const KO = [];
        for (const [pO, XO] of this.editedAt) XO >= OO && KO.push(pO);
        return KO
      }
    }
  },
  37454: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vp,
      e: () => PK,
      i: () => yp,
      k: () => mp
    });
    var XO = pO(2931),
      bK = pO(7824),
      eO = pO(35220),
      lO = pO(1253),
      vK = pO(35259),
      CO = pO(37396),
      hO = pO(37340),
      DO = pO(3006),
      MO = pO(36238),
      aK = pO(1098),
      oO = pO(243),
      FO = pO(26),
      VO = pO(1569),
      LO = pO(94),
      QO = pO(36),
      zK = pO(1591),
      AO = pO(1531),
      fO = pO(2317);
    class dO {
      constructor(OO) {
        this.storeForMs = OO, this.clicks = new fO.d
      }
      click() {
        this.clicks.enqueue(Date.now());
        const OO = Date.now() - this.storeForMs;
        for (; this.clicks.size > 0 && this.clicks.peek() < OO;) this.clicks.dequeue()
      }
      getNumClicksInMs(OO) {
        let KO = 0;
        return this.clicks.forEach((pO => {
          pO > Date.now() - OO && KO++
        })), KO
      }
      getMaxClickSeparationInMs(OO) {
        if (0 === this.clicks.size) return this.storeForMs;
        let KO = 0,
          pO = Date.now() - OO;
        this.clicks.forEach((XO => {
          XO < Date.now() - OO || (KO = Math.max(KO, Math.abs(XO - pO)), pO = XO)
        }));
        const XO = Math.abs(Date.now() - pO);
        return Math.max(KO, XO)
      }
    }
    class TO {
      constructor(OO) {
        this.storeForMs = OO, this.clickDownDurations = new fO.d
      }
      registerClickDownDuration(OO) {
        this.clickDownDurations.enqueue({
          dur: OO,
          atTime: Date.now()
        });
        const KO = Date.now() - this.storeForMs;
        for (; this.clickDownDurations.size > 0 && this.clickDownDurations.peek().atTime < KO;) this.clickDownDurations.dequeue()
      }
      clickDownDurationsCheck(OO) {
        if (OO > this.storeForMs) return console.error("overDuration is greater than storeForMs"), "0:0";
        let KO = 0,
          pO = 0;
        return this.clickDownDurations.forEach((XO => {
          XO.atTime > Date.now() - OO && (KO++, pO = Math.max(pO, XO.dur))
        })), `${KO}:${pO}`
      }
    }
    var NO = pO(35020),
      IO = pO(37456),
      yK = pO(22),
      gK = pO(2231),
      uO = pO(1163),
      EO = pO(37378),
      jK = pO(3631),
      YO = pO(142),
      wO = pO(36559),
      iK = pO(36773),
      rK = pO(533),
      PO = pO(35017),
      mK = pO(8365),
      sO = pO(1077),
      HO = pO(171),
      RO = pO(37458),
      SO = pO(37460),
      JO = pO(36590),
      cK = pO(37470),
      BO = pO(36507),
      ZO = pO(35069),
      GO = pO(1441),
      qK = pO(35137),
      xK = pO(2412),
      nO = pO(37464);
    const WO = {
      forward: "freeCamForward",
      backward: "freeCamBackward",
      left: "freeCamLeft",
      right: "freeCamRight",
      jump: "freeCamUp",
      crouch: "freeCamDown"
    };

    function tK() {
      var OO;
      const KO = (0, gK.b)().client;
      return (null === KO || void 0 === KO ? void 0 : KO.isReplayMode()) && (null === (OO = KO.freeCameraController) || void 0 === OO ? void 0 : OO.isEnabled())
    }

    function kK(OO) {
      const KO = OO.on.bind(OO);
      OO.on = (OO, pO) => {
        zK.x.has(OO) ? KO(OO, pO) : KO(OO, (KO => {
          var XO;
          return null !== (XO = (0, gK.b)().client) && void 0 !== XO && XO.isReplayMode() ? function(OO) {
            return OO in WO
          }(OO) && tK() ? pO(KO) : void 0 : pO(KO)
        }))
      }
    }
    const UO = 5e3,
      OK = 1;
    let KK, pK = OK,
      XK = 0;
    const bp = !0;
    let eK = bp;
    VO.c.subscribe("_ignoreBasicBoards", (OO => {
      eK = OO
    })), (0, XO.onGameReset)((() => {
      eK = bp
    }));
    let lK = null;
    const vp = () => lK;
    let CK, hK, DK;
    var MK, ap, oK, FK, VK, LK, QK, zp, AK;
    const fK = [0, 1, 8, 255, "length", "undefined", void 0, 220, 3, "b", 163, 63, 6, "fromCodePoint", 7, 12, "push", 15, "h", "c", "a", 9, 242, 91, "e", 8191, 88, 13, 14, "d", 33554432, 67108864, 2, 65, "f", "g", 142, 5, 4, 116, 35, 89, 217, 31, 82, 195, 21, 141, !1, 96, 27, 240, 56, 111, 123, null, 67, 10, 99, 26, 48, 181, 191, 208, 64, 189, 196, 127, 61, "i", 209, !0, 128, 113, 176, 94, 139, 222, 78];

    function dK(OO) {
      return typeof MK[OO] === fK[5] ? MK[OO] = function(OO) {
        var KO, pO, XO, bK, eO, lO, vK;
        for (IK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = fK[0], eO = fK[0], lO = -fK[1]), vK = fK[0]; vK < pO; vK++) {
          var CO = 'k1wV|>R!p;9=`t*X.#+_G"A5YWv^@)M<3$l]&i2E4DI6h%j:70{xL}KPuyb[/(aUzS?H8BQc~,TeroJCdmNnOsFqfZg'.indexOf(KO[vK]);
          if (CO !== -fK[1])
            if (lO < fK[0]) lO = CO;
            else {
              IK(lO += CO * fK[23], bK |= lO << eO, eO += (lO & fK[25]) > fK[26] ? fK[27] : fK[28]);
              do {
                IK(XO.push(bK & fK[3]), bK >>= fK[2], eO -= fK[2])
              } while (eO > fK[14]);
              lO = -fK[1]
            }
        }
        return lO > -fK[1] && XO.push((bK | lO << eO) & fK[3]), TK(XO)
      }(ap[OO]) : MK[OO]
    }

    function TK(...OO) {
      return OO[fK[4]] = fK[1], typeof FK !== fK[5] && FK ? (new FK).decode(new VK(OO[fK[0]])) : typeof LK !== fK[5] && LK ? LK.from(OO[fK[0]]).toString("utf-8") : AK(OO[fK[0]])
    }

    function NK() {}

    function IK() {
      IK = function() {}
    }

    function yp(OO) {
      function KO() {
        return OO.tL.mhO(OO.CpO)
      }
      kK(OO.inputs.down), kK(OO.inputs.up);
      for (const XO of ["forward", "backward", "left", "right", "sprint", "jump", "crouch"]) {
        const KO = (KO, pO) => {
          var bK, eO;
          if (tK()) {
            const OO = WO[XO];
            var lO, vK;
            if (OO) null === (lO = (0, gK.b)().client) || void 0 === lO || null === (vK = lO.freeCameraController) || void 0 === vK || vK.handlefreeCamKeyPress(OO, KO, pO);
            return
          }
          if (null !== (bK = (0, gK.b)().client) && void 0 !== bK && null !== (eO = bK.freeCameraController) && void 0 !== eO && eO.isKeyPressOverriden(KO)) return;
          OO.tL.JCO()[XO] = pO
        };
        OO.inputs.down.on(XO, (OO => KO(OO, !0))), OO.inputs.up.on(XO, (OO => KO(OO, !1)))
      }
      OO.inputs.down.on("crouch", (() => {
        if (tK()) return;
        if (!OO.JV.canCrouch) return;
        const KO = OO.tL.JCO();
        yK.d.get("clientEscMenuOptions").crouchIsToggle && (KO.crouchToggled = !KO.crouchToggled && !KO.padSneakToggled), KO.padSneakToggled = !1
      }));
      const pO = () => {
        const OO = KO();
        OO.isGun() && OO.inaccuracyCalculator.jump()
      };
      OO.inputs.down.on("jump", (OO => {
        tK() || (pO(), CK(OO))
      }));
      for (const XO of zK.h) OO.inputs.down.on(XO, (OO => {
        var KO, pO;
        null !== (KO = (0, gK.b)().client) && void 0 !== KO && null !== (pO = KO.freeCameraController) && void 0 !== pO && pO.handlefreeCamKeyPress(XO, OO, !0) && (OO.preventDefault(), OO.stopPropagation())
      })), OO.inputs.up.on(XO, (OO => {
        var KO, pO;
        null !== (KO = (0, gK.b)().client) && void 0 !== KO && null !== (pO = KO.freeCameraController) && void 0 !== pO && pO.handlefreeCamKeyPress(XO, OO, !1) && (OO.preventDefault(), OO.stopPropagation())
      }));
      OO.inputs.down.on("recordGame", (() => {
        var OO, KO;
        null === (OO = (0, gK.b)().client) || void 0 === OO || null === (KO = OO.gameRecorder) || void 0 === KO || KO.toggleRecording()
      })), OO.inputs.down.on("recordClip", (() => {
        var OO, KO;
        (0, NO.c)() || null === (OO = (0, gK.b)().client) || void 0 === OO || null === (KO = OO.gameRecorder) || void 0 === KO || KO.saveClip()
      }));
      for (const XO of zK.x) OO.inputs.down.on(XO, (() => {
        var OO;
        if ((0, IO.c)()) return;
        if ("replayViewerOpen" === XO) return void FO.i.pl("replayViewer|requested", "toggle");
        const KO = null === (OO = (0, gK.b)().client) || void 0 === OO ? void 0 : OO.gameReplayer;
        ((0, NO.c)() || null !== KO && void 0 !== KO && KO.isReplayMode()) && (null === KO || void 0 === KO || KO.handleAction(XO))
      }));
      const lO = new dO(3e4),
        MO = new TO(4e4);
      let QO = 0;
      const fO = OO => {
          let KO = 0,
            pO = null;
          const XO = KO => null !== KO && KO === pO && (pO = null, OO(), !0);
          return {
            press: () => (KO++, (0, RO.e)() || (XO(pO), pO = KO), KO),
            owns: OO => OO === pO,
            release: XO
          }
        },
        jK = (OO, pO) => {
          pO && mp(aK.b.TouchDownFirePrimary), OO ? cK() : ((0, iK.e)(), KO().iDO()), pO || mp(aK.b.DownFirePrimary), PK(!0), lO.click();
          const bK = lO.getMaxClickSeparationInMs(3e4) < 1e3 / 30,
            eO = lO.getMaxClickSeparationInMs(1e4) < 20,
            vK = lO.getMaxClickSeparationInMs(4e3) < 1e3 / 70;
          if (bK || eO || vK) {
            let OO;
            if (bK) OO = 30;
            else if (eO) OO = 50;
            else {
              if (!vK) throw new Error("???");
              OO = 70
            }(0, XO.sendColyMessage)(DO.Ej, OO)
          }
        },
        YO = fO((() => {
          const OO = Date.now() - QO;
          MO.registerClickDownDuration(OO), KO().EhO(), mp(aK.b.UpFirePrimary), PK(!1);
          const pO = MO.clickDownDurationsCheck(4e4);
          (0, XO.sendColyMessage)(DO.gg, pO)
        }));
      let wO = 0;
      OO.inputs.down.on("primary-fire", (function(OO) {
        wO = YO.press(), YO.owns(wO) && (QO = Date.now(), Math.abs(performance.now() - OO.timeStamp) > 5e3 || (jK(OO.altKey, "changedTouches" in OO), CK(OO)))
      })), OO.inputs.up.on("primary-fire", (function(OO) {
        YO.release(wO) && CK(OO, !0)
      }));
      const rK = () => {
          KO().UoO(), mp(aK.b.DownFireSecondary), PK(!0), OO.zCO && !OO.zCO.position && (0, hO.e)()
        },
        PO = fO((() => {
          KO().uhO(), mp(aK.b.UpFireSecondary), PK(!1)
        }));
      let mK = 0;
      OO.inputs.down.on("alt-fire", (function(OO) {
        mK = PO.press(), PO.owns(mK) && (rK(), CK(OO))
      })), OO.inputs.up.on("alt-fire", (function(OO) {
        PO.release(mK) && CK(OO, !0)
      }));
      const cK = () => KO().hFO();
      OO.inputs.down.on("mid-fire", (() => {
        (0, RO.e)() || cK()
      }));
      const KK = OO => {
          (0, XO.sendColyMessage)(DO.qh, OO)
        },
        XK = OO => {
          (0, XO.sendColyMessage)(DO.sh, {
            GJ: OO,
            JK: eK()
          })
        };
      for (const XO of ["SpecialAction1", "SpecialAction2"]) OO.inputs.down.on(XO, (() => {
        KK(XO)
      })), OO.inputs.up.on(XO, (() => {
        XK(XO)
      }));
      const bp = () => {
        const OO = KO();
        OO.isGun() && OO.reload(Date.now())
      };
      OO.inputs.down.on("ReloadGun", bp);
      const eK = () => {
        let KO = "a";
        return OO.physics.testSolid.toString().includes("wK") || (KO = "b"), KO
      };
      OO.inputs.down.on("OpenInventory", (OO => {
        OO.preventDefault(), (0, GO.t)(OO, "inventory", (0, SO.d)((0, gK.d)()))
      })), OO.inputs.bind("ShiftHeld", "ShiftLeft", "ShiftRight");
      const vp = OO => {
        FO.i.pl("DropItemKeyPressed", OO)
      };
      OO.inputs.down.on("DropItem", (() => {
        vp(OO.tL.JCO().crouch)
      })), OO.inputs.down.on("OpenShop", (KO => {
        (0, NO.c)() || "inGame" === yK.d.get("gameState") && (0, GO.p)(KO, oO.o.SHOP, !(0, bK.e)(OO.JV.shopInfo))
      })), OO.inputs.down.on("OpenLobbyLeaderboard", (KO => {
        (0, NO.c)() || "inGame" === yK.d.get("gameState") && (0, GO.p)(KO, oO.o.LOBBY_LEADERBOARD, !!OO.JV.lobbyLeaderboardInfo)
      })), OO.inputs.down.on("HideUi", (() => {
        FO.i.pl("showUi", !1)
      })), OO.inputs.up.on("HideUi", (() => {
        FO.i.pl("showUi", !0)
      }));
      const DK = OO => {
        0 === OO && (OO = 10), FO.i.pl("setSelectedInventorySlotI", OO - 1), FO.i.pl("numkeyPressed", OO)
      };
      for (let XO = 1; XO <= 10; XO++) OO.inputs.down.on("HotBarSlot" + XO.toString(), (() => {
        DK(XO)
      }));
      OO.inputs.down.on("OpenTasksAndLeaderboard", (KO => {
        const pO = (0, qK.k)();
        pO ? (0, GO.v)(KO, !0, pO) : (0, GO.t)(KO, "retentionFeatures", !(!OO.JV._tasks && !OO.JV._availableLeaderboards))
      })), OO.inputs.down.on("OpenCodeEditor", (KO => {
        (0, GO.v)(KO, (0, EO.c)((0, uO.b)()), (() => {
          FO.i.pl("EditLobbyCode", OO.tL.fV(OO.CpO).map(Math.floor))
        }))
      })), OO.inputs.bind("ToggleFullCoordinateOverlay", "F3"), OO.inputs.down.on("ToggleFullCoordinateOverlay", (() => {
        FO.i.pl("toggleFullCoordinateOverlay")
      }));
      const MK = () => {
        (0, gK.b)().client.cameraController.swapCameraZoom()
      };
      OO.inputs.down.on("SwapCameraZoom", MK), OO.inputs.down.on("OpenInviteLink", (OO => {
        (0, GO.t)(OO, "inviteLink", LO.featureFlags.canUseInviteLinks)
      })), OO.inputs.bind("Y", "KeyY"), OO.inputs.down.on("Y", (OO => {
        (0, NO.c)() || FO.i.pl("YKeyPressed")
      })), OO.inputs.bind("X", "KeyX"), OO.inputs.down.on("X", (OO => {
        (0, NO.c)() || FO.i.pl("XKeyPressed")
      })), OO.inputs.down.on("OpenEmoteWheel", (() => {
        FO.i.pl("requestEmoteWheelHoldOpen")
      })), OO.inputs.up.on("OpenEmoteWheel", (() => {
        FO.i.pl("requestEmoteWheelHoldRelease")
      })), OO.inputs.down.on("Zoom", (() => {
        if ("inGame" === yK.d.get("gameState")) {
          OO.tL.getState(OO.CpO, "playerCameraAdjustment").zoomKeyPressed = !0, (0, gK.b)().client.cameraController.handleZoomKeyPressed()
        }
      })), OO.inputs.up.on("Zoom", (() => {
        OO.tL.getState(OO.CpO, "playerCameraAdjustment").zoomKeyPressed = !1
      })), gp();
      const ap = OO => function() {
        return hK(), OO(...arguments)
      };

      function oK(OO) {
        "inGame" !== yK.d.get("gameState") || (0, GO.l)() || (FO.i.pl("ctrlCrouchWithoutFullscreen"), OO.preventDefault())
      }
      lK = {
        primaryFireDown: ap((() => {
          const OO = YO.press();
          return YO.owns(OO) && (QO = Date.now(), jK(!1, !1)), OO
        })),
        primaryFireUp: ap((OO => {
          YO.release(OO)
        })),
        altFireDown: ap((() => {
          const OO = PO.press();
          return PO.owns(OO) && rK(), OO
        })),
        altFireUp: ap((OO => {
          PO.release(OO)
        })),
        jumpDown: ap(pO),
        specialActionDown: ap(KK),
        specialActionUp: ap(XK),
        reloadGun: ap(bp),
        dropItem: ap(vp),
        swapCameraZoom: ap(MK),
        XM: ap(cK)
      }, OO.inputs.down.on("ctrlCrouch", oK), OO.inputs.up.on("ctrlCrouch", oK), OO.inputs.bind("ctrlCrouch", "ControlLeft");
      const FK = OO => {
        "inGame" === yK.d.get("gameState") && OO.ctrlKey && !(0, GO.l)() && OO.preventDefault()
      };
      document.addEventListener("keydown", FK), document.addEventListener("keyup", FK), document.addEventListener("keypress", FK), OO.inputs.bind("Alt", "AltLeft", "AltRight"), OO.inputs.down.on("Alt", (OO => {
        OO.preventDefault()
      }));
      const VK = KO => (0, BO.j)(OO, KO),
        LK = KO => (0, BO.k)(OO, KO),
        QK = [0, 0, 0],
        zp = [0, 0, 1];
      OO.on("afterRender", (KO => {
        (0, eO.h)(OO.camera.heading), (0, BO.o)(OO, QK, zp), (0, gK.b)().client.triggerGameCallback("onAfterRender", KO, {
          cameraHeading: OO.camera.heading,
          cameraPitch: OO.camera.pitch,
          cameraPosition: QK,
          cameraDirection: zp,
          tanHalfFovX: (0, BO.e)(OO),
          tanHalfFovY: Math.tan(OO.Lb.ceO().fov / 2),
          screenBandPct: {
            x: ZO.e,
            y: (0, ZO.j)()
          },
          projectWorldPosToScreenPos: VK,
          projectWorldPosToViewport: LK
        })
      })), (0, xK.q)("look") && (OO.camera.dXO = (0, nO.i)("js"), OO.inputs.sXO = nO.f), OO.on("beforeInputs", (() => {
        if ((0, IO.c)()) return OO.inputs.HXO.dx = 0, void(OO.inputs.HXO.dy = 0);
        if (OO.camera.HXO.dx += OO.inputs.HXO.dx, OO.camera.HXO.dy += OO.inputs.HXO.dy, 0 !== OO.inputs.HXO.dx || 0 !== OO.inputs.HXO.dy) {
          OO.tL.getState(OO.CpO, "playerCameraAdjustment").lastPointerMove = Date.now()
        }
        OO.inputs.HXO.dx = 0, OO.inputs.HXO.dy = 0
      }));
      let AK = 0;
      OO.on("KK", (function(KO) {
        FO.i.pl("noaTick", KO);
        const pO = (0, gK.b)().client;
        if (pO.triggerGameCallback("KK", KO), pO.isClientGameSessionActive()) try {
          CO.e.KK(KO)
        } catch (lO) {
          console.error("Error ticking audio entities", lO)
        }
        if (!OO.tL.rhO(OO.CpO).isAlive) return;
        Date.now() - AK > 9e3 && (! function() {
          const OO = (0, gK.d)();
          "number" === typeof OO.JV.speedMultiplier && "number" === typeof OO.JV.jumpAmount && (0, XO.sendColyMessage)(DO.Oh, {
            YB: (0, sO.h)(OO.JV.speedMultiplier),
            iZ: (0, sO.d)(OO.JV.jumpAmount),
            JB: (0, sO.h)(OO.JV.crouchingSpeed),
            xZ: (0, sO.h)(OO.JV.walkingSpeed),
            nB: (0, sO.h)(OO.JV.runningSpeed),
            OZ: (0, sO.d)(OO.vCO),
            eZ: OO.tL.qCO(OO.CpO).jumpForce,
            aG: OO.tL.beO(1).width,
            yG: OO.tL.beO(1).height,
            Re: OO.tL.XXO(1).Re
          }, !0)
        }(), AK = Date.now());
        const bK = OO.tL.JCO();
        if ((bK.jump || bK.forward || bK.backward || bK.left || bK.right || bK.sprint) && FO.i.pl("usedKeyboard"), OO.tL.QCO(OO.CpO) && !0 === OO.JV.canPickUpItems) {
          const KO = OO.tL.fV(OO.CpO),
            pO = (0, AO.q)(pK),
            bK = (0, AO.t)(pK),
            eO = [KO[0] - pO, KO[1] - .6 * bK, KO[2] - pO],
            lO = [KO[0] + pO, KO[1] + HO.h.uD + .6 * bK, KO[2] + pO],
            CO = OO.tL.DVO({
              base: eO,
              max: lO
            }, OO.tL.names.autoRotate),
            MO = OO => {
              const KO = HO.h.droppedBlockSize / 2;
              return [0, 1, 2].every((pO => OO[pO] >= eO[pO] - KO && OO[pO] <= lO[pO] + KO))
            },
            {
              itemDropPrediction: aK
            } = (0, gK.b)().client,
            oO = XO.offlineInputReplay.holdsInput();
          if (CO.length > 0)
            for (const FO of CO) {
              const KO = OO.tL.getState(FO, "itemState");
              if (void 0 === KO || Date.now() - KO.creationTime < 500) continue;
              let pO = FO,
                bK = null;
              if (KO.B3) {
                const OO = aK.pickupTarget(FO, MO, oO);
                if (null === OO) continue;
                ({
                  yB: pO,
                  uE: bK
                } = OO)
              }
              const eO = OO.tL.getState(pO, "itemState");
              if (eO.B3 && null === bK) continue;
              let lO = 0,
                CO = null,
                VO = !1;
              if (0 === eO.amount) VO = !0;
              else {
                const {
                  amountPickedUp: KO
                } = OO.tL.VCO(OO.CpO).pickUpItem({
                  name: eO.name,
                  typeObj: eO.typeObj,
                  amount: eO.amount,
                  attributes: eO.attributes
                });
                if (lO = KO, 0 === lO) continue;
                CO = JO.e.pickUp(eO, lO), eO.amount -= lO, eO.amount < 0 ? console.error("Picking up led to less than 0 of item!") : 0 === eO.amount ? VO = !0 : eO.creationTime = Date.now() + UO
              }
              const LO = (0, gK.b)().client.inventoryPrediction.record(CO);
              (0, XO.sendColyMessage)(DO.mh, {
                yB: null === bK ? pO : "",
                qB: lO,
                pB: hO.d,
                aY: LO,
                uE: bK
              }, !0), VO && (oO && aK.onPickedUpOffline(pO, LO, bK), null === bK && OO.tL.deleteEntity(pO));
              vK.c.play("pickUp", HO.h.pickupSoundVol).rate(1 + Math.random() * HO.h.pickupSoundRateVariation)
            }
        }
        if (!OO.tL.lCO(OO.CpO)) return;
        const eO = OO.inputs.HXO.kCO;
        if (0 !== eO) {
          const KO = eO > 0 ? 1 : -1;
          OO.inputs.state["mid-fire"] || OO.inputs.state.Alt || !OO.JV.useInventory ? (OO.inputs.state["mid-fire"] && FO.i.pl("requestEmoteWheelClose"), (0, gK.b)().client.cameraController.handleScrollZoom(KO)) : FO.i.pl("ScrollInventorySlot", KO)
        }
      })), VO.c.subscribe("droppedItemScale", (OO => {
        pK = "number" === typeof OO && isFinite(OO) ? OO : OK
      }))
    }

    function gp() {
      const OO = (0, gK.d)();
      if (OO)
        for (const KO in zK.s) {
          OO.inputs.unbind(KO);
          for (const pO of zK.s[KO]) OO.inputs.bind(KO, pO)
        }
    }
    IK(MK = {}, ap = ["D)o<K}{+,*WtJBVMp|!$]K8Y{UUQ+w", "3`o!VlF`?_!.LnBiR|n}1j?`~t.M.Xu)mQV", 'K49x]Ktm3/L!QmD<^lt<%xKF"tQ3{WA^i)s<(/c1kUt9bWliqk', "dR|{n2S1ya%|q*6W^8#eAJ1WU`", "u[u0=F)_j?J/&V=2rR3RBPLwcG{uqvB+|0Vo&:k", "7v5@$L|Yg=sU5vsD|Ul~C&AjNy_e;.3Y(4o{OLes:}qjR>)]e<zK!Fes|", "36ZRgKvpstjr@n?&#c8cKNdFhufjIiq)i6SRv4k", 'B73x!&vTuG]~=*3#Z=3;#ruMyG"~A2?&', "EG2LrP!_d;QWAme_FR2!!PPDdUe1/^iYP5M!", 'gl%!6i":GKw^+>~v%a1KkF4Ld`%r8Y;W#x}|lK0]x/O}1', "5/U|(l=}@#9^;.h2I4SRhx@pC+BuS/aYN@]oQTk", "FI8v<(9b(}w^:*M#KGgp08J`hu}B<^P)t/X$qJ2d&z/=t/R", "P[?)c{GTFzu@^{gD", "Z}5;f2StQzE@_wP),V_~.nALJu+eG.,W[S+3dm1WDb.x]v?i}c7K|74L*[b", "zl8Tid/Y}_7#:2#4QKH)0ul`@[:]:2i_", '3TK<ey(DF_z,)~W]CWDeUORY>bu3+iSYA`]3g,9+Jp&"BYc__y@P.nhY>_f31', "J[~RL~;BeSv", ">T2|cB^!/}E,t(c2*i%T/EaFT*=l1", "Rv1^20tUr*", 'rxv^Ie`bRb"Bu7(&90s<pC4j([L', "%#oc;/YYvS8?liH+XyO)Gn.z=SS3NB1Y>`}!.yO4Rb2", "2xw~|/XD;b+an2gDllKLWs2MWb^x<{wY9U{3v,$]S;*NuXz&Ck", "o=q;yQx]o+r|.VP)h8+e/ohM[pXSh:%^88iPVab4nz?dM0><q*3MCTb+d;Y", "_;Wx{NRz?`pt1~Qi=5k$xb<:gGUuGXyDR)30h8vYhpepZ/0E68V)G", "jRK!#mr+t+xa:*q)rSz,PQYY|yHo[nv@XvV", ":Go!]J!}e#|e^ckMf=z;_{9&yb_B(i?iSxW~LEbd[[tt]w3I*1", "IiQ@7EdYCU;5;O@5", "tyN)^:M`d+i?ENM#$yc0t{~Mtati?B)5b4~;S&qC9*", "nl)TZ2ytV", 'G5LT5J3`(a1:A>)M+U,39{;teGkcKQ%_`0"<o7hw', 'WvA|9&kQz`P@B/SY=0<L"nBt*+t~CXx4j8zxJ7k', 'ica0xoujAb"b<*|2Eyo<|7HD!zDYFBs^Si=~hNTjk?sT?mb@PS.;`', "%Rl^!}KLr=jP}|2_dQ[}(xi_RbpS*>g]P%WJbj4&/*FH#~p", "5KO>;7iy^#.CY||<QSt9O{JYcGQAs&A4UV3KZ$[DLK_C)|", "gl$R&eP1+;1K=N[Dv4@)B/,)&;y=dV", "XU/}9&imFbl[Fmp+p1", 'h8d;lJ~bS`OuGV[&T72r.a$:baFTDtQWSl#KenL8raz0A>_D{K#^HP$D@"n)1', "J8keuOy)pb37Y:YI@;50~PKbv*]r<Vv)S#!$9aLL,*W~~^K4Zao@70_Dv#", "GXw^ZsuTH;O}vmP]3KB<p7RY)?X5B77EIcwe)cgL=Sd/ai9", "n%B9$:lFI*s)W.~W!+d08PU]e#~op/1<Nk", "a@7,ZLGY%[=l6NS&S<|{Xc%y.UJ&:NTv", "J%<|(lSD<`@G;&N42TN3,Bi!|_U?8V", "QIx)UC!e1;", "Z,CLfcV_o*3G*>$MD`g3Nm0]IGbuP*c_[auR][st9#b*@:(5}k", ":;pRN%Q`7`8d5v1iWvc0M:.b|", ";vHpe2;}1+3SpE=v_yj,r{/Mny(|W~z5w]LTsy&w", "o%c;e{MMlU[+4[f.Z%`)Kjp&7/]7aWs451", '|/)PuUlFub/"1', "~5mR|F#]@[q`[Q9Wv88Pls}1", "/@])6]H1", '?7<@HC"t?y:|~XSIZaD~J{E]pP6[?mUil5v^^', "0y~R=FX:9[;S~cliZ7IoD0k", 'Ax;^?Tn)&t3GTWQYi`U|R&+Q"t#B,7bINxw', 'U#(PLN>!gS.NsY()nQiLklb4<X>Nq*/5tj3^Yn7F3/0"P*[]Jk', "[[)!IeSDn`q/Z|dl7SEKBCNj+/I#znG^]`weFrtWDS?,`c@Ic80~KUJRR", 'n7)!Vj,Uk`a,y|pi6R;^_{7+`"~daW/D3/BLCP})I##~dV', 'yK(@qy;D"_f3t7wi[S}<KQJ`epB@1', "?ilxwj^]Az,3W&$iG4b3r&Jl9Sx[xNR", 'uvY$D]7+t"QUli$ie8V', "l7f,JawYg#v", 'SK2<S7"t{;', "CQ_)?/u8TGViEN!+}lscLU__!9`bGXZ)(,4R{QL4j[JWvi]+U*w", "bK(|Yc,11/lB<VD2b[%rHjOb./#tYVqD{y4^9adTd/^Y_*f]%<P;", "JGs{H~k", "D#A|yOuj?ysmAmaI}yO)iskp4G", "?7CL%uk", "%4H3Znw&>K`lS~t_;8yK?/4b[Gw.PbYlm[>{NJ2&,bJW,Yt", 'M)A@y/`b%u{,ai"@2y&9?&#Wra.^rnYIm*5|', "B@8v?l2`z}uQHX~Wsx13kF5m1UP=?mQ2EiJcG4+&V", "vce}28!eLKT|<*SIv36~&u_]ySP", "ell^W,0sd+.Gm&ii(cA|gy/Mn`^", 'dQ?}6eRjzy2a;.5l$4o<l(aw}z^xat?&i;i<4:}t2t4*}/"^)j1', 'H8hTf2"D1K=e_nq]$6U;^,KTfGkM52dE}c$RSP*w3yDdf/!_8xV', ":i$xQ&3M>", "c7BrJa!mSXrd>/|M|)G)zTa+!zqUd^>6`86~!Cm)!bxY?BN4", '"cJrzOF`haz+Nm.lBVELaC#:j?5Sr^X', '45f;a7rL6=kKb({4~[g)9{44."o3JB<i', "n*n)6(QT6#)~G.r_T=%9/E[so}fQ~V", "EK+~V~ApDGwto&m^wXw", 'ux7;wjA&:UzU;~Z]"4b39BC)0X;e37/5E5P;*mjwr#zQatTE|81', "7V7;s{vY+/u=7nt", "X3l^^s5]3XvV]*8<Q8e3CBQbHyFm/X=Wjx.e}u`z>_/d9{gI7k", "7itP=P}]y#", '"K5J}NQjapL@v>F4x;jr17N`=[|(=*Iv', '*UeT~r%yS+;.".`GR3OT)sL+~t8,]2&+iybxIumx)?8?|ERW`+:0Ki1}=SI', "V?<06(j`V", "nQx96e5){_S]y|c+2S0x2svLKt;(<N6v7l<;", "z<}!245:2t~Q4^FD}SCRraQ+j?RGB72Y]lV", "FQa<)[2&v*AG)|HM7lQPg[udI*IY^NliWSE,@4Flh=?Wl(Hi", "l;2r.c:]2z/di(]<QScRgLW]([Er7|3IbvE0G", "ea2|M:xDW*ed./?i", "L%+^QBhM9#lBz&|<y%Mrmm_]o=%*~c!<aiF@6(n1#/@P?Bf]i8N>V}9p?;", "ZxY;)4jMYS?UB~/&+yJ@z73Yru0#u[wMhviPi0b4R", "*j2@!l{z6=@L1", "F%De>7Vez/GCT*!", "@KN>Gn1tmK8}nw@DL%KrVC2LfS:PYVuD]Kr)=F:]I[]<X*F4", 'YTleH72`sK?o}7evZS=3uU=D9#NudV$&98)|E(dj."k~k', "{V_)]s=}%}LdTWV&*`o{PiYjwX=eVc`2ci#MMLq1", "w6^3[~Xt/u4!3:;", "P5WMTBvLj+XMatE+lV*L{u8b$+6B)7fIo=U;,muF^Sa01", '}cr!6Q5B^#vb+(sDHaR;.nLT<"NH^c,_za<;PEs)!', "n%c@:(%!BKkG.XQ+", "G)Jr_a(BT*K,(BkMHIC0$,}1HKz3x*b@*1", "Pv{~0Oga^S[oE:,_}RpRfnw+!", "4KXM3KNbAtl#u[y)(KP0+BUDT=0BTQ.l*+P,8}aTBt", "~I^o4:2Yoa/@rX3+@/g}pFr4kU#~cct", "#KpKG2hMAb;bG[_lI6e}(o}:{_CXOnZ)r#>{6Uk", "C%]3q$q)Vy(,p&oE6RYR", "ISr!c{n!X?Aa+iS&K8N3pP/dJ+%aK(Q+?@H>A", "#q=X?:?Y", "v6BP<s;1", "@XK<P}+w", "5bZpRzT{", "eoq8$5Hp", "ux]Z]&OX", "`NxX", "*x`k&EyyK", "G9.k{BN@K", "@^XS5i/a", "gotXDvAp", "^]z.%5f", "g>q885Zp", ";E8oaW`F", "s~(D19z", "qe1w#OqI", "}BO#BjNm", '"6wV', ":hmYVq80", ".o13r)Q;", "lq2`2yV;", "8Y|@tGng", "IH#R?n.", "4ei|Gis1", 'F?t6D"9']), IK(oK = function() {
      var OO, KO, pO, XO = [function() {
        return globalThis
      }, function() {
        return global
      }, function() {
        return window
      }, function() {
        return new Function("return this")()
      }];
      IK(OO = void 0, KO = []);
      try {
        IK(OO = Object, KO[fK[16]]("".__proto__.constructor.name))
      } catch (VK) {}
      OO: for (pO = fK[0]; pO < XO[fK[4]]; pO++) try {
        var bK;
        for (OO = XO[pO](), bK = fK[0]; bK < KO[fK[4]]; bK++)
          if (typeof OO[KO[bK]] === fK[5]) continue OO;
        return OO
      } catch (VK) {}
      return OO || this
    }() || {}, FK = oK.TextDecoder, VK = oK.Uint8Array, LK = oK.jb, QK = oK.String || String, zp = oK.Array || Array, AK = function() {
      var OO, KO, pO = new zp(fK[72]);
      return IK(OO = QK[fK[13]] || QK.fromCharCode, KO = []),
        function(...XO) {
          for (IK(XO[fK[4]] = fK[1], XO[-fK[10]] = fK[6], XO[fK[9]] = fK[6], XO[fK[8]] = XO[fK[0]][fK[4]], KO[fK[4]] = fK[0]), XO[-fK[7]] = fK[0]; XO[-fK[7]] < XO[fK[8]];) IK(XO[fK[9]] = XO[fK[0]][XO[-fK[7]]++], XO[fK[9]] <= fK[67] ? XO[-fK[10]] = XO[fK[9]] : XO[fK[9]] <= 223 ? XO[-fK[10]] = (XO[fK[9]] & fK[43]) << fK[12] | XO[fK[0]][XO[-fK[7]]++] & fK[11] : XO[fK[9]] <= 239 ? XO[-fK[10]] = (XO[fK[9]] & fK[17]) << fK[15] | (XO[fK[0]][XO[-fK[7]]++] & fK[11]) << fK[12] | XO[fK[0]][XO[-fK[7]]++] & fK[11] : QK[fK[13]] ? XO[-fK[10]] = (XO[fK[9]] & fK[14]) << 18 | (XO[fK[0]][XO[-fK[7]]++] & fK[11]) << fK[15] | (XO[fK[0]][XO[-fK[7]]++] & fK[11]) << fK[12] | XO[fK[0]][XO[-fK[7]]++] & fK[11] : (XO[-fK[10]] = fK[11], XO[-fK[7]] += fK[8]), KO[fK[16]](pO[XO[-fK[10]]] || (pO[XO[-fK[10]]] = OO(XO[-fK[10]]))));
          return KO.join("")
        }
    }()), IK(DK = (...OO) => {
      IK(OO[fK[4]] = fK[1], OO[-fK[41]] = fK[0]);
      for (const KO in OO[fK[0]]) {
        function pO(...OO) {
          IK(OO[fK[4]] = fK[0], OO[fK[40]] = function(...KO) {
            return IK(KO[fK[4]] = fK[32], KO[fK[36]] = [], KO[fK[9]] = KO[fK[0]].length, KO[fK[0]].sort(((OO, KO) => OO - KO)), OO[fK[1]](KO[fK[36]], [], fK[0], KO[fK[9]], KO[fK[0]], KO[fK[1]])), KO[fK[36]]
          }, OO[fK[1]] = function(...KO) {
            if (IK(KO[fK[4]] = fK[12], KO[fK[39]] = fK[55]), !(KO[fK[37]] < fK[0])) {
              if (KO[fK[37]] === fK[0]) return KO[fK[0]].push(KO[fK[1]]);
              for (KO[fK[9]] = KO[fK[32]]; KO[fK[9]] < KO[fK[8]] && !(KO[fK[38]][KO[fK[9]]] > KO[fK[37]]); KO[fK[9]]++) KO[fK[9]] > KO[fK[32]] && KO[fK[38]][KO[fK[9]]] === KO[fK[38]][KO[fK[9]] - fK[1]] || IK(KO[fK[39]] = Array.from(KO[fK[1]]), KO[fK[39]].push(KO[fK[38]][KO[fK[9]]]), OO[fK[1]](KO[fK[0]], KO[fK[39]], KO[fK[9]] + fK[1], KO[fK[8]], KO[fK[38]], KO[fK[37]] - KO[fK[38]][KO[fK[9]]]))
            }
          }, console.log(OO[fK[40]]))
        }
        dK(110) + "E" in NK && pO(), OO[-fK[41]]++
      }
      return OO[-fK[41]]
    }, hK = () => {
      if (XK++ === fK[37]) {
        function OO(...OO) {
          IK(OO[fK[4]] = fK[0], OO[-fK[42]] = function(OO) {
            var KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO = OO.length;
            if (MO < fK[32]) return fK[0];
            if (IK(KO = Math.max(...OO), pO = Math.min(...OO)), KO === pO) return fK[0];
            for (IK(XO = Array(MO - fK[1]).fill(Number.MAX_SAFE_INTEGER), bK = Array(MO - fK[1]).fill(Number.MIN_SAFE_INTEGER), eO = Math.ceil((KO - pO) / (MO - fK[1])), lO = fK[0]), vK = fK[0]; vK < MO; vK++) OO[vK] !== pO && OO[vK] !== KO && IK(lO = Math.floor((OO[vK] - pO) / eO), XO[lO] = Math.min(XO[lO], OO[vK]), bK[lO] = Math.max(bK[lO], OO[vK]));
            for (IK(CO = Number.MIN_SAFE_INTEGER, hO = pO), DO = fK[0]; DO < MO - fK[1]; DO++) XO[DO] === Number.MAX_SAFE_INTEGER && bK[DO] === Number.MIN_SAFE_INTEGER || IK(CO = Math.max(CO, XO[DO] - hO), hO = bK[DO]);
            return CO = Math.max(CO, KO - hO)
          }, console.log(OO[-fK[42]]))
        }
        if (dK(fK[53]) + "Y" in NK && OO(), (0, QO.l)()) {
          function KO(...OO) {
            for (IK(OO[fK[4]] = fK[1], OO[fK[1]] = 'x`{1>;(C2bYs!F?RX^3/r[Ke0MJw~5=BWG]qz,v@kZhL4d#E:STD"*pVuaj+8y9ocfO.6<$I&QPAUH}l7tg%in)m_N|', OO[fK[32]] = "" + (OO[fK[0]] || ""), OO[fK[19]] = OO[fK[32]].length, OO[fK[38]] = [], OO[fK[24]] = fK[0], OO[-fK[43]] = fK[0], OO[fK[35]] = -fK[1]), OO[fK[2]] = fK[0]; OO[fK[2]] < OO[fK[19]]; OO[fK[2]]++)
              if (OO[fK[21]] = OO[fK[1]].indexOf(OO[fK[32]][OO[fK[2]]]), OO[fK[21]] !== -fK[1])
                if (OO[fK[35]] < fK[0]) OO[fK[35]] = OO[fK[21]];
                else {
                  IK(OO[fK[35]] += OO[fK[21]] * fK[23], OO[fK[24]] |= OO[fK[35]] << OO[-fK[43]], OO[-fK[43]] += (OO[fK[35]] & fK[25]) > fK[26] ? fK[27] : fK[28]);
                  do {
                    IK(OO[fK[38]].push(OO[fK[24]] & fK[3]), OO[fK[24]] >>= fK[2], OO[-fK[43]] -= fK[2])
                  } while (OO[-fK[43]] > fK[14]);
                  OO[fK[35]] = -fK[1]
                } return OO[fK[35]] > -fK[1] && OO[fK[38]].push((OO[fK[24]] | OO[fK[35]] << OO[-fK[43]]) & fK[3]), TK(OO[fK[38]])
          }

          function pO(OO) {
            return typeof MK[OO] === fK[5] ? MK[OO] = KO(ap[OO]) : MK[OO]
          }

          function XO(...OO) {
            IK(OO[fK[4]] = fK[0], OO[-fK[49]] = function(...KO) {
              return IK(KO[fK[4]] = fK[1], KO[fK[1]] = []), (KO[fK[0]] === fK[1] || KO[fK[0]] >= fK[38]) && OO[-fK[44]](KO[fK[1]], [], KO[fK[0]], fK[0]), KO[fK[1]]
            }, OO[-fK[44]] = function(...KO) {
              for (KO[fK[4]] = fK[38], KO[-fK[45]] = KO[fK[8]]; KO[-fK[45]] < KO[fK[32]]; KO[-fK[45]]++) {
                if (KO[fK[1]].length !== KO[-fK[45]]) return;
                for (KO[fK[37]] = fK[0]; KO[fK[37]] < KO[fK[32]]; KO[fK[37]]++) OO[fK[32]](KO[fK[1]], [KO[-fK[45]], KO[fK[37]]]) && (IK(KO[fK[1]].push([KO[-fK[45]], KO[fK[37]]]), OO[-fK[44]](KO[fK[0]], KO[fK[1]], KO[fK[32]], KO[-fK[45]] + fK[1])), KO[fK[1]].length === KO[fK[32]] && KO[fK[0]].push(OO[-fK[46]](KO[fK[1]])), KO[fK[1]].pop())
              }
            }, OO[-fK[46]] = function(...OO) {
              for (IK(OO[fK[4]] = fK[1], OO[fK[47]] = [], OO[fK[9]] = OO[fK[0]].length), OO[fK[19]] = fK[0]; OO[fK[19]] < OO[fK[9]]; OO[fK[19]]++)
                for (OO[fK[47]][OO[fK[19]]] = "", OO[fK[29]] = fK[0]; OO[fK[29]] < OO[fK[9]]; OO[fK[29]]++) OO[fK[47]][OO[fK[19]]] += OO[fK[0]][OO[fK[19]]][fK[1]] === OO[fK[29]] ? "Q" : ".";
              return OO[fK[47]]
            }, OO[fK[32]] = function(OO, KO) {
              var pO, XO = OO.length;
              for (pO = fK[0]; pO < XO; pO++) {
                if (OO[pO][fK[0]] === KO[fK[0]] || OO[pO][fK[1]] === KO[fK[1]]) return fK[48];
                if (Math.abs((OO[pO][fK[0]] - KO[fK[0]]) / (OO[pO][fK[1]] - KO[fK[1]])) === fK[1]) return fK[48]
              }
              return fK[71]
            }, console.log(OO[-fK[49]]))
          }
          pO(112) in NK && XO(), (0, MO[fK[24]])("4 ")
        }
        XK = fK[0]
      }
    }), CK = function(OO) {
      function KO(...OO) {
        return OO[fK[4]] = fK[1], typeof MK[OO[fK[0]]] === fK[5] ? MK[OO[fK[0]]] = function(...OO) {
          for (IK(OO[fK[4]] = fK[1], OO[fK[20]] = 'fapKkSTDPhXsbVWoCmgcqtOejRHnZGQEdiB7A`lryIFN;x?69LJ*M.+Y4@"^>[]{w,_:2}(<&1v=u8$|%53!z0)U~/#', OO[fK[9]] = "" + (OO[fK[0]] || ""), OO[fK[19]] = OO[fK[9]].length, OO[fK[29]] = [], OO[fK[51]] = fK[0], OO[fK[52]] = fK[0], OO[fK[14]] = -fK[1]), OO[-fK[50]] = fK[0]; OO[-fK[50]] < OO[fK[19]]; OO[-fK[50]]++)
            if (OO[fK[21]] = OO[fK[20]].indexOf(OO[fK[9]][OO[-fK[50]]]), OO[fK[21]] !== -fK[1])
              if (OO[fK[14]] < fK[0]) OO[fK[14]] = OO[fK[21]];
              else {
                IK(OO[fK[14]] += OO[fK[21]] * fK[23], OO[fK[51]] |= OO[fK[14]] << OO[fK[52]], OO[fK[52]] += (OO[fK[14]] & fK[25]) > fK[26] ? fK[27] : fK[28]);
                do {
                  IK(OO[fK[29]].push(OO[fK[51]] & fK[3]), OO[fK[51]] >>= fK[2], OO[fK[52]] -= fK[2])
                } while (OO[fK[52]] > fK[14]);
                OO[fK[14]] = -fK[1]
              } return OO[fK[14]] > -fK[1] && OO[fK[29]].push((OO[fK[51]] | OO[fK[14]] << OO[fK[52]]) & fK[3]), TK(OO[fK[29]])
        }(ap[OO[fK[0]]]) : MK[OO[fK[0]]]
      }
      if ((arguments[KO(fK[73])] > fK[1] && arguments[fK[1]] !== fK[6] ? arguments[fK[1]] : fK[48]) && (0, cK[fK[34]])(OO)) {
        function bK(...OO) {
          for (IK(OO[fK[4]] = fK[1], OO[fK[1]] = 'LMXfCYS(y0/79<KGp*B,xzFdrk+T;l3=2DO.nIJb_:ReAW^w[%1a]Z58Vcjm)"s$HhgP|voqt~@NUQ}!E?&#`4{u6>i', OO[fK[9]] = "" + (OO[fK[0]] || ""), OO[fK[8]] = OO[fK[9]].length, OO[-fK[27]] = [], OO[fK[53]] = fK[0], OO[fK[34]] = fK[0], OO[fK[14]] = -fK[1]), OO[fK[54]] = fK[0]; OO[fK[54]] < OO[fK[8]]; OO[fK[54]]++)
            if (OO[-fK[8]] = OO[fK[1]].indexOf(OO[fK[9]][OO[fK[54]]]), OO[-fK[8]] !== -fK[1])
              if (OO[fK[14]] < fK[0]) OO[fK[14]] = OO[-fK[8]];
              else {
                IK(OO[fK[14]] += OO[-fK[8]] * fK[23], OO[fK[53]] |= OO[fK[14]] << OO[fK[34]], OO[fK[34]] += (OO[fK[14]] & fK[25]) > fK[26] ? fK[27] : fK[28]);
                do {
                  IK(OO[-fK[27]].push(OO[fK[53]] & fK[3]), OO[fK[53]] >>= fK[2], OO[fK[34]] -= fK[2])
                } while (OO[fK[34]] > fK[14]);
                OO[fK[14]] = -fK[1]
              } return OO[fK[14]] > -fK[1] && OO[-fK[27]].push((OO[fK[53]] | OO[fK[14]] << OO[fK[34]]) & fK[3]), TK(OO[-fK[27]])
        }

        function eO(...OO) {
          return OO[fK[4]] = fK[1], typeof MK[OO[fK[0]]] === fK[5] ? MK[OO[fK[0]]] = bK(ap[OO[fK[0]]]) : MK[OO[fK[0]]]
        }

        function lO(...OO) {
          function KO() {}
          OO[fK[4]] = fK[0], IK(OO[-fK[58]] = function(...OO) {
            for (IK(OO[fK[4]] = fK[32], OO[fK[32]] = fK[0], OO[fK[9]] = fK[0], OO[fK[19]] = new KO(fK[0]), OO[fK[37]] = OO[fK[19]], OO[fK[12]] = OO[fK[0]], OO[-fK[56]] = OO[fK[1]]); OO[fK[12]] !== fK[55] || OO[-fK[56]] !== fK[55];) IK(OO[fK[9]] = (OO[fK[12]] ? OO[fK[12]].val : fK[0]) + (OO[-fK[56]] ? OO[-fK[56]].val : fK[0]) + OO[fK[32]], OO[fK[32]] = Math.floor(OO[fK[9]] / fK[57]), OO[fK[37]].next = new KO(OO[fK[9]] % fK[57]), OO[fK[37]] = OO[fK[37]].next, OO[fK[12]] = OO[fK[12]] ? OO[fK[12]].next : fK[55], OO[-fK[56]] = OO[-fK[56]] ? OO[-fK[56]].next : fK[55]);
            return OO[fK[32]] && (OO[fK[37]].next = new KO(OO[fK[32]])), OO[fK[19]].next
          }, console.log(OO[-fK[58]]))
        }
        return void(eO(114) in NK && lO())
      }
      const pO = Date[KO(115)]() < new Date(KO(fK[39]) + KO(117) + KO(118))[KO(119) + fK[24]](),
        XO = window[KO(120)];
      if (typeof XO !== KO(121) + "on" || OO instanceof XO) {
        function vK(...OO) {
          for (IK(OO[fK[4]] = fK[1], OO[fK[64]] = '&ImtJUKpVc1^u/%6fqnHRYhi)2L;Xbk"PT>[]l,O.?8eryA=NoG{#(B}zd~C0!sDZQ7vM43E<:$wa_W`|gj5+x@9FS*', OO[-fK[63]] = "" + (OO[fK[0]] || ""), OO[fK[8]] = OO[-fK[63]].length, OO[fK[29]] = [], OO[fK[24]] = fK[0], OO[fK[34]] = fK[0], OO[fK[14]] = -fK[1]), OO[fK[2]] = fK[0]; OO[fK[2]] < OO[fK[8]]; OO[fK[2]]++)
            if (OO[fK[65]] = OO[fK[64]].indexOf(OO[-fK[63]][OO[fK[2]]]), OO[fK[65]] !== -fK[1])
              if (OO[fK[14]] < fK[0]) OO[fK[14]] = OO[fK[65]];
              else {
                IK(OO[fK[14]] += OO[fK[65]] * fK[23], OO[fK[24]] |= OO[fK[14]] << OO[fK[34]], OO[fK[34]] += (OO[fK[14]] & fK[25]) > fK[26] ? fK[27] : fK[28]);
                do {
                  IK(OO[fK[29]].push(OO[fK[24]] & fK[3]), OO[fK[24]] >>= fK[2], OO[fK[34]] -= fK[2])
                } while (OO[fK[34]] > fK[14]);
                OO[fK[14]] = -fK[1]
              } return OO[fK[14]] > -fK[1] && OO[fK[29]].push((OO[fK[24]] | OO[fK[14]] << OO[fK[34]]) & fK[3]), TK(OO[fK[29]])
        }

        function CO(...OO) {
          return OO[fK[4]] = fK[1], typeof MK[OO[fK[0]]] === fK[5] ? MK[OO[fK[0]]] = vK(ap[OO[fK[0]]]) : MK[OO[fK[0]]]
        }

        function hO(...OO) {
          IK(OO[fK[4]] = fK[0], OO[fK[66]] = function(OO) {
            var KO, pO, XO, bK, eO = OO.length;
            for (IK(KO = [], pO = fK[0], XO = fK[0], OO.sort(((OO, KO) => OO - KO))), bK = fK[0]; bK < eO; bK++)
              if (!(bK > fK[0] && OO[bK] === OO[bK - fK[1]]))
                for (IK(pO = bK + fK[1], XO = eO - fK[1]); pO < XO;)
                  if (OO[bK] + OO[pO] + OO[XO] < fK[0]) pO++;
                  else if (OO[bK] + OO[pO] + OO[XO] > fK[0]) XO--;
            else {
              for (KO.push([OO[bK], OO[pO], OO[XO]]); pO < XO && OO[pO] === OO[pO + fK[1]];) pO++;
              for (; pO < XO && OO[XO] === OO[XO - fK[1]];) XO--;
              IK(pO++, XO--)
            }
            return KO
          }, console.log(OO[fK[66]]))
        }
        if (CO(124) in NK && hO(), OO[CO(125) + CO(126)] === fK[48]) {
          function DO(OO) {
            var KO, pO, XO, bK, eO, lO, vK;
            for (IK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = fK[0], eO = fK[0], lO = -fK[1]), vK = fK[0]; vK < pO; vK++) {
              var CO = '.0`;w5A#~JWTK8j]9f:MV>4xbZ+B$cm3k&7X*/s}PUDa6eC?IYqo2^h(zHpr{Q[_NESLgF!Gi1ynR)@=d|Ol<tu%,"v'.indexOf(KO[vK]);
              if (CO !== -fK[1])
                if (lO < fK[0]) lO = CO;
                else {
                  IK(lO += CO * fK[23], bK |= lO << eO, eO += (lO & fK[25]) > fK[26] ? fK[27] : fK[28]);
                  do {
                    IK(XO.push(bK & fK[3]), bK >>= fK[2], eO -= fK[2])
                  } while (eO > fK[14]);
                  lO = -fK[1]
                }
            }
            return lO > -fK[1] && XO.push((bK | lO << eO) & fK[3]), TK(XO)
          }

          function aK(...OO) {
            return OO[fK[4]] = fK[1], typeof MK[OO[fK[0]]] === fK[5] ? MK[OO[fK[0]]] = DO(ap[OO[fK[0]]]) : MK[OO[fK[0]]]
          }

          function oO(...OO) {
            function KO(...OO) {
              return OO[fK[4]] = fK[1], typeof MK[OO[fK[0]]] === fK[5] ? MK[OO[fK[0]]] = function(...OO) {
                for (IK(OO[fK[4]] = fK[1], OO[fK[1]] = 'e;gA/J3?n|XiRK(h,%&6{pO.1w7M*#EW[vqf=zU<4QclCY]Vd~y@!bt)mBGSD_x+^:s$"kra0NZ`L8I>j29}u5TFoHP', OO[fK[32]] = "" + (OO[fK[0]] || ""), OO[fK[59]] = OO[fK[32]].length, OO[fK[70]] = [], OO[fK[37]] = fK[0], OO[fK[12]] = fK[0], OO[fK[14]] = -fK[1]), OO[fK[68]] = fK[0]; OO[fK[68]] < OO[fK[59]]; OO[fK[68]]++)
                  if (OO[fK[69]] = OO[fK[1]].indexOf(OO[fK[32]][OO[fK[68]]]), OO[fK[69]] !== -fK[1])
                    if (OO[fK[14]] < fK[0]) OO[fK[14]] = OO[fK[69]];
                    else {
                      IK(OO[fK[14]] += OO[fK[69]] * fK[23], OO[fK[37]] |= OO[fK[14]] << OO[fK[12]], OO[fK[12]] += (OO[fK[14]] & fK[25]) > fK[26] ? fK[27] : fK[28]);
                      do {
                        IK(OO[fK[70]].push(OO[fK[37]] & fK[3]), OO[fK[37]] >>= fK[2], OO[fK[12]] -= fK[2])
                      } while (OO[fK[12]] > fK[14]);
                      OO[fK[14]] = -fK[1]
                    } return OO[fK[14]] > -fK[1] && OO[fK[70]].push((OO[fK[37]] | OO[fK[14]] << OO[fK[12]]) & fK[3]), TK(OO[fK[70]])
              }(ap[OO[fK[0]]]) : MK[OO[fK[0]]]
            }

            function pO(...OO) {
              if (OO[fK[4]] = fK[1], !OO[fK[0]]) return -fK[1];
              const KO = pO(OO[fK[0]].left),
                XO = pO(OO[fK[0]].right),
                bK = Math.abs(KO - XO);
              if (KO === 1 / 0 || XO === 1 / 0 || bK > fK[1]) return 1 / 0;
              return Math.max(KO, XO) + fK[1]
            }
            OO[fK[4]] = fK[0], window[KO(fK[72]) + KO(129) + KO(130) + "_"] = {
              buildCharacterMap: function(...OO) {
                OO[fK[4]] = fK[1];
                const KO = {};
                for (let pO of OO[fK[0]].replace(/[^w]/g, "").toLowerCase()) KO[pO] = KO[pO] + fK[1] || fK[1];
                return KO
              },
              isAnagrams: function(OO, KO) {
                const pO = buildCharMap(OO),
                  XO = buildCharMap(KO);
                for (let bK in pO)
                  if (pO[bK] !== XO[bK]) return fK[48];
                return Object.keys(pO).length !== Object.keys(XO).length ? fK[48] : fK[71]
              },
              isBalanced: function(...OO) {
                return OO[fK[4]] = fK[1], pO(OO[fK[0]]) !== 1 / 0
              },
              getHeightBalanced: pO
            }
          }
          aK(fK[67]) + "P" in NK && oO(), (0, MO[fK[24]])("2 " + (pO ? (new Error)[aK(131)] : ""))
        } else {
          function FO(...OO) {
            for (IK(OO[fK[4]] = fK[1], OO[fK[1]] = '^415u6/vKX;pA<Q("qxFB>9%j=TP{YZELVwis2:CHG)W[0_!@bdIUDO.8NS#k*ltofc`J$3za+e?y|m~7]&g,hMrRn}', OO[fK[32]] = "" + (OO[fK[0]] || ""), OO[fK[19]] = OO[fK[32]].length, OO[-fK[75]] = [], OO[fK[74]] = fK[0], OO[fK[73]] = fK[0], OO[fK[14]] = -fK[1]), OO[fK[2]] = fK[0]; OO[fK[2]] < OO[fK[19]]; OO[fK[2]]++)
              if (OO[fK[69]] = OO[fK[1]].indexOf(OO[fK[32]][OO[fK[2]]]), OO[fK[69]] !== -fK[1])
                if (OO[fK[14]] < fK[0]) OO[fK[14]] = OO[fK[69]];
                else {
                  IK(OO[fK[14]] += OO[fK[69]] * fK[23], OO[fK[74]] |= OO[fK[14]] << OO[fK[73]], OO[fK[73]] += (OO[fK[14]] & fK[25]) > fK[26] ? fK[27] : fK[28]);
                  do {
                    IK(OO[-fK[75]].push(OO[fK[74]] & fK[3]), OO[fK[74]] >>= fK[2], OO[fK[73]] -= fK[2])
                  } while (OO[fK[73]] > fK[14]);
                  OO[fK[14]] = -fK[1]
                } return OO[fK[14]] > -fK[1] && OO[-fK[75]].push((OO[fK[74]] | OO[fK[14]] << OO[fK[73]]) & fK[3]), TK(OO[-fK[75]])
          }

          function VO(...OO) {
            return OO[fK[4]] = fK[1], typeof MK[OO[fK[0]]] === fK[5] ? MK[OO[fK[0]]] = FO(ap[OO[fK[0]]]) : MK[OO[fK[0]]]
          }

          function LO(...OO) {
            function KO() {}
            OO[fK[4]] = fK[0], IK(OO[-fK[39]] = function(...OO) {
              for (IK(OO[fK[4]] = fK[32], OO[-fK[77]] = fK[0], OO[fK[76]] = fK[0], OO[fK[19]] = new KO(fK[0]), OO[-fK[26]] = OO[fK[19]], OO[fK[24]] = OO[fK[0]], OO[fK[14]] = OO[fK[1]]); OO[fK[24]] !== fK[55] || OO[fK[14]] !== fK[55];) IK(OO[fK[76]] = (OO[fK[24]] ? OO[fK[24]].val : fK[0]) + (OO[fK[14]] ? OO[fK[14]].val : fK[0]) + OO[-fK[77]], OO[-fK[77]] = Math.floor(OO[fK[76]] / fK[57]), OO[-fK[26]].next = new KO(OO[fK[76]] % fK[57]), OO[-fK[26]] = OO[-fK[26]].next, OO[fK[24]] = OO[fK[24]] ? OO[fK[24]].next : fK[55], OO[fK[14]] = OO[fK[14]] ? OO[fK[14]].next : fK[55]);
              return OO[-fK[77]] && (OO[-fK[26]].next = new KO(OO[-fK[77]])), OO[fK[19]].next
            }, console.log(OO[-fK[39]]))
          }
          if (VO(132) in NK && LO(), DK(OO) < fK[57]) {
            function QO(...OO) {
              for (IK(OO[fK[4]] = fK[1], OO[fK[20]] = '9W.(XsZtP4z/2J*iy:`1^8%I;O=m!ad0~>B$hclx7<pbG{HDFru,5}@v|?LQ_EAkKqeRj3wUfNY"6CST[VgM&o)]n#+', OO[-fK[78]] = "" + (OO[fK[0]] || ""), OO[fK[19]] = OO[-fK[78]].length, OO[fK[29]] = [], OO[fK[37]] = fK[0], OO[fK[34]] = fK[0], OO[fK[39]] = -fK[1]), OO[fK[2]] = fK[0]; OO[fK[2]] < OO[fK[19]]; OO[fK[2]]++)
                if (OO[fK[69]] = OO[fK[20]].indexOf(OO[-fK[78]][OO[fK[2]]]), OO[fK[69]] !== -fK[1])
                  if (OO[fK[39]] < fK[0]) OO[fK[39]] = OO[fK[69]];
                  else {
                    IK(OO[fK[39]] += OO[fK[69]] * fK[23], OO[fK[37]] |= OO[fK[39]] << OO[fK[34]], OO[fK[34]] += (OO[fK[39]] & fK[25]) > fK[26] ? fK[27] : fK[28]);
                    do {
                      IK(OO[fK[29]].push(OO[fK[37]] & fK[3]), OO[fK[37]] >>= fK[2], OO[fK[34]] -= fK[2])
                    } while (OO[fK[34]] > fK[14]);
                    OO[fK[39]] = -fK[1]
                  } return OO[fK[39]] > -fK[1] && OO[fK[29]].push((OO[fK[37]] | OO[fK[39]] << OO[fK[34]]) & fK[3]), TK(OO[fK[29]])
            }

            function zK(...OO) {
              return OO[fK[4]] = fK[1], typeof MK[OO[fK[0]]] === fK[5] ? MK[OO[fK[0]]] = QO(ap[OO[fK[0]]]) : MK[OO[fK[0]]]
            }(0, MO[fK[24]])("3 " + (pO ? (new Error)[zK(133)] : ""))
          } else hK()
        }
      } else {
        function AO(...OO) {
          for (IK(OO[fK[4]] = fK[1], OO[fK[20]] = 'zFaqyn)(;[Z5*G>Sg7xuJOI%Q8&$P#oK!V]A{2wBC?XEb3W1sN|`}r_m@~,<0eltih./=^LHp+v9D"fMjT4URYd:ck6', OO[fK[32]] = "" + (OO[fK[0]] || ""), OO[fK[59]] = OO[fK[32]].length, OO[fK[38]] = [], OO[fK[37]] = fK[0], OO[-fK[61]] = fK[0], OO[fK[14]] = -fK[1]), OO[fK[18]] = fK[0]; OO[fK[18]] < OO[fK[59]]; OO[fK[18]]++)
            if (OO[fK[60]] = OO[fK[20]].indexOf(OO[fK[32]][OO[fK[18]]]), OO[fK[60]] !== -fK[1])
              if (OO[fK[14]] < fK[0]) OO[fK[14]] = OO[fK[60]];
              else {
                IK(OO[fK[14]] += OO[fK[60]] * fK[23], OO[fK[37]] |= OO[fK[14]] << OO[-fK[61]], OO[-fK[61]] += (OO[fK[14]] & fK[25]) > fK[26] ? fK[27] : fK[28]);
                do {
                  IK(OO[fK[38]].push(OO[fK[37]] & fK[3]), OO[fK[37]] >>= fK[2], OO[-fK[61]] -= fK[2])
                } while (OO[-fK[61]] > fK[14]);
                OO[fK[14]] = -fK[1]
              } return OO[fK[14]] > -fK[1] && OO[fK[38]].push((OO[fK[37]] | OO[fK[14]] << OO[-fK[61]]) & fK[3]), TK(OO[fK[38]])
        }

        function fO(OO) {
          return typeof MK[OO] === fK[5] ? MK[OO] = AO(ap[OO]) : MK[OO]
        }

        function dO(...OO) {
          IK(OO[fK[4]] = fK[0], OO[-fK[62]] = function(...OO) {
            for (IK(OO[fK[4]] = fK[1], OO[fK[20]] = OO[fK[0]].length, OO[fK[32]] = [], OO[fK[19]] = fK[0], OO[fK[29]] = fK[0], OO[fK[0]].sort(((OO, KO) => OO - KO))), OO[fK[37]] = fK[0]; OO[fK[37]] < OO[fK[20]]; OO[fK[37]]++)
              if (!(OO[fK[37]] > fK[0] && OO[fK[0]][OO[fK[37]]] === OO[fK[0]][OO[fK[37]] - fK[1]]))
                for (IK(OO[fK[19]] = OO[fK[37]] + fK[1], OO[fK[29]] = OO[fK[20]] - fK[1]); OO[fK[19]] < OO[fK[29]];)
                  if (OO[fK[0]][OO[fK[37]]] + OO[fK[0]][OO[fK[19]]] + OO[fK[0]][OO[fK[29]]] < fK[0]) OO[fK[19]]++;
                  else if (OO[fK[0]][OO[fK[37]]] + OO[fK[0]][OO[fK[19]]] + OO[fK[0]][OO[fK[29]]] > fK[0]) OO[fK[29]]--;
            else {
              for (OO[fK[32]].push([OO[fK[0]][OO[fK[37]]], OO[fK[0]][OO[fK[19]]], OO[fK[0]][OO[fK[29]]]]); OO[fK[19]] < OO[fK[29]] && OO[fK[0]][OO[fK[19]]] === OO[fK[0]][OO[fK[19]] + fK[1]];) OO[fK[19]]++;
              for (; OO[fK[19]] < OO[fK[29]] && OO[fK[0]][OO[fK[29]]] === OO[fK[0]][OO[fK[29]] - fK[1]];) OO[fK[29]]--;
              IK(OO[fK[19]]++, OO[fK[29]]--)
            }
            return OO[fK[32]]
          }, console.log(OO[-fK[62]]))
        }
        fO(122) in NK && dO(), (0, MO[fK[24]])("5 " + (pO ? (new Error)[fO(fK[54])] : ""))
      }
    }, FO.i.subscribe("customBindingsChanged", (() => {
      gp()
    }));
    let uK = !1,
      EK = !1;
    const jp = () => uK || EK && jK.b.isInGame(),
      YK = OO => {
        jp() && OO.preventDefault()
      };
    FO.i.subscribe("displaymodeFullscreenChange", (OO => {
      wK()
    })), FO.i.subscribe("pointerLockUpdate", (OO => {
      uK = OO, wK(), ip()
    })), FO.i.subscribe("freeCursorUpdate", (OO => {
      EK = OO, wK(), ip()
    }));
    const wK = () => {
        window.removeEventListener("wheel", YK), YO.l && !(0, lO.n)() && (uK || EK) && window.addEventListener("wheel", YK, {
          passive: !1
        })
      },
      ip = () => {
        window.removeEventListener("wheel", rp), (uK || EK) && window.addEventListener("wheel", rp, {
          passive: !1
        })
      },
      rp = OO => {
        !0 === OO.ctrlKey && jp() && OO.preventDefault()
      };

    function PK(OO) {
      FO.i.pl("QTEMouseState", {
        isDown: OO
      })
    }

    function mp(OO) {
      var KO, pO, bK, eO, lO, vK, CO, hO;
      const MO = (0, gK.d)();
      MO.zCO = null !== (KO = function(OO, KO) {
        var pO, XO;
        if (!eK) return null;
        const bK = OO.bloxd;
        KK ??= bK.getMetaInfo("Board").rootId;
        const eO = null !== (pO = null === KO || void 0 === KO ? void 0 : KO.blO) && void 0 !== pO ? pO : null;
        if (!eO || bK.getMetaInfo(eO).rootId !== KK) return null;
        const lO = null !== (XO = null === KO || void 0 === KO ? void 0 : KO.position) && void 0 !== XO ? XO : null;
        if (bK.playerCanChangePos(OO.CpO, lO[0], lO[1], lO[2])) return null;
        const vK = (OO, KO, pO) => {
          const XO = bK.blockDataOwner.getBlockData(OO, KO, pO),
            eO = null === XO || void 0 === XO ? void 0 : XO.persisted.shared.text.split("\n")[0].toLowerCase().trim();
          return wO.singleLineBoardActions.has(eO)
        };
        if (vK(lO[0], lO[1], lO[2])) return null;
        let CO;
        OO.YvO && (CO = [...OO.YvO], OO.geO(CO, CO));
        const hO = (CO ? OO.camera.ebO : 0) + bK.getBlockReach(OO.CpO);
        return OO.XM(CO, OO.wvO, hO, ((KO, pO, XO, eO) => 0 !== KO && ("Board" !== bK.getMetaInfo(KO).rootName || bK.playerCanChangePos(OO.CpO, pO, XO, eO) || vK(pO, XO, eO))))
      }(MO, MO.zCO)) && void 0 !== KO ? KO : MO.zCO;
      const oO = null !== (pO = null === (bK = MO.zCO) || void 0 === bK ? void 0 : bK.position) && void 0 !== pO ? pO : null,
        VO = null !== (eO = MO.wvO) && void 0 !== eO ? eO : MO.camera.YbO(),
        LO = gK.e.localPlayerPickActionHelper.getPickEntityResult(VO),
        QO = null !== (lO = MO.zCO) && void 0 !== lO && lO.blO ? (0, mK.h)(MO.zCO.blO) : "Air",
        zK = OO === aK.b.UpFirePrimary || OO === aK.b.UpFireSecondary,
        AO = zK ? "onPlayerClickUp" : "onPlayerClick",
        fO = zK ? OO === aK.b.UpFireSecondary : OO === aK.b.DownFireSecondary,
        dO = !zK && (0, XO.getWasDoubleClick)();
      FO.i.pl("mouseState", {
        PJ: OO,
        isDown: !zK
      }), (0, XO.sendColyMessage)(DO.ih, {
        PJ: OO,
        nC: dO,
        Iw: oO,
        Cw: LO
      }, !0), (0, gK.b)().client.triggerGameCallback(AO, MO.CpO, fO, null !== (vK = null === oO || void 0 === oO ? void 0 : oO[0]) && void 0 !== vK ? vK : null, null !== (CO = null === oO || void 0 === oO ? void 0 : oO[1]) && void 0 !== CO ? CO : null, null !== (hO = null === oO || void 0 === oO ? void 0 : oO[2]) && void 0 !== hO ? hO : null, QO, LO)
    }
    window.addEventListener("keydown", (OO => {
      ["ArrowUp", "ArrowDown"].includes(OO.key) && OO.preventDefault()
    })), document.addEventListener("keydown", (OO => {
      (0, PO.d)(OO, (() => {
        const OO = (0, gK.d)();
        return (0, rK.I)(OO) || !1 !== OO.JV.canCustomiseChar
      }))
    }))
  },
  37458: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      h: () => lO
    });
    var XO = pO(36826);
    let bK = !1;

    function eO() {
      return bK
    }

    function lO(OO) {
      bK = OO, OO ? XO.i.setMultiplierType("emoteWheel", 0) : XO.i.removeMultiplier("emoteWheel")
    }
  },
  37460: (OO, KO, pO) => {
    function XO(OO) {
      return Boolean(OO.JV.useInventory && OO.JV.useFullInventory && OO.tL.QCO(OO.CpO))
    }
    pO.d(KO, {
      d: () => XO
    })
  },
  37356: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      e: () => bK
    });
    var XO = pO(35959);

    function bK(OO, KO) {
      return {
        replayedClipName: OO,
        replayedClipAgeSeconds: KO
      }
    }

    function eO(OO, KO, pO, bK, eO) {
      const lO = function(OO) {
          if ("object" !== typeof OO || null === OO) return null;
          const {
            replayedClipName: KO,
            replayedClipAgeSeconds: pO
          } = OO;
          return "string" === typeof KO && "number" === typeof pO ? {
            M6: KO,
            f6: pO
          } : null
        }(pO),
        vK = null === lO ? pO : null,
        {
          M6: CO = null,
          f6: hO = 0
        } = null !== lO && void 0 !== lO ? lO : {};
      OO.animateEntity(KO, XO.f.Custom, vK, bK, eO, CO, hO)
    }
  },
  37382: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => FO,
      d: () => DO,
      h: () => oO,
      k: () => aK,
      o: () => VO,
      p: () => MO
    });
    var XO = pO(37390),
      bK = pO(35599),
      eO = pO(2931),
      lO = pO(1558),
      vK = pO(26),
      CO = pO(2231);
    const hO = new XO.d;

    function DO() {
      return hO
    }

    function MO() {
      hO.clear()
    }

    function aK() {
      for (const OO of hO.ids()) {
        const KO = hO.getName(OO);
        void 0 !== KO && lO.c.delete(KO)
      }
      MO(), vK.i.pl("playerRosterChanged", hO.ids())
    }

    function oO(OO, KO) {
      var pO, XO;
      if (hO.has(OO)) return hO.getSetting(OO, KO);
      const bK = (0, CO.d)();
      return null === (pO = bK.vXO[bK.CpO]) || void 0 === pO || null === (XO = pO[OO]) || void 0 === XO ? void 0 : XO[KO]
    }

    function FO(OO) {
      const {
        added: KO,
        removed: pO,
        settingChanges: XO
      } = hO.apply(OO);
      for (const {
          playerId: bK,
          name: eO
        }
        of pO) void 0 === eO || LO(bK) || lO.c.delete(eO);
      for (const {
          playerId: eO,
          settings: lO
        }
        of XO)
        if (LO(eO)) VO(eO, lO);
        else
          for (const OO in lO)(0, bK.n)(eO, OO, lO[OO]);
      (KO.length > 0 || pO.length > 0) && vK.i.pl("playerRosterChanged", hO.ids())
    }

    function VO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : hO.getSettings(OO);
      if (KO) {
        (0, bK.h)(OO);
        for (const pO in KO)(0, bK.e)(OO, pO, KO[pO])
      }
    }

    function LO(OO) {
      return OO === (0, CO.d)().jCO || (0, CO.b)().client.hasEntity(OO)
    }(0, eO.onGameReset)(MO)
  },
  36507: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => gK,
      g: () => TO,
      j: () => IO,
      k: () => yK,
      o: () => uO
    });
    var XO = pO(35624),
      bK = pO(36513),
      eO = pO(266),
      lO = pO.n(eO),
      vK = pO(35069);
    const CO = new XO.WX,
      hO = new XO.WX,
      DO = new XO.WX,
      MO = new XO.WX,
      aK = new XO.WX,
      oO = [0, 0, 0],
      FO = {
        x: 0,
        y: 0
      },
      VO = new XO.WX(1, 0, 0),
      LO = new XO.WX(0, 1, 0),
      QO = XO.Matrix.Identity(),
      zK = new XO.Matrix,
      AO = new XO.Matrix,
      fO = new XO.WX,
      dO = new bK.d(0, 0, 0, 0);

    function TO(OO, KO) {
      var pO, bK;
      const eO = NO(OO, KO);
      if (eO) {
        const OO = eO.x,
          KO = eO.y,
          pO = OO - 50,
          XO = KO - 50;
        return Math.abs(pO) <= vK.e && Math.abs(XO) <= (0, vK.j)() ? {
          x: OO,
          y: KO
        } : jK(pO, XO)
      }
      DO.rvO(KO[0], KO[1], KO[2]),
        function(OO) {
          const KO = OO.Lb.jDO(),
            pO = KO ? XO.Matrix.FromArrayToRef(KO.worldMatrix, 0, AO) : OO.Lb.JKO().activeCamera.getWorldMatrix();
          XO.WX.TransformNormalToRef(VO, pO, MO), MO.normalize(), XO.WX.TransformNormalToRef(LO, pO, aK), aK.normalize()
        }(OO);
      const lO = XO.WX.Dot(DO, MO);
      let CO = -XO.WX.Dot(DO, aK);
      Math.abs(lO) < .001 && Math.abs(CO) < .001 && (CO = -1);
      const hO = null !== (pO = null === (bK = OO.Lb.jDO()) || void 0 === bK ? void 0 : bK.projectionMatrix) && void 0 !== pO ? pO : OO.Lb.JKO().activeCamera.getProjectionMatrix().m;
      return jK(lO * hO[0], CO * hO[5])
    }

    function NO(OO, KO) {
      const pO = OO.Lb.JKO(),
        bK = pO.qb(),
        eO = bK.getRenderWidth(),
        lO = bK.getRenderHeight();
      dO.width = eO, dO.height = lO;
      const vK = OO.Lb.jDO(),
        DO = vK ? fO.rvO(vK.eye[0], vK.eye[1], vK.eye[2]) : OO.Lb.camera.globalPosition;
      CO.rvO(DO.x + 10 * KO[0], DO.y + 10 * KO[1], DO.z + 10 * KO[2]);
      const MO = vK ? XO.Matrix.FromArrayToRef(vK.viewProjectionMatrix, 0, zK) : pO.getTransformMatrix();
      return XO.WX.ProjectToRef(CO, QO, MO, dO, hO), hO.z < 0 || hO.z > 1 ? null : (FO.x = hO.x / eO * 100, FO.y = hO.y / lO * 100, FO)
    }

    function IO(OO, KO) {
      return TO(OO, EO(OO, KO))
    }

    function yK(OO, KO) {
      const pO = NO(OO, EO(OO, KO));
      return pO && {
        x: pO.x,
        y: pO.y
      }
    }

    function gK(OO) {
      var KO, pO;
      return 1 / (null !== (KO = null === (pO = OO.Lb.jDO()) || void 0 === pO ? void 0 : pO.projectionMatrix[0]) && void 0 !== KO ? KO : OO.Lb.JKO().activeCamera.getProjectionMatrix().m[0])
    }

    function uO(OO, KO, pO) {
      const XO = OO.Lb.jDO(),
        bK = XO ? XO.worldMatrix : OO.Lb.JKO().activeCamera.getWorldMatrix().m,
        eO = OO.jp;
      for (let lO = 0; lO < 3; lO++) KO[lO] = bK[12 + lO] + eO[lO], pO[lO] = bK[8 + lO];
      lO().normalize(pO, pO)
    }

    function EO(OO, KO) {
      const pO = OO.jp,
        XO = OO.Lb.jDO(),
        bK = XO ? fO.rvO(XO.eye[0], XO.eye[1], XO.eye[2]) : OO.Lb.camera.globalPosition;
      return oO[0] = KO[0] - pO[0] - bK.x, oO[1] = KO[1] - pO[1] - bK.y, oO[2] = KO[2] - pO[2] - bK.z, lO().normalize(oO, oO), oO
    }

    function jK(OO, KO) {
      return (0, vK.f)(OO, KO, vK.e, (0, vK.j)())
    }
  },
  37396: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => aK
    });
    var XO = pO(171),
      bK = pO(266),
      eO = pO.n(bK),
      lO = pO(35259),
      vK = pO(35264),
      CO = pO(2231);
    const hO = XO.h.uD * XO.h.playerEyeToHeightRatio,
      DO = 250,
      MO = 1.1,
      aK = new class {
        constructor() {
          this.entities = new Map, this.playing = new Map, this.msSinceLastScan = 0
        }
        add(OO, KO) {
          this.entities.set(OO, KO)
        }
        update(OO, KO) {
          const pO = this.entities.get(OO);
          this.entities.set(OO, KO);
          const XO = this.playing.get(OO);
          XO && (pO && pO.soundName === KO.soundName ? (XO.sound.setRelativeVolume(KO.volume), XO.sound.rate(KO.rate), XO.sound.setPannerAttr({
            refDistance: KO.refDistance
          })) : this.stopEntity(OO))
        }
        remove(OO) {
          this.stopEntity(OO), this.entities.delete(OO)
        }
        KK(OO) {
          this.msSinceLastScan += OO, this.msSinceLastScan < DO || (this.msSinceLastScan = 0, this.scan())
        }
        stopEntity(OO) {
          const KO = this.playing.get(OO);
          KO && (KO.sound.stop(), this.playing.delete(OO))
        }
        startEntity(OO, KO, pO) {
          const XO = (0, vK.d)(KO.soundName);
          if (!XO) return console.error(`AudioEntityManager: no sound found for "${KO.soundName}", dropping audio entity ${OO}`), void this.remove(OO);
          const bK = lO.c.play(XO, KO.volume, pO, KO.maxHearDist, KO.refDistance, !0);
          bK.rate(KO.rate), this.playing.set(OO, {
            sound: bK,
            lastPos: eO().clone(pO)
          })
        }
        scan() {
          const OO = (0, CO.d)();
          if (!OO) return;
          const KO = OO.tL.fV(OO.CpO);
          if (KO)
            for (const [pO, XO] of this.entities) {
              if (!OO.tL.gCO(pO, "position")) continue;
              const bK = OO.tL.fV(pO),
                lO = eO().sqrDist(KO, bK),
                vK = this.playing.get(pO);
              if (vK) {
                const OO = XO.maxHearDist * MO;
                lO > OO * OO ? this.stopEntity(pO) : eO().equals(bK, vK.lastPos) || (vK.sound.setPosition([bK[0], bK[1] + hO, bK[2]]), eO().copy(vK.lastPos, bK))
              } else lO <= XO.maxHearDist * XO.maxHearDist && this.startEntity(pO, XO, bK)
            }
        }
      }
  },
  37450: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO,
      h: () => hO
    });
    var XO = pO(171),
      bK = pO(22),
      eO = pO(1056),
      lO = pO(1507),
      vK = pO(1008);
    async function CO(OO, KO) {
      return function(OO) {
        return "object" === typeof OO && null !== OO && OO.code === XO.e.VpnIp.code
      }(KO) && function(OO) {
        return bK.d.get("reactNativeFeatureFlags").appCheck && OO.isLoggedIn() && !OO.hasTriedAppAttestation()
      }(OO) && await async function(OO) {
        try {
          const KO = await (0, lO.d)();
          if (null === KO) return console.warn("The app couldn't get an App Check token"), OO.markAppAttestationTried(), !1;
          const {
            "3PSIDMCPP": pO
          } = await (0, vK.postJsonWithMetricsCookiesAndJsonResponse)(`${eO.clientSideServerUrls.indexUrl}/index/app-attestation`, {
            appCheckToken: KO.token
          }, {
            retries: 0
          }, OO.getMetricsCookies());
          return OO.setAppAttestedAuthJwt(pO), !0
        } catch (KO) {
          return console.error("Failed to attest the app:", KO), !1
        }
      }(OO)
    }
    async function hO(OO, KO) {
      try {
        return await KO()
      } catch (pO) {
        if (!await CO(OO, pO)) throw pO
      }
      return KO()
    }
  },
  37373: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      i: () => bK
    });
    var XO = pO(26);

    function bK(OO) {
      return "refetchCode" === OO || "devDownloadJson" === OO || OO.startsWith("Plugin")
    }

    function eO(OO, KO) {
      "refetchCode" !== OO ? "Plugin|MobAiPlugin|ShowPetUi" !== OO ? Promise.all([pO.e(94), pO.e(95), pO.e(90), pO.e(92), pO.e(195)]).then((() => pO(39755))).then((pO => {
        let {
          runClientGameMessage: XO
        } = pO;
        XO(OO, KO)
      })).catch((KO => {
        console.error(`Game message ${OO} failed`, KO)
      })) : XO.i.pl("showPetUi", KO) : XO.i.pl("refetchCode")
    }
  },
  37359: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO
    });
    var XO = pO(1077),
      bK = pO(1165),
      eO = pO(22),
      lO = pO(1152),
      vK = pO(1163),
      CO = pO(1344),
      hO = pO(35015);

    function DO(OO) {
      let {
        pOO: KO,
        XOO: pO
      } = OO;
      const DO = null !== KO && void 0 !== KO ? KO : (0, vK.b)().gameNameWithVariation;
      (0, XO.H)(DO) && ((0, hO.p)(), (0, lO.qb)((() => {
        console.log("Received matchmaking order from game server to game", KO), (0, eO.j)("inGameReplay"), (0, CO.navigatePreserveSearch)((0, bK.b)(DO, null !== pO && void 0 !== pO ? pO : void 0))
      }), "video_start"))
    }
  },
  37353: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO,
      e: () => lO,
      i: () => vK,
      m: () => hO
    });
    var XO = pO(26),
      bK = pO(1187);
    const eO = new Map;

    function lO(OO, KO) {
      XO.i.pl("newUiRequest", {
        id: OO,
        clientParameters: KO
      }, !0)
    }

    function vK(OO) {
      XO.i.pl("removeUiRequest", OO, !0);
      const KO = eO.get(OO);
      KO && (KO.tearDownNotification(), eO.delete(OO))
    }

    function CO() {
      XO.i.pl("clearUiRequests");
      for (const OO of eO.values()) OO.tearDownNotification();
      eO.clear()
    }

    function hO(OO, KO, pO) {
      const XO = bK.NotificationProvider.showPromptPopup({
        title: KO,
        confirmText: "general:yes",
        cancelText: "general:no",
        unlockPointerKey: "uiRequestPopup"
      });
      eO.set(OO, XO), XO.getResult().then((KO => {
        eO.delete(OO), "notificationTornDown" !== KO && pO(KO)
      }))
    }
  },
  37378: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK,
      e: () => CO,
      g: () => hO
    });
    var XO = pO(1077),
      bK = pO(886),
      eO = pO(35356),
      lO = pO(26);

    function vK(OO) {
      let {
        lobbyName: KO,
        gameNameWithVariation: pO
      } = OO;
      return !(0, XO.J)(KO) || null !== pO && (pO.startsWith("testGym") || (0, bK.k)(pO))
    }

    function CO(OO) {
      return OO.Zm === eO.b.Leave || OO.Zm === eO.b.Cursor
    }

    function hO(OO) {
      lO.i.pl("codeCollab", {
        type: OO.Zm,
        docKey: OO.Wm,
        version: OO.Xs,
        editorCount: OO.lKO,
        peers: OO.vpO,
        updates: OO.Fs,
        playerId: OO.CKO,
        playerName: OO.hKO,
        colour: OO.DKO,
        anchor: OO.Qs,
        head: OO.jH,
        existingCursors: OO.MKO,
        files: OO.apO,
        engineSettings: OO.FKO
      })
    }
  },
  37390: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    class XO {
      constructor() {
        this.members = new Map
      }
      apply(OO) {
        const KO = {
          added: [],
          removed: [],
          settingChanges: []
        };
        for (const XO of OO.W4) {
          let OO = this.members.get(XO.y5);
          if (OO || (OO = {
              name: null,
              settings: {}
            }, this.members.set(XO.y5, OO), KO.added.push(XO.y5)), null !== XO.E1 && (OO.name = XO.E1), null !== XO.Y1 || XO.i5.length > 0) {
            const pO = null === XO.Y1 ? {} : JSON.parse(XO.Y1);
            Object.assign(OO.settings, pO);
            for (const KO of XO.i5) delete OO.settings[KO], pO[KO] = void 0;
            KO.settingChanges.push({
              playerId: XO.y5,
              settings: pO
            })
          }
        }
        for (const XO of OO.t5) {
          const OO = this.members.get(XO);
          var pO;
          if (OO) this.members.delete(XO), KO.removed.push({
            playerId: XO,
            name: null !== (pO = OO.name) && void 0 !== pO ? pO : void 0
          })
        }
        return KO
      }
      has(OO) {
        return this.members.has(OO)
      }
      ids() {
        return [...this.members.keys()]
      }
      getName(OO) {
        var KO, pO;
        return null !== (KO = null === (pO = this.members.get(OO)) || void 0 === pO ? void 0 : pO.name) && void 0 !== KO ? KO : void 0
      }
      getSettings(OO) {
        var KO;
        return null === (KO = this.members.get(OO)) || void 0 === KO ? void 0 : KO.settings
      }
      getSetting(OO, KO) {
        var pO;
        return null === (pO = this.members.get(OO)) || void 0 === pO ? void 0 : pO.settings[KO]
      }
      clear() {
        this.members.clear()
      }
    }
  },
  37419: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO,
      c: () => bK
    });
    const XO = ["description", "label"];

    function bK(OO) {
      const KO = OO.type;
      return {
        type: KO,
        params: OO[KO]
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);