/*! For license information please see vjxd5n.249.699c90fc.chunk.js.LICENSE.txt */
export const id = 249;
export const ids = [249];
export const modules = {
    38634: (OO, KO, pO) => {
        pO.r(KO), pO.d(KO, {
          ActionCodeOperation: () => aK,
          ActionCodeURL: () => tp,
          AuthCredential: () => HK,
          AuthErrorCodes: () => QO,
          EmailAuthCredential: () => GK,
          EmailAuthProvider: () => UK,
          FacebookAuthProvider: () => Xp,
          FactorId: () => CO,
          GithubAuthProvider: () => ep,
          GoogleAuthProvider: () => bX,
          OAuthCredential: () => xp,
          OAuthProvider: () => pp,
          OperationType: () => MO,
          PhoneAuthCredential: () => WK,
          PhoneAuthProvider: () => Kb,
          PhoneMultiFactorGenerator: () => Oe,
          ProviderId: () => hO,
          RecaptchaVerifier: () => xb,
          SAMLAuthProvider: () => vX,
          SignInMethod: () => DO,
          TotpMultiFactorGenerator: () => Ke,
          TotpSecret: () => Xe,
          TwitterAuthProvider: () => Cp,
          applyActionCode: () => wp,
          beforeAuthStateChanged: () => bb,
          browserLocalPersistence: () => AX,
          browserPopupRedirectResolver: () => te,
          browserSessionPersistence: () => dX,
          checkActionCode: () => iX,
          confirmPasswordReset: () => Yp,
          connectAuthEmulator: () => PK,
          createUserWithEmailAndPassword: () => Pp,
          debugErrorMap: () => FO,
          deleteUser: () => hX,
          fetchSignInMethodsForEmail: () => Sp,
          getAdditionalUserInfo: () => OX,
          getAuth: () => Me,
          getIdToken: () => GO,
          getIdTokenResult: () => qK,
          getMultiFactorResolver: () => ab,
          getRedirectResult: () => Nb,
          inMemoryPersistence: () => vp,
          indexedDBLocalPersistence: () => sX,
          initializeAuth: () => rp,
          initializeRecaptchaConfig: () => pX,
          isSignInWithEmailLink: () => Hp,
          linkWithCredential: () => Tp,
          linkWithPhoneNumber: () => tb,
          linkWithPopup: () => Mb,
          linkWithRedirect: () => Tb,
          multiFactor: () => VX,
          onAuthStateChanged: () => eX,
          onIdTokenChanged: () => XX,
          parseActionCodeURL: () => kp,
          prodErrorMap: () => VO,
          reauthenticateWithCredential: () => Np,
          reauthenticateWithPhoneNumber: () => kb,
          reauthenticateWithPopup: () => Db,
          reauthenticateWithRedirect: () => db,
          reload: () => OK,
          sendEmailVerification: () => Jp,
          sendPasswordResetEmail: () => jX,
          sendSignInLinkToEmail: () => sp,
          setPersistence: () => KX,
          signInAnonymously: () => aX,
          signInWithCredential: () => dp,
          signInWithCustomToken: () => Ip,
          signInWithEmailAndPassword: () => mX,
          signInWithEmailLink: () => Rp,
          signInWithPhoneNumber: () => WX,
          signInWithPopup: () => hb,
          signInWithRedirect: () => fb,
          signOut: () => CX,
          unlink: () => Lp,
          updateCurrentUser: () => vb,
          updateEmail: () => Zp,
          updatePassword: () => Gp,
          updatePhoneNumber: () => Ob,
          updateProfile: () => Bp,
          useDeviceLanguage: () => lX,
          verifyBeforeUpdateEmail: () => cX,
          verifyPasswordResetCode: () => rX
        });
        var XO = pO(38622),
          bK = pO(38610);

        function eO(OO, KO) {
          var pO = {};
          for (var XO in OO) Object.prototype.hasOwnProperty.call(OO, XO) && KO.indexOf(XO) < 0 && (pO[XO] = OO[XO]);
          if (null != OO && "function" === typeof Object.getOwnPropertySymbols) {
            var bK = 0;
            for (XO = Object.getOwnPropertySymbols(OO); bK < XO.length; bK++) KO.indexOf(XO[bK]) < 0 && Object.prototype.propertyIsEnumerable.call(OO, XO[bK]) && (pO[XO[bK]] = OO[XO[bK]])
          }
          return pO
        }
        Object.create;
        Object.create;
        "function" === typeof SuppressedError && SuppressedError;
        var lO = pO(38624),
          vK = pO(38613);
        const CO = {
            PHONE: "phone",
            TOTP: "totp"
          },
          hO = {
            FACEBOOK: "facebook.com",
            GITHUB: "github.com",
            GOOGLE: "google.com",
            PASSWORD: "password",
            PHONE: "phone",
            TWITTER: "twitter.com"
          },
          DO = {
            EMAIL_LINK: "emailLink",
            EMAIL_PASSWORD: "password",
            FACEBOOK: "facebook.com",
            GITHUB: "github.com",
            GOOGLE: "google.com",
            PHONE: "phone",
            TWITTER: "twitter.com"
          },
          MO = {
            LINK: "link",
            REAUTHENTICATE: "reauthenticate",
            SIGN_IN: "signIn"
          },
          aK = {
            EMAIL_SIGNIN: "EMAIL_SIGNIN",
            PASSWORD_RESET: "PASSWORD_RESET",
            RECOVER_EMAIL: "RECOVER_EMAIL",
            REVERT_SECOND_FACTOR_ADDITION: "REVERT_SECOND_FACTOR_ADDITION",
            VERIFY_AND_CHANGE_EMAIL: "VERIFY_AND_CHANGE_EMAIL",
            VERIFY_EMAIL: "VERIFY_EMAIL"
          };

        function oO() {
          return {
            "dependent-sdk-initialized-before-auth": "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."
          }
        }
        const FO = function() {
            return {
              "admin-restricted-operation": "This operation is restricted to administrators only.",
              "argument-error": "",
              "app-not-authorized": "This app, identified by the domain where it's hosted, is not authorized to use Firebase Authentication with the provided API key. Review your key configuration in the Google API console.",
              "app-not-installed": "The requested mobile application corresponding to the identifier (Android package name or iOS bundle ID) provided is not installed on this device.",
              "captcha-check-failed": "The reCAPTCHA response token provided is either invalid, expired, already used or the domain associated with it does not match the list of whitelisted domains.",
              "code-expired": "The SMS code has expired. Please re-send the verification code to try again.",
              "cordova-not-ready": "Cordova framework is not ready.",
              "cors-unsupported": "This browser is not supported.",
              "credential-already-in-use": "This credential is already associated with a different user account.",
              "custom-token-mismatch": "The custom token corresponds to a different audience.",
              "requires-recent-login": "This operation is sensitive and requires recent authentication. Log in again before retrying this request.",
              "dependent-sdk-initialized-before-auth": "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK.",
              "dynamic-link-not-activated": "Please activate Dynamic Links in the Firebase Console and agree to the terms and conditions.",
              "email-change-needs-verification": "Multi-factor users must always have a verified email.",
              "email-already-in-use": "The email address is already in use by another account.",
              "emulator-config-failed": 'Auth instance has already been used to make a network call. Auth can no longer be configured to use the emulator. Try calling "connectAuthEmulator()" sooner.',
              "expired-action-code": "The action code has expired.",
              "cancelled-popup-request": "This operation has been cancelled due to another conflicting popup being opened.",
              "internal-error": "An internal AuthError has occurred.",
              "invalid-app-credential": "The phone verification request contains an invalid application verifier. The reCAPTCHA token response is either invalid or expired.",
              "invalid-app-id": "The mobile app identifier is not registed for the current project.",
              "invalid-user-token": "This user's credential isn't valid for this project. This can happen if the user's token has been tampered with, or if the user isn't for the project associated with this API key.",
              "invalid-auth-event": "An internal AuthError has occurred.",
              "invalid-verification-code": "The SMS verification code used to create the phone auth credential is invalid. Please resend the verification code sms and be sure to use the verification code provided by the user.",
              "invalid-continue-uri": "The continue URL provided in the request is invalid.",
              "invalid-cordova-configuration": "The following Cordova plugins must be installed to enable OAuth sign-in: cordova-plugin-buildinfo, cordova-universal-links-plugin, cordova-plugin-browsertab, cordova-plugin-inappbrowser and cordova-plugin-customurlscheme.",
              "invalid-custom-token": "The custom token format is incorrect. Please check the documentation.",
              "invalid-dynamic-link-domain": "The provided dynamic link domain is not configured or authorized for the current project.",
              "invalid-email": "The email address is badly formatted.",
              "invalid-emulator-scheme": "Emulator URL must start with a valid scheme (http:// or https://).",
              "invalid-api-key": "Your API key is invalid, please check you have copied it correctly.",
              "invalid-cert-hash": "The SHA-1 certificate hash provided is invalid.",
              "invalid-credential": "The supplied auth credential is malformed or has expired.",
              "invalid-message-payload": "The email template corresponding to this action contains invalid characters in its message. Please fix by going to the Auth email templates section in the Firebase Console.",
              "invalid-multi-factor-session": "The request does not contain a valid proof of first factor successful sign-in.",
              "invalid-oauth-provider": "EmailAuthProvider is not supported for this operation. This operation only supports OAuth providers.",
              "invalid-oauth-client-id": "The OAuth client ID provided is either invalid or does not match the specified API key.",
              "unauthorized-domain": "This domain is not authorized for OAuth operations for your Firebase project. Edit the list of authorized domains from the Firebase console.",
              "invalid-action-code": "The action code is invalid. This can happen if the code is malformed, expired, or has already been used.",
              "wrong-password": "The password is invalid or the user does not have a password.",
              "invalid-persistence-type": "The specified persistence type is invalid. It can only be local, session or none.",
              "invalid-phone-number": "The format of the phone number provided is incorrect. Please enter the phone number in a format that can be parsed into E.164 format. E.164 phone numbers are written in the format [+][country code][subscriber number including area code].",
              "invalid-provider-id": "The specified provider ID is invalid.",
              "invalid-recipient-email": "The email corresponding to this action failed to send as the provided recipient email address is invalid.",
              "invalid-sender": "The email template corresponding to this action contains an invalid sender email or name. Please fix by going to the Auth email templates section in the Firebase Console.",
              "invalid-verification-id": "The verification ID used to create the phone auth credential is invalid.",
              "invalid-tenant-id": "The Auth instance's tenant ID is invalid.",
              "login-blocked": "Login blocked by user-provided method: {$originalMessage}",
              "missing-android-pkg-name": "An Android Package Name must be provided if the Android App is required to be installed.",
              "auth-domain-config-required": "Be sure to include authDomain when calling firebase.initializeApp(), by following the instructions in the Firebase console.",
              "missing-app-credential": "The phone verification request is missing an application verifier assertion. A reCAPTCHA response token needs to be provided.",
              "missing-verification-code": "The phone auth credential was created with an empty SMS verification code.",
              "missing-continue-uri": "A continue URL must be provided in the request.",
              "missing-iframe-start": "An internal AuthError has occurred.",
              "missing-ios-bundle-id": "An iOS Bundle ID must be provided if an App Store ID is provided.",
              "missing-or-invalid-nonce": "The request does not contain a valid nonce. This can occur if the SHA-256 hash of the provided raw nonce does not match the hashed nonce in the ID token payload.",
              "missing-password": "A non-empty password must be provided",
              "missing-multi-factor-info": "No second factor identifier is provided.",
              "missing-multi-factor-session": "The request is missing proof of first factor successful sign-in.",
              "missing-phone-number": "To send verification codes, provide a phone number for the recipient.",
              "missing-verification-id": "The phone auth credential was created with an empty verification ID.",
              "app-deleted": "This instance of FirebaseApp has been deleted.",
              "multi-factor-info-not-found": "The user does not have a second factor matching the identifier provided.",
              "multi-factor-auth-required": "Proof of ownership of a second factor is required to complete sign-in.",
              "account-exists-with-different-credential": "An account already exists with the same email address but different sign-in credentials. Sign in using a provider associated with this email address.",
              "network-request-failed": "A network AuthError (such as timeout, interrupted connection or unreachable host) has occurred.",
              "no-auth-event": "An internal AuthError has occurred.",
              "no-such-provider": "User was not linked to an account with the given provider.",
              "null-user": "A null user object was provided as the argument for an operation which requires a non-null user object.",
              "operation-not-allowed": "The given sign-in provider is disabled for this Firebase project. Enable it in the Firebase console, under the sign-in method tab of the Auth section.",
              "operation-not-supported-in-this-environment": 'This operation is not supported in the environment this application is running on. "location.protocol" must be http, https or chrome-extension and web storage must be enabled.',
              "popup-blocked": "Unable to establish a connection with the popup. It may have been blocked by the browser.",
              "popup-closed-by-user": "The popup has been closed by the user before finalizing the operation.",
              "provider-already-linked": "User can only be linked to one identity for the given provider.",
              "quota-exceeded": "The project's quota for this operation has been exceeded.",
              "redirect-cancelled-by-user": "The redirect operation has been cancelled by the user before finalizing.",
              "redirect-operation-pending": "A redirect sign-in operation is already pending.",
              "rejected-credential": "The request contains malformed or mismatching credentials.",
              "second-factor-already-in-use": "The second factor is already enrolled on this account.",
              "maximum-second-factor-count-exceeded": "The maximum allowed number of second factors on a user has been exceeded.",
              "tenant-id-mismatch": "The provided tenant ID does not match the Auth instance's tenant ID",
              timeout: "The operation has timed out.",
              "user-token-expired": "The user's credential is no longer valid. The user must sign in again.",
              "too-many-requests": "We have blocked all requests from this device due to unusual activity. Try again later.",
              "unauthorized-continue-uri": "The domain of the continue URL is not whitelisted.  Please whitelist the domain in the Firebase console.",
              "unsupported-first-factor": "Enrolling a second factor or signing in with a multi-factor account requires sign-in with a supported first factor.",
              "unsupported-persistence-type": "The current environment does not support the specified persistence type.",
              "unsupported-tenant-operation": "This operation is not supported in a multi-tenant context.",
              "unverified-email": "The operation requires a verified email.",
              "user-cancelled": "The user did not grant your application the permissions it requested.",
              "user-not-found": "There is no user record corresponding to this identifier. The user may have been deleted.",
              "user-disabled": "The user account has been disabled by an administrator.",
              "user-mismatch": "The supplied credentials do not correspond to the previously signed in user.",
              "user-signed-out": "",
              "weak-password": "The password must be 6 characters long or more.",
              "web-storage-unsupported": "This browser is not supported or 3rd party cookies and data may be disabled.",
              "already-initialized": "initializeAuth() has already been called with different options. To avoid this error, call initializeAuth() with the same options as when it was originally called, or call getAuth() to return the already initialized instance.",
              "missing-recaptcha-token": "The reCAPTCHA token is missing when sending request to the backend.",
              "invalid-recaptcha-token": "The reCAPTCHA token is invalid when sending request to the backend.",
              "invalid-recaptcha-action": "The reCAPTCHA action is invalid when sending request to the backend.",
              "recaptcha-not-enabled": "reCAPTCHA Enterprise integration is not enabled for this project.",
              "missing-client-type": "The reCAPTCHA client type is missing when sending request to the backend.",
              "missing-recaptcha-version": "The reCAPTCHA version is missing when sending request to the backend.",
              "invalid-req-type": "Invalid request parameters.",
              "invalid-recaptcha-version": "The reCAPTCHA version is invalid when sending request to the backend."
            }
          },
          VO = oO,
          LO = new XO.h("auth", "Firebase", {
            "dependent-sdk-initialized-before-auth": "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."
          }),
          QO = {
            ADMIN_ONLY_OPERATION: "auth/admin-restricted-operation",
            ARGUMENT_ERROR: "auth/argument-error",
            APP_NOT_AUTHORIZED: "auth/app-not-authorized",
            APP_NOT_INSTALLED: "auth/app-not-installed",
            CAPTCHA_CHECK_FAILED: "auth/captcha-check-failed",
            CODE_EXPIRED: "auth/code-expired",
            CORDOVA_NOT_READY: "auth/cordova-not-ready",
            CORS_UNSUPPORTED: "auth/cors-unsupported",
            CREDENTIAL_ALREADY_IN_USE: "auth/credential-already-in-use",
            CREDENTIAL_MISMATCH: "auth/custom-token-mismatch",
            CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "auth/requires-recent-login",
            DEPENDENT_SDK_INIT_BEFORE_AUTH: "auth/dependent-sdk-initialized-before-auth",
            DYNAMIC_LINK_NOT_ACTIVATED: "auth/dynamic-link-not-activated",
            EMAIL_CHANGE_NEEDS_VERIFICATION: "auth/email-change-needs-verification",
            EMAIL_EXISTS: "auth/email-already-in-use",
            EMULATOR_CONFIG_FAILED: "auth/emulator-config-failed",
            EXPIRED_OOB_CODE: "auth/expired-action-code",
            EXPIRED_POPUP_REQUEST: "auth/cancelled-popup-request",
            INTERNAL_ERROR: "auth/internal-error",
            INVALID_API_KEY: "auth/invalid-api-key",
            INVALID_APP_CREDENTIAL: "auth/invalid-app-credential",
            INVALID_APP_ID: "auth/invalid-app-id",
            INVALID_AUTH: "auth/invalid-user-token",
            INVALID_AUTH_EVENT: "auth/invalid-auth-event",
            INVALID_CERT_HASH: "auth/invalid-cert-hash",
            INVALID_CODE: "auth/invalid-verification-code",
            INVALID_CONTINUE_URI: "auth/invalid-continue-uri",
            INVALID_CORDOVA_CONFIGURATION: "auth/invalid-cordova-configuration",
            INVALID_CUSTOM_TOKEN: "auth/invalid-custom-token",
            INVALID_DYNAMIC_LINK_DOMAIN: "auth/invalid-dynamic-link-domain",
            INVALID_EMAIL: "auth/invalid-email",
            INVALID_EMULATOR_SCHEME: "auth/invalid-emulator-scheme",
            INVALID_IDP_RESPONSE: "auth/invalid-credential",
            INVALID_MESSAGE_PAYLOAD: "auth/invalid-message-payload",
            INVALID_MFA_SESSION: "auth/invalid-multi-factor-session",
            INVALID_OAUTH_CLIENT_ID: "auth/invalid-oauth-client-id",
            INVALID_OAUTH_PROVIDER: "auth/invalid-oauth-provider",
            INVALID_OOB_CODE: "auth/invalid-action-code",
            INVALID_ORIGIN: "auth/unauthorized-domain",
            INVALID_PASSWORD: "auth/wrong-password",
            INVALID_PERSISTENCE: "auth/invalid-persistence-type",
            INVALID_PHONE_NUMBER: "auth/invalid-phone-number",
            INVALID_PROVIDER_ID: "auth/invalid-provider-id",
            INVALID_RECIPIENT_EMAIL: "auth/invalid-recipient-email",
            INVALID_SENDER: "auth/invalid-sender",
            INVALID_SESSION_INFO: "auth/invalid-verification-id",
            INVALID_TENANT_ID: "auth/invalid-tenant-id",
            MFA_INFO_NOT_FOUND: "auth/multi-factor-info-not-found",
            MFA_REQUIRED: "auth/multi-factor-auth-required",
            MISSING_ANDROID_PACKAGE_NAME: "auth/missing-android-pkg-name",
            MISSING_APP_CREDENTIAL: "auth/missing-app-credential",
            MISSING_AUTH_DOMAIN: "auth/auth-domain-config-required",
            MISSING_CODE: "auth/missing-verification-code",
            MISSING_CONTINUE_URI: "auth/missing-continue-uri",
            MISSING_IFRAME_START: "auth/missing-iframe-start",
            MISSING_IOS_BUNDLE_ID: "auth/missing-ios-bundle-id",
            MISSING_OR_INVALID_NONCE: "auth/missing-or-invalid-nonce",
            MISSING_MFA_INFO: "auth/missing-multi-factor-info",
            MISSING_MFA_SESSION: "auth/missing-multi-factor-session",
            MISSING_PHONE_NUMBER: "auth/missing-phone-number",
            MISSING_SESSION_INFO: "auth/missing-verification-id",
            MODULE_DESTROYED: "auth/app-deleted",
            NEED_CONFIRMATION: "auth/account-exists-with-different-credential",
            NETWORK_REQUEST_FAILED: "auth/network-request-failed",
            NULL_USER: "auth/null-user",
            NO_AUTH_EVENT: "auth/no-auth-event",
            NO_SUCH_PROVIDER: "auth/no-such-provider",
            OPERATION_NOT_ALLOWED: "auth/operation-not-allowed",
            OPERATION_NOT_SUPPORTED: "auth/operation-not-supported-in-this-environment",
            POPUP_BLOCKED: "auth/popup-blocked",
            POPUP_CLOSED_BY_USER: "auth/popup-closed-by-user",
            PROVIDER_ALREADY_LINKED: "auth/provider-already-linked",
            QUOTA_EXCEEDED: "auth/quota-exceeded",
            REDIRECT_CANCELLED_BY_USER: "auth/redirect-cancelled-by-user",
            REDIRECT_OPERATION_PENDING: "auth/redirect-operation-pending",
            REJECTED_CREDENTIAL: "auth/rejected-credential",
            SECOND_FACTOR_ALREADY_ENROLLED: "auth/second-factor-already-in-use",
            SECOND_FACTOR_LIMIT_EXCEEDED: "auth/maximum-second-factor-count-exceeded",
            TENANT_ID_MISMATCH: "auth/tenant-id-mismatch",
            TIMEOUT: "auth/timeout",
            TOKEN_EXPIRED: "auth/user-token-expired",
            TOO_MANY_ATTEMPTS_TRY_LATER: "auth/too-many-requests",
            UNAUTHORIZED_DOMAIN: "auth/unauthorized-continue-uri",
            UNSUPPORTED_FIRST_FACTOR: "auth/unsupported-first-factor",
            UNSUPPORTED_PERSISTENCE: "auth/unsupported-persistence-type",
            UNSUPPORTED_TENANT_OPERATION: "auth/unsupported-tenant-operation",
            UNVERIFIED_EMAIL: "auth/unverified-email",
            USER_CANCELLED: "auth/user-cancelled",
            USER_DELETED: "auth/user-not-found",
            USER_DISABLED: "auth/user-disabled",
            USER_MISMATCH: "auth/user-mismatch",
            USER_SIGNED_OUT: "auth/user-signed-out",
            WEAK_PASSWORD: "auth/weak-password",
            WEB_STORAGE_UNSUPPORTED: "auth/web-storage-unsupported",
            ALREADY_INITIALIZED: "auth/already-initialized",
            RECAPTCHA_NOT_ENABLED: "auth/recaptcha-not-enabled",
            MISSING_RECAPTCHA_TOKEN: "auth/missing-recaptcha-token",
            INVALID_RECAPTCHA_TOKEN: "auth/invalid-recaptcha-token",
            INVALID_RECAPTCHA_ACTION: "auth/invalid-recaptcha-action",
            MISSING_CLIENT_TYPE: "auth/missing-client-type",
            MISSING_RECAPTCHA_VERSION: "auth/missing-recaptcha-version",
            INVALID_RECAPTCHA_VERSION: "auth/invalid-recaptcha-version",
            INVALID_REQ_TYPE: "auth/invalid-req-type"
          },
          zK = new lO.e("@firebase/auth");

        function AO(OO) {
          if (zK.logLevel <= lO.d.ERROR) {
            for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
            zK.error(`Auth (${bK.g}): ${OO}`, ...pO)
          }
        }

        function fO(OO) {
          for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
          throw IO(OO, ...pO)
        }

        function dO(OO) {
          for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
          return IO(OO, ...pO)
        }

        function TO(OO, KO, pO) {
          const bK = Object.assign(Object.assign({}, VO()), {
            [KO]: pO
          });
          return new XO.h("auth", "Firebase", bK).create(KO, {
            appName: OO.name
          })
        }

        function NO(OO, KO, pO) {
          if (!(KO instanceof pO)) throw pO.name !== KO.constructor.name && fO(OO, "argument-error"), TO(OO, "argument-error", `Type of ${KO.constructor.name} does not match expected instance.Did you pass a reference from a different Auth SDK?`)
        }

        function IO(OO) {
          for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
          if ("string" !== typeof OO) {
            const KO = pO[0],
              XO = [...pO.slice(1)];
            return XO[0] && (XO[0].appName = OO.name), OO._errorFactory.create(KO, ...XO)
          }
          return LO.create(OO, ...pO)
        }

        function yK(OO, KO) {
          if (!OO) {
            for (var pO = arguments.length, XO = new Array(pO > 2 ? pO - 2 : 0), bK = 2; bK < pO; bK++) XO[bK - 2] = arguments[bK];
            throw IO(KO, ...XO)
          }
        }

        function gK(OO) {
          const KO = "INTERNAL ASSERTION FAILED: " + OO;
          throw AO(KO), new Error(KO)
        }

        function uO(OO, KO) {
          OO || gK(KO)
        }

        function EO() {
          var OO;
          return "undefined" !== typeof self && (null === (OO = self.location) || void 0 === OO ? void 0 : OO.href) || ""
        }

        function jK() {
          return "http:" === YO() || "https:" === YO()
        }

        function YO() {
          var OO;
          return "undefined" !== typeof self && (null === (OO = self.location) || void 0 === OO ? void 0 : OO.protocol) || null
        }
        class wO {
          constructor(OO, KO) {
            this.shortDelay = OO, this.longDelay = KO, uO(KO > OO, "Short delay should be less than long delay!"), this.isMobile = (0, XO.$)() || (0, XO.ab)()
          }
          get() {
            return "undefined" !== typeof navigator && navigator && "onLine" in navigator && "boolean" === typeof navigator.onLine && (jK() || (0, XO.Q)() || "connection" in navigator) && !navigator.onLine ? Math.min(5e3, this.shortDelay) : this.isMobile ? this.longDelay : this.shortDelay
          }
        }

        function iK(OO, KO) {
          uO(OO.emulator, "Emulator should always be set here");
          const {
            url: pO
          } = OO.emulator;
          return KO ? `${pO}${KO.startsWith("/")?KO.slice(1):KO}` : pO
        }
        class rK {
          static initialize(OO, KO, pO) {
            this.fetchImpl = OO, KO && (this.headersImpl = KO), pO && (this.responseImpl = pO)
          }
          static fetch() {
            return this.fetchImpl ? this.fetchImpl : "undefined" !== typeof self && "fetch" in self ? self.fetch : void gK("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")
          }
          static headers() {
            return this.headersImpl ? this.headersImpl : "undefined" !== typeof self && "Headers" in self ? self.Headers : void gK("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")
          }
          static response() {
            return this.responseImpl ? this.responseImpl : "undefined" !== typeof self && "Response" in self ? self.Response : void gK("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")
          }
        }
        const PO = {
            CREDENTIAL_MISMATCH: "custom-token-mismatch",
            MISSING_CUSTOM_TOKEN: "internal-error",
            INVALID_IDENTIFIER: "invalid-email",
            MISSING_CONTINUE_URI: "internal-error",
            INVALID_PASSWORD: "wrong-password",
            MISSING_PASSWORD: "missing-password",
            EMAIL_EXISTS: "email-already-in-use",
            PASSWORD_LOGIN_DISABLED: "operation-not-allowed",
            INVALID_IDP_RESPONSE: "invalid-credential",
            INVALID_PENDING_TOKEN: "invalid-credential",
            FEDERATED_USER_ID_ALREADY_LINKED: "credential-already-in-use",
            MISSING_REQ_TYPE: "internal-error",
            EMAIL_NOT_FOUND: "user-not-found",
            RESET_PASSWORD_EXCEED_LIMIT: "too-many-requests",
            EXPIRED_OOB_CODE: "expired-action-code",
            INVALID_OOB_CODE: "invalid-action-code",
            MISSING_OOB_CODE: "internal-error",
            CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "requires-recent-login",
            INVALID_ID_TOKEN: "invalid-user-token",
            TOKEN_EXPIRED: "user-token-expired",
            USER_NOT_FOUND: "user-token-expired",
            TOO_MANY_ATTEMPTS_TRY_LATER: "too-many-requests",
            INVALID_CODE: "invalid-verification-code",
            INVALID_SESSION_INFO: "invalid-verification-id",
            INVALID_TEMPORARY_PROOF: "invalid-credential",
            MISSING_SESSION_INFO: "missing-verification-id",
            SESSION_EXPIRED: "code-expired",
            MISSING_ANDROID_PACKAGE_NAME: "missing-android-pkg-name",
            UNAUTHORIZED_DOMAIN: "unauthorized-continue-uri",
            INVALID_OAUTH_CLIENT_ID: "invalid-oauth-client-id",
            ADMIN_ONLY_OPERATION: "admin-restricted-operation",
            INVALID_MFA_PENDING_CREDENTIAL: "invalid-multi-factor-session",
            MFA_ENROLLMENT_NOT_FOUND: "multi-factor-info-not-found",
            MISSING_MFA_ENROLLMENT_ID: "missing-multi-factor-info",
            MISSING_MFA_PENDING_CREDENTIAL: "missing-multi-factor-session",
            SECOND_FACTOR_EXISTS: "second-factor-already-in-use",
            SECOND_FACTOR_LIMIT_EXCEEDED: "maximum-second-factor-count-exceeded",
            BLOCKING_FUNCTION_ERROR_RESPONSE: "internal-error",
            RECAPTCHA_NOT_ENABLED: "recaptcha-not-enabled",
            MISSING_RECAPTCHA_TOKEN: "missing-recaptcha-token",
            INVALID_RECAPTCHA_TOKEN: "invalid-recaptcha-token",
            INVALID_RECAPTCHA_ACTION: "invalid-recaptcha-action",
            MISSING_CLIENT_TYPE: "missing-client-type",
            MISSING_RECAPTCHA_VERSION: "missing-recaptcha-version",
            INVALID_RECAPTCHA_VERSION: "invalid-recaptcha-version",
            INVALID_REQ_TYPE: "invalid-req-type"
          },
          mK = new wO(3e4, 6e4);

        function sO(OO, KO) {
          return OO.tenantId && !KO.tenantId ? Object.assign(Object.assign({}, KO), {
            tenantId: OO.tenantId
          }) : KO
        }
        async function HO(OO, KO, pO, bK) {
          return RO(OO, arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {}, (async () => {
            let eO = {},
              lO = {};
            bK && ("GET" === KO ? lO = bK : eO = {
              body: JSON.stringify(bK)
            });
            const vK = (0, XO.gb)(Object.assign({
                key: OO.config.apiKey
              }, lO)).slice(1),
              CO = await OO._getAdditionalHeaders();
            return CO["Content-Type"] = "application/json", OO.languageCode && (CO["X-Firebase-Locale"] = OO.languageCode), rK.fetch()(JO(OO, OO.config.apiHost, pO, vK), Object.assign({
              method: KO,
              headers: CO,
              referrerPolicy: "no-referrer"
            }, eO))
          }))
        }
        async function RO(OO, KO, pO) {
          OO._canInitEmulator = !1;
          const bK = Object.assign(Object.assign({}, PO), KO);
          try {
            const KO = new cK(OO),
              XO = await Promise.race([pO(), KO.promise]);
            KO.clearNetworkTimeout();
            const eO = await XO.json();
            if ("needConfirmation" in eO) throw BO(OO, "account-exists-with-different-credential", eO);
            if (XO.ok && !("errorMessage" in eO)) return eO;
            {
              const KO = XO.ok ? eO.errorMessage : eO.error.message,
                [pO, lO] = KO.split(" : ");
              if ("FEDERATED_USER_ID_ALREADY_LINKED" === pO) throw BO(OO, "credential-already-in-use", eO);
              if ("EMAIL_EXISTS" === pO) throw BO(OO, "email-already-in-use", eO);
              if ("USER_DISABLED" === pO) throw BO(OO, "user-disabled", eO);
              const vK = bK[pO] || pO.toLowerCase().replace(/[_\s]+/g, "-");
              if (lO) throw TO(OO, vK, lO);
              fO(OO, vK)
            }
          } catch (eO) {
            if (eO instanceof XO.k) throw eO;
            fO(OO, "network-request-failed", {
              message: String(eO)
            })
          }
        }
        async function SO(OO, KO, pO, XO) {
          let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
          const eO = await HO(OO, KO, pO, XO, bK);
          return "mfaPendingCredential" in eO && fO(OO, "multi-factor-auth-required", {
            _serverResponse: eO
          }), eO
        }

        function JO(OO, KO, pO, XO) {
          const bK = `${KO}${pO}?${XO}`;
          return OO.config.emulator ? iK(OO.config, bK) : `${OO.config.apiScheme}://${bK}`
        }
        class cK {
          constructor(OO) {
            this.auth = OO, this.timer = null, this.promise = new Promise(((OO, KO) => {
              this.timer = setTimeout((() => KO(dO(this.auth, "network-request-failed"))), mK.get())
            }))
          }
          clearNetworkTimeout() {
            clearTimeout(this.timer)
          }
        }

        function BO(OO, KO, pO) {
          const XO = {
            appName: OO.name
          };
          pO.email && (XO.email = pO.email), pO.phoneNumber && (XO.phoneNumber = pO.phoneNumber);
          const bK = dO(OO, KO, XO);
          return bK.customData._tokenResponse = pO, bK
        }

        function ZO(OO) {
          if (OO) try {
            const KO = new Date(Number(OO));
            if (!isNaN(KO.getTime())) return KO.toUTCString()
          } catch (KO) {}
        }

        function GO(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          return (0, XO.N)(OO).getIdToken(KO)
        }
        async function qK(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          const pO = (0, XO.N)(OO),
            bK = await pO.getIdToken(KO),
            eO = nO(bK);
          yK(eO && eO.exp && eO.auth_time && eO.iat, pO.auth, "internal-error");
          const lO = "object" === typeof eO.firebase ? eO.firebase : void 0,
            vK = null === lO || void 0 === lO ? void 0 : lO.sign_in_provider;
          return {
            claims: eO,
            token: bK,
            authTime: ZO(xK(eO.auth_time)),
            issuedAtTime: ZO(xK(eO.iat)),
            expirationTime: ZO(xK(eO.exp)),
            signInProvider: vK || null,
            signInSecondFactor: (null === lO || void 0 === lO ? void 0 : lO.sign_in_second_factor) || null
          }
        }

        function xK(OO) {
          return 1e3 * Number(OO)
        }

        function nO(OO) {
          const [KO, pO, bK] = OO.split(".");
          if (void 0 === KO || void 0 === pO || void 0 === bK) return AO("JWT malformed, contained fewer than 3 sections"), null;
          try {
            const OO = (0, XO.p)(pO);
            return OO ? JSON.parse(OO) : (AO("Failed to decode base64 JWT payload"), null)
          } catch (eO) {
            return AO("Caught error parsing JWT payload as JSON", null === eO || void 0 === eO ? void 0 : eO.toString()), null
          }
        }
        async function WO(OO, KO) {
          if (arguments.length > 2 && void 0 !== arguments[2] && arguments[2]) return KO;
          try {
            return await KO
          } catch (pO) {
            throw pO instanceof XO.k && function(OO) {
              let {
                code: KO
              } = OO;
              return "auth/user-disabled" === KO || "auth/user-token-expired" === KO
            }(pO) && OO.auth.currentUser === OO && await OO.auth.signOut(), pO
          }
        }
        class tK {
          constructor(OO) {
            this.user = OO, this.isRunning = !1, this.timerId = null, this.errorBackoff = 3e4
          }
          _start() {
            this.isRunning || (this.isRunning = !0, this.schedule())
          }
          _stop() {
            this.isRunning && (this.isRunning = !1, null !== this.timerId && clearTimeout(this.timerId))
          }
          getInterval(OO) {
            var KO;
            if (OO) {
              const OO = this.errorBackoff;
              return this.errorBackoff = Math.min(2 * this.errorBackoff, 96e4), OO
            } {
              this.errorBackoff = 3e4;
              const OO = (null !== (KO = this.user.stsTokenManager.expirationTime) && void 0 !== KO ? KO : 0) - Date.now() - 3e5;
              return Math.max(0, OO)
            }
          }
          schedule() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (!this.isRunning) return;
            const KO = this.getInterval(OO);
            this.timerId = setTimeout((async () => {
              await this.iteration()
            }), KO)
          }
          async iteration() {
            try {
              await this.user.getIdToken(!0)
            } catch (OO) {
              return void("auth/network-request-failed" === (null === OO || void 0 === OO ? void 0 : OO.code) && this.schedule(!0))
            }
            this.schedule()
          }
        }
        class kK {
          constructor(OO, KO) {
            this.createdAt = OO, this.lastLoginAt = KO, this._initializeTime()
          }
          _initializeTime() {
            this.lastSignInTime = ZO(this.lastLoginAt), this.creationTime = ZO(this.createdAt)
          }
          _copy(OO) {
            this.createdAt = OO.createdAt, this.lastLoginAt = OO.lastLoginAt, this._initializeTime()
          }
          toJSON() {
            return {
              createdAt: this.createdAt,
              lastLoginAt: this.lastLoginAt
            }
          }
        }
        async function UO(OO) {
          var KO;
          const pO = OO.auth,
            XO = await OO.getIdToken(),
            bK = await WO(OO, async function(OO, KO) {
              return HO(OO, "POST", "/v1/accounts:lookup", KO)
            }(pO, {
              idToken: XO
            }));
          yK(null === bK || void 0 === bK ? void 0 : bK.users.length, pO, "internal-error");
          const lO = bK.users[0];
          OO._notifyReloadListener(lO);
          const vK = (null === (KO = lO.providerUserInfo) || void 0 === KO ? void 0 : KO.length) ? lO.providerUserInfo.map((OO => {
            var {
              providerId: KO
            } = OO, pO = eO(OO, ["providerId"]);
            return {
              providerId: KO,
              uid: pO.rawId || "",
              displayName: pO.displayName || null,
              email: pO.email || null,
              phoneNumber: pO.phoneNumber || null,
              photoURL: pO.photoUrl || null
            }
          })) : [];
          const CO = (hO = OO.providerData, DO = vK, [...hO.filter((OO => !DO.some((KO => KO.providerId === OO.providerId)))), ...DO]);
          var hO, DO;
          const MO = OO.isAnonymous,
            aK = !(OO.email && lO.passwordHash) && !(null === CO || void 0 === CO ? void 0 : CO.length),
            oO = !!MO && aK,
            FO = {
              uid: lO.localId,
              displayName: lO.displayName || null,
              photoURL: lO.photoUrl || null,
              email: lO.email || null,
              emailVerified: lO.emailVerified || !1,
              phoneNumber: lO.phoneNumber || null,
              tenantId: lO.tenantId || null,
              providerData: CO,
              metadata: new kK(lO.createdAt, lO.lastLoginAt),
              isAnonymous: oO
            };
          Object.assign(OO, FO)
        }
        async function OK(OO) {
          const KO = (0, XO.N)(OO);
          await UO(KO), await KO.auth._persistUserIfCurrent(KO), KO.auth._notifyListenersIfCurrent(KO)
        }
        class KK {
          constructor() {
            this.refreshToken = null, this.accessToken = null, this.expirationTime = null
          }
          get isExpired() {
            return !this.expirationTime || Date.now() > this.expirationTime - 3e4
          }
          updateFromServerResponse(OO) {
            yK(OO.idToken, "internal-error"), yK("undefined" !== typeof OO.idToken, "internal-error"), yK("undefined" !== typeof OO.refreshToken, "internal-error");
            const KO = "expiresIn" in OO && "undefined" !== typeof OO.expiresIn ? Number(OO.expiresIn) : function(OO) {
              const KO = nO(OO);
              return yK(KO, "internal-error"), yK("undefined" !== typeof KO.exp, "internal-error"), yK("undefined" !== typeof KO.iat, "internal-error"), Number(KO.exp) - Number(KO.iat)
            }(OO.idToken);
            this.updateTokensAndExpiration(OO.idToken, OO.refreshToken, KO)
          }
          async getToken(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            return yK(!this.accessToken || this.refreshToken, OO, "user-token-expired"), KO || !this.accessToken || this.isExpired ? this.refreshToken ? (await this.refresh(OO, this.refreshToken), this.accessToken) : null : this.accessToken
          }
          clearRefreshToken() {
            this.refreshToken = null
          }
          async refresh(OO, KO) {
            const {
              accessToken: pO,
              refreshToken: bK,
              expiresIn: eO
            } = await async function(OO, KO) {
              const pO = await RO(OO, {}, (async () => {
                const pO = (0, XO.gb)({
                    grant_type: "refresh_token",
                    refresh_token: KO
                  }).slice(1),
                  {
                    tokenApiHost: bK,
                    apiKey: eO
                  } = OO.config,
                  lO = JO(OO, bK, "/v1/token", `key=${eO}`),
                  vK = await OO._getAdditionalHeaders();
                return vK["Content-Type"] = "application/x-www-form-urlencoded", rK.fetch()(lO, {
                  method: "POST",
                  headers: vK,
                  body: pO
                })
              }));
              return {
                accessToken: pO.access_token,
                expiresIn: pO.expires_in,
                refreshToken: pO.refresh_token
              }
            }(OO, KO);
            this.updateTokensAndExpiration(pO, bK, Number(eO))
          }
          updateTokensAndExpiration(OO, KO, pO) {
            this.refreshToken = KO || null, this.accessToken = OO || null, this.expirationTime = Date.now() + 1e3 * pO
          }
          static fromJSON(OO, KO) {
            const {
              refreshToken: pO,
              accessToken: XO,
              expirationTime: bK
            } = KO, eO = new KK;
            return pO && (yK("string" === typeof pO, "internal-error", {
              appName: OO
            }), eO.refreshToken = pO), XO && (yK("string" === typeof XO, "internal-error", {
              appName: OO
            }), eO.accessToken = XO), bK && (yK("number" === typeof bK, "internal-error", {
              appName: OO
            }), eO.expirationTime = bK), eO
          }
          toJSON() {
            return {
              refreshToken: this.refreshToken,
              accessToken: this.accessToken,
              expirationTime: this.expirationTime
            }
          }
          _assign(OO) {
            this.accessToken = OO.accessToken, this.refreshToken = OO.refreshToken, this.expirationTime = OO.expirationTime
          }
          _clone() {
            return Object.assign(new KK, this.toJSON())
          }
          _performRefresh() {
            return gK("not implemented")
          }
        }

        function pK(OO, KO) {
          yK("string" === typeof OO || "undefined" === typeof OO, "internal-error", {
            appName: KO
          })
        }
        class XK {
          constructor(OO) {
            var {
              uid: KO,
              auth: pO,
              stsTokenManager: XO
            } = OO, bK = eO(OO, ["uid", "auth", "stsTokenManager"]);
            this.providerId = "firebase", this.proactiveRefresh = new tK(this), this.reloadUserInfo = null, this.reloadListener = null, this.uid = KO, this.auth = pO, this.stsTokenManager = XO, this.accessToken = XO.accessToken, this.displayName = bK.displayName || null, this.email = bK.email || null, this.emailVerified = bK.emailVerified || !1, this.phoneNumber = bK.phoneNumber || null, this.photoURL = bK.photoURL || null, this.isAnonymous = bK.isAnonymous || !1, this.tenantId = bK.tenantId || null, this.providerData = bK.providerData ? [...bK.providerData] : [], this.metadata = new kK(bK.createdAt || void 0, bK.lastLoginAt || void 0)
          }
          async getIdToken(OO) {
            const KO = await WO(this, this.stsTokenManager.getToken(this.auth, OO));
            return yK(KO, this.auth, "internal-error"), this.accessToken !== KO && (this.accessToken = KO, await this.auth._persistUserIfCurrent(this), this.auth._notifyListenersIfCurrent(this)), KO
          }
          getIdTokenResult(OO) {
            return qK(this, OO)
          }
          reload() {
            return OK(this)
          }
          _assign(OO) {
            this !== OO && (yK(this.uid === OO.uid, this.auth, "internal-error"), this.displayName = OO.displayName, this.photoURL = OO.photoURL, this.email = OO.email, this.emailVerified = OO.emailVerified, this.phoneNumber = OO.phoneNumber, this.isAnonymous = OO.isAnonymous, this.tenantId = OO.tenantId, this.providerData = OO.providerData.map((OO => Object.assign({}, OO))), this.metadata._copy(OO.metadata), this.stsTokenManager._assign(OO.stsTokenManager))
          }
          _clone(OO) {
            const KO = new XK(Object.assign(Object.assign({}, this), {
              auth: OO,
              stsTokenManager: this.stsTokenManager._clone()
            }));
            return KO.metadata._copy(this.metadata), KO
          }
          _onReload(OO) {
            yK(!this.reloadListener, this.auth, "internal-error"), this.reloadListener = OO, this.reloadUserInfo && (this._notifyReloadListener(this.reloadUserInfo), this.reloadUserInfo = null)
          }
          _notifyReloadListener(OO) {
            this.reloadListener ? this.reloadListener(OO) : this.reloadUserInfo = OO
          }
          _startProactiveRefresh() {
            this.proactiveRefresh._start()
          }
          _stopProactiveRefresh() {
            this.proactiveRefresh._stop()
          }
          async _updateTokensIfNecessary(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              pO = !1;
            OO.idToken && OO.idToken !== this.stsTokenManager.accessToken && (this.stsTokenManager.updateFromServerResponse(OO), pO = !0), KO && await UO(this), await this.auth._persistUserIfCurrent(this), pO && this.auth._notifyListenersIfCurrent(this)
          }
          async delete() {
            const OO = await this.getIdToken();
            return await WO(this, async function(OO, KO) {
              return HO(OO, "POST", "/v1/accounts:delete", KO)
            }(this.auth, {
              idToken: OO
            })), this.stsTokenManager.clearRefreshToken(), this.auth.signOut()
          }
          toJSON() {
            return Object.assign(Object.assign({
              uid: this.uid,
              email: this.email || void 0,
              emailVerified: this.emailVerified,
              displayName: this.displayName || void 0,
              isAnonymous: this.isAnonymous,
              photoURL: this.photoURL || void 0,
              phoneNumber: this.phoneNumber || void 0,
              tenantId: this.tenantId || void 0,
              providerData: this.providerData.map((OO => Object.assign({}, OO))),
              stsTokenManager: this.stsTokenManager.toJSON(),
              _redirectEventId: this._redirectEventId
            }, this.metadata.toJSON()), {
              apiKey: this.auth.config.apiKey,
              appName: this.auth.name
            })
          }
          get refreshToken() {
            return this.stsTokenManager.refreshToken || ""
          }
          static _fromJSON(OO, KO) {
            var pO, XO, bK, eO, lO, vK, CO, hO;
            const DO = null !== (pO = KO.displayName) && void 0 !== pO ? pO : void 0,
              MO = null !== (XO = KO.email) && void 0 !== XO ? XO : void 0,
              aK = null !== (bK = KO.phoneNumber) && void 0 !== bK ? bK : void 0,
              oO = null !== (eO = KO.photoURL) && void 0 !== eO ? eO : void 0,
              FO = null !== (lO = KO.tenantId) && void 0 !== lO ? lO : void 0,
              VO = null !== (vK = KO._redirectEventId) && void 0 !== vK ? vK : void 0,
              LO = null !== (CO = KO.createdAt) && void 0 !== CO ? CO : void 0,
              QO = null !== (hO = KO.lastLoginAt) && void 0 !== hO ? hO : void 0,
              {
                uid: zK,
                emailVerified: AO,
                isAnonymous: fO,
                providerData: dO,
                stsTokenManager: TO
              } = KO;
            yK(zK && TO, OO, "internal-error");
            const NO = KK.fromJSON(this.name, TO);
            yK("string" === typeof zK, OO, "internal-error"), pK(DO, OO.name), pK(MO, OO.name), yK("boolean" === typeof AO, OO, "internal-error"), yK("boolean" === typeof fO, OO, "internal-error"), pK(aK, OO.name), pK(oO, OO.name), pK(FO, OO.name), pK(VO, OO.name), pK(LO, OO.name), pK(QO, OO.name);
            const IO = new XK({
              uid: zK,
              auth: OO,
              email: MO,
              emailVerified: AO,
              displayName: DO,
              isAnonymous: fO,
              photoURL: oO,
              phoneNumber: aK,
              tenantId: FO,
              stsTokenManager: NO,
              createdAt: LO,
              lastLoginAt: QO
            });
            return dO && Array.isArray(dO) && (IO.providerData = dO.map((OO => Object.assign({}, OO)))), VO && (IO._redirectEventId = VO), IO
          }
          static async _fromIdTokenResponse(OO, KO) {
            let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
            const XO = new KK;
            XO.updateFromServerResponse(KO);
            const bK = new XK({
              uid: KO.localId,
              auth: OO,
              stsTokenManager: XO,
              isAnonymous: pO
            });
            return await UO(bK), bK
          }
        }
        const bp = new Map;

        function eK(OO) {
          uO(OO instanceof Function, "Expected a class definition");
          let KO = bp.get(OO);
          return KO ? (uO(KO instanceof OO, "Instance stored in cache mismatched with class"), KO) : (KO = new OO, bp.set(OO, KO), KO)
        }
        class lK {
          constructor() {
            this.type = "NONE", this.storage = {}
          }
          async _isAvailable() {
            return !0
          }
          async _set(OO, KO) {
            this.storage[OO] = KO
          }
          async _get(OO) {
            const KO = this.storage[OO];
            return void 0 === KO ? null : KO
          }
          async _remove(OO) {
            delete this.storage[OO]
          }
          _addListener(OO, KO) {}
          _removeListener(OO, KO) {}
        }
        lK.type = "NONE";
        const vp = lK;

        function CK(OO, KO, pO) {
          return `firebase:${OO}:${KO}:${pO}`
        }
        class hK {
          constructor(OO, KO, pO) {
            this.persistence = OO, this.auth = KO, this.userKey = pO;
            const {
              config: XO,
              name: bK
            } = this.auth;
            this.fullUserKey = CK(this.userKey, XO.apiKey, bK), this.fullPersistenceKey = CK("persistence", XO.apiKey, bK), this.boundEventHandler = KO._onStorageEvent.bind(KO), this.persistence._addListener(this.fullUserKey, this.boundEventHandler)
          }
          setCurrentUser(OO) {
            return this.persistence._set(this.fullUserKey, OO.toJSON())
          }
          async getCurrentUser() {
            const OO = await this.persistence._get(this.fullUserKey);
            return OO ? XK._fromJSON(this.auth, OO) : null
          }
          removeCurrentUser() {
            return this.persistence._remove(this.fullUserKey)
          }
          savePersistenceForRedirect() {
            return this.persistence._set(this.fullPersistenceKey, this.persistence.type)
          }
          async setPersistence(OO) {
            if (this.persistence === OO) return;
            const KO = await this.getCurrentUser();
            return await this.removeCurrentUser(), this.persistence = OO, KO ? this.setCurrentUser(KO) : void 0
          }
          delete() {
            this.persistence._removeListener(this.fullUserKey, this.boundEventHandler)
          }
          static async create(OO, KO) {
            let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "authUser";
            if (!KO.length) return new hK(eK(vp), OO, pO);
            const XO = (await Promise.all(KO.map((async OO => {
              if (await OO._isAvailable()) return OO
            })))).filter((OO => OO));
            let bK = XO[0] || eK(vp);
            const eO = CK(pO, OO.config.apiKey, OO.name);
            let lO = null;
            for (const hO of KO) try {
              const KO = await hO._get(eO);
              if (KO) {
                const pO = XK._fromJSON(OO, KO);
                hO !== bK && (lO = pO), bK = hO;
                break
              }
            } catch (CO) {}
            const vK = XO.filter((OO => OO._shouldAllowMigration));
            return bK._shouldAllowMigration && vK.length ? (bK = vK[0], lO && await bK._set(eO, lO.toJSON()), await Promise.all(KO.map((async OO => {
              if (OO !== bK) try {
                await OO._remove(eO)
              } catch (CO) {}
            }))), new hK(bK, OO, pO)) : new hK(bK, OO, pO)
          }
        }

        function DK(OO) {
          const KO = OO.toLowerCase();
          if (KO.includes("opera/") || KO.includes("opr/") || KO.includes("opios/")) return "Opera";
          if (FK(KO)) return "IEMobile";
          if (KO.includes("msie") || KO.includes("trident/")) return "IE";
          if (KO.includes("edge/")) return "Edge";
          if (MK(KO)) return "Firefox";
          if (KO.includes("silk/")) return "Silk";
          if (LK(KO)) return "Blackberry";
          if (QK(KO)) return "Webos";
          if (ap(KO)) return "Safari";
          if ((KO.includes("chrome/") || oK(KO)) && !KO.includes("edge/")) return "Chrome";
          if (VK(KO)) return "Android";
          {
            const KO = /([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,
              pO = OO.match(KO);
            if (2 === (null === pO || void 0 === pO ? void 0 : pO.length)) return pO[1]
          }
          return "Other"
        }

        function MK() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.P)();
          return /firefox\//i.test(OO)
        }

        function ap() {
          const OO = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.P)()).toLowerCase();
          return OO.includes("safari/") && !OO.includes("chrome/") && !OO.includes("crios/") && !OO.includes("android")
        }

        function oK() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.P)();
          return /crios\//i.test(OO)
        }

        function FK() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.P)();
          return /iemobile/i.test(OO)
        }

        function VK() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.P)();
          return /android/i.test(OO)
        }

        function LK() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.P)();
          return /blackberry/i.test(OO)
        }

        function QK() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.P)();
          return /webos/i.test(OO)
        }

        function zp() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.P)();
          return /iphone|ipad|ipod/i.test(OO) || /macintosh/i.test(OO) && /mobile/i.test(OO)
        }

        function AK() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.P)();
          return zp(OO) || VK(OO) || QK(OO) || LK(OO) || /windows phone/i.test(OO) || FK(OO)
        }

        function fK(OO) {
          let KO, pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
          switch (OO) {
            case "Browser":
              KO = DK((0, XO.P)());
              break;
            case "Worker":
              KO = `${DK((0,XO.P)())}-${OO}`;
              break;
            default:
              KO = OO
          }
          const eO = pO.length ? pO.join(",") : "FirebaseCore-web";
          return `${KO}/JsCore/${bK.g}/${eO}`
        }
        async function dK(OO, KO) {
          return HO(OO, "GET", "/v2/recaptchaConfig", sO(OO, KO))
        }

        function TK(OO) {
          return void 0 !== OO && void 0 !== OO.getResponse
        }

        function NK(OO) {
          return void 0 !== OO && void 0 !== OO.enterprise
        }
        class IK {
          constructor(OO) {
            if (this.siteKey = "", this.emailPasswordEnabled = !1, void 0 === OO.recaptchaKey) throw new Error("recaptchaKey undefined");
            this.siteKey = OO.recaptchaKey.split("/")[3], this.emailPasswordEnabled = OO.recaptchaEnforcementState.some((OO => "EMAIL_PASSWORD_PROVIDER" === OO.provider && "OFF" !== OO.enforcementState))
          }
        }

        function yp(OO) {
          return new Promise(((KO, pO) => {
            const XO = document.createElement("script");
            XO.setAttribute("src", OO), XO.onload = KO, XO.onerror = OO => {
                const KO = dO("internal-error");
                KO.customData = OO, pO(KO)
              }, XO.type = "text/javascript", XO.charset = "UTF-8",
              function() {
                var OO, KO;
                return null !== (KO = null === (OO = document.getElementsByTagName("head")) || void 0 === OO ? void 0 : OO[0]) && void 0 !== KO ? KO : document
              }().appendChild(XO)
          }))
        }

        function gp(OO) {
          return `__${OO}${Math.floor(1e6*Math.random())}`
        }
        class uK {
          constructor(OO) {
            this.type = "recaptcha-enterprise", this.auth = wK(OO)
          }
          async verify() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "verify",
              KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];

            function pO(KO, pO, XO) {
              const bK = window.grecaptcha;
              NK(bK) ? bK.enterprise.ready((() => {
                bK.enterprise.execute(KO, {
                  action: OO
                }).then((OO => {
                  pO(OO)
                })).catch((() => {
                  pO("NO_RECAPTCHA")
                }))
              })) : XO(Error("No reCAPTCHA enterprise script loaded."))
            }
            return new Promise(((OO, XO) => {
              (async function(OO) {
                if (!KO) {
                  if (null == OO.tenantId && null != OO._agentRecaptchaConfig) return OO._agentRecaptchaConfig.siteKey;
                  if (null != OO.tenantId && void 0 !== OO._tenantRecaptchaConfigs[OO.tenantId]) return OO._tenantRecaptchaConfigs[OO.tenantId].siteKey
                }
                return new Promise((async (KO, pO) => {
                  dK(OO, {
                    clientType: "CLIENT_TYPE_WEB",
                    version: "RECAPTCHA_ENTERPRISE"
                  }).then((XO => {
                    if (void 0 !== XO.recaptchaKey) {
                      const pO = new IK(XO);
                      return null == OO.tenantId ? OO._agentRecaptchaConfig = pO : OO._tenantRecaptchaConfigs[OO.tenantId] = pO, KO(pO.siteKey)
                    }
                    pO(new Error("recaptcha Enterprise site key undefined"))
                  })).catch((OO => {
                    pO(OO)
                  }))
                }))
              })(this.auth).then((bK => {
                if (!KO && NK(window.grecaptcha)) pO(bK, OO, XO);
                else {
                  if ("undefined" === typeof window) return void XO(new Error("RecaptchaVerifier is only supported in browser"));
                  yp("https://www.google.com/recaptcha/enterprise.js?render=" + bK).then((() => {
                    pO(bK, OO, XO)
                  })).catch((OO => {
                    XO(OO)
                  }))
                }
              })).catch((OO => {
                XO(OO)
              }))
            }))
          }
        }
        async function EK(OO, KO, pO) {
          let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
          const bK = new uK(OO);
          let eO;
          try {
            eO = await bK.verify(pO)
          } catch (vK) {
            eO = await bK.verify(pO, !0)
          }
          const lO = Object.assign({}, KO);
          return XO ? Object.assign(lO, {
            captchaResp: eO
          }) : Object.assign(lO, {
            captchaResponse: eO
          }), Object.assign(lO, {
            clientType: "CLIENT_TYPE_WEB"
          }), Object.assign(lO, {
            recaptchaVersion: "RECAPTCHA_ENTERPRISE"
          }), lO
        }
        class jp {
          constructor(OO) {
            this.auth = OO, this.queue = []
          }
          pushCallback(OO, KO) {
            const pO = KO => new Promise(((pO, XO) => {
              try {
                pO(OO(KO))
              } catch (bK) {
                XO(bK)
              }
            }));
            pO.onAbort = KO, this.queue.push(pO);
            const XO = this.queue.length - 1;
            return () => {
              this.queue[XO] = () => Promise.resolve()
            }
          }
          async runMiddleware(OO) {
            if (this.auth.currentUser === OO) return;
            const KO = [];
            try {
              for (const pO of this.queue) await pO(OO), pO.onAbort && KO.push(pO.onAbort)
            } catch (pO) {
              KO.reverse();
              for (const OO of KO) try {
                OO()
              } catch (XO) {}
              throw this.auth._errorFactory.create("login-blocked", {
                originalMessage: null === pO || void 0 === pO ? void 0 : pO.message
              })
            }
          }
        }
        class YK {
          constructor(OO, KO, pO, XO) {
            this.app = OO, this.heartbeatServiceProvider = KO, this.appCheckServiceProvider = pO, this.config = XO, this.currentUser = null, this.emulatorConfig = null, this.operations = Promise.resolve(), this.authStateSubscription = new ip(this), this.idTokenSubscription = new ip(this), this.beforeStateQueue = new jp(this), this.redirectUser = null, this.isProactiveRefreshEnabled = !1, this._canInitEmulator = !0, this._isInitialized = !1, this._deleted = !1, this._initializationPromise = null, this._popupRedirectResolver = null, this._errorFactory = LO, this._agentRecaptchaConfig = null, this._tenantRecaptchaConfigs = {}, this.lastNotifiedUid = void 0, this.languageCode = null, this.tenantId = null, this.settings = {
              appVerificationDisabledForTesting: !1
            }, this.frameworks = [], this.name = OO.name, this.clientVersion = XO.sdkClientVersion
          }
          _initializeWithPersistence(OO, KO) {
            return KO && (this._popupRedirectResolver = eK(KO)), this._initializationPromise = this.queue((async () => {
              var pO, XO;
              if (!this._deleted && (this.persistenceManager = await hK.create(this, OO), !this._deleted)) {
                if (null === (pO = this._popupRedirectResolver) || void 0 === pO ? void 0 : pO._shouldInitProactively) try {
                  await this._popupRedirectResolver._initialize(this)
                } catch (bK) {}
                await this.initializeCurrentUser(KO), this.lastNotifiedUid = (null === (XO = this.currentUser) || void 0 === XO ? void 0 : XO.uid) || null, this._deleted || (this._isInitialized = !0)
              }
            })), this._initializationPromise
          }
          async _onStorageEvent() {
            if (this._deleted) return;
            const OO = await this.assertedPersistence.getCurrentUser();
            return this.currentUser || OO ? this.currentUser && OO && this.currentUser.uid === OO.uid ? (this._currentUser._assign(OO), void await this.currentUser.getIdToken()) : void await this._updateCurrentUser(OO, !0) : void 0
          }
          async initializeCurrentUser(OO) {
            var KO;
            const pO = await this.assertedPersistence.getCurrentUser();
            let XO = pO,
              bK = !1;
            if (OO && this.config.authDomain) {
              await this.getOrInitRedirectPersistenceManager();
              const pO = null === (KO = this.redirectUser) || void 0 === KO ? void 0 : KO._redirectEventId,
                eO = null === XO || void 0 === XO ? void 0 : XO._redirectEventId,
                lO = await this.tryRedirectSignIn(OO);
              pO && pO !== eO || !(null === lO || void 0 === lO ? void 0 : lO.user) || (XO = lO.user, bK = !0)
            }
            if (!XO) return this.directlySetCurrentUser(null);
            if (!XO._redirectEventId) {
              if (bK) try {
                await this.beforeStateQueue.runMiddleware(XO)
              } catch (eO) {
                XO = pO, this._popupRedirectResolver._overrideRedirectResult(this, (() => Promise.reject(eO)))
              }
              return XO ? this.reloadAndSetCurrentUserOrClear(XO) : this.directlySetCurrentUser(null)
            }
            return yK(this._popupRedirectResolver, this, "argument-error"), await this.getOrInitRedirectPersistenceManager(), this.redirectUser && this.redirectUser._redirectEventId === XO._redirectEventId ? this.directlySetCurrentUser(XO) : this.reloadAndSetCurrentUserOrClear(XO)
          }
          async tryRedirectSignIn(OO) {
            let KO = null;
            try {
              KO = await this._popupRedirectResolver._completeRedirectFn(this, OO, !0)
            } catch (pO) {
              await this._setRedirectUser(null)
            }
            return KO
          }
          async reloadAndSetCurrentUserOrClear(OO) {
            try {
              await UO(OO)
            } catch (KO) {
              if ("auth/network-request-failed" !== (null === KO || void 0 === KO ? void 0 : KO.code)) return this.directlySetCurrentUser(null)
            }
            return this.directlySetCurrentUser(OO)
          }
          useDeviceLanguage() {
            this.languageCode = function() {
              if ("undefined" === typeof navigator) return null;
              const OO = navigator;
              return OO.languages && OO.languages[0] || OO.language || null
            }()
          }
          async _delete() {
            this._deleted = !0
          }
          async updateCurrentUser(OO) {
            const KO = OO ? (0, XO.N)(OO) : null;
            return KO && yK(KO.auth.config.apiKey === this.config.apiKey, this, "invalid-user-token"), this._updateCurrentUser(KO && KO._clone(this))
          }
          async _updateCurrentUser(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if (!this._deleted) return OO && yK(this.tenantId === OO.tenantId, this, "tenant-id-mismatch"), KO || await this.beforeStateQueue.runMiddleware(OO), this.queue((async () => {
              await this.directlySetCurrentUser(OO), this.notifyAuthListeners()
            }))
          }
          async signOut() {
            return await this.beforeStateQueue.runMiddleware(null), (this.redirectPersistenceManager || this._popupRedirectResolver) && await this._setRedirectUser(null), this._updateCurrentUser(null, !0)
          }
          setPersistence(OO) {
            return this.queue((async () => {
              await this.assertedPersistence.setPersistence(eK(OO))
            }))
          }
          async initializeRecaptchaConfig() {
            const OO = await dK(this, {
                clientType: "CLIENT_TYPE_WEB",
                version: "RECAPTCHA_ENTERPRISE"
              }),
              KO = new IK(OO);
            if (null == this.tenantId ? this._agentRecaptchaConfig = KO : this._tenantRecaptchaConfigs[this.tenantId] = KO, KO.emailPasswordEnabled) {
              new uK(this).verify()
            }
          }
          _getRecaptchaConfig() {
            return null == this.tenantId ? this._agentRecaptchaConfig : this._tenantRecaptchaConfigs[this.tenantId]
          }
          _getPersistence() {
            return this.assertedPersistence.persistence.type
          }
          _updateErrorMap(OO) {
            this._errorFactory = new XO.h("auth", "Firebase", OO())
          }
          onAuthStateChanged(OO, KO, pO) {
            return this.registerStateListener(this.authStateSubscription, OO, KO, pO)
          }
          beforeAuthStateChanged(OO, KO) {
            return this.beforeStateQueue.pushCallback(OO, KO)
          }
          onIdTokenChanged(OO, KO, pO) {
            return this.registerStateListener(this.idTokenSubscription, OO, KO, pO)
          }
          toJSON() {
            var OO;
            return {
              apiKey: this.config.apiKey,
              authDomain: this.config.authDomain,
              appName: this.name,
              currentUser: null === (OO = this._currentUser) || void 0 === OO ? void 0 : OO.toJSON()
            }
          }
          async _setRedirectUser(OO, KO) {
            const pO = await this.getOrInitRedirectPersistenceManager(KO);
            return null === OO ? pO.removeCurrentUser() : pO.setCurrentUser(OO)
          }
          async getOrInitRedirectPersistenceManager(OO) {
            if (!this.redirectPersistenceManager) {
              const KO = OO && eK(OO) || this._popupRedirectResolver;
              yK(KO, this, "argument-error"), this.redirectPersistenceManager = await hK.create(this, [eK(KO._redirectPersistence)], "redirectUser"), this.redirectUser = await this.redirectPersistenceManager.getCurrentUser()
            }
            return this.redirectPersistenceManager
          }
          async _redirectUserForId(OO) {
            var KO, pO;
            return this._isInitialized && await this.queue((async () => {})), (null === (KO = this._currentUser) || void 0 === KO ? void 0 : KO._redirectEventId) === OO ? this._currentUser : (null === (pO = this.redirectUser) || void 0 === pO ? void 0 : pO._redirectEventId) === OO ? this.redirectUser : null
          }
          async _persistUserIfCurrent(OO) {
            if (OO === this.currentUser) return this.queue((async () => this.directlySetCurrentUser(OO)))
          }
          _notifyListenersIfCurrent(OO) {
            OO === this.currentUser && this.notifyAuthListeners()
          }
          _key() {
            return `${this.config.authDomain}:${this.config.apiKey}:${this.name}`
          }
          _startProactiveRefresh() {
            this.isProactiveRefreshEnabled = !0, this.currentUser && this._currentUser._startProactiveRefresh()
          }
          _stopProactiveRefresh() {
            this.isProactiveRefreshEnabled = !1, this.currentUser && this._currentUser._stopProactiveRefresh()
          }
          get _currentUser() {
            return this.currentUser
          }
          notifyAuthListeners() {
            var OO, KO;
            if (!this._isInitialized) return;
            this.idTokenSubscription.next(this.currentUser);
            const pO = null !== (KO = null === (OO = this.currentUser) || void 0 === OO ? void 0 : OO.uid) && void 0 !== KO ? KO : null;
            this.lastNotifiedUid !== pO && (this.lastNotifiedUid = pO, this.authStateSubscription.next(this.currentUser))
          }
          registerStateListener(OO, KO, pO, XO) {
            if (this._deleted) return () => {};
            const bK = "function" === typeof KO ? KO : KO.next.bind(KO),
              eO = this._isInitialized ? Promise.resolve() : this._initializationPromise;
            return yK(eO, this, "internal-error"), eO.then((() => bK(this.currentUser))), "function" === typeof KO ? OO.addObserver(KO, pO, XO) : OO.addObserver(KO)
          }
          async directlySetCurrentUser(OO) {
            this.currentUser && this.currentUser !== OO && this._currentUser._stopProactiveRefresh(), OO && this.isProactiveRefreshEnabled && OO._startProactiveRefresh(), this.currentUser = OO, OO ? await this.assertedPersistence.setCurrentUser(OO) : await this.assertedPersistence.removeCurrentUser()
          }
          queue(OO) {
            return this.operations = this.operations.then(OO, OO), this.operations
          }
          get assertedPersistence() {
            return yK(this.persistenceManager, this, "internal-error"), this.persistenceManager
          }
          _logFramework(OO) {
            OO && !this.frameworks.includes(OO) && (this.frameworks.push(OO), this.frameworks.sort(), this.clientVersion = fK(this.config.clientPlatform, this._getFrameworks()))
          }
          _getFrameworks() {
            return this.frameworks
          }
          async _getAdditionalHeaders() {
            var OO;
            const KO = {
              "X-Client-Version": this.clientVersion
            };
            this.app.options.appId && (KO["X-Firebase-gmpid"] = this.app.options.appId);
            const pO = await (null === (OO = this.heartbeatServiceProvider.getImmediate({
              optional: !0
            })) || void 0 === OO ? void 0 : OO.getHeartbeatsHeader());
            pO && (KO["X-Firebase-Client"] = pO);
            const XO = await this._getAppCheckToken();
            return XO && (KO["X-Firebase-AppCheck"] = XO), KO
          }
          async _getAppCheckToken() {
            var OO;
            const KO = await (null === (OO = this.appCheckServiceProvider.getImmediate({
              optional: !0
            })) || void 0 === OO ? void 0 : OO.getToken());
            return (null === KO || void 0 === KO ? void 0 : KO.error) && function(OO) {
              if (zK.logLevel <= lO.d.WARN) {
                for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
                zK.warn(`Auth (${bK.g}): ${OO}`, ...pO)
              }
            }(`Error while retrieving App Check token: ${KO.error}`), null === KO || void 0 === KO ? void 0 : KO.token
          }
        }

        function wK(OO) {
          return (0, XO.N)(OO)
        }
        class ip {
          constructor(OO) {
            this.auth = OO, this.observer = null, this.addObserver = (0, XO.z)((OO => this.observer = OO))
          }
          get next() {
            return yK(this.observer, this.auth, "internal-error"), this.observer.next.bind(this.observer)
          }
        }

        function rp(OO, KO) {
          const pO = (0, bK.w)(OO, "auth");
          if (pO.isInitialized()) {
            const OO = pO.getImmediate(),
              bK = pO.getOptions();
            if ((0, XO.B)(bK, null !== KO && void 0 !== KO ? KO : {})) return OO;
            fO(OO, "already-initialized")
          }
          return pO.initialize({
            options: KO
          })
        }

        function PK(OO, KO, pO) {
          const XO = wK(OO);
          yK(XO._canInitEmulator, XO, "emulator-config-failed"), yK(/^https?:\/\//.test(KO), XO, "invalid-emulator-scheme");
          const bK = !!(null === pO || void 0 === pO ? void 0 : pO.disableWarnings),
            eO = mp(KO),
            {
              host: lO,
              port: vK
            } = function(OO) {
              const KO = mp(OO),
                pO = /(\/\/)?([^?#/]+)/.exec(OO.substr(KO.length));
              if (!pO) return {
                host: "",
                port: null
              };
              const XO = pO[2].split("@").pop() || "",
                bK = /^(\[[^\]]+\])(:|$)/.exec(XO);
              if (bK) {
                const OO = bK[1];
                return {
                  host: OO,
                  port: sK(XO.substr(OO.length + 1))
                }
              } {
                const [OO, KO] = XO.split(":");
                return {
                  host: OO,
                  port: sK(KO)
                }
              }
            }(KO),
            CO = null === vK ? "" : `:${vK}`;
          XO.config.emulator = {
            url: `${eO}//${lO}${CO}/`
          }, XO.settings.appVerificationDisabledForTesting = !0, XO.emulatorConfig = Object.freeze({
            host: lO,
            port: vK,
            protocol: eO.replace(":", ""),
            options: Object.freeze({
              disableWarnings: bK
            })
          }), bK || function() {
            function OO() {
              const OO = document.createElement("p"),
                KO = OO.style;
              OO.innerText = "Running in emulator mode. Do not use with production credentials.", KO.position = "fixed", KO.width = "100%", KO.backgroundColor = "#ffffff", KO.border = ".1em solid #000000", KO.color = "#b50000", KO.bottom = "0px", KO.left = "0px", KO.margin = "0px", KO.zIndex = "10000", KO.textAlign = "center", OO.classList.add("firebase-emulator-warning"), document.body.appendChild(OO)
            }
            "undefined" !== typeof console && "function" === typeof console.info && console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials.");
            "undefined" !== typeof window && "undefined" !== typeof document && ("loading" === document.readyState ? window.addEventListener("DOMContentLoaded", OO) : OO())
          }()
        }

        function mp(OO) {
          const KO = OO.indexOf(":");
          return KO < 0 ? "" : OO.substr(0, KO + 1)
        }

        function sK(OO) {
          if (!OO) return null;
          const KO = Number(OO);
          return isNaN(KO) ? null : KO
        }
        class HK {
          constructor(OO, KO) {
            this.providerId = OO, this.signInMethod = KO
          }
          toJSON() {
            return gK("not implemented")
          }
          _getIdTokenResponse(OO) {
            return gK("not implemented")
          }
          _linkToIdToken(OO, KO) {
            return gK("not implemented")
          }
          _getReauthenticationResolver(OO) {
            return gK("not implemented")
          }
        }
        async function RK(OO, KO) {
          return HO(OO, "POST", "/v1/accounts:resetPassword", sO(OO, KO))
        }
        async function SK(OO, KO) {
          return HO(OO, "POST", "/v1/accounts:update", KO)
        }
        async function JK(OO, KO) {
          return SO(OO, "POST", "/v1/accounts:signInWithPassword", sO(OO, KO))
        }
        async function cp(OO, KO) {
          return HO(OO, "POST", "/v1/accounts:sendOobCode", sO(OO, KO))
        }
        async function BK(OO, KO) {
          return cp(OO, KO)
        }
        async function ZK(OO, KO) {
          return cp(OO, KO)
        }
        class GK extends HK {
          constructor(OO, KO, pO) {
            let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
            super("password", pO), this._email = OO, this._password = KO, this._tenantId = XO
          }
          static _fromEmailAndPassword(OO, KO) {
            return new GK(OO, KO, "password")
          }
          static _fromEmailAndCode(OO, KO) {
            return new GK(OO, KO, "emailLink", arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null)
          }
          toJSON() {
            return {
              email: this._email,
              password: this._password,
              signInMethod: this.signInMethod,
              tenantId: this._tenantId
            }
          }
          static fromJSON(OO) {
            const KO = "string" === typeof OO ? JSON.parse(OO) : OO;
            if ((null === KO || void 0 === KO ? void 0 : KO.email) && (null === KO || void 0 === KO ? void 0 : KO.password)) {
              if ("password" === KO.signInMethod) return this._fromEmailAndPassword(KO.email, KO.password);
              if ("emailLink" === KO.signInMethod) return this._fromEmailAndCode(KO.email, KO.password, KO.tenantId)
            }
            return null
          }
          async _getIdTokenResponse(OO) {
            var KO;
            switch (this.signInMethod) {
              case "password":
                const pO = {
                  returnSecureToken: !0,
                  email: this._email,
                  password: this._password,
                  clientType: "CLIENT_TYPE_WEB"
                };
                if (null === (KO = OO._getRecaptchaConfig()) || void 0 === KO ? void 0 : KO.emailPasswordEnabled) {
                  const KO = await EK(OO, pO, "signInWithPassword");
                  return JK(OO, KO)
                }
                return JK(OO, pO).catch((async KO => {
                  if ("auth/missing-recaptcha-token" === KO.code) {
                    console.log("Sign-in with email address and password is protected by reCAPTCHA for this project. Automatically triggering the reCAPTCHA flow and restarting the sign-in flow.");
                    const KO = await EK(OO, pO, "signInWithPassword");
                    return JK(OO, KO)
                  }
                  return Promise.reject(KO)
                }));
              case "emailLink":
                return async function(OO, KO) {
                  return SO(OO, "POST", "/v1/accounts:signInWithEmailLink", sO(OO, KO))
                }(OO, {
                  email: this._email,
                  oobCode: this._password
                });
              default:
                fO(OO, "internal-error")
            }
          }
          async _linkToIdToken(OO, KO) {
            switch (this.signInMethod) {
              case "password":
                return SK(OO, {
                  idToken: KO,
                  returnSecureToken: !0,
                  email: this._email,
                  password: this._password
                });
              case "emailLink":
                return async function(OO, KO) {
                  return SO(OO, "POST", "/v1/accounts:signInWithEmailLink", sO(OO, KO))
                }(OO, {
                  idToken: KO,
                  email: this._email,
                  oobCode: this._password
                });
              default:
                fO(OO, "internal-error")
            }
          }
          _getReauthenticationResolver(OO) {
            return this._getIdTokenResponse(OO)
          }
        }
        async function qp(OO, KO) {
          return SO(OO, "POST", "/v1/accounts:signInWithIdp", sO(OO, KO))
        }
        class xp extends HK {
          constructor() {
            super(...arguments), this.pendingToken = null
          }
          static _fromParams(OO) {
            const KO = new xp(OO.providerId, OO.signInMethod);
            return OO.idToken || OO.accessToken ? (OO.idToken && (KO.idToken = OO.idToken), OO.accessToken && (KO.accessToken = OO.accessToken), OO.nonce && !OO.pendingToken && (KO.nonce = OO.nonce), OO.pendingToken && (KO.pendingToken = OO.pendingToken)) : OO.oauthToken && OO.oauthTokenSecret ? (KO.accessToken = OO.oauthToken, KO.secret = OO.oauthTokenSecret) : fO("argument-error"), KO
          }
          toJSON() {
            return {
              idToken: this.idToken,
              accessToken: this.accessToken,
              secret: this.secret,
              nonce: this.nonce,
              pendingToken: this.pendingToken,
              providerId: this.providerId,
              signInMethod: this.signInMethod
            }
          }
          static fromJSON(OO) {
            const KO = "string" === typeof OO ? JSON.parse(OO) : OO,
              {
                providerId: pO,
                signInMethod: XO
              } = KO,
              bK = eO(KO, ["providerId", "signInMethod"]);
            if (!pO || !XO) return null;
            const lO = new xp(pO, XO);
            return lO.idToken = bK.idToken || void 0, lO.accessToken = bK.accessToken || void 0, lO.secret = bK.secret, lO.nonce = bK.nonce, lO.pendingToken = bK.pendingToken || null, lO
          }
          _getIdTokenResponse(OO) {
            return qp(OO, this.buildRequest())
          }
          _linkToIdToken(OO, KO) {
            const pO = this.buildRequest();
            return pO.idToken = KO, qp(OO, pO)
          }
          _getReauthenticationResolver(OO) {
            const KO = this.buildRequest();
            return KO.autoCreate = !1, qp(OO, KO)
          }
          buildRequest() {
            const OO = {
              requestUri: "http://localhost",
              returnSecureToken: !0
            };
            if (this.pendingToken) OO.pendingToken = this.pendingToken;
            else {
              const KO = {};
              this.idToken && (KO.id_token = this.idToken), this.accessToken && (KO.access_token = this.accessToken), this.secret && (KO.oauth_token_secret = this.secret), KO.providerId = this.providerId, this.nonce && !this.pendingToken && (KO.nonce = this.nonce), OO.postBody = (0, XO.gb)(KO)
            }
            return OO
          }
        }
        const nK = {
          USER_NOT_FOUND: "user-not-found"
        };
        class WK extends HK {
          constructor(OO) {
            super("phone", "phone"), this.params = OO
          }
          static _fromVerification(OO, KO) {
            return new WK({
              verificationId: OO,
              verificationCode: KO
            })
          }
          static _fromTokenResponse(OO, KO) {
            return new WK({
              phoneNumber: OO,
              temporaryProof: KO
            })
          }
          _getIdTokenResponse(OO) {
            return async function(OO, KO) {
              return SO(OO, "POST", "/v1/accounts:signInWithPhoneNumber", sO(OO, KO))
            }(OO, this._makeVerificationRequest())
          }
          _linkToIdToken(OO, KO) {
            return async function(OO, KO) {
              const pO = await SO(OO, "POST", "/v1/accounts:signInWithPhoneNumber", sO(OO, KO));
              if (pO.temporaryProof) throw BO(OO, "account-exists-with-different-credential", pO);
              return pO
            }(OO, Object.assign({
              idToken: KO
            }, this._makeVerificationRequest()))
          }
          _getReauthenticationResolver(OO) {
            return async function(OO, KO) {
              return SO(OO, "POST", "/v1/accounts:signInWithPhoneNumber", sO(OO, Object.assign(Object.assign({}, KO), {
                operation: "REAUTH"
              })), nK)
            }(OO, this._makeVerificationRequest())
          }
          _makeVerificationRequest() {
            const {
              temporaryProof: OO,
              phoneNumber: KO,
              verificationId: pO,
              verificationCode: XO
            } = this.params;
            return OO && KO ? {
              temporaryProof: OO,
              phoneNumber: KO
            } : {
              sessionInfo: pO,
              code: XO
            }
          }
          toJSON() {
            const OO = {
              providerId: this.providerId
            };
            return this.params.phoneNumber && (OO.phoneNumber = this.params.phoneNumber), this.params.temporaryProof && (OO.temporaryProof = this.params.temporaryProof), this.params.verificationCode && (OO.verificationCode = this.params.verificationCode), this.params.verificationId && (OO.verificationId = this.params.verificationId), OO
          }
          static fromJSON(OO) {
            "string" === typeof OO && (OO = JSON.parse(OO));
            const {
              verificationId: KO,
              verificationCode: pO,
              phoneNumber: XO,
              temporaryProof: bK
            } = OO;
            return pO || KO || XO || bK ? new WK({
              verificationId: KO,
              verificationCode: pO,
              phoneNumber: XO,
              temporaryProof: bK
            }) : null
          }
        }
        class tp {
          constructor(OO) {
            var KO, pO, bK, eO, lO, vK;
            const CO = (0, XO.eb)((0, XO.C)(OO)),
              hO = null !== (KO = CO.apiKey) && void 0 !== KO ? KO : null,
              DO = null !== (pO = CO.oobCode) && void 0 !== pO ? pO : null,
              MO = function(OO) {
                switch (OO) {
                  case "recoverEmail":
                    return "RECOVER_EMAIL";
                  case "resetPassword":
                    return "PASSWORD_RESET";
                  case "signIn":
                    return "EMAIL_SIGNIN";
                  case "verifyEmail":
                    return "VERIFY_EMAIL";
                  case "verifyAndChangeEmail":
                    return "VERIFY_AND_CHANGE_EMAIL";
                  case "revertSecondFactorAddition":
                    return "REVERT_SECOND_FACTOR_ADDITION";
                  default:
                    return null
                }
              }(null !== (bK = CO.mode) && void 0 !== bK ? bK : null);
            yK(hO && DO && MO, "argument-error"), this.apiKey = hO, this.operation = MO, this.code = DO, this.continueUrl = null !== (eO = CO.continueUrl) && void 0 !== eO ? eO : null, this.languageCode = null !== (lO = CO.languageCode) && void 0 !== lO ? lO : null, this.tenantId = null !== (vK = CO.tenantId) && void 0 !== vK ? vK : null
          }
          static parseLink(OO) {
            const KO = function(OO) {
              const KO = (0, XO.eb)((0, XO.C)(OO)).link,
                pO = KO ? (0, XO.eb)((0, XO.C)(KO)).deep_link_id : null,
                bK = (0, XO.eb)((0, XO.C)(OO)).deep_link_id;
              return (bK ? (0, XO.eb)((0, XO.C)(bK)).link : null) || bK || pO || KO || OO
            }(OO);
            try {
              return new tp(KO)
            } catch (pO) {
              return null
            }
          }
        }

        function kp(OO) {
          return tp.parseLink(OO)
        }
        class UK {
          constructor() {
            this.providerId = UK.PROVIDER_ID
          }
          static credential(OO, KO) {
            return GK._fromEmailAndPassword(OO, KO)
          }
          static credentialWithLink(OO, KO) {
            const pO = tp.parseLink(KO);
            return yK(pO, "argument-error"), GK._fromEmailAndCode(OO, pO.code, pO.tenantId)
          }
        }
        UK.PROVIDER_ID = "password", UK.EMAIL_PASSWORD_SIGN_IN_METHOD = "password", UK.EMAIL_LINK_SIGN_IN_METHOD = "emailLink";
        class Op {
          constructor(OO) {
            this.providerId = OO, this.defaultLanguageCode = null, this.customParameters = {}
          }
          setDefaultLanguage(OO) {
            this.defaultLanguageCode = OO
          }
          setCustomParameters(OO) {
            return this.customParameters = OO, this
          }
          getCustomParameters() {
            return this.customParameters
          }
        }
        class Kp extends Op {
          constructor() {
            super(...arguments), this.scopes = []
          }
          addScope(OO) {
            return this.scopes.includes(OO) || this.scopes.push(OO), this
          }
          getScopes() {
            return [...this.scopes]
          }
        }
        class pp extends Kp {
          static credentialFromJSON(OO) {
            const KO = "string" === typeof OO ? JSON.parse(OO) : OO;
            return yK("providerId" in KO && "signInMethod" in KO, "argument-error"), xp._fromParams(KO)
          }
          credential(OO) {
            return this._credential(Object.assign(Object.assign({}, OO), {
              nonce: OO.rawNonce
            }))
          }
          _credential(OO) {
            return yK(OO.idToken || OO.accessToken, "argument-error"), xp._fromParams(Object.assign(Object.assign({}, OO), {
              providerId: this.providerId,
              signInMethod: this.providerId
            }))
          }
          static credentialFromResult(OO) {
            return pp.oauthCredentialFromTaggedObject(OO)
          }
          static credentialFromError(OO) {
            return pp.oauthCredentialFromTaggedObject(OO.customData || {})
          }
          static oauthCredentialFromTaggedObject(OO) {
            let {
              _tokenResponse: KO
            } = OO;
            if (!KO) return null;
            const {
              oauthIdToken: pO,
              oauthAccessToken: XO,
              oauthTokenSecret: bK,
              pendingToken: eO,
              nonce: lO,
              providerId: vK
            } = KO;
            if (!XO && !bK && !pO && !eO) return null;
            if (!vK) return null;
            try {
              return new pp(vK)._credential({
                idToken: pO,
                accessToken: XO,
                nonce: lO,
                pendingToken: eO
              })
            } catch (CO) {
              return null
            }
          }
        }
        class Xp extends Kp {
          constructor() {
            super("facebook.com")
          }
          static credential(OO) {
            return xp._fromParams({
              providerId: Xp.PROVIDER_ID,
              signInMethod: Xp.FACEBOOK_SIGN_IN_METHOD,
              accessToken: OO
            })
          }
          static credentialFromResult(OO) {
            return Xp.credentialFromTaggedObject(OO)
          }
          static credentialFromError(OO) {
            return Xp.credentialFromTaggedObject(OO.customData || {})
          }
          static credentialFromTaggedObject(OO) {
            let {
              _tokenResponse: KO
            } = OO;
            if (!KO || !("oauthAccessToken" in KO)) return null;
            if (!KO.oauthAccessToken) return null;
            try {
              return Xp.credential(KO.oauthAccessToken)
            } catch (pO) {
              return null
            }
          }
        }
        Xp.FACEBOOK_SIGN_IN_METHOD = "facebook.com", Xp.PROVIDER_ID = "facebook.com";
        class bX extends Kp {
          constructor() {
            super("google.com"), this.addScope("profile")
          }
          static credential(OO, KO) {
            return xp._fromParams({
              providerId: bX.PROVIDER_ID,
              signInMethod: bX.GOOGLE_SIGN_IN_METHOD,
              idToken: OO,
              accessToken: KO
            })
          }
          static credentialFromResult(OO) {
            return bX.credentialFromTaggedObject(OO)
          }
          static credentialFromError(OO) {
            return bX.credentialFromTaggedObject(OO.customData || {})
          }
          static credentialFromTaggedObject(OO) {
            let {
              _tokenResponse: KO
            } = OO;
            if (!KO) return null;
            const {
              oauthIdToken: pO,
              oauthAccessToken: XO
            } = KO;
            if (!pO && !XO) return null;
            try {
              return bX.credential(pO, XO)
            } catch (bK) {
              return null
            }
          }
        }
        bX.GOOGLE_SIGN_IN_METHOD = "google.com", bX.PROVIDER_ID = "google.com";
        class ep extends Kp {
          constructor() {
            super("github.com")
          }
          static credential(OO) {
            return xp._fromParams({
              providerId: ep.PROVIDER_ID,
              signInMethod: ep.GITHUB_SIGN_IN_METHOD,
              accessToken: OO
            })
          }
          static credentialFromResult(OO) {
            return ep.credentialFromTaggedObject(OO)
          }
          static credentialFromError(OO) {
            return ep.credentialFromTaggedObject(OO.customData || {})
          }
          static credentialFromTaggedObject(OO) {
            let {
              _tokenResponse: KO
            } = OO;
            if (!KO || !("oauthAccessToken" in KO)) return null;
            if (!KO.oauthAccessToken) return null;
            try {
              return ep.credential(KO.oauthAccessToken)
            } catch (pO) {
              return null
            }
          }
        }
        ep.GITHUB_SIGN_IN_METHOD = "github.com", ep.PROVIDER_ID = "github.com";
        class lp extends HK {
          constructor(OO, KO) {
            super(OO, OO), this.pendingToken = KO
          }
          _getIdTokenResponse(OO) {
            return qp(OO, this.buildRequest())
          }
          _linkToIdToken(OO, KO) {
            const pO = this.buildRequest();
            return pO.idToken = KO, qp(OO, pO)
          }
          _getReauthenticationResolver(OO) {
            const KO = this.buildRequest();
            return KO.autoCreate = !1, qp(OO, KO)
          }
          toJSON() {
            return {
              signInMethod: this.signInMethod,
              providerId: this.providerId,
              pendingToken: this.pendingToken
            }
          }
          static fromJSON(OO) {
            const KO = "string" === typeof OO ? JSON.parse(OO) : OO,
              {
                providerId: pO,
                signInMethod: XO,
                pendingToken: bK
              } = KO;
            return pO && XO && bK && pO === XO ? new lp(pO, bK) : null
          }
          static _create(OO, KO) {
            return new lp(OO, KO)
          }
          buildRequest() {
            return {
              requestUri: "http://localhost",
              returnSecureToken: !0,
              pendingToken: this.pendingToken
            }
          }
        }
        class vX extends Op {
          constructor(OO) {
            yK(OO.startsWith("saml."), "argument-error"), super(OO)
          }
          static credentialFromResult(OO) {
            return vX.samlCredentialFromTaggedObject(OO)
          }
          static credentialFromError(OO) {
            return vX.samlCredentialFromTaggedObject(OO.customData || {})
          }
          static credentialFromJSON(OO) {
            const KO = lp.fromJSON(OO);
            return yK(KO, "argument-error"), KO
          }
          static samlCredentialFromTaggedObject(OO) {
            let {
              _tokenResponse: KO
            } = OO;
            if (!KO) return null;
            const {
              pendingToken: pO,
              providerId: XO
            } = KO;
            if (!pO || !XO) return null;
            try {
              return lp._create(XO, pO)
            } catch (bK) {
              return null
            }
          }
        }
        class Cp extends Kp {
          constructor() {
            super("twitter.com")
          }
          static credential(OO, KO) {
            return xp._fromParams({
              providerId: Cp.PROVIDER_ID,
              signInMethod: Cp.TWITTER_SIGN_IN_METHOD,
              oauthToken: OO,
              oauthTokenSecret: KO
            })
          }
          static credentialFromResult(OO) {
            return Cp.credentialFromTaggedObject(OO)
          }
          static credentialFromError(OO) {
            return Cp.credentialFromTaggedObject(OO.customData || {})
          }
          static credentialFromTaggedObject(OO) {
            let {
              _tokenResponse: KO
            } = OO;
            if (!KO) return null;
            const {
              oauthAccessToken: pO,
              oauthTokenSecret: XO
            } = KO;
            if (!pO || !XO) return null;
            try {
              return Cp.credential(pO, XO)
            } catch (bK) {
              return null
            }
          }
        }
        async function hp(OO, KO) {
          return SO(OO, "POST", "/v1/accounts:signUp", sO(OO, KO))
        }
        Cp.TWITTER_SIGN_IN_METHOD = "twitter.com", Cp.PROVIDER_ID = "twitter.com";
        class Dp {
          constructor(OO) {
            this.user = OO.user, this.providerId = OO.providerId, this._tokenResponse = OO._tokenResponse, this.operationType = OO.operationType
          }
          static async _fromIdTokenResponse(OO, KO, pO) {
            let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
            const bK = await XK._fromIdTokenResponse(OO, pO, XO),
              eO = Mp(pO);
            return new Dp({
              user: bK,
              providerId: eO,
              _tokenResponse: pO,
              operationType: KO
            })
          }
          static async _forOperation(OO, KO, pO) {
            await OO._updateTokensIfNecessary(pO, !0);
            const XO = Mp(pO);
            return new Dp({
              user: OO,
              providerId: XO,
              _tokenResponse: pO,
              operationType: KO
            })
          }
        }

        function Mp(OO) {
          return OO.providerId ? OO.providerId : "phoneNumber" in OO ? "phone" : null
        }
        async function aX(OO) {
          var KO;
          const pO = wK(OO);
          if (await pO._initializationPromise, null === (KO = pO.currentUser) || void 0 === KO ? void 0 : KO.isAnonymous) return new Dp({
            user: pO.currentUser,
            providerId: null,
            operationType: "signIn"
          });
          const XO = await hp(pO, {
              returnSecureToken: !0
            }),
            bK = await Dp._fromIdTokenResponse(pO, "signIn", XO, !0);
          return await pO._updateCurrentUser(bK.user), bK
        }
        class op extends XO.k {
          constructor(OO, KO, pO, XO) {
            var bK;
            super(KO.code, KO.message), this.operationType = pO, this.user = XO, Object.setPrototypeOf(this, op.prototype), this.customData = {
              appName: OO.name,
              tenantId: null !== (bK = OO.tenantId) && void 0 !== bK ? bK : void 0,
              _serverResponse: KO.customData._serverResponse,
              operationType: pO
            }
          }
          static _fromErrorAndOperation(OO, KO, pO, XO) {
            return new op(OO, KO, pO, XO)
          }
        }

        function Fp(OO, KO, pO, XO) {
          return ("reauthenticate" === KO ? pO._getReauthenticationResolver(OO) : pO._getIdTokenResponse(OO)).catch((pO => {
            if ("auth/multi-factor-auth-required" === pO.code) throw op._fromErrorAndOperation(OO, pO, KO, XO);
            throw pO
          }))
        }

        function Vp(OO) {
          return new Set(OO.map((OO => {
            let {
              providerId: KO
            } = OO;
            return KO
          })).filter((OO => !!OO)))
        }
        async function Lp(OO, KO) {
          const pO = (0, XO.N)(OO);
          await zX(!0, pO, KO);
          const {
            providerUserInfo: bK
          } = await async function(OO, KO) {
            return HO(OO, "POST", "/v1/accounts:update", KO)
          }(pO.auth, {
            idToken: await pO.getIdToken(),
            deleteProvider: [KO]
          }), eO = Vp(bK || []);
          return pO.providerData = pO.providerData.filter((OO => eO.has(OO.providerId))), eO.has("phone") || (pO.phoneNumber = null), await pO.auth._persistUserIfCurrent(pO), pO
        }
        async function Qp(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
          const XO = await WO(OO, KO._linkToIdToken(OO.auth, await OO.getIdToken()), pO);
          return Dp._forOperation(OO, "link", XO)
        }
        async function zX(OO, KO, pO) {
          await UO(KO);
          const XO = !1 === OO ? "provider-already-linked" : "no-such-provider";
          yK(Vp(KO.providerData).has(pO) === OO, KO.auth, XO)
        }
        async function Ap(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
          const {
            auth: XO
          } = OO, bK = "reauthenticate";
          try {
            const eO = await WO(OO, Fp(XO, bK, KO, OO), pO);
            yK(eO.idToken, XO, "internal-error");
            const lO = nO(eO.idToken);
            yK(lO, XO, "internal-error");
            const {
              sub: vK
            } = lO;
            return yK(OO.uid === vK, XO, "user-mismatch"), Dp._forOperation(OO, bK, eO)
          } catch (eO) {
            throw "auth/user-not-found" === (null === eO || void 0 === eO ? void 0 : eO.code) && fO(XO, "user-mismatch"), eO
          }
        }
        async function fp(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
          const XO = "signIn",
            bK = await Fp(OO, XO, KO),
            eO = await Dp._fromIdTokenResponse(OO, XO, bK);
          return pO || await OO._updateCurrentUser(eO.user), eO
        }
        async function dp(OO, KO) {
          return fp(wK(OO), KO)
        }
        async function Tp(OO, KO) {
          const pO = (0, XO.N)(OO);
          return await zX(!1, pO, KO.providerId), Qp(pO, KO)
        }
        async function Np(OO, KO) {
          return Ap((0, XO.N)(OO), KO)
        }
        async function Ip(OO, KO) {
          const pO = wK(OO),
            XO = await async function(OO, KO) {
              return SO(OO, "POST", "/v1/accounts:signInWithCustomToken", sO(OO, KO))
            }(pO, {
              token: KO,
              returnSecureToken: !0
            }), bK = await Dp._fromIdTokenResponse(pO, "signIn", XO);
          return await pO._updateCurrentUser(bK.user), bK
        }
        class yX {
          constructor(OO, KO) {
            this.factorId = OO, this.uid = KO.mfaEnrollmentId, this.enrollmentTime = new Date(KO.enrolledAt).toUTCString(), this.displayName = KO.displayName
          }
          static _fromServerResponse(OO, KO) {
            return "phoneInfo" in KO ? gX._fromServerResponse(OO, KO) : "totpInfo" in KO ? upO._fromServerResponse(OO, KO) : fO(OO, "internal-error")
          }
        }
        class gX extends yX {
          constructor(OO) {
            super("phone", OO), this.phoneNumber = OO.phoneInfo
          }
          static _fromServerResponse(OO, KO) {
            return new gX(KO)
          }
        }
        class upO extends yX {
          constructor(OO) {
            super("totp", OO)
          }
          static _fromServerResponse(OO, KO) {
            return new upO(KO)
          }
        }

        function Ep(OO, KO, pO) {
          var XO;
          yK((null === (XO = pO.url) || void 0 === XO ? void 0 : XO.length) > 0, OO, "invalid-continue-uri"), yK("undefined" === typeof pO.dynamicLinkDomain || pO.dynamicLinkDomain.length > 0, OO, "invalid-dynamic-link-domain"), KO.continueUrl = pO.url, KO.dynamicLinkDomain = pO.dynamicLinkDomain, KO.canHandleCodeInApp = pO.handleCodeInApp, pO.iOS && (yK(pO.iOS.bundleId.length > 0, OO, "missing-ios-bundle-id"), KO.iOSBundleId = pO.iOS.bundleId), pO.android && (yK(pO.android.packageName.length > 0, OO, "missing-android-pkg-name"), KO.androidInstallApp = pO.android.installApp, KO.androidMinimumVersionCode = pO.android.minimumVersion, KO.androidPackageName = pO.android.packageName)
        }
        async function jX(OO, KO, pO) {
          var XO;
          const bK = wK(OO),
            eO = {
              requestType: "PASSWORD_RESET",
              email: KO,
              clientType: "CLIENT_TYPE_WEB"
            };
          if (null === (XO = bK._getRecaptchaConfig()) || void 0 === XO ? void 0 : XO.emailPasswordEnabled) {
            const OO = await EK(bK, eO, "getOobCode", !0);
            pO && Ep(bK, OO, pO), await BK(bK, OO)
          } else pO && Ep(bK, eO, pO), await BK(bK, eO).catch((async OO => {
            if ("auth/missing-recaptcha-token" !== OO.code) return Promise.reject(OO);
            {
              console.log("Password resets are protected by reCAPTCHA for this project. Automatically triggering the reCAPTCHA flow and restarting the password reset flow.");
              const OO = await EK(bK, eO, "getOobCode", !0);
              pO && Ep(bK, OO, pO), await BK(bK, OO)
            }
          }))
        }
        async function Yp(OO, KO, pO) {
          await RK((0, XO.N)(OO), {
            oobCode: KO,
            newPassword: pO
          })
        }
        async function wp(OO, KO) {
          await async function(OO, KO) {
            return HO(OO, "POST", "/v1/accounts:update", sO(OO, KO))
          }((0, XO.N)(OO), {
            oobCode: KO
          })
        }
        async function iX(OO, KO) {
          const pO = (0, XO.N)(OO),
            bK = await RK(pO, {
              oobCode: KO
            }),
            eO = bK.requestType;
          switch (yK(eO, pO, "internal-error"), eO) {
            case "EMAIL_SIGNIN":
              break;
            case "VERIFY_AND_CHANGE_EMAIL":
              yK(bK.newEmail, pO, "internal-error");
              break;
            case "REVERT_SECOND_FACTOR_ADDITION":
              yK(bK.mfaInfo, pO, "internal-error");
            default:
              yK(bK.email, pO, "internal-error")
          }
          let lO = null;
          return bK.mfaInfo && (lO = yX._fromServerResponse(wK(pO), bK.mfaInfo)), {
            data: {
              email: ("VERIFY_AND_CHANGE_EMAIL" === bK.requestType ? bK.newEmail : bK.email) || null,
              previousEmail: ("VERIFY_AND_CHANGE_EMAIL" === bK.requestType ? bK.email : bK.newEmail) || null,
              multiFactorInfo: lO
            },
            operation: eO
          }
        }
        async function rX(OO, KO) {
          const {
            data: pO
          } = await iX((0, XO.N)(OO), KO);
          return pO.email
        }
        async function Pp(OO, KO, pO) {
          var XO;
          const bK = wK(OO),
            eO = {
              returnSecureToken: !0,
              email: KO,
              password: pO,
              clientType: "CLIENT_TYPE_WEB"
            };
          let lO;
          if (null === (XO = bK._getRecaptchaConfig()) || void 0 === XO ? void 0 : XO.emailPasswordEnabled) {
            const OO = await EK(bK, eO, "signUpPassword");
            lO = hp(bK, OO)
          } else lO = hp(bK, eO).catch((async OO => {
            if ("auth/missing-recaptcha-token" === OO.code) {
              console.log("Sign-up is protected by reCAPTCHA for this project. Automatically triggering the reCAPTCHA flow and restarting the sign-up flow.");
              const OO = await EK(bK, eO, "signUpPassword");
              return hp(bK, OO)
            }
            return Promise.reject(OO)
          }));
          const vK = await lO.catch((OO => Promise.reject(OO))),
            CO = await Dp._fromIdTokenResponse(bK, "signIn", vK);
          return await bK._updateCurrentUser(CO.user), CO
        }

        function mX(OO, KO, pO) {
          return dp((0, XO.N)(OO), UK.credential(KO, pO))
        }
        async function sp(OO, KO, pO) {
          var XO;
          const bK = wK(OO),
            eO = {
              requestType: "EMAIL_SIGNIN",
              email: KO,
              clientType: "CLIENT_TYPE_WEB"
            };

          function lO(OO, KO) {
            yK(KO.handleCodeInApp, bK, "argument-error"), KO && Ep(bK, OO, KO)
          }
          if (null === (XO = bK._getRecaptchaConfig()) || void 0 === XO ? void 0 : XO.emailPasswordEnabled) {
            const OO = await EK(bK, eO, "getOobCode", !0);
            lO(OO, pO), await ZK(bK, OO)
          } else lO(eO, pO), await ZK(bK, eO).catch((async OO => {
            if ("auth/missing-recaptcha-token" !== OO.code) return Promise.reject(OO);
            {
              console.log("Email link sign-in is protected by reCAPTCHA for this project. Automatically triggering the reCAPTCHA flow and restarting the sign-in flow.");
              const OO = await EK(bK, eO, "getOobCode", !0);
              lO(OO, pO), await ZK(bK, OO)
            }
          }))
        }

        function Hp(OO, KO) {
          const pO = tp.parseLink(KO);
          return "EMAIL_SIGNIN" === (null === pO || void 0 === pO ? void 0 : pO.operation)
        }
        async function Rp(OO, KO, pO) {
          const bK = (0, XO.N)(OO),
            eO = UK.credentialWithLink(KO, pO || EO());
          return yK(eO._tenantId === (bK.tenantId || null), bK, "tenant-id-mismatch"), dp(bK, eO)
        }
        async function Sp(OO, KO) {
          const pO = {
              identifier: KO,
              continueUri: jK() ? EO() : "http://localhost"
            },
            {
              signinMethods: bK
            } = await async function(OO, KO) {
              return HO(OO, "POST", "/v1/accounts:createAuthUri", sO(OO, KO))
            }((0, XO.N)(OO), pO);
          return bK || []
        }
        async function Jp(OO, KO) {
          const pO = (0, XO.N)(OO),
            bK = {
              requestType: "VERIFY_EMAIL",
              idToken: await OO.getIdToken()
            };
          KO && Ep(pO.auth, bK, KO);
          const {
            email: eO
          } = await async function(OO, KO) {
            return cp(OO, KO)
          }(pO.auth, bK);
          eO !== OO.email && await OO.reload()
        }
        async function cX(OO, KO, pO) {
          const bK = (0, XO.N)(OO),
            eO = {
              requestType: "VERIFY_AND_CHANGE_EMAIL",
              idToken: await OO.getIdToken(),
              newEmail: KO
            };
          pO && Ep(bK.auth, eO, pO);
          const {
            email: lO
          } = await async function(OO, KO) {
            return cp(OO, KO)
          }(bK.auth, eO);
          lO !== OO.email && await OO.reload()
        }
        async function Bp(OO, KO) {
          let {
            displayName: pO,
            photoURL: bK
          } = KO;
          if (void 0 === pO && void 0 === bK) return;
          const eO = (0, XO.N)(OO),
            lO = {
              idToken: await eO.getIdToken(),
              displayName: pO,
              photoUrl: bK,
              returnSecureToken: !0
            },
            vK = await WO(eO, async function(OO, KO) {
              return HO(OO, "POST", "/v1/accounts:update", KO)
            }(eO.auth, lO));
          eO.displayName = vK.displayName || null, eO.photoURL = vK.photoUrl || null;
          const CO = eO.providerData.find((OO => {
            let {
              providerId: KO
            } = OO;
            return "password" === KO
          }));
          CO && (CO.displayName = eO.displayName, CO.photoURL = eO.photoURL), await eO._updateTokensIfNecessary(vK)
        }

        function Zp(OO, KO) {
          return qX((0, XO.N)(OO), KO, null)
        }

        function Gp(OO, KO) {
          return qX((0, XO.N)(OO), null, KO)
        }
        async function qX(OO, KO, pO) {
          const {
            auth: XO
          } = OO, bK = {
            idToken: await OO.getIdToken(),
            returnSecureToken: !0
          };
          KO && (bK.email = KO), pO && (bK.password = pO);
          const eO = await WO(OO, SK(XO, bK));
          await OO._updateTokensIfNecessary(eO, !0)
        }
        class xX {
          constructor(OO, KO) {
            let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            this.isNewUser = OO, this.providerId = KO, this.profile = pO
          }
        }
        class np extends xX {
          constructor(OO, KO, pO, XO) {
            super(OO, KO, pO), this.username = XO
          }
        }
        class Wp extends xX {
          constructor(OO, KO) {
            super(OO, "facebook.com", KO)
          }
        }
        class tX extends np {
          constructor(OO, KO) {
            super(OO, "github.com", KO, "string" === typeof(null === KO || void 0 === KO ? void 0 : KO.login) ? null === KO || void 0 === KO ? void 0 : KO.login : null)
          }
        }
        class kX extends xX {
          constructor(OO, KO) {
            super(OO, "google.com", KO)
          }
        }
        class Up extends np {
          constructor(OO, KO, pO) {
            super(OO, "twitter.com", KO, pO)
          }
        }

        function OX(OO) {
          const {
            user: KO,
            _tokenResponse: pO
          } = OO;
          return KO.isAnonymous && !pO ? {
            providerId: null,
            isNewUser: !1,
            profile: null
          } : function(OO) {
            var KO, pO;
            if (!OO) return null;
            const {
              providerId: XO
            } = OO, bK = OO.rawUserInfo ? JSON.parse(OO.rawUserInfo) : {}, eO = OO.isNewUser || "identitytoolkit#SignupNewUserResponse" === OO.kind;
            if (!XO && (null === OO || void 0 === OO ? void 0 : OO.idToken)) {
              const XO = null === (pO = null === (KO = nO(OO.idToken)) || void 0 === KO ? void 0 : KO.firebase) || void 0 === pO ? void 0 : pO.sign_in_provider;
              if (XO) return new xX(eO, "anonymous" !== XO && "custom" !== XO ? XO : null)
            }
            if (!XO) return null;
            switch (XO) {
              case "facebook.com":
                return new Wp(eO, bK);
              case "github.com":
                return new tX(eO, bK);
              case "google.com":
                return new kX(eO, bK);
              case "twitter.com":
                return new Up(eO, bK, OO.screenName || null);
              case "custom":
              case "anonymous":
                return new xX(eO, null);
              default:
                return new xX(eO, XO, bK)
            }
          }(pO)
        }

        function KX(OO, KO) {
          return (0, XO.N)(OO).setPersistence(KO)
        }

        function pX(OO) {
          return wK(OO).initializeRecaptchaConfig()
        }

        function XX(OO, KO, pO, bK) {
          return (0, XO.N)(OO).onIdTokenChanged(KO, pO, bK)
        }

        function bb(OO, KO, pO) {
          return (0, XO.N)(OO).beforeAuthStateChanged(KO, pO)
        }

        function eX(OO, KO, pO, bK) {
          return (0, XO.N)(OO).onAuthStateChanged(KO, pO, bK)
        }

        function lX(OO) {
          (0, XO.N)(OO).useDeviceLanguage()
        }

        function vb(OO, KO) {
          return (0, XO.N)(OO).updateCurrentUser(KO)
        }

        function CX(OO) {
          return (0, XO.N)(OO).signOut()
        }
        async function hX(OO) {
          return (0, XO.N)(OO).delete()
        }
        class DX {
          constructor(OO, KO, pO) {
            this.type = OO, this.credential = KO, this.auth = pO
          }
          static _fromIdtoken(OO, KO) {
            return new DX("enroll", OO, KO)
          }
          static _fromMfaPendingCredential(OO) {
            return new DX("signin", OO)
          }
          toJSON() {
            const OO = "enroll" === this.type ? "idToken" : "pendingCredential";
            return {
              multiFactorSession: {
                [OO]: this.credential
              }
            }
          }
          static fromJSON(OO) {
            var KO, pO;
            if (null === OO || void 0 === OO ? void 0 : OO.multiFactorSession) {
              if (null === (KO = OO.multiFactorSession) || void 0 === KO ? void 0 : KO.pendingCredential) return DX._fromMfaPendingCredential(OO.multiFactorSession.pendingCredential);
              if (null === (pO = OO.multiFactorSession) || void 0 === pO ? void 0 : pO.idToken) return DX._fromIdtoken(OO.multiFactorSession.idToken)
            }
            return null
          }
        }
        class MX {
          constructor(OO, KO, pO) {
            this.session = OO, this.hints = KO, this.signInResolver = pO
          }
          static _fromError(OO, KO) {
            const pO = wK(OO),
              XO = KO.customData._serverResponse,
              bK = (XO.mfaInfo || []).map((OO => yX._fromServerResponse(pO, OO)));
            yK(XO.mfaPendingCredential, pO, "internal-error");
            const eO = DX._fromMfaPendingCredential(XO.mfaPendingCredential);
            return new MX(eO, bK, (async OO => {
              const bK = await OO._process(pO, eO);
              delete XO.mfaInfo, delete XO.mfaPendingCredential;
              const lO = Object.assign(Object.assign({}, XO), {
                idToken: bK.idToken,
                refreshToken: bK.refreshToken
              });
              switch (KO.operationType) {
                case "signIn":
                  const OO = await Dp._fromIdTokenResponse(pO, KO.operationType, lO);
                  return await pO._updateCurrentUser(OO.user), OO;
                case "reauthenticate":
                  return yK(KO.user, pO, "internal-error"), Dp._forOperation(KO.user, KO.operationType, lO);
                default:
                  fO(pO, "internal-error")
              }
            }))
          }
          async resolveSignIn(OO) {
            const KO = OO;
            return this.signInResolver(KO)
          }
        }

        function ab(OO, KO) {
          var pO;
          const bK = (0, XO.N)(OO),
            eO = KO;
          return yK(KO.customData.operationType, bK, "argument-error"), yK(null === (pO = eO.customData._serverResponse) || void 0 === pO ? void 0 : pO.mfaPendingCredential, bK, "argument-error"), MX._fromError(bK, eO)
        }
        class oX {
          constructor(OO) {
            this.user = OO, this.enrolledFactors = [], OO._onReload((KO => {
              KO.mfaInfo && (this.enrolledFactors = KO.mfaInfo.map((KO => yX._fromServerResponse(OO.auth, KO))))
            }))
          }
          static _fromUser(OO) {
            return new oX(OO)
          }
          async getSession() {
            return DX._fromIdtoken(await this.user.getIdToken(), this.user.auth)
          }
          async enroll(OO, KO) {
            const pO = OO,
              XO = await this.getSession(),
              bK = await WO(this.user, pO._process(this.user.auth, XO, KO));
            return await this.user._updateTokensIfNecessary(bK), this.user.reload()
          }
          async unenroll(OO) {
            const KO = "string" === typeof OO ? OO : OO.uid,
              pO = await this.user.getIdToken();
            try {
              const OO = await WO(this.user, (XO = this.user.auth, bK = {
                idToken: pO,
                mfaEnrollmentId: KO
              }, HO(XO, "POST", "/v2/accounts/mfaEnrollment:withdraw", sO(XO, bK))));
              this.enrolledFactors = this.enrolledFactors.filter((OO => {
                let {
                  uid: pO
                } = OO;
                return pO !== KO
              })), await this.user._updateTokensIfNecessary(OO), await this.user.reload()
            } catch (eO) {
              throw eO
            }
            var XO, bK
          }
        }
        const FX = new WeakMap;

        function VX(OO) {
          const KO = (0, XO.N)(OO);
          return FX.has(KO) || FX.set(KO, oX._fromUser(KO)), FX.get(KO)
        }
        const LX = "__sak";
        class QX {
          constructor(OO, KO) {
            this.storageRetriever = OO, this.type = KO
          }
          _isAvailable() {
            try {
              return this.storage ? (this.storage.setItem(LX, "1"), this.storage.removeItem(LX), Promise.resolve(!0)) : Promise.resolve(!1)
            } catch (OO) {
              return Promise.resolve(!1)
            }
          }
          _set(OO, KO) {
            return this.storage.setItem(OO, JSON.stringify(KO)), Promise.resolve()
          }
          _get(OO) {
            const KO = this.storage.getItem(OO);
            return Promise.resolve(KO ? JSON.parse(KO) : null)
          }
          _remove(OO) {
            return this.storage.removeItem(OO), Promise.resolve()
          }
          get storage() {
            return this.storageRetriever()
          }
        }
        class zb extends QX {
          constructor() {
            super((() => window.localStorage), "LOCAL"), this.boundEventHandler = (OO, KO) => this.onStorageEvent(OO, KO), this.listeners = {}, this.localCache = {}, this.pollTimer = null, this.safariLocalStorageNotSynced = function() {
              const OO = (0, XO.P)();
              return ap(OO) || zp(OO)
            }() && function() {
              try {
                return !(!window || window === window.top)
              } catch (OO) {
                return !1
              }
            }(), this.fallbackToPolling = AK(), this._shouldAllowMigration = !0
          }
          forAllChangedKeys(OO) {
            for (const KO of Object.keys(this.listeners)) {
              const pO = this.storage.getItem(KO),
                XO = this.localCache[KO];
              pO !== XO && OO(KO, XO, pO)
            }
          }
          onStorageEvent(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if (!OO.key) return void this.forAllChangedKeys(((OO, KO, pO) => {
              this.notifyListeners(OO, pO)
            }));
            const pO = OO.key;
            if (KO ? this.detachListener() : this.stopPolling(), this.safariLocalStorageNotSynced) {
              const XO = this.storage.getItem(pO);
              if (OO.newValue !== XO) null !== OO.newValue ? this.storage.setItem(pO, OO.newValue) : this.storage.removeItem(pO);
              else if (this.localCache[pO] === OO.newValue && !KO) return
            }
            const bK = () => {
                const OO = this.storage.getItem(pO);
                (KO || this.localCache[pO] !== OO) && this.notifyListeners(pO, OO)
              },
              eO = this.storage.getItem(pO);
            (0, XO.V)() && 10 === document.documentMode && eO !== OO.newValue && OO.newValue !== OO.oldValue ? setTimeout(bK, 10) : bK()
          }
          notifyListeners(OO, KO) {
            this.localCache[OO] = KO;
            const pO = this.listeners[OO];
            if (pO)
              for (const XO of Array.from(pO)) XO(KO ? JSON.parse(KO) : KO)
          }
          startPolling() {
            this.stopPolling(), this.pollTimer = setInterval((() => {
              this.forAllChangedKeys(((OO, KO, pO) => {
                this.onStorageEvent(new StorageEvent("storage", {
                  key: OO,
                  oldValue: KO,
                  newValue: pO
                }), !0)
              }))
            }), 1e3)
          }
          stopPolling() {
            this.pollTimer && (clearInterval(this.pollTimer), this.pollTimer = null)
          }
          attachListener() {
            window.addEventListener("storage", this.boundEventHandler)
          }
          detachListener() {
            window.removeEventListener("storage", this.boundEventHandler)
          }
          _addListener(OO, KO) {
            0 === Object.keys(this.listeners).length && (this.fallbackToPolling ? this.startPolling() : this.attachListener()), this.listeners[OO] || (this.listeners[OO] = new Set, this.localCache[OO] = this.storage.getItem(OO)), this.listeners[OO].add(KO)
          }
          _removeListener(OO, KO) {
            this.listeners[OO] && (this.listeners[OO].delete(KO), 0 === this.listeners[OO].size && delete this.listeners[OO]), 0 === Object.keys(this.listeners).length && (this.detachListener(), this.stopPolling())
          }
          async _set(OO, KO) {
            await super._set(OO, KO), this.localCache[OO] = JSON.stringify(KO)
          }
          async _get(OO) {
            const KO = await super._get(OO);
            return this.localCache[OO] = JSON.stringify(KO), KO
          }
          async _remove(OO) {
            await super._remove(OO), delete this.localCache[OO]
          }
        }
        zb.type = "LOCAL";
        const AX = zb;
        class fX extends QX {
          constructor() {
            super((() => window.sessionStorage), "SESSION")
          }
          _addListener(OO, KO) {}
          _removeListener(OO, KO) {}
        }
        fX.type = "SESSION";
        const dX = fX;
        class TX {
          constructor(OO) {
            this.eventTarget = OO, this.handlersMap = {}, this.boundEventHandler = this.handleEvent.bind(this)
          }
          static _getInstance(OO) {
            const KO = this.receivers.find((KO => KO.isListeningto(OO)));
            if (KO) return KO;
            const pO = new TX(OO);
            return this.receivers.push(pO), pO
          }
          isListeningto(OO) {
            return this.eventTarget === OO
          }
          async handleEvent(OO) {
            const KO = OO,
              {
                eventId: pO,
                eventType: XO,
                data: bK
              } = KO.data,
              eO = this.handlersMap[XO];
            if (!(null === eO || void 0 === eO ? void 0 : eO.size)) return;
            KO.ports[0].postMessage({
              status: "ack",
              eventId: pO,
              eventType: XO
            });
            const lO = Array.from(eO).map((async OO => OO(KO.origin, bK))),
              vK = await
            function(OO) {
              return Promise.all(OO.map((async OO => {
                try {
                  return {
                    fulfilled: !0,
                    value: await OO
                  }
                } catch (KO) {
                  return {
                    fulfilled: !1,
                    reason: KO
                  }
                }
              })))
            }(lO);
            KO.ports[0].postMessage({
              status: "done",
              eventId: pO,
              eventType: XO,
              response: vK
            })
          }
          _subscribe(OO, KO) {
            0 === Object.keys(this.handlersMap).length && this.eventTarget.addEventListener("message", this.boundEventHandler), this.handlersMap[OO] || (this.handlersMap[OO] = new Set), this.handlersMap[OO].add(KO)
          }
          _unsubscribe(OO, KO) {
            this.handlersMap[OO] && KO && this.handlersMap[OO].delete(KO), KO && 0 !== this.handlersMap[OO].size || delete this.handlersMap[OO], 0 === Object.keys(this.handlersMap).length && this.eventTarget.removeEventListener("message", this.boundEventHandler)
          }
        }

        function NX() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
            KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10,
            pO = "";
          for (let XO = 0; XO < KO; XO++) pO += Math.floor(10 * Math.random());
          return OO + pO
        }
        TX.receivers = [];
        class IX {
          constructor(OO) {
            this.target = OO, this.handlers = new Set
          }
          removeMessageHandler(OO) {
            OO.messageChannel && (OO.messageChannel.port1.removeEventListener("message", OO.YV), OO.messageChannel.port1.close()), this.handlers.delete(OO)
          }
          async _send(OO, KO) {
            let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 50;
            const XO = "undefined" !== typeof MessageChannel ? new MessageChannel : null;
            if (!XO) throw new Error("connection_unavailable");
            let bK, eO;
            return new Promise(((lO, vK) => {
              const CO = NX("", 20);
              XO.port1.start();
              const hO = setTimeout((() => {
                vK(new Error("unsupported_event"))
              }), pO);
              eO = {
                messageChannel: XO,
                YV(OO) {
                  const KO = OO;
                  if (KO.data.eventId === CO) switch (KO.data.status) {
                    case "ack":
                      clearTimeout(hO), bK = setTimeout((() => {
                        vK(new Error("timeout"))
                      }), 3e3);
                      break;
                    case "done":
                      clearTimeout(bK), lO(KO.data.response);
                      break;
                    default:
                      clearTimeout(hO), clearTimeout(bK), vK(new Error("invalid_response"))
                  }
                }
              }, this.handlers.add(eO), XO.port1.addEventListener("message", eO.YV), this.target.postMessage({
                eventType: OO,
                eventId: CO,
                data: KO
              }, [XO.port2])
            })).finally((() => {
              eO && this.removeMessageHandler(eO)
            }))
          }
        }

        function yb() {
          return window
        }

        function gb() {
          return "undefined" !== typeof yb().WorkerGlobalScope && "function" === typeof yb().importScripts
        }
        const uX = "firebaseLocalStorageDb",
          EX = "firebaseLocalStorage",
          jb = "fbase_key";
        class YX {
          constructor(OO) {
            this.request = OO
          }
          toPromise() {
            return new Promise(((OO, KO) => {
              this.request.addEventListener("success", (() => {
                OO(this.request.result)
              })), this.request.addEventListener("error", (() => {
                KO(this.request.error)
              }))
            }))
          }
        }

        function wX(OO, KO) {
          return OO.transaction([EX], KO ? "readwrite" : "readonly").objectStore(EX)
        }

        function ib() {
          const OO = indexedDB.open(uX, 1);
          return new Promise(((KO, pO) => {
            OO.addEventListener("error", (() => {
              pO(OO.error)
            })), OO.addEventListener("upgradeneeded", (() => {
              const KO = OO.result;
              try {
                KO.createObjectStore(EX, {
                  keyPath: jb
                })
              } catch (XO) {
                pO(XO)
              }
            })), OO.addEventListener("success", (async () => {
              const pO = OO.result;
              pO.objectStoreNames.contains(EX) ? KO(pO) : (pO.close(), await
                function() {
                  const OO = indexedDB.deleteDatabase(uX);
                  return new YX(OO).toPromise()
                }(), KO(await ib()))
            }))
          }))
        }
        async function rb(OO, KO, pO) {
          const XO = wX(OO, !0).put({
            [jb]: KO,
            value: pO
          });
          return new YX(XO).toPromise()
        }

        function PX(OO, KO) {
          const pO = wX(OO, !0).delete(KO);
          return new YX(pO).toPromise()
        }
        class mb {
          constructor() {
            this.type = "LOCAL", this._shouldAllowMigration = !0, this.listeners = {}, this.localCache = {}, this.pollTimer = null, this.pendingWrites = 0, this.receiver = null, this.sender = null, this.serviceWorkerReceiverAvailable = !1, this.activeServiceWorker = null, this._workerInitializationPromise = this.initializeServiceWorkerMessaging().then((() => {}), (() => {}))
          }
          async _openDb() {
            return this.db || (this.db = await ib()), this.db
          }
          async _withRetries(OO) {
            let KO = 0;
            for (;;) try {
              const KO = await this._openDb();
              return await OO(KO)
            } catch (pO) {
              if (KO++ > 3) throw pO;
              this.db && (this.db.close(), this.db = void 0)
            }
          }
          async initializeServiceWorkerMessaging() {
            return gb() ? this.initializeReceiver() : this.initializeSender()
          }
          async initializeReceiver() {
            this.receiver = TX._getInstance(gb() ? self : null), this.receiver._subscribe("keyChanged", (async (OO, KO) => ({
              keyProcessed: (await this._poll()).includes(KO.key)
            }))), this.receiver._subscribe("ping", (async (OO, KO) => ["keyChanged"]))
          }
          async initializeSender() {
            var OO, KO;
            if (this.activeServiceWorker = await async function() {
                if (!(null === navigator || void 0 === navigator ? void 0 : navigator.serviceWorker)) return null;
                try {
                  return (await navigator.serviceWorker.ready).active
                } catch (OO) {
                  return null
                }
              }(), !this.activeServiceWorker) return;
            this.sender = new IX(this.activeServiceWorker);
            const pO = await this.sender._send("ping", {}, 800);
            pO && (null === (OO = pO[0]) || void 0 === OO ? void 0 : OO.fulfilled) && (null === (KO = pO[0]) || void 0 === KO ? void 0 : KO.value.includes("keyChanged")) && (this.serviceWorkerReceiverAvailable = !0)
          }
          async notifyServiceWorker(OO) {
            if (this.sender && this.activeServiceWorker && function() {
                var OO;
                return (null === (OO = null === navigator || void 0 === navigator ? void 0 : navigator.serviceWorker) || void 0 === OO ? void 0 : OO.controller) || null
              }() === this.activeServiceWorker) try {
              await this.sender._send("keyChanged", {
                key: OO
              }, this.serviceWorkerReceiverAvailable ? 800 : 50)
            } catch (KO) {}
          }
          async _isAvailable() {
            try {
              if (!indexedDB) return !1;
              const OO = await ib();
              return await rb(OO, LX, "1"), await PX(OO, LX), !0
            } catch (OO) {}
            return !1
          }
          async _withPendingWrite(OO) {
            this.pendingWrites++;
            try {
              await OO()
            } finally {
              this.pendingWrites--
            }
          }
          async _set(OO, KO) {
            return this._withPendingWrite((async () => (await this._withRetries((pO => rb(pO, OO, KO))), this.localCache[OO] = KO, this.notifyServiceWorker(OO))))
          }
          async _get(OO) {
            const KO = await this._withRetries((KO => async function(OO, KO) {
              const pO = wX(OO, !1).get(KO),
                XO = await new YX(pO).toPromise();
              return void 0 === XO ? null : XO.value
            }(KO, OO)));
            return this.localCache[OO] = KO, KO
          }
          async _remove(OO) {
            return this._withPendingWrite((async () => (await this._withRetries((KO => PX(KO, OO))), delete this.localCache[OO], this.notifyServiceWorker(OO))))
          }
          async _poll() {
            const OO = await this._withRetries((OO => {
              const KO = wX(OO, !1).getAll();
              return new YX(KO).toPromise()
            }));
            if (!OO) return [];
            if (0 !== this.pendingWrites) return [];
            const KO = [],
              pO = new Set;
            for (const {
                fbase_key: XO,
                value: bK
              }
              of OO) pO.add(XO), JSON.stringify(this.localCache[XO]) !== JSON.stringify(bK) && (this.notifyListeners(XO, bK), KO.push(XO));
            for (const XO of Object.keys(this.localCache)) this.localCache[XO] && !pO.has(XO) && (this.notifyListeners(XO, null), KO.push(XO));
            return KO
          }
          notifyListeners(OO, KO) {
            this.localCache[OO] = KO;
            const pO = this.listeners[OO];
            if (pO)
              for (const XO of Array.from(pO)) XO(KO)
          }
          startPolling() {
            this.stopPolling(), this.pollTimer = setInterval((async () => this._poll()), 800)
          }
          stopPolling() {
            this.pollTimer && (clearInterval(this.pollTimer), this.pollTimer = null)
          }
          _addListener(OO, KO) {
            0 === Object.keys(this.listeners).length && this.startPolling(), this.listeners[OO] || (this.listeners[OO] = new Set, this._get(OO)), this.listeners[OO].add(KO)
          }
          _removeListener(OO, KO) {
            this.listeners[OO] && (this.listeners[OO].delete(KO), 0 === this.listeners[OO].size && delete this.listeners[OO]), 0 === Object.keys(this.listeners).length && this.stopPolling()
          }
        }
        mb.type = "LOCAL";
        const sX = mb;
        const HX = 1e12;
        class RX {
          constructor(OO) {
            this.auth = OO, this.counter = HX, this._widgets = new Map
          }
          render(OO, KO) {
            const pO = this.counter;
            return this._widgets.set(pO, new SX(OO, this.auth.name, KO || {})), this.counter++, pO
          }
          reset(OO) {
            var KO;
            const pO = OO || HX;
            null === (KO = this._widgets.get(pO)) || void 0 === KO || KO.delete(), this._widgets.delete(pO)
          }
          getResponse(OO) {
            var KO;
            const pO = OO || HX;
            return (null === (KO = this._widgets.get(pO)) || void 0 === KO ? void 0 : KO.getResponse()) || ""
          }
          async execute(OO) {
            var KO;
            const pO = OO || HX;
            return null === (KO = this._widgets.get(pO)) || void 0 === KO || KO.execute(), ""
          }
        }
        class SX {
          constructor(OO, KO, pO) {
            this.params = pO, this.timerId = null, this.deleted = !1, this.responseToken = null, this.clickHandler = () => {
              this.execute()
            };
            const XO = "string" === typeof OO ? document.getElementById(OO) : OO;
            yK(XO, "argument-error", {
              appName: KO
            }), this.container = XO, this.isVisible = "invisible" !== this.params.size, this.isVisible ? this.execute() : this.container.addEventListener("click", this.clickHandler)
          }
          getResponse() {
            return this.checkIfDeleted(), this.responseToken
          }
          delete() {
            this.checkIfDeleted(), this.deleted = !0, this.timerId && (clearTimeout(this.timerId), this.timerId = null), this.container.removeEventListener("click", this.clickHandler)
          }
          execute() {
            this.checkIfDeleted(), this.timerId || (this.timerId = window.setTimeout((() => {
              this.responseToken = function(OO) {
                const KO = [],
                  pO = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                for (let XO = 0; XO < OO; XO++) KO.push(pO.charAt(Math.floor(Math.random() * pO.length)));
                return KO.join("")
              }(50);
              const {
                callback: OO,
                "expired-callback": KO
              } = this.params;
              if (OO) try {
                OO(this.responseToken)
              } catch (pO) {}
              this.timerId = window.setTimeout((() => {
                if (this.timerId = null, this.responseToken = null, KO) try {
                  KO()
                } catch (pO) {}
                this.isVisible && this.execute()
              }), 6e4)
            }), 500))
          }
          checkIfDeleted() {
            if (this.deleted) throw new Error("reCAPTCHA mock was already deleted!")
          }
        }
        const JX = gp("rcb"),
          cb = new wO(3e4, 6e4);
        class BX {
          constructor() {
            var OO;
            this.hostLanguage = "", this.counter = 0, this.librarySeparatelyLoaded = !!(null === (OO = yb().grecaptcha) || void 0 === OO ? void 0 : OO.render)
          }
          load(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
            return yK(function(OO) {
              return OO.length <= 6 && /^\s*[a-zA-Z0-9\-]*\s*$/.test(OO)
            }(KO), OO, "argument-error"), this.shouldResolveImmediately(KO) && TK(yb().grecaptcha) ? Promise.resolve(yb().grecaptcha) : new Promise(((pO, bK) => {
              const eO = yb().setTimeout((() => {
                bK(dO(OO, "network-request-failed"))
              }), cb.get());
              yb()[JX] = () => {
                yb().clearTimeout(eO), delete yb()[JX];
                const XO = yb().grecaptcha;
                if (!XO || !TK(XO)) return void bK(dO(OO, "internal-error"));
                const lO = XO.render;
                XO.render = (OO, KO) => {
                  const pO = lO(OO, KO);
                  return this.counter++, pO
                }, this.hostLanguage = KO, pO(XO)
              };
              yp(`https://www.google.com/recaptcha/api.js??${(0,XO.gb)({onload:JX,render:"explicit",hl:KO})}`).catch((() => {
                clearTimeout(eO), bK(dO(OO, "internal-error"))
              }))
            }))
          }
          clearedOneInstance() {
            this.counter--
          }
          shouldResolveImmediately(OO) {
            var KO;
            return !!(null === (KO = yb().grecaptcha) || void 0 === KO ? void 0 : KO.render) && (OO === this.hostLanguage || this.counter > 0 || this.librarySeparatelyLoaded)
          }
        }
        class ZX {
          async load(OO) {
            return new RX(OO)
          }
          clearedOneInstance() {}
        }
        const GX = "recaptcha",
          qb = {
            theme: "light",
            type: "image"
          };
        class xb {
          constructor(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Object.assign({}, qb),
              pO = arguments.length > 2 ? arguments[2] : void 0;
            this.parameters = KO, this.type = GX, this.destroyed = !1, this.widgetId = null, this.tokenChangeListeners = new Set, this.renderPromise = null, this.recaptcha = null, this.auth = wK(pO), this.isInvisible = "invisible" === this.parameters.size, yK("undefined" !== typeof document, this.auth, "operation-not-supported-in-this-environment");
            const XO = "string" === typeof OO ? document.getElementById(OO) : OO;
            yK(XO, this.auth, "argument-error"), this.container = XO, this.parameters.callback = this.makeTokenCallback(this.parameters.callback), this._recaptchaLoader = this.auth.settings.appVerificationDisabledForTesting ? new ZX : new BX, this.validateStartingState()
          }
          async verify() {
            this.assertNotDestroyed();
            const OO = await this.render(),
              KO = this.getAssertedRecaptcha(),
              pO = KO.getResponse(OO);
            return pO || new Promise((pO => {
              const XO = OO => {
                OO && (this.tokenChangeListeners.delete(XO), pO(OO))
              };
              this.tokenChangeListeners.add(XO), this.isInvisible && KO.execute(OO)
            }))
          }
          render() {
            try {
              this.assertNotDestroyed()
            } catch (OO) {
              return Promise.reject(OO)
            }
            return this.renderPromise || (this.renderPromise = this.makeRenderPromise().catch((OO => {
              throw this.renderPromise = null, OO
            }))), this.renderPromise
          }
          _reset() {
            this.assertNotDestroyed(), null !== this.widgetId && this.getAssertedRecaptcha().reset(this.widgetId)
          }
          clear() {
            this.assertNotDestroyed(), this.destroyed = !0, this._recaptchaLoader.clearedOneInstance(), this.isInvisible || this.container.childNodes.forEach((OO => {
              this.container.removeChild(OO)
            }))
          }
          validateStartingState() {
            yK(!this.parameters.sitekey, this.auth, "argument-error"), yK(this.isInvisible || !this.container.hasChildNodes(), this.auth, "argument-error"), yK("undefined" !== typeof document, this.auth, "operation-not-supported-in-this-environment")
          }
          makeTokenCallback(OO) {
            return KO => {
              if (this.tokenChangeListeners.forEach((OO => OO(KO))), "function" === typeof OO) OO(KO);
              else if ("string" === typeof OO) {
                const pO = yb()[OO];
                "function" === typeof pO && pO(KO)
              }
            }
          }
          assertNotDestroyed() {
            yK(!this.destroyed, this.auth, "internal-error")
          }
          async makeRenderPromise() {
            if (await this.init(), !this.widgetId) {
              let OO = this.container;
              if (!this.isInvisible) {
                const KO = document.createElement("div");
                OO.appendChild(KO), OO = KO
              }
              this.widgetId = this.getAssertedRecaptcha().render(OO, this.parameters)
            }
            return this.widgetId
          }
          async init() {
            yK(jK() && !gb(), this.auth, "internal-error"), await
            function() {
              let OO = null;
              return new Promise((KO => {
                "complete" !== document.readyState ? (OO = () => KO(), window.addEventListener("load", OO)) : KO()
              })).catch((KO => {
                throw OO && window.removeEventListener("load", OO), KO
              }))
            }(), this.recaptcha = await this._recaptchaLoader.load(this.auth, this.auth.languageCode || void 0);
            const OO = await async function(OO) {
              return (await HO(OO, "GET", "/v1/recaptchaParams")).recaptchaSiteKey || ""
            }(this.auth);
            yK(OO, this.auth, "internal-error"), this.parameters.sitekey = OO
          }
          getAssertedRecaptcha() {
            return yK(this.recaptcha, this.auth, "internal-error"), this.recaptcha
          }
        }
        class nX {
          constructor(OO, KO) {
            this.verificationId = OO, this.onConfirmation = KO
          }
          confirm(OO) {
            const KO = WK._fromVerification(this.verificationId, OO);
            return this.onConfirmation(KO)
          }
        }
        async function WX(OO, KO, pO) {
          const bK = wK(OO),
            eO = await UX(bK, KO, (0, XO.N)(pO));
          return new nX(eO, (OO => dp(bK, OO)))
        }
        async function tb(OO, KO, pO) {
          const bK = (0, XO.N)(OO);
          await zX(!1, bK, "phone");
          const eO = await UX(bK.auth, KO, (0, XO.N)(pO));
          return new nX(eO, (OO => Tp(bK, OO)))
        }
        async function kb(OO, KO, pO) {
          const bK = (0, XO.N)(OO),
            eO = await UX(bK.auth, KO, (0, XO.N)(pO));
          return new nX(eO, (OO => Np(bK, OO)))
        }
        async function UX(OO, KO, pO) {
          var XO;
          const bK = await pO.verify();
          try {
            let eO;
            if (yK("string" === typeof bK, OO, "argument-error"), yK(pO.type === GX, OO, "argument-error"), eO = "string" === typeof KO ? {
                phoneNumber: KO
              } : KO, "session" in eO) {
              const KO = eO.session;
              if ("phoneNumber" in eO) {
                yK("enroll" === KO.type, OO, "internal-error");
                const pO = await
                function(OO, KO) {
                  return HO(OO, "POST", "/v2/accounts/mfaEnrollment:start", sO(OO, KO))
                }(OO, {
                  idToken: KO.credential,
                  phoneEnrollmentInfo: {
                    phoneNumber: eO.phoneNumber,
                    recaptchaToken: bK
                  }
                });
                return pO.phoneSessionInfo.sessionInfo
              } {
                yK("signin" === KO.type, OO, "internal-error");
                const pO = (null === (XO = eO.multiFactorHint) || void 0 === XO ? void 0 : XO.uid) || eO.multiFactorUid;
                yK(pO, OO, "missing-multi-factor-info");
                const lO = await
                function(OO, KO) {
                  return HO(OO, "POST", "/v2/accounts/mfaSignIn:start", sO(OO, KO))
                }(OO, {
                  mfaPendingCredential: KO.credential,
                  mfaEnrollmentId: pO,
                  phoneSignInInfo: {
                    recaptchaToken: bK
                  }
                });
                return lO.phoneResponseInfo.sessionInfo
              }
            } {
              const {
                sessionInfo: KO
              } = await async function(OO, KO) {
                return HO(OO, "POST", "/v1/accounts:sendVerificationCode", sO(OO, KO))
              }(OO, {
                phoneNumber: eO.phoneNumber,
                recaptchaToken: bK
              });
              return KO
            }
          } finally {
            pO._reset()
          }
        }
        async function Ob(OO, KO) {
          await Qp((0, XO.N)(OO), KO)
        }
        class Kb {
          constructor(OO) {
            this.providerId = Kb.PROVIDER_ID, this.auth = wK(OO)
          }
          verifyPhoneNumber(OO, KO) {
            return UX(this.auth, OO, (0, XO.N)(KO))
          }
          static credential(OO, KO) {
            return WK._fromVerification(OO, KO)
          }
          static credentialFromResult(OO) {
            const KO = OO;
            return Kb.credentialFromTaggedObject(KO)
          }
          static credentialFromError(OO) {
            return Kb.credentialFromTaggedObject(OO.customData || {})
          }
          static credentialFromTaggedObject(OO) {
            let {
              _tokenResponse: KO
            } = OO;
            if (!KO) return null;
            const {
              phoneNumber: pO,
              temporaryProof: XO
            } = KO;
            return pO && XO ? WK._fromTokenResponse(pO, XO) : null
          }
        }

        function pb(OO, KO) {
          return KO ? eK(KO) : (yK(OO._popupRedirectResolver, OO, "argument-error"), OO._popupRedirectResolver)
        }
        Kb.PROVIDER_ID = "phone", Kb.PHONE_SIGN_IN_METHOD = "phone";
        class Xb extends HK {
          constructor(OO) {
            super("custom", "custom"), this.params = OO
          }
          _getIdTokenResponse(OO) {
            return qp(OO, this._buildIdpRequest())
          }
          _linkToIdToken(OO, KO) {
            return qp(OO, this._buildIdpRequest(KO))
          }
          _getReauthenticationResolver(OO) {
            return qp(OO, this._buildIdpRequest())
          }
          _buildIdpRequest(OO) {
            const KO = {
              requestUri: this.params.requestUri,
              sessionId: this.params.sessionId,
              postBody: this.params.postBody,
              tenantId: this.params.tenantId,
              pendingToken: this.params.pendingToken,
              returnSecureToken: !0,
              returnIdpCredential: !0
            };
            return OO && (KO.idToken = OO), KO
          }
        }

        function be(OO) {
          return fp(OO.auth, new Xb(OO), OO.bypassAuthState)
        }

        function eb(OO) {
          const {
            auth: KO,
            user: pO
          } = OO;
          return yK(pO, KO, "internal-error"), Ap(pO, new Xb(OO), OO.bypassAuthState)
        }
        async function lb(OO) {
          const {
            auth: KO,
            user: pO
          } = OO;
          return yK(pO, KO, "internal-error"), Qp(pO, new Xb(OO), OO.bypassAuthState)
        }
        class ve {
          constructor(OO, KO, pO, XO) {
            let bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
            this.auth = OO, this.resolver = pO, this.user = XO, this.bypassAuthState = bK, this.pendingPromise = null, this.eventManager = null, this.filter = Array.isArray(KO) ? KO : [KO]
          }
          execute() {
            return new Promise((async (OO, KO) => {
              this.pendingPromise = {
                resolve: OO,
                reject: KO
              };
              try {
                this.eventManager = await this.resolver._initialize(this.auth), await this.onExecution(), this.eventManager.registerConsumer(this)
              } catch (pO) {
                this.reject(pO)
              }
            }))
          }
          async onAuthEvent(OO) {
            const {
              urlResponse: KO,
              sessionId: pO,
              postBody: XO,
              tenantId: bK,
              error: eO,
              type: lO
            } = OO;
            if (eO) return void this.reject(eO);
            const vK = {
              auth: this.auth,
              requestUri: KO,
              sessionId: pO,
              tenantId: bK || void 0,
              postBody: XO || void 0,
              user: this.user,
              bypassAuthState: this.bypassAuthState
            };
            try {
              this.resolve(await this.getIdpTask(lO)(vK))
            } catch (CO) {
              this.reject(CO)
            }
          }
          onError(OO) {
            this.reject(OO)
          }
          getIdpTask(OO) {
            switch (OO) {
              case "signInViaPopup":
              case "signInViaRedirect":
                return be;
              case "linkViaPopup":
              case "linkViaRedirect":
                return lb;
              case "reauthViaPopup":
              case "reauthViaRedirect":
                return eb;
              default:
                fO(this.auth, "internal-error")
            }
          }
          resolve(OO) {
            uO(this.pendingPromise, "Pending promise was never set"), this.pendingPromise.resolve(OO), this.unregisterAndCleanUp()
          }
          reject(OO) {
            uO(this.pendingPromise, "Pending promise was never set"), this.pendingPromise.reject(OO), this.unregisterAndCleanUp()
          }
          unregisterAndCleanUp() {
            this.eventManager && this.eventManager.unregisterConsumer(this), this.pendingPromise = null, this.cleanUp()
          }
        }
        const Cb = new wO(2e3, 1e4);
        async function hb(OO, KO, pO) {
          const XO = wK(OO);
          NO(OO, KO, Op);
          const bK = pb(XO, pO);
          return new ae(XO, "signInViaPopup", KO, bK).executeNotNull()
        }
        async function Db(OO, KO, pO) {
          const bK = (0, XO.N)(OO);
          NO(bK.auth, KO, Op);
          const eO = pb(bK.auth, pO);
          return new ae(bK.auth, "reauthViaPopup", KO, eO, bK).executeNotNull()
        }
        async function Mb(OO, KO, pO) {
          const bK = (0, XO.N)(OO);
          NO(bK.auth, KO, Op);
          const eO = pb(bK.auth, pO);
          return new ae(bK.auth, "linkViaPopup", KO, eO, bK).executeNotNull()
        }
        class ae extends ve {
          constructor(OO, KO, pO, XO, bK) {
            super(OO, KO, XO, bK), this.provider = pO, this.authWindow = null, this.pollId = null, ae.currentPopupAction && ae.currentPopupAction.cancel(), ae.currentPopupAction = this
          }
          async executeNotNull() {
            const OO = await this.execute();
            return yK(OO, this.auth, "internal-error"), OO
          }
          async onExecution() {
            uO(1 === this.filter.length, "Popup operations only handle one event");
            const OO = NX();
            this.authWindow = await this.resolver._openPopup(this.auth, this.provider, this.filter[0], OO), this.authWindow.associatedEvent = OO, this.resolver._originValidation(this.auth).catch((OO => {
              this.reject(OO)
            })), this.resolver._isIframeWebStorageSupported(this.auth, (OO => {
              OO || this.reject(dO(this.auth, "web-storage-unsupported"))
            })), this.pollUserCancellation()
          }
          get eventId() {
            var OO;
            return (null === (OO = this.authWindow) || void 0 === OO ? void 0 : OO.associatedEvent) || null
          }
          cancel() {
            this.reject(dO(this.auth, "cancelled-popup-request"))
          }
          cleanUp() {
            this.authWindow && this.authWindow.close(), this.pollId && window.clearTimeout(this.pollId), this.authWindow = null, this.pollId = null, ae.currentPopupAction = null
          }
          pollUserCancellation() {
            const OO = () => {
              var KO, pO;
              (null === (pO = null === (KO = this.authWindow) || void 0 === KO ? void 0 : KO.window) || void 0 === pO ? void 0 : pO.closed) ? this.pollId = window.setTimeout((() => {
                this.pollId = null, this.reject(dO(this.auth, "popup-closed-by-user"))
              }), 8e3): this.pollId = window.setTimeout(OO, Cb.get())
            };
            OO()
          }
        }
        ae.currentPopupAction = null;
        const ob = "pendingRedirect",
          Fb = new Map;
        class Vb extends ve {
          constructor(OO, KO) {
            super(OO, ["signInViaRedirect", "linkViaRedirect", "reauthViaRedirect", "unknown"], KO, void 0, arguments.length > 2 && void 0 !== arguments[2] && arguments[2]), this.eventId = null
          }
          async execute() {
            let OO = Fb.get(this.auth._key());
            if (!OO) {
              try {
                const KO = await async function(OO, KO) {
                  const pO = Ab(KO),
                    XO = ze(OO);
                  if (!await XO._isAvailable()) return !1;
                  const bK = "true" === await XO._get(pO);
                  return await XO._remove(pO), bK
                }(this.resolver, this.auth) ? await super.execute() : null;
                OO = () => Promise.resolve(KO)
              } catch (KO) {
                OO = () => Promise.reject(KO)
              }
              Fb.set(this.auth._key(), OO)
            }
            return this.bypassAuthState || Fb.set(this.auth._key(), (() => Promise.resolve(null))), OO()
          }
          async onAuthEvent(OO) {
            if ("signInViaRedirect" === OO.type) return super.onAuthEvent(OO);
            if ("unknown" !== OO.type) {
              if (OO.eventId) {
                const KO = await this.auth._redirectUserForId(OO.eventId);
                if (KO) return this.user = KO, super.onAuthEvent(OO);
                this.resolve(null)
              }
            } else this.resolve(null)
          }
          async onExecution() {}
          cleanUp() {}
        }
        async function Lb(OO, KO) {
          return ze(OO)._set(Ab(KO), "true")
        }

        function Qb(OO, KO) {
          Fb.set(OO._key(), KO)
        }

        function ze(OO) {
          return eK(OO._redirectPersistence)
        }

        function Ab(OO) {
          return CK(ob, OO.config.apiKey, OO.name)
        }

        function fb(OO, KO, pO) {
          return async function(OO, KO, pO) {
            const XO = wK(OO);
            NO(OO, KO, Op), await XO._initializationPromise;
            const bK = pb(XO, pO);
            return await Lb(bK, XO), bK._openRedirect(XO, KO, "signInViaRedirect")
          }(OO, KO, pO)
        }

        function db(OO, KO, pO) {
          return async function(OO, KO, pO) {
            const bK = (0, XO.N)(OO);
            NO(bK.auth, KO, Op), await bK.auth._initializationPromise;
            const eO = pb(bK.auth, pO);
            await Lb(eO, bK.auth);
            const lO = await ye(bK);
            return eO._openRedirect(bK.auth, KO, "reauthViaRedirect", lO)
          }(OO, KO, pO)
        }

        function Tb(OO, KO, pO) {
          return async function(OO, KO, pO) {
            const bK = (0, XO.N)(OO);
            NO(bK.auth, KO, Op), await bK.auth._initializationPromise;
            const eO = pb(bK.auth, pO);
            await zX(!1, bK, KO.providerId), await Lb(eO, bK.auth);
            const lO = await ye(bK);
            return eO._openRedirect(bK.auth, KO, "linkViaRedirect", lO)
          }(OO, KO, pO)
        }
        async function Nb(OO, KO) {
          return await wK(OO)._initializationPromise, Ib(OO, KO, !1)
        }
        async function Ib(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
          const XO = wK(OO),
            bK = pb(XO, KO),
            eO = new Vb(XO, bK, pO),
            lO = await eO.execute();
          return lO && !pO && (delete lO.user._redirectEventId, await XO._persistUserIfCurrent(lO.user), await XO._setRedirectUser(null, KO)), lO
        }
        async function ye(OO) {
          const KO = NX(`${OO.uid}:::`);
          return OO._redirectEventId = KO, await OO.auth._setRedirectUser(OO), await OO.auth._persistUserIfCurrent(OO), KO
        }
        class ge {
          constructor(OO) {
            this.auth = OO, this.cachedEventUids = new Set, this.consumers = new Set, this.queuedRedirectEvent = null, this.hasHandledPotentialRedirect = !1, this.lastProcessedEventTime = Date.now()
          }
          registerConsumer(OO) {
            this.consumers.add(OO), this.queuedRedirectEvent && this.isEventForConsumer(this.queuedRedirectEvent, OO) && (this.sendToConsumer(this.queuedRedirectEvent, OO), this.saveEventToCache(this.queuedRedirectEvent), this.queuedRedirectEvent = null)
          }
          unregisterConsumer(OO) {
            this.consumers.delete(OO)
          }
          onEvent(OO) {
            if (this.hasEventBeenHandled(OO)) return !1;
            let KO = !1;
            return this.consumers.forEach((pO => {
              this.isEventForConsumer(OO, pO) && (KO = !0, this.sendToConsumer(OO, pO), this.saveEventToCache(OO))
            })), this.hasHandledPotentialRedirect || ! function(OO) {
              switch (OO.type) {
                case "signInViaRedirect":
                case "linkViaRedirect":
                case "reauthViaRedirect":
                  return !0;
                case "unknown":
                  return Eb(OO);
                default:
                  return !1
              }
            }(OO) || (this.hasHandledPotentialRedirect = !0, KO || (this.queuedRedirectEvent = OO, KO = !0)), KO
          }
          sendToConsumer(OO, KO) {
            var pO;
            if (OO.error && !Eb(OO)) {
              const XO = (null === (pO = OO.error.code) || void 0 === pO ? void 0 : pO.split("auth/")[1]) || "internal-error";
              KO.onError(dO(this.auth, XO))
            } else KO.onAuthEvent(OO)
          }
          isEventForConsumer(OO, KO) {
            const pO = null === KO.eventId || !!OO.eventId && OO.eventId === KO.eventId;
            return KO.filter.includes(OO.type) && pO
          }
          hasEventBeenHandled(OO) {
            return Date.now() - this.lastProcessedEventTime >= 6e5 && this.cachedEventUids.clear(), this.cachedEventUids.has(ub(OO))
          }
          saveEventToCache(OO) {
            this.cachedEventUids.add(ub(OO)), this.lastProcessedEventTime = Date.now()
          }
        }

        function ub(OO) {
          return [OO.type, OO.eventId, OO.sessionId, OO.tenantId].filter((OO => OO)).join("-")
        }

        function Eb(OO) {
          let {
            type: KO,
            error: pO
          } = OO;
          return "unknown" === KO && "auth/no-auth-event" === (null === pO || void 0 === pO ? void 0 : pO.code)
        }
        const je = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,
          Yb = /^https?/;
        async function wb(OO) {
          if (OO.config.emulator) return;
          const {
            authorizedDomains: KO
          } = await async function(OO) {
            return HO(OO, "GET", "/v1/projects", arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {})
          }(OO);
          for (const XO of KO) try {
            if (ie(XO)) return
          } catch (pO) {}
          fO(OO, "unauthorized-domain")
        }

        function ie(OO) {
          const KO = EO(),
            {
              protocol: pO,
              hostname: XO
            } = new URL(KO);
          if (OO.startsWith("chrome-extension://")) {
            const bK = new URL(OO);
            return "" === bK.hostname && "" === XO ? "chrome-extension:" === pO && OO.replace("chrome-extension://", "") === KO.replace("chrome-extension://", "") : "chrome-extension:" === pO && bK.hostname === XO
          }
          if (!Yb.test(pO)) return !1;
          if (je.test(OO)) return XO === OO;
          const bK = OO.replace(/\./g, "\\.");
          return new RegExp("^(.+\\." + bK + "|" + bK + ")$", "i").test(XO)
        }
        const re = new wO(3e4, 6e4);

        function Pb() {
          const OO = yb().___jsl;
          if (null === OO || void 0 === OO ? void 0 : OO.H)
            for (const KO of Object.keys(OO.H))
              if (OO.H[KO].r = OO.H[KO].r || [], OO.H[KO].L = OO.H[KO].L || [], OO.H[KO].r = [...OO.H[KO].L], OO.CP)
                for (let pO = 0; pO < OO.CP.length; pO++) OO.CP[pO] = null
        }
        let me = null;

        function sb(OO) {
          return me = me || function(OO) {
            return new Promise(((KO, pO) => {
              var XO, bK, eO;

              function lO() {
                Pb(), gapi.load("gapi.iframes", {
                  callback: () => {
                    KO(gapi.iframes.getContext())
                  },
                  ontimeout: () => {
                    Pb(), pO(dO(OO, "network-request-failed"))
                  },
                  timeout: re.get()
                })
              }
              if (null === (bK = null === (XO = yb().gapi) || void 0 === XO ? void 0 : XO.iframes) || void 0 === bK ? void 0 : bK.Iframe) KO(gapi.iframes.getContext());
              else {
                if (!(null === (eO = yb().gapi) || void 0 === eO ? void 0 : eO.load)) {
                  const KO = gp("iframefcb");
                  return yb()[KO] = () => {
                    gapi.load ? lO() : pO(dO(OO, "network-request-failed"))
                  }, yp(`https://apis.google.com/js/api.js?onload=${KO}`).catch((OO => pO(OO)))
                }
                lO()
              }
            })).catch((OO => {
              throw me = null, OO
            }))
          }(OO), me
        }
        const Hb = new wO(5e3, 15e3),
          Rb = {
            style: {
              position: "absolute",
              top: "-100px",
              width: "1px",
              height: "1px"
            },
            "aria-hidden": "true",
            tabindex: "-1"
          },
          Sb = new Map([
            ["identitytoolkit.googleapis.com", "p"],
            ["staging-identitytoolkit.sandbox.googleapis.com", "s"],
            ["test-identitytoolkit.sandbox.googleapis.com", "t"]
          ]);

        function Jb(OO) {
          const KO = OO.config;
          yK(KO.authDomain, OO, "auth-domain-config-required");
          const pO = KO.emulator ? iK(KO, "emulator/auth/iframe") : `https://${OO.config.authDomain}/__/auth/iframe`,
            eO = {
              apiKey: KO.apiKey,
              appName: OO.name,
              v: bK.g
            },
            lO = Sb.get(OO.config.apiHost);
          lO && (eO.eid = lO);
          const vK = OO._getFrameworks();
          return vK.length && (eO.fw = vK.join(",")), `${pO}?${(0,XO.gb)(eO).slice(1)}`
        }
        const ce = {
          location: "yes",
          resizable: "yes",
          statusbar: "yes",
          toolbar: "no"
        };
        class Bb {
          constructor(OO) {
            this.window = OO, this.associatedEvent = null
          }
          close() {
            if (this.window) try {
              this.window.close()
            } catch (OO) {}
          }
        }

        function Zb(OO, KO, pO) {
          let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 500,
            eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 600;
          const lO = Math.max((window.screen.availHeight - eO) / 2, 0).toString(),
            vK = Math.max((window.screen.availWidth - bK) / 2, 0).toString();
          let CO = "";
          const hO = Object.assign(Object.assign({}, ce), {
              width: bK.toString(),
              height: eO.toString(),
              top: lO,
              left: vK
            }),
            DO = (0, XO.P)().toLowerCase();
          pO && (CO = oK(DO) ? "_blank" : pO), MK(DO) && (KO = KO || "http://localhost", hO.scrollbars = "yes");
          const MO = Object.entries(hO).reduce(((OO, KO) => {
            let [pO, XO] = KO;
            return `${OO}${pO}=${XO},`
          }), "");
          if (function() {
              var OO;
              return zp(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.P)()) && !!(null === (OO = window.navigator) || void 0 === OO ? void 0 : OO.standalone)
            }(DO) && "_self" !== CO) return function(OO, KO) {
            const pO = document.createElement("a");
            pO.href = OO, pO.target = KO;
            const XO = document.createEvent("MouseEvent");
            XO.initMouseEvent("click", !0, !0, window, 1, 0, 0, 0, 0, !1, !1, !1, !1, 1, null), pO.dispatchEvent(XO)
          }(KO || "", CO), new Bb(null);
          const aK = window.open(KO || "", CO, MO);
          yK(aK, OO, "popup-blocked");
          try {
            aK.focus()
          } catch (oO) {}
          return new Bb(aK)
        }
        const Gb = "__/auth/handler",
          qe = "emulator/auth/handler",
          xe = encodeURIComponent("fac");
        async function nb(OO, KO, pO, eO, lO, vK) {
            yK(OO.config.authDomain, OO, "auth-domain-config-required"), yK(OO.config.apiKey, OO, "invalid-api-key");
            const CO = {
              apiKey: OO.config.apiKey,
              appName: OO.name,
              authType: pO,
              redirectUrl: eO,
              v: bK.g,
              eventId: lO
            };
            if (KO instanceof Op) {
              KO.setDefaultLanguage(OO.languageCode), CO.providerId = KO.providerId || "", (0, XO.T)(KO.getCustomParameters()) || (CO.customParameters = JSON.stringify(KO.getCustomParameters()));
              for (const [OO, KO] of Object.entries(vK || {})) CO[OO] = KO
            }
            if (KO instanceof Kp) {
              const OO = KO.getScopes().filter((OO => "" !== OO));
              OO.length > 0 && (CO.scopes = OO.join(","))
            }
            OO.tenantId && (CO.tid = OO.tenantId);
            const hO = CO;
            for (const XO of Object.keys(hO)) void 0 === hO[XO] && delete hO[XO];
            const DO = await OO._getAppCheckToken(),
              MO = DO ? `#${xe}=${encodeURIComponent(DO)}` : "";
            return `${function(OO){let{config:KO}=OO;if(!KO.emulator)return`
            https: //${KO.authDomain}/${Gb}`;return iK(KO,qe)}(OO)}?${(0,XO.gb)(hO).slice(1)}${MO}`}const Wb="webStorageSupport";const te=class{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=dX,this._completeRedirectFn=Ib,this._overrideRedirectResult=Qb}async _openPopup(OO,KO,pO,XO){var bK;uO(null===(bK=this.eventManagers[OO._key()])||void 0===bK?void 0:bK.manager,"_initialize() not called before _openPopup()");return Zb(OO,await nb(OO,KO,pO,EO(),XO),NX())}async _openRedirect(OO,KO,pO,XO){await this._originValidation(OO);return function(OO){yb().location.href=OO}(await nb(OO,KO,pO,EO(),XO)),new Promise((()=>{}))}_initialize(OO){const KO=OO._key();if(this.eventManagers[KO]){const{manager:OO,promise:pO}=this.eventManagers[KO];return OO?Promise.resolve(OO):(uO(pO,"If manager is not set, promise should be"),pO)}const pO=this.initAndGetManager(OO);return this.eventManagers[KO]={promise:pO},pO.catch((()=>{delete this.eventManagers[KO]})),pO}async initAndGetManager(OO){const KO=await async function(OO){const KO=await sb(OO),pO=yb().gapi;return yK(pO,OO,"internal-error"),KO.open({where:document.body,url:Jb(OO),messageHandlersFilter:pO.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:Rb,dontclear:!0},(KO=>new Promise((async(pO,XO)=>{await KO.restyle({setHideOnLeave:!1});const bK=dO(OO,"network-request-failed"),eO=yb().setTimeout((()=>{XO(bK)}),Hb.get());function lO(){yb().clearTimeout(eO),pO(KO)}KO.ping(lO).then(lO,(()=>{XO(bK)}))}))))}(OO),pO=new ge(OO);return KO.register("authEvent",(KO=>{yK(null===KO||void 0===KO?void 0:KO.authEvent,OO,"invalid-auth-event");return{status:pO.onEvent(KO.authEvent)?"ACK":"ERROR"}}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[OO._key()]={manager:pO},this.iframes[OO._key()]=KO,pO}_isIframeWebStorageSupported(OO,KO){this.iframes[OO._key()].send(Wb,{type:Wb},(pO=>{var XO;const bK=null===(XO=null===pO||void 0===pO?void 0:pO[0])||void 0===XO?void 0:XO[Wb];void 0!==bK&&KO(!!bK),fO(OO,"internal-error")}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(OO){const KO=OO._key();return this.originValidationPromises[KO]||(this.originValidationPromises[KO]=wb(OO)),this.originValidationPromises[KO]}get _shouldInitProactively(){return AK()||ap()||zp()}};class ke{constructor(OO){this.factorId=OO}_process(OO,KO,pO){switch(KO.type){case"enroll":return this._finalizeEnroll(OO,KO.credential,pO);case"signin":return this._finalizeSignIn(OO,KO.credential);default:return gK("unexpected MultiFactorSessionType")}}}class Ub extends ke{constructor(OO){super("phone"),this.credential=OO}static _fromCredential(OO){return new Ub(OO)}_finalizeEnroll(OO,KO,pO){return function(OO,KO){return HO(OO,"POST","/v2/accounts/mfaEnrollment:finalize",sO(OO,KO))}(OO,{idToken:KO,displayName:pO,phoneVerificationInfo:this.credential._makeVerificationRequest()})}_finalizeSignIn(OO,KO){return function(OO,KO){return HO(OO,"POST","/v2/accounts/mfaSignIn:finalize",sO(OO,KO))}(OO,{mfaPendingCredential:KO,phoneVerificationInfo:this.credential._makeVerificationRequest()})}}class Oe{constructor(){}static assertion(OO){return Ub._fromCredential(OO)}}Oe.FACTOR_ID="phone";class Ke{static assertionForEnrollment(OO,KO){return pe._fromSecret(OO,KO)}static assertionForSignIn(OO,KO){return pe._fromEnrollmentId(OO,KO)}static async generateSecret(OO){const KO=OO;yK("undefined"!==typeof KO.auth,"internal-error");const pO=await(XO=KO.auth,bK={idToken:KO.credential,totpEnrollmentInfo:{}},HO(XO,"POST","/v2/accounts/mfaEnrollment:start",sO(XO,bK)));var XO,bK;return Xe._fromStartTotpMfaEnrollmentResponse(pO,KO.auth)}}Ke.FACTOR_ID="totp";class pe extends ke{constructor(OO,KO,pO){super("totp"),this.otp=OO,this.enrollmentId=KO,this.secret=pO}static _fromSecret(OO,KO){return new pe(KO,void 0,OO)}static _fromEnrollmentId(OO,KO){return new pe(KO,OO)}async _finalizeEnroll(OO,KO,pO){return yK("undefined"!==typeof this.secret,OO,"argument-error"),function(OO,KO){return HO(OO,"POST","/v2/accounts/mfaEnrollment:finalize",sO(OO,KO))}(OO,{idToken:KO,displayName:pO,totpVerificationInfo:this.secret._makeTotpVerificationInfo(this.otp)})}async _finalizeSignIn(OO,KO){yK(void 0!==this.enrollmentId&&void 0!==this.otp,OO,"argument-error");const pO={verificationCode:this.otp};return function(OO,KO){return HO(OO,"POST","/v2/accounts/mfaSignIn:finalize",sO(OO,KO))}(OO,{mfaPendingCredential:KO,mfaEnrollmentId:this.enrollmentId,totpVerificationInfo:pO})}}class Xe{constructor(OO,KO,pO,XO,bK,eO,lO){this.sessionInfo=eO,this.auth=lO,this.secretKey=OO,this.hashingAlgorithm=KO,this.codeLength=pO,this.codeIntervalSeconds=XO,this.enrollmentCompletionDeadline=bK}static _fromStartTotpMfaEnrollmentResponse(OO,KO){return new Xe(OO.totpSessionInfo.sharedSecretKey,OO.totpSessionInfo.hashingAlgorithm,OO.totpSessionInfo.verificationCodeLength,OO.totpSessionInfo.periodSec,new Date(OO.totpSessionInfo.finalizeEnrollmentTime).toUTCString(),OO.totpSessionInfo.sessionInfo,KO)}_makeTotpVerificationInfo(OO){return{sessionInfo:this.sessionInfo,verificationCode:OO}}generateQrCodeUrl(OO,KO){var pO;let XO=!1;return(bl(OO)||bl(KO))&&(XO=!0),XO&&(bl(OO)&&(OO=(null===(pO=this.auth.currentUser)||void 0===pO?void 0:pO.email)||"unknownuser"),bl(KO)&&(KO=this.auth.name)),`otpauth://totp/${KO}:${OO}?secret=${this.secretKey}&issuer=${KO}&algorithm=${this.hashingAlgorithm}&digits=${this.codeLength}`}}function bl(OO){return"undefined"===typeof OO||0===(null===OO||void 0===OO?void 0:OO.length)}var ee="@firebase/auth",le="0.23.2";class vl{constructor(OO){this.auth=OO,this.internalListeners=new Map}getUid(){var OO;return this.assertAuthConfigured(),(null===(OO=this.auth.currentUser)||void 0===OO?void 0:OO.uid)||null}async getToken(OO){if(this.assertAuthConfigured(),await this.auth._initializationPromise,!this.auth.currentUser)return null;return{accessToken:await this.auth.currentUser.getIdToken(OO)}}addAuthTokenListener(OO){if(this.assertAuthConfigured(),this.internalListeners.has(OO))return;const KO=this.auth.onIdTokenChanged((KO=>{OO((null===KO||void 0===KO?void 0:KO.stsTokenManager.accessToken)||null)}));this.internalListeners.set(OO,KO),this.updateProactiveRefresh()}removeAuthTokenListener(OO){this.assertAuthConfigured();const KO=this.internalListeners.get(OO);KO&&(this.internalListeners.delete(OO),KO(),this.updateProactiveRefresh())}assertAuthConfigured(){yK(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}const Ce=(0,XO.L)("authIdTokenMaxAge")||300;let he=null;const De=OO=>async KO=>{const pO=KO&&await KO.getIdTokenResult(),XO=pO&&((new Date).getTime()-Date.parse(pO.issuedAtTime))/1e3;if(XO&&XO>Ce)return;const bK=null===pO||void 0===pO?void 0:pO.token;he!==bK&&(he=bK,await fetch(OO,{method:bK?"POST":"DELETE",headers:bK?{Authorization:`Bearer ${bK}`}:{}}))};function Me(){let OO=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,bK.J)();const KO=(0,bK.w)(OO,"auth");if(KO.isInitialized())return KO.getImmediate();const pO=rp(OO,{popupRedirectResolver:te,persistence:[sX,AX,dX]}),eO=(0,XO.L)("authTokenSyncURL");if(eO){const OO=De(eO);bb(pO,OO,(()=>OO(pO.currentUser))),XX(pO,(KO=>OO(KO)))}const lO=(0,XO.I)("auth");return lO&&PK(pO,`http://${lO}`),pO}var al;al="Browser",(0,bK.y)(new vK.d("auth",((OO,KO)=>{let{options:pO}=KO;const XO=OO.getProvider("app").getImmediate(),bK=OO.getProvider("heartbeat"),eO=OO.getProvider("app-check-internal"),{apiKey:lO,authDomain:vK}=XO.options;yK(lO&&!lO.includes(":"),"invalid-api-key",{appName:XO.name});const CO={apiKey:lO,authDomain:vK,clientPlatform:al,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:fK(al)},hO=new YK(XO,bK,eO,CO);return function(OO,KO){const pO=(null===KO||void 0===KO?void 0:KO.persistence)||[],XO=(Array.isArray(pO)?pO:[pO]).map(eK);(null===KO||void 0===KO?void 0:KO.errorMap)&&OO._updateErrorMap(KO.errorMap),OO._initializeWithPersistence(XO,null===KO||void 0===KO?void 0:KO.popupRedirectResolver)}(hO,pO),hO}),"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback(((OO,KO,pO)=>{OO.getProvider("auth-internal").initialize()}))),(0,bK.y)(new vK.d("auth-internal",(OO=>(OO=>new vl(OO))(wK(OO.getProvider("auth").getImmediate()))),"PRIVATE").setInstantiationMode("EXPLICIT")),(0,bK.P)(ee,le,function(OO){switch(OO){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";default:return}}(al)),(0,bK.P)(ee,le,"esm2017")}};Object.freeze(modules);for(const OO in modules)Object.freeze(modules[OO]);