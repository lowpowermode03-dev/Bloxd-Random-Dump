export const id = 192;
export const ids = [192];
export const modules = {
  34879: (OO, KO, pO) => {
    pO.d(KO, {
      reportCappedWasmFailure: () => lO,
      reportWasmFailure: () => eO
    });
    var XO = pO(2516);
    const bK = XO.e - 4;

    function eO(OO, KO, pO) {
      (0, XO.i)(OO, KO, pO, !1)
    }

    function lO(OO, KO, pO) {
      (0, XO.i)(OO, KO, pO, !1, bK)
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);