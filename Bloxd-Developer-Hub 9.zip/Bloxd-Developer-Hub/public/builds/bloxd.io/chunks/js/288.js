export const id = 288;
export const ids = [288];
export const modules = {
  39803: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      _ENVTextureLoader: () => yK
    });
    var XO = pO(37996),
      bK = pO(35632),
      eO = pO(35664),
      lO = pO(38048),
      vK = pO(37889),
      CO = pO(38056),
      hO = (pO(38170), pO(39812)),
      DO = pO(37061),
      MO = (pO(39825), pO(39846), pO(38136));
    const aK = "image/png",
      oO = [134, 22, 135, 150, 246, 214, 150, 54];

    function FO(OO) {
      const KO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength);
      let pO = 0;
      for (let lO = 0; lO < oO.length; lO++)
        if (KO.getUint8(pO++) !== oO[lO]) return DO.b.Error("Not a babylon environment map"), null;
      let XO, bK = "";
      for (; XO = KO.getUint8(pO++);) bK += String.fromCharCode(XO);
      let eO = JSON.parse(bK);
      return eO = VO(eO), eO.binaryDataPosition = pO, eO.specular && (eO.specular.lodGenerationScale = eO.specular.lodGenerationScale || .8), eO
    }

    function VO(OO) {
      if (OO.version > 2) throw new Error(`Unsupported babylon environment map version "${OO.version}". Latest supported version is "2".`);
      return 2 === OO.version ? OO : OO = {
        ...OO,
        version: 2,
        imageType: aK
      }
    }

    function LO(OO, KO) {
      const pO = (KO = VO(KO)).specular;
      let XO = Math.log2(KO.width);
      if (XO = Math.round(XO) + 1, pO.mipmaps.length !== 6 * XO) throw new Error(`Unsupported specular mipmaps number "${pO.mipmaps.length}"`);
      const bK = new Array(XO);
      for (let eO = 0; eO < XO; eO++) {
        bK[eO] = new Array(6);
        for (let XO = 0; XO < 6; XO++) {
          const lO = pO.mipmaps[6 * eO + XO];
          bK[eO][XO] = new Uint8Array(OO.buffer, OO.byteOffset + KO.binaryDataPosition + lO.position, lO.length)
        }
      }
      return bK
    }

    function QO(OO, KO) {
      KO = VO(KO);
      const pO = new Array(6),
        XO = KO.irradiance?.irradianceTexture;
      if (XO) {
        if (6 !== XO.faces.length) throw new Error(`Incorrect irradiance texture faces number "${XO.faces.length}"`);
        for (let bK = 0; bK < 6; bK++) {
          const eO = XO.faces[bK];
          pO[bK] = new Uint8Array(OO.buffer, OO.byteOffset + KO.binaryDataPosition + eO.position, eO.length)
        }
      }
      return pO
    }

    function zK(OO, KO, pO) {
      const XO = (pO = VO(pO)).specular;
      if (!XO) return Promise.resolve([]);
      OO._lodGenerationScale = XO.lodGenerationScale;
      const eO = [],
        lO = LO(KO, pO);
      eO.push(fO(OO, lO, pO.imageType));
      const vK = pO.irradiance?.irradianceTexture;
      if (vK) {
        const XO = QO(KO, pO);
        let lO = null;
        pO.irradiance?.irradianceTexture?.dominantDirection && (lO = bK.o.FromArray(pO.irradiance.irradianceTexture.dominantDirection)), eO.push(dO(OO, XO, vK.size, pO.imageType, lO))
      }
      return Promise.all(eO)
    }
    async function AO(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
      return await new Promise(((MO, aK) => {
        if (pO) {
          const pO = KO.createTexture(null, !0, !0, null, 1, null, (OO => {
            aK(OO)
          }), OO);
          XO?.onEffectCreatedObservable.addOnce((vK => {
            vK.executeWhenCompiled((() => {
              XO.externalTextureSamplerBinding = !0, XO.onApply = XO => {
                XO._bindTexture("textureSampler", pO), XO.setFloat2("scale", 1, KO._features.needsInvertingBitmap && OO instanceof ImageBitmap ? -1 : 1)
              }, KO.scenes.length && (KO.scenes[0].postProcessManager.directRender([XO], hO, !0, eO, lO), KO.restoreDefaultFramebuffer(), pO.dispose(), URL.revokeObjectURL(bK), MO())
            }))
          }))
        } else {
          if (KO._uploadImageToTexture(DO, OO, eO, lO), vK) {
            const pO = CO[lO];
            pO && KO._uploadImageToTexture(pO._texture, OO, eO, 0)
          }
          MO()
        }
      }))
    }
    async function fO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : aK;
      const XO = OO.qb();
      OO.format = 5, OO.type = 0, OO.generateMipMaps = !0, OO._cachedAnisotropicFilteringLevel = null, XO.updateTextureSamplingMode(3, OO), await TO(OO, KO, !0, pO), OO.isReady = !0
    }
    async function dO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : aK,
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
      const eO = OO.qb(),
        lO = new vK.e(eO, 5),
        hO = new CO.d(eO, lO);
      OO._irradianceTexture = hO, hO._dominantDirection = bK, lO.isCube = !0, lO.format = 5, lO.type = 0, lO.generateMipMaps = !0, lO._cachedAnisotropicFilteringLevel = null, lO.generateMipMaps = !0, lO.width = pO, lO.height = pO, eO.updateTextureSamplingMode(3, lO), await TO(lO, [KO], !1, XO), eO.generateMipMapsForCubemap(lO), lO.isReady = !0
    }
    async function TO(OO, KO, bK) {
      let lO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : aK;
      if (!(0, XO.j)(OO.width)) throw new Error("Texture size must be a power of two");
      const DO = (0, eO.ILog2)(OO.width) + 1,
        oO = OO.qb();
      let FO = !1,
        VO = !1,
        LO = null,
        QO = null,
        zK = null;
      const fO = oO.getCaps();
      fO.textureLOD ? oO._features.supportRenderAndCopyToLodForFloatTextures ? fO.textureHalfFloatRender && fO.textureHalfFloatLinearFiltering ? (FO = !0, OO.type = 2) : fO.textureFloatRender && fO.textureFloatLinearFiltering && (FO = !0, OO.type = 1) : FO = !1 : (FO = !1, VO = bK);
      let dO = 0;
      if (FO) oO.isWebGPU ? (dO = 1, await pO.e(322).then((() => pO(59271)))) : await pO.e(304).then((() => pO(59280))), LO = new hO.d("rgbdDecode", "rgbdDecode", null, null, 1, null, 3, oO, !1, void 0, OO.type, void 0, null, !1, void 0, dO), OO._isRGBD = !1, OO.invertY = !1, QO = oO.createRenderTargetCubeTexture(OO.width, {
        generateDepthBuffer: !1,
        generateMipMaps: !0,
        generateStencilBuffer: !1,
        samplingMode: 3,
        type: OO.type,
        format: 5
      });
      else if (OO._isRGBD = !0, OO.invertY = !0, VO) {
        const KO = 3;
        zK = {};
        const pO = OO._lodGenerationScale,
          XO = OO._lodGenerationOffset;
        for (let bK = 0; bK < KO; bK++) {
          const eO = (DO - 1) * pO + XO,
            lO = XO + (eO - XO) * (1 - bK / (KO - 1)),
            hO = Math.round(Math.min(Math.max(lO, 0), eO)),
            MO = new vK.e(oO, 2);
          MO.isCube = !0, MO.invertY = !0, MO.generateMipMaps = !1, oO.updateTextureSamplingMode(2, MO);
          const aK = new CO.d(null);
          switch (aK._isCube = !0, aK._texture = MO, zK[hO] = aK, bK) {
            case 0:
              OO._lodTextureLow = aK;
              break;
            case 1:
              OO._lodTextureMid = aK;
              break;
            case 2:
              OO._lodTextureHigh = aK
          }
        }
      }
      const TO = [];
      for (let pO = 0; pO < KO.length; pO++)
        for (let XO = 0; XO < 6; XO++) {
          const bK = KO[pO][XO],
            eO = (0, MO.l)(bK),
            vK = new Blob([eO], {
              type: lO
            }),
            CO = URL.createObjectURL(vK);
          let hO;
          if (oO._features.forceBitmapOverHTMLImageElement) hO = oO.createImageBitmap(vK, {
            premultiplyAlpha: "none",
            colorSpaceConversion: "none"
          }).then((async KO => await AO(KO, oO, FO, LO, CO, XO, pO, VO, zK, QO, OO)));
          else {
            const KO = new Image;
            KO.src = CO, hO = new Promise(((bK, eO) => {
              KO.onload = () => {
                AO(KO, oO, FO, LO, CO, XO, pO, VO, zK, QO, OO).then((() => bK())).catch((OO => {
                  eO(OO)
                }))
              }, KO.onerror = OO => {
                eO(OO)
              }
            }))
          }
          TO.push(hO)
        }
      if (await Promise.all(TO), KO.length < DO) {
        let pO;
        const XO = Math.pow(2, DO - 1 - KO.length),
          bK = XO * XO * 4;
        switch (OO.type) {
          case 0:
            pO = new Uint8Array(bK);
            break;
          case 2:
            pO = new Uint16Array(bK);
            break;
          case 1:
            pO = new Float32Array(bK)
        }
        for (let eO = KO.length; eO < DO; eO++)
          for (let KO = 0; KO < 6; KO++) oO._uploadArrayBufferViewToTexture(QO?.texture || OO, pO, KO, eO)
      }
      if (QO) {
        const KO = OO._irradianceTexture;
        OO._irradianceTexture = null, oO._releaseTexture(OO), QO._swapAndDie(OO), OO._irradianceTexture = KO
      }
      LO && LO.dispose(), VO && (OO._lodTextureHigh && OO._lodTextureHigh._texture && (OO._lodTextureHigh._texture.isReady = !0), OO._lodTextureMid && OO._lodTextureMid._texture && (OO._lodTextureMid._texture.isReady = !0), OO._lodTextureLow && OO._lodTextureLow._texture && (OO._lodTextureLow._texture.isReady = !0))
    }

    function NO(OO, KO) {
      const pO = (KO = VO(KO)).irradiance;
      if (!pO) return;
      const XO = new lO.f;
      bK.o.FromArrayToRef(pO.x, 0, XO.x), bK.o.FromArrayToRef(pO.y, 0, XO.y), bK.o.FromArrayToRef(pO.z, 0, XO.z), bK.o.FromArrayToRef(pO.xx, 0, XO.xx), bK.o.FromArrayToRef(pO.yy, 0, XO.yy), bK.o.FromArrayToRef(pO.zz, 0, XO.zz), bK.o.FromArrayToRef(pO.yz, 0, XO.yz), bK.o.FromArrayToRef(pO.zx, 0, XO.zx), bK.o.FromArrayToRef(pO.xy, 0, XO.xy), OO._sphericalPolynomial = XO
    }
    var IO = pO(39849);
    class yK {
      constructor() {
        this.supportCascades = !1
      }
      loadCubeData(OO, KO, pO, XO, bK) {
        if (Array.isArray(OO)) return;
        const eO = FO(OO);
        if (eO) {
          KO.width = eO.width, KO.height = eO.width;
          try {
            (0, IO.c)(), NO(KO, eO), zK(KO, OO, eO).then((() => {
              KO.isReady = !0, KO.onLoadedObservable.notifyObservers(KO), KO.onLoadedObservable.clear(), XO && XO()
            }), (OO => {
              bK?.("Can not upload environment levels", OO)
            }))
          } catch (lO) {
            bK?.("Can not upload environment file", lO)
          }
        } else bK && bK("Can not parse the environment file", null)
      }
      loadData() {
        throw ".env not supported in 2d."
      }
    }
  },
  39849: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(39784),
      bK = pO(38056);
    let eO = !1;

    function lO() {
      eO || (eO = !0, bK.d.prototype._sphericalPolynomialTargetSize = 0, bK.d.prototype.forceSphericalPolynomialsRecompute = function() {
        this._texture && (this._texture._sphericalPolynomial = null, this._texture._sphericalPolynomialPromise = null, this._texture._sphericalPolynomialComputed = !1)
      }, Object.defineProperty(bK.d.prototype, "sphericalPolynomial", {
        get: function() {
          if (this._texture) {
            if (this._texture._sphericalPolynomial || this._texture._sphericalPolynomialComputed) return this._texture._sphericalPolynomial;
            if (this._texture.isReady) return this._texture._sphericalPolynomialPromise || (this._texture._sphericalPolynomialPromise = XO.b.ConvertCubeMapTextureToSphericalPolynomial(this), null === this._texture._sphericalPolynomialPromise ? this._texture._sphericalPolynomialComputed = !0 : this._texture._sphericalPolynomialPromise.then((OO => {
              this._texture._sphericalPolynomial = OO, this._texture._sphericalPolynomialComputed = !0
            }))), null
          }
          return null
        },
        set: function(OO) {
          this._texture && (this._texture._sphericalPolynomial = OO)
        },
        enumerable: !0,
        configurable: !0
      }))
    }
  },
  39784: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO
    });
    var XO = pO(35632),
      bK = pO(35664),
      eO = pO(38048),
      lO = pO(35639),
      vK = pO(35688);
    class CO {
      constructor(OO, KO, pO, XO) {
        this.name = OO, this.worldAxisForNormal = KO, this.worldAxisForFileX = pO, this.worldAxisForFileY = XO
      }
    }
    class hO {
      static _NearestPow2Floor(OO) {
        return OO <= 1 ? 1 : 1 << Math.floor(Math.log2(OO))
      }
      static ConvertCubeMapTextureToSphericalPolynomial(OO) {
        if (!OO.isCube) return null;
        OO.JKO()?.qb().flushFramebuffer();
        const KO = OO.getSize().width,
          pO = OO._sphericalPolynomialTargetSize,
          XO = pO > 0 ? this._NearestPow2Floor(pO) : 0,
          bK = !OO.noMipmap && !0 === OO._texture?.generateMipMaps,
          eO = XO > 0 && XO < KO && bK,
          lO = eO ? Math.max(0, Math.round(Math.log2(KO / XO))) : 0,
          vK = eO ? Math.max(1, Math.floor(KO / Math.pow(2, lO))) : KO,
          CO = OO.readPixels(0, lO, void 0, !1),
          hO = OO.readPixels(1, lO, void 0, !1);
        let DO, MO;
        OO.isRenderTarget ? (DO = OO.readPixels(3, lO, void 0, !1), MO = OO.readPixels(2, lO, void 0, !1)) : (DO = OO.readPixels(2, lO, void 0, !1), MO = OO.readPixels(3, lO, void 0, !1));
        const aK = OO.readPixels(4, lO, void 0, !1),
          oO = OO.readPixels(5, lO, void 0, !1),
          FO = OO.gammaSpace,
          VO = XO > 0 && XO < KO && !eO;
        return new Promise((OO => {
          Promise.all([hO, CO, DO, MO, aK, oO]).then((pO => {
            let [bK, eO, lO, CO, hO, DO] = pO, MO = vK;
            if (VO) {
              const OO = 4;
              bK = this._DownsampleFace(bK, KO, XO, OO), eO = this._DownsampleFace(eO, KO, XO, OO), lO = this._DownsampleFace(lO, KO, XO, OO), CO = this._DownsampleFace(CO, KO, XO, OO), hO = this._DownsampleFace(hO, KO, XO, OO), DO = this._DownsampleFace(DO, KO, XO, OO), MO = XO
            }
            const aK = {
              size: MO,
              right: eO,
              left: bK,
              up: lO,
              down: CO,
              front: hO,
              back: DO,
              format: 5,
              type: bK instanceof Float32Array ? 1 : 0,
              gammaSpace: FO
            };
            OO(this.ConvertCubeMapToSphericalPolynomial(aK))
          }))
        }))
      }
      static _AreaElement(OO, KO) {
        return Math.atan2(OO * KO, Math.sqrt(OO * OO + KO * KO + 1))
      }
      static _DownsampleFace(OO, KO, pO, XO) {
        const bK = OO instanceof Float32Array ? OO : Float32Array.from(OO),
          eO = pO * pO * XO,
          lO = new Float32Array(eO),
          vK = KO / pO,
          CO = 1 / (vK * vK);
        for (let DO = 0; DO < pO; DO++) {
          const OO = Math.floor(DO * vK),
            eO = Math.floor((DO + 1) * vK);
          for (let hO = 0; hO < pO; hO++) {
            const MO = Math.floor(hO * vK),
              aK = Math.floor((hO + 1) * vK),
              oO = (DO * pO + hO) * XO;
            for (let pO = 0; pO < XO; pO++) {
              let vK = 0;
              for (let lO = OO; lO < eO; lO++)
                for (let OO = MO; OO < aK; OO++) vK += bK[(lO * KO + OO) * XO + pO];
              lO[oO + pO] = vK * CO
            }
          }
        }
        if (OO instanceof Float32Array) return lO;
        const hO = new(0, OO.constructor)(eO);
        for (let DO = 0; DO < eO; DO++) hO[DO] = lO[DO] + .5 | 0;
        return hO
      }
      static ConvertCubeMapToSphericalPolynomial(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        const pO = KO > 0 ? this._NearestPow2Floor(KO) : 0;
        if (pO > 0 && OO.size > pO) {
          const KO = 5 === OO.format ? 4 : 3,
            XO = ["right", "left", "up", "down", "front", "back"],
            bK = {};
          for (const eO of XO) bK[eO] = this._DownsampleFace(OO[eO], OO.size, pO, KO);
          OO = {
            ...OO,
            ...bK,
            size: pO
          }
        }
        const XO = new eO.e;
        let CO = 0;
        const hO = 2 / OO.size,
          DO = hO,
          MO = .5 * hO,
          aK = MO - 1;
        for (let eO = 0; eO < 6; eO++) {
          const KO = this._FileFaces[eO],
            pO = OO[KO.name];
          let oO = aK;
          const FO = 5 === OO.format ? 4 : 3;
          for (let eO = 0; eO < OO.size; eO++) {
            let VO = aK;
            for (let DO = 0; DO < OO.size; DO++) {
              const aK = KO.worldAxisForFileX.scale(VO).add(KO.worldAxisForFileY.scale(oO)).add(KO.worldAxisForNormal);
              aK.normalize();
              const LO = this._AreaElement(VO - MO, oO - MO) - this._AreaElement(VO - MO, oO + MO) - this._AreaElement(VO + MO, oO - MO) + this._AreaElement(VO + MO, oO + MO);
              let QO = pO[eO * OO.size * FO + DO * FO + 0],
                zK = pO[eO * OO.size * FO + DO * FO + 1],
                AO = pO[eO * OO.size * FO + DO * FO + 2];
              isNaN(QO) && (QO = 0), isNaN(zK) && (zK = 0), isNaN(AO) && (AO = 0), 0 === OO.type && (QO /= 255, zK /= 255, AO /= 255), OO.gammaSpace && (QO = Math.pow((0, bK.Clamp)(QO), lO.e), zK = Math.pow((0, bK.Clamp)(zK), lO.e), AO = Math.pow((0, bK.Clamp)(AO), lO.e));
              const fO = this.MAX_HDRI_VALUE;
              if (this.PRESERVE_CLAMPED_COLORS) {
                const OO = Math.max(QO, zK, AO);
                if (OO > fO) {
                  const KO = fO / OO;
                  QO *= KO, zK *= KO, AO *= KO
                }
              } else QO = (0, bK.Clamp)(QO, 0, fO), zK = (0, bK.Clamp)(zK, 0, fO), AO = (0, bK.Clamp)(AO, 0, fO);
              const dO = new vK.e(QO, zK, AO);
              XO.addLight(aK, dO, LO), CO += LO, VO += hO
            }
            oO += DO
          }
        }
        const oO = 6 * (4 * Math.PI) / 6 / CO;
        return XO.scaleInPlace(oO), XO.convertIncidentRadianceToIrradiance(), XO.convertIrradianceToLambertianRadiance(), eO.f.FromHarmonics(XO)
      }
    }
    hO._FileFaces = [new CO("right", new XO.o(1, 0, 0), new XO.o(0, 0, -1), new XO.o(0, -1, 0)), new CO("left", new XO.o(-1, 0, 0), new XO.o(0, 0, 1), new XO.o(0, -1, 0)), new CO("up", new XO.o(0, 1, 0), new XO.o(1, 0, 0), new XO.o(0, 0, 1)), new CO("down", new XO.o(0, -1, 0), new XO.o(1, 0, 0), new XO.o(0, 0, -1)), new CO("front", new XO.o(0, 0, 1), new XO.o(1, 0, 0), new XO.o(0, -1, 0)), new CO("back", new XO.o(0, 0, -1), new XO.o(-1, 0, 0), new XO.o(0, -1, 0))], hO.MAX_HDRI_VALUE = 4096, hO.PRESERVE_CLAMPED_COLORS = !1
  },
  39825: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO
    });
    var XO = pO(39812),
      bK = pO(39827);
    class eO {
      static ExpandRGBDTexture(OO) {
        const KO = OO._texture;
        if (!KO || !OO.isRGBD) return;
        const bK = KO.qb(),
          eO = bK.getCaps(),
          lO = KO.isReady;
        let vK = !1;
        eO.textureHalfFloatRender && eO.textureHalfFloatLinearFiltering ? (vK = !0, KO.type = 2) : eO.textureFloatRender && eO.textureFloatLinearFiltering && (vK = !0, KO.type = 1), vK && (KO.isReady = !1, KO._isRGBD = !1, KO.invertY = !1);
        const CO = async () => {
          const eO = bK.isWebGPU,
            lO = eO ? 1 : 0;
          KO.isReady = !1, eO ? await pO.e(322).then((() => pO(59271))) : await pO.e(304).then((() => pO(59280)));
          const vK = new XO.d("rgbdDecode", "rgbdDecode", null, null, 1, null, 3, bK, !1, void 0, KO.type, void 0, null, !1, void 0, lO);
          vK.externalTextureSamplerBinding = !0;
          const CO = bK.createRenderTargetTexture(KO.width, {
            generateDepthBuffer: !1,
            generateMipMaps: !1,
            generateStencilBuffer: !1,
            samplingMode: KO.samplingMode,
            type: KO.type,
            format: 5
          });
          vK.onEffectCreatedObservable.addOnce((pO => {
            pO.executeWhenCompiled((() => {
              vK.onApply = OO => {
                OO._bindTexture("textureSampler", KO), OO.setFloat2("scale", 1, 1)
              }, OO.JKO()?.postProcessManager.directRender([vK], CO, !0), bK.restoreDefaultFramebuffer(), bK._releaseTexture(KO), vK && vK.dispose(), CO._swapAndDie(KO), KO.isReady = !0
            }))
          }))
        };
        vK && (lO ? CO() : OO.onLoadObservable.addOnce(CO))
      }
      static async EncodeTextureToRGBD(OO, KO) {
        let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        return KO.qb().isWebGPU ? await pO.e(323).then((() => pO(59303))) : await pO.e(305).then((() => pO(59295))), await (0, bK.e)("rgbdEncode", OO, KO, XO, 1, 5)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);