export const id = 244;
export const ids = [244];
export const modules = {
  39620: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {}
    XO.AUTOSAMPLERSUFFIX = "Sampler", XO.DISABLEUA = "#define DISABLE_UNIFORMITY_ANALYSIS", XO.ALPHA_DISABLE = 0, XO.ALPHA_ADD = 1, XO.ALPHA_COMBINE = 2, XO.ALPHA_SUBTRACT = 3, XO.ALPHA_MULTIPLY = 4, XO.ALPHA_MAXIMIZED = 5, XO.ALPHA_ONEONE = 6, XO.ALPHA_PREMULTIPLIED = 7, XO.ALPHA_PREMULTIPLIED_PORTERDUFF = 8, XO.ALPHA_INTERPOLATE = 9, XO.ALPHA_SCREENMODE = 10, XO.ALPHA_ONEONE_ONEONE = 11, XO.ALPHA_ALPHATOCOLOR = 12, XO.ALPHA_REVERSEONEMINUS = 13, XO.ALPHA_SRC_DSTONEMINUSSRCALPHA = 14, XO.ALPHA_ONEONE_ONEZERO = 15, XO.ALPHA_EXCLUSION = 16, XO.ALPHA_LAYER_ACCUMULATE = 17, XO.ALPHA_MIN = 18, XO.ALPHA_MAX = 19, XO.ALPHA_DUAL_SRC0_ADD_SRC1xDST = 20, XO.ALPHA_REPLACE_COLOR = 21, XO.ALPHA_EQUATION_ADD = 0, XO.ALPHA_EQUATION_SUBSTRACT = 1, XO.ALPHA_EQUATION_REVERSE_SUBTRACT = 2, XO.ALPHA_EQUATION_MAX = 3, XO.ALPHA_EQUATION_MIN = 4, XO.ALPHA_EQUATION_DARKEN = 5, XO.DELAYLOADSTATE_NONE = 0, XO.DELAYLOADSTATE_LOADED = 1, XO.DELAYLOADSTATE_LOADING = 2, XO.DELAYLOADSTATE_NOTLOADED = 4, XO.NEVER = 512, XO.ALWAYS = 519, XO.LESS = 513, XO.EQUAL = 514, XO.LEQUAL = 515, XO.GREATER = 516, XO.GEQUAL = 518, XO.NOTEQUAL = 517, XO.KEEP = 7680, XO.ZERO = 0, XO.REPLACE = 7681, XO.INCR = 7682, XO.DECR = 7683, XO.INVERT = 5386, XO.INCR_WRAP = 34055, XO.DECR_WRAP = 34056, XO.TEXTURE_CLAMP_ADDRESSMODE = 0, XO.TEXTURE_WRAP_ADDRESSMODE = 1, XO.TEXTURE_MIRROR_ADDRESSMODE = 2, XO.TEXTURE_REPETITION_NONE = 0, XO.TEXTURE_REPETITION_NOISE_BLEND = 1, XO.TEXTURE_REPETITION_HEX_TILING = 2, XO.TEXTURE_REPETITION_TILE_RANDOMIZATION = 3, XO.TEXTURE_REPETITION_VORONOI_BOMBING = 4, XO.TEXTURE_CREATIONFLAG_STORAGE = 1, XO.TEXTUREFORMAT_ALPHA = 0, XO.TEXTUREFORMAT_LUMINANCE = 1, XO.TEXTUREFORMAT_LUMINANCE_ALPHA = 2, XO.TEXTUREFORMAT_RGB = 4, XO.TEXTUREFORMAT_RGBA = 5, XO.TEXTUREFORMAT_RED = 6, XO.TEXTUREFORMAT_R = 6, XO.TEXTUREFORMAT_R16_UNORM = 33322, XO.TEXTUREFORMAT_RG16_UNORM = 33324, XO.TEXTUREFORMAT_RGB16_UNORM = 32852, XO.TEXTUREFORMAT_RGBA16_UNORM = 32859, XO.TEXTUREFORMAT_R16_SNORM = 36760, XO.TEXTUREFORMAT_RG16_SNORM = 36761, XO.TEXTUREFORMAT_RGB16_SNORM = 36762, XO.TEXTUREFORMAT_RGBA16_SNORM = 36763, XO.TEXTUREFORMAT_RG = 7, XO.TEXTUREFORMAT_RED_INTEGER = 8, XO.TEXTUREFORMAT_R_INTEGER = 8, XO.TEXTUREFORMAT_RG_INTEGER = 9, XO.TEXTUREFORMAT_RGB_INTEGER = 10, XO.TEXTUREFORMAT_RGBA_INTEGER = 11, XO.TEXTUREFORMAT_BGRA = 12, XO.TEXTUREFORMAT_DEPTH24_STENCIL8 = 13, XO.TEXTUREFORMAT_DEPTH32_FLOAT = 14, XO.TEXTUREFORMAT_DEPTH16 = 15, XO.TEXTUREFORMAT_DEPTH24 = 16, XO.TEXTUREFORMAT_DEPTH24UNORM_STENCIL8 = 17, XO.TEXTUREFORMAT_DEPTH32FLOAT_STENCIL8 = 18, XO.TEXTUREFORMAT_STENCIL8 = 19, XO.TEXTUREFORMAT_UNDEFINED = 4294967295, XO.TEXTUREFORMAT_COMPRESSED_RGBA_BPTC_UNORM = 36492, XO.TEXTUREFORMAT_COMPRESSED_SRGB_ALPHA_BPTC_UNORM = 36493, XO.TEXTUREFORMAT_COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT = 36495, XO.TEXTUREFORMAT_COMPRESSED_RGB_BPTC_SIGNED_FLOAT = 36494, XO.TEXTUREFORMAT_COMPRESSED_RGBA_S3TC_DXT5 = 33779, XO.TEXTUREFORMAT_COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT = 35919, XO.TEXTUREFORMAT_COMPRESSED_RGBA_S3TC_DXT3 = 33778, XO.TEXTUREFORMAT_COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT = 35918, XO.TEXTUREFORMAT_COMPRESSED_RGBA_S3TC_DXT1 = 33777, XO.TEXTUREFORMAT_COMPRESSED_RGB_S3TC_DXT1 = 33776, XO.TEXTUREFORMAT_COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT = 35917, XO.TEXTUREFORMAT_COMPRESSED_SRGB_S3TC_DXT1_EXT = 35916, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_4x4 = 37808, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_5x4 = 37809, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_5x5 = 37810, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_6x5 = 37811, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_6x6 = 37812, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_8x5 = 37813, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_8x6 = 37814, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_8x8 = 37815, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_10x5 = 37816, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_10x6 = 37817, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_10x8 = 37818, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_10x10 = 37819, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_12x10 = 37820, XO.TEXTUREFORMAT_COMPRESSED_RGBA_ASTC_12x12 = 37821, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR = 37840, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR = 37841, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR = 37842, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR = 37843, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR = 37844, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR = 37845, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR = 37846, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR = 37847, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR = 37848, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR = 37849, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR = 37850, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR = 37851, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR = 37852, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR = 37853, XO.TEXTUREFORMAT_COMPRESSED_RGB_ETC1_WEBGL = 36196, XO.TEXTUREFORMAT_COMPRESSED_RGB8_ETC2 = 37492, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ETC2 = 37493, XO.TEXTUREFORMAT_COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2 = 37494, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2 = 37495, XO.TEXTUREFORMAT_COMPRESSED_RGBA8_ETC2_EAC = 37496, XO.TEXTUREFORMAT_COMPRESSED_SRGB8_ALPHA8_ETC2_EAC = 37497, XO.TEXTURETYPE_UNSIGNED_BYTE = 0, XO.TEXTURETYPE_UNSIGNED_INT = 0, XO.TEXTURETYPE_FLOAT = 1, XO.TEXTURETYPE_HALF_FLOAT = 2, XO.TEXTURETYPE_BYTE = 3, XO.TEXTURETYPE_SHORT = 4, XO.TEXTURETYPE_UNSIGNED_SHORT = 5, XO.TEXTURETYPE_INT = 6, XO.TEXTURETYPE_UNSIGNED_INTEGER = 7, XO.TEXTURETYPE_UNSIGNED_SHORT_4_4_4_4 = 8, XO.TEXTURETYPE_UNSIGNED_SHORT_5_5_5_1 = 9, XO.TEXTURETYPE_UNSIGNED_SHORT_5_6_5 = 10, XO.TEXTURETYPE_UNSIGNED_INT_2_10_10_10_REV = 11, XO.TEXTURETYPE_UNSIGNED_INT_24_8 = 12, XO.TEXTURETYPE_UNSIGNED_INT_10F_11F_11F_REV = 13, XO.TEXTURETYPE_UNSIGNED_INT_5_9_9_9_REV = 14, XO.TEXTURETYPE_FLOAT_32_UNSIGNED_INT_24_8_REV = 15, XO.TEXTURETYPE_UNDEFINED = 16, XO.TEXTURE_2D = 3553, XO.TEXTURE_2D_ARRAY = 35866, XO.TEXTURE_CUBE_MAP = 34067, XO.TEXTURE_CUBE_MAP_ARRAY = 3735928559, XO.TEXTURE_3D = 32879, XO.TEXTURE_NEAREST_SAMPLINGMODE = 1, XO.TEXTURE_NEAREST_NEAREST = 1, XO.TEXTURE_BILINEAR_SAMPLINGMODE = 2, XO.TEXTURE_LINEAR_LINEAR = 2, XO.TEXTURE_TRILINEAR_SAMPLINGMODE = 3, XO.TEXTURE_LINEAR_LINEAR_MIPLINEAR = 3, XO.TEXTURE_NEAREST_NEAREST_MIPNEAREST = 4, XO.TEXTURE_NEAREST_LINEAR_MIPNEAREST = 5, XO.TEXTURE_NEAREST_LINEAR_MIPLINEAR = 6, XO.TEXTURE_NEAREST_LINEAR = 7, XO.TEXTURE_NEAREST_NEAREST_MIPLINEAR = 8, XO.TEXTURE_LINEAR_NEAREST_MIPNEAREST = 9, XO.TEXTURE_LINEAR_NEAREST_MIPLINEAR = 10, XO.TEXTURE_LINEAR_LINEAR_MIPNEAREST = 11, XO.TEXTURE_LINEAR_NEAREST = 12, XO.TEXTURE_EXPLICIT_MODE = 0, XO.TEXTURE_SPHERICAL_MODE = 1, XO.TEXTURE_PLANAR_MODE = 2, XO.TEXTURE_CUBIC_MODE = 3, XO.TEXTURE_PROJECTION_MODE = 4, XO.TEXTURE_SKYBOX_MODE = 5, XO.TEXTURE_INVCUBIC_MODE = 6, XO.TEXTURE_EQUIRECTANGULAR_MODE = 7, XO.TEXTURE_FIXED_EQUIRECTANGULAR_MODE = 8, XO.TEXTURE_FIXED_EQUIRECTANGULAR_MIRRORED_MODE = 9, XO.TEXTURE_FILTERING_QUALITY_OFFLINE = 4096, XO.TEXTURE_FILTERING_QUALITY_HIGH = 64, XO.TEXTURE_FILTERING_QUALITY_MEDIUM = 16, XO.TEXTURE_FILTERING_QUALITY_LOW = 8, XO.SCALEMODE_FLOOR = 1, XO.SCALEMODE_NEAREST = 2, XO.SCALEMODE_CEILING = 3, XO.MATERIAL_TextureDirtyFlag = 1, XO.MATERIAL_LightDirtyFlag = 2, XO.MATERIAL_FresnelDirtyFlag = 4, XO.MATERIAL_AttributesDirtyFlag = 8, XO.MATERIAL_MiscDirtyFlag = 16, XO.MATERIAL_PrePassDirtyFlag = 32, XO.MATERIAL_ImageProcessingDirtyFlag = 64, XO.MATERIAL_AllDirtyFlag = 127, XO.MATERIAL_TriangleFillMode = 0, XO.MATERIAL_WireFrameFillMode = 1, XO.MATERIAL_PointFillMode = 2, XO.MATERIAL_PointListDrawMode = 3, XO.MATERIAL_LineListDrawMode = 4, XO.MATERIAL_LineLoopDrawMode = 5, XO.MATERIAL_LineStripDrawMode = 6, XO.MATERIAL_TriangleStripDrawMode = 7, XO.MATERIAL_TriangleFanDrawMode = 8, XO.MATERIAL_ClockWiseSideOrientation = 0, XO.MATERIAL_CounterClockWiseSideOrientation = 1, XO.MATERIAL_DIFFUSE_MODEL_E_OREN_NAYAR = 0, XO.MATERIAL_DIFFUSE_MODEL_BURLEY = 1, XO.MATERIAL_DIFFUSE_MODEL_LAMBERT = 2, XO.MATERIAL_DIFFUSE_MODEL_LEGACY = 3, XO.MATERIAL_DIELECTRIC_SPECULAR_MODEL_GLTF = 0, XO.MATERIAL_DIELECTRIC_SPECULAR_MODEL_OPENPBR = 1, XO.MATERIAL_CONDUCTOR_SPECULAR_MODEL_GLTF = 0, XO.MATERIAL_CONDUCTOR_SPECULAR_MODEL_OPENPBR = 1, XO.ACTION_NothingTrigger = 0, XO.ACTION_OnPickTrigger = 1, XO.ACTION_OnLeftPickTrigger = 2, XO.ACTION_OnRightPickTrigger = 3, XO.ACTION_OnCenterPickTrigger = 4, XO.ACTION_OnPickDownTrigger = 5, XO.ACTION_OnDoublePickTrigger = 6, XO.ACTION_OnPickUpTrigger = 7, XO.ACTION_OnPickOutTrigger = 16, XO.ACTION_OnLongPressTrigger = 8, XO.ACTION_OnPointerOverTrigger = 9, XO.ACTION_OnPointerOutTrigger = 10, XO.ACTION_OnEveryFrameTrigger = 11, XO.ACTION_OnIntersectionEnterTrigger = 12, XO.ACTION_OnIntersectionExitTrigger = 13, XO.ACTION_OnKeyDownTrigger = 14, XO.ACTION_OnKeyUpTrigger = 15, XO.PARTICLES_BILLBOARDMODE_Y = 2, XO.PARTICLES_BILLBOARDMODE_ALL = 7, XO.PARTICLES_BILLBOARDMODE_STRETCHED = 8, XO.PARTICLES_BILLBOARDMODE_STRETCHED_LOCAL = 9, XO.MESHES_CULLINGSTRATEGY_STANDARD = 0, XO.MESHES_CULLINGSTRATEGY_BOUNDINGSPHERE_ONLY = 1, XO.MESHES_CULLINGSTRATEGY_OPTIMISTIC_INCLUSION = 2, XO.MESHES_CULLINGSTRATEGY_OPTIMISTIC_INCLUSION_THEN_BSPHERE_ONLY = 3, XO.SCENELOADER_NO_LOGGING = 0, XO.SCENELOADER_MINIMAL_LOGGING = 1, XO.SCENELOADER_SUMMARY_LOGGING = 2, XO.SCENELOADER_DETAILED_LOGGING = 3, XO.PREPASS_IRRADIANCE_LEGACY_TEXTURE_TYPE = 0, XO.PREPASS_POSITION_TEXTURE_TYPE = 1, XO.PREPASS_VELOCITY_TEXTURE_TYPE = 2, XO.PREPASS_REFLECTIVITY_TEXTURE_TYPE = 3, XO.PREPASS_COLOR_TEXTURE_TYPE = 4, XO.PREPASS_DEPTH_TEXTURE_TYPE = 5, XO.PREPASS_NORMAL_TEXTURE_TYPE = 6, XO.PREPASS_ALBEDO_SQRT_TEXTURE_TYPE = 7, XO.PREPASS_WORLD_NORMAL_TEXTURE_TYPE = 8, XO.PREPASS_LOCAL_POSITION_TEXTURE_TYPE = 9, XO.PREPASS_SCREENSPACE_DEPTH_TEXTURE_TYPE = 10, XO.PREPASS_VELOCITY_LINEAR_TEXTURE_TYPE = 11, XO.PREPASS_ALBEDO_TEXTURE_TYPE = 12, XO.PREPASS_NORMALIZED_VIEW_DEPTH_TEXTURE_TYPE = 13, XO.PREPASS_IRRADIANCE_TEXTURE_TYPE = 14, XO.PREPASS_OBJECT_ID_TEXTURE_TYPE = 15, XO.PREPASS_MESH_BLEND_TAG_TEXTURE_TYPE = 16, XO.BUFFER_CREATIONFLAG_READ = 1, XO.BUFFER_CREATIONFLAG_WRITE = 2, XO.BUFFER_CREATIONFLAG_READWRITE = 3, XO.BUFFER_CREATIONFLAG_UNIFORM = 4, XO.BUFFER_CREATIONFLAG_VERTEX = 8, XO.BUFFER_CREATIONFLAG_INDEX = 16, XO.BUFFER_CREATIONFLAG_STORAGE = 32, XO.BUFFER_CREATIONFLAG_INDIRECT = 64, XO.RENDERPASS_MAIN = 0, XO.INPUT_ALT_KEY = 18, XO.INPUT_CTRL_KEY = 17, XO.INPUT_META_KEY1 = 91, XO.INPUT_META_KEY2 = 92, XO.INPUT_META_KEY3 = 93, XO.INPUT_SHIFT_KEY = 16, XO.SNAPSHOTRENDERING_STANDARD = 0, XO.SNAPSHOTRENDERING_FAST = 1, XO.PERSPECTIVE_CAMERA = 0, XO.ORTHOGRAPHIC_CAMERA = 1, XO.FOVMODE_VERTICAL_FIXED = 0, XO.FOVMODE_HORIZONTAL_FIXED = 1, XO.RIG_MODE_NONE = 0, XO.RIG_MODE_STEREOSCOPIC_ANAGLYPH = 10, XO.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_PARALLEL = 11, XO.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_CROSSEYED = 12, XO.RIG_MODE_STEREOSCOPIC_OVERUNDER = 13, XO.RIG_MODE_STEREOSCOPIC_INTERLACED = 14, XO.RIG_MODE_VR = 20, XO.RIG_MODE_CUSTOM = 22, XO.MAX_SUPPORTED_UV_SETS = 6, XO.GL_ALPHA_EQUATION_ADD = 32774, XO.GL_ALPHA_EQUATION_MIN = 32775, XO.GL_ALPHA_EQUATION_MAX = 32776, XO.GL_ALPHA_EQUATION_SUBTRACT = 32778, XO.GL_ALPHA_EQUATION_REVERSE_SUBTRACT = 32779, XO.GL_ALPHA_FUNCTION_SRC = 768, XO.GL_ALPHA_FUNCTION_ONE_MINUS_SRC_COLOR = 769, XO.GL_ALPHA_FUNCTION_SRC_ALPHA = 770, XO.GL_ALPHA_FUNCTION_ONE_MINUS_SRC_ALPHA = 771, XO.GL_ALPHA_FUNCTION_DST_ALPHA = 772, XO.GL_ALPHA_FUNCTION_ONE_MINUS_DST_ALPHA = 773, XO.GL_ALPHA_FUNCTION_DST_COLOR = 774, XO.GL_ALPHA_FUNCTION_ONE_MINUS_DST_COLOR = 775, XO.GL_ALPHA_FUNCTION_SRC_ALPHA_SATURATED = 776, XO.GL_ALPHA_FUNCTION_CONSTANT_COLOR = 32769, XO.GL_ALPHA_FUNCTION_ONE_MINUS_CONSTANT_COLOR = 32770, XO.GL_ALPHA_FUNCTION_CONSTANT_ALPHA = 32771, XO.GL_ALPHA_FUNCTION_ONE_MINUS_CONSTANT_ALPHA = 32772, XO.GL_ALPHA_FUNCTION_SRC1_COLOR = 35065, XO.GL_ALPHA_FUNCTION_ONE_MINUS_SRC1_COLOR = 35066, XO.GL_ALPHA_FUNCTION_SRC1_ALPHA = 34185, XO.GL_ALPHA_FUNCTION_ONE_MINUS_SRC1_ALPHA = 35067, XO.SnippetUrl = "https://snippet.babylonjs.com", XO.FOGMODE_NONE = 0, XO.FOGMODE_EXP = 1, XO.FOGMODE_EXP2 = 2, XO.FOGMODE_LINEAR = 3, XO.BYTE = 5120, XO.UNSIGNED_BYTE = 5121, XO.SHORT = 5122, XO.UNSIGNED_SHORT = 5123, XO.INT = 5124, XO.UNSIGNED_INT = 5125, XO.FLOAT = 5126, XO.HALF_FLOAT = 5131, XO.PositionKind = "position", XO.NormalKind = "normal", XO.TangentKind = "tangent", XO.UVKind = "uv", XO.UV2Kind = "uv2", XO.UV3Kind = "uv3", XO.UV4Kind = "uv4", XO.UV5Kind = "uv5", XO.UV6Kind = "uv6", XO.ColorKind = "color", XO.ColorInstanceKind = "instanceColor", XO.MatricesIndicesKind = "matricesIndices", XO.MatricesWeightsKind = "matricesWeights", XO.MatricesIndicesExtraKind = "matricesIndicesExtra", XO.MatricesWeightsExtraKind = "matricesWeightsExtra", XO.ANIMATIONTYPE_FLOAT = 0, XO.ANIMATIONTYPE_VECTOR3 = 1, XO.ANIMATIONTYPE_QUATERNION = 2, XO.ANIMATIONTYPE_MATRIX = 3, XO.ANIMATIONTYPE_COLOR3 = 4, XO.ANIMATIONTYPE_COLOR4 = 7, XO.ANIMATIONTYPE_VECTOR2 = 5, XO.ANIMATIONTYPE_SIZE = 6, XO.ShadowMinZ = 0, XO.ShadowMaxZ = 1e4, XO.OUTLINELAYER_SAMPLING_TRIDIRECTIONAL = 0, XO.OUTLINELAYER_SAMPLING_OCTADIRECTIONAL = 1
  },
  39601: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => CO
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35632),
      lO = pO(38347),
      vK = pO(38310);
    let CO = (() => {
      var OO;
      let KO, pO, CO, hO, DO = lO.b,
        MO = [];
      return OO = class extends DO {
        constructor() {
          super(...arguments), this._position = (0, XO.i)(this, MO), this._needProjectionMatrixCompute = !0, this._viewMatrix = eO.c.Identity(), this._projectionMatrix = eO.c.Identity()
        }
        _setPosition(OO) {
          this._position = OO
        }
        get position() {
          return this._position
        }
        set position(OO) {
          this._setPosition(OO)
        }
        _setDirection(OO) {
          this._direction = OO
        }
        get direction() {
          return this._direction
        }
        set direction(OO) {
          this._setDirection(OO)
        }
        get shadowMinZ() {
          return this._shadowMinZ
        }
        set shadowMinZ(OO) {
          this._shadowMinZ = OO, this.forceProjectionMatrixCompute()
        }
        get shadowMaxZ() {
          return this._shadowMaxZ
        }
        set shadowMaxZ(OO) {
          this._shadowMaxZ = OO, this.forceProjectionMatrixCompute()
        }
        computeTransformedInformation() {
          return !(!this.parent || !this.parent.getWorldMatrix) && (this.transformedPosition || (this.transformedPosition = eO.o.Zero()), eO.o.TransformCoordinatesToRef(this.position, this.parent.getWorldMatrix(), this.transformedPosition), this.direction && (this.transformedDirection || (this.transformedDirection = eO.o.Zero()), eO.o.TransformNormalToRef(this.direction, this.parent.getWorldMatrix(), this.transformedDirection)), !0)
        }
        getDepthScale() {
          return 50
        }
        getShadowDirection(OO) {
          return this.transformedDirection ? this.transformedDirection : this.direction
        }
        getAbsolutePosition() {
          return this.transformedPosition ? this.transformedPosition : this.position
        }
        setDirectionToTarget(OO) {
          return this.direction = eO.o.Normalize(OO.subtract(this.position)), this.direction
        }
        getRotation() {
          this.direction.normalize();
          const OO = eO.o.Cross(this.direction, vK.b.Y),
            KO = eO.o.Cross(OO, this.direction);
          return eO.o.RotationFromAxis(OO, KO, this.direction)
        }
        needCube() {
          return !1
        }
        needProjectionMatrixCompute() {
          return this._needProjectionMatrixCompute
        }
        forceProjectionMatrixCompute() {
          this._needProjectionMatrixCompute = !0
        }
        _initCache() {
          super._initCache(), this._cache.position = eO.o.Zero()
        }
        _isSynchronized() {
          return !!this._cache.position.equals(this.position)
        }
        computeWorldMatrix(OO) {
          return !OO && this.isSynchronized() ? (this._currentRenderId = this.JKO().getRenderId(), this._worldMatrix) : (this._updateCache(), this._cache.position.NhO(this.position), this._worldMatrix || (this._worldMatrix = eO.c.Identity()), eO.c.TranslationToRef(this.position.x, this.position.y, this.position.z, this._worldMatrix), this.parent && this.parent.getWorldMatrix && (this._worldMatrix.multiplyToRef(this.parent.getWorldMatrix(), this._worldMatrix), this._markSyncedWithParent()), this._worldMatrixDeterminantIsDirty = !0, this._worldMatrix)
        }
        getDepthMinZ(OO) {
          return void 0 !== this.shadowMinZ ? this.shadowMinZ : OO?.minZ || 0
        }
        getDepthMaxZ(OO) {
          return void 0 !== this.shadowMaxZ ? this.shadowMaxZ : OO?.maxZ || 1e4
        }
        setShadowProjectionMatrix(OO, KO, pO) {
          return this.customProjectionMatrixBuilder ? this.customProjectionMatrixBuilder(KO, pO, OO) : this._setDefaultShadowProjectionMatrix(OO, KO, pO), this
        }
        _syncParentEnabledState() {
          super._syncParentEnabledState(), this.parent && this.parent.getWorldMatrix || (this.transformedPosition = null, this.transformedDirection = null)
        }
        getViewMatrix(OO) {
          const KO = eO.j.WX[0];
          let pO = this.position;
          this.computeTransformedInformation() && (pO = this.transformedPosition), eO.o.NormalizeToRef(this.getShadowDirection(OO), KO), 1 === Math.abs(eO.o.Dot(KO, eO.o.Up())) && (KO.z = 1e-13);
          const XO = eO.j.WX[1];
          return pO.addToRef(KO, XO), eO.c.LookAtLHToRef(pO, XO, eO.o.Up(), this._viewMatrix), this._viewMatrix
        }
        getProjectionMatrix(OO, KO) {
          return this.setShadowProjectionMatrix(this._projectionMatrix, OO ?? this._viewMatrix, KO ?? []), this._projectionMatrix
        }
      }, (() => {
        const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(DO[Symbol.metadata] ?? null) : void 0;
        KO = [(0, bK.L)()], pO = [(0, bK.L)()], CO = [(0, bK.M)()], hO = [(0, bK.M)()], (0, XO.f)(OO, null, KO, {
          kind: "getter",
          name: "position",
          static: !1,
          private: !1,
          access: {
            has: OO => "position" in OO,
            get: OO => OO.position
          },
          metadata: eO
        }, null, MO), (0, XO.f)(OO, null, pO, {
          kind: "getter",
          name: "direction",
          static: !1,
          private: !1,
          access: {
            has: OO => "direction" in OO,
            get: OO => OO.direction
          },
          metadata: eO
        }, null, MO), (0, XO.f)(OO, null, CO, {
          kind: "getter",
          name: "shadowMinZ",
          static: !1,
          private: !1,
          access: {
            has: OO => "shadowMinZ" in OO,
            get: OO => OO.shadowMinZ
          },
          metadata: eO
        }, null, MO), (0, XO.f)(OO, null, hO, {
          kind: "getter",
          name: "shadowMaxZ",
          static: !1,
          private: !1,
          access: {
            has: OO => "shadowMaxZ" in OO,
            get: OO => OO.shadowMaxZ
          },
          metadata: eO
        }, null, MO), eO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: eO
        })
      })(), OO
    })()
  },
  39616: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(38580);
    class bK extends XO.e {
      constructor(OO, KO, pO, bK, eO) {
        let lO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
          vK = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
          CO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 3,
          hO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0,
          DO = arguments.length > 9 ? arguments[9] : void 0,
          MO = arguments.length > 10 ? arguments[10] : void 0,
          aK = arguments.length > 11 ? arguments[11] : void 0,
          oO = arguments.length > 12 ? arguments[12] : void 0;
        super(null, eO, !lO, vK, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, DO), this.format = bK, this._engine && (this._engine._caps.textureFloatLinearFiltering || 1 !== hO || (CO = 1), this._engine._caps.textureHalfFloatLinearFiltering || 2 !== hO || (CO = 1), this._texture = this._engine.createRawTexture(OO, KO, pO, bK, lO, vK, CO, null, hO, DO ?? 0, MO ?? !1, oO), this.wrapU = XO.e.CLAMP_ADDRESSMODE, this.wrapV = XO.e.CLAMP_ADDRESSMODE, this._waitingForData = !!aK && !OO)
      }
      update(OO) {
        this.updateMipLevel(OO, 0)
      }
      updateMipLevel(OO, KO) {
        this._getEngine().updateRawTexture(this._texture, OO, this._texture.format, this._texture.invertY, null, this._texture.type, this._texture._useSRGBBuffer, KO), this._waitingForData = !1
      }
      clone() {
        if (!this._texture) return super.clone();
        const OO = new bK(null, this.getSize().width, this.getSize().height, this.format, this.JKO(), this._texture.generateMipMaps, this._invertY, this.samplingMode, this._texture.type, this._texture._creationFlags, this._useSRGBBuffer);
        return OO._texture = this._texture, this._texture.incrementReferences(), OO
      }
      isReady() {
        return super.isReady() && !this._waitingForData
      }
      static CreateLuminanceTexture(OO, KO, pO, XO) {
        return new bK(OO, KO, pO, 1, XO, !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], arguments.length > 5 && void 0 !== arguments[5] && arguments[5], arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 3)
      }
      static CreateLuminanceAlphaTexture(OO, KO, pO, XO) {
        return new bK(OO, KO, pO, 2, XO, !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], arguments.length > 5 && void 0 !== arguments[5] && arguments[5], arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 3)
      }
      static CreateAlphaTexture(OO, KO, pO, XO) {
        return new bK(OO, KO, pO, 0, XO, !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], arguments.length > 5 && void 0 !== arguments[5] && arguments[5], arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 3)
      }
      static CreateRGBTexture(OO, KO, pO, XO) {
        return new bK(OO, KO, pO, 4, XO, !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], arguments.length > 5 && void 0 !== arguments[5] && arguments[5], arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 3, arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0, arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0, arguments.length > 9 && void 0 !== arguments[9] && arguments[9])
      }
      static CreateRGBATexture(OO, KO, pO, XO) {
        return new bK(OO, KO, pO, 5, XO, !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], arguments.length > 5 && void 0 !== arguments[5] && arguments[5], arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 3, arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0, arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0, arguments.length > 9 && void 0 !== arguments[9] && arguments[9], arguments.length > 10 && void 0 !== arguments[10] && arguments[10])
      }
      static CreateRGBAStorageTexture(OO, KO, pO, XO) {
        return new bK(OO, KO, pO, 5, XO, !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], arguments.length > 5 && void 0 !== arguments[5] && arguments[5], arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 3, arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0, 1, arguments.length > 8 && void 0 !== arguments[8] && arguments[8])
      }
      static CreateRTexture(OO, KO, pO, eO) {
        let lO = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
          vK = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
          CO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : XO.e.TRILINEAR_SAMPLINGMODE;
        return new bK(OO, KO, pO, 6, eO, lO, vK, CO, arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 1)
      }
      static CreateRStorageTexture(OO, KO, pO, eO) {
        let lO = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
          vK = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
          CO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : XO.e.TRILINEAR_SAMPLINGMODE;
        return new bK(OO, KO, pO, 6, eO, lO, vK, CO, arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 1, 1)
      }
    }
  },
  39660: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO.d
    });
    var XO = pO(38537);
    (0, XO.f)()
  },
  39604: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO.d
    });
    var XO = pO(38564);
    (0, XO.g)()
  },
  38564: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => aK,
      g: () => VO
    });
    var XO, bK, eO = pO(35688),
      lO = pO(38216),
      vK = pO(38502),
      CO = pO(38568),
      hO = pO(38382),
      DO = pO(38572),
      MO = pO(37938);
    class aK extends vK.c {
      _isShaderMaterial(OO) {
        return !!OO && "ShaderMaterial" === OO.getClassName()
      }
      constructor(OO) {
        let KO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
          XO = arguments.length > 5 ? arguments[5] : void 0,
          bK = arguments.length > 6 ? arguments[6] : void 0,
          vK = arguments.length > 7 ? arguments[7] : void 0;
        super(OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null, KO, arguments.length > 4 ? arguments[4] : void 0), this.useVertexColor = XO, this.useVertexAlpha = bK, this.color = new eO.e(1, 1, 1), this.alpha = 1, this._shaderLanguage = 0, this._ownsMaterial = !1, KO && (this.color = KO.color.clone(), this.alpha = KO.alpha, this.useVertexColor = KO.useVertexColor, this.useVertexAlpha = KO.useVertexAlpha), this.intersectionThreshold = .1;
        const CO = {
          attributes: [lO.j.PositionKind],
          uniforms: ["world", "viewProjection"],
          needAlphaBlending: !0,
          defines: [],
          useClipPlane: null,
          shaderLanguage: 0
        };
        if (this.useVertexAlpha ? CO.defines.push("#define VERTEXALPHA") : CO.needAlphaBlending = !1, this.useVertexColor ? (CO.defines.push("#define VERTEXCOLOR"), CO.attributes.push(lO.j.ColorKind)) : (CO.uniforms.push("color"), this._color4 = new eO.g), vK) this.material = vK;
        else {
          this.JKO().qb().isWebGPU && !aK.ForceGLSL && (this._shaderLanguage = 1), CO.shaderLanguage = this._shaderLanguage, CO.extraInitializationsAsync = async () => {
            1 === this._shaderLanguage ? await Promise.all([pO.e(324).then((() => pO(40588))), pO.e(330).then((() => pO(40592)))]) : await Promise.all([pO.e(306).then((() => pO(40598))), pO.e(312).then((() => pO(40604)))])
          };
          const OO = new DO.m("colorShader", this.JKO(), "color", CO, !1);
          OO.doNotSerialize = !0, this._ownsMaterial = !0, this._setInternalMaterial(OO)
        }
      }
      getClassName() {
        return "LinesMesh"
      }
      get material() {
        return this._internalAbstractMeshDataInfo._material
      }
      set material(OO) {
        const KO = this.material;
        if (KO === OO) return;
        const pO = KO && this._ownsMaterial;
        this._ownsMaterial = !1, this._setInternalMaterial(OO), pO && KO?.dispose()
      }
      _setInternalMaterial(OO) {
        this._setMaterial(OO), this.material && (this.material.fillMode = hO.b.LineListDrawMode, this.material.disableLighting = !0)
      }
      get checkCollisions() {
        return !1
      }
      set checkCollisions(OO) {}
      _bind(OO, KO) {
        if (!this._geometry) return this;
        const pO = this.isUnIndexed ? null : this._geometry.getIndexBuffer();
        if (!this._userInstancedBuffersStorage || this.hasThinInstances ? this._geometry._bind(KO, pO) : this._geometry._bind(KO, pO, this._userInstancedBuffersStorage.vertexBuffers, this._userInstancedBuffersStorage.vertexArrayObjects), !this.useVertexColor && this._isShaderMaterial(this.material)) {
          const {
            r: OO,
            g: KO,
            b: pO
          } = this.color;
          this._color4.set(OO, KO, pO, this.alpha), this.material.setColor4("color", this._color4)
        }
        return this
      }
      _draw(OO, KO, pO) {
        if (!this._geometry || !this._geometry.getVertexBuffers() || !this._unIndexed && !this._geometry.getIndexBuffer()) return this;
        const XO = this.JKO().qb();
        return this._unIndexed ? XO.drawArraysType(hO.b.LineListDrawMode, OO.verticesStart, OO.verticesCount, pO) : XO.drawElementsType(hO.b.LineListDrawMode, OO.indexStart, OO.indexCount, pO), this
      }
      dispose(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        (arguments.length > 2 ? arguments[2] : void 0) || (this._ownsMaterial || KO) && this.material?.dispose(!1, !1, !0), super.dispose(OO)
      }
      clone(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        if (KO && void 0 === KO._addToSceneRootNodes) {
          const pO = KO;
          return pO.source = this, new aK(OO, this.JKO(), pO.parent, pO.source, pO.doNotCloneChildren)
        }
        return new aK(OO, this.JKO(), KO, this, pO)
      }
      createInstance(OO) {
        const KO = new oO(OO, this);
        if (this.lpO) {
          KO.lpO = {};
          for (const OO in this.lpO) KO.lpO[OO] = this.lpO[OO]
        }
        return KO
      }
      serialize(OO) {
        super.serialize(OO), OO.color = this.color.WhO(), OO.alpha = this.alpha
      }
      static Parse(OO, KO) {
        const pO = new aK(OO.name, KO);
        return pO.color = eO.e.FromArray(OO.color), pO.alpha = OO.alpha, pO
      }
    }
    aK.ForceGLSL = !1;
    class oO extends CO.d {
      constructor(OO, KO) {
        super(OO, KO), this.intersectionThreshold = KO.intersectionThreshold
      }
      getClassName() {
        return "InstancedLinesMesh"
      }
    }
    let FO = !1;

    function VO() {
      FO || (FO = !0, vK.c._LinesMeshParser = (OO, KO) => aK.Parse(OO, KO))
    }(XO = aK.prototype).enableEdgesRendering ?? (XO.enableEdgesRendering = (0, MO.h)("LinesMesh", "enableEdgesRendering")), (bK = oO.prototype).enableEdgesRendering ?? (bK.enableEdgesRendering = (0, MO.h)("InstancedLinesMesh", "enableEdgesRendering"))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);