export const id = 231;
export const ids = [231];
export const modules = {
  37875: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => xK
    });
    pO(5611);
    var XO = pO(63),
      bK = pO(37880),
      eO = pO(38162),
      lO = pO(38284),
      vK = pO(38338),
      CO = pO(38355),
      hO = pO(35680),
      DO = pO(35624),
      MO = pO(38499),
      aK = pO(38557),
      oO = (pO(38587), pO(1077)),
      FO = pO(171),
      VO = pO(1051),
      LO = pO(22),
      QO = pO(2209),
      zK = pO(1271),
      AO = pO(933),
      fO = pO(5602),
      dO = pO(5620),
      TO = pO(3635),
      NO = pO(976);
    const IO = 1.2,
      yK = .2,
      gK = .0066 * Math.PI / 180,
      uO = new Set(["Escape", "KeyG"]),
      EO = {
        ArrowLeft: -1,
        ArrowRight: 1
      },
      jK = "ArrowUp",
      YO = new Set([...Object.keys(EO), jK, "ArrowDown"]),
      wO = 32,
      iK = 1,
      rK = 10,
      PO = "F4",
      mK = "Period",
      sO = Math.PI / 2 - .001,
      HO = Math.PI / 6,
      RO = Math.PI / 6,
      SO = 1.08,
      JO = [{
        name: "X",
        direction: [1, 0, 0],
        colour: "#e5534b"
      }, {
        name: "Y",
        direction: [0, 1, 0],
        colour: "#57ab5a"
      }, {
        name: "Z",
        direction: [0, 0, 1],
        colour: "#539bf5"
      }],
      cK = 24,
      BO = 7,
      ZO = 4,
      GO = .01,
      qK = 4;

    function xK(OO) {
      let {
        heatmap: KO,
        scale: pO,
        fullyOpaqueFrom: iK,
        bounds: HO,
        fitBounds: RO,
        schematic: SO,
        controls: JO,
        onStepTime: cK,
        onShowAllTime: BO,
        onTogglePlaying: ZO,
        getReadout: qK = null
      } = OO;
      const {
        t: xK
      } = (0, VO.D)(), {
        clientEscMenuOptions: eK
      } = (0, LO.l)(["clientEscMenuOptions"]), CK = (0, XO.useRef)(null), hK = (0, XO.useRef)(null), DK = (0, XO.useRef)(null), MK = (0, QO.d)(CK), [ap, oK] = (0, XO.useState)(!1), [FK, VK] = (0, XO.useState)(!1), [LK, QK] = (0, XO.useState)(!0), zp = (0, XO.useRef)(!1), [AK, fK] = (0, XO.useState)(!1), dK = FK || !LK && AK, [TK, NK] = (0, XO.useState)(!1), [IK, yp] = (0, XO.useState)(!0), [gp, uK] = (0, XO.useState)(null), EK = HO.min, [jp, YK] = (0, XO.useState)(EK);
      jp[0] === EK[0] && jp[1] === EK[1] && jp[2] === EK[2] || (YK(EK), null !== gp && uK({
        ...gp,
        position: lK(gp.position, lK(jp, vp(EK, -1)))
      }));
      const wK = (0, XO.useMemo)((() => function(OO) {
          return [OO.max[0] - OO.min[0] + 1, OO.max[1] - OO.min[1] + 1, OO.max[2] - OO.min[2] + 1]
        }(HO)), [HO]),
        ip = (0, XO.useMemo)((() => function(OO, KO) {
          const pO = [],
            XO = [];
          for (const [bK, eO] of Object.entries(OO.frequencies)) {
            const OO = Number(bK);
            for (const [bK, lO] of Object.entries(eO)) {
              const eO = Number(bK);
              for (const [bK, vK] of Object.entries(lO)) vK <= 0 || (pO.push(OO - KO[0], eO - KO[1], Number(bK) - KO[2]), XO.push(vK))
            }
          }
          return {
            positions: Int32Array.from(pO),
            values: Float64Array.from(XO),
            count: XO.length
          }
        }(KO, EK)), [KO, EK]),
        rp = IO * eK.cameraFOV / 100,
        PK = MK.height > 0 ? MK.width / MK.height : 1,
        mp = (0, XO.useMemo)((() => function(OO, KO) {
          return {
            min: [OO.min[0] - KO[0], OO.min[1] - KO[1], OO.min[2] - KO[2]],
            max: [OO.max[0] - KO[0] + 1, OO.max[1] - KO[1] + 1, OO.max[2] - KO[2] + 1]
          }
        }(RO, EK)), [RO, EK]),
        sK = pK(mp, PK, rp),
        HK = null !== gp && void 0 !== gp ? gp : sK,
        RK = (0, XO.useRef)({
          fittedView: sK,
          fieldOfView: rp,
          mouseSensitivity: eK.mouseSensitivity,
          canLock: LK
        });
      RK.current = {
        fittedView: sK,
        fieldOfView: rp,
        mouseSensitivity: eK.mouseSensitivity,
        canLock: LK
      };
      const SK = (0, XO.useMemo)((() => {
          if (!dK) return null;
          const OO = (OO, pO, XO) => {
              var bK, eO, lO;
              return null !== (bK = null === (eO = KO.frequencies[OO + EK[0]]) || void 0 === eO || null === (lO = eO[pO + EK[1]]) || void 0 === lO ? void 0 : lO[XO + EK[2]]) && void 0 !== bK ? bK : 0
            },
            XO = function(OO, KO, pO, XO) {
              let bK = 0,
                eO = 1 / 0;
              for (const MO of [0, 1, 2]) {
                if (0 === KO[MO]) {
                  if (OO[MO] < 0 || OO[MO] > pO[MO]) return null;
                  continue
                }
                const XO = (0 - OO[MO]) / KO[MO],
                  lO = (pO[MO] - OO[MO]) / KO[MO];
                bK = Math.max(bK, Math.min(XO, lO)), eO = Math.min(eO, Math.max(XO, lO))
              }
              if (bK > eO) return null;
              const lO = [0, 1, 2].map((XO => Math.min(pO[XO] - 1, Math.max(0, Math.floor(OO[XO] + KO[XO] * bK))))),
                vK = [0, 1, 2].map((OO => Math.sign(KO[OO]))),
                CO = [0, 1, 2].map((pO => {
                  if (0 === vK[pO]) return 1 / 0;
                  return ((vK[pO] > 0 ? lO[pO] + 1 : lO[pO]) - OO[pO]) / KO[pO]
                })),
                hO = [0, 1, 2].map((OO => 0 === vK[OO] ? 1 / 0 : Math.abs(1 / KO[OO])));
              let DO = null;
              for (;;) {
                const OO = XO(lO[0], lO[1], lO[2]);
                if (OO >= 1) return lO;
                OO > 0 && (DO = [lO[0], lO[1], lO[2]]);
                const KO = CO[0] < CO[1] ? CO[0] < CO[2] ? 0 : 2 : CO[1] < CO[2] ? 1 : 2;
                if (CO[KO] > eO) return DO;
                if (lO[KO] += vK[KO], CO[KO] += hO[KO], lO[KO] < 0 || lO[KO] >= pO[KO]) return DO
              }
            }(HK.position, OK(HK), wK, ((KO, XO, bK) => (0, fO.x)(OO(KO, XO, bK), pO, iK)));
          return null === XO ? null : {
            x: XO[0] + EK[0],
            y: XO[1] + EK[1],
            z: XO[2] + EK[2],
            value: OO(XO[0], XO[1], XO[2])
          }
        }), [dK, KO, EK, HK, wK, pO, iK]),
        {
          keyHandlers: JK
        } = (0, dO.g)({
          isEnabled: dK,
          claimedKeyCodes: YO,
          AK: OO => {
            uK((KO => function(OO, KO) {
              const pO = [Math.sin(OO.heading), 0, Math.cos(OO.heading)],
                XO = lK(lK(vp(pO, KO.forward), vp(KK(OO.heading), KO.right)), [0, KO.up, 0]);
              return {
                ...OO,
                position: lK(OO.position, XO)
              }
            }(null !== KO && void 0 !== KO ? KO : RK.current.fittedView, OO)))
          },
          onZoomChange: NK
        });
      (0, XO.useEffect)((() => {
        const OO = hK.current;
        if (!OO) return;
        let KO;
        try {
          KO = function(OO, KO) {
            const pO = new bK.d(OO, !0, {
                stencil: !1
              }, !0),
              XO = new eO.d(pO),
              [oO, FO, VO] = fO.R;
            XO.clearColor = new hO.c(oO / 255, FO / 255, VO / 255, 1);
            const LO = new lO.b("Heatmap3DCamera", DO.WX.Zero(), XO);
            LO.fov = KO, LO.minZ = .05;
            const QO = new vK.b("Heatmap3DLight", new DO.WX(.4, 1, -.6), XO);
            QO.diffuse = hO.Color3.White(), QO.groundColor = hO.Color3.Black(), QO.specular = hO.Color3.Black();
            const zK = new CO.StandardMaterial("Heatmap3DCellMaterial", XO);
            zK.diffuseColor = new hO.Color3(.4, .4, .4), zK.emissiveColor = new hO.Color3(.62, .62, .62), zK.specularColor = hO.Color3.Black();
            const AO = (0, MO.e)("Heatmap3DCells", {
              size: 1
            }, XO);
            AO.material = zK, AO.De = !1, AO.xb = !0, AO.isVisible = !1;
            const dO = (0, MO.e)("Heatmap3DTranslucentCells", {
              size: 1
            }, XO);
            dO.material = zK, dO.hasVertexAlpha = !0, dO.De = !1, dO.xb = !0, dO.isVisible = !1;
            const TO = new CO.StandardMaterial("Heatmap3DSchematicMaterial", XO);
            TO.diffuseColor = new hO.Color3(.6, .6, .6), TO.emissiveColor = new hO.Color3(.4, .4, .4), TO.specularColor = hO.Color3.Black();
            const NO = (0, MO.e)("Heatmap3DSchematicBlocks", {
              size: 1
            }, XO);
            NO.material = TO, NO.De = !1, NO.xb = !0, NO.isVisible = !1;
            const IO = (0, aK.b)("Heatmap3DTarget", {
              lines: UO([-.52, -.52, -.52], [.52, .52, .52])
            }, XO);
            return IO.color = new hO.Color3(.06, .14, .23), IO.renderingGroupId = 1, IO.De = !1, IO.isVisible = !1, {
              engine: pO,
              Ce: XO,
              camera: LO,
              cells: AO,
              translucentCells: dO,
              translucent: {
                gp: new Float32Array(0),
                colours: new Float32Array(0),
                count: 0
              },
              translucentSortedFrom: null,
              schematicBlocks: NO,
              targetOutline: IO,
              chunkGrid: null,
              chunkGridCentre: null,
              chunkGridOrigin: null,
              targetFieldOfView: KO,
              needsRender: !0
            }
          }(OO, RK.current.fieldOfView)
        } catch (pO) {
          return console.error("Failed to start the 3D heatmap", pO), void oK(!0)
        }
        return DK.current = KO, KO.engine.runRenderLoop((() => {
          const OO = KO.camera;
          OO.fov !== KO.targetFieldOfView && (OO.fov += (KO.targetFieldOfView - OO.fov) * (OO.fov > KO.targetFieldOfView ? .3 : .2), Math.abs(KO.targetFieldOfView - OO.fov) < 5e-4 && (OO.fov = KO.targetFieldOfView), KO.needsRender = !0), KO.needsRender && (KO.Ce.render(), KO.needsRender = !KO.Ce.isReady() || !KO.engine.areAllEffectsReady())
        })), () => {
          DK.current = null, KO.engine.dispose()
        }
      }), []), (0, XO.useEffect)((() => {
        const OO = hK.current;
        if (!OO) return;
        const KO = () => {
            zp.current = !1, VK(document.pointerLockElement === OO)
          },
          pO = () => {
            zp.current && (zp.current = !1, QK(!1))
          },
          XO = KO => {
            const pO = !RK.current.canLock && document.activeElement === OO && 0 !== (1 & KO.buttons);
            if (document.pointerLockElement !== OO && !pO) return;
            const XO = RK.current.mouseSensitivity * gK;
            uK((OO => function(OO, KO, pO) {
              const XO = 2 * Math.PI;
              return {
                ...OO,
                heading: ((OO.heading + KO) % XO + XO) % XO,
                pitch: Math.max(-sO, Math.min(sO, OO.pitch + pO))
              }
            }(null !== OO && void 0 !== OO ? OO : RK.current.fittedView, KO.movementX * XO, KO.movementY * XO)))
          };
        return document.addEventListener("pointerlockchange", KO), document.addEventListener("pointerlockerror", pO), document.addEventListener("pointermove", XO), () => {
          document.removeEventListener("pointerlockchange", KO), document.removeEventListener("pointerlockerror", pO), document.removeEventListener("pointermove", XO), document.pointerLockElement === OO && (0, TO.c)()
        }
      }), []), (0, XO.useEffect)((() => {
        const OO = DK.current;
        null !== OO && 0 !== MK.width && 0 !== MK.height && (OO.engine.resize(), OO.needsRender = !0)
      }), [MK.width, MK.height]), (0, XO.useEffect)((() => {
        const OO = DK.current;
        null !== OO && (OO.targetFieldOfView = rp * (TK ? yK : 1))
      }), [rp, TK]), (0, XO.useEffect)((() => {
        const OO = DK.current;
        null !== OO && function(OO, KO, pO, XO) {
          const bK = [],
            eO = [],
            lO = [],
            vK = [];
          for (let CO = 0; CO < KO.count; CO++) {
            const OO = KO.values[CO],
              hO = (0, fO.x)(OO, pO, XO);
            if (hO <= 0) continue;
            const [DO, MO, aK] = (0, fO.r)((0, fO.K)(OO, pO)), oO = hO >= 1;
            (oO ? bK : lO).push(KO.positions[3 * CO] + .5, KO.positions[3 * CO + 1] + .5, KO.positions[3 * CO + 2] + .5), (oO ? eO : vK).push(DO / 255, MO / 255, aK / 255, hO)
          }
          tK(OO.cells, Float32Array.from(bK), Float32Array.from(eO), eO.length / 4), OO.translucent = {
            gp: Float32Array.from(lO),
            colours: Float32Array.from(vK),
            count: vK.length / 4
          }, OO.translucentSortedFrom = null, kK(OO), OO.needsRender = !0
        }(OO, ip, pO, iK)
      }), [ip, pO, iK]), (0, XO.useEffect)((() => {
        const OO = DK.current;
        null !== OO && function(OO, KO) {
          OO.chunkGridOrigin = KO, OO.chunkGridCentre = null, WO(OO)
        }(OO, HO.min)
      }), [HO]), (0, XO.useEffect)((() => {
        const OO = DK.current;
        null !== OO && function(OO, KO, pO) {
          const XO = [],
            bK = [];
          if (null !== KO) {
            const {
              positions: OO,
              colours: eO,
              count: lO
            } = KO.surface;
            for (let KO = 0; KO < lO; KO++) {
              const lO = [OO[3 * KO], OO[3 * KO + 1], OO[3 * KO + 2]];
              [0, 1, 2].every((OO => lO[OO] >= pO.min[OO] - wO && lO[OO] <= pO.max[OO] + wO)) && (XO.push(lO[0] - pO.min[0] + .5, lO[1] - pO.min[1] + .5, lO[2] - pO.min[2] + .5), bK.push(eO[3 * KO] / 255, eO[3 * KO + 1] / 255, eO[3 * KO + 2] / 255, 1))
            }
          }
          tK(OO.schematicBlocks, Float32Array.from(XO), Float32Array.from(bK), bK.length / 4), OO.needsRender = !0
        }(OO, SO, HO)
      }), [SO, HO]), (0, XO.useEffect)((() => {
        const OO = DK.current;
        null !== OO && null !== OO.chunkGrid && (OO.chunkGrid.isVisible = IK, OO.needsRender = !0)
      }), [IK, HO]), (0, XO.useEffect)((() => {
        const OO = DK.current;
        null !== OO && function(OO, KO, pO) {
          const {
            camera: XO
          } = OO;
          XO.position.set(KO.position[0], KO.position[1], KO.position[2]), XO.rotation.set(KO.pitch, KO.heading, 0);
          const bK = (rK + 1) * FO.h.SX * Math.sqrt(3);
          XO.maxZ = Math.max(bK, Math.hypot(...lK(KO.position, vp(bp({
            min: [0, 0, 0],
            max: pO
          }), -1))) + 2 * Math.hypot(...pO)), WO(OO), kK(OO), OO.needsRender = !0
        }(OO, HK, wK)
      }), [HK, wK]), (0, XO.useEffect)((() => {
        const OO = DK.current;
        null !== OO && (OO.targetOutline.isVisible = null !== SK, null !== SK && OO.targetOutline.position.set(SK.x - EK[0] + .5, SK.y - EK[1] + .5, SK.z - EK[2] + .5), OO.needsRender = !0)
      }), [SK, EK]);
      return (0, NO.jsxs)("div", {
        className: "StudioHeatmapMap StudioHeatmap3D",
        ref: CK,
        children: [(0, NO.jsx)("canvas", {
          className: "StudioHeatmapMapCanvas",
          ref: hK,
          style: {
            width: `${MK.width}px`,
            height: `${MK.height}px`
          },
          tabIndex: 0,
          "aria-label": xK("3D heatmap"),
          onClick: () => {
            const OO = hK.current;
            if (null === OO) return;
            if (OO.focus({
                preventScroll: !0
              }), FK || !LK) return;
            const KO = OO.requestPointerLock();
            KO instanceof Promise ? KO.catch((OO => {
              OO instanceof DOMException && ("WrongDocumentError" === OO.name || "NotSupportedError" === OO.name) && QK(!1)
            })) : zp.current = !0
          },
          ...JK,
          onKeyDown: OO => {
            if (dK && uO.has(OO.code)) return OO.preventDefault(), void(() => {
              const OO = hK.current;
              null !== OO && document.pointerLockElement === OO ? (0, TO.c)() : null === OO || void 0 === OO || OO.blur()
            })();
            const KO = EO[OO.code];
            return dK && void 0 !== KO ? (OO.preventDefault(), void cK(KO)) : dK && (0, dO.d)("replayPlayPause", OO.code) && !(0, dO.d)("Zoom", OO.code) ? (OO.preventDefault(), void(OO.repeat || ZO())) : dK && OO.code === jK ? (OO.preventDefault(), void BO()) : dK && OO.code === mK ? (OO.preventDefault(), void uK(null)) : dK && OO.code === PO ? (OO.preventDefault(), void yp((OO => !OO))) : void JK.onKeyDown(OO)
          },
          onFocus: () => {
            fK(!0)
          },
          onBlur: () => {
            fK(!1), JK.onBlur()
          }
        }), ap && (0, NO.jsx)("div", {
          className: "StudioHeatmap3DUnavailable SmallTextLight",
          children: xK("3D view isn't available in this browser.")
        }), dK && (0, NO.jsx)("div", {
          className: "StudioHeatmap3DCrosshair"
        }), (0, NO.jsx)("div", {
          className: "StudioHeatmap3DCoordinates SmallTextLight",
          children: HK.position.map(((OO, KO) => (OO + EK[KO]).toFixed(2))).join(" ")
        }), IK && (0, NO.jsx)(nO, {
          heading: HK.heading,
          pitch: HK.pitch,
          onViewFrom: OO => {
            const KO = vp(OO, -1),
              pO = 0 === KO[1] ? {
                heading: Math.atan2(KO[0], KO[2]),
                pitch: 0
              } : {
                heading: HK.heading,
                pitch: KO[1] < 0 ? sO : -sO
              };
            uK(pK(mp, PK, rp, pO))
          },
          onTurn: (OO, KO) => {
            uK((pO => function(OO, KO, pO, XO) {
              return XK(OO, KO, {
                heading: OO.heading + pO * GO,
                pitch: Math.max(-sO, Math.min(sO, OO.pitch + XO * GO))
              })
            }(null !== pO && void 0 !== pO ? pO : RK.current.fittedView, bp(mp), OO, KO)))
          },
          onFlip: () => {
            uK((OO => function(OO, KO) {
              return XK(OO, KO, {
                heading: OO.heading + Math.PI,
                pitch: -OO.pitch
              })
            }(null !== OO && void 0 !== OO ? OO : RK.current.fittedView, bp(mp))))
          }
        }), null !== SK && (0, NO.jsx)("div", {
          className: "StudioHeatmapMapReadout SmallTextLight",
          children: null === qK ? xK("studio:heatmapBlockReadout", {
            x: SK.x,
            y: SK.y,
            z: SK.z,
            count: (0, oO.L)(SK.value)
          }) : qK(SK.x, SK.y, SK.z, SK.value)
        }), (0, NO.jsxs)("div", {
          className: "StudioHeatmapMapControls",
          children: [JO, (0, NO.jsx)(zK.S, {
            active: null === gp,
            onClick: () => {
              uK(null)
            },
            children: (0, NO.jsx)(AO.d, {
              name: "eye"
            })
          })]
        })]
      })
    }

    function nO(OO) {
      let {
        heading: KO,
        pitch: pO,
        onViewFrom: bK,
        onTurn: eO,
        onFlip: lO
      } = OO;
      const {
        t: vK
      } = (0, VO.D)(), CO = (0, XO.useRef)(null), hO = OK({
        heading: KO,
        pitch: pO
      }), DO = KK(KO), MO = hK(hO, DO), aK = cK + BO + 2, oO = JO.flatMap((OO => [1, -1].map((KO => {
        const pO = vp(OO.direction, KO);
        return {
          ...OO,
          sign: KO,
          direction: pO,
          endX: aK + CK(pO, DO) * cK,
          endY: aK - CK(pO, MO) * cK,
          depth: CK(pO, hO)
        }
      })))).sort(((OO, KO) => KO.depth - OO.depth));
      return (0, NO.jsxs)("svg", {
        className: "StudioHeatmap3DGizmo",
        width: 2 * aK,
        height: 2 * aK,
        "aria-hidden": !0,
        onPointerDown: OO => {
          var KO, pO;
          OO.currentTarget.setPointerCapture(OO.pointerId);
          const XO = OO.target,
            bK = XO.getAttribute("data-end");
          CO.current = {
            pointerId: OO.pointerId,
            x: OO.clientX,
            y: OO.clientY,
            travel: 0,
            side: null === bK ? null : null !== (KO = null === (pO = oO[Number(bK)]) || void 0 === pO ? void 0 : pO.direction) && void 0 !== KO ? KO : null,
            isOnMiddle: XO.hasAttribute("data-middle")
          }
        },
        onPointerMove: OO => {
          const KO = CO.current;
          if (null === KO || KO.pointerId !== OO.pointerId) return;
          const pO = OO.clientX - KO.x,
            XO = OO.clientY - KO.y;
          KO.x = OO.clientX, KO.y = OO.clientY, KO.travel += Math.abs(pO) + Math.abs(XO), KO.travel >= qK && eO(pO, XO)
        },
        onPointerUp: OO => {
          const KO = CO.current;
          CO.current = null, null === KO || KO.pointerId !== OO.pointerId || KO.travel >= qK || (null !== KO.side ? bK(KO.side) : KO.isOnMiddle && lO())
        },
        onPointerCancel: () => {
          CO.current = null
        },
        children: [oO.map(((OO, KO) => {
          const pO = OO.sign > 0;
          return (0, NO.jsxs)("g", {
            children: [(0, NO.jsx)("line", {
              x1: aK,
              y1: aK,
              x2: OO.endX,
              y2: OO.endY,
              stroke: OO.colour,
              strokeOpacity: pO ? 1 : .5,
              strokeWidth: 2,
              strokeLinecap: "round"
            }), (0, NO.jsx)("circle", {
              className: "StudioHeatmap3DGizmoEnd",
              "data-end": KO,
              cx: OO.endX,
              cy: OO.endY,
              r: pO ? BO : BO - 1,
              fill: OO.colour,
              fillOpacity: pO ? 1 : .3,
              stroke: OO.colour,
              strokeWidth: pO ? 0 : 1.5,
              children: (0, NO.jsx)("title", {
                children: `${vK("View from")} ${pO?"+":"\u2212"}${OO.name}`
              })
            }), pO && (0, NO.jsx)("text", {
              pointerEvents: "none",
              x: OO.endX,
              y: OO.endY,
              fill: "#151515",
              fontSize: 9,
              fontWeight: "bold",
              textAnchor: "middle",
              dominantBaseline: "central",
              children: OO.name
            })]
          }, `${pO?"+":"-"}${OO.name}`)
        })), (0, NO.jsx)("circle", {
          className: "StudioHeatmap3DGizmoEnd",
          "data-middle": !0,
          cx: aK,
          cy: aK,
          r: ZO,
          fill: "#d0d0d0",
          fillOpacity: .85,
          children: (0, NO.jsx)("title", {
            children: vK("View from the opposite side")
          })
        })]
      })
    }

    function WO(OO) {
      var KO, pO, XO;
      const {
        chunkGridOrigin: bK,
        camera: eO
      } = OO;
      if (null === bK) return;
      const lO = [eO.position.x, eO.position.y, eO.position.z],
        vK = [0, 2].map((OO => Math.floor((lO[OO] + bK[OO]) / FO.h.SX))),
        CO = OO.chunkGridCentre;
      if (null !== CO && CO.every(((OO, KO) => OO === vK[KO]))) return;
      const MO = null === (KO = null === (pO = OO.chunkGrid) || void 0 === pO ? void 0 : pO.isVisible) || void 0 === KO || KO;
      null === (XO = OO.chunkGrid) || void 0 === XO || XO.dispose();
      const [oO, VO] = [0, 2].map(((OO, KO) => {
        const pO = [];
        for (let XO = vK[KO] - rK; XO <= vK[KO] + rK + 1; XO++) pO.push(XO * FO.h.SX - bK[OO]);
        return pO
      })), LO = -bK[1], QO = [];
      for (const hO of VO) QO.push([new DO.WX(oO[0], LO, hO), new DO.WX(oO[oO.length - 1], LO, hO)]);
      for (const hO of oO) QO.push([new DO.WX(hO, LO, VO[0]), new DO.WX(hO, LO, VO[VO.length - 1])]);
      const zK = (0, aK.b)("Heatmap3DChunkGrid", {
        lines: QO
      }, OO.Ce);
      zK.color = new hO.Color3(.45, .6, .78), zK.De = !1, zK.isVisible = MO, OO.chunkGrid = zK, OO.chunkGridCentre = vK, OO.needsRender = !0
    }

    function tK(OO, KO, pO, XO) {
      OO.ulO("matrix", function(OO, KO) {
        const pO = new Float32Array(16 * KO);
        for (let XO = 0; XO < KO; XO++) {
          const KO = 16 * XO;
          pO[KO] = 1, pO[KO + 5] = 1, pO[KO + 10] = 1, pO[KO + 12] = OO[3 * XO], pO[KO + 13] = OO[3 * XO + 1], pO[KO + 14] = OO[3 * XO + 2], pO[KO + 15] = 1
        }
        return pO
      }(KO, XO), 16, !0), OO.ulO("color", pO, 4, !0), OO.isVisible = XO > 0
    }

    function kK(OO) {
      const {
        camera: KO,
        translucent: pO
      } = OO, XO = [KO.position.x, KO.position.y, KO.position.z], bK = OO.translucentSortedFrom;
      if (null !== bK && Math.hypot(XO[0] - bK[0], XO[1] - bK[1], XO[2] - bK[2]) < iK) return;
      OO.translucentSortedFrom = XO;
      const eO = new Float64Array(pO.count),
        lO = new Uint32Array(pO.count);
      for (let hO = 0; hO < pO.count; hO++) {
        const OO = pO.gp[3 * hO] - XO[0],
          KO = pO.gp[3 * hO + 1] - XO[1],
          bK = pO.gp[3 * hO + 2] - XO[2];
        eO[hO] = OO * OO + KO * KO + bK * bK, lO[hO] = hO
      }
      lO.sort(((OO, KO) => eO[KO] - eO[OO]));
      const vK = new Float32Array(3 * pO.count),
        CO = new Float32Array(4 * pO.count);
      lO.forEach(((OO, KO) => {
        vK.set(pO.gp.subarray(3 * OO, 3 * OO + 3), 3 * KO), CO.set(pO.colours.subarray(4 * OO, 4 * OO + 4), 4 * KO)
      })), tK(OO.translucentCells, vK, CO, pO.count), OO.needsRender = !0
    }

    function UO(OO, KO) {
      const pO = (pO, XO, bK) => new DO.WX(0 === pO ? OO[0] : KO[0], 0 === XO ? OO[1] : KO[1], 0 === bK ? OO[2] : KO[2]),
        XO = [];
      for (const bK of [0, 1])
        for (const OO of [0, 1]) XO.push([pO(0, bK, OO), pO(1, bK, OO)], [pO(bK, 0, OO), pO(bK, 1, OO)], [pO(bK, OO, 0), pO(bK, OO, 1)]);
      return XO
    }

    function OK(OO) {
      return [Math.sin(OO.heading) * Math.cos(OO.pitch), -Math.sin(OO.pitch), Math.cos(OO.heading) * Math.cos(OO.pitch)]
    }

    function KK(OO) {
      return [Math.cos(OO), 0, -Math.sin(OO)]
    }

    function pK(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {
        heading: HO,
        pitch: RO
      };
      const bK = [OO.max[0] - OO.min[0], OO.max[1] - OO.min[1], OO.max[2] - OO.min[2]],
        eO = OK(XO),
        lO = KK(XO.heading),
        vK = hK(eO, lO),
        CO = Math.tan(pO / 2),
        hO = CO * KO;
      let DO = 1;
      for (const MO of [-bK[0] / 2, bK[0] / 2])
        for (const OO of [-bK[1] / 2, bK[1] / 2])
          for (const KO of [-bK[2] / 2, bK[2] / 2]) {
            const pO = [MO, OO, KO],
              XO = CK(pO, eO);
            DO = Math.max(DO, Math.abs(CK(pO, lO)) / hO - XO, Math.abs(CK(pO, vK)) / CO - XO)
          }
      return {
        position: lK([OO.min[0] + bK[0] / 2, OO.min[1] + bK[1] / 2, OO.min[2] + bK[2] / 2], vp(eO, -DO * SO)),
        heading: XO.heading,
        pitch: XO.pitch
      }
    }

    function XK(OO, KO, pO) {
      const XO = eK(OO),
        bK = eK(pO),
        eO = lK(OO.position, vp(KO, -1)),
        lO = [0, 1, 2].reduce(((OO, KO) => lK(OO, vp(bK[KO], CK(eO, XO[KO])))), [0, 0, 0]);
      return {
        position: lK(KO, lO),
        heading: pO.heading,
        pitch: pO.pitch
      }
    }

    function bp(OO) {
      return vp(lK(OO.min, OO.max), .5)
    }

    function eK(OO) {
      const KO = OK(OO),
        pO = KK(OO.heading);
      return [KO, pO, hK(KO, pO)]
    }

    function lK(OO, KO) {
      return [OO[0] + KO[0], OO[1] + KO[1], OO[2] + KO[2]]
    }

    function vp(OO, KO) {
      return [OO[0] * KO, OO[1] * KO, OO[2] * KO]
    }

    function CK(OO, KO) {
      return OO[0] * KO[0] + OO[1] * KO[1] + OO[2] * KO[2]
    }

    function hK(OO, KO) {
      return [OO[1] * KO[2] - OO[2] * KO[1], OO[2] * KO[0] - OO[0] * KO[2], OO[0] * KO[1] - OO[1] * KO[0]]
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);