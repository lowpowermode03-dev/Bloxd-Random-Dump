export const id = 239;
export const ids = [239];
export const modules = {
  38284: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => gK
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35632),
      lO = pO(38287),
      vK = pO(38330),
      CO = pO(38258),
      hO = pO(38172);
    let DO = (() => {
      var OO;
      let KO, pO, lO, vK, DO, MO, aK, oO, FO, VO, LO, QO = [],
        zK = [],
        AO = [],
        fO = [],
        dO = [],
        TO = [],
        NO = [],
        IO = [],
        yK = [],
        gK = [],
        uO = [],
        EO = [],
        jK = [],
        YO = [],
        wO = [],
        iK = [],
        rK = [],
        PO = [],
        mK = [],
        sO = [],
        HO = [],
        RO = [];
      return OO = class {
        constructor() {
          this.keysUp = (0, XO.i)(this, QO, [38]), this.keysUpward = ((0, XO.i)(this, zK), (0, XO.i)(this, AO, [33])), this.keysDown = ((0, XO.i)(this, fO), (0, XO.i)(this, dO, [40])), this.keysDownward = ((0, XO.i)(this, TO), (0, XO.i)(this, NO, [34])), this.keysLeft = ((0, XO.i)(this, IO), (0, XO.i)(this, yK, [37])), this.keysRight = ((0, XO.i)(this, gK), (0, XO.i)(this, uO, [39])), this.rotationSpeed = ((0, XO.i)(this, EO), (0, XO.i)(this, jK, .5)), this.keysRotateLeft = ((0, XO.i)(this, YO), (0, XO.i)(this, wO, [])), this.keysRotateRight = ((0, XO.i)(this, iK), (0, XO.i)(this, rK, [])), this.keysRotateUp = ((0, XO.i)(this, PO), (0, XO.i)(this, mK, [])), this.keysRotateDown = ((0, XO.i)(this, sO), (0, XO.i)(this, HO, [])), this._keys = ((0, XO.i)(this, RO), new Array)
        }
        attachControl(OO) {
          OO = hO.k.BackCompatCameraNoPreventDefault(arguments), this._onCanvasBlurObserver || (this._scene = this.camera.JKO(), this._engine = this._scene.qb(), this._onCanvasBlurObserver = this._engine.onCanvasBlurObservable.add((() => {
            this._keys.length = 0
          })), this._onKeyboardObserver = this._scene.onKeyboardObservable.add((KO => {
            const pO = KO.event;
            if (!pO.metaKey)
              if (KO.type === CO.d.KEYDOWN) {
                if (-1 !== this.keysUp.indexOf(pO.keyCode) || -1 !== this.keysDown.indexOf(pO.keyCode) || -1 !== this.keysLeft.indexOf(pO.keyCode) || -1 !== this.keysRight.indexOf(pO.keyCode) || -1 !== this.keysUpward.indexOf(pO.keyCode) || -1 !== this.keysDownward.indexOf(pO.keyCode) || -1 !== this.keysRotateLeft.indexOf(pO.keyCode) || -1 !== this.keysRotateRight.indexOf(pO.keyCode) || -1 !== this.keysRotateUp.indexOf(pO.keyCode) || -1 !== this.keysRotateDown.indexOf(pO.keyCode)) {
                  -1 === this._keys.indexOf(pO.keyCode) && this._keys.push(pO.keyCode), OO || pO.preventDefault()
                }
              } else if (-1 !== this.keysUp.indexOf(pO.keyCode) || -1 !== this.keysDown.indexOf(pO.keyCode) || -1 !== this.keysLeft.indexOf(pO.keyCode) || -1 !== this.keysRight.indexOf(pO.keyCode) || -1 !== this.keysUpward.indexOf(pO.keyCode) || -1 !== this.keysDownward.indexOf(pO.keyCode) || -1 !== this.keysRotateLeft.indexOf(pO.keyCode) || -1 !== this.keysRotateRight.indexOf(pO.keyCode) || -1 !== this.keysRotateUp.indexOf(pO.keyCode) || -1 !== this.keysRotateDown.indexOf(pO.keyCode)) {
              const KO = this._keys.indexOf(pO.keyCode);
              KO >= 0 && this._keys.splice(KO, 1), OO || pO.preventDefault()
            }
          })))
        }
        detachControl() {
          this._scene && (this._onKeyboardObserver && this._scene.onKeyboardObservable.remove(this._onKeyboardObserver), this._onCanvasBlurObserver && this._engine.onCanvasBlurObservable.remove(this._onCanvasBlurObserver), this._onKeyboardObserver = null, this._onCanvasBlurObserver = null), this._keys.length = 0
        }
        checkInputs() {
          if (this._onKeyboardObserver) {
            const OO = this.camera,
              KO = OO.movement.input,
              pO = KO.getEntry("keyboard", "translate"),
              XO = KO.getEntry("keyboard", "rotate"),
              bK = XO?.sensitivity ?? 1,
              lO = OO._localDirection.rvO(0, 0, 0);
            for (let eO = 0; eO < this._keys.length; eO++) {
              const KO = this._keys[eO]; - 1 !== this.keysLeft.indexOf(KO) ? lO.x -= 1 : -1 !== this.keysUp.indexOf(KO) ? lO.z += 1 : -1 !== this.keysRight.indexOf(KO) ? lO.x += 1 : -1 !== this.keysDown.indexOf(KO) ? lO.z -= 1 : -1 !== this.keysUpward.indexOf(KO) ? lO.y += 1 : -1 !== this.keysDownward.indexOf(KO) ? lO.y -= 1 : -1 !== this.keysRotateLeft.indexOf(KO) ? XO && (OO.cameraRotation.y -= this._getLocalRotation() * bK) : -1 !== this.keysRotateRight.indexOf(KO) ? XO && (OO.cameraRotation.y += this._getLocalRotation() * bK) : -1 !== this.keysRotateUp.indexOf(KO) ? XO && (OO.cameraRotation.x -= this._getLocalRotation() * bK) : -1 !== this.keysRotateDown.indexOf(KO) && XO && (OO.cameraRotation.x += this._getLocalRotation() * bK)
            }
            if (pO && (0 !== lO.x || 0 !== lO.y || 0 !== lO.z)) {
              const KO = OO._computeLocalCameraSpeed() * (pO.sensitivity ?? 1);
              lO.normalize().scaleInPlace(KO), OO.JKO().useRightHandedSystem && (lO.z *= -1), OO.getViewMatrix().invertToRef(OO._cameraTransformMatrix), eO.o.TransformNormalToRef(lO, OO._cameraTransformMatrix, OO._transformedDirection), OO.cameraDirection.addInPlace(OO._transformedDirection)
            }
          }
        }
        getClassName() {
          return "FreeCameraKeyboardMoveInput"
        }
        _onLostFocus() {
          this._keys.length = 0
        }
        getSimpleName() {
          return "keyboard"
        }
        _getLocalRotation() {
          const OO = this.camera._calculateHandednessMultiplier();
          return this.rotationSpeed * this._engine.getDeltaTime() / 1e3 * OO
        }
      }, (() => {
        const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], lO = [(0, bK.M)()], vK = [(0, bK.M)()], DO = [(0, bK.M)()], MO = [(0, bK.M)()], aK = [(0, bK.M)()], oO = [(0, bK.M)()], FO = [(0, bK.M)()], VO = [(0, bK.M)()], LO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "keysUp",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysUp" in OO,
            get: OO => OO.keysUp,
            set: (OO, KO) => {
              OO.keysUp = KO
            }
          },
          metadata: eO
        }, QO, zK), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "keysUpward",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysUpward" in OO,
            get: OO => OO.keysUpward,
            set: (OO, KO) => {
              OO.keysUpward = KO
            }
          },
          metadata: eO
        }, AO, fO), (0, XO.f)(null, null, lO, {
          kind: "field",
          name: "keysDown",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysDown" in OO,
            get: OO => OO.keysDown,
            set: (OO, KO) => {
              OO.keysDown = KO
            }
          },
          metadata: eO
        }, dO, TO), (0, XO.f)(null, null, vK, {
          kind: "field",
          name: "keysDownward",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysDownward" in OO,
            get: OO => OO.keysDownward,
            set: (OO, KO) => {
              OO.keysDownward = KO
            }
          },
          metadata: eO
        }, NO, IO), (0, XO.f)(null, null, DO, {
          kind: "field",
          name: "keysLeft",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysLeft" in OO,
            get: OO => OO.keysLeft,
            set: (OO, KO) => {
              OO.keysLeft = KO
            }
          },
          metadata: eO
        }, yK, gK), (0, XO.f)(null, null, MO, {
          kind: "field",
          name: "keysRight",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysRight" in OO,
            get: OO => OO.keysRight,
            set: (OO, KO) => {
              OO.keysRight = KO
            }
          },
          metadata: eO
        }, uO, EO), (0, XO.f)(null, null, aK, {
          kind: "field",
          name: "rotationSpeed",
          static: !1,
          private: !1,
          access: {
            has: OO => "rotationSpeed" in OO,
            get: OO => OO.rotationSpeed,
            set: (OO, KO) => {
              OO.rotationSpeed = KO
            }
          },
          metadata: eO
        }, jK, YO), (0, XO.f)(null, null, oO, {
          kind: "field",
          name: "keysRotateLeft",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysRotateLeft" in OO,
            get: OO => OO.keysRotateLeft,
            set: (OO, KO) => {
              OO.keysRotateLeft = KO
            }
          },
          metadata: eO
        }, wO, iK), (0, XO.f)(null, null, FO, {
          kind: "field",
          name: "keysRotateRight",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysRotateRight" in OO,
            get: OO => OO.keysRotateRight,
            set: (OO, KO) => {
              OO.keysRotateRight = KO
            }
          },
          metadata: eO
        }, rK, PO), (0, XO.f)(null, null, VO, {
          kind: "field",
          name: "keysRotateUp",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysRotateUp" in OO,
            get: OO => OO.keysRotateUp,
            set: (OO, KO) => {
              OO.keysRotateUp = KO
            }
          },
          metadata: eO
        }, mK, sO), (0, XO.f)(null, null, LO, {
          kind: "field",
          name: "keysRotateDown",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysRotateDown" in OO,
            get: OO => OO.keysRotateDown,
            set: (OO, KO) => {
              OO.keysRotateDown = KO
            }
          },
          metadata: eO
        }, HO, RO), eO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: eO
        })
      })(), OO
    })();
    vK.b.FreeCameraKeyboardMoveInput = DO;
    var MO = pO(35660),
      aK = pO(38254);
    let oO = (() => {
      var OO;
      let KO, pO, eO = [],
        lO = [],
        vK = [],
        CO = [];
      return OO = class {
        _applyPointerRotation(OO, KO) {
          this._pointerConditions.button = this._currentActiveButton;
          const pO = this.camera.movement.input.resolveInteraction("pointer", this._pointerConditions);
          if (!pO || "rotate" !== pO.interaction) return;
          const XO = pO.tbO ?? pO.sensitivity ?? 1 / this.angularSensibility,
            bK = pO.kbO ?? pO.sensitivity ?? 1 / this.angularSensibility;
          this.camera.cameraRotation.y += OO * XO, this.camera.cameraRotation.x += KO * bK
        }
        constructor() {
          let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
          this.touchEnabled = OO, this.buttons = (0, XO.i)(this, eO, [0, 1, 2]), this.angularSensibility = ((0, XO.i)(this, lO), (0, XO.i)(this, vK, 2e3)), this._pointerInput = (0, XO.i)(this, CO), this._previousPosition = null, this.onPointerMovedObservable = new MO.e, this._allowCameraRotation = !0, this._currentActiveButton = -1, this._activePointerId = -1, this._pointerConditions = {}
        }
        attachControl(OO) {
          OO = hO.k.BackCompatCameraNoPreventDefault(arguments);
          const KO = this.camera.qb(),
            pO = KO.getInputElement();
          this._pointerInput || (this._pointerInput = XO => {
            const bK = XO.event,
              eO = "touch" === bK.pointerType;
            if (!this.touchEnabled && eO) return;
            if (XO.type !== aK.c.POINTERMOVE && -1 === this.buttons.indexOf(bK.button)) return;
            const lO = bK.target;
            if (XO.type === aK.c.POINTERDOWN) {
              if (eO && -1 !== this._activePointerId || !eO && -1 !== this._currentActiveButton) return;
              this._activePointerId = bK.pointerId;
              try {
                lO?.setPointerCapture(bK.pointerId)
              } catch (vK) {} - 1 === this._currentActiveButton && (this._currentActiveButton = bK.button), this._previousPosition = {
                x: bK.clientX,
                y: bK.clientY
              }, OO || (bK.preventDefault(), pO && pO.focus()), KO.isPointerLock && this._onMouseMove && this._onMouseMove(XO.event)
            } else if (XO.type === aK.c.POINTERUP) {
              if (eO && this._activePointerId !== bK.pointerId || !eO && this._currentActiveButton !== bK.button) return;
              try {
                lO?.releasePointerCapture(bK.pointerId)
              } catch (vK) {}
              this._currentActiveButton = -1, this._previousPosition = null, OO || bK.preventDefault(), this._activePointerId = -1
            } else if (XO.type === aK.c.POINTERMOVE && (this._activePointerId === bK.pointerId || !eO))
              if (KO.isPointerLock && this._onMouseMove) this._onMouseMove(XO.event);
              else if (this._previousPosition) {
              const KO = this.camera._calculateHandednessMultiplier(),
                pO = (bK.clientX - this._previousPosition.x) * KO,
                XO = (bK.clientY - this._previousPosition.y) * KO;
              this._allowCameraRotation && this._applyPointerRotation(pO, XO), this.onPointerMovedObservable.notifyObservers({
                offsetX: pO,
                offsetY: XO
              }), this._previousPosition = {
                x: bK.clientX,
                y: bK.clientY
              }, OO || bK.preventDefault()
            }
          }), this._onMouseMove = pO => {
            if (!KO.isPointerLock) return;
            const XO = this.camera._calculateHandednessMultiplier();
            this._applyPointerRotation(pO.movementX * XO, pO.movementY * XO), this._previousPosition = null, OO || pO.preventDefault()
          }, this._observer = this.camera.JKO()._inputManager._addCameraPointerObserver(this._pointerInput, aK.c.POINTERDOWN | aK.c.POINTERUP | aK.c.POINTERMOVE), pO && (this._contextMenuBind = OO => this.onContextMenu(OO), pO.addEventListener("contextmenu", this._contextMenuBind, !1))
        }
        onContextMenu(OO) {
          OO.preventDefault()
        }
        detachControl() {
          if (this._observer) {
            if (this.camera.JKO()._inputManager._removeCameraPointerObserver(this._observer), this._contextMenuBind) {
              const OO = this.camera.qb().getInputElement();
              OO && OO.removeEventListener("contextmenu", this._contextMenuBind)
            }
            this.onPointerMovedObservable && this.onPointerMovedObservable.clear(), this._observer = null, this._onMouseMove = null, this._previousPosition = null
          }
          this._activePointerId = -1, this._currentActiveButton = -1
        }
        getClassName() {
          return "FreeCameraMouseInput"
        }
        getSimpleName() {
          return "mouse"
        }
      }, (() => {
        const hO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "buttons",
          static: !1,
          private: !1,
          access: {
            has: OO => "buttons" in OO,
            get: OO => OO.buttons,
            set: (OO, KO) => {
              OO.buttons = KO
            }
          },
          metadata: hO
        }, eO, lO), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "angularSensibility",
          static: !1,
          private: !1,
          access: {
            has: OO => "angularSensibility" in OO,
            get: OO => OO.angularSensibility,
            set: (OO, KO) => {
              OO.angularSensibility = KO
            }
          },
          metadata: hO
        }, vK, CO), hO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: hO
        })
      })(), OO
    })();
    vK.b.FreeCameraMouseInput = oO;
    var FO = pO(38266);
    let VO = (() => {
      var OO;
      let KO, pO, eO, lO = [],
        vK = [],
        CO = [],
        DO = [],
        oO = [],
        VO = [];
      return OO = class {
        constructor() {
          this.wheelPrecisionX = (0, XO.i)(this, lO, 3), this.wheelPrecisionY = ((0, XO.i)(this, vK), (0, XO.i)(this, CO, 3)), this.wheelPrecisionZ = ((0, XO.i)(this, DO), (0, XO.i)(this, oO, 3)), this.onChangedObservable = ((0, XO.i)(this, VO), new MO.e), this._wheelDeltaX = 0, this._wheelDeltaY = 0, this._wheelDeltaZ = 0, this._ffMultiplier = 12, this._normalize = 120
        }
        attachControl(OO) {
          OO = hO.k.BackCompatCameraNoPreventDefault(arguments), this._wheel = KO => {
            if (KO.type !== aK.c.POINTERWHEEL) return;
            const pO = KO.event,
              XO = pO.deltaMode === FO.e.DOM_DELTA_LINE ? this._ffMultiplier : 1;
            this._wheelDeltaX += this.wheelPrecisionX * XO * pO.deltaX / this._normalize, this._wheelDeltaY -= this.wheelPrecisionY * XO * pO.deltaY / this._normalize, this._wheelDeltaZ += this.wheelPrecisionZ * XO * pO.deltaZ / this._normalize, pO.preventDefault && (OO || pO.preventDefault())
          }, this._observer = this.camera.JKO()._inputManager._addCameraPointerObserver(this._wheel, aK.c.POINTERWHEEL)
        }
        detachControl() {
          this._observer && (this.camera.JKO()._inputManager._removeCameraPointerObserver(this._observer), this._observer = null, this._wheel = null), this.onChangedObservable && this.onChangedObservable.clear()
        }
        checkInputs() {
          this.onChangedObservable.notifyObservers({
            wheelDeltaX: this._wheelDeltaX,
            wheelDeltaY: this._wheelDeltaY,
            wheelDeltaZ: this._wheelDeltaZ
          }), this._wheelDeltaX = 0, this._wheelDeltaY = 0, this._wheelDeltaZ = 0
        }
        getClassName() {
          return "BaseCameraMouseWheelInput"
        }
        getSimpleName() {
          return "mousewheel"
        }
      }, (() => {
        const hO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], eO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "wheelPrecisionX",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelPrecisionX" in OO,
            get: OO => OO.wheelPrecisionX,
            set: (OO, KO) => {
              OO.wheelPrecisionX = KO
            }
          },
          metadata: hO
        }, lO, vK), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "wheelPrecisionY",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelPrecisionY" in OO,
            get: OO => OO.wheelPrecisionY,
            set: (OO, KO) => {
              OO.wheelPrecisionY = KO
            }
          },
          metadata: hO
        }, CO, DO), (0, XO.f)(null, null, eO, {
          kind: "field",
          name: "wheelPrecisionZ",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelPrecisionZ" in OO,
            get: OO => OO.wheelPrecisionZ,
            set: (OO, KO) => {
              OO.wheelPrecisionZ = KO
            }
          },
          metadata: hO
        }, oO, VO), hO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: hO
        })
      })(), OO
    })();
    var LO;
    ! function(OO) {
      OO[OO.MoveRelative = 0] = "MoveRelative", OO[OO.RotateRelative = 1] = "RotateRelative", OO[OO.MoveScene = 2] = "MoveScene"
    }(LO || (LO = {}));
    let QO = (() => {
      var OO;
      let KO, pO, lO, vK, CO, hO, DO, MO, aK, oO = VO,
        FO = [];
      return OO = class extends oO {
        constructor() {
          super(...arguments), this.camera = (0, XO.i)(this, FO), this._moveRelative = eO.o.Zero(), this._rotateRelative = eO.o.Zero(), this._moveScene = eO.o.Zero(), this._wheelXAction = LO.MoveRelative, this._wheelXActionCoordinate = 0, this._wheelYAction = LO.MoveRelative, this._wheelYActionCoordinate = 2, this._wheelZAction = null, this._wheelZActionCoordinate = null
        }
        getClassName() {
          return "FreeCameraMouseWheelInput"
        }
        set wheelXMoveRelative(OO) {
          null === OO && this._wheelXAction !== LO.MoveRelative || (this._wheelXAction = LO.MoveRelative, this._wheelXActionCoordinate = OO)
        }
        get wheelXMoveRelative() {
          return this._wheelXAction !== LO.MoveRelative ? null : this._wheelXActionCoordinate
        }
        set wheelYMoveRelative(OO) {
          null === OO && this._wheelYAction !== LO.MoveRelative || (this._wheelYAction = LO.MoveRelative, this._wheelYActionCoordinate = OO)
        }
        get wheelYMoveRelative() {
          return this._wheelYAction !== LO.MoveRelative ? null : this._wheelYActionCoordinate
        }
        set wheelZMoveRelative(OO) {
          null === OO && this._wheelZAction !== LO.MoveRelative || (this._wheelZAction = LO.MoveRelative, this._wheelZActionCoordinate = OO)
        }
        get wheelZMoveRelative() {
          return this._wheelZAction !== LO.MoveRelative ? null : this._wheelZActionCoordinate
        }
        set wheelXRotateRelative(OO) {
          null === OO && this._wheelXAction !== LO.RotateRelative || (this._wheelXAction = LO.RotateRelative, this._wheelXActionCoordinate = OO)
        }
        get wheelXRotateRelative() {
          return this._wheelXAction !== LO.RotateRelative ? null : this._wheelXActionCoordinate
        }
        set wheelYRotateRelative(OO) {
          null === OO && this._wheelYAction !== LO.RotateRelative || (this._wheelYAction = LO.RotateRelative, this._wheelYActionCoordinate = OO)
        }
        get wheelYRotateRelative() {
          return this._wheelYAction !== LO.RotateRelative ? null : this._wheelYActionCoordinate
        }
        set wheelZRotateRelative(OO) {
          null === OO && this._wheelZAction !== LO.RotateRelative || (this._wheelZAction = LO.RotateRelative, this._wheelZActionCoordinate = OO)
        }
        get wheelZRotateRelative() {
          return this._wheelZAction !== LO.RotateRelative ? null : this._wheelZActionCoordinate
        }
        set wheelXMoveScene(OO) {
          null === OO && this._wheelXAction !== LO.MoveScene || (this._wheelXAction = LO.MoveScene, this._wheelXActionCoordinate = OO)
        }
        get wheelXMoveScene() {
          return this._wheelXAction !== LO.MoveScene ? null : this._wheelXActionCoordinate
        }
        set wheelYMoveScene(OO) {
          null === OO && this._wheelYAction !== LO.MoveScene || (this._wheelYAction = LO.MoveScene, this._wheelYActionCoordinate = OO)
        }
        get wheelYMoveScene() {
          return this._wheelYAction !== LO.MoveScene ? null : this._wheelYActionCoordinate
        }
        set wheelZMoveScene(OO) {
          null === OO && this._wheelZAction !== LO.MoveScene || (this._wheelZAction = LO.MoveScene, this._wheelZActionCoordinate = OO)
        }
        get wheelZMoveScene() {
          return this._wheelZAction !== LO.MoveScene ? null : this._wheelZActionCoordinate
        }
        checkInputs() {
          if (0 === this._wheelDeltaX && 0 === this._wheelDeltaY && 0 == this._wheelDeltaZ) return;
          this._moveRelative.plO(0), this._rotateRelative.plO(0), this._moveScene.plO(0), this._updateCamera(), this.camera.JKO().useRightHandedSystem && (this._moveRelative.z *= -1);
          const OO = eO.c.Zero();
          this.camera.getViewMatrix().invertToRef(OO);
          const KO = eO.o.Zero();
          eO.o.TransformNormalToRef(this._moveRelative, OO, KO), this.camera.cameraRotation.x += this._rotateRelative.x / 200, this.camera.cameraRotation.y += this._rotateRelative.y / 200, this.camera.cameraDirection.addInPlace(KO), this.camera.cameraDirection.addInPlace(this._moveScene), super.checkInputs()
        }
        _updateCamera() {
          this._updateCameraProperty(this._wheelDeltaX, this._wheelXAction, this._wheelXActionCoordinate), this._updateCameraProperty(this._wheelDeltaY, this._wheelYAction, this._wheelYActionCoordinate), this._updateCameraProperty(this._wheelDeltaZ, this._wheelZAction, this._wheelZActionCoordinate)
        }
        _updateCameraProperty(OO, KO, pO) {
          if (0 === OO) return;
          if (null === KO || null === pO) return;
          let XO = null;
          switch (KO) {
            case LO.MoveRelative:
              XO = this._moveRelative;
              break;
            case LO.RotateRelative:
              XO = this._rotateRelative;
              break;
            case LO.MoveScene:
              XO = this._moveScene
          }
          switch (pO) {
            case 0:
              XO.set(OO, 0, 0);
              break;
            case 1:
              XO.set(0, OO, 0);
              break;
            case 2:
              XO.set(0, 0, OO)
          }
        }
      }, (() => {
        const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(oO[Symbol.metadata] ?? null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], lO = [(0, bK.M)()], vK = [(0, bK.M)()], CO = [(0, bK.M)()], hO = [(0, bK.M)()], DO = [(0, bK.M)()], MO = [(0, bK.M)()], aK = [(0, bK.M)()], (0, XO.f)(OO, null, KO, {
          kind: "setter",
          name: "wheelXMoveRelative",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelXMoveRelative" in OO,
            set: (OO, KO) => {
              OO.wheelXMoveRelative = KO
            }
          },
          metadata: eO
        }, null, FO), (0, XO.f)(OO, null, pO, {
          kind: "setter",
          name: "wheelYMoveRelative",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelYMoveRelative" in OO,
            set: (OO, KO) => {
              OO.wheelYMoveRelative = KO
            }
          },
          metadata: eO
        }, null, FO), (0, XO.f)(OO, null, lO, {
          kind: "setter",
          name: "wheelZMoveRelative",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelZMoveRelative" in OO,
            set: (OO, KO) => {
              OO.wheelZMoveRelative = KO
            }
          },
          metadata: eO
        }, null, FO), (0, XO.f)(OO, null, vK, {
          kind: "setter",
          name: "wheelXRotateRelative",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelXRotateRelative" in OO,
            set: (OO, KO) => {
              OO.wheelXRotateRelative = KO
            }
          },
          metadata: eO
        }, null, FO), (0, XO.f)(OO, null, CO, {
          kind: "setter",
          name: "wheelYRotateRelative",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelYRotateRelative" in OO,
            set: (OO, KO) => {
              OO.wheelYRotateRelative = KO
            }
          },
          metadata: eO
        }, null, FO), (0, XO.f)(OO, null, hO, {
          kind: "setter",
          name: "wheelZRotateRelative",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelZRotateRelative" in OO,
            set: (OO, KO) => {
              OO.wheelZRotateRelative = KO
            }
          },
          metadata: eO
        }, null, FO), (0, XO.f)(OO, null, DO, {
          kind: "setter",
          name: "wheelXMoveScene",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelXMoveScene" in OO,
            set: (OO, KO) => {
              OO.wheelXMoveScene = KO
            }
          },
          metadata: eO
        }, null, FO), (0, XO.f)(OO, null, MO, {
          kind: "setter",
          name: "wheelYMoveScene",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelYMoveScene" in OO,
            set: (OO, KO) => {
              OO.wheelYMoveScene = KO
            }
          },
          metadata: eO
        }, null, FO), (0, XO.f)(OO, null, aK, {
          kind: "setter",
          name: "wheelZMoveScene",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelZMoveScene" in OO,
            set: (OO, KO) => {
              OO.wheelZMoveScene = KO
            }
          },
          metadata: eO
        }, null, FO), eO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: eO
        })
      })(), OO
    })();
    vK.b.FreeCameraMouseWheelInput = QO;
    let zK = (() => {
      var OO;
      let KO, pO, lO = [],
        vK = [],
        CO = [],
        DO = [];
      return OO = class {
        constructor() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          this.allowMouse = OO, this.touchAngularSensibility = (0, XO.i)(this, lO, 2e5), this.touchMoveSensibility = ((0, XO.i)(this, vK), (0, XO.i)(this, CO, 250)), this.singleFingerRotate = ((0, XO.i)(this, DO), !1), this._offsetX = null, this._offsetY = null, this._pointerPressed = new Array, this._isSafari = hO.k.IsSafari()
        }
        attachControl(OO) {
          OO = hO.k.BackCompatCameraNoPreventDefault(arguments);
          let KO = null;
          if (void 0 === this._pointerInput && (this._onLostFocus = () => {
              this._offsetX = null, this._offsetY = null
            }, this._pointerInput = pO => {
              const XO = pO.event,
                bK = "mouse" === XO.pointerType || this._isSafari && "undefined" === typeof XO.pointerType;
              if (this.allowMouse || !bK)
                if (pO.type === aK.c.POINTERDOWN) {
                  if (OO || XO.preventDefault(), this._pointerPressed.push(XO.pointerId), 1 !== this._pointerPressed.length) return;
                  KO = {
                    x: XO.clientX,
                    y: XO.clientY
                  }
                } else if (pO.type === aK.c.POINTERUP) {
                OO || XO.preventDefault();
                const pO = this._pointerPressed.indexOf(XO.pointerId);
                if (-1 === pO) return;
                if (this._pointerPressed.splice(pO, 1), 0 != pO) return;
                KO = null, this._offsetX = null, this._offsetY = null
              } else if (pO.type === aK.c.POINTERMOVE) {
                if (OO || XO.preventDefault(), !KO) return;
                if (0 != this._pointerPressed.indexOf(XO.pointerId)) return;
                this._offsetX = XO.clientX - KO.x, this._offsetY = -(XO.clientY - KO.y)
              }
            }), this._observer = this.camera.JKO()._inputManager._addCameraPointerObserver(this._pointerInput, aK.c.POINTERDOWN | aK.c.POINTERUP | aK.c.POINTERMOVE), this._onLostFocus) {
            const OO = this.camera.qb().getInputElement();
            OO && OO.addEventListener("blur", this._onLostFocus)
          }
        }
        detachControl() {
          if (this._pointerInput) {
            if (this._observer && (this.camera.JKO()._inputManager._removeCameraPointerObserver(this._observer), this._observer = null), this._onLostFocus) {
              const OO = this.camera.qb().getInputElement();
              OO && OO.removeEventListener("blur", this._onLostFocus), this._onLostFocus = null
            }
            this._pointerPressed.length = 0, this._offsetX = null, this._offsetY = null
          }
        }
        checkInputs() {
          if (null === this._offsetX || null === this._offsetY) return;
          if (0 === this._offsetX && 0 === this._offsetY) return;
          const OO = this.camera,
            KO = OO.movement.input,
            pO = KO.getEntry("touch", "rotate"),
            XO = KO.getEntry("touch", "translate"),
            bK = OO._calculateHandednessMultiplier(),
            lO = this.singleFingerRotate && 1 === this._pointerPressed.length || !this.singleFingerRotate && this._pointerPressed.length > 1;
          if (pO) {
            const KO = pO.sensitivity ?? 1 / this.touchAngularSensibility;
            OO.cameraRotation.y = this._offsetX * bK * KO, lO && (OO.cameraRotation.x = -this._offsetY * bK * KO)
          }
          if (!lO && XO) {
            const KO = OO._computeLocalCameraSpeed(),
              pO = XO.sensitivity ?? (0 !== this.touchMoveSensibility ? 1 / this.touchMoveSensibility : 0),
              bK = eO.j.WX[0];
            bK.rvO(0, 0, KO * this._offsetY * pO), eO.c.RotationYawPitchRollToRef(OO.rotation.y, OO.rotation.x, 0, OO._cameraRotationMatrix), eO.o.TransformCoordinatesToRef(bK, OO._cameraRotationMatrix, bK), OO.cameraDirection.addInPlace(bK)
          }
        }
        getClassName() {
          return "FreeCameraTouchInput"
        }
        getSimpleName() {
          return "touch"
        }
      }, (() => {
        const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "touchAngularSensibility",
          static: !1,
          private: !1,
          access: {
            has: OO => "touchAngularSensibility" in OO,
            get: OO => OO.touchAngularSensibility,
            set: (OO, KO) => {
              OO.touchAngularSensibility = KO
            }
          },
          metadata: eO
        }, lO, vK), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "touchMoveSensibility",
          static: !1,
          private: !1,
          access: {
            has: OO => "touchMoveSensibility" in OO,
            get: OO => OO.touchMoveSensibility,
            set: (OO, KO) => {
              OO.touchMoveSensibility = KO
            }
          },
          metadata: eO
        }, CO, DO), eO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: eO
        })
      })(), OO
    })();
    vK.b.FreeCameraTouchInput = zK;
    var AO, fO, dO, TO = pO(37938);
    class NO extends vK.c {
      constructor(OO) {
        super(OO), this._mouseInput = null, this._mouseWheelInput = null
      }
      addKeyboard() {
        return this.add(new DO), this
      }
      addMouse() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        return this._mouseInput || (this._mouseInput = new oO(OO), this.add(this._mouseInput)), this
      }
      removeMouse() {
        return this._mouseInput && this.remove(this._mouseInput), this
      }
      addMouseWheel() {
        return this._mouseWheelInput || (this._mouseWheelInput = new QO, this.add(this._mouseWheelInput)), this
      }
      removeMouseWheel() {
        return this._mouseWheelInput && this.remove(this._mouseWheelInput), this
      }
      addTouch() {
        return this.add(new zK), this
      }
      clear() {
        super.clear(), this._mouseInput = null
      }
    }(AO = NO.prototype).addDeviceOrientation ?? (AO.addDeviceOrientation = (0, TO.h)("FreeCameraInputsManager", "addDeviceOrientation")), (fO = NO.prototype).addVirtualJoystick ?? (fO.addVirtualJoystick = (0, TO.h)("FreeCameraInputsManager", "addVirtualJoystick")), (dO = NO.prototype).addGamepad ?? (dO.addGamepad = (0, TO.h)("FreeCameraInputsManager", "addGamepad"));
    var IO = pO(37962),
      yK = pO(35676);
    let gK = (() => {
        var OO;
        let KO, pO, vK, CO, DO = lO.f,
          MO = [],
          aK = [],
          oO = [],
          FO = [],
          VO = [],
          LO = [],
          QO = [],
          zK = [];
        return OO = class extends DO {
          get angularSensibility() {
            const OO = this.inputs.attached.mouse;
            return OO ? OO.angularSensibility : 0
          }
          set angularSensibility(OO) {
            const KO = this.inputs.attached.mouse;
            KO && (KO.angularSensibility = OO)
          }
          get keysUp() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysUp : []
          }
          set keysUp(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysUp = OO)
          }
          get keysUpward() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysUpward : []
          }
          set keysUpward(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysUpward = OO)
          }
          get keysDown() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysDown : []
          }
          set keysDown(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysDown = OO)
          }
          get keysDownward() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysDownward : []
          }
          set keysDownward(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysDownward = OO)
          }
          get keysLeft() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysLeft : []
          }
          set keysLeft(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysLeft = OO)
          }
          get keysRight() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysRight : []
          }
          set keysRight(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysRight = OO)
          }
          get keysRotateLeft() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysRotateLeft : []
          }
          set keysRotateLeft(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysRotateLeft = OO)
          }
          get keysRotateRight() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysRotateRight : []
          }
          set keysRotateRight(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysRotateRight = OO)
          }
          get keysRotateUp() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysRotateUp : []
          }
          set keysRotateUp(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysRotateUp = OO)
          }
          get keysRotateDown() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysRotateDown : []
          }
          set keysRotateDown(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysRotateDown = OO)
          }
          constructor(OO, KO, pO) {
            var bK;
            super(OO, KO, pO, !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3]), bK = this, this.ellipsoid = (0, XO.i)(this, MO, new eO.o(.5, 1, .5)), this.ellipsoidOffset = ((0, XO.i)(this, aK), (0, XO.i)(this, oO, new eO.o(0, 0, 0))), this.checkCollisions = ((0, XO.i)(this, FO), (0, XO.i)(this, VO, !1)), this.applyGravity = ((0, XO.i)(this, LO), (0, XO.i)(this, QO, !1)), this.inputs = (0, XO.i)(this, zK), this._needMoveForGravity = !1, this._oldPosition = eO.o.Zero(), this._diffPosition = eO.o.Zero(), this._newPosition = eO.o.Zero(), this._collisionMask = -1, this._onCollisionPositionChange = function(OO, KO) {
              let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
              bK._newPosition.NhO(KO), bK._newPosition.subtractToRef(bK._oldPosition, bK._diffPosition), bK._diffPosition.length() > IO.e.CollisionsEpsilon && (bK.position.addToRef(bK._diffPosition, bK._deferredPositionUpdate), bK._deferOnly ? bK._deferredUpdated = !0 : bK.position.NhO(bK._deferredPositionUpdate), bK.QK && pO && bK.QK(pO))
            }, this.inputs = new NO(this), this.inputs.addKeyboard().addMouse()
          }
          attachControl(OO, KO) {
            KO = hO.k.BackCompatCameraNoPreventDefault(arguments), this.inputs.attachElement(KO)
          }
          detachControl() {
            this.inputs.detachElement(), this.cameraDirection = new eO.o(0, 0, 0), this.cameraRotation = new eO.m(0, 0)
          }
          get collisionMask() {
            return this._collisionMask
          }
          set collisionMask(OO) {
            this._collisionMask = isNaN(OO) ? -1 : OO
          }
          _collideWithWorld(OO) {
            let KO;
            KO = this.parent ? eO.o.TransformCoordinates(this.position, this.parent.getWorldMatrix()) : this.position, KO.subtractFromFloatsToRef(0, this.ellipsoid.y, 0, this._oldPosition), this._oldPosition.addInPlace(this.ellipsoidOffset);
            const pO = this.JKO().collisionCoordinator;
            this._collider || (this._collider = pO.createCollider()), this._collider._radius = this.ellipsoid, this._collider.collisionMask = this._collisionMask;
            let XO = OO;
            this.applyGravity && (XO = OO.add(this.JKO().gravity)), pO.getNewPosition(this._oldPosition, XO, this._collider, 3, null, this._onCollisionPositionChange, this.uniqueId)
          }
          _checkInputs() {
            this._localDirection || (this._localDirection = eO.o.Zero(), this._transformedDirection = eO.o.Zero()), this.inputs.checkInputs(), super._checkInputs()
          }
          set needMoveForGravity(OO) {
            this._needMoveForGravity = OO
          }
          get needMoveForGravity() {
            return this._needMoveForGravity
          }
          _decideIfNeedsToMove() {
            return this._needMoveForGravity || Math.abs(this.cameraDirection.x) > 0 || Math.abs(this.cameraDirection.y) > 0 || Math.abs(this.cameraDirection.z) > 0
          }
          _updatePosition() {
            this.checkCollisions && this.JKO().collisionsEnabled ? this._collideWithWorld(this.cameraDirection) : super._updatePosition()
          }
          dispose() {
            this.inputs.clear(), super.dispose()
          }
          getClassName() {
            return "FreeCamera"
          }
        }, (() => {
          const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(DO[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.L)()], pO = [(0, bK.L)()], vK = [(0, bK.M)()], CO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "ellipsoid",
            static: !1,
            private: !1,
            access: {
              has: OO => "ellipsoid" in OO,
              get: OO => OO.ellipsoid,
              set: (OO, KO) => {
                OO.ellipsoid = KO
              }
            },
            metadata: eO
          }, MO, aK), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "ellipsoidOffset",
            static: !1,
            private: !1,
            access: {
              has: OO => "ellipsoidOffset" in OO,
              get: OO => OO.ellipsoidOffset,
              set: (OO, KO) => {
                OO.ellipsoidOffset = KO
              }
            },
            metadata: eO
          }, oO, FO), (0, XO.f)(null, null, vK, {
            kind: "field",
            name: "checkCollisions",
            static: !1,
            private: !1,
            access: {
              has: OO => "checkCollisions" in OO,
              get: OO => OO.checkCollisions,
              set: (OO, KO) => {
                OO.checkCollisions = KO
              }
            },
            metadata: eO
          }, VO, LO), (0, XO.f)(null, null, CO, {
            kind: "field",
            name: "applyGravity",
            static: !1,
            private: !1,
            access: {
              has: OO => "applyGravity" in OO,
              get: OO => OO.applyGravity,
              set: (OO, KO) => {
                OO.applyGravity = KO
              }
            },
            metadata: eO
          }, QO, zK), eO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: eO
          })
        })(), OO
      })(),
      uO = !1;
    uO || (uO = !0, (0, yK.h)("BABYLON.FreeCamera", gK))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);