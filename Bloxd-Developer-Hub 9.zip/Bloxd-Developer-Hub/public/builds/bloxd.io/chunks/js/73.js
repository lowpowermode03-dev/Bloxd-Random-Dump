export const id = 73;
export const ids = [73];
export const modules = {
  35083: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => HO,
      d: () => mK
    });
    var XO = pO(63),
      bK = pO(1556),
      eO = pO(35088),
      lO = pO.n(eO),
      vK = pO(3730),
      CO = pO(1533),
      hO = pO(1263),
      DO = pO(94),
      MO = pO(107),
      aK = pO(256),
      oO = pO(918),
      FO = pO.n(oO),
      VO = pO(22),
      LO = pO(933),
      QO = pO(1441),
      zK = pO(1481),
      AO = pO(1479),
      fO = pO(1610),
      dO = pO(1232),
      TO = pO(1659),
      NO = pO(1225),
      IO = pO(7857),
      yK = pO(35092),
      gK = pO(35105),
      uO = pO(1298),
      EO = pO(1994),
      jK = pO(1051),
      YO = pO(35111);
    var wO = pO(976);
    const iK = pO(35116),
      rK = ["enter", "t", "/"];
    let PO = !1;

    function mK() {
      return PO || (0, zK.isTextEntry)(document.activeElement)
    }

    function sO() {
      var OO, KO;
      (0, TO.e)();
      const pO = null !== (OO = null === (KO = (0, dO.g)()) || void 0 === KO ? void 0 : KO.getBoundButton("keyboardChannel")) && void 0 !== OO ? OO : null;
      return pO ? (0, wO.jsx)(fO.b, {
        className: "ChatInputChannelGlyph",
        glyph: pO
      }) : null
    }

    function HO() {
      const {
        t: OO
      } = (0, jK.D)(), {
        isTouchScreen: KO
      } = (0, VO.l)(["isTouchScreen"]), pO = (0, NO.p)(), [eO, oO] = (0, XO.useState)(!1), fO = (0, XO.useRef)(eO), dO = (0, XO.useRef)(null), {
        messages: TO,
        reportedPlayers: mK,
        channel: HO
      } = (0, IO.t)(), SO = (0, XO.useRef)(0), JO = (0, XO.useRef)(""), cK = (0, XO.useRef)(null);
      var BO;
      BO = cK, (0, XO.useEffect)((() => {
        if (!(0, DO.isIOS)()) return;
        const OO = BO.current;
        let KO = null;
        const pO = pO => {
            const XO = pO.changedTouches[0];
            KO = "none" === getComputedStyle(OO).pointerEvents ? {
              id: XO.identifier,
              y: XO.clientY
            } : null
          },
          XO = pO => {
            const XO = KO,
              bK = XO && (0, YO.b)(pO.changedTouches, XO.id);
            bK && (pO.preventDefault(), OO.scrollBy({
              top: XO.y - bK.clientY,
              behavior: "instant"
            }), XO.y = bK.clientY)
          };
        return OO.addEventListener("touchstart", pO, {
          passive: !0
        }), OO.addEventListener("touchmove", XO, {
          passive: !1
        }), () => {
          OO.removeEventListener("touchstart", pO), OO.removeEventListener("touchmove", XO)
        }
      }), [BO]);
      const [ZO, GO] = (0, XO.useState)(!1), [qK, xK] = (0, XO.useState)(!1), nO = (0, XO.useRef)(ZO), WO = (0, XO.useRef)(null), tK = (0, XO.useRef)(!1), kK = (0, XO.useRef)(null), UO = (0, XO.useRef)(null), OK = (0, XO.useRef)(null), KK = (0, XO.useRef)(eK);
      KK.current = eK;
      const pK = (0, EO.k)();

      function XK() {
        fO.current = !1, oO(!1), UO.current.blur()
      }

      function bp(OO) {
        nO.current = OO, GO(OO)
      }

      function eK() {
        const OO = UO.current.value;
        UO.current.value = "", lK(OO)
      }

      function lK(OO) {
        (0, IO.p)(OO), SO.current = 0, bp(!1)
      }

      function vp(OO, KO) {
        0 === SO.current && (JO.current = UO.current.value);
        const pO = (0, IO.l)(SO.current + OO, KO);
        SO.current = pO.stepsBack, UO.current.value = 0 === pO.stepsBack ? JO.current : pO.text, setTimeout((() => {
          UO.current && UO.current.setSelectionRange(-1, -1)
        }), 0)
      }

      function CK() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        cK.current && (!OO && nO.current || (cK.current.scrollTop = 1e5))
      }
      return (0, vK.b)(!0, eO, "ChatComponent"), (0, XO.useEffect)((() => (PO = eO, () => {
        PO = !1
      })), [eO]), (0, hO.f)("appManagerUpdated|openEverythingMenuName", (() => {
        (0, QO.l)() && oO(!1)
      })), (0, XO.useEffect)((() => {
        UO.current.addEventListener("blur", (OO => {
          if (null === UO.current) return;
          Array.from(document.querySelectorAll(":hover")).some((OO => OO.classList.contains("ChatInputChannel") || OO.classList.contains("ChatMsgSelectWrapper"))) || ((0, DO.isMobile)() && fO.current && "" !== UO.current.value && KK.current(), oO(!1))
        }));
        const OO = OO => {
          dO.current.contains(OO.target) || (0, AO.k)(OO.target) || oO(!1)
        };
        document.addEventListener("touchstart", OO, {
          capture: !0
        });
        const KO = OO => {
          (0, gK.d)(OO.target) && (fO.current = !1, oO(!1))
        };
        document.addEventListener("mousedown", KO, {
          capture: !0
        });
        const pO = () => {
            clearTimeout(WO.current), bp(!0)
          },
          XO = () => {
            clearTimeout(WO.current), WO.current = setTimeout((() => {
              bp(!1), CK()
            }), 4e3)
          },
          eO = () => {
            document.pointerLockElement ? (oO(!1), xK(!0), tK.current = !1, bp(!1), CK()) : xK(!1)
          };
        cK.current.addEventListener("pointermove", (OO => {
          "touch" === OO.pointerType || tK.current || document.pointerLockElement || (tK.current = !0, pO())
        })), cK.current.addEventListener("pointerleave", (OO => {
          "touch" !== OO.pointerType && (tK.current = !1, XO())
        })), cK.current.addEventListener("wheel", (() => {
          document.pointerLockElement || (pO(), tK.current || (WO.current = setTimeout((() => {
            bp(!1)
          }), 4e3)))
        }), {
          passive: !0
        }), cK.current.addEventListener("touchstart", pO), cK.current.addEventListener("touchend", XO), cK.current.addEventListener("touchcancel", XO), document.addEventListener("pointerlockchange", eO);
        const vK = OO => {
          if (pK.shown && (fO.current || ! function(OO) {
              if ((0, zK.isTypingInInput)()) return !0;
              const KO = document.activeElement;
              return (KO instanceof HTMLButtonElement || "button" === (null === KO || void 0 === KO ? void 0 : KO.getAttribute("role"))) && ["Enter", " "].includes(OO.key)
            }(OO)) && "codeEditor" !== VO.d.get("openInGameMenuName") && "lobbyCodeEditor" !== VO.d.get("openInGameMenuName") && !bK.gameBridge.latest("connectedGame").replay)
            if (fO.current || !(0, QO.l)()) {
              if (fO.current) {
                if ("ArrowUp" === OO.code || "ArrowDown" === OO.code) return vp("ArrowUp" === OO.code ? 1 : -1, !1), void OO.stopPropagation();
                if ("Tab" === OO.code) return IO.e.selectNextChannel(), OO.stopPropagation(), void OO.preventDefault();
                if (OO.ctrlKey && RO.includes(iK[OO.keyCode])) return OO.preventDefault(), void OO.stopPropagation()
              }
              if ([...rK, "esc"].includes(lO()(OO)))
                if ("esc" !== lO()(OO)) {
                  if (!fO.current || "/" !== lO()(OO)) {
                    if ("t" === lO()(OO)) {
                      if (fO.current) return void OO.stopPropagation();
                      OO.preventDefault()
                    }
                    fO.current && "" !== UO.current.value && KK.current(), OO.repeat || (fO.current || "/" === lO()(OO) && (UO.current.value = "/", OO.preventDefault()), oO(!fO.current))
                  }
                } else fO.current && (oO(!1), OO.stopPropagation());
              else fO.current && OO.stopPropagation()
            } else rK.includes(lO()(OO)) && (OO.preventDefault(), OO.stopPropagation(), (0, QO.b)(OO))
        };
        document.addEventListener("keydown", vK, {
          capture: !0
        });
        const CO = cK.current;
        let hO = !1;
        const MO = new ResizeObserver((() => {
            hO && (hO = !1, CK())
          })),
          aK = () => {
            hO = !0, MO.unobserve(CO), MO.observe(CO)
          };
        kK.current = aK;
        const FO = new MutationObserver(aK);
        return FO.observe(CO, {
          childList: !0,
          subtree: !0
        }), () => {
          document.removeEventListener("keydown", vK, {
            capture: !0
          }), document.removeEventListener("touchstart", OO, {
            capture: !0
          }), document.removeEventListener("mousedown", KO, {
            capture: !0
          }), document.removeEventListener("pointerlockchange", eO), kK.current = null, FO.disconnect(), MO.disconnect(), clearTimeout(WO.current)
        }
      }), []), (0, AO.o)(UO, {
        open: () => {
          oO(!0)
        },
        close: () => {
          XK()
        },
        submit: () => {
          "" !== UO.current.value && eK(), XK()
        },
        stepHistory: () => {
          vp(1, !0)
        },
        sendLine: OO => {
          lK(OO), XK()
        },
        selectNextChannel: () => {
          IO.e.selectNextChannel()
        }
      }), (0, XO.useEffect)((() => {
        var OO;
        (fO.current = eO, UO.current) && (eO ? (SO.current = 0, UO.current.focus()) : (UO.current.blur(), null === (OO = kK.current) || void 0 === OO || OO.call(kK)))
      }), [eO]), (0, wO.jsx)(wO.Fragment, {
        children: (0, wO.jsxs)("div", {
          ref: dO,
          className: FO()("Chat", {
            Chatting: eO
          }),
          "data-camera-keeper": eO ? "" : void 0,
          children: [(0, wO.jsx)("div", {
            ref: cK,
            className: FO()("ChatMessages", {
              HideScrollbar: !ZO && !eO,
              NoScrolling: !(0, DO.isMobile)() && qK
            }),
            children: (0, wO.jsx)(yK.b, {
              messages: TO,
              reportedPlayers: mK
            })
          }), KO && !eO && (0, wO.jsx)("button", {
            type: "button",
            className: "ChatIconWrapper SmallTextLight",
            "aria-label": OO("general:chat"),
            ...(0, uO.d)((() => {
              oO(!0), OK.current.style.display = "flex", (0, DO.isIOS)() && UO.current.focus()
            }), "pointerup"),
            children: (0, wO.jsx)(LO.d, {
              name: "comment-dots",
              className: "ChatIcon"
            })
          }), (0, wO.jsxs)("div", {
            ref: OK,
            className: "ChatInputWrapper",
            style: {
              display: "" + (eO ? "flex" : "none")
            },
            children: [HO && (0, wO.jsx)("button", {
              type: "button",
              className: "ChatInputChannel",
              style: {
                backgroundColor: HO.elementBgColor
              },
              onClick: OO => {
                IO.e.selectNextChannel(), UO.current.focus()
              },
              children: (0, wO.jsx)("span", {
                className: "SmallTextBold",
                children: (0, wO.jsx)(CO.d, {
                  text: HO.elementContent
                })
              })
            }), HO && pO && (0, wO.jsx)(sO, {}), (0, wO.jsx)("input", {
              className: "ChatInput",
              maxLength: aK.Rc,
              ref: UO,
              spellCheck: "false",
              autoComplete: "off",
              autoCorrect: "off",
              placeholder: HO ? `${HO.channelName} Chat${"touchOnly"===(0,MO.c)()||pO?"":" [Tab]"}` : ""
            })]
          })]
        })
      })
    }
    const RO = ["W", "S", "D", "N", "T", "<tab>", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "<page-up>", "<page-down>", "B", "O", "H", "J", "F", "G", "J", "M", "<enter>", "L", "K", "E", "P", "R", "O", "U"]
  },
  35092: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => IO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(7865),
      vK = pO(26),
      CO = pO(1933),
      hO = pO(2838),
      DO = pO(1627),
      MO = pO(22),
      aK = pO(1533),
      oO = pO(35095),
      FO = pO(1749),
      VO = pO(35102),
      LO = pO(2097),
      QO = pO(2077),
      zK = pO(2070),
      AO = pO(2855),
      fO = pO(2407),
      dO = pO(1583),
      TO = pO(976);

    function NO(OO) {
      for (let pO = OO.length - 1; pO >= 0; pO--) {
        const XO = "string" === typeof(KO = OO[pO]) ? KO : "str" in KO && "string" === typeof KO.str ? KO.str : "";
        if ("" !== XO.trim()) return XO
      }
      var KO;
      return ""
    }

    function IO(OO) {
      let {
        messages: KO,
        reportedPlayers: pO
      } = OO;
      return (0, TO.jsx)(TO.Fragment, {
        children: KO.map((OO => (0, TO.jsx)(yK, {
          message: OO,
          reportedPlayers: pO
        }, OO.clientChatMsgId)))
      })
    }
    const yK = (0, XO.memo)((function(OO) {
      var KO;
      let {
        message: pO,
        reportedPlayers: bK
      } = OO;
      const IO = (0, XO.useRef)(null),
        [yK] = (0, XO.useState)(fO.d),
        {
          author: gK
        } = pO,
        uO = null === gK || void 0 === gK ? void 0 : gK.id,
        EO = null !== (KO = null === gK || void 0 === gK ? void 0 : gK.name) && void 0 !== KO ? KO : void 0,
        jK = (0, DO.c)(EO),
        YO = null !== gK && void 0 !== gK && gK.profileEffect ? FO.c[gK.profileEffect] : void 0,
        wO = null !== gK && !gK.local,
        iK = null === gK && null !== pO.serverChatMsgId,
        rK = (0, dO.e)("hiddenPlayerNames", (OO => (0, VO.i)(wO, EO, OO))),
        PO = null === pO.serverChatMsgId || null === gK ? null : {
          text: NO(pO.content),
          serverChatMsgId: pO.serverChatMsgId,
          authorId: gK.id
        },
        mK = iK || null !== PO && !bK.includes(uO),
        sO = (0, hO.i)(wO && null !== EO && void 0 !== EO ? EO : null),
        HO = (0, zK.h)(IO);
      (0, XO.useEffect)((() => () => {
        zK.b.closeIfOwner(IO)
      }), []);
      const RO = () => {
          iK ? vK.i.pl("OpenReportMenu", {
            playerEId: null,
            playerName: void 0,
            Tl: (0, lO.d)(pO.content),
            serverChatMsgId: pO.serverChatMsgId
          }) : null !== PO ? vK.i.pl("OpenReportMenu", {
            playerEId: uO,
            playerName: EO,
            Tl: PO.text,
            serverChatMsgId: PO.serverChatMsgId
          }) : console.warn("Reporting a chat message the server never acknowledged")
        },
        SO = void 0 === EO ? [] : (0, AO.c)(sO, EO, PO);
      return (0, TO.jsxs)("div", {
        ref: IO,
        className: eO()("MessageWrapper", {
          ChatMsgSelectWrapper: uO,
          Still: yK
        }),
        onContextMenu: rK ? OO => {
          (0, LO.d)(IO, OO, {
            ...(0, VO.e)(uO, EO),
            showLocation: !1,
            status: null,
            extraActions: mK ? [{
              icon: "flag",
              text: "Report",
              onClick: RO
            }] : [],
            friendRequestSource: "chat"
          }, MO.d.get("isTouchScreen"))
        } : void 0,
        onPointerDown: rK ? OO => {
          (0, QO.e)(OO, (() => (0, VO.e)(uO, EO).playerSocialPreview))
        } : void 0,
        children: [YO && (0, TO.jsx)(YO, {
          className: "ChatMessageBackground",
          simple: !0
        }), (wO || iK) && !HO && (0, TO.jsx)(oO.d, {
          className: "ChatFloatingActions",
          triggerElementRef: IO,
          options: [{
            icon: "flag",
            text: "Report",
            onPointerDown: RO,
            show: mK
          }, ...SO, {
            icon: "user-plus",
            text: "socialBar:sendFriendRequest",
            onPointerDown: OO => {
              (0, CO.g)(EO, "chat")
            },
            analyticsClick: {
              id: "social.add_friend",
              value: "chat"
            },
            show: rK && "blocked" !== sO
          }]
        }), (0, TO.jsx)(aK.d, {
          text: pO.content,
          friendBadgeFor: jK ? EO : void 0
        }, pO.clientChatMsgId)]
      }, pO.clientChatMsgId)
    }))
  },
  35130: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      h: () => FO,
      i: () => aK,
      k: () => MO
    });
    var XO = pO(8311),
      bK = pO(35137),
      eO = pO(35139),
      lO = pO(7854),
      vK = pO(1263),
      CO = pO(63),
      hO = pO(77),
      DO = pO(976);

    function MO() {
      var OO;
      return (0, vK.h)(bK.d, (0, bK.l)()), (0, DO.jsx)(DO.Fragment, {
        children: null === (OO = (0, bK.l)()) || void 0 === OO ? void 0 : OO.content
      })
    }

    function aK(OO) {
      var KO;
      let {
        show: pO
      } = OO;
      (0, vK.h)(bK.d, (0, bK.l)());
      const hO = null === (KO = (0, bK.l)()) || void 0 === KO ? void 0 : KO.menu;
      return (0, CO.useEffect)((() => {
        var OO;
        pO || (null === hO || void 0 === hO || null === (OO = hO.onClose) || void 0 === OO || OO.call(hO), (0, eO.q)())
      }), [pO, hO]), (0, CO.useEffect)((() => pO ? (0, lO.f)(eO.y, eO.f) : void 0), [pO]), (0, DO.jsx)(XO.e, {
        showing: pO,
        globallyUniqueKey: "clientGameMenu",
        children: null === hO || void 0 === hO ? void 0 : hO.content
      })
    }

    function oO(OO) {
      let {
        placement: KO = "bottom"
      } = OO;
      return (0, DO.jsx)("div", {
        id: `clientGameHud-${KO}`,
        style: {
          display: "contents"
        }
      })
    }

    function FO(OO) {
      let {
        children: KO,
        placement: pO = "bottom"
      } = OO;
      const [XO, bK] = (0, CO.useState)(null);
      return (0, CO.useEffect)((() => {
        bK(document.getElementById(`clientGameHud-${pO}`))
      }), [pO]), XO ? (0, hO.createPortal)(KO, XO) : null
    }
  },
  35386: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => AO,
      f: () => LO,
      g: () => FO,
      j: () => oO,
      m: () => zK,
      n: () => yK,
      o: () => fO,
      p: () => TO,
      r: () => dO,
      v: () => IO,
      y: () => bK,
      z: () => NO
    });
    var XO = pO(63);
    const bK = 5e3,
      eO = 500,
      lO = 3e3;
    let vK = null,
      CO = null,
      hO = null;
    const DO = new Set;

    function MO(OO) {
      vK = OO;
      for (const KO of DO) KO()
    }

    function aK() {
      if (!vK || void 0 !== vK.endedAt) return;
      null !== CO && (clearTimeout(CO), CO = null), MO({
        ...vK,
        endedAt: Date.now()
      });
      const OO = hO;
      hO = null, null === OO || void 0 === OO || OO()
    }

    function oO(OO, KO) {
      let {
        submit: pO,
        reopen: XO
      } = KO;
      null !== CO && clearTimeout(CO), hO = XO, MO({
        ...OO,
        startedAt: Date.now(),
        errors: []
      }), CO = setTimeout(aK, lO), pO()
    }

    function FO() {
      vK && void 0 === vK.endedAt && void 0 === vK.ranAt && (null !== CO && clearTimeout(CO), MO({
        ...vK,
        ranAt: Date.now()
      }), CO = setTimeout(aK, bK))
    }
    const VO = 3;

    function LO(OO) {
      if (!vK || void 0 === vK.ranAt || void 0 !== vK.endedAt || vK.errors.includes(OO) || vK.errors.length >= VO) return;
      const KO = 0 === vK.errors.length;
      MO({
        ...vK,
        errors: [...vK.errors, OO]
      }), KO && (null !== CO && clearTimeout(CO), CO = setTimeout(aK, eO))
    }

    function QO(OO) {
      var KO;
      return (null === (KO = vK) || void 0 === KO ? void 0 : KO.chatKey) === OO ? vK : null
    }

    function zK(OO) {
      const KO = QO(OO);
      return KO && void 0 !== KO.endedAt ? (MO(null), KO) : null
    }

    function AO(OO) {
      var KO;
      (null === (KO = vK) || void 0 === KO ? void 0 : KO.chatKey) === OO && (null !== CO && (clearTimeout(CO), CO = null), hO = null, MO(null))
    }
    const fO = "These changes from your last answer didn't go in. Make them again.";

    function dO(OO) {
      const KO = [...new Set(OO)].slice(0, VO);
      return `Fix this in your change: when it ran, the world showed ${1===KO.length?"this error":"these errors"}: ${KO.join(" ")}`
    }

    function TO(OO) {
      return `Your change didn't go in, because the code wouldn't run at all: ${OO.join(" ")} Send the whole change again with that fixed.`
    }

    function NO(OO) {
      return `Fix this in your change: ${OO.join(" ")}`
    }

    function IO(OO) {
      var KO;
      if (void 0 === OO.ranAt) return {
        title: "Couldn't test it",
        text: "Your change didn't go into your world, so it couldn't be tested. Press Submit to try it."
      };
      const pO = Math.max(1, Math.round(((null !== (KO = OO.endedAt) && void 0 !== KO ? KO : OO.ranAt) - OO.ranAt) / 1e3)),
        XO = `Your change ran in your world for ${pO} ${1===pO?"second":"seconds"}`;
      return 0 === OO.errors.length ? {
        title: "Tested: no errors",
        text: `${XO} without an error.`
      } : {
        title: 1 === OO.errors.length ? "Tested: it showed an error" : `Tested: it showed ${OO.errors.length} errors`,
        text: `${XO} and showed: ${OO.errors.join(" ")}`
      }
    }

    function yK(OO) {
      const [KO, pO] = (0, XO.useState)((() => QO(OO)));
      return (0, XO.useEffect)((() => {
        const KO = () => {
          pO(QO(OO))
        };
        return KO(), DO.add(KO), () => {
          DO.delete(KO)
        }
      }), [OO]), KO
    }
  },
  35395: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      i: () => XO
    });
    const XO = {
      key: "worldCode",
      label: "World Code",
      codeBlock: !1
    };

    function bK(OO, KO, pO) {
      return {
        key: OO,
        label: `Code block at ${KO.join(", ")}`,
        codeBlock: !0,
        pos: KO,
        canChangePos: pO
      }
    }
  },
  35383: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO,
      f: () => eO,
      j: () => lO,
      k: () => bK
    });
    const XO = "code block",
      bK = "World Code/";

    function eO(OO) {
      return OO.trim().toLowerCase().startsWith(bK.toLowerCase())
    }

    function lO(OO) {
      return OO.trim().slice(bK.length).replace(/^\.?\//, "")
    }
  },
  35364: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => aK,
      B: () => iK,
      E: () => IO,
      F: () => yK,
      H: () => wO,
      e: () => FO,
      i: () => CO,
      j: () => VO,
      m: () => uO,
      n: () => vK,
      o: () => DO,
      q: () => oO,
      r: () => LO,
      u: () => fO,
      v: () => EO,
      z: () => gK
    });
    var XO = pO(35356),
      bK = pO(35362);
    const eO = "bloxd-world-code-directory-sync",
      lO = "handles",
      vK = "[INVALID SCHEMATIC PLACEHOLDER]";

    function CO(OO, KO) {
      return `${OO}::${KO}`
    }
    const hO = new Set(["node_modules", ".git"]);

    function DO() {
      return "undefined" !== typeof window && "function" === typeof window.showDirectoryPicker
    }

    function MO() {
      return new Promise(((OO, KO) => {
        const pO = indexedDB.open(eO, 1);
        pO.onupgradeneeded = () => {
          const OO = pO.result;
          OO.objectStoreNames.contains(lO) || OO.createObjectStore(lO)
        }, pO.onsuccess = () => {
          OO(pO.result)
        }, pO.onerror = () => {
          var OO;
          KO(null !== (OO = pO.error) && void 0 !== OO ? OO : new Error("Failed to open directory sync IndexedDB"))
        }
      }))
    }
    async function aK(OO, KO) {
      const pO = await MO();
      try {
        await new Promise(((XO, bK) => {
          const eO = pO.transaction(lO, "readwrite");
          eO.objectStore(lO).put(KO, OO), eO.oncomplete = () => {
            XO()
          }, eO.onerror = () => {
            var OO;
            bK(null !== (OO = eO.error) && void 0 !== OO ? OO : new Error("Failed to store directory handle"))
          }
        }))
      } finally {
        pO.close()
      }
    }
    async function oO(OO) {
      const KO = await MO();
      try {
        return await new Promise(((pO, XO) => {
          const bK = KO.transaction(lO, "readonly").objectStore(lO).get(OO);
          bK.onsuccess = () => {
            var OO;
            pO(null !== (OO = bK.result) && void 0 !== OO ? OO : null)
          }, bK.onerror = () => {
            var OO;
            XO(null !== (OO = bK.error) && void 0 !== OO ? OO : new Error("Failed to load directory handle"))
          }
        }))
      } finally {
        KO.close()
      }
    }
    async function FO(OO) {
      const KO = await MO();
      try {
        await new Promise(((pO, XO) => {
          const bK = KO.transaction(lO, "readwrite");
          bK.objectStore(lO).delete(OO), bK.oncomplete = () => {
            pO()
          }, bK.onerror = () => {
            var OO;
            XO(null !== (OO = bK.error) && void 0 !== OO ? OO : new Error("Failed to clear directory handle"))
          }
        }))
      } finally {
        KO.close()
      }
    }
    async function VO(OO) {
      const KO = {
        mode: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "readwrite"
      };
      return "granted" === await OO.queryPermission(KO) || "granted" === await OO.requestPermission(KO)
    }
    async function LO(OO) {
      if (!DO()) return null;
      try {
        const KO = await window.showDirectoryPicker({
          mode: "readwrite"
        });
        return await aK(OO, KO), KO
      } catch (KO) {
        if (function(OO) {
            return OO instanceof DOMException && "AbortError" === OO.name
          }(KO)) return null;
        throw KO
      }
    }

    function QO(OO) {
      return OO.startsWith(".") || hO.has(OO)
    }

    function zK(OO) {
      if (!OO) return !0;
      const KO = OO.split("/");
      for (const pO of KO)
        if ("" === pO || "." === pO || ".." === pO) return !1;
      return !0
    }
    async function AO(OO, KO, pO) {
      for await (const [eO, lO] of OO.entries()) {
        if ("directory" === lO.kind) {
          if (QO(eO)) continue;
          const OO = KO ? `${KO}/${eO}` : eO;
          if (!zK(OO)) continue;
          await AO(lO, OO, pO);
          continue
        }
        const OO = KO ? `${KO}/${eO}` : eO;
        if (!(0, XO.x)(OO) && !(0, bK.e)(OO)) continue;
        const vK = await lO.getFile();
        pO[OO] = (0, bK.e)(OO) ? await jK(vK) : await vK.text()
      }
    }
    async function fO(OO) {
      const KO = {};
      return await AO(OO, "", KO), KO
    }

    function dO(OO) {
      return !(!OO || OO !== OO.trim() || OO.startsWith("/") || OO.includes("\\") || OO.includes("\0")) && zK(OO)
    }
    async function TO(OO, KO, pO) {
      const XO = KO.split("/"),
        bK = XO[XO.length - 1];
      let eO = OO;
      for (let lO = 0; lO < XO.length - 1; lO++) eO = await eO.getDirectoryHandle(XO[lO], {
        create: pO
      });
      return {
        dir: eO,
        fileName: bK
      }
    }
    async function NO(OO, KO, pO) {
      if (!dO(KO)) throw new Error(`Refusing to write unsafe path: ${KO}`);
      const {
        dir: XO,
        fileName: bK
      } = await TO(OO, KO, !0), eO = await XO.getFileHandle(bK, {
        create: !0
      }), lO = await eO.createWritable();
      await lO.write(pO), await lO.close()
    }
    async function IO(OO, KO, pO) {
      const XO = await async function(OO, KO) {
        if (!dO(KO)) return null;
        try {
          const {
            dir: pO,
            fileName: XO
          } = await TO(OO, KO, !1), bK = await pO.getFileHandle(XO), eO = await bK.getFile();
          return await eO.text()
        } catch (pO) {
          if (pO instanceof DOMException && ("NotFoundError" === pO.name || "NotAllowedError" === pO.name)) return null;
          throw pO
        }
      }(OO, KO);
      XO !== pO && await NO(OO, KO, pO)
    }
    async function yK(OO, KO, pO) {
      if (!(0, XO.x)(KO) && !(0, bK.e)(KO)) throw new Error(`Refusing to write non-allowlisted path: ${KO}`);
      if ((0, bK.e)(KO)) {
        if (await YO(OO, KO) === vK) throw new Error(`Move the binary schematic ${KO} outside the linked folder before syncing its placeholder`)
      }
      await NO(OO, KO, pO)
    }
    async function gK(OO, KO) {
      if (!dO(KO)) throw new Error(`Refusing to remove unsafe path: ${KO}`);
      try {
        const {
          dir: pO,
          fileName: XO
        } = await TO(OO, KO, !1);
        await pO.removeEntry(XO)
      } catch (pO) {
        if (pO instanceof DOMException && ("NotFoundError" === pO.name || "NotAllowedError" === pO.name)) return;
        throw pO
      }
    }
    async function uO(OO, KO) {
      if (!dO(KO)) return null;
      try {
        const pO = KO.split("/");
        let XO = OO;
        for (const OO of pO) XO = await XO.getDirectoryHandle(OO);
        return XO
      } catch (pO) {
        if (pO instanceof DOMException && ("NotFoundError" === pO.name || "NotAllowedError" === pO.name)) return null;
        throw pO
      }
    }
    async function EO(OO, KO) {
      if ((0, XO.x)(KO) || (0, bK.e)(KO)) {
        if ((0, bK.e)(KO)) {
          if (await YO(OO, KO) === vK) throw new Error(`Refusing to remove a binary schematic: ${KO}`)
        }
        await gK(OO, KO)
      }
    }
    async function jK(OO) {
      if (OO.size > 64) return vK;
      const KO = await OO.text();
      return Array.from(KO).some((OO => {
        const KO = OO.charCodeAt(0);
        return KO < 9 || KO > 13 && KO < 32 || 65533 === KO
      })) ? vK : KO
    }
    async function YO(OO, KO) {
      try {
        const {
          dir: pO,
          fileName: XO
        } = await TO(OO, KO, !1);
        return await jK(await (await pO.getFileHandle(XO)).getFile())
      } catch (pO) {
        if (pO instanceof DOMException && "NotFoundError" === pO.name) return null;
        throw pO
      }
    }
    async function wO(OO, KO) {
      const pO = await fO(OO);
      for (const XO of Object.keys(pO)) XO in KO || (0, bK.e)(XO) || await EO(OO, XO);
      for (const [eO, lO] of Object.entries(KO))((0, XO.x)(eO) || (0, bK.e)(eO)) && await yK(OO, eO, lO)
    }

    function iK(OO, KO) {
      var pO, XO;
      let bK = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      const eO = null !== (pO = bK.debounceMs) && void 0 !== pO ? pO : 300,
        lO = null !== (XO = bK.pollMs) && void 0 !== XO ? XO : 1e3;
      let vK = !1,
        CO = null,
        hO = null,
        DO = null;
      const MO = () => {
          vK || (CO && clearTimeout(CO), CO = setTimeout((() => {
            CO = null, aK()
          }), eO))
        },
        aK = async () => {
          if (!vK) try {
            if (!await VO(OO, "readwrite")) return;
            const pO = await fO(OO);
            vK || KO(pO)
          } catch (pO) {
            console.error("[WorldCodeDirectorySync] Failed to read watched directory", pO)
          }
        };
      aK();
      const oO = window.FileSystemObserver;
      if (oO) try {
        DO = new oO((() => {
          MO()
        })), DO.observe(OO, {
          recursive: !0
        })
      } catch (FO) {
        console.warn("[WorldCodeDirectorySync] FileSystemObserver unavailable, falling back to polling", FO), DO = null
      }
      return DO || (hO = setInterval((() => {
        MO()
      }), lO)), () => {
        vK = !0, CO && clearTimeout(CO), hO && clearInterval(hO), DO && DO.disconnect()
      }
    }
  },
  35037: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => NO,
      d: () => TO,
      f: () => fO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(1e3),
      vK = pO(243),
      CO = pO(1991),
      hO = pO(26),
      DO = pO(1569),
      MO = pO(36),
      aK = pO(1583),
      oO = pO(22),
      FO = pO(1588),
      VO = pO(1225),
      LO = pO(7907),
      QO = pO(1618),
      zK = pO(1051),
      AO = pO(976);
    const fO = 7e3;
    let dO = !1;

    function TO() {
      return dO
    }
    const NO = (0, XO.memo)((function() {
      const {
        isTouchScreen: OO,
        loadingOverlayVisible: KO
      } = (0, oO.l)(["isTouchScreen", "loadingOverlayVisible"]), pO = (0, VO.p)();
      (0, lO.c)();
      const bK = (0, CO.i)("showBasicMovementControls"),
        [hO, DO] = (0, XO.useState)("movement"),
        aK = "movement" === hO,
        FO = pO && !1 !== bK;
      (0, XO.useEffect)((() => {
        "padActions" !== hO || FO || DO("done")
      }), [hO, FO]);
      const LO = MO.e.getItem(vK.Ib) > 2,
        QO = "padActions" === hO && FO && !LO,
        zK = (0, XO.useRef)(!1);
      return zK.current = !1 !== bK && !LO, (0, XO.useEffect)((() => (dO = QO, () => {
        dO = !1
      })), [QO, hO]), (0, XO.useEffect)((() => {
        if (KO || "done" === hO) return;
        const OO = setTimeout((() => {
          const OO = "movement" === hO && (0, VO.h)() ? "padActions" : "done";
          dO = "padActions" === OO && zK.current, DO(OO)
        }), fO);
        return () => {
          clearTimeout(OO)
        }
      }), [KO, hO]), LO ? (0, AO.jsx)(uO, {
        showingMovementControls: !1
      }) : (0, AO.jsxs)(AO.Fragment, {
        children: [OO && !pO || !aK || !1 === bK ? null : (0, AO.jsxs)("div", {
          className: eO()("ControlsTutorialDiv", {
            UnderLoadingOverlay: KO
          }),
          children: [(0, AO.jsx)(IO, {}), (0, AO.jsx)(gK, {
            header: "Sprint",
            noaAction: "sprint"
          }), (0, AO.jsx)(gK, {
            header: "Jump",
            noaAction: "jump"
          })]
        }), "padActions" === hO && FO && (0, AO.jsx)(yK, {}), (0, AO.jsx)(uO, {
          showingMovementControls: "done" !== hO
        })]
      })
    }));

    function IO() {
      const OO = (0, VO.p)();
      return (0, AO.jsxs)("div", {
        className: "KeyControlDiv",
        children: [(0, AO.jsx)("div", {
          className: "KeyHeader",
          children: "Move"
        }), OO && (0, AO.jsx)(FO.d, {
          noaAction: "forward"
        }), !OO && (0, AO.jsxs)(AO.Fragment, {
          children: [(0, AO.jsx)("div", {
            className: "WasdKeysTopRow",
            children: (0, AO.jsx)(FO.d, {
              noaAction: "forward"
            })
          }), (0, AO.jsxs)("div", {
            className: "WasdKeysBottomRow",
            children: [(0, AO.jsx)(FO.d, {
              noaAction: "left"
            }), (0, AO.jsx)(FO.d, {
              noaAction: "backward"
            }), (0, AO.jsx)(FO.d, {
              noaAction: "right"
            })]
          })]
        })]
      })
    }

    function yK() {
      const {
        t: OO
      } = (0, zK.D)(), KO = (0, CO.i)("useInventory");
      return (0, AO.jsxs)("div", {
        className: "ControlsTutorialDiv",
        children: [(0, AO.jsx)(gK, {
          header: OO("controller:tutorialMine"),
          noaAction: "primary-fire"
        }), (0, AO.jsx)(gK, {
          header: OO("controller:tutorialPlace"),
          noaAction: "alt-fire"
        }), !1 !== KO && (0, AO.jsx)(gK, {
          header: OO("controller:tutorialInventory"),
          noaAction: "OpenInventory"
        }), (0, AO.jsx)(gK, {
          header: OO("controller:tutorialPause"),
          noaAction: "OpenSettings"
        })]
      })
    }

    function gK(OO) {
      let {
        header: KO,
        noaAction: pO
      } = OO;
      return (0, AO.jsxs)("div", {
        className: "KeyControlDiv",
        children: [(0, AO.jsx)("div", {
          className: "KeyHeader",
          children: KO
        }), (0, AO.jsx)(FO.d, {
          noaAction: pO
        })]
      })
    }

    function uO(OO) {
      let {
        showingMovementControls: KO
      } = OO;
      const {
        isTouchScreen: pO
      } = (0, oO.l)(["isTouchScreen"]), bK = (0, VO.p)(), eO = (0, QO.d)("OpenShop"), [lO, vK] = (0, XO.useState)(!1), FO = `SeenShopControls|${(0,aK.e)("connectedGame",(OO=>OO.gameNameWithVariation))}`, zK = () => (!(0, VO.h)() || null !== (0, LO.d)("OpenShop")) && !MO.e.getItem(FO) && DO.c.get("shopInfo") && !KO, fO = () => (vK(!0), MO.e.setItem(FO, !0), (0, VO.h)() || hO.i.pl("showShopTouchTutorial"), setTimeout((() => {
        vK(!1)
      }), 7e3));
      (0, XO.useEffect)((() => {
        let OO;
        const KO = hO.i.subscribe("showShopTutorial", (() => {
          zK() && (OO = fO())
        }));
        return () => {
          clearTimeout(OO), hO.i.unsubscribe(KO)
        }
      }), [KO]);
      const dO = (0, XO.useRef)();
      return (0, CO.f)("currencyAmounts", (OO => {
        if (zK()) {
          let pO = !1;
          const XO = DO.c.get("shopInfo");
          for (const bK in XO) {
            for (const eO in XO[bK].items) {
              var KO;
              const lO = XO[bK].items[eO];
              if (void 0 !== lO.currency && OO[lO.currency] && lO.cost <= OO[lO.currency].amount && (null === (KO = lO.hidden) || void 0 === KO || !KO)) {
                pO = !0;
                break
              }
            }
            if (pO) break
          }
          pO && (dO.current = fO())
        }
      })), (0, XO.useEffect)((() => () => {
        clearTimeout(dO.current)
      }), [KO]), !lO || bK && !eO ? null : (0, AO.jsx)("div", {
        className: "ControlsTutorialDiv",
        children: pO && !bK ? null : (0, AO.jsx)(gK, {
          header: "Shop",
          noaAction: "OpenShop"
        })
      })
    }
  },
  3967: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => LO,
      f: () => QO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(63),
      lO = pO(1051),
      vK = pO(3969),
      CO = pO(1533),
      hO = pO(1991),
      DO = pO(3972),
      MO = pO(976);
    const aK = new WeakMap;
    let oO = 0;

    function FO(OO) {
      let KO = aK.get(OO);
      return void 0 === KO && (KO = oO++, aK.set(OO, KO)), KO
    }

    function VO(OO) {
      let {
        piece: KO
      } = OO;
      return "space" === KO.kind ? (0, MO.jsx)(MO.Fragment, {
        children: KO.text
      }) : (0, MO.jsx)("span", {
        className: "DialogueWord",
        style: {
          "--word-delay": `${KO.delayMs}ms`
        },
        children: (0, MO.jsx)(vK.b, {
          text: "icon" === KO.kind ? `[[${KO.icon}]]` : KO.text
        })
      })
    }

    function LO(OO) {
      let {
        display: KO
      } = OO;
      const {
        selectedLanguage: pO
      } = (0, lO.D)(), XO = (0, eO.useMemo)((() => (0, DO.e)((0, DO.g)(KO).plan.pieces)), [KO, pO.code]);
      return (0, MO.jsxs)("div", {
        className: bK()("Dialogue", {
          DialogueAnimateIn: !1 !== KO.animateIn
        }),
        children: [KO.speakerName && (0, MO.jsx)(CO.d, {
          text: KO.speakerName,
          className: "DialogueSpeaker"
        }), (0, MO.jsx)("p", {
          className: "DialogueLine",
          children: XO.map(((OO, KO) => 1 === OO.length && "space" === OO[0].kind ? OO[0].text : (0, MO.jsx)("span", {
            className: "DialogueGlue",
            children: OO.map(((OO, KO) => (0, MO.jsx)(VO, {
              piece: OO
            }, KO)))
          }, KO)))
        })]
      })
    }
    const QO = (0, eO.memo)((function() {
      const OO = (0, hO.i)("dialogue");
      return (0, MO.jsx)("div", {
        className: "DialogueAnchor",
        "data-camera-keeper": "",
        role: "status",
        "aria-live": "polite",
        "aria-atomic": "true",
        children: OO && (0, MO.jsx)(LO, {
          display: OO
        }, FO(OO))
      })
    }))
  },
  35220: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      h: () => FO
    });
    var XO = pO(63),
      bK = pO(2332),
      eO = pO(1263),
      lO = pO(1583),
      vK = pO(35157),
      CO = pO(533),
      hO = pO(918),
      DO = pO.n(hO),
      MO = pO(976);
    const aK = {},
      oO = (0, XO.memo)((function() {
        const OO = (0, bK.b)();
        return (0, eO.f)("damagedByOtherPlayer", (KO => {
          let {
            A7: pO,
            direction: XO
          } = KO;
          const bK = pO || "nonDirectional";
          if (aK[bK]) {
            const KO = aK[bK];
            clearTimeout(KO.timeout), KO.direction = XO, KO.timeout = setTimeout((() => {
              delete aK[bK], OO()
            }), 800)
          } else aK[bK] = {
            direction: XO,
            wpO: null,
            timeout: setTimeout((() => {
              delete aK[bK], OO()
            }), 800)
          };
          OO()
        })), (0, lO.b)("kill", (KO => {
          let {
            killer: pO,
            victim: XO
          } = KO;
          const bK = XO.id;
          pO.local && bK && bK in aK && (clearTimeout(aK[bK].timeout), delete aK[bK], OO())
        })), (0, XO.useEffect)((() => {
          const OO = (0, vK.f)("turnDamageIndicators", FO);
          return () => {
            OO();
            for (const OO in aK) clearTimeout(aK[OO].timeout), delete aK[OO]
          }
        }), []), (0, MO.jsx)("div", {
          className: "DirectionalDamage",
          children: Object.entries(aK).map((OO => {
            let [KO, pO] = OO;
            const XO = (0, CO.I)(pO.direction);
            return (0, MO.jsx)("div", {
              ref: OO => {
                aK[KO] && (aK[KO].wpO = OO)
              },
              className: DO()("DamageIndicator", {
                DamageIndicatorFullCircle: XO
              })
            }, KO)
          }))
        })
      }));

    function FO(OO) {
      for (const KO in aK) {
        const {
          direction: pO,
          wpO: XO
        } = aK[KO];
        if ((0, CO.I)(pO)) continue;
        const bK = pO - OO;
        XO.style.rotate = `${bK}rad`
      }
    }
  },
  7872: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => YO,
      g: () => gK,
      h: () => uO
    });
    var XO = pO(63),
      bK = pO(3730),
      eO = pO(1004),
      lO = pO(1263),
      vK = pO(26),
      CO = pO(2692),
      hO = pO(1811),
      DO = pO(1098),
      MO = pO(7899),
      aK = pO(1556),
      oO = pO(1583),
      FO = pO(1051),
      VO = pO(22),
      LO = pO(1441),
      QO = pO(918),
      zK = pO.n(QO),
      AO = pO(7875),
      fO = pO(7880),
      dO = pO(7886),
      TO = pO(7847),
      NO = pO(7893),
      IO = (pO(7896), pO(976));
    let yK = null;

    function gK() {
      return null !== yK
    }

    function uO() {
      return "pad" === yK
    }

    function EO() {
      return "inGame" === VO.d.get("gameState") && !(0, LO.i)()
    }

    function jK(OO) {
      return (0, fO.v)(OO, DO.m, fO.g, fO.k, fO.n)
    }
    const YO = (0, XO.memo)((function() {
      const {
        t: OO
      } = (0, FO.D)(), {
        userContext: KO
      } = (0, eO.d)(), [pO, VO] = (0, XO.useState)(null), [QO, gK] = (0, XO.useState)(null), uO = (0, XO.useRef)(null), YO = (0, XO.useCallback)((OO => {
        uO.current = OO, gK(OO)
      }), []), wO = (0, XO.useRef)(0), iK = (0, XO.useRef)(null), rK = (0, XO.useRef)({
        x: 0,
        y: 0
      }), [PO, mK] = (0, XO.useState)(0), sO = (0, XO.useMemo)((() => function(OO) {
        const KO = [];
        for (let XO = 0; XO < DO.m; XO++) {
          var pO;
          KO.push(null !== (pO = OO[XO]) && void 0 !== pO ? pO : null)
        }
        return KO
      }((0, MO.h)(KO.getPlayerCosmetics().emote))), [KO, PO]);
      (0, oO.b)("cosmeticsUpdated", (OO => {
        OO.some((OO => OO.local && "emote" === OO.oV)) && mK((OO => OO + 1))
      }));
      const HO = (0, XO.useRef)(!1),
        RO = (0, XO.useCallback)((function(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          "pad" === OO && (0, dO.e)(), HO.current = KO, rK.current = {
            x: 0,
            y: 0
          }, YO(null), VO(OO)
        }), [YO]),
        SO = (0, XO.useCallback)((() => {
          VO(null), YO(null), rK.current = {
            x: 0,
            y: 0
          }
        }), [YO]),
        JO = (0, XO.useCallback)((OO => {
          if (Date.now() < wO.current) return;
          const KO = (0, hO.j)(OO),
            pO = !!KO.holdUntilMove,
            XO = pO ? 600 : Math.ceil(1e3 * KO.animation.animation_length / hO.d) + 200;
          wO.current = Date.now() + XO, iK.current = OO, aK.gameBridge.send("playEmote", OO), aK.gameBridge.send("applyTemporaryThirdPerson", pO ? {} : {
            durationMs: XO
          })
        }), []);
      (0, lO.f)("requestToggleEmoteWheel", (() => {
        null === pO ? EO() && RO("click") : SO()
      })), (0, lO.f)("requestEmoteWheelHoldOpen", (() => {
        null === pO && EO() && RO((0, AO.b)() ? "hold" : "click")
      })), (0, lO.f)("requestEmoteWheelPadOpen", (OO => {
        null !== pO || !EO() || (0, TO.b)() || (0, NO.o)() || RO("pad", OO)
      })), (0, lO.f)("requestEmoteRepeatLast", (() => {
        if (null !== pO || !EO() || (0, TO.b)() || (0, NO.o)()) return;
        const OO = iK.current;
        null !== OO && sO.includes(OO) ? JO(OO) : RO("pad", !0)
      }));
      const cK = () => {
        const OO = uO.current,
          KO = null !== OO ? sO[OO] : null;
        null !== KO && "pad" === pO && Date.now() < wO.current || (SO(), null !== KO && JO(KO))
      };
      (0, lO.f)("emoteWheelPadAim", (OO => {
        if ("pad" !== pO) return;
        const KO = (0, fO.H)(OO, DO.m, uO.current);
        YO(null !== KO && null !== sO[KO] ? KO : null)
      })), (0, lO.f)("requestEmoteWheelPadCommit", (OO => {
        "pad" !== pO || OO && HO.current || cK()
      })), (0, lO.f)("appManagerUpdated|activeInputDevice", (OO => {
        null !== pO && "pad" === pO !== ("gamepad" === OO) && SO()
      })), (0, XO.useLayoutEffect)((() => (yK = pO, (0, CO.r)("emoteWheel", "pad" === pO), vK.i.pl(CO.i), () => {
        yK = null, (0, CO.r)("emoteWheel", !1), vK.i.pl(CO.i)
      })), [pO]), (0, lO.f)("requestEmoteWheelHoldRelease", (() => {
        "hold" === pO && cK()
      })), (0, lO.f)("requestEmoteWheelClose", (() => {
        null !== pO && SO()
      })), (0, lO.f)("appManagerUpdated|gameState", (OO => {
        "inGame" !== OO && SO()
      }));
      const BO = () => {
        (0, LO.i)() && SO()
      };
      if ((0, lO.f)("appManagerUpdated|openEverythingMenuName", BO), (0, lO.f)("appManagerUpdated|openInGameMenuName", BO), (0, lO.f)("pointerLockUpdate", (OO => {
          OO || "hold" !== pO || SO()
        })), (0, XO.useEffect)((() => {
          if (null === pO) return;
          const OO = OO => {
            "Escape" === OO.key && (OO.stopImmediatePropagation(), OO.preventDefault(), SO())
          };
          return document.addEventListener("keydown", OO, !0), () => {
            document.removeEventListener("keydown", OO, !0)
          }
        }), [pO, SO]), (0, bK.b)(!0, "click" === pO, "EmoteWheelOverlay"), (0, XO.useEffect)((() => {
          if ("hold" === pO) return aK.gameBridge.send("holdEmoteWheel", !0), () => {
            aK.gameBridge.send("holdEmoteWheel", !1)
          }
        }), [pO]), (0, XO.useEffect)((() => {
          if ("hold" !== pO) return;
          const OO = parseFloat(window.getComputedStyle(document.documentElement).fontSize),
            KO = fO.u * OO,
            XO = fO.t * OO,
            bK = OO => {
              let pO = rK.current.x + OO.movementX,
                bK = rK.current.y + OO.movementY;
              const eO = Math.hypot(pO, bK);
              if (eO > KO) {
                const OO = KO / eO;
                pO *= OO, bK *= OO
              }
              rK.current = {
                x: pO,
                y: bK
              }, YO(function(OO, KO, pO, XO) {
                if (Math.hypot(OO, KO) < pO) return null;
                const bK = (0, fO.w)(OO, KO, DO.m);
                return null === XO[bK] ? null : bK
              }(pO, bK, XO, sO))
            };
          return document.addEventListener("mousemove", bK), () => {
            document.removeEventListener("mousemove", bK)
          }
        }), [pO, sO, YO]), null === pO) return null;
      const ZO = "hold" === pO || "pad" === pO,
        GO = null !== QO ? sO[QO] : null,
        qK = null !== GO ? (0, hO.j)(GO).displayName : OO("emotes:pickEmote");
      return (0, IO.jsx)("div", {
        className: zK()("EmoteWheelOverlay", {
          EmoteWheelOverlayPad: "pad" === pO
        }),
        onMouseDown: OO => {
          OO.target === OO.currentTarget && SO()
        },
        children: (0, IO.jsxs)("div", {
          className: "EmoteWheel",
          style: {
            width: 2 * fO.u + "rem",
            height: 2 * fO.u + "rem"
          },
          children: [(0, IO.jsxs)("svg", {
            className: "EmoteWheelSvg",
            viewBox: `0 0 ${fO.r} ${fO.r}`,
            children: [sO.map(((KO, pO) => {
              const XO = null !== KO,
                bK = ZO && pO === QO;
              return (0, IO.jsx)("path", {
                d: jK(pO),
                className: zK()("EmoteWheelWedge", {
                  EmoteWheelWedgeHighlighted: bK,
                  EmoteWheelWedgeDisabled: !XO
                }),
                onClick: OO => {
                  OO.stopPropagation(), null !== KO && (OO => {
                    SO(), JO(OO)
                  })(KO)
                },
                "aria-label": null !== KO ? (0, hO.j)(KO).displayName : OO("emotes:emptySlot")
              }, pO)
            })), (0, IO.jsx)("circle", {
              className: "EmoteWheelOuterRing",
              cx: fO.g,
              cy: fO.g,
              r: fO.n
            }), (0, IO.jsx)("circle", {
              className: "EmoteWheelInnerRing",
              cx: fO.g,
              cy: fO.g,
              r: fO.k
            }), ZO && null !== QO && (0, IO.jsx)("path", {
              className: "EmoteWheelWedgeOutline",
              d: jK(QO)
            })]
          }), sO.map(((OO, KO) => {
            const pO = null !== OO,
              XO = ZO && KO === QO,
              bK = (0, fO.z)(KO, DO.m),
              eO = fO.d * Math.cos(bK),
              lO = fO.d * Math.sin(bK);
            return (0, IO.jsx)("div", {
              className: zK()("EmoteWheelSlotIcon", {
                EmoteWheelSlotIconHighlighted: XO,
                EmoteWheelSlotIconDisabled: !pO
              }),
              style: {
                left: `calc(50% + ${eO}rem)`,
                top: `calc(50% + ${lO}rem)`,
                backgroundImage: pO ? `url(/textures/charSkins/previews/emote_${OO}_preview.png)` : void 0
              },
              "aria-hidden": !0
            }, KO)
          })), (0, IO.jsx)("div", {
            className: "EmoteWheelHint SmallTextBold",
            children: qK
          })]
        })
      })
    }))
  },
  35095: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => LO
    });
    var XO = pO(63),
      bK = pO(77),
      eO = pO(1051),
      lO = pO(918),
      vK = pO.n(lO),
      CO = pO(1481),
      hO = pO(933),
      DO = pO(1134),
      MO = pO(1302),
      aK = pO(1473),
      oO = pO(1298),
      FO = pO(976);
    const VO = 14;

    function LO(OO) {
      let {
        className: KO,
        triggerElementRef: pO,
        options: lO
      } = OO;
      const {
        t: LO
      } = (0, eO.D)(), [QO, zK] = (0, XO.useState)(!1), [AO, fO] = (0, XO.useState)({
        x: 0,
        y: 0
      }), dO = (0, XO.useRef)(null);
      (0, XO.useEffect)((() => {
        let OO = null;
        const KO = KO => {
            OO = {
              x: KO.clientX,
              y: KO.clientY
            }
          },
          XO = KO => {
            if (null === OO || !(0, oO.c)(OO, KO)) return;
            OO = null;
            const pO = VO * (0, CO.getRemInPx)();
            fO({
              x: Math.min(KO.clientX, window.innerWidth - pO - 5),
              y: KO.clientY
            }), zK((OO => !OO))
          },
          bK = OO => {
            var KO;
            null !== (KO = dO.current) && void 0 !== KO && KO.contains(OO.relatedTarget) || zK(!1)
          },
          eO = pO.current;
        return eO.addEventListener("pointerdown", KO), eO.addEventListener("pointerup", XO), eO.addEventListener("mouseleave", bK), () => {
          eO.removeEventListener("pointerdown", KO), eO.removeEventListener("pointerup", XO), eO.removeEventListener("mouseleave", bK)
        }
      }), [pO]), (0, XO.useEffect)((() => {
        if (QO) return (0, aK.b)("pointerdown", (OO => {
          !dO.current || dO.current.contains(OO.target) || pO.current.contains(OO.target) || zK(!1)
        }))
      }), [QO, pO]), (0, XO.useLayoutEffect)((() => {
        if (!QO || !dO.current) return;
        const OO = dO.current.getBoundingClientRect().height,
          KO = Math.max(5, window.innerHeight - OO - 5);
        AO.y > KO && fO({
          x: AO.x,
          y: KO
        })
      }), [QO, AO]), (0, DO.q)("popup", dO, (() => {
        zK(!1)
      }), QO);
      const TO = lO.filter((OO => !1 !== OO.show));
      return QO && 0 !== TO.length ? (0, bK.createPortal)((0, FO.jsx)("div", {
        ref: dO,
        className: vK()("FloatingActions", {
          [KO]: KO
        }),
        style: {
          width: `${VO}rem`,
          top: AO.y,
          left: AO.x
        },
        children: TO.map((OO => {
          let {
            icon: KO,
            text: pO,
            onPointerDown: XO,
            analyticsClick: bK
          } = OO;
          return (0, FO.jsxs)("div", {
            className: "FloatingAction",
            "data-pad-focusable": !0,
            onPointerUp: OO => {
              void 0 !== bK && (0, MO.e)(bK), XO(OO), zK(!1), OO.stopPropagation()
            },
            children: [(0, FO.jsx)(hO.d, {
              name: KO
            }), (0, FO.jsx)("div", {
              children: LO(pO)
            })]
          }, pO)
        }))
      }), function() {
        var OO;
        return null !== (OO = document.querySelector(".WholeAppWrapperInner")) && void 0 !== OO ? OO : document.body
      }()) : null
    }
  },
  35246: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => Ie
    });
    var XO = pO(35130),
      bK = pO(63),
      eO = pO(1650),
      lO = pO(3719),
      vK = pO(3725),
      CO = pO(1991),
      hO = pO(1556),
      DO = pO(976);

    function MO(OO) {
      let {
        className: KO,
        style: pO,
        vw: XO,
        maxPx: bK,
        children: eO
      } = OO;
      console.assert("number" === typeof XO && "number" === typeof bK, "vw and maxPx passed to Text must be numbers");
      const lO = window.innerWidth * (XO / 100) > bK ? `${bK}px` : `${XO}vw`;
      return (0, DO.jsx)("div", {
        className: KO,
        style: {
          ...pO,
          fontSize: lO
        },
        children: eO
      })
    }
    var aK = pO(35252),
      oO = pO(1271),
      FO = pO(26),
      VO = pO(1569),
      LO = pO(933);

    function QO(OO) {
      let {
        tasks: KO,
        lastDisplayedTasks: pO
      } = OO;
      return (0, DO.jsx)(DO.Fragment, {
        children: Object.keys(KO).map((OO => (0, DO.jsx)(zK, {
          task: KO[OO],
          lastDisplayedAs: pO[OO]
        }, KO[OO].text)))
      })
    }

    function zK(OO) {
      let {
        task: KO,
        lastDisplayedAs: pO
      } = OO;
      const [XO, eO] = (0, bK.useState)(null !== pO && void 0 !== pO && pO.progress ? pO.progress / KO.goal : 0), [lO, vK] = (0, bK.useState)(!1), [CO, hO] = (0, bK.useState)(KO.claimed || !1);
      return (0, bK.useEffect)((() => {
        eO(KO.progress / KO.goal)
      }), [KO.progress, KO.goal]), CO ? null : (0, DO.jsxs)("div", {
        className: "Task",
        children: [(0, DO.jsx)("div", {
          className: "TaskDescDiv",
          children: (0, DO.jsx)(MO, {
            className: "",
            style: {},
            vw: 1.5,
            maxPx: 30,
            children: KO.text
          })
        }), KO.progress < KO.goal ? (0, DO.jsxs)("div", {
          className: "TaskProgress",
          children: [0 !== XO ? (0, DO.jsx)("div", {
            className: "TaskProgressForeground",
            style: {
              width: 100 * XO + "%"
            }
          }) : null, (0, DO.jsx)("div", {
            className: "TaskProgressText",
            children: `${KO.progress}/${KO.goal}`
          })]
        }) : (0, DO.jsx)(oO.m, {
          className: "ClaimRewardButton",
          onClick: () => {
            vK(!0)
          },
          children: (0, DO.jsx)(MO, {
            className: "",
            style: {},
            vw: 1.5,
            maxPx: 30,
            children: "Claim Reward"
          })
        }), lO ? (0, DO.jsx)(AO, {
          task: KO,
          close: () => {
            KO.claimed = !0, hO(!0), vK(!1)
          }
        }) : null]
      })
    }

    function AO(OO) {
      let {
        task: KO,
        close: pO
      } = OO;
      const [XO, eO] = (0, bK.useState)({}), [lO, vK] = (0, bK.useState)("closed");
      (0, bK.useEffect)((() => {
        let OO;
        return "animStart" === lO && (OO = setTimeout((() => {
          vK("animEnd")
        }), 700)), () => {
          clearTimeout(OO)
        }
      }), [lO]), (0, aK.d)((() => {
        hO.gameBridge.send("completeTask", KO.text)
      }));
      const MO = (0, CO.i)("currencyAmounts");
      return (0, DO.jsxs)("div", {
        className: "RewardBackground",
        onClick: () => {
          if ("animEnd" === lO)
            if (0 === KO.rewards.length) pO(), hO.gameBridge.send("completeTask", KO.text);
            else {
              const OO = {
                ...VO.c.get("currencyAmounts")
              };
              for (const KO in XO) OO[KO] = {
                ...OO[KO],
                amount: OO[KO].amount + XO[KO]
              };
              VO.c.apply({
                currencyAmounts: OO
              }), vK("closed")
            }
          else "closed" === lO && (eO(KO.rewards.pop()), vK("animStart"))
        },
        children: [(0, DO.jsx)("img", {
          className: "Chest",
          alt: "closed" !== lO ? "open chest" : "closed chest",
          src: `/textures/miscImages/Treasure Chest ${"closed"!==lO?"open":"closed"}.png`
        }), (0, DO.jsx)("div", {
          className: "Rewards",
          children: "closed" !== lO ? Object.keys(XO).map((OO => {
            const KO = null === MO || void 0 === MO ? void 0 : MO[OO];
            return !KO || KO.hidden ? null : (0, DO.jsxs)("div", {
              className: "Reward",
              children: [(0, DO.jsx)(LO.d, {
                name: KO.icon,
                className: "3x UiCurrencyIcon RewardIcon",
                style: {
                  color: KO.iconColour
                }
              }), (0, DO.jsx)("div", {
                className: "RewardAmountText",
                children: "animStart" === lO ? 0 : XO[OO]
              })]
            }, OO)
          })) : null
        }), "animStart" === lO ? (0, DO.jsx)(fO, {}) : null, (0, DO.jsx)("div", {
          className: "ChestsLeft",
          children: KO.rewards.length
        })]
      })
    }

    function fO() {
      const [OO, KO] = (0, bK.useState)(0);
      (0, bK.useEffect)((() => {
        KO(1)
      }), []);
      return (0, DO.jsx)(DO.Fragment, {
        children: Array.from({
          length: 40
        }).map(((KO, pO) => (0, DO.jsx)(LO.d, {
          name: "star",
          className: "3x UiCurrencyIcon OpenStar",
          style: {
            bottom: 50 * OO * Math.cos(pO / 40 * (2 * Math.PI)) + 50 + "vh",
            left: 50 * OO * Math.sin(pO / 40 * (2 * Math.PI)) + "vh",
            opacity: 0 === OO ? 1 : 0
          }
        }, pO)))
      })
    }
    FO.i.subscribe("requiredLibrariesLoaded", (() => {
      setTimeout((() => {
        const OO = new Image,
          KO = new Image;
        OO.src = "/textures/miscImages/Treasure Chest open.png", KO.src = "/textures/miscImages/Treasure Chest closed.png"
      }), 1e4)
    }));
    var dO = pO(2430),
      TO = pO(1004),
      NO = pO(1533),
      IO = pO(1263),
      yK = pO(256),
      gK = pO(1583),
      uO = pO(1180);

    function EO(OO) {
      var KO, pO;
      let {
        byId: XO,
        localId: bK
      } = OO;
      return null === bK ? null : null !== (KO = null === (pO = XO[bK]) || void 0 === pO ? void 0 : pO.name) && void 0 !== KO ? KO : null
    }

    function jK(OO) {
      let {
        lbStats: KO,
        storedState: pO = {}
      } = OO;
      const {
        userContext: XO
      } = (0, TO.d)(), eO = (0, gK.e)("players", EO), [lO, vK] = (0, bK.useState)(pO.selectedCat || (null === KO || void 0 === KO ? void 0 : KO[0]) || null), [CO, MO] = (0, bK.useState)(pO.selectedTimeframe || "Today"), [aK, oO] = (0, bK.useState)(null);
      (0, bK.useEffect)((() => {
        null === lO && null !== KO && KO.length > 0 && vK(KO[0])
      }), [KO, lO]);
      const [FO, VO] = (0, bK.useState)(pO.seeingTop || !1), [LO, QO] = (0, bK.useState)(!1), zK = (0, bK.useCallback)((() => {
        null !== lO && null !== CO && (hO.gameBridge.send("requestLeaderboard", {
          category: lO.value,
          timeframe: CO,
          seeTop: FO
        }), fO(!0), iK && rK(null))
      }), [lO, CO, pO, FO]);
      (0, bK.useEffect)((() => {
        zK(), pO.selectedCat = lO, pO.selectedTimeframe = CO, pO.seeingTop = FO
      }), [lO, CO, pO, FO, zK]), (0, bK.useEffect)((() => {
        if ((null === aK || void 0 === aK ? void 0 : aK.length) > 0)
          if (FO) FO && QO(null === jK(aK));
          else {
            for (const OO of aK)
              if (1 === OO.place) return void QO(!1);
            QO(!0)
          }
      }), [aK, FO]), (0, IO.f)("leaderboardResponse", (OO => {
        let {
          category: pO,
          timeframe: XO,
          data: bK
        } = OO;
        for (let eO = 0; eO < KO; eO++)
          if (KO[eO].value === pO) {
            vK(KO[eO]);
            break
          } MO(XO), oO(bK), fO(!1)
      }));
      const [AO, fO] = (0, bK.useState)(!0);

      function jK(OO) {
        const KO = EO(hO.gameBridge.latest("players"));
        for (let pO = 0; pO < OO.length; pO++)
          if (OO[pO].name === KO) return OO[pO].place;
        return null
      }
      const [YO, wO] = (0, bK.useState)(!1), [iK, rK] = (0, bK.useState)(null);
      (0, bK.useEffect)((() => {
        if (aK && !YO) {
          const OO = jK(aK);
          OO < (pO.lastSeenPlayerPlace || 0) && rK(pO.lastSeenPlayerPlace - OO), wO(!0)
        }
      }), [aK, pO, YO]), (0, bK.useEffect)((() => () => {
        aK && (pO.lastSeenPlayerPlace = jK(aK))
      }), [aK, pO]);
      const PO = (0, bK.useRef)(null),
        [mK, sO] = (0, bK.useState)(void 0);
      return (0, bK.useEffect)((() => {
        var OO, KO;
        mK !== (null === (OO = PO.current) || void 0 === OO ? void 0 : OO.offsetHeight) && sO(null === (KO = PO.current) || void 0 === KO ? void 0 : KO.offsetHeight)
      })), XO.isLoggedIn() ? (0, DO.jsxs)(DO.Fragment, {
        children: [(0, DO.jsxs)("div", {
          className: "LeaderboardSelectors",
          children: [(0, DO.jsx)("div", {
            className: "LeaderboardSelect",
            children: (0, DO.jsx)(dO.b, {
              options: KO.map((OO => ({
                label: OO.label,
                value: OO.value
              }))),
              value: lO,
              onChange: OO => {
                vK(OO)
              },
              controlClassName: "LBSelectClass",
              arrowClassName: "LBSelectArrow",
              menuClassName: "LBDropdownMenu"
            })
          }), (0, DO.jsx)("div", {
            className: "LeaderboardSelect",
            children: (0, DO.jsx)(dO.b, {
              options: yK.Hc.map((OO => ({
                value: OO,
                label: OO,
                className: "LBDropdownMenuItem"
              }))),
              value: CO,
              onChange: OO => {
                MO(OO.label)
              },
              controlClassName: "LBSelectClass",
              arrowClassName: "LBSelectArrow",
              menuClassName: "LBDropdownMenu"
            })
          }), LO ? (0, DO.jsx)("div", {
            className: "SeeTopText",
            onClick: () => {
              VO(!FO)
            },
            children: FO ? "See Yourself" : "See Top"
          }) : null]
        }), (0, DO.jsx)("div", {
          className: "LBTableWrapper",
          children: AO ? (0, DO.jsx)("div", {
            className: "LoaderContainer",
            children: (0, DO.jsx)(uO.e, {})
          }) : null === iK ? (0, DO.jsx)(DO.Fragment, {
            children: (0, DO.jsxs)("table", {
              className: "LBTable",
              children: [(0, DO.jsx)("thead", {
                className: "LBTableTHead",
                ref: PO,
                children: (0, DO.jsxs)("tr", {
                  children: [(0, DO.jsx)("th", {
                    className: "LBTablePlaceTH LBTableTH",
                    children: "PLACE"
                  }), (0, DO.jsx)("th", {
                    className: "LBTablePlayerTH LBTableTH",
                    children: "PLAYER"
                  }), (0, DO.jsx)("th", {
                    className: "LBTableValueTH LBTableTH",
                    children: lO.label.toUpperCase()
                  })]
                })
              }), (0, DO.jsx)("tbody", {
                children: aK.map((OO => (0, DO.jsxs)("tr", {
                  className: "LBTableTR " + (OO.name === eO ? "LBTableTRYou" : ""),
                  children: [(0, DO.jsx)("td", {
                    className: "LBTableTD",
                    children: `#${OO.place}`
                  }), (0, DO.jsx)("td", {
                    className: "LBTableTD",
                    children: (0, DO.jsx)(NO.d, {
                      text: [{
                        entityName: OO.name
                      }]
                    })
                  }), (0, DO.jsx)("td", {
                    className: "LBTableTD",
                    children: OO.stat
                  })]
                }, OO.name)))
              })]
            })
          }) : (0, DO.jsx)("div", {
            className: "LBIncreaseWrapper",
            onClick: () => {
              rK(null)
            },
            children: (0, DO.jsxs)("div", {
              className: "LBIncreaseDiv",
              children: [(0, DO.jsx)("div", {
                className: "TriangleUp"
              }), (0, DO.jsx)("div", {
                className: "LBIncreaseText",
                children: `${iK} Place${iK>1?"s":""}`
              })]
            })
          })
        })]
      }) : (0, DO.jsxs)("div", {
        className: "LBLoginDiv",
        children: [(0, DO.jsx)("div", {
          className: "LBLoginInfo",
          children: "Login to see the leaderboard"
        }), (0, DO.jsx)("div", {
          className: "LBLoginInfo",
          children: "You can login from the top left homescreen"
        })]
      })
    }
    var YO = pO(1e3),
      wO = pO(94),
      iK = pO(36),
      rK = pO(2686);
    const PO = (0, bK.memo)((function(OO) {
      let {
        show: KO,
        onClose: pO
      } = OO;
      (0, YO.c)();
      const XO = (0, CO.i)("_tasks"),
        eO = (0, CO.i)("_availableLeaderboards"),
        [hO, MO] = (0, bK.useState)({});
      XO && Object.keys(XO).length > 0 && 0 === Object.keys(hO).length && MO(XO);
      const [aK] = (0, bK.useState)({
        tasks: {},
        leaderboard: {}
      }), oO = {
        tasks: {
          Title: "Tasks",
          getIsDefined: () => !!XO && Object.keys(XO).length > 0,
          content: (0, DO.jsx)(QO, {
            tasks: XO,
            lastDisplayedTasks: hO
          })
        },
        leaderboard: {
          Title: "Leaderboard",
          getIsDefined: () => (null === eO || void 0 === eO ? void 0 : eO.length) > 0,
          content: (0, DO.jsx)(jK, {
            lbStats: eO,
            storedState: aK.leaderboard
          })
        }
      };

      function FO() {
        for (const OO in oO)
          if (oO[OO].getIsDefined()) return OO;
        return null
      }
      const [VO, LO] = (0, bK.useState)(FO());

      function zK() {
        MO({
          ...XO
        }), pO()
      }(0, bK.useEffect)((() => {
        VO || LO(FO())
      }), [FO()]), (0, vK.e)(!0, VO && KO), (0, bK.useEffect)((() => {
        KO && !VO && (console.log("CLOSE"), zK())
      }), [KO, VO]);
      const [AO, fO] = (0, bK.useState)(!1);
      return (0, bK.useEffect)((() => {
        KO && VO && !AO && fO(!0)
      }), [KO, AO, VO]), (0, bK.useEffect)((() => {
        !AO && XO && "tasks" !== VO && LO("tasks")
      }), [AO, XO, VO]), (0, DO.jsx)(DO.Fragment, {
        children: VO ? (0, DO.jsx)(rK.b, {
          className: "RetentionFeaturesWrapper",
          show: KO,
          children: (0, DO.jsxs)(lO.d, {
            close: zK,
            escDoesExit: !1,
            closeClassnameList: ["VerticalMenuScreenDiv"],
            togglePointerLock: !1,
            globallyUniqueKey: "RetentionFeaturesComponent",
            children: [(0, DO.jsxs)("div", {
              className: "VerticalMenuScreenDiv",
              children: [(0, DO.jsx)(sO, {}), (0, DO.jsxs)("div", {
                className: "MenuDiv",
                children: [(0, DO.jsx)(mK, {
                  setCategory: LO,
                  menuCategories: oO,
                  selectedCat: VO
                }), (0, DO.jsx)("div", {
                  className: "MenuCategoryContainer",
                  children: oO[VO].content
                })]
              })]
            }), (0, DO.jsx)("div", {
              className: "BottomScreenMenuWrapper",
              children: wO.featureFlags.useDiscord && (0, DO.jsx)("div", {
                className: "DiscordMenuDivDiv",
                children: (0, DO.jsx)("div", {
                  className: "DiscordMenuDiv",
                  children: (0, DO.jsx)(HO, {
                    tasks: XO
                  })
                })
              })
            })]
          })
        }) : null
      })
    }));

    function mK(OO) {
      let {
        selectedCat: KO,
        setCategory: pO,
        menuCategories: XO
      } = OO;
      return (0, DO.jsx)("div", {
        className: "MenuHeader",
        children: Object.keys(XO).map((OO => XO[OO].getIsDefined() ? (0, DO.jsx)("div", {
          className: "MenuHeaderCategory " + (OO === KO ? "SelectedHeaderCat" : "UnselectedHeaderCat"),
          onClick: () => {
            pO(OO)
          },
          children: XO[OO].Title
        }, OO) : null))
      })
    }

    function sO() {
      const OO = (0, CO.i)("currencyAmounts");
      return (0, DO.jsx)("div", {
        className: "TopScreenCurrencies",
        children: Object.keys(null !== OO && void 0 !== OO ? OO : {}).map((KO => {
          const pO = OO[KO];
          return pO.hidden ? null : (0, DO.jsxs)("div", {
            className: "TopScreenCurrencyDiv",
            children: [(0, DO.jsx)(LO.d, {
              name: pO.icon,
              className: "3x UiCurrencyIcon",
              style: {
                color: pO.iconColour
              }
            }), (0, DO.jsx)("div", {
              className: "UiCurrencyAmount",
              children: pO.amount
            })]
          }, KO)
        }))
      })
    }

    function HO(OO) {
      let {
        tasks: KO
      } = OO;
      return (0, DO.jsxs)("a", {
        className: "MenuDiscordButtonWrapper",
        href: "https://discord.gg/playbloxd",
        target: "_blank",
        rel: "noreferrer",
        children: [(0, DO.jsx)(LO.d, {
          name: "discord",
          kit: "brands",
          className: "DiscordButton",
          onClick: () => {
            iK.e.setItem("DiscordPressed", !0), hO.gameBridge.send("setServerCookie", {
              key: "joinDiscord",
              value: "true"
            }), "joinDiscord" in KO && FO.i.pl("clientTaskProgress", {
              taskId: "joinDiscord",
              progress: 1
            })
          }
        }), (0, DO.jsx)(eO.e, {})]
      })
    }
    var RO = pO(22),
      SO = pO(3764),
      JO = pO(35083),
      cK = pO(8268),
      BO = pO(3812),
      ZO = pO(149),
      GO = pO(1067),
      qK = pO(1195),
      xK = pO(2115),
      nO = pO(1051),
      WO = pO(1446),
      tK = pO(1950),
      kK = pO(1933),
      UO = pO(1693),
      OK = pO(1633),
      KK = pO(1119),
      pK = pO(1302);
    const XK = new Map;

    function bp(OO, KO) {
      const pO = KO.toLowerCase();
      for (const XO of OO)
        if (XO.toLowerCase() === pO) return !0;
      return !1
    }

    function eK(OO) {
      if (null === OO) return !0;
      const {
        visibility: KO
      } = OO;
      return "public" === KO || "unlisted" === KO || "whitelist" === KO && OO.canManage
    }

    function lK(OO, KO, pO) {
      if (pO) {
        const pO = KO.filter((KO => !bp(OO.whitelist, KO)));
        return {
          ...OO,
          whitelist: [...OO.whitelist, ...pO]
        }
      }
      return {
        ...OO,
        whitelist: OO.whitelist.filter((OO => !bp(KO, OO)))
      }
    }
    var vp = pO(2141);

    function CK(OO) {
      let {
        worldCode: KO,
        message: pO
      } = OO;
      const {
        t: XO
      } = (0, nO.D)(), {
        isTouchScreen: eO
      } = (0, RO.l)(["isTouchScreen"]), lO = wO.featureFlags.canUseInviteLinks, vK = (0, cK.i)(lO && null === pO), [CO, hO] = (0, vp.g)(), MO = (0, bK.useRef)(null);
      if (null !== pO) return (0, DO.jsxs)("div", {
        className: "WorldSocialLinkRow WorldSocialLinkRowMessage",
        children: [(0, DO.jsx)(LO.d, {
          name: "lock"
        }), (0, DO.jsx)("span", {
          children: pO
        })]
      });
      const aK = lO ? vK : KO,
        FO = eO && lO && (0, vp.b)();
      return (0, DO.jsxs)("div", {
        className: "WorldSocialLinkRow",
        children: [!lO && (0, DO.jsx)("span", {
          className: "WorldSocialCodeLabel",
          children: XO("worldSocial:worldCode")
        }), (0, DO.jsx)("input", {
          ref: MO,
          className: "WorldSocialLink",
          readOnly: !0,
          value: null !== aK && void 0 !== aK ? aK : "",
          "aria-label": XO(lO ? "worldSocial:worldLink" : "worldSocial:worldCode"),
          onFocus: OO => {
            OO.currentTarget.select()
          }
        }), (0, DO.jsxs)(oO.d, {
          className: "WorldSocialCopy",
          disabled: null === aK,
          onClick: () => {
            null !== aK && (0, vp.f)(aK, {
              useShareSheet: FO,
              onOutcome: OO => {
                if ((0, pK.e)({
                    id: "world_social.copy_link",
                    value: "copied" !== OO || lO ? OO : "code"
                  }), "copied" === OO) hO();
                else if ("failed" === OO) {
                  var KO;
                  null === (KO = MO.current) || void 0 === KO || KO.focus(), UO.b.showMessage({
                    translationKey: "partyBar:copyFailed"
                  })
                }
              }
            })
          },
          children: [(0, DO.jsx)(LO.d, {
            name: CO ? "check" : FO ? "up-from-bracket" : "copy"
          }), " ", XO(CO ? "general:copied" : FO ? "worldSocial:share" : "general:copy")]
        })]
      })
    }
    var hK = pO(918),
      DK = pO.n(hK);
    const MK = {
        unlisted: "link",
        public: "globe",
        whitelist: "user-check",
        private: "lock"
      },
      ap = ["unlisted", "public", "whitelist", "private"];

    function oK(OO) {
      let {
        visibility: KO,
        onPick: pO
      } = OO;
      const {
        t: XO
      } = (0, nO.D)(), eO = (0, bK.useRef)([]);
      return (0, DO.jsx)("div", {
        className: "WorldSocialTiles",
        role: "group",
        "aria-label": XO("worldSocial:whoCanJoin"),
        children: ap.map(((OO, bK) => {
          const lO = OO === KO;
          return (0, DO.jsxs)("button", {
            ref: OO => {
              eO.current[bK] = OO
            },
            type: "button",
            className: DK()("WorldSocialTile", {
              WorldSocialTileSelected: lO
            }),
            "aria-pressed": lO,
            tabIndex: lO ? 0 : -1,
            onKeyDown: OO => {
              ((OO, KO) => {
                const pO = "ArrowRight" === OO.key || "ArrowDown" === OO.key ? 1 : "ArrowLeft" === OO.key || "ArrowUp" === OO.key ? -1 : 0;
                var XO;
                0 !== pO && (OO.preventDefault(), null === (XO = eO.current[(KO + pO + ap.length) % ap.length]) || void 0 === XO || XO.focus())
              })(OO, bK)
            },
            onClick: () => {
              pO(OO)
            },
            children: [(0, DO.jsx)("span", {
              className: "WorldSocialTileIcon",
              children: (0, DO.jsx)(LO.d, {
                name: MK[OO]
              })
            }), (0, DO.jsxs)("span", {
              className: "WorldSocialTileText",
              children: [(0, DO.jsx)("span", {
                className: "WorldSocialTileTitle",
                children: XO(`worldSocial:${OO}`)
              }), (0, DO.jsx)("span", {
                className: "WorldSocialTileDescription",
                children: XO(`worldSocial:${OO}Description`)
              })]
            })]
          }, OO)
        }))
      })
    }
    var FK = pO(512),
      VK = pO(2111),
      LK = pO(2061),
      QK = pO(3618);

    function zp(OO, KO) {
      var pO;
      return {
        isError: !1,
        name: OO,
        ranks: [...arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : []],
        cosmetics: null !== KO && void 0 !== KO ? KO : {},
        nameColour: null !== (pO = null === KO || void 0 === KO ? void 0 : KO.nameColour) && void 0 !== pO ? pO : FK.b,
        location: {
          status: "offline"
        }
      }
    }

    function AK(OO) {
      let {
        player: KO,
        isFriend: pO = !1,
        status: XO,
        showLocation: bK = void 0 === XO,
        KK: eO,
        onSendFriendRequest: lO,
        actions: vK,
        zIndex: CO
      } = OO;
      const {
        t: hO
      } = (0, nO.D)();
      let MO, aK = XO;
      return null !== eO && void 0 !== eO && eO.on && (aK = (0, DO.jsxs)(DO.Fragment, {
        children: [null !== XO && void 0 !== XO ? XO : (0, DO.jsx)(LK.d, {
          socialPreview: KO
        }), (0, DO.jsxs)("span", {
          className: "WorldSocialCanJoin",
          children: [" \xb7 ", hO("worldSocial:canJoin")]
        })]
      })), (vK || eO) && (MO = (0, DO.jsxs)(DO.Fragment, {
        children: [vK, eO && (0, DO.jsx)("label", {
          className: "WorldSocialTick",
          children: (0, DO.jsx)(QK.c, {
            checked: eO.on,
            disabled: !1,
            ariaLabel: hO("worldSocial:letJoin", {
              playerName: KO.name
            }),
            onChange: OO => {
              eO.onChange(OO.target.checked)
            }
          })
        })]
      })), (0, DO.jsx)(VK.d, {
        playerSocialPreview: KO,
        isFriend: pO,
        hideFriendBadge: !0,
        onFriendRemoved: pO ? OO => {
          WO.e.removeFriendFromState(OO)
        } : void 0,
        status: aK,
        showLocation: bK,
        onSendFriendRequest: lO,
        opensProfileCard: !1,
        zIndex: CO,
        children: MO
      })
    }

    function fK(OO) {
      let {
        row: KO,
        KK: pO,
        canInvite: XO,
        invited: bK,
        onInvite: eO,
        zIndex: lO
      } = OO;
      const {
        t: vK
      } = (0, nO.D)(), CO = "online" === KO.place ? oO.d : oO.e;
      return (0, DO.jsx)(AK, {
        player: KO.friend,
        isFriend: !0,
        status: "here" === KO.place ? vK("worldSocial:inThisWorld") : void 0,
        showLocation: !0,
        KK: pO,
        zIndex: lO,
        actions: XO && (0, DO.jsx)(CO, {
          className: "WorldSocialInvite SmallTextLight",
          disabled: bK,
          onClick: eO,
          ariaLabel: `${vK("worldSocial:invite")} ${KO.friend.name}`,
          children: vK(bK ? "worldSocial:invited" : "worldSocial:invite")
        })
      })
    }
    var dK = pO(2174);

    function TK(OO) {
      let {
        playersHere: KO,
        exclude: pO,
        qL: XO
      } = OO;
      const {
        t: eO
      } = (0, nO.D)(), lO = (0, dK.l)(dK.i), [vK, CO] = (0, bK.useState)([]), hO = [], MO = (OO, KO) => {
        const XO = [...pO, ...hO.map((OO => OO.player.name))];
        hO.length < 3 && !bp(XO, OO.name) && hO.push({
          player: OO,
          status: KO
        })
      };
      for (const bK of KO) MO(zp(bK.name, bK.cosmetics, bK.ranks), eO("worldSocial:inThisWorld"));
      if ("loaded" === lO.state.status)
        for (const bK of lO.state.recentPlayers) bK.preview.name && !bK.preview.isError && MO({
          ...bK.preview,
          location: {
            status: "offline"
          }
        }, eO("worldSocial:playedWithYou"));
      const aK = OO => {
        CO((KO => [...KO, OO])), XO(OO).finally((() => {
          CO((KO => KO.filter((KO => KO !== OO))))
        }))
      };
      return (0, DO.jsx)(DO.Fragment, {
        children: hO.map(((OO, KO) => {
          let {
            player: pO,
            status: XO
          } = OO;
          return (0, DO.jsx)(AK, {
            zIndex: hO.length - KO,
            player: pO,
            status: XO,
            onSendFriendRequest: () => {
              aK(pO.name)
            },
            actions: (0, DO.jsx)(qK.g, {
              tooltipInner: (0, DO.jsx)(DO.Fragment, {
                children: eO("recentPlayers:addFriend")
              }),
              delayShow: 0,
              hoverOnly: !0,
              children: (0, DO.jsx)(oO.d, {
                className: "FriendRequestButton",
                disabled: vK.includes(pO.name),
                ariaLabel: `${eO("recentPlayers:addFriend")} ${pO.name}`,
                onClick: () => {
                  aK(pO.name)
                },
                children: (0, DO.jsx)(LO.d, {
                  name: "user-plus"
                })
              })
            })
          }, `suggestion:${pO.name}`)
        }))
      })
    }
    var NK = pO(1475);

    function IK(OO) {
      let {
        qL: KO
      } = OO;
      const {
        t: pO
      } = (0, nO.D)(), XO = (0, bK.useRef)(null), [eO, lO] = (0, bK.useState)(""), [vK, CO] = (0, bK.useState)(!1), hO = () => {
        const OO = eO.trim();
        "" === OO || vK || (CO(!0), KO(OO).then((OO => {
          OO && XO.current && (XO.current.value = "", lO(""))
        })).finally((() => {
          CO(!1)
        })))
      };
      return (0, DO.jsxs)("div", {
        className: "WorldSocialAddFriend",
        onKeyDown: OO => {
          OO.target === XO.current && "Escape" !== OO.key && OO.stopPropagation()
        },
        children: [(0, DO.jsx)(NK.e, {
          className: "WorldSocialAddFriendInput",
          domRef: XO,
          maxLength: 32,
          placeholderText: pO("worldSocial:addFriendPlaceholder"),
          ariaLabel: pO("worldSocial:addFriendPlaceholder"),
          stopPropagation: !1,
          onValueChange: OO => {
            lO(OO)
          },
          onEnter: hO
        }), (0, DO.jsxs)(oO.d, {
          className: "WorldSocialAddFriendButton SmallTextLight",
          disabled: vK || "" === eO.trim(),
          onClick: hO,
          children: [(0, DO.jsx)(LO.d, {
            name: "user-plus"
          }), " ", pO("socialBar:sendRequest")]
        })]
      })
    }
    const yp = new Map;

    function gp(OO) {
      const KO = yp.get(OO);
      if (!KO) return [];
      const pO = Date.now();
      for (const [XO, bK] of KO) pO - bK >= ZO.j && KO.delete(XO);
      return [...KO.keys()]
    }
    var uK = pO(1077),
      EK = pO(3791);
    const jp = ["auto", "auto_existing"];

    function YK(OO) {
      return jp.includes(OO)
    }

    function wK(OO) {
      let {
        justMade: KO,
        playerId: pO,
        lobbyName: XO,
        personalWorld: bK
      } = OO;
      return KO ? "auto" : !PK(pO) && function(OO, KO) {
        const pO = (0, uK.kb)(OO);
        return null !== KO && (0, uK.kb)(KO) === pO || (0, EK.c)().some((OO => (0, uK.kb)(OO.name) === pO))
      }(XO, bK) ? "auto_existing" : null
    }
    const ip = new Set;

    function rp(OO) {
      return `worldSocialSeen:${OO}`
    }

    function PK(OO) {
      return !OO || ip.has(OO) || !0 === iK.e.getItem(rp(OO))
    }

    function mp(OO) {
      OO && !ip.has(OO) && (ip.add(OO), iK.e.setItem(rp(OO), !0))
    }

    function sK(OO) {
      let {
        show: KO,
        onClose: pO,
        opener: XO
      } = OO;
      const {
        lobbyName: eO,
        shownLobbyName: vK
      } = (0, gK.i)("connectedGame");
      return (0, bK.useEffect)((() => {
        KO && (0, pK.e)({
          id: "world_social.open",
          value: XO
        })
      }), [KO]), (0, DO.jsx)(lO.d, {
        show: KO && null !== eO,
        close: pO,
        togglePointerLock: !1,
        className: "WorldSocialBackgroundScreen",
        globallyUniqueKey: "WorldSocialPopup",
        doGameplayStartStopOnShow: !0,
        children: KO && null !== eO && (0, DO.jsx)(HK, {
          lobbyName: eO,
          worldCode: null !== vK && void 0 !== vK ? vK : eO,
          onClose: pO
        }, eO)
      })
    }

    function HK(OO) {
      var KO;
      let {
        lobbyName: pO,
        worldCode: XO,
        onClose: eO
      } = OO;
      const {
        t: lO
      } = (0, nO.D)(), vK = (0, bK.useRef)(null), {
        settings: CO,
        loading: hO,
        answered: MO,
        change: aK,
        retry: FO
      } = function(OO) {
        const [KO, pO] = (0, bK.useState)((() => {
          var KO;
          return null !== (KO = XK.get(OO)) && void 0 !== KO ? KO : null
        })), [XO, eO] = (0, bK.useState)(!0), [lO, vK] = (0, bK.useState)((() => XK.has(OO))), CO = (0, bK.useRef)(KO);
        CO.current = KO;
        const hO = (0, bK.useRef)(0),
          DO = (0, bK.useRef)(0),
          MO = (0, bK.useRef)(!1),
          aK = (0, bK.useRef)(!0),
          oO = (0, bK.useCallback)((async () => {
            const KO = ++hO.current,
              XO = await SO.e.getSocialSettings(OO);
            aK.current && KO === hO.current && (vK(!0), eO(!1), "error" in XO || pO(XO.settings))
          }), [OO]),
          FO = (0, bK.useCallback)((() => {
            eO(!0), oO()
          }), [oO]);
        (0, bK.useEffect)((() => (aK.current = !0, XK.delete(OO), FO(), () => {
          aK.current = !1
        })), [FO, OO]);
        const VO = OO => {
          hO.current++, eO(!1), CO.current = OO, pO(OO)
        };
        return {
          settings: KO,
          loading: XO,
          answered: lO,
          retry: FO,
          change: async function(KO, pO) {
            let {
              quiet: XO = !1
            } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            const bK = CO.current;
            if (null === bK) return !1;
            VO(pO(bK)), DO.current > 0 && (MO.current = !0), DO.current++;
            const eO = await SO.e.setSocialSettings(OO, KO);
            DO.current--;
            const lO = !("error" in eO);
            if (!aK.current) return lO;
            if (XO);
            else if ("error" in eO) UO.b.showMessage({
              translationKey: eO.error
            });
            else
              for (const OO of eO.notFound) UO.b.showMessage({
                translationKey: "worldSocial:notFound",
                params: {
                  playerName: OO
                }
              });
            if (DO.current > 0) return lO;
            const vK = MO.current;
            return MO.current = !1, !vK && "settings" in eO ? VO(eO.settings) : (vK || VO(bK), oO()), lO
          }
        }
      }(pO), VO = (0, WO.m)(), QO = (0, gK.i)("players"), zK = (0, gK.i)("hiddenPlayerNames"), [AO, fO] = (0, bK.useState)([]), [dO, NO] = (0, bK.useState)([]), [IO, yK] = (0, bK.useState)(!1), EO = (0, bK.useMemo)((() => {
        var OO, KO;
        const pO = null === QO.localId ? null : null !== (OO = null === (KO = QO.byId[QO.localId]) || void 0 === KO ? void 0 : KO.name) && void 0 !== OO ? OO : null;
        return QO.ids.flatMap((OO => {
          const KO = QO.byId[OO];
          return null !== KO && void 0 !== KO && KO.name && KO.name !== pO ? [{
            name: KO.name,
            cosmetics: KO.cosmetics,
            ranks: KO.ranks
          }] : []
        }))
      }), [QO]), jK = (0, bK.useMemo)((() => function(OO, KO, pO) {
        const XO = [],
          bK = [],
          eO = [];
        for (const lO of OO) !lO.isError && lO.name && ("inGame" === lO.location.status && lO.location.inLobbyName === KO || bp(pO, lO.name) ? bK.push({
          friend: lO,
          place: "here"
        }) : "offline" === lO.location.status ? eO.push({
          friend: lO,
          place: "offline"
        }) : XO.push({
          friend: lO,
          place: "online"
        }));
        return [...XO, ...bK, ...eO]
      }(VO.friends, pO, EO.map((OO => OO.name)))), [VO.friends, pO, EO]), YO = wO.featureFlags.canSeeRealPlayerNames ? EO.filter((OO => null === (0, KK.e)(OO.name, zK))) : [], iK = null !== CO && void 0 !== CO && CO.canManage ? CO : null, rK = null !== iK, PO = null !== (KO = null === CO || void 0 === CO ? void 0 : CO.visibility) && void 0 !== KO ? KO : null, mK = "whitelist" === (null === iK || void 0 === iK ? void 0 : iK.visibility), sO = "private" === PO || "whitelist" === PO && !rK, {
        userContext: HO
      } = (0, TO.d)();
      (0, bK.useEffect)((() => {
        rK && mp(HO.whamm)
      }), [rK, HO]);
      const RO = "private" === PO && rK ? lO("worldSocial:privateLinkRow") : sO ? lO("worldSocial:ownerOnlyInvites") : null,
        cK = null === RO;
      (0, bK.useEffect)((() => sO ? void 0 : UO.b.quietFriendAdded()), [sO]), (0, bK.useEffect)((() => UO.b.quietFriendRequests()), []);
      const vp = (0, bK.useRef)(!1);
      (0, bK.useEffect)((() => {
        const OO = vK.current,
          KO = !vp.current;
        vp.current = !0;
        const pO = null === document.activeElement || document.activeElement === document.body;
        null !== OO && void 0 !== OO && OO.contains(document.activeElement) || !KO && !pO || (0, JO.d)() || null === OO || void 0 === OO || OO.focus({
          preventScroll: !0
        })
      }), [cK]), (0, bK.useEffect)((() => {
        const OO = OO => {
          "Escape" !== OO.key || null !== document.activeElement && document.activeElement !== document.body || eO()
        };
        return document.addEventListener("keydown", OO), () => {
          document.removeEventListener("keydown", OO)
        }
      }), [eO]);
      const hK = null === CO && !MO,
        DK = (hO || VO.loading) && 0 === VO.friends.length,
        MK = VO.friends.flatMap((OO => OO.name ? [OO.name] : [])),
        ap = AO.filter((OO => !bp(MK, OO))),
        FK = jK.length + 3,
        VK = ap.length + FK,
        LK = IO ? VO.requests : VO.requests.slice(0, 1),
        QK = async function(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          for (const pO of function(OO, KO) {
              const pO = [];
              for (let XO = 0; XO < OO.length; XO += KO) pO.push(OO.slice(XO, XO + KO));
              return pO
            }(OO, BO.A)) {
            if (!await aK({
                whitelistAdd: pO
              }, (OO => lK(OO, pO, !0)), {
                quiet: KO
              })) return !1
          }
          return !0
        }, dK = async OO => {
          if (OO === PO) return;
          (0, pK.e)({
            id: "world_social.set_mode",
            value: OO
          });
          const KO = [...gp(pO), ...dO],
            XO = "whitelist" === OO && CO ? function(OO, KO, pO) {
              const XO = [],
                bK = OO.flatMap((OO => "here" === OO.place ? [OO.friend.name] : []));
              for (const eO of [...bK, ...KO]) bp(XO, eO) || bp(pO, eO) || XO.push(eO);
              return XO
            }(jK, KO, CO.whitelist) : [];
          await aK({
            setVisibility: OO
          }, (KO => ({
            ...KO,
            visibility: OO
          }))) && await QK(XO)
        }, NK = OO => {
          if (mK && iK) return {
            on: bp(iK.whitelist, OO),
            onChange: KO => {
              (0, pK.e)({
                id: "world_social.whitelist_toggle",
                value: KO ? "on" : "off"
              }), aK(KO ? {
                whitelistAdd: [OO]
              } : {
                whitelistRemove: OO
              }, (pO => lK(pO, [OO], KO)))
            }
          }
        }, uK = async OO => {
          (0, pK.e)({
            id: "world_social.invite",
            value: "friend"
          });
          const KO = () => {
            NO((KO => KO.filter((KO => KO !== OO))))
          };
          NO((KO => [...KO, OO]));
          const XO = function(OO, KO) {
            return null === OO || void 0 === OO || !OO.canManage || bp(OO.whitelist, KO) ? "none" : "whitelist" === OO.visibility ? "required" : "quiet"
          }(CO, OO);
          if ("none" !== XO) {
            const pO = QK([OO], "quiet" === XO);
            if ("required" === XO && !await pO) return void KO()
          }
          await (0, tK.j)(OO, "game", {
            announceSent: !1,
            source: "world_social"
          }) ? (! function(OO, KO) {
            var pO;
            const XO = null !== (pO = yp.get(OO)) && void 0 !== pO ? pO : new Map;
            XO.set(KO, Date.now()), yp.set(OO, XO)
          }(pO, OO), setTimeout(KO, ZO.n)) : KO()
        }, EK = async (OO, KO) => {
          (0, pK.e)({
            id: "world_social.add_friend",
            value: KO
          });
          const pO = await (0, kK.f)(OO, "world_social");
          return (0, kK.d)(pO, OO, {
            announceSent: !1
          }), "failed" !== pO.kind && ("sent" === pO.kind && fO((KO => bp(KO, OO) ? KO : [...KO, OO])), mK && await QK([OO]), !0)
        };
      return (0, DO.jsxs)("div", {
        ref: vK,
        className: "WorldSocialPopup AnimFadeInScaleUp",
        tabIndex: -1,
        onKeyDown: OO => {
          OO.target === OO.currentTarget && " " === OO.key && OO.preventDefault()
        },
        role: "dialog",
        "aria-modal": "true",
        "aria-labelledby": "WorldSocialTitle",
        children: [(0, DO.jsxs)("div", {
          className: "WorldSocialHeader",
          children: [(0, DO.jsx)("h2", {
            id: "WorldSocialTitle",
            className: "WorldSocialTitle SmallTextBold",
            children: lO("worldSocial:title")
          }), (0, DO.jsx)(oO.i, {
            className: "WorldSocialClose",
            onClick: eO
          })]
        }), hK && (0, DO.jsx)("div", {
          className: "WorldSocialLoading",
          children: (0, DO.jsx)(uO.e, {})
        }), !hK && (0, DO.jsxs)(DO.Fragment, {
          children: [(0, DO.jsx)(CK, {
            worldCode: XO,
            message: RO
          }), null === CO && !hO && (0, DO.jsx)("button", {
            type: "button",
            className: "WorldSocialLoadFailed",
            onClick: FO,
            children: lO("worldSocial:loadFailed")
          }), rK && null !== PO && (0, DO.jsx)(oK, {
            visibility: PO,
            onPick: OO => {
              dK(OO)
            }
          }), VO.requests.length > 0 && (0, DO.jsxs)("div", {
            className: "WorldSocialSection",
            children: [(0, DO.jsx)(xK.b, {
              label: (0, DO.jsxs)(DO.Fragment, {
                children: [(0, DO.jsx)(LO.d, {
                  name: OK.h
                }), " ", lO("socialBar:requests")]
              }),
              meta: (0, DO.jsxs)(DO.Fragment, {
                children: [VO.requests.length, VO.requests.length === GO.m && (0, DO.jsx)("span", {
                  className: "SocialSectionTitleLimit",
                  children: lO("socialBar:limitReached")
                }), !IO && VO.requests.length > 1 && (0, DO.jsx)("button", {
                  type: "button",
                  className: "WorldSocialMoreRequests",
                  onClick: () => {
                    yK(!0)
                  },
                  children: lO("worldSocial:moreRequests", {
                    count: VO.requests.length - 1
                  })
                })]
              })
            }), (0, DO.jsx)("div", {
              className: "PlayerRows",
              children: LK.map(((OO, KO) => (0, DO.jsx)(AK, {
                zIndex: LK.length - KO,
                player: OO,
                actions: (0, DO.jsxs)(DO.Fragment, {
                  children: [(0, DO.jsx)(qK.g, {
                    tooltipInner: (0, DO.jsx)(DO.Fragment, {
                      children: lO("general:accept")
                    }),
                    delayShow: 0,
                    hoverOnly: !0,
                    children: (0, DO.jsx)(oO.d, {
                      className: "FriendRequestButton",
                      ariaLabel: `${lO("general:accept")} ${OO.name}`,
                      analyticsClick: {
                        id: "social.accept_friend_request",
                        value: "world_social"
                      },
                      onClick: () => {
                        (0, kK.e)(OO.name, !0, {
                          source: "world_social"
                        })
                      },
                      children: (0, DO.jsx)(LO.d, {
                        name: "check"
                      })
                    })
                  }), (0, DO.jsx)(qK.g, {
                    tooltipInner: (0, DO.jsx)(DO.Fragment, {
                      children: lO("general:decline")
                    }),
                    delayShow: 0,
                    hoverOnly: !0,
                    children: (0, DO.jsx)(oO.e, {
                      className: "FriendRequestButton",
                      ariaLabel: `${lO("general:decline")} ${OO.name}`,
                      analyticsClick: {
                        id: "social.decline_friend_request",
                        value: "world_social"
                      },
                      onClick: () => {
                        (0, kK.e)(OO.name, !1, {
                          source: "world_social"
                        })
                      },
                      children: (0, DO.jsx)(LO.d, {
                        name: "xmark"
                      })
                    })
                  })]
                })
              }, `incoming:${OO.name}`)))
            })]
          }), (0, DO.jsxs)("div", {
            className: "WorldSocialSection",
            children: [(0, DO.jsx)(xK.b, {
              label: (0, DO.jsxs)(DO.Fragment, {
                children: [(0, DO.jsx)(LO.d, {
                  name: OK.e
                }), " ", lO("socialBar:friends")]
              }),
              meta: VO.loaded && !sO ? VO.friends.length : void 0
            }), (0, DO.jsx)(IK, {
              qL: OO => EK(OO, "field")
            }), DK && (0, DO.jsx)("div", {
              className: "WorldSocialLoading",
              children: (0, DO.jsx)(uO.e, {})
            }), !DK && (0, DO.jsxs)(DO.Fragment, {
              children: [(0, DO.jsxs)("div", {
                className: "PlayerRows",
                children: [ap.map(((OO, KO) => (0, DO.jsx)(AK, {
                  zIndex: VK - KO,
                  player: zp(OO, null),
                  status: lO("worldSocial:requestSent"),
                  KK: NK(OO)
                }, `request:${OO}`))), !sO && jK.map(((OO, KO) => (0, DO.jsx)(fK, {
                  zIndex: FK - KO,
                  row: OO,
                  KK: NK(OO.friend.name),
                  canInvite: eK(CO) && "here" !== OO.place,
                  invited: dO.includes(OO.friend.name),
                  onInvite: () => {
                    uK(OO.friend.name)
                  }
                }, OO.friend.name))), VO.loaded && 0 === VO.friends.length && (0, DO.jsx)(TK, {
                  playersHere: YO,
                  exclude: AO,
                  qL: OO => EK(OO, "suggestion")
                })]
              }), mK && VO.loaded && 0 === VO.friends.length && 0 === ap.length && (0, DO.jsx)("div", {
                className: "WorldSocialEmpty",
                children: lO("worldSocial:whitelistNoFriends")
              })]
            })]
          })]
        })]
      })
    }
    var RK = pO(35037),
      SK = pO(1977);
    const JK = RK.f;

    function cp(OO) {
      let {
        show: KO,
        onClose: pO,
        option: XO
      } = OO;
      ! function() {
        const {
          gameEntrySource: OO,
          loadingOverlayVisible: KO
        } = (0, RO.l)(["gameEntrySource", "loadingOverlayVisible"]), {
          userContext: pO
        } = (0, TO.d)(), XO = (0, gK.e)("connectedGame", (OO => (0, SK.c)(OO) ? OO.lobbyName : null)), eO = (0, gK.i)("localPlayerAlive"), lO = (0, gK.e)("players", (OO => null !== OO.localId && void 0 !== OO.byId[OO.localId])), vK = (0, bK.useRef)(null);
        (0, bK.useEffect)((() => {
          if (null === XO || !(!KO && eO && lO)) return;
          const bK = pO.whamm,
            CO = wK({
              justMade: "worldCreation" === OO,
              playerId: bK,
              lobbyName: XO,
              personalWorld: pO.getPersonalWorldLobbyName()
            });
          if (null === CO) return;
          const DO = () => {
            vK.current === XO || ZK(XO) || (vK.current = XO, function(OO, KO, pO, XO) {
              SO.e.getSocialSettings(OO).then((bK => {
                if (!("error" in bK)) return bK.settings.canManage ? void
                function(OO, KO) {
                  if (!(0, JO.d)()) return void KO();
                  let pO = 0;
                  const XO = () => {
                    pO = (0, JO.d)() ? 0 : pO + 1, pO >= 2 || hO.gameBridge.latest("connectedGame").lobbyName !== OO ? KO() : setTimeout(XO, qp)
                  };
                  setTimeout(XO, qp)
                }(OO, (() => {
                  XO();
                  const eO = hO.gameBridge.latest("connectedGame").lobbyName === OO,
                    lO = RO.d.get("loadingOverlayVisible") || null !== RO.d.get("openInGameMenuName") || null !== RO.d.get("openEverythingMenuName"),
                    vK = "auto_existing" === KO && PK(pO);
                  !eO || lO || ZK(OO) || vK || (GK(OO), mp(pO), function(OO, KO) {
                    XK.set(OO, KO)
                  }(OO, bK.settings), FO.i.pl("toggleMenu", `inviteLink|${KO}`))
                })): (GK(OO), void XO());
                XO()
              }))
            }(XO, CO, bK, (() => {
              vK.current === XO && (vK.current = null)
            })))
          };
          let MO = setTimeout((() => {
            (0, RK.d)() ? MO = setTimeout(DO, JK): DO()
          }), JK + 250);
          return () => {
            clearTimeout(MO)
          }
        }), [OO, KO, XO, eO, lO, pO])
      }();
      return (0, gK.e)("connectedGame", SK.c) ? (0, DO.jsx)(sK, {
        show: KO,
        onClose: pO,
        opener: YK(XO) ? XO : "icon"
      }) : (0, DO.jsx)(cK.d, {
        show: KO,
        onClose: pO
      })
    }
    const BK = new Set;

    function ZK(OO) {
      return BK.has(OO) || !!iK.h.getItem(`worldSocialShown:${OO}`)
    }

    function GK(OO) {
      BK.add(OO), iK.h.setItem(`worldSocialShown:${OO}`, !0)
    }
    const qp = 500;
    var xp = pO(35255),
      nK = pO(2446),
      WK = pO(2454),
      tp = pO(1591);
    const kp = (OO, KO) => {
        (0, bK.useEffect)((() => {
          setTimeout((() => {
            OO && OO.current && OO.current.focus()
          }), 1)
        }), [KO])
      },
      UK = (0, bK.memo)((function(OO) {
        let {
          isInputActive: KO,
          onClose: pO,
          onChange: XO,
          textAreaRef: bK,
          fontSize: eO,
          lineHeight: lO,
          currText: vK
        } = OO;
        return (0, DO.jsxs)("div", {
          className: "WriteOnBoardWrapper",
          children: [(0, DO.jsx)("img", {
            src: `${nK.c.getTexture("board_full",WK.g.BLOCK).url}`,
            alt: "Board",
            className: "WriteOnBoardImg"
          }), (0, DO.jsx)("textarea", {
            className: "WriteOnBoardTextArea",
            value: vK,
            ref: bK,
            style: {
              fontSize: `${eO}rem`,
              lineHeight: `${lO}rem`
            },
            onKeyDown: OO => {
              var KO;
              "Escape" !== OO.key && (OO.stopPropagation(), "Tab" === OO.key && function(OO) {
                OO.preventDefault();
                const KO = OO.target,
                  {
                    value: pO
                  } = KO;
                let XO = KO.selectionStart,
                  bK = KO.selectionEnd,
                  eO = pO.slice(XO, bK);
                if (!eO.includes("\n") && !OO.shiftKey) return void document.execCommand("insertText", !1, "\t");
                for (; XO > 0 && "\n" !== pO[XO - 1];) XO--;
                const lO = "\n" === pO[bK - 1];
                lO && bK--;
                eO = pO.slice(XO, bK);
                const vK = eO.split("\n").map((KO => OO.shiftKey ? KO.replace(/^\t/, "") : "\t" + KO)).join("\n");
                if (OO.shiftKey && pO.slice(XO, bK) === vK) return;
                let {
                  selectionStart: CO
                } = KO;
                KO.setSelectionRange(XO, bK), CO > XO && (!OO.shiftKey || "\t" === eO[0]) && (CO += OO.shiftKey ? -1 : 1);
                bK = XO + vK.length + (lO ? 1 : 0), document.execCommand("insertText", !1, vK), KO.setSelectionRange(CO, bK)
              }(OO), /^F\d+$/i.test(OO.code) && null !== (KO = tp.s.OpenCodeEditor) && void 0 !== KO && KO.includes(OO.code) && pO())
            },
            spellCheck: "false",
            autoComplete: "off",
            onChange: XO
          })]
        })
      }));

    function Op(OO) {
      return 1.3 * OO
    }
    var Kp = pO(1479);
    const pp = (0, bK.memo)((function(OO) {
        let {
          show: KO,
          onOpen: pO,
          onClose: XO
        } = OO;
        const [eO, vK] = (0, bK.useState)(null), [CO, MO] = (0, bK.useState)(""), [aK, FO] = (0, bK.useState)(0), [VO, LO] = (0, bK.useState)(null), [QO, zK] = (0, bK.useState)({
          text: "",
          textSize: 0
        }), AO = (OO, KO) => VO ? (0, xp.m)(OO, KO, VO.width, VO.height) : (0, xp.f)(OO, KO), fO = OO => {
          MO(AO(CO, OO)), FO(OO), iK.e.setItem("lastBoardTextSize", OO)
        }, dO = () => {
          XO(), VO && CO === QO.text && aK === QO.textSize || hO.gameBridge.send("writeOnBoard", {
            pos: eO,
            text: CO,
            textSize: aK
          })
        };
        (0, gK.b)("boardEditRequested", (OO => {
          var bK, eO;
          if (!wO.featureFlags.canSeePlayerWrittenText) return;
          if (null === OO) return vK(null), void(KO && XO());
          const {
            pos: lO,
            noticeboardSpan: CO,
            text: hO
          } = OO;
          vK(lO), LO(CO), MO(hO);
          const DO = null !== (bK = null !== (eO = OO.textSize) && void 0 !== eO ? eO : iK.e.getItem("lastBoardTextSize")) && void 0 !== bK ? bK : 0;
          FO(DO), zK({
            text: hO,
            textSize: DO
          }), iK.e.setItem("lastBoardTextSize", DO), pO()
        }));
        const TO = (0, bK.useRef)(null);
        kp(TO, KO), (0, Kp.q)(TO, {
          kind: "sign",
          submit: dO
        });
        const NO = function(OO, KO) {
            const pO = xp.e[OO];
            if (!KO) return pO.uiFontSize;
            const {
              numLines: XO,
              charsPerLine: bK
            } = (0, xp.t)(KO.width, KO.height, OO);
            return pO.uiFontSize * Math.min(pO.charsPerLine / bK, pO.numLines / XO)
          }(aK, VO),
          IO = Op(NO);
        return (0, DO.jsxs)(lO.d, {
          className: "WriteOnBoardBg",
          close: dO,
          escDoesExit: !0,
          show: KO,
          togglePointerLock: !1,
          globallyUniqueKey: "WriteOnSignComp",
          children: [(0, DO.jsx)(UK, {
            isInputActive: () => KO,
            onClose: dO,
            onChange: OO => {
              MO(AO(OO.target.value, aK))
            },
            textAreaRef: TO,
            fontSize: NO,
            lineHeight: IO,
            currText: CO
          }), (0, DO.jsx)("div", {
            className: "WriteOnBoardTextSizeHeader SmallTextBold",
            children: "Text Size"
          }), (0, DO.jsxs)("div", {
            className: "WriteOnBoardTextSizeButtons",
            children: [(0, DO.jsx)(oO.d, {
              className: "WriteOnBoardTextSizeButton",
              onClick: () => {
                fO(0)
              },
              disabled: 0 === aK,
              children: "Small"
            }), (0, DO.jsx)(oO.d, {
              className: "WriteOnBoardTextSizeButton",
              onClick: () => {
                fO(1)
              },
              disabled: 1 === aK,
              children: "Medium"
            }), (0, DO.jsx)(oO.d, {
              className: "WriteOnBoardTextSizeButton",
              onClick: () => {
                fO(2)
              },
              disabled: 2 === aK,
              children: "Large"
            })]
          })]
        })
      })),
      Xp = (0, bK.memo)((function(OO) {
        let {
          show: KO,
          onOpen: pO,
          onClose: XO
        } = OO;
        const [eO, vK] = (0, bK.useState)(""), CO = () => {
          XO(), hO.gameBridge.send("writeNameTag", eO)
        };
        (0, IO.f)("EditNameTag", (OO => {
          wO.featureFlags.canSeePlayerWrittenText && null !== OO && (vK(OO), pO())
        }));
        const MO = (0, bK.useRef)(null);
        kp(MO, KO), (0, Kp.q)(MO, {
          kind: "nameTag",
          submit: CO
        });
        const aK = xp.E.nameTag.uiFontSize,
          FO = Op(aK);
        return (0, DO.jsxs)(lO.d, {
          className: "WriteOnBoardBg",
          close: CO,
          escDoesExit: !0,
          show: KO,
          togglePointerLock: !1,
          globallyUniqueKey: "WriteOnSignComp",
          children: [(0, DO.jsx)("div", {
            className: "NameTagTrim",
            children: (0, DO.jsx)(UK, {
              isInputActive: () => KO,
              onClose: CO,
              onChange: OO => {
                const KO = OO.target.value.replaceAll("\n", "");
                vK((0, xp.p)(KO, "nameTag"))
              },
              textAreaRef: MO,
              fontSize: aK,
              lineHeight: FO,
              currText: eO
            })
          }), (0, DO.jsx)(oO.d, {
            onClick: CO,
            className: "WriteOnNameTagCloseButton",
            children: "Finish"
          })]
        })
      })),
      bX = (0, bK.memo)((function(OO) {
        let {
          show: KO,
          onOpen: pO,
          onClose: XO
        } = OO;
        const [eO, vK] = (0, bK.useState)(""), [CO, MO] = (0, bK.useState)(0), [aK, FO] = (0, bK.useState)(!1), [VO, LO] = (0, bK.useState)(["", "", "", "", "", "", "", "", "", ""]), [QO, zK] = (0, bK.useState)("Title"), [AO, fO] = (0, bK.useState)(!0), [dO, TO] = (0, bK.useState)(!1);
        (0, IO.f)("EditBook", (OO => {
          let {
            pages: KO,
            title: XO,
            isPublished: bK
          } = OO;
          var eO;
          wO.featureFlags.canSeePlayerWrittenText && (null !== KO ? (LO(KO), vK(null !== (eO = KO[0]) && void 0 !== eO ? eO : ""), zK(XO), MO(0), FO(!1), fO(!bK), TO(!1), pO()) : LO(["", "", "", "", "", "", "", "", "", ""]))
        }));
        const NO = (0, bK.useRef)(null),
          yK = (0, bK.useRef)(null);
        kp(NO, KO), (0, Kp.q)(NO, {
          kind: "book"
        }), (0, Kp.q)(yK, {
          kind: "jG"
        });
        const gK = xp.E.book.uiFontSize,
          uO = Op(gK),
          EO = KO ? nK.c.getTexture("book_page", WK.g.ITEM).url : void 0,
          jK = () => {
            (AO || dO) && hO.gameBridge.send("writeBook", {
              pages: [...VO],
              title: QO,
              published: !AO && dO
            })
          },
          YO = OO => {
            aK && (VO[CO] = eO, FO(!1)), vK(VO[OO]), MO(OO)
          };
        return (0, DO.jsxs)(lO.d, {
          className: "WriteOnBoardBg",
          close: () => {
            XO(), VO[CO] = eO, jK()
          },
          escDoesExit: !0,
          show: KO,
          togglePointerLock: !1,
          globallyUniqueKey: "WriteOnBookComp",
          children: [(0, DO.jsxs)("div", {
            className: "WriteOnBookWrapper",
            children: [(0, DO.jsx)("textarea", {
              className: "BookTitleTextArea SmallTextLight",
              value: QO,
              ref: yK,
              style: {
                fontSize: "2.5rem",
                lineHeight: `${uO}rem`
              },
              onKeyDown: OO => {
                AO && OO.stopPropagation()
              },
              spellCheck: "false",
              autoComplete: "off",
              onChange: OO => {
                let KO = OO.target.value;
                KO = (0, xp.p)(KO, "jG"), zK(KO)
              },
              readOnly: !AO
            }), (0, DO.jsx)("img", {
              src: EO,
              alt: "book_page",
              className: "WriteOnBookPageImg"
            }), (0, DO.jsx)("div", {
              className: "BookTextAreaPadding",
              children: (0, DO.jsx)("textarea", {
                className: "WriteOnBookPageTextArea",
                value: eO,
                ref: NO,
                style: {
                  fontSize: `${gK}rem`,
                  lineHeight: `${uO}rem`
                },
                onKeyDown: OO => {
                  AO && OO.stopPropagation()
                },
                spellCheck: "false",
                autoComplete: "off",
                onChange: OO => {
                  const KO = OO.target.value;
                  vK((0, xp.p)(KO, "book")), FO(!0)
                },
                readOnly: !AO
              })
            })]
          }), (0, DO.jsxs)("div", {
            className: "BookNavigationWrapper",
            children: [(0, DO.jsx)(oO.d, {
              disabled: 0 === CO,
              onClick: () => {
                YO(CO - 1)
              },
              className: "BookNavButton",
              children: "<"
            }), (0, DO.jsx)("div", {
              style: {
                width: "2rem"
              }
            }), (0, DO.jsx)(oO.d, {
              disabled: 9 === CO,
              onClick: () => {
                YO(CO + 1)
              },
              className: "BookNavButton",
              children: ">"
            }), (0, DO.jsx)("div", {
              style: {
                width: "2rem"
              }
            }), (0, DO.jsx)(oO.d, {
              onClick: () => {
                fO(!AO), TO(!0)
              },
              className: "BookNavButton",
              children: AO ? "Publish" : "Edit"
            })]
          })]
        })
      }));
    var ep = pO(35139),
      lp = pO(7762),
      vX = pO(1225),
      Cp = pO(1546);

    function hp(OO) {
      let {
        show: KO,
        buttons: pO
      } = OO;
      const {
        t: XO
      } = (0, nO.D)(), eO = (0, bK.useRef)(null);
      return (0, bK.useEffect)((() => {
        var OO, pO;
        const XO = KO ? (0, ep.B)() : null;
        if (!XO || !(0, vX.h)()) return;
        const bK = (0, ep.m)().findIndex((OO => OO.id === XO));
        (0, lp.m)(null !== (OO = null === (pO = eO.current) || void 0 === pO ? void 0 : pO.children[bK]) && void 0 !== OO ? OO : null)
      }), [KO]), 0 === pO.length ? null : (0, DO.jsx)("div", {
        ref: eO,
        className: "ClientGameInventoryButtons",
        onPointerDown: OO => {
          OO.stopPropagation()
        },
        onPointerUp: OO => {
          OO.stopPropagation()
        },
        children: pO.map((OO => {
          const KO = XO(OO.labelKey);
          return (0, DO.jsxs)(oO.m, {
            className: OO.className,
            disabled: OO.disabled,
            onClick: () => {
              (0, ep.s)(OO)
            },
            ariaLabel: OO.iconOnly ? KO : void 0,
            title: OO.iconOnly ? KO : void 0,
            children: [OO.icon && (0, DO.jsxs)("div", {
              className: "ClientGameInventoryButtonIcon",
              children: ["item" === OO.icon.kind && (0, DO.jsx)(Cp.b, {
                itemName: OO.icon.name,
                amount: 0
              }), "image" === OO.icon.kind && (0, DO.jsx)("img", {
                src: OO.icon.src,
                alt: "",
                draggable: !1
              }), "icon" === OO.icon.kind && (0, DO.jsx)(LO.d, {
                name: OO.icon.name
              })]
            }), !OO.iconOnly && KO]
          }, OO.id)
        }))
      })
    }
    var Dp = pO(35259),
      Mp = pO(2204),
      aX = pO(8330),
      op = pO(35064),
      Fp = pO(35058);
    let Vp = null;
    window.setShowInventoryAdsOverride = OO => {
      Vp = OO
    };
    const Lp = 24e4;
    var Qp = pO(1548);

    function zX(OO) {
      var KO;
      let {
        draggedInfo: {
          name: pO,
          attributes: XO,
          amount: bK
        },
        toAddRef: eO
      } = OO;
      return (0, DO.jsx)("div", {
        className: "DraggedInvenItem",
        ref: eO,
        children: (0, DO.jsx)(Cp.b, {
          itemName: pO,
          amount: bK,
          enchantmentTier: null === XO || void 0 === XO || null === (KO = XO.customAttributes) || void 0 === KO ? void 0 : KO.enchantmentTier,
          bar: (0, Qp.j)(XO)
        })
      })
    }

    function Ap(OO) {
      let {
        className: KO = "",
        displayInfo: pO,
        domRef: XO
      } = OO;
      return (0, DO.jsxs)("div", {
        className: `InvenHoveredItemInfo SmallTextBold ${KO}`,
        ref: XO,
        children: [(0, DO.jsx)(NO.d, {
          text: (0, yK.ob)(pO.name, {
            fontStyle: pO.fontStyle
          })
        }), (0, DO.jsx)("div", {
          className: "InvenHoveredItemInfoDescription",
          children: (0, DO.jsx)(NO.d, {
            text: pO.desc
          })
        })]
      })
    }

    function fp(OO) {
      let {
        info: KO,
        draggedInfo: pO
      } = OO;
      const XO = (0, bK.useRef)(null);
      return (0, bK.useLayoutEffect)((() => {
        const OO = XO.current,
          {
            left: pO,
            top: bK
          } = function(OO, KO, pO, XO) {
            const bK = XO.left * pO.width / 100 + 4,
              eO = pO.width - XO.right * pO.width / 100 - 4 - KO.width,
              lO = XO.top * pO.height / 100 + 4,
              vK = pO.height - 4 - KO.height;
            return {
              left: Math.max(bK, Math.min(OO.x - KO.width / 2, eO)),
              top: Math.max(lO, Math.min(OO.y - 48 - KO.height, vK))
            }
          }({
            x: KO.initTouchX,
            y: KO.initTouchY
          }, {
            width: OO.offsetWidth,
            height: OO.offsetHeight
          }, {
            width: window.innerWidth,
            height: window.innerHeight
          }, RO.d.get("notchSize"));
        OO.style.left = `${pO}px`, OO.style.top = `${bK}px`
      }), [KO]), (0, DO.jsxs)("div", {
        className: "LongHoldSplitInfoUI SmallTextBold",
        ref: XO,
        children: [(0, DO.jsx)("div", {
          className: "LongHoldSplitInfoUIInner",
          style: {
            width: pO.amount / KO.maxAmount * 100 + "%"
          }
        }), (0, DO.jsxs)("div", {
          className: "LongHoldSplitInfoUIText",
          children: [pO.amount, "/", KO.maxAmount]
        })]
      })
    }
    var dp = pO(171);
    const Tp = (0, bK.memo)((function(OO) {
      let {
        show: KO,
        onOpen: pO,
        onClose: XO
      } = OO;
      const eO = (0, bK.useRef)({
          pos: null
        }),
        [vK, CO] = (0, bK.useState)([0, 0, 0, 0]),
        {
          userContext: MO
        } = (0, TO.d)();
      (0, gK.b)("ironChestOpenRequested", (OO => {
        let {
          pos: KO,
          ownerDbId: XO,
          cachedPasskey: bK
        } = OO;
        if (eO.current.pos = KO, XO !== MO.whamm) return null !== bK ? (CO(bK), void aK(bK)) : void pO();
        aK(vK)
      })), (0, gK.b)("localEffectUpdated", (OO => {
        "Thief" === OO && XO()
      }));
      const aK = OO => {
        const {
          pos: KO
        } = eO.current;
        hO.gameBridge.send("openIronChest", {
          pos: KO,
          pC: OO
        })
      };
      return (0, DO.jsx)(lO.d, {
        className: "IronChestPasskeyInputScreenOuter",
        close: XO,
        escDoesExit: !0,
        show: KO,
        togglePointerLock: !1,
        globallyUniqueKey: "IronChestPasskeyInputScreen",
        children: (0, DO.jsx)("div", {
          className: "IronChestPasskeyInputScreen",
          children: (0, DO.jsx)(Np, {
            pC: vK,
            onPasskeyUpdated: CO,
            confirmText: "ironChest:tryUnlock",
            onConfirm: () => {
              aK(vK)
            }
          })
        })
      })
    }));

    function Np(OO) {
      let {
        className: KO = "",
        pC: pO,
        onPasskeyUpdated: XO,
        confirmText: bK,
        onConfirm: eO
      } = OO;
      const {
        t: lO
      } = (0, nO.D)();
      return (0, DO.jsxs)("div", {
        className: `${KO} IronChestPasskeyInput`,
        children: [(0, DO.jsx)("div", {
          className: "SmallTextBold IronChestPasskeyInputTitle",
          children: lO("ironChest:passkeyInputTitle")
        }), (0, DO.jsx)("div", {
          className: "IronChestPasskeyInputRow",
          children: new Array(dp.h.ironChestPasskeyLength).fill(0).map(((OO, KO) => (0, DO.jsx)(Ip, {
            digit: pO[KO],
            onPasskeyDigitUpdated: OO => {
              const bK = [...pO];
              bK[KO] = OO, XO(bK)
            }
          }, KO)))
        }), (0, DO.jsx)(oO.m, {
          className: "IronChestPasskeyInputConfirmButton",
          onClick: eO,
          children: lO(bK)
        })]
      })
    }

    function Ip(OO) {
      let {
        digit: KO,
        onPasskeyDigitUpdated: pO
      } = OO;
      return (0, DO.jsx)("div", {
        className: "IronChestPasskeyDigitInputWrapper",
        children: (0, DO.jsxs)("div", {
          className: "IronChestPasskeyDigitInput",
          children: [(0, DO.jsx)(oO.m, {
            className: "IronChestPasskeyChangeDigitButton",
            onClick: () => {
              pO(yK.e.mod(KO + 1, 10))
            },
            children: (0, DO.jsx)(LO.d, {
              name: "angle-up"
            })
          }), (0, DO.jsx)("div", {
            className: "SmallTextBold IronChestPasskeyDigit",
            children: KO
          }), (0, DO.jsx)(oO.m, {
            className: "IronChestPasskeyChangeDigitButton",
            onClick: () => {
              pO(yK.e.mod(KO - 1, 10))
            },
            children: (0, DO.jsx)(LO.d, {
              name: "angle-down"
            })
          })]
        })
      })
    }
    var yX = pO(8321),
      gX = pO(35295),
      upO = pO(35049);

    function Ep(OO) {
      let {
        specialItemInfo: KO,
        setHovered: pO,
        pointerDown: XO,
        pointerUp: eO,
        enchantingTablePosition: lO,
        enchantingTableBlockName: vK
      } = OO;
      const {
        t: MO
      } = (0, nO.D)(), [aK, FO] = (0, bK.useState)(null), [VO, LO] = (0, bK.useState)(null), QO = (0, CO.i)("auraPerLevel"), zK = Math.floor((0, gK.i)("aura") / QO);
      (0, bK.useEffect)((() => {
        if (!KO) return void FO(null);
        let OO = !0;
        return hO.gameBridge.query("enchantingOffer", {
          slot: KO.idx,
          name: KO.name,
          blockName: vK
        }).then((pO => {
          var XO, bK;
          let {
            perks: eO,
            options: lO
          } = pO;
          if (!OO) return;
          const vK = {
            isEnchantable: eO.length > 0,
            possibleEnchantments: eO,
            options: lO.map((OO => {
              let {
                level: KO,
                odds: pO
              } = OO;
              return {
                level: KO,
                possibilities: Object.fromEntries(pO.map(((OO, KO) => [`Tier ${KO+1}`, OO])))
              }
            })),
            isAlreadyEnchanted: eO.length > 0 && void 0 !== (null === (XO = KO.attributes) || void 0 === XO || null === (bK = XO.customAttributes) || void 0 === bK ? void 0 : bK.enchantmentTier)
          };
          FO(vK), (OO => {
            const KO = OO.options.map((OO => Object.entries(OO.possibilities).map((OO => {
              let [KO, pO] = OO;
              return {
                str: `${KO}: ${pO>0?pO<.01?pO.toPrecision(1):pO.toFixed(2):0}%\n`,
                style: {
                  color: yK.hb[KO]
                }
              }
            }))));
            LO(KO)
          })(vK)
        })), () => {
          OO = !1
        }
      }), [KO, lO, vK]);
      const AO = [];
      for (let bK = 0; bK < gX.c; bK++) {
        const OO = null === aK || void 0 === aK ? void 0 : aK.options[bK],
          XO = !OO || OO.level > zK;
        AO.push((0, DO.jsx)(oO.d, {
          className: "EnchantmentButton",
          onPointerEnter: OO ? OO => null === pO || void 0 === pO ? void 0 : pO()(!0, {
            name: "",
            desc: VO[bK]
          }, OO) : void 0,
          onPointerLeave: OO ? () => null === pO || void 0 === pO ? void 0 : pO()(!1) : void 0,
          onClick: XO ? void 0 : () => {
            hO.gameBridge.send("enchantItem", {
              slot: KO.idx,
              level: OO.level,
              tablePos: lO
            }), FO(null)
          },
          disabled: XO,
          children: OO ? (0, DO.jsxs)(DO.Fragment, {
            children: [(0, DO.jsxs)("h1", {
              className: "EnchantmentLevels",
              children: [(0, DO.jsxs)("span", {
                className: "EnchantmentLevelsCost",
                children: [MO("enchantments:cost"), ": "]
              }), " ", MO("enchantments:levels", {
                level: OO.level
              })]
            }), (0, DO.jsxs)("div", {
              className: "EnchantmentPossibilities",
              children: [(0, DO.jsxs)("div", {
                className: "EnchantmentPossibilitiesRow",
                children: [(0, DO.jsx)("span", {
                  className: "EnchantmentPossibilitiesTitle",
                  children: MO("enchantments:tier")
                }), Object.entries(OO.possibilities).map((OO => {
                  let [KO, pO] = OO;
                  return 0 === pO ? null : (0, DO.jsx)("span", {
                    className: "EnchantmentPossibilitiesValue",
                    style: {
                      color: yK.hb[KO]
                    },
                    children: KO
                  }, KO)
                }))]
              }), (0, DO.jsxs)("div", {
                className: "EnchantmentPossibilitiesRow",
                children: [(0, DO.jsx)("span", {
                  className: "EnchantmentPossibilitiesTitle",
                  children: MO("enchantments:odds")
                }), Object.entries(OO.possibilities).map((OO => {
                  let [KO, pO] = OO;
                  return 0 === pO ? null : (0, DO.jsxs)("span", {
                    className: "EnchantmentPossibilitiesValue",
                    style: {
                      color: yK.hb[KO]
                    },
                    children: [pO > 0 && pO < .1 ? "<0.1" : pO.toFixed(0 < pO && pO < .95 ? 1 : 0), "%"]
                  }, KO)
                }))]
              })]
            })]
          }) : !1 === (null === aK || void 0 === aK ? void 0 : aK.isEnchantable) ? (0, DO.jsx)("h1", {
            className: "EnchantmentLevels",
            children: MO("enchantments:notEnchantable")
          }) : (0, DO.jsx)("h1", {
            className: "EnchantmentLevels",
            children: MO("enchantments:enterItem")
          })
        }, bK))
      }
      return (0, DO.jsxs)("div", {
        className: "EnchantingTable",
        children: [(0, DO.jsx)("div", {
          className: "InvenLeftSideHeader SmallTextBold",
          children: vK
        }), (0, DO.jsxs)("div", {
          className: "EnchantingTableBody",
          children: [(0, DO.jsxs)("div", {
            className: "EnchantingTableLeft",
            children: [(0, DO.jsx)(upO.b, {
              idx: Fp.c,
              setHovered: OO => {
                null === pO || void 0 === pO || pO(Fp.c)(OO)
              },
              pointerDown: XO,
              pointerUp: eO,
              draggedInfo: null,
              specialItemInfo: KO,
              variation: "Enchanting Table"
            }), aK && aK.possibleEnchantments.length > 0 && (0, DO.jsxs)("div", {
              className: "PossibleEnchantments",
              children: [(0, DO.jsx)("h2", {
                children: "Possible Perks:"
              }), aK.possibleEnchantments.map((OO => (0, DO.jsxs)(bK.Fragment, {
                children: [(0, DO.jsxs)("div", {
                  className: "PossibleEnchantmentName",
                  children: [(0, DO.jsx)("div", {
                    className: "PossibleEnchantmentIcon",
                    children: (0, DO.jsx)(Cp.b, {
                      itemName: `${OO} Enchantment`,
                      amount: 1
                    })
                  }), (0, DO.jsx)("div", {
                    className: "PossibleEnchantmentNameText",
                    children: OO
                  })]
                }), (0, DO.jsx)("div", {
                  className: "PossibleEnchantmentDescription",
                  children: MO((0, yX.n)(OO).translationKey)
                })]
              }, OO)))]
            })]
          }), (0, DO.jsxs)("div", {
            className: "EnchantmentOptions",
            children: [aK && aK.isAlreadyEnchanted && (0, DO.jsx)("div", {
              className: "AlreadyEnchantedWarning",
              children: MO("enchantments:alreadyEnchanted")
            }), AO]
          })]
        })]
      })
    }
    var jX = pO(35301);

    function Yp(OO) {
      var KO;
      let {
        specialItemInfo: pO,
        setSpecialItemInfo: XO,
        setHovered: eO,
        pointerDown: lO,
        pointerUp: vK
      } = OO;
      const {
        t: CO
      } = (0, nO.D)(), MO = (0, gK.e)("inventory", (OO => OO.freeSlots)), [aK, FO] = (0, bK.useState)(null);
      (0, bK.useEffect)((() => {
        if (pO) {
          const OO = (0, jX.c)(pO.name, pO.amount);
          FO({
            salvageable: !!OO,
            produces: OO
          })
        } else FO(null)
      }), [pO, null === pO || void 0 === pO ? void 0 : pO.name, null === pO || void 0 === pO ? void 0 : pO.amount]);
      const VO = !!pO && !(null === aK || void 0 === aK || !aK.salvageable) && !(null !== (KO = aK.produces) && void 0 !== KO && KO.some((OO => {
        let {
          amt: KO
        } = OO;
        return KO < 1
      })));
      return (0, DO.jsxs)("div", {
        className: "SalvagingTable",
        children: [(0, DO.jsx)("div", {
          className: "InvenLeftSideHeader SmallTextBold",
          children: CO("item:salvagingTable")
        }), (0, DO.jsxs)("div", {
          className: "SalvagingTableBody",
          children: [(0, DO.jsx)("div", {
            className: "SalvagingTableLeft",
            children: (0, DO.jsx)(upO.b, {
              idx: Fp.c,
              setHovered: OO => {
                null === eO || void 0 === eO || eO(Fp.c)(OO)
              },
              pointerDown: lO,
              pointerUp: vK,
              draggedInfo: null,
              specialItemInfo: pO,
              variation: "Salvaging Table"
            })
          }), (0, DO.jsx)("div", {
            className: "SalvagingTableRight",
            children: (0, DO.jsx)(oO.d, {
              className: "SalvageButton",
              onClick: VO ? () => {
                const {
                  idx: OO,
                  name: KO,
                  amount: bK
                } = pO;
                hO.gameBridge.send("salvageItem", {
                  slot: OO,
                  name: KO,
                  amount: bK
                }) && (FO(null), XO(null))
              } : void 0,
              disabled: !VO,
              children: aK ? aK.salvageable ? aK.produces.some((OO => {
                let {
                  amt: KO
                } = OO;
                return KO < 1
              })) ? (0, DO.jsx)("div", {
                className: "SalvageButtonText",
                children: (0, DO.jsx)("div", {
                  className: "SalvageText Error",
                  children: CO("salvagingTable:notEnoughResources")
                })
              }) : MO < aK.produces.length ? (0, DO.jsx)("div", {
                className: "SalvageButtonText",
                children: (0, DO.jsx)("div", {
                  className: "SalvageText Error",
                  children: CO("salvagingTable:notEnoughInventorySpace")
                })
              }) : (0, DO.jsxs)("div", {
                className: "SalvageButtonText",
                children: [(0, DO.jsx)("div", {
                  className: "SalvageText",
                  children: CO("salvagingTable:salvage")
                }), (0, DO.jsx)("div", {
                  className: "SalvageIcons",
                  children: aK.produces.map(((OO, KO) => {
                    let {
                      item: pO,
                      amt: XO
                    } = OO;
                    return (0, DO.jsx)("div", {
                      className: "SalvageIcon",
                      children: (0, DO.jsx)(Cp.b, {
                        itemName: pO,
                        amount: Math.floor(XO)
                      })
                    }, KO)
                  }))
                })]
              }) : (0, DO.jsx)("div", {
                className: "SalvageButtonText",
                children: (0, DO.jsx)("div", {
                  className: "SalvageText Error",
                  children: CO("salvagingTable:unsalvageable")
                })
              }) : (0, DO.jsx)(DO.Fragment, {})
            })
          })]
        })]
      })
    }
    var wp = pO(641),
      iX = pO(8365),
      rX = pO(2164),
      Pp = pO(7775),
      mX = pO(7768),
      sp = pO(1473),
      Hp = pO(1610),
      Rp = pO(1232),
      Sp = pO(1659);

    function Jp(OO, KO, pO) {
      const XO = OO.trim().toLowerCase();
      if ("" === XO) return 0;
      let bK = null;
      for (const eO of KO) {
        const OO = eO.toLowerCase().indexOf(XO);
        if (0 === OO) return 0;
        OO > 0 && (bK = 1)
      }
      if (null !== bK) return bK;
      for (const eO of pO)
        if (eO.toLowerCase().includes(XO)) return 2;
      return null
    }

    function cX(OO) {
      return OO.map((OO => {
        var KO;
        return OO ? {
          name: OO.name,
          amount: null !== (KO = OO.amount) && void 0 !== KO ? KO : 1
        } : null
      }))
    }

    function Bp(OO) {
      return OO < 1e3 ? `${OO}` : OO < 1e4 ? Math.floor(OO / 100) / 10 + "k" : `${Math.floor(OO/1e3)}k`
    }
    var Zp = pO(35308);
    const Gp = oO.d,
      qX = {
        initialDelayMs: 400,
        intervalMs: 100
      },
      xX = () => {
        const OO = (0, Rp.g)();
        return OO ? OO.getPadRepeatTiming(qX) : qX
      };

    function np(OO, KO, pO) {
      var XO, bK;
      const eO = (0, aX.w)(KO, OO);
      let lO = null === (XO = KO[OO]) || void 0 === XO ? void 0 : XO.description;
      if (pO && (null === (bK = (0, Zp.d)().get(OO)) || void 0 === bK || !bK.hideIngredients)) {
        lO ? (lO = (0, yK.ob)(lO), lO.push({
          str: "\n"
        })) : lO = [], lO.push({
          str: "\n"
        }), lO.push({
          str: "Can be crafted from:\n"
        });
        for (const OO of pO) "string" === typeof OO && (lO.push({
          icon: OO,
          style: {
            fontSize: "1.5em"
          }
        }), lO.push({
          str: " "
        }), lO.push(...(0, yK.ob)((0, aX.w)(KO, OO))), lO.push({
          str: "\n"
        }))
      }
      return {
        name: eO,
        desc: lO
      }
    }

    function Wp(OO) {
      let {
        name: KO,
        WH: pO
      } = OO;
      return `${KO}_${pO}`
    }

    function tX(OO) {
      var KO;
      let {
        onClick: pO,
        itemName: XO,
        recipeId: eO,
        isSelected: lO,
        haveIngredients: vK,
        craftable: CO,
        setHovered: hO,
        padActions: MO,
        marked: aK,
        lock: oO,
        itemInfo: FO
      } = OO;
      const VO = (0, bK.useRef)(null);
      return (0, Pp.g)(VO, {
        press: OO => !vK || "secondary" === OO && !CO ? (MO.refuse(), !1) : "primary" === OO ? (MO.choose(), !0) : MO.craft(),
        release: MO.stopCraft,
        hints: {
          primary: "inventoryChooseRecipe",
          secondary: "inventoryCraft"
        }
      }), (0, DO.jsxs)("div", {
        ref: VO,
        className: DK()("InvenItem", {
          CraftableItemNotEnoughIngredients: !vK && !oO,
          CraftableItemMarked: aK,
          CraftableItemLocked: void 0 !== oO,
          CraftableItemLockedFar: (null !== (KO = null === oO || void 0 === oO ? void 0 : oO.stepsAway) && void 0 !== KO ? KO : 1) > 1
        }),
        "data-recipe-key": eO,
        "data-pad-inventory-default": lO ? "" : void 0,
        onClick: pO,
        style: {
          cursor: lO ? null : "pointer"
        },
        onPointerEnter: OO => {
          null === hO || void 0 === hO || hO(!0, np(XO, FO)), !lO && (0, sp.s)(OO.nativeEvent) && (0, mX.g)() && pO()
        },
        onPointerLeave: () => {
          null === hO || void 0 === hO || hO(!1)
        },
        children: [(0, DO.jsx)(Cp.b, {
          itemName: XO,
          amount: 1
        }), aK && (0, DO.jsx)("span", {
          className: "CraftableItemMarkBadge",
          "aria-hidden": "true",
          children: "!"
        }), oO && (0, DO.jsxs)("span", {
          className: "CraftableItemLockTag",
          children: [(0, DO.jsx)(LO.d, {
            name: "lock"
          }), (0, DO.jsx)(NO.d, {
            text: oO.tag
          })]
        })]
      })
    }

    function kX(OO) {
      let {
        idx: KO,
        status: pO,
        shownItem: XO,
        dim: eO,
        onHoverStart: lO,
        onHoverEnd: vK,
        onPadBack: CO
      } = OO;
      const hO = (0, bK.useRef)(null);
      (0, Pp.g)(hO, {
        press: () => !1,
        back: CO,
        hints: {
          back: "inventoryBackToRecipes"
        }
      });
      const MO = pO.need > 0 ? Math.min(pO.have / pO.need, 1) : 1;
      return (0, DO.jsxs)("div", {
        ref: hO,
        className: DK()("CupTile", {
          Short: pO.missing > 0
        }),
        style: {
          width: eO,
          height: eO
        },
        "data-craft-ingredient": KO,
        onPointerEnter: lO,
        onPointerLeave: vK,
        children: [(0, DO.jsx)("div", {
          className: "CupFill",
          style: {
            transform: `scaleY(${MO})`
          }
        }), (0, DO.jsx)(Cp.b, {
          itemName: XO,
          amount: 0
        }), (0, DO.jsxs)("div", {
          className: "CupCount SmallTextBold",
          children: [Bp(pO.have), "/", Bp(pO.need)]
        })]
      })
    }

    function Up(OO) {
      var KO, pO, XO, eO, lO;
      let {
        show: vK,
        recipeItem: {
          name: CO,
          WH: MO,
          requires: aK,
          produces: oO,
          haveIngredients: FO
        },
        detail: VO,
        onCraft: LO,
        setHovered: QO,
        craftButtonRef: zK,
        onPadBack: AO,
        showPadShortcut: fO,
        refusedCount: dO,
        lock: TO,
        itemInfo: IO
      } = OO;
      const {
        t: yK
      } = (0, nO.D)(), gK = null !== VO && !VO.roomForOne, uO = null !== (KO = null === VO || void 0 === VO ? void 0 : VO.craftAllTimes) && void 0 !== KO ? KO : 0, EO = function(OO, KO) {
        return OO.map((OO => {
          let {
            items: pO,
            amt: XO
          } = OO, bK = 0;
          const eO = [];
          for (const lO of pO) {
            const OO = KO(lO);
            bK += OO, OO > 0 && eO.push(lO)
          }
          return 0 === eO.length && eO.push(pO[0]), {
            shownItems: eO,
            need: XO,
            have: bK,
            missing: Math.max(XO - bK, 0)
          }
        }))
      }(aK, (OO => {
        var KO;
        return null !== (KO = null === VO || void 0 === VO ? void 0 : VO.amounts[OO]) && void 0 !== KO ? KO : 0
      }));
      let jK = "4rem",
        YO = 4;
      3 === aK.length || 4 === aK.length ? jK = "3.75rem" : aK.length >= 5 && (jK = "3rem"), 4 === aK.length ? YO = 2 : aK.length <= 6 && (YO = 3);
      const wO = `calc(${YO} * ${jK} + ${YO-1} * 0.4rem + 1px)`,
        iK = (0, bK.useRef)(null),
        rK = (0, bK.useRef)(null);
      (0, bK.useLayoutEffect)((() => {
        iK.current.scrollTop = 0
      }), [CO, MO]);
      const PO = (0, bK.useRef)(dO);
      (0, bK.useEffect)((() => {
        if (dO === PO.current) return;
        PO.current = dO;
        const OO = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? [{
          opacity: 1
        }, {
          opacity: .4
        }, {
          opacity: 1
        }] : [{
          transform: "translateX(0)"
        }, {
          transform: "translateX(-0.25rem)"
        }, {
          transform: "translateX(0.25rem)"
        }, {
          transform: "translateX(-0.15rem)"
        }, {
          transform: "translateX(0)"
        }];
        for (const XO of null !== (KO = null === (pO = iK.current) || void 0 === pO ? void 0 : pO.querySelectorAll(".CupTile.Short, .CantCraftInfo")) && void 0 !== KO ? KO : []) {
          var KO, pO;
          XO.animate(OO, {
            duration: 280,
            easing: "ease-out"
          })
        }
      }), [dO]);
      const mK = (OO, KO, pO) => {
          var XO;
          if ((0, Zp.d)().has(CO)) return void(pO && clearInterval(sO.current));
          const bK = null !== (XO = null === VO || void 0 === VO ? void 0 : VO.resultStackable) && void 0 !== XO && XO,
            eO = cX(hO.gameBridge.latest("inventory").player),
            {
              kR: lO,
              uq: vK,
              amountAddedToSlot: DO
            } = hO.gameBridge.send("craftRecipe", {
              name: CO,
              WH: MO,
              times: KO || OO && bK ? null : 1
            });
          if (lO > 0) {
            const KO = [],
              XO = new Set(aK.flatMap((OO => {
                let {
                  items: KO
                } = OO;
                return KO
              }))),
              lO = function(OO, KO, pO) {
                const XO = [];
                for (let bK = 0; bK < OO.length; bK++) {
                  const eO = OO[bK];
                  if (!eO || !pO.has(eO.name)) continue;
                  const lO = KO[bK],
                    vK = (null === lO || void 0 === lO ? void 0 : lO.name) === eO.name ? lO.amount : 0;
                  vK < eO.amount && XO.push({
                    idx: bK,
                    itemName: eO.name,
                    amount: eO.amount - vK
                  })
                }
                return XO
              }(eO, cX(hO.gameBridge.latest("inventory").player), XO).slice(0, 12),
              MO = pO ? 0 : Math.min(50, 400 / lO.length),
              FO = pO ? 220 : 320;
            for (const OO of lO) {
              var oO;
              const pO = aK.findIndex((KO => {
                  let {
                    items: pO
                  } = KO;
                  return pO.includes(OO.itemName)
                })),
                XO = null === (oO = iK.current) || void 0 === oO ? void 0 : oO.querySelector(`[data-craft-ingredient="${pO}"]`),
                bK = (0, aX.g)(OO.idx);
              XO && bK && KO.push({
                kind: "ingredient",
                itemName: OO.itemName,
                amount: OO.amount,
                uq: OO.idx,
                from: bK,
                to: (0, aX.g)(XO),
                delayMs: Math.round(KO.length * MO),
                durationMs: FO
              })
            }
            let VO;
            if (null !== vK && DO > 0 && rK.current) {
              const OO = KO.length > 0 ? KO[KO.length - 1].delayMs + .6 * FO : 0;
              VO = {
                itemName: CO,
                amount: DO,
                uq: vK,
                from: (0, aX.g)(rK.current),
                delayMs: Math.round(OO)
              }
            }
            LO(VO, OO && !bK ? vK : null, KO), Dp.c.play("wood1", .5).rate(1.75)
          }
        },
        sO = (0, bK.useRef)(null);
      (0, bK.useEffect)((() => () => {
        clearInterval(sO.current)
      }), []);
      const HO = (OO, KO) => {
          mK(OO, !1, !1), clearInterval(sO.current), KO && (sO.current = setTimeout((() => {
            sO.current = setInterval((() => {
              mK(OO, !1, !0)
            }), KO.intervalMs)
          }), KO.initialDelayMs))
        },
        RO = () => {
          clearInterval(sO.current)
        },
        SO = !FO || gK || Boolean(TO),
        JO = (0, bK.useRef)(null),
        cK = null !== (pO = null === (XO = (0, Sp.e)()) || void 0 === XO ? void 0 : XO.hideButtonHints) && void 0 !== pO && pO,
        BO = null !== (eO = null === (lO = (0, Rp.g)()) || void 0 === lO ? void 0 : lO.getBoundButton("inventorySecondary")) && void 0 !== eO ? eO : null,
        ZO = () => !SO && (mK(!1, !0, !1), !0);
      (0, Pp.g)(zK, {
        press: OO => "secondary" === OO ? ZO() : !SO && (HO(!1, xX()), !0),
        release: RO,
        back: AO,
        hints: {
          primary: "inventoryCraft",
          secondary: "inventoryCraftAll",
          back: "inventoryBackToRecipes"
        }
      }), (0, Pp.g)(JO, {
        press: ZO,
        back: AO,
        hints: {
          primary: "inventoryCraftAll",
          back: "inventoryBackToRecipes"
        }
      });
      const [GO, qK] = (0, bK.useState)(0), [xK, WO] = (0, bK.useState)(null);
      (0, bK.useEffect)((() => {
        if (!0 === vK) {
          qK(0);
          const OO = setInterval((() => {
            qK((OO => OO + 1))
          }), 1e3);
          return () => {
            clearInterval(OO)
          }
        }
        return () => {}
      }), [vK]);
      const tK = null === VO || void 0 === VO ? void 0 : VO.ingredientsCraftedFrom,
        kK = (0, bK.useRef)(QO);
      (0, bK.useEffect)((() => {
        kK.current = QO
      }), [QO]);
      const UO = !(null === TO || void 0 === TO || !TO.hideIngredients);
      (0, bK.useEffect)((() => {
        var OO, KO;
        if (!xK) return;
        if (UO) return WO(null), void(null === (KO = kK.current) || void 0 === KO || KO.call(kK, !1));
        const pO = xK[GO % xK.length];
        null === (OO = kK.current) || void 0 === OO || OO.call(kK, !0, np(pO, IO, null === tK || void 0 === tK ? void 0 : tK[pO]))
      }), [xK, GO, IO, tK, UO]);
      const OK = !!TO,
        KK = (0, bK.useRef)(!1);
      (0, bK.useEffect)((() => {
        var OO;
        OK && (clearInterval(sO.current), UO && KK.current && (KK.current = !1, null === (OO = kK.current) || void 0 === OO || OO.call(kK, !1)))
      }), [OK, UO]);
      const pK = (0, aX.w)(IO, CO);
      return (0, DO.jsxs)("div", {
        ref: iK,
        className: "CraftableInfo SmallTextBold",
        children: [(0, DO.jsx)("div", {
          className: "CraftableHeader",
          children: (0, DO.jsx)(NO.d, {
            text: pK
          })
        }), !UO && (0, DO.jsx)("div", {
          className: DK()("CraftableIngredients", {
            Compact: aK.length >= 5
          }),
          style: {
            maxWidth: wO
          },
          children: EO.map(((OO, KO) => {
            const pO = OO.shownItems[GO % OO.shownItems.length];
            return (0, DO.jsx)(kX, {
              idx: KO,
              status: OO,
              shownItem: pO,
              dim: jK,
              onHoverStart: () => {
                WO(OO.shownItems)
              },
              onHoverEnd: () => {
                WO(null), null === QO || void 0 === QO || QO(!1)
              },
              onPadBack: AO
            }, KO)
          }))
        }), TO && (0, DO.jsx)("div", {
          className: "CantCraftInfo CraftableLockReason",
          children: (0, DO.jsx)(NO.d, {
            text: TO.reason
          })
        }), !TO && (!FO || gK) && (0, DO.jsxs)("div", {
          className: "CantCraftInfo",
          children: [!FO && "Missing ingredients", (0, DO.jsx)("br", {}), gK && "Inventory is full"]
        }), !UO && (0, DO.jsxs)(DO.Fragment, {
          children: [(0, DO.jsxs)(Gp, {
            ref: zK,
            className: "DoCraftButton",
            onPointerDown: OO => {
              HO((0, aX.A)(OO), (0, sp.s)(OO.nativeEvent) ? xX() : qX)
            },
            onPointerUp: RO,
            onPointerLeave: RO,
            disabled: SO,
            children: [fO && BO && !SO && !cK && (0, DO.jsx)(Hp.b, {
              className: "CraftShortcutGlyph",
              glyph: BO
            }), (0, DO.jsx)("div", {
              ref: rK,
              className: "DoCraftItem",
              onPointerEnter: () => {
                KK.current = !0, null === QO || void 0 === QO || QO(!0, np(CO, IO))
              },
              onPointerLeave: () => {
                KK.current = !1, null === QO || void 0 === QO || QO(!1)
              },
              children: (0, DO.jsx)(Cp.b, {
                itemName: CO,
                amount: oO
              })
            })]
          }), (0, DO.jsxs)(Gp, {
            ref: JO,
            className: "DoCraftAllButton",
            onPointerDown: OO => {
              mK((0, aX.A)(OO), !0, !1)
            },
            disabled: SO,
            children: [(0, DO.jsx)("span", {
              className: "CraftAllLabel",
              children: yK("general:craftAll")
            }), uO > 0 && (0, DO.jsxs)("span", {
              className: "CraftAllCount",
              children: ["x", Bp(uO)]
            })]
          })]
        })]
      })
    }

    function OX(OO) {
      let {
        selectedIdx: KO,
        hidden: pO
      } = OO;
      const XO = (0, vX.p)(),
        eO = (0, bK.useRef)(null);
      return (0, bK.useLayoutEffect)((() => {
        const OO = eO.current,
          XO = null === OO || void 0 === OO ? void 0 : OO.parentElement;
        if (!XO || !OO) return;
        const bK = XO.querySelector(".CraftableItems"),
          lO = () => {
            var eO, lO;
            if (pO) return void(OO.style.opacity = "0");
            const vK = null === bK || void 0 === bK ? void 0 : bK.children[KO],
              CO = null === (eO = null !== (lO = null === vK || void 0 === vK ? void 0 : vK.querySelector(".InvenItem")) && void 0 !== lO ? lO : vK) || void 0 === eO ? void 0 : eO.getBoundingClientRect();
            if (!CO || 0 === CO.width) return void(OO.style.opacity = "0");
            const hO = XO.getBoundingClientRect();
            OO.style.opacity = "1", OO.style.width = `${CO.width}px`, OO.style.height = `${CO.height}px`, OO.style.transform = `translate(${CO.left-hO.left+XO.scrollLeft}px, ${CO.top-hO.top+XO.scrollTop}px)`
          };
        lO();
        const vK = new MutationObserver(lO),
          CO = new ResizeObserver(lO);
        return CO.observe(XO), bK && (vK.observe(bK, {
          childList: !0,
          subtree: !0
        }), CO.observe(bK)), () => {
          vK.disconnect(), CO.disconnect()
        }
      }), [KO, pO]), (0, DO.jsx)("div", {
        ref: eO,
        className: DK()("SelectionReticle", {
          Secondary: XO
        })
      })
    }

    function KX(OO, KO, pO) {
      return OO ? (0, wp.e)(iX.l, OO) ? pX(OO, KO, pO) : OO : pO("classicGame:handCrafting")
    }

    function pX(OO, KO, pO) {
      var XO;
      const bK = null === (XO = KO[OO]) || void 0 === XO ? void 0 : XO.displayName;
      if ("string" === typeof bK) return pO(bK);
      const eO = hO.gameBridge.latest("hiddenPlayerNames");
      return Array.isArray(bK) ? bK.map((OO => {
        if ("string" === typeof OO) return OO;
        if ("translationKey" in OO) return pO(OO.translationKey, (0, nO.q)(OO.params, eO));
        if ("str" in OO) {
          if ("string" === typeof OO.str) return OO.str;
          if ("translationKey" in OO.str) return pO(OO.str.translationKey, (0, nO.q)(OO.str.params, eO))
        }
        return ""
      })).join("") : bK && "translationKey" in bK ? pO(bK.translationKey, (0, nO.q)(bK.params, eO)) : OO
    }

    function XX(OO, KO) {
      return OO === KO || null !== OO && null !== KO && OO.name === KO.name && OO.WH === KO.WH
    }

    function bb(OO) {
      var KO, pO, XO;
      let {
        show: eO,
        onCraft: lO,
        dispatchSelectedCraftable: vK,
        selectedCraftable: CO,
        craftingStation: MO,
        setHovered: aK
      } = OO;
      const {
        t: oO
      } = (0, nO.D)(), [FO, VO] = (0, bK.useState)(""), [LO, QO] = (0, bK.useState)(0);
      (0, bK.useEffect)((() => {
        eO || (VO(""), QO((OO => OO + 1)))
      }), [eO]);
      const [zK, AO] = (0, bK.useState)(MO);
      zK !== MO && (AO(MO), "" !== FO && (VO(""), QO((OO => OO + 1))));
      const fO = (0, bK.useRef)(null),
        dO = (0, bK.useRef)(null),
        TO = (0, mX.k)(),
        NO = TO.showing && "recipe" === TO.kind,
        [IO, yK] = (0, bK.useState)(0),
        uO = null !== MO && void 0 !== MO ? MO : null,
        EO = (0, bK.useRef)(null),
        jK = OO => {
          return !((KO = EO.current) === (pO = OO) || null !== KO && null !== pO && KO.station === pO.station && XX(KO.recipe, pO.recipe)) && (EO.current = OO, hO.gameBridge.send("focusCrafting", OO), !0);
          var KO, pO
        };
      jK(eO ? {
        station: uO,
        recipe: (null === (KO = EO.current) || void 0 === KO ? void 0 : KO.station) === uO ? EO.current.recipe : null
      } : null);
      let YO = hO.gameBridge.latest("crafting");
      const wO = (0, gK.i)("itemInfo"),
        iK = "" !== FO.trim(),
        rK = (0, Zp.x)(),
        PO = (0, Zp.u)(),
        mK = (0, Zp.B)(),
        sO = function(OO, KO) {
          const [pO, XO] = (0, bK.useState)(!1);
          (0, bK.useEffect)((() => {
            if (!OO) return void XO(!1);
            const KO = setTimeout((() => {
              XO(!0)
            }), 0);
            return () => {
              clearTimeout(KO)
            }
          }), [OO]);
          const eO = OO && pO,
            lO = (0, bK.useRef)({
              station: KO,
              at: new Map
            });
          return (lO.current.station !== KO || !eO && lO.current.at.size > 0) && (lO.current = {
            station: KO,
            at: new Map
          }), eO ? lO.current.at : null
        }(eO, MO);
      let HO = YO.recipes.filter((OO => {
        let {
          listed: KO
        } = OO;
        return KO
      }));
      if (iK) {
        const OO = [];
        for (const KO of YO.recipes) {
          var RO;
          const pO = null !== (RO = PO.get(KO.name)) && void 0 !== RO && RO.hideIngredients ? [] : KO.requires.flatMap((OO => {
              let {
                items: KO
              } = OO;
              return KO.flatMap((OO => [OO, pX(OO, wO, oO)]))
            })),
            XO = Jp(FO, [KO.name, pX(KO.name, wO, oO)], pO);
          null !== XO && OO.push({
            item: KO,
            rank: XO
          })
        }
        OO.sort(((OO, KO) => OO.rank - KO.rank)), HO = OO.map((OO => {
          let {
            item: KO
          } = OO;
          return KO
        }))
      } else {
        if (sO && sO.size > 0) {
          const OO = YO.recipes.filter((OO => !OO.listed && sO.has(Wp(OO))));
          HO = HO.concat(OO)
        }
        HO = (0, Zp.g)(HO, rK, PO, mK), sO && (HO = (0, Zp.f)(HO, sO, Wp))
      }
      const SO = OO => HO.find((KO => Wp(KO) === OO)),
        JO = `${MO}|${FO}`,
        [cK, BO] = (0, bK.useState)(null),
        ZO = (null === cK || void 0 === cK ? void 0 : cK.context) === JO ? cK.key : null,
        GO = CO ? Wp(CO) : null,
        qK = null !== (pO = null !== (XO = SO(GO)) && void 0 !== XO ? XO : SO(ZO)) && void 0 !== pO ? pO : HO[0],
        xK = qK ? Wp(qK) : null,
        WO = qK ? {
          name: qK.name,
          WH: qK.WH
        } : null;
      eO && jK({
        station: uO,
        recipe: WO
      }) && (YO = hO.gameBridge.latest("crafting")), xK !== GO && xK !== ZO && BO(xK ? {
        context: JO,
        key: xK
      } : null), (0, bK.useEffect)((() => () => {
        EO.current = null, hO.gameBridge.send("focusCrafting", null)
      }), []);
      const tK = XX(YO.detail, WO) ? YO.detail : null,
        kK = null !== tK && !tK.roomForOne,
        UO = HO.findIndex((OO => Wp(OO) === Wp(qK))),
        OK = () => dO.current ? (0, Pp.d)(dO.current) : null,
        KK = (0, bK.useRef)(null),
        pK = (0, bK.useRef)(0);
      pK.current++;
      const XK = pK.current;
      (0, bK.useEffect)((() => {
        const OO = KK.current;
        if (!OO || XK <= OO.afterRender) return;
        if (KK.current = null, OO.key !== xK) return;
        const KO = OK();
        var pO;
        null !== KO && void 0 !== KO && KO.press("primary") && !OO.JK && (null === (pO = KO.release) || void 0 === pO || pO.call(KO))
      }));
      const bp = OO => {
          const KO = {
            name: OO.name,
            WH: OO.WH
          };
          return {
            choose: () => {
              vK(KO), (0, lp.m)(dO.current)
            },
            craft: () => {
              var OO, pO;
              return vK(KO), Wp(KO) !== Wp(qK) ? (KK.current = {
                key: Wp(KO),
                JK: !0,
                afterRender: pK.current
              }, !0) : null !== (OO = null === (pO = OK()) || void 0 === pO ? void 0 : pO.press("primary")) && void 0 !== OO && OO
            },
            stopCraft: () => {
              var OO, KO;
              KK.current ? KK.current.JK = !1 : null === (OO = OK()) || void 0 === OO || null === (KO = OO.release) || void 0 === KO || KO.call(OO)
            },
            refuse: () => {
              Wp(KO) !== Wp(qK) && vK(KO), yK((OO => OO + 1))
            }
          }
        },
        eK = () => {
          var OO, KO, pO;
          (0, lp.m)(null !== (OO = null === (KO = fO.current) || void 0 === KO || null === (pO = KO.querySelector(".CraftableItems")) || void 0 === pO ? void 0 : pO.children[UO]) && void 0 !== OO ? OO : null)
        },
        lK = HO.map(Wp).join("|"),
        vp = (0, bK.useRef)(lK);
      return (0, bK.useEffect)((() => {
        vp.current !== lK && (vp.current = lK, NO && UO >= 0 && (0, mX.g)() && eK())
      })), (0, DO.jsxs)("div", {
        className: "Craftables",
        children: [(0, DO.jsx)("div", {
          className: "InvenLeftSideHeader SmallTextBold",
          children: KX(MO, wO, oO)
        }), (0, DO.jsxs)("div", {
          className: "CraftablesBody",
          children: [(0, DO.jsx)(NK.e, {
            className: "CraftingSearch",
            placeholderText: oO("general:searchRecipes"),
            defaultValue: FO,
            maxLength: 100,
            onValueChange: OO => {
              VO(OO)
            },
            blurOnEnter: !0
          }, LO), 0 === HO.length && iK && (0, DO.jsx)("div", {
            className: "CraftingNoMatches SmallTextBold",
            children: oO("general:noRecipesMatchSearch")
          }), HO.length > 0 && (0, DO.jsxs)(DO.Fragment, {
            children: [(0, DO.jsxs)("div", {
              ref: fO,
              className: "CraftablesLeftSide",
              children: [(0, DO.jsx)(rX.b, {
                lazyLoadedClassName: "CraftableItems",
                observerUpdateDeps: [JSON.stringify(HO.map((OO => {
                  let {
                    name: KO,
                    WH: pO,
                    haveIngredients: XO
                  } = OO;
                  return {
                    name: KO,
                    WH: pO,
                    haveIngredients: XO
                  }
                })))],
                observing: eO,
                children: HO.map((OO => {
                  const {
                    name: KO,
                    WH: pO,
                    haveIngredients: XO
                  } = OO, bK = Wp(OO);
                  return (0, DO.jsx)(tX, {
                    recipeId: bK,
                    itemName: KO,
                    onClick: () => {
                      vK({
                        name: KO,
                        WH: pO
                      })
                    },
                    isSelected: Wp(qK) === bK,
                    haveIngredients: XO,
                    craftable: XO && !PO.has(KO) && !(Wp(qK) === bK && kK),
                    setHovered: aK,
                    padActions: bp(OO),
                    marked: rK.has(KO),
                    lock: PO.get(KO),
                    itemInfo: wO
                  }, bK)
                }))
              }), (0, DO.jsx)(OX, {
                selectedIdx: UO,
                hidden: NO && TO.steppingSlots
              })]
            }), (0, DO.jsx)(Up, {
              show: eO,
              recipeItem: qK,
              detail: tK,
              onCraft: lO,
              setHovered: aK,
              craftButtonRef: dO,
              onPadBack: eK,
              showPadShortcut: NO,
              refusedCount: IO,
              lock: PO.get(qK.name),
              itemInfo: wO
            })]
          })]
        })]
      })
    }
    var eX = pO(35217),
      lX = pO(2560),
      vb = pO(1698),
      CX = pO(7757);
    class hX {
      constructor(OO, KO, pO) {
        this.commit = OO, this.delayMs = KO, this.defers = pO, this.pending = null, this.timer = void 0, this.JK = !1, this.flush = () => {
          clearTimeout(this.timer);
          const OO = this.pending;
          null !== OO && (this.pending = null, this.commit(OO))
        }
      }
      type(OO) {
        this.pending = OO, clearTimeout(this.timer), this.JK || this.defers() ? this.JK || (this.timer = setTimeout(this.flush, this.delayMs)) : this.flush()
      }
      getTyped(OO) {
        var KO;
        return null !== (KO = this.pending) && void 0 !== KO ? KO : OO
      }
      isHeld() {
        return this.JK
      }
      setHeld(OO) {
        this.JK = OO, OO || this.flush()
      }
    }

    function DX(OO) {
      return null === OO ? "creativeInventory:all" : `creativeInventory:${OO}`
    }

    function MX(OO) {
      let {
        category: KO
      } = OO;
      return null === KO ? (0, DO.jsx)(LO.d, {
        name: "layer-group"
      }) : (0, DO.jsx)(Cp.b, {
        itemName: eX.creativeItemCategoryIcons[KO],
        amount: 0
      })
    }

    function ab(OO) {
      let {
        labelKey: KO,
        isSelected: pO,
        onSelect: XO,
        setHovered: bK,
        children: eO
      } = OO;
      return (0, DO.jsx)("div", {
        className: DK()("CreativeCategoryTab", {
          Selected: pO
        }),
        onClick: XO,
        onPointerEnter: OO => {
          (0, aX.t)(OO) || bK(!0, {
            name: {
              translationKey: KO
            },
            desc: ""
          })
        },
        onPointerLeave: () => {
          bK(!1)
        },
        children: eO
      })
    }

    function oX(OO) {
      let {
        categories: KO,
        selectedCategory: pO,
        onSelect: XO
      } = OO;
      const {
        t: eO
      } = (0, nO.D)(), [lO, vK] = (0, bK.useState)(!1), CO = (0, bK.useRef)(null), hO = (0, bK.useCallback)((() => {
        vK(!1)
      }), []);
      return (0, vb.d)(CO, hO), (0, DO.jsxs)("div", {
        className: "CreativeCategoryDropdown",
        ref: CO,
        children: [(0, DO.jsxs)("div", {
          className: "CreativeCategoryDropdownButton",
          onClick: () => {
            vK(!lO)
          },
          children: [(0, DO.jsx)("div", {
            className: "CreativeCategoryIcon",
            children: (0, DO.jsx)(MX, {
              category: pO
            })
          }), (0, DO.jsx)("span", {
            children: eO(DX(pO))
          }), (0, DO.jsx)(LO.d, {
            name: lO ? "caret-up" : "caret-down"
          })]
        }), lO && (0, DO.jsx)("div", {
          className: "CreativeCategoryDropdownMenu",
          children: KO.map((OO => (0, DO.jsxs)("div", {
            className: DK()("CreativeCategoryDropdownOption", {
              Selected: pO === OO
            }),
            onClick: () => {
              XO(OO), vK(!1)
            },
            children: [(0, DO.jsx)("div", {
              className: "CreativeCategoryIcon",
              children: (0, DO.jsx)(MX, {
                category: OO
              })
            }), (0, DO.jsx)("span", {
              children: eO(DX(OO))
            })]
          }, null !== OO && void 0 !== OO ? OO : "all")))
        })]
      })
    }
    const FX = (0, bK.memo)((function(OO) {
      let {
        creativeScrollDiv: KO,
        playerInvenNumSlots: pO,
        getSetHoveringForIdx: XO,
        getPointerDownForIdx: eO,
        getPointerUpForIdx: lO,
        creativeSearchVal: vK,
        setCreativeSearchVal: hO,
        creativeCategory: MO,
        setCreativeCategory: aK,
        show: oO
      } = OO;
      const {
        t: FO
      } = (0, nO.D)(), VO = (0, gK.i)("creativeVisibility"), {
        userContext: QO
      } = (0, TO.d)(), zK = (0, CO.i)("canUseDevCreativeItems"), AO = QO.playerHasRank("developer") || !!zK, fO = (0, bK.useMemo)((() => LX("", VO, AO)), [VO, AO]), dO = (0, bK.useMemo)((() => {
        const OO = (0, eX.creativeItemIds)(),
          KO = new Set(fO.map((KO => (0, eX.creativeCategoryOf)(OO[KO]))));
        return eX.creativeItemCategories.filter((OO => KO.has(OO)))
      }), [fO]), NO = null !== MO && dO.includes(MO) ? MO : null, yK = (0, bK.useMemo)((() => "" === vK ? fO : LX(vK, VO, AO)), [fO, vK, VO, AO]), uO = (0, bK.useMemo)((() => {
        const OO = (0, eX.creativeItemIds)();
        return null !== NO ? yK.filter((KO => (0, eX.creativeCategoryOf)(OO[KO]) === NO)) : "" === vK ? yK.filter((KO => !(0, eX.showOnlyInCreativeCategory)(OO[KO]))) : yK
      }), [yK, NO, vK]), EO = XO();

      function jK(OO) {
        aK(OO), KO.current.scrollTop = 0
      }
      const YO = [null, ...dO],
        {
          isTouchScreen: wO
        } = (0, RO.l)(["isTouchScreen"]),
        iK = !wO,
        rK = (0, bK.useRef)(null),
        [PO, mK] = (0, bK.useState)(0);
      (0, bK.useEffect)((() => {
        const OO = rK.current;
        if (!OO) return;
        const KO = new ResizeObserver((OO => {
          mK(OO[0].contentRect.height)
        }));
        return KO.observe(OO), () => {
          KO.disconnect()
        }
      }), [iK]);
      const sO = (0, bK.useRef)(null),
        HO = (0, bK.useCallback)((function OO() {
          "up" === sO.current ? KO.current.scrollTop -= 10 : "down" === sO.current && (KO.current.scrollTop += 10), sO.current && requestAnimationFrame(OO)
        }), [KO]),
        SO = (0, bK.useCallback)((function(OO) {
          sO.current || (sO.current = OO, HO())
        }), [HO]);

      function JO() {
        sO.current = null
      }
      const cK = (0, bK.useRef)({
        creativeSearchVal: vK,
        setCreativeSearchVal: hO
      });
      cK.current = {
        creativeSearchVal: vK,
        setCreativeSearchVal: hO
      };
      const [BO] = (0, bK.useState)((() => new hX((OO => {
        cK.current.setCreativeSearchVal(OO)
      }), 250, vX.h))), ZO = OO => {
        var pO;
        null === (pO = KO.current) || void 0 === pO || pO.classList.toggle("CreativeItemSlotsStale", OO)
      };
      (0, IO.f)(CX.e, (OO => {
        BO.setHeld(OO), OO || ZO(!1)
      })), (0, bK.useEffect)((() => BO.flush), [BO]);
      const GO = (0, DO.jsx)(NK.e, {
          className: "CreativeItemSlotsSearch",
          placeholderText: "Search",
          defaultValue: vK,
          maxLength: 1e4,
          onValueChange: (OO, KO) => {
            "" === BO.getTyped(cK.current.creativeSearchVal) && "" !== OO && aK(null), BO.type(OO), ZO(BO.isHeld())
          },
          onEnter: BO.flush,
          blurOnEnter: !0
        }),
        qK = (0, DO.jsxs)("div", {
          className: "CreateItemSlotsScrollable",
          children: [wO && (0, DO.jsxs)("div", {
            className: "CreativeScrollButtons",
            children: [(0, DO.jsx)("div", {
              className: "CreativeScrollButton Up",
              onPointerDown: () => {
                SO("up")
              },
              onPointerLeave: JO,
              onPointerUp: JO,
              children: (0, DO.jsx)(LO.d, {
                name: "arrow-up"
              })
            }), (0, DO.jsx)("div", {
              className: "CreativeScrollButton Down",
              onPointerDown: () => {
                SO("down")
              },
              onPointerLeave: JO,
              onPointerUp: JO,
              children: (0, DO.jsx)(LO.d, {
                name: "arrow-up"
              })
            })]
          }), (0, DO.jsxs)("div", {
            className: "CreativeItemSlots",
            ref: KO,
            children: [0 === uO.length && "" !== vK && (0, DO.jsx)("div", {
              className: "CreativeItemSlotsEmpty",
              children: FO("general:noResults")
            }), (0, DO.jsx)(rX.b, {
              lazyLoadedClassName: "CreativeItemSlotsInner",
              observerUpdateDeps: [vK, NO],
              observerRoot: "CreativeItemSlots",
              observing: oO,
              children: uO.map((OO => {
                const KO = pO + OO;
                return (0, DO.jsx)(upO.b, {
                  idx: KO,
                  draggedInfo: null,
                  specialItemInfo: null,
                  setHovered: XO(KO),
                  pointerDown: eO(KO),
                  pointerUp: lO(KO)
                }, KO)
              }))
            })]
          })]
        });
      return (0, DO.jsxs)("div", {
        className: DK()("CreativeItemSlotsWrapper", iK ? "WithRail" : "WithDropdown"),
        children: [iK && (0, DO.jsx)("div", {
          className: "CreativeCategoryRail",
          ref: rK,
          style: {
            "--rail-height": PO > 0 ? `${PO}px` : void 0,
            "--tab-rows": Math.ceil(YO.length / 2)
          },
          children: YO.map((OO => (0, DO.jsx)(ab, {
            labelKey: DX(OO),
            isSelected: NO === OO,
            onSelect: () => {
              jK(OO)
            },
            setHovered: EO,
            children: (0, DO.jsx)(MX, {
              category: OO
            })
          }, null !== OO && void 0 !== OO ? OO : "all")))
        }), (0, DO.jsxs)("div", {
          className: "CreativeItemSlotsMain",
          children: [(0, DO.jsxs)("div", {
            className: "CreativeItemSlotsSearchRow",
            children: [GO, !iK && (0, DO.jsx)(oX, {
              categories: YO,
              selectedCategory: NO,
              onSelect: jK
            })]
          }), qK]
        })]
      })
    }));

    function VX(OO) {
      var KO;
      return null !== (KO = (0, lX.e)(OO)) && void 0 !== KO ? KO : ""
    }

    function LX(OO, KO, pO) {
      let {
        publicLobby: XO,
        shownInGame: bK
      } = KO;
      const eO = OO.toLowerCase(),
        lO = (0, eX.creativeItemIds)(),
        vK = OO => {
          var KO;
          const eO = lO[OO];
          return !(0, eX.itemIsDisabled)(eO, XO, null === (KO = bK[VX(eO)]) || void 0 === KO || KO, pO)
        };
      if ("" === eO) return lO.map(((OO, KO) => KO)).filter((OO => !(0, eX.showOnlyInCreativeSearch)(lO[OO]))).filter(vK);
      const CO = [];
      for (let hO = 0; hO < lO.length; hO++) VX(lO[hO]).toLowerCase().includes(eO) && CO.push(hO);
      CO.sort(((OO, KO) => {
        const pO = VX(lO[OO]).toLowerCase(),
          XO = VX(lO[KO]).toLowerCase();
        return pO.indexOf(eO) - XO.indexOf(eO)
      }));
      for (const [hO, DO] of(0, eX.creativeAltNames)())
        for (const OO of DO)
          if (OO.toLowerCase().includes(eO)) {
            const OO = lO.indexOf(hO);
            CO.includes(OO) || CO.push(OO)
          } return CO.filter(vK)
    }
    var QX = pO(35322),
      zb = pO(533);

    function AX(OO) {
      return OO > zb.l
    }

    function fX(OO) {
      const KO = OO / 2,
        pO = [];
      for (let XO = 0; XO < KO / 6; XO++)
        for (let OO = 0; OO < 12; OO++) {
          const bK = OO < 6 ? 0 : KO;
          pO.push(bK + 6 * XO + OO % 6)
        }
      return pO
    }

    function dX(OO) {
      let {
        numSlots: KO,
        renderSlot: pO
      } = OO;
      const {
        t: XO
      } = (0, nO.D)(), eO = (0, bK.useRef)(null);
      var lO;
      return lO = eO, (0, bK.useLayoutEffect)((() => {
        var OO;
        const KO = null === (OO = lO.current) || void 0 === OO ? void 0 : OO.closest(".InvenBody");
        if (!KO) return;
        const pO = () => {
          KO.style.zoom = "";
          const OO = parseFloat(getComputedStyle(document.documentElement).fontSize),
            pO = window.innerWidth - 2 * OO,
            XO = KO.getBoundingClientRect().width;
          XO > pO && (KO.style.zoom = "" + pO / XO)
        };
        return pO(), window.addEventListener("resize", pO), () => {
          window.removeEventListener("resize", pO), KO.style.zoom = ""
        }
      }), [lO]), (0, DO.jsxs)("div", {
        ref: eO,
        className: "ChestItemSlots DoubleChestSlots",
        children: [(0, DO.jsx)("div", {
          className: "InvenLeftSideHeader SmallTextBold",
          children: XO("doubleChest:title")
        }), (0, DO.jsx)("div", {
          className: "GridItemSlots",
          children: fX(KO).map((OO => pO(OO)))
        })]
      })
    }

    function TX(OO) {
      let {
        hiO: KO,
        initialPasskey: pO
      } = OO;
      const {
        t: XO
      } = (0, nO.D)(), [eO, lO] = (0, bK.useState)(pO), [vK, CO] = (0, bK.useState)(pO);
      (0, bK.useEffect)((() => {
        lO(pO), CO(pO)
      }), [...KO]);
      return (0, DO.jsxs)("div", {
        className: "IronChestPasskeyEditorWrapper",
        children: [(0, DO.jsx)("div", {
          className: "SmallTextBold",
          children: XO("ironChest:currentPasskey", {
            currentPasskey: eO.join("")
          })
        }), (0, DO.jsx)(Np, {
          className: "IronChestPasskeyEditor",
          pC: vK,
          onPasskeyUpdated: CO,
          confirmText: "ironChest:changePasskey",
          onConfirm: () => {
            hO.gameBridge.send("changeIronChestPasskey", {
              pos: [...KO],
              pC: [...vK]
            }), lO([...vK])
          }
        })]
      })
    }

    function NX(OO) {
      let {
        variation: KO,
        canCraft: pO,
        show: XO,
        creativeMounted: bK,
        specialItemRef: eO,
        draggedInfo: lO,
        getSetHovering: vK,
        getPointerDownForIdx: CO,
        getPointerUpForIdx: hO,
        enchantingTablePosition: MO,
        enchantingTableBlockName: aK,
        selectedCraftable: oO,
        dispatchSelectedCraftable: FO,
        creativeScrollDiv: VO,
        creativeSearchVal: LO,
        setCreativeSearchVal: QO,
        creativeCategory: zK,
        setCreativeCategory: AO,
        onCraft: fO
      } = OO;
      const {
        userContext: dO
      } = (0, TO.d)(), {
        t: NO
      } = (0, nO.D)(), IO = (0, gK.e)("inventory", (OO => OO.chest)), yK = (0, gK.e)("inventory", (OO => OO.player.length)), uO = (0, gK.e)("inventory", (OO => OO.creative));
      if (0 === yK) return null;
      let EO, jK;
      const YO = OO => {
          const KO = yK + OO;
          return (0, DO.jsx)(upO.b, {
            idx: KO,
            draggedInfo: lO,
            specialItemInfo: eO.current,
            setHovered: vK(KO),
            pointerDown: CO(KO),
            pointerUp: hO(KO)
          }, KO)
        },
        wO = IO ? (0, QX.e)(IO.type) : null;
      if (wO) EO = DK()("InvenLeftSideChestCustom", wO.className), jK = (0, DO.jsx)("div", {
        className: "ChestItemSlotsWrapper",
        children: wO.render({
          hiO: IO.pos,
          renderSlot: YO
        })
      });
      else if (IO) {
        const OO = IO.pos,
          KO = "Iron" === IO.type || "Moonstone" === IO.type ? IO.type : "Standard";
        let pO = !1,
          XO = null;
        "Iron" === KO && (pO = IO.ironChest.ownerDbId === dO.whamm, XO = IO.ironChest.pC), EO = `InvenLeftSideChest${KO}`;
        const bK = AX(IO.numSlots);
        jK = (0, DO.jsxs)("div", {
          className: "ChestItemSlotsWrapper",
          children: [pO && (0, DO.jsx)(TX, {
            hiO: OO,
            initialPasskey: XO
          }), bK && (0, DO.jsx)(dX, {
            numSlots: IO.numSlots,
            renderSlot: YO
          }), !bK && (0, DO.jsxs)("div", {
            className: "ChestItemSlots",
            children: [(0, DO.jsx)("div", {
              className: "InvenLeftSideHeader SmallTextBold",
              children: NO("Moonstone" === KO ? "item:moonstoneChest" : "Iron" === KO ? "item:ironChest" : "item:chest")
            }), (0, DO.jsx)("div", {
              className: "GridItemSlots",
              children: new Array(IO.numSlots).fill(0).map(((OO, KO) => YO(KO)))
            })]
          })]
        })
      } else if (!uO || KO && pO)
        if (pO && "Enchanting Table" === KO) EO = `InvenLeftSide${(null!==aK&&void 0!==aK?aK:"").replace(/ /gi,"")}`, jK = (0, DO.jsx)(Ep, {
          specialItemInfo: eO.current,
          setHovered: vK,
          pointerDown: CO(Fp.c),
          pointerUp: hO(Fp.c),
          enchantingTablePosition: MO,
          enchantingTableBlockName: aK
        });
        else if (pO && "Salvaging Table" === KO) EO = "InvenLeftSideSalvagingTable", jK = (0, DO.jsx)(Yp, {
        specialItemInfo: eO.current,
        setSpecialItemInfo: OO => {
          eO.current = OO
        },
        setHovered: vK,
        pointerDown: CO(Fp.c),
        pointerUp: hO(Fp.c)
      });
      else {
        if (!pO) return null;
        EO = `InvenLeftSide${(null!==KO&&void 0!==KO?KO:"HandCrafting").replace(/ /gi,"")}`, jK = (0, DO.jsx)(bb, {
          show: XO,
          onCraft: fO,
          craftingStation: KO,
          selectedCraftable: oO,
          dispatchSelectedCraftable: FO,
          setHovered: vK()
        })
      } else EO = "InvenLeftSideCreative", jK = bK ? (0, DO.jsx)(FX, {
        creativeScrollDiv: VO,
        playerInvenNumSlots: yK,
        getSetHoveringForIdx: vK,
        getPointerDownForIdx: CO,
        getPointerUpForIdx: hO,
        creativeSearchVal: LO,
        setCreativeSearchVal: QO,
        creativeCategory: zK,
        setCreativeCategory: AO,
        show: XO
      }) : null;
      const iK = !!IO || pO && !!KO;
      return (0, DO.jsx)("div", {
        className: `InvenLeftSide ${EO}`,
        "data-pad-inventory-start": iK ? "" : void 0,
        children: jK
      })
    }
    var IX = pO(518);
    const yb = {
      Helmet: "empty_armor_slot_helmet",
      Chestplate: "empty_armor_slot_chestplate",
      Gauntlets: "empty_armor_slot_gauntlets",
      Leggings: "empty_armor_slot_leggings",
      Boots: "empty_armor_slot_boots"
    };

    function gb(OO) {
      let {
        draggedInfo: KO,
        specialItemInfo: pO,
        craftFlyAnims: XO,
        getSetHovering: bK,
        getPointerDownForIdx: eO,
        getPointerUpForIdx: lO,
        variation: vK,
        canCraft: CO,
        isNewSlot: hO
      } = OO;
      const MO = (0, gK.e)("inventory", (OO => OO.player.length));
      return 0 === MO ? null : (0, DO.jsxs)("div", {
        className: "InvenBodyRight",
        children: [(0, DO.jsx)("div", {
          className: "ArmourItemSlots",
          children: new Array(IX.b.length).fill(0).map(((OO, aK) => {
            const oO = MO - IX.b.length + aK;
            return (0, DO.jsx)(upO.b, {
              idx: oO,
              draggedInfo: KO,
              specialItemInfo: pO,
              craftFlyHoldbackInfo: (0, op.h)(XO, oO),
              setHovered: bK(oO),
              pointerDown: eO(oO),
              pointerUp: lO(oO),
              defaultIconB64: nK.c.getTexture(yb[IX.b[aK]], WK.g.ITEM).url,
              variation: CO ? vK : void 0,
              showNewDot: hO(oO)
            }, oO)
          }))
        }), (0, DO.jsx)("div", {
          className: "GridItemSlots",
          children: new Array(MO - 10 - IX.b.length).fill(0).map(((OO, aK) => {
            const oO = MO - IX.b.length - aK - 1;
            return (0, DO.jsx)(upO.b, {
              idx: oO,
              draggedInfo: KO,
              specialItemInfo: pO,
              craftFlyHoldbackInfo: (0, op.h)(XO, oO),
              setHovered: bK(oO),
              pointerDown: eO(oO),
              pointerUp: lO(oO),
              variation: CO ? vK : void 0,
              showNewDot: hO(oO)
            }, oO)
          }))
        })]
      })
    }
    var uX = pO(35326),
      EX = pO(35333);

    function jb(OO) {
      const {
        e: KO,
        idx: pO
      } = OO, XO = (0, aX.l)(OO.readInventory(), pO), bK = (0, aX.r)(KO);
      pO === Fp.b ? function(OO, KO) {
        const {
          draggedInfoRef: pO,
          removeItem: XO,
          removeDraggedInfoRef: bK,
          close: eO
        } = OO;
        if (pO.current) {
          const OO = KO && pO.current.amount || 1;
          XO(pO.current.idx, OO, !0) && (pO.current.amount -= OO, pO.current.amount <= 0 && bK())
        } else KO && eO()
      }(OO, bK) : pO === Fp.c ? function(OO, KO) {
        const {
          e: pO,
          draggedInfoRef: XO,
          specialItemRef: bK,
          moveAmtIntoSlot: eO,
          removeDraggedInfoRef: lO
        } = OO;
        if ((0, aX.A)(pO) && bK.current) bK.current = null;
        else if (XO.current && bK.current && (XO.current.idx === bK.current.idx || (0, EX.b)(XO.current, bK.current)) && XO.current.amount > 0 && bK.current.amount > 0 && bK.current.amount < dp.h.maxItemStackSize)
          if (XO.current.idx === bK.current.idx) {
            if (KO) {
              const OO = Math.min(XO.current.amount, dp.h.maxItemStackSize - bK.current.amount);
              bK.current.amount += OO, XO.current.amount -= OO
            } else XO.current.amount--, bK.current.amount++;
            XO.current.amount <= 0 && lO()
          } else if (KO) {
          const OO = Math.min(XO.current.amount, dp.h.maxItemStackSize - bK.current.amount);
          eO(bK.current.idx, OO) && (bK.current.amount += OO)
        } else {
          eO(bK.current.idx, 1) && bK.current.amount++
        } else if (!XO.current || bK.current || KO) {
          const OO = XO.current;
          XO.current = bK.current, bK.current = OO
        } else XO.current.amount--, bK.current = {
          idx: XO.current.idx,
          name: XO.current.name,
          attributes: XO.current.attributes,
          amount: 1
        }
      }(OO, bK) : (0, aX.A)(KO) ? function(OO, KO) {
        var pO, XO;
        const {
          idx: bK,
          draggedInfoRef: eO,
          specialItemRef: lO,
          canCraft: vK,
          variation: CO,
          swapSlots: hO,
          moveIntoSlots: DO
        } = OO;
        if (!KO) return;
        let MO = KO.amount;
        bK === (null === (pO = eO.current) || void 0 === pO ? void 0 : pO.idx) && (MO = eO.current.amount <= 0 ? 0 : KO.amount - eO.current.amount);
        bK === (null === (XO = lO.current) || void 0 === XO ? void 0 : XO.idx) && (MO = lO.current.amount <= 0 ? 0 : KO.amount - lO.current.amount);
        if (0 === MO) return;
        const aK = OO.readInventory(),
          oO = aK.player.length,
          FO = aK.chest,
          VO = oO - IX.b.length,
          LO = () => {
            if (!(0, vX.h)()) return void DO(10, VO, bK, MO);
            const OO = OO => {
              const pO = (0, aX.l)(aK, OO);
              return pO ? {
                amount: pO.amount,
                stacksWithMoved: (0, EX.b)(pO, KO)
              } : null
            };
            for (const KO of ((OO, KO, pO, XO, bK) => {
                const eO = [];
                let lO = XO;
                if (null !== XO) {
                  let vK = 0;
                  for (let XO = KO; XO < pO; XO++) {
                    const KO = OO(XO);
                    null !== KO && void 0 !== KO && KO.stacksWithMoved && null !== KO.amount && KO.amount > 0 && (vK += Math.max(0, bK - KO.amount))
                  }
                  const CO = Math.min(XO, vK);
                  if (CO > 0 && (eO.push({
                      start: KO,
                      end: pO,
                      amount: CO
                    }), lO = XO - CO), lO <= 0) return eO
                }
                for (let vK = pO - 1; vK >= KO; vK--)
                  if (null === OO(vK)) {
                    eO.push({
                      start: vK,
                      end: vK + 1,
                      amount: lO
                    });
                    break
                  } return eO
              })(OO, 10, VO, MO, dp.h.maxItemStackSize)) DO(KO.start, KO.end, bK, KO.amount)
          };
        if (!vK || "Enchanting Table" !== CO && "Salvaging Table" !== CO) {
          const pO = (0, yK.ub)(KO.name),
            XO = pO ? (0, yK.tb)(pO) : null;
          if (!IX.b.includes(pO) || bK !== XO && (0, aX.n)(aK, OO.itemInfo, XO, bK))
            if (FO)
              if (bK < oO) {
                var QO, zK;
                const [OO, KO] = null !== (QO = null === (zK = (0, QX.e)(FO.type)) || void 0 === zK ? void 0 : zK.quickMoveRange) && void 0 !== QO ? QO : [0, FO.numSlots];
                DO(oO + OO, oO + KO, bK, MO)
              } else DO(0, oO - IX.b.length, bK, MO);
          else aK.creative ? bK < 10 ? LO() : bK < oO ? DO(0, 10, bK, MO) : DO(0, oO - IX.b.length, bK, null !== KO.amount ? dp.h.maxItemStackSize : null) : bK < 10 ? LO() : DO(0, 10, bK, MO);
          else bK < oO - IX.b.length || bK >= oO ? hO(XO, bK) : (DO(0, oO - IX.b.length, XO, MO), Dp.c.play("equip_leather1", 1).rate(.9 + .3 * Math.random()))
        } else lO.current = {
          idx: bK,
          name: KO.name,
          attributes: KO.attributes,
          amount: null !== KO.amount ? MO : 0
        }
      }(OO, XO) : OO.draggedInfoRef.current ? function(OO, KO, pO, XO) {
        const {
          draggedInfoRef: bK,
          specialItemRef: eO,
          moveAmtIntoSlot: lO,
          swapSlots: vK,
          removeItem: CO,
          removeDraggedInfoRef: hO
        } = OO, DO = OO.readInventory(), MO = bK.current.idx;
        if (pO && (KO === MO || (0, EX.b)(bK.current, pO)) && bK.current.amount > 0 && (0, aX.e)(pO) > 0 && (pO.amount < dp.h.maxItemStackSize || KO === MO)) XO ? pO.amount + bK.current.amount <= dp.h.maxItemStackSize || KO === MO ? lO(KO, bK.current.amount) : lO(KO, dp.h.maxItemStackSize - pO.amount) : lO(KO, 1);
        else if (bK.current.amount > 0 && !pO) lO(KO, XO ? bK.current.amount : 1);
        else if (XO || pO || 0 === bK.current.amount)
          if (DO.creative && !DO.chest && KO >= DO.player.length) {
            const OO = 0 === bK.current.amount ? 1 : bK.current.amount;
            CO(bK.current.idx, OO, !1) && hO()
          } else {
            var aK;
            const pO = (null === (aK = eO.current) || void 0 === aK ? void 0 : aK.idx) === KO;
            if (vK(KO, bK.current.idx)) {
              const XO = OO.readInventory(),
                lO = (0, aX.l)(XO, MO),
                vK = !XO.chest && XO.creative && bK.current.idx >= XO.player.length;
              if (lO && bK.current.idx !== KO && !vK) {
                let OO = (0, aX.e)(lO);
                pO && (OO -= eO.current.amount), bK.current = pO && 0 === OO ? null : {
                  idx: bK.current.idx,
                  name: lO.name,
                  attributes: lO.attributes,
                  amount: OO
                }
              } else hO()
            }
          }
        else lO(KO, 1)
      }(OO, pO, XO, bK) : function(OO, KO, pO, XO) {
        var bK;
        const {
          draggedInfoRef: eO,
          specialItemRef: lO
        } = OO;
        if (!pO) return;
        let vK = (0, aX.e)(pO);
        const CO = (null === (bK = lO.current) || void 0 === bK ? void 0 : bK.idx) === KO;
        CO && (vK -= lO.current.amount);
        XO || (vK = Math.ceil(vK / 2));
        eO.current = CO && 0 === vK ? null : {
          idx: KO,
          name: pO.name,
          attributes: pO.attributes,
          amount: vK
        }
      }(OO, pO, XO, bK)
    }

    function YX(OO, KO) {
      return !!KO && KO.name === OO.name
    }

    function wX() {
      return hO.gameBridge.latest("inventory")
    }

    function ib(OO, KO, pO) {
      return hO.gameBridge.send("removeInventoryItem", {
        slot: OO,
        amount: KO,
        drop: pO
      })
    }

    function rb(OO) {
      return (0, aX.k)(OO, hO.gameBridge.latest("itemInfo"), hO.gameBridge.latest("stationItems").enchantable)
    }

    function PX(OO) {
      let {
        show: KO,
        close: pO,
        canCraft: XO,
        variation: eO,
        inventoryItemsMoveable: lO,
        setCraftFlyAnims: vK
      } = OO;
      (0, gK.i)("itemInfo");
      const [CO, DO] = (0, bK.useState)(null), [MO, aK] = (0, bK.useState)(null), [oO, FO] = (0, bK.useState)(!1), VO = (0, bK.useRef)(null), LO = (0, bK.useRef)(null), QO = (0, bK.useRef)(null), zK = (0, bK.useRef)(null), [AO, fO] = (0, bK.useReducer)((OO => OO + 1), 0), dO = (0, bK.useCallback)((() => {
        KO && fO()
      }), [KO, fO]), TO = (0, bK.useCallback)((() => {
        LO.current = null, PO.current = null, dO()
      }), [dO]), NO = (0, bK.useCallback)(((OO, KO) => {
        vK((pO => pO.map((pO => "ingredient" === pO.kind ? pO : pO.uq === OO ? {
          ...pO,
          uq: KO,
          to: (0, aX.g)(KO)
        } : pO.uq === KO ? {
          ...pO,
          uq: OO,
          to: (0, aX.g)(OO)
        } : pO))))
      }), [vK]), IO = (0, bK.useCallback)(((OO, KO) => {
        const pO = HO.current;
        if (pO.x = OO, pO.y = KO, VO.current) !RO.current.isTouch || RO.current.itemBeingDragged && !PO.current ? (VO.current.style.transform = `translate(${pO.x}px, ${pO.y}px)`, FO(RO.current.isTouch && !PO.current)) : (VO.current.style.transform = "translate(0.5rem, 0.5rem)", FO(!0));
        else if (zK.current) {
          const pO = zK.current;
          let XO = OO + 10,
            bK = KO + 10;
          const eO = pO.offsetWidth,
            lO = pO.offsetHeight;
          XO + eO > window.innerWidth && (XO = OO - eO - 10), bK + lO > window.innerHeight && (bK = KO - lO - 10), XO < 0 && (XO = 0), bK < 0 && (bK = 0), zK.current.style.transform = `translate(${XO}px, ${bK}px)`
        }
      }), []), uO = (0, bK.useCallback)((OO => (KO, pO, XO) => {
        if (DO(KO && void 0 !== OO ? OO : null), KO) {
          if (void 0 === OO && !pO) return void(0, uX.d)("Error in invenComp", new Error("isHovering true but no idx or text"));
          if (void 0 !== OO) {
            var bK;
            const KO = wX();
            let pO;
            if (pO = OO === Fp.c ? QO.current ? (0, aX.l)(KO, QO.current.idx) : null : (0, aX.l)(KO, OO), !pO) return void aK(null);
            if ((null === (bK = QO.current) || void 0 === bK ? void 0 : bK.idx) === OO) {
              if (0 === (0, aX.e)(pO) - QO.current.amount) return void aK(null)
            }
            aK(rb(pO))
          } else aK({
            name: pO.name,
            desc: pO.desc,
            fontStyle: "normal"
          })
        } else aK(null);
        XO && setTimeout((() => {
          IO(XO.pageX, XO.pageY)
        }), 0)
      }), [IO]), EO = (0, bK.useCallback)(((OO, KO) => {
        const pO = hO.gameBridge.send("moveInventoryItem", {
          from: LO.current.idx,
          to: OO,
          amount: KO
        });
        return pO ? (LO.current.amount -= KO, LO.current.amount <= 0 && TO()) : console.error("moveInventoryItem failed"), pO
      }), [TO]), jK = (0, bK.useCallback)(((OO, KO) => {
        const pO = QO.current,
          XO = null === pO || void 0 === pO ? void 0 : pO.idx;
        pO && (pO.idx = function(OO, KO, pO) {
          return OO === KO ? pO : OO === pO ? KO : OO
        }(XO, OO, KO));
        const bK = hO.gameBridge.send("swapInventorySlots", {
          a: OO,
          b: KO
        });
        return bK ? NO(OO, KO) : pO && (pO.idx = XO), bK
      }), [NO]), YO = (0, bK.useCallback)(((OO, KO, pO, XO) => {
        const bK = hO.gameBridge.send("quickMoveInventoryItem", {
          slot: pO,
          start: OO,
          end: KO,
          amount: XO
        });
        null !== bK && NO(pO, bK)
      }), [NO]), wO = (0, bK.useCallback)(((OO, KO) => {
        var bK;
        ((OO, KO, pO) => {
          const XO = OO - (pO - IX.b.length);
          return !(!KO || XO < 0 || XO >= IX.b.length) && (0, yK.ub)(KO) !== IX.b[XO]
        })(KO, null === (bK = LO.current) || void 0 === bK ? void 0 : bK.name, wX().player.length) || (jb({
          e: OO,
          idx: KO,
          readInventory: wX,
          itemInfo: hO.gameBridge.latest("itemInfo"),
          draggedInfoRef: LO,
          specialItemRef: QO,
          moveAmtIntoSlot: EO,
          swapSlots: jK,
          moveIntoSlots: YO,
          removeItem: ib,
          removeDraggedInfoRef: TO,
          close: pO,
          canCraft: XO,
          variation: eO
        }), dO())
      }), [XO, pO, EO, YO, TO, jK, eO, dO]), iK = (0, bK.useRef)(0), rK = (0, bK.useRef)(null), PO = (0, bK.useRef)(null), mK = (0, bK.useRef)(null), sO = (0, bK.useRef)(new Set), HO = (0, bK.useRef)({
        x: 0,
        y: 0
      }), RO = (0, bK.useRef)({
        isTouch: !1,
        itemBeingDragged: !1
      }), SO = (0, bK.useCallback)((() => (mK.current = null, RO.current.itemBeingDragged = !1, clearTimeout(rK.current), !!PO.current && (PO.current = null, dO(), !0))), [dO]);
      (0, bK.useEffect)((() => {
        SO(), sO.current.clear()
      }), [KO]);
      const JO = OO => void 0 !== OO && (sO.current.has(OO) || null !== mK.current && OO !== mK.current),
        cK = OO => {
          RO.current.isTouch = (0, aX.t)(OO)
        },
        BO = (0, bK.useCallback)((OO => KO => {
          const XO = (0, aX.t)(KO);
          if (XO || IO(KO.pageX, KO.pageY), lO)
            if (JO(KO.pointerId)) void 0 !== KO.pointerId && sO.current.add(KO.pointerId);
            else {
              if (cK(KO), XO) {
                iK.current = KO.timeStamp, RO.current.itemBeingDragged = !0, mK.current = KO.pointerId;
                const pO = (0, aX.l)(wX(), OO);
                if (pO && pO.amount && pO.amount > 0) {
                  const pO = KO.pageX,
                    XO = KO.pageY,
                    bK = HO.current.x,
                    eO = HO.current.y;
                  clearTimeout(rK.current), rK.current = setTimeout((() => {
                    if (LO.current && LO.current.idx === OO && (Math.abs(pO - HO.current.x) < 20 && Math.abs(XO - HO.current.y) < 20 || bK === HO.current.x && eO === HO.current.y) && RO.current.itemBeingDragged) {
                      const OO = wX(),
                        pO = OO.creative && !OO.chest && LO.current.idx >= dp.h.numInvenSlots && null !== (0, aX.l)(OO, LO.current.idx).amount ? dp.h.maxItemStackSize : LO.current.amount;
                      PO.current = {
                        initTouchX: KO.pageX,
                        initTouchY: KO.pageY,
                        maxAmount: pO
                      }, LO.current.amount = Math.ceil(LO.current.amount / 2), VO.current.style.transform = "translate(0.5rem, 0.5rem)", FO(!0), dO()
                    }
                  }), 500)
                }
              }
              wO(KO, OO)
            }
          else OO === Fp.b && (0, aX.r)(KO) && pO()
        }), [IO, wO, lO, pO, dO]),
        ZO = (0, bK.useCallback)((OO => OO => {
          if (JO(OO.pointerId)) return;
          const KO = (0, aX.t)(OO);
          if (cK(OO), !SO()) {
            if (KO && LO.current && OO.timeStamp - iK.current > 150) {
              const KO = document.elementFromPoint(OO.clientX, OO.clientY);
              if (null !== KO) {
                const pO = KO.getAttribute("data-inven-idx");
                null !== pO ? wO(OO, parseInt(pO)) : KO.classList.contains("InventoryBackgroundScreen") && wO(OO, -1)
              }
            }
            IO(OO.pageX, OO.pageY)
          }
        }), [IO, wO, SO]);
      (0, bK.useEffect)((() => {
        let OO;
        const pO = ["pointerup", "pointercancel"],
          XO = OO => {
            sO.current.has(OO.pointerId) ? setTimeout((() => {
              sO.current.delete(OO.pointerId)
            }), 0) : OO.pointerId === mK.current && setTimeout((() => {
              mK.current === OO.pointerId && SO()
            }), 0)
          };
        if (KO) {
          for (const OO of pO) document.addEventListener(OO, XO, !0);
          if (!RO.current.isTouch) {
            const OO = HO.current;
            IO(OO.x, OO.y)
          }
          OO = OO => {
            OO.preventDefault(), JO(OO.pointerId) || (cK(OO), IO(OO.pageX, OO.pageY), PO.current && OO.pointerId === mK.current && (OO => {
              if (!LO.current) return PO.current = null, void dO();
              const {
                initTouchX: KO,
                maxAmount: pO
              } = PO.current, XO = (OO.pageX - KO) * PO.current.maxAmount / 160, bK = Math.ceil(pO / 2) + Math.ceil(XO);
              LO.current.amount = Math.min(pO, Math.max(1, bK)), dO()
            })(OO))
          }, document.addEventListener("pointermove", OO, !0)
        }
        return () => {
          document.removeEventListener("pointermove", OO, !0);
          for (const OO of pO) document.removeEventListener(OO, XO, !0)
        }
      }));
      const GO = (0, bK.useCallback)((() => {
          if (LO.current) {
            const OO = (0, aX.l)(wX(), LO.current.idx);
            (!YX(LO.current, OO) || OO.amount < LO.current.amount) && TO()
          }
        }), [TO]),
        qK = (0, bK.useCallback)((() => {
          const OO = LO.current;
          if (OO) {
            const KO = (0, aX.l)(wX(), OO.idx);
            YX(OO, KO) && (OO.attributes = KO.attributes)
          }
        }), []);
      return {
        draggedDomRef: VO,
        draggedInfoRef: LO,
        specialItemRef: QO,
        hoverInfoDomRef: zK,
        longHoldSplitInfoRef: PO,
        currHoveredIdx: CO,
        currHoveredDisplayInfo: MO,
        displayDraggedItemName: oO,
        forceRerenderIfVisible: dO,
        removeDraggedInfoRef: TO,
        checkDraggedItemConsistencyWithInven: GO,
        refreshDraggedAttributes: qK,
        swapSlots: jK,
        getPointerDownForIdx: BO,
        getPointerUpForIdx: ZO,
        getSetHovering: uO,
        setCurrHoveredDisplayInfo: aK,
        moveFollowerTo: IO
      }
    }
    class mb {
      constructor(OO) {
        this.snapshot = [], this.newSlots = new Set, this.update(OO, !1)
      }
      update(OO, KO) {
        const pO = OO.map((OO => {
          var KO;
          return OO ? {
            name: OO.name,
            amount: null !== (KO = OO.amount) && void 0 !== KO ? KO : 1
          } : null
        }));
        pO.forEach(((OO, pO) => {
          const XO = this.snapshot[pO],
            bK = (null === OO || void 0 === OO ? void 0 : OO.name) !== (null === XO || void 0 === XO ? void 0 : XO.name);
          (!OO || bK || OO.amount < XO.amount) && this.newSlots.delete(pO), KO && OO && (bK || OO.amount > XO.amount) && this.newSlots.add(pO)
        })), this.snapshot = pO
      }
      clearMarks() {
        this.newSlots.clear()
      }
      isNew(OO) {
        return this.newSlots.has(OO)
      }
    }
    const sX = (OO, KO, pO) => ({
      button: KO,
      shiftKey: pO,
      pageX: OO.clientX,
      pageY: OO.clientY,
      clientX: OO.clientX,
      clientY: OO.clientY,
      pointerType: "mouse"
    });

    function HX(OO) {
      const [KO, pO] = (0, bK.useState)(OO);
      return OO && !KO && pO(!0), (0, bK.useEffect)((() => {
        if (KO) return;
        let OO = !0;
        const XO = () => {
            OO && (OO = !1, pO(!0))
          },
          bK = "function" === typeof window.requestIdleCallback,
          eO = bK ? window.requestIdleCallback(XO, {
            timeout: 2e3
          }) : void 0,
          lO = setTimeout(XO, bK ? 2e3 : 1e3);
        return () => {
          OO = !1, clearTimeout(lO), void 0 !== eO && window.cancelIdleCallback(eO)
        }
      }), [KO]), KO
    }
    var RX = pO(1994);
    const SX = (0, bK.memo)((function(OO) {
      var KO;
      let {
        show: pO,
        onOpen: XO,
        onClose: eO,
        variation: vK
      } = OO;
      const MO = (0, bK.useRef)(null),
        aK = (0, bK.useRef)(null),
        oO = function(OO) {
          const [KO, pO] = (0, bK.useState)(!0), [XO, eO] = (0, bK.useState)(!1), lO = (0, bK.useRef)(null), vK = (0, bK.useRef)(null), hO = (0, CO.i)("_shield"), DO = (0, bK.useRef)(null), MO = (0, CO.i)("_health"), aK = (0, bK.useRef)(null);

          function oO(OO) {
            const KO = Date.now() + OO;
            KO < vK.current || (pO(!1), clearTimeout(lO.current), vK.current = KO, lO.current = setTimeout((() => {
              pO(!0)
            }), OO))
          }
          return (0, bK.useEffect)((() => {
            oO(Lp);
            const OO = FO.i.subscribe("requestingPlayVideoAd", (() => {
              oO(Lp)
            }));
            return () => {
              clearTimeout(lO.current), FO.i.unsubscribe(OO)
            }
          }), []), (0, bK.useEffect)((() => {
            (DO.current > hO || aK.current > MO) && oO(6e4), DO.current = hO, aK.current = MO
          }), [hO, MO]), (0, bK.useEffect)((() => {
            let KO = null;
            return OO ? KO = setTimeout((() => {
              eO(!0)
            }), 250) : eO(!1), () => {
              clearTimeout(KO)
            }
          }), [OO]), KO && XO
        }(pO);
      (0, IO.h)(ep.c, null);
      const VO = (0, ep.m)(),
        LO = VO.some((OO => OO.panel)),
        QO = (0, gK.e)("inventory", (OO => null !== OO.chest && (null !== OO.chest.ironChest || AX(OO.chest.numSlots)))),
        zK = HX(pO),
        AO = HX(pO),
        [fO, dO] = (0, bK.useState)([]),
        TO = (0, bK.useCallback)((OO => {
          dO((KO => KO.filter((KO => KO.id !== OO))))
        }), []),
        NO = (0, bK.useRef)(null),
        uO = (0, bK.useRef)(0),
        EO = (0, bK.useCallback)((() => {
          NO.current && (uO.current = NO.current.scrollTop), eO()
        }), [eO]),
        jK = (0, CO.i)("inventoryItemsMoveable"),
        YO = (0, CO.i)("canCraft"),
        {
          clientEscMenuOptions: wO
        } = (0, RO.l)(["clientEscMenuOptions"]),
        iK = (0, bK.useRef)(null);
      iK.current || (iK.current = new mb(hO.gameBridge.latest("inventory").player));
      const PO = iK.current,
        {
          draggedDomRef: mK,
          draggedInfoRef: sO,
          specialItemRef: HO,
          hoverInfoDomRef: SO,
          longHoldSplitInfoRef: JO,
          currHoveredIdx: cK,
          currHoveredDisplayInfo: BO,
          displayDraggedItemName: ZO,
          forceRerenderIfVisible: GO,
          removeDraggedInfoRef: qK,
          checkDraggedItemConsistencyWithInven: xK,
          refreshDraggedAttributes: nO,
          swapSlots: WO,
          getPointerDownForIdx: tK,
          getPointerUpForIdx: kK,
          getSetHovering: UO,
          setCurrHoveredDisplayInfo: OK,
          moveFollowerTo: KK
        } = PX({
          show: pO,
          close: EO,
          canCraft: YO,
          variation: vK,
          inventoryItemsMoveable: jK,
          setCraftFlyAnims: dO
        });
      (0, bK.useEffect)((() => {
        const OO = !pO && null !== hO.gameBridge.latest("inventory").chest;
        if (OO && hO.gameBridge.send("closeChest", null), pO || (PO.clearMarks(), UO(null)(!1)), OO) {
          Dp.c.play("chestClose", 1).rate(.8 + .4 * Math.random())
        }
      }), [pO]), (0, gK.b)("chestToggled", (OO => {
        if (OO ? XO() : pO && EO(), OO) {
          Dp.c.play("chestOpen", 1).rate(.8 + .4 * Math.random())
        }
      }));
      const pK = (0, RX.k)();
      (0, gK.b)("inventory", (OO => {
        let {
          player: KO
        } = OO;
        var XO, bK, eO;
        (PO.update(KO, !pO && pK.shown), HO.current) && (HO.current = (bK = HO.current, eO = null !== (XO = KO[HO.current.idx]) && void 0 !== XO ? XO : null, YX(bK, eO) ? (bK.attributes = eO.attributes, null !== eO.amount && bK.amount > eO.amount && (bK.amount = eO.amount), bK) : null));
        nO(), null !== cK && UO(cK)(!0), GO()
      })), (0, bK.useEffect)((() => (hO.gameBridge.send("setInventoryOpen", pO), () => {
        hO.gameBridge.send("setInventoryOpen", !1)
      })), [pO]);
      const XK = (OO, KO) => {
        if (OO === Fp.c) return void(OO => {
          const KO = HO.current;
          if (!KO || null === (0, aX.l)(hO.gameBridge.latest("inventory"), KO.idx)) return;
          const pO = OO ? Math.max(KO.amount, 1) : 1,
            XO = KO.amount - pO;
          if (!hO.gameBridge.send("removeInventoryItem", {
              slot: KO.idx,
              amount: pO,
              drop: !0
            })) return;
          const bK = HO.current;
          bK && (bK.amount = Math.min(bK.amount, XO), bK.amount <= 0 && (HO.current = null)), GO()
        })(KO);
        const pO = null === OO ? null : (0, aX.l)(hO.gameBridge.latest("inventory"), OO);
        if (null !== pO) {
          var XO, bK, eO;
          const lO = KO && null !== (XO = pO.amount) && void 0 !== XO ? XO : 1;
          hO.gameBridge.send("removeInventoryItem", {
            slot: OO,
            amount: lO,
            drop: !0
          }), OO === (null === (bK = sO.current) || void 0 === bK ? void 0 : bK.idx) && (sO.current.amount -= lO, sO.current.amount <= 0 && qK(), GO()), OO === (null === (eO = HO.current) || void 0 === eO ? void 0 : eO.idx) && (HO.current = null, GO())
        }
      };
      (0, gK.b)("inventoryDropRequested", (OO => {
        pO && cK !== Fp.c && XK(cK, OO)
      }));
      const bp = (OO, KO) => {
        let pO = KO;
        if (KO === Fp.c) {
          if (!HO.current) return;
          pO = HO.current.idx
        }
        const XO = WO(OO, pO);
        if (XO && sO.current && (sO.current.idx === pO ? sO.current.idx = OO : sO.current.idx === OO && (sO.current.idx = pO)), XO && KO === Fp.c) {
          const OO = (0, aX.l)(hO.gameBridge.latest("inventory"), pO);
          HO.current = OO ? {
            idx: pO,
            name: OO.name,
            attributes: OO.attributes,
            amount: OO.amount
          } : null
        }
        GO()
      };
      (0, gK.b)("numberKeyPressed", (OO => {
        null !== cK && pO && bp(OO - 1, cK)
      })), (0, bK.useEffect)((() => {
        pO || (HO.current = null, qK(), OK(null))
      }), [pO, qK, OK, HO]);
      const eK = HO.current;
      (0, bK.useEffect)((() => {
        cK === Fp.c && UO(Fp.c)(!0)
      }), [eK, cK, UO]);
      const lK = () => {
        xK(), nO(), GO()
      };
      (0, gK.b)("chestRefreshed", lK), (0, gK.b)("inventorySynced", lK);
      const [vp, CK] = (0, bK.useState)(new Map), hK = null !== (KO = vp.get(vK)) && void 0 !== KO ? KO : null, MK = (OO, KO) => {
        CK((pO => {
          const XO = pO.get(OO);
          return XO && XO.name === KO.name && XO.WH === KO.WH ? pO : new Map(pO).set(OO, KO)
        }))
      };
      (0, IO.f)("craftingRecipesEdited", (() => {
        GO()
      })), (0, IO.f)(Zp.c, (OO => {
        let {
          variation: KO,
          itemName: pO
        } = OO;
        MK(KO, {
          name: pO,
          WH: 0
        })
      }));
      const [ap, oK] = (0, bK.useState)(null), [FK, VK] = (0, bK.useState)(null);
      (0, gK.b)("enchantingTableOpened", (OO => {
        let {
          position: KO,
          blockName: pO
        } = OO;
        oK(KO), VK(pO)
      }));
      const [LK, QK] = (0, bK.useState)(""), [zp, AK] = (0, bK.useState)(null);
      (0, bK.useEffect)((() => {
        pO && NO.current && (NO.current.scrollTop = uO.current)
      }), [pO]);
      return (OO => {
        const KO = (0, bK.useRef)(OO);
        KO.current = OO, (0, bK.useEffect)((() => {
          if (!OO.show) return;
          const pO = (OO, pO, XO, bK) => {
              const {
                getPointerDownForIdx: eO,
                getPointerUpForIdx: lO
              } = KO.current;
              eO(OO)(sX(pO, XO, bK)), lO(OO)(sX(pO, XO, bK))
            },
            XO = {
              primary: (OO, KO) => {
                pO(OO, KO, 0, !1)
              },
              secondary: (OO, KO) => {
                pO(OO, KO, 2, !1)
              },
              quickMove: (OO, KO) => {
                pO(OO, KO, 0, !0)
              },
              dropHeld: (OO, pO) => {
                KO.current.getPointerDownForIdx(Fp.b)(sX(pO, OO ? 0 : 2, !1))
              },
              dropSlot: (OO, pO) => {
                KO.current.dropFromIdx(OO, pO)
              },
              swapWithHotbar: (OO, pO) => {
                KO.current.swapWithHotbar(OO, pO)
              },
              cancel: () => {
                KO.current.removeDraggedInfoRef()
              },
              isHolding: () => !!KO.current.draggedInfoRef.current,
              hasItemAt: OO => {
                const {
                  draggedInfoRef: pO,
                  specialItemRef: XO
                } = KO.current;
                if (OO === Fp.c) return !!XO.current;
                const bK = (0, aX.l)(hO.gameBridge.latest("inventory"), OO);
                return !!bK && (0, upO.d)(OO, (0, aX.e)(bK), [pO.current, XO.current]).shown
              },
              hover: (OO, pO) => {
                const {
                  moveFollowerTo: XO,
                  getSetHovering: bK
                } = KO.current;
                XO(pO.clientX, pO.clientY), bK(null !== OO && void 0 !== OO ? OO : void 0)(null !== OO, void 0, {
                  pageX: pO.clientX,
                  pageY: pO.clientY
                })
              },
              moveTo: OO => {
                KO.current.moveFollowerTo(OO.clientX, OO.clientY)
              },
              close: () => {
                KO.current.close()
              }
            };
          return (0, lp.i)(XO)
        }), [OO.show])
      })({
        show: pO,
        close: EO,
        draggedInfoRef: sO,
        specialItemRef: HO,
        getPointerDownForIdx: tK,
        getPointerUpForIdx: kK,
        getSetHovering: UO,
        moveFollowerTo: KK,
        removeDraggedInfoRef: qK,
        dropFromIdx: XK,
        swapWithHotbar: bp
      }), (0, bK.useEffect)((() => {
        FO.i.pl("inventoryDraggedItemUpdated", {
          draggedInfo: sO.current,
          specialItemInfo: HO.current,
          setHovered: UO,
          pointerDown: tK,
          pointerUp: kK,
          variation: YO ? vK : void 0,
          craftFlyAnims: fO
        })
      })), (0, DO.jsxs)(rK.b, {
        show: pO,
        style: {
          touchAction: pO ? "none" : void 0
        },
        children: [sO.current && (0, DO.jsx)(zX, {
          draggedInfo: sO.current,
          toAddRef: mK
        }), sO.current && ZO && (0, DO.jsx)(Ap, {
          className: "DraggedInvenItemName",
          displayInfo: rb(sO.current),
          domRef: null
        }), !sO.current && BO && (0, DO.jsx)(Ap, {
          displayInfo: BO,
          domRef: SO
        }), JO.current && sO.current && (0, DO.jsx)(fp, {
          info: JO.current,
          draggedInfo: sO.current
        }), fO.map((OO => (0, DO.jsx)(op.b, {
          anim: OO,
          onComplete: TO
        }, OO.id))), (0, DO.jsx)(lO.d, {
          show: pO,
          className: "InventoryBackgroundScreen",
          globallyUniqueKey: "Inventory",
          close: EO,
          togglePointerLock: !1,
          closeOnPressBackground: !1,
          preventContextMenu: !0,
          pointerDown: tK(Fp.b),
          pointerUp: kK(Fp.b),
          doGameplayStartStopOnShow: !0
        }), zK && (0, DO.jsxs)("div", {
          className: "EntireInventoryWrapper",
          children: [(0, DO.jsx)("div", {
            ref: MO,
            className: "InventoryAdOuter",
            children: (0, DO.jsx)(Mp.b, {
              info: {
                adType: "leaderboard",
                adId: 6,
                adAlias: "inventory"
              },
              sizeInfo: {
                parentRef: MO
              },
              verticalAlign: "start",
              showing: pO && oO,
              extraContrastBackgroundBox: "top",
              noFillShowBloxdAdProbability: 0,
              autoRefreshMode: "none"
            })
          }), (0, DO.jsxs)("div", {
            className: "InventoryWrapper",
            children: [(0, DO.jsxs)("div", {
              className: DK()("Inventory", {
                WithPanelButtons: LO,
                WideChestOpen: QO
              }),
              children: [(0, DO.jsx)("div", {
                className: "InventoryFiller"
              }), (0, DO.jsx)(hp, {
                show: pO,
                buttons: VO
              }), (0, DO.jsxs)("div", {
                className: "InvenBody",
                children: [(0, DO.jsx)(NX, {
                  variation: vK,
                  canCraft: YO,
                  show: pO,
                  creativeMounted: AO,
                  specialItemRef: HO,
                  draggedInfo: sO.current,
                  getSetHovering: UO,
                  getPointerDownForIdx: tK,
                  getPointerUpForIdx: kK,
                  enchantingTablePosition: ap,
                  enchantingTableBlockName: FK,
                  selectedCraftable: hK,
                  dispatchSelectedCraftable: OO => {
                    MK(vK, OO)
                  },
                  creativeScrollDiv: NO,
                  creativeSearchVal: LK,
                  setCreativeSearchVal: QK,
                  creativeCategory: zp,
                  setCreativeCategory: AK,
                  onCraft: function(OO, KO) {
                    let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
                    if (xK(), (OO || pO.length > 0) && dO((KO => {
                        const XO = [...KO],
                          bK = KO.filter((OO => "ingredient" === OO.kind)).length;
                        for (const OO of pO.slice(0, Math.max(0, 24 - bK))) XO.push({
                          id: (0, op.d)(),
                          ...OO,
                          to: OO.to
                        });
                        return OO && XO.push({
                          id: (0, op.d)(),
                          ...OO,
                          to: (0, aX.g)(OO.uq)
                        }), XO
                      })), null !== KO) {
                      var XO;
                      const OO = hO.gameBridge.latest("inventory");
                      (0, yK.ub)(null === (XO = (0, aX.l)(OO, KO)) || void 0 === XO ? void 0 : XO.name) ? tK(KO)({
                        button: 0,
                        shiftKey: !0
                      }): WO(KO, OO.selectedSlot)
                    }
                  }
                }), (0, DO.jsx)(gb, {
                  draggedInfo: sO.current,
                  specialItemInfo: HO.current,
                  craftFlyAnims: fO,
                  getSetHovering: UO,
                  getPointerDownForIdx: tK,
                  getPointerUpForIdx: kK,
                  variation: vK,
                  canCraft: YO,
                  isNewSlot: OO => wO.showNewItemIndicator && PO.isNew(OO)
                })]
              })]
            }), (0, DO.jsx)("div", {
              className: "InventoryAdOuter",
              children: (0, DO.jsx)("div", {
                ref: aK,
                className: "InventoryAd",
                children: (0, DO.jsx)("div", {
                  className: "InventoryAdInner"
                })
              })
            })]
          })]
        })]
      })
    }));
    var JX = pO(1253),
      cb = pO(142);
    const BX = (0, bK.memo)((function(OO) {
      let {
        show: KO,
        onOpen: pO,
        onClose: XO
      } = OO;
      const eO = (0, bK.useRef)(0),
        vK = () => (0, JX.c)() && !(0, JX.n)() && eO.current <= 2;
      KO = vK() && KO;
      const CO = () => {
        eO.current++, XO()
      };
      (0, IO.f)("ctrlCrouchWithoutFullscreen", (() => {
        vK() && pO()
      })), (0, IO.f)("displaymodeFullscreenChange", (OO => {
        KO && OO && CO()
      }));
      const hO = "crazygames" === cb.t;
      return (0, DO.jsx)(lO.d, {
        close: CO,
        escDoesExit: !0,
        show: KO,
        togglePointerLock: !1,
        globallyUniqueKey: "CantCtrlCrouchIfNotFullscreenComp",
        children: (0, DO.jsxs)("div", {
          className: "CantCtrlCrouchIfNotFullscreenComp SmallTextBold",
          children: [(0, DO.jsx)("div", {
            className: "CantCtrlCrouchHeader",
            children: "Go fullscreen to crouch with ctrl"
          }), hO && (0, DO.jsx)("div", {
            className: "CantCtrlCrouchInstructions SmallTextLight",
            children: "Press the crazygames full screen button"
          }), (0, DO.jsx)("div", {
            className: "CantCtrlCrouchSubtext SmallTextLight",
            children: "(Otherwise I can't stop CTRL+W closing the window!)"
          }), (0, DO.jsxs)("div", {
            className: "CantCtrlCrouchButtonsContainer",
            children: [!hO && (0, DO.jsx)(oO.m, {
              className: "CantCtrlCrouchButtonWrapper",
              onClick: () => {
                (0, JX.t)(), CO()
              },
              children: (0, DO.jsx)("div", {
                className: "CantCtrlCrouchButton",
                children: "Go Fullscreen"
              })
            }), (0, DO.jsx)(oO.I, {
              className: "CantCtrlCrouchButtonWrapper",
              onClick: () => {
                CO()
              },
              children: (0, DO.jsx)("div", {
                className: "CantCtrlCrouchButton",
                children: "Nevermind"
              })
            })]
          })]
        })
      })
    }));
    var ZX = pO(2862);
    pO(2871);
    const GX = (0, bK.memo)((function(OO) {
        let {
          show: KO,
          onOpen: pO,
          onClose: XO
        } = OO;
        const [eO, vK] = (0, bK.useState)(""), [CO, MO] = (0, bK.useState)(""), [aK, oO] = (0, bK.useState)(null), [FO, VO] = (0, bK.useState)(null), LO = (0, gK.i)("hiddenPlayerNames"), QO = {
          kind: "worldCodeLine",
          onSubmit: (OO, KO) => {
            XO(), hO.gameBridge.send("reportWorldCodeChat", {
              chatMsgId: FO,
              LX: OO,
              details: KO
            })
          }
        }, zK = {
          kind: "player",
          shownPlayerName: (0, KK.f)(eO, LO),
          onSubmit: (OO, KO) => {
            XO(), (0, ZX.g)({
              playerId: CO,
              playerName: eO,
              chatMsgId: FO,
              policyId: OO,
              details: KO
            })
          }
        };
        return (0, IO.f)("OpenReportMenu", (OO => {
          let {
            playerEId: KO,
            playerName: XO,
            Tl: bK,
            serverChatMsgId: eO
          } = OO;
          MO(KO), vK(XO), oO(bK), VO(eO), pO()
        })), (0, DO.jsx)(lO.d, {
          show: KO,
          close: XO,
          padShowsHud: !0,
          togglePointerLock: !1,
          escDoesExit: !0,
          centerChildren: !1,
          className: "MakeReportBackgroundScreen",
          globallyUniqueKey: "MakeReportComponent",
          children: (0, DO.jsx)("div", {
            className: "ReportMenu",
            children: KO && (0, DO.jsx)(ZX.c, {
              reported: null === CO ? QO : zK,
              chatMessage: aK,
              inGame: !0,
              onCancel: XO
            })
          })
        })
      })),
      qb = (0, bK.memo)((function(OO) {
        let {
          show: KO,
          onOpen: pO,
          onClose: XO
        } = OO;
        const [eO, vK] = (0, bK.useState)(null), [CO, MO] = (0, bK.useState)(0);
        (0, IO.f)("OpenDiscordReportBox", (OO => {
          hO.gameBridge.send("requestDiscordReportKey", OO), MO(0), pO()
        }));
        return (0, IO.f)("setDiscordReportKey", (OO => {
          vK(OO)
        })), (0, DO.jsx)(lO.d, {
          show: KO,
          close: () => {
            XO(), vK(null), MO(0)
          },
          padShowsHud: !0,
          togglePointerLock: !1,
          escDoesExit: !0,
          centerChildren: !1,
          className: "MakeDiscordReportBackgroundScreen",
          globallyUniqueKey: "MakeDiscordReportComponent",
          children: (0, DO.jsxs)("div", {
            className: "ReportKeyBox",
            children: [(0, DO.jsx)("div", {
              className: "ReportKeyBoxHeader SmallTextBold",
              children: "Report via Discord"
            }), (0, DO.jsxs)("div", {
              className: "ReportKeyBoxDescription SmallTextLight",
              children: ["Hacking/auto-clicking and explicit build reports must be made via discord.", (0, DO.jsx)("br", {}), (0, DO.jsx)("br", {}), "1. Join the Bloxd discord server", " ", (0, DO.jsx)("a", {
                href: "https://discord.gg/playbloxd",
                target: "_blank",
                rel: "noreferrer",
                children: "here"
              }), ".", (0, DO.jsx)("br", {}), "2. Copy the Report Key below", (0, DO.jsx)("br", {}), "3. Raise a report ticket (and include the report key!)", (0, DO.jsx)("div", {
                className: "ReportKeyBoxSubheader SmallTextBold",
                children: "Report Key:"
              })]
            }), (0, DO.jsxs)("div", {
              className: "ReportKeyInnerWrapper",
              children: [(0, DO.jsx)("div", {
                className: "ReportKeyInner",
                children: null !== eO && void 0 !== eO ? eO : "Loading report key..."
              }), (0, DO.jsx)(oO.d, {
                className: "ReportKeyCopyButton",
                onClick: () => {
                  navigator.clipboard.writeText(eO).catch((OO => {
                    console.error("Failed to copy report key:", OO)
                  })), MO(Date.now())
                },
                disabled: Date.now() - CO < 1e3 || !eO,
                children: Date.now() - CO < 1e3 ? "Copied" : "Copy"
              })]
            })]
          })
        })
      }));
    var xb = pO(1136);
    const nX = {
        "game:sandbox": {
          "customLobbyBlock:classicLobbySpawn": {
            blocks: ["Spawn Block (White)"],
            tooltip: "customLobbyBlock:classicLobbySpawnDescription"
          }
        },
        "game:bedwars": {
          "customLobbyBlock:bedwarsBeds": {
            blocks: ["Red Bed", "Blue Bed", "Lime Bed", "Yellow Bed", "Cyan Bed", "White Bed", "Pink Bed", "Gray Bed"],
            tooltip: "customLobbyBlock:bedwarsBedsDescription"
          },
          "customLobbyBlock:bedwarsChests": {
            blocks: ["Chest", "Moonstone Chest"],
            tooltip: "customLobbyBlock:bedwarsChestsDescription"
          },
          "customLobbyBlock:bedwarsTeamSpawns": {
            blocks: ["Spawn Block (Red)", "Spawn Block (Blue)", "Spawn Block (Lime)", "Spawn Block (Yellow)", "Spawn Block (Cyan)", "Spawn Block (White)", "Spawn Block (Pink)", "Spawn Block (Gray)"],
            tooltip: "customLobbyBlock:bedwarsTeamSpawnsDescription"
          },
          "customLobbyBlock:bedwarsShopkeeperSpawns": {
            blocks: ["Wizard Shop Spawn Block", "Trader Shop Spawn Block"],
            tooltip: "customLobbyBlock:bedwarsShopkeeperSpawnsDescription"
          },
          "customLobbyBlock:bedwarsGenerators": {
            blocks: ["Generator Spawn Block (Red)", "Generator Spawn Block (Blue)", "Generator Spawn Block (Lime)", "Generator Spawn Block (Yellow)", "Generator Spawn Block (Cyan)", "Generator Spawn Block (White)", "Generator Spawn Block (Pink)", "Generator Spawn Block (Gray)", "Generator Spawn Block (Diamond)", "Generator Spawn Block (Moonstone)", "Generator Spawn Block (Ore)"],
            tooltip: "customLobbyBlock:bedwarsGeneratorsDescription"
          }
        },
        "game:skyWars": {
          "customLobbyBlock:skywarsBlocks": {
            blocks: ["Spawn Block (White)", "Chest", "Moonstone Chest"],
            tooltip: "customLobbyBlock:skywarsBlocksDescription"
          }
        },
        "game:cubeWarfare": {
          "customLobbyBlock:cubeWarfareSpawns": {
            blocks: ["Spawn Block (White)"],
            tooltip: "customLobbyBlock:cubeWarfareSpawnsDescription"
          }
        },
        "game:bridge": {
          "customLobbyBlock:bridgeSpawns": {
            blocks: ["Spawn Block (Red)", "Spawn Block (Blue)"],
            tooltip: "customLobbyBlock:bridgeSpawnsDescription"
          },
          "customLobbyBlock:bridgeGoals": {
            blocks: ["Goal Block (Red)", "Goal Block (Blue)"],
            tooltip: "customLobbyBlock:bridgeGoalsDescription"
          }
        },
        "game:rocketSpleef": {
          "customLobbyBlock:rocketSpleefSpawns": {
            blocks: ["Spawn Block (White)", "Drop Location Block"],
            tooltip: "customLobbyBlock:rocketSpleefSpawnsDescription"
          }
        },
        "game:rocketObby": {
          "customLobbyBlock:rocketObbyBlocks": {
            blocks: ["Spawn Block (White)", "Checkpoint Block", "Finish Block", "Obby Death Block", "Obby Absorb Block", "Obby Absorb Death Block"],
            tooltip: "customLobbyBlock:rocketObbyBlocksDescription"
          }
        }
      },
      WX = (0, bK.memo)((function(OO) {
        let {
          show: KO,
          onOpen: pO,
          onClose: XO
        } = OO;
        const [eO, vK] = (0, bK.useState)(null), CO = (0, bK.useRef)(0), MO = (0, bK.useRef)(null), {
          t: aK
        } = (0, nO.D)();
        (0, IO.f)("EditCustomLobbyBlock", (OO => {
          let {
            pos: KO
          } = OO;
          vK(KO), null !== KO && pO(), MO.current.scrollTo(0, CO.current)
        }));
        const oO = OO => {
          hO.gameBridge.send("setCustomLobbyBlock", {
            pos: eO,
            blockName: OO
          }), XO()
        };
        return (0, DO.jsx)(lO.d, {
          className: "CustomLobbyBlockEditorOuter",
          close: XO,
          escDoesExit: !0,
          show: KO,
          togglePointerLock: !1,
          globallyUniqueKey: "CustomLobbyBlockEditor",
          children: (0, DO.jsx)("div", {
            className: "CustomLobbyBlockEditor",
            ref: MO,
            onScroll: () => {
              CO.current = MO.current.scrollTop
            },
            children: (0, DO.jsx)("div", {
              className: "CustomLobbyBlockGameContainer",
              children: Object.entries(nX).map((OO => {
                let [KO, pO] = OO;
                return (0, DO.jsxs)("div", {
                  className: "CustomLobbyBlockGame",
                  children: [(0, DO.jsx)("h2", {
                    className: "CustomLobbyBlockGameTitle",
                    children: aK(KO)
                  }), (0, DO.jsx)("div", {
                    className: "CustomLobbyBlockCategoryContainer",
                    children: Object.entries(pO).map((OO => {
                      let [KO, {
                        tooltip: pO,
                        blocks: XO
                      }] = OO;
                      return (0, DO.jsxs)("div", {
                        className: "CustomLobbyBlockCategory",
                        children: [(0, DO.jsxs)("h3", {
                          className: "CustomLobbyBlockCategoryTitle",
                          children: [aK(KO), (0, DO.jsx)(qK.c, {
                            hoverInfo: aK(pO),
                            className: "CustomLobbyBlockTooltip"
                          })]
                        }), (0, DO.jsx)("div", {
                          className: "CustonLobbyBlockContainer",
                          children: XO.map((OO => (0, DO.jsx)(tb, {
                            blockName: OO,
                            selectBlock: oO
                          }, OO)))
                        })]
                      }, KO)
                    }))
                  })]
                }, KO)
              }))
            })
          })
        })
      })),
      tb = (0, bK.memo)((function(OO) {
        var KO;
        let {
          blockName: pO,
          selectBlock: XO
        } = OO;
        const bK = (0, lX.c)(pO),
          eO = null !== (KO = void 0 === bK ? void 0 : (0, eX.displayNameOf)(bK)) && void 0 !== KO ? KO : pO,
          lO = void 0 === bK ? void 0 : (0, eX.descriptionOf)(bK);
        return (0, DO.jsx)(qK.g, {
          tooltipInner: (0, DO.jsxs)("div", {
            className: "CustomLobbyBlockNameTooltip",
            children: [(0, DO.jsx)("div", {
              className: "CustomLobbyBlockName",
              children: (0, DO.jsx)(NO.d, {
                text: eO
              })
            }), lO && (0, DO.jsx)("div", {
              className: "CustomLobbyBlockDescription",
              children: (0, DO.jsx)(NO.d, {
                text: lO
              })
            })]
          }),
          children: (0, DO.jsx)("div", {
            className: "CustomLobbyBlockButton",
            onClick: () => XO(pO),
            children: (0, DO.jsx)(Cp.b, {
              itemName: pO,
              amount: 1
            })
          })
        }, pO)
      }));
    var kb = pO(2332),
      UX = pO(3509),
      Ob = pO(35338);

    function Kb() {
      const OO = (0, gK.i)("itemInfo");
      return (0, bK.useMemo)((() => function(OO) {
        return {
          getDefaultItemStat(KO, pO) {
            var XO;
            const bK = OO[KO];
            return "description" === pO ? null === bK || void 0 === bK ? void 0 : bK.description : null !== (XO = null === bK || void 0 === bK ? void 0 : bK.displayName) && void 0 !== XO ? XO : KO
          }
        }
      }(OO)), [OO])
    }
    const pb = (0, bK.memo)((function(OO) {
        var KO, pO, XO, eO, vK, CO, hO, MO, aK, oO, FO, VO, QO, zK, AO, fO, dO, TO, NO, yK, gK, uO, EO;
        let {
          togglePointerLock: jK,
          show: YO,
          onOpen: wO,
          onClose: iK
        } = OO;
        const {
          t: rK
        } = (0, nO.D)(), PO = Kb(), mK = (0, bK.useRef)(null), sO = (0, bK.useRef)(UX.b.MobHungerLevel.Hungry), HO = (0, bK.useRef)(null), RO = (0, kb.b)(), SO = (0, bK.useRef)(null), JO = (0, bK.useRef)(null), cK = mK.current;
        (0, bK.useEffect)((() => {
          if (!YO) return;
          const OO = Ob.e.openPet(SO.current);
          return JO.current = OO, () => {
            OO.close(), JO.current = null
          }
        }), [YO]), (0, bK.useEffect)((() => {
          YO && cK && JO.current.show(function(OO) {
            var KO;
            let {
              mobType: pO,
              mobSettings: XO
            } = OO;
            return {
              mobType: pO,
              variation: null !== (KO = XO.variation) && void 0 !== KO ? KO : "default",
              metaInfo: XO.metaInfo,
              tamed: !(0, zb.I)(XO.ownerDbId)
            }
          }(cK))
        }), [YO, cK]), (0, bK.useEffect)((() => {
          const OO = () => {
            var OO;
            const KO = UX.b.getMobHungerLevel(null === (OO = mK.current) || void 0 === OO ? void 0 : OO.mobSettings.petInfo.lastFedAt);
            if (KO !== sO.current && (sO.current = KO, RO()), HO.current) {
              var pO;
              const OO = Date.now(),
                KO = UX.b.getNextStateAt(null === (pO = mK.current) || void 0 === pO ? void 0 : pO.mobSettings.petInfo.lastFedAt);
              let XO = Math.floor((KO - OO) / 1e3),
                bK = "";
              if (XO > 3600) {
                bK += Math.floor(XO / 60 / 60).toString().padStart(2, "0"), bK += ":", XO %= 3600
              }
              const eO = XO % 60;
              bK += Math.floor(XO / 60).toString().padStart(2, "0"), bK += ":", bK += eO.toString().padStart(2, "0"), HO.current.textContent = bK
            }
          };
          OO();
          const KO = setInterval(OO, 250);
          return () => {
            clearInterval(KO)
          }
        }), [cK, RO]), (0, IO.f)("showPetUi", (OO => {
          let {
            mobType: KO,
            mobSettings: pO
          } = OO;
          mK.current = {
            mobType: KO,
            mobSettings: pO
          }, YO || wO()
        }));
        const BO = null === (KO = mK.current) || void 0 === KO ? void 0 : KO.mobSettings.health,
          ZO = null === (pO = mK.current) || void 0 === pO ? void 0 : pO.mobSettings.maxHealth,
          GO = UX.b.getFriendshipLevelInfo(null !== (XO = null === (eO = mK.current) || void 0 === eO ? void 0 : eO.mobSettings.petInfo.friendshipPoints) && void 0 !== XO ? XO : 0);
        return (0, DO.jsx)(lO.d, {
          className: "PetUIOuter",
          close: iK,
          escDoesExit: !0,
          show: YO,
          togglePointerLock: jK,
          forcePointerUnlock: YO,
          globallyUniqueKey: "PetUI",
          children: (0, DO.jsx)("div", {
            className: "PetUI",
            children: (0, DO.jsxs)("div", {
              className: "PetUIContainer",
              children: [(0, DO.jsxs)("div", {
                className: "PetUILeftSideContainer",
                children: [(0, DO.jsx)("div", {
                  className: "PetUITitle",
                  children: null !== (vK = null === (CO = mK.current) || void 0 === CO ? void 0 : CO.mobSettings.name) && void 0 !== vK ? vK : "Your Pet"
                }), (0, DO.jsx)("div", {
                  className: "PetUICanvasContainer",
                  ref: SO
                })]
              }), (0, DO.jsxs)("div", {
                className: "PetUIInformation",
                children: [!(0, zb.I)(null === (hO = mK.current) || void 0 === hO ? void 0 : hO.mobSettings.petInfo.friendshipPoints) && (0, DO.jsxs)("div", {
                  className: "PetUIFriendshipPoints",
                  children: [(0, DO.jsx)("div", {
                    className: "PetUIFriendshipPointsTitle",
                    children: rK("mobAiPlugin:friendshipTitle")
                  }), (0, DO.jsx)("div", {
                    className: "PetUIFriendshipHearts",
                    children: UX.b.getIconsFromFriendshipPoints(null !== (MO = mK.current.mobSettings.petInfo.friendshipPoints) && void 0 !== MO ? MO : 0).map(((OO, KO) => (0, DO.jsx)("div", {
                      className: "PetUIFriendshipHeart",
                      children: (0, DO.jsx)(Cp.b, {
                        itemName: OO,
                        amount: 1
                      })
                    }, KO)))
                  }), (0, DO.jsx)("div", {
                    className: "PetUIFriendshipBar",
                    children: (0, DO.jsxs)("div", {
                      className: "PetUIFriendshipBarBackground",
                      children: [(0, DO.jsx)("div", {
                        className: "PetUIFriendshipBarForeground",
                        style: {
                          transform: `scaleX(${GO.totalPointsForNextLevel>0?Math.max(GO.pointsIntoCurrentLevel/GO.totalPointsForNextLevel,0):1})`,
                          transformOrigin: "left center"
                        }
                      }), (0, DO.jsx)("div", {
                        className: "PetUIFriendshipBarText",
                        children: GO.totalPointsForNextLevel > 0 ? ` ${Math.ceil(GO.pointsIntoCurrentLevel)}/${Math.ceil(GO.totalPointsForNextLevel)}` : Math.ceil(GO.pointsIntoCurrentLevel)
                      })]
                    })
                  })]
                }), (0, DO.jsxs)("div", {
                  className: "PetUIHungry",
                  children: [(0, DO.jsx)("div", {
                    className: "PetUIHungryTitle",
                    children: rK("mobAiPlugin:hungerTitle")
                  }), (0, DO.jsx)("div", {
                    className: "PetUIHungryCurrent",
                    children: UX.b.hungerLevelIcons[sO.current].map(((OO, KO) => (0, DO.jsx)("div", {
                      className: "PetUIHungryIcon",
                      children: (0, DO.jsx)(Cp.b, {
                        itemName: OO,
                        amount: 1
                      })
                    }, KO)))
                  }), (0, DO.jsxs)("div", {
                    className: "PetUIHungryLevel",
                    children: [rK(UX.b.hungerLevelTranslations[sO.current].translationKey), sO.current !== UX.b.MobHungerLevel.Starving && !(0, zb.I)(null === (aK = mK.current) || void 0 === aK ? void 0 : aK.mobSettings.petInfo.lastFedAt) && (0, DO.jsxs)("div", {
                      className: "PetUIHungryNext",
                      children: [rK("mobAiPlugin:nextFeedIn", {
                        state: rK(UX.b.hungerLevelTranslations[sO.current + 1].translationKey)
                      }), ":", " ", (0, DO.jsx)("span", {
                        ref: HO
                      })]
                    })]
                  })]
                }), (0, DO.jsx)(qK.g, {
                  delayShow: 0,
                  delayHide: 0,
                  tooltipInner: (0, DO.jsx)("div", {
                    className: "PetUIQuickStatsTooltip",
                    children: rK("mobAiPlugin:healthTooltip")
                  }),
                  children: (0, DO.jsxs)("div", {
                    className: DK()("PetUIQuickStatsItem", {
                      Disabled: (0, zb.I)(BO) || (0, zb.I)(ZO)
                    }),
                    children: [(0, DO.jsx)("div", {
                      className: "PetUIQuickStatsIcon",
                      children: (0, DO.jsx)(Cp.b, {
                        itemName: "Health",
                        amount: 1
                      })
                    }), (0, DO.jsx)("div", {
                      className: "PetUIQuickStatsValue",
                      children: (0, zb.I)(BO) || (0, zb.I)(ZO) ? "" : (0, DO.jsxs)(DO.Fragment, {
                        children: [Math.ceil(BO), (0, DO.jsxs)("span", {
                          className: "PetUIQuickStatsValueMax",
                          children: ["/", Math.ceil(ZO)]
                        })]
                      })
                    })]
                  })
                }), (0, DO.jsx)(qK.g, {
                  delayShow: 0,
                  delayHide: 0,
                  tooltipInner: (0, DO.jsx)("div", {
                    className: "PetUIQuickStatsTooltip",
                    children: rK("mobAiPlugin:attackDamageTooltip")
                  }),
                  children: (0, DO.jsxs)("div", {
                    className: DK()("PetUIQuickStatsItem", {
                      Disabled: (0, zb.I)(null === (oO = mK.current) || void 0 === oO ? void 0 : oO.mobSettings.attackDamage) || mK.current.mobSettings.attackDamage <= 0
                    }),
                    children: [(0, DO.jsx)("div", {
                      className: "PetUIQuickStatsIcon",
                      children: (0, DO.jsx)(Cp.b, {
                        itemName: "Iron Sword",
                        amount: 1
                      })
                    }), (0, DO.jsx)("div", {
                      className: "PetUIQuickStatsValue",
                      children: (null === (FO = mK.current) || void 0 === FO ? void 0 : FO.mobSettings.attackDamage) || ""
                    })]
                  })
                }), (0, DO.jsx)(qK.g, {
                  delayShow: 0,
                  delayHide: 0,
                  tooltipInner: (0, DO.jsx)("div", {
                    className: "PetUIQuickStatsTooltip",
                    children: rK("mobAiPlugin:secondaryAttackDamageTooltip")
                  }),
                  children: (0, DO.jsxs)("div", {
                    className: DK()("PetUIQuickStatsItem", {
                      Disabled: (0, zb.I)(null === (VO = mK.current) || void 0 === VO ? void 0 : VO.mobSettings.secondaryAttackDamage) || mK.current.mobSettings.secondaryAttackDamage <= 0
                    }),
                    children: [(0, DO.jsx)("div", {
                      className: "PetUIQuickStatsIcon",
                      children: (0, DO.jsx)(Cp.b, {
                        itemName: "Stone Crossbow",
                        amount: 1
                      })
                    }), (0, DO.jsx)("div", {
                      className: "PetUIQuickStatsValue",
                      children: (null === (QO = mK.current) || void 0 === QO ? void 0 : QO.mobSettings.secondaryAttackDamage) || ""
                    })]
                  })
                }), (0, DO.jsx)(qK.g, {
                  delayShow: 0,
                  delayHide: 0,
                  tooltipInner: (0, DO.jsx)("div", {
                    className: "PetUIQuickStatsTooltip",
                    children: rK("mobAiPlugin:speedTooltip")
                  }),
                  children: (0, DO.jsxs)("div", {
                    className: DK()("PetUIQuickStatsItem", {
                      Disabled: (0, zb.I)(null === (zK = mK.current) || void 0 === zK ? void 0 : zK.mobSettings.baseRunningSpeed)
                    }),
                    children: [(0, DO.jsx)("div", {
                      className: "PetUIQuickStatsIcon",
                      children: (0, DO.jsx)(Cp.b, {
                        itemName: "Speed",
                        amount: 1
                      })
                    }), (0, DO.jsx)("div", {
                      className: "PetUIQuickStatsValue",
                      children: null !== (AO = null === (fO = mK.current) || void 0 === fO || null === (dO = fO.mobSettings.baseRunningSpeed) || void 0 === dO ? void 0 : dO.toFixed(2)) && void 0 !== AO ? AO : ""
                    })]
                  })
                }), (0, DO.jsx)(qK.g, {
                  delayShow: 0,
                  delayHide: 0,
                  tooltipInner: (0, DO.jsx)("div", {
                    className: "PetUIQuickStatsTooltip",
                    children: rK("mobAiPlugin:saddledTooltip")
                  }),
                  children: (0, DO.jsxs)("div", {
                    className: DK()("PetUIQuickStatsItem", {
                      Disabled: "Saddled" !== (null === (TO = mK.current) || void 0 === TO ? void 0 : TO.mobSettings.metaInfo)
                    }),
                    children: [(0, DO.jsx)("div", {
                      className: "PetUIQuickStatsIcon",
                      children: (0, DO.jsx)(Cp.b, {
                        itemName: "Saddle",
                        amount: 1
                      })
                    }), (0, DO.jsx)("div", {
                      className: "PetUIQuickStatsValue",
                      children: "Saddled" === (null === (NO = mK.current) || void 0 === NO ? void 0 : NO.mobSettings.metaInfo) ? (0, DO.jsx)(LO.d, {
                        name: "check"
                      }) : ""
                    })]
                  })
                }), !(0, zb.I)(null === (yK = mK.current) || void 0 === yK ? void 0 : yK.mobSettings.tameInfo) && (0, DO.jsxs)(DO.Fragment, {
                  children: [(0, DO.jsxs)("div", {
                    className: "PetUIFood",
                    children: [(0, DO.jsxs)("div", {
                      className: "PetUIFoodSection",
                      children: [(0, DO.jsx)("div", {
                        className: "PetUIFoodTitle",
                        children: (0, DO.jsx)(be, {
                          icon: "Pixelated Heart",
                          displayName: {
                            translationKey: "mobAiPlugin:superlikedFoodTitle"
                          },
                          description: null,
                          tintColor: UX.b.feedTextColours[UX.b.MobFoodType.Superliked],
                          className: "PetUIFoodTitleIcon"
                        })
                      }), (0, DO.jsx)("div", {
                        className: "PetUIFoodItems",
                        children: (0, DO.jsx)("div", {
                          className: "PetUIFoodItem",
                          children: mK.current.mobSettings.petInfo.superlikedFoodKnown ? (0, DO.jsx)(Xb, {
                            food: mK.current.mobSettings.petInfo.superlikedFood
                          }) : (0, DO.jsx)(be, {
                            icon: "Question Mark",
                            displayName: {
                              translationKey: "mobAiPlugin:superlikedFoodUnknownTitle"
                            },
                            description: {
                              translationKey: "mobAiPlugin:superlikedFoodUnknownDescription"
                            }
                          })
                        })
                      })]
                    }), (0, DO.jsxs)("div", {
                      className: "PetUIFoodSection",
                      children: [(0, DO.jsx)("div", {
                        className: "PetUIFoodTitle",
                        children: (0, DO.jsx)(be, {
                          icon: "Pixelated Heart",
                          displayName: {
                            translationKey: "mobAiPlugin:likedFoodTitle"
                          },
                          description: null,
                          tintColor: UX.b.feedTextColours[UX.b.MobFoodType.Liked],
                          className: "PetUIFoodTitleIcon"
                        })
                      }), (0, DO.jsx)("div", {
                        className: "PetUIFoodItems",
                        children: null === (gK = mK.current.mobSettings.tameInfo.likedFoods) || void 0 === gK ? void 0 : gK.filter((OO => !mK.current.mobSettings.petInfo.superlikedFoodKnown || OO !== mK.current.mobSettings.petInfo.superlikedFood)).map((OO => (0, DO.jsx)(Xb, {
                          food: OO
                        }, OO)))
                      })]
                    }), (0, DO.jsxs)("div", {
                      className: "PetUIFoodSection",
                      children: [(0, DO.jsx)("div", {
                        className: "PetUIFoodTitle",
                        children: (0, DO.jsx)(be, {
                          icon: "Pixelated Heart",
                          displayName: {
                            translationKey: "mobAiPlugin:neutralFoodTitle"
                          },
                          description: null,
                          tintColor: UX.b.feedTextColours[UX.b.MobFoodType.Neutral],
                          className: "PetUIFoodTitleIcon"
                        })
                      }), (0, DO.jsx)("div", {
                        className: "PetUIFoodItems",
                        children: null === (uO = mK.current.mobSettings.tameInfo.neutralFoods) || void 0 === uO ? void 0 : uO.map((OO => (0, DO.jsx)(Xb, {
                          food: OO
                        }, OO)))
                      })]
                    }), (0, DO.jsxs)("div", {
                      className: "PetUIFoodSection",
                      children: [(0, DO.jsx)("div", {
                        className: "PetUIFoodTitle",
                        children: (0, DO.jsx)(be, {
                          icon: "Pixelated Heart",
                          displayName: {
                            translationKey: "mobAiPlugin:dislikedFoodTitle"
                          },
                          description: null,
                          tintColor: UX.b.feedTextColours[UX.b.MobFoodType.Disliked],
                          className: "PetUIFoodTitleIcon"
                        })
                      }), (0, DO.jsx)("div", {
                        className: "PetUIFoodItems",
                        children: null === (EO = mK.current.mobSettings.tameInfo.dislikedFoods) || void 0 === EO ? void 0 : EO.map((OO => (0, DO.jsx)(Xb, {
                          food: OO
                        }, OO)))
                      })]
                    })]
                  }), mK.current.mobSettings.tameInfo.levelUpBonuses && (0, DO.jsx)("div", {
                    className: "PetUIFeedDrops",
                    children: Array.from({
                      length: UX.b.MAX_LEVEL + 1
                    }).map(((OO, KO) => {
                      const pO = KO;
                      if (0 === pO) return null;
                      const XO = mK.current.mobSettings.tameInfo.levelUpBonuses[pO],
                        bK = UX.b.getBonusDisplayInfo(PO, mK.current.mobSettings, mK.current.mobType, XO);
                      return (0, DO.jsxs)("div", {
                        className: DK()("PetUIFeedDropContainer", {
                          Selected: pO === UX.b.getFriendshipLevelInfo(mK.current.mobSettings.petInfo.friendshipPoints).level
                        }),
                        children: [(0, DO.jsx)("div", {
                          className: "PetUIFeedDropHearts",
                          children: Array.from({
                            length: pO
                          }).map(((OO, KO) => (0, DO.jsx)("div", {
                            className: "PetUIFeedDropHeart",
                            children: (0, DO.jsx)(Cp.b, {
                              itemName: "Friendship",
                              amount: 1
                            })
                          }, `${pO}-${KO}`)))
                        }), (0, DO.jsx)("div", {
                          className: "PetUIFeedDropItems",
                          children: bK && (0, DO.jsx)(be, {
                            icon: bK.icon,
                            displayName: bK.displayName,
                            description: bK.description
                          })
                        })]
                      }, pO)
                    }))
                  })]
                })]
              })]
            })
          })
        })
      })),
      Xb = (0, bK.memo)((function(OO) {
        let {
          food: KO,
          includeDescription: pO = !1
        } = OO;
        const XO = Kb(),
          bK = XO.getDefaultItemStat(KO, "displayName"),
          eO = XO.getDefaultItemStat(KO, "description");
        return (0, DO.jsx)(be, {
          icon: KO,
          displayName: bK,
          description: pO ? eO : null
        })
      })),
      be = (0, bK.memo)((function(OO) {
        let {
          icon: KO,
          displayName: pO,
          description: XO,
          tintColor: bK,
          className: eO = "PetUIFoodItem"
        } = OO;
        return (0, DO.jsx)(qK.g, {
          delayHide: 0,
          delayShow: 0,
          tooltipInner: (0, DO.jsxs)("div", {
            className: "PetUIFoodItemTooltip",
            children: [(0, DO.jsx)("div", {
              className: "PetUIFoodItemName",
              children: (0, DO.jsx)(NO.d, {
                text: pO
              })
            }), XO && (0, DO.jsx)("div", {
              className: "PetUIFoodItemDescription",
              children: (0, DO.jsx)(NO.d, {
                text: XO
              })
            })]
          }),
          children: (0, DO.jsx)("div", {
            className: eO,
            children: (0, DO.jsx)(Cp.b, {
              itemName: KO,
              amount: 1,
              tintColor: bK
            })
          })
        })
      }));
    var eb = pO(3006),
      lb = pO(1008),
      ve = pO(1098),
      Cb = pO(35356),
      hb = pO(35350),
      Db = pO(886),
      Mb = pO(1193),
      ae = pO(1187),
      ob = pO(1925);

    function Fb(OO) {
      let {
        peers: KO
      } = OO;
      const [pO, XO] = (0, bK.useState)(null), eO = (0, gK.i)("players");
      return (0, DO.jsx)("div", {
        className: "CodeEditorPresence",
        children: KO.map((OO => {
          var KO, bK;
          const lO = null !== (KO = null === (bK = eO.byId[OO.playerId]) || void 0 === bK ? void 0 : bK.cosmetics) && void 0 !== KO ? KO : {};
          return (0, DO.jsxs)("div", {
            className: DK()("PresenceIcon", {
              Viewer: !OO.isEditor
            }),
            style: {
              backgroundColor: OO.colour
            },
            onMouseEnter: () => {
              XO(OO.playerId)
            },
            onMouseLeave: () => {
              XO(null)
            },
            children: [(0, DO.jsx)(ob.c, {
              cosmetics: lO
            }), pO === OO.playerId && (0, DO.jsx)("div", {
              className: "PresenceTooltip",
              style: {
                backgroundColor: OO.colour
              },
              children: OO.playerName
            })]
          }, OO.playerId)
        }))
      })
    }
    var Vb = pO(570),
      Lb = pO(35348),
      Qb = pO(35095),
      ze = pO(35362);

    function Ab(OO) {
      const KO = OO.split("/"),
        pO = [];
      for (let XO = 1; XO < KO.length; XO++) pO.push(KO.slice(0, XO).join("/"));
      return pO
    }

    function fb(OO) {
      return OO.slice(OO.lastIndexOf("/") + 1)
    }
    const db = (0, bK.memo)((function(OO) {
      var KO;
      let {
        files: pO,
        activePath: XO,
        canEdit: eO,
        directoryLinked: lO,
        pluginNames: vK,
        activePluginName: CO,
        activePluginFile: hO,
        onSelect: MO,
        onSelectPlugin: aK,
        onCreate: FO,
        onRename: VO,
        onRenameFolder: QO,
        onDelete: zK,
        onToggleDirectorySync: AO,
        schematics: fO,
        onManageSchematic: dO
      } = OO;
      const {
        t: TO
      } = (0, nO.D)(), NO = null !== (KO = (0, hb.b)(pO)) && void 0 !== KO ? KO : ve.f, IO = Object.keys(pO), [yK, gK] = (0, bK.useState)((() => new Set)), uO = function(OO, KO, pO) {
        const XO = {
          folders: new Map,
          files: []
        };
        for (const lO of OO) {
          if (lO === KO) continue;
          let OO = XO;
          for (const KO of Ab(lO)) {
            let pO = OO.folders.get(KO);
            pO || (pO = {
              folders: new Map,
              files: []
            }, OO.folders.set(KO, pO)), OO = pO
          }
          OO.files.push(lO)
        }
        const bK = [];
        OO.includes(KO) && bK.push({
          kind: "file",
          path: KO,
          name: fb(KO),
          depth: 0
        });
        const eO = (OO, KO) => {
          const XO = [...OO.folders.entries()].sort(((OO, KO) => {
            let [pO] = OO, [XO] = KO;
            return pO.localeCompare(XO)
          }));
          for (const [lO, vK] of XO) {
            const OO = pO.has(lO);
            bK.push({
              kind: "folder",
              path: lO,
              name: fb(lO),
              depth: KO,
              collapsed: OO
            }), OO || eO(vK, KO + 1)
          }
          OO.files.sort(((OO, KO) => OO.localeCompare(KO)));
          for (const pO of OO.files) bK.push({
            kind: "file",
            path: pO,
            name: fb(pO),
            depth: KO
          })
        };
        return eO(XO, 0), bK
      }(IO, NO, yK);
      (0, bK.useEffect)((() => {
        gK((OO => {
          const KO = new Set(OO);
          let pO = !1;
          for (const bK of Ab(XO)) pO = KO.delete(bK) || pO;
          return pO ? KO : OO
        }))
      }), [XO]);
      const EO = IO.length >= xp.A,
        jK = (OO, KO) => {
          if (OO.length > Cb.B) return `Path must be at most ${Cb.B} characters`;
          if (!(0, Cb.x)(OO)) return "Use a relative .js, .ts, or .d.ts path, e.g. lib/util.js";
          if ("index.d.ts" === OO) return "index.d.ts cannot be the world-code entry";
          const XO = !!KO && (0, hb.f)(KO, OO);
          if (KO && (0, hb.h)(KO) && !XO) return `Cannot rename ${KO} (only swapping ${ve.f} and ${ve.j} is allowed)`;
          if (OO in pO) return "A file with that path already exists";
          if ((0, hb.h)(OO) && !XO) {
            if ((OO === ve.f ? ve.j : ve.f) in pO) return `World code cannot have both ${ve.f} and ${ve.j}`
          }
          return null
        },
        YO = OO => {
          ae.NotificationProvider.showInputPopup({
            title: "codeEditor:newFile",
            subtitle: "codeEditor:newFilePathHint",
            placeholderText: "lib/util.js",
            initialValue: void 0 === OO ? void 0 : `${OO}/`,
            submitText: "general:create",
            secondaryButtonText: "general:cancel",
            middleScreenPopupContainerClassName: "FileTreePathPopup",
            validate: OO => jK(OO)
          }).getResult().then((OO => {
            "notificationTornDown" !== OO && null !== OO && "submit" === OO.type && FO(OO.value)
          }))
        },
        wO = OO => {
          ae.NotificationProvider.showInputPopup({
            title: "codeEditor:renameFile",
            subtitle: "codeEditor:newFilePathHint",
            initialValue: OO,
            submitText: "codeEditor:rename",
            secondaryButtonText: "general:cancel",
            middleScreenPopupContainerClassName: "FileTreePathPopup",
            validate: KO => KO === OO ? "That is already the file's path" : jK(KO, OO)
          }).getResult().then((KO => {
            "notificationTornDown" !== KO && null !== KO && "submit" === KO.type && VO(OO, KO.value)
          }))
        },
        iK = OO => {
          const KO = OO => OO.replace(/\/+$/, "");
          ae.NotificationProvider.showInputPopup({
            title: "codeEditor:renameFolder",
            subtitle: "codeEditor:renameFolderHint",
            initialValue: OO,
            submitText: "codeEditor:rename",
            secondaryButtonText: "general:cancel",
            middleScreenPopupContainerClassName: "FileTreePathPopup",
            validate: pO => {
              const XO = KO(pO);
              if (XO === OO) return "That is already the folder's path";
              for (const [KO, bK] of(0, hb.m)(IO, OO, XO)) {
                const OO = jK(bK, KO);
                if (null !== OO) return OO
              }
              return null
            }
          }).getResult().then((pO => {
            "notificationTornDown" !== pO && null !== pO && "submit" === pO.type && QO(OO, KO(pO.value))
          }))
        },
        rK = OO => {
          ae.NotificationProvider.showPromptPopup({
            title: "codeEditor:deleteFile",
            subtitle: "codeEditor:deleteFileConfirm",
            textOpts: {
              subtitle: {
                path: OO
              }
            },
            confirmText: "general:delete",
            destructive: !0,
            cancelText: "general:cancel"
          }).getResult().then((KO => {
            !0 === KO && zK(OO)
          }))
        };
      return (0, DO.jsxs)("div", {
        className: "CodeEditorFileTree",
        children: [(0, DO.jsxs)("div", {
          className: "FileTreeHeader",
          children: [(0, DO.jsx)("span", {
            children: "Files"
          }), eO && !EO && (0, DO.jsx)(oO.s, {
            className: "FileTreeHeaderButton",
            onClick: () => {
              YO()
            },
            children: (0, DO.jsx)(LO.d, {
              name: "plus"
            })
          })]
        }), (0, DO.jsxs)("div", {
          className: "FileTreeList",
          children: [uO.map((OO => {
            const KO = OO.path;
            if ("folder" === OO.kind) return (0, DO.jsx)(Ib, {
              path: KO,
              name: OO.name,
              depth: OO.depth,
              collapsed: OO.collapsed,
              onToggle: () => {
                var OO;
                OO = KO, gK((KO => {
                  const pO = new Set(KO);
                  return pO.delete(OO) || pO.add(OO), pO
                }))
              },
              canCreate: eO && !EO,
              canRename: eO,
              onCreate: YO,
              onRename: iK
            }, `folder:${KO}`);
            const bK = (0, hb.h)(KO),
              lO = ve.f in pO && ve.j in pO,
              vK = !bK || lO,
              hO = null === CO && KO === XO;
            return (0, DO.jsx)(ge, {
              path: KO,
              label: OO.name,
              depth: OO.depth,
              isActive: hO,
              canRename: eO,
              onSelect: MO,
              onRename: wO,
              onDelete: rK,
              canDelete: vK && eO
            }, KO)
          })), (0, DO.jsxs)("div", {
            className: "FileTreeHeader Secondary",
            children: [(0, DO.jsxs)("span", {
              children: ["Schematics (", Object.keys(fO).length, "/", ze.g, ")"]
            }), eO && (0, DO.jsx)(oO.s, {
              className: "FileTreeHeaderButton",
              disabled: Object.keys(fO).length >= ze.g,
              onClick: () => {
                dO("")
              },
              children: (0, DO.jsx)(LO.d, {
                name: "plus"
              })
            })]
          }), Object.keys(fO).sort().map((OO => (0, DO.jsx)(ge, {
            path: OO,
            isActive: !1,
            canRename: !1,
            canDelete: !1,
            onSelect: dO
          }, OO))), vK.length > 0 && (0, DO.jsxs)(DO.Fragment, {
            children: [(0, DO.jsx)("div", {
              className: "FileTreeHeader Secondary",
              children: (0, DO.jsx)("span", {
                children: "Plugins"
              })
            }), vK.map((OO => {
              var KO;
              const pO = Lb.e[OO],
                XO = Object.keys(null !== (KO = null === pO || void 0 === pO ? void 0 : pO.files) && void 0 !== KO ? KO : {
                  "index.ts": ""
                }).sort(((OO, KO) => "index.ts" === OO ? -1 : "index.ts" === KO ? 1 : OO.localeCompare(KO)));
              return (0, DO.jsxs)("div", {
                children: [(0, DO.jsx)("div", {
                  className: "FileTreePluginName",
                  children: (0, hb.x)(OO)
                }), XO.map((KO => (0, DO.jsx)(ge, {
                  path: KO,
                  nested: !0,
                  isActive: CO === OO && hO === KO,
                  canRename: !1,
                  onSelect: () => {
                    aK(OO, KO)
                  },
                  canDelete: !1
                }, KO)))]
              }, OO)
            }))]
          })]
        }), (0, DO.jsx)("div", {
          className: "FileTreeFooter",
          children: (0, DO.jsx)(oO.d, {
            className: "FileTreeFooterButton",
            onClick: AO,
            children: TO(lO ? "codeEditor:directorySyncUnlink" : "codeEditor:directorySyncLink")
          })
        })]
      })
    }));

    function Tb(OO) {
      return OO > 0 ? {
        className: "Indented",
        style: {
          "--tree-depth": OO
        }
      } : {
        className: void 0,
        style: void 0
      }
    }

    function Nb(OO) {
      let {
        depth: KO
      } = OO;
      return (0, DO.jsx)(DO.Fragment, {
        children: Array.from({
          length: KO
        }, ((OO, KO) => (0, DO.jsx)("span", {
          className: "FileTreeIndentGuide",
          style: {
            "--guide-level": KO
          }
        }, KO)))
      })
    }

    function Ib(OO) {
      let {
        path: KO,
        name: pO,
        depth: XO,
        collapsed: bK,
        onToggle: eO,
        canCreate: lO,
        canRename: vK,
        onCreate: CO,
        onRename: hO
      } = OO;
      const MO = [];
      lO && MO.push({
        icon: "plus",
        text: "codeEditor:newFile",
        onPointerDown: () => {
          CO(KO)
        }
      }), vK && MO.push({
        icon: "pen",
        text: "codeEditor:renameFolder",
        onPointerDown: () => {
          hO(KO)
        }
      });
      const aK = Tb(XO);
      return (0, DO.jsxs)("div", {
        className: DK()("FileTreeItem FileTreeFolder", aK.className),
        style: aK.style,
        children: [(0, DO.jsx)(Nb, {
          depth: XO
        }), (0, DO.jsxs)("button", {
          type: "button",
          className: "FileTreeItemName",
          "aria-expanded": !bK,
          onClick: eO,
          children: [(0, DO.jsx)(LO.d, {
            className: "FileTreeFolderCaret",
            name: bK ? "caret-right" : "caret-down"
          }), (0, DO.jsx)(LO.d, {
            className: "FileTreeFolderIcon",
            name: bK ? "folder" : "folder-open"
          }), pO]
        }), (0, DO.jsx)(ye, {
          path: KO,
          actions: MO
        })]
      })
    }

    function ye(OO) {
      let {
        path: KO,
        actions: pO
      } = OO;
      const XO = (0, bK.useRef)(null);
      return 0 === pO.length ? null : (0, DO.jsxs)("div", {
        ref: XO,
        className: "FileTreeItemActions",
        children: [(0, DO.jsx)("button", {
          type: "button",
          className: "FileTreeActionMenuButton",
          "aria-label": `Actions for ${KO}`,
          children: (0, DO.jsx)(LO.d, {
            name: "ellipsis"
          })
        }), (0, DO.jsx)(Qb.d, {
          triggerElementRef: XO,
          options: pO
        })]
      })
    }

    function ge(OO) {
      let {
        path: KO,
        label: pO = KO,
        depth: XO = 0,
        isActive: bK,
        canRename: eO,
        onSelect: lO,
        onRename: vK,
        onDelete: CO,
        canDelete: hO,
        nested: MO
      } = OO;
      const aK = [];
      eO && vK && aK.push({
        icon: "pen",
        text: "codeEditor:rename",
        onPointerDown: () => {
          vK(KO)
        }
      }), hO && CO && aK.push({
        icon: "xmark",
        text: "general:delete",
        onPointerDown: () => {
          CO(KO)
        }
      });
      const oO = Tb(XO);
      return (0, DO.jsxs)("div", {
        className: DK()("FileTreeItem", oO.className, {
          Active: bK,
          Nested: MO
        }),
        style: oO.style,
        children: [(0, DO.jsx)(Nb, {
          depth: XO
        }), (0, DO.jsx)("button", {
          type: "button",
          className: "FileTreeItemName",
          title: pO === KO ? void 0 : KO,
          onClick: () => {
            lO(KO)
          },
          children: pO
        }), (0, DO.jsx)(ye, {
          path: KO,
          actions: aK
        })]
      })
    }
    async function ub(OO) {
      const KO = (0, hb.b)(OO);
      if (!KO || "" === OO[KO].trim()) return [];
      const {
        collectImportedWorldCodePluginNames: XO
      } = await Promise.all([pO.e(279), pO.e(280)]).then((() => pO(39514)));
      return (0, Lb.b)(XO(OO))
    }
    var Eb = pO(35364);

    function je(OO, KO) {
      const pO = Object.keys(OO),
        XO = Object.keys(KO);
      if (pO.length !== XO.length) return !1;
      for (const bK of pO)
        if (!(bK in KO) || OO[bK] !== KO[bK]) return !1;
      return !0
    }

    function Yb(OO, KO) {
      const pO = [],
        XO = [],
        bK = [];
      for (const eO of Object.keys(KO)) eO in OO ? OO[eO] !== KO[eO] && bK.push(eO) : pO.push(eO);
      for (const eO of Object.keys(OO)) eO in KO || XO.push(eO);
      return pO.sort(), XO.sort(), bK.sort(), {
        creates: pO,
        deletes: XO,
        updates: bK
      }
    }

    function wb(OO, KO) {
      var pO;
      const XO = {
          ...OO
        },
        bK = (0, hb.b)(KO),
        eO = (0, hb.b)(XO);
      if (ve.f in XO && ve.j in XO) {
        const OO = null !== bK && void 0 !== bK ? bK : ve.j,
          pO = OO === ve.f ? ve.j : ve.f;
        var lO;
        if (!(OO in XO)) XO[OO] = null !== (lO = KO[OO]) && void 0 !== lO ? lO : "";
        return delete XO[pO], XO
      }
      var vK;
      return bK && !(bK in XO) ? (eO || (XO[bK] = null !== (vK = KO[bK]) && void 0 !== vK ? vK : ""), XO) : (eO || bK || (XO[ve.f] = null !== (pO = XO[ve.f]) && void 0 !== pO ? pO : "", delete XO[ve.j]), XO)
    }

    function ie(OO, KO) {
      const pO = (0, hb.b)(KO),
        XO = ve.f in KO && ve.j in KO;
      return OO.filter((OO => !(0, hb.h)(OO) || (!!XO || pO !== OO)))
    }
    async function re(OO, KO, XO) {
      const bK = OO.getLobbyFiles(),
        eO = (0, xp.j)(XO, (0, hb.p)(bK, KO)),
        lO = await OO.ensureJoined(KO),
        vK = (0, Cb.C)(lO.docKey);
      if (lO.doc === eO) return;
      for (let pO = 0; pO < 100; pO++) {
        const pO = OO.getCollabSnapshot();
        if (pO && (0, Cb.C)(pO.docKey) === vK && OO.getActivePath() === KO) {
          if (OO.replaceActiveDoc(vK, eO)) return;
          await (0, zb.M)(40)
        } else await (0, zb.M)(40)
      }
      const {
        ChangeSet: CO
      } = await pO.e(275).then((() => pO(39338))), DO = OO.getCollabSnapshot(), MO = DO && (0, Cb.C)(DO.docKey) === vK ? DO : lO;
      await async function(OO, KO, pO, XO) {
        const bK = OO.of({
            from: 0,
            to: pO.length,
            insert: XO
          }, pO.length),
          eO = JSON.stringify([{
            clientID: KO.clientID,
            changes: bK.toJSON()
          }]),
          lO = (0, Cb.C)(KO.docKey);
        eO.length <= Cb.i ? hO.gameBridge.send("sendCodeCollab", {
          Zm: Cb.b.Push,
          Wm: lO,
          Xs: KO.version,
          Fs: eO
        }) : await (0, lb.postJsonWithMetricsCookiesAndJsonResponse)(`${KO.httpConfig.gsUrl}/code/collab-push`, eb.q["collab-push"].toBuffer({
          gameNameWithVariation: KO.httpConfig.gameNameWithVariation,
          lobbyName: KO.httpConfig.lobbyName,
          docKey: lO,
          version: KO.version,
          updates: eO
        }), {
          retries: 0
        })
      }(CO, MO, MO.doc, eO)
    }
    class Pb {
      constructor(OO) {
        this.handle = null, this.lastSynced = {}, this.lastLobbySeen = null, this.pendingDocText = new Map, this.flushingDocText = !1, this.recheckingDisk = !1, this.stopWatch = null, this.lobbyPollTimer = null, this.running = !1, this.applying = !1, this.reconcileSettled = !1, this.reconcileInFlight = !1, this.linked = !1, this.scaffoldedPluginNamesKey = null, this.scaffoldingLocalTypes = Promise.resolve(), this.bridge = void 0, this.bridge = OO
      }
      async writeLobbyFiles(OO) {
        const KO = {
            ...this.bridge.getLobbyFiles()
          },
          pO = {
            ...KO
          };
        for (const {
            path: eO,
            text: lO
          }
          of OO) pO[eO] = lO;
        if (!OO.every((OO => {
            let {
              path: KO,
              text: XO
            } = OO;
            return (0, xp.j)(XO, (0, hb.p)(pO, KO)) === XO
          }))) return !1;
        const XO = [];
        try {
          for (const {
              path: KO,
              text: pO
            }
            of OO) XO.push(KO), KO in this.bridge.getLobbyFiles() || (this.bridge.createFile(KO, {
            focus: !1
          }), await this.bridge.waitForLobbyPath(KO, !0)), await re(this.bridge, KO, pO)
        } catch (bK) {
          for (const OO of XO) OO in KO ? await re(this.bridge, OO, KO[OO]).catch((KO => {
            console.error("World Code AI: couldn't put back", OO, KO)
          })) : this.bridge.deleteFile(OO);
          throw bK
        }
        return !0
      }
      isLinked() {
        return this.linked
      }
      async linkFolder() {
        if (!this.bridge.canEditCode()) return this.bridge.setMessage(this.bridge.t("codeEditor:directorySyncNeedEdit"), "warning"), !1;
        const OO = await (0, Eb.r)(this.bridge.getStorageKey());
        return !!OO && (this.handle = OO, this.linked = !0, this.reconcileSettled = !1, await this.scaffoldLocalTypes(OO), !0)
      }
      async unlinkFolder() {
        const OO = this.bridge.getStorageKey();
        this.pendingDocText.clear(), this.stopContinuousSync(), this.handle = null, this.linked = !1, this.reconcileSettled = !1, this.lastSynced = {}, this.lastLobbySeen = null, this.scaffoldedPluginNamesKey = null, await (0, Eb.e)(OO), this.bridge.onUnlinked()
      }
      async tryRestoreHandle() {
        const OO = this.bridge.getStorageKey(),
          KO = await (0, Eb.q)(OO);
        return !!KO && (!!await (0, Eb.j)(KO, "readwrite") && (this.handle = KO, this.linked = !0, await (0, Eb.A)(OO, KO), await this.scaffoldLocalTypes(KO), !0))
      }
      scaffoldLocalTypes(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.bridge.getLobbyFiles();
        return this.scaffoldingLocalTypes = this.scaffoldingLocalTypes.then((async () => {
          try {
            const XO = (await ub(KO)).map((OO => Lb.e[OO])),
              bK = XO.map((OO => {
                var KO;
                return `${OO.name}:${Object.keys(null!==(KO=null===OO||void 0===OO?void 0:OO.files)&&void 0!==KO?KO:{}).sort().join(",")}`
              })).join("\0");
            if (this.scaffoldedPluginNamesKey === bK) return;
            const {
              ensureLocalBloxdTypes: eO
            } = await Promise.all([pO.e(72), pO.e(277), pO.e(282)]).then((() => pO(39521)));
            await eO(OO, XO), this.scaffoldedPluginNamesKey = bK
          } catch (XO) {
            console.error("[WorldCodeDirectorySync] Failed to scaffold local @bloxd types", XO)
          }
        })), this.scaffoldingLocalTypes
      }
      async startWhenReady() {
        this.linked && this.handle && !this.running && !this.reconcileInFlight && this.bridge.getCollabSnapshot() && (this.reconcileSettled ? this.beginWatch() : await this.runInitialReconcileAndSync())
      }
      stopContinuousSync() {
        this.flushDocTextToDisk(), this.running = !1, this.stopWatch && (this.stopWatch(), this.stopWatch = null), this.lobbyPollTimer && (clearInterval(this.lobbyPollTimer), this.lobbyPollTimer = null)
      }
      async onLobbyFilesChanged(OO) {
        this.handle && await this.scaffoldLocalTypes(this.handle, OO), this.running && this.handle && !this.applying && await this.applyRemoteTreeToDisk(OO)
      }
      async onDocTextChanged(OO, KO) {
        if (!this.handle) return;
        const pO = [this.scaffoldLocalTypes(this.handle, {
          ...this.bridge.getLobbyFiles(),
          [OO]: KO
        })];
        this.running && (this.pendingDocText.set(OO, KO), pO.push(this.flushDocTextToDisk())), await Promise.all(pO)
      }
      async flushDocTextToDisk() {
        if (this.flushingDocText || this.applying || !this.handle || 0 === this.pendingDocText.size) return;
        const OO = this.handle;
        this.flushingDocText = !0, this.applying = !0;
        try {
          for (; this.pendingDocText.size > 0;) {
            const KO = [...this.pendingDocText];
            this.pendingDocText.clear();
            for (const [pO, XO] of KO) this.lastSynced[pO] !== XO && (await (0, Eb.F)(OO, pO, XO), this.lastSynced = {
              ...this.lastSynced,
              [pO]: XO
            })
          }
        } catch (KO) {
          console.error("[WorldCodeDirectorySync] Failed to write remote doc to disk", KO), this.bridge.setMessage(this.bridge.t("codeEditor:directorySyncError"), "warning")
        } finally {
          this.flushingDocText = !1, this.applying = !1, this.settleAfterApplying()
        }
      }
      settleAfterApplying() {
        this.flushDocTextToDisk(), this.recheckDiskFiles()
      }
      async recheckDiskFiles() {
        if (this.running && this.handle && !this.applying && !this.recheckingDisk) {
          this.recheckingDisk = !0;
          try {
            await this.onDiskFilesChanged(await (0, Eb.u)(this.handle))
          } catch (OO) {
            console.error("[WorldCodeDirectorySync] Failed to re-check disk after sync", OO)
          } finally {
            this.recheckingDisk = !1
          }
        }
      }
      async runInitialReconcileAndSync() {
        if (this.handle && !this.reconcileInFlight) {
          this.reconcileInFlight = !0;
          try {
            if (!await (0, Eb.j)(this.handle, "readwrite")) return this.bridge.setMessage(this.bridge.t("codeEditor:directorySyncPermissionDenied"), "warning"), void(this.reconcileSettled = !0);
            await this.bridge.pullLobbyFiles();
            const KO = this.bridge.getLobbyFiles(),
              pO = await (0, Eb.u)(this.handle);
            for (const OO of Object.keys(KO).filter(ze.e)) {
              if (pO[OO] === Eb.n) return void this.bridge.setMessage(`Move ${OO} outside the linked folder before syncing its placeholder.`, "warning");
              pO[OO] = ze.k
            }
            if (je(pO, KO)) {
              for (const OO of Object.keys(KO).filter(ze.e)) await (0, Eb.F)(this.handle, OO, ze.k);
              return this.lastSynced = {
                ...pO
              }, void this.beginWatch()
            }
            const XO = await this.promptReconcile(function(OO) {
              return null !== (0, hb.b)(OO)
            }(pO));
            if ("unlink" === XO) return void await this.unlinkFolder();
            if ("dismissed" === XO) return void(this.reconcileSettled = !0);
            this.applying = !0;
            try {
              if ("local" === XO) {
                if (!this.bridge.canEditCode()) return this.bridge.setMessage(this.bridge.t("codeEditor:directorySyncNeedEdit"), "warning"), void(this.reconcileSettled = !0);
                await this.applyLocalTreeToLobby(pO);
                for (const OO of Object.keys(KO).filter(ze.e)) await (0, Eb.F)(this.handle, OO, ze.k);
                this.lastSynced = {
                  ...await (0, Eb.u)(this.handle)
                }
              } else await (0, Eb.H)(this.handle, KO), this.lastSynced = {
                ...KO
              }
            } catch (OO) {
              return console.error("[WorldCodeDirectorySync] Reconcile failed", OO), this.bridge.setMessage(this.bridge.t("codeEditor:directorySyncError"), "warning"), void(this.reconcileSettled = !0)
            } finally {
              this.applying = !1, this.settleAfterApplying()
            }
            this.beginWatch()
          } finally {
            this.reconcileInFlight = !1
          }
        }
      }
      async promptReconcile(OO) {
        return await new Promise((KO => {
          const pO = [{
              choice: "local",
              Button: oO.d,
              labelKey: "directorySyncUseLocal",
              descriptionKey: "directorySyncUseLocalDescription"
            }, {
              choice: "live",
              Button: oO.d,
              labelKey: "directorySyncUseLive",
              descriptionKey: "directorySyncUseLiveDescription"
            }, {
              choice: "unlink",
              Button: oO.d,
              labelKey: "directorySyncUseUnlink",
              descriptionKey: "directorySyncUseUnlinkDescription"
            }],
            XO = (0, DO.jsxs)("div", {
              className: "CodeEditorDirectorySyncPrompt",
              children: [(0, DO.jsx)("div", {
                className: "CodeEditorDirectorySyncPromptTitle",
                children: this.bridge.t("codeEditor:directorySyncDifferTitle")
              }), (0, DO.jsx)("div", {
                className: "CodeEditorDirectorySyncPromptBody",
                children: OO ? this.bridge.t("codeEditor:directorySyncDifferBody") : this.bridge.t("codeEditor:directorySyncLocalInvalidEntry")
              }), (0, DO.jsx)("div", {
                className: "CodeEditorDirectorySyncOptions",
                children: pO.filter((KO => "local" !== KO.choice || OO)).map((OO => {
                  let {
                    choice: pO,
                    Button: XO,
                    labelKey: eO,
                    descriptionKey: lO
                  } = OO;
                  return (0, DO.jsxs)("div", {
                    className: "CodeEditorDirectorySyncOption",
                    children: [(0, DO.jsx)(XO, {
                      className: "CodeEditorButton",
                      onClick: () => {
                        (OO => {
                          bK.tearDownNotification(), KO(OO)
                        })(pO)
                      },
                      children: this.bridge.t(`codeEditor:${eO}`)
                    }), (0, DO.jsx)("div", {
                      className: "CodeEditorDirectorySyncOptionDescription",
                      children: this.bridge.t(`codeEditor:${lO}`)
                    })]
                  }, pO)
                }))
              })]
            }),
            bK = ae.NotificationProvider.showCustomPopup({
              body: XO,
              disableExitButton: !0,
              disablePressBackgroundToClose: !0,
              unlockPointerKey: "worldCodeDirectorySync"
            });
          bK.getResult().then((OO => {
            "notificationTornDown" === OO && KO("dismissed")
          }))
        }))
      }
      beginWatch() {
        this.handle && (this.stopContinuousSync(), this.reconcileSettled = !0, this.running = !0, this.stopWatch = (0, Eb.B)(this.handle, (OO => {
          this.onDiskFilesChanged(OO)
        })), this.lobbyPollTimer = setInterval((() => {
          this.pollRemoteLobbyFiles()
        }), 2e3))
      }
      async pollRemoteLobbyFiles() {
        if (this.running && !this.applying) try {
          await this.bridge.pullLobbyFiles()
        } catch (OO) {
          console.error("[WorldCodeDirectorySync] Lobby poll failed", OO)
        }
      }
      async onDiskFilesChanged(OO) {
        if (!this.running || !this.handle || this.applying) return;
        if (!this.bridge.canEditCode()) return;
        const KO = this.bridge.getLobbyFiles();
        let pO = wb(OO, this.lastSynced);
        for (const eO in KO)
          if ((0, ze.e)(eO) && pO[eO] === Eb.n) return void this.bridge.setMessage("Move binary schematic files outside the linked folder. Add them through the Code Editor.", "warning");
        const XO = Object.keys(pO).filter((OO => (0, ze.e)(OO) && !(OO in KO)));
        XO.length > 0 && this.bridge.setMessage("Add or rename schematics in the Code Editor. Unknown local schematic files are not uploaded.", "warning");
        for (const eO of Object.keys(KO).filter(ze.e))(eO in pO || XO.length > 0 || !(eO in this.lastSynced)) && (pO[eO] = ze.k);
        if (!je(pO, OO)) {
          this.applying = !0;
          try {
            await this.persistEntryRepair(OO, pO), pO = wb(await (0, Eb.u)(this.handle), this.lastSynced)
          } finally {
            this.applying = !1
          }
        }
        if (!je(pO, this.lastSynced)) {
          this.applying = !0;
          try {
            const OO = Yb(this.lastSynced, pO);
            if (await this.pushDiskDeltaToLobby(pO, KO), null !== this.lastLobbySeen)
              for (const pO of [...OO.creates, ...OO.updates, ...OO.deletes])(0, ze.e)(pO) || (pO in KO ? this.lastLobbySeen[pO] = KO[pO] : delete this.lastLobbySeen[pO]);
            this.lastSynced = {
              ...pO
            }
          } catch (bK) {
            console.error("[WorldCodeDirectorySync] Disk\u2192lobby sync failed", bK), this.bridge.setMessage(this.bridge.t("codeEditor:directorySyncError"), "warning")
          } finally {
            this.applying = !1, this.settleAfterApplying()
          }
        }
      }
      async persistEntryRepair(OO, KO) {
        if (this.handle) {
          for (const pO of Object.keys(OO)) pO in KO || await (0, Eb.v)(this.handle, pO);
          for (const [pO, XO] of Object.entries(KO)) OO[pO] !== XO && await (0, Eb.F)(this.handle, pO, XO)
        }
      }
      async applyRemoteTreeToDisk(OO) {
        if (!this.handle) return;
        const KO = this.lastLobbySeen;
        if (null === KO) return void(this.lastLobbySeen = {
          ...OO
        });
        const pO = Object.keys(OO).filter((pO => KO[pO] !== OO[pO])),
          XO = Object.keys(KO).filter((KO => !(KO in OO)));
        if (0 !== pO.length || 0 !== XO.length) {
          this.applying = !0;
          try {
            for (const KO of [...XO, ...pO]) try {
              if (KO in OO) await (0, Eb.F)(this.handle, KO, OO[KO]), this.lastSynced = {
                ...this.lastSynced,
                [KO]: OO[KO]
              }, this.lastLobbySeen = {
                ...this.lastLobbySeen,
                [KO]: OO[KO]
              };
              else {
                await (0, Eb.v)(this.handle, KO);
                const OO = {
                  ...this.lastSynced
                };
                delete OO[KO], this.lastSynced = OO;
                const pO = {
                  ...this.lastLobbySeen
                };
                delete pO[KO], this.lastLobbySeen = pO
              }
            } catch (bK) {
              console.error("[WorldCodeDirectorySync] Lobby\u2192disk sync failed", bK), this.bridge.setMessage(this.bridge.t("codeEditor:directorySyncError"), "warning")
            }
          } finally {
            this.applying = !1, this.settleAfterApplying()
          }
        }
      }
      async renameLobbyEntryIfSwitched(OO, KO) {
        const pO = function(OO, KO) {
          const pO = (0, hb.b)(OO),
            XO = (0, hb.b)(KO);
          return pO && XO && pO !== XO ? {
            from: pO,
            to: XO
          } : null
        }(OO, KO);
        return !!pO && (this.bridge.renameFile(pO.from, pO.to), await this.bridge.waitForLobbyPath(pO.to, !0), !0)
      }
      async applyLocalTreeToLobby(OO) {
        var KO;
        const pO = this.bridge.getActivePath();
        await this.renameLobbyEntryIfSwitched(this.bridge.getLobbyFiles(), OO);
        const XO = this.bridge.getLobbyFiles(),
          bK = Yb(XO, OO),
          eO = ie(bK.deletes, XO);
        for (const hO of bK.creates)(0, ze.e)(hO) || (this.bridge.createFile(hO, {
          focus: !1
        }), await this.bridge.waitForLobbyPath(hO, !0));
        for (const hO of eO)(0, ze.e)(hO) || (this.bridge.deleteFile(hO), await this.bridge.waitForLobbyPath(hO, !1));
        if (!(0, hb.b)(this.bridge.getLobbyFiles()) && !(0, hb.b)(OO)) {
          if (this.bridge.createFile(ve.f, {
              focus: !1
            }), await this.bridge.waitForLobbyPath(ve.f, !0), !this.handle) return;
          await (0, Eb.F)(this.handle, ve.f, ""), OO = {
            ...OO,
            [ve.f]: ""
          }
        }
        const lO = this.bridge.getLobbyFiles();
        for (const hO of Object.keys(OO))(0, ze.e)(hO) || lO[hO] !== OO[hO] && await re(this.bridge, hO, OO[hO]);
        const vK = this.bridge.getLobbyFiles(),
          CO = pO in vK ? pO : null !== (KO = (0, hb.b)(vK)) && void 0 !== KO ? KO : ve.f;
        await this.bridge.ensureJoined(CO)
      }
      async pushDiskDeltaToLobby(OO, KO) {
        const pO = this.bridge.getActivePath(),
          XO = await this.renameLobbyEntryIfSwitched(KO, OO) ? this.bridge.getLobbyFiles() : KO,
          bK = Yb(this.lastSynced, OO),
          eO = ie(bK.deletes, XO).filter((OO => OO in XO));
        for (const lO of bK.creates)(0, ze.e)(lO) || (lO in this.bridge.getLobbyFiles() || (this.bridge.createFile(lO, {
          focus: !1
        }), await this.bridge.waitForLobbyPath(lO, !0)), await re(this.bridge, lO, OO[lO]));
        for (const lO of eO)(0, ze.e)(lO) ? await this.bridge.deleteSchematic(lO) : (this.bridge.deleteFile(lO), await this.bridge.waitForLobbyPath(lO, !1));
        for (const lO of bK.updates)(0, ze.e)(lO) || await re(this.bridge, lO, OO[lO]);
        pO in this.bridge.getLobbyFiles() && this.bridge.getActivePath() !== pO && await this.bridge.ensureJoined(pO)
      }
    }
    var me = pO(1056);

    function sb() {
      const {
        websocketUrl: OO,
        gameNameWithVariation: KO,
        lobbyName: pO
      } = hO.gameBridge.latest("connectedGame");
      return {
        gsUrl: me.clientSideServerUrls.getHttpUrlFromWebSocketUrl(OO),
        gameNameWithVariation: KO,
        lobbyName: pO
      }
    }
    async function Hb(OO) {
      const {
        gsUrl: KO,
        gameNameWithVariation: pO,
        lobbyName: XO
      } = sb();
      return await (0, lb.postBinaryWithMetricsCookiesAndCustomResponse)(`${KO}/code/schematics`, eb.Gj.schematics.toBuffer({
        gameNameWithVariation: pO,
        lobbyName: XO,
        request: JSON.stringify(OO)
      }), {
        retries: 0
      }, lb.HttpPayloadType.json)
    }
    var Rb = pO(34934);

    function Sb(OO) {
      let {
        path: KO,
        revision: pO
      } = OO;
      const [XO, eO] = (0, bK.useState)(""), [lO, vK] = (0, bK.useState)(!1), [CO, hO] = (0, bK.useState)(0);
      return (0, bK.useEffect)((() => {
        let OO = !1;
        return eO(""), vK(!1), Hb({
          action: "preview",
          path: KO
        }).then((KO => {
          OO || eO(`data:image/webp;base64,${KO.previewBase64}`)
        })).catch((KO => {
          console.error("Could not load schematic preview", KO), OO || vK(!0)
        })), () => {
          OO = !0
        }
      }), [KO, pO, CO]), (0, DO.jsxs)("div", {
        className: "SchematicPreview",
        children: [XO && (0, DO.jsx)("img", {
          src: XO,
          alt: `Preview of ${KO}`
        }), !XO && !lO && (0, DO.jsx)(uO.e, {
          loaderType: "Secondary"
        }), lO && (0, DO.jsxs)(DO.Fragment, {
          children: [(0, DO.jsx)("div", {
            className: "SmallTextLight",
            role: "status",
            children: "Preview unavailable."
          }), (0, DO.jsx)(oO.d, {
            onClick: () => {
              hO(CO + 1)
            },
            children: "Retry preview"
          })]
        })]
      })
    }

    function Jb(OO) {
      var KO;
      let {
        initialPath: pO,
        onChanged: XO,
        onClose: eO
      } = OO;
      const lO = "" === pO,
        [vK, CO] = (0, bK.useState)(null),
        [hO, MO] = (0, bK.useState)(pO),
        [aK, FO] = (0, bK.useState)(!1),
        [VO, LO] = (0, bK.useState)(!1),
        [QO, zK] = (0, bK.useState)(null),
        [AO, fO] = (0, bK.useState)(!1),
        [dO, TO] = (0, bK.useState)(""),
        NO = (0, bK.useRef)(null),
        IO = (0, bK.useRef)(!1),
        yK = (0, bK.useRef)(!0);
      (0, bK.useEffect)((() => (yK.current = !0, Hb({
        action: "state"
      }).then((OO => {
        yK.current && CO(OO)
      })).catch((OO => {
        console.error("Could not load schematic assets", OO), yK.current && TO("Could not load schematics. Reopen this panel to retry.")
      })), () => {
        yK.current = !1
      })), []);
      const gK = null === vK || void 0 === vK ? void 0 : vK.assets[pO],
        uO = Object.keys(null !== (KO = null === vK || void 0 === vK ? void 0 : vK.assets) && void 0 !== KO ? KO : {}).length,
        EO = hO.trim(),
        jK = EO ? (0, ze.e)(EO) ? null !== vK && void 0 !== vK && vK.assets[EO] && (lO || EO !== pO) ? "A schematic already uses that path." : "" : "Use a relative path ending in .bloxdschem." : "",
        YO = !!EO && !jK && (lO ? uO < ze.g : EO !== pO),
        wO = AO || !vK;
      async function iK(OO) {
        if (!IO.current && yK.current) {
          IO.current = !0, fO(!0), TO("");
          try {
            const KO = await Hb({
              ...OO,
              expectedRevision: vK.revision
            });
            XO(KO), yK.current && eO()
          } catch (pO) {
            var KO;
            if (console.error("Schematic asset operation failed", pO), yK.current) TO(pO instanceof ZO.b ? null !== (KO = pO.errorMessageForUser) && void 0 !== KO ? KO : pO.message : String(pO));
            try {
              const OO = await Hb({
                action: "state"
              });
              XO(OO), yK.current && CO(OO)
            } catch (bK) {
              console.error("Could not refresh schematic assets", bK)
            }
          } finally {
            IO.current = !1, yK.current && fO(!1)
          }
        }
      }
      return (0, DO.jsxs)("div", {
        className: "WorldCodeSchematicPanel InputGenericPopup PromptGenericPopup FileTreePathPopup",
        children: [(0, DO.jsx)("div", {
          className: "PromptGenericPopupTitle SmallTextBold",
          children: lO ? "New schematic" : aK ? "Rename schematic" : "Schematic"
        }), dO && (0, DO.jsx)("div", {
          className: "InputGenericPopupError SmallTextLight",
          role: "alert",
          children: dO
        }), !vK && !dO && (0, DO.jsx)("div", {
          className: "SmallTextLight",
          children: "Loading schematic\u2026"
        }), (0, DO.jsxs)("fieldset", {
          disabled: wO,
          children: [lO || aK ? (0, DO.jsxs)("label", {
            className: "SchematicField",
            children: [(0, DO.jsx)("span", {
              className: "SmallTextBold",
              children: "Project path"
            }), (0, DO.jsx)("div", {
              className: "InputGenericPopupInputRow",
              children: (0, DO.jsx)(NK.e, {
                className: "InputGenericPopupInput",
                defaultValue: pO,
                placeholderText: "maps/arena.bloxdschem",
                maxLength: 64,
                onValueChange: MO
              }, aK ? "rename" : "create")
            })]
          }) : (0, DO.jsx)("div", {
            className: "SchematicPath SmallTextBold",
            children: pO
          }), (lO || aK) && jK && (0, DO.jsx)("div", {
            className: "InputGenericPopupError SmallTextLight",
            role: "alert",
            children: jK
          }), lO ? (0, DO.jsxs)(DO.Fragment, {
            children: [uO >= ze.g && (0, DO.jsxs)("div", {
              className: "SmallTextLight",
              children: ["Delete a schematic before adding another (", ze.g, " maximum)."]
            }), VO ? (0, DO.jsxs)(DO.Fragment, {
              children: [(0, DO.jsx)("div", {
                className: "SmallTextBold",
                children: "Choose from profile"
              }), (0, DO.jsx)("div", {
                className: "SchematicProfilePicker",
                "aria-disabled": wO || !YO,
                children: (0, DO.jsx)(Rb.c, {
                  loading: null === QO,
                  schematics: null !== QO && void 0 !== QO ? QO : [],
                  disableAutoExport: !0,
                  onSchematicPicked: OO => {
                    !wO && YO && iK({
                      action: "profile",
                      path: EO,
                      schematicId: OO.schematicId
                    })
                  }
                })
              }), (0, DO.jsx)("div", {
                className: "InputGenericPopupButtons",
                children: (0, DO.jsx)(oO.d, {
                  className: "InputGenericPopupButton",
                  disabled: wO,
                  onClick: () => {
                    LO(!1)
                  },
                  children: "Back"
                })
              })]
            }) : (0, DO.jsxs)("div", {
              className: "InputGenericPopupButtons",
              children: [(0, DO.jsx)(oO.d, {
                className: "InputGenericPopupButton",
                disabled: wO || !YO,
                onClick: () => {
                  NO.current.click()
                },
                children: "Upload Schematic"
              }), (0, DO.jsx)(oO.d, {
                className: "InputGenericPopupButton",
                disabled: wO || !YO,
                onClick: () => {
                  !async function() {
                    if (LO(!0), TO(""), !QO) try {
                      const OO = await (0, lb.postJsonWithMetricsCookiesAndJsonResponse)(`${me.clientSideServerUrls.indexUrl}/index/schematic/get-owned-schematics`, {}, {
                        retries: 0,
                        minTimeout: 3e3
                      });
                      yK.current && zK(OO)
                    } catch (OO) {
                      console.error("Could not load profile schematics", OO), yK.current && (LO(!1), TO("Could not load your schematics. Try again."))
                    }
                  }()
                },
                children: "Choose from profile"
              })]
            }), (0, DO.jsx)("input", {
              ref: NO,
              type: "file",
              accept: ".bloxdschem",
              hidden: !0,
              onChange: OO => {
                var KO;
                const pO = null === (KO = OO.target.files) || void 0 === KO ? void 0 : KO[0];
                if (OO.target.value = "", !pO) return;
                if (pO.size > ze.h) return void TO("The schematic file is too large.");
                const XO = EO;
                fO(!0);
                const bK = new FileReader;
                bK.onload = () => {
                  iK({
                    action: "upload",
                    path: XO,
                    base64: String(bK.result).split(",")[1]
                  })
                }, bK.onerror = () => {
                  console.error("Could not read schematic file", bK.error), yK.current && (fO(!1), TO("Could not read the selected file."))
                }, bK.readAsDataURL(pO)
              }
            })]
          }) : gK ? (0, DO.jsxs)(DO.Fragment, {
            children: [!aK && (0, DO.jsx)(Sb, {
              path: pO,
              revision: vK.revision
            }), !aK && (0, DO.jsxs)("p", {
              className: "SchematicDetails SmallTextLight",
              children: [Math.ceil(gK.byteSize / 1024), " KB \xb7 ", gK.dimensions.join(" \xd7 "), " blocks"]
            }), (0, DO.jsx)("div", {
              className: "InputGenericPopupButtons",
              children: aK ? (0, DO.jsxs)(DO.Fragment, {
                children: [(0, DO.jsx)(oO.d, {
                  className: "InputGenericPopupButton",
                  disabled: wO || !YO,
                  onClick: () => {
                    iK({
                      action: "rename",
                      path: pO,
                      newPath: EO
                    })
                  },
                  children: "Rename"
                }), (0, DO.jsx)(oO.d, {
                  className: "InputGenericPopupButton",
                  disabled: wO,
                  onClick: () => {
                    FO(!1), MO(pO)
                  },
                  children: "Cancel"
                })]
              }) : (0, DO.jsxs)(DO.Fragment, {
                children: [(0, DO.jsx)(oO.d, {
                  className: "InputGenericPopupButton",
                  disabled: wO,
                  onClick: () => {
                    FO(!0)
                  },
                  children: "Rename"
                }), (0, DO.jsx)(oO.I, {
                  className: "InputGenericPopupButton",
                  disabled: wO,
                  onClick: () => {
                    iK({
                      action: "remove",
                      path: pO
                    })
                  },
                  children: "Delete"
                })]
              })
            })]
          }) : vK && (0, DO.jsx)("div", {
            className: "SmallTextLight",
            children: "This schematic is no longer in the project."
          })]
        })]
      })
    }

    function ce(OO) {
      if ("string" !== typeof OO) return null;
      try {
        const KO = JSON.parse(OO);
        return (0, hb.j)(null === KO || void 0 === KO ? void 0 : KO.worldCodeEngine) && "boolean" === typeof KO.engineLocked && function(OO) {
          if (null === OO) return !0;
          const KO = null === OO || void 0 === OO ? void 0 : OO.location;
          return "string" === typeof(null === OO || void 0 === OO ? void 0 : OO.reason) && (null === KO || "string" === typeof(null === KO || void 0 === KO ? void 0 : KO.path) && Number.isInteger(KO.line))
        }(KO.fallback) ? KO : (console.error("[CodeCollab] Malformed engine settings", OO), null)
      } catch (KO) {
        return console.error("[CodeCollab] Failed to parse engine settings", KO), null
      }
    }

    function Bb(OO) {
      let {
        fallback: KO,
        onGoToLine: pO
      } = OO;
      const {
        t: XO
      } = (0, nO.D)(), {
        location: bK
      } = KO;
      return (0, DO.jsxs)("div", {
        className: "CodeEditorEngineNotice",
        children: [XO("codeEditorEngine:notice", {
          reason: KO.reason
        }), bK && (0, DO.jsxs)(DO.Fragment, {
          children: [" ", (0, DO.jsx)("button", {
            type: "button",
            className: "CodeEditorEngineNoticeLink",
            onClick: () => {
              pO(bK.path, bK.line)
            },
            children: XO("codeEditorEngine:goToLine", {
              line: String(bK.line)
            })
          })]
        })]
      })
    }
    var Zb = pO(4059);

    function Gb(OO) {
      let {
        label: KO,
        hint: pO,
        checked: XO,
        onChange: bK
      } = OO;
      return (0, DO.jsxs)("label", {
        className: "CodeEditorMoreOptionsRow CodeEditorOptionSwitch",
        children: [(0, DO.jsxs)("span", {
          className: "CodeEditorOptionSwitchText",
          children: [(0, DO.jsx)("span", {
            children: KO
          }), (0, DO.jsx)("span", {
            className: "CodeEditorOptionSwitchHint",
            children: pO
          })]
        }), (0, DO.jsx)("span", {
          className: "SwitchContainer",
          children: (0, DO.jsx)(QK.c, {
            className: "SwitchCheckbox",
            checked: XO,
            onChange: OO => {
              bK(OO.target.checked)
            },
            disabled: !1
          })
        })]
      })
    }

    function qe(OO) {
      let {
        engine: KO,
        onSetEngine: pO,
        aiHints: XO,
        variation: bK
      } = OO;
      const {
        t: eO
      } = (0, nO.D)();
      return (0, DO.jsxs)("div", {
        className: "CodeEditorMoreOptions",
        children: [(0, DO.jsx)("div", {
          className: "CodeEditorMoreOptionsTitle",
          children: eO("codeEditor:moreOptions")
        }), KO && (0, DO.jsx)(Gb, {
          label: eO("codeEditorEngine:toggle"),
          hint: eO("codeEditorEngine:toggleHint"),
          checked: "ses" === KO,
          onChange: OO => {
            pO(OO ? "ses" : "quickjs")
          }
        }), XO && (0, DO.jsx)(Gb, {
          label: eO("codeEditorAiHints:toggle"),
          hint: eO("codeEditorAiHints:toggleHint"),
          checked: XO.shown,
          onChange: XO.setShown
        }), bK && (0, DO.jsxs)("div", {
          className: "CodeEditorMoreOptionsRow",
          children: [(0, DO.jsx)(Zb.e, {
            label: "codeEditor:variationLabel",
            children: (0, DO.jsx)(NK.e, {
              className: "CodeEditorVariationInput",
              maxLength: 32,
              defaultValue: bK.name,
              onValueChange: bK.setName,
              onEnter: bK.reload
            })
          }), (0, DO.jsx)(oO.y, {
            className: "CodeEditorButton",
            onClick: bK.reload,
            children: eO("codeEditor:reloadAsVariation")
          })]
        })]
      })
    }
    var xe = pO(35367),
      nb = pO(35375);

    function Wb(OO) {
      let {
        close: KO
      } = OO;
      const {
        t: pO
      } = (0, nO.D)(), XO = [{
        name: pO("codeEditor:welcomeTutorial"),
        tutorial: "welcome"
      }, {
        name: pO("codeEditor:docsOverviewTutorial"),
        tutorial: "docsOverview"
      }, {
        name: pO("codeEditorAiTutorial:tutorialName"),
        tutorial: "aiHelperOverview"
      }];
      return (0, DO.jsxs)("div", {
        className: "PromptGenericPopup CodeEditorTutorialsPopup",
        children: [(0, DO.jsx)("div", {
          className: "PromptGenericPopupTitle SmallTextBold",
          children: pO("codeEditor:tutorialsTitle")
        }), (0, DO.jsx)("div", {
          className: "CodeEditorTutorialsList",
          children: XO.map((OO => (0, DO.jsx)(oO.d, {
            className: "CodeEditorTutorialsListButton",
            onClick: () => {
              KO(), (0, nb.H)(OO.tutorial)
            },
            children: OO.name
          }, OO.tutorial)))
        })]
      })
    }
    var te = pO(107),
      ke = pO(35092),
      Ub = pO(7857);
    const Oe = (0, bK.forwardRef)((function(OO, KO) {
      let {
        value: pO,
        onChange: XO,
        onSubmit: bK,
        placeholder: eO,
        maxLength: lO,
        rows: vK = 2,
        allowNewLines: CO = !1,
        onKeyDown: hO,
        before: MO
      } = OO;
      const {
        t: aK
      } = (0, nO.D)(), FO = "" !== pO.trim(), VO = () => {
        FO && bK()
      };
      return (0, DO.jsxs)("div", {
        className: "PanelPromptInputRow",
        children: [MO, (0, DO.jsx)("textarea", {
          ref: KO,
          className: "PanelPromptInput",
          value: pO,
          maxLength: lO,
          rows: vK,
          placeholder: eO,
          spellCheck: !1,
          autoComplete: "off",
          onChange: OO => {
            XO(CO ? OO.target.value : OO.target.value.replace(/\r?\n/g, " "))
          },
          onKeyDown: OO => {
            OO.nativeEvent.isComposing || 229 === OO.nativeEvent.keyCode ? OO.stopPropagation() : "Escape" !== OO.key && (OO.stopPropagation(), null === hO || void 0 === hO || hO(OO), OO.defaultPrevented || "Enter" !== OO.key || CO && OO.shiftKey || (OO.preventDefault(), VO()))
          }
        }), (0, DO.jsx)(oO.d, {
          className: "PanelPromptSend",
          disabled: !FO,
          onClick: VO,
          ariaLabel: aK("codeEditorPanels:send"),
          children: (0, DO.jsx)(LO.d, {
            name: "arrow-up"
          })
        })]
      })
    }));

    function Ke(OO) {
      let {
        close: KO,
        inputRef: pO
      } = OO;
      const {
        t: XO
      } = (0, nO.D)(), {
        messages: eO,
        reportedPlayers: lO,
        channel: vK
      } = (0, Ub.t)(), [CO, hO] = (0, bK.useState)(""), MO = (0, bK.useRef)({
        stepsBack: 0,
        text: ""
      });
      return (0, DO.jsxs)("div", {
        className: "CodeEditorChatPanel",
        children: [(0, DO.jsxs)("div", {
          className: "CodeEditorChatHeader",
          children: [(0, DO.jsx)("span", {
            className: "CodeEditorChatTitle",
            children: XO("codeEditorChat:title")
          }), (0, DO.jsx)(oO.i, {
            className: "CodeEditorChatHide",
            onClick: KO
          })]
        }), 0 === eO.length ? (0, DO.jsx)("div", {
          className: "CodeEditorChatEmpty",
          children: XO("codeEditorChat:empty")
        }) : (0, DO.jsx)("div", {
          className: "ChatMessages CodeEditorChatMessages",
          children: (0, DO.jsx)(ke.b, {
            messages: eO,
            reportedPlayers: lO
          })
        }), (0, DO.jsx)(Oe, {
          ref: pO,
          value: CO,
          onChange: hO,
          onSubmit: () => {
            (0, Ub.p)(CO), hO(""), MO.current = {
              stepsBack: 0,
              text: ""
            }
          },
          maxLength: yK.Rc,
          rows: 1,
          placeholder: vK ? XO("touchOnly" === (0, te.c)() ? "codeEditorChat:channelPlaceholderTouch" : "codeEditorChat:channelPlaceholder", {
            channel: vK.channelName
          }) : XO("codeEditorChat:placeholder"),
          before: vK && (0, DO.jsx)("button", {
            type: "button",
            className: "CodeEditorChatChannel",
            style: {
              backgroundColor: vK.elementBgColor
            },
            onClick: () => {
              Ub.e.selectNextChannel(), pO.current.focus()
            },
            children: (0, DO.jsx)(NO.d, {
              text: vK.elementContent
            })
          }),
          onKeyDown: OO => {
            const KO = CO === MO.current.text;
            if ("ArrowUp" !== OO.key && "ArrowDown" !== OO.key || !KO && "" !== CO) "Tab" === OO.key && !OO.shiftKey && vK && (OO.preventDefault(), Ub.e.selectNextChannel());
            else {
              OO.preventDefault();
              const pO = KO ? MO.current.stepsBack : 0;
              MO.current = (0, Ub.l)(pO + ("ArrowUp" === OO.key ? 1 : -1)), hO(MO.current.text)
            }
          }
        })]
      })
    }

    function pe(OO) {
      let {
        side: KO,
        defaultWidth: pO,
        children: XO
      } = OO;
      const eO = (0, bK.useRef)(null),
        [lO, vK] = (0, bK.useState)(null),
        CO = (0, bK.useRef)(null),
        hO = () => {
          CO.current = null
        };
      return (0, DO.jsxs)("div", {
        ref: eO,
        className: DK()("ResizableSidePanel", `ResizableSidePanel-${KO}`),
        style: {
          width: null !== lO && void 0 !== lO ? lO : pO
        },
        children: [XO, (0, DO.jsx)("div", {
          className: "ResizableSidePanelHandle",
          role: "separator",
          "aria-orientation": "vertical",
          onPointerDown: OO => {
            if (0 !== OO.button) return;
            OO.preventDefault();
            const KO = eO.current,
              pO = Array.from(KO.parentElement.children).reduce(((OO, pO) => pO !== KO && "0" !== getComputedStyle(pO).flexGrow ? OO + pO.clientWidth : OO), 0),
              XO = KO.offsetWidth,
              bK = Math.min(200, XO),
              lO = Math.max(bK, XO + Math.max(0, pO - 160));
            CO.current = {
              startX: OO.clientX,
              startWidth: XO,
              minWidth: bK,
              maxWidth: lO
            }, OO.currentTarget.setPointerCapture(OO.pointerId)
          },
          onPointerMove: OO => {
            const pO = CO.current;
            if (!pO) return;
            const XO = "left" === KO ? OO.clientX - pO.startX : pO.startX - OO.clientX;
            vK(Math.min(pO.maxWidth, Math.max(pO.minWidth, pO.startWidth + XO)))
          },
          onPointerUp: hO,
          onPointerCancel: hO,
          onLostPointerCapture: hO
        })]
      })
    }
    var Xe = pO(35378);
    class bl {
      constructor(OO, KO) {
        this.storageKey = OO, this.defaultValue = KO, this.value = null, this.listeners = new Set, this.get = () => {
          if (null === this.value) {
            const OO = iK.e.getItem(this.storageKey);
            this.value = "boolean" === typeof OO ? OO : this.defaultValue
          }
          return this.value
        }, this.set = OO => {
          this.value = OO, iK.e.setItem(this.storageKey, OO);
          for (const KO of this.listeners) KO(OO)
        }
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
    }
    const ee = new bl("codeEditorLightMode", !1),
      le = new bl("codeEditorAiHints", !0);

    function vl(OO) {
      const [KO, pO] = (0, bK.useState)(OO.get);
      return (0, bK.useEffect)((() => {
        const KO = OO.subscribe(pO);
        return pO(OO.get()), KO
      }), [OO]), [KO, OO.set]
    }
    var Ce = pO(35383),
      he = pO(35386),
      De = pO(1441),
      Me = pO(35395);
    const al = (0, bK.lazy)((() => Promise.all([pO.e(279), pO.e(275), pO.e(278), pO.e(274), pO.e(72), pO.e(277), pO.e(276), pO.e(273)]).then((() => pO(39328))))),
      oe = (0, bK.lazy)((() => Promise.all([pO.e(67), pO.e(70), pO.e(71), pO.e(69), pO.e(281)]).then((() => pO(39501))))),
      Fe = (0, bK.lazy)((() => Promise.all([pO.e(279), pO.e(278), pO.e(72), pO.e(70), pO.e(71), pO.e(69), pO.e(277), pO.e(276), pO.e(68), pO.e(77)]).then((() => pO(39503)))));

    function Ve(OO) {
      return hO.gameBridge.query("worldCodeAiChunk", OO)
    }

    function Le() {
      return hO.gameBridge.query("worldCodeAiGameState", null)
    }

    function Qe(OO) {
      const {
        gsUrl: KO,
        gameNameWithVariation: pO,
        lobbyName: XO
      } = sb();
      return (0, lb.postJsonWithMetricsCookiesAndJsonResponse)(`${KO}/code/get-lobby-code`, eb.Gj["get-lobby-code"].toBuffer({
        gameNameWithVariation: pO,
        lobbyName: XO,
        path: OO
      }), {
        retries: 1
      })
    }
    let zl = !1;
    const Ae = [],
      fe = {
        message: "You do not have permission to view the code.",
        type: "warning"
      },
      de = (0, bK.memo)((function(OO) {
        var KO, pO;
        let {
          show: XO,
          onOpen: eO,
          onClose: vK,
          isLobbyCode: MO
        } = OO;
        const aK = (0, bK.useRef)(""),
          [VO, QO] = (0, bK.useState)(null),
          zK = (0, bK.useRef)(MO),
          [AO, fO] = (0, bK.useState)({
            message: null,
            type: null
          }),
          [dO, TO] = (0, bK.useState)(""),
          NO = AO.message ? AO : {
            message: dO,
            type: "warning"
          },
          [EO, jK] = (0, bK.useState)(!0),
          [YO, iK] = vl(ee),
          [rK, PO] = vl(le),
          [mK, sO] = (0, bK.useState)(!1),
          [HO, SO] = (0, bK.useState)(!1),
          JO = (0, bK.useRef)(null),
          cK = (0, bK.useRef)(!1);
        (0, bK.useEffect)((() => {
          var OO;
          HO && cK.current && (cK.current = !1, null === (OO = JO.current) || void 0 === OO || OO.focus())
        }), [HO]);
        const BO = (0, Xe.b)(),
          ZO = (0, bK.useRef)(null),
          GO = (0, bK.useRef)(null),
          {
            openInGameMenuName: xK,
            openEverythingMenuName: WO
          } = (0, RO.l)(["openInGameMenuName", "openEverythingMenuName"]),
          tK = OO => {
            XO && (ZO.current = OO, IK.current = !0)
          };
        (0, IO.f)("OpenReportMenu", (() => {
          tK("CX")
        })), (0, IO.f)("OpenStoreFromCodeEditor", (() => {
          tK("store")
        })), (0, bK.useEffect)((() => {
          const OO = ZO.current;
          null === OO || "CX" === OO && ("makeReport" === xK || "makeDiscordReport" === xK) || "store" === OO && null !== WO || (ZO.current = null, null === xK && null === WO ? MO ? (GO.current = pp.current, FO.i.pl("EditLobbyCode", VO)) : FO.i.pl("EditCodeBlock", {
            pos: VO,
            canChangePos: zK.current
          }) : (0, nb.z)())
        }), [xK, WO, MO, VO]), (0, bK.useEffect)((() => {
          if (XO) return () => {
            GO.current = null
          }
        }), [XO]);
        const [kK, UO] = function() {
          const [OO, KO] = (0, bK.useState)(zl);
          return (0, IO.f)("CodeEditorAiHelperShown", (OO => {
            KO(OO)
          })), [OO, (0, bK.useCallback)((OO => {
            zl = OO, FO.i.pl("CodeEditorAiHelperShown", OO)
          }), [])]
        }(), [OK, KK] = (0, bK.useState)(null), [pK, XK] = (0, bK.useState)([]), [bp, eK] = (0, bK.useState)(0), [lK, vp] = (0, bK.useState)(0), [CK, hK] = (0, bK.useState)(""), MK = (0, bK.useRef)(null), [ap, oK] = (0, bK.useState)(MO ? Me.i : null), FK = MO || null !== VO, VK = (0, CO.i)("canEditCode"), LK = (0, CO.i)("canUseDevCreativeItems"), QK = (0, xe.j)("welcome"), zp = (0, xe.j)("docsOverview"), AK = zp ? "docsOverview" : "welcome", fK = null !== zp && void 0 !== zp ? zp : QK, dK = (0, xe.j)("aiHelperOverview"), TK = dK ? "aiHelperOverview" : "welcome", NK = null !== dK && void 0 !== dK ? dK : QK, IK = (0, bK.useRef)(!1), yp = (0, bK.useRef)(!1), gp = (0, bK.useRef)(null), [EK, jp] = (0, bK.useState)(""), [YK, wK] = (0, bK.useState)(!1), [ip, rp] = (0, bK.useState)(null), PK = (0, gK.i)("connectedGame"), mp = MO && VK && "classic" === PK.gameNameWithVariation && !(0, uK.J)(PK.lobbyName), [sK, HK] = (0, bK.useState)(null), [RK, SK] = (0, bK.useState)({
          [ve.f]: ""
        }), [JK, cp] = (0, bK.useState)({
          assets: {},
          revision: 0
        }), BK = (0, bK.useRef)(JK), ZK = (0, bK.useCallback)((OO => {
          var KO;
          OO.revision < BK.current.revision || (BK.current = OO, cp(OO), TO(OO.startupError ? `Schematics could not load: ${OO.startupError}` : ""), null === (KO = Fp.current) || void 0 === KO || KO.onLobbyFilesChanged({
            ...vX.current,
            ...(0, ze.i)(OO.assets)
          }))
        }), []), [GK, qp] = (0, bK.useState)(ve.f), [nK, WK] = (0, bK.useState)(null), [kp, UK] = (0, bK.useState)(null), Op = (0, bK.useRef)(!1), Kp = (0, bK.useRef)(null), pp = (0, bK.useRef)(GK);
        pp.current = GK;
        const Xp = (0, bK.useRef)(nK);
        Xp.current = nK;
        const bX = nK ? null : ip,
          ep = bX && !bX.engineLocked ? bX.worldCodeEngine : null,
          lp = (0, bK.useRef)(kp);
        lp.current = kp;
        const vX = (0, bK.useRef)(RK);
        vX.current = RK;
        const Cp = (0, bK.useRef)(null),
          hp = (0, bK.useRef)(null),
          [Dp, Mp] = (0, bK.useState)(!1),
          aX = (0, Eb.o)(),
          op = (0, bK.useRef)([]),
          Fp = (0, bK.useRef)(null),
          Vp = (0, bK.useRef)(null),
          Lp = (0, bK.useRef)(null);

        function Qp(OO) {
          fO(OO), clearTimeout(gp.current), gp.current = setTimeout((() => {
            fO({
              message: null,
              type: null
            })
          }), 3e3)
        }
        const zX = (0, bK.useCallback)((function() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            Op.current && Kp.current && (hO.gameBridge.send("sendCodeCollab", {
              Zm: Cb.b.Leave,
              Wm: (0, Cb.C)(Kp.current),
              qH: !!OO || null
            }), Op.current = !1, Kp.current = null), HK(null)
          }), []),
          Ap = (0, bK.useCallback)((OO => {
            const KO = {
              kind: "lobby",
              path: OO
            };
            Kp.current = KO, qp(OO), aK.current = "", hO.gameBridge.send("sendCodeCollab", {
              Zm: Cb.b.Join,
              Wm: (0, Cb.C)(KO)
            }), Op.current = !0
          }), []),
          fp = (0, bK.useCallback)((OO => {
            var KO;
            const pO = null === (KO = Vp.current) || void 0 === KO ? void 0 : KO.collabState;
            return pO && "lobby" === pO.docKey.kind && pO.docKey.path === OO && pp.current === OO ? Promise.resolve({
              doc: pO.doc,
              version: pO.version,
              clientID: pO.clientID,
              docKey: pO.docKey,
              httpConfig: pO.httpConfig
            }) : new Promise(((KO, pO) => {
              const XO = setTimeout((() => {
                  op.current = op.current.filter((OO => OO !== bK)), pO(new Error(`Timed out joining ${OO}`))
                }), 15e3),
                bK = pO => {
                  "lobby" === pO.docKey.kind && pO.docKey.path === OO && (clearTimeout(XO), op.current = op.current.filter((OO => OO !== bK)), KO(pO))
                };
              op.current.push(bK), pp.current !== OO ? (zX(!0), Ap(OO)) : Op.current || Ap(OO)
            }))
          }), [Ap, zX]),
          dp = (0, bK.useCallback)((async function(OO, KO) {
            let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1e4;
            const XO = Date.now();
            let bK = OO in vX.current;
            for (; bK !== KO;) {
              if (Date.now() - XO > pO) throw new Error(`Timed out waiting for lobby path ${OO} present=${KO}`);
              await (0, zb.M)(50), bK = OO in vX.current
            }
          }), []),
          Tp = (0, bK.useCallback)((OO => {
            const KO = vX.current,
              pO = ve.f in KO && ve.j in KO;
            if (!(0, hb.h)(OO) || pO) {
              if (pp.current === OO) {
                var XO;
                const bK = pO && (0, hb.h)(OO) ? OO === ve.f ? ve.j : ve.f : null !== (XO = (0, hb.b)(KO)) && void 0 !== XO ? XO : ve.f;
                hp.current = {
                  fromPath: OO,
                  toPath: bK
                }, qp(bK)
              }
              hO.gameBridge.send("sendCodeCollab", {
                Zm: Cb.b.DeleteFile,
                Wm: (0, Cb.C)({
                  kind: "lobby",
                  path: pp.current
                }),
                xH: OO
              })
            }
          }), []),
          Np = (0, bK.useCallback)((OO => {
            GO.current = null, WK(null), UK(null), !MO || OO === pp.current && Op.current || (zX(!0), Ap(OO))
          }), [MO, zX, Ap]),
          Ip = (0, bK.useCallback)(((OO, KO) => {
            const pO = Lb.e[OO],
              XO = pO && KO in pO.files ? KO : "index.ts";
            if (OO !== Xp.current || XO !== lp.current) {
              var bK;
              if (OO !== Xp.current) null === (bK = Fp.current) || void 0 === bK || bK.stopContinuousSync(), zX(!0);
              WK(OO), UK(XO)
            }
          }), [zX]),
          yX = (0, bK.useCallback)((OO => {
            var KO;
            const pO = pp.current,
              XO = vX.current[pO],
              bK = Op.current && !Xp.current && pO in OO && void 0 !== XO ? {
                ...OO,
                [pO]: XO
              } : OO;
            SK(bK);
            const eO = Cp.current;
            if (eO && eO in OO) Cp.current = null, eO !== pp.current && Np(eO);
            else if (!(pp.current in OO) && Op.current && !Xp.current) {
              var lO;
              Np(null !== (lO = (0, hb.b)(OO)) && void 0 !== lO ? lO : ve.f)
            }
            null === (KO = Fp.current) || void 0 === KO || KO.onLobbyFilesChanged({
              ...bK,
              ...(0, ze.i)(BK.current.assets)
            })
          }), [Np]),
          gX = (0, bK.useCallback)((() => Qe(pp.current).then((async OO => {
            if (!Op.current || !OO.files) return null;
            yX(OO.files);
            const KO = await Hb({
              action: "state"
            });
            return ZK(KO), {
              ...OO.files,
              ...(0, ze.i)(KO.assets)
            }
          })).catch((OO => (console.error("[CodeCollab] Failed to fetch lobby files via HTTP", OO), Qp({
            message: "Could not refresh the file list",
            type: "warning"
          }), null)))), [yX, ZK]),
          upO = () => {
            vK()
          };
        (0, bK.useEffect)((() => {
          if (TO(""), !XO || !MO) return;
          let OO = !1;
          return BK.current = {
            assets: {},
            revision: 0
          }, cp(BK.current), Hb({
            action: "state"
          }).then((KO => {
            OO || ZK(KO)
          })).catch((KO => {
            console.error("Could not load project schematics", KO), OO || TO("Could not load schematics. Reopen the Code Editor to retry.")
          })), () => {
            OO = !0
          }
        }), [XO, MO, ZK]);
        const Ep = (0, bK.useCallback)((() => {
            Kp.current && hO.gameBridge.send("sendCodeCollab", {
              Zm: Cb.b.Submit,
              Wm: (0, Cb.C)(Kp.current)
            })
          }), []),
          jX = (0, bK.useCallback)((() => {
            if (!Kp.current || "lobby" !== Kp.current.kind) return;
            const OO = EK.trim();
            (0, Db.r)(OO) ? (hO.gameBridge.send("sendCodeCollab", {
              Zm: Cb.b.ReloadAsVariation,
              Wm: (0, Cb.C)(Kp.current),
              Fs: OO
            }), wK(!1)) : Qp({
              message: "Variation must be 1-32 characters: A-Z, a-z, 0-9, _, -",
              type: "warning"
            })
          }), [EK]),
          Yp = (0, bK.useCallback)((OO => {
            hO.gameBridge.send("sendCodeCollab", {
              Zm: Cb.b.SetEngine,
              Wm: (0, Cb.C)({
                kind: "lobby",
                path: pp.current
              }),
              Fs: OO
            })
          }), []),
          wp = (0, bK.useCallback)((OO => {
            if (!Xp.current && VK && (zK.current || MO)) {
              if (MO) {
                var KO;
                const pO = (0, hb.p)(vX.current, pp.current),
                  XO = Math.min(xp.x, Math.max(0, xp.B - pO)),
                  bK = OO.slice(0, XO);
                return aK.current = bK, SK((OO => ({
                  ...OO,
                  [pp.current]: bK
                }))), void(null === (KO = Fp.current) || void 0 === KO || KO.onDocTextChanged(pp.current, bK))
              }
              aK.current = OO, hK(OO)
            }
          }), [VK, MO]);
        (0, IO.f)("EditLobbyCode", (OO => {
          var KO;
          wO.featureFlags.canSeePlayerWrittenText && MO && (zX(), QO(OO), aK.current = "", SK({
            [ve.f]: ""
          }), rp(null), qp(ve.f), WK(null), UK(null), Cp.current = null, hp.current = null, null === (KO = Fp.current) || void 0 === KO || KO.stopContinuousSync(), eO(), Ap(ve.f))
        })), (0, IO.f)("EditCodeBlock", (OO => {
          let {
            pos: KO,
            canChangePos: pO
          } = OO;
          if (wO.featureFlags.canSeePlayerWrittenText && !MO)
            if (zX(), null !== KO && (KO = [...KO]), QO(KO), zK.current = pO, null !== KO) {
              aK.current = "", hK(""), eO();
              const OO = {
                  kind: "codeBlock",
                  pos: KO
                },
                XO = (0, Cb.C)(OO);
              MK.current !== XO && (MK.current = XO, XK([]), vp(bp)), oK((0, Me.e)(XO, [KO[0], KO[1], KO[2]], !!pO)), Kp.current = OO, hO.gameBridge.send("sendCodeCollab", {
                Zm: Cb.b.Join,
                Wm: (0, Cb.C)(OO)
              }), Op.current = !0
            } else XO && vK()
        })), (0, IO.f)("codeCollabRejoin", (OO => {
          const KO = Kp.current ? (0, Cb.C)(Kp.current) : null;
          KO && OO.docKey === KO && (aK.current = OO.doc, MO || hK(OO.doc), HK((KO => KO ? {
            ...KO,
            doc: OO.doc,
            version: OO.version,
            clientID: (0, Vb.c)()
          } : KO)))
        })), (0, IO.f)("codeCollab", (OO => {
          var KO;
          const pO = Kp.current ? (0, Cb.C)(Kp.current) : null;
          if (OO.type === Cb.e.LobbyFilesChanged && MO) {
            if ("string" !== typeof OO.files) return void gX();
            try {
              yX(JSON.parse(OO.files))
            } catch (hO) {
              console.error("[CodeCollab] Failed to parse lobby files", hO), gX()
            }
            return
          }
          if (OO.type === Cb.e.EngineSettings && MO) return void rp(ce(OO.engineSettings));
          const bK = OO.type === Cb.e.Joined ? (0, Cb.m)(OO.docKey) : null,
            eO = MO && "lobby" === (null === (KO = Kp.current) || void 0 === KO ? void 0 : KO.kind) && (0, hb.h)(Kp.current.path) && "lobby" === (null === bK || void 0 === bK ? void 0 : bK.kind) && (0, hb.h)(bK.path);
          if (!pO || OO.docKey === pO || eO)
            if (OO.type !== Cb.e.ForceClose) {
              if (XO)
                if (OO.type === Cb.e.Joined) {
                  var lO;
                  const DO = JSON.parse(OO.peers),
                    oO = OO.existingCursors ? JSON.parse(OO.existingCursors) : [],
                    FO = (0, Vb.c)(),
                    LO = sb(),
                    {
                      gsUrl: QO,
                      gameNameWithVariation: zK,
                      lobbyName: AO
                    } = LO,
                    dO = null !== (lO = (0, Cb.m)(OO.docKey)) && void 0 !== lO ? lO : Kp.current;
                  dO && (Kp.current = dO, "lobby" === dO.kind && (qp(dO.path), pp.current = dO.path));
                  const TO = dO || (MO ? {
                    kind: "lobby",
                    path: pp.current
                  } : {
                    kind: "codeBlock",
                    pos: VO
                  });

                  function NO(KO) {
                    var pO, XO;
                    if (!Op.current) return;
                    const bK = null !== (pO = KO.code) && void 0 !== pO ? pO : "",
                      eO = null !== (XO = KO.collabVersion) && void 0 !== XO ? XO : 0;
                    aK.current = bK, MO || hK(bK), MO && KO.files ? SK(KO.files) : MO && SK((OO => ({
                      ...OO,
                      [pp.current]: bK
                    })));
                    const lO = {
                      doc: bK,
                      version: eO,
                      clientID: FO,
                      docKey: TO,
                      peers: DO,
                      editorCount: OO.editorCount,
                      existingCursors: oO,
                      httpConfig: LO
                    };
                    if (HK(lO), "lobby" === TO.kind) {
                      var vK;
                      const OO = {
                        doc: bK,
                        version: eO,
                        clientID: FO,
                        docKey: TO,
                        httpConfig: LO
                      };
                      for (const KO of [...op.current]) KO(OO);
                      null === (vK = Fp.current) || void 0 === vK || vK.startWhenReady()
                    }
                    KO.canSeeCode ? (clearTimeout(gp.current), fO({
                      message: null,
                      type: null
                    })) : function(OO) {
                      clearTimeout(gp.current), fO(OO)
                    }(fe);
                    const CO = GO.current;
                    GO.current = null, MO && CO && KO.files && CO in KO.files && CO !== pp.current && Np(CO)
                  }
                  MO ? Qe(pp.current).then(NO).catch((OO => {
                    console.error("[CodeCollab] Failed to fetch lobby code via HTTP", OO), zX()
                  })) : (0, lb.postJsonWithMetricsCookiesAndJsonResponse)(`${QO}/code/get-code-block`, eb.Gj["get-code-block"].toBuffer({
                    gameNameWithVariation: zK,
                    lobbyName: AO,
                    pos: VO
                  }), {
                    retries: 1
                  }).then(NO).catch((OO => {
                    console.error("[CodeCollab] Failed to fetch code block via HTTP", OO), zX()
                  }))
                } else if (OO.type === Cb.e.Presence) {
                if (!pO) return;
                const IO = JSON.parse(OO.peers);
                HK((KO => KO ? {
                  ...KO,
                  peers: IO,
                  editorCount: OO.editorCount
                } : KO))
              }
            } else {
              var CO;
              if (!pO) return;
              const yK = Kp.current;
              Op.current = !1, Kp.current = null, HK(null);
              if (!MO || "close" === OO.updates) return (0, he.g)(), void(XO && vK());
              if (!XO) return;
              const gK = vX.current,
                uO = hp.current;
              hp.current = null;
              const EO = "lobby" === (null === yK || void 0 === yK ? void 0 : yK.kind) && yK.path === (null === uO || void 0 === uO ? void 0 : uO.fromPath),
                jK = uO && (EO || uO.toPath in gK || (0, hb.h)(uO.toPath)) ? uO.toPath : pp.current in gK ? pp.current : null !== (CO = (0, hb.b)(gK)) && void 0 !== CO ? CO : ve.f;
              Ap(jK)
            }
        })), (0, IO.f)("refetchCode", (() => {
          wO.featureFlags.canSeePlayerWrittenText && XO && Op.current && (VK || (zX(), MO ? FO.i.pl("EditLobbyCode", VO) : FO.i.pl("EditCodeBlock", {
            pos: VO,
            canChangePos: zK.current
          })))
        }));
        const iX = (0, bK.useCallback)((() => {
            XO && (sO(!1), window.open("/docs", "_blank", "popup=yes,width=1200,height=800"))
          }), [XO]),
          rX = (0, bK.useCallback)((() => {
            sO(!1)
          }), []);
        (0, bK.useEffect)((() => {
          XO && VK && ("docsButton" === fK && mK ? (0, nb.e)("docsButton") : fK && nb.i.includes(fK) && !mK && (sO(!0), UO(!1)))
        }), [XO, VK, fK, mK, UO]);
        const Pp = (0, bK.useCallback)((() => {
          UO(!1)
        }), [UO]);
        (0, bK.useEffect)((() => {
          XO && VK && FK && ("aiHelperButton" === NK && kK ? (0, nb.e)("aiHelperButton") : NK && nb.b.includes(NK) && !kK && (UO(!0), sO(!1)))
        }), [XO, VK, FK, NK, kK, UO]), (0, bK.useEffect)((() => {
          if (!XO || !VK) return;
          const OO = MO ? "worldCode" : "codeBlock";
          return (0, nb.B)(OO, !0), () => {
            (0, nb.B)(OO, !1)
          }
        }), [XO, VK, MO]), (0, bK.useEffect)((() => {
          if (XO) return () => {
            IK.current ? IK.current = !1 : (0, nb.z)()
          }
        }), [XO]), (0, bK.useEffect)((() => {
          (0, nb.E)("exportButton", !!LK)
        }), [LK]);
        const {
          t: mX
        } = (0, nO.D)(), sp = !kK && bp > lK, Hp = sp ? oO.I : oO.y, Rp = (0, bK.useCallback)(((OO, KO) => {
          FO.i.pl("CodeEditorGoToLine", {
            path: OO,
            line: KO
          }), Np(OO)
        }), [Np]), Sp = (0, bK.useCallback)((OO => {
          Lp.current = OO
        }), []), Jp = function(OO, KO) {
          const [pO, XO] = (0, bK.useState)(null);
          return (0, bK.useEffect)((() => {
            if (!KO) return void XO(null);
            let pO = !1;
            return ub(OO).then((OO => {
              pO || XO(OO)
            }), (OO => {
              console.error("[CodeEditor] could not collect the imported plugins", OO), pO || XO(null)
            })), () => {
              pO = !0
            }
          }), [OO, KO]), pO
        }(RK, XO);
        (0, bK.useEffect)((() => {
          Jp && nK && !Jp.includes(nK) && (WK(null), UK(null), MO && !Op.current && Ap(pp.current))
        }), [nK, Jp, MO, Ap]), Vp.current = {
          collabState: sK,
          ensureJoinedPath: fp,
          waitForLobbyPath: dp,
          pullLobbyFiles: gX,
          t: mX,
          canEditCode: !!VK
        }, Fp.current || (Fp.current = new Pb({
          getLobbyFiles: () => ({
            ...vX.current,
            ...(0, ze.i)(BK.current.assets)
          }),
          deleteSchematic: async OO => {
            const KO = await Hb({
              action: "remove",
              path: OO,
              expectedRevision: BK.current.revision
            });
            ZK(KO)
          },
          getActivePath: () => pp.current,
          getCollabSnapshot: () => {
            var OO;
            if (Xp.current) return null;
            const KO = null === (OO = Vp.current) || void 0 === OO ? void 0 : OO.collabState;
            return KO ? {
              doc: KO.doc,
              version: KO.version,
              clientID: KO.clientID,
              docKey: KO.docKey,
              httpConfig: KO.httpConfig
            } : null
          },
          replaceActiveDoc: (OO, KO) => {
            var pO, XO;
            return null !== (pO = null === (XO = Lp.current) || void 0 === XO ? void 0 : XO.call(Lp, OO, KO)) && void 0 !== pO && pO
          },
          ensureJoined: OO => Vp.current.ensureJoinedPath(OO),
          createFile: (OO, KO) => {
            !1 !== (null === KO || void 0 === KO ? void 0 : KO.focus) && (Cp.current = OO), hO.gameBridge.send("sendCodeCollab", {
              Zm: Cb.b.CreateFile,
              Wm: (0, Cb.C)({
                kind: "lobby",
                path: pp.current
              }),
              xH: OO
            })
          },
          renameFile: (OO, KO) => {
            const pO = (0, Cb.C)({
              kind: "lobby",
              path: pp.current
            });
            pp.current === OO && (hp.current = {
              fromPath: OO,
              toPath: KO
            }, qp(KO)), hO.gameBridge.send("sendCodeCollab", {
              Zm: Cb.b.RenameFile,
              Wm: pO,
              xH: OO,
              Ws: KO
            })
          },
          deleteFile: OO => {
            Tp(OO)
          },
          waitForLobbyPath: (OO, KO, pO) => Vp.current.waitForLobbyPath(OO, KO, pO),
          pullLobbyFiles: () => Vp.current.pullLobbyFiles(),
          setMessage: (OO, KO) => {
            Qp({
              message: OO,
              type: KO
            })
          },
          onUnlinked: () => {
            Mp(!1)
          },
          t: OO => Vp.current.t(OO),
          canEditCode: () => Vp.current.canEditCode,
          getStorageKey: () => {
            const {
              gameNameWithVariation: OO,
              lobbyName: KO
            } = hO.gameBridge.latest("connectedGame");
            return (0, Eb.i)(OO, KO)
          }
        }));
        const cX = (0, bK.useCallback)((async OO => {
            const KO = Fp.current;
            if (!KO) return !1;
            try {
              return await KO.writeLobbyFiles(OO)
            } catch (pO) {
              return console.error("World Code AI: couldn't write the change", pO), !1
            }
          }), []),
          Bp = (0, bK.useCallback)((async OO => {
            var KO, pO;
            const XO = null === (KO = OO.find((OO => OO.path === Ce.b))) || void 0 === KO ? void 0 : KO.text,
              bK = Kp.current;
            return void 0 !== XO && "codeBlock" === (null === bK || void 0 === bK ? void 0 : bK.kind) && (!(null === (pO = Lp.current) || void 0 === pO || !pO.call(Lp, (0, Cb.C)(bK), XO)) && (aK.current = XO, hK(XO), !0))
          }), []),
          Zp = (0, bK.useCallback)((async () => {
            try {
              var OO, KO;
              const pO = await Qe(ve.f);
              return !1 === pO.canSeeCode ? null : null !== (OO = pO.files) && void 0 !== OO ? OO : {
                [ve.f]: null !== (KO = pO.code) && void 0 !== KO ? KO : ""
              }
            } catch (pO) {
              return console.error("World Code AI: couldn't read World Code for a code block", pO), null
            }
          }), []),
          Gp = (0, bK.useMemo)((() => ({
            [Ce.b]: CK
          })), [CK]),
          qX = (0, bK.useCallback)(((OO, KO) => {
            FO.i.pl("CodeEditorGoToLine", {
              path: Ce.b,
              line: KO
            })
          }), []);
        (0, bK.useEffect)((() => {
          kK && XO && vp(bp)
        }), [kK, XO, bp]);
        const xX = (0, bK.useCallback)((() => {
            var OO, KO;
            Ep();
            const pO = (0, wO.isTouchscreen)() ? "open World Code again" : `press ${null!==(OO=null===(KO=tp.s.OpenCodeEditor)||void 0===KO?void 0:KO[0])&&void 0!==OO?OO:"F8"}`,
              XO = MO ? `\ud83e\udd16 Try out your change, then ${pO} to tell the AI Helper how it went.` : "\ud83e\udd16 Click the code block to try your change, then open it again to tell the AI Helper how it went.";
            FO.i.pl("chat", {
              content: [{
                str: XO,
                style: {
                  color: yK.J.cyanUiText
                }
              }]
            })
          }), [Ep, MO]),
          np = (0, bK.useCallback)((OO => {
            const KO = VO,
              pO = zK.current;
            MO || !KO || hO.gameBridge.lookup("codeBlockClickable", KO) ? (0, he.j)(OO, {
              submit: () => {
                Ep(), FO.i.pl("chat", {
                  content: [{
                    str: "\ud83e\udd16 Testing your change. The AI Helper comes back in a moment.",
                    style: {
                      color: yK.J.cyanUiText
                    }
                  }]
                }), !MO && KO && setTimeout((() => {
                  hO.gameBridge.send("clickCodeBlock", KO)
                }), 1e3)
              },
              reopen: () => {
                (0, De.i)() || (MO ? FO.i.pl("EditLobbyCode", KO) : FO.i.pl("EditCodeBlock", {
                  pos: KO,
                  canChangePos: pO
                }))
              }
            }) : xX()
          }), [Ep, MO, VO, xX]),
          Wp = (0, bK.useCallback)((() => {
            UO(!1)
          }), [UO]),
          tX = (0, bK.useRef)(upO);
        tX.current = upO;
        const kX = (0, bK.useCallback)((function(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            FO.i.pl("WorldCodeAiDraft", {
              text: OO,
              send: KO
            }), tX.current(), FO.i.pl("EditLobbyCode", VO)
          }), [VO]),
          Up = (0, bK.useCallback)((OO => {
            tX.current(), OO.codeBlock ? FO.i.pl("EditCodeBlock", {
              pos: [...OO.pos],
              canChangePos: OO.canChangePos
            }) : FO.i.pl("EditLobbyCode", VO)
          }), [VO]);
        (0, IO.f)("WorldCodeAiDraft", (OO => {
          MO && (KK(OO), UO(!0))
        }));
        const OX = !!VK && !!fK && nb.i.includes(fK);
        (0, bK.useEffect)((() => {
          XO && kK && FK && !OX && sO(!1)
        }), [XO, kK, FK, OX]);
        const KX = (0, bK.useCallback)((() => {
            KK(null)
          }), []),
          [pX, XX] = (0, bK.useState)(null);
        (0, IO.f)("WorldCodeAiSelection", (OO => {
          XO && (XX(OO), UO(!0), sO(!1))
        }));
        const bb = (0, bK.useCallback)((() => {
          XX(null)
        }), []);
        (0, IO.f)("chat", (OO => {
          let {
            content: KO
          } = OO;
          if (!MO && null === MK.current) return;
          const pO = Array.isArray(KO) ? KO : [KO],
            XO = pO.some((OO => {
              var KO;
              return (null === OO || void 0 === OO || null === (KO = OO.style) || void 0 === KO ? void 0 : KO.color) === yK.J.redUiText
            })),
            bK = pO.map((OO => {
              var KO;
              const pO = null !== (KO = null === OO || void 0 === OO ? void 0 : OO.str) && void 0 !== KO ? KO : OO;
              return "string" === typeof pO ? pO : ""
            })).join("");
          XO && /world code|error/i.test(bK) && (XK((OO => [...OO, bK].slice(-10))), eK((OO => OO + 1)), (0, he.f)(bK))
        })), (0, bK.useEffect)((() => {
          if (!XO || !MO || !aX) return;
          let OO = !1;
          return (async (KO, pO) => {
            const XO = await (null === (KO = Fp.current) || void 0 === KO ? void 0 : KO.tryRestoreHandle());
            !OO && XO && (Mp(!0), null === (pO = Fp.current) || void 0 === pO || pO.startWhenReady())
          })(), () => {
            OO = !0
          }
        }), [XO, MO, aX]), (0, bK.useEffect)((() => {
          var OO;
          XO || (null === (OO = Fp.current) || void 0 === OO || OO.stopContinuousSync(), zX(!1), yp.current && (yp.current = !1, hO.gameBridge.send("sendChatMessage", {
            Tl: "//export",
            channelName: null
          })))
        }), [XO, zX]);
        const eX = (0, bK.useCallback)((async () => {
            if (aX && Fp.current) try {
              if (!await Fp.current.linkFolder()) return;
              Mp(!0), await Fp.current.startWhenReady()
            } catch (OO) {
              console.error("[WorldCodeDirectorySync] Link failed", OO), Qp({
                message: mX("codeEditor:directorySyncError"),
                type: "warning"
              })
            }
          }), [aX, mX]),
          lX = (0, bK.useCallback)((async () => {
            Fp.current && await Fp.current.unlinkFolder()
          }), []),
          vb = (0, bK.useCallback)((() => {
            aX ? Dp ? lX() : eX() : ae.NotificationProvider.showAlertPopup({
              title: "codeEditor:directorySyncUnsupported",
              subtitle: "codeEditor:directorySyncUnsupportedBody",
              confirmText: "general:ok"
            })
          }), [aX, Dp, eX, lX]);
        return (0, DO.jsxs)(lO.d, {
          className: DK()("CodeEditorBg", {
            CodeEditorLight: YO
          }),
          close: upO,
          escDoesExit: !0,
          show: XO,
          togglePointerLock: !1,
          globallyUniqueKey: MO ? "LobbyCodeEditor" : "CodeBlockEditor",
          children: [(0, DO.jsx)(xe.b, {
            tutorial: "welcome",
            step: "codeBlockIntro",
            text: mX("codeEditor:tutorialCodeBlockIntro"),
            enabled: !!VK && !MO
          }), (0, DO.jsx)(xe.b, {
            tutorial: "welcome",
            step: "worldCodeIntro",
            text: (0, DO.jsxs)(DO.Fragment, {
              children: [(0, DO.jsx)("p", {
                children: mX("codeEditor:tutorialWorldCodeWelcome")
              }), (0, DO.jsxs)("ul", {
                className: "TutorialStepList",
                children: [(0, DO.jsx)("li", {
                  children: mX("codeEditor:tutorialWorldCodeUseSetUp")
                }), (0, DO.jsx)("li", {
                  children: mX("codeEditor:tutorialWorldCodeUseReact")
                }), (0, DO.jsx)("li", {
                  children: mX("codeEditor:tutorialWorldCodeUseRun")
                })]
              })]
            }),
            enabled: !!VK && MO
          }), (0, DO.jsx)("div", {
            className: "CodeEditorTitle",
            children: MO ? "World Code" : "Code Block"
          }), (0, DO.jsxs)("div", {
            className: "CodeEditorTopBar",
            children: [(0, DO.jsx)("div", {
              className: "CodeEditorTopLeft",
              children: (0, DO.jsx)(qK.g, {
                tooltipInner: mX(LK ? "codeEditor:exportTooltip" : "codeEditor:exportOwnerOnly"),
                delayShow: LK ? void 0 : 0,
                hideTooltip: "exportButton" === QK,
                children: (0, DO.jsx)(xe.f, {
                  tutorial: "welcome",
                  step: "exportButton",
                  text: mX("codeEditor:tutorialExport"),
                  enabled: !!VK,
                  children: (0, DO.jsx)(oO.m, {
                    className: "CodeEditorButton",
                    disabled: !LK,
                    onClick: () => {
                      "exportButton" === QK && ((0, nb.e)("exportButton"), IK.current = !0), yp.current = !0, upO()
                    },
                    padDestructive: !0,
                    children: mX("codeEditor:exportWorld")
                  })
                })
              })
            }), (0, DO.jsxs)("div", {
              className: "CodeEditorTopRight",
              children: [VK && (0, DO.jsx)(qK.g, {
                tooltipInner: mX("codeEditor:helpTooltip"),
                hideTooltip: "helpButton" === QK,
                children: (0, DO.jsx)(xe.f, {
                  tutorial: "welcome",
                  step: "helpButton",
                  text: mX("codeEditor:tutorialHelpButton"),
                  placement: "bottom",
                  children: (0, DO.jsx)(oO.d, {
                    className: "CodeEditorHelpButton",
                    ariaLabel: mX("codeEditor:helpTooltip"),
                    onClick: () => {
                      (0, nb.e)("helpButton"), ae.NotificationProvider.showCustomPopup({
                        body: OO => (0, DO.jsx)(Wb, {
                          close: OO
                        }),
                        unlockPointerKey: "codeEditorTutorials"
                      })
                    },
                    children: (0, DO.jsx)("div", {
                      className: "CodeEditorHelpButtonInner",
                      children: (0, DO.jsx)(LO.d, {
                        name: "circle-question"
                      })
                    })
                  })
                })
              }), (0, DO.jsx)(qK.g, {
                tooltipInner: mX("codeEditor:closeTooltip"),
                children: (0, DO.jsx)("div", {
                  className: "CodeEditorCloseButtonClickZone",
                  onClick: () => {
                    upO()
                  },
                  children: (0, DO.jsx)(oO.i, {
                    className: "CodeEditorCloseButton"
                  })
                })
              })]
            })]
          }), (0, DO.jsx)(Fb, {
            peers: null !== (KO = null === sK || void 0 === sK ? void 0 : sK.peers) && void 0 !== KO ? KO : []
          }), (0, DO.jsxs)("div", {
            className: "CodeEditorMainArea",
            children: [HO && BO && (0, DO.jsx)(pe, {
              side: "left",
              defaultWidth: "max(16rem, 24%)",
              children: (0, DO.jsx)(Ke, {
                inputRef: JO,
                close: () => {
                  SO(!1)
                }
              })
            }), MO && (0, DO.jsx)(db, {
              schematics: JK.assets,
              onManageSchematic: OO => {
                VK && ae.NotificationProvider.showCustomPopup({
                  body: KO => (0, DO.jsx)(Jb, {
                    initialPath: OO,
                    onChanged: ZK,
                    onClose: KO
                  }),
                  unlockPointerKey: "worldCodeSchematics"
                })
              },
              files: RK,
              activePath: GK,
              canEdit: !!VK,
              directoryLinked: Dp,
              pluginNames: null !== Jp && void 0 !== Jp ? Jp : Ae,
              activePluginName: nK,
              activePluginFile: kp,
              onSelect: Np,
              onSelectPlugin: Ip,
              onToggleDirectorySync: vb,
              onCreate: OO => {
                Cp.current = OO, hO.gameBridge.send("sendCodeCollab", {
                  Zm: Cb.b.CreateFile,
                  Wm: (0, Cb.C)({
                    kind: "lobby",
                    path: pp.current
                  }),
                  xH: OO
                })
              },
              onRename: (OO, KO) => {
                pp.current === OO && (hp.current = {
                  fromPath: OO,
                  toPath: KO
                }, qp(KO)), hO.gameBridge.send("sendCodeCollab", {
                  Zm: Cb.b.RenameFile,
                  Wm: (0, Cb.C)({
                    kind: "lobby",
                    path: pp.current
                  }),
                  xH: OO,
                  Ws: KO
                })
              },
              onRenameFolder: (OO, KO) => {
                const [pO] = (0, hb.m)([pp.current], OO, KO);
                pO && (hp.current = {
                  fromPath: pO[0],
                  toPath: pO[1]
                }, qp(pO[1])), hO.gameBridge.send("sendCodeCollab", {
                  Zm: Cb.b.RenameFolder,
                  Wm: (0, Cb.C)({
                    kind: "lobby",
                    path: pp.current
                  }),
                  xH: OO,
                  Ws: KO
                })
              },
              onDelete: Tp
            }), (0, DO.jsx)("div", {
              className: DK()("CodeEditorMessage", {
                CodeEditorMessageHidden: !NO.message,
                CodeEditorMessageSuccess: "success" === NO.type
              }),
              children: NO.message && (0, DO.jsx)("div", {
                className: "CodeEditorMessageText",
                children: NO.message
              })
            }), (0, DO.jsx)(bK.Suspense, {
              fallback: (0, DO.jsx)("div", {
                className: "CodeEditorContent",
                children: (0, DO.jsx)(uO.e, {})
              }),
              children: (0, DO.jsx)(al, {
                isLobbyCode: MO,
                code: sK ? sK.doc : aK.current,
                files: MO ? RK : void 0,
                activePath: MO ? GK : void 0,
                pluginName: nK,
                pluginFile: kp,
                pluginSource: nK && kp ? null === (pO = Lb.e[nK]) || void 0 === pO ? void 0 : pO.files[kp] : void 0,
                onChange: wp,
                canEditCode: VK,
                setTemporaryMessage: Qp,
                close: upO,
                showTooltips: EO,
                lightMode: YO,
                collabState: sK,
                setActiveDocReplacer: Sp,
                showAiHints: FK && rK,
                canAiChangeCode: !!VK && (MO || !!zK.current),
                onRemoteDocChange: OO => {
                  var KO;
                  (aK.current = OO, MO) ? (SK((KO => ({
                    ...KO,
                    [pp.current]: OO
                  }))), null === (KO = Fp.current) || void 0 === KO || KO.onDocTextChanged(pp.current, OO)) : hK(OO)
                }
              })
            }), mK && (0, DO.jsx)(pe, {
              side: "right",
              defaultWidth: "40%",
              children: (0, DO.jsx)(bK.Suspense, {
                fallback: (0, DO.jsx)("div", {
                  className: "DocsPanel",
                  children: (0, DO.jsx)(uO.e, {})
                }),
                children: (0, DO.jsx)(oe, {
                  popOutDocs: iX,
                  hideDocs: rX,
                  tutorialEnabled: !!VK
                })
              })
            }), kK && ap && FK && (0, DO.jsx)(pe, {
              side: "right",
              defaultWidth: "max(18rem, 36%)",
              children: (0, DO.jsx)(bK.Suspense, {
                fallback: (0, DO.jsx)(uO.e, {}),
                children: (0, DO.jsx)(Fe, {
                  target: ap,
                  chatKey: `${PK.gameNameWithVariation}/${PK.lobbyName}/aiHelper`,
                  historyKey: `${PK.gameNameWithVariation}/${PK.lobbyName}/${ap.key}`,
                  files: ap.codeBlock ? Gp : RK,
                  activePath: ap.codeBlock ? Ce.b : GK,
                  canEdit: !!VK && (ap.codeBlock ? !!zK.current : !nK),
                  isLoaded: null !== sK,
                  errors: pK,
                  errorCount: bp,
                  applyFiles: ap.codeBlock ? Bp : cX,
                  submit: xX,
                  testRun: np,
                  close: Wp,
                  goToLine: ap.codeBlock ? qX : Rp,
                  openWorldCode: ap.codeBlock ? kX : void 0,
                  readWorldCode: ap.codeBlock ? Zp : void 0,
                  viewChunk: Ve,
                  viewGameState: Le,
                  openTarget: VK ? Up : void 0,
                  draft: OK,
                  onDraftUsed: KX,
                  selection: pX,
                  onSelectionUsed: bb
                }, ap.key)
              })
            })]
          }), (null === bX || void 0 === bX ? void 0 : bX.fallback) && (0, DO.jsx)(Bb, {
            fallback: bX.fallback,
            onGoToLine: Rp
          }), (0, DO.jsxs)("div", {
            className: "CodeEditorButtons",
            "data-pad-hint-bar-avoid": !0,
            children: [(0, DO.jsx)(qK.g, {
              tooltipInner: mX(YO ? "codeEditor:switchToDarkMode" : "codeEditor:switchToLightMode"),
              placement: "top",
              children: (0, DO.jsx)(oO.d, {
                className: "CodeEditorButton CodeEditorThemeButton",
                ariaLabel: mX(YO ? "codeEditor:switchToDarkMode" : "codeEditor:switchToLightMode"),
                onClick: () => {
                  iK(!YO)
                },
                children: (0, DO.jsx)(LO.d, {
                  name: YO ? "moon" : "sun-bright"
                })
              })
            }), (0, DO.jsx)(qK.g, {
              tooltipInner: mX("codeEditor:submitCodeTooltip"),
              placement: "top",
              children: (0, DO.jsx)(oO.m, {
                className: "CodeEditorButton",
                onClick: Ep,
                padDefaultFocus: !0,
                children: mX("codeEditor:submitCode")
              })
            }), (0, DO.jsx)(qK.g, {
              tooltipInner: mX(mK ? "codeEditor:hideDocsTooltip" : "codeEditor:showDocsTooltip"),
              placement: "top",
              hideTooltip: "docsButton" === fK || "hideDocsButton" === fK,
              children: (0, DO.jsx)(xe.f, {
                tutorial: AK,
                step: mK ? "hideDocsButton" : "docsButton",
                text: mX(mK ? "codeEditor:tutorialHideDocs" : "codeEditor:tutorialDocs"),
                enabled: !!VK,
                placement: "top",
                waitForClick: !0,
                onPrevious: mK && "welcome" === AK ? rX : void 0,
                children: (0, DO.jsx)(oO.y, {
                  className: "CodeEditorButton",
                  onClick: () => {
                    (0, nb.e)(mK ? "hideDocsButton" : "docsButton"), sO(!mK), UO(!1)
                  },
                  children: mX(mK ? "codeEditor:hideDocs" : "codeEditor:showDocs")
                })
              })
            }), FK && (0, DO.jsx)(xe.f, {
              tutorial: TK,
              step: kK ? "hideAiHelperButton" : "aiHelperButton",
              text: mX(kK ? "codeEditorAiTutorial:hideAiHelperButton" : "welcome" === TK ? "codeEditorAiTutorial:welcomeAiHelperButton" : "codeEditorAiTutorial:aiHelperButton"),
              enabled: !!VK,
              placement: "top",
              waitForClick: !0,
              onPrevious: kK && "welcome" === TK ? Pp : void 0,
              children: (0, DO.jsx)(Hp, {
                className: "CodeEditorButton",
                onClick: () => {
                  (0, nb.e)(kK ? "hideAiHelperButton" : "aiHelperButton"), UO(!kK), sO(!1)
                },
                children: kK ? "Hide AI Helper" : sp ? "Fix error with AI" : "AI Helper"
              })
            }), BO && (0, DO.jsx)(qK.g, {
              tooltipInner: mX(HO ? "codeEditorChat:hideChatTooltip" : "codeEditorChat:showChatTooltip"),
              placement: "top",
              children: (0, DO.jsx)(oO.y, {
                className: "CodeEditorButton",
                onClick: () => {
                  cK.current = !HO, SO(!HO)
                },
                children: mX(HO ? "codeEditorChat:hideChat" : "codeEditorChat:showChat")
              })
            }), (0, DO.jsx)(qK.g, {
              tooltipInner: mX("codeEditor:formatCodeTooltip"),
              placement: "top",
              children: (0, DO.jsx)(oO.d, {
                className: "CodeEditorButton",
                onClick: () => {
                  FO.i.pl("FormatCode")
                },
                children: mX("codeEditor:formatCode")
              })
            }), (0, DO.jsx)(qK.g, {
              tooltipInner: mX("codeEditor:copyCodeTooltip"),
              placement: "top",
              children: (0, DO.jsx)(oO.d, {
                className: "CodeEditorButton",
                onClick: () => {
                  navigator.clipboard.writeText(aK.current).then((() => {
                    Qp({
                      message: "Successfully copied code to clipboard",
                      type: "success"
                    })
                  })).catch((() => {
                    Qp({
                      message: "Failed to copy code to clipboard",
                      type: "warning"
                    })
                  }))
                },
                children: mX("codeEditor:copyCode")
              })
            }), (0, DO.jsx)(qK.g, {
              tooltipInner: mX(EO ? "codeEditor:hideTooltipsTooltip" : "codeEditor:showTooltipsTooltip"),
              placement: "top",
              children: (0, DO.jsx)(oO.d, {
                className: "CodeEditorButton",
                onClick: () => {
                  jK(!EO)
                },
                children: mX(EO ? "codeEditor:hideTooltips" : "codeEditor:showTooltips")
              })
            }), !MO && (0, DO.jsx)(qK.g, {
              tooltipInner: mX("codeEditor:worldCodeTooltip"),
              placement: "top",
              hideTooltip: "worldCodeButton" === QK,
              children: (0, DO.jsx)(xe.f, {
                tutorial: "welcome",
                step: "worldCodeButton",
                text: mX("codeEditor:tutorialWorldCodeButton"),
                enabled: !!VK,
                placement: "top",
                waitForClick: !0,
                children: (0, DO.jsx)(oO.y, {
                  className: "CodeEditorButton",
                  onClick: () => {
                    "worldCodeButton" === QK && ((0, nb.e)("worldCodeButton"), IK.current = !0), upO(), FO.i.pl("EditLobbyCode", VO)
                  },
                  children: mX("codeEditor:worldCode")
                })
              })
            }), (mp || ep || FK) && (0, DO.jsx)(qK.g, {
              tooltipInner: mX("codeEditor:moreOptionsTooltip"),
              placement: "top",
              children: (0, DO.jsx)(oO.d, {
                className: "CodeEditorButton CodeEditorMoreButton",
                onClick: () => {
                  wK(!0)
                },
                children: (0, DO.jsx)(LO.d, {
                  name: "ellipsis"
                })
              })
            })]
          }), YK && (0, DO.jsx)(Mb.c, {
            middleScreenPopupContainerClassName: "CodeEditorMoreOptionsPopup",
            close: () => {
              wK(!1)
            },
            body: (0, DO.jsx)(qe, {
              engine: ep,
              onSetEngine: Yp,
              aiHints: FK ? {
                shown: rK,
                setShown: PO
              } : null,
              variation: mp ? {
                name: EK,
                setName: jp,
                reload: jX
              } : null
            })
          })]
        })
      })),
      Te = new Set(["makeReport", "makeDiscordReport", "inviteLink"]);

    function Ne(OO) {
      return "inventory" === OO
    }
    const Ie = (0, bK.memo)((function() {
      const {
        openEverythingMenuName: OO,
        openInGameMenuName: KO
      } = (0, RO.l)(["openEverythingMenuName", "openInGameMenuName"]), pO = (0, gK.i)("fullInventory"), eO = (0, bK.useRef)(null), lO = (0, RX.k)();
      (0, IO.f)("toggleMenu", (OO => {
        var KO;
        if (!lO.shown) return;
        const pO = RO.d.get("openInGameMenuName");
        let XO = null === OO || void 0 === OO ? void 0 : OO.split("|")[0];
        const bK = null !== (KO = null === OO || void 0 === OO ? void 0 : OO.split("|")[1]) && void 0 !== KO ? KO : null;
        ("closeCurrentMenu" === bK && pO || XO === pO) && (eO.current = null, XO = null);
        const vK = "closeCurrentMenu" === bK ? null : bK;
        eO.current !== vK && (eO.current = vK), null !== XO && (0, xb.k)("InGameMenu", {
          keepsMovement: Ne(XO)
        }), RO.d.set({
          openInGameMenuName: XO
        })
      }));
      const vK = (0, bK.useCallback)((OO => () => {
          FO.i.pl("toggleMenu", OO)
        }), []),
        CO = (0, bK.useRef)({
          cantCrouchIfNotFullscreen: vK("cantCrouchIfNotFullscreen"),
          makeReport: vK("makeReport"),
          makeDiscordReport: vK("makeDiscordReport"),
          editBook: vK("editBook"),
          editNameTag: vK("editNameTag"),
          inventory: vK("inventory"),
          inviteLink: vK("inviteLink"),
          writeOnBoard: vK("writeOnBoard"),
          codeEditor: vK("codeEditor"),
          lobbyCodeEditor: vK("lobbyCodeEditor"),
          customLobbyBlockEditor: vK("customLobbyBlockEditor"),
          ironChestPasskeyInput: vK("ironChestPasskeyInput"),
          petUi: vK("petUi")
        }),
        hO = (0, bK.useCallback)((() => {
          RO.d.set({
            openInGameMenuName: null
          })
        }), []),
        MO = (0, bK.useRef)(null);
      return (0, bK.useEffect)((() => {
        if (KO) {
          var OO;
          (0, xb.k)("InGameMenu", {
            keepsMovement: Ne(KO)
          }), MO.current = Te.has(KO) ? null !== (OO = RO.d.get("openEverythingMenuName")) && void 0 !== OO ? OO : MO.current : null, RO.d.set({
            openEverythingMenuName: null
          })
        } else {
          const OO = MO.current;
          MO.current = null, null !== OO && null === RO.d.get("openEverythingMenuName") && RO.d.set({
            openEverythingMenuName: OO
          }), eO.current = null, (0, xb.j)("InGameMenu")
        }
      }), [KO]), (0, bK.useEffect)((() => {
        null !== OO && hO()
      }), [OO, hO]), (0, DO.jsxs)(DO.Fragment, {
        children: [(0, DO.jsx)(XO.i, {
          show: "clientGame" === KO
        }), (0, DO.jsx)(BX, {
          show: "cantCrouchIfNotFullscreen" === KO,
          onOpen: CO.current.cantCrouchIfNotFullscreen,
          onClose: hO
        }), (0, DO.jsx)(GX, {
          show: "makeReport" === KO,
          onOpen: CO.current.makeReport,
          onClose: hO
        }), (0, DO.jsx)(qb, {
          show: "makeDiscordReport" === KO,
          onOpen: CO.current.makeDiscordReport,
          onClose: hO
        }), (0, DO.jsx)(bX, {
          show: "editBook" === KO,
          onOpen: CO.current.editBook,
          onClose: hO
        }), (0, DO.jsx)(Xp, {
          show: "editNameTag" === KO,
          onOpen: CO.current.editNameTag,
          onClose: hO
        }), pO && (0, DO.jsx)(SX, {
          show: "inventory" === KO,
          onOpen: CO.current.inventory,
          onClose: hO,
          variation: eO.current
        }), (0, DO.jsx)(cp, {
          show: "inviteLink" === KO,
          onClose: hO,
          option: eO.current
        }), (0, DO.jsx)(PO, {
          show: "retentionFeatures" === KO,
          onClose: hO
        }), (0, DO.jsx)(pp, {
          show: "writeOnBoard" === KO,
          onOpen: CO.current.writeOnBoard,
          onClose: hO
        }), (0, DO.jsx)(de, {
          show: "lobbyCodeEditor" === KO,
          onOpen: CO.current.lobbyCodeEditor,
          onClose: hO,
          isLobbyCode: !0
        }), (0, DO.jsx)(de, {
          show: "codeEditor" === KO,
          onOpen: CO.current.codeEditor,
          onClose: hO,
          isLobbyCode: !1
        }), (0, DO.jsx)(WX, {
          show: "customLobbyBlockEditor" === KO,
          onOpen: CO.current.customLobbyBlockEditor,
          onClose: hO
        }), (0, DO.jsx)(Tp, {
          show: "ironChestPasskeyInput" === KO,
          onOpen: CO.current.ironChestPasskeyInput,
          onClose: hO
        }), (0, DO.jsx)(pb, {
          togglePointerLock: !0,
          show: "petUi" === KO,
          onOpen: CO.current.petUi,
          onClose: hO
        })]
      })
    }))
  },
  35025: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => Ie
    });
    pO(35033);
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(2981),
      vK = pO(1263),
      CO = pO(1533),
      hO = pO(976);

    function DO() {
      const OO = 2e3,
        [KO, pO] = (0, XO.useState)(null),
        [bK, DO] = (0, XO.useState)(null),
        MO = (0, XO.useRef)(null);
      (0, vK.f)("showBottomMessage", (KO => {
        let {
          message: pO,
          timeoutLength: XO = OO,
          type: bK
        } = KO;
        DO({
          message: pO,
          type: bK
        }), clearTimeout(MO.current), MO.current = setTimeout((() => {
          DO(null)
        }), XO)
      })), (0, vK.f)("showPermanentBottomMessage", (OO => {
        pO(OO)
      })), (0, XO.useEffect)((() => ((0, lO.c)((() => {
        pO(null)
      })), () => {
        clearTimeout(MO.current)
      })), []);
      const aK = bK || KO;
      return aK ? (0, hO.jsx)("div", {
        className: eO()("BottomScreenMessage", aK.type),
        children: (0, hO.jsx)(CO.d, {
          text: aK.message
        })
      }) : null
    }
    var MO = pO(1912),
      aK = pO(1556),
      oO = pO(1344),
      FO = pO(1994);

    function VO() {
      let OO;
      const KO = () => {
          clearTimeout(OO), OO = setTimeout((() => {
            aK.gameBridge.latest("connectedGame").replay || (aK.gameBridge.send("leaveGame", {
              reloadPath: "/"
            }), (0, oO.navigatePreserveSearch)("/"))
          }), 3e5)
        },
        pO = () => {
          clearTimeout(OO)
        };
      return window.addEventListener("focus", pO), window.addEventListener("blur", KO), () => {
        window.removeEventListener("blur", KO), window.removeEventListener("focus", pO), clearTimeout(OO)
      }
    }
    var LO = pO(1004),
      QO = pO(35037),
      zK = pO(1991),
      AO = pO(1195),
      fO = pO(1e3),
      dO = pO(26),
      TO = pO(933);
    const NO = (0, XO.memo)((function() {
      return (0, fO.c)(), (0, hO.jsx)(IO, {})
    }));
    class IO extends XO.Component {
      constructor(OO) {
        super(OO), this.showQueue = [], this.slideDuration = 1, this.state = {
          showQueue: [],
          currState: null
        }, this.currMessage = null, this.justShowed = !1
      }
      componentDidMount() {
        this.sub = dO.i.subscribe("TopRightHelper", (OO => {
          this.showQueue.push(OO), this.setState({
            showQueue: this.showQueue
          })
        }))
      }
      componentWillUnmount() {
        dO.i.unsubscribe(this.sub), clearTimeout(this.slideOutTimeout), clearTimeout(this.hidingMessageTimeout)
      }
      componentDidUpdate(OO, KO) {
        this.justShowed && (this.justShowed = !1, this.setState({
          currState: "slideIn"
        }), this.slideOutTimeout = setTimeout((() => {
          this.setState({
            currState: "slideOut"
          })
        }), 1e3 * ((this.currMessage.duration || 8) - 1)), this.hidingMessageTimeout = setTimeout((() => {
          this.showQueue.shift(), this.currMessage = null, this.setState({
            showQueue: this.showQueue,
            currState: null
          })
        }), 1e3 * (this.currMessage.duration || 8)))
      }
      render() {
        let OO, KO, pO, XO, bK, eO = !0;
        if (this.state.showQueue.length > 0 && null === this.state.currState ? (this.currMessage = this.state.showQueue[0], this.justShowed = !0, OO = "slideIn") : "slideOut" === this.state.currState ? OO = "slideOut" : null === this.currMessage && (eO = !1), this.currMessage) {
          const eO = this.currMessage.color || "rgb(102, 102, 102)";
          KO = {
            width: this.currMessage.width || "250px",
            height: this.currMessage.height || "70px",
            animation: "1s " + ("slideOut" === OO ? "HelperSlideKeyFrameReverse" : "HelperSlideKeyFrame")
          }, pO = {
            backgroundColor: eO
          }, XO = {
            animation: "2s " + ("slideOut" === OO ? "CloseNotification" : "ExpandNotification")
          }, bK = {
            fontSize: this.currMessage.fontSize || "16px",
            animation: "2s " + ("slideOut" === OO ? "textDisappear" : "textAppear")
          }
        }
        return eO ? (0, hO.jsxs)("div", {
          className: "TopRightHelperBox",
          style: {
            ...KO
          },
          children: [(0, hO.jsx)("div", {
            className: "LeftSide",
            style: pO,
            children: (0, hO.jsx)(TO.d, {
              name: this.currMessage.icon,
              className: `fa-${this.currMessage.iconSizeMult||3}x HelperIcon`
            })
          }), (0, hO.jsx)("div", {
            className: "RightSide",
            style: XO,
            children: (0, hO.jsx)("div", {
              className: "HelperText",
              style: bK,
              children: this.currMessage.text
            })
          })]
        }) : null
      }
    }
    var yK = pO(35044),
      gK = pO(1232);
    const uO = (0, gK.j)((OO => OO.PadSneakChip));

    function EO(OO) {
      const [KO, pO, XO] = function(OO) {
        const KO = parseInt(OO.substring(1), 16),
          pO = (KO >> 16) / 255,
          XO = (KO >> 8 & 255) / 255,
          bK = (255 & KO) / 255,
          eO = Math.max(pO, XO, bK),
          lO = Math.min(pO, XO, bK),
          vK = (eO + lO) / 2,
          CO = eO - lO;
        if (0 === CO) return [0, 0, vK];
        const hO = CO / (1 - Math.abs(2 * vK - 1));
        let DO;
        DO = eO === pO ? (XO - bK) / CO % 6 : eO === XO ? (bK - pO) / CO + 2 : (pO - XO) / CO + 4;
        return [(60 * DO + 360) % 360, hO, vK]
      }(OO), bK = 0 === pO ? 0 : Math.min(.6, pO + .03), eO = XO > .5 ? -1 : 1, lO = jK(XO + .09 * eO);
      return {
        panel: OO,
        slot: YO(KO, bK, lO),
        slotSelected: YO(KO, bK, jK(lO + .2 * eO)),
        slotUnavailable: YO(KO, bK, jK(XO + -.1 * eO))
      }
    }

    function jK(OO) {
      return Math.min(1, Math.max(0, OO))
    }

    function YO(OO, KO, pO) {
      const XO = (1 - Math.abs(2 * pO - 1)) * KO,
        bK = XO * (1 - Math.abs(OO / 60 % 2 - 1)),
        eO = pO - XO / 2;
      let lO;
      return lO = OO < 60 ? [XO, bK, 0] : OO < 120 ? [bK, XO, 0] : OO < 180 ? [0, XO, bK] : OO < 240 ? [0, bK, XO] : OO < 300 ? [bK, 0, XO] : [XO, 0, bK], "#" + lO.map((OO => function(OO) {
        return Math.round(255 * OO).toString(16).padStart(2, "0")
      }(OO + eO))).join("")
    }
    var wO = pO(35083),
      iK = pO(22),
      rK = pO(1583),
      PO = pO(3546),
      mK = pO(1225),
      sO = pO(1964),
      HO = pO(1969),
      RO = pO(35075),
      SO = pO(3962),
      JO = pO(1289),
      cK = pO(1051),
      BO = pO(533);

    function ZO(OO, KO, pO, XO) {
      OO.style.display = "";
      const bK = OO.offsetWidth,
        eO = OO.offsetHeight,
        lO = Math.min(Math.max((KO.left + KO.right) / 2 - bK / 2, 8), window.innerWidth - 8 - bK);
      let vK = KO.top - pO - eO;
      const CO = [...XO].sort(((OO, KO) => KO.top - OO.top));
      for (const hO of CO) lO < hO.right && lO + bK > hO.left && vK < hO.bottom && vK + eO > hO.top && (vK = hO.top - 8 - eO);
      return vK < 8 ? (OO.style.display = "none", null) : (OO.style.transform = `translate(${lO-KO.left}px, ${vK-KO.top}px)`, {
        left: lO,
        top: vK,
        right: lO + bK,
        bottom: vK + eO
      })
    }

    function GO(OO) {
      const KO = [];
      for (const pO of document.querySelectorAll(OO)) {
        const OO = pO.getBoundingClientRect();
        OO.width > 0 && "visible" === getComputedStyle(pO).visibility && KO.push(OO)
      }
      return KO
    }

    function qK(OO, KO) {
      return OO.clientX >= KO.left - 8 && OO.clientX <= KO.right + 8 && OO.clientY >= KO.top - 8 && OO.clientY <= KO.bottom + 8
    }
    var xK = pO(7952);
    class nO {
      constructor(OO) {
        this.deps = OO, this.phase = "idle", this.armTimer = null, this.suspended = !1
      }
      get locked() {
        return "locked" === this.phase
      }
      get offered() {
        return "armed" === this.phase || "ready" === this.phase
      }
      target(OO) {
        OO && "armed" === this.phase ? this.setPhase("ready") : OO || "ready" !== this.phase || this.setPhase("armed")
      }
      lift() {
        return "ready" !== this.phase ? (this.cancel(), !1) : (this.setPhase("locked"), !0)
      }
      cancel() {
        "idle" !== this.phase && this.setPhase("idle")
      }
      suspend() {
        this.suspendArming(), this.cancel()
      }
      suspendArming() {
        this.suspended = !0, "locked" !== this.phase && this.cancel()
      }
      startTouch() {
        this.suspended = !1, this.cancel()
      }
      hold(OO, KO) {
        this.suspended || (this.offered ? KO || this.setPhase("idle") : OO && "idle" === this.phase ? (this.setPhase("charging"), this.armTimer = setTimeout((() => {
          this.armTimer = null, this.onArm(), this.setPhase("armed")
        }), 1e3)) : OO || "charging" !== this.phase || this.setPhase("idle"))
      }
      onArm() {}
      setPhase(OO) {
        null !== this.armTimer && (clearTimeout(this.armTimer), this.armTimer = null);
        const KO = this.phase;
        this.phase = OO, this.deps.onPhase(OO, KO)
      }
    }
    const WO = 25 * Math.PI / 180,
      tK = 45 * Math.PI / 180;
    class kK extends nO {
      constructor() {
        super(...arguments), this.speed = 0, this.armedSpeed = 0
      }
      get lockedSpeed() {
        return this.armedSpeed
      }
      move(OO, KO, pO) {
        this.speed = pO;
        const XO = Math.hypot(OO, KO),
          bK = XO > 0 ? Math.acos(Math.min(1, -KO / XO)) : Math.PI;
        this.hold(XO >= .8 && bK <= WO, XO >= .5 && bK <= tK)
      }
      onArm() {
        this.armedSpeed = this.speed
      }
    }
    var UO = pO(1136);

    function OK(OO, KO) {
      const pO = (0, XO.useRef)(null),
        bK = (0, XO.useRef)(KO);
      return bK.current = KO, (0, XO.useEffect)((() => {
        if (!OO) return;
        const {
          create: KO,
          elementRef: XO,
          ringRef: eO,
          classPrefix: lO,
          keptBehindMovementPanels: vK,
          resizeEnds: CO
        } = bK.current, hO = {
          charging: `${lO}Charging`,
          armed: `${lO}Armed`,
          ready: `${lO}Ready`,
          locked: `${lO}Locked`
        };
        let DO = null;
        const MO = KO({
          onPhase: (OO, KO) => {
            const pO = XO.current;
            if (null !== pO) {
              for (const [KO, XO] of Object.entries(hO)) pO.classList.toggle(XO, KO === OO);
              if ("charging" === OO) DO = eO.current.animate([{
                strokeDashoffset: 1
              }, {
                strokeDashoffset: 0
              }], {
                delay: 400,
                duration: 600,
                fill: "forwards"
              });
              else if ("idle" === OO) {
                var lO;
                null === (lO = DO) || void 0 === lO || lO.cancel(), DO = null
              }
              var vK, CO;
              if ("armed" === OO && "charging" === KO && bK.current.onArmed(), "ready" === OO && xK.f.play("lockReady"), "locked" === OO) xK.f.play("lockLocked"), null === (vK = (CO = bK.current).onLocked) || void 0 === vK || vK.call(CO);
              "locked" === KO && bK.current.onUnlocked()
            }
          }
        });
        pO.current = MO;
        const aK = () => {
            MO.suspend()
          },
          oO = () => {
            "hidden" === document.visibilityState && aK()
          },
          FO = () => {
            CO ? MO.suspend() : MO.suspendArming()
          },
          VO = (0, UO.e)((OO => {
            let {
              keepsMovement: KO
            } = OO;
            KO && vK ? MO.suspendArming() : aK()
          }));
        return document.addEventListener("visibilitychange", oO), window.addEventListener("blur", aK), window.addEventListener("resize", FO), () => {
          VO(), document.removeEventListener("visibilitychange", oO), window.removeEventListener("blur", aK), window.removeEventListener("resize", FO), MO.cancel(), pO.current = null
        }
      }), [OO]), (0, rK.b)("localPlayerAliveSet", (() => {
        var OO;
        null === (OO = pO.current) || void 0 === OO || OO.suspend()
      })), pO
    }
    const KK = 50;

    function pK(OO) {
      let {
        onMove: KO,
        mode: pO,
        speedCurve: bK,
        autorun: eO = !1
      } = OO;
      const lO = (0, XO.useRef)(null),
        vK = (0, XO.useRef)(null),
        CO = (0, XO.useRef)(null),
        DO = (0, XO.useRef)(null),
        MO = (0, XO.useRef)(null),
        oO = (0, XO.useRef)(null),
        FO = (0, XO.useRef)(null),
        VO = (0, XO.useRef)(null),
        LO = (0, XO.useRef)(!1),
        QO = (0, XO.useRef)({
          clientX: 0,
          clientY: 0
        }),
        {
          t: zK
        } = (0, cK.D)(),
        AO = "fixed_shown" === pO || "fixed_hidden" === pO,
        fO = (0, iK.l)(["notchSize"]).notchSize.left,
        dO = function(OO, KO, pO, bK, eO) {
          const lO = (0, XO.useRef)(null),
            vK = () => {
              clearInterval(lO.current), lO.current = null
            },
            CO = OK(OO, {
              create: OO => new kK(OO),
              elementRef: KO,
              ringRef: pO,
              classPrefix: "Autorun",
              keptBehindMovementPanels: !0,
              resizeEnds: !0,
              onArmed: eO,
              onLocked: () => {
                lO.current = setInterval((() => {
                  aK.gameBridge.lookup("dropAhead", null) && (xK.f.play("autorunLedgeStop"), CO.current.cancel())
                }), 100)
              },
              onUnlocked: () => {
                vK(), bK()
              }
            });
          return (0, XO.useEffect)((() => vK), []), CO
        }(eO, vK, oO, (() => {
          EO(), uO()
        }), (() => {
          NO(), null === VO.current && dO.current.suspend()
        }));

      function NO() {
        const OO = vK.current.getBoundingClientRect();
        VO.current = ZO(FO.current, OO, 80, GO(".TouchInventoryKey")), LO.current = null !== VO.current && qK(QO.current, VO.current)
      }

      function IO(OO) {
        vK.current.style.transform = `translate(${OO.x-KK}px, ${OO.y-KK}px)`
      }

      function yK(OO) {
        const KO = vK.current;
        KO.classList.add("Resting"), KO.classList.toggle("Returning", OO), KO.style.display = "fixed_hidden" === pO ? "none" : "block", IO(function() {
          const OO = fO * window.innerWidth / 100,
            KO = window.innerHeight > window.innerWidth ? 135 : 100;
          return {
            x: OO + 90,
            y: window.innerHeight - KO
          }
        }())
      }
      const gK = (0, XO.useRef)({
        restFixed: yK,
        release: jK
      });

      function uO() {
        AO ? yK("fixed_shown" === pO) : "floating" === pO && (vK.current.style.display = "none"), KO({
          x: 0,
          y: 0
        })
      }

      function EO() {
        MO.current = null, DO.current = null, CO.current.style.transform = "translate(-50%, -50%)"
      }

      function jK(OO) {
        EO();
        const pO = dO.current;
        OO && null !== pO && void 0 !== pO && pO.lift() ? KO({
          x: 0,
          y: -pO.lockedSpeed
        }) : (null === pO || void 0 === pO || pO.cancel(), uO())
      }

      function YO(OO) {
        const pO = Array.from(OO.touches).find((OO => OO.identifier === MO.current));
        if (null === DO.current || null === MO.current || (0, BO.I)(pO)) return;
        const XO = dO.current,
          eO = pO.clientX - DO.current.x,
          lO = pO.clientY - DO.current.y,
          vK = Math.hypot(eO, lO),
          hO = vK > 0 ? Math.min(1, KK / vK) : 0,
          aK = eO * hO,
          oO = lO * hO,
          FO = Math.hypot(aK, oO) / KK,
          zK = bK && FO > 0 ? bK(FO) / FO : 1;
        CO.current.style.transform = `translate(calc(-50% + ${aK}px), calc(-50% + ${oO}px))`;
        const AO = aK / KK,
          fO = oO / KK;
        if (KO({
            x: AO * zK,
            y: fO * zK
          }), null !== XO && null !== VO.current) {
          XO.move(AO, fO, FO * zK), QO.current = {
            clientX: pO.clientX,
            clientY: pO.clientY
          };
          const OO = LO.current;
          LO.current = qK(pO, VO.current), LO.current !== OO && XO.target(LO.current)
        }
      }
      return gK.current = {
        restFixed: yK,
        release: jK
      }, (0, XO.useLayoutEffect)((() => {
        if (!AO) return;
        null === MO.current && gK.current.restFixed(!1);
        const OO = () => {
          null === MO.current && gK.current.restFixed(!1)
        };
        window.addEventListener("resize", OO);
        const KO = vK.current;
        return () => {
          window.removeEventListener("resize", OO), KO.classList.remove("Resting", "Returning"), null === MO.current && (KO.style.display = "", KO.style.transform = "")
        }
      }), [AO, pO, fO]), (0, XO.useEffect)((() => {
        const OO = OO => {
            const KO = MO.current;
            null === KO || Array.from(OO.touches).some((OO => OO.identifier === KO)) || gK.current.release("touchend" === OO.type && Array.from(OO.changedTouches).some((OO => OO.identifier === KO)))
          },
          KO = () => {
            null !== MO.current && gK.current.release(!1)
          },
          pO = () => {
            "hidden" === document.visibilityState && KO()
          };
        document.addEventListener("touchstart", OO, {
          capture: !0,
          passive: !0
        }), document.addEventListener("touchmove", OO, {
          capture: !0,
          passive: !0
        }), document.addEventListener("touchend", OO, {
          capture: !0,
          passive: !0
        }), document.addEventListener("touchcancel", OO, {
          capture: !0,
          passive: !0
        }), window.addEventListener("blur", KO), document.addEventListener("visibilitychange", pO);
        const XO = (0, UO.e)((OO => {
          let {
            keepsMovement: pO
          } = OO;
          pO || KO()
        }));
        return () => {
          XO(), document.removeEventListener("touchstart", OO, {
            capture: !0
          }), document.removeEventListener("touchmove", OO, {
            capture: !0
          }), document.removeEventListener("touchend", OO, {
            capture: !0
          }), document.removeEventListener("touchcancel", OO, {
            capture: !0
          }), window.removeEventListener("blur", KO), document.removeEventListener("visibilitychange", pO)
        }
      }), []), (0, XO.useEffect)((() => {
        const OO = lO.current,
          KO = OO => {
            OO.preventDefault()
          };
        return OO.addEventListener("touchstart", KO, {
          passive: !1
        }), () => {
          OO.removeEventListener("touchstart", KO)
        }
      }), []), (0, hO.jsx)("div", {
        ref: lO,
        className: "JoystickZone",
        onTouchStart: function(OO) {
          var KO;
          if (null !== MO.current) return;
          const XO = Array.from(OO.changedTouches).find((OO => {
            var KO;
            return null === (KO = lO.current) || void 0 === KO ? void 0 : KO.contains(OO.target)
          }));
          if (XO) {
            if (null === (KO = dO.current) || void 0 === KO || KO.startTouch(), MO.current = XO.identifier, "pinned" === pO) {
              const OO = vK.current.getBoundingClientRect();
              DO.current = {
                x: OO.left + OO.width / 2,
                y: OO.top + OO.height / 2
              }
            } else DO.current = {
              x: XO.clientX,
              y: XO.clientY
            }, vK.current.classList.remove("Resting", "Returning"), vK.current.style.display = "block", IO(DO.current), eO && (QO.current = {
              clientX: XO.clientX,
              clientY: XO.clientY
            }, NO());
            YO(OO)
          }
        },
        onTouchMove: YO,
        children: (0, hO.jsxs)("div", {
          ref: vK,
          className: "Joystick",
          style: {
            width: "100px",
            height: "100px",
            transform: "pinned" === pO ? "translate(4vw, calc(50vh - 50%))" : void 0
          },
          children: [(0, hO.jsx)("div", {
            className: "JoystickBase",
            style: {
              width: "100px",
              height: "100px"
            }
          }), eO && (0, hO.jsxs)(hO.Fragment, {
            children: [(0, hO.jsx)("svg", {
              className: "AutorunRing",
              viewBox: "0 0 100 100",
              children: (0, hO.jsx)("circle", {
                ref: oO,
                cx: "50",
                cy: "50",
                r: "48",
                pathLength: 1
              })
            }), (0, hO.jsxs)("div", {
              ref: FO,
              className: "AutorunTarget",
              children: [(0, hO.jsx)(TO.d, {
                name: "lock"
              }), zK("settingsMenu:autoRun")]
            })]
          }), (0, hO.jsx)("div", {
            ref: CO,
            className: "JoystickKnob",
            style: {
              width: "50px",
              height: "50px"
            }
          })]
        })
      })
    }
    var XK = pO(35122),
      bp = pO(35072),
      eK = pO(35111),
      lK = pO(1473);
    class vp extends nO {
      constructor() {
        super(...arguments), this.start = {
          x: 0,
          y: 0
        }, this.moved = !1
      }
      press(OO, KO) {
        this.start = {
          x: OO,
          y: KO
        }, this.moved = !1, this.startTouch(), this.hold(!0, !1)
      }
      move(OO, KO, pO) {
        const XO = Math.hypot(OO - this.start.x, KO - this.start.y) <= 12;
        this.moved ||= !XO;
        const bK = null !== pO && KO < this.start.y - 12 && qK({
          clientX: OO,
          clientY: KO
        }, pO);
        this.hold(!this.moved, XO || bK)
      }
    }
    const CK = new Set;

    function hK(OO) {
      const KO = new Set(Array.from(OO.touches, (OO => OO.identifier)));
      for (const pO of CK) {
        for (const OO of pO.ids) KO.has(OO) || pO.ids.delete(OO);
        if (0 === pO.ids.size) {
          CK.delete(pO);
          pO.pressesOnPointerDown && "touchstart" === OO.type && Array.from(OO.changedTouches).some((OO => OO.target instanceof Node && pO.element.contains(OO.target))) || pO.release()
        }
      }
    }
    if ("undefined" !== typeof window)
      for (const Pe of ["touchstart", "touchmove"]) window.addEventListener(Pe, hK, {
        capture: !0,
        passive: !0
      });

    function DK(OO) {
      let {
        pressesOnPointerDown: KO = !1
      } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      const pO = (0, XO.useRef)(OO);
      pO.current = OO;
      const bK = (0, XO.useRef)({
        ids: new Set,
        element: null,
        pressesOnPointerDown: KO,
        release: () => {
          pO.current()
        }
      });
      (0, XO.useEffect)((() => {
        const OO = bK.current;
        return () => {
          CK.delete(OO), OO.ids.clear()
        }
      }), []);
      const eO = OO => {
        const KO = bK.current;
        for (const pO of Array.from(OO.changedTouches)) KO.ids.delete(pO.identifier);
        0 === KO.ids.size && CK.delete(KO)
      };
      return {
        onTouchStart: OO => {
          const KO = bK.current;
          KO.element = OO.currentTarget;
          for (const pO of Array.from(OO.changedTouches)) pO.target instanceof Node && OO.currentTarget.contains(pO.target) && KO.ids.add(pO.identifier);
          KO.ids.size > 0 && CK.add(KO)
        },
        onTouchEnd: eO,
        onTouchCancel: eO
      }
    }

    function MK(OO, KO) {
      return null === KO ? null : (0, eK.b)(OO.nativeEvent.changedTouches, KO.id)
    }

    function ap(OO) {
      let {
        lockable: KO
      } = OO;
      const {
        t: pO
      } = (0, cK.D)(), bK = (0, XO.useRef)(!1);
      (0, bp.m)(sO.t.Jump, bK);
      const eO = (0, XO.useRef)(null),
        lO = (0, XO.useRef)(null),
        vK = (0, XO.useRef)(null),
        CO = (0, XO.useRef)(null),
        DO = (0, XO.useRef)(null),
        MO = (0, XO.useRef)(null),
        aK = (0, XO.useRef)(!1),
        oO = (OO, KO) => {
          bK.current = OO, (0, HO.u)(sO.t.Jump, OO, KO)
        },
        FO = function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            isTrusted: !0,
            timeStamp: performance.now()
          };
          bK.current && (eO.current && (0, JO.c)(eO.current, !1), oO(!1, OO))
        },
        VO = OK(KO, {
          create: OO => new vp(OO),
          elementRef: eO,
          ringRef: lO,
          classPrefix: "JumpLock",
          keptBehindMovementPanels: !1,
          resizeEnds: !1,
          onArmed: () => {
            const OO = eO.current.getBoundingClientRect(),
              KO = vK.current.parentElement,
              pO = KO.getBoundingClientRect(),
              XO = {
                left: pO.left + KO.clientLeft,
                top: pO.top + KO.clientTop,
                right: pO.right - KO.clientLeft,
                bottom: pO.bottom - KO.clientTop
              };
            if (DO.current = ZO(vK.current, XO, 16, GO(".TouchKeyHit:not(.JumpKey) > .TouchKey, .TouchInventoryKey")), null === DO.current) return void VO.current.suspend();
            const bK = DO.current;
            MO.current = {
              left: Math.min(OO.left, bK.left),
              top: bK.top,
              right: Math.max(OO.right, bK.right),
              bottom: OO.bottom
            }, aK.current = null !== CO.current && qK({
              clientX: CO.current.x,
              clientY: CO.current.y
            }, bK)
          },
          onUnlocked: () => {
            null === CO.current && FO()
          }
        }),
        LO = OO => {
          var KO;
          CO.current = null, null === (KO = VO.current) || void 0 === KO || KO.cancel(), FO(OO)
        },
        QO = DK((() => {
          LO()
        })),
        zK = OO => {
          const KO = CO.current;
          var pO;
          return null === KO ? null !== (pO = VO.current) && void 0 !== pO && pO.locked ? null : "lifted" : MK(OO, KO) ? "lifted" : (0, eK.f)(OO.nativeEvent.touches, KO.id) ? null : "dropped"
        };
      return (0, hO.jsxs)(bp.i, {
        ref: eO,
        slot: bp.k.Jump,
        className: "JumpKey",
        onTouchStart: OO => {
          QO.onTouchStart(OO), (0, JO.c)(OO.currentTarget, !0), null === CO.current || (0, eK.f)(OO.nativeEvent.touches, CO.current.id) || LO();
          const KO = OO.changedTouches[0];
          var pO;
          null === CO.current && KO && (CO.current = {
            id: KO.identifier,
            x: KO.clientX,
            y: KO.clientY
          }, null === (pO = VO.current) || void 0 === pO || pO.press(KO.clientX, KO.clientY));
          bK.current || oO(!0, OO.nativeEvent)
        },
        onTouchMove: OO => {
          const KO = CO.current,
            pO = MK(OO, KO);
          if (!pO) return;
          const XO = VO.current,
            bK = (0, UO.l)() && !(null !== XO && void 0 !== XO && XO.offered) && !Array.from(OO.nativeEvent.touches).some((OO => OO.target instanceof Element && (0, lK.o)(OO.target)));
          if (null === XO || void 0 === XO || XO.move(pO.clientX, pO.clientY, MO.current), null !== XO && void 0 !== XO && XO.offered) {
            const OO = qK(pO, DO.current);
            OO !== aK.current && (aK.current = OO, XO.target(OO))
          } else bK && (0, RO.h)(pO.clientX - KO.x, pO.clientY - KO.y);
          KO.x = pO.clientX, KO.y = pO.clientY
        },
        onTouchEnd: OO => {
          var KO;
          QO.onTouchEnd(OO);
          const pO = zK(OO);
          null !== pO && ("dropped" !== pO ? (CO.current = null, null !== (KO = VO.current) && void 0 !== KO && KO.lift() ? (0, JO.c)(OO.currentTarget, !1) : FO(OO.nativeEvent)) : LO(OO.nativeEvent))
        },
        onTouchCancel: OO => {
          QO.onTouchCancel(OO), null !== zK(OO) && LO(OO.nativeEvent)
        },
        children: [(0, hO.jsx)(TO.d, {
          name: "arrow-up-from-line"
        }), KO && (0, hO.jsxs)(hO.Fragment, {
          children: [(0, hO.jsx)("span", {
            className: "JumpLockBadge",
            children: (0, hO.jsx)(TO.d, {
              name: "lock"
            })
          }), (0, hO.jsx)("svg", {
            className: "JumpLockRing",
            viewBox: "0 0 100 100",
            preserveAspectRatio: "none",
            children: (0, hO.jsx)("rect", {
              ref: lO,
              x: "2",
              y: "2",
              width: "96",
              height: "96",
              rx: "10",
              pathLength: 1
            })
          }), (0, hO.jsxs)("div", {
            ref: vK,
            className: "JumpLockTarget",
            children: [(0, hO.jsx)(TO.d, {
              name: "lock"
            }), pO("settingsMenu:jumpLock")]
          })]
        })]
      })
    }
    const oK = new WeakMap;
    class FK {
      constructor(OO) {
        this.zones = OO, this.followed = new Map, this.onStart = OO => {
          if (this.releaseMissing(OO.touches), OO.target instanceof HTMLCanvasElement)
            for (let pO = 0; pO < OO.changedTouches.length; pO++) {
              var KO;
              const {
                identifier: XO,
                clientX: bK,
                clientY: eO
              } = OO.changedTouches[pO];
              this.release(XO);
              const lO = this.zones.hitZone(bK, eO);
              if (!lO) continue;
              const {
                key: vK
              } = lO;
              null === (KO = oK.get(vK)) || void 0 === KO || KO.cancel();
              const CO = {
                hit: lO.element,
                key: vK,
                x: lO.x,
                y: lO.y,
                reach: .6 * lO.radius
              };
              this.followed.set(XO, CO), (0, JO.c)(lO.element, !0), VK(CO, bK, eO)
            }
        }, this.onMove = OO => {
          this.releaseMissing(OO.touches);
          for (let KO = 0; KO < OO.changedTouches.length; KO++) {
            const {
              identifier: pO,
              clientX: XO,
              clientY: bK
            } = OO.changedTouches[KO], eO = this.followed.get(pO);
            eO && VK(eO, XO, bK)
          }
        }, this.onEnd = OO => {
          for (let KO = 0; KO < OO.changedTouches.length; KO++) this.release(OO.changedTouches[KO].identifier)
        }, this.onVisibilityChange = () => {
          document.hidden && this.releaseAll()
        }
      }
      start() {
        const OO = {
          passive: !0
        };
        return document.addEventListener("touchstart", this.onStart, OO), document.addEventListener("touchmove", this.onMove, OO), document.addEventListener("touchend", this.onEnd, OO), document.addEventListener("touchcancel", this.onEnd, OO), document.addEventListener("visibilitychange", this.onVisibilityChange), () => {
          document.removeEventListener("touchstart", this.onStart), document.removeEventListener("touchmove", this.onMove), document.removeEventListener("touchend", this.onEnd), document.removeEventListener("touchcancel", this.onEnd), document.removeEventListener("visibilitychange", this.onVisibilityChange), this.releaseAll()
        }
      }
      releaseMissing(OO) {
        for (const KO of [...this.followed.keys()])(0, eK.f)(OO, KO) || this.release(KO)
      }
      releaseAll() {
        for (const OO of [...this.followed.keys()]) this.release(OO)
      }
      release(OO) {
        const KO = this.followed.get(OO);
        if (!KO) return;
        this.followed.delete(OO);
        for (const bK of this.followed.values())
          if (bK.key === KO.key) return;
        (0, JO.c)(KO.hit, !1);
        const {
          key: pO
        } = KO, XO = pO.style.translate;
        pO.style.translate = "", XO && oK.set(pO, pO.animate({
          translate: [XO, "0 0"]
        }, {
          duration: 150,
          easing: "ease-out"
        }))
      }
    }

    function VK(OO, KO, pO) {
      let {
        key: XO,
        x: bK,
        y: eO,
        reach: lO
      } = OO;
      const vK = KO - bK,
        CO = pO - eO,
        hO = Math.min(1, lO / (Math.hypot(vK, CO) || 1));
      XO.style.translate = `${vK*hO}px ${CO*hO}px`
    }
    const LK = () => {
      const OO = (0, PO.l)(),
        KO = (0, mK.p)();
      return OO || KO
    };

    function QK(OO) {
      (0, RO.e)(OO.x, OO.y)
    }
    const zp = (0, XO.memo)((function() {
        const OO = LK(),
          {
            joystickMode: KO,
            touchSpeedCurve: pO,
            autorun: bK
          } = (0, iK.l)(["clientEscMenuOptions"]).clientEscMenuOptions;
        return (0, XO.useEffect)((() => ((0, SO.j)(sO.u.TouchControls, sO.u.TouchControls), () => {
          (0, SO.j)(sO.u.TouchControls, 0), (0, RO.e)(0, 0)
        })), []), (0, hO.jsx)("div", {
          className: eO()("TouchMovementWrapper", {
            Hidden: OO
          }),
          "data-camera-keeper": "",
          children: (0, hO.jsx)(pK, {
            onMove: QK,
            mode: KO,
            speedCurve: pO ? XK.b : void 0,
            autorun: bK
          })
        })
      })),
      AK = (0, XO.memo)((function() {
        const OO = LK(),
          {
            clientEscMenuOptions: KO
          } = (0, iK.l)(["clientEscMenuOptions"]),
          pO = KO.touchActionButtons;
        return (0, XO.useEffect)((() => new FK(RO.d).start()), []), (0, XO.useEffect)((() => {
          dO.i.pl(bp.e)
        }), [OO]), (0, hO.jsxs)("div", {
          className: eO()("TouchComponentsButtons", {
            Hidden: OO
          }),
          "data-camera-keeper": "",
          children: [(0, hO.jsx)(ap, {
            lockable: KO.jumpLock && !OO
          }), (0, hO.jsx)(wK, {
            hidden: OO,
            actionButtons: pO
          }), (0, hO.jsx)(dK, {})]
        })
      }));

    function fK(OO) {
      const KO = KO => pO => {
        (0, JO.c)(pO.currentTarget, KO), OO(KO, pO.nativeEvent)
      };
      return {
        onPointerDown: KO(!0),
        onPointerUp: KO(!1),
        onPointerCancel: KO(!1)
      }
    }

    function dK() {
      const OO = (0, zK.i)("canCrouch"),
        KO = (0, rK.i)("crouching"),
        pO = (0, XO.useRef)(!1);
      (0, bp.m)(sO.t.Crouch, pO);
      const bK = (OO, KO) => {
          pO.current = OO, (0, HO.u)(sO.t.Crouch, OO, KO)
        },
        eO = (0, XO.useRef)(null),
        lO = () => {
          pO.current && (eO.current && (0, JO.c)(eO.current, !1), bK(!1, {
            isTrusted: !0,
            timeStamp: performance.now()
          }))
        },
        vK = DK(lO);
      return (0, XO.useEffect)((() => {
        !1 === OO && lO()
      }), [OO]), !1 === OO ? null : (0, hO.jsx)(bp.i, {
        ref: eO,
        slot: bp.k.Crouch,
        className: "CrouchKey",
        lit: KO,
        ...vK,
        ...fK(bK),
        children: (0, hO.jsx)(TO.d, {
          name: "arrow-down-to-line"
        })
      })
    }
    const TK = [{
        icon: "arrows-rotate"
      }],
      NK = [{
        icon: "Arrow"
      }],
      IK = [{
        icon: "crosshairs"
      }],
      yp = [{
        icon: "swords"
      }],
      gp = [{
        icon: "hand-back-point-up"
      }],
      uK = [{
        icon: "Firecracker"
      }];

    function EK(OO, KO, pO, XO) {
      return {
        id: JSON.stringify(KO),
        render: bK => (0, hO.jsx)(ip, {
          code: OO,
          slot: bK,
          icon: KO,
          label: XO,
          hidden: pO
        })
      }
    }

    function jp(OO, KO) {
      return {
        id: "fly",
        render: pO => (0, hO.jsx)(YK, {
          slot: pO,
          flying: OO,
          label: KO
        })
      }
    }

    function YK(OO) {
      let {
        slot: KO,
        flying: pO,
        label: XO
      } = OO;
      return (0, hO.jsx)(bp.i, {
        slot: KO,
        className: "FlyKey",
        lit: pO,
        label: XO,
        ...fK(((OO, KO) => {
          (0, HO.u)(sO.t.Fly, OO, KO)
        })),
        children: (0, hO.jsx)(TO.d, {
          name: "feather-pointed"
        })
      })
    }

    function wK(OO) {
      var KO, pO;
      let {
        hidden: XO,
        actionButtons: bK
      } = OO;
      const {
        t: eO
      } = (0, cK.D)(), {
        gun: lO,
        aimable: vK,
        chargeName: CO
      } = (0, rK.i)("heldItemAim"), DO = (0, rK.i)("gliderBoostFuel"), {
        canFly: MO,
        flying: aK
      } = (0, rK.i)("flight"), oO = (0, zK.i)("touchscreenActionButton"), FO = lO ? TK : oO, VO = vK ? {
        icon: NK,
        label: eO("touchKeys:aim")
      } : null, LO = null !== CO ? {
        icon: [{
          icon: CO
        }]
      } : null, QO = null !== VO && void 0 !== VO ? VO : LO, AO = null !== (KO = null === (pO = lO ? VO : null !== LO && void 0 !== LO ? LO : VO) || void 0 === pO ? void 0 : pO.icon) && void 0 !== KO ? KO : gp, fO = [!bK && QO ? EK(RO.b.Action2, QO.icon, XO, QO.label) : null, lO ? EK(RO.b.Action3, IK, XO, eO("touchKeys:scope")) : null, MO ? jp(aK, eO("touchKeys:fly")) : null];
      return (0, hO.jsxs)(hO.Fragment, {
        children: [FO && (0, hO.jsx)(ip, {
          code: RO.b.Action1,
          slot: bp.k.Game,
          icon: FO,
          label: lO ? eO("touchKeys:reload") : void 0,
          hidden: XO
        }, JSON.stringify(FO)), bK && (0, hO.jsxs)(hO.Fragment, {
          children: [(0, hO.jsx)(ip, {
            code: RO.b.Attack,
            slot: bp.k.Attack,
            icon: yp,
            name: eO("touchKeys:attack"),
            hidden: XO
          }), (0, hO.jsx)(ip, {
            code: RO.b.Use,
            slot: bp.k.Use,
            icon: AO,
            name: eO("touchKeys:use"),
            hidden: XO
          })]
        }), (0, bp.l)(fO, bK), DO > 0 && (0, hO.jsx)(ip, {
          code: RO.b.Boost,
          slot: bp.k.Context,
          icon: uK,
          label: eO("touchKeys:boost", {
            fuel: DO > 99 ? "99+" : DO
          }),
          hidden: XO
        })]
      })
    }

    function ip(OO) {
      let {
        code: KO,
        slot: pO,
        icon: XO,
        label: bK,
        name: eO,
        hidden: lO
      } = OO;
      const vK = (0, bp.p)(KO, lO);
      return (0, hO.jsx)(bp.i, {
        ref: vK,
        slot: pO,
        className: "TouchActionKey",
        canvasZone: !0,
        label: bK,
        role: void 0 !== eO ? "img" : void 0,
        "aria-label": eO,
        children: (0, hO.jsx)(CO.d, {
          text: XO
        })
      })
    }
    var rp = pO(3533),
      PK = pO(2332),
      mp = pO(570);
    const sK = (0, XO.memo)((function() {
      (0, fO.c)();
      const OO = (0, XO.useRef)([]),
        KO = (0, PK.b)(),
        pO = (0, XO.useRef)(0),
        bK = (0, XO.useRef)(0),
        eO = (0, XO.useRef)([]),
        lO = (0, XO.useRef)(null);

      function DO(pO, XO, bK, eO) {
        const lO = (0, mp.c)(),
          vK = setTimeout((() => {
            OO.current = OO.current.filter((OO => OO.id !== lO)), KO()
          }), eO);
        aK.gameBridge.send("recordFlyingMiddleText", {
          content: pO,
          ROO: XO,
          angle: bK,
          SOO: eO
        }), OO.current.push({
          id: lO,
          content: pO,
          ROO: XO,
          SOO: eO,
          removeTimeout: vK,
          angle: bK
        }), KO()
      }
      return (0, rK.b)("shotDamageToShow", (OO => {
        let {
          damage: KO,
          wasCrit: pO,
          distance: XO
        } = OO;
        const bK = -Math.PI / 4 + Math.random() * Math.PI / 2;
        DO(pO ? [{
          str: KO.toString(),
          style: {
            color: "#ff8a80",
            fontSize: "1.6em"
          }
        }] : [KO.toString()], XO, bK, 1e3)
      })), (0, vK.f)("flyingMiddleMessage", (OO => {
        let {
          content: KO,
          ROO: XO,
          SOO: vK
        } = OO;
        eO.current.push({
          content: KO,
          ROO: XO,
          SOO: vK
        });
        const CO = () => {
          const {
            content: OO,
            ROO: KO,
            SOO: XO
          } = eO.current.shift(), lO = function(OO) {
            const KO = -Math.PI / 4,
              pO = Math.PI / 4,
              XO = pO - KO,
              bK = (1 + Math.sqrt(5)) / 2,
              eO = 2 * Math.PI / (bK * bK);
            let lO = OO + eO;
            for (; lO > pO;) lO -= XO;
            for (; lO < KO;) lO += XO;
            const vK = Math.PI / 6;
            if (Math.abs(lO - OO) < vK) {
              lO = OO + (Math.sign(lO - OO) || 1) * vK, lO > pO && (lO = OO - vK), lO < KO && (lO = OO + vK)
            }
            return lO
          }(bK.current);
          bK.current = lO, pO.current = Date.now(), DO(OO, KO, lO, XO)
        };
        if (!lO.current) {
          const OO = () => {
            eO.current.length > 0 && CO(), 0 === eO.current.length && (clearInterval(lO.current), lO.current = null)
          };
          lO.current = setInterval(OO, 200), pO.current + 200 < Date.now() && OO()
        }
        for (; eO.current.length > 4;) CO()
      })), (0, vK.f)("forceFlyingMiddleMessage", (OO => {
        let {
          content: KO,
          ROO: pO,
          angle: XO,
          SOO: bK
        } = OO;
        DO(KO, pO, XO, bK)
      })), (0, XO.useEffect)((() => () => {
        clearInterval(lO.current), lO.current = null;
        for (const KO of OO.current) clearTimeout(KO.removeTimeout)
      }), []), (0, hO.jsx)("div", {
        className: "FlyingMiddleTextWrapper",
        children: OO.current.map((OO => {
          const {
            id: KO,
            content: pO,
            ROO: XO,
            SOO: bK,
            angle: eO
          } = OO;
          return OO.pos || (OO.pos = function(OO, KO) {
            const pO = 50 / (OO ** .7 * .35);
            return {
              x: pO * Math.sin(KO),
              y: -pO * Math.cos(KO)
            }
          }(XO, eO)), (0, hO.jsx)(HK, {
            className: "FlyingMiddleText",
            classNames: "FlyingMiddleText",
            timeout: bK,
            enterActiveStyle: {
              transform: `translate(${OO.pos.x}vw, ${OO.pos.y}vh)`,
              transition: `transform ${bK}ms ease-out`
            },
            children: (0, hO.jsx)("div", {
              children: (0, hO.jsx)(CO.d, {
                text: pO
              })
            })
          }, KO)
        }))
      })
    }));

    function HK(OO) {
      let {
        children: KO,
        className: pO,
        classNames: bK,
        timeout: eO,
        enterActiveStyle: lO
      } = OO;
      const [vK, CO] = (0, XO.useState)(!1), [DO, MO] = (0, XO.useState)(!1), aK = (0, XO.useRef)(null);
      return (0, XO.useEffect)((() => {
        CO(!0)
      }), []), (0, hO.jsx)(rp.d, {
        className: pO,
        classNames: bK || pO,
        in: vK,
        timeout: eO,
        nodeRef: aK,
        onEntering: () => {
          MO(!0)
        },
        children: (0, XO.cloneElement)(KO, {
          ref: aK,
          style: DO && lO || void 0
        })
      })
    }
    var RK = pO(35130);

    function SK() {
      const OO = (0, rK.i)("health");
      return (0, hO.jsxs)("div", {
        className: "BottomScreenStatBarList",
        children: [(0, hO.jsx)(RK.e, {
          placement: "statBars"
        }), (0, hO.jsx)(JK, {
          actualValue: OO.shield,
          maxValue: OO.maxShield,
          hideAtValue: 0,
          icon: "shield",
          className: "ShieldBar"
        }), (0, hO.jsx)(JK, {
          actualValue: OO.health,
          maxValue: OO.maxHealth,
          icon: "heart",
          className: "HealthBar"
        })]
      })
    }

    function JK(OO) {
      let {
        actualValue: KO,
        maxValue: pO,
        hideAtValue: XO,
        icon: bK,
        className: eO
      } = OO;
      return (0, fO.d)(), null === KO || null === pO || KO === XO || pO === XO ? null : (0, hO.jsx)("div", {
        className: "BottomScreenStatBarWrapper",
        children: (0, hO.jsxs)("div", {
          className: "BottomScreenStatBarBackground",
          children: [(0, hO.jsx)("div", {
            className: `BottomScreenStatBar ${eO}`,
            style: {
              transform: `scaleX(${Math.max(KO/pO,0)})`,
              transformOrigin: "left center"
            }
          }), (0, hO.jsxs)("div", {
            className: "BottomScreenStatBarText SmallTextBold",
            children: [(0, hO.jsx)(TO.d, {
              name: bK
            }), ` ${Math.ceil(KO)}/${pO}`]
          })]
        })
      })
    }
    var cp = pO(8311),
      BK = pO(3719),
      ZK = pO(1165),
      GK = pO(2204),
      qp = pO(1271),
      xp = pO(1152),
      nK = pO(2686),
      WK = pO(2716),
      tp = pO(1569),
      kp = pO(2704),
      UK = pO(638),
      Op = pO(2730),
      Kp = pO(142),
      pp = pO(8273),
      Xp = pO(256);

    function bX(OO, KO) {
      let {
        shownName: pO,
        lifeformType: XO
      } = OO;
      return null !== pO ? pO : null !== XO ? KO(`lifeform:${(0,Xp.ke)(XO)}`) : null
    }
    var ep = pO(2696),
      lp = pO(2702);
    const vX = {
        FallDamage: "respawnPage:diedFallDamage",
        VoidJump: "respawnPage:diedVoid",
        Lava: "respawnPage:diedLava",
        "Toxic Waste": "respawnPage:diedToxicWaste",
        "Poison Potion": "respawnPage:diedPoisoned",
        "Rotten Brain": "respawnPage:diedPoisoned"
      },
      Cp = (0, XO.memo)((function() {
        var OO, KO;
        const pO = (0, fO.c)(),
          bK = (0, oO.useNavigatePreserveSearch)(),
          {
            t: lO
          } = (0, cK.D)(),
          {
            loadingOverlayVisible: CO
          } = (0, iK.l)(["loadingOverlayVisible"]),
          DO = (0, mK.p)(),
          [MO, FO] = (0, XO.useState)(!1),
          [VO, LO] = (0, XO.useState)(!0),
          [QO, AO] = (0, XO.useState)(null),
          dO = (0, PK.b)(),
          NO = (0, zK.i)("respawnButtonText"),
          IO = (0, zK.i)("usePlayAgainButton"),
          yK = (0, zK.i)("useRespawnButton"),
          {
            gameNameWithVariation: uO
          } = (0, rK.i)("connectedGame"),
          EO = (0, XO.useRef)(tp.c.get("secsToRespawn")),
          jK = (0, XO.useRef)(aK.gameBridge.latest("localPlayerAlive")),
          YO = (0, XO.useRef)(tp.c.get("secsToRespawn")),
          wO = (0, XO.useRef)(tp.c.get("autoRespawn")),
          PO = (0, XO.useRef)(null),
          sO = (0, XO.useRef)(0),
          HO = (0, XO.useRef)(0),
          [RO, SO] = (0, XO.useState)(!1),
          JO = (0, XO.useRef)(null),
          BO = (0, XO.useRef)(null),
          ZO = (0, XO.useRef)(null);
        (0, zK.f)("secsToRespawn", (OO => {
          console.log("Received new secsToRespawn with", OO, "and current canRespawn value of ", wO.current), YO.current = OO, nO()
        })), (0, zK.f)("autoRespawn", (OO => {
          console.log("Received autorespawn", OO, "current canRespawn value of ", EO.current), wO.current = OO, nO()
        }));
        const GO = OO => {
          console.log("Updating respawn component from localPlayerAliveSet. isAlive:", OO), OO || sO.current++, jK.current = OO, nO()
        };
        (0, rK.b)("localPlayerAliveSet", GO), (0, vK.f)(WK.n, (OO => {
          "connected" === OO && !jK.current && wO.current && EO.current <= 0 && (HO.current = 0, WO())
        })), (0, XO.useEffect)((() => {
          const OO = aK.gameBridge.latest("localPlayerAlive");
          OO === jK.current ? (console.log("Updating respawn component from initial mount"), nO()) : GO(OO)
        }), []), (0, XO.useEffect)((() => {
          if (MO) {
            SO(!1);
            const OO = setTimeout((() => {
              SO(!0)
            }), 600);
            return (0, pp.f)(), () => {
              clearTimeout(OO)
            }
          }
          return () => {}
        }), [MO]);
        (0, rK.b)("kill", (OO => {
          let {
            killer: KO,
            victim: pO,
            withItem: XO
          } = OO;
          if (!pO.local) return;
          const bK = ((OO, KO) => {
            if (OO.local) {
              const OO = vX[KO];
              return OO ? lO(OO) : null
            }
            const pO = bX(OO, lO);
            return pO ? lO("respawnPage:killedBy", {
              name: pO
            }) : null
          })(KO, XO);
          bK && AO({
            text: bK,
            deathCount: jK.current ? sO.current + 1 : sO.current
          })
        }));
        const qK = () => {
            MO && wO.current && jK.current && RO && FO(!1)
          },
          xK = MO && wO.current && jK.current && RO && !CO;
        (0, vK.f)("usedKeyboard", (() => {
          qK()
        })), (0, lp.c)("respawn", xK, qK);
        const nO = () => {
            LO(YO.current >= 3 || !wO.current), jK.current ? (clearInterval(PO.current), PO.current = null, wO.current ? dO() : FO(!1)) : (FO(!0), EO.current = YO.current, dO(), console.log("Running respawn stats updated", wO.current, EO.current), wO.current && EO.current <= 0 && WO(), clearInterval(PO.current), EO.current > 0 && (PO.current = setInterval((() => {
              EO.current = Math.max(EO.current - 1, 0), dO(), EO.current <= 0 && (clearInterval(PO.current), PO.current = null, tp.c.get("autoRespawn") && WO())
            }), 1e3)))
          },
          WO = () => {
            if (Date.now() - HO.current > 1e3) {
              const OO = () => {
                aK.gameBridge.send("respawn", null), HO.current = Date.now()
              };
              tp.c.get("autoRespawn") ? OO() : (0, xp.qb)((() => {
                OO()
              }), "video_respawn")
            }
          },
          tK = (0, XO.useMemo)((() => {
            var OO;
            return null === (OO = (0, UK.p)(uO)) || void 0 === OO ? void 0 : OO.otherGameLinksOnRespawnPage
          }), [uO]),
          kK = 0 === EO.current,
          UO = (null === QO || void 0 === QO ? void 0 : QO.deathCount) === sO.current ? QO.text : null,
          OK = MO && VO && !CO,
          KK = DO && xK && null !== (OO = null === (KO = (0, gK.g)()) || void 0 === KO ? void 0 : KO.getBoundButton("menuConfirm")) && void 0 !== OO ? OO : null,
          pK = OO => kK ? OO : lO("respawnPage:actionInSeconds", {
            action: OO,
            seconds: EO.current
          });
        return (0, hO.jsx)(cp.e, {
          showing: MO,
          globallyUniqueKey: "RespawnComponent",
          alwaysMountChildren: !0,
          children: (0, hO.jsx)(nK.b, {
            show: MO,
            children: (0, hO.jsxs)(BK.d, {
              close: () => {
                FO(!1)
              },
              togglePointerLock: !1,
              closeOnPressBackground: !1,
              className: "RespawnBackgroundScreen",
              padLayerKind: wO.current || CO ? null : "death",
              padBackCloses: !1,
              cameraKeeper: !0,
              children: [(0, Kp.o)() && (0, hO.jsx)(qp.c, {
                onClick: kp.b,
                children: lO("homePage:backToGames")
              }), (0, hO.jsxs)("div", {
                className: "RespawnContainer",
                onClick: qK,
                children: [(0, hO.jsxs)("div", {
                  className: "RespawnTop",
                  children: [(0, hO.jsx)("div", {
                    ref: BO,
                    className: "RespawnSideSquareBannerDiv",
                    children: pO[0] > 925 && (0, hO.jsx)(GK.b, {
                      info: {
                        adType: "square",
                        adId: 1,
                        adAlias: "banner_respawn_1"
                      },
                      sizeInfo: {
                        parentRef: BO
                      },
                      showing: OK,
                      horizontalAlign: "start",
                      extraContrastBackgroundBox: "left",
                      noFillShowBloxdAdProbability: 0
                    })
                  }), (0, hO.jsx)("div", {
                    className: "RespawnMainContent",
                    children: (0, hO.jsxs)("div", {
                      className: eO()("RespawnMainContentInner", {
                        RespawnMainContentInnerPad: DO
                      }),
                      children: [wO.current && (0, hO.jsxs)("div", {
                        className: "AutoRespawnDeathInfo",
                        children: [(0, hO.jsxs)("div", {
                          className: "AutoRespawnDeathTitle FullyFancyText",
                          children: [(0, hO.jsx)(TO.d, {
                            name: "skull",
                            className: "AutoRespawnDeathIcon"
                          }), lO("respawnPage:youDied")]
                        }), (0, hO.jsxs)("div", {
                          className: "AutoRespawnDeathCause FullyFancyText",
                          children: [null === KK && (jK.current ? lO("respawnPage:pressAnywhereToContinue") : kK ? lO("respawnPage:respawning") : pK(lO("general:respawn"))), null !== KK && (0, hO.jsx)(ep.b, {
                            text: lO("controller:screensPressToContinue", {
                              button: ep.c
                            }),
                            glyph: KK,
                            className: "AutoRespawnContinueGlyph"
                          })]
                        }), UO && (0, hO.jsx)("div", {
                          className: "AutoRespawnStatus",
                          children: UO
                        })]
                      }), !wO.current && (0, hO.jsxs)(hO.Fragment, {
                        children: [(0, hO.jsxs)("div", {
                          className: eO()("RespawnPageButtons", {
                            RespawnPageButtonsVertical: !tK
                          }),
                          children: [IO && (0, hO.jsx)(qp.m, {
                            className: "RespawnPageButton",
                            padDefaultFocus: !0,
                            onClick: () => {
                              (0, xp.qb)((() => {
                                (0, iK.j)("inGameReplay");
                                const OO = (0, ZK.b)(uO);
                                bK(OO)
                              }), "video_start")
                            },
                            disabled: !kK || !RO,
                            touchPressOn: "pointerup",
                            children: pK(lO("respawnPage:playAgain"))
                          }), yK && (0, hO.jsx)(qp.d, {
                            className: "RespawnPageButton",
                            onClick: WO,
                            padDefaultFocus: !IO,
                            padBack: "sessionBasedGame:stayInLobby" === NO,
                            disabled: !kK || !RO,
                            touchPressOn: "pointerup",
                            children: pK(lO(NO))
                          }), !(0, Kp.o)() && (0, hO.jsx)(qp.I, {
                            className: "RespawnPageButton",
                            onClick: kp.b,
                            disabled: !kK || !RO,
                            touchPressOn: "pointerup",
                            children: pK(lO("respawnPage:exitGame"))
                          })]
                        }), tK && (0, hO.jsxs)("div", {
                          className: "RespawnPageOtherGames",
                          children: [(0, hO.jsx)("div", {
                            className: "RespawnPageOtherGamesTitle",
                            children: lO("respawnPage:orTry")
                          }), (0, hO.jsx)("div", {
                            className: "RespawnPageOtherGameThumbnails",
                            children: tK.map((OO => (0, hO.jsx)(Op.f, {
                              source: {
                                type: "game",
                                gameNameWithVariation: OO
                              },
                              disabled: !kK || !RO,
                              gameWidth: "13rem",
                              hideDescription: !0,
                              hideFavourites: !0,
                              hideCcu: !0,
                              onClick: () => {
                                (0, iK.j)("inGameReplay");
                                const KO = (0, ZK.b)(OO);
                                bK(KO)
                              }
                            }, OO)))
                          })]
                        })]
                      })]
                    })
                  }), (0, hO.jsx)("div", {
                    ref: ZO,
                    className: "RespawnSideSquareBannerDiv"
                  })]
                }), (0, hO.jsx)("div", {
                  ref: JO,
                  className: "RespawnBottom",
                  children: (0, hO.jsx)(GK.b, {
                    info: {
                      adType: "leaderboard",
                      adId: 1,
                      adAlias: "banner_respawn_2"
                    },
                    sizeInfo: {
                      parentRef: JO
                    },
                    showing: OK,
                    verticalAlign: "end",
                    extraContrastBackgroundBox: "bottom",
                    noFillShowBloxdAdProbability: 1
                  })
                })]
              })]
            })
          })
        })
      }));
    var hp = pO(35145);
    const Dp = [{
        opacity: 1,
        transform: "scale(1.5)",
        offset: 0
      }, {
        opacity: 1,
        transform: "scale(1)",
        offset: .25
      }, {
        opacity: 0,
        transform: "scale(0.85)",
        offset: 1
      }],
      Mp = [{
        opacity: 1,
        transform: "scale(1.7)",
        offset: 0
      }, {
        opacity: 1,
        transform: "scale(1.1)",
        offset: .2
      }, {
        opacity: .9,
        transform: "scale(1)",
        offset: .5
      }, {
        opacity: 0,
        transform: "scale(0.85)",
        offset: 1
      }],
      aX = {
        duration: 300,
        easing: "ease-out",
        fill: "forwards"
      },
      op = {
        duration: 400,
        easing: "ease-out",
        fill: "forwards"
      },
      Fp = (0, XO.memo)((function() {
        const OO = (0, XO.useRef)(null),
          KO = (0, XO.useRef)(null);

        function pO(pO) {
          var XO;
          let {
            qOO: bK,
            screenPos: eO
          } = pO;
          const lO = OO.current;
          null === (XO = KO.current) || void 0 === XO || XO.cancel(), lO.classList.remove("HitmarkerCrit"), eO ? (lO.style.left = `${eO.x}%`, lO.style.top = `${eO.y}%`) : (lO.style.left = "50%", lO.style.top = "50%"), lO.style.rotate = 16 * (Math.random() - .5) + "deg", bK && lO.classList.add("HitmarkerCrit");
          const vK = lO.animate(bK ? Mp : Dp, bK ? op : aX);
          KO.current = vK, vK.onfinish = () => {
            lO.classList.remove("HitmarkerCrit")
          }
        }
        return (0, vK.f)("localGunHitmarker", (OO => {
          let {
            qOO: KO
          } = OO;
          pO({
            qOO: KO
          })
        })), (0, vK.f)("yourAttackHit", (OO => {
          let {
            qOO: KO,
            screenPos: XO
          } = OO;
          pO({
            qOO: KO,
            screenPos: iK.d.get("isTouchScreen") ? XO : void 0
          })
        })), (0, vK.f)("sendHitmarker", (OO => {
          let {
            qOO: KO,
            screenPos: XO
          } = OO;
          pO({
            qOO: KO,
            screenPos: XO
          })
        })), (0, hO.jsxs)("div", {
          ref: OO,
          className: "Hitmarker",
          children: [(0, hO.jsx)("div", {
            className: "HitmarkerBar"
          }), (0, hO.jsx)("div", {
            className: "HitmarkerBar"
          }), (0, hO.jsx)("div", {
            className: "HitmarkerBar"
          }), (0, hO.jsx)("div", {
            className: "HitmarkerBar"
          })]
        })
      }));

    function Vp() {
      const OO = (0, XO.useRef)(!0);
      return (0, vK.f)("localBlockMined", (() => {
        xK.f.play("blockMined")
      })), (0, vK.f)("yourAttackHit", (() => {
        xK.f.play("hitLanded")
      })), (0, vK.f)("localGunHitmarker", (() => {
        xK.f.play("hitLanded")
      })), (0, vK.f)("damagedByOtherPlayer", (() => {
        xK.f.play("damageTaken")
      })), (0, rK.b)("localPlayerAliveSet", (KO => {
        !KO && OO.current && xK.f.play("death"), OO.current = KO
      })), null
    }
    var Lp = pO(1546),
      Qp = pO(35167),
      zX = pO.n(Qp),
      Ap = pO(1631),
      fp = pO(1623),
      dp = pO(2560),
      Tp = pO(35217);
    const Np = Xp.$d ? 7e7 : 7e3,
      Ip = zX()("#ffffff").alpha(.5).string();

    function yX(OO) {
      const KO = (0, dp.c)(OO);
      return void 0 !== KO && "Gun" === (0, Tp.itemTypeOf)(KO)
    }

    function gX(OO) {
      if (!OO) return console.error(`Killfeed colour was ${OO}`), Ip;
      try {
        return zX()(OO).alpha(.5).string()
      } catch {
        return console.warn(`Killfeed colour ${OO} is not a colour`), Ip
      }
    }
    const upO = (0, XO.memo)((function() {
      const {
        t: OO
      } = (0, cK.D)(), KO = (0, XO.useRef)([]), pO = (0, PK.b)();
      return (0, rK.b)("kill", (function(XO) {
        var bK, eO;
        let {
          killer: lO,
          victim: vK,
          withItem: CO,
          killstreak: hO
        } = XO;
        const DO = KO.current;
        if (DO.length >= 3) {
          const OO = DO.shift();
          clearTimeout(OO.timeout)
        }
        const MO = aK.gameBridge.latest("hiddenPlayerNames"),
          oO = {
            deadName: bX(vK, OO),
            killerName: bX(lO, OO),
            isFriend: {
              killer: (0, Ap.g)(lO.realName, MO),
              dead: (0, Ap.g)(vK.realName, MO)
            },
            withItem: CO,
            wasHeadshot: !1,
            killstreak: hO,
            timeout: setTimeout((() => {
              DO.shift(), pO()
            }), Np),
            reactId: `${null!==(bK=lO.id)&&void 0!==bK?bK:lO.shownName}|${null!==(eO=vK.id)&&void 0!==eO?eO:vK.shownName}|${Date.now()}`,
            killerBackground: gX(lO.colour),
            deadBackground: gX(vK.colour)
          };
        DO.push(oO), pO()
      })), (0, XO.useEffect)((() => {
        const OO = KO.current;
        return () => {
          for (; OO.length > 0;) {
            const {
              timeout: KO
            } = OO.pop();
            clearTimeout(KO)
          }
        }
      }), []), (0, hO.jsx)("div", {
        className: "Killfeed",
        children: KO.current.map((OO => {
          let {
            deadName: KO,
            killerName: pO,
            withItem: XO,
            wasHeadshot: bK,
            killstreak: eO,
            killerBackground: lO,
            deadBackground: vK,
            reactId: CO,
            isFriend: DO
          } = OO;
          return (0, hO.jsxs)("div", {
            className: "IndividualKillWrapper SmallTextLight",
            style: {
              background: `linear-gradient(90deg, ${lO} calc(100% - 10rem), ${vK} 100%)`
            },
            children: [eO >= 2 ? (0, hO.jsx)("div", {
              className: "KillfeedKillstreak",
              children: (0, Xp.O)(eO)
            }) : null, (0, hO.jsx)("div", {
              className: "KillfeedKillerName",
              children: pO
            }), DO.killer && (0, hO.jsx)(fp.c, {}), (0, hO.jsx)("div", {
              className: "KillfeedItem",
              style: {
                height: "5vmin",
                width: yX(XO) ? "7.5vmin" : "5vmin"
              },
              children: (0, hO.jsx)(Lp.b, {
                itemName: XO,
                amount: 0,
                gunTransform: "scaleX(-1)",
                itemMarginTop: 0
              })
            }), bK ? (0, hO.jsx)(TO.d, {
              name: "crosshairs",
              className: "3x KillfeedHeadshotIcon"
            }) : null, (0, hO.jsx)("div", {
              className: "KillfeedDeadName",
              children: KO
            }), DO.dead && (0, hO.jsx)(fp.c, {})]
          }, CO)
        }))
      })
    }));
    var Ep = pO(35220),
      jX = pO(35228),
      Yp = pO.n(jX),
      wp = pO(243),
      iX = pO(35069),
      rX = pO(35230),
      Pp = pO(1146);
    const mX = {},
      sp = (0, XO.memo)((function() {
        const OO = (0, XO.useRef)({}),
          [, KO] = (0, XO.useReducer)((OO => OO + 1), 0);
        (0, vK.f)("setDirectionArrow", (pO => {
          let {
            id: XO,
            position: bK,
            style: eO,
            text: lO,
            Dk: vK
          } = pO;
          const CO = OO.current,
            hO = eO || mX,
            DO = lO,
            MO = CO[XO];
          if (!MO) return CO[XO] = {
            position: bK,
            style: hO,
            text: DO,
            shouldShowDistance: vK,
            wpO: null,
            chevronElement: null,
            distanceElement: null,
            lastRenderedDist: -1,
            lastDistUpdateTime: 0,
            lastScreenX: NaN,
            lastScreenY: NaN,
            onScreen: void 0
          }, void KO();
          const aK = !Yp()(MO.style, hO) || !Yp()(MO.text, DO) || MO.shouldShowDistance !== vK;
          MO.position = bK, MO.style = hO, MO.text = DO, MO.shouldShowDistance = vK, aK && KO()
        })), (0, vK.f)("clearDirectionArrow", (pO => {
          let {
            id: XO
          } = pO;
          const bK = OO.current;
          if (null === XO)
            for (const OO in bK) delete bK[OO];
          else delete bK[XO];
          KO()
        })), (0, XO.useEffect)((() => {
          const KO = OO.current,
            pO = (0, Pp.j)((() => {
              ! function(OO) {
                const KO = aK.gameBridge.lookup("localPos", null),
                  pO = iX.e - Hp,
                  XO = (0, iX.j)() - Hp;
                for (const bK in OO) {
                  const eO = OO[bK];
                  if (!eO.wpO) continue;
                  const lO = aK.gameBridge.lookup("screenPos", eO.position),
                    vK = lO.x - 50,
                    CO = lO.y - 50;
                  lO.x === eO.lastScreenX && lO.y === eO.lastScreenY || (eO.lastScreenX = lO.x, eO.lastScreenY = lO.y, eO.wpO.style.translate = `${lO.x}vw ${lO.y}vh`, eO.chevronElement && (eO.chevronElement.style.rotate = `${Xp.e.fastATan2(CO,vK)}rad`));
                  const hO = Math.abs(vK) < pO && Math.abs(CO) < XO;
                  if (hO !== eO.onScreen && (eO.onScreen = hO, eO.wpO.classList.toggle("DirectionArrowOnScreen", hO)), eO.shouldShowDistance && eO.distanceElement) {
                    const OO = eO.position[0] - KO[0],
                      pO = eO.position[1] - KO[1],
                      XO = eO.position[2] - KO[2],
                      bK = Math.round(Math.sqrt(OO * OO + pO * pO + XO * XO));
                    (-1 === eO.lastRenderedDist || (0, rX.d)(bK, eO.lastRenderedDist, eO.lastDistUpdateTime)) && (eO.distanceElement.textContent = `${bK}m`, eO.lastRenderedDist = bK, eO.lastDistUpdateTime = Date.now() + Math.floor(100 * Math.random()))
                  }
                }
              }(KO)
            }));
          return () => {
            pO();
            for (const OO in KO) delete KO[OO]
          }
        }), []);
        const pO = OO.current;
        return (0, hO.jsx)("div", {
          className: "DirectionArrows",
          children: Object.entries(pO).map((OO => {
            var KO;
            let [XO, bK] = OO;
            const eO = null !== (KO = (0, wp.Ub)(bK.style)) && void 0 !== KO ? KO : "#ffffff";
            return (0, hO.jsxs)("div", {
              ref: OO => {
                pO[XO] && (pO[XO].wpO = OO)
              },
              className: "DirectionArrow",
              style: {
                fontSize: bK.style.fontSize,
                opacity: bK.style.opacity
              },
              children: [(0, hO.jsxs)("div", {
                className: "DirectionArrowChevron",
                ref: OO => {
                  pO[XO] && (pO[XO].chevronElement = OO)
                },
                children: [(0, hO.jsxs)("div", {
                  className: "DirectionArrowShadowLayer",
                  children: [(0, hO.jsx)("div", {
                    className: "DirectionArrowBar"
                  }), (0, hO.jsx)("div", {
                    className: "DirectionArrowBar"
                  })]
                }), (0, hO.jsxs)("div", {
                  className: "DirectionArrowBarLayer",
                  children: [(0, hO.jsx)("div", {
                    className: "DirectionArrowBar",
                    style: {
                      background: eO
                    }
                  }), (0, hO.jsx)("div", {
                    className: "DirectionArrowBar",
                    style: {
                      background: eO
                    }
                  })]
                })]
              }), (0, hO.jsx)("div", {
                className: "DirectionArrowMarker",
                style: {
                  background: eO,
                  boxShadow: `0 0 3px rgba(0, 0, 0, 0.8), 0 0 8px ${eO}`
                }
              }), bK.text && (0, hO.jsx)("div", {
                className: "DirectionArrowLabel SmallTextLight",
                style: {
                  color: eO,
                  fontWeight: bK.style.fontWeight,
                  fontStyle: bK.style.fontStyle
                },
                children: (0, hO.jsx)(CO.d, {
                  text: bK.text
                })
              }), bK.shouldShowDistance && (0, hO.jsx)("div", {
                className: "DirectionArrowDistance SmallTextLight",
                ref: OO => {
                  pO[XO] && (pO[XO].distanceElement = OO)
                },
                style: {
                  color: eO,
                  fontWeight: bK.style.fontWeight,
                  fontStyle: bK.style.fontStyle
                }
              })]
            }, XO)
          }))
        })
      })),
      Hp = .5;
    const Rp = (0, XO.memo)((function(OO) {
        let {
          isTouchScreen: KO
        } = OO;
        return (0, hO.jsxs)("div", {
          className: "BottomRightElements",
          "data-camera-keeper-host": "",
          children: [(0, hO.jsx)(Bp, {}), KO && (0, hO.jsx)(AK, {})]
        })
      })),
      Sp = {
        readyForNext: 0,
        running: 1
      },
      Jp = 50;

    function cX(OO) {
      console.assert(OO.state.current === Sp.readyForNext);
      const KO = OO.queue.current,
        pO = OO.foreground.current;
      if (KO.length > 0 && pO) {
        const {
          toFraction: XO,
          toDuration: bK
        } = KO.shift();
        OO.state.current = Sp.running, pO.style.transition = `transform ${Math.max(bK-Jp,0)}ms linear`, pO.classList.remove("Complete"), OO.timeout.current = setTimeout((() => {
          pO.style.transform = `scaleX(${XO})`, OO.timeout.current = setTimeout((() => {
            1 === XO && pO.classList.add("Complete"), OO.state.current = Sp.readyForNext, cX(OO)
          }), Math.max(bK - Jp, 0))
        }), Jp)
      }
    }

    function Bp() {
      const OO = (0, XO.useRef)([]),
        KO = (0, XO.useRef)(Sp.readyForNext),
        pO = (0, XO.useRef)(void 0),
        bK = (0, XO.useRef)(null),
        eO = (0, XO.useRef)({
          queue: OO,
          state: KO,
          timeout: pO,
          foreground: bK
        }),
        lO = (0, zK.i)("showProgressBar");
      if ((0, XO.useLayoutEffect)((() => (lO && KO.current === Sp.readyForNext && cX(eO.current), () => {
          KO.current = Sp.readyForNext, clearTimeout(pO.current), lO && (OO.current.length = 0)
        })), [lO]), (0, vK.f)("progressBarUpdate", (pO => {
          let {
            toFraction: XO,
            toDuration: bK
          } = pO;
          OO.current.push({
            toFraction: XO,
            toDuration: bK
          }), KO.current === Sp.readyForNext && cX(eO.current)
        })), !lO) return null;
      return (0, hO.jsx)("div", {
        className: "ProgressBarBackground",
        children: (0, hO.jsx)("div", {
          className: "ProgressBarForeground",
          ref: bK,
          style: {
            width: "15vw",
            transformOrigin: "left center",
            transform: "scaleX(0)"
          }
        })
      })
    }
    var Zp = pO(35232),
      Gp = pO(35238);
    var qX = pO(2929),
      xX = pO(2924),
      np = pO(1441),
      Wp = pO(1329),
      tX = pO(1446),
      kX = pO(1481),
      Up = pO(1693),
      OX = pO(1008),
      KX = pO(3554),
      pX = pO(1302),
      XX = pO(1193);
    const bb = 2e4,
      eX = 6e5,
      lX = new Set;

    function vb() {
      const {
        gameEntrySource: OO,
        loadingOverlayVisible: KO
      } = (0, iK.l)(["gameEntrySource", "loadingOverlayVisible"]), pO = (0, rK.e)("connectedGame", (OO => (0, KX.g)(OO) ? OO.lobbyName : null)), bK = (0, rK.i)("localPlayerAlive"), eO = (0, rK.e)("players", (OO => null !== OO.localId && void 0 !== OO.byId[OO.localId])), [lO, vK] = (0, XO.useState)(null);
      return !KO && bK && eO && null !== pO && lO !== pO && vK(pO), (0, XO.useEffect)((() => {
        if (!(0, KX.h)(OO) || null === lO || lO !== pO || lX.has(lO)) return;
        const KO = setTimeout((() => {
          lX.add(lO), async function(OO) {
            const KO = await OX.userContextManager.getCurrentUserContext();
            let pO;
            try {
              pO = (await Wp.c.getWorldOwnerFriendOffer(KO)).owner
            } catch (bK) {
              return void console.warn("Couldn't ask who owns this world", bK)
            }
            if (!pO || (0, KX.p)(pO.name, Date.now())) return;
            const XO = pO;
            ! function(OO, KO) {
              const pO = Date.now() + eX;
              let XO = Date.now(),
                bK = 0;
              const eO = () => {
                const lO = Date.now(),
                  vK = aK.gameBridge.latest("connectedGame");
                vK.lobbyName !== OO || lO > pO || (null === vK.websocketUrl ? XO = 1 / 0 : XO === 1 / 0 && !iK.d.get("loadingOverlayVisible") && aK.gameBridge.latest("localPlayerAlive") && (XO = lO + bb), bK = lO < XO || !aK.gameBridge.latest("localPlayerAlive") || iK.d.get("isUiHidden") || iK.d.get("isUiHiddenByCamera") || (0, kX.isTypingInInput)() || iK.d.get("loadingOverlayVisible") || (0, np.i)() || (0, qX.g)() || (0, XX.m)() ? 0 : bK + 1, bK >= 2 ? KO() : setTimeout(eO, 500))
              };
              eO()
            }(OO, (() => {
              (0, KX.f)(tX.e.getSocialState().friends, XO.name) || ((0, KX.l)(XO.name, Date.now()), Up.b.showWorldOwnerOffer(XO), (0, pX.e)({
                id: "social.world_owner_offer",
                value: "shown"
              }))
            }))
          }(lO).catch((OO => {
            console.error("Failed to offer the world's owner as a friend", OO)
          }))
        }), bb);
        return () => {
          clearTimeout(KO)
        }
      }), [OO, lO, pO]), null
    }
    var CX = pO(1539);
    const hX = (0, XO.memo)((function(OO) {
        let {
          durationMs: KO,
          endsAtMs: pO
        } = OO;
        const [, bK] = (0, XO.useReducer)((OO => OO + 1), 0), eO = null === pO ? KO : Math.max(pO - Date.now(), 0);
        return (0, XO.useEffect)((() => {
          if (null === pO || eO <= 0) return;
          const OO = setTimeout(bK, eO - 1e3 * (Math.ceil(eO / 1e3) - 1));
          return () => {
            clearTimeout(OO)
          }
        })), (0, hO.jsx)("div", {
          className: "EffectInfoDuration SmallTextLight",
          children: (0, Xp.$)(eO)
        })
      })),
      DX = (0, XO.memo)((function() {
        const OO = (0, rK.i)("localEffects");
        return (0, hO.jsx)("div", {
          className: "EffectInfosWrapper",
          children: Object.entries(OO).map((OO => {
            let [KO, {
              icon: pO,
              displayName: XO,
              durationMs: bK,
              endsAtMs: eO,
              level: lO
            }] = OO;
            return (0, hO.jsxs)("div", {
              className: "EffectInfo",
              children: [(0, hO.jsx)(CX.b, {
                icon: pO,
                className: "EffectInfoIcon"
              }), (0, hO.jsxs)("div", {
                className: "EffectInfoRightSide",
                style: {
                  marginTop: null !== bK ? "0" : "1rem"
                },
                children: [(0, hO.jsxs)("div", {
                  className: "EffectInfoNameWrapper",
                  children: [(0, hO.jsx)(CO.d, {
                    text: null !== XO && void 0 !== XO ? XO : KO,
                    className: "EffectInfoName SmallTextBold"
                  }), lO > 1 && (0, hO.jsx)("div", {
                    className: "EffectInfoName SmallTextBold",
                    children: (0, Xp.O)(lO)
                  })]
                }), null !== bK && (0, hO.jsx)(hX, {
                  durationMs: bK,
                  endsAtMs: eO
                })]
              })]
            }, KO)
          }))
        })
      }));
    var MX = pO(35246),
      ab = pO(35378),
      oX = pO(171),
      FX = pO(36),
      VX = pO(1187),
      LX = pO(2224);

    function QX(OO, KO) {
      (0, XO.useLayoutEffect)((() => {
        let KO, pO;
        const XO = requestAnimationFrame((() => {
          pO = setTimeout((() => {
            pO = void 0;
            const XO = OO();
            KO = "function" === typeof XO ? XO : void 0
          }), 0)
        }));
        return () => {
          var OO;
          cancelAnimationFrame(XO), clearTimeout(pO), null === (OO = KO) || void 0 === OO || OO()
        }
      }), KO)
    }
    const zb = [5, 5, 5],
      AX = [7, 4, 4, 4];

    function fX(OO) {
      return OO.reduce(((OO, KO) => OO + KO), 0)
    }

    function dX(OO, KO, pO, XO, bK) {
      const eO = OO.getContext("2d");
      if (!eO) return null;
      const lO = KO.fontFamily,
        vK = KO.fontWeight;
      return OO.width = pO, OO.height = XO, eO.fillStyle = KO.color, eO.textAlign = "center", eO.textBaseline = "middle", eO.font = `${vK} ${bK}px ${lO}`, eO
    }
    const TX = (0, XO.memo)((function(OO) {
      let {
        show: KO
      } = OO;
      const pO = (0, XO.useRef)(null),
        bK = (0, XO.useRef)(null),
        eO = (0, XO.useRef)(null),
        lO = (0, FO.k)();
      return (0, XO.useEffect)((() => lO.whenShown((() => {
        let OO = 0,
          KO = 0,
          pO = 0,
          XO = 0;
        const lO = (0, Pp.j)((() => {
          var lO;
          OO++, KO++;
          const vK = performance.now();
          if (vK - pO < 1e3) return;
          const CO = Math.round(OO / (vK - pO) * 1e3);
          if (bK.current = CO, null === (lO = eO.current) || void 0 === lO || lO.call(eO, CO), OO = 0, pO = vK, CO < 55) {
            var hO, DO;
            XO += 1;
            const OO = FX.e.getItem("decreaseLoadDistPromptDeniedCount"),
              [KO, pO] = tp.c.get("minChunkAddDist");
            if (XO >= 15 && function(OO, KO) {
                const pO = aK.gameBridge.lookup("RV", null);
                return null !== pO && (pO.horizontal > OO || pO.vertical > KO)
              }(KO, pO) && (null !== (hO = FX.e.getItem("lastDecreaseLoadDistPromptTime")) && void 0 !== hO ? hO : 0) + 432e5 < Date.now() && (null !== (DO = FX.e.getItem("decreaseLoadDistPromptDeniedCount")) && void 0 !== DO ? DO : 0) < 3) {
              FX.e.setItem("lastDecreaseLoadDistPromptTime", Date.now());
              VX.NotificationProvider.showPromptPopup({
                title: "Lag (low FPS) caused by high chunk load distance. Decrease it?",
                confirmText: "general:yes",
                cancelText: "general:no",
                unlockPointerKey: "chunkLoadDistanceLagPopup"
              }).getResult().then((XO => {
                XO ? (aK.gameBridge.send("setChunkAddDistance", {
                  horizontal: KO,
                  vertical: pO
                }), FX.e.setItem("chunkHorizAddDist", KO), FX.e.setItem("chunkVertAddDist", pO), dO.i.pl("updatedChunkLoadDist"), FX.e.setItem("decreaseLoadDistPromptDeniedCount", 0)) : FX.e.setItem("decreaseLoadDistPromptDeniedCount", OO + 1)
              }))
            }
          } else XO = 0
        }));
        let vK = performance.now();
        KO = 0;
        let CO = null,
          hO = !document.hidden;

        function DO() {
          const OO = performance.now() - vK,
            pO = 1e3 * KO / OO;
          hO && (null === CO && (CO = pO), LX.b.setFps(pO, CO)), KO = 0, vK = performance.now()
        }
        let MO = setInterval(DO, 15e3);

        function oO() {
          const OO = hO;
          hO = !document.hidden, !OO && hO && (KO = 0, vK = performance.now(), clearInterval(MO), MO = setInterval(DO, 15e3))
        }
        return document.addEventListener("visibilitychange", oO), () => {
          lO(), document.removeEventListener("visibilitychange", oO), clearInterval(MO)
        }
      }))), [lO]), QX((() => {
        var OO;
        if (!KO || eO.current) return;
        const XO = pO.current,
          lO = window.getComputedStyle(XO.parentElement),
          vK = null !== (OO = window.devicePixelRatio) && void 0 !== OO ? OO : 1,
          CO = parseFloat(lO.fontSize) * vK,
          hO = Math.round(3 * CO),
          DO = Math.round(CO),
          MO = dX(XO, lO, hO, DO, CO);
        if (!MO) return;
        const aK = OO => {
          MO.clearRect(0, 0, XO.width, XO.height), MO.fillText(OO.toString(), XO.width / 2, XO.height / 2)
        };
        eO.current = aK, null !== bK.current && aK(bK.current)
      }), [KO]), (0, hO.jsxs)("div", {
        className: "FpsWrapperDiv",
        style: {
          display: KO ? "flex" : "none"
        },
        children: [(0, hO.jsx)("div", {
          className: "FpsLabel",
          children: "FPS"
        }), (0, hO.jsx)("canvas", {
          className: "FpsCanvas",
          ref: pO,
          width: 48,
          height: 16
        })]
      })
    }));

    function NX(OO) {
      return Math.sign(OO) * Math.round(100 * Math.abs(OO))
    }

    function IX(OO) {
      let {
        getCoordinates: KO,
        showChunkCoords: pO,
        columns: bK
      } = OO;
      const eO = (0, XO.useRef)(null);
      return QX((() => {
        var OO;
        const XO = eO.current,
          lO = window.getComputedStyle(XO.parentElement),
          vK = null !== (OO = window.devicePixelRatio) && void 0 !== OO ? OO : 1,
          CO = parseFloat(lO.fontSize) * vK,
          hO = Math.round(CO * fX(bK)),
          DO = Math.round(CO),
          MO = dX(XO, lO, hO, DO, CO);
        if (!MO) return;
        let oO = !0,
          FO = 0,
          VO = 0,
          LO = 0,
          QO = 0,
          zK = 0,
          AO = 0;
        const fO = () => {
          oO = !0
        };
        document.fonts.load(MO.font).then(fO, fO);
        const dO = () => {
          dX(XO, lO, hO, DO, CO), fO()
        };
        XO.addEventListener("contextrestored", dO);
        const TO = (0, Pp.o)((() => {
          var OO, eO, lO, vK, hO, DO;
          const [fO, dO, TO] = KO(), NO = NX(fO), IO = NX(dO), yK = NX(TO);
          let gK = null;
          if (pO) {
            const OO = aK.gameBridge.lookup("localPos", null);
            gK = (0, BO.Z)(OO[0], OO[1], OO[2])
          }
          const uO = null !== (OO = null === (eO = gK) || void 0 === eO ? void 0 : eO[0]) && void 0 !== OO ? OO : 0,
            EO = null !== (lO = null === (vK = gK) || void 0 === vK ? void 0 : vK[1]) && void 0 !== lO ? lO : 0,
            jK = null !== (hO = null === (DO = gK) || void 0 === DO ? void 0 : DO[2]) && void 0 !== hO ? hO : 0;
          if (!oO && NO === FO && IO === VO && yK === LO && uO === QO && EO === zK && jK === AO) return;
          oO = !1, FO = NO, VO = IO, LO = yK, QO = uO, zK = EO, AO = jK;
          const YO = [(NO / 100).toFixed(2), (IO / 100).toFixed(2), (yK / 100).toFixed(2)];
          gK && YO.unshift(`${uO} ${EO} ${jK}`), MO.clearRect(0, 0, XO.width, XO.height);
          const wO = XO.height / 2;
          let iK = 0;
          for (let KO = 0; KO < YO.length; KO++) {
            const OO = CO * bK[KO];
            MO.fillText(YO[KO], iK + OO / 2, wO, OO), iK += OO
          }
        }));
        return () => {
          TO(), XO.removeEventListener("contextrestored", dO)
        }
      }), [KO, pO, bK]), (0, hO.jsx)("div", {
        className: "CoordinateUI",
        children: (0, hO.jsx)("canvas", {
          ref: eO,
          className: "CoordinateCanvas",
          width: 16 * fX(bK),
          height: 16
        })
      })
    }
    const yb = (0, XO.memo)((function() {
        const OO = (0, XO.useCallback)((() => {
          const OO = aK.gameBridge.lookup("localPos", null);
          return [OO[0], OO[1], OO[2]]
        }), []);
        return (0, hO.jsx)(IX, {
          getCoordinates: OO,
          showChunkCoords: !1,
          columns: zb
        })
      })),
      gb = (0, XO.memo)((function() {
        const OO = (0, XO.useCallback)((() => {
          const OO = aK.gameBridge.lookup("localPos", null),
            KO = oX.h.SX;
          let pO = OO[0] % KO,
            XO = OO[1] % KO,
            bK = OO[2] % KO;
          return pO < 0 && (pO += KO), XO < 0 && (XO += KO), bK < 0 && (bK += KO), [pO, XO, bK]
        }), []);
        return (0, hO.jsx)(IX, {
          getCoordinates: OO,
          showChunkCoords: !0,
          columns: AX
        })
      }));
    var uX = pO(1641),
      EX = pO(1180),
      jb = pO(886),
      YX = pO(1077),
      wX = pO(94),
      ib = pO(35259),
      rb = pO(1273),
      PX = pO(2446);
    const mb = (0, XO.memo)((function() {
      const OO = (0, zK.i)("auraPerLevel"),
        KO = (0, zK.i)("maxAuraLevel"),
        [pO, bK] = (0, XO.useState)((() => {
          var OO;
          return null !== (OO = aK.gameBridge.latest("aura")) && void 0 !== OO ? OO : void 0
        })),
        [eO, lO] = (0, XO.useState)((() => QO(pO))),
        [vK, CO] = (0, XO.useReducer)((OO => OO + 1), 0),
        DO = (0, XO.useRef)(null),
        MO = (0, XO.useRef)([]),
        oO = (0, XO.useRef)({
          width: 0,
          level: 0
        }),
        FO = (0, XO.useRef)(null),
        VO = (0, XO.useRef)(null);

      function LO() {
        if (null !== FO.current) return;
        if (0 === MO.current.length) return;
        const {
          width: OO,
          level: KO
        } = MO.current.shift();
        let pO;
        if (KO !== oO.current.level && KO > oO.current.level !== OO > oO.current.width) {
          const XO = KO > oO.current.level;
          pO = XO ? OO : 100 - OO, DO.current.style.transition = "none", DO.current.style.width = XO ? "0%" : "100%", DO.current.offsetWidth
        } else pO = Math.abs(OO - oO.current.width);
        const XO = 100 * pO / 20;
        DO.current.style.transition = `width ${XO}ms linear`, lO(OO), oO.current = {
          width: OO,
          level: KO
        }, MO.current.length > 0 && (FO.current = setTimeout((() => {
          FO.current = null, LO()
        }), XO))
      }

      function QO(pO) {
        return Math.floor(pO / OO) === KO ? 100 : pO % OO / OO * 100
      }
      return (0, XO.useEffect)((() => () => {
        clearTimeout(FO.current), clearTimeout(VO.current), FO.current = null, VO.current = null
      }), []), (0, rK.b)("aura", (KO => {
        if (VO.current && clearTimeout(VO.current), null === KO) return clearTimeout(FO.current), VO.current = null, FO.current = null, MO.current = [], oO.current = {
          width: 0,
          level: 0
        }, bK(void 0), void lO(0);
        VO.current = setTimeout((() => {
          const XO = Math.floor(pO / OO),
            eO = Math.floor(KO / OO),
            lO = QO(KO);
          KO > pO && ib.c.play("exp_collect", .1).rate(1.6 + .5 * Math.random()), eO > XO ? (eO % 5 === 0 && ib.c.play("exp_levelup", .45).rate(.95 + .1 * Math.random()), CO(), MO.current.push({
            width: 100,
            level: XO
          })) : eO < XO && MO.current.push({
            width: 0,
            level: XO
          }), KO === pO && eO === XO || MO.current.push({
            width: lO,
            level: eO
          }), bK(KO), LO()
        }), 50)
      })), (0, fO.d)(), 0 === KO ? null : (0, hO.jsxs)("div", {
        className: "AuraBarWrapper",
        children: [(0, hO.jsxs)("div", {
          className: "AuraBarLabel SmallTextBold",
          children: [(0, hO.jsx)(rb.b, {
            showSignal: vK,
            particleElement: (0, hO.jsx)("img", {
              src: (0, PX.d)("glint"),
              alt: ""
            })
          }), (0, hO.jsx)("img", {
            className: "AuraBarLabelImage",
            src: (0, PX.d)("glint"),
            alt: "aura"
          }), (0, hO.jsx)("div", {
            className: "AuraBarLabelText",
            children: Math.floor((null !== pO && void 0 !== pO ? pO : 0) / OO)
          })]
        }), (0, hO.jsx)("div", {
          className: "AuraBar",
          children: (0, hO.jsx)("div", {
            ref: DO,
            className: "AuraBarBackground",
            style: {
              width: `${eO}%`
            }
          })
        })]
      })
    }));
    var sX = pO(2043);

    function HX(OO) {
      OO.timed && (OO.endedAnimation = OO.timed.animation, OO.timed = null)
    }
    const RX = (0, XO.memo)((function() {
      const OO = (0, XO.useRef)(null),
        KO = (0, XO.useRef)(null),
        pO = (0, XO.useRef)({
          timed: null,
          endedAnimation: null
        });
      return (0, vK.f)("middleScreenBarInitiate", (OO => {
        var XO;
        let {
          duration: bK,
          vOO: eO,
          horizBarRemOffset: lO
        } = OO;
        const vK = pO.current;
        HX(vK);
        const CO = KO.current;
        if (!(bK >= 0) || !CO) return;
        null === (XO = vK.endedAnimation) || void 0 === XO || XO.cancel(), vK.endedAnimation = null;
        const hO = CO.animate([{
          transform: "scaleX(0)"
        }, {
          transform: "scaleX(1)"
        }], {
          duration: bK,
          fill: "forwards"
        });
        vK.timed = {
          vOO: eO,
          horizBarRemOffset: lO,
          animation: hO
        }
      })), (0, vK.f)("middleScreenBarRemove", (() => {
        HX(pO.current)
      })), (0, XO.useEffect)((() => {
        const XO = pO.current;
        let bK = Number.NaN,
          eO = Number.NaN,
          lO = Number.NaN;
        return (0, Pp.g)((() => {
          var pO, vK, CO, hO;
          const DO = OO.current,
            MO = KO.current;
          if (!DO || !MO) return;
          null !== (pO = XO.timed) && void 0 !== pO && pO.vOO && "finished" === XO.timed.animation.playState && HX(XO), null === (vK = XO.endedAnimation) || void 0 === vK || vK.cancel(), XO.endedAnimation = null;
          let oO = XO.timed ? 1 : 0;
          if (!XO.timed) {
            const OO = aK.gameBridge.lookup("momentumFrac", null);
            oO = OO > 0 ? 1 : 0, OO !== lO && (lO = OO, MO.style.transform = `scaleX(${OO})`)
          }
          const FO = null !== (CO = null === (hO = XO.timed) || void 0 === hO ? void 0 : hO.horizBarRemOffset) && void 0 !== CO ? CO : 0;
          FO === bK && oO === eO || (bK = FO, eO = oO, DO.style.transform = `translateX(calc(-50% + ${FO}rem)) scaleX(${oO})`)
        }))
      }), []), (0, hO.jsx)("div", {
        className: "MiddleScreenBar",
        ref: OO,
        children: (0, hO.jsx)("div", {
          className: "MiddleScreenBarFill",
          ref: KO
        })
      })
    }));
    var SX = pO(3846),
      JX = pO(2197);

    function cb() {
      const {
        t: OO
      } = (0, cK.D)(), KO = (0, vK.h)("serverUpdating", null), pO = (0, JX.e)(250, null !== KO);
      return null === KO || pO - KO > 3e4 ? null : (0, hO.jsxs)("div", {
        className: "UpdateCountdownBanner",
        children: [(0, hO.jsx)("div", {
          className: "UpdateCountdownBannerTitle",
          children: OO("updateWaiting:updatingIn", {
            countdown: (0, SX.n)(KO - pO)
          })
        }), (0, hO.jsx)("div", {
          children: OO("updateWaiting:bringYouBack")
        })]
      })
    }
    var BX = pO(35402),
      ZX = pO(1591),
      GX = pO(1618),
      qb = pO(1588);
    const xb = [{
        translationKey: "general:interact"
      }],
      nX = (0, XO.memo)((function() {
        const OO = (0, zK.i)("crosshairText"),
          {
            interactPrompt: KO,
            blockText: pO,
            neededTool: bK
          } = (0, rK.i)("crosshairTarget"),
          {
            isTouchScreen: eO
          } = (0, iK.l)(["isTouchScreen"]),
          lO = (0, mK.p)(),
          DO = (0, GX.d)("alt-fire");
        (0, XO.useEffect)((() => {
          aK.gameBridge.send("setCrosshairInteractPrompt", !eO || lO ? "key" : "touch")
        }), [eO, lO]);
        const [MO, oO] = (0, XO.useReducer)((OO => OO + 1), 0);
        (0, vK.f)("customBindingsChanged", oO);
        var FO;
        if (null !== KO && (lO && null !== DO || !eO && null !== (0, ZX.m)("alt-fire"))) return (0, hO.jsxs)("div", {
          className: "CrosshairText SmallTextBold InteractPrompt",
          children: [(0, hO.jsx)(qb.d, {
            noaAction: "alt-fire"
          }), (0, hO.jsx)(CO.d, {
            text: null !== (FO = KO.label) && void 0 !== FO ? FO : xb
          })]
        });
        let VO = null;
        return null !== pO ? VO = pO : null !== OO && "" !== OO ? VO = OO : null !== bK && (VO = [{
          icon: bK,
          style: {
            opacity: .8
          }
        }, {
          str: " needed",
          style: {
            opacity: .8
          }
        }]), VO ? (0, hO.jsx)("div", {
          className: "CrosshairText SmallTextBold",
          children: (0, hO.jsx)(CO.d, {
            text: VO
          })
        }) : null
      }));
    var WX = pO(2045);
    const tb = (0, XO.memo)((function() {
      var OO;
      const {
        interactPrompt: KO
      } = (0, rK.i)("crosshairTarget"), {
        openInGameMenuName: pO,
        openEverythingMenuName: XO
      } = (0, iK.l)(["openInGameMenuName", "openEverythingMenuName"]), bK = (0, vK.h)("aimingOverlay", "none"), eO = (0, PO.l)(), lO = (0, WX.b)();
      return null === KO || null !== pO || null !== XO || "sniper" === bK || eO || lO ? null : (0, hO.jsx)(kb, {
        label: null !== (OO = KO.label) && void 0 !== OO ? OO : xb
      })
    }));

    function kb(OO) {
      let {
        label: KO
      } = OO;
      const pO = (0, bp.p)(RO.b.Interact, !1);
      return (0, hO.jsx)("div", {
        ref: pO,
        className: "TouchInteractHit",
        children: (0, hO.jsxs)("div", {
          className: "TouchInteractKey",
          children: [(0, hO.jsx)("span", {
            className: "TouchInteractIcon",
            children: (0, hO.jsx)(TO.d, {
              name: "hand-back-point-up"
            })
          }), (0, hO.jsx)(CO.d, {
            text: KO
          })]
        })
      })
    }
    var UX = pO(3908),
      Ob = pO(3967);
    const Kb = (0, XO.forwardRef)((function(OO, KO) {
        let {
          text: pO,
          className: XO,
          children: bK
        } = OO;
        return pO.hasText ? (0, hO.jsx)("div", {
          ref: KO,
          className: eO()("HudTextPanel", XO, {
            NoBackground: !pO.showBackground
          }),
          children: null !== bK && void 0 !== bK ? bK : (0, hO.jsx)(CO.d, {
            text: pO.content
          })
        }) : null
      })),
      pb = (0, XO.memo)((function() {
        const OO = (0, zK.m)("middleTextTop"),
          [KO, pO] = (0, XO.useState)(null),
          bK = (0, Gp.l)(KO);
        return OO.hasText ? (0, hO.jsx)("div", {
          className: eO()("MiddleTextTopContainer", {
            MiddleTextTopBelow: bK
          }),
          children: (0, hO.jsx)(Kb, {
            ref: pO,
            className: "MiddleTextTop",
            text: OO
          })
        }) : null
      })),
      Xb = (0, XO.memo)((function() {
        const OO = (0, zK.b)();
        return (0, hO.jsx)(hO.Fragment, {
          children: OO.map(((OO, KO) => (0, hO.jsx)(Kb, {
            className: "HeaderChip",
            text: OO
          }, KO)))
        })
      }));
    var be = pO(2874),
      eb = pO(3789);
    const lb = (0, XO.memo)((function() {
      const {
        t: OO
      } = (0, cK.D)(), [KO, pO] = (0, XO.useState)(!1), bK = (0, XO.useRef)(!1), eO = function(OO) {
        let {
          gameNameWithVariation: KO,
          lobbyName: pO
        } = OO;
        if ((0, jb.k)(KO)) return ve;
        if ((0, YX.D)(pO)) return Cb;
        return null
      }((0, rK.i)("connectedGame"));
      if (!eO || KO) return null;
      const lO = eb.c[eO.target];
      return (0, hO.jsx)(AO.g, {
        tooltipInner: (0, hO.jsx)("div", {
          children: OO(lO.reportButtonTooltip)
        }),
        children: (0, hO.jsx)("div", {
          children: (0, hO.jsx)(qp.P, {
            onClick: () => {
              bK.current || (bK.current = !0, (0, eb.f)(eO.reportPolicyIds, lO).then((OO => {
                null !== OO && void 0 !== OO && OO.selectedPolicyId && (aK.gameBridge.send("reportLobbyOrGame", {
                  target: eO.target,
                  LX: OO.selectedPolicyId,
                  details: OO.Ur
                }), pO(!0))
              })).finally((() => {
                bK.current = !1
              })))
            }
          })
        })
      })
    }));
    const ve = {
        target: "customGame",
        reportPolicyIds: be.c
      },
      Cb = {
        target: "lobby",
        reportPolicyIds: be.g
      };
    var hb = pO(7872),
      Db = pO(35414),
      Mb = pO(35421),
      ae = pO(35427),
      ob = pO(35432),
      Fb = pO(35454);

    function Vb(OO) {
      return OO instanceof Error && Lb.has(OO.message) ? OO.message : void 0
    }
    const Lb = new Set([Fb.b.saveBusy.text, Fb.b.saveClosed.text, Fb.b.cropBusy.text]);
    let Qb = !1;
    async function ze(OO, KO) {
      var pO, XO;
      const {
        files: bK
      } = KO, eO = bK.replayKey();
      if (null === eO) return "none";
      if (Qb) throw new Error(Fb.b.saveBusy.text);
      const lO = null !== (pO = null === (XO = bK.saveRefusal) || void 0 === XO ? void 0 : XO.call(bK)) && void 0 !== pO ? pO : null;
      if (null !== lO) throw new Error(lO);
      Qb = !0;
      try {
        return await async function(OO, KO, pO) {
          const {
            files: XO
          } = KO, bK = () => XO.replayKey() === pO, eO = (OO, KO) => {
            bK() && XO.markSaved(OO, KO)
          };
          let lO = null;
          if (KO.pickerSupported()) {
            try {
              if (lO = await KO.chooseFile(OO ? null : XO.fileHandle()), null === lO) return "dl"
            } catch (CO) {
              KO.onFallback(CO)
            }
            if (!bK()) throw new Error(Fb.b.saveClosed.text)
          }
          const vK = await XO.encode();
          if (null === vK) {
            if (null !== lO) throw new Error(Fb.b.saveClosed.text);
            return "none"
          }
          if (null !== lO) try {
            return await KO.write(lO, vK), eO(lO), "written"
          } catch (CO) {
            KO.onFallback(CO)
          }
          return eO(null, KO.download(vK)), "downloaded"
        }(OO, KO, eO)
      } finally {
        Qb = !1
      }
    }
    var Ab = pO(3730),
      fb = pO(77);
    const db = [1, 2, 4, 8, 16, 32, 64];

    function Tb(OO, KO) {
      return Math.max(0, Math.min(OO, KO))
    }

    function Nb(OO, KO, pO) {
      return pO <= KO ? 0 : (OO - KO) / (pO - KO) * 100
    }

    function Ib(OO, KO, pO) {
      const XO = pO - KO;
      return Math.round(KO + OO / 100 * XO)
    }

    function ye(OO, KO) {
      const pO = Math.floor(OO / KO / 60),
        XO = Math.floor(OO / KO % 60),
        bK = OO % KO;
      return `${pO.toString().padStart(2,"0")}:${XO.toString().padStart(2,"0")}:${bK.toString().padStart(2,"0")}`
    }

    function ge(OO) {
      return Number.isInteger(OO) || db.includes(OO) ? `${Math.round(OO)}\xd7` : `${OO.toFixed(1)}\xd7`
    }

    function ub(OO, KO) {
      const pO = db.indexOf(OO);
      if (-1 !== pO) return "in" === KO ? db[Math.min(pO + 1, db.length - 1)] : db[Math.max(pO - 1, 0)];
      if ("in" === KO) {
        for (const KO of db)
          if (KO >= OO) return KO;
        return OO
      }
      for (let XO = db.length - 1; XO >= 0; XO--)
        if (db[XO] <= OO) return db[XO];
      return db[0]
    }

    function Eb(OO, KO) {
      const pO = KO.getBoundingClientRect();
      if (pO.width <= 0) return 0;
      const XO = (OO - pO.left) / pO.width * 100;
      return Math.max(0, Math.min(100, XO))
    }

    function je(OO, KO) {
      return KO <= 0 ? 0 : OO / KO * 100
    }

    function Yb(OO, KO, pO) {
      const XO = [];
      let bK = Math.ceil(OO / pO) * pO;
      for (; bK <= KO;) XO.push(bK), bK += pO;
      return XO
    }
    var wb = pO(35460);
    const ie = [{
        label: "Linear",
        easing: wb.k
      }, {
        label: "Ease",
        easing: [.25, .1, .25, 1]
      }, {
        label: "Ease In",
        easing: wb.e
      }, {
        label: "Ease Out",
        easing: wb.g
      }, {
        label: "Ease In Out",
        easing: wb.d
      }],
      re = 200,
      Pb = 150;

    function me(OO) {
      const KO = OO => Number(OO.toFixed(3)).toString();
      return `cubic-bezier(${KO(OO[0])}, ${KO(OO[1])}, ${KO(OO[2])}, ${KO(OO[3])})`
    }

    function sb(OO, KO) {
      return {
        cx: 25 + OO * Pb,
        cy: 25 + (1 - KO) * Pb
      }
    }

    function Hb(OO, KO, pO) {
      const XO = OO - pO.left,
        bK = KO - pO.top;
      return {
        x: Xp.e.clamp((XO - 25) / Pb, 0, 1),
        y: Xp.e.clamp(1 - (bK - 25) / Pb, -1, 2)
      }
    }

    function Rb(OO, KO, pO, XO, bK) {
      return {
        x: (0, wb.v)(OO, pO, bK),
        y: (0, wb.v)(KO, XO, bK)
      }
    }
    const Sb = (0, XO.memo)((function(OO) {
      let {
        value: KO,
        onChange: pO
      } = OO;
      const bK = (0, XO.useRef)(null),
        eO = (0, XO.useRef)(null),
        [lO, vK] = (0, XO.useState)(null),
        CO = (0, XO.useCallback)((() => {
          const OO = bK.current;
          if (!OO) return;
          const pO = OO.getContext("2d");
          if (!pO) return;
          const XO = window.devicePixelRatio || 1;
          OO.width = re * XO, OO.height = re * XO, pO.setTransform(XO, 0, 0, XO, 0, 0), pO.clearRect(0, 0, re, re), pO.fillStyle = "rgba(38, 52, 93, 0.85)", pO.fillRect(0, 0, re, re), pO.beginPath();
          const eO = sb(0, 0),
            vK = sb(1, 1);
          pO.moveTo(eO.cx, eO.cy), pO.lineTo(vK.cx, vK.cy), pO.strokeStyle = "rgba(164, 164, 164, 0.35)", pO.setLineDash([3, 3]), pO.stroke(), pO.setLineDash([]);
          const [CO, hO, DO, MO] = KO, aK = sb(CO, hO), oO = sb(DO, MO);
          pO.strokeStyle = "rgba(252, 211, 115, 0.55)", pO.lineWidth = 1.5, pO.beginPath(), pO.moveTo(eO.cx, eO.cy), pO.lineTo(aK.cx, aK.cy), pO.moveTo(vK.cx, vK.cy), pO.lineTo(oO.cx, oO.cy), pO.stroke(), pO.strokeStyle = "#fcd373", pO.lineWidth = 2, pO.beginPath();
          for (let KO = 0; KO <= 50; KO++) {
            const OO = Rb(CO, hO, DO, MO, KO / 50),
              XO = sb(OO.x, OO.y);
            0 === KO ? pO.moveTo(XO.cx, XO.cy) : pO.lineTo(XO.cx, XO.cy)
          }
          pO.stroke();
          const FO = (OO, KO, XO) => {
            pO.beginPath(), pO.arc(OO, KO, XO ? 6 : 5, 0, 2 * Math.PI), pO.fillStyle = XO ? "#ffb914" : "#fcd373", pO.fill(), pO.strokeStyle = "#1a1f2e", pO.lineWidth = 1.5, pO.stroke()
          };
          FO(aK.cx, aK.cy, "p1" === lO), FO(oO.cx, oO.cy, "p2" === lO)
        }), [lO, KO]);
      (0, XO.useEffect)((() => {
        CO()
      }), [CO]);
      const DO = (0, XO.useCallback)(((OO, XO) => {
          const lO = bK.current,
            vK = eO.current;
          if (!lO || !vK) return;
          const CO = lO.getBoundingClientRect(),
            {
              x: hO,
              y: DO
            } = Hb(OO, XO, CO);
          pO("p1" === vK ? [hO, DO, KO[2], KO[3]] : [KO[0], KO[1], hO, DO])
        }), [pO, KO]),
        MO = (0, XO.useCallback)((OO => {
          const pO = bK.current;
          if (!pO) return;
          const XO = pO.getBoundingClientRect();
          let {
            x: lO,
            y: CO
          } = Hb(OO.clientX, OO.clientY, XO);
          lO = Xp.e.clamp(lO, 0, 1), CO = Xp.e.clamp(CO, 0, 1);
          const [hO, MO, aK, oO] = KO.map((OO => Xp.e.clamp(OO, 0, 1))), FO = Math.hypot(lO - hO, CO - MO), VO = Math.hypot(lO - aK, CO - oO), LO = FO <= VO ? "p1" : "p2";
          ("p1" === LO ? FO : VO) > .12 || (eO.current = LO, vK(LO), pO.setPointerCapture(OO.pointerId), DO(OO.clientX, OO.clientY))
        }), [DO, KO]),
        aK = (0, XO.useCallback)((OO => {
          eO.current && DO(OO.clientX, OO.clientY)
        }), [DO]),
        oO = (0, XO.useCallback)((OO => {
          eO.current = null, vK(null), OO.currentTarget.hasPointerCapture(OO.pointerId) && OO.currentTarget.releasePointerCapture(OO.pointerId)
        }), []);
      return (0, hO.jsxs)("div", {
        className: "CubicBezierEasingEditor",
        children: [(0, hO.jsx)("canvas", {
          ref: bK,
          className: "CubicBezierEasingEditorCanvas",
          style: {
            width: re,
            height: re
          },
          onPointerDown: MO,
          onPointerMove: aK,
          onPointerUp: oO,
          onPointerCancel: oO
        }), (0, hO.jsx)("span", {
          className: "CubicBezierEasingEditorReadout",
          children: me(KO)
        })]
      })
    }));
    var Jb = pO(1479);
    const ce = 12;

    function Bb(OO) {
      return {
        left: OO.left + OO.width / 2,
        top: OO.top - 8
      }
    }

    function Zb(OO, KO) {
      const [pO, bK] = (0, XO.useState)(null);
      return (0, XO.useLayoutEffect)((() => {
        const pO = OO.current;
        if (!pO) return;
        const {
          width: XO,
          height: eO
        } = pO.getBoundingClientRect();
        bK(function(OO, KO, pO) {
          const XO = window.innerWidth,
            bK = window.innerHeight,
            eO = KO / 2;
          let lO = OO.left + OO.width / 2;
          lO = Math.max(ce + eO, Math.min(lO, XO - ce - eO));
          const vK = OO.top - 8 - ce,
            CO = bK - OO.bottom - 8 - ce,
            hO = vK < pO && CO >= vK;
          let DO;
          hO ? (DO = OO.bottom + 8, DO + pO > bK - ce && (DO = bK - ce - pO), DO = Math.max(ce, DO)) : (DO = OO.top - 8, DO - pO < ce && (DO = ce + pO));
          return {
            left: lO,
            top: DO,
            placeBelow: hO
          }
        }(KO, XO, eO))
      }), [KO, OO]), pO
    }

    function Gb(OO, KO, pO) {
      (0, XO.useEffect)((() => (0, lK.b)("pointerdown", (XO => {
        var bK, eO;
        const lO = XO.target;
        lO instanceof Node && (null !== (bK = OO.current) && void 0 !== bK && bK.contains(lO) || null !== pO && void 0 !== pO && null !== (eO = pO.current) && void 0 !== eO && eO.contains(lO) || (0, Jb.k)(lO) || KO())
      }))), [pO, KO, OO])
    }

    function qe(OO) {
      let {
        label: KO,
        value: pO,
        onChange: XO
      } = OO;
      return (0, hO.jsxs)("div", {
        className: "ReplayKeyframePopoverVec3",
        children: [(0, hO.jsx)("span", {
          className: "ReplayKeyframePopoverVec3Label",
          children: KO
        }), (0, hO.jsx)("div", {
          className: "ReplayKeyframePopoverVec3Inputs",
          children: ["X", "Y", "Z"].map(((OO, KO) => (0, hO.jsxs)("label", {
            className: "ReplayKeyframePopoverAxis",
            children: [(0, hO.jsx)("span", {
              children: OO
            }), (0, hO.jsx)("input", {
              type: "number",
              step: "any",
              value: pO[KO],
              onChange: OO => {
                const bK = Number.parseFloat(OO.target.value);
                if (Number.isNaN(bK)) return;
                const eO = [pO[0], pO[1], pO[2]];
                eO[KO] = bK, XO(eO)
              }
            })]
          }, OO)))
        })]
      })
    }
    const xe = (0, XO.memo)((function(OO) {
        var KO, pO, bK;
        let {
          keyframe: lO,
          anchor: vK,
          hasOutgoingSegment: CO,
          onClose: DO,
          onApply: MO,
          onDelete: aK,
          onUseCurrentCamera: oO
        } = OO;
        const FO = (0, XO.useRef)(null),
          VO = Zb(FO, vK.rect),
          [LO, QO] = (0, XO.useState)((() => [lO.position[0], lO.position[1], lO.position[2]])),
          [zK, AO] = (0, XO.useState)((() => [lO.direction[0], lO.direction[1], lO.direction[2]])),
          [fO, dO] = (0, XO.useState)((() => lO.easing));
        (0, XO.useEffect)((() => {
          QO([lO.position[0], lO.position[1], lO.position[2]]), AO([lO.direction[0], lO.direction[1], lO.direction[2]]), dO(lO.easing)
        }), [lO]), Gb(FO, DO);
        const TO = (0, XO.useCallback)((() => {
            MO({
              KK: lO.KK,
              position: LO,
              direction: zK,
              easing: fO
            }), DO()
          }), [zK, fO, lO.KK, MO, DO, LO]),
          NO = (0, XO.useCallback)((() => {
            aK(lO.KK), DO()
          }), [lO.KK, aK, DO]),
          IO = (0, XO.useCallback)((() => {
            const OO = oO();
            OO && (QO([OO.position[0], OO.position[1], OO.position[2]]), AO([OO.direction[0], OO.direction[1], OO.direction[2]]))
          }), [oO]),
          yK = Bb(vK.rect);
        return (0, hO.jsxs)("div", {
          ref: FO,
          className: eO()("ReplayViewerPopover ReplayKeyframePopover", {
            Below: null !== (KO = null === VO || void 0 === VO ? void 0 : VO.placeBelow) && void 0 !== KO && KO,
            Positioned: null !== VO
          }),
          style: {
            left: `${null!==(pO=null===VO||void 0===VO?void 0:VO.left)&&void 0!==pO?pO:yK.left}px`,
            top: `${null!==(bK=null===VO||void 0===VO?void 0:VO.top)&&void 0!==bK?bK:yK.top}px`
          },
          onPointerDown: OO => {
            OO.stopPropagation()
          },
          children: [(0, hO.jsxs)("div", {
            className: "ReplayKeyframePopoverHeader",
            children: [(0, hO.jsx)("span", {
              className: "ReplayKeyframePopoverTitle",
              children: "Camera keyframe"
            }), (0, hO.jsxs)("span", {
              className: "ReplayKeyframePopoverTick",
              children: ["Tick ", vK.KK]
            })]
          }), (0, hO.jsx)(qe, {
            label: "Position",
            value: LO,
            onChange: QO
          }), (0, hO.jsx)(qe, {
            label: "Direction",
            value: zK,
            onChange: AO
          }), CO && (0, hO.jsxs)("div", {
            className: "ReplayKeyframePopoverEasing",
            children: [(0, hO.jsx)("span", {
              className: "ReplayKeyframePopoverEasingLabel",
              children: "Easing to next"
            }), (0, hO.jsx)("div", {
              className: "ReplayKeyframePopoverEasingPresets",
              children: ie.map((OO => {
                const KO = (pO = fO, XO = OO.easing, pO[0] === XO[0] && pO[1] === XO[1] && pO[2] === XO[2] && pO[3] === XO[3]);
                var pO, XO;
                return (0, hO.jsx)(qp.S, {
                  className: eO()("ReplayKeyframePopoverPreset", {
                    Active: KO
                  }),
                  onClick: () => {
                    dO(OO.easing)
                  },
                  children: OO.label
                }, OO.label)
              }))
            }), (0, hO.jsx)(Sb, {
              value: fO,
              onChange: dO
            })]
          }), (0, hO.jsxs)("div", {
            className: "ReplayKeyframePopoverActions",
            children: [(0, hO.jsx)(qp.d, {
              className: "ReplayViewerCompactButton",
              onClick: IO,
              children: "Use current view"
            }), (0, hO.jsx)(qp.m, {
              className: "ReplayViewerCompactButton",
              onClick: TO,
              children: "Apply"
            }), (0, hO.jsx)(qp.I, {
              className: "ReplayViewerCompactButton",
              onClick: NO,
              children: "Delete"
            })]
          })]
        })
      })),
      nb = (0, XO.memo)((function(OO) {
        var KO, pO, bK;
        let {
          anchor: lO,
          hasPlaybackMark: vK,
          onClose: CO,
          onMark: DO,
          onZoom: MO,
          onCrop: aK,
          onDeleteKeyframes: oO,
          onClearMark: FO
        } = OO;
        const VO = (0, XO.useRef)(null),
          LO = Zb(VO, lO.rect),
          QO = Bb(lO.rect),
          zK = {
            startTick: lO.startTick,
            endTick: lO.endTick
          },
          AO = lO.endTick > lO.startTick;
        return Gb(VO, CO), (0, hO.jsx)("div", {
          ref: VO,
          className: eO()("ReplayViewerPopover ReplayTimelineSelectionPopover", {
            Below: null !== (KO = null === LO || void 0 === LO ? void 0 : LO.placeBelow) && void 0 !== KO && KO,
            Positioned: null !== LO
          }),
          style: {
            left: `${null!==(pO=null===LO||void 0===LO?void 0:LO.left)&&void 0!==pO?pO:QO.left}px`,
            top: `${null!==(bK=null===LO||void 0===LO?void 0:LO.top)&&void 0!==bK?bK:QO.top}px`
          },
          onPointerDown: OO => {
            OO.stopPropagation()
          },
          children: (0, hO.jsxs)("div", {
            className: "ReplayTimelineSelectionPopoverActions",
            children: [(0, hO.jsx)(qp.m, {
              className: "ReplayViewerActionButton",
              onClick: () => {
                DO(zK)
              },
              disabled: !AO,
              children: (0, hO.jsx)("span", {
                children: " Play range "
              })
            }), (0, hO.jsx)(qp.d, {
              className: "ReplayViewerActionButton",
              onClick: () => {
                MO(zK)
              },
              children: (0, hO.jsx)("span", {
                children: " Zoom "
              })
            }), (0, hO.jsx)(qp.S, {
              className: "ReplayViewerActionButton Quiet",
              onClick: () => {
                aK(zK)
              },
              disabled: !AO,
              children: (0, hO.jsx)("span", {
                children: " Crop "
              })
            }), (0, hO.jsx)(qp.S, {
              className: "ReplayViewerActionButton Quiet",
              onClick: () => {
                oO(zK)
              },
              children: (0, hO.jsx)("span", {
                children: " Delete all keyframes "
              })
            }), vK && (0, hO.jsx)(qp.S, {
              className: "ReplayViewerActionButton Quiet",
              onClick: () => {
                FO()
              },
              children: (0, hO.jsx)("span", {
                children: " Clear range "
              })
            })]
          })
        })
      })),
      Wb = (0, XO.memo)((function(OO) {
        var KO, pO;
        let {
          maxTick: bK,
          displayTick: lO,
          RKO: vK,
          cameraKeyframes: CO,
          playbackMark: DO,
          onSeek: MO,
          onPause: aK,
          onScrubTickChange: oO,
          onMoveCameraKeyframe: FO,
          onUpdateCameraKeyframe: VO,
          onDeleteCameraKeyframe: LO,
          onUseCurrentCamera: QO,
          onMarkRange: zK,
          onCropRange: AO,
          onDeleteKeyframesInRange: fO,
          onClearMark: dO,
          zoomLevel: TO,
          onZoomLevelChange: NO
        } = OO;
        const IO = (0, XO.useRef)(null),
          yK = (0, XO.useRef)(null),
          gK = (0, XO.useRef)(!1),
          uO = (0, XO.useRef)(!1),
          EO = (0, XO.useRef)(TO),
          jK = (0, XO.useRef)(null),
          YO = (0, XO.useRef)(null),
          wO = (0, XO.useRef)(null),
          iK = (0, XO.useRef)(null),
          [rK, PO] = (0, XO.useState)(null),
          [mK, sO] = (0, XO.useState)(lO),
          [HO, RO] = (0, XO.useState)(null),
          [SO, JO] = (0, XO.useState)(null),
          [cK, BO] = (0, XO.useState)(null),
          [ZO, GO] = (0, XO.useState)(null),
          qK = (0, XO.useMemo)((() => CO.map((OO => OO.KK))), [CO]),
          xK = null !== rK && void 0 !== rK ? rK : lO,
          {
            viewStart: nO,
            viewEnd: WO
          } = (0, XO.useMemo)((() => function(OO) {
            const KO = OO.maxTick + 1,
              pO = Math.max(1, Math.ceil(KO / OO.zoomLevel)),
              XO = Math.floor(pO / 2);
            let bK = OO.centerTick - XO;
            return bK = Math.max(0, Math.min(bK, OO.maxTick - pO + 1)), {
              viewStart: bK,
              viewEnd: Math.min(OO.maxTick, bK + pO - 1)
            }
          }({
            maxTick: bK,
            zoomLevel: TO,
            centerTick: mK
          })), [bK, TO, mK]);
        (0, XO.useEffect)((() => {
          if (null !== rK || null !== YO.current || null !== wO.current || null !== iK.current) return;
          if (gK.current) return void(gK.current = !1);
          if (uO.current) return void(uO.current = !1);
          const OO = EO.current !== TO;
          EO.current = TO, OO && sO(lO)
        }), [TO, lO, rK]);
        const tK = (0, XO.useCallback)((OO => {
            let KO = Tb(OO, bK);
            return DO && (KO = Math.max(DO.inTick, Math.min(KO, DO.outTick))), KO
          }), [bK, DO]),
          kK = (0, XO.useCallback)(((OO, KO) => {
            const pO = tK(OO);
            MO(pO), KO && sO(pO)
          }), [tK, MO]),
          UO = (0, XO.useCallback)(((OO, KO) => {
            const pO = tK(OO);
            PO(pO), oO(pO), kK(pO, KO)
          }), [tK, kK, oO]),
          OK = (0, XO.useCallback)((() => {
            PO((OO => (null !== OO && sO(OO), null))), oO(null)
          }), [oO]),
          KK = (0, XO.useCallback)((() => {
            BO(null), GO(null)
          }), []),
          pK = (0, XO.useCallback)((OO => {
            const KO = IO.current;
            if (!KO) return 0;
            return Tb(Ib(Eb(OO, KO), nO, WO), bK)
          }), [bK, WO, nO]),
          XK = (0, XO.useCallback)((OO => {
            const KO = yK.current;
            if (!KO) return 0;
            return Tb(Ib(Eb(OO, KO), 0, bK), bK)
          }), [bK]),
          bp = (0, XO.useMemo)((() => {
            if (!HO) return [...qK];
            const OO = qK.filter((OO => OO !== HO.fromTick));
            return OO.push(HO.previewTick), OO.sort(((OO, KO) => OO - KO)), OO
          }), [qK, HO]),
          eK = (0, XO.useMemo)((() => {
            var OO;
            return SO && null !== (OO = CO.find((OO => OO.KK === SO.KK))) && void 0 !== OO ? OO : null
          }), [CO, SO]),
          lK = (0, XO.useMemo)((() => !!eK && CO.some((OO => OO.KK > eK.KK))), [CO, eK]);
        (0, XO.useEffect)((() => {
          SO && !eK && JO(null)
        }), [SO, eK]), (0, XO.useEffect)((() => {
          if (!ZO) return () => {};
          const OO = OO => {
            "Escape" === OO.key && KK()
          };
          return window.addEventListener("keydown", OO), () => {
            window.removeEventListener("keydown", OO)
          }
        }), [KK, ZO]);
        const vp = (0, XO.useCallback)(((OO, KO) => {
            KK(), aK(), MO(OO, {
              ignorePlaybackMark: !0
            }), JO({
              KK: OO,
              rect: KO.getBoundingClientRect()
            })
          }), [KK, aK, MO]),
          CK = (0, XO.useCallback)(((OO, KO) => pO => {
            0 === pO.button && (pO.stopPropagation(), JO(null), KK(), aK(), jK.current = {
              fromTick: OO,
              startX: pO.clientX,
              startY: pO.clientY,
              didDrag: !1,
              track: KO
            }, RO({
              fromTick: OO,
              previewTick: OO,
              track: KO
            }), pO.currentTarget.setPointerCapture(pO.pointerId))
          }), [KK, aK]),
          hK = (0, XO.useCallback)((OO => {
            if (!HO) return;
            OO.stopPropagation();
            const KO = jK.current;
            if (KO && !KO.didDrag) {
              const pO = OO.clientX - KO.startX,
                XO = OO.clientY - KO.startY;
              Math.hypot(pO, XO) > 5 && (KO.didDrag = !0)
            }
            const pO = "detail" === HO.track ? pK(OO.clientX) : XK(OO.clientX);
            pO !== HO.previewTick && RO({
              ...HO,
              previewTick: pO
            })
          }), [HO, pK, XK]),
          DK = (0, XO.useCallback)((OO => {
            if (!HO) return;
            OO.stopPropagation();
            const KO = jK.current,
              pO = "detail" === HO.track ? pK(OO.clientX) : XK(OO.clientX);
            KO && !KO.didDrag ? vp(KO.fromTick, OO.currentTarget) : pO !== HO.fromTick && FO(HO.fromTick, pO), RO(null), jK.current = null, OO.currentTarget.releasePointerCapture(OO.pointerId)
          }), [HO, FO, vp, pK, XK]),
          MK = (0, XO.useCallback)((OO => {
            if (0 !== OO.button) return;
            JO(null), aK();
            const KO = pK(OO.clientX);
            YO.current = {
              pointerId: OO.pointerId,
              startX: OO.clientX,
              startY: OO.clientY,
              startTick: KO,
              currentTick: KO,
              didSelect: !1
            }, BO(null), GO(null), OO.currentTarget.setPointerCapture(OO.pointerId)
          }), [aK, pK]),
          ap = (0, XO.useCallback)((OO => {
            const KO = YO.current;
            if (!KO || KO.pointerId !== OO.pointerId) return;
            const pO = pK(OO.clientX);
            if (KO.currentTick = pO, !KO.didSelect) {
              const pO = OO.clientX - KO.startX,
                XO = OO.clientY - KO.startY;
              if (Math.hypot(pO, XO) <= 5) return;
              KO.didSelect = !0
            }
            const XO = Math.min(KO.startTick, pO),
              bK = Math.max(KO.startTick, pO);
            BO({
              startTick: XO,
              endTick: bK
            })
          }), [pK]),
          oK = (0, XO.useCallback)((OO => {
            const KO = YO.current;
            if (!KO || KO.pointerId !== OO.pointerId) return;
            if (YO.current = null, OO.currentTarget.releasePointerCapture(OO.pointerId), !KO.didSelect) return KK(), void kK(KO.startTick, !0);
            const pO = pK(OO.clientX),
              XO = Math.min(KO.startTick, pO),
              bK = Math.max(KO.startTick, pO),
              eO = {
                startTick: XO,
                endTick: bK
              };
            BO(eO);
            const lO = IO.current;
            if (!lO) return;
            const vK = lO.getBoundingClientRect(),
              CO = Nb(XO, nO, WO) / 100,
              hO = Nb(bK, nO, WO) / 100,
              DO = vK.left + CO * vK.width,
              MO = vK.left + hO * vK.width;
            GO({
              ...eO,
              rect: new DOMRect(DO, vK.top, Math.max(MO - DO, 1), vK.height)
            })
          }), [KK, kK, pK, WO, nO]),
          FK = (0, XO.useCallback)((OO => KO => {
            if (0 !== KO.button) return;
            KO.stopPropagation(), JO(null), KK(), aK(), wO.current = {
              pointerId: KO.pointerId,
              track: OO
            }, KO.currentTarget.setPointerCapture(KO.pointerId);
            const pO = "detail" === OO ? pK(KO.clientX) : XK(KO.clientX);
            UO(pO, !1)
          }), [KK, aK, UO, pK, XK]),
          VK = (0, XO.useCallback)((OO => {
            const KO = wO.current;
            if (!KO || KO.pointerId !== OO.pointerId) return;
            OO.stopPropagation();
            const pO = "detail" === KO.track ? pK(OO.clientX) : XK(OO.clientX);
            UO(pO, !1)
          }), [UO, pK, XK]),
          LK = (0, XO.useCallback)((OO => {
            const KO = wO.current;
            KO && KO.pointerId === OO.pointerId && (OO.stopPropagation(), wO.current = null, OO.currentTarget.releasePointerCapture(OO.pointerId), OK())
          }), [OK]),
          QK = (0, XO.useCallback)((OO => {
            0 === OO.button && (KK(), aK(), iK.current = {
              pointerId: OO.pointerId
            }, OO.currentTarget.setPointerCapture(OO.pointerId), UO(XK(OO.clientX), !0))
          }), [KK, aK, UO, XK]),
          zp = (0, XO.useCallback)((OO => {
            const KO = iK.current;
            KO && KO.pointerId === OO.pointerId && UO(XK(OO.clientX), !0)
          }), [UO, XK]),
          AK = (0, XO.useCallback)((OO => {
            const KO = iK.current;
            KO && KO.pointerId === OO.pointerId && (iK.current = null, OO.currentTarget.releasePointerCapture(OO.pointerId), OK())
          }), [OK]),
          fK = (0, XO.useCallback)((OO => {
            const KO = Math.max(1, OO.endTick - OO.startTick + 1),
              pO = bK + 1,
              XO = pO / KO,
              eO = Math.max(1, Math.ceil(pO / XO)),
              lO = OO.startTick + Math.floor((eO - 1) / 2);
            uO.current = !0, EO.current = XO, sO(Tb(lO, bK)), NO(XO), KK()
          }), [KK, bK, NO]),
          dK = (0, XO.useCallback)((OO => {
            zK(OO), KK()
          }), [KK, zK]),
          TK = (0, XO.useCallback)((OO => {
            AO(OO), KK()
          }), [KK, AO]),
          NK = (0, XO.useCallback)((OO => {
            fO(OO), KK()
          }), [KK, fO]),
          IK = (0, XO.useCallback)((() => {
            dO(), KK()
          }), [KK, dO]);
        (0, XO.useEffect)((() => {
          const OO = IO.current;
          if (!OO) return () => {};
          const KO = KO => {
            KO.preventDefault();
            const pO = Tb(Ib(Eb(KO.clientX, OO), nO, WO), bK),
              XO = KO.deltaY < 0 ? "in" : "out",
              eO = ub(TO, XO);
            eO !== TO && (gK.current = !0, sO(pO), NO(eO))
          };
          return OO.addEventListener("wheel", KO, {
            passive: !1
          }), () => {
            OO.removeEventListener("wheel", KO)
          }
        }), [bK, NO, WO, nO, TO]);
        const yp = Nb(xK, nO, WO),
          gp = je(xK, bK),
          uK = je(nO, bK),
          EK = bK > 0 ? je(WO, bK) : 100,
          jp = null !== DO,
          YK = null !== (KO = null === DO || void 0 === DO ? void 0 : DO.inTick) && void 0 !== KO ? KO : 0,
          wK = null !== (pO = null === DO || void 0 === DO ? void 0 : DO.outTick) && void 0 !== pO ? pO : bK,
          ip = je(YK, bK),
          rp = Math.max(je(wK, bK) - ip, 0),
          PK = Nb(Math.max(YK, nO), nO, WO),
          mp = Nb(Math.min(wK, WO), nO, WO),
          sK = Math.max(mp - PK, 0),
          HK = jp && wK >= nO && YK <= WO,
          RK = Nb(YK, nO, WO),
          SK = Nb(wK, nO, WO),
          JK = jp && YK >= nO && YK <= WO,
          cp = jp && wK >= nO && wK <= WO,
          BK = je(YK, bK),
          ZK = je(wK, bK),
          GK = null !== cK && void 0 !== cK ? cK : ZO ? {
            startTick: ZO.startTick,
            endTick: ZO.endTick
          } : null,
          qp = GK ? Nb(Math.max(GK.startTick, nO), nO, WO) : 0,
          xp = GK ? Nb(Math.min(GK.endTick, WO), nO, WO) : 0,
          nK = Math.max(xp - qp, 0),
          WK = null !== GK && GK.endTick >= nO && GK.startTick <= WO,
          tp = (0, XO.useMemo)((() => Yb(0, bK, vK)), [bK, vK]),
          kp = (0, XO.useMemo)((() => Yb(nO, WO, vK)), [nO, WO, vK]),
          UK = (0, XO.useMemo)((() => bp.filter((OO => OO >= nO && OO <= WO))), [bp, WO, nO]),
          Op = (0, XO.useCallback)(((OO, KO, pO) => {
            const XO = "detail" === KO ? Nb(OO, nO, WO) : je(OO, bK),
              lO = null !== HO && pO === HO.fromTick,
              vK = null !== SO && SO.KK === pO;
            return (0, hO.jsx)("button", {
              type: "button",
              className: eO()("ReplayTimelineCameraKeyframeMarker", "detail" === KO ? "Detail" : "Overview", {
                Dragging: lO,
                Selected: vK
              }),
              style: {
                left: `${XO}%`
              },
              onPointerDown: CK(pO, KO),
              onPointerMove: hK,
              onPointerUp: DK,
              onPointerCancel: DK,
              "aria-label": `Camera keyframe at tick ${pO}`
            }, `cam-${KO}-${pO}`)
          }), [CK, SO, DK, HO, bK, hK, WO, nO]),
          Kp = (0, XO.useCallback)((OO => HO && OO === HO.previewTick ? HO.fromTick : OO), [HO]);
        return bK <= 0 ? null : (0, hO.jsxs)("div", {
          className: "ReplayTimeline",
          children: [SO && eK && (0, fb.createPortal)((0, hO.jsx)(xe, {
            keyframe: eK,
            anchor: SO,
            hasOutgoingSegment: lK,
            onClose: () => {
              JO(null)
            },
            onApply: VO,
            onDelete: LO,
            onUseCurrentCamera: QO
          }), document.body), ZO && (0, fb.createPortal)((0, hO.jsx)(nb, {
            anchor: ZO,
            hasPlaybackMark: jp,
            onClose: KK,
            onMark: dK,
            onZoom: fK,
            onCrop: TK,
            onDeleteKeyframes: NK,
            onClearMark: IK
          }), document.body), (0, hO.jsxs)("div", {
            className: eO()("ReplayTimelineOverviewSection", {
              Hidden: TO <= 1
            }),
            children: [(0, hO.jsx)("div", {
              className: "ReplayTimelineSectionLabel",
              children: "Overview"
            }), (0, hO.jsxs)("div", {
              ref: yK,
              className: "ReplayTimelineOverviewTrack",
              onPointerDown: QK,
              onPointerMove: zp,
              onPointerUp: AK,
              onPointerCancel: AK,
              role: "slider",
              "aria-label": "Recording overview",
              "aria-valuemin": 0,
              "aria-valuemax": bK,
              "aria-valuenow": xK,
              tabIndex: 0,
              children: [tp.map((OO => {
                const KO = je(OO, bK);
                return (0, hO.jsx)("div", {
                  className: "ReplayTimelineSecondMarker Overview",
                  style: {
                    left: `${KO}%`
                  }
                }, OO)
              })), jp && (0, hO.jsxs)(hO.Fragment, {
                children: [(0, hO.jsx)("div", {
                  className: "ReplayTimelineMarkRegion Overview",
                  style: {
                    left: `${ip}%`,
                    width: `${rp}%`
                  }
                }), (0, hO.jsx)("div", {
                  className: "ReplayTimelineMarkMarker In Overview",
                  style: {
                    left: `${BK}%`
                  },
                  "aria-hidden": !0
                }), (0, hO.jsx)("div", {
                  className: "ReplayTimelineMarkMarker Out Overview",
                  style: {
                    left: `${ZK}%`
                  },
                  "aria-hidden": !0
                })]
              }), bp.map((OO => Op(OO, "overview", Kp(OO)))), (0, hO.jsx)("div", {
                className: "ReplayTimelineViewport",
                style: {
                  left: `${uK}%`,
                  width: `${Math.max(EK-uK,.5)}%`
                }
              }), (0, hO.jsx)("button", {
                type: "button",
                className: eO()("ReplayTimelinePlayhead Overview", {
                  Scrubbing: null !== rK
                }),
                style: {
                  left: `${gp}%`
                },
                onPointerDown: FK("overview"),
                onPointerMove: VK,
                onPointerUp: LK,
                onPointerCancel: LK,
                "aria-label": "Scrub playhead"
              })]
            })]
          }), (0, hO.jsxs)("div", {
            className: "ReplayTimelineDetailSection",
            children: [(0, hO.jsxs)("div", {
              className: "ReplayTimelineDetailHeader",
              children: [(0, hO.jsx)("span", {
                className: "ReplayTimelineSectionLabel",
                children: "Timeline"
              }), (0, hO.jsxs)("span", {
                className: "ReplayTimelineDetailRange",
                children: [ye(nO, vK), " \u2013 ", ye(WO, vK), TO > 1 && (0, hO.jsx)("span", {
                  className: "ReplayTimelineZoomBadge",
                  children: ge(TO)
                })]
              })]
            }), (0, hO.jsxs)("div", {
              ref: IO,
              className: "ReplayTimelineDetailTrack",
              onPointerDown: MK,
              onPointerMove: ap,
              onPointerUp: oK,
              onPointerCancel: oK,
              role: "slider",
              "aria-label": "Recording timeline",
              "aria-valuemin": nO,
              "aria-valuemax": WO,
              "aria-valuenow": xK,
              tabIndex: 0,
              children: [kp.map((OO => {
                const KO = Nb(OO, nO, WO);
                return (0, hO.jsx)("div", {
                  className: "ReplayTimelineSecondMarker Detail",
                  style: {
                    left: `${KO}%`
                  }
                }, OO)
              })), HK && (0, hO.jsx)("div", {
                className: "ReplayTimelineMarkRegion Detail",
                style: {
                  left: `${PK}%`,
                  width: `${sK}%`
                }
              }), JK && (0, hO.jsx)("div", {
                className: "ReplayTimelineMarkMarker In Detail",
                style: {
                  left: `${RK}%`
                },
                "aria-label": `Play range start at tick ${YK}`
              }), cp && (0, hO.jsx)("div", {
                className: "ReplayTimelineMarkMarker Out Detail",
                style: {
                  left: `${SK}%`
                },
                "aria-label": `Play range end at tick ${wK}`
              }), WK && GK && (0, hO.jsx)("div", {
                className: "ReplayTimelineSelectionRegion Detail",
                style: {
                  left: `${qp}%`,
                  width: `${nK}%`
                }
              }), UK.map((OO => Op(OO, "detail", Kp(OO)))), (0, hO.jsx)("button", {
                type: "button",
                className: eO()("ReplayTimelinePlayhead Detail", {
                  Scrubbing: null !== rK
                }),
                style: {
                  left: `${yp}%`
                },
                onPointerDown: FK("detail"),
                onPointerMove: VK,
                onPointerUp: LK,
                onPointerCancel: LK,
                "aria-label": "Scrub playhead"
              })]
            }), (0, hO.jsxs)("div", {
              className: "ReplayTimelineWheelHint",
              children: [(0, hO.jsx)("span", {
                className: "Select",
                children: "Drag timeline to select"
              }), " \xb7 Scroll to zoom \xb7 Drag playhead to scrub"]
            })]
          })]
        })
      })),
      te = (0, XO.memo)((function(OO) {
        let {
          enabled: KO
        } = OO;
        const pO = (0, XO.useRef)(!1),
          bK = (0, XO.useRef)(null),
          [lO, vK] = (0, XO.useState)(!1),
          CO = (0, XO.useCallback)((OO => {
            KO && 0 === OO.button && (pO.current = !0, vK(!0), bK.current = {
              x: OO.clientX,
              y: OO.clientY
            }, OO.currentTarget.setPointerCapture(OO.pointerId))
          }), [KO]),
          DO = (0, XO.useCallback)((OO => {
            if (!KO || !pO.current || !bK.current) return;
            const XO = OO.clientX - bK.current.x,
              eO = OO.clientY - bK.current.y;
            bK.current = {
              x: OO.clientX,
              y: OO.clientY
            }, aK.gameBridge.send("dragReplayCamera", {
              dx: XO,
              dy: eO
            })
          }), [KO]),
          MO = (0, XO.useCallback)((OO => {
            pO.current && (pO.current = !1, vK(!1), bK.current = null, OO.currentTarget.releasePointerCapture(OO.pointerId))
          }), []);
        return KO ? (0, hO.jsx)("div", {
          className: eO()("ReplayViewerCameraDragSurface", {
            Dragging: lO
          }),
          onPointerDown: CO,
          onPointerMove: DO,
          onPointerUp: MO,
          onPointerCancel: MO,
          "aria-hidden": !0
        }) : null
      }));
    var ke = pO(35463),
      Ub = pO(35470);
    const Oe = (0, XO.memo)((function(OO) {
        var KO, pO, bK;
        let {
          anchorRect: lO,
          anchorRef: CO,
          onClose: DO
        } = OO;
        const MO = (0, XO.useRef)(null),
          aK = Zb(MO, lO),
          [oO, FO] = (0, XO.useState)(Ub.e),
          VO = (0, XO.useMemo)((() => Object.values(oO).every((OO => OO))), [oO]);
        (0, vK.f)("replayViewer|uiVisibilityChanged", (() => {
          FO((0, Ub.e)())
        })), Gb(MO, DO, CO);
        const LO = (0, XO.useCallback)(((OO, KO) => {
            (0, Ub.k)(OO, KO), FO((0, Ub.e)())
          }), []),
          QO = (0, XO.useCallback)((OO => {
            for (const {
                group: KO
              }
              of ke.h)(0, Ub.k)(KO, OO);
            FO((0, Ub.e)())
          }), []),
          zK = Bb(lO);
        return (0, fb.createPortal)((0, hO.jsxs)("div", {
          ref: MO,
          className: eO()("ReplayViewerPopover ReplayUiVisibilityPopover", {
            Below: null !== (KO = null === aK || void 0 === aK ? void 0 : aK.placeBelow) && void 0 !== KO && KO,
            Positioned: null !== aK
          }),
          style: {
            left: `${null!==(pO=null===aK||void 0===aK?void 0:aK.left)&&void 0!==pO?pO:zK.left}px`,
            top: `${null!==(bK=null===aK||void 0===aK?void 0:aK.top)&&void 0!==bK?bK:zK.top}px`
          },
          onPointerDown: OO => {
            OO.stopPropagation()
          },
          children: [(0, hO.jsx)("div", {
            className: "ReplayUiVisibilityPopoverHeader",
            children: (0, hO.jsx)("span", {
              className: "ReplayUiVisibilityPopoverTitle",
              children: "UI visibility"
            })
          }), (0, hO.jsxs)("div", {
            className: "ReplayUiVisibilityPopoverChecks",
            children: [(0, hO.jsxs)("div", {
              className: "ReplayUiVisibilityPopoverCheck",
              children: [(0, hO.jsx)("input", {
                type: "checkbox",
                checked: VO,
                onChange: OO => {
                  QO(OO.target.checked)
                }
              }), (0, hO.jsx)("span", {
                children: "SELECT ALL"
              })]
            }), ke.h.map((OO => {
              let {
                group: KO,
                label: pO
              } = OO;
              return (0, hO.jsxs)("label", {
                className: "ReplayUiVisibilityPopoverCheck",
                children: [(0, hO.jsx)("input", {
                  type: "checkbox",
                  checked: oO[KO],
                  onChange: OO => {
                    LO(KO, OO.target.checked)
                  }
                }), (0, hO.jsx)("span", {
                  children: pO
                })]
              }, KO)
            }))]
          })]
        }), document.body)
      })),
      Ke = (0, XO.memo)((function(OO) {
        let {
          disabled: KO
        } = OO;
        const pO = (0, XO.useRef)(null),
          [bK, eO] = (0, XO.useState)(!1),
          [lO, vK] = (0, XO.useState)(null),
          CO = (0, XO.useCallback)((() => {
            pO.current && (vK(pO.current.getBoundingClientRect()), eO((OO => !OO)))
          }), []),
          DO = (0, XO.useCallback)((() => {
            eO(!1)
          }), []);
        return (0, hO.jsxs)(hO.Fragment, {
          children: [(0, hO.jsx)("div", {
            ref: pO,
            children: (0, hO.jsx)(qp.d, {
              className: "ReplayViewerActionButton",
              onClick: CO,
              disabled: KO,
              children: (0, hO.jsx)("span", {
                children: "Hide UI elements"
              })
            })
          }), bK && lO && (0, hO.jsx)(Oe, {
            anchorRect: lO,
            anchorRef: pO,
            onClose: DO
          })]
        })
      })),
      pe = ["freeCamUp", "freeCamDown"];

    function Xe(OO, KO) {
      aK.gameBridge.send("holdReplayFreecamVertical", {
        action: OO,
        JK: KO
      })
    }
    const bl = (0, XO.memo)((function() {
        (0, XO.useEffect)((() => () => {
          ! function() {
            aK.gameBridge.send("moveReplayFreecam", null);
            for (const OO of pe) Xe(OO, !1)
          }()
        }), []);
        const OO = (0, XO.useCallback)((OO => {
            aK.gameBridge.send("moveReplayFreecam", OO)
          }), []),
          KO = (0, XO.useCallback)((OO => ({
            onTouchStart: KO => {
              KO.preventDefault(), KO.stopPropagation(), Xe(OO, !0)
            },
            onTouchEnd: KO => {
              KO.preventDefault(), KO.stopPropagation(), Xe(OO, !1)
            },
            onTouchCancel: KO => {
              KO.preventDefault(), KO.stopPropagation(), Xe(OO, !1)
            }
          })), []);
        return (0, hO.jsxs)("div", {
          className: "ReplayFreecamTouchControls",
          children: [(0, hO.jsx)("div", {
            className: "ReplayFreecamJoystickWrap",
            children: (0, hO.jsx)(pK, {
              onMove: OO,
              mode: "pinned"
            })
          }), (0, hO.jsxs)("div", {
            className: "ReplayFreecamVerticalButtons",
            children: [(0, hO.jsx)("button", {
              type: "button",
              className: "ReplayFreecamVerticalButton",
              "aria-label": "Freecam up",
              ...KO("freeCamUp"),
              children: (0, hO.jsx)(TO.d, {
                name: "arrow-up",
                className: "ReplayFreecamVerticalIcon"
              })
            }), (0, hO.jsx)("button", {
              type: "button",
              className: "ReplayFreecamVerticalButton",
              "aria-label": "Freecam down",
              ...KO("freeCamDown"),
              children: (0, hO.jsx)(TO.d, {
                name: "angle-down",
                className: "ReplayFreecamVerticalIcon"
              })
            })]
          })]
        })
      })),
      ee = [],
      le = (0, XO.memo)((function() {
        const OO = (0, PO.l)();
        return (0, rK.b)("replayViewerRequested", (OO => {
          (0, PO.i)("toggle" === OO ? !(0, PO.h)() : "open" === OO)
        })), OO ? (0, hO.jsx)(vl, {}) : null
      })),
      vl = (0, XO.memo)((function() {
        var OO, KO, pO, bK, lO, vK, CO, DO, MO, oO, FO, VO;
        const LO = XO.useRef(null),
          [QO, zK] = (0, XO.useState)(null),
          [fO, dO] = (0, XO.useState)(1),
          [NO, IO] = (0, XO.useState)(null),
          [yK, gK] = (0, XO.useState)(!1),
          {
            isTouchScreen: uO
          } = (0, iK.l)(["isTouchScreen"]),
          EO = (0, rK.i)("replay"),
          jK = (0, rK.i)("replayEdits"),
          YO = null !== EO,
          wO = null !== (OO = null === EO || void 0 === EO ? void 0 : EO.KK) && void 0 !== OO ? OO : 0,
          mK = null !== (KO = null === EO || void 0 === EO ? void 0 : EO.totalTicks) && void 0 !== KO ? KO : 0,
          sO = Math.max(0, mK - 1),
          HO = null !== (pO = null === EO || void 0 === EO ? void 0 : EO.playing) && void 0 !== pO && pO,
          RO = null !== (bK = null === EO || void 0 === EO ? void 0 : EO.speed) && void 0 !== bK ? bK : 1,
          SO = null !== (lO = null === EO || void 0 === EO ? void 0 : EO.RKO) && void 0 !== lO ? lO : 20,
          JO = null !== NO && void 0 !== NO ? NO : wO,
          cK = null !== (vK = null === EO || void 0 === EO ? void 0 : EO.freecam) && void 0 !== vK && vK,
          BO = null !== (CO = null === EO || void 0 === EO ? void 0 : EO.cameraMode) && void 0 !== CO ? CO : "recording",
          ZO = null !== (DO = null === jK || void 0 === jK ? void 0 : jK.cameraKeyframes) && void 0 !== DO ? DO : ee,
          GO = null !== (MO = null === jK || void 0 === jK ? void 0 : jK.playbackMark) && void 0 !== MO ? MO : null,
          qK = null !== (oO = null === jK || void 0 === jK ? void 0 : jK.fileName) && void 0 !== oO ? oO : null,
          xK = null !== (FO = null === jK || void 0 === jK ? void 0 : jK.unsavedChanges) && void 0 !== FO && FO,
          nO = null !== (VO = null === jK || void 0 === jK ? void 0 : jK.suggestSaveAs) && void 0 !== VO && VO,
          WO = (0, rK.i)("replayVideoExporting"),
          tK = !WO && YO && ("freecam" === BO || ("recording" === BO || "keyframe" === BO) && !HO),
          kK = uO && YO && "freecam" === BO && !WO && !yK;
        (0, Ab.b)(!0, !0, "ReplayViewerOverlay"), (0, XO.useEffect)((() => {
          aK.gameBridge.send("syncReplayCameraMode", null)
        }), [cK]);
        const UO = (0, XO.useCallback)(((OO, KO) => {
            aK.gameBridge.send("seekReplay", {
              KK: OO,
              ignorePlaybackMark: null === KO || void 0 === KO ? void 0 : KO.ignorePlaybackMark
            })
          }), []),
          OK = (0, XO.useCallback)((() => {
            aK.gameBridge.send("setReplayPlaying", !1)
          }), []),
          KK = (0, XO.useCallback)(((OO, KO) => {
            aK.gameBridge.send("moveReplayCameraKeyframe", {
              from: OO,
              to: KO
            })
          }), []),
          pK = (0, XO.useCallback)((OO => {
            aK.gameBridge.send("setReplayCameraKeyframe", OO)
          }), []),
          XK = (0, XO.useCallback)((OO => {
            aK.gameBridge.send("deleteReplayCameraKeyframes", {
              start: OO,
              end: OO
            })
          }), []),
          bp = (0, XO.useCallback)((OO => {
            aK.gameBridge.send("deleteReplayCameraKeyframes", {
              start: OO.startTick,
              end: OO.endTick
            })
          }), []),
          eK = (0, XO.useCallback)((() => aK.gameBridge.lookup("replayCamera", null)), []),
          lK = (0, XO.useCallback)((OO => {
            IO(OO)
          }), []),
          vp = (0, XO.useCallback)((OO => {
            aK.gameBridge.send("setReplayPlaybackMark", {
              inTick: OO.startTick,
              outTick: OO.endTick
            })
          }), []),
          CK = (0, XO.useCallback)((() => {
            aK.gameBridge.send("setReplayPlaybackMark", null)
          }), []),
          hK = (0, XO.useCallback)((OO => {
            const KO = aK.gameBridge.latest("replay");
            if (null === KO || OO.endTick <= OO.startTick) return;
            const pO = OO.startTick,
              XO = OO.endTick;
            VX.NotificationProvider.showPromptPopup({
              title: "Crop recording to the selected range? This cannot be undone.",
              confirmText: "Crop",
              destructive: !0,
              cancelText: "Cancel"
            }).getResult().then((OO => {
              var bK;
              if (!0 !== OO) return;
              if ((null === (bK = aK.gameBridge.latest("replay")) || void 0 === bK ? void 0 : bK.id) !== KO.id) return;
              aK.gameBridge.send("cropReplay", {
                start: pO,
                end: XO
              }) && (IO(null), dO(1))
            }))
          }), []),
          DK = (0, XO.useCallback)(((OO, KO) => {
            zK(null), dO(1), IO(null), (0, Db.d)().open(OO, KO).catch((OO => {
              console.error(OO), zK(OO instanceof Error ? OO.message : "Failed to parse recording")
            }))
          }), []),
          MK = (0, XO.useCallback)(((OO, KO) => {
            null !== aK.gameBridge.latest("connectedGame").websocketUrl ? VX.NotificationProvider.showPromptPopup({
              title: "Leave current game and play recording?",
              confirmText: "Yes",
              cancelText: "No"
            }).getResult().then((pO => {
              !0 === pO && DK(OO, KO)
            })) : DK(OO, KO)
          }), [DK]),
          ap = (0, XO.useCallback)((OO => {
            var KO;
            const pO = null === (KO = OO.target.files) || void 0 === KO ? void 0 : KO[0];
            if (OO.target.value = "", !pO) return;
            const XO = new FileReader;
            XO.onload = () => {
              MK(new Uint8Array(XO.result), {
                fileName: pO.name
              })
            }, XO.onerror = () => {
              zK("Failed to read file")
            }, XO.readAsArrayBuffer(pO)
          }), [MK]),
          oK = (0, XO.useCallback)((() => {
            const OO = () => {
              var OO;
              null === (OO = LO.current) || void 0 === OO || OO.click()
            };
            (0, ob.k)() ? (0, ob.f)().then((OO => {
              OO && MK(OO.bytes, {
                fileHandle: OO.handle
              })
            })).catch((KO => {
              console.error(KO), OO()
            })): OO()
          }), [MK]),
          FK = (0, XO.useCallback)((async function() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            let KO;
            try {
              KO = await ze(OO, {
                files: (0, Db.d)(),
                pickerSupported: ob.k,
                chooseFile: ob.e,
                write: ob.l,
                download: ae.j,
                onFallback: console.error
              })
            } catch (pO) {
              return void(OO => {
                console.error(OO), VX.NotificationProvider.showAlertPopup({
                  title: "Failed to save recording",
                  subtitle: Vb(OO),
                  confirmText: "OK"
                })
              })(pO)
            }
            "written" !== KO && "downloaded" !== KO || (() => {
              const OO = VX.NotificationProvider.showAlertPopup({
                title: "Recording saved",
                disableBackground: !0
              });
              setTimeout((() => {
                OO.tearDownNotification()
              }), 1e3)
            })()
          }), []),
          VK = (0, XO.useCallback)((OO => {
            aK.gameBridge.send("replayAction", OO)
          }), []),
          LK = (0, XO.useCallback)((OO => {
            dO((KO => ub(KO, OO)))
          }), []),
          QK = (0, XO.useCallback)((OO => {
            if (!aK.gameBridge.latest("replayVideoExporting")) switch (OO) {
              case "replayLoad":
                oK();
                break;
              case "replaySave":
                FK(!1);
                break;
              case "replaySaveAs":
                FK(!0);
                break;
              case "replayTimelineZoomIn":
                LK("in");
                break;
              case "replayTimelineZoomOut":
                LK("out")
            }
          }), [oK, FK, LK]);
        (0, rK.b)("replayUiActionRequested", QK);
        const zp = (0, XO.useCallback)((OO => {
            aK.gameBridge.send("setReplayCameraMode", OO)
          }), []),
          AK = YO ? qp.d : qp.m,
          fK = xK && !nO ? qp.m : qp.d,
          dK = xK && nO ? qp.m : qp.d;
        return (0, hO.jsxs)("div", {
          className: "ReplayViewerOverlay",
          children: [(0, hO.jsx)(te, {
            enabled: tK
          }), kK && (0, hO.jsx)(bl, {}), (0, hO.jsx)("input", {
            ref: LO,
            type: "file",
            accept: ae.e,
            className: "ReplayViewerFileInput",
            onChange: ap
          }), (0, hO.jsxs)("div", {
            className: eO()("ReplayViewerBar", {
              Collapsed: yK
            }),
            children: [(0, hO.jsx)("button", {
              type: "button",
              className: "ReplayViewerCollapseTab",
              onClick: () => {
                yK ? gK(!1) : YO ? gK(!0) : (0, PO.e)()
              },
              "aria-expanded": !yK,
              "aria-label": yK ? "Expand replay viewer" : "Collapse replay viewer",
              children: (0, hO.jsx)(TO.d, {
                name: yK ? "angle-up" : "angle-down"
              })
            }), !yK && (0, hO.jsxs)("div", {
              className: "ReplayViewerBarBody",
              children: [YO && mK > 0 && (0, hO.jsx)(Wb, {
                maxTick: sO,
                displayTick: JO,
                RKO: SO,
                cameraKeyframes: ZO,
                playbackMark: GO,
                onSeek: UO,
                onPause: OK,
                onScrubTickChange: lK,
                onMoveCameraKeyframe: KK,
                onUpdateCameraKeyframe: pK,
                onDeleteCameraKeyframe: XK,
                onUseCurrentCamera: eK,
                onMarkRange: vp,
                onCropRange: hK,
                onDeleteKeyframesInRange: bp,
                onClearMark: CK,
                zoomLevel: fO,
                onZoomLevelChange: dO
              }, sO), (0, hO.jsxs)("div", {
                className: "ReplayViewerControls",
                children: [(0, hO.jsxs)("div", {
                  className: "ReplayViewerControlsLeftSide",
                  children: [(0, hO.jsxs)("div", {
                    className: "ReplayViewerControlsGroup FileGroup",
                    children: [YO && (0, hO.jsxs)("div", {
                      className: "ReplayViewerFileName",
                      children: [null !== qK && void 0 !== qK ? qK : "Unsaved recording", xK ? " *" : ""]
                    }), (0, hO.jsxs)(AK, {
                      className: "ReplayViewerActionButton",
                      onClick: () => {
                        QK("replayLoad")
                      },
                      children: [(0, hO.jsx)(qb.d, {
                        noaAction: "replayLoad",
                        padHidesKey: !0
                      }), (0, hO.jsx)("span", {
                        children: " Load "
                      })]
                    }), (0, hO.jsxs)(qp.d, {
                      className: "ReplayViewerActionButton",
                      onClick: PO.e,
                      children: [(0, hO.jsx)(qb.d, {
                        noaAction: "replayViewerOpen",
                        padHidesKey: !0
                      }), (0, hO.jsx)("span", {
                        children: " Hide "
                      })]
                    }), (0, hO.jsxs)(fK, {
                      className: "ReplayViewerActionButton",
                      onClick: () => {
                        QK("replaySave")
                      },
                      disabled: !YO,
                      children: [(0, hO.jsx)(qb.d, {
                        noaAction: "replaySave",
                        padHidesKey: !0
                      }), (0, hO.jsx)("span", {
                        children: " Save "
                      })]
                    }), (0, hO.jsxs)(qp.d, {
                      className: "ReplayViewerActionButton",
                      onClick: () => {
                        aK.gameBridge.send("leaveGame", {
                          reloadPath: "/"
                        })
                      },
                      disabled: !YO,
                      children: [(0, hO.jsx)(qb.d, {
                        noaAction: "replayExit",
                        padHidesKey: !0
                      }), (0, hO.jsx)("span", {
                        children: " Exit "
                      })]
                    }), (0, hO.jsxs)(dK, {
                      className: "ReplayViewerActionButton",
                      onClick: () => {
                        QK("replaySaveAs")
                      },
                      disabled: !YO,
                      children: [(0, hO.jsx)(qb.d, {
                        noaAction: "replaySaveAs",
                        padHidesKey: !0
                      }), (0, hO.jsx)("span", {
                        children: " Save As "
                      })]
                    }), (0, hO.jsxs)(qp.d, {
                      className: "ReplayViewerActionButton",
                      onClick: () => {
                        aK.gameBridge.send("exportReplayVideo", null)
                      },
                      disabled: !YO || 0 === mK || WO,
                      children: [(0, hO.jsx)(qb.d, {
                        noaAction: "replayExportVideo",
                        padHidesKey: !0
                      }), (0, hO.jsx)("span", {
                        children: " Export "
                      })]
                    })]
                  }), (0, hO.jsxs)("div", {
                    className: "ReplayViewerControlBox",
                    children: [(0, hO.jsxs)("span", {
                      className: "ReplayViewerControlBoxLabel",
                      children: [(0, hO.jsx)("span", {
                        children: " Camera Mode "
                      }), (0, hO.jsx)(qb.d, {
                        noaAction: "replayChangeCameraMode",
                        padHidesKey: !0
                      })]
                    }), (0, hO.jsxs)("div", {
                      className: "ReplayViewerControlBoxBody CameraModes",
                      children: [(0, hO.jsx)(AO.g, {
                        tooltipInner: (0, hO.jsx)("div", {
                          className: "ReplayTooltip",
                          children: "Replicate how the camera was set when recorded."
                        }),
                        children: (0, hO.jsxs)(qp.S, {
                          className: "ReplayViewerModeButton",
                          active: "recording" === BO,
                          onClick: () => {
                            zp("recording")
                          },
                          disabled: !YO,
                          children: ["Recorded ", (0, hO.jsx)(TO.d, {
                            name: "circle-info"
                          })]
                        })
                      }), (0, hO.jsx)(AO.g, {
                        tooltipInner: (0, hO.jsx)("div", {
                          className: "ReplayTooltip",
                          children: "Move the camera freely around."
                        }),
                        children: (0, hO.jsxs)(qp.S, {
                          className: "ReplayViewerModeButton",
                          active: "freecam" === BO,
                          onClick: () => {
                            zp("freecam")
                          },
                          disabled: !YO,
                          children: ["Free ", (0, hO.jsx)(TO.d, {
                            name: "circle-info"
                          })]
                        })
                      }), (0, hO.jsx)(AO.g, {
                        tooltipInner: (0, hO.jsx)("div", {
                          className: "ReplayTooltip",
                          children: "Display the replay in real time using keyframes."
                        }),
                        children: (0, hO.jsxs)(qp.S, {
                          className: "ReplayViewerModeButton",
                          active: "keyframe" === BO,
                          onClick: () => {
                            zp("keyframe")
                          },
                          disabled: !YO,
                          children: ["Preview ", (0, hO.jsx)(TO.d, {
                            name: "circle-info"
                          })]
                        })
                      })]
                    })]
                  })]
                }), (0, hO.jsxs)("div", {
                  className: "ReplayViewerControlsGroup TimeGroup",
                  children: [(0, hO.jsxs)("div", {
                    className: "ReplayViewerTimecodeContainer",
                    children: [(0, hO.jsxs)("span", {
                      className: "ReplayViewerTimecode",
                      children: [(0, hO.jsx)("span", {
                        className: "ReplayViewerTimecodeNow",
                        children: ye(JO, SO)
                      }), (0, hO.jsx)("span", {
                        className: "ReplayViewerTimecodeDivider",
                        children: "/"
                      }), (0, hO.jsx)("span", {
                        className: "ReplayViewerTimecodeTotal",
                        children: ye(sO, SO)
                      })]
                    }), (0, hO.jsxs)("span", {
                      className: "ReplayViewerTickLabel",
                      children: ["Tick ", JO, " / ", sO]
                    })]
                  }), (0, hO.jsxs)("div", {
                    className: "ReplayViewerTimecodeControls",
                    children: [(0, hO.jsxs)(qp.d, {
                      className: "ReplayViewerMediaButton SkipButton",
                      onClick: () => {
                        VK("replaySkipBack")
                      },
                      disabled: !YO,
                      children: [(0, hO.jsxs)("span", {
                        children: [" ", (0, hO.jsx)(TO.d, {
                          name: "clock-rotate-left"
                        }), " 1s"]
                      }), (0, hO.jsx)(qb.d, {
                        noaAction: "replaySkipBack",
                        padHidesKey: !0
                      })]
                    }), (0, hO.jsxs)(qp.m, {
                      className: "ReplayViewerMediaButton PlayButton",
                      onClick: () => {
                        aK.gameBridge.send("setReplayPlaying", !HO)
                      },
                      disabled: !YO,
                      children: [(0, hO.jsxs)("span", {
                        children: [" ", HO ? (0, hO.jsx)(TO.d, {
                          name: "pause"
                        }) : (0, hO.jsx)(TO.d, {
                          name: "play"
                        }), " "]
                      }), (0, hO.jsx)(qb.d, {
                        noaAction: "replayPlayPause",
                        padHidesKey: !0
                      })]
                    }), (0, hO.jsxs)(qp.d, {
                      className: "ReplayViewerMediaButton SkipButton",
                      onClick: () => {
                        VK("replaySkipForward")
                      },
                      disabled: !YO,
                      children: [(0, hO.jsxs)("span", {
                        children: [" ", (0, hO.jsx)(TO.d, {
                          name: "rotate-forward"
                        }), " 1s"]
                      }), (0, hO.jsx)(qb.d, {
                        noaAction: "replaySkipForward",
                        padHidesKey: !0
                      })]
                    })]
                  })]
                }), (0, hO.jsxs)("div", {
                  className: "ReplayViewerControlsRightSide",
                  children: [(0, hO.jsxs)("div", {
                    className: "ReplayViewerControlsGroup RecordKeyframeGroup",
                    children: [(0, hO.jsxs)(qp.m, {
                      className: "ReplayViewerActionButton",
                      onClick: () => {
                        VK("replayRecordKeyframe")
                      },
                      disabled: !YO,
                      children: [(0, hO.jsx)(qb.d, {
                        noaAction: "replayRecordKeyframe",
                        padHidesKey: !0
                      }), (0, hO.jsx)("span", {
                        children: " Record keyframe "
                      })]
                    }), (0, hO.jsx)(Ke, {
                      disabled: !YO
                    }), GO && (0, hO.jsx)(qp.S, {
                      className: "ReplayViewerActionButton",
                      onClick: CK,
                      disabled: !YO,
                      children: (0, hO.jsx)("span", {
                        children: " Clear range "
                      })
                    })]
                  }), (0, hO.jsxs)("div", {
                    className: "ReplayViewerControlBox",
                    children: [(0, hO.jsx)("span", {
                      className: "ReplayViewerControlBoxLabel",
                      children: "Speed"
                    }), (0, hO.jsxs)("div", {
                      className: "ReplayViewerControlBoxBody",
                      children: [(0, hO.jsx)(qp.d, {
                        className: "ReplayViewerMediaButton Compact",
                        onClick: () => {
                          VK("replaySpeedDown")
                        },
                        disabled: !YO || (0, Mb.d)(RO),
                        children: (0, hO.jsx)("span", {
                          children: " \u2212 "
                        })
                      }), (0, hO.jsxs)("span", {
                        className: "ReplayViewerControlBoxValue",
                        children: [RO, "\xd7"]
                      }), (0, hO.jsx)(qp.d, {
                        className: "ReplayViewerMediaButton Compact",
                        onClick: () => {
                          VK("replaySpeedUp")
                        },
                        disabled: !YO || (0, Mb.c)(RO),
                        children: (0, hO.jsx)("span", {
                          children: " + "
                        })
                      })]
                    })]
                  }), (0, hO.jsxs)("div", {
                    className: "ReplayViewerControlBox",
                    children: [(0, hO.jsx)("span", {
                      className: "ReplayViewerControlBoxLabel",
                      children: "Timeline Zoom"
                    }), (0, hO.jsxs)("div", {
                      className: "ReplayViewerControlBoxBody",
                      children: [(0, hO.jsxs)(qp.d, {
                        className: "ReplayViewerMediaButton Compact",
                        onClick: () => {
                          QK("replayTimelineZoomOut")
                        },
                        disabled: !YO || fO <= db[0],
                        children: [(0, hO.jsx)("span", {
                          children: " \u2212 "
                        }), (0, hO.jsx)(qb.d, {
                          noaAction: "replayTimelineZoomOut",
                          padHidesKey: !0
                        })]
                      }), (0, hO.jsx)("span", {
                        className: "ReplayViewerControlBoxValue",
                        children: ge(fO)
                      }), (0, hO.jsxs)(qp.d, {
                        className: "ReplayViewerMediaButton Compact",
                        onClick: () => {
                          QK("replayTimelineZoomIn")
                        },
                        disabled: !YO || fO >= db[db.length - 1],
                        children: [(0, hO.jsx)("span", {
                          children: " + "
                        }), (0, hO.jsx)(qb.d, {
                          noaAction: "replayTimelineZoomIn",
                          padHidesKey: !0
                        })]
                      })]
                    })]
                  })]
                })]
              }), (0, hO.jsx)("div", {
                className: "ReplayViewerEmptyState",
                children: !YO && "Load a recording to begin playback"
              }), QO && (0, hO.jsx)("div", {
                className: "ReplayViewerError",
                children: QO
              })]
            })]
          })]
        })
      }));
    var Ce = pO(1163);

    function he() {
      const [, OO] = (0, XO.useState)(0);
      return (0, vK.f)("replayViewer|uiVisibilityChanged", (() => {
          OO((OO => OO + 1))
        })), (0, vK.f)("replayViewer|replayLoaded", (() => {
          OO((OO => OO + 1))
        })),
        function() {
          if (!(0, Ce.f)()) return {};
          const OO = {
              [ke.d]: "true"
            },
            KO = (0, Ub.e)();
          for (const {
              group: pO,
              dataAttr: XO
            }
            of ke.h) XO && !KO[pO] && (OO[XO] = "true");
          return OO
        }()
    }
    var De = pO(8303),
      Me = pO(1643),
      al = pO(7800),
      oe = pO(7789),
      Fe = pO(1659);
    const Ve = (0, XO.memo)((function() {
      var OO, KO, pO;
      const bK = (0, zK.i)("customButtons");
      (0, XO.useEffect)((() => bK ? (aK.gameBridge.send("bindCustomButtonKeys", bK.filter(al.f).map((OO => {
        let {
          id: KO,
          keycode: pO
        } = OO;
        return {
          id: KO,
          keycode: pO
        }
      }))), () => {
        aK.gameBridge.send("bindCustomButtonKeys", [])
      }) : () => {}), [bK]);
      const eO = null !== (OO = null === bK || void 0 === bK ? void 0 : bK.filter(al.f)) && void 0 !== OO ? OO : [],
        lO = (0, oe.i)(),
        vK = null !== (KO = null === (pO = (0, Fe.e)()) || void 0 === pO ? void 0 : pO.hideButtonHints) && void 0 !== KO && KO,
        CO = "customButton" !== (null === lO || void 0 === lO ? void 0 : lO.kind) || vK ? null : lO.id,
        DO = eO.length > 0,
        MO = (0, XO.useRef)(null);
      return (0, XO.useLayoutEffect)((() => {
        if (!DO) return () => {};
        const OO = MO.current,
          KO = OO.closest(".InGameUi"),
          pO = () => {
            KO.style.setProperty("--custom-buttons-top", `${OO.offsetTop}px`)
          };
        pO();
        const XO = new ResizeObserver(pO);
        return XO.observe(OO), XO.observe(OO.parentElement), () => {
          XO.disconnect(), KO.style.removeProperty("--custom-buttons-top")
        }
      }), [DO]), (0, hO.jsx)("div", {
        ref: MO,
        className: "" + ((0, wX.isMobile)() ? "CustomIconsMobile" : "CustomIcons"),
        children: eO.map((OO => {
          var KO, pO;
          return (0, hO.jsx)(Le, {
            button: OO,
            padGlyph: OO.id === CO && null !== (KO = null === (pO = (0, gK.g)()) || void 0 === pO ? void 0 : pO.getBoundButton("actionButton")) && void 0 !== KO ? KO : null
          }, OO.id)
        }))
      })
    }));

    function Le(OO) {
      let {
        button: KO,
        padGlyph: pO
      } = OO;
      const bK = (0, XO.useRef)(null),
        eO = () => {
          null !== bK.current && (bK.current = null, aK.gameBridge.send("pressCustomButton", {
            id: KO.id,
            down: !1
          }))
        };
      (0, XO.useEffect)((() => eO), []);
      const lO = DK(eO, {
          pressesOnPointerDown: !0
        }),
        vK = OO => {
          bK.current === OO.pointerId && eO()
        };
      return (0, hO.jsxs)("div", {
        className: "CustomIcon",
        ...lO,
        onLostPointerCapture: vK,
        children: [(0, hO.jsx)(Me.c, {
          icon: KO.icon,
          keyboardHint: (0, al.e)(KO.keycode),
          padGlyph: pO,
          onPointerDown: OO => {
            OO.currentTarget.setPointerCapture(OO.pointerId), null === bK.current && aK.gameBridge.send("pressCustomButton", {
              id: KO.id,
              down: !0
            }), bK.current = OO.pointerId
          },
          onPointerUp: vK,
          onPointerCancel: vK,
          showTouchTutorialPubSubId: !1,
          showRedDotPubSubId: !1
        }), KO.description && (0, hO.jsx)("div", {
          className: "CustomIconDescription SmallTextBold",
          children: KO.description
        })]
      })
    }
    var Qe = pO(1984),
      zl = pO(35105),
      Ae = pO(8336);
    const fe = {
      frame: OO => {
        const KO = requestAnimationFrame((() => {
          OO()
        }));
        return () => {
          cancelAnimationFrame(KO)
        }
      },
      afterFrame: OO => {
        const KO = setTimeout(OO, 0);
        return () => {
          clearTimeout(KO)
        }
      }
    };
    class de {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ae.b,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : fe;
        this.idle = OO, this.frames = KO, this.waiting = [], this.cancelIdle = null, this.cancelFrame = null, this.cancelAfterFrame = null, this.starvedFrames = 0, this.shown = !1
      }
      request(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return this.shown ? (OO(), () => {}) : (KO ? this.waiting.unshift(OO) : this.waiting.push(OO), this.schedule(), () => {
          const KO = this.waiting.indexOf(OO);
          KO >= 0 && (this.waiting.splice(KO, 1), this.settle())
        })
      }
      show() {
        for (this.shown = !0; this.waiting.length > 0;) this.mountNext()
      }
      schedule() {
        0 !== this.waiting.length && (this.cancelIdle ??= this.idle((OO => {
          for (this.cancelIdle = null; this.waiting.length > 0 && OO.timeRemaining() >= 8;) this.mountNext();
          this.schedule()
        })), this.cancelFrame ??= this.frames.frame((() => {
          this.cancelFrame = null, this.starvedFrames++, this.starvedFrames >= 4 && (this.cancelAfterFrame ??= this.frames.afterFrame((() => {
            this.cancelAfterFrame = null, this.mountNext(), this.schedule()
          }))), this.schedule()
        })))
      }
      mountNext() {
        this.starvedFrames = 0;
        const OO = this.waiting.shift();
        try {
          OO()
        } finally {
          this.settle()
        }
      }
      settle() {
        0 === this.waiting.length && this.stop()
      }
      stop() {
        var OO, KO, pO;
        null === (OO = this.cancelIdle) || void 0 === OO || OO.call(this), this.cancelIdle = null, null === (KO = this.cancelFrame) || void 0 === KO || KO.call(this), this.cancelFrame = null, null === (pO = this.cancelAfterFrame) || void 0 === pO || pO.call(this), this.cancelAfterFrame = null
      }
    }
    const Te = (0, XO.createContext)(null);

    function Ne(OO) {
      let {
        children: KO,
        first: pO = !1
      } = OO;
      const bK = (0, XO.useContext)(Te),
        [eO, lO] = (0, XO.useState)(null === bK);
      return (0, XO.useEffect)((() => {
        if (!eO && null !== bK) return bK.request((() => {
          lO(!0)
        }), pO)
      }), [pO, eO, bK]), eO ? (0, XO.createElement)(XO.Fragment, null, KO) : null
    }
    const Ie = (0, XO.memo)((function(OO) {
        let {
          shown: KO
        } = OO;
        const [pO] = (0, XO.useState)((() => new FO.e(KO))), [bK] = (0, XO.useState)((() => KO ? null : new de));
        return (0, XO.useLayoutEffect)((() => {
          KO && (null === bK || void 0 === bK || bK.show(), pO.show())
        }), [KO, pO, bK]), (0, hO.jsx)(FO.c.Provider, {
          value: pO,
          children: (0, hO.jsx)(Te.Provider, {
            value: bK,
            children: (0, hO.jsx)(yl, {})
          })
        })
      })),
      yl = (0, XO.memo)((function() {
        const {
          isUiHidden: OO,
          isUiHiddenByCamera: KO,
          isTouchScreen: pO
        } = (0, iK.l)(["isUiHidden", "isUiHiddenByCamera", "isTouchScreen"]), bK = (0, ab.b)(), lO = he(), vK = (0, FO.k)(), CO = (0, XO.useRef)(null), DO = (0, zK.i)("showKillfeed");
        return function() {
            const OO = (0, FO.k)();
            (0, XO.useEffect)((() => OO.whenShown(VO)), [OO])
          }(),
          function() {
            const OO = (0, zK.i)("inventoryColourOverride");
            (0, XO.useEffect)((() => {
              if (!OO) return;
              const {
                panel: KO,
                slot: pO,
                slotSelected: XO,
                slotUnavailable: bK
              } = EO(OO), eO = document.documentElement.style;
              return eO.setProperty("--InventoryPanelColour", KO), eO.setProperty("--InventorySlotColour", pO), eO.setProperty("--InventorySlotSelectedColour", XO), eO.setProperty("--InventorySlotUnavailableColour", bK), () => {
                eO.removeProperty("--InventoryPanelColour"), eO.removeProperty("--InventorySlotColour"), eO.removeProperty("--InventorySlotSelectedColour"), eO.removeProperty("--InventorySlotUnavailableColour")
              }
            }), [OO])
          }(), (0, XO.useLayoutEffect)((() => vK.whenShown((() => {
            var OO;
            null === (OO = CO.current) || void 0 === OO || OO.classList.remove("PreMounted")
          }))), [vK]), (0, hO.jsxs)(hO.Fragment, {
            children: [(0, hO.jsxs)("div", {
              ref: CO,
              className: eO()("InGameUi", {
                PreMounted: !vK.shown,
                Hidden: OO,
                HiddenByCamera: KO
              }),
              ...lO,
              children: [(0, hO.jsxs)(Ne, {
                children: [(0, hO.jsx)(hp.b, {}), (0, hO.jsx)(Fp, {})]
              }), (0, hO.jsx)(FO.h, {
                children: (0, hO.jsx)(Vp, {})
              }), (0, hO.jsxs)(Ne, {
                children: [(0, hO.jsx)(RX, {}), (0, hO.jsx)(nX, {}), pO && (0, hO.jsx)(tb, {})]
              }), (0, hO.jsxs)(Ne, {
                children: [(0, hO.jsx)(sK, {}), (0, hO.jsx)(Ep.e, {}), (0, hO.jsx)(sp, {})]
              }), (0, hO.jsx)(FO.h, {
                children: (0, hO.jsx)(Cp, {})
              }), (0, hO.jsxs)(Ne, {
                children: [(0, hO.jsx)(BX.d, {}), (0, hO.jsx)(le, {})]
              }), (0, hO.jsxs)(Ne, {
                children: [(0, hO.jsx)(UX.f, {}), (0, hO.jsx)(Ob.f, {})]
              }), (0, hO.jsx)(Ne, {
                children: (0, hO.jsx)(RK.k, {})
              }), (0, hO.jsx)(Ne, {
                children: (0, hO.jsx)(il, {
                  showChat: bK
                })
              }), (0, hO.jsxs)(Ne, {
                children: [(0, hO.jsx)(pb, {}), (0, hO.jsx)(cb, {})]
              }), (0, hO.jsxs)("div", {
                className: eO()("RightElements", {
                  RightElementsTouchscreen: pO
                }),
                "data-camera-keeper-host": "",
                children: [(0, hO.jsxs)("div", {
                  className: Gp.h,
                  children: [(0, hO.jsxs)("div", {
                    className: "TopRightElementsLeft",
                    children: [(0, hO.jsx)(Ne, {
                      children: (0, hO.jsx)(uX.c, {})
                    }), (0, hO.jsxs)(Ne, {
                      children: [(0, hO.jsx)(NO, {}), (0, hO.jsx)(qX.d, {})]
                    }), wX.featureFlags.useSocialFeatures && (0, hO.jsx)(FO.h, {
                      children: (0, hO.jsx)(xX.b, {
                        placement: "inGame"
                      })
                    }), wX.featureFlags.useSocialFeatures && (0, hO.jsx)(FO.h, {
                      children: (0, hO.jsx)(vb, {})
                    }), DO && (0, hO.jsx)(FO.h, {
                      children: (0, hO.jsx)(upO, {})
                    }), (0, hO.jsx)(Ne, {
                      children: (0, hO.jsx)(De.d, {})
                    })]
                  }), wX.featureFlags.useSocialFeatures && (0, hO.jsx)("div", {
                    className: "TopRightElementsRight",
                    children: (0, hO.jsx)(Ne, {
                      children: (0, hO.jsx)(sX.b, {})
                    })
                  })]
                }), (0, hO.jsxs)(Ne, {
                  children: [(0, hO.jsx)(RK.e, {
                    placement: "topRight"
                  }), (0, hO.jsx)(rl, {})]
                })]
              }), (0, hO.jsx)("div", {
                className: "LeftCentre",
                children: (0, hO.jsx)(Ne, {
                  children: (0, hO.jsx)(Ve, {})
                })
              }), (0, hO.jsxs)("div", {
                className: "BottomCentre",
                children: [(0, hO.jsx)(FO.h, {
                  children: (0, hO.jsx)(QO.b, {})
                }), (0, hO.jsx)(Ne, {
                  children: (0, hO.jsx)(ue, {})
                }), (0, hO.jsxs)("div", {
                  className: "BottomElements",
                  children: [(0, hO.jsx)("div", {
                    className: eO()("BottomLeftElements", {
                      Touch: pO
                    }),
                    children: (0, hO.jsxs)(Ne, {
                      children: [(0, hO.jsx)(DX, {}), !pO && (0, hO.jsx)(Qe.c, {})]
                    })
                  }), (0, hO.jsx)(Ne, {
                    children: (0, hO.jsx)(we, {})
                  }), (0, hO.jsx)(Ne, {
                    children: (0, hO.jsx)(Rp, {
                      isTouchScreen: pO
                    })
                  })]
                })]
              }), (0, hO.jsx)("div", {
                className: "MiddleLeft"
              }), pO && (0, hO.jsx)(Ne, {
                children: (0, hO.jsx)(zp, {})
              }), (0, hO.jsx)("div", {
                className: "CameraFadeHost",
                ref: zl.e
              })]
            }), (0, hO.jsx)(FO.h, {
              children: (0, hO.jsx)(hb.e, {})
            }), (0, hO.jsx)(Ne, {
              first: !0,
              children: (0, hO.jsx)(MX.b, {})
            }), (0, hO.jsx)(FO.h, {
              children: (0, hO.jsx)(gl, {})
            })]
          })
      }));

    function gl() {
      return (0, XO.useEffect)((() => {
        const OO = setTimeout((() => {
          (0, dO.f)()
        }), 0);
        return () => {
          clearTimeout(OO), dO.i.JC(!1)
        }
      }), []), null
    }
    const ue = (0, XO.memo)((function() {
        const OO = (0, vK.h)("aimingOverlay", "none");
        (0, fO.c)();
        const KO = (0, zK.m)("middleTextUpper"),
          pO = (0, zK.m)("middleTextLower");
        return (0, hO.jsxs)("div", {
          className: "MiddleTextBottom",
          style: "sniper" === OO ? {
            visibility: "hidden"
          } : {},
          children: [(0, hO.jsx)(Ye, {
            text: KO,
            className: "MiddleText MiddleTextUpper SmallTextBold",
            maxHeightFraction: Ee
          }), (0, hO.jsx)(Ye, {
            text: pO,
            className: "MiddleText",
            maxHeightFraction: jl
          })]
        })
      })),
      Ee = .3,
      jl = .2;

    function Ye(OO) {
      let {
        text: KO,
        className: pO,
        maxHeightFraction: bK
      } = OO;
      const eO = (0, XO.useRef)(null),
        lO = (0, XO.useRef)(null);
      return function(OO, KO, pO, bK) {
        (0, XO.useLayoutEffect)((() => {
          const XO = OO.current,
            bK = KO.current;
          if (!XO || !bK) return;
          let eO = -1,
            lO = -1;
          const vK = OO => (bK.style.setProperty("zoom", String(OO)), XO.getBoundingClientRect().height),
            CO = () => {
              const OO = document.documentElement.clientHeight * pO;
              let KO = 1;
              if (vK(1) > OO) {
                let pO = .5,
                  XO = 1;
                for (let KO = 0; KO < 6; KO++) {
                  const KO = (pO + XO) / 2;
                  vK(KO) <= OO ? pO = KO : XO = KO
                }
                KO = pO
              }
              lO = vK(KO), eO = XO.getBoundingClientRect().width
            };
          CO();
          let hO = 0;
          const DO = () => {
              cancelAnimationFrame(hO), hO = requestAnimationFrame(CO)
            },
            MO = new ResizeObserver((() => {
              const {
                width: OO,
                height: KO
              } = XO.getBoundingClientRect();
              OO === eO && KO === lO || DO()
            }));
          return MO.observe(XO), window.addEventListener("resize", DO), () => {
            MO.disconnect(), window.removeEventListener("resize", DO), cancelAnimationFrame(hO), bK.style.removeProperty("zoom")
          }
        }), [OO, KO, pO, bK])
      }(eO, lO, bK, KO.content), (0, hO.jsx)("div", {
        ref: eO,
        className: "MiddleTextFit",
        children: (0, hO.jsx)(Kb, {
          ref: lO,
          text: KO,
          className: pO
        })
      })
    }
    const we = (0, XO.memo)((function() {
        const OO = (0, vK.h)("aimingOverlay", "none");
        (0, fO.c)();
        const KO = (0, zK.i)("useInventory");
        return (0, hO.jsxs)("div", {
          className: "BottomMiddleElements",
          style: "sniper" === OO ? {
            visibility: "hidden"
          } : {},
          children: [(0, hO.jsx)(DO, {}), (0, hO.jsx)(RK.e, {}), (0, hO.jsx)(SK, {}), (0, hO.jsx)(FO.h, {
            children: (0, hO.jsx)(mb, {})
          }), (0, hO.jsxs)("div", {
            className: "HotBarRow",
            children: [KO ? (0, hO.jsx)(yK.b, {}) : (0, hO.jsx)(yK.d, {}), (0, hO.jsx)(uO, {})]
          })]
        })
      })),
      il = (0, XO.memo)((function(OO) {
        let {
          showChat: KO
        } = OO;
        const {
          t: pO
        } = (0, cK.D)(), {
          clientEscMenuOptions: bK,
          isTouchScreen: lO
        } = (0, iK.l)(["clientEscMenuOptions", "isTouchScreen"]);
        (0, fO.c)();
        const {
          userContext: vK,
          isUserContextUpdating: CO
        } = (0, LO.d)(), DO = (0, zK.i)("hideCoordinates"), aK = (0, zK.i)("customVariationTitle"), {
          requestedGameNameWithVariation: oO,
          gameNameWithVariation: FO,
          lobbyName: VO,
          shownLobbyName: QO
        } = (0, rK.i)("connectedGame"), dO = (0, MO.b)(oO, VO, !1), [TO, NO] = (0, XO.useState)(null), IO = (0, jb.l)(FO || oO || ""), yK = aK || IO || "";
        (0, XO.useEffect)((() => {
          CO || Wp.c.getFavouriteLobbies(vK).then((OO => {
            console.log("Got favourite lobbies", OO), NO(OO)
          }))
        }), [CO, vK]);
        const gK = (0, XO.useRef)(null);
        return (0, XO.useLayoutEffect)((() => {
            const OO = gK.current,
              KO = document.documentElement,
              pO = new ResizeObserver((() => {
                KO.style.setProperty("--InGameHeaderRowsHeight", `${OO.offsetHeight}px`)
              }));
            return pO.observe(OO), () => {
              pO.disconnect(), KO.style.removeProperty("--InGameHeaderRowsHeight")
            }
          }), []),
          function(OO) {
            const {
              isTouchScreen: KO
            } = (0, iK.l)(["isTouchScreen"]);
            (0, XO.useLayoutEffect)((() => {
              if (!KO) return;
              const pO = OO.current,
                XO = document.querySelector(`.${Gp.h}`),
                bK = OO => {
                  const KO = () => {
                    const KO = `${Math.floor(OO.getBoundingClientRect().left-pO.getBoundingClientRect().left-4)}px`;
                    pO.style.getPropertyValue("--InGameHeaderMaxWidth") !== KO && pO.style.setProperty("--InGameHeaderMaxWidth", KO)
                  };
                  KO();
                  const bK = new ResizeObserver(KO);
                  bK.observe(OO), bK.observe(XO), window.addEventListener("resize", KO);
                  const eO = new MutationObserver(KO);
                  return eO.observe(document.body, {
                    attributes: !0,
                    attributeFilter: ["style"]
                  }), () => {
                    bK.disconnect(), eO.disconnect(), window.removeEventListener("resize", KO)
                  }
                },
                eO = () => XO.querySelector(".TopRightIconsContainer"),
                lO = eO();
              let vK;
              if (lO) vK = bK(lO);
              else {
                const OO = new MutationObserver((() => {
                  const KO = eO();
                  KO && (OO.disconnect(), vK = bK(KO))
                }));
                OO.observe(XO, {
                  childList: !0,
                  subtree: !0
                }), vK = () => {
                  OO.disconnect()
                }
              }
              return () => {
                vK(), pO.style.removeProperty("--InGameHeaderMaxWidth")
              }
            }), [KO, OO])
          }(gK), (0, hO.jsxs)(hO.Fragment, {
            children: [(0, hO.jsxs)("div", {
              className: eO()(Gp.g, {
                Touchscreen: lO
              }),
              ref: gK,
              children: [(0, hO.jsxs)("div", {
                className: "InGameHeader",
                children: [(0, hO.jsxs)("div", {
                  className: "InGameHeaderLogo",
                  onMouseDown: OO => {
                    OO.stopPropagation(), OO.preventDefault()
                  },
                  onClick: () => {
                    iK.d.set({
                      openEverythingMenuName: wp.o.SETTINGS
                    })
                  },
                  children: [(0, hO.jsx)(EX.e, {
                    showFace: !0,
                    loading: !1
                  }), "bloxd.io"]
                }), (0, hO.jsx)("div", {
                  className: "InGameHeaderSpacer"
                }), (0, hO.jsxs)("div", {
                  className: "InGameHeaderGameName",
                  children: [null === dO && (0, hO.jsx)(EX.e, {}), null !== dO && (0, hO.jsxs)(hO.Fragment, {
                    children: [dO, yK && ` ${yK}`]
                  })]
                }), (0, hO.jsx)("div", {
                  className: "InGameHeaderSpacer"
                }), (0, hO.jsx)("div", {
                  className: "InGameHeaderLobbyName",
                  children: QO
                }), (0, YX.D)(VO) && (0, hO.jsx)(AO.g, {
                  tooltipInner: (0, hO.jsx)("div", {
                    children: pO(null !== TO && TO.includes(VO) ? "customLobby:removeFromFavourites" : "customLobby:addToFavourites")
                  }),
                  children: (0, hO.jsx)("div", {
                    children: (0, hO.jsx)(qp.w, {
                      isLiked: null !== TO && TO.includes(VO),
                      onClick: () => {
                        try {
                          if (!TO) return;
                          TO.includes(VO) ? (Wp.c.unfavouriteLobby(vK, VO).catch((OO => {
                            console.error("Failed to favourite lobby", OO)
                          })), NO(TO.filter((OO => OO !== VO)))) : (Wp.c.favouriteLobby(vK, VO).catch((OO => {
                            console.error("Failed to favourite lobby", OO)
                          })), NO([...TO, VO]))
                        } catch (OO) {
                          console.error("Failed to like lobby", OO)
                        }
                      },
                      isLoading: null === TO
                    })
                  })
                }), (0, hO.jsx)(lb, {})]
              }), (0, hO.jsx)(TX, {
                show: bK.showFPS
              }), !DO && bK.showCoordinates && (0, hO.jsx)(yb, {}), !DO && bK.showChunkCoordinates && (0, hO.jsx)(gb, {}), (0, hO.jsx)(Xb, {})]
            }), (0, hO.jsx)("div", {
              className: "TopLeftElements",
              children: (0, hO.jsx)("div", {
                className: "InGameHeaderAndChat",
                children: KO && (0, hO.jsx)(wO.b, {})
              })
            })]
          })
      })),
      rl = (0, XO.memo)((function() {
        (0, fO.c)();
        const OO = (0, zK.m)("RightInfoText"),
          [KO, pO] = (0, XO.useState)(null);
        return (0, Zp.f)(KO, ".RightElements"), OO.hasText ? (0, hO.jsx)("div", {
          className: "RightInfoDivContainer",
          children: (0, hO.jsx)(Kb, {
            ref: pO,
            text: OO,
            className: "RightInfoDiv",
            children: (0, hO.jsx)("div", {
              className: "RightInfoDivInner",
              children: (0, hO.jsx)(CO.d, {
                text: OO.content
              })
            })
          })
        }) : null
      }))
  },
  3969: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK
    });
    var XO = pO(63),
      bK = pO(243),
      eO = pO(1546),
      lO = pO(976);

    function vK(OO) {
      let {
        text: KO
      } = OO;
      const pO = [];
      let vK = "";
      return (0, bK.cc)(KO).forEach(((OO, KO) => {
        if ("string" === typeof OO || !(0, eO.d)(OO.icon)) return void(vK += "string" === typeof OO ? OO : OO.icon);
        const bK = Math.max(0, vK.trimEnd().search(/\S{1,12}$/));
        pO.push((0, lO.jsxs)(XO.Fragment, {
          children: [vK.slice(0, bK), (0, lO.jsxs)("span", {
            className: "InlineIconTextGlue",
            children: [vK.slice(bK), (0, lO.jsx)("span", {
              className: "InlineIconTextIcon",
              role: "img",
              "aria-label": OO.icon,
              children: (0, lO.jsx)(eO.b, {
                itemName: OO.icon,
                amount: 0
              })
            })]
          })]
        }, KO)), vK = ""
      })), pO.push(vK), (0, lO.jsx)(lO.Fragment, {
        children: pO
      })
    }
  },
  35064: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => aK,
      d: () => DO,
      h: () => MO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(1546),
      vK = pO(976);
    const CO = 350;
    let hO = 0;

    function DO() {
      return hO += 1, hO
    }

    function MO(OO, KO) {
      let pO = 0;
      for (const XO of OO) "ingredient" !== XO.kind && XO.uq === KO && (pO += XO.amount);
      return pO > 0 ? {
        idx: KO,
        amount: pO
      } : null
    }

    function aK(OO) {
      var KO, pO;
      let {
        anim: bK,
        onComplete: hO
      } = OO;
      const DO = null !== (KO = bK.delayMs) && void 0 !== KO ? KO : 0,
        MO = null !== (pO = bK.durationMs) && void 0 !== pO ? pO : CO,
        [aK, oO] = (0, XO.useState)(bK.from),
        [FO, VO] = (0, XO.useState)(0 === DO),
        [LO, QO] = (0, XO.useState)(!1),
        zK = (0, XO.useRef)(!1);
      return (0, XO.useEffect)((() => {
        let OO, KO;
        const pO = () => {
            zK.current = !0, VO(!0), OO = requestAnimationFrame((() => {
              KO = requestAnimationFrame((() => {
                oO({
                  x: bK.to.x,
                  y: bK.to.y
                }), QO(!0)
              }))
            }))
          },
          XO = zK.current ? 0 : DO;
        let eO;
        XO > 0 ? eO = setTimeout(pO, XO) : pO();
        const lO = setTimeout((() => {
          hO(bK.id)
        }), XO + MO + 50);
        return () => {
          clearTimeout(eO), cancelAnimationFrame(OO), cancelAnimationFrame(KO), clearTimeout(lO)
        }
      }), [bK.id, bK.to.x, bK.to.y, hO, DO, MO]), (0, vK.jsx)("div", {
        className: eO()("CraftItemFlyAnimation", {
          Ingredient: "ingredient" === bK.kind,
          Waiting: !FO,
          Arrived: LO
        }),
        style: {
          left: aK.x,
          top: aK.y,
          "--fly-duration": `${MO}ms`
        },
        children: (0, vK.jsx)(lO.b, {
          itemName: bK.itemName,
          amount: bK.amount
        })
      })
    }
  },
  35044: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => wO,
      d: () => PO
    });
    var XO = pO(63),
      bK = pO(2332),
      eO = pO(5691),
      lO = pO(1643),
      vK = pO(1991),
      CO = pO(7917),
      hO = pO(256),
      DO = pO(26),
      MO = pO(1263),
      aK = pO(36),
      oO = pO(918),
      FO = pO.n(oO),
      VO = pO(243),
      LO = pO(35049),
      QO = pO(1533),
      zK = pO(1583),
      AO = pO(7768),
      fO = pO(976);

    function dO(OO) {
      var KO, pO;
      let {
        slotIdx: eO
      } = OO;
      const lO = (0, zK.e)("hotbar", (OO => {
          var KO;
          return null !== (KO = OO.items[eO]) && void 0 !== KO ? KO : null
        })),
        CO = (0, zK.e)("hotbar", (OO => OO.ammo)),
        [DO, MO] = (0, XO.useState)(!1),
        aK = (0, XO.useRef)(null),
        [oO, VO] = (0, XO.useState)(null),
        [LO, dO] = (0, XO.useState)(null),
        TO = (0, vK.i)("maxAuraLevel"),
        NO = (0, bK.b)(),
        IO = (0, XO.useCallback)((() => {
          if (clearTimeout(aK.current), lO) {
            var OO, KO, pO, XO;
            const CO = lO.displayName,
              DO = [],
              MO = Array.isArray(CO) ? CO : [CO],
              aK = {
                fontStyle: null !== (OO = lO.attributes.customAttributes) && void 0 !== OO && OO.author ? "italic" : "normal"
              };
            for (const OO of MO) OO.str ? DO.push(OO) : DO.push({
              str: OO,
              style: aK
            });
            if (null !== (KO = lO.attributes.customAttributes) && void 0 !== KO && KO.enchantments) {
              DO.push(" ");
              const OO = Object.entries(lO.attributes.customAttributes.enchantments).sort(((OO, KO) => KO[1] - OO[1])),
                KO = lO.attributes.customAttributes.enchantmentData;
              for (const [pO, XO] of OO) {
                var bK, eO;
                const OO = null !== (bK = null === KO || void 0 === KO || null === (eO = KO[pO]) || void 0 === eO ? void 0 : eO.icon) && void 0 !== bK ? bK : `${pO} Enchantment`;
                var vK;
                if (XO < 4)
                  for (let KO = 0; KO < XO; KO++) DO.push({
                    icon: OO,
                    style: {
                      fontSize: "1.5em"
                    }
                  });
                else DO.push({
                  icon: OO,
                  style: {
                    fontSize: "1.5em"
                  }
                }), DO.push(null !== (vK = (0, hO.O)(XO)) && void 0 !== vK ? vK : XO.toString())
              }
            }
            VO(DO), dO(null !== (pO = null === (XO = lO.attributes.customAttributes) || void 0 === XO ? void 0 : XO.enchantmentTier) && void 0 !== pO ? pO : null)
          } else VO(null), dO(null);
          MO(!0), NO();
          const CO = null === lO || void 0 === lO ? void 0 : lO.attributes.customAttributes;
          void 0 === (null === CO || void 0 === CO ? void 0 : CO.shotsLeft) && (aK.current = setTimeout((() => {
            MO(!1)
          }), 2e3))
        }), [null === lO || void 0 === lO ? void 0 : lO.name, eO, null === lO || void 0 === lO ? void 0 : lO.instance, null === lO || void 0 === lO ? void 0 : lO.displayName]);
      (0, XO.useEffect)((() => (IO(), () => {
        clearTimeout(aK.current), MO(!1)
      })), [null === lO || void 0 === lO ? void 0 : lO.name, eO, null === lO || void 0 === lO ? void 0 : lO.instance, IO]);
      const yK = null === lO || void 0 === lO || null === (KO = lO.attributes.customAttributes) || void 0 === KO ? void 0 : KO.shotsLeft,
        gK = void 0 === yK ? null : (0, fO.jsx)("div", {
          className: "SelectedItemShotsLeft",
          children: `${yK}|${lO.requiresAmmo?`${CO}x${lO.clipSize}`:lO.clipSize}`
        }),
        uO = (0, AO.k)();
      return (0, fO.jsx)(fO.Fragment, {
        children: DO && lO && !uO.showing ? (0, fO.jsxs)("div", {
          className: FO()("SelectedItemName SmallTextBold", {
            NoAuraBar: 0 === TO,
            Enchanted: null !== LO
          }),
          style: {
            "--enchantmentColour": null !== (pO = hO.hb[LO]) && void 0 !== pO ? pO : hO.hb.None,
            "--duration": LO ? (0, hO.bb)(LO) + "s" : void 0
          },
          children: [LO && (0, fO.jsxs)("div", {
            className: "SelectedItemNameGradient",
            children: [(0, fO.jsx)(QO.d, {
              text: oO
            }), gK]
          }), (0, fO.jsxs)("div", {
            className: "SelectedItemNameNormal",
            children: [(0, fO.jsx)(QO.d, {
              text: oO
            }), gK]
          })]
        }) : null
      })
    }
    var TO = pO(35064),
      NO = pO(22),
      IO = pO(1556),
      yK = pO(533),
      gK = pO(1994),
      uO = pO(35069),
      EO = pO(35072);
    var jK = pO(1667);
    var YO = pO(1289);
    const wO = (0, XO.memo)((function() {
      const [OO, KO] = (0, XO.useState)(0), pO = (0, vK.i)("useFullInventory"), {
        isTouchScreen: lO,
        openInGameMenuName: CO
      } = (0, NO.l)(["isTouchScreen", "openInGameMenuName"]), hO = null !== CO && "inventory" !== CO, aK = (0, zK.i)("fullInventory") && "inventory" === CO, oO = function() {
        const OO = (0, XO.useRef)(null);
        return (0, jK.e)(((KO, pO) => {
          var XO;
          const bK = pO >= KO;
          if ((null === (XO = OO.current) || void 0 === XO ? void 0 : XO.width) !== KO || OO.current.portrait !== bK) {
            const pO = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--touch-hotbar-ends-spare"));
            OO.current = {
              width: KO,
              portrait: bK,
              atEnds: pO >= 0
            }
          }
          return OO.current.atEnds
        }))
      }(), VO = lO && !oO;
      ! function(OO, KO, pO) {
        (0, XO.useLayoutEffect)((() => {
          const XO = document.documentElement.classList;
          return OO && (XO.add("TouchHotbar"), XO.toggle("TouchHotbarKeysAbove", KO), XO.toggle("TouchHotbarHasBag", pO)), (0, uO.h)(), DO.i.pl(EO.e), () => {
            XO.remove("TouchHotbar", "TouchHotbarKeysAbove", "TouchHotbarHasBag"), (0, uO.h)(), DO.i.pl(EO.e)
          }
        }), [OO, KO, pO])
      }(lO, VO, pO);
      const [QO, AO] = (0, eO.d)("changedHotbarUsingNumkeys", !0), gK = (0, zK.e)("hotbar", (OO => OO.selectedSlot)), YO = null !== gK && void 0 !== gK ? gK : OO, wO = (0, bK.b)(), mK = (0, XO.useRef)(null), sO = (0, MO.h)("pointerLockUpdate", Boolean(document.pointerLockElement));
      (0, MO.f)("inventoryDraggedItemUpdated", (OO => {
        mK.current = OO, wO()
      })), (0, zK.b)("hotbarScrolled", (OO => {
        null === gK && SO(OO)
      })), (0, zK.b)("hotbarSlotRequested", (OO => {
        RO(OO), AO(!1)
      })), (0, zK.b)("numberKeyPressed", (() => {
        AO(!1)
      })), (0, zK.b)("hotbarDropRequested", (OO => {
        const KO = IO.gameBridge.latest("hotbar").items[YO];
        if (KO) {
          var pO;
          const XO = OO && null !== (pO = KO.amount) && void 0 !== pO ? pO : 1;
          IO.gameBridge.send("removeInventoryItem", {
            slot: YO,
            amount: XO,
            drop: !0
          })
        }
      }));
      const RO = OO => {
          IO.gameBridge.send("selectHotbarSlot", OO), KO(OO)
        },
        SO = OO => {
          RO((YO + OO + yK.p) % yK.p)
        };
      let JO, cK = null,
        BO = null,
        ZO = OO => OO => {},
        GO = OO => KO => {
          RO(OO)
        },
        qK = OO => OO => {},
        xK = [];
      if (aK) {
        var nO;
        const OO = mK.current;
        if (null === OO || void 0 === OO || !OO.setHovered) return (0, fO.jsx)("div", {
          className: FO()("HotBarContainer", {
            Touch: lO,
            KeysAbove: VO
          }),
          children: (0, fO.jsx)("div", {
            className: "HotBar"
          })
        });
        cK = OO.draggedInfo, BO = OO.specialItemInfo, ZO = OO.setHovered, GO = OO.pointerDown, qK = OO.pointerUp, JO = OO.variation, xK = null !== (nO = OO.craftFlyAnims) && void 0 !== nO ? nO : []
      }
      return (0, fO.jsxs)("div", {
        className: FO()("HotBarContainer", {
          Touch: lO,
          PopupOpen: lO && hO,
          KeysAbove: VO
        }),
        children: [(0, fO.jsxs)("div", {
          className: FO()("HotBar", {
            HoverDisabled: sO
          }),
          children: [lO && (0, fO.jsxs)(fO.Fragment, {
            children: [(0, fO.jsx)(rK, {
              useFullInventory: pO,
              inventoryOpen: aK
            }), (0, fO.jsx)(iK, {
              direction: "Previous",
              onPress: () => {
                SO(-1)
              }
            })]
          }), !lO && (0, fO.jsxs)(fO.Fragment, {
            children: [(0, fO.jsx)(PO, {}), (0, fO.jsx)("div", {
              className: "HotBarFiller"
            })]
          }), (0, fO.jsx)("div", {
            className: "HotBarGameItemsContainer",
            children: new Array(10).fill(0).map(((OO, KO) => (0, fO.jsx)(LO.b, {
              idx: KO,
              draggedInfo: cK,
              specialItemInfo: BO,
              craftFlyHoldbackInfo: (0, TO.h)(xK, KO),
              setHovered: ZO(KO),
              pointerDown: GO(KO),
              pointerUp: qK(KO),
              variation: JO,
              isSelected: KO === YO,
              hoverDisabled: sO,
              showNumber: QO && !lO
            }, KO)))
          }), lO && (0, fO.jsx)(iK, {
            direction: "Next",
            onPress: () => {
              SO(1)
            }
          }), !lO && (0, fO.jsxs)(fO.Fragment, {
            children: [(0, fO.jsx)("div", {
              className: "HotBarFiller"
            }), (0, fO.jsx)("div", {
              className: FO()("HotBarItem ButtonHotBarItem", {
                HiddenButtonHotBarItem: !pO
              }),
              onPointerDown: () => {
                DO.i.pl("toggleMenu", "inventory")
              },
              children: (0, fO.jsx)(HO, {})
            })]
          })]
        }), (0, fO.jsx)(dO, {
          slotIdx: YO
        })]
      })
    }));

    function iK(OO) {
      let {
        direction: KO,
        onPress: pO
      } = OO;
      return (0, fO.jsx)("div", {
        className: FO()("HotBarArrow", KO),
        ...YO.b,
        children: (0, fO.jsx)(lO.c, {
          icon: "Previous" === KO ? "caret-left" : "caret-right",
          touchPressOn: "pointerdown",
          onClick: pO
        })
      })
    }
    const rK = (0, XO.memo)((function(OO) {
        let {
          useFullInventory: KO,
          inventoryOpen: pO
        } = OO;
        const bK = (0, vK.i)("maxAuraLevel"),
          eO = (0, XO.useRef)(null);
        return function(OO, KO, pO) {
          (0, XO.useLayoutEffect)((() => (document.documentElement.classList.toggle("TouchHotbarHasShop", KO), () => {
            document.documentElement.classList.remove("TouchHotbarHasShop")
          })), [KO]), (0, XO.useLayoutEffect)((() => {
            const KO = OO.current.closest(".BottomMiddleElements");
            return KO.classList.toggle("TouchInventoryOpen", pO), () => {
              KO.classList.remove("TouchInventoryOpen")
            }
          }), [OO, pO])
        }(eO, (0, CO.c)(), pO), (0, fO.jsxs)("div", {
          ref: eO,
          className: FO()("TouchInventoryKeys", {
            NoAuraBar: 0 === bK,
            InventoryOpen: pO
          }),
          children: [(0, fO.jsx)(PO, {
            touchKey: !0
          }), (0, fO.jsx)("div", {
            className: FO()("TouchInventoryKey BagKey", {
              Hidden: !KO
            }),
            ...YO.b,
            children: (0, fO.jsx)(HO, {
              touchKey: !0
            })
          })]
        })
      })),
      PO = (0, XO.memo)((function(OO) {
        let {
          touchKey: KO = !1
        } = OO;
        const pO = (0, CO.c)();
        return (0, fO.jsx)("div", {
          className: KO ? FO()("TouchInventoryKey ShopKey", {
            Hidden: !pO
          }) : FO()("HotBarItem ButtonHotBarItem", {
            HiddenButtonHotBarItem: !pO
          }),
          ...KO ? YO.b : {},
          children: (0, fO.jsx)(lO.c, {
            icon: (0, hO.cc)(),
            noaAction: "OpenShop",
            touchPressOn: "pointerup",
            onClick: () => {
              pO && NO.d.set({
                openEverythingMenuName: VO.o.SHOP
              })
            },
            showTouchTutorialPubSubId: "showShopTouchTutorial",
            showRedDotPubSubId: "showShopIconRedDot",
            touchIconPosition: "topleft"
          })
        })
      }));

    function mK(OO) {
      let {
        player: KO
      } = OO;
      return KO.some((OO => null !== OO && hO.Nc.includes(OO.name)))
    }

    function sO(OO) {
      OO.creative || aK.e.getItem("LogInInventoryRedDotTutorialComplete") || (mK(OO) ? (DO.i.pl("RedDotOpenInventoryIcon", !0), DO.i.pl("TouchTutorialOpenInventoryIcon", !0)) : (DO.i.pl("RedDotOpenInventoryIcon", !1), DO.i.pl("TouchTutorialOpenInventoryIcon", !1)))
    }
    const HO = (0, XO.memo)((function(OO) {
      let {
        touchKey: KO = !1
      } = OO;
      const {
        backpackPointerRequested: pO
      } = (0, NO.l)(["backpackPointerRequested"]);
      (0, XO.useEffect)((() => {
        sO(IO.gameBridge.latest("inventory"))
      }), []), (0, zK.b)("inventory", sO);
      const bK = (0, gK.k)();
      return (0, MO.f)("toggleMenu", (OO => {
        bK.shown && (null !== OO && void 0 !== OO && OO.startsWith("inventory") && mK(IO.gameBridge.latest("inventory")) ? (aK.e.setItem("LogInInventoryRedDotTutorialComplete", !0), DO.i.pl("RedDotOpenInventoryIcon", !1), DO.i.pl("TouchTutorialOpenInventoryIcon", !1)) : "shop" === OO && DO.i.pl("showShopTouchTutorial", !1))
      })), KO ? (0, fO.jsx)(lO.c, {
        icon: "backpack",
        noaAction: "OpenInventory",
        touchPressOn: "pointerup",
        onClick: () => {
          DO.i.pl("toggleMenu", "inventory")
        },
        showRedDotPubSubId: "RedDotOpenInventoryIcon",
        showTouchTutorialPubSubId: "TouchTutorialOpenInventoryIcon",
        touchTutorialRequested: pO,
        touchIconPosition: "topleft"
      }) : (0, fO.jsx)("div", {
        className: "HotBarButton",
        onPointerDown: () => {
          DO.i.pl("toggleMenu", "inventory")
        },
        children: (0, fO.jsx)(lO.c, {
          icon: "backpack",
          noaAction: "OpenInventory",
          onPointerDown: OO => {
            DO.i.pl("toggleMenu", "inventory"), OO.stopPropagation()
          },
          showRedDotPubSubId: "RedDotOpenInventoryIcon",
          showTouchTutorialPubSubId: "TouchTutorialOpenInventoryIcon",
          touchTutorialRequested: pO,
          touchIconPosition: "topleft"
        })
      })
    }))
  },
  35049: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => LO,
      d: () => FO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(1548),
      vK = pO(1546),
      CO = pO(1556),
      hO = pO(1583),
      DO = pO(35058),
      MO = pO(8330),
      aK = pO(1225),
      oO = pO(976);
    const FO = (OO, KO, pO) => {
      let XO = KO,
        bK = !1;
      for (const eO of pO)(null === eO || void 0 === eO ? void 0 : eO.idx) === OO && (bK = !0, XO > 0 && (XO -= eO.amount));
      return {
        displayedAmt: XO,
        shown: !bK || XO > 0
      }
    };
    const VO = OO => {
        let {
          idx: KO
        } = OO;
        return (0, aK.p)() ? null : (0, oO.jsx)("div", {
          className: "HotbarItemNumber SmallTextBold",
          children: KO < 9 ? KO + 1 : 0
        })
      },
      LO = (0, XO.memo)((function(OO) {
        var KO, pO, XO;
        let {
          idx: bK,
          setHovered: aK,
          pointerDown: LO,
          pointerUp: QO,
          draggedInfo: zK,
          specialItemInfo: AO,
          craftFlyHoldbackInfo: fO,
          defaultIconB64: dO = null,
          variation: TO,
          isSelected: NO = !1,
          hoverDisabled: IO = !1,
          showNumber: yK = !1,
          showNewDot: gK = !1
        } = OO;
        const uO = (0, hO.e)("inventory", (OO => bK === DO.c ? null : (0, MO.l)(OO, bK)));
        let EO, jK, YO, wO;
        if (bK === DO.c) AO && (EO = AO.name, YO = AO.amount, wO = AO.attributes);
        else if (uO) {
          var iK;
          EO = uO.name, jK = uO.icon, YO = null !== (iK = uO.amount) && void 0 !== iK ? iK : 0, wO = uO.attributes
        }
        const rK = null === (KO = wO) || void 0 === KO || null === (pO = KO.customAttributes) || void 0 === pO ? void 0 : pO.enchantmentTier,
          PO = (0, lO.j)(wO),
          {
            displayedAmt: mK,
            shown: sO
          } = FO(bK, YO, [zK, AO, fO]),
          HO = EO && sO,
          RO = void 0 !== TO && function(OO, KO) {
            const {
              enchantable: pO,
              salvageable: XO
            } = CO.gameBridge.latest("stationItems");
            return "Enchanting Table" === OO ? !0 === pO[KO] : "Salvaging Table" === OO && !0 === XO[KO]
          }(TO, EO);
        return (0, oO.jsxs)("div", {
          className: eO()("InvenItem", {
            Highlighted: HO && RO,
            Selected: NO,
            HoverDisabled: IO
          }),
          onPointerEnter: () => {
            null === aK || void 0 === aK || aK(!0)
          },
          onPointerLeave: () => {
            null === aK || void 0 === aK || aK(!1)
          },
          onPointerDown: LO,
          onPointerUp: QO,
          "data-inven-idx": bK,
          children: [HO && (0, oO.jsx)(vK.b, {
            itemName: null !== (XO = jK) && void 0 !== XO ? XO : EO,
            amount: mK,
            enchantmentTier: rK,
            bar: PO
          }), HO && gK && (0, oO.jsx)("div", {
            className: "InvenItemNewDot"
          }), yK && (0, oO.jsx)(VO, {
            idx: bK
          }), dO && !HO && (0, oO.jsx)("div", {
            className: "InvenItemUnfilled",
            style: {
              backgroundImage: `url(${dO})`
            }
          })]
        })
      }))
  },
  8319: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO
    });
    var XO = pO(256),
      bK = pO(8321);

    function eO(OO, KO, pO) {
      const eO = Object.entries(KO).sort(((OO, KO) => KO[1] - OO[1])),
        lO = (0, XO.ob)(OO);
      lO.push(OO ? "\n\n" : "\n");
      for (const [bK, FO] of eO) {
        var vK, CO, hO;
        const OO = null !== (vK = null === pO || void 0 === pO || null === (CO = pO[bK]) || void 0 === CO ? void 0 : CO.icon) && void 0 !== vK ? vK : `${bK} Enchantment`;
        lO.push({
          icon: OO,
          style: {
            fontSize: "1.5rem"
          }
        }), lO.push({
          str: `${bK} ${null!==(hO=(0,XO.O)(FO))&&void 0!==hO?hO:FO}\n`
        })
      }
      lO.push({
        str: "\n"
      });
      for (const [XO, FO] of eO) {
        var DO, MO, aK, oO;
        const OO = null !== (DO = null === pO || void 0 === pO || null === (MO = pO[XO]) || void 0 === MO ? void 0 : MO.icon) && void 0 !== DO ? DO : `${XO} Enchantment`,
          KO = null !== (aK = null === pO || void 0 === pO || null === (oO = pO[XO]) || void 0 === oO ? void 0 : oO.description) && void 0 !== aK ? aK : (0, bK.n)(XO);
        lO.push({
          icon: OO,
          style: {
            fontSize: "1.25rem",
            opacity: .75
          }
        }), lO.push({
          str: KO,
          style: {
            fontSize: "0.8em",
            fontWeight: "normal",
            opacity: .75
          }
        }), lO.push({
          str: "\n"
        })
      }
      return lO
    }
  },
  35058: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO,
      c: () => bK
    });
    const XO = -1,
      bK = -2
  },
  8330: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => MO,
      e: () => hO,
      g: () => zK,
      k: () => LO,
      l: () => CO,
      n: () => QO,
      r: () => DO,
      t: () => aK,
      w: () => VO
    });
    var XO = pO(243),
      bK = pO(533),
      eO = pO(256),
      lO = pO(3509),
      vK = pO(8319);

    function CO(OO, KO) {
      var pO;
      let {
        player: XO,
        chestOrCreative: bK
      } = OO;
      var eO;
      return KO < XO.length ? null !== (eO = XO[KO]) && void 0 !== eO ? eO : null : null !== (pO = bK[KO - XO.length]) && void 0 !== pO ? pO : null
    }

    function hO(OO) {
      var KO;
      return null !== (KO = OO.amount) && void 0 !== KO ? KO : 0
    }

    function DO(OO) {
      return 0 === OO.button || void 0 === OO.button
    }

    function MO(OO) {
      return !!OO.shiftKey
    }

    function aK(OO) {
      return "touches" in OO || "touch" === OO.pointerType || "pen" === OO.pointerType
    }
    const oO = new Set,
      FO = 50;

    function VO(OO, KO) {
      var pO;
      const XO = null === (pO = OO[KO]) || void 0 === pO ? void 0 : pO.displayName;
      return (0, bK.I)(XO) ? "string" !== typeof KO ? "" : (!oO.has(KO) && oO.size < FO && (oO.add(KO), console.warn(`No item called "${KO}", so its hover shows the name as given`)), KO) : XO
    }

    function LO(OO, KO, pO) {
      var CO, hO, DO, MO, aK, oO, FO, LO, QO, zK, AO, fO, dO, TO;
      const NO = OO.attributes,
        IO = null !== (CO = null === (hO = KO[OO.name]) || void 0 === hO ? void 0 : hO.rootName) && void 0 !== CO ? CO : OO.name,
        yK = null !== (DO = null !== (MO = NO.customDisplayName) && void 0 !== MO ? MO : null === (aK = KO[OO.name]) || void 0 === aK ? void 0 : aK.displayName) && void 0 !== DO ? DO : VO(KO, IO);
      let gK = yK;
      const uO = null === (oO = NO.customAttributes) || void 0 === oO ? void 0 : oO.enchantmentTier;
      uO && (gK = (0, eO.ob)(yK, {
        colour: eO.hb[uO]
      }));
      const EO = null !== (FO = null !== (LO = null !== (QO = function(OO, KO) {
        var pO;
        if (void 0 === OO || null !== (pO = KO.customAttributes) && void 0 !== pO && pO.author) return OO;
        const bK = (0, XO.cc)(OO);
        return bK.every((OO => "string" === typeof OO)) ? OO : bK.map((OO => "string" === typeof OO ? OO : {
          icon: OO.icon,
          style: {
            fontSize: "1.5em"
          }
        }))
      }(NO.customDescription, NO)) && void 0 !== QO ? QO : null === (zK = KO[OO.name]) || void 0 === zK ? void 0 : zK.description) && void 0 !== LO ? LO : null === (AO = KO[IO]) || void 0 === AO ? void 0 : AO.description) && void 0 !== FO ? FO : "";
      let jK = EO;
      if (null !== (fO = NO.customAttributes) && void 0 !== fO && fO.enchantments) jK = (0, vK.b)(EO, NO.customAttributes.enchantments, NO.customAttributes.enchantmentData);
      else if (pO[IO]) jK = (0, eO.ob)(EO), jK.push({
        str: "\n"
      }), jK.push({
        str: "Enchantable",
        style: {
          fontSize: "0.8em",
          fontWeight: "normal",
          opacity: .4
        }
      });
      else if (null !== (dO = NO.customAttributes) && void 0 !== dO && dO.mobSettings) {
        var YO, wO;
        const OO = NO.customAttributes.mobSettings;
        var iK, rK;
        if (jK = [], (0, bK.I)(NO.customAttributes.health) || (jK.push({
            str: "\n"
          }), jK.push({
            icon: "Health",
            style: {
              fontSize: "1.5em"
            }
          }), jK.push({
            str: " "
          }), jK.push({
            str: NO.customAttributes.health.toString()
          }), (0, bK.I)(OO.maxHealth) || (jK.push({
            str: "/"
          }), jK.push({
            str: OO.maxHealth.toString()
          }))), !(0, bK.I)(OO.attackDamage) && OO.attackDamage > 0 && (jK.push({
            str: "\n"
          }), jK.push({
            icon: "Iron Sword",
            style: {
              fontSize: "1.5em"
            }
          }), jK.push({
            str: " "
          }), jK.push({
            str: OO.attackDamage.toString()
          })), !(0, bK.I)(OO.secondaryAttackDamage) && OO.secondaryAttackDamage > 0 && (jK.push({
            str: "\n"
          }), jK.push({
            icon: "Stone Crossbow",
            style: {
              fontSize: "1.5em"
            }
          }), jK.push({
            str: " "
          }), jK.push({
            str: OO.secondaryAttackDamage.toString()
          })), (0, bK.I)(OO.baseRunningSpeed) || (jK.push({
            str: "\n"
          }), jK.push({
            icon: "Speed",
            style: {
              fontSize: "1.5em"
            }
          }), jK.push({
            str: " "
          }), jK.push({
            str: OO.baseRunningSpeed.toFixed(2)
          })), "Saddled" === OO.metaInfo) jK.push({
          str: "\n"
        }), jK.push({
          str: {
            translationKey: "general:has"
          }
        }), jK.push({
          str: " "
        }), jK.push({
          icon: null !== (iK = null === (rK = OO.tameInfo) || void 0 === rK ? void 0 : rK.saddleItemName) && void 0 !== iK ? iK : "Saddle",
          style: {
            fontSize: "1.5em"
          }
        });
        if (jK.push({
            str: "\n"
          }), jK.push({
            str: "\n"
          }), OO.petInfo && null !== (YO = OO.tameInfo) && void 0 !== YO && YO.supportsFriendship) {
          const KO = lO.b.getIconsFromFriendshipPoints(OO.petInfo.friendshipPoints);
          for (const OO of KO) jK.push({
            icon: OO,
            style: {
              fontSize: "1.5em"
            }
          });
          jK.push({
            str: "\n"
          });
          const pO = lO.b.getMobHungerLevel(OO.petInfo.lastFedAt);
          for (const OO of lO.b.hungerLevelIcons[pO]) jK.push({
            icon: OO,
            style: {
              fontSize: "1.5em"
            }
          });
          jK.push({
            str: " "
          }), jK.push({
            str: lO.b.hungerLevelTranslations[pO],
            style: {
              fontWeight: "bolder"
            }
          })
        }
        if (OO.tameInfo && null !== (wO = OO.tameInfo) && void 0 !== wO && wO.supportsFriendship) {
          var PO, mK;
          let KO = null !== (PO = OO.tameInfo.likedFoods) && void 0 !== PO ? PO : [];
          jK.push({
            str: "\n"
          }), jK.push({
            icon: "Pixelated Heart",
            style: {
              fontSize: "1.5em",
              color: lO.b.feedTextColours[lO.b.MobFoodType.Superliked]
            }
          }), jK.push({
            str: " "
          }), null !== (mK = OO.petInfo) && void 0 !== mK && mK.superlikedFoodKnown ? (jK.push({
            icon: OO.petInfo.superlikedFood,
            style: {
              fontSize: "1.5em"
            }
          }), KO = KO.filter((KO => KO !== OO.petInfo.superlikedFood))) : jK.push({
            icon: "Question Mark",
            style: {
              fontSize: "1.5em"
            }
          }), jK.push({
            str: "\n"
          }), jK.push({
            icon: "Pixelated Heart",
            style: {
              fontSize: "1.5em",
              color: lO.b.feedTextColours[lO.b.MobFoodType.Liked]
            }
          }), jK.push({
            str: " "
          });
          for (const OO of KO) jK.push({
            icon: OO,
            style: {
              fontSize: "1.5em"
            }
          });
          jK.push({
            str: "\n"
          }), jK.push({
            icon: "Pixelated Heart",
            style: {
              fontSize: "1.5em",
              color: lO.b.feedTextColours[lO.b.MobFoodType.Neutral]
            }
          }), jK.push({
            str: " "
          });
          for (const pO of null !== (sO = OO.tameInfo.neutralFoods) && void 0 !== sO ? sO : []) {
            var sO;
            jK.push({
              icon: pO,
              style: {
                fontSize: "1.5em"
              }
            })
          }
          jK.push({
            str: "\n"
          }), jK.push({
            icon: "Pixelated Heart",
            style: {
              fontSize: "1.5em",
              color: lO.b.feedTextColours[lO.b.MobFoodType.Disliked]
            }
          }), jK.push({
            str: " "
          });
          for (const pO of null !== (HO = OO.tameInfo.dislikedFoods) && void 0 !== HO ? HO : []) {
            var HO;
            jK.push({
              icon: pO,
              style: {
                fontSize: "1.5em"
              }
            })
          }
        }
        jK.length > 0 ? (jK.shift(), jK.unshift(...(0, eO.ob)(EO))) : jK = (0, eO.ob)(EO)
      }
      return {
        name: gK,
        desc: jK,
        fontStyle: null !== (TO = NO.customAttributes) && void 0 !== TO && TO.author ? "italic" : "normal"
      }
    }

    function QO(OO, KO, pO, XO) {
      const bK = CO(OO, pO),
        eO = CO(OO, XO);
      if (!bK) return !1;
      const lO = KO[bK.name].armourReduction,
        vK = KO[eO.name].armourReduction;
      if (vK === lO) {
        var hO, DO, MO, aK;
        const OO = null !== (hO = null === (DO = bK.attributes.customAttributes) || void 0 === DO ? void 0 : DO.enchantmentTier) && void 0 !== hO ? hO : "Tier 0",
          KO = null !== (MO = null === (aK = eO.attributes.customAttributes) || void 0 === aK ? void 0 : aK.enchantmentTier) && void 0 !== MO ? MO : "Tier 0";
        return parseInt(OO.replace("Tier ", "")) >= parseInt(KO.replace("Tier ", ""))
      }
      return lO > vK
    }

    function zK(OO) {
      let KO;
      if ("number" === typeof OO) {
        const pO = document.querySelector(`[data-inven-idx="${OO}"]`);
        if (!pO) return null;
        KO = pO.getBoundingClientRect()
      } else KO = OO.getBoundingClientRect();
      return {
        x: KO.left + KO.width / 2,
        y: KO.top + KO.height / 2
      }
    }
  },
  8268: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => oO,
      e: () => FO,
      i: () => VO
    });
    var XO = pO(1271),
      bK = pO(63),
      eO = pO(1152),
      lO = pO(3719),
      vK = pO(1912),
      CO = pO(1051),
      hO = pO(94),
      DO = pO(1583),
      MO = pO(1180),
      aK = pO(976);

    function oO(OO) {
      let {
        show: KO,
        onClose: pO
      } = OO;
      const {
        requestedGameNameWithVariation: XO,
        lobbyName: bK,
        shownLobbyName: eO
      } = (0, DO.i)("connectedGame"), CO = (0, vK.b)(XO, bK, !1);
      return hO.featureFlags.canUseInviteLinks && (0, aK.jsx)(lO.d, {
        show: KO,
        close: pO,
        padShowsHud: !0,
        togglePointerLock: !1,
        globallyUniqueKey: "InviteLinkBox",
        doGameplayStartStopOnShow: !0,
        children: (0, aK.jsxs)("div", {
          className: "InviteLinkBox AnimFadeInScaleUp",
          children: [(0, aK.jsx)("div", {
            className: "InviteLinkBoxHeader SmallTextBold",
            children: "Invite Friends"
          }), (0, aK.jsxs)("div", {
            className: "InviteLinkBoxDescription SmallTextLight",
            children: [(0, aK.jsx)("div", {
              className: "InviteLinkBoxSubheader SmallTextBold",
              children: '"Join Lobby Name" Button Info'
            }), "Game: ", null === CO ? (0, aK.jsx)(MO.e, {}) : CO, (0, aK.jsx)("br", {}), "Lobby Name: ", eO, (0, aK.jsx)("br", {}), (0, aK.jsx)("br", {}), (0, aK.jsx)("br", {}), (0, aK.jsx)("div", {
              className: "InviteLinkBoxSubheader SmallTextBold",
              children: "Link"
            })]
          }), (0, aK.jsx)(FO, {})]
        })
      })
    }

    function FO() {
      var OO;
      const {
        t: KO
      } = (0, CO.D)(), pO = null !== (OO = VO(hO.featureFlags.canUseInviteLinks)) && void 0 !== OO ? OO : "Loading Link...", [eO, lO] = (0, bK.useState)(0), [vK, DO] = (0, bK.useReducer)((OO => OO + 1), 0);
      return (0, bK.useEffect)((() => {
        const OO = setTimeout((() => {
          DO()
        }), 1100);
        return () => {
          clearTimeout(OO)
        }
      }), [eO]), hO.featureFlags.canUseInviteLinks && (0, aK.jsxs)("div", {
        className: "InviteLinkInnerWrapper",
        children: [(0, aK.jsx)("div", {
          className: "InviteLinkInner",
          children: pO
        }), (0, aK.jsx)(XO.d, {
          className: "InviteLinkCopyButton",
          onClick: () => {
            navigator.clipboard.writeText(pO).catch((OO => {
              console.error("Failed to copy invite link:", OO)
            })), lO(Date.now())
          },
          disabled: Date.now() - eO < 1e3,
          children: Date.now() - eO < 1e3 ? KO("general:copied") : KO("general:copy")
        })]
      })
    }

    function VO(OO) {
      const [KO, pO] = (0, bK.useState)(null);
      return (0, bK.useEffect)((() => {
        if (!OO) return;
        let KO = !0;
        return (0, eO.I)().then((OO => {
          KO && pO(OO)
        })).catch((OO => {
          console.error("Failed to get invite link:", OO)
        })), () => {
          KO = !1
        }
      }), [OO]), KO
    }
  },
  35477: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => IO
    });
    var XO = pO(63),
      bK = pO(1991),
      eO = pO(1533),
      lO = pO(512),
      vK = pO(26),
      CO = pO(918),
      hO = pO.n(CO),
      DO = pO(35095),
      MO = pO(2070),
      aK = pO(35102),
      oO = pO(2097),
      FO = pO(2077),
      VO = pO(2855),
      LO = pO(22),
      QO = pO(1631),
      zK = pO(1925),
      AO = pO(1077),
      fO = pO(4041),
      dO = pO(1583),
      TO = pO(94),
      NO = pO(976);
    const IO = (0, XO.memo)((function() {
      const OO = (0, bK.i)("lobbyLeaderboardInfo"),
        KO = (0, dO.i)("players"),
        pO = (0, dO.i)("lobbyLeaderboardRows"),
        vK = (0, dO.i)("hiddenPlayerNames"),
        CO = (0, XO.useRef)(null),
        [hO, DO] = (0, XO.useReducer)((OO => OO + 1), 0);
      return (0, XO.useEffect)((() => (0, QO.d)((() => {
        DO()
      }))), []), (0, NO.jsx)("div", {
        className: "LobbyLeaderboardContainer Menu",
        children: (0, NO.jsx)("div", {
          className: "MenuBody",
          children: function() {
            if (!OO) return (0, NO.jsx)(NO.Fragment, {});
            const XO = JSON.parse(JSON.stringify(OO)),
              bK = [...KO.ids],
              hO = {},
              DO = {};
            for (const OO of bK) {
              var MO, oO;
              hO[OO] = null === (MO = pO[OO]) || void 0 === MO ? void 0 : MO.colour;
              const KO = null === (oO = pO[OO]) || void 0 === oO ? void 0 : oO.values;
              KO && (DO[OO] = {
                ...KO
              })
            }
            const FO = Object.keys(XO);
            FO.sort(((OO, KO) => XO[OO].sortPriority - XO[KO].sortPriority)), bK.sort(((OO, KO) => {
              if (!DO[OO] || !DO[KO]) return 0;
              for (const pO of FO) {
                const bK = DO[OO][pO],
                  eO = DO[KO][pO];
                let lO = 0;
                if ("string" == typeof bK && "string" == typeof eO ? lO = bK.localeCompare(eO) : "number" == typeof bK && "number" == typeof eO ? lO = bK - eO : "number" == typeof bK && "string" == typeof eO ? lO = 1 : "string" == typeof bK && "number" == typeof eO && (lO = -1), lO) return lO * ("ascending" === XO[pO].sortOrder ? 1 : -1)
              }
              return 0
            }));
            for (const OO of bK) {
              var VO, LO, dO;
              const {
                name: XO,
                ranks: bK,
                cosmetics: eO
              } = KO.byId[OO], vK = [], CO = null !== (VO = null === (LO = pO[OO]) || void 0 === LO || null === (dO = LO.tags) || void 0 === dO ? void 0 : dO.flatMap((OO => 0 === OO.length ? OO : [...OO, String.fromCharCode(8198)]))) && void 0 !== VO ? VO : [];
              vK.push(...CO), vK.push(...(0, AO.v)(bK, XO, (null === eO || void 0 === eO ? void 0 : eO.nameColour) === lO.b || null === eO || void 0 === eO ? void 0 : eO.nameColour)), DO[OO] ??= {}, DO[OO].name = vK
            }

            function TO(OO, pO) {
              if (DO[OO] && void 0 !== DO[OO][pO]) {
                if ("name" === pO) {
                  const {
                    name: XO,
                    cosmetics: bK
                  } = KO.byId[OO];
                  return (0, NO.jsxs)("div", {
                    className: "PlayerPfpAndName",
                    children: [bK && (0, NO.jsx)(zK.c, {
                      cosmetics: bK
                    }), " ", (0, NO.jsx)(eO.d, {
                      text: DO[OO][pO],
                      friendBadgeFor: (0, QO.g)(XO, vK) ? XO : void 0
                    })]
                  })
                }
                return (0, NO.jsx)(eO.d, {
                  text: DO[OO][pO]
                })
              }
              return ""
            }
            const IO = Object.keys(XO).filter((OO => !0 !== XO[OO].hidden)).map((OO => {
              var KO;
              return {
                key: OO,
                header: (0, NO.jsx)(eO.d, {
                  text: null !== (KO = XO[OO].displayName) && void 0 !== KO ? KO : ""
                })
              }
            }));
            return (0, NO.jsx)("div", {
              ref: CO,
              className: "LobbyLeaderboard",
              children: (0, NO.jsx)(fO.c, {
                columns: IO,
                rows: bK,
                getRowKey: OO => OO,
                renderRow: OO => {
                  const pO = OO !== KO.localId;
                  return (0, NO.jsx)(yK, {
                    playerId: OO,
                    playerName: KO.byId[OO].name,
                    isOtherPlayer: pO,
                    opensProfileCard: (0, aK.i)(pO, KO.byId[OO].name, vK),
                    lobbyLeaderboardInfo: XO,
                    getPlayerValue: TO,
                    playerColors: hO
                  })
                }
              })
            })
          }()
        })
      })
    }));

    function yK(OO) {
      let {
        playerId: KO,
        playerName: pO,
        isOtherPlayer: bK,
        opensProfileCard: eO,
        lobbyLeaderboardInfo: lO,
        getPlayerValue: CO,
        playerColors: QO
      } = OO;
      const zK = (0, XO.useRef)(null);
      (0, XO.useEffect)((() => () => {
        MO.b.closeIfOwner(zK)
      }), []);
      const AO = {
          icon: "flag",
          text: "Report",
          onClick: () => {
            vK.i.pl("OpenReportMenu", {
              playerEId: KO,
              playerName: pO,
              Tl: null,
              serverChatMsgId: null
            })
          }
        },
        fO = () => ({
          ...(0, aK.e)(KO, pO),
          showLocation: !1,
          status: null,
          extraActions: [AO],
          friendRequestSource: "leaderboard"
        });
      return (0, NO.jsxs)("tr", {
        ref: zK,
        "data-pad-focusable": eO || void 0,
        [MO.e]: eO || void 0,
        onClick: eO ? () => {
          var OO;
          MO.b.toggle(zK, {
            ...fO(),
            anchor: null !== (OO = zK.current.querySelector(".PlayerPfpAndName")) && void 0 !== OO ? OO : zK.current
          })
        } : void 0,
        onContextMenu: eO ? OO => {
          (0, oO.d)(zK, OO, fO(), LO.d.get("isTouchScreen"))
        } : void 0,
        onPointerDown: eO ? OO => {
          (0, FO.e)(OO, (() => (0, aK.e)(KO, pO).playerSocialPreview))
        } : void 0,
        children: [Object.keys(lO).map((OO => !0 === lO[OO].hidden ? null : (0, NO.jsxs)("td", {
          className: hO()("LobbyLeaderboardValue SmallTextBold", {
            LobbyLeaderboardValueHighlighted: !bK
          }),
          children: [(0, NO.jsx)("div", {
            className: "LobbyLeaderboardValueText",
            children: CO(KO, OO)
          }), (0, NO.jsx)("div", {
            className: "LobbyLeaderboardValueBg",
            style: {
              backgroundColor: QO[KO]
            }
          })]
        }, OO))), bK && !eO && (0, NO.jsx)(DO.d, {
          className: "LobbyLeaderboardRowFloatingActions",
          triggerElementRef: zK,
          options: [{
            icon: AO.icon,
            text: AO.text,
            onPointerDown: AO.onClick
          }, ...null === pO || TO.featureFlags.useSocialFeatures ? [] : (0, VO.c)(null, pO)]
        })]
      })
    }
  },
  3908: (OO, KO, pO) => {
    pO.d(KO, {
      f: () => zK,
      b: () => QO
    });
    var XO = pO(63),
      bK = pO(1263),
      eO = pO(1533),
      lO = pO(3912),
      vK = pO(976);
    const CO = (0, XO.memo)((function(OO) {
      let {
        initialParameters: KO
      } = OO;
      const pO = (0, XO.useRef)(null),
        bK = (0, XO.useRef)(null),
        CO = (0, XO.useRef)(0),
        hO = (0, XO.useRef)(null),
        DO = KO.description,
        MO = KO.e_,
        {
          scale: aK,
          rotation: oO
        } = null !== KO && void 0 !== KO ? KO : {},
        FO = (0, lO.e)();
      return (0, XO.useEffect)((() => {
        const OO = FO.onFrame((() => {
          const OO = FO.getState();
          if (!OO.isActive || !pO.current || !bK.current) return;
          const KO = OO.state;
          if (pO.current.value = KO.progress, KO.clickCount > CO.current) {
            CO.current = KO.clickCount;
            const OO = bK.current;
            OO.classList.add("pulse"), hO.current = setTimeout((() => {
              OO.classList.remove("pulse")
            }), 100)
          }
        }));
        return () => {
          clearTimeout(hO.current), OO()
        }
      }), [FO]), (0, vK.jsx)(vK.Fragment, {
        children: (0, vK.jsxs)("div", {
          className: "QTEProgressBarWrapper",
          style: {
            ...null !== aK && {
              "--scale": aK
            },
            ...null !== oO && {
              "--rotation": `${oO}deg`
            }
          },
          children: [(0, vK.jsx)("progress", {
            id: "catch",
            max: 100,
            className: "QTEProgressBar",
            ref: pO
          }), (0, vK.jsx)("span", {
            className: "QTEProgressBarInteractionIndicator",
            ref: bK,
            children: (0, vK.jsx)(eO.d, {
              text: [{
                icon: MO
              }]
            })
          }), (0, vK.jsx)("div", {
            className: "QTEProgressBarDescription",
            children: (0, vK.jsx)(eO.d, {
              text: DO
            })
          })]
        })
      })
    }));
    var hO = pO(918),
      DO = pO.n(hO);
    const MO = 2 * Math.PI * 90,
      aK = (0, XO.memo)((function(OO) {
        let {
          initialParameters: KO
        } = OO;
        const pO = (0, XO.useRef)(null),
          bK = (0, XO.useRef)(null),
          CO = (0, XO.useRef)(null),
          hO = KO.label,
          aK = KO.icon,
          oO = KO.M_,
          {
            scale: FO,
            rotation: VO,
            o_: LO
          } = null !== KO && void 0 !== KO ? KO : {},
          QO = (0, lO.e)();
        return (0, XO.useEffect)((() => {
          const OO = QO.onFrame((() => {
            var OO, KO;
            const XO = QO.getState();
            if (!XO.isActive || !bK.current) return;
            const eO = XO.state,
              lO = null !== (OO = eO.timeRemaining) && void 0 !== OO ? OO : 0,
              vK = null !== (KO = eO.h_) && void 0 !== KO ? KO : 1,
              hO = MO * (1 - lO / vK);
            bK.current.style.strokeDashoffset = `${hO}`, pO.current && (pO.current.style.opacity = lO > 0 ? "1" : "0"), CO.current && oO && (CO.current.textContent = `${(lO/1e3).toFixed(1)}s`)
          }));
          return () => {
            OO()
          }
        }), [QO, oO]), (0, vK.jsxs)("div", {
          className: "QTETimedClick",
          ref: pO,
          style: {
            ...null !== FO && {
              "--scale": FO
            },
            ...null !== VO && {
              "--rotation": `${VO}deg`
            }
          },
          children: [(0, vK.jsxs)("div", {
            className: "QTETimedClickCircleContainer",
            children: [(0, vK.jsxs)("svg", {
              className: "QTETimedClickCircularProgress",
              viewBox: "0 0 200 200",
              children: [(0, vK.jsx)("circle", {
                className: "QTETimedClickProgressTrack",
                cx: "100",
                cy: "100",
                r: 90,
                fill: "none",
                strokeWidth: "12"
              }), (0, vK.jsx)("circle", {
                className: "QTETimedClickProgressArc",
                cx: "100",
                cy: "100",
                r: 90,
                fill: "none",
                strokeWidth: "12",
                strokeLinecap: "square",
                strokeDasharray: MO,
                ref: bK
              })]
            }), (0, vK.jsx)("div", {
              className: "QTETimedClickCenterContent",
              children: (0, vK.jsx)(eO.d, {
                text: [{
                  icon: aK
                }],
                className: DO()("QTETimedClickInnerText", {
                  QTETimedClickBreathe: LO
                })
              })
            })]
          }), (0, vK.jsxs)("div", {
            className: "QTETimedClickRightTextContainer",
            children: [(0, vK.jsx)(eO.d, {
              text: hO,
              className: "QTETimedClickLabelText"
            }), oO && (0, vK.jsx)("span", {
              className: "QTETimedClickTimeText",
              ref: CO
            })]
          })]
        })
      })),
      oO = (0, XO.memo)((function(OO) {
        let {
          initialParameters: KO
        } = OO;
        const pO = (0, XO.useRef)(null),
          bK = (0, XO.useRef)(null),
          CO = (0, XO.useRef)(null),
          hO = (0, XO.useRef)(!1),
          DO = KO.description,
          MO = null === KO || void 0 === KO ? void 0 : KO.icon,
          aK = (0, lO.e)();
        return (0, XO.useEffect)((() => {
          const OO = aK.onFrame((() => {
            const OO = aK.getState();
            if (!OO.isActive) return;
            const KO = OO.state;
            if (pO.current) {
              const OO = 100 * (KO.catchZonePosition - KO.L_ / 2);
              pO.current.style.left = `${OO}%`, pO.current.style.width = 100 * KO.L_ + "%", KO.isCatching !== hO.current && (hO.current = KO.isCatching, KO.isCatching ? pO.current.classList.add("catching") : pO.current.classList.remove("catching"))
            }
            bK.current && (bK.current.style.left = 100 * KO.moverPosition + "%"), CO.current && (CO.current.value = KO.progress)
          }));
          return () => {
            OO()
          }
        }), [aK]), (0, vK.jsxs)("div", {
          className: "QTEGravityBar",
          children: [(0, vK.jsx)("div", {
            className: "QTEGravityBarDescription",
            children: (0, vK.jsx)(eO.d, {
              text: DO
            })
          }), (0, vK.jsx)("progress", {
            max: 100,
            className: "QTEGravityBarProgress",
            ref: CO
          }), (0, vK.jsxs)("div", {
            className: "QTEGravityBarTrack",
            children: [(0, vK.jsx)("div", {
              className: "QTEGravityBarCatchZone",
              ref: pO
            }), (0, vK.jsx)("div", {
              className: "QTEGravityBarMover",
              ref: bK,
              children: (0, vK.jsx)("span", {
                children: MO && (0, vK.jsx)(eO.d, {
                  text: [{
                    icon: MO,
                    style: {
                      fontSize: "4rem"
                    }
                  }]
                })
              })
            })]
          })]
        })
      }));
    var FO = pO(533);
    const VO = (0, XO.memo)((function(OO) {
        let {
          initialParameters: KO
        } = OO;
        const pO = (0, XO.useRef)(null),
          bK = KO.label,
          CO = KO.Y_,
          {
            icon: hO,
            scale: DO,
            rotation: MO
          } = null !== KO && void 0 !== KO ? KO : {},
          aK = 100 * (.5 - CO / 2),
          oO = 100 * CO,
          VO = (0, lO.e)();
        return (0, XO.useEffect)((() => {
          const OO = VO.onFrame((() => {
            const OO = VO.getState();
            if (!OO.isActive || !pO.current) return;
            const KO = OO.state;
            pO.current.style.left = 100 * KO.markerPosition + "%"
          }));
          return () => {
            OO()
          }
        }), [VO]), (0, vK.jsxs)("div", {
          className: "QTEPrecisionBarWrapper",
          style: {
            ...!(0, FO.I)(DO) && {
              "--scale": DO
            },
            ...!(0, FO.I)(MO) && {
              "--rotation": `${MO}deg`
            }
          },
          children: [hO && (0, vK.jsx)(eO.d, {
            text: [{
              icon: hO
            }],
            className: "QTEPrecisionBarIcon"
          }), (0, vK.jsxs)("div", {
            className: "QTEPrecisionBarTrack",
            children: [(0, vK.jsx)("div", {
              className: "QTEPrecisionBarSuccessZone",
              style: {
                left: `${aK}%`,
                width: `${oO}%`
              }
            }), (0, vK.jsx)("div", {
              className: "QTEPrecisionBarMarker",
              ref: pO
            })]
          }), (0, vK.jsx)("div", {
            className: "QTEPrecisionBarLabel",
            children: (0, vK.jsx)(eO.d, {
              text: bK
            })
          })]
        })
      })),
      LO = (0, XO.memo)((function(OO) {
        let {
          initialParameters: KO
        } = OO;
        const pO = (0, XO.useRef)(null),
          [bK, CO] = (0, XO.useState)((() => new Array(KO.R_).fill("pending"))),
          [hO, DO] = (0, XO.useState)((() => {
            const OO = KO.B_;
            return (0, FO.I)(OO) || OO <= 0 ? [] : new Array(OO).fill("pending")
          })),
          MO = KO.label,
          {
            icon: aK
          } = KO,
          oO = (0, XO.useRef)(0),
          VO = (0, XO.useRef)(0),
          LO = (0, XO.useRef)([]),
          QO = (0, lO.e)();
        return (0, XO.useEffect)((() => {
          const OO = QO.onFrame((() => {
            const OO = QO.getState();
            if (!OO.isActive || !pO.current) return;
            const KO = OO.state,
              XO = 30 + 60 * KO.outerCircleProgress;
            if (pO.current.setAttribute("r", String(XO)), !0 === KO.lastClickResult && KO.successes > oO.current) {
              pO.current.classList.remove("QTERhythmClickOuterCircle--miss"), pO.current.classList.add("QTERhythmClickOuterCircle--hit");
              const OO = setTimeout((() => {
                var OO;
                null === (OO = pO.current) || void 0 === OO || OO.classList.remove("QTERhythmClickOuterCircle--hit")
              }), 200);
              LO.current.push(OO)
            } else if (!1 === KO.lastClickResult && KO.misses > VO.current) {
              pO.current.classList.remove("QTERhythmClickOuterCircle--hit"), pO.current.classList.add("QTERhythmClickOuterCircle--miss");
              const OO = setTimeout((() => {
                var OO;
                null === (OO = pO.current) || void 0 === OO || OO.classList.remove("QTERhythmClickOuterCircle--miss")
              }), 200);
              LO.current.push(OO)
            }
            KO.successes === oO.current && KO.misses === VO.current || (oO.current = KO.successes, VO.current = KO.misses, CO((OO => {
              const pO = [...OO];
              for (let XO = 0; XO < KO.R_; XO++) pO[XO] = XO < KO.successes ? "success" : "pending";
              return pO
            })), DO((OO => {
              if (0 === OO.length) return OO;
              const pO = [...OO];
              for (let XO = 0; XO < pO.length; XO++) pO[XO] = XO < KO.misses ? "miss" : "pending";
              return pO
            })))
          }));
          return () => {
            OO();
            for (const OO of LO.current) clearTimeout(OO);
            LO.current = []
          }
        }), [QO]), (0, vK.jsxs)("div", {
          className: "QTERhythmClickWrapper",
          children: [(0, vK.jsx)("div", {
            className: "QTERhythmClickProgress",
            children: bK.map(((OO, KO) => (0, vK.jsx)("div", {
              className: "QTERhythmClickDot" + ("success" === OO ? " QTERhythmClickDot--success" : " QTERhythmClickDot--pendingSuccess")
            }, KO)))
          }), (0, vK.jsxs)("div", {
            className: "QTERhythmClickCircleContainer",
            children: [(0, vK.jsxs)("svg", {
              className: "QTERhythmClickSvg",
              viewBox: "0 0 200 200",
              children: [(0, vK.jsx)("circle", {
                className: "QTERhythmClickInnerCircle",
                cx: "100",
                cy: "100",
                r: 30
              }), (0, vK.jsx)("circle", {
                className: "QTERhythmClickOuterCircle",
                cx: "100",
                cy: "100",
                r: 90,
                ref: pO
              })]
            }), aK && (0, vK.jsx)("div", {
              className: "QTERhythmClickCenterContent",
              children: (0, vK.jsx)(eO.d, {
                text: [{
                  icon: aK
                }],
                className: "QTERhythmClickIcon"
              })
            })]
          }), hO.length > 0 && (0, vK.jsx)("div", {
            className: "QTERhythmClickProgress",
            children: hO.map(((OO, KO) => (0, vK.jsx)("div", {
              className: "QTERhythmClickDot" + ("miss" === OO ? " QTERhythmClickDot--miss" : " QTERhythmClickDot--pendingMiss")
            }, KO)))
          }), (0, vK.jsx)("div", {
            className: "QTERhythmClickLabel",
            children: (0, vK.jsx)(eO.d, {
              text: MO
            })
          })]
        })
      }));

    function QO(OO) {
      let {
        qte: KO
      } = OO;
      switch (KO.type) {
        case "progressBar":
          return (0, vK.jsx)(CO, {
            initialParameters: KO.parameters
          });
        case "timedClick":
          return (0, vK.jsx)(aK, {
            initialParameters: KO.parameters
          });
        case "gravityBar":
          return (0, vK.jsx)(oO, {
            initialParameters: KO.parameters
          });
        case "precisionBar":
          return (0, vK.jsx)(VO, {
            initialParameters: KO.parameters
          });
        case "rhythmClick":
          return (0, vK.jsx)(LO, {
            initialParameters: KO.parameters
          });
        default:
          return console.warn("Unknown QTE type"), null
      }
    }
    const zK = (0, XO.memo)((function() {
      const [OO, KO] = (0, XO.useState)({
        type: null,
        parameters: null,
        state: null,
        isActive: !1
      });
      return (0, bK.f)("qteStateUpdated", (OO => {
        KO(OO)
      })), OO.isActive && OO.type ? (0, vK.jsx)("div", {
        className: "QTE",
        "data-camera-keeper": "",
        children: (0, vK.jsx)(QO, {
          qte: OO
        })
      }) : null
    }))
  },
  3912: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK,
      e: () => CO
    });
    var XO = pO(63),
      bK = pO(1146),
      eO = pO(3916);
    const lO = {
        getState: () => eO.e.getCurrentState(),
        onFrame: bK.g
      },
      vK = (0, XO.createContext)(lO);

    function CO() {
      return (0, XO.useContext)(vK)
    }
  },
  8303: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => hO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(1583),
      vK = pO(976);

    function CO(OO) {
      const KO = Math.floor(OO / 3600),
        pO = Math.floor(OO % 3600 / 60),
        XO = Math.floor(OO % 60),
        bK = `${pO.toString().padStart(2,"0")}:${XO.toString().padStart(2,"0")}`;
      return KO > 0 ? `${KO}:${bK}` : bK
    }
    const hO = (0, XO.memo)((function(OO) {
      let {
        className: KO
      } = OO;
      const {
        recording: pO,
        seconds: XO
      } = (0, lO.i)("replayRecorder");
      return pO ? (0, vK.jsxs)("div", {
        className: eO()("RecordingIndicator", KO),
        children: [(0, vK.jsx)("span", {
          className: "RecordingIndicatorDot"
        }), (0, vK.jsx)("span", {
          className: "RecordingIndicatorLabel",
          children: "REC"
        }), (0, vK.jsx)("span", {
          className: "RecordingIndicatorTime",
          children: CO(XO)
        })]
      }) : null
    }))
  },
  34934: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => DO,
      d: () => aK
    });
    var XO = pO(63),
      bK = pO(1187),
      eO = pO(1051),
      lO = pO(1180),
      vK = pO(2730),
      CO = pO(4054),
      hO = pO(976);

    function DO(OO) {
      let {
        loading: KO,
        schematics: pO,
        onSchematicPicked: XO,
        selectedSchematicIdList: bK = [],
        disableAutoExport: CO
      } = OO;
      const {
        t: DO
      } = (0, eO.D)();
      return (0, hO.jsxs)("div", {
        className: "SchematicList",
        children: [KO && (0, hO.jsx)(lO.e, {}), !KO && 0 === pO.length && (0, hO.jsx)("div", {
          className: "NoSchematicsText",
          children: DO("worldBuilder:noSavedSchematic")
        }), !KO && pO.map((OO => (0, hO.jsx)(vK.f, {
          source: {
            type: "schematic",
            schematic: OO
          },
          gameWidth: "25%",
          useLongRatio: !0,
          onClick: () => {
            XO(OO)
          },
          isSelected: bK.includes(OO.schematicId),
          hideCcu: !0,
          hideFavourites: !0,
          showPublishedChip: !0,
          hideUnpublishedChip: !0,
          disabled: OO.isAutoExported && CO,
          disabledReason: "worldBuilder:autoExportDisabled"
        }, OO.schematicId)))]
      })
    }

    function MO(OO) {
      let {
        ownedSchematics: KO,
        currentWorldSchematicId: pO,
        onClose: bK
      } = OO;
      const {
        t: lO
      } = (0, eO.D)(), [vK, MO] = (0, XO.useState)(null);
      return (0, hO.jsxs)("div", {
        className: "SchematicListWindow",
        children: [null === vK && (0, hO.jsxs)(hO.Fragment, {
          children: [(0, hO.jsx)("h1", {
            className: "SchematicPopupTitle",
            children: lO("worldBuilder:schematicList")
          }), (0, hO.jsx)("h2", {
            className: "SchematicPopupSubtitle",
            children: lO("worldBuilder:clickSchematicForOptions")
          }), (0, hO.jsx)("div", {
            className: "SchematicPopupSchematicListContainer",
            children: (0, hO.jsx)(DO, {
              loading: !1,
              schematics: KO,
              onSchematicPicked: OO => {
                MO(OO)
              },
              disableAutoExport: !1
            })
          })]
        }), null !== vK && (0, hO.jsx)(CO.f, {
          schematic: vK,
          inSourceWorld: vK.schematicId === pO,
          onSchematicUpdate: OO => {
            MO(OO)
          },
          onClose: () => {
            MO(null), bK()
          }
        })]
      })
    }

    function aK(OO) {
      let {
        ownedSchematics: KO,
        currentWorldSchematicId: pO,
        onClose: XO
      } = OO;
      bK.NotificationProvider.showCustomPopup({
        body: OO => (0, hO.jsx)(MO, {
          ownedSchematics: KO,
          currentWorldSchematicId: pO,
          onClose: OO
        }),
        middleScreenPopupClassName: "SchematicPopup",
        onClose: XO,
        unlockPointerKey: "schematicListPopup"
      })
    }
  },
  35402: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => dO,
      f: () => fO
    });
    var XO = pO(3533),
      bK = pO(1263),
      eO = pO(63),
      lO = pO(5628),
      vK = pO(3523),
      CO = pO(1136),
      hO = pO(1556),
      DO = pO(1533),
      MO = pO(1271),
      aK = pO(1051),
      oO = pO(35409),
      FO = pO(918),
      VO = pO.n(FO),
      LO = pO(1152),
      QO = pO(933),
      zK = pO(1134),
      AO = pO(976);
    const fO = "SleepingOverlay";

    function dO() {
      const {
        t: OO
      } = (0, aK.D)(), [KO, pO] = (0, eO.useState)(!1), [FO, dO] = (0, eO.useState)(null), [NO, IO] = (0, eO.useState)(1), [yK, gK] = (0, eO.useState)(!1), [uO, EO] = (0, eO.useState)(!1), jK = (0, eO.useRef)(0), YO = (0, eO.useRef)(!1), wO = (0, eO.useRef)(!1), iK = (0, eO.useRef)(), rK = (0, eO.useRef)(null);

      function PO() {
        const OO = null !== FO && void 0 !== FO ? FO : "Rested Speed";
        hO.gameBridge.send("wakeUp", uO ? OO : null), rK.current = null, pO(!1), dO(null), IO(1), gK(!1), EO(!1)
      }

      function mK() {
        return !yK && (PO(), !0)
      }
      return (0, bK.f)("PlayerPhysicsTypeUpdate", (OO => {
        OO !== rK.current && (rK.current = OO, OO === lO.p.SLEEPING ? (wO.current || (jK.current = hO.gameBridge.lookup("cameraZoom", null), wO.current = !0), YO.current = !0, hO.gameBridge.send("setCameraZoom", 3), pO(!0), IO(function() {
          for (const OO of hO.gameBridge.lookup("blocksStandingOn", null)) {
            if (oO.d.leafBeds.includes(OO)) return console.log(`Found leaf bed: ${OO}`), 1;
            if (oO.d.woolBeds.includes(OO)) return console.log(`Found woold bed: ${OO}`), 2;
            if (oO.d.strongBeds.includes(OO)) return console.log(`Found strong bed ${OO}`), 3
          }
          return 1
        }())) : (wO.current = !1, pO(!1), dO(null), IO(1)))
      })), (0, eO.useEffect)((() => () => {
        (0, CO.j)(fO)
      }), []), (0, eO.useEffect)((() => {
        KO ? (0, CO.k)(fO) : ((0, CO.j)(fO), YO.current && (hO.gameBridge.send("setCameraZoom", jK.current), YO.current = !1))
      }), [KO]), (0, zK.q)("overlay", iK, mK, KO), (0, AO.jsx)(XO.d, {
        className: "SleepingOverlay",
        "data-camera-keeper": "",
        in: KO,
        timeout: 300,
        nodeRef: iK,
        unmountOnExit: !0,
        children: (0, AO.jsx)("div", {
          ref: iK,
          onClick: OO => {
            mK() && OO.stopPropagation()
          },
          children: (0, AO.jsxs)("div", {
            className: "SleepingOverlayBody",
            children: [(0, AO.jsx)("div", {
              className: "SleepingOverlayPerkList",
              children: vK.f.map((KO => (0, AO.jsxs)(TO, {
                restedEffect: KO,
                LJ: FO,
                setChosenRestedEffect: dO,
                children: [(0, AO.jsxs)("div", {
                  className: "SleepingOverlayPerkTitle",
                  children: [(0, AO.jsx)(DO.d, {
                    text: [{
                      icon: KO
                    }]
                  }), vK.d[KO].shortName]
                }), (0, AO.jsx)("div", {
                  className: "SleepingOverlayPerkDescription",
                  children: OO(vK.d[KO].description, {
                    time: vK.d[KO].effectLevelDurations[NO] / 6e4
                  })
                })]
              }, KO)))
            }), (0, AO.jsxs)("div", {
              className: "SleepingOverlayPerkBottom",
              children: [(0, AO.jsx)("div", {
                className: "SleepingOverlayPerkBottomSide"
              }), (0, AO.jsxs)(MO.d, {
                className: "SleepingOverlayWakeUpButton",
                onClick: OO => {
                  uO ? PO() : (gK(!0), (0, LO.mb)((() => {
                    gK(!1), EO(!0)
                  }), !0)), OO.stopPropagation()
                },
                loading: yK,
                children: [!uO && (0, AO.jsxs)(AO.Fragment, {
                  children: [(0, AO.jsx)(QO.d, {
                    name: "film"
                  }), " ", OO("classicGame:watchAdToGetRestedPerk")]
                }), uO && OO("classicGame:wakeUp")]
              }), (0, AO.jsxs)("div", {
                className: "SleepingOverlayPerkBottomSide",
                children: [(0, AO.jsx)("div", {
                  className: VO()("SleepingOverlayBedIcon", {
                    SleepingOverlayBedIconActive: 1 === NO
                  }),
                  children: (0, AO.jsx)(DO.d, {
                    text: [{
                      icon: "Leaf Bed"
                    }]
                  })
                }), (0, AO.jsx)("div", {
                  className: VO()("SleepingOverlayBedIcon", {
                    SleepingOverlayBedIconActive: 2 === NO
                  }),
                  children: (0, AO.jsx)(DO.d, {
                    text: [{
                      icon: "Red Bed"
                    }]
                  })
                }), (0, AO.jsx)("div", {
                  className: VO()("SleepingOverlayBedIcon", {
                    SleepingOverlayBedIconActive: 3 === NO
                  }),
                  children: (0, AO.jsx)(DO.d, {
                    text: [{
                      icon: "Red Strongbed"
                    }]
                  })
                })]
              })]
            })]
          })
        })
      })
    }
    const TO = (0, eO.memo)((function(OO) {
      let {
        children: KO,
        restedEffect: pO,
        LJ: XO,
        setChosenRestedEffect: bK
      } = OO;
      return pO === XO ? (0, AO.jsx)(MO.m, {
        onClick: OO => {
          OO.stopPropagation()
        },
        children: KO
      }) : (0, AO.jsx)(MO.e, {
        onClick: OO => {
          bK(pO), OO.stopPropagation()
        },
        children: KO
      })
    }))
  },
  35102: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => hO,
      i: () => CO
    });
    var XO = pO(512),
      bK = pO(1556),
      eO = pO(1446),
      lO = pO(94),
      vK = pO(1119);

    function CO(OO, KO, pO) {
      return lO.featureFlags.useSocialFeatures && OO && null === (0, vK.e)(KO, pO)
    }

    function hO(OO, KO) {
      var pO, lO;
      const vK = eO.e.getSocialState().friends.find((OO => OO.name.toLowerCase() === KO.toLowerCase())),
        CO = bK.gameBridge.latest("players").byId[OO],
        hO = void 0 !== CO && CO.name === KO,
        DO = hO && null !== (pO = CO.cosmetics) && void 0 !== pO ? pO : void 0,
        MO = vK && DO ? {
          ...vK,
          cosmetics: DO
        } : vK;
      return {
        playerSocialPreview: null !== MO && void 0 !== MO ? MO : {
          isError: !1,
          name: KO,
          ranks: hO ? [...CO.ranks] : [],
          cosmetics: null !== DO && void 0 !== DO ? DO : {},
          nameColour: null !== (lO = null === DO || void 0 === DO ? void 0 : DO.nameColour) && void 0 !== lO ? lO : XO.b,
          location: {
            status: "inGame"
          }
        },
        isFriend: void 0 !== vK
      }
    }
  },
  35072: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => MO,
      i: () => oO,
      k: () => aK,
      l: () => VO,
      m: () => FO,
      p: () => DO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(35075),
      vK = pO(26),
      CO = pO(1969),
      hO = pO(976);

    function DO(OO, KO) {
      const pO = (0, XO.useRef)(null);
      return (0, XO.useLayoutEffect)((() => (lO.d.set(OO, pO.current, KO), () => {
        lO.d.set(OO, null)
      })), [OO, KO]), pO
    }
    const MO = "touchKeysChanged",
      aK = {
        Crouch: "C",
        Jump: "J",
        Use: "U",
        Primary: "P",
        Attack: "A",
        Game: "G",
        Context: "X"
      },
      oO = (0, XO.forwardRef)((function(OO, KO) {
        let {
          slot: pO,
          canvasZone: bK = !1,
          lit: lO = !1,
          label: CO,
          className: DO,
          children: aK,
          ...oO
        } = OO;
        return (0, XO.useEffect)((() => (vK.i.pl(MO), () => {
          vK.i.pl(MO)
        })), []), (0, hO.jsx)("div", {
          ref: KO,
          className: eO()("TouchKeyHit", `TouchSlot${pO}`, DO, {
            CanvasZone: bK
          }),
          ...oO,
          children: (0, hO.jsxs)("div", {
            className: eO()("TouchKey", {
              Lit: lO,
              Labelled: void 0 !== CO
            }),
            children: [aK, void 0 !== CO && (0, hO.jsx)("span", {
              className: "TouchKeyLabel",
              children: CO
            })]
          })
        })
      }));

    function FO(OO, KO) {
      (0, XO.useEffect)((() => () => {
        KO.current && (KO.current = !1, (0, CO.u)(OO, !1, {
          isTrusted: !0,
          timeStamp: performance.now()
        }))
      }), [])
    }

    function VO(OO, KO) {
      const pO = KO ? [aK.Context] : [aK.Primary, aK.Context];
      return OO.filter((OO => null !== OO)).slice(0, pO.length).map(((OO, KO) => {
        const bK = pO[KO];
        return (0, hO.jsx)(XO.Fragment, {
          children: OO.render(bK)
        }, `${OO.id}:${bK}`)
      }))
    }
  },
  8311: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(3725),
      bK = pO(3730);

    function eO(OO) {
      let {
        children: KO,
        showing: pO,
        globallyUniqueKey: eO,
        alwaysMountChildren: lO = !1,
        doGameplayStartStopOnShow: vK = !0,
        keepsMovement: CO = !1
      } = OO;
      return (0, bK.b)(!0, pO, eO, CO), (0, XO.e)(vK, pO), pO || lO ? KO : null
    }
  },
  4041: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(976);

    function vK(OO) {
      let {
        columns: KO,
        rows: pO,
        getRowKey: bK,
        renderRow: vK,
        className: CO
      } = OO;
      return (0, lO.jsxs)("table", {
        className: eO()("Table", CO),
        children: [(0, lO.jsx)("thead", {
          children: (0, lO.jsx)("tr", {
            children: KO.map((OO => (0, lO.jsx)("th", {
              children: OO.header
            }, OO.key)))
          })
        }), (0, lO.jsx)("tbody", {
          children: pO.map((OO => (0, lO.jsx)(XO.Fragment, {
            children: vK(OO)
          }, bK(OO))))
        })]
      })
    }
  },
  35367: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => fO,
      f: () => AO,
      j: () => aK
    });
    var XO = pO(63),
      bK = pO(77),
      eO = pO(1201),
      lO = pO(1271),
      vK = pO(1195),
      CO = pO(1134),
      hO = pO(1051),
      DO = pO(35375),
      MO = pO(976);

    function aK(OO) {
      const [KO, pO] = (0, XO.useState)((() => (0, DO.n)(OO)));
      return (0, XO.useEffect)((() => (pO((0, DO.n)(OO)), (0, DO.L)((() => {
        pO((0, DO.n)(OO))
      })))), [OO]), KO
    }

    function oO(OO, KO) {
      "function" === typeof OO ? OO(KO) : OO && (OO.current = KO)
    }

    function FO(OO) {
      let {
        tutorial: KO,
        step: pO,
        enabled: XO = !0
      } = OO;
      const bK = aK(KO);
      return XO && bK === pO
    }

    function VO(OO, KO) {
      const pO = (0, DO.o)(OO),
        XO = pO.indexOf(KO);
      return !pO.slice(XO + 1).some((KO => (0, DO.w)(OO, KO)))
    }

    function LO(OO, KO, pO, XO) {
      let {
        tutorial: bK,
        step: eO,
        waitForClick: lO = !1,
        onPrevious: vK
      } = OO;
      const hO = KO && (0, DO.s)(bK, eO),
        MO = KO && !VO(bK, eO),
        aK = lO ? XO : pO;
      let oO = null;
      hO ? oO = () => {
        null === vK || void 0 === vK || vK(), (0, DO.p)(bK, eO)
      } : MO && (oO = () => {
        (0, DO.l)(bK)
      }), (0, CO.q)("popup", null !== aK && void 0 !== aK ? aK : pO, oO, KO && null !== aK, null, hO ? void 0 : "controller:menusSkipTutorial")
    }

    function QO(OO) {
      let {
        tutorial: KO,
        step: pO,
        text: XO,
        waitForClick: bK = !1,
        onPrevious: eO
      } = OO;
      const {
        t: vK
      } = (0, hO.D)(), CO = VO(KO, pO);
      return (0, MO.jsxs)(MO.Fragment, {
        children: [(0, MO.jsx)("div", {
          className: "TutorialStepText",
          children: XO
        }), (0, MO.jsxs)("div", {
          className: "TutorialStepButtons",
          children: [(0, DO.s)(KO, pO) && (0, MO.jsx)(lO.e, {
            className: "TutorialStepButton",
            onClick: () => {
              null === eO || void 0 === eO || eO(), (0, DO.p)(KO, pO)
            },
            children: vK("tutorial:back")
          }), !bK && (0, MO.jsx)(lO.d, {
            className: "TutorialStepButton",
            onClick: () => {
              (0, DO.e)(pO)
            },
            padDefaultFocus: !0,
            children: vK(CO ? "tutorial:done" : "tutorial:next")
          }), !CO && (0, MO.jsx)(lO.e, {
            className: "TutorialStepButton",
            onClick: () => {
              (0, DO.l)(KO)
            },
            children: vK("tutorial:skip")
          })]
        })]
      })
    }

    function zK(OO) {
      let {
        rect: KO
      } = OO;
      const pO = Math.max(0, KO.top - 6),
        XO = KO.bottom + 6,
        bK = Math.max(0, KO.left - 6),
        eO = KO.right + 6;
      return (0, MO.jsxs)(MO.Fragment, {
        children: [(0, MO.jsx)("div", {
          className: "TutorialSpotlightBackdrop",
          style: {
            top: 0,
            left: 0,
            right: 0,
            height: pO
          }
        }), (0, MO.jsx)("div", {
          className: "TutorialSpotlightBackdrop",
          style: {
            top: XO,
            left: 0,
            right: 0,
            bottom: 0
          }
        }), (0, MO.jsx)("div", {
          className: "TutorialSpotlightBackdrop",
          style: {
            top: pO,
            left: 0,
            width: bK,
            height: XO - pO
          }
        }), (0, MO.jsx)("div", {
          className: "TutorialSpotlightBackdrop",
          style: {
            top: pO,
            left: eO,
            right: 0,
            height: XO - pO
          }
        })]
      })
    }
    const AO = (0, XO.forwardRef)((function(OO, KO) {
      let {
        placement: pO = "right",
        children: lO,
        ...CO
      } = OO;
      const hO = FO(CO),
        DO = (0, XO.useRef)(null),
        aK = (0, XO.useRef)(null);
      LO(CO, hO, DO, aK);
      const {
        getArrowProps: VO,
        getTooltipProps: AO,
        setTooltipRef: fO,
        setTriggerRef: dO
      } = (0, eO.e)({
        placement: pO,
        trigger: null,
        visible: hO,
        interactive: !0,
        closeOnOutsideClick: !1
      }), [TO, NO] = (0, XO.useState)(null), IO = function(OO, KO) {
        const [pO, bK] = (0, XO.useState)(null);
        return (0, XO.useEffect)((() => {
          if (!KO || !OO) return void bK(null);
          let pO = 0,
            XO = null;
          const eO = () => {
            const KO = OO.getBoundingClientRect();
            XO && KO.left === XO.left && KO.top === XO.top && KO.width === XO.width && KO.height === XO.height || (XO = KO, bK(KO)), pO = requestAnimationFrame(eO)
          };
          return eO(), () => {
            cancelAnimationFrame(pO)
          }
        }), [OO, KO]), pO
      }(TO, hO);
      (0, XO.useEffect)((() => {
        hO && TO && TO.scrollIntoView({
          block: "nearest",
          inline: "nearest"
        })
      }), [hO, TO]);
      const yK = lO.ref,
        gK = (0, XO.useCallback)((OO => {
          dO(OO), aK.current = OO, NO(OO), oO(KO, OO), oO(yK, OO)
        }), [dO, KO, yK]),
        uO = (0, XO.useCallback)((OO => {
          fO(OO), DO.current = OO
        }), [fO]);
      return (0, MO.jsxs)(MO.Fragment, {
        children: [(0, XO.cloneElement)(lO, {
          ref: gK
        }), hO && (0, bK.createPortal)((0, MO.jsxs)(MO.Fragment, {
          children: [IO && (0, MO.jsx)(zK, {
            rect: IO
          }), (0, MO.jsxs)("div", {
            ref: uO,
            ...AO({
              className: "tooltip-container SmallTextLight TutorialStep"
            }),
            children: [(0, MO.jsx)(QO, {
              ...CO
            }), (0, MO.jsx)("div", {
              ...VO({
                className: "tooltip-arrow"
              })
            })]
          })]
        }), (0, vK.j)())]
      })
    }));

    function fO(OO) {
      const KO = FO(OO),
        pO = (0, XO.useRef)(null);
      return LO(OO, KO, pO, null), KO ? (0, bK.createPortal)((0, MO.jsx)("div", {
        className: "TutorialCentreBackdrop",
        children: (0, MO.jsx)("div", {
          ref: pO,
          className: "tooltip-container SmallTextLight TutorialStep TutorialCentreStep",
          children: (0, MO.jsx)(QO, {
            ...OO
          })
        })
      }), (0, vK.j)()) : null
    }
  },
  35238: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      g: () => lO,
      h: () => vK,
      l: () => CO
    });
    var XO = pO(63),
      bK = pO(1e3);
    const eO = 8,
      lO = "InGameHeaderContainer",
      vK = "TopRightElements";

    function CO(OO) {
      const [KO] = (0, bK.c)(), [pO, CO] = (0, XO.useState)(!1);
      return (0, XO.useLayoutEffect)((() => {
        if (!OO) return;
        const KO = document.querySelector(`.${lO}`),
          pO = document.querySelector(`.${vK}`),
          XO = () => {
            const XO = OO.getBoundingClientRect(),
              bK = KO ? KO.getBoundingClientRect().right : 0,
              lO = pO ? pO.getBoundingClientRect().left : window.innerWidth,
              vK = XO.left < bK + eO,
              hO = XO.right > lO - eO;
            CO(vK || hO)
          };
        XO();
        const bK = new ResizeObserver(XO);
        return bK.observe(OO), KO && bK.observe(KO), pO && bK.observe(pO), () => {
          bK.disconnect()
        }
      }), [OO, KO]), pO
    }
  },
  5691: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(63),
      bK = pO(36);

    function eO(OO, KO) {
      var pO;
      const [eO, lO] = (0, XO.useState)(null !== (pO = bK.e.getItem(OO)) && void 0 !== pO ? pO : KO);
      return [eO, KO => {
        bK.e.setItem(OO, KO), lO(KO)
      }]
    }
  },
  7857: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => aK,
      h: () => VO,
      l: () => LO,
      p: () => FO,
      t: () => oO
    });
    var XO = pO(63),
      bK = pO(7865),
      eO = pO(26),
      lO = pO(1556),
      vK = pO(596),
      CO = pO(36),
      hO = pO(1119),
      DO = pO(1569);
    const MO = 50;
    const aK = new class {
      constructor() {
        this.state = {
          messages: [],
          reportedPlayers: [],
          channel: null
        }, this.listeners = new Set, this.stopListening = [], this.nextClientChatMsgId = 0, this.subscribe = OO => {
          if (0 === this.listeners.size) {
            var KO, pO;
            this.state = {
              ...this.state,
              channel: null !== (KO = null === (pO = DO.c.get("chatChannels")) || void 0 === pO ? void 0 : pO[0]) && void 0 !== KO ? KO : null
            };
            const OO = eO.i.subscribe("reportPlayer", (OO => {
              let {
                playerEId: KO
              } = OO;
              this.setState({
                ...this.state,
                reportedPlayers: [...this.state.reportedPlayers, KO]
              })
            }));
            this.stopListening = [lO.gameBridge.subscribe("chatReceived", (OO => {
              let {
                serverChatMsgId: KO,
                content: pO,
                author: XO
              } = OO;
              this.addMessage(KO, pO, XO)
            })), () => {
              eO.i.unsubscribe(OO)
            }, DO.c.subscribe("chatChannels", (OO => {
              var KO;
              this.setState({
                ...this.state,
                channel: null !== (KO = null === OO || void 0 === OO ? void 0 : OO[0]) && void 0 !== KO ? KO : null
              })
            }))]
          }
          return this.listeners.add(OO), () => {
            if (this.listeners.delete(OO), 0 === this.listeners.size) {
              for (const OO of this.stopListening) OO();
              this.stopListening = [], this.state = {
                messages: [],
                reportedPlayers: [],
                channel: null
              }
            }
          }
        }, this.getState = () => this.state
      }
      addMessage(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        const XO = {
          serverChatMsgId: OO,
          content: KO,
          clientChatMsgId: this.nextClientChatMsgId++,
          author: pO
        };
        this.setState({
          ...this.state,
          messages: [XO, ...this.state.messages].slice(0, bK.f)
        })
      }
      selectNextChannel() {
        const OO = DO.c.get("chatChannels");
        if (OO) {
          const KO = OO.findIndex((OO => {
            var KO;
            return OO.channelName === (null === (KO = this.state.channel) || void 0 === KO ? void 0 : KO.channelName)
          }));
          this.setState({
            ...this.state,
            channel: OO[(KO + 1) % OO.length]
          })
        }
      }
      setState(OO) {
        this.state = OO;
        for (const KO of this.listeners) KO()
      }
    };

    function oO() {
      const [OO, KO] = (0, XO.useState)(aK.getState);
      return (0, XO.useEffect)((() => {
        const OO = aK.subscribe((() => {
          KO(aK.getState())
        }));
        return KO(aK.getState()), OO
      }), []), OO
    }

    function FO(OO) {
      var KO, pO;
      if (vK.k && "/" !== OO[0]) aK.addMessage(null, [{
        str: "Cannot send chat messages in bloxdk12. Use /help for a list of commands."
      }]);
      else {
        if (OO.startsWith("/report")) {
          var XO;
          const KO = null !== (XO = OO.replace("/report", "").trim().split(" ")[0]) && void 0 !== XO ? XO : "";
          if ("" === KO) return void aK.addMessage(null, [{
            str: "You must type a player's name when reporting them.\nExample:\n/report Bob"
          }]);
          const pO = lO.gameBridge.latest("players"),
            bK = lO.gameBridge.latest("hiddenPlayerNames"),
            vK = OO => {
              var XO, eO;
              const lO = null !== (XO = null === (eO = pO.byId[OO]) || void 0 === eO ? void 0 : eO.name) && void 0 !== XO ? XO : null;
              return null !== lO && (lO === KO || (0, hO.e)(lO, bK) === KO)
            };
          if (null !== pO.localId && vK(pO.localId)) return void aK.addMessage(null, [{
            str: "You cannot report yourself."
          }]);
          for (const OO of pO.ids)
            if (vK(OO)) return eO.i.pl("OpenReportMenu", {
              playerEId: OO,
              playerName: pO.byId[OO].name,
              Tl: null,
              serverChatMsgId: null
            }), void console.log("Opening report menu...");
          aK.addMessage(null, [{
            str: "Player not found in lobby."
          }])
        }
        lO.gameBridge.send("sendChatMessage", {
            Tl: OO,
            channelName: null !== (KO = null === (pO = aK.getState().channel) || void 0 === pO ? void 0 : pO.channelName) && void 0 !== KO ? KO : null
          }),
          function(OO) {
            var KO;
            const pO = null !== (KO = CO.e.getItem("recentlySentChatMsgs")) && void 0 !== KO ? KO : [];
            pO.push(OO), pO.length > MO && pO.shift();
            CO.e.setItem("recentlySentChatMsgs", pO)
          }(OO)
      }
    }

    function VO() {
      var OO;
      return null !== (OO = CO.e.getItem("recentlySentChatMsgs")) && void 0 !== OO ? OO : []
    }

    function LO(OO) {
      var KO;
      let pO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      const XO = null !== (KO = CO.e.getItem("recentlySentChatMsgs")) && void 0 !== KO ? KO : [],
        bK = XO.length + 1,
        eO = pO ? (OO % bK + bK) % bK : Math.min(XO.length, Math.max(0, OO));
      return {
        stepsBack: eO,
        text: 0 === eO ? "" : XO[XO.length - eO]
      }
    }
  },
  7800: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      f: () => eO
    });
    var XO = pO(1608);
    const bK = /^(?:Key[A-Z]|Digit[0-9]|Arrow(?:Up|Down|Left|Right)|Space)$/,
      eO = OO => "string" === typeof OO.icon && "" !== OO.icon && "string" === typeof OO.keycode && bK.test(OO.keycode),
      lO = OO => "Space" === OO ? "_" : XO.f[OO]
  },
  7875: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK
    });
    var XO = pO(22);

    function bK() {
      return !XO.d.get("isTouchScreen") && null !== document.pointerLockElement
    }
  },
  7880: (OO, KO, pO) => {
    pO.d(KO, {
      D: () => aK,
      H: () => oO,
      d: () => eO,
      g: () => vK,
      k: () => hO,
      n: () => CO,
      r: () => lO,
      t: () => bK,
      u: () => XO,
      v: () => FO,
      w: () => MO,
      z: () => DO
    });
    const XO = 14,
      bK = 6,
      eO = (XO + bK) / 2,
      lO = 200,
      vK = lO / 2,
      CO = lO / 2 - 1,
      hO = bK / XO * (lO / 2),
      DO = (OO, KO) => -Math.PI / 2 + 2 * OO * Math.PI / KO,
      MO = (OO, KO, pO) => {
        const XO = 2 * Math.PI / pO;
        return (Math.round((Math.atan2(KO, OO) + Math.PI / 2) / XO) % pO + pO) % pO
      },
      aK = .5,
      oO = (OO, KO, pO) => Math.hypot(OO.x, OO.y) < aK ? pO : MO(OO.x, OO.y, KO),
      FO = (OO, KO, pO, XO, bK) => {
        const eO = Math.PI / KO,
          lO = DO(OO, KO),
          vK = lO - eO,
          CO = lO + eO,
          hO = (OO, KO) => `${pO+OO*Math.cos(KO)} ${pO+OO*Math.sin(KO)}`;
        return [`M ${hO(XO,vK)}`, `L ${hO(bK,vK)}`, `A ${bK} ${bK} 0 0 1 ${hO(bK,CO)}`, `L ${hO(XO,CO)}`, `A ${XO} ${XO} 0 0 0 ${hO(XO,vK)}`, "Z"].join(" ")
      }
  },
  35232: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      f: () => CO
    });
    var XO = pO(63),
      bK = pO(22),
      eO = pO(1263),
      lO = pO(35072);

    function vK(OO, KO, pO) {
      let XO = null;
      for (const eO of document.querySelectorAll(".TouchComponentsButtons .TouchKeyHit")) {
        const lO = eO.getBoundingClientRect();
        var bK;
        if (lO.height > 0 && lO.top > pO && lO.left < KO && lO.right > OO) XO = Math.min(null !== (bK = XO) && void 0 !== bK ? bK : lO.top, lO.top)
      }
      return XO
    }

    function CO(OO, KO) {
      const {
        isTouchScreen: pO
      } = (0, bK.l)(["isTouchScreen"]), CO = (0, XO.useRef)(null);
      (0, eO.f)(lO.e, (() => {
        var OO;
        null === (OO = CO.current) || void 0 === OO || OO.call(CO)
      })), (0, XO.useEffect)((() => {
        const XO = null === OO || void 0 === OO ? void 0 : OO.closest(KO),
          bK = document.querySelector(".BottomRightElements");
        if (!pO || !OO || !XO || !bK) return;
        const eO = () => {
          ! function(OO, KO) {
            const pO = OO.getBoundingClientRect(),
              XO = vK(pO.left, pO.right, -1 / 0),
              bK = KO.getBoundingClientRect().bottom + parseFloat(getComputedStyle(KO).bottom),
              eO = null === XO ? "0px" : `${Math.ceil(bK-XO+4)}px`;
            KO.style.getPropertyValue("--touch-keys-reach") !== eO && KO.style.setProperty("--touch-keys-reach", eO)
          }(OO, XO)
        };
        CO.current = eO;
        const lO = new ResizeObserver(eO);
        return lO.observe(OO), lO.observe(bK), window.addEventListener("resize", eO), () => {
          CO.current = null, lO.disconnect(), window.removeEventListener("resize", eO), XO.style.setProperty("--touch-keys-reach", "0px")
        }
      }), [pO, OO, KO])
    }
  },
  35378: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO
    });
    var XO = pO(22),
      bK = pO(1152);

    function eO() {
      const {
        clientEscMenuOptions: OO
      } = (0, XO.l)(["clientEscMenuOptions"]);
      return (0, bK.F)() && OO.showChat
    }
  },
  7917: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(63),
      bK = pO(7824),
      eO = pO(1991);

    function lO() {
      const OO = (0, eO.i)("shopInfo"),
        [, KO] = (0, XO.useReducer)((OO => OO + 1), 0);
      return (0, eO.f)("shopInfo", KO), !(0, bK.e)(OO)
    }
  },
  35326: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO
    });
    var XO = pO(2231),
      bK = pO(2931),
      eO = pO(2302);
    const lO = ["Unable to create vertex buffer"];
    let vK = {};

    function CO(OO, KO) {
      const pO = new Date;
      console.error(`${pO.getUTCHours()}:${pO.getUTCMinutes()}:${pO.getUTCSeconds()}`, OO, KO, null === KO || void 0 === KO ? void 0 : KO.stack), lO.includes(null === KO || void 0 === KO ? void 0 : KO.message) && (console.error("Unrecoverable error occurred. Leaving game."), (0, XO.b)().client.leaveGameUnwanted({
        reason: `Unrecoverable error occurred.\nThis is a bug.\n\nError:\n${KO.message}\n\nPlease refresh the page.`,
        requiresRefresh: !0,
        canReconnect: !1,
        automaticallyReconnect: !1
      })), (0, eO.logError)("warning", `${OO}\n ${KO} "\n" ${null===KO||void 0===KO?void 0:KO.stack}`);
      const bK = OO + KO + (null === KO || void 0 === KO ? void 0 : KO.stack);
      bK in vK || ((0, eO.logError)("error", `${OO}\n ${KO} "\n" ${null===KO||void 0===KO?void 0:KO.stack}`), vK[bK] = !0)
    }(0, bK.onGameReset)((() => {
      vK = {}
    }))
  },
  3972: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => rK,
      g: () => iK
    });
    var XO = pO(3977),
      bK = pO(243);
    const eO = 120,
      lO = 260,
      vK = 1.15,
      CO = 1.2,
      hO = 2,
      DO = 1.08,
      MO = .8,
      aK = .95,
      oO = 8,
      FO = "[\"')\\]\u300d\u300f\uff09]*",
      VO = new RegExp(`[.!?\u2026\u3002\uff01\uff1f]${FO}$`),
      LO = new RegExp(`[?\uff1f]${FO}$`),
      QO = new RegExp(`[!\uff01]${FO}$`),
      zK = /[,;:\u3001\uff0c\uff1b\uff1a]$/,
      AO = "\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uac00-\\ud7af\\uf900-\\ufaff",
      fO = new RegExp(`[${AO}]`),
      dO = new RegExp(`[${AO}]|[^${AO}]+`, "g"),
      TO = /[aeiouy\u0430\u0435\u0438\u043e\u0443\u044b\u044d\u044e\u044f\u03b1\u03b5\u03b7\u03b9\u03bf\u03c5\u03c9]+/g;

    function NO(OO) {
      let KO = 2166136261;
      for (let pO = 0; pO < OO.length; pO++) KO ^= OO.charCodeAt(pO), KO = Math.imul(KO, 16777619);
      return (KO >>> 0) / 4294967295 * 2 - 1
    }

    function IO(OO) {
      var KO;
      if (fO.test(OO)) return 1;
      const pO = OO.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase(),
        XO = pO.replace(/[^0-9]/g, "");
      if (XO.length > 0 && !/\p{L}/u.test(pO)) return Math.min(XO.length, 4);
      const bK = null !== (KO = pO.match(TO)) && void 0 !== KO ? KO : [];
      if (0 === bK.length) {
        var eO, lO;
        const OO = null !== (eO = null === (lO = pO.match(/\p{L}/gu)) || void 0 === lO ? void 0 : lO.length) && void 0 !== eO ? eO : 0;
        return 0 === OO ? 0 : Math.min(Math.max(1, Math.round(OO / 2.5)), oO)
      }
      const vK = pO.replace(/[^\p{L}]/gu, ""),
        CO = bK.length > 1 && "e" === bK.at(-1) && vK.endsWith("e") && !vK.endsWith("le") && !/[\u00e9\u00e8\u00ea]$/i.test(OO.replace(/[^\p{L}]/gu, ""));
      return Math.min(bK.length - (CO ? 1 : 0), oO)
    }

    function yK(OO) {
      return OO.toLowerCase().replace(/[^\p{L}\p{N}]/gu, "")
    }

    function gK(OO) {
      const KO = OO.replace(/[^\p{L}]/gu, "");
      return KO.length >= 2 && KO === KO.toUpperCase() && KO !== KO.toLowerCase()
    }

    function uO(OO, KO) {
      var pO;
      const oO = KO && (0, XO.l)(KO),
        FO = null !== (pO = null === oO || void 0 === oO ? void 0 : oO.syllableMs) && void 0 !== pO ? pO : XO.d,
        AO = function(OO) {
          const KO = [];
          for (const XO of (0, bK.cc)(OO))
            if ("string" === typeof XO)
              for (const OO of XO.split(/(\s+)/)) {
                if ("" === OO) continue;
                if (/^\s+$/.test(OO)) {
                  KO.push({
                    kind: "space",
                    text: OO
                  });
                  continue
                }
                if (!fO.test(OO)) {
                  KO.push({
                    kind: "word",
                    text: OO,
                    delayMs: 0
                  });
                  continue
                }
                let XO = !0;
                for (const bK of null !== (pO = OO.match(dO)) && void 0 !== pO ? pO : []) {
                  var pO;
                  const OO = KO.at(-1);
                  XO || "word" !== (null === OO || void 0 === OO ? void 0 : OO.kind) || fO.test(bK) || /[\p{L}\p{N}]/u.test(bK) ? (XO || KO.push({
                    kind: "space",
                    text: "\u200b"
                  }), KO.push({
                    kind: "word",
                    text: bK,
                    delayMs: 0
                  }), XO = !1) : OO.text += bK
                }
              } else KO.push({
                kind: "icon",
                text: XO.icon,
                delayMs: 0
              });
          return KO
        }(OO),
        TO = [];
      let uO = [];
      for (const XO of AO) "space" !== XO.kind && (uO.push(XO), VO.test(XO.text) && (TO.push(uO), uO = []));
      TO.push(uO);
      const EO = [];
      let jK = 0;
      for (const XO of TO) {
        var YO, wO;
        const OO = null !== (YO = null === (wO = XO.at(-1)) || void 0 === wO ? void 0 : wO.text) && void 0 !== YO ? YO : "",
          KO = LO.test(OO),
          pO = QO.test(OO),
          bK = XO.map((OO => "word" === OO.kind ? IO(OO.text) : 1)),
          AO = bK.findLastIndex((OO => OO > 0));
        for (const [LO, QO] of XO.entries()) {
          const OO = "word" === QO.kind,
            XO = bK[LO];
          QO.delayMs = jK;
          for (let bK = 0; oO && bK < XO; bK++) {
            const {
              intonation: eO
            } = oO;
            let lO = AO > 0 ? -eO.declineSemitones * (LO / AO) : 0;
            lO += NO(`${yK(QO.text)}|${bK}`) * eO.variationSemitones;
            const VO = Math.min(1, eO.variationSemitones);
            let zK = oO.glideSemitones,
              fO = 1;
            pO && (lO += eO.exclaimLiftSemitones, fO *= vK), KO && LO === AO && (lO += eO.questionRiseSemitones * (XO > 1 ? .5 + .5 * bK / (XO - 1) : 1), bK === XO - 1 && (zK = Math.abs(zK) + eO.questionRiseSemitones / 2)), OO && gK(QO.text) && (lO += hO * VO, fO *= CO), XO > 1 && 0 === bK && (lO += MO * VO, fO *= DO), EO.push({
              atMs: jK + bK * FO,
              semitones: lO,
              glideSemitones: zK,
              durationMs: bK < XO - 1 ? Math.min(oO.durationMs, FO * aK) : oO.durationMs,
              level: fO
            })
          }
          jK += XO * FO + (VO.test(QO.text) ? lO : zK.test(QO.text) ? eO : 0)
        }
      }
      return {
        pieces: AO.map((OO => "space" === OO.kind ? OO : "icon" === OO.kind ? {
          kind: "icon",
          icon: OO.text,
          delayMs: OO.delayMs
        } : {
          kind: "word",
          text: OO.text,
          delayMs: OO.delayMs
        })),
        blips: EO
      }
    }
    var EO = pO(1051),
      jK = pO(1109),
      YO = pO(1558);

    function wO(OO) {
      if ("string" === typeof OO) return OO;
      const KO = jK.f.get().getCurrentLanguageCode();
      return (0, EO.s)(KO, OO.translationKey, (0, EO.q)(OO.params, YO.c.shown))
    }

    function iK(OO) {
      const KO = void 0 === OO.voice ? null : (0, XO.m)(OO.voice),
        pO = KO && (0, XO.l)(KO);
      return {
        plan: uO(wO(OO.line), pO),
        synth: pO
      }
    }

    function rK(OO) {
      const KO = [];
      let pO = [];
      for (const [bK, eO] of OO.entries()) {
        var XO;
        "space" === eO.kind && (" " !== eO.text || "icon" !== (null === (XO = OO[bK + 1]) || void 0 === XO ? void 0 : XO.kind)) ? (pO.length > 0 && KO.push(pO), KO.push([eO]), pO = []) : pO.push(eO)
      }
      return pO.length > 0 && KO.push(pO), KO
    }
  },
  35230: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK
    });
    const XO = [{
      maxDist: 30,
      timeBetweenSoftChecks: 1e3,
      softUpdateDist: 2,
      hardUpdateDist: 10
    }, {
      maxDist: 200,
      timeBetweenSoftChecks: 2e3,
      softUpdateDist: 5,
      hardUpdateDist: 20
    }, {
      maxDist: 1 / 0,
      timeBetweenSoftChecks: 5e3,
      softUpdateDist: 30,
      hardUpdateDist: 100
    }];

    function bK(OO, KO, pO) {
      const bK = Math.abs(OO - KO),
        eO = Date.now() - pO;
      for (const lO of XO)
        if (OO < lO.maxDist) return bK >= lO.hardUpdateDist || eO > lO.timeBetweenSoftChecks && bK >= lO.softUpdateDist;
      return !1
    }
  },
  35421: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      d: () => eO,
      e: () => bK
    });
    const XO = [.25, .5, 1, 2, 4, 8, 16];

    function bK(OO, KO) {
      const pO = XO;
      let bK = pO.indexOf(OO);
      return -1 === bK && (bK = pO.findIndex((KO => KO >= OO)), -1 === bK && (bK = pO.length - 1)), "up" === KO ? pO[Math.min(bK + 1, pO.length - 1)] : pO[Math.max(bK - 1, 0)]
    }

    function eO(OO) {
      return OO <= XO[0]
    }

    function lO(OO) {
      return OO >= XO[XO.length - 1]
    }
  },
  35463: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      h: () => bK
    });
    const XO = "data-replay-ui-active",
      bK = [{
        group: "middleTextTop",
        dataAttr: "data-replay-hide-middle-text-top",
        label: "Middle text top"
      }, {
        group: "middleTextUpper",
        dataAttr: "data-replay-hide-middle-text-upper",
        label: "Middle text upper"
      }, {
        group: "middleTextLower",
        dataAttr: "data-replay-hide-middle-text-lower",
        label: "Middle text lower"
      }, {
        group: "rightInfoText",
        dataAttr: "data-replay-hide-right-info-text",
        label: "Right info text"
      }, {
        group: "crosshair",
        dataAttr: "data-replay-hide-crosshair",
        label: "Crosshair"
      }, {
        group: "flyingMiddleText",
        dataAttr: "data-replay-hide-flying-middle-text",
        label: "Flying middle text"
      }, {
        group: "hotbar",
        dataAttr: "data-replay-hide-hotbar",
        label: "Hotbar (shop, inventory, item name)"
      }, {
        group: "auraBar",
        dataAttr: "data-replay-hide-aura-bar",
        label: "Aura XP bar"
      }, {
        group: "healthAndShield",
        dataAttr: "data-replay-hide-health-and-shield",
        label: "Health bar and shield bar"
      }, {
        group: "effectInfo",
        dataAttr: "data-replay-hide-effect-info",
        label: "Effect info"
      }, {
        group: "nametag",
        dataAttr: null,
        label: "Nametags"
      }, {
        group: "everythingElse",
        dataAttr: "data-replay-hide-everything-else",
        label: "Everything else"
      }]
  },
  35470: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => hO,
      g: () => MO,
      k: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(35463);

    function lO() {
      const OO = {};
      for (const {
          group: KO
        }
        of eO.h) OO[KO] = !0;
      return OO
    }
    let vK = lO();

    function CO() {
      bK.i.pl("replayViewer|uiVisibilityChanged")
    }

    function hO() {
      return vK
    }

    function DO(OO, KO) {
      vK[OO] !== KO && (vK = {
        ...vK,
        [OO]: KO
      }, "nametag" === OO && XO.d.set({
        areNametagsHidden: !KO
      }), CO())
    }

    function MO() {
      vK = lO(), XO.d.set({
        areNametagsHidden: !1
      }), CO()
    }
  },
  7793: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      h: () => lO,
      l: () => vK,
      o: () => bK
    });
    var XO = pO(7800);
    const bK = OO => {
        const KO = [];
        OO.holdingGun && KO.push({
          kind: "reload"
        }), OO.touchscreenActionButton && KO.push({
          kind: "touchButton",
          label: OO.touchscreenActionButton
        });
        for (const eO of null !== (pO = null === (bK = OO.customButtons) || void 0 === bK ? void 0 : bK.filter(XO.f)) && void 0 !== pO ? pO : []) {
          var pO, bK;
          KO.push({
            kind: "customButton",
            id: eO.id,
            icon: eO.icon,
            description: eO.description
          })
        }
        return KO
      },
      eO = OO => OO.length >= 2,
      lO = OO => "specialAction" !== OO.kind,
      vK = (OO, KO) => {
        if (null === OO || null === KO) return OO === KO;
        if (OO.kind !== KO.kind) return !1;
        switch (OO.kind) {
          case "reload":
            return !0;
          case "specialAction":
            return OO.action === KO.action;
          case "customButton":
            return OO.id === KO.id && OO.icon === KO.icon;
          case "touchButton":
            return OO.label === KO.label
        }
      }
  },
  7789: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      e: () => oO,
      i: () => MO,
      j: () => FO
    });
    var XO = pO(63),
      bK = pO(26),
      eO = pO(1263),
      lO = pO(7793),
      vK = pO(7806);
    let CO = null;
    const hO = () => CO,
      DO = OO => {
        (0, lO.l)(CO, OO) || (CO = OO, bK.i.pl(vK.f, CO))
      },
      MO = () => {
        const [OO, KO] = (0, XO.useState)(hO);
        return (0, eO.f)(vK.f, KO), OO
      };
    let aK = !1;
    const oO = OO => {
        OO !== aK && (aK = OO, bK.i.pl(vK.j, OO))
      },
      FO = () => {
        const [OO, KO] = (0, XO.useState)(aK);
        return (0, eO.f)(vK.j, KO), OO
      }
  },
  7806: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      f: () => XO,
      j: () => bK,
      m: () => vK,
      p: () => CO,
      q: () => hO,
      s: () => lO
    });
    const XO = "controllerActionHintChanged",
      bK = "controllerActionWheelHintChanged",
      eO = "controllerOpenChat",
      lO = "controllerSneakToggledChanged",
      vK = "controllerAttackLatchedChanged",
      CO = "controllerDropStackHoldChanged",
      hO = "controllerPickBlockHintChanged"
  },
  7768: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      e: () => eO,
      g: () => CO,
      k: () => vK
    });
    var XO = pO(1263),
      bK = pO(1232);
    const eO = "controllerInventoryCursorChanged",
      lO = {
        showing: !1,
        kind: null,
        holding: !1,
        slotHasItem: !1,
        pressHints: null,
        hasCategories: !1,
        hasList: !1,
        openButtonCloses: !1,
        steppingSlots: !1,
        quickMoveToHotbar: !1,
        dropStackHold: null,
        hotbarPicking: !1
      },
      vK = () => {
        var OO, KO;
        return (0, XO.h)(eO, null !== (OO = null === (KO = (0, bK.g)()) || void 0 === KO ? void 0 : KO.getInventoryCursorState()) && void 0 !== OO ? OO : lO)
      },
      CO = () => {
        var OO, KO;
        return null !== (OO = null === (KO = (0, bK.g)()) || void 0 === KO ? void 0 : KO.isPadSteppingSlots()) && void 0 !== OO && OO
      }
  },
  7762: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => aK,
      e: () => vK,
      f: () => CO,
      g: () => lO,
      i: () => eO,
      m: () => DO,
      o: () => MO
    });
    let XO = null;
    const bK = new Set,
      eO = OO => (XO = OO, () => {
        if (XO === OO) {
          XO = null;
          for (const OO of bK) OO()
        }
      }),
      lO = OO => (bK.add(OO), () => {
        bK.delete(OO)
      }),
      vK = () => XO,
      CO = () => null !== XO;
    let hO = null;
    const DO = OO => {
        hO = OO
      },
      MO = () => {
        const OO = hO;
        return hO = null, OO
      },
      aK = (OO, KO) => {
        var pO, XO;
        return null !== (pO = null !== (XO = OO.find((OO => OO.element === KO))) && void 0 !== XO ? XO : OO.find((OO => OO.element.contains(KO)))) && void 0 !== pO ? pO : null
      }
  },
  7775: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      g: () => lO
    });
    var XO = pO(63);
    const bK = new WeakMap,
      eO = OO => {
        var KO, pO;
        return null !== (KO = null === (pO = bK.get(OO)) || void 0 === pO ? void 0 : pO.current) && void 0 !== KO ? KO : null
      },
      lO = (OO, KO) => {
        const pO = (0, XO.useRef)(KO);
        pO.current = KO;
        const eO = (0, XO.useRef)(null);
        (0, XO.useEffect)((() => {
          const KO = OO.current,
            XO = eO.current;
          KO !== XO && (XO && bK.get(XO) === pO && bK.delete(XO), eO.current = KO, KO && bK.set(KO, pO))
        })), (0, XO.useEffect)((() => () => {
          const OO = eO.current;
          OO && bK.get(OO) === pO && bK.delete(OO), eO.current = null
        }), [])
      }
  },
  7907: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      f: () => hO,
      g: () => MO,
      k: () => DO,
      l: () => CO,
      m: () => oO
    });
    var XO = pO(26),
      bK = pO(1621),
      eO = pO(1232),
      lO = pO(1225);
    const vK = OO => {
        var KO, pO;
        return (0, lO.h)() && null !== (KO = null === (pO = (0, eO.g)()) || void 0 === pO ? void 0 : pO.getGlyphForNoaAction(OO)) && void 0 !== KO ? KO : null
      },
      CO = "controllerGlyph:",
      hO = OO => {
        var KO, pO;
        return null !== (KO = null === (pO = (0, eO.g)()) || void 0 === pO ? void 0 : pO.getPadGlyphIconName(OO)) && void 0 !== KO ? KO : `${CO}xbox/${OO}`
      },
      DO = OO => OO.startsWith(CO),
      MO = OO => {
        var KO, pO;
        return DO(OO) && null !== (KO = null === (pO = (0, eO.g)()) || void 0 === pO ? void 0 : pO.getPadGlyphIconUrl(OO)) && void 0 !== KO ? KO : null
      },
      aK = ["customBindingsChanged", "appManagerUpdated|isTouchScreen", lO.d, bK.f, bK.b],
      oO = OO => {
        const KO = aK.map((KO => XO.i.subscribe(KO, OO)));
        return () => {
          for (const OO of KO) XO.i.unsubscribe(OO)
        }
      }
  },
  7757: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => XO
    });
    const XO = "controllerOpenKeyboard",
      bK = "controllerKeyboardVisible"
  },
  7854: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      f: () => bK
    });
    let XO = null;
    const bK = function(OO) {
        const KO = {
          cycle: OO,
          canCycle: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => !0
        };
        return XO = KO, () => {
          XO === KO && (XO = null)
        }
      },
      eO = () => {
        var OO;
        return null !== (OO = XO) && void 0 !== OO && OO.canCycle() ? XO.cycle : null
      }
  },
  7893: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      h: () => lO,
      j: () => eO,
      k: () => XO,
      l: () => vK,
      o: () => hO,
      p: () => DO
    });
    const XO = "controllerActionWheelOpen",
      bK = "controllerActionWheelAim",
      eO = "controllerActionWheelCommit",
      lO = "controllerActionWheelClose",
      vK = "controllerActionWheelPick";
    let CO = !1;
    const hO = () => CO,
      DO = OO => {
        CO = OO
      }
  },
  7886: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      e: () => bK
    });
    let XO = 0;
    const bK = () => {
        XO++
      },
      eO = () => XO
  },
  7847: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO,
      e: () => bK,
      i: () => lO,
      m: () => eO,
      o: () => XO,
      p: () => hO
    });
    const XO = "controllerQuickChatWheelOpen",
      bK = "controllerQuickChatWheelAim",
      eO = "controllerQuickChatWheelCommit",
      lO = "controllerQuickChatWheelClose";
    let vK = !1;
    const CO = () => vK,
      hO = OO => {
        vK = OO
      }
  },
  35338: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO.b
    });
    var XO = pO(35340);
    class bK {
      constructor(OO) {
        this.load = OO, this.loaded = null, this.loading = null
      }
      run(OO) {
        return null !== this.loaded ? OO(this.loaded) : (this.loading ??= this.load().then((OO => (this.loaded = OO, OO)), (OO => {
          throw this.loading = null, OO
        })), this.loading.then(OO))
      }
    }
    class eO {
      constructor() {
        this.mobScene = new bK((() => Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(65), pO.e(233), pO.e(63), pO.e(64), pO.e(243), pO.e(237), pO.e(242), pO.e(240), pO.e(232), pO.e(206), pO.e(271), pO.e(211), pO.e(225), pO.e(238), pO.e(241), pO.e(127), pO.e(183), pO.e(207), pO.e(219), pO.e(205), pO.e(105), pO.e(103), pO.e(272), pO.e(147)]).then((() => pO(39228))))), this.characterScene = new bK((() => Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(65), pO.e(233), pO.e(63), pO.e(64), pO.e(243), pO.e(237), pO.e(242), pO.e(240), pO.e(232), pO.e(206), pO.e(271), pO.e(211), pO.e(225), pO.e(238), pO.e(241), pO.e(127), pO.e(183), pO.e(207), pO.e(219), pO.e(205), pO.e(105), pO.e(103), pO.e(272), pO.e(146)]).then((() => pO(39319)))))
      }
      openMob(OO) {
        return this.mobScene.run((KO => KO.openMobPreview(OO)))
      }
      openPet(OO) {
        return this.mobScene.run((KO => KO.openPetPreview(OO)))
      }
      openMobLineup(OO) {
        return this.mobScene.run((KO => KO.openMobLineupPreview(OO)))
      }
      openCharacter(OO) {
        return this.characterScene.run((KO => KO.openCharacterPreview(OO)))
      }
    }
    XO.b.setDefaultHost((() => new eO))
  },
  35322: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => eO
    });
    const XO = new Map;

    function bK(OO) {
      var KO;
      return null === OO ? null : null !== (KO = XO.get(OO)) && void 0 !== KO ? KO : null
    }

    function eO(OO, KO) {
      return XO.set(OO, KO), () => {
        XO.get(OO) === KO && XO.delete(OO)
      }
    }
  },
  35139: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => zK,
      c: () => eO,
      f: () => VO,
      i: () => LO,
      m: () => vK,
      n: () => aK,
      q: () => QO,
      s: () => MO,
      u: () => AO,
      y: () => FO
    });
    var XO = pO(22),
      bK = pO(26);
    const eO = "clientGameInventoryButtonsChanged",
      lO = new Map;

    function vK() {
      return [...lO.values()].sort(((OO, KO) => {
        var pO, XO;
        return (null !== (pO = OO.order) && void 0 !== pO ? pO : 0) - (null !== (XO = KO.order) && void 0 !== XO ? XO : 0)
      }))
    }
    let CO = null;

    function hO(OO) {
      CO = OO
    }
    let DO = !1;

    function MO(OO) {
      DO = !0;
      try {
        OO.onClick()
      } finally {
        DO = !1
      }
      OO.panel && "clientGame" === XO.d.get("openInGameMenuName") && hO(OO.id)
    }

    function aK() {
      return DO
    }

    function oO() {
      return vK().filter((OO => OO.panel && !OO.disabled))
    }

    function FO(OO) {
      const KO = oO(),
        pO = KO.findIndex((OO => OO.id === CO));
      return !(pO < 0 || KO.length < 2) && (MO(KO[(pO + OO + KO.length) % KO.length]), !0)
    }

    function VO() {
      return null !== CO && oO().length > 1
    }

    function LO() {
      hO(null)
    }

    function QO() {
      "inventory" !== XO.d.get("openInGameMenuName") && hO(null)
    }

    function zK() {
      const OO = CO;
      return hO(null), OO
    }

    function AO(OO) {
      return lO.set(OO.id, OO), bK.i.pl(eO, vK(), !0), () => {
        lO.get(OO.id) === OO && (lO.delete(OO.id), bK.i.pl(eO, vK()))
      }
    }
  },
  35137: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      g: () => LO,
      j: () => QO,
      k: () => aK,
      l: () => hO,
      o: () => VO,
      p: () => oO,
      q: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(1136),
      lO = pO(35139);
    const vK = "clientGameUiChanged";
    let CO = null;

    function hO() {
      return CO
    }

    function DO(OO, KO) {
      const pO = {
        content: OO,
        menu: KO
      };
      return CO = pO, bK.i.pl(vK, CO, !0), () => {
        CO === pO && (CO = null, FO = !1, LO(), bK.i.pl(vK, null))
      }
    }
    let MO = null;

    function aK() {
      return MO
    }

    function oO(OO) {
      return MO = OO, () => {
        MO === OO && (MO = null)
      }
    }
    let FO = !1;

    function VO() {
      const OO = XO.d.get("openInGameMenuName");
      "clientGame" !== OO && (FO = "inventory" === OO), (0, lO.n)() || (0, lO.i)(), (0, eO.k)("InGameMenu"), XO.d.set({
        openInGameMenuName: "clientGame",
        openEverythingMenuName: null
      })
    }

    function LO() {
      zK(!1)
    }

    function QO() {
      zK(FO)
    }

    function zK(OO) {
      "clientGame" === XO.d.get("openInGameMenuName") && XO.d.set({
        openInGameMenuName: OO ? "inventory" : null
      }), OO || (0, lO.i)(), FO = !1
    }
  },
  35435: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => tp,
      h: () => WK
    });
    var XO = pO(3520),
      bK = pO(533),
      eO = pO(2988),
      lO = pO(3013),
      vK = pO.n(lO);
    const CO = new Set(["nameTagInfo", "multilineTextBox", "animationScript", "content", "skyBox", "opts", "fromBlockData", "toBlockData", "sharedBlockData"]),
      hO = "EV_boolean",
      DO = "EV_double",
      MO = "EV_string",
      aK = "EV_doubleArr",
      oO = "EV_armour",
      FO = "EV_other",
      VO = "EV_cosmetics",
      LO = "OEV_boolean",
      QO = "OEV_int",
      zK = "OEV_double",
      AO = "OEV_string",
      fO = "OEV_stringArr",
      dO = "OEV_meshScaling",
      TO = "IV_int",
      NO = "IV_string",
      IO = "IV_doubleArr",
      yK = "IV_double",
      gK = "HV_int",
      uO = "HV_slots",
      EO = "EnvV_string",
      jK = "EnvV_double",
      YO = "EnvV_doubleArr",
      wO = "EnvV_boolean",
      iK = {
        type: MO,
        name: MO,
        position: aK,
        rotation: aK,
        scale: DO,
        speed: DO,
        jumping: hO,
        crouching: hO,
        cameraPitch: DO,
        armSwinging: hO,
        heldItemName: MO,
        heldItemEnchantmentTier: MO,
        pose: MO,
        followingEId: MO,
        ridingVehicleEId: MO,
        leaderboardTop: MO,
        meshKind: MO,
        meshOpts: MO,
        followingOffset: aK,
        shouldMatchFollowingEntityRotation: hO,
        meshOffset: aK,
        baseRenderHeading: DO,
        armour: oO,
        vXO: FO,
        playerCustomisations: VO,
        variation: MO,
        metaInfo: MO,
        soundName: MO,
        volume: DO,
        refDistance: DO,
        maxHearDist: DO,
        rate: DO,
        aiState: MO
      },
      rK = {
        opacity: zK,
        zIndex: QO,
        overlayColour: AO,
        canSee: LO,
        meshScaling: dO,
        nameTagInfo: AO,
        multilineTextBox: AO,
        hasPriorityNametag: LO,
        ranks: fO,
        nameColour: AO,
        _isAlive: LO,
        _invisibleEffect: LO,
        _invincible: LO,
        killfeedColour: AO,
        hideNameSeed: QO,
        _glowingEffect: LO,
        lockHeadToBody: LO
      },
      PO = {
        itemName: NO,
        amount: TO,
        position: IO,
        size: yK,
        attributes: NO
      },
      mK = {
        skyBox: EO,
        fogColourOverride: EO,
        fogChunkDistanceOverride: jK,
        cameraTint: YO,
        fogOnSkybox: wO,
        fogBlockDistanceOverride: jK
      },
      sO = {
        type: "array",
        items: "double"
      },
      HO = {
        type: "array",
        items: "int"
      },
      RO = {
        type: "map",
        values: {
          type: "record",
          name: "RecordedArmourPiece",
          fields: [{
            name: "itemName",
            type: "string"
          }, {
            name: "enchantmentTier",
            type: ["null", "string"],
            default: null
          }]
        }
      },
      SO = {
        type: "map",
        values: sO
      };

    function JO(OO, KO) {
      return {
        type: "record",
        name: OO,
        fields: [{
          name: "x",
          type: KO
        }]
      }
    }
    const cK = {
        type: "array",
        items: {
          type: "record",
          name: "OtherEntityDeltaEntry",
          fields: [{
            name: "i",
            type: "int"
          }, {
            name: "v",
            type: ["null", JO(LO, "boolean"), JO(QO, "int"), JO(zK, "double"), JO(AO, "string"), JO(fO, {
              type: "array",
              items: "string"
            }), JO(dO, SO)]
          }]
        }
      },
      BO = {
        type: "array",
        items: {
          type: "record",
          name: "EntityDeltaEntry",
          fields: [{
            name: "i",
            type: "int"
          }, {
            name: "v",
            type: ["null", JO(hO, "boolean"), JO(DO, "double"), JO(MO, "string"), JO(aK, sO), JO(oO, RO), JO(FO, cK), JO(VO, {
              type: "map",
              values: "string"
            })]
          }]
        }
      },
      ZO = {
        type: "array",
        items: {
          type: "record",
          name: "ItemDeltaEntry",
          fields: [{
            name: "i",
            type: "int"
          }, {
            name: "v",
            type: ["null", JO(TO, "int"), JO(NO, "string"), JO(yK, "double"), JO(IO, sO)]
          }]
        }
      },
      GO = {
        type: "map",
        values: ["null", {
          type: "record",
          name: "RecordedHotbarSlot",
          fields: [{
            name: "name",
            type: "string"
          }, {
            name: "amount",
            type: ["null", "int"],
            default: null
          }, {
            name: "attributes",
            type: "string"
          }]
        }]
      },
      qK = {
        type: "record",
        name: "HotbarDeltaEntry",
        fields: [{
          name: "i",
          type: "int"
        }, {
          name: "v",
          type: ["null", JO(gK, "int"), JO(uO, GO)]
        }]
      },
      xK = {
        type: "array",
        items: {
          type: "record",
          name: "PlayerHudDeltaEntry",
          fields: [{
            name: "i",
            type: "int"
          }, {
            name: "v",
            type: ["null", "int", "double"]
          }]
        }
      },
      nO = {
        type: "array",
        items: {
          type: "record",
          name: "UiElementsDeltaEntry",
          fields: [{
            name: "i",
            type: "int"
          }, {
            name: "v",
            type: ["null", "string"]
          }]
        }
      },
      WO = {
        type: "array",
        items: {
          type: "record",
          name: "EnvironmentDeltaEntry",
          fields: [{
            name: "i",
            type: "int"
          }, {
            name: "v",
            type: ["null", JO(EO, "string"), JO(jK, "double"), JO(YO, sO), JO(wO, "boolean")]
          }]
        }
      },
      tK = [{
        name: "EKO",
        type: "record",
        fields: [{
          name: "pos",
          type: HO
        }, {
          name: "fromBlockId",
          type: "int"
        }, {
          name: "toBlockId",
          type: "int"
        }, {
          name: "fromBlockData",
          type: ["null", "string"],
          default: null
        }, {
          name: "toBlockData",
          type: ["null", "string"],
          default: null
        }]
      }, {
        name: "setBlockData",
        type: "record",
        fields: [{
          name: "pos",
          type: HO
        }, {
          name: "fromBlockData",
          type: ["null", "string"],
          default: null
        }, {
          name: "toBlockData",
          type: ["null", "string"],
          default: null
        }]
      }, {
        name: "chunkAdded",
        type: "record",
        fields: [{
          name: "chunkX",
          type: "int"
        }, {
          name: "chunkY",
          type: "int"
        }, {
          name: "chunkZ",
          type: "int"
        }, {
          name: "rle",
          type: "bytes"
        }, {
          name: "sharedBlockData",
          type: "string"
        }]
      }, {
        name: "chunkRemoved",
        type: "record",
        fields: [{
          name: "chunkX",
          type: "int"
        }, {
          name: "chunkY",
          type: "int"
        }, {
          name: "chunkZ",
          type: "int"
        }, {
          name: "rle",
          type: "bytes"
        }, {
          name: "sharedBlockData",
          type: "string"
        }]
      }],
      kK = [{
        name: "playSound",
        type: "record",
        fields: [{
          name: "o9",
          type: "string"
        }, {
          name: "volume",
          type: "double"
        }, {
          name: "rate",
          type: "double"
        }, {
          name: "N9",
          type: ["null", {
            type: "record",
            name: "SoundPosSettings",
            fields: [{
              name: "I9",
              type: ["null", "string", sO],
              default: null
            }, {
              name: "yOO",
              type: ["null", "double"],
              default: null
            }, {
              name: "gOO",
              type: ["null", "double"],
              default: null
            }]
          }],
          default: null
        }]
      }, {
        name: "animateEntity",
        type: "record",
        fields: [{
          name: "Om",
          type: "string"
        }, {
          name: "R7",
          type: "int"
        }, {
          name: "animationScript",
          type: ["null", "string"]
        }, {
          name: "J7",
          type: "double"
        }, {
          name: "B7",
          type: "double"
        }]
      }, {
        name: "bullet",
        type: "record",
        fields: [{
          name: "A7",
          type: "string"
        }, {
          name: "bulletDirections",
          type: {
            type: "array",
            items: sO
          }
        }]
      }, {
        name: "lifeformHealth",
        type: "record",
        fields: [{
          name: "Qm",
          type: "string"
        }, {
          name: "j_",
          type: ["null", "double"],
          default: null
        }, {
          name: "i_",
          type: ["null", "double"],
          default: null
        }]
      }, {
        name: "particleEffectPlayed",
        type: "record",
        fields: [{
          name: "opts",
          type: "string"
        }]
      }, {
        name: "flyingMiddleText",
        type: "record",
        fields: [{
          name: "content",
          type: "string"
        }, {
          name: "ROO",
          type: "double"
        }, {
          name: "angle",
          type: "double"
        }, {
          name: "SOO",
          type: "int"
        }]
      }, {
        name: "playerKilled",
        type: "record",
        fields: [{
          name: "deadEId",
          type: "string"
        }, {
          name: "killerEId",
          type: "string"
        }, {
          name: "withItem",
          type: "string"
        }, {
          name: "killstreak",
          type: "int"
        }]
      }, {
        name: "customKillfeed",
        type: "record",
        fields: [{
          name: "killer",
          type: {
            type: "record",
            name: "RecordedKillfeedParty",
            fields: [{
              name: "eId",
              type: ["null", "string"],
              default: null
            }, {
              name: "name",
              type: ["null", "string"],
              default: null
            }, {
              name: "colour",
              type: ["null", "string"],
              default: null
            }]
          }
        }, {
          name: "victim",
          type: "RecordedKillfeedParty"
        }, {
          name: "withItem",
          type: "string"
        }]
      }],
      UO = [{
        name: "position",
        type: sO
      }, {
        name: "direction",
        type: sO
      }, {
        name: "firstPerson",
        type: "boolean"
      }, {
        name: "aiming",
        type: "boolean"
      }, {
        name: "reloading",
        type: "boolean"
      }, {
        name: "charging",
        type: "boolean"
      }];

    function OK() {
      const OO = [{
        name: "entities",
        type: {
          type: "map",
          values: BO
        }
      }, {
        name: "items",
        type: {
          type: "map",
          values: ZO
        }
      }, {
        name: "camera",
        type: {
          type: "record",
          name: "ReplayCameraState",
          fields: UO
        }
      }, {
        name: "hotbar",
        type: ["null", {
          type: "record",
          name: "HotbarFieldDelta",
          fields: [{
            name: "fullSlotsArray",
            type: "boolean"
          }, {
            name: "entries",
            type: {
              type: "array",
              items: qK
            }
          }]
        }],
        default: null
      }, {
        name: "playerHud",
        type: ["null", xK],
        default: null
      }];
      return OO.push({
        name: "effects",
        type: ["null", {
          type: "array",
          items: {
            type: "record",
            name: "ReplayActiveEffect",
            fields: [{
              name: "Qm",
              type: "string"
            }, {
              name: "name",
              type: "string"
            }, {
              name: "icon",
              type: "string"
            }, {
              name: "level",
              type: "float"
            }, {
              name: "displayName",
              type: ["null", "string"],
              default: null
            }, {
              name: "endTick",
              type: ["null", "int"],
              default: null
            }, {
              name: "showInNametag",
              type: "boolean"
            }]
          }
        }],
        default: null
      }), OO.push({
        name: "uiElements",
        type: nO
      }, {
        name: "environment",
        type: WO
      }, {
        name: "structuralEvents",
        type: {
          type: "array",
          items: tK
        }
      }, {
        name: "ephemeralEvents",
        type: {
          type: "array",
          items: kK
        }
      }), OO
    }
    const KK = {
      name: "editState",
      type: {
        type: "record",
        name: "ReplayEditState",
        fields: [{
          name: "cameraKeyframes",
          type: {
            type: "array",
            items: {
              type: "record",
              name: "ReplayCameraKeyframe",
              fields: [{
                name: "KK",
                type: "int"
              }, {
                name: "position",
                type: sO
              }, {
                name: "direction",
                type: sO
              }, {
                name: "easing",
                type: sO
              }]
            }
          }
        }, {
          name: "playbackMark",
          type: ["null", {
            type: "record",
            name: "ReplayPlaybackMark",
            fields: [{
              name: "inTick",
              type: "int"
            }, {
              name: "outTick",
              type: "int"
            }]
          }],
          default: null
        }]
      }
    };
    let pK;

    function XK(OO) {
      if (9 === OO) return pK ??= (KO = [{
        name: "meta",
        type: {
          type: "record",
          name: "RecordingMeta",
          fields: [{
            name: "formatVersion",
            type: "int"
          }, {
            name: "recordedAt",
            type: "string"
          }, {
            name: "RKO",
            type: "int"
          }, {
            name: "keyframeIntervalTicks",
            type: "int"
          }, {
            name: "gameNameWithVariation",
            type: "string"
          }, {
            name: "lobbyName",
            type: "string"
          }, {
            name: "gameName",
            type: "string"
          }, {
            name: "variation",
            type: ["null", "string"],
            default: null
          }, {
            name: "lobbyType",
            type: "int"
          }, {
            name: "localPlayerEntityId",
            type: "string"
          }, {
            name: "serverPlayerEntityId",
            type: "string"
          }]
        }
      }, {
        name: "initialChunks",
        type: {
          type: "array",
          items: {
            type: "record",
            name: "InitialChunk",
            fields: [{
              name: "chunkPos",
              type: HO
            }, {
              name: "rle",
              type: "bytes"
            }, {
              name: "sharedBlockData",
              type: "string"
            }]
          }
        }
      }, {
        name: "ticks",
        type: {
          type: "array",
          items: {
            type: "record",
            name: "RecordingTick",
            fields: OK()
          }
        }
      }, KK], vK().Type.forSchema({
        type: "record",
        name: "RecordingState",
        fields: KO
      }, {
        aX: Object.create(null)
      })), pK;
      var KO
    }
    var bp = pO(35443);
    let eK, lK, vp, CK;
    const hK = 12;
    var DK, MK;
    const ap = [0, 1, 8, 255, "length", "undefined", 63, 6, "fromCodePoint", 7, 12, "push", 91, 8191, 88, 13, 14, 3, 2, !1, 16, 87, 4, !0, 89, 15, 84, 1023, 65536, 10, 55296, 56320, 128, 31, 18, 192, 224, 240, 102, 60, 5, 11, 9, 127, 512, 56319, 57343, 65535, 24, 32, 19, 64];

    function oK(OO) {
      return typeof Kp !== ap[5] && Kp ? (new Kp).decode(new pp(OO)) : typeof Xp !== ap[5] && Xp ? Xp.from(OO).toString("utf-8") : lp(OO)
    }

    function FK() {}

    function VK() {
      VK = function() {}
    }
    var LK, QK;
    VK(DK = {}, MK = ["_*n1[1ee]%z0pzC,n+kEmalf2bVM!SqZNXspD~Ch/^q", 'pt75"b?o]>*keyc92p*p}>oTr)_e2a8', '@oeq~.l{z_V1"]SO.$eTw>ub59|`$l[p^^c', "S+^8*?6", "_qyF+]%,6GU{sL*p[IOn{!Uu0n>b%~V[XNtp@n#3;fhe^eer8I)P", 'g$uh"u}[afh2;(][Wt$1=M(uK9$i1j|', '!#`X.syCHNJ(7|6"U{OXzwhPZA*k<exr+*bj', "Zth<5}6", "+lo}3~?NAN(ri_uNkp5Ej;W|t3wTs+x,R0#sz", "~+In&xEbj", "&g95dJOO79ws3|T", "V?9n=MzOX8}w&F%@K[us#4RC0ntjda)uX(?<TU#{4o85=BlL", 'G*lEe>qLh_bP+^>ZD*$wU.]}zg)*CBRZ"gq/:>syVg#+s`6O', "/:k}(?^JqC+MJ4&7+6", "M0!rgaWP[oDj1^Xa7DZ(MF6", 'TN#q_aJJ$A*k,v][G+=s?+gtXAvPr4C,V0Q(a(bCk9:(pcmQ"}c&L?7t":O', "3[CX9L~I{_[G^_ja]_]0DtRf)nxH=^ROA?gp*V}[#:U3^_vL_%l", "*+zqFViuS|dbL$<,gz=8(5@ulf;CH", "b^L8H>vHmg:Gn(IpM*[5}F^ZAo$SJ_cLVDsPJei0T8fy6", "OW;k1V%Pl%YoRB),Ph[`%kKtV|j5qB|gNNGT}>PUqGnSXa?NXjs$>2Bc", "3CGh)4s,#D5h`^b7@?/1p$H,._", "%ZB/<bl{l", "/*C0rIsh,9/y<l}{u+c", "_b]qJ0j7e:mH9Llp%h/pD~oNx|Iw(jyfh}JjdRHbeD#26", "@}lEUR2,_N0wt{Xac>53y+qO8Dnktv=af>,`JeP{DN", "+CVn{kBc", "U:1p5}C,W)(wy(CuF*/r+?Se{::3=4:Lz%}0SFYO8:)9H", 'IDL}EyJHZgBO#zyNM^.1IVL159!Vm>k@1."h<bsh.#:GVWi*sVbwf', "JX2rLv:Ce:e", "rhh}TDAOqNvM3jSp8bI%4!T1z_C{(>][+zl", "U.SP(5$HE8Q]{+b91.?8#}Aok9?T3jm7n+(T", "<Des#F6", ")}a<k<BeY|Fy4_2&>DJna?814AIDDyC,6Cl", "C$Iwruy,|^8&G{_g50nw0S7c4>f`N*mZ/?}s;!hCUNQkgWHL;6", "bnH&VS=cn|6ZO&J@J$p/.(a1O|.9e{Z[}.Swv2TN2>Yh4cl{i.JX", "P(+0Za.|gn.wP&k@BtiE%+),]CQ+a|mZZqGqhv8;2byHH", "_bNq8DJbpb}3(`}a0.YX.5RyGnbwmj{r&>|8Jb??T8z", "5ZCn~1#fI:D(ELru2:%qi`mCE", 'hWar6epCr:`s|~(@"X/<~4^hLnYQH', "xX18pvwC>TW2C+LpB>tjRwoTCDfy3ji/=?O5)yYI~%g0E+{rV_J1c+Qc", "GXH0!Lu5zD0Ofz#f*h}0Kkgc", '30`nR^4,(CKT[*(@):!1R!GM.3mL=l"aV$v}sk^ZGn,9&]u/PH', 'phKT*V5|]n"DMJ@p(:X1944|2Wq9?Wm,hZap7V6', "~75h|4!;GnDrH", "%z5s9k@UM>]WPz3[1o&h(~?X.Nkq148", '|Wb%1`:,qoT/B^]r>:*jJ*Go9>h1zE!I%NVnTU7e"#](|B6"^Ddr7*n/2V1', "u[.}p$MIkTc%L^Izo}lh&niH#_V13`jax6", "D:8qpvJf6)h8}(kfP(@k!C67T<YsR`PpOZ|8dRLc", "}+opZ!rOz_:3k&Q&TuJrLu.J)f>^|L;Bh*KTD+6", "Iz(n1SotX8%%{j+[16", "|CZj.]MI2W<{XEmuft_k~k:,MNFVGU7{MV]h+]i,5:Ks__Wg1CR`;R6", "XoqnG+xC:>3M2^BzX?YnR$MO{gJw/EuN>%fsH>qMIg~3V4BI[CI&9", '[n_%~4S1(CnSyUs&/hdkj3>t?f=+Ml_fB0O/w<n1ff"l3`/L$6', ',"E}v`rLM3`{"_/uo?B5f', "b^#`WF5C]C<#d_d[VZwX2<h5@|%eHL@f{hl", 'US<%un67^9>bX*K7wV*}x.2C<|&y<_:LD??F"(0J;eG^CO:p}X3<QC6', 'k[#`y`"JyAkND|U[.ols94Mo@eysu&`*b_T%', "jq=h`U]159u^L^vhPZ/<]FUH.Niw*vIN)?d(>e?opNg8#aw@t%I/D`bZC9D_H", "&:6X)13,Ab#]$SaNaX9n}}uf0o:Tj4A7fo+%", 'ag2r(~%Hh_JyYOH*R"Ep?L2y{:bNcU|&d6', "i%x$be||#:@Dr&ROHb^}6t4H", "M_z&s}.|_W4s|+vh3lR5E>Dt7:g[H", "W$p%/JIO{:dH}(7{YX0sW4VIOg6Z#]X", "3CJw^3>ts_wH{jVhOga1;yRP9>L8S(k@][fqWULLj", "0ptPYk6", '3zS1{ke?1nL`"_aOv:H/H<*Ck9+kQ_/ZHbhr]ULoP8)2_E5{4S~P', "y9*<_}_O9GB[hBS{s0a%{C!I8:%*kWEa", "A*4sa*qOg|H:=l", "Aw.p:+wh23!QG*f,yp6XL!4,PALrXE?Nd:6/;RcMqoNDH", 'lnpj<SS}BNFk3{AL70bwOkhJ._"y[_O,i6', "G?o8E<rL+WiwM&^7h$hkz", "d.60PD%PRnH*!{j/3Z7`00#y:brkH", "#(OXl+&J&9L`LJHZtp{&.?]O6%<Mbaa{C^WkKRH|/Gjcq^b9x:SpXy|H", ";:a%,u9f,g,OH", "Qhz0tMw02N2SSa4&$+*j8LLc", "WtV(#y+ce9g&daCh{n^T!yIN2V=OUj", "ft_bfrvO", "06x[H]9O", '"K/B[', "reXyBfng", "y;#dqeJP", "x?!WpC{g", "JJ;Q$", "lEuDu53K", 'J2Go`":I', 'k"|zHQMI', "^odi3", "@{gE", "b{|zF;DI", "cokX", "O{[Sq8lI", 'o@mVA"Kc', ";1i=Rk>D", "~Qq*tzH<", "m.1!D,O", "P!3Ab*Z<", "!VL6?&v<", '"8qN|ec<', '"8"1!', 'o^_]N<Cfda=S+v"A%^$9vK3', "AC@X?1<B}0;72g&3l`qT+<={ow*%MvJ", "cmTo0i/gzl|.$>;H{m~:>u1", 'l|n=`"@UJ$YMf*ZOIb4^T@iA_<LQu~#', 'l|n=`"@UJ$+a=YSiG5n^=RhU"l$', "gV(*WXA", "]D2bBu>0", ")wdM", "]T2o", "DTn5Z8[F", 'O0Bc"{bA', '}yaf"]TF', "Hj2ZdQ9D", "Q^F%C3QP", 'ut|v"=,E', "i+g(7:zE", "q|%DJ+YE", "Q#gAznXH", "Tbw0n><H", "bWg(kFk5[9?8Hau", '29e"W2Q5Mr^R&+C', '"LqG$(fRLeyV.Tu', "VKCq?xbLcS=eN3O", "^op(vJQ5Be{+.au", "}^fc.ZdH]47q+NOcrLJAm%hRbUvl`5!@;`96L", "OZB~1PS)L|aihigpo;73gP=69u^8Qdt#%j[~5", 'LOuA"#hRLey=ITZ^28GD)8/<%k}lHaD|!`96_', "ZGoGN?Kvvr]Vc=A|T{_A)8ev~|TlHacXs`_AL", "Y._AvJ^)QG=FeZ2bEN0>hz^V!CWKSacXh`E", "CIJ,", "HT`?fAID", "7f#g&`_O", "K.o)", "nWft6l_wD?hylRelIi{)", "q#)~}q{TCH&c[7]II{<t", "),V!LY}.t%UC&ekXq!])", "5;mtf!Dqa)n2Ld~IqW=)", "M4mH1kba", ";<j;:Yky", "Uw3EM", "R)%|pdhy", ";<j;r.A]", "46%#g", "Q[Oc#dKU#f_Ga<", "%%vz2h<58GT;:<", "2MX{_M<pekT`C9", "_B7ZVZ^qLpC>*c", 'df;}3K|Ld.=>"*', "nhkCny7]}{0"]), VK(Op = function() {
      var OO, KO, pO, XO = [function() {
        return globalThis
      }, function() {
        return global
      }, function() {
        return window
      }, function() {
        return new Function("return this")()
      }];
      VK(OO = void 0, KO = []);
      try {
        VK(OO = Object, KO[ap[11]]("".__proto__.constructor.name))
      } catch (pp) {}
      OO: for (pO = ap[0]; pO < XO[ap[4]]; pO++) try {
        var bK;
        for (OO = XO[pO](), bK = ap[0]; bK < KO[ap[4]]; bK++)
          if (typeof OO[KO[bK]] === ap[5]) continue OO;
        return OO
      } catch (pp) {}
      return OO || this
    }() || {}, Kp = Op.TextDecoder, pp = Op.Uint8Array, Xp = Op.jb, bX = Op.String || String, ep = Op.Array || Array, lp = function() {
      var OO, KO, pO = new ep(ap[32]);
      return VK(OO = bX[ap[8]] || bX.fromCharCode, KO = []),
        function(XO) {
          var bK, eO, lO, vK;
          for (VK(eO = void 0, lO = XO[ap[4]], KO[ap[4]] = ap[0]), vK = ap[0]; vK < lO;) VK(eO = XO[vK++], eO <= ap[43] ? bK = eO : eO <= 223 ? bK = (eO & ap[33]) << ap[7] | XO[vK++] & ap[6] : eO <= 239 ? bK = (eO & ap[25]) << ap[10] | (XO[vK++] & ap[6]) << ap[7] | XO[vK++] & ap[6] : bX[ap[8]] ? bK = (eO & ap[9]) << ap[34] | (XO[vK++] & ap[6]) << ap[10] | (XO[vK++] & ap[6]) << ap[7] | XO[vK++] & ap[6] : (bK = ap[6], vK += ap[17]), KO[ap[11]](pO[bK] || (pO[bK] = OO(bK))));
          return KO.join("")
        }
    }()), (() => {
      function OO(OO) {
        return typeof DK[OO] === ap[5] ? DK[OO] = function(OO) {
          var KO, pO, XO, bK, eO, lO, vK;
          for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
            var CO = '1POVHThJnNQDYdiKjpvCs~Zk:X[I!{%"b/(_2@}aRFg*=SM$3#l7&6Ey8f).9wLcG|,et]B`U0^5zromWuAxq><?4+;'.indexOf(KO[vK]);
            if (CO !== -ap[1])
              if (lO < ap[0]) lO = CO;
              else {
                VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                do {
                  VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                } while (eO > ap[9]);
                lO = -ap[1]
              }
          }
          return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
        }(MK[OO]) : DK[OO]
      }
      const KO = ap[20],
        pO = OO(76) + OO(77) + OO(78),
        XO = [ap[0], ap[1], ap[18], ap[17]].map((OO => {
          function KO(OO) {
            return typeof DK[OO] === ap[5] ? DK[OO] = function(OO) {
              var KO, pO, XO, bK, eO, lO, vK;
              for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                var CO = '2PgtXQKdFZSqoAcJB1,V]rR?O*zG#$n)9N3>&^=p{mEb_@sCi:j/!WxyheuL7H|I[TU8;~l<50v+kDwaMY`f4.%}"6('.indexOf(KO[vK]);
                if (CO !== -ap[1])
                  if (lO < ap[0]) lO = CO;
                  else {
                    VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                    do {
                      VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                    } while (eO > ap[9]);
                    lO = -ap[1]
                  }
              }
              return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
            }(MK[OO]) : DK[OO]
          }
          KO(79) in FK && function() {
            var OO = function(OO) {
              var KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO = OO.length;
              if (MO < ap[18]) return ap[0];
              if (VK(KO = Math.max(...OO), pO = Math.min(...OO)), KO === pO) return ap[0];
              for (VK(XO = Array(MO - ap[1]).fill(Number.MAX_SAFE_INTEGER), bK = Array(MO - ap[1]).fill(Number.MIN_SAFE_INTEGER), eO = Math.ceil((KO - pO) / (MO - ap[1])), lO = ap[0]), vK = ap[0]; vK < MO; vK++) OO[vK] !== pO && OO[vK] !== KO && VK(lO = Math.floor((OO[vK] - pO) / eO), XO[lO] = Math.min(XO[lO], OO[vK]), bK[lO] = Math.max(bK[lO], OO[vK]));
              for (VK(CO = Number.MIN_SAFE_INTEGER, hO = pO), DO = ap[0]; DO < MO - ap[1]; DO++) XO[DO] === Number.MAX_SAFE_INTEGER && bK[DO] === Number.MIN_SAFE_INTEGER || VK(CO = Math.max(CO, XO[DO] - hO), hO = bK[DO]);
              return CO = Math.max(CO, KO - hO)
            };
            console.log(OO)
          }();
          let XO = ap[0];
          for (let bK = ap[17]; bK >= ap[0]; bK--) {
            function eO() {
              var OO;
              VK(OO = function(KO, pO, XO, bK, eO, lO, vK) {
                var CO = ap[19];
                return lO >= XO.length ? ap[23] : void 0 !== vK["" + bK + eO + lO] ? vK["" + bK + eO + lO] : (XO[lO] === KO[bK] && XO[lO] === pO[eO] ? CO = OO(KO, pO, XO, bK + ap[1], eO, lO + ap[1], vK) || OO(KO, pO, XO, bK, eO + ap[1], lO + ap[1], vK) : XO[lO] === KO[bK] ? CO = OO(KO, pO, XO, bK + ap[1], eO, lO + ap[1], vK) : XO[lO] === pO[eO] && (CO = OO(KO, pO, XO, bK, eO + ap[1], lO + ap[1], vK)), vK["" + bK + eO + lO] = CO, CO)
              }, console.log((function(KO, pO, XO) {
                return XO.length !== KO.length + pO.length ? ap[19] : OO(KO, pO, XO, ap[0], ap[0], ap[0], {})
              })))
            }
            KO(80) + "A" in FK && eO(), XO = XO << ap[2] | pO[KO(81) + KO(82)](OO * ap[22] + bK)
          }
          return XO >>> ap[0]
        })),
        bK = (OO, KO) => (function(OO) {
          return typeof DK[OO] === ap[5] ? DK[OO] = function(OO) {
            var KO, pO, XO, bK, eO, lO, vK;
            for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
              var CO = 'fKPEDVJkHUXQhZ|B6wOY:(^sdMz9}v_CF=>;]S!G)TLgmA1j52b#*lapiyI8~e+trR{x&W0qn$o7c3u@<[4%?,"`./N'.indexOf(KO[vK]);
              if (CO !== -ap[1])
                if (lO < ap[0]) lO = CO;
                else {
                  VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                  do {
                    VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                  } while (eO > ap[9]);
                  lO = -ap[1]
                }
            }
            return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
          }(MK[OO]) : DK[OO]
        }(83) in FK && function() {
          var OO, KO = function(KO, pO) {
            var XO, bK = [];
            return VK(XO = KO.length, KO.sort(((OO, KO) => OO - KO)), OO(bK, [], ap[0], XO, KO, pO)), bK
          };
          VK(OO = function(KO, pO, XO, bK, eO, lO) {
            var vK, CO = null;
            if (!(lO < ap[0])) {
              if (lO === ap[0]) return KO.push(pO);
              for (vK = XO; vK < bK && !(eO[vK] > lO); vK++) vK > XO && eO[vK] === eO[vK - ap[1]] || VK(CO = Array.from(pO), CO.push(eO[vK]), OO(KO, CO, vK + ap[1], bK, eO, lO - eO[vK]))
            }
          }, console.log(KO))
        }(), OO << KO | OO >>> ap[49] - KO),
        eO = (OO, KO, pO, XO, eO) => {
          VK(OO[KO] += OO[pO], OO[eO] = bK(OO[eO] ^ OO[KO], ap[20]), OO[XO] += OO[eO], OO[pO] = bK(OO[pO] ^ OO[XO], ap[10]), OO[KO] += OO[pO], OO[eO] = bK(OO[eO] ^ OO[KO], ap[2]), OO[XO] += OO[eO], OO[pO] = bK(OO[pO] ^ OO[XO], ap[9]))
        };
      CK = (OO, pO, bK, lO) => {
        function vK(OO) {
          return typeof DK[OO] === ap[5] ? DK[OO] = function(OO) {
            var KO, pO, XO, bK, eO, lO, vK;
            for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
              var CO = '6GIrXNUFiKEP7}J{x4b%[gMO+Llw`3@Yz~?T#kD!(_)WR5:nyve0^uoQA9f12$=p*mc|&tB"VC;sHSqZ.8<da]>h,/j'.indexOf(KO[vK]);
              if (CO !== -ap[1])
                if (lO < ap[0]) lO = CO;
                else {
                  VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                  do {
                    VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                  } while (eO > ap[9]);
                  lO = -ap[1]
                }
            }
            return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
          }(MK[OO]) : DK[OO]
        }
        const CO = new DataView(pO[vK(ap[26])], pO[vK(85) + vK(86)], hK),
          hO = new Uint32Array(KO);
        VK(hO[vK(ap[21])](XO), hO[vK(ap[21])](OO, ap[22]), hO[ap[15]] = CO[vK(ap[14]) + vK(ap[24])](ap[0], ap[23]), hO[ap[16]] = CO[vK(ap[14]) + vK(ap[24])](ap[22], ap[23]), hO[ap[25]] = CO[vK(ap[14]) + vK(ap[24])](ap[2], ap[23]));
        const DO = new Uint32Array(KO),
          MO = new Uint8Array(DO[vK(ap[26])]);
        for (let aK = ap[0], oO = bK; aK < lO[vK(90)]; aK += KO * ap[22], oO++) {
          function FO(OO) {
            var KO, pO, XO, bK, eO, lO, vK;
            for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
              var CO = 'PcD;w<sZ^,o5#zmT0l9i`2kHU!I%ae]&=[udrOp)|:71(KxC>*$4VE+G.j6Yb~h_JLMqSvBRt}@3"?fgQAFnN8Wy{X/'.indexOf(KO[vK]);
              if (CO !== -ap[1])
                if (lO < ap[0]) lO = CO;
                else {
                  VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                  do {
                    VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                  } while (eO > ap[9]);
                  lO = -ap[1]
                }
            }
            return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
          }

          function VO(OO) {
            return typeof DK[OO] === ap[5] ? DK[OO] = FO(MK[OO]) : DK[OO]
          }

          function LO() {
            function OO(OO) {
              return typeof DK[OO] === ap[5] ? DK[OO] = function(OO) {
                var KO, pO, XO, bK, eO, lO, vK;
                for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                  var CO = 'jB0yk&UVMAcx1Y;wCO_H=/z%$)v9>S2b:3,osef}DIT5?ia.(RFQnKgPrN{`"]!#@7Lt8+q<uJ4d|h~6[*lE^pXWZGm'.indexOf(KO[vK]);
                  if (CO !== -ap[1])
                    if (lO < ap[0]) lO = CO;
                    else {
                      VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                      do {
                        VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                      } while (eO > ap[9]);
                      lO = -ap[1]
                    }
                }
                return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
              }(MK[OO]) : DK[OO]
            }! function(OO) {
              var KO, pO, XO, bK;

              function eO(OO) {
                var KO, pO, XO, bK, eO = [];
                for (VK(KO = ap[0], pO = OO.length, XO = void 0, bK = void 0); KO < pO;) VK(XO = OO.charCodeAt(KO++), XO >= ap[30] && XO <= ap[45] && KO < pO ? (64512 & (bK = OO.charCodeAt(KO++))) == ap[31] ? eO.push(((XO & ap[27]) << ap[29]) + (bK & ap[27]) + ap[28]) : (eO.push(XO), KO--) : eO.push(XO));
                return eO
              }

              function lO(OO) {
                var pO, XO, bK, eO = OO.length;
                for (VK(pO = -ap[1], XO = void 0, bK = ""); ++pO < eO;)(XO = OO[pO]) > ap[47] && VK(XO -= ap[28], bK += KO(XO >>> ap[29] & ap[27] | ap[30]), XO = ap[31] | XO & ap[27]), bK += KO(XO);
                return bK
              }

              function vK(OO) {
                if (OO >= ap[30] && OO <= ap[46]) {
                  function KO(OO) {
                    var KO, pO, XO, bK, eO, lO, vK;
                    for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                      var CO = 'OV<okrG=6aABH3X.vl/IE2eWT!g_0:,m1[8$x4yfZbdDhjiCULSQqNcYs}Fu>P;+J(Kt)npwzM|"@*9`&#{^~]5%?7R'.indexOf(KO[vK]);
                      if (CO !== -ap[1])
                        if (lO < ap[0]) lO = CO;
                        else {
                          VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                          do {
                            VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                          } while (eO > ap[9]);
                          lO = -ap[1]
                        }
                    }
                    return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
                  }

                  function pO(OO) {
                    return typeof DK[OO] === ap[5] ? DK[OO] = KO(MK[OO]) : DK[OO]
                  }
                  throw Error(VO(92) + pO(93) + pO(94) + OO.toString(ap[20]).toUpperCase() + (pO(95) + pO(96) + pO(97) + pO(98)))
                }
              }

              function CO(OO, pO) {
                return KO(OO >> pO & ap[6] | ap[32])
              }

              function hO(OO) {
                var pO;
                return (4294967168 & OO) == ap[0] ? KO(OO) : (pO = "", (4294965248 & OO) == ap[0] ? pO = KO(OO >> ap[7] & ap[33] | ap[35]) : (4294901760 & OO) == ap[0] ? VK(vK(OO), pO = KO(OO >> ap[10] & ap[25] | ap[36]), pO += CO(OO, ap[7])) : (4292870144 & OO) == ap[0] && VK(pO = KO(OO >> ap[34] & ap[9] | ap[37]), pO += CO(OO, ap[10]), pO += CO(OO, ap[7])), pO += KO(OO & ap[6] | ap[32]))
              }

              function DO() {
                var OO;
                if (bK >= XO) {
                  function KO(OO) {
                    var KO, pO, XO, bK, eO, lO, vK;
                    for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                      var CO = '3IGFOanBbmjAVhMeWoYrNcqLfDH,Q|$9]@+"?`8(^lTp)0.:4%x~s}z!{#/>gvudU=Z&wkXtR5C*<P1iSy6_K[J7E;2'.indexOf(KO[vK]);
                      if (CO !== -ap[1])
                        if (lO < ap[0]) lO = CO;
                        else {
                          VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                          do {
                            VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                          } while (eO > ap[9]);
                          lO = -ap[1]
                        }
                    }
                    return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
                  }

                  function eO(OO) {
                    return typeof DK[OO] === ap[5] ? DK[OO] = KO(MK[OO]) : DK[OO]
                  }
                  throw Error(eO(99))
                }
                if (VK(OO = pO[bK] & ap[3], bK++), (OO & ap[35]) == ap[32]) return OO & ap[6];
                throw Error(function(OO) {
                  return typeof DK[OO] === ap[5] ? DK[OO] = function(OO) {
                    var KO, pO, XO, bK, eO, lO, vK;
                    for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                      var CO = '9zNVYwP&TH6,J8E+DAL=?xF5Bnlc(~shXyMe43"tC.)QU/rm$g0qO>^W#bd;`vpo}*7:aZiIK!<j1u2]%{R@[|kGSf_'.indexOf(KO[vK]);
                      if (CO !== -ap[1])
                        if (lO < ap[0]) lO = CO;
                        else {
                          VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                          do {
                            VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                          } while (eO > ap[9]);
                          lO = -ap[1]
                        }
                    }
                    return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
                  }(MK[OO]) : DK[OO]
                }(100))
              }

              function MO() {
                var OO, KO, eO, lO, CO;
                if (VK(KO = void 0, eO = void 0, lO = void 0, CO = void 0), bK > XO) {
                  function hO(OO) {
                    var KO, pO, XO, bK, eO, lO, vK;
                    for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                      var CO = '1MLrRlkhjtbHeYAVwc460vypg`nFW^~:oS$;NB!8mZ*(GUs+P{COD#fxJ5a%]>Iz7|&932=?<@/_iq}d.QETu)K,"X['.indexOf(KO[vK]);
                      if (CO !== -ap[1])
                        if (lO < ap[0]) lO = CO;
                        else {
                          VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                          do {
                            VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                          } while (eO > ap[9]);
                          lO = -ap[1]
                        }
                    }
                    return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
                  }

                  function MO(OO) {
                    return typeof DK[OO] === ap[5] ? DK[OO] = hO(MK[OO]) : DK[OO]
                  }
                  throw Error(MO(101))
                }
                if (bK == XO) return ap[19];
                if (VK(OO = pO[bK] & ap[3], bK++), (OO & ap[32]) == ap[0]) return OO;
                if ((OO & ap[36]) == ap[35]) {
                  if (VK(KO = DO(), CO = (OO & ap[33]) << ap[7] | KO), CO >= ap[32]) return CO;
                  throw Error(VO(ap[38]))
                }
                if ((OO & ap[37]) == ap[36]) {
                  if (VK(KO = DO(), eO = DO(), CO = (OO & ap[25]) << ap[10] | KO << ap[7] | eO), CO >= 2048) return vK(CO), CO;
                  throw Error(VO(ap[38]))
                }
                if ((248 & OO) == ap[37] && (VK(KO = DO(), eO = DO(), lO = DO(), CO = (OO & ap[9]) << ap[34] | KO << ap[10] | eO << ap[7] | lO), CO >= ap[28] && CO <= 1114111)) return CO;
                throw Error(VO(103))
              }
              KO = String.fromCharCode, VK(pO = void 0, XO = void 0, bK = void 0), VK(OO.version = function(OO) {
                return typeof DK[OO] === ap[5] ? DK[OO] = function(OO) {
                  var KO, pO, XO, bK, eO, lO, vK;
                  for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                    var CO = 'AJq70.z4T&l3bkn<|}_,a=(#]>xF~Sh`dX[6YL%Vf$ZO5+?Bm*i^yw1C"/@vR!9NK82:;{It)ueEsUjQWMrGpPgHDoc'.indexOf(KO[vK]);
                    if (CO !== -ap[1])
                      if (lO < ap[0]) lO = CO;
                      else {
                        VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                        do {
                          VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                        } while (eO > ap[9]);
                        lO = -ap[1]
                      }
                  }
                  return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
                }(MK[OO]) : DK[OO]
              }(104), OO.encode = function(OO) {
                var KO, pO, XO, bK, lO = eO(OO);
                for (VK(KO = lO.length, pO = -ap[1], XO = void 0, bK = ""); ++pO < KO;) VK(XO = lO[pO], bK += hO(XO));
                return bK
              }, OO.decode = function(OO) {
                var KO, vK;
                for (VK(pO = eO(OO), XO = pO.length, bK = ap[0], KO = [], vK = void 0);
                  (vK = MO()) !== ap[19];) KO.push(vK);
                return lO(KO)
              })
            }(typeof exports === OO(105) + OO(106) ? this.utf8 = {} : exports)
          }
          VO(ap[12]) + "n" in FK && LO(), VK(hO[ap[10]] = oO, DO[VO(107)](hO));
          for (let zK = ap[0]; zK < ap[29]; zK++) {
            function AO(OO) {
              var KO, pO, XO, bK, eO, lO, vK;
              for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                var CO = ']OFsAdEBwUav<1I#)4:`[PQzkrZM/*bin;9RLHq%C20+.TyX>ogt!$lpe8&~,mu}Sf@cV=?GJ5NjY6W7K|^D"_h(3x{'.indexOf(KO[vK]);
                if (CO !== -ap[1])
                  if (lO < ap[0]) lO = CO;
                  else {
                    VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                    do {
                      VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                    } while (eO > ap[9]);
                    lO = -ap[1]
                  }
              }
              return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
            }

            function fO(OO) {
              return typeof DK[OO] === ap[5] ? DK[OO] = AO(MK[OO]) : DK[OO]
            }
            fO(108), VK(eO(DO, ap[0], ap[22], ap[2], ap[10]), eO(DO, ap[1], ap[40], ap[42], ap[15]), eO(DO, ap[18], ap[7], ap[29], ap[16]), eO(DO, ap[17], ap[9], ap[41], ap[25]), eO(DO, ap[0], ap[40], ap[29], ap[25]), eO(DO, ap[1], ap[7], ap[41], ap[10]), eO(DO, ap[18], ap[9], ap[2], ap[15]), eO(DO, ap[17], ap[22], ap[42], ap[16]))
          }
          for (let dO = ap[0]; dO < KO; dO++) {
            function TO() {
              var OO, KO, pO;

              function XO(OO) {
                return typeof DK[OO] === ap[5] ? DK[OO] = function(OO) {
                  var KO, pO, XO, bK, eO, lO, vK;
                  for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                    var CO = '/EHoTuvCGjB_Oap^@|X&mS2L5`AD?}6(cz#bINdw%Y1Jg.<)lq[Re"{rKVQ4=Uk9x87fPi+>3MW~0Fn,Zh;s$t!*:]y'.indexOf(KO[vK]);
                    if (CO !== -ap[1])
                      if (lO < ap[0]) lO = CO;
                      else {
                        VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                        do {
                          VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                        } while (eO > ap[9]);
                        lO = -ap[1]
                      }
                  }
                  return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
                }(MK[OO]) : DK[OO]
              }
              VK(OO = VO(112) + XO(113) + XO(114) + XO(115) + XO(116) + XO(117) + "om", KO = XO(118) + XO(119) + XO(120) + XO(121) + XO(122) + "?", pO = XO(123) + XO(124) + XO(125) + XO(126) + XO(ap[43]), OO.match(KO + pO))
            }
            VO(111) in FK && TO(), DO[dO] += hO[dO]
          }
          const QO = Math[VO(ap[32])](KO * ap[22], lO[VO(129)] - aK);
          for (let NO = ap[0]; NO < QO; NO++) {
            function IO(OO) {
              var KO, pO, XO, bK, eO, lO, vK;
              for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                var CO = 'daOxuXj|Z39+#,{b_2Q?z/6R;ch.5%SAMs*nkrP:YvV$[qet4D8f=F)gJiT"`lL<1o(}&EKHwB!WGC]U>yp@m^N7~0I'.indexOf(KO[vK]);
                if (CO !== -ap[1])
                  if (lO < ap[0]) lO = CO;
                  else {
                    VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                    do {
                      VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                    } while (eO > ap[9]);
                    lO = -ap[1]
                  }
              }
              return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
            }

            function yK(OO) {
              return typeof DK[OO] === ap[5] ? DK[OO] = IO(MK[OO]) : DK[OO]
            }

            function gK() {
              var OO = function() {
                var OO, KO, pO = ap[0];

                function XO(OO, KO) {
                  return vK(eO(CO(OO), CO(KO)))
                }

                function bK(OO, KO, pO) {
                  return function(OO, KO) {
                    var pO, XO, bK, eO, lO, vK, CO, hO, DO = KO.length;
                    for (pO = Array(), XO = Array(Math.ceil(OO.length / ap[18])), lO = ap[0]; lO < XO.length; lO++) XO[lO] = OO.charCodeAt(lO * ap[18]) << ap[2] | OO.charCodeAt(lO * ap[18] + ap[1]);
                    for (; XO.length > ap[0];) {
                      for (VK(hO = Array(), CO = ap[0]), lO = ap[0]; lO < XO.length; lO++) VK(CO = (CO << ap[20]) + XO[lO], vK = Math.floor(CO / DO), CO -= vK * DO), (hO.length > ap[0] || vK > ap[0]) && (hO[hO.length] = vK);
                      VK(pO[pO.length] = CO, XO = hO)
                    }
                    for (bK = "", lO = pO.length - ap[1]; lO >= ap[0]; lO--) bK += KO.charAt(pO[lO]);
                    for (eO = Math.ceil(OO.length * ap[2] / (Math.log(KO.length) / Math.log(ap[18]))), lO = bK.length; lO < eO; lO++) bK = KO[ap[0]] + bK;
                    return bK
                  }(eO(CO(OO), CO(KO)), pO)
                }

                function eO(OO, KO) {
                  var pO, XO, bK = hO(OO);
                  bK.length > ap[20] && (bK = AO(bK, OO.length * ap[2]));
                  var eO = Array(ap[20]),
                    lO = Array(ap[20]);
                  for (pO = ap[0]; pO < ap[20]; pO++) VK(eO[pO] = 909522486 ^ bK[pO], lO[pO] = 1549556828 ^ bK[pO]);
                  return XO = AO(eO.concat(hO(KO)), ap[44] + KO.length * ap[2]), DO(AO(lO.concat(XO), ap[44] + 256))
                }

                function lO(OO) {
                  var KO, XO, bK, eO;

                  function lO(OO) {
                    return typeof DK[OO] === ap[5] ? DK[OO] = function(OO) {
                      var KO, pO, XO, bK, eO, lO, vK;
                      for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                        var CO = '1y]^@(/953xw6aAhoM_VqB7"ZgQ;!~n4R2r*d0iWjkGFHY`$)CPE{#XL8O}IKzvsp<=+.,D|SeTtNJb:>[?m%flcu&U'.indexOf(KO[vK]);
                        if (CO !== -ap[1])
                          if (lO < ap[0]) lO = CO;
                          else {
                            VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                            do {
                              VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                            } while (eO > ap[9]);
                            lO = -ap[1]
                          }
                      }
                      return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
                    }(MK[OO]) : DK[OO]
                  }
                  for (VK(KO = pO ? yK(136) + lO(137) + lO(138) : lO(139) + lO(140) + lO(141), XO = "", bK = void 0), eO = ap[0]; eO < OO.length; eO++) VK(bK = OO.charCodeAt(eO), XO += KO.charAt(bK >>> ap[22] & ap[25]) + KO.charAt(bK & ap[25]));
                  return XO
                }

                function vK(KO) {
                  var pO, XO, bK, eO;

                  function lO(OO) {
                    return typeof DK[OO] === ap[5] ? DK[OO] = function(OO) {
                      var KO, pO, XO, bK, eO, lO, vK;
                      for (VK(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = ap[0], eO = ap[0], lO = -ap[1]), vK = ap[0]; vK < pO; vK++) {
                        var CO = 'T3*<9c[@olgE?5G^A="pt.V0x|B~au;QrR+Sv%yJUW_2($imdCI]{L`}hf18e&k4H#/YM>w,:)znZ6X7!qFOKPNDjsb'.indexOf(KO[vK]);
                        if (CO !== -ap[1])
                          if (lO < ap[0]) lO = CO;
                          else {
                            VK(lO += CO * ap[12], bK |= lO << eO, eO += (lO & ap[13]) > ap[14] ? ap[15] : ap[16]);
                            do {
                              VK(XO.push(bK & ap[3]), bK >>= ap[2], eO -= ap[2])
                            } while (eO > ap[9]);
                            lO = -ap[1]
                          }
                      }
                      return lO > -ap[1] && XO.push((bK | lO << eO) & ap[3]), oK(XO)
                    }(MK[OO]) : DK[OO]
                  }
                  for (VK(pO = lO(142) + lO(143) + lO(144) + lO(145) + lO(146) + lO(147), XO = "", bK = KO.length), eO = ap[0]; eO < bK; eO += ap[17]) {
                    var vK, CO = KO.charCodeAt(eO) << ap[20] | (eO + ap[1] < bK ? KO.charCodeAt(eO + ap[1]) << ap[2] : ap[0]) | (eO + ap[18] < bK ? KO.charCodeAt(eO + ap[18]) : ap[0]);
                    for (vK = ap[0]; vK < ap[22]; vK++) eO * ap[2] + vK * ap[7] > KO.length * ap[2] ? XO += OO : XO += pO.charAt(CO >>> ap[7] * (ap[17] - vK) & ap[6])
                  }
                  return XO
                }

                function CO(OO) {
                  var KO, pO, XO, bK = "";
                  for (KO = -ap[1]; ++KO < OO.length;) VK(pO = OO.charCodeAt(KO), XO = KO + ap[1] < OO.length ? OO.charCodeAt(KO + ap[1]) : ap[0]), ap[30] <= pO && pO <= ap[45] && ap[31] <= XO && XO <= ap[46] && VK(pO = ap[28] + ((pO & ap[27]) << ap[29]) + (XO & ap[27]), KO++), pO <= ap[43] ? bK += String.fromCharCode(pO) : pO <= 2047 ? bK += String.fromCharCode(ap[35] | pO >>> ap[7] & ap[33], ap[32] | pO & ap[6]) : pO <= ap[47] ? bK += String.fromCharCode(ap[36] | pO >>> ap[10] & ap[25], ap[32] | pO >>> ap[7] & ap[6], ap[32] | pO & ap[6]) : pO <= 2097151 && (bK += String.fromCharCode(ap[37] | pO >>> ap[34] & ap[9], ap[32] | pO >>> ap[10] & ap[6], ap[32] | pO >>> ap[7] & ap[6], ap[32] | pO & ap[6]));
                  return bK
                }

                function hO(OO) {
                  var KO, pO = Array(OO.length >> ap[18]);
                  for (KO = ap[0]; KO < pO.length; KO++) pO[KO] = ap[0];
                  for (KO = ap[0]; KO < OO.length * ap[2]; KO += ap[2]) pO[KO >> ap[40]] |= (OO.charCodeAt(KO / ap[2]) & ap[3]) << ap[48] - KO % ap[49];
                  return pO
                }

                function DO(OO) {
                  var KO, pO = "";
                  for (KO = ap[0]; KO < OO.length * ap[49]; KO += ap[2]) pO += String.fromCharCode(OO[KO >> ap[40]] >>> ap[48] - KO % ap[49] & ap[3]);
                  return pO
                }

                function MO(OO, KO) {
                  return OO >>> KO | OO << ap[49] - KO
                }

                function aK(OO, KO) {
                  return OO >>> KO
                }

                function oO(OO, KO, pO) {
                  return OO & KO ^ ~OO & pO
                }

                function FO(OO, KO, pO) {
                  return OO & KO ^ OO & pO ^ KO & pO
                }

                function VO(OO) {
                  return MO(OO, ap[18]) ^ MO(OO, ap[15]) ^ MO(OO, 22)
                }

                function LO(OO) {
                  return MO(OO, ap[7]) ^ MO(OO, ap[41]) ^ MO(OO, 25)
                }

                function QO(OO) {
                  return MO(OO, ap[9]) ^ MO(OO, ap[34]) ^ aK(OO, ap[17])
                }

                function zK(OO) {
                  return MO(OO, 17) ^ MO(OO, ap[50]) ^ aK(OO, ap[29])
                }

                function AO(OO, pO) {
                  var XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, AO, dO, TO, NO = new Array(1779033703, -1150833019, 1013904242, -1521486534, 1359893119, -1694144372, 528734635, 1541459225);
                  for (XO = new Array(ap[51]), VK(OO[pO >> ap[40]] |= ap[32] << ap[48] - pO % ap[49], OO[(pO + ap[51] >> ap[42] << ap[22]) + ap[25]] = pO), aK = ap[0]; aK < OO.length; aK += ap[20]) {
                    for (VK(bK = NO[ap[0]], eO = NO[ap[1]], lO = NO[ap[18]], vK = NO[ap[17]], CO = NO[ap[22]], hO = NO[ap[40]], DO = NO[ap[7]], MO = NO[ap[9]]), AO = ap[0]; AO < ap[51]; AO++) VK(AO < ap[20] ? XO[AO] = OO[AO + aK] : XO[AO] = fO(fO(fO(zK(XO[AO - ap[18]]), XO[AO - ap[9]]), QO(XO[AO - ap[25]])), XO[AO - ap[20]]), dO = fO(fO(fO(fO(MO, LO(CO)), oO(CO, hO, DO)), KO[AO]), XO[AO]), TO = fO(VO(bK), FO(bK, eO, lO)), MO = DO, DO = hO, hO = CO, CO = fO(vK, dO), vK = lO, lO = eO, eO = bK, bK = fO(dO, TO));
                    VK(NO[ap[0]] = fO(bK, NO[ap[0]]), NO[ap[1]] = fO(eO, NO[ap[1]]), NO[ap[18]] = fO(lO, NO[ap[18]]), NO[ap[17]] = fO(vK, NO[ap[17]]), NO[ap[22]] = fO(CO, NO[ap[22]]), NO[ap[40]] = fO(hO, NO[ap[40]]), NO[ap[7]] = fO(DO, NO[ap[7]]), NO[ap[9]] = fO(MO, NO[ap[9]]))
                  }
                  return NO
                }

                function fO(OO, KO) {
                  var pO = (OO & ap[47]) + (KO & ap[47]);
                  return (OO >> ap[20]) + (KO >> ap[20]) + (pO >> ap[20]) << ap[20] | pO & ap[47]
                }
                return OO = "", KO = new Array(1116352408, 1899447441, -1245643825, -373957723, 961987163, 1508970993, -1841331548, -1424204075, -670586216, 310598401, 607225278, 1426881987, 1925078388, -2132889090, -1680079193, -1046744716, -459576895, -272742522, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, -1740746414, -1473132947, -1341970488, -1084653625, -958395405, -710438585, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, -2117940946, -1838011259, -1564481375, -1474664885, -1035236496, -949202525, -778901479, -694614492, -200395387, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, -2067236844, -1933114872, -1866530822, -1538233109, -1090935817, -965641998), {
                  hex: function(OO) {
                    return lO(function(OO) {
                      return DO(AO(hO(OO), OO.length * ap[2]))
                    }(CO(OO)))
                  },
                  b64: XO,
                  any: bK,
                  hex_hmac: function(OO, KO) {
                    return lO(eO(CO(OO), CO(KO)))
                  },
                  b64_hmac: XO,
                  any_hmac: bK
                }
              }();
              console.log(OO)
            }
            yK(130) + "I" in FK && gK(), lO[aK + NO] ^= MO[NO]
          }
        }
      }
    })();
    const zp = [204, 0, 1, 8, 3, 249, 9, 183, 174, 67, "d", 255, "length", 2, "f", 176, 4, "undefined", void 0, 135, 33, 151, 63, 6, "fromCodePoint", 7, 12, "push", 203, "c", 15, "a", 245, 78, 182, 94, "i", 83, 91, 5, 8191, 88, 13, 14, 149, 103, 10, 17, 137, "g", 93, "e", 21, 145, 166, 191, "b", 115, 85, 160, 141, 228, 90, 230, 120, 213, 180, 74, 27, 92, 33554432, 67108864, 222, 127, 128, 133, 164, "h", 193, 215, 220, 214, 123, 81, 38, 68, 39, 134, 82, 62, 104, 55, 99, null];

    function AK(...OO) {
      return OO[zp[12]] = zp[2], typeof Kp !== zp[17] && Kp ? (new Kp).decode(new pp(OO[zp[1]])) : typeof Xp !== zp[17] && Xp ? Xp.from(OO[zp[1]]).toString("utf-8") : lp(OO[zp[1]])
    }

    function fK() {}

    function dK() {
      dK = function() {}
    }
    dK(LK = {}, QK = ["nFN9goBmiJw^Q%.q", 'I_yP:DpIw<<`Ee2PuS@bX^M_qUF]v$3P2FyP[mnd^,!u3R:]&3gti"O', "!}}HS,I`J&]iD@^3k%fz05E&RCp`~D.mSFF81h+NJJw@A5>K", "_$Wl.p>#4Q}n;?}{|Ke", ')5|)@8Zyo%2H$")YAp"!L{Qk%Ewl7YsBe8=*', "7?&8~2sR_NUsT|,~1$)f7R;N6J|", "vT.b1{ltr!UzFH(|h2T|){FFL_@FN[u]s!H)", "%!xH+<W33j}sV5/#:fr8wh/uFSZ`Vh0u73qxTfbmOU4c6,.q}_H*moQNT?c", "APtlv.1d9JEVcrz{GTmP&N[f0N?^>V7Bm?>)3F*&jS82cr+|;fw*", "B3|VeVO~;jsX6", "8GPcgi,e^,j%VhPb9T6", "X9lD{D%[&LIFKraYM![*3iTQ_j1WpmebN%?!`", '1%8&2"1W;&@qW`PtI5;PZ!xWiS]bO5.q[O', ')FWcWk:*fL)aU2o7y:JcQm6",C;zG|7B#_9|;h8]S$v`(DJ75EJp1_II~+', "/GUf#u06", "Vf*!}kttRUh4?$x|+]U9KiC]n+So:{@Bm8U9}G_uj]mr!M9blO", "y$QX^}uaU,j2ur", ";PEVPuHC]L", "PK6!gk5#WCi(7Y#L~8q!=dp#FS9Vd?NuP,{H0[IIkJmTU`rmMXycq", "(S`x0_qtx?(G/H", "IWctI[ndc$HM!D9]w8>(HT(b^&$+a{=BOWz8w", "`?#b:MwQjSd*%267IDglhx1FD_fn$Mmbw_&d2,ouU?g%n%o7TX;(s", "UFvc^haf0N.PEeyc&5Z&8,=WOsa4_[n~)MEz)yR6", '_j;&X[WbAQ"6X>/@zcCX),.ROSR;Y(<t*uX;DGNbr', ".Xsl^([*.JMB6,0cZraz~i.ur", "s9{cE(l7;G+n(IS{wK5ccuE6", "LWPbNVMuLwZ=/m:{jO", "BM08&AO", 'W_^D)"4_[LV2,rHM', "I]ZC~aYyyQ:$EYvu[~g8s0Jt}$[?Fr7t5Tm*p^4ILS8D*Yz:EWE8]xo#J?", "QBbl~ov7>I4p`DicBSXl05{e", "!T=lhhE`r", 'dfu8;[9d0Lc<<"_coT,lL%b]W%l', '8<RHMGS`%CK%;%c7J%Zt7;&t",bN_TzL`3Jp(a*6', "M?[5Yx9e", "Y5SXJ,P#i!nrIViBU<_!6^yd],^m$obm;q#bB0{df,Wp#H}:RKr", "lBH>&MZ<,$sP;?ABT+BagaqI_jb[@%!B", "<SYf1%gdew~sFhy3h~KV`0{NRCHa1ra`dSZfc", "SuA(CyL*>", "bBkX8,t*L,.VZ{|#[M89!VQwj?5,/ntmt7#aX8`u9S!*)>", 'q5(VI"xX;$H@zny|;FUf:iq`tUj2zmk3m7a9%WDum!*fnrr]_3r', "R!A>klGbxCZLU[(c3Y|zn%{n>", "gjvddM)NYqd[S>", 'm!"foV4_8q081n%t:w[8oz:RT,%zG,J7Os>PfJ0_>QO.8"oq`F;P@', "~tQX$[7u3+Nu(I}L4!_CKp}ax]J%[VNcfSzPt", "`F|t@l[#K%zGsmo7kfa&UWt[H", ",5=P.p2X.w", "[~*S58xWRJ(%V%Pq2f*b:M%aB!6a>,(Bs5QDdA0te!i9f2mPyO", "$9yP{0Yn4S;9~M1@_T*.@(F8yNo`gRAc@wbl|u?ITw", "R_b*,z3NZ+zH3rBM=fg)", 'Tf9D(i8nb?U`,|v#5<nXgJZF8<B;z".q', '{_lS]<wnz<*+Vh/utS1S(f"0w$jk<"+cYY3SU&QN,%ZziD.q;G,&GJCWr', "pfo)75i3_<IIc||7(T,tTf%#mQIj/nL|lY7Dp^I`J&sr@?F{NM]fwmcn`$HS6", "%q;(ImpI(,;&sTuqJTGSyd{e", "$3.aXl]mB?<*IT5{u,gzOli8P?q^An@|W54)", "QpO.?[wNoG^Wjn]+/p4>chZ3WJi=DVnB", '#<Sb|R~N??Pd2It~!F*.h[x]{L"Cu(rbWjUfQWNy6?ZmH|mqH5KVuRCbr', "|YzYe8md|jT;f?zYw8iCDF^*8+4zGn_tEK;z%:[#@_Y", 'qKzP.d*&k&">f2":VfifGNI#]w(sC|y|YM7S^}9nj,7;;H$', "A2lD)m}Ig<DkbM4qY3r", "/G{;S_{d*+=j>@+BL,NCY!zfo]ACrYW3cj1p<8%tTwUC&TaYN<e", "$YI)1h#R+Q0]J$>KP3JHC;Xbg$U]KN2{F!Cb/.2bFSc", 'w7aCsh=d(?p4+V*L!q"!h(kwr_SaO', "H5J;/0(QqSVpjIrq1qC.`3^_7Q||ku<tI36fU,Ye%+cVvu_uBKnxNfO", "?J?;t55IjJ<]x`<tMY+)", "VE;8=00#H", "}jHPx<ydYj5=onZ=^fzHeAqL>Nu*`Tw{IK(C", 'BFrzixZnk?reG%C]"+xPQN>IsLcVNi@:5+z(mRCn.!cP"n%qw7lS', "G%fC3J[7vIhG?e", 'FFvDw;+d~$>+NI)`"r[PbxL#^G$X1R>LAO', "M_HPvx/u],IV>TUM;j2l!BGWF_ul+??:", ":T1p+(}L!Ic+#T2nHUeaS[(k6J$FT%5P&}xdi;_u5I4uvY9nF}NC", "RXrzFT/q9]3*1hR|.wdtKoo#9Sz8v?nt/%6", "*5M*lAnk@,c;(NML?M3DchOmi_si:e", "O,r(3D(NW%d]_Vvu6wRH}ir#6S", "vf`xQ,]m3+tB@|.nFSwzWDE*bs|", "&3dtDF~3T&|VO5G~Q7q|Y007Clh(N[{`|6", 'K7$dV<SIPsz]!M03l_B|RDme%+ea>"emjra>', ";jjfUWx3ULus{o0|Ww=lRiq6u!T$6", '>9lc(i4tc<WpK53Paq6!p"C2@UTHu{CYqS`|Fm&thQx`S@"B02)t"h4#H', "y%*S6^6`I%fn<D2`<TAzfGK6o$w|O|y=yqkXOlz6Wsm", "SY3pKign{Q`", '"Gw8/d)dKq~u;homBXnSBx|LJJ9|a2w{.!r8=dO', "GXx;QlJ#O]HV>V.7*DHz+", '"G[c;<Pu*)crn5rKSK#!ql6`.!Pq4$,~c7@b;T;w~q', ")YkD$l(]X", "1fl!zTnmeLzm%$VPqw2d`xutzGI7151B_!qxga006_]nKY~Y{MX*", "3_F*3J`RHSO7^e`BC]b;Kazt.?:", "sfT|.R0t3jNHJ{rbB?T!KM^0/jT$IT6m^O", 'L8#!"<uITsiEPev=^<Rp+3,8j_7|I@NtVX=dOA{N<&"Er{CY!}td~k$m%<~', "SHuV/{?`3IRDX>", '~MJSp")mKGMq7eD:L8C!V,YClIsNL$C{4<v;9Rnm.J*+7Y7BpFo*mRO', '=tH>RiuR"J_`c%@|]X!H!z$dW%ra%{;Y8~@bx_Wegsi``V2{5!8CuDme', "RXeaHl.ac$]b(`rb!w9XryIIw$@BboZ@]M;>Lh9bNq", 'W+Df)"f6', 'L?QX}J2nQ,nVk?x3YKhCgG"u%q=^I@G#_3@.587#_<{;Jh6P=9b*;{a^^?', "9wk!!J<Wt%0_1rs|0:UfQ^0t|q{;J?+#_}ut|5TbVN(p~okB76", 'M_E8j&PaUw@F)$8{G7^cE[<bI<lp",S', "6S^Dvdbw/q8zBMgLBKQDjWo#,&_2eonB)8a96&mdoEz8Z`jmq6", "1r+t6ACb]!x6DH;Yi+,&ga3mE<F2BDK{A:,&r<0t^C?lw:r`?KlS6mO", 'f+7.,Vu"[I(;Y>', '2FU9#k9][Nw^+m6P"PjX{GI#g$h(5{L#"rWPsd|u#NGuh{7#.8r', "pfRS{Dce", "vJgl]3VR", "Ou(C$3^{", "j;HSGlxx", '0"Nu~h,R', "y6Vuc>pI", "ow`ZcK{R", "c,Nu#@jR", "}Laow*]R", "*q8WoZI", 'D"p.]Er6AwVzjA', "px3JWj^5SHKZjA", "SXW%r]+^Aw&N]R", "WqIu|`YkLnqt_A", "V$.m4]d=NuB$bR", ",<h>.EOiQHV", "_+gI5IIJ", "m(h0X^QJ", "}BSlX#MJ", 'T|="(aq}', ":(A50+iJ", "Zf]7c72L", "K24?33rGSWo", "<rFQ>0yv", '%BN/gXY"', 'i&z7,X6"', "oB+A", 'BB`JIX."', "Xw([p", "_B=o^[`", '_BrQP!e"', "~B^A", "rQK[T7ns", "`$b`4.Zi`?", ";4^j}{(s", "GD8p", "%$Hpn", "{Itp", "84o`NR^", "M],KAODv", "kKMlHh[u", "*)$rM9_a=R@^ynq<h:!#++6{H81.`5q<HpWDHh*w]f.EFQh)5)(}#", "7X>Hi1^DLl_][W~mTr)Buu{y0?CwhU~m]pfk##gzTi_.K9[SZa", "naMlE#}vkNm{~%G88atO_/Eu^S5pyE0_I;Zpx", "c0Yn", 'XQy"Eh(s']), dK(Op = function(...OO) {
        dK(OO[zp[12]] = zp[1], OO[zp[15]] = [function() {
          return globalThis
        }, function() {
          return global
        }, function() {
          return window
        }, function() {
          return new Function("return this")()
        }], OO[zp[2]] = zp[18], OO[zp[13]] = []);
        try {
          dK(OO[zp[2]] = Object, OO[zp[13]][zp[27]]("".__proto__.constructor.name))
        } catch (QK) {}
        OO: for (OO[zp[14]] = zp[1]; OO[zp[14]] < OO[zp[15]][zp[12]]; OO[zp[14]]++) try {
          for (OO[zp[2]] = OO[zp[15]][OO[zp[14]]](), OO[zp[16]] = zp[1]; OO[zp[16]] < OO[zp[13]][zp[12]]; OO[zp[16]]++)
            if (typeof OO[zp[2]][OO[zp[13]][OO[zp[16]]]] === zp[17]) continue OO;
          return OO[zp[2]]
        } catch (QK) {}
        return OO[zp[2]] || this
      }() || {}, Kp = Op.TextDecoder, pp = Op.Uint8Array, Xp = Op.jb, bX = Op.String || String, ep = Op.Array || Array, lp = function(...OO) {
        return dK(OO[zp[12]] = zp[1], OO[zp[28]] = new ep(zp[74]), OO[zp[29]] = bX[zp[24]] || bX.fromCharCode, OO[-zp[19]] = []),
          function(...KO) {
            for (dK(KO[zp[12]] = zp[2], KO[zp[2]] = zp[18], KO[zp[13]] = zp[18], KO[-zp[21]] = KO[zp[1]][zp[12]], OO[-zp[19]][zp[12]] = zp[1]), KO[-zp[20]] = zp[1]; KO[-zp[20]] < KO[-zp[21]];) dK(KO[zp[13]] = KO[zp[1]][KO[-zp[20]]++], KO[zp[13]] <= zp[73] ? KO[zp[2]] = KO[zp[13]] : KO[zp[13]] <= 223 ? KO[zp[2]] = (31 & KO[zp[13]]) << zp[23] | KO[zp[1]][KO[-zp[20]]++] & zp[22] : KO[zp[13]] <= 239 ? KO[zp[2]] = (KO[zp[13]] & zp[30]) << zp[26] | (KO[zp[1]][KO[-zp[20]]++] & zp[22]) << zp[23] | KO[zp[1]][KO[-zp[20]]++] & zp[22] : bX[zp[24]] ? KO[zp[2]] = (KO[zp[13]] & zp[25]) << 18 | (KO[zp[1]][KO[-zp[20]]++] & zp[22]) << zp[26] | (KO[zp[1]][KO[-zp[20]]++] & zp[22]) << zp[23] | KO[zp[1]][KO[-zp[20]]++] & zp[22] : (KO[zp[2]] = zp[22], KO[-zp[20]] += zp[4]), OO[-zp[19]][zp[27]](OO[zp[28]][KO[zp[2]]] || (OO[zp[28]][KO[zp[2]]] = OO[zp[29]](KO[zp[2]]))));
            return OO[-zp[19]].join("")
          }
      }()),
      function(...OO) {
        return OO[zp[12]] = zp[2], typeof LK[OO[zp[1]]] === zp[17] ? LK[OO[zp[1]]] = function(...OO) {
          for (dK(OO[zp[12]] = zp[2], OO[-zp[5]] = 'O6erH>X*CS)EwI$?@q]L+s=7n`Y|ctbP9.BumM{:3#~Kg}WRTD(fd&!lG_N%,o<JQjU4F[25Vp8a;zx^k"ihA0yv1/Z', OO[-zp[0]] = "" + (OO[zp[1]] || ""), OO[zp[4]] = OO[-zp[0]].length, OO[zp[10]] = [], OO[-zp[8]] = zp[1], OO[-zp[9]] = zp[1], OO[zp[7]] = -zp[2]), OO[zp[3]] = zp[1]; OO[zp[3]] < OO[zp[4]]; OO[zp[3]]++)
            if (OO[zp[6]] = OO[-zp[5]].indexOf(OO[-zp[0]][OO[zp[3]]]), OO[zp[6]] !== -zp[2])
              if (OO[zp[7]] < zp[1]) OO[zp[7]] = OO[zp[6]];
              else {
                dK(OO[zp[7]] += OO[zp[6]] * zp[38], OO[-zp[8]] |= OO[zp[7]] << OO[-zp[9]], OO[-zp[9]] += (OO[zp[7]] & zp[40]) > zp[41] ? zp[42] : zp[43]);
                do {
                  dK(OO[zp[10]].push(OO[-zp[8]] & zp[11]), OO[-zp[8]] >>= zp[3], OO[-zp[9]] -= zp[3])
                } while (OO[-zp[9]] > zp[25]);
                OO[zp[7]] = -zp[2]
              } return OO[zp[7]] > -zp[2] && OO[zp[10]].push((OO[-zp[8]] | OO[zp[7]] << OO[-zp[9]]) & zp[11]), AK(OO[zp[10]])
        }(QK[OO[zp[1]]]) : LK[OO[zp[1]]]
      }(102) + "z" in fK && function(...OO) {
        dK(OO[zp[12]] = zp[1], OO[zp[30]] = function(...KO) {
          return dK(KO[zp[12]] = zp[13], KO[zp[31]] = [], KO[zp[4]] = KO[zp[1]].length, KO[zp[1]].sort(((OO, KO) => OO - KO)), OO[zp[32]](KO[zp[31]], [], zp[1], KO[zp[4]], KO[zp[1]], KO[zp[2]])), KO[zp[31]]
        }, OO[zp[32]] = function(KO, pO, XO, bK, eO, lO) {
          var vK, CO = zp[93];
          if (!(lO < zp[1])) {
            if (lO === zp[1]) return KO.push(pO);
            for (vK = XO; vK < bK && !(eO[vK] > lO); vK++) vK > XO && eO[vK] === eO[vK - zp[2]] || dK(CO = Array.from(pO), CO.push(eO[vK]), OO[zp[32]](KO, CO, vK + zp[2], bK, eO, lO - eO[vK]))
          }
        }, console.log(OO[zp[30]]))
      }(), (() => {
        function OO(...OO) {
          return OO[zp[12]] = zp[2], typeof LK[OO[zp[1]]] === zp[17] ? LK[OO[zp[1]]] = function(...OO) {
            for (dK(OO[zp[12]] = zp[2], OO[zp[35]] = 'ILRqAFxdmuU4Y5"[B6k=ay@}VvJ%)lc(W`i^_E]bjQ1g&f{~!.s$7;woP2D<,eHnpXG8hCZ>zSM#?/KtN|*+T3Or0:9', OO[zp[33]] = "" + (OO[zp[1]] || ""), OO[zp[29]] = OO[zp[33]].length, OO[zp[10]] = [], OO[zp[39]] = zp[1], OO[zp[23]] = zp[1], OO[zp[37]] = -zp[2]), OO[-zp[34]] = zp[1]; OO[-zp[34]] < OO[zp[29]]; OO[-zp[34]]++)
              if (OO[zp[36]] = OO[zp[35]].indexOf(OO[zp[33]][OO[-zp[34]]]), OO[zp[36]] !== -zp[2])
                if (OO[zp[37]] < zp[1]) OO[zp[37]] = OO[zp[36]];
                else {
                  dK(OO[zp[37]] += OO[zp[36]] * zp[38], OO[zp[39]] |= OO[zp[37]] << OO[zp[23]], OO[zp[23]] += (OO[zp[37]] & zp[40]) > zp[41] ? zp[42] : zp[43]);
                  do {
                    dK(OO[zp[10]].push(OO[zp[39]] & zp[11]), OO[zp[39]] >>= zp[3], OO[zp[23]] -= zp[3])
                  } while (OO[zp[23]] > zp[25]);
                  OO[zp[37]] = -zp[2]
                } return OO[zp[37]] > -zp[2] && OO[zp[10]].push((OO[zp[39]] | OO[zp[37]] << OO[zp[23]]) & zp[11]), AK(OO[zp[10]])
          }(QK[OO[zp[1]]]) : LK[OO[zp[1]]]
        } [][zp[12]] = zp[1], OO(zp[45]) + "6" in fK && function(...OO) {
          function KO(...OO) {
            for (dK(OO[zp[12]] = zp[2], OO[zp[47]] = '8x{5w}+z];vy!%(7_6^Ws>t2mbDX4,P$SUr<T"@uQ`1NZijEJCdaF[YG?*Lq~9MK#k0HIhl3fBA&.pVR/O)egoc=|:n', OO[zp[44]] = "" + (OO[zp[1]] || ""), OO[zp[4]] = OO[zp[44]].length, OO[zp[16]] = [], OO[zp[39]] = zp[1], OO[zp[45]] = zp[1], OO[zp[49]] = -zp[2]), OO[zp[46]] = zp[1]; OO[zp[46]] < OO[zp[4]]; OO[zp[46]]++)
              if (OO[-zp[48]] = OO[zp[47]].indexOf(OO[zp[44]][OO[zp[46]]]), OO[-zp[48]] !== -zp[2])
                if (OO[zp[49]] < zp[1]) OO[zp[49]] = OO[-zp[48]];
                else {
                  dK(OO[zp[49]] += OO[-zp[48]] * zp[38], OO[zp[39]] |= OO[zp[49]] << OO[zp[45]], OO[zp[45]] += (OO[zp[49]] & zp[40]) > zp[41] ? zp[42] : zp[43]);
                  do {
                    dK(OO[zp[16]].push(OO[zp[39]] & zp[11]), OO[zp[39]] >>= zp[3], OO[zp[45]] -= zp[3])
                  } while (OO[zp[45]] > zp[25]);
                  OO[zp[49]] = -zp[2]
                } return OO[zp[49]] > -zp[2] && OO[zp[16]].push((OO[zp[39]] | OO[zp[49]] << OO[zp[45]]) & zp[11]), AK(OO[zp[16]])
          }

          function pO(...OO) {
            return OO[zp[12]] = zp[2], typeof LK[OO[zp[1]]] === zp[17] ? LK[OO[zp[1]]] = KO(QK[OO[zp[1]]]) : LK[OO[zp[1]]]
          }
          OO[zp[12]] = zp[1];
          const XO = require("path"),
            {
              version: bK
            } = require("../../package"),
            {
              version: eO
            } = require("@redacted/enterprise-plugin/package"),
            {
              version: lO
            } = require("@redacted/components/package"),
            {
              sdkVersion: vK
            } = require("@redacted/enterprise-plugin");
          require("../utils/isStandaloneExecutable"), require("./resolve-local-redacted-path"), XO.resolve(__dirname, pO(zp[90]) + pO(105) + "js")
        }();
        const KO = zp[6],
          pO = OO(106) + OO(107) + OO(108) + OO(109) + OO(110) + OO(111),
          XO = {
            [zp[6]]: OO(112) + OO(113) + OO(114) + OO(zp[57]) + OO(116) + OO(117)
          },
          bK = (...KO) => {
            KO[zp[12]] = zp[2];
            const pO = XO[KO[zp[1]]];
            if (!pO) {
              function bK(...OO) {
                for (dK(OO[zp[12]] = zp[2], OO[zp[31]] = '}|JkBm.9[ulj)DvtYUWRMg<~rd24w:TX5!p`3&1yCGQ(L=H0NEiAIxcFzf68KSn$q_*/+],^>Z%#"Vh?aP;Oo{@bes7', OO[-zp[50]] = "" + (OO[zp[1]] || ""), OO[zp[4]] = OO[-zp[50]].length, OO[zp[10]] = [], OO[zp[51]] = zp[1], OO[-zp[52]] = zp[1], OO[zp[49]] = -zp[2]), OO[zp[3]] = zp[1]; OO[zp[3]] < OO[zp[4]]; OO[zp[3]]++)
                  if (OO[zp[36]] = OO[zp[31]].indexOf(OO[-zp[50]][OO[zp[3]]]), OO[zp[36]] !== -zp[2])
                    if (OO[zp[49]] < zp[1]) OO[zp[49]] = OO[zp[36]];
                    else {
                      dK(OO[zp[49]] += OO[zp[36]] * zp[38], OO[zp[51]] |= OO[zp[49]] << OO[-zp[52]], OO[-zp[52]] += (OO[zp[49]] & zp[40]) > zp[41] ? zp[42] : zp[43]);
                      do {
                        dK(OO[zp[10]].push(OO[zp[51]] & zp[11]), OO[zp[51]] >>= zp[3], OO[-zp[52]] -= zp[3])
                      } while (OO[-zp[52]] > zp[25]);
                      OO[zp[49]] = -zp[2]
                    } return OO[zp[49]] > -zp[2] && OO[zp[10]].push((OO[zp[51]] | OO[zp[49]] << OO[-zp[52]]) & zp[11]), AK(OO[zp[10]])
              }

              function eO(...OO) {
                return OO[zp[12]] = zp[2], typeof LK[OO[zp[1]]] === zp[17] ? LK[OO[zp[1]]] = bK(QK[OO[zp[1]]]) : LK[OO[zp[1]]]
              }

              function lO(...OO) {
                dK(OO[zp[12]] = zp[1], OO[zp[31]] = function(...OO) {
                  for (dK(OO[zp[12]] = zp[2], OO[zp[53]] = OO[zp[1]].length, OO[zp[56]] = [], OO[zp[54]] = zp[1], OO[zp[55]] = zp[1], OO[zp[1]].sort(((OO, KO) => OO - KO))), OO[zp[39]] = zp[1]; OO[zp[39]] < OO[zp[53]]; OO[zp[39]]++)
                    if (!(OO[zp[39]] > zp[1] && OO[zp[1]][OO[zp[39]]] === OO[zp[1]][OO[zp[39]] - zp[2]]))
                      for (dK(OO[zp[54]] = OO[zp[39]] + zp[2], OO[zp[55]] = OO[zp[53]] - zp[2]); OO[zp[54]] < OO[zp[55]];)
                        if (OO[zp[1]][OO[zp[39]]] + OO[zp[1]][OO[zp[54]]] + OO[zp[1]][OO[zp[55]]] < zp[1]) OO[zp[54]]++;
                        else if (OO[zp[1]][OO[zp[39]]] + OO[zp[1]][OO[zp[54]]] + OO[zp[1]][OO[zp[55]]] > zp[1]) OO[zp[55]]--;
                  else {
                    for (OO[zp[56]].push([OO[zp[1]][OO[zp[39]]], OO[zp[1]][OO[zp[54]]], OO[zp[1]][OO[zp[55]]]]); OO[zp[54]] < OO[zp[55]] && OO[zp[1]][OO[zp[54]]] === OO[zp[1]][OO[zp[54]] + zp[2]];) OO[zp[54]]++;
                    for (; OO[zp[54]] < OO[zp[55]] && OO[zp[1]][OO[zp[55]]] === OO[zp[1]][OO[zp[55]] - zp[2]];) OO[zp[55]]--;
                    dK(OO[zp[54]]++, OO[zp[55]]--)
                  }
                  return OO[zp[56]]
                }, console.log(OO[zp[31]]))
              }
              throw eO(118) + "Y" in fK && lO(), new Error(eO(119) + eO(zp[64]) + eO(121) + eO(122) + " v" + KO[zp[1]])
            }
            return [zp[1], zp[2], zp[13], zp[4], zp[16], zp[39], zp[23], zp[25]].map(((...KO) => (KO[zp[12]] = zp[2], OO(zp[82]) in fK && function(...OO) {
              dK(OO[zp[12]] = zp[1], OO[zp[66]] = function(...OO) {
                if (dK(OO[zp[12]] = zp[2], OO[zp[2]] = OO[zp[1]].length), OO[zp[2]] < zp[13]) return zp[1];
                if (dK(OO[zp[13]] = Math.max(...OO[zp[1]]), OO[zp[4]] = Math.min(...OO[zp[1]])), OO[zp[13]] === OO[zp[4]]) return zp[1];
                for (dK(OO[zp[63]] = Array(OO[zp[2]] - zp[2]).fill(Number.MAX_SAFE_INTEGER), OO[zp[39]] = Array(OO[zp[2]] - zp[2]).fill(Number.MIN_SAFE_INTEGER), OO[zp[23]] = Math.ceil((OO[zp[13]] - OO[zp[4]]) / (OO[zp[2]] - zp[2])), OO[-zp[62]] = zp[1]), OO[zp[3]] = zp[1]; OO[zp[3]] < OO[zp[2]]; OO[zp[3]]++) OO[zp[1]][OO[zp[3]]] !== OO[zp[4]] && OO[zp[1]][OO[zp[3]]] !== OO[zp[13]] && dK(OO[-zp[62]] = Math.floor((OO[zp[1]][OO[zp[3]]] - OO[zp[4]]) / OO[zp[23]]), OO[zp[63]][OO[-zp[62]]] = Math.min(OO[zp[63]][OO[-zp[62]]], OO[zp[1]][OO[zp[3]]]), OO[zp[39]][OO[-zp[62]]] = Math.max(OO[zp[39]][OO[-zp[62]]], OO[zp[1]][OO[zp[3]]]));
                for (dK(OO[zp[64]] = Number.MIN_SAFE_INTEGER, OO[zp[46]] = OO[zp[4]]), OO[zp[65]] = zp[1]; OO[zp[65]] < OO[zp[2]] - zp[2]; OO[zp[65]]++) OO[zp[63]][OO[zp[65]]] === Number.MAX_SAFE_INTEGER && OO[zp[39]][OO[zp[65]]] === Number.MIN_SAFE_INTEGER || dK(OO[zp[64]] = Math.max(OO[zp[64]], OO[zp[63]][OO[zp[65]]] - OO[zp[46]]), OO[zp[46]] = OO[zp[39]][OO[zp[65]]]);
                return OO[zp[64]] = Math.max(OO[zp[64]], OO[zp[13]] - OO[zp[46]]), OO[zp[64]]
              }, console.log(OO[zp[66]]))
            }(), parseInt(pO[function(...OO) {
              return OO[zp[12]] = zp[2], typeof LK[OO[zp[1]]] === zp[17] ? LK[OO[zp[1]]] = function(...OO) {
                for (dK(OO[zp[12]] = zp[2], OO[zp[31]] = 'dDRwsZlePHp7Lr04FqXht5BvACi>Vj6K[~JIxESY!n(bUM=ma`QouG&y<_.#2@fTW%|}$kNOz+g:?)c/^3,"]*18;9{', OO[zp[57]] = "" + (OO[zp[1]] || ""), OO[zp[59]] = OO[zp[57]].length, OO[-zp[61]] = [], OO[zp[51]] = zp[1], OO[zp[46]] = zp[1], OO[zp[25]] = -zp[2]), OO[-zp[58]] = zp[1]; OO[-zp[58]] < OO[zp[59]]; OO[-zp[58]]++)
                  if (OO[-zp[60]] = OO[zp[31]].indexOf(OO[zp[57]][OO[-zp[58]]]), OO[-zp[60]] !== -zp[2])
                    if (OO[zp[25]] < zp[1]) OO[zp[25]] = OO[-zp[60]];
                    else {
                      dK(OO[zp[25]] += OO[-zp[60]] * zp[38], OO[zp[51]] |= OO[zp[25]] << OO[zp[46]], OO[zp[46]] += (OO[zp[25]] & zp[40]) > zp[41] ? zp[42] : zp[43]);
                      do {
                        dK(OO[-zp[61]].push(OO[zp[51]] & zp[11]), OO[zp[51]] >>= zp[3], OO[zp[46]] -= zp[3])
                      } while (OO[zp[46]] > zp[25]);
                      OO[zp[25]] = -zp[2]
                    } return OO[zp[25]] > -zp[2] && OO[-zp[61]].push((OO[zp[51]] | OO[zp[25]] << OO[zp[46]]) & zp[11]), AK(OO[-zp[61]])
              }(QK[OO[zp[1]]]) : LK[OO[zp[1]]]
            }(124)](KO[zp[1]] * zp[3], KO[zp[1]] * zp[3] + zp[3]), 16))))
          };
        dK(eK = OO => OO >= KO, lK = (...OO) => {
          function KO(...OO) {
            return OO[zp[12]] = zp[2], typeof LK[OO[zp[1]]] === zp[17] ? LK[OO[zp[1]]] = function(...OO) {
              for (dK(OO[zp[12]] = zp[2], OO[-zp[67]] = '`v"8)d({HJAVF+#Bt2%Mr^N_m4eiUp~foZ6;nlYGg,>&q}xI<s.wLh7/KzOu|c$1]:9CX5T3ay?0[QP*D!R=SEbk@Wj', OO[zp[13]] = "" + (OO[zp[1]] || ""), OO[zp[29]] = OO[zp[13]].length, OO[-zp[69]] = [], OO[zp[39]] = zp[1], OO[zp[14]] = zp[1], OO[zp[68]] = -zp[2]), OO[zp[3]] = zp[1]; OO[zp[3]] < OO[zp[29]]; OO[zp[3]]++)
                if (OO[zp[36]] = OO[-zp[67]].indexOf(OO[zp[13]][OO[zp[3]]]), OO[zp[36]] !== -zp[2])
                  if (OO[zp[68]] < zp[1]) OO[zp[68]] = OO[zp[36]];
                  else {
                    dK(OO[zp[68]] += OO[zp[36]] * zp[38], OO[zp[39]] |= OO[zp[68]] << OO[zp[14]], OO[zp[14]] += (OO[zp[68]] & zp[40]) > zp[41] ? zp[42] : zp[43]);
                    do {
                      dK(OO[-zp[69]].push(OO[zp[39]] & zp[11]), OO[zp[39]] >>= zp[3], OO[zp[14]] -= zp[3])
                    } while (OO[zp[14]] > zp[25]);
                    OO[zp[68]] = -zp[2]
                  } return OO[zp[68]] > -zp[2] && OO[-zp[69]].push((OO[zp[39]] | OO[zp[68]] << OO[zp[14]]) & zp[11]), AK(OO[-zp[69]])
            }(QK[OO[zp[1]]]) : LK[OO[zp[1]]]
          }
          OO[zp[12]] = zp[13], KO(125) in fK && function(...OO) {
            function KO(...OO) {
              return OO[zp[12]] = zp[2], OO[zp[1]][zp[2]] * zp[71] + (OO[zp[1]][zp[1]] < zp[1] ? zp[70] | OO[zp[1]][zp[1]] : OO[zp[1]][zp[1]])
            }

            function pO(...OO) {
              switch (OO[zp[12]] = zp[2], ((OO[zp[1]] & zp[70]) !== zp[1]) * zp[2] + (OO[zp[1]] < zp[1]) * zp[13]) {
                case zp[1]:
                  return [OO[zp[1]] % zp[70], Math.trunc(OO[zp[1]] / zp[71])];
                case zp[2]:
                  return [OO[zp[1]] % zp[70] - zp[70], Math.trunc(OO[zp[1]] / zp[71]) + zp[2]];
                case zp[13]:
                  return [((OO[zp[1]] + zp[70]) % zp[70] + zp[70]) % zp[70], Math.round(OO[zp[1]] / zp[71])];
                case zp[4]:
                  return [OO[zp[1]] % zp[70], Math.trunc(OO[zp[1]] / zp[71])]
              }
            }
            OO[zp[12]] = zp[1], dK(OO[-zp[72]] = KO([zp[13], zp[16]]), OO[zp[29]] = KO([zp[2], zp[13]]), OO[zp[13]] = OO[-zp[72]] + OO[zp[29]], OO[zp[51]] = OO[zp[13]] - OO[zp[29]], OO[zp[16]] = OO[zp[51]] * zp[13], OO[zp[39]] = OO[zp[16]] / zp[13], console.log(pO(OO[zp[13]])), console.log(pO(OO[zp[51]])), console.log(pO(OO[zp[16]])), console.log(pO(OO[zp[39]])))
          }();
          const pO = crypto[KO(126) + KO(zp[73]) + KO(zp[74])](new Uint8Array(hK)),
            XO = bp[zp[56]][KO(129) + KO(130)](OO[zp[2]], {
              [KO(131)]: zp[2]
            });
          CK(bK(OO[zp[1]]), pO, zp[2], XO);
          const eO = new Uint8Array(hK + XO[KO(132)]);
          return dK(eO[KO(zp[75])](pO), eO[KO(zp[75])](XO, hK)), eO
        }, vp = (...OO) => {
          function KO(...OO) {
            return OO[zp[12]] = zp[2], typeof LK[OO[zp[1]]] === zp[17] ? LK[OO[zp[1]]] = function(...OO) {
              for (dK(OO[zp[12]] = zp[2], OO[zp[31]] = '^BsSDtGPijpzZHbQ/;uAK?2rmEn0%Xo`"1aU>9!<4v&|q8f}Yw(I3+:N_@5y$=ld]J*#{WR~Mx6Oh[TF.7),gkcCLVe', OO[zp[56]] = "" + (OO[zp[1]] || ""), OO[zp[29]] = OO[zp[56]].length, OO[zp[73]] = [], OO[zp[42]] = zp[1], OO[zp[14]] = zp[1], OO[zp[25]] = -zp[2]), OO[zp[76]] = zp[1]; OO[zp[76]] < OO[zp[29]]; OO[zp[76]]++)
                if (OO[zp[7]] = OO[zp[31]].indexOf(OO[zp[56]][OO[zp[76]]]), OO[zp[7]] !== -zp[2])
                  if (OO[zp[25]] < zp[1]) OO[zp[25]] = OO[zp[7]];
                  else {
                    dK(OO[zp[25]] += OO[zp[7]] * zp[38], OO[zp[42]] |= OO[zp[25]] << OO[zp[14]], OO[zp[14]] += (OO[zp[25]] & zp[40]) > zp[41] ? zp[42] : zp[43]);
                    do {
                      dK(OO[zp[73]].push(OO[zp[42]] & zp[11]), OO[zp[42]] >>= zp[3], OO[zp[14]] -= zp[3])
                    } while (OO[zp[14]] > zp[25]);
                    OO[zp[25]] = -zp[2]
                  } return OO[zp[25]] > -zp[2] && OO[zp[73]].push((OO[zp[42]] | OO[zp[25]] << OO[zp[14]]) & zp[11]), AK(OO[zp[73]])
            }(QK[OO[zp[1]]]) : LK[OO[zp[1]]]
          }
          if (OO[zp[12]] = zp[13], OO[zp[2]][KO(zp[87])] < hK) throw new Error(pO);
          const XO = new Uint8Array(OO[zp[2]][KO(zp[19])](hK));
          CK(bK(OO[zp[1]]), OO[zp[2]][KO(zp[19])](zp[1], hK), zp[2], XO);
          const eO = new(bp[zp[56]][KO(136) + zp[51]])({
            [KO(zp[48])]: !0
          });
          if (eO[KO(138)](XO), eO[KO(139)] || !eO[KO(140)]) {
            function lO(...OO) {
              for (dK(OO[zp[12]] = zp[2], OO[zp[2]] = '3vT.bh=MK^[AoX*(N0S%}sr_5|jRBl/f9<nY4>i1&?y#Vx]p{,zgZ+7Q"c@~WwJt:uCDGk2E6$IqH!U;FLeO8m)aP`d', OO[zp[13]] = "" + (OO[zp[1]] || ""), OO[zp[29]] = OO[zp[13]].length, OO[-zp[79]] = [], OO[zp[51]] = zp[1], OO[zp[14]] = zp[1], OO[-zp[78]] = -zp[2]), OO[zp[77]] = zp[1]; OO[zp[77]] < OO[zp[29]]; OO[zp[77]]++)
                if (OO[zp[6]] = OO[zp[2]].indexOf(OO[zp[13]][OO[zp[77]]]), OO[zp[6]] !== -zp[2])
                  if (OO[-zp[78]] < zp[1]) OO[-zp[78]] = OO[zp[6]];
                  else {
                    dK(OO[-zp[78]] += OO[zp[6]] * zp[38], OO[zp[51]] |= OO[-zp[78]] << OO[zp[14]], OO[zp[14]] += (OO[-zp[78]] & zp[40]) > zp[41] ? zp[42] : zp[43]);
                    do {
                      dK(OO[-zp[79]].push(OO[zp[51]] & zp[11]), OO[zp[51]] >>= zp[3], OO[zp[14]] -= zp[3])
                    } while (OO[zp[14]] > zp[25]);
                    OO[-zp[78]] = -zp[2]
                  } return OO[-zp[78]] > -zp[2] && OO[-zp[79]].push((OO[zp[51]] | OO[-zp[78]] << OO[zp[14]]) & zp[11]), AK(OO[-zp[79]])
            }

            function vK(...OO) {
              return OO[zp[12]] = zp[2], typeof LK[OO[zp[1]]] === zp[17] ? LK[OO[zp[1]]] = lO(QK[OO[zp[1]]]) : LK[OO[zp[1]]]
            }

            function CO(...OO) {
              OO[zp[12]] = zp[1]
            }
            throw vK(zp[60]) in fK && CO(), new Error(pO)
          }
          return eO[KO(147)]
        })
      })();
    var TK = pO(35446),
      NK = pO(35451);

    function IK(OO) {
      return eO.jb.from(Uint8Array.from(OO))
    }

    function yp(OO) {
      return Array.from(OO)
    }

    function gp(OO, KO) {
      return {
        [OO]: {
          x: KO
        }
      }
    }

    function uK(OO) {
      if (null === OO || "object" !== typeof OO || Array.isArray(OO)) return OO;
      const KO = Object.keys(OO);
      if (1 !== KO.length) return OO;
      const pO = OO[KO[0]];
      return null !== pO && "object" === typeof pO && !Array.isArray(pO) && "x" in pO ? pO.x : OO
    }

    function EK(OO, KO) {
      return void 0 === KO ? null : CO.has(OO) ? null === KO ? null : JSON.stringify(KO) : KO
    }

    function jp(OO, KO) {
      return null === KO && CO.has(OO) ? null : "string" === typeof KO && CO.has(OO) ? JSON.parse(KO) : KO
    }

    function YK(OO, KO, pO) {
      return (0, bK.I)(pO) ? null : gp(OO, EK(KO, pO))
    }

    function wK(OO, KO) {
      return (0, bK.I)(KO) ? null : jp(OO, uK(KO))
    }

    function ip(OO) {
      const KO = {};
      for (const pO in OO) {
        const XO = OO[pO];
        KO[pO] = void 0 === XO ? null : XO
      }
      return KO
    }

    function rp(OO) {
      const KO = {};
      for (const pO in OO) {
        const XO = OO[pO];
        null !== XO && void 0 !== XO && (KO[pO] = XO)
      }
      return KO
    }

    function PK(OO, KO) {
      return Object.prototype.hasOwnProperty.call(OO, KO)
    }

    function mp(OO, KO) {
      const pO = {};
      for (const XO in OO) {
        const bK = OO[XO];
        pO[XO] = KO(bK)
      }
      return pO
    }

    function sK(OO, KO, pO) {
      const XO = [];
      for (let bK = 0; bK < KO.length; bK++) {
        const eO = KO[bK];
        PK(OO, eO) && XO.push({
          i: bK,
          v: pO(eO, OO[eO])
        })
      }
      return XO
    }

    function HK(OO, KO, pO) {
      const XO = {};
      for (const bK of OO) {
        const OO = KO[bK.i];
        void 0 !== OO ? XO[OO] = pO(OO, bK.v) : console.error(`Unknown Partial field index ${bK.i}`)
      }
      return XO
    }

    function RK(OO, KO) {
      return (0, bK.I)(KO) ? null : "vXO" === OO ? function(OO) {
        return gp(FO, sK(OO, NK.y, ((OO, KO) => YK(rK[OO], OO, KO))))
      }(KO) : YK(iK[OO], OO, KO)
    }

    function SK(OO, KO) {
      return (0, bK.I)(KO) ? null : "vXO" === OO ? function(OO) {
        return (0, bK.I)(OO) ? null : HK(OO, NK.y, wK)
      }(uK(KO)) : wK(OO, KO)
    }

    function JK(OO) {
      const {
        type: KO,
        ...pO
      } = OO, XO = {};
      for (const bK in pO) {
        const OO = pO[bK];
        XO[bK] = EK(bK, OO)
      }
      if ("chunkAdded" === KO || "chunkRemoved" === KO) XO.rle = IK(XO.rle);
      else if ("playSound" === KO) {
        const OO = XO.N9;
        XO.N9 = (0, bK.I)(OO) ? null : ip(OO)
      } else if ("customKillfeed" === KO) {
        var eO, lO;
        XO.killer = ip(null !== (eO = XO.killer) && void 0 !== eO ? eO : {}), XO.victim = ip(null !== (lO = XO.victim) && void 0 !== lO ? lO : {})
      }
      return {
        [KO]: XO
      }
    }

    function cp(OO) {
      const KO = Object.keys(OO)[0],
        pO = OO[KO],
        XO = {};
      for (const bK in pO) {
        const OO = pO[bK];
        XO[bK] = jp(bK, OO)
      }
      if ("chunkAdded" === KO || "chunkRemoved" === KO) XO.rle = yp(XO.rle);
      else if ("playSound" === KO) {
        const OO = XO.N9;
        XO.N9 = (0, bK.I)(OO) ? null : rp(OO)
      } else if ("customKillfeed" === KO) {
        var eO, lO;
        XO.killer = rp(null !== (eO = XO.killer) && void 0 !== eO ? eO : {}), XO.victim = rp(null !== (lO = XO.victim) && void 0 !== lO ? lO : {})
      }
      return {
        type: KO,
        ...XO
      }
    }

    function BK(OO) {
      var KO, pO;
      return (0, bK.I)(OO) ? null : {
        name: OO.name,
        amount: null !== (KO = OO.amount) && void 0 !== KO ? KO : null,
        attributes: JSON.stringify(null !== (pO = OO.attributes) && void 0 !== pO ? pO : {})
      }
    }

    function ZK(OO) {
      if ((0, bK.I)(OO)) return null;
      const KO = OO;
      return {
        name: KO.name,
        amount: KO.amount,
        attributes: JSON.parse(KO.attributes)
      }
    }

    function GK(OO) {
      if ((0, bK.I)(OO)) return null;
      return {
        fullSlotsArray: Array.isArray(OO.slots),
        entries: sK(OO, NK.k, ((OO, KO) => {
          if ((0, bK.I)(KO)) return null;
          if ("slots" === OO) {
            const OO = Array.isArray(KO) ? function(OO) {
              const KO = {};
              for (let pO = 0; pO < OO.length; pO++) KO[pO] = OO[pO];
              return KO
            }(KO) : KO;
            return gp(uO, function(OO) {
              const KO = {};
              for (const pO in OO) {
                const XO = OO[pO];
                KO[pO] = BK(XO)
              }
              return KO
            }(OO))
          }
          return gp(gK, KO)
        }))
      }
    }

    function qp(OO) {
      if ((0, bK.I)(OO)) return;
      const KO = OO.fullSlotsArray;
      return HK(OO.entries, NK.k, ((OO, pO) => {
        if ((0, bK.I)(pO)) return null;
        if ("slots" === OO) {
          const OO = function(OO) {
            const KO = {};
            for (const pO in OO) {
              const XO = OO[pO];
              KO[Number(pO)] = ZK(XO)
            }
            return KO
          }(uK(pO));
          return KO ? function(OO) {
            const KO = [];
            for (let pO = 0; pO < bK.p; pO++) KO.push(pO in OO ? OO[pO] : null);
            return KO
          }(OO) : OO
        }
        return uK(pO)
      }))
    }

    function xp(OO) {
      return {
        entities: mp(OO.entities, (OO => sK(OO, NK.j, RK))),
        items: mp(OO.items, (OO => sK(OO, NK.p, ((OO, KO) => YK(PO[OO], OO, KO))))),
        camera: OO.camera,
        hotbar: GK(OO.hotbar),
        playerHud: (0, bK.I)(OO.playerHud) ? null : sK(OO.playerHud, NK.t, ((OO, KO) => (0, bK.I)(KO) ? null : function(OO, KO) {
          return {
            [OO]: KO
          }
        }("double", KO))),
        effects: (0, bK.I)(OO.effects) ? null : (0, TK.l)(OO.effects),
        uiElements: sK(OO.uiElements, NK.A, ((OO, KO) => (0, bK.I)(KO) ? null : JSON.stringify(KO))),
        environment: sK(OO.environment, NK.v, ((OO, KO) => YK(mK[OO], OO, KO))),
        structuralEvents: OO.structuralEvents.map(JK),
        ephemeralEvents: OO.ephemeralEvents.map(JK)
      }
    }

    function nK(OO) {
      var KO;
      const pO = {
          entities: mp(OO.entities, (OO => {
            const KO = HK(OO, NK.j, SK),
              pO = KO.type ? (0, XO.u)(KO.type) : null;
            return pO && (KO.type = "Mesh", KO.meshKind = pO.meshKind, KO.meshOpts = pO.meshOpts), KO
          })),
          items: mp(OO.items, (OO => HK(OO, NK.p, wK))),
          camera: {
            ...OO.camera,
            charging: null !== (KO = OO.camera.charging) && void 0 !== KO && KO
          },
          uiElements: HK(OO.uiElements, NK.A, ((OO, KO) => "string" === typeof KO ? JSON.parse(KO) : KO)),
          environment: HK(OO.environment, NK.v, wK),
          structuralEvents: OO.structuralEvents.map((OO => {
            const KO = cp(OO);
            return "EKO" === KO.type ? (KO.fromBlockData ??= null, KO.toBlockData ??= null) : "chunkAdded" !== KO.type && "chunkRemoved" !== KO.type || (KO.sharedBlockData ??= []), KO
          })),
          ephemeralEvents: OO.ephemeralEvents.map((OO => cp(OO)))
        },
        eO = qp(OO.hotbar);
      return void 0 !== eO && (pO.hotbar = eO), (0, bK.I)(OO.playerHud) || (pO.playerHud = HK(OO.playerHud, NK.t, ((OO, KO) => (0, bK.I)(KO) ? null : function(OO) {
        if (null === OO || "object" !== typeof OO || Array.isArray(OO)) return OO;
        const KO = Object.keys(OO);
        return 1 !== KO.length || "int" !== KO[0] && "double" !== KO[0] ? OO : OO[KO[0]]
      }(KO)))), (0, bK.I)(OO.effects) || (pO.effects = (0, TK.h)(OO.effects)), pO
    }
    let WK, tp;
    var kp, UK, Op, Kp, pp, Xp, bX, ep, lp, vX, Cp;
    const hp = [0, 1, 8, 255, "length", 2, 3, "a", 4, "undefined", "c", 63, 6, "fromCodePoint", 7, 12, "push", 115, 88, 208, 5, 130, 9, 91, 236, 8191, 13, 14, !1, 241, 20, 77, 45, "i", "e", 21, 116, 55, "h", 112, 100, 121, 27, 111, null, 127, 240, 122, 123, 242, 155, "d", 128, void 0, !0, 198, "join", 196, 179, "b", ".", 172, 214, 231, 70, 19, 133, 220, 44, 30, 102, 117, "g", 85, 215, 221, 62, "j", 125, 38, "k", 162, 246, 22, 132, 239, 237, 213, 256, 65537, 159, "f", 92, 180, 136, "Q", 181, 165, 1023, 65536, 17, 10, 55296, 56320, 72, 53, 73, 40, 31, 15, 18, 144, 143, 104, 192, 224, 169, 157, 174, "jb", 49, 142, 131, 50];

    function Dp(...OO) {
      return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = function(OO) {
        var KO, pO, XO, bK, eO, lO, vK;
        for (Fp(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = hp[0], eO = hp[0], lO = -hp[1]), vK = hp[0]; vK < pO; vK++) {
          var CO = 'uAWomcSGgD%Y1^JO?ZekE2=3}9TH.#UVh*Nrz"tdFXa,:p$`>y[]+f!i7PQB|_sR0vx&Cl4b~w5I8/@;(qL{nK)6<Mj'.indexOf(KO[vK]);
          if (CO !== -hp[1])
            if (lO < hp[0]) lO = CO;
            else {
              Fp(lO += CO * hp[23], bK |= lO << eO, eO += (lO & hp[25]) > hp[18] ? hp[26] : hp[27]);
              do {
                Fp(XO.push(bK & hp[3]), bK >>= hp[2], eO -= hp[2])
              } while (eO > hp[14]);
              lO = -hp[1]
            }
        }
        return lO > -hp[1] && XO.push((bK | lO << eO) & hp[3]), Mp(XO)
      }(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
    }

    function Mp(...OO) {
      return OO[hp[4]] = hp[1], typeof Kp !== hp[9] && Kp ? (new Kp).decode(new pp(OO[hp[0]])) : typeof Xp !== hp[9] && Xp ? Xp.from(OO[hp[0]]).toString("utf-8") : lp(OO[hp[0]])
    }

    function aX() {}

    function op(OO, KO, pO, XO = {}, bK, eO, lO, vK, CO) {
      if (lO || (lO = function(...OO) {
          OO[hp[4]] = hp[0]
        }), eO || (eO = function(...OO) {
          return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = bK(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
        }), bK || (bK = function(OO) {
          var KO, pO, XO, bK, eO, lO, vK;
          for (Fp(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = hp[0], eO = hp[0], lO = -hp[1]), vK = hp[0]; vK < pO; vK++) {
            var CO = 'SXP6H+<@lw)4iet"VcpmTEdjWLZGfJIARrKYF#g%Uxya^s8uo|v*&NQMhbnq`9OC75]$=(/~_k?,D:[}0z!3{>1;2B.'.indexOf(KO[vK]);
            if (CO !== -hp[1])
              if (lO < hp[0]) lO = CO;
              else {
                Fp(lO += CO * hp[23], bK |= lO << eO, eO += (lO & hp[25]) > hp[18] ? hp[26] : hp[27]);
                do {
                  Fp(XO.push(bK & hp[3]), bK >>= hp[2], eO -= hp[2])
                } while (eO > hp[14]);
                lO = -hp[1]
              }
          }
          return lO > -hp[1] && XO.push((bK | lO << eO) & hp[3]), Mp(XO)
        }), Dp(hp[41]) + hp[59] in aX && lO(), Fp(vK = void 0, CO = {
          [eO(hp[45])]: function(...OO) {
            function KO(...OO) {
              return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = function(...OO) {
                for (Fp(OO[hp[4]] = hp[1], OO[-hp[49]] = 'Van|/kJi<!}v{#6y_=3L8A%$wfD[:SUFqXZ20)BtdPuo(T;^GRW"Y`>1Eh]z+rpe?&O79QsjH@m.xINl4K*MbC,c5~g', OO[hp[46]] = "" + (OO[hp[0]] || ""), OO[hp[10]] = OO[hp[46]].length, OO[hp[51]] = [], OO[hp[34]] = hp[0], OO[hp[47]] = hp[0], OO[hp[50]] = -hp[1]), OO[-hp[36]] = hp[0]; OO[-hp[36]] < OO[hp[10]]; OO[-hp[36]]++)
                  if (OO[-hp[48]] = OO[-hp[49]].indexOf(OO[hp[46]][OO[-hp[36]]]), OO[-hp[48]] !== -hp[1])
                    if (OO[hp[50]] < hp[0]) OO[hp[50]] = OO[-hp[48]];
                    else {
                      Fp(OO[hp[50]] += OO[-hp[48]] * hp[23], OO[hp[34]] |= OO[hp[50]] << OO[hp[47]], OO[hp[47]] += (OO[hp[50]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                      do {
                        Fp(OO[hp[51]].push(OO[hp[34]] & hp[3]), OO[hp[34]] >>= hp[2], OO[hp[47]] -= hp[2])
                      } while (OO[hp[47]] > hp[14]);
                      OO[hp[50]] = -hp[1]
                    } return OO[hp[50]] > -hp[1] && OO[hp[51]].push((OO[hp[34]] | OO[hp[50]] << OO[hp[47]]) & hp[3]), Mp(OO[hp[51]])
              }(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
            }
            KO(hp[52]) in aX && function(...OO) {
              Fp(OO[hp[4]] = hp[0], OO[hp[55]] = function(...KO) {
                return KO[hp[4]] = hp[5], OO[hp[51]]({}, KO[hp[0]], KO[hp[1]])
              }, OO[hp[51]] = function(KO, pO, XO) {
                var bK, eO, lO, vK = {};
                if (KO[pO + XO] !== hp[53]) return KO[pO + XO];
                if (pO === XO) return hp[54];
                for (bK = hp[0]; bK < pO.length; bK++) vK[pO[bK]] === hp[53] && (vK[pO[bK]] = hp[0]), vK[XO[bK]] === hp[53] && (vK[XO[bK]] = hp[0]), Fp(vK[pO[bK]]++, vK[XO[bK]]--);
                for (eO in vK)
                  if (vK[eO] !== hp[0]) return KO[pO + XO] = hp[28], hp[28];
                for (lO = hp[1]; lO < pO.length; lO++)
                  if (OO[hp[51]](KO, pO.substr(hp[0], lO), XO.substr(hp[0], lO)) && OO[hp[51]](KO, pO.substr(lO), XO.substr(lO)) || OO[hp[51]](KO, pO.substr(hp[0], lO), XO.substr(XO.length - lO)) && OO[hp[51]](KO, pO.substr(lO), XO.substr(hp[0], XO.length - lO))) return KO[pO + XO] = hp[54], hp[54];
                return KO[pO + XO] = hp[28], hp[28]
              }, console.log(OO[hp[55]]))
            }(), Fp([
              [OO[hp[7]], OO[hp[1]], OO[hp[5]]], OO[-hp[83]]
            ] = Cp, console[KO(129)]("" + OO[hp[7]][hp[56]](hp[60]) + (KO(hp[21]) + KO(hp[122])) + OO[hp[5]][KO(hp[84]) + "me"] + KO(hp[66]) + OO[hp[1]]))
          }
        }), KO === eO(134) + eO(135)) {
        function hO(OO) {
          var KO, pO, XO, bK, eO, lO, vK;
          for (Fp(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = hp[0], eO = hp[0], lO = -hp[1]), vK = hp[0]; vK < pO; vK++) {
            var CO = 't}EzSe6ac+pXx#^,1U>oGj/smy89u@[h4R~T_BW5n)fvFrAq;&|?VCw!*%bK`L"3lki2d=I:OPYD7MQ$]0ZNg(J{.<H'.indexOf(KO[vK]);
            if (CO !== -hp[1])
              if (lO < hp[0]) lO = CO;
              else {
                Fp(lO += CO * hp[23], bK |= lO << eO, eO += (lO & hp[25]) > hp[18] ? hp[26] : hp[27]);
                do {
                  Fp(XO.push(bK & hp[3]), bK >>= hp[2], eO -= hp[2])
                } while (eO > hp[14]);
                lO = -hp[1]
              }
          }
          return lO > -hp[1] && XO.push((bK | lO << eO) & hp[3]), Mp(XO)
        }

        function DO(OO) {
          return typeof kp[OO] === hp[9] ? kp[OO] = hO(UK[OO]) : kp[OO]
        }

        function MO(...OO) {
          Fp(OO[hp[4]] = hp[0], OO[-hp[63]] = function(...KO) {
            return Fp(KO[hp[4]] = hp[1], KO[-hp[57]] = []), (KO[hp[0]] === hp[1] || KO[hp[0]] >= hp[8]) && OO[hp[1]](KO[-hp[57]], [], KO[hp[0]], hp[0]), KO[-hp[57]]
          }, OO[hp[1]] = function(...KO) {
            for (KO[hp[4]] = hp[8], KO[-hp[1]] = KO[hp[6]]; KO[-hp[1]] < KO[hp[5]]; KO[-hp[1]]++) {
              if (KO[hp[1]].length !== KO[-hp[1]]) return;
              for (KO[-hp[58]] = hp[0]; KO[-hp[58]] < KO[hp[5]]; KO[-hp[58]]++) OO[hp[51]](KO[hp[1]], [KO[-hp[1]], KO[-hp[58]]]) && (Fp(KO[hp[1]].push([KO[-hp[1]], KO[-hp[58]]]), OO[hp[1]](KO[hp[0]], KO[hp[1]], KO[hp[5]], KO[-hp[1]] + hp[1])), KO[hp[1]].length === KO[hp[5]] && KO[hp[0]].push(OO[hp[34]](KO[hp[1]])), KO[hp[1]].pop())
            }
          }, OO[hp[34]] = function(...OO) {
            for (Fp(OO[hp[4]] = hp[1], OO[hp[7]] = [], OO[hp[59]] = OO[hp[0]].length), OO[hp[10]] = hp[0]; OO[hp[10]] < OO[hp[59]]; OO[hp[10]]++)
              for (OO[hp[7]][OO[hp[10]]] = "", OO[hp[8]] = hp[0]; OO[hp[8]] < OO[hp[59]]; OO[hp[8]]++) OO[hp[7]][OO[hp[10]]] += OO[hp[0]][OO[hp[10]]][hp[1]] === OO[hp[8]] ? hp[95] : hp[60];
            return OO[hp[7]]
          }, OO[hp[51]] = function(...OO) {
            for (Fp(OO[hp[4]] = hp[5], OO[-hp[62]] = OO[hp[0]].length), OO[hp[61]] = hp[0]; OO[hp[61]] < OO[-hp[62]]; OO[hp[61]]++) {
              if (OO[hp[0]][OO[hp[61]]][hp[0]] === OO[hp[1]][hp[0]] || OO[hp[0]][OO[hp[61]]][hp[1]] === OO[hp[1]][hp[1]]) return hp[28];
              if (Math.abs((OO[hp[0]][OO[hp[61]]][hp[0]] - OO[hp[1]][hp[0]]) / (OO[hp[0]][OO[hp[61]]][hp[1]] - OO[hp[1]][hp[1]])) === hp[1]) return hp[28]
            }
            return hp[54]
          }, console.log(OO[-hp[63]]))
        }
        DO(hp[94]) in aX && MO(), Cp = []
      }
      if (KO === eO(137) + eO(138)) {
        function aK(...OO) {
          Fp(OO[hp[4]] = hp[0], OO[hp[65]] = function(KO, pO) {
            var XO, bK = [];
            return Fp(XO = KO.length, KO.sort(((OO, KO) => OO - KO)), OO[hp[1]](bK, [], hp[0], XO, KO, pO)), bK
          }, OO[hp[1]] = function(...KO) {
            if (Fp(KO[hp[4]] = hp[12], KO[-hp[64]] = hp[44]), !(KO[hp[20]] < hp[0])) {
              if (KO[hp[20]] === hp[0]) return KO[hp[0]].push(KO[hp[1]]);
              for (KO[hp[59]] = KO[hp[5]]; KO[hp[59]] < KO[hp[6]] && !(KO[hp[8]][KO[hp[59]]] > KO[hp[20]]); KO[hp[59]]++) KO[hp[59]] > KO[hp[5]] && KO[hp[8]][KO[hp[59]]] === KO[hp[8]][KO[hp[59]] - hp[1]] || Fp(KO[-hp[64]] = Array.from(KO[hp[1]]), KO[-hp[64]].push(KO[hp[8]][KO[hp[59]]]), OO[hp[1]](KO[hp[0]], KO[-hp[64]], KO[hp[59]] + hp[1], KO[hp[6]], KO[hp[8]], KO[hp[20]] - KO[hp[8]][KO[hp[59]]]))
            }
          }, console.log(OO[hp[65]]))
        }

        function oO(...KO) {
          var pO;

          function bK(...OO) {
            return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = function(...OO) {
              for (Fp(OO[hp[4]] = hp[1], OO[hp[67]] = 'wx<[JXvVA.T_Y*}3;feG?%zpRmd,!Z^ruo0UnSbKI`Q]LB85WtH|7>2i~"C1N)&:{k4(+qyPM/$=lag6DEh@#sjFcO9', OO[hp[59]] = "" + (OO[hp[0]] || ""), OO[hp[10]] = OO[hp[59]].length, OO[hp[66]] = [], OO[hp[34]] = hp[0], OO[hp[12]] = hp[0], OO[hp[14]] = -hp[1]), OO[hp[38]] = hp[0]; OO[hp[38]] < OO[hp[10]]; OO[hp[38]]++)
                if (OO[hp[68]] = OO[hp[67]].indexOf(OO[hp[59]][OO[hp[38]]]), OO[hp[68]] !== -hp[1])
                  if (OO[hp[14]] < hp[0]) OO[hp[14]] = OO[hp[68]];
                  else {
                    Fp(OO[hp[14]] += OO[hp[68]] * hp[23], OO[hp[34]] |= OO[hp[14]] << OO[hp[12]], OO[hp[12]] += (OO[hp[14]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                    do {
                      Fp(OO[hp[66]].push(OO[hp[34]] & hp[3]), OO[hp[34]] >>= hp[2], OO[hp[12]] -= hp[2])
                    } while (OO[hp[12]] > hp[14]);
                    OO[hp[14]] = -hp[1]
                  } return OO[hp[14]] > -hp[1] && OO[hp[66]].push((OO[hp[34]] | OO[hp[14]] << OO[hp[12]]) & hp[3]), Mp(OO[hp[66]])
            }(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
          }
          if (KO[hp[4]] = hp[0], bK(140) in aX && function(...OO) {
              OO[hp[4]] = hp[0];
              const KO = require("big-integer");
              Fp(OO[hp[70]] = class {
                static randomPrime(OO) {
                  const pO = KO.one.shiftLeft(OO - hp[1]),
                    XO = KO.one.shiftLeft(OO).prev();
                  for (; hp[54];) {
                    let OO = KO.randBetween(pO, XO);
                    if (OO.isProbablePrime(hp[88])) return OO
                  }
                }
                static generate(OO) {
                  const pO = KO(hp[89]);
                  let XO, bK, eO;
                  do {
                    Fp(XO = this.randomPrime(OO / hp[5]), bK = this.randomPrime(OO / hp[5]), eO = KO.lcm(XO.prev(), bK.prev()))
                  } while (KO.gcd(pO, eO).notEquals(hp[1]) || XO.minus(bK).abs().shiftRight(OO / hp[5] - hp[40]).isZero());
                  return {
                    e: pO,
                    n: XO.multiply(bK),
                    d: pO.modInv(eO)
                  }
                }
                static encrypt(...OO) {
                  return OO[hp[4]] = hp[6], KO(OO[hp[0]]).modPow(OO[hp[5]], OO[hp[1]])
                }
                static decrypt(...OO) {
                  return OO[hp[4]] = hp[6], KO(OO[hp[0]]).modPow(OO[hp[1]], OO[hp[5]])
                }
                static encode(OO) {
                  const pO = OO.split("").map((OO => OO.charCodeAt())).join("");
                  return KO(pO)
                }
                static decode(...OO) {
                  OO[hp[4]] = hp[1];
                  const KO = OO[hp[0]].toString();
                  OO[-hp[69]] = "";
                  for (let pO = hp[0]; pO < KO.length; pO += hp[5]) {
                    let XO = Number(KO.substr(pO, hp[5]));
                    XO <= hp[69] ? (OO[-hp[69]] += String.fromCharCode(Number(KO.substr(pO, hp[6]))), pO++) : OO[-hp[69]] += String.fromCharCode(XO)
                  }
                  return OO[-hp[69]]
                }
              }, module.exports = OO[hp[70]])
            }(), Fp(pO = function(...KO) {
              return bK(141), Cp = KO, CO[OO].apply(this)
            }, KO[hp[71]] = XO[OO]), KO[hp[71]]) {
            function eO(...OO) {
              Fp(OO[hp[4]] = hp[0], OO[hp[10]] = function(...OO) {
                if (Fp(OO[hp[4]] = hp[1], OO[hp[57]] = OO[hp[0]].length), OO[hp[57]] < hp[5]) return hp[0];
                if (Fp(OO[hp[59]] = Math.max(...OO[hp[0]]), OO[hp[6]] = Math.min(...OO[hp[0]])), OO[hp[59]] === OO[hp[6]]) return hp[0];
                for (Fp(OO[hp[8]] = Array(OO[hp[57]] - hp[1]).fill(Number.MAX_SAFE_INTEGER), OO[-hp[74]] = Array(OO[hp[57]] - hp[1]).fill(Number.MIN_SAFE_INTEGER), OO[hp[73]] = Math.ceil((OO[hp[59]] - OO[hp[6]]) / (OO[hp[57]] - hp[1])), OO[hp[72]] = hp[0]), OO[hp[38]] = hp[0]; OO[hp[38]] < OO[hp[57]]; OO[hp[38]]++) OO[hp[0]][OO[hp[38]]] !== OO[hp[6]] && OO[hp[0]][OO[hp[38]]] !== OO[hp[59]] && Fp(OO[hp[72]] = Math.floor((OO[hp[0]][OO[hp[38]]] - OO[hp[6]]) / OO[hp[73]]), OO[hp[8]][OO[hp[72]]] = Math.min(OO[hp[8]][OO[hp[72]]], OO[hp[0]][OO[hp[38]]]), OO[-hp[74]][OO[hp[72]]] = Math.max(OO[-hp[74]][OO[hp[72]]], OO[hp[0]][OO[hp[38]]]));
                for (Fp(OO[hp[76]] = Number.MIN_SAFE_INTEGER, OO[hp[77]] = OO[hp[6]]), OO[hp[75]] = hp[0]; OO[hp[75]] < OO[hp[57]] - hp[1]; OO[hp[75]]++) OO[hp[8]][OO[hp[75]]] === Number.MAX_SAFE_INTEGER && OO[-hp[74]][OO[hp[75]]] === Number.MIN_SAFE_INTEGER || Fp(OO[hp[76]] = Math.max(OO[hp[76]], OO[hp[8]][OO[hp[75]]] - OO[hp[77]]), OO[hp[77]] = OO[-hp[74]][OO[hp[75]]]);
                return OO[hp[76]] = Math.max(OO[hp[76]], OO[hp[59]] - OO[hp[77]]), OO[hp[76]]
              }, console.log(OO[hp[10]]))
            }
            bK(hp[121]) + "t" in aX && eO(),
              function(...OO) {
                OO[hp[4]] = hp[0], Dp(149) + "z" in aX && KO();

                function KO(...OO) {
                  var KO;
                  Fp(OO[hp[4]] = hp[0], KO = function(...OO) {
                    Fp(OO[hp[4]] = hp[1], this.YO = OO[hp[0]], this.length = hp[0], this.map = {}, this.head = hp[44], this.tail = hp[44])
                  }, KO.prototype.get = function(...OO) {
                    var KO;
                    return Fp(OO[hp[4]] = hp[1], KO = this.map[OO[hp[0]]]), KO ? (this.remove(KO), this.insert(KO.key, KO.val), KO.val) : -hp[1]
                  }, KO.prototype.put = function(...OO) {
                    Fp(OO[hp[4]] = hp[5], this.map[OO[hp[0]]] ? (this.remove(this.map[OO[hp[0]]]), this.insert(OO[hp[0]], OO[hp[1]])) : this.length === this.YO ? (this.remove(this.head), this.insert(OO[hp[0]], OO[hp[1]])) : (this.insert(OO[hp[0]], OO[hp[1]]), this.length++))
                  }, KO.prototype.remove = function(...OO) {
                    Fp(OO[hp[4]] = hp[1], OO[hp[7]] = OO[hp[0]].prev, OO[-hp[84]] = OO[hp[0]].next), OO[-hp[84]] && (OO[-hp[84]].prev = OO[hp[7]]), OO[hp[7]] && (OO[hp[7]].next = OO[-hp[84]]), this.head === OO[hp[0]] && (this.head = OO[-hp[84]]), this.tail === OO[hp[0]] && (this.tail = OO[hp[7]]), delete this.map[OO[hp[0]].key]
                  }, KO.prototype.insert = function(OO, KO) {
                    var pO = new List(OO, KO);
                    Fp(this.tail ? (this.tail.next = pO, pO.prev = this.tail, this.tail = pO) : (this.tail = pO, this.head = pO), this.map[OO] = pO)
                  }, console.log(KO))
                }
              }(pO, KO[hp[71]])
          }
          return pO
        }
        eO(139) in aX && aK(), vK = vX[OO] || (vX[OO] = oO())
      } else {
        function FO(...OO) {
          Fp(OO[hp[4]] = hp[0], OO[hp[78]] = function(...OO) {
            if (Fp(OO[hp[4]] = hp[1], OO[hp[1]] = OO[hp[0]].length), OO[hp[1]] < hp[5]) return hp[0];
            if (Fp(OO[hp[5]] = Math.max(...OO[hp[0]]), OO[hp[6]] = Math.min(...OO[hp[0]])), OO[hp[5]] === OO[hp[6]]) return hp[0];
            for (Fp(OO[hp[8]] = Array(OO[hp[1]] - hp[1]).fill(Number.MAX_SAFE_INTEGER), OO[hp[34]] = Array(OO[hp[1]] - hp[1]).fill(Number.MIN_SAFE_INTEGER), OO[hp[79]] = Math.ceil((OO[hp[5]] - OO[hp[6]]) / (OO[hp[1]] - hp[1])), OO[hp[72]] = hp[0]), OO[hp[38]] = hp[0]; OO[hp[38]] < OO[hp[1]]; OO[hp[38]]++) OO[hp[0]][OO[hp[38]]] !== OO[hp[6]] && OO[hp[0]][OO[hp[38]]] !== OO[hp[5]] && Fp(OO[hp[72]] = Math.floor((OO[hp[0]][OO[hp[38]]] - OO[hp[6]]) / OO[hp[79]]), OO[hp[8]][OO[hp[72]]] = Math.min(OO[hp[8]][OO[hp[72]]], OO[hp[0]][OO[hp[38]]]), OO[hp[34]][OO[hp[72]]] = Math.max(OO[hp[34]][OO[hp[72]]], OO[hp[0]][OO[hp[38]]]));
            for (Fp(OO[hp[33]] = Number.MIN_SAFE_INTEGER, OO[hp[81]] = OO[hp[6]]), OO[hp[80]] = hp[0]; OO[hp[80]] < OO[hp[1]] - hp[1]; OO[hp[80]]++) OO[hp[8]][OO[hp[80]]] === Number.MAX_SAFE_INTEGER && OO[hp[34]][OO[hp[80]]] === Number.MIN_SAFE_INTEGER || Fp(OO[hp[33]] = Math.max(OO[hp[33]], OO[hp[8]][OO[hp[80]]] - OO[hp[81]]), OO[hp[81]] = OO[hp[34]][OO[hp[80]]]);
            return OO[hp[33]] = Math.max(OO[hp[33]], OO[hp[5]] - OO[hp[81]]), OO[hp[33]]
          }, console.log(OO[hp[78]]))
        }
        eO(hp[112]) + "D" in aX && FO(), vK = CO[OO]()
      }
      if (pO === eO(hp[111]) + eO(145)) {
        function VO(...OO) {
          for (Fp(OO[hp[4]] = hp[1], OO[hp[1]] = '[=KoAJQuPrXvO$!3q?jcBC#~pkD]e|l/%Ra0N"W)2n+16:>g9`s;.&@Z(EfbF*y<}8YUtG5MwmiHL4,xIhVz_T^{7Sd', OO[hp[5]] = "" + (OO[hp[0]] || ""), OO[hp[10]] = OO[hp[5]].length, OO[-hp[63]] = [], OO[hp[20]] = hp[0], OO[hp[12]] = hp[0], OO[hp[72]] = -hp[1]), OO[hp[38]] = hp[0]; OO[hp[38]] < OO[hp[10]]; OO[hp[38]]++)
            if (OO[hp[82]] = OO[hp[1]].indexOf(OO[hp[5]][OO[hp[38]]]), OO[hp[82]] !== -hp[1])
              if (OO[hp[72]] < hp[0]) OO[hp[72]] = OO[hp[82]];
              else {
                Fp(OO[hp[72]] += OO[hp[82]] * hp[23], OO[hp[20]] |= OO[hp[72]] << OO[hp[12]], OO[hp[12]] += (OO[hp[72]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                do {
                  Fp(OO[-hp[63]].push(OO[hp[20]] & hp[3]), OO[hp[20]] >>= hp[2], OO[hp[12]] -= hp[2])
                } while (OO[hp[12]] > hp[14]);
                OO[hp[72]] = -hp[1]
              } return OO[hp[72]] > -hp[1] && OO[-hp[63]].push((OO[hp[20]] | OO[hp[72]] << OO[hp[12]]) & hp[3]), Mp(OO[-hp[63]])
        }

        function LO(...OO) {
          return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = VO(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
        }

        function QO(...OO) {
          OO[hp[4]] = hp[0]
        }
        return eO(146) + "s" in aX && QO(), {
          [LO(147) + LO(148)]: vK
        }
      }
      return vK
    }

    function Fp() {
      Fp = function() {}
    }
    Fp(kp = {}, UK = ["dSYh([u", "iNY~;{q^U2/h,L)NZ1iwG;3#<^I4a9b9sCJVnsn+{kI&ko", "ipcV#{[+XJ*>]J?FzD;D|4GqqR[", 'S3WH4zgQPZ/#<O<N.N&g{*gULRW"M(P.*FG+!LSgL1fwGTY', ":32GvnZ9>D&BA~(N`,dDryE}o", "+S{h)*,k^e04A", "~3<DEbykt0N", "4EASh+sUK^", 'VO15TwqG#sH%644"1A', ':b`yCN5}+DW"mb#zZh]h{P>e%JFG="P#|>o', "+338c5%U)0ysOLTaiD_iX7(FgvKqE`J", 'DC@mvq)F&!3SU".r4>XUf]i^$2!8oo)HYb=D2BT)|sw4BOu3KwY#4l&P1Z', "%$+5y7nN`e4RrJ!Xju", 'Isc8C;mz+0l/vz&exC6y@q5NyelmZzqHPD/[c;<1;|AvCOo"ETVyH', "2!;Slzg}K0TH5qT#6BDHh@IAmP.V|OC};J_i3`aQQZr", '7bqSDi7QS0o_IJ*"dsIcarQ};|yyt_bV$Co', "v!vhjtYk|sq&E{xU=|2+rrg+pfS^Mm", "UF`yH@|$n0n1mbEF^eU8P~q^^28/;{9r3TdDP|++ADGoa9|r", 'RCwg|dQUrPKP4^m"">FI]/egjY>+y?nHCDZ]DPJ)x!TEktR3', '7D.5hw$Wk|lr"~/Hjsfih(2XxPHV?OD', ';va/Vw1e/BZvkt`HXv5/c~`^HZ+V$_LFWOtiiQfGo!;9S"j#73=V[7fA', "FskhV@!UxOeo7{,d?$=mfLpIS", 'd]]~b;x5:7mC6J*zpv{f%lm)Jxl/_|"V)p}!a"F}?Re](OAa6No', '3Fw!""_rc^B7_m}a3|}H28y^p7t;P9KH,1A@?t6K[!.8)tGk)u', "SP^i~i%$jBGC3`Yd", "jv*I`d{#8YC/I4MrO!6!W5FeOR+.EOWZ$DvSE[!W", "*P.G8[v#7Q.i#m", "#|/mT+rkA1=E9>KX[pm[[]v3)kfxA~93FCu!;s2#O1_Y0H%", "cmbDzI~U`23s3[W}YT8cPRHG:gzVc~%", '|>15I5>$40yZ$99XQb]%id|}LRWWQlnN|E8/p/5N.vqRV[kXD"If~Nu', ';phUGi|UpYC/m~GkmRIh@pB3E!Y"?`(H_J!m~[*rNRK/,`3#`bgSjPuUcQh', "KBG@G5z1Bv//~>{N4D!8/lGkTZ6$Z>WUs!JiH`14S", "vVAS;z,GsOuC]HOEEb+G", "=3X]r@]Kx!do^~rVq4{[OPHG)^5fMz^", "0wjh*(mz(ecE{WyH$Z/5F(tQlkgIP}teGb3SDitQBvT%N9N3LBA~]R+W", "N5Cc)+z+tQT^dt^", '3]|G8[UzLR;m+HtV=TgS`Qfr?2{5q|A3%":%[$BrnDkNktg', 'K>B#cqWenD2Nx^.awZti||Sz?1]R:ox"]][H`]QW', "539@C>`r(|,oVW/HE]9HjwaW", "n]m[0$4eW|3>}b<NCo*H7]1W", 'mRJ+{BoIOR>.Pz8t["Cfi/dGm', "Kv.#A>RIjsZ;^~>FQBW]Q4/#wZwhbJX9`b>!g;ykpYOItQ;Tvu", '|"}Drr?QAO', 'OTSV"Fxer|?HM>EN!bjh=', "!p*!~>[Qpst87}=FPF`+j!eQF^qy1BFk3P*!_]Ezs7!J3Jbk[u", "z]A]]R1$*xC(A?%TlSiwp/%Q?erN}HX96v_8m>Wz`R)/^z#3^b;.#", 'T"I#GN05{k[x6J)NQb<w[L3XyO@Yv>I9Kplio)qA', "mm[~3Bn}8vZ;(b6=Pu", 'mDJi$RXkuRf+Yt]Xt59]y]s1pJ{9f|W"dsdyp"pGD%W"ho', "my0]e@z1hO0r?H?T3DB/6+VrrPZUp~#ziu", "@.3.udrPR75=Nc", "#5m#6`E$i^hJLyB3WO3m|$]3!k9~tW", "2vpi#FCSWkTvLq0}(onTbf)Fwso;6JMN/B3+VwZG|fu~@TD", 'w7W/*+`P/fz;NW|U1RXHj{ue`7XJhoc,x"E//qGqe|sw"y1', 'dZ"%U_`k~^X8w}B.:s8ck@O9>DIATyGt[o<DiL&38JUJd4^ED"W', '43pi(+}}*D{f@l,tO"U+zr}0Bvxw8z%E6p8V?8^`xRTQ<o', "w>/5&i]G@Y6kTcXk", ".D*I$C]`ekvA*m", "Q!}]DqXIYB#l.`nH_.i+q+<}G", "cy*].K@SA1L4;`!N0Vw]5lq]S^zl2>T.Zb>D", 'b3Whvz"q7E)[lm', "O!]%/{``$O[}IJ8t#|CG", '%,m%An@NpxR2T"_Z@v=.;ldl01nO6JwT', 'TvI/u>>0_Yl.X~uU0>r~{psQG^w#Z?rz9C3Dl~eW"Q"8u', 'D$8[^i+Cux_7|OhZ(]>yj{ofxkJCn>%EtS>D:7~SCkqY;4""6BVy9@u', "%CR+b;Xq[!plB4+H{pdyuiu", "JS>!w;b#aYDQbTgk11]#:7&X_e.%I4wd^mW", '~>lTYt}}.J6hCo8kT$4.9`pAzDIY1O*U:1/5dR"rMs^H~brUu|7!*Cu', "~BxgN@IAVe3SYt@F;S;mU", 'TTD]7|R`+D,>P~wd/Z]~S)"kTvo~Uc2N=]^V:4fG>Om`ymG', "z,;.VbX`hxhVW9<a~J]#_dXkS", 'Wx7DSlMPsB{5[Jl"jNG8s$8S87~4A9/TN1r/a!]r?D=S=q>N|NuS', 'E$RyR;9`87z8,Hs}XP3.["<FDZqef>}N]F7yV@V#c!|/GH,tYRo', "6pRm%|rR<E)9)9+.ux}y}@IIIY{RCHXd1O?!pL*X!kCYbJu,Mu", 'vS$m9{R]Ueplg?4}G1IhM@`kv|*;">j#pP]hK*Zkc', "AP?*$/wG`OFZMm_37CL#Z", 'h|KT.rS4Hv_Yv}l9CS:#l|HG(ef81>V"2E"i$L=zr!oL>`*Vdvtw7$.1o', "!]MhLpQe:7VE$9.3{4%IE[.}9QeI_lAZ]T,/.{Yk^2DUVWo9u1Rw?", '6ptD;zok~EBGhoQz#NY#1zQ51J9]`4l"RsY#wqX^IBPmB4b9SrUG', 'XS]f^i?g@RGU3L?HTvFS.{gU:JOU&Qo9T3F!1{T0RR"', "tvr5QNSeDQcCO`H3(v@D)[vXAP6qfm9NwCWI,IC}YEW*YW", '%y6!;lv3BBE^j9R"}$}HUF5}C^ZNhB&evZimzI5}qPIe+oNZ)]<]68KG,g', "Uv!mNwv#[k<=0o)H9beHh!^9AD=ZY[Y9J||/8[C$FQ;qe_vV0]fm", "~S>Sb|j$1v#i:HttW28/>y~U~Z|", "Dyn/|;VGn!!Ve_H#bp&%Q]B#.vNsQyb9S|ODws_R*P:8mzYtTDvS", "ipThj!/A", 'W|5hs/k`hP<zScBZFv{T>]bR=0"oubGtyu', "v>syI5u", "X5<!i;zz8Bdw.{>F53MSifF}GQK=iJ.3vVY#&s}$?P:B(BqdIV<D", "Gh#VIlu", "7S5]Slyk(R#;dWW3OyR.:!{P7^6e6W@Fyp28pyu", "+FSV=bXq~EK5x^`FiB8#$_~+xP1?#?0}xo_5$4u", "*32V,LdkVO]wjlCVAxp.ZsMK<E4A!^T#soqS+IYfm", 'WR"Vy">U30tw&QoZJP{cJlsSLRtJ@l*zDm/b}BS4yRK|s^7.}]&/X(`A', '>!ZS"Fm)x|!8eq49f1:#R/J$;R~&4J%tJhq]&suzh2PJqmDebJ|/%PnFG', "sCY~g|]`o|7m1BFe!>BfT8v]o", "BNpVJ8P`r|w9EbaT:VcV3+`P`O1Iec5V~Y$V7nT)0|o;1O/H&!nc", ">VA!;s(FjZp}a^eHD#Z!VbdGxRB", "+on/j{KZTZkQQyfHvV7y0$/GN1f(P}3Fr|Q/jp_`_eI(3`:d", '{d^VrK;]u2+xjyC}]pqg5qy`)^7wA>Yt=!s.!"h5IY4xuHJ', "V1<D,_8S`gbyA", '?RZSqi]XIJ)&3b[N&aC/>4v]`1x/Z"WzMBOD', "Sybw1i:$A|4(&O`F]Shw(8;ALDC/+o~kmhb+WNqAJRi.G[l9ipCGc>KlW1", "YT0w@[OX>|ZS#m$k}C&hAfVX/f,GL9ZdJm_i&;#ruD2;uH2X@]o", 'N""G|N>Wc!,Jiti#5V#%', '7CEVB]O`wZEQ="B3x!o~FIu', "@BIfKP(SDQim8o=.(SeI#(vrQJSQ8H5tX3u*Nwu", '"PA]UbHrzk*l~o|X', "5>$+@>fXAP>J0o?TOOVDM@&l_B1EO[,9=|#GWz7W5Yk}:`PrpvlbH", '2|2.=8gQL1}i(O{X?":%z!FW', '6dm#3`/Pyx{91d0UgbLf[]bXyO>l>O+Xls6D!7dAsR]l$La9m|"VU', 'gP]hQ]}zL|:Gym)F9,hwHFe5_YL#:o}X2CK.<@8N$BYIBJR"(7Y%jtT)TET', "k!_+v>Yk1Zx/&4(Nf!aHqtiAuRgoX>nHaZ:5Itu", "IpCc%)^AuR:8E>[Nk1c[G)+Uz!4$N_?FLvy]dRJ$%i?st_^", "Tb5hUb,A", 'c,@`VbIG,Zs+"mddUP?D@@L)Ivk]ay1', "LF3+&!244mX", "Ol5y8j7o", "<&eLILxo", "OloL}XFo", "x]tV/qEW", "+PP!O[.W", ">P]hB/}W", 'R7Ng2W}=_xszv"L^ej,wMMTh|DX9&GL^|6+Q|eR3[F9.qoe7G7n`w', 'KJ>^XqcsgU4)elha$}n<EER[D7+*Zyha)(z!tt/I$X4,&"e;0~', 'Kpw|z)D}i6c%:+"00pL<[nzl]S$EPz_[WC9EI', '#%"l', "MUo|yhhP", "`D7<pl>n", '9"YIo4V', "+gd/Wt}a", "qhM<j%V", "1j2q{1{n", ";g[MCdqV", ">/KR|/gP", "kT<@G", 'Rw>4"M*E', "5wU|0FfP", "KKtAV", "v58&_DvP", "9kQ|n=Px", "+fGu}&Ox", "j}FlRIqx", "$*eAxh;X", "X]AI^=nP", "saJAp", "%w~fS}qX", '"E~@Vh+K', "qjz%]", "z!dm4qFW", "VfQ5!!%r", "{w!j$&hp", "yy2Fgi/tS%", "1QxfhMjr", "c.j`yxI", "&UQ^K|H8i", "?5N#Ll)o", "ELXQ", "O4RkFl@o", "^KFP}|E8", 'S1xq@p"8', "9VPCK~g", "dCk>=q$8", "Cw(AWHB8", "%jx&G|v8", "%j%PC", '"<eK=UL~C[:MvGTm}<ZIG|+', 'FuWo:!"L2;X#.w~_|UbJO"+pPMj@i3x', "tZcS5_+0abAVC7R*zZ|e78/", "0XZ[K|H8:3{$SgkPD45TCH,v@B7l2bV", "3c:6KzUVjxFk6&l`t~:26@+Vz3x", "_r/f>jY", "3D$ZxX)9", "pLjk", "&X%gF``r", "K/D`3GI", "7.6f@w=p", "QTc`Y;1p", "u6jqj", "85pqGOIi", "7IhEy", "#Mq*7c1|", "J`jWLL3|", "xcUx~ez*xF", "4qQGQ", "4qQG9KSk|6ev|", "w_,qY~D<EIse8B", 'bvV^HDC:d"{S&C', "w26qgaM]%vztuB", "HCJqU.]Hu#CgHm", "0CI4A}$Q/Zc[NB"]), Fp(Op = function(...OO) {
      Fp(OO[hp[4]] = hp[0], OO[hp[7]] = [function() {
        return globalThis
      }, function() {
        return global
      }, function() {
        return window
      }, function() {
        return new Function("return this")()
      }], OO[hp[1]] = hp[53], OO[hp[5]] = []);
      try {
        Fp(OO[hp[1]] = Object, OO[hp[5]][hp[16]]("".__proto__.constructor.name))
      } catch (UK) {}
      OO: for (OO[hp[6]] = hp[0]; OO[hp[6]] < OO[hp[7]][hp[4]]; OO[hp[6]]++) try {
        for (OO[hp[1]] = OO[hp[7]][OO[hp[6]]](), OO[hp[8]] = hp[0]; OO[hp[8]] < OO[hp[5]][hp[4]]; OO[hp[8]]++)
          if (typeof OO[hp[1]][OO[hp[5]][OO[hp[8]]]] === hp[9]) continue OO;
        return OO[hp[1]]
      } catch (UK) {}
      return OO[hp[1]] || this
    }() || {}, Kp = Op.TextDecoder, pp = Op.Uint8Array, Xp = Op[hp[119]], bX = Op.String || String, ep = Op.Array || Array, lp = function(...OO) {
      return Fp(OO[hp[4]] = hp[0], OO[hp[7]] = new ep(hp[52]), OO[hp[1]] = bX[hp[13]] || bX.fromCharCode, OO[hp[10]] = []),
        function(KO) {
          var pO, XO, bK, eO;
          for (Fp(XO = void 0, bK = KO[hp[4]], OO[hp[10]][hp[4]] = hp[0]), eO = hp[0]; eO < bK;) Fp(XO = KO[eO++], XO <= hp[45] ? pO = XO : XO <= 223 ? pO = (XO & hp[108]) << hp[12] | KO[eO++] & hp[11] : XO <= hp[85] ? pO = (XO & hp[109]) << hp[15] | (KO[eO++] & hp[11]) << hp[12] | KO[eO++] & hp[11] : bX[hp[13]] ? pO = (XO & hp[14]) << hp[110] | (KO[eO++] & hp[11]) << hp[15] | (KO[eO++] & hp[11]) << hp[12] | KO[eO++] & hp[11] : (pO = hp[11], eO += hp[6]), OO[hp[10]][hp[16]](OO[hp[7]][pO] || (OO[hp[7]][pO] = OO[hp[1]](pO))));
          return OO[hp[10]][hp[56]]("")
        }
    }()), Dp(114) + "T" in aX && (module.exports = async (OO = () => {
      throw new Error(Dp(hp[17]))
    }) => {
      function KO(...OO) {
        for (Fp(OO[hp[4]] = hp[1], OO[hp[21]] = 'tQO}WxL.n]6Dcuv2T(Cmg${NhEl#sk1M+rUe`F/y_&~S=aKb*:PjI4qXYR0"5Bo[Afp?>iH<wZzV%^Jd!3,)|@978;G', OO[hp[5]] = "" + (OO[hp[0]] || ""), OO[hp[20]] = OO[hp[5]].length, OO[hp[14]] = [], OO[-hp[24]] = hp[0], OO[hp[17]] = hp[0], OO[-hp[18]] = -hp[1]), OO[-hp[19]] = hp[0]; OO[-hp[19]] < OO[hp[20]]; OO[-hp[19]]++)
          if (OO[hp[22]] = OO[hp[21]].indexOf(OO[hp[5]][OO[-hp[19]]]), OO[hp[22]] !== -hp[1])
            if (OO[-hp[18]] < hp[0]) OO[-hp[18]] = OO[hp[22]];
            else {
              Fp(OO[-hp[18]] += OO[hp[22]] * hp[23], OO[-hp[24]] |= OO[-hp[18]] << OO[hp[17]], OO[hp[17]] += (OO[-hp[18]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
              do {
                Fp(OO[hp[14]].push(OO[-hp[24]] & hp[3]), OO[-hp[24]] >>= hp[2], OO[hp[17]] -= hp[2])
              } while (OO[hp[17]] > hp[14]);
              OO[-hp[18]] = -hp[1]
            } return OO[-hp[18]] > -hp[1] && OO[hp[14]].push((OO[-hp[24]] | OO[-hp[18]] << OO[hp[17]]) & hp[3]), Mp(OO[hp[14]])
      }

      function pO(...OO) {
        return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = KO(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
      }
      const XO = new Set(process.argv.slice(hp[5]));
      if (!XO.has(pO(hp[36]))) {
        if (XO.size !== hp[1]) return hp[28];
        if (!XO.has("-v")) return hp[28]
      }
      return await (async (KO, pO) => {
        function XO(...OO) {
          for (Fp(OO[hp[4]] = hp[1], OO[hp[32]] = 'pgo&ef2?M|y5FAr,3E$JxBlq_nkc.wb#K+U*T~791z=!Vv^%t8Hd:];>a6CZImGPiN`{jXuQ/s)[WLOh(4"<}D0S@YR', OO[hp[29]] = "" + (OO[hp[0]] || ""), OO[-hp[31]] = OO[hp[29]].length, OO[hp[8]] = [], OO[hp[34]] = hp[0], OO[-hp[35]] = hp[0], OO[hp[14]] = -hp[1]), OO[hp[30]] = hp[0]; OO[hp[30]] < OO[-hp[31]]; OO[hp[30]]++)
            if (OO[hp[33]] = OO[hp[32]].indexOf(OO[hp[29]][OO[hp[30]]]), OO[hp[33]] !== -hp[1])
              if (OO[hp[14]] < hp[0]) OO[hp[14]] = OO[hp[33]];
              else {
                Fp(OO[hp[14]] += OO[hp[33]] * hp[23], OO[hp[34]] |= OO[hp[14]] << OO[-hp[35]], OO[-hp[35]] += (OO[hp[14]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                do {
                  Fp(OO[hp[8]].push(OO[hp[34]] & hp[3]), OO[hp[34]] >>= hp[2], OO[-hp[35]] -= hp[2])
                } while (OO[-hp[35]] > hp[14]);
                OO[hp[14]] = -hp[1]
              } return OO[hp[14]] > -hp[1] && OO[hp[8]].push((OO[hp[34]] | OO[hp[14]] << OO[-hp[35]]) & hp[3]), Mp(OO[hp[8]])
        }

        function bK(...OO) {
          return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = XO(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
        }
        return pO === await OO() ? bK(119) + "l)" : ""
      })(), hp[54]
    }), Fp(vX = Object[Dp(120)](hp[44]), Cp = void 0), (() => {
      function OO(OO) {
        return typeof kp[OO] === hp[9] ? kp[OO] = function(...OO) {
          for (Fp(OO[hp[4]] = hp[1], OO[hp[85]] = 'IproDgZvdfS(lm_zkQbh%~E#6HaYFUt2@P/;,C[+T{>y^?BO"J:.jN5qLsAV81MRXnuecG0wi]WK}`|=x<$&3!7)49*', OO[-hp[63]] = "" + (OO[hp[0]] || ""), OO[hp[6]] = OO[-hp[63]].length, OO[hp[8]] = [], OO[-hp[86]] = hp[0], OO[hp[87]] = hp[0], OO[hp[14]] = -hp[1]), OO[hp[38]] = hp[0]; OO[hp[38]] < OO[hp[6]]; OO[hp[38]]++)
            if (OO[hp[22]] = OO[hp[85]].indexOf(OO[-hp[63]][OO[hp[38]]]), OO[hp[22]] !== -hp[1])
              if (OO[hp[14]] < hp[0]) OO[hp[14]] = OO[hp[22]];
              else {
                Fp(OO[hp[14]] += OO[hp[22]] * hp[23], OO[-hp[86]] |= OO[hp[14]] << OO[hp[87]], OO[hp[87]] += (OO[hp[14]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                do {
                  Fp(OO[hp[8]].push(OO[-hp[86]] & hp[3]), OO[-hp[86]] >>= hp[2], OO[hp[87]] -= hp[2])
                } while (OO[hp[87]] > hp[14]);
                OO[hp[14]] = -hp[1]
              } return OO[hp[14]] > -hp[1] && OO[hp[8]].push((OO[-hp[86]] | OO[hp[14]] << OO[hp[87]]) & hp[3]), Mp(OO[hp[8]])
        }(UK[OO]) : kp[OO]
      } [][hp[4]] = hp[0], OO(150) + hp[34] in aX && function() {
        const OO = require("big-integer");
        class KO {
          static randomPrime(KO) {
            const pO = OO.one.shiftLeft(KO - hp[1]),
              XO = OO.one.shiftLeft(KO).prev();
            for (; hp[54];) {
              let KO = OO.randBetween(pO, XO);
              if (KO.isProbablePrime(hp[88])) return KO
            }
          }
          static generate(...KO) {
            KO[hp[4]] = hp[1];
            const pO = OO(hp[89]);
            let XO, bK;
            KO[hp[1]] = hp[53];
            do {
              Fp(XO = this.randomPrime(KO[hp[0]] / hp[5]), bK = this.randomPrime(KO[hp[0]] / hp[5]), KO[hp[1]] = OO.lcm(XO.prev(), bK.prev()))
            } while (OO.gcd(pO, KO[hp[1]]).notEquals(hp[1]) || XO.minus(bK).abs().shiftRight(KO[hp[0]] / hp[5] - hp[40]).isZero());
            return {
              e: pO,
              n: XO.multiply(bK),
              d: pO.modInv(KO[hp[1]])
            }
          }
          static encrypt(...KO) {
            return KO[hp[4]] = hp[6], OO(KO[hp[0]]).modPow(KO[hp[5]], KO[hp[1]])
          }
          static decrypt(KO, pO, XO) {
            return OO(KO).modPow(pO, XO)
          }
          static encode(...KO) {
            KO[hp[4]] = hp[1];
            const pO = KO[hp[0]].split("").map((OO => OO.charCodeAt())).join("");
            return OO(pO)
          }
          static decode(...OO) {
            OO[hp[4]] = hp[1];
            const KO = OO[hp[0]].toString();
            OO[-hp[75]] = "";
            for (let pO = hp[0]; pO < KO.length; pO += hp[5]) {
              let XO = Number(KO.substr(pO, hp[5]));
              XO <= hp[69] ? (OO[-hp[75]] += String.fromCharCode(Number(KO.substr(pO, hp[6]))), pO++) : OO[-hp[75]] += String.fromCharCode(XO)
            }
            return OO[-hp[75]]
          }
        }
        module.exports = KO
      }(), Fp(WK = (...KO) => {
        KO[hp[4]] = hp[1];
        const pO = function(OO) {
            var KO;
            return {
              meta: {
                ...OO.meta,
                formatVersion: NK.g,
                variation: null !== (KO = OO.meta.variation) && void 0 !== KO ? KO : null
              },
              initialChunks: OO.initialChunks.map((OO => ({
                chunkPos: OO.chunkPos,
                rle: IK(OO.rle),
                sharedBlockData: EK("sharedBlockData", OO.sharedBlockData)
              }))),
              ticks: OO.ticks.map(xp),
              editState: OO.editState
            }
          }(KO[hp[0]]),
          XO = XK(NK[hp[72]]);
        KO[hp[7]] = hp[53];
        try {
          function vK(...OO) {
            Fp(OO[hp[4]] = hp[0], OO[hp[7]] = function(...OO) {
              if (Fp(OO[hp[4]] = hp[1], OO[hp[7]] = OO[hp[0]].length), OO[hp[7]] < hp[5]) return hp[0];
              if (Fp(OO[hp[59]] = Math.max(...OO[hp[0]]), OO[hp[90]] = Math.min(...OO[hp[0]])), OO[hp[59]] === OO[hp[90]]) return hp[0];
              for (Fp(OO[hp[51]] = Array(OO[hp[7]] - hp[1]).fill(Number.MAX_SAFE_INTEGER), OO[hp[34]] = Array(OO[hp[7]] - hp[1]).fill(Number.MIN_SAFE_INTEGER), OO[hp[91]] = Math.ceil((OO[hp[59]] - OO[hp[90]]) / (OO[hp[7]] - hp[1])), OO[hp[14]] = hp[0]), OO[hp[38]] = hp[0]; OO[hp[38]] < OO[hp[7]]; OO[hp[38]]++) OO[hp[0]][OO[hp[38]]] !== OO[hp[90]] && OO[hp[0]][OO[hp[38]]] !== OO[hp[59]] && Fp(OO[hp[14]] = Math.floor((OO[hp[0]][OO[hp[38]]] - OO[hp[90]]) / OO[hp[91]]), OO[hp[51]][OO[hp[14]]] = Math.min(OO[hp[51]][OO[hp[14]]], OO[hp[0]][OO[hp[38]]]), OO[hp[34]][OO[hp[14]]] = Math.max(OO[hp[34]][OO[hp[14]]], OO[hp[0]][OO[hp[38]]]));
              for (Fp(OO[hp[22]] = Number.MIN_SAFE_INTEGER, OO[-hp[92]] = OO[hp[90]]), OO[hp[80]] = hp[0]; OO[hp[80]] < OO[hp[7]] - hp[1]; OO[hp[80]]++) OO[hp[51]][OO[hp[80]]] === Number.MAX_SAFE_INTEGER && OO[hp[34]][OO[hp[80]]] === Number.MIN_SAFE_INTEGER || Fp(OO[hp[22]] = Math.max(OO[hp[22]], OO[hp[51]][OO[hp[80]]] - OO[-hp[92]]), OO[-hp[92]] = OO[hp[34]][OO[hp[80]]]);
              return OO[hp[22]] = Math.max(OO[hp[22]], OO[hp[59]] - OO[-hp[92]]), OO[hp[22]]
            }, console.log(OO[hp[7]]))
          }
          OO(151) in aX && vK(), KO[hp[7]] = XO[OO(152)](pO)
        } catch (ep) {
          function hO(OO) {
            var KO, pO, XO, bK, eO, lO, vK;
            for (Fp(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = hp[0], eO = hp[0], lO = -hp[1]), vK = hp[0]; vK < pO; vK++) {
              var CO = '6orAOBikTQpnVajCW0/,K9ut8IDh_y^s[=2]zPE!X.FLqxG1%g35N)U&`md{4bR@:7$M?eY(<*Hf|#S}lvJZ"w+~;>c'.indexOf(KO[vK]);
              if (CO !== -hp[1])
                if (lO < hp[0]) lO = CO;
                else {
                  Fp(lO += CO * hp[23], bK |= lO << eO, eO += (lO & hp[25]) > hp[18] ? hp[26] : hp[27]);
                  do {
                    Fp(XO.push(bK & hp[3]), bK >>= hp[2], eO -= hp[2])
                  } while (eO > hp[14]);
                  lO = -hp[1]
                }
            }
            return lO > -hp[1] && XO.push((bK | lO << eO) & hp[3]), Mp(XO)
          }

          function DO(...OO) {
            return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = hO(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
          }

          function MO(...OO) {
            Fp(OO[hp[4]] = hp[0], OO[hp[7]] = function(KO) {
              var pO = [];
              return (KO === hp[1] || KO >= hp[8]) && OO[hp[59]](pO, [], KO, hp[0]), pO
            }, OO[hp[59]] = function(...KO) {
              for (KO[hp[4]] = hp[8], KO[-hp[93]] = KO[hp[6]]; KO[-hp[93]] < KO[hp[5]]; KO[-hp[93]]++) {
                if (KO[hp[1]].length !== KO[-hp[93]]) return;
                for (KO[hp[20]] = hp[0]; KO[hp[20]] < KO[hp[5]]; KO[hp[20]]++) OO[hp[10]](KO[hp[1]], [KO[-hp[93]], KO[hp[20]]]) && (Fp(KO[hp[1]].push([KO[-hp[93]], KO[hp[20]]]), OO[hp[59]](KO[hp[0]], KO[hp[1]], KO[hp[5]], KO[-hp[93]] + hp[1])), KO[hp[1]].length === KO[hp[5]] && KO[hp[0]].push(OO[hp[94]](KO[hp[1]])), KO[hp[1]].pop())
              }
            }, OO[hp[94]] = function(...OO) {
              for (Fp(OO[hp[4]] = hp[1], OO[hp[7]] = [], OO[hp[5]] = OO[hp[0]].length), OO[hp[6]] = hp[0]; OO[hp[6]] < OO[hp[5]]; OO[hp[6]]++)
                for (OO[hp[7]][OO[hp[6]]] = "", OO[hp[8]] = hp[0]; OO[hp[8]] < OO[hp[5]]; OO[hp[8]]++) OO[hp[7]][OO[hp[6]]] += OO[hp[0]][OO[hp[6]]][hp[1]] === OO[hp[8]] ? hp[95] : hp[60];
              return OO[hp[7]]
            }, OO[hp[10]] = function(...OO) {
              for (Fp(OO[hp[4]] = hp[5], OO[hp[96]] = OO[hp[0]].length), OO[hp[59]] = hp[0]; OO[hp[59]] < OO[hp[96]]; OO[hp[59]]++) {
                if (OO[hp[0]][OO[hp[59]]][hp[0]] === OO[hp[1]][hp[0]] || OO[hp[0]][OO[hp[59]]][hp[1]] === OO[hp[1]][hp[1]]) return hp[28];
                if (Math.abs((OO[hp[0]][OO[hp[59]]][hp[0]] - OO[hp[1]][hp[0]]) / (OO[hp[0]][OO[hp[59]]][hp[1]] - OO[hp[1]][hp[1]])) === hp[1]) return hp[28]
              }
              return hp[54]
            }, console.log(OO[hp[7]]))
          }
          throw OO(153) in aX && MO(), Fp(console[OO(154)](pO), XO[DO(hp[50])](pO, {
            [DO(156) + DO(hp[117])]: (...OO) => (DO(158) in aX && function() {
              function OO(...OO) {
                for (Fp(OO[hp[4]] = hp[1], OO[hp[7]] = '%x9@.*S!kz"6:Q|L8l[FH#G_>pOm)M$Zoht&nwEYDC~KcJ,v{R</buU?eB(TP3sg1}=^A+]rXN7jy2adq45i`fWI0V;', OO[hp[59]] = "" + (OO[hp[0]] || ""), OO[hp[10]] = OO[hp[59]].length, OO[hp[51]] = [], OO[hp[34]] = hp[0], OO[hp[91]] = hp[0], OO[hp[81]] = -hp[1]), OO[-hp[97]] = hp[0]; OO[-hp[97]] < OO[hp[10]]; OO[-hp[97]]++)
                  if (OO[hp[33]] = OO[hp[7]].indexOf(OO[hp[59]][OO[-hp[97]]]), OO[hp[33]] !== -hp[1])
                    if (OO[hp[81]] < hp[0]) OO[hp[81]] = OO[hp[33]];
                    else {
                      Fp(OO[hp[81]] += OO[hp[33]] * hp[23], OO[hp[34]] |= OO[hp[81]] << OO[hp[91]], OO[hp[91]] += (OO[hp[81]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                      do {
                        Fp(OO[hp[51]].push(OO[hp[34]] & hp[3]), OO[hp[34]] >>= hp[2], OO[hp[91]] -= hp[2])
                      } while (OO[hp[91]] > hp[14]);
                      OO[hp[81]] = -hp[1]
                    } return OO[hp[81]] > -hp[1] && OO[hp[51]].push((OO[hp[34]] | OO[hp[81]] << OO[hp[91]]) & hp[3]), Mp(OO[hp[51]])
              }

              function KO(KO) {
                return typeof kp[KO] === hp[9] ? kp[KO] = OO(UK[KO]) : kp[KO]
              }! function(...OO) {
                function KO(OO) {
                  var KO, pO, XO, bK, eO, lO, vK, CO = 'YKZeH6:RU!SOCFBs0#|`1y/MlqnmPkVgJjaAEctrDLdWIQGXpfTbo$=+(4]<N3i{}9.2@v?^)8x[7&"*>5;w~,_u%zh';
                  for (Fp(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = hp[0], eO = hp[0], lO = -hp[1]), vK = hp[0]; vK < pO; vK++) {
                    var hO = CO.indexOf(KO[vK]);
                    if (hO !== -hp[1])
                      if (lO < hp[0]) lO = hO;
                      else {
                        Fp(lO += hO * hp[23], bK |= lO << eO, eO += (lO & hp[25]) > hp[18] ? hp[26] : hp[27]);
                        do {
                          Fp(XO.push(bK & hp[3]), bK >>= hp[2], eO -= hp[2])
                        } while (eO > hp[14]);
                        lO = -hp[1]
                      }
                  }
                  return lO > -hp[1] && XO.push((bK | lO << eO) & hp[3]), Mp(XO)
                }

                function pO(...OO) {
                  return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = KO(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
                }

                function XO(...OO) {
                  for (Fp(OO[hp[4]] = hp[1], OO[hp[7]] = [], OO[hp[5]] = hp[0], OO[hp[10]] = OO[hp[0]].length, OO[hp[51]] = hp[53], OO[hp[34]] = hp[53]); OO[hp[5]] < OO[hp[10]];) Fp(OO[hp[51]] = OO[hp[0]].charCodeAt(OO[hp[5]]++), OO[hp[51]] >= hp[102] && OO[hp[51]] <= 56319 && OO[hp[5]] < OO[hp[10]] ? (OO[hp[34]] = OO[hp[0]].charCodeAt(OO[hp[5]]++), (64512 & OO[hp[34]]) == hp[103] ? OO[hp[7]].push(((OO[hp[51]] & hp[98]) << hp[101]) + (OO[hp[34]] & hp[98]) + hp[99]) : (OO[hp[7]].push(OO[hp[51]]), OO[hp[5]]--)) : OO[hp[7]].push(OO[hp[51]]));
                  return OO[hp[7]]
                }

                function bK(...KO) {
                  for (Fp(KO[hp[4]] = hp[1], KO[hp[1]] = KO[hp[0]].length, KO[hp[59]] = -hp[1], KO[hp[10]] = hp[53], KO[hp[51]] = ""); ++KO[hp[59]] < KO[hp[1]];) KO[hp[10]] = KO[hp[0]][KO[hp[59]]], KO[hp[10]] > 65535 && Fp(KO[hp[10]] -= hp[99], KO[hp[51]] += OO[hp[100]](KO[hp[10]] >>> hp[101] & hp[98] | hp[102]), KO[hp[10]] = hp[103] | KO[hp[10]] & hp[98]), KO[hp[51]] += OO[hp[100]](KO[hp[10]]);
                  return KO[hp[51]]
                }

                function eO(OO) {
                  if (OO >= hp[102] && OO <= 57343) {
                    function KO(...OO) {
                      for (Fp(OO[hp[4]] = hp[1], OO[hp[7]] = 'gw8^*u7MA`>T"ktVB4JFN!|X{C,D?2~9Pzj<o:Za$=mKflbUE(_1x&v/cy3YOd+#n;h@R[r}p6G%0qQsH)I]Se.iWL5', OO[-hp[64]] = "" + (OO[hp[0]] || ""), OO[hp[10]] = OO[-hp[64]].length, OO[-hp[107]] = [], OO[-hp[106]] = hp[0], OO[hp[12]] = hp[0], OO[-hp[105]] = -hp[1]), OO[hp[38]] = hp[0]; OO[hp[38]] < OO[hp[10]]; OO[hp[38]]++)
                        if (OO[hp[104]] = OO[hp[7]].indexOf(OO[-hp[64]][OO[hp[38]]]), OO[hp[104]] !== -hp[1])
                          if (OO[-hp[105]] < hp[0]) OO[-hp[105]] = OO[hp[104]];
                          else {
                            Fp(OO[-hp[105]] += OO[hp[104]] * hp[23], OO[-hp[106]] |= OO[-hp[105]] << OO[hp[12]], OO[hp[12]] += (OO[-hp[105]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                            do {
                              Fp(OO[-hp[107]].push(OO[-hp[106]] & hp[3]), OO[-hp[106]] >>= hp[2], OO[hp[12]] -= hp[2])
                            } while (OO[hp[12]] > hp[14]);
                            OO[-hp[105]] = -hp[1]
                          } return OO[-hp[105]] > -hp[1] && OO[-hp[107]].push((OO[-hp[106]] | OO[-hp[105]] << OO[hp[12]]) & hp[3]), Mp(OO[-hp[107]])
                    }

                    function pO(...OO) {
                      return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = KO(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
                    }
                    throw Error(pO(hp[90]) + pO(160) + pO(161) + OO.toString(16).toUpperCase() + (pO(hp[81]) + pO(163) + pO(164) + pO(hp[97])))
                  }
                }

                function lO(...KO) {
                  return KO[hp[4]] = hp[5], OO[hp[100]](KO[hp[0]] >> KO[hp[1]] & hp[11] | hp[52])
                }

                function vK(...KO) {
                  return KO[hp[4]] = hp[1], (4294967168 & KO[hp[0]]) == hp[0] ? OO[hp[100]](KO[hp[0]]) : (KO[hp[7]] = "", (4294965248 & KO[hp[0]]) == hp[0] ? KO[hp[7]] = OO[hp[100]](KO[hp[0]] >> hp[12] & hp[108] | hp[114]) : (4294901760 & KO[hp[0]]) == hp[0] ? Fp(eO(KO[hp[0]]), KO[hp[7]] = OO[hp[100]](KO[hp[0]] >> hp[15] & hp[109] | hp[115]), KO[hp[7]] += lO(KO[hp[0]], hp[12])) : (4292870144 & KO[hp[0]]) == hp[0] && Fp(KO[hp[7]] = OO[hp[100]](KO[hp[0]] >> hp[110] & hp[14] | hp[46]), KO[hp[7]] += lO(KO[hp[0]], hp[15]), KO[hp[7]] += lO(KO[hp[0]], hp[12])), KO[hp[7]] += OO[hp[100]](KO[hp[0]] & hp[11] | hp[52]), KO[hp[7]])
                }

                function CO(OO) {
                  var KO, pO, bK, eO, lO = XO(OO);
                  for (Fp(KO = lO.length, pO = -hp[1], bK = void 0, eO = ""); ++pO < KO;) Fp(bK = lO[pO], eO += vK(bK));
                  return eO
                }

                function hO(...KO) {
                  function pO(...OO) {
                    for (Fp(OO[hp[4]] = hp[1], OO[-hp[74]] = 'N8)e9M5~J=gQxV0OaF%+:tR1LS|m^d/zoYiAK_T}uIG6Ch[&vw;bc?fD{ZHXU3yP2j#>4E`,rB"n!k.s@p$Wl]<(*7q', OO[hp[5]] = "" + (OO[hp[0]] || ""), OO[hp[6]] = OO[hp[5]].length, OO[hp[113]] = [], OO[hp[111]] = hp[0], OO[-hp[112]] = hp[0], OO[hp[72]] = -hp[1]), OO[hp[38]] = hp[0]; OO[hp[38]] < OO[hp[6]]; OO[hp[38]]++)
                      if (OO[hp[107]] = OO[-hp[74]].indexOf(OO[hp[5]][OO[hp[38]]]), OO[hp[107]] !== -hp[1])
                        if (OO[hp[72]] < hp[0]) OO[hp[72]] = OO[hp[107]];
                        else {
                          Fp(OO[hp[72]] += OO[hp[107]] * hp[23], OO[hp[111]] |= OO[hp[72]] << OO[-hp[112]], OO[-hp[112]] += (OO[hp[72]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                          do {
                            Fp(OO[hp[113]].push(OO[hp[111]] & hp[3]), OO[hp[111]] >>= hp[2], OO[-hp[112]] -= hp[2])
                          } while (OO[-hp[112]] > hp[14]);
                          OO[hp[72]] = -hp[1]
                        } return OO[hp[72]] > -hp[1] && OO[hp[113]].push((OO[hp[111]] | OO[hp[72]] << OO[-hp[112]]) & hp[3]), Mp(OO[hp[113]])
                  }

                  function XO(...OO) {
                    return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = pO(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
                  }
                  if (KO[hp[4]] = hp[0], OO[hp[59]] >= OO[hp[6]]) {
                    function bK(OO) {
                      var KO, pO, XO, bK, eO, lO, vK, CO = '+%r3*[>b;DQmaxh@/"AS=!dk~N.yY0ZIKwvTt2cu<,R57Xfj{})V1J&lq`6$FG4Cz:9]^Oso?WLpUiEBM8_e|(P#ngH';
                      for (Fp(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = hp[0], eO = hp[0], lO = -hp[1]), vK = hp[0]; vK < pO; vK++) {
                        var hO = CO.indexOf(KO[vK]);
                        if (hO !== -hp[1])
                          if (lO < hp[0]) lO = hO;
                          else {
                            Fp(lO += hO * hp[23], bK |= lO << eO, eO += (lO & hp[25]) > hp[18] ? hp[26] : hp[27]);
                            do {
                              Fp(XO.push(bK & hp[3]), bK >>= hp[2], eO -= hp[2])
                            } while (eO > hp[14]);
                            lO = -hp[1]
                          }
                      }
                      return lO > -hp[1] && XO.push((bK | lO << eO) & hp[3]), Mp(XO)
                    }

                    function eO(...OO) {
                      return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = bK(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
                    }
                    throw Error(eO(166))
                  }
                  if (Fp(KO[-hp[50]] = OO[hp[8]][OO[hp[59]]] & hp[3], OO[hp[59]]++), (KO[-hp[50]] & hp[114]) == hp[52]) return KO[-hp[50]] & hp[11];
                  throw Error(XO(167))
                }

                function MO() {
                  var KO, pO, XO, bK, lO;

                  function vK(OO) {
                    var KO, pO, XO, bK, eO, lO, vK, CO = '!u^B.;$02vp~G=}Sf3>`KrN9VbR%kaLh6y)(w1oicOTsE{<,5Wx4g/Ft7MD&#q+Yj_"*l|]@?JUmze[XPA8:HdnZQCI';
                    for (Fp(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = hp[0], eO = hp[0], lO = -hp[1]), vK = hp[0]; vK < pO; vK++) {
                      var hO = CO.indexOf(KO[vK]);
                      if (hO !== -hp[1])
                        if (lO < hp[0]) lO = hO;
                        else {
                          Fp(lO += hO * hp[23], bK |= lO << eO, eO += (lO & hp[25]) > hp[18] ? hp[26] : hp[27]);
                          do {
                            Fp(XO.push(bK & hp[3]), bK >>= hp[2], eO -= hp[2])
                          } while (eO > hp[14]);
                          lO = -hp[1]
                        }
                    }
                    return lO > -hp[1] && XO.push((bK | lO << eO) & hp[3]), Mp(XO)
                  }

                  function CO(...OO) {
                    return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = vK(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
                  }
                  if (Fp(KO = void 0, pO = void 0, XO = void 0, bK = void 0, lO = void 0), OO[hp[59]] > OO[hp[6]]) {
                    function MO(...OO) {
                      for (Fp(OO[hp[4]] = hp[1], OO[hp[1]] = '/NKr3b~m^wh*i)kYntML5&u90:{j,.|eSpCR"QH<ZoT>gB(`!zq#;fdJGE=$67Ua?Av@PD4XFI+[_W2OV]lc81x%y}s', OO[hp[59]] = "" + (OO[hp[0]] || ""), OO[hp[6]] = OO[hp[59]].length, OO[hp[8]] = [], OO[hp[34]] = hp[0], OO[-hp[37]] = hp[0], OO[hp[14]] = -hp[1]), OO[hp[38]] = hp[0]; OO[hp[38]] < OO[hp[6]]; OO[hp[38]]++)
                        if (OO[hp[65]] = OO[hp[1]].indexOf(OO[hp[59]][OO[hp[38]]]), OO[hp[65]] !== -hp[1])
                          if (OO[hp[14]] < hp[0]) OO[hp[14]] = OO[hp[65]];
                          else {
                            Fp(OO[hp[14]] += OO[hp[65]] * hp[23], OO[hp[34]] |= OO[hp[14]] << OO[-hp[37]], OO[-hp[37]] += (OO[hp[14]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                            do {
                              Fp(OO[hp[8]].push(OO[hp[34]] & hp[3]), OO[hp[34]] >>= hp[2], OO[-hp[37]] -= hp[2])
                            } while (OO[-hp[37]] > hp[14]);
                            OO[hp[14]] = -hp[1]
                          } return OO[hp[14]] > -hp[1] && OO[hp[8]].push((OO[hp[34]] | OO[hp[14]] << OO[-hp[37]]) & hp[3]), Mp(OO[hp[8]])
                    }

                    function aK(...OO) {
                      return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = MO(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
                    }
                    throw Error(aK(168))
                  }
                  if (OO[hp[59]] == OO[hp[6]]) return hp[28];
                  if (Fp(KO = OO[hp[8]][OO[hp[59]]] & hp[3], OO[hp[59]]++), (KO & hp[52]) == hp[0]) return KO;
                  if ((KO & hp[115]) == hp[114]) {
                    if (Fp(pO = hO(), lO = (KO & hp[108]) << hp[12] | pO), lO >= hp[52]) return lO;
                    throw Error(DO(hp[116]))
                  }
                  if ((KO & hp[46]) == hp[115]) {
                    if (Fp(pO = hO(), XO = hO(), lO = (KO & hp[109]) << hp[15] | pO << hp[12] | XO), lO >= 2048) return eO(lO), lO;
                    throw Error(DO(hp[116]))
                  }
                  if ((248 & KO) == hp[46] && (Fp(pO = hO(), XO = hO(), bK = hO(), lO = (KO & hp[14]) << hp[110] | pO << hp[15] | XO << hp[12] | bK), lO >= hp[99] && lO <= 1114111)) return lO;
                  throw Error(CO(170))
                }

                function aK(...KO) {
                  for (Fp(KO[hp[4]] = hp[1], OO[hp[8]] = XO(KO[hp[0]]), OO[hp[6]] = OO[hp[8]].length, OO[hp[59]] = hp[0], KO[hp[1]] = [], KO[hp[117]] = hp[53]);
                    (KO[hp[117]] = MO()) !== hp[28];) KO[hp[1]].push(KO[hp[117]]);
                  return bK(KO[hp[1]])
                }
                OO[hp[4]] = hp[1], OO[hp[100]] = String.fromCharCode, Fp(OO[hp[8]] = hp[53], OO[hp[6]] = hp[53], OO[hp[59]] = hp[53]), Fp(OO[hp[0]].version = pO(171), OO[hp[0]].encode = CO, OO[hp[0]].decode = aK)
              }(typeof exports === KO(hp[61]) + KO(173) ? this.utf8 = {} : exports)
            }(), Cp = [OO, {}], op(DO(hp[118])))
          })), ep
        }
        const bK = lK(NK[hp[72]], KO[hp[7]]),
          lO = eO[hp[119]][OO(175)](hp[8]);
        return lO[OO(176) + OO(177) + "E"](NK[hp[72]]), eO[hp[119]].concat([lO, bK])
      }, tp = (...OO) => {
        function KO(...OO) {
          return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = function(...OO) {
            for (Fp(OO[hp[4]] = hp[1], OO[hp[1]] = ';CifBmRoYnEQ+!x>LZ"#Ih.=0:yjzwH4q(T`P8&V_N{219cgdKv6eO@SlA],U%sr|tGpau[53)M/^}D~FJ7W?X<$*kb', OO[hp[120]] = "" + (OO[hp[0]] || ""), OO[hp[6]] = OO[hp[120]].length, OO[hp[51]] = [], OO[hp[34]] = hp[0], OO[hp[12]] = hp[0], OO[hp[110]] = -hp[1]), OO[hp[38]] = hp[0]; OO[hp[38]] < OO[hp[6]]; OO[hp[38]]++)
              if (OO[hp[22]] = OO[hp[1]].indexOf(OO[hp[120]][OO[hp[38]]]), OO[hp[22]] !== -hp[1])
                if (OO[hp[110]] < hp[0]) OO[hp[110]] = OO[hp[22]];
                else {
                  Fp(OO[hp[110]] += OO[hp[22]] * hp[23], OO[hp[34]] |= OO[hp[110]] << OO[hp[12]], OO[hp[12]] += (OO[hp[110]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                  do {
                    Fp(OO[hp[51]].push(OO[hp[34]] & hp[3]), OO[hp[34]] >>= hp[2], OO[hp[12]] -= hp[2])
                  } while (OO[hp[12]] > hp[14]);
                  OO[hp[110]] = -hp[1]
                } return OO[hp[110]] > -hp[1] && OO[hp[51]].push((OO[hp[34]] | OO[hp[110]] << OO[hp[12]]) & hp[3]), Mp(OO[hp[51]])
          }(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
        }
        OO[hp[4]] = hp[1];
        const pO = eO[hp[119]][KO(178)](OO[hp[0]]);
        if (pO[KO(hp[58]) + KO(hp[93])] >= hp[8]) {
          function XO(...OO) {
            for (Fp(OO[hp[4]] = hp[1], OO[hp[7]] = 'f|2H:7>b*D%TzCUMg=dPOFylmI!Qr#SxG]_+k.&?~,EJX(K3jWYq5L$1i`o@cwZ609/Bn4vh)"N^aA8pe<RVs[;{u}t', OO[hp[5]] = "" + (OO[hp[0]] || ""), OO[hp[121]] = OO[hp[5]].length, OO[hp[51]] = [], OO[hp[123]] = hp[0], OO[hp[12]] = hp[0], OO[hp[72]] = -hp[1]), OO[-hp[122]] = hp[0]; OO[-hp[122]] < OO[hp[121]]; OO[-hp[122]]++)
              if (OO[hp[33]] = OO[hp[7]].indexOf(OO[hp[5]][OO[-hp[122]]]), OO[hp[33]] !== -hp[1])
                if (OO[hp[72]] < hp[0]) OO[hp[72]] = OO[hp[33]];
                else {
                  Fp(OO[hp[72]] += OO[hp[33]] * hp[23], OO[hp[123]] |= OO[hp[72]] << OO[hp[12]], OO[hp[12]] += (OO[hp[72]] & hp[25]) > hp[18] ? hp[26] : hp[27]);
                  do {
                    Fp(OO[hp[51]].push(OO[hp[123]] & hp[3]), OO[hp[123]] >>= hp[2], OO[hp[12]] -= hp[2])
                  } while (OO[hp[12]] > hp[14]);
                  OO[hp[72]] = -hp[1]
                } return OO[hp[72]] > -hp[1] && OO[hp[51]].push((OO[hp[123]] | OO[hp[72]] << OO[hp[12]]) & hp[3]), Mp(OO[hp[51]])
          }

          function lO(...OO) {
            return OO[hp[4]] = hp[1], typeof kp[OO[hp[0]]] === hp[9] ? kp[OO[hp[0]]] = XO(UK[OO[hp[0]]]) : kp[OO[hp[0]]]
          }
          const vK = pO[lO(hp[96]) + lO(182)](hp[0]);
          if ((hp[0], NK.o)(vK)) {
            const CO = pO[lO(183)](hp[8]),
              hO = eK(vK) ? eO[hp[119]][lO(184)](vp(vK, CO)) : CO;
            return function(OO) {
              var KO, pO, XO, eO, lO;
              const vK = null === (KO = OO.meta) || void 0 === KO ? void 0 : KO.formatVersion;
              if (!(0, NK.o)(vK)) throw new Error(`Unsupported recording format version: ${vK}`);
              if (!Array.isArray(OO.initialChunks) || !Array.isArray(OO.ticks)) throw new Error("Recording is missing initialChunks or ticks");
              for (const bK of OO.ticks)
                if (!Array.isArray(bK.structuralEvents) || !Array.isArray(bK.ephemeralEvents)) throw new Error("Recording tick is missing structuralEvents or ephemeralEvents");
              const CO = {
                ...OO.meta
              };
              return CO.formatVersion = NK.g, (0, bK.I)(CO.variation) && delete CO.variation, {
                meta: CO,
                initialChunks: OO.initialChunks.map((OO => {
                  var KO;
                  return {
                    chunkPos: OO.chunkPos,
                    rle: yp(OO.rle),
                    sharedBlockData: null !== (KO = jp("sharedBlockData", OO.sharedBlockData)) && void 0 !== KO ? KO : []
                  }
                })),
                ticks: OO.ticks.map(nK),
                editState: {
                  cameraKeyframes: null !== (pO = null === (XO = OO.editState) || void 0 === XO ? void 0 : XO.cameraKeyframes) && void 0 !== pO ? pO : [],
                  playbackMark: null !== (eO = null === (lO = OO.editState) || void 0 === lO ? void 0 : lO.playbackMark) && void 0 !== eO ? eO : null
                }
              }
            }(XK(vK)[lO(185)](hO))
          }
        }
        throw new Error(KO(186) + KO(187) + KO(188) + KO(189) + KO(190) + "ad")
      })
    })()
  },
  35451: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => vK,
      d: () => lO,
      g: () => XO,
      j: () => MO,
      k: () => aK,
      o: () => eO,
      p: () => hO,
      t: () => oO,
      v: () => CO,
      y: () => DO
    });
    const XO = 9,
      bK = [9];

    function eO(OO) {
      return bK.includes(OO)
    }
    const lO = 100,
      vK = ["RightInfoText", "middleTextTop", "middleTextUpper", "middleTextLower", "crosshairText", "headerChips"],
      CO = ["skyBox", "fogColourOverride", "fogChunkDistanceOverride", "cameraTint", "fogOnSkybox", "fogBlockDistanceOverride"],
      hO = ["itemName", "amount", "position", "size", "attributes"],
      DO = ["opacity", "zIndex", "overlayColour", "canSee", "meshScaling", "nameTagInfo", "multilineTextBox", "hasPriorityNametag", "ranks", "nameColour", "_isAlive", "_invisibleEffect", "_invincible", "killfeedColour", "hideNameSeed", "_glowingEffect", "lockHeadToBody"],
      MO = ["type", "name", "position", "rotation", "scale", "speed", "jumping", "crouching", "cameraPitch", "armSwinging", "heldItemName", "heldItemEnchantmentTier", "pose", "followingEId", "followingOffset", "shouldMatchFollowingEntityRotation", "meshOffset", "baseRenderHeading", "armour", "vXO", "playerCustomisations", "variation", "metaInfo", "soundName", "volume", "refDistance", "maxHearDist", "rate", "ridingVehicleEId", "leaderboardTop", "meshKind", "meshOpts", "aiState"],
      aK = ["selectedSlotIndex", "slots"],
      oO = ["_health", "_totalMaxHealth", "_shield", "maxShield", "_aura", "auraPerLevel", "maxAuraLevel"]
  },
  35446: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => MO,
      e: () => FO,
      h: () => CO,
      i: () => lO,
      l: () => vK,
      m: () => hO
    });
    var XO = pO(256),
      bK = pO(26);

    function eO(OO) {
      return null === OO || void 0 === OO ? null : "string" === typeof OO ? OO : null
    }

    function lO(OO, KO) {
      return JSON.stringify(OO) === JSON.stringify(KO)
    }

    function vK(OO) {
      const KO = [];
      for (const pO of Object.keys(OO)) {
        const XO = OO[pO];
        for (const OO of Object.keys(XO)) KO.push({
          Qm: pO,
          name: OO,
          ...XO[OO]
        })
      }
      return KO
    }

    function CO(OO) {
      const KO = {};
      for (const eO of OO) {
        var pO, XO, bK;
        KO[eO.Qm] || (KO[eO.Qm] = {}), KO[eO.Qm][eO.name] = {
          icon: eO.icon,
          level: eO.level,
          displayName: null !== (pO = eO.displayName) && void 0 !== pO ? pO : null,
          endTick: null !== (XO = eO.endTick) && void 0 !== XO ? XO : null,
          showInNametag: null === (bK = eO.showInNametag) || void 0 === bK || bK
        }
      }
      return KO
    }

    function hO(OO, KO) {
      const pO = {};
      for (const bK of Object.keys(OO)) {
        const eO = {};
        for (const pO of Object.keys(OO[bK])) {
          const XO = OO[bK][pO];
          null !== XO.endTick && XO.endTick < KO || (eO[pO] = {
            ...XO,
            endTick: null === XO.endTick ? null : XO.endTick - KO
          })
        }(0, XO.tc)(eO) || (pO[bK] = eO)
      }
      return pO
    }

    function DO(OO, KO, pO) {
      if (null !== OO) return Math.max(0, 1e3 * (OO - KO) / pO)
    }
    class MO {
      constructor() {
        this.tracked = {}
      }
      clear() {
        this.tracked = {}
      }
      seedFromClient(OO, KO) {
        this.clear();
        const pO = Date.now();
        for (const vK of OO.iterateEntityIds()) {
          const CO = OO.getEffects(vK);
          if ((0, XO.tc)(CO)) continue;
          const hO = KO(vK);
          for (const OO of Object.keys(CO)) {
            var bK, lO;
            const KO = CO[OO];
            this.upsert(hO, OO, {
              icon: KO.icon,
              level: KO.level,
              displayName: eO(KO.displayName),
              showInNametag: null === (bK = KO.showInNametag) || void 0 === bK || bK,
              endTime: void 0 !== KO.duration && null !== KO.duration ? (null !== (lO = KO.appliedAt) && void 0 !== lO ? lO : pO) + KO.duration : null
            })
          }
        }
      }
      upsert(OO, KO, pO) {
        this.tracked[OO] || (this.tracked[OO] = {}), this.tracked[OO][KO] = pO
      }
      remove(OO, KO) {
        const pO = this.tracked[OO];
        pO && (delete pO[KO], (0, XO.tc)(pO) && delete this.tracked[OO])
      }
      handleUpdate(OO) {
        var KO;
        0 !== OO.duration ? this.upsert(OO.Qm, OO.name, {
          icon: OO.icon,
          level: OO.level,
          displayName: eO(OO.displayName),
          showInNametag: null === (KO = OO.showInNametag) || void 0 === KO || KO,
          endTime: void 0 !== OO.duration && null !== OO.duration ? Date.now() + OO.duration : null
        }) : this.remove(OO.Qm, OO.name)
      }
      handleRemove(OO, KO) {
        this.remove(OO, KO)
      }
      sample(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Date.now();
        const bK = {},
          eO = 1e3 / KO;
        for (const lO of Object.keys(this.tracked)) {
          const KO = this.tracked[lO],
            vK = {};
          for (const XO of Object.keys(KO)) {
            const bK = KO[XO];
            let CO = null;
            if (null !== bK.endTime) {
              const KO = Math.max(0, bK.endTime - pO);
              if (0 === KO) {
                this.remove(lO, XO);
                continue
              }
              CO = OO + Math.ceil(KO / eO)
            }
            vK[XO] = {
              icon: bK.icon,
              level: bK.level,
              displayName: bK.displayName,
              endTick: CO,
              showInNametag: bK.showInNametag
            }
          }(0, XO.tc)(vK) || (bK[lO] = vK)
        }
        return bK
      }
    }

    function aK(OO, KO, pO, XO) {
      OO.hasEntity(KO) ? OO.updateEffect(KO, pO, XO) : function(OO, KO, pO) {
        bK.i.pl("EffectUpdate", {
          Qm: OO,
          name: KO,
          ...pO
        }, !0)
      }(KO, pO, XO)
    }

    function oO(OO, KO, pO) {
      OO.hasEntity(KO) ? OO.removeEffect(KO, pO) : function(OO, KO) {
        bK.i.pl("RemoveEffect", {
          Qm: OO,
          name: KO
        }, !0)
      }(KO, pO)
    }

    function FO(OO, KO, pO, XO, bK, eO, lO) {
      for (const DO of Object.keys(pO))
        for (const eO of Object.keys(pO[DO])) {
          var vK;
          null !== (vK = KO[DO]) && void 0 !== vK && vK[eO] || (oO(OO, DO, eO), XO && DO === XO && String(bK) !== String(DO) && oO(OO, bK, eO))
        }
      for (const VO of Object.keys(KO))
        for (const vK of Object.keys(KO[VO])) {
          var CO, hO;
          const LO = KO[VO][vK],
            QO = DO(LO.endTick, eO, lO);
          if (0 === QO) {
            oO(OO, VO, vK), XO && VO === XO && String(bK) !== String(VO) && oO(OO, bK, vK);
            continue
          }
          const zK = null === (CO = pO[VO]) || void 0 === CO ? void 0 : CO[vK],
            AO = zK && (FO = LO, (MO = zK).icon === FO.icon && MO.level === FO.level && MO.displayName === FO.displayName && MO.endTick === FO.endTick && MO.showInNametag === FO.showInNametag),
            fO = {
              icon: LO.icon,
              level: LO.level,
              displayName: null !== (hO = LO.displayName) && void 0 !== hO ? hO : void 0,
              duration: QO,
              showInNametag: LO.showInNametag
            };
          AO || aK(OO, VO, vK, fO), XO && VO === XO && aK(OO, bK, vK, {
            ...fO,
            showInNametag: !1
          })
        }
      var MO, FO
    }
  },
  35432: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => hO,
      f: () => CO,
      g: () => MO,
      k: () => lO,
      l: () => DO
    });
    var XO = pO(35427),
      bK = pO(35435);
    const eO = {
      description: "Bloxd Replay",
      accept: {
        [XO.h]: XO.e
      }
    };

    function lO() {
      return "function" === typeof window.showOpenFilePicker && "function" === typeof window.showSaveFilePicker
    }

    function vK(OO) {
      return OO instanceof DOMException && "AbortError" === OO.name
    }
    async function CO() {
      try {
        const [OO] = await window.showOpenFilePicker({
          multiple: !1,
          types: [eO]
        }), KO = await OO.getFile();
        return {
          handle: OO,
          bytes: new Uint8Array(await KO.arrayBuffer())
        }
      } catch (OO) {
        if (vK(OO)) return null;
        throw OO
      }
    }
    async function hO(OO) {
      if (OO && await async function(OO) {
          const KO = {
            mode: "readwrite"
          };
          return "granted" === await OO.queryPermission(KO) || "granted" === await OO.requestPermission(KO)
        }(OO)) return OO;
      try {
        return await window.showSaveFilePicker({
          suggestedName: (0, XO.m)(),
          types: [eO]
        })
      } catch (KO) {
        if (vK(KO)) return null;
        throw KO
      }
    }
    async function DO(OO, KO) {
      const pO = await OO.createWritable();
      await pO.write(new Blob([KO], {
        type: XO.h
      })), await pO.close()
    }

    function MO(OO) {
      return (0, XO.j)((0, bK.h)(OO))
    }
  },
  35e3: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => MO
    });
    var XO = pO(22),
      bK = pO(94),
      eO = pO(36),
      lO = pO(2831),
      vK = pO(2668),
      CO = pO(5800);
    const hO = "shaderPackListingCheckedAt",
      DO = 36e5;

    function MO() {
      const {
        canUseShaderPacks: OO
      } = bK.featureFlags.settings;
      var KO, MO;
      (0, vK.k)(OO) && !(0, vK.g)(OO) && (KO = eO.e.getItem(hO), MO = Date.now(), "number" !== typeof KO || MO < KO || MO - KO >= DO) && (0, lO.d)((() => {
        (async function() {
          if ("landingPage" !== XO.d.get("gameState")) return;
          const OO = await (0, CO.h)();
          if (void 0 === (null === OO || void 0 === OO ? void 0 : OO.listing)) return;
          eO.e.setItem(hO, Date.now());
          const {
            followListingUpdates: KO
          } = await Promise.all([pO.e(127), pO.e(124), pO.e(116)]).then((() => pO(39221)));
          await KO(OO, OO.listing) || eO.e.removeItem(hO)
        })().catch((OO => {
          console.error("Failed to check the shader pack listing for an update", OO)
        }))
      }))
    }
  },
  35017: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO
    });
    var XO = pO(243),
      bK = pO(22),
      eO = pO(35020),
      lO = pO(1441),
      vK = pO(1591);

    function CO(OO, KO) {
      var pO, CO, hO;
      if (!bK.d.get("isKeydownEnabled") || OO.repeat) return;
      const DO = OO.code;
      "Escape" === OO.key ? (0, lO.f)(OO) : null !== (pO = vK.s.OpenSettings) && void 0 !== pO && pO.includes(DO) ? (0, lO.p)(OO, XO.o.SETTINGS) : null !== (CO = vK.s.OpenCharacterCustomization) && void 0 !== CO && CO.includes(DO) ? (0, eO.c)() || (0, lO.p)(OO, XO.o.CUSTOMISATION, KO()) : null !== (hO = vK.s.ShowDebugOverlay) && void 0 !== hO && hO.includes(DO) && bK.d.set({
        showDebugOverlay: !bK.d.get("showDebugOverlay")
      })
    }
  },
  7952: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      f: () => CO
    });
    var XO = pO(22),
      bK = pO(1163),
      eO = pO(94);
    const lO = {
      blockMined: {
        pattern: [18],
        priority: 1,
        minGapMs: 120
      },
      hitLanded: {
        pattern: [20],
        priority: 2,
        minGapMs: 80
      },
      damageTaken: {
        pattern: [45],
        priority: 3,
        minGapMs: 250
      },
      fishBite: {
        pattern: null,
        priority: 3,
        minGapMs: 0
      },
      death: {
        pattern: [60, 70, 120],
        priority: 4,
        minGapMs: 0
      },
      lockReady: {
        pattern: [8],
        priority: 2,
        minGapMs: 0
      },
      lockLocked: {
        pattern: [15, 50, 15],
        priority: 2,
        minGapMs: 0
      },
      autorunLedgeStop: {
        pattern: [40],
        priority: 3,
        minGapMs: 0
      }
    };

    function vK() {
      return (0, eO.isMobile)() && "function" === typeof navigator.vibrate
    }
    const CO = new class {
      constructor(OO) {
        this.deps = OO, this.lastAt = new Map, this.lastAnyAt = -1 / 0, this.playingUntil = -1 / 0, this.playingPriority = 0
      }
      play(OO, KO) {
        var pO;
        if (!this.deps.enabled()) return;
        const XO = lO[OO],
          bK = null !== KO && void 0 !== KO ? KO : XO.pattern;
        if (null === bK) return void console.warn("No vibration pattern for", OO);
        const eO = this.deps.now();
        eO - this.lastAnyAt < 40 && XO.priority < this.playingPriority || eO - (null !== (pO = this.lastAt.get(OO)) && void 0 !== pO ? pO : -1 / 0) < XO.minGapMs || eO < this.playingUntil && XO.priority < this.playingPriority || (this.lastAt.set(OO, eO), this.lastAnyAt = eO, this.playingUntil = eO + bK.reduce(((OO, KO) => OO + KO), 0), this.playingPriority = XO.priority, this.deps.vibrate(bK))
      }
    }({
      vibrate: OO => {
        navigator.vibrate([...OO])
      },
      now: () => performance.now(),
      enabled: () => vK() && XO.d.get("isTouchScreen") && XO.d.get("clientEscMenuOptions").vibration && !(0, bK.f)()
    })
  },
  35008: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => QO
    });
    var XO = pO(533),
      bK = pO(1086),
      eO = pO(149),
      lO = pO(1104),
      vK = pO(1077),
      CO = pO(26),
      hO = pO(1500),
      DO = pO(1521),
      MO = pO(2314),
      aK = pO(1152),
      oO = pO(1163),
      FO = pO(1329),
      VO = pO(1056),
      LO = pO(35011);

    function QO(OO) {
      return async (KO, pO, vK, FO, VO) => {
        let LO;
        if ((0, XO.I)(vK)) {
          if (VO.aborted) return zK();
          const OO = await AO(KO, pO, FO);
          if (VO.aborted || MO.g.matchmakingEnded(OO.isError() ? null : performance.now()), OO.isError()) {
            const KO = OO.asError();
            return console.log("Join room did not succeed, reason:", KO.message), KO.forward()
          }
          LO = OO.getValue()
        } else {
          MO.g.skipPlayWait();
          const OO = fO(vK.replace("https://", "").replace("http://", ""));
          if (OO.isError()) return OO.asError().forward();
          LO = {
            endpoint: OO.getValue(),
            gameNameWithVariation: pO,
            lobbyName: KO instanceof bK.d ? KO.getLobbyName() : KO
          }
        }
        if (VO.aborted) return zK();
        console.log(`Connecting to ${LO.gameNameWithVariation} in lobby ${LO.lobbyName} on game server ${LO.endpoint}`), CO.i.pl("matchmakeAndPlayStepCompleted", {
          step: eO.f.REQUEST_TO_MATCHMAKING,
          totalSubSteps: 1
        }), (0, hO.e)(), DO.d.markGameLoadStart(), (0, oO.q)({
          websocketUrl: LO.endpoint,
          gameNameWithVariation: LO.gameNameWithVariation,
          lobbyName: LO.lobbyName
        }), CO.i.pl("loadingScreenState", "loadingPage:loadingGame");
        const QO = await OO({
          place: LO,
          userContext: FO,
          direct: !(0, XO.I)(vK),
          rematch: async () => {
            const OO = await async function(OO, KO, pO, XO) {
              const bK = await AO(OO, KO, pO);
              if (!bK.isError() && !XO.aborted) {
                const {
                  endpoint: OO,
                  gameNameWithVariation: KO,
                  lobbyName: pO
                } = bK.getValue();
                (0, oO.q)({
                  websocketUrl: OO,
                  gameNameWithVariation: KO,
                  lobbyName: pO
                })
              }
              return bK
            }(KO, pO, FO, VO);
            return OO.isError() || (LO = OO.getValue()), OO
          }
        }, VO);
        return QO.isError() ? QO.asError().forward() : ((0, aK.fb)(), window.gtag ? window.gtag("event", "conversion", {
          send_to: "AW-16469618203/ipUBCJKWoJUZEJvcqa09"
        }) : console.error("window.gtag not defined"), lO.c.value({
          gameNameWithVariation: LO.gameNameWithVariation,
          lobbyName: LO.lobbyName,
          addLobbyToRecentlyPlayed: !(KO instanceof bK.d)
        }))
      }
    }

    function zK() {
      return lO.c.errorWithCode("Left the game while it loaded", eO.f.REQUEST_TO_MATCHMAKING, {
        severity: "low",
        dl: !0
      })
    }
    async function AO(OO, KO, pO) {
      return (0, XO.I)(OO) || OO instanceof bK.d || !(OO.length > vK.K) ? await FO.c.matchmakePlayer(pO, OO, KO, (0, LO.c)()).then((OO => {
        if (!1 === OO.succeeded) return lO.c.errorWithCode(OO.failReason, eO.f.REQUEST_TO_MATCHMAKING, {
          severity: "low"
        });
        const {
          gameServerHost: KO,
          lobbyName: pO,
          gameNameWithVariation: XO
        } = OO, bK = fO(KO);
        return bK.isError() ? bK.asError().forward() : lO.c.value({
          endpoint: bK.getValue(),
          gameNameWithVariation: XO,
          lobbyName: pO
        })
      })).catch((OO => (console.error("Bad response from the matchmaking server:", OO), lO.c.errorWithCode(OO.toString(), eO.f.REQUEST_TO_MATCHMAKING, {
        error: OO,
        severity: "medium"
      })))) : (console.error("Invalid lobby ID:", OO), lO.c.errorWithCode("This lobby link's name is too long. Ask for a new link.", eO.f.REQUEST_TO_MATCHMAKING, {
        severity: "low"
      }))
    }

    function fO(OO) {
      const KO = VO.clientSideServerUrls.getServerWebSocketUrlFromServerUrl(OO);
      return KO.isError() ? lO.c.errorWithCode(KO.asError().message, eO.f.CONNECT_TO_GAME_SERVER, {
        severity: "medium"
      }) : lO.c.value(KO.getValue())
    }
    setTimeout((() => {
      window.initialD ? Date.now = window.initialD : console.error("window.initialD not defined")
    }), 3e3), window.leaveGame = () => {
      (0, oO.n)("/")
    }
  },
  8273: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      f: () => aK
    });
    var XO = pO(22),
      bK = pO(1507),
      eO = pO(36),
      lO = pO(1187),
      vK = pO(2919),
      CO = pO(1302),
      hO = pO(1225);
    const DO = 2592e5,
      MO = "notificationOptInLastPromptedAt";
    async function aK() {
      var OO;
      const KO = await oO();
      if (null === KO) return;
      const pO = null !== (OO = eO.e.getItem(MO)) && void 0 !== OO ? OO : 0;
      if (Date.now() - pO < DO) return;
      if ((0, hO.h)()) return;
      const XO = await lO.NotificationProvider.showPromptPopup({
        icon: "bell",
        title: "mobilePushNotifications:optInTitle",
        subtitle: (0, bK.h)() ? "mobilePushNotifications:optInSubtitle" : "mobilePushNotifications:optInSubtitleBrowser",
        confirmText: "mobilePushNotifications:optInConfirm",
        cancelText: "mobilePushNotifications:optInCancel",
        padStartsOnCancel: !0
      }).getResult();
      "notificationTornDown" !== XO && (eO.e.setItem(MO, Date.now()), (0, CO.e)({
        id: !0 === XO ? "push.allow" : "push.deny",
        value: (0, bK.h)() ? "app" : "browser"
      }), !0 === XO && KO())
    }
    async function oO() {
      return (0, bK.h)() ? XO.d.get("mobilePushNotificationsCanAsk") ? async () => {
        (0, bK.o)("requestNotificationPermission", {})
      }: null: await vK.d.canAsk() ? () => vK.d.requestPermission() : null
    }
  },
  35011: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => LO,
      g: () => QO
    });
    var XO = pO(886),
      bK = pO(536),
      eO = pO(256),
      lO = pO(888),
      vK = pO(554),
      CO = pO(3710),
      hO = pO(94),
      DO = pO(142),
      MO = pO(1481),
      aK = pO(107),
      oO = pO(35015),
      FO = pO(36),
      VO = pO(959);

    function LO() {
      var OO, KO;
      return [...null !== (OO = navigator.languages) && void 0 !== OO ? OO : [null !== (KO = navigator.language) && void 0 !== KO ? KO : "none"], "En-GB"]
    }

    function QO(OO, KO, pO, QO, zK) {
      const AO = (0, XO.k)(KO) ? (0, XO.o)(KO) : null,
        fO = {
          cookies: (0, MO.getAllCookiesForGameNameWithVariation)(KO),
          isMobile: (0, hO.isMobile)(),
          isUsingCustomGameTexturePack: null !== AO && zK(AO),
          generalCookies: {
            joinDiscord: !!FO.e.getItem("DiscordPressed"),
            newGo: CO.d,
            ...OO.getMetricsCookies(),
            trafficCode: QO,
            compliance: hO.compliance
          },
          browserInfo: {
            ua: window.navigator.userAgent,
            name: (0, hO.getBrowserName)(),
            version: (0, hO.getBrowserVersion)(),
            platform: navigator.platform,
            platformType: (0, hO.getPlatformType)(),
            deviceType: (0, aK.c)()
          },
          isLoggedIn: OO.isLoggedIn(),
          lobbyName: pO,
          languages: LO(),
          version: bK.e,
          siteUsed: DO.t,
          subsiteUsed: DO.A,
          playSessionId: (0, oO.l)(KO),
          visitSessionId: (0, VO.b)(),
          clientReason: vK.i.reason
        };
      return null !== AO && (0, eO.xc)(AO) ? (fO.lobbyName = (0, XO.g)(AO, (0, XO.l)(KO), pO), {
        roomName: `classic_${lO.f}`,
        joinOptions: fO
      }) : {
        roomName: KO,
        joinOptions: fO
      }
    }
  },
  7824: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(7833),
      bK = pO(533),
      eO = pO(142);

    function lO(OO) {
      var KO, pO;
      if ((0, bK.I)(OO)) return !0;
      const lO = null !== (KO = null === (pO = eO.p[eO.t]) || void 0 === pO ? void 0 : pO.adConfig.showRewardedAds) && void 0 !== KO && KO;
      for (const bK in OO) {
        const KO = OO[bK];
        if (null !== KO && void 0 !== KO && KO.items)
          for (const OO in KO.items)
            if ((0, XO.i)(KO.items[OO], lO)) return !1
      }
      return !0
    }
  },
  35111: (OO, KO, pO) => {
    function XO(OO, KO) {
      for (let pO = 0; pO < OO.length; pO++)
        if (OO[pO].identifier === KO) return OO[pO];
      return null
    }

    function bK(OO, KO) {
      return null !== XO(OO, KO)
    }
    pO.d(KO, {
      b: () => XO,
      f: () => bK
    })
  },
  35375: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => mK,
      E: () => sO,
      H: () => rK,
      L: () => HO,
      b: () => CO,
      e: () => EO,
      i: () => vK,
      l: () => iK,
      n: () => gK,
      o: () => TO,
      p: () => wO,
      s: () => YO,
      w: () => yK,
      z: () => PO
    });
    var XO = pO(36);
    const bK = {
        codeBlock: ["codeBlockIntro", "docsButton", "hideDocsButton", "aiHelperButton", "hideAiHelperButton", "worldCodeButton", "exportButton", "helpButton"],
        worldCode: ["worldCodeIntro", "docsButton", "hideDocsButton", "aiHelperButton", "hideAiHelperButton", "exportButton", "helpButton"]
      },
      eO = ["docsButton", "docsPanel", "docsClientOptionsTab", "docsClientOptions", "docsApiReferenceTab", "docsApiReference", "docsCallbacksTab", "docsCallbacks", "hideDocsButton"],
      lO = ["aiHelperButton", "aiPanel", "aiAskBox", "aiModelChip", "aiAnswer", "aiEdits", "aiGear", "aiNotes", "aiGameSettings", "hideAiHelperButton"],
      vK = eO.filter((OO => "docsButton" !== OO)),
      CO = lO.filter((OO => "aiHelperButton" !== OO)),
      hO = "codeEditorTutorials",
      DO = {
        codeBlockIntro: "codeBlockIntroShown",
        worldCodeIntro: "worldCodeIntroShown"
      },
      MO = {
        welcome: "welcomeComplete",
        docsOverview: "docsOverviewComplete",
        aiHelperOverview: "aiHelperOverviewComplete"
      };
    let aK = null,
      oO = null;
    const FO = new Set,
      VO = new Set;
    let LO = null;
    const QO = new Set,
      zK = new Set;

    function AO() {
      zK.forEach((OO => {
        OO()
      }))
    }

    function fO() {
      if (!aK) {
        const OO = XO.e.getItem(hO);
        aK = {
          codeBlockIntroShown: !1,
          worldCodeIntroShown: !1,
          welcomeComplete: !1,
          docsOverviewComplete: !1,
          aiHelperOverviewComplete: !1,
          ..."object" === typeof OO && null !== OO ? OO : {}
        }
      }
      return aK
    }

    function dO(OO) {
      const KO = fO();
      KO[OO] || (aK = {
        ...KO,
        [OO]: !0
      }, XO.e.setItem(hO, aK))
    }

    function TO(OO) {
      return "docsOverview" === OO ? eO : "aiHelperOverview" === OO ? lO : oO ? bK[oO] : []
    }

    function NO(OO) {
      return ("worldCodeButton" !== OO || !fO().worldCodeIntroShown) && !QO.has(OO)
    }

    function IO(OO) {
      var KO;
      return (null === (KO = LO) || void 0 === KO ? void 0 : KO.name) === OO ? LO.stepsDone : FO
    }

    function yK(OO, KO) {
      if (! function(OO) {
          return LO ? LO.name === OO : "welcome" === OO
        }(OO) || !NO(KO) || IO(OO).has(KO)) return !1;
      if (LO) return !0;
      const pO = DO[KO];
      return pO ? !fO()[pO] || VO.has(KO) : !fO()[MO[OO]]
    }

    function gK(OO) {
      var KO;
      return null !== (KO = TO(OO).find((KO => yK(OO, KO)))) && void 0 !== KO ? KO : null
    }

    function uO(OO) {
      var KO;
      dO(MO[OO]), (null === (KO = LO) || void 0 === KO ? void 0 : KO.name) === OO && (LO = null)
    }

    function EO(OO) {
      const KO = (LO ? [LO.name] : ["welcome", "docsOverview"]).find((KO => gK(KO) === OO));
      if (!KO) return;
      IO(KO).add(OO);
      const pO = DO[OO];
      pO && (dO(pO), LO || VO.add(OO)), null === gK(KO) && uO(KO), AO()
    }

    function jK(OO, KO) {
      const pO = TO(OO),
        XO = IO(OO);
      for (let bK = pO.indexOf(KO) - 1; bK >= 0; bK--)
        if (XO.has(pO[bK]) && NO(pO[bK])) return pO[bK];
      return null
    }

    function YO(OO, KO) {
      return null !== jK(OO, KO)
    }

    function wO(OO, KO) {
      const pO = jK(OO, KO);
      pO && (IO(OO).delete(pO), AO())
    }

    function iK(OO) {
      uO(OO), "welcome" === OO && TO("welcome").forEach((OO => {
        const KO = DO[OO];
        KO && dO(KO)
      })), AO()
    }

    function rK(OO) {
      LO = {
        name: OO,
        stepsDone: new Set
      }, AO()
    }

    function PO() {
      (LO || 0 !== FO.size || 0 !== VO.size) && (LO = null, FO.clear(), VO.clear(), AO())
    }

    function mK(OO, KO) {
      const pO = KO ? OO : oO === OO ? null : oO;
      pO !== oO && (oO = pO, AO())
    }

    function sO(OO, KO) {
      QO.has(OO) === KO && (KO ? QO.delete(OO) : QO.add(OO), AO())
    }

    function HO(OO) {
      return zK.add(OO), () => {
        zK.delete(OO)
      }
    }
  },
  7865: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      f: () => XO
    });
    const XO = 100;

    function bK(OO) {
      let {
        translationKeys: KO = !1
      } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      return OO.map((OO => {
        var pO;
        return null !== (pO = function(OO, KO) {
          if ("string" === typeof OO) return OO;
          const pO = "str" in OO ? OO.str : OO;
          if ("string" === typeof pO) return pO;
          if ("entityName" in pO) return pO.entityName;
          if (KO && "translationKey" in pO) return `{${pO.translationKey}${void 0===pO.params?"":` ${JSON.stringify(pO.params)}`}}`;
          return null
        }(OO, KO)) && void 0 !== pO ? pO : " "
      })).join("")
    }
  },
  7899: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      h: () => vK,
      l: () => CO
    });
    var XO = pO(1803),
      bK = pO(1098),
      eO = pO(1811);
    const lO = ",";

    function vK(OO) {
      if (!OO) return [];
      const KO = new Set,
        pO = [];
      for (const XO of OO.split(lO)) {
        const OO = XO.trim();
        if ((0, eO.n)(OO) && !KO.has(OO) && (KO.add(OO), pO.push(OO), pO.length >= bK.m)) break
      }
      return pO
    }

    function CO(OO) {
      const KO = new Set,
        pO = [];
      for (const XO of OO)
        if ((0, eO.n)(XO) && !KO.has(XO) && (KO.add(XO), pO.push(XO), pO.length >= bK.m)) break;
      return pO.join(lO)
    }

    function hO() {
      return CO(eO.g)
    }

    function DO(OO) {
      var KO;
      return "emote" === OO ? hO() : null !== (KO = MO[OO][0]) && void 0 !== KO ? KO : aK[OO]
    }
    const MO = bK.w.reduce(((OO, KO) => {
        const pO = [];
        for (const eO in XO.d[KO]) {
          var bK;
          "default" === (null === (bK = (0, XO.j)(KO, eO)) || void 0 === bK ? void 0 : bK.cosmeticPack) && pO.push(eO)
        }
        return OO[KO] = pO, OO
      }), {}),
      aK = bK.w.reduce(((OO, KO) => (OO[KO] = Object.keys(XO.d[KO])[0], OO)), {})
  },
  35348: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO,
      e: () => vK
    });
    const XO = {
        files: {
          "debugLog.ts": "export function debugLog(message: string): void {\n\tconsole.log(`[debug] ${message}`)\n}\n",
          "index.ts": 'import type { PlayerId } from "@bloxd"\nimport { debugLog } from "./debugLog"\n\nonPlayerJoin = (player: PlayerId) => {\n\tapi.log(`Player ${player} joined - Love from Debug Plugin!`)\n}\n\nexport { debugLog }\n'
        },
        dependencies: [],
        bundledSource: 'var __defProp = Object.defineProperty;\nvar __getOwnPropDesc = Object.getOwnPropertyDescriptor;\nvar __getOwnPropNames = Object.getOwnPropertyNames;\nvar __hasOwnProp = Object.prototype.hasOwnProperty;\nvar __export = (target, all) => {\n  for (var name in all)\n    __defProp(target, name, { get: all[name], enumerable: true });\n};\nvar __copyProps = (to, from, except, desc) => {\n  if (from && typeof from === "object" || typeof from === "function") {\n    for (let key of __getOwnPropNames(from))\n      if (!__hasOwnProp.call(to, key) && key !== except)\n        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });\n  }\n  return to;\n};\nvar __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);\n\n// world-code-plugin:index.ts\nvar index_exports = {};\n__export(index_exports, {\n  debugLog: () => debugLog\n});\nmodule.exports = __toCommonJS(index_exports);\n\n// world-code-plugin:debugLog.ts\nfunction debugLog(message) {\n  console.log(`[debug] ${message}`);\n}\n\n// world-code-plugin:index.ts\nonPlayerJoin = (player) => {\n  api.log(`Player ${player} joined - Love from Debug Plugin!`);\n};\n',
        types: "declare function debugLog(message: string): void;\n\nexport { debugLog };\n"
      },
      bK = {
        files: {
          "index.ts": 'import type { CustomTextStyling, DialogueText, PlayerId, SpeechVoice } from "@bloxd"\nimport { clearTimeout, setTimeout, TimeoutId } from "@plugins/helpers"\n\n/** Long enough to read most lines once they have appeared. */\nconst DEFAULT_DURATION_MS = 6000\n\nexport type DialogueOpts = {\n\t/** Shown above the line, such as a name. */\n\tspeakerName?: string | CustomTextStyling\n\t/** A preset such as "regular" or "gruff", or every synth parameter. Omit for a silent line. */\n\tvoice?: SpeechVoice\n\t/** How long the line stays up, counted from when it starts to appear. Defaults to 6 seconds. */\n\tdurationMs?: number\n}\n\nconst hideTimeouts: Record<PlayerId, TimeoutId> = {}\n\n/**\n * Shows a player a line of dialogue below the crosshair for a while. A new line replaces the one already up.\n * @param playerId - The player to show the line to\n * @param text - The line. `[[Item Name]]` shows the item\'s icon inline\n * @param opts - The speaker\'s name, the voice that reads it out, and how long it stays up\n */\nexport function sayDialogue(playerId: PlayerId, text: DialogueText, opts: DialogueOpts = {}) {\n\tif (hideTimeouts[playerId] !== undefined) {\n\t\tclearTimeout(hideTimeouts[playerId])\n\t\t// Cleared first, so a line said again replays rather than matching the value already set\n\t\tapi.setClientOption(playerId, "dialogue", null)\n\t}\n\tapi.setClientOption(playerId, "dialogue", { line: text, speakerName: opts.speakerName, voice: opts.voice })\n\thideTimeouts[playerId] = setTimeout(\n\t\t() => {\n\t\t\tclearDialogue(playerId)\n\t\t},\n\t\topts.durationMs ?? DEFAULT_DURATION_MS,\n\t\tplayerId,\n\t)\n}\n\n/**\n * Hides the line of dialogue a player is shown.\n * @param playerId - The player shown the line\n */\nexport function clearDialogue(playerId: PlayerId) {\n\tif (hideTimeouts[playerId] === undefined) {\n\t\treturn\n\t}\n\tclearTimeout(hideTimeouts[playerId])\n\tdelete hideTimeouts[playerId]\n\tapi.setClientOption(playerId, "dialogue", null)\n}\n\nonPlayerLeave = (playerId: PlayerId) => {\n\tdelete hideTimeouts[playerId]\n}\n'
        },
        dependencies: ["helpers"],
        bundledSource: 'var __defProp = Object.defineProperty;\nvar __getOwnPropDesc = Object.getOwnPropertyDescriptor;\nvar __getOwnPropNames = Object.getOwnPropertyNames;\nvar __hasOwnProp = Object.prototype.hasOwnProperty;\nvar __export = (target, all) => {\n  for (var name in all)\n    __defProp(target, name, { get: all[name], enumerable: true });\n};\nvar __copyProps = (to, from, except, desc) => {\n  if (from && typeof from === "object" || typeof from === "function") {\n    for (let key of __getOwnPropNames(from))\n      if (!__hasOwnProp.call(to, key) && key !== except)\n        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });\n  }\n  return to;\n};\nvar __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);\n\n// world-code-plugin:index.ts\nvar index_exports = {};\n__export(index_exports, {\n  clearDialogue: () => clearDialogue,\n  sayDialogue: () => sayDialogue\n});\nmodule.exports = __toCommonJS(index_exports);\nvar import_helpers = require("@plugins/helpers");\nvar DEFAULT_DURATION_MS = 6e3;\nvar hideTimeouts = {};\nfunction sayDialogue(playerId, text, opts = {}) {\n  if (hideTimeouts[playerId] !== void 0) {\n    (0, import_helpers.clearTimeout)(hideTimeouts[playerId]);\n    api.setClientOption(playerId, "dialogue", null);\n  }\n  api.setClientOption(playerId, "dialogue", { line: text, speakerName: opts.speakerName, voice: opts.voice });\n  hideTimeouts[playerId] = (0, import_helpers.setTimeout)(\n    () => {\n      clearDialogue(playerId);\n    },\n    opts.durationMs ?? DEFAULT_DURATION_MS,\n    playerId\n  );\n}\nfunction clearDialogue(playerId) {\n  if (hideTimeouts[playerId] === void 0) {\n    return;\n  }\n  (0, import_helpers.clearTimeout)(hideTimeouts[playerId]);\n  delete hideTimeouts[playerId];\n  api.setClientOption(playerId, "dialogue", null);\n}\nonPlayerLeave = (playerId) => {\n  delete hideTimeouts[playerId];\n};\n',
        types: "import { CustomTextStyling, SpeechVoice, PlayerId, DialogueText } from '@bloxd';\n\ntype DialogueOpts = {\n    /** Shown above the line, such as a name. */\n    speakerName?: string | CustomTextStyling;\n    /** A preset such as \"regular\" or \"gruff\", or every synth parameter. Omit for a silent line. */\n    voice?: SpeechVoice;\n    /** How long the line stays up, counted from when it starts to appear. Defaults to 6 seconds. */\n    durationMs?: number;\n};\n/**\n * Shows a player a line of dialogue below the crosshair for a while. A new line replaces the one already up.\n * @param playerId - The player to show the line to\n * @param text - The line. `[[Item Name]]` shows the item's icon inline\n * @param opts - The speaker's name, the voice that reads it out, and how long it stays up\n */\ndeclare function sayDialogue(playerId: PlayerId, text: DialogueText, opts?: DialogueOpts): void;\n/**\n * Hides the line of dialogue a player is shown.\n * @param playerId - The player shown the line\n */\ndeclare function clearDialogue(playerId: PlayerId): void;\n\nexport { clearDialogue, sayDialogue };\nexport type { DialogueOpts };\n"
      },
      eO = {
        files: {
          "chunk.ts": 'import { setTimeout } from "./timers"\n\n/**\n * Forces a chunk to be loaded.\n * @param x - The x coordinate of the chunk\n * @param y - The y coordinate of the chunk\n * @param z - The z coordinate of the chunk\n * @param onLoaded - The function to call when the chunk is loaded\n */\nexport function forceLoadChunk(x: number, y: number, z: number, onLoaded: () => void) {\n\tconst block = api.getBlock(x, y, z)\n\tif (block !== "Unloaded") {\n\t\tonLoaded()\n\t\treturn\n\t}\n\n\tsetTimeout(() => {\n\t\tforceLoadChunk(x, y, z, onLoaded)\n\t}, 100)\n}\n',
          "index.ts": 'import { handleTimers } from "./timers"\n\ntick = () => {\n\thandleTimers()\n}\n\nexport { setTimeout, setInterval, clearTimeout, clearInterval } from "./timers"\nexport type { TimeoutId, IntervalId } from "./timers"\nexport { forceLoadChunk } from "./chunk"\nexport { randomInt, shuffleArray, getRandomItem } from "./random"\n',
          "random.ts": "/**\n * Generates a random integer between min and max, inclusive.\n * @param min - The minimum value.\n * @param max - The maximum value.\n * @param includeMax - Whether to include the max value in the range. Defaults to false.\n * @returns A random integer between min and max, inclusive.\n */\nexport function randomInt(min: number, max: number, includeMax: boolean = false): number {\n\treturn Math.floor(Math.random() * (max - min + (includeMax ? 1 : 0))) + min\n}\n\n/**\n * Shuffles an array in place.\n * @param array - The array to shuffle.\n * @returns The shuffled array.\n */\nexport function shuffleArray<T>(array: T[]): T[] {\n\tfor (let i = 0; i < array.length; i++) {\n\t\tconst j = randomInt(i, array.length)\n\t\t;[array[i], array[j]] = [array[j], array[i]]\n\t}\n\treturn array\n}\n\n/**\n * Gets a random item from an array.\n * @param array - The array to get a random item from.\n * @returns A random item from the array.\n */\nexport function getRandomItem<T extends readonly any[]>(array: T): T[number]\nexport function getRandomItem<T>(array: readonly T[] | T[]): T | undefined {\n\treturn array[randomInt(0, array.length)]\n}\n",
          "timers.ts": 'import { PlayerId } from "@bloxd"\n\ndeclare const __brand: unique symbol\ntype Branded<T, B> = T & { [__brand]: B }\nexport type TimeoutId = Branded<number, "TimeoutId">\nexport type IntervalId = Branded<number, "IntervalId">\n\nlet nextTimeoutId: number = 1\nlet nextIntervalId: number = 1\ntype Callback = {\n\tcallback: () => void\n\tcallAt: number\n\tinterval?: number\n\tplayerId?: PlayerId\n}\nconst timeouts: Record<TimeoutId, Callback> = {}\nconst intervals: Record<IntervalId, Callback> = {}\n\n/**\n * Registers a function to be called after a delay.\n * @param callback - The callback to call when the timeout expires\n * @param delay - The delay in milliseconds before the callback is called\n * @param playerId - Optional playerId to tie the timeout to. If the player leaves, this timeout will be cleared\n * @returns The timeout id\n */\nexport function setTimeout(callback: () => void, delay: number, playerId?: PlayerId): TimeoutId {\n\tconst id = nextTimeoutId++\n\ttimeouts[id] = { callback, callAt: api.now() + delay, playerId }\n\treturn id as TimeoutId\n}\n\n/**\n * Registers a function to be called repeatedly every interval.\n * @param callback - The callback to call when the interval expires\n * @param interval - The interval in milliseconds before the callback is called\n * @param playerId - Optional playerId to tie the interval to. If the player leaves, this interval will be stopped\n * @returns The interval id\n */\nexport function setInterval(callback: () => void, interval: number, playerId?: PlayerId): IntervalId {\n\tconst id = nextIntervalId++\n\tintervals[id] = { callback, callAt: api.now() + interval, interval, playerId }\n\treturn id as IntervalId\n}\n\n/**\n * Clears a timeout.\n * @param id - The id of the timeout to clear\n */\nexport function clearTimeout(id: TimeoutId) {\n\tdelete timeouts[id]\n}\n\n/**\n * Clears an interval.\n * @param id - The id of the interval to clear\n */\nexport function clearInterval(id: IntervalId) {\n\tdelete intervals[id]\n}\n\nexport function handleTimers() {\n\tconst now = api.now()\n\tfor (const timeoutId in timeouts) {\n\t\tconst callback = timeouts[timeoutId]\n\t\tif (callback.callAt <= now) {\n\t\t\tif (!callback.playerId || api.checkValid(callback.playerId)) {\n\t\t\t\ttry {\n\t\t\t\t\tcallback.callback()\n\t\t\t\t} catch (e) {\n\t\t\t\t\tapi.log(`Error in timeout callback ${timeoutId}: ${e}`)\n\t\t\t\t}\n\t\t\t}\n\t\t\tdelete timeouts[timeoutId]\n\t\t}\n\t}\n\tfor (const intervalId in intervals) {\n\t\tconst callback = intervals[intervalId]\n\t\tif (callback.callAt <= now) {\n\t\t\tif (callback.playerId && !api.checkValid(callback.playerId)) {\n\t\t\t\tdelete intervals[intervalId]\n\t\t\t\tcontinue\n\t\t\t}\n\n\t\t\ttry {\n\t\t\t\tcallback.callback()\n\t\t\t} catch (e) {\n\t\t\t\tapi.log(`Error in interval callback ${intervalId}: ${e}`)\n\t\t\t}\n\t\t\tcallback.callAt += callback.interval\n\t\t}\n\t}\n}\n'
        },
        dependencies: [],
        bundledSource: 'var __defProp = Object.defineProperty;\nvar __getOwnPropDesc = Object.getOwnPropertyDescriptor;\nvar __getOwnPropNames = Object.getOwnPropertyNames;\nvar __hasOwnProp = Object.prototype.hasOwnProperty;\nvar __export = (target, all) => {\n  for (var name in all)\n    __defProp(target, name, { get: all[name], enumerable: true });\n};\nvar __copyProps = (to, from, except, desc) => {\n  if (from && typeof from === "object" || typeof from === "function") {\n    for (let key of __getOwnPropNames(from))\n      if (!__hasOwnProp.call(to, key) && key !== except)\n        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });\n  }\n  return to;\n};\nvar __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);\n\n// world-code-plugin:index.ts\nvar index_exports = {};\n__export(index_exports, {\n  clearInterval: () => clearInterval,\n  clearTimeout: () => clearTimeout,\n  forceLoadChunk: () => forceLoadChunk,\n  getRandomItem: () => getRandomItem,\n  randomInt: () => randomInt,\n  setInterval: () => setInterval,\n  setTimeout: () => setTimeout,\n  shuffleArray: () => shuffleArray\n});\nmodule.exports = __toCommonJS(index_exports);\n\n// world-code-plugin:timers.ts\nvar nextTimeoutId = 1;\nvar nextIntervalId = 1;\nvar timeouts = {};\nvar intervals = {};\nfunction setTimeout(callback, delay, playerId) {\n  const id = nextTimeoutId++;\n  timeouts[id] = { callback, callAt: api.now() + delay, playerId };\n  return id;\n}\nfunction setInterval(callback, interval, playerId) {\n  const id = nextIntervalId++;\n  intervals[id] = { callback, callAt: api.now() + interval, interval, playerId };\n  return id;\n}\nfunction clearTimeout(id) {\n  delete timeouts[id];\n}\nfunction clearInterval(id) {\n  delete intervals[id];\n}\nfunction handleTimers() {\n  const now = api.now();\n  for (const timeoutId in timeouts) {\n    const callback = timeouts[timeoutId];\n    if (callback.callAt <= now) {\n      if (!callback.playerId || api.checkValid(callback.playerId)) {\n        try {\n          callback.callback();\n        } catch (e) {\n          api.log(`Error in timeout callback ${timeoutId}: ${e}`);\n        }\n      }\n      delete timeouts[timeoutId];\n    }\n  }\n  for (const intervalId in intervals) {\n    const callback = intervals[intervalId];\n    if (callback.callAt <= now) {\n      if (callback.playerId && !api.checkValid(callback.playerId)) {\n        delete intervals[intervalId];\n        continue;\n      }\n      try {\n        callback.callback();\n      } catch (e) {\n        api.log(`Error in interval callback ${intervalId}: ${e}`);\n      }\n      callback.callAt += callback.interval;\n    }\n  }\n}\n\n// world-code-plugin:chunk.ts\nfunction forceLoadChunk(x, y, z, onLoaded) {\n  const block = api.getBlock(x, y, z);\n  if (block !== "Unloaded") {\n    onLoaded();\n    return;\n  }\n  setTimeout(() => {\n    forceLoadChunk(x, y, z, onLoaded);\n  }, 100);\n}\n\n// world-code-plugin:random.ts\nfunction randomInt(min, max, includeMax = false) {\n  return Math.floor(Math.random() * (max - min + (includeMax ? 1 : 0))) + min;\n}\nfunction shuffleArray(array) {\n  for (let i = 0; i < array.length; i++) {\n    const j = randomInt(i, array.length);\n    [array[i], array[j]] = [array[j], array[i]];\n  }\n  return array;\n}\nfunction getRandomItem(array) {\n  return array[randomInt(0, array.length)];\n}\n\n// world-code-plugin:index.ts\ntick = () => {\n  handleTimers();\n};\n',
        types: 'import { PlayerId } from \'@bloxd\';\n\ndeclare const __brand: unique symbol;\ntype Branded<T, B> = T & {\n    [__brand]: B;\n};\ntype TimeoutId = Branded<number, "TimeoutId">;\ntype IntervalId = Branded<number, "IntervalId">;\n/**\n * Registers a function to be called after a delay.\n * @param callback - The callback to call when the timeout expires\n * @param delay - The delay in milliseconds before the callback is called\n * @param playerId - Optional playerId to tie the timeout to. If the player leaves, this timeout will be cleared\n * @returns The timeout id\n */\ndeclare function setTimeout(callback: () => void, delay: number, playerId?: PlayerId): TimeoutId;\n/**\n * Registers a function to be called repeatedly every interval.\n * @param callback - The callback to call when the interval expires\n * @param interval - The interval in milliseconds before the callback is called\n * @param playerId - Optional playerId to tie the interval to. If the player leaves, this interval will be stopped\n * @returns The interval id\n */\ndeclare function setInterval(callback: () => void, interval: number, playerId?: PlayerId): IntervalId;\n/**\n * Clears a timeout.\n * @param id - The id of the timeout to clear\n */\ndeclare function clearTimeout(id: TimeoutId): void;\n/**\n * Clears an interval.\n * @param id - The id of the interval to clear\n */\ndeclare function clearInterval(id: IntervalId): void;\n\n/**\n * Forces a chunk to be loaded.\n * @param x - The x coordinate of the chunk\n * @param y - The y coordinate of the chunk\n * @param z - The z coordinate of the chunk\n * @param onLoaded - The function to call when the chunk is loaded\n */\ndeclare function forceLoadChunk(x: number, y: number, z: number, onLoaded: () => void): void;\n\n/**\n * Generates a random integer between min and max, inclusive.\n * @param min - The minimum value.\n * @param max - The maximum value.\n * @param includeMax - Whether to include the max value in the range. Defaults to false.\n * @returns A random integer between min and max, inclusive.\n */\ndeclare function randomInt(min: number, max: number, includeMax?: boolean): number;\n/**\n * Shuffles an array in place.\n * @param array - The array to shuffle.\n * @returns The shuffled array.\n */\ndeclare function shuffleArray<T>(array: T[]): T[];\n/**\n * Gets a random item from an array.\n * @param array - The array to get a random item from.\n * @returns A random item from the array.\n */\ndeclare function getRandomItem<T extends readonly any[]>(array: T): T[number];\n\nexport { clearInterval, clearTimeout, forceLoadChunk, getRandomItem, randomInt, setInterval, setTimeout, shuffleArray };\nexport type { IntervalId, TimeoutId };\n'
      },
      lO = {
        files: {
          "MapVoter.ts": 'import { PlayerId } from "@bloxd"\nimport { BaseMapInfo, BaseTeamInfo } from "./types"\nimport { SessionBasedPlayer } from "./SessionBasedPlayer"\nimport { shuffleArray, getRandomItem, setTimeout } from "@plugins/helpers"\n\nconst MAP_VOTING_CATEGORY = "__SBG_MAP_VOTING__"\nconst MAP_VOTING_ITEM_PREFIX = "__SBG_MAP_"\n\nconst MAP_OPTION_COUNT = 4\n\nexport class MapVoter<TeamInfo extends BaseTeamInfo, MapInfo extends BaseMapInfo<TeamInfo>> {\n\tprivate possibleMapOptions: MapInfo[] = []\n\tprivate mapVotes: Record<PlayerId, MapInfo["name"]> = {}\n\tprivate mapVotingActive: boolean = false\n\n\tconstructor(\n\t\treadonly maps: readonly MapInfo[],\n\t\treadonly players: Record<PlayerId, SessionBasedPlayer<TeamInfo, MapInfo>>,\n\t) {}\n\n\tcreateMapVoting(): void {\n\t\tif (this.mapVotingActive) {\n\t\t\treturn\n\t\t}\n\t\tthis.mapVotingActive = true\n\t\tapi.configureShopCategory(MAP_VOTING_CATEGORY, {\n\t\t\tcustomTitle: "Map Voting",\n\t\t\tsortPriority: 0.5,\n\t\t})\n\n\t\t// Delete previous map options\n\t\tfor (const map of this.possibleMapOptions) {\n\t\t\tapi.deleteShopItem(MAP_VOTING_CATEGORY, `${MAP_VOTING_ITEM_PREFIX}${map.name}`)\n\t\t}\n\n\t\tconst possibleOptions = this.maps.slice()\n\t\tshuffleArray(possibleOptions)\n\t\tthis.possibleMapOptions = possibleOptions.slice(0, MAP_OPTION_COUNT)\n\t\tfor (const map of this.possibleMapOptions) {\n\t\t\tapi.createShopItem(MAP_VOTING_CATEGORY, `${MAP_VOTING_ITEM_PREFIX}${map.name}`, {\n\t\t\t\timage: map.icon,\n\t\t\t\tcustomTitle: map.name,\n\t\t\t\tcanBuy: true,\n\t\t\t\tbuyButtonText: "Votes: 0",\n\t\t\t})\n\t\t}\n\n\t\tsetTimeout(() => {\n\t\t\tfor (const playerId in this.players) {\n\t\t\t\tapi.openShop(playerId, false, MAP_VOTING_CATEGORY)\n\t\t\t}\n\t\t}, 100)\n\t}\n\n\tonMapVote(playerId: PlayerId, categoryKey: string, shopItemKey: string) {\n\t\tif (categoryKey !== MAP_VOTING_CATEGORY) {\n\t\t\treturn\n\t\t}\n\t\tif (!this.mapVotingActive) {\n\t\t\treturn\n\t\t}\n\t\tif (!shopItemKey.startsWith(MAP_VOTING_ITEM_PREFIX)) {\n\t\t\treturn\n\t\t}\n\t\tconst mapName = shopItemKey.replace(MAP_VOTING_ITEM_PREFIX, "")\n\t\tif (\n\t\t\t!this.possibleMapOptions.some((map) => {\n\t\t\t\treturn map.name === mapName\n\t\t\t})\n\t\t) {\n\t\t\treturn\n\t\t}\n\t\tconst hadVotedBefore = !!this.mapVotes[playerId]\n\t\tthis.mapVotes[playerId] = mapName\n\t\tthis.updateMapVotingForPlayer(playerId)\n\t\tthis.updateMapCountsForEveryone()\n\t\tif (!hadVotedBefore) {\n\t\t\tapi.openShop(playerId, true)\n\t\t}\n\t}\n\n\tonPlayerJoin(playerId: PlayerId) {\n\t\tif (!this.mapVotingActive) {\n\t\t\treturn\n\t\t}\n\t\tthis.updateMapVotingForPlayer(playerId)\n\t\tsetTimeout(\n\t\t\t() => {\n\t\t\t\tapi.openShop(playerId, false, MAP_VOTING_CATEGORY)\n\t\t\t},\n\t\t\t100,\n\t\t\tplayerId,\n\t\t)\n\t}\n\n\tonPlayerLeave(playerId: PlayerId) {\n\t\tif (!this.mapVotingActive) {\n\t\t\treturn\n\t\t}\n\t\tdelete this.mapVotes[playerId]\n\t\tthis.updateMapCountsForEveryone()\n\t}\n\n\tprivate updateMapCountsForEveryone() {\n\t\tfor (const map of this.possibleMapOptions) {\n\t\t\tconst votes = Object.values(this.mapVotes).filter((v) => {\n\t\t\t\treturn v === map.name\n\t\t\t}).length\n\t\t\tapi.updateShopItem(MAP_VOTING_CATEGORY, `${MAP_VOTING_ITEM_PREFIX}${map.name}`, {\n\t\t\t\tbuyButtonText: `Votes: ${votes}`,\n\t\t\t})\n\t\t}\n\t}\n\tprivate updateMapVotingForPlayer(playerId: PlayerId) {\n\t\tapi.configureShopCategoryForPlayer(playerId, MAP_VOTING_CATEGORY, {\n\t\t\tredDot: !this.mapVotes[playerId],\n\t\t})\n\t\tfor (const map of this.possibleMapOptions) {\n\t\t\tapi.updateShopItemForPlayer(playerId, MAP_VOTING_CATEGORY, `${MAP_VOTING_ITEM_PREFIX}${map.name}`, {\n\t\t\t\tcanBuy: this.mapVotes[playerId] !== map.name,\n\t\t\t\tisSelected: this.mapVotes[playerId] === map.name,\n\t\t\t})\n\t\t}\n\t}\n\n\tendMapVoting() {\n\t\tif (!this.mapVotingActive) {\n\t\t\treturn\n\t\t}\n\t\tthis.mapVotingActive = false\n\t\tfor (const map of this.possibleMapOptions) {\n\t\t\tapi.deleteShopItem(MAP_VOTING_CATEGORY, `${MAP_VOTING_ITEM_PREFIX}${map.name}`)\n\t\t}\n\t\tthis.possibleMapOptions = []\n\t\tthis.mapVotes = {}\n\t}\n\n\tchooseMap(): MapInfo {\n\t\tif (!this.mapVotingActive) {\n\t\t\treturn null\n\t\t}\n\t\tconst votedPlayers = Object.keys(this.mapVotes)\n\t\tif (votedPlayers.length === 0) {\n\t\t\treturn getRandomItem(this.possibleMapOptions)\n\t\t}\n\n\t\tconst randomPlayer = getRandomItem(votedPlayers)\n\t\tconst choice = this.mapVotes[randomPlayer]\n\t\treturn this.maps.find((map) => {\n\t\t\treturn map.name === choice\n\t\t})\n\t}\n}\n',
          "SessionBasedGame.ts": 'import { BaseTeamInfo, BaseMapInfo, SessionBasedGameSetupOptions, MapSource } from "./types"\nimport { SessionBasedPlayer } from "./SessionBasedPlayer"\nimport { BlockName, CustomTextStyling, PlayerId, Pos } from "@bloxd"\nimport { style, getDimensions, getLowHigh, displayMs, getSourceRect } from "./helpers"\nimport { forceLoadChunk, setInterval, shuffleArray, getRandomItem } from "@plugins/helpers"\nimport { MapVoter } from "./MapVoter"\n\nexport class SessionBasedGame<TeamInfo extends BaseTeamInfo, MapInfo extends BaseMapInfo<TeamInfo>, Player extends SessionBasedPlayer<TeamInfo, MapInfo>> {\n\tgamePhase: "beforeGame" | "inGame" | "gameFinished" = "beforeGame"\n\tprivate startingRound = false\n\tprivate players: Record<PlayerId, Player> = {}\n\tmap: MapInfo | null = null\n\tprivate gameStartTime: number = 0\n\tprivate startGameAt: number = Infinity\n\tprivate endGameAt: number = Infinity\n\tprivate mapVoter: MapVoter<TeamInfo, MapInfo>\n\n\tmessageColours = {\n\t\terror: "#ff0000",\n\t\tsuccess: "#00ff00",\n\t\tinfo: "#ffffff",\n\t}\n\n\tprivate get playersForFullLobby() {\n\t\treturn this.gameOptions.teams.reduce((a, b) => {\n\t\t\treturn a + b.maxPlayers\n\t\t}, 0)\n\t}\n\n\tprivate get playerCount() {\n\t\treturn Object.keys(this.players).length\n\t}\n\n\tconstructor(readonly gameOptions: Required<SessionBasedGameSetupOptions<TeamInfo, MapInfo, Player>>) {\n\t\tthis.mapVoter = new MapVoter(this.gameOptions.maps, this.players)\n\t\tthis.resetGame(false)\n\t\tsetInterval(() => {\n\t\t\tthis.sendRightInfoText()\n\t\t}, 1000)\n\t}\n\n\t/**\n\t * Gets the player object for a given player ID.\n\t * @param playerId The player ID to get the player for\n\t */\n\tgetPlayer(playerId: PlayerId) {\n\t\treturn this.players[playerId]\n\t}\n\n\t/**\n\t * Gets all the players in the game, including spectators.\n\t * @returns An iterator of all the players in the game.\n\t */\n\t*getPlayers(): Generator<Player> {\n\t\tfor (const playerId in this.players) {\n\t\t\tyield this.players[playerId]\n\t\t}\n\t}\n\n\tgetStartingInText(): string | CustomTextStyling {\n\t\tif (this.gamePhase !== "beforeGame") {\n\t\t\treturn []\n\t\t}\n\t\tconst timeLeft = this.startGameAt - api.now()\n\t\tif (timeLeft < 0) {\n\t\t\treturn []\n\t\t}\n\t\treturn [\n\t\t\t...style({ translationKey: "sessionBasedGame:startingIn" }, this.messageColours.info),\n\t\t\t" ",\n\t\t\t...style(`${displayMs(timeLeft)}`, timeLeft < 10_000 ? this.messageColours.success : this.messageColours.info),\n\t\t]\n\t}\n\t/**\n\t * Gives all players coloured armour based on their team name. Spectators will get black armour.\n\t * If their team name is not a valid colour, they will be skipped.\n\t */\n\tgiveColouredArmourToEveryone() {\n\t\tfor (const playerId in this.players) {\n\t\t\tconst player = this.players[playerId]\n\t\t\tconst prefix = player.team ? player.team.name : "Black"\n\t\t\ttry {\n\t\t\t\tapi.setItemSlot(playerId, 46, `${prefix} Wood Helmet`)\n\t\t\t\tapi.setItemSlot(playerId, 47, `${prefix} Wood Chestplate`)\n\t\t\t\tapi.setItemSlot(playerId, 48, `${prefix} Wood Gauntlets`)\n\t\t\t\tapi.setItemSlot(playerId, 49, `${prefix} Wood Leggings`)\n\t\t\t\tapi.setItemSlot(playerId, 50, `${prefix} Wood Boots`)\n\t\t\t} catch (e) {\n\t\t\t\tapi.log(`Error giving coloured armour to player ${playerId}: ${e}`)\n\t\t\t}\n\t\t}\n\t}\n\n\tonPlayerJoin(playerId: PlayerId) {\n\t\tthis.players[playerId] = new this.gameOptions.playerConstructor(playerId, this)\n\t\tthis.mapVoter.onPlayerJoin(playerId)\n\t\tthis.updateTimeTillStart()\n\t}\n\n\tonPlayerLeave(playerId: PlayerId) {\n\t\tif (!this.players[playerId]) {\n\t\t\treturn\n\t\t}\n\t\tif (this.gamePhase === "beforeGame") {\n\t\t\tconst requestedTeam = this.players[playerId].requestedTeam\n\t\t\tif (requestedTeam) {\n\t\t\t\tthis.placeTeamPad(requestedTeam.name, false)\n\t\t\t}\n\t\t}\n\t\tdelete this.players[playerId]\n\t\tthis.checkWin()\n\t\tthis.mapVoter.onPlayerLeave(playerId)\n\t}\n\n\tonPlayerDie(playerId: PlayerId) {\n\t\tthis.checkWin()\n\t}\n\n\tcheckWin() {\n\t\tif (this.gamePhase !== "inGame") {\n\t\t\treturn\n\t\t}\n\t\tconst teamsAlive = this.getTeamsAlive()\n\t\tif (teamsAlive.length === 1) {\n\t\t\tthis.makeTeamWin(teamsAlive[0])\n\t\t}\n\t}\n\n\tonPlayerChat(playerId: PlayerId, message: string) {\n\t\treturn this.players[playerId].onMessage()\n\t}\n\n\tonPlayerBoughtShopItem(playerId: PlayerId, categoryKey: string, itemKey: string) {\n\t\tthis.mapVoter.onMapVote(playerId, categoryKey, itemKey)\n\t}\n\n\ttick() {\n\t\tthis.checkGameTransition()\n\t}\n\n\tprivate getTeamsAlive() {\n\t\tconst teamsAlive: TeamInfo[] = []\n\t\tfor (const playerId in this.players) {\n\t\t\tconst player = this.players[playerId]\n\t\t\tif (player.team && !teamsAlive.includes(player.team)) {\n\t\t\t\tteamsAlive.push(player.team)\n\t\t\t}\n\t\t}\n\t\treturn teamsAlive\n\t}\n\n\tprivate updateTimeTillStart() {\n\t\tif (this.gamePhase === "beforeGame" && this.playerCount >= this.playersForFullLobby) {\n\t\t\tthis.setStartGame(this.gameOptions.fullLobbyStartInSecs)\n\t\t}\n\t}\n\n\tprivate setStartGame(startInSecs: number) {\n\t\tconst newStartAt = api.now() + startInSecs * 1000\n\t\tthis.startGameAt = Math.min(this.startGameAt, newStartAt)\n\t\tapi.broadcastMessage(style(`Starting in ${startInSecs}s...`, this.messageColours.info))\n\t}\n\n\tprivate checkGameTransition() {\n\t\tif (this.gamePhase === "beforeGame") {\n\t\t\tconst timeLeft = this.startGameAt - api.now()\n\t\t\tif (timeLeft < 0) {\n\t\t\t\tif (this.playerCount < 2) {\n\t\t\t\t\tapi.broadcastMessage(style("Not enough players to start game", this.messageColours.error))\n\t\t\t\t\tthis.startGameAt = Infinity\n\t\t\t\t\tthis.setStartGame(this.gameOptions.emptyLobbyStartInSecs)\n\t\t\t\t} else {\n\t\t\t\t\tthis.startGame()\n\t\t\t\t}\n\t\t\t\treturn\n\t\t\t} else if (timeLeft < 5_000) {\n\t\t\t\tconst secsLeft = Math.ceil(timeLeft / 1000)\n\t\t\t\tfor (const playerId in this.players) {\n\t\t\t\t\tapi.setClientOption(playerId, "middleTextUpper", style(`Game starts in ${secsLeft} seconds`, this.messageColours.info))\n\t\t\t\t}\n\t\t\t} else {\n\t\t\t\tfor (const playerId in this.players) {\n\t\t\t\t\tapi.setClientOption(playerId, "middleTextUpper", [])\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t\tif (this.gamePhase === "gameFinished") {\n\t\t\tconst timeLeft = this.endGameAt - api.now()\n\t\t\tif (timeLeft < 0) {\n\t\t\t\tthis.resetGame(true)\n\t\t\t} else if (timeLeft < 5_000) {\n\t\t\t\tconst secsLeft = Math.ceil(timeLeft / 1000)\n\t\t\t\tfor (const playerId in this.players) {\n\t\t\t\t\tapi.setClientOption(playerId, "middleTextUpper", style(`Game ends in ${secsLeft} seconds`, this.messageColours.info))\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t}\n\n\tprivate sendRightInfoText() {\n\t\tfor (const playerId in this.players) {\n\t\t\tconst rightInfoText = this.gameOptions.getRightInfoText(this.players[playerId])\n\t\t\tif (rightInfoText) {\n\t\t\t\tapi.setClientOption(playerId, "RightInfoText", rightInfoText)\n\t\t\t}\n\t\t}\n\t}\n\n\tprivate loadMap(source: MapSource) {\n\t\tconst rect = getSourceRect(source)\n\t\tconst mapDimensions = getDimensions(rect)\n\t\tconst { low: mapLow } = getLowHigh(rect)\n\n\t\tconst { low: playAreaLow, high: playAreaHigh } = getLowHigh(this.gameOptions.playAreaRect)\n\n\t\tfor (let x = 0; x < mapDimensions.l; x += 32) {\n\t\t\tfor (let y = 0; y < mapDimensions.w; y += 32) {\n\t\t\t\tfor (let z = 0; z < mapDimensions.h; z += 32) {\n\t\t\t\t\tconst mapChunkPos: Pos = [mapLow[0] + x, mapLow[1] + y, mapLow[2] + z]\n\t\t\t\t\tconst playAreaChunkPos: Pos = [playAreaLow[0] + x, playAreaLow[1] + y, playAreaLow[2] + z]\n\n\t\t\t\t\tif (source.schematic !== undefined) {\n\t\t\t\t\t\tapi.setChunkAsSchematic(source.schematic, mapChunkPos, playAreaChunkPos)\n\t\t\t\t\t} else {\n\t\t\t\t\t\tforceLoadChunk(mapChunkPos[0], mapChunkPos[1], mapChunkPos[2], () => {\n\t\t\t\t\t\t\tapi.copyChunk(mapChunkPos, playAreaChunkPos)\n\t\t\t\t\t\t})\n\t\t\t\t\t}\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\n\t\t// Replace the rest of the play area with air\n\t\tconst mapEnd: Pos = [playAreaLow[0] + mapDimensions.l, playAreaLow[1] + mapDimensions.w, playAreaLow[2] + mapDimensions.h]\n\t\tfillOutsideWithAir(playAreaLow, playAreaHigh, mapEnd)\n\t}\n\n\tprivate startGame() {\n\t\tapi.setMaxPlayers(1, this.playersForFullLobby + this.gameOptions.maxSpectators)\n\n\t\tthis.assignTeams()\n\n\t\tthis.map = null\n\t\tif (this.gameOptions.mapVotingEnabled) {\n\t\t\tthis.map = this.mapVoter.chooseMap()\n\t\t\tthis.mapVoter.endMapVoting()\n\t\t}\n\n\t\tif (!this.map) {\n\t\t\tthis.map = getRandomItem(this.gameOptions.maps)\n\t\t}\n\n\t\t// finally: a throw here leaves the game in beforeGame, and a startingRound stuck true\n\t\t// would fade every player in the lobby it resets to\n\t\tthis.startingRound = true\n\t\ttry {\n\t\t\tfor (const playerId in this.players) {\n\t\t\t\tapi.setClientOption(playerId, "middleTextUpper", [])\n\t\t\t\tif (this.players[playerId].team) {\n\t\t\t\t\tthis.players[playerId].startPlaying()\n\t\t\t\t} else {\n\t\t\t\t\tthis.players[playerId].startSpectating()\n\t\t\t\t}\n\t\t\t}\n\n\t\t\tthis.loadMap(this.map.source)\n\n\t\t\tthis.gameStartTime = api.now()\n\t\t\tthis.gamePhase = "inGame"\n\t\t} finally {\n\t\t\tthis.startingRound = false\n\t\t}\n\t\tthis.gameOptions.onStart()\n\t}\n\n\t/**\n\t * Whether spectators should render faded. gamePhase can\'t be read directly: it only flips to\n\t * "inGame" once startGame() has started every player, and the sit-out spectators it makes\n\t * along the way need fading too.\n\t */\n\tspectatorsAreFaded(): boolean {\n\t\treturn this.startingRound || this.gamePhase === "inGame"\n\t}\n\n\tprivate assignTeams() {\n\t\tconst teamCounts = Object.fromEntries(\n\t\t\tthis.gameOptions.teams.map((team) => {\n\t\t\t\treturn [team.name, 0]\n\t\t\t}),\n\t\t) as Record<string, number>\n\t\tconst requestedPlayers: PlayerId[] = []\n\t\tconst unrequestedPlayers: PlayerId[] = []\n\t\tfor (const playerId in this.players) {\n\t\t\tconst player = this.players[playerId]\n\t\t\tif (player.requestedTeam) {\n\t\t\t\trequestedPlayers.push(playerId)\n\t\t\t} else {\n\t\t\t\tunrequestedPlayers.push(playerId)\n\t\t\t}\n\t\t}\n\t\tshuffleArray(unrequestedPlayers)\n\t\tconst playerIds = [...requestedPlayers, ...unrequestedPlayers]\n\t\tfor (const playerId of playerIds) {\n\t\t\tconst player = this.players[playerId]\n\t\t\tif (player.requestedTeam) {\n\t\t\t\tplayer.team = player.requestedTeam\n\t\t\t\tteamCounts[player.requestedTeam.name]++\n\t\t\t\tcontinue\n\t\t\t}\n\t\t\tlet smallestTeamPlayers = Infinity\n\t\t\tlet smallestTeam: TeamInfo | null = null\n\t\t\tfor (const team of this.gameOptions.teams) {\n\t\t\t\tconst numOnTeam = teamCounts[team.name]\n\t\t\t\tif (numOnTeam < smallestTeamPlayers && numOnTeam < team.maxPlayers) {\n\t\t\t\t\tsmallestTeamPlayers = numOnTeam\n\t\t\t\t\tsmallestTeam = team\n\t\t\t\t}\n\t\t\t}\n\t\t\tif (smallestTeam === null) {\n\t\t\t\tcontinue\n\t\t\t}\n\t\t\tthis.players[playerId].team = smallestTeam\n\t\t\tteamCounts[smallestTeam.name]++\n\t\t}\n\t}\n\n\t/**\n\t * Manually sets a team to win the game. Will begin the game reset timer to restart the game.#\n\t * Automatically called when there is only one team left.\n\t * @param winningTeam - The team object that won the game.\n\t */\n\tmakeTeamWin(winningTeam: TeamInfo | null) {\n\t\tif (this.gamePhase !== "inGame") {\n\t\t\treturn\n\t\t}\n\t\tthis.gamePhase = "gameFinished"\n\t\tthis.gameOptions.onFinish(winningTeam)\n\t\tthis.endGameAt = api.now() + this.gameOptions.gameResetInSecs * 1000\n\t}\n\n\tprivate resetGame(restart: boolean) {\n\t\tthis.gamePhase = "beforeGame"\n\t\tthis.startGameAt = Infinity\n\t\tthis.endGameAt = Infinity\n\t\tfor (const playerId in this.players) {\n\t\t\tconst player = this.players[playerId]\n\t\t\tplayer.startSpectating()\n\t\t\tplayer.requestedTeam = null\n\t\t\tif (restart) {\n\t\t\t\tapi.killLifeform(playerId)\n\t\t\t}\n\t\t}\n\t\tapi.setMaxPlayers(this.playersForFullLobby, this.playersForFullLobby + this.gameOptions.maxSpectators)\n\t\tthis.loadMap(this.gameOptions.lobby.source)\n\t\tif (this.gameOptions.lobby.teamPads) {\n\t\t\tthis.placeTeamPads()\n\t\t}\n\t\tthis.setStartGame(this.gameOptions.emptyLobbyStartInSecs)\n\t\tif (this.gameOptions.mapVotingEnabled) {\n\t\t\tthis.mapVoter.createMapVoting()\n\t\t}\n\t}\n\n\tonBlockStandStart(playerId: PlayerId, x: number, y: number, z: number, blockName: BlockName) {\n\t\tif (!this.gameOptions.lobby.teamPads) {\n\t\t\treturn\n\t\t}\n\t\tif (this.gamePhase !== "beforeGame") {\n\t\t\treturn\n\t\t}\n\t\tconst player = this.players[playerId]\n\t\tlet team: TeamInfo | null = null\n\t\tconst { low: playAreaLow, high: playAreaHigh } = getLowHigh(this.gameOptions.playAreaRect)\n\t\tfor (const teamPadName in this.gameOptions.lobby.teamPads) {\n\t\t\tconst teamPadInfo = this.gameOptions.lobby.teamPads[teamPadName]\n\t\t\tconst { low: rectLow, high: rectHigh } = getLowHigh(teamPadInfo.rect)\n\t\t\trectLow[0] += playAreaLow[0]\n\t\t\trectLow[1] += playAreaLow[1]\n\t\t\trectLow[2] += playAreaLow[2]\n\t\t\trectHigh[0] += playAreaLow[0]\n\t\t\trectHigh[1] += playAreaLow[1]\n\t\t\trectHigh[2] += playAreaLow[2]\n\t\t\tif (api.isInsideRect([x, y, z], rectLow, rectHigh)) {\n\t\t\t\tteam = this.gameOptions.teams.find((team) => {\n\t\t\t\t\treturn team.name === teamPadName\n\t\t\t\t})\n\t\t\t\tbreak\n\t\t\t}\n\t\t}\n\t\tif (!team) {\n\t\t\treturn\n\t\t}\n\n\t\tconst oldTeam = player.requestedTeam\n\t\tif (oldTeam === team) {\n\t\t\treturn\n\t\t}\n\n\t\tlet requestCount = 0\n\t\tfor (const playerId in this.players) {\n\t\t\tconst player = this.players[playerId]\n\t\t\tif (player.requestedTeam === team) {\n\t\t\t\trequestCount++\n\t\t\t}\n\t\t}\n\n\t\tif (player.qTextId) {\n\t\t\tapi.removeFromQueue(player.qTextId)\n\t\t}\n\t\tif (requestCount >= team.maxPlayers) {\n\t\t\tif (player.requestedTeam !== team) {\n\t\t\t\tplayer.qTextId = api.queueMiddleTextLower(playerId, style(`${team.name} team is full`, this.messageColours.error), 1000)\n\t\t\t}\n\t\t\t// Unneeded, but nice sanity check\n\t\t\tthis.placeTeamPad(team.name, true)\n\t\t\treturn\n\t\t}\n\n\t\tplayer.requestedTeam = team\n\n\t\tplayer.qTextId = api.queueMiddleTextLower(playerId, style(`${team.name} team selected`, this.messageColours.success), 1000)\n\t\tif (oldTeam !== team) {\n\t\t\tif (oldTeam) {\n\t\t\t\tthis.placeTeamPad(oldTeam.name, false)\n\t\t\t}\n\t\t\tconst isFull = requestCount + 1 >= team.maxPlayers\n\t\t\tthis.placeTeamPad(team.name, isFull)\n\t\t}\n\t}\n\n\tprivate placeTeamPad(teamName: string, full: boolean) {\n\t\tconst { low: playAreaLow } = getLowHigh(this.gameOptions.playAreaRect)\n\t\tconst { rect, emptyBlock, fullBlock } = this.gameOptions.lobby.teamPads[teamName]\n\t\t// Only force load the first chunk - assumes the rest of the chunk is already loaded\n\t\tconst { low: rectLow, high: rectHigh } = getLowHigh(rect)\n\t\tfor (let x = rectLow[0] + playAreaLow[0]; x <= rectHigh[0] + playAreaLow[0]; x += 32) {\n\t\t\tfor (let y = rectLow[1] + playAreaLow[1]; y <= rectHigh[1] + playAreaLow[1]; y += 32) {\n\t\t\t\tfor (let z = rectLow[2] + playAreaLow[2]; z <= rectHigh[2] + playAreaLow[2]; z += 32) {\n\t\t\t\t\tforceLoadChunk(x, y, z, () => {\n\t\t\t\t\t\tconst endX = Math.min(x + 31, rectHigh[0] + playAreaLow[0])\n\t\t\t\t\t\tconst endY = Math.min(y + 31, rectHigh[1] + playAreaLow[1])\n\t\t\t\t\t\tconst endZ = Math.min(z + 31, rectHigh[2] + playAreaLow[2])\n\t\t\t\t\t\tfillBox([x, y, z], [endX, endY, endZ], full ? fullBlock : emptyBlock)\n\t\t\t\t\t})\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t}\n\n\tprivate placeTeamPads() {\n\t\tfor (const teamName in this.gameOptions.lobby.teamPads) {\n\t\t\tthis.placeTeamPad(teamName, false)\n\t\t}\n\t}\n}\n\nfunction fillOutsideWithAir(low: Pos, high: Pos, copiedHigh: Pos) {\n\tfor (let axis = 0; axis < 3; axis++) {\n\t\tconst slabLow: Pos = [low[0], low[1], low[2]]\n\t\tconst slabHigh: Pos = [high[0], high[1], high[2]]\n\t\tslabLow[axis] = copiedHigh[axis] + 1\n\n\t\t// Avoid overlapping slabs (no point setting blocks already set)\n\t\tfor (let earlier = 0; earlier < axis; earlier++) {\n\t\t\tslabHigh[earlier] = Math.min(copiedHigh[earlier], high[earlier])\n\t\t}\n\n\t\tif (slabLow[0] <= slabHigh[0] && slabLow[1] <= slabHigh[1] && slabLow[2] <= slabHigh[2]) {\n\t\t\tfillBox(slabLow, slabHigh, "Air")\n\t\t}\n\t}\n}\n\nfunction fillBox(pos1: Pos, pos2: Pos, block: BlockName) {\n\t// api.setBlockRect caps at 360 blocks; slice along Z, then Y, then X so each call stays under the cap.\n\tconst maxRectVol = 360\n\tconst {\n\t\tlow: [x1, y1, z1],\n\t\thigh: [x2, y2, z2],\n\t} = getLowHigh([pos1, pos2])\n\tconst zSizeFull = z2 - z1 + 1\n\tconst zStep = Math.min(zSizeFull, maxRectVol)\n\tfor (let z = z1; z <= z2; z += zStep) {\n\t\tconst zEnd = Math.min(z2, z + zStep - 1)\n\t\tconst zSize = zEnd - z + 1\n\t\tconst yStep = Math.max(1, Math.floor(maxRectVol / zSize))\n\t\tfor (let y = y1; y <= y2; y += yStep) {\n\t\t\tconst yEnd = Math.min(y2, y + yStep - 1)\n\t\t\tconst yz = (yEnd - y + 1) * zSize\n\t\t\tconst xStep = Math.max(1, Math.floor(maxRectVol / yz))\n\t\t\tfor (let x = x1; x <= x2; x += xStep) {\n\t\t\t\tconst xEnd = Math.min(x2, x + xStep - 1)\n\t\t\t\tapi.setBlockRect([x, y, z], [xEnd, yEnd, zEnd], block)\n\t\t\t}\n\t\t}\n\t}\n}\n',
          "SessionBasedPlayer.ts": 'import { BaseTeamInfo, BaseMapInfo } from "./types"\nimport { ChatTags, PlayerId, Pos, RecursiveReadonly } from "@bloxd"\nimport { SessionBasedGame } from "./SessionBasedGame"\nimport { style, getLowHigh } from "./helpers"\n\n/** Opacity a spectator renders at. Only other spectators can see them, and themselves in third person. */\nexport const SPECTATOR_OPACITY = 0.5\n\nexport class SessionBasedPlayer<TeamInfo extends BaseTeamInfo, MapInfo extends BaseMapInfo<TeamInfo>> {\n\tisSpectating = true\n\tteam: TeamInfo | null = null\n\trequestedTeam: TeamInfo | null = null\n\tqTextId: string | null = null\n\n\tconstructor(\n\t\treadonly playerId: PlayerId,\n\t\treadonly game: SessionBasedGame<TeamInfo, MapInfo, SessionBasedPlayer<TeamInfo, MapInfo>>,\n\t) {\n\t\tapi.setPlayerGamemode(this.playerId, "survival")\n\t\tthis.startSpectating()\n\t\tthis.spawn()\n\t}\n\n\tprivate spawn() {\n\t\tconst spawnPosition = this.onRespawnRequest()\n\t\tif (spawnPosition) {\n\t\t\tapi.setPosition(this.playerId, spawnPosition)\n\t\t}\n\t}\n\n\t/**\n\t * Sets the player as playing the game, setting their health, shields, and other settings.\n\t * Automatically called at the start of a game for players assigned to a team.\n\t */\n\tstartPlaying() {\n\t\tthis.isSpectating = false\n\t\tconst maxHealth = api.getClientOption(this.playerId, "maxHealth")\n\t\tapi.setHealth(this.playerId, maxHealth)\n\t\tif (api.getHealth(this.playerId) !== null) {\n\t\t\tapi.setShieldAmount(this.playerId, api.getClientOption(this.playerId, "initialShield"))\n\t\t}\n\t\tapi.setClientOptions(this.playerId, {\n\t\t\tinitialHealth: maxHealth,\n\t\t\tcreative: false,\n\t\t\tcanAltAction: true,\n\t\t\tcanChange: false,\n\t\t\tuseFullInventory: true,\n\t\t\tcantBreakError: "",\n\t\t\tcantBuildError: [{ str: { translationKey: "general:cantBuildHere" } }],\n\t\t\tcanPickUpItems: true,\n\t\t\tautoRespawn: true,\n\t\t\tsecsToRespawn: 5,\n\t\t\trespawnButtonText: "sessionBasedGame:spectate",\n\t\t\tusePlayAgainButton: true,\n\t\t})\n\t\tthis.updateOtherEntitySettings(false)\n\t\tapi.setCanChangeBlockRect(this.playerId, ...this.game.gameOptions.playAreaRect)\n\n\t\tif (this.team) {\n\t\t\tapi.setTargetedPlayerSettingForEveryone(this.playerId, "killfeedColour", this.team.colour, true)\n\t\t\tapi.setTargetedPlayerSettingForEveryone(this.playerId, "colorInLobbyLeaderboard", this.team.colour, true)\n\t\t}\n\n\t\tthis.spawn()\n\t}\n\n\t/**\n\t * Sets the player as spectating the game, resetting their health, shields, and other settings.\n\t * Automatically called at the start of a game for players not assigned to a team.\n\t * Call this function to turn a player into a spectator (for example, once they die).\n\t */\n\tstartSpectating() {\n\t\tthis.isSpectating = true\n\t\tthis.team = null\n\t\tconst isBeforeGame = this.game.gamePhase === "beforeGame"\n\t\tapi.setClientOptions(this.playerId, {\n\t\t\tcreative: !isBeforeGame,\n\t\t\tuseFullInventory: false,\n\t\t\tcanAltAction: isBeforeGame,\n\t\t\tcanChange: false,\n\t\t\tcantBreakError: [\n\t\t\t\t{ str: { translationKey: "sessionBasedGame:cantChangeBlocksWhileSpectating" }, style: { colour: this.game.messageColours.error } },\n\t\t\t],\n\t\t\tcantBuildError: [\n\t\t\t\t{ str: { translationKey: "sessionBasedGame:cantChangeBlocksWhileSpectating" }, style: { colour: this.game.messageColours.error } },\n\t\t\t],\n\t\t\tcanPickUpItems: true,\n\t\t\tautoRespawn: false,\n\t\t\tsecsToRespawn: 3,\n\t\t\trespawnButtonText: isBeforeGame ? "general:respawn" : "sessionBasedGame:spectate",\n\t\t\tusePlayAgainButton: true,\n\t\t})\n\t\tapi.setEveryoneSettingForPlayer(this.playerId, "canSee", true)\n\t\tthis.updateOtherEntitySettings(true)\n\t\tapi.resetCanChangeBlockRect(this.playerId, ...this.game.gameOptions.playAreaRect)\n\n\t\tfor (const effect of api.getEffects(this.playerId)) {\n\t\t\tapi.removeEffect(this.playerId, effect)\n\t\t}\n\t\tapi.clearInventory(this.playerId)\n\n\t\tthis.game.checkWin()\n\t}\n\n\tprivate updateOtherEntitySettings(isSpectating: boolean) {\n\t\t// pass in isSpectating in case games set it after calling startPlaying()/startSpectating()\n\t\t// Lobby players all carry isSpectating, so fading there would grey out the whole lobby\n\t\tconst fadeSpectators = this.game.spectatorsAreFaded()\n\t\tfor (const player of this.game.getPlayers()) {\n\t\t\tconst canAttack = !isSpectating && !player.isSpectating && (this.playerId === player.playerId || this.team !== player.team)\n\t\t\tapi.setOtherEntitySetting(this.playerId, player.playerId, "canAttack", canAttack)\n\t\t\tapi.setOtherEntitySetting(player.playerId, this.playerId, "canAttack", canAttack)\n\n\t\t\tapi.setOtherEntitySetting(this.playerId, player.playerId, "canSee", isSpectating || !player.isSpectating)\n\t\t\tapi.setOtherEntitySetting(player.playerId, this.playerId, "canSee", player.isSpectating || !isSpectating)\n\n\t\t\t// Our own fade, and the only place it gets cleared again. Also covers the self pair.\n\t\t\tapi.setOtherEntitySetting(player.playerId, this.playerId, "opacity", fadeSpectators && isSpectating ? SPECTATOR_OPACITY : 1)\n\t\t\t// Others are only ever faded in, never cleared, so an opacity a game set for its own\n\t\t\t// effect survives until that player\'s own startPlaying clears it.\n\t\t\tif (player.playerId !== this.playerId && fadeSpectators && player.isSpectating) {\n\t\t\t\tapi.setOtherEntitySetting(this.playerId, player.playerId, "opacity", SPECTATOR_OPACITY)\n\t\t\t}\n\t\t}\n\t}\n\n\tonMessage(): ChatTags {\n\t\tif (this.game.gamePhase === "beforeGame") {\n\t\t\treturn undefined\n\t\t}\n\t\tconst team = this.team\n\t\tif (!team) {\n\t\t\treturn [\n\t\t\t\tstyle("[", this.game.messageColours.info),\n\t\t\t\tstyle({ translationKey: "sessionBasedGame:spectator" }, this.game.messageColours.info),\n\t\t\t\tstyle("]", this.game.messageColours.info),\n\t\t\t]\n\t\t}\n\n\t\treturn [style("[", team.colour), style(team.name, team.colour), style("]", team.colour)]\n\t}\n\n\tonRespawnRequest(): Pos | undefined {\n\t\tlet spawnArea: RecursiveReadonly<{ spawn: Pos; spawnFacing: Pos }> | undefined\n\t\tif (this.team && this.game.map?.teams[this.team.name]) {\n\t\t\tspawnArea = this.game.map.teams[this.team.name]\n\t\t} else if (this.game.gameOptions.lobby) {\n\t\t\tspawnArea = this.game.gameOptions.lobby\n\t\t} else {\n\t\t\treturn undefined\n\t\t}\n\n\t\tconst { spawn, spawnFacing } = spawnArea\n\t\tconst { low: playAreaLow } = getLowHigh(this.game.gameOptions.playAreaRect)\n\t\tconst playAreaSpawn: Pos = [playAreaLow[0] + spawn[0] + 0.5, playAreaLow[1] + spawn[1] + 0.5, playAreaLow[2] + spawn[2] + 0.5]\n\t\tapi.setVelocity(this.playerId, 0, 0, 0)\n\t\tapi.setCameraDirection(this.playerId, spawnFacing as Pos)\n\t\treturn playAreaSpawn\n\t}\n\n\t/**\n\t * Gets the position of the player relative to the play area.\n\t * @returns The position of the player relative to the play area.\n\t */\n\tgetPositionInPlayArea(): Pos {\n\t\tconst { low: playAreaLow } = getLowHigh(this.game.gameOptions.playAreaRect)\n\t\tconst position = api.getPosition(this.playerId)\n\t\treturn [position[0] - playAreaLow[0], position[1] - playAreaLow[1], position[2] - playAreaLow[2]]\n\t}\n}\n',
          "helpers.ts": 'import { CustomTextStyling, Pos, RecursiveReadonly, TranslatedText } from "@bloxd"\nimport { MapSource, MaybeRecursiveReadonly } from "./types"\n\nexport function style(msg: string | TranslatedText, colour: string): CustomTextStyling {\n\treturn [{ str: msg, style: { colour: colour } }]\n}\n\nexport function roundOutwardsToChunkBoundary(rect: RecursiveReadonly<[Pos, Pos]>): [Pos, Pos] {\n\tconst { low, high } = getLowHigh(rect)\n\treturn [\n\t\t[Math.floor(low[0] / 32) * 32, Math.floor(low[1] / 32) * 32, Math.floor(low[2] / 32) * 32],\n\t\t[Math.ceil(high[0] / 32) * 32, Math.ceil(high[1] / 32) * 32, Math.ceil(high[2] / 32) * 32],\n\t]\n}\n\nexport function getDimensions(rect: MaybeRecursiveReadonly<[Pos, Pos]>): { l: number; w: number; h: number } {\n\tconst [pos1, pos2] = rect\n\treturn {\n\t\tl: Math.abs(pos1[0] - pos2[0]),\n\t\tw: Math.abs(pos1[1] - pos2[1]),\n\t\th: Math.abs(pos1[2] - pos2[2]),\n\t}\n}\n\nexport function getLowHigh(rect: RecursiveReadonly<[Pos, Pos]>): { low: Pos; high: Pos } {\n\tconst [pos1, pos2] = rect\n\treturn {\n\t\tlow: [Math.min(pos1[0], pos2[0]), Math.min(pos1[1], pos2[1]), Math.min(pos1[2], pos2[2])],\n\t\thigh: [Math.max(pos1[0], pos2[0]), Math.max(pos1[1], pos2[1]), Math.max(pos1[2], pos2[2])],\n\t}\n}\n\nexport function getSourceRect(source: MapSource): [Pos, Pos] {\n\tif (source.schematic !== undefined) {\n\t\treturn roundOutwardsToChunkBoundary([[0, 0, 0], api.getSchematicDimensions(source.schematic)])\n\t}\n\treturn roundOutwardsToChunkBoundary(source.rect)\n}\n\nexport function preloadRect(rect: MaybeRecursiveReadonly<[Pos, Pos]>) {\n\t// Preloads the chunks in the rectangle to ensure they\'re loaded when the game starts\n\tconst { low: mapLow, high: mapHigh } = getLowHigh(rect)\n\tfor (let x = mapLow[0]; x < mapHigh[0]; x += 32) {\n\t\tfor (let y = mapLow[1]; y < mapHigh[1]; y += 32) {\n\t\t\tfor (let z = mapLow[2]; z < mapHigh[2]; z += 32) {\n\t\t\t\tapi.getBlock(x, y, z)\n\t\t\t}\n\t\t}\n\t}\n}\n\nfunction numToTwoDigStr(n: number) {\n\treturn (n < 10 ? "0" : "") + n\n}\n\n/**\n * Display ms in format mm:ss, or hh:mm:ss if hours > 0\n * ss is rounded up (i.e. if ms > 0 then ss always 01 or more)\n */\nexport function displayMs(ms: number): string {\n\tconst totalS = Math.ceil(ms / 1000) // Round up to nearest second\n\tconst hours = Math.floor(totalS / 3600)\n\tconst min = Math.floor((totalS % 3600) / 60)\n\tconst sec = Math.floor(totalS % 60)\n\tif (hours > 0) {\n\t\treturn `${hours}:${numToTwoDigStr(min)}:${numToTwoDigStr(sec)}`\n\t}\n\treturn `${min}:${numToTwoDigStr(sec)}`\n}\n',
          "index.ts": 'import { ChatTags, CustomTextStyling, EntityId, PlayerId, Pos, TranslatedText, RecursiveReadonly, BlockName } from "@bloxd"\nimport { BaseTeamInfo, BaseMapInfo, MapSource, SessionBasedGameSetupOptions } from "./types"\nimport { SessionBasedPlayer } from "./SessionBasedPlayer"\nimport { SessionBasedGame } from "./SessionBasedGame"\nimport { roundOutwardsToChunkBoundary, getDimensions, preloadRect, style, getSourceRect } from "./helpers"\n\nlet game: SessionBasedGame<any, any, SessionBasedPlayer<any, any>> | null = null\n\nonPlayerJoin = (playerId: PlayerId) => {\n\tgame?.onPlayerJoin(playerId)\n}\n\nonPlayerLeave = (playerId: PlayerId) => {\n\tgame?.onPlayerLeave(playerId)\n}\n\ntick = () => {\n\tgame?.tick()\n}\n\nonPlayerChat = (playerId: PlayerId, message: string) => {\n\treturn game?.onPlayerChat(playerId, message)\n}\n\nonMobKilledPlayer = (mobId: EntityId, playerId: PlayerId) => {\n\tgame?.onPlayerDie(playerId)\n}\n\nonPlayerKilledOtherPlayer = (killerId: PlayerId, victimId: PlayerId) => {\n\tgame?.onPlayerDie(victimId)\n}\n\nonRespawnRequest = (playerId: PlayerId) => {\n\treturn game?.getPlayer(playerId)?.onRespawnRequest()\n}\n\nonPlayerBoughtShopItem = (playerId: PlayerId, categoryKey: string, itemKey: string) => {\n\tgame?.onPlayerBoughtShopItem(playerId, categoryKey, itemKey)\n}\n\nonBlockStandStart = (playerId: PlayerId, x: number, y: number, z: number, blockName: BlockName) => {\n\tgame?.onBlockStandStart(playerId, x, y, z, blockName)\n}\n\n/**\n * Create a new SessionBasedGame.\n * @param opts - The options for the game.\n * @param opts.teams - The teams for the game. This should include the team name, max players for this team, and hex colour.\n * @param opts.maps - The maps for the game. This should include the map name, source rectangle or schematic path, and the spawn positions for each team.\n * @param opts.lobby - The lobby area. This should include the source rectangle or schematic path, spawn info, and team pads for team choosing.\n * @param opts.playAreaRect - The play area rectangle. These will be rounded outwards to the nearest chunk boundary\n * @param opts.maxSpectators - The maximum number of spectators allowed in the game.\n * @param opts.emptyLobbyStartInSecs - The number of seconds to wait for the game to start when the lobby isn\'t full yet.\n * @param opts.fullLobbyStartInSecs - The number of seconds to wait for the game to start when the lobby is full.\n * @param opts.gameResetInSecs - The number of seconds to wait before resetting the game after the game finishes.\n * @param opts.mapVotingEnabled - Whether to enable map voting.\n * @param opts.onStart - The function to call when the game starts.\n * @param opts.onFinish - The function to call when the game finishes.\n * @param opts.getRightInfoText - The function to call to get the RightInfoText for the game.\n * @param opts.playerConstructor - The constructor for the player class. This should be a class that extends SessionBasedPlayer\n * @returns The game instance\n */\nexport function createGame<TeamInfo extends BaseTeamInfo, MapInfo extends BaseMapInfo<TeamInfo>, Player extends SessionBasedPlayer<TeamInfo, MapInfo>>(\n\topts: SessionBasedGameSetupOptions<TeamInfo, MapInfo, Player>,\n): SessionBasedGame<TeamInfo, MapInfo, Player> {\n\tif (game) {\n\t\tthrow new Error("Game already setup")\n\t}\n\tif (opts.maps.length === 0) {\n\t\tthrow new Error("No maps provided")\n\t}\n\tif (opts.teams.length < 2) {\n\t\tthrow new Error(`At least 2 teams are required (got ${opts.teams.length})`)\n\t}\n\tfor (const team of opts.teams) {\n\t\tif (team.maxPlayers < 1) {\n\t\t\tthrow new Error(`Team ${team.name} max players must be at least 1`)\n\t\t}\n\t}\n\topts.playAreaRect = roundOutwardsToChunkBoundary(opts.playAreaRect)\n\tconst playAreaDimensions = getDimensions(opts.playAreaRect)\n\tpreloadRect(opts.playAreaRect)\n\n\tconst newMaps = []\n\tfor (const map of opts.maps) {\n\t\tconst newMap: MapInfo = {\n\t\t\t...map,\n\t\t\tsource: map.source.schematic !== undefined ? map.source : { ...map.source, rect: roundOutwardsToChunkBoundary(map.source.rect) },\n\t\t}\n\t\tconst mapDimensions = getDimensions(getSourceRect(newMap.source))\n\t\tif (mapDimensions.l > playAreaDimensions.l || mapDimensions.w > playAreaDimensions.w || mapDimensions.h > playAreaDimensions.h) {\n\t\t\tthrow new Error(`Map ${map.name} is too large for play area`)\n\t\t}\n\n\t\t// preload the map chunks\n\t\tif (newMap.source.schematic === undefined) {\n\t\t\tpreloadRect(newMap.source.rect)\n\t\t}\n\t\tnewMaps.push(newMap)\n\t}\n\topts.maps = newMaps\n\n\topts.lobby = {\n\t\t...opts.lobby,\n\t\tsource:\n\t\t\topts.lobby.source.schematic !== undefined\n\t\t\t\t? opts.lobby.source\n\t\t\t\t: ({ ...opts.lobby.source, rect: roundOutwardsToChunkBoundary(opts.lobby.source.rect) } as MapSource),\n\t}\n\tconst lobbyDimensions = getDimensions(getSourceRect(opts.lobby.source))\n\tif (lobbyDimensions.l > playAreaDimensions.l || lobbyDimensions.w > playAreaDimensions.w || lobbyDimensions.h > playAreaDimensions.h) {\n\t\tthrow new Error(`Lobby is too large for play area`)\n\t}\n\tif (opts.lobby.source.schematic === undefined) {\n\t\tpreloadRect(opts.lobby.source.rect)\n\t}\n\n\tconst newGame = new SessionBasedGame<TeamInfo, MapInfo, Player>({\n\t\t...defaultSessionBasedGameSetupOptions,\n\t\t...opts,\n\t} as Required<SessionBasedGameSetupOptions<TeamInfo, MapInfo, Player>>)\n\tgame = newGame\n\treturn newGame\n}\n\nconst defaultSessionBasedGameSetupOptions: Required<\n\tOmit<\n\t\tSessionBasedGameSetupOptions<BaseTeamInfo, BaseMapInfo<BaseTeamInfo>, SessionBasedPlayer<BaseTeamInfo, BaseMapInfo<BaseTeamInfo>>>,\n\t\t"teams" | "maps" | "playAreaRect" | "lobby"\n\t>\n> = {\n\tmaxSpectators: 10,\n\temptyLobbyStartInSecs: 60,\n\tfullLobbyStartInSecs: 10,\n\tgameResetInSecs: 10,\n\tmapVotingEnabled: false,\n\tonStart: () => {\n\t\tapi.broadcastMessage(style("Game started", game?.messageColours.success))\n\t},\n\tonFinish: (winningTeam: BaseTeamInfo) => {\n\t\tapi.broadcastMessage(style(`${winningTeam.name} won the game`, winningTeam.colour))\n\t},\n\tgetRightInfoText: (player: SessionBasedPlayer<BaseTeamInfo, BaseMapInfo<BaseTeamInfo>>) => {\n\t\treturn game?.getStartingInText()\n\t},\n\tplayerConstructor: SessionBasedPlayer,\n}\n\nexport { SessionBasedGame, SessionBasedPlayer, BaseTeamInfo, BaseMapInfo, SessionBasedGameSetupOptions }\n\nexport type { MapSource } from "./types"\n',
          "types.ts": 'import { BlockName, CustomTextStyling, Pos, RecursiveReadonly } from "@bloxd"\nimport { SessionBasedPlayer } from "./SessionBasedPlayer"\n\nexport type BaseTeamInfo = RecursiveReadonly<{\n\tname: string\n\tmaxPlayers: number\n\tcolour: string\n}>\n\n/** A world rectangle (rounded outwards to chunk boundaries), or a project schematic path. */\nexport type MapSource = RecursiveReadonly<{ rect: [Pos, Pos]; schematic?: never } | { schematic: string; rect?: never }>\n\nexport type BaseMapInfo<TeamInfo extends BaseTeamInfo> = RecursiveReadonly<{\n\t/** The name of the map */\n\tname: string\n\t/** The icon of the map - used in the Map Voting Shop UI */\n\ticon: string\n\tsource: MapSource\n}> & {\n\t// Kept out of the RecursiveReadonly above and made readonly explicitly: TypeScript can\'t index a\n\t// Record keyed by a still-generic type (TeamInfo["name"]) once RecursiveReadonly\'s recursive\n\t// conditional type has wrapped it.\n\treadonly teams: Record<\n\t\tTeamInfo["name"],\n\t\tRecursiveReadonly<{\n\t\t\tspawn: Pos // offset from the lowest corner of the map (after rounding outwards)\n\t\t\tspawnFacing: Pos\n\t\t}>\n\t>\n}\n\ntype Constructor<T> = new (...args: any[]) => T\n\nexport type TeamPadInfo = RecursiveReadonly<{\n\trect: [Pos, Pos]\n\temptyBlock: BlockName\n\tfullBlock: BlockName\n}>\n\nexport type SessionBasedGameSetupOptions<\n\tTeamInfo extends BaseTeamInfo,\n\tMapInfo extends BaseMapInfo<TeamInfo>,\n\tPlayer extends SessionBasedPlayer<TeamInfo, MapInfo>,\n> = {\n\tteams: readonly TeamInfo[]\n\tmaps: readonly MapInfo[]\n\t/** Lobby area information */\n\tlobby: RecursiveReadonly<{\n\t\tsource: MapSource\n\t\tspawn: Pos\n\t\tspawnFacing: Pos\n\t}> & {\n\t\t// Kept out of the RecursiveReadonly above: TeamPadInfo is already recursively readonly on its\n\t\t// own, and re-wrapping a Record keyed by a still-generic type (TeamInfo["name"]) breaks indexing.\n\t\t/** Block coordinates representing the start and the end of the team pads. Offset from the lowest corner of the map (after rounding outwards). If not provided, team choosing will be disabled. */\n\t\tteamPads?: Record<TeamInfo["name"], TeamPadInfo>\n\t}\n\t/** Block coordinates representing the start and the end of the play area. These will be rounded outwards to the nearest chunk boundary */\n\tplayAreaRect: readonly [Pos, Pos]\n\t/** Maximum number of spectators allowed in the game */\n\tmaxSpectators?: number\n\t/** The number of seconds to wait before resetting the game after the game finishes */\n\temptyLobbyStartInSecs?: number\n\t/** The number of seconds to wait before starting the game when the lobby is full */\n\tfullLobbyStartInSecs?: number\n\t/** The number of seconds to wait before resetting the game after the game finishes */\n\tgameResetInSecs?: number\n\t/** Enable Map Voting - If enabled, players will be able to vote for the next map to play. */\n\tmapVotingEnabled?: boolean\n\t/** Function to call when the game starts */\n\tonStart?: () => void\n\t/** Function to call when the game finishes */\n\tonFinish?: (winningTeam: TeamInfo) => void\n\t/** Function to get the RightInfoText for a player */\n\tgetRightInfoText?: (player: SessionBasedPlayer<TeamInfo, MapInfo>) => string | CustomTextStyling | null\n\t/** The constructor for the player class. This should be a class that extends SessionBasedPlayer */\n\tplayerConstructor?: Constructor<Player>\n}\n\nexport type MaybeRecursiveReadonly<T> = RecursiveReadonly<T> | T\n'
        },
        dependencies: ["helpers"],
        bundledSource: 'var __defProp = Object.defineProperty;\nvar __getOwnPropDesc = Object.getOwnPropertyDescriptor;\nvar __getOwnPropNames = Object.getOwnPropertyNames;\nvar __hasOwnProp = Object.prototype.hasOwnProperty;\nvar __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;\nvar __export = (target, all) => {\n  for (var name in all)\n    __defProp(target, name, { get: all[name], enumerable: true });\n};\nvar __copyProps = (to, from, except, desc) => {\n  if (from && typeof from === "object" || typeof from === "function") {\n    for (let key of __getOwnPropNames(from))\n      if (!__hasOwnProp.call(to, key) && key !== except)\n        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });\n  }\n  return to;\n};\nvar __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);\nvar __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);\n\n// world-code-plugin:index.ts\nvar index_exports = {};\n__export(index_exports, {\n  SessionBasedGame: () => SessionBasedGame2,\n  SessionBasedPlayer: () => SessionBasedPlayer,\n  createGame: () => createGame\n});\nmodule.exports = __toCommonJS(index_exports);\n\n// world-code-plugin:helpers.ts\nfunction style(msg, colour) {\n  return [{ str: msg, style: { colour } }];\n}\nfunction roundOutwardsToChunkBoundary(rect) {\n  const { low, high } = getLowHigh(rect);\n  return [\n    [Math.floor(low[0] / 32) * 32, Math.floor(low[1] / 32) * 32, Math.floor(low[2] / 32) * 32],\n    [Math.ceil(high[0] / 32) * 32, Math.ceil(high[1] / 32) * 32, Math.ceil(high[2] / 32) * 32]\n  ];\n}\nfunction getDimensions(rect) {\n  const [pos1, pos2] = rect;\n  return {\n    l: Math.abs(pos1[0] - pos2[0]),\n    w: Math.abs(pos1[1] - pos2[1]),\n    h: Math.abs(pos1[2] - pos2[2])\n  };\n}\nfunction getLowHigh(rect) {\n  const [pos1, pos2] = rect;\n  return {\n    low: [Math.min(pos1[0], pos2[0]), Math.min(pos1[1], pos2[1]), Math.min(pos1[2], pos2[2])],\n    high: [Math.max(pos1[0], pos2[0]), Math.max(pos1[1], pos2[1]), Math.max(pos1[2], pos2[2])]\n  };\n}\nfunction getSourceRect(source) {\n  if (source.schematic !== void 0) {\n    return roundOutwardsToChunkBoundary([[0, 0, 0], api.getSchematicDimensions(source.schematic)]);\n  }\n  return roundOutwardsToChunkBoundary(source.rect);\n}\nfunction preloadRect(rect) {\n  const { low: mapLow, high: mapHigh } = getLowHigh(rect);\n  for (let x = mapLow[0]; x < mapHigh[0]; x += 32) {\n    for (let y = mapLow[1]; y < mapHigh[1]; y += 32) {\n      for (let z = mapLow[2]; z < mapHigh[2]; z += 32) {\n        api.getBlock(x, y, z);\n      }\n    }\n  }\n}\nfunction numToTwoDigStr(n) {\n  return (n < 10 ? "0" : "") + n;\n}\nfunction displayMs(ms) {\n  const totalS = Math.ceil(ms / 1e3);\n  const hours = Math.floor(totalS / 3600);\n  const min = Math.floor(totalS % 3600 / 60);\n  const sec = Math.floor(totalS % 60);\n  if (hours > 0) {\n    return `${hours}:${numToTwoDigStr(min)}:${numToTwoDigStr(sec)}`;\n  }\n  return `${min}:${numToTwoDigStr(sec)}`;\n}\n\n// world-code-plugin:SessionBasedPlayer.ts\nvar SPECTATOR_OPACITY = 0.5;\nvar SessionBasedPlayer = class {\n  constructor(playerId, game2) {\n    __publicField(this, "playerId", playerId);\n    __publicField(this, "game", game2);\n    __publicField(this, "isSpectating", true);\n    __publicField(this, "team", null);\n    __publicField(this, "requestedTeam", null);\n    __publicField(this, "qTextId", null);\n    api.setPlayerGamemode(this.playerId, "survival");\n    this.startSpectating();\n    this.spawn();\n  }\n  spawn() {\n    const spawnPosition = this.onRespawnRequest();\n    if (spawnPosition) {\n      api.setPosition(this.playerId, spawnPosition);\n    }\n  }\n  /**\n   * Sets the player as playing the game, setting their health, shields, and other settings.\n   * Automatically called at the start of a game for players assigned to a team.\n   */\n  startPlaying() {\n    this.isSpectating = false;\n    const maxHealth = api.getClientOption(this.playerId, "maxHealth");\n    api.setHealth(this.playerId, maxHealth);\n    if (api.getHealth(this.playerId) !== null) {\n      api.setShieldAmount(this.playerId, api.getClientOption(this.playerId, "initialShield"));\n    }\n    api.setClientOptions(this.playerId, {\n      initialHealth: maxHealth,\n      creative: false,\n      canAltAction: true,\n      canChange: false,\n      useFullInventory: true,\n      cantBreakError: "",\n      cantBuildError: [{ str: { translationKey: "general:cantBuildHere" } }],\n      canPickUpItems: true,\n      autoRespawn: true,\n      secsToRespawn: 5,\n      respawnButtonText: "sessionBasedGame:spectate",\n      usePlayAgainButton: true\n    });\n    this.updateOtherEntitySettings(false);\n    api.setCanChangeBlockRect(this.playerId, ...this.game.gameOptions.playAreaRect);\n    if (this.team) {\n      api.setTargetedPlayerSettingForEveryone(this.playerId, "killfeedColour", this.team.colour, true);\n      api.setTargetedPlayerSettingForEveryone(this.playerId, "colorInLobbyLeaderboard", this.team.colour, true);\n    }\n    this.spawn();\n  }\n  /**\n   * Sets the player as spectating the game, resetting their health, shields, and other settings.\n   * Automatically called at the start of a game for players not assigned to a team.\n   * Call this function to turn a player into a spectator (for example, once they die).\n   */\n  startSpectating() {\n    this.isSpectating = true;\n    this.team = null;\n    const isBeforeGame = this.game.gamePhase === "beforeGame";\n    api.setClientOptions(this.playerId, {\n      creative: !isBeforeGame,\n      useFullInventory: false,\n      canAltAction: isBeforeGame,\n      canChange: false,\n      cantBreakError: [\n        { str: { translationKey: "sessionBasedGame:cantChangeBlocksWhileSpectating" }, style: { colour: this.game.messageColours.error } }\n      ],\n      cantBuildError: [\n        { str: { translationKey: "sessionBasedGame:cantChangeBlocksWhileSpectating" }, style: { colour: this.game.messageColours.error } }\n      ],\n      canPickUpItems: true,\n      autoRespawn: false,\n      secsToRespawn: 3,\n      respawnButtonText: isBeforeGame ? "general:respawn" : "sessionBasedGame:spectate",\n      usePlayAgainButton: true\n    });\n    api.setEveryoneSettingForPlayer(this.playerId, "canSee", true);\n    this.updateOtherEntitySettings(true);\n    api.resetCanChangeBlockRect(this.playerId, ...this.game.gameOptions.playAreaRect);\n    for (const effect of api.getEffects(this.playerId)) {\n      api.removeEffect(this.playerId, effect);\n    }\n    api.clearInventory(this.playerId);\n    this.game.checkWin();\n  }\n  updateOtherEntitySettings(isSpectating) {\n    const fadeSpectators = this.game.spectatorsAreFaded();\n    for (const player of this.game.getPlayers()) {\n      const canAttack = !isSpectating && !player.isSpectating && (this.playerId === player.playerId || this.team !== player.team);\n      api.setOtherEntitySetting(this.playerId, player.playerId, "canAttack", canAttack);\n      api.setOtherEntitySetting(player.playerId, this.playerId, "canAttack", canAttack);\n      api.setOtherEntitySetting(this.playerId, player.playerId, "canSee", isSpectating || !player.isSpectating);\n      api.setOtherEntitySetting(player.playerId, this.playerId, "canSee", player.isSpectating || !isSpectating);\n      api.setOtherEntitySetting(player.playerId, this.playerId, "opacity", fadeSpectators && isSpectating ? SPECTATOR_OPACITY : 1);\n      if (player.playerId !== this.playerId && fadeSpectators && player.isSpectating) {\n        api.setOtherEntitySetting(this.playerId, player.playerId, "opacity", SPECTATOR_OPACITY);\n      }\n    }\n  }\n  onMessage() {\n    if (this.game.gamePhase === "beforeGame") {\n      return void 0;\n    }\n    const team = this.team;\n    if (!team) {\n      return [\n        style("[", this.game.messageColours.info),\n        style({ translationKey: "sessionBasedGame:spectator" }, this.game.messageColours.info),\n        style("]", this.game.messageColours.info)\n      ];\n    }\n    return [style("[", team.colour), style(team.name, team.colour), style("]", team.colour)];\n  }\n  onRespawnRequest() {\n    let spawnArea;\n    if (this.team && this.game.map?.teams[this.team.name]) {\n      spawnArea = this.game.map.teams[this.team.name];\n    } else if (this.game.gameOptions.lobby) {\n      spawnArea = this.game.gameOptions.lobby;\n    } else {\n      return void 0;\n    }\n    const { spawn, spawnFacing } = spawnArea;\n    const { low: playAreaLow } = getLowHigh(this.game.gameOptions.playAreaRect);\n    const playAreaSpawn = [playAreaLow[0] + spawn[0] + 0.5, playAreaLow[1] + spawn[1] + 0.5, playAreaLow[2] + spawn[2] + 0.5];\n    api.setVelocity(this.playerId, 0, 0, 0);\n    api.setCameraDirection(this.playerId, spawnFacing);\n    return playAreaSpawn;\n  }\n  /**\n   * Gets the position of the player relative to the play area.\n   * @returns The position of the player relative to the play area.\n   */\n  getPositionInPlayArea() {\n    const { low: playAreaLow } = getLowHigh(this.game.gameOptions.playAreaRect);\n    const position = api.getPosition(this.playerId);\n    return [position[0] - playAreaLow[0], position[1] - playAreaLow[1], position[2] - playAreaLow[2]];\n  }\n};\n\n// world-code-plugin:MapVoter.ts\nvar import_helpers2 = require("@plugins/helpers");\nvar MAP_VOTING_CATEGORY = "__SBG_MAP_VOTING__";\nvar MAP_VOTING_ITEM_PREFIX = "__SBG_MAP_";\nvar MAP_OPTION_COUNT = 4;\nvar MapVoter = class {\n  constructor(maps, players) {\n    __publicField(this, "maps", maps);\n    __publicField(this, "players", players);\n    __publicField(this, "possibleMapOptions", []);\n    __publicField(this, "mapVotes", {});\n    __publicField(this, "mapVotingActive", false);\n  }\n  createMapVoting() {\n    if (this.mapVotingActive) {\n      return;\n    }\n    this.mapVotingActive = true;\n    api.configureShopCategory(MAP_VOTING_CATEGORY, {\n      customTitle: "Map Voting",\n      sortPriority: 0.5\n    });\n    for (const map of this.possibleMapOptions) {\n      api.deleteShopItem(MAP_VOTING_CATEGORY, `${MAP_VOTING_ITEM_PREFIX}${map.name}`);\n    }\n    const possibleOptions = this.maps.slice();\n    (0, import_helpers2.shuffleArray)(possibleOptions);\n    this.possibleMapOptions = possibleOptions.slice(0, MAP_OPTION_COUNT);\n    for (const map of this.possibleMapOptions) {\n      api.createShopItem(MAP_VOTING_CATEGORY, `${MAP_VOTING_ITEM_PREFIX}${map.name}`, {\n        image: map.icon,\n        customTitle: map.name,\n        canBuy: true,\n        buyButtonText: "Votes: 0"\n      });\n    }\n    (0, import_helpers2.setTimeout)(() => {\n      for (const playerId in this.players) {\n        api.openShop(playerId, false, MAP_VOTING_CATEGORY);\n      }\n    }, 100);\n  }\n  onMapVote(playerId, categoryKey, shopItemKey) {\n    if (categoryKey !== MAP_VOTING_CATEGORY) {\n      return;\n    }\n    if (!this.mapVotingActive) {\n      return;\n    }\n    if (!shopItemKey.startsWith(MAP_VOTING_ITEM_PREFIX)) {\n      return;\n    }\n    const mapName = shopItemKey.replace(MAP_VOTING_ITEM_PREFIX, "");\n    if (!this.possibleMapOptions.some((map) => {\n      return map.name === mapName;\n    })) {\n      return;\n    }\n    const hadVotedBefore = !!this.mapVotes[playerId];\n    this.mapVotes[playerId] = mapName;\n    this.updateMapVotingForPlayer(playerId);\n    this.updateMapCountsForEveryone();\n    if (!hadVotedBefore) {\n      api.openShop(playerId, true);\n    }\n  }\n  onPlayerJoin(playerId) {\n    if (!this.mapVotingActive) {\n      return;\n    }\n    this.updateMapVotingForPlayer(playerId);\n    (0, import_helpers2.setTimeout)(\n      () => {\n        api.openShop(playerId, false, MAP_VOTING_CATEGORY);\n      },\n      100,\n      playerId\n    );\n  }\n  onPlayerLeave(playerId) {\n    if (!this.mapVotingActive) {\n      return;\n    }\n    delete this.mapVotes[playerId];\n    this.updateMapCountsForEveryone();\n  }\n  updateMapCountsForEveryone() {\n    for (const map of this.possibleMapOptions) {\n      const votes = Object.values(this.mapVotes).filter((v) => {\n        return v === map.name;\n      }).length;\n      api.updateShopItem(MAP_VOTING_CATEGORY, `${MAP_VOTING_ITEM_PREFIX}${map.name}`, {\n        buyButtonText: `Votes: ${votes}`\n      });\n    }\n  }\n  updateMapVotingForPlayer(playerId) {\n    api.configureShopCategoryForPlayer(playerId, MAP_VOTING_CATEGORY, {\n      redDot: !this.mapVotes[playerId]\n    });\n    for (const map of this.possibleMapOptions) {\n      api.updateShopItemForPlayer(playerId, MAP_VOTING_CATEGORY, `${MAP_VOTING_ITEM_PREFIX}${map.name}`, {\n        canBuy: this.mapVotes[playerId] !== map.name,\n        isSelected: this.mapVotes[playerId] === map.name\n      });\n    }\n  }\n  endMapVoting() {\n    if (!this.mapVotingActive) {\n      return;\n    }\n    this.mapVotingActive = false;\n    for (const map of this.possibleMapOptions) {\n      api.deleteShopItem(MAP_VOTING_CATEGORY, `${MAP_VOTING_ITEM_PREFIX}${map.name}`);\n    }\n    this.possibleMapOptions = [];\n    this.mapVotes = {};\n  }\n  chooseMap() {\n    if (!this.mapVotingActive) {\n      return null;\n    }\n    const votedPlayers = Object.keys(this.mapVotes);\n    if (votedPlayers.length === 0) {\n      return (0, import_helpers2.getRandomItem)(this.possibleMapOptions);\n    }\n    const randomPlayer = (0, import_helpers2.getRandomItem)(votedPlayers);\n    const choice = this.mapVotes[randomPlayer];\n    return this.maps.find((map) => {\n      return map.name === choice;\n    });\n  }\n};\n\n// world-code-plugin:SessionBasedGame.ts\nvar import_helpers4 = require("@plugins/helpers");\nvar SessionBasedGame2 = class {\n  constructor(gameOptions) {\n    __publicField(this, "gameOptions", gameOptions);\n    __publicField(this, "gamePhase", "beforeGame");\n    __publicField(this, "startingRound", false);\n    __publicField(this, "players", {});\n    __publicField(this, "map", null);\n    __publicField(this, "gameStartTime", 0);\n    __publicField(this, "startGameAt", Infinity);\n    __publicField(this, "endGameAt", Infinity);\n    __publicField(this, "mapVoter");\n    __publicField(this, "messageColours", {\n      error: "#ff0000",\n      success: "#00ff00",\n      info: "#ffffff"\n    });\n    this.mapVoter = new MapVoter(this.gameOptions.maps, this.players);\n    this.resetGame(false);\n    (0, import_helpers4.setInterval)(() => {\n      this.sendRightInfoText();\n    }, 1e3);\n  }\n  get playersForFullLobby() {\n    return this.gameOptions.teams.reduce((a, b) => {\n      return a + b.maxPlayers;\n    }, 0);\n  }\n  get playerCount() {\n    return Object.keys(this.players).length;\n  }\n  /**\n   * Gets the player object for a given player ID.\n   * @param playerId The player ID to get the player for\n   */\n  getPlayer(playerId) {\n    return this.players[playerId];\n  }\n  /**\n   * Gets all the players in the game, including spectators.\n   * @returns An iterator of all the players in the game.\n   */\n  *getPlayers() {\n    for (const playerId in this.players) {\n      yield this.players[playerId];\n    }\n  }\n  getStartingInText() {\n    if (this.gamePhase !== "beforeGame") {\n      return [];\n    }\n    const timeLeft = this.startGameAt - api.now();\n    if (timeLeft < 0) {\n      return [];\n    }\n    return [\n      ...style({ translationKey: "sessionBasedGame:startingIn" }, this.messageColours.info),\n      " ",\n      ...style(`${displayMs(timeLeft)}`, timeLeft < 1e4 ? this.messageColours.success : this.messageColours.info)\n    ];\n  }\n  /**\n   * Gives all players coloured armour based on their team name. Spectators will get black armour.\n   * If their team name is not a valid colour, they will be skipped.\n   */\n  giveColouredArmourToEveryone() {\n    for (const playerId in this.players) {\n      const player = this.players[playerId];\n      const prefix = player.team ? player.team.name : "Black";\n      try {\n        api.setItemSlot(playerId, 46, `${prefix} Wood Helmet`);\n        api.setItemSlot(playerId, 47, `${prefix} Wood Chestplate`);\n        api.setItemSlot(playerId, 48, `${prefix} Wood Gauntlets`);\n        api.setItemSlot(playerId, 49, `${prefix} Wood Leggings`);\n        api.setItemSlot(playerId, 50, `${prefix} Wood Boots`);\n      } catch (e) {\n        api.log(`Error giving coloured armour to player ${playerId}: ${e}`);\n      }\n    }\n  }\n  onPlayerJoin(playerId) {\n    this.players[playerId] = new this.gameOptions.playerConstructor(playerId, this);\n    this.mapVoter.onPlayerJoin(playerId);\n    this.updateTimeTillStart();\n  }\n  onPlayerLeave(playerId) {\n    if (!this.players[playerId]) {\n      return;\n    }\n    if (this.gamePhase === "beforeGame") {\n      const requestedTeam = this.players[playerId].requestedTeam;\n      if (requestedTeam) {\n        this.placeTeamPad(requestedTeam.name, false);\n      }\n    }\n    delete this.players[playerId];\n    this.checkWin();\n    this.mapVoter.onPlayerLeave(playerId);\n  }\n  onPlayerDie(playerId) {\n    this.checkWin();\n  }\n  checkWin() {\n    if (this.gamePhase !== "inGame") {\n      return;\n    }\n    const teamsAlive = this.getTeamsAlive();\n    if (teamsAlive.length === 1) {\n      this.makeTeamWin(teamsAlive[0]);\n    }\n  }\n  onPlayerChat(playerId, message) {\n    return this.players[playerId].onMessage();\n  }\n  onPlayerBoughtShopItem(playerId, categoryKey, itemKey) {\n    this.mapVoter.onMapVote(playerId, categoryKey, itemKey);\n  }\n  tick() {\n    this.checkGameTransition();\n  }\n  getTeamsAlive() {\n    const teamsAlive = [];\n    for (const playerId in this.players) {\n      const player = this.players[playerId];\n      if (player.team && !teamsAlive.includes(player.team)) {\n        teamsAlive.push(player.team);\n      }\n    }\n    return teamsAlive;\n  }\n  updateTimeTillStart() {\n    if (this.gamePhase === "beforeGame" && this.playerCount >= this.playersForFullLobby) {\n      this.setStartGame(this.gameOptions.fullLobbyStartInSecs);\n    }\n  }\n  setStartGame(startInSecs) {\n    const newStartAt = api.now() + startInSecs * 1e3;\n    this.startGameAt = Math.min(this.startGameAt, newStartAt);\n    api.broadcastMessage(style(`Starting in ${startInSecs}s...`, this.messageColours.info));\n  }\n  checkGameTransition() {\n    if (this.gamePhase === "beforeGame") {\n      const timeLeft = this.startGameAt - api.now();\n      if (timeLeft < 0) {\n        if (this.playerCount < 2) {\n          api.broadcastMessage(style("Not enough players to start game", this.messageColours.error));\n          this.startGameAt = Infinity;\n          this.setStartGame(this.gameOptions.emptyLobbyStartInSecs);\n        } else {\n          this.startGame();\n        }\n        return;\n      } else if (timeLeft < 5e3) {\n        const secsLeft = Math.ceil(timeLeft / 1e3);\n        for (const playerId in this.players) {\n          api.setClientOption(playerId, "middleTextUpper", style(`Game starts in ${secsLeft} seconds`, this.messageColours.info));\n        }\n      } else {\n        for (const playerId in this.players) {\n          api.setClientOption(playerId, "middleTextUpper", []);\n        }\n      }\n    }\n    if (this.gamePhase === "gameFinished") {\n      const timeLeft = this.endGameAt - api.now();\n      if (timeLeft < 0) {\n        this.resetGame(true);\n      } else if (timeLeft < 5e3) {\n        const secsLeft = Math.ceil(timeLeft / 1e3);\n        for (const playerId in this.players) {\n          api.setClientOption(playerId, "middleTextUpper", style(`Game ends in ${secsLeft} seconds`, this.messageColours.info));\n        }\n      }\n    }\n  }\n  sendRightInfoText() {\n    for (const playerId in this.players) {\n      const rightInfoText = this.gameOptions.getRightInfoText(this.players[playerId]);\n      if (rightInfoText) {\n        api.setClientOption(playerId, "RightInfoText", rightInfoText);\n      }\n    }\n  }\n  loadMap(source) {\n    const rect = getSourceRect(source);\n    const mapDimensions = getDimensions(rect);\n    const { low: mapLow } = getLowHigh(rect);\n    const { low: playAreaLow, high: playAreaHigh } = getLowHigh(this.gameOptions.playAreaRect);\n    for (let x = 0; x < mapDimensions.l; x += 32) {\n      for (let y = 0; y < mapDimensions.w; y += 32) {\n        for (let z = 0; z < mapDimensions.h; z += 32) {\n          const mapChunkPos = [mapLow[0] + x, mapLow[1] + y, mapLow[2] + z];\n          const playAreaChunkPos = [playAreaLow[0] + x, playAreaLow[1] + y, playAreaLow[2] + z];\n          if (source.schematic !== void 0) {\n            api.setChunkAsSchematic(source.schematic, mapChunkPos, playAreaChunkPos);\n          } else {\n            (0, import_helpers4.forceLoadChunk)(mapChunkPos[0], mapChunkPos[1], mapChunkPos[2], () => {\n              api.copyChunk(mapChunkPos, playAreaChunkPos);\n            });\n          }\n        }\n      }\n    }\n    const mapEnd = [playAreaLow[0] + mapDimensions.l, playAreaLow[1] + mapDimensions.w, playAreaLow[2] + mapDimensions.h];\n    fillOutsideWithAir(playAreaLow, playAreaHigh, mapEnd);\n  }\n  startGame() {\n    api.setMaxPlayers(1, this.playersForFullLobby + this.gameOptions.maxSpectators);\n    this.assignTeams();\n    this.map = null;\n    if (this.gameOptions.mapVotingEnabled) {\n      this.map = this.mapVoter.chooseMap();\n      this.mapVoter.endMapVoting();\n    }\n    if (!this.map) {\n      this.map = (0, import_helpers4.getRandomItem)(this.gameOptions.maps);\n    }\n    this.startingRound = true;\n    try {\n      for (const playerId in this.players) {\n        api.setClientOption(playerId, "middleTextUpper", []);\n        if (this.players[playerId].team) {\n          this.players[playerId].startPlaying();\n        } else {\n          this.players[playerId].startSpectating();\n        }\n      }\n      this.loadMap(this.map.source);\n      this.gameStartTime = api.now();\n      this.gamePhase = "inGame";\n    } finally {\n      this.startingRound = false;\n    }\n    this.gameOptions.onStart();\n  }\n  /**\n   * Whether spectators should render faded. gamePhase can\'t be read directly: it only flips to\n   * "inGame" once startGame() has started every player, and the sit-out spectators it makes\n   * along the way need fading too.\n   */\n  spectatorsAreFaded() {\n    return this.startingRound || this.gamePhase === "inGame";\n  }\n  assignTeams() {\n    const teamCounts = Object.fromEntries(\n      this.gameOptions.teams.map((team) => {\n        return [team.name, 0];\n      })\n    );\n    const requestedPlayers = [];\n    const unrequestedPlayers = [];\n    for (const playerId in this.players) {\n      const player = this.players[playerId];\n      if (player.requestedTeam) {\n        requestedPlayers.push(playerId);\n      } else {\n        unrequestedPlayers.push(playerId);\n      }\n    }\n    (0, import_helpers4.shuffleArray)(unrequestedPlayers);\n    const playerIds = [...requestedPlayers, ...unrequestedPlayers];\n    for (const playerId of playerIds) {\n      const player = this.players[playerId];\n      if (player.requestedTeam) {\n        player.team = player.requestedTeam;\n        teamCounts[player.requestedTeam.name]++;\n        continue;\n      }\n      let smallestTeamPlayers = Infinity;\n      let smallestTeam = null;\n      for (const team of this.gameOptions.teams) {\n        const numOnTeam = teamCounts[team.name];\n        if (numOnTeam < smallestTeamPlayers && numOnTeam < team.maxPlayers) {\n          smallestTeamPlayers = numOnTeam;\n          smallestTeam = team;\n        }\n      }\n      if (smallestTeam === null) {\n        continue;\n      }\n      this.players[playerId].team = smallestTeam;\n      teamCounts[smallestTeam.name]++;\n    }\n  }\n  /**\n   * Manually sets a team to win the game. Will begin the game reset timer to restart the game.#\n   * Automatically called when there is only one team left.\n   * @param winningTeam - The team object that won the game.\n   */\n  makeTeamWin(winningTeam) {\n    if (this.gamePhase !== "inGame") {\n      return;\n    }\n    this.gamePhase = "gameFinished";\n    this.gameOptions.onFinish(winningTeam);\n    this.endGameAt = api.now() + this.gameOptions.gameResetInSecs * 1e3;\n  }\n  resetGame(restart) {\n    this.gamePhase = "beforeGame";\n    this.startGameAt = Infinity;\n    this.endGameAt = Infinity;\n    for (const playerId in this.players) {\n      const player = this.players[playerId];\n      player.startSpectating();\n      player.requestedTeam = null;\n      if (restart) {\n        api.killLifeform(playerId);\n      }\n    }\n    api.setMaxPlayers(this.playersForFullLobby, this.playersForFullLobby + this.gameOptions.maxSpectators);\n    this.loadMap(this.gameOptions.lobby.source);\n    if (this.gameOptions.lobby.teamPads) {\n      this.placeTeamPads();\n    }\n    this.setStartGame(this.gameOptions.emptyLobbyStartInSecs);\n    if (this.gameOptions.mapVotingEnabled) {\n      this.mapVoter.createMapVoting();\n    }\n  }\n  onBlockStandStart(playerId, x, y, z, blockName) {\n    if (!this.gameOptions.lobby.teamPads) {\n      return;\n    }\n    if (this.gamePhase !== "beforeGame") {\n      return;\n    }\n    const player = this.players[playerId];\n    let team = null;\n    const { low: playAreaLow, high: playAreaHigh } = getLowHigh(this.gameOptions.playAreaRect);\n    for (const teamPadName in this.gameOptions.lobby.teamPads) {\n      const teamPadInfo = this.gameOptions.lobby.teamPads[teamPadName];\n      const { low: rectLow, high: rectHigh } = getLowHigh(teamPadInfo.rect);\n      rectLow[0] += playAreaLow[0];\n      rectLow[1] += playAreaLow[1];\n      rectLow[2] += playAreaLow[2];\n      rectHigh[0] += playAreaLow[0];\n      rectHigh[1] += playAreaLow[1];\n      rectHigh[2] += playAreaLow[2];\n      if (api.isInsideRect([x, y, z], rectLow, rectHigh)) {\n        team = this.gameOptions.teams.find((team2) => {\n          return team2.name === teamPadName;\n        });\n        break;\n      }\n    }\n    if (!team) {\n      return;\n    }\n    const oldTeam = player.requestedTeam;\n    if (oldTeam === team) {\n      return;\n    }\n    let requestCount = 0;\n    for (const playerId2 in this.players) {\n      const player2 = this.players[playerId2];\n      if (player2.requestedTeam === team) {\n        requestCount++;\n      }\n    }\n    if (player.qTextId) {\n      api.removeFromQueue(player.qTextId);\n    }\n    if (requestCount >= team.maxPlayers) {\n      if (player.requestedTeam !== team) {\n        player.qTextId = api.queueMiddleTextLower(playerId, style(`${team.name} team is full`, this.messageColours.error), 1e3);\n      }\n      this.placeTeamPad(team.name, true);\n      return;\n    }\n    player.requestedTeam = team;\n    player.qTextId = api.queueMiddleTextLower(playerId, style(`${team.name} team selected`, this.messageColours.success), 1e3);\n    if (oldTeam !== team) {\n      if (oldTeam) {\n        this.placeTeamPad(oldTeam.name, false);\n      }\n      const isFull = requestCount + 1 >= team.maxPlayers;\n      this.placeTeamPad(team.name, isFull);\n    }\n  }\n  placeTeamPad(teamName, full) {\n    const { low: playAreaLow } = getLowHigh(this.gameOptions.playAreaRect);\n    const { rect, emptyBlock, fullBlock } = this.gameOptions.lobby.teamPads[teamName];\n    const { low: rectLow, high: rectHigh } = getLowHigh(rect);\n    for (let x = rectLow[0] + playAreaLow[0]; x <= rectHigh[0] + playAreaLow[0]; x += 32) {\n      for (let y = rectLow[1] + playAreaLow[1]; y <= rectHigh[1] + playAreaLow[1]; y += 32) {\n        for (let z = rectLow[2] + playAreaLow[2]; z <= rectHigh[2] + playAreaLow[2]; z += 32) {\n          (0, import_helpers4.forceLoadChunk)(x, y, z, () => {\n            const endX = Math.min(x + 31, rectHigh[0] + playAreaLow[0]);\n            const endY = Math.min(y + 31, rectHigh[1] + playAreaLow[1]);\n            const endZ = Math.min(z + 31, rectHigh[2] + playAreaLow[2]);\n            fillBox([x, y, z], [endX, endY, endZ], full ? fullBlock : emptyBlock);\n          });\n        }\n      }\n    }\n  }\n  placeTeamPads() {\n    for (const teamName in this.gameOptions.lobby.teamPads) {\n      this.placeTeamPad(teamName, false);\n    }\n  }\n};\nfunction fillOutsideWithAir(low, high, copiedHigh) {\n  for (let axis = 0; axis < 3; axis++) {\n    const slabLow = [low[0], low[1], low[2]];\n    const slabHigh = [high[0], high[1], high[2]];\n    slabLow[axis] = copiedHigh[axis] + 1;\n    for (let earlier = 0; earlier < axis; earlier++) {\n      slabHigh[earlier] = Math.min(copiedHigh[earlier], high[earlier]);\n    }\n    if (slabLow[0] <= slabHigh[0] && slabLow[1] <= slabHigh[1] && slabLow[2] <= slabHigh[2]) {\n      fillBox(slabLow, slabHigh, "Air");\n    }\n  }\n}\nfunction fillBox(pos1, pos2, block) {\n  const maxRectVol = 360;\n  const {\n    low: [x1, y1, z1],\n    high: [x2, y2, z2]\n  } = getLowHigh([pos1, pos2]);\n  const zSizeFull = z2 - z1 + 1;\n  const zStep = Math.min(zSizeFull, maxRectVol);\n  for (let z = z1; z <= z2; z += zStep) {\n    const zEnd = Math.min(z2, z + zStep - 1);\n    const zSize = zEnd - z + 1;\n    const yStep = Math.max(1, Math.floor(maxRectVol / zSize));\n    for (let y = y1; y <= y2; y += yStep) {\n      const yEnd = Math.min(y2, y + yStep - 1);\n      const yz = (yEnd - y + 1) * zSize;\n      const xStep = Math.max(1, Math.floor(maxRectVol / yz));\n      for (let x = x1; x <= x2; x += xStep) {\n        const xEnd = Math.min(x2, x + xStep - 1);\n        api.setBlockRect([x, y, z], [xEnd, yEnd, zEnd], block);\n      }\n    }\n  }\n}\n\n// world-code-plugin:index.ts\nvar game = null;\nonPlayerJoin = (playerId) => {\n  game?.onPlayerJoin(playerId);\n};\nonPlayerLeave = (playerId) => {\n  game?.onPlayerLeave(playerId);\n};\ntick = () => {\n  game?.tick();\n};\nonPlayerChat = (playerId, message) => {\n  return game?.onPlayerChat(playerId, message);\n};\nonMobKilledPlayer = (mobId, playerId) => {\n  game?.onPlayerDie(playerId);\n};\nonPlayerKilledOtherPlayer = (killerId, victimId) => {\n  game?.onPlayerDie(victimId);\n};\nonRespawnRequest = (playerId) => {\n  return game?.getPlayer(playerId)?.onRespawnRequest();\n};\nonPlayerBoughtShopItem = (playerId, categoryKey, itemKey) => {\n  game?.onPlayerBoughtShopItem(playerId, categoryKey, itemKey);\n};\nonBlockStandStart = (playerId, x, y, z, blockName) => {\n  game?.onBlockStandStart(playerId, x, y, z, blockName);\n};\nfunction createGame(opts) {\n  if (game) {\n    throw new Error("Game already setup");\n  }\n  if (opts.maps.length === 0) {\n    throw new Error("No maps provided");\n  }\n  if (opts.teams.length < 2) {\n    throw new Error(`At least 2 teams are required (got ${opts.teams.length})`);\n  }\n  for (const team of opts.teams) {\n    if (team.maxPlayers < 1) {\n      throw new Error(`Team ${team.name} max players must be at least 1`);\n    }\n  }\n  opts.playAreaRect = roundOutwardsToChunkBoundary(opts.playAreaRect);\n  const playAreaDimensions = getDimensions(opts.playAreaRect);\n  preloadRect(opts.playAreaRect);\n  const newMaps = [];\n  for (const map of opts.maps) {\n    const newMap = {\n      ...map,\n      source: map.source.schematic !== void 0 ? map.source : { ...map.source, rect: roundOutwardsToChunkBoundary(map.source.rect) }\n    };\n    const mapDimensions = getDimensions(getSourceRect(newMap.source));\n    if (mapDimensions.l > playAreaDimensions.l || mapDimensions.w > playAreaDimensions.w || mapDimensions.h > playAreaDimensions.h) {\n      throw new Error(`Map ${map.name} is too large for play area`);\n    }\n    if (newMap.source.schematic === void 0) {\n      preloadRect(newMap.source.rect);\n    }\n    newMaps.push(newMap);\n  }\n  opts.maps = newMaps;\n  opts.lobby = {\n    ...opts.lobby,\n    source: opts.lobby.source.schematic !== void 0 ? opts.lobby.source : { ...opts.lobby.source, rect: roundOutwardsToChunkBoundary(opts.lobby.source.rect) }\n  };\n  const lobbyDimensions = getDimensions(getSourceRect(opts.lobby.source));\n  if (lobbyDimensions.l > playAreaDimensions.l || lobbyDimensions.w > playAreaDimensions.w || lobbyDimensions.h > playAreaDimensions.h) {\n    throw new Error(`Lobby is too large for play area`);\n  }\n  if (opts.lobby.source.schematic === void 0) {\n    preloadRect(opts.lobby.source.rect);\n  }\n  const newGame = new SessionBasedGame2({\n    ...defaultSessionBasedGameSetupOptions,\n    ...opts\n  });\n  game = newGame;\n  return newGame;\n}\nvar defaultSessionBasedGameSetupOptions = {\n  maxSpectators: 10,\n  emptyLobbyStartInSecs: 60,\n  fullLobbyStartInSecs: 10,\n  gameResetInSecs: 10,\n  mapVotingEnabled: false,\n  onStart: () => {\n    api.broadcastMessage(style("Game started", game?.messageColours.success));\n  },\n  onFinish: (winningTeam) => {\n    api.broadcastMessage(style(`${winningTeam.name} won the game`, winningTeam.colour));\n  },\n  getRightInfoText: (player) => {\n    return game?.getStartingInText();\n  },\n  playerConstructor: SessionBasedPlayer\n};\n',
        types: 'import * as _bloxd from \'@bloxd\';\nimport { PlayerId, CustomTextStyling, BlockName, ChatTags, Pos, RecursiveReadonly } from \'@bloxd\';\n\ndeclare class SessionBasedGame<TeamInfo extends BaseTeamInfo, MapInfo extends BaseMapInfo<TeamInfo>, Player extends SessionBasedPlayer<TeamInfo, MapInfo>> {\n    readonly gameOptions: Required<SessionBasedGameSetupOptions<TeamInfo, MapInfo, Player>>;\n    gamePhase: "beforeGame" | "inGame" | "gameFinished";\n    private startingRound;\n    private players;\n    map: MapInfo | null;\n    private gameStartTime;\n    private startGameAt;\n    private endGameAt;\n    private mapVoter;\n    messageColours: {\n        error: string;\n        success: string;\n        info: string;\n    };\n    private get playersForFullLobby();\n    private get playerCount();\n    constructor(gameOptions: Required<SessionBasedGameSetupOptions<TeamInfo, MapInfo, Player>>);\n    /**\n     * Gets the player object for a given player ID.\n     * @param playerId The player ID to get the player for\n     */\n    getPlayer(playerId: PlayerId): Player;\n    /**\n     * Gets all the players in the game, including spectators.\n     * @returns An iterator of all the players in the game.\n     */\n    getPlayers(): Generator<Player>;\n    getStartingInText(): string | CustomTextStyling;\n    /**\n     * Gives all players coloured armour based on their team name. Spectators will get black armour.\n     * If their team name is not a valid colour, they will be skipped.\n     */\n    giveColouredArmourToEveryone(): void;\n    onPlayerJoin(playerId: PlayerId): void;\n    onPlayerLeave(playerId: PlayerId): void;\n    onPlayerDie(playerId: PlayerId): void;\n    checkWin(): void;\n    onPlayerChat(playerId: PlayerId, message: string): _bloxd.ChatTags;\n    onPlayerBoughtShopItem(playerId: PlayerId, categoryKey: string, itemKey: string): void;\n    tick(): void;\n    private getTeamsAlive;\n    private updateTimeTillStart;\n    private setStartGame;\n    private checkGameTransition;\n    private sendRightInfoText;\n    private loadMap;\n    private startGame;\n    /**\n     * Whether spectators should render faded. gamePhase can\'t be read directly: it only flips to\n     * "inGame" once startGame() has started every player, and the sit-out spectators it makes\n     * along the way need fading too.\n     */\n    spectatorsAreFaded(): boolean;\n    private assignTeams;\n    /**\n     * Manually sets a team to win the game. Will begin the game reset timer to restart the game.#\n     * Automatically called when there is only one team left.\n     * @param winningTeam - The team object that won the game.\n     */\n    makeTeamWin(winningTeam: TeamInfo | null): void;\n    private resetGame;\n    onBlockStandStart(playerId: PlayerId, x: number, y: number, z: number, blockName: BlockName): void;\n    private placeTeamPad;\n    private placeTeamPads;\n}\n\ndeclare class SessionBasedPlayer<TeamInfo extends BaseTeamInfo, MapInfo extends BaseMapInfo<TeamInfo>> {\n    readonly playerId: PlayerId;\n    readonly game: SessionBasedGame<TeamInfo, MapInfo, SessionBasedPlayer<TeamInfo, MapInfo>>;\n    isSpectating: boolean;\n    team: TeamInfo | null;\n    requestedTeam: TeamInfo | null;\n    qTextId: string | null;\n    constructor(playerId: PlayerId, game: SessionBasedGame<TeamInfo, MapInfo, SessionBasedPlayer<TeamInfo, MapInfo>>);\n    private spawn;\n    /**\n     * Sets the player as playing the game, setting their health, shields, and other settings.\n     * Automatically called at the start of a game for players assigned to a team.\n     */\n    startPlaying(): void;\n    /**\n     * Sets the player as spectating the game, resetting their health, shields, and other settings.\n     * Automatically called at the start of a game for players not assigned to a team.\n     * Call this function to turn a player into a spectator (for example, once they die).\n     */\n    startSpectating(): void;\n    private updateOtherEntitySettings;\n    onMessage(): ChatTags;\n    onRespawnRequest(): Pos | undefined;\n    /**\n     * Gets the position of the player relative to the play area.\n     * @returns The position of the player relative to the play area.\n     */\n    getPositionInPlayArea(): Pos;\n}\n\ntype BaseTeamInfo = RecursiveReadonly<{\n    name: string;\n    maxPlayers: number;\n    colour: string;\n}>;\n/** A world rectangle (rounded outwards to chunk boundaries), or a project schematic path. */\ntype MapSource = RecursiveReadonly<{\n    rect: [Pos, Pos];\n    schematic?: never;\n} | {\n    schematic: string;\n    rect?: never;\n}>;\ntype BaseMapInfo<TeamInfo extends BaseTeamInfo> = RecursiveReadonly<{\n    /** The name of the map */\n    name: string;\n    /** The icon of the map - used in the Map Voting Shop UI */\n    icon: string;\n    source: MapSource;\n}> & {\n    readonly teams: Record<TeamInfo["name"], RecursiveReadonly<{\n        spawn: Pos;\n        spawnFacing: Pos;\n    }>>;\n};\ntype Constructor<T> = new (...args: any[]) => T;\ntype TeamPadInfo = RecursiveReadonly<{\n    rect: [Pos, Pos];\n    emptyBlock: BlockName;\n    fullBlock: BlockName;\n}>;\ntype SessionBasedGameSetupOptions<TeamInfo extends BaseTeamInfo, MapInfo extends BaseMapInfo<TeamInfo>, Player extends SessionBasedPlayer<TeamInfo, MapInfo>> = {\n    teams: readonly TeamInfo[];\n    maps: readonly MapInfo[];\n    /** Lobby area information */\n    lobby: RecursiveReadonly<{\n        source: MapSource;\n        spawn: Pos;\n        spawnFacing: Pos;\n    }> & {\n        /** Block coordinates representing the start and the end of the team pads. Offset from the lowest corner of the map (after rounding outwards). If not provided, team choosing will be disabled. */\n        teamPads?: Record<TeamInfo["name"], TeamPadInfo>;\n    };\n    /** Block coordinates representing the start and the end of the play area. These will be rounded outwards to the nearest chunk boundary */\n    playAreaRect: readonly [Pos, Pos];\n    /** Maximum number of spectators allowed in the game */\n    maxSpectators?: number;\n    /** The number of seconds to wait before resetting the game after the game finishes */\n    emptyLobbyStartInSecs?: number;\n    /** The number of seconds to wait before starting the game when the lobby is full */\n    fullLobbyStartInSecs?: number;\n    /** The number of seconds to wait before resetting the game after the game finishes */\n    gameResetInSecs?: number;\n    /** Enable Map Voting - If enabled, players will be able to vote for the next map to play. */\n    mapVotingEnabled?: boolean;\n    /** Function to call when the game starts */\n    onStart?: () => void;\n    /** Function to call when the game finishes */\n    onFinish?: (winningTeam: TeamInfo) => void;\n    /** Function to get the RightInfoText for a player */\n    getRightInfoText?: (player: SessionBasedPlayer<TeamInfo, MapInfo>) => string | CustomTextStyling | null;\n    /** The constructor for the player class. This should be a class that extends SessionBasedPlayer */\n    playerConstructor?: Constructor<Player>;\n};\n\n/**\n * Create a new SessionBasedGame.\n * @param opts - The options for the game.\n * @param opts.teams - The teams for the game. This should include the team name, max players for this team, and hex colour.\n * @param opts.maps - The maps for the game. This should include the map name, source rectangle or schematic path, and the spawn positions for each team.\n * @param opts.lobby - The lobby area. This should include the source rectangle or schematic path, spawn info, and team pads for team choosing.\n * @param opts.playAreaRect - The play area rectangle. These will be rounded outwards to the nearest chunk boundary\n * @param opts.maxSpectators - The maximum number of spectators allowed in the game.\n * @param opts.emptyLobbyStartInSecs - The number of seconds to wait for the game to start when the lobby isn\'t full yet.\n * @param opts.fullLobbyStartInSecs - The number of seconds to wait for the game to start when the lobby is full.\n * @param opts.gameResetInSecs - The number of seconds to wait before resetting the game after the game finishes.\n * @param opts.mapVotingEnabled - Whether to enable map voting.\n * @param opts.onStart - The function to call when the game starts.\n * @param opts.onFinish - The function to call when the game finishes.\n * @param opts.getRightInfoText - The function to call to get the RightInfoText for the game.\n * @param opts.playerConstructor - The constructor for the player class. This should be a class that extends SessionBasedPlayer\n * @returns The game instance\n */\ndeclare function createGame<TeamInfo extends BaseTeamInfo, MapInfo extends BaseMapInfo<TeamInfo>, Player extends SessionBasedPlayer<TeamInfo, MapInfo>>(opts: SessionBasedGameSetupOptions<TeamInfo, MapInfo, Player>): SessionBasedGame<TeamInfo, MapInfo, Player>;\n\nexport { SessionBasedGame, SessionBasedPlayer, createGame };\nexport type { BaseMapInfo, BaseTeamInfo, MapSource, SessionBasedGameSetupOptions };\n'
      },
      vK = {
        debug: {
          name: "debug",
          specifier: "@plugins/debug",
          sourceVfsPath: "/node_modules/@plugins/debug/index.ts",
          typesVfsPath: "/node_modules/@plugins/debug/index.d.ts",
          files: XO.files,
          dependencies: XO.dependencies,
          bundledSource: XO.bundledSource,
          types: XO.types
        },
        dialogue: {
          name: "dialogue",
          specifier: "@plugins/dialogue",
          sourceVfsPath: "/node_modules/@plugins/dialogue/index.ts",
          typesVfsPath: "/node_modules/@plugins/dialogue/index.d.ts",
          files: bK.files,
          dependencies: bK.dependencies,
          bundledSource: bK.bundledSource,
          types: bK.types
        },
        helpers: {
          name: "helpers",
          specifier: "@plugins/helpers",
          sourceVfsPath: "/node_modules/@plugins/helpers/index.ts",
          typesVfsPath: "/node_modules/@plugins/helpers/index.d.ts",
          files: eO.files,
          dependencies: eO.dependencies,
          bundledSource: eO.bundledSource,
          types: eO.types
        },
        sessionBasedGame: {
          name: "sessionBasedGame",
          specifier: "@plugins/sessionBasedGame",
          sourceVfsPath: "/node_modules/@plugins/sessionBasedGame/index.ts",
          typesVfsPath: "/node_modules/@plugins/sessionBasedGame/index.d.ts",
          files: lO.files,
          dependencies: lO.dependencies,
          bundledSource: lO.bundledSource,
          types: lO.types
        }
      };

    function CO(OO) {
      const KO = [],
        pO = new Set,
        XO = OO => {
          if (pO.has(OO)) return;
          const bK = vK[OO];
          if (bK) {
            pO.add(OO);
            for (const OO of bK.dependencies) XO(OO);
            KO.push(OO)
          }
        };
      for (const bK of OO) XO(bK);
      return KO
    }
  },
  35350: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO,
      f: () => vK,
      h: () => lO,
      j: () => eO,
      m: () => hO,
      p: () => DO,
      s: () => FO,
      t: () => oO,
      x: () => aK
    });
    var XO = pO(1098);
    const bK = ["quickjs", "ses"];

    function eO(OO) {
      return bK.includes(OO)
    }

    function lO(OO) {
      return OO === XO.f || OO === XO.j
    }

    function vK(OO, KO) {
      return OO === XO.f && KO === XO.j || OO === XO.j && KO === XO.f
    }

    function CO(OO) {
      const KO = XO.j in OO,
        pO = XO.f in OO;
      return KO && pO ? null : KO ? XO.j : pO ? XO.f : null
    }

    function hO(OO, KO, pO) {
      const XO = `${KO}/`;
      return OO.filter((OO => OO.startsWith(XO))).map((OO => [OO, `${pO}/${OO.slice(XO.length)}`]))
    }

    function DO(OO, KO) {
      let pO = 0;
      for (const [XO, bK] of Object.entries(OO)) XO !== KO && (pO += bK.length);
      return pO
    }
    const MO = "@plugins/";

    function aK(OO) {
      return `${MO}${OO}`
    }

    function oO(OO, KO) {
      return `/node_modules/@plugins/${OO}/${KO}`
    }

    function FO(OO) {
      if (!OO.startsWith(MO)) return null;
      const KO = OO.slice(MO.length);
      return function(OO) {
        return /^[a-zA-Z][a-zA-Z0-9_-]*$/.test(OO)
      }(KO) ? KO : null
    }
  },
  35362: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      g: () => bK,
      h: () => lO,
      i: () => CO,
      k: () => eO
    });
    var XO = pO(35356);
    const bK = 5,
      eO = "[SCHEMATIC]",
      lO = 1024e4;

    function vK(OO) {
      return OO.endsWith(".bloxdschem") && (0, XO.x)(OO.slice(0, -11) + ".ts") && OO.length <= 64
    }

    function CO(OO) {
      return Object.fromEntries(Object.keys(OO).map((OO => [OO, eO])))
    }
  },
  7833: (OO, KO, pO) => {
    function XO(OO, KO) {
      return !OO.hidden && (KO || !OO.isRewardedAd)
    }

    function bK(OO) {
      return "object" === typeof OO ? OO.option : OO
    }

    function eO(OO, KO) {
      var pO;
      if ("dropdown" === (null === (pO = OO.userInput) || void 0 === pO ? void 0 : pO.type) && "object" === typeof OO.userInput.dropdownOptions[0]) {
        for (const pO of OO.userInput.dropdownOptions)
          if (bK(pO) === KO) return "object" === typeof pO ? pO.cost : OO.cost;
        console.error("Didn't find matching option for dropdown item. Item:", OO, "input:", KO)
      }
      return OO.cost
    }

    function lO(OO, KO, pO) {
      var XO;
      const bK = null !== (XO = pO.excludedPlayers) && void 0 !== XO ? XO : [KO];
      return OO.filter((OO => !bK.includes(OO)))
    }
    pO.d(KO, {
      e: () => eO,
      f: () => bK,
      g: () => lO,
      i: () => XO
    })
  },
  3977: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      g: () => XO,
      k: () => eO,
      l: () => CO,
      m: () => lO
    });
    const XO = ["sine", "triangle", "square", "sawtooth"],
      bK = 55,
      eO = {
        soft: {
          waveform: "sine",
          pitchHz: 300,
          glideSemitones: -.5,
          durationMs: 80,
          attackMs: 6,
          releaseMs: 18,
          lowpassHz: null,
          volume: .6,
          intonation: {
            variationSemitones: 1.2,
            declineSemitones: 1.5,
            questionRiseSemitones: 3.5,
            exclaimLiftSemitones: 1.5
          },
          syllableMs: 60
        },
        regular: {
          waveform: "triangle",
          pitchHz: 195,
          glideSemitones: -.6,
          durationMs: 70,
          attackMs: 2,
          releaseMs: 12,
          lowpassHz: null,
          volume: 1,
          intonation: {
            variationSemitones: 1.5,
            declineSemitones: 2,
            questionRiseSemitones: 4,
            exclaimLiftSemitones: 2
          },
          syllableMs: 52
        },
        dark: {
          waveform: "sawtooth",
          pitchHz: 80,
          glideSemitones: -.6,
          durationMs: 85,
          attackMs: 6,
          releaseMs: 16,
          lowpassHz: 420,
          volume: 1.05,
          intonation: {
            variationSemitones: 1,
            declineSemitones: 3.5,
            questionRiseSemitones: 2.5,
            exclaimLiftSemitones: 1
          },
          syllableMs: 64
        },
        "high-pitched": {
          waveform: "triangle",
          pitchHz: 300,
          glideSemitones: -.8,
          durationMs: 55,
          attackMs: 2,
          releaseMs: 10,
          lowpassHz: null,
          volume: .8,
          intonation: {
            variationSemitones: 2.2,
            declineSemitones: 2,
            questionRiseSemitones: 5,
            exclaimLiftSemitones: 3
          },
          syllableMs: 44
        },
        gruff: {
          waveform: "sawtooth",
          pitchHz: 105,
          glideSemitones: -.8,
          durationMs: 75,
          attackMs: 4,
          releaseMs: 14,
          lowpassHz: 900,
          volume: .85,
          intonation: {
            variationSemitones: 1.2,
            declineSemitones: 3,
            questionRiseSemitones: 3,
            exclaimLiftSemitones: 2
          },
          syllableMs: 58
        },
        lively: {
          waveform: "square",
          pitchHz: 230,
          glideSemitones: .6,
          durationMs: 55,
          attackMs: 2,
          releaseMs: 10,
          lowpassHz: 2400,
          volume: .5,
          intonation: {
            variationSemitones: 2.6,
            declineSemitones: 1.5,
            questionRiseSemitones: 5,
            exclaimLiftSemitones: 3.5
          },
          syllableMs: 44
        },
        posh: {
          waveform: "triangle",
          pitchHz: 175,
          glideSemitones: 1.2,
          durationMs: 90,
          attackMs: 6,
          releaseMs: 20,
          lowpassHz: 2e3,
          volume: 1,
          intonation: {
            variationSemitones: 2,
            declineSemitones: 4,
            questionRiseSemitones: 5,
            exclaimLiftSemitones: 2.5
          },
          syllableMs: 60
        },
        mechanical: {
          waveform: "square",
          pitchHz: 140,
          glideSemitones: 0,
          durationMs: 60,
          attackMs: 0,
          releaseMs: 4,
          lowpassHz: 1400,
          volume: .55,
          intonation: {
            variationSemitones: 0,
            declineSemitones: 0,
            questionRiseSemitones: 0,
            exclaimLiftSemitones: 0
          },
          syllableMs: 62
        }
      };

    function lO(OO) {
      return "string" !== typeof OO ? OO : Object.hasOwn(eO, OO) ? eO[OO] : null
    }

    function vK(OO, KO, pO) {
      return Math.min(pO, Math.max(KO, OO))
    }

    function CO(OO) {
      const KO = vK(OO.durationMs, 10, 500),
        pO = vK(OO.attackMs, 0, KO),
        {
          intonation: bK
        } = OO;
      return {
        waveform: XO.includes(OO.waveform) ? OO.waveform : "sine",
        pitchHz: vK(OO.pitchHz, 20, 4e3),
        glideSemitones: vK(OO.glideSemitones, -24, 24),
        durationMs: KO,
        attackMs: pO,
        releaseMs: vK(OO.releaseMs, 0, KO - pO),
        lowpassHz: null === OO.lowpassHz ? null : vK(OO.lowpassHz, 20, 2e4),
        volume: vK(OO.volume, 0, 2),
        intonation: {
          variationSemitones: vK(bK.variationSemitones, 0, 6),
          declineSemitones: vK(bK.declineSemitones, 0, 12),
          questionRiseSemitones: vK(bK.questionRiseSemitones, 0, 12),
          exclaimLiftSemitones: vK(bK.exclaimLiftSemitones, 0, 12)
        },
        syllableMs: vK(OO.syllableMs, 25, 200)
      }
    }
  },
  7896: () => {}
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);