export const id = 286;
export const ids = [286];
export const modules = {
  39784: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO
    });
    var XO = pO(35632),
      bK = pO(35664),
      eO = pO(38048),
      lO = pO(35639),
      vK = pO(35688);
    class CO {
      constructor(OO, KO, pO, XO) {
        this.name = OO, this.worldAxisForNormal = KO, this.worldAxisForFileX = pO, this.worldAxisForFileY = XO
      }
    }
    class hO {
      static _NearestPow2Floor(OO) {
        return OO <= 1 ? 1 : 1 << Math.floor(Math.log2(OO))
      }
      static ConvertCubeMapTextureToSphericalPolynomial(OO) {
        if (!OO.isCube) return null;
        OO.JKO()?.qb().flushFramebuffer();
        const KO = OO.getSize().width,
          pO = OO._sphericalPolynomialTargetSize,
          XO = pO > 0 ? this._NearestPow2Floor(pO) : 0,
          bK = !OO.noMipmap && !0 === OO._texture?.generateMipMaps,
          eO = XO > 0 && XO < KO && bK,
          lO = eO ? Math.max(0, Math.round(Math.log2(KO / XO))) : 0,
          vK = eO ? Math.max(1, Math.floor(KO / Math.pow(2, lO))) : KO,
          CO = OO.readPixels(0, lO, void 0, !1),
          hO = OO.readPixels(1, lO, void 0, !1);
        let DO, MO;
        OO.isRenderTarget ? (DO = OO.readPixels(3, lO, void 0, !1), MO = OO.readPixels(2, lO, void 0, !1)) : (DO = OO.readPixels(2, lO, void 0, !1), MO = OO.readPixels(3, lO, void 0, !1));
        const aK = OO.readPixels(4, lO, void 0, !1),
          oO = OO.readPixels(5, lO, void 0, !1),
          FO = OO.gammaSpace,
          VO = XO > 0 && XO < KO && !eO;
        return new Promise((OO => {
          Promise.all([hO, CO, DO, MO, aK, oO]).then((pO => {
            let [bK, eO, lO, CO, hO, DO] = pO, MO = vK;
            if (VO) {
              const OO = 4;
              bK = this._DownsampleFace(bK, KO, XO, OO), eO = this._DownsampleFace(eO, KO, XO, OO), lO = this._DownsampleFace(lO, KO, XO, OO), CO = this._DownsampleFace(CO, KO, XO, OO), hO = this._DownsampleFace(hO, KO, XO, OO), DO = this._DownsampleFace(DO, KO, XO, OO), MO = XO
            }
            const aK = {
              size: MO,
              right: eO,
              left: bK,
              up: lO,
              down: CO,
              front: hO,
              back: DO,
              format: 5,
              type: bK instanceof Float32Array ? 1 : 0,
              gammaSpace: FO
            };
            OO(this.ConvertCubeMapToSphericalPolynomial(aK))
          }))
        }))
      }
      static _AreaElement(OO, KO) {
        return Math.atan2(OO * KO, Math.sqrt(OO * OO + KO * KO + 1))
      }
      static _DownsampleFace(OO, KO, pO, XO) {
        const bK = OO instanceof Float32Array ? OO : Float32Array.from(OO),
          eO = pO * pO * XO,
          lO = new Float32Array(eO),
          vK = KO / pO,
          CO = 1 / (vK * vK);
        for (let DO = 0; DO < pO; DO++) {
          const OO = Math.floor(DO * vK),
            eO = Math.floor((DO + 1) * vK);
          for (let hO = 0; hO < pO; hO++) {
            const MO = Math.floor(hO * vK),
              aK = Math.floor((hO + 1) * vK),
              oO = (DO * pO + hO) * XO;
            for (let pO = 0; pO < XO; pO++) {
              let vK = 0;
              for (let lO = OO; lO < eO; lO++)
                for (let OO = MO; OO < aK; OO++) vK += bK[(lO * KO + OO) * XO + pO];
              lO[oO + pO] = vK * CO
            }
          }
        }
        if (OO instanceof Float32Array) return lO;
        const hO = new(0, OO.constructor)(eO);
        for (let DO = 0; DO < eO; DO++) hO[DO] = lO[DO] + .5 | 0;
        return hO
      }
      static ConvertCubeMapToSphericalPolynomial(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        const pO = KO > 0 ? this._NearestPow2Floor(KO) : 0;
        if (pO > 0 && OO.size > pO) {
          const KO = 5 === OO.format ? 4 : 3,
            XO = ["right", "left", "up", "down", "front", "back"],
            bK = {};
          for (const eO of XO) bK[eO] = this._DownsampleFace(OO[eO], OO.size, pO, KO);
          OO = {
            ...OO,
            ...bK,
            size: pO
          }
        }
        const XO = new eO.e;
        let CO = 0;
        const hO = 2 / OO.size,
          DO = hO,
          MO = .5 * hO,
          aK = MO - 1;
        for (let eO = 0; eO < 6; eO++) {
          const KO = this._FileFaces[eO],
            pO = OO[KO.name];
          let oO = aK;
          const FO = 5 === OO.format ? 4 : 3;
          for (let eO = 0; eO < OO.size; eO++) {
            let VO = aK;
            for (let DO = 0; DO < OO.size; DO++) {
              const aK = KO.worldAxisForFileX.scale(VO).add(KO.worldAxisForFileY.scale(oO)).add(KO.worldAxisForNormal);
              aK.normalize();
              const LO = this._AreaElement(VO - MO, oO - MO) - this._AreaElement(VO - MO, oO + MO) - this._AreaElement(VO + MO, oO - MO) + this._AreaElement(VO + MO, oO + MO);
              let QO = pO[eO * OO.size * FO + DO * FO + 0],
                zK = pO[eO * OO.size * FO + DO * FO + 1],
                AO = pO[eO * OO.size * FO + DO * FO + 2];
              isNaN(QO) && (QO = 0), isNaN(zK) && (zK = 0), isNaN(AO) && (AO = 0), 0 === OO.type && (QO /= 255, zK /= 255, AO /= 255), OO.gammaSpace && (QO = Math.pow((0, bK.Clamp)(QO), lO.e), zK = Math.pow((0, bK.Clamp)(zK), lO.e), AO = Math.pow((0, bK.Clamp)(AO), lO.e));
              const fO = this.MAX_HDRI_VALUE;
              if (this.PRESERVE_CLAMPED_COLORS) {
                const OO = Math.max(QO, zK, AO);
                if (OO > fO) {
                  const KO = fO / OO;
                  QO *= KO, zK *= KO, AO *= KO
                }
              } else QO = (0, bK.Clamp)(QO, 0, fO), zK = (0, bK.Clamp)(zK, 0, fO), AO = (0, bK.Clamp)(AO, 0, fO);
              const dO = new vK.e(QO, zK, AO);
              XO.addLight(aK, dO, LO), CO += LO, VO += hO
            }
            oO += DO
          }
        }
        const oO = 6 * (4 * Math.PI) / 6 / CO;
        return XO.scaleInPlace(oO), XO.convertIncidentRadianceToIrradiance(), XO.convertIrradianceToLambertianRadiance(), eO.f.FromHarmonics(XO)
      }
    }
    hO._FileFaces = [new CO("right", new XO.o(1, 0, 0), new XO.o(0, 0, -1), new XO.o(0, -1, 0)), new CO("left", new XO.o(-1, 0, 0), new XO.o(0, 0, 1), new XO.o(0, -1, 0)), new CO("up", new XO.o(0, 1, 0), new XO.o(1, 0, 0), new XO.o(0, 0, 1)), new CO("down", new XO.o(0, -1, 0), new XO.o(1, 0, 0), new XO.o(0, 0, -1)), new CO("front", new XO.o(0, 0, 1), new XO.o(1, 0, 0), new XO.o(0, -1, 0)), new CO("back", new XO.o(0, 0, -1), new XO.o(-1, 0, 0), new XO.o(0, -1, 0))], hO.MAX_HDRI_VALUE = 4096, hO.PRESERVE_CLAMPED_COLORS = !1
  },
  39775: (OO, KO, pO) => {
    pO.d(KO, {
      DDSTools: () => FO
    });
    var XO = pO(35664),
      bK = pO(37061),
      eO = pO(39784),
      lO = pO(38140);
    const vK = 131072,
      CO = 131072;

    function hO(OO) {
      return OO.charCodeAt(0) + (OO.charCodeAt(1) << 8) + (OO.charCodeAt(2) << 16) + (OO.charCodeAt(3) << 24)
    }
    const DO = hO("DXT1"),
      MO = hO("DXT3"),
      aK = hO("DXT5"),
      oO = hO("DX10");
    class FO {
      static GetDDSInfo(OO) {
        const KO = new Int32Array(OO.buffer, OO.byteOffset, 31),
          pO = new Int32Array(OO.buffer, OO.byteOffset, 35);
        let XO = 1;
        KO[2] & vK && (XO = Math.max(1, KO[7]));
        const bK = KO[21],
          eO = bK === oO ? pO[32] : 0;
        let lO = 0;
        switch (bK) {
          case 113:
            lO = 2;
            break;
          case 116:
            lO = 1;
            break;
          case oO:
            if (10 === eO) {
              lO = 2;
              break
            }
            if (2 === eO) {
              lO = 1;
              break
            }
        }
        return {
          width: KO[4],
          height: KO[3],
          mipmapCount: XO,
          isFourCC: 4 === (4 & KO[20]),
          isRGB: 64 === (64 & KO[20]),
          isLuminance: (KO[20] & CO) === CO,
          isCube: 512 === (512 & KO[28]),
          isCompressed: bK === DO || bK === MO || bK === aK,
          dxgiFormat: eO,
          textureType: lO
        }
      }
      static _GetHalfFloatAsFloatRGBAArrayBuffer(OO, KO, pO, XO, bK, eO) {
        const vK = new Float32Array(XO),
          CO = new Uint16Array(bK, pO);
        let hO = 0;
        for (let DO = 0; DO < KO; DO++)
          for (let KO = 0; KO < OO; KO++) {
            const pO = 4 * (KO + DO * OO);
            vK[hO] = (0, lO.d)(CO[pO]), vK[hO + 1] = (0, lO.d)(CO[pO + 1]), vK[hO + 2] = (0, lO.d)(CO[pO + 2]), FO.StoreLODInAlphaChannel ? vK[hO + 3] = eO : vK[hO + 3] = (0, lO.d)(CO[pO + 3]), hO += 4
          }
        return vK
      }
      static _GetHalfFloatRGBAArrayBuffer(OO, KO, pO, XO, bK, eO) {
        if (FO.StoreLODInAlphaChannel) {
          const vK = new Uint16Array(XO),
            CO = new Uint16Array(bK, pO);
          let hO = 0;
          for (let pO = 0; pO < KO; pO++)
            for (let KO = 0; KO < OO; KO++) {
              const XO = 4 * (KO + pO * OO);
              vK[hO] = CO[XO], vK[hO + 1] = CO[XO + 1], vK[hO + 2] = CO[XO + 2], vK[hO + 3] = (0, lO.i)(eO), hO += 4
            }
          return vK
        }
        return new Uint16Array(bK, pO, XO)
      }
      static _GetFloatRGBAArrayBuffer(OO, KO, pO, XO, bK, eO) {
        if (FO.StoreLODInAlphaChannel) {
          const lO = new Float32Array(XO),
            vK = new Float32Array(bK, pO);
          let CO = 0;
          for (let pO = 0; pO < KO; pO++)
            for (let KO = 0; KO < OO; KO++) {
              const XO = 4 * (KO + pO * OO);
              lO[CO] = vK[XO], lO[CO + 1] = vK[XO + 1], lO[CO + 2] = vK[XO + 2], lO[CO + 3] = eO, CO += 4
            }
          return lO
        }
        return new Float32Array(bK, pO, XO)
      }
      static _GetFloatAsHalfFloatRGBAArrayBuffer(OO, KO, pO, XO, bK, eO) {
        const vK = new Uint16Array(XO),
          CO = new Float32Array(bK, pO);
        let hO = 0;
        for (let DO = 0; DO < KO; DO++)
          for (let KO = 0; KO < OO; KO++) vK[hO] = (0, lO.i)(CO[hO]), vK[hO + 1] = (0, lO.i)(CO[hO + 1]), vK[hO + 2] = (0, lO.i)(CO[hO + 2]), FO.StoreLODInAlphaChannel ? vK[hO + 3] = (0, lO.i)(eO) : vK[hO + 3] = (0, lO.i)(CO[hO + 3]), hO += 4;
        return vK
      }
      static _GetFloatAsUIntRGBAArrayBuffer(OO, KO, pO, bK, eO, lO) {
        const vK = new Uint8Array(bK),
          CO = new Float32Array(eO, pO);
        let hO = 0;
        for (let DO = 0; DO < KO; DO++)
          for (let KO = 0; KO < OO; KO++) {
            const pO = 4 * (KO + DO * OO);
            vK[hO] = 255 * (0, XO.Clamp)(CO[pO]), vK[hO + 1] = 255 * (0, XO.Clamp)(CO[pO + 1]), vK[hO + 2] = 255 * (0, XO.Clamp)(CO[pO + 2]), FO.StoreLODInAlphaChannel ? vK[hO + 3] = lO : vK[hO + 3] = 255 * (0, XO.Clamp)(CO[pO + 3]), hO += 4
          }
        return vK
      }
      static _GetHalfFloatAsUIntRGBAArrayBuffer(OO, KO, pO, bK, eO, vK) {
        const CO = new Uint8Array(bK),
          hO = new Uint16Array(eO, pO);
        let DO = 0;
        for (let MO = 0; MO < KO; MO++)
          for (let KO = 0; KO < OO; KO++) {
            const pO = 4 * (KO + MO * OO);
            CO[DO] = 255 * (0, XO.Clamp)((0, lO.d)(hO[pO])), CO[DO + 1] = 255 * (0, XO.Clamp)((0, lO.d)(hO[pO + 1])), CO[DO + 2] = 255 * (0, XO.Clamp)((0, lO.d)(hO[pO + 2])), FO.StoreLODInAlphaChannel ? CO[DO + 3] = vK : CO[DO + 3] = 255 * (0, XO.Clamp)((0, lO.d)(hO[pO + 3])), DO += 4
          }
        return CO
      }
      static _GetRGBAArrayBuffer(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        const hO = new Uint8Array(XO),
          DO = new Uint8Array(bK, pO);
        let MO = 0;
        for (let aK = 0; aK < KO; aK++)
          for (let KO = 0; KO < OO; KO++) {
            const pO = 4 * (KO + aK * OO);
            hO[MO] = DO[pO + eO], hO[MO + 1] = DO[pO + lO], hO[MO + 2] = DO[pO + vK], hO[MO + 3] = DO[pO + CO], MO += 4
          }
        return hO
      }
      static _ExtractLongWordOrder(OO) {
        return 0 === OO || 255 === OO || -16777216 === OO ? 0 : 1 + FO._ExtractLongWordOrder(OO >> 8)
      }
      static _GetRGBArrayBuffer(OO, KO, pO, XO, bK, eO, lO, vK) {
        const CO = new Uint8Array(XO),
          hO = new Uint8Array(bK, pO);
        let DO = 0;
        for (let MO = 0; MO < KO; MO++)
          for (let KO = 0; KO < OO; KO++) {
            const pO = 3 * (KO + MO * OO);
            CO[DO] = hO[pO + eO], CO[DO + 1] = hO[pO + lO], CO[DO + 2] = hO[pO + vK], DO += 3
          }
        return CO
      }
      static _GetLuminanceArrayBuffer(OO, KO, pO, XO, bK) {
        const eO = new Uint8Array(XO),
          lO = new Uint8Array(bK, pO);
        let vK = 0;
        for (let CO = 0; CO < KO; CO++)
          for (let KO = 0; KO < OO; KO++) {
            const pO = KO + CO * OO;
            eO[vK] = lO[pO], vK++
          }
        return eO
      }
      static UploadDDSLevels(OO, KO, pO, XO, lO, CO) {
        let hO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : -1,
          VO = arguments.length > 7 ? arguments[7] : void 0,
          LO = !(arguments.length > 8 && void 0 !== arguments[8]) || arguments[8],
          QO = null;
        XO.sphericalPolynomial && (QO = []);
        const zK = !!OO.getCaps().s3tc;
        KO.generateMipMaps = lO;
        const AO = new Int32Array(pO.buffer, pO.byteOffset, 31);
        let fO, dO, TO, NO, IO, yK, gK, uO = 0,
          EO = 0,
          jK = 1;
        if (542327876 !== AO[0]) return void bK.b.Error("Invalid magic number in DDS header");
        if (!XO.isFourCC && !XO.isRGB && !XO.isLuminance) return void bK.b.Error("Unsupported format, must contain a FourCC, RGB or LUMINANCE code");
        if (XO.isCompressed && !zK) return void bK.b.Error("Compressed textures are not supported on this platform.");
        let YO = AO[22];
        NO = AO[1] + 4;
        let wO = !1;
        if (XO.isFourCC) switch (fO = AO[21], fO) {
          case DO:
            jK = 8, EO = 33777;
            break;
          case MO:
            jK = 16, EO = 33778;
            break;
          case aK:
            jK = 16, EO = 33779;
            break;
          case 113:
            wO = !0, YO = 64;
            break;
          case 116:
            wO = !0, YO = 128;
            break;
          case oO: {
            NO += 20;
            let OO = !1;
            switch (XO.dxgiFormat) {
              case 10:
                wO = !0, YO = 64, OO = !0;
                break;
              case 2:
                wO = !0, YO = 128, OO = !0;
                break;
              case 88:
                XO.isRGB = !0, XO.isFourCC = !1, YO = 32, OO = !0
            }
            if (OO) break
          }
          default:
            return void bK.b.Error(["Unsupported FourCC code:", (iK = fO, String.fromCharCode(255 & iK, iK >> 8 & 255, iK >> 16 & 255, iK >> 24 & 255))])
        }
        var iK;
        const rK = FO._ExtractLongWordOrder(AO[23]),
          PO = FO._ExtractLongWordOrder(AO[24]),
          mK = FO._ExtractLongWordOrder(AO[25]),
          sO = FO._ExtractLongWordOrder(AO[26]);
        wO && (EO = OO._getRGBABufferInternalSizedFormat(XO.textureType)), yK = 1, AO[2] & vK && !1 !== lO && (yK = Math.max(1, AO[7]));
        const HO = VO || 0,
          RO = OO.getCaps();
        for (let bK = HO; bK < CO; bK++) {
          for (dO = AO[4], TO = AO[3], gK = 0; gK < yK; ++gK) {
            if (-1 === hO || hO === gK) {
              const eO = -1 === hO ? gK : 0;
              if (!XO.isCompressed && XO.isFourCC) {
                KO.format = 5, uO = dO * TO * 4;
                let XO = null;
                if (OO._badOS || OO._badDesktopOS || !RO.textureHalfFloat && !RO.textureFloat) 128 === YO ? (XO = FO._GetFloatAsUIntRGBAArrayBuffer(dO, TO, pO.byteOffset + NO, uO, pO.buffer, eO), QO && 0 == eO && QO.push(FO._GetFloatRGBAArrayBuffer(dO, TO, pO.byteOffset + NO, uO, pO.buffer, eO))) : 64 === YO && (XO = FO._GetHalfFloatAsUIntRGBAArrayBuffer(dO, TO, pO.byteOffset + NO, uO, pO.buffer, eO), QO && 0 == eO && QO.push(FO._GetHalfFloatAsFloatRGBAArrayBuffer(dO, TO, pO.byteOffset + NO, uO, pO.buffer, eO))), KO.type = 0;
                else {
                  const OO = RO.textureFloat && (LO && RO.textureFloatLinearFiltering || !LO),
                    bK = RO.textureHalfFloat && (LO && RO.textureHalfFloatLinearFiltering || !LO),
                    lO = (128 === YO || 64 === YO && !bK) && OO ? 1 : (64 === YO || 128 === YO && !OO) && bK ? 2 : 0;
                  let vK, CO = null;
                  if (128 === YO) switch (lO) {
                    case 1:
                      vK = FO._GetFloatRGBAArrayBuffer, CO = null;
                      break;
                    case 2:
                      vK = FO._GetFloatAsHalfFloatRGBAArrayBuffer, CO = FO._GetFloatRGBAArrayBuffer;
                      break;
                    case 0:
                      vK = FO._GetFloatAsUIntRGBAArrayBuffer, CO = FO._GetFloatRGBAArrayBuffer
                  } else switch (lO) {
                    case 1:
                      vK = FO._GetHalfFloatAsFloatRGBAArrayBuffer, CO = null;
                      break;
                    case 2:
                      vK = FO._GetHalfFloatRGBAArrayBuffer, CO = FO._GetHalfFloatAsFloatRGBAArrayBuffer;
                      break;
                    case 0:
                      vK = FO._GetHalfFloatAsUIntRGBAArrayBuffer, CO = FO._GetHalfFloatAsFloatRGBAArrayBuffer
                  }
                  KO.type = lO, XO = vK(dO, TO, pO.byteOffset + NO, uO, pO.buffer, eO), QO && 0 == eO && QO.push(CO ? CO(dO, TO, pO.byteOffset + NO, uO, pO.buffer, eO) : XO)
                }
                XO && OO._uploadDataToTextureDirectly(KO, XO, bK, eO)
              } else if (XO.isRGB) KO.type = 0, 24 === YO ? (KO.format = 4, uO = dO * TO * 3, IO = FO._GetRGBArrayBuffer(dO, TO, pO.byteOffset + NO, uO, pO.buffer, rK, PO, mK), OO._uploadDataToTextureDirectly(KO, IO, bK, eO)) : (KO.format = 5, uO = dO * TO * 4, IO = FO._GetRGBAArrayBuffer(dO, TO, pO.byteOffset + NO, uO, pO.buffer, rK, PO, mK, sO), OO._uploadDataToTextureDirectly(KO, IO, bK, eO));
              else if (XO.isLuminance) {
                const XO = OO._getUnpackAlignement(),
                  lO = dO;
                uO = Math.floor((dO + XO - 1) / XO) * XO * (TO - 1) + lO, IO = FO._GetLuminanceArrayBuffer(dO, TO, pO.byteOffset + NO, uO, pO.buffer), KO.format = 1, KO.type = 0, OO._uploadDataToTextureDirectly(KO, IO, bK, eO)
              } else uO = Math.max(4, dO) / 4 * Math.max(4, TO) / 4 * jK, IO = new Uint8Array(pO.buffer, pO.byteOffset + NO, uO), KO.type = 0, OO._uploadCompressedDataToTextureDirectly(KO, EO, dO, TO, IO, bK, eO)
            }
            NO += YO ? dO * TO * (YO / 8) : uO, dO *= .5, TO *= .5, dO = Math.max(1, dO), TO = Math.max(1, TO)
          }
          if (void 0 !== VO) break
        }
        QO && QO.length > 0 ? XO.sphericalPolynomial = eO.b.ConvertCubeMapToSphericalPolynomial({
          size: AO[4],
          right: QO[0],
          left: QO[1],
          up: QO[2],
          down: QO[3],
          front: QO[4],
          back: QO[5],
          format: 5,
          type: 1,
          gammaSpace: !1
        }) : XO.sphericalPolynomial = void 0
      }
    }
    FO.StoreLODInAlphaChannel = !1
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);