export const id = 78;
export const ids = [78];
export const modules = {
  41309: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      DOCS_AGENT_PART_CHARS: () => sK.e,
      DOCS_LLMS_FULL_TXT_PATH: () => sK.h,
      DOCS_LLMS_TXT_PATH: () => sK.i,
      DOCS_LLMS_TXT_URL: () => sK.j,
      ROOT_LLMS_TXT_PATH: () => sK.m,
      allGamemodeSettings: () => XO.e,
      arcadeModeStaticConfig: () => LO.c,
      arenaStaticConfig: () => eK,
      backroomsStaticConfig: () => bp.e,
      battleBoxStaticConfig: () => hK,
      bedwarsStaticConfig: () => YO.b,
      bloxdAggregatorConfig: () => vK.b,
      bloxdK12AggregatorConfig: () => CO.e,
      bloxdPreprodAggregatorConfig: () => hO.d,
      bloxdStagingAggregatorConfig: () => DO.e,
      bridgeBattleStaticConfig: () => JO.b,
      captureTheFlagStaticConfig: () => FK,
      classicStaticConfig: () => rK.d,
      clutchStaticConfig: () => nO.c,
      conquerorStaticConfig: () => oK,
      containmentBreachStaticConfig: () => KK.c,
      cookingStaticConfig: () => ZO.d,
      coolMathGamesAggregatorConfig: () => MO.e,
      coreDefendersStaticConfig: () => OK.d,
      crazyGamesNinetyNineNightsBundle: () => aK.e,
      ctfStaticConfig: () => ap,
      customGameSettings: () => XO.h,
      customGamesListingHeading: () => PK.c,
      customGamesListingPath: () => PK.e,
      defusalStaticConfig: () => MK,
      docsPageHtmlPath: () => sK.o,
      docsPageMarkdownPath: () => sK.s,
      docsPagePartPath: () => sK.t,
      docsPageTitles: () => gp.b,
      docsSitePageMarkdownPath: () => sK.u,
      dodgeBowStaticConfig: () => CK,
      doodleStaticConfig: () => EO.d,
      dressUpStaticConfig: () => WO.c,
      eatToGrowStaticConfig: () => XK.e,
      escapeHtml: () => gp.c,
      eviltowerStaticConfig: () => AO.d,
      exampleStaticConfig: () => QO.c,
      extractionStaticConfig: () => GO.c,
      firstPartyStudioGames: () => eO.d,
      fishingStaticConfig: () => VO.c,
      gameImageVariantHeights: () => IK.b,
      gameImageVariantsEncoding: () => NK.c,
      getAllAggregatorGameNames: () => lO.e,
      getConfiguredGameImagePaths: () => yp.d,
      getCustomGameFromPath: () => gp.d,
      getCustomGameListingPage: () => PK.g,
      getCustomGamePagePath: () => gp.h,
      getCustomGamePageRedirectPath: () => gp.k,
      getCustomGameSchematicIdFromPath: () => gp.l,
      getCustomGameThumbnailCandidates: () => fK.e,
      getCustomGameThumbnailUrls: () => fK.f,
      getCustomGameUrlIdFromPath: () => gp.o,
      getFirstPartyStudioGameName: () => eO.e,
      getGameCanonicalUrl: () => gp.q,
      getGameImageBlurhash: () => dK.c,
      getGameImagePath: () => yp.e,
      getGameImageVariantPath: () => IK.i,
      getGameImageVariantSource: () => TK.b,
      getGameImageVariants: () => TK.f,
      getGamePage: () => gp.B,
      getGamePageContentHeadings: () => uK.g,
      getGamePagePath: () => gp.u,
      getGamePageRedirectPath: () => gp.x,
      getGameSeoMetadata: () => gp.F,
      getGameTileImagePaths: () => TK.i,
      getIndexedCustomGameListingPaths: () => PK.i,
      getIndexedGamePages: () => gp.H,
      getJsonLdScriptText: () => gp.K,
      getPathGamePageContentGame: () => gp.O,
      getPathSeoMetadata: () => gp.R,
      getPlayableGame: () => bK,
      getPlayerSeoMetadata: () => gp.T,
      getSeoMetaTagAttributes: () => gp.V,
      getShaderPackPolicy: () => XO.l,
      getStaticGameConfig: () => XO.p,
      getStaticPageSeoMetadata: () => gp.Z,
      getUndescribedPageSeoMetadata: () => gp.$,
      goalRushStaticConfig: () => kK.e,
      goldrushStaticConfig: () => lK,
      greenvilleStaticConfig: () => jK.c,
      heroesvbrainrotsStaticConfig: () => UO.e,
      hideseekStaticConfig: () => iK.c,
      infectionStaticConfig: () => PO.c,
      isGameIndexed: () => gp.ab,
      knockoutStaticConfig: () => xK.e,
      lastStandStaticConfig: () => RO.b,
      loadGamePageContent: () => uK.h,
      luckyBattlegroundsStaticConfig: () => uO.e,
      luckyTowersStaticConfig: () => gK.d,
      murderMysteryStaticConfig: () => wO.b,
      naturalDisasterStaticConfig: () => sO.b,
      ninetyNineNightsStaticConfig: () => HO.b,
      normaliseFirstPartyGameNames: () => eO.i,
      oneBlockStaticConfig: () => fO.c,
      paintballStaticConfig: () => mK.c,
      parkourStaticConfig: () => oO.c,
      petSimulatorStaticConfig: () => DK,
      piratesStaticConfig: () => IO.c,
      plotsStaticConfig: () => NO.b,
      prisonStaticConfig: () => AK,
      pvpCivStaticConfig: () => pK.b,
      racingStaticConfig: () => zp,
      rankedStaticConfig: () => cK.b,
      readDocsPageMarkdownPath: () => sK.x,
      renderGamePageContentHtml: () => rp,
      renderSeoMetaTags: () => gp.bb,
      rocketParkourStaticConfig: () => SO.d,
      rocketSpleefStaticConfig: () => yK.b,
      seoSiteOrigin: () => mp.e,
      shootingStaticConfig: () => FO.b,
      simonSaysStaticConfig: () => qK.d,
      skyIslandsStaticConfig: () => tK.e,
      skyblockStaticConfig: () => dO.e,
      skywarsStaticConfig: () => TO.e,
      survivalRoyaleStaticConfig: () => VK,
      testGymStaticConfig: () => zK.b,
      thePitStaticConfig: () => QK,
      tsunamiStaticConfig: () => BO.d,
      uchStaticConfig: () => LK,
      wallsStaticConfig: () => vp
    });
    var XO = pO(638);

    function bK(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = (0, XO.p)(OO)) || void 0 === pO ? void 0 : pO.defaultListedVariation) && void 0 !== KO ? KO : OO
    }
    var eO = pO(881),
      lO = pO(906),
      vK = pO(630),
      CO = pO(627),
      hO = pO(614),
      DO = pO(619),
      MO = pO(609),
      aK = pO(604),
      oO = pO(648),
      FO = pO(683),
      VO = pO(651),
      LO = pO(657),
      QO = pO(665),
      zK = pO(674),
      AO = pO(687),
      fO = pO(691),
      dO = pO(694),
      TO = pO(707),
      NO = pO(714),
      IO = pO(719),
      yK = pO(724),
      gK = pO(728),
      uO = pO(732),
      EO = pO(741),
      jK = pO(748),
      YO = pO(752),
      wO = pO(754),
      iK = pO(760),
      rK = pO(763),
      PO = pO(767),
      mK = pO(769),
      sO = pO(773),
      HO = pO(779),
      RO = pO(786),
      SO = pO(789),
      JO = pO(793),
      cK = pO(797),
      BO = pO(801),
      ZO = pO(803),
      GO = pO(806),
      qK = pO(813),
      xK = pO(819),
      nO = pO(824),
      WO = pO(831),
      tK = pO(840),
      kK = pO(844),
      UO = pO(851),
      OK = pO(856),
      KK = pO(863),
      pK = pO(865),
      XK = pO(867),
      bp = pO(873);
    const eK = {
        type: "Arena",
        title: "Battle Arena",
        description: "Fight for glory in a 2v2v2v2v2v2v2v2 arena!",
        smallPicture: "battle_arena",
        thumbnailUseLongRatio: !1,
        badges: [{
          type: "limitedTimeGame"
        }],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      lK = {
        type: "Arena",
        title: "Goldrush",
        description: "Who is the best miner?\nMine gold and deposit it at your spawn, but beware of others killing you",
        smallPicture: "goldrushThumbnail",
        largePicture: "goldrushThumbnailLarge",
        thumbnailUseLongRatio: !1,
        badges: [{
          type: "limitedTimeGame"
        }],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      vp = {
        type: "Arena",
        title: "Walls",
        description: "Prepare with your team before the walls comes down and you need to fight to the death!",
        smallPicture: "wallsThumbnail2",
        thumbnailUseLongRatio: !1,
        badges: [],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      CK = {
        type: "Arena",
        title: "Dodge Bow",
        description: "Runners use speed and cover to survive until the timer ends. Hunters use bows, trying to eliminate all runners before time runs out.",
        smallPicture: "image-c",
        thumbnailUseLongRatio: !1,
        badges: [],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        firebaseConfig: {
          apiKey: "AIzaSyCJ-G6m_NyA3P021v-ugDmMmkcKysUebSE",
          projectId: "bloxd-ee1aa",
          storageBucket: "bloxd-ee1aa.appspot.com",
          messagingSenderId: "758847442742",
          appId: "1:758847442742:web:65e726de81c0cd0bf02d97",
          measurementId: "G-KYV287K7XD"
        },
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      hK = {
        type: "Arena",
        title: "BattleBox",
        description: "Battle other teams in rounds!",
        largePicture: "bloxd_battlebox_thumbnail_large",
        smallPicture: "bloxd_battlebox_thumbnail_small",
        thumbnailUseLongRatio: !1,
        badges: [{
          type: "limitedTimeGame"
        }],
        countdownInformation: {
          type: "releaseCountdown",
          previewText: "general:comingSoon",
          countdownStartTime: new Date("2025-08-13T12:00:00Z"),
          countdownToTime: new Date("2025-08-18T13:30:00Z")
        },
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        gameMonId: ""
      },
      DK = {
        type: "Simulator",
        title: "game:petSim",
        description: "game:petSimDescription",
        smallPicture: "bloxd_pet_sim_thumbnail_small_1",
        largePicture: "bloxd_pet_sim_thumbnail_large_1",
        thumbnailUseLongRatio: !1,
        badges: [{
          type: "limitedTimeGame"
        }],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      MK = {
        type: "Shooting",
        title: "Defusal",
        description: "Defuse or detonate the spike!",
        smallPicture: "thumbnail",
        thumbnailUseLongRatio: !1,
        badges: [],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      ap = {
        type: "Arena",
        title: "Capture the Flag",
        description: "Classic 'Capture the Flag' with kits.",
        smallPicture: "ctf",
        thumbnailUseLongRatio: !1,
        badges: [],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: []
      },
      oK = {
        type: "Arena",
        title: "Conqueror",
        description: "Make tactical choices to conquer your enemies!",
        smallPicture: "duos_combined_pic",
        thumbnailUseLongRatio: !1,
        badges: [],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        firebaseConfig: {
          apiKey: "AIzaSyCJ-G6m_NyA3P021v-ugDmMmkcKysUebSE",
          projectId: "bloxd-ee1aa",
          storageBucket: "bloxd-ee1aa.appspot.com",
          messagingSenderId: "758847442742",
          appId: "1:758847442742:web:c3d095738f8bde05f02d97",
          measurementId: "G-SCYFMGGGEW"
        },
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      FK = {
        type: "Arena",
        title: "Capture the Flag",
        description: "Capture the flag to win! It's that simple!",
        smallPicture: "bloxd_capture_the_flag_thumbnail_small",
        largePicture: "bloxd_capture_the_flag_thumbnail_large",
        thumbnailUseLongRatio: !1,
        badges: [{
          type: "limitedTimeGame"
        }],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: []
      },
      VK = {
        type: "Survival",
        title: "Survival Royale",
        description: "Fortnite but way better ofc ;)",
        smallPicture: "survivalRoyale",
        thumbnailUseLongRatio: !1,
        badges: [],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      LK = {
        type: "Parkour",
        title: "Parkour Builder",
        description: "Race through a parkour map with a twist - each round, you get to add a new block to the course!",
        smallPicture: "uchThumbnail",
        thumbnailUseLongRatio: !1,
        badges: [{
          type: "limitedTimeGame"
        }],
        visibleBetweenDates: {
          startDate: new Date("2025-10-24T14:00:00Z"),
          endDate: new Date("2025-10-25T14:00:00Z")
        },
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      QK = {
        type: "Arena",
        title: "The Pit",
        description: "Jump in the pit, beat everyone else!",
        smallPicture: "thePitThumbnail",
        thumbnailUseLongRatio: !1,
        badges: [],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      zp = {
        type: "Racing",
        title: "Rush Racing",
        description: "Compete against other players in a fast-paced racing game!",
        smallPicture: "racing_thumbnail_compressed",
        thumbnailUseLongRatio: !1,
        badges: [{
          type: "limitedTimeGame"
        }],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      },
      AK = {
        title: "Prison",
        type: "Roleplay",
        description: "Survive in maximum security prison!",
        smallPicture: "prison_thumbnail",
        thumbnailUseLongRatio: !1,
        badges: [],
        useRejoinLastLobbyButton: !1,
        additionalMetaTags: [],
        firebaseConfig: {
          apiKey: "AIzaSyCJ-G6m_NyA3P021v-ugDmMmkcKysUebSE",
          projectId: "bloxd-ee1aa",
          storageBucket: "bloxd-ee1aa.appspot.com",
          messagingSenderId: "758847442742",
          appId: "1:758847442742:web:bd6d1461bd147389f02d97",
          measurementId: "G-3NHZG8TJSS"
        },
        gameMonId: "wzap3u9jp9ki78o4dohtfdfnklxyci19"
      };
    var fK = pO(1390),
      dK = pO(1403),
      TK = pO(2755),
      NK = pO(2767),
      IK = pO(1396),
      yp = pO(2764),
      gp = pO(1382),
      uK = pO(1410);

    function EK(OO, KO, pO) {
      return `<${OO}><h2>${(0,gp.c)(KO)}</h2>${pO}</${OO}>`
    }

    function jp(OO) {
      return OO.map((OO => `<p>${(0,gp.c)(OO)}</p>`)).join("")
    }

    function YK(OO) {
      return `<ul>${OO.map((OO=>`<li>${OO}</li>`)).join("")}</ul>`
    }

    function wK(OO) {
      return YK(OO.map(gp.c))
    }

    function ip(OO, KO) {
      return YK(OO.similarGames.map((OO => {
        var pO, bK;
        const eO = null !== (pO = null === (bK = uK.e[OO]) || void 0 === bK ? void 0 : bK.name) && void 0 !== pO ? pO : KO(XO.e[OO].title);
        return `<a href="${(0,gp.c)((0,gp.u)(OO))}">${(0,gp.c)(eO)}</a>`
      })))
    }
    async function rp(OO, KO) {
      const pO = (0, gp.B)(OO);
      if (!pO) return null;
      const XO = await (0, uK.h)(pO),
        bK = (0, uK.g)(XO),
        eO = XO.faq.map((OO => {
          let {
            question: KO,
            answer: pO
          } = OO;
          return `<h3>${(0,gp.c)(KO)}</h3><p>${(0,gp.c)(pO)}</p>`
        })).join("");
      return `<main style="position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)"><article>${[`<header><h1>${(0,gp.c)(XO.name)}</h1><p>${(0,gp.c)(XO.description)}</p></header>`,EK("section",bK.whatIs,jp(XO.whatIs)),EK("section",bK.howToPlay,jp(XO.howToPlay)),EK("section",bK.features,wK(XO.features)),EK("aside",bK.tips,wK(XO.tips)),EK("section",bK.faq,eO),EK("nav",bK.similarGames,ip(XO,KO))].join("")}</article></main>`
    }
    var PK = pO(1408),
      mp = pO(1406),
      sK = pO(3964)
  },
  3964: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => CO,
      i: () => eO,
      j: () => lO,
      m: () => vK,
      o: () => LO,
      s: () => DO,
      t: () => MO,
      u: () => VO,
      x: () => oO
    });
    var XO = pO(1406);
    const bK = 24e3,
      eO = "/docs/llms.txt",
      lO = `${XO.e}${eO}`,
      vK = "/llms.txt",
      CO = "/docs/llms-full.txt";

    function hO(OO) {
      return OO || "index"
    }

    function DO(OO) {
      return `/docs/${hO(OO)}.md`
    }

    function MO(OO, KO) {
      return `/docs/${hO(OO)}/${KO+1}.md`
    }
    const aK = /^\/docs\/([a-z0-9-]+)(?:\/(\d+))?\.md$/;

    function oO(OO) {
      const KO = aK.exec(OO);
      return null === KO ? null : {
        name: KO[1],
        part: void 0 === KO[2] ? null : Number(KO[2])
      }
    }
    const FO = /^(?:\/studio)?\/docs(?:\/([a-z0-9-]+)(?:\/(\d+))?)?\/?$/;

    function VO(OO) {
      const KO = FO.exec(OO);
      if (null === KO) return null;
      const [, pO = "", XO] = KO;
      return void 0 === XO ? DO(pO) : MO(pO, Number(XO) - 1)
    }

    function LO(OO) {
      return `/docsHtml/${hO(OO)}.html`
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);