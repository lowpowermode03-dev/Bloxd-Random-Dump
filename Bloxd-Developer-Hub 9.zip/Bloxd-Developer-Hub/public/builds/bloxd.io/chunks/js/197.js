/*! For license information please see vjxd5n.197.3d908520.chunk.js.LICENSE.txt */
export const id = 197;
export const ids = [197];
export const modules = {
  37778: (OO, KO, pO) => {
    OO.exports = bK;
    var XO = pO(266);

    function bK(OO, KO) {
      if (!(this instanceof bK)) return new bK(OO, KO);
      var pO = XO.create();
      XO.add(pO, OO, KO), this.base = XO.min(XO.create(), OO, pO), this.vec = XO.clone(KO), this.max = XO.max(XO.create(), OO, pO), this.mag = XO.length(this.vec)
    }
    var eO = bK.prototype;
    eO.width = function() {
      return this.vec[0]
    }, eO.height = function() {
      return this.vec[1]
    }, eO.depth = function() {
      return this.vec[2]
    }, eO.x0 = function() {
      return this.base[0]
    }, eO.y0 = function() {
      return this.base[1]
    }, eO.z0 = function() {
      return this.base[2]
    }, eO.x1 = function() {
      return this.max[0]
    }, eO.y1 = function() {
      return this.max[1]
    }, eO.z1 = function() {
      return this.max[2]
    }, eO.translate = function(OO) {
      return XO.add(this.max, this.max, OO), XO.add(this.base, this.base, OO), this
    }, eO.setPosition = function(OO) {
      return XO.add(this.max, OO, this.vec), XO.copy(this.base, OO), this
    }, eO.expand = function(OO) {
      var KO = XO.create(),
        pO = XO.create();
      return XO.max(KO, OO.max, this.max), XO.min(pO, OO.base, this.base), XO.subtract(KO, KO, pO), new bK(pO, KO)
    }, eO.intersects = function(OO) {
      return !(OO.base[0] > this.max[0]) && (!(OO.base[1] > this.max[1]) && (!(OO.base[2] > this.max[2]) && (!(OO.max[0] < this.base[0]) && (!(OO.max[1] < this.base[1]) && !(OO.max[2] < this.base[2])))))
    }, eO.touches = function(OO) {
      var KO = this.union(OO);
      return null !== KO && (0 == KO.width() || 0 == KO.height() || 0 == KO.depth())
    }, eO.union = function(OO) {
      if (!this.intersects(OO)) return null;
      var KO = Math.max(OO.base[0], this.base[0]),
        pO = Math.max(OO.base[1], this.base[1]),
        XO = Math.max(OO.base[2], this.base[2]);
      return new bK([KO, pO, XO], [Math.min(OO.max[0], this.max[0]) - KO, Math.min(OO.max[1], this.max[1]) - pO, Math.min(OO.max[2], this.max[2]) - XO])
    }
  },
  35228: OO => {
    OO.exports = function OO(KO, pO) {
      if (KO === pO) return !0;
      if (KO && pO && "object" == typeof KO && "object" == typeof pO) {
        if (KO.constructor !== pO.constructor) return !1;
        var XO, bK, eO;
        if (Array.isArray(KO)) {
          if ((XO = KO.length) != pO.length) return !1;
          for (bK = XO; 0 !== bK--;)
            if (!OO(KO[bK], pO[bK])) return !1;
          return !0
        }
        if (KO.constructor === RegExp) return KO.source === pO.source && KO.flags === pO.flags;
        if (KO.valueOf !== Object.prototype.valueOf) return KO.valueOf() === pO.valueOf();
        if (KO.toString !== Object.prototype.toString) return KO.toString() === pO.toString();
        if ((XO = (eO = Object.keys(KO)).length) !== Object.keys(pO).length) return !1;
        for (bK = XO; 0 !== bK--;)
          if (!Object.prototype.hasOwnProperty.call(pO, eO[bK])) return !1;
        for (bK = XO; 0 !== bK--;) {
          var lO = eO[bK];
          if (!OO(KO[lO], pO[lO])) return !1
        }
        return !0
      }
      return KO !== KO && pO !== pO
    }
  },
  37774: OO => {
    OO.exports = function(OO, KO, pO, XO, bK, eO) {
      var lO = +KO[0],
        vK = +KO[1],
        CO = +KO[2],
        hO = +pO[0],
        DO = +pO[1],
        MO = +pO[2],
        aK = Math.sqrt(hO * hO + DO * DO + MO * MO);
      if (0 === aK) throw new Error("Can't raycast along a zero vector");
      return function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
        for (var DO = 0, MO = Math.floor, aK = 0 | MO(KO), oO = 0 | MO(pO), FO = 0 | MO(XO), VO = bK > 0 ? 1 : -1, LO = eO > 0 ? 1 : -1, QO = lO > 0 ? 1 : -1, zK = Math.abs(1 / bK), AO = Math.abs(1 / eO), fO = Math.abs(1 / lO), dO = zK < 1 / 0 ? zK * (VO > 0 ? aK + 1 - KO : KO - aK) : 1 / 0, TO = AO < 1 / 0 ? AO * (LO > 0 ? oO + 1 - pO : pO - oO) : 1 / 0, NO = fO < 1 / 0 ? fO * (QO > 0 ? FO + 1 - XO : XO - FO) : 1 / 0, IO = -1; DO <= vK;) {
          var yK = OO(aK, oO, FO);
          if (yK) return CO && (CO[0] = KO + DO * bK, CO[1] = pO + DO * eO, CO[2] = XO + DO * lO), hO && (hO[0] = hO[1] = hO[2] = 0, 0 === IO && (hO[0] = -VO), 1 === IO && (hO[1] = -LO), 2 === IO && (hO[2] = -QO)), yK;
          dO < TO ? dO < NO ? (aK += VO, DO = dO, dO += zK, IO = 0) : (FO += QO, DO = NO, NO += fO, IO = 2) : TO < NO ? (oO += LO, DO = TO, TO += AO, IO = 1) : (FO += QO, DO = NO, NO += fO, IO = 2)
        }
        return CO && (CO[0] = KO + DO * bK, CO[1] = pO + DO * eO, CO[2] = XO + DO * lO), hO && (hO[0] = hO[1] = hO[2] = 0), 0
      }(OO, lO, vK, CO, hO /= aK, DO /= aK, MO /= aK, XO = "undefined" === typeof XO ? 64 : +XO, bK, eO)
    }
  },
  37470: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      f: () => eO
    });
    var XO = pO(3357);
    let bK = null;

    function eO(OO) {
      return null !== bK && OO === bK
    }

    function lO() {
      this.PXO = !1, this.stopPropagation = !1, this.mbO = !1, this.disabled = !1
    }
    class vK {
      constructor(OO, KO) {
        this.version = "0.7.0";
        var pO = Object.assign({}, new lO, KO || {});
        this.element = OO || document, this.PXO = !!pO.PXO, this.stopPropagation = !!pO.stopPropagation, this.mbO = !!pO.mbO, this.disabled = !!pO.disabled, this.filterEvents = (OO, KO) => !0, this.down = new XO.EventEmitter, this.up = new XO.EventEmitter, this.state = {}, this.HXO = {
          dx: 0,
          dy: 0,
          tCO: 0,
          kCO: 0,
          UvO: 0
        }, this.pressCount = {}, this.releaseCount = {}, this._keyBindmap = {}, this._keyStates = {}, this._bindPressCount = {}, this._touches = {
          lastX: 0,
          lastY: 0,
          currID: null
        }, "loading" !== document.readyState ? hO(this) : document.addEventListener("DOMContentLoaded", (OO => {
          hO(this)
        }), {
          once: !0
        })
      }
      bind(OO) {
        for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
        pO.forEach((KO => {
          var pO = this._keyBindmap[KO] || [];
          pO.includes(OO) || (pO.push(OO), this._keyBindmap[KO] = pO)
        })), this.state[OO] = !!this.state[OO], this.pressCount[OO] = this.pressCount[OO] || 0, this.releaseCount[OO] = this.releaseCount[OO] || 0
      }
      unbind(OO) {
        for (var KO in this._keyBindmap) {
          var pO = this._keyBindmap[KO],
            XO = pO.indexOf(OO);
          XO > -1 && pO.splice(XO, 1)
        }
      }
      getBindings() {
        var OO = {};
        for (var KO in this._keyBindmap) {
          this._keyBindmap[KO].forEach((pO => {
            OO[pO] = OO[pO] || [], OO[pO].push(KO)
          }))
        }
        return OO
      }
      KK() {
        CO(this.HXO), CO(this.pressCount), CO(this.releaseCount)
      }
    }

    function CO(OO) {
      for (var KO in OO) OO[KO] = 0
    }

    function hO(OO) {
      window.addEventListener("keydown", LO.bind(null, OO, !0), !1), window.addEventListener("keyup", LO.bind(null, OO, !1), !1);
      var KO = {
        passive: !0
      };
      OO.element.addEventListener("touchstart", oO.bind(void 0, OO), {
        passive: !1
      }), OO.element.addEventListener("touchend", VO.bind(void 0, OO), KO), OO.element.addEventListener("mousedown", QO.bind(null, OO, !0), KO), window.document.addEventListener("mouseup", QO.bind(null, OO, !1), KO), OO.element.addEventListener("touchmove", zK.bind(null, OO), KO), OO.element.addEventListener("mousemove", zK.bind(null, OO), KO), window.PointerEvent, OO.element.addEventListener("wheel", AO.bind(null, OO), KO), OO.element.addEventListener("contextmenu", fO.bind(null, OO), !1), window.addEventListener("blur", NO.bind(null, OO), !1)
    }
    var DO = 0,
      MO = 0,
      aK = null;

    function oO(OO, KO) {
      KO.preventDefault(), FO(KO)
    }

    function FO(OO) {
      let KO = !1;
      for (let pO = 0; pO < OO.touches.length; ++pO)
        if (OO.touches[pO].identifier === aK) {
          KO = !0;
          break
        } if (!KO) {
        const KO = OO.changedTouches[0];
        DO = KO.clientX, MO = KO.clientY, aK = KO.identifier
      }
    }

    function VO(OO, KO) {
      for (var pO = KO.changedTouches, XO = 0; XO < pO.length; ++XO) pO[XO].identifier === aK && (aK = null)
    }

    function LO(OO, KO, pO) {
      try {
        IO(OO, pO), KO && pO.isTrusted && !pO.repeat && OO._keyStates[pO.code] && yK(OO, pO.code)
      } finally {
        gK(pO.code, KO, OO, pO)
      }
    }

    function QO(OO, KO, pO) {
      try {
        IO(OO, pO)
      } finally {
        ! function(OO, KO, pO) {
          if ("pointerId" in pO)
            if (KO) {
              if (null !== OO._touches.currID) return;
              OO._touches.currID = pO.pointerId
            } else {
              if (OO._touches.currID !== pO.pointerId) return;
              OO._touches.currID = null
            } var XO = "button" in pO ? pO.button + 1 : 1;
          gK("Mouse" + XO, KO, OO, pO)
        }(OO, KO, pO)
      }
    }

    function zK(OO, KO) {
      var pO = KO.movementX || KO.mozMovementX || 0,
        XO = KO.movementY || KO.mozMovementY || 0;
      if (KO.touches && 0 === (pO | XO)) {
        var bK = function(OO) {
          FO(OO);
          for (let KO = 0; KO < OO.changedTouches.length; ++KO)
            if (OO.changedTouches[KO].identifier == aK) {
              const pO = OO.changedTouches[KO],
                XO = [pO.clientX - DO, pO.clientY - MO];
              return DO = pO.clientX, MO = pO.clientY, XO
            } return console.error(`Did not find touch id ${aK}`), [0, 0]
        }(KO);
        pO = bK[0], XO = bK[1]
      }
      OO.HXO.dx += pO, OO.HXO.dy += XO
    }

    function AO(OO, KO) {
      IO(OO, KO);
      var pO = 1;
      switch (KO.deltaMode) {
        case 0:
          pO = 1;
          break;
        case 1:
          pO = 12;
          break;
        case 2:
          pO = OO.element.clientHeight || window.innerHeight
      }
      OO.HXO.tCO += (KO.deltaX || 0) * pO, OO.HXO.kCO += (KO.deltaY || 0) * pO, OO.HXO.UvO += (KO.deltaZ || 0) * pO
    }

    function fO(OO, KO) {
      if (!OO.mbO) return KO.preventDefault(), !1
    }
    var dO = {
      AltLeft: "altKey",
      AltRight: "altKey",
      ControlLeft: "ctrlKey",
      ControlRight: "ctrlKey",
      ShiftLeft: "shiftKey",
      ShiftRight: "shiftKey",
      MetaLeft: "metaKey",
      MetaRight: "metaKey"
    };

    function TO(OO, KO) {
      return !!OO[dO[KO]] || ("AltRight" === KO || "ControlLeft" === KO) && "function" === typeof OO.getModifierState && !0 === OO.getModifierState("AltGraph")
    }

    function NO(OO, KO) {
      for (var pO in OO._modifiersHeldThroughBlur = {}, dO) OO._keyStates[pO] && (OO._modifiersHeldThroughBlur[pO] = !0);
      KO && KO.isTrusted && function() {
        try {
          return window.self !== window.top
        } catch (OO) {
          return !0
        }
      }() && (clearTimeout(OO._blurRelease), OO._blurRelease = setTimeout((function() {
        if (!document.hasFocus())
          for (var KO in OO._modifiersHeldThroughBlur = {}, OO._keyStates) OO._keyStates[KO] && !/^Mouse\d/.test(KO) && yK(OO, KO)
      }), 0))
    }

    function IO(OO, KO) {
      var pO = OO._modifiersHeldThroughBlur;
      if (pO && KO.isTrusted && document.hasFocus())
        for (var XO in pO) delete pO[XO], OO._keyStates[XO] && XO !== KO.code && (TO(KO, XO) || yK(OO, XO))
    }

    function yK(OO, KO) {
      const pO = {
          code: KO,
          preventDefault: () => {},
          stopPropagation: () => {}
        },
        XO = bK;
      bK = pO;
      try {
        gK(KO, !1, OO, pO)
      } finally {
        bK = XO
      }
    }

    function gK(OO, KO, pO, XO) {
      var bK = pO._keyBindmap[OO];
      bK && (uO(pO._keyStates[OO], KO) && (pO._keyStates[OO] = KO, bK.forEach((OO => {
        (!pO.filterEvents || pO.filterEvents(XO, OO)) && function(OO, KO, pO, XO) {
          var bK = KO ? pO.pressCount : pO.releaseCount;
          bK[OO] = (bK[OO] || 0) + 1;
          var eO = pO._bindPressCount[OO] || 0;
          (eO += KO ? 1 : -1) < 0 && (eO = 0);
          pO._bindPressCount[OO] = eO;
          var lO = pO.state[OO];
          if (uO(lO, eO)) {
            pO.state[OO] = eO > 0;
            var vK = KO ? pO.down : pO.up;
            pO.disabled || vK.emit(OO, XO)
          }
        }(OO, KO, pO, XO)
      }))), "button" in XO || (pO.PXO && !XO.defaultPrevented && XO.preventDefault(), pO.stopPropagation && XO.stopPropagation()))
    }

    function uO(OO, KO) {
      return OO ? !KO : KO
    }
  },
  35088: (OO, KO) => {
    function pO(OO) {
      if (OO && "object" === typeof OO) {
        var KO = OO.which || OO.keyCode || OO.charCode;
        KO && (OO = KO)
      }
      if ("number" === typeof OO) return lO[OO];
      var pO, eO = String(OO);
      return (pO = XO[eO.toLowerCase()]) ? pO : (pO = bK[eO.toLowerCase()]) || (1 === eO.length ? eO.charCodeAt(0) : void 0)
    }
    pO.isEventKey = function(OO, KO) {
      if (OO && "object" === typeof OO) {
        var pO = OO.which || OO.keyCode || OO.charCode;
        if (null === pO || void 0 === pO) return !1;
        if ("string" === typeof KO) {
          var eO;
          if (eO = XO[KO.toLowerCase()]) return eO === pO;
          if (eO = bK[KO.toLowerCase()]) return eO === pO
        } else if ("number" === typeof KO) return KO === pO;
        return !1
      }
    };
    var XO = (KO = OO.exports = pO).code = KO.codes = {
        backspace: 8,
        tab: 9,
        enter: 13,
        shift: 16,
        ctrl: 17,
        alt: 18,
        "pause/break": 19,
        "caps lock": 20,
        esc: 27,
        space: 32,
        "page up": 33,
        "page down": 34,
        end: 35,
        home: 36,
        left: 37,
        up: 38,
        right: 39,
        down: 40,
        insert: 45,
        delete: 46,
        command: 91,
        "left command": 91,
        "right command": 93,
        "numpad *": 106,
        "numpad +": 107,
        "numpad -": 109,
        "numpad .": 110,
        "numpad /": 111,
        "num lock": 144,
        "scroll lock": 145,
        "my computer": 182,
        "my calculator": 183,
        ";": 186,
        "=": 187,
        ",": 188,
        "-": 189,
        ".": 190,
        "/": 191,
        "`": 192,
        "[": 219,
        "\\": 220,
        "]": 221,
        "'": 222
      },
      bK = KO.aliases = {
        windows: 91,
        "\u21e7": 16,
        "\u2325": 18,
        "\u2303": 17,
        "\u2318": 91,
        ctl: 17,
        control: 17,
        option: 18,
        pause: 19,
        break: 19,
        caps: 20,
        return: 13,
        escape: 27,
        spc: 32,
        spacebar: 32,
        pgup: 33,
        pgdn: 34,
        ins: 45,
        del: 46,
        cmd: 91
      };
    for (eO = 97; eO < 123; eO++) XO[String.fromCharCode(eO)] = eO - 32;
    for (var eO = 48; eO < 58; eO++) XO[eO - 48] = eO;
    for (eO = 1; eO < 13; eO++) XO["f" + eO] = eO + 111;
    for (eO = 0; eO < 10; eO++) XO["numpad " + eO] = eO + 96;
    var lO = KO.names = KO.title = {};
    for (eO in XO) lO[XO[eO]] = eO;
    for (var vK in bK) XO[vK] = bK[vK]
  },
  37767: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    class XO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10;
        this.TpO = !1, this.NpO = !1, this.RKO = 30, this.zXO = 0, this.yXO = 100, this.nl = !1, this.fullscreen = !1, this.xV = function(OO) {}, this.gXO = function(OO, KO, pO) {}, this.jXO = function() {}, this.tV = function() {}, this.upK = function() {}, this.onFullscreenChanged = function() {}, this.onPointerLockError = function(OO) {}, this._data = new bK(KO),
          function(OO) {
            if ("loading" === document.readyState) {
              var KO = () => {
                document.removeEventListener("readystatechange", KO), OO()
              };
              document.addEventListener("readystatechange", KO)
            } else setTimeout(OO, 0)
          }((() => {
            ! function(OO) {
              var KO = OO._data,
                pO = KO.nowObject.now();
              KO.lastTickStarted = pO, KO.lastFrameStarted = pO, KO.lastRenderStarted = pO, KO.frameCB = () => function(OO) {
                var KO = OO._data;
                requestAnimationFrame(KO.frameCB), vK(OO);
                var pO = KO.nowObject.now(),
                  XO = pO - KO.lastFrameStarted;
                if (KO.lastFrameStarted = pO, OO.zXO > 0) {
                  KO.renderAccum += XO;
                  var bK = 1e3 / OO.zXO;
                  if (KO.renderAccum < bK) return;
                  KO.renderAccum -= bK, KO.renderAccum > bK && (KO.renderAccum = bK)
                }
                var eO = pO - KO.lastRenderStarted;
                KO.lastRenderStarted = pO;
                var lO = 1e3 / OO.RKO,
                  CO = (pO - KO.lastTickStarted) / lO;
                CO < 0 && (CO = 0);
                OO.gXO(eO, CO, lO), setTimeout(vK, 0, OO, !0)
              }(OO), KO.intervalCB = () => vK(OO), requestAnimationFrame(KO.frameCB), KO.pollTime > 0 && (KO.intervalID = setInterval(KO.intervalCB, Math.max(KO.pollTime, 1e3 / OO.RKO / 2)))
            }(this),
            function(OO, KO) {
              if (!KO) return;
              var pO = !1,
                XO = !1,
                bK = OO => {
                  if (!!OO !== (pO = KO === document.pointerLockElement))
                    if (OO) {
                      var XO = KO.requestPointerLock();
                      XO && XO.catch && XO.catch((OO => {}))
                    } else document.exitPointerLock()
                },
                eO = OO => {
                  !!OO !== (XO = KO === document.fullscreenElement) && (OO ? KO.requestFullscreen ? KO.requestFullscreen() : KO.webkitRequestFullscreen && KO.webkitRequestFullscreen() : document.exitFullscreen ? document.exitFullscreen() : document.webkitExitFullscreen && document.webkitExitFullscreen())
                };
              document.addEventListener("pointerlockchange", (XO => {
                pO = KO === document.pointerLockElement, OO.upK(pO)
              })), document.addEventListener("fullscreenchange", (pO => {
                XO = KO === document.fullscreenElement, OO.onFullscreenChanged(XO)
              })), document.addEventListener("pointerlockerror", (XO => {
                pO = KO === document.pointerLockElement, OO.onPointerLockError(XO)
              })), Object.defineProperty(OO, "nl", {
                get: () => pO,
                set: bK
              }), Object.defineProperty(OO, "fullscreen", {
                get: () => XO,
                set: eO
              }), KO.addEventListener("click", (KO => {
                OO.TpO && bK(!0), OO.NpO && eO(!0)
              }));
              var lO = () => OO.tV();
              if (window.ResizeObserver) {
                new ResizeObserver(lO).observe(KO)
              } else window.addEventListener("resize", lO)
            }(this, OO), this.jXO()
          }))
      }
    }

    function bK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 10;
      this.nowObject = performance || Date, this.pollTime = OO, this.renderAccum = 0, this.lastTickStarted = 0, this.lastFrameStarted = 0, this.lastRenderStarted = 0, this.avgTickTime = 2, this.frameCB = null, this.intervalCB = null, this.intervalID = -1
    }
    var eO = 3,
      lO = 20;

    function vK(OO) {
      for (var KO = OO._data, pO = 1e3 / OO.RKO, XO = KO.nowObject.now() + lO, bK = 0; KO.nowObject.now() >= KO.lastTickStarted + pO && KO.nowObject.now() < XO && ++bK <= eO;) OO.xV(pO), KO.lastTickStarted += pO;
      var vK = 5 * (pO + 5),
        CO = KO.nowObject.now();
      if (CO - KO.lastTickStarted > vK)
        for (; CO >= KO.lastTickStarted + pO;) KO.lastTickStarted += pO
    }
  },
  35252: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO
    });
    var XO = pO(63);
    const bK = XO.useLayoutEffect;
    const eO = function(OO) {
      var KO = (0, XO.useRef)(OO);
      return bK((function() {
        KO.current = OO
      })), KO
    };
    var lO = function(OO) {
      var KO = eO(OO);
      (0, XO.useEffect)((function() {
        var OO = function(OO) {
          var pO;
          if (null != KO.current && (pO = KO.current(OO)), OO.defaultPrevented && (OO.returnValue = ""), "string" === typeof pO) return OO.returnValue = pO, pO
        };
        return window.addEventListener("beforeunload", OO),
          function() {
            window.removeEventListener("beforeunload", OO)
          }
      }), [])
    }
  },
  35116: OO => {
    var KO, pO = "undefined" !== typeof window ? window.navigator.userAgent : "",
      XO = /OS X/.test(pO),
      bK = /Opera/.test(pO),
      eO = !/like Gecko/.test(pO) && !bK,
      lO = OO.exports = {
        0: XO ? "<menu>" : "<UNK>",
        1: "<mouse 1>",
        2: "<mouse 2>",
        3: "<break>",
        4: "<mouse 3>",
        5: "<mouse 4>",
        6: "<mouse 5>",
        8: "<backspace>",
        9: "<tab>",
        12: "<clear>",
        13: "<enter>",
        16: "<shift>",
        17: "<control>",
        18: "<alt>",
        19: "<pause>",
        20: "<caps-lock>",
        21: "<ime-hangul>",
        23: "<ime-junja>",
        24: "<ime-final>",
        25: "<ime-kanji>",
        27: "<escape>",
        28: "<ime-convert>",
        29: "<ime-nonconvert>",
        30: "<ime-accept>",
        31: "<ime-mode-change>",
        32: "<space>",
        33: "<page-up>",
        34: "<page-down>",
        35: "<end>",
        36: "<home>",
        37: "<left>",
        38: "<up>",
        39: "<right>",
        40: "<down>",
        41: "<select>",
        42: "<print>",
        43: "<execute>",
        44: "<snapshot>",
        45: "<insert>",
        46: "<delete>",
        47: "<help>",
        91: "<meta>",
        92: "<meta>",
        93: XO ? "<meta>" : "<menu>",
        95: "<sleep>",
        106: "<num-*>",
        107: "<num-+>",
        108: "<num-enter>",
        109: "<num--\x3e",
        110: "<num-.>",
        111: "<num-/>",
        144: "<num-lock>",
        145: "<scroll-lock>",
        160: "<shift-left>",
        161: "<shift-right>",
        162: "<control-left>",
        163: "<control-right>",
        164: "<alt-left>",
        165: "<alt-right>",
        166: "<browser-back>",
        167: "<browser-forward>",
        168: "<browser-refresh>",
        169: "<browser-stop>",
        170: "<browser-search>",
        171: "<browser-favorites>",
        172: "<browser-home>",
        173: XO && eO ? "-" : "<volume-mute>",
        174: "<volume-down>",
        175: "<volume-up>",
        176: "<next-track>",
        177: "<prev-track>",
        178: "<stop>",
        179: "<play-pause>",
        180: "<launch-mail>",
        181: "<launch-media-select>",
        182: "<launch-app 1>",
        183: "<launch-app 2>",
        186: ";",
        187: "=",
        188: ",",
        189: "-",
        190: ".",
        191: "/",
        192: "`",
        219: "[",
        220: "\\",
        221: "]",
        222: "'",
        223: "<meta>",
        224: "<meta>",
        226: "<alt-gr>",
        229: "<ime-process>",
        231: bK ? "`" : "<unicode>",
        246: "<attention>",
        247: "<crsel>",
        248: "<exsel>",
        249: "<erase-eof>",
        250: "<play>",
        251: "<zoom>",
        252: "<no-name>",
        253: "<pa-1>",
        254: "<clear>"
      };
    for (KO = 58; KO < 65; ++KO) lO[KO] = String.fromCharCode(KO);
    for (KO = 48; KO < 58; ++KO) lO[KO] = KO - 48 + "";
    for (KO = 65; KO < 91; ++KO) lO[KO] = String.fromCharCode(KO);
    for (KO = 96; KO < 106; ++KO) lO[KO] = "<num-" + (KO - 96) + ">";
    for (KO = 112; KO < 136; ++KO) lO[KO] = "F" + (KO - 111)
  },
  37410: (OO, KO, pO) => {
    function XO(OO, KO, pO, XO, bK) {
      var eO = {};
      return Object.keys(XO).forEach((function(OO) {
        eO[OO] = XO[OO]
      })), eO.enumerable = !!eO.enumerable, eO.configurable = !!eO.configurable, ("value" in eO || eO.initializer) && (eO.writable = !0), eO = pO.slice().reverse().reduce((function(pO, XO) {
        return XO(OO, KO, pO) || pO
      }), eO), bK && void 0 !== eO.initializer && (eO.value = eO.initializer ? eO.initializer.call(bK) : void 0, eO.initializer = void 0), void 0 === eO.initializer && (Object.defineProperty(OO, KO, eO), eO = null), eO
    }
    pO.d(KO, {
      c: () => XO
    })
  },
  37402: (OO, KO, pO) => {
    function XO(OO, KO, pO, XO) {
      pO && Object.defineProperty(OO, KO, {
        enumerable: pO.enumerable,
        configurable: pO.configurable,
        writable: pO.writable,
        value: pO.initializer ? pO.initializer.call(XO) : void 0
      })
    }
    pO.d(KO, {
      e: () => XO
    })
  },
  37055: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(37061);
    const bK = (OO, KO, pO) => OO ? OO.getClassName && "Mesh" === OO.getClassName() ? null : !OO.getClassName || "SubMesh" !== OO.getClassName() && "PhysicsBody" !== OO.getClassName() ? OO.clone ? OO.clone() : Array.isArray(OO) ? OO.slice() : pO && "object" === typeof OO ? {
      ...OO
    } : null : OO.clone(KO) : null;
    class eO {
      static DeepCopy(OO, KO, pO, eO) {
        let lO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        const vK = function(OO) {
          const KO = [];
          do {
            const pO = Object.getOwnPropertyNames(OO);
            for (const OO of pO) - 1 === KO.indexOf(OO) && KO.push(OO)
          } while (OO = Object.getPrototypeOf(OO));
          return KO
        }(OO);
        for (const hO of vK) {
          if ("_" === hO[0] && (!eO || -1 === eO.indexOf(hO))) continue;
          if (hO.endsWith("Observable")) continue;
          if (pO && -1 !== pO.indexOf(hO)) continue;
          const vK = OO[hO],
            DO = typeof vK;
          if ("function" !== DO) try {
            if ("object" === DO)
              if (vK instanceof Uint8Array) KO[hO] = Uint8Array.from(vK);
              else if (vK instanceof Array) {
              if (KO[hO] = [], vK.length > 0)
                if ("object" == typeof vK[0])
                  for (let OO = 0; OO < vK.length; OO++) {
                    const pO = bK(vK[OO], KO, lO); - 1 === KO[hO].indexOf(pO) && KO[hO].push(pO)
                  } else KO[hO] = vK.slice(0)
            } else KO[hO] = bK(vK, KO, lO);
            else KO[hO] = vK
          } catch (CO) {
            XO.b.Warn(CO.message)
          }
        }
      }
    }
  },
  37085: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      h: () => eO,
      j: () => lO,
      k: () => vK
    });
    var XO = pO(35688);
    class bK {
      constructor(OO, KO, pO) {
        this.gradient = OO, this.color1 = KO, this.color2 = pO
      }
      getColorToRef(OO) {
        this.color2 ? XO.g.LerpToRef(this.color1, this.color2, Math.random(), OO) : OO.NhO(this.color1)
      }
    }
    class eO {
      constructor(OO, KO) {
        this.gradient = OO, this.color = KO
      }
    }
    class lO {
      constructor(OO, KO, pO) {
        this.gradient = OO, this.factor1 = KO, this.factor2 = pO
      }
      getFactor() {
        return void 0 === this.factor2 || this.factor2 === this.factor1 ? this.factor1 : this.factor1 + (this.factor2 - this.factor1) * Math.random()
      }
    }
    class vK {
      static GetCurrentGradient(OO, KO, pO) {
        if (KO[0].gradient > OO) return void pO(KO[0], KO[0], 1);
        for (let bK = 0; bK < KO.length - 1; bK++) {
          const XO = KO[bK],
            eO = KO[bK + 1];
          if (OO >= XO.gradient && OO <= eO.gradient) {
            return void pO(XO, eO, (OO - XO.gradient) / (eO.gradient - XO.gradient))
          }
        }
        const XO = KO.length - 1;
        pO(KO[XO], KO[XO], 1)
      }
    }
  },
  37061: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      static _CheckLimit(OO, KO) {
        let pO = XO._LogLimitOutputs[OO];
        return pO ? pO.current++ : (pO = {
          limit: KO,
          current: 1
        }, XO._LogLimitOutputs[OO] = pO), pO.current <= pO.limit
      }
      static _GenerateLimitMessage(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        const pO = XO._LogLimitOutputs[OO];
        if (!pO || !XO.MessageLimitReached) return;
        const bK = this._Levels[KO];
        pO.current === pO.limit && XO[bK.name](XO.MessageLimitReached.replace(/%LIMIT%/g, "" + pO.limit).replace(/%TYPE%/g, bK.name ?? ""))
      }
      static _AddLogEntry(OO) {
        XO._LogCache = OO + XO._LogCache, XO.OnNewCacheEntry && XO.OnNewCacheEntry(OO)
      }
      static _FormatMessage(OO) {
        const KO = OO => OO < 10 ? "0" + OO : "" + OO,
          pO = new Date;
        return "[" + KO(pO.getHours()) + ":" + KO(pO.getMinutes()) + ":" + KO(pO.getSeconds()) + "]: " + OO
      }
      static _LogDisabled(OO, KO) {}
      static _LogEnabled() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const bK = Array.isArray(KO) ? KO[0] : KO;
        if (void 0 !== pO && !XO._CheckLimit(bK, pO)) return;
        const eO = XO._FormatMessage(bK),
          lO = this._Levels[OO],
          vK = Array.isArray(KO) ? KO.slice(1) : [];
        lO.logFunc && lO.logFunc("BJS - " + eO, ...vK);
        const CO = `<div style='color:${lO.color}'>${eO}</div><br>`;
        XO._AddLogEntry(CO), XO._GenerateLimitMessage(bK, OO)
      }
      static get LogCache() {
        return XO._LogCache
      }
      static ClearLogCache() {
        XO._LogCache = "", XO._LogLimitOutputs = {}, XO.errorsCount = 0
      }
      static set LogLevels(OO) {
        XO.Log = XO._LogDisabled, XO.Warn = XO._LogDisabled, XO.Error = XO._LogDisabled;
        const KO = [XO.MessageLogLevel, XO.WarningLogLevel, XO.ErrorLogLevel];
        for (const pO of KO)
          if ((OO & pO) === pO) {
            const OO = this._Levels[pO];
            XO[OO.name] = XO._LogEnabled.bind(XO, pO)
          }
      }
    }
    XO.NoneLogLevel = 0, XO.MessageLogLevel = 1, XO.WarningLogLevel = 2, XO.ErrorLogLevel = 4, XO.AllLogLevel = 7, XO.MessageLimitReached = "Too many %TYPE%s (%LIMIT%), no more %TYPE%s will be reported for this message.", XO._LogCache = "", XO._LogLimitOutputs = {}, XO._Levels = [{}, {
      color: "white",
      logFunc: console.log,
      name: "Log"
    }, {
      color: "orange",
      logFunc: console.warn,
      name: "Warn"
    }, {}, {
      color: "red",
      logFunc: console.error,
      name: "Error"
    }], XO.errorsCount = 0, XO.Log = XO._LogEnabled.bind(XO, XO.MessageLogLevel), XO.Warn = XO._LogEnabled.bind(XO, XO.WarningLogLevel), XO.Error = XO._LogEnabled.bind(XO, XO.ErrorLogLevel)
  },
  37088: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO
    });
    var XO = pO(35632),
      bK = pO(35664),
      eO = pO(37055);
    class lO {
      constructor() {
        this.direction1 = new XO.o(0, 1, 0), this.direction2 = new XO.o(0, 1, 0), this.minEmitBox = new XO.o(-.5, -.5, -.5), this.maxEmitBox = new XO.o(.5, .5, .5)
      }
      startDirectionFunction(OO, KO, pO, eO) {
        const lO = (0, bK.RandomRange)(this.direction1.x, this.direction2.x),
          vK = (0, bK.RandomRange)(this.direction1.y, this.direction2.y),
          CO = (0, bK.RandomRange)(this.direction1.z, this.direction2.z);
        if (eO) return KO.x = lO, KO.y = vK, void(KO.z = CO);
        XO.o.TransformNormalFromFloatsToRef(lO, vK, CO, OO, KO)
      }
      startPositionFunction(OO, KO, pO, eO) {
        const lO = (0, bK.RandomRange)(this.minEmitBox.x, this.maxEmitBox.x),
          vK = (0, bK.RandomRange)(this.minEmitBox.y, this.maxEmitBox.y),
          CO = (0, bK.RandomRange)(this.minEmitBox.z, this.maxEmitBox.z);
        if (eO) return KO.x = lO, KO.y = vK, void(KO.z = CO);
        XO.o.TransformCoordinatesFromFloatsToRef(lO, vK, CO, OO, KO)
      }
      clone() {
        const OO = new lO;
        return eO.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {
        OO.setVector3("direction1", this.direction1), OO.setVector3("direction2", this.direction2), OO.setVector3("minEmitBox", this.minEmitBox), OO.setVector3("maxEmitBox", this.maxEmitBox)
      }
      buildUniformLayout(OO) {
        OO.addUniform("direction1", 3), OO.addUniform("direction2", 3), OO.addUniform("minEmitBox", 3), OO.addUniform("maxEmitBox", 3)
      }
      getEffectDefines() {
        return "#define BOXEMITTER"
      }
      getClassName() {
        return "BoxParticleEmitter"
      }
      serialize() {
        const OO = {};
        return OO.type = this.getClassName(), OO.direction1 = this.direction1.WhO(), OO.direction2 = this.direction2.WhO(), OO.minEmitBox = this.minEmitBox.WhO(), OO.maxEmitBox = this.maxEmitBox.WhO(), OO
      }
      parse(OO) {
        XO.o.FromArrayToRef(OO.direction1, 0, this.direction1), XO.o.FromArrayToRef(OO.direction2, 0, this.direction2), XO.o.FromArrayToRef(OO.minEmitBox, 0, this.minEmitBox), XO.o.FromArrayToRef(OO.maxEmitBox, 0, this.maxEmitBox)
      }
    }
  },
  37049: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      e: () => lO
    });
    var XO = pO(35632),
      bK = pO(35664),
      eO = pO(37055);
    class lO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
          bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        this.radius = OO, this.height = KO, this.radiusRange = pO, this.directionRandomizer = bK, this._tempVector = XO.o.Zero()
      }
      startDirectionFunction(OO, KO, pO, eO, lO) {
        pO.position.subtractToRef(OO.getTranslation(), this._tempVector), this._tempVector.normalize(), XO.o.TransformNormalToRef(this._tempVector, lO, this._tempVector);
        const vK = (0, bK.RandomRange)(-this.directionRandomizer / 2, this.directionRandomizer / 2);
        let CO = Math.atan2(this._tempVector.x, this._tempVector.z);
        CO += (0, bK.RandomRange)(-Math.PI / 2, Math.PI / 2) * this.directionRandomizer, this._tempVector.y = vK, this._tempVector.x = Math.sin(CO), this._tempVector.z = Math.cos(CO), this._tempVector.normalize(), eO ? KO.NhO(this._tempVector) : XO.o.TransformNormalFromFloatsToRef(this._tempVector.x, this._tempVector.y, this._tempVector.z, OO, KO)
      }
      startPositionFunction(OO, KO, pO, eO) {
        const lO = (0, bK.RandomRange)(-this.height / 2, this.height / 2),
          vK = (0, bK.RandomRange)(0, 2 * Math.PI),
          CO = (0, bK.RandomRange)((1 - this.radiusRange) * (1 - this.radiusRange), 1),
          hO = Math.sqrt(CO) * this.radius,
          DO = hO * Math.cos(vK),
          MO = hO * Math.sin(vK);
        eO ? KO.rvO(DO, lO, MO) : XO.o.TransformCoordinatesFromFloatsToRef(DO, lO, MO, OO, KO)
      }
      clone() {
        const OO = new lO(this.radius, this.directionRandomizer);
        return eO.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {
        OO.setFloat("radius", this.radius), OO.setFloat("height", this.height), OO.setFloat("radiusRange", this.radiusRange), OO.setFloat("directionRandomizer", this.directionRandomizer)
      }
      buildUniformLayout(OO) {
        OO.addUniform("radius", 1), OO.addUniform("height", 1), OO.addUniform("radiusRange", 1), OO.addUniform("directionRandomizer", 1)
      }
      getEffectDefines() {
        return "#define CYLINDEREMITTER"
      }
      getClassName() {
        return "CylinderParticleEmitter"
      }
      serialize() {
        const OO = {};
        return OO.type = this.getClassName(), OO.radius = this.radius, OO.height = this.height, OO.radiusRange = this.radiusRange, OO.directionRandomizer = this.directionRandomizer, OO
      }
      parse(OO) {
        this.radius = OO.radius, this.height = OO.height, this.radiusRange = OO.radiusRange, this.directionRandomizer = OO.directionRandomizer
      }
    }
    class vK extends lO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
          bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : new XO.o(0, 1, 0),
          eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : new XO.o(0, 1, 0);
        super(OO, KO, pO), this.direction1 = bK, this.direction2 = eO
      }
      startDirectionFunction(OO, KO, pO, eO) {
        const lO = (0, bK.RandomRange)(this.direction1.x, this.direction2.x),
          vK = (0, bK.RandomRange)(this.direction1.y, this.direction2.y),
          CO = (0, bK.RandomRange)(this.direction1.z, this.direction2.z);
        eO ? KO.rvO(lO, vK, CO) : XO.o.TransformNormalFromFloatsToRef(lO, vK, CO, OO, KO)
      }
      clone() {
        const OO = new vK(this.radius, this.height, this.radiusRange, this.direction1, this.direction2);
        return eO.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {
        OO.setFloat("radius", this.radius), OO.setFloat("height", this.height), OO.setFloat("radiusRange", this.radiusRange), OO.setVector3("direction1", this.direction1), OO.setVector3("direction2", this.direction2)
      }
      buildUniformLayout(OO) {
        OO.addUniform("radius", 1), OO.addUniform("height", 1), OO.addUniform("radiusRange", 1), OO.addUniform("direction1", 3), OO.addUniform("direction2", 3)
      }
      getEffectDefines() {
        return "#define CYLINDEREMITTER\n#define DIRECTEDCYLINDEREMITTER"
      }
      getClassName() {
        return "CylinderDirectedParticleEmitter"
      }
      serialize() {
        const OO = super.serialize();
        return OO.direction1 = this.direction1.WhO(), OO.direction2 = this.direction2.WhO(), OO
      }
      parse(OO) {
        super.parse(OO), XO.o.FromArrayToRef(OO.direction1, 0, this.direction1), XO.o.FromArrayToRef(OO.direction2, 0, this.direction2)
      }
    }
  },
  37159: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => MO
    });
    const XO = .5 * (Math.sqrt(3) - 1),
      bK = (3 - Math.sqrt(3)) / 6,
      eO = 1 / 3,
      lO = 1 / 6,
      vK = (Math.sqrt(5) - 1) / 4,
      CO = (5 - Math.sqrt(5)) / 20,
      hO = new Float32Array([1, 1, 0, -1, 1, 0, 1, -1, 0, -1, -1, 0, 1, 0, 1, -1, 0, 1, 1, 0, -1, -1, 0, -1, 0, 1, 1, 0, -1, 1, 0, 1, -1, 0, -1, -1]),
      DO = new Float32Array([0, 1, 1, 1, 0, 1, 1, -1, 0, 1, -1, 1, 0, 1, -1, -1, 0, -1, 1, 1, 0, -1, 1, -1, 0, -1, -1, 1, 0, -1, -1, -1, 1, 0, 1, 1, 1, 0, 1, -1, 1, 0, -1, 1, 1, 0, -1, -1, -1, 0, 1, 1, -1, 0, 1, -1, -1, 0, -1, 1, -1, 0, -1, -1, 1, 1, 0, 1, 1, 1, 0, -1, 1, -1, 0, 1, 1, -1, 0, -1, -1, 1, 0, 1, -1, 1, 0, -1, -1, -1, 0, 1, -1, -1, 0, -1, 1, 1, 1, 0, 1, 1, -1, 0, 1, -1, 1, 0, 1, -1, -1, 0, -1, 1, 1, 0, -1, 1, -1, 0, -1, -1, 1, 0, -1, -1, -1, 0]);
    const MO = class {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Math.random;
        const KO = "function" == typeof OO ? OO : function(OO) {
          let KO = 0,
            pO = 0,
            XO = 0,
            bK = 1;
          const eO = function() {
            let OO = 4022871197;
            return function(KO) {
              KO = KO.toString();
              for (let pO = 0; pO < KO.length; pO++) {
                OO += KO.charCodeAt(pO);
                let XO = .02519603282416938 * OO;
                OO = XO >>> 0, XO -= OO, XO *= OO, OO = XO >>> 0, XO -= OO, OO += 4294967296 * XO
              }
              return 2.3283064365386963e-10 * (OO >>> 0)
            }
          }();
          KO = eO(" "), pO = eO(" "), XO = eO(" "), KO -= eO(OO), KO < 0 && (KO += 1);
          pO -= eO(OO), pO < 0 && (pO += 1);
          XO -= eO(OO), XO < 0 && (XO += 1);
          return function() {
            const OO = 2091639 * KO + 2.3283064365386963e-10 * bK;
            return KO = pO, pO = XO, XO = OO - (bK = 0 | OO)
          }
        }(OO);
        this.p = function(OO) {
          const KO = new Uint8Array(256);
          for (let pO = 0; pO < 256; pO++) KO[pO] = pO;
          for (let pO = 0; pO < 255; pO++) {
            const XO = pO + ~~(OO() * (256 - pO)),
              bK = KO[pO];
            KO[pO] = KO[XO], KO[XO] = bK
          }
          return KO
        }(KO), this.perm = new Uint8Array(512), this.permMod12 = new Uint8Array(512);
        for (let pO = 0; pO < 512; pO++) this.perm[pO] = this.p[255 & pO], this.permMod12[pO] = this.perm[pO] % 12
      }
      noise2D(OO, KO) {
        const pO = this.permMod12,
          eO = this.perm;
        let lO = 0,
          vK = 0,
          CO = 0;
        const DO = (OO + KO) * XO,
          MO = Math.floor(OO + DO),
          aK = Math.floor(KO + DO),
          oO = (MO + aK) * bK,
          FO = OO - (MO - oO),
          VO = KO - (aK - oO);
        let LO, QO;
        FO > VO ? (LO = 1, QO = 0) : (LO = 0, QO = 1);
        const zK = FO - LO + bK,
          AO = VO - QO + bK,
          fO = FO - 1 + 2 * bK,
          dO = VO - 1 + 2 * bK,
          TO = 255 & MO,
          NO = 255 & aK;
        let IO = .5 - FO * FO - VO * VO;
        if (IO >= 0) {
          const OO = 3 * pO[TO + eO[NO]];
          IO *= IO, lO = IO * IO * (hO[OO] * FO + hO[OO + 1] * VO)
        }
        let yK = .5 - zK * zK - AO * AO;
        if (yK >= 0) {
          const OO = 3 * pO[TO + LO + eO[NO + QO]];
          yK *= yK, vK = yK * yK * (hO[OO] * zK + hO[OO + 1] * AO)
        }
        let gK = .5 - fO * fO - dO * dO;
        if (gK >= 0) {
          const OO = 3 * pO[TO + 1 + eO[NO + 1]];
          gK *= gK, CO = gK * gK * (hO[OO] * fO + hO[OO + 1] * dO)
        }
        return 70 * (lO + vK + CO)
      }
      noise3D(OO, KO, pO) {
        const XO = this.permMod12,
          bK = this.perm;
        let vK, CO, DO, MO;
        const aK = (OO + KO + pO) * eO,
          oO = Math.floor(OO + aK),
          FO = Math.floor(KO + aK),
          VO = Math.floor(pO + aK),
          LO = (oO + FO + VO) * lO,
          QO = OO - (oO - LO),
          zK = KO - (FO - LO),
          AO = pO - (VO - LO);
        let fO, dO, TO, NO, IO, yK;
        QO >= zK ? zK >= AO ? (fO = 1, dO = 0, TO = 0, NO = 1, IO = 1, yK = 0) : QO >= AO ? (fO = 1, dO = 0, TO = 0, NO = 1, IO = 0, yK = 1) : (fO = 0, dO = 0, TO = 1, NO = 1, IO = 0, yK = 1) : zK < AO ? (fO = 0, dO = 0, TO = 1, NO = 0, IO = 1, yK = 1) : QO < AO ? (fO = 0, dO = 1, TO = 0, NO = 0, IO = 1, yK = 1) : (fO = 0, dO = 1, TO = 0, NO = 1, IO = 1, yK = 0);
        const gK = QO - fO + lO,
          uO = zK - dO + lO,
          EO = AO - TO + lO,
          jK = QO - NO + 2 * lO,
          YO = zK - IO + 2 * lO,
          wO = AO - yK + 2 * lO,
          iK = QO - 1 + .5,
          rK = zK - 1 + .5,
          PO = AO - 1 + .5,
          mK = 255 & oO,
          sO = 255 & FO,
          HO = 255 & VO;
        let RO = .6 - QO * QO - zK * zK - AO * AO;
        if (RO < 0) vK = 0;
        else {
          const OO = 3 * XO[mK + bK[sO + bK[HO]]];
          RO *= RO, vK = RO * RO * (hO[OO] * QO + hO[OO + 1] * zK + hO[OO + 2] * AO)
        }
        let SO = .6 - gK * gK - uO * uO - EO * EO;
        if (SO < 0) CO = 0;
        else {
          const OO = 3 * XO[mK + fO + bK[sO + dO + bK[HO + TO]]];
          SO *= SO, CO = SO * SO * (hO[OO] * gK + hO[OO + 1] * uO + hO[OO + 2] * EO)
        }
        let JO = .6 - jK * jK - YO * YO - wO * wO;
        if (JO < 0) DO = 0;
        else {
          const OO = 3 * XO[mK + NO + bK[sO + IO + bK[HO + yK]]];
          JO *= JO, DO = JO * JO * (hO[OO] * jK + hO[OO + 1] * YO + hO[OO + 2] * wO)
        }
        let cK = .6 - iK * iK - rK * rK - PO * PO;
        if (cK < 0) MO = 0;
        else {
          const OO = 3 * XO[mK + 1 + bK[sO + 1 + bK[HO + 1]]];
          cK *= cK, MO = cK * cK * (hO[OO] * iK + hO[OO + 1] * rK + hO[OO + 2] * PO)
        }
        return 32 * (vK + CO + DO + MO)
      }
      noise4D(OO, KO, pO, XO) {
        const bK = this.perm;
        let eO, lO, hO, MO, aK;
        const oO = (OO + KO + pO + XO) * vK,
          FO = Math.floor(OO + oO),
          VO = Math.floor(KO + oO),
          LO = Math.floor(pO + oO),
          QO = Math.floor(XO + oO),
          zK = (FO + VO + LO + QO) * CO,
          AO = OO - (FO - zK),
          fO = KO - (VO - zK),
          dO = pO - (LO - zK),
          TO = XO - (QO - zK);
        let NO = 0,
          IO = 0,
          yK = 0,
          gK = 0;
        AO > fO ? NO++ : IO++, AO > dO ? NO++ : yK++, AO > TO ? NO++ : gK++, fO > dO ? IO++ : yK++, fO > TO ? IO++ : gK++, dO > TO ? yK++ : gK++;
        const uO = NO >= 3 ? 1 : 0,
          EO = IO >= 3 ? 1 : 0,
          jK = yK >= 3 ? 1 : 0,
          YO = gK >= 3 ? 1 : 0,
          wO = NO >= 2 ? 1 : 0,
          iK = IO >= 2 ? 1 : 0,
          rK = yK >= 2 ? 1 : 0,
          PO = gK >= 2 ? 1 : 0,
          mK = NO >= 1 ? 1 : 0,
          sO = IO >= 1 ? 1 : 0,
          HO = yK >= 1 ? 1 : 0,
          RO = gK >= 1 ? 1 : 0,
          SO = AO - uO + CO,
          JO = fO - EO + CO,
          cK = dO - jK + CO,
          BO = TO - YO + CO,
          ZO = AO - wO + 2 * CO,
          GO = fO - iK + 2 * CO,
          qK = dO - rK + 2 * CO,
          xK = TO - PO + 2 * CO,
          nO = AO - mK + 3 * CO,
          WO = fO - sO + 3 * CO,
          tK = dO - HO + 3 * CO,
          kK = TO - RO + 3 * CO,
          UO = AO - 1 + 4 * CO,
          OK = fO - 1 + 4 * CO,
          KK = dO - 1 + 4 * CO,
          pK = TO - 1 + 4 * CO,
          XK = 255 & FO,
          bp = 255 & VO,
          eK = 255 & LO,
          lK = 255 & QO;
        let vp = .6 - AO * AO - fO * fO - dO * dO - TO * TO;
        if (vp < 0) eO = 0;
        else {
          const OO = bK[XK + bK[bp + bK[eK + bK[lK]]]] % 32 * 4;
          vp *= vp, eO = vp * vp * (DO[OO] * AO + DO[OO + 1] * fO + DO[OO + 2] * dO + DO[OO + 3] * TO)
        }
        let CK = .6 - SO * SO - JO * JO - cK * cK - BO * BO;
        if (CK < 0) lO = 0;
        else {
          const OO = bK[XK + uO + bK[bp + EO + bK[eK + jK + bK[lK + YO]]]] % 32 * 4;
          CK *= CK, lO = CK * CK * (DO[OO] * SO + DO[OO + 1] * JO + DO[OO + 2] * cK + DO[OO + 3] * BO)
        }
        let hK = .6 - ZO * ZO - GO * GO - qK * qK - xK * xK;
        if (hK < 0) hO = 0;
        else {
          const OO = bK[XK + wO + bK[bp + iK + bK[eK + rK + bK[lK + PO]]]] % 32 * 4;
          hK *= hK, hO = hK * hK * (DO[OO] * ZO + DO[OO + 1] * GO + DO[OO + 2] * qK + DO[OO + 3] * xK)
        }
        let DK = .6 - nO * nO - WO * WO - tK * tK - kK * kK;
        if (DK < 0) MO = 0;
        else {
          const OO = bK[XK + mK + bK[bp + sO + bK[eK + HO + bK[lK + RO]]]] % 32 * 4;
          DK *= DK, MO = DK * DK * (DO[OO] * nO + DO[OO + 1] * WO + DO[OO + 2] * tK + DO[OO + 3] * kK)
        }
        let MK = .6 - UO * UO - OK * OK - KK * KK - pK * pK;
        if (MK < 0) aK = 0;
        else {
          const OO = bK[XK + 1 + bK[bp + 1 + bK[eK + 1 + bK[lK + 1]]]] % 32 * 4;
          MK *= MK, aK = MK * MK * (DO[OO] * UO + DO[OO + 1] * OK + DO[OO + 2] * KK + DO[OO + 3] * pK)
        }
        return 27 * (eO + lO + hO + MO + aK)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);