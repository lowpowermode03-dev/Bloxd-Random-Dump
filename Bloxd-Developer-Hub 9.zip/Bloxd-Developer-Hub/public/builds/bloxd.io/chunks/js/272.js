export const id = 272;
export const ids = [272];
export const modules = {
  39261: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      CapeMaterialPlugin: () => fO,
      HueTintMaterialPlugin: () => dO,
      LifeformMaterialPlugin: () => TO,
      OverlayMaterialPlugin: () => NO
    });
    var XO = pO(39268),
      bK = pO(36388);
    class eO extends((0, XO.e)(bK.e)) {}(0, XO.i)(bK.e, eO);
    var lO = pO(35543);
    class vK extends((0, XO.e)(lO.e)) {}(0, XO.i)(lO.e, vK);
    var CO = pO(36219);
    class hO extends((0, XO.e)(CO.i)) {}(0, XO.i)(CO.i, hO);
    var DO = pO(35765),
      MO = pO(38355),
      aK = pO(35758);
    class oO extends((0, XO.e)(aK.f)) {
      constructor(OO, KO, pO) {
        super(OO, KO, pO), (0, DO.g)(OO)
      }
      dispose(OO) {
        (0, DO.j)(this._material), super.dispose(OO)
      }
    }(0, XO.i)(aK.f, oO), (0, aK.h)({
      disableUnusedSpecularTerm: XO.b,
      isLightingDisabled: OO => OO instanceof MO.StandardMaterial && OO.disableLighting
    });
    var FO = pO(37070);
    class VO extends((0, XO.e)(FO.h)) {}(0, XO.i)(FO.h, VO);
    var LO = pO(37168),
      QO = pO(35694),
      zK = pO(36539),
      AO = pO(35589);
    class fO extends((0, XO.e)(LO.d)) {}(0, XO.i)(LO.d, fO);
    class dO extends((0, XO.e)(QO.b)) {}(0, XO.i)(QO.b, dO);
    class TO extends((0, XO.e)(zK.p)) {}(0, XO.i)(zK.p, TO);
    class NO extends((0, XO.e)(AO.c)) {}(0, XO.i)(AO.c, NO)
  },
  39268: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => SO,
      e: () => zK,
      i: () => qK
    });
    var XO = pO(38355),
      bK = pO(39276),
      eO = pO(39317),
      lO = pO(39279),
      vK = pO(36182),
      CO = pO(36194),
      hO = pO(36201),
      DO = pO(36204),
      MO = pO(35578),
      aK = pO(35587),
      oO = pO(39285),
      FO = pO(35568),
      VO = pO(35570),
      LO = pO(35552);

    function QO(OO, KO) {
      return Object.assign((function(OO, pO, XO, bK) {
        return KO(this.featureState, OO, pO, XO, bK)
      }), {
        oX: OO
      })
    }

    function zK(OO) {
      const KO = class extends oO.e {
          constructor(KO, pO) {
            const XO = (0, VO.cb)(KO),
              bK = XO && (0, VO.w)(XO, OO.name);
            for (var eO = arguments.length, lO = new Array(eO > 2 ? eO - 2 : 0), vK = 2; vK < eO; vK++) lO[vK - 2] = arguments[vK];
            super(KO, OO.name, OO.priority, bK ? bK.defines : OO.defines(...lO), !1), this.featureState = void 0, this.featureState = pO, this._pluginManager._addPlugin(this), this._enable(!0), (0, VO.y)(this._material, OO, this.featureState, this._pluginDefineNames)
          }
          getClassName() {
            return OO.className
          }
          isCompatible(OO) {
            return OO === LO.e.GLSL || OO === LO.e.WGSL
          }
        },
        pO = (0, FO.g)(OO);
      for (const [XO, bK] of Object.entries(FO.e)) {
        const eO = OO[XO];
        if (eO) {
          const OO = pO[XO];
          Object.defineProperty(KO.prototype, bK, {
            value: QO(eO, OO),
            writable: !0,
            configurable: !0
          })
        }
      }
      return KO
    }
    class AO extends(zK(vK.b)) {}
    var fO = pO(37880),
      dO = pO(39291);
    const TO = new WeakMap;

    function NO(OO, KO, pO) {
      let XO = TO.get(pO);
      XO || (XO = new Map, TO.set(pO, XO));
      const {
        url: bK
      } = OO;
      let eO = XO.get(bK);
      return eO || (eO = async function(OO, KO, pO) {
        const {
          width: XO,
          height: bK
        } = OO.getSize(), eO = Math.round(bK / XO), vK = KO && KO.byteLength === XO * XO * eO * 4 ? KO : OO._readPixelsSync();
        return new dO.e(vK, XO, XO, eO, fO.d.TEXTUREFORMAT_RGBA, pO, !0, !1, lO.c.NEAREST_NEAREST_MIPLINEAR)
      }(OO, KO, pO), XO.set(bK, eO), eO.catch((() => {
        XO.delete(bK)
      }))), eO
    }
    var IO = pO(36213);
    class yK extends(zK(CO.f)) {
      constructor(OO, KO) {
        super(OO, KO), KO.textures.forEach(((OO, KO) => {
          OO.mirror.onLoadObservable.add((OO => {
            this.setTextureArrayData(OO, KO).catch((OO => {
              console.error(`Failed to build texture array for atlas ${KO}`, OO)
            }))
          }))
        })), (0, IO.j)(KO, OO.shaderLanguage)
      }
      async setTextureArrayData(OO, KO) {
        var pO, XO;
        const bK = this.featureState,
          {
            width: eO,
            height: lO
          } = OO.getSize(),
          vK = bK.useWebGL2 ? await NO(OO, null !== (pO = null === (XO = bK.sources.pixels) || void 0 === XO ? void 0 : XO[KO]) && void 0 !== pO ? pO : null, this._material.JKO()) : null;
        (0, IO.e)(this._material, bK, KO, vK, eO, Math.round(lO / eO), this._material.shaderLanguage)
      }
    }
    var gK = pO(39297),
      uO = pO(38400),
      EO = pO(35624),
      jK = pO(39305),
      YO = pO(38511),
      wO = pO(38388),
      iK = pO(39251),
      rK = pO(35919),
      PO = pO(39314);
    class mK extends gK.e {
      getData() {
        return null
      }
      _rebuild() {}
      restore() {
        super._rebuild()
      }
    }
    const sO = {
      Mesh: jK.c,
      TransformNode: iK.c,
      jb: gK.e,
      VertexBuffer: gK.f,
      BoundingInfo: uO.d,
      WX: EO.WX,
      ArenaBuffer: mK,
      SubMesh: wO.b,
      VertexData: YO.e,
      MirroredGeometry: PO.c,
      meshFromArrays: PO.e,
      plainMeshFromArrays: PO.g
    };
    (0, rK.f)(sO);
    var HO = pO(35765);
    class RO extends(zK(DO.i)) {
      constructor(OO, KO) {
        if (super(OO, KO), OO instanceof XO.StandardMaterial && KO.dirLightCount > 0) {
          const KO = OO,
            pO = KO._blockDirtyMechanism;
          KO._blockDirtyMechanism = !0, OO.disableLighting = !0, KO._blockDirtyMechanism = pO;
          const XO = (0, VO.cb)(OO);
          XO && (XO.disableLighting = !0, (0, VO.bb)(XO))
        }(0, HO.g)(OO)
      }
      dispose(OO) {
        (0, HO.j)(this._material), super.dispose(OO)
      }
    }

    function SO(OO, KO) {
      if (!(KO instanceof XO.StandardMaterial) || KO.specularTexture) return;
      const {
        r: pO,
        g: bK,
        b: eO
      } = KO.specularColor;
      0 === pO && 0 === bK && 0 === eO && (OO.SPECULARTERM = !1)
    }(0, DO.g)({
      disableUnusedSpecularTerm: SO
    });
    var JO = pO(35711),
      cK = pO(35928);
    const BO = new RegExp(`^#define ${hO.c}\\s*$`, "m");
    class ZO extends(zK(hO.h)) {
      constructor(OO, KO) {
        super(OO, KO), this.YX = !1, KO.ditherOnlyWhileFading && (cK.c.add(OO), this.prewarmDitherTwins(OO))
      }
      prewarmDitherTwins(OO) {
        const KO = new WeakSet;
        OO.onEffectCreatedObservable.add((pO => {
          let {
            effect: XO,
            subMesh: bK
          } = pO;
          if (this.featureState.prewarmingDither || KO.has(XO)) return;
          KO.add(XO);
          const eO = null === bK || void 0 === bK ? void 0 : bK.getMesh();
          eO && !BO.test(XO.defines) && OO.JKO().onAfterRenderObservable.addOnce((() => {
            this.prewarmDither(eO) || KO.delete(XO)
          }))
        }))
      }
      prewarmDither(OO) {
        if (this.YX || OO.FhO()) return !1;
        const KO = new wO.b(0, 0, 0, 0, 0, OO, void 0, !1, !1);
        this.featureState.prewarmingDither = !0;
        try {
          this._material.isReadyForSubMesh(OO, KO)
        } finally {
          this.featureState.prewarmingDither = !1
        }
        return null !== KO.effect
      }
      dispose(OO) {
        this.YX = !0, super.dispose(OO)
      }
    }
    const GO = new Map;

    function qK(OO, KO) {
      GO.set(OO, KO)
    }
    qK(vK.b, AO), qK(CO.f, yK), qK(hO.h, ZO), qK(DO.i, RO), (0, MO.b)({
      create: (OO, KO) => {
        const pO = new XO.StandardMaterial(OO.name, KO);
        return (0, JO.q)(OO, pO), pO.detailMap._pluginDefineNames
      },
      write: (OO, KO, pO) => {
        (0, JO.Y)(OO.mirror, KO, pO)
      },
      addFeature: (OO, KO, pO) => {
        const XO = GO.get(KO.feature);
        if (!XO) throw new Error(`${KO.feature.name} has no plugin class (registerPluginClass)`);
        new XO(OO.mirror, KO.state, ...pO)
      },
      texture: (OO, KO, pO) => {
        let {
          url: XO,
          noMipmap: bK,
          invertY: eO,
          samplingMode: vK,
          data: CO,
          sets: hO
        } = pO;
        if (!CO) {
          const pO = new lO.c(XO, KO, bK, eO, vK);
          return Object.assign(pO, hO), void(0, aK.K)(OO, pO)
        }
        const DO = {},
          MO = new Promise(((OO, KO) => {
            DO.onLoad = OO, DO.onError = (OO, pO) => {
              KO(new Error(`${CO.context}: ${(null===pO||void 0===pO?void 0:pO.message)||OO||"Failed to load texture"}`))
            }
          })),
          {
            mimeType: oO,
            bytes: FO,
            label: VO
          } = CO,
          LO = {
            noMipmap: bK,
            invertY: !1,
            samplingMode: vK,
            ...DO,
            mimeType: oO,
            loaderOptions: void 0,
            useSRGBBuffer: !1
          },
          QO = new lO.c(null, KO, LO);
        JO.t.set(QO, MO), Object.assign(QO, hO), QO.updateURL(XO, FO);
        const zK = QO.getInternalTexture();
        zK && (zK.label = VO), OO.uvSet = QO.coordinatesIndex, OO.matrix.set((0, JO.R)(QO)), (0, aK.K)(OO, QO)
      },
      cube: (OO, KO, pO) => {
        let {
          rootUrl: XO,
          files: eO,
          noMipmap: vK,
          luminance: CO
        } = pO;
        const {
          samplingMode: hO
        } = OO.sampler, DO = hO === (0, aK.A)(vK) ? null : () => {
          (0, JO.P)(MO, hO)
        }, MO = new bK.e(XO, KO, null, vK, eO, DO, null, (0, aK.y)(CO));
        MO.coordinatesMode = lO.c.SKYBOX_MODE, (0, aK.K)(OO, MO)
      },
      canvas: (OO, KO, pO) => {
        let {
          width: XO,
          height: bK,
          mipmaps: vK,
          samplingMode: CO,
          hasAlpha: hO = !1,
          wrap: DO = lO.c.CLAMP_ADDRESSMODE
        } = pO;
        const MO = new eO.e(KO, {
          width: XO,
          height: bK
        }, OO, vK, CO);
        MO.hasAlpha = hO, MO.wrapU = DO, MO.wrapV = DO;
        const aK = (0, JO.C)(MO);
        return (0, JO.F)(aK, MO), aK
      }
    })
  },
  39314: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => DO,
      e: () => MO,
      g: () => aK
    });
    var XO = pO(39297),
      bK = pO(38136),
      eO = pO(38400),
      lO = pO(38517),
      vK = pO(39305),
      CO = pO(38511),
      hO = pO(35807);
    class DO extends lO.e {
      constructor() {
        super(...arguments), this.model = null, this.onGeometryUpdated = (OO, KO) => {
          this.releaseUnlessInstanced(KO)
        }, this.onLinked = null
      }
      link(OO) {
        var KO;
        (0, hO.m)(OO), this.model = OO, null === (KO = this.onLinked) || void 0 === KO || KO.call(this, OO)
      }
      relink() {
        this.release();
        const OO = [];
        for (const bK of Object.values(this._vertexBuffers))
          if (!bK.getIsInstanced()) {
            const {
              byteOffset: KO,
              byteStride: pO,
              type: XO,
              normalized: eO
            } = bK;
            OO.push({
              kind: bK.getKind(),
              data: bK.getData(),
              offset: KO,
              stride: pO,
              components: bK.getSize(),
              glType: XO,
              isNormalized: eO
            })
          } const KO = this._indices.length ? this._indices : null,
          {
            minimum: pO,
            maximum: XO
          } = this.extend;
        this.link(new hO.h(OO, KO, this.getTotalVertices(), new Float64Array(pO.WhO()), new Float64Array(XO.WhO())))
      }
      copy(OO) {
        if (!this.model) return super.copy(OO);
        const KO = new DO(OO, this.JKO()),
          pO = this.rFO(void 0, !0);
        pO && KO.setIndices(pO);
        let lO = !1;
        for (const eO in this._vertexBuffers) {
          const OO = this._vertexBuffers[eO],
            pO = OO.getData();
          if (!pO) continue;
          const vK = OO.getSize(),
            {
              type: CO,
              byteOffset: hO,
              byteStride: DO,
              normalized: MO
            } = OO;
          lO ||= OO.isUpdatable();
          const aK = OO.getIsInstanced() ? (pO instanceof Array ? 4 * pO.length : pO.byteLength) / DO : this.getTotalVertices(),
            oO = (0, bK.u)(pO, vK, CO, hO, DO, aK, !0),
            FO = {
              updatable: OO.isUpdatable(),
              stride: vK,
              type: CO,
              normalized: MO,
              takeBufferOwnership: !0,
              instanced: OO.getIsInstanced()
            };
          KO.setVerticesBuffer(new XO.f(this.qb(), oO, eO, FO), aK)
        }
        return KO._updatable = lO, KO._boundingInfo = new eO.d(this.extend.minimum, this.extend.maximum), KO.relink(), KO
      }
      static mergeMeshes(OO, KO, pO, XO, bK, eO) {
        const CO = OO[0].JKO(),
          hO = new vK.c(OO[0].name + "_merged", CO),
          MO = new DO(lO.e.RandomId(), CO, void 0, !1, hO);
        try {
          if (!vK.c.MergeMeshes(OO, KO, pO, hO, bK, eO)) return hO.dispose(), null
        } catch (aK) {
          throw hO.dispose(), aK
        }
        return MO.relink(), hO
      }
      removeVerticesData(OO) {
        this.releaseUnlessInstanced(OO), super.removeVerticesData(OO)
      }
      dispose() {
        this.release(), super.dispose()
      }
      releaseUnlessInstanced(OO) {
        var KO;
        OO && null !== (KO = this.getVertexBuffer(OO)) && void 0 !== KO && KO.getIsInstanced() || this.release()
      }
      release() {
        this.model && ((0, hO.q)(this.model), this.model = null)
      }
    }

    function MO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : new vK.c(OO, pO);
      const bK = (0, hO.k)(KO),
        {
          positions: eO,
          normals: MO,
          uvs: aK,
          indices: oO,
          named: FO = {}
        } = KO,
        VO = new CO.e;
      VO.positions = eO, VO.normals = null !== MO && void 0 !== MO ? MO : null, VO.uvs = null !== aK && void 0 !== aK ? aK : null, VO.indices = oO;
      const LO = new DO(lO.e.RandomId(), pO, VO, !1, XO);
      for (const {
          kind: lO,
          components: vK
        }
        of bK.vertexAttributes) lO in FO && XO.setVerticesData(lO, FO[lO], !1, vK);
      return LO.link(bK), XO
    }

    function aK(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      const bK = new vK.c(OO, pO),
        {
          positions: eO,
          normals: lO,
          uvs: hO,
          indices: DO
        } = KO;
      return Object.assign(new CO.e, {
        positions: eO,
        normals: lO,
        uvs: hO,
        indices: DO
      }).applyToMesh(bK, XO), bK
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);