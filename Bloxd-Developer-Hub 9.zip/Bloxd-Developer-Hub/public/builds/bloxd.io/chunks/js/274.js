export const id = 274;
export const ids = [274];
export const modules = {
  39336: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => ip,
      f: () => IK,
      i: () => zp,
      j: () => CO,
      k: () => rp,
      o: () => hO,
      p: () => ap
    });
    var XO = pO(39338),
      bK = pO(39341),
      eO = pO(39347);
    class lO {
      constructor(OO, KO, pO, XO) {
        this.state = OO, this.pos = KO, this.explicit = pO, this.view = XO, this.abortListeners = [], this.abortOnDocChange = !1
      }
      tokenBefore(OO) {
        let KO = (0, eO.ib)(this.state).resolveInner(this.pos, -1);
        for (; KO && OO.indexOf(KO.name) < 0;) KO = KO.parent;
        return KO ? {
          from: KO.from,
          to: this.pos,
          text: this.state.sliceDoc(KO.from, this.pos),
          type: KO.type
        } : null
      }
      matchBefore(OO) {
        let KO = this.state.doc.lineAt(this.pos),
          pO = Math.max(KO.from, this.pos - 250),
          XO = KO.text.slice(pO - KO.from, this.pos - KO.from),
          bK = XO.search(aK(OO, !1));
        return bK < 0 ? null : {
          from: pO + bK,
          to: this.pos,
          text: XO.slice(bK)
        }
      }
      get aborted() {
        return null == this.abortListeners
      }
      addEventListener(OO, KO, pO) {
        "abort" == OO && this.abortListeners && (this.abortListeners.push(KO), pO && pO.onDocChange && (this.abortOnDocChange = !0))
      }
    }

    function vK(OO) {
      let KO = Object.keys(OO).join(""),
        pO = /\w/.test(KO);
      return pO && (KO = KO.replace(/\w/g, "")), `[${pO?"\\w":""}${KO.replace(/[^\w\s]/g,"\\$&")}]`
    }

    function CO(OO) {
      let KO = OO.map((OO => "string" == typeof OO ? {
          label: OO
        } : OO)),
        [pO, XO] = KO.every((OO => /^\w+$/.test(OO.label))) ? [/\w*$/, /\w+$/] : function(OO) {
          let KO = Object.create(null),
            pO = Object.create(null);
          for (let {
              label: bK
            }
            of OO) {
            KO[bK[0]] = !0;
            for (let OO = 1; OO < bK.length; OO++) pO[bK[OO]] = !0
          }
          let XO = vK(KO) + vK(pO) + "*$";
          return [new RegExp("^" + XO), new RegExp(XO)]
        }(KO);
      return OO => {
        let bK = OO.matchBefore(XO);
        return bK || OO.explicit ? {
          from: bK ? bK.from : OO.pos,
          options: KO,
          validFor: pO
        } : null
      }
    }

    function hO(OO, KO) {
      return pO => {
        for (let KO = (0, eO.ib)(pO.state).resolveInner(pO.pos, -1); KO; KO = KO.parent) {
          if (OO.indexOf(KO.name) > -1) return null;
          if (KO.type.isTop) break
        }
        return KO(pO)
      }
    }
    class DO {
      constructor(OO, KO, pO, XO) {
        this.completion = OO, this.source = KO, this.match = pO, this.score = XO
      }
    }

    function MO(OO) {
      return OO.selection.main.from
    }

    function aK(OO, KO) {
      var pO;
      let {
        source: XO
      } = OO, bK = KO && "^" != XO[0], eO = "$" != XO[XO.length - 1];
      return bK || eO ? new RegExp(`${bK?"^":""}(?:${XO})${eO?"$":""}`, null !== (pO = OO.flags) && void 0 !== pO ? pO : OO.ignoreCase ? "i" : "") : OO
    }
    const oO = XO.d.define();

    function FO(OO, KO, pO, bK) {
      let {
        main: eO
      } = OO.selection, lO = pO - eO.from, vK = bK - eO.from;
      return {
        ...OO.changeByRange((CO => {
          if (CO != eO && pO != bK && OO.sliceDoc(CO.from + lO, CO.from + vK) != OO.sliceDoc(pO, bK)) return {
            range: CO
          };
          let hO = OO.toText(KO);
          return {
            changes: {
              from: CO.from + lO,
              to: bK == eO.from ? CO.to : CO.from + vK,
              insert: hO
            },
            range: XO.j.cursor(CO.from + lO + hO.length)
          }
        })),
        scrollIntoView: !0,
        userEvent: "input.complete"
      }
    }
    const VO = new WeakMap;

    function LO(OO) {
      if (!Array.isArray(OO)) return OO;
      let KO = VO.get(OO);
      return KO || VO.set(OO, KO = CO(OO)), KO
    }
    const QO = XO.C.define(),
      zK = XO.C.define();
    class AO {
      constructor(OO) {
        this.pattern = OO, this.chars = [], this.folded = [], this.any = [], this.precise = [], this.byWord = [], this.score = 0, this.matched = [];
        for (let KO = 0; KO < OO.length;) {
          let pO = (0, XO.N)(OO, KO),
            bK = (0, XO.P)(pO);
          this.chars.push(pO);
          let eO = OO.slice(KO, KO + bK),
            lO = eO.toUpperCase();
          this.folded.push((0, XO.N)(lO == eO ? eO.toLowerCase() : lO, 0)), KO += bK
        }
        this.astral = OO.length != this.chars.length
      }
      ret(OO, KO) {
        return this.score = OO, this.matched = KO, this
      }
      match(OO) {
        if (0 == this.pattern.length) return this.ret(-100, []);
        if (OO.length < this.pattern.length) return null;
        let {
          chars: KO,
          folded: pO,
          any: bK,
          precise: eO,
          byWord: lO
        } = this;
        if (1 == KO.length) {
          let bK = (0, XO.N)(OO, 0),
            eO = (0, XO.P)(bK),
            lO = eO == OO.length ? 0 : -100;
          if (bK == KO[0]);
          else {
            if (bK != pO[0]) return null;
            lO += -200
          }
          return this.ret(lO, [0, eO])
        }
        let vK = OO.indexOf(this.pattern);
        if (0 == vK) return this.ret(OO.length == this.pattern.length ? 0 : -100, [0, this.pattern.length]);
        let CO = KO.length,
          hO = 0;
        if (vK < 0) {
          for (let eO = 0, lO = Math.min(OO.length, 200); eO < lO && hO < CO;) {
            let lO = (0, XO.N)(OO, eO);
            lO != KO[hO] && lO != pO[hO] || (bK[hO++] = eO), eO += (0, XO.P)(lO)
          }
          if (hO < CO) return null
        }
        let DO = 0,
          MO = 0,
          aK = !1,
          oO = 0,
          FO = -1,
          VO = -1,
          LO = /[a-z]/.test(OO),
          QO = !0;
        for (let zK = 0, AO = Math.min(OO.length, 200), fO = 0; zK < AO && MO < CO;) {
          let bK = (0, XO.N)(OO, zK);
          vK < 0 && (DO < CO && bK == KO[DO] && (eO[DO++] = zK), oO < CO && (bK == KO[oO] || bK == pO[oO] ? (0 == oO && (FO = zK), VO = zK + 1, oO++) : oO = 0));
          let hO, AO = bK < 255 ? bK >= 48 && bK <= 57 || bK >= 97 && bK <= 122 ? 2 : bK >= 65 && bK <= 90 ? 1 : 0 : (hO = (0, XO.ab)(bK)) != hO.toLowerCase() ? 1 : hO != hO.toUpperCase() ? 2 : 0;
          (!zK || 1 == AO && LO || 0 == fO && 0 != AO) && (KO[MO] == bK || pO[MO] == bK && (aK = !0) ? lO[MO++] = zK : lO.length && (QO = !1)), fO = AO, zK += (0, XO.P)(bK)
        }
        return MO == CO && 0 == lO[0] && QO ? this.result((aK ? -200 : 0) - 100, lO, OO) : oO == CO && 0 == FO ? this.ret(-200 - OO.length + (VO == OO.length ? 0 : -100), [0, VO]) : vK > -1 ? this.ret(-700 - OO.length, [vK, vK + this.pattern.length]) : oO == CO ? this.ret(-900 - OO.length, [FO, VO]) : MO == CO ? this.result((aK ? -200 : 0) - 100 - 700 + (QO ? 0 : -1100), lO, OO) : 2 == KO.length ? null : this.result((bK[0] ? -700 : 0) - 200 - 1100, bK, OO)
      }
      result(OO, KO, pO) {
        let bK = [],
          eO = 0;
        for (let lO of KO) {
          let OO = lO + (this.astral ? (0, XO.P)((0, XO.N)(pO, lO)) : 1);
          eO && bK[eO - 1] == lO ? bK[eO - 1] = OO : (bK[eO++] = lO, bK[eO++] = OO)
        }
        return this.ret(OO - pO.length, bK)
      }
    }
    class fO {
      constructor(OO) {
        this.pattern = OO, this.matched = [], this.score = 0, this.folded = OO.toLowerCase()
      }
      match(OO) {
        if (OO.length < this.pattern.length) return null;
        let KO = OO.slice(0, this.pattern.length),
          pO = KO == this.pattern ? 0 : KO.toLowerCase() == this.folded ? -200 : null;
        return null == pO ? null : (this.matched = [0, KO.length], this.score = pO + (OO.length == this.pattern.length ? 0 : -100), this)
      }
    }
    const dO = XO.n.define({
      combine: OO => (0, XO.T)(OO, {
        activateOnTyping: !0,
        activateOnCompletion: () => !1,
        activateOnTypingDelay: 100,
        selectOnOpen: !0,
        override: null,
        closeOnBlur: !0,
        maxRenderedOptions: 100,
        defaultKeymap: !0,
        tooltipClass: () => "",
        optionClass: () => "",
        aboveCursor: !1,
        icons: !0,
        addToOptions: [],
        positionInfo: NO,
        filterStrict: !1,
        compareCompletions: (OO, KO) => (OO.sortText || OO.label).localeCompare(KO.sortText || KO.label),
        interactionDelay: 75,
        updateSyncTime: 100
      }, {
        defaultKeymap: (OO, KO) => OO && KO,
        closeOnBlur: (OO, KO) => OO && KO,
        icons: (OO, KO) => OO && KO,
        tooltipClass: (OO, KO) => pO => TO(OO(pO), KO(pO)),
        optionClass: (OO, KO) => pO => TO(OO(pO), KO(pO)),
        addToOptions: (OO, KO) => OO.concat(KO),
        filterStrict: (OO, KO) => OO || KO
      })
    });

    function TO(OO, KO) {
      return OO ? KO ? OO + " " + KO : OO : KO
    }

    function NO(OO, KO, pO, XO, eO, lO) {
      let vK, CO, hO = OO.textDirection == bK.d.RTL,
        DO = hO,
        MO = !1,
        aK = "top",
        oO = KO.left - eO.left,
        FO = eO.right - KO.right,
        VO = XO.right - XO.left,
        LO = XO.bottom - XO.top;
      if (DO && oO < Math.min(VO, FO) ? DO = !1 : !DO && FO < Math.min(VO, oO) && (DO = !0), VO <= (DO ? oO : FO)) vK = Math.max(eO.top, Math.min(pO.top, eO.bottom - LO)) - KO.top, CO = Math.min(400, DO ? oO : FO);
      else {
        MO = !0, CO = Math.min(400, (hO ? KO.right : eO.right - KO.left) - 30);
        let OO = eO.bottom - KO.bottom;
        OO >= LO || OO > KO.top ? vK = pO.bottom - KO.top : (aK = "bottom", vK = KO.bottom - pO.top)
      }
      return {
        style: `${aK}: ${vK/((KO.bottom-KO.top)/lO.offsetHeight)}px; max-width: ${CO/((KO.right-KO.left)/lO.offsetWidth)}px`,
        class: "cm-completionInfo-" + (MO ? hO ? "left-narrow" : "right-narrow" : DO ? "left" : "right")
      }
    }
    const IO = XO.C.define();

    function yK(OO, KO, pO) {
      if (OO <= pO) return {
        from: 0,
        to: OO
      };
      if (KO < 0 && (KO = 0), KO <= OO >> 1) {
        let OO = Math.floor(KO / pO);
        return {
          from: OO * pO,
          to: (OO + 1) * pO
        }
      }
      let XO = Math.floor((OO - KO) / pO);
      return {
        from: OO - (XO + 1) * pO,
        to: OO - XO * pO
      }
    }
    class gK {
      constructor(OO, KO, pO) {
        this.view = OO, this.stateField = KO, this.applyCompletion = pO, this.info = null, this.infoDestroy = null, this.placeInfoReq = {
          read: () => this.measureInfo(),
          write: OO => this.placeInfo(OO),
          key: this
        }, this.space = null, this.currentClass = "";
        let XO = OO.state.field(KO),
          {
            options: bK,
            selected: eO
          } = XO.open,
          lO = OO.state.facet(dO);
        this.optionContent = function(OO) {
          let KO = OO.addToOptions.slice();
          return OO.icons && KO.push({
            render(OO) {
              let KO = document.createElement("div");
              return KO.classList.add("cm-completionIcon"), OO.type && KO.classList.add(...OO.type.split(/\s+/g).map((OO => "cm-completionIcon-" + OO))), KO.setAttribute("aria-hidden", "true"), KO
            },
            position: 20
          }), KO.push({
            render(OO, KO, pO, XO) {
              let bK = document.createElement("span");
              bK.className = "cm-completionLabel";
              let eO = OO.displayLabel || OO.label,
                lO = 0;
              for (let vK = 0; vK < XO.length;) {
                let OO = XO[vK++],
                  KO = XO[vK++];
                OO > lO && bK.appendChild(document.createTextNode(eO.slice(lO, OO)));
                let pO = bK.appendChild(document.createElement("span"));
                pO.appendChild(document.createTextNode(eO.slice(OO, KO))), pO.className = "cm-completionMatchedText", lO = KO
              }
              return lO < eO.length && bK.appendChild(document.createTextNode(eO.slice(lO))), bK
            },
            position: 50
          }, {
            render(OO) {
              if (!OO.detail) return null;
              let KO = document.createElement("span");
              return KO.className = "cm-completionDetail", KO.textContent = OO.detail, KO
            },
            position: 80
          }), KO.sort(((OO, KO) => OO.position - KO.position)).map((OO => OO.render))
        }(lO), this.optionClass = lO.optionClass, this.tooltipClass = lO.tooltipClass, this.range = yK(bK.length, eO, lO.maxRenderedOptions), this.dom = document.createElement("div"), this.dom.className = "cm-tooltip-autocomplete", this.updateTooltipClass(OO.state), this.dom.addEventListener("mousedown", (pO => {
          let {
            options: XO
          } = OO.state.field(KO).open;
          for (let KO, bK = pO.target; bK && bK != this.dom; bK = bK.parentNode)
            if ("LI" == bK.nodeName && (KO = /-(\d+)$/.exec(bK.id)) && +KO[1] < XO.length) return this.applyCompletion(OO, XO[+KO[1]]), void pO.preventDefault();
          if (pO.target == this.list) {
            let KO = this.list.classList.contains("cm-completionListIncompleteTop") && pO.clientY < this.list.firstChild.getBoundingClientRect().top ? this.range.from - 1 : this.list.classList.contains("cm-completionListIncompleteBottom") && pO.clientY > this.list.lastChild.getBoundingClientRect().bottom ? this.range.to : null;
            null != KO && (OO.dispatch({
              effects: IO.of(KO)
            }), pO.preventDefault())
          }
        })), this.dom.addEventListener("focusout", (KO => {
          let pO = OO.state.field(this.stateField, !1);
          pO && pO.tooltip && OO.state.facet(dO).closeOnBlur && KO.relatedTarget != OO.contentDOM && OO.dispatch({
            effects: zK.of(null)
          })
        })), this.showOptions(bK, XO.id)
      }
      mount() {
        this.updateSel()
      }
      showOptions(OO, KO) {
        this.list && this.list.remove(), this.list = this.dom.appendChild(this.createListBox(OO, KO, this.range)), this.list.addEventListener("scroll", (() => {
          this.info && this.view.requestMeasure(this.placeInfoReq)
        }))
      }
      update(OO) {
        var KO;
        let pO = OO.state.field(this.stateField),
          XO = OO.startState.field(this.stateField);
        if (this.updateTooltipClass(OO.state), pO != XO) {
          let {
            options: bK,
            selected: eO,
            disabled: lO
          } = pO.open;
          XO.open && XO.open.options == bK || (this.range = yK(bK.length, eO, OO.state.facet(dO).maxRenderedOptions), this.showOptions(bK, pO.id)), this.updateSel(), lO != (null === (KO = XO.open) || void 0 === KO ? void 0 : KO.disabled) && this.dom.classList.toggle("cm-tooltip-autocomplete-disabled", !!lO)
        }
      }
      updateTooltipClass(OO) {
        let KO = this.tooltipClass(OO);
        if (KO != this.currentClass) {
          for (let OO of this.currentClass.split(" ")) OO && this.dom.classList.remove(OO);
          for (let OO of KO.split(" ")) OO && this.dom.classList.add(OO);
          this.currentClass = KO
        }
      }
      positioned(OO) {
        this.space = OO, this.info && this.view.requestMeasure(this.placeInfoReq)
      }
      updateSel() {
        let OO = this.view.state.field(this.stateField),
          KO = OO.open;
        (KO.selected > -1 && KO.selected < this.range.from || KO.selected >= this.range.to) && (this.range = yK(KO.options.length, KO.selected, this.view.state.facet(dO).maxRenderedOptions), this.showOptions(KO.options, OO.id));
        let pO = this.updateSelectedOption(KO.selected);
        if (pO) {
          this.destroyInfo();
          let {
            completion: XO
          } = KO.options[KO.selected], {
            info: eO
          } = XO;
          if (!eO) return;
          let lO = "string" === typeof eO ? document.createTextNode(eO) : eO(XO);
          if (!lO) return;
          "then" in lO ? lO.then((KO => {
            KO && this.view.state.field(this.stateField, !1) == OO && this.addInfoPane(KO, XO)
          })).catch((OO => (0, bK.S)(this.view.state, OO, "completion info"))) : (this.addInfoPane(lO, XO), pO.setAttribute("aria-describedby", this.info.id))
        }
      }
      addInfoPane(OO, KO) {
        this.destroyInfo();
        let pO = this.info = document.createElement("div");
        if (pO.className = "cm-tooltip cm-completionInfo", pO.id = "cm-completionInfo-" + Math.floor(65535 * Math.random()).toString(16), null != OO.nodeType) pO.appendChild(OO), this.infoDestroy = null;
        else {
          let {
            dom: KO,
            destroy: XO
          } = OO;
          pO.appendChild(KO), this.infoDestroy = XO || null
        }
        this.dom.appendChild(pO), this.view.requestMeasure(this.placeInfoReq)
      }
      updateSelectedOption(OO) {
        let KO = null;
        for (let pO = this.list.firstChild, XO = this.range.from; pO; pO = pO.nextSibling, XO++) "LI" == pO.nodeName && pO.id ? XO == OO ? pO.hasAttribute("aria-selected") || (pO.setAttribute("aria-selected", "true"), KO = pO) : pO.hasAttribute("aria-selected") && (pO.removeAttribute("aria-selected"), pO.removeAttribute("aria-describedby")) : XO--;
        return KO && function(OO, KO) {
          let pO = OO.getBoundingClientRect(),
            XO = KO.getBoundingClientRect(),
            bK = pO.height / OO.offsetHeight;
          XO.top < pO.top ? OO.scrollTop -= (pO.top - XO.top) / bK : XO.bottom > pO.bottom && (OO.scrollTop += (XO.bottom - pO.bottom) / bK)
        }(this.list, KO), KO
      }
      measureInfo() {
        let OO = this.dom.querySelector("[aria-selected]");
        if (!OO || !this.info) return null;
        let KO = this.dom.getBoundingClientRect(),
          pO = this.info.getBoundingClientRect(),
          XO = OO.getBoundingClientRect(),
          bK = this.space;
        if (!bK) {
          let OO = this.dom.ownerDocument.documentElement;
          bK = {
            left: 0,
            top: 0,
            right: OO.clientWidth,
            bottom: OO.clientHeight
          }
        }
        return XO.top > Math.min(bK.bottom, KO.bottom) - 10 || XO.bottom < Math.max(bK.top, KO.top) + 10 ? null : this.view.state.facet(dO).positionInfo(this.view, KO, XO, pO, bK, this.dom)
      }
      placeInfo(OO) {
        this.info && (OO ? (OO.style && (this.info.style.cssText = OO.style), this.info.className = "cm-tooltip cm-completionInfo " + (OO.class || "")) : this.info.style.cssText = "top: -1e6px")
      }
      createListBox(OO, KO, pO) {
        const XO = document.createElement("ul");
        XO.id = KO, XO.setAttribute("role", "listbox"), XO.setAttribute("aria-expanded", "true"), XO.setAttribute("aria-label", this.view.state.phrase("Completions")), XO.addEventListener("mousedown", (OO => {
          OO.target == XO && OO.preventDefault()
        }));
        let bK = null;
        for (let eO = pO.from; eO < pO.to; eO++) {
          let {
            completion: lO,
            match: vK
          } = OO[eO], {
            section: CO
          } = lO;
          if (CO) {
            let OO = "string" == typeof CO ? CO : CO.name;
            if (OO != bK && (eO > pO.from || 0 == pO.from))
              if (bK = OO, "string" != typeof CO && CO.header) XO.appendChild(CO.header(CO));
              else {
                XO.appendChild(document.createElement("completion-section")).textContent = OO
              }
          }
          const hO = XO.appendChild(document.createElement("li"));
          hO.id = KO + "-" + eO, hO.setAttribute("role", "option");
          let DO = this.optionClass(lO);
          DO && (hO.className = DO);
          for (let OO of this.optionContent) {
            let KO = OO(lO, this.view.state, this.view, vK);
            KO && hO.appendChild(KO)
          }
        }
        return pO.from && XO.classList.add("cm-completionListIncompleteTop"), pO.to < OO.length && XO.classList.add("cm-completionListIncompleteBottom"), XO
      }
      destroyInfo() {
        this.info && (this.infoDestroy && this.infoDestroy(), this.info.remove(), this.info = null)
      }
      destroy() {
        this.destroyInfo()
      }
    }

    function uO(OO, KO) {
      return pO => new gK(pO, OO, KO)
    }

    function EO(OO) {
      return 100 * (OO.boost || 0) + (OO.apply ? 10 : 0) + (OO.info ? 5 : 0) + (OO.type ? 1 : 0)
    }
    class jK {
      constructor(OO, KO, pO, XO, bK, eO) {
        this.options = OO, this.attrs = KO, this.tooltip = pO, this.timestamp = XO, this.selected = bK, this.disabled = eO
      }
      setSelected(OO, KO) {
        return OO == this.selected || OO >= this.options.length ? this : new jK(this.options, rK(KO, OO), this.tooltip, this.timestamp, OO, this.disabled)
      }
      static build(OO, KO, pO, XO, bK, eO) {
        if (XO && !eO && OO.some((OO => OO.isPending))) return XO.setDisabled();
        let lO = function(OO, KO) {
          let pO = [],
            XO = null,
            bK = null,
            eO = OO => {
              pO.push(OO);
              let {
                section: KO
              } = OO.completion;
              if (KO) {
                XO || (XO = []);
                let OO = "string" == typeof KO ? KO : KO.name;
                XO.some((KO => KO.name == OO)) || XO.push("string" == typeof KO ? {
                  name: OO
                } : KO)
              }
            },
            lO = KO.facet(dO);
          for (let MO of OO)
            if (MO.hasResult()) {
              let OO = MO.result.getMatch;
              if (!1 === MO.result.filter)
                for (let KO of MO.result.options) eO(new DO(KO, MO.source, OO ? OO(KO) : [], 1e9 - pO.length));
              else {
                let pO, XO = KO.sliceDoc(MO.from, MO.to),
                  vK = lO.filterStrict ? new fO(XO) : new AO(XO);
                for (let KO of MO.result.options)
                  if (pO = vK.match(KO.label)) {
                    let XO = KO.displayLabel ? OO ? OO(KO, pO.matched) : [] : pO.matched,
                      lO = pO.score + (KO.boost || 0);
                    if (eO(new DO(KO, MO.source, XO, lO)), "object" == typeof KO.section && "dynamic" === KO.section.rank) {
                      let {
                        name: OO
                      } = KO.section;
                      bK || (bK = Object.create(null)), bK[OO] = Math.max(lO, bK[OO] || -1e9)
                    }
                  }
              }
            } if (XO) {
            let OO = Object.create(null),
              KO = 0,
              eO = (OO, KO) => ("dynamic" === OO.rank && "dynamic" === KO.rank ? bK[KO.name] - bK[OO.name] : 0) || ("number" == typeof OO.rank ? OO.rank : 1e9) - ("number" == typeof KO.rank ? KO.rank : 1e9) || (OO.name < KO.name ? -1 : 1);
            for (let pO of XO.sort(eO)) KO -= 1e5, OO[pO.name] = KO;
            for (let XO of pO) {
              let {
                section: KO
              } = XO.completion;
              KO && (XO.score += OO["string" == typeof KO ? KO : KO.name])
            }
          }
          let vK = [],
            CO = null,
            hO = lO.compareCompletions;
          for (let DO of pO.sort(((OO, KO) => KO.score - OO.score || hO(OO.completion, KO.completion)))) {
            let OO = DO.completion;
            !CO || CO.label != OO.label || CO.detail != OO.detail || null != CO.type && null != OO.type && CO.type != OO.type || CO.apply != OO.apply || CO.boost != OO.boost ? vK.push(DO) : EO(DO.completion) > EO(CO) && (vK[vK.length - 1] = DO), CO = DO.completion
          }
          return vK
        }(OO, KO);
        if (!lO.length) return XO && OO.some((OO => OO.isPending)) ? XO.setDisabled() : null;
        let vK = KO.facet(dO).selectOnOpen ? 0 : -1;
        if (XO && XO.selected != vK && -1 != XO.selected) {
          let OO = XO.options[XO.selected].completion;
          for (let KO = 0; KO < lO.length; KO++)
            if (lO[KO].completion == OO) {
              vK = KO;
              break
            }
        }
        return new jK(lO, rK(pO, vK), {
          pos: OO.reduce(((OO, KO) => KO.hasResult() ? Math.min(OO, KO.from) : OO), 1e8),
          create: cK,
          above: bK.aboveCursor
        }, XO ? XO.timestamp : Date.now(), vK, !1)
      }
      map(OO) {
        return new jK(this.options, this.attrs, {
          ...this.tooltip,
          pos: OO.mapPos(this.tooltip.pos)
        }, this.timestamp, this.selected, this.disabled)
      }
      setDisabled() {
        return new jK(this.options, this.attrs, this.tooltip, this.timestamp, this.selected, !0)
      }
    }
    class YO {
      constructor(OO, KO, pO) {
        this.active = OO, this.id = KO, this.open = pO
      }
      static start() {
        return new YO(PO, "cm-ac-" + Math.floor(2e6 * Math.random()).toString(36), null)
      }
      update(OO) {
        let {
          state: KO
        } = OO, pO = KO.facet(dO), XO = (pO.override || KO.languageDataAt("autocomplete", MO(KO)).map(LO)).map((KO => (this.active.find((OO => OO.source == KO)) || new sO(KO, this.active.some((OO => 0 != OO.state)) ? 1 : 0)).update(OO, pO)));
        XO.length == this.active.length && XO.every(((OO, KO) => OO == this.active[KO])) && (XO = this.active);
        let bK = this.open,
          eO = OO.effects.some((OO => OO.is(RO)));
        bK && OO.docChanged && (bK = bK.map(OO.changes)), OO.selection || XO.some((KO => KO.hasResult() && OO.changes.touchesRange(KO.from, KO.to))) || ! function(OO, KO) {
          if (OO == KO) return !0;
          for (let pO = 0, XO = 0;;) {
            for (; pO < OO.length && !OO[pO].hasResult();) pO++;
            for (; XO < KO.length && !KO[XO].hasResult();) XO++;
            let bK = pO == OO.length,
              eO = XO == KO.length;
            if (bK || eO) return bK == eO;
            if (OO[pO++].result != KO[XO++].result) return !1
          }
        }(XO, this.active) || eO ? bK = jK.build(XO, KO, this.id, bK, pO, eO) : bK && bK.disabled && !XO.some((OO => OO.isPending)) && (bK = null), !bK && XO.every((OO => !OO.isPending)) && XO.some((OO => OO.hasResult())) && (XO = XO.map((OO => OO.hasResult() ? new sO(OO.source, 0) : OO)));
        for (let lO of OO.effects) lO.is(IO) && (bK = bK && bK.setSelected(lO.value, this.id));
        return XO == this.active && bK == this.open ? this : new YO(XO, this.id, bK)
      }
      get tooltip() {
        return this.open ? this.open.tooltip : null
      }
      get attrs() {
        return this.open ? this.open.attrs : this.active.length ? wO : iK
      }
    }
    const wO = {
        "aria-autocomplete": "list"
      },
      iK = {};

    function rK(OO, KO) {
      let pO = {
        "aria-autocomplete": "list",
        "aria-haspopup": "listbox",
        "aria-controls": OO
      };
      return KO > -1 && (pO["aria-activedescendant"] = OO + "-" + KO), pO
    }
    const PO = [];

    function mK(OO, KO) {
      if (OO.isUserEvent("input.complete")) {
        let pO = OO.annotation(oO);
        if (pO && KO.activateOnCompletion(pO)) return 12
      }
      let pO = OO.isUserEvent("input.type");
      return pO && KO.activateOnTyping ? 5 : pO ? 1 : OO.isUserEvent("delete.backward") ? 2 : OO.selection ? 8 : OO.docChanged ? 16 : 0
    }
    class sO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        this.source = OO, this.state = KO, this.explicit = pO
      }
      hasResult() {
        return !1
      }
      get isPending() {
        return 1 == this.state
      }
      update(OO, KO) {
        let pO = mK(OO, KO),
          XO = this;
        (8 & pO || 16 & pO && this.touches(OO)) && (XO = new sO(XO.source, 0)), 4 & pO && 0 == XO.state && (XO = new sO(this.source, 1)), XO = XO.updateFor(OO, pO);
        for (let bK of OO.effects)
          if (bK.is(QO)) XO = new sO(XO.source, 1, bK.value);
          else if (bK.is(zK)) XO = new sO(XO.source, 0);
        else if (bK.is(RO))
          for (let OO of bK.value) OO.source == XO.source && (XO = OO);
        return XO
      }
      updateFor(OO, KO) {
        return this.map(OO.changes)
      }
      map(OO) {
        return this
      }
      touches(OO) {
        return OO.changes.touchesRange(MO(OO.state))
      }
    }
    class HO extends sO {
      constructor(OO, KO, pO, XO, bK, eO) {
        super(OO, 3, KO), this.limit = pO, this.result = XO, this.from = bK, this.to = eO
      }
      hasResult() {
        return !0
      }
      updateFor(OO, KO) {
        var pO;
        if (!(3 & KO)) return this.map(OO.changes);
        let XO = this.result;
        XO.map && !OO.changes.empty && (XO = XO.map(XO, OO.changes));
        let bK = OO.changes.mapPos(this.from),
          eO = OO.changes.mapPos(this.to, 1),
          vK = MO(OO.state);
        if (vK > eO || !XO || 2 & KO && (MO(OO.startState) == this.from || vK < this.limit)) return new sO(this.source, 4 & KO ? 1 : 0);
        let CO = OO.changes.mapPos(this.limit);
        return function(OO, KO, pO, XO) {
          if (!OO) return !1;
          let bK = KO.sliceDoc(pO, XO);
          return "function" == typeof OO ? OO(bK, pO, XO, KO) : aK(OO, !0).test(bK)
        }(XO.validFor, OO.state, bK, eO) ? new HO(this.source, this.explicit, CO, XO, bK, eO) : XO.update && (XO = XO.update(XO, bK, eO, new lO(OO.state, vK, !1))) ? new HO(this.source, this.explicit, CO, XO, XO.from, null !== (pO = XO.to) && void 0 !== pO ? pO : MO(OO.state)) : new sO(this.source, 1, this.explicit)
      }
      map(OO) {
        if (OO.empty) return this;
        return (this.result.map ? this.result.map(this.result, OO) : this.result) ? new HO(this.source, this.explicit, OO.mapPos(this.limit), this.result, OO.mapPos(this.from), OO.mapPos(this.to, 1)) : new sO(this.source, 0)
      }
      touches(OO) {
        return OO.changes.touchesRange(this.from, this.to)
      }
    }
    const RO = XO.C.define({
        map: (OO, KO) => OO.map((OO => OO.map(KO)))
      }),
      SO = XO.G.define({
        create: () => YO.start(),
        update: (OO, KO) => OO.update(KO),
        provide: OO => [bK.eb.from(OO, (OO => OO.tooltip)), bK.h.contentAttributes.from(OO, (OO => OO.attrs))]
      });

    function JO(OO, KO) {
      const pO = KO.completion.apply || KO.completion.label;
      let XO = OO.state.field(SO).active.find((OO => OO.source == KO.source));
      return XO instanceof HO && ("string" == typeof pO ? OO.dispatch({
        ...FO(OO.state, pO, XO.from, XO.to),
        annotations: oO.of(KO.completion)
      }) : pO(OO, KO.completion, XO.from, XO.to), !0)
    }
    const cK = uO(SO, JO);

    function BO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "option";
      return pO => {
        let XO = pO.state.field(SO, !1);
        if (!XO || !XO.open || XO.open.disabled || Date.now() - XO.open.timestamp < pO.state.facet(dO).interactionDelay) return !1;
        let eO, lO = 1;
        "page" == KO && (eO = (0, bK.y)(pO, XO.open.tooltip)) && (lO = Math.max(2, Math.floor(eO.dom.offsetHeight / eO.dom.querySelector("li").offsetHeight) - 1));
        let {
          length: vK
        } = XO.open.options, CO = XO.open.selected > -1 ? XO.open.selected + lO * (OO ? 1 : -1) : OO ? 0 : vK - 1;
        return CO < 0 ? CO = "page" == KO ? 0 : vK - 1 : CO >= vK && (CO = "page" == KO ? vK - 1 : 0), pO.dispatch({
          effects: IO.of(CO)
        }), !0
      }
    }
    const ZO = OO => !!OO.state.field(SO, !1) && (OO.dispatch({
      effects: QO.of(!0)
    }), !0);
    class GO {
      constructor(OO, KO) {
        this.active = OO, this.context = KO, this.time = Date.now(), this.updates = [], this.done = void 0
      }
    }
    const qK = bK.l.fromClass(class {
        constructor(OO) {
          this.view = OO, this.debounceUpdate = -1, this.running = [], this.debounceAccept = -1, this.pendingStart = !1, this.composing = 0;
          for (let KO of OO.state.field(SO).active) KO.isPending && this.startQuery(KO)
        }
        update(OO) {
          let KO = OO.state.field(SO),
            pO = OO.state.facet(dO);
          if (!OO.selectionSet && !OO.docChanged && OO.startState.field(SO) == KO) return;
          let XO = OO.transactions.some((OO => {
            let KO = mK(OO, pO);
            return 8 & KO || (OO.selection || OO.docChanged) && !(3 & KO)
          }));
          for (let vK = 0; vK < this.running.length; vK++) {
            let KO = this.running[vK];
            if (XO || KO.context.abortOnDocChange && OO.docChanged || KO.updates.length + OO.transactions.length > 50 && Date.now() - KO.time > 1e3) {
              for (let OO of KO.context.abortListeners) try {
                OO()
              } catch (lO) {
                (0, bK.S)(this.view.state, lO)
              }
              KO.context.abortListeners = null, this.running.splice(vK--, 1)
            } else KO.updates.push(...OO.transactions)
          }
          this.debounceUpdate > -1 && clearTimeout(this.debounceUpdate), OO.transactions.some((OO => OO.effects.some((OO => OO.is(QO))))) && (this.pendingStart = !0);
          let eO = this.pendingStart ? 50 : pO.activateOnTypingDelay;
          if (this.debounceUpdate = KO.active.some((OO => OO.isPending && !this.running.some((KO => KO.active.source == OO.source)))) ? setTimeout((() => this.startUpdate()), eO) : -1, 0 != this.composing)
            for (let bK of OO.transactions) bK.isUserEvent("input.type") ? this.composing = 2 : 2 == this.composing && bK.selection && (this.composing = 3)
        }
        startUpdate() {
          this.debounceUpdate = -1, this.pendingStart = !1;
          let {
            state: OO
          } = this.view, KO = OO.field(SO);
          for (let pO of KO.active) pO.isPending && !this.running.some((OO => OO.active.source == pO.source)) && this.startQuery(pO);
          this.running.length && KO.open && KO.open.disabled && (this.debounceAccept = setTimeout((() => this.accept()), this.view.state.facet(dO).updateSyncTime))
        }
        startQuery(OO) {
          let {
            state: KO
          } = this.view, pO = MO(KO), XO = new lO(KO, pO, OO.explicit, this.view), eO = new GO(OO, XO);
          this.running.push(eO), Promise.resolve(OO.source(XO)).then((OO => {
            eO.context.aborted || (eO.done = OO || null, this.scheduleAccept())
          }), (OO => {
            this.view.dispatch({
              effects: zK.of(null)
            }), (0, bK.S)(this.view.state, OO)
          }))
        }
        scheduleAccept() {
          this.running.every((OO => void 0 !== OO.done)) ? this.accept() : this.debounceAccept < 0 && (this.debounceAccept = setTimeout((() => this.accept()), this.view.state.facet(dO).updateSyncTime))
        }
        accept() {
          var OO;
          this.debounceAccept > -1 && clearTimeout(this.debounceAccept), this.debounceAccept = -1;
          let KO = [],
            pO = this.view.state.facet(dO),
            XO = this.view.state.field(SO);
          for (let bK = 0; bK < this.running.length; bK++) {
            let eO = this.running[bK];
            if (void 0 === eO.done) continue;
            if (this.running.splice(bK--, 1), eO.done) {
              let XO = MO(eO.updates.length ? eO.updates[0].startState : this.view.state),
                bK = Math.min(XO, eO.done.from + (eO.active.explicit ? 0 : 1)),
                lO = new HO(eO.active.source, eO.active.explicit, bK, eO.done, eO.done.from, null !== (OO = eO.done.to) && void 0 !== OO ? OO : XO);
              for (let OO of eO.updates) lO = lO.update(OO, pO);
              if (lO.hasResult()) {
                KO.push(lO);
                continue
              }
            }
            let lO = XO.active.find((OO => OO.source == eO.active.source));
            if (lO && lO.isPending)
              if (null == eO.done) {
                let OO = new sO(eO.active.source, 0);
                for (let KO of eO.updates) OO = OO.update(KO, pO);
                OO.isPending || KO.push(OO)
              } else this.startQuery(lO)
          }(KO.length || XO.open && XO.open.disabled) && this.view.dispatch({
            effects: RO.of(KO)
          })
        }
      }, {
        eventHandlers: {
          blur(OO) {
            let KO = this.view.state.field(SO, !1);
            if (KO && KO.tooltip && this.view.state.facet(dO).closeOnBlur) {
              let pO = KO.open && (0, bK.y)(this.view, KO.open.tooltip);
              pO && pO.dom.contains(OO.relatedTarget) || setTimeout((() => this.view.dispatch({
                effects: zK.of(null)
              })), 10)
            }
          },
          compositionstart() {
            this.composing = 1
          },
          compositionend() {
            3 == this.composing && setTimeout((() => this.view.dispatch({
              effects: QO.of(!1)
            })), 20), this.composing = 0
          }
        }
      }),
      xK = "object" == typeof navigator && /Win/.test(navigator.platform),
      nO = XO.u.highest(bK.h.domEventHandlers({
        keydown(OO, KO) {
          let pO = KO.state.field(SO, !1);
          if (!pO || !pO.open || pO.open.disabled || pO.open.selected < 0 || OO.key.length > 1 || OO.ctrlKey && (!xK || !OO.altKey) || OO.metaKey) return !1;
          let XO = pO.open.options[pO.open.selected],
            bK = pO.active.find((OO => OO.source == XO.source)),
            eO = XO.completion.commitCharacters || bK.result.commitCharacters;
          return eO && eO.indexOf(OO.key) > -1 && JO(KO, XO), !1
        }
      })),
      WO = bK.h.baseTheme({
        ".cm-tooltip.cm-tooltip-autocomplete": {
          "& > ul": {
            fontFamily: "monospace",
            whiteSpace: "nowrap",
            overflow: "hidden auto",
            maxWidth_fallback: "700px",
            maxWidth: "min(700px, 95vw)",
            minWidth: "250px",
            maxHeight: "10em",
            height: "100%",
            listStyle: "none",
            margin: 0,
            padding: 0,
            "& > li, & > completion-section": {
              padding: "1px 3px",
              lineHeight: 1.2
            },
            "& > li": {
              overflowX: "hidden",
              textOverflow: "ellipsis",
              cursor: "pointer"
            },
            "& > completion-section": {
              display: "list-item",
              borderBottom: "1px solid silver",
              paddingLeft: "0.5em",
              opacity: .7
            }
          }
        },
        "&light .cm-tooltip-autocomplete ul li[aria-selected]": {
          background: "#17c",
          color: "white"
        },
        "&light .cm-tooltip-autocomplete-disabled ul li[aria-selected]": {
          background: "#777"
        },
        "&dark .cm-tooltip-autocomplete ul li[aria-selected]": {
          background: "#347",
          color: "white"
        },
        "&dark .cm-tooltip-autocomplete-disabled ul li[aria-selected]": {
          background: "#444"
        },
        ".cm-completionListIncompleteTop:before, .cm-completionListIncompleteBottom:after": {
          content: '"\xb7\xb7\xb7"',
          opacity: .5,
          display: "block",
          textAlign: "center"
        },
        ".cm-tooltip.cm-completionInfo": {
          position: "absolute",
          padding: "3px 9px",
          width: "max-content",
          maxWidth: "400px",
          boxSizing: "border-box",
          whiteSpace: "pre-line"
        },
        ".cm-completionInfo.cm-completionInfo-left": {
          right: "100%"
        },
        ".cm-completionInfo.cm-completionInfo-right": {
          left: "100%"
        },
        ".cm-completionInfo.cm-completionInfo-left-narrow": {
          right: "30px"
        },
        ".cm-completionInfo.cm-completionInfo-right-narrow": {
          left: "30px"
        },
        "&light .cm-snippetField": {
          backgroundColor: "#00000022"
        },
        "&dark .cm-snippetField": {
          backgroundColor: "#ffffff22"
        },
        ".cm-snippetFieldPosition": {
          verticalAlign: "text-top",
          width: 0,
          height: "1.15em",
          display: "inline-block",
          margin: "0 -0.7px -.7em",
          borderLeft: "1.4px dotted #888"
        },
        ".cm-completionMatchedText": {
          textDecoration: "underline"
        },
        ".cm-completionDetail": {
          marginLeft: "0.5em",
          fontStyle: "italic"
        },
        ".cm-completionIcon": {
          fontSize: "90%",
          width: ".8em",
          display: "inline-block",
          textAlign: "center",
          paddingRight: ".6em",
          opacity: "0.6",
          boxSizing: "content-box"
        },
        ".cm-completionIcon-function, .cm-completionIcon-method": {
          "&:after": {
            content: "'\u0192'"
          }
        },
        ".cm-completionIcon-class": {
          "&:after": {
            content: "'\u25cb'"
          }
        },
        ".cm-completionIcon-interface": {
          "&:after": {
            content: "'\u25cc'"
          }
        },
        ".cm-completionIcon-variable": {
          "&:after": {
            content: "'\ud835\udc65'"
          }
        },
        ".cm-completionIcon-constant": {
          "&:after": {
            content: "'\ud835\udc36'"
          }
        },
        ".cm-completionIcon-type": {
          "&:after": {
            content: "'\ud835\udc61'"
          }
        },
        ".cm-completionIcon-enum": {
          "&:after": {
            content: "'\u222a'"
          }
        },
        ".cm-completionIcon-property": {
          "&:after": {
            content: "'\u25a1'"
          }
        },
        ".cm-completionIcon-keyword": {
          "&:after": {
            content: "'\ud83d\udd11\ufe0e'"
          }
        },
        ".cm-completionIcon-namespace": {
          "&:after": {
            content: "'\u25a2'"
          }
        },
        ".cm-completionIcon-text": {
          "&:after": {
            content: "'abc'",
            fontSize: "50%",
            verticalAlign: "middle"
          }
        }
      });
    class tK {
      constructor(OO, KO, pO, XO) {
        this.field = OO, this.line = KO, this.from = pO, this.to = XO
      }
    }
    class kK {
      constructor(OO, KO, pO) {
        this.field = OO, this.from = KO, this.to = pO
      }
      map(OO) {
        let KO = OO.mapPos(this.from, -1, XO.r.TrackDel),
          pO = OO.mapPos(this.to, 1, XO.r.TrackDel);
        return null == KO || null == pO ? null : new kK(this.field, KO, pO)
      }
    }
    class UO {
      constructor(OO, KO) {
        this.lines = OO, this.fieldPositions = KO
      }
      instantiate(OO, KO) {
        let pO = [],
          XO = [KO],
          bK = OO.doc.lineAt(KO),
          lO = /^\s*/.exec(bK.text)[0];
        for (let CO of this.lines) {
          if (pO.length) {
            let pO = lO,
              bK = /^\t*/.exec(CO)[0].length;
            for (let KO = 0; KO < bK; KO++) pO += OO.facet(eO.W);
            XO.push(KO + pO.length - bK), CO = pO + CO.slice(bK)
          }
          pO.push(CO), KO += CO.length + 1
        }
        let vK = this.fieldPositions.map((OO => new kK(OO.field, XO[OO.line] + OO.from, XO[OO.line] + OO.to)));
        return {
          text: pO,
          Xl: vK
        }
      }
      static parse(OO) {
        let KO, pO = [],
          XO = [],
          bK = [];
        for (let eO of OO.split(/\r\n?|\n/)) {
          for (; KO = /[#$]\{(?:(\d+)(?::([^{}]*))?|((?:\\[{}]|[^{}])*))\}/.exec(eO);) {
            let OO = KO[1] ? +KO[1] : null,
              lO = KO[2] || KO[3] || "",
              vK = -1,
              CO = lO.replace(/\\[{}]/g, (OO => OO[1]));
            for (let KO = 0; KO < pO.length; KO++)(null != OO ? pO[KO].seq == OO : CO && pO[KO].name == CO) && (vK = KO);
            if (vK < 0) {
              let KO = 0;
              for (; KO < pO.length && (null == OO || null != pO[KO].seq && pO[KO].seq < OO);) KO++;
              pO.splice(KO, 0, {
                seq: OO,
                name: CO
              }), vK = KO;
              for (let OO of bK) OO.field >= vK && OO.field++
            }
            for (let pO of bK)
              if (pO.line == XO.length && pO.from > KO.index) {
                let OO = KO[2] ? 3 + (KO[1] || "").length : 2;
                pO.from -= OO, pO.to -= OO
              } bK.push(new tK(vK, XO.length, KO.index, KO.index + CO.length)), eO = eO.slice(0, KO.index) + lO + eO.slice(KO.index + KO[0].length)
          }
          eO = eO.replace(/\\([{}])/g, ((OO, KO, pO) => {
            for (let eO of bK) eO.line == XO.length && eO.from > pO && (eO.from--, eO.to--);
            return KO
          })), XO.push(eO)
        }
        return new UO(XO, bK)
      }
    }
    let OK = bK.c.widget({
        widget: new class extends bK.m {
          toDOM() {
            let OO = document.createElement("span");
            return OO.className = "cm-snippetFieldPosition", OO
          }
          ignoreEvent() {
            return !1
          }
        }
      }),
      KK = bK.c.mark({
        class: "cm-snippetField"
      });
    class pK {
      constructor(OO, KO) {
        this.Xl = OO, this.active = KO, this.deco = bK.c.set(OO.map((OO => (OO.from == OO.to ? OK : KK).range(OO.from, OO.to))), !0)
      }
      map(OO) {
        let KO = [];
        for (let pO of this.Xl) {
          let XO = pO.map(OO);
          if (!XO) return null;
          KO.push(XO)
        }
        return new pK(KO, this.active)
      }
      selectionInsideField(OO) {
        return OO.Xl.every((OO => this.Xl.some((KO => KO.field == this.active && KO.from <= OO.from && KO.to >= OO.to))))
      }
    }
    const XK = XO.C.define({
        map: (OO, KO) => OO && OO.map(KO)
      }),
      bp = XO.C.define(),
      eK = XO.G.define({
        create: () => null,
        update(OO, KO) {
          for (let pO of KO.effects) {
            if (pO.is(XK)) return pO.value;
            if (pO.is(bp) && OO) return new pK(OO.Xl, pO.value)
          }
          return OO && KO.docChanged && (OO = OO.map(KO.changes)), OO && KO.selection && !OO.selectionInsideField(KO.selection) && (OO = null), OO
        },
        provide: OO => bK.h.ql.from(OO, (OO => OO ? OO.deco : bK.c.none))
      });

    function lK(OO, KO) {
      return XO.j.create(OO.filter((OO => OO.field == KO)).map((OO => XO.j.range(OO.from, OO.to))))
    }

    function vp(OO) {
      let KO = UO.parse(OO);
      return (OO, pO, bK, eO) => {
        let {
          text: lO,
          Xl: vK
        } = KO.instantiate(OO.state, bK), {
          main: CO
        } = OO.state.selection, hO = {
          changes: {
            from: bK,
            to: eO == CO.from ? CO.to : eO,
            insert: XO.I.of(lO)
          },
          scrollIntoView: !0,
          annotations: pO ? [oO.of(pO), XO.M.userEvent.of("input.complete")] : void 0
        };
        if (vK.length && (hO.selection = lK(vK, 0)), vK.some((OO => OO.field > 0))) {
          let KO = new pK(vK, 0),
            pO = hO.effects = [XK.of(KO)];
          void 0 === OO.state.field(eK, !1) && pO.push(XO.C.appendConfig.of([eK, MK, oK, WO]))
        }
        OO.dispatch(OO.state.update(hO))
      }
    }

    function CK(OO) {
      return KO => {
        let {
          state: pO,
          dispatch: XO
        } = KO, bK = pO.field(eK, !1);
        if (!bK || OO < 0 && 0 == bK.active) return !1;
        let eO = bK.active + OO,
          lO = OO > 0 && !bK.Xl.some((KO => KO.field == eO + OO));
        return XO(pO.update({
          selection: lK(bK.Xl, eO),
          effects: XK.of(lO ? null : new pK(bK.Xl, eO)),
          scrollIntoView: !0
        })), !0
      }
    }
    const hK = [{
        key: "Tab",
        run: CK(1),
        shift: CK(-1)
      }, {
        key: "Escape",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          return !!KO.field(eK, !1) && (pO(KO.update({
            effects: XK.of(null)
          })), !0)
        }
      }],
      DK = XO.n.define({
        combine: OO => OO.length ? OO[0] : hK
      }),
      MK = XO.u.highest(bK.O.compute([DK], (OO => OO.facet(DK))));

    function ap(OO, KO) {
      return {
        ...KO,
        apply: vp(OO)
      }
    }
    const oK = bK.h.domEventHandlers({
      mousedown(OO, KO) {
        let pO, XO = KO.state.field(eK, !1);
        if (!XO || null == (pO = KO.posAtCoords({
            x: OO.clientX,
            y: OO.clientY
          }))) return !1;
        let bK = XO.Xl.find((OO => OO.from <= pO && OO.to >= pO));
        return !(!bK || bK.field == XO.active) && (KO.dispatch({
          selection: lK(XO.Xl, bK.field),
          effects: XK.of(XO.Xl.some((OO => OO.field > bK.field)) ? new pK(XO.Xl, bK.field) : null),
          scrollIntoView: !0
        }), !0)
      }
    });
    const FK = {
        brackets: ["(", "[", "{", "'", '"'],
        before: ")]}:;>",
        stringPrefixes: []
      },
      VK = XO.C.define({
        map(OO, KO) {
          let pO = KO.mapPos(OO, -1, XO.r.TrackAfter);
          return null == pO ? void 0 : pO
        }
      }),
      LK = new class extends XO.A {};
    LK.startSide = 1, LK.endSide = -1;
    const QK = XO.G.define({
      create: () => XO.y.empty,
      update(OO, KO) {
        if (OO = OO.map(KO.changes), KO.selection) {
          let pO = KO.state.doc.lineAt(KO.selection.main.head);
          OO = OO.update({
            filter: OO => OO >= pO.from && OO <= pO.to
          })
        }
        for (let pO of KO.effects) pO.is(VK) && (OO = OO.update({
          add: [LK.range(pO.value, pO.value + 1)]
        }));
        return OO
      }
    });

    function zp() {
      return [NK, QK]
    }
    const AK = "()[]{}<>\xab\xbb\xbb\xab\uff3b\uff3d\uff5b\uff5d";

    function fK(OO) {
      for (let KO = 0; KO < 16; KO += 2)
        if (AK.charCodeAt(KO) == OO) return AK.charAt(KO + 1);
      return (0, XO.ab)(OO < 128 ? OO : OO + 1)
    }

    function dK(OO, KO) {
      return OO.languageDataAt("closeBrackets", KO)[0] || FK
    }
    const TK = "object" == typeof navigator && /Android\b/.test(navigator.userAgent),
      NK = bK.h.inputHandler.of(((OO, KO, pO, bK) => {
        if ((TK ? OO.composing : OO.compositionStarted) || OO.state.readOnly) return !1;
        let eO = OO.state.selection.main;
        if (bK.length > 2 || 2 == bK.length && 1 == (0, XO.P)((0, XO.N)(bK, 0)) || KO != eO.from || pO != eO.to) return !1;
        let lO = function(OO, KO) {
          let pO = dK(OO, OO.selection.main.head),
            bK = pO.brackets || FK.brackets;
          for (let eO of bK) {
            let lO = fK((0, XO.N)(eO, 0));
            if (KO == eO) return lO == eO ? jp(OO, eO, bK.indexOf(eO + eO + eO) > -1, pO) : uK(OO, eO, lO, pO.before || FK.before);
            if (KO == lO && yp(OO, OO.selection.main.from)) return EK(OO, eO, lO)
          }
          return null
        }(OO.state, bK);
        return !!lO && (OO.dispatch(lO), !0)
      })),
      IK = [{
        key: "Backspace",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          if (KO.readOnly) return !1;
          let bK = dK(KO, KO.selection.main.head).brackets || FK.brackets,
            eO = null,
            lO = KO.changeByRange((OO => {
              if (OO.empty) {
                let pO = function(OO, KO) {
                  let pO = OO.sliceString(KO - 2, KO);
                  return (0, XO.P)((0, XO.N)(pO, 0)) == pO.length ? pO : pO.slice(1)
                }(KO.doc, OO.head);
                for (let eO of bK)
                  if (eO == pO && gp(KO.doc, OO.head) == fK((0, XO.N)(eO, 0))) return {
                    changes: {
                      from: OO.head - eO.length,
                      to: OO.head + eO.length
                    },
                    range: XO.j.cursor(OO.head - eO.length)
                  }
              }
              return {
                range: eO = OO
              }
            }));
          return eO || pO(KO.update(lO, {
            scrollIntoView: !0,
            userEvent: "delete.backward"
          })), !eO
        }
      }];

    function yp(OO, KO) {
      let pO = !1;
      return OO.field(QK).between(0, OO.doc.length, (OO => {
        OO == KO && (pO = !0)
      })), pO
    }

    function gp(OO, KO) {
      let pO = OO.sliceString(KO, KO + 2);
      return pO.slice(0, (0, XO.P)((0, XO.N)(pO, 0)))
    }

    function uK(OO, KO, pO, bK) {
      let eO = null,
        lO = OO.changeByRange((lO => {
          if (!lO.empty) return {
            changes: [{
              insert: KO,
              from: lO.from
            }, {
              insert: pO,
              from: lO.to
            }],
            effects: VK.of(lO.to + KO.length),
            range: XO.j.range(lO.anchor + KO.length, lO.head + KO.length)
          };
          let vK = gp(OO.doc, lO.head);
          return !vK || /\s/.test(vK) || bK.indexOf(vK) > -1 ? {
            changes: {
              insert: KO + pO,
              from: lO.head
            },
            effects: VK.of(lO.head + KO.length),
            range: XO.j.cursor(lO.head + KO.length)
          } : {
            range: eO = lO
          }
        }));
      return eO ? null : OO.update(lO, {
        scrollIntoView: !0,
        userEvent: "input.type"
      })
    }

    function EK(OO, KO, pO) {
      let bK = null,
        eO = OO.changeByRange((KO => KO.empty && gp(OO.doc, KO.head) == pO ? {
          changes: {
            from: KO.head,
            to: KO.head + pO.length,
            insert: pO
          },
          range: XO.j.cursor(KO.head + pO.length)
        } : bK = {
          range: KO
        }));
      return bK ? null : OO.update(eO, {
        scrollIntoView: !0,
        userEvent: "input.type"
      })
    }

    function jp(OO, KO, pO, bK) {
      let lO = bK.stringPrefixes || FK.stringPrefixes,
        vK = null,
        CO = OO.changeByRange((bK => {
          if (!bK.empty) return {
            changes: [{
              insert: KO,
              from: bK.from
            }, {
              insert: KO,
              from: bK.to
            }],
            effects: VK.of(bK.to + KO.length),
            range: XO.j.range(bK.anchor + KO.length, bK.head + KO.length)
          };
          let CO, hO = bK.head,
            DO = gp(OO.doc, hO);
          if (DO == KO) {
            if (YK(OO, hO)) return {
              changes: {
                insert: KO + KO,
                from: hO
              },
              effects: VK.of(hO + KO.length),
              range: XO.j.cursor(hO + KO.length)
            };
            if (yp(OO, hO)) {
              let bK = pO && OO.sliceDoc(hO, hO + 3 * KO.length) == KO + KO + KO ? KO + KO + KO : KO;
              return {
                changes: {
                  from: hO,
                  to: hO + bK.length,
                  insert: bK
                },
                range: XO.j.cursor(hO + bK.length)
              }
            }
          } else {
            if (pO && OO.sliceDoc(hO - 2 * KO.length, hO) == KO + KO && (CO = wK(OO, hO - 2 * KO.length, lO)) > -1 && YK(OO, CO)) return {
              changes: {
                insert: KO + KO + KO + KO,
                from: hO
              },
              effects: VK.of(hO + KO.length),
              range: XO.j.cursor(hO + KO.length)
            };
            if (OO.charCategorizer(hO)(DO) != XO.i.Word && wK(OO, hO, lO) > -1 && ! function(OO, KO, pO, XO) {
                let bK = (0, eO.ib)(OO).resolveInner(KO, -1),
                  lO = XO.reduce(((OO, KO) => Math.max(OO, KO.length)), 0);
                for (let eO = 0; eO < 5; eO++) {
                  let eO = OO.sliceDoc(bK.from, Math.min(bK.to, bK.from + pO.length + lO)),
                    vK = eO.indexOf(pO);
                  if (!vK || vK > -1 && XO.indexOf(eO.slice(0, vK)) > -1) {
                    let KO = bK.firstChild;
                    for (; KO && KO.from == bK.from && KO.to - KO.from > pO.length + vK;) {
                      if (OO.sliceDoc(KO.to - pO.length, KO.to) == pO) return !1;
                      KO = KO.firstChild
                    }
                    return !0
                  }
                  let CO = bK.to == KO && bK.parent;
                  if (!CO) break;
                  bK = CO
                }
                return !1
              }(OO, hO, KO, lO)) return {
              changes: {
                insert: KO + KO,
                from: hO
              },
              effects: VK.of(hO + KO.length),
              range: XO.j.cursor(hO + KO.length)
            }
          }
          return {
            range: vK = bK
          }
        }));
      return vK ? null : OO.update(CO, {
        scrollIntoView: !0,
        userEvent: "input.type"
      })
    }

    function YK(OO, KO) {
      let pO = (0, eO.ib)(OO).resolveInner(KO + 1);
      return pO.parent && pO.from == KO
    }

    function wK(OO, KO, pO) {
      let bK = OO.charCategorizer(KO);
      if (bK(OO.sliceDoc(KO - 1, KO)) != XO.i.Word) return KO;
      for (let eO of pO) {
        let pO = KO - eO.length;
        if (OO.sliceDoc(pO, KO) == eO && bK(OO.sliceDoc(pO - 1, pO)) != XO.i.Word) return pO
      }
      return -1
    }

    function ip() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      return [nO, SO, dO.of(OO), qK, PK, WO]
    }
    const rp = [{
        key: "Ctrl-Space",
        run: ZO
      }, {
        mac: "Alt-`",
        run: ZO
      }, {
        mac: "Alt-i",
        run: ZO
      }, {
        key: "Escape",
        run: OO => {
          let KO = OO.state.field(SO, !1);
          return !(!KO || !KO.active.some((OO => 0 != OO.state))) && (OO.dispatch({
            effects: zK.of(null)
          }), !0)
        }
      }, {
        key: "ArrowDown",
        run: BO(!0)
      }, {
        key: "ArrowUp",
        run: BO(!1)
      }, {
        key: "PageDown",
        run: BO(!0, "page")
      }, {
        key: "PageUp",
        run: BO(!1, "page")
      }, {
        key: "Enter",
        run: OO => {
          let KO = OO.state.field(SO, !1);
          return !(OO.state.readOnly || !KO || !KO.open || KO.open.selected < 0 || KO.open.disabled || Date.now() - KO.open.timestamp < OO.state.facet(dO).interactionDelay) && JO(OO, KO.open.options[KO.open.selected])
        }
      }],
      PK = XO.u.highest(bK.O.computeN([dO], (OO => OO.facet(dO).defaultKeymap ? [rp] : [])))
  },
  39483: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO,
      e: () => aK,
      h: () => DO,
      j: () => MO
    });
    var XO = pO(39338);
    class bK {
      constructor(OO, KO, pO, XO) {
        this.origin = OO, this.changes = KO, this.effects = pO, this.clientID = XO
      }
    }
    class eO {
      constructor(OO, KO) {
        this.version = OO, this.unconfirmed = KO
      }
    }
    const lO = XO.n.define({
        combine(OO) {
          let KO = (0, XO.T)(OO, {
            startVersion: 0,
            clientID: null,
            sharedEffects: () => []
          }, {
            generatedID: OO => OO
          });
          return null == KO.clientID && (KO.clientID = OO.length && OO[0].generatedID || ""), KO
        }
      }),
      vK = XO.d.define(),
      CO = XO.G.define({
        create: OO => new eO(OO.facet(lO).startVersion, []),
        update(OO, KO) {
          let pO = KO.annotation(vK);
          if (pO) return pO;
          let {
            sharedEffects: XO,
            clientID: CO
          } = KO.startState.facet(lO), hO = XO(KO);
          return hO.length || !KO.changes.empty ? new eO(OO.version, OO.unconfirmed.concat(new bK(KO, KO.changes, hO, CO))) : OO
        }
      });

    function hO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      return [CO, lO.of(Object.assign({
        generatedID: Math.floor(1e9 * Math.random()).toString(36)
      }, OO))]
    }

    function DO(OO, KO) {
      let {
        version: pO,
        unconfirmed: hO
      } = OO.field(CO), {
        clientID: DO
      } = OO.facet(lO);
      pO += KO.length;
      let MO = [],
        aK = null,
        oO = 0;
      for (let bK of KO) {
        let OO = oO < hO.length ? hO[oO] : null;
        OO && OO.clientID == bK.clientID ? (aK && (aK = aK.map(OO.changes, !0)), MO = XO.C.mapEffects(MO, bK.changes), oO++) : (MO = XO.C.mapEffects(MO, bK.changes), bK.effects && (MO = MO.concat(bK.effects)), aK = aK ? aK.compose(bK.changes) : bK.changes)
      }
      if (oO && (hO = hO.slice(oO)), hO.length && (aK && (hO = hO.map((OO => {
          let KO = OO.changes.map(aK);
          return aK = aK.map(OO.changes, !0), new bK(OO.origin, KO, XO.C.mapEffects(OO.effects, aK), DO)
        }))), MO.length)) {
        let OO = hO.reduce(((OO, KO) => OO.compose(KO.changes)), XO.ChangeSet.empty(hO[0].changes.length));
        MO = XO.C.mapEffects(MO, OO)
      }
      return aK ? OO.update({
        changes: aK,
        effects: MO,
        annotations: [XO.M.addToHistory.of(!1), XO.M.remote.of(!0), vK.of(new eO(pO, hO))],
        filter: !1
      }) : OO.update({
        annotations: [vK.of(new eO(pO, hO))]
      })
    }

    function MO(OO) {
      return OO.field(CO).unconfirmed
    }

    function aK(OO) {
      return OO.field(CO).version
    }
  },
  39364: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => VK
    });
    var XO = pO(39350);
    class bK {
      constructor(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        let hO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0,
          DO = arguments.length > 10 ? arguments[10] : void 0;
        this.p = OO, this.stack = KO, this.state = pO, this.reducePos = XO, this.pos = bK, this.score = eO, this.buffer = lO, this.bufferBase = vK, this.curContext = CO, this.lookAhead = hO, this.parent = DO
      }
      toString() {
        return `[${this.stack.filter(((OO,KO)=>KO%3==0)).concat(this.state)}]@${this.pos}${this.score?"!"+this.score:""}`
      }
      static start(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = OO.parser.context;
        return new bK(OO, [], KO, pO, pO, 0, [], 0, XO ? new eO(XO, XO.start) : null, 0, null)
      }
      get context() {
        return this.curContext ? this.curContext.context : null
      }
      pushState(OO, KO) {
        this.stack.push(this.state, KO, this.bufferBase + this.buffer.length), this.state = OO
      }
      reduce(OO) {
        var KO;
        let pO = OO >> 19,
          XO = 65535 & OO,
          {
            parser: bK
          } = this.p,
          eO = this.reducePos < this.pos - 25 && this.setLookAhead(this.pos),
          lO = bK.dynamicPrecedence(XO);
        if (lO && (this.score += lO), 0 == pO) return this.pushState(bK.getGoto(this.state, XO, !0), this.reducePos), XO < bK.minRepeatTerm && this.storeNode(XO, this.reducePos, this.reducePos, eO ? 8 : 4, !0), void this.reduceContext(XO, this.reducePos);
        let vK = this.stack.length - 3 * (pO - 1) - (262144 & OO ? 6 : 0),
          CO = vK ? this.stack[vK - 2] : this.p.Xl[0].from,
          hO = this.reducePos - CO;
        hO >= 2e3 && !(null === (KO = this.p.parser.nodeSet.types[XO]) || void 0 === KO ? void 0 : KO.isAnonymous) && (CO == this.p.lastBigReductionStart ? (this.p.bigReductionCount++, this.p.lastBigReductionSize = hO) : this.p.lastBigReductionSize < hO && (this.p.bigReductionCount = 1, this.p.lastBigReductionStart = CO, this.p.lastBigReductionSize = hO));
        let DO = vK ? this.stack[vK - 1] : 0,
          MO = this.bufferBase + this.buffer.length - DO;
        if (XO < bK.minRepeatTerm || 131072 & OO) {
          let OO = bK.stateFlag(this.state, 1) ? this.pos : this.reducePos;
          this.storeNode(XO, CO, OO, MO + 4, !0)
        }
        if (262144 & OO) this.state = this.stack[vK];
        else {
          let OO = this.stack[vK - 3];
          this.state = bK.getGoto(OO, XO, !0)
        }
        for (; this.stack.length > vK;) this.stack.pop();
        this.reduceContext(XO, CO)
      }
      storeNode(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 4,
          bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        if (0 == OO && (!this.stack.length || this.stack[this.stack.length - 1] < this.buffer.length + this.bufferBase)) {
          let OO = this,
            XO = this.buffer.length;
          if (0 == XO && OO.parent && (XO = OO.bufferBase - OO.parent.bufferBase, OO = OO.parent), XO > 0 && 0 == OO.buffer[XO - 4] && OO.buffer[XO - 1] > -1) {
            if (KO == pO) return;
            if (OO.buffer[XO - 2] >= KO) return void(OO.buffer[XO - 2] = pO)
          }
        }
        if (bK && this.pos != pO) {
          let bK = this.buffer.length;
          if (bK > 0 && (0 != this.buffer[bK - 4] || this.buffer[bK - 1] < 0)) {
            let OO = !1;
            for (let KO = bK; KO > 0 && this.buffer[KO - 2] > pO; KO -= 4)
              if (this.buffer[KO - 1] >= 0) {
                OO = !0;
                break
              } if (OO)
              for (; bK > 0 && this.buffer[bK - 2] > pO;) this.buffer[bK] = this.buffer[bK - 4], this.buffer[bK + 1] = this.buffer[bK - 3], this.buffer[bK + 2] = this.buffer[bK - 2], this.buffer[bK + 3] = this.buffer[bK - 1], bK -= 4, XO > 4 && (XO -= 4)
          }
          this.buffer[bK] = OO, this.buffer[bK + 1] = KO, this.buffer[bK + 2] = pO, this.buffer[bK + 3] = XO
        } else this.buffer.push(OO, KO, pO, XO)
      }
      shift(OO, KO, pO, XO) {
        if (131072 & OO) this.pushState(65535 & OO, this.pos);
        else if (0 == (262144 & OO)) {
          let bK = OO,
            {
              parser: eO
            } = this.p;
          this.pos = XO;
          let lO = eO.stateFlag(bK, 1);
          !lO && (XO > pO || KO <= eO.maxNode) && (this.reducePos = XO), this.pushState(bK, lO ? pO : Math.min(pO, this.reducePos)), this.shiftContext(KO, pO), KO <= eO.maxNode && this.buffer.push(KO, pO, XO, 4)
        } else this.pos = XO, this.shiftContext(KO, pO), KO <= this.p.parser.maxNode && this.buffer.push(KO, pO, XO, 4)
      }
      apply(OO, KO, pO, XO) {
        65536 & OO ? this.reduce(OO) : this.shift(OO, KO, pO, XO)
      }
      useNode(OO, KO) {
        let pO = this.p.reused.length - 1;
        (pO < 0 || this.p.reused[pO] != OO) && (this.p.reused.push(OO), pO++);
        let XO = this.pos;
        this.reducePos = this.pos = XO + OO.length, this.pushState(KO, XO), this.buffer.push(pO, XO, this.reducePos, -1), this.curContext && this.updateContext(this.curContext.tracker.reuse(this.curContext.context, OO, this, this.p.stream.reset(this.pos - OO.length)))
      }
      split() {
        let OO = this,
          KO = OO.buffer.length;
        for (; KO > 0 && OO.buffer[KO - 2] > OO.reducePos;) KO -= 4;
        let pO = OO.buffer.slice(KO),
          XO = OO.bufferBase + KO;
        for (; OO && XO == OO.bufferBase;) OO = OO.parent;
        return new bK(this.p, this.stack.slice(), this.state, this.reducePos, this.pos, this.score, pO, XO, this.curContext, this.lookAhead, OO)
      }
      recoverByDelete(OO, KO) {
        let pO = OO <= this.p.parser.maxNode;
        pO && this.storeNode(OO, this.pos, KO, 4), this.storeNode(0, this.pos, KO, pO ? 8 : 4), this.pos = this.reducePos = KO, this.score -= 190
      }
      canShift(OO) {
        for (let KO = new lO(this);;) {
          let pO = this.p.parser.stateSlot(KO.state, 4) || this.p.parser.hasAction(KO.state, OO);
          if (0 == pO) return !1;
          if (0 == (65536 & pO)) return !0;
          KO.reduce(pO)
        }
      }
      recoverByInsert(OO) {
        if (this.stack.length >= 300) return [];
        let KO = this.p.parser.nextStates(this.state);
        if (KO.length > 8 || this.stack.length >= 120) {
          let pO = [];
          for (let XO, bK = 0; bK < KO.length; bK += 2)(XO = KO[bK + 1]) != this.state && this.p.parser.hasAction(XO, OO) && pO.push(KO[bK], XO);
          if (this.stack.length < 120)
            for (let OO = 0; pO.length < 8 && OO < KO.length; OO += 2) {
              let XO = KO[OO + 1];
              pO.some(((OO, KO) => 1 & KO && OO == XO)) || pO.push(KO[OO], XO)
            }
          KO = pO
        }
        let pO = [];
        for (let XO = 0; XO < KO.length && pO.length < 4; XO += 2) {
          let OO = KO[XO + 1];
          if (OO == this.state) continue;
          let bK = this.split();
          bK.pushState(OO, this.pos), bK.storeNode(0, bK.pos, bK.pos, 4, !0), bK.shiftContext(KO[XO], this.pos), bK.reducePos = this.pos, bK.score -= 200, pO.push(bK)
        }
        return pO
      }
      forceReduce() {
        let {
          parser: OO
        } = this.p, KO = OO.stateSlot(this.state, 5);
        if (0 == (65536 & KO)) return !1;
        if (!OO.validAction(this.state, KO)) {
          let pO = KO >> 19,
            XO = 65535 & KO,
            bK = this.stack.length - 3 * pO;
          if (bK < 0 || OO.getGoto(this.stack[bK], XO, !1) < 0) {
            let OO = this.findForcedReduction();
            if (null == OO) return !1;
            KO = OO
          }
          this.storeNode(0, this.pos, this.pos, 4, !0), this.score -= 100
        }
        return this.reducePos = this.pos, this.reduce(KO), !0
      }
      findForcedReduction() {
        let {
          parser: OO
        } = this.p, KO = [], pO = (XO, bK) => {
          if (!KO.includes(XO)) return KO.push(XO), OO.allActions(XO, (KO => {
            if (393216 & KO);
            else if (65536 & KO) {
              let pO = (KO >> 19) - bK;
              if (pO > 1) {
                let XO = 65535 & KO,
                  bK = this.stack.length - 3 * pO;
                if (bK >= 0 && OO.getGoto(this.stack[bK], XO, !1) >= 0) return pO << 19 | 65536 | XO
              }
            } else {
              let OO = pO(KO, bK + 1);
              if (null != OO) return OO
            }
          }))
        };
        return pO(this.state, 0)
      }
      forceAll() {
        for (; !this.p.parser.stateFlag(this.state, 2);)
          if (!this.forceReduce()) {
            this.storeNode(0, this.pos, this.pos, 4, !0);
            break
          } return this
      }
      get deadEnd() {
        if (3 != this.stack.length) return !1;
        let {
          parser: OO
        } = this.p;
        return 65535 == OO.data[OO.stateSlot(this.state, 1)] && !OO.stateSlot(this.state, 4)
      }
      restart() {
        this.storeNode(0, this.pos, this.pos, 4, !0), this.state = this.stack[0], this.stack.length = 0
      }
      sameState(OO) {
        if (this.state != OO.state || this.stack.length != OO.stack.length) return !1;
        for (let KO = 0; KO < this.stack.length; KO += 3)
          if (this.stack[KO] != OO.stack[KO]) return !1;
        return !0
      }
      get parser() {
        return this.p.parser
      }
      dialectEnabled(OO) {
        return this.p.parser.dialect.flags[OO]
      }
      shiftContext(OO, KO) {
        this.curContext && this.updateContext(this.curContext.tracker.shift(this.curContext.context, OO, this, this.p.stream.reset(KO)))
      }
      reduceContext(OO, KO) {
        this.curContext && this.updateContext(this.curContext.tracker.reduce(this.curContext.context, OO, this, this.p.stream.reset(KO)))
      }
      emitContext() {
        let OO = this.buffer.length - 1;
        (OO < 0 || -3 != this.buffer[OO]) && this.buffer.push(this.curContext.hash, this.pos, this.pos, -3)
      }
      emitLookAhead() {
        let OO = this.buffer.length - 1;
        (OO < 0 || -4 != this.buffer[OO]) && this.buffer.push(this.lookAhead, this.pos, this.pos, -4)
      }
      updateContext(OO) {
        if (OO != this.curContext.context) {
          let KO = new eO(this.curContext.tracker, OO);
          KO.hash != this.curContext.hash && this.emitContext(), this.curContext = KO
        }
      }
      setLookAhead(OO) {
        return !(OO <= this.lookAhead) && (this.emitLookAhead(), this.lookAhead = OO, !0)
      }
      close() {
        this.curContext && this.curContext.tracker.strict && this.emitContext(), this.lookAhead > 0 && this.emitLookAhead()
      }
    }
    class eO {
      constructor(OO, KO) {
        this.tracker = OO, this.context = KO, this.hash = OO.strict ? OO.hash(KO) : 0
      }
    }
    class lO {
      constructor(OO) {
        this.start = OO, this.state = OO.state, this.stack = OO.stack, this.base = this.stack.length
      }
      reduce(OO) {
        let KO = 65535 & OO,
          pO = OO >> 19;
        0 == pO ? (this.stack == this.start.stack && (this.stack = this.stack.slice()), this.stack.push(this.state, 0, 0), this.base += 3) : this.base -= 3 * (pO - 1);
        let XO = this.start.p.parser.getGoto(this.stack[this.base - 3], KO, !0);
        this.state = XO
      }
    }
    class vK {
      constructor(OO, KO, pO) {
        this.stack = OO, this.pos = KO, this.index = pO, this.buffer = OO.buffer, 0 == this.index && this.maybeNext()
      }
      static create(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO.bufferBase + OO.buffer.length;
        return new vK(OO, KO, KO - OO.bufferBase)
      }
      maybeNext() {
        let OO = this.stack.parent;
        null != OO && (this.index = this.stack.bufferBase - OO.bufferBase, this.stack = OO, this.buffer = OO.buffer)
      }
      get id() {
        return this.buffer[this.index - 4]
      }
      get start() {
        return this.buffer[this.index - 3]
      }
      get end() {
        return this.buffer[this.index - 2]
      }
      get size() {
        return this.buffer[this.index - 1]
      }
      next() {
        this.index -= 4, this.pos -= 4, 0 == this.index && this.maybeNext()
      }
      fork() {
        return new vK(this.stack, this.pos, this.index)
      }
    }

    function CO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Uint16Array;
      if ("string" != typeof OO) return OO;
      let pO = null;
      for (let XO = 0, bK = 0; XO < OO.length;) {
        let eO = 0;
        for (;;) {
          let KO = OO.charCodeAt(XO++),
            pO = !1;
          if (126 == KO) {
            eO = 65535;
            break
          }
          KO >= 92 && KO--, KO >= 34 && KO--;
          let bK = KO - 32;
          if (bK >= 46 && (bK -= 46, pO = !0), eO += bK, pO) break;
          eO *= 46
        }
        pO ? pO[bK++] = eO : pO = new KO(eO)
      }
      return pO
    }
    class hO {
      constructor() {
        this.start = -1, this.value = -1, this.end = -1, this.extended = -1, this.lookAhead = 0, this.mask = 0, this.context = 0
      }
    }
    const DO = new hO;
    class MO {
      constructor(OO, KO) {
        this.input = OO, this.Xl = KO, this.chunk = "", this.chunkOff = 0, this.chunk2 = "", this.chunk2Pos = 0, this.next = -1, this.token = DO, this.rangeIndex = 0, this.pos = this.chunkPos = KO[0].from, this.range = KO[0], this.end = KO[KO.length - 1].to, this.readNext()
      }
      resolveOffset(OO, KO) {
        let pO = this.range,
          XO = this.rangeIndex,
          bK = this.pos + OO;
        for (; bK < pO.from;) {
          if (!XO) return null;
          let OO = this.Xl[--XO];
          bK -= pO.from - OO.to, pO = OO
        }
        for (; KO < 0 ? bK > pO.to : bK >= pO.to;) {
          if (XO == this.Xl.length - 1) return null;
          let OO = this.Xl[++XO];
          bK += OO.from - pO.to, pO = OO
        }
        return bK
      }
      clipPos(OO) {
        if (OO >= this.range.from && OO < this.range.to) return OO;
        for (let KO of this.Xl)
          if (KO.to > OO) return Math.max(OO, KO.from);
        return this.end
      }
      peek(OO) {
        let KO, pO, XO = this.chunkOff + OO;
        if (XO >= 0 && XO < this.chunk.length) KO = this.pos + OO, pO = this.chunk.charCodeAt(XO);
        else {
          let XO = this.resolveOffset(OO, 1);
          if (null == XO) return -1;
          if (KO = XO, KO >= this.chunk2Pos && KO < this.chunk2Pos + this.chunk2.length) pO = this.chunk2.charCodeAt(KO - this.chunk2Pos);
          else {
            let OO = this.rangeIndex,
              XO = this.range;
            for (; XO.to <= KO;) XO = this.Xl[++OO];
            this.chunk2 = this.input.chunk(this.chunk2Pos = KO), KO + this.chunk2.length > XO.to && (this.chunk2 = this.chunk2.slice(0, XO.to - KO)), pO = this.chunk2.charCodeAt(0)
          }
        }
        return KO >= this.token.lookAhead && (this.token.lookAhead = KO + 1), pO
      }
      acceptToken(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = KO ? this.resolveOffset(KO, -1) : this.pos;
        if (null == pO || pO < this.token.start) throw new RangeError("Token end out of bounds");
        this.token.value = OO, this.token.end = pO
      }
      acceptTokenTo(OO, KO) {
        this.token.value = OO, this.token.end = KO
      }
      getChunk() {
        if (this.pos >= this.chunk2Pos && this.pos < this.chunk2Pos + this.chunk2.length) {
          let {
            chunk: OO,
            chunkPos: KO
          } = this;
          this.chunk = this.chunk2, this.chunkPos = this.chunk2Pos, this.chunk2 = OO, this.chunk2Pos = KO, this.chunkOff = this.pos - this.chunkPos
        } else {
          this.chunk2 = this.chunk, this.chunk2Pos = this.chunkPos;
          let OO = this.input.chunk(this.pos),
            KO = this.pos + OO.length;
          this.chunk = KO > this.range.to ? OO.slice(0, this.range.to - this.pos) : OO, this.chunkPos = this.pos, this.chunkOff = 0
        }
      }
      readNext() {
        return this.chunkOff >= this.chunk.length && (this.getChunk(), this.chunkOff == this.chunk.length) ? this.next = -1 : this.next = this.chunk.charCodeAt(this.chunkOff)
      }
      advance() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
        for (this.chunkOff += OO; this.pos + OO >= this.range.to;) {
          if (this.rangeIndex == this.Xl.length - 1) return this.setDone();
          OO -= this.range.to - this.pos, this.range = this.Xl[++this.rangeIndex], this.pos = this.range.from
        }
        return this.pos += OO, this.pos >= this.token.lookAhead && (this.token.lookAhead = this.pos + 1), this.readNext()
      }
      setDone() {
        return this.pos = this.chunkPos = this.end, this.range = this.Xl[this.rangeIndex = this.Xl.length - 1], this.chunk = "", this.next = -1
      }
      reset(OO, KO) {
        if (KO ? (this.token = KO, KO.start = OO, KO.lookAhead = OO + 1, KO.value = KO.extended = -1) : this.token = DO, this.pos != OO) {
          if (this.pos = OO, OO == this.end) return this.setDone(), this;
          for (; OO < this.range.from;) this.range = this.Xl[--this.rangeIndex];
          for (; OO >= this.range.to;) this.range = this.Xl[++this.rangeIndex];
          OO >= this.chunkPos && OO < this.chunkPos + this.chunk.length ? this.chunkOff = OO - this.chunkPos : (this.chunk = "", this.chunkOff = 0), this.readNext()
        }
        return this
      }
      read(OO, KO) {
        if (OO >= this.chunkPos && KO <= this.chunkPos + this.chunk.length) return this.chunk.slice(OO - this.chunkPos, KO - this.chunkPos);
        if (OO >= this.chunk2Pos && KO <= this.chunk2Pos + this.chunk2.length) return this.chunk2.slice(OO - this.chunk2Pos, KO - this.chunk2Pos);
        if (OO >= this.range.from && KO <= this.range.to) return this.input.read(OO, KO);
        let pO = "";
        for (let XO of this.Xl) {
          if (XO.from >= KO) break;
          XO.to > OO && (pO += this.input.read(Math.max(XO.from, OO), Math.min(XO.to, KO)))
        }
        return pO
      }
    }
    class aK {
      constructor(OO, KO) {
        this.data = OO, this.id = KO
      }
      token(OO, KO) {
        let {
          parser: pO
        } = KO.p;
        VO(this.data, OO, KO, this.id, pO.data, pO.tokenPrecTable)
      }
    }
    aK.prototype.contextual = aK.prototype.fallback = aK.prototype.extend = !1;
    class oO {
      constructor(OO, KO, pO) {
        this.precTable = KO, this.elseToken = pO, this.data = "string" == typeof OO ? CO(OO) : OO
      }
      token(OO, KO) {
        let pO = OO.pos,
          XO = 0;
        for (;;) {
          let pO = OO.next < 0,
            bK = OO.resolveOffset(1, 1);
          if (VO(this.data, OO, KO, 0, this.data, this.precTable), OO.token.value > -1) break;
          if (null == this.elseToken) return;
          if (pO || XO++, null == bK) break;
          OO.reset(bK, OO.token)
        }
        XO && (OO.reset(pO, OO.token), OO.acceptToken(this.elseToken, XO))
      }
    }
    oO.prototype.contextual = aK.prototype.fallback = aK.prototype.extend = !1;
    class FO {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        this.token = OO, this.contextual = !!KO.contextual, this.fallback = !!KO.fallback, this.extend = !!KO.extend
      }
    }

    function VO(OO, KO, pO, XO, bK, eO) {
      let lO = 0,
        vK = 1 << XO,
        {
          dialect: CO
        } = pO.p.parser;
      OO: for (; 0 != (vK & OO[lO]);) {
        let pO = OO[lO + 1];
        for (let MO = lO + 3; MO < pO; MO += 2)
          if ((OO[MO + 1] & vK) > 0) {
            let pO = OO[MO];
            if (CO.allows(pO) && (-1 == KO.token.value || KO.token.value == pO || QO(pO, KO.token.value, bK, eO))) {
              KO.acceptToken(pO);
              break
            }
          } let XO = KO.next,
          hO = 0,
          DO = OO[lO + 2];
        if (!(KO.next < 0 && DO > hO && 65535 == OO[pO + 3 * DO - 3])) {
          for (; hO < DO;) {
            let bK = hO + DO >> 1,
              eO = pO + bK + (bK << 1),
              vK = OO[eO],
              CO = OO[eO + 1] || 65536;
            if (XO < vK) DO = bK;
            else {
              if (!(XO >= CO)) {
                lO = OO[eO + 2], KO.advance();
                continue OO
              }
              hO = bK + 1
            }
          }
          break
        }
        lO = OO[pO + 3 * DO - 1]
      }
    }

    function LO(OO, KO, pO) {
      for (let XO, bK = KO; 65535 != (XO = OO[bK]); bK++)
        if (XO == pO) return bK - KO;
      return -1
    }

    function QO(OO, KO, pO, XO) {
      let bK = LO(pO, XO, KO);
      return bK < 0 || LO(pO, XO, OO) < bK
    }
    const zK = "undefined" != typeof process && {
      NODE_ENV: "production",
      PUBLIC_URL: "",
      WDS_SOCKET_HOST: void 0,
      WDS_SOCKET_PATH: void 0,
      WDS_SOCKET_PORT: void 0,
      FAST_REFRESH: !0,
      REACT_APP_DEV_URLS: "false"
    } && /\bparse\b/.test({
      NODE_ENV: "production",
      PUBLIC_URL: "",
      WDS_SOCKET_HOST: void 0,
      WDS_SOCKET_PATH: void 0,
      WDS_SOCKET_PORT: void 0,
      FAST_REFRESH: !0,
      REACT_APP_DEV_URLS: "false"
    }.LOG);
    let AO = null;

    function fO(OO, KO, pO) {
      let bK = OO.cursor(XO.f.IncludeAnonymous);
      for (bK.moveTo(KO);;)
        if (!(pO < 0 ? bK.childBefore(KO) : bK.childAfter(KO)))
          for (;;) {
            if ((pO < 0 ? bK.to < KO : bK.from > KO) && !bK.type.isError) return pO < 0 ? Math.max(0, Math.min(bK.to - 1, KO - 25)) : Math.min(OO.length, Math.max(bK.from + 1, KO + 25));
            if (pO < 0 ? bK.prevSibling() : bK.nextSibling()) break;
            if (!bK.parent()) return pO < 0 ? 0 : OO.length
          }
    }
    class dO {
      constructor(OO, KO) {
        this.fragments = OO, this.nodeSet = KO, this.i = 0, this.fragment = null, this.safeFrom = -1, this.safeTo = -1, this.trees = [], this.start = [], this.index = [], this.nextFragment()
      }
      nextFragment() {
        let OO = this.fragment = this.i == this.fragments.length ? null : this.fragments[this.i++];
        if (OO) {
          for (this.safeFrom = OO.openStart ? fO(OO.tree, OO.from + OO.offset, 1) - OO.offset : OO.from, this.safeTo = OO.openEnd ? fO(OO.tree, OO.to + OO.offset, -1) - OO.offset : OO.to; this.trees.length;) this.trees.pop(), this.start.pop(), this.index.pop();
          this.trees.push(OO.tree), this.start.push(-OO.offset), this.index.push(0), this.nextStart = this.safeFrom
        } else this.nextStart = 1e9
      }
      nodeAt(OO) {
        if (OO < this.nextStart) return null;
        for (; this.fragment && this.safeTo <= OO;) this.nextFragment();
        if (!this.fragment) return null;
        for (;;) {
          let KO = this.trees.length - 1;
          if (KO < 0) return this.nextFragment(), null;
          let pO = this.trees[KO],
            bK = this.index[KO];
          if (bK == pO.children.length) {
            this.trees.pop(), this.start.pop(), this.index.pop();
            continue
          }
          let eO = pO.children[bK],
            lO = this.start[KO] + pO.positions[bK];
          if (lO > OO) return this.nextStart = lO, null;
          if (eO instanceof XO.B) {
            if (lO == OO) {
              if (lO < this.safeFrom) return null;
              let OO = lO + eO.length;
              if (OO <= this.safeTo) {
                let KO = eO.prop(XO.i.lookAhead);
                if (!KO || OO + KO < this.fragment.to) return eO
              }
            }
            this.index[KO]++, lO + eO.length >= Math.max(this.safeFrom, OO) && (this.trees.push(eO), this.start.push(lO), this.index.push(0))
          } else this.index[KO]++, this.nextStart = lO + eO.length
        }
      }
    }
    class TO {
      constructor(OO, KO) {
        this.stream = KO, this.tokens = [], this.mainToken = null, this.actions = [], this.tokens = OO.tokenizers.map((OO => new hO))
      }
      getActions(OO) {
        let KO = 0,
          pO = null,
          {
            parser: XO
          } = OO.p,
          {
            tokenizers: bK
          } = XO,
          eO = XO.stateSlot(OO.state, 3),
          lO = OO.curContext ? OO.curContext.hash : 0,
          vK = 0;
        for (let CO = 0; CO < bK.length; CO++) {
          if (0 == (1 << CO & eO)) continue;
          let XO = bK[CO],
            hO = this.tokens[CO];
          if ((!pO || XO.fallback) && ((XO.contextual || hO.start != OO.pos || hO.mask != eO || hO.context != lO) && (this.updateCachedToken(hO, XO, OO), hO.mask = eO, hO.context = lO), hO.lookAhead > hO.end + 25 && (vK = Math.max(hO.lookAhead, vK)), 0 != hO.value)) {
            let bK = KO;
            if (hO.extended > -1 && (KO = this.addActions(OO, hO.extended, hO.end, KO)), KO = this.addActions(OO, hO.value, hO.end, KO), !XO.extend && (pO = hO, KO > bK)) break
          }
        }
        for (; this.actions.length > KO;) this.actions.pop();
        return vK && OO.setLookAhead(vK), pO || OO.pos != this.stream.end || (pO = new hO, pO.value = OO.p.parser.eofTerm, pO.start = pO.end = OO.pos, KO = this.addActions(OO, pO.value, pO.end, KO)), this.mainToken = pO, this.actions
      }
      getMainToken(OO) {
        if (this.mainToken) return this.mainToken;
        let KO = new hO,
          {
            pos: pO,
            p: XO
          } = OO;
        return KO.start = pO, KO.end = Math.min(pO + 1, XO.stream.end), KO.value = pO == XO.stream.end ? XO.parser.eofTerm : 0, KO
      }
      updateCachedToken(OO, KO, pO) {
        let XO = this.stream.clipPos(pO.pos);
        if (KO.token(this.stream.reset(XO, OO), pO), OO.value > -1) {
          let {
            parser: KO
          } = pO.p;
          for (let XO = 0; XO < KO.specialized.length; XO++)
            if (KO.specialized[XO] == OO.value) {
              let bK = KO.specializers[XO](this.stream.read(OO.start, OO.end), pO);
              if (bK >= 0 && pO.p.parser.dialect.allows(bK >> 1)) {
                0 == (1 & bK) ? OO.value = bK >> 1 : OO.extended = bK >> 1;
                break
              }
            }
        } else OO.value = 0, OO.end = this.stream.clipPos(XO + 1)
      }
      putAction(OO, KO, pO, XO) {
        for (let bK = 0; bK < XO; bK += 3)
          if (this.actions[bK] == OO) return XO;
        return this.actions[XO++] = OO, this.actions[XO++] = KO, this.actions[XO++] = pO, XO
      }
      addActions(OO, KO, pO, XO) {
        let {
          state: bK
        } = OO, {
          parser: eO
        } = OO.p, {
          data: lO
        } = eO;
        for (let vK = 0; vK < 2; vK++)
          for (let OO = eO.stateSlot(bK, vK ? 2 : 1);; OO += 3) {
            if (65535 == lO[OO]) {
              if (1 != lO[OO + 1]) {
                0 == XO && 2 == lO[OO + 1] && (XO = this.putAction(EO(lO, OO + 2), KO, pO, XO));
                break
              }
              OO = EO(lO, OO + 2)
            }
            lO[OO] == KO && (XO = this.putAction(EO(lO, OO + 1), KO, pO, XO))
          }
        return XO
      }
    }
    class NO {
      constructor(OO, KO, pO, XO) {
        this.parser = OO, this.input = KO, this.Xl = XO, this.recovering = 0, this.nextStackID = 9812, this.minStackPos = 0, this.reused = [], this.stoppedAt = null, this.lastBigReductionStart = -1, this.lastBigReductionSize = 0, this.bigReductionCount = 0, this.stream = new MO(KO, XO), this.tokens = new TO(OO, this.stream), this.topTerm = OO.top[1];
        let {
          from: eO
        } = XO[0];
        this.stacks = [bK.start(this, OO.top[0], eO)], this.fragments = pO.length && this.stream.end - eO > 4 * OO.bufferLength ? new dO(pO, OO.nodeSet) : null
      }
      get parsedPos() {
        return this.minStackPos
      }
      advance() {
        let OO, KO, pO = this.stacks,
          XO = this.minStackPos,
          bK = this.stacks = [];
        if (this.bigReductionCount > 300 && 1 == pO.length) {
          let [OO] = pO;
          for (; OO.forceReduce() && OO.stack.length && OO.stack[OO.stack.length - 2] >= this.lastBigReductionStart;);
          this.bigReductionCount = this.lastBigReductionSize = 0
        }
        for (let eO = 0; eO < pO.length; eO++) {
          let lO = pO[eO];
          for (;;) {
            if (this.tokens.mainToken = null, lO.pos > XO) bK.push(lO);
            else {
              if (this.advanceStack(lO, bK, pO)) continue;
              {
                OO || (OO = [], KO = []), OO.push(lO);
                let pO = this.tokens.getMainToken(lO);
                KO.push(pO.value, pO.end)
              }
            }
            break
          }
        }
        if (!bK.length) {
          let KO = OO && function(OO) {
            let KO = null;
            for (let pO of OO) {
              let OO = pO.p.stoppedAt;
              (pO.pos == pO.p.stream.end || null != OO && pO.pos > OO) && pO.p.parser.stateFlag(pO.state, 2) && (!KO || KO.score < pO.score) && (KO = pO)
            }
            return KO
          }(OO);
          if (KO) return zK && console.log("Finish with " + this.stackID(KO)), this.stackToTree(KO);
          if (this.parser.strict) throw zK && OO && console.log("Stuck with token " + (this.tokens.mainToken ? this.parser.getName(this.tokens.mainToken.value) : "none")), new SyntaxError("No parse at " + XO);
          this.recovering || (this.recovering = 5)
        }
        if (this.recovering && OO) {
          let pO = null != this.stoppedAt && OO[0].pos > this.stoppedAt ? OO[0] : this.runRecovery(OO, KO, bK);
          if (pO) return zK && console.log("Force-finish " + this.stackID(pO)), this.stackToTree(pO.forceAll())
        }
        if (this.recovering) {
          let OO = 1 == this.recovering ? 1 : 3 * this.recovering;
          if (bK.length > OO)
            for (bK.sort(((OO, KO) => KO.score - OO.score)); bK.length > OO;) bK.pop();
          bK.some((OO => OO.reducePos > XO)) && this.recovering--
        } else if (bK.length > 1) {
          OO: for (let OO = 0; OO < bK.length - 1; OO++) {
            let KO = bK[OO];
            for (let pO = OO + 1; pO < bK.length; pO++) {
              let XO = bK[pO];
              if (KO.sameState(XO) || KO.buffer.length > 500 && XO.buffer.length > 500) {
                if (!((KO.score - XO.score || KO.buffer.length - XO.buffer.length) > 0)) {
                  bK.splice(OO--, 1);
                  continue OO
                }
                bK.splice(pO--, 1)
              }
            }
          }
          bK.length > 12 && (bK.sort(((OO, KO) => KO.score - OO.score)), bK.splice(12, bK.length - 12))
        }
        this.minStackPos = bK[0].pos;
        for (let eO = 1; eO < bK.length; eO++) bK[eO].pos < this.minStackPos && (this.minStackPos = bK[eO].pos);
        return null
      }
      stopAt(OO) {
        if (null != this.stoppedAt && this.stoppedAt < OO) throw new RangeError("Can't move stoppedAt forward");
        this.stoppedAt = OO
      }
      advanceStack(OO, KO, pO) {
        let bK = OO.pos,
          {
            parser: eO
          } = this,
          lO = zK ? this.stackID(OO) + " -> " : "";
        if (null != this.stoppedAt && bK > this.stoppedAt) return OO.forceReduce() ? OO : null;
        if (this.fragments) {
          let KO = OO.curContext && OO.curContext.tracker.strict,
            pO = KO ? OO.curContext.hash : 0;
          for (let vK = this.fragments.nodeAt(bK); vK;) {
            let bK = this.parser.nodeSet.types[vK.type.id] == vK.type ? eO.getGoto(OO.state, vK.type.id) : -1;
            if (bK > -1 && vK.length && (!KO || (vK.prop(XO.i.contextHash) || 0) == pO)) return OO.useNode(vK, bK), zK && console.log(lO + this.stackID(OO) + ` (via reuse of ${eO.getName(vK.type.id)})`), !0;
            if (!(vK instanceof XO.B) || 0 == vK.children.length || vK.positions[0] > 0) break;
            let CO = vK.children[0];
            if (!(CO instanceof XO.B && 0 == vK.positions[0])) break;
            vK = CO
          }
        }
        let vK = eO.stateSlot(OO.state, 4);
        if (vK > 0) return OO.reduce(vK), zK && console.log(lO + this.stackID(OO) + ` (via always-reduce ${eO.getName(65535&vK)})`), !0;
        if (OO.stack.length >= 8400)
          for (; OO.stack.length > 6e3 && OO.forceReduce(););
        let CO = this.tokens.getActions(OO);
        for (let XO = 0; XO < CO.length;) {
          let vK = CO[XO++],
            hO = CO[XO++],
            DO = CO[XO++],
            MO = XO == CO.length || !pO,
            aK = MO ? OO : OO.split(),
            oO = this.tokens.mainToken;
          if (aK.apply(vK, hO, oO ? oO.start : aK.pos, DO), zK && console.log(lO + this.stackID(aK) + ` (via ${0==(65536&vK)?"shift":`reduce of ${eO.getName(65535&vK)}`} for ${eO.getName(hO)} @ ${bK}${aK==OO?"":", split"})`), MO) return !0;
          aK.pos > bK ? KO.push(aK) : pO.push(aK)
        }
        return !1
      }
      advanceFully(OO, KO) {
        let pO = OO.pos;
        for (;;) {
          if (!this.advanceStack(OO, null, null)) return !1;
          if (OO.pos > pO) return IO(OO, KO), !0
        }
      }
      runRecovery(OO, KO, pO) {
        let XO = null,
          bK = !1;
        for (let eO = 0; eO < OO.length; eO++) {
          let lO = OO[eO],
            vK = KO[eO << 1],
            CO = KO[1 + (eO << 1)],
            hO = zK ? this.stackID(lO) + " -> " : "";
          if (lO.deadEnd) {
            if (bK) continue;
            if (bK = !0, lO.restart(), zK && console.log(hO + this.stackID(lO) + " (restarted)"), this.advanceFully(lO, pO)) continue
          }
          let DO = lO.split(),
            MO = hO;
          for (let OO = 0; OO < 10 && DO.forceReduce(); OO++) {
            if (zK && console.log(MO + this.stackID(DO) + " (via force-reduce)"), this.advanceFully(DO, pO)) break;
            zK && (MO = this.stackID(DO) + " -> ")
          }
          for (let OO of lO.recoverByInsert(vK)) zK && console.log(hO + this.stackID(OO) + " (via recover-insert)"), this.advanceFully(OO, pO);
          this.stream.end > lO.pos ? (CO == lO.pos && (CO++, vK = 0), lO.recoverByDelete(vK, CO), zK && console.log(hO + this.stackID(lO) + ` (via recover-delete ${this.parser.getName(vK)})`), IO(lO, pO)) : (!XO || XO.score < DO.score) && (XO = DO)
        }
        return XO
      }
      stackToTree(OO) {
        return OO.close(), XO.B.build({
          buffer: vK.create(OO),
          nodeSet: this.parser.nodeSet,
          topID: this.topTerm,
          maxBufferLength: this.parser.bufferLength,
          reused: this.reused,
          start: this.Xl[0].from,
          length: OO.pos - this.Xl[0].from,
          minRepeatType: this.parser.minRepeatTerm
        })
      }
      stackID(OO) {
        let KO = (AO || (AO = new WeakMap)).get(OO);
        return KO || AO.set(OO, KO = String.fromCodePoint(this.nextStackID++)), KO + OO
      }
    }

    function IO(OO, KO) {
      for (let pO = 0; pO < KO.length; pO++) {
        let XO = KO[pO];
        if (XO.pos == OO.pos && XO.sameState(OO)) return void(KO[pO].score < OO.score && (KO[pO] = OO))
      }
      KO.push(OO)
    }
    class yK {
      constructor(OO, KO, pO) {
        this.source = OO, this.flags = KO, this.disabled = pO
      }
      allows(OO) {
        return !this.disabled || 0 == this.disabled[OO]
      }
    }
    const gK = OO => OO;
    class uO extends XO.v {
      constructor(OO) {
        if (super(), this.wrappers = [], 14 != OO.version) throw new RangeError(`Parser version (${OO.version}) doesn't match runtime version (14)`);
        let KO = OO.nodeNames.split(" ");
        this.minRepeatTerm = KO.length;
        for (let XO = 0; XO < OO.repeatNodeCount; XO++) KO.push("");
        let pO = Object.keys(OO.topRules).map((KO => OO.topRules[KO][1])),
          bK = [];
        for (let XO = 0; XO < KO.length; XO++) bK.push([]);

        function eO(OO, KO, pO) {
          bK[OO].push([KO, KO.deserialize(String(pO))])
        }
        if (OO.nodeProps)
          for (let vK of OO.nodeProps) {
            let OO = vK[0];
            "string" == typeof OO && (OO = XO.i[OO]);
            for (let KO = 1; KO < vK.length;) {
              let pO = vK[KO++];
              if (pO >= 0) eO(pO, OO, vK[KO++]);
              else {
                let XO = vK[KO + -pO];
                for (let bK = -pO; bK > 0; bK--) eO(vK[KO++], OO, XO);
                KO++
              }
            }
          }
        this.nodeSet = new XO.m(KO.map(((KO, eO) => XO.q.define({
          name: eO >= this.minRepeatTerm ? void 0 : KO,
          id: eO,
          props: bK[eO],
          top: pO.indexOf(eO) > -1,
          error: 0 == eO,
          skipped: OO.skippedNodes && OO.skippedNodes.indexOf(eO) > -1
        })))), OO.propSources && (this.nodeSet = this.nodeSet.extend(...OO.propSources)), this.strict = !1, this.bufferLength = XO.c;
        let lO = CO(OO.tokenData);
        this.context = OO.context, this.specializerSpecs = OO.specialized || [], this.specialized = new Uint16Array(this.specializerSpecs.length);
        for (let XO = 0; XO < this.specializerSpecs.length; XO++) this.specialized[XO] = this.specializerSpecs[XO].term;
        this.specializers = this.specializerSpecs.map(jK), this.states = CO(OO.states, Uint32Array), this.data = CO(OO.stateData), this.goto = CO(OO.goto), this.maxTerm = OO.maxTerm, this.tokenizers = OO.tokenizers.map((OO => "number" == typeof OO ? new aK(lO, OO) : OO)), this.topRules = OO.topRules, this.dialects = OO.dialects || {}, this.dynamicPrecedences = OO.dynamicPrecedences || null, this.tokenPrecTable = OO.tokenPrec, this.termNames = OO.termNames || null, this.maxNode = this.nodeSet.types.length - 1, this.dialect = this.parseDialect(), this.top = this.topRules[Object.keys(this.topRules)[0]]
      }
      createParse(OO, KO, pO) {
        let XO = new NO(this, OO, KO, pO);
        for (let bK of this.wrappers) XO = bK(XO, OO, KO, pO);
        return XO
      }
      getGoto(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = this.goto;
        if (KO >= XO[0]) return -1;
        for (let bK = XO[KO + 1];;) {
          let KO = XO[bK++],
            eO = 1 & KO,
            lO = XO[bK++];
          if (eO && pO) return lO;
          for (let pO = bK + (KO >> 1); bK < pO; bK++)
            if (XO[bK] == OO) return lO;
          if (eO) return -1
        }
      }
      hasAction(OO, KO) {
        let pO = this.data;
        for (let XO = 0; XO < 2; XO++)
          for (let bK, eO = this.stateSlot(OO, XO ? 2 : 1);; eO += 3) {
            if (65535 == (bK = pO[eO])) {
              if (1 != pO[eO + 1]) {
                if (2 == pO[eO + 1]) return EO(pO, eO + 2);
                break
              }
              bK = pO[eO = EO(pO, eO + 2)]
            }
            if (bK == KO || 0 == bK) return EO(pO, eO + 1)
          }
        return 0
      }
      stateSlot(OO, KO) {
        return this.states[6 * OO + KO]
      }
      stateFlag(OO, KO) {
        return (this.stateSlot(OO, 0) & KO) > 0
      }
      validAction(OO, KO) {
        return !!this.allActions(OO, (OO => OO == KO || null))
      }
      allActions(OO, KO) {
        let pO = this.stateSlot(OO, 4),
          XO = pO ? KO(pO) : void 0;
        for (let bK = this.stateSlot(OO, 1); null == XO; bK += 3) {
          if (65535 == this.data[bK]) {
            if (1 != this.data[bK + 1]) break;
            bK = EO(this.data, bK + 2)
          }
          XO = KO(EO(this.data, bK + 1))
        }
        return XO
      }
      nextStates(OO) {
        let KO = [];
        for (let pO = this.stateSlot(OO, 1);; pO += 3) {
          if (65535 == this.data[pO]) {
            if (1 != this.data[pO + 1]) break;
            pO = EO(this.data, pO + 2)
          }
          if (0 == (1 & this.data[pO + 2])) {
            let OO = this.data[pO + 1];
            KO.some(((KO, pO) => 1 & pO && KO == OO)) || KO.push(this.data[pO], OO)
          }
        }
        return KO
      }
      configure(OO) {
        let KO = Object.assign(Object.create(uO.prototype), this);
        if (OO.props && (KO.nodeSet = this.nodeSet.extend(...OO.props)), OO.top) {
          let pO = this.topRules[OO.top];
          if (!pO) throw new RangeError(`Invalid top rule name ${OO.top}`);
          KO.top = pO
        }
        return OO.tokenizers && (KO.tokenizers = this.tokenizers.map((KO => {
          let pO = OO.tokenizers.find((OO => OO.from == KO));
          return pO ? pO.to : KO
        }))), OO.specializers && (KO.specializers = this.specializers.slice(), KO.specializerSpecs = this.specializerSpecs.map(((pO, XO) => {
          let bK = OO.specializers.find((OO => OO.from == pO.external));
          if (!bK) return pO;
          let eO = Object.assign(Object.assign({}, pO), {
            external: bK.to
          });
          return KO.specializers[XO] = jK(eO), eO
        }))), OO.contextTracker && (KO.context = OO.contextTracker), OO.dialect && (KO.dialect = this.parseDialect(OO.dialect)), null != OO.strict && (KO.strict = OO.strict), OO.wrap && (KO.wrappers = KO.wrappers.concat(OO.wrap)), null != OO.bufferLength && (KO.bufferLength = OO.bufferLength), KO
      }
      hasWrappers() {
        return this.wrappers.length > 0
      }
      getName(OO) {
        return this.termNames ? this.termNames[OO] : String(OO <= this.maxNode && this.nodeSet.types[OO].name || OO)
      }
      get eofTerm() {
        return this.maxNode + 1
      }
      get topNode() {
        return this.nodeSet.types[this.top[1]]
      }
      dynamicPrecedence(OO) {
        let KO = this.dynamicPrecedences;
        return null == KO ? 0 : KO[OO] || 0
      }
      parseDialect(OO) {
        let KO = Object.keys(this.dialects),
          pO = KO.map((() => !1));
        if (OO)
          for (let bK of OO.split(" ")) {
            let OO = KO.indexOf(bK);
            OO >= 0 && (pO[OO] = !0)
          }
        let XO = null;
        for (let bK = 0; bK < KO.length; bK++)
          if (!pO[bK])
            for (let OO, pO = this.dialects[KO[bK]]; 65535 != (OO = this.data[pO++]);)(XO || (XO = new Uint8Array(this.maxTerm + 1)))[OO] = 1;
        return new yK(OO, pO, XO)
      }
      static deserialize(OO) {
        return new uO(OO)
      }
    }

    function EO(OO, KO) {
      return OO[KO] | OO[KO + 1] << 16
    }

    function jK(OO) {
      if (OO.external) {
        let KO = OO.extend ? 1 : 0;
        return (pO, XO) => OO.external(pO, XO) << 1 | KO
      }
      return OO.get
    }
    var YO = pO(39358);
    const wO = [9, 10, 11, 12, 13, 32, 133, 160, 5760, 8192, 8193, 8194, 8195, 8196, 8197, 8198, 8199, 8200, 8201, 8202, 8232, 8233, 8239, 8287, 12288],
      iK = new class {
        constructor(OO) {
          this.start = OO.start, this.shift = OO.shift || gK, this.reduce = OO.reduce || gK, this.reuse = OO.reuse || gK, this.hash = OO.hash || (() => 0), this.strict = !1 !== OO.strict
        }
      }({
        start: !1,
        shift: (OO, KO) => 5 == KO || 6 == KO || 320 == KO ? OO : 321 == KO,
        strict: !1
      }),
      rK = new FO(((OO, KO) => {
        let {
          next: pO
        } = OO;
        (125 == pO || -1 == pO || KO.context) && OO.acceptToken(318)
      }), {
        contextual: !0,
        fallback: !0
      }),
      PO = new FO(((OO, KO) => {
        let pO, {
          next: XO
        } = OO;
        wO.indexOf(XO) > -1 || (47 != XO || 47 != (pO = OO.peek(1)) && 42 != pO) && (125 == XO || 59 == XO || -1 == XO || KO.context || OO.acceptToken(316))
      }), {
        contextual: !0
      }),
      mK = new FO(((OO, KO) => {
        91 != OO.next || KO.context || OO.acceptToken(317)
      }), {
        contextual: !0
      }),
      sO = new FO(((OO, KO) => {
        let {
          next: pO
        } = OO;
        if (43 == pO || 45 == pO) {
          if (OO.advance(), pO == OO.next) {
            OO.advance();
            let pO = !KO.context && KO.canShift(1);
            OO.acceptToken(pO ? 1 : 2)
          }
        } else 63 == pO && 46 == OO.peek(1) && (OO.advance(), OO.advance(), (OO.next < 48 || OO.next > 57) && OO.acceptToken(3))
      }), {
        contextual: !0
      });

    function HO(OO, KO) {
      return OO >= 65 && OO <= 90 || OO >= 97 && OO <= 122 || 95 == OO || OO >= 192 || !KO && OO >= 48 && OO <= 57
    }
    const RO = new FO(((OO, KO) => {
        if (60 != OO.next || !KO.dialectEnabled(0)) return;
        if (OO.advance(), 47 == OO.next) return;
        let pO = 0;
        for (; wO.indexOf(OO.next) > -1;) OO.advance(), pO++;
        if (HO(OO.next, !0)) {
          for (OO.advance(), pO++; HO(OO.next, !1);) OO.advance(), pO++;
          for (; wO.indexOf(OO.next) > -1;) OO.advance(), pO++;
          if (44 == OO.next) return;
          for (let KO = 0;; KO++) {
            if (7 == KO) {
              if (!HO(OO.next, !0)) return;
              break
            }
            if (OO.next != "extends".charCodeAt(KO)) break;
            OO.advance(), pO++
          }
        }
        OO.acceptToken(4, -pO)
      })),
      SO = (0, YO.h)({
        "get set async static": YO.l.modifier,
        "for while do if else switch try catch finally return throw break continue default case defer": YO.l.controlKeyword,
        "in of await yield void typeof delete instanceof as satisfies": YO.l.operatorKeyword,
        "let var const using function class extends": YO.l.definitionKeyword,
        "import export from": YO.l.moduleKeyword,
        "with debugger new": YO.l.keyword,
        TemplateString: YO.l.special(YO.l.string),
        super: YO.l.atom,
        BooleanLiteral: YO.l.bool,
        this: YO.l.self,
        null: YO.l.null,
        Star: YO.l.modifier,
        VariableName: YO.l.variableName,
        "CallExpression/VariableName TaggedTemplateExpression/VariableName": YO.l.function(YO.l.variableName),
        VariableDefinition: YO.l.definition(YO.l.variableName),
        Label: YO.l.labelName,
        PropertyName: YO.l.propertyName,
        PrivatePropertyName: YO.l.special(YO.l.propertyName),
        "CallExpression/MemberExpression/PropertyName": YO.l.function(YO.l.propertyName),
        "FunctionDeclaration/VariableDefinition": YO.l.function(YO.l.definition(YO.l.variableName)),
        "ClassDeclaration/VariableDefinition": YO.l.definition(YO.l.className),
        "NewExpression/VariableName": YO.l.className,
        PropertyDefinition: YO.l.definition(YO.l.propertyName),
        PrivatePropertyDefinition: YO.l.definition(YO.l.special(YO.l.propertyName)),
        UpdateOp: YO.l.updateOperator,
        "LineComment Hashbang": YO.l.lineComment,
        BlockComment: YO.l.blockComment,
        Number: YO.l.number,
        String: YO.l.string,
        Escape: YO.l.escape,
        ArithOp: YO.l.arithmeticOperator,
        LogicOp: YO.l.logicOperator,
        BitOp: YO.l.bitwiseOperator,
        CompareOp: YO.l.compareOperator,
        RegExp: YO.l.regexp,
        Equals: YO.l.definitionOperator,
        Arrow: YO.l.function(YO.l.punctuation),
        ": Spread": YO.l.punctuation,
        "( )": YO.l.paren,
        "[ ]": YO.l.squareBracket,
        "{ }": YO.l.brace,
        "InterpolationStart InterpolationEnd": YO.l.special(YO.l.brace),
        ".": YO.l.derefOperator,
        ", ;": YO.l.separator,
        "@": YO.l.meta,
        TypeName: YO.l.typeName,
        TypeDefinition: YO.l.definition(YO.l.typeName),
        "type enum interface implements namespace module declare": YO.l.definitionKeyword,
        "abstract global Privacy readonly override": YO.l.modifier,
        "is keyof unique infer asserts": YO.l.operatorKeyword,
        JSXAttributeValue: YO.l.attributeValue,
        JSXText: YO.l.content,
        "JSXStartTag JSXStartCloseTag JSXSelfCloseEndTag JSXEndTag": YO.l.angleBracket,
        "JSXIdentifier JSXNameSpacedName": YO.l.tagName,
        "JSXAttribute/JSXIdentifier JSXAttribute/JSXNameSpacedName": YO.l.attributeName,
        "JSXBuiltin/JSXIdentifier": YO.l.standard(YO.l.tagName)
      }),
      JO = {
        __proto__: null,
        export: 20,
        as: 25,
        from: 33,
        default: 36,
        async: 41,
        function: 42,
        in: 52,
        out: 55,
        const: 56,
        extends: 60,
        this: 64,
        true: 72,
        false: 72,
        null: 84,
        void: 88,
        typeof: 92,
        super: 108,
        new: 142,
        delete: 154,
        yield: 163,
        await: 167,
        class: 172,
        public: 235,
        private: 235,
        protected: 235,
        readonly: 237,
        instanceof: 256,
        satisfies: 259,
        import: 292,
        keyof: 349,
        unique: 353,
        infer: 359,
        asserts: 395,
        is: 397,
        abstract: 417,
        implements: 419,
        type: 421,
        let: 424,
        var: 426,
        using: 429,
        interface: 435,
        enum: 439,
        namespace: 445,
        module: 447,
        declare: 451,
        global: 455,
        defer: 471,
        for: 476,
        of: 485,
        while: 488,
        with: 492,
        do: 496,
        if: 500,
        else: 502,
        switch: 506,
        case: 512,
        try: 518,
        catch: 522,
        finally: 526,
        return: 530,
        throw: 534,
        break: 538,
        continue: 542,
        debugger: 546
      },
      cK = {
        __proto__: null,
        async: 129,
        get: 131,
        set: 133,
        declare: 195,
        public: 197,
        private: 197,
        protected: 197,
        static: 199,
        abstract: 201,
        override: 203,
        readonly: 209,
        accessor: 211,
        new: 401
      },
      BO = {
        __proto__: null,
        "<": 193
      },
      ZO = uO.deserialize({
        version: 14,
        states: "$F|Q%TQlOOO%[QlOOO'_QpOOP(lO`OOO*zQ!0MxO'#CiO+RO#tO'#CjO+aO&jO'#CjO+oO#@ItO'#DaO.QQlO'#DgO.bQlO'#DrO%[QlO'#DzO0fQlO'#ESOOQ!0Lf'#E['#E[O1PQ`O'#EXOOQO'#Ep'#EpOOQO'#Il'#IlO1XQ`O'#GsO1dQ`O'#EoO1iQ`O'#EoO3hQ!0MxO'#JrO6[Q!0MxO'#JsO6uQ`O'#F]O6zQ,UO'#FtOOQ!0Lf'#Ff'#FfO7VO7dO'#FfO9XQMhO'#F|O9`Q`O'#F{OOQ!0Lf'#Js'#JsOOQ!0Lb'#Jr'#JrO9eQ`O'#GwOOQ['#K_'#K_O9pQ`O'#IYO9uQ!0LrO'#IZOOQ['#J`'#J`OOQ['#I_'#I_Q`QlOOQ`QlOOO9}Q!L^O'#DvO:UQlO'#EOO:]QlO'#EQO9kQ`O'#GsO:dQMhO'#CoO:rQ`O'#EnO:}Q`O'#EyO;hQMhO'#FeO;xQ`O'#GsOOQO'#K`'#K`O;}Q`O'#K`O<]Q`O'#G{O<]Q`O'#G|O<]Q`O'#HOO9kQ`O'#HRO=SQ`O'#HUO>kQ`O'#CeO>{Q`O'#HcO?TQ`O'#HiO?TQ`O'#HkO`QlO'#HmO?TQ`O'#HoO?TQ`O'#HrO?YQ`O'#HxO?_Q!0LsO'#IOO%[QlO'#IQO?jQ!0LsO'#ISO?uQ!0LsO'#IUO9uQ!0LrO'#IWO@QQ!0MxO'#CiOASQpO'#DlQOQ`OOO%[QlO'#EQOAjQ`O'#ETO:dQMhO'#EnOAuQ`O'#EnOBQQ!bO'#FeOOQ['#Cg'#CgOOQ!0Lb'#Dq'#DqOOQ!0Lb'#Jv'#JvO%[QlO'#JvOOQO'#Jy'#JyOOQO'#Ih'#IhOCQQpO'#EgOOQ!0Lb'#Ef'#EfOOQ!0Lb'#J}'#J}OC|Q!0MSO'#EgODWQpO'#EWOOQO'#Jx'#JxODlQpO'#JyOEyQpO'#EWODWQpO'#EgPFWO&2DjO'#CbPOOO)CD})CD}OOOO'#I`'#I`OFcO#tO,59UOOQ!0Lh,59U,59UOOOO'#Ia'#IaOFqO&jO,59UOGPQ!L^O'#DcOOOO'#Ic'#IcOGWO#@ItO,59{OOQ!0Lf,59{,59{OGfQlO'#IdOGyQ`O'#JtOIxQ!fO'#JtO+}QlO'#JtOJPQ`O,5:ROJgQ`O'#EpOJtQ`O'#KTOKPQ`O'#KSOKPQ`O'#KSOKXQ`O,5;^OK^Q`O'#KROOQ!0Ln,5:^,5:^OKeQlO,5:^OMcQ!0MxO,5:fONSQ`O,5:nONmQ!0LrO'#KQONtQ`O'#KPO9eQ`O'#KPO! YQ`O'#KPO! bQ`O,5;]O! gQ`O'#KPO!#lQ!fO'#JsOOQ!0Lh'#Ci'#CiO%[QlO'#ESO!$[Q!fO,5:sOOQS'#Jz'#JzOOQO-E<j-E<jO9kQ`O,5=_O!$rQ`O,5=_O!$wQlO,5;ZO!&zQMhO'#EkO!(eQ`O,5;ZO!(jQlO'#DyO!(tQpO,5;dO!(|QpO,5;dO%[QlO,5;dOOQ['#FT'#FTOOQ['#FV'#FVO%[QlO,5;eO%[QlO,5;eO%[QlO,5;eO%[QlO,5;eO%[QlO,5;eO%[QlO,5;eO%[QlO,5;eO%[QlO,5;eO%[QlO,5;eO%[QlO,5;eOOQ['#FZ'#FZO!)[QlO,5;tOOQ!0Lf,5;y,5;yOOQ!0Lf,5;z,5;zOOQ!0Lf,5;|,5;|O%[QlO'#IpO!+_Q!0LrO,5<iO%[QlO,5;eO!&zQMhO,5;eO!+|QMhO,5;eO!-nQMhO'#E^O%[QlO,5;wOOQ!0Lf,5;{,5;{O!-uQ,UO'#FjO!.rQ,UO'#KXO!.^Q,UO'#KXO!.yQ,UO'#KXOOQO'#KX'#KXO!/_Q,UO,5<SOOOW,5<`,5<`O!/pQlO'#FvOOOW'#Io'#IoO7VO7dO,5<QO!/wQ,UO'#FxOOQ!0Lf,5<Q,5<QO!0hQ$IUO'#CyOOQ!0Lh'#C}'#C}O!0{O#@ItO'#DRO!1iQMjO,5<eO!1pQ`O,5<hO!3YQ(CWO'#GXO!3jQ`O'#GYO!3oQ`O'#GYO!5_Q(CWO'#G^O!6dQpO'#GbOOQO'#Gn'#GnO!,TQMhO'#GmOOQO'#Gp'#GpO!,TQMhO'#GoO!7VQ$IUO'#JlOOQ!0Lh'#Jl'#JlO!7aQ`O'#JkO!7oQ`O'#JjO!7wQ`O'#CuOOQ!0Lh'#C{'#C{O!8YQ`O'#C}OOQ!0Lh'#DV'#DVOOQ!0Lh'#DX'#DXO!8_Q`O,5<eO1SQ`O'#DZO!,TQMhO'#GPO!,TQMhO'#GRO!8gQ`O'#GTO!8lQ`O'#GUO!3oQ`O'#G[O!,TQMhO'#GaO<]Q`O'#JkO!8qQ`O'#EqO!9`Q`O,5<gOOQ!0Lb'#Cr'#CrO!9hQ`O'#ErO!:bQpO'#EsOOQ!0Lb'#KR'#KRO!:iQ!0LrO'#KaO9uQ!0LrO,5=cO`QlO,5>tOOQ['#Jh'#JhOOQ[,5>u,5>uOOQ[-E<]-E<]O!<hQ!0MxO,5:bO!:]QpO,5:`O!?RQ!0MxO,5:jO%[QlO,5:jO!AiQ!0MxO,5:lOOQO,5@z,5@zO!BYQMhO,5=_O!BhQ!0LrO'#JiO9`Q`O'#JiO!ByQ!0LrO,59ZO!CUQpO,59ZO!C^QMhO,59ZO:dQMhO,59ZO!CiQ`O,5;ZO!CqQ`O'#HbO!DVQ`O'#KdO%[QlO,5;}O!:]QpO,5<PO!D_Q`O,5=zO!DdQ`O,5=zO!DiQ`O,5=zO!DwQ`O,5=zO9uQ!0LrO,5=zO<]Q`O,5=jOOQO'#Cy'#CyO!EOQpO,5=gO!EWQMhO,5=hO!EcQ`O,5=jO!EhQ!bO,5=mO!EpQ`O'#K`O?YQ`O'#HWO9kQ`O'#HYO!EuQ`O'#HYO:dQMhO'#H[O!EzQ`O'#H[OOQ[,5=p,5=pO!FPQ`O'#H]O!FbQ`O'#CoO!FgQ`O,59PO!FqQ`O,59PO!HvQlO,59POOQ[,59P,59PO!IWQ!0LrO,59PO%[QlO,59PO!KcQlO'#HeOOQ['#Hf'#HfOOQ['#Hg'#HgO`QlO,5=}O!KyQ`O,5=}O`QlO,5>TO`QlO,5>VO!LOQ`O,5>XO`QlO,5>ZO!LTQ`O,5>^O!LYQlO,5>dOOQ[,5>j,5>jO%[QlO,5>jO9uQ!0LrO,5>lOOQ[,5>n,5>nO#!dQ`O,5>nOOQ[,5>p,5>pO#!dQ`O,5>pOOQ[,5>r,5>rO##QQpO'#D_O%[QlO'#JvO##sQpO'#JvO##}QpO'#DmO#$`QpO'#DmO#&qQlO'#DmO#&xQ`O'#JuO#'QQ`O,5:WO#'VQ`O'#EtO#'eQ`O'#KUO#'mQ`O,5;_O#'rQpO'#DmO#(PQpO'#EVOOQ!0Lf,5:o,5:oO%[QlO,5:oO#(WQ`O,5:oO?YQ`O,5;YO!CUQpO,5;YO!C^QMhO,5;YO:dQMhO,5;YO#(`Q`O,5@bO#(eQ07dO,5:sOOQO-E<f-E<fO#)kQ!0MSO,5;RODWQpO,5:rO#)uQpO,5:rODWQpO,5;RO!ByQ!0LrO,5:rOOQ!0Lb'#Ej'#EjOOQO,5;R,5;RO%[QlO,5;RO#*SQ!0LrO,5;RO#*_Q!0LrO,5;RO!CUQpO,5:rOOQO,5;X,5;XO#*mQ!0LrO,5;RPOOO'#I^'#I^P#+RO&2DjO,58|POOO,58|,58|OOOO-E<^-E<^OOQ!0Lh1G.p1G.pOOOO-E<_-E<_OOOO,59},59}O#+^Q!bO,59}OOOO-E<a-E<aOOQ!0Lf1G/g1G/gO#+cQ!fO,5?OO+}QlO,5?OOOQO,5?U,5?UO#+mQlO'#IdOOQO-E<b-E<bO#+zQ`O,5@`O#,SQ!fO,5@`O#,ZQ`O,5@nOOQ!0Lf1G/m1G/mO%[QlO,5@oO#,cQ`O'#IjOOQO-E<h-E<hO#,ZQ`O,5@nOOQ!0Lb1G0x1G0xOOQ!0Ln1G/x1G/xOOQ!0Ln1G0Y1G0YO%[QlO,5@lO#,wQ!0LrO,5@lO#-YQ!0LrO,5@lO#-aQ`O,5@kO9eQ`O,5@kO#-iQ`O,5@kO#-wQ`O'#ImO#-aQ`O,5@kOOQ!0Lb1G0w1G0wO!(tQpO,5:uO!)PQpO,5:uOOQS,5:w,5:wO#.iQdO,5:wO#.qQMhO1G2yO9kQ`O1G2yOOQ!0Lf1G0u1G0uO#/PQ!0MxO1G0uO#0UQ!0MvO,5;VOOQ!0Lh'#GW'#GWO#0rQ!0MzO'#JlO!$wQlO1G0uO#2}Q!fO'#JwO%[QlO'#JwO#3XQ`O,5:eOOQ!0Lh'#D_'#D_OOQ!0Lf1G1O1G1OO%[QlO1G1OOOQ!0Lf1G1f1G1fO#3^Q`O1G1OO#5rQ!0MxO1G1PO#5yQ!0MxO1G1PO#8aQ!0MxO1G1PO#8hQ!0MxO1G1PO#;OQ!0MxO1G1PO#=fQ!0MxO1G1PO#=mQ!0MxO1G1PO#=tQ!0MxO1G1PO#@[Q!0MxO1G1PO#@cQ!0MxO1G1PO#BpQ?MtO'#CiO#DkQ?MtO1G1`O#DrQ?MtO'#JsO#EVQ!0MxO,5?[OOQ!0Lb-E<n-E<nO#GdQ!0MxO1G1PO#HaQ!0MzO1G1POOQ!0Lf1G1P1G1PO#IdQMjO'#J|O#InQ`O,5:xO#IsQ!0MxO1G1cO#JgQ,UO,5<WO#JoQ,UO,5<XO#JwQ,UO'#FoO#K`Q`O'#FnOOQO'#KY'#KYOOQO'#In'#InO#KeQ,UO1G1nOOQ!0Lf1G1n1G1nOOOW1G1y1G1yO#KvQ?MtO'#JrO#LQQ`O,5<bO!)[QlO,5<bOOOW-E<m-E<mOOQ!0Lf1G1l1G1lO#LVQpO'#KXOOQ!0Lf,5<d,5<dO#L_QpO,5<dO#LdQMhO'#DTOOOO'#Ib'#IbO#LkO#@ItO,59mOOQ!0Lh,59m,59mO%[QlO1G2PO!8lQ`O'#IrO#LvQ`O,5<zOOQ!0Lh,5<w,5<wO!,TQMhO'#IuO#MdQMjO,5=XO!,TQMhO'#IwO#NVQMjO,5=ZO!&zQMhO,5=]OOQO1G2S1G2SO#NaQ!dO'#CrO#NtQ(CWO'#ErO$ |QpO'#GbO$!dQ!dO,5<sO$!kQ`O'#K[O9eQ`O'#K[O$!yQ`O,5<uO$#aQ!dO'#C{O!,TQMhO,5<tO$#kQ`O'#GZO$$PQ`O,5<tO$$UQ!dO'#GWO$$cQ!dO'#K]O$$mQ`O'#K]O!&zQMhO'#K]O$$rQ`O,5<xO$$wQlO'#JvO$%RQpO'#GcO#$`QpO'#GcO$%dQ`O'#GgO!3oQ`O'#GkO$%iQ!0LrO'#ItO$%tQpO,5<|OOQ!0Lp,5<|,5<|O$%{QpO'#GcO$&YQpO'#GdO$&kQpO'#GdO$&pQMjO,5=XO$'QQMjO,5=ZOOQ!0Lh,5=^,5=^O!,TQMhO,5@VO!,TQMhO,5@VO$'bQ`O'#IyO$'vQ`O,5@UO$(OQ`O,59aOOQ!0Lh,59i,59iO$(TQ`O,5@VO$)TQ$IYO,59uOOQ!0Lh'#Jp'#JpO$)vQMjO,5<kO$*iQMjO,5<mO@zQ`O,5<oOOQ!0Lh,5<p,5<pO$*sQ`O,5<vO$*xQMjO,5<{O$+YQ`O'#KPO!$wQlO1G2RO$+_Q`O1G2RO9eQ`O'#KSO9eQ`O'#EtO%[QlO'#EtO9eQ`O'#I{O$+dQ!0LrO,5@{OOQ[1G2}1G2}OOQ[1G4`1G4`OOQ!0Lf1G/|1G/|OOQ!0Lf1G/z1G/zO$-fQ!0MxO1G0UOOQ[1G2y1G2yO!&zQMhO1G2yO%[QlO1G2yO#.tQ`O1G2yO$/jQMhO'#EkOOQ!0Lb,5@T,5@TO$/wQ!0LrO,5@TOOQ[1G.u1G.uO!ByQ!0LrO1G.uO!CUQpO1G.uO!C^QMhO1G.uO$0YQ`O1G0uO$0_Q`O'#CiO$0jQ`O'#KeO$0rQ`O,5=|O$0wQ`O'#KeO$0|Q`O'#KeO$1[Q`O'#JRO$1jQ`O,5AOO$1rQ!fO1G1iOOQ!0Lf1G1k1G1kO9kQ`O1G3fO@zQ`O1G3fO$1yQ`O1G3fO$2OQ`O1G3fO!DiQ`O1G3fO9uQ!0LrO1G3fOOQ[1G3f1G3fO!EcQ`O1G3UO!&zQMhO1G3RO$2TQ`O1G3ROOQ[1G3S1G3SO!&zQMhO1G3SO$2YQ`O1G3SO$2bQpO'#HQOOQ[1G3U1G3UO!6_QpO'#I}O!EhQ!bO1G3XOOQ[1G3X1G3XOOQ[,5=r,5=rO$2jQMhO,5=tO9kQ`O,5=tO$%dQ`O,5=vO9`Q`O,5=vO!CUQpO,5=vO!C^QMhO,5=vO:dQMhO,5=vO$2xQ`O'#KcO$3TQ`O,5=wOOQ[1G.k1G.kO$3YQ!0LrO1G.kO@zQ`O1G.kO$3eQ`O1G.kO9uQ!0LrO1G.kO$5mQ!fO,5AQO$5zQ`O,5AQO9eQ`O,5AQO$6VQlO,5>PO$6^Q`O,5>POOQ[1G3i1G3iO`QlO1G3iOOQ[1G3o1G3oOOQ[1G3q1G3qO?TQ`O1G3sO$6cQlO1G3uO$:gQlO'#HtOOQ[1G3x1G3xO$:tQ`O'#HzO?YQ`O'#H|OOQ[1G4O1G4OO$:|QlO1G4OO9uQ!0LrO1G4UOOQ[1G4W1G4WOOQ!0Lb'#G_'#G_O9uQ!0LrO1G4YO9uQ!0LrO1G4[O$?TQ`O,5@bO!)[QlO,5;`O9eQ`O,5;`O?YQ`O,5:XO!)[QlO,5:XO!CUQpO,5:XO$?YQ?MtO,5:XOOQO,5;`,5;`O$?dQpO'#IeO$?zQ`O,5@aOOQ!0Lf1G/r1G/rO$@SQpO'#IkO$@^Q`O,5@pOOQ!0Lb1G0y1G0yO#$`QpO,5:XOOQO'#Ig'#IgO$@fQpO,5:qOOQ!0Ln,5:q,5:qO#(ZQ`O1G0ZOOQ!0Lf1G0Z1G0ZO%[QlO1G0ZOOQ!0Lf1G0t1G0tO?YQ`O1G0tO!CUQpO1G0tO!C^QMhO1G0tOOQ!0Lb1G5|1G5|O!ByQ!0LrO1G0^OOQO1G0m1G0mO%[QlO1G0mO$@mQ!0LrO1G0mO$@xQ!0LrO1G0mO!CUQpO1G0^ODWQpO1G0^O$AWQ!0LrO1G0mOOQO1G0^1G0^O$AlQ!0MxO1G0mPOOO-E<[-E<[POOO1G.h1G.hOOOO1G/i1G/iO$AvQ!bO,5<iO$BOQ!fO1G4jOOQO1G4p1G4pO%[QlO,5?OO$BYQ`O1G5zO$BbQ`O1G6YO$BjQ!fO1G6ZO9eQ`O,5?UO$BtQ!0MxO1G6WO%[QlO1G6WO$CUQ!0LrO1G6WO$CgQ`O1G6VO$CgQ`O1G6VO9eQ`O1G6VO$CoQ`O,5?XO9eQ`O,5?XOOQO,5?X,5?XO$DTQ`O,5?XO$+YQ`O,5?XOOQO-E<k-E<kOOQS1G0a1G0aOOQS1G0c1G0cO#.lQ`O1G0cOOQ[7+(e7+(eO!&zQMhO7+(eO%[QlO7+(eO$DcQ`O7+(eO$DnQMhO7+(eO$D|Q!0MzO,5=XO$GXQ!0MzO,5=ZO$IdQ!0MzO,5=XO$KuQ!0MzO,5=ZO$NWQ!0MzO,59uO%!]Q!0MzO,5<kO%$hQ!0MzO,5<mO%&sQ!0MzO,5<{OOQ!0Lf7+&a7+&aO%)UQ!0MxO7+&aO%)xQlO'#IfO%*VQ`O,5@cO%*_Q!fO,5@cOOQ!0Lf1G0P1G0PO%*iQ`O7+&jOOQ!0Lf7+&j7+&jO%*nQ?MtO,5:fO%[QlO7+&zO%*xQ?MtO,5:bO%+VQ?MtO,5:jO%+aQ?MtO,5:lO%+kQMhO'#IiO%+uQ`O,5@hOOQ!0Lh1G0d1G0dOOQO1G1r1G1rOOQO1G1s1G1sO%+}Q!jO,5<ZO!)[QlO,5<YOOQO-E<l-E<lOOQ!0Lf7+'Y7+'YOOOW7+'e7+'eOOOW1G1|1G1|O%,YQ`O1G1|OOQ!0Lf1G2O1G2OOOOO,59o,59oO%,_Q!dO,59oOOOO-E<`-E<`OOQ!0Lh1G/X1G/XO%,fQ!0MxO7+'kOOQ!0Lh,5?^,5?^O%-YQMhO1G2fP%-aQ`O'#IrPOQ!0Lh-E<p-E<pO%-}QMjO,5?aOOQ!0Lh-E<s-E<sO%.pQMjO,5?cOOQ!0Lh-E<u-E<uO%.zQ!dO1G2wO%/RQ!dO'#CrO%/iQMhO'#KSO$$wQlO'#JvOOQ!0Lh1G2_1G2_O%/sQ`O'#IqO%0[Q`O,5@vO%0[Q`O,5@vO%0dQ`O,5@vO%0oQ`O,5@vOOQO1G2a1G2aO%0}QMjO1G2`O$+YQ`O'#K[O!,TQMhO1G2`O%1_Q(CWO'#IsO%1lQ`O,5@wO!&zQMhO,5@wO%1tQ!dO,5@wOOQ!0Lh1G2d1G2dO%4UQ!fO'#CiO%4`Q`O,5=POOQ!0Lb,5<},5<}O%4hQpO,5<}OOQ!0Lb,5=O,5=OOCwQ`O,5<}O%4sQpO,5<}OOQ!0Lb,5=R,5=RO$+YQ`O,5=VOOQO,5?`,5?`OOQO-E<r-E<rOOQ!0Lp1G2h1G2hO#$`QpO,5<}O$$wQlO,5=PO%5RQ`O,5=OO%5^QpO,5=OO!,TQMhO'#IuO%6WQMjO1G2sO!,TQMhO'#IwO%6yQMjO1G2uO%7TQMjO1G5qO%7_QMjO1G5qOOQO,5?e,5?eOOQO-E<w-E<wOOQO1G.{1G.{O!,TQMhO1G5qO!,TQMhO1G5qO!:]QpO,59wO%[QlO,59wOOQ!0Lh,5<j,5<jO%7lQ`O1G2ZO!,TQMhO1G2bO%7qQ!0MxO7+'mOOQ!0Lf7+'m7+'mO!$wQlO7+'mO%8eQ`O,5;`OOQ!0Lb,5?g,5?gOOQ!0Lb-E<y-E<yO%8jQ!dO'#K^O#(ZQ`O7+(eO4UQ!fO7+(eO$DfQ`O7+(eO%8tQ!0MvO'#CiO%9XQ!0MvO,5=SO%9lQ`O,5=SO%9tQ`O,5=SOOQ!0Lb1G5o1G5oOOQ[7+$a7+$aO!ByQ!0LrO7+$aO!CUQpO7+$aO!$wQlO7+&aO%9yQ`O'#JQO%:bQ`O,5APOOQO1G3h1G3hO9kQ`O,5APO%:bQ`O,5APO%:jQ`O,5APOOQO,5?m,5?mOOQO-E=P-E=POOQ!0Lf7+'T7+'TO%:oQ`O7+)QO9uQ!0LrO7+)QO9kQ`O7+)QO@zQ`O7+)QO%:tQ`O7+)QOOQ[7+)Q7+)QOOQ[7+(p7+(pO%:yQ!0MvO7+(mO!&zQMhO7+(mO!E^Q`O7+(nOOQ[7+(n7+(nO!&zQMhO7+(nO%;TQ`O'#KbO%;`Q`O,5=lOOQO,5?i,5?iOOQO-E<{-E<{OOQ[7+(s7+(sO%<rQpO'#HZOOQ[1G3`1G3`O!&zQMhO1G3`O%[QlO1G3`O%<yQ`O1G3`O%=UQMhO1G3`O9uQ!0LrO1G3bO$%dQ`O1G3bO9`Q`O1G3bO!CUQpO1G3bO!C^QMhO1G3bO%=dQ`O'#JPO%=xQ`O,5@}O%>QQpO,5@}OOQ!0Lb1G3c1G3cOOQ[7+$V7+$VO@zQ`O7+$VO9uQ!0LrO7+$VO%>]Q`O7+$VO%[QlO1G6lO%[QlO1G6mO%>bQ!0LrO1G6lO%>lQlO1G3kO%>sQ`O1G3kO%>xQlO1G3kOOQ[7+)T7+)TO9uQ!0LrO7+)_O`QlO7+)aOOQ['#Kh'#KhOOQ['#JS'#JSO%?PQlO,5>`OOQ[,5>`,5>`O%[QlO'#HuO%?^Q`O'#HwOOQ[,5>f,5>fO9eQ`O,5>fOOQ[,5>h,5>hOOQ[7+)j7+)jOOQ[7+)p7+)pOOQ[7+)t7+)tOOQ[7+)v7+)vO%?cQpO1G5|O%?}Q?MtO1G0zO%@XQ`O1G0zOOQO1G/s1G/sO%@dQ?MtO1G/sO?YQ`O1G/sO!)[QlO'#DmOOQO,5?P,5?POOQO-E<c-E<cOOQO,5?V,5?VOOQO-E<i-E<iO!CUQpO1G/sOOQO-E<e-E<eOOQ!0Ln1G0]1G0]OOQ!0Lf7+%u7+%uO#(ZQ`O7+%uOOQ!0Lf7+&`7+&`O?YQ`O7+&`O!CUQpO7+&`OOQO7+%x7+%xO$AlQ!0MxO7+&XOOQO7+&X7+&XO%[QlO7+&XO%@nQ!0LrO7+&XO!ByQ!0LrO7+%xO!CUQpO7+%xO%@yQ!0LrO7+&XO%AXQ!0MxO7++rO%[QlO7++rO%AiQ`O7++qO%AiQ`O7++qOOQO1G4s1G4sO9eQ`O1G4sO%AqQ`O1G4sOOQS7+%}7+%}O#(ZQ`O<<LPO4UQ!fO<<LPO%BPQ`O<<LPOOQ[<<LP<<LPO!&zQMhO<<LPO%[QlO<<LPO%BXQ`O<<LPO%BdQ!0MzO,5?aO%DoQ!0MzO,5?cO%FzQ!0MzO1G2`O%I]Q!0MzO1G2sO%KhQ!0MzO1G2uO%MsQ!fO,5?QO%[QlO,5?QOOQO-E<d-E<dO%M}Q`O1G5}OOQ!0Lf<<JU<<JUO%NVQ?MtO1G0uO&!^Q?MtO1G1PO&!eQ?MtO1G1PO&$fQ?MtO1G1PO&$mQ?MtO1G1PO&&nQ?MtO1G1PO&(oQ?MtO1G1PO&(vQ?MtO1G1PO&(}Q?MtO1G1PO&+OQ?MtO1G1PO&+VQ?MtO1G1PO&+^Q!0MxO<<JfO&-UQ?MtO1G1PO&.RQ?MvO1G1PO&/UQ?MvO'#JlO&1[Q?MtO1G1cO&1iQ?MtO1G0UO&1sQMjO,5?TOOQO-E<g-E<gO!)[QlO'#FqOOQO'#KZ'#KZOOQO1G1u1G1uO&1}Q`O1G1tO&2SQ?MtO,5?[OOOW7+'h7+'hOOOO1G/Z1G/ZO&2^Q!dO1G4xOOQ!0Lh7+(Q7+(QP!&zQMhO,5?^O!,TQMhO7+(cO&2eQ`O,5?]O9eQ`O,5?]O$+YQ`O,5?]OOQO-E<o-E<oO&2sQ`O1G6bO&2sQ`O1G6bO&2{Q`O1G6bO&3WQMjO7+'zO&3hQ!dO,5?_O&3rQ`O,5?_O!&zQMhO,5?_OOQO-E<q-E<qO&3wQ!dO1G6cO&4RQ`O1G6cO&4ZQ`O1G2kO!&zQMhO1G2kOOQ!0Lb1G2i1G2iOOQ!0Lb1G2j1G2jO%4hQpO1G2iO!CUQpO1G2iOCwQ`O1G2iOOQ!0Lb1G2q1G2qO&4`QpO1G2iO&4nQ`O1G2kO$+YQ`O1G2jOCwQ`O1G2jO$$wQlO1G2kO&4vQ`O1G2jO&5jQMjO,5?aOOQ!0Lh-E<t-E<tO&6]QMjO,5?cOOQ!0Lh-E<v-E<vO!,TQMhO7++]O&6gQMjO7++]O&6qQMjO7++]OOQ!0Lh1G/c1G/cO&7OQ`O1G/cOOQ!0Lh7+'u7+'uO&7TQMjO7+'|O&7eQ!0MxO<<KXOOQ!0Lf<<KX<<KXO&8XQ`O1G0zO!&zQMhO'#IzO&8^Q`O,5@xO&:`Q!fO<<LPO!&zQMhO1G2nO&:gQ!0LrO1G2nOOQ[<<G{<<G{O!ByQ!0LrO<<G{O&:xQ!0MxO<<I{OOQ!0Lf<<I{<<I{OOQO,5?l,5?lO&;lQ`O,5?lO&;qQ`O,5?lOOQO-E=O-E=OO&<PQ`O1G6kO&<PQ`O1G6kO9kQ`O1G6kO@zQ`O<<LlOOQ[<<Ll<<LlO&<XQ`O<<LlO9uQ!0LrO<<LlO9kQ`O<<LlOOQ[<<LX<<LXO%:yQ!0MvO<<LXOOQ[<<LY<<LYO!E^Q`O<<LYO&<^QpO'#I|O&<iQ`O,5@|O!)[QlO,5@|OOQ[1G3W1G3WOOQO'#JO'#JOO9uQ!0LrO'#JOO&<qQpO,5=uOOQ[,5=u,5=uO&<xQpO'#EgO&=PQpO'#GeO&=UQ`O7+(zO&=ZQ`O7+(zOOQ[7+(z7+(zO!&zQMhO7+(zO%[QlO7+(zO&=cQ`O7+(zOOQ[7+(|7+(|O9uQ!0LrO7+(|O$%dQ`O7+(|O9`Q`O7+(|O!CUQpO7+(|O&=nQ`O,5?kOOQO-E<}-E<}OOQO'#H^'#H^O&=yQ`O1G6iO9uQ!0LrO<<GqOOQ[<<Gq<<GqO@zQ`O<<GqO&>RQ`O7+,WO&>WQ`O7+,XO%[QlO7+,WO%[QlO7+,XOOQ[7+)V7+)VO&>]Q`O7+)VO&>bQlO7+)VO&>iQ`O7+)VOOQ[<<Ly<<LyOOQ[<<L{<<L{OOQ[-E=Q-E=QOOQ[1G3z1G3zO&>nQ`O,5>aOOQ[,5>c,5>cO&>sQ`O1G4QO9eQ`O7+&fO!)[QlO7+&fOOQO7+%_7+%_O&>xQ?MtO1G6ZO?YQ`O7+%_OOQ!0Lf<<Ia<<IaOOQ!0Lf<<Iz<<IzO?YQ`O<<IzOOQO<<Is<<IsO$AlQ!0MxO<<IsO%[QlO<<IsOOQO<<Id<<IdO!ByQ!0LrO<<IdO&?SQ!0LrO<<IsO&?_Q!0MxO<= ^O&?oQ`O<= ]OOQO7+*_7+*_O9eQ`O7+*_OOQ[ANAkANAkO&?wQ!fOANAkO!&zQMhOANAkO#(ZQ`OANAkO4UQ!fOANAkO&@OQ`OANAkO%[QlOANAkO&@WQ!0MzO7+'zO&BiQ!0MzO,5?aO&DtQ!0MzO,5?cO&GPQ!0MzO7+'|O&IbQ!fO1G4lO&IlQ?MtO7+&aO&KpQ?MvO,5=XO&MwQ?MvO,5=ZO&NXQ?MvO,5=XO&NiQ?MvO,5=ZO&NyQ?MvO,59uO'#PQ?MvO,5<kO'%SQ?MvO,5<mO''hQ?MvO,5<{O')^Q?MtO7+'kO')kQ?MtO7+'mO')xQ`O,5<]OOQO7+'`7+'`OOQ!0Lh7+*d7+*dO')}QMjO<<K}OOQO1G4w1G4wO'*UQ`O1G4wO'*aQ`O1G4wO'*oQ`O7++|O'*oQ`O7++|O!&zQMhO1G4yO'*wQ!dO1G4yO'+RQ`O7++}O'+ZQ`O7+(VO'+fQ!dO7+(VOOQ!0Lb7+(T7+(TOOQ!0Lb7+(U7+(UO!CUQpO7+(TOCwQ`O7+(TO'+pQ`O7+(VO!&zQMhO7+(VO$+YQ`O7+(UO'+uQ`O7+(VOCwQ`O7+(UO'+}QMjO<<NwO!,TQMhO<<NwOOQ!0Lh7+$}7+$}O',XQ!dO,5?fOOQO-E<x-E<xO',cQ!0MvO7+(YO!&zQMhO7+(YOOQ[AN=gAN=gO9kQ`O1G5WOOQO1G5W1G5WO',sQ`O1G5WO',xQ`O7+,VO',xQ`O7+,VO9uQ!0LrOANBWO@zQ`OANBWOOQ[ANBWANBWO'-QQ`OANBWOOQ[ANAsANAsOOQ[ANAtANAtO'-VQ`O,5?hOOQO-E<z-E<zO'-bQ?MtO1G6hOOQO,5?j,5?jOOQO-E<|-E<|OOQ[1G3a1G3aO'-lQ`O,5=POOQ[<<Lf<<LfO!&zQMhO<<LfO&=UQ`O<<LfO'-qQ`O<<LfO%[QlO<<LfOOQ[<<Lh<<LhO9uQ!0LrO<<LhO$%dQ`O<<LhO9`Q`O<<LhO'-yQpO1G5VO'.UQ`O7+,TOOQ[AN=]AN=]O9uQ!0LrOAN=]OOQ[<= r<= rOOQ[<= s<= sO'.^Q`O<= rO'.cQ`O<= sOOQ[<<Lq<<LqO'.hQ`O<<LqO'.mQlO<<LqOOQ[1G3{1G3{O?YQ`O7+)lO'.tQ`O<<JQO'/PQ?MtO<<JQOOQO<<Hy<<HyOOQ!0LfAN?fAN?fOOQOAN?_AN?_O$AlQ!0MxOAN?_OOQOAN?OAN?OO%[QlOAN?_OOQO<<My<<MyOOQ[G27VG27VO!&zQMhOG27VO#(ZQ`OG27VO'/ZQ!fOG27VO4UQ!fOG27VO'/bQ`OG27VO'/jQ?MtO<<JfO'/wQ?MvO1G2`O'1mQ?MvO,5?aO'3pQ?MvO,5?cO'5sQ?MvO1G2sO'7vQ?MvO1G2uO'9yQ?MtO<<KXO':WQ?MtO<<I{OOQO1G1w1G1wO!,TQMhOANAiOOQO7+*c7+*cO':eQ`O7+*cO':pQ`O<= hO':xQ!dO7+*eOOQ!0Lb<<Kq<<KqO$+YQ`O<<KqOCwQ`O<<KqO';SQ`O<<KqO!&zQMhO<<KqOOQ!0Lb<<Ko<<KoO!CUQpO<<KoO';_Q!dO<<KqOOQ!0Lb<<Kp<<KpO';iQ`O<<KqO!&zQMhO<<KqO$+YQ`O<<KpO';nQMjOANDcO';xQ!0MvO<<KtOOQO7+*r7+*rO9kQ`O7+*rO'<YQ`O<= qOOQ[G27rG27rO9uQ!0LrOG27rO@zQ`OG27rO!)[QlO1G5SO'<bQ`O7+,SO'<jQ`O1G2kO&=UQ`OANBQOOQ[ANBQANBQO!&zQMhOANBQO'<oQ`OANBQOOQ[ANBSANBSO9uQ!0LrOANBSO$%dQ`OANBSOOQO'#H_'#H_OOQO7+*q7+*qOOQ[G22wG22wOOQ[ANE^ANE^OOQ[ANE_ANE_OOQ[ANB]ANB]O'<wQ`OANB]OOQ[<<MW<<MWO!)[QlOAN?lOOQOG24yG24yO$AlQ!0MxOG24yO#(ZQ`OLD,qOOQ[LD,qLD,qO!&zQMhOLD,qO'<|Q!fOLD,qO'=TQ?MvO7+'zO'>yQ?MvO,5?aO'@|Q?MvO,5?cO'CPQ?MvO7+'|O'DuQMjOG27TOOQO<<M}<<M}OOQ!0LbANA]ANA]O$+YQ`OANA]OCwQ`OANA]O'EVQ!dOANA]OOQ!0LbANAZANAZO'E^Q`OANA]O!&zQMhOANA]O'EiQ!dOANA]OOQ!0LbANA[ANA[OOQO<<N^<<N^OOQ[LD-^LD-^O9uQ!0LrOLD-^O'EsQ?MtO7+*nOOQO'#Gf'#GfOOQ[G27lG27lO&=UQ`OG27lO!&zQMhOG27lOOQ[G27nG27nO9uQ!0LrOG27nOOQ[G27wG27wO'E}Q?MtOG25WOOQOLD*eLD*eOOQ[!$(!]!$(!]O#(ZQ`O!$(!]O!&zQMhO!$(!]O'FXQ!0MzOG27TOOQ!0LbG26wG26wO$+YQ`OG26wO'HjQ`OG26wOCwQ`OG26wO'HuQ!dOG26wO!&zQMhOG26wOOQ[!$(!x!$(!xOOQ[LD-WLD-WO&=UQ`OLD-WOOQ[LD-YLD-YOOQ[!)9Ew!)9EwO#(ZQ`O!)9EwOOQ!0LbLD,cLD,cO$+YQ`OLD,cOCwQ`OLD,cO'H|Q`OLD,cO'IXQ!dOLD,cOOQ[!$(!r!$(!rOOQ[!.K;c!.K;cO'I`Q?MvOG27TOOQ!0Lb!$( }!$( }O$+YQ`O!$( }OCwQ`O!$( }O'KUQ`O!$( }OOQ!0Lb!)9Ei!)9EiO$+YQ`O!)9EiOCwQ`O!)9EiOOQ!0Lb!.K;T!.K;TO$+YQ`O!.K;TOOQ!0Lb!4/0o!4/0oO!)[QlO'#DzO1PQ`O'#EXO'KaQ!fO'#JrO'KhQ!L^O'#DvO'KoQlO'#EOO'KvQ!fO'#CiO'N^Q!fO'#CiO!)[QlO'#EQO'NnQlO,5;ZO!)[QlO,5;eO!)[QlO,5;eO!)[QlO,5;eO!)[QlO,5;eO!)[QlO,5;eO!)[QlO,5;eO!)[QlO,5;eO!)[QlO,5;eO!)[QlO,5;eO!)[QlO,5;eO!)[QlO'#IpO(!qQ`O,5<iO!)[QlO,5;eO(!yQMhO,5;eO($dQMhO,5;eO!)[QlO,5;wO!&zQMhO'#GmO(!yQMhO'#GmO!&zQMhO'#GoO(!yQMhO'#GoO1SQ`O'#DZO1SQ`O'#DZO!&zQMhO'#GPO(!yQMhO'#GPO!&zQMhO'#GRO(!yQMhO'#GRO!&zQMhO'#GaO(!yQMhO'#GaO!)[QlO,5:jO($kQpO'#D_O($uQpO'#JvO!)[QlO,5@oO'NnQlO1G0uO(%PQ?MtO'#CiO!)[QlO1G2PO!&zQMhO'#IuO(!yQMhO'#IuO!&zQMhO'#IwO(!yQMhO'#IwO(%ZQ!dO'#CrO!&zQMhO,5<tO(!yQMhO,5<tO'NnQlO1G2RO!)[QlO7+&zO!&zQMhO1G2`O(!yQMhO1G2`O!&zQMhO'#IuO(!yQMhO'#IuO!&zQMhO'#IwO(!yQMhO'#IwO!&zQMhO1G2bO(!yQMhO1G2bO'NnQlO7+'mO'NnQlO7+&aO!&zQMhOANAiO(!yQMhOANAiO(%nQ`O'#EoO(%sQ`O'#EoO(%{Q`O'#F]O(&QQ`O'#EyO(&VQ`O'#KTO(&bQ`O'#KRO(&mQ`O,5;ZO(&rQMjO,5<eO(&yQ`O'#GYO('OQ`O'#GYO('TQ`O,5<eO(']Q`O,5<gO('eQ`O,5;ZO('mQ?MtO1G1`O('tQ`O,5<tO('yQ`O,5<tO((OQ`O,5<vO((TQ`O,5<vO((YQ`O1G2RO((_Q`O1G0uO((dQMjO<<K}O((kQMjO<<K}O((rQMhO'#F|O9`Q`O'#F{OAuQ`O'#EnO!)[QlO,5;tO!3oQ`O'#GYO!3oQ`O'#GYO!3oQ`O'#G[O!3oQ`O'#G[O!,TQMhO7+(cO!,TQMhO7+(cO%.zQ!dO1G2wO%.zQ!dO1G2wO!&zQMhO,5=]O!&zQMhO,5=]",
        stateData: "()x~O'|OS'}OSTOS(ORQ~OPYOQYOSfOY!VOaqOdzOeyOl!POpkOrYOskOtkOzkO|YO!OYO!SWO!WkO!XkO!_XO!iuO!lZO!oYO!pYO!qYO!svO!uwO!xxO!|]O$W|O$niO%h}O%j!QO%l!OO%m!OO%n!OO%q!RO%s!SO%v!TO%w!TO%y!UO&W!WO&^!XO&`!YO&b!ZO&d![O&g!]O&m!^O&s!_O&u!`O&w!aO&y!bO&{!cO(TSO(VTO(YUO(aVO(o[O~OWtO~P`OPYOQYOSfOd!jOe!iOpkOrYOskOtkOzkO|YO!OYO!SWO!WkO!XkO!_!eO!iuO!lZO!oYO!pYO!qYO!svO!u!gO!x!hO$W!kO$niO(T!dO(VTO(YUO(aVO(o[O~Oa!wOs!nO!S!oO!b!yO!c!vO!d!vO!|<VO#T!pO#U!pO#V!xO#W!pO#X!pO#[!zO#]!zO(U!lO(VTO(YUO(e!mO(o!sO~O(O!{O~OP]XR]X[]Xa]Xj]Xr]X!Q]X!S]X!]]X!l]X!p]X#R]X#S]X#`]X#kfX#n]X#o]X#p]X#q]X#r]X#s]X#t]X#u]X#v]X#x]X#z]X#{]X$Q]X'z]X(a]X(r]X(y]X(z]X~O!g%RX~P(qO_!}O(V#PO(W!}O(X#PO~O_#QO(X#PO(Y#PO(Z#QO~Ox#SO!U#TO(b#TO(c#VO~OPYOQYOSfOd!jOe!iOpkOrYOskOtkOzkO|YO!OYO!SWO!WkO!XkO!_!eO!iuO!lZO!oYO!pYO!qYO!svO!u!gO!x!hO$W!kO$niO(T<ZO(VTO(YUO(aVO(o[O~O![#ZO!]#WO!Y(hP!Y(vP~P+}O!^#cO~P`OPYOQYOSfOd!jOe!iOrYOskOtkOzkO|YO!OYO!SWO!WkO!XkO!_!eO!iuO!lZO!oYO!pYO!qYO!svO!u!gO!x!hO$W!kO$niO(VTO(YUO(aVO(o[O~Op#mO![#iO!|]O#i#lO#j#iO(T<[O!k(sP~P.iO!l#oO(T#nO~O!x#sO!|]O%h#tO~O#k#uO~O!g#vO#k#uO~OP$[OR#zO[$cOj$ROr$aO!Q#yO!S#{O!]$_O!l#xO!p$[O#R$RO#n$OO#o$PO#p$PO#q$PO#r$QO#s$RO#t$RO#u$bO#v$SO#x$UO#z$WO#{$XO(aVO(r$YO(y#|O(z#}O~Oa(fX'z(fX'w(fX!k(fX!Y(fX!_(fX%i(fX!g(fX~P1qO#S$dO#`$eO$Q$eOP(gXR(gX[(gXj(gXr(gX!Q(gX!S(gX!](gX!l(gX!p(gX#R(gX#n(gX#o(gX#p(gX#q(gX#r(gX#s(gX#t(gX#u(gX#v(gX#x(gX#z(gX#{(gX(a(gX(r(gX(y(gX(z(gX!_(gX%i(gX~Oa(gX'z(gX'w(gX!Y(gX!k(gXv(gX!g(gX~P4UO#`$eO~O$]$hO$_$gO$f$mO~OSfO!_$nO$i$oO$k$qO~Oh%VOj%dOk%dOp%WOr%XOs$tOt$tOz%YO|%ZO!O%]O!S${O!_$|O!i%bO!l$xO#j%cO$W%`O$t%^O$v%_O$y%aO(T$sO(VTO(YUO(a$uO(y$}O(z%POg(^P~Ol%[O~P7eO!l%eO~O!S%hO!_%iO(T%gO~O!g%mO~Oa%nO'z%nO~O!Q%rO~P%[O(U!lO~P%[O%n%vO~P%[Oh%VO!l%eO(T%gO(U!lO~Oe%}O!l%eO(T%gO~Oj$RO~O!_&PO(T%gO(U!lO(VTO(YUO`)WP~O!Q&SO!l&RO%j&VO&T&WO~P;SO!x#sO~O%s&YO!S)SX!_)SX(T)SX~O(T&ZO~Ol!PO!u&`O%j!QO%l!OO%m!OO%n!OO%q!RO%s!SO%v!TO%w!TO~Od&eOe&dO!x&bO%h&cO%{&aO~P<bOd&hOeyOl!PO!_&gO!u&`O!xxO!|]O%h}O%l!OO%m!OO%n!OO%q!RO%s!SO%v!TO%w!TO%y!UO~Ob&kO#`&nO%j&iO(U!lO~P=gO!l&oO!u&sO~O!l#oO~O!_XO~Oa%nO'x&{O'z%nO~Oa%nO'x'OO'z%nO~Oa%nO'x'QO'z%nO~O'w]X!Y]Xv]X!k]X&[]X!_]X%i]X!g]X~P(qO!b'_O!c'WO!d'WO(U!lO(VTO(YUO~Os'UO!S'TO!['XO(e'SO!^(iP!^(xP~P@nOn'bO!_'`O(T%gO~Oe'gO!l%eO(T%gO~O!Q&SO!l&RO~Os!nO!S!oO!|<VO#T!pO#U!pO#W!pO#X!pO(U!lO(VTO(YUO(e!mO(o!sO~O!b'mO!c'lO!d'lO#V!pO#['nO#]'nO~PBYOa%nOh%VO!g#vO!l%eO'z%nO(r'pO~O!p'tO#`'rO~PChOs!nO!S!oO(VTO(YUO(e!mO(o!sO~O!_XOs(mX!S(mX!b(mX!c(mX!d(mX!|(mX#T(mX#U(mX#V(mX#W(mX#X(mX#[(mX#](mX(U(mX(V(mX(Y(mX(e(mX(o(mX~O!c'lO!d'lO(U!lO~PDWO(P'xO(Q'xO(R'zO~O_!}O(V'|O(W!}O(X'|O~O_#QO(X'|O(Y'|O(Z#QO~Ov(OO~P%[Ox#SO!U#TO(b#TO(c(RO~O![(TO!Y'WX!Y'^X!]'WX!]'^X~P+}O!](VO!Y(hX~OP$[OR#zO[$cOj$ROr$aO!Q#yO!S#{O!](VO!l#xO!p$[O#R$RO#n$OO#o$PO#p$PO#q$PO#r$QO#s$RO#t$RO#u$bO#v$SO#x$UO#z$WO#{$XO(aVO(r$YO(y#|O(z#}O~O!Y(hX~PHRO!Y([O~O!Y(uX!](uX!g(uX!k(uX(r(uX~O#`(uX#k#dX!^(uX~PJUO#`(]O!Y(wX!](wX~O!](^O!Y(vX~O!Y(aO~O#`$eO~PJUO!^(bO~P`OR#zO!Q#yO!S#{O!l#xO(aVOP!na[!naj!nar!na!]!na!p!na#R!na#n!na#o!na#p!na#q!na#r!na#s!na#t!na#u!na#v!na#x!na#z!na#{!na(r!na(y!na(z!na~Oa!na'z!na'w!na!Y!na!k!nav!na!_!na%i!na!g!na~PKlO!k(cO~O!g#vO#`(dO(r'pO!](tXa(tX'z(tX~O!k(tX~PNXO!S%hO!_%iO!|]O#i(iO#j(hO(T%gO~O!](jO!k(sX~O!k(lO~O!S%hO!_%iO#j(hO(T%gO~OP(gXR(gX[(gXj(gXr(gX!Q(gX!S(gX!](gX!l(gX!p(gX#R(gX#n(gX#o(gX#p(gX#q(gX#r(gX#s(gX#t(gX#u(gX#v(gX#x(gX#z(gX#{(gX(a(gX(r(gX(y(gX(z(gX~O!g#vO!k(gX~P! uOR(nO!Q(mO!l#xO#S$dO!|!{a!S!{a~O!x!{a%h!{a!_!{a#i!{a#j!{a(T!{a~P!#vO!x(rO~OPYOQYOSfOd!jOe!iOpkOrYOskOtkOzkO|YO!OYO!SWO!WkO!XkO!_XO!iuO!lZO!oYO!pYO!qYO!svO!u!gO!x!hO$W!kO$niO(T!dO(VTO(YUO(aVO(o[O~Oh%VOp%WOr%XOs$tOt$tOz%YO|%ZO!O<sO!S${O!_$|O!i>VO!l$xO#j<yO$W%`O$t<uO$v<wO$y%aO(T(vO(VTO(YUO(a$uO(y$}O(z%PO~O#k(xO~O![(zO!k(kP~P%[O(e(|O(o[O~O!S)OO!l#xO(e(|O(o[O~OP<UOQ<UOSfOd>ROe!iOpkOr<UOskOtkOzkO|<UO!O<UO!SWO!WkO!XkO!_!eO!i<XO!lZO!o<UO!p<UO!q<UO!s<YO!u<]O!x!hO$W!kO$n>PO(T)]O(VTO(YUO(aVO(o[O~O!]$_Oa$qa'z$qa'w$qa!k$qa!Y$qa!_$qa%i$qa!g$qa~Ol)dO~P!&zOh%VOp%WOr%XOs$tOt$tOz%YO|%ZO!O%]O!S${O!_$|O!i%bO!l$xO#j%cO$W%`O$t%^O$v%_O$y%aO(T(vO(VTO(YUO(a$uO(y$}O(z%PO~Og(pP~P!,TO!Q)iO!g)hO!_$^X$Z$^X$]$^X$_$^X$f$^X~O!g)hO!_({X$Z({X$]({X$_({X$f({X~O!Q)iO~P!.^O!Q)iO!_({X$Z({X$]({X$_({X$f({X~O!_)kO$Z)oO$])jO$_)jO$f)pO~O![)sO~P!)[O$]$hO$_$gO$f)wO~On$zX!Q$zX#S$zX'y$zX(y$zX(z$zX~OgmXg$zXnmX!]mX#`mX~P!0SOx)yO(b)zO(c)|O~On*VO!Q*OO'y*PO(y$}O(z%PO~Og)}O~P!1WOg*WO~Oh%VOr%XOs$tOt$tOz%YO|%ZO!O<sO!S*YO!_*ZO!i>VO!l$xO#j<yO$W%`O$t<uO$v<wO$y%aO(VTO(YUO(a$uO(y$}O(z%PO~Op*`O![*^O(T*XO!k)OP~P!1uO#k*aO~O!l*bO~Oh%VOp%WOr%XOs$tOt$tOz%YO|%ZO!O<sO!S${O!_$|O!i>VO!l$xO#j<yO$W%`O$t<uO$v<wO$y%aO(T*dO(VTO(YUO(a$uO(y$}O(z%PO~O![*gO!Y)PP~P!3tOr*sOs!nO!S*iO!b*qO!c*kO!d*kO!l*bO#[*rO%`*mO(U!lO(VTO(YUO(e!mO~O!^*pO~P!5iO#S$dOn(`X!Q(`X'y(`X(y(`X(z(`X!](`X#`(`X~Og(`X$O(`X~P!6kOn*xO#`*wOg(_X!](_X~O!]*yOg(^X~Oj%dOk%dOl%dO(T&ZOg(^P~Os*|O~Og)}O(T&ZO~O!l+SO~O(T(vO~Op+WO!S%hO![#iO!_%iO!|]O#i#lO#j#iO(T%gO!k(sP~O!g#vO#k+XO~O!S%hO![+ZO!](^O!_%iO(T%gO!Y(vP~Os'[O!S+]O![+[O(VTO(YUO(e(|O~O!^(xP~P!9|O!]+^Oa)TX'z)TX~OP$[OR#zO[$cOj$ROr$aO!Q#yO!S#{O!l#xO!p$[O#R$RO#n$OO#o$PO#p$PO#q$PO#r$QO#s$RO#t$RO#u$bO#v$SO#x$UO#z$WO#{$XO(aVO(r$YO(y#|O(z#}O~Oa!ja!]!ja'z!ja'w!ja!Y!ja!k!jav!ja!_!ja%i!ja!g!ja~P!:tOR#zO!Q#yO!S#{O!l#xO(aVOP!ra[!raj!rar!ra!]!ra!p!ra#R!ra#n!ra#o!ra#p!ra#q!ra#r!ra#s!ra#t!ra#u!ra#v!ra#x!ra#z!ra#{!ra(r!ra(y!ra(z!ra~Oa!ra'z!ra'w!ra!Y!ra!k!rav!ra!_!ra%i!ra!g!ra~P!=[OR#zO!Q#yO!S#{O!l#xO(aVOP!ta[!taj!tar!ta!]!ta!p!ta#R!ta#n!ta#o!ta#p!ta#q!ta#r!ta#s!ta#t!ta#u!ta#v!ta#x!ta#z!ta#{!ta(r!ta(y!ta(z!ta~Oa!ta'z!ta'w!ta!Y!ta!k!tav!ta!_!ta%i!ta!g!ta~P!?rOh%VOn+gO!_'`O%i+fO~O!g+iOa(]X!_(]X'z(]X!](]X~Oa%nO!_XO'z%nO~Oh%VO!l%eO~Oh%VO!l%eO(T%gO~O!g#vO#k(xO~Ob+tO%j+uO(T+qO(VTO(YUO!^)XP~O!]+vO`)WX~O[+zO~O`+{O~O!_&PO(T%gO(U!lO`)WP~O%j,OO~P;SOh%VO#`,SO~Oh%VOn,VO!_$|O~O!_,XO~O!Q,ZO!_XO~O%n%vO~O!x,`O~Oe,eO~Ob,fO(T#nO(VTO(YUO!^)VP~Oe%}O~O%j!QO(T&ZO~P=gO[,kO`,jO~OPYOQYOSfOdzOeyOpkOrYOskOtkOzkO|YO!OYO!SWO!WkO!XkO!iuO!lZO!oYO!pYO!qYO!svO!xxO!|]O$niO%h}O(VTO(YUO(aVO(o[O~O!_!eO!u!gO$W!kO(T!dO~P!FyO`,jOa%nO'z%nO~OPYOQYOSfOd!jOe!iOpkOrYOskOtkOzkO|YO!OYO!SWO!WkO!XkO!_!eO!iuO!lZO!oYO!pYO!qYO!svO!x!hO$W!kO$niO(T!dO(VTO(YUO(aVO(o[O~Oa,pOl!OO!uwO%l!OO%m!OO%n!OO~P!IcO!l&oO~O&^,vO~O!_,xO~O&o,zO&q,{OP&laQ&laS&laY&laa&lad&lae&lal&lap&lar&las&lat&laz&la|&la!O&la!S&la!W&la!X&la!_&la!i&la!l&la!o&la!p&la!q&la!s&la!u&la!x&la!|&la$W&la$n&la%h&la%j&la%l&la%m&la%n&la%q&la%s&la%v&la%w&la%y&la&W&la&^&la&`&la&b&la&d&la&g&la&m&la&s&la&u&la&w&la&y&la&{&la'w&la(T&la(V&la(Y&la(a&la(o&la!^&la&e&lab&la&j&la~O(T-QO~Oh!eX!]!RX!^!RX!g!RX!g!eX!l!eX#`!RX~O!]!eX!^!eX~P#!iO!g-VO#`-UOh(jX!]#hX!^#hX!g(jX!l(jX~O!](jX!^(jX~P##[Oh%VO!g-XO!l%eO!]!aX!^!aX~Os!nO!S!oO(VTO(YUO(e!mO~OP<UOQ<UOSfOd>ROe!iOpkOr<UOskOtkOzkO|<UO!O<UO!SWO!WkO!XkO!_!eO!i<XO!lZO!o<UO!p<UO!q<UO!s<YO!u<]O!x!hO$W!kO$n>PO(VTO(YUO(aVO(o[O~O(T=QO~P#$qO!]-]O!^(iX~O!^-_O~O!g-VO#`-UO!]#hX!^#hX~O!]-`O!^(xX~O!^-bO~O!c-cO!d-cO(U!lO~P#$`O!^-fO~P'_On-iO!_'`O~O!Y-nO~Os!{a!b!{a!c!{a!d!{a#T!{a#U!{a#V!{a#W!{a#X!{a#[!{a#]!{a(U!{a(V!{a(Y!{a(e!{a(o!{a~P!#vO!p-sO#`-qO~PChO!c-uO!d-uO(U!lO~PDWOa%nO#`-qO'z%nO~Oa%nO!g#vO#`-qO'z%nO~Oa%nO!g#vO!p-sO#`-qO'z%nO(r'pO~O(P'xO(Q'xO(R-zO~Ov-{O~O!Y'Wa!]'Wa~P!:tO![.PO!Y'WX!]'WX~P%[O!](VO!Y(ha~O!Y(ha~PHRO!](^O!Y(va~O!S%hO![.TO!_%iO(T%gO!Y'^X!]'^X~O#`.VO!](ta!k(taa(ta'z(ta~O!g#vO~P#,wO!](jO!k(sa~O!S%hO!_%iO#j.ZO(T%gO~Op.`O!S%hO![.]O!_%iO!|]O#i._O#j.]O(T%gO!]'aX!k'aX~OR.dO!l#xO~Oh%VOn.gO!_'`O%i.fO~Oa#ci!]#ci'z#ci'w#ci!Y#ci!k#civ#ci!_#ci%i#ci!g#ci~P!:tOn>]O!Q*OO'y*PO(y$}O(z%PO~O#k#_aa#_a#`#_a'z#_a!]#_a!k#_a!_#_a!Y#_a~P#/sO#k(`XP(`XR(`X[(`Xa(`Xj(`Xr(`X!S(`X!l(`X!p(`X#R(`X#n(`X#o(`X#p(`X#q(`X#r(`X#s(`X#t(`X#u(`X#v(`X#x(`X#z(`X#{(`X'z(`X(a(`X(r(`X!k(`X!Y(`X'w(`Xv(`X!_(`X%i(`X!g(`X~P!6kO!].tO!k(kX~P!:tO!k.wO~O!Y.yO~OP$[OR#zO!Q#yO!S#{O!l#xO!p$[O(aVO[#mia#mij#mir#mi!]#mi#R#mi#o#mi#p#mi#q#mi#r#mi#s#mi#t#mi#u#mi#v#mi#x#mi#z#mi#{#mi'z#mi(r#mi(y#mi(z#mi'w#mi!Y#mi!k#miv#mi!_#mi%i#mi!g#mi~O#n#mi~P#3cO#n$OO~P#3cOP$[OR#zOr$aO!Q#yO!S#{O!l#xO!p$[O#n$OO#o$PO#p$PO#q$PO(aVO[#mia#mij#mi!]#mi#R#mi#s#mi#t#mi#u#mi#v#mi#x#mi#z#mi#{#mi'z#mi(r#mi(y#mi(z#mi'w#mi!Y#mi!k#miv#mi!_#mi%i#mi!g#mi~O#r#mi~P#6QO#r$QO~P#6QOP$[OR#zO[$cOj$ROr$aO!Q#yO!S#{O!l#xO!p$[O#R$RO#n$OO#o$PO#p$PO#q$PO#r$QO#s$RO#t$RO#u$bO(aVOa#mi!]#mi#x#mi#z#mi#{#mi'z#mi(r#mi(y#mi(z#mi'w#mi!Y#mi!k#miv#mi!_#mi%i#mi!g#mi~O#v#mi~P#8oOP$[OR#zO[$cOj$ROr$aO!Q#yO!S#{O!l#xO!p$[O#R$RO#n$OO#o$PO#p$PO#q$PO#r$QO#s$RO#t$RO#u$bO#v$SO(aVO(z#}Oa#mi!]#mi#z#mi#{#mi'z#mi(r#mi(y#mi'w#mi!Y#mi!k#miv#mi!_#mi%i#mi!g#mi~O#x$UO~P#;VO#x#mi~P#;VO#v$SO~P#8oOP$[OR#zO[$cOj$ROr$aO!Q#yO!S#{O!l#xO!p$[O#R$RO#n$OO#o$PO#p$PO#q$PO#r$QO#s$RO#t$RO#u$bO#v$SO#x$UO(aVO(y#|O(z#}Oa#mi!]#mi#{#mi'z#mi(r#mi'w#mi!Y#mi!k#miv#mi!_#mi%i#mi!g#mi~O#z#mi~P#={O#z$WO~P#={OP]XR]X[]Xj]Xr]X!Q]X!S]X!l]X!p]X#R]X#S]X#`]X#kfX#n]X#o]X#p]X#q]X#r]X#s]X#t]X#u]X#v]X#x]X#z]X#{]X$Q]X(a]X(r]X(y]X(z]X!]]X!^]X~O$O]X~P#@jOP$[OR#zO[<mOj<bOr<kO!Q#yO!S#{O!l#xO!p$[O#R<bO#n<_O#o<`O#p<`O#q<`O#r<aO#s<bO#t<bO#u<lO#v<cO#x<eO#z<gO#{<hO(aVO(r$YO(y#|O(z#}O~O$O.{O~P#BwO#S$dO#`<nO$Q<nO$O(gX!^(gX~P! uOa'da!]'da'z'da'w'da!k'da!Y'dav'da!_'da%i'da!g'da~P!:tO[#mia#mij#mir#mi!]#mi#R#mi#r#mi#s#mi#t#mi#u#mi#v#mi#x#mi#z#mi#{#mi'z#mi(r#mi'w#mi!Y#mi!k#miv#mi!_#mi%i#mi!g#mi~OP$[OR#zO!Q#yO!S#{O!l#xO!p$[O#n$OO#o$PO#p$PO#q$PO(aVO(y#mi(z#mi~P#EyOn>]O!Q*OO'y*PO(y$}O(z%POP#miR#mi!S#mi!l#mi!p#mi#n#mi#o#mi#p#mi#q#mi(a#mi~P#EyO!]/POg(pX~P!1WOg/RO~Oa$Pi!]$Pi'z$Pi'w$Pi!Y$Pi!k$Piv$Pi!_$Pi%i$Pi!g$Pi~P!:tO$]/SO$_/SO~O$]/TO$_/TO~O!g)hO#`/UO!_$cX$Z$cX$]$cX$_$cX$f$cX~O![/VO~O!_)kO$Z/XO$])jO$_)jO$f/YO~O!]<iO!^(fX~P#BwO!^/ZO~O!g)hO$f({X~O$f/]O~Ov/^O~P!&zOx)yO(b)zO(c/aO~O!S/dO~O(y$}On%aa!Q%aa'y%aa(z%aa!]%aa#`%aa~Og%aa$O%aa~P#L{O(z%POn%ca!Q%ca'y%ca(y%ca!]%ca#`%ca~Og%ca$O%ca~P#MnO!]fX!gfX!kfX!k$zX(rfX~P!0SOp%WO![/mO!](^O(T/lO!Y(vP!Y)PP~P!1uOr*sO!b*qO!c*kO!d*kO!l*bO#[*rO%`*mO(U!lO(VTO(YUO~Os<}O!S/nO![+[O!^*pO(e<|O!^(xP~P$ [O!k/oO~P#/sO!]/pO!g#vO(r'pO!k)OX~O!k/uO~OnoX!QoX'yoX(yoX(zoX~O!g#vO!koX~P$#OOp/wO!S%hO![*^O!_%iO(T%gO!k)OP~O#k/xO~O!Y$zX!]$zX!g%RX~P!0SO!]/yO!Y)PX~P#/sO!g/{O~O!Y/}O~OpkO(T0OO~P.iOh%VOr0TO!g#vO!l%eO(r'pO~O!g+iO~Oa%nO!]0XO'z%nO~O!^0ZO~P!5iO!c0[O!d0[O(U!lO~P#$`Os!nO!S0]O(VTO(YUO(e!mO~O#[0_O~Og%aa!]%aa#`%aa$O%aa~P!1WOg%ca!]%ca#`%ca$O%ca~P!1WOj%dOk%dOl%dO(T&ZOg'mX!]'mX~O!]*yOg(^a~Og0hO~On0jO#`0iOg(_a!](_a~OR0kO!Q0kO!S0lO#S$dOn}a'y}a(y}a(z}a!]}a#`}a~Og}a$O}a~P$(cO!Q*OO'y*POn$sa(y$sa(z$sa!]$sa#`$sa~Og$sa$O$sa~P$)_O!Q*OO'y*POn$ua(y$ua(z$ua!]$ua#`$ua~Og$ua$O$ua~P$*QO#k0oO~Og%Ta!]%Ta#`%Ta$O%Ta~P!1WO!g#vO~O#k0rO~O!]+^Oa)Ta'z)Ta~OR#zO!Q#yO!S#{O!l#xO(aVOP!ri[!rij!rir!ri!]!ri!p!ri#R!ri#n!ri#o!ri#p!ri#q!ri#r!ri#s!ri#t!ri#u!ri#v!ri#x!ri#z!ri#{!ri(r!ri(y!ri(z!ri~Oa!ri'z!ri'w!ri!Y!ri!k!riv!ri!_!ri%i!ri!g!ri~P$+oOh%VOr%XOs$tOt$tOz%YO|%ZO!O<sO!S${O!_$|O!i>VO!l$xO#j<yO$W%`O$t<uO$v<wO$y%aO(VTO(YUO(a$uO(y$}O(z%PO~Op0{O%]0|O(T0zO~P$.VO!g+iOa(]a!_(]a'z(]a!](]a~O#k1SO~O[]X!]fX!^fX~O!]1TO!^)XX~O!^1VO~O[1WO~Ob1YO(T+qO(VTO(YUO~O!_&PO(T%gO`'uX!]'uX~O!]+vO`)Wa~O!k1]O~P!:tO[1`O~O`1aO~O#`1fO~On1iO!_$|O~O(e(|O!^)UP~Oh%VOn1rO!_1oO%i1qO~O[1|O!]1zO!^)VX~O!^1}O~O`2POa%nO'z%nO~O(T#nO(VTO(YUO~O#S$dO#`$eO$Q$eOP(gXR(gX[(gXr(gX!Q(gX!S(gX!](gX!l(gX!p(gX#R(gX#n(gX#o(gX#p(gX#q(gX#r(gX#s(gX#t(gX#u(gX#v(gX#x(gX#z(gX#{(gX(a(gX(r(gX(y(gX(z(gX~Oj2SO&[2TOa(gX~P$3pOj2SO#`$eO&[2TO~Oa2VO~P%[Oa2XO~O&e2[OP&ciQ&ciS&ciY&cia&cid&cie&cil&cip&cir&cis&cit&ciz&ci|&ci!O&ci!S&ci!W&ci!X&ci!_&ci!i&ci!l&ci!o&ci!p&ci!q&ci!s&ci!u&ci!x&ci!|&ci$W&ci$n&ci%h&ci%j&ci%l&ci%m&ci%n&ci%q&ci%s&ci%v&ci%w&ci%y&ci&W&ci&^&ci&`&ci&b&ci&d&ci&g&ci&m&ci&s&ci&u&ci&w&ci&y&ci&{&ci'w&ci(T&ci(V&ci(Y&ci(a&ci(o&ci!^&cib&ci&j&ci~Ob2bO!^2`O&j2aO~P`O!_XO!l2dO~O&q,{OP&liQ&liS&liY&lia&lid&lie&lil&lip&lir&lis&lit&liz&li|&li!O&li!S&li!W&li!X&li!_&li!i&li!l&li!o&li!p&li!q&li!s&li!u&li!x&li!|&li$W&li$n&li%h&li%j&li%l&li%m&li%n&li%q&li%s&li%v&li%w&li%y&li&W&li&^&li&`&li&b&li&d&li&g&li&m&li&s&li&u&li&w&li&y&li&{&li'w&li(T&li(V&li(Y&li(a&li(o&li!^&li&e&lib&li&j&li~O!Y2jO~O!]!aa!^!aa~P#BwOs!nO!S!oO![2pO(e!mO!]'XX!^'XX~P@nO!]-]O!^(ia~O!]'_X!^'_X~P!9|O!]-`O!^(xa~O!^2wO~P'_Oa%nO#`3QO'z%nO~Oa%nO!g#vO#`3QO'z%nO~Oa%nO!g#vO!p3UO#`3QO'z%nO(r'pO~Oa%nO'z%nO~P!:tO!]$_Ov$qa~O!Y'Wi!]'Wi~P!:tO!](VO!Y(hi~O!](^O!Y(vi~O!Y(wi!](wi~P!:tO!](ti!k(tia(ti'z(ti~P!:tO#`3WO!](ti!k(tia(ti'z(ti~O!](jO!k(si~O!S%hO!_%iO!|]O#i3]O#j3[O(T%gO~O!S%hO!_%iO#j3[O(T%gO~On3dO!_'`O%i3cO~Oh%VOn3dO!_'`O%i3cO~O#k%aaP%aaR%aa[%aaa%aaj%aar%aa!S%aa!l%aa!p%aa#R%aa#n%aa#o%aa#p%aa#q%aa#r%aa#s%aa#t%aa#u%aa#v%aa#x%aa#z%aa#{%aa'z%aa(a%aa(r%aa!k%aa!Y%aa'w%aav%aa!_%aa%i%aa!g%aa~P#L{O#k%caP%caR%ca[%caa%caj%car%ca!S%ca!l%ca!p%ca#R%ca#n%ca#o%ca#p%ca#q%ca#r%ca#s%ca#t%ca#u%ca#v%ca#x%ca#z%ca#{%ca'z%ca(a%ca(r%ca!k%ca!Y%ca'w%cav%ca!_%ca%i%ca!g%ca~P#MnO#k%aaP%aaR%aa[%aaa%aaj%aar%aa!S%aa!]%aa!l%aa!p%aa#R%aa#n%aa#o%aa#p%aa#q%aa#r%aa#s%aa#t%aa#u%aa#v%aa#x%aa#z%aa#{%aa'z%aa(a%aa(r%aa!k%aa!Y%aa'w%aa#`%aav%aa!_%aa%i%aa!g%aa~P#/sO#k%caP%caR%ca[%caa%caj%car%ca!S%ca!]%ca!l%ca!p%ca#R%ca#n%ca#o%ca#p%ca#q%ca#r%ca#s%ca#t%ca#u%ca#v%ca#x%ca#z%ca#{%ca'z%ca(a%ca(r%ca!k%ca!Y%ca'w%ca#`%cav%ca!_%ca%i%ca!g%ca~P#/sO#k}aP}a[}aa}aj}ar}a!l}a!p}a#R}a#n}a#o}a#p}a#q}a#r}a#s}a#t}a#u}a#v}a#x}a#z}a#{}a'z}a(a}a(r}a!k}a!Y}a'w}av}a!_}a%i}a!g}a~P$(cO#k$saP$saR$sa[$saa$saj$sar$sa!S$sa!l$sa!p$sa#R$sa#n$sa#o$sa#p$sa#q$sa#r$sa#s$sa#t$sa#u$sa#v$sa#x$sa#z$sa#{$sa'z$sa(a$sa(r$sa!k$sa!Y$sa'w$sav$sa!_$sa%i$sa!g$sa~P$)_O#k$uaP$uaR$ua[$uaa$uaj$uar$ua!S$ua!l$ua!p$ua#R$ua#n$ua#o$ua#p$ua#q$ua#r$ua#s$ua#t$ua#u$ua#v$ua#x$ua#z$ua#{$ua'z$ua(a$ua(r$ua!k$ua!Y$ua'w$uav$ua!_$ua%i$ua!g$ua~P$*QO#k%TaP%TaR%Ta[%Taa%Taj%Tar%Ta!S%Ta!]%Ta!l%Ta!p%Ta#R%Ta#n%Ta#o%Ta#p%Ta#q%Ta#r%Ta#s%Ta#t%Ta#u%Ta#v%Ta#x%Ta#z%Ta#{%Ta'z%Ta(a%Ta(r%Ta!k%Ta!Y%Ta'w%Ta#`%Tav%Ta!_%Ta%i%Ta!g%Ta~P#/sOa#cq!]#cq'z#cq'w#cq!Y#cq!k#cqv#cq!_#cq%i#cq!g#cq~P!:tO![3lO!]'YX!k'YX~P%[O!].tO!k(ka~O!].tO!k(ka~P!:tO!Y3oO~O$O!na!^!na~PKlO$O!ja!]!ja!^!ja~P#BwO$O!ra!^!ra~P!=[O$O!ta!^!ta~P!?rOg']X!]']X~P!,TO!]/POg(pa~OSfO!_4TO$d4UO~O!^4YO~Ov4ZO~P#/sOa$mq!]$mq'z$mq'w$mq!Y$mq!k$mqv$mq!_$mq%i$mq!g$mq~P!:tO!Y4]O~P!&zO!S4^O~O!Q*OO'y*PO(z%POn'ia(y'ia!]'ia#`'ia~Og'ia$O'ia~P%-fO!Q*OO'y*POn'ka(y'ka(z'ka!]'ka#`'ka~Og'ka$O'ka~P%.XO(r$YO~P#/sO!YfX!Y$zX!]fX!]$zX!g%RX#`fX~P!0SOp%WO(T=WO~P!1uOp4bO!S%hO![4aO!_%iO(T%gO!]'eX!k'eX~O!]/pO!k)Oa~O!]/pO!g#vO!k)Oa~O!]/pO!g#vO(r'pO!k)Oa~Og$|i!]$|i#`$|i$O$|i~P!1WO![4jO!Y'gX!]'gX~P!3tO!]/yO!Y)Pa~O!]/yO!Y)Pa~P#/sOP]XR]X[]Xj]Xr]X!Q]X!S]X!Y]X!]]X!l]X!p]X#R]X#S]X#`]X#kfX#n]X#o]X#p]X#q]X#r]X#s]X#t]X#u]X#v]X#x]X#z]X#{]X$Q]X(a]X(r]X(y]X(z]X~Oj%YX!g%YX~P%2OOj4oO!g#vO~Oh%VO!g#vO!l%eO~Oh%VOr4tO!l%eO(r'pO~Or4yO!g#vO(r'pO~Os!nO!S4zO(VTO(YUO(e!mO~O(y$}On%ai!Q%ai'y%ai(z%ai!]%ai#`%ai~Og%ai$O%ai~P%5oO(z%POn%ci!Q%ci'y%ci(y%ci!]%ci#`%ci~Og%ci$O%ci~P%6bOg(_i!](_i~P!1WO#`5QOg(_i!](_i~P!1WO!k5VO~Oa$oq!]$oq'z$oq'w$oq!Y$oq!k$oqv$oq!_$oq%i$oq!g$oq~P!:tO!Y5ZO~O!]5[O!_)QX~P#/sOa$zX!_$zX%^]X'z$zX!]$zX~P!0SO%^5_OaoX!_oX'zoX!]oX~P$#OOp5`O(T#nO~O%^5_O~Ob5fO%j5gO(T+qO(VTO(YUO!]'tX!^'tX~O!]1TO!^)Xa~O[5kO~O`5lO~O[5pO~Oa%nO'z%nO~P#/sO!]5uO#`5wO!^)UX~O!^5xO~Or6OOs!nO!S*iO!b!yO!c!vO!d!vO!|<VO#T!pO#U!pO#V!pO#W!pO#X!pO#[5}O#]!zO(U!lO(VTO(YUO(e!mO(o!sO~O!^5|O~P%;eOn6TO!_1oO%i6SO~Oh%VOn6TO!_1oO%i6SO~Ob6[O(T#nO(VTO(YUO!]'sX!^'sX~O!]1zO!^)Va~O(VTO(YUO(e6^O~O`6bO~Oj6eO&[6fO~PNXO!k6gO~P%[Oa6iO~Oa6iO~P%[Ob2bO!^6nO&j2aO~P`O!g6pO~O!g6rOh(ji!](ji!^(ji!g(ji!l(jir(ji(r(ji~O!]#hi!^#hi~P#BwO#`6sO!]#hi!^#hi~O!]!ai!^!ai~P#BwOa%nO#`6|O'z%nO~Oa%nO!g#vO#`6|O'z%nO~O!](tq!k(tqa(tq'z(tq~P!:tO!](jO!k(sq~O!S%hO!_%iO#j7TO(T%gO~O!_'`O%i7WO~On7[O!_'`O%i7WO~O#k'iaP'iaR'ia['iaa'iaj'iar'ia!S'ia!l'ia!p'ia#R'ia#n'ia#o'ia#p'ia#q'ia#r'ia#s'ia#t'ia#u'ia#v'ia#x'ia#z'ia#{'ia'z'ia(a'ia(r'ia!k'ia!Y'ia'w'iav'ia!_'ia%i'ia!g'ia~P%-fO#k'kaP'kaR'ka['kaa'kaj'kar'ka!S'ka!l'ka!p'ka#R'ka#n'ka#o'ka#p'ka#q'ka#r'ka#s'ka#t'ka#u'ka#v'ka#x'ka#z'ka#{'ka'z'ka(a'ka(r'ka!k'ka!Y'ka'w'kav'ka!_'ka%i'ka!g'ka~P%.XO#k$|iP$|iR$|i[$|ia$|ij$|ir$|i!S$|i!]$|i!l$|i!p$|i#R$|i#n$|i#o$|i#p$|i#q$|i#r$|i#s$|i#t$|i#u$|i#v$|i#x$|i#z$|i#{$|i'z$|i(a$|i(r$|i!k$|i!Y$|i'w$|i#`$|iv$|i!_$|i%i$|i!g$|i~P#/sO#k%aiP%aiR%ai[%aia%aij%air%ai!S%ai!l%ai!p%ai#R%ai#n%ai#o%ai#p%ai#q%ai#r%ai#s%ai#t%ai#u%ai#v%ai#x%ai#z%ai#{%ai'z%ai(a%ai(r%ai!k%ai!Y%ai'w%aiv%ai!_%ai%i%ai!g%ai~P%5oO#k%ciP%ciR%ci[%cia%cij%cir%ci!S%ci!l%ci!p%ci#R%ci#n%ci#o%ci#p%ci#q%ci#r%ci#s%ci#t%ci#u%ci#v%ci#x%ci#z%ci#{%ci'z%ci(a%ci(r%ci!k%ci!Y%ci'w%civ%ci!_%ci%i%ci!g%ci~P%6bO!]'Ya!k'Ya~P!:tO!].tO!k(ki~O$O#ci!]#ci!^#ci~P#BwOP$[OR#zO!Q#yO!S#{O!l#xO!p$[O(aVO[#mij#mir#mi#R#mi#o#mi#p#mi#q#mi#r#mi#s#mi#t#mi#u#mi#v#mi#x#mi#z#mi#{#mi$O#mi(r#mi(y#mi(z#mi!]#mi!^#mi~O#n#mi~P%NdO#n<_O~P%NdOP$[OR#zOr<kO!Q#yO!S#{O!l#xO!p$[O#n<_O#o<`O#p<`O#q<`O(aVO[#mij#mi#R#mi#s#mi#t#mi#u#mi#v#mi#x#mi#z#mi#{#mi$O#mi(r#mi(y#mi(z#mi!]#mi!^#mi~O#r#mi~P&!lO#r<aO~P&!lOP$[OR#zO[<mOj<bOr<kO!Q#yO!S#{O!l#xO!p$[O#R<bO#n<_O#o<`O#p<`O#q<`O#r<aO#s<bO#t<bO#u<lO(aVO#x#mi#z#mi#{#mi$O#mi(r#mi(y#mi(z#mi!]#mi!^#mi~O#v#mi~P&$tOP$[OR#zO[<mOj<bOr<kO!Q#yO!S#{O!l#xO!p$[O#R<bO#n<_O#o<`O#p<`O#q<`O#r<aO#s<bO#t<bO#u<lO#v<cO(aVO(z#}O#z#mi#{#mi$O#mi(r#mi(y#mi!]#mi!^#mi~O#x<eO~P&&uO#x#mi~P&&uO#v<cO~P&$tOP$[OR#zO[<mOj<bOr<kO!Q#yO!S#{O!l#xO!p$[O#R<bO#n<_O#o<`O#p<`O#q<`O#r<aO#s<bO#t<bO#u<lO#v<cO#x<eO(aVO(y#|O(z#}O#{#mi$O#mi(r#mi!]#mi!^#mi~O#z#mi~P&)UO#z<gO~P&)UOa#|y!]#|y'z#|y'w#|y!Y#|y!k#|yv#|y!_#|y%i#|y!g#|y~P!:tO[#mij#mir#mi#R#mi#r#mi#s#mi#t#mi#u#mi#v#mi#x#mi#z#mi#{#mi$O#mi(r#mi!]#mi!^#mi~OP$[OR#zO!Q#yO!S#{O!l#xO!p$[O#n<_O#o<`O#p<`O#q<`O(aVO(y#mi(z#mi~P&,QOn>^O!Q*OO'y*PO(y$}O(z%POP#miR#mi!S#mi!l#mi!p#mi#n#mi#o#mi#p#mi#q#mi(a#mi~P&,QO#S$dOP(`XR(`X[(`Xj(`Xn(`Xr(`X!Q(`X!S(`X!l(`X!p(`X#R(`X#n(`X#o(`X#p(`X#q(`X#r(`X#s(`X#t(`X#u(`X#v(`X#x(`X#z(`X#{(`X$O(`X'y(`X(a(`X(r(`X(y(`X(z(`X!](`X!^(`X~O$O$Pi!]$Pi!^$Pi~P#BwO$O!ri!^!ri~P$+oOg']a!]']a~P!1WO!^7nO~O!]'da!^'da~P#BwO!Y7oO~P#/sO!g#vO(r'pO!]'ea!k'ea~O!]/pO!k)Oi~O!]/pO!g#vO!k)Oi~Og$|q!]$|q#`$|q$O$|q~P!1WO!Y'ga!]'ga~P#/sO!g7vO~O!]/yO!Y)Pi~P#/sO!]/yO!Y)Pi~O!Y7yO~Oh%VOr8OO!l%eO(r'pO~Oj8QO!g#vO~Or8TO!g#vO(r'pO~O!Q*OO'y*PO(z%POn'ja(y'ja!]'ja#`'ja~Og'ja$O'ja~P&5RO!Q*OO'y*POn'la(y'la(z'la!]'la#`'la~Og'la$O'la~P&5tOg(_q!](_q~P!1WO#`8VOg(_q!](_q~P!1WO!Y8WO~Og%Oq!]%Oq#`%Oq$O%Oq~P!1WOa$oy!]$oy'z$oy'w$oy!Y$oy!k$oyv$oy!_$oy%i$oy!g$oy~P!:tO!g6rO~O!]5[O!_)Qa~O!_'`OP$TaR$Ta[$Taj$Tar$Ta!Q$Ta!S$Ta!]$Ta!l$Ta!p$Ta#R$Ta#n$Ta#o$Ta#p$Ta#q$Ta#r$Ta#s$Ta#t$Ta#u$Ta#v$Ta#x$Ta#z$Ta#{$Ta(a$Ta(r$Ta(y$Ta(z$Ta~O%i7WO~P&8fO%^8[Oa%[i!_%[i'z%[i!]%[i~Oa#cy!]#cy'z#cy'w#cy!Y#cy!k#cyv#cy!_#cy%i#cy!g#cy~P!:tO[8^O~Ob8`O(T+qO(VTO(YUO~O!]1TO!^)Xi~O`8dO~O(e(|O!]'pX!^'pX~O!]5uO!^)Ua~O!^8nO~P%;eO(o!sO~P$&YO#[8oO~O!_1oO~O!_1oO%i8qO~On8tO!_1oO%i8qO~O[8yO!]'sa!^'sa~O!]1zO!^)Vi~O!k8}O~O!k9OO~O!k9RO~O!k9RO~P%[Oa9TO~O!g9UO~O!k9VO~O!](wi!^(wi~P#BwOa%nO#`9_O'z%nO~O!](ty!k(tya(ty'z(ty~P!:tO!](jO!k(sy~O%i9bO~P&8fO!_'`O%i9bO~O#k$|qP$|qR$|q[$|qa$|qj$|qr$|q!S$|q!]$|q!l$|q!p$|q#R$|q#n$|q#o$|q#p$|q#q$|q#r$|q#s$|q#t$|q#u$|q#v$|q#x$|q#z$|q#{$|q'z$|q(a$|q(r$|q!k$|q!Y$|q'w$|q#`$|qv$|q!_$|q%i$|q!g$|q~P#/sO#k'jaP'jaR'ja['jaa'jaj'jar'ja!S'ja!l'ja!p'ja#R'ja#n'ja#o'ja#p'ja#q'ja#r'ja#s'ja#t'ja#u'ja#v'ja#x'ja#z'ja#{'ja'z'ja(a'ja(r'ja!k'ja!Y'ja'w'jav'ja!_'ja%i'ja!g'ja~P&5RO#k'laP'laR'la['laa'laj'lar'la!S'la!l'la!p'la#R'la#n'la#o'la#p'la#q'la#r'la#s'la#t'la#u'la#v'la#x'la#z'la#{'la'z'la(a'la(r'la!k'la!Y'la'w'lav'la!_'la%i'la!g'la~P&5tO#k%OqP%OqR%Oq[%Oqa%Oqj%Oqr%Oq!S%Oq!]%Oq!l%Oq!p%Oq#R%Oq#n%Oq#o%Oq#p%Oq#q%Oq#r%Oq#s%Oq#t%Oq#u%Oq#v%Oq#x%Oq#z%Oq#{%Oq'z%Oq(a%Oq(r%Oq!k%Oq!Y%Oq'w%Oq#`%Oqv%Oq!_%Oq%i%Oq!g%Oq~P#/sO!]'Yi!k'Yi~P!:tO$O#cq!]#cq!^#cq~P#BwO(y$}OP%aaR%aa[%aaj%aar%aa!S%aa!l%aa!p%aa#R%aa#n%aa#o%aa#p%aa#q%aa#r%aa#s%aa#t%aa#u%aa#v%aa#x%aa#z%aa#{%aa$O%aa(a%aa(r%aa!]%aa!^%aa~On%aa!Q%aa'y%aa(z%aa~P&IyO(z%POP%caR%ca[%caj%car%ca!S%ca!l%ca!p%ca#R%ca#n%ca#o%ca#p%ca#q%ca#r%ca#s%ca#t%ca#u%ca#v%ca#x%ca#z%ca#{%ca$O%ca(a%ca(r%ca!]%ca!^%ca~On%ca!Q%ca'y%ca(y%ca~P&LQOn>^O!Q*OO'y*PO(z%PO~P&IyOn>^O!Q*OO'y*PO(y$}O~P&LQOR0kO!Q0kO!S0lO#S$dOP}a[}aj}an}ar}a!l}a!p}a#R}a#n}a#o}a#p}a#q}a#r}a#s}a#t}a#u}a#v}a#x}a#z}a#{}a$O}a'y}a(a}a(r}a(y}a(z}a!]}a!^}a~O!Q*OO'y*POP$saR$sa[$saj$san$sar$sa!S$sa!l$sa!p$sa#R$sa#n$sa#o$sa#p$sa#q$sa#r$sa#s$sa#t$sa#u$sa#v$sa#x$sa#z$sa#{$sa$O$sa(a$sa(r$sa(y$sa(z$sa!]$sa!^$sa~O!Q*OO'y*POP$uaR$ua[$uaj$uan$uar$ua!S$ua!l$ua!p$ua#R$ua#n$ua#o$ua#p$ua#q$ua#r$ua#s$ua#t$ua#u$ua#v$ua#x$ua#z$ua#{$ua$O$ua(a$ua(r$ua(y$ua(z$ua!]$ua!^$ua~On>^O!Q*OO'y*PO(y$}O(z%PO~OP%TaR%Ta[%Taj%Tar%Ta!S%Ta!l%Ta!p%Ta#R%Ta#n%Ta#o%Ta#p%Ta#q%Ta#r%Ta#s%Ta#t%Ta#u%Ta#v%Ta#x%Ta#z%Ta#{%Ta$O%Ta(a%Ta(r%Ta!]%Ta!^%Ta~P''VO$O$mq!]$mq!^$mq~P#BwO$O$oq!]$oq!^$oq~P#BwO!^9oO~O$O9pO~P!1WO!g#vO!]'ei!k'ei~O!g#vO(r'pO!]'ei!k'ei~O!]/pO!k)Oq~O!Y'gi!]'gi~P#/sO!]/yO!Y)Pq~Or9wO!g#vO(r'pO~O[9yO!Y9xO~P#/sO!Y9xO~Oj:PO!g#vO~Og(_y!](_y~P!1WO!]'na!_'na~P#/sOa%[q!_%[q'z%[q!]%[q~P#/sO[:UO~O!]1TO!^)Xq~O`:YO~O#`:ZO!]'pa!^'pa~O!]5uO!^)Ui~P#BwO!S:]O~O!_1oO%i:`O~O(VTO(YUO(e:eO~O!]1zO!^)Vq~O!k:hO~O!k:iO~O!k:jO~O!k:jO~P%[O#`:mO!]#hy!^#hy~O!]#hy!^#hy~P#BwO%i:rO~P&8fO!_'`O%i:rO~O$O#|y!]#|y!^#|y~P#BwOP$|iR$|i[$|ij$|ir$|i!S$|i!l$|i!p$|i#R$|i#n$|i#o$|i#p$|i#q$|i#r$|i#s$|i#t$|i#u$|i#v$|i#x$|i#z$|i#{$|i$O$|i(a$|i(r$|i!]$|i!^$|i~P''VO!Q*OO'y*PO(z%POP'iaR'ia['iaj'ian'iar'ia!S'ia!l'ia!p'ia#R'ia#n'ia#o'ia#p'ia#q'ia#r'ia#s'ia#t'ia#u'ia#v'ia#x'ia#z'ia#{'ia$O'ia(a'ia(r'ia(y'ia!]'ia!^'ia~O!Q*OO'y*POP'kaR'ka['kaj'kan'kar'ka!S'ka!l'ka!p'ka#R'ka#n'ka#o'ka#p'ka#q'ka#r'ka#s'ka#t'ka#u'ka#v'ka#x'ka#z'ka#{'ka$O'ka(a'ka(r'ka(y'ka(z'ka!]'ka!^'ka~O(y$}OP%aiR%ai[%aij%ain%air%ai!Q%ai!S%ai!l%ai!p%ai#R%ai#n%ai#o%ai#p%ai#q%ai#r%ai#s%ai#t%ai#u%ai#v%ai#x%ai#z%ai#{%ai$O%ai'y%ai(a%ai(r%ai(z%ai!]%ai!^%ai~O(z%POP%ciR%ci[%cij%cin%cir%ci!Q%ci!S%ci!l%ci!p%ci#R%ci#n%ci#o%ci#p%ci#q%ci#r%ci#s%ci#t%ci#u%ci#v%ci#x%ci#z%ci#{%ci$O%ci'y%ci(a%ci(r%ci(y%ci!]%ci!^%ci~O$O$oy!]$oy!^$oy~P#BwO$O#cy!]#cy!^#cy~P#BwO!g#vO!]'eq!k'eq~O!]/pO!k)Oy~O!Y'gq!]'gq~P#/sOr:|O!g#vO(r'pO~O[;QO!Y;PO~P#/sO!Y;PO~Og(_!R!](_!R~P!1WOa%[y!_%[y'z%[y!]%[y~P#/sO!]1TO!^)Xy~O!]5uO!^)Uq~O(T;XO~O!_1oO%i;[O~O!k;_O~O%i;dO~P&8fOP$|qR$|q[$|qj$|qr$|q!S$|q!l$|q!p$|q#R$|q#n$|q#o$|q#p$|q#q$|q#r$|q#s$|q#t$|q#u$|q#v$|q#x$|q#z$|q#{$|q$O$|q(a$|q(r$|q!]$|q!^$|q~P''VO!Q*OO'y*PO(z%POP'jaR'ja['jaj'jan'jar'ja!S'ja!l'ja!p'ja#R'ja#n'ja#o'ja#p'ja#q'ja#r'ja#s'ja#t'ja#u'ja#v'ja#x'ja#z'ja#{'ja$O'ja(a'ja(r'ja(y'ja!]'ja!^'ja~O!Q*OO'y*POP'laR'la['laj'lan'lar'la!S'la!l'la!p'la#R'la#n'la#o'la#p'la#q'la#r'la#s'la#t'la#u'la#v'la#x'la#z'la#{'la$O'la(a'la(r'la(y'la(z'la!]'la!^'la~OP%OqR%Oq[%Oqj%Oqr%Oq!S%Oq!l%Oq!p%Oq#R%Oq#n%Oq#o%Oq#p%Oq#q%Oq#r%Oq#s%Oq#t%Oq#u%Oq#v%Oq#x%Oq#z%Oq#{%Oq$O%Oq(a%Oq(r%Oq!]%Oq!^%Oq~P''VOg%e!Z!]%e!Z#`%e!Z$O%e!Z~P!1WO!Y;hO~P#/sOr;iO!g#vO(r'pO~O[;kO!Y;hO~P#/sO!]'pq!^'pq~P#BwO!]#h!Z!^#h!Z~P#BwO#k%e!ZP%e!ZR%e!Z[%e!Za%e!Zj%e!Zr%e!Z!S%e!Z!]%e!Z!l%e!Z!p%e!Z#R%e!Z#n%e!Z#o%e!Z#p%e!Z#q%e!Z#r%e!Z#s%e!Z#t%e!Z#u%e!Z#v%e!Z#x%e!Z#z%e!Z#{%e!Z'z%e!Z(a%e!Z(r%e!Z!k%e!Z!Y%e!Z'w%e!Z#`%e!Zv%e!Z!_%e!Z%i%e!Z!g%e!Z~P#/sOr;tO!g#vO(r'pO~O!Y;uO~P#/sOr;|O!g#vO(r'pO~O!Y;}O~P#/sOP%e!ZR%e!Z[%e!Zj%e!Zr%e!Z!S%e!Z!l%e!Z!p%e!Z#R%e!Z#n%e!Z#o%e!Z#p%e!Z#q%e!Z#r%e!Z#s%e!Z#t%e!Z#u%e!Z#v%e!Z#x%e!Z#z%e!Z#{%e!Z$O%e!Z(a%e!Z(r%e!Z!]%e!Z!^%e!Z~P''VOr<QO!g#vO(r'pO~Ov(fX~P1qO!Q%rO~P!)[O(U!lO~P!)[O!YfX!]fX#`fX~P%2OOP]XR]X[]Xj]Xr]X!Q]X!S]X!]]X!]fX!l]X!p]X#R]X#S]X#`]X#`fX#kfX#n]X#o]X#p]X#q]X#r]X#s]X#t]X#u]X#v]X#x]X#z]X#{]X$Q]X(a]X(r]X(y]X(z]X~O!gfX!k]X!kfX(rfX~P'LTOP<UOQ<UOSfOd>ROe!iOpkOr<UOskOtkOzkO|<UO!O<UO!SWO!WkO!XkO!_XO!i<XO!lZO!o<UO!p<UO!q<UO!s<YO!u<]O!x!hO$W!kO$n>PO(T)]O(VTO(YUO(aVO(o[O~O!]<iO!^$qa~Oh%VOp%WOr%XOs$tOt$tOz%YO|%ZO!O<tO!S${O!_$|O!i>WO!l$xO#j<zO$W%`O$t<vO$v<xO$y%aO(T(vO(VTO(YUO(a$uO(y$}O(z%PO~Ol)dO~P(!yOr!eX(r!eX~P#!iOr(jX(r(jX~P##[O!^]X!^fX~P'LTO!YfX!Y$zX!]fX!]$zX#`fX~P!0SO#k<^O~O!g#vO#k<^O~O#`<nO~Oj<bO~O#`=OO!](wX!^(wX~O#`<nO!](uX!^(uX~O#k=PO~Og=RO~P!1WO#k=XO~O#k=YO~Og=RO(T&ZO~O!g#vO#k=ZO~O!g#vO#k=PO~O$O=[O~P#BwO#k=]O~O#k=^O~O#k=cO~O#k=dO~O#k=eO~O#k=fO~O$O=gO~P!1WO$O=hO~P!1WOl=sO~P7eOk#S#T#U#W#X#[#i#j#u$n$t$v$y%]%^%h%i%j%q%s%v%w%y%{~(OT#o!X'|(U#ps#n#qr!Q'}$]'}(T$_(e~",
        goto: "$9Y)]PPPPPP)^PP)aP)rP+W/]PPPP6mPP7TPP=QPPP@tPA^PA^PPPA^PCfPA^PA^PA^PCjPCoPD^PIWPPPI[PPPPI[L_PPPLeMVPI[PI[PP! eI[PPPI[PI[P!#lI[P!'S!(X!(bP!)U!)Y!)U!,gPPPPPPP!-W!(XPP!-h!/YP!2iI[I[!2n!5z!:h!:h!>gPPP!>oI[PPPPPPPPP!BOP!C]PPI[!DnPI[PI[I[I[I[I[PI[!FQP!I[P!LbP!Lf!Lp!Lt!LtP!IXP!Lx!LxP#!OP#!SI[PI[#!Y#%_CjA^PA^PA^A^P#&lA^A^#)OA^#+vA^#.SA^A^#.r#1W#1W#1]#1f#1W#1qPP#1WPA^#2ZA^#6YA^A^6mPPP#:_PPP#:x#:xP#:xP#;`#:xPP#;fP#;]P#;]#;y#;]#<e#<k#<n)aP#<q)aP#<z#<z#<zP)aP)aP)aP)aPP)aP#=Q#=TP#=T)aP#=XP#=[P)aP)aP)aP)aP)aP)a)aPP#=b#=h#=s#=y#>P#>V#>]#>k#>q#>{#?R#?]#?c#?s#?y#@k#@}#AT#AZ#Ai#BO#Cs#DR#DY#Et#FS#Gt#HS#HY#H`#Hf#Hp#Hv#H|#IW#Ij#IpPPPPPPPPPPP#IvPPPPPPP#Jk#Mx$ b$ i$ qPPP$']P$'f$*_$0x$0{$1O$1}$2Q$2X$2aP$2g$2jP$3W$3[$4S$5b$5g$5}PP$6S$6Y$6^$6a$6e$6i$7e$7|$8e$8i$8l$8o$8y$8|$9Q$9UR!|RoqOXst!Z#d%m&r&t&u&w,s,x2[2_Y!vQ'`-e1o5{Q%tvQ%|yQ&T|Q&j!VS'W!e-]Q'f!iS'l!r!yU*k$|*Z*oQ+o%}S+|&V&WQ,d&dQ-c'_Q-m'gQ-u'mQ0[*qQ1b,OQ1y,eR<{<Y%SdOPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$_$a$e%m%t&R&k&n&r&t&u&w&{'T'b'r(T(V(](d(x(z)O)}*i+X+],p,s,x-i-q.P.V.t.{/n0]0l0r1S1r2S2T2V2X2[2_2a3Q3W3l4z6T6e6f6i6|8t9T9_S#q]<V!r)_$Z$n'X)s-U-X/V2p4T5w6s:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>SU+P%]<s<tQ+t&PQ,f&gQ,m&oQ0x+gQ0}+iQ1Y+uQ2R,kQ3`.gQ5`0|Q5f1TQ6[1zQ7Y3dQ8`5gR9e7['QkOPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$Z$_$a$e$n%m%t&R&k&n&o&r&t&u&w&{'T'X'b'r(T(V(](d(x(z)O)s)}*i+X+]+g,p,s,x-U-X-i-q.P.V.g.t.{/V/n0]0l0r1S1r2S2T2V2X2[2_2a2p3Q3W3d3l4T4z5w6T6e6f6i6s6|7[8t9T9_:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>S!S!nQ!r!v!y!z$|'W'_'`'l'm'n*k*o*q*r-]-c-e-u0[0_1o5{5}%[$ti#v$b$c$d$x${%O%Q%^%_%c)y*R*T*V*Y*a*g*w*x+f+i,S,V.f/P/d/m/x/y/{0`0b0i0j0o1f1i1q3c4^4_4j4o5Q5[5_6S7W7v8Q8V8[8q9b9p9y:P:`:r;Q;[;d;k<l<m<o<p<q<r<u<v<w<x<y<z=S=T=U=V=X=Y=]=^=_=`=a=b=c=d=g=h>P>X>Y>]>^Q&X|Q'U!eS'[%i-`Q+t&PQ,P&WQ,f&gQ0n+SQ1Y+uQ1_+{Q2Q,jQ2R,kQ5f1TQ5o1aQ6[1zQ6_1|Q6`2PQ8`5gQ8c5lQ8|6bQ:X8dQ:f8yQ;V:YR<}*ZrnOXst!V!Z#d%m&i&r&t&u&w,s,x2[2_R,h&k&z^OPXYstuvwz!Z!`!g!j!o#S#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$Z$_$a$e$n%m%t&R&k&n&o&r&t&u&w&{'T'b'r(V(](d(x(z)O)s)}*i+X+]+g,p,s,x-U-X-i-q.P.V.g.t.{/V/n0]0l0r1S1r2S2T2V2X2[2_2a2p3Q3W3d3l4T4z5w6T6e6f6i6s6|7[8t9T9_:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>R>S[#]WZ#W#Z'X(T!b%jm#h#i#l$x%e%h(^(h(i(j*Y*^*b+Z+[+^,o-V.T.Z.[.]._/m/p2d3[3]4a6r7TQ%wxQ%{yW&Q|&V&W,OQ&_!TQ'c!hQ'e!iQ(q#sS+n%|%}Q+r&PQ,_&bQ,c&dS-l'f'gQ.i(rQ1R+oQ1X+uQ1Z+vQ1^+zQ1t,`S1x,d,eQ2|-mQ5e1TQ5i1WQ5n1`Q6Z1yQ8_5gQ8b5kQ8f5pQ:T8^R;T:U!U$zi$d%O%Q%^%_%c*R*T*a*w*x/P/x0`0b0i0j0o4_5Q8V9p>P>X>Y!^%yy!i!u%{%|%}'V'e'f'g'k'u*j+n+o-Y-l-m-t0R0U1R2u2|3T4r4s4v7}9{Q+h%wQ,T&[Q,W&]Q,b&dQ.h(qQ1s,_U1w,c,d,eQ3e.iQ6U1tS6Y1x1yQ8x6Z#f>T#v$b$c$x${)y*V*Y*g+f+i,S,V.f/d/m/y/{1f1i1q3c4^4j4o5[5_6S7W7v8Q8[8q9b9y:P:`:r;Q;[;d;k<o<q<u<w<y=S=U=X=]=_=a=c=g>]>^o>U<l<m<p<r<v<x<z=T=V=Y=^=`=b=d=hW%Ti%V*y>PS&[!Q&iQ&]!RQ&^!SU*}%[%d=sR,R&Y%]%Si#v$b$c$d$x${%O%Q%^%_%c)y*R*T*V*Y*a*g*w*x+f+i,S,V.f/P/d/m/x/y/{0`0b0i0j0o1f1i1q3c4^4_4j4o5Q5[5_6S7W7v8Q8V8[8q9b9p9y:P:`:r;Q;[;d;k<l<m<o<p<q<r<u<v<w<x<y<z=S=T=U=V=X=Y=]=^=_=`=a=b=c=d=g=h>P>X>Y>]>^T)z$u){V+P%]<s<tW'[!e%i*Z-`S(}#y#zQ+c%rQ+y&SS.b(m(nQ1j,XQ5T0kR8i5u'QkOPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$Z$_$a$e$n%m%t&R&k&n&o&r&t&u&w&{'T'X'b'r(T(V(](d(x(z)O)s)}*i+X+]+g,p,s,x-U-X-i-q.P.V.g.t.{/V/n0]0l0r1S1r2S2T2V2X2[2_2a2p3Q3W3d3l4T4z5w6T6e6f6i6s6|7[8t9T9_:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>S$i$^c#Y#e%q%s%u(S(Y(t(y)R)S)T)U)V)W)X)Y)Z)[)^)`)b)g)q+d+x-Z-x-}.S.U.s.v.z.|.}/O/b0p2k2n3O3V3k3p3q3r3s3t3u3v3w3x3y3z3{3|4P4Q4X5X5c6u6{7Q7a7b7k7l8k9X9]9g9m9n:o;W;`<W=vT#TV#U'RkOPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$Z$_$a$e$n%m%t&R&k&n&o&r&t&u&w&{'T'X'b'r(T(V(](d(x(z)O)s)}*i+X+]+g,p,s,x-U-X-i-q.P.V.g.t.{/V/n0]0l0r1S1r2S2T2V2X2[2_2a2p3Q3W3d3l4T4z5w6T6e6f6i6s6|7[8t9T9_:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>SQ'Y!eR2q-]!W!nQ!e!r!v!y!z$|'W'_'`'l'm'n*Z*k*o*q*r-]-c-e-u0[0_1o5{5}R1l,ZnqOXst!Z#d%m&r&t&u&w,s,x2[2_Q&y!^Q'v!xS(s#u<^Q+l%zQ,]&_Q,^&aQ-j'dQ-w'oS.r(x=PS0q+X=ZQ1P+mQ1n,[Q2c,zQ2e,{Q2m-WQ2z-kQ2}-oS5Y0r=eQ5a1QS5d1S=fQ6t2oQ6x2{Q6}3SQ8]5bQ9Y6vQ9Z6yQ9^7OR:l9V$d$]c#Y#e%s%u(S(Y(t(y)R)S)T)U)V)W)X)Y)Z)[)^)`)b)g)q+d+x-Z-x-}.S.U.s.v.z.}/O/b0p2k2n3O3V3k3p3q3r3s3t3u3v3w3x3y3z3{3|4P4Q4X5X5c6u6{7Q7a7b7k7l8k9X9]9g9m9n:o;W;`<W=vS(o#p'iQ)P#zS+b%q.|S.c(n(pR3^.d'QkOPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$Z$_$a$e$n%m%t&R&k&n&o&r&t&u&w&{'T'X'b'r(T(V(](d(x(z)O)s)}*i+X+]+g,p,s,x-U-X-i-q.P.V.g.t.{/V/n0]0l0r1S1r2S2T2V2X2[2_2a2p3Q3W3d3l4T4z5w6T6e6f6i6s6|7[8t9T9_:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>SS#q]<VQ&t!XQ&u!YQ&w![Q&x!]R2Z,vQ'a!hQ+e%wQ-h'cS.e(q+hQ2x-gW3b.h.i0w0yQ6w2yW7U3_3a3e5^U9a7V7X7ZU:q9c9d9fS;b:p:sQ;p;cR;x;qU!wQ'`-eT5y1o5{!Q_OXZ`st!V!Z#d#h%e%m&i&k&r&t&u&w(j,s,x.[2[2_]!pQ!r'`-e1o5{T#q]<V%^{OPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$_$a$e%m%t&R&k&n&o&r&t&u&w&{'T'b'r(T(V(](d(x(z)O)}*i+X+]+g,p,s,x-i-q.P.V.g.t.{/n0]0l0r1S1r2S2T2V2X2[2_2a3Q3W3d3l4z6T6e6f6i6|7[8t9T9_S(}#y#zS.b(m(n!s=l$Z$n'X)s-U-X/V2p4T5w6s:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>SU$fd)_,mS(p#p'iU*v%R(w4OU0m+O.n7gQ5^0xQ7V3`Q9d7YR:s9em!tQ!r!v!y!z'`'l'm'n-e-u1o5{5}Q't!uS(f#g2US-s'k'wQ/s*]Q0R*jQ3U-vQ4f/tQ4r0TQ4s0UQ4x0^Q7r4`S7}4t4vS8R4y4{Q9r7sQ9v7yQ9{8OQ:Q8TS:{9w9xS;g:|;PS;s;h;iS;{;t;uS<P;|;}R<S<QQ#wbQ's!uS(e#g2US(g#m+WQ+Y%fQ+j%xQ+p&OU-r'k't'wQ.W(fU/r*]*`/wQ0S*jQ0V*lQ1O+kQ1u,aS3R-s-vQ3Z.`S4e/s/tQ4n0PS4q0R0^Q4u0WQ6W1vQ7P3US7q4`4bQ7u4fU7|4r4x4{Q8P4wQ8v6XS9q7r7sQ9u7yQ9}8RQ:O8SQ:c8wQ:y9rS:z9v9xQ;S:QQ;^:dS;f:{;PS;r;g;hS;z;s;uS<O;{;}Q<R<PQ<T<SQ=o=jQ={=tR=|=uV!wQ'`-e%^aOPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$_$a$e%m%t&R&k&n&o&r&t&u&w&{'T'b'r(T(V(](d(x(z)O)}*i+X+]+g,p,s,x-i-q.P.V.g.t.{/n0]0l0r1S1r2S2T2V2X2[2_2a3Q3W3d3l4z6T6e6f6i6|7[8t9T9_S#wz!j!r=i$Z$n'X)s-U-X/V2p4T5w6s:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>SR=o>R%^bOPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$_$a$e%m%t&R&k&n&o&r&t&u&w&{'T'b'r(T(V(](d(x(z)O)}*i+X+]+g,p,s,x-i-q.P.V.g.t.{/n0]0l0r1S1r2S2T2V2X2[2_2a3Q3W3d3l4z6T6e6f6i6|7[8t9T9_Q%fj!^%xy!i!u%{%|%}'V'e'f'g'k'u*j+n+o-Y-l-m-t0R0U1R2u2|3T4r4s4v7}9{S&Oz!jQ+k%yQ,a&dW1v,b,c,d,eU6X1w1x1yS8w6Y6ZQ:d8x!r=j$Z$n'X)s-U-X/V2p4T5w6s:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>SQ=t>QR=u>R%QeOPXYstuvw!Z!`!g!o#S#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$_$a$e%m%t&R&k&n&r&t&u&w&{'T'b'r(V(](d(x(z)O)}*i+X+]+g,p,s,x-i-q.P.V.g.t.{/n0]0l0r1S1r2S2T2V2X2[2_2a3Q3W3d3l4z6T6e6f6i6|7[8t9T9_Y#bWZ#W#Z(T!b%jm#h#i#l$x%e%h(^(h(i(j*Y*^*b+Z+[+^,o-V.T.Z.[.]._/m/p2d3[3]4a6r7TQ,n&o!p=k$Z$n)s-U-X/V2p4T5w6s:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>SR=n'XU']!e%i*ZR2s-`%SdOPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$_$a$e%m%t&R&k&n&r&t&u&w&{'T'b'r(T(V(](d(x(z)O)}*i+X+],p,s,x-i-q.P.V.t.{/n0]0l0r1S1r2S2T2V2X2[2_2a3Q3W3l4z6T6e6f6i6|8t9T9_!r)_$Z$n'X)s-U-X/V2p4T5w6s:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>SQ,m&oQ0x+gQ3`.gQ7Y3dR9e7[!b$Tc#Y%q(S(Y(t(y)Z)[)`)g+x-x-}.S.U.s.v/b0p3O3V3k3{5X5c6{7Q7a9]:o<W!P<d)^)q-Z.|2k2n3p3y3z4P4X6u7b7k7l8k9X9g9m9n;W;`=v!f$Vc#Y%q(S(Y(t(y)W)X)Z)[)`)g+x-x-}.S.U.s.v/b0p3O3V3k3{5X5c6{7Q7a9]:o<W!T<f)^)q-Z.|2k2n3p3v3w3y3z4P4X6u7b7k7l8k9X9g9m9n;W;`=v!^$Zc#Y%q(S(Y(t(y)`)g+x-x-}.S.U.s.v/b0p3O3V3k3{5X5c6{7Q7a9]:o<WQ4_/kz>S)^)q-Z.|2k2n3p4P4X6u7b7k7l8k9X9g9m9n;W;`=vQ>X>ZR>Y>['QkOPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$Z$_$a$e$n%m%t&R&k&n&o&r&t&u&w&{'T'X'b'r(T(V(](d(x(z)O)s)}*i+X+]+g,p,s,x-U-X-i-q.P.V.g.t.{/V/n0]0l0r1S1r2S2T2V2X2[2_2a2p3Q3W3d3l4T4z5w6T6e6f6i6s6|7[8t9T9_:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>SS$oh$pR4U/U'XgOPWXYZhstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$Z$_$a$e$n$p%m%t&R&k&n&o&r&t&u&w&{'T'X'b'r(T(V(](d(x(z)O)s)}*i+X+]+g,p,s,x-U-X-i-q.P.V.g.t.{/U/V/n0]0l0r1S1r2S2T2V2X2[2_2a2p3Q3W3d3l4T4z5w6T6e6f6i6s6|7[8t9T9_:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>ST$kf$qQ$ifS)j$l)nR)v$qT$jf$qT)l$l)n'XhOPWXYZhstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$Z$_$a$e$n$p%m%t&R&k&n&o&r&t&u&w&{'T'X'b'r(T(V(](d(x(z)O)s)}*i+X+]+g,p,s,x-U-X-i-q.P.V.g.t.{/U/V/n0]0l0r1S1r2S2T2V2X2[2_2a2p3Q3W3d3l4T4z5w6T6e6f6i6s6|7[8t9T9_:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>ST$oh$pQ$rhR)u$p%^jOPWXYZstuvw!Z!`!g!o#S#W#Z#d#o#u#x#{$O$P$Q$R$S$T$U$V$W$X$_$a$e%m%t&R&k&n&o&r&t&u&w&{'T'b'r(T(V(](d(x(z)O)}*i+X+]+g,p,s,x-i-q.P.V.g.t.{/n0]0l0r1S1r2S2T2V2X2[2_2a3Q3W3d3l4z6T6e6f6i6|7[8t9T9_!s>Q$Z$n'X)s-U-X/V2p4T5w6s:Z:m<U<X<Y<]<^<_<`<a<b<c<d<e<f<g<h<i<k<n<{=O=P=R=Z=[=e=f>S#glOPXZst!Z!`!o#S#d#o#{$n%m&k&n&o&r&t&u&w&{'T'b)O)s*i+]+g,p,s,x-i.g/V/n0]0l1r2S2T2V2X2[2_2a3d4T4z6T6e6f6i7[8t9T!U%Ri$d%O%Q%^%_%c*R*T*a*w*x/P/x0`0b0i0j0o4_5Q8V9p>P>X>Y#f(w#v$b$c$x${)y*V*Y*g+f+i,S,V.f/d/m/y/{1f1i1q3c4^4j4o5[5_6S7W7v8Q8[8q9b9y:P:`:r;Q;[;d;k<o<q<u<w<y=S=U=X=]=_=a=c=g>]>^Q+T%aQ/c*Oo4O<l<m<p<r<v<x<z=T=V=Y=^=`=b=d=h!U$yi$d%O%Q%^%_%c*R*T*a*w*x/P/x0`0b0i0j0o4_5Q8V9p>P>X>YQ*c$zU*l$|*Z*oQ+U%bQ0W*m#f=q#v$b$c$x${)y*V*Y*g+f+i,S,V.f/d/m/y/{1f1i1q3c4^4j4o5[5_6S7W7v8Q8[8q9b9y:P:`:r;Q;[;d;k<o<q<u<w<y=S=U=X=]=_=a=c=g>]>^n=r<l<m<p<r<v<x<z=T=V=Y=^=`=b=d=hQ=w>TQ=x>UQ=y>VR=z>W!U%Ri$d%O%Q%^%_%c*R*T*a*w*x/P/x0`0b0i0j0o4_5Q8V9p>P>X>Y#f(w#v$b$c$x${)y*V*Y*g+f+i,S,V.f/d/m/y/{1f1i1q3c4^4j4o5[5_6S7W7v8Q8[8q9b9y:P:`:r;Q;[;d;k<o<q<u<w<y=S=U=X=]=_=a=c=g>]>^o4O<l<m<p<r<v<x<z=T=V=Y=^=`=b=d=hnoOXst!Z#d%m&r&t&u&w,s,x2[2_S*f${*YQ-R'OQ-S'QR4i/y%[%Si#v$b$c$d$x${%O%Q%^%_%c)y*R*T*V*Y*a*g*w*x+f+i,S,V.f/P/d/m/x/y/{0`0b0i0j0o1f1i1q3c4^4_4j4o5Q5[5_6S7W7v8Q8V8[8q9b9p9y:P:`:r;Q;[;d;k<l<m<o<p<q<r<u<v<w<x<y<z=S=T=U=V=X=Y=]=^=_=`=a=b=c=d=g=h>P>X>Y>]>^Q,U&]Q1h,WQ5s1gR8h5tV*n$|*Z*oU*n$|*Z*oT5z1o5{S0P*i/nQ4w0]T8S4z:]Q+j%xQ0V*lQ1O+kQ1u,aQ6W1vQ8v6XQ:c8wR;^:d!U%Oi$d%O%Q%^%_%c*R*T*a*w*x/P/x0`0b0i0j0o4_5Q8V9p>P>X>Yx*R$v)e*S*u+V/v0d0e4R4g5R5S5W7p8U:R:x=p=}>OS0`*t0a#f<o#v$b$c$x${)y*V*Y*g+f+i,S,V.f/d/m/y/{1f1i1q3c4^4j4o5[5_6S7W7v8Q8[8q9b9y:P:`:r;Q;[;d;k<o<q<u<w<y=S=U=X=]=_=a=c=g>]>^n<p<l<m<p<r<v<x<z=T=V=Y=^=`=b=d=h!d=S(u)c*[*e.j.m.q/_/k/|0v1e3h4[4h4l5r7]7`7w7z8X8Z9t9|:S:};R;e;j;v>Z>[`=T3}7c7f7j9h:t:w;yS=_.l3iT=`7e9k!U%Qi$d%O%Q%^%_%c*R*T*a*w*x/P/x0`0b0i0j0o4_5Q8V9p>P>X>Y|*T$v)e*U*t+V/g/v0d0e4R4g4|5R5S5W7p8U:R:x=p=}>OS0b*u0c#f<q#v$b$c$x${)y*V*Y*g+f+i,S,V.f/d/m/y/{1f1i1q3c4^4j4o5[5_6S7W7v8Q8[8q9b9y:P:`:r;Q;[;d;k<o<q<u<w<y=S=U=X=]=_=a=c=g>]>^n<r<l<m<p<r<v<x<z=T=V=Y=^=`=b=d=h!h=U(u)c*[*e.k.l.q/_/k/|0v1e3f3h4[4h4l5r7]7^7`7w7z8X8Z9t9|:S:};R;e;j;v>Z>[d=V3}7d7e7j9h9i:t:u:w;yS=a.m3jT=b7f9lrnOXst!V!Z#d%m&i&r&t&u&w,s,x2[2_Q&f!UR,p&ornOXst!V!Z#d%m&i&r&t&u&w,s,x2[2_R&f!UQ,Y&^R1d,RsnOXst!V!Z#d%m&i&r&t&u&w,s,x2[2_Q1p,_S6R1s1tU8p6P6Q6US:_8r8sS;Y:^:aQ;m;ZR;w;nQ&m!VR,i&iR6_1|R:f8yW&Q|&V&W,OR1Z+vQ&r!WR,s&sR,y&xT2],x2_R,}&yQ,|&yR2f,}Q'y!{R-y'ySsOtQ#dXT%ps#dQ#OTR'{#OQ#RUR'}#RQ){$uR/`){Q#UVR(Q#UQ#XWU(W#X(X.QQ(X#YR.Q(YQ-^'YR2r-^Q.u(yS3m.u3nR3n.vQ-e'`R2v-eY!rQ'`-e1o5{R'j!rQ/Q)eR4S/QU#_W%h*YU(_#_(`.RQ(`#`R.R(ZQ-a']R2t-at`OXst!V!Z#d%m&i&k&r&t&u&w,s,x2[2_S#hZ%eU#r`#h.[R.[(jQ(k#jQ.X(gW.a(k.X3X7RQ3X.YR7R3YQ)n$lR/W)nQ$phR)t$pQ$`cU)a$`-|<jQ-|<WR<j)qQ/q*]W4c/q4d7t9sU4d/r/s/tS7t4e4fR9s7u$e*Q$v(u)c)e*[*e*t*u+Q+R+V.l.m.o.p.q/_/g/i/k/v/|0d0e0v1e3f3g3h3}4R4[4g4h4l4|5O5R5S5W5r7]7^7_7`7e7f7h7i7j7p7w7z8U8X8Z9h9i9j9t9|:R:S:t:u:v:w:x:};R;e;j;v;y=p=}>O>Z>[Q/z*eU4k/z4m7xQ4m/|R7x4lS*o$|*ZR0Y*ox*S$v)e*t*u+V/v0d0e4R4g5R5S5W7p8U:R:x=p=}>O!d.j(u)c*[*e.l.m.q/_/k/|0v1e3h4[4h4l5r7]7`7w7z8X8Z9t9|:S:};R;e;j;v>Z>[U/h*S.j7ca7c3}7e7f7j9h:t:w;yQ0a*tQ3i.lU4}0a3i9kR9k7e|*U$v)e*t*u+V/g/v0d0e4R4g4|5R5S5W7p8U:R:x=p=}>O!h.k(u)c*[*e.l.m.q/_/k/|0v1e3f3h4[4h4l5r7]7^7`7w7z8X8Z9t9|:S:};R;e;j;v>Z>[U/j*U.k7de7d3}7e7f7j9h9i:t:u:w;yQ0c*uQ3j.mU5P0c3j9lR9l7fQ*z%UR0g*zQ5]0vR8Y5]Q+_%kR0u+_Q5v1jS8j5v:[R:[8kQ,[&_R1m,[Q5{1oR8m5{Q1{,fS6]1{8zR8z6_Q1U+rW5h1U5j8a:VQ5j1XQ8a5iR:V8bQ+w&QR1[+wQ2_,xR6m2_YrOXst#dQ&v!ZQ+a%mQ,r&rQ,t&tQ,u&uQ,w&wQ2Y,sS2],x2_R6l2[Q%opQ&z!_Q&}!aQ'P!bQ'R!cQ'q!uQ+`%lQ+l%zQ,Q&XQ,h&mQ-P&|W-p'k's't'wQ-w'oQ0X*nQ1P+mQ1c,PS2O,i,lQ2g-OQ2h-RQ2i-SQ2}-oW3P-r-s-v-xQ5a1QQ5m1_Q5q1eQ6V1uQ6a2QQ6k2ZU6z3O3R3UQ6}3SQ8]5bQ8e5oQ8g5rQ8l5zQ8u6WQ8{6`S9[6{7PQ9^7OQ:W8cQ:b8vQ:g8|Q:n9]Q;U:XQ;]:cQ;a:oQ;l;VR;o;^Q%zyQ'd!iQ'o!uU+m%{%|%}Q-W'VU-k'e'f'gS-o'k'uQ0Q*jS1Q+n+oQ2o-YS2{-l-mQ3S-tS4p0R0UQ5b1RQ6v2uQ6y2|Q7O3TU7{4r4s4vQ9z7}R;O9{S$wi>PR*{%VU%Ui%V>PR0f*yQ$viS(u#v+iS)c$b$cQ)e$dQ*[$xS*e${*YQ*t%OQ*u%QQ+Q%^Q+R%_Q+V%cQ.l<oQ.m<qQ.o<uQ.p<wQ.q<yQ/_)yQ/g*RQ/i*TQ/k*VQ/v*aS/|*g/mQ0d*wQ0e*xl0v+f,V.f1i1q3c6S7W8q9b:`:r;[;dQ1e,SQ3f=SQ3g=UQ3h=XS3}<l<mQ4R/PS4[/d4^Q4g/xQ4h/yQ4l/{Q4|0`Q5O0bQ5R0iQ5S0jQ5W0oQ5r1fQ7]=]Q7^=_Q7_=aQ7`=cQ7e<pQ7f<rQ7h<vQ7i<xQ7j<zQ7p4_Q7w4jQ7z4oQ8U5QQ8X5[Q8Z5_Q9h=YQ9i=TQ9j=VQ9t7vQ9|8QQ:R8VQ:S8[Q:t=^Q:u=`Q:v=bQ:w=dQ:x9pQ:}9yQ;R:PQ;e=gQ;j;QQ;v;kQ;y=hQ=p>PQ=}>XQ>O>YQ>Z>]R>[>^Q+O%]Q.n<sR7g<tnpOXst!Z#d%m&r&t&u&w,s,x2[2_Q!fPS#fZ#oQ&|!`W'h!o*i0]4zQ(P#SQ)Q#{Q)r$nS,l&k&nQ,q&oQ-O&{S-T'T/nQ-g'bQ.x)OQ/[)sQ0s+]Q0y+gQ2W,pQ2y-iQ3a.gQ4W/VQ5U0lQ6Q1rQ6c2SQ6d2TQ6h2VQ6j2XQ6o2aQ7Z3dQ7m4TQ8s6TQ9P6eQ9Q6fQ9S6iQ9f7[Q:a8tR:k9T#[cOPXZst!Z!`!o#d#o#{%m&k&n&o&r&t&u&w&{'T'b)O*i+]+g,p,s,x-i.g/n0]0l1r2S2T2V2X2[2_2a3d4z6T6e6f6i7[8t9TQ#YWQ#eYQ%quQ%svS%uw!gS(S#W(VQ(Y#ZQ(t#uQ(y#xQ)R$OQ)S$PQ)T$QQ)U$RQ)V$SQ)W$TQ)X$UQ)Y$VQ)Z$WQ)[$XQ)^$ZQ)`$_Q)b$aQ)g$eW)q$n)s/V4TQ+d%tQ+x&RS-Z'X2pQ-x'rS-}(T.PQ.S(]Q.U(dQ.s(xQ.v(zQ.z<UQ.|<XQ.}<YQ/O<]Q/b)}Q0p+XQ2k-UQ2n-XQ3O-qQ3V.VQ3k.tQ3p<^Q3q<_Q3r<`Q3s<aQ3t<bQ3u<cQ3v<dQ3w<eQ3x<fQ3y<gQ3z<hQ3{.{Q3|<kQ4P<nQ4Q<{Q4X<iQ5X0rQ5c1SQ6u=OQ6{3QQ7Q3WQ7a3lQ7b=PQ7k=RQ7l=ZQ8k5wQ9X6sQ9]6|Q9g=[Q9m=eQ9n=fQ:o9_Q;W:ZQ;`:mQ<W#SR=v>SR#[WR'Z!el!tQ!r!v!y!z'`'l'm'n-e-u1o5{5}S'V!e-]U*j$|*Z*oS-Y'W'_S0U*k*qQ0^*rQ2u-cQ4v0[R4{0_R({#xQ!fQT-d'`-e]!qQ!r'`-e1o5{Q#p]R'i<VR)f$dY!uQ'`-e1o5{Q'k!rS'u!v!yS'w!z5}S-t'l'mQ-v'nR3T-uT#kZ%eS#jZ%eS%km,oU(g#h#i#lS.Y(h(iQ.^(jQ0t+^Q3Y.ZU3Z.[.]._S7S3[3]R9`7Td#^W#W#Z%h(T(^*Y+Z.T/mr#gZm#h#i#l%e(h(i(j+^.Z.[.]._3[3]7TS*]$x*bQ/t*^Q2U,oQ2l-VQ4`/pQ6q2dQ7s4aQ9W6rT=m'X+[V#aW%h*YU#`W%h*YS(U#W(^U(Z#Z+Z/mS-['X+[T.O(T.TV'^!e%i*ZQ$lfR)x$qT)m$l)nR4V/UT*_$x*bT*h${*YQ0w+fQ1g,VQ3_.fQ5t1iQ6P1qQ7X3cQ8r6SQ9c7WQ:^8qQ:p9bQ;Z:`Q;c:rQ;n;[R;q;dnqOXst!Z#d%m&r&t&u&w,s,x2[2_Q&l!VR,h&itmOXst!U!V!Z#d%m&i&r&t&u&w,s,x2[2_R,o&oT%lm,oR1k,XR,g&gQ&U|S+}&V&WR1^,OR+s&PT&p!W&sT&q!W&sT2^,x2_",
        nodeNames: "\u26a0 ArithOp ArithOp ?. JSXStartTag LineComment BlockComment Script Hashbang ExportDeclaration export Star as VariableName String Escape from ; default FunctionDeclaration async function VariableDefinition > < TypeParamList in out const TypeDefinition extends ThisType this LiteralType ArithOp Number BooleanLiteral TemplateType InterpolationEnd Interpolation InterpolationStart NullType null VoidType void TypeofType typeof MemberExpression . PropertyName [ TemplateString Escape Interpolation super RegExp ] ArrayExpression Spread , } { ObjectExpression Property async get set PropertyDefinition Block : NewTarget new NewExpression ) ( ArgList UnaryExpression delete LogicOp BitOp YieldExpression yield AwaitExpression await ParenthesizedExpression ClassExpression class ClassBody MethodDeclaration Decorator @ MemberExpression PrivatePropertyName CallExpression TypeArgList CompareOp < declare Privacy static abstract override PrivatePropertyDefinition PropertyDeclaration readonly accessor Optional TypeAnnotation Equals StaticBlock FunctionExpression ArrowFunction ParamList ParamList ArrayPattern ObjectPattern PatternProperty Privacy readonly Arrow MemberExpression BinaryExpression ArithOp ArithOp ArithOp ArithOp BitOp CompareOp instanceof satisfies CompareOp BitOp BitOp BitOp LogicOp LogicOp ConditionalExpression LogicOp LogicOp AssignmentExpression UpdateOp PostfixExpression CallExpression InstantiationExpression TaggedTemplateExpression DynamicImport import ImportMeta JSXElement JSXSelfCloseEndTag JSXSelfClosingTag JSXIdentifier JSXBuiltin JSXIdentifier JSXNamespacedName JSXMemberExpression JSXSpreadAttribute JSXAttribute JSXAttributeValue JSXEscape JSXEndTag JSXOpenTag JSXFragmentTag JSXText JSXEscape JSXStartCloseTag JSXCloseTag PrefixCast < ArrowFunction TypeParamList SequenceExpression InstantiationExpression KeyofType keyof UniqueType unique ImportType InferredType infer TypeName ParenthesizedType FunctionSignature ParamList NewSignature IndexedType TupleType Label ArrayType ReadonlyType ObjectType MethodType PropertyType IndexSignature PropertyDefinition CallSignature TypePredicate asserts is NewSignature new UnionType LogicOp IntersectionType LogicOp ConditionalType ParameterizedType ClassDeclaration abstract implements type VariableDeclaration let var using TypeAliasDeclaration InterfaceDeclaration interface EnumDeclaration enum EnumBody NamespaceDeclaration namespace module AmbientDeclaration declare GlobalDeclaration global ClassDeclaration ClassBody AmbientFunctionDeclaration ExportGroup VariableName VariableName ImportDeclaration defer ImportGroup ForStatement for ForSpec ForInSpec ForOfSpec of WhileStatement while WithStatement with DoStatement do IfStatement if else SwitchStatement switch SwitchBody CaseLabel case DefaultLabel TryStatement try CatchClause catch FinallyClause finally ReturnStatement return ThrowStatement throw BreakStatement break ContinueStatement continue DebuggerStatement debugger LabeledStatement ExpressionStatement SingleExpression SingleClassItem",
        maxTerm: 380,
        context: iK,
        nodeProps: [
          ["isolate", -8, 5, 6, 14, 37, 39, 51, 53, 55, ""],
          ["group", -26, 9, 17, 19, 68, 207, 211, 215, 216, 218, 221, 224, 234, 237, 243, 245, 247, 249, 252, 258, 264, 266, 268, 270, 272, 274, 275, "Statement", -34, 13, 14, 32, 35, 36, 42, 51, 54, 55, 57, 62, 70, 72, 76, 80, 82, 84, 85, 110, 111, 120, 121, 136, 139, 141, 142, 143, 144, 145, 147, 148, 167, 169, 171, "Expression", -23, 31, 33, 37, 41, 43, 45, 173, 175, 177, 178, 180, 181, 182, 184, 185, 186, 188, 189, 190, 201, 203, 205, 206, "Type", -3, 88, 103, 109, "ClassItem"],
          ["openedBy", 23, "<", 38, "InterpolationStart", 56, "[", 60, "{", 73, "(", 160, "JSXStartCloseTag"],
          ["closedBy", -2, 24, 168, ">", 40, "InterpolationEnd", 50, "]", 61, "}", 74, ")", 165, "JSXEndTag"]
        ],
        propSources: [SO],
        skippedNodes: [0, 5, 6, 278],
        repeatNodeCount: 37,
        tokenData: "$Fq07[R!bOX%ZXY+gYZ-yZ[+g[]%Z]^.c^p%Zpq+gqr/mrs3cst:_tuEruvJSvwLkwx! Yxy!'iyz!(sz{!)}{|!,q|}!.O}!O!,q!O!P!/Y!P!Q!9j!Q!R#:O!R![#<_![!]#I_!]!^#Jk!^!_#Ku!_!`$![!`!a$$v!a!b$*T!b!c$,r!c!}Er!}#O$-|#O#P$/W#P#Q$4o#Q#R$5y#R#SEr#S#T$7W#T#o$8b#o#p$<r#p#q$=h#q#r$>x#r#s$@U#s$f%Z$f$g+g$g#BYEr#BY#BZ$A`#BZ$ISEr$IS$I_$A`$I_$I|Er$I|$I}$Dk$I}$JO$Dk$JO$JTEr$JT$JU$A`$JU$KVEr$KV$KW$A`$KW&FUEr&FU&FV$A`&FV;'SEr;'S;=`I|<%l?HTEr?HT?HU$A`?HUOEr(n%d_$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z&j&hT$i&jO!^&c!_#o&c#p;'S&c;'S;=`&w<%lO&c&j&zP;=`<%l&c'|'U]$i&j(Z!bOY&}YZ&cZw&}wx&cx!^&}!^!_'}!_#O&}#O#P&c#P#o&}#o#p'}#p;'S&};'S;=`(l<%lO&}!b(SU(Z!bOY'}Zw'}x#O'}#P;'S'};'S;=`(f<%lO'}!b(iP;=`<%l'}'|(oP;=`<%l&}'[(y]$i&j(WpOY(rYZ&cZr(rrs&cs!^(r!^!_)r!_#O(r#O#P&c#P#o(r#o#p)r#p;'S(r;'S;=`*a<%lO(rp)wU(WpOY)rZr)rs#O)r#P;'S)r;'S;=`*Z<%lO)rp*^P;=`<%l)r'[*dP;=`<%l(r#S*nX(Wp(Z!bOY*gZr*grs'}sw*gwx)rx#O*g#P;'S*g;'S;=`+Z<%lO*g#S+^P;=`<%l*g(n+dP;=`<%l%Z07[+rq$i&j(Wp(Z!b'|0/lOX%ZXY+gYZ&cZ[+g[p%Zpq+gqr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p$f%Z$f$g+g$g#BY%Z#BY#BZ+g#BZ$IS%Z$IS$I_+g$I_$JT%Z$JT$JU+g$JU$KV%Z$KV$KW+g$KW&FU%Z&FU&FV+g&FV;'S%Z;'S;=`+a<%l?HT%Z?HT?HU+g?HUO%Z07[.ST(X#S$i&j'}0/lO!^&c!_#o&c#p;'S&c;'S;=`&w<%lO&c07[.n_$i&j(Wp(Z!b'}0/lOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z)3p/x`$i&j!p),Q(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`0z!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(KW1V`#v(Ch$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`2X!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(KW2d_#v(Ch$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'At3l_(V':f$i&j(Z!bOY4kYZ5qZr4krs7nsw4kwx5qx!^4k!^!_8p!_#O4k#O#P5q#P#o4k#o#p8p#p;'S4k;'S;=`:X<%lO4k(^4r_$i&j(Z!bOY4kYZ5qZr4krs7nsw4kwx5qx!^4k!^!_8p!_#O4k#O#P5q#P#o4k#o#p8p#p;'S4k;'S;=`:X<%lO4k&z5vX$i&jOr5qrs6cs!^5q!^!_6y!_#o5q#o#p6y#p;'S5q;'S;=`7h<%lO5q&z6jT$d`$i&jO!^&c!_#o&c#p;'S&c;'S;=`&w<%lO&c`6|TOr6yrs7]s;'S6y;'S;=`7b<%lO6y`7bO$d``7eP;=`<%l6y&z7kP;=`<%l5q(^7w]$d`$i&j(Z!bOY&}YZ&cZw&}wx&cx!^&}!^!_'}!_#O&}#O#P&c#P#o&}#o#p'}#p;'S&};'S;=`(l<%lO&}!r8uZ(Z!bOY8pYZ6yZr8prs9hsw8pwx6yx#O8p#O#P6y#P;'S8p;'S;=`:R<%lO8p!r9oU$d`(Z!bOY'}Zw'}x#O'}#P;'S'};'S;=`(f<%lO'}!r:UP;=`<%l8p(^:[P;=`<%l4k%9[:hh$i&j(Wp(Z!bOY%ZYZ&cZq%Zqr<Srs&}st%ZtuCruw%Zwx(rx!^%Z!^!_*g!_!c%Z!c!}Cr!}#O%Z#O#P&c#P#R%Z#R#SCr#S#T%Z#T#oCr#o#p*g#p$g%Z$g;'SCr;'S;=`El<%lOCr(r<__WS$i&j(Wp(Z!bOY<SYZ&cZr<Srs=^sw<Swx@nx!^<S!^!_Bm!_#O<S#O#P>`#P#o<S#o#pBm#p;'S<S;'S;=`Cl<%lO<S(Q=g]WS$i&j(Z!bOY=^YZ&cZw=^wx>`x!^=^!^!_?q!_#O=^#O#P>`#P#o=^#o#p?q#p;'S=^;'S;=`@h<%lO=^&n>gXWS$i&jOY>`YZ&cZ!^>`!^!_?S!_#o>`#o#p?S#p;'S>`;'S;=`?k<%lO>`S?XSWSOY?SZ;'S?S;'S;=`?e<%lO?SS?hP;=`<%l?S&n?nP;=`<%l>`!f?xWWS(Z!bOY?qZw?qwx?Sx#O?q#O#P?S#P;'S?q;'S;=`@b<%lO?q!f@eP;=`<%l?q(Q@kP;=`<%l=^'`@w]WS$i&j(WpOY@nYZ&cZr@nrs>`s!^@n!^!_Ap!_#O@n#O#P>`#P#o@n#o#pAp#p;'S@n;'S;=`Bg<%lO@ntAwWWS(WpOYApZrAprs?Ss#OAp#O#P?S#P;'SAp;'S;=`Ba<%lOAptBdP;=`<%lAp'`BjP;=`<%l@n#WBvYWS(Wp(Z!bOYBmZrBmrs?qswBmwxApx#OBm#O#P?S#P;'SBm;'S;=`Cf<%lOBm#WCiP;=`<%lBm(rCoP;=`<%l<S%9[C}i$i&j(o%1l(Wp(Z!bOY%ZYZ&cZr%Zrs&}st%ZtuCruw%Zwx(rx!Q%Z!Q![Cr![!^%Z!^!_*g!_!c%Z!c!}Cr!}#O%Z#O#P&c#P#R%Z#R#SCr#S#T%Z#T#oCr#o#p*g#p$g%Z$g;'SCr;'S;=`El<%lOCr%9[EoP;=`<%lCr07[FRk$i&j(Wp(Z!b$]#t(T,2j(e$I[OY%ZYZ&cZr%Zrs&}st%ZtuEruw%Zwx(rx}%Z}!OGv!O!Q%Z!Q![Er![!^%Z!^!_*g!_!c%Z!c!}Er!}#O%Z#O#P&c#P#R%Z#R#SEr#S#T%Z#T#oEr#o#p*g#p$g%Z$g;'SEr;'S;=`I|<%lOEr+dHRk$i&j(Wp(Z!b$]#tOY%ZYZ&cZr%Zrs&}st%ZtuGvuw%Zwx(rx}%Z}!OGv!O!Q%Z!Q![Gv![!^%Z!^!_*g!_!c%Z!c!}Gv!}#O%Z#O#P&c#P#R%Z#R#SGv#S#T%Z#T#oGv#o#p*g#p$g%Z$g;'SGv;'S;=`Iv<%lOGv+dIyP;=`<%lGv07[JPP;=`<%lEr(KWJ_`$i&j(Wp(Z!b#p(ChOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`Ka!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(KWKl_$i&j$Q(Ch(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z,#xLva(z+JY$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sv%ZvwM{wx(rx!^%Z!^!_*g!_!`Ka!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(KWNW`$i&j#z(Ch(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`Ka!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'At! c_(Y';W$i&j(WpOY!!bYZ!#hZr!!brs!#hsw!!bwx!$xx!^!!b!^!_!%z!_#O!!b#O#P!#h#P#o!!b#o#p!%z#p;'S!!b;'S;=`!'c<%lO!!b'l!!i_$i&j(WpOY!!bYZ!#hZr!!brs!#hsw!!bwx!$xx!^!!b!^!_!%z!_#O!!b#O#P!#h#P#o!!b#o#p!%z#p;'S!!b;'S;=`!'c<%lO!!b&z!#mX$i&jOw!#hwx6cx!^!#h!^!_!$Y!_#o!#h#o#p!$Y#p;'S!#h;'S;=`!$r<%lO!#h`!$]TOw!$Ywx7]x;'S!$Y;'S;=`!$l<%lO!$Y`!$oP;=`<%l!$Y&z!$uP;=`<%l!#h'l!%R]$d`$i&j(WpOY(rYZ&cZr(rrs&cs!^(r!^!_)r!_#O(r#O#P&c#P#o(r#o#p)r#p;'S(r;'S;=`*a<%lO(r!Q!&PZ(WpOY!%zYZ!$YZr!%zrs!$Ysw!%zwx!&rx#O!%z#O#P!$Y#P;'S!%z;'S;=`!']<%lO!%z!Q!&yU$d`(WpOY)rZr)rs#O)r#P;'S)r;'S;=`*Z<%lO)r!Q!'`P;=`<%l!%z'l!'fP;=`<%l!!b/5|!'t_!l/.^$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z#&U!)O_!k!Lf$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z-!n!*[b$i&j(Wp(Z!b(U%&f#q(ChOY%ZYZ&cZr%Zrs&}sw%Zwx(rxz%Zz{!+d{!^%Z!^!_*g!_!`Ka!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(KW!+o`$i&j(Wp(Z!b#n(ChOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`Ka!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z+;x!,|`$i&j(Wp(Z!br+4YOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`Ka!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z,$U!.Z_!]+Jf$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z07[!/ec$i&j(Wp(Z!b!Q.2^OY%ZYZ&cZr%Zrs&}sw%Zwx(rx!O%Z!O!P!0p!P!Q%Z!Q![!3Y![!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z#%|!0ya$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!O%Z!O!P!2O!P!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z#%|!2Z_![!L^$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad!3eg$i&j(Wp(Z!bs'9tOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!Q%Z!Q![!3Y![!^%Z!^!_*g!_!g%Z!g!h!4|!h#O%Z#O#P&c#P#R%Z#R#S!3Y#S#X%Z#X#Y!4|#Y#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad!5Vg$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx{%Z{|!6n|}%Z}!O!6n!O!Q%Z!Q![!8S![!^%Z!^!_*g!_#O%Z#O#P&c#P#R%Z#R#S!8S#S#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad!6wc$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!Q%Z!Q![!8S![!^%Z!^!_*g!_#O%Z#O#P&c#P#R%Z#R#S!8S#S#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad!8_c$i&j(Wp(Z!bs'9tOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!Q%Z!Q![!8S![!^%Z!^!_*g!_#O%Z#O#P&c#P#R%Z#R#S!8S#S#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z07[!9uf$i&j(Wp(Z!b#o(ChOY!;ZYZ&cZr!;Zrs!<nsw!;Zwx!Lcxz!;Zz{#-}{!P!;Z!P!Q#/d!Q!^!;Z!^!_#(i!_!`#7S!`!a#8i!a!}!;Z!}#O#,f#O#P!Dy#P#o!;Z#o#p#(i#p;'S!;Z;'S;=`#-w<%lO!;Z?O!;fb$i&j(Wp(Z!b!X7`OY!;ZYZ&cZr!;Zrs!<nsw!;Zwx!Lcx!P!;Z!P!Q#&`!Q!^!;Z!^!_#(i!_!}!;Z!}#O#,f#O#P!Dy#P#o!;Z#o#p#(i#p;'S!;Z;'S;=`#-w<%lO!;Z>^!<w`$i&j(Z!b!X7`OY!<nYZ&cZw!<nwx!=yx!P!<n!P!Q!Eq!Q!^!<n!^!_!Gr!_!}!<n!}#O!KS#O#P!Dy#P#o!<n#o#p!Gr#p;'S!<n;'S;=`!L]<%lO!<n<z!>Q^$i&j!X7`OY!=yYZ&cZ!P!=y!P!Q!>|!Q!^!=y!^!_!@c!_!}!=y!}#O!CW#O#P!Dy#P#o!=y#o#p!@c#p;'S!=y;'S;=`!Ek<%lO!=y<z!?Td$i&j!X7`O!^&c!_#W&c#W#X!>|#X#Z&c#Z#[!>|#[#]&c#]#^!>|#^#a&c#a#b!>|#b#g&c#g#h!>|#h#i&c#i#j!>|#j#k!>|#k#m&c#m#n!>|#n#o&c#p;'S&c;'S;=`&w<%lO&c7`!@hX!X7`OY!@cZ!P!@c!P!Q!AT!Q!}!@c!}#O!Ar#O#P!Bq#P;'S!@c;'S;=`!CQ<%lO!@c7`!AYW!X7`#W#X!AT#Z#[!AT#]#^!AT#a#b!AT#g#h!AT#i#j!AT#j#k!AT#m#n!AT7`!AuVOY!ArZ#O!Ar#O#P!B[#P#Q!@c#Q;'S!Ar;'S;=`!Bk<%lO!Ar7`!B_SOY!ArZ;'S!Ar;'S;=`!Bk<%lO!Ar7`!BnP;=`<%l!Ar7`!BtSOY!@cZ;'S!@c;'S;=`!CQ<%lO!@c7`!CTP;=`<%l!@c<z!C][$i&jOY!CWYZ&cZ!^!CW!^!_!Ar!_#O!CW#O#P!DR#P#Q!=y#Q#o!CW#o#p!Ar#p;'S!CW;'S;=`!Ds<%lO!CW<z!DWX$i&jOY!CWYZ&cZ!^!CW!^!_!Ar!_#o!CW#o#p!Ar#p;'S!CW;'S;=`!Ds<%lO!CW<z!DvP;=`<%l!CW<z!EOX$i&jOY!=yYZ&cZ!^!=y!^!_!@c!_#o!=y#o#p!@c#p;'S!=y;'S;=`!Ek<%lO!=y<z!EnP;=`<%l!=y>^!Ezl$i&j(Z!b!X7`OY&}YZ&cZw&}wx&cx!^&}!^!_'}!_#O&}#O#P&c#P#W&}#W#X!Eq#X#Z&}#Z#[!Eq#[#]&}#]#^!Eq#^#a&}#a#b!Eq#b#g&}#g#h!Eq#h#i&}#i#j!Eq#j#k!Eq#k#m&}#m#n!Eq#n#o&}#o#p'}#p;'S&};'S;=`(l<%lO&}8r!GyZ(Z!b!X7`OY!GrZw!Grwx!@cx!P!Gr!P!Q!Hl!Q!}!Gr!}#O!JU#O#P!Bq#P;'S!Gr;'S;=`!J|<%lO!Gr8r!Hse(Z!b!X7`OY'}Zw'}x#O'}#P#W'}#W#X!Hl#X#Z'}#Z#[!Hl#[#]'}#]#^!Hl#^#a'}#a#b!Hl#b#g'}#g#h!Hl#h#i'}#i#j!Hl#j#k!Hl#k#m'}#m#n!Hl#n;'S'};'S;=`(f<%lO'}8r!JZX(Z!bOY!JUZw!JUwx!Arx#O!JU#O#P!B[#P#Q!Gr#Q;'S!JU;'S;=`!Jv<%lO!JU8r!JyP;=`<%l!JU8r!KPP;=`<%l!Gr>^!KZ^$i&j(Z!bOY!KSYZ&cZw!KSwx!CWx!^!KS!^!_!JU!_#O!KS#O#P!DR#P#Q!<n#Q#o!KS#o#p!JU#p;'S!KS;'S;=`!LV<%lO!KS>^!LYP;=`<%l!KS>^!L`P;=`<%l!<n=l!Ll`$i&j(Wp!X7`OY!LcYZ&cZr!Lcrs!=ys!P!Lc!P!Q!Mn!Q!^!Lc!^!_# o!_!}!Lc!}#O#%P#O#P!Dy#P#o!Lc#o#p# o#p;'S!Lc;'S;=`#&Y<%lO!Lc=l!Mwl$i&j(Wp!X7`OY(rYZ&cZr(rrs&cs!^(r!^!_)r!_#O(r#O#P&c#P#W(r#W#X!Mn#X#Z(r#Z#[!Mn#[#](r#]#^!Mn#^#a(r#a#b!Mn#b#g(r#g#h!Mn#h#i(r#i#j!Mn#j#k!Mn#k#m(r#m#n!Mn#n#o(r#o#p)r#p;'S(r;'S;=`*a<%lO(r8Q# vZ(Wp!X7`OY# oZr# ors!@cs!P# o!P!Q#!i!Q!}# o!}#O#$R#O#P!Bq#P;'S# o;'S;=`#$y<%lO# o8Q#!pe(Wp!X7`OY)rZr)rs#O)r#P#W)r#W#X#!i#X#Z)r#Z#[#!i#[#])r#]#^#!i#^#a)r#a#b#!i#b#g)r#g#h#!i#h#i)r#i#j#!i#j#k#!i#k#m)r#m#n#!i#n;'S)r;'S;=`*Z<%lO)r8Q#$WX(WpOY#$RZr#$Rrs!Ars#O#$R#O#P!B[#P#Q# o#Q;'S#$R;'S;=`#$s<%lO#$R8Q#$vP;=`<%l#$R8Q#$|P;=`<%l# o=l#%W^$i&j(WpOY#%PYZ&cZr#%Prs!CWs!^#%P!^!_#$R!_#O#%P#O#P!DR#P#Q!Lc#Q#o#%P#o#p#$R#p;'S#%P;'S;=`#&S<%lO#%P=l#&VP;=`<%l#%P=l#&]P;=`<%l!Lc?O#&kn$i&j(Wp(Z!b!X7`OY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#W%Z#W#X#&`#X#Z%Z#Z#[#&`#[#]%Z#]#^#&`#^#a%Z#a#b#&`#b#g%Z#g#h#&`#h#i%Z#i#j#&`#j#k#&`#k#m%Z#m#n#&`#n#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z9d#(r](Wp(Z!b!X7`OY#(iZr#(irs!Grsw#(iwx# ox!P#(i!P!Q#)k!Q!}#(i!}#O#+`#O#P!Bq#P;'S#(i;'S;=`#,`<%lO#(i9d#)th(Wp(Z!b!X7`OY*gZr*grs'}sw*gwx)rx#O*g#P#W*g#W#X#)k#X#Z*g#Z#[#)k#[#]*g#]#^#)k#^#a*g#a#b#)k#b#g*g#g#h#)k#h#i*g#i#j#)k#j#k#)k#k#m*g#m#n#)k#n;'S*g;'S;=`+Z<%lO*g9d#+gZ(Wp(Z!bOY#+`Zr#+`rs!JUsw#+`wx#$Rx#O#+`#O#P!B[#P#Q#(i#Q;'S#+`;'S;=`#,Y<%lO#+`9d#,]P;=`<%l#+`9d#,cP;=`<%l#(i?O#,o`$i&j(Wp(Z!bOY#,fYZ&cZr#,frs!KSsw#,fwx#%Px!^#,f!^!_#+`!_#O#,f#O#P!DR#P#Q!;Z#Q#o#,f#o#p#+`#p;'S#,f;'S;=`#-q<%lO#,f?O#-tP;=`<%l#,f?O#-zP;=`<%l!;Z07[#.[b$i&j(Wp(Z!b(O0/l!X7`OY!;ZYZ&cZr!;Zrs!<nsw!;Zwx!Lcx!P!;Z!P!Q#&`!Q!^!;Z!^!_#(i!_!}!;Z!}#O#,f#O#P!Dy#P#o!;Z#o#p#(i#p;'S!;Z;'S;=`#-w<%lO!;Z07[#/o_$i&j(Wp(Z!bT0/lOY#/dYZ&cZr#/drs#0nsw#/dwx#4Ox!^#/d!^!_#5}!_#O#/d#O#P#1p#P#o#/d#o#p#5}#p;'S#/d;'S;=`#6|<%lO#/d06j#0w]$i&j(Z!bT0/lOY#0nYZ&cZw#0nwx#1px!^#0n!^!_#3R!_#O#0n#O#P#1p#P#o#0n#o#p#3R#p;'S#0n;'S;=`#3x<%lO#0n05W#1wX$i&jT0/lOY#1pYZ&cZ!^#1p!^!_#2d!_#o#1p#o#p#2d#p;'S#1p;'S;=`#2{<%lO#1p0/l#2iST0/lOY#2dZ;'S#2d;'S;=`#2u<%lO#2d0/l#2xP;=`<%l#2d05W#3OP;=`<%l#1p01O#3YW(Z!bT0/lOY#3RZw#3Rwx#2dx#O#3R#O#P#2d#P;'S#3R;'S;=`#3r<%lO#3R01O#3uP;=`<%l#3R06j#3{P;=`<%l#0n05x#4X]$i&j(WpT0/lOY#4OYZ&cZr#4Ors#1ps!^#4O!^!_#5Q!_#O#4O#O#P#1p#P#o#4O#o#p#5Q#p;'S#4O;'S;=`#5w<%lO#4O00^#5XW(WpT0/lOY#5QZr#5Qrs#2ds#O#5Q#O#P#2d#P;'S#5Q;'S;=`#5q<%lO#5Q00^#5tP;=`<%l#5Q05x#5zP;=`<%l#4O01p#6WY(Wp(Z!bT0/lOY#5}Zr#5}rs#3Rsw#5}wx#5Qx#O#5}#O#P#2d#P;'S#5};'S;=`#6v<%lO#5}01p#6yP;=`<%l#5}07[#7PP;=`<%l#/d)3h#7ab$i&j$Q(Ch(Wp(Z!b!X7`OY!;ZYZ&cZr!;Zrs!<nsw!;Zwx!Lcx!P!;Z!P!Q#&`!Q!^!;Z!^!_#(i!_!}!;Z!}#O#,f#O#P!Dy#P#o!;Z#o#p#(i#p;'S!;Z;'S;=`#-w<%lO!;ZAt#8vb$Z#t$i&j(Wp(Z!b!X7`OY!;ZYZ&cZr!;Zrs!<nsw!;Zwx!Lcx!P!;Z!P!Q#&`!Q!^!;Z!^!_#(i!_!}!;Z!}#O#,f#O#P!Dy#P#o!;Z#o#p#(i#p;'S!;Z;'S;=`#-w<%lO!;Z'Ad#:Zp$i&j(Wp(Z!bs'9tOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!O%Z!O!P!3Y!P!Q%Z!Q![#<_![!^%Z!^!_*g!_!g%Z!g!h!4|!h#O%Z#O#P&c#P#R%Z#R#S#<_#S#U%Z#U#V#?i#V#X%Z#X#Y!4|#Y#b%Z#b#c#>_#c#d#Bq#d#l%Z#l#m#Es#m#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad#<jk$i&j(Wp(Z!bs'9tOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!O%Z!O!P!3Y!P!Q%Z!Q![#<_![!^%Z!^!_*g!_!g%Z!g!h!4|!h#O%Z#O#P&c#P#R%Z#R#S#<_#S#X%Z#X#Y!4|#Y#b%Z#b#c#>_#c#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad#>j_$i&j(Wp(Z!bs'9tOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad#?rd$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!Q%Z!Q!R#AQ!R!S#AQ!S!^%Z!^!_*g!_#O%Z#O#P&c#P#R%Z#R#S#AQ#S#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad#A]f$i&j(Wp(Z!bs'9tOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!Q%Z!Q!R#AQ!R!S#AQ!S!^%Z!^!_*g!_#O%Z#O#P&c#P#R%Z#R#S#AQ#S#b%Z#b#c#>_#c#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad#Bzc$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!Q%Z!Q!Y#DV!Y!^%Z!^!_*g!_#O%Z#O#P&c#P#R%Z#R#S#DV#S#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad#Dbe$i&j(Wp(Z!bs'9tOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!Q%Z!Q!Y#DV!Y!^%Z!^!_*g!_#O%Z#O#P&c#P#R%Z#R#S#DV#S#b%Z#b#c#>_#c#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad#E|g$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!Q%Z!Q![#Ge![!^%Z!^!_*g!_!c%Z!c!i#Ge!i#O%Z#O#P&c#P#R%Z#R#S#Ge#S#T%Z#T#Z#Ge#Z#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z'Ad#Gpi$i&j(Wp(Z!bs'9tOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!Q%Z!Q![#Ge![!^%Z!^!_*g!_!c%Z!c!i#Ge!i#O%Z#O#P&c#P#R%Z#R#S#Ge#S#T%Z#T#Z#Ge#Z#b%Z#b#c#>_#c#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z*)x#Il_!g$b$i&j$O)Lv(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z)[#Jv_al$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z04f#LS^h#)`#R-<U(Wp(Z!b$n7`OY*gZr*grs'}sw*gwx)rx!P*g!P!Q#MO!Q!^*g!^!_#Mt!_!`$ f!`#O*g#P;'S*g;'S;=`+Z<%lO*g(n#MXX$k&j(Wp(Z!bOY*gZr*grs'}sw*gwx)rx#O*g#P;'S*g;'S;=`+Z<%lO*g(El#M}Z#r(Ch(Wp(Z!bOY*gZr*grs'}sw*gwx)rx!_*g!_!`#Np!`#O*g#P;'S*g;'S;=`+Z<%lO*g(El#NyX$Q(Ch(Wp(Z!bOY*gZr*grs'}sw*gwx)rx#O*g#P;'S*g;'S;=`+Z<%lO*g(El$ oX#s(Ch(Wp(Z!bOY*gZr*grs'}sw*gwx)rx#O*g#P;'S*g;'S;=`+Z<%lO*g*)x$!ga#`*!Y$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`0z!`!a$#l!a#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(K[$#w_#k(Cl$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z*)x$%Vag!*r#s(Ch$f#|$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`$&[!`!a$'f!a#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(KW$&g_#s(Ch$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(KW$'qa#r(Ch$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`Ka!`!a$(v!a#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(KW$)R`#r(Ch$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`Ka!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(Kd$*`a(r(Ct$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!a%Z!a!b$+e!b#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(KW$+p`$i&j#{(Ch(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`Ka!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z%#`$,}_!|$Ip$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z04f$.X_!S0,v$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(n$/]Z$i&jO!^$0O!^!_$0f!_#i$0O#i#j$0k#j#l$0O#l#m$2^#m#o$0O#o#p$0f#p;'S$0O;'S;=`$4i<%lO$0O(n$0VT_#S$i&jO!^&c!_#o&c#p;'S&c;'S;=`&w<%lO&c#S$0kO_#S(n$0p[$i&jO!Q&c!Q![$1f![!^&c!_!c&c!c!i$1f!i#T&c#T#Z$1f#Z#o&c#o#p$3|#p;'S&c;'S;=`&w<%lO&c(n$1kZ$i&jO!Q&c!Q![$2^![!^&c!_!c&c!c!i$2^!i#T&c#T#Z$2^#Z#o&c#p;'S&c;'S;=`&w<%lO&c(n$2cZ$i&jO!Q&c!Q![$3U![!^&c!_!c&c!c!i$3U!i#T&c#T#Z$3U#Z#o&c#p;'S&c;'S;=`&w<%lO&c(n$3ZZ$i&jO!Q&c!Q![$0O![!^&c!_!c&c!c!i$0O!i#T&c#T#Z$0O#Z#o&c#p;'S&c;'S;=`&w<%lO&c#S$4PR!Q![$4Y!c!i$4Y#T#Z$4Y#S$4]S!Q![$4Y!c!i$4Y#T#Z$4Y#q#r$0f(n$4lP;=`<%l$0O#1[$4z_!Y#)l$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z(KW$6U`#x(Ch$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`Ka!`#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z+;p$7c_$i&j(Wp(Z!b(a+4QOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z07[$8qk$i&j(Wp(Z!b(T,2j$_#t(e$I[OY%ZYZ&cZr%Zrs&}st%Ztu$8buw%Zwx(rx}%Z}!O$:f!O!Q%Z!Q![$8b![!^%Z!^!_*g!_!c%Z!c!}$8b!}#O%Z#O#P&c#P#R%Z#R#S$8b#S#T%Z#T#o$8b#o#p*g#p$g%Z$g;'S$8b;'S;=`$<l<%lO$8b+d$:qk$i&j(Wp(Z!b$_#tOY%ZYZ&cZr%Zrs&}st%Ztu$:fuw%Zwx(rx}%Z}!O$:f!O!Q%Z!Q![$:f![!^%Z!^!_*g!_!c%Z!c!}$:f!}#O%Z#O#P&c#P#R%Z#R#S$:f#S#T%Z#T#o$:f#o#p*g#p$g%Z$g;'S$:f;'S;=`$<f<%lO$:f+d$<iP;=`<%l$:f07[$<oP;=`<%l$8b#Jf$<{X!_#Hb(Wp(Z!bOY*gZr*grs'}sw*gwx)rx#O*g#P;'S*g;'S;=`+Z<%lO*g,#x$=sa(y+JY$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_!`Ka!`#O%Z#O#P&c#P#o%Z#o#p*g#p#q$+e#q;'S%Z;'S;=`+a<%lO%Z)>v$?V_!^(CdvBr$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z?O$@a_!q7`$i&j(Wp(Z!bOY%ZYZ&cZr%Zrs&}sw%Zwx(rx!^%Z!^!_*g!_#O%Z#O#P&c#P#o%Z#o#p*g#p;'S%Z;'S;=`+a<%lO%Z07[$Aq|$i&j(Wp(Z!b'|0/l$]#t(T,2j(e$I[OX%ZXY+gYZ&cZ[+g[p%Zpq+gqr%Zrs&}st%ZtuEruw%Zwx(rx}%Z}!OGv!O!Q%Z!Q![Er![!^%Z!^!_*g!_!c%Z!c!}Er!}#O%Z#O#P&c#P#R%Z#R#SEr#S#T%Z#T#oEr#o#p*g#p$f%Z$f$g+g$g#BYEr#BY#BZ$A`#BZ$ISEr$IS$I_$A`$I_$JTEr$JT$JU$A`$JU$KVEr$KV$KW$A`$KW&FUEr&FU&FV$A`&FV;'SEr;'S;=`I|<%l?HTEr?HT?HU$A`?HUOEr07[$D|k$i&j(Wp(Z!b'}0/l$]#t(T,2j(e$I[OY%ZYZ&cZr%Zrs&}st%ZtuEruw%Zwx(rx}%Z}!OGv!O!Q%Z!Q![Er![!^%Z!^!_*g!_!c%Z!c!}Er!}#O%Z#O#P&c#P#R%Z#R#SEr#S#T%Z#T#oEr#o#p*g#p$g%Z$g;'SEr;'S;=`I|<%lOEr",
        tokenizers: [PO, mK, sO, RO, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, rK, new oO("$S~RRtu[#O#Pg#S#T#|~_P#o#pb~gOx~~jVO#i!P#i#j!U#j#l!P#l#m!q#m;'S!P;'S;=`#v<%lO!P~!UO!U~~!XS!Q![!e!c!i!e#T#Z!e#o#p#Z~!hR!Q![!q!c!i!q#T#Z!q~!tR!Q![!}!c!i!}#T#Z!}~#QR!Q![!P!c!i!P#T#Z!P~#^R!Q![#g!c!i#g#T#Z#g~#jS!Q![#g!c!i#g#T#Z#g#q#r!P~#yP;=`<%l!P~$RO(c~~", 141, 340), new oO("j~RQYZXz{^~^O(Q~~aP!P!Qd~iO(R~~", 25, 323)],
        topRules: {
          Script: [0, 7],
          SingleExpression: [1, 276],
          SingleClassItem: [2, 277]
        },
        dialects: {
          jsx: 0,
          ts: 15175
        },
        dynamicPrecedences: {
          80: 1,
          82: 1,
          94: 1,
          169: 1,
          199: 1
        },
        specialized: [{
          term: 327,
          get: OO => JO[OO] || -1
        }, {
          term: 343,
          get: OO => cK[OO] || -1
        }, {
          term: 95,
          get: OO => BO[OO] || -1
        }],
        tokenPrec: 15201
      });
    var GO = pO(39347),
      qK = pO(39338),
      xK = pO(39341),
      nO = pO(39336);
    const WO = [(0, nO.p)("function ${name}(${params}) {\n\t${}\n}", {
        label: "function",
        detail: "definition",
        type: "keyword"
      }), (0, nO.p)("for (let ${index} = 0; ${index} < ${bound}; ${index}++) {\n\t${}\n}", {
        label: "for",
        detail: "loop",
        type: "keyword"
      }), (0, nO.p)("for (let ${name} of ${collection}) {\n\t${}\n}", {
        label: "for",
        detail: "of loop",
        type: "keyword"
      }), (0, nO.p)("do {\n\t${}\n} while (${})", {
        label: "do",
        detail: "loop",
        type: "keyword"
      }), (0, nO.p)("while (${}) {\n\t${}\n}", {
        label: "while",
        detail: "loop",
        type: "keyword"
      }), (0, nO.p)("try {\n\t${}\n} catch (${error}) {\n\t${}\n}", {
        label: "try",
        detail: "/ catch block",
        type: "keyword"
      }), (0, nO.p)("if (${}) {\n\t${}\n}", {
        label: "if",
        detail: "block",
        type: "keyword"
      }), (0, nO.p)("if (${}) {\n\t${}\n} else {\n\t${}\n}", {
        label: "if",
        detail: "/ else block",
        type: "keyword"
      }), (0, nO.p)("class ${name} {\n\tconstructor(${params}) {\n\t\t${}\n\t}\n}", {
        label: "class",
        detail: "definition",
        type: "keyword"
      }), (0, nO.p)('import {${names}} from "${module}"\n${}', {
        label: "import",
        detail: "named",
        type: "keyword"
      }), (0, nO.p)('import ${name} from "${module}"\n${}', {
        label: "import",
        detail: "default",
        type: "keyword"
      })],
      tK = WO.concat([(0, nO.p)("interface ${name} {\n\t${}\n}", {
        label: "interface",
        detail: "definition",
        type: "keyword"
      }), (0, nO.p)("type ${name} = ${type}", {
        label: "type",
        detail: "definition",
        type: "keyword"
      }), (0, nO.p)("enum ${name} {\n\t${}\n}", {
        label: "enum",
        detail: "definition",
        type: "keyword"
      })]),
      kK = new XO.r,
      UO = new Set(["Script", "Block", "FunctionExpression", "FunctionDeclaration", "ArrowFunction", "MethodDeclaration", "ForStatement"]);

    function OK(OO) {
      return (KO, pO) => {
        let XO = KO.node.getChild("VariableDefinition");
        return XO && pO(XO, OO), !0
      }
    }
    const KK = ["FunctionDeclaration"],
      pK = {
        FunctionDeclaration: OK("function"),
        ClassDeclaration: OK("class"),
        ClassExpression: () => !0,
        EnumDeclaration: OK("constant"),
        TypeAliasDeclaration: OK("type"),
        NamespaceDeclaration: OK("namespace"),
        VariableDefinition(OO, KO) {
          OO.matchContext(KK) || KO(OO, "variable")
        },
        TypeDefinition(OO, KO) {
          KO(OO, "type")
        },
        __proto__: null
      };

    function XK(OO, KO) {
      let pO = kK.get(KO);
      if (pO) return pO;
      let bK = [],
        eO = !0;

      function lO(KO, pO) {
        let XO = OO.sliceString(KO.from, KO.to);
        bK.push({
          label: XO,
          type: pO
        })
      }
      return KO.cursor(XO.f.IncludeAnonymous).iterate((KO => {
        if (eO) eO = !1;
        else if (KO.name) {
          let OO = pK[KO.name];
          if (OO && OO(KO, lO) || UO.has(KO.name)) return !1
        } else if (KO.to - KO.from > 8192) {
          for (let pO of XK(OO, KO.node)) bK.push(pO);
          return !1
        }
      })), kK.set(KO, bK), bK
    }
    const bp = /^[\w$\xa1-\uffff][\w$\d\xa1-\uffff]*$/,
      eK = ["TemplateString", "String", "RegExp", "LineComment", "BlockComment", "VariableDefinition", "TypeDefinition", "Label", "PropertyDefinition", "PropertyName", "PrivatePropertyDefinition", "PrivatePropertyName", "JSXText", "JSXAttributeValue", "JSXOpenTag", "JSXCloseTag", "JSXSelfClosingTag", ".", "?."];

    function lK(OO) {
      let KO = (0, GO.ib)(OO.state).resolveInner(OO.pos, -1);
      if (eK.indexOf(KO.name) > -1) return null;
      let pO = "VariableName" == KO.name || KO.to - KO.from < 20 && bp.test(OO.state.sliceDoc(KO.from, KO.to));
      if (!pO && !OO.explicit) return null;
      let XO = [];
      for (let bK = KO; bK; bK = bK.parent) UO.has(bK.name) && (XO = XO.concat(XK(OO.state.doc, bK)));
      return {
        options: XO,
        from: pO ? KO.from : OO.pos,
        validFor: bp
      }
    }
    const vp = GO.g.define({
        name: "javascript",
        parser: ZO.configure({
          props: [GO.Q.add({
            IfStatement: (0, GO.n)({
              except: /^\s*({|else\b)/
            }),
            TryStatement: (0, GO.n)({
              except: /^\s*({|catch\b|finally\b)/
            }),
            LabeledStatement: GO.y,
            SwitchBody: OO => {
              let KO = OO.textAfter,
                pO = /^\s*\}/.test(KO),
                XO = /^\s*(case|default)\b/.test(KO);
              return OO.baseIndent + (pO ? 0 : XO ? 1 : 2) * OO.unit
            },
            Block: (0, GO.u)({
              closing: "}"
            }),
            ArrowFunction: OO => OO.baseIndent + OO.unit,
            "TemplateString BlockComment": () => null,
            "Statement Property": (0, GO.n)({
              except: /^\s*{/
            }),
            JSXElement(OO) {
              let KO = /^\s*<\//.test(OO.textAfter);
              return OO.lineIndent(OO.node.from) + (KO ? 0 : OO.unit)
            },
            JSXEscape(OO) {
              let KO = /\s*\}/.test(OO.textAfter);
              return OO.lineIndent(OO.node.from) + (KO ? 0 : OO.unit)
            },
            "JSXOpenTag JSXSelfClosingTag": OO => OO.column(OO.node.from) + OO.unit
          }), GO.J.add({
            "Block ClassBody SwitchBody EnumBody ObjectExpression ArrayExpression ObjectType": GO.D,
            BlockComment: OO => ({
              from: OO.from + 2,
              to: OO.to - 2
            }),
            JSXElement(OO) {
              let KO = OO.firstChild;
              if (!KO || "JSXSelfClosingTag" == KO.name) return null;
              let pO = OO.lastChild;
              return {
                from: KO.to,
                to: pO.type.isError ? OO.to : pO.from
              }
            },
            "JSXSelfClosingTag JSXOpenTag"(OO) {
              var KO;
              let pO = null === (KO = OO.firstChild) || void 0 === KO ? void 0 : KO.nextSibling,
                XO = OO.lastChild;
              return !pO || pO.type.isError ? null : {
                from: pO.to,
                to: XO.type.isError ? OO.to : XO.from
              }
            }
          })]
        }),
        languageData: {
          closeBrackets: {
            brackets: ["(", "[", "{", "'", '"', "`"]
          },
          commentTokens: {
            line: "//",
            block: {
              open: "/*",
              close: "*/"
            }
          },
          indentOnInput: /^\s*(?:case |default:|\{|\}|<\/)$/,
          wordChars: "$"
        }
      }),
      CK = {
        test: OO => /^JSX/.test(OO.name),
        facet: (0, GO.r)({
          commentTokens: {
            block: {
              open: "{/*",
              close: "*/}"
            }
          }
        })
      },
      hK = vp.configure({
        dialect: "ts"
      }, "typescript"),
      DK = vp.configure({
        dialect: "jsx",
        props: [GO.ab.add((OO => OO.isTop ? [CK] : void 0))]
      }),
      MK = vp.configure({
        dialect: "jsx ts",
        props: [GO.ab.add((OO => OO.isTop ? [CK] : void 0))]
      }, "typescript");
    let ap = OO => ({
      label: OO,
      type: "keyword"
    });
    const oK = "break case const continue default delete export extends false finally in instanceof let new return static super switch this throw true typeof var yield".split(" ").map(ap),
      FK = oK.concat(["declare", "implements", "private", "protected", "public"].map(ap));

    function VK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        KO = OO.jsx ? OO.typescript ? MK : DK : OO.typescript ? hK : vp,
        pO = OO.typescript ? tK.concat(FK) : WO.concat(oK);
      return new GO.i(KO, [vp.data.of({
        autocomplete: (0, nO.o)(eK, (0, nO.j)(pO))
      }), vp.data.of({
        autocomplete: lK
      }), OO.jsx ? zp : []])
    }

    function LK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : OO.length;
      for (let XO = null === KO || void 0 === KO ? void 0 : KO.firstChild; XO; XO = XO.nextSibling)
        if ("JSXIdentifier" == XO.name || "JSXBuiltin" == XO.name || "JSXNamespacedName" == XO.name || "JSXMemberExpression" == XO.name) return OO.sliceString(XO.from, Math.min(XO.to, pO));
      return ""
    }
    const QK = "object" == typeof navigator && /Android\b/.test(navigator.userAgent),
      zp = xK.h.inputHandler.of(((OO, KO, pO, XO, bK) => {
        if ((QK ? OO.composing : OO.compositionStarted) || OO.state.readOnly || KO != pO || ">" != XO && "/" != XO || !vp.isActiveAt(OO.state, KO, -1)) return !1;
        let eO = bK(),
          {
            state: lO
          } = eO,
          vK = lO.changeByRange((OO => {
            var KO;
            let pO, {
                head: bK
              } = OO,
              eO = (0, GO.ib)(lO).resolveInner(bK - 1, -1);
            if ("JSXStartTag" == eO.name && (eO = eO.parent), lO.doc.sliceString(bK - 1, bK) != XO || "JSXAttributeValue" == eO.name && eO.to > bK);
            else {
              if (">" == XO && "JSXFragmentTag" == eO.name) return {
                range: OO,
                changes: {
                  from: bK,
                  insert: "</>"
                }
              };
              if ("/" == XO && "JSXStartCloseTag" == eO.name) {
                let OO = eO.parent,
                  XO = OO.parent;
                if (XO && OO.from == bK - 2 && ((pO = LK(lO.doc, XO.firstChild, bK)) || "JSXFragmentTag" == (null === (KO = XO.firstChild) || void 0 === KO ? void 0 : KO.name))) {
                  let OO = `${pO}>`;
                  return {
                    range: qK.j.cursor(bK + OO.length, -1),
                    changes: {
                      from: bK,
                      insert: OO
                    }
                  }
                }
              } else if (">" == XO) {
                let KO = function(OO) {
                  for (;;) {
                    if ("JSXOpenTag" == OO.name || "JSXSelfClosingTag" == OO.name || "JSXFragmentTag" == OO.name) return OO;
                    if ("JSXEscape" == OO.name || !OO.parent) return null;
                    OO = OO.parent
                  }
                }(eO);
                if (KO && "JSXOpenTag" == KO.name && !/^\/?>|^<\//.test(lO.doc.sliceString(bK, bK + 2)) && (pO = LK(lO.doc, KO, bK))) return {
                  range: OO,
                  changes: {
                    from: bK,
                    insert: `</${pO}>`
                  }
                }
              }
            }
            return {
              range: OO
            }
          }));
        return !vK.changes.empty && (OO.dispatch([eO, lO.update(vK, {
          userEvent: "input.complete",
          scrollIntoView: !0
        })]), !0)
      }))
  },
  39347: (OO, KO, pO) => {
    pO.d(KO, {
      D: () => WO,
      G: () => hK,
      J: () => nO,
      K: () => QO,
      L: () => YO,
      M: () => iK,
      Q: () => PO,
      S: () => qK,
      T: () => wO,
      W: () => jK,
      _: () => cp,
      ab: () => MO,
      d: () => fK,
      e: () => rK,
      eb: () => IK,
      g: () => FO,
      gb: () => LO,
      i: () => uO,
      ib: () => VO,
      k: () => HK,
      n: () => ZO,
      o: () => uK,
      r: () => DO,
      u: () => JO,
      y: () => BO,
      z: () => zp
    });
    var XO, bK = pO(39350),
      eO = pO(39338),
      lO = pO(39341),
      vK = pO(39358),
      CO = pO(39343);
    const hO = new bK.i;

    function DO(OO) {
      return eO.n.define({
        combine: OO ? KO => KO.concat(OO) : void 0
      })
    }
    const MO = new bK.i;
    class aK {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [],
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
        this.data = OO, this.name = XO, eO.m.prototype.hasOwnProperty("tree") || Object.defineProperty(eO.m.prototype, "tree", {
          get() {
            return VO(this)
          }
        }), this.parser = KO, this.extension = [gK.of(this), eO.m.languageData.of(((OO, KO, pO) => {
          let XO = oO(OO, KO, pO),
            bK = XO.type.prop(hO);
          if (!bK) return [];
          let eO = OO.facet(bK),
            lO = XO.type.prop(MO);
          if (lO) {
            let bK = XO.resolve(KO - XO.from, pO);
            for (let KO of lO)
              if (KO.test(bK, OO)) {
                let pO = OO.facet(KO.facet);
                return "replace" == KO.type ? pO : pO.concat(eO)
              }
          }
          return eO
        }))].concat(pO)
      }
      isActiveAt(OO, KO) {
        return oO(OO, KO, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : -1).type.prop(hO) == this.data
      }
      findRegions(OO) {
        let KO = OO.facet(gK);
        if ((null === KO || void 0 === KO ? void 0 : KO.data) == this.data) return [{
          from: 0,
          to: OO.doc.length
        }];
        if (!KO || !KO.allowsNesting) return [];
        let pO = [],
          XO = (OO, KO) => {
            if (OO.prop(hO) == this.data) return void pO.push({
              from: KO,
              to: KO + OO.length
            });
            let eO = OO.prop(bK.i.mounted);
            if (eO) {
              if (eO.tree.prop(hO) == this.data) {
                if (eO.overlay)
                  for (let OO of eO.overlay) pO.push({
                    from: OO.from + KO,
                    to: OO.to + KO
                  });
                else pO.push({
                  from: KO,
                  to: KO + OO.length
                });
                return
              }
              if (eO.overlay) {
                let OO = pO.length;
                if (XO(eO.tree, eO.overlay[0].from + KO), pO.length > OO) return
              }
            }
            for (let pO = 0; pO < OO.children.length; pO++) {
              let eO = OO.children[pO];
              eO instanceof bK.B && XO(eO, OO.positions[pO] + KO)
            }
          };
        return XO(VO(OO), 0), pO
      }
      get allowsNesting() {
        return !0
      }
    }

    function oO(OO, KO, pO) {
      let XO = OO.facet(gK),
        eO = VO(OO).topNode;
      if (!XO || XO.allowsNesting)
        for (let lO = eO; lO; lO = lO.enter(KO, pO, bK.f.ExcludeBuffers | bK.f.EnterBracketed)) lO.type.isTop && (eO = lO);
      return eO
    }
    aK.setState = eO.C.define();
    class FO extends aK {
      constructor(OO, KO, pO) {
        super(OO, KO, [], pO), this.parser = KO
      }
      static define(OO) {
        let KO = DO(OO.languageData);
        return new FO(KO, OO.parser.configure({
          props: [hO.add((OO => OO.isTop ? KO : void 0))]
        }), OO.name)
      }
      configure(OO, KO) {
        return new FO(this.data, this.parser.configure(OO), KO || this.name)
      }
      get allowsNesting() {
        return this.parser.hasWrappers()
      }
    }

    function VO(OO) {
      let KO = OO.field(aK.state, !1);
      return KO ? KO.tree : bK.B.empty
    }

    function LO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO.doc.length;
      var pO;
      return (null === (pO = OO.field(aK.state, !1)) || void 0 === pO ? void 0 : pO.context.isDone(KO)) || !1
    }

    function QO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO.viewport.to,
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 100,
        XO = function(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 50;
          var XO;
          let bK = null === (XO = OO.field(aK.state, !1)) || void 0 === XO ? void 0 : XO.context;
          if (!bK) return null;
          let eO = bK.viewport;
          bK.updateViewport({
            from: 0,
            to: KO
          });
          let lO = bK.isDone(KO) || bK.work(pO, KO) ? bK.tree : null;
          return bK.updateViewport(eO), lO
        }(OO.state, KO, pO);
      return XO != VO(OO.state) && OO.dispatch({}), !!XO
    }
    class zK {
      constructor(OO) {
        this.doc = OO, this.cursorPos = 0, this.string = "", this.cursor = OO.iter()
      }
      get length() {
        return this.doc.length
      }
      syncTo(OO) {
        return this.string = this.cursor.next(OO - this.cursorPos).value, this.cursorPos = OO + this.string.length, this.cursorPos - this.string.length
      }
      chunk(OO) {
        return this.syncTo(OO), this.string
      }
      get lineChunks() {
        return !0
      }
      read(OO, KO) {
        let pO = this.cursorPos - this.string.length;
        return OO < pO || KO >= this.cursorPos ? this.doc.sliceString(OO, KO) : this.string.slice(OO - pO, KO - pO)
      }
    }
    let AO = null;
    class fO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [],
          XO = arguments.length > 3 ? arguments[3] : void 0,
          bK = arguments.length > 4 ? arguments[4] : void 0,
          eO = arguments.length > 5 ? arguments[5] : void 0,
          lO = arguments.length > 6 ? arguments[6] : void 0,
          vK = arguments.length > 7 ? arguments[7] : void 0;
        this.parser = OO, this.state = KO, this.fragments = pO, this.tree = XO, this.treeLen = bK, this.viewport = eO, this.skipped = lO, this.scheduleOn = vK, this.parse = null, this.tempSkipped = []
      }
      static create(OO, KO, pO) {
        return new fO(OO, KO, [], bK.B.empty, 0, pO, [], null)
      }
      startParse() {
        return this.parser.startParse(new zK(this.state.doc), this.fragments)
      }
      work(OO, KO) {
        return null != KO && KO >= this.state.doc.length && (KO = void 0), this.tree != bK.B.empty && this.isDone(null !== KO && void 0 !== KO ? KO : this.state.doc.length) ? (this.takeTree(), !0) : this.withContext((() => {
          var pO;
          if ("number" == typeof OO) {
            let KO = Date.now() + OO;
            OO = () => Date.now() > KO
          }
          for (this.parse || (this.parse = this.startParse()), null != KO && (null == this.parse.stoppedAt || this.parse.stoppedAt > KO) && KO < this.state.doc.length && this.parse.stopAt(KO);;) {
            let XO = this.parse.advance();
            if (XO) {
              if (this.fragments = this.withoutTempSkipped(bK.y.addTree(XO, this.fragments, null != this.parse.stoppedAt)), this.treeLen = null !== (pO = this.parse.stoppedAt) && void 0 !== pO ? pO : this.state.doc.length, this.tree = XO, this.parse = null, !(this.treeLen < (null !== KO && void 0 !== KO ? KO : this.state.doc.length))) return !0;
              this.parse = this.startParse()
            }
            if (OO()) return !1
          }
        }))
      }
      takeTree() {
        let OO, KO;
        this.parse && (OO = this.parse.parsedPos) >= this.treeLen && ((null == this.parse.stoppedAt || this.parse.stoppedAt > OO) && this.parse.stopAt(OO), this.withContext((() => {
          for (; !(KO = this.parse.advance()););
        })), this.treeLen = OO, this.tree = KO, this.fragments = this.withoutTempSkipped(bK.y.addTree(this.tree, this.fragments, !0)), this.parse = null)
      }
      withContext(OO) {
        let KO = AO;
        AO = this;
        try {
          return OO()
        } finally {
          AO = KO
        }
      }
      withoutTempSkipped(OO) {
        for (let KO; KO = this.tempSkipped.pop();) OO = dO(OO, KO.from, KO.to);
        return OO
      }
      changes(OO, KO) {
        let {
          fragments: pO,
          tree: XO,
          treeLen: eO,
          viewport: lO,
          skipped: vK
        } = this;
        if (this.takeTree(), !OO.empty) {
          let KO = [];
          if (OO.iterChangedRanges(((OO, pO, XO, bK) => KO.push({
              fromA: OO,
              toA: pO,
              fromB: XO,
              toB: bK
            }))), pO = bK.y.applyChanges(pO, KO), XO = bK.B.empty, eO = 0, lO = {
              from: OO.mapPos(lO.from, -1),
              to: OO.mapPos(lO.to, 1)
            }, this.skipped.length) {
            vK = [];
            for (let KO of this.skipped) {
              let pO = OO.mapPos(KO.from, 1),
                XO = OO.mapPos(KO.to, -1);
              pO < XO && vK.push({
                from: pO,
                to: XO
              })
            }
          }
        }
        return new fO(this.parser, KO, pO, XO, eO, lO, vK, this.scheduleOn)
      }
      updateViewport(OO) {
        if (this.viewport.from == OO.from && this.viewport.to == OO.to) return !1;
        this.viewport = OO;
        let KO = this.skipped.length;
        for (let pO = 0; pO < this.skipped.length; pO++) {
          let {
            from: KO,
            to: XO
          } = this.skipped[pO];
          KO < OO.to && XO > OO.from && (this.fragments = dO(this.fragments, KO, XO), this.skipped.splice(pO--, 1))
        }
        return !(this.skipped.length >= KO) && (this.reset(), !0)
      }
      reset() {
        this.parse && (this.takeTree(), this.parse = null)
      }
      skipUntilInView(OO, KO) {
        this.skipped.push({
          from: OO,
          to: KO
        })
      }
      static getSkippingParser(OO) {
        return new class extends bK.v {
          createParse(KO, pO, XO) {
            let eO = XO[0].from,
              lO = XO[XO.length - 1].to;
            return {
              parsedPos: eO,
              advance() {
                let KO = AO;
                if (KO) {
                  for (let OO of XO) KO.tempSkipped.push(OO);
                  OO && (KO.scheduleOn = KO.scheduleOn ? Promise.all([KO.scheduleOn, OO]) : OO)
                }
                return this.parsedPos = lO, new bK.B(bK.q.none, [], [], lO - eO)
              },
              stoppedAt: null,
              stopAt() {}
            }
          }
        }
      }
      isDone(OO) {
        OO = Math.min(OO, this.state.doc.length);
        let KO = this.fragments;
        return this.treeLen >= OO && KO.length && 0 == KO[0].from && KO[0].to >= OO
      }
      static get() {
        return AO
      }
    }

    function dO(OO, KO, pO) {
      return bK.y.applyChanges(OO, [{
        fromA: KO,
        toA: pO,
        fromB: KO,
        toB: pO
      }])
    }
    class TO {
      constructor(OO) {
        this.context = OO, this.tree = OO.tree
      }
      apply(OO) {
        if (!OO.docChanged && this.tree == this.context.tree) return this;
        let KO = this.context.changes(OO.changes, OO.state),
          pO = this.context.treeLen == OO.startState.doc.length ? void 0 : Math.max(OO.changes.mapPos(this.context.treeLen), KO.viewport.to);
        return KO.work(20, pO) || KO.takeTree(), new TO(KO)
      }
      static init(OO) {
        let KO = Math.min(3e3, OO.doc.length),
          pO = fO.create(OO.facet(gK).parser, OO, {
            from: 0,
            to: KO
          });
        return pO.work(20, KO) || pO.takeTree(), new TO(pO)
      }
    }
    aK.state = eO.G.define({
      create: TO.init,
      update(OO, KO) {
        for (let pO of KO.effects)
          if (pO.is(aK.setState)) return pO.value;
        return KO.startState.facet(gK) != KO.state.facet(gK) ? TO.init(KO.state) : OO.apply(KO)
      }
    });
    let NO = OO => {
      let KO = setTimeout((() => OO()), 500);
      return () => clearTimeout(KO)
    };
    "undefined" != typeof requestIdleCallback && (NO = OO => {
      let KO = -1,
        pO = setTimeout((() => {
          KO = requestIdleCallback(OO, {
            timeout: 400
          })
        }), 100);
      return () => KO < 0 ? clearTimeout(pO) : cancelIdleCallback(KO)
    });
    const IO = "undefined" != typeof navigator && (null === (XO = navigator.scheduling) || void 0 === XO ? void 0 : XO.isInputPending) ? () => navigator.scheduling.isInputPending() : null,
      yK = lO.l.fromClass(class {
        constructor(OO) {
          this.view = OO, this.working = null, this.workScheduled = 0, this.chunkEnd = -1, this.chunkBudget = -1, this.work = this.work.bind(this), this.scheduleWork()
        }
        update(OO) {
          let KO = this.view.state.field(aK.state).context;
          (KO.updateViewport(OO.view.viewport) || this.view.viewport.to > KO.treeLen) && this.scheduleWork(), (OO.docChanged || OO.selectionSet) && (this.view.hasFocus && (this.chunkBudget += 50), this.scheduleWork()), this.checkAsyncSchedule(KO)
        }
        scheduleWork() {
          if (this.working) return;
          let {
            state: OO
          } = this.view, KO = OO.field(aK.state);
          KO.tree == KO.context.tree && KO.context.isDone(OO.doc.length) || (this.working = NO(this.work))
        }
        work(OO) {
          this.working = null;
          let KO = Date.now();
          if (this.chunkEnd < KO && (this.chunkEnd < 0 || this.view.hasFocus) && (this.chunkEnd = KO + 3e4, this.chunkBudget = 3e3), this.chunkBudget <= 0) return;
          let {
            state: pO,
            viewport: {
              to: XO
            }
          } = this.view, bK = pO.field(aK.state);
          if (bK.tree == bK.context.tree && bK.context.isDone(XO + 1e5)) return;
          let eO = Date.now() + Math.min(this.chunkBudget, 100, OO && !IO ? Math.max(25, OO.timeRemaining() - 5) : 1e9),
            lO = bK.context.treeLen < XO && pO.doc.length > XO + 1e3,
            vK = bK.context.work((() => IO && IO() || Date.now() > eO), XO + (lO ? 0 : 1e5));
          this.chunkBudget -= Date.now() - KO, (vK || this.chunkBudget <= 0) && (bK.context.takeTree(), this.view.dispatch({
            effects: aK.setState.of(new TO(bK.context))
          })), this.chunkBudget > 0 && (!vK || lO) && this.scheduleWork(), this.checkAsyncSchedule(bK.context)
        }
        checkAsyncSchedule(OO) {
          OO.scheduleOn && (this.workScheduled++, OO.scheduleOn.then((() => this.scheduleWork())).catch((OO => (0, lO.S)(this.view.state, OO))).then((() => this.workScheduled--)), OO.scheduleOn = null)
        }
        destroy() {
          this.working && this.working()
        }
        isWorking() {
          return !!(this.working || this.workScheduled > 0)
        }
      }, {
        eventHandlers: {
          focus() {
            this.scheduleWork()
          }
        }
      }),
      gK = eO.n.define({
        combine: OO => OO.length ? OO[0] : null,
        enables: OO => [aK.state, yK, lO.h.contentAttributes.compute([OO], (KO => {
          let pO = KO.facet(OO);
          return pO && pO.name ? {
            "data-language": pO.name
          } : {}
        }))]
      });
    class uO {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
        this.language = OO, this.support = KO, this.extension = [OO, KO]
      }
    }
    const EO = eO.n.define(),
      jK = eO.n.define({
        combine: OO => {
          if (!OO.length) return "  ";
          let KO = OO[0];
          if (!KO || /\S/.test(KO) || Array.from(KO).some((OO => OO != KO[0]))) throw new Error("Invalid indent unit: " + JSON.stringify(OO[0]));
          return KO
        }
      });

    function YO(OO) {
      let KO = OO.facet(jK);
      return 9 == KO.charCodeAt(0) ? OO.tabSize * KO.length : KO.length
    }

    function wO(OO, KO) {
      let pO = "",
        XO = OO.tabSize,
        bK = OO.facet(jK)[0];
      if ("\t" == bK) {
        for (; KO >= XO;) pO += "\t", KO -= XO;
        bK = " "
      }
      for (let eO = 0; eO < KO; eO++) pO += bK;
      return pO
    }

    function iK(OO, KO) {
      OO instanceof eO.m && (OO = new rK(OO));
      for (let XO of OO.state.facet(EO)) {
        let pO = XO(OO, KO);
        if (void 0 !== pO) return pO
      }
      let pO = VO(OO.state);
      return pO.length >= KO ? function(OO, KO, pO) {
        let XO = KO.resolveStack(pO),
          bK = KO.resolveInner(pO, -1).resolve(pO, 0).enterUnfinishedNodesBefore(pO);
        if (bK != XO.node) {
          let OO = [];
          for (let KO = bK; KO && !(KO.from < XO.node.from || KO.to > XO.node.to || KO.from == XO.node.from && KO.type == XO.node.type); KO = KO.parent) OO.push(KO);
          for (let KO = OO.length - 1; KO >= 0; KO--) XO = {
            node: OO[KO],
            next: XO
          }
        }
        return mK(XO, OO, pO)
      }(OO, pO, KO) : null
    }
    class rK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        this.state = OO, this.options = KO, this.unit = YO(OO)
      }
      lineAt(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = this.state.doc.lineAt(OO),
          {
            simulateBreak: XO,
            simulateDoubleBreak: bK
          } = this.options;
        return null != XO && XO >= pO.from && XO <= pO.to ? bK && XO == OO ? {
          text: "",
          from: OO
        } : (KO < 0 ? XO < OO : XO <= OO) ? {
          text: pO.text.slice(XO - pO.from),
          from: XO
        } : {
          text: pO.text.slice(0, XO - pO.from),
          from: pO.from
        } : pO
      }
      textAfterPos(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        if (this.options.simulateDoubleBreak && OO == this.options.simulateBreak) return "";
        let {
          text: pO,
          from: XO
        } = this.lineAt(OO, KO);
        return pO.slice(OO - XO, Math.min(pO.length, OO + 100 - XO))
      }
      column(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          {
            text: pO,
            from: XO
          } = this.lineAt(OO, KO),
          bK = this.countColumn(pO, OO - XO),
          eO = this.options.overrideIndentation ? this.options.overrideIndentation(XO) : -1;
        return eO > -1 && (bK += eO - this.countColumn(pO, pO.search(/\S|$/))), bK
      }
      countColumn(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO.length;
        return (0, eO.U)(OO, this.state.tabSize, KO)
      }
      lineIndent(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          {
            text: pO,
            from: XO
          } = this.lineAt(OO, KO),
          bK = this.options.overrideIndentation;
        if (bK) {
          let OO = bK(XO);
          if (OO > -1) return OO
        }
        return this.countColumn(pO, pO.search(/\S|$/))
      }
      get simulatedBreak() {
        return this.options.simulateBreak || null
      }
    }
    const PO = new bK.i;

    function mK(OO, KO, pO) {
      for (let XO = OO; XO; XO = XO.next) {
        let OO = sO(XO.node);
        if (OO) return OO(RO.create(KO, pO, XO))
      }
      return 0
    }

    function sO(OO) {
      let KO = OO.type.prop(PO);
      if (KO) return KO;
      let pO, XO = OO.firstChild;
      if (XO && (pO = XO.type.prop(bK.i.closedBy))) {
        let KO = OO.lastChild,
          XO = KO && pO.indexOf(KO.name) > -1;
        return OO => cK(OO, !0, 1, void 0, XO && ! function(OO) {
          return OO.pos == OO.options.simulateBreak && OO.options.simulateDoubleBreak
        }(OO) ? KO.from : void 0)
      }
      return null == OO.parent ? HO : null
    }

    function HO() {
      return 0
    }
    class RO extends rK {
      constructor(OO, KO, pO) {
        super(OO.state, OO.options), this.base = OO, this.pos = KO, this.context = pO
      }
      get node() {
        return this.context.node
      }
      static create(OO, KO, pO) {
        return new RO(OO, KO, pO)
      }
      get textAfter() {
        return this.textAfterPos(this.pos)
      }
      get baseIndent() {
        return this.baseIndentFor(this.node)
      }
      baseIndentFor(OO) {
        let KO = this.state.doc.lineAt(OO.from);
        for (;;) {
          let pO = OO.resolve(KO.from);
          for (; pO.parent && pO.parent.from == pO.from;) pO = pO.parent;
          if (SO(pO, OO)) break;
          KO = this.state.doc.lineAt(pO.from)
        }
        return this.lineIndent(KO.from)
      }
      continue () {
        return mK(this.context.next, this.base, this.pos)
      }
    }

    function SO(OO, KO) {
      for (let pO = KO; pO; pO = pO.parent)
        if (OO == pO) return !0;
      return !1
    }

    function JO(OO) {
      let {
        closing: KO,
        align: pO = !0,
        units: XO = 1
      } = OO;
      return OO => cK(OO, pO, XO, KO)
    }

    function cK(OO, KO, pO, XO, bK) {
      let eO = OO.textAfter,
        lO = eO.match(/^\s*/)[0].length,
        vK = XO && eO.slice(lO, lO + XO.length) == XO || bK == OO.pos + lO,
        CO = KO ? function(OO) {
          let KO = OO.node,
            pO = KO.childAfter(KO.from),
            XO = KO.lastChild;
          if (!pO) return null;
          let bK = OO.options.simulateBreak,
            eO = OO.state.doc.lineAt(pO.from),
            lO = null == bK || bK <= eO.from ? eO.to : Math.min(eO.to, bK);
          for (let vK = pO.to;;) {
            let OO = KO.childAfter(vK);
            if (!OO || OO == XO) return null;
            if (!OO.type.isSkipped) {
              if (OO.from >= lO) return null;
              let KO = /^ */.exec(eO.text.slice(pO.to - eO.from))[0].length;
              return {
                from: pO.from,
                to: pO.to + KO
              }
            }
            vK = OO.to
          }
        }(OO) : null;
      return CO ? vK ? OO.column(CO.from) : OO.column(CO.to) : OO.baseIndent + (vK ? 0 : OO.unit * pO)
    }
    const BO = OO => OO.baseIndent;

    function ZO() {
      let {
        except: OO,
        units: KO = 1
      } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      return pO => {
        let XO = OO && OO.test(pO.textAfter);
        return pO.baseIndent + (XO ? 0 : KO * pO.unit)
      }
    }
    const GO = 200;

    function qK() {
      return eO.m.transactionFilter.of((OO => {
        if (!OO.docChanged || !OO.isUserEvent("input.type") && !OO.isUserEvent("input.complete")) return OO;
        let KO = OO.startState.languageDataAt("indentOnInput", OO.startState.selection.main.head);
        if (!KO.length) return OO;
        let pO = OO.newDoc,
          {
            head: XO
          } = OO.newSelection.main,
          bK = pO.lineAt(XO);
        if (XO > bK.from + GO) return OO;
        let eO = pO.sliceString(bK.from, XO);
        if (!KO.some((OO => OO.test(eO)))) return OO;
        let {
          state: lO
        } = OO, vK = -1, CO = [];
        for (let {
            head: hO
          }
          of lO.selection.Xl) {
          let OO = lO.doc.lineAt(hO);
          if (OO.from == vK) continue;
          vK = OO.from;
          let KO = iK(lO, OO.from);
          if (null == KO) continue;
          let pO = /^\s*/.exec(OO.text)[0],
            XO = wO(lO, KO);
          pO != XO && CO.push({
            from: OO.from,
            to: OO.from + pO.length,
            insert: XO
          })
        }
        return CO.length ? [OO, {
          changes: CO,
          sequential: !0
        }] : OO
      }))
    }
    const xK = eO.n.define(),
      nO = new bK.i;

    function WO(OO) {
      let KO = OO.firstChild,
        pO = OO.lastChild;
      return KO && KO.to < pO.from ? {
        from: KO.to,
        to: pO.type.isError ? OO.to : pO.from
      } : null
    }

    function tK(OO) {
      let KO = OO.lastChild;
      return KO && KO.to == OO.to && KO.type.isError
    }

    function kK(OO, KO, pO) {
      for (let XO of OO.facet(xK)) {
        let bK = XO(OO, KO, pO);
        if (bK) return bK
      }
      return function(OO, KO, pO) {
        let XO = VO(OO);
        if (XO.length < pO) return null;
        let bK = null;
        for (let eO = XO.resolveStack(pO, 1); eO; eO = eO.next) {
          let lO = eO.node;
          if (lO.to <= pO || lO.from > pO) continue;
          if (bK && lO.from < KO) break;
          let vK = lO.type.prop(nO);
          if (vK && (lO.to < XO.length - 50 || XO.length == OO.doc.length || !tK(lO))) {
            let XO = vK(lO, OO);
            XO && XO.from <= pO && XO.from >= KO && XO.to > pO && (bK = XO)
          }
        }
        return bK
      }(OO, KO, pO)
    }

    function UO(OO, KO) {
      let pO = KO.mapPos(OO.from, 1),
        XO = KO.mapPos(OO.to, -1);
      return pO >= XO ? void 0 : {
        from: pO,
        to: XO
      }
    }
    const OK = eO.C.define({
        map: UO
      }),
      KK = eO.C.define({
        map: UO
      });

    function pK(OO) {
      let KO = [];
      for (let {
          head: pO
        }
        of OO.state.selection.Xl) KO.some((OO => OO.from <= pO && OO.to >= pO)) || KO.push(OO.lineBlockAt(pO));
      return KO
    }
    const XK = eO.G.define({
      create: () => lO.c.none,
      update(OO, KO) {
        KO.isUserEvent("delete") && KO.changes.iterChangedRanges(((KO, pO) => OO = bp(OO, KO, pO))), OO = OO.map(KO.changes);
        for (let pO of KO.effects)
          if (pO.is(OK) && !lK(OO, pO.value.from, pO.value.to)) {
            let {
              preparePlaceholder: XO
            } = KO.state.facet(MK), bK = XO ? lO.c.replace({
              widget: new VK(XO(KO.state, pO.value))
            }) : FK;
            OO = OO.update({
              add: [bK.range(pO.value.from, pO.value.to)]
            })
          } else pO.is(KK) && (OO = OO.update({
            filter: (OO, KO) => pO.value.from != OO || pO.value.to != KO,
            filterFrom: pO.value.from,
            filterTo: pO.value.to
          }));
        return KO.selection && (OO = bp(OO, KO.selection.main.head)), OO
      },
      provide: OO => lO.h.ql.from(OO),
      toJSON(OO, KO) {
        let pO = [];
        return OO.between(0, KO.doc.length, ((OO, KO) => {
          pO.push(OO, KO)
        })), pO
      },
      fromJSON(OO) {
        if (!Array.isArray(OO) || OO.length % 2) throw new RangeError("Invalid JSON for fold state");
        let KO = [];
        for (let pO = 0; pO < OO.length;) {
          let XO = OO[pO++],
            bK = OO[pO++];
          if ("number" != typeof XO || "number" != typeof bK) throw new RangeError("Invalid JSON for fold state");
          KO.push(FK.range(XO, bK))
        }
        return lO.c.set(KO, !0)
      }
    });

    function bp(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : KO,
        XO = !1;
      return OO.between(KO, pO, ((OO, bK) => {
        OO < pO && bK > KO && (XO = !0)
      })), XO ? OO.update({
        filterFrom: KO,
        filterTo: pO,
        filter: (OO, XO) => OO >= pO || XO <= KO
      }) : OO
    }

    function eK(OO, KO, pO) {
      var XO;
      let bK = null;
      return null === (XO = OO.field(XK, !1)) || void 0 === XO || XO.between(KO, pO, ((OO, KO) => {
        (!bK || bK.from > OO) && (bK = {
          from: OO,
          to: KO
        })
      })), bK
    }

    function lK(OO, KO, pO) {
      let XO = !1;
      return OO.between(KO, KO, ((OO, bK) => {
        OO == KO && bK == pO && (XO = !0)
      })), XO
    }

    function vp(OO, KO) {
      return OO.field(XK, !1) ? KO : KO.concat(eO.C.appendConfig.of(ap()))
    }

    function CK(OO, KO) {
      let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
        XO = OO.state.doc.lineAt(KO.from).number,
        bK = OO.state.doc.lineAt(KO.to).number;
      return lO.h.announce.of(`${OO.state.phrase(pO?"Folded lines":"Unfolded lines")} ${XO} ${OO.state.phrase("to")} ${bK}.`)
    }
    const hK = [{
        key: "Ctrl-Shift-[",
        mac: "Cmd-Alt-[",
        run: OO => {
          for (let KO of pK(OO)) {
            let pO = kK(OO.state, KO.from, KO.to);
            if (pO) return OO.dispatch({
              effects: vp(OO.state, [OK.of(pO), CK(OO, pO)])
            }), !0
          }
          return !1
        }
      }, {
        key: "Ctrl-Shift-]",
        mac: "Cmd-Alt-]",
        run: OO => {
          if (!OO.state.field(XK, !1)) return !1;
          let KO = [];
          for (let pO of pK(OO)) {
            let XO = eK(OO.state, pO.from, pO.to);
            XO && KO.push(KK.of(XO), CK(OO, XO, !1))
          }
          return KO.length && OO.dispatch({
            effects: KO
          }), KO.length > 0
        }
      }, {
        key: "Ctrl-Alt-[",
        run: OO => {
          let {
            state: KO
          } = OO, pO = [];
          for (let XO = 0; XO < KO.doc.length;) {
            let bK = OO.lineBlockAt(XO),
              eO = kK(KO, bK.from, bK.to);
            eO && pO.push(OK.of(eO)), XO = (eO ? OO.lineBlockAt(eO.to) : bK).to + 1
          }
          return pO.length && OO.dispatch({
            effects: vp(OO.state, pO)
          }), !!pO.length
        }
      }, {
        key: "Ctrl-Alt-]",
        run: OO => {
          let KO = OO.state.field(XK, !1);
          if (!KO || !KO.size) return !1;
          let pO = [];
          return KO.between(0, OO.state.doc.length, ((OO, KO) => {
            pO.push(KK.of({
              from: OO,
              to: KO
            }))
          })), OO.dispatch({
            effects: pO
          }), !0
        }
      }],
      DK = {
        placeholderDOM: null,
        preparePlaceholder: null,
        placeholderText: "\u2026"
      },
      MK = eO.n.define({
        combine: OO => (0, eO.T)(OO, DK)
      });

    function ap(OO) {
      let KO = [XK, AK];
      return OO && KO.push(MK.of(OO)), KO
    }

    function oK(OO, KO) {
      let {
        state: pO
      } = OO, XO = pO.facet(MK), bK = KO => {
        let pO = OO.lineBlockAt(OO.posAtDOM(KO.target)),
          XO = eK(OO.state, pO.from, pO.to);
        XO && OO.dispatch({
          effects: KK.of(XO)
        }), KO.preventDefault()
      };
      if (XO.placeholderDOM) return XO.placeholderDOM(OO, bK, KO);
      let eO = document.createElement("span");
      return eO.textContent = XO.placeholderText, eO.setAttribute("aria-label", pO.phrase("folded code")), eO.title = pO.phrase("unfold"), eO.className = "cm-foldPlaceholder", eO.onclick = bK, eO
    }
    const FK = lO.c.replace({
      widget: new class extends lO.m {
        toDOM(OO) {
          return oK(OO, null)
        }
      }
    });
    class VK extends lO.m {
      constructor(OO) {
        super(), this.value = OO
      }
      eq(OO) {
        return this.value == OO.value
      }
      toDOM(OO) {
        return oK(OO, this.value)
      }
    }
    const LK = {
      openText: "\u2304",
      closedText: "\u203a",
      markerDOM: null,
      domEventHandlers: {},
      foldingChanged: () => !1
    };
    class QK extends lO.i {
      constructor(OO, KO) {
        super(), this.config = OO, this.open = KO
      }
      eq(OO) {
        return this.config == OO.config && this.open == OO.open
      }
      toDOM(OO) {
        if (this.config.markerDOM) return this.config.markerDOM(this.open);
        let KO = document.createElement("span");
        return KO.textContent = this.open ? this.config.openText : this.config.closedText, KO.title = OO.state.phrase(this.open ? "Fold line" : "Unfold line"), KO
      }
    }

    function zp() {
      let OO = {
          ...LK,
          ...arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}
        },
        KO = new QK(OO, !0),
        pO = new QK(OO, !1),
        XO = lO.l.fromClass(class {
          constructor(OO) {
            this.from = OO.viewport.from, this.markers = this.buildMarkers(OO)
          }
          update(KO) {
            (KO.docChanged || KO.viewportChanged || KO.startState.facet(gK) != KO.state.facet(gK) || KO.startState.field(XK, !1) != KO.state.field(XK, !1) || VO(KO.startState) != VO(KO.state) || OO.foldingChanged(KO)) && (this.markers = this.buildMarkers(KO.view))
          }
          buildMarkers(OO) {
            let XO = new eO.v;
            for (let bK of OO.viewportLineBlocks) {
              let eO = eK(OO.state, bK.from, bK.to) ? pO : kK(OO.state, bK.from, bK.to) ? KO : null;
              eO && XO.add(bK.from, bK.from, eO)
            }
            return XO.finish()
          }
        }),
        {
          domEventHandlers: bK
        } = OO;
      return [XO, (0, lO.C)({
        class: "cm-foldGutter",
        markers(OO) {
          var KO;
          return (null === (KO = OO.plugin(XO)) || void 0 === KO ? void 0 : KO.markers) || eO.y.empty
        },
        initialSpacer: () => new QK(OO, !1),
        domEventHandlers: {
          ...bK,
          click: (OO, KO, pO) => {
            if (bK.click && bK.click(OO, KO, pO)) return !0;
            let XO = eK(OO.state, KO.from, KO.to);
            if (XO) return OO.dispatch({
              effects: KK.of(XO)
            }), !0;
            let eO = kK(OO.state, KO.from, KO.to);
            return !!eO && (OO.dispatch({
              effects: OK.of(eO)
            }), !0)
          }
        }
      }), ap()]
    }
    const AK = lO.h.baseTheme({
      ".cm-foldPlaceholder": {
        backgroundColor: "#eee",
        border: "1px solid #ddd",
        color: "#888",
        borderRadius: ".2em",
        margin: "0 1px",
        padding: "0 1px",
        cursor: "pointer"
      },
      ".cm-foldGutter span": {
        padding: "0 1px",
        cursor: "pointer"
      }
    });
    class fK {
      constructor(OO, KO) {
        let pO;

        function XO(OO) {
          let KO = CO.e.newName();
          return (pO || (pO = Object.create(null)))["." + KO] = OO, KO
        }
        this.specs = OO;
        const bK = "string" == typeof KO.all ? KO.all : KO.all ? XO(KO.all) : void 0,
          eO = KO.scope;
        this.scope = eO instanceof aK ? OO => OO.prop(hO) == eO.data : eO ? OO => OO == eO : void 0, this.style = (0, vK.j)(OO.map((OO => ({
          tag: OO.tag,
          class: OO.class || XO(Object.assign({}, OO, {
            tag: null
          }))
        }))), {
          all: bK
        }).style, this.module = pO ? new CO.e(pO) : null, this.themeType = KO.themeType
      }
      static define(OO, KO) {
        return new fK(OO, KO || {})
      }
    }
    const dK = eO.n.define(),
      TK = eO.n.define({
        combine: OO => OO.length ? [OO[0]] : null
      });

    function NK(OO) {
      let KO = OO.facet(dK);
      return KO.length ? KO : OO.facet(TK)
    }

    function IK(OO, KO) {
      let pO, XO = [gp];
      return OO instanceof fK && (OO.module && XO.push(lO.h.styleModule.of(OO.module)), pO = OO.themeType), (null === KO || void 0 === KO ? void 0 : KO.fallback) ? XO.push(TK.of(OO)) : pO ? XO.push(dK.computeN([lO.h.darkTheme], (KO => KO.facet(lO.h.darkTheme) == ("dark" == pO) ? [OO] : []))) : XO.push(dK.of(OO)), XO
    }
    class yp {
      constructor(OO) {
        this.markCache = Object.create(null), this.tree = VO(OO.state), this.ql = this.buildDeco(OO, NK(OO.state)), this.decoratedTo = OO.viewport.to
      }
      update(OO) {
        let KO = VO(OO.state),
          pO = NK(OO.state),
          XO = pO != NK(OO.startState),
          {
            viewport: bK
          } = OO.view,
          eO = OO.changes.mapPos(this.decoratedTo, 1);
        KO.length < bK.to && !XO && KO.type == this.tree.type && eO >= bK.to ? (this.ql = this.ql.map(OO.changes), this.decoratedTo = eO) : (KO != this.tree || OO.viewportChanged || XO) && (this.tree = KO, this.ql = this.buildDeco(OO.view, pO), this.decoratedTo = bK.to)
      }
      buildDeco(OO, KO) {
        if (!KO || !this.tree.length) return lO.c.none;
        let pO = new eO.v;
        for (let {
            from: XO,
            to: bK
          }
          of OO.yvO)(0, vK.e)(this.tree, KO, ((OO, KO, XO) => {
          pO.add(OO, KO, this.markCache[XO] || (this.markCache[XO] = lO.c.mark({
            class: XO
          })))
        }), XO, bK);
        return pO.finish()
      }
    }
    const gp = eO.u.high(lO.l.fromClass(yp, {
        ql: OO => OO.ql
      })),
      uK = fK.define([{
        tag: vK.l.meta,
        color: "#404740"
      }, {
        tag: vK.l.link,
        textDecoration: "underline"
      }, {
        tag: vK.l.heading,
        textDecoration: "underline",
        fontWeight: "bold"
      }, {
        tag: vK.l.emphasis,
        fontStyle: "italic"
      }, {
        tag: vK.l.strong,
        fontWeight: "bold"
      }, {
        tag: vK.l.strikethrough,
        textDecoration: "line-through"
      }, {
        tag: vK.l.keyword,
        color: "#708"
      }, {
        tag: [vK.l.atom, vK.l.bool, vK.l.url, vK.l.contentSeparator, vK.l.labelName],
        color: "#219"
      }, {
        tag: [vK.l.literal, vK.l.inserted],
        color: "#164"
      }, {
        tag: [vK.l.string, vK.l.deleted],
        color: "#a11"
      }, {
        tag: [vK.l.regexp, vK.l.escape, vK.l.special(vK.l.string)],
        color: "#e40"
      }, {
        tag: vK.l.definition(vK.l.variableName),
        color: "#00f"
      }, {
        tag: vK.l.local(vK.l.variableName),
        color: "#30a"
      }, {
        tag: [vK.l.typeName, vK.l.namespace],
        color: "#085"
      }, {
        tag: vK.l.className,
        color: "#167"
      }, {
        tag: [vK.l.special(vK.l.variableName), vK.l.macroName],
        color: "#256"
      }, {
        tag: vK.l.definition(vK.l.propertyName),
        color: "#00c"
      }, {
        tag: vK.l.comment,
        color: "#940"
      }, {
        tag: vK.l.invalid,
        color: "#f00"
      }]),
      EK = lO.h.baseTheme({
        "&.cm-focused .cm-matchingBracket": {
          backgroundColor: "#328c8252"
        },
        "&.cm-focused .cm-nonmatchingBracket": {
          backgroundColor: "#bb555544"
        }
      }),
      jp = 1e4,
      YK = "()[]{}",
      wK = eO.n.define({
        combine: OO => (0, eO.T)(OO, {
          afterCursor: !0,
          brackets: YK,
          maxScanDistance: jp,
          renderMatch: PK
        })
      }),
      ip = lO.c.mark({
        class: "cm-matchingBracket"
      }),
      rp = lO.c.mark({
        class: "cm-nonmatchingBracket"
      });

    function PK(OO) {
      let KO = [],
        pO = OO.matched ? ip : rp;
      return KO.push(pO.range(OO.start.from, OO.start.to)), OO.end && KO.push(pO.range(OO.end.from, OO.end.to)), KO
    }

    function mp(OO) {
      let KO = [],
        pO = OO.facet(wK);
      for (let XO of OO.selection.Xl) {
        if (!XO.empty) continue;
        let bK = cp(OO, XO.head, -1, pO) || XO.head > 0 && cp(OO, XO.head - 1, 1, pO) || pO.afterCursor && (cp(OO, XO.head, 1, pO) || XO.head < OO.doc.length && cp(OO, XO.head + 1, -1, pO));
        bK && (KO = KO.concat(pO.renderMatch(bK, OO)))
      }
      return lO.c.set(KO, !0)
    }
    const sK = [lO.l.fromClass(class {
      constructor(OO) {
        this.paused = !1, this.ql = mp(OO.state)
      }
      update(OO) {
        (OO.docChanged || OO.selectionSet || this.paused) && (OO.view.composing ? (this.ql = this.ql.map(OO.changes), this.paused = !0) : (this.ql = mp(OO.state), this.paused = !1))
      }
    }, {
      ql: OO => OO.ql
    }), EK];

    function HK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      return [wK.of(OO), sK]
    }
    const RK = new bK.i;

    function SK(OO, KO, pO) {
      let XO = OO.prop(KO < 0 ? bK.i.openedBy : bK.i.closedBy);
      if (XO) return XO;
      if (1 == OO.name.length) {
        let XO = pO.indexOf(OO.name);
        if (XO > -1 && XO % 2 == (KO < 0 ? 1 : 0)) return [pO[XO + KO]]
      }
      return null
    }

    function JK(OO) {
      let KO = OO.type.prop(RK);
      return KO ? KO(OO.node) : OO
    }

    function cp(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
        bK = XO.maxScanDistance || jp,
        eO = XO.brackets || YK,
        lO = VO(OO),
        vK = lO.resolveInner(KO, pO);
      for (let CO = vK; CO; CO = CO.parent) {
        let XO = SK(CO.type, pO, eO);
        if (XO && CO.from < CO.to) {
          let bK = JK(CO);
          if (bK && (pO > 0 ? KO >= bK.from && KO < bK.to : KO > bK.from && KO <= bK.to)) return BK(OO, KO, pO, CO, bK, XO, eO)
        }
      }
      return function(OO, KO, pO, XO, bK, eO, lO) {
        if (pO < 0 ? !KO : KO == OO.doc.length) return null;
        let vK = pO < 0 ? OO.sliceDoc(KO - 1, KO) : OO.sliceDoc(KO, KO + 1),
          CO = lO.indexOf(vK);
        if (CO < 0 || CO % 2 == 0 != pO > 0) return null;
        let hO = {
            from: pO < 0 ? KO - 1 : KO,
            to: pO > 0 ? KO + 1 : KO
          },
          DO = OO.doc.iterRange(KO, pO > 0 ? OO.doc.length : 0),
          MO = 0;
        for (let aK = 0; !DO.next().done && aK <= eO;) {
          let OO = DO.value;
          pO < 0 && (aK += OO.length);
          let eO = KO + aK * pO;
          for (let KO = pO > 0 ? 0 : OO.length - 1, vK = pO > 0 ? OO.length : -1; KO != vK; KO += pO) {
            let vK = lO.indexOf(OO[KO]);
            if (!(vK < 0 || XO.resolveInner(eO + KO, 1).type != bK))
              if (vK % 2 == 0 == pO > 0) MO++;
              else {
                if (1 == MO) return {
                  start: hO,
                  end: {
                    from: eO + KO,
                    to: eO + KO + 1
                  },
                  matched: vK >> 1 == CO >> 1
                };
                MO--
              }
          }
          pO > 0 && (aK += OO.length)
        }
        return DO.done ? {
          start: hO,
          matched: !1
        } : null
      }(OO, KO, pO, lO, vK.type, bK, eO)
    }

    function BK(OO, KO, pO, XO, bK, eO, lO) {
      let vK = XO.parent,
        CO = {
          from: bK.from,
          to: bK.to
        },
        hO = 0,
        DO = null === vK || void 0 === vK ? void 0 : vK.cursor();
      if (DO && (pO < 0 ? DO.childBefore(XO.from) : DO.childAfter(XO.to)))
        do {
          if (pO < 0 ? DO.to <= XO.from : DO.from >= XO.to) {
            if (0 == hO && eO.indexOf(DO.type.name) > -1 && DO.from < DO.to) {
              let OO = JK(DO);
              return {
                start: CO,
                end: OO ? {
                  from: OO.from,
                  to: OO.to
                } : void 0,
                matched: !0
              }
            }
            if (SK(DO.type, pO, lO)) hO++;
            else if (SK(DO.type, -pO, lO)) {
              if (0 == hO) {
                let OO = JK(DO);
                return {
                  start: CO,
                  end: OO && OO.from < OO.to ? {
                    from: OO.from,
                    to: OO.to
                  } : void 0,
                  matched: !1
                }
              }
              hO--
            }
          }
        } while (pO < 0 ? DO.prevSibling() : DO.nextSibling());
      return {
        start: CO,
        matched: !1
      }
    }
    const ZK = Object.create(null),
      GK = [bK.q.none],
      qp = [],
      xp = Object.create(null),
      nK = Object.create(null);
    for (let [kp, UK] of [
        ["variable", "variableName"],
        ["variable-2", "variableName.special"],
        ["string-2", "string.special"],
        ["def", "variableName.definition"],
        ["tag", "tagName"],
        ["attribute", "attributeName"],
        ["type", "typeName"],
        ["builtin", "variableName.standard"],
        ["qualifier", "modifier"],
        ["error", "invalid"],
        ["header", "heading"],
        ["property", "propertyName"]
      ]) nK[kp] = tp(ZK, UK);

    function WK(OO, KO) {
      qp.indexOf(OO) > -1 || (qp.push(OO), console.warn(KO))
    }

    function tp(OO, KO) {
      let pO = [];
      for (let bK of KO.split(" ")) {
        let KO = [];
        for (let pO of bK.split(".")) {
          let XO = OO[pO] || vK.l[pO];
          XO ? "function" == typeof XO ? KO.length ? KO = KO.map(XO) : WK(pO, `Modifier ${pO} used at start of tag`) : KO.length ? WK(pO, `Tag ${pO} used as modifier`) : KO = Array.isArray(XO) ? XO : [XO] : WK(pO, `Unknown highlighting tag ${pO}`)
        }
        for (let OO of KO) pO.push(OO)
      }
      if (!pO.length) return 0;
      let XO = KO.replace(/ /g, "_"),
        eO = XO + " " + pO.map((OO => OO.id)),
        lO = xp[eO];
      if (lO) return lO.id;
      let CO = xp[eO] = bK.q.define({
        id: GK.length,
        name: XO,
        props: [(0, vK.h)({
          [XO]: pO
        })]
      });
      return GK.push(CO), CO.id
    }
    lO.d.RTL, lO.d.LTR
  },
  39384: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => AO,
      g: () => NO
    });
    var XO = pO(39341),
      bK = pO(39338),
      eO = pO(39345);
    class lO {
      constructor(OO, KO, pO) {
        this.from = OO, this.to = KO, this.diagnostic = pO
      }
    }
    class vK {
      constructor(OO, KO, pO) {
        this.diagnostics = OO, this.panel = KO, this.selected = pO
      }
      static init(OO, KO, pO) {
        let eO = pO.facet(dO).markerFilter;
        eO && (OO = eO(OO, pO));
        let lO = OO.slice().sort(((OO, KO) => OO.from - KO.from || OO.to - KO.to)),
          hO = new bK.v,
          DO = [],
          MO = 0,
          aK = pO.doc.iter(),
          oO = 0,
          FO = pO.doc.length;
        for (let bK = 0;;) {
          let OO, KO, pO = bK == lO.length ? null : lO[bK];
          if (!pO && !DO.length) break;
          if (DO.length) OO = MO, KO = DO.reduce(((OO, KO) => Math.min(OO, KO.to)), pO && pO.from > OO ? pO.from : 1e8);
          else {
            if (OO = pO.from, OO > FO) break;
            KO = pO.to, DO.push(pO), bK++
          }
          for (; bK < lO.length;) {
            let pO = lO[bK];
            if (pO.from != OO || !(pO.to > pO.from || pO.to == OO)) {
              KO = Math.min(pO.from, KO);
              break
            }
            DO.push(pO), bK++, KO = Math.min(pO.to, KO)
          }
          KO = Math.min(KO, FO);
          let eO = !1;
          if (DO.some((pO => pO.from == OO && (pO.to == KO || KO == FO))) && (eO = OO == KO, !eO && KO - OO < 10)) {
            let pO = OO - (oO + aK.value.length);
            pO > 0 && (aK.next(pO), oO = OO);
            for (let XO = OO;;) {
              if (XO >= KO) {
                eO = !0;
                break
              }
              if (!aK.lineBreak && oO + aK.value.length > XO) break;
              XO = oO + aK.value.length, oO += aK.value.length, aK.next()
            }
          }
          let vK = rK(DO);
          if (eO) hO.add(OO, OO, XO.c.widget({
            widget: new gK(vK),
            diagnostics: DO.slice()
          }));
          else {
            let pO = DO.reduce(((OO, KO) => KO.markClass ? OO + " " + KO.markClass : OO), "");
            hO.add(OO, KO, XO.c.mark({
              class: "cm-lintRange cm-lintRange-" + vK + pO,
              diagnostics: DO.slice(),
              inclusiveEnd: DO.some((OO => OO.to > KO))
            }))
          }
          if (MO = KO, MO == FO) break;
          for (let XO = 0; XO < DO.length; XO++) DO[XO].to <= MO && DO.splice(XO--, 1)
        }
        let VO = hO.finish();
        return new vK(VO, KO, CO(VO))
      }
    }

    function CO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
        XO = null;
      return OO.between(pO, 1e9, ((OO, pO, bK) => {
        let {
          spec: eO
        } = bK;
        if (!(KO && eO.diagnostics.indexOf(KO) < 0))
          if (XO) {
            if (eO.diagnostics.indexOf(XO.diagnostic) < 0) return !1;
            XO = new lO(XO.from, pO, XO.diagnostic)
          } else XO = new lO(OO, pO, KO || eO.diagnostics[0])
      })), XO
    }

    function hO(OO, KO) {
      let pO = KO.pos,
        XO = KO.end || pO,
        bK = OO.state.facet(dO).hideOn(OO, pO, XO);
      if (null != bK) return bK;
      let eO = OO.startState.doc.lineAt(KO.pos);
      return !(!OO.effects.some((OO => OO.is(MO))) && !OO.changes.touchesRange(eO.from, Math.max(eO.to, XO)))
    }

    function DO(OO, KO) {
      return OO.field(FO, !1) ? KO : KO.concat(bK.C.appendConfig.of(PO))
    }
    const MO = bK.C.define(),
      aK = bK.C.define(),
      oO = bK.C.define(),
      FO = bK.G.define({
        create: () => new vK(XO.c.none, null, null),
        update(OO, KO) {
          if (KO.docChanged && OO.diagnostics.size) {
            let pO = OO.diagnostics.map(KO.changes),
              XO = null,
              bK = OO.panel;
            if (OO.selected) {
              let bK = KO.changes.mapPos(OO.selected.from, 1);
              XO = CO(pO, OO.selected.diagnostic, bK) || CO(pO, null, bK)
            }!pO.size && bK && KO.state.facet(dO).autoPanel && (bK = null), OO = new vK(pO, bK, XO)
          }
          for (let pO of KO.effects)
            if (pO.is(MO)) {
              let XO = KO.state.facet(dO).autoPanel ? pO.value.length ? EO.open : null : OO.panel;
              OO = vK.init(pO.value, XO, KO.state)
            } else pO.is(aK) ? OO = new vK(OO.diagnostics, pO.value ? EO.open : null, OO.selected) : pO.is(oO) && (OO = new vK(OO.diagnostics, OO.panel, pO.value));
          return OO
        },
        provide: OO => [XO.cb.from(OO, (OO => OO.panel)), XO.h.ql.from(OO, (OO => OO.diagnostics))]
      });
    const VO = XO.c.mark({
      class: "cm-lintRange cm-lintRange-active"
    });

    function LO(OO, KO, pO) {
      let XO, {
          diagnostics: bK
        } = OO.state.field(FO),
        eO = -1,
        lO = -1;
      bK.between(KO - (pO < 0 ? 1 : 0), KO + (pO > 0 ? 1 : 0), ((OO, bK, vK) => {
        let {
          spec: CO
        } = vK;
        if (KO >= OO && KO <= bK && (OO == bK || (KO > OO || pO > 0) && (KO < bK || pO < 0))) return XO = CO.diagnostics, eO = OO, lO = bK, !1
      }));
      let vK = OO.state.facet(dO).tooltipFilter;
      return XO && vK && (XO = vK(XO, OO.state)), XO ? {
        pos: eO,
        end: lO,
        above: OO.state.doc.lineAt(eO).to < lO,
        create: () => ({
          dom: QO(OO, XO)
        })
      } : null
    }

    function QO(OO, KO) {
      return (0, eO.b)("ul", {
        class: "cm-tooltip-lint"
      }, KO.map((KO => yK(OO, KO, !1))))
    }
    const zK = OO => {
        let KO = OO.state.field(FO, !1);
        return !(!KO || !KO.panel) && (OO.dispatch({
          effects: aK.of(!1)
        }), !0)
      },
      AO = [{
        key: "Mod-Shift-m",
        run: OO => {
          let KO = OO.state.field(FO, !1);
          KO && KO.panel || OO.dispatch({
            effects: DO(OO.state, [aK.of(!0)])
          });
          let pO = (0, XO.w)(OO, EO.open);
          return pO && pO.dom.querySelector(".cm-panel-lint ul").focus(), !0
        },
        preventDefault: !0
      }, {
        key: "F8",
        run: OO => {
          let KO = OO.state.field(FO, !1);
          if (!KO) return !1;
          let pO = OO.state.selection.main,
            XO = CO(KO.diagnostics, null, pO.to + 1);
          return !(!XO && (XO = CO(KO.diagnostics, null, 0), !XO || XO.from == pO.from && XO.to == pO.to)) && (OO.dispatch({
            selection: {
              anchor: XO.from,
              head: XO.to
            },
            scrollIntoView: !0
          }), !0)
        }
      }],
      fO = XO.l.fromClass(class {
        constructor(OO) {
          this.view = OO, this.timeout = -1, this.set = !0;
          let {
            delay: KO
          } = OO.state.facet(dO);
          this.lintTime = Date.now() + KO, this.run = this.run.bind(this), this.timeout = setTimeout(this.run, KO)
        }
        run() {
          clearTimeout(this.timeout);
          let OO = Date.now();
          if (OO < this.lintTime - 10) this.timeout = setTimeout(this.run, this.lintTime - OO);
          else {
            this.set = !1;
            let {
              state: OO
            } = this.view, {
              sources: KO
            } = OO.facet(dO);
            KO.length && function(OO, KO, pO) {
              let XO = [],
                bK = -1;
              for (let eO of OO) eO.then((pO => {
                XO.push(pO), clearTimeout(bK), XO.length == OO.length ? KO(XO) : bK = setTimeout((() => KO(XO)), 200)
              }), pO)
            }(KO.map((OO => Promise.resolve(OO(this.view)))), (KO => {
              this.view.state.doc == OO.doc && this.view.dispatch(function(OO, KO) {
                return {
                  effects: DO(OO, [MO.of(KO)])
                }
              }(this.view.state, KO.reduce(((OO, KO) => OO.concat(KO)))))
            }), (OO => {
              (0, XO.S)(this.view.state, OO)
            }))
          }
        }
        update(OO) {
          let KO = OO.state.facet(dO);
          (OO.docChanged || KO != OO.startState.facet(dO) || KO.needsRefresh && KO.needsRefresh(OO)) && (this.lintTime = Date.now() + KO.delay, this.set || (this.set = !0, this.timeout = setTimeout(this.run, KO.delay)))
        }
        force() {
          this.set && (this.lintTime = Date.now(), this.run())
        }
        destroy() {
          clearTimeout(this.timeout)
        }
      });
    const dO = bK.n.define({
      combine: OO => ({
        sources: OO.map((OO => OO.source)).filter((OO => null != OO)),
        ...(0, bK.T)(OO.map((OO => OO.config)), {
          delay: 750,
          markerFilter: null,
          tooltipFilter: null,
          needsRefresh: null,
          hideOn: () => null
        }, {
          delay: Math.max,
          markerFilter: TO,
          tooltipFilter: TO,
          needsRefresh: (OO, KO) => OO ? KO ? pO => OO(pO) || KO(pO) : OO : KO,
          hideOn: (OO, KO) => OO ? KO ? (pO, XO, bK) => OO(pO, XO, bK) || KO(pO, XO, bK) : OO : KO,
          autoPanel: (OO, KO) => OO || KO
        })
      })
    });

    function TO(OO, KO) {
      return OO ? KO ? (pO, XO) => KO(OO(pO, XO), XO) : OO : KO
    }

    function NO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      return [dO.of({
        source: OO,
        config: KO
      }), fO, PO]
    }

    function IO(OO) {
      let KO = [];
      if (OO) OO: for (let {
          name: pO
        }
        of OO) {
        for (let OO = 0; OO < pO.length; OO++) {
          let XO = pO[OO];
          if (/[a-zA-Z]/.test(XO) && !KO.some((OO => OO.toLowerCase() == XO.toLowerCase()))) {
            KO.push(XO);
            continue OO
          }
        }
        KO.push("")
      }
      return KO
    }

    function yK(OO, KO, pO) {
      var XO;
      let bK = pO ? IO(KO.actions) : [];
      return (0, eO.b)("li", {
        class: "cm-diagnostic cm-diagnostic-" + KO.severity
      }, (0, eO.b)("span", {
        class: "cm-diagnosticText"
      }, KO.renderMessage ? KO.renderMessage(OO) : KO.message), null === (XO = KO.actions) || void 0 === XO ? void 0 : XO.map(((pO, XO) => {
        let lO = !1,
          vK = XO => {
            if (XO.preventDefault(), lO) return;
            lO = !0;
            let bK = CO(OO.state.field(FO).diagnostics, KO);
            bK && pO.apply(OO, bK.from, bK.to)
          },
          {
            name: hO
          } = pO,
          DO = bK[XO] ? hO.indexOf(bK[XO]) : -1,
          MO = DO < 0 ? hO : [hO.slice(0, DO), (0, eO.b)("u", hO.slice(DO, DO + 1)), hO.slice(DO + 1)],
          aK = pO.markClass ? " " + pO.markClass : "";
        return (0, eO.b)("button", {
          type: "button",
          class: "cm-diagnosticAction" + aK,
          onclick: vK,
          onmousedown: vK,
          "aria-label": ` Action: ${hO}${DO<0?"":` (access key "${bK[XO]})"`}.`
        }, MO)
      })), KO.source && (0, eO.b)("div", {
        class: "cm-diagnosticSource"
      }, KO.source))
    }
    class gK extends XO.m {
      constructor(OO) {
        super(), this.sev = OO
      }
      eq(OO) {
        return OO.sev == this.sev
      }
      toDOM() {
        return (0, eO.b)("span", {
          class: "cm-lintPoint cm-lintPoint-" + this.sev
        })
      }
    }
    class uO {
      constructor(OO, KO) {
        this.diagnostic = KO, this.id = "item_" + Math.floor(4294967295 * Math.random()).toString(16), this.dom = yK(OO, KO, !0), this.dom.id = this.id, this.dom.setAttribute("role", "option")
      }
    }
    class EO {
      constructor(OO) {
        this.view = OO, this.items = [];
        this.list = (0, eO.b)("ul", {
          tabIndex: 0,
          role: "listbox",
          "aria-label": this.view.state.phrase("Diagnostics"),
          onkeydown: KO => {
            if (!(KO.ctrlKey || KO.altKey || KO.metaKey)) {
              if (27 == KO.keyCode) zK(this.view), this.view.focus();
              else if (38 == KO.keyCode || 33 == KO.keyCode) this.moveSelection((this.selectedIndex - 1 + this.items.length) % this.items.length);
              else if (40 == KO.keyCode || 34 == KO.keyCode) this.moveSelection((this.selectedIndex + 1) % this.items.length);
              else if (36 == KO.keyCode) this.moveSelection(0);
              else if (35 == KO.keyCode) this.moveSelection(this.items.length - 1);
              else if (13 == KO.keyCode) this.view.focus();
              else {
                if (!(KO.keyCode >= 65 && KO.keyCode <= 90 && this.selectedIndex >= 0)) return;
                {
                  let {
                    diagnostic: pO
                  } = this.items[this.selectedIndex], XO = IO(pO.actions);
                  for (let bK = 0; bK < XO.length; bK++)
                    if (XO[bK].toUpperCase().charCodeAt(0) == KO.keyCode) {
                      let KO = CO(this.view.state.field(FO).diagnostics, pO);
                      KO && pO.actions[bK].apply(OO, KO.from, KO.to)
                    }
                }
              }
              KO.preventDefault()
            }
          },
          onclick: OO => {
            for (let KO = 0; KO < this.items.length; KO++) this.items[KO].dom.contains(OO.target) && this.moveSelection(KO)
          }
        }), this.dom = (0, eO.b)("div", {
          class: "cm-panel-lint"
        }, this.list, (0, eO.b)("button", {
          type: "button",
          name: "close",
          "aria-label": this.view.state.phrase("close"),
          onclick: () => zK(this.view)
        }, "\xd7")), this.update()
      }
      get selectedIndex() {
        let OO = this.view.state.field(FO).selected;
        if (!OO) return -1;
        for (let KO = 0; KO < this.items.length; KO++)
          if (this.items[KO].diagnostic == OO.diagnostic) return KO;
        return -1
      }
      update() {
        let {
          diagnostics: OO,
          selected: KO
        } = this.view.state.field(FO), pO = 0, XO = !1, bK = null, eO = new Set;
        for (OO.between(0, this.view.state.doc.length, ((OO, lO, vK) => {
            let {
              spec: CO
            } = vK;
            for (let hO of CO.diagnostics) {
              if (eO.has(hO)) continue;
              eO.add(hO);
              let OO, lO = -1;
              for (let KO = pO; KO < this.items.length; KO++)
                if (this.items[KO].diagnostic == hO) {
                  lO = KO;
                  break
                } lO < 0 ? (OO = new uO(this.view, hO), this.items.splice(pO, 0, OO), XO = !0) : (OO = this.items[lO], lO > pO && (this.items.splice(pO, lO - pO), XO = !0)), KO && OO.diagnostic == KO.diagnostic ? OO.dom.hasAttribute("aria-selected") || (OO.dom.setAttribute("aria-selected", "true"), bK = OO) : OO.dom.hasAttribute("aria-selected") && OO.dom.removeAttribute("aria-selected"), pO++
            }
          })); pO < this.items.length && !(1 == this.items.length && this.items[0].diagnostic.from < 0);) XO = !0, this.items.pop();
        0 == this.items.length && (this.items.push(new uO(this.view, {
          from: -1,
          to: -1,
          severity: "info",
          message: this.view.state.phrase("No diagnostics")
        })), XO = !0), bK ? (this.list.setAttribute("aria-activedescendant", bK.id), this.view.requestMeasure({
          key: this,
          read: () => ({
            sel: bK.dom.getBoundingClientRect(),
            panel: this.list.getBoundingClientRect()
          }),
          write: OO => {
            let {
              sel: KO,
              panel: pO
            } = OO, XO = pO.height / this.list.offsetHeight;
            KO.top < pO.top ? this.list.scrollTop -= (pO.top - KO.top) / XO : KO.bottom > pO.bottom && (this.list.scrollTop += (KO.bottom - pO.bottom) / XO)
          }
        })) : this.selectedIndex < 0 && this.list.removeAttribute("aria-activedescendant"), XO && this.sync()
      }
      sync() {
        let OO = this.list.firstChild;

        function KO() {
          let KO = OO;
          OO = KO.nextSibling, KO.remove()
        }
        for (let pO of this.items)
          if (pO.dom.parentNode == this.list) {
            for (; OO != pO.dom;) KO();
            OO = pO.dom.nextSibling
          } else this.list.insertBefore(pO.dom, OO);
        for (; OO;) KO()
      }
      moveSelection(OO) {
        if (this.selectedIndex < 0) return;
        let KO = CO(this.view.state.field(FO).diagnostics, this.items[OO].diagnostic);
        KO && this.view.dispatch({
          selection: {
            anchor: KO.from,
            head: KO.to
          },
          scrollIntoView: !0,
          effects: oO.of(KO)
        })
      }
      static open(OO) {
        return new EO(OO)
      }
    }

    function jK(OO) {
      return `url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" ${arguments.length>1&&void 0!==arguments[1]?arguments[1]:'viewBox="0 0 40 40"'}>${encodeURIComponent(OO)}</svg>')`
    }

    function YO(OO) {
      return jK(`<path d="m0 2.5 l2 -1.5 l1 0 l2 1.5 l1 0" stroke="${OO}" fill="none" stroke-width=".7"/>`, 'width="6" height="3"')
    }
    const wO = XO.h.baseTheme({
      ".cm-diagnostic": {
        padding: "3px 6px 3px 8px",
        marginLeft: "-1px",
        display: "block",
        whiteSpace: "pre-wrap"
      },
      ".cm-diagnostic-error": {
        borderLeft: "5px solid #d11"
      },
      ".cm-diagnostic-warning": {
        borderLeft: "5px solid orange"
      },
      ".cm-diagnostic-info": {
        borderLeft: "5px solid #999"
      },
      ".cm-diagnostic-hint": {
        borderLeft: "5px solid #66d"
      },
      ".cm-diagnosticAction": {
        font: "inherit",
        border: "none",
        padding: "2px 4px",
        backgroundColor: "#444",
        color: "white",
        borderRadius: "3px",
        marginLeft: "8px",
        cursor: "pointer"
      },
      ".cm-diagnosticSource": {
        fontSize: "70%",
        opacity: .7
      },
      ".cm-lintRange": {
        backgroundPosition: "left bottom",
        backgroundRepeat: "repeat-x",
        paddingBottom: "0.7px"
      },
      ".cm-lintRange-error": {
        backgroundImage: YO("#d11")
      },
      ".cm-lintRange-warning": {
        backgroundImage: YO("orange")
      },
      ".cm-lintRange-info": {
        backgroundImage: YO("#999")
      },
      ".cm-lintRange-hint": {
        backgroundImage: YO("#66d")
      },
      ".cm-lintRange-active": {
        backgroundColor: "#ffdd9980"
      },
      ".cm-tooltip-lint": {
        padding: 0,
        margin: 0
      },
      ".cm-lintPoint": {
        position: "relative",
        "&:after": {
          content: '""',
          position: "absolute",
          bottom: 0,
          left: "-2px",
          borderLeft: "3px solid transparent",
          borderRight: "3px solid transparent",
          borderBottom: "4px solid #d11"
        }
      },
      ".cm-lintPoint-warning": {
        "&:after": {
          borderBottomColor: "orange"
        }
      },
      ".cm-lintPoint-info": {
        "&:after": {
          borderBottomColor: "#999"
        }
      },
      ".cm-lintPoint-hint": {
        "&:after": {
          borderBottomColor: "#66d"
        }
      },
      ".cm-panel.cm-panel-lint": {
        position: "relative",
        "& ul": {
          maxHeight: "100px",
          overflowY: "auto",
          "& [aria-selected]": {
            backgroundColor: "#ddd",
            "& u": {
              textDecoration: "underline"
            }
          },
          "&:focus [aria-selected]": {
            background_fallback: "#bdf",
            backgroundColor: "Highlight",
            color_fallback: "white",
            color: "HighlightText"
          },
          "& u": {
            textDecoration: "none"
          },
          padding: 0,
          margin: 0
        },
        "& [name=close]": {
          position: "absolute",
          top: "0",
          right: "2px",
          background: "inherit",
          border: "none",
          font: "inherit",
          padding: 0,
          margin: 0
        }
      },
      "&dark .cm-lintRange-active": {
        backgroundColor: "#86714a80"
      },
      "&dark .cm-panel.cm-panel-lint ul": {
        "& [aria-selected]": {
          backgroundColor: "#2e343e"
        }
      }
    });

    function iK(OO) {
      return "error" == OO ? 4 : "warning" == OO ? 3 : "info" == OO ? 2 : 1
    }

    function rK(OO) {
      let KO = "hint",
        pO = 1;
      for (let XO of OO) {
        let OO = iK(XO.severity);
        OO > pO && (pO = OO, KO = XO.severity)
      }
      return KO
    }
    XO.i;
    const PO = [FO, XO.h.ql.compute([FO], (OO => {
      let {
        selected: KO,
        panel: pO
      } = OO.field(FO);
      return KO && pO && KO.from != KO.to ? XO.c.set([VO.range(KO.from, KO.to)]) : XO.c.none
    })), (0, XO.M)(LO, {
      hideOn: hO
    }), wO]
  },
  39375: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => kK,
      h: () => QO,
      j: () => UO
    });
    var XO = pO(39341),
      bK = pO(39338),
      eO = pO(39345);
    const lO = "function" == typeof String.prototype.normalize ? OO => OO.normalize("NFKD") : OO => OO;
    class vK {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : OO.length,
          bK = arguments.length > 4 ? arguments[4] : void 0,
          eO = arguments.length > 5 ? arguments[5] : void 0;
        this.test = eO, this.value = {
          from: 0,
          to: 0
        }, this.done = !1, this.matches = [], this.buffer = "", this.bufferPos = 0, this.iter = OO.iterRange(pO, XO), this.bufferStart = pO, this.normalize = bK ? OO => bK(lO(OO)) : lO, this.query = this.normalize(KO)
      }
      peek() {
        if (this.bufferPos == this.buffer.length) {
          if (this.bufferStart += this.buffer.length, this.iter.next(), this.iter.done) return -1;
          this.bufferPos = 0, this.buffer = this.iter.value
        }
        return (0, bK.N)(this.buffer, this.bufferPos)
      }
      next() {
        for (; this.matches.length;) this.matches.pop();
        return this.nextOverlapping()
      }
      nextOverlapping() {
        for (;;) {
          let OO = this.peek();
          if (OO < 0) return this.done = !0, this;
          let KO = (0, bK.ab)(OO),
            pO = this.bufferStart + this.bufferPos;
          this.bufferPos += (0, bK.P)(OO);
          let XO = this.normalize(KO);
          if (XO.length)
            for (let bK = 0, eO = pO;; bK++) {
              let OO = XO.charCodeAt(bK),
                lO = this.match(OO, eO, this.bufferPos + this.bufferStart);
              if (bK == XO.length - 1) {
                if (lO) return this.value = lO, this;
                break
              }
              eO == pO && bK < KO.length && KO.charCodeAt(bK) == OO && eO++
            }
        }
      }
      match(OO, KO, pO) {
        let XO = null;
        for (let bK = 0; bK < this.matches.length; bK += 2) {
          let KO = this.matches[bK],
            eO = !1;
          this.query.charCodeAt(KO) == OO && (KO == this.query.length - 1 ? XO = {
            from: this.matches[bK + 1],
            to: pO
          } : (this.matches[bK]++, eO = !0)), eO || (this.matches.splice(bK, 2), bK -= 2)
        }
        return this.query.charCodeAt(0) == OO && (1 == this.query.length ? XO = {
          from: KO,
          to: pO
        } : this.matches.push(1, KO)), XO && this.test && !this.test(XO.from, XO.to, this.buffer, this.bufferStart) && (XO = null), XO
      }
    }
    "undefined" != typeof Symbol && (vK.prototype[Symbol.iterator] = function() {
      return this
    });
    const CO = {
        from: -1,
        to: -1,
        match: /.*/.exec("")
      },
      hO = "gm" + (null == /x/.unicode ? "" : "u");
    class DO {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : OO.length;
        if (this.text = OO, this.to = bK, this.curLine = "", this.done = !1, this.value = CO, /\\[sWDnr]|\n|\r|\[\^/.test(KO)) return new oO(OO, KO, pO, XO, bK);
        this.re = new RegExp(KO, hO + ((null === pO || void 0 === pO ? void 0 : pO.ignoreCase) ? "i" : "")), this.test = null === pO || void 0 === pO ? void 0 : pO.test, this.iter = OO.iter();
        let eO = OO.lineAt(XO);
        this.curLineStart = eO.from, this.matchPos = FO(OO, XO), this.getLine(this.curLineStart)
      }
      getLine(OO) {
        this.iter.next(OO), this.iter.lineBreak ? this.curLine = "" : (this.curLine = this.iter.value, this.curLineStart + this.curLine.length > this.to && (this.curLine = this.curLine.slice(0, this.to - this.curLineStart)), this.iter.next())
      }
      nextLine() {
        this.curLineStart = this.curLineStart + this.curLine.length + 1, this.curLineStart > this.to ? this.curLine = "" : this.getLine(0)
      }
      next() {
        for (let OO = this.matchPos - this.curLineStart;;) {
          this.re.lastIndex = OO;
          let KO = this.matchPos <= this.to && this.re.exec(this.curLine);
          if (KO) {
            let pO = this.curLineStart + KO.index,
              XO = pO + KO[0].length;
            if (this.matchPos = FO(this.text, XO + (pO == XO ? 1 : 0)), pO == this.curLineStart + this.curLine.length && this.nextLine(), (pO < XO || pO > this.value.to) && (!this.test || this.test(pO, XO, KO))) return this.value = {
              from: pO,
              to: XO,
              match: KO
            }, this;
            OO = this.matchPos - this.curLineStart
          } else {
            if (!(this.curLineStart + this.curLine.length < this.to)) return this.done = !0, this;
            this.nextLine(), OO = 0
          }
        }
      }
    }
    const MO = new WeakMap;
    class aK {
      constructor(OO, KO) {
        this.from = OO, this.text = KO
      }
      get to() {
        return this.from + this.text.length
      }
      static get(OO, KO, pO) {
        let XO = MO.get(OO);
        if (!XO || XO.from >= pO || XO.to <= KO) {
          let XO = new aK(KO, OO.sliceString(KO, pO));
          return MO.set(OO, XO), XO
        }
        if (XO.from == KO && XO.to == pO) return XO;
        let {
          text: bK,
          from: eO
        } = XO;
        return eO > KO && (bK = OO.sliceString(KO, eO) + bK, eO = KO), XO.to < pO && (bK += OO.sliceString(XO.to, pO)), MO.set(OO, new aK(eO, bK)), new aK(KO, bK.slice(KO - eO, pO - eO))
      }
    }
    class oO {
      constructor(OO, KO, pO, XO, bK) {
        this.text = OO, this.to = bK, this.done = !1, this.value = CO, this.matchPos = FO(OO, XO), this.re = new RegExp(KO, hO + ((null === pO || void 0 === pO ? void 0 : pO.ignoreCase) ? "i" : "")), this.test = null === pO || void 0 === pO ? void 0 : pO.test, this.flat = aK.get(OO, XO, this.chunkEnd(XO + 5e3))
      }
      chunkEnd(OO) {
        return OO >= this.to ? this.to : this.text.lineAt(OO).to
      }
      next() {
        for (;;) {
          let OO = this.re.lastIndex = this.matchPos - this.flat.from,
            KO = this.re.exec(this.flat.text);
          if (KO && !KO[0] && KO.index == OO && (this.re.lastIndex = OO + 1, KO = this.re.exec(this.flat.text)), KO) {
            let OO = this.flat.from + KO.index,
              pO = OO + KO[0].length;
            if ((this.flat.to >= this.to || KO.index + KO[0].length <= this.flat.text.length - 10) && (!this.test || this.test(OO, pO, KO))) return this.value = {
              from: OO,
              to: pO,
              match: KO
            }, this.matchPos = FO(this.text, pO + (OO == pO ? 1 : 0)), this
          }
          if (this.flat.to == this.to) return this.done = !0, this;
          this.flat = aK.get(this.text, this.flat.from, this.chunkEnd(this.flat.from + 2 * this.flat.text.length))
        }
      }
    }

    function FO(OO, KO) {
      if (KO >= OO.length) return KO;
      let pO, XO = OO.lineAt(KO);
      for (; KO < XO.to && (pO = XO.text.charCodeAt(KO - XO.from)) >= 56320 && pO < 57344;) KO++;
      return KO
    }
    "undefined" != typeof Symbol && (DO.prototype[Symbol.iterator] = oO.prototype[Symbol.iterator] = function() {
      return this
    });
    const VO = {
        highlightWordAroundCursor: !1,
        minSelectionLength: 1,
        maxMatches: 100,
        wholeWords: !1
      },
      LO = bK.n.define({
        combine: OO => (0, bK.T)(OO, VO, {
          highlightWordAroundCursor: (OO, KO) => OO || KO,
          minSelectionLength: Math.min,
          maxMatches: Math.min
        })
      });

    function QO(OO) {
      let KO = [TO, dO];
      return OO && KO.push(LO.of(OO)), KO
    }
    const zK = XO.c.mark({
        class: "cm-selectionMatch"
      }),
      AO = XO.c.mark({
        class: "cm-selectionMatch cm-selectionMatch-main"
      });

    function fO(OO, KO, pO, XO) {
      return (0 == pO || OO(KO.sliceDoc(pO - 1, pO)) != bK.i.Word) && (XO == KO.doc.length || OO(KO.sliceDoc(XO, XO + 1)) != bK.i.Word)
    }
    const dO = XO.l.fromClass(class {
        constructor(OO) {
          this.ql = this.getDeco(OO)
        }
        update(OO) {
          (OO.selectionSet || OO.docChanged || OO.viewportChanged) && (this.ql = this.getDeco(OO.view))
        }
        getDeco(OO) {
          let KO = OO.state.facet(LO),
            {
              state: pO
            } = OO,
            eO = pO.selection;
          if (eO.Xl.length > 1) return XO.c.none;
          let lO, CO = eO.main,
            hO = null;
          if (CO.empty) {
            if (!KO.highlightWordAroundCursor) return XO.c.none;
            let OO = pO.wordAt(CO.head);
            if (!OO) return XO.c.none;
            hO = pO.charCategorizer(CO.head), lO = pO.sliceDoc(OO.from, OO.to)
          } else {
            let OO = CO.to - CO.from;
            if (OO < KO.minSelectionLength || OO > 200) return XO.c.none;
            if (KO.wholeWords) {
              if (lO = pO.sliceDoc(CO.from, CO.to), hO = pO.charCategorizer(CO.head), !fO(hO, pO, CO.from, CO.to) || ! function(OO, KO, pO, XO) {
                  return OO(KO.sliceDoc(pO, pO + 1)) == bK.i.Word && OO(KO.sliceDoc(XO - 1, XO)) == bK.i.Word
                }(hO, pO, CO.from, CO.to)) return XO.c.none
            } else if (lO = pO.sliceDoc(CO.from, CO.to), !lO) return XO.c.none
          }
          let DO = [];
          for (let bK of OO.yvO) {
            let OO = new vK(pO.doc, lO, bK.from, bK.to);
            for (; !OO.next().done;) {
              let {
                from: bK,
                to: eO
              } = OO.value;
              if ((!hO || fO(hO, pO, bK, eO)) && (CO.empty && bK <= CO.from && eO >= CO.to ? DO.push(AO.range(bK, eO)) : (bK >= CO.to || eO <= CO.from) && DO.push(zK.range(bK, eO)), DO.length > KO.maxMatches)) return XO.c.none
            }
          }
          return XO.c.set(DO)
        }
      }, {
        ql: OO => OO.ql
      }),
      TO = XO.h.baseTheme({
        ".cm-selectionMatch": {
          backgroundColor: "#99ff7780"
        },
        ".cm-searchMatch .cm-selectionMatch": {
          backgroundColor: "transparent"
        }
      });
    const NO = bK.n.define({
      combine: OO => (0, bK.T)(OO, {
        top: !1,
        caseSensitive: !1,
        literal: !1,
        regexp: !1,
        wholeWord: !1,
        createPanel: OO => new OK(OO),
        scrollToMatch: OO => XO.h.scrollIntoView(OO)
      })
    });
    class IO {
      constructor(OO) {
        this.search = OO.search, this.caseSensitive = !!OO.caseSensitive, this.literal = !!OO.literal, this.regexp = !!OO.regexp, this.replace = OO.replace || "", this.valid = !!this.search && (!this.regexp || function(OO) {
          try {
            return new RegExp(OO, hO), !0
          } catch (KO) {
            return !1
          }
        }(this.search)), this.unquoted = this.unquote(this.search), this.wholeWord = !!OO.wholeWord, this.test = OO.test
      }
      unquote(OO) {
        return this.literal ? OO : OO.replace(/\\([nrt\\])/g, ((OO, KO) => "n" == KO ? "\n" : "r" == KO ? "\r" : "t" == KO ? "\t" : "\\"))
      }
      eq(OO) {
        return this.search == OO.search && this.replace == OO.replace && this.caseSensitive == OO.caseSensitive && this.regexp == OO.regexp && this.wholeWord == OO.wholeWord && this.test == OO.test
      }
      create() {
        return this.regexp ? new wO(this) : new uO(this)
      }
      getCursor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = OO.doc ? OO : bK.m.create({
            doc: OO
          });
        return null == pO && (pO = XO.doc.length), this.regexp ? EO(this, XO, KO, pO) : gK(this, XO, KO, pO)
      }
    }
    class yK {
      constructor(OO) {
        this.spec = OO
      }
    }

    function gK(OO, KO, pO, XO) {
      let eO;
      var lO, CO;
      return OO.wholeWord && (lO = KO.doc, CO = KO.charCategorizer(KO.selection.main.head), eO = (OO, KO, pO, XO) => ((XO > OO || XO + pO.length < KO) && (XO = Math.max(0, OO - 2), pO = lO.sliceString(XO, Math.min(lO.length, KO + 2))), (CO(jK(pO, OO - XO)) != bK.i.Word || CO(YO(pO, OO - XO)) != bK.i.Word) && (CO(YO(pO, KO - XO)) != bK.i.Word || CO(jK(pO, KO - XO)) != bK.i.Word))), OO.test && (eO = function(OO, KO, pO) {
        return (XO, bK, eO, lO) => {
          if (pO && !pO(XO, bK, eO, lO)) return !1;
          let vK = XO >= lO && bK <= lO + eO.length ? eO.slice(XO - lO, bK - lO) : KO.doc.sliceString(XO, bK);
          return OO(vK, KO, XO, bK)
        }
      }(OO.test, KO, eO)), new vK(KO.doc, OO.unquoted, pO, XO, OO.caseSensitive ? void 0 : OO => OO.toLowerCase(), eO)
    }
    class uO extends yK {
      constructor(OO) {
        super(OO)
      }
      nextMatch(OO, KO, pO) {
        let XO = gK(this.spec, OO, pO, OO.doc.length).nextOverlapping();
        if (XO.done) {
          let pO = Math.min(OO.doc.length, KO + this.spec.unquoted.length);
          XO = gK(this.spec, OO, 0, pO).nextOverlapping()
        }
        return XO.done || XO.value.from == KO && XO.value.to == pO ? null : XO.value
      }
      prevMatchInRange(OO, KO, pO) {
        for (let XO = pO;;) {
          let pO = Math.max(KO, XO - 1e4 - this.spec.unquoted.length),
            bK = gK(this.spec, OO, pO, XO),
            eO = null;
          for (; !bK.nextOverlapping().done;) eO = bK.value;
          if (eO) return eO;
          if (pO == KO) return null;
          XO -= 1e4
        }
      }
      prevMatch(OO, KO, pO) {
        let XO = this.prevMatchInRange(OO, 0, KO);
        return XO || (XO = this.prevMatchInRange(OO, Math.max(0, pO - this.spec.unquoted.length), OO.doc.length)), !XO || XO.from == KO && XO.to == pO ? null : XO
      }
      getReplacement(OO) {
        return this.spec.unquote(this.spec.replace)
      }
      matchAll(OO, KO) {
        let pO = gK(this.spec, OO, 0, OO.doc.length),
          XO = [];
        for (; !pO.next().done;) {
          if (XO.length >= KO) return null;
          XO.push(pO.value)
        }
        return XO
      }
      highlight(OO, KO, pO, XO) {
        let bK = gK(this.spec, OO, Math.max(0, KO - this.spec.unquoted.length), Math.min(pO + this.spec.unquoted.length, OO.doc.length));
        for (; !bK.next().done;) XO(bK.value.from, bK.value.to)
      }
    }

    function EO(OO, KO, pO, XO) {
      let eO;
      var lO;
      return OO.wholeWord && (lO = KO.charCategorizer(KO.selection.main.head), eO = (OO, KO, pO) => !pO[0].length || (lO(jK(pO.input, pO.index)) != bK.i.Word || lO(YO(pO.input, pO.index)) != bK.i.Word) && (lO(YO(pO.input, pO.index + pO[0].length)) != bK.i.Word || lO(jK(pO.input, pO.index + pO[0].length)) != bK.i.Word)), OO.test && (eO = function(OO, KO, pO) {
        return (XO, bK, eO) => (!pO || pO(XO, bK, eO)) && OO(eO[0], KO, XO, bK)
      }(OO.test, KO, eO)), new DO(KO.doc, OO.search, {
        ignoreCase: !OO.caseSensitive,
        test: eO
      }, pO, XO)
    }

    function jK(OO, KO) {
      return OO.slice((0, bK.Y)(OO, KO, !1), KO)
    }

    function YO(OO, KO) {
      return OO.slice(KO, (0, bK.Y)(OO, KO))
    }
    class wO extends yK {
      nextMatch(OO, KO, pO) {
        let XO = EO(this.spec, OO, pO, OO.doc.length).next();
        return XO.done && (XO = EO(this.spec, OO, 0, KO).next()), XO.done ? null : XO.value
      }
      prevMatchInRange(OO, KO, pO) {
        for (let XO = 1;; XO++) {
          let bK = Math.max(KO, pO - 1e4 * XO),
            eO = EO(this.spec, OO, bK, pO),
            lO = null;
          for (; !eO.next().done;) lO = eO.value;
          if (lO && (bK == KO || lO.from > bK + 10)) return lO;
          if (bK == KO) return null
        }
      }
      prevMatch(OO, KO, pO) {
        return this.prevMatchInRange(OO, 0, KO) || this.prevMatchInRange(OO, pO, OO.doc.length)
      }
      getReplacement(OO) {
        return this.spec.unquote(this.spec.replace).replace(/\$([$&]|\d+)/g, ((KO, pO) => {
          if ("&" == pO) return OO.match[0];
          if ("$" == pO) return "$";
          for (let XO = pO.length; XO > 0; XO--) {
            let KO = +pO.slice(0, XO);
            if (KO > 0 && KO < OO.match.length) return OO.match[KO] + pO.slice(XO)
          }
          return KO
        }))
      }
      matchAll(OO, KO) {
        let pO = EO(this.spec, OO, 0, OO.doc.length),
          XO = [];
        for (; !pO.next().done;) {
          if (XO.length >= KO) return null;
          XO.push(pO.value)
        }
        return XO
      }
      highlight(OO, KO, pO, XO) {
        let bK = EO(this.spec, OO, Math.max(0, KO - 250), Math.min(pO + 250, OO.doc.length));
        for (; !bK.next().done;) XO(bK.value.from, bK.value.to)
      }
    }
    const iK = bK.C.define(),
      rK = bK.C.define(),
      PO = bK.G.define({
        create: OO => new mK(xK(OO).create(), null),
        update(OO, KO) {
          for (let pO of KO.effects) pO.is(iK) ? OO = new mK(pO.value.create(), OO.panel) : pO.is(rK) && (OO = new mK(OO.query, pO.value ? qK : null));
          return OO
        },
        provide: OO => XO.cb.from(OO, (OO => OO.panel))
      });
    class mK {
      constructor(OO, KO) {
        this.query = OO, this.panel = KO
      }
    }
    const sO = XO.c.mark({
        class: "cm-searchMatch"
      }),
      HO = XO.c.mark({
        class: "cm-searchMatch cm-searchMatch-selected"
      }),
      RO = XO.l.fromClass(class {
        constructor(OO) {
          this.view = OO, this.ql = this.highlight(OO.state.field(PO))
        }
        update(OO) {
          let KO = OO.state.field(PO);
          (KO != OO.startState.field(PO) || OO.docChanged || OO.selectionSet || OO.viewportChanged) && (this.ql = this.highlight(KO))
        }
        highlight(OO) {
          let {
            query: KO,
            panel: pO
          } = OO;
          if (!pO || !KO.spec.valid) return XO.c.none;
          let {
            view: eO
          } = this, lO = new bK.v;
          for (let XO = 0, bK = eO.yvO, vK = bK.length; XO < vK; XO++) {
            let {
              from: OO,
              to: pO
            } = bK[XO];
            for (; XO < vK - 1 && pO > bK[XO + 1].from - 500;) pO = bK[++XO].to;
            KO.highlight(eO.state, OO, pO, ((OO, KO) => {
              let pO = eO.state.selection.Xl.some((pO => pO.from == OO && pO.to == KO));
              lO.add(OO, KO, pO ? HO : sO)
            }))
          }
          return lO.finish()
        }
      }, {
        ql: OO => OO.ql
      });

    function SO(OO) {
      return KO => {
        let pO = KO.state.field(PO, !1);
        return pO && pO.query.spec.valid ? OO(KO, pO) : tK(KO)
      }
    }
    const JO = SO(((OO, KO) => {
        let {
          query: pO
        } = KO, {
          to: XO
        } = OO.state.selection.main, eO = pO.nextMatch(OO.state, XO, XO);
        if (!eO) return !1;
        let lO = bK.j.single(eO.from, eO.to),
          vK = OO.state.facet(NO);
        return OO.dispatch({
          selection: lO,
          effects: [bp(OO, eO), vK.scrollToMatch(lO.main, OO)],
          userEvent: "select.search"
        }), WO(OO), !0
      })),
      cK = SO(((OO, KO) => {
        let {
          query: pO
        } = KO, {
          state: XO
        } = OO, {
          from: eO
        } = XO.selection.main, lO = pO.prevMatch(XO, eO, eO);
        if (!lO) return !1;
        let vK = bK.j.single(lO.from, lO.to),
          CO = OO.state.facet(NO);
        return OO.dispatch({
          selection: vK,
          effects: [bp(OO, lO), CO.scrollToMatch(vK.main, OO)],
          userEvent: "select.search"
        }), WO(OO), !0
      })),
      BO = SO(((OO, KO) => {
        let {
          query: pO
        } = KO, XO = pO.matchAll(OO.state, 1e3);
        return !(!XO || !XO.length) && (OO.dispatch({
          selection: bK.j.create(XO.map((OO => bK.j.range(OO.from, OO.to)))),
          userEvent: "select.search.matches"
        }), !0)
      })),
      ZO = SO(((OO, KO) => {
        let {
          query: pO
        } = KO, {
          state: eO
        } = OO, {
          from: lO,
          to: vK
        } = eO.selection.main;
        if (eO.readOnly) return !1;
        let CO = pO.nextMatch(eO, lO, lO);
        if (!CO) return !1;
        let hO, DO, MO = CO,
          aK = [],
          oO = [];
        MO.from == lO && MO.to == vK && (DO = eO.toText(pO.getReplacement(MO)), aK.push({
          from: MO.from,
          to: MO.to,
          insert: DO
        }), MO = pO.nextMatch(eO, MO.from, MO.to), oO.push(XO.h.announce.of(eO.phrase("replaced match on line $", eO.doc.lineAt(lO).number) + ".")));
        let FO = OO.state.changes(aK);
        return MO && (hO = bK.j.single(MO.from, MO.to).map(FO), oO.push(bp(OO, MO)), oO.push(eO.facet(NO).scrollToMatch(hO.main, OO))), OO.dispatch({
          changes: FO,
          selection: hO,
          effects: oO,
          userEvent: "input.replace"
        }), !0
      })),
      GO = SO(((OO, KO) => {
        let {
          query: pO
        } = KO;
        if (OO.state.readOnly) return !1;
        let bK = pO.matchAll(OO.state, 1e9).map((OO => {
          let {
            from: KO,
            to: XO
          } = OO;
          return {
            from: KO,
            to: XO,
            insert: pO.getReplacement(OO)
          }
        }));
        if (!bK.length) return !1;
        let eO = OO.state.phrase("replaced $ matches", bK.length) + ".";
        return OO.dispatch({
          changes: bK,
          effects: XO.h.announce.of(eO),
          userEvent: "input.replace.all"
        }), !0
      }));

    function qK(OO) {
      return OO.state.facet(NO).createPanel(OO)
    }

    function xK(OO, KO) {
      var pO, XO, bK, eO, lO;
      let vK = OO.selection.main,
        CO = vK.empty || vK.to > vK.from + 100 ? "" : OO.sliceDoc(vK.from, vK.to);
      if (KO && !CO) return KO;
      let hO = OO.facet(NO);
      return new IO({
        search: (null !== (pO = null === KO || void 0 === KO ? void 0 : KO.literal) && void 0 !== pO ? pO : hO.literal) ? CO : CO.replace(/\n/g, "\\n"),
        caseSensitive: null !== (XO = null === KO || void 0 === KO ? void 0 : KO.caseSensitive) && void 0 !== XO ? XO : hO.caseSensitive,
        literal: null !== (bK = null === KO || void 0 === KO ? void 0 : KO.literal) && void 0 !== bK ? bK : hO.literal,
        regexp: null !== (eO = null === KO || void 0 === KO ? void 0 : KO.regexp) && void 0 !== eO ? eO : hO.regexp,
        wholeWord: null !== (lO = null === KO || void 0 === KO ? void 0 : KO.wholeWord) && void 0 !== lO ? lO : hO.wholeWord
      })
    }

    function nO(OO) {
      let KO = (0, XO.w)(OO, qK);
      return KO && KO.dom.querySelector("[main-field]")
    }

    function WO(OO) {
      let KO = nO(OO);
      KO && KO == OO.root.activeElement && KO.select()
    }
    const tK = OO => {
        let KO = OO.state.field(PO, !1);
        if (KO && KO.panel) {
          let pO = nO(OO);
          if (pO && pO != OO.root.activeElement) {
            let XO = xK(OO.state, KO.query.spec);
            XO.valid && OO.dispatch({
              effects: iK.of(XO)
            }), pO.focus(), pO.select()
          }
        } else OO.dispatch({
          effects: [rK.of(!0), KO ? iK.of(xK(OO.state, KO.query.spec)) : bK.C.appendConfig.of(lK)]
        });
        return !0
      },
      kK = OO => {
        let KO = OO.state.field(PO, !1);
        if (!KO || !KO.panel) return !1;
        let pO = (0, XO.w)(OO, qK);
        return pO && pO.dom.contains(OO.root.activeElement) && OO.focus(), OO.dispatch({
          effects: rK.of(!1)
        }), !0
      },
      UO = [{
        key: "Mod-f",
        run: tK,
        scope: "editor search-panel"
      }, {
        key: "F3",
        run: JO,
        shift: cK,
        scope: "editor search-panel",
        preventDefault: !0
      }, {
        key: "Mod-g",
        run: JO,
        shift: cK,
        scope: "editor search-panel",
        preventDefault: !0
      }, {
        key: "Escape",
        run: kK,
        scope: "editor search-panel"
      }, {
        key: "Mod-Shift-l",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO, XO = KO.selection;
          if (XO.Xl.length > 1 || XO.main.empty) return !1;
          let {
            from: eO,
            to: lO
          } = XO.main, CO = [], hO = 0;
          for (let DO = new vK(KO.doc, KO.sliceDoc(eO, lO)); !DO.next().done;) {
            if (CO.length > 1e3) return !1;
            DO.value.from == eO && (hO = CO.length), CO.push(bK.j.range(DO.value.from, DO.value.to))
          }
          return pO(KO.update({
            selection: bK.j.create(CO, hO),
            userEvent: "select.search.matches"
          })), !0
        }
      }, {
        key: "Mod-Alt-g",
        run: OO => {
          let {
            state: KO
          } = OO, pO = String(KO.doc.lineAt(OO.state.selection.main.head).number), {
            close: eO,
            result: lO
          } = (0, XO.$)(OO, {
            label: KO.phrase("Go to line"),
            input: {
              type: "text",
              name: "line",
              value: pO
            },
            focus: !0,
            submitLabel: KO.phrase("go")
          });
          return lO.then((pO => {
            let lO = pO && /^([+-])?(\d+)?(:\d+)?(%)?$/.exec(pO.elements.line.value);
            if (!lO) return void OO.dispatch({
              effects: eO
            });
            let vK = KO.doc.lineAt(KO.selection.main.head),
              [, CO, hO, DO, MO] = lO,
              aK = DO ? +DO.slice(1) : 0,
              oO = hO ? +hO : vK.number;
            if (hO && MO) {
              let OO = oO / 100;
              CO && (OO = OO * ("-" == CO ? -1 : 1) + vK.number / KO.doc.lines), oO = Math.round(KO.doc.lines * OO)
            } else hO && CO && (oO = oO * ("-" == CO ? -1 : 1) + vK.number);
            let FO = KO.doc.line(Math.max(1, Math.min(KO.doc.lines, oO))),
              VO = bK.j.cursor(FO.from + Math.max(0, Math.min(aK, FO.length)));
            OO.dispatch({
              effects: [eO, XO.h.scrollIntoView(VO.from, {
                y: "center"
              })],
              selection: VO
            })
          })), !0
        }
      }, {
        key: "Mod-d",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO, {
            Xl: eO
          } = KO.selection;
          if (eO.some((OO => OO.from === OO.to))) return (OO => {
            let {
              state: KO,
              dispatch: pO
            } = OO, {
              selection: XO
            } = KO, eO = bK.j.create(XO.Xl.map((OO => KO.wordAt(OO.head) || bK.j.cursor(OO.head))), XO.mainIndex);
            return !eO.eq(XO) && (pO(KO.update({
              selection: eO
            })), !0)
          })({
            state: KO,
            dispatch: pO
          });
          let lO = KO.sliceDoc(eO[0].from, eO[0].to);
          if (KO.selection.Xl.some((OO => KO.sliceDoc(OO.from, OO.to) != lO))) return !1;
          let CO = function(OO, KO) {
            let {
              main: pO,
              Xl: XO
            } = OO.selection, bK = OO.wordAt(pO.head), eO = bK && bK.from == pO.from && bK.to == pO.to;
            for (let lO = !1, CO = new vK(OO.doc, KO, XO[XO.length - 1].to);;) {
              if (CO.next(), !CO.done) {
                if (lO && XO.some((OO => OO.from == CO.value.from))) continue;
                if (eO) {
                  let KO = OO.wordAt(CO.value.from);
                  if (!KO || KO.from != CO.value.from || KO.to != CO.value.to) continue
                }
                return CO.value
              }
              if (lO) return null;
              CO = new vK(OO.doc, KO, 0, Math.max(0, XO[XO.length - 1].from - 1)), lO = !0
            }
          }(KO, lO);
          return !!CO && (pO(KO.update({
            selection: KO.selection.addRange(bK.j.range(CO.from, CO.to), !1),
            effects: XO.h.scrollIntoView(CO.to)
          })), !0)
        },
        preventDefault: !0
      }];
    class OK {
      constructor(OO) {
        this.view = OO;
        let KO = this.query = OO.state.field(PO).query.spec;

        function pO(OO, KO, pO) {
          return (0, eO.b)("button", {
            class: "cm-button",
            name: OO,
            onclick: KO,
            type: "button"
          }, pO)
        }
        this.commit = this.commit.bind(this), this.searchField = (0, eO.b)("input", {
          value: KO.search,
          placeholder: KK(OO, "Find"),
          "aria-label": KK(OO, "Find"),
          class: "cm-textfield",
          name: "search",
          form: "",
          "main-field": "true",
          onchange: this.commit,
          onkeyup: this.commit
        }), this.replaceField = (0, eO.b)("input", {
          value: KO.replace,
          placeholder: KK(OO, "Replace"),
          "aria-label": KK(OO, "Replace"),
          class: "cm-textfield",
          name: "replace",
          form: "",
          onchange: this.commit,
          onkeyup: this.commit
        }), this.caseField = (0, eO.b)("input", {
          type: "checkbox",
          name: "case",
          form: "",
          checked: KO.caseSensitive,
          onchange: this.commit
        }), this.reField = (0, eO.b)("input", {
          type: "checkbox",
          name: "re",
          form: "",
          checked: KO.regexp,
          onchange: this.commit
        }), this.wordField = (0, eO.b)("input", {
          type: "checkbox",
          name: "word",
          form: "",
          checked: KO.wholeWord,
          onchange: this.commit
        }), this.dom = (0, eO.b)("div", {
          onkeydown: OO => this.keydown(OO),
          class: "cm-search"
        }, [this.searchField, pO("next", (() => JO(OO)), [KK(OO, "next")]), pO("prev", (() => cK(OO)), [KK(OO, "previous")]), pO("select", (() => BO(OO)), [KK(OO, "all")]), (0, eO.b)("label", null, [this.caseField, KK(OO, "match case")]), (0, eO.b)("label", null, [this.reField, KK(OO, "regexp")]), (0, eO.b)("label", null, [this.wordField, KK(OO, "by word")]), ...OO.state.readOnly ? [] : [(0, eO.b)("br"), this.replaceField, pO("replace", (() => ZO(OO)), [KK(OO, "replace")]), pO("replaceAll", (() => GO(OO)), [KK(OO, "replace all")])], (0, eO.b)("button", {
          name: "close",
          onclick: () => kK(OO),
          "aria-label": KK(OO, "close"),
          type: "button"
        }, ["\xd7"])])
      }
      commit() {
        let OO = new IO({
          search: this.searchField.value,
          caseSensitive: this.caseField.checked,
          regexp: this.reField.checked,
          wholeWord: this.wordField.checked,
          replace: this.replaceField.value
        });
        OO.eq(this.query) || (this.query = OO, this.view.dispatch({
          effects: iK.of(OO)
        }))
      }
      keydown(OO) {
        (0, XO.X)(this.view, OO, "search-panel") ? OO.preventDefault(): 13 == OO.keyCode && OO.target == this.searchField ? (OO.preventDefault(), (OO.shiftKey ? cK : JO)(this.view)) : 13 == OO.keyCode && OO.target == this.replaceField && (OO.preventDefault(), ZO(this.view))
      }
      update(OO) {
        for (let KO of OO.transactions)
          for (let OO of KO.effects) OO.is(iK) && !OO.value.eq(this.query) && this.setQuery(OO.value)
      }
      setQuery(OO) {
        this.query = OO, this.searchField.value = OO.search, this.replaceField.value = OO.replace, this.caseField.checked = OO.caseSensitive, this.reField.checked = OO.regexp, this.wordField.checked = OO.wholeWord
      }
      mount() {
        this.searchField.select()
      }
      get pos() {
        return 80
      }
      get top() {
        return this.view.state.facet(NO).top
      }
    }

    function KK(OO, KO) {
      return OO.state.phrase(KO)
    }
    const pK = 30,
      XK = /[\s\.,:;?!]/;

    function bp(OO, KO) {
      let {
        from: pO,
        to: bK
      } = KO, eO = OO.state.doc.lineAt(pO), lO = OO.state.doc.lineAt(bK).to, vK = Math.max(eO.from, pO - pK), CO = Math.min(lO, bK + pK), hO = OO.state.sliceDoc(vK, CO);
      if (vK != eO.from)
        for (let XO = 0; XO < pK; XO++)
          if (!XK.test(hO[XO + 1]) && XK.test(hO[XO])) {
            hO = hO.slice(XO);
            break
          } if (CO != lO)
        for (let XO = hO.length - 1; XO > hO.length - pK; XO--)
          if (!XK.test(hO[XO - 1]) && XK.test(hO[XO])) {
            hO = hO.slice(0, XO);
            break
          } return XO.h.announce.of(`${OO.state.phrase("current match")}. ${hO} ${OO.state.phrase("on line")} ${eO.number}.`)
    }
    const eK = XO.h.baseTheme({
        ".cm-panel.cm-search": {
          padding: "2px 6px 4px",
          position: "relative",
          "& [name=close]": {
            position: "absolute",
            top: "0",
            right: "4px",
            backgroundColor: "inherit",
            border: "none",
            font: "inherit",
            padding: 0,
            margin: 0
          },
          "& input, & button, & label": {
            margin: ".2em .6em .2em 0"
          },
          "& input[type=checkbox]": {
            marginRight: ".2em"
          },
          "& label": {
            fontSize: "80%",
            whiteSpace: "pre"
          }
        },
        "&light .cm-searchMatch": {
          backgroundColor: "#ffff0054"
        },
        "&dark .cm-searchMatch": {
          backgroundColor: "#00ffff8a"
        },
        "&light .cm-searchMatch-selected": {
          backgroundColor: "#ff6a0054"
        },
        "&dark .cm-searchMatch-selected": {
          backgroundColor: "#ff00ff8a"
        }
      }),
      lK = [PO, bK.u.low(RO), eK]
  },
  39341: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => wO,
      d: () => hK,
      h: () => ye,
      i: () => el,
      l: () => WK,
      m: () => jK,
      p: () => Ee,
      s: () => Wb,
      v: () => ee,
      w: () => We,
      y: () => ql,
      C: () => Dl,
      I: () => Qe,
      F: () => jv,
      K: () => oe,
      M: () => Ge,
      O: () => re,
      Q: () => yv,
      S: () => GK,
      T: () => de,
      U: () => yl,
      X: () => sb,
      $: () => Kl,
      cb: () => Ol,
      eb: () => Re
    });
    for (var XO = pO(39338), bK = pO(39343), eO = {
        8: "Backspace",
        9: "Tab",
        10: "Enter",
        12: "NumLock",
        13: "Enter",
        16: "Shift",
        17: "Control",
        18: "Alt",
        20: "CapsLock",
        27: "Escape",
        32: " ",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "ArrowLeft",
        38: "ArrowUp",
        39: "ArrowRight",
        40: "ArrowDown",
        44: "PrintScreen",
        45: "Insert",
        46: "Delete",
        59: ";",
        61: "=",
        91: "Meta",
        92: "Meta",
        106: "*",
        107: "+",
        108: ",",
        109: "-",
        110: ".",
        111: "/",
        144: "NumLock",
        145: "ScrollLock",
        160: "Shift",
        161: "Shift",
        162: "Control",
        163: "Control",
        164: "Alt",
        165: "Alt",
        173: "-",
        186: ";",
        187: "=",
        188: ",",
        189: "-",
        190: ".",
        191: "/",
        192: "`",
        219: "[",
        220: "\\",
        221: "]",
        222: "'"
      }, lO = {
        48: ")",
        49: "!",
        50: "@",
        51: "#",
        52: "$",
        53: "%",
        54: "^",
        55: "&",
        56: "*",
        57: "(",
        59: ":",
        61: "+",
        173: "_",
        186: ":",
        187: "+",
        188: "<",
        189: "_",
        190: ">",
        191: "?",
        192: "~",
        219: "{",
        220: "|",
        221: "}",
        222: '"'
      }, vK = "undefined" != typeof navigator && /Mac/.test(navigator.platform), CO = "undefined" != typeof navigator && /MSIE \d|Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent), hO = 0; hO < 10; hO++) eO[48 + hO] = eO[96 + hO] = String(hO);
    for (hO = 1; hO <= 24; hO++) eO[hO + 111] = "F" + hO;
    for (hO = 65; hO <= 90; hO++) eO[hO] = String.fromCharCode(hO + 32), lO[hO] = String.fromCharCode(hO);
    for (var DO in eO) lO.hasOwnProperty(DO) || (lO[DO] = eO[DO]);
    var MO = pO(39345);
    let aK = "undefined" != typeof navigator ? navigator : {
        userAgent: "",
        vendor: "",
        platform: ""
      },
      oO = "undefined" != typeof document ? document : {
        documentElement: {
          style: {}
        }
      };
    const FO = /Edge\/(\d+)/.exec(aK.userAgent),
      VO = /MSIE \d/.test(aK.userAgent),
      LO = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(aK.userAgent),
      QO = !!(VO || LO || FO),
      zK = !QO && /gecko\/(\d+)/i.test(aK.userAgent),
      AO = !QO && /Chrome\/(\d+)/.exec(aK.userAgent),
      fO = "webkitFontSmoothing" in oO.documentElement.style,
      dO = !QO && /Apple Computer/.test(aK.vendor),
      TO = dO && (/Mobile\/\w+/.test(aK.userAgent) || aK.maxTouchPoints > 2);
    var NO = {
      mac: TO || /Mac/.test(aK.platform),
      windows: /Win/.test(aK.platform),
      linux: /Linux|X11/.test(aK.platform),
      ie: QO,
      ie_version: VO ? oO.documentMode || 6 : LO ? +LO[1] : FO ? +FO[1] : 0,
      gecko: zK,
      gecko_version: zK ? +(/Firefox\/(\d+)/.exec(aK.userAgent) || [0, 0])[1] : 0,
      chrome: !!AO,
      chrome_version: AO ? +AO[1] : 0,
      ios: TO,
      android: /Android\b/.test(aK.userAgent),
      webkit: fO,
      webkit_version: fO ? +(/\bAppleWebKit\/(\d+)/.exec(aK.userAgent) || [0, 0])[1] : 0,
      safari: dO,
      safari_version: dO ? +(/\bVersion\/(\d+(\.\d+)?)/.exec(aK.userAgent) || [0, 0])[1] : 0,
      tabSize: null != oO.documentElement.style.tabSize ? "tab-size" : "-moz-tab-size"
    };

    function IO(OO, KO) {
      for (let pO in OO) "class" == pO && KO.class ? KO.class += " " + OO.class : "style" == pO && KO.style ? KO.style += ";" + OO.style : KO[pO] = OO[pO];
      return KO
    }
    const yK = Object.create(null);

    function gK(OO, KO, pO) {
      if (OO == KO) return !0;
      OO || (OO = yK), KO || (KO = yK);
      let XO = Object.keys(OO),
        bK = Object.keys(KO);
      if (XO.length - (pO && XO.indexOf(pO) > -1 ? 1 : 0) != bK.length - (pO && bK.indexOf(pO) > -1 ? 1 : 0)) return !1;
      for (let eO of XO)
        if (eO != pO && (-1 == bK.indexOf(eO) || OO[eO] !== KO[eO])) return !1;
      return !0
    }

    function uO(OO, KO, pO) {
      let XO = !1;
      if (KO)
        for (let bK in KO) pO && bK in pO || (XO = !0, "style" == bK ? OO.style.cssText = "" : OO.removeAttribute(bK));
      if (pO)
        for (let bK in pO) KO && KO[bK] == pO[bK] || (XO = !0, "style" == bK ? OO.style.cssText = pO[bK] : OO.setAttribute(bK, pO[bK]));
      return XO
    }

    function EO(OO) {
      let KO = Object.create(null);
      for (let pO = 0; pO < OO.attributes.length; pO++) {
        let XO = OO.attributes[pO];
        KO[XO.name] = XO.value
      }
      return KO
    }
    class jK {
      eq(OO) {
        return !1
      }
      updateDOM(OO, KO, pO) {
        return !1
      }
      compare(OO) {
        return this == OO || this.constructor == OO.constructor && this.eq(OO)
      }
      get estimatedHeight() {
        return -1
      }
      get lineBreaks() {
        return 0
      }
      ignoreEvent(OO) {
        return !0
      }
      coordsAt(OO, KO, pO) {
        return null
      }
      get isHidden() {
        return !1
      }
      get editable() {
        return !1
      }
      destroy(OO) {}
    }
    var YO = function(OO) {
      return OO[OO.Text = 0] = "Text", OO[OO.WidgetBefore = 1] = "WidgetBefore", OO[OO.WidgetAfter = 2] = "WidgetAfter", OO[OO.WidgetRange = 3] = "WidgetRange", OO
    }(YO || (YO = {}));
    class wO extends XO.A {
      constructor(OO, KO, pO, XO) {
        super(), this.startSide = OO, this.endSide = KO, this.widget = pO, this.spec = XO
      }
      get heightRelevant() {
        return !1
      }
      static mark(OO) {
        return new iK(OO)
      }
      static widget(OO) {
        let KO = Math.max(-1e4, Math.min(1e4, OO.side || 0)),
          pO = !!OO.block;
        return KO += pO && !OO.inlineOrder ? KO > 0 ? 3e8 : -4e8 : KO > 0 ? 1e8 : -1e8, new PO(OO, KO, KO, pO, OO.widget || null, !1)
      }
      static replace(OO) {
        let KO, pO, XO = !!OO.block;
        if (OO.isBlockGap) KO = -5e8, pO = 4e8;
        else {
          let {
            start: bK,
            end: eO
          } = mK(OO, XO);
          KO = (bK ? XO ? -3e8 : -1 : 5e8) - 1, pO = 1 + (eO ? XO ? 2e8 : 1 : -6e8)
        }
        return new PO(OO, KO, pO, XO, OO.widget || null, !0)
      }
      static line(OO) {
        return new rK(OO)
      }
      static set(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return XO.y.of(OO, KO)
      }
      hasHeight() {
        return !!this.widget && this.widget.estimatedHeight > -1
      }
    }
    wO.none = XO.y.empty;
    class iK extends wO {
      constructor(OO) {
        let {
          start: KO,
          end: pO
        } = mK(OO);
        super(KO ? -1 : 5e8, pO ? 1 : -6e8, null, OO), this.tagName = OO.tagName || "span", this.attrs = OO.class && OO.attributes ? IO(OO.attributes, {
          class: OO.class
        }) : OO.class ? {
          class: OO.class
        } : OO.attributes || yK
      }
      eq(OO) {
        return this == OO || OO instanceof iK && this.tagName == OO.tagName && gK(this.attrs, OO.attrs)
      }
      range(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO;
        if (OO >= KO) throw new RangeError("Mark decorations may not be empty");
        return super.range(OO, KO)
      }
    }
    iK.prototype.point = !1;
    class rK extends wO {
      constructor(OO) {
        super(-2e8, -2e8, null, OO)
      }
      eq(OO) {
        return OO instanceof rK && this.spec.class == OO.spec.class && gK(this.spec.attributes, OO.spec.attributes)
      }
      range(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO;
        if (KO != OO) throw new RangeError("Line decoration ranges must be zero-length");
        return super.range(OO, KO)
      }
    }
    rK.prototype.mapMode = XO.r.TrackBefore, rK.prototype.point = !0;
    class PO extends wO {
      constructor(OO, KO, pO, bK, eO, lO) {
        super(KO, pO, eO, OO), this.block = bK, this.isReplace = lO, this.mapMode = bK ? KO <= 0 ? XO.r.TrackBefore : XO.r.TrackAfter : XO.r.TrackDel
      }
      get type() {
        return this.startSide != this.endSide ? YO.WidgetRange : this.startSide <= 0 ? YO.WidgetBefore : YO.WidgetAfter
      }
      get heightRelevant() {
        return this.block || !!this.widget && (this.widget.estimatedHeight >= 5 || this.widget.lineBreaks > 0)
      }
      eq(OO) {
        return OO instanceof PO && (KO = this.widget, pO = OO.widget, KO == pO || !!(KO && pO && KO.compare(pO))) && this.block == OO.block && this.startSide == OO.startSide && this.endSide == OO.endSide;
        var KO, pO
      }
      range(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO;
        if (this.isReplace && (OO > KO || OO == KO && this.startSide > 0 && this.endSide <= 0)) throw new RangeError("Invalid range for replacement decoration");
        if (!this.isReplace && KO != OO) throw new RangeError("Widget decorations can only have zero-length ranges");
        return super.range(OO, KO)
      }
    }

    function mK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        {
          inclusiveStart: pO,
          inclusiveEnd: XO
        } = OO;
      return null == pO && (pO = OO.inclusive), null == XO && (XO = OO.inclusive), {
        start: null !== pO && void 0 !== pO ? pO : KO,
        end: null !== XO && void 0 !== XO ? XO : KO
      }
    }

    function sO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
        bK = pO.length - 1;
      bK >= 0 && pO[bK] + XO >= OO ? pO[bK] = Math.max(pO[bK], KO) : pO.push(OO, KO)
    }
    PO.prototype.point = !0;
    class HO extends XO.A {
      constructor(OO, KO) {
        super(), this.tagName = OO, this.attributes = KO
      }
      eq(OO) {
        return OO == this || OO instanceof HO && this.tagName == OO.tagName && gK(this.attributes, OO.attributes)
      }
      static create(OO) {
        return new HO(OO.tagName, OO.attributes || yK)
      }
      static set(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return XO.y.of(OO, KO)
      }
    }

    function RO(OO) {
      let KO;
      return KO = 11 == OO.nodeType ? OO.getSelection ? OO : OO.ownerDocument : OO, KO.getSelection()
    }

    function SO(OO, KO) {
      return !!KO && (OO == KO || OO.contains(1 != KO.nodeType ? KO.parentNode : KO))
    }

    function JO(OO, KO) {
      if (!KO.anchorNode) return !1;
      try {
        return SO(OO, KO.anchorNode)
      } catch (pO) {
        return !1
      }
    }

    function cK(OO) {
      return 3 == OO.nodeType ? XK(OO, 0, OO.nodeValue.length).getClientRects() : 1 == OO.nodeType ? OO.getClientRects() : []
    }

    function BO(OO, KO, pO, XO) {
      return !!pO && (qK(OO, KO, pO, XO, -1) || qK(OO, KO, pO, XO, 1))
    }

    function ZO(OO) {
      for (var KO = 0;; KO++)
        if (!(OO = OO.previousSibling)) return KO
    }

    function GO(OO) {
      return 1 == OO.nodeType && /^(DIV|P|LI|UL|OL|BLOCKQUOTE|DD|DT|H\d|SECTION|PRE)$/.test(OO.nodeName)
    }

    function qK(OO, KO, pO, XO, bK) {
      for (;;) {
        if (OO == pO && KO == XO) return !0;
        if (KO == (bK < 0 ? 0 : xK(OO))) {
          if ("DIV" == OO.nodeName) return !1;
          let pO = OO.parentNode;
          if (!pO || 1 != pO.nodeType) return !1;
          KO = ZO(OO) + (bK < 0 ? 0 : 1), OO = pO
        } else {
          if (1 != OO.nodeType) return !1;
          if (1 == (OO = OO.childNodes[KO + (bK < 0 ? -1 : 0)]).nodeType && "false" == OO.contentEditable) return !1;
          KO = bK < 0 ? xK(OO) : 0
        }
      }
    }

    function xK(OO) {
      return 3 == OO.nodeType ? OO.nodeValue.length : OO.childNodes.length
    }

    function nO(OO, KO) {
      let pO = KO ? OO.left : OO.right;
      return {
        left: pO,
        right: pO,
        top: OO.top,
        bottom: OO.bottom
      }
    }

    function WO(OO) {
      let KO = OO.visualViewport;
      return KO ? {
        left: 0,
        right: KO.width,
        top: 0,
        bottom: KO.height
      } : {
        left: 0,
        right: OO.innerWidth,
        top: 0,
        bottom: OO.innerHeight
      }
    }

    function tK(OO, KO) {
      let pO = KO.width / OO.offsetWidth,
        XO = KO.height / OO.offsetHeight;
      return (pO > .995 && pO < 1.005 || !isFinite(pO) || Math.abs(KO.width - OO.offsetWidth) < 1) && (pO = 1), (XO > .995 && XO < 1.005 || !isFinite(XO) || Math.abs(KO.height - OO.offsetHeight) < 1) && (XO = 1), {
        scaleX: pO,
        scaleY: XO
      }
    }

    function kK(OO) {
      let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
        pO = OO.ownerDocument,
        XO = null,
        bK = null;
      for (let eO = OO.parentNode; eO && (eO != pO.body && (KO && !XO || !bK));)
        if (1 == eO.nodeType) !bK && eO.scrollHeight > eO.clientHeight && (bK = eO), KO && !XO && eO.scrollWidth > eO.clientWidth && (XO = eO), eO = eO.assignedSlot || eO.parentNode;
        else {
          if (11 != eO.nodeType) break;
          eO = eO.host
        } return {
        x: XO,
        y: bK
      }
    }
    HO.prototype.startSide = HO.prototype.endSide = -1;
    class UO {
      constructor() {
        this.anchorNode = null, this.anchorOffset = 0, this.focusNode = null, this.focusOffset = 0
      }
      eq(OO) {
        return this.anchorNode == OO.anchorNode && this.anchorOffset == OO.anchorOffset && this.focusNode == OO.focusNode && this.focusOffset == OO.focusOffset
      }
      setRange(OO) {
        let {
          anchorNode: KO,
          focusNode: pO
        } = OO;
        this.set(KO, Math.min(OO.anchorOffset, KO ? xK(KO) : 0), pO, Math.min(OO.focusOffset, pO ? xK(pO) : 0))
      }
      set(OO, KO, pO, XO) {
        this.anchorNode = OO, this.anchorOffset = KO, this.focusNode = pO, this.focusOffset = XO
      }
    }
    let OK, KK = null;

    function pK(OO) {
      if (OO.setActive) return OO.setActive();
      if (KK) return OO.focus(KK);
      let KO = [];
      for (let pO = OO; pO && (KO.push(pO, pO.scrollTop, pO.scrollLeft), pO != pO.ownerDocument); pO = pO.parentNode);
      if (OO.focus(null == KK ? {
          get preventScroll() {
            return KK = {
              preventScroll: !0
            }, !0
          }
        } : void 0), !KK) {
        KK = !1;
        for (let OO = 0; OO < KO.length;) {
          let pO = KO[OO++],
            XO = KO[OO++],
            bK = KO[OO++];
          pO.scrollTop != XO && (pO.scrollTop = XO), pO.scrollLeft != bK && (pO.scrollLeft = bK)
        }
      }
    }

    function XK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : KO,
        XO = OK || (OK = document.createRange());
      return XO.setEnd(OO, pO), XO.setStart(OO, KO), XO
    }

    function bp(OO, KO, pO, XO) {
      let bK = {
        key: KO,
        code: KO,
        keyCode: pO,
        which: pO,
        cancelable: !0
      };
      XO && ({
        altKey: bK.altKey,
        ctrlKey: bK.ctrlKey,
        shiftKey: bK.shiftKey,
        metaKey: bK.metaKey
      } = XO);
      let eO = new KeyboardEvent("keydown", bK);
      eO.synthetic = !0, OO.dispatchEvent(eO);
      let lO = new KeyboardEvent("keyup", bK);
      return lO.synthetic = !0, OO.dispatchEvent(lO), eO.defaultPrevented || lO.defaultPrevented
    }

    function eK(OO) {
      return OO instanceof Window ? OO.pageYOffset > Math.max(0, OO.document.documentElement.scrollHeight - OO.innerHeight - 4) : OO.scrollTop > Math.max(1, OO.scrollHeight - OO.clientHeight - 4)
    }

    function lK(OO, KO) {
      for (let pO = OO, XO = KO;;) {
        if (3 == pO.nodeType && XO > 0) return {
          node: pO,
          offset: XO
        };
        if (1 == pO.nodeType && XO > 0) {
          if ("false" == pO.contentEditable) return null;
          pO = pO.childNodes[XO - 1], XO = xK(pO)
        } else {
          if (!pO.parentNode || GO(pO)) return null;
          XO = ZO(pO), pO = pO.parentNode
        }
      }
    }

    function vp(OO, KO) {
      for (let pO = OO, XO = KO;;) {
        if (3 == pO.nodeType && XO < pO.nodeValue.length) return {
          node: pO,
          offset: XO
        };
        if (1 == pO.nodeType && XO < pO.childNodes.length) {
          if ("false" == pO.contentEditable) return null;
          pO = pO.childNodes[XO], XO = 0
        } else {
          if (!pO.parentNode || GO(pO)) return null;
          XO = ZO(pO) + 1, pO = pO.parentNode
        }
      }
    }
    NO.safari && NO.safari_version >= 26 && (KK = !1);
    class CK {
      constructor(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        this.node = OO, this.offset = KO, this.precise = pO
      }
      static before(OO, KO) {
        return new CK(OO.parentNode, ZO(OO), KO)
      }
      static after(OO, KO) {
        return new CK(OO.parentNode, ZO(OO) + 1, KO)
      }
    }
    var hK = function(OO) {
      return OO[OO.LTR = 0] = "LTR", OO[OO.RTL = 1] = "RTL", OO
    }(hK || (hK = {}));
    const DK = hK.LTR,
      MK = hK.RTL;

    function ap(OO) {
      let KO = [];
      for (let pO = 0; pO < OO.length; pO++) KO.push(1 << +OO[pO]);
      return KO
    }
    const oK = ap("88888888888888888888888888888888888666888888787833333333337888888000000000000000000000000008888880000000000000000000000000088888888888888888888888888888888888887866668888088888663380888308888800000000000000000000000800000000000000000000000000000008"),
      FK = ap("4444448826627288999999999992222222222222222222222222222222222222222222222229999999999999999999994444444444644222822222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222999999949999999229989999223333333333"),
      VK = Object.create(null),
      LK = [];
    for (let Yl of ["()", "[]", "{}"]) {
      let OO = Yl.charCodeAt(0),
        KO = Yl.charCodeAt(1);
      VK[OO] = KO, VK[KO] = -OO
    }

    function QK(OO) {
      return OO <= 247 ? oK[OO] : 1424 <= OO && OO <= 1524 ? 2 : 1536 <= OO && OO <= 1785 ? FK[OO - 1536] : 1774 <= OO && OO <= 2220 ? 4 : 8192 <= OO && OO <= 8204 ? 256 : 64336 <= OO && OO <= 65023 ? 4 : 1
    }
    const zp = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac\ufb50-\ufdff]/;
    class AK {
      get dir() {
        return this.level % 2 ? MK : DK
      }
      constructor(OO, KO, pO) {
        this.from = OO, this.to = KO, this.level = pO
      }
      side(OO, KO) {
        return this.dir == KO == OO ? this.to : this.from
      }
      forward(OO, KO) {
        return OO == (this.dir == KO)
      }
      static find(OO, KO, pO, XO) {
        let bK = -1;
        for (let eO = 0; eO < OO.length; eO++) {
          let lO = OO[eO];
          if (lO.from <= KO && lO.to >= KO) {
            if (lO.level == pO) return eO;
            (bK < 0 || (0 != XO ? XO < 0 ? lO.from < KO : lO.to > KO : OO[bK].level > lO.level)) && (bK = eO)
          }
        }
        if (bK < 0) throw new RangeError("Index out of range");
        return bK
      }
    }

    function fK(OO, KO) {
      if (OO.length != KO.length) return !1;
      for (let pO = 0; pO < OO.length; pO++) {
        let XO = OO[pO],
          bK = KO[pO];
        if (XO.from != bK.from || XO.to != bK.to || XO.direction != bK.direction || !fK(XO.inner, bK.inner)) return !1
      }
      return !0
    }
    const dK = [];

    function TK(OO, KO, pO, XO, bK, eO, lO) {
      let vK = XO % 2 ? 2 : 1;
      if (XO % 2 == bK % 2)
        for (let CO = KO, hO = 0; CO < pO;) {
          let KO = !0,
            DO = !1;
          if (hO == eO.length || CO < eO[hO].from) {
            let OO = dK[CO];
            OO != vK && (KO = !1, DO = 16 == OO)
          }
          let MO = KO || 1 != vK ? null : [],
            aK = KO ? XO : XO + 1,
            oO = CO;
          OO: for (;;)
            if (hO < eO.length && oO == eO[hO].from) {
              if (DO) break OO;
              let FO = eO[hO];
              if (!KO)
                for (let OO = FO.to, KO = hO + 1;;) {
                  if (OO == pO) break OO;
                  if (!(KO < eO.length && eO[KO].from == OO)) {
                    if (dK[OO] == vK) break OO;
                    break
                  }
                  OO = eO[KO++].to
                }
              if (hO++, MO) MO.push(FO);
              else {
                FO.from > CO && lO.push(new AK(CO, FO.from, aK)), NK(OO, FO.direction == DK != !(aK % 2) ? XO + 1 : XO, bK, FO.inner, FO.from, FO.to, lO), CO = FO.to
              }
              oO = FO.to
            } else {
              if (oO == pO || (KO ? dK[oO] != vK : dK[oO] == vK)) break;
              oO++
            } MO ? TK(OO, CO, oO, XO + 1, bK, MO, lO) : CO < oO && lO.push(new AK(CO, oO, aK)), CO = oO
        } else
          for (let CO = pO, hO = eO.length; CO > KO;) {
            let pO = !0,
              DO = !1;
            if (!hO || CO > eO[hO - 1].to) {
              let OO = dK[CO - 1];
              OO != vK && (pO = !1, DO = 16 == OO)
            }
            let MO = pO || 1 != vK ? null : [],
              aK = pO ? XO : XO + 1,
              oO = CO;
            OO: for (;;)
              if (hO && oO == eO[hO - 1].to) {
                if (DO) break OO;
                let FO = eO[--hO];
                if (!pO)
                  for (let OO = FO.from, pO = hO;;) {
                    if (OO == KO) break OO;
                    if (!pO || eO[pO - 1].to != OO) {
                      if (dK[OO - 1] == vK) break OO;
                      break
                    }
                    OO = eO[--pO].from
                  }
                if (MO) MO.push(FO);
                else {
                  FO.to < CO && lO.push(new AK(FO.to, CO, aK)), NK(OO, FO.direction == DK != !(aK % 2) ? XO + 1 : XO, bK, FO.inner, FO.from, FO.to, lO), CO = FO.from
                }
                oO = FO.from
              } else {
                if (oO == KO || (pO ? dK[oO - 1] != vK : dK[oO - 1] == vK)) break;
                oO--
              } MO ? TK(OO, oO, CO, XO + 1, bK, MO, lO) : oO < CO && lO.push(new AK(oO, CO, aK)), CO = oO
          }
    }

    function NK(OO, KO, pO, XO, bK, eO, lO) {
      let vK = KO % 2 ? 2 : 1;
      ! function(OO, KO, pO, XO, bK) {
        for (let eO = 0; eO <= XO.length; eO++) {
          let lO = eO ? XO[eO - 1].to : KO,
            vK = eO < XO.length ? XO[eO].from : pO,
            CO = eO ? 256 : bK;
          for (let KO = lO, pO = CO, XO = CO; KO < vK; KO++) {
            let bK = QK(OO.charCodeAt(KO));
            512 == bK ? bK = pO : 8 == bK && 4 == XO && (bK = 16), dK[KO] = 4 == bK ? 2 : bK, 7 & bK && (XO = bK), pO = bK
          }
          for (let OO = lO, KO = CO, XO = CO; OO < vK; OO++) {
            let bK = dK[OO];
            if (128 == bK) OO < vK - 1 && KO == dK[OO + 1] && 24 & KO ? bK = dK[OO] = KO : dK[OO] = 256;
            else if (64 == bK) {
              let bK = OO + 1;
              for (; bK < vK && 64 == dK[bK];) bK++;
              let eO = OO && 8 == KO || bK < pO && 8 == dK[bK] ? 1 == XO ? 1 : 8 : 256;
              for (let KO = OO; KO < bK; KO++) dK[KO] = eO;
              OO = bK - 1
            } else 8 == bK && 1 == XO && (dK[OO] = 1);
            KO = bK, 7 & bK && (XO = bK)
          }
        }
      }(OO, bK, eO, XO, vK),
      function(OO, KO, pO, XO, bK) {
        let eO = 1 == bK ? 2 : 1;
        for (let lO = 0, vK = 0, CO = 0; lO <= XO.length; lO++) {
          let hO = lO ? XO[lO - 1].to : KO,
            DO = lO < XO.length ? XO[lO].from : pO;
          for (let KO, pO, XO, lO = hO; lO < DO; lO++)
            if (pO = VK[KO = OO.charCodeAt(lO)])
              if (pO < 0) {
                for (let OO = vK - 3; OO >= 0; OO -= 3)
                  if (LK[OO + 1] == -pO) {
                    let KO = LK[OO + 2],
                      pO = 2 & KO ? bK : 4 & KO ? 1 & KO ? eO : bK : 0;
                    pO && (dK[lO] = dK[LK[OO]] = pO), vK = OO;
                    break
                  }
              } else {
                if (189 == LK.length) break;
                LK[vK++] = lO, LK[vK++] = KO, LK[vK++] = CO
              }
          else if (2 == (XO = dK[lO]) || 1 == XO) {
            let OO = XO == bK;
            CO = OO ? 0 : 1;
            for (let KO = vK - 3; KO >= 0; KO -= 3) {
              let pO = LK[KO + 2];
              if (2 & pO) break;
              if (OO) LK[KO + 2] |= 2;
              else {
                if (4 & pO) break;
                LK[KO + 2] |= 4
              }
            }
          }
        }
      }(OO, bK, eO, XO, vK),
      function(OO, KO, pO, XO) {
        for (let bK = 0, eO = XO; bK <= pO.length; bK++) {
          let lO = bK ? pO[bK - 1].to : OO,
            vK = bK < pO.length ? pO[bK].from : KO;
          for (let CO = lO; CO < vK;) {
            let lO = dK[CO];
            if (256 == lO) {
              let lO = CO + 1;
              for (;;)
                if (lO == vK) {
                  if (bK == pO.length) break;
                  lO = pO[bK++].to, vK = bK < pO.length ? pO[bK].from : KO
                } else {
                  if (256 != dK[lO]) break;
                  lO++
                } let hO = 1 == eO,
                DO = hO == (1 == (lO < KO ? dK[lO] : XO)) ? hO ? 1 : 2 : XO;
              for (let KO = lO, XO = bK, eO = XO ? pO[XO - 1].to : OO; KO > CO;) KO == eO && (KO = pO[--XO].from, eO = XO ? pO[XO - 1].to : OO), dK[--KO] = DO;
              CO = lO
            } else eO = lO, CO++
          }
        }
      }(bK, eO, XO, vK), TK(OO, bK, eO, KO, pO, XO, lO)
    }

    function IK(OO, KO, pO) {
      if (!OO) return [new AK(0, 0, KO == MK ? 1 : 0)];
      if (KO == DK && !pO.length && !zp.test(OO)) return yp(OO.length);
      if (pO.length)
        for (; OO.length > dK.length;) dK[dK.length] = 256;
      let XO = [],
        bK = KO == DK ? 0 : 1;
      return NK(OO, bK, bK, pO, 0, OO.length, XO), XO
    }

    function yp(OO) {
      return [new AK(0, OO, 0)]
    }
    let gp = "";

    function uK(OO, KO, pO, bK, eO) {
      var lO;
      let vK = bK.head - OO.from,
        CO = AK.find(KO, vK, null !== (lO = bK.bidiLevel) && void 0 !== lO ? lO : -1, bK.assoc),
        hO = KO[CO],
        DO = hO.side(eO, pO);
      if (vK == DO) {
        let OO = CO += eO ? 1 : -1;
        if (OO < 0 || OO >= KO.length) return null;
        hO = KO[CO = OO], vK = hO.side(!eO, pO), DO = hO.side(eO, pO)
      }
      let MO = (0, XO.Y)(OO.text, vK, hO.forward(eO, pO));
      (MO < hO.from || MO > hO.to) && (MO = DO), gp = OO.text.slice(Math.min(vK, MO), Math.max(vK, MO));
      let aK = CO == (eO ? KO.length - 1 : 0) ? null : KO[CO + (eO ? 1 : -1)];
      return aK && MO == DO && aK.level + (eO ? 0 : 1) < hO.level ? XO.j.cursor(aK.side(!eO, pO) + OO.from, aK.forward(eO, pO) ? 1 : -1, aK.level) : XO.j.cursor(MO + OO.from, hO.forward(eO, pO) ? -1 : 1, hO.level)
    }

    function EK(OO, KO, pO) {
      for (let XO = KO; XO < pO; XO++) {
        let KO = QK(OO.charCodeAt(XO));
        if (1 == KO) return DK;
        if (2 == KO || 4 == KO) return MK
      }
      return DK
    }
    const jp = XO.n.define(),
      YK = XO.n.define(),
      wK = XO.n.define(),
      ip = XO.n.define(),
      rp = XO.n.define(),
      PK = XO.n.define(),
      mp = XO.n.define(),
      sK = XO.n.define(),
      HK = XO.n.define(),
      RK = XO.n.define({
        combine: OO => OO.some((OO => OO))
      }),
      SK = XO.n.define({
        combine: OO => OO.some((OO => OO))
      }),
      JK = XO.n.define();
    class cp {
      constructor(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
        this.range = OO, this.y = KO, this.x = pO, this.yMargin = XO, this.xMargin = bK, this.isSnapshot = eO
      }
      map(OO) {
        return OO.empty ? this : new cp(this.range.map(OO), this.y, this.x, this.yMargin, this.xMargin, this.isSnapshot)
      }
      clip(OO) {
        return this.range.to <= OO.doc.length ? this : new cp(XO.j.cursor(OO.doc.length), this.y, this.x, this.yMargin, this.xMargin, this.isSnapshot)
      }
    }
    const BK = XO.C.define({
        map: (OO, KO) => OO.map(KO)
      }),
      ZK = XO.C.define();

    function GK(OO, KO, pO) {
      let XO = OO.facet(ip);
      XO.length ? XO[0](KO) : window.onerror && window.onerror(String(KO), pO, void 0, void 0, KO) || (pO ? console.error(pO + ":", KO) : console.error(KO))
    }
    const qp = XO.n.define({
      combine: OO => !OO.length || OO[0]
    });
    let xp = 0;
    const nK = XO.n.define({
      combine: OO => OO.filter(((KO, pO) => {
        for (let XO = 0; XO < pO; XO++)
          if (OO[XO].plugin == KO.plugin) return !1;
        return !0
      }))
    });
    class WK {
      constructor(OO, KO, pO, XO, bK) {
        this.id = OO, this.create = KO, this.domEventHandlers = pO, this.domEventObservers = XO, this.baseExtensions = bK(this), this.extension = this.baseExtensions.concat(nK.of({
          plugin: this,
          arg: void 0
        }))
      }
      of(OO) {
        return this.baseExtensions.concat(nK.of({
          plugin: this,
          arg: OO
        }))
      }
      static define(OO, KO) {
        const {
          eventHandlers: pO,
          eventObservers: XO,
          provide: bK,
          ql: eO
        } = KO || {};
        return new WK(xp++, OO, pO, XO, (OO => {
          let KO = [];
          return eO && KO.push(Op.of((KO => {
            let pO = KO.plugin(OO);
            return pO ? eO(pO) : wO.none
          }))), bK && KO.push(bK(OO)), KO
        }))
      }
      static fromClass(OO, KO) {
        return WK.define(((KO, pO) => new OO(KO, pO)), KO)
      }
    }
    class tp {
      constructor(OO) {
        this.spec = OO, this.mustUpdate = null, this.value = null
      }
      get plugin() {
        return this.spec && this.spec.plugin
      }
      update(OO) {
        if (this.value) {
          if (this.mustUpdate) {
            let OO = this.mustUpdate;
            if (this.mustUpdate = null, this.value.update) try {
              this.value.update(OO)
            } catch (KO) {
              if (GK(OO.state, KO, "CodeMirror plugin crashed"), this.value.destroy) try {
                this.value.destroy()
              } catch (pO) {}
              this.deactivate()
            }
          }
        } else if (this.spec) try {
          this.value = this.spec.plugin.create(OO, this.spec.arg)
        } catch (KO) {
          GK(OO.state, KO, "CodeMirror plugin crashed"), this.deactivate()
        }
        return this
      }
      destroy(OO) {
        var KO;
        if (null === (KO = this.value) || void 0 === KO ? void 0 : KO.destroy) try {
          this.value.destroy()
        } catch (pO) {
          GK(OO.state, pO, "CodeMirror plugin crashed")
        }
      }
      deactivate() {
        this.spec = this.value = null
      }
    }
    const kp = XO.n.define(),
      UK = XO.n.define(),
      Op = XO.n.define(),
      Kp = XO.n.define(),
      pp = XO.n.define(),
      Xp = XO.n.define(),
      bX = XO.n.define();

    function ep(OO, KO) {
      let pO = OO.state.facet(bX);
      if (!pO.length) return pO;
      let bK = pO.map((KO => KO instanceof Function ? KO(OO) : KO)),
        eO = [];
      return XO.y.spans(bK, KO.from, KO.to, {
        point() {},
        span(OO, pO, XO, bK) {
          let lO = OO - KO.from,
            vK = pO - KO.from,
            CO = eO;
          for (let eO = XO.length - 1; eO >= 0; eO--, bK--) {
            let OO, pO = XO[eO].spec.bidiIsolate;
            if (null == pO && (pO = EK(KO.text, lO, vK)), bK > 0 && CO.length && (OO = CO[CO.length - 1]).to == lO && OO.direction == pO) OO.to = vK, CO = OO.inner;
            else {
              let OO = {
                from: lO,
                to: vK,
                direction: pO,
                inner: []
              };
              CO.push(OO), CO = OO.inner
            }
          }
        }
      }), eO
    }
    const lp = XO.n.define();

    function vX(OO) {
      let KO = 0,
        pO = 0,
        XO = 0,
        bK = 0;
      for (let eO of OO.state.facet(lp)) {
        let lO = eO(OO);
        lO && (null != lO.left && (KO = Math.max(KO, lO.left)), null != lO.right && (pO = Math.max(pO, lO.right)), null != lO.top && (XO = Math.max(XO, lO.top)), null != lO.bottom && (bK = Math.max(bK, lO.bottom)))
      }
      return {
        left: KO,
        right: pO,
        top: XO,
        bottom: bK
      }
    }
    const Cp = XO.n.define();
    class hp {
      constructor(OO, KO, pO, XO) {
        this.fromA = OO, this.toA = KO, this.fromB = pO, this.toB = XO
      }
      join(OO) {
        return new hp(Math.min(this.fromA, OO.fromA), Math.max(this.toA, OO.toA), Math.min(this.fromB, OO.fromB), Math.max(this.toB, OO.toB))
      }
      addToSet(OO) {
        let KO = OO.length,
          pO = this;
        for (; KO > 0; KO--) {
          let XO = OO[KO - 1];
          if (!(XO.fromA > pO.toA)) {
            if (XO.toA < pO.fromA) break;
            pO = pO.join(XO), OO.splice(KO - 1, 1)
          }
        }
        return OO.splice(KO, 0, pO), OO
      }
      static extendWithRanges(OO, KO) {
        if (0 == KO.length) return OO;
        let pO = [];
        for (let XO = 0, bK = 0, eO = 0;;) {
          let lO = XO < OO.length ? OO[XO].fromB : 1e9,
            vK = bK < KO.length ? KO[bK] : 1e9,
            CO = Math.min(lO, vK);
          if (1e9 == CO) break;
          let hO = CO + eO,
            DO = CO,
            MO = hO;
          for (;;)
            if (bK < KO.length && KO[bK] <= DO) {
              let pO = KO[bK + 1];
              bK += 2, DO = Math.max(DO, pO);
              for (let KO = XO; KO < OO.length && OO[KO].fromB <= DO; KO++) eO = OO[KO].toA - OO[KO].toB;
              MO = Math.max(MO, pO + eO)
            } else {
              if (!(XO < OO.length && OO[XO].fromB <= DO)) break;
              {
                let KO = OO[XO++];
                DO = Math.max(DO, KO.toB), MO = Math.max(MO, KO.toA), eO = KO.toA - KO.toB
              }
            } pO.push(new hp(hO, MO, CO, DO))
        }
        return pO
      }
    }
    class Dp {
      constructor(OO, KO, pO) {
        this.view = OO, this.state = KO, this.transactions = pO, this.flags = 0, this.startState = OO.state, this.changes = XO.ChangeSet.empty(this.startState.doc.length);
        for (let XO of pO) this.changes = this.changes.compose(XO.changes);
        let bK = [];
        this.changes.iterChangedRanges(((OO, KO, pO, XO) => bK.push(new hp(OO, KO, pO, XO)))), this.changedRanges = bK
      }
      static create(OO, KO, pO) {
        return new Dp(OO, KO, pO)
      }
      get viewportChanged() {
        return (4 & this.flags) > 0
      }
      get viewportMoved() {
        return (8 & this.flags) > 0
      }
      get heightChanged() {
        return (2 & this.flags) > 0
      }
      get geometryChanged() {
        return this.docChanged || (18 & this.flags) > 0
      }
      get focusChanged() {
        return (1 & this.flags) > 0
      }
      get docChanged() {
        return !this.changes.empty
      }
      get selectionSet() {
        return this.transactions.some((OO => OO.selection))
      }
      get empty() {
        return 0 == this.flags && 0 == this.transactions.length
      }
    }
    const Mp = [];
    class aX {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        this.dom = OO, this.length = KO, this.flags = pO, this.parent = null, OO.cmTile = this
      }
      get breakAfter() {
        return 1 & this.flags
      }
      get children() {
        return Mp
      }
      isWidget() {
        return !1
      }
      get isHidden() {
        return !1
      }
      isComposite() {
        return !1
      }
      isLine() {
        return !1
      }
      isText() {
        return !1
      }
      isBlock() {
        return !1
      }
      get domAttrs() {
        return null
      }
      sync(OO) {
        if (this.flags |= 2, 4 & this.flags) {
          this.flags &= -5;
          let OO = this.domAttrs;
          OO && function(OO, KO) {
            for (let pO = OO.attributes.length - 1; pO >= 0; pO--) {
              let XO = OO.attributes[pO].name;
              null == KO[XO] && OO.removeAttribute(XO)
            }
            for (let pO in KO) {
              let XO = KO[pO];
              "style" == pO ? OO.style.cssText = XO : OO.getAttribute(pO) != XO && OO.setAttribute(pO, XO)
            }
          }(this.dom, OO)
        }
      }
      toString() {
        return this.constructor.name + (this.children.length ? `(${this.children})` : "") + (this.breakAfter ? "#" : "")
      }
      destroy() {
        this.parent = null
      }
      setDOM(OO) {
        this.dom = OO, OO.cmTile = this
      }
      get posAtStart() {
        return this.parent ? this.parent.posBefore(this) : 0
      }
      get posAtEnd() {
        return this.posAtStart + this.length
      }
      posBefore(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.posAtStart;
        for (let pO of this.children) {
          if (pO == OO) return KO;
          KO += pO.length + pO.breakAfter
        }
        throw new RangeError("Invalid child in posBefore")
      }
      posAfter(OO) {
        return this.posBefore(OO) + OO.length
      }
      covers(OO) {
        return !0
      }
      coordsIn(OO, KO) {
        return null
      }
      domPosFor(OO, KO) {
        let pO = ZO(this.dom),
          XO = this.length ? OO > 0 : KO > 0;
        return new CK(this.parent.dom, pO + (XO ? 1 : 0), 0 == OO || OO == this.length)
      }
      markDirty(OO) {
        this.flags &= -3, OO && (this.flags |= 4), this.parent && 2 & this.parent.flags && this.parent.markDirty(!1)
      }
      get overrideDOMText() {
        return null
      }
      get root() {
        for (let OO = this; OO; OO = OO.parent)
          if (OO instanceof Vp) return OO;
        return null
      }
      static get(OO) {
        return OO.cmTile
      }
    }
    class op extends aX {
      constructor(OO) {
        super(OO, 0), this._children = []
      }
      isComposite() {
        return !0
      }
      get children() {
        return this._children
      }
      get lastChild() {
        return this.children.length ? this.children[this.children.length - 1] : null
      }
      append(OO) {
        this.children.push(OO), OO.parent = this
      }
      sync(OO) {
        if (2 & this.flags) return;
        super.sync(OO);
        let KO, pO = this.dom,
          XO = null,
          bK = (null === OO || void 0 === OO ? void 0 : OO.node) == pO ? OO : null,
          eO = 0;
        for (let lO of this.children) {
          if (lO.sync(OO), eO += lO.length + lO.breakAfter, KO = XO ? XO.nextSibling : pO.firstChild, bK && KO != lO.dom && (bK.written = !0), lO.dom.parentNode == pO)
            for (; KO && KO != lO.dom;) KO = Fp(KO);
          else pO.insertBefore(lO.dom, KO);
          XO = lO.dom
        }
        for (KO = XO ? XO.nextSibling : pO.firstChild, bK && KO && (bK.written = !0); KO;) KO = Fp(KO);
        this.length = eO
      }
    }

    function Fp(OO) {
      let KO = OO.nextSibling;
      return OO.parentNode.removeChild(OO), KO
    }
    class Vp extends op {
      constructor(OO, KO) {
        super(KO), this.view = OO
      }
      owns(OO) {
        for (; OO; OO = OO.parent)
          if (OO == this) return !0;
        return !1
      }
      isBlock() {
        return !0
      }
      nearest(OO) {
        for (;;) {
          if (!OO) return null;
          let KO = aX.get(OO);
          if (KO && this.owns(KO)) return KO;
          OO = OO.parentNode
        }
      }
      blockTiles(OO) {
        for (let KO = [], pO = this, XO = 0, bK = 0;;)
          if (XO == pO.children.length) {
            if (!KO.length) return;
            pO = pO.parent, pO.breakAfter && bK++, XO = KO.pop()
          } else {
            let eO = pO.children[XO++];
            if (eO instanceof Lp) KO.push(XO), pO = eO, XO = 0;
            else {
              let KO = bK + eO.length,
                pO = OO(eO, bK);
              if (void 0 !== pO) return pO;
              bK = KO + eO.breakAfter
            }
          }
      }
      resolveBlock(OO, KO) {
        let pO, XO, bK = -1,
          eO = -1;
        if (this.blockTiles(((lO, vK) => {
            let CO = vK + lO.length;
            if (OO >= vK && OO <= CO) {
              if (lO.isWidget() && KO >= -1 && KO <= 1) {
                if (32 & lO.flags) return !0;
                16 & lO.flags && (pO = void 0)
              }(vK < OO || OO == CO && (KO < -1 ? lO.length : lO.covers(1))) && (!pO || !lO.isWidget() && pO.isWidget()) && (pO = lO, bK = OO - vK), (CO > OO || OO == vK && (KO > 1 ? lO.length : lO.covers(-1))) && (!XO || !lO.isWidget() && XO.isWidget()) && (XO = lO, eO = OO - vK)
            }
          })), !pO && !XO) throw new Error("No tile at position " + OO);
        return pO && KO < 0 || !XO ? {
          tile: pO,
          offset: bK
        } : {
          tile: XO,
          offset: eO
        }
      }
    }
    class Lp extends op {
      constructor(OO, KO) {
        super(OO), this.wrapper = KO
      }
      isBlock() {
        return !0
      }
      covers(OO) {
        return !!this.children.length && (OO < 0 ? this.children[0].covers(-1) : this.lastChild.covers(1))
      }
      get domAttrs() {
        return this.wrapper.attributes
      }
      static of (OO, KO) {
        let pO = new Lp(KO || document.createElement(OO.tagName), OO);
        return KO || (pO.flags |= 4), pO
      }
    }
    class Qp extends op {
      constructor(OO, KO) {
        super(OO), this.attrs = KO
      }
      isLine() {
        return !0
      }
      static start(OO, KO, pO) {
        let XO = new Qp(KO || document.createElement("div"), OO);
        return KO && pO || (XO.flags |= 4), XO
      }
      get domAttrs() {
        return this.attrs
      }
      resolveInline(OO, KO, pO) {
        let XO = null,
          bK = -1,
          eO = null,
          lO = -1;
        ! function OO(vK, CO) {
          for (let hO = 0, DO = 0; hO < vK.children.length && DO <= CO; hO++) {
            let MO = vK.children[hO],
              aK = DO + MO.length;
            aK >= CO && (MO.isComposite() ? OO(MO, CO - DO) : (!eO || eO.isHidden && (KO > 0 || pO && zX(eO, MO))) && (aK > CO || 32 & MO.flags) ? (eO = MO, lO = CO - DO) : (DO < CO || 16 & MO.flags && !MO.isHidden) && (XO = MO, bK = CO - DO)), DO = aK
          }
        }(this, OO);
        let vK = (KO < 0 ? XO : eO) || XO || eO;
        return vK ? {
          tile: vK,
          offset: vK == XO ? bK : lO
        } : null
      }
      coordsIn(OO, KO) {
        let pO = this.resolveInline(OO, KO, !0);
        return pO ? pO.tile.coordsIn(Math.max(0, pO.offset), KO) : function(OO) {
          let KO = OO.dom.lastChild;
          if (!KO) return OO.dom.getBoundingClientRect();
          let pO = cK(KO);
          return pO[pO.length - 1] || null
        }(this)
      }
      domIn(OO, KO) {
        let pO = this.resolveInline(OO, KO);
        if (pO) {
          let {
            tile: OO,
            offset: XO
          } = pO;
          if (this.dom.contains(OO.dom)) return OO.isText() ? new CK(OO.dom, Math.min(OO.dom.nodeValue.length, XO)) : OO.domPosFor(XO, 16 & OO.flags ? 1 : 32 & OO.flags ? -1 : KO);
          let bK = pO.tile.parent,
            eO = !1;
          for (let KO of bK.children) {
            if (eO) return new CK(KO.dom, 0);
            KO == pO.tile && (eO = !0)
          }
        }
        return new CK(this.dom, 0)
      }
    }

    function zX(OO, KO) {
      let pO = OO.coordsIn(0, 1),
        XO = KO.coordsIn(0, 1);
      return pO && XO && XO.top < pO.bottom
    }
    class Ap extends op {
      constructor(OO, KO) {
        super(OO), this.mark = KO
      }
      get domAttrs() {
        return this.mark.attrs
      }
      static of (OO, KO) {
        let pO = new Ap(KO || document.createElement(OO.tagName), OO);
        return KO || (pO.flags |= 4), pO
      }
    }
    class fp extends aX {
      constructor(OO, KO) {
        super(OO, KO.length), this.text = KO
      }
      sync(OO) {
        2 & this.flags || (super.sync(OO), this.dom.nodeValue != this.text && (OO && OO.node == this.dom && (OO.written = !0), this.dom.nodeValue = this.text))
      }
      isText() {
        return !0
      }
      toString() {
        return JSON.stringify(this.text)
      }
      coordsIn(OO, KO) {
        let pO = this.dom.nodeValue.length;
        OO > pO && (OO = pO);
        let XO = OO,
          bK = OO,
          eO = 0;
        0 == OO && KO < 0 || OO == pO && KO >= 0 ? NO.chrome || NO.gecko || (OO ? (XO--, eO = 1) : bK < pO && (bK++, eO = -1)) : KO < 0 ? XO-- : bK < pO && bK++;
        let lO = XK(this.dom, XO, bK).getClientRects();
        if (!lO.length) return null;
        let vK = lO[(eO ? eO < 0 : KO >= 0) ? 0 : lO.length - 1];
        return NO.safari && !eO && 0 == vK.width && (vK = Array.prototype.find.call(lO, (OO => OO.width)) || vK), eO ? nO(vK, eO < 0) : vK || null
      }
      static of (OO, KO) {
        let pO = new fp(KO || document.createTextNode(OO), OO);
        return KO || (pO.flags |= 2), pO
      }
    }
    class dp extends aX {
      constructor(OO, KO, pO, XO) {
        super(OO, KO, XO), this.widget = pO
      }
      isWidget() {
        return !0
      }
      get isHidden() {
        return this.widget.isHidden
      }
      covers(OO) {
        return !(48 & this.flags) && (this.flags & (OO < 0 ? 64 : 128)) > 0
      }
      coordsIn(OO, KO) {
        return this.coordsInWidget(OO, KO, !1)
      }
      coordsInWidget(OO, KO, pO) {
        let XO = this.widget.coordsAt(this.dom, OO, KO);
        if (XO) return XO;
        if (pO) return nO(this.dom.getBoundingClientRect(), this.length ? 0 == OO : KO <= 0);
        {
          let KO = this.dom.getClientRects(),
            pO = null;
          if (!KO.length) return null;
          let XO = !!(16 & this.flags) || !(32 & this.flags) && OO > 0;
          for (let bK = XO ? KO.length - 1 : 0; pO = KO[bK], !(OO > 0 ? 0 == bK : bK == KO.length - 1 || pO.top < pO.bottom); bK += XO ? -1 : 1);
          return nO(pO, !XO)
        }
      }
      get overrideDOMText() {
        if (!this.length) return XO.I.empty;
        let {
          root: OO
        } = this;
        if (!OO) return XO.I.empty;
        let KO = this.posAtStart;
        return OO.view.state.doc.slice(KO, KO + this.length)
      }
      destroy() {
        super.destroy(), this.widget.destroy(this.dom)
      }
      static of (OO, KO, pO, XO, bK) {
        return bK || (bK = OO.toDOM(KO), OO.editable || (bK.contentEditable = "false")), new dp(bK, pO, OO, XO)
      }
    }
    class Tp extends aX {
      constructor(OO) {
        let KO = document.createElement("img");
        KO.className = "cm-widgetBuffer", KO.setAttribute("aria-hidden", "true"), super(KO, 0, OO)
      }
      get isHidden() {
        return !0
      }
      get overrideDOMText() {
        return XO.I.empty
      }
      coordsIn(OO) {
        return this.dom.getBoundingClientRect()
      }
    }
    class Np {
      constructor(OO) {
        this.index = 0, this.beforeBreak = !1, this.parents = [], this.tile = OO
      }
      advance(OO, KO, pO) {
        let {
          tile: XO,
          index: bK,
          beforeBreak: eO,
          parents: lO
        } = this;
        for (; OO || KO > 0;)
          if (XO.isComposite())
            if (eO) {
              if (!OO) break;
              pO && pO.break(), OO--, eO = !1
            } else if (bK == XO.children.length) {
          if (!OO && !lO.length) break;
          pO && pO.DX(XO), eO = !!XO.breakAfter, ({
            tile: XO,
            index: bK
          } = lO.pop()), bK++
        } else {
          let vK = XO.children[bK],
            CO = vK.breakAfter;
          !(KO > 0 ? vK.length <= OO : vK.length < OO) || pO && !1 === pO.skip(vK, 0, vK.length) && vK.isComposite ? (lO.push({
            tile: XO,
            index: bK
          }), XO = vK, bK = 0, pO && vK.isComposite() && pO.enter(vK)) : (eO = !!CO, bK++, OO -= vK.length)
        } else if (bK == XO.length) eO = !!XO.breakAfter, ({
          tile: XO,
          index: bK
        } = lO.pop()), bK++;
        else {
          if (!OO) break;
          {
            let KO = Math.min(OO, XO.length - bK);
            pO && pO.skip(XO, bK, bK + KO), OO -= KO, bK += KO
          }
        }
        return this.tile = XO, this.index = bK, this.beforeBreak = eO, this
      }
      get root() {
        return this.parents.length ? this.parents[0].tile : this.tile
      }
    }
    class Ip {
      constructor(OO, KO, pO, XO) {
        this.from = OO, this.to = KO, this.wrapper = pO, this.rank = XO
      }
    }
    class yX {
      constructor(OO, KO, pO) {
        this.cache = OO, this.root = KO, this.blockWrappers = pO, this.curLine = null, this.lastBlock = null, this.afterWidget = null, this.pos = 0, this.wrappers = [], this.wrapperPos = 0
      }
      addText(OO, KO, pO, XO) {
        var bK;
        this.flushBuffer();
        let eO = this.ensureMarks(KO, pO),
          lO = eO.lastChild;
        if (lO && lO.isText() && !(8 & lO.flags) && lO.length + OO.length < 512) {
          this.cache.reused.set(lO, 2), (eO.children[eO.children.length - 1] = new fp(lO.dom, lO.text + OO)).parent = eO
        } else eO.append(XO || fp.of(OO, null === (bK = this.cache.find(fp)) || void 0 === bK ? void 0 : bK.dom));
        this.pos += OO.length, this.afterWidget = null
      }
      addComposition(OO, KO) {
        let pO = this.curLine;
        pO.dom != KO.line.dom && (pO.setDOM(this.cache.reused.has(KO.line) ? iX(KO.line.dom) : KO.line.dom), this.cache.reused.set(KO.line, 2));
        let XO = pO;
        for (let lO = KO.marks.length - 1; lO >= 0; lO--) {
          let OO = KO.marks[lO],
            pO = XO.lastChild;
          if (pO instanceof Ap && pO.mark.eq(OO.mark)) pO.dom != OO.dom && pO.setDOM(iX(OO.dom)), XO = pO;
          else {
            if (this.cache.reused.get(OO)) {
              let KO = aX.get(OO.dom);
              KO && KO.setDOM(iX(OO.dom))
            }
            let KO = Ap.of(OO.mark, OO.dom);
            XO.append(KO), XO = KO
          }
          this.cache.reused.set(OO, 2)
        }
        let bK = aX.get(OO.text);
        bK && this.cache.reused.set(bK, 2);
        let eO = new fp(OO.text, OO.text.nodeValue);
        eO.flags |= 8, XO.append(eO)
      }
      addInlineWidget(OO, KO, pO) {
        let XO = this.afterWidget && 48 & OO.flags && (48 & this.afterWidget.flags) == (48 & OO.flags);
        XO || this.flushBuffer();
        let bK = this.ensureMarks(KO, pO);
        XO || 16 & OO.flags || bK.append(this.getBuffer(1)), bK.append(OO), this.pos += OO.length, this.afterWidget = OO
      }
      addMark(OO, KO, pO) {
        this.flushBuffer(), this.ensureMarks(KO, pO).append(OO), this.pos += OO.length, this.afterWidget = null
      }
      addBlockWidget(OO) {
        this.getBlockPos().append(OO), this.pos += OO.length, this.lastBlock = OO, this.endLine()
      }
      continueWidget(OO) {
        (this.afterWidget || this.lastBlock).length += OO, this.pos += OO
      }
      addLineStart(OO, KO) {
        var pO;
        OO || (OO = wp);
        let XO = Qp.start(OO, KO || (null === (pO = this.cache.find(Qp)) || void 0 === pO ? void 0 : pO.dom), !!KO);
        this.getBlockPos().append(this.lastBlock = this.curLine = XO)
      }
      addLine(OO) {
        this.getBlockPos().append(OO), this.pos += OO.length, this.lastBlock = OO, this.endLine()
      }
      addBreak() {
        this.lastBlock.flags |= 1, this.endLine(), this.pos++
      }
      addLineStartIfNotCovered(OO) {
        this.blockPosCovered() || this.addLineStart(OO)
      }
      ensureLine(OO) {
        this.curLine || this.addLineStart(OO)
      }
      ensureMarks(OO, KO) {
        var pO;
        let XO = this.curLine;
        for (let bK = OO.length - 1; bK >= 0; bK--) {
          let eO, lO = OO[bK];
          if (KO > 0 && (eO = XO.lastChild) && eO instanceof Ap && eO.mark.eq(lO)) XO = eO, KO--;
          else {
            let OO = Ap.of(lO, null === (pO = this.cache.find(Ap, (OO => OO.mark.eq(lO)))) || void 0 === pO ? void 0 : pO.dom);
            XO.append(OO), XO = OO, KO = 0
          }
        }
        return XO
      }
      endLine() {
        if (this.curLine) {
          this.flushBuffer();
          let OO = this.curLine.lastChild;
          OO && Yp(this.curLine, !1) && ("BR" == OO.dom.nodeName || !OO.isWidget() || NO.ios && Yp(this.curLine, !0)) || this.curLine.append(this.cache.findWidget(Pp, 0, 32) || new dp(Pp.toDOM(), 0, Pp, 32)), this.curLine = this.afterWidget = null
        }
      }
      updateBlockWrappers() {
        this.wrapperPos > this.pos + 1e4 && (this.blockWrappers.goto(this.pos), this.wrappers.length = 0);
        for (let OO = this.wrappers.length - 1; OO >= 0; OO--) this.wrappers[OO].to < this.pos && this.wrappers.splice(OO, 1);
        for (let OO = this.blockWrappers; OO.value && OO.from <= this.pos; OO.next())
          if (OO.to >= this.pos) {
            let KO = new Ip(OO.from, OO.to, OO.value, OO.rank),
              pO = this.wrappers.length;
            for (; pO > 0 && (this.wrappers[pO - 1].rank - KO.rank || this.wrappers[pO - 1].to - KO.to) < 0;) pO--;
            this.wrappers.splice(pO, 0, KO)
          } this.wrapperPos = this.pos
      }
      getBlockPos() {
        var OO;
        this.updateBlockWrappers();
        let KO = this.root;
        for (let pO of this.wrappers) {
          let XO = KO.lastChild;
          if (pO.from < this.pos && XO instanceof Lp && XO.wrapper.eq(pO.wrapper)) KO = XO;
          else {
            let XO = Lp.of(pO.wrapper, null === (OO = this.cache.find(Lp, (OO => OO.wrapper.eq(pO.wrapper)))) || void 0 === OO ? void 0 : OO.dom);
            KO.append(XO), KO = XO
          }
        }
        return KO
      }
      blockPosCovered() {
        let OO = this.lastBlock;
        return null != OO && !OO.breakAfter && (!OO.isWidget() || (160 & OO.flags) > 0)
      }
      getBuffer(OO) {
        let KO = 2 | (OO < 0 ? 16 : 32),
          pO = this.cache.find(Tp, void 0, 1);
        return pO && (pO.flags = KO), pO || new Tp(KO)
      }
      flushBuffer() {
        !this.afterWidget || 32 & this.afterWidget.flags || (this.afterWidget.parent.append(this.getBuffer(-1)), this.afterWidget = null)
      }
    }
    class gX {
      constructor(OO) {
        this.skipCount = 0, this.text = "", this.textOff = 0, this.cursor = OO.iter()
      }
      skip(OO) {
        this.textOff + OO <= this.text.length ? this.textOff += OO : (this.skipCount += OO - (this.text.length - this.textOff), this.text = "", this.textOff = 0)
      }
      next(OO) {
        if (this.textOff == this.text.length) {
          let {
            value: KO,
            lineBreak: pO,
            done: XO
          } = this.cursor.next(this.skipCount);
          if (this.skipCount = 0, XO) throw new Error("Ran out of text content when drawing inline views");
          this.text = KO;
          let bK = this.textOff = Math.min(OO, KO.length);
          return pO ? null : KO.slice(0, bK)
        }
        let KO = Math.min(this.text.length, this.textOff + OO),
          pO = this.text.slice(this.textOff, KO);
        return this.textOff = KO, pO
      }
    }
    const upO = [dp, Qp, fp, Ap, Tp, Lp, Vp];
    for (let Yl = 0; Yl < upO.length; Yl++) upO[Yl].bucket = Yl;
    class Ep {
      constructor(OO) {
        this.view = OO, this.buckets = upO.map((() => [])), this.index = upO.map((() => 0)), this.reused = new Map
      }
      add(OO) {
        let KO = OO.constructor.bucket,
          pO = this.buckets[KO];
        pO.length < 6 ? pO.push(OO) : pO[this.index[KO] = (this.index[KO] + 1) % 6] = OO
      }
      find(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2,
          XO = OO.bucket,
          bK = this.buckets[XO],
          eO = this.index[XO];
        for (let lO = bK.length - 1; lO >= 0; lO--) {
          let OO = (lO + eO) % bK.length,
            vK = bK[OO];
          if ((!KO || KO(vK)) && !this.reused.has(vK)) return bK.splice(OO, 1), OO < eO && this.index[XO]--, this.reused.set(vK, pO), vK
        }
        return null
      }
      findWidget(OO, KO, pO) {
        let XO = this.buckets[0];
        if (XO.length)
          for (let bK = 0, eO = 0;; bK++) {
            if (bK == XO.length) {
              if (eO) return null;
              eO = 1, bK = 0
            }
            let lO = XO[bK];
            if (!this.reused.has(lO) && (0 == eO ? lO.widget.compare(OO) : lO.widget.constructor == OO.constructor && OO.updateDOM(lO.dom, this.view, lO.widget))) return XO.splice(bK, 1), bK < this.index[0] && this.index[0]--, lO.widget == OO && lO.length == KO && (497 & lO.flags) == pO ? (this.reused.set(lO, 1), lO) : (this.reused.set(lO, 2), new dp(lO.dom, KO, OO, -498 & lO.flags | pO))
          }
      }
      reuse(OO) {
        return this.reused.set(OO, 1), OO
      }
      maybeReuse(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
        if (!this.reused.has(OO)) return this.reused.set(OO, KO), OO.dom
      }
      clear() {
        for (let OO = 0; OO < this.buckets.length; OO++) this.buckets[OO].length = this.index[OO] = 0
      }
    }
    class jX {
      constructor(OO, KO, pO, bK, eO) {
        this.view = OO, this.ql = bK, this.disallowBlockEffectsFor = eO, this.openWidget = !1, this.openMarks = 0, this.cache = new Ep(OO), this.text = new gX(OO.state.doc), this.builder = new yX(this.cache, new Vp(OO, OO.contentDOM), XO.y.iter(pO)), this.cache.reused.set(KO, 2), this.old = new Np(KO), this.reuseWalker = {
          skip: (OO, KO, pO) => {
            if (this.cache.add(OO), OO.isComposite()) return !1
          },
          enter: OO => this.cache.add(OO),
          DX: () => {},
          break: () => {}
        }
      }
      run(OO, KO) {
        let pO = KO && this.getCompositionContext(KO.text);
        for (let XO = 0, bK = 0, eO = 0;;) {
          let lO = eO < OO.length ? OO[eO++] : null,
            vK = lO ? lO.fromA : this.old.root.length;
          if (vK > XO) {
            let OO = vK - XO;
            this.preserve(OO, !eO, !lO), XO = vK, bK += OO
          }
          if (!lO) break;
          KO && lO.fromA <= KO.range.fromA && lO.toA >= KO.range.toA ? (this.forward(lO.fromA, KO.range.fromA, KO.range.fromA < KO.range.toA ? 1 : -1), this.emit(bK, KO.range.fromB), this.cache.clear(), this.builder.addComposition(KO, pO), this.text.skip(KO.range.toB - KO.range.fromB), this.forward(KO.range.fromA, lO.toA), this.emit(KO.range.toB, lO.toB)) : (this.forward(lO.fromA, lO.toA), this.emit(bK, lO.toB)), bK = lO.toB, XO = lO.toA
        }
        return this.builder.curLine && this.builder.endLine(), this.builder.root
      }
      preserve(OO, KO, pO) {
        let XO = function(OO) {
            let KO = [];
            for (let pO = OO.parents.length; pO > 1; pO--) {
              let XO = pO == OO.parents.length ? OO.tile : OO.parents[pO].tile;
              XO instanceof Ap && KO.push(XO.mark)
            }
            return KO
          }(this.old),
          bK = this.openMarks;
        this.old.advance(OO, pO ? 1 : -1, {
          skip: (OO, KO, pO) => {
            if (OO.isWidget())
              if (this.openWidget) this.builder.continueWidget(pO - KO);
              else {
                let eO = pO > 0 || KO < OO.length ? dp.of(OO.widget, this.view, pO - KO, 496 & OO.flags, this.cache.maybeReuse(OO)) : this.cache.reuse(OO);
                256 & eO.flags ? (eO.flags &= -2, this.builder.addBlockWidget(eO)) : (this.builder.ensureLine(null), this.builder.addInlineWidget(eO, XO, bK), bK = XO.length)
              }
            else if (OO.isText()) this.builder.ensureLine(null), KO || pO != OO.length || this.cache.reused.has(OO) ? (this.cache.add(OO), this.builder.addText(OO.text.slice(KO, pO), XO, bK)) : this.builder.addText(OO.text, XO, bK, this.cache.reuse(OO)), bK = XO.length;
            else if (OO.isLine()) OO.flags &= -2, this.cache.reused.set(OO, 1), this.builder.addLine(OO);
            else if (OO instanceof Tp) this.cache.add(OO);
            else {
              if (!(OO instanceof Ap)) return !1;
              this.builder.ensureLine(null), this.builder.addMark(OO, XO, bK), this.cache.reused.set(OO, 1), bK = XO.length
            }
            this.openWidget = !1
          },
          enter: OO => {
            OO.isLine() ? this.builder.addLineStart(OO.attrs, this.cache.maybeReuse(OO)) : (this.cache.add(OO), OO instanceof Ap && XO.unshift(OO.mark)), this.openWidget = !1
          },
          DX: OO => {
            OO.isLine() ? XO.length && (XO.length = bK = 0) : OO instanceof Ap && (XO.shift(), bK = Math.min(bK, XO.length))
          },
          break: () => {
            this.builder.addBreak(), this.openWidget = !1
          }
        }), this.text.skip(OO)
      }
      emit(OO, KO) {
        let pO = null,
          bK = this.builder,
          eO = 0,
          lO = XO.y.spans(this.ql, OO, KO, {
            point: (OO, KO, XO, lO, vK, CO) => {
              if (XO instanceof PO) {
                if (this.disallowBlockEffectsFor[CO]) {
                  if (XO.block) throw new RangeError("Block decorations may not be specified via plugins");
                  if (KO > this.view.state.doc.lineAt(OO).to) throw new RangeError("Decorations that replace line breaks may not be specified via plugins")
                }
                if (eO = lO.length, vK > lO.length) bK.continueWidget(KO - OO);
                else {
                  let eO = XO.widget || (XO.block ? rX.block : rX.inline),
                    CO = function(OO) {
                      let KO = OO.isReplace ? (OO.startSide < 0 ? 64 : 0) | (OO.endSide > 0 ? 128 : 0) : OO.startSide > 0 ? 32 : 16;
                      OO.block && (KO |= 256);
                      return KO
                    }(XO),
                    hO = this.cache.findWidget(eO, KO - OO, CO) || dp.of(eO, this.view, KO - OO, CO);
                  XO.block ? (XO.startSide > 0 && bK.addLineStartIfNotCovered(pO), bK.addBlockWidget(hO)) : (bK.ensureLine(pO), bK.addInlineWidget(hO, lO, vK))
                }
                pO = null
              } else pO = function(OO, KO) {
                let pO = KO.spec.attributes,
                  XO = KO.spec.class;
                if (!pO && !XO) return OO;
                OO || (OO = {
                  class: "cm-line"
                });
                pO && IO(pO, OO);
                XO && (OO.class += " " + XO);
                return OO
              }(pO, XO);
              KO > OO && this.text.skip(KO - OO)
            },
            span: (OO, KO, XO, eO) => {
              for (let lO = OO; lO < KO;) {
                let vK = this.text.next(Math.min(512, KO - lO));
                null == vK ? (bK.addLineStartIfNotCovered(pO), bK.addBreak(), lO++) : (bK.ensureLine(pO), bK.addText(vK, XO, lO == OO ? eO : XO.length), lO += vK.length), pO = null
              }
            }
          });
        bK.addLineStartIfNotCovered(pO), this.openWidget = lO > eO, this.openMarks = lO
      }
      forward(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
        KO - OO <= 10 ? this.old.advance(KO - OO, pO, this.reuseWalker) : (this.old.advance(5, -1, this.reuseWalker), this.old.advance(KO - OO - 10, -1), this.old.advance(5, pO, this.reuseWalker))
      }
      getCompositionContext(OO) {
        let KO = [],
          pO = null;
        for (let XO = OO.parentNode;; XO = XO.parentNode) {
          let OO = aX.get(XO);
          if (XO == this.view.contentDOM) break;
          OO instanceof Ap ? KO.push(OO) : (null === OO || void 0 === OO ? void 0 : OO.isLine()) ? pO = OO : OO instanceof Lp || ("DIV" != XO.nodeName || pO || XO == this.view.contentDOM ? pO || KO.push(Ap.of(new iK({
            tagName: XO.nodeName.toLowerCase(),
            attributes: EO(XO)
          }), XO)) : pO = new Qp(XO, wp))
        }
        return {
          line: pO,
          marks: KO
        }
      }
    }

    function Yp(OO, KO) {
      let pO = OO => {
        for (let XO of OO.children)
          if ((KO ? XO.isText() : XO.length) || pO(XO)) return !0;
        return !1
      };
      return pO(OO)
    }
    const wp = {
      class: "cm-line"
    };

    function iX(OO) {
      let KO = aX.get(OO);
      return KO && KO.setDOM(OO.cloneNode()), OO
    }
    class rX extends jK {
      constructor(OO) {
        super(), this.tag = OO
      }
      eq(OO) {
        return OO.tag == this.tag
      }
      toDOM() {
        return document.createElement(this.tag)
      }
      updateDOM(OO) {
        return OO.nodeName.toLowerCase() == this.tag
      }
      get isHidden() {
        return !0
      }
    }
    rX.inline = new rX("span"), rX.block = new rX("div");
    const Pp = new class extends jK {
      toDOM() {
        return document.createElement("br")
      }
      get isHidden() {
        return !0
      }
      get editable() {
        return !0
      }
    };
    class mX {
      constructor(OO) {
        this.view = OO, this.ql = [], this.blockWrappers = [], this.dynamicDecorationMap = [!1], this.domChanged = null, this.hasComposition = null, this.editContextFormatting = wO.none, this.lastCompositionAfterCursor = !1, this.minWidth = 0, this.minWidthFrom = 0, this.minWidthTo = 0, this.impreciseAnchor = null, this.impreciseHead = null, this.forceSelection = !1, this.lastUpdate = Date.now(), this.updateDeco(), this.tile = new Vp(OO, OO.contentDOM), this.updateInner([new hp(0, 0, 0, OO.state.doc.length)], null)
      }
      update(OO) {
        var KO;
        let pO = OO.changedRanges;
        this.minWidth > 0 && pO.length && (pO.every((OO => {
          let {
            fromA: KO,
            toA: pO
          } = OO;
          return pO < this.minWidthFrom || KO > this.minWidthTo
        })) ? (this.minWidthFrom = OO.changes.mapPos(this.minWidthFrom, 1), this.minWidthTo = OO.changes.mapPos(this.minWidthTo, 1)) : this.minWidth = this.minWidthFrom = this.minWidthTo = 0), this.updateEditContextFormatting(OO);
        let bK = -1;
        this.view.inputState.composing >= 0 && !this.view.observer.editContext && ((null === (KO = this.domChanged) || void 0 === KO ? void 0 : KO.newSel) ? bK = this.domChanged.newSel.head : function(OO, KO) {
          let pO = !1;
          KO && OO.iterChangedRanges(((OO, XO) => {
            OO < KO.to && XO > KO.from && (pO = !0)
          }));
          return pO
        }(OO.changes, this.hasComposition) || OO.selectionSet || (bK = OO.state.selection.main.head));
        let eO = bK > -1 ? function(OO, KO, pO) {
          let XO = Hp(OO, pO);
          if (!XO) return null;
          let {
            node: bK,
            from: eO,
            to: lO
          } = XO, vK = bK.nodeValue;
          if (/[\n\r]/.test(vK)) return null;
          if (OO.state.doc.sliceString(XO.from, XO.to) != vK) return null;
          let CO = KO.invertedDesc;
          return {
            range: new hp(CO.mapPos(eO), CO.mapPos(lO), eO, lO),
            text: bK
          }
        }(this.view, OO.changes, bK) : null;
        if (this.domChanged = null, this.hasComposition) {
          let {
            from: KO,
            to: XO
          } = this.hasComposition;
          pO = new hp(KO, XO, OO.changes.mapPos(KO, -1), OO.changes.mapPos(XO, 1)).addToSet(pO.slice())
        }
        this.hasComposition = eO ? {
          from: eO.range.fromB,
          to: eO.range.toB
        } : null, (NO.ie || NO.chrome) && !eO && OO && OO.state.doc.lines != OO.startState.doc.lines && (this.forceSelection = !0);
        let lO = this.ql,
          vK = this.blockWrappers;
        this.updateDeco();
        let CO = function(OO, KO, pO) {
          let bK = new Rp;
          return XO.y.compare(OO, KO, pO, bK), bK.changes
        }(lO, this.ql, OO.changes);
        CO.length && (pO = hp.extendWithRanges(pO, CO));
        let hO = function(OO, KO, pO) {
          let bK = new Sp;
          return XO.y.compare(OO, KO, pO, bK), bK.changes
        }(vK, this.blockWrappers, OO.changes);
        return hO.length && (pO = hp.extendWithRanges(pO, hO)), eO && !pO.some((OO => OO.fromA <= eO.range.fromA && OO.toA >= eO.range.toA)) && (pO = eO.range.addToSet(pO.slice())), !(2 & this.tile.flags && 0 == pO.length) && (this.updateInner(pO, eO), OO.transactions.length && (this.lastUpdate = Date.now()), !0)
      }
      updateInner(OO, KO) {
        this.view.viewState.mustMeasureContent = !0;
        let {
          observer: pO
        } = this.view;
        pO.ignore((() => {
          if (KO || OO.length) {
            let pO = this.tile,
              XO = new jX(this.view, pO, this.blockWrappers, this.ql, this.dynamicDecorationMap);
            KO && aX.get(KO.text) && XO.cache.reused.set(aX.get(KO.text), 2), this.tile = XO.run(OO, KO), sp(pO, XO.cache.reused)
          }
          this.tile.dom.style.height = this.view.viewState.contentHeight / this.view.scaleY + "px", this.tile.dom.style.flexBasis = this.minWidth ? this.minWidth + "px" : "";
          let XO = NO.chrome || NO.ios ? {
            node: pO.selectionRange.focusNode,
            written: !1
          } : void 0;
          this.tile.sync(XO), !XO || !XO.written && pO.selectionRange.focusNode == XO.node && this.tile.dom.contains(XO.node) || (this.forceSelection = !0), this.tile.dom.style.height = ""
        }));
        let XO = [];
        if (this.view.viewport.from || this.view.viewport.to < this.view.state.doc.length)
          for (let bK of this.tile.children) bK.isWidget() && bK.widget instanceof Jp && XO.push(bK.dom);
        pO.updateGaps(XO)
      }
      updateEditContextFormatting(OO) {
        this.editContextFormatting = this.editContextFormatting.map(OO.changes);
        for (let KO of OO.transactions)
          for (let OO of KO.effects) OO.is(ZK) && (this.editContextFormatting = OO.value)
      }
      updateSelection() {
        let OO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        !(arguments.length > 0 && void 0 !== arguments[0] && arguments[0]) && this.view.observer.selectionRange.focusNode || this.view.observer.readSelectionRange();
        let {
          dom: KO
        } = this.tile, pO = this.view.root.activeElement, XO = pO == KO, bK = !XO && !(this.view.state.facet(qp) || KO.tabIndex > -1) && JO(KO, this.view.observer.selectionRange) && !(pO && KO.contains(pO));
        if (!(XO || OO || bK)) return;
        let eO = this.forceSelection;
        this.forceSelection = !1;
        let lO, vK, CO = this.view.state.selection.main;
        if (CO.empty ? vK = lO = this.inlineDOMNearPos(CO.anchor, CO.assoc || 1) : (vK = this.inlineDOMNearPos(CO.head, CO.head == CO.from ? 1 : -1), lO = this.inlineDOMNearPos(CO.anchor, CO.anchor == CO.from ? 1 : -1)), NO.gecko && CO.empty && !this.hasComposition && (1 == (hO = lO).node.nodeType && hO.node.firstChild && (0 == hO.offset || "false" == hO.node.childNodes[hO.offset - 1].contentEditable) && (hO.offset == hO.node.childNodes.length || "false" == hO.node.childNodes[hO.offset].contentEditable))) {
          let OO = document.createTextNode("");
          this.view.observer.ignore((() => lO.node.insertBefore(OO, lO.node.childNodes[lO.offset] || null))), lO = vK = new CK(OO, 0), eO = !0
        }
        var hO;
        let DO = this.view.observer.selectionRange;
        !eO && DO.focusNode && (BO(lO.node, lO.offset, DO.anchorNode, DO.anchorOffset) && BO(vK.node, vK.offset, DO.focusNode, DO.focusOffset) || this.suppressWidgetCursorChange(DO, CO)) || (this.view.observer.ignore((() => {
          NO.android && NO.chrome && KO.contains(DO.focusNode) && function(OO, KO) {
            for (let pO = OO; pO && pO != KO; pO = pO.assignedSlot || pO.parentNode)
              if (1 == pO.nodeType && "false" == pO.contentEditable) return !0;
            return !1
          }(DO.focusNode, KO) && (KO.blur(), KO.focus({
            preventScroll: !0
          }));
          let OO = RO(this.view.root);
          if (OO)
            if (CO.empty) {
              if (NO.gecko) {
                let OO = (XO = lO.node, eO = lO.offset, 1 != XO.nodeType ? 0 : (eO && "false" == XO.childNodes[eO - 1].contentEditable ? 1 : 0) | (eO < XO.childNodes.length && "false" == XO.childNodes[eO].contentEditable ? 2 : 0));
                if (OO && 3 != OO) {
                  let KO = (1 == OO ? lK : vp)(lO.node, lO.offset);
                  KO && (lO = new CK(KO.node, KO.offset))
                }
              }
              OO.collapse(lO.node, lO.offset), null != CO.bidiLevel && void 0 !== OO.caretBidiLevel && (OO.caretBidiLevel = CO.bidiLevel)
            } else if (OO.extend) {
            OO.collapse(lO.node, lO.offset);
            try {
              OO.extend(vK.node, vK.offset)
            } catch (hO) {}
          } else {
            let KO = document.createRange();
            CO.anchor > CO.head && ([lO, vK] = [vK, lO]), KO.setEnd(vK.node, vK.offset), KO.setStart(lO.node, lO.offset), OO.removeAllRanges(), OO.addRange(KO)
          } else;
          var XO, eO;
          bK && this.view.root.activeElement == KO && (KO.blur(), pO && pO.focus())
        })), this.view.observer.setSelectionRange(lO, vK)), this.impreciseAnchor = lO.precise ? null : new CK(DO.anchorNode, DO.anchorOffset), this.impreciseHead = vK.precise ? null : new CK(DO.focusNode, DO.focusOffset)
      }
      suppressWidgetCursorChange(OO, KO) {
        return this.hasComposition && KO.empty && BO(OO.focusNode, OO.focusOffset, OO.anchorNode, OO.anchorOffset) && this.posFromDOM(OO.focusNode, OO.focusOffset) == KO.head
      }
      enforceCursorAssoc() {
        if (this.hasComposition) return;
        let {
          view: OO
        } = this, KO = OO.state.selection.main, pO = RO(OO.root), {
          anchorNode: XO,
          anchorOffset: bK
        } = OO.observer.selectionRange;
        if (!pO || !KO.empty || !KO.assoc || !pO.modify) return;
        let eO = this.lineAt(KO.head, KO.assoc);
        if (!eO) return;
        let lO = eO.posAtStart;
        if (KO.head == lO || KO.head == lO + eO.length) return;
        let vK = this.coordsAt(KO.head, -1),
          CO = this.coordsAt(KO.head, 1);
        if (!vK || !CO || vK.bottom > CO.top) return;
        let hO = this.domAtPos(KO.head + KO.assoc, KO.assoc);
        pO.collapse(hO.node, hO.offset), pO.modify("move", KO.assoc < 0 ? "forward" : "backward", "lineboundary"), OO.observer.readSelectionRange();
        let DO = OO.observer.selectionRange;
        OO.docView.posFromDOM(DO.anchorNode, DO.anchorOffset) != KO.from && pO.collapse(XO, bK)
      }
      posFromDOM(OO, KO) {
        let pO = this.tile.nearest(OO);
        if (!pO) return 2 & this.tile.dom.compareDocumentPosition(OO) ? 0 : this.view.state.doc.length;
        let XO = pO.posAtStart;
        if (!pO.isComposite()) return pO.isText() ? OO == pO.dom ? XO + KO : XO + (KO ? pO.length : 0) : XO;
        {
          let bK;
          if (OO == pO.dom) bK = pO.dom.childNodes[KO];
          else {
            let XO = 0 == xK(OO) ? 0 : 0 == KO ? -1 : 1;
            for (;;) {
              let KO = OO.parentNode;
              if (KO == pO.dom) break;
              0 == XO && KO.firstChild != KO.lastChild && (XO = OO == KO.firstChild ? -1 : 1), OO = KO
            }
            bK = XO < 0 ? OO : OO.nextSibling
          }
          if (bK == pO.dom.firstChild) return XO;
          for (; bK && !aX.get(bK);) bK = bK.nextSibling;
          if (!bK) return XO + pO.length;
          for (let OO = 0, KO = XO;; OO++) {
            let XO = pO.children[OO];
            if (XO.dom == bK) return KO;
            KO += XO.length + XO.breakAfter
          }
        }
      }
      domAtPos(OO, KO) {
        let {
          tile: pO,
          offset: XO
        } = this.tile.resolveBlock(OO, KO);
        return pO.isWidget() ? pO.domPosFor(OO, KO) : pO.domIn(XO, KO)
      }
      inlineDOMNearPos(OO, KO) {
        let pO, XO, bK = -1,
          eO = !1,
          lO = -1,
          vK = !1;
        return this.tile.blockTiles(((KO, CO) => {
          if (KO.isWidget()) {
            if (32 & KO.flags && CO >= OO) return !0;
            16 & KO.flags && (eO = !0)
          } else {
            let hO = CO + KO.length;
            if (CO <= OO && (pO = KO, bK = OO - CO, eO = hO < OO), hO >= OO && !XO && (XO = KO, lO = OO - CO, vK = CO > OO), CO > OO && XO) return !0
          }
        })), pO || XO ? (eO && XO ? pO = null : vK && pO && (XO = null), pO && KO < 0 || !XO ? pO.domIn(bK, KO) : XO.domIn(lO, KO)) : this.domAtPos(OO, KO)
      }
      coordsAt(OO, KO) {
        let {
          tile: pO,
          offset: XO
        } = this.tile.resolveBlock(OO, KO);
        return pO.isWidget() ? pO.widget instanceof Jp ? null : pO.coordsInWidget(XO, KO, !0) : pO.coordsIn(XO, KO)
      }
      lineAt(OO, KO) {
        let {
          tile: pO
        } = this.tile.resolveBlock(OO, KO);
        return pO.isLine() ? pO : null
      }
      coordsForChar(OO) {
        let {
          tile: KO,
          offset: pO
        } = this.tile.resolveBlock(OO, 1);
        if (!KO.isLine()) return null;
        return function OO(KO, pO) {
          if (KO.isComposite())
            for (let XO of KO.children) {
              if (XO.length >= pO) {
                let KO = OO(XO, pO);
                if (KO) return KO
              }
              if ((pO -= XO.length) < 0) break
            } else if (KO.isText() && pO < KO.length) {
              let OO = (0, XO.Y)(KO.text, pO);
              if (OO == pO) return null;
              let bK = XK(KO.dom, pO, OO).getClientRects();
              for (let KO = 0; KO < bK.length; KO++) {
                let OO = bK[KO];
                if (KO == bK.length - 1 || OO.top < OO.bottom && OO.left < OO.right) return OO
              }
            } return null
        }(KO, pO)
      }
      measureVisibleLineHeights(OO) {
        let KO = [],
          {
            from: pO,
            to: XO
          } = OO,
          bK = this.view.contentDOM.clientWidth,
          eO = bK > Math.max(this.view.scrollDOM.clientWidth, this.minWidth) + 1,
          lO = -1,
          vK = this.view.textDirection == hK.LTR,
          CO = 0,
          hO = (OO, DO, MO) => {
            for (let aK = 0; aK < OO.children.length && !(DO > XO); aK++) {
              let XO = OO.children[aK],
                oO = DO + XO.length,
                FO = XO.dom.getBoundingClientRect(),
                {
                  height: VO
                } = FO;
              if (MO && !aK && (CO += FO.top - MO.top), XO instanceof Lp) oO > pO && hO(XO, DO, FO);
              else if (DO >= pO && (CO > 0 && KO.push(-CO), KO.push(VO + CO), CO = 0, eO)) {
                let OO = XO.dom.lastChild,
                  KO = OO ? cK(OO) : [];
                if (KO.length) {
                  let OO = KO[KO.length - 1],
                    pO = vK ? OO.right - FO.left : FO.right - OO.left;
                  pO > lO && (lO = pO, this.minWidth = bK, this.minWidthFrom = DO, this.minWidthTo = oO)
                }
              }
              MO && aK == OO.children.length - 1 && (CO += MO.bottom - FO.bottom), DO = oO + XO.breakAfter
            }
          };
        return hO(this.tile, 0, null), KO
      }
      textDirectionAt(OO) {
        let {
          tile: KO
        } = this.tile.resolveBlock(OO, 1);
        return "rtl" == getComputedStyle(KO.dom).direction ? hK.RTL : hK.LTR
      }
      measureTextSize() {
        let OO = this.tile.blockTiles((OO => {
          if (OO.isLine() && OO.children.length && OO.length <= 20) {
            let KO, pO = 0;
            for (let XO of OO.children) {
              if (!XO.isText() || /[^ -~]/.test(XO.text)) return;
              let OO = cK(XO.dom);
              if (1 != OO.length) return;
              pO += OO[0].width, KO = OO[0].height
            }
            if (pO) return {
              lineHeight: OO.dom.getBoundingClientRect().height,
              charWidth: pO / OO.length,
              textHeight: KO
            }
          }
        }));
        if (OO) return OO;
        let KO, pO, XO, bK = document.createElement("div");
        return bK.className = "cm-line", bK.style.width = "99999px", bK.style.position = "absolute", bK.textContent = "abc def ghi jkl mno pqr stu", this.view.observer.ignore((() => {
          this.tile.dom.appendChild(bK);
          let OO = cK(bK.firstChild)[0];
          KO = bK.getBoundingClientRect().height, pO = OO && OO.width ? OO.width / 27 : 7, XO = OO && OO.height ? OO.height : KO, bK.remove()
        })), {
          lineHeight: KO,
          charWidth: pO,
          textHeight: XO
        }
      }
      computeBlockGapDeco() {
        let OO = [],
          KO = this.view.viewState;
        for (let pO = 0, XO = 0;; XO++) {
          let bK = XO == KO.viewports.length ? null : KO.viewports[XO],
            eO = bK ? bK.from - 1 : this.view.state.doc.length;
          if (eO > pO) {
            let XO = (KO.lineBlockAt(eO).bottom - KO.lineBlockAt(pO).top) / this.view.scaleY;
            OO.push(wO.replace({
              widget: new Jp(XO),
              block: !0,
              inclusive: !0,
              isBlockGap: !0
            }).range(pO, eO))
          }
          if (!bK) break;
          pO = bK.to + 1
        }
        return wO.set(OO)
      }
      updateDeco() {
        let OO = 1,
          KO = this.view.state.facet(Op).map((KO => (this.dynamicDecorationMap[OO++] = "function" == typeof KO) ? KO(this.view) : KO)),
          pO = !1,
          bK = this.view.state.facet(pp).map(((OO, KO) => {
            let XO = "function" == typeof OO;
            return XO && (pO = !0), XO ? OO(this.view) : OO
          }));
        for (bK.length && (this.dynamicDecorationMap[OO++] = pO, KO.push(XO.y.join(bK))), this.ql = [this.editContextFormatting, ...KO, this.computeBlockGapDeco(), this.view.viewState.lineGapDeco]; OO < this.ql.length;) this.dynamicDecorationMap[OO++] = !1;
        this.blockWrappers = this.view.state.facet(Kp).map((OO => "function" == typeof OO ? OO(this.view) : OO))
      }
      scrollIntoView(OO) {
        var KO;
        if (OO.isSnapshot) {
          let KO = this.view.viewState.lineBlockAt(OO.range.head);
          return this.view.scrollDOM.scrollTop = KO.top - OO.yMargin, void(this.view.scrollDOM.scrollLeft = OO.xMargin)
        }
        for (let DO of this.view.state.facet(JK)) try {
          if (DO(this.view, OO.range, OO)) return !0
        } catch (hO) {
          GK(this.view.state, hO, "scroll handler")
        }
        let pO, {
            range: XO
          } = OO,
          bK = this.coordsAt(XO.head, null !== (KO = XO.assoc) && void 0 !== KO ? KO : XO.empty ? 0 : XO.head > XO.anchor ? -1 : 1);
        if (!bK) return;
        !XO.empty && (pO = this.coordsAt(XO.anchor, XO.anchor > XO.head ? -1 : 1)) && (bK = {
          left: Math.min(bK.left, pO.left),
          top: Math.min(bK.top, pO.top),
          right: Math.max(bK.right, pO.right),
          bottom: Math.max(bK.bottom, pO.bottom)
        });
        let eO = vX(this.view),
          lO = {
            left: bK.left - eO.left,
            top: bK.top - eO.top,
            right: bK.right + eO.right,
            bottom: bK.bottom + eO.bottom
          },
          {
            offsetWidth: vK,
            offsetHeight: CO
          } = this.view.scrollDOM;
        if (function(OO, KO, pO, XO, bK, eO, lO, vK) {
            let CO = OO.ownerDocument,
              hO = CO.defaultView || window;
            for (let DO = OO, MO = !1; DO && !MO;)
              if (1 == DO.nodeType) {
                let OO, aK = DO == CO.body,
                  oO = 1,
                  FO = 1;
                if (aK) OO = WO(hO);
                else {
                  if (/^(fixed|sticky)$/.test(getComputedStyle(DO).position) && (MO = !0), DO.scrollHeight <= DO.clientHeight && DO.scrollWidth <= DO.clientWidth) {
                    DO = DO.assignedSlot || DO.parentNode;
                    continue
                  }
                  let KO = DO.getBoundingClientRect();
                  ({
                    scaleX: oO,
                    scaleY: FO
                  } = tK(DO, KO)), OO = {
                    left: KO.left,
                    right: KO.left + DO.clientWidth * oO,
                    top: KO.top,
                    bottom: KO.top + DO.clientHeight * FO
                  }
                }
                let VO = 0,
                  LO = 0;
                if ("nearest" == bK) KO.top < OO.top + lO ? (LO = KO.top - (OO.top + lO), pO > 0 && KO.bottom > OO.bottom + LO && (LO = KO.bottom - OO.bottom + lO)) : KO.bottom > OO.bottom - lO && (LO = KO.bottom - OO.bottom + lO, pO < 0 && KO.top - LO < OO.top && (LO = KO.top - (OO.top + lO)));
                else {
                  let XO = KO.bottom - KO.top,
                    eO = OO.bottom - OO.top;
                  LO = ("center" == bK && XO <= eO ? KO.top + XO / 2 - eO / 2 : "start" == bK || "center" == bK && pO < 0 ? KO.top - lO : KO.bottom - eO + lO) - OO.top
                }
                if ("nearest" == XO ? KO.left < OO.left + eO ? (VO = KO.left - (OO.left + eO), pO > 0 && KO.right > OO.right + VO && (VO = KO.right - OO.right + eO)) : KO.right > OO.right - eO && (VO = KO.right - OO.right + eO, pO < 0 && KO.left < OO.left + VO && (VO = KO.left - (OO.left + eO))) : VO = ("center" == XO ? KO.left + (KO.right - KO.left) / 2 - (OO.right - OO.left) / 2 : "start" == XO == vK ? KO.left - eO : KO.right - (OO.right - OO.left) + eO) - OO.left, VO || LO)
                  if (aK) hO.scrollBy(VO, LO);
                  else {
                    let OO = 0,
                      pO = 0;
                    if (LO) {
                      let OO = DO.scrollTop;
                      DO.scrollTop += LO / FO, pO = (DO.scrollTop - OO) * FO
                    }
                    if (VO) {
                      let KO = DO.scrollLeft;
                      DO.scrollLeft += VO / oO, OO = (DO.scrollLeft - KO) * oO
                    }
                    KO = {
                      left: KO.left - OO,
                      top: KO.top - pO,
                      right: KO.right - OO,
                      bottom: KO.bottom - pO
                    }, OO && Math.abs(OO - VO) < 1 && (XO = "nearest"), pO && Math.abs(pO - LO) < 1 && (bK = "nearest")
                  } if (aK) break;
                (KO.top < OO.top || KO.bottom > OO.bottom || KO.left < OO.left || KO.right > OO.right) && (KO = {
                  left: Math.max(KO.left, OO.left),
                  right: Math.min(KO.right, OO.right),
                  top: Math.max(KO.top, OO.top),
                  bottom: Math.min(KO.bottom, OO.bottom)
                }), DO = DO.assignedSlot || DO.parentNode
              } else {
                if (11 != DO.nodeType) break;
                DO = DO.host
              }
          }(this.view.scrollDOM, lO, XO.head < XO.anchor ? -1 : 1, OO.x, OO.y, Math.max(Math.min(OO.xMargin, vK), -vK), Math.max(Math.min(OO.yMargin, CO), -CO), this.view.textDirection == hK.LTR), window.visualViewport && window.innerHeight - window.visualViewport.height > 1 && (bK.top > window.pageYOffset + window.visualViewport.offsetTop + window.visualViewport.height || bK.bottom < window.pageYOffset + window.visualViewport.offsetTop)) {
          let OO = this.view.docView.lineAt(XO.head, 1);
          OO && OO.dom.scrollIntoView({
            block: "nearest"
          })
        }
      }
      lineHasWidget(OO) {
        let KO = OO => OO.isWidget() || OO.children.some(KO);
        return KO(this.tile.resolveBlock(OO, 1).tile)
      }
      destroy() {
        sp(this.tile)
      }
    }

    function sp(OO, KO) {
      let pO = null === KO || void 0 === KO ? void 0 : KO.get(OO);
      if (1 != pO) {
        null == pO && OO.destroy();
        for (let pO of OO.children) sp(pO, KO)
      }
    }

    function Hp(OO, KO) {
      let pO = OO.observer.selectionRange;
      if (!pO.focusNode) return null;
      let XO = lK(pO.focusNode, pO.focusOffset),
        bK = vp(pO.focusNode, pO.focusOffset),
        eO = XO || bK;
      if (bK && XO && bK.node != XO.node) {
        let KO = aX.get(bK.node);
        if (!KO || KO.isText() && KO.text != bK.node.nodeValue) eO = bK;
        else if (OO.docView.lastCompositionAfterCursor) {
          let OO = aX.get(XO.node);
          !OO || OO.isText() && OO.text != XO.node.nodeValue || (eO = bK)
        }
      }
      if (OO.docView.lastCompositionAfterCursor = eO != XO, !eO) return null;
      let lO = KO - eO.offset;
      return {
        from: lO,
        to: lO + eO.node.nodeValue.length,
        node: eO.node
      }
    }
    let Rp = class {
      constructor() {
        this.changes = []
      }
      compareRange(OO, KO) {
        sO(OO, KO, this.changes)
      }
      comparePoint(OO, KO) {
        sO(OO, KO, this.changes)
      }
      boundChange(OO) {
        sO(OO, OO, this.changes)
      }
    };
    class Sp {
      constructor() {
        this.changes = []
      }
      compareRange(OO, KO) {
        sO(OO, KO, this.changes)
      }
      comparePoint() {}
      boundChange(OO) {
        sO(OO, OO, this.changes)
      }
    }
    class Jp extends jK {
      constructor(OO) {
        super(), this.height = OO
      }
      toDOM() {
        let OO = document.createElement("div");
        return OO.className = "cm-gap", this.updateDOM(OO), OO
      }
      eq(OO) {
        return OO.height == this.height
      }
      updateDOM(OO) {
        return OO.style.height = this.height + "px", !0
      }
      get editable() {
        return !0
      }
      get estimatedHeight() {
        return this.height
      }
      ignoreEvent() {
        return !1
      }
    }

    function cX(OO, KO, pO) {
      let XO = OO.lineBlockAt(KO);
      if (Array.isArray(XO.type)) {
        let OO;
        for (let bK of XO.type) {
          if (bK.from > KO) break;
          if (!(bK.to < KO)) {
            if (bK.from < KO && bK.to > KO) return bK;
            OO && (bK.type != YO.Text || OO.type == bK.type && !(pO < 0 ? bK.from < KO : bK.to > KO)) || (OO = bK)
          }
        }
        return OO || XO
      }
      return XO
    }

    function Bp(OO, KO, pO, XO) {
      let bK = OO.state.doc.lineAt(KO.head),
        eO = OO.bidiSpans(bK),
        lO = OO.textDirectionAt(bK.from);
      for (let vK = KO, CO = null;;) {
        let KO = uK(bK, eO, lO, vK, pO),
          hO = gp;
        if (!KO) {
          if (bK.number == (pO ? OO.state.doc.lines : 1)) return vK;
          hO = "\n", bK = OO.state.doc.line(bK.number + (pO ? 1 : -1)), eO = OO.bidiSpans(bK), KO = OO.visualLineSide(bK, !pO)
        }
        if (CO) {
          if (!CO(hO)) return vK
        } else {
          if (!XO) return KO;
          CO = XO(hO)
        }
        vK = KO
      }
    }

    function Zp(OO, KO, pO) {
      for (;;) {
        let XO = 0;
        for (let bK of OO) bK.between(KO - 1, KO + 1, ((OO, bK, eO) => {
          if (KO > OO && KO < bK) {
            let eO = XO || pO || (KO - OO < bK - KO ? -1 : 1);
            KO = eO < 0 ? OO : bK, XO = eO
          }
        }));
        if (!XO) return KO
      }
    }

    function Gp(OO, KO) {
      let pO = null;
      for (let bK = 0; bK < KO.Xl.length; bK++) {
        let eO = KO.Xl[bK],
          lO = null;
        if (eO.empty) {
          let KO = Zp(OO, eO.from, 0);
          KO != eO.from && (lO = XO.j.cursor(KO, -1))
        } else {
          let KO = Zp(OO, eO.from, -1),
            pO = Zp(OO, eO.to, 1);
          KO == eO.from && pO == eO.to || (lO = XO.j.range(eO.from == eO.anchor ? KO : pO, eO.from == eO.head ? KO : pO))
        }
        lO && (pO || (pO = KO.Xl.slice()), pO[bK] = lO)
      }
      return pO ? XO.j.create(pO, KO.mainIndex) : KO
    }

    function qX(OO, KO, pO) {
      let bK = Zp(OO.state.facet(Xp).map((KO => KO(OO))), pO.from, KO.head > pO.from ? -1 : 1);
      return bK == pO.from ? pO : XO.j.cursor(bK, bK < pO.from ? 1 : -1)
    }
    class xX {
      constructor(OO, KO) {
        this.pos = OO, this.assoc = KO
      }
    }

    function np(OO, KO, pO, bK) {
      let eO, lO = OO.contentDOM.getBoundingClientRect(),
        vK = lO.top + OO.viewState.paddingTop,
        {
          x: CO,
          y: hO
        } = KO,
        DO = hO - vK;
      for (;;) {
        if (DO < 0) return new xX(0, 1);
        if (DO > OO.viewState.docHeight) return new xX(OO.state.doc.length, -1);
        if (eO = OO.elementAtHeight(DO), null == bK) break;
        if (eO.type == YO.Text) {
          if (bK < 0 ? eO.to < OO.viewport.from : eO.from > OO.viewport.to) break;
          let KO = OO.docView.coordsAt(bK < 0 ? eO.from : eO.to, bK > 0 ? -1 : 1);
          if (KO && (bK < 0 ? KO.top <= DO + vK : KO.bottom >= DO + vK)) break
        }
        let KO = OO.viewState.heightOracle.textHeight / 2;
        DO = bK > 0 ? eO.bottom + KO : eO.top - KO
      }
      if (OO.viewport.from >= eO.to || OO.viewport.to <= eO.from) {
        if (pO) return null;
        if (eO.type == YO.Text) {
          let KO = function(OO, KO, pO, bK, eO) {
            let lO = Math.round((bK - KO.left) * OO.defaultCharacterWidth);
            if (OO.lineWrapping && pO.height > 1.5 * OO.defaultLineHeight) {
              let KO = OO.viewState.heightOracle.textHeight;
              lO += Math.floor((eO - pO.top - .5 * (OO.defaultLineHeight - KO)) / KO) * OO.viewState.heightOracle.lineLength
            }
            let vK = OO.state.sliceDoc(pO.from, pO.to);
            return pO.from + (0, XO._)(vK, lO, OO.state.tabSize)
          }(OO, lO, eO, CO, hO);
          return new xX(KO, KO == eO.from ? 1 : -1)
        }
      }
      if (eO.type != YO.Text) return DO < (eO.top + eO.bottom) / 2 ? new xX(eO.from, 1) : new xX(eO.to, -1);
      let MO = OO.docView.lineAt(eO.from, 2);
      return MO && MO.length == eO.length || (MO = OO.docView.lineAt(eO.from, -2)), new Wp(OO, CO, hO, OO.textDirectionAt(eO.from)).scanTile(MO, eO.from)
    }
    class Wp {
      constructor(OO, KO, pO, XO) {
        this.view = OO, this.x = KO, this.y = pO, this.baseDir = XO, this.line = null, this.spans = null
      }
      bidiSpansAt(OO) {
        return (!this.line || this.line.from > OO || this.line.to < OO) && (this.line = this.view.state.doc.lineAt(OO), this.spans = this.view.bidiSpans(this.line)), this
      }
      baseDirAt(OO, KO) {
        let {
          line: pO,
          spans: XO
        } = this.bidiSpansAt(OO);
        return XO[AK.find(XO, OO - pO.from, -1, KO)].level == this.baseDir
      }
      dirAt(OO, KO) {
        let {
          line: pO,
          spans: XO
        } = this.bidiSpansAt(OO);
        return XO[AK.find(XO, OO - pO.from, -1, KO)].dir
      }
      bidiIn(OO, KO) {
        let {
          spans: pO,
          line: XO
        } = this.bidiSpansAt(OO);
        return pO.length > 1 || pO.length && (pO[0].level != this.baseDir || pO[0].to + XO.from < KO)
      }
      scan(OO, KO) {
        let pO, XO, bK, eO = 0,
          lO = OO.length - 1,
          vK = new Set,
          CO = this.bidiIn(OO[0], OO[lO]),
          hO = -1,
          DO = 1e9;
        OO: for (; eO < lO;) {
          let MO = lO - eO,
            aK = eO + lO >> 1;
          KO: if (vK.has(aK)) {
            let OO = eO + Math.floor(Math.random() * MO);
            for (let KO = 0; KO < MO; KO++) {
              if (!vK.has(OO)) {
                aK = OO;
                break KO
              }
              OO++, OO == lO && (OO = eO)
            }
            break OO
          } vK.add(aK);
          let oO = KO(aK);
          if (oO)
            for (let KO = 0; KO < oO.length; KO++) {
              let vK = oO[KO],
                MO = 0;
              if (!(0 == vK.width && oO.length > 1)) {
                if (vK.bottom < this.y)(!pO || pO.bottom < vK.bottom) && (pO = vK), MO = 1;
                else if (vK.top > this.y)(!XO || XO.top > vK.top) && (XO = vK), MO = -1;
                else {
                  let OO = vK.left > this.x ? this.x - vK.left : vK.right < this.x ? this.x - vK.right : 0,
                    KO = Math.abs(OO);
                  KO < DO && (hO = aK, DO = KO, bK = vK), OO && (MO = OO < 0 == (this.baseDir == hK.LTR) ? -1 : 1)
                } - 1 != MO || CO && !this.baseDirAt(OO[aK], 1) ? 1 != MO || CO && !this.baseDirAt(OO[aK + 1], -1) || (eO = aK + 1) : lO = aK
              }
            }
        }
        if (!bK) {
          let bK = pO && (!XO || this.y - pO.bottom < XO.top - this.y) ? pO : XO;
          return this.y = (bK.top + bK.bottom) / 2, this.scan(OO, KO)
        }
        if (DO) {
          if (pO && pO.bottom > bK.top) return this.y = pO.bottom - 1, this.scan(OO, KO);
          if (XO && XO.top < bK.bottom) return this.y = XO.top + 1, this.scan(OO, KO)
        }
        let MO = (CO ? this.dirAt(OO[hO], 1) : this.baseDir) == hK.LTR;
        return {
          i: hO,
          after: this.x > (bK.left + bK.right) / 2 == MO
        }
      }
      scanText(OO, KO) {
        let pO = [];
        for (let eO = 0; eO < OO.length; eO = (0, XO.Y)(OO.text, eO)) pO.push(KO + eO);
        pO.push(KO + OO.length);
        let bK = this.scan(pO, (XO => {
          let bK = pO[XO] - KO,
            eO = pO[XO + 1] - KO;
          return XK(OO.dom, bK, eO).getClientRects()
        }));
        return bK.after ? new xX(pO[bK.i + 1], -1) : new xX(pO[bK.i], 1)
      }
      scanTile(OO, KO) {
        if (!OO.length) return new xX(KO, 1);
        if (1 == OO.children.length) {
          let pO = OO.children[0];
          if (pO.isText()) return this.scanText(pO, KO);
          if (pO.isComposite()) return this.scanTile(pO, KO)
        }
        let pO = [KO];
        for (let lO = 0, vK = KO; lO < OO.children.length; lO++) pO.push(vK += OO.children[lO].length);
        let XO = this.scan(pO, (KO => {
            let pO = OO.children[KO];
            return 48 & pO.flags ? null : (1 == pO.dom.nodeType ? pO.dom : XK(pO.dom, 0, pO.length)).getClientRects()
          })),
          bK = OO.children[XO.i],
          eO = pO[XO.i];
        return bK.isText() ? this.scanText(bK, eO) : bK.isComposite() ? this.scanTile(bK, eO) : XO.after ? new xX(pO[XO.i + 1], -1) : new xX(eO, 1)
      }
    }
    const tX = "\uffff";
    class kX {
      constructor(OO, KO) {
        this.points = OO, this.view = KO, this.text = "", this.lineSeparator = KO.state.facet(XO.m.lineSeparator)
      }
      append(OO) {
        this.text += OO
      }
      lineBreak() {
        this.text += tX
      }
      readRange(OO, KO) {
        if (!OO) return this;
        let pO = OO.parentNode;
        for (let XO = OO;;) {
          this.findPointBefore(pO, XO);
          let OO = this.text.length;
          this.readNode(XO);
          let bK = aX.get(XO),
            eO = XO.nextSibling;
          if (eO == KO) {
            (null === bK || void 0 === bK ? void 0 : bK.breakAfter) && !eO && pO != this.view.contentDOM && this.lineBreak();
            break
          }
          let lO = aX.get(eO);
          (bK && lO ? bK.breakAfter : (bK ? bK.breakAfter : GO(XO)) || GO(eO) && ("BR" != XO.nodeName || (null === bK || void 0 === bK ? void 0 : bK.isWidget())) && this.text.length > OO) && !OX(eO, KO) && this.lineBreak(), XO = eO
        }
        return this.findPointBefore(pO, KO), this
      }
      readTextNode(OO) {
        let KO = OO.nodeValue;
        for (let pO of this.points) pO.node == OO && (pO.pos = this.text.length + Math.min(pO.offset, KO.length));
        for (let pO = 0, XO = this.lineSeparator ? null : /\r\n?|\n/g;;) {
          let bK, eO = -1,
            lO = 1;
          if (this.lineSeparator ? (eO = KO.indexOf(this.lineSeparator, pO), lO = this.lineSeparator.length) : (bK = XO.exec(KO)) && (eO = bK.index, lO = bK[0].length), this.append(KO.slice(pO, eO < 0 ? KO.length : eO)), eO < 0) break;
          if (this.lineBreak(), lO > 1)
            for (let KO of this.points) KO.node == OO && KO.pos > this.text.length && (KO.pos -= lO - 1);
          pO = eO + lO
        }
      }
      readNode(OO) {
        let KO = aX.get(OO),
          pO = KO && KO.overrideDOMText;
        if (null != pO) {
          this.findPointInside(OO, pO.length);
          for (let OO = pO.iter(); !OO.next().done;) OO.lineBreak ? this.lineBreak() : this.append(OO.value)
        } else 3 == OO.nodeType ? this.readTextNode(OO) : "BR" == OO.nodeName ? OO.nextSibling && this.lineBreak() : 1 == OO.nodeType && this.readRange(OO.firstChild, null)
      }
      findPointBefore(OO, KO) {
        for (let pO of this.points) pO.node == OO && OO.childNodes[pO.offset] == KO && (pO.pos = this.text.length)
      }
      findPointInside(OO, KO) {
        for (let pO of this.points)(3 == OO.nodeType ? pO.node == OO : OO.contains(pO.node)) && (pO.pos = this.text.length + (Up(OO, pO.node, pO.offset) ? KO : 0))
      }
    }

    function Up(OO, KO, pO) {
      for (;;) {
        if (!KO || pO < xK(KO)) return !1;
        if (KO == OO) return !0;
        pO = ZO(KO) + 1, KO = KO.parentNode
      }
    }

    function OX(OO, KO) {
      let pO;
      for (; OO != KO && OO; OO = OO.nextSibling) {
        let KO = aX.get(OO);
        if (!(null === KO || void 0 === KO ? void 0 : KO.isWidget())) return !1;
        KO && (pO || (pO = [])).push(KO)
      }
      if (pO)
        for (let XO of pO) {
          let OO = XO.overrideDOMText;
          if (null === OO || void 0 === OO ? void 0 : OO.length) return !1
        }
      return !0
    }
    class KX {
      constructor(OO, KO) {
        this.node = OO, this.offset = KO, this.pos = -1
      }
    }
    class pX {
      constructor(OO, KO, pO, bK) {
        this.typeOver = bK, this.bounds = null, this.text = "", this.domChanged = KO > -1;
        let {
          impreciseHead: eO,
          impreciseAnchor: lO
        } = OO.docView, vK = OO.state.selection;
        if (OO.state.readOnly && KO > -1) this.newSel = null;
        else if (KO > -1 && (this.bounds = XX(OO.docView.tile, KO, pO, 0))) {
          let KO = eO || lO ? [] : function(OO) {
              let KO = [];
              if (OO.root.activeElement != OO.contentDOM) return KO;
              let {
                anchorNode: pO,
                anchorOffset: XO,
                focusNode: bK,
                focusOffset: eO
              } = OO.observer.selectionRange;
              pO && (KO.push(new KX(pO, XO)), bK == pO && eO == XO || KO.push(new KX(bK, eO)));
              return KO
            }(OO),
            pO = new kX(KO, OO);
          pO.readRange(this.bounds.startDOM, this.bounds.endDOM), this.text = pO.text, this.newSel = function(OO, KO) {
            if (0 == OO.length) return null;
            let pO = OO[0].pos,
              bK = 2 == OO.length ? OO[1].pos : pO;
            return pO > -1 && bK > -1 ? XO.j.single(pO + KO, bK + KO) : null
          }(KO, this.bounds.from)
        } else {
          let KO = OO.observer.selectionRange,
            pO = eO && eO.node == KO.focusNode && eO.offset == KO.focusOffset || !SO(OO.contentDOM, KO.focusNode) ? vK.main.head : OO.docView.posFromDOM(KO.focusNode, KO.focusOffset),
            bK = lO && lO.node == KO.anchorNode && lO.offset == KO.anchorOffset || !SO(OO.contentDOM, KO.anchorNode) ? vK.main.anchor : OO.docView.posFromDOM(KO.anchorNode, KO.anchorOffset),
            CO = OO.viewport;
          if ((NO.ios || NO.chrome) && vK.main.empty && pO != bK && (CO.from > 0 || CO.to < OO.state.doc.length)) {
            let KO = Math.min(pO, bK),
              XO = Math.max(pO, bK),
              eO = CO.from - KO,
              lO = CO.to - XO;
            0 != eO && 1 != eO && 0 != KO || 0 != lO && -1 != lO && XO != OO.state.doc.length || (pO = 0, bK = OO.state.doc.length)
          }
          if (OO.inputState.composing > -1 && vK.Xl.length > 1) this.newSel = vK.replaceRange(XO.j.range(bK, pO));
          else if (OO.lineWrapping && bK == pO && (!vK.main.empty || vK.main.head != pO) && OO.inputState.lastTouchTime > Date.now() - 100) {
            let KO = OO.coordsAtPos(pO, -1),
              bK = 0;
            KO && (bK = OO.inputState.lastTouchY <= KO.bottom ? -1 : 1), this.newSel = XO.j.create([XO.j.cursor(pO, bK)])
          } else this.newSel = XO.j.single(bK, pO)
        }
      }
    }

    function XX(OO, KO, pO, XO) {
      if (OO.isComposite()) {
        let bK = -1,
          eO = -1,
          lO = -1,
          vK = -1;
        for (let CO = 0, hO = XO, DO = XO; CO < OO.children.length; CO++) {
          let XO = OO.children[CO],
            MO = hO + XO.length;
          if (hO < KO && MO > pO) return XX(XO, KO, pO, hO);
          if (MO >= KO && -1 == bK && (bK = CO, eO = hO), hO > pO && XO.dom.parentNode == OO.dom) {
            lO = CO, vK = DO;
            break
          }
          DO = MO, hO = MO + XO.breakAfter
        }
        return {
          from: eO,
          to: vK < 0 ? XO + OO.length : vK,
          startDOM: (bK ? OO.children[bK - 1].dom.nextSibling : null) || OO.dom.firstChild,
          endDOM: lO < OO.children.length && lO >= 0 ? OO.children[lO].dom : null
        }
      }
      return OO.isText() ? {
        from: XO,
        to: XO + OO.length,
        startDOM: OO.dom,
        endDOM: OO.dom.nextSibling
      } : null
    }

    function bb(OO, KO) {
      let pO, {
          newSel: bK
        } = KO,
        {
          state: eO
        } = OO,
        lO = eO.selection.main,
        vK = OO.inputState.lastKeyTime > Date.now() - 100 ? OO.inputState.lastKeyCode : -1;
      if (KO.bounds) {
        let {
          from: OO,
          to: bK
        } = KO.bounds, CO = lO.from, hO = null;
        (8 === vK || NO.android && KO.text.length < bK - OO) && (CO = lO.to, hO = "end");
        let DO, MO, aK = eO.doc.sliceString(OO, bK, tX);
        !lO.empty && lO.from >= OO && lO.to <= bK && (KO.typeOver || aK != KO.text) && aK.slice(0, lO.from - OO) == KO.text.slice(0, lO.from - OO) && aK.slice(lO.to - OO) == KO.text.slice(DO = KO.text.length - (aK.length - (lO.to - OO))) ? pO = {
          from: lO.from,
          to: lO.to,
          insert: XO.I.of(KO.text.slice(lO.from - OO, DO).split(tX))
        } : (MO = lX(aK, KO.text, CO - OO, hO)) && (NO.chrome && 13 == vK && MO.toB == MO.from + 2 && KO.text.slice(MO.from, MO.toB) == tX + tX && MO.toB--, pO = {
          from: OO + MO.from,
          to: OO + MO.toA,
          insert: XO.I.of(KO.text.slice(MO.from, MO.toB).split(tX))
        })
      } else bK && (!OO.hasFocus && eO.facet(qp) || vb(bK, lO)) && (bK = null);
      if (!pO && !bK) return !1;
      if ((NO.mac || NO.android) && pO && pO.from == pO.to && pO.from == lO.head - 1 && /^\. ?$/.test(pO.insert.toString()) && "off" == OO.contentDOM.getAttribute("autocorrect") ? (bK && 2 == pO.insert.length && (bK = XO.j.single(bK.main.anchor - 1, bK.main.head - 1)), pO = {
          from: pO.from,
          to: pO.to,
          insert: XO.I.of([pO.insert.toString().replace(".", " ")])
        }) : eO.doc.lineAt(lO.from).to < lO.to && OO.docView.lineHasWidget(lO.to) && OO.inputState.insertingTextAt > Date.now() - 50 ? pO = {
          from: lO.from,
          to: lO.to,
          insert: eO.toText(OO.inputState.insertingText)
        } : NO.chrome && pO && pO.from == pO.to && pO.from == lO.head && "\n " == pO.insert.toString() && OO.lineWrapping && (bK && (bK = XO.j.single(bK.main.anchor - 1, bK.main.head - 1)), pO = {
          from: lO.from,
          to: lO.to,
          insert: XO.I.of([" "])
        }), pO) return eX(OO, pO, bK, vK);
      if (bK && !vb(bK, lO)) {
        let KO = !1,
          pO = "select";
        return OO.inputState.lastSelectionTime > Date.now() - 50 && ("select" == OO.inputState.lastSelectionOrigin && (KO = !0), pO = OO.inputState.lastSelectionOrigin, "select.pointer" == pO && (bK = Gp(eO.facet(Xp).map((KO => KO(OO))), bK))), OO.dispatch({
          selection: bK,
          scrollIntoView: KO,
          userEvent: pO
        }), !0
      }
      return !1
    }

    function eX(OO, KO, pO) {
      let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : -1;
      if (NO.ios && OO.inputState.flushIOSKey(KO)) return !0;
      let eO = OO.state.selection.main;
      if (NO.android && (KO.to == eO.to && (KO.from == eO.from || KO.from == eO.from - 1 && " " == OO.state.sliceDoc(KO.from, eO.from)) && 1 == KO.insert.length && 2 == KO.insert.lines && bp(OO.contentDOM, "Enter", 13) || (KO.from == eO.from - 1 && KO.to == eO.to && 0 == KO.insert.length || 8 == bK && KO.insert.length < KO.to - KO.from && KO.to > eO.head) && bp(OO.contentDOM, "Backspace", 8) || KO.from == eO.from && KO.to == eO.to + 1 && 0 == KO.insert.length && bp(OO.contentDOM, "Delete", 46))) return !0;
      let lO, vK = KO.insert.toString();
      OO.inputState.composing >= 0 && OO.inputState.composing++;
      let CO = () => lO || (lO = function(OO, KO, pO) {
        let bK, eO = OO.state,
          lO = eO.selection.main,
          vK = -1;
        if (KO.from == KO.to && KO.from < lO.from || KO.from > lO.to) {
          let pO = KO.from < lO.from ? -1 : 1,
            XO = pO < 0 ? lO.from : lO.to,
            bK = Zp(eO.facet(Xp).map((KO => KO(OO))), XO, pO);
          KO.from == bK && (vK = bK)
        }
        if (vK > -1) bK = {
          changes: KO,
          selection: XO.j.cursor(KO.from + KO.insert.length, -1)
        };
        else if (KO.from >= lO.from && KO.to <= lO.to && KO.to - KO.from >= (lO.to - lO.from) / 3 && (!pO || pO.main.empty && pO.main.from == KO.from + KO.insert.length) && OO.inputState.composing < 0) {
          let pO = lO.from < KO.from ? eO.sliceDoc(lO.from, KO.from) : "",
            XO = lO.to > KO.to ? eO.sliceDoc(KO.to, lO.to) : "";
          bK = eO.replaceSelection(OO.state.toText(pO + KO.insert.sliceString(0, void 0, OO.state.lineBreak) + XO))
        } else {
          let vK = eO.changes(KO),
            CO = pO && pO.main.to <= vK.newLength ? pO.main : void 0;
          if (eO.selection.Xl.length > 1 && (OO.inputState.composing >= 0 || OO.inputState.compositionPendingChange) && KO.to <= lO.to + 10 && KO.to >= lO.to - 10) {
            let hO, DO = OO.state.sliceDoc(KO.from, KO.to),
              MO = pO && Hp(OO, pO.main.head);
            if (MO) {
              let OO = KO.insert.length - (KO.to - KO.from);
              hO = {
                from: MO.from,
                to: MO.to - OO
              }
            } else hO = OO.state.doc.lineAt(lO.head);
            let aK = lO.to - KO.to;
            bK = eO.changeByRange((pO => {
              if (pO.from == lO.from && pO.to == lO.to) return {
                changes: vK,
                range: CO || pO.map(vK)
              };
              let bK = pO.to - aK,
                MO = bK - DO.length;
              if (OO.state.sliceDoc(MO, bK) != DO || bK >= hO.from && MO <= hO.to) return {
                range: pO
              };
              let oO = eO.changes({
                  from: MO,
                  to: bK,
                  insert: KO.insert
                }),
                FO = pO.to - lO.to;
              return {
                changes: oO,
                range: CO ? XO.j.range(Math.max(0, CO.anchor + FO), Math.max(0, CO.head + FO)) : pO.map(oO)
              }
            }))
          } else bK = {
            changes: vK,
            selection: CO && eO.selection.replaceRange(CO)
          }
        }
        let CO = "input.type";
        (OO.composing || OO.inputState.compositionPendingChange && OO.inputState.compositionEndedAt > Date.now() - 50) && (OO.inputState.compositionPendingChange = !1, CO += ".compose", OO.inputState.compositionFirstChange && (CO += ".start", OO.inputState.compositionFirstChange = !1));
        return eO.update(bK, {
          userEvent: CO,
          scrollIntoView: !0
        })
      }(OO, KO, pO));
      return OO.state.facet(PK).some((pO => pO(OO, KO.from, KO.to, vK, CO))) || OO.dispatch(CO()), !0
    }

    function lX(OO, KO, pO, XO) {
      let bK = Math.min(OO.length, KO.length),
        eO = 0;
      for (; eO < bK && OO.charCodeAt(eO) == KO.charCodeAt(eO);) eO++;
      if (eO == bK && OO.length == KO.length) return null;
      let lO = OO.length,
        vK = KO.length;
      for (; lO > 0 && vK > 0 && OO.charCodeAt(lO - 1) == KO.charCodeAt(vK - 1);) lO--, vK--;
      if ("end" == XO) {
        pO -= lO + Math.max(0, eO - Math.min(lO, vK)) - eO
      }
      if (lO < eO && OO.length < KO.length) {
        eO -= pO <= eO && pO >= lO ? eO - pO : 0, vK = eO + (vK - lO), lO = eO
      } else if (vK < eO) {
        eO -= pO <= eO && pO >= vK ? eO - pO : 0, lO = eO + (lO - vK), vK = eO
      }
      return {
        from: eO,
        toA: lO,
        toB: vK
      }
    }

    function vb(OO, KO) {
      return KO.head == OO.main.head && KO.anchor == OO.main.anchor
    }
    class CX {
      setSelectionOrigin(OO) {
        this.lastSelectionOrigin = OO, this.lastSelectionTime = Date.now()
      }
      constructor(OO) {
        this.view = OO, this.lastKeyCode = 0, this.lastKeyTime = 0, this.lastTouchTime = 0, this.lastTouchX = 0, this.lastTouchY = 0, this.lastFocusTime = 0, this.lastScrollTop = 0, this.lastScrollLeft = 0, this.lastWheelEvent = 0, this.pendingIOSKey = void 0, this.tabFocusMode = -1, this.lastSelectionOrigin = null, this.lastSelectionTime = 0, this.lastContextMenu = 0, this.scrollHandlers = [], this.handlers = Object.create(null), this.composing = -1, this.compositionFirstChange = null, this.compositionEndedAt = 0, this.compositionPendingKey = !1, this.compositionPendingChange = !1, this.insertingText = "", this.insertingTextAt = 0, this.mouseSelection = null, this.draggedContent = null, this.handleEvent = this.handleEvent.bind(this), this.notifiedFocused = OO.hasFocus, NO.safari && OO.contentDOM.addEventListener("input", (() => null)), NO.gecko && function(OO) {
          ib.has(OO) || (ib.add(OO), OO.addEventListener("copy", (() => {})), OO.addEventListener("cut", (() => {})))
        }(OO.contentDOM.ownerDocument)
      }
      handleEvent(OO) {
        (function(OO, KO) {
          if (!KO.bubbles) return !0;
          if (KO.defaultPrevented) return !1;
          for (let pO, XO = KO.target; XO != OO.contentDOM; XO = XO.parentNode)
            if (!XO || 11 == XO.nodeType || (pO = aX.get(XO)) && pO.isWidget() && !pO.isHidden && pO.widget.ignoreEvent(KO)) return !1;
          return !0
        })(this.view, OO) && !this.ignoreDuringComposition(OO) && ("keydown" == OO.type && this.keydown(OO) || (0 != this.view.updateState ? Promise.resolve().then((() => this.runHandlers(OO.type, OO))) : this.runHandlers(OO.type, OO)))
      }
      runHandlers(OO, KO) {
        let pO = this.handlers[OO];
        if (pO) {
          for (let OO of pO.observers) OO(this.view, KO);
          for (let OO of pO.handlers) {
            if (KO.defaultPrevented) break;
            if (OO(this.view, KO)) {
              KO.preventDefault();
              break
            }
          }
        }
      }
      ensureHandlers(OO) {
        let KO = DX(OO),
          pO = this.handlers,
          XO = this.view.contentDOM;
        for (let bK in KO)
          if ("scroll" != bK) {
            let OO = !KO[bK].handlers.length,
              eO = pO[bK];
            eO && OO != !eO.handlers.length && (XO.removeEventListener(bK, this.handleEvent), eO = null), eO || XO.addEventListener(bK, this.handleEvent, {
              passive: OO
            })
          } for (let bK in pO) "scroll" == bK || KO[bK] || XO.removeEventListener(bK, this.handleEvent);
        this.handlers = KO
      }
      keydown(OO) {
        if (this.lastKeyCode = OO.keyCode, this.lastKeyTime = Date.now(), 9 == OO.keyCode && this.tabFocusMode > -1 && (!this.tabFocusMode || Date.now() <= this.tabFocusMode)) return !0;
        if (this.tabFocusMode > 0 && 27 != OO.keyCode && oX.indexOf(OO.keyCode) < 0 && (this.tabFocusMode = -1), NO.android && NO.chrome && !OO.synthetic && (13 == OO.keyCode || 8 == OO.keyCode)) return this.view.observer.delayAndroidKey(OO.key, OO.keyCode), !0;
        let KO;
        return !NO.ios || OO.synthetic || OO.altKey || OO.metaKey || OO.shiftKey || !((KO = MX.find((KO => KO.keyCode == OO.keyCode))) && !OO.ctrlKey || ab.indexOf(OO.key) > -1 && OO.ctrlKey) ? (229 != OO.keyCode && this.view.observer.forceFlush(), !1) : (this.pendingIOSKey = KO || OO, setTimeout((() => this.flushIOSKey()), 250), !0)
      }
      flushIOSKey(OO) {
        let KO = this.pendingIOSKey;
        return !!KO && (!("Enter" == KO.key && OO && OO.from < OO.to && /^\S+$/.test(OO.insert.toString())) && (this.pendingIOSKey = void 0, bp(this.view.contentDOM, KO.key, KO.keyCode, KO instanceof KeyboardEvent ? KO : void 0)))
      }
      ignoreDuringComposition(OO) {
        return !(!/^key/.test(OO.type) || OO.synthetic) && (this.composing > 0 || !!(NO.safari && !NO.ios && this.compositionPendingKey && Date.now() - this.compositionEndedAt < 100) && (this.compositionPendingKey = !1, !0))
      }
      startMouseSelection(OO) {
        this.mouseSelection && this.mouseSelection.destroy(), this.mouseSelection = OO
      }
      update(OO) {
        this.view.observer.update(OO), this.mouseSelection && this.mouseSelection.update(OO), this.draggedContent && OO.docChanged && (this.draggedContent = this.draggedContent.map(OO.changes)), OO.transactions.length && (this.lastKeyCode = this.lastSelectionTime = 0)
      }
      destroy() {
        this.mouseSelection && this.mouseSelection.destroy()
      }
    }

    function hX(OO, KO) {
      return (pO, XO) => {
        try {
          return KO.call(OO, XO, pO)
        } catch (bK) {
          GK(pO.state, bK)
        }
      }
    }

    function DX(OO) {
      let KO = Object.create(null);

      function pO(OO) {
        return KO[OO] || (KO[OO] = {
          observers: [],
          handlers: []
        })
      }
      for (let XO of OO) {
        let OO = XO.spec,
          KO = OO && OO.plugin.domEventHandlers,
          bK = OO && OO.plugin.domEventObservers;
        if (KO)
          for (let eO in KO) {
            let OO = KO[eO];
            OO && pO(eO).handlers.push(hX(XO.value, OO))
          }
        if (bK)
          for (let eO in bK) {
            let OO = bK[eO];
            OO && pO(eO).observers.push(hX(XO.value, OO))
          }
      }
      for (let XO in LX) pO(XO).handlers.push(LX[XO]);
      for (let XO in QX) pO(XO).observers.push(QX[XO]);
      return KO
    }
    const MX = [{
        key: "Backspace",
        keyCode: 8,
        inputType: "deleteContentBackward"
      }, {
        key: "Enter",
        keyCode: 13,
        inputType: "insertParagraph"
      }, {
        key: "Enter",
        keyCode: 13,
        inputType: "insertLineBreak"
      }, {
        key: "Delete",
        keyCode: 46,
        inputType: "deleteContentForward"
      }],
      ab = "dthko",
      oX = [16, 17, 18, 20, 91, 92, 224, 225];

    function FX(OO) {
      return .7 * Math.max(0, OO) + 8
    }
    class VX {
      constructor(OO, KO, pO, bK) {
        this.view = OO, this.startEvent = KO, this.style = pO, this.mustSelect = bK, this.scrollSpeed = {
          x: 0,
          y: 0
        }, this.scrolling = -1, this.lastEvent = KO, this.scrollParents = kK(OO.contentDOM), this.atoms = OO.state.facet(Xp).map((KO => KO(OO)));
        let eO = OO.contentDOM.ownerDocument;
        eO.addEventListener("mousemove", this.move = this.move.bind(this)), eO.addEventListener("mouseup", this.up = this.up.bind(this)), this.extend = KO.shiftKey, this.multiple = OO.state.facet(XO.m.allowMultipleSelections) && function(OO, KO) {
          let pO = OO.state.facet(jp);
          return pO.length ? pO[0](KO) : NO.mac ? KO.metaKey : KO.ctrlKey
        }(OO, KO), this.dragging = !(! function(OO, KO) {
          let {
            main: pO
          } = OO.state.selection;
          if (pO.empty) return !1;
          let XO = RO(OO.root);
          if (!XO || 0 == XO.rangeCount) return !0;
          let bK = XO.getRangeAt(0).getClientRects();
          for (let eO = 0; eO < bK.length; eO++) {
            let OO = bK[eO];
            if (OO.left <= KO.clientX && OO.right >= KO.clientX && OO.top <= KO.clientY && OO.bottom >= KO.clientY) return !0
          }
          return !1
        }(OO, KO) || 1 != gb(KO)) && null
      }
      start(OO) {
        !1 === this.dragging && this.select(OO)
      }
      move(OO) {
        if (0 == OO.buttons) return this.destroy();
        if (this.dragging || null == this.dragging && (KO = this.startEvent, pO = OO, Math.max(Math.abs(KO.clientX - pO.clientX), Math.abs(KO.clientY - pO.clientY)) < 10)) return;
        var KO, pO;
        this.select(this.lastEvent = OO);
        let XO = 0,
          bK = 0,
          eO = 0,
          lO = 0,
          vK = this.view.win.innerWidth,
          CO = this.view.win.innerHeight;
        this.scrollParents.x && ({
          left: eO,
          right: vK
        } = this.scrollParents.x.getBoundingClientRect()), this.scrollParents.y && ({
          top: lO,
          bottom: CO
        } = this.scrollParents.y.getBoundingClientRect());
        let hO = vX(this.view);
        OO.clientX - hO.left <= eO + 6 ? XO = -FX(eO - OO.clientX) : OO.clientX + hO.right >= vK - 6 && (XO = FX(OO.clientX - vK)), OO.clientY - hO.top <= lO + 6 ? bK = -FX(lO - OO.clientY) : OO.clientY + hO.bottom >= CO - 6 && (bK = FX(OO.clientY - CO)), this.setScrollSpeed(XO, bK)
      }
      up(OO) {
        null == this.dragging && this.select(this.lastEvent), this.dragging || OO.preventDefault(), this.destroy()
      }
      destroy() {
        this.setScrollSpeed(0, 0);
        let OO = this.view.contentDOM.ownerDocument;
        OO.removeEventListener("mousemove", this.move), OO.removeEventListener("mouseup", this.up), this.view.inputState.mouseSelection = this.view.inputState.draggedContent = null
      }
      setScrollSpeed(OO, KO) {
        this.scrollSpeed = {
          x: OO,
          y: KO
        }, OO || KO ? this.scrolling < 0 && (this.scrolling = setInterval((() => this.scroll()), 50)) : this.scrolling > -1 && (clearInterval(this.scrolling), this.scrolling = -1)
      }
      scroll() {
        let {
          x: OO,
          y: KO
        } = this.scrollSpeed;
        OO && this.scrollParents.x && (this.scrollParents.x.scrollLeft += OO, OO = 0), KO && this.scrollParents.y && (this.scrollParents.y.scrollTop += KO, KO = 0), (OO || KO) && this.view.win.scrollBy(OO, KO), !1 === this.dragging && this.select(this.lastEvent)
      }
      select(OO) {
        let {
          view: KO
        } = this, pO = Gp(this.atoms, this.style.get(OO, this.extend, this.multiple));
        !this.mustSelect && pO.eq(KO.state.selection, !1 === this.dragging) || this.view.dispatch({
          selection: pO,
          userEvent: "select.pointer"
        }), this.mustSelect = !1
      }
      update(OO) {
        OO.transactions.some((OO => OO.isUserEvent("input.type"))) ? this.destroy() : this.style.update(OO) && setTimeout((() => this.select(this.lastEvent)), 20)
      }
    }
    const LX = Object.create(null),
      QX = Object.create(null),
      zb = NO.ie && NO.ie_version < 15 || NO.ios && NO.webkit_version < 604;

    function AX(OO, KO, pO) {
      for (let XO of OO.facet(KO)) pO = XO(pO, OO);
      return pO
    }

    function fX(OO, KO) {
      KO = AX(OO.state, sK, KO);
      let pO, {
          state: bK
        } = OO,
        eO = 1,
        lO = bK.toText(KO),
        vK = lO.lines == bK.selection.Xl.length;
      if (null != EX && bK.selection.Xl.every((OO => OO.empty)) && EX == lO.toString()) {
        let OO = -1;
        pO = bK.changeByRange((pO => {
          let CO = bK.doc.lineAt(pO.from);
          if (CO.from == OO) return {
            range: pO
          };
          OO = CO.from;
          let hO = bK.toText((vK ? lO.line(eO++).text : KO) + bK.lineBreak);
          return {
            changes: {
              from: CO.from,
              insert: hO
            },
            range: XO.j.cursor(pO.from + hO.length)
          }
        }))
      } else pO = vK ? bK.changeByRange((OO => {
        let KO = lO.line(eO++);
        return {
          changes: {
            from: OO.from,
            to: OO.to,
            insert: KO.text
          },
          range: XO.j.cursor(OO.from + KO.length)
        }
      })) : bK.replaceSelection(lO);
      OO.dispatch(pO, {
        userEvent: "input.paste",
        scrollIntoView: !0
      })
    }

    function dX(OO, KO, pO, bK) {
      if (1 == bK) return XO.j.cursor(KO, pO);
      if (2 == bK) return function(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
          bK = OO.charCategorizer(KO),
          eO = OO.doc.lineAt(KO),
          lO = KO - eO.from;
        if (0 == eO.length) return XO.j.cursor(KO);
        0 == lO ? pO = 1 : lO == eO.length && (pO = -1);
        let vK = lO,
          CO = lO;
        pO < 0 ? vK = (0, XO.Y)(eO.text, lO, !1) : CO = (0, XO.Y)(eO.text, lO);
        let hO = bK(eO.text.slice(vK, CO));
        for (; vK > 0;) {
          let OO = (0, XO.Y)(eO.text, vK, !1);
          if (bK(eO.text.slice(OO, vK)) != hO) break;
          vK = OO
        }
        for (; CO < eO.length;) {
          let OO = (0, XO.Y)(eO.text, CO);
          if (bK(eO.text.slice(CO, OO)) != hO) break;
          CO = OO
        }
        return XO.j.range(vK + eO.from, CO + eO.from)
      }(OO.state, KO, pO);
      {
        let bK = OO.docView.lineAt(KO, pO),
          eO = OO.state.doc.lineAt(bK ? bK.posAtEnd : KO),
          lO = bK ? bK.posAtStart : eO.from,
          vK = bK ? bK.posAtEnd : eO.to;
        return vK < OO.state.doc.length && vK == eO.to && vK++, XO.j.range(lO, vK)
      }
    }
    QX.scroll = OO => {
      OO.inputState.lastScrollTop = OO.scrollDOM.scrollTop, OO.inputState.lastScrollLeft = OO.scrollDOM.scrollLeft
    }, QX.wheel = QX.mousewheel = OO => {
      OO.inputState.lastWheelEvent = Date.now()
    }, LX.keydown = (OO, KO) => (OO.inputState.setSelectionOrigin("select"), 27 == KO.keyCode && 0 != OO.inputState.tabFocusMode && (OO.inputState.tabFocusMode = Date.now() + 2e3), !1), QX.touchstart = (OO, KO) => {
      let pO = OO.inputState,
        XO = KO.targetTouches[0];
      pO.lastTouchTime = Date.now(), XO && (pO.lastTouchX = XO.clientX, pO.lastTouchY = XO.clientY), pO.setSelectionOrigin("select.pointer")
    }, QX.touchmove = OO => {
      OO.inputState.setSelectionOrigin("select.pointer")
    }, LX.mousedown = (OO, KO) => {
      if (OO.observer.flush(), OO.inputState.lastTouchTime > Date.now() - 2e3) return !1;
      let pO = null;
      for (let XO of OO.state.facet(wK))
        if (pO = XO(OO, KO), pO) break;
      if (pO || 0 != KO.button || (pO = function(OO, KO) {
          let pO = OO.posAndSideAtCoords({
              x: KO.clientX,
              y: KO.clientY
            }, !1),
            bK = gb(KO),
            eO = OO.state.selection;
          return {
            update(OO) {
              OO.docChanged && (pO.pos = OO.changes.mapPos(pO.pos), eO = eO.map(OO.changes))
            },
            get(KO, lO, vK) {
              let CO, hO = OO.posAndSideAtCoords({
                  x: KO.clientX,
                  y: KO.clientY
                }, !1),
                DO = dX(OO, hO.pos, hO.assoc, bK);
              if (pO.pos != hO.pos && !lO) {
                let KO = dX(OO, pO.pos, pO.assoc, bK),
                  eO = Math.min(KO.from, DO.from),
                  lO = Math.max(KO.to, DO.to);
                DO = eO < DO.from ? XO.j.range(eO, lO, DO.assoc) : XO.j.range(lO, eO, DO.assoc)
              }
              return lO ? eO.replaceRange(eO.main.extend(DO.from, DO.to, DO.assoc)) : vK && 1 == bK && eO.Xl.length > 1 && (CO = function(OO, KO) {
                for (let pO = 0; pO < OO.Xl.length; pO++) {
                  let {
                    from: bK,
                    to: eO
                  } = OO.Xl[pO];
                  if (bK <= KO && eO >= KO) return XO.j.create(OO.Xl.slice(0, pO).concat(OO.Xl.slice(pO + 1)), OO.mainIndex == pO ? 0 : OO.mainIndex - (OO.mainIndex > pO ? 1 : 0))
                }
                return null
              }(eO, hO.pos)) ? CO : vK ? eO.addRange(DO) : XO.j.create([DO])
            }
          }
        }(OO, KO)), pO) {
        let XO = !OO.hasFocus;
        OO.inputState.startMouseSelection(new VX(OO, KO, pO, XO)), XO && OO.observer.ignore((() => {
          pK(OO.contentDOM);
          let KO = OO.root.activeElement;
          KO && !KO.contains(OO.contentDOM) && KO.blur()
        }));
        let bK = OO.inputState.mouseSelection;
        if (bK) return bK.start(KO), !1 === bK.dragging
      } else OO.inputState.setSelectionOrigin("select.pointer");
      return !1
    };
    const TX = NO.ie && NO.ie_version <= 11;
    let NX = null,
      IX = 0,
      yb = 0;

    function gb(OO) {
      if (!TX) return OO.detail;
      let KO = NX,
        pO = yb;
      return NX = OO, yb = Date.now(), IX = !KO || pO > Date.now() - 400 && Math.abs(KO.clientX - OO.clientX) < 2 && Math.abs(KO.clientY - OO.clientY) < 2 ? (IX + 1) % 3 : 1
    }

    function uX(OO, KO, pO, XO) {
      if (!(pO = AX(OO.state, sK, pO))) return;
      let bK = OO.posAtCoords({
          x: KO.clientX,
          y: KO.clientY
        }, !1),
        {
          draggedContent: eO
        } = OO.inputState,
        lO = XO && eO && function(OO, KO) {
          let pO = OO.state.facet(YK);
          return pO.length ? pO[0](KO) : NO.mac ? !KO.altKey : !KO.ctrlKey
        }(OO, KO) ? {
          from: eO.from,
          to: eO.to
        } : null,
        vK = {
          from: bK,
          insert: pO
        },
        CO = OO.state.changes(lO ? [lO, vK] : vK);
      OO.focus(), OO.dispatch({
        changes: CO,
        selection: {
          anchor: CO.mapPos(bK, -1),
          head: CO.mapPos(bK, 1)
        },
        userEvent: lO ? "move.drop" : "input.drop"
      }), OO.inputState.draggedContent = null
    }
    LX.dragstart = (OO, KO) => {
      let {
        selection: {
          main: pO
        }
      } = OO.state;
      if (KO.target.draggable) {
        let bK = OO.docView.tile.nearest(KO.target);
        if (bK && bK.isWidget()) {
          let OO = bK.posAtStart,
            KO = OO + bK.length;
          (OO >= pO.to || KO <= pO.from) && (pO = XO.j.range(OO, KO))
        }
      }
      let {
        inputState: bK
      } = OO;
      return bK.mouseSelection && (bK.mouseSelection.dragging = !0), bK.draggedContent = pO, KO.dataTransfer && (KO.dataTransfer.setData("Text", AX(OO.state, HK, OO.state.sliceDoc(pO.from, pO.to))), KO.dataTransfer.effectAllowed = "copyMove"), !1
    }, LX.dragend = OO => (OO.inputState.draggedContent = null, !1), LX.drop = (OO, KO) => {
      if (!KO.dataTransfer) return !1;
      if (OO.state.readOnly) return !0;
      let pO = KO.dataTransfer.files;
      if (pO && pO.length) {
        let XO = Array(pO.length),
          bK = 0,
          eO = () => {
            ++bK == pO.length && uX(OO, KO, XO.filter((OO => null != OO)).join(OO.state.lineBreak), !1)
          };
        for (let OO = 0; OO < pO.length; OO++) {
          let KO = new FileReader;
          KO.onerror = eO, KO.onload = () => {
            /[\x00-\x08\x0e-\x1f]{2}/.test(KO.result) || (XO[OO] = KO.result), eO()
          }, KO.readAsText(pO[OO])
        }
        return !0
      } {
        let pO = KO.dataTransfer.getData("Text");
        if (pO) return uX(OO, KO, pO, !0), !0
      }
      return !1
    }, LX.paste = (OO, KO) => {
      if (OO.state.readOnly) return !0;
      OO.observer.flush();
      let pO = zb ? null : KO.clipboardData;
      return pO ? (fX(OO, pO.getData("text/plain") || pO.getData("text/uri-list")), !0) : (function(OO) {
        let KO = OO.dom.parentNode;
        if (!KO) return;
        let pO = KO.appendChild(document.createElement("textarea"));
        pO.style.cssText = "position: fixed; left: -10000px; top: 10px", pO.focus(), setTimeout((() => {
          OO.focus(), pO.remove(), fX(OO, pO.value)
        }), 50)
      }(OO), !1)
    };
    let EX = null;
    LX.copy = LX.cut = (OO, KO) => {
      if (!JO(OO.contentDOM, OO.observer.selectionRange)) return !1;
      let {
        text: pO,
        Xl: XO,
        linewise: bK
      } = function(OO) {
        let KO = [],
          pO = [],
          XO = !1;
        for (let bK of OO.selection.Xl) bK.empty || (KO.push(OO.sliceDoc(bK.from, bK.to)), pO.push(bK));
        if (!KO.length) {
          let bK = -1;
          for (let {
              from: XO
            }
            of OO.selection.Xl) {
            let eO = OO.doc.lineAt(XO);
            eO.number > bK && (KO.push(eO.text), pO.push({
              from: eO.from,
              to: Math.min(OO.doc.length, eO.to + 1)
            })), bK = eO.number
          }
          XO = !0
        }
        return {
          text: AX(OO, HK, KO.join(OO.lineBreak)),
          Xl: pO,
          linewise: XO
        }
      }(OO.state);
      if (!pO && !bK) return !1;
      EX = bK ? pO : null, "cut" != KO.type || OO.state.readOnly || OO.dispatch({
        changes: XO,
        scrollIntoView: !0,
        userEvent: "delete.cut"
      });
      let eO = zb ? null : KO.clipboardData;
      return eO ? (eO.clearData(), eO.setData("text/plain", pO), !0) : (function(OO, KO) {
        let pO = OO.dom.parentNode;
        if (!pO) return;
        let XO = pO.appendChild(document.createElement("textarea"));
        XO.style.cssText = "position: fixed; left: -10000px; top: 10px", XO.value = KO, XO.focus(), XO.selectionEnd = KO.length, XO.selectionStart = 0, setTimeout((() => {
          XO.remove(), OO.focus()
        }), 50)
      }(OO, pO), !1)
    };
    const jb = XO.d.define();

    function YX(OO, KO) {
      let pO = [];
      for (let XO of OO.facet(mp)) {
        let bK = XO(OO, KO);
        bK && pO.push(bK)
      }
      return pO.length ? OO.update({
        effects: pO,
        annotations: jb.of(!0)
      }) : null
    }

    function wX(OO) {
      setTimeout((() => {
        let KO = OO.hasFocus;
        if (KO != OO.inputState.notifiedFocused) {
          let pO = YX(OO.state, KO);
          pO ? OO.dispatch(pO) : OO.update([])
        }
      }), 10)
    }
    QX.focus = OO => {
      OO.inputState.lastFocusTime = Date.now(), OO.scrollDOM.scrollTop || !OO.inputState.lastScrollTop && !OO.inputState.lastScrollLeft || (OO.scrollDOM.scrollTop = OO.inputState.lastScrollTop, OO.scrollDOM.scrollLeft = OO.inputState.lastScrollLeft), wX(OO)
    }, QX.blur = OO => {
      OO.observer.clearSelectionRange(), wX(OO)
    }, QX.compositionstart = QX.compositionupdate = OO => {
      OO.observer.editContext || (null == OO.inputState.compositionFirstChange && (OO.inputState.compositionFirstChange = !0), OO.inputState.composing < 0 && (OO.inputState.composing = 0))
    }, QX.compositionend = OO => {
      OO.observer.editContext || (OO.inputState.composing = -1, OO.inputState.compositionEndedAt = Date.now(), OO.inputState.compositionPendingKey = !0, OO.inputState.compositionPendingChange = OO.observer.pendingRecords().length > 0, OO.inputState.compositionFirstChange = null, NO.chrome && NO.android ? OO.observer.flushSoon() : OO.inputState.compositionPendingChange ? Promise.resolve().then((() => OO.observer.flush())) : setTimeout((() => {
        OO.inputState.composing < 0 && OO.docView.hasComposition && OO.update([])
      }), 50))
    }, QX.contextmenu = OO => {
      OO.inputState.lastContextMenu = Date.now()
    }, LX.beforeinput = (OO, KO) => {
      var pO, XO;
      if ("insertText" != KO.inputType && "insertCompositionText" != KO.inputType || (OO.inputState.insertingText = KO.data, OO.inputState.insertingTextAt = Date.now()), "insertReplacementText" == KO.inputType && OO.observer.editContext) {
        let XO = null === (pO = KO.dataTransfer) || void 0 === pO ? void 0 : pO.getData("text/plain"),
          bK = KO.getTargetRanges();
        if (XO && bK.length) {
          let KO = bK[0],
            pO = OO.posAtDOM(KO.startContainer, KO.startOffset),
            eO = OO.posAtDOM(KO.endContainer, KO.endOffset);
          return eX(OO, {
            from: pO,
            to: eO,
            insert: OO.state.toText(XO)
          }, null), !0
        }
      }
      let bK;
      if (NO.chrome && NO.android && (bK = MX.find((OO => OO.inputType == KO.inputType))) && (OO.observer.delayAndroidKey(bK.key, bK.keyCode), "Backspace" == bK.key || "Delete" == bK.key)) {
        let KO = (null === (XO = window.visualViewport) || void 0 === XO ? void 0 : XO.height) || 0;
        setTimeout((() => {
          var pO;
          ((null === (pO = window.visualViewport) || void 0 === pO ? void 0 : pO.height) || 0) > KO + 10 && OO.hasFocus && (OO.contentDOM.blur(), OO.focus())
        }), 100)
      }
      return NO.ios && "deleteContentForward" == KO.inputType && OO.observer.flushSoon(), NO.safari && "insertText" == KO.inputType && OO.inputState.composing >= 0 && setTimeout((() => QX.compositionend(OO, KO)), 20), !1
    };
    const ib = new Set;
    const rb = ["pre-wrap", "normal", "pre-line", "break-spaces"];
    let PX = !1;

    function mb() {
      PX = !1
    }
    class sX {
      constructor(OO) {
        this.lineWrapping = OO, this.doc = XO.I.empty, this.heightSamples = {}, this.lineHeight = 14, this.charWidth = 7, this.textHeight = 14, this.lineLength = 30
      }
      heightForGap(OO, KO) {
        let pO = this.doc.lineAt(KO).number - this.doc.lineAt(OO).number + 1;
        return this.lineWrapping && (pO += Math.max(0, Math.ceil((KO - OO - pO * this.lineLength * .5) / this.lineLength))), this.lineHeight * pO
      }
      heightForLine(OO) {
        if (!this.lineWrapping) return this.lineHeight;
        return (1 + Math.max(0, Math.ceil((OO - this.lineLength) / Math.max(1, this.lineLength - 5)))) * this.lineHeight
      }
      setDoc(OO) {
        return this.doc = OO, this
      }
      mustRefreshForWrapping(OO) {
        return rb.indexOf(OO) > -1 != this.lineWrapping
      }
      mustRefreshForHeights(OO) {
        let KO = !1;
        for (let pO = 0; pO < OO.length; pO++) {
          let XO = OO[pO];
          XO < 0 ? pO++ : this.heightSamples[Math.floor(10 * XO)] || (KO = !0, this.heightSamples[Math.floor(10 * XO)] = !0)
        }
        return KO
      }
      refresh(OO, KO, pO, XO, bK, eO) {
        let lO = rb.indexOf(OO) > -1,
          vK = Math.abs(KO - this.lineHeight) > .3 || this.lineWrapping != lO || Math.abs(pO - this.charWidth) > .1;
        if (this.lineWrapping = lO, this.lineHeight = KO, this.charWidth = pO, this.textHeight = XO, this.lineLength = bK, vK) {
          this.heightSamples = {};
          for (let OO = 0; OO < eO.length; OO++) {
            let KO = eO[OO];
            KO < 0 ? OO++ : this.heightSamples[Math.floor(10 * KO)] = !0
          }
        }
        return vK
      }
    }
    class HX {
      constructor(OO, KO) {
        this.from = OO, this.heights = KO, this.index = 0
      }
      get more() {
        return this.index < this.heights.length
      }
    }
    class RX {
      constructor(OO, KO, pO, XO, bK) {
        this.from = OO, this.length = KO, this.top = pO, this.height = XO, this._content = bK
      }
      get type() {
        return "number" == typeof this._content ? YO.Text : Array.isArray(this._content) ? this._content : this._content.type
      }
      get to() {
        return this.from + this.length
      }
      get bottom() {
        return this.top + this.height
      }
      get widget() {
        return this._content instanceof PO ? this._content.widget : null
      }
      get widgetLineBreaks() {
        return "number" == typeof this._content ? this._content : 0
      }
      join(OO) {
        let KO = (Array.isArray(this._content) ? this._content : [this]).concat(Array.isArray(OO._content) ? OO._content : [OO]);
        return new RX(this.from, this.length + OO.length, this.top, this.height + OO.height, KO)
      }
    }
    var SX = function(OO) {
      return OO[OO.ByPos = 0] = "ByPos", OO[OO.ByHeight = 1] = "ByHeight", OO[OO.ByPosNoHeight = 2] = "ByPosNoHeight", OO
    }(SX || (SX = {}));
    const JX = .001;
    class cb {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2;
        this.length = OO, this.height = KO, this.flags = pO
      }
      get outdated() {
        return (2 & this.flags) > 0
      }
      set outdated(OO) {
        this.flags = (OO ? 2 : 0) | -3 & this.flags
      }
      setHeight(OO) {
        this.height != OO && (Math.abs(this.height - OO) > JX && (PX = !0), this.height = OO)
      }
      replace(OO, KO, pO) {
        return cb.of(pO)
      }
      decomposeLeft(OO, KO) {
        KO.push(this)
      }
      decomposeRight(OO, KO) {
        KO.push(this)
      }
      applyChanges(OO, KO, pO, XO) {
        let bK = this,
          eO = pO.doc;
        for (let lO = XO.length - 1; lO >= 0; lO--) {
          let {
            fromA: vK,
            toA: CO,
            fromB: hO,
            toB: DO
          } = XO[lO], MO = bK.lineAt(vK, SX.ByPosNoHeight, pO.setDoc(KO), 0, 0), aK = MO.to >= CO ? MO : bK.lineAt(CO, SX.ByPosNoHeight, pO, 0, 0);
          for (DO += aK.to - CO, CO = aK.to; lO > 0 && MO.from <= XO[lO - 1].toA;) vK = XO[lO - 1].fromA, hO = XO[lO - 1].fromB, lO--, vK < MO.from && (MO = bK.lineAt(vK, SX.ByPosNoHeight, pO, 0, 0));
          hO += MO.from - vK, vK = MO.from;
          let oO = tb.build(pO.setDoc(eO), OO, hO, DO);
          bK = BX(bK, bK.replace(vK, CO, oO))
        }
        return bK.updateHeight(pO, 0)
      }
      static empty() {
        return new qb(0, 0, 0)
      }
      static of (OO) {
        if (1 == OO.length) return OO[0];
        let KO = 0,
          pO = OO.length,
          XO = 0,
          bK = 0;
        for (;;)
          if (KO == pO)
            if (XO > 2 * bK) {
              let bK = OO[KO - 1];
              bK.break ? OO.splice(--KO, 1, bK.left, null, bK.right) : OO.splice(--KO, 1, bK.left, bK.right), pO += 1 + bK.break, XO -= bK.size
            } else {
              if (!(bK > 2 * XO)) break;
              {
                let KO = OO[pO];
                KO.break ? OO.splice(pO, 1, KO.left, null, KO.right) : OO.splice(pO, 1, KO.left, KO.right), pO += 2 + KO.break, bK -= KO.size
              }
            }
        else if (XO < bK) {
          let pO = OO[KO++];
          pO && (XO += pO.size)
        } else {
          let KO = OO[--pO];
          KO && (bK += KO.size)
        }
        let eO = 0;
        return null == OO[KO - 1] ? (eO = 1, KO--) : null == OO[KO] && (eO = 1, pO++), new nX(cb.of(OO.slice(0, KO)), eO, cb.of(OO.slice(pO)))
      }
    }

    function BX(OO, KO) {
      return OO == KO ? OO : (OO.constructor != KO.constructor && (PX = !0), KO)
    }
    cb.prototype.size = 1;
    const ZX = wO.replace({});
    class GX extends cb {
      constructor(OO, KO, pO) {
        super(OO, KO), this.deco = pO, this.spaceAbove = 0
      }
      mainBlock(OO, KO) {
        return new RX(KO, this.length, OO + this.spaceAbove, this.height - this.spaceAbove, this.deco || 0)
      }
      blockAt(OO, KO, pO, XO) {
        return this.spaceAbove && OO < pO + this.spaceAbove ? new RX(XO, 0, pO, this.spaceAbove, ZX) : this.mainBlock(pO, XO)
      }
      lineAt(OO, KO, pO, XO, bK) {
        let eO = this.mainBlock(XO, bK);
        return this.spaceAbove ? this.blockAt(0, pO, XO, bK).join(eO) : eO
      }
      forEachLine(OO, KO, pO, XO, bK, eO) {
        OO <= bK + this.length && KO >= bK && eO(this.lineAt(0, SX.ByPos, pO, XO, bK))
      }
      setMeasuredHeight(OO) {
        let KO = OO.heights[OO.index++];
        KO < 0 ? (this.spaceAbove = -KO, KO = OO.heights[OO.index++]) : this.spaceAbove = 0, this.setHeight(KO)
      }
      updateHeight(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 3 ? arguments[3] : void 0;
        return pO && pO.from <= KO && pO.more && this.setMeasuredHeight(pO), this.outdated = !1, this
      }
      toString() {
        return `block(${this.length})`
      }
    }
    class qb extends GX {
      constructor(OO, KO, pO) {
        super(OO, KO, null), this.collapsed = 0, this.widgetHeight = 0, this.breaks = 0, this.spaceAbove = pO
      }
      mainBlock(OO, KO) {
        return new RX(KO, this.length, OO + this.spaceAbove, this.height - this.spaceAbove, this.breaks)
      }
      replace(OO, KO, pO) {
        let XO = pO[0];
        return 1 == pO.length && (XO instanceof qb || XO instanceof xb && 4 & XO.flags) && Math.abs(this.length - XO.length) < 10 ? (XO instanceof xb ? XO = new qb(XO.length, this.height, this.spaceAbove) : XO.height = this.height, this.outdated || (XO.outdated = !1), XO) : cb.of(pO)
      }
      updateHeight(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 ? arguments[3] : void 0;
        return XO && XO.from <= KO && XO.more ? this.setMeasuredHeight(XO) : (pO || this.outdated) && (this.spaceAbove = 0, this.setHeight(Math.max(this.widgetHeight, OO.heightForLine(this.length - this.collapsed)) + this.breaks * OO.lineHeight)), this.outdated = !1, this
      }
      toString() {
        return `line(${this.length}${this.collapsed?-this.collapsed:""}${this.widgetHeight?":"+this.widgetHeight:""})`
      }
    }
    class xb extends cb {
      constructor(OO) {
        super(OO, 0)
      }
      heightMetrics(OO, KO) {
        let pO, XO = OO.doc.lineAt(KO).number,
          bK = OO.doc.lineAt(KO + this.length).number,
          eO = bK - XO + 1,
          lO = 0;
        if (OO.lineWrapping) {
          let KO = Math.min(this.height, OO.lineHeight * eO);
          pO = KO / eO, this.length > eO + 1 && (lO = (this.height - KO) / (this.length - eO - 1))
        } else pO = this.height / eO;
        return {
          firstLine: XO,
          lastLine: bK,
          perLine: pO,
          perChar: lO
        }
      }
      blockAt(OO, KO, pO, XO) {
        let {
          firstLine: bK,
          lastLine: eO,
          perLine: lO,
          perChar: vK
        } = this.heightMetrics(KO, XO);
        if (KO.lineWrapping) {
          let bK = XO + (OO < KO.lineHeight ? 0 : Math.round(Math.max(0, Math.min(1, (OO - pO) / this.height)) * this.length)),
            eO = KO.doc.lineAt(bK),
            CO = lO + eO.length * vK,
            hO = Math.max(pO, OO - CO / 2);
          return new RX(eO.from, eO.length, hO, CO, 0)
        } {
          let XO = Math.max(0, Math.min(eO - bK, Math.floor((OO - pO) / lO))),
            {
              from: vK,
              length: CO
            } = KO.doc.line(bK + XO);
          return new RX(vK, CO, pO + lO * XO, lO, 0)
        }
      }
      lineAt(OO, KO, pO, XO, bK) {
        if (KO == SX.ByHeight) return this.blockAt(OO, pO, XO, bK);
        if (KO == SX.ByPosNoHeight) {
          let {
            from: KO,
            to: XO
          } = pO.doc.lineAt(OO);
          return new RX(KO, XO - KO, 0, 0, 0)
        }
        let {
          firstLine: eO,
          perLine: lO,
          perChar: vK
        } = this.heightMetrics(pO, bK), CO = pO.doc.lineAt(OO), hO = lO + CO.length * vK, DO = CO.number - eO, MO = XO + lO * DO + vK * (CO.from - bK - DO);
        return new RX(CO.from, CO.length, Math.max(XO, Math.min(MO, XO + this.height - hO)), hO, 0)
      }
      forEachLine(OO, KO, pO, XO, bK, eO) {
        OO = Math.max(OO, bK), KO = Math.min(KO, bK + this.length);
        let {
          firstLine: lO,
          perLine: vK,
          perChar: CO
        } = this.heightMetrics(pO, bK);
        for (let hO = OO, DO = XO; hO <= KO;) {
          let KO = pO.doc.lineAt(hO);
          if (hO == OO) {
            let pO = KO.number - lO;
            DO += vK * pO + CO * (OO - bK - pO)
          }
          let XO = vK + CO * KO.length;
          eO(new RX(KO.from, KO.length, DO, XO, 0)), DO += XO, hO = KO.to + 1
        }
      }
      replace(OO, KO, pO) {
        let XO = this.length - KO;
        if (XO > 0) {
          let OO = pO[pO.length - 1];
          OO instanceof xb ? pO[pO.length - 1] = new xb(OO.length + XO) : pO.push(null, new xb(XO - 1))
        }
        if (OO > 0) {
          let KO = pO[0];
          KO instanceof xb ? pO[0] = new xb(OO + KO.length) : pO.unshift(new xb(OO - 1), null)
        }
        return cb.of(pO)
      }
      decomposeLeft(OO, KO) {
        KO.push(new xb(OO - 1), null)
      }
      decomposeRight(OO, KO) {
        KO.push(null, new xb(this.length - OO - 1))
      }
      updateHeight(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 ? arguments[3] : void 0,
          bK = KO + this.length;
        if (XO && XO.from <= KO + this.length && XO.more) {
          let pO = [],
            eO = Math.max(KO, XO.from),
            lO = -1;
          for (XO.from > KO && pO.push(new xb(XO.from - KO - 1).updateHeight(OO, KO)); eO <= bK && XO.more;) {
            let KO = OO.doc.lineAt(eO).length;
            pO.length && pO.push(null);
            let bK = XO.heights[XO.index++],
              vK = 0;
            bK < 0 && (vK = -bK, bK = XO.heights[XO.index++]), -1 == lO ? lO = bK : Math.abs(bK - lO) >= JX && (lO = -2);
            let CO = new qb(KO, bK, vK);
            CO.outdated = !1, pO.push(CO), eO += KO + 1
          }
          eO <= bK && pO.push(null, new xb(bK - eO).updateHeight(OO, eO));
          let vK = cb.of(pO);
          return (lO < 0 || Math.abs(vK.height - this.height) >= JX || Math.abs(lO - this.heightMetrics(OO, KO).perLine) >= JX) && (PX = !0), BX(this, vK)
        }
        return (pO || this.outdated) && (this.setHeight(OO.heightForGap(KO, KO + this.length)), this.outdated = !1), this
      }
      toString() {
        return `gap(${this.length})`
      }
    }
    class nX extends cb {
      constructor(OO, KO, pO) {
        super(OO.length + KO + pO.length, OO.height + pO.height, KO | (OO.outdated || pO.outdated ? 2 : 0)), this.left = OO, this.right = pO, this.size = OO.size + pO.size
      }
      get break() {
        return 1 & this.flags
      }
      blockAt(OO, KO, pO, XO) {
        let bK = pO + this.left.height;
        return OO < bK ? this.left.blockAt(OO, KO, pO, XO) : this.right.blockAt(OO, KO, bK, XO + this.left.length + this.break)
      }
      lineAt(OO, KO, pO, XO, bK) {
        let eO = XO + this.left.height,
          lO = bK + this.left.length + this.break,
          vK = KO == SX.ByHeight ? OO < eO : OO < lO,
          CO = vK ? this.left.lineAt(OO, KO, pO, XO, bK) : this.right.lineAt(OO, KO, pO, eO, lO);
        if (this.break || (vK ? CO.to < lO : CO.from > lO)) return CO;
        let hO = KO == SX.ByPosNoHeight ? SX.ByPosNoHeight : SX.ByPos;
        return vK ? CO.join(this.right.lineAt(lO, hO, pO, eO, lO)) : this.left.lineAt(lO, hO, pO, XO, bK).join(CO)
      }
      forEachLine(OO, KO, pO, XO, bK, eO) {
        let lO = XO + this.left.height,
          vK = bK + this.left.length + this.break;
        if (this.break) OO < vK && this.left.forEachLine(OO, KO, pO, XO, bK, eO), KO >= vK && this.right.forEachLine(OO, KO, pO, lO, vK, eO);
        else {
          let CO = this.lineAt(vK, SX.ByPos, pO, XO, bK);
          OO < CO.from && this.left.forEachLine(OO, CO.from - 1, pO, XO, bK, eO), CO.to >= OO && CO.from <= KO && eO(CO), KO > CO.to && this.right.forEachLine(CO.to + 1, KO, pO, lO, vK, eO)
        }
      }
      replace(OO, KO, pO) {
        let XO = this.left.length + this.break;
        if (KO < XO) return this.balanced(this.left.replace(OO, KO, pO), this.right);
        if (OO > this.left.length) return this.balanced(this.left, this.right.replace(OO - XO, KO - XO, pO));
        let bK = [];
        OO > 0 && this.decomposeLeft(OO, bK);
        let eO = bK.length;
        for (let lO of pO) bK.push(lO);
        if (OO > 0 && WX(bK, eO - 1), KO < this.length) {
          let OO = bK.length;
          this.decomposeRight(KO, bK), WX(bK, OO)
        }
        return cb.of(bK)
      }
      decomposeLeft(OO, KO) {
        let pO = this.left.length;
        if (OO <= pO) return this.left.decomposeLeft(OO, KO);
        KO.push(this.left), this.break && (pO++, OO >= pO && KO.push(null)), OO > pO && this.right.decomposeLeft(OO - pO, KO)
      }
      decomposeRight(OO, KO) {
        let pO = this.left.length,
          XO = pO + this.break;
        if (OO >= XO) return this.right.decomposeRight(OO - XO, KO);
        OO < pO && this.left.decomposeRight(OO, KO), this.break && OO < XO && KO.push(null), KO.push(this.right)
      }
      balanced(OO, KO) {
        return OO.size > 2 * KO.size || KO.size > 2 * OO.size ? cb.of(this.break ? [OO, null, KO] : [OO, KO]) : (this.left = BX(this.left, OO), this.right = BX(this.right, KO), this.setHeight(OO.height + KO.height), this.outdated = OO.outdated || KO.outdated, this.size = OO.size + KO.size, this.length = OO.length + this.break+KO.length, this)
      }
      updateHeight(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 ? arguments[3] : void 0,
          {
            left: bK,
            right: eO
          } = this,
          lO = KO + bK.length + this.break,
          vK = null;
        return XO && XO.from <= KO + bK.length && XO.more ? vK = bK = bK.updateHeight(OO, KO, pO, XO) : bK.updateHeight(OO, KO, pO), XO && XO.from <= lO + eO.length && XO.more ? vK = eO = eO.updateHeight(OO, lO, pO, XO) : eO.updateHeight(OO, lO, pO), vK ? this.balanced(bK, eO) : (this.height = this.left.height + this.right.height, this.outdated = !1, this)
      }
      toString() {
        return this.left + (this.break ? " " : "-") + this.right
      }
    }

    function WX(OO, KO) {
      let pO, XO;
      null == OO[KO] && (pO = OO[KO - 1]) instanceof xb && (XO = OO[KO + 1]) instanceof xb && OO.splice(KO - 1, 3, new xb(pO.length + 1 + XO.length))
    }
    class tb {
      constructor(OO, KO) {
        this.pos = OO, this.oracle = KO, this.nodes = [], this.lineStart = -1, this.lineEnd = -1, this.covering = null, this.writtenTo = OO
      }
      get isCovered() {
        return this.covering && this.nodes[this.nodes.length - 1] == this.covering
      }
      span(OO, KO) {
        if (this.lineStart > -1) {
          let OO = Math.min(KO, this.lineEnd),
            pO = this.nodes[this.nodes.length - 1];
          pO instanceof qb ? pO.length += OO - this.pos : (OO > this.pos || !this.isCovered) && this.nodes.push(new qb(OO - this.pos, -1, 0)), this.writtenTo = OO, KO > OO && (this.nodes.push(null), this.writtenTo++, this.lineStart = -1)
        }
        this.pos = KO
      }
      point(OO, KO, pO) {
        if (OO < KO || pO.heightRelevant) {
          let XO = pO.widget ? pO.widget.estimatedHeight : 0,
            bK = pO.widget ? pO.widget.lineBreaks : 0;
          XO < 0 && (XO = this.oracle.lineHeight);
          let eO = KO - OO;
          pO.block ? this.pCO(new GX(eO, XO, pO)) : (eO || bK || XO >= 5) && this.addLineDeco(XO, bK, eO)
        } else KO > OO && this.span(OO, KO);
        this.lineEnd > -1 && this.lineEnd < this.pos && (this.lineEnd = this.oracle.doc.lineAt(this.pos).to)
      }
      enterLine() {
        if (this.lineStart > -1) return;
        let {
          from: OO,
          to: KO
        } = this.oracle.doc.lineAt(this.pos);
        this.lineStart = OO, this.lineEnd = KO, this.writtenTo < OO && ((this.writtenTo < OO - 1 || null == this.nodes[this.nodes.length - 1]) && this.nodes.push(this.blankContent(this.writtenTo, OO - 1)), this.nodes.push(null)), this.pos > OO && this.nodes.push(new qb(this.pos - OO, -1, 0)), this.writtenTo = this.pos
      }
      blankContent(OO, KO) {
        let pO = new xb(KO - OO);
        return this.oracle.doc.lineAt(OO).to == KO && (pO.flags |= 4), pO
      }
      ensureLine() {
        this.enterLine();
        let OO = this.nodes.length ? this.nodes[this.nodes.length - 1] : null;
        if (OO instanceof qb) return OO;
        let KO = new qb(0, -1, 0);
        return this.nodes.push(KO), KO
      }
      pCO(OO) {
        this.enterLine();
        let KO = OO.deco;
        KO && KO.startSide > 0 && !this.isCovered && this.ensureLine(), this.nodes.push(OO), this.writtenTo = this.pos = this.pos + OO.length, KO && KO.endSide > 0 && (this.covering = OO)
      }
      addLineDeco(OO, KO, pO) {
        let XO = this.ensureLine();
        XO.length += pO, XO.collapsed += pO, XO.widgetHeight = Math.max(XO.widgetHeight, OO), XO.breaks += KO, this.writtenTo = this.pos = this.pos + pO
      }
      finish(OO) {
        let KO = 0 == this.nodes.length ? null : this.nodes[this.nodes.length - 1];
        !(this.lineStart > -1) || KO instanceof qb || this.isCovered ? (this.writtenTo < this.pos || null == KO) && this.nodes.push(this.blankContent(this.writtenTo, this.pos)) : this.nodes.push(new qb(0, -1, 0));
        let pO = OO;
        for (let XO of this.nodes) XO instanceof qb && XO.updateHeight(this.oracle, pO), pO += XO ? XO.length : 1;
        return this.nodes
      }
      static build(OO, KO, pO, bK) {
        let eO = new tb(pO, OO);
        return XO.y.spans(KO, pO, bK, eO, 0), eO.finish(pO)
      }
    }
    class kb {
      constructor() {
        this.changes = []
      }
      compareRange() {}
      comparePoint(OO, KO, pO, XO) {
        (OO < KO || pO && pO.heightRelevant || XO && XO.heightRelevant) && sO(OO, KO, this.changes, 5)
      }
    }

    function UX(OO, KO) {
      let pO = OO.getBoundingClientRect(),
        XO = OO.ownerDocument,
        bK = XO.defaultView || window,
        eO = Math.max(0, pO.left),
        lO = Math.min(bK.innerWidth, pO.right),
        vK = Math.max(0, pO.top),
        CO = Math.min(bK.innerHeight, pO.bottom);
      for (let hO = OO.parentNode; hO && hO != XO.body;)
        if (1 == hO.nodeType) {
          let KO = hO,
            pO = window.getComputedStyle(KO);
          if ((KO.scrollHeight > KO.clientHeight || KO.scrollWidth > KO.clientWidth) && "visible" != pO.overflow) {
            let pO = KO.getBoundingClientRect();
            eO = Math.max(eO, pO.left), lO = Math.min(lO, pO.right), vK = Math.max(vK, pO.top), CO = Math.min(hO == OO.parentNode ? bK.innerHeight : CO, pO.bottom)
          }
          hO = "absolute" == pO.position || "fixed" == pO.position ? KO.offsetParent : KO.parentNode
        } else {
          if (11 != hO.nodeType) break;
          hO = hO.host
        } return {
        left: eO - pO.left,
        right: Math.max(eO, lO) - pO.left,
        top: vK - (pO.top + KO),
        bottom: Math.max(vK, CO) - (pO.top + KO)
      }
    }

    function Ob(OO, KO) {
      let pO = OO.getBoundingClientRect();
      return {
        left: 0,
        right: pO.right - pO.left,
        top: KO,
        bottom: pO.bottom - (pO.top + KO)
      }
    }
    class Kb {
      constructor(OO, KO, pO, XO) {
        this.from = OO, this.to = KO, this.size = pO, this.displaySize = XO
      }
      static same(OO, KO) {
        if (OO.length != KO.length) return !1;
        for (let pO = 0; pO < OO.length; pO++) {
          let XO = OO[pO],
            bK = KO[pO];
          if (XO.from != bK.from || XO.to != bK.to || XO.size != bK.size) return !1
        }
        return !0
      }
      draw(OO, KO) {
        return wO.replace({
          widget: new pb(this.displaySize * (KO ? OO.scaleY : OO.scaleX), KO)
        }).range(this.from, this.to)
      }
    }
    class pb extends jK {
      constructor(OO, KO) {
        super(), this.size = OO, this.vertical = KO
      }
      eq(OO) {
        return OO.size == this.size && OO.vertical == this.vertical
      }
      toDOM() {
        let OO = document.createElement("div");
        return this.vertical ? OO.style.height = this.size + "px" : (OO.style.width = this.size + "px", OO.style.height = "2px", OO.style.display = "inline-block"), OO
      }
      get estimatedHeight() {
        return this.vertical ? this.size : -1
      }
    }
    class Xb {
      constructor(OO, KO) {
        this.view = OO, this.state = KO, this.pixelViewport = {
          left: 0,
          right: window.innerWidth,
          top: 0,
          bottom: 0
        }, this.inView = !0, this.paddingTop = 0, this.paddingBottom = 0, this.contentDOMWidth = 0, this.contentDOMHeight = 0, this.editorHeight = 0, this.editorWidth = 0, this.scaleX = 1, this.scaleY = 1, this.scrollOffset = 0, this.scrolledToBottom = !1, this.scrollAnchorPos = 0, this.scrollAnchorHeight = -1, this.scaler = ve, this.scrollTarget = null, this.printing = !1, this.mustMeasureContent = !0, this.defaultTextDirection = hK.LTR, this.yvO = [], this.mustEnforceCursorAssoc = !1;
        let pO = KO.facet(UK).some((OO => "function" != typeof OO && "cm-lineWrapping" == OO.class));
        this.heightOracle = new sX(pO), this.stateDeco = Cb(KO), this.heightMap = cb.empty().applyChanges(this.stateDeco, XO.I.empty, this.heightOracle.setDoc(KO.doc), [new hp(0, 0, 0, KO.doc.length)]);
        for (let XO = 0; XO < 2 && (this.viewport = this.getViewport(0, null), this.updateForViewport()); XO++);
        this.updateViewportLines(), this.lineGaps = this.ensureLineGaps([]), this.lineGapDeco = wO.set(this.lineGaps.map((OO => OO.draw(this, !1)))), this.scrollParent = OO.scrollDOM, this.computeVisibleRanges()
      }
      updateForViewport() {
        let OO = [this.viewport],
          {
            main: KO
          } = this.state.selection;
        for (let pO = 0; pO <= 1; pO++) {
          let XO = pO ? KO.head : KO.anchor;
          if (!OO.some((OO => {
              let {
                from: KO,
                to: pO
              } = OO;
              return XO >= KO && XO <= pO
            }))) {
            let {
              from: KO,
              to: pO
            } = this.lineBlockAt(XO);
            OO.push(new be(KO, pO))
          }
        }
        return this.viewports = OO.sort(((OO, KO) => OO.from - KO.from)), this.updateScaler()
      }
      updateScaler() {
        let OO = this.scaler;
        return this.scaler = this.heightMap.height <= 7e6 ? ve : new hb(this.heightOracle, this.heightMap, this.viewports), OO.eq(this.scaler) ? 0 : 2
      }
      updateViewportLines() {
        this.viewportLines = [], this.heightMap.forEachLine(this.viewport.from, this.viewport.to, this.heightOracle.setDoc(this.state.doc), 0, 0, (OO => {
          this.viewportLines.push(Db(OO, this.scaler))
        }))
      }
      update(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        this.state = OO.state;
        let pO = this.stateDeco;
        this.stateDeco = Cb(this.state);
        let bK = OO.changedRanges,
          eO = hp.extendWithRanges(bK, function(OO, KO, pO) {
            let bK = new kb;
            return XO.y.compare(OO, KO, pO, bK, 0), bK.changes
          }(pO, this.stateDeco, OO ? OO.changes : XO.ChangeSet.empty(this.state.doc.length))),
          lO = this.heightMap.height,
          vK = this.scrolledToBottom ? null : this.scrollAnchorAt(this.scrollOffset);
        mb(), this.heightMap = this.heightMap.applyChanges(this.stateDeco, OO.startState.doc, this.heightOracle.setDoc(this.state.doc), eO), (this.heightMap.height != lO || PX) && (OO.flags |= 2), vK ? (this.scrollAnchorPos = OO.changes.mapPos(vK.from, -1), this.scrollAnchorHeight = vK.top) : (this.scrollAnchorPos = -1, this.scrollAnchorHeight = lO);
        let CO = eO.length ? this.mapViewport(this.viewport, OO.changes) : this.viewport;
        (KO && (KO.range.head < CO.from || KO.range.head > CO.to) || !this.viewportIsAppropriate(CO)) && (CO = this.getViewport(0, KO));
        let hO = CO.from != this.viewport.from || CO.to != this.viewport.to;
        this.viewport = CO, OO.flags |= this.updateForViewport(), (hO || !OO.changes.empty || 2 & OO.flags) && this.updateViewportLines(), (this.lineGaps.length || this.viewport.to - this.viewport.from > 4e3) && this.updateLineGaps(this.ensureLineGaps(this.mapLineGaps(this.lineGaps, OO.changes))), OO.flags |= this.computeVisibleRanges(OO.changes), KO && (this.scrollTarget = KO), !this.mustEnforceCursorAssoc && (OO.selectionSet || OO.focusChanged) && OO.view.lineWrapping && OO.state.selection.main.empty && OO.state.selection.main.assoc && !OO.state.facet(SK) && (this.mustEnforceCursorAssoc = !0)
      }
      measure() {
        let {
          view: OO
        } = this, KO = OO.contentDOM, pO = window.getComputedStyle(KO), bK = this.heightOracle, eO = pO.whiteSpace;
        this.defaultTextDirection = "rtl" == pO.direction ? hK.RTL : hK.LTR;
        let lO = this.heightOracle.mustRefreshForWrapping(eO) || "refresh" === this.mustMeasureContent,
          vK = KO.getBoundingClientRect(),
          CO = lO || this.mustMeasureContent || this.contentDOMHeight != vK.height;
        this.contentDOMHeight = vK.height, this.mustMeasureContent = !1;
        let hO = 0,
          DO = 0;
        if (vK.width && vK.height) {
          let {
            scaleX: OO,
            scaleY: pO
          } = tK(KO, vK);
          (OO > .005 && Math.abs(this.scaleX - OO) > .005 || pO > .005 && Math.abs(this.scaleY - pO) > .005) && (this.scaleX = OO, this.scaleY = pO, hO |= 16, lO = CO = !0)
        }
        let MO = (parseInt(pO.paddingTop) || 0) * this.scaleY,
          aK = (parseInt(pO.paddingBottom) || 0) * this.scaleY;
        this.paddingTop == MO && this.paddingBottom == aK || (this.paddingTop = MO, this.paddingBottom = aK, hO |= 18), this.editorWidth != OO.scrollDOM.clientWidth && (bK.lineWrapping && (CO = !0), this.editorWidth = OO.scrollDOM.clientWidth, hO |= 16);
        let oO = kK(this.view.contentDOM, !1).y;
        oO != this.scrollParent && (this.scrollParent = oO, this.scrollAnchorHeight = -1, this.scrollOffset = 0);
        let FO = this.getScrollOffset();
        this.scrollOffset != FO && (this.scrollAnchorHeight = -1, this.scrollOffset = FO), this.scrolledToBottom = eK(this.scrollParent || OO.win);
        let VO = (this.printing ? Ob : UX)(KO, this.paddingTop),
          LO = VO.top - this.pixelViewport.top,
          QO = VO.bottom - this.pixelViewport.bottom;
        this.pixelViewport = VO;
        let zK = this.pixelViewport.bottom > this.pixelViewport.top && this.pixelViewport.right > this.pixelViewport.left;
        if (zK != this.inView && (this.inView = zK, zK && (CO = !0)), !this.inView && !this.scrollTarget && ! function(OO) {
            let KO = OO.getBoundingClientRect(),
              pO = OO.ownerDocument.defaultView || window;
            return KO.left < pO.innerWidth && KO.right > 0 && KO.top < pO.innerHeight && KO.bottom > 0
          }(OO.dom)) return 0;
        let AO = vK.width;
        if (this.contentDOMWidth == AO && this.editorHeight == OO.scrollDOM.clientHeight || (this.contentDOMWidth = vK.width, this.editorHeight = OO.scrollDOM.clientHeight, hO |= 16), CO) {
          let KO = OO.docView.measureVisibleLineHeights(this.viewport);
          if (bK.mustRefreshForHeights(KO) && (lO = !0), lO || bK.lineWrapping && Math.abs(AO - this.contentDOMWidth) > bK.charWidth) {
            let {
              lineHeight: pO,
              charWidth: XO,
              textHeight: vK
            } = OO.docView.measureTextSize();
            lO = pO > 0 && bK.refresh(eO, pO, XO, vK, Math.max(5, AO / XO), KO), lO && (OO.docView.minWidth = 0, hO |= 16)
          }
          LO > 0 && QO > 0 ? DO = Math.max(LO, QO) : LO < 0 && QO < 0 && (DO = Math.min(LO, QO)), mb();
          for (let pO of this.viewports) {
            let eO = pO.from == this.viewport.from ? KO : OO.docView.measureVisibleLineHeights(pO);
            this.heightMap = (lO ? cb.empty().applyChanges(this.stateDeco, XO.I.empty, this.heightOracle, [new hp(0, 0, 0, OO.state.doc.length)]) : this.heightMap).updateHeight(bK, 0, lO, new HX(pO.from, eO))
          }
          PX && (hO |= 2)
        }
        let fO = !this.viewportIsAppropriate(this.viewport, DO) || this.scrollTarget && (this.scrollTarget.range.head < this.viewport.from || this.scrollTarget.range.head > this.viewport.to);
        return fO && (2 & hO && (hO |= this.updateScaler()), this.viewport = this.getViewport(DO, this.scrollTarget), hO |= this.updateForViewport()), (2 & hO || fO) && this.updateViewportLines(), (this.lineGaps.length || this.viewport.to - this.viewport.from > 4e3) && this.updateLineGaps(this.ensureLineGaps(lO ? [] : this.lineGaps, OO)), hO |= this.computeVisibleRanges(), this.mustEnforceCursorAssoc && (this.mustEnforceCursorAssoc = !1, OO.docView.enforceCursorAssoc()), hO
      }
      get visibleTop() {
        return this.scaler.fromDOM(this.pixelViewport.top)
      }
      get visibleBottom() {
        return this.scaler.fromDOM(this.pixelViewport.bottom)
      }
      getViewport(OO, KO) {
        let pO = .5 - Math.max(-.5, Math.min(.5, OO / 1e3 / 2)),
          XO = this.heightMap,
          bK = this.heightOracle,
          {
            visibleTop: eO,
            visibleBottom: lO
          } = this,
          vK = new be(XO.lineAt(eO - 1e3 * pO, SX.ByHeight, bK, 0, 0).from, XO.lineAt(lO + 1e3 * (1 - pO), SX.ByHeight, bK, 0, 0).to);
        if (KO) {
          let {
            head: OO
          } = KO.range;
          if (OO < vK.from || OO > vK.to) {
            let pO, eO = Math.min(this.editorHeight, this.pixelViewport.bottom - this.pixelViewport.top),
              lO = XO.lineAt(OO, SX.ByPos, bK, 0, 0);
            pO = "center" == KO.y ? (lO.top + lO.bottom) / 2 - eO / 2 : "start" == KO.y || "nearest" == KO.y && OO < vK.from ? lO.top : lO.bottom - eO, vK = new be(XO.lineAt(pO - 500, SX.ByHeight, bK, 0, 0).from, XO.lineAt(pO + eO + 500, SX.ByHeight, bK, 0, 0).to)
          }
        }
        return vK
      }
      mapViewport(OO, KO) {
        let pO = KO.mapPos(OO.from, -1),
          XO = KO.mapPos(OO.to, 1);
        return new be(this.heightMap.lineAt(pO, SX.ByPos, this.heightOracle, 0, 0).from, this.heightMap.lineAt(XO, SX.ByPos, this.heightOracle, 0, 0).to)
      }
      viewportIsAppropriate(OO) {
        let {
          from: KO,
          to: pO
        } = OO, XO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        if (!this.inView) return !0;
        let {
          top: bK
        } = this.heightMap.lineAt(KO, SX.ByPos, this.heightOracle, 0, 0), {
          bottom: eO
        } = this.heightMap.lineAt(pO, SX.ByPos, this.heightOracle, 0, 0), {
          visibleTop: lO,
          visibleBottom: vK
        } = this;
        return (0 == KO || bK <= lO - Math.max(10, Math.min(-XO, 250))) && (pO == this.state.doc.length || eO >= vK + Math.max(10, Math.min(XO, 250))) && bK > lO - 2e3 && eO < vK + 2e3
      }
      mapLineGaps(OO, KO) {
        if (!OO.length || KO.empty) return OO;
        let pO = [];
        for (let XO of OO) KO.touchesRange(XO.from, XO.to) || pO.push(new Kb(KO.mapPos(XO.from), KO.mapPos(XO.to), XO.size, XO.displaySize));
        return pO
      }
      ensureLineGaps(OO, KO) {
        let pO = this.heightOracle.lineWrapping,
          bK = pO ? 1e4 : 2e3,
          eO = bK >> 1,
          lO = bK << 1;
        if (this.defaultTextDirection != hK.LTR && !pO) return [];
        let vK = [],
          CO = (bK, lO, hO, DO) => {
            if (lO - bK < eO) return;
            let MO = this.state.selection.main,
              aK = [MO.from];
            MO.empty || aK.push(MO.to);
            for (let OO of aK)
              if (OO > bK && OO < lO) return CO(bK, OO - 10, hO, DO), void CO(OO + 10, lO, hO, DO);
            let oO = function(OO, KO) {
              for (let pO of OO)
                if (KO(pO)) return pO;
              return
            }(OO, (OO => OO.from >= hO.from && OO.to <= hO.to && Math.abs(OO.from - bK) < eO && Math.abs(OO.to - lO) < eO && !aK.some((KO => OO.from < KO && OO.to > KO))));
            if (!oO) {
              if (lO < hO.to && KO && pO && KO.yvO.some((OO => OO.from <= lO && OO.to >= lO))) {
                let OO = KO.moveToLineBoundary(XO.j.cursor(lO), !1, !0).head;
                OO > bK && (lO = OO)
              }
              let OO = this.gapSize(hO, bK, lO, DO);
              oO = new Kb(bK, lO, OO, pO || OO < 2e6 ? OO : 2e6)
            }
            vK.push(oO)
          },
          hO = KO => {
            if (KO.length < lO || KO.type != YO.Text) return;
            let eO = function(OO, KO, pO) {
              let bK = [],
                eO = OO,
                lO = 0;
              XO.y.spans(pO, OO, KO, {
                span() {},
                point(OO, KO) {
                  OO > eO && (bK.push({
                    from: eO,
                    to: OO
                  }), lO += OO - eO), eO = KO
                }
              }, 20), eO < KO && (bK.push({
                from: eO,
                to: KO
              }), lO += KO - eO);
              return {
                total: lO,
                Xl: bK
              }
            }(KO.from, KO.to, this.stateDeco);
            if (eO.total < lO) return;
            let vK, hO, DO = this.scrollTarget ? this.scrollTarget.range.head : null;
            if (pO) {
              let OO, pO, XO = bK / this.heightOracle.lineLength * this.heightOracle.lineHeight;
              if (null != DO) {
                let bK = lb(eO, DO),
                  lO = ((this.visibleBottom - this.visibleTop) / 2 + XO) / KO.height;
                OO = bK - lO, pO = bK + lO
              } else OO = (this.visibleTop - KO.top - XO) / KO.height, pO = (this.visibleBottom - KO.top + XO) / KO.height;
              vK = eb(eO, OO), hO = eb(eO, pO)
            } else {
              let pO = eO.total * this.heightOracle.charWidth,
                XO = bK * this.heightOracle.charWidth,
                lO = 0;
              if (pO > 2e6)
                for (let bK of OO) bK.from >= KO.from && bK.from < KO.to && bK.size != bK.displaySize && bK.from * this.heightOracle.charWidth + lO < this.pixelViewport.left && (lO = bK.size - bK.displaySize);
              let CO, MO, aK = this.pixelViewport.left + lO,
                oO = this.pixelViewport.right + lO;
              if (null != DO) {
                let OO = lb(eO, DO),
                  KO = ((oO - aK) / 2 + XO) / pO;
                CO = OO - KO, MO = OO + KO
              } else CO = (aK - XO) / pO, MO = (oO + XO) / pO;
              vK = eb(eO, CO), hO = eb(eO, MO)
            }
            vK > KO.from && CO(KO.from, vK, KO, eO), hO < KO.to && CO(hO, KO.to, KO, eO)
          };
        for (let XO of this.viewportLines) Array.isArray(XO.type) ? XO.type.forEach(hO) : hO(XO);
        return vK
      }
      gapSize(OO, KO, pO, XO) {
        let bK = lb(XO, pO) - lb(XO, KO);
        return this.heightOracle.lineWrapping ? OO.height * bK : XO.total * this.heightOracle.charWidth * bK
      }
      updateLineGaps(OO) {
        Kb.same(OO, this.lineGaps) || (this.lineGaps = OO, this.lineGapDeco = wO.set(OO.map((OO => OO.draw(this, this.heightOracle.lineWrapping)))))
      }
      computeVisibleRanges(OO) {
        let KO = this.stateDeco;
        this.lineGaps.length && (KO = KO.concat(this.lineGapDeco));
        let pO = [];
        XO.y.spans(KO, this.viewport.from, this.viewport.to, {
          span(OO, KO) {
            pO.push({
              from: OO,
              to: KO
            })
          },
          point() {}
        }, 20);
        let bK = 0;
        if (pO.length != this.yvO.length) bK = 12;
        else
          for (let XO = 0; XO < pO.length && !(8 & bK); XO++) {
            let KO = this.yvO[XO],
              eO = pO[XO];
            KO.from == eO.from && KO.to == eO.to || (bK |= 4, OO && OO.mapPos(KO.from, -1) == eO.from && OO.mapPos(KO.to, 1) == eO.to || (bK |= 8))
          }
        return this.yvO = pO, bK
      }
      lineBlockAt(OO) {
        return OO >= this.viewport.from && OO <= this.viewport.to && this.viewportLines.find((KO => KO.from <= OO && KO.to >= OO)) || Db(this.heightMap.lineAt(OO, SX.ByPos, this.heightOracle, 0, 0), this.scaler)
      }
      lineBlockAtHeight(OO) {
        return OO >= this.viewportLines[0].top && OO <= this.viewportLines[this.viewportLines.length - 1].bottom && this.viewportLines.find((KO => KO.top <= OO && KO.bottom >= OO)) || Db(this.heightMap.lineAt(this.scaler.fromDOM(OO), SX.ByHeight, this.heightOracle, 0, 0), this.scaler)
      }
      getScrollOffset() {
        return (this.scrollParent == this.view.scrollDOM ? this.scrollParent.scrollTop : (this.scrollParent ? this.scrollParent.getBoundingClientRect().top : 0) - this.view.contentDOM.getBoundingClientRect().top) * this.scaleY
      }
      scrollAnchorAt(OO) {
        let KO = this.lineBlockAtHeight(OO + 8);
        return KO.from >= this.viewport.from || this.viewportLines[0].top - OO > 200 ? KO : this.viewportLines[0]
      }
      elementAtHeight(OO) {
        return Db(this.heightMap.blockAt(this.scaler.fromDOM(OO), this.heightOracle, 0, 0), this.scaler)
      }
      get docHeight() {
        return this.scaler.toDOM(this.heightMap.height)
      }
      get contentHeight() {
        return this.docHeight + this.paddingTop + this.paddingBottom
      }
    }
    class be {
      constructor(OO, KO) {
        this.from = OO, this.to = KO
      }
    }

    function eb(OO, KO) {
      let {
        total: pO,
        Xl: XO
      } = OO;
      if (KO <= 0) return XO[0].from;
      if (KO >= 1) return XO[XO.length - 1].to;
      let bK = Math.floor(pO * KO);
      for (let eO = 0;; eO++) {
        let {
          from: OO,
          to: KO
        } = XO[eO], pO = KO - OO;
        if (bK <= pO) return OO + bK;
        bK -= pO
      }
    }

    function lb(OO, KO) {
      let pO = 0;
      for (let {
          from: XO,
          to: bK
        }
        of OO.Xl) {
        if (KO <= bK) {
          pO += KO - XO;
          break
        }
        pO += bK - XO
      }
      return pO / OO.total
    }
    const ve = {
      toDOM: OO => OO,
      fromDOM: OO => OO,
      scale: 1,
      eq(OO) {
        return OO == this
      }
    };

    function Cb(OO) {
      let KO = OO.facet(Op).filter((OO => "function" != typeof OO)),
        pO = OO.facet(pp).filter((OO => "function" != typeof OO));
      return pO.length && KO.push(XO.y.join(pO)), KO
    }
    class hb {
      constructor(OO, KO, pO) {
        let XO = 0,
          bK = 0,
          eO = 0;
        this.viewports = pO.map((pO => {
          let {
            from: bK,
            to: eO
          } = pO, lO = KO.lineAt(bK, SX.ByPos, OO, 0, 0).top, vK = KO.lineAt(eO, SX.ByPos, OO, 0, 0).bottom;
          return XO += vK - lO, {
            from: bK,
            to: eO,
            top: lO,
            bottom: vK,
            domTop: 0,
            domBottom: 0
          }
        })), this.scale = (7e6 - XO) / (KO.height - XO);
        for (let lO of this.viewports) lO.domTop = eO + (lO.top - bK) * this.scale, eO = lO.domBottom = lO.domTop + (lO.bottom - lO.top), bK = lO.bottom
      }
      toDOM(OO) {
        for (let KO = 0, pO = 0, XO = 0;; KO++) {
          let bK = KO < this.viewports.length ? this.viewports[KO] : null;
          if (!bK || OO < bK.top) return XO + (OO - pO) * this.scale;
          if (OO <= bK.bottom) return bK.domTop + (OO - bK.top);
          pO = bK.bottom, XO = bK.domBottom
        }
      }
      fromDOM(OO) {
        for (let KO = 0, pO = 0, XO = 0;; KO++) {
          let bK = KO < this.viewports.length ? this.viewports[KO] : null;
          if (!bK || OO < bK.domTop) return pO + (OO - XO) / this.scale;
          if (OO <= bK.domBottom) return bK.top + (OO - bK.domTop);
          pO = bK.bottom, XO = bK.domBottom
        }
      }
      eq(OO) {
        return OO instanceof hb && (this.scale == OO.scale && this.viewports.length == OO.viewports.length && this.viewports.every(((KO, pO) => KO.from == OO.viewports[pO].from && KO.to == OO.viewports[pO].to)))
      }
    }

    function Db(OO, KO) {
      if (1 == KO.scale) return OO;
      let pO = KO.toDOM(OO.top),
        XO = KO.toDOM(OO.bottom);
      return new RX(OO.from, OO.length, pO, XO - pO, Array.isArray(OO._content) ? OO._content.map((OO => Db(OO, KO))) : OO._content)
    }
    const Mb = XO.n.define({
        combine: OO => OO.join(" ")
      }),
      ae = XO.n.define({
        combine: OO => OO.indexOf(!0) > -1
      }),
      ob = bK.e.newName(),
      Fb = bK.e.newName(),
      Vb = bK.e.newName(),
      Lb = {
        "&light": "." + Fb,
        "&dark": "." + Vb
      };

    function Qb(OO, KO, pO) {
      return new bK.e(KO, {
        finish: KO => /&/.test(KO) ? KO.replace(/&\w*/, (KO => {
          if ("&" == KO) return OO;
          if (!pO || !pO[KO]) throw new RangeError(`Unsupported selector: ${KO}`);
          return pO[KO]
        })) : OO + " " + KO
      })
    }
    const ze = Qb("." + ob, {
        "&": {
          position: "relative !important",
          boxSizing: "border-box",
          "&.cm-focused": {
            outline: "1px dotted #212121"
          },
          display: "flex !important",
          flexDirection: "column"
        },
        ".cm-scroller": {
          display: "flex !important",
          alignItems: "flex-start !important",
          fontFamily: "monospace",
          lineHeight: 1.4,
          height: "100%",
          overflowX: "auto",
          position: "relative",
          zIndex: 0,
          overflowAnchor: "none"
        },
        ".cm-content": {
          margin: 0,
          flexGrow: 2,
          flexShrink: 0,
          display: "block",
          whiteSpace: "pre",
          wordWrap: "normal",
          boxSizing: "border-box",
          minHeight: "100%",
          padding: "4px 0",
          outline: "none",
          "&[contenteditable=true]": {
            WebkitUserModify: "read-write-plaintext-only"
          }
        },
        ".cm-lineWrapping": {
          whiteSpace_fallback: "pre-wrap",
          whiteSpace: "break-spaces",
          wordBreak: "break-word",
          overflowWrap: "anywhere",
          flexShrink: 1
        },
        "&light .cm-content": {
          caretColor: "black"
        },
        "&dark .cm-content": {
          caretColor: "white"
        },
        ".cm-line": {
          display: "block",
          padding: "0 2px 0 6px"
        },
        ".cm-layer": {
          position: "absolute",
          left: 0,
          top: 0,
          contain: "size style",
          "& > *": {
            position: "absolute"
          }
        },
        "&light .cm-selectionBackground": {
          background: "#d9d9d9"
        },
        "&dark .cm-selectionBackground": {
          background: "#222"
        },
        "&light.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground": {
          background: "#d7d4f0"
        },
        "&dark.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground": {
          background: "#233"
        },
        ".cm-cursorLayer": {
          pointerEvents: "none"
        },
        "&.cm-focused > .cm-scroller > .cm-cursorLayer": {
          animation: "steps(1) cm-blink 1.2s infinite"
        },
        "@keyframes cm-blink": {
          "0%": {},
          "50%": {
            opacity: 0
          },
          "100%": {}
        },
        "@keyframes cm-blink2": {
          "0%": {},
          "50%": {
            opacity: 0
          },
          "100%": {}
        },
        ".cm-cursor, .cm-dropCursor": {
          borderLeft: "1.2px solid black",
          marginLeft: "-0.6px",
          pointerEvents: "none"
        },
        ".cm-cursor": {
          display: "none"
        },
        "&dark .cm-cursor": {
          borderLeftColor: "#ddd"
        },
        ".cm-selectionHandle": {
          backgroundColor: "currentColor",
          width: "1.5px"
        },
        ".cm-selectionHandle-start::before, .cm-selectionHandle-end::before": {
          content: '""',
          backgroundColor: "inherit",
          borderRadius: "50%",
          width: "8px",
          height: "8px",
          position: "absolute",
          left: "-3.25px"
        },
        ".cm-selectionHandle-start::before": {
          top: "-8px"
        },
        ".cm-selectionHandle-end::before": {
          bottom: "-8px"
        },
        ".cm-dropCursor": {
          position: "absolute"
        },
        "&.cm-focused > .cm-scroller > .cm-cursorLayer .cm-cursor": {
          display: "block"
        },
        ".cm-iso": {
          unicodeBidi: "isolate"
        },
        ".cm-announced": {
          position: "fixed",
          top: "-10000px"
        },
        "@media print": {
          ".cm-announced": {
            display: "none"
          }
        },
        "&light .cm-activeLine": {
          backgroundColor: "#cceeff44"
        },
        "&dark .cm-activeLine": {
          backgroundColor: "#99eeff33"
        },
        "&light .cm-specialChar": {
          color: "red"
        },
        "&dark .cm-specialChar": {
          color: "#f78"
        },
        ".cm-gutters": {
          flexShrink: 0,
          display: "flex",
          height: "100%",
          boxSizing: "border-box",
          zIndex: 200
        },
        ".cm-gutters-before": {
          insetInlineStart: 0
        },
        ".cm-gutters-after": {
          insetInlineEnd: 0
        },
        "&light .cm-gutters": {
          backgroundColor: "#f5f5f5",
          color: "#6c6c6c",
          border: "0px solid #ddd",
          "&.cm-gutters-before": {
            borderRightWidth: "1px"
          },
          "&.cm-gutters-after": {
            borderLeftWidth: "1px"
          }
        },
        "&dark .cm-gutters": {
          backgroundColor: "#333338",
          color: "#ccc"
        },
        ".cm-gutter": {
          display: "flex !important",
          flexDirection: "column",
          flexShrink: 0,
          boxSizing: "border-box",
          minHeight: "100%",
          overflow: "hidden"
        },
        ".cm-gutterElement": {
          boxSizing: "border-box"
        },
        ".cm-lineNumbers .cm-gutterElement": {
          padding: "0 3px 0 5px",
          minWidth: "20px",
          textAlign: "right",
          whiteSpace: "nowrap"
        },
        "&light .cm-activeLineGutter": {
          backgroundColor: "#e2f2ff"
        },
        "&dark .cm-activeLineGutter": {
          backgroundColor: "#222227"
        },
        ".cm-panels": {
          boxSizing: "border-box",
          position: "sticky",
          left: 0,
          right: 0,
          zIndex: 300
        },
        "&light .cm-panels": {
          backgroundColor: "#f5f5f5",
          color: "black"
        },
        "&light .cm-panels-top": {
          borderBottom: "1px solid #ddd"
        },
        "&light .cm-panels-bottom": {
          borderTop: "1px solid #ddd"
        },
        "&dark .cm-panels": {
          backgroundColor: "#333338",
          color: "white"
        },
        ".cm-dialog": {
          padding: "2px 19px 4px 6px",
          position: "relative",
          "& label": {
            fontSize: "80%"
          }
        },
        ".cm-dialog-close": {
          position: "absolute",
          top: "3px",
          right: "4px",
          backgroundColor: "inherit",
          border: "none",
          font: "inherit",
          fontSize: "14px",
          padding: "0"
        },
        ".cm-tab": {
          display: "inline-block",
          overflow: "hidden",
          verticalAlign: "bottom"
        },
        ".cm-widgetBuffer": {
          verticalAlign: "text-top",
          height: "1em",
          width: 0,
          display: "inline"
        },
        ".cm-placeholder": {
          color: "#888",
          display: "inline-block",
          verticalAlign: "top",
          userSelect: "none"
        },
        ".cm-highlightSpace": {
          backgroundImage: "radial-gradient(circle at 50% 55%, #aaa 20%, transparent 5%)",
          backgroundPosition: "center"
        },
        ".cm-highlightTab": {
          backgroundImage: 'url(\'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="20"><path stroke="%23888" stroke-width="1" fill="none" d="M1 10H196L190 5M190 15L196 10M197 4L197 16"/></svg>\')',
          backgroundSize: "auto 100%",
          backgroundPosition: "right 90%",
          backgroundRepeat: "no-repeat"
        },
        ".cm-trailingSpace": {
          backgroundColor: "#ff332255"
        },
        ".cm-button": {
          verticalAlign: "middle",
          color: "inherit",
          fontSize: "70%",
          padding: ".2em 1em",
          borderRadius: "1px"
        },
        "&light .cm-button": {
          backgroundImage: "linear-gradient(#eff1f5, #d9d9df)",
          border: "1px solid #888",
          "&:active": {
            backgroundImage: "linear-gradient(#b4b4b4, #d0d3d6)"
          }
        },
        "&dark .cm-button": {
          backgroundImage: "linear-gradient(#393939, #111)",
          border: "1px solid #888",
          "&:active": {
            backgroundImage: "linear-gradient(#111, #333)"
          }
        },
        ".cm-textfield": {
          verticalAlign: "middle",
          color: "inherit",
          fontSize: "70%",
          border: "1px solid silver",
          padding: ".2em .5em"
        },
        "&light .cm-textfield": {
          backgroundColor: "white"
        },
        "&dark .cm-textfield": {
          border: "1px solid #555",
          backgroundColor: "inherit"
        }
      }, Lb),
      Ab = {
        childList: !0,
        characterData: !0,
        subtree: !0,
        attributes: !0,
        characterDataOldValue: !0
      },
      fb = NO.ie && NO.ie_version <= 11;
    class db {
      constructor(OO) {
        this.view = OO, this.active = !1, this.editContext = null, this.selectionRange = new UO, this.selectionChanged = !1, this.delayedFlush = -1, this.resizeTimeout = -1, this.queue = [], this.delayedAndroidKey = null, this.flushingAndroidKey = -1, this.lastChange = 0, this.scrollTargets = [], this.intersection = null, this.resizeScroll = null, this.intersecting = !1, this.gapIntersection = null, this.gaps = [], this.printQuery = null, this.parentCheck = -1, this.dom = OO.contentDOM, this.observer = new MutationObserver((KO => {
          for (let OO of KO) this.queue.push(OO);
          (NO.ie && NO.ie_version <= 11 || NO.ios && OO.composing) && KO.some((OO => "childList" == OO.type && OO.removedNodes.length || "characterData" == OO.type && OO.oldValue.length > OO.target.nodeValue.length)) ? this.flushSoon() : this.flush()
        })), !window.EditContext || !NO.android || !1 === OO.constructor.EDIT_CONTEXT || NO.chrome && NO.chrome_version < 126 || (this.editContext = new Ib(OO), OO.state.facet(qp) && (OO.contentDOM.editContext = this.editContext.editContext)), fb && (this.onCharData = OO => {
          this.queue.push({
            target: OO.target,
            type: "characterData",
            oldValue: OO.prevValue
          }), this.flushSoon()
        }), this.onSelectionChange = this.onSelectionChange.bind(this), this.tV = this.tV.bind(this), this.onPrint = this.onPrint.bind(this), this.onScroll = this.onScroll.bind(this), window.matchMedia && (this.printQuery = window.matchMedia("print")), "function" == typeof ResizeObserver && (this.resizeScroll = new ResizeObserver((() => {
          var OO;
          (null === (OO = this.view.docView) || void 0 === OO ? void 0 : OO.lastUpdate) < Date.now() - 75 && this.tV()
        })), this.resizeScroll.observe(OO.scrollDOM)), this.addWindowListeners(this.win = OO.win), this.start(), "function" == typeof IntersectionObserver && (this.intersection = new IntersectionObserver((OO => {
          this.parentCheck < 0 && (this.parentCheck = setTimeout(this.listenForScroll.bind(this), 1e3)), OO.length > 0 && OO[OO.length - 1].intersectionRatio > 0 != this.intersecting && (this.intersecting = !this.intersecting, this.intersecting != this.view.inView && this.onScrollChanged(document.createEvent("Event")))
        }), {
          threshold: [0, .001]
        }), this.intersection.observe(this.dom), this.gapIntersection = new IntersectionObserver((OO => {
          OO.length > 0 && OO[OO.length - 1].intersectionRatio > 0 && this.onScrollChanged(document.createEvent("Event"))
        }), {})), this.listenForScroll(), this.readSelectionRange()
      }
      onScrollChanged(OO) {
        this.view.inputState.runHandlers("scroll", OO), this.intersecting && this.view.measure()
      }
      onScroll(OO) {
        this.intersecting && this.flush(!1), this.editContext && this.view.requestMeasure(this.editContext.measureReq), this.onScrollChanged(OO)
      }
      tV() {
        this.resizeTimeout < 0 && (this.resizeTimeout = setTimeout((() => {
          this.resizeTimeout = -1, this.view.requestMeasure()
        }), 50))
      }
      onPrint(OO) {
        ("change" != OO.type && OO.type || OO.matches) && (this.view.viewState.printing = !0, this.view.measure(), setTimeout((() => {
          this.view.viewState.printing = !1, this.view.requestMeasure()
        }), 500))
      }
      updateGaps(OO) {
        if (this.gapIntersection && (OO.length != this.gaps.length || this.gaps.some(((KO, pO) => KO != OO[pO])))) {
          this.gapIntersection.disconnect();
          for (let KO of OO) this.gapIntersection.observe(KO);
          this.gaps = OO
        }
      }
      onSelectionChange(OO) {
        let KO = this.selectionChanged;
        if (!this.readSelectionRange() || this.delayedAndroidKey) return;
        let {
          view: pO
        } = this, XO = this.selectionRange;
        if (pO.state.facet(qp) ? pO.root.activeElement != this.dom : !JO(this.dom, XO)) return;
        let bK = XO.anchorNode && pO.docView.tile.nearest(XO.anchorNode);
        bK && bK.isWidget() && bK.widget.ignoreEvent(OO) ? KO || (this.selectionChanged = !1) : (NO.ie && NO.ie_version <= 11 || NO.android && NO.chrome) && !pO.state.selection.main.empty && XO.focusNode && BO(XO.focusNode, XO.focusOffset, XO.anchorNode, XO.anchorOffset) ? this.flushSoon() : this.flush(!1)
      }
      readSelectionRange() {
        let {
          view: OO
        } = this, KO = RO(OO.root);
        if (!KO) return !1;
        let pO = NO.safari && 11 == OO.root.nodeType && OO.root.activeElement == this.dom && function(OO, KO) {
          if (KO.getComposedRanges) {
            let pO = KO.getComposedRanges(OO.root)[0];
            if (pO) return Nb(OO, pO)
          }
          let pO = null;

          function XO(OO) {
            OO.preventDefault(), OO.stopImmediatePropagation(), pO = OO.getTargetRanges()[0]
          }
          return OO.contentDOM.addEventListener("beforeinput", XO, !0), OO.dom.ownerDocument.execCommand("indent"), OO.contentDOM.removeEventListener("beforeinput", XO, !0), pO ? Nb(OO, pO) : null
        }(this.view, KO) || KO;
        if (!pO || this.selectionRange.eq(pO)) return !1;
        let XO = JO(this.dom, pO);
        return XO && !this.selectionChanged && OO.inputState.lastFocusTime > Date.now() - 200 && OO.inputState.lastTouchTime < Date.now() - 300 && function(OO, KO) {
          let pO = KO.focusNode,
            XO = KO.focusOffset;
          if (!pO || KO.anchorNode != pO || KO.anchorOffset != XO) return !1;
          for (XO = Math.min(XO, xK(pO));;)
            if (XO) {
              if (1 != pO.nodeType) return !1;
              let OO = pO.childNodes[XO - 1];
              "false" == OO.contentEditable ? XO-- : (pO = OO, XO = xK(pO))
            } else {
              if (pO == OO) return !0;
              XO = ZO(pO), pO = pO.parentNode
            }
        }(this.dom, pO) ? (this.view.inputState.lastFocusTime = 0, OO.docView.updateSelection(), !1) : (this.selectionRange.setRange(pO), XO && (this.selectionChanged = !0), !0)
      }
      setSelectionRange(OO, KO) {
        this.selectionRange.set(OO.node, OO.offset, KO.node, KO.offset), this.selectionChanged = !1
      }
      clearSelectionRange() {
        this.selectionRange.set(null, 0, null, 0)
      }
      listenForScroll() {
        this.parentCheck = -1;
        let OO = 0,
          KO = null;
        for (let pO = this.dom; pO;)
          if (1 == pO.nodeType) !KO && OO < this.scrollTargets.length && this.scrollTargets[OO] == pO ? OO++ : KO || (KO = this.scrollTargets.slice(0, OO)), KO && KO.push(pO), pO = pO.assignedSlot || pO.parentNode;
          else {
            if (11 != pO.nodeType) break;
            pO = pO.host
          } if (OO < this.scrollTargets.length && !KO && (KO = this.scrollTargets.slice(0, OO)), KO) {
          for (let OO of this.scrollTargets) OO.removeEventListener("scroll", this.onScroll);
          for (let OO of this.scrollTargets = KO) OO.addEventListener("scroll", this.onScroll)
        }
      }
      ignore(OO) {
        if (!this.active) return OO();
        try {
          return this.stop(), OO()
        } finally {
          this.start(), this.clear()
        }
      }
      start() {
        this.active || (this.observer.observe(this.dom, Ab), fb && this.dom.addEventListener("DOMCharacterDataModified", this.onCharData), this.active = !0)
      }
      stop() {
        this.active && (this.active = !1, this.observer.disconnect(), fb && this.dom.removeEventListener("DOMCharacterDataModified", this.onCharData))
      }
      clear() {
        this.processRecords(), this.queue.length = 0, this.selectionChanged = !1
      }
      delayAndroidKey(OO, KO) {
        var pO;
        if (!this.delayedAndroidKey) {
          let OO = () => {
            let OO = this.delayedAndroidKey;
            if (OO) {
              this.clearDelayedAndroidKey(), this.view.inputState.lastKeyCode = OO.keyCode, this.view.inputState.lastKeyTime = Date.now(), !this.flush() && OO.force && bp(this.dom, OO.key, OO.keyCode)
            }
          };
          this.flushingAndroidKey = this.view.win.requestAnimationFrame(OO)
        }
        this.delayedAndroidKey && "Enter" != OO || (this.delayedAndroidKey = {
          key: OO,
          keyCode: KO,
          force: this.lastChange < Date.now() - 50 || !!(null === (pO = this.delayedAndroidKey) || void 0 === pO ? void 0 : pO.force)
        })
      }
      clearDelayedAndroidKey() {
        this.win.cancelAnimationFrame(this.flushingAndroidKey), this.delayedAndroidKey = null, this.flushingAndroidKey = -1
      }
      flushSoon() {
        this.delayedFlush < 0 && (this.delayedFlush = this.view.win.requestAnimationFrame((() => {
          this.delayedFlush = -1, this.flush()
        })))
      }
      forceFlush() {
        this.delayedFlush >= 0 && (this.view.win.cancelAnimationFrame(this.delayedFlush), this.delayedFlush = -1), this.flush()
      }
      pendingRecords() {
        for (let OO of this.observer.takeRecords()) this.queue.push(OO);
        return this.queue
      }
      processRecords() {
        let OO = this.pendingRecords();
        OO.length && (this.queue = []);
        let KO = -1,
          pO = -1,
          XO = !1;
        for (let bK of OO) {
          let OO = this.readMutation(bK);
          OO && (OO.typeOver && (XO = !0), -1 == KO ? ({
            from: KO,
            to: pO
          } = OO) : (KO = Math.min(OO.from, KO), pO = Math.max(OO.to, pO)))
        }
        return {
          from: KO,
          to: pO,
          typeOver: XO
        }
      }
      readChange() {
        let {
          from: OO,
          to: KO,
          typeOver: pO
        } = this.processRecords(), XO = this.selectionChanged && JO(this.dom, this.selectionRange);
        if (OO < 0 && !XO) return null;
        OO > -1 && (this.lastChange = Date.now()), this.view.inputState.lastFocusTime = 0, this.selectionChanged = !1;
        let bK = new pX(this.view, OO, KO, pO);
        return this.view.docView.domChanged = {
          newSel: bK.newSel ? bK.newSel.main : null
        }, bK
      }
      flush() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        if (this.delayedFlush >= 0 || this.delayedAndroidKey) return !1;
        OO && this.readSelectionRange();
        let KO = this.readChange();
        if (!KO) return this.view.requestMeasure(), !1;
        let pO = this.view.state,
          XO = bb(this.view, KO);
        return this.view.state == pO && (KO.domChanged || KO.newSel && !vb(this.view.state.selection, KO.newSel.main)) && this.view.update([]), XO
      }
      readMutation(OO) {
        let KO = this.view.docView.tile.nearest(OO.target);
        if (!KO || KO.isWidget()) return null;
        if (KO.markDirty("attributes" == OO.type), "childList" == OO.type) {
          let pO = Tb(KO, OO.previousSibling || OO.target.previousSibling, -1),
            XO = Tb(KO, OO.nextSibling || OO.target.nextSibling, 1);
          return {
            from: pO ? KO.posAfter(pO) : KO.posAtStart,
            to: XO ? KO.posBefore(XO) : KO.posAtEnd,
            typeOver: !1
          }
        }
        return "characterData" == OO.type ? {
          from: KO.posAtStart,
          to: KO.posAtEnd,
          typeOver: OO.target.nodeValue == OO.oldValue
        } : null
      }
      setWindow(OO) {
        OO != this.win && (this.removeWindowListeners(this.win), this.win = OO, this.addWindowListeners(this.win))
      }
      addWindowListeners(OO) {
        OO.addEventListener("resize", this.tV), this.printQuery ? this.printQuery.addEventListener ? this.printQuery.addEventListener("change", this.onPrint) : this.printQuery.addListener(this.onPrint) : OO.addEventListener("beforeprint", this.onPrint), OO.addEventListener("scroll", this.onScroll), OO.document.addEventListener("selectionchange", this.onSelectionChange)
      }
      removeWindowListeners(OO) {
        OO.removeEventListener("scroll", this.onScroll), OO.removeEventListener("resize", this.tV), this.printQuery ? this.printQuery.removeEventListener ? this.printQuery.removeEventListener("change", this.onPrint) : this.printQuery.removeListener(this.onPrint) : OO.removeEventListener("beforeprint", this.onPrint), OO.document.removeEventListener("selectionchange", this.onSelectionChange)
      }
      update(OO) {
        this.editContext && (this.editContext.update(OO), OO.startState.facet(qp) != OO.state.facet(qp) && (OO.view.contentDOM.editContext = OO.state.facet(qp) ? this.editContext.editContext : null))
      }
      destroy() {
        var OO, KO, pO;
        this.stop(), null === (OO = this.intersection) || void 0 === OO || OO.disconnect(), null === (KO = this.gapIntersection) || void 0 === KO || KO.disconnect(), null === (pO = this.resizeScroll) || void 0 === pO || pO.disconnect();
        for (let XO of this.scrollTargets) XO.removeEventListener("scroll", this.onScroll);
        this.removeWindowListeners(this.win), clearTimeout(this.parentCheck), clearTimeout(this.resizeTimeout), this.win.cancelAnimationFrame(this.delayedFlush), this.win.cancelAnimationFrame(this.flushingAndroidKey), this.editContext && (this.view.contentDOM.editContext = null, this.editContext.destroy())
      }
    }

    function Tb(OO, KO, pO) {
      for (; KO;) {
        let XO = aX.get(KO);
        if (XO && XO.parent == OO) return XO;
        let bK = KO.parentNode;
        KO = bK != OO.dom ? bK : pO > 0 ? KO.nextSibling : KO.previousSibling
      }
      return null
    }

    function Nb(OO, KO) {
      let pO = KO.startContainer,
        XO = KO.startOffset,
        bK = KO.endContainer,
        eO = KO.endOffset,
        lO = OO.docView.domAtPos(OO.state.selection.main.anchor, 1);
      return BO(lO.node, lO.offset, bK, eO) && ([pO, XO, bK, eO] = [bK, eO, pO, XO]), {
        anchorNode: pO,
        anchorOffset: XO,
        focusNode: bK,
        focusOffset: eO
      }
    }
    class Ib {
      constructor(OO) {
        this.from = 0, this.to = 0, this.pendingContextChange = null, this.handlers = Object.create(null), this.composing = null, this.resetRange(OO.state);
        let KO = this.editContext = new window.EditContext({
          text: OO.state.doc.sliceString(this.from, this.to),
          selectionStart: this.toContextPos(Math.max(this.from, Math.min(this.to, OO.state.selection.main.anchor))),
          selectionEnd: this.toContextPos(OO.state.selection.main.head)
        });
        this.handlers.textupdate = pO => {
          let bK = OO.state.selection.main,
            {
              anchor: eO,
              head: lO
            } = bK,
            vK = this.toEditorPos(pO.updateRangeStart),
            CO = this.toEditorPos(pO.updateRangeEnd);
          OO.inputState.composing >= 0 && !this.composing && (this.composing = {
            contextBase: pO.updateRangeStart,
            editorBase: vK,
            drifted: !1
          });
          let hO = CO - vK > pO.text.length;
          vK == this.from && eO < this.from ? vK = eO : CO == this.to && eO > this.to && (CO = eO);
          let DO = lX(OO.state.sliceDoc(vK, CO), pO.text, (hO ? bK.from : bK.to) - vK, hO ? "end" : null);
          if (!DO) {
            let KO = XO.j.single(this.toEditorPos(pO.selectionStart), this.toEditorPos(pO.selectionEnd));
            return void(vb(KO, bK) || OO.dispatch({
              selection: KO,
              userEvent: "select"
            }))
          }
          let MO = {
            from: DO.from + vK,
            to: DO.toA + vK,
            insert: XO.I.of(pO.text.slice(DO.from, DO.toB).split("\n"))
          };
          if ((NO.mac || NO.android) && MO.from == lO - 1 && /^\. ?$/.test(pO.text) && "off" == OO.contentDOM.getAttribute("autocorrect") && (MO = {
              from: vK,
              to: CO,
              insert: XO.I.of([pO.text.replace(".", " ")])
            }), this.pendingContextChange = MO, !OO.state.readOnly) {
            let KO = this.to - this.from + (MO.to - MO.from + MO.insert.length);
            eX(OO, MO, XO.j.single(this.toEditorPos(pO.selectionStart, KO), this.toEditorPos(pO.selectionEnd, KO)))
          }
          this.pendingContextChange && (this.revertPending(OO.state), this.setSelection(OO.state)), MO.from < MO.to && !MO.insert.length && OO.inputState.composing >= 0 && !/[\\p{Alphabetic}\\p{Number}_]/.test(KO.text.slice(Math.max(0, pO.updateRangeStart - 1), Math.min(KO.text.length, pO.updateRangeStart + 1))) && this.handlers.compositionend(pO)
        }, this.handlers.characterboundsupdate = pO => {
          let XO = [],
            bK = null;
          for (let KO = this.toEditorPos(pO.rangeStart), eO = this.toEditorPos(pO.rangeEnd); KO < eO; KO++) {
            let pO = OO.coordsForChar(KO);
            bK = pO && new DOMRect(pO.left, pO.top, pO.right - pO.left, pO.bottom - pO.top) || bK || new DOMRect, XO.push(bK)
          }
          KO.updateCharacterBounds(pO.rangeStart, XO)
        }, this.handlers.textformatupdate = KO => {
          let pO = [];
          for (let OO of KO.getTextFormats()) {
            let KO = OO.underlineStyle,
              XO = OO.underlineThickness;
            if (!/none/i.test(KO) && !/none/i.test(XO)) {
              let bK = this.toEditorPos(OO.rangeStart),
                eO = this.toEditorPos(OO.rangeEnd);
              if (bK < eO) {
                let OO = `text-decoration: underline ${/^[a-z]/.test(KO)?KO+" ":"Dashed"==KO?"dashed ":"Squiggle"==KO?"wavy ":""}${/thin/i.test(XO)?1:2}px`;
                pO.push(wO.mark({
                  attributes: {
                    style: OO
                  }
                }).range(bK, eO))
              }
            }
          }
          OO.dispatch({
            effects: ZK.of(wO.set(pO))
          })
        }, this.handlers.compositionstart = () => {
          OO.inputState.composing < 0 && (OO.inputState.composing = 0, OO.inputState.compositionFirstChange = !0)
        }, this.handlers.compositionend = () => {
          if (OO.inputState.composing = -1, OO.inputState.compositionFirstChange = null, this.composing) {
            let {
              drifted: KO
            } = this.composing;
            this.composing = null, KO && this.reset(OO.state)
          }
        };
        for (let pO in this.handlers) KO.addEventListener(pO, this.handlers[pO]);
        this.measureReq = {
          read: OO => {
            this.editContext.updateControlBounds(OO.contentDOM.getBoundingClientRect());
            let KO = RO(OO.root);
            KO && KO.rangeCount && this.editContext.updateSelectionBounds(KO.getRangeAt(0).getBoundingClientRect())
          }
        }
      }
      applyEdits(OO) {
        let KO = 0,
          pO = !1,
          XO = this.pendingContextChange;
        return OO.changes.iterChanges(((bK, eO, lO, vK, CO) => {
          if (pO) return;
          let hO = CO.length - (eO - bK);
          if (XO && eO >= XO.to) {
            if (XO.from == bK && XO.to == eO && XO.insert.eq(CO)) return XO = this.pendingContextChange = null, KO += hO, void(this.to += hO);
            XO = null, this.revertPending(OO.state)
          }
          if (bK += KO, (eO += KO) <= this.from) this.from += hO, this.to += hO;
          else if (bK < this.to) {
            if (bK < this.from || eO > this.to || this.to - this.from + CO.length > 3e4) return void(pO = !0);
            this.editContext.updateText(this.toContextPos(bK), this.toContextPos(eO), CO.toString()), this.to += hO
          }
          KO += hO
        })), XO && !pO && this.revertPending(OO.state), !pO
      }
      update(OO) {
        let KO = this.pendingContextChange,
          pO = OO.startState.selection.main;
        this.composing && (this.composing.drifted || !OO.changes.touchesRange(pO.from, pO.to) && OO.transactions.some((OO => !OO.isUserEvent("input.type") && OO.changes.touchesRange(this.from, this.to)))) ? (this.composing.drifted = !0, this.composing.editorBase = OO.changes.mapPos(this.composing.editorBase)) : this.applyEdits(OO) && this.rangeIsValid(OO.state) ? (OO.docChanged || OO.selectionSet || KO) && this.setSelection(OO.state) : (this.pendingContextChange = null, this.reset(OO.state)), (OO.geometryChanged || OO.docChanged || OO.selectionSet) && OO.view.requestMeasure(this.measureReq)
      }
      resetRange(OO) {
        let {
          head: KO
        } = OO.selection.main;
        this.from = Math.max(0, KO - 1e4), this.to = Math.min(OO.doc.length, KO + 1e4)
      }
      reset(OO) {
        this.resetRange(OO), this.editContext.updateText(0, this.editContext.text.length, OO.doc.sliceString(this.from, this.to)), this.setSelection(OO)
      }
      revertPending(OO) {
        let KO = this.pendingContextChange;
        this.pendingContextChange = null, this.editContext.updateText(this.toContextPos(KO.from), this.toContextPos(KO.from + KO.insert.length), OO.doc.sliceString(KO.from, KO.to))
      }
      setSelection(OO) {
        let {
          main: KO
        } = OO.selection, pO = this.toContextPos(Math.max(this.from, Math.min(this.to, KO.anchor))), XO = this.toContextPos(KO.head);
        this.editContext.selectionStart == pO && this.editContext.selectionEnd == XO || this.editContext.updateSelection(pO, XO)
      }
      rangeIsValid(OO) {
        let {
          head: KO
        } = OO.selection.main;
        return !(this.from > 0 && KO - this.from < 500 || this.to < OO.doc.length && this.to - KO < 500 || this.to - this.from > 3e4)
      }
      toEditorPos(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.to - this.from;
        OO = Math.min(OO, KO);
        let pO = this.composing;
        return pO && pO.drifted ? pO.editorBase + (OO - pO.contextBase) : OO + this.from
      }
      toContextPos(OO) {
        let KO = this.composing;
        return KO && KO.drifted ? KO.contextBase + (OO - KO.editorBase) : OO - this.from
      }
      destroy() {
        for (let OO in this.handlers) this.editContext.removeEventListener(OO, this.handlers[OO])
      }
    }
    class ye {
      get state() {
        return this.viewState.state
      }
      get viewport() {
        return this.viewState.viewport
      }
      get yvO() {
        return this.viewState.yvO
      }
      get inView() {
        return this.viewState.inView
      }
      get composing() {
        return !!this.inputState && this.inputState.composing > 0
      }
      get compositionStarted() {
        return !!this.inputState && this.inputState.composing >= 0
      }
      get root() {
        return this._root
      }
      get win() {
        return this.dom.ownerDocument.defaultView || window
      }
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        var KO;
        this.plugins = [], this.pluginMap = new Map, this.editorAttrs = {}, this.contentAttrs = {}, this.bidiCache = [], this.destroyed = !1, this.updateState = 2, this.measureScheduled = -1, this.measureRequests = [], this.contentDOM = document.createElement("div"), this.scrollDOM = document.createElement("div"), this.scrollDOM.tabIndex = -1, this.scrollDOM.className = "cm-scroller", this.scrollDOM.appendChild(this.contentDOM), this.announceDOM = document.createElement("div"), this.announceDOM.className = "cm-announced", this.announceDOM.setAttribute("aria-live", "polite"), this.dom = document.createElement("div"), this.dom.appendChild(this.announceDOM), this.dom.appendChild(this.scrollDOM), OO.parent && OO.parent.appendChild(this.dom);
        let {
          dispatch: pO
        } = OO;
        this.dispatchTransactions = OO.dispatchTransactions || pO && (OO => OO.forEach((OO => pO(OO, this)))) || (OO => this.update(OO)), this.dispatch = this.dispatch.bind(this), this._root = OO.root || function(OO) {
          for (; OO;) {
            if (OO && (9 == OO.nodeType || 11 == OO.nodeType && OO.host)) return OO;
            OO = OO.assignedSlot || OO.parentNode
          }
          return null
        }(OO.parent) || document, this.viewState = new Xb(this, OO.state || XO.m.create(OO)), OO.scrollTo && OO.scrollTo.is(BK) && (this.viewState.scrollTarget = OO.scrollTo.value.clip(this.viewState.state)), this.plugins = this.state.facet(nK).map((OO => new tp(OO)));
        for (let XO of this.plugins) XO.update(this);
        this.observer = new db(this), this.inputState = new CX(this), this.inputState.ensureHandlers(this.plugins), this.docView = new mX(this), this.mountStyles(), this.updateAttrs(), this.updateState = 0, this.requestMeasure(), (null === (KO = document.fonts) || void 0 === KO ? void 0 : KO.ready) && document.fonts.ready.then((() => {
          this.viewState.mustMeasureContent = "refresh", this.requestMeasure()
        }))
      }
      dispatch() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        let bK = 1 == KO.length && KO[0] instanceof XO.M ? KO : 1 == KO.length && Array.isArray(KO[0]) ? KO[0] : [this.state.update(...KO)];
        this.dispatchTransactions(bK, this)
      }
      update(OO) {
        if (0 != this.updateState) throw new Error("Calls to EditorView.update are not allowed while an update is in progress");
        let KO, pO = !1,
          bK = !1,
          eO = this.state;
        for (let XO of OO) {
          if (XO.startState != eO) throw new RangeError("Trying to update state with a transaction that doesn't start from the previous state.");
          eO = XO.state
        }
        if (this.destroyed) return void(this.viewState.state = eO);
        let lO = this.hasFocus,
          vK = 0,
          CO = null;
        OO.some((OO => OO.annotation(jb))) ? (this.inputState.notifiedFocused = lO, vK = 1) : lO != this.inputState.notifiedFocused && (this.inputState.notifiedFocused = lO, CO = YX(eO, lO), CO || (vK = 1));
        let hO = this.observer.delayedAndroidKey,
          DO = null;
        if (hO ? (this.observer.clearDelayedAndroidKey(), DO = this.observer.readChange(), (DO && !this.state.doc.eq(eO.doc) || !this.state.selection.eq(eO.selection)) && (DO = null)) : this.observer.clear(), eO.facet(XO.m.phrases) != this.state.facet(XO.m.phrases)) return this.setState(eO);
        KO = Dp.create(this, eO, OO), KO.flags |= vK;
        let MO = this.viewState.scrollTarget;
        try {
          this.updateState = 2;
          for (let KO of OO) {
            if (MO && (MO = MO.map(KO.changes)), KO.scrollIntoView) {
              let {
                main: OO
              } = KO.state.selection, {
                x: pO,
                y: bK
              } = this.state.facet(ye.cursorScrollMargin);
              MO = new cp(OO.empty ? OO : XO.j.cursor(OO.head, OO.head > OO.anchor ? -1 : 1), "nearest", "nearest", bK, pO)
            }
            for (let OO of KO.effects) OO.is(BK) && (MO = OO.value.clip(this.state))
          }
          this.viewState.update(KO, MO), this.bidiCache = Eb.update(this.bidiCache, KO.changes), KO.empty || (this.updatePlugins(KO), this.inputState.update(KO)), pO = this.docView.update(KO), this.state.facet(Cp) != this.styleModules && this.mountStyles(), bK = this.updateAttrs(), this.showAnnouncements(OO), this.docView.updateSelection(pO, OO.some((OO => OO.isUserEvent("select.pointer"))))
        } finally {
          this.updateState = 0
        }
        if (KO.startState.facet(Mb) != KO.state.facet(Mb) && (this.viewState.mustMeasureContent = !0), (pO || bK || MO || this.viewState.mustEnforceCursorAssoc || this.viewState.mustMeasureContent) && this.requestMeasure(), pO && this.docViewUpdate(), !KO.empty)
          for (let XO of this.state.facet(rp)) try {
            XO(KO)
          } catch (aK) {
            GK(this.state, aK, "update listener")
          }(CO || DO) && Promise.resolve().then((() => {
            CO && this.state == CO.startState && this.dispatch(CO), DO && !bb(this, DO) && hO.force && bp(this.contentDOM, hO.key, hO.keyCode)
          }))
      }
      setState(OO) {
        if (0 != this.updateState) throw new Error("Calls to EditorView.setState are not allowed while an update is in progress");
        if (this.destroyed) return void(this.viewState.state = OO);
        this.updateState = 2;
        let KO = this.hasFocus;
        try {
          for (let OO of this.plugins) OO.destroy(this);
          this.viewState = new Xb(this, OO), this.plugins = OO.facet(nK).map((OO => new tp(OO))), this.pluginMap.clear();
          for (let OO of this.plugins) OO.update(this);
          this.docView.destroy(), this.docView = new mX(this), this.inputState.ensureHandlers(this.plugins), this.mountStyles(), this.updateAttrs(), this.bidiCache = []
        } finally {
          this.updateState = 0
        }
        KO && this.focus(), this.requestMeasure()
      }
      updatePlugins(OO) {
        let KO = OO.startState.facet(nK),
          pO = OO.state.facet(nK);
        if (KO != pO) {
          let XO = [];
          for (let bK of pO) {
            let pO = KO.indexOf(bK);
            if (pO < 0) XO.push(new tp(bK));
            else {
              let KO = this.plugins[pO];
              KO.mustUpdate = OO, XO.push(KO)
            }
          }
          for (let KO of this.plugins) KO.mustUpdate != OO && KO.destroy(this);
          this.plugins = XO, this.pluginMap.clear()
        } else
          for (let XO of this.plugins) XO.mustUpdate = OO;
        for (let XO = 0; XO < this.plugins.length; XO++) this.plugins[XO].update(this);
        KO != pO && this.inputState.ensureHandlers(this.plugins)
      }
      docViewUpdate() {
        for (let KO of this.plugins) {
          let pO = KO.value;
          if (pO && pO.docViewUpdate) try {
            pO.docViewUpdate(this)
          } catch (OO) {
            GK(this.state, OO, "doc view update listener")
          }
        }
      }
      measure() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        if (this.destroyed) return;
        if (this.measureScheduled > -1 && this.win.cancelAnimationFrame(this.measureScheduled), this.observer.delayedAndroidKey) return this.measureScheduled = -1, void this.requestMeasure();
        this.measureScheduled = 0, OO && this.observer.forceFlush();
        let KO = null,
          pO = this.viewState.scrollParent,
          XO = this.viewState.getScrollOffset(),
          {
            scrollAnchorPos: bK,
            scrollAnchorHeight: eO
          } = this.viewState;
        Math.abs(XO - this.viewState.scrollOffset) > 1 && (eO = -1), this.viewState.scrollAnchorHeight = -1;
        try {
          for (let OO = 0;; OO++) {
            if (eO < 0)
              if (eK(pO || this.win)) bK = -1, eO = this.viewState.heightMap.height;
              else {
                let OO = this.viewState.scrollAnchorAt(XO);
                bK = OO.from, eO = OO.top
              } this.updateState = 1;
            let vK = this.viewState.measure();
            if (!vK && !this.measureRequests.length && null == this.viewState.scrollTarget) break;
            if (OO > 5) {
              console.warn(this.measureRequests.length ? "Measure loop restarted more than 5 times" : "Viewport failed to stabilize");
              break
            }
            let CO = [];
            4 & vK || ([this.measureRequests, CO] = [CO, this.measureRequests]);
            let hO = CO.map((OO => {
                try {
                  return OO.read(this)
                } catch (KO) {
                  return GK(this.state, KO), ub
                }
              })),
              DO = Dp.create(this, this.state, []),
              MO = !1;
            DO.flags |= vK, KO ? KO.flags |= vK : KO = DO, this.updateState = 2, DO.empty || (this.updatePlugins(DO), this.inputState.update(DO), this.updateAttrs(), MO = this.docView.update(DO), MO && this.docViewUpdate());
            for (let OO = 0; OO < CO.length; OO++)
              if (hO[OO] != ub) try {
                let KO = CO[OO];
                KO.write && KO.write(hO[OO], this)
              } catch (lO) {
                GK(this.state, lO)
              }
            if (MO && this.docView.updateSelection(!0), !DO.viewportChanged && 0 == this.measureRequests.length) {
              if (this.viewState.editorHeight) {
                if (this.viewState.scrollTarget) {
                  this.docView.scrollIntoView(this.viewState.scrollTarget), this.viewState.scrollTarget = null, eO = -1;
                  continue
                } {
                  let OO = ((bK < 0 ? this.viewState.heightMap.height : this.viewState.lineBlockAt(bK).top) - eO) / this.scaleY;
                  if ((OO > 1 || OO < -1) && (pO == this.scrollDOM || this.hasFocus || Math.max(this.inputState.lastWheelEvent, this.inputState.lastTouchTime) > Date.now() - 100)) {
                    XO += OO, pO ? pO.scrollTop += OO : this.win.scrollBy(0, OO), eO = -1;
                    continue
                  }
                }
              }
              break
            }
          }
        } finally {
          this.updateState = 0, this.measureScheduled = -1
        }
        if (KO && !KO.empty)
          for (let vK of this.state.facet(rp)) vK(KO)
      }
      get themeClasses() {
        return ob + " " + (this.state.facet(ae) ? Vb : Fb) + " " + this.state.facet(Mb)
      }
      updateAttrs() {
        let OO = je(this, kp, {
            class: "cm-editor" + (this.hasFocus ? " cm-focused " : " ") + this.themeClasses
          }),
          KO = {
            spellcheck: "false",
            autocorrect: "off",
            autocapitalize: "off",
            writingsuggestions: "false",
            translate: "no",
            contenteditable: this.state.facet(qp) ? "true" : "false",
            class: "cm-content",
            style: `${NO.tabSize}: ${this.state.tabSize}`,
            role: "textbox",
            "aria-multiline": "true"
          };
        this.state.readOnly && (KO["aria-readonly"] = "true"), je(this, UK, KO);
        let pO = this.observer.ignore((() => {
          let pO = uO(this.contentDOM, this.contentAttrs, KO),
            XO = uO(this.dom, this.editorAttrs, OO);
          return pO || XO
        }));
        return this.editorAttrs = OO, this.contentAttrs = KO, pO
      }
      showAnnouncements(OO) {
        let KO = !0;
        for (let pO of OO)
          for (let OO of pO.effects)
            if (OO.is(ye.announce)) {
              KO && (this.announceDOM.textContent = ""), KO = !1, this.announceDOM.appendChild(document.createElement("div")).textContent = OO.value
            }
      }
      mountStyles() {
        this.styleModules = this.state.facet(Cp);
        let OO = this.state.facet(ye.cspNonce);
        bK.e.mount(this.root, this.styleModules.concat(ze).reverse(), OO ? {
          nonce: OO
        } : void 0)
      }
      readMeasured() {
        if (2 == this.updateState) throw new Error("Reading the editor layout isn't allowed during an update");
        0 == this.updateState && this.measureScheduled > -1 && this.measure(!1)
      }
      requestMeasure(OO) {
        if (this.measureScheduled < 0 && (this.measureScheduled = this.win.requestAnimationFrame((() => this.measure()))), OO) {
          if (this.measureRequests.indexOf(OO) > -1) return;
          if (null != OO.key)
            for (let KO = 0; KO < this.measureRequests.length; KO++)
              if (this.measureRequests[KO].key === OO.key) return void(this.measureRequests[KO] = OO);
          this.measureRequests.push(OO)
        }
      }
      plugin(OO) {
        let KO = this.pluginMap.get(OO);
        return (void 0 === KO || KO && KO.plugin != OO) && this.pluginMap.set(OO, KO = this.plugins.find((KO => KO.plugin == OO)) || null), KO && KO.update(this).value
      }
      get documentTop() {
        return this.contentDOM.getBoundingClientRect().top + this.viewState.paddingTop
      }
      get documentPadding() {
        return {
          top: this.viewState.paddingTop,
          bottom: this.viewState.paddingBottom
        }
      }
      get scaleX() {
        return this.viewState.scaleX
      }
      get scaleY() {
        return this.viewState.scaleY
      }
      elementAtHeight(OO) {
        return this.readMeasured(), this.viewState.elementAtHeight(OO)
      }
      lineBlockAtHeight(OO) {
        return this.readMeasured(), this.viewState.lineBlockAtHeight(OO)
      }
      get viewportLineBlocks() {
        return this.viewState.viewportLines
      }
      lineBlockAt(OO) {
        return this.viewState.lineBlockAt(OO)
      }
      get contentHeight() {
        return this.viewState.contentHeight
      }
      moveByChar(OO, KO, pO) {
        return qX(this, OO, Bp(this, OO, KO, pO))
      }
      moveByGroup(OO, KO) {
        return qX(this, OO, Bp(this, OO, KO, (KO => function(OO, KO, pO) {
          let bK = OO.state.charCategorizer(KO),
            eO = bK(pO);
          return OO => {
            let KO = bK(OO);
            return eO == XO.i.Space && (eO = KO), eO == KO
          }
        }(this, OO.head, KO))))
      }
      visualLineSide(OO, KO) {
        let pO = this.bidiSpans(OO),
          bK = this.textDirectionAt(OO.from),
          eO = pO[KO ? pO.length - 1 : 0];
        return XO.j.cursor(eO.side(KO, bK) + OO.from, eO.forward(!KO, bK) ? 1 : -1)
      }
      moveToLineBoundary(OO, KO) {
        return function(OO, KO, pO, bK) {
          let eO = cX(OO, KO.head, KO.assoc || -1),
            lO = bK && eO.type == YO.Text && (OO.lineWrapping || eO.widgetLineBreaks) ? OO.coordsAtPos(KO.assoc < 0 && KO.head > eO.from ? KO.head - 1 : KO.head) : null;
          if (lO) {
            let KO = OO.dom.getBoundingClientRect(),
              bK = OO.textDirectionAt(eO.from),
              vK = OO.posAtCoords({
                x: pO == (bK == hK.LTR) ? KO.right - 1 : KO.left + 1,
                y: (lO.top + lO.bottom) / 2
              });
            if (null != vK) return XO.j.cursor(vK, pO ? -1 : 1)
          }
          return XO.j.cursor(pO ? eO.to : eO.from, pO ? -1 : 1)
        }(this, OO, KO, !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2])
      }
      moveVertically(OO, KO, pO) {
        return qX(this, OO, function(OO, KO, pO, bK) {
          let eO = KO.head,
            lO = pO ? 1 : -1;
          if (eO == (pO ? OO.state.doc.length : 0)) return XO.j.cursor(eO, KO.assoc);
          let vK, CO = KO.goalColumn,
            hO = OO.contentDOM.getBoundingClientRect(),
            DO = OO.coordsAtPos(eO, KO.assoc || ((KO.empty ? pO : KO.head == KO.from) ? 1 : -1)),
            MO = OO.documentTop;
          if (DO) null == CO && (CO = DO.left - hO.left), vK = lO < 0 ? DO.top : DO.bottom;
          else {
            let KO = OO.viewState.lineBlockAt(eO);
            null == CO && (CO = Math.min(hO.right - hO.left, OO.defaultCharacterWidth * (eO - KO.from))), vK = (lO < 0 ? KO.top : KO.bottom) + MO
          }
          let aK = hO.left + CO,
            oO = OO.viewState.heightOracle.textHeight >> 1,
            FO = null !== bK && void 0 !== bK ? bK : oO;
          for (let VO = 0;; VO += oO) {
            let KO = vK + (FO + VO) * lO,
              bK = np(OO, {
                x: aK,
                y: KO
              }, !1, lO);
            if (pO ? KO > hO.bottom : KO < hO.top) return XO.j.cursor(bK.pos, bK.assoc);
            let eO = OO.coordsAtPos(bK.pos, bK.assoc),
              DO = eO ? (eO.top + eO.bottom) / 2 : 0;
            if (!eO || (pO ? DO > vK : DO < vK)) return XO.j.cursor(bK.pos, bK.assoc, void 0, CO)
          }
        }(this, OO, KO, pO))
      }
      domAtPos(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        return this.docView.domAtPos(OO, KO)
      }
      posAtDOM(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return this.docView.posFromDOM(OO, KO)
      }
      posAtCoords(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        this.readMeasured();
        let pO = np(this, OO, KO);
        return pO && pO.pos
      }
      posAndSideAtCoords(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        return this.readMeasured(), np(this, OO, KO)
      }
      coordsAtPos(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        this.readMeasured();
        let pO = this.docView.coordsAt(OO, KO);
        if (!pO || pO.left == pO.right) return pO;
        let XO = this.state.doc.lineAt(OO),
          bK = this.bidiSpans(XO);
        return nO(pO, bK[AK.find(bK, OO - XO.from, -1, KO)].dir == hK.LTR == KO > 0)
      }
      coordsForChar(OO) {
        return this.readMeasured(), this.docView.coordsForChar(OO)
      }
      get defaultCharacterWidth() {
        return this.viewState.heightOracle.charWidth
      }
      get defaultLineHeight() {
        return this.viewState.heightOracle.lineHeight
      }
      get textDirection() {
        return this.viewState.defaultTextDirection
      }
      textDirectionAt(OO) {
        return !this.state.facet(RK) || OO < this.viewport.from || OO > this.viewport.to ? this.textDirection : (this.readMeasured(), this.docView.textDirectionAt(OO))
      }
      get lineWrapping() {
        return this.viewState.heightOracle.lineWrapping
      }
      bidiSpans(OO) {
        if (OO.length > ge) return yp(OO.length);
        let KO, pO = this.textDirectionAt(OO.from);
        for (let bK of this.bidiCache)
          if (bK.from == OO.from && bK.dir == pO && (bK.fresh || fK(bK.isolates, KO = ep(this, OO)))) return bK.order;
        KO || (KO = ep(this, OO));
        let XO = IK(OO.text, pO, KO);
        return this.bidiCache.push(new Eb(OO.from, OO.to, pO, KO, !0, XO)), XO
      }
      get hasFocus() {
        var OO;
        return (this.dom.ownerDocument.hasFocus() || NO.safari && (null === (OO = this.inputState) || void 0 === OO ? void 0 : OO.lastContextMenu) > Date.now() - 3e4) && this.root.activeElement == this.contentDOM
      }
      focus() {
        this.observer.ignore((() => {
          pK(this.contentDOM), this.docView.updateSelection()
        }))
      }
      setRoot(OO) {
        this._root != OO && (this._root = OO, this.observer.setWindow((9 == OO.nodeType ? OO : OO.ownerDocument).defaultView || window), this.mountStyles())
      }
      destroy() {
        this.root.activeElement == this.contentDOM && this.contentDOM.blur();
        for (let OO of this.plugins) OO.destroy(this);
        this.plugins = [], this.inputState.destroy(), this.docView.destroy(), this.dom.remove(), this.observer.destroy(), this.measureScheduled > -1 && this.win.cancelAnimationFrame(this.measureScheduled), this.destroyed = !0
      }
      static scrollIntoView(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        var pO, bK, eO, lO;
        return BK.of(new cp("number" == typeof OO ? XO.j.cursor(OO) : OO, null !== (pO = KO.y) && void 0 !== pO ? pO : "nearest", null !== (bK = KO.x) && void 0 !== bK ? bK : "nearest", null !== (eO = KO.yMargin) && void 0 !== eO ? eO : 5, null !== (lO = KO.xMargin) && void 0 !== lO ? lO : 5))
      }
      scrollSnapshot() {
        let {
          scrollTop: OO,
          scrollLeft: KO
        } = this.scrollDOM, pO = this.viewState.scrollAnchorAt(OO);
        return BK.of(new cp(XO.j.cursor(pO.from), "start", "start", pO.top - OO, KO, !0))
      }
      setTabFocusMode(OO) {
        null == OO ? this.inputState.tabFocusMode = this.inputState.tabFocusMode < 0 ? 0 : -1 : "boolean" == typeof OO ? this.inputState.tabFocusMode = OO ? 0 : -1 : 0 != this.inputState.tabFocusMode && (this.inputState.tabFocusMode = Date.now() + OO)
      }
      static domEventHandlers(OO) {
        return WK.define((() => ({})), {
          eventHandlers: OO
        })
      }
      static domEventObservers(OO) {
        return WK.define((() => ({})), {
          eventObservers: OO
        })
      }
      static theme(OO, KO) {
        let pO = bK.e.newName(),
          XO = [Mb.of(pO), Cp.of(Qb(`.${pO}`, OO))];
        return KO && KO.dark && XO.push(ae.of(!0)), XO
      }
      static baseTheme(OO) {
        return XO.u.lowest(Cp.of(Qb("." + ob, OO, Lb)))
      }
      static findFromDOM(OO) {
        var KO;
        let pO = OO.querySelector(".cm-content"),
          XO = pO && aX.get(pO) || aX.get(OO);
        return (null === (KO = null === XO || void 0 === XO ? void 0 : XO.root) || void 0 === KO ? void 0 : KO.view) || null
      }
    }
    ye.styleModule = Cp, ye.inputHandler = PK, ye.clipboardInputFilter = sK, ye.clipboardOutputFilter = HK, ye.scrollHandler = JK, ye.focusChangeEffect = mp, ye.perLineTextDirection = RK, ye.exceptionSink = ip, ye.updateListener = rp, ye.editable = qp, ye.mouseSelectionStyle = wK, ye.dragMovesSelection = YK, ye.clickAddsSelectionRange = jp, ye.ql = Op, ye.blockWrappers = Kp, ye.outerDecorations = pp, ye.atomicRanges = Xp, ye.bidiIsolatedRanges = bX, ye.cursorScrollMargin = XO.n.define({
      combine: OO => {
        let KO = 5,
          pO = 5;
        for (let XO of OO) "number" == typeof XO ? KO = pO = XO : ({
          x: KO,
          y: pO
        } = XO);
        return {
          x: KO,
          y: pO
        }
      }
    }), ye.scrollMargins = lp, ye.darkTheme = ae, ye.cspNonce = XO.n.define({
      combine: OO => OO.length ? OO[0] : ""
    }), ye.contentAttributes = UK, ye.editorAttributes = kp, ye.lineWrapping = ye.contentAttributes.of({
      class: "cm-lineWrapping"
    }), ye.announce = XO.C.define();
    const ge = 4096,
      ub = {};
    class Eb {
      constructor(OO, KO, pO, XO, bK, eO) {
        this.from = OO, this.to = KO, this.dir = pO, this.isolates = XO, this.fresh = bK, this.order = eO
      }
      static update(OO, KO) {
        if (KO.empty && !OO.some((OO => OO.fresh))) return OO;
        let pO = [],
          XO = OO.length ? OO[OO.length - 1].dir : hK.LTR;
        for (let bK = Math.max(0, OO.length - 10); bK < OO.length; bK++) {
          let eO = OO[bK];
          eO.dir != XO || KO.touchesRange(eO.from, eO.to) || pO.push(new Eb(KO.mapPos(eO.from, 1), KO.mapPos(eO.to, -1), eO.dir, eO.isolates, !1, eO.order))
        }
        return pO
      }
    }

    function je(OO, KO, pO) {
      for (let XO = OO.state.facet(KO), bK = XO.length - 1; bK >= 0; bK--) {
        let KO = XO[bK],
          eO = "function" == typeof KO ? KO(OO) : KO;
        eO && IO(eO, pO)
      }
      return pO
    }
    const Yb = NO.mac ? "mac" : NO.windows ? "win" : NO.linux ? "linux" : "key";

    function wb(OO, KO, pO) {
      return KO.altKey && (OO = "Alt-" + OO), KO.ctrlKey && (OO = "Ctrl-" + OO), KO.metaKey && (OO = "Meta-" + OO), !1 !== pO && KO.shiftKey && (OO = "Shift-" + OO), OO
    }
    const ie = XO.u.default(ye.domEventHandlers({
        keydown: (OO, KO) => Jb(me(KO.state), OO, KO, "editor")
      })),
      re = XO.n.define({
        enables: ie
      }),
      Pb = new WeakMap;

    function me(OO) {
      let KO = OO.facet(re),
        pO = Pb.get(KO);
      return pO || Pb.set(KO, pO = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Yb,
          pO = Object.create(null),
          XO = Object.create(null),
          bK = (OO, KO) => {
            let pO = XO[OO];
            if (null == pO) XO[OO] = KO;
            else if (pO != KO) throw new Error("Key binding " + OO + " is used both as a regular binding and as a multi-stroke prefix")
          },
          eO = (OO, XO, eO, lO, vK) => {
            var CO, hO;
            let DO = pO[OO] || (pO[OO] = Object.create(null)),
              MO = XO.split(/ (?!$)/).map((OO => function(OO, KO) {
                const pO = OO.split(/-(?!$)/);
                let XO, bK, eO, lO, vK = pO[pO.length - 1];
                "Space" == vK && (vK = " ");
                for (let CO = 0; CO < pO.length - 1; ++CO) {
                  const OO = pO[CO];
                  if (/^(cmd|meta|m)$/i.test(OO)) lO = !0;
                  else if (/^a(lt)?$/i.test(OO)) XO = !0;
                  else if (/^(c|ctrl|control)$/i.test(OO)) bK = !0;
                  else if (/^s(hift)?$/i.test(OO)) eO = !0;
                  else {
                    if (!/^mod$/i.test(OO)) throw new Error("Unrecognized modifier name: " + OO);
                    "mac" == KO ? lO = !0 : bK = !0
                  }
                }
                return XO && (vK = "Alt-" + vK), bK && (vK = "Ctrl-" + vK), lO && (vK = "Meta-" + vK), eO && (vK = "Shift-" + vK), vK
              }(OO, KO)));
            for (let KO = 1; KO < MO.length; KO++) {
              let pO = MO.slice(0, KO).join(" ");
              bK(pO, !0), DO[pO] || (DO[pO] = {
                preventDefault: !0,
                stopPropagation: !1,
                run: [KO => {
                  let XO = Hb = {
                    view: KO,
                    prefix: pO,
                    scope: OO
                  };
                  return setTimeout((() => {
                    Hb == XO && (Hb = null)
                  }), Rb), !0
                }]
              })
            }
            let aK = MO.join(" ");
            bK(aK, !1);
            let oO = DO[aK] || (DO[aK] = {
              preventDefault: !1,
              stopPropagation: !1,
              run: (null === (hO = null === (CO = DO._any) || void 0 === CO ? void 0 : CO.run) || void 0 === hO ? void 0 : hO.slice()) || []
            });
            eO && oO.run.push(eO), lO && (oO.preventDefault = !0), vK && (oO.stopPropagation = !0)
          };
        for (let lO of OO) {
          let OO = lO.scope ? lO.scope.split(" ") : ["editor"];
          if (lO.any)
            for (let KO of OO) {
              let OO = pO[KO] || (pO[KO] = Object.create(null));
              OO._any || (OO._any = {
                preventDefault: !1,
                stopPropagation: !1,
                run: []
              });
              let {
                any: XO
              } = lO;
              for (let KO in OO) OO[KO].run.push((OO => XO(OO, Sb)))
            }
          let XO = lO[KO] || lO.key;
          if (XO)
            for (let KO of OO) eO(KO, XO, lO.run, lO.preventDefault, lO.stopPropagation), lO.shift && eO(KO, "Shift-" + XO, lO.shift, lO.preventDefault, lO.stopPropagation)
        }
        return pO
      }(KO.reduce(((OO, KO) => OO.concat(KO)), []))), pO
    }

    function sb(OO, KO, pO) {
      return Jb(me(OO.state), KO, OO, pO)
    }
    let Hb = null;
    const Rb = 4e3;
    let Sb = null;

    function Jb(OO, KO, pO, bK) {
      Sb = KO;
      let hO = function(OO) {
          var KO = !(vK && OO.metaKey && OO.shiftKey && !OO.ctrlKey && !OO.altKey || CO && OO.shiftKey && OO.key && 1 == OO.key.length || "Unidentified" == OO.key) && OO.key || (OO.shiftKey ? lO : eO)[OO.keyCode] || OO.key || "Unidentified";
          return "Esc" == KO && (KO = "Escape"), "Del" == KO && (KO = "Delete"), "Left" == KO && (KO = "ArrowLeft"), "Up" == KO && (KO = "ArrowUp"), "Right" == KO && (KO = "ArrowRight"), "Down" == KO && (KO = "ArrowDown"), KO
        }(KO),
        DO = (0, XO.N)(hO, 0),
        MO = (0, XO.P)(DO) == hO.length && " " != hO,
        aK = "",
        oO = !1,
        FO = !1,
        VO = !1;
      Hb && Hb.view == pO && Hb.scope == bK && (aK = Hb.prefix + " ", oX.indexOf(KO.keyCode) < 0 && (FO = !0, Hb = null));
      let LO, QO, zK = new Set,
        AO = OO => {
          if (OO) {
            for (let KO of OO.run)
              if (!zK.has(KO) && (zK.add(KO), KO(pO))) return OO.stopPropagation && (VO = !0), !0;
            OO.preventDefault && (OO.stopPropagation && (VO = !0), FO = !0)
          }
          return !1
        },
        fO = OO[bK];
      return fO && (AO(fO[aK + wb(hO, KO, !MO)]) ? oO = !0 : !MO || !(KO.altKey || KO.metaKey || KO.ctrlKey) || NO.windows && KO.ctrlKey && KO.altKey || NO.mac && KO.altKey && !KO.ctrlKey && !KO.metaKey || !(LO = eO[KO.keyCode]) || LO == hO ? MO && KO.shiftKey && AO(fO[aK + wb(hO, KO, !0)]) && (oO = !0) : (AO(fO[aK + wb(LO, KO, !0)]) || KO.shiftKey && (QO = lO[KO.keyCode]) != hO && QO != LO && AO(fO[aK + wb(QO, KO, !1)])) && (oO = !0), !oO && AO(fO._any) && (oO = !0)), FO && (oO = !0), oO && VO && KO.stopPropagation(), Sb = null, oO
    }
    class ce {
      constructor(OO, KO, pO, XO, bK) {
        this.className = OO, this.left = KO, this.top = pO, this.width = XO, this.height = bK
      }
      draw() {
        let OO = document.createElement("div");
        return OO.className = this.className, this.adjust(OO), OO
      }
      update(OO, KO) {
        return KO.className == this.className && (this.adjust(OO), !0)
      }
      adjust(OO) {
        OO.style.left = this.left + "px", OO.style.top = this.top + "px", null != this.width && (OO.style.width = this.width + "px"), OO.style.height = this.height + "px"
      }
      eq(OO) {
        return this.left == OO.left && this.top == OO.top && this.width == OO.width && this.height == OO.height && this.className == OO.className
      }
      static forRange(OO, KO, pO) {
        if (pO.empty) {
          let XO = OO.coordsAtPos(pO.head, pO.assoc || 1);
          if (!XO) return [];
          let bK = Bb(OO);
          return [new ce(KO, XO.left - bK.left, XO.top - bK.top, null, XO.bottom - XO.top)]
        }
        return function(OO, KO, pO) {
          if (pO.to <= OO.viewport.from || pO.from >= OO.viewport.to) return [];
          let XO = Math.max(pO.from, OO.viewport.from),
            bK = Math.min(pO.to, OO.viewport.to),
            eO = OO.textDirection == hK.LTR,
            lO = OO.contentDOM,
            vK = lO.getBoundingClientRect(),
            CO = Bb(OO),
            hO = lO.querySelector(".cm-line"),
            DO = hO && window.getComputedStyle(hO),
            MO = vK.left + (DO ? parseInt(DO.paddingLeft) + Math.min(0, parseInt(DO.textIndent)) : 0),
            aK = vK.right - (DO ? parseInt(DO.paddingRight) : 0),
            oO = cX(OO, XO, 1),
            FO = cX(OO, bK, -1),
            VO = oO.type == YO.Text ? oO : null,
            LO = FO.type == YO.Text ? FO : null;
          VO && (OO.lineWrapping || oO.widgetLineBreaks) && (VO = Zb(OO, XO, 1, VO));
          LO && (OO.lineWrapping || FO.widgetLineBreaks) && (LO = Zb(OO, bK, -1, LO));
          if (VO && LO && VO.from == LO.from && VO.to == LO.to) return zK(AO(pO.from, pO.to, VO));
          {
            let KO = VO ? AO(pO.from, null, VO) : fO(oO, !1),
              XO = LO ? AO(null, pO.to, LO) : fO(FO, !0),
              bK = [];
            return (VO || oO).to < (LO || FO).from - (VO && LO ? 1 : 0) || oO.widgetLineBreaks > 1 && KO.bottom + OO.defaultLineHeight / 2 < XO.top ? bK.push(QO(MO, KO.bottom, aK, XO.top)) : KO.bottom < XO.top && OO.elementAtHeight((KO.bottom + XO.top) / 2).type == YO.Text && (KO.bottom = XO.top = (KO.bottom + XO.top) / 2), zK(KO).concat(bK).concat(zK(XO))
          }

          function QO(OO, pO, XO, bK) {
            return new ce(KO, OO - CO.left, pO - CO.top, Math.max(0, XO - OO), bK - pO)
          }

          function zK(OO) {
            let {
              top: KO,
              bottom: pO,
              horizontal: XO
            } = OO, bK = [];
            for (let eO = 0; eO < XO.length; eO += 2) bK.push(QO(XO[eO], KO, XO[eO + 1], pO));
            return bK
          }

          function AO(KO, pO, XO) {
            let bK = 1e9,
              lO = -1e9,
              vK = [];

            function CO(KO, pO, CO, hO, DO) {
              let oO = OO.coordsAtPos(KO, KO == XO.to ? -2 : 2),
                FO = OO.coordsAtPos(CO, CO == XO.from ? 2 : -2);
              oO && FO && (bK = Math.min(oO.top, FO.top, bK), lO = Math.max(oO.bottom, FO.bottom, lO), DO == hK.LTR ? vK.push(eO && pO ? MO : oO.left, eO && hO ? aK : FO.right) : vK.push(!eO && hO ? MO : FO.left, !eO && pO ? aK : oO.right))
            }
            let hO = null !== KO && void 0 !== KO ? KO : XO.from,
              DO = null !== pO && void 0 !== pO ? pO : XO.to;
            for (let eO of OO.yvO)
              if (eO.to > hO && eO.from < DO)
                for (let XO = Math.max(eO.from, hO), bK = Math.min(eO.to, DO);;) {
                  let eO = OO.state.doc.lineAt(XO);
                  for (let lO of OO.bidiSpans(eO)) {
                    let OO = lO.from + eO.from,
                      vK = lO.to + eO.from;
                    if (OO >= bK) break;
                    vK > XO && CO(Math.max(OO, XO), null == KO && OO <= hO, Math.min(vK, bK), null == pO && vK >= DO, lO.dir)
                  }
                  if (XO = eO.to + 1, XO >= bK) break
                }
            return 0 == vK.length && CO(hO, null == KO, DO, null == pO, OO.textDirection), {
              top: bK,
              bottom: lO,
              horizontal: vK
            }
          }

          function fO(OO, KO) {
            let pO = vK.top + (KO ? OO.top : OO.bottom);
            return {
              top: pO,
              bottom: pO,
              horizontal: []
            }
          }
        }(OO, KO, pO)
      }
    }

    function Bb(OO) {
      let KO = OO.scrollDOM.getBoundingClientRect();
      return {
        left: (OO.textDirection == hK.LTR ? KO.left : KO.right - OO.scrollDOM.clientWidth * OO.scaleX) - OO.scrollDOM.scrollLeft * OO.scaleX,
        top: KO.top - OO.scrollDOM.scrollTop * OO.scaleY
      }
    }

    function Zb(OO, KO, pO, XO) {
      let bK = OO.coordsAtPos(KO, 2 * pO);
      if (!bK) return XO;
      let eO = OO.dom.getBoundingClientRect(),
        lO = (bK.top + bK.bottom) / 2,
        vK = OO.posAtCoords({
          x: eO.left + 1,
          y: lO
        }),
        CO = OO.posAtCoords({
          x: eO.right - 1,
          y: lO
        });
      return null == vK || null == CO ? XO : {
        from: Math.max(XO.from, Math.min(vK, CO)),
        to: Math.min(XO.to, Math.max(vK, CO))
      }
    }
    class Gb {
      constructor(OO, KO) {
        this.view = OO, this.layer = KO, this.drawn = [], this.scaleX = 1, this.scaleY = 1, this.measureReq = {
          read: this.measure.bind(this),
          write: this.draw.bind(this)
        }, this.dom = OO.scrollDOM.appendChild(document.createElement("div")), this.dom.classList.add("cm-layer"), KO.above && this.dom.classList.add("cm-layer-above"), KO.class && this.dom.classList.add(KO.class), this.scale(), this.dom.setAttribute("aria-hidden", "true"), this.setOrder(OO.state), OO.requestMeasure(this.measureReq), KO.mount && KO.mount(this.dom, OO)
      }
      update(OO) {
        OO.startState.facet(qe) != OO.state.facet(qe) && this.setOrder(OO.state), (this.layer.update(OO, this.dom) || OO.geometryChanged) && (this.scale(), OO.view.requestMeasure(this.measureReq))
      }
      docViewUpdate(OO) {
        !1 !== this.layer.updateOnDocViewUpdate && OO.requestMeasure(this.measureReq)
      }
      setOrder(OO) {
        let KO = 0,
          pO = OO.facet(qe);
        for (; KO < pO.length && pO[KO] != this.layer;) KO++;
        this.dom.style.zIndex = String((this.layer.above ? 150 : -1) - KO)
      }
      measure() {
        return this.layer.markers(this.view)
      }
      scale() {
        let {
          scaleX: OO,
          scaleY: KO
        } = this.view;
        OO == this.scaleX && KO == this.scaleY || (this.scaleX = OO, this.scaleY = KO, this.dom.style.transform = `scale(${1/OO}, ${1/KO})`)
      }
      draw(OO) {
        if (OO.length != this.drawn.length || OO.some(((OO, KO) => {
            return pO = OO, XO = this.drawn[KO], !(pO.constructor == XO.constructor && pO.eq(XO));
            var pO, XO
          }))) {
          let KO = this.dom.firstChild,
            pO = 0;
          for (let XO of OO) XO.update && KO && XO.constructor && this.drawn[pO].constructor && XO.update(KO, this.drawn[pO]) ? (KO = KO.nextSibling, pO++) : this.dom.insertBefore(XO.draw(), KO);
          for (; KO;) {
            let OO = KO.nextSibling;
            KO.remove(), KO = OO
          }
          this.drawn = OO, NO.webkit && (this.dom.style.display = this.dom.firstChild ? "" : "none")
        }
      }
      destroy() {
        this.layer.destroy && this.layer.destroy(this.dom, this.view), this.dom.remove()
      }
    }
    const qe = XO.n.define();

    function xe(OO) {
      return [WK.define((KO => new Gb(KO, OO))), qe.of(OO)]
    }
    const nb = XO.n.define({
      combine: OO => (0, XO.T)(OO, {
        cursorBlinkRate: 1200,
        drawRangeCursor: !0,
        iosSelectionHandles: !0
      }, {
        cursorBlinkRate: (OO, KO) => Math.min(OO, KO),
        drawRangeCursor: (OO, KO) => OO || KO
      })
    });

    function Wb() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      return [nb.of(OO), ke, Oe, Ke, SK.of(!0)]
    }

    function te(OO) {
      return OO.startState.facet(nb) != OO.state.facet(nb)
    }
    const ke = xe({
      above: !0,
      markers(OO) {
        let {
          state: KO
        } = OO, pO = KO.facet(nb), bK = [];
        for (let eO of KO.selection.Xl) {
          let lO = eO == KO.selection.main;
          if (eO.empty || pO.drawRangeCursor && !(lO && NO.ios && pO.iosSelectionHandles)) {
            let KO = lO ? "cm-cursor cm-cursor-primary" : "cm-cursor cm-cursor-secondary",
              pO = eO.empty ? eO : XO.j.cursor(eO.head, eO.assoc);
            for (let XO of ce.forRange(OO, KO, pO)) bK.push(XO)
          }
        }
        return bK
      },
      update(OO, KO) {
        OO.transactions.some((OO => OO.selection)) && (KO.style.animationName = "cm-blink" == KO.style.animationName ? "cm-blink2" : "cm-blink");
        let pO = te(OO);
        return pO && Ub(OO.state, KO), OO.docChanged || OO.selectionSet || pO
      },
      mount(OO, KO) {
        Ub(KO.state, OO)
      },
      class: "cm-cursorLayer"
    });

    function Ub(OO, KO) {
      KO.style.animationDuration = OO.facet(nb).cursorBlinkRate + "ms"
    }
    const Oe = xe({
        above: !1,
        markers(OO) {
          let KO = [],
            {
              main: pO,
              Xl: bK
            } = OO.state.selection;
          for (let XO of bK)
            if (!XO.empty)
              for (let pO of ce.forRange(OO, "cm-selectionBackground", XO)) KO.push(pO);
          if (NO.ios && !pO.empty && OO.state.facet(nb).iosSelectionHandles) {
            for (let bK of ce.forRange(OO, "cm-selectionHandle cm-selectionHandle-start", XO.j.cursor(pO.from, 1))) KO.push(bK);
            for (let bK of ce.forRange(OO, "cm-selectionHandle cm-selectionHandle-end", XO.j.cursor(pO.to, 1))) KO.push(bK)
          }
          return KO
        },
        update: (OO, KO) => OO.docChanged || OO.selectionSet || OO.viewportChanged || te(OO),
        class: "cm-selectionLayer"
      }),
      Ke = XO.u.highest(ye.theme({
        ".cm-line": {
          "& ::selection, &::selection": {
            backgroundColor: "transparent !important"
          },
          caretColor: "transparent !important"
        },
        ".cm-content": {
          caretColor: "transparent !important",
          "& :focus": {
            caretColor: "initial !important",
            "&::selection, & ::selection": {
              backgroundColor: "Highlight !important"
            }
          }
        }
      })),
      pe = XO.C.define({
        map: (OO, KO) => null == OO ? null : KO.mapPos(OO)
      }),
      Xe = XO.G.define({
        create: () => null,
        update: (OO, KO) => (null != OO && (OO = KO.changes.mapPos(OO)), KO.effects.reduce(((OO, KO) => KO.is(pe) ? KO.value : OO), OO))
      }),
      bl = WK.fromClass(class {
        constructor(OO) {
          this.view = OO, this.cursor = null, this.measureReq = {
            read: this.readPos.bind(this),
            write: this.drawCursor.bind(this)
          }
        }
        update(OO) {
          var KO;
          let pO = OO.state.field(Xe);
          null == pO ? null != this.cursor && (null === (KO = this.cursor) || void 0 === KO || KO.remove(), this.cursor = null) : (this.cursor || (this.cursor = this.view.scrollDOM.appendChild(document.createElement("div")), this.cursor.className = "cm-dropCursor"), (OO.startState.field(Xe) != pO || OO.docChanged || OO.geometryChanged) && this.view.requestMeasure(this.measureReq))
        }
        readPos() {
          let {
            view: OO
          } = this, KO = OO.state.field(Xe), pO = null != KO && OO.coordsAtPos(KO);
          if (!pO) return null;
          let XO = OO.scrollDOM.getBoundingClientRect();
          return {
            left: pO.left - XO.left + OO.scrollDOM.scrollLeft * OO.scaleX,
            top: pO.top - XO.top + OO.scrollDOM.scrollTop * OO.scaleY,
            height: pO.bottom - pO.top
          }
        }
        drawCursor(OO) {
          if (this.cursor) {
            let {
              scaleX: KO,
              scaleY: pO
            } = this.view;
            OO ? (this.cursor.style.left = OO.left / KO + "px", this.cursor.style.top = OO.top / pO + "px", this.cursor.style.height = OO.height / pO + "px") : this.cursor.style.left = "-100000px"
          }
        }
        destroy() {
          this.cursor && this.cursor.remove()
        }
        setDropPos(OO) {
          this.view.state.field(Xe) != OO && this.view.dispatch({
            effects: pe.of(OO)
          })
        }
      }, {
        eventObservers: {
          dragover(OO) {
            this.setDropPos(this.view.posAtCoords({
              x: OO.clientX,
              y: OO.clientY
            }))
          },
          dragleave(OO) {
            OO.target != this.view.contentDOM && this.view.contentDOM.contains(OO.relatedTarget) || this.setDropPos(null)
          },
          dragend() {
            this.setDropPos(null)
          },
          drop() {
            this.setDropPos(null)
          }
        }
      });

    function ee() {
      return [Xe, bl]
    }

    function le(OO, KO, pO, XO, bK) {
      KO.lastIndex = 0;
      for (let eO, lO = OO.iterRange(pO, XO), vK = pO; !lO.next().done; vK += lO.value.length)
        if (!lO.lineBreak)
          for (; eO = KO.exec(lO.value);) bK(vK + eO.index, eO)
    }
    class vl {
      constructor(OO) {
        const {
          regexp: KO,
          decoration: pO,
          decorate: XO,
          boundary: bK,
          maxLength: eO = 1e3
        } = OO;
        if (!KO.global) throw new RangeError("The regular expression given to MatchDecorator should have its 'g' flag set");
        if (this.regexp = KO, XO) this.addMatch = (OO, KO, pO, bK) => XO(bK, pO, pO + OO[0].length, OO, KO);
        else if ("function" == typeof pO) this.addMatch = (OO, KO, XO, bK) => {
          let eO = pO(OO, KO, XO);
          eO && bK(XO, XO + OO[0].length, eO)
        };
        else {
          if (!pO) throw new RangeError("Either 'decorate' or 'decoration' should be provided to MatchDecorator");
          this.addMatch = (OO, KO, XO, bK) => bK(XO, XO + OO[0].length, pO)
        }
        this.boundary = bK, this.maxLength = eO
      }
      createDeco(OO) {
        let KO = new XO.v,
          pO = KO.add.bind(KO);
        for (let {
            from: XO,
            to: bK
          }
          of
          function(OO, KO) {
            let pO = OO.yvO;
            if (1 == pO.length && pO[0].from == OO.viewport.from && pO[0].to == OO.viewport.to) return pO;
            let XO = [];
            for (let {
                from: bK,
                to: eO
              }
              of pO) bK = Math.max(OO.state.doc.lineAt(bK).from, bK - KO), eO = Math.min(OO.state.doc.lineAt(eO).to, eO + KO), XO.length && XO[XO.length - 1].to >= bK ? XO[XO.length - 1].to = eO : XO.push({
              from: bK,
              to: eO
            });
            return XO
          }(OO, this.maxLength)) le(OO.state.doc, this.regexp, XO, bK, ((KO, XO) => this.addMatch(XO, OO, KO, pO)));
        return KO.finish()
      }
      updateDeco(OO, KO) {
        let pO = 1e9,
          XO = -1;
        return OO.docChanged && OO.changes.iterChanges(((KO, bK, eO, lO) => {
          lO >= OO.view.viewport.from && eO <= OO.view.viewport.to && (pO = Math.min(eO, pO), XO = Math.max(lO, XO))
        })), OO.viewportMoved || XO - pO > 1e3 ? this.createDeco(OO.view) : XO > -1 ? this.updateRange(OO.view, KO.map(OO.changes), pO, XO) : KO
      }
      updateRange(OO, KO, pO, XO) {
        for (let bK of OO.yvO) {
          let eO = Math.max(bK.from, pO),
            lO = Math.min(bK.to, XO);
          if (lO >= eO) {
            let pO = OO.state.doc.lineAt(eO),
              XO = pO.to < lO ? OO.state.doc.lineAt(lO) : pO,
              vK = Math.max(bK.from, pO.from),
              CO = Math.min(bK.to, XO.to);
            if (this.boundary) {
              for (; eO > pO.from; eO--)
                if (this.boundary.test(pO.text[eO - 1 - pO.from])) {
                  vK = eO;
                  break
                } for (; lO < XO.to; lO++)
                if (this.boundary.test(XO.text[lO - XO.from])) {
                  CO = lO;
                  break
                }
            }
            let hO, DO = [],
              MO = (OO, KO, pO) => DO.push(pO.range(OO, KO));
            if (pO == XO)
              for (this.regexp.lastIndex = vK - pO.from;
                (hO = this.regexp.exec(pO.text)) && hO.index < CO - pO.from;) this.addMatch(hO, OO, hO.index + pO.from, MO);
            else le(OO.state.doc, this.regexp, vK, CO, ((KO, pO) => this.addMatch(pO, OO, KO, MO)));
            KO = KO.update({
              filterFrom: vK,
              filterTo: CO,
              filter: (OO, KO) => OO < vK || KO > CO,
              add: DO
            })
          }
        }
        return KO
      }
    }
    const Ce = null != /x/.unicode ? "gu" : "g",
      he = new RegExp("[\0-\b\n-\x1f\x7f-\x9f\xad\u061c\u200b\u200e\u200f\u2028\u2029\u202d\u202e\u2066\u2067\u2069\ufeff\ufff9-\ufffc]", Ce),
      De = {
        0: "null",
        7: "bell",
        8: "backspace",
        10: "newline",
        11: "vertical tab",
        13: "carriage return",
        27: "escape",
        8203: "zero width space",
        8204: "zero width non-joiner",
        8205: "zero width joiner",
        8206: "left-to-right mark",
        8207: "right-to-left mark",
        8232: "line separator",
        8237: "left-to-right override",
        8238: "right-to-left override",
        8294: "left-to-right isolate",
        8295: "right-to-left isolate",
        8297: "pop directional isolate",
        8233: "paragraph separator",
        65279: "zero width no-break space",
        65532: "object replacement"
      };
    let Me = null;
    const al = XO.n.define({
      combine(OO) {
        let KO = (0, XO.T)(OO, {
          render: null,
          specialChars: he,
          addSpecialChars: null
        });
        return (KO.replaceTabs = ! function() {
          var OO;
          if (null == Me && "undefined" != typeof document && document.body) {
            let KO = document.body.style;
            Me = null != (null !== (OO = KO.tabSize) && void 0 !== OO ? OO : KO.MozTabSize)
          }
          return Me || !1
        }()) && (KO.specialChars = new RegExp("\t|" + KO.specialChars.source, Ce)), KO.addSpecialChars && (KO.specialChars = new RegExp(KO.specialChars.source + "|" + KO.addSpecialChars.source, Ce)), KO
      }
    });

    function oe() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      return [al.of(OO), Fe || (Fe = WK.fromClass(class {
        constructor(OO) {
          this.view = OO, this.ql = wO.none, this.decorationCache = Object.create(null), this.decorator = this.makeDecorator(OO.state.facet(al)), this.ql = this.decorator.createDeco(OO)
        }
        makeDecorator(OO) {
          return new vl({
            regexp: OO.specialChars,
            decoration: (KO, pO, bK) => {
              let {
                doc: eO
              } = pO.state, lO = (0, XO.N)(KO[0], 0);
              if (9 == lO) {
                let OO = eO.lineAt(bK),
                  KO = pO.state.tabSize,
                  lO = (0, XO.U)(OO.text, KO, bK - OO.from);
                return wO.replace({
                  widget: new Le((KO - lO % KO) * this.view.defaultCharacterWidth / this.view.scaleX)
                })
              }
              return this.decorationCache[lO] || (this.decorationCache[lO] = wO.replace({
                widget: new Ve(OO, lO)
              }))
            },
            boundary: OO.replaceTabs ? void 0 : /[^]/
          })
        }
        update(OO) {
          let KO = OO.state.facet(al);
          OO.startState.facet(al) != KO ? (this.decorator = this.makeDecorator(KO), this.ql = this.decorator.createDeco(OO.view)) : this.ql = this.decorator.updateDeco(OO, this.ql)
        }
      }, {
        ql: OO => OO.ql
      }))]
    }
    let Fe = null;
    class Ve extends jK {
      constructor(OO, KO) {
        super(), this.options = OO, this.code = KO
      }
      eq(OO) {
        return OO.code == this.code
      }
      toDOM(OO) {
        let KO = function(OO) {
            return OO >= 32 ? "\u2022" : 10 == OO ? "\u2424" : String.fromCharCode(9216 + OO)
          }(this.code),
          pO = OO.state.phrase("Control character") + " " + (De[this.code] || "0x" + this.code.toString(16)),
          XO = this.options.render && this.options.render(this.code, pO, KO);
        if (XO) return XO;
        let bK = document.createElement("span");
        return bK.textContent = KO, bK.title = pO, bK.setAttribute("aria-label", pO), bK.className = "cm-specialChar", bK
      }
      ignoreEvent() {
        return !1
      }
    }
    class Le extends jK {
      constructor(OO) {
        super(), this.width = OO
      }
      eq(OO) {
        return OO.width == this.width
      }
      toDOM() {
        let OO = document.createElement("span");
        return OO.textContent = "\t", OO.className = "cm-tab", OO.style.width = this.width + "px", OO
      }
      ignoreEvent() {
        return !1
      }
    }

    function Qe() {
      return Ae
    }
    const zl = wO.line({
        class: "cm-activeLine"
      }),
      Ae = WK.fromClass(class {
        constructor(OO) {
          this.ql = this.getDeco(OO)
        }
        update(OO) {
          (OO.docChanged || OO.selectionSet) && (this.ql = this.getDeco(OO.view))
        }
        getDeco(OO) {
          let KO = -1,
            pO = [];
          for (let XO of OO.state.selection.Xl) {
            let bK = OO.lineBlockAt(XO.head);
            bK.from > KO && (pO.push(zl.range(bK.from)), KO = bK.from)
          }
          return wO.set(pO)
        }
      }, {
        ql: OO => OO.ql
      });
    class fe extends jK {
      constructor(OO) {
        super(), this.content = OO
      }
      toDOM(OO) {
        let KO = document.createElement("span");
        return KO.className = "cm-placeholder", KO.style.pointerEvents = "none", KO.appendChild("string" == typeof this.content ? document.createTextNode(this.content) : "function" == typeof this.content ? this.content(OO) : this.content.cloneNode(!0)), KO.setAttribute("aria-hidden", "true"), KO
      }
      coordsAt(OO) {
        let KO = OO.firstChild ? cK(OO.firstChild) : [];
        if (!KO.length) return null;
        let pO = window.getComputedStyle(OO.parentNode),
          XO = nO(KO[0], "rtl" != pO.direction),
          bK = parseInt(pO.lineHeight);
        return XO.bottom - XO.top > 1.5 * bK ? {
          left: XO.left,
          right: XO.right,
          top: XO.top,
          bottom: XO.top + bK
        } : XO
      }
      ignoreEvent() {
        return !1
      }
    }

    function de(OO) {
      let KO = WK.fromClass(class {
        constructor(KO) {
          this.view = KO, this.placeholder = OO ? wO.set([wO.widget({
            widget: new fe(OO),
            side: 1
          }).range(0)]) : wO.none
        }
        get ql() {
          return this.view.state.doc.length ? wO.none : this.placeholder
        }
      }, {
        ql: OO => OO.ql
      });
      return "string" == typeof OO ? [KO, ye.contentAttributes.of({
        "aria-placeholder": OO
      })] : KO
    }
    const Te = 2e3;

    function Ne(OO, KO) {
      let pO = OO.posAtCoords({
          x: KO.clientX,
          y: KO.clientY
        }, !1),
        bK = OO.state.doc.lineAt(pO),
        eO = pO - bK.from,
        lO = eO > Te ? -1 : eO == bK.length ? function(OO, KO) {
          let pO = OO.coordsAtPos(OO.viewport.from);
          return pO ? Math.round(Math.abs((pO.left - KO) / OO.defaultCharacterWidth)) : -1
        }(OO, KO.clientX) : (0, XO.U)(bK.text, OO.state.tabSize, pO - bK.from);
      return {
        line: bK.number,
        col: lO,
        off: eO
      }
    }

    function Ie(OO, KO) {
      let pO = Ne(OO, KO),
        bK = OO.state.selection;
      return pO ? {
        update(OO) {
          if (OO.docChanged) {
            let KO = OO.changes.mapPos(OO.startState.doc.line(pO.line).from),
              XO = OO.state.doc.lineAt(KO);
            pO = {
              line: XO.number,
              col: pO.col,
              off: Math.min(pO.off, XO.length)
            }, bK = bK.map(OO.changes)
          }
        },
        get(KO, eO, lO) {
          let vK = Ne(OO, KO);
          if (!vK) return bK;
          let CO = function(OO, KO, pO) {
            let bK = Math.min(KO.line, pO.line),
              eO = Math.max(KO.line, pO.line),
              lO = [];
            if (KO.off > Te || pO.off > Te || KO.col < 0 || pO.col < 0) {
              let vK = Math.min(KO.off, pO.off),
                CO = Math.max(KO.off, pO.off);
              for (let KO = bK; KO <= eO; KO++) {
                let pO = OO.doc.line(KO);
                pO.length <= CO && lO.push(XO.j.range(pO.from + vK, pO.to + CO))
              }
            } else {
              let vK = Math.min(KO.col, pO.col),
                CO = Math.max(KO.col, pO.col);
              for (let KO = bK; KO <= eO; KO++) {
                let pO = OO.doc.line(KO),
                  bK = (0, XO._)(pO.text, vK, OO.tabSize, !0);
                if (bK < 0) lO.push(XO.j.cursor(pO.to));
                else {
                  let KO = (0, XO._)(pO.text, CO, OO.tabSize);
                  lO.push(XO.j.range(pO.from + bK, pO.from + KO))
                }
              }
            }
            return lO
          }(OO.state, pO, vK);
          return CO.length ? lO ? XO.j.create(CO.concat(bK.Xl)) : XO.j.create(CO) : bK
        }
      } : null
    }

    function yl(OO) {
      let KO = (null === OO || void 0 === OO ? void 0 : OO.eventFilter) || (OO => OO.altKey && 0 == OO.button);
      return ye.mouseSelectionStyle.of(((OO, pO) => KO(pO) ? Ie(OO, pO) : null))
    }
    const gl = {
        Alt: [18, OO => !!OO.altKey],
        Control: [17, OO => !!OO.ctrlKey],
        Shift: [16, OO => !!OO.shiftKey],
        Meta: [91, OO => !!OO.metaKey]
      },
      ue = {
        style: "cursor: crosshair"
      };

    function Ee() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        [KO, pO] = gl[OO.key || "Alt"],
        XO = WK.fromClass(class {
          constructor(OO) {
            this.view = OO, this.isDown = !1
          }
          set(OO) {
            this.isDown != OO && (this.isDown = OO, this.view.update([]))
          }
        }, {
          eventObservers: {
            keydown(OO) {
              this.set(OO.keyCode == KO || pO(OO))
            },
            keyup(OO) {
              OO.keyCode != KO && pO(OO) || this.set(!1)
            },
            mousemove(OO) {
              this.set(pO(OO))
            }
          }
        });
      return [XO, ye.contentAttributes.of((OO => {
        var KO;
        return (null === (KO = OO.plugin(XO)) || void 0 === KO ? void 0 : KO.isDown) ? ue : null
      }))]
    }
    const jl = "-10000px";
    class Ye {
      constructor(OO, KO, pO, XO) {
        this.facet = KO, this.createTooltipView = pO, this.removeTooltipView = XO, this.input = OO.state.facet(KO), this.tooltips = this.input.filter((OO => OO));
        let bK = null;
        this.tooltipViews = this.tooltips.map((OO => bK = pO(OO, bK)))
      }
      update(OO, KO) {
        var pO;
        let XO = OO.state.facet(this.facet),
          bK = XO.filter((OO => OO));
        if (XO === this.input) {
          for (let KO of this.tooltipViews) KO.update && KO.update(OO);
          return !1
        }
        let eO = [],
          lO = KO ? [] : null;
        for (let vK = 0; vK < bK.length; vK++) {
          let pO = bK[vK],
            XO = -1;
          if (pO) {
            for (let OO = 0; OO < this.tooltips.length; OO++) {
              let KO = this.tooltips[OO];
              KO && KO.create == pO.create && (XO = OO)
            }
            if (XO < 0) eO[vK] = this.createTooltipView(pO, vK ? eO[vK - 1] : null), lO && (lO[vK] = !!pO.above);
            else {
              let pO = eO[vK] = this.tooltipViews[XO];
              lO && (lO[vK] = KO[XO]), pO.update && pO.update(OO)
            }
          }
        }
        for (let vK of this.tooltipViews) eO.indexOf(vK) < 0 && (this.removeTooltipView(vK), null === (pO = vK.destroy) || void 0 === pO || pO.call(vK));
        return KO && (lO.forEach(((OO, pO) => KO[pO] = OO)), KO.length = lO.length), this.input = XO, this.tooltips = bK, this.tooltipViews = eO, !0
      }
    }

    function we(OO) {
      let KO = OO.dom.ownerDocument.documentElement;
      return {
        top: 0,
        left: 0,
        bottom: KO.clientHeight,
        right: KO.clientWidth
      }
    }
    const il = XO.n.define({
        combine: OO => {
          var KO, pO, XO;
          return {
            position: NO.ios ? "absolute" : (null === (KO = OO.find((OO => OO.position))) || void 0 === KO ? void 0 : KO.position) || "fixed",
            parent: (null === (pO = OO.find((OO => OO.parent))) || void 0 === pO ? void 0 : pO.parent) || null,
            tooltipSpace: (null === (XO = OO.find((OO => OO.tooltipSpace))) || void 0 === XO ? void 0 : XO.tooltipSpace) || we
          }
        }
      }),
      rl = new WeakMap,
      Pe = WK.fromClass(class {
        constructor(OO) {
          this.view = OO, this.above = [], this.inView = !0, this.madeAbsolute = !1, this.lastTransaction = 0, this.measureTimeout = -1;
          let KO = OO.state.facet(il);
          this.position = KO.position, this.parent = KO.parent, this.classes = OO.themeClasses, this.createContainer(), this.measureReq = {
            read: this.readMeasure.bind(this),
            write: this.writeMeasure.bind(this),
            key: this
          }, this.resizeObserver = "function" == typeof ResizeObserver ? new ResizeObserver((() => this.measureSoon())) : null, this.manager = new Ye(OO, Re, ((OO, KO) => this.createTooltip(OO, KO)), (OO => {
            this.resizeObserver && this.resizeObserver.unobserve(OO.dom), OO.dom.remove()
          })), this.above = this.manager.tooltips.map((OO => !!OO.above)), this.intersectionObserver = "function" == typeof IntersectionObserver ? new IntersectionObserver((OO => {
            Date.now() > this.lastTransaction - 50 && OO.length > 0 && OO[OO.length - 1].intersectionRatio < 1 && this.measureSoon()
          }), {
            threshold: [1]
          }) : null, this.observeIntersection(), OO.win.addEventListener("resize", this.measureSoon = this.measureSoon.bind(this)), this.maybeMeasure()
        }
        createContainer() {
          this.parent ? (this.container = document.createElement("div"), this.container.style.position = "relative", this.container.className = this.view.themeClasses, this.parent.appendChild(this.container)) : this.container = this.view.dom
        }
        observeIntersection() {
          if (this.intersectionObserver) {
            this.intersectionObserver.disconnect();
            for (let OO of this.manager.tooltipViews) this.intersectionObserver.observe(OO.dom)
          }
        }
        measureSoon() {
          this.measureTimeout < 0 && (this.measureTimeout = setTimeout((() => {
            this.measureTimeout = -1, this.maybeMeasure()
          }), 50))
        }
        update(OO) {
          OO.transactions.length && (this.lastTransaction = Date.now());
          let KO = this.manager.update(OO, this.above);
          KO && this.observeIntersection();
          let pO = KO || OO.geometryChanged,
            XO = OO.state.facet(il);
          if (XO.position != this.position && !this.madeAbsolute) {
            this.position = XO.position;
            for (let OO of this.manager.tooltipViews) OO.dom.style.position = this.position;
            pO = !0
          }
          if (XO.parent != this.parent) {
            this.parent && this.container.remove(), this.parent = XO.parent, this.createContainer();
            for (let OO of this.manager.tooltipViews) this.container.appendChild(OO.dom);
            pO = !0
          } else this.parent && this.view.themeClasses != this.classes && (this.classes = this.container.className = this.view.themeClasses);
          pO && this.maybeMeasure()
        }
        createTooltip(OO, KO) {
          let pO = OO.create(this.view),
            XO = KO ? KO.dom : null;
          if (pO.dom.classList.add("cm-tooltip"), OO.arrow && !pO.dom.querySelector(".cm-tooltip > .cm-tooltip-arrow")) {
            let OO = document.createElement("div");
            OO.className = "cm-tooltip-arrow", pO.dom.appendChild(OO)
          }
          return pO.dom.style.position = this.position, pO.dom.style.top = jl, pO.dom.style.left = "0px", this.container.insertBefore(pO.dom, XO), pO.mount && pO.mount(this.view), this.resizeObserver && this.resizeObserver.observe(pO.dom), pO
        }
        destroy() {
          var OO, KO, pO;
          this.view.win.removeEventListener("resize", this.measureSoon);
          for (let XO of this.manager.tooltipViews) XO.dom.remove(), null === (OO = XO.destroy) || void 0 === OO || OO.call(XO);
          this.parent && this.container.remove(), null === (KO = this.resizeObserver) || void 0 === KO || KO.disconnect(), null === (pO = this.intersectionObserver) || void 0 === pO || pO.disconnect(), clearTimeout(this.measureTimeout)
        }
        readMeasure() {
          let OO = 1,
            KO = 1,
            pO = !1;
          if ("fixed" == this.position && this.manager.tooltipViews.length) {
            let {
              dom: OO
            } = this.manager.tooltipViews[0];
            if (NO.safari) {
              let KO = OO.getBoundingClientRect();
              pO = Math.abs(KO.top + 1e4) > 1 || Math.abs(KO.left) > 1
            } else pO = !!OO.offsetParent && OO.offsetParent != this.container.ownerDocument.body
          }
          if (pO || "absolute" == this.position)
            if (this.parent) {
              let pO = this.parent.getBoundingClientRect();
              pO.width && pO.height && (OO = pO.width / this.parent.offsetWidth, KO = pO.height / this.parent.offsetHeight)
            } else({
              scaleX: OO,
              scaleY: KO
            } = this.view.viewState);
          let XO = this.view.scrollDOM.getBoundingClientRect(),
            bK = vX(this.view);
          return {
            visible: {
              left: XO.left + bK.left,
              top: XO.top + bK.top,
              right: XO.right - bK.right,
              bottom: XO.bottom - bK.bottom
            },
            parent: this.parent ? this.container.getBoundingClientRect() : this.view.dom.getBoundingClientRect(),
            pos: this.manager.tooltips.map(((OO, KO) => {
              let pO = this.manager.tooltipViews[KO];
              return pO.getCoords ? pO.getCoords(OO.pos) : this.view.coordsAtPos(OO.pos)
            })),
            size: this.manager.tooltipViews.map((OO => {
              let {
                dom: KO
              } = OO;
              return KO.getBoundingClientRect()
            })),
            space: this.view.state.facet(il).tooltipSpace(this.view),
            scaleX: OO,
            scaleY: KO,
            makeAbsolute: pO
          }
        }
        writeMeasure(OO) {
          var KO;
          if (OO.makeAbsolute) {
            this.madeAbsolute = !0, this.position = "absolute";
            for (let OO of this.manager.tooltipViews) OO.dom.style.position = "absolute"
          }
          let {
            visible: pO,
            space: XO,
            scaleX: bK,
            scaleY: eO
          } = OO, lO = [];
          for (let vK = 0; vK < this.manager.tooltips.length; vK++) {
            let CO = this.manager.tooltips[vK],
              hO = this.manager.tooltipViews[vK],
              {
                dom: DO
              } = hO,
              MO = OO.pos[vK],
              aK = OO.size[vK];
            if (!MO || !1 !== CO.clip && (MO.bottom <= Math.max(pO.top, XO.top) || MO.top >= Math.min(pO.bottom, XO.bottom) || MO.right < Math.max(pO.left, XO.left) - .1 || MO.left > Math.min(pO.right, XO.right) + .1)) {
              DO.style.top = jl;
              continue
            }
            let oO = CO.arrow ? hO.dom.querySelector(".cm-tooltip-arrow") : null,
              FO = oO ? 7 : 0,
              VO = aK.right - aK.left,
              LO = null !== (KO = rl.get(hO)) && void 0 !== KO ? KO : aK.bottom - aK.top,
              QO = hO.offset || He,
              zK = this.view.textDirection == hK.LTR,
              AO = aK.width > XO.right - XO.left ? zK ? XO.left : XO.right - aK.width : zK ? Math.max(XO.left, Math.min(MO.left - (oO ? 14 : 0) + QO.x, XO.right - VO)) : Math.min(Math.max(XO.left, MO.left - VO + (oO ? 14 : 0) - QO.x), XO.right - VO),
              fO = this.above[vK];
            !CO.strictSide && (fO ? MO.top - LO - FO - QO.y < XO.top : MO.bottom + LO + FO + QO.y > XO.bottom) && fO == XO.bottom - MO.bottom > MO.top - XO.top && (fO = this.above[vK] = !fO);
            let dO = (fO ? MO.top - XO.top : XO.bottom - MO.bottom) - FO;
            if (dO < LO && !1 !== hO.resize) {
              if (dO < this.view.defaultLineHeight) {
                DO.style.top = jl;
                continue
              }
              rl.set(hO, LO), DO.style.height = (LO = dO) / eO + "px"
            } else DO.style.height && (DO.style.height = "");
            let TO = fO ? MO.top - LO - FO - QO.y : MO.bottom + FO + QO.y,
              NO = AO + VO;
            if (!0 !== hO.overlap)
              for (let OO of lO) OO.left < NO && OO.right > AO && OO.top < TO + LO && OO.bottom > TO && (TO = fO ? OO.top - LO - 2 - FO : OO.bottom + FO + 2);
            if ("absolute" == this.position ? (DO.style.top = (TO - OO.parent.top) / eO + "px", ml(DO, (AO - OO.parent.left) / bK)) : (DO.style.top = TO / eO + "px", ml(DO, AO / bK)), oO) {
              let OO = MO.left + (zK ? QO.x : -QO.x) - (AO + 14 - 7);
              oO.style.left = OO / bK + "px"
            }!0 !== hO.overlap && lO.push({
              left: AO,
              top: TO,
              right: NO,
              bottom: TO + LO
            }), DO.classList.toggle("cm-tooltip-above", fO), DO.classList.toggle("cm-tooltip-below", !fO), hO.positioned && hO.positioned(OO.space)
          }
        }
        maybeMeasure() {
          if (this.manager.tooltips.length && (this.view.inView && this.view.requestMeasure(this.measureReq), this.inView != this.view.inView && (this.inView = this.view.inView, !this.inView)))
            for (let OO of this.manager.tooltipViews) OO.dom.style.top = jl
        }
      }, {
        eventObservers: {
          scroll() {
            this.maybeMeasure()
          }
        }
      });

    function ml(OO, KO) {
      let pO = parseInt(OO.style.left, 10);
      (isNaN(pO) || Math.abs(KO - pO) > 1) && (OO.style.left = KO + "px")
    }
    const se = ye.baseTheme({
        ".cm-tooltip": {
          zIndex: 500,
          boxSizing: "border-box"
        },
        "&light .cm-tooltip": {
          border: "1px solid #bbb",
          backgroundColor: "#f5f5f5"
        },
        "&light .cm-tooltip-section:not(:first-child)": {
          borderTop: "1px solid #bbb"
        },
        "&dark .cm-tooltip": {
          backgroundColor: "#333338",
          color: "white"
        },
        ".cm-tooltip-arrow": {
          height: "7px",
          width: "14px",
          position: "absolute",
          zIndex: -1,
          overflow: "hidden",
          "&:before, &:after": {
            content: "''",
            position: "absolute",
            width: 0,
            height: 0,
            borderLeft: "7px solid transparent",
            borderRight: "7px solid transparent"
          },
          ".cm-tooltip-above &": {
            bottom: "-7px",
            "&:before": {
              borderTop: "7px solid #bbb"
            },
            "&:after": {
              borderTop: "7px solid #f5f5f5",
              bottom: "1px"
            }
          },
          ".cm-tooltip-below &": {
            top: "-7px",
            "&:before": {
              borderBottom: "7px solid #bbb"
            },
            "&:after": {
              borderBottom: "7px solid #f5f5f5",
              top: "1px"
            }
          }
        },
        "&dark .cm-tooltip .cm-tooltip-arrow": {
          "&:before": {
            borderTopColor: "#333338",
            borderBottomColor: "#333338"
          },
          "&:after": {
            borderTopColor: "transparent",
            borderBottomColor: "transparent"
          }
        }
      }),
      He = {
        x: 0,
        y: 0
      },
      Re = XO.n.define({
        enables: [Pe, se]
      }),
      Se = XO.n.define({
        combine: OO => OO.reduce(((OO, KO) => OO.concat(KO)), [])
      });
    class Je {
      static create(OO) {
        return new Je(OO)
      }
      constructor(OO) {
        this.view = OO, this.mounted = !1, this.dom = document.createElement("div"), this.dom.classList.add("cm-tooltip-hover"), this.manager = new Ye(OO, Se, ((OO, KO) => this.createHostedView(OO, KO)), (OO => OO.dom.remove()))
      }
      createHostedView(OO, KO) {
        let pO = OO.create(this.view);
        return pO.dom.classList.add("cm-tooltip-section"), this.dom.insertBefore(pO.dom, KO ? KO.dom.nextSibling : this.dom.firstChild), this.mounted && pO.mount && pO.mount(this.view), pO
      }
      mount(OO) {
        for (let KO of this.manager.tooltipViews) KO.mount && KO.mount(OO);
        this.mounted = !0
      }
      positioned(OO) {
        for (let KO of this.manager.tooltipViews) KO.positioned && KO.positioned(OO)
      }
      update(OO) {
        this.manager.update(OO)
      }
      destroy() {
        var OO;
        for (let KO of this.manager.tooltipViews) null === (OO = KO.destroy) || void 0 === OO || OO.call(KO)
      }
      passProp(OO) {
        let KO;
        for (let pO of this.manager.tooltipViews) {
          let XO = pO[OO];
          if (void 0 !== XO)
            if (void 0 === KO) KO = XO;
            else if (KO !== XO) return
        }
        return KO
      }
      get offset() {
        return this.passProp("offset")
      }
      get getCoords() {
        return this.passProp("getCoords")
      }
      get overlap() {
        return this.passProp("overlap")
      }
      get resize() {
        return this.passProp("resize")
      }
    }
    const cl = Re.compute([Se], (OO => {
      let KO = OO.facet(Se);
      return 0 === KO.length ? null : {
        pos: Math.min(...KO.map((OO => OO.pos))),
        end: Math.max(...KO.map((OO => {
          var KO;
          return null !== (KO = OO.end) && void 0 !== KO ? KO : OO.pos
        }))),
        create: Je.create,
        above: KO[0].above,
        arrow: KO.some((OO => OO.arrow))
      }
    }));
    class Be {
      constructor(OO, KO, pO, XO, bK) {
        this.view = OO, this.source = KO, this.field = pO, this.setHover = XO, this.hoverTime = bK, this.hoverTimeout = -1, this.restartTimeout = -1, this.pending = null, this.lastMove = {
          x: 0,
          y: 0,
          target: OO.dom,
          time: 0
        }, this.checkHover = this.checkHover.bind(this), OO.dom.addEventListener("mouseleave", this.mouseleave = this.mouseleave.bind(this)), OO.dom.addEventListener("mousemove", this.mousemove = this.mousemove.bind(this))
      }
      update() {
        this.pending && (this.pending = null, clearTimeout(this.restartTimeout), this.restartTimeout = setTimeout((() => this.startHover()), 20))
      }
      get active() {
        return this.view.state.field(this.field)
      }
      checkHover() {
        if (this.hoverTimeout = -1, this.active.length) return;
        let OO = Date.now() - this.lastMove.time;
        OO < this.hoverTime ? this.hoverTimeout = setTimeout(this.checkHover, this.hoverTime - OO) : this.startHover()
      }
      startHover() {
        clearTimeout(this.restartTimeout);
        let {
          view: OO,
          lastMove: KO
        } = this, pO = OO.docView.tile.nearest(KO.target);
        if (!pO) return;
        let XO, bK = 1;
        if (pO.isWidget()) XO = pO.posAtStart;
        else {
          if (XO = OO.posAtCoords(KO), null == XO) return;
          let pO = OO.coordsAtPos(XO);
          if (!pO || KO.y < pO.top || KO.y > pO.bottom || KO.x < pO.left - OO.defaultCharacterWidth || KO.x > pO.right + OO.defaultCharacterWidth) return;
          let eO = OO.bidiSpans(OO.state.doc.lineAt(XO)).find((OO => OO.from <= XO && OO.to >= XO)),
            lO = eO && eO.dir == hK.RTL ? -1 : 1;
          bK = KO.x < pO.left ? -lO : lO
        }
        let eO = this.source(OO, XO, bK);
        if (null === eO || void 0 === eO ? void 0 : eO.then) {
          let KO = this.pending = {
            pos: XO
          };
          eO.then((pO => {
            this.pending == KO && (this.pending = null, !pO || Array.isArray(pO) && !pO.length || OO.dispatch({
              effects: this.setHover.of(Array.isArray(pO) ? pO : [pO])
            }))
          }), (KO => GK(OO.state, KO, "hover tooltip")))
        } else !eO || Array.isArray(eO) && !eO.length || OO.dispatch({
          effects: this.setHover.of(Array.isArray(eO) ? eO : [eO])
        })
      }
      get tooltip() {
        let OO = this.view.plugin(Pe),
          KO = OO ? OO.manager.tooltips.findIndex((OO => OO.create == Je.create)) : -1;
        return KO > -1 ? OO.manager.tooltipViews[KO] : null
      }
      mousemove(OO) {
        var KO, pO;
        this.lastMove = {
          x: OO.clientX,
          y: OO.clientY,
          target: OO.target,
          time: Date.now()
        }, this.hoverTimeout < 0 && (this.hoverTimeout = setTimeout(this.checkHover, this.hoverTime));
        let {
          active: XO,
          tooltip: bK
        } = this;
        if (XO.length && bK && ! function(OO, KO) {
            let pO, {
              left: XO,
              right: bK,
              top: eO,
              bottom: lO
            } = OO.getBoundingClientRect();
            if (pO = OO.querySelector(".cm-tooltip-arrow")) {
              let OO = pO.getBoundingClientRect();
              eO = Math.min(OO.top, eO), lO = Math.max(OO.bottom, lO)
            }
            return KO.clientX >= XO - Ze && KO.clientX <= bK + Ze && KO.clientY >= eO - Ze && KO.clientY <= lO + Ze
          }(bK.dom, OO) || this.pending) {
          let {
            pos: bK
          } = XO[0] || this.pending, eO = null !== (pO = null === (KO = XO[0]) || void 0 === KO ? void 0 : KO.end) && void 0 !== pO ? pO : bK;
          (bK == eO ? this.view.posAtCoords(this.lastMove) == bK : function(OO, KO, pO, XO, bK) {
            let eO = OO.scrollDOM.getBoundingClientRect(),
              lO = OO.documentTop + OO.documentPadding.top + OO.contentHeight;
            if (eO.left > XO || eO.right < XO || eO.top > bK || Math.min(eO.bottom, lO) < bK) return !1;
            let vK = OO.posAtCoords({
              x: XO,
              y: bK
            }, !1);
            return vK >= KO && vK <= pO
          }(this.view, bK, eO, OO.clientX, OO.clientY)) || (this.view.dispatch({
            effects: this.setHover.of([])
          }), this.pending = null)
        }
      }
      mouseleave(OO) {
        clearTimeout(this.hoverTimeout), this.hoverTimeout = -1;
        let {
          active: KO
        } = this;
        if (KO.length) {
          let {
            tooltip: KO
          } = this;
          KO && KO.dom.contains(OO.relatedTarget) ? this.watchTooltipLeave(KO.dom) : this.view.dispatch({
            effects: this.setHover.of([])
          })
        }
      }
      watchTooltipLeave(OO) {
        let KO = pO => {
          OO.removeEventListener("mouseleave", KO), this.active.length && !this.view.dom.contains(pO.relatedTarget) && this.view.dispatch({
            effects: this.setHover.of([])
          })
        };
        OO.addEventListener("mouseleave", KO)
      }
      destroy() {
        clearTimeout(this.hoverTimeout), clearTimeout(this.restartTimeout), this.view.dom.removeEventListener("mouseleave", this.mouseleave), this.view.dom.removeEventListener("mousemove", this.mousemove)
      }
    }
    const Ze = 4;

    function Ge(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        pO = XO.C.define(),
        bK = XO.G.define({
          create: () => [],
          update(OO, bK) {
            if (OO.length && (KO.hideOnChange && (bK.docChanged || bK.selection) ? OO = [] : KO.hideOn && (OO = OO.filter((OO => !KO.hideOn(bK, OO)))), bK.docChanged)) {
              let KO = [];
              for (let pO of OO) {
                let OO = bK.changes.mapPos(pO.pos, -1, XO.r.TrackDel);
                if (null != OO) {
                  let XO = Object.assign(Object.create(null), pO);
                  XO.pos = OO, null != XO.end && (XO.end = bK.changes.mapPos(XO.end)), KO.push(XO)
                }
              }
              OO = KO
            }
            for (let KO of bK.effects) KO.is(pO) && (OO = KO.value), KO.is(xl) && (OO = []);
            return OO
          },
          provide: OO => Se.from(OO)
        });
      return {
        active: bK,
        extension: [bK, WK.define((XO => new Be(XO, OO, bK, pO, KO.hoverTime || 300))), cl]
      }
    }

    function ql(OO, KO) {
      let pO = OO.plugin(Pe);
      if (!pO) return null;
      let XO = pO.manager.tooltips.indexOf(KO);
      return XO < 0 ? null : pO.manager.tooltipViews[XO]
    }
    const xl = XO.C.define();
    const ne = XO.n.define({
      combine(OO) {
        let KO, pO;
        for (let XO of OO) KO = KO || XO.topContainer, pO = pO || XO.bottomContainer;
        return {
          topContainer: KO,
          bottomContainer: pO
        }
      }
    });

    function We(OO, KO) {
      let pO = OO.plugin(tl),
        XO = pO ? pO.specs.indexOf(KO) : -1;
      return XO > -1 ? pO.panels[XO] : null
    }
    const tl = WK.fromClass(class {
      constructor(OO) {
        this.input = OO.state.facet(Ol), this.specs = this.input.filter((OO => OO)), this.panels = this.specs.map((KO => KO(OO)));
        let KO = OO.state.facet(ne);
        this.top = new kl(OO, !0, KO.topContainer), this.bottom = new kl(OO, !1, KO.bottomContainer), this.top.sync(this.panels.filter((OO => OO.top))), this.bottom.sync(this.panels.filter((OO => !OO.top)));
        for (let pO of this.panels) pO.dom.classList.add("cm-panel"), pO.mount && pO.mount()
      }
      update(OO) {
        let KO = OO.state.facet(ne);
        this.top.container != KO.topContainer && (this.top.sync([]), this.top = new kl(OO.view, !0, KO.topContainer)), this.bottom.container != KO.bottomContainer && (this.bottom.sync([]), this.bottom = new kl(OO.view, !1, KO.bottomContainer)), this.top.syncClasses(), this.bottom.syncClasses();
        let pO = OO.state.facet(Ol);
        if (pO != this.input) {
          let KO = pO.filter((OO => OO)),
            XO = [],
            bK = [],
            eO = [],
            lO = [];
          for (let pO of KO) {
            let KO, vK = this.specs.indexOf(pO);
            vK < 0 ? (KO = pO(OO.view), lO.push(KO)) : (KO = this.panels[vK], KO.update && KO.update(OO)), XO.push(KO), (KO.top ? bK : eO).push(KO)
          }
          this.specs = KO, this.panels = XO, this.top.sync(bK), this.bottom.sync(eO);
          for (let OO of lO) OO.dom.classList.add("cm-panel"), OO.mount && OO.mount()
        } else
          for (let XO of this.panels) XO.update && XO.update(OO)
      }
      destroy() {
        this.top.sync([]), this.bottom.sync([])
      }
    }, {
      provide: OO => ye.scrollMargins.of((KO => {
        let pO = KO.plugin(OO);
        return pO && {
          top: pO.top.scrollMargin(),
          bottom: pO.bottom.scrollMargin()
        }
      }))
    });
    class kl {
      constructor(OO, KO, pO) {
        this.view = OO, this.top = KO, this.container = pO, this.dom = void 0, this.classes = "", this.panels = [], this.syncClasses()
      }
      sync(OO) {
        for (let KO of this.panels) KO.destroy && OO.indexOf(KO) < 0 && KO.destroy();
        this.panels = OO, this.syncDOM()
      }
      syncDOM() {
        if (0 == this.panels.length) return void(this.dom && (this.dom.remove(), this.dom = void 0));
        if (!this.dom) {
          this.dom = document.createElement("div"), this.dom.className = this.top ? "cm-panels cm-panels-top" : "cm-panels cm-panels-bottom", this.dom.style[this.top ? "top" : "bottom"] = "0";
          let OO = this.container || this.view.dom;
          OO.insertBefore(this.dom, this.top ? OO.firstChild : null)
        }
        let OO = this.dom.firstChild;
        for (let KO of this.panels)
          if (KO.dom.parentNode == this.dom) {
            for (; OO != KO.dom;) OO = Ue(OO);
            OO = OO.nextSibling
          } else this.dom.insertBefore(KO.dom, OO);
        for (; OO;) OO = Ue(OO)
      }
      scrollMargin() {
        return !this.dom || this.container ? 0 : Math.max(0, this.top ? this.dom.getBoundingClientRect().bottom - Math.max(0, this.view.scrollDOM.getBoundingClientRect().top) : Math.min(innerHeight, this.view.scrollDOM.getBoundingClientRect().bottom) - this.dom.getBoundingClientRect().top)
      }
      syncClasses() {
        if (this.container && this.classes != this.view.themeClasses) {
          for (let OO of this.classes.split(" ")) OO && this.container.classList.remove(OO);
          for (let OO of (this.classes = this.view.themeClasses).split(" ")) OO && this.container.classList.add(OO)
        }
      }
    }

    function Ue(OO) {
      let KO = OO.nextSibling;
      return OO.remove(), KO
    }
    const Ol = XO.n.define({
      enables: tl
    });

    function Kl(OO, KO) {
      let pO, bK = new Promise((OO => pO = OO)),
        eO = OO => function(OO, KO, pO) {
          let XO = KO.content ? KO.content(OO, (() => lO(null))) : null;
          if (!XO) {
            if (XO = (0, MO.b)("form"), KO.input) {
              let OO = (0, MO.b)("input", KO.input);
              /^(text|password|number|email|tel|url)$/.test(OO.type) && OO.classList.add("cm-textfield"), OO.name || (OO.name = "input"), XO.appendChild((0, MO.b)("label", (KO.label || "") + ": ", OO))
            } else XO.appendChild(document.createTextNode(KO.label || ""));
            XO.appendChild(document.createTextNode(" ")), XO.appendChild((0, MO.b)("button", {
              class: "cm-button",
              type: "submit"
            }, KO.submitLabel || "OK"))
          }
          let bK = "FORM" == XO.nodeName ? [XO] : XO.querySelectorAll("form");
          for (let vK = 0; vK < bK.length; vK++) {
            let OO = bK[vK];
            OO.addEventListener("keydown", (KO => {
              27 == KO.keyCode ? (KO.preventDefault(), lO(null)) : 13 == KO.keyCode && (KO.preventDefault(), lO(OO))
            })), OO.addEventListener("submit", (KO => {
              KO.preventDefault(), lO(OO)
            }))
          }
          let eO = (0, MO.b)("div", XO, (0, MO.b)("button", {
            onclick: () => lO(null),
            "aria-label": OO.state.phrase("close"),
            class: "cm-dialog-close",
            type: "button"
          }, ["\xd7"]));
          KO.class && (eO.className = KO.class);

          function lO(KO) {
            eO.contains(eO.ownerDocument.activeElement) && OO.focus(), pO(KO)
          }
          return eO.classList.add("cm-dialog"), {
            dom: eO,
            top: KO.top,
            mount: () => {
              if (KO.focus) {
                let OO;
                OO = "string" == typeof KO.focus ? XO.querySelector(KO.focus) : XO.querySelector("input") || XO.querySelector("button"), OO && "select" in OO ? OO.select() : OO && "focus" in OO && OO.focus()
              }
            }
          }
        }(OO, KO, pO);
      OO.state.field(pl, !1) ? OO.dispatch({
        effects: Xl.of(eO)
      }) : OO.dispatch({
        effects: XO.C.appendConfig.of(pl.init((() => [eO])))
      });
      let lO = bv.of(eO);
      return {
        close: lO,
        result: bK.then((KO => ((OO.win.queueMicrotask || (KO => OO.win.setTimeout(KO, 10)))((() => {
          OO.state.field(pl).indexOf(eO) > -1 && OO.dispatch({
            effects: lO
          })
        })), KO)))
      }
    }
    const pl = XO.G.define({
        create: () => [],
        update(OO, KO) {
          for (let pO of KO.effects) pO.is(Xl) ? OO = [pO.value].concat(OO) : pO.is(bv) && (OO = OO.filter((OO => OO != pO.value)));
          return OO
        },
        provide: OO => Ol.computeN([OO], (KO => KO.field(OO)))
      }),
      Xl = XO.C.define(),
      bv = XO.C.define();
    class el extends XO.A {
      compare(OO) {
        return this == OO || this.constructor == OO.constructor && this.eq(OO)
      }
      eq(OO) {
        return !1
      }
      destroy(OO) {}
    }
    el.prototype.elementClass = "", el.prototype.toDOM = void 0, el.prototype.mapMode = XO.r.TrackBefore, el.prototype.startSide = el.prototype.endSide = -1, el.prototype.point = !0;
    const ll = XO.n.define(),
      vv = XO.n.define(),
      Cl = {
        class: "",
        renderEmptyElements: !1,
        elementStyle: "",
        markers: () => XO.y.empty,
        lineMarker: () => null,
        widgetMarker: () => null,
        lineMarkerChange: null,
        initialSpacer: null,
        updateSpacer: null,
        domEventHandlers: {},
        side: "before"
      },
      hl = XO.n.define();

    function Dl(OO) {
      return [av(), hl.of({
        ...Cl,
        ...OO
      })]
    }
    const Ml = XO.n.define({
      combine: OO => OO.some((OO => OO))
    });

    function av(OO) {
      let KO = [ol];
      return OO && !1 === OO.fixed && KO.push(Ml.of(!0)), KO
    }
    const ol = WK.fromClass(class {
      constructor(OO) {
        this.view = OO, this.domAfter = null, this.prevViewport = OO.viewport, this.dom = document.createElement("div"), this.dom.className = "cm-gutters cm-gutters-before", this.dom.setAttribute("aria-hidden", "true"), this.dom.style.minHeight = this.view.contentHeight / this.view.scaleY + "px", this.gutters = OO.state.facet(hl).map((KO => new Ql(OO, KO))), this.fixed = !OO.state.facet(Ml);
        for (let KO of this.gutters) "after" == KO.config.side ? this.getDOMAfter().appendChild(KO.dom) : this.dom.appendChild(KO.dom);
        this.fixed && (this.dom.style.position = "sticky"), this.syncGutters(!1), OO.scrollDOM.insertBefore(this.dom, OO.contentDOM)
      }
      getDOMAfter() {
        return this.domAfter || (this.domAfter = document.createElement("div"), this.domAfter.className = "cm-gutters cm-gutters-after", this.domAfter.setAttribute("aria-hidden", "true"), this.domAfter.style.minHeight = this.view.contentHeight / this.view.scaleY + "px", this.domAfter.style.position = this.fixed ? "sticky" : "", this.view.scrollDOM.appendChild(this.domAfter)), this.domAfter
      }
      update(OO) {
        if (this.updateGutters(OO)) {
          let KO = this.prevViewport,
            pO = OO.view.viewport,
            XO = Math.min(KO.to, pO.to) - Math.max(KO.from, pO.from);
          this.syncGutters(XO < .8 * (pO.to - pO.from))
        }
        if (OO.geometryChanged) {
          let OO = this.view.contentHeight / this.view.scaleY + "px";
          this.dom.style.minHeight = OO, this.domAfter && (this.domAfter.style.minHeight = OO)
        }
        this.view.state.facet(Ml) != !this.fixed && (this.fixed = !this.fixed, this.dom.style.position = this.fixed ? "sticky" : "", this.domAfter && (this.domAfter.style.position = this.fixed ? "sticky" : "")), this.prevViewport = OO.view.viewport
      }
      syncGutters(OO) {
        let KO = this.dom.nextSibling;
        OO && (this.dom.remove(), this.domAfter && this.domAfter.remove());
        let pO = XO.y.iter(this.view.state.facet(ll), this.view.viewport.from),
          bK = [],
          eO = this.gutters.map((OO => new Ll(OO, this.view.viewport, -this.view.documentPadding.top)));
        for (let XO of this.view.viewportLineBlocks)
          if (bK.length && (bK = []), Array.isArray(XO.type)) {
            let OO = !0;
            for (let KO of XO.type)
              if (KO.type == YO.Text && OO) {
                Vl(pO, bK, KO.from);
                for (let OO of eO) OO.line(this.view, KO, bK);
                OO = !1
              } else if (KO.widget)
              for (let OO of eO) OO.widget(this.view, KO)
          } else if (XO.type == YO.Text) {
          Vl(pO, bK, XO.from);
          for (let OO of eO) OO.line(this.view, XO, bK)
        } else if (XO.widget)
          for (let OO of eO) OO.widget(this.view, XO);
        for (let XO of eO) XO.finish();
        OO && (this.view.scrollDOM.insertBefore(this.dom, KO), this.domAfter && this.view.scrollDOM.appendChild(this.domAfter))
      }
      updateGutters(OO) {
        let KO = OO.startState.facet(hl),
          pO = OO.state.facet(hl),
          bK = OO.docChanged || OO.heightChanged || OO.viewportChanged || !XO.y.eq(OO.startState.facet(ll), OO.state.facet(ll), OO.view.viewport.from, OO.view.viewport.to);
        if (KO == pO)
          for (let XO of this.gutters) XO.update(OO) && (bK = !0);
        else {
          bK = !0;
          let XO = [];
          for (let bK of pO) {
            let pO = KO.indexOf(bK);
            pO < 0 ? XO.push(new Ql(this.view, bK)) : (this.gutters[pO].update(OO), XO.push(this.gutters[pO]))
          }
          for (let OO of this.gutters) OO.dom.remove(), XO.indexOf(OO) < 0 && OO.destroy();
          for (let OO of XO) "after" == OO.config.side ? this.getDOMAfter().appendChild(OO.dom) : this.dom.appendChild(OO.dom);
          this.gutters = XO
        }
        return bK
      }
      destroy() {
        for (let OO of this.gutters) OO.destroy();
        this.dom.remove(), this.domAfter && this.domAfter.remove()
      }
    }, {
      provide: OO => ye.scrollMargins.of((KO => {
        let pO = KO.plugin(OO);
        if (!pO || 0 == pO.gutters.length || !pO.fixed) return null;
        let XO = pO.dom.offsetWidth * KO.scaleX,
          bK = pO.domAfter ? pO.domAfter.offsetWidth * KO.scaleX : 0;
        return KO.textDirection == hK.LTR ? {
          left: XO,
          right: bK
        } : {
          right: XO,
          left: bK
        }
      }))
    });

    function Fl(OO) {
      return Array.isArray(OO) ? OO : [OO]
    }

    function Vl(OO, KO, pO) {
      for (; OO.value && OO.from <= pO;) OO.from == pO && KO.push(OO.value), OO.next()
    }
    class Ll {
      constructor(OO, KO, pO) {
        this.gutter = OO, this.height = pO, this.i = 0, this.cursor = XO.y.iter(OO.markers, KO.from)
      }
      addElement(OO, KO, pO) {
        let {
          gutter: XO
        } = this, bK = (KO.top - this.height) / OO.scaleY, eO = KO.height / OO.scaleY;
        if (this.i == XO.elements.length) {
          let KO = new zv(OO, eO, bK, pO);
          XO.elements.push(KO), XO.dom.appendChild(KO.dom)
        } else XO.elements[this.i].update(OO, eO, bK, pO);
        this.height = KO.bottom, this.i++
      }
      line(OO, KO, pO) {
        let XO = [];
        Vl(this.cursor, XO, KO.from), pO.length && (XO = XO.concat(pO));
        let bK = this.gutter.config.lineMarker(OO, KO, XO);
        bK && XO.unshift(bK);
        let eO = this.gutter;
        (0 != XO.length || eO.config.renderEmptyElements) && this.addElement(OO, KO, XO)
      }
      widget(OO, KO) {
        let pO = this.gutter.config.widgetMarker(OO, KO.widget, KO),
          XO = pO ? [pO] : null;
        for (let bK of OO.state.facet(vv)) {
          let pO = bK(OO, KO.widget, KO);
          pO && (XO || (XO = [])).push(pO)
        }
        XO && this.addElement(OO, KO, XO)
      }
      finish() {
        let OO = this.gutter;
        for (; OO.elements.length > this.i;) {
          let KO = OO.elements.pop();
          OO.dom.removeChild(KO.dom), KO.destroy()
        }
      }
    }
    class Ql {
      constructor(OO, KO) {
        this.view = OO, this.config = KO, this.elements = [], this.spacer = null, this.dom = document.createElement("div"), this.dom.className = "cm-gutter" + (this.config.class ? " " + this.config.class : "");
        for (let pO in KO.domEventHandlers) this.dom.addEventListener(pO, (XO => {
          let bK, eO = XO.target;
          if (eO != this.dom && this.dom.contains(eO)) {
            for (; eO.parentNode != this.dom;) eO = eO.parentNode;
            let OO = eO.getBoundingClientRect();
            bK = (OO.top + OO.bottom) / 2
          } else bK = XO.clientY;
          let lO = OO.lineBlockAtHeight(bK - OO.documentTop);
          KO.domEventHandlers[pO](OO, lO, XO) && XO.preventDefault()
        }));
        this.markers = Fl(KO.markers(OO)), KO.initialSpacer && (this.spacer = new zv(OO, 0, 0, [KO.initialSpacer(OO)]), this.dom.appendChild(this.spacer.dom), this.spacer.dom.style.cssText += "visibility: hidden; pointer-events: none")
      }
      update(OO) {
        let KO = this.markers;
        if (this.markers = Fl(this.config.markers(OO.view)), this.spacer && this.config.updateSpacer) {
          let KO = this.config.updateSpacer(this.spacer.markers[0], OO);
          KO != this.spacer.markers[0] && this.spacer.update(OO.view, 0, 0, [KO])
        }
        let pO = OO.view.viewport;
        return !XO.y.eq(this.markers, KO, pO.from, pO.to) || !!this.config.lineMarkerChange && this.config.lineMarkerChange(OO)
      }
      destroy() {
        for (let OO of this.elements) OO.destroy()
      }
    }
    class zv {
      constructor(OO, KO, pO, XO) {
        this.height = -1, this.above = 0, this.markers = [], this.dom = document.createElement("div"), this.dom.className = "cm-gutterElement", this.update(OO, KO, pO, XO)
      }
      update(OO, KO, pO, XO) {
        this.height != KO && (this.height = KO, this.dom.style.height = KO + "px"), this.above != pO && (this.dom.style.marginTop = (this.above = pO) ? pO + "px" : ""),
          function(OO, KO) {
            if (OO.length != KO.length) return !1;
            for (let pO = 0; pO < OO.length; pO++)
              if (!OO[pO].compare(KO[pO])) return !1;
            return !0
          }(this.markers, XO) || this.setMarkers(OO, XO)
      }
      setMarkers(OO, KO) {
        let pO = "cm-gutterElement",
          XO = this.dom.firstChild;
        for (let bK = 0, eO = 0;;) {
          let lO = eO,
            vK = bK < KO.length ? KO[bK++] : null,
            CO = !1;
          if (vK) {
            let OO = vK.elementClass;
            OO && (pO += " " + OO);
            for (let KO = eO; KO < this.markers.length; KO++)
              if (this.markers[KO].compare(vK)) {
                lO = KO, CO = !0;
                break
              }
          } else lO = this.markers.length;
          for (; eO < lO;) {
            let OO = this.markers[eO++];
            if (OO.toDOM) {
              OO.destroy(XO);
              let KO = XO.nextSibling;
              XO.remove(), XO = KO
            }
          }
          if (!vK) break;
          vK.toDOM && (CO ? XO = XO.nextSibling : this.dom.insertBefore(vK.toDOM(OO), XO)), CO && eO++
        }
        this.dom.className = pO, this.markers = KO
      }
      destroy() {
        this.setMarkers(null, [])
      }
    }
    const Al = XO.n.define(),
      fl = XO.n.define(),
      dl = XO.n.define({
        combine: OO => (0, XO.T)(OO, {
          formatNumber: String,
          domEventHandlers: {}
        }, {
          domEventHandlers(OO, KO) {
            let pO = Object.assign({}, OO);
            for (let XO in KO) {
              let OO = pO[XO],
                bK = KO[XO];
              pO[XO] = OO ? (KO, pO, XO) => OO(KO, pO, XO) || bK(KO, pO, XO) : bK
            }
            return pO
          }
        })
      });
    class Tl extends el {
      constructor(OO) {
        super(), this.number = OO
      }
      eq(OO) {
        return this.number == OO.number
      }
      toDOM() {
        return document.createTextNode(this.number)
      }
    }

    function Nl(OO, KO) {
      return OO.state.facet(dl).formatNumber(KO, OO.state)
    }
    const Il = hl.compute([dl], (OO => ({
      class: "cm-lineNumbers",
      renderEmptyElements: !1,
      markers: OO => OO.state.facet(Al),
      lineMarker: (OO, KO, pO) => pO.some((OO => OO.toDOM)) ? null : new Tl(Nl(OO, OO.state.doc.lineAt(KO.from).number)),
      widgetMarker: (OO, KO, pO) => {
        for (let XO of OO.state.facet(fl)) {
          let bK = XO(OO, KO, pO);
          if (bK) return bK
        }
        return null
      },
      lineMarkerChange: OO => OO.startState.facet(dl) != OO.state.facet(dl),
      initialSpacer: OO => new Tl(Nl(OO, gv(OO.state.doc.lines))),
      updateSpacer(OO, KO) {
        let pO = Nl(KO.view, gv(KO.view.state.doc.lines));
        return pO == OO.number ? OO : new Tl(pO)
      },
      domEventHandlers: OO.facet(dl).domEventHandlers,
      side: "before"
    })));

    function yv() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      return [dl.of(OO), av(), Il]
    }

    function gv(OO) {
      let KO = 9;
      for (; KO < OO;) KO = 10 * KO + 9;
      return KO
    }
    const ul = new class extends el {
        constructor() {
          super(...arguments), this.elementClass = "cm-activeLineGutter"
        }
      },
      El = ll.compute(["selection"], (OO => {
        let KO = [],
          pO = -1;
        for (let XO of OO.selection.Xl) {
          let bK = OO.doc.lineAt(XO.head).from;
          bK > pO && (pO = bK, KO.push(ul.range(bK)))
        }
        return XO.y.of(KO)
      }));

    function jv() {
      return El
    }
  },
  39350: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => FO,
      c: () => XO,
      f: () => oO,
      i: () => lO,
      m: () => DO,
      q: () => hO,
      r: () => iK,
      v: () => PO,
      y: () => rK
    });
    const XO = 1024;
    let bK = 0;
    class eO {
      constructor(OO, KO) {
        this.from = OO, this.to = KO
      }
    }
    class lO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        this.id = bK++, this.perNode = !!OO.perNode, this.deserialize = OO.deserialize || (() => {
          throw new Error("This node type doesn't define a deserialize function")
        }), this.combine = OO.combine || null
      }
      add(OO) {
        if (this.perNode) throw new RangeError("Can't add per-node props to node types");
        return "function" != typeof OO && (OO = hO.match(OO)), KO => {
          let pO = OO(KO);
          return void 0 === pO ? null : [this, pO]
        }
      }
    }
    lO.closedBy = new lO({
      deserialize: OO => OO.split(" ")
    }), lO.openedBy = new lO({
      deserialize: OO => OO.split(" ")
    }), lO.group = new lO({
      deserialize: OO => OO.split(" ")
    }), lO.isolate = new lO({
      deserialize: OO => {
        if (OO && "rtl" != OO && "ltr" != OO && "auto" != OO) throw new RangeError("Invalid value for isolate: " + OO);
        return OO || "auto"
      }
    }), lO.contextHash = new lO({
      perNode: !0
    }), lO.lookAhead = new lO({
      perNode: !0
    }), lO.mounted = new lO({
      perNode: !0
    });
    class vK {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        this.tree = OO, this.overlay = KO, this.parser = pO, this.bracketed = XO
      }
      static get(OO) {
        return OO && OO.props && OO.props[lO.mounted.id]
      }
    }
    const CO = Object.create(null);
    class hO {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        this.name = OO, this.props = KO, this.id = pO, this.flags = XO
      }
      static define(OO) {
        let KO = OO.props && OO.props.length ? Object.create(null) : CO,
          pO = (OO.top ? 1 : 0) | (OO.skipped ? 2 : 0) | (OO.error ? 4 : 0) | (null == OO.name ? 8 : 0),
          XO = new hO(OO.name || "", KO, OO.id, pO);
        if (OO.props)
          for (let bK of OO.props)
            if (Array.isArray(bK) || (bK = bK(XO)), bK) {
              if (bK[0].perNode) throw new RangeError("Can't store a per-node prop on a node type");
              KO[bK[0].id] = bK[1]
            } return XO
      }
      prop(OO) {
        return this.props[OO.id]
      }
      get isTop() {
        return (1 & this.flags) > 0
      }
      get isSkipped() {
        return (2 & this.flags) > 0
      }
      get isError() {
        return (4 & this.flags) > 0
      }
      get isAnonymous() {
        return (8 & this.flags) > 0
      }
      is(OO) {
        if ("string" == typeof OO) {
          if (this.name == OO) return !0;
          let KO = this.prop(lO.group);
          return !!KO && KO.indexOf(OO) > -1
        }
        return this.id == OO
      }
      static match(OO) {
        let KO = Object.create(null);
        for (let pO in OO)
          for (let XO of pO.split(" ")) KO[XO] = OO[pO];
        return OO => {
          for (let pO = OO.prop(lO.group), XO = -1; XO < (pO ? pO.length : 0); XO++) {
            let bK = KO[XO < 0 ? OO.name : pO[XO]];
            if (bK) return bK
          }
        }
      }
    }
    hO.none = new hO("", Object.create(null), 0, 8);
    class DO {
      constructor(OO) {
        this.types = OO;
        for (let KO = 0; KO < OO.length; KO++)
          if (OO[KO].id != KO) throw new RangeError("Node type ids should correspond to array positions when creating a node set")
      }
      extend() {
        let OO = [];
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        for (let bK of this.types) {
          let KO = null;
          for (let OO of pO) {
            let pO = OO(bK);
            if (pO) {
              KO || (KO = Object.assign({}, bK.props));
              let OO = pO[1],
                XO = pO[0];
              XO.combine && XO.id in KO && (OO = XO.combine(KO[XO.id], OO)), KO[XO.id] = OO
            }
          }
          OO.push(KO ? new hO(bK.name, KO, bK.id, bK.flags) : bK)
        }
        return new DO(OO)
      }
    }
    const MO = new WeakMap,
      aK = new WeakMap;
    var oO;
    ! function(OO) {
      OO[OO.ExcludeBuffers = 1] = "ExcludeBuffers", OO[OO.IncludeAnonymous = 2] = "IncludeAnonymous", OO[OO.IgnoreMounts = 4] = "IgnoreMounts", OO[OO.IgnoreOverlays = 8] = "IgnoreOverlays", OO[OO.EnterBracketed = 16] = "EnterBracketed"
    }(oO || (oO = {}));
    class FO {
      constructor(OO, KO, pO, XO, bK) {
        if (this.type = OO, this.children = KO, this.positions = pO, this.length = XO, this.props = null, bK && bK.length) {
          this.props = Object.create(null);
          for (let [OO, KO] of bK) this.props["number" == typeof OO ? OO : OO.id] = KO
        }
      }
      toString() {
        let OO = vK.get(this);
        if (OO && !OO.overlay) return OO.tree.toString();
        let KO = "";
        for (let pO of this.children) {
          let OO = pO.toString();
          OO && (KO && (KO += ","), KO += OO)
        }
        return this.type.name ? (/\W/.test(this.type.name) && !this.type.isError ? JSON.stringify(this.type.name) : this.type.name) + (KO.length ? "(" + KO + ")" : "") : KO
      }
      cursor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return new uO(this.topNode, OO)
      }
      cursorAt(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = MO.get(this) || this.topNode,
          XO = new uO(pO);
        return XO.moveTo(OO, KO), MO.set(this, XO._tree), XO
      }
      get topNode() {
        return new fO(this, 0, 0, null)
      }
      resolve(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = zK(MO.get(this) || this.topNode, OO, KO, !1);
        return MO.set(this, pO), pO
      }
      resolveInner(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = zK(aK.get(this) || this.topNode, OO, KO, !0);
        return aK.set(this, pO), pO
      }
      resolveStack(OO) {
        return function(OO, KO, pO) {
          let XO = OO.resolveInner(KO, pO),
            bK = null;
          for (let eO = XO instanceof fO ? XO : XO.context.parent; eO; eO = eO.parent)
            if (eO.index < 0) {
              let OO = eO.parent;
              (bK || (bK = [XO])).push(OO.resolve(KO, pO)), eO = OO
            } else {
              let OO = vK.get(eO.tree);
              if (OO && OO.overlay && OO.overlay[0].from <= KO && OO.overlay[OO.overlay.length - 1].to >= KO) {
                let lO = new fO(OO.tree, OO.overlay[0].from + eO.from, -1, eO);
                (bK || (bK = [XO])).push(zK(lO, KO, pO, !1))
              }
            } return bK ? yK(bK) : XO
        }(this, OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0)
      }
      iterate(OO) {
        let {
          enter: KO,
          DX: pO,
          from: XO = 0,
          to: bK = this.length
        } = OO, eO = OO.mode || 0, lO = (eO & oO.IncludeAnonymous) > 0;
        for (let vK = this.cursor(eO | oO.IncludeAnonymous);;) {
          let OO = !1;
          if (vK.from <= bK && vK.to >= XO && (!lO && vK.type.isAnonymous || !1 !== KO(vK))) {
            if (vK.firstChild()) continue;
            OO = !0
          }
          for (; OO && pO && (lO || !vK.type.isAnonymous) && pO(vK), !vK.nextSibling();) {
            if (!vK.parent()) return;
            OO = !0
          }
        }
      }
      prop(OO) {
        return OO.perNode ? this.props ? this.props[OO.id] : void 0 : this.type.prop(OO)
      }
      get propValues() {
        let OO = [];
        if (this.props)
          for (let KO in this.props) OO.push([+KO, this.props[KO]]);
        return OO
      }
      balance() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return this.children.length <= 8 ? this : wO(hO.none, this.children, this.positions, 0, this.children.length, 0, this.length, ((OO, KO, pO) => new FO(this.type, OO, KO, pO, this.propValues)), OO.makeTree || ((OO, KO, pO) => new FO(hO.none, OO, KO, pO)))
      }
      static build(OO) {
        return function(OO) {
          var KO;
          let {
            buffer: pO,
            nodeSet: bK,
            maxBufferLength: eO = XO,
            reused: vK = [],
            minRepeatType: CO = bK.types.length
          } = OO, hO = Array.isArray(pO) ? new VO(pO, pO.length) : pO, DO = bK.types, MO = 0, aK = 0;

          function oO(OO, KO, pO, XO, lO, FO) {
            let {
              id: VO,
              start: NO,
              end: IO,
              size: yK
            } = hO, gK = aK, uO = MO;
            if (yK < 0) {
              if (hO.next(), -1 == yK) {
                let KO = vK[VO];
                return pO.push(KO), void XO.push(NO - OO)
              }
              if (-3 == yK) return void(MO = VO);
              if (-4 == yK) return void(aK = VO);
              throw new RangeError(`Unrecognized record size: ${yK}`)
            }
            let EO, jK, YO = DO[VO],
              iK = NO - OO;
            if (IO - NO <= eO && (jK = dO(hO.pos - KO, lO))) {
              let KO = new Uint16Array(jK.size - jK.skip),
                pO = hO.pos - jK.size,
                XO = KO.length;
              for (; hO.pos > pO;) XO = TO(jK.start, KO, XO);
              EO = new LO(KO, IO - jK.start, bK), iK = jK.start - OO
            } else {
              let OO = hO.pos - yK;
              hO.next();
              let KO = [],
                pO = [],
                XO = VO >= CO ? VO : -1,
                bK = 0,
                lO = IO;
              for (; hO.pos > OO;) XO >= 0 && hO.id == XO && hO.size >= 0 ? (hO.end <= lO - eO && (AO(KO, pO, NO, bK, hO.end, lO, XO, gK, uO), bK = KO.length, lO = hO.end), hO.next()) : FO > 2500 ? QO(NO, OO, KO, pO) : oO(NO, OO, KO, pO, XO, FO + 1);
              if (XO >= 0 && bK > 0 && bK < KO.length && AO(KO, pO, NO, bK, NO, lO, XO, gK, uO), KO.reverse(), pO.reverse(), XO > -1 && bK > 0) {
                let OO = zK(YO, uO);
                EO = wO(YO, KO, pO, 0, KO.length, 0, IO - NO, OO, OO)
              } else EO = fO(YO, KO, pO, IO - NO, gK - IO, uO)
            }
            pO.push(EO), XO.push(iK)
          }

          function QO(OO, KO, pO, XO) {
            let lO = [],
              vK = 0,
              CO = -1;
            for (; hO.pos > KO;) {
              let {
                id: OO,
                start: KO,
                end: pO,
                size: XO
              } = hO;
              if (XO > 4) hO.next();
              else {
                if (CO > -1 && KO < CO) break;
                CO < 0 && (CO = pO - eO), lO.push(OO, KO, pO), vK++, hO.next()
              }
            }
            if (vK) {
              let KO = new Uint16Array(4 * vK),
                eO = lO[lO.length - 2];
              for (let OO = lO.length - 3, pO = 0; OO >= 0; OO -= 3) KO[pO++] = lO[OO], KO[pO++] = lO[OO + 1] - eO, KO[pO++] = lO[OO + 2] - eO, KO[pO++] = pO;
              pO.push(new LO(KO, lO[2] - eO, bK)), XO.push(eO - OO)
            }
          }

          function zK(OO, KO) {
            return (pO, XO, bK) => {
              let eO, vK, CO = 0,
                hO = pO.length - 1;
              if (hO >= 0 && (eO = pO[hO]) instanceof FO) {
                if (!hO && eO.type == OO && eO.length == bK) return eO;
                (vK = eO.prop(lO.lookAhead)) && (CO = XO[hO] + eO.length + vK)
              }
              return fO(OO, pO, XO, bK, CO, KO)
            }
          }

          function AO(OO, KO, pO, XO, eO, lO, vK, CO, hO) {
            let DO = [],
              MO = [];
            for (; OO.length > XO;) DO.push(OO.pop()), MO.push(KO.pop() + pO - eO);
            OO.push(fO(bK.types[vK], DO, MO, lO - eO, CO - lO, hO)), KO.push(eO - pO)
          }

          function fO(OO, KO, pO, XO, bK, eO, vK) {
            if (eO) {
              let OO = [lO.contextHash, eO];
              vK = vK ? [OO].concat(vK) : [OO]
            }
            if (bK > 25) {
              let OO = [lO.lookAhead, bK];
              vK = vK ? [OO].concat(vK) : [OO]
            }
            return new FO(OO, KO, pO, XO, vK)
          }

          function dO(OO, KO) {
            let pO = hO.fork(),
              XO = 0,
              bK = 0,
              lO = 0,
              vK = pO.end - eO,
              DO = {
                size: 0,
                start: 0,
                skip: 0
              };
            OO: for (let eO = pO.pos - OO; pO.pos > eO;) {
              let OO = pO.size;
              if (pO.id == KO && OO >= 0) {
                DO.size = XO, DO.start = bK, DO.skip = lO, lO += 4, XO += 4, pO.next();
                continue
              }
              let hO = pO.pos - OO;
              if (OO < 0 || hO < eO || pO.start < vK) break;
              let MO = pO.id >= CO ? 4 : 0,
                aK = pO.start;
              for (pO.next(); pO.pos > hO;) {
                if (pO.size < 0) {
                  if (-3 != pO.size && -4 != pO.size) break OO;
                  MO += 4
                } else pO.id >= CO && (MO += 4);
                pO.next()
              }
              bK = aK, XO += OO, lO += MO
            }
            return (KO < 0 || XO == OO) && (DO.size = XO, DO.start = bK, DO.skip = lO), DO.size > 4 ? DO : void 0
          }

          function TO(OO, KO, pO) {
            let {
              id: XO,
              start: bK,
              end: eO,
              size: lO
            } = hO;
            if (hO.next(), lO >= 0 && XO < CO) {
              let vK = pO;
              if (lO > 4) {
                let XO = hO.pos - (lO - 4);
                for (; hO.pos > XO;) pO = TO(OO, KO, pO)
              }
              KO[--pO] = vK, KO[--pO] = eO - OO, KO[--pO] = bK - OO, KO[--pO] = XO
            } else - 3 == lO ? MO = XO : -4 == lO && (aK = XO);
            return pO
          }
          let NO = [],
            IO = [];
          for (; hO.pos > 0;) oO(OO.start || 0, OO.bufferStart || 0, NO, IO, -1, 0);
          let yK = null !== (KO = OO.length) && void 0 !== KO ? KO : NO.length ? IO[0] + NO[0].length : 0;
          return new FO(DO[OO.topID], NO.reverse(), IO.reverse(), yK)
        }(OO)
      }
    }
    FO.empty = new FO(hO.none, [], [], 0);
    class VO {
      constructor(OO, KO) {
        this.buffer = OO, this.index = KO
      }
      get id() {
        return this.buffer[this.index - 4]
      }
      get start() {
        return this.buffer[this.index - 3]
      }
      get end() {
        return this.buffer[this.index - 2]
      }
      get size() {
        return this.buffer[this.index - 1]
      }
      get pos() {
        return this.index
      }
      next() {
        this.index -= 4
      }
      fork() {
        return new VO(this.buffer, this.index)
      }
    }
    class LO {
      constructor(OO, KO, pO) {
        this.buffer = OO, this.length = KO, this.set = pO
      }
      get type() {
        return hO.none
      }
      toString() {
        let OO = [];
        for (let KO = 0; KO < this.buffer.length;) OO.push(this.childString(KO)), KO = this.buffer[KO + 3];
        return OO.join(",")
      }
      childString(OO) {
        let KO = this.buffer[OO],
          pO = this.buffer[OO + 3],
          XO = this.set.types[KO],
          bK = XO.name;
        if (/\W/.test(bK) && !XO.isError && (bK = JSON.stringify(bK)), pO == (OO += 4)) return bK;
        let eO = [];
        for (; OO < pO;) eO.push(this.childString(OO)), OO = this.buffer[OO + 3];
        return bK + "(" + eO.join(",") + ")"
      }
      findChild(OO, KO, pO, XO, bK) {
        let {
          buffer: eO
        } = this, lO = -1;
        for (let vK = OO; vK != KO && !(QO(bK, XO, eO[vK + 1], eO[vK + 2]) && (lO = vK, pO > 0)); vK = eO[vK + 3]);
        return lO
      }
      slice(OO, KO, pO) {
        let XO = this.buffer,
          bK = new Uint16Array(KO - OO),
          eO = 0;
        for (let lO = OO, vK = 0; lO < KO;) {
          bK[vK++] = XO[lO++], bK[vK++] = XO[lO++] - pO;
          let KO = bK[vK++] = XO[lO++] - pO;
          bK[vK++] = XO[lO++] - OO, eO = Math.max(eO, KO)
        }
        return new LO(bK, eO, this.set)
      }
    }

    function QO(OO, KO, pO, XO) {
      switch (OO) {
        case -2:
          return pO < KO;
        case -1:
          return XO >= KO && pO < KO;
        case 0:
          return pO < KO && XO > KO;
        case 1:
          return pO <= KO && XO > KO;
        case 2:
          return XO > KO;
        case 4:
          return !0
      }
    }

    function zK(OO, KO, pO, XO) {
      for (var bK; OO.from == OO.to || (pO < 1 ? OO.from >= KO : OO.from > KO) || (pO > -1 ? OO.to <= KO : OO.to < KO);) {
        let KO = !XO && OO instanceof fO && OO.index < 0 ? null : OO.parent;
        if (!KO) return OO;
        OO = KO
      }
      let eO = XO ? 0 : oO.IgnoreOverlays;
      if (XO)
        for (let lO = OO, vK = lO.parent; vK; lO = vK, vK = lO.parent) lO instanceof fO && lO.index < 0 && (null === (bK = vK.enter(KO, pO, eO)) || void 0 === bK ? void 0 : bK.from) != lO.from && (OO = vK);
      for (;;) {
        let XO = OO.enter(KO, pO, eO);
        if (!XO) return OO;
        OO = XO
      }
    }
    class AO {
      cursor() {
        return new uO(this, arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0)
      }
      getChild(OO) {
        let KO = dO(this, OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null);
        return KO.length ? KO[0] : null
      }
      getChildren(OO) {
        return dO(this, OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null)
      }
      resolve(OO) {
        return zK(this, OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, !1)
      }
      resolveInner(OO) {
        return zK(this, OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, !0)
      }
      matchContext(OO) {
        return TO(this.parent, OO)
      }
      enterUnfinishedNodesBefore(OO) {
        let KO = this.childBefore(OO),
          pO = this;
        for (; KO;) {
          let OO = KO.lastChild;
          if (!OO || OO.to != KO.to) break;
          OO.type.isError && OO.from == OO.to ? (pO = KO, KO = OO.prevSibling) : KO = OO
        }
        return pO
      }
      get node() {
        return this
      }
      get next() {
        return this.parent
      }
    }
    class fO extends AO {
      constructor(OO, KO, pO, XO) {
        super(), this._tree = OO, this.from = KO, this.index = pO, this._parent = XO
      }
      get type() {
        return this._tree.type
      }
      get name() {
        return this._tree.type.name
      }
      get to() {
        return this.from + this._tree.length
      }
      nextChild(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0;
        for (let eO = this;;) {
          for (let {
              children: lO,
              positions: CO
            } = eO._tree, hO = KO > 0 ? lO.length : -1; OO != hO; OO += KO) {
            let hO, DO = lO[OO],
              MO = CO[OO] + eO.from;
            if (bK & oO.EnterBracketed && DO instanceof FO && (hO = vK.get(DO)) && !hO.overlay && hO.bracketed && pO >= MO && pO <= MO + DO.length || QO(XO, pO, MO, MO + DO.length))
              if (DO instanceof LO) {
                if (bK & oO.ExcludeBuffers) continue;
                let lO = DO.findChild(0, DO.buffer.length, KO, pO - MO, XO);
                if (lO > -1) return new IO(new NO(eO, DO, OO, MO), null, lO)
              } else if (bK & oO.IncludeAnonymous || !DO.type.isAnonymous || EO(DO)) {
              let lO;
              if (!(bK & oO.IgnoreMounts) && (lO = vK.get(DO)) && !lO.overlay) return new fO(lO.tree, MO, OO, eO);
              let CO = new fO(DO, MO, OO, eO);
              return bK & oO.IncludeAnonymous || !CO.type.isAnonymous ? CO : CO.nextChild(KO < 0 ? DO.children.length - 1 : 0, KO, pO, XO, bK)
            }
          }
          if (bK & oO.IncludeAnonymous || !eO.type.isAnonymous) return null;
          if (OO = eO.index >= 0 ? eO.index + KO : KO < 0 ? -1 : eO._parent._tree.children.length, eO = eO._parent, !eO) return null
        }
      }
      get firstChild() {
        return this.nextChild(0, 1, 0, 4)
      }
      get lastChild() {
        return this.nextChild(this._tree.children.length - 1, -1, 0, 4)
      }
      childAfter(OO) {
        return this.nextChild(0, 1, OO, 2)
      }
      childBefore(OO) {
        return this.nextChild(this._tree.children.length - 1, -1, OO, -2)
      }
      prop(OO) {
        return this._tree.prop(OO)
      }
      enter(OO, KO) {
        let pO, XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        if (!(XO & oO.IgnoreOverlays) && (pO = vK.get(this._tree)) && pO.overlay) {
          let bK = OO - this.from,
            eO = XO & oO.EnterBracketed && pO.bracketed;
          for (let {
              from: OO,
              to: XO
            }
            of pO.overlay)
            if ((KO > 0 || eO ? OO <= bK : OO < bK) && (KO < 0 || eO ? XO >= bK : XO > bK)) return new fO(pO.tree, pO.overlay[0].from + this.from, -1, this)
        }
        return this.nextChild(0, 1, OO, KO, XO)
      }
      nextSignificantParent() {
        let OO = this;
        for (; OO.type.isAnonymous && OO._parent;) OO = OO._parent;
        return OO
      }
      get parent() {
        return this._parent ? this._parent.nextSignificantParent() : null
      }
      get nextSibling() {
        return this._parent && this.index >= 0 ? this._parent.nextChild(this.index + 1, 1, 0, 4) : null
      }
      get prevSibling() {
        return this._parent && this.index >= 0 ? this._parent.nextChild(this.index - 1, -1, 0, 4) : null
      }
      get tree() {
        return this._tree
      }
      toTree() {
        return this._tree
      }
      toString() {
        return this._tree.toString()
      }
    }

    function dO(OO, KO, pO, XO) {
      let bK = OO.cursor(),
        eO = [];
      if (!bK.firstChild()) return eO;
      if (null != pO)
        for (let lO = !1; !lO;)
          if (lO = bK.type.is(pO), !bK.nextSibling()) return eO;
      for (;;) {
        if (null != XO && bK.type.is(XO)) return eO;
        if (bK.type.is(KO) && eO.push(bK.node), !bK.nextSibling()) return null == XO ? eO : []
      }
    }

    function TO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : KO.length - 1;
      for (let XO = OO; pO >= 0; XO = XO.parent) {
        if (!XO) return !1;
        if (!XO.type.isAnonymous) {
          if (KO[pO] && KO[pO] != XO.name) return !1;
          pO--
        }
      }
      return !0
    }
    class NO {
      constructor(OO, KO, pO, XO) {
        this.parent = OO, this.buffer = KO, this.index = pO, this.start = XO
      }
    }
    class IO extends AO {
      get name() {
        return this.type.name
      }
      get from() {
        return this.context.start + this.context.buffer.buffer[this.index + 1]
      }
      get to() {
        return this.context.start + this.context.buffer.buffer[this.index + 2]
      }
      constructor(OO, KO, pO) {
        super(), this.context = OO, this._parent = KO, this.index = pO, this.type = OO.buffer.set.types[OO.buffer.buffer[pO]]
      }
      child(OO, KO, pO) {
        let {
          buffer: XO
        } = this.context, bK = XO.findChild(this.index + 4, XO.buffer[this.index + 3], OO, KO - this.context.start, pO);
        return bK < 0 ? null : new IO(this.context, this, bK)
      }
      get firstChild() {
        return this.child(1, 0, 4)
      }
      get lastChild() {
        return this.child(-1, 0, 4)
      }
      childAfter(OO) {
        return this.child(1, OO, 2)
      }
      childBefore(OO) {
        return this.child(-1, OO, -2)
      }
      prop(OO) {
        return this.type.prop(OO)
      }
      enter(OO, KO) {
        if ((arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0) & oO.ExcludeBuffers) return null;
        let {
          buffer: pO
        } = this.context, XO = pO.findChild(this.index + 4, pO.buffer[this.index + 3], KO > 0 ? 1 : -1, OO - this.context.start, KO);
        return XO < 0 ? null : new IO(this.context, this, XO)
      }
      get parent() {
        return this._parent || this.context.parent.nextSignificantParent()
      }
      externalSibling(OO) {
        return this._parent ? null : this.context.parent.nextChild(this.context.index + OO, OO, 0, 4)
      }
      get nextSibling() {
        let {
          buffer: OO
        } = this.context, KO = OO.buffer[this.index + 3];
        return KO < (this._parent ? OO.buffer[this._parent.index + 3] : OO.buffer.length) ? new IO(this.context, this._parent, KO) : this.externalSibling(1)
      }
      get prevSibling() {
        let {
          buffer: OO
        } = this.context, KO = this._parent ? this._parent.index + 4 : 0;
        return this.index == KO ? this.externalSibling(-1) : new IO(this.context, this._parent, OO.findChild(KO, this.index, -1, 0, 4))
      }
      get tree() {
        return null
      }
      toTree() {
        let OO = [],
          KO = [],
          {
            buffer: pO
          } = this.context,
          XO = this.index + 4,
          bK = pO.buffer[this.index + 3];
        if (bK > XO) {
          let eO = pO.buffer[this.index + 1];
          OO.push(pO.slice(XO, bK, eO)), KO.push(0)
        }
        return new FO(this.type, OO, KO, this.to - this.from)
      }
      toString() {
        return this.context.buffer.childString(this.index)
      }
    }

    function yK(OO) {
      if (!OO.length) return null;
      let KO = 0,
        pO = OO[0];
      for (let eO = 1; eO < OO.length; eO++) {
        let XO = OO[eO];
        (XO.from > pO.from || XO.to < pO.to) && (pO = XO, KO = eO)
      }
      let XO = pO instanceof fO && pO.index < 0 ? null : pO.parent,
        bK = OO.slice();
      return XO ? bK[KO] = XO : bK.splice(KO, 1), new gK(bK, pO)
    }
    class gK {
      constructor(OO, KO) {
        this.heads = OO, this.node = KO
      }
      get next() {
        return yK(this.heads)
      }
    }
    class uO {
      get name() {
        return this.type.name
      }
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        if (this.buffer = null, this.stack = [], this.index = 0, this.bufferNode = null, this.mode = KO & ~oO.EnterBracketed, OO instanceof fO) this.yieldNode(OO);
        else {
          this._tree = OO.context.parent, this.buffer = OO.context;
          for (let KO = OO._parent; KO; KO = KO._parent) this.stack.unshift(KO.index);
          this.bufferNode = OO, this.yieldBuf(OO.index)
        }
      }
      yieldNode(OO) {
        return !!OO && (this._tree = OO, this.type = OO.type, this.from = OO.from, this.to = OO.to, !0)
      }
      yieldBuf(OO, KO) {
        this.index = OO;
        let {
          start: pO,
          buffer: XO
        } = this.buffer;
        return this.type = KO || XO.set.types[XO.buffer[OO]], this.from = pO + XO.buffer[OO + 1], this.to = pO + XO.buffer[OO + 2], !0
      }
      yield(OO) {
        return !!OO && (OO instanceof fO ? (this.buffer = null, this.yieldNode(OO)) : (this.buffer = OO.context, this.yieldBuf(OO.index, OO.type)))
      }
      toString() {
        return this.buffer ? this.buffer.buffer.childString(this.index) : this._tree.toString()
      }
      enterChild(OO, KO, pO) {
        if (!this.buffer) return this.yield(this._tree.nextChild(OO < 0 ? this._tree._tree.children.length - 1 : 0, OO, KO, pO, this.mode));
        let {
          buffer: XO
        } = this.buffer, bK = XO.findChild(this.index + 4, XO.buffer[this.index + 3], OO, KO - this.buffer.start, pO);
        return !(bK < 0) && (this.stack.push(this.index), this.yieldBuf(bK))
      }
      firstChild() {
        return this.enterChild(1, 0, 4)
      }
      lastChild() {
        return this.enterChild(-1, 0, 4)
      }
      childAfter(OO) {
        return this.enterChild(1, OO, 2)
      }
      childBefore(OO) {
        return this.enterChild(-1, OO, -2)
      }
      enter(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.mode;
        return this.buffer ? !(pO & oO.ExcludeBuffers) && this.enterChild(1, OO, KO) : this.yield(this._tree.enter(OO, KO, pO))
      }
      parent() {
        if (!this.buffer) return this.yieldNode(this.mode & oO.IncludeAnonymous ? this._tree._parent : this._tree.parent);
        if (this.stack.length) return this.yieldBuf(this.stack.pop());
        let OO = this.mode & oO.IncludeAnonymous ? this.buffer.parent : this.buffer.parent.nextSignificantParent();
        return this.buffer = null, this.yieldNode(OO)
      }
      sibling(OO) {
        if (!this.buffer) return !!this._tree._parent && this.yield(this._tree.index < 0 ? null : this._tree._parent.nextChild(this._tree.index + OO, OO, 0, 4, this.mode));
        let {
          buffer: KO
        } = this.buffer, pO = this.stack.length - 1;
        if (OO < 0) {
          let OO = pO < 0 ? 0 : this.stack[pO] + 4;
          if (this.index != OO) return this.yieldBuf(KO.findChild(OO, this.index, -1, 0, 4))
        } else {
          let OO = KO.buffer[this.index + 3];
          if (OO < (pO < 0 ? KO.buffer.length : KO.buffer[this.stack[pO] + 3])) return this.yieldBuf(OO)
        }
        return pO < 0 && this.yield(this.buffer.parent.nextChild(this.buffer.index + OO, OO, 0, 4, this.mode))
      }
      nextSibling() {
        return this.sibling(1)
      }
      prevSibling() {
        return this.sibling(-1)
      }
      atLastNode(OO) {
        let KO, pO, {
          buffer: XO
        } = this;
        if (XO) {
          if (OO > 0) {
            if (this.index < XO.buffer.buffer.length) return !1
          } else
            for (let OO = 0; OO < this.index; OO++)
              if (XO.buffer.buffer[OO + 3] < this.index) return !1;
          ({
            index: KO,
            parent: pO
          } = XO)
        } else({
          index: KO,
          _parent: pO
        } = this._tree);
        for (; pO;
          ({
            index: KO,
            _parent: pO
          } = pO))
          if (KO > -1)
            for (let XO = KO + OO, bK = OO < 0 ? -1 : pO._tree.children.length; XO != bK; XO += OO) {
              let OO = pO._tree.children[XO];
              if (this.mode & oO.IncludeAnonymous || OO instanceof LO || !OO.type.isAnonymous || EO(OO)) return !1
            }
        return !0
      }
      move(OO, KO) {
        if (KO && this.enterChild(OO, 0, 4)) return !0;
        for (;;) {
          if (this.sibling(OO)) return !0;
          if (this.atLastNode(OO) || !this.parent()) return !1
        }
      }
      next() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        return this.move(1, OO)
      }
      prev() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        return this.move(-1, OO)
      }
      moveTo(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        for (;
          (this.from == this.to || (KO < 1 ? this.from >= OO : this.from > OO) || (KO > -1 ? this.to <= OO : this.to < OO)) && this.parent(););
        for (; this.enterChild(1, OO, KO););
        return this
      }
      get node() {
        if (!this.buffer) return this._tree;
        let OO = this.bufferNode,
          KO = null,
          pO = 0;
        if (OO && OO.context == this.buffer) OO: for (let XO = this.index, bK = this.stack.length; bK >= 0;) {
          for (let eO = OO; eO; eO = eO._parent)
            if (eO.index == XO) {
              if (XO == this.index) return eO;
              KO = eO, pO = bK + 1;
              break OO
            } XO = this.stack[--bK]
        }
        for (let XO = pO; XO < this.stack.length; XO++) KO = new IO(this.buffer, KO, this.stack[XO]);
        return this.bufferNode = new IO(this.buffer, KO, this.index)
      }
      get tree() {
        return this.buffer ? null : this._tree._tree
      }
      iterate(OO, KO) {
        for (let pO = 0;;) {
          let XO = !1;
          if (this.type.isAnonymous || !1 !== OO(this)) {
            if (this.firstChild()) {
              pO++;
              continue
            }
            this.type.isAnonymous || (XO = !0)
          }
          for (;;) {
            if (XO && KO && KO(this), XO = this.type.isAnonymous, !pO) return;
            if (this.nextSibling()) break;
            this.parent(), pO--, XO = !0
          }
        }
      }
      matchContext(OO) {
        if (!this.buffer) return TO(this.node.parent, OO);
        let {
          buffer: KO
        } = this.buffer, {
          types: pO
        } = KO.set;
        for (let XO = OO.length - 1, bK = this.stack.length - 1; XO >= 0; bK--) {
          if (bK < 0) return TO(this._tree, OO, XO);
          let eO = pO[KO.buffer[this.stack[bK]]];
          if (!eO.isAnonymous) {
            if (OO[XO] && OO[XO] != eO.name) return !1;
            XO--
          }
        }
        return !0
      }
    }

    function EO(OO) {
      return OO.children.some((OO => OO instanceof LO || !OO.type.isAnonymous || EO(OO)))
    }
    const jK = new WeakMap;

    function YO(OO, KO) {
      if (!OO.isAnonymous || KO instanceof LO || KO.type != OO) return 1;
      let pO = jK.get(KO);
      if (null == pO) {
        pO = 1;
        for (let XO of KO.children) {
          if (XO.type != OO || !(XO instanceof FO)) {
            pO = 1;
            break
          }
          pO += YO(OO, XO)
        }
        jK.set(KO, pO)
      }
      return pO
    }

    function wO(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
      let hO = 0;
      for (let oO = XO; oO < bK; oO++) hO += YO(OO, KO[oO]);
      let DO = Math.ceil(1.5 * hO / 8),
        MO = [],
        aK = [];
      return function KO(pO, XO, bK, lO, vK) {
        for (let hO = bK; hO < lO;) {
          let bK = hO,
            oO = XO[hO],
            FO = YO(OO, pO[hO]);
          for (hO++; hO < lO; hO++) {
            let KO = YO(OO, pO[hO]);
            if (FO + KO >= DO) break;
            FO += KO
          }
          if (hO == bK + 1) {
            if (FO > DO) {
              let OO = pO[bK];
              KO(OO.children, OO.positions, 0, OO.children.length, XO[bK] + vK);
              continue
            }
            MO.push(pO[bK])
          } else {
            let KO = XO[hO - 1] + pO[hO - 1].length - oO;
            MO.push(wO(OO, pO, XO, bK, hO, oO, KO, null, CO))
          }
          aK.push(oO + vK - eO)
        }
      }(KO, pO, XO, bK, 0), (vK || CO)(MO, aK, lO)
    }
    class iK {
      constructor() {
        this.map = new WeakMap
      }
      setBuffer(OO, KO, pO) {
        let XO = this.map.get(OO);
        XO || this.map.set(OO, XO = new Map), XO.set(KO, pO)
      }
      getBuffer(OO, KO) {
        let pO = this.map.get(OO);
        return pO && pO.get(KO)
      }
      set(OO, KO) {
        OO instanceof IO ? this.setBuffer(OO.context.buffer, OO.index, KO) : OO instanceof fO && this.map.set(OO.tree, KO)
      }
      get(OO) {
        return OO instanceof IO ? this.getBuffer(OO.context.buffer, OO.index) : OO instanceof fO ? this.map.get(OO.tree) : void 0
      }
      cursorSet(OO, KO) {
        OO.buffer ? this.setBuffer(OO.buffer.buffer, OO.index, KO) : this.map.set(OO.tree, KO)
      }
      cursorGet(OO) {
        return OO.buffer ? this.getBuffer(OO.buffer.buffer, OO.index) : this.map.get(OO.tree)
      }
    }
    class rK {
      constructor(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
          eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
        this.from = OO, this.to = KO, this.tree = pO, this.offset = XO, this.open = (bK ? 1 : 0) | (eO ? 2 : 0)
      }
      get openStart() {
        return (1 & this.open) > 0
      }
      get openEnd() {
        return (2 & this.open) > 0
      }
      static addTree(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = [new rK(0, OO.length, OO, 0, !1, pO)];
        for (let bK of KO) bK.to > OO.length && XO.push(bK);
        return XO
      }
      static applyChanges(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 128;
        if (!KO.length) return OO;
        let XO = [],
          bK = 1,
          eO = OO.length ? OO[0] : null;
        for (let lO = 0, vK = 0, CO = 0;; lO++) {
          let hO = lO < KO.length ? KO[lO] : null,
            DO = hO ? hO.fromA : 1e9;
          if (DO - vK >= pO)
            for (; eO && eO.from < DO;) {
              let KO = eO;
              if (vK >= KO.from || DO <= KO.to || CO) {
                let OO = Math.max(KO.from, vK) - CO,
                  pO = Math.min(KO.to, DO) - CO;
                KO = OO >= pO ? null : new rK(OO, pO, KO.tree, KO.offset + CO, lO > 0, !!hO)
              }
              if (KO && XO.push(KO), eO.to > DO) break;
              eO = bK < OO.length ? OO[bK++] : null
            }
          if (!hO) break;
          vK = hO.toA, CO = hO.toA - hO.toB
        }
        return XO
      }
    }
    class PO {
      startParse(OO, KO, pO) {
        return "string" == typeof OO && (OO = new mK(OO)), pO = pO ? pO.length ? pO.map((OO => new eO(OO.from, OO.to))) : [new eO(0, 0)] : [new eO(0, OO.length)], this.createParse(OO, KO || [], pO)
      }
      parse(OO, KO, pO) {
        let XO = this.startParse(OO, KO, pO);
        for (;;) {
          let OO = XO.advance();
          if (OO) return OO
        }
      }
    }
    class mK {
      constructor(OO) {
        this.string = OO
      }
      get length() {
        return this.string.length
      }
      chunk(OO) {
        return this.string.slice(OO)
      }
      get lineChunks() {
        return !1
      }
      read(OO, KO) {
        return this.string.slice(OO, KO)
      }
    }
    new lO({
      perNode: !0
    })
  },
  39358: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => aK,
      h: () => CO,
      j: () => MO,
      l: () => jK
    });
    var XO = pO(39350);
    let bK = 0;
    class eO {
      constructor(OO, KO, pO, XO) {
        this.name = OO, this.set = KO, this.base = pO, this.modified = XO, this.id = bK++
      }
      toString() {
        let {
          name: OO
        } = this;
        for (let KO of this.modified) KO.name && (OO = `${KO.name}(${OO})`);
        return OO
      }
      static define(OO, KO) {
        let pO = "string" == typeof OO ? OO : "?";
        if (OO instanceof eO && (KO = OO), null === KO || void 0 === KO ? void 0 : KO.base) throw new Error("Can not derive from a modified tag");
        let XO = new eO(pO, [], null, []);
        if (XO.set.push(XO), KO)
          for (let bK of KO.set) XO.set.push(bK);
        return XO
      }
      static defineModifier(OO) {
        let KO = new vK(OO);
        return OO => OO.modified.indexOf(KO) > -1 ? OO : vK.get(OO.base || OO, OO.modified.concat(KO).sort(((OO, KO) => OO.id - KO.id)))
      }
    }
    let lO = 0;
    class vK {
      constructor(OO) {
        this.name = OO, this.instances = [], this.id = lO++
      }
      static get(OO, KO) {
        if (!KO.length) return OO;
        let pO = KO[0].instances.find((pO => {
          return pO.base == OO && (XO = KO, bK = pO.modified, XO.length == bK.length && XO.every(((OO, KO) => OO == bK[KO])));
          var XO, bK
        }));
        if (pO) return pO;
        let XO = [],
          bK = new eO(OO.name, XO, OO, KO);
        for (let eO of KO) eO.instances.push(bK);
        let lO = function(OO) {
          let KO = [
            []
          ];
          for (let pO = 0; pO < OO.length; pO++)
            for (let XO = 0, bK = KO.length; XO < bK; XO++) KO.push(KO[XO].concat(OO[pO]));
          return KO.sort(((OO, KO) => KO.length - OO.length))
        }(KO);
        for (let eO of OO.set)
          if (!eO.modified.length)
            for (let OO of lO) XO.push(vK.get(eO, OO));
        return bK
      }
    }

    function CO(OO) {
      let KO = Object.create(null);
      for (let pO in OO) {
        let XO = OO[pO];
        Array.isArray(XO) || (XO = [XO]);
        for (let OO of pO.split(" "))
          if (OO) {
            let pO = [],
              bK = 2,
              eO = OO;
            for (let KO = 0;;) {
              if ("..." == eO && KO > 0 && KO + 3 == OO.length) {
                bK = 1;
                break
              }
              let XO = /^"(?:[^"\\]|\\.)*?"|[^\/!]+/.exec(eO);
              if (!XO) throw new RangeError("Invalid path: " + OO);
              if (pO.push("*" == XO[0] ? "" : '"' == XO[0][0] ? JSON.parse(XO[0]) : XO[0]), KO += XO[0].length, KO == OO.length) break;
              let lO = OO[KO++];
              if (KO == OO.length && "!" == lO) {
                bK = 0;
                break
              }
              if ("/" != lO) throw new RangeError("Invalid path: " + OO);
              eO = OO.slice(KO)
            }
            let lO = pO.length - 1,
              vK = pO[lO];
            if (!vK) throw new RangeError("Invalid path: " + OO);
            let CO = new DO(XO, bK, lO > 0 ? pO.slice(0, lO) : null);
            KO[vK] = CO.sort(KO[vK])
          }
      }
      return hO.add(KO)
    }
    const hO = new XO.i({
      combine(OO, KO) {
        let pO, XO, bK;
        for (; OO || KO;) {
          if (!OO || KO && OO.depth >= KO.depth ? (bK = KO, KO = KO.next) : (bK = OO, OO = OO.next), pO && pO.mode == bK.mode && !bK.context && !pO.context) continue;
          let eO = new DO(bK.tags, bK.mode, bK.context);
          pO ? pO.next = eO : XO = eO, pO = eO
        }
        return XO
      }
    });
    class DO {
      constructor(OO, KO, pO, XO) {
        this.tags = OO, this.mode = KO, this.context = pO, this.next = XO
      }
      get opaque() {
        return 0 == this.mode
      }
      get inherit() {
        return 1 == this.mode
      }
      sort(OO) {
        return !OO || OO.depth < this.depth ? (this.next = OO, this) : (OO.next = this.sort(OO.next), OO)
      }
      get depth() {
        return this.context ? this.context.length : 0
      }
    }

    function MO(OO, KO) {
      let pO = Object.create(null);
      for (let eO of OO)
        if (Array.isArray(eO.tag))
          for (let OO of eO.tag) pO[OO.id] = eO.class;
        else pO[eO.tag.id] = eO.class;
      let {
        scope: XO,
        all: bK = null
      } = KO || {};
      return {
        style: OO => {
          let KO = bK;
          for (let XO of OO)
            for (let OO of XO.set) {
              let XO = pO[OO.id];
              if (XO) {
                KO = KO ? KO + " " + XO : XO;
                break
              }
            }
          return KO
        },
        scope: XO
      }
    }

    function aK(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : OO.length,
        eO = new oO(XO, Array.isArray(KO) ? KO : [KO], pO);
      eO.highlightRange(OO.cursor(), XO, bK, "", eO.highlighters), eO.flush(bK)
    }
    DO.empty = new DO([], 2, null);
    class oO {
      constructor(OO, KO, pO) {
        this.at = OO, this.highlighters = KO, this.span = pO, this.class = ""
      }
      startSpan(OO, KO) {
        KO != this.class && (this.flush(OO), OO > this.at && (this.at = OO), this.class = KO)
      }
      flush(OO) {
        OO > this.at && this.class && this.span(this.at, OO, this.class)
      }
      highlightRange(OO, KO, pO, bK, eO) {
        let {
          type: lO,
          from: vK,
          to: CO
        } = OO;
        if (vK >= pO || CO <= KO) return;
        lO.isTop && (eO = this.highlighters.filter((OO => !OO.scope || OO.scope(lO))));
        let MO = bK,
          aK = function(OO) {
            let KO = OO.type.prop(hO);
            for (; KO && KO.context && !OO.matchContext(KO.context);) KO = KO.next;
            return KO || null
          }(OO) || DO.empty,
          oO = function(OO, KO) {
            let pO = null;
            for (let XO of OO) {
              let OO = XO.style(KO);
              OO && (pO = pO ? pO + " " + OO : OO)
            }
            return pO
          }(eO, aK.tags);
        if (oO && (MO && (MO += " "), MO += oO, 1 == aK.mode && (bK += (bK ? " " : "") + oO)), this.startSpan(Math.max(KO, vK), MO), aK.opaque) return;
        let FO = OO.tree && OO.tree.prop(XO.i.mounted);
        if (FO && FO.overlay) {
          let XO = OO.node.enter(FO.overlay[0].from + vK, 1),
            lO = this.highlighters.filter((OO => !OO.scope || OO.scope(FO.tree.type))),
            hO = OO.firstChild();
          for (let DO = 0, aK = vK;; DO++) {
            let oO = DO < FO.overlay.length ? FO.overlay[DO] : null,
              VO = oO ? oO.from + vK : CO,
              LO = Math.max(KO, aK),
              QO = Math.min(pO, VO);
            if (LO < QO && hO)
              for (; OO.from < QO && (this.highlightRange(OO, LO, QO, bK, eO), this.startSpan(Math.min(QO, OO.to), MO), !(OO.to >= VO) && OO.nextSibling()););
            if (!oO || VO > pO) break;
            aK = oO.to + vK, aK > KO && (this.highlightRange(XO.cursor(), Math.max(KO, oO.from + vK), Math.min(pO, aK), "", lO), this.startSpan(Math.min(pO, aK), MO))
          }
          hO && OO.parent()
        } else if (OO.firstChild()) {
          FO && (bK = "");
          do {
            if (!(OO.to <= KO)) {
              if (OO.from >= pO) break;
              this.highlightRange(OO, KO, pO, bK, eO), this.startSpan(Math.min(pO, OO.to), MO)
            }
          } while (OO.nextSibling());
          OO.parent()
        }
      }
    }
    const FO = eO.define,
      VO = FO(),
      LO = FO(),
      QO = FO(LO),
      zK = FO(LO),
      AO = FO(),
      fO = FO(AO),
      dO = FO(AO),
      TO = FO(),
      NO = FO(TO),
      IO = FO(),
      yK = FO(),
      gK = FO(),
      uO = FO(gK),
      EO = FO(),
      jK = {
        comment: VO,
        lineComment: FO(VO),
        blockComment: FO(VO),
        docComment: FO(VO),
        name: LO,
        variableName: FO(LO),
        typeName: QO,
        tagName: FO(QO),
        propertyName: zK,
        attributeName: FO(zK),
        className: FO(LO),
        labelName: FO(LO),
        namespace: FO(LO),
        macroName: FO(LO),
        literal: AO,
        string: fO,
        docString: FO(fO),
        character: FO(fO),
        attributeValue: FO(fO),
        number: dO,
        integer: FO(dO),
        float: FO(dO),
        bool: FO(AO),
        regexp: FO(AO),
        escape: FO(AO),
        color: FO(AO),
        url: FO(AO),
        keyword: IO,
        self: FO(IO),
        null: FO(IO),
        atom: FO(IO),
        unit: FO(IO),
        modifier: FO(IO),
        operatorKeyword: FO(IO),
        controlKeyword: FO(IO),
        definitionKeyword: FO(IO),
        moduleKeyword: FO(IO),
        operator: yK,
        derefOperator: FO(yK),
        arithmeticOperator: FO(yK),
        logicOperator: FO(yK),
        bitwiseOperator: FO(yK),
        compareOperator: FO(yK),
        updateOperator: FO(yK),
        definitionOperator: FO(yK),
        typeOperator: FO(yK),
        controlOperator: FO(yK),
        punctuation: gK,
        separator: FO(gK),
        bracket: uO,
        angleBracket: FO(uO),
        squareBracket: FO(uO),
        paren: FO(uO),
        brace: FO(uO),
        content: TO,
        heading: NO,
        heading1: FO(NO),
        heading2: FO(NO),
        heading3: FO(NO),
        heading4: FO(NO),
        heading5: FO(NO),
        heading6: FO(NO),
        contentSeparator: FO(TO),
        list: FO(TO),
        quote: FO(TO),
        emphasis: FO(TO),
        strong: FO(TO),
        link: FO(TO),
        monospace: FO(TO),
        strikethrough: FO(TO),
        inserted: FO(),
        deleted: FO(),
        changed: FO(),
        invalid: FO(),
        meta: EO,
        documentMeta: FO(EO),
        annotation: FO(EO),
        processingInstruction: FO(EO),
        definition: eO.defineModifier("definition"),
        constant: eO.defineModifier("constant"),
        function: eO.defineModifier("function"),
        standard: eO.defineModifier("standard"),
        local: eO.defineModifier("local"),
        special: eO.defineModifier("special")
      };
    for (let YO in jK) {
      let OO = jK[YO];
      OO instanceof eO && (OO.name = YO)
    }
    MO([{
      tag: jK.link,
      class: "tok-link"
    }, {
      tag: jK.heading,
      class: "tok-heading"
    }, {
      tag: jK.emphasis,
      class: "tok-emphasis"
    }, {
      tag: jK.strong,
      class: "tok-strong"
    }, {
      tag: jK.keyword,
      class: "tok-keyword"
    }, {
      tag: jK.atom,
      class: "tok-atom"
    }, {
      tag: jK.bool,
      class: "tok-bool"
    }, {
      tag: jK.url,
      class: "tok-url"
    }, {
      tag: jK.labelName,
      class: "tok-labelName"
    }, {
      tag: jK.inserted,
      class: "tok-inserted"
    }, {
      tag: jK.deleted,
      class: "tok-deleted"
    }, {
      tag: jK.literal,
      class: "tok-literal"
    }, {
      tag: jK.string,
      class: "tok-string"
    }, {
      tag: jK.number,
      class: "tok-number"
    }, {
      tag: [jK.regexp, jK.escape, jK.special(jK.string)],
      class: "tok-string2"
    }, {
      tag: jK.variableName,
      class: "tok-variableName"
    }, {
      tag: jK.local(jK.variableName),
      class: "tok-variableName tok-local"
    }, {
      tag: jK.definition(jK.variableName),
      class: "tok-variableName tok-definition"
    }, {
      tag: jK.special(jK.variableName),
      class: "tok-variableName2"
    }, {
      tag: jK.definition(jK.propertyName),
      class: "tok-propertyName tok-definition"
    }, {
      tag: jK.typeName,
      class: "tok-typeName"
    }, {
      tag: jK.namespace,
      class: "tok-namespace"
    }, {
      tag: jK.className,
      class: "tok-className"
    }, {
      tag: jK.macroName,
      class: "tok-macroName"
    }, {
      tag: jK.propertyName,
      class: "tok-propertyName"
    }, {
      tag: jK.operator,
      class: "tok-operator"
    }, {
      tag: jK.comment,
      class: "tok-comment"
    }, {
      tag: jK.meta,
      class: "tok-meta"
    }, {
      tag: jK.invalid,
      class: "tok-invalid"
    }, {
      tag: jK.punctuation,
      class: "tok-punctuation"
    }])
  },
  39372: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK.h,
      g: () => lO.u,
      j: () => lO.C,
      l: () => lO.G,
      n: () => vK.l,
      r: () => Np,
      s: () => vK.M,
      w: () => vK.eb
    });
    var XO = pO(1211),
      bK = pO(1208),
      eO = pO(63),
      lO = pO(39338),
      vK = pO(39341),
      CO = pO(39347),
      hO = pO(39350);

    function DO(OO, KO) {
      return pO => {
        let {
          state: XO,
          dispatch: bK
        } = pO;
        if (XO.readOnly) return !1;
        let eO = OO(KO, XO);
        return !!eO && (bK(XO.update(eO)), !0)
      }
    }
    const MO = DO(QO, 0),
      aK = DO(LO, 0),
      oO = DO(((OO, KO) => LO(OO, KO, function(OO) {
        let KO = [];
        for (let pO of OO.selection.Xl) {
          let XO = OO.doc.lineAt(pO.from),
            bK = pO.to <= XO.to ? XO : OO.doc.lineAt(pO.to);
          bK.from > XO.from && bK.from == pO.to && (bK = pO.to == XO.to + 1 ? XO : OO.doc.lineAt(pO.to - 1));
          let eO = KO.length - 1;
          eO >= 0 && KO[eO].to > XO.from ? KO[eO].to = bK.to : KO.push({
            from: XO.from + /^\s*/.exec(XO.text)[0].length,
            to: bK.to
          })
        }
        return KO
      }(KO))), 0);

    function FO(OO, KO) {
      let pO = OO.languageDataAt("commentTokens", KO, 1);
      return pO.length ? pO[0] : {}
    }
    const VO = 50;

    function LO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : KO.selection.Xl,
        XO = pO.map((OO => FO(KO, OO.from).block));
      if (!XO.every((OO => OO))) return null;
      let bK = pO.map(((OO, pO) => function(OO, KO, pO, XO) {
        let bK, eO, {
            open: lO,
            close: vK
          } = KO,
          CO = OO.sliceDoc(pO - VO, pO),
          hO = OO.sliceDoc(XO, XO + VO),
          DO = /\s*$/.exec(CO)[0].length,
          MO = /^\s*/.exec(hO)[0].length,
          aK = CO.length - DO;
        if (CO.slice(aK - lO.length, aK) == lO && hO.slice(MO, MO + vK.length) == vK) return {
          open: {
            pos: pO - DO,
            margin: DO && 1
          },
          close: {
            pos: XO + MO,
            margin: MO && 1
          }
        };
        XO - pO <= 2 * VO ? bK = eO = OO.sliceDoc(pO, XO) : (bK = OO.sliceDoc(pO, pO + VO), eO = OO.sliceDoc(XO - VO, XO));
        let oO = /^\s*/.exec(bK)[0].length,
          FO = /\s*$/.exec(eO)[0].length,
          LO = eO.length - FO - vK.length;
        return bK.slice(oO, oO + lO.length) == lO && eO.slice(LO, LO + vK.length) == vK ? {
          open: {
            pos: pO + oO + lO.length,
            margin: /\s/.test(bK.charAt(oO + lO.length)) ? 1 : 0
          },
          close: {
            pos: XO - FO - vK.length,
            margin: /\s/.test(eO.charAt(LO - 1)) ? 1 : 0
          }
        } : null
      }(KO, XO[pO], OO.from, OO.to)));
      if (2 != OO && !bK.every((OO => OO))) return {
        changes: KO.changes(pO.map(((OO, KO) => bK[KO] ? [] : [{
          from: OO.from,
          insert: XO[KO].open + " "
        }, {
          from: OO.to,
          insert: " " + XO[KO].close
        }])))
      };
      if (1 != OO && bK.some((OO => OO))) {
        let OO = [];
        for (let KO, pO = 0; pO < bK.length; pO++)
          if (KO = bK[pO]) {
            let bK = XO[pO],
              {
                open: eO,
                close: lO
              } = KO;
            OO.push({
              from: eO.pos - bK.open.length,
              to: eO.pos + eO.margin
            }, {
              from: lO.pos - lO.margin,
              to: lO.pos + bK.close.length
            })
          } return {
          changes: OO
        }
      }
      return null
    }

    function QO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : KO.selection.Xl,
        XO = [],
        bK = -1;
      OO: for (let {
          from: eO,
          to: lO
        }
        of pO) {
        let OO, pO = XO.length,
          vK = 1e9;
        for (let CO = eO; CO <= lO;) {
          let pO = KO.doc.lineAt(CO);
          if (void 0 == OO && (OO = FO(KO, pO.from).line, !OO)) continue OO;
          if (pO.from > bK && (eO == lO || lO > pO.from)) {
            bK = pO.from;
            let KO = /^\s*/.exec(pO.text)[0].length,
              eO = KO == pO.length,
              lO = pO.text.slice(KO, KO + OO.length) == OO ? KO : -1;
            KO < pO.text.length && KO < vK && (vK = KO), XO.push({
              line: pO,
              comment: lO,
              token: OO,
              indent: KO,
              empty: eO,
              single: !1
            })
          }
          CO = pO.to + 1
        }
        if (vK < 1e9)
          for (let KO = pO; KO < XO.length; KO++) XO[KO].indent < XO[KO].line.text.length && (XO[KO].indent = vK);
        XO.length == pO + 1 && (XO[pO].single = !0)
      }
      if (2 != OO && XO.some((OO => OO.comment < 0 && (!OO.empty || OO.single)))) {
        let OO = [];
        for (let {
            line: KO,
            token: bK,
            indent: eO,
            empty: lO,
            single: vK
          }
          of XO) !vK && lO || OO.push({
          from: KO.from + eO,
          insert: bK + " "
        });
        let pO = KO.changes(OO);
        return {
          changes: pO,
          selection: KO.selection.map(pO, 1)
        }
      }
      if (1 != OO && XO.some((OO => OO.comment >= 0))) {
        let OO = [];
        for (let {
            line: KO,
            comment: pO,
            token: bK
          }
          of XO)
          if (pO >= 0) {
            let XO = KO.from + pO,
              eO = XO + bK.length;
            " " == KO.text[eO - KO.from] && eO++, OO.push({
              from: XO,
              to: eO
            })
          } return {
          changes: OO
        }
      }
      return null
    }
    const zK = lO.d.define(),
      AO = lO.d.define(),
      fO = lO.n.define(),
      dO = lO.n.define({
        combine: OO => (0, lO.T)(OO, {
          minDepth: 100,
          newGroupDelay: 500,
          joinToEvent: (OO, KO) => KO
        }, {
          minDepth: Math.max,
          newGroupDelay: Math.min,
          joinToEvent: (OO, KO) => (pO, XO) => OO(pO, XO) || KO(pO, XO)
        })
      }),
      TO = lO.G.define({
        create: () => RO.empty,
        update(OO, KO) {
          let pO = KO.state.facet(dO),
            XO = KO.annotation(zK);
          if (XO) {
            let bK = EO.fromTransaction(KO, XO.selection),
              eO = XO.side,
              lO = 0 == eO ? OO.undone : OO.done;
            return lO = bK ? jK(lO, lO.length, pO.minDepth, bK) : rK(lO, KO.startState.selection), new RO(0 == eO ? XO.rest : lO, 0 == eO ? lO : XO.rest)
          }
          let bK = KO.annotation(AO);
          if ("full" != bK && "before" != bK || (OO = OO.isolate()), !1 === KO.annotation(lO.M.addToHistory)) return KO.changes.empty ? OO : OO.addMapping(KO.changes.desc);
          let eO = EO.fromTransaction(KO),
            vK = KO.annotation(lO.M.time),
            CO = KO.annotation(lO.M.userEvent);
          return eO ? OO = OO.addChanges(eO, vK, CO, pO, KO) : KO.selection && (OO = OO.addSelection(KO.startState.selection, vK, CO, pO.newGroupDelay)), "full" != bK && "after" != bK || (OO = OO.isolate()), OO
        },
        toJSON: OO => ({
          done: OO.done.map((OO => OO.toJSON())),
          undone: OO.undone.map((OO => OO.toJSON()))
        }),
        fromJSON: OO => new RO(OO.done.map(EO.fromJSON), OO.undone.map(EO.fromJSON))
      });

    function NO(OO, KO) {
      return function(pO) {
        let {
          state: XO,
          dispatch: bK
        } = pO;
        if (!KO && XO.readOnly) return !1;
        let eO = XO.field(TO, !1);
        if (!eO) return !1;
        let lO = eO.pop(OO, XO, KO);
        return !!lO && (bK(lO), !0)
      }
    }
    const IO = NO(0, !1),
      yK = NO(1, !1),
      gK = NO(0, !0),
      uO = NO(1, !0);
    class EO {
      constructor(OO, KO, pO, XO, bK) {
        this.changes = OO, this.effects = KO, this.mapped = pO, this.startSelection = XO, this.selectionsAfter = bK
      }
      setSelAfter(OO) {
        return new EO(this.changes, this.effects, this.mapped, this.startSelection, OO)
      }
      toJSON() {
        var OO, KO, pO;
        return {
          changes: null === (OO = this.changes) || void 0 === OO ? void 0 : OO.toJSON(),
          mapped: null === (KO = this.mapped) || void 0 === KO ? void 0 : KO.toJSON(),
          startSelection: null === (pO = this.startSelection) || void 0 === pO ? void 0 : pO.toJSON(),
          selectionsAfter: this.selectionsAfter.map((OO => OO.toJSON()))
        }
      }
      static fromJSON(OO) {
        return new EO(OO.changes && lO.ChangeSet.fromJSON(OO.changes), [], OO.mapped && lO.h.fromJSON(OO.mapped), OO.startSelection && lO.j.fromJSON(OO.startSelection), OO.selectionsAfter.map(lO.j.fromJSON))
      }
      static fromTransaction(OO, KO) {
        let pO = wO;
        for (let XO of OO.startState.facet(fO)) {
          let KO = XO(OO);
          KO.length && (pO = pO.concat(KO))
        }
        return !pO.length && OO.changes.empty ? null : new EO(OO.changes.invert(OO.startState.doc), pO, void 0, KO || OO.startState.selection, wO)
      }
      static selection(OO) {
        return new EO(void 0, wO, void 0, void 0, OO)
      }
    }

    function jK(OO, KO, pO, XO) {
      let bK = KO + 1 > pO + 20 ? KO - pO - 1 : 0,
        eO = OO.slice(bK, KO);
      return eO.push(XO), eO
    }

    function YO(OO, KO) {
      return OO.length ? KO.length ? OO.concat(KO) : OO : KO
    }
    const wO = [],
      iK = 200;

    function rK(OO, KO) {
      if (OO.length) {
        let pO = OO[OO.length - 1],
          XO = pO.selectionsAfter.slice(Math.max(0, pO.selectionsAfter.length - iK));
        return XO.length && XO[XO.length - 1].eq(KO) ? OO : (XO.push(KO), jK(OO, OO.length - 1, 1e9, pO.setSelAfter(XO)))
      }
      return [EO.selection([KO])]
    }

    function PO(OO) {
      let KO = OO[OO.length - 1],
        pO = OO.slice();
      return pO[OO.length - 1] = KO.setSelAfter(KO.selectionsAfter.slice(0, KO.selectionsAfter.length - 1)), pO
    }

    function mK(OO, KO) {
      if (!OO.length) return OO;
      let pO = OO.length,
        XO = wO;
      for (; pO;) {
        let bK = sO(OO[pO - 1], KO, XO);
        if (bK.changes && !bK.changes.empty || bK.effects.length) {
          let KO = OO.slice(0, pO);
          return KO[pO - 1] = bK, KO
        }
        KO = bK.mapped, pO--, XO = bK.selectionsAfter
      }
      return XO.length ? [EO.selection(XO)] : wO
    }

    function sO(OO, KO, pO) {
      let XO = YO(OO.selectionsAfter.length ? OO.selectionsAfter.map((OO => OO.map(KO))) : wO, pO);
      if (!OO.changes) return EO.selection(XO);
      let bK = OO.changes.map(KO),
        eO = KO.mapDesc(OO.changes, !0),
        vK = OO.mapped ? OO.mapped.composeDesc(eO) : eO;
      return new EO(bK, lO.C.mapEffects(OO.effects, KO), vK, OO.startSelection.map(eO), XO)
    }
    const HO = /^(input\.type|delete)($|\.)/;
    class RO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : void 0;
        this.done = OO, this.undone = KO, this.prevTime = pO, this.prevUserEvent = XO
      }
      isolate() {
        return this.prevTime ? new RO(this.done, this.undone) : this
      }
      addChanges(OO, KO, pO, XO, bK) {
        let eO = this.done,
          vK = eO[eO.length - 1];
        return eO = vK && vK.changes && !vK.changes.empty && OO.changes && (!pO || HO.test(pO)) && (!vK.selectionsAfter.length && KO - this.prevTime < XO.newGroupDelay && XO.joinToEvent(bK, function(OO, KO) {
          let pO = [],
            XO = !1;
          return OO.iterChangedRanges(((OO, KO) => pO.push(OO, KO))), KO.iterChangedRanges(((OO, KO, bK, eO) => {
            for (let lO = 0; lO < pO.length;) {
              let OO = pO[lO++],
                KO = pO[lO++];
              eO >= OO && bK <= KO && (XO = !0)
            }
          })), XO
        }(vK.changes, OO.changes)) || "input.type.compose" == pO) ? jK(eO, eO.length - 1, XO.minDepth, new EO(OO.changes.compose(vK.changes), YO(lO.C.mapEffects(OO.effects, vK.changes), vK.effects), vK.mapped, vK.startSelection, wO)) : jK(eO, eO.length, XO.minDepth, OO), new RO(eO, wO, KO, pO)
      }
      addSelection(OO, KO, pO, XO) {
        let bK = this.done.length ? this.done[this.done.length - 1].selectionsAfter : wO;
        return bK.length > 0 && KO - this.prevTime < XO && pO == this.prevUserEvent && pO && /^select($|\.)/.test(pO) && (eO = bK[bK.length - 1], lO = OO, eO.Xl.length == lO.Xl.length && 0 === eO.Xl.filter(((OO, KO) => OO.empty != lO.Xl[KO].empty)).length) ? this : new RO(rK(this.done, OO), this.undone, KO, pO);
        var eO, lO
      }
      addMapping(OO) {
        return new RO(mK(this.done, OO), mK(this.undone, OO), this.prevTime, this.prevUserEvent)
      }
      pop(OO, KO, pO) {
        let XO = 0 == OO ? this.done : this.undone;
        if (0 == XO.length) return null;
        let bK = XO[XO.length - 1],
          eO = bK.selectionsAfter[0] || (bK.startSelection ? bK.startSelection.map(bK.changes.invertedDesc, 1) : KO.selection);
        if (pO && bK.selectionsAfter.length) return KO.update({
          selection: bK.selectionsAfter[bK.selectionsAfter.length - 1],
          annotations: zK.of({
            side: OO,
            rest: PO(XO),
            selection: eO
          }),
          userEvent: 0 == OO ? "select.undo" : "select.redo",
          scrollIntoView: !0
        });
        if (bK.changes) {
          let pO = 1 == XO.length ? wO : XO.slice(0, XO.length - 1);
          return bK.mapped && (pO = mK(pO, bK.mapped)), KO.update({
            changes: bK.changes,
            selection: bK.startSelection,
            effects: bK.effects,
            annotations: zK.of({
              side: OO,
              rest: pO,
              selection: eO
            }),
            filter: !1,
            userEvent: 0 == OO ? "undo" : "redo",
            scrollIntoView: !0
          })
        }
        return null
      }
    }
    RO.empty = new RO(wO, wO);
    const SO = [{
      key: "Mod-z",
      run: IO,
      preventDefault: !0
    }, {
      key: "Mod-y",
      mac: "Mod-Shift-z",
      run: yK,
      preventDefault: !0
    }, {
      linux: "Ctrl-Shift-z",
      run: yK,
      preventDefault: !0
    }, {
      key: "Mod-u",
      run: gK,
      preventDefault: !0
    }, {
      key: "Alt-u",
      mac: "Mod-Shift-u",
      run: uO,
      preventDefault: !0
    }];

    function JO(OO, KO) {
      return lO.j.create(OO.Xl.map(KO), OO.mainIndex)
    }

    function cK(OO, KO) {
      return OO.update({
        selection: KO,
        scrollIntoView: !0,
        userEvent: "select"
      })
    }

    function BO(OO, KO) {
      let {
        state: pO,
        dispatch: XO
      } = OO, bK = JO(pO.selection, KO);
      return !bK.eq(pO.selection, !0) && (XO(cK(pO, bK)), !0)
    }

    function ZO(OO, KO) {
      return lO.j.cursor(KO ? OO.to : OO.from)
    }

    function GO(OO, KO) {
      return BO(OO, (pO => pO.empty ? OO.moveByChar(pO, KO) : ZO(pO, KO)))
    }

    function qK(OO) {
      return OO.textDirectionAt(OO.state.selection.main.head) == vK.d.LTR
    }
    const xK = OO => GO(OO, !qK(OO)),
      nO = OO => GO(OO, qK(OO));

    function WO(OO, KO) {
      return BO(OO, (pO => pO.empty ? OO.moveByGroup(pO, KO) : ZO(pO, KO)))
    }
    "undefined" != typeof Intl && Intl.Segmenter;

    function tK(OO, KO, pO) {
      if (KO.type.prop(pO)) return !0;
      let XO = KO.to - KO.from;
      return XO && (XO > 2 || /[^\s,.;:]/.test(OO.sliceDoc(KO.from, KO.to))) || KO.firstChild
    }

    function kK(OO, KO, pO) {
      let XO, bK, eO = (0, CO.ib)(OO).resolveInner(KO.head),
        vK = pO ? hO.i.closedBy : hO.i.openedBy;
      for (let lO = KO.head;;) {
        let KO = pO ? eO.childAfter(lO) : eO.childBefore(lO);
        if (!KO) break;
        tK(OO, KO, vK) ? eO = KO : lO = pO ? KO.to : KO.from
      }
      return bK = eO.type.prop(vK) && (XO = pO ? (0, CO._)(OO, eO.from, 1) : (0, CO._)(OO, eO.to, -1)) && XO.matched ? pO ? XO.end.to : XO.end.from : pO ? eO.to : eO.from, lO.j.cursor(bK, pO ? -1 : 1)
    }

    function UO(OO, KO) {
      return BO(OO, (pO => {
        if (!pO.empty) return ZO(pO, KO);
        let XO = OO.moveVertically(pO, KO);
        return XO.head != pO.head ? XO : OO.moveToLineBoundary(pO, KO)
      }))
    }
    const OK = OO => UO(OO, !1),
      KK = OO => UO(OO, !0);

    function pK(OO) {
      let KO, pO = OO.scrollDOM.clientHeight < OO.scrollDOM.scrollHeight - 2,
        XO = 0,
        bK = 0;
      if (pO) {
        for (let KO of OO.state.facet(vK.h.scrollMargins)) {
          let pO = KO(OO);
          (null === pO || void 0 === pO ? void 0 : pO.top) && (XO = Math.max(null === pO || void 0 === pO ? void 0 : pO.top, XO)), (null === pO || void 0 === pO ? void 0 : pO.bottom) && (bK = Math.max(null === pO || void 0 === pO ? void 0 : pO.bottom, bK))
        }
        KO = OO.scrollDOM.clientHeight - XO - bK
      } else KO = (OO.dom.ownerDocument.defaultView || window).innerHeight;
      return {
        marginTop: XO,
        marginBottom: bK,
        selfScroll: pO,
        height: Math.max(OO.defaultLineHeight, KO - 5)
      }
    }

    function XK(OO, KO) {
      let pO, XO = pK(OO),
        {
          state: bK
        } = OO,
        eO = JO(bK.selection, (pO => pO.empty ? OO.moveVertically(pO, KO, XO.height) : ZO(pO, KO)));
      if (eO.eq(bK.selection)) return !1;
      if (XO.selfScroll) {
        let KO = OO.coordsAtPos(bK.selection.main.head),
          lO = OO.scrollDOM.getBoundingClientRect(),
          CO = lO.top + XO.marginTop,
          hO = lO.bottom - XO.marginBottom;
        KO && KO.top > CO && KO.bottom < hO && (pO = vK.h.scrollIntoView(eO.main.head, {
          y: "start",
          yMargin: KO.top - CO
        }))
      }
      return OO.dispatch(cK(bK, eO), {
        effects: pO
      }), !0
    }
    const bp = OO => XK(OO, !1),
      eK = OO => XK(OO, !0);

    function lK(OO, KO, pO) {
      let XO = OO.lineBlockAt(KO.head),
        bK = OO.moveToLineBoundary(KO, pO);
      if (bK.head == KO.head && bK.head != (pO ? XO.to : XO.from) && (bK = OO.moveToLineBoundary(KO, pO, !1)), !pO && bK.head == XO.from && XO.length) {
        let pO = /^\s*/.exec(OO.state.sliceDoc(XO.from, Math.min(XO.from + 100, XO.to)))[0].length;
        pO && KO.head != XO.from + pO && (bK = lO.j.cursor(XO.from + pO))
      }
      return bK
    }

    function vp(OO, KO, pO) {
      let XO = !1,
        bK = JO(OO.selection, (KO => {
          let bK = (0, CO._)(OO, KO.head, -1) || (0, CO._)(OO, KO.head, 1) || KO.head > 0 && (0, CO._)(OO, KO.head - 1, 1) || KO.head < OO.doc.length && (0, CO._)(OO, KO.head + 1, -1);
          if (!bK || !bK.end) return KO;
          XO = !0;
          let eO = bK.start.from == KO.head ? bK.end.to : bK.end.from;
          return pO ? lO.j.range(KO.anchor, eO) : lO.j.cursor(eO)
        }));
      return !!XO && (KO(cK(OO, bK)), !0)
    }

    function CK(OO, KO) {
      let pO = JO(OO.state.selection, (OO => {
        let pO = KO(OO);
        return lO.j.range(OO.anchor, pO.head, pO.goalColumn, pO.bidiLevel || void 0, pO.assoc)
      }));
      return !pO.eq(OO.state.selection) && (OO.dispatch(cK(OO.state, pO)), !0)
    }

    function hK(OO, KO) {
      return CK(OO, (pO => OO.moveByChar(pO, KO)))
    }
    const DK = OO => hK(OO, !qK(OO)),
      MK = OO => hK(OO, qK(OO));

    function ap(OO, KO) {
      return CK(OO, (pO => OO.moveByGroup(pO, KO)))
    }

    function oK(OO, KO) {
      return CK(OO, (pO => OO.moveVertically(pO, KO)))
    }
    const FK = OO => oK(OO, !1),
      VK = OO => oK(OO, !0);

    function LK(OO, KO) {
      return CK(OO, (pO => OO.moveVertically(pO, KO, pK(OO).height)))
    }
    const QK = OO => LK(OO, !1),
      zp = OO => LK(OO, !0),
      AK = OO => {
        let {
          state: KO,
          dispatch: pO
        } = OO;
        return pO(cK(KO, {
          anchor: 0
        })), !0
      },
      fK = OO => {
        let {
          state: KO,
          dispatch: pO
        } = OO;
        return pO(cK(KO, {
          anchor: KO.doc.length
        })), !0
      },
      dK = OO => {
        let {
          state: KO,
          dispatch: pO
        } = OO;
        return pO(cK(KO, {
          anchor: KO.selection.main.anchor,
          head: 0
        })), !0
      },
      TK = OO => {
        let {
          state: KO,
          dispatch: pO
        } = OO;
        return pO(cK(KO, {
          anchor: KO.selection.main.anchor,
          head: KO.doc.length
        })), !0
      };

    function NK(OO, KO) {
      let {
        state: pO
      } = OO, XO = pO.selection, bK = pO.selection.Xl.slice();
      for (let eO of pO.selection.Xl) {
        let XO = pO.doc.lineAt(eO.head);
        if (KO ? XO.to < OO.state.doc.length : XO.from > 0)
          for (let pO = eO;;) {
            let eO = OO.moveVertically(pO, KO);
            if (eO.head < XO.from || eO.head > XO.to) {
              bK.some((OO => OO.head == eO.head)) || bK.push(eO);
              break
            }
            if (eO.head == pO.head) break;
            pO = eO
          }
      }
      return bK.length != XO.Xl.length && (OO.dispatch(cK(pO, lO.j.create(bK, bK.length - 1))), !0)
    }

    function IK(OO, KO) {
      if (OO.state.readOnly) return !1;
      let pO = "delete.selection",
        {
          state: XO
        } = OO,
        bK = XO.changeByRange((XO => {
          let {
            from: bK,
            to: eO
          } = XO;
          if (bK == eO) {
            let lO = KO(XO);
            lO < bK ? (pO = "delete.backward", lO = yp(OO, lO, !1)) : lO > bK && (pO = "delete.forward", lO = yp(OO, lO, !0)), bK = Math.min(bK, lO), eO = Math.max(eO, lO)
          } else bK = yp(OO, bK, !1), eO = yp(OO, eO, !0);
          return bK == eO ? {
            range: XO
          } : {
            changes: {
              from: bK,
              to: eO
            },
            range: lO.j.cursor(bK, bK < XO.head ? -1 : 1)
          }
        }));
      return !bK.changes.empty && (OO.dispatch(XO.update(bK, {
        scrollIntoView: !0,
        userEvent: pO,
        effects: "delete.selection" == pO ? vK.h.announce.of(XO.phrase("Selection deleted")) : void 0
      })), !0)
    }

    function yp(OO, KO, pO) {
      if (OO instanceof vK.h)
        for (let XO of OO.state.facet(vK.h.atomicRanges).map((KO => KO(OO)))) XO.between(KO, KO, ((OO, XO) => {
          OO < KO && XO > KO && (KO = pO ? XO : OO)
        }));
      return KO
    }
    const gp = (OO, KO, pO) => IK(OO, (XO => {
        let bK, eO, vK = XO.from,
          {
            state: hO
          } = OO,
          DO = hO.doc.lineAt(vK);
        if (pO && !KO && vK > DO.from && vK < DO.from + 200 && !/[^ \t]/.test(bK = DO.text.slice(0, vK - DO.from))) {
          if ("\t" == bK[bK.length - 1]) return vK - 1;
          let OO = (0, lO.U)(bK, hO.tabSize) % (0, CO.L)(hO) || (0, CO.L)(hO);
          for (let KO = 0; KO < OO && " " == bK[bK.length - 1 - KO]; KO++) vK--;
          eO = vK
        } else eO = (0, lO.Y)(DO.text, vK - DO.from, KO, KO) + DO.from, eO == vK && DO.number != (KO ? hO.doc.lines : 1) ? eO += KO ? 1 : -1 : !KO && /[\ufe00-\ufe0f]/.test(DO.text.slice(eO - DO.from, vK - DO.from)) && (eO = (0, lO.Y)(DO.text, eO - DO.from, !1, !1) + DO.from);
        return eO
      })),
      uK = OO => gp(OO, !1, !0),
      EK = OO => gp(OO, !0, !1),
      jp = (OO, KO) => IK(OO, (pO => {
        let XO = pO.head,
          {
            state: bK
          } = OO,
          eO = bK.doc.lineAt(XO),
          vK = bK.charCategorizer(XO);
        for (let OO = null;;) {
          if (XO == (KO ? eO.to : eO.from)) {
            XO == pO.head && eO.number != (KO ? bK.doc.lines : 1) && (XO += KO ? 1 : -1);
            break
          }
          let CO = (0, lO.Y)(eO.text, XO - eO.from, KO) + eO.from,
            hO = eO.text.slice(Math.min(XO, CO) - eO.from, Math.max(XO, CO) - eO.from),
            DO = vK(hO);
          if (null != OO && DO != OO) break;
          " " == hO && XO == pO.head || (OO = DO), XO = CO
        }
        return XO
      })),
      YK = OO => jp(OO, !1);

    function wK(OO) {
      let KO = [],
        pO = -1;
      for (let XO of OO.selection.Xl) {
        let bK = OO.doc.lineAt(XO.from),
          eO = OO.doc.lineAt(XO.to);
        if (XO.empty || XO.to != eO.from || (eO = OO.doc.lineAt(XO.to - 1)), pO >= bK.number) {
          let OO = KO[KO.length - 1];
          OO.to = eO.to, OO.Xl.push(XO)
        } else KO.push({
          from: bK.from,
          to: eO.to,
          Xl: [XO]
        });
        pO = eO.number + 1
      }
      return KO
    }

    function ip(OO, KO, pO) {
      if (OO.readOnly) return !1;
      let XO = [],
        bK = [];
      for (let eO of wK(OO)) {
        if (pO ? eO.to == OO.doc.length : 0 == eO.from) continue;
        let KO = OO.doc.lineAt(pO ? eO.to + 1 : eO.from - 1),
          vK = KO.length + 1;
        if (pO) {
          XO.push({
            from: eO.to,
            to: KO.to
          }, {
            from: eO.from,
            insert: KO.text + OO.lineBreak
          });
          for (let KO of eO.Xl) bK.push(lO.j.range(Math.min(OO.doc.length, KO.anchor + vK), Math.min(OO.doc.length, KO.head + vK)))
        } else {
          XO.push({
            from: KO.from,
            to: eO.from
          }, {
            from: eO.to,
            insert: OO.lineBreak + KO.text
          });
          for (let OO of eO.Xl) bK.push(lO.j.range(OO.anchor - vK, OO.head - vK))
        }
      }
      return !!XO.length && (KO(OO.update({
        changes: XO,
        scrollIntoView: !0,
        selection: lO.j.create(bK, OO.selection.mainIndex),
        userEvent: "move.line"
      })), !0)
    }

    function rp(OO, KO, pO) {
      if (OO.readOnly) return !1;
      let XO = [];
      for (let eO of wK(OO)) pO ? XO.push({
        from: eO.from,
        insert: OO.doc.slice(eO.from, eO.to) + OO.lineBreak
      }) : XO.push({
        from: eO.to,
        insert: OO.lineBreak + OO.doc.slice(eO.from, eO.to)
      });
      let bK = OO.changes(XO);
      return KO(OO.update({
        changes: bK,
        selection: OO.selection.map(bK, pO ? 1 : -1),
        scrollIntoView: !0,
        userEvent: "input.copyline"
      })), !0
    }
    const PK = mp(!1);

    function mp(OO) {
      return KO => {
        let {
          state: pO,
          dispatch: XO
        } = KO;
        if (pO.readOnly) return !1;
        let bK = pO.changeByRange((KO => {
          let {
            from: XO,
            to: bK
          } = KO, eO = pO.doc.lineAt(XO), vK = !OO && XO == bK && function(OO, KO) {
            if (/\(\)|\[\]|\{\}/.test(OO.sliceDoc(KO - 1, KO + 1))) return {
              from: KO,
              to: KO
            };
            let pO, XO = (0, CO.ib)(OO).resolveInner(KO),
              bK = XO.childBefore(KO),
              eO = XO.childAfter(KO);
            return bK && eO && bK.to <= KO && eO.from >= KO && (pO = bK.type.prop(hO.i.closedBy)) && pO.indexOf(eO.name) > -1 && OO.doc.lineAt(bK.to).from == OO.doc.lineAt(eO.from).from && !/\S/.test(OO.sliceDoc(bK.to, eO.from)) ? {
              from: bK.to,
              to: eO.from
            } : null
          }(pO, XO);
          OO && (XO = bK = (bK <= eO.to ? eO : pO.doc.lineAt(bK)).to);
          let DO = new CO.e(pO, {
              simulateBreak: XO,
              simulateDoubleBreak: !!vK
            }),
            MO = (0, CO.M)(DO, XO);
          for (null == MO && (MO = (0, lO.U)(/^\s*/.exec(pO.doc.lineAt(XO).text)[0], pO.tabSize)); bK < eO.to && /\s/.test(eO.text[bK - eO.from]);) bK++;
          vK ? ({
            from: XO,
            to: bK
          } = vK) : XO > eO.from && XO < eO.from + 100 && !/\S/.test(eO.text.slice(0, XO)) && (XO = eO.from);
          let aK = ["", (0, CO.T)(pO, MO)];
          return vK && aK.push((0, CO.T)(pO, DO.lineIndent(eO.from, -1))), {
            changes: {
              from: XO,
              to: bK,
              insert: lO.I.of(aK)
            },
            range: lO.j.cursor(XO + 1 + aK[1].length)
          }
        }));
        return XO(pO.update(bK, {
          scrollIntoView: !0,
          userEvent: "input"
        })), !0
      }
    }

    function sK(OO, KO) {
      let pO = -1;
      return OO.changeByRange((XO => {
        let bK = [];
        for (let lO = XO.from; lO <= XO.to;) {
          let eO = OO.doc.lineAt(lO);
          eO.number > pO && (XO.empty || XO.to > eO.from) && (KO(eO, bK, XO), pO = eO.number), lO = eO.to + 1
        }
        let eO = OO.changes(bK);
        return {
          changes: bK,
          range: lO.j.range(eO.mapPos(XO.anchor, 1), eO.mapPos(XO.head, 1))
        }
      }))
    }
    const HK = OO => {
        let {
          state: KO,
          dispatch: pO
        } = OO;
        return !KO.readOnly && (pO(KO.update(sK(KO, ((OO, pO) => {
          pO.push({
            from: OO.from,
            insert: KO.facet(CO.W)
          })
        })), {
          userEvent: "input.indent"
        })), !0)
      },
      RK = OO => {
        let {
          state: KO,
          dispatch: pO
        } = OO;
        return !KO.readOnly && (pO(KO.update(sK(KO, ((OO, pO) => {
          let XO = /^\s*/.exec(OO.text)[0];
          if (!XO) return;
          let bK = (0, lO.U)(XO, KO.tabSize),
            eO = 0,
            vK = (0, CO.T)(KO, Math.max(0, bK - (0, CO.L)(KO)));
          for (; eO < XO.length && eO < vK.length && XO.charCodeAt(eO) == vK.charCodeAt(eO);) eO++;
          pO.push({
            from: OO.from + eO,
            to: OO.from + XO.length,
            insert: vK.slice(eO)
          })
        })), {
          userEvent: "delete.dedent"
        })), !0)
      },
      SK = [{
        key: "Alt-ArrowLeft",
        mac: "Ctrl-ArrowLeft",
        run: OO => BO(OO, (KO => kK(OO.state, KO, !qK(OO)))),
        shift: OO => CK(OO, (KO => kK(OO.state, KO, !qK(OO))))
      }, {
        key: "Alt-ArrowRight",
        mac: "Ctrl-ArrowRight",
        run: OO => BO(OO, (KO => kK(OO.state, KO, qK(OO)))),
        shift: OO => CK(OO, (KO => kK(OO.state, KO, qK(OO))))
      }, {
        key: "Alt-ArrowUp",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          return ip(KO, pO, !1)
        }
      }, {
        key: "Shift-Alt-ArrowUp",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          return rp(KO, pO, !1)
        }
      }, {
        key: "Alt-ArrowDown",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          return ip(KO, pO, !0)
        }
      }, {
        key: "Shift-Alt-ArrowDown",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          return rp(KO, pO, !0)
        }
      }, {
        key: "Mod-Alt-ArrowUp",
        run: OO => NK(OO, !1)
      }, {
        key: "Mod-Alt-ArrowDown",
        run: OO => NK(OO, !0)
      }, {
        key: "Escape",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO, XO = KO.selection, bK = null;
          return XO.Xl.length > 1 ? bK = lO.j.create([XO.main]) : XO.main.empty || (bK = lO.j.create([lO.j.cursor(XO.main.head)])), !!bK && (pO(cK(KO, bK)), !0)
        }
      }, {
        key: "Mod-Enter",
        run: mp(!0)
      }, {
        key: "Alt-l",
        mac: "Ctrl-l",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO, XO = wK(KO).map((OO => {
            let {
              from: pO,
              to: XO
            } = OO;
            return lO.j.range(pO, Math.min(XO + 1, KO.doc.length))
          }));
          return pO(KO.update({
            selection: lO.j.create(XO),
            userEvent: "select"
          })), !0
        }
      }, {
        key: "Mod-i",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO, XO = JO(KO.selection, (OO => {
            let pO = (0, CO.ib)(KO),
              XO = pO.resolveStack(OO.from, 1);
            if (OO.empty) {
              let KO = pO.resolveStack(OO.from, -1);
              KO.node.from >= XO.node.from && KO.node.to <= XO.node.to && (XO = KO)
            }
            for (let KO = XO; KO; KO = KO.next) {
              let {
                node: pO
              } = KO;
              if ((pO.from < OO.from && pO.to >= OO.to || pO.to > OO.to && pO.from <= OO.from) && KO.next) return lO.j.range(pO.to, pO.from)
            }
            return OO
          }));
          return !XO.eq(KO.selection) && (pO(cK(KO, XO)), !0)
        },
        preventDefault: !0
      }, {
        key: "Mod-[",
        run: RK
      }, {
        key: "Mod-]",
        run: HK
      }, {
        key: "Mod-Alt-\\",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          if (KO.readOnly) return !1;
          let XO = Object.create(null),
            bK = new CO.e(KO, {
              overrideIndentation: OO => {
                let KO = XO[OO];
                return null == KO ? -1 : KO
              }
            }),
            eO = sK(KO, ((OO, pO, eO) => {
              let lO = (0, CO.M)(bK, OO.from);
              if (null == lO) return;
              /\S/.test(OO.text) || (lO = 0);
              let vK = /^\s*/.exec(OO.text)[0],
                hO = (0, CO.T)(KO, lO);
              (vK != hO || eO.from < OO.from + vK.length) && (XO[OO.from] = lO, pO.push({
                from: OO.from,
                to: OO.from + vK.length,
                insert: hO
              }))
            }));
          return eO.changes.empty || pO(KO.update(eO, {
            userEvent: "indent"
          })), !0
        }
      }, {
        key: "Shift-Mod-k",
        run: OO => {
          if (OO.state.readOnly) return !1;
          let {
            state: KO
          } = OO, pO = KO.changes(wK(KO).map((OO => {
            let {
              from: pO,
              to: XO
            } = OO;
            return pO > 0 ? pO-- : XO < KO.doc.length && XO++, {
              from: pO,
              to: XO
            }
          }))), XO = JO(KO.selection, (KO => {
            let pO;
            if (OO.lineWrapping) {
              let XO = OO.lineBlockAt(KO.head),
                bK = OO.coordsAtPos(KO.head, KO.assoc || 1);
              bK && (pO = XO.bottom + OO.documentTop - bK.bottom + OO.defaultLineHeight / 2)
            }
            return OO.moveVertically(KO, !0, pO)
          })).map(pO);
          return OO.dispatch({
            changes: pO,
            selection: XO,
            scrollIntoView: !0,
            userEvent: "delete.line"
          }), !0
        }
      }, {
        key: "Shift-Mod-\\",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          return vp(KO, pO, !1)
        }
      }, {
        key: "Mod-/",
        run: OO => {
          let {
            state: KO
          } = OO, pO = KO.doc.lineAt(KO.selection.main.from), XO = FO(OO.state, pO.from);
          return XO.line ? MO(OO) : !!XO.block && oO(OO)
        }
      }, {
        key: "Alt-A",
        run: aK
      }, {
        key: "Ctrl-m",
        mac: "Shift-Alt-m",
        run: OO => (OO.setTabFocusMode(), !0)
      }].concat([{
        key: "ArrowLeft",
        run: xK,
        shift: DK,
        preventDefault: !0
      }, {
        key: "Mod-ArrowLeft",
        mac: "Alt-ArrowLeft",
        run: OO => WO(OO, !qK(OO)),
        shift: OO => ap(OO, !qK(OO)),
        preventDefault: !0
      }, {
        mac: "Cmd-ArrowLeft",
        run: OO => BO(OO, (KO => lK(OO, KO, !qK(OO)))),
        shift: OO => CK(OO, (KO => lK(OO, KO, !qK(OO)))),
        preventDefault: !0
      }, {
        key: "ArrowRight",
        run: nO,
        shift: MK,
        preventDefault: !0
      }, {
        key: "Mod-ArrowRight",
        mac: "Alt-ArrowRight",
        run: OO => WO(OO, qK(OO)),
        shift: OO => ap(OO, qK(OO)),
        preventDefault: !0
      }, {
        mac: "Cmd-ArrowRight",
        run: OO => BO(OO, (KO => lK(OO, KO, qK(OO)))),
        shift: OO => CK(OO, (KO => lK(OO, KO, qK(OO)))),
        preventDefault: !0
      }, {
        key: "ArrowUp",
        run: OK,
        shift: FK,
        preventDefault: !0
      }, {
        mac: "Cmd-ArrowUp",
        run: AK,
        shift: dK
      }, {
        mac: "Ctrl-ArrowUp",
        run: bp,
        shift: QK
      }, {
        key: "ArrowDown",
        run: KK,
        shift: VK,
        preventDefault: !0
      }, {
        mac: "Cmd-ArrowDown",
        run: fK,
        shift: TK
      }, {
        mac: "Ctrl-ArrowDown",
        run: eK,
        shift: zp
      }, {
        key: "PageUp",
        run: bp,
        shift: QK
      }, {
        key: "PageDown",
        run: eK,
        shift: zp
      }, {
        key: "Home",
        run: OO => BO(OO, (KO => lK(OO, KO, !1))),
        shift: OO => CK(OO, (KO => lK(OO, KO, !1))),
        preventDefault: !0
      }, {
        key: "Mod-Home",
        run: AK,
        shift: dK
      }, {
        key: "End",
        run: OO => BO(OO, (KO => lK(OO, KO, !0))),
        shift: OO => CK(OO, (KO => lK(OO, KO, !0))),
        preventDefault: !0
      }, {
        key: "Mod-End",
        run: fK,
        shift: TK
      }, {
        key: "Enter",
        run: PK,
        shift: PK
      }, {
        key: "Mod-a",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          return pO(KO.update({
            selection: {
              anchor: 0,
              head: KO.doc.length
            },
            userEvent: "select"
          })), !0
        }
      }, {
        key: "Backspace",
        run: uK,
        shift: uK,
        preventDefault: !0
      }, {
        key: "Delete",
        run: EK,
        preventDefault: !0
      }, {
        key: "Mod-Backspace",
        mac: "Alt-Backspace",
        run: YK,
        preventDefault: !0
      }, {
        key: "Mod-Delete",
        mac: "Alt-Delete",
        run: OO => jp(OO, !0),
        preventDefault: !0
      }, {
        mac: "Mod-Backspace",
        run: OO => IK(OO, (KO => {
          let pO = OO.moveToLineBoundary(KO, !1).head;
          return KO.head > pO ? pO : Math.max(0, KO.head - 1)
        })),
        preventDefault: !0
      }, {
        mac: "Mod-Delete",
        run: OO => IK(OO, (KO => {
          let pO = OO.moveToLineBoundary(KO, !0).head;
          return KO.head < pO ? pO : Math.min(OO.state.doc.length, KO.head + 1)
        })),
        preventDefault: !0
      }].concat([{
        key: "Ctrl-b",
        run: xK,
        shift: DK,
        preventDefault: !0
      }, {
        key: "Ctrl-f",
        run: nO,
        shift: MK
      }, {
        key: "Ctrl-p",
        run: OK,
        shift: FK
      }, {
        key: "Ctrl-n",
        run: KK,
        shift: VK
      }, {
        key: "Ctrl-a",
        run: OO => BO(OO, (KO => lO.j.cursor(OO.lineBlockAt(KO.head).from, 1))),
        shift: OO => CK(OO, (KO => lO.j.cursor(OO.lineBlockAt(KO.head).from)))
      }, {
        key: "Ctrl-e",
        run: OO => BO(OO, (KO => lO.j.cursor(OO.lineBlockAt(KO.head).to, -1))),
        shift: OO => CK(OO, (KO => lO.j.cursor(OO.lineBlockAt(KO.head).to)))
      }, {
        key: "Ctrl-d",
        run: EK
      }, {
        key: "Ctrl-h",
        run: uK
      }, {
        key: "Ctrl-k",
        run: OO => IK(OO, (KO => {
          let pO = OO.lineBlockAt(KO.head).to;
          return KO.head < pO ? pO : Math.min(OO.state.doc.length, KO.head + 1)
        }))
      }, {
        key: "Ctrl-Alt-h",
        run: YK
      }, {
        key: "Ctrl-o",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          if (KO.readOnly) return !1;
          let XO = KO.changeByRange((OO => ({
            changes: {
              from: OO.from,
              to: OO.to,
              insert: lO.I.of(["", ""])
            },
            range: lO.j.cursor(OO.from)
          })));
          return pO(KO.update(XO, {
            scrollIntoView: !0,
            userEvent: "input"
          })), !0
        }
      }, {
        key: "Ctrl-t",
        run: OO => {
          let {
            state: KO,
            dispatch: pO
          } = OO;
          if (KO.readOnly) return !1;
          let XO = KO.changeByRange((OO => {
            if (!OO.empty || 0 == OO.from || OO.from == KO.doc.length) return {
              range: OO
            };
            let pO = OO.from,
              XO = KO.doc.lineAt(pO),
              bK = pO == XO.from ? pO - 1 : (0, lO.Y)(XO.text, pO - XO.from, !1) + XO.from,
              eO = pO == XO.to ? pO + 1 : (0, lO.Y)(XO.text, pO - XO.from, !0) + XO.from;
            return {
              changes: {
                from: bK,
                to: eO,
                insert: KO.doc.slice(pO, eO).append(KO.doc.slice(bK, pO))
              },
              range: lO.j.cursor(eO)
            }
          }));
          return !XO.changes.empty && (pO(KO.update(XO, {
            scrollIntoView: !0,
            userEvent: "move.character"
          })), !0)
        }
      }, {
        key: "Ctrl-v",
        run: eK
      }].map((OO => ({
        mac: OO.key,
        run: OO.run,
        shift: OO.shift
      }))))),
      JK = {
        key: "Tab",
        run: HK,
        shift: RK
      };
    var cp = pO(39375),
      BK = pO(39336),
      ZK = pO(39384),
      GK = function(OO) {
        void 0 === OO && (OO = {});
        var {
          crosshairCursor: KO = !1
        } = OO, pO = [];
        !1 !== OO.closeBracketsKeymap && (pO = pO.concat(BK.f)), !1 !== OO.defaultKeymap && (pO = pO.concat(SK)), !1 !== OO.searchKeymap && (pO = pO.concat(cp.j)), !1 !== OO.historyKeymap && (pO = pO.concat(SO)), !1 !== OO.foldKeymap && (pO = pO.concat(CO.G)), !1 !== OO.completionKeymap && (pO = pO.concat(BK.k)), !1 !== OO.lintKeymap && (pO = pO.concat(ZK.c));
        var XO = [];
        return !1 !== OO.lineNumbers && XO.push((0, vK.Q)()), !1 !== OO.highlightActiveLineGutter && XO.push((0, vK.F)()), !1 !== OO.highlightSpecialChars && XO.push((0, vK.K)()), !1 !== OO.history && XO.push(function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          return [TO, dO.of(OO), vK.h.domEventHandlers({
            beforeinput(OO, KO) {
              let pO = "historyUndo" == OO.inputType ? IO : "historyRedo" == OO.inputType ? yK : null;
              return !!pO && (OO.preventDefault(), pO(KO))
            }
          })]
        }()), !1 !== OO.foldGutter && XO.push((0, CO.z)()), !1 !== OO.drawSelection && XO.push((0, vK.s)()), !1 !== OO.dropCursor && XO.push((0, vK.v)()), !1 !== OO.allowMultipleSelections && XO.push(lO.m.allowMultipleSelections.of(!0)), !1 !== OO.indentOnInput && XO.push((0, CO.S)()), !1 !== OO.syntaxHighlighting && XO.push((0, CO.eb)(CO.o, {
          fallback: !0
        })), !1 !== OO.bracketMatching && XO.push((0, CO.k)()), !1 !== OO.closeBrackets && XO.push((0, BK.i)()), !1 !== OO.autocompletion && XO.push((0, BK.c)()), !1 !== OO.rectangularSelection && XO.push((0, vK.U)()), !1 !== KO && XO.push((0, vK.p)()), !1 !== OO.highlightActiveLine && XO.push((0, vK.I)()), !1 !== OO.highlightSelectionMatches && XO.push((0, cp.h)()), OO.tabSize && "number" === typeof OO.tabSize && XO.push(CO.W.of(" ".repeat(OO.tabSize))), XO.concat([vK.O.of(pO.flat())]).filter(Boolean)
      },
      qp = pO(39358);
    const xp = "#e5c07b",
      nK = "#e06c75",
      WK = "#56b6c2",
      tp = "#ffffff",
      kp = "#abb2bf",
      UK = "#7d8799",
      Op = "#61afef",
      Kp = "#98c379",
      pp = "#d19a66",
      Xp = "#c678dd",
      bX = "#21252b",
      ep = "#2c313a",
      lp = "#282c34",
      vX = "#353a42",
      Cp = "#3E4451",
      hp = "#528bff",
      Dp = vK.h.theme({
        "&": {
          color: kp,
          backgroundColor: lp
        },
        ".cm-content": {
          caretColor: hp
        },
        ".cm-cursor, .cm-dropCursor": {
          borderLeftColor: hp
        },
        "&.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection": {
          backgroundColor: Cp
        },
        ".cm-panels": {
          backgroundColor: bX,
          color: kp
        },
        ".cm-panels.cm-panels-top": {
          borderBottom: "2px solid black"
        },
        ".cm-panels.cm-panels-bottom": {
          borderTop: "2px solid black"
        },
        ".cm-searchMatch": {
          backgroundColor: "#72a1ff59",
          outline: "1px solid #457dff"
        },
        ".cm-searchMatch.cm-searchMatch-selected": {
          backgroundColor: "#6199ff2f"
        },
        ".cm-activeLine": {
          backgroundColor: "#6699ff0b"
        },
        ".cm-selectionMatch": {
          backgroundColor: "#aafe661a"
        },
        "&.cm-focused .cm-matchingBracket, &.cm-focused .cm-nonmatchingBracket": {
          backgroundColor: "#bad0f847"
        },
        ".cm-gutters": {
          backgroundColor: lp,
          color: UK,
          border: "none"
        },
        ".cm-activeLineGutter": {
          backgroundColor: ep
        },
        ".cm-foldPlaceholder": {
          backgroundColor: "transparent",
          border: "none",
          color: "#ddd"
        },
        ".cm-tooltip": {
          border: "none",
          backgroundColor: vX
        },
        ".cm-tooltip .cm-tooltip-arrow:before": {
          borderTopColor: "transparent",
          borderBottomColor: "transparent"
        },
        ".cm-tooltip .cm-tooltip-arrow:after": {
          borderTopColor: vX,
          borderBottomColor: vX
        },
        ".cm-tooltip-autocomplete": {
          "& > ul > li[aria-selected]": {
            backgroundColor: ep,
            color: kp
          }
        }
      }, {
        dark: !0
      }),
      Mp = CO.d.define([{
        tag: qp.l.keyword,
        color: Xp
      }, {
        tag: [qp.l.name, qp.l.deleted, qp.l.character, qp.l.propertyName, qp.l.macroName],
        color: nK
      }, {
        tag: [qp.l.function(qp.l.variableName), qp.l.labelName],
        color: Op
      }, {
        tag: [qp.l.color, qp.l.constant(qp.l.name), qp.l.standard(qp.l.name)],
        color: pp
      }, {
        tag: [qp.l.definition(qp.l.name), qp.l.separator],
        color: kp
      }, {
        tag: [qp.l.typeName, qp.l.className, qp.l.number, qp.l.changed, qp.l.annotation, qp.l.modifier, qp.l.self, qp.l.namespace],
        color: xp
      }, {
        tag: [qp.l.operator, qp.l.operatorKeyword, qp.l.url, qp.l.escape, qp.l.regexp, qp.l.link, qp.l.special(qp.l.string)],
        color: WK
      }, {
        tag: [qp.l.meta, qp.l.comment],
        color: UK
      }, {
        tag: qp.l.strong,
        fontWeight: "bold"
      }, {
        tag: qp.l.emphasis,
        fontStyle: "italic"
      }, {
        tag: qp.l.strikethrough,
        textDecoration: "line-through"
      }, {
        tag: qp.l.link,
        color: UK,
        textDecoration: "underline"
      }, {
        tag: qp.l.heading,
        fontWeight: "bold",
        color: nK
      }, {
        tag: [qp.l.atom, qp.l.bool, qp.l.special(qp.l.variableName)],
        color: pp
      }, {
        tag: [qp.l.processingInstruction, qp.l.string, qp.l.inserted],
        color: Kp
      }, {
        tag: qp.l.invalid,
        color: tp
      }]),
      aX = [Dp, (0, CO.eb)(Mp)];
    var op = vK.h.theme({
      "&": {
        backgroundColor: "#fff"
      }
    }, {
      dark: !1
    });
    class Fp {
      constructor(OO, KO) {
        this.timeLeftMS = void 0, this.timeoutMS = void 0, this.isCancelled = !1, this.isTimeExhausted = !1, this.callbacks = [], this.timeLeftMS = KO, this.timeoutMS = KO, this.callbacks.push(OO)
      }
      KK() {
        if (!this.isCancelled && !this.isTimeExhausted && (this.timeLeftMS--, this.timeLeftMS <= 0)) {
          this.isTimeExhausted = !0;
          var OO = this.callbacks.slice();
          this.callbacks.length = 0, OO.forEach((OO => {
            try {
              OO()
            } catch (KO) {
              console.error("TimeoutLatch callback error:", KO)
            }
          }))
        }
      }
      cancel() {
        this.isCancelled = !0, this.callbacks.length = 0
      }
      reset() {
        this.timeLeftMS = this.timeoutMS, this.isCancelled = !1, this.isTimeExhausted = !1
      }
      get isDone() {
        return this.isCancelled || this.isTimeExhausted
      }
    }
    class Vp {
      constructor() {
        this.interval = null, this.latches = new Set
      }
      add(OO) {
        this.latches.add(OO), this.start()
      }
      remove(OO) {
        this.latches.delete(OO), 0 === this.latches.size && this.stop()
      }
      start() {
        null === this.interval && (this.interval = setInterval((() => {
          this.latches.forEach((OO => {
            OO.KK(), OO.isDone && this.remove(OO)
          }))
        }), 1))
      }
      stop() {
        null !== this.interval && (clearInterval(this.interval), this.interval = null)
      }
    }
    var Lp = null,
      Qp = lO.d.define(),
      zX = [];

    function Ap(OO) {
      var {
        value: KO,
        selection: pO,
        onChange: XO,
        onStatistics: bK,
        onCreateEditor: CO,
        onUpdate: hO,
        extensions: DO = zX,
        autoFocus: MO,
        theme: aK = "light",
        height: oO = null,
        minHeight: FO = null,
        maxHeight: VO = null,
        width: LO = null,
        minWidth: QO = null,
        maxWidth: zK = null,
        placeholder: AO = "",
        editable: fO = !0,
        readOnly: dO = !1,
        indentWithTab: TO = !0,
        basicSetup: NO = !0,
        root: IO,
        initialState: yK
      } = OO, [gK, uO] = (0, eO.useState)(), [EO, jK] = (0, eO.useState)(), [YO, wO] = (0, eO.useState)(), iK = (0, eO.useState)((() => ({
        current: null
      })))[0], rK = (0, eO.useState)((() => ({
        current: null
      })))[0], PO = vK.h.theme({
        "&": {
          height: oO,
          minHeight: FO,
          maxHeight: VO,
          width: LO,
          minWidth: QO,
          maxWidth: zK
        },
        "& .cm-scroller": {
          height: "100% !important"
        }
      }), mK = vK.h.updateListener.of((OO => {
        if (OO.docChanged && "function" === typeof XO && !OO.transactions.some((OO => OO.annotation(Qp)))) {
          iK.current ? iK.current.reset() : (iK.current = new Fp((() => {
            if (rK.current) {
              var OO = rK.current;
              rK.current = null, OO()
            }
            iK.current = null
          }), 200), ("undefined" === typeof window ? new Vp : (Lp || (Lp = new Vp), Lp)).add(iK.current));
          var KO = OO.state.doc.toString();
          XO(KO, OO)
        }
        bK && bK((OO => ({
          line: OO.state.doc.lineAt(OO.state.selection.main.from),
          lineCount: OO.state.doc.lines,
          lineBreak: OO.state.lineBreak,
          length: OO.state.doc.length,
          readOnly: OO.state.readOnly,
          tabSize: OO.state.tabSize,
          selection: OO.state.selection,
          selectionAsSingle: OO.state.selection.asSingle().main,
          Xl: OO.state.selection.Xl,
          selectionCode: OO.state.sliceDoc(OO.state.selection.main.from, OO.state.selection.main.to),
          selections: OO.state.selection.Xl.map((KO => OO.state.sliceDoc(KO.from, KO.to))),
          selectedText: OO.state.selection.Xl.some((OO => !OO.empty))
        }))(OO))
      })), sO = function(OO) {
        void 0 === OO && (OO = {});
        var {
          indentWithTab: KO = !0,
          editable: pO = !0,
          readOnly: XO = !1,
          theme: bK = "light",
          placeholder: eO = "",
          basicSetup: CO = !0
        } = OO, hO = [];
        switch (KO && hO.unshift(vK.O.of([JK])), CO && ("boolean" === typeof CO ? hO.unshift(GK()) : hO.unshift(GK(CO))), eO && hO.unshift((0, vK.T)(eO)), bK) {
          case "light":
            hO.push(op);
            break;
          case "dark":
            hO.push(aX);
            break;
          case "none":
            break;
          default:
            hO.push(bK)
        }
        return !1 === pO && hO.push(vK.h.editable.of(!1)), XO && hO.push(lO.m.readOnly.of(!0)), [...hO]
      }({
        theme: aK,
        editable: fO,
        readOnly: dO,
        placeholder: AO,
        indentWithTab: TO,
        basicSetup: NO
      }), HO = [mK, PO, ...sO];
      return hO && "function" === typeof hO && HO.push(vK.h.updateListener.of(hO)), HO = HO.concat(DO), (0, eO.useLayoutEffect)((() => {
        if (gK && !YO) {
          var OO = {
              doc: KO,
              selection: pO,
              extensions: HO
            },
            XO = yK ? lO.m.fromJSON(yK.json, OO, yK.fields) : lO.m.create(OO);
          if (wO(XO), !EO) {
            var bK = new vK.h({
              state: XO,
              parent: gK,
              root: IO
            });
            jK(bK), CO && CO(bK, XO)
          }
        }
        return () => {
          EO && (wO(void 0), jK(void 0))
        }
      }), [gK, YO]), (0, eO.useEffect)((() => {
        OO.container && uO(OO.container)
      }), [OO.container]), (0, eO.useEffect)((() => () => {
        EO && (EO.destroy(), jK(void 0)), iK.current && (iK.current.cancel(), iK.current = null)
      }), [EO]), (0, eO.useEffect)((() => {
        MO && EO && EO.focus()
      }), [MO, EO]), (0, eO.useEffect)((() => {
        EO && EO.dispatch({
          effects: lO.C.reconfigure.of(HO)
        })
      }), [aK, DO, oO, FO, VO, LO, QO, zK, AO, fO, dO, TO, NO, XO, hO]), (0, eO.useEffect)((() => {
        if (void 0 !== KO) {
          var OO = EO ? EO.state.doc.toString() : "";
          if (EO && KO !== OO) {
            var pO = () => {
              EO && KO !== EO.state.doc.toString() && EO.dispatch({
                changes: {
                  from: 0,
                  to: EO.state.doc.toString().length,
                  insert: KO || ""
                },
                annotations: [Qp.of(!0)]
              })
            };
            iK.current && !iK.current.isDone ? rK.current = pO : pO()
          }
        }
      }), [KO, EO]), {
        state: YO,
        setState: wO,
        view: EO,
        setView: jK,
        container: gK,
        setContainer: uO
      }
    }
    var fp = pO(976),
      dp = ["className", "value", "selection", "extensions", "onChange", "onStatistics", "onCreateEditor", "onUpdate", "autoFocus", "theme", "height", "minHeight", "maxHeight", "width", "minWidth", "maxWidth", "basicSetup", "placeholder", "indentWithTab", "editable", "readOnly", "root", "initialState"],
      Tp = (0, eO.forwardRef)(((OO, KO) => {
        var {
          className: pO,
          value: lO = "",
          selection: vK,
          extensions: CO = [],
          onChange: hO,
          onStatistics: DO,
          onCreateEditor: MO,
          onUpdate: aK,
          autoFocus: oO,
          theme: FO = "light",
          height: VO,
          minHeight: LO,
          maxHeight: QO,
          width: zK,
          minWidth: AO,
          maxWidth: fO,
          basicSetup: dO,
          placeholder: TO,
          indentWithTab: NO,
          editable: IO,
          readOnly: yK,
          root: gK,
          initialState: uO
        } = OO, EO = (0, bK.e)(OO, dp), jK = (0, eO.useRef)(null), {
          state: YO,
          view: wO,
          container: iK,
          setContainer: rK
        } = Ap({
          root: gK,
          value: lO,
          autoFocus: oO,
          theme: FO,
          height: VO,
          minHeight: LO,
          maxHeight: QO,
          width: zK,
          minWidth: AO,
          maxWidth: fO,
          basicSetup: dO,
          placeholder: TO,
          indentWithTab: NO,
          editable: IO,
          readOnly: yK,
          selection: vK,
          onChange: hO,
          onStatistics: DO,
          onCreateEditor: MO,
          onUpdate: aK,
          extensions: CO,
          initialState: uO
        });
        (0, eO.useImperativeHandle)(KO, (() => ({
          editor: jK.current,
          state: YO,
          view: wO
        })), [jK, iK, YO, wO]);
        var PO = (0, eO.useCallback)((OO => {
          jK.current = OO, rK(OO)
        }), [rK]);
        if ("string" !== typeof lO) throw new Error("value must be typeof string but got " + typeof lO);
        var mK = "string" === typeof FO ? "cm-theme-" + FO : "cm-theme";
        return (0, fp.jsx)("div", (0, XO.d)({
          ref: PO,
          className: mK + (pO ? " " + pO : "")
        }, EO))
      }));
    Tp.displayName = "CodeMirror";
    const Np = Tp
  },
  39345: (OO, KO, pO) => {
    function XO() {
      var OO = arguments[0];
      "string" == typeof OO && (OO = document.createElement(OO));
      var KO = 1,
        pO = arguments[1];
      if (pO && "object" == typeof pO && null == pO.nodeType && !Array.isArray(pO)) {
        for (var XO in pO)
          if (Object.prototype.hasOwnProperty.call(pO, XO)) {
            var eO = pO[XO];
            "string" == typeof eO ? OO.setAttribute(XO, eO) : null != eO && (OO[XO] = eO)
          } KO++
      }
      for (; KO < arguments.length; KO++) bK(OO, arguments[KO]);
      return OO
    }

    function bK(OO, KO) {
      if ("string" == typeof KO) OO.appendChild(document.createTextNode(KO));
      else if (null == KO);
      else if (null != KO.nodeType) OO.appendChild(KO);
      else {
        if (!Array.isArray(KO)) throw new RangeError("Unsupported child node: " + KO);
        for (var pO = 0; pO < KO.length; pO++) bK(OO, KO[pO])
      }
    }
    pO.d(KO, {
      b: () => XO
    })
  },
  39343: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    const XO = "undefined" == typeof Symbol ? "__\u037c" : Symbol.for("\u037c"),
      bK = "undefined" == typeof Symbol ? "__styleSet" + Math.floor(1e8 * Math.random()) : Symbol("styleSet"),
      eO = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : {};
    class lO {
      constructor(OO, KO) {
        this.rules = [];
        let {
          finish: pO
        } = KO || {};

        function XO(OO) {
          return /^@/.test(OO) ? [OO] : OO.split(/,\s*/)
        }

        function bK(OO, KO, eO, lO) {
          let vK = [],
            CO = /^@(\w+)\b/.exec(OO[0]),
            hO = CO && "keyframes" == CO[1];
          if (CO && null == KO) return eO.push(OO[0] + ";");
          for (let pO in KO) {
            let lO = KO[pO];
            if (/&/.test(pO)) bK(pO.split(/,\s*/).map((KO => OO.map((OO => KO.replace(/&/, OO))))).reduce(((OO, KO) => OO.concat(KO))), lO, eO);
            else if (lO && "object" == typeof lO) {
              if (!CO) throw new RangeError("The value of a property (" + pO + ") should be a primitive value.");
              bK(XO(pO), lO, vK, hO)
            } else null != lO && vK.push(pO.replace(/_.*/, "").replace(/[A-Z]/g, (OO => "-" + OO.toLowerCase())) + ": " + lO + ";")
          }(vK.length || hO) && eO.push((!pO || CO || lO ? OO : OO.map(pO)).join(", ") + " {" + vK.join(" ") + "}")
        }
        for (let eO in OO) bK(XO(eO), OO[eO], this.rules)
      }
      getRules() {
        return this.rules.join("\n")
      }
      static newName() {
        let OO = eO[XO] || 1;
        return eO[XO] = OO + 1, "\u037c" + OO.toString(36)
      }
      static mount(OO, KO, pO) {
        let XO = OO[bK],
          eO = pO && pO.nonce;
        XO ? eO && XO.setNonce(eO) : XO = new CO(OO, eO), XO.mount(Array.isArray(KO) ? KO : [KO], OO)
      }
    }
    let vK = new Map;
    class CO {
      constructor(OO, KO) {
        let pO = OO.ownerDocument || OO,
          XO = pO.defaultView;
        if (!OO.head && OO.adoptedStyleSheets && XO.CSSStyleSheet) {
          let KO = vK.get(pO);
          if (KO) return OO[bK] = KO;
          this.sheet = new XO.CSSStyleSheet, vK.set(pO, this)
        } else this.styleTag = pO.createElement("style"), KO && this.styleTag.setAttribute("nonce", KO);
        this.modules = [], OO[bK] = this
      }
      mount(OO, KO) {
        let pO = this.sheet,
          XO = 0,
          bK = 0;
        for (let eO = 0; eO < OO.length; eO++) {
          let KO = OO[eO],
            lO = this.modules.indexOf(KO);
          if (lO < bK && lO > -1 && (this.modules.splice(lO, 1), bK--, lO = -1), -1 == lO) {
            if (this.modules.splice(bK++, 0, KO), pO)
              for (let OO = 0; OO < KO.rules.length; OO++) pO.insertRule(KO.rules[OO], XO++)
          } else {
            for (; bK < lO;) XO += this.modules[bK++].rules.length;
            XO += KO.rules.length, bK++
          }
        }
        if (pO) KO.adoptedStyleSheets.indexOf(this.sheet) < 0 && (KO.adoptedStyleSheets = [this.sheet, ...KO.adoptedStyleSheets]);
        else {
          let OO = "";
          for (let KO = 0; KO < this.modules.length; KO++) OO += this.modules[KO].getRules() + "\n";
          this.styleTag.textContent = OO;
          let pO = KO.head || KO;
          this.styleTag.parentNode != pO && pO.insertBefore(this.styleTag, pO.firstChild)
        }
      }
      setNonce(OO) {
        this.styleTag && this.styleTag.getAttribute("nonce") != OO && this.styleTag.setAttribute("nonce", OO)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);