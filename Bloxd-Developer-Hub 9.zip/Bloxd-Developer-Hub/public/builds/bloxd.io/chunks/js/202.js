export const id = 202;
export const ids = [202];
export const modules = {
  39553: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO
    });
    var XO = pO(63),
      bK = pO(2209);

    function eO(OO, KO, pO) {
      const eO = (0, XO.useRef)(null),
        {
          width: lO,
          height: vK
        } = (0, bK.d)(OO);
      (0, XO.useEffect)((() => {
        const pO = KO(OO.current);
        return eO.current = pO, () => {
          pO.close(), eO.current = null
        }
      }), [OO, KO]), (0, XO.useEffect)((() => {
        lO <= 0 || vK <= 0 || eO.current.resize(lO, vK)
      }), [lO, vK]), (0, XO.useEffect)((() => {
        eO.current.show(pO)
      }), [pO])
    }
  },
  39555: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => aK,
      f: () => MO,
      h: () => CO
    });
    var XO = pO(35966),
      bK = pO(37020);

    function eO(OO, KO) {
      let [pO, XO, bK] = OO;
      return [0, .5, 1].map((OO => ({
        timeFraction: OO,
        rotation: {
          U6: "catmull-rom-spline",
          point: [pO, XO, bK + (.5 === OO ? KO : 0)]
        }
      })))
    }

    function lO(OO, KO, pO) {
      return {
        w6: 3200,
        loop: !0,
        r4: {
          Root: {
            timeline: [0, .5, 1].map((OO => ({
              timeFraction: OO,
              position: {
                U6: "catmull-rom-spline",
                point: [0, .5 === OO ? .18 : 0, 0]
              }
            })))
          },
          HeadMesh: {
            timeline: [0, .25, .75, 1].map((OO => ({
              timeFraction: OO,
              rotation: {
                U6: "catmull-rom-spline",
                point: [0, .25 === OO ? .12 : .75 === OO ? -.12 : 0, 0]
              }
            })))
          },
          ArmLeftMesh: {
            timeline: eO(OO, pO)
          },
          ArmRightMesh: {
            timeline: eO(KO, -pO)
          }
        }
      }
    }
    const vK = lO([0, 0, 0], [0, 0, 0], .07),
      CO = (0, bK.d)((0, XO.g)(vK), "mobIdle"),
      hO = lO([-.2 * Math.PI, -.15 * Math.PI, 0], [-.1 * Math.PI, .18 * Math.PI, 0], .02),
      DO = lO([-.4 * Math.PI, -.15 * Math.PI, 0], [-.3 * Math.PI, .18 * Math.PI, 0], .02),
      MO = (0, bK.d)((0, XO.g)(hO), "gunReady"),
      aK = (0, bK.d)((0, XO.g)(DO), "gunAimed")
  },
  37020: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      e: () => eO
    });
    const XO = new WeakMap;

    function bK(OO, KO) {
      return XO.set(OO, KO), OO
    }

    function eO(OO) {
      var KO;
      return null !== (KO = XO.get(OO)) && void 0 !== KO ? KO : null
    }
  },
  35338: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO.b
    });
    var XO = pO(35340);
    class bK {
      constructor(OO) {
        this.load = OO, this.loaded = null, this.loading = null
      }
      run(OO) {
        return null !== this.loaded ? OO(this.loaded) : (this.loading ??= this.load().then((OO => (this.loaded = OO, OO)), (OO => {
          throw this.loading = null, OO
        })), this.loading.then(OO))
      }
    }
    class eO {
      constructor() {
        this.mobScene = new bK((() => Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(65), pO.e(233), pO.e(63), pO.e(64), pO.e(243), pO.e(237), pO.e(242), pO.e(240), pO.e(232), pO.e(206), pO.e(271), pO.e(211), pO.e(225), pO.e(238), pO.e(241), pO.e(127), pO.e(183), pO.e(207), pO.e(219), pO.e(205), pO.e(105), pO.e(103), pO.e(272), pO.e(147)]).then((() => pO(39228))))), this.characterScene = new bK((() => Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(65), pO.e(233), pO.e(63), pO.e(64), pO.e(243), pO.e(237), pO.e(242), pO.e(240), pO.e(232), pO.e(206), pO.e(271), pO.e(211), pO.e(225), pO.e(238), pO.e(241), pO.e(127), pO.e(183), pO.e(207), pO.e(219), pO.e(205), pO.e(105), pO.e(103), pO.e(272), pO.e(146)]).then((() => pO(39319)))))
      }
      openMob(OO) {
        return this.mobScene.run((KO => KO.openMobPreview(OO)))
      }
      openPet(OO) {
        return this.mobScene.run((KO => KO.openPetPreview(OO)))
      }
      openMobLineup(OO) {
        return this.mobScene.run((KO => KO.openMobLineupPreview(OO)))
      }
      openCharacter(OO) {
        return this.characterScene.run((KO => KO.openCharacterPreview(OO)))
      }
    }
    XO.b.setDefaultHost((() => new eO))
  },
  39766: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      FrontlineMvpLineup: () => MO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(35338),
      vK = pO(39555),
      CO = pO(39553),
      hO = pO(976);

    function DO(OO) {
      return lO.e.openMobLineup(OO)
    }
    const MO = (0, XO.memo)((function(OO) {
      let {
        players: KO,
        className: pO
      } = OO;
      const bK = (0, XO.useRef)(null),
        lO = (0, XO.useMemo)((() => KO.map((OO => {
          let {
            cosmetics: KO,
            size: pO,
            heldGun: XO
          } = OO;
          return {
            cosmetics: KO,
            size: pO,
            XE: XO.name,
            animation: XO.aimed ? vK.e : vK.f
          }
        }))), [KO]),
        MO = function(OO) {
          const [KO, pO] = (0, XO.useState)([]);
          return (0, XO.useEffect)((() => {
            pO(OO.map((() => !1)));
            const KO = OO.map(((OO, KO) => {
              let {
                showAfterMs: XO
              } = OO;
              return window.setTimeout((() => {
                pO((OO => OO.map(((OO, pO) => OO || pO === KO))))
              }), XO)
            }));
            return () => {
              for (const OO of KO) window.clearTimeout(OO)
            }
          }), [OO]), KO
        }(KO),
        aK = (0, XO.useMemo)((() => ({
          figures: lO,
          shown: MO
        })), [lO, MO]);
      return (0, CO.b)(bK, DO, aK), (0, hO.jsx)("div", {
        className: eO()("MobPreview", pO),
        ref: bK
      })
    }))
  },
  35966: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK,
      g: () => lO
    });
    var XO = pO(35959),
      bK = pO(256),
      eO = pO(1531);

    function lO(OO) {
      if ("w6" in OO) return TO.createAnimationScript(OO);
      return new hO(OO).createAnimationScript()
    }

    function vK(OO, KO, pO, bK) {
      const eO = OO.w6 <= 0 ? 1 : KO + pO * Math.max(0, bK) / OO.w6;
      return OO.i4 === XO.j.LoopOnLastFrame ? eO % 1 : OO.i4 === XO.j.NoLoop && eO >= 1 ? null : Math.min(1, eO)
    }
    class CO {
      createAnimationScript(OO) {
        const {
          w6: KO,
          loop: pO,
          r4: XO
        } = OO;
        return {
          w6: Math.round(KO),
          i4: this.createLoopMode(null !== pO && void 0 !== pO && pO),
          r4: this.createNodeSkeletonAnimationScript(null !== XO && void 0 !== XO ? XO : null)
        }
      }
      createLoopMode(OO) {
        switch (OO) {
          case !1:
            return XO.j.NoLoop;
          case !0:
            return XO.j.LoopOnLastFrame;
          case "hold-on-last-frame":
            return XO.j.HoldOnLastFrame
        }
        throw new Error(`Invalid loop mode schema: ${OO}`)
      }
      createNodeSkeletonAnimationScript(OO) {
        if (null === OO) return null;
        const KO = {};
        for (const pO in OO) {
          const XO = OO[pO];
          KO[pO] = this.createNodeAnimationScript(XO)
        }
        return KO
      }
      createNodeAnimationScript(OO) {
        const {
          timeline: KO
        } = OO, pO = KO.filter((OO => Number.isFinite(OO.timeFraction)));
        return pO.sort(((OO, KO) => OO.timeFraction - KO.timeFraction)), {
          rotation: this.createTimelineFromKeyframes(pO, "rotation", aK),
          position: this.createTimelineFromKeyframes(pO, "position", FO)
        }
      }
      createTimelineFromKeyframes(OO, KO, pO) {
        const XO = [];
        for (const CO of OO) {
          const OO = CO[KO];
          if (OO) {
            const KO = this.createAnimationFrameWithoutPrecomputes(CO.timeFraction, OO);
            DO(KO) && XO.push(KO)
          }
        }
        const bK = [];
        for (let CO = 0; CO < XO.length; CO++) {
          var eO, lO, vK;
          const OO = XO[CO],
            KO = null !== (eO = XO[CO - 1]) && void 0 !== eO ? eO : OO,
            hO = null !== (lO = XO[CO + 1]) && void 0 !== lO ? lO : OO,
            DO = null !== (vK = XO[CO + 2]) && void 0 !== vK ? vK : hO;
          bK.push({
            ...OO,
            ...pO(KO.post, KO.timeFraction, OO.post, OO.timeFraction, hO.pre, hO.timeFraction, DO.pre, DO.timeFraction)
          })
        }
        return bK
      }
      createAnimationFrameWithoutPrecomputes(OO, KO) {
        let pO, XO, bK = null;
        var eO;
        if ("object" === typeof KO && "point" in KO) bK = null !== (eO = KO.U6) && void 0 !== eO ? eO : null, pO = KO.point, XO = KO.point;
        else if ("object" === typeof KO && "pre" in KO) {
          var lO;
          bK = null !== (lO = KO.U6) && void 0 !== lO ? lO : null, pO = KO.pre, XO = KO.post
        } else pO = KO, XO = KO;
        return {
          timeFraction: OO,
          U6: this.createLerpMode(bK),
          pre: pO,
          post: XO
        }
      }
      createLerpMode(OO) {
        return null === OO ? XO.i.Linear : CO.LERP_MODE_SCHEMA_MAPPING[OO]
      }
    }
    CO.LERP_MODE_SCHEMA_MAPPING = {
      linear: XO.i.Linear,
      "catmull-rom-spline": XO.i.CatmullRomSpline
    };
    class hO {
      constructor(OO) {
        this.animationSchema = OO
      }
      createAnimationScript() {
        const {
          animation_length: OO,
          loop: KO,
          bones: pO
        } = this.animationSchema;
        return {
          w6: Math.round(1e3 * OO),
          i4: this.createLoopMode(null !== KO && void 0 !== KO && KO),
          r4: this.createNodeSkeletonAnimationScript(null !== pO && void 0 !== pO ? pO : null)
        }
      }
      createLoopMode(OO) {
        switch (OO) {
          case !1:
            return XO.j.NoLoop;
          case !0:
            return XO.j.LoopOnLastFrame;
          case "hold_on_last_frame":
            return XO.j.HoldOnLastFrame
        }
        throw new Error(`Invalid Blockbench loop mode schema: ${OO}`)
      }
      createNodeSkeletonAnimationScript(OO) {
        if (null === OO) return null;
        const KO = {};
        for (const pO in OO) {
          const XO = OO[pO];
          KO[pO] = this.createNodeAnimationScript(XO)
        }
        return KO
      }
      createNodeAnimationScript(OO) {
        const {
          rotation: KO,
          position: pO
        } = OO;
        return {
          rotation: this.createAnimationTimeline(null !== KO && void 0 !== KO ? KO : null, LO, aK, !0),
          position: this.createAnimationTimeline(null !== pO && void 0 !== pO ? pO : null, zK, FO, !1)
        }
      }
      createAnimationTimeline(OO, KO, pO, XO) {
        if (null === OO) return [];
        if (Array.isArray(OO)) {
          OO = {
            "0.0": OO
          }
        }
        const bK = Object.entries(OO).map((OO => {
          let [pO, XO] = OO;
          const bK = Number(pO) / this.animationSchema.animation_length;
          return this.createAnimationFrameWithoutPrecomputes(bK, XO, KO)
        })).filter(DO);
        bK.sort(((OO, KO) => OO.timeFraction - KO.timeFraction)), XO && function(OO) {
          for (let KO = 1; KO < OO.length; KO++) {
            const pO = OO[KO - 1].post,
              XO = OO[KO],
              bK = AO(XO.pre),
              eO = AO(XO.post),
              lO = dO(pO, XO.pre);
            dO(pO, bK) < lO && (OO[KO] = {
              ...XO,
              pre: bK,
              post: eO
            })
          }
        }(bK);
        const eO = [];
        for (let hO = 0; hO < bK.length; hO++) {
          var lO, vK, CO;
          const OO = bK[hO],
            KO = null !== (lO = bK[hO - 1]) && void 0 !== lO ? lO : OO,
            XO = null !== (vK = bK[hO + 1]) && void 0 !== vK ? vK : OO,
            DO = null !== (CO = bK[hO + 2]) && void 0 !== CO ? CO : XO;
          eO.push({
            ...OO,
            ...pO(KO.post, KO.timeFraction, OO.post, OO.timeFraction, XO.pre, XO.timeFraction, DO.pre, DO.timeFraction)
          })
        }
        return eO
      }
      createAnimationFrameWithoutPrecomputes(OO, KO, pO) {
        let XO, bK, eO = null;
        if ("object" === typeof KO && "post" in KO) {
          var lO;
          eO = null !== (lO = KO.lerp_mode) && void 0 !== lO ? lO : null, bK = VO(KO.post, pO), XO = KO.pre ? VO(KO.pre, pO) : bK
        } else {
          const OO = VO(KO, pO);
          bK = OO, XO = OO
        }
        return {
          timeFraction: OO,
          U6: this.createLerpMode(eO),
          pre: XO,
          post: bK
        }
      }
      createLerpMode(OO) {
        return null === OO ? XO.i.Linear : hO.LERP_MODE_SCHEMA_MAPPING[OO]
      }
    }

    function DO(OO) {
      return Number.isFinite(OO.timeFraction) && MO(OO.pre) && MO(OO.post)
    }

    function MO(OO) {
      return Number.isFinite(OO[0]) && Number.isFinite(OO[1]) && Number.isFinite(OO[2])
    }

    function aK(OO, KO, pO, XO, bK, eO, lO, vK) {
      const CO = eO - KO,
        hO = eO - XO,
        DO = vK - XO,
        MO = [null, null, null];
      for (let aK = 0; aK < MO.length; aK++) MO[aK] = oO(OO[aK], pO[aK], bK[aK], lO[aK], CO, DO);
      return {
        O4: hO,
        K4: MO
      }
    }

    function oO(OO, KO, pO, XO, eO, lO) {
      return {
        B4: bK.e.computeShortestRotation(OO, pO) / eO,
        Z4: bK.e.computeShortestRotation(KO, XO) / lO,
        delta: bK.e.computeShortestRotation(KO, pO)
      }
    }

    function FO(OO, KO, pO, XO, bK, eO, lO, vK) {
      const CO = eO - KO,
        hO = eO - XO,
        DO = vK - XO,
        MO = [null, null, null];
      for (let aK = 0; aK < MO.length; aK++) MO[aK] = {
        B4: (bK[aK] - OO[aK]) / CO,
        Z4: (lO[aK] - pO[aK]) / DO,
        delta: bK[aK] - pO[aK]
      };
      return {
        O4: hO,
        K4: MO
      }
    }

    function VO(OO, KO) {
      return null === KO ? OO : KO(OO)
    }

    function LO(OO) {
      const [KO, pO, XO] = OO, lO = -(0, eO.n)(KO), vK = -(0, eO.n)(pO), CO = (0, eO.n)(XO), hO = bK.e.quaternionFromEulerZYX(lO, vK, CO);
      return bK.e.eulerYXZFromQuaternion(hO)
    }
    hO.LERP_MODE_SCHEMA_MAPPING = {
      linear: XO.i.Linear,
      catmullrom: XO.i.CatmullRomSpline
    };
    const QO = 1 / 16;

    function zK(OO) {
      return [-OO[0] * QO, OO[1] * QO, OO[2] * QO]
    }

    function AO(OO) {
      const [KO, pO, XO] = OO;
      return [KO >= 0 ? Math.PI - KO : -Math.PI - KO, fO(pO + Math.PI), fO(XO + Math.PI)]
    }

    function fO(OO) {
      return bK.e.mod(OO + Math.PI, 2 * Math.PI) - Math.PI
    }

    function dO(OO, KO) {
      return Math.abs(bK.e.computeShortestRotation(OO[0], KO[0])) + Math.abs(bK.e.computeShortestRotation(OO[1], KO[1])) + Math.abs(bK.e.computeShortestRotation(OO[2], KO[2]))
    }
    const TO = new CO
  },
  35959: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      f: () => eO,
      i: () => XO,
      j: () => bK
    });
    let XO = function(OO) {
        return OO[OO.Linear = 0] = "Linear", OO[OO.CatmullRomSpline = 1] = "CatmullRomSpline", OO
      }({}),
      bK = function(OO) {
        return OO[OO.NoLoop = 0] = "NoLoop", OO[OO.LoopOnLastFrame = 1] = "LoopOnLastFrame", OO[OO.HoldOnLastFrame = 2] = "HoldOnLastFrame", OO
      }({}),
      eO = function(OO) {
        return OO[OO.Movement = 0] = "Movement", OO[OO.Action = 1] = "Action", OO[OO.Emote = 2] = "Emote", OO[OO.Custom = 3] = "Custom", OO
      }({}),
      lO = function(OO) {
        return OO[OO.Start = 0] = "Start", OO[OO.Stop = 1] = "Stop", OO
      }({})
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);