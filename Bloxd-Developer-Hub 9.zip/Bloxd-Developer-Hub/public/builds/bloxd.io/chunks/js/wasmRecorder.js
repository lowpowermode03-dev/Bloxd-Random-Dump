export const id = 56;
export const ids = [56];
export const modules = {
  59364: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_recorder_bg.01043305438a18818b6d.wasm"
  },
  59359: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      BloxdRecorderWasmError: () => rK,
      RECORDER_MODULE_ID: () => iK,
      loadRecorderModule: () => sO,
      markRecorderTrapped: () => RO,
      prefetchRecorderModule: () => HO,
      recorderMemoryBytes: () => JO,
      unloadRecorderModule: () => SO
    });
    var XO = {};
    pO.r(XO), pO.d(XO, {
      wMO: () => bK,
      RoO: () => jK,
      aK: () => eO,
      default: () => EO,
      initSync: () => uO,
      oO: () => lO,
      jaO: () => vK,
      dMO: () => CO
    });
    class bK {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, DO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        IO.kObc(OO, 0)
      }
      busy() {
        return 0 !== IO.iP5o(this.__wbg_ptr)
      }
      command(OO, KO) {
        return 0 !== IO.I3EJ(this.__wbg_ptr, OO, KO)
      }
      TMO(OO) {
        return IO.lNmT(this.__wbg_ptr, OO) >>> 0
      }
      fMO() {
        IO.r5md(this.__wbg_ptr)
      }
      AMO() {
        return IO.p8r7(this.__wbg_ptr) >>> 0
      }
      zaO() {
        return IO.ryJv(this.__wbg_ptr)
      }
      gaO() {
        return IO.Qf3C(this.__wbg_ptr) >>> 0
      }
      uMO() {
        return IO.Uu5Y(this.__wbg_ptr) >>> 0
      }
      feed(OO) {
        return IO.CG9U(this.__wbg_ptr, OO) >>> 0
      }
      constructor() {
        const OO = IO.DSpn();
        return this.__wbg_ptr = OO, DO.register(this, this.__wbg_ptr, this), this
      }
      yaO() {
        return IO.Cpqu(this.__wbg_ptr) >>> 0
      }
      SoO() {
        return IO.RdLF(this.__wbg_ptr) >>> 0
      }
      QMO(OO, KO, pO) {
        return 0 !== IO.nStT(this.__wbg_ptr, OO, KO, pO)
      }
      stage(OO) {
        return IO.cE1f(this.__wbg_ptr, OO) >>> 0
      }
      step() {
        return IO.c8TL(this.__wbg_ptr) >>> 0
      }
    }

    function eO(OO, KO) {
      const pO = function(OO, KO, pO) {
          if (void 0 === pO) {
            const pO = dO.encode(OO),
              XO = KO(pO.length, 1) >>> 0;
            return FO().subarray(XO, XO + pO.length).set(pO), yK = pO.length, XO
          }
          let XO = OO.length,
            bK = KO(XO, 1) >>> 0;
          const eO = FO();
          let lO = 0;
          for (; lO < XO; lO++) {
            const KO = OO.charCodeAt(lO);
            if (KO > 127) break;
            eO[bK + lO] = KO
          }
          if (lO !== XO) {
            0 !== lO && (OO = OO.slice(lO)), bK = pO(bK, XO, XO = lO + 3 * OO.length, 1) >>> 0;
            const KO = FO().subarray(bK + lO, bK + XO);
            lO += dO.encodeInto(OO, KO).written, bK = pO(bK, XO, lO, 1) >>> 0
          }
          return yK = lO, bK
        }(OO, IO.rL5e, IO.jIBj),
        XO = yK,
        bK = IO.MnSW(pO, XO, KO);
      if (bK[1]) throw QO(bK[0])
    }

    function lO() {
      IO.vlf1()
    }

    function vK() {
      return IO.YiOG() >>> 0
    }

    function CO() {
      return QO(IO.N4uK())
    }

    function hO() {
      return {
        __proto__: null,
        ytq4: {
          __proto__: null,
          qfs2: function(OO, KO) {
            return MO(Error(aK(OO, KO)))
          },
          Xd4L: function() {
            return MO(IO.memory)
          },
          FQ4h: function(OO, KO) {
            throw new Error(aK(OO, KO))
          },
          BOCe: function(OO, KO) {
            console.error(aK(OO, KO))
          },
          sRVS: function() {
            return performance.now()
          }
        }
      }
    }
    Symbol.dispose && (bK.prototype[Symbol.dispose] = bK.prototype.free);
    const DO = "undefined" === typeof FinalizationRegistry ? {
      register: () => {},
      unregister: () => {}
    } : new FinalizationRegistry((OO => IO?.__wbg_recordermodule_free(OO, 1)));

    function MO(OO) {
      LO === VO.length && VO.push(VO.length + 1);
      const KO = LO;
      return LO = VO[KO], VO[KO] = OO, KO
    }

    function aK(OO, KO) {
      return function(OO, KO) {
        fO += KO, fO >= AO && (zK = new TextDecoder("utf-8", {
          ignoreBOM: !0,
          fatal: !0
        }), zK.decode(), fO = KO);
        return zK.decode(FO().subarray(OO, OO + KO))
      }(OO >>> 0, KO)
    }
    let oO = null;

    function FO() {
      return null !== oO && 0 !== oO.byteLength || (oO = new Uint8Array(IO.memory.buffer)), oO
    }
    let VO = new Array(1024).fill(void 0);
    VO.push(void 0, null, !0, !1);
    let LO = VO.length;

    function QO(OO) {
      const KO = function(OO) {
        return VO[OO]
      }(OO);
      return function(OO) {
        OO < 1028 || (VO[OO] = LO, LO = OO)
      }(OO), KO
    }
    let zK = new TextDecoder("utf-8", {
      ignoreBOM: !0,
      fatal: !0
    });
    zK.decode();
    const AO = 2146435072;
    let fO = 0;
    const dO = new TextEncoder;
    "encodeInto" in dO || (dO.encodeInto = function(OO, KO) {
      const pO = dO.encode(OO);
      return KO.set(pO), {
        read: OO.length,
        written: pO.length
      }
    });
    let TO, NO, IO, yK = 0;

    function gK(OO, KO) {
      return NO = OO, IO = OO.exports, TO = KO, oO = null, IO.HzSF(), IO
    }

    function uO(OO) {
      if (void 0 !== IO) return IO;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module: OO
      } = OO) : console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));
      const KO = hO();
      OO instanceof WebAssembly.Module || (OO = new WebAssembly.Module(OO));
      return gK(new WebAssembly.Instance(OO, KO), OO)
    }
    async function EO(OO) {
      if (void 0 !== IO) return IO;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module_or_path: OO
      } = OO) : console.warn("using deprecated parameters for the initialization function; pass a single object instead"));
      const KO = hO();
      ("string" === typeof OO || "function" === typeof Request && OO instanceof Request || "function" === typeof URL && OO instanceof URL) && (OO = fetch(OO));
      const {
        instance: pO,
        module: XO
      } = await async function(OO, KO) {
        if ("function" === typeof Response && OO instanceof Response) {
          if (!OO.ok) throw new Error(`failed to fetch Wasm: ${OO.status} ${OO.statusText} fetching '${OO.url}'`);
          if ("function" === typeof WebAssembly.instantiateStreaming) try {
            return await WebAssembly.instantiateStreaming(OO, KO)
          } catch (pO) {
            if (! function(OO) {
                switch (OO) {
                  case "basic":
                  case "cors":
                  case "default":
                    return !0
                }
                return !1
              }(OO.type) || "application/wasm" === OO.headers.get("Content-Type")) throw pO;
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", pO)
          }
          const XO = await OO.arrayBuffer();
          return await WebAssembly.instantiate(XO, KO)
        } {
          const pO = await WebAssembly.instantiate(OO, KO);
          return pO instanceof WebAssembly.Instance ? {
            instance: pO,
            module: OO
          } : pO
        }
      }(await OO, KO);
      return gK(pO, XO)
    }

    function jK() {
      IO = void 0, NO = void 0, oO = null, VO = new Array(1024).fill(void 0), VO.push(void 0, null, !0, !1), LO = VO.length
    }
    var YO = pO(2951),
      wO = pO(5747);
    const iK = 2;
    class rK extends Error {
      stage;
      constructor(OO, KO) {
        super((0, YO.v)(OO, KO), {
          cause: KO
        }), this.name = "BloxdRecorderWasmError", this.stage = OO
      }
    }
    let PO = null;
    const mK = function(OO) {
      let KO = null,
        pO = null,
        XO = null,
        bK = null;
      const eO = async () => {
        let pO = null;
        try {
          return pO = KO ??= (0, YO.x)(OO.url(), (0, wO.e)(OO.name)), await pO
        } catch (XO) {
          throw KO === pO && (KO = null), OO.error((0, YO.z)(XO), XO)
        }
      };
      return {
        load: () => {
          if (bK) return Promise.reject(bK);
          if (pO) return pO;
          const KO = (async () => {
            const KO = await eO();
            try {
              await OO.init(KO)
            } catch (pO) {
              throw OO.error("instantiate", pO)
            }
            return OO.MX
          })();
          pO = KO, XO = KO;
          const lO = () => {
            XO === KO && (XO = null)
          };
          return KO.then(lO, (() => {
            lO(), pO === KO && (pO = null)
          })), KO
        },
        prefetch: async () => {
          bK || pO || await eO()
        },
        markTrapped: KO => (bK ??= OO.error("call", KO), bK),
        unload: () => {
          bK || !OO.reset || XO || (OO.reset(), pO = null)
        }
      }
    }({
      name: "bloxd_wasm_recorder",
      url: () => new pO.U(pO(59364)),
      init: async OO => {
        await EO({
          module_or_path: OO
        }), PO = CO()
      },
      MX: XO,
      error: (OO, KO) => new rK(OO, KO),
      reset: () => {
        jK(), PO = null
      }
    });

    function sO() {
      return mK.load()
    }

    function HO() {
      return mK.prefetch()
    }

    function RO(OO) {
      return mK.markTrapped(OO)
    }

    function SO() {
      mK.unload()
    }

    function JO() {
      return PO?.buffer.byteLength ?? 0
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);