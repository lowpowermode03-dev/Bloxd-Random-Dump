export const id = 105;
export const ids = [105];
export const modules = {
  35145: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => VO,
      c: () => fO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(63),
      lO = pO(1263),
      vK = pO(1556),
      CO = pO(1583),
      hO = pO(22),
      DO = pO(1991),
      MO = pO(35151),
      aK = pO(35157),
      oO = pO(35162),
      FO = pO(976);
    const VO = (0, eO.memo)((function() {
      const {
        isTouchScreen: OO,
        clientEscMenuOptions: KO,
        scriptedCameraFacing: pO,
        crosshairShownOverride: XO
      } = (0, hO.l)(["isTouchScreen", "clientEscMenuOptions", "scriptedCameraFacing", "crosshairShownOverride"]), vK = (0, DO.i)("gunshotOrigin"), VO = (0, eO.useRef)(null), QO = (0, eO.useRef)(!1), [zK, AO] = (0, eO.useState)(LO);
      (0, lO.f)("cameraZoomSet", AO), (0, eO.useEffect)((() => {
        AO(LO())
      }), []);
      const dO = (0, CO.i)("heldItemAim"),
        NO = dO.gun;
      (0, eO.useEffect)((() => (0, aK.f)("crosshairAccuracy", fO)), []), (0, lO.f)("mouseState", (OO => {
        let {
          isDown: KO
        } = OO;
        QO.current = KO, VO.current && (VO.current.style.transform = KO ? "scale(1.4)" : "scale(1)")
      }));
      const IO = (0, oO.h)(OO, KO.touchActionButtons);
      return (null !== XO && void 0 !== XO ? XO : (0, MO.g)(dO, zK > 1, IO, vK)) ? "movement" === pO || "cursor" === pO ? null : (0, FO.jsxs)(FO.Fragment, {
        children: [NO && (0, FO.jsx)(TO, {}), !NO && (0, FO.jsx)("div", {
          className: bK()("Crosshair", {
            Touch: OO
          }),
          ref: VO,
          style: {
            transform: QO.current ? "scale(1.4)" : "scale(1)"
          },
          children: "+"
        })]
      }) : null
    }));

    function LO() {
      return vK.gameBridge.lookup("cameraZoom", null)
    }
    const QO = [{
        current: null
      }, {
        current: null
      }, {
        current: null
      }, {
        current: null
      }],
      zK = {
        current: null
      };
    let AO = 0;

    function fO(OO) {
      QO[0].current || zK.current ? dO(OO) : AO = OO
    }

    function dO(OO) {
      if (QO[0].current) {
        const KO = `${(0,MO.e)(OO)}vh`;
        QO[0].current.style.transform = `translateX(calc(0px - ${KO}))`, QO[1].current.style.transform = `translateX(calc(0px + ${KO}))`, QO[2].current.style.transform = `translateY(calc(0px - ${KO}))`, QO[3].current.style.transform = `translateY(calc(0px + ${KO}))`
      }
      zK.current && (zK.current.style.filter = `blur(${Math.round(OO/10)}px)`)
    }

    function TO() {
      const OO = (0, lO.h)("aimingOverlay", "none"),
        KO = "1.2vh",
        pO = "0.3vh";
      return (0, eO.useEffect)((() => {
        AO && dO(AO)
      }), []), (0, FO.jsxs)(FO.Fragment, {
        children: ["sniper" === OO && (0, FO.jsxs)("div", {
          ref: zK,
          className: "GunCrosshairOverlayWrapper",
          children: [(0, FO.jsx)("div", {
            className: "GunCrosshairOverlay"
          }), (0, FO.jsx)("div", {
            className: "GunCrosshairOverlayLine1"
          }), (0, FO.jsx)("div", {
            className: "GunCrosshairOverlayLine2"
          }), (0, FO.jsx)("div", {
            className: "GunCrosshairOverlayDot"
          })]
        }), (0, FO.jsxs)("div", {
          className: "GunCrosshairWrapper",
          style: {
            opacity: "sniper" === OO ? 0 : 1
          },
          children: [(0, FO.jsx)("div", {
            className: "GunCrosshair",
            style: {
              width: KO,
              height: pO,
              top: "49.85vh",
              left: "calc(50vw - 0.6vh)"
            },
            ref: QO[0]
          }), (0, FO.jsx)("div", {
            className: "GunCrosshair",
            style: {
              width: KO,
              height: pO,
              top: "49.85vh",
              left: "calc(50vw - 0.6vh)"
            },
            ref: QO[1]
          }), (0, FO.jsx)("div", {
            className: "GunCrosshair",
            style: {
              width: pO,
              height: KO,
              top: "49.4vh",
              left: "calc(50vw - 0.15vh)"
            },
            ref: QO[2]
          }), (0, FO.jsx)("div", {
            className: "GunCrosshair",
            style: {
              width: pO,
              height: KO,
              top: "49.4vh",
              left: "calc(50vw - 0.15vh)"
            },
            ref: QO[3]
          })]
        })]
      })
    }
  },
  35273: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      f: () => CO,
      j: () => lO
    });
    var XO = pO(533),
      bK = pO(2231);

    function eO(OO) {
      return OO === (0, bK.d)().jCO ? (0, bK.d)().CpO : OO
    }

    function lO(OO) {
      return !(0, XO.I)(OO) && eO(OO) === (0, bK.d)().CpO
    }
    const vK = "gravity";

    function CO() {
      return (0, bK.d)().physics[vK][1]
    }
  },
  35259: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => AO
    });
    var XO = pO(35264),
      bK = pO(171),
      eO = pO(3988),
      lO = pO(35290),
      vK = pO(35273),
      CO = pO(266),
      hO = pO.n(CO),
      DO = pO(1056),
      MO = pO(2231),
      aK = pO(35287),
      oO = pO(26),
      FO = pO(22),
      VO = pO(35279);
    const LO = new Set(["note"]);
    const QO = {
      stop: () => QO,
      fade: () => QO,
      rate: () => QO,
      stopsAtOnce: () => !1,
      isAlive: () => !1,
      getDurationMs: () => 0,
      getVolume: () => 0,
      getRelativeVolume: () => 0,
      setRelativeVolume: () => QO,
      setPannerAttr: () => QO,
      setPosition: () => QO
    };
    class zK {
      constructor(OO) {
        let KO, {
          src: pO,
          volumeScalar: bK,
          isSoundSprite: vK
        } = OO;
        this._howl = void 0, this._volumeMultiplier = void 0, this._spriteTrackSrc = void 0, this._loadFailed = !1, vK ? (KO = (0, XO.f)(pO), this._spriteTrackSrc = KO) : KO = {
          src: DO.clientSideServerUrls.staticUrl + pO
        }, this._volumeMultiplier = new lO.f, this._volumeMultiplier.setMultiplierType("persistentScalar", bK), this._howl = new eO.Howl({
          ...KO,
          pool: 15
        }), this._howl.once("loaderror", (() => {
          this._loadFailed = !0
        }))
      }
      play() {
        let OO, KO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0,
          pO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (KO) {
          var XO;
          if (null === (XO = this._spriteTrackSrc) || void 0 === XO || !XO.sprite[KO]) throw new Error("No such sprite in your spritetrack");
          OO = this._howl.play(KO)
        } else OO = this._howl.play();
        pO && this._howl.loop(!0, OO);
        let bK = 1;
        this._howl.volume(this._volumeMultiplier.getTotalMultipliedVal(), OO);
        const eO = {
          stop: () => (this._howl.stop(OO), eO),
          fade: (KO, pO, XO) => (this._howl.fade(KO, pO, XO, OO), eO),
          rate: KO => (this._howl.rate(KO, OO), eO),
          stopsAtOnce: () => this._howl.playing(OO) && !this._howl._playLock,
          isAlive: () => {
            const KO = this._howl._soundById(OO);
            return !this._loadFailed && !!KO && !KO._ended
          },
          getDurationMs: () => this._howl._soundById(OO) ? 1e3 * this._howl.duration(OO) / this._howl.rate(OO) : 0,
          getVolume: () => bK * this._volumeMultiplier.getTotalMultipliedVal(),
          getRelativeVolume: () => bK,
          setRelativeVolume: KO => {
            if (KO > 1) throw new Error("Volume should be <= 1");
            return bK = FO.d.get("soundOnFromAd") ? KO : 0, this._howl.volume(Math.min(1, bK * this._volumeMultiplier.getTotalMultipliedVal()), OO), eO
          },
          setPannerAttr: KO => {
            let {
              coneInnerAngle: pO,
              coneOuterAngle: XO = 360,
              coneOuterGain: bK,
              distanceModel: lO,
              maxDistance: vK,
              panningModel: CO,
              refDistance: hO,
              rolloffFactor: DO
            } = KO;
            return this._setPannerAttr({
              id: OO,
              coneInnerAngle: pO,
              coneOuterAngle: XO,
              coneOuterGain: bK,
              distanceModel: lO,
              maxDistance: vK,
              panningModel: CO,
              refDistance: hO,
              rolloffFactor: DO
            }), eO
          },
          setPosition: KO => (this._howl.pos(KO[2], KO[1], KO[0], OO), eO)
        };
        return eO
      }
      setGlobalVolume(OO) {
        this._volumeMultiplier.setMultiplierType("globalVolume", OO), this._howl.volume(OO)
      }
      _setPannerAttr(OO) {
        let {
          id: KO,
          coneInnerAngle: pO = 360,
          coneOuterAngle: XO = 360,
          coneOuterGain: bK = 0,
          distanceModel: eO = "inverse",
          maxDistance: lO = 1e3,
          panningModel: vK = "HRTF",
          refDistance: CO = aK.h,
          rolloffFactor: hO = 1
        } = OO;
        this._howl.pannerAttr({
          coneOuterAngle: XO
        }, KO);
        const DO = {
          coneInnerAngle: pO,
          coneOuterAngle: XO,
          coneOuterGain: bK,
          distanceModel: eO,
          maxDistance: lO,
          panningModel: vK,
          refDistance: CO,
          rolloffFactor: hO
        };
        this._howl.pannerAttr(DO, KO)
      }
    }
    const AO = new class {
      constructor() {
        this.stereoSheets = {}, this.spatialSheets = {}, this.spatialVoices = new VO.b, oO.i.subscribe("appManagerUpdated|soundVolume", (OO => {
          const KO = Object.values(this.stereoSheets).concat(Object.values(this.spatialSheets));
          for (const pO of KO) pO.setGlobalVolume(OO)
        }))
      }
      play(OO, KO) {
        var pO;
        let eO, lO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null === (pO = (0, MO.d)()) || void 0 === pO ? void 0 : pO.CpO,
          CO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : aK.g,
          DO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : aK.h,
          oO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
        var AO;
        (0, MO.d)() ? eO = !!Array.isArray(lO) || (0, vK.e)(lO) !== (null === (AO = (0, MO.d)()) || void 0 === AO ? void 0 : AO.CpO): eO = !1;
        const fO = eO ? this.spatialSheets : this.stereoSheets,
          dO = (0, XO.g)(OO);
        if (!fO[dO]) {
          const OO = new zK({
            src: dO,
            isSoundSprite: !0,
            volumeScalar: 1
          });
          OO.setGlobalVolume(FO.d.get("soundVolume")), fO[dO] = OO
        }
        const TO = fO[dO];
        if (!eO) {
          const pO = TO.play(OO, oO);
          return pO.setRelativeVolume(KO), pO
        }
        const NO = (0, MO.d)(),
          IO = Array.isArray(lO) ? lO : NO.tL.fV(lO),
          yK = NO.tL.fV(NO.CpO);
        if (!IO || hO().sqrDist(IO, yK) > CO * CO) return QO;
        let gK;
        if (!oO) {
          if (!this.spatialVoices.admit({
              group: LO.has(dO) ? null : (0, VO.g)(OO),
              loudness: (0, VO.e)(KO, hO().OO(IO, yK), DO),
              startMs: performance.now(),
              getDurationMs: () => {
                var OO, KO;
                return null !== (OO = null === (KO = gK) || void 0 === KO ? void 0 : KO.getDurationMs()) && void 0 !== OO ? OO : 0
              },
              isAlive: () => {
                var OO, KO;
                return null !== (OO = null === (KO = gK) || void 0 === KO ? void 0 : KO.isAlive()) && void 0 !== OO && OO
              },
              canStop: () => {
                var OO, KO;
                return null !== (OO = null === (KO = gK) || void 0 === KO ? void 0 : KO.stopsAtOnce()) && void 0 !== OO && OO
              },
              stop: () => {
                var OO;
                null === (OO = gK) || void 0 === OO || OO.stop()
              }
            })) return QO
        }
        return gK = TO.play(OO, oO), gK.setRelativeVolume(KO), gK.setPannerAttr({
          refDistance: DO
        }), gK.setPosition([IO[0], IO[1] + bK.h.uD * bK.h.playerEyeToHeightRatio, IO[2]]), gK
      }
    }
  },
  35333: (OO, KO, pO) => {
    function XO(OO, KO) {
      var pO, XO, bK, eO, lO, vK, CO, hO;
      return OO.name === KO.name && ((null === (pO = OO.attributes) || void 0 === pO || null === (XO = pO.customAttributes) || void 0 === XO ? void 0 : XO.stackKey) === (null === (bK = KO.attributes) || void 0 === bK || null === (eO = bK.customAttributes) || void 0 === eO ? void 0 : eO.stackKey) && (!0 !== (null === (lO = OO.attributes) || void 0 === lO || null === (vK = lO.customAttributes) || void 0 === vK ? void 0 : vK.unstackable) && !0 !== (null === (CO = KO.attributes) || void 0 === CO || null === (hO = CO.customAttributes) || void 0 === hO ? void 0 : hO.unstackable)))
    }
    pO.d(KO, {
      b: () => XO
    })
  },
  5628: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      f: () => bK,
      j: () => CO,
      m: () => eO,
      o: () => hO,
      p: () => XO,
      q: () => vK
    });
    let XO = function(OO) {
        return OO[OO.DEFAULT = 0] = "DEFAULT", OO[OO.BOAT = 1] = "BOAT", OO[OO.GLIDER = 2] = "GLIDER", OO[OO.BALLOON = 3] = "BALLOON", OO[OO.SLEEPING = 4] = "SLEEPING", OO[OO.RIDING_MOB = 5] = "RIDING_MOB", OO[OO.CAR = 6] = "CAR", OO[OO.HOVERCRAFT = 7] = "HOVERCRAFT", OO
      }({}),
      bK = function(OO) {
        return OO[OO.WOOD = 0] = "WOOD", OO[OO.OBSIDIAN = 1] = "OBSIDIAN", OO[OO.SPEED = 2] = "SPEED", OO
      }({}),
      eO = function(OO) {
        return OO[OO.WOOD = 0] = "WOOD", OO[OO.IRON = 1] = "IRON", OO[OO.GOLD = 2] = "GOLD", OO[OO.DIAMOND = 3] = "DIAMOND", OO
      }({}),
      lO = function(OO) {
        return OO[OO.YELLOW = 0] = "YELLOW", OO[OO.WHITE = 1] = "WHITE", OO[OO.RED = 2] = "RED", OO[OO.PURPLE = 3] = "PURPLE", OO[OO.PINK = 4] = "PINK", OO[OO.ORANGE = 5] = "ORANGE", OO[OO.MAGENTA = 6] = "MAGENTA", OO[OO.LIME = 7] = "LIME", OO[OO.LIGHT_GRAY = 8] = "LIGHT_GRAY", OO[OO.LIGHT_BLUE = 9] = "LIGHT_BLUE", OO[OO.GREEN = 10] = "GREEN", OO[OO.GRAY = 11] = "GRAY", OO[OO.CYAN = 12] = "CYAN", OO[OO.BROWN = 13] = "BROWN", OO[OO.BLUE = 14] = "BLUE", OO[OO.BLACK = 15] = "BLACK", OO
      }({}),
      vK = function(OO) {
        return OO[OO.ROTATION_1 = 0] = "ROTATION_1", OO[OO.ROTATION_2 = 1] = "ROTATION_2", OO[OO.ROTATION_3 = 2] = "ROTATION_3", OO[OO.ROTATION_4 = 3] = "ROTATION_4", OO
      }({}),
      CO = function(OO) {
        return OO[OO.KART = 0] = "KART", OO[OO.OFF_ROADER = 1] = "OFF_ROADER", OO[OO.CAR = 2] = "CAR", OO[OO.GOLD_MINING_DRILL = 3] = "GOLD_MINING_DRILL", OO[OO.ARMORED_CAR = 4] = "ARMORED_CAR", OO[OO.IRON_MINING_DRILL = 5] = "IRON_MINING_DRILL", OO[OO.DIAMOND_MINING_DRILL = 6] = "DIAMOND_MINING_DRILL", OO[OO.MOONSTONE_MINING_DRILL = 7] = "MOONSTONE_MINING_DRILL", OO
      }({});
    XO.DEFAULT, XO.BOAT, bK.SPEED, XO.GLIDER, eO.DIAMOND, XO.BALLOON, lO.BLACK, XO.SLEEPING, vK.ROTATION_4, XO.RIDING_MOB, XO.CAR, CO.MOONSTONE_MINING_DRILL, XO.HOVERCRAFT;
    let hO = function(OO) {
      return OO[OO.NORMAL = 0] = "NORMAL", OO[OO.GLIDING = 1] = "GLIDING", OO[OO.FLOATING = 2] = "FLOATING", OO
    }({})
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);