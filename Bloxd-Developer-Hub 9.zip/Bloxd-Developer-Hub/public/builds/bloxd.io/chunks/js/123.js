export const id = 123;
export const ids = [123];
export const modules = {
  5763: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      loadShaderPackTextures: () => lO,
      shaderPackTextures: () => vK
    });
    var XO = pO(5709);
    let bK = null,
      eO = null;

    function lO() {
      return eO ??= Promise.all([pO.e(62), pO.e(182)]).then((() => pO(38591))).then((OO => {
        let {
          FORMER_BLOCK_IMAGE_NAMES: KO,
          textureNameToIndex: pO,
          textureAnimationData: eO
        } = OO;
        return bK ??= (0, XO.k)(pO, eO, KO), bK
      })), eO
    }

    function vK() {
      if (null === bK) throw new Error("Shader pack textures read before loadShaderPackTextures");
      return bK
    }
  },
  5709: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      f: () => eO,
      h: () => XO,
      k: () => FO,
      m: () => DO,
      q: () => bK,
      t: () => CO,
      v: () => hO,
      w: () => MO
    });
    const XO = 5;

    function bK(OO) {
      return OO === XO
    }
    const eO = 262144,
      lO = 256,
      vK = 256;

    function CO(OO) {
      if ("object" !== typeof OO || null === OO || Array.isArray(OO)) return "The pack has no files.";
      const KO = [];
      for (const [pO, XO] of Object.entries(OO)) {
        if ("string" !== typeof XO) return `${pO} isn't text.`;
        KO.push({
          path: pO,
          source: XO
        })
      }
      return KO.sort(((OO, KO) => DO(OO.path, KO.path))),
        function(OO) {
          if (0 === OO.length) return "The pack has no .wgsl files.";
          if (OO.length > lO) return `The pack has more than ${lO} .wgsl files.`;
          const KO = new Set;
          for (const {
              path: pO
            }
            of OO) {
            const OO = aK(pO);
            if (null !== OO) return OO;
            if (KO.has(pO)) return `The pack has two files at ${pO}.`;
            KO.add(pO)
          }
          return MO(OO) > eO ? `The pack's .wgsl files are over ${eO/1024} KB in total.` : null
        }(KO) ?? KO
    }

    function hO(OO) {
      const KO = {};
      for (const pO of OO) KO[pO.path] = pO.source;
      return KO
    }

    function DO(OO, KO) {
      return OO < KO ? -1 : OO > KO ? 1 : 0
    }

    function MO(OO) {
      const KO = new TextEncoder;
      let pO = 0;
      for (const {
          source: XO
        }
        of OO) pO += KO.encode(XO).byteLength;
      return pO
    }

    function aK(OO) {
      if (!OO.toLowerCase().endsWith(".wgsl")) return `${OO} isn't a .wgsl file.`;
      if (OO.length > vK) return `A file path is over ${vK} characters.`;
      if (OO.includes("\\") || /[\u0000-\u001f]/.test(OO)) return `${OO} isn't a valid file path.`;
      return OO.split("/").some((OO => "" === OO || "." === OO || ".." === OO)) ? `${OO} isn't a valid file path.` : null
    }
    const oO = /^(.*)\[rot\[([1-4])$/;

    function FO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new Map;
      const XO = new Map;
      KO.forEach(((OO, KO) => {
        let {
          numAnimStates: pO,
          animStartIdx: bK
        } = OO;
        for (let eO = 1; eO < pO; eO++) XO.set(bK + eO - 1, KO)
      }));
      const bK = Object.entries(OO),
        eO = new Map;
      for (const [VO, LO] of bK) {
        const OO = oO.exec(VO);
        "1" === OO?.[2] && eO.set(OO[1], LO + 1)
      }
      const lO = OO => {
          const KO = oO.exec(OO);
          return KO && eO.has(KO[1]) ? {
            root: KO[1],
            rotation: Number(KO[2]) - 1
          } : null
        },
        vK = new Set(bK.map((OO => {
          let [KO] = OO;
          return lO(KO)?.root ?? KO
        }))),
        CO = (OO, pO) => {
          const XO = OO.replace(/_?0$/, "");
          return (KO[pO]?.numAnimStates ?? 0) > 1 && !vK.has(XO) ? XO : OO
        },
        hO = new Map;
      for (const [oO, VO] of bK) hO.set(VO, CO(lO(oO)?.root ?? oO, VO));
      const DO = bK.reduce(((OO, KO) => {
          let [, pO] = KO;
          return Math.max(OO, pO + 1)
        }), 0),
        MO = Array.from({
          length: DO
        }, ((OO, KO) => ({
          id: KO + 1,
          rotation: 0
        }))),
        aK = new Map,
        FO = new Map;
      for (const [oO, VO] of bK) {
        const OO = lO(oO),
          KO = XO.get(VO);
        if (void 0 !== KO) {
          const pO = hO.get(KO);
          FO.set(oO, {
            name: oO,
            texture: pO,
            kind: "frame"
          }), OO && !FO.has(OO.root) && FO.set(OO.root, {
            name: OO.root,
            texture: pO,
            kind: "frame"
          });
          continue
        }
        const pO = hO.get(VO),
          bK = OO?.root ?? oO;
        if (pO !== bK && FO.set(bK, {
            name: bK,
            texture: pO,
            kind: "frame"
          }), OO) {
          const KO = eO.get(OO.root);
          MO[VO] = {
            id: KO,
            rotation: OO.rotation
          }, aK.set(pO, KO), FO.set(oO, {
            name: oO,
            texture: pO,
            kind: "rotation"
          })
        } else aK.set(pO, VO + 1)
      }
      for (const oO of aK.keys()) FO.delete(oO);
      for (const [oO, VO] of pO) {
        const OO = aK.get(VO);
        void 0 === OO || aK.has(oO) || (aK.set(oO, OO), FO.delete(oO))
      }
      return {
        named: [...aK].sort(((OO, KO) => {
          let [pO] = OO, [XO] = KO;
          return pO < XO ? -1 : pO > XO ? 1 : 0
        })).map((OO => {
          let [KO, pO] = OO;
          return {
            name: KO,
            id: pO
          }
        })),
        aliases: [...FO.values()],
        layers: MO
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);