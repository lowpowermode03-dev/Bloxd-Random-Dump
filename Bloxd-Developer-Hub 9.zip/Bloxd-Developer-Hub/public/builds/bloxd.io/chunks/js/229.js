export const id = 229;
export const ids = [229];
export const modules = {
  38667: (OO, KO, pO) => {
    pO.d(KO, {
      Ad: () => CO,
      Bc: () => XK,
      Bf: () => Tp,
      Ce: () => Zp,
      Cf: () => Lp,
      D: () => bp,
      Db: () => QO,
      Dd: () => DO,
      De: () => iX,
      Df: () => np,
      Ee: () => Pp,
      Ef: () => sp,
      F: () => uO,
      Fc: () => MK,
      Fe: () => rX,
      Gb: () => zp,
      Gc: () => gK,
      Gf: () => Hp,
      Hd: () => LK,
      He: () => wp,
      Ie: () => Rp,
      J: () => jK,
      Jb: () => WO,
      Jc: () => hK,
      Jd: () => GK,
      Je: () => Yp,
      Kf: () => Ap,
      Lc: () => CK,
      Ld: () => SO,
      Me: () => cX,
      Mf: () => Vp,
      N: () => EO,
      Nb: () => Op,
      Nd: () => ap,
      O: () => cp,
      Pc: () => pK,
      Pe: () => Jp,
      Q: () => oO,
      Qc: () => yK,
      Qf: () => mX,
      Rb: () => YO,
      Rd: () => nK,
      Se: () => Sp,
      Tb: () => kK,
      Tc: () => fO,
      Td: () => SK,
      Tf: () => Np,
      U: () => BO,
      Ue: () => XX,
      Vb: () => tK,
      Vc: () => XO,
      Vf: () => fp,
      W: () => bb,
      We: () => Ip,
      X: () => UK,
      Xb: () => KK,
      Xc: () => IO,
      Xd: () => OK,
      Xf: () => Gp,
      Y: () => nO,
      Yd: () => UO,
      Z: () => tp,
      _: () => kp,
      _b: () => VK,
      _c: () => lK,
      _e: () => Ep,
      _f: () => zX,
      ae: () => cK,
      af: () => yX,
      bb: () => xK,
      bc: () => qK,
      bf: () => jX,
      bg: () => Bp,
      cb: () => WK,
      cd: () => LO,
      cf: () => upO,
      cg: () => aX,
      dd: () => VO,
      e: () => eO,
      ed: () => FO,
      ee: () => dO,
      fc: () => wO,
      gb: () => HO,
      gf: () => gX,
      gg: () => Fp,
      h: () => lO,
      hb: () => Xp,
      hd: () => ep,
      he: () => MO,
      i: () => NO,
      ic: () => eK,
      id: () => lp,
      jb: () => bX,
      jf: () => pX,
      kd: () => TO,
      ke: () => Cp,
      l: () => sO,
      lf: () => tX,
      m: () => hp,
      mb: () => RO,
      mc: () => zK,
      n: () => vX,
      nc: () => AO,
      ne: () => KX,
      nf: () => Up,
      od: () => rK,
      oe: () => Qp,
      pb: () => pp,
      pd: () => iK,
      pf: () => Wp,
      qc: () => DK,
      r: () => vK,
      rb: () => Kp,
      rc: () => hO,
      sb: () => oK,
      sd: () => mK,
      se: () => dp,
      t: () => JK,
      tc: () => ZK,
      tf: () => kX,
      ue: () => op,
      v: () => BK,
      vb: () => vp,
      w: () => ZO,
      wc: () => JO,
      wd: () => PO,
      wf: () => OX,
      x: () => qp,
      xf: () => xX,
      yc: () => GO,
      ye: () => qX,
      z: () => aK,
      zb: () => bK,
      zc: () => xp,
      zd: () => FK
    });
    const XO = -2147483648,
      bK = 12,
      eO = 12,
      lO = 4095,
      vK = {
        Lifeform: 1,
        Throwable: 2,
        Mesh: 3,
        Audio: 4,
        Item: 5
      },
      CO = {
        Alive: 1,
        Crouching: 2,
        OnGround: 4,
        InFluid: 8,
        Spectating: 16,
        AttemptingBreak: 32,
        Aiming: 64,
        FirstPerson: 128,
        Replay: 256,
        Breaking: 512,
        CursorAim: 1024,
        FreeCam: 2048,
        ZoomFirstPerson: 4096,
        JumpHeld: 8192,
        Flying: 16384,
        CanFly: 32768,
        PadSneakToggled: 65536,
        DropAhead: 131072
      },
      hO = {
        None: 0,
        Entity: 1,
        Open: 2,
        Close: 3,
        Milk: 4,
        Shear: 5,
        Tame: 6,
        TameWith: 7,
        Feed: 8,
        Ride: 9
      },
      DO = {
        Off: 0,
        Key: 1,
        Touch: 2
      },
      MO = {
        Alive: 16
      },
      aK = 32,
      oO = {
        Stored: 1,
        Unloaded: 2,
        ResetAll: 4
      },
      FO = {
        opacity: 0,
        zIndex: 1,
        overlayColour: 2,
        canAttack: 3,
        canSee: 4,
        interactable: 5,
        interactionPrompt: 6,
        showDamageAmounts: 7,
        lockHeadToBody: 8,
        killfeedColour: 9,
        meshScaling: 10,
        colorInLobbyLeaderboard: 11,
        lobbyLeaderboardValues: 12,
        lobbyLeaderboardTags: 13,
        nameTagInfo: 14,
        hasPriorityNametag: 15,
        alwaysInInterest: 16,
        multilineTextBox: 17,
        ranks: 18,
        nameColour: 19,
        hideNameSeed: 20,
        _leaderboardAround: 21,
        _invincible: 22,
        _isAlive: 23,
        _invisibleEffect: 24,
        _glowingEffect: 25,
        _armourReductionSum: 26,
        _protectionEnchantSum: 27,
        _receivingDamageMultiplier: 28
      },
      VO = 4294967295,
      LO = 0,
      QO = 4294967295,
      zK = 4,
      AO = 123,
      fO = -2147483648,
      dO = {
        Off: 0,
        All: 1,
        Filter: 2
      },
      TO = 51,
      NO = 5,
      IO = 4294967295,
      yK = 4294967295,
      gK = 128,
      uO = ["Workbench", "Furnace", "Artisan Bench", "Potion Table", "Salvaging Table", "Enchanting Table"],
      EO = 16,
      jK = 255,
      YO = {
        Off: 0,
        On: 1,
        Keep: 2
      },
      wO = {
        AltVeto: 1,
        AltAction: 2,
        Click: 3,
        ChangeBlock: 4,
        DropItem: 5,
        Tick: 6,
        Message: 7,
        Create: 8,
        Director: 11
      },
      iK = {
        Hotbar: 256,
        Drop: 257
      },
      rK = {
        Down: 1,
        Next: 2,
        Stack: 4
      },
      PO = {
        Rate: 0,
        Gyro: 1
      },
      mK = {
        Active: 1,
        JumpHeld: 2,
        JumpPressed: 4,
        Running: 8,
        SprintHeld: 16,
        SneakHeld: 32,
        SneakHoldMode: 64,
        Peek: 128,
        EndToggle: 256
      },
      sO = {
        Prevent: 0,
        Allow: 1,
        PreventPlacement: 2
      },
      HO = {
        None: 0,
        Pose: 1,
        FaceMovement: 2,
        FaceCamera: 3,
        FaceCursor: 4
      },
      RO = {
        LookPointed: 1,
        Held: 2
      },
      SO = 3,
      JO = {
        Synced: 0,
        ChestOpened: 1,
        ChestClosed: 2,
        ChestRefreshed: 3,
        EnchantingTable: 4,
        HotbarRequest: 5,
        Scrolled: 6,
        NumberKey: 7,
        DropRequested: 8
      },
      cK = {
        ToggleMenu: 0,
        EditBoard: 1,
        EditCodeBlock: 2,
        ViewCodeBlock: 3,
        EditCustomLobbyBlock: 4,
        OpenIronChest: 5,
        EditNameTag: 6,
        EditBook: 7,
        CantChangeBlock: 8,
        MiddleBarStart: 9,
        MiddleBarStop: 10,
        AimingOverlay: 11,
        BottomMessage: 12,
        Hitmarker: 13,
        ShotsLeft: 14,
        Crosshair: 15,
        ChargeStage: 16,
        EmoteWheelClose: 17,
        BlockMined: 18
      },
      BO = {
        Alt: 1,
        Up: 2,
        HasPos: 4,
        AttackOnly: 8
      },
      ZO = {
        Solid: 1,
        Fluid: 2,
        PlaceOver: 4
      },
      GO = {
        Stackable: 1
      },
      qK = {
        granule: 1,
        wood: 2,
        rock: 3,
        cuttable: 4
      },
      xK = {
        Detail: 1,
        RoomForOne: 2
      },
      nO = {
        HaveIngredients: 1,
        Listed: 2
      },
      WO = {
        HasOpts: 1
      },
      tK = {
        Flat: 0,
        Chevrons: 1,
        FurnaceFire: 2,
        FlatOpaque: 3,
        FlatOnTop: 4
      },
      kK = {
        Up: 1,
        Down: 2
      },
      UO = {
        TwoD: 1,
        Loop: 2
      },
      OK = {
        StopAfter: 1
      },
      KK = {
        Anchor: 1,
        Visible: 2,
        UvOffset: 4,
        Visibility: 8,
        Scale: 16
      },
      pK = {
        Pose: 1,
        Visible: 2
      },
      XK = 255,
      bp = 65535,
      eK = 255,
      lK = 65535,
      vp = ["standing", "sitting", "zombie", "gliding", "driving", "sleeping", "riding"],
      CK = ["", "Sheared", "Saddled", "Antlers", "skyblockHeldBoss"],
      hK = ["Box", "BloxdBlock", "Person", "Leaderboard", "ParticleEmitter"],
      DK = {
        Bytes: 16,
        Hidden: 2147483648,
        Max: 262144
      },
      MK = 4294967295,
      ap = 4294967295,
      oK = 255,
      FK = {
        PresetNone: 65535,
        HasBox: 1,
        Anchored: 1,
        MaxOpts: 4096,
        MaxBurst: 2e3,
        MaxPoints: 512,
        PointBytes: 16,
        MaxKey: 1073741823,
        MaxLiveKeys: 256
      },
      VK = {
        critical: 123
      },
      LK = 4294967295,
      QK = {
        BYTES: 4,
        KK: (OO, KO) => OO.getUint32(KO + 0, !0)
      },
      zp = {
        BYTES: 12,
        serverId: (OO, KO) => OO.getInt32(KO + 0, !0),
        index: (OO, KO) => OO.getUint32(KO + 4, !0),
        kind: (OO, KO) => OO.getUint16(KO + 8, !0)
      },
      AK = {
        BYTES: 20,
        pos: (OO, KO, pO) => OO.getInt32(KO + 0 + 4 * pO, !0),
        actual: (OO, KO) => OO.getUint32(KO + 12, !0),
        dataLen: (OO, KO) => OO.getUint32(KO + 16, !0)
      },
      fK = {
        BYTES: 20,
        what: (OO, KO) => OO.getUint8(KO + 0),
        value: (OO, KO) => OO.getInt16(KO + 2, !0),
        pos: (OO, KO, pO) => OO.getInt32(KO + 4 + 4 * pO, !0),
        block: (OO, KO) => OO.getUint32(KO + 16, !0)
      },
      dK = {
        BYTES: 4,
        item: (OO, KO) => OO.getUint16(KO + 0, !0),
        slot: (OO, KO) => OO.getUint8(KO + 2)
      },
      TK = {
        BYTES: 16,
        target: (OO, KO) => OO.getInt32(KO + 0, !0),
        damage: (OO, KO) => OO.getFloat32(KO + 4, !0),
        distance: (OO, KO) => OO.getFloat32(KO + 8, !0),
        crit: (OO, KO) => OO.getUint8(KO + 12)
      },
      NK = {
        BYTES: 4,
        slot: (OO, KO) => OO.getUint16(KO + 0, !0)
      },
      IK = {
        BYTES: 20,
        what: (OO, KO) => OO.getUint8(KO + 0),
        value: (OO, KO) => OO.getInt16(KO + 2, !0),
        pos: (OO, KO, pO) => OO.getInt32(KO + 4 + 4 * pO, !0),
        block: (OO, KO) => OO.getUint32(KO + 16, !0)
      },
      yp = {
        BYTES: 12,
        serverId: (OO, KO) => OO.getInt32(KO + 0, !0),
        index: (OO, KO) => OO.getUint32(KO + 4, !0),
        what: (OO, KO) => OO.getUint16(KO + 8, !0)
      },
      gp = {
        BYTES: 24,
        cx: (OO, KO) => OO.getInt32(KO + 0, !0),
        cy: (OO, KO) => OO.getInt32(KO + 4, !0),
        cz: (OO, KO) => OO.getInt32(KO + 8, !0),
        slot: (OO, KO) => OO.getUint32(KO + 12, !0),
        generation: (OO, KO) => OO.getUint32(KO + 16, !0),
        flags: (OO, KO) => OO.getUint32(KO + 20, !0)
      },
      uK = {
        BYTES: 44,
        pos: (OO, KO, pO) => OO.getFloat64(KO + 0 + 8 * pO, !0),
        sound: (OO, KO) => OO.getUint16(KO + 24, !0),
        flags: (OO, KO) => OO.getUint16(KO + 26, !0),
        handle: (OO, KO) => OO.getUint32(KO + 28, !0),
        volume: (OO, KO) => OO.getFloat32(KO + 32, !0),
        rate: (OO, KO) => OO.getFloat32(KO + 36, !0),
        refDist: (OO, KO) => OO.getFloat32(KO + 40, !0)
      },
      EK = {
        BYTES: 28,
        pos: (OO, KO, pO) => OO.getFloat64(KO + 0 + 8 * pO, !0),
        handle: (OO, KO) => OO.getUint32(KO + 24, !0)
      },
      jp = {
        BYTES: 16,
        handle: (OO, KO) => OO.getUint32(KO + 0, !0),
        volume: (OO, KO) => OO.getFloat32(KO + 4, !0),
        rate: (OO, KO) => OO.getFloat32(KO + 8, !0),
        refDist: (OO, KO) => OO.getFloat32(KO + 12, !0)
      },
      YK = {
        BYTES: 12,
        handle: (OO, KO) => OO.getUint32(KO + 0, !0),
        to: (OO, KO) => OO.getFloat32(KO + 4, !0),
        ms: (OO, KO) => OO.getUint16(KO + 8, !0),
        flags: (OO, KO) => OO.getUint16(KO + 10, !0)
      },
      wK = {
        BYTES: 4,
        handle: (OO, KO) => OO.getUint32(KO + 0, !0)
      },
      ip = {
        BYTES: 4,
        reason: (OO, KO) => OO.getUint8(KO + 0),
        code: (OO, KO) => OO.getUint8(KO + 1)
      },
      rp = {
        BYTES: 4,
        key: (OO, KO) => OO.getUint8(KO + 0),
        tag: (OO, KO) => OO.getUint8(KO + 1)
      },
      PK = {
        BYTES: 16,
        save: (OO, KO) => OO.getUint32(KO + 0, !0),
        index: (OO, KO) => OO.getUint32(KO + 4, !0),
        ptr: (OO, KO) => OO.getUint32(KO + 8, !0),
        len: (OO, KO) => OO.getUint32(KO + 12, !0)
      },
      mp = {
        BYTES: 16,
        save: (OO, KO) => OO.getUint32(KO + 0, !0),
        kind: (OO, KO) => OO.getUint8(KO + 4),
        parts: (OO, KO) => OO.getUint32(KO + 8, !0),
        bytes: (OO, KO) => OO.getUint32(KO + 12, !0)
      },
      sK = {
        BYTES: 4,
        totalTicks: (OO, KO) => OO.getUint32(KO + 0, !0)
      },
      HK = {
        BYTES: 24,
        what: (OO, KO) => OO.getUint8(KO + 0),
        int: (OO, KO) => OO.getInt32(KO + 4, !0),
        x: (OO, KO) => OO.getFloat64(KO + 8, !0),
        y: (OO, KO) => OO.getFloat64(KO + 16, !0)
      },
      RK = {
        BYTES: 8,
        what: (OO, KO) => OO.getUint8(KO + 0),
        kind: (OO, KO) => OO.getUint8(KO + 1),
        save: (OO, KO) => OO.getUint32(KO + 4, !0)
      },
      SK = {
        BYTES: 4,
        Tl: (OO, KO) => OO.getUint16(KO + 0, !0)
      },
      JK = {
        BYTES: 360,
        eye: (OO, KO, pO) => OO.getFloat64(KO + 0 + 8 * pO, !0),
        localPos: (OO, KO, pO) => OO.getFloat64(KO + 24 + 8 * pO, !0),
        YvO: (OO, KO, pO) => OO.getFloat64(KO + 48 + 8 * pO, !0),
        viewProj: (OO, KO, pO) => OO.getFloat32(KO + 72 + 4 * pO, !0),
        origin: (OO, KO, pO) => OO.getInt32(KO + 136 + 4 * pO, !0),
        heading: (OO, KO) => OO.getFloat32(KO + 148, !0),
        pitch: (OO, KO) => OO.getFloat32(KO + 152, !0),
        tanHalfFovX: (OO, KO) => OO.getFloat32(KO + 156, !0),
        tanHalfFovY: (OO, KO) => OO.getFloat32(KO + 160, !0),
        viewportCss: (OO, KO, pO) => OO.getFloat32(KO + 164 + 4 * pO, !0),
        localVel: (OO, KO, pO) => OO.getFloat32(KO + 172 + 4 * pO, !0),
        actionDir: (OO, KO, pO) => OO.getFloat32(KO + 184 + 4 * pO, !0),
        localId: (OO, KO) => OO.getInt32(KO + 196, !0),
        playerFlags: (OO, KO) => OO.getUint32(KO + 200, !0),
        targetBlock: (OO, KO, pO) => OO.getInt32(KO + 204 + 4 * pO, !0),
        targetAdjacent: (OO, KO, pO) => OO.getInt32(KO + 216 + 4 * pO, !0),
        targetBlockId: (OO, KO) => OO.getUint32(KO + 228, !0),
        targetNormal: (OO, KO, pO) => OO.getInt8(KO + 232 + 1 * pO),
        targetFlags: (OO, KO) => OO.getUint8(KO + 235),
        pickedEntity: (OO, KO) => OO.getInt32(KO + 236, !0),
        breakingPos: (OO, KO, pO) => OO.getInt32(KO + 240 + 4 * pO, !0),
        breakingProgress: (OO, KO) => OO.getFloat32(KO + 252, !0),
        XE: (OO, KO) => OO.getUint16(KO + 256, !0),
        selectedSlot: (OO, KO) => OO.getUint8(KO + 258),
        heldFlags: (OO, KO) => OO.getUint8(KO + 259),
        heldAttrVersion: (OO, KO) => OO.getUint32(KO + 260, !0),
        inventoryVersion: (OO, KO) => OO.getUint32(KO + 264, !0),
        effectsVersion: (OO, KO) => OO.getUint32(KO + 268, !0),
        entitiesVersion: (OO, KO) => OO.getUint32(KO + 272, !0),
        entRenderPtr: (OO, KO) => OO.getUint32(KO + 276, !0),
        entCapacity: (OO, KO) => OO.getUint32(KO + 280, !0),
        frameMs: (OO, KO) => OO.getFloat32(KO + 284, !0),
        fps: (OO, KO) => OO.getFloat32(KO + 288, !0),
        entVisPtr: (OO, KO) => OO.getUint32(KO + 292, !0),
        momentumFrac: (OO, KO) => OO.getFloat32(KO + 296, !0),
        chunkSlotsPtr: (OO, KO) => OO.getUint32(KO + 300, !0),
        chunkSlotsLen: (OO, KO) => OO.getUint32(KO + 304, !0),
        walkThroughPtr: (OO, KO) => OO.getUint32(KO + 308, !0),
        walkThroughLen: (OO, KO) => OO.getUint32(KO + 312, !0),
        audioViewPtr: (OO, KO) => OO.getUint32(KO + 316, !0),
        inventoryViewPtr: (OO, KO) => OO.getUint32(KO + 320, !0),
        eventOverflowGen: (OO, KO) => OO.getUint32(KO + 324, !0),
        eventOverflowMask: (OO, KO) => OO.getUint32(KO + 328, !0),
        promptEntity: (OO, KO) => OO.getInt32(KO + 332, !0),
        replayViewPtr: (OO, KO) => OO.getUint32(KO + 336, !0),
        slotIcon: (OO, KO) => OO.getUint32(KO + 340, !0),
        localDeaths: (OO, KO) => OO.getUint32(KO + 344, !0),
        cameraFar: (OO, KO) => OO.getFloat32(KO + 348, !0),
        gliderBoostFuel: (OO, KO) => OO.getUint32(KO + 352, !0),
        interactLabel: (OO, KO) => OO.getUint16(KO + 356, !0),
        interactIcon: (OO, KO) => OO.getUint16(KO + 358, !0)
      },
      cp = {
        BYTES: 16,
        voxelsPtr: (OO, KO) => OO.getUint32(KO + 0, !0),
        version: (OO, KO) => OO.getUint32(KO + 4, !0),
        generation: (OO, KO) => OO.getUint32(KO + 8, !0),
        JK: (OO, KO) => OO.getUint32(KO + 12, !0)
      },
      BK = {
        BYTES: 56,
        listener: (OO, KO, pO) => OO.getFloat64(KO + 0 + 8 * pO, !0),
        forward: (OO, KO, pO) => OO.getFloat32(KO + 24 + 4 * pO, !0),
        up: (OO, KO, pO) => OO.getFloat32(KO + 36 + 4 * pO, !0),
        dropped: (OO, KO) => OO.getUint32(KO + 48, !0),
        unfollowed: (OO, KO) => OO.getUint32(KO + 52, !0)
      },
      ZK = {
        BYTES: 8,
        item: (OO, KO) => OO.getUint16(KO + 0, !0),
        amount: (OO, KO) => OO.getUint16(KO + 2, !0),
        attrVersion: (OO, KO) => OO.getUint32(KO + 4, !0)
      },
      GK = {
        BYTES: 76,
        version: (OO, KO) => OO.getUint32(KO + 0, !0),
        state: (OO, KO) => OO.getUint8(KO + 4),
        cameraMode: (OO, KO) => OO.getUint8(KO + 5),
        KK: (OO, KO) => OO.getUint32(KO + 8, !0),
        totalTicks: (OO, KO) => OO.getUint32(KO + 12, !0),
        speed: (OO, KO) => OO.getFloat32(KO + 16, !0),
        markIn: (OO, KO) => OO.getUint32(KO + 20, !0),
        markOut: (OO, KO) => OO.getUint32(KO + 24, !0),
        editVersion: (OO, KO) => OO.getUint32(KO + 28, !0),
        drops: (OO, KO, pO) => OO.getUint32(KO + 32 + 4 * pO, !0)
      },
      qp = {
        BYTES: 6,
        flags: (OO, KO) => OO.getUint8(KO + 0),
        harvestType: (OO, KO) => OO.getUint8(KO + 1),
        harvestLevel: (OO, KO) => OO.getUint8(KO + 2),
        attachedTop: (OO, KO) => OO.getUint16(KO + 4, !0)
      },
      xp = {
        BYTES: 3,
        flags: (OO, KO) => OO.getUint8(KO + 0),
        harvests: (OO, KO) => OO.getUint8(KO + 1),
        level: (OO, KO) => OO.getUint8(KO + 2)
      },
      nK = {
        BYTES: 12,
        item: (OO, KO) => OO.getUint32(KO + 0, !0),
        amount: (OO, KO) => OO.getFloat64(KO + 4, !0)
      },
      WK = {
        BYTES: 16,
        recipes: (OO, KO) => OO.getUint32(KO + 0, !0),
        ingredients: (OO, KO) => OO.getUint32(KO + 4, !0),
        craftAllTimes: (OO, KO) => OO.getUint32(KO + 8, !0),
        flags: (OO, KO) => OO.getUint32(KO + 12, !0)
      },
      tp = {
        BYTES: 10,
        item: (OO, KO) => OO.getUint16(KO + 0, !0),
        recipe: (OO, KO) => OO.getUint16(KO + 2, !0),
        produces: (OO, KO) => OO.getUint16(KO + 4, !0),
        requires: (OO, KO) => OO.getUint16(KO + 6, !0),
        flags: (OO, KO) => OO.getUint8(KO + 8)
      },
      kp = {
        BYTES: 4,
        amount: (OO, KO) => OO.getUint16(KO + 0, !0),
        items: (OO, KO) => OO.getUint16(KO + 2, !0)
      },
      UK = {
        BYTES: 8,
        amount: (OO, KO) => OO.getUint32(KO + 0, !0),
        item: (OO, KO) => OO.getUint16(KO + 4, !0),
        from: (OO, KO) => OO.getUint16(KO + 6, !0)
      },
      Op = {
        BYTES: 16,
        serverId: (OO, KO) => OO.getInt32(KO + 0, !0),
        len: (OO, KO) => OO.getUint32(KO + 4, !0),
        kind: (OO, KO) => OO.getUint16(KO + 8, !0),
        variation: (OO, KO) => OO.getUint16(KO + 10, !0),
        pose: (OO, KO) => OO.getUint8(KO + 12),
        meta: (OO, KO) => OO.getUint8(KO + 13),
        mesh: (OO, KO) => OO.getUint8(KO + 14),
        flags: (OO, KO) => OO.getUint8(KO + 15)
      },
      Kp = {
        BYTES: 40,
        terrainOpaque: (OO, KO) => OO.getUint32(KO + 0, !0),
        terrainTransparent: (OO, KO) => OO.getUint32(KO + 4, !0),
        terrainPack: (OO, KO) => OO.getUint32(KO + 8, !0),
        earthSky: (OO, KO) => OO.getUint32(KO + 12, !0),
        skyMeshes: (OO, KO) => OO.getUint32(KO + 16, !0),
        regular: (OO, KO) => OO.getUint32(KO + 20, !0),
        thin: (OO, KO) => OO.getUint32(KO + 24, !0),
        line: (OO, KO) => OO.getUint32(KO + 28, !0),
        text: (OO, KO) => OO.getUint32(KO + 32, !0),
        particles: (OO, KO) => OO.getUint32(KO + 36, !0)
      },
      pp = {
        BYTES: 16,
        fov: (OO, KO) => OO.getFloat32(KO + 0, !0),
        baseFov: (OO, KO) => OO.getFloat32(KO + 4, !0),
        aspect: (OO, KO) => OO.getFloat32(KO + 8, !0),
        bodyHeading: (OO, KO) => OO.getFloat32(KO + 12, !0)
      },
      Xp = {
        BYTES: 32,
        eye: (OO, KO, pO) => OO.getFloat64(KO + 0 + 8 * pO, !0),
        heading: (OO, KO) => OO.getFloat32(KO + 24, !0),
        pitch: (OO, KO) => OO.getFloat32(KO + 28, !0)
      },
      bX = {
        BYTES: 40,
        feet: (OO, KO, pO) => OO.getFloat64(KO + 0 + 8 * pO, !0),
        eyeHeight: (OO, KO) => OO.getFloat32(KO + 24, !0),
        heading: (OO, KO) => OO.getFloat32(KO + 28, !0),
        headingIsDrawn: (OO, KO) => OO.getUint32(KO + 32, !0)
      },
      ep = 32,
      lp = 63,
      vX = {
        TickEnd: 32,
        EntitySpawned: 33,
        EntityDespawned: 34,
        ChangeBlockFail: 39,
        ChangeBlockFailEnd: 46,
        InventoryEvent: 48,
        HeldItemChanged: 49,
        ShotDamage: 50,
        EnchantOffer: 51,
        UiEvent: 52,
        EntityInfoChanged: 53,
        ChunkSlot: 55,
        PlaySound: 40,
        SoundPos: 41,
        SoundSet: 42,
        SoundFade: 43,
        SoundStop: 44,
        SoundReset: 45,
        ReplayFailed: 56,
        ReplayOption: 57,
        ReplayFilePart: 58,
        ReplayFileReady: 59,
        ReplayOpened: 60,
        ReplayUiEvent: 61,
        RecorderEvent: 62
      };

    function Cp(OO, KO, pO, XO, bK) {
      var eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO, QO, zK, AO, fO, dO, TO, NO, IO, yK, gK, uO, EO, jK;
      switch (OO) {
        case 32:
          return 4 === XO && (null === (eO = bK.tickEnd) || void 0 === eO || eO.call(bK, QK.KK(KO, pO)), !0);
        case 33:
          return 12 === XO && (null === (lO = bK.entitySpawned) || void 0 === lO || lO.call(bK, zp.serverId(KO, pO), zp.index(KO, pO), zp.kind(KO, pO)), !0);
        case 34:
          return 12 === XO && (null === (vK = bK.entityDespawned) || void 0 === vK || vK.call(bK, zp.serverId(KO, pO), zp.index(KO, pO), zp.kind(KO, pO)), !0);
        case 39:
          return !(XO < 20) && (null === (CO = bK.changeBlockFail) || void 0 === CO || CO.call(bK, AK.pos(KO, pO, 0), AK.pos(KO, pO, 1), AK.pos(KO, pO, 2), AK.actual(KO, pO), AK.dataLen(KO, pO), pO + 20, XO - 20), !0);
        case 46:
          return 0 === XO && (null === (hO = bK.changeBlockFailEnd) || void 0 === hO || hO.call(bK), !0);
        case 48:
          return 20 === XO && (null === (DO = bK.inventoryEvent) || void 0 === DO || DO.call(bK, fK.what(KO, pO), fK.value(KO, pO), fK.pos(KO, pO, 0), fK.pos(KO, pO, 1), fK.pos(KO, pO, 2), fK.block(KO, pO)), !0);
        case 49:
          return 4 === XO && (null === (MO = bK.heldItemChanged) || void 0 === MO || MO.call(bK, dK.item(KO, pO), dK.slot(KO, pO)), !0);
        case 50:
          return 16 === XO && (null === (aK = bK.shotDamage) || void 0 === aK || aK.call(bK, TK.target(KO, pO), TK.damage(KO, pO), TK.distance(KO, pO), TK.crit(KO, pO)), !0);
        case 51:
          return !(XO < 4) && (null === (oO = bK.enchantOffer) || void 0 === oO || oO.call(bK, NK.slot(KO, pO), pO + 4, XO - 4), !0);
        case 52:
          return !(XO < 20) && (null === (FO = bK.uiEvent) || void 0 === FO || FO.call(bK, IK.what(KO, pO), IK.value(KO, pO), IK.pos(KO, pO, 0), IK.pos(KO, pO, 1), IK.pos(KO, pO, 2), IK.block(KO, pO), pO + 20, XO - 20), !0);
        case 53:
          return 12 === XO && (null === (VO = bK.entityInfoChanged) || void 0 === VO || VO.call(bK, yp.serverId(KO, pO), yp.index(KO, pO), yp.what(KO, pO)), !0);
        case 55:
          return 24 === XO && (null === (LO = bK.chunkSlot) || void 0 === LO || LO.call(bK, gp.cx(KO, pO), gp.cy(KO, pO), gp.cz(KO, pO), gp.slot(KO, pO), gp.generation(KO, pO), gp.flags(KO, pO)), !0);
        case 40:
          return 44 === XO && (null === (QO = bK.playSound) || void 0 === QO || QO.call(bK, uK.pos(KO, pO, 0), uK.pos(KO, pO, 1), uK.pos(KO, pO, 2), uK.sound(KO, pO), uK.flags(KO, pO), uK.handle(KO, pO), uK.volume(KO, pO), uK.rate(KO, pO), uK.refDist(KO, pO)), !0);
        case 41:
          return 28 === XO && (null === (zK = bK.soundPos) || void 0 === zK || zK.call(bK, EK.pos(KO, pO, 0), EK.pos(KO, pO, 1), EK.pos(KO, pO, 2), EK.handle(KO, pO)), !0);
        case 42:
          return 16 === XO && (null === (AO = bK.soundSet) || void 0 === AO || AO.call(bK, jp.handle(KO, pO), jp.volume(KO, pO), jp.rate(KO, pO), jp.refDist(KO, pO)), !0);
        case 43:
          return 12 === XO && (null === (fO = bK.soundFade) || void 0 === fO || fO.call(bK, YK.handle(KO, pO), YK.to(KO, pO), YK.ms(KO, pO), YK.flags(KO, pO)), !0);
        case 44:
          return 4 === XO && (null === (dO = bK.soundStop) || void 0 === dO || dO.call(bK, wK.handle(KO, pO)), !0);
        case 45:
          return 0 === XO && (null === (TO = bK.soundReset) || void 0 === TO || TO.call(bK), !0);
        case 56:
          return 4 === XO && (null === (NO = bK.replayFailed) || void 0 === NO || NO.call(bK, ip.reason(KO, pO), ip.code(KO, pO)), !0);
        case 57:
          return !(XO < 4) && (null === (IO = bK.replayOption) || void 0 === IO || IO.call(bK, rp.key(KO, pO), rp.tag(KO, pO), pO + 4, XO - 4), !0);
        case 58:
          return 16 === XO && (null === (yK = bK.replayFilePart) || void 0 === yK || yK.call(bK, PK.save(KO, pO), PK.index(KO, pO), PK.ptr(KO, pO), PK.len(KO, pO)), !0);
        case 59:
          return 16 === XO && (null === (gK = bK.replayFileReady) || void 0 === gK || gK.call(bK, mp.save(KO, pO), mp.kind(KO, pO), mp.parts(KO, pO), mp.bytes(KO, pO)), !0);
        case 60:
          return !(XO < 4) && (null === (uO = bK.replayOpened) || void 0 === uO || uO.call(bK, sK.totalTicks(KO, pO), pO + 4, XO - 4), !0);
        case 61:
          return !(XO < 24) && (null === (EO = bK.replayUiEvent) || void 0 === EO || EO.call(bK, HK.what(KO, pO), HK.int(KO, pO), HK.x(KO, pO), HK.y(KO, pO), pO + 24, XO - 24), !0);
        case 62:
          return 8 === XO && (null === (jK = bK.recorderEvent) || void 0 === jK || jK.call(bK, RK.what(KO, pO), RK.kind(KO, pO), RK.save(KO, pO)), !0);
        default:
          return !1
      }
    }
    const hp = {
      SetChunkAddDistance: 2,
      WatchEntityInfo: 66,
      EventResync: 67,
      WatchPromptPick: 68,
      SetLocalDbId: 69,
      SetAltVeto: 128,
      EnchantOfferRequest: 130,
      ClearPickupDelay: 131,
      SyncOpMarker: 132,
      SetHooks: 133,
      SetPublicLobby: 144,
      ClickCodeBlock: 145,
      Send: 256,
      Leave: 257,
      SetPaused: 258,
      ParticleBurst: 320,
      ParticleStart: 321,
      ParticleUpdate: 322,
      ParticleStop: 323,
      ParticleEmitPoints: 324,
      ParticleStopAll: 325,
      InstancePool: 384,
      InstanceCommit: 385,
      GameMeshCreate: 386,
      GameMeshSet: 387,
      GameMeshDispose: 388,
      SetNametagOffset: 389,
      SetFacingTolerance: 390,
      SetGroundArrowStyle: 391,
      InstancePoolDispose: 392,
      MobModel: 393,
      MobModelSet: 394,
      MobModelDispose: 398,
      ThirdPersonFor: 448,
      FreecamMove: 450,
      ScriptedRelease: 451,
      SetZoom: 452,
      SwapZoom: 453,
      FreecamCmd: 454,
      SecondCentres: 455,
      SetCameraFar: 456,
      RecorderOption: 530,
      RecorderFlyingText: 531,
      RecorderPlayerKilled: 532,
      RecorderKillfeed: 533,
      Respawn: 576,
      BindCustomButtonKeys: 577,
      PressCustomButton: 578,
      PadMove: 579
    };
    let Dp = new Uint8Array(0);

    function Mp(OO) {
      return Dp.buffer !== OO.buffer && (Dp = new Uint8Array(OO.buffer)), Dp
    }

    function aX(OO, KO, pO) {
      const XO = OO.Ip(66, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint8(XO + 0, pO), !0
    }

    function op(OO, KO, pO) {
      const XO = OO.Ip(67, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint32(XO + 0, pO, !0), !0
    }

    function Fp(OO, KO, pO) {
      const XO = OO.Ip(68, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint8(XO + 0, pO), !0
    }

    function Vp(OO, KO, pO, XO) {
      const bK = OO.Ip(69, KO, 4 + XO.length);
      if (bK < 0) return !1;
      const eO = OO.view;
      return eO.setUint8(bK + 0, pO), Mp(eO).set(XO, eO.byteOffset + bK + 4), !0
    }

    function Lp(OO, KO, pO, XO, bK) {
      const eO = OO.Ip(128, KO, 4 + bK.length);
      if (eO < 0) return !1;
      const lO = OO.view;
      return lO.setUint8(eO + 0, pO), lO.setUint16(eO + 2, XO, !0), Mp(lO).set(bK, lO.byteOffset + eO + 4), !0
    }

    function Qp(OO, KO, pO) {
      const XO = OO.Ip(131, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setInt32(XO + 0, pO, !0), !0
    }

    function zX(OO, KO, pO) {
      const XO = OO.Ip(132, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint32(XO + 0, pO, !0), !0
    }

    function Ap(OO, KO, pO) {
      const XO = OO.Ip(133, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint32(XO + 0, pO, !0), !0
    }

    function fp(OO, KO, pO) {
      const XO = OO.Ip(144, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint8(XO + 0, pO), !0
    }

    function dp(OO, KO, pO, XO, bK) {
      const eO = OO.Ip(145, KO, 12);
      if (eO < 0) return !1;
      const lO = OO.view;
      return lO.setInt32(eO + 0, pO, !0), lO.setInt32(eO + 4, XO, !0), lO.setInt32(eO + 8, bK, !0), !0
    }

    function Tp(OO, KO, pO, XO) {
      const bK = OO.Ip(256, KO, 4 + XO.length);
      if (bK < 0) return !1;
      const eO = OO.view;
      return eO.setUint16(bK + 0, pO, !0), Mp(eO).set(XO, eO.byteOffset + bK + 4), !0
    }

    function Np(OO, KO, pO) {
      const XO = OO.Ip(258, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint8(XO + 0, pO), !0
    }

    function Ip(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
      const hO = OO.Ip(320, KO, 48 + CO.length);
      if (hO < 0) return !1;
      const DO = OO.view;
      DO.setUint32(hO + 0, pO, !0), DO.setUint16(hO + 4, XO, !0), DO.setUint16(hO + 6, bK, !0), DO.setUint32(hO + 8, eO, !0);
      for (let MO = 0; MO < 3; MO++) DO.setFloat64(hO + 12 + 8 * MO, lO[MO], !0);
      for (let MO = 0; MO < 3; MO++) DO.setFloat32(hO + 36 + 4 * MO, vK[MO], !0);
      return Mp(DO).set(CO, DO.byteOffset + hO + 48), !0
    }

    function yX(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
      const hO = OO.Ip(321, KO, 48 + CO.length);
      if (hO < 0) return !1;
      const DO = OO.view;
      DO.setUint32(hO + 0, pO, !0), DO.setInt32(hO + 4, XO, !0), DO.setUint16(hO + 8, bK, !0), DO.setUint16(hO + 10, eO, !0);
      for (let MO = 0; MO < 3; MO++) DO.setFloat64(hO + 12 + 8 * MO, lO[MO], !0);
      for (let MO = 0; MO < 3; MO++) DO.setFloat32(hO + 36 + 4 * MO, vK[MO], !0);
      return Mp(DO).set(CO, DO.byteOffset + hO + 48), !0
    }

    function gX(OO, KO, pO, XO, bK, eO, lO) {
      const vK = OO.Ip(322, KO, 44 + lO.length);
      if (vK < 0) return !1;
      const CO = OO.view;
      CO.setUint32(vK + 0, pO, !0), CO.setUint32(vK + 4, XO, !0);
      for (let hO = 0; hO < 3; hO++) CO.setFloat64(vK + 8 + 8 * hO, bK[hO], !0);
      for (let hO = 0; hO < 3; hO++) CO.setFloat32(vK + 32 + 4 * hO, eO[hO], !0);
      return Mp(CO).set(lO, CO.byteOffset + vK + 44), !0
    }

    function upO(OO, KO, pO) {
      const XO = OO.Ip(323, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint32(XO + 0, pO, !0), !0
    }

    function Ep(OO, KO, pO, XO, bK, eO) {
      const lO = OO.Ip(324, KO, 32 + eO.length);
      if (lO < 0) return !1;
      const vK = OO.view;
      vK.setUint32(lO + 0, pO, !0), vK.setUint32(lO + 4, XO, !0);
      for (let CO = 0; CO < 3; CO++) vK.setFloat64(lO + 8 + 8 * CO, bK[CO], !0);
      return Mp(vK).set(eO, vK.byteOffset + lO + 32), !0
    }

    function jX(OO, KO) {
      return !(OO.Ip(325, KO, 0) < 0)
    }

    function Yp(OO, KO, pO, XO, bK, eO) {
      const lO = OO.Ip(384, KO, 16);
      if (lO < 0) return !1;
      const vK = OO.view;
      return vK.setUint32(lO + 0, pO, !0), vK.setUint32(lO + 4, XO, !0), vK.setFloat32(lO + 8, bK, !0), vK.setFloat32(lO + 12, eO, !0), !0
    }

    function wp(OO, KO, pO, XO, bK, eO, lO) {
      const vK = OO.Ip(385, KO, 36 + lO.length);
      if (vK < 0) return !1;
      const CO = OO.view;
      CO.setUint32(vK + 0, pO, !0), CO.setUint32(vK + 4, XO, !0);
      for (let hO = 0; hO < 3; hO++) CO.setFloat64(vK + 8 + 8 * hO, bK[hO], !0);
      return CO.setUint32(vK + 32, eO, !0), Mp(CO).set(lO, CO.byteOffset + vK + 36), !0
    }

    function iX(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
      const hO = OO.Ip(386, KO, 56 + CO.length);
      if (hO < 0) return !1;
      const DO = OO.view;
      DO.setUint32(hO + 0, pO, !0), DO.setUint8(hO + 4, XO);
      for (let MO = 0; MO < 4; MO++) DO.setFloat32(hO + 8 + 4 * MO, bK[MO], !0);
      for (let MO = 0; MO < 3; MO++) DO.setFloat64(hO + 24 + 8 * MO, eO[MO], !0);
      return DO.setUint32(hO + 48, lO, !0), DO.setUint32(hO + 52, vK, !0), Mp(DO).set(CO, DO.byteOffset + hO + 56), !0
    }

    function rX(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
      const hO = OO.Ip(387, KO, 56);
      if (hO < 0) return !1;
      const DO = OO.view;
      DO.setUint32(hO + 0, pO, !0), DO.setUint16(hO + 4, XO, !0), DO.setUint8(hO + 6, bK);
      for (let MO = 0; MO < 3; MO++) DO.setFloat64(hO + 8 + 8 * MO, eO[MO], !0);
      for (let MO = 0; MO < 2; MO++) DO.setFloat32(hO + 32 + 4 * MO, lO[MO], !0);
      DO.setFloat32(hO + 40, vK, !0);
      for (let MO = 0; MO < 3; MO++) DO.setFloat32(hO + 44 + 4 * MO, CO[MO], !0);
      return !0
    }

    function Pp(OO, KO, pO) {
      const XO = OO.Ip(388, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint32(XO + 0, pO, !0), !0
    }

    function mX(OO, KO, pO, XO) {
      const bK = OO.Ip(389, KO, 8);
      if (bK < 0) return !1;
      const eO = OO.view;
      return eO.setInt32(bK + 0, pO, !0), eO.setFloat32(bK + 4, XO, !0), !0
    }

    function sp(OO, KO, pO, XO) {
      const bK = OO.Ip(390, KO, 8);
      if (bK < 0) return !1;
      const eO = OO.view;
      return eO.setInt32(bK + 0, pO, !0), eO.setFloat32(bK + 4, XO, !0), !0
    }

    function Hp(OO, KO, pO, XO, bK, eO) {
      const lO = OO.Ip(391, KO, 12);
      if (lO < 0) return !1;
      const vK = OO.view;
      return vK.setFloat32(lO + 0, pO, !0), vK.setFloat32(lO + 4, XO, !0), vK.setUint8(lO + 8, bK), vK.setUint8(lO + 9, eO), !0
    }

    function Rp(OO, KO, pO) {
      const XO = OO.Ip(392, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint32(XO + 0, pO, !0), !0
    }

    function Sp(OO, KO, pO, XO, bK) {
      const eO = OO.Ip(393, KO, 12);
      if (eO < 0) return !1;
      const lO = OO.view;
      return lO.setUint32(eO + 0, pO, !0), lO.setUint16(eO + 4, XO, !0), lO.setFloat32(eO + 8, bK, !0), !0
    }

    function Jp(OO, KO, pO, XO, bK, eO, lO) {
      const vK = OO.Ip(394, KO, 36);
      if (vK < 0) return !1;
      const CO = OO.view;
      CO.setUint32(vK + 0, pO, !0), CO.setUint16(vK + 4, XO, !0), CO.setUint8(vK + 6, bK);
      for (let hO = 0; hO < 3; hO++) CO.setFloat64(vK + 8 + 8 * hO, eO[hO], !0);
      return CO.setFloat32(vK + 32, lO, !0), !0
    }

    function cX(OO, KO, pO) {
      const XO = OO.Ip(398, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setUint32(XO + 0, pO, !0), !0
    }

    function Bp(OO, KO, pO) {
      const XO = OO.Ip(448, KO, 4);
      if (XO < 0) return !1;
      return OO.view.setFloat32(XO + 0, pO, !0), !0
    }

    function Zp(OO, KO, pO, XO) {
      const bK = OO.Ip(450, KO, 12);
      if (bK < 0) return !1;
      const eO = OO.view;
      for (let lO = 0; lO < 2; lO++) eO.setFloat32(bK + 0 + 4 * lO, pO[lO], !0);
      return eO.setUint8(bK + 8, XO), !0
    }

    function Gp(OO, KO, pO, XO) {
      const bK = OO.Ip(452, KO, 8);
      if (bK < 0) return !1;
      const eO = OO.view;
      return eO.setFloat32(bK + 0, pO, !0), eO.setUint8(bK + 4, XO), !0
    }

    function qX(OO, KO, pO, XO) {
      const bK = OO.Ip(454, KO, 4);
      if (bK < 0) return !1;
      const eO = OO.view;
      return eO.setUint8(bK + 0, pO), eO.setUint8(bK + 1, XO), !0
    }

    function xX(OO, KO, pO, XO) {
      const bK = OO.Ip(455, KO, 40);
      if (bK < 0) return !1;
      const eO = OO.view;
      for (let lO = 0; lO < 9; lO++) eO.setInt32(bK + 0 + 4 * lO, pO[lO], !0);
      return eO.setUint32(bK + 36, XO, !0), !0
    }

    function np(OO, KO, pO, XO) {
      const bK = OO.Ip(456, KO, 8);
      if (bK < 0) return !1;
      const eO = OO.view;
      return eO.setFloat32(bK + 0, pO, !0), eO.setUint8(bK + 4, XO), !0
    }

    function Wp(OO, KO, pO, XO) {
      const bK = OO.Ip(530, KO, 4 + XO.length);
      if (bK < 0) return !1;
      const eO = OO.view;
      return eO.setUint8(bK + 0, pO), Mp(eO).set(XO, eO.byteOffset + bK + 4), !0
    }

    function tX(OO, KO, pO, XO, bK, eO) {
      const lO = OO.Ip(531, KO, 12 + eO.length);
      if (lO < 0) return !1;
      const vK = OO.view;
      return vK.setFloat32(lO + 0, pO, !0), vK.setFloat32(lO + 4, XO, !0), vK.setUint32(lO + 8, bK, !0), Mp(vK).set(eO, vK.byteOffset + lO + 12), !0
    }

    function kX(OO, KO, pO, XO, bK, eO) {
      const lO = OO.Ip(532, KO, 12 + eO.length);
      if (lO < 0) return !1;
      const vK = OO.view;
      return vK.setInt32(lO + 0, pO, !0), vK.setInt32(lO + 4, XO, !0), vK.setUint32(lO + 8, bK, !0), Mp(vK).set(eO, vK.byteOffset + lO + 12), !0
    }

    function Up(OO, KO, pO, XO, bK) {
      const eO = OO.Ip(533, KO, 8 + bK.length);
      if (eO < 0) return !1;
      const lO = OO.view;
      return lO.setInt32(eO + 0, pO, !0), lO.setInt32(eO + 4, XO, !0), Mp(lO).set(bK, lO.byteOffset + eO + 8), !0
    }

    function OX(OO, KO) {
      return !(OO.Ip(576, KO, 0) < 0)
    }

    function KX(OO, KO, pO, XO, bK, eO) {
      const lO = OO.Ip(577, KO, 36 + eO.length);
      if (lO < 0) return !1;
      const vK = OO.view;
      vK.setUint8(lO + 0, pO);
      for (let CO = 0; CO < 16; CO++) vK.setUint8(lO + 4 + 1 * CO, XO[CO]);
      for (let CO = 0; CO < 16; CO++) vK.setUint8(lO + 20 + 1 * CO, bK[CO]);
      return Mp(vK).set(eO, vK.byteOffset + lO + 36), !0
    }

    function pX(OO, KO, pO, XO) {
      const bK = OO.Ip(578, KO, 4 + XO.length);
      if (bK < 0) return !1;
      const eO = OO.view;
      return eO.setUint8(bK + 0, pO), Mp(eO).set(XO, eO.byteOffset + bK + 4), !0
    }

    function XX(OO, KO, pO, XO, bK, eO, lO, vK) {
      const CO = OO.Ip(579, KO, 36);
      if (CO < 0) return !1;
      const hO = OO.view;
      return hO.setFloat64(CO + 0, pO, !0), hO.setFloat64(CO + 8, XO, !0), hO.setFloat64(CO + 16, bK, !0), hO.setFloat64(CO + 24, eO, !0), hO.setUint16(CO + 32, lO, !0), hO.setUint8(CO + 34, vK), !0
    }
    class bb {
      constructor(OO, KO) {
        this.core = OO, this.afterCall = KO
      }
      canModify(OO, KO, pO) {
        const XO = this.core.oaO(OO, KO, pO);
        return this.afterCall(), XO
      }
      terrainBlocked(OO, KO, pO, XO, bK) {
        const eO = this.core.MoO(OO, KO, pO, XO, bK);
        return this.afterCall(), eO
      }
      EKO(OO, KO, pO, XO) {
        const bK = this.core.Cp(OO, KO, pO, XO);
        return this.afterCall(), bK
      }
      blockData(OO, KO, pO) {
        const XO = this.core.MaO(OO, KO, pO);
        return this.afterCall(), XO
      }
      cameraSweep(OO, KO, pO, XO, bK, eO, lO) {
        const vK = this.core.XMO(OO, KO, pO, XO, bK, eO, lO);
        return this.afterCall(), vK
      }
      hasServerTarget(OO) {
        const KO = this.core.goO(OO);
        return this.afterCall(), KO
      }
      entityInteractable(OO) {
        const KO = this.core.daO(OO);
        return this.afterCall(), KO
      }
      entityCrouching(OO) {
        const KO = this.core.AaO(OO);
        return this.afterCall(), KO
      }
      predictServerPosition(OO, KO, pO, XO) {
        const bK = this.core.HaO(OO, KO, pO, XO);
        return this.afterCall(), bK
      }
      setOtherEntitySetting(OO, KO, pO) {
        const XO = this.core.CMO(OO, KO, pO);
        return this.afterCall(), XO
      }
      entityInfoBatch(OO) {
        const KO = this.core.MMO(OO);
        return this.afterCall(), KO
      }
      entityName(OO) {
        const KO = this.core.TaO(OO);
        return this.afterCall(), KO
      }
      hasEffect(OO, KO) {
        const pO = this.core.yoO(OO, KO);
        return this.afterCall(), pO
      }
      scratchPtr() {
        const OO = this.core.OMO();
        return this.afterCall(), OO
      }
      invSwap(OO, KO) {
        const pO = this.core.ioO(OO, KO);
        return this.afterCall(), pO
      }
      invMove(OO, KO, pO) {
        const XO = this.core.joO(OO, KO, pO);
        return this.afterCall(), XO
      }
      invQuickMove(OO, KO, pO, XO) {
        const bK = this.core.YaO(OO, KO, pO, XO);
        return this.afterCall(), bK
      }
      invRemove(OO, KO, pO) {
        const XO = this.core.waO(OO, KO, pO);
        return this.afterCall(), XO
      }
      invEnchant(OO, KO, pO, XO, bK) {
        const eO = this.core.EaO(OO, KO, pO, XO, bK);
        return this.afterCall(), eO
      }
      craft(OO, KO, pO) {
        const XO = this.core.craft(OO, KO, pO);
        return this.afterCall(), XO
      }
      salvage(OO, KO, pO) {
        const XO = this.core.salvage(OO, KO, pO);
        return this.afterCall(), XO
      }
      selectSlot(OO) {
        const KO = this.core.coO(OO);
        return this.afterCall(), KO
      }
      closeChest() {
        const OO = this.core.FaO();
        return this.afterCall(), OO
      }
      itemAttributesBatch(OO) {
        const KO = this.core.DMO(OO);
        return this.afterCall(), KO
      }
      itemNames() {
        const OO = this.core.FE();
        return this.afterCall(), OO
      }
      blockProps() {
        const OO = this.core.aoO();
        return this.afterCall(), OO
      }
      itemProps() {
        const OO = this.core.roO();
        return this.afterCall(), OO
      }
      salvageRecipe(OO) {
        const KO = this.core.oMO(OO);
        return this.afterCall(), KO
      }
      craftingView(OO, KO, pO) {
        const XO = this.core.hMO(OO, KO, pO);
        return this.afterCall(), XO
      }
      directorView() {
        const OO = this.core.pMO();
        return this.afterCall(), OO
      }
      directorDefaultPose() {
        const OO = this.core.baO();
        return this.afterCall(), OO
      }
      directorEntity(OO) {
        const KO = this.core.eMO(OO);
        return this.afterCall(), KO
      }
      directorPose(OO, KO, pO, XO, bK, eO) {
        const lO = this.core.lMO(OO, KO, pO, XO, bK, eO);
        return this.afterCall(), lO
      }
      passTimings(OO) {
        const KO = this.core.saO(OO);
        return this.afterCall(), KO
      }
      drawCensus() {
        const OO = this.core.zoO();
        return this.afterCall(), OO
      }
    }
  },
  38709: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO,
      d: () => vK,
      g: () => lO
    });
    var XO = pO(38717),
      bK = pO(3934),
      eO = pO(38721);

    function lO(OO) {
      return OO.payloadKind === bK.cc.Msgpack ? (0, XO.c)(OO.payload) : void 0
    }

    function vK(OO, KO) {
      if (KO.payloadKind === bK.cc.Bytes || KO.payloadKind === bK.cc.MsgpackBin) return (0, eO.d)(OO, KO.payload)
    }

    function CO(OO) {
      return null !== OO && "object" === typeof OO
    }
  },
  38723: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => MO,
      g: () => aK,
      k: () => oO,
      n: () => DO,
      q: () => LO
    });
    var XO = pO(3934),
      bK = pO(38732);
    const eO = new Map,
      lO = new Set,
      vK = new Set;
    let CO = 0,
      hO = 0;

    function DO(OO, KO) {
      let pO = eO.get(OO);
      return pO || (pO = new Set, eO.set(OO, pO)), pO.add(KO), () => {
        pO.delete(KO)
      }
    }

    function MO() {
      return 0 !== CO
    }

    function aK(OO) {
      return lO.add(OO), () => {
        lO.delete(OO)
      }
    }

    function oO(OO) {
      return vK.add(OO), () => {
        vK.delete(OO)
      }
    }
    const FO = "A raw message listener threw";

    function VO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : lO;
      for (const XO of KO) try {
        XO()
      } catch (pO) {
        OO ? (0, bK.p)(pO, FO) : console.error(FO, pO)
      }
    }
    const LO = {
      fire: function(OO) {
        if ("connection" === OO.type) {
          const KO = OO.phase === XO.F.Activated && OO.conn !== CO && OO.conn > hO,
            pO = (OO.phase === XO.F.Left || OO.phase === XO.F.Closed) && OO.conn === CO;
          return void(KO || pO ? (CO = KO ? OO.conn : 0, VO(!0)) : OO.phase === XO.F.Resumed && 0 !== CO && OO.conn > hO && (CO = OO.conn, VO(!0, vK)))
        }
        const KO = eO.get(OO.Tl);
        if (KO && OO.conn === CO && 0 !== CO)
          for (const XO of KO) try {
            XO(OO)
          } catch (pO) {
            (0, bK.p)(pO, FO)
          }
      },
      close: function(OO) {
        hO = Math.max(hO, OO, CO), 0 !== CO && (CO = 0, VO(!1))
      }
    }
  },
  38698: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO,
      d: () => CO,
      f: () => vK
    });
    var XO = pO(1123),
      bK = pO(38667);
    const eO = new TextDecoder,
      lO = new TextEncoder;

    function vK(OO, KO) {
      const pO = OO.queries.entityName(KO);
      if (pO === bK.Fc) return;
      const lO = OO.memoryData(OO.scratch(), 4 + pO, 4, "entity_name's answer");
      if (!lO) return;
      const vK = lO.getUint32(0, !0),
        CO = eO.decode(new Uint8Array(lO.buffer, lO.byteOffset + 4, pO));
      return (0, XO.c)(CO, !1, vK === bK.Nd ? null : vK)
    }

    function CO(OO, KO, pO) {
      const XO = lO.encode(pO);
      if (XO.length > bK.sb) return !1;
      const eO = OO.memoryView(Uint8Array, OO.scratch(), XO.length, "has_effect's name");
      return !!eO && (eO.set(XO), 1 === OO.queries.hasEffect(KO, XO.length))
    }

    function hO(OO, KO, pO, XO) {
      const lO = OO.queries.blockData(KO, pO, XO);
      if (lO === bK.Fc) return;
      const vK = OO.memoryView(Uint8Array, OO.scratch(), lO, "block_data's answer");
      return vK ? JSON.parse(eO.decode(vK)) : void 0
    }
  },
  38717: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => DO
    });
    const XO = new TextDecoder;

    function bK(OO) {
      const KO = new eO(OO),
        pO = KO.value();
      if (KO.at !== OO.length) throw new Error(`msgpack: ${OO.length-KO.at} bytes after the value`);
      return pO
    }
    class eO {
      constructor(OO) {
        this.bytes = OO, this.at = 0, this.depth = 0, this.view = void 0, this.view = new DataView(OO.buffer, OO.byteOffset, OO.byteLength)
      }
      value() {
        const OO = this.u8();
        if (OO <= 127) return OO;
        if (OO >= 224) return OO - 256;
        if (OO >= 128 && OO <= 143) return this.map(15 & OO);
        if (OO >= 144 && OO <= 159) return this.array(15 & OO);
        if (OO >= 160 && OO <= 191) return this.str(31 & OO);
        switch (OO) {
          case 192:
            return null;
          case 194:
            return !1;
          case 195:
            return !0;
          case 196:
            return this.bin(this.u8());
          case 197:
            return this.bin(this.u16());
          case 198:
            return this.bin(this.u32());
          case 199:
            return this.ext(this.u8());
          case 200:
            return this.ext(this.u16());
          case 201:
            return this.ext(this.u32());
          case 202:
            return this.view.getFloat32(this.take(4), !1);
          case 203:
            return this.view.getFloat64(this.take(8), !1);
          case 204:
            return this.u8();
          case 205:
            return this.u16();
          case 206:
            return this.u32();
          case 207:
            return this.int64(!1);
          case 208:
            return this.view.getInt8(this.take(1));
          case 209:
            return this.view.getInt16(this.take(2), !1);
          case 210:
            return this.view.getInt32(this.take(4), !1);
          case 211:
            return this.int64(!0);
          case 212:
            return this.ext(1);
          case 213:
            return this.ext(2);
          case 214:
            return this.ext(4);
          case 215:
            return this.ext(8);
          case 216:
            return this.ext(16);
          case 217:
            return this.str(this.u8());
          case 218:
            return this.str(this.u16());
          case 219:
            return this.str(this.u32());
          case 220:
            return this.array(this.u16());
          case 221:
            return this.array(this.u32());
          case 222:
            return this.map(this.u16());
          case 223:
            return this.map(this.u32());
          default:
            throw new Error(`msgpack: unknown byte 0x${OO.toString(16)} at ${this.at-1}`)
        }
      }
      take(OO) {
        const KO = this.at;
        if (KO + OO > this.bytes.length) throw new Error(`msgpack: ${OO} bytes past the end at ${KO}`);
        return this.at = KO + OO, KO
      }
      u8() {
        return this.view.getUint8(this.take(1))
      }
      u16() {
        return this.view.getUint16(this.take(2), !1)
      }
      u32() {
        return this.view.getUint32(this.take(4), !1)
      }
      int64(OO) {
        const KO = this.take(8);
        return OO ? this.view.getBigInt64(KO, !1) : this.view.getBigUint64(KO, !1)
      }
      str(OO) {
        const KO = this.take(OO),
          pO = this.bytes;
        if (OO < 16) {
          let bK = "";
          for (let eO = KO; eO < KO + OO; eO++) {
            const lO = pO[eO];
            if (lO >= 128) return XO.decode(pO.subarray(KO, KO + OO));
            bK += String.fromCharCode(lO)
          }
          return bK
        }
        return XO.decode(pO.subarray(KO, KO + OO))
      }
      bin(OO) {
        const KO = this.take(OO);
        return this.bytes.subarray(KO, KO + OO)
      }
      enter() {
        if (++this.depth > 512) throw new Error("msgpack: nested too deep")
      }
      array(OO) {
        this.enter();
        const KO = [];
        for (let pO = 0; pO < OO; pO++) KO.push(this.value());
        return this.depth--, KO
      }
      map(OO) {
        this.enter();
        const KO = {};
        for (let pO = 0; pO < OO; pO++) {
          const OO = this.value(),
            pO = this.value();
          KO["__proto__" === OO ? "__proto_" : String(OO)] = pO
        }
        return this.depth--, KO
      }
      ext(OO) {
        const KO = this.view.getInt8(this.take(1)),
          pO = this.take(OO);
        if (0 !== KO) {
          if (-1 === KO) {
            if (1 === OO) return new Date(NaN);
            if (4 === OO) return new Date(1e3 * this.view.getUint32(pO, !1));
            if (8 === OO) {
              const OO = this.view.getUint32(pO, !1),
                KO = OO >>> 2,
                XO = 4294967296 * (3 & OO) + this.view.getUint32(pO + 4, !1);
              return new Date(1e3 * XO + KO / 1e6)
            }
            if (12 === OO) {
              const OO = this.view.getUint32(pO, !1),
                KO = 4294967296 * this.view.getInt32(pO + 4, !1) + this.view.getUint32(pO + 8, !1);
              return new Date(1e3 * KO + OO / 1e6)
            }
          }
          throw new Error(`msgpack: ext type ${KO} of ${OO} bytes`)
        }
      }
    }
    const lO = new TextEncoder,
      vK = -(2n ** 63n),
      CO = 2n ** 63n - 1n,
      hO = 2n ** 64n - 1n;

    function DO(OO) {
      const KO = new MO;
      return KO.value(OO, 0), KO.bytes()
    }
    class MO {
      constructor() {
        this.buf = new Uint8Array(64), this.view = new DataView(this.buf.buffer), this.at = 0
      }
      bytes() {
        return this.buf.subarray(0, this.at)
      }
      value(OO, KO) {
        if (KO > 512) throw new Error("msgpack: nested too deep");
        switch (typeof OO) {
          case "undefined":
            return this.u8(212), this.u8(0), void this.u8(0);
          case "boolean":
            return void this.u8(OO ? 195 : 194);
          case "number":
            return void this.number(OO);
          case "bigint":
            return void this.bigint(OO);
          case "string":
            return void this.string(OO);
          case "object":
            if (null === OO) this.u8(192);
            else if (OO instanceof Uint8Array) this.head(OO.length, 196, -1, 197, 198), this.room(OO.length), this.buf.set(OO, this.at), this.at += OO.length;
            else if (Array.isArray(OO)) {
              this.head(OO.length, 220, 144, 220, 221);
              for (const pO of OO) this.value(pO, KO + 1)
            } else {
              var pO, XO;
              if (Object.getPrototypeOf(OO) !== Object.prototype && null !== Object.getPrototypeOf(OO)) throw new Error(`msgpack: can't encode a ${null!==(pO=null===(XO=OO.constructor)||void 0===XO?void 0:XO.name)&&void 0!==pO?pO:"object"}`);
              {
                const pO = Object.keys(OO);
                this.head(pO.length, 222, 128, 222, 223);
                for (const XO of pO) this.string(XO), this.value(OO[XO], KO + 1)
              }
            }
            return;
          default:
            throw new Error("msgpack: can't encode a " + typeof OO)
        }
      }
      number(OO) {
        Number.isInteger(OO) && OO >= -2147483648 && OO <= 4294967295 ? OO >= 0 ? OO < 128 ? this.u8(OO) : OO < 256 ? (this.u8(204), this.u8(OO)) : OO < 65536 ? (this.u8(205), this.u16(OO)) : (this.u8(206), this.u32(OO)) : OO >= -32 ? this.u8(OO + 256) : OO >= -128 ? (this.u8(208), this.u8(OO + 256)) : OO >= -32768 ? (this.u8(209), this.u16(OO + 65536)) : (this.u8(210), this.u32(OO >>> 0)) : (this.u8(203), this.room(8), this.view.setFloat64(this.at, OO, !1), this.at += 8)
      }
      bigint(OO) {
        const KO = OO >= vK && OO <= CO;
        if (!KO && (OO < 0n || OO > hO)) throw new Error("msgpack: a BigInt past 64 bits");
        this.u8(KO ? 211 : 207), this.room(8), KO ? this.view.setBigInt64(this.at, OO, !1) : this.view.setBigUint64(this.at, OO, !1), this.at += 8
      }
      string(OO) {
        const KO = lO.encode(OO);
        this.head(KO.length, 217, 160, 218, 219), this.room(KO.length), this.buf.set(KO, this.at), this.at += KO.length
      }
      head(OO, KO, pO, XO, bK) {
        pO >= 0 && OO < (160 === pO ? 32 : 16) ? this.u8(pO | OO) : KO !== XO && OO < 256 ? (this.u8(KO), this.u8(OO)) : OO < 65536 ? (this.u8(XO), this.u16(OO)) : (this.u8(bK), this.u32(OO))
      }
      room(OO) {
        if (this.at + OO <= this.buf.length) return;
        let KO = 2 * this.buf.length;
        for (; KO < this.at + OO;) KO *= 2;
        const pO = new Uint8Array(KO);
        pO.set(this.buf.subarray(0, this.at)), this.buf = pO, this.view = new DataView(pO.buffer)
      }
      u8(OO) {
        this.room(1), this.buf[this.at++] = OO
      }
      u16(OO) {
        this.room(2), this.view.setUint16(this.at, OO, !1), this.at += 2
      }
      u32(OO) {
        this.room(4), this.view.setUint32(this.at, OO, !1), this.at += 4
      }
    }
  },
  38721: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO
    });
    var XO = pO(38700);
    const bK = new TextDecoder("utf-8", {
      ignoreBOM: !0
    });
    class eO {
      constructor(OO) {
        this.buf = OO, this.at = 0, this.view = null
      }
      bool() {
        return 0 !== this.u8()
      }
      long() {
        let OO = this.u8(),
          KO = 127 & OO,
          pO = 128;
        for (; 128 & OO;) {
          if (pO > 2 ** 63) throw new RangeError("avro: varint too long");
          OO = this.u8(), KO += (127 & OO) * pO, pO *= 128
        }
        return KO % 2 === 1 ? -(KO + 1) / 2 : KO / 2
      }
      float() {
        const OO = this.take(4);
        return this.floats().getFloat32(OO, !0)
      }
      double() {
        const OO = this.take(8);
        return this.floats().getFloat64(OO, !0)
      }
      str() {
        const OO = this.size(),
          KO = this.take(OO),
          pO = KO + OO;
        if (OO <= 32) {
          let OO = "";
          for (let XO = KO; XO < pO; XO++) {
            const eO = this.buf[XO];
            if (eO >= 128) return bK.decode(this.buf.subarray(KO, pO));
            OO += String.fromCharCode(eO)
          }
          return OO
        }
        return bK.decode(this.buf.subarray(KO, pO))
      }
      bytes() {
        return this.fixed(this.size())
      }
      fixed(OO) {
        const KO = this.take(OO);
        return this.buf.slice(KO, KO + OO)
      }
      index(OO) {
        const KO = this.long();
        if (!(KO >= 0 && KO < OO)) throw new RangeError(`avro: index ${KO} of ${OO}`);
        return KO
      }
      wX(OO) {
        const KO = [];
        for (let pO = this.long(); 0 !== pO; pO = this.long()) {
          pO = this.block(pO);
          for (let XO = 0; XO < pO; XO++) KO.push(OO(this))
        }
        return KO
      }
      map(OO) {
        const KO = {};
        for (let pO = this.long(); 0 !== pO; pO = this.long()) {
          pO = this.block(pO);
          for (let XO = 0; XO < pO; XO++) {
            KO[this.str()] = OO(this)
          }
        }
        return KO
      }
      end() {
        if (this.at !== this.buf.length) throw new RangeError(`avro: ${this.buf.length-this.at} bytes after the value`)
      }
      block(OO) {
        let KO = OO;
        if (KO < 0 && (KO = -KO, this.long()), KO > this.buf.length - this.at) throw new RangeError(`avro: block of ${KO} items in ${this.buf.length-this.at} bytes`);
        return KO
      }
      floats() {
        return this.view ??= new DataView(this.buf.buffer, this.buf.byteOffset, this.buf.byteLength), this.view
      }
      size() {
        const OO = this.long();
        if (OO < 0) throw new RangeError(`avro: length ${OO}`);
        return OO
      }
      u8() {
        const OO = this.buf[this.at];
        if (void 0 === OO) throw new RangeError("avro: truncated");
        return this.at++, OO
      }
      take(OO) {
        const KO = this.at;
        if (OO > this.buf.length - KO) throw new RangeError("avro: truncated");
        return this.at = KO + OO, KO
      }
    }

    function lO(OO, KO) {
      const pO = new eO(KO),
        bK = (0, XO.hb)(OO, pO);
      return pO.end(), bK
    }
  },
  38700: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => hO,
      D: () => lO,
      F: () => uO,
      H: () => bK,
      L: () => vK,
      M: () => oO,
      O: () => yK,
      S: () => IO,
      U: () => TO,
      W: () => DO,
      Y: () => MO,
      Z: () => gK,
      ab: () => FO,
      bb: () => AO,
      e: () => dO,
      fb: () => VO,
      gb: () => CO,
      h: () => LO,
      hb: () => EO,
      i: () => QO,
      l: () => zK,
      m: () => NO,
      p: () => XO,
      s: () => eO,
      t: () => fO,
      w: () => aK
    });
    const XO = 2,
      bK = 12,
      eO = 27,
      lO = 40,
      vK = 52,
      CO = 59,
      hO = 63,
      DO = 83,
      MO = 84,
      aK = 89,
      oO = 91,
      FO = 93,
      VO = 94,
      LO = 95,
      QO = 97,
      zK = 101,
      AO = 102,
      fO = 73,
      dO = 16,
      TO = 86,
      NO = 60,
      IO = 17,
      yK = 56,
      gK = 100,
      uO = 81;

    function EO(OO, KO) {
      switch (OO) {
        case XO:
          return function(OO) {
            return {
              HOO: nO(OO),
              ROO: OO.float(),
              SOO: OO.long()
            }
          }(KO);
        case bK:
          return function(OO) {
            return {
              pOO: rK(OO),
              XOO: rK(OO)
            }
          }(KO);
        case eO:
          return function(OO) {
            return {
              pW: OO.bool(),
              DW: rK(OO)
            }
          }(KO);
        case lO:
          return KO.str();
        case vK:
          return function(OO) {
            return {
              id: OO.long(),
              r_: lK(OO)
            }
          }(KO);
        case CO:
        case hO:
          return KO.str();
        case DO:
        case MO:
          return KO.long();
        case aK:
          return function(OO) {
            return {
              bOO: OO.long(),
              vOO: OO.bool(),
              aOO: OO.float()
            }
          }(KO);
        case oO:
          return KO.long();
        case FO:
          return function(OO) {
            return {
              qOO: OO.bool(),
              jsO: hK(OO)
            }
          }(KO);
        case VO:
          return function(OO) {
            return {
              id: OO.str(),
              position: CK(OO),
              text: DK(OO),
              style: SO(OO),
              Dk: OO.bool()
            }
          }(KO);
        case LO:
          return function(OO) {
            return {
              id: rK(OO)
            }
          }(KO);
        case QO:
          return function(OO) {
            return {
              Zm: OO.long(),
              Wm: OO.str(),
              Xs: bp(OO),
              lKO: bp(OO),
              vpO: rK(OO),
              Fs: rK(OO),
              CKO: rK(OO),
              hKO: rK(OO),
              DKO: rK(OO),
              Qs: bp(OO),
              jH: bp(OO),
              MKO: rK(OO),
              apO: rK(OO),
              FKO: rK(OO)
            }
          }(KO);
        case zK:
          return KO.str();
        case AO:
          return KO.long();
        case fO:
          return function(OO) {
            return {
              Z2: OO.long(),
              A7: OO.str(),
              N7: OO.float()
            }
          }(KO);
        case dO:
          return function(OO) {
            return {
              VOO: OO.bool(),
              LOO: rK(OO),
              QOO: OO.str(),
              hiO: ap(OO),
              zKO: ap(OO),
              AOO: OO.bool(),
              fOO: OO.long(),
              dOO: oK(OO)
            }
          }(KO);
        case TO:
          return function(OO) {
            return {
              P5: rK(OO)
            }
          }(KO);
        case NO:
          return function(OO) {
            return {
              Qm: OO.str(),
              Am: OO.str(),
              Tm: FK(OO),
              v_: OO.str(),
              Q0: kK(OO),
              y_: OO.float()
            }
          }(KO);
        case IO:
          return function(OO) {
            return {
              Qm: OO.str(),
              Am: OO.str(),
              Tm: FK(OO)
            }
          }(KO);
        case yK:
          return function(OO) {
            return OO.wX(VK)
          }(KO);
        case gK:
          return function(OO) {
            return {
              W4: QK(OO),
              t5: BO(OO)
            }
          }(KO);
        case uO:
          return function(OO) {
            return {
              eOO: OO.bool(),
              lOO: rK(OO),
              Ql: AK(OO),
              fe: PK(OO)
            }
          }(KO);
        default:
          throw new Error(`no reader for to-client message ${OO}`)
      }
    }

    function jK(OO) {
      return {
        entityName: OO.str()
      }
    }

    function YO(OO) {
      const KO = OO.index(4);
      return 0 === KO ? OO.str() : 1 === KO ? OO.long() : 2 === KO ? OO.bool() : jK(OO)
    }

    function wO(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return OO.map(YO)
      }(OO)
    }

    function iK(OO) {
      return {
        translationKey: OO.str(),
        params: wO(OO)
      }
    }

    function rK(OO) {
      return 0 === OO.index(2) ? null : OO.str()
    }

    function PO(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          color: rK(OO),
          colour: rK(OO),
          fontSize: rK(OO)
        }
      }(OO)
    }

    function mK(OO) {
      return {
        icon: OO.str(),
        style: PO(OO)
      }
    }

    function sO(OO) {
      const KO = OO.index(3);
      return 0 === KO ? {
        string: OO.str()
      } : 1 === KO ? {
        styledEntityName: jK(OO)
      } : {
        styledTranslatedText: iK(OO)
      }
    }

    function HO(OO) {
      const KO = OO.index(3);
      return 0 === KO ? null : 1 === KO ? OO.str() : OO.long()
    }

    function RO(OO) {
      return 0 === OO.index(2) ? null : OO.float()
    }

    function SO(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          color: rK(OO),
          colour: rK(OO),
          fontWeight: HO(OO),
          fontStyle: rK(OO),
          fontSize: rK(OO),
          opacity: RO(OO)
        }
      }(OO)
    }

    function JO(OO) {
      return {
        str: sO(OO),
        style: SO(OO),
        clickableUrl: rK(OO)
      }
    }

    function cK(OO) {
      return OO.str()
    }

    function BO(OO) {
      return OO.wX(cK)
    }

    function ZO(OO) {
      return 0 === OO.index(2) ? null : BO(OO)
    }

    function GO(OO) {
      return {
        type: OO.str(),
        progress: OO.float(),
        width: rK(OO),
        height: rK(OO),
        colours: ZO(OO),
        backgroundColour: rK(OO)
      }
    }

    function qK(OO) {
      return {
        type: OO.str(),
        action: OO.str(),
        style: SO(OO)
      }
    }

    function xK(OO) {
      const KO = OO.index(7);
      return 0 === KO ? {
        string: OO.str()
      } : 1 === KO ? {
        entityName: jK(OO)
      } : 2 === KO ? {
        translatedText: iK(OO)
      } : 3 === KO ? {
        styledIcon: mK(OO)
      } : 4 === KO ? {
        Kw: JO(OO)
      } : 5 === KO ? {
        styledProgressBar: GO(OO)
      } : {
        styledKeyBinding: qK(OO)
      }
    }

    function nO(OO) {
      return OO.wX(xK)
    }
    const WO = ["progressBar", "timedClick", "gravityBar", "precisionBar", "rhythmClick"];

    function tK(OO) {
      return WO[OO.index(5)]
    }

    function kK(OO) {
      return 0 === OO.index(2) ? null : OO.double()
    }

    function UO(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          RP: kK(OO),
          k_: OO.double(),
          p_: OO.double(),
          qm: OO.bool(),
          description: nO(OO),
          e_: OO.str(),
          scale: kK(OO),
          rotation: kK(OO)
        }
      }(OO)
    }

    function OK(OO) {
      return 0 === OO.index(2) ? null : OO.bool()
    }

    function KK(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          h_: OO.double(),
          icon: OO.str(),
          label: nO(OO),
          M_: OO.bool(),
          scale: kK(OO),
          rotation: kK(OO),
          o_: OK(OO)
        }
      }(OO)
    }

    function pK(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          RP: kK(OO),
          L_: OO.double(),
          Q_: OO.double(),
          A_: OO.double(),
          gravity: OO.double(),
          f_: OO.double(),
          T_: OO.double(),
          N_: OO.double(),
          qm: OO.bool(),
          description: nO(OO),
          icon: rK(OO)
        }
      }(OO)
    }

    function XK(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          speed: OO.double(),
          Y_: OO.double(),
          label: nO(OO),
          icon: rK(OO),
          scale: kK(OO),
          rotation: kK(OO)
        }
      }(OO)
    }

    function bp(OO) {
      return 0 === OO.index(2) ? null : OO.long()
    }

    function eK(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          R_: OO.long(),
          S_: OO.double(),
          J_: OO.double(),
          B_: bp(OO),
          label: nO(OO),
          icon: rK(OO)
        }
      }(OO)
    }

    function lK(OO) {
      return {
        type: tK(OO),
        progressBar: UO(OO),
        timedClick: KK(OO),
        gravityBar: pK(OO),
        precisionBar: XK(OO),
        rhythmClick: eK(OO)
      }
    }

    function vp(OO) {
      return OO.float()
    }

    function CK(OO) {
      return OO.wX(vp)
    }

    function hK(OO) {
      return 0 === OO.index(2) ? null : CK(OO)
    }

    function DK(OO) {
      return 0 === OO.index(2) ? null : nO(OO)
    }

    function MK(OO) {
      return OO.long()
    }

    function ap(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return OO.wX(MK)
      }(OO)
    }

    function oK(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          Rm: OO.str(),
          Jm: OO.long()
        }
      }(OO)
    }

    function FK(OO) {
      const KO = OO.index(3);
      return 0 === KO ? null : 1 === KO ? OO.str() : iK(OO)
    }

    function VK(OO) {
      return {
        EW: OO.str(),
        oV: OO.str(),
        VV: OO.str()
      }
    }

    function LK(OO) {
      return {
        y5: OO.str(),
        E1: rK(OO),
        Y1: rK(OO),
        i5: BO(OO)
      }
    }

    function QK(OO) {
      return OO.wX(LK)
    }

    function zp(OO) {
      return {
        fp: OO.str(),
        x: OO.long(),
        y: OO.long(),
        z: OO.long()
      }
    }

    function AK(OO) {
      return OO.wX(zp)
    }

    function fK(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          cl: OO.float(),
          kl: OO.long(),
          Ue: OO.long()
        }
      }(OO)
    }

    function dK(OO) {
      return {
        blockName: OO.str(),
        Be: OO.bool(),
        Ze: OO.bool(),
        Ge: OO.bool(),
        Je: OO.float(),
        tl: OO.float(),
        He: OO.long(),
        ne: fK(OO)
      }
    }

    function TK(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return OO.wX(dK)
      }(OO)
    }

    function NK(OO) {
      return {
        Ie: OO.str(),
        ql: TK(OO)
      }
    }

    function IK(OO) {
      return {
        blockName: OO.str(),
        frequency: OO.float()
      }
    }

    function yp(OO) {
      return OO.wX(IK)
    }

    function gp(OO) {
      return {
        de: OO.str(),
        Te: OO.str(),
        frequency: OO.float(),
        Ne: yp(OO)
      }
    }

    function uK(OO) {
      return OO.wX(gp)
    }

    function EK(OO) {
      return {
        blockName: OO.str(),
        radius: OO.long(),
        il: OO.long(),
        pp: OO.long(),
        ep: OO.long(),
        ml: OO.float()
      }
    }

    function jp(OO) {
      return OO.wX(EK)
    }

    function YK(OO) {
      return {
        pp: OO.long(),
        ep: OO.long(),
        rl: OO.long(),
        Pe: OO.bool(),
        ge: NK(OO),
        wb: uK(OO),
        AO: jp(OO)
      }
    }

    function wK(OO) {
      return OO.wX(YK)
    }

    function ip(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          name: OO.str(),
          Ll: rK(OO)
        }
      }(OO)
    }

    function rp(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          terrain: ip(OO),
          Kl: jp(OO)
        }
      }(OO)
    }

    function PK(OO) {
      return 0 === OO.index(2) ? null : function(OO) {
        return {
          layers: wK(OO),
          Ol: rp(OO)
        }
      }(OO)
    }
  },
  37577: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      d: () => vK
    });
    var XO = pO(256),
      bK = pO(3651);
    const eO = new Set(bK.o),
      lO = new Map;

    function vK(OO, KO) {
      let pO = lO.get(KO);
      void 0 === pO && (pO = new Map, lO.set(KO, pO));
      let bK = pO.get(OO);
      return void 0 === bK && (bK = `${OO}${(0,XO.A)(KO)}`, pO.set(OO, bK)), bK
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);