export const id = 335;
export const ids = [335];
export const modules = {
  59088: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      WorldCodeAiDeepSeekNotice: () => lO,
      deepSeekPrivacyPolicyUrl: () => eO
    });
    var XO = pO(1051),
      bK = pO(976);
    const eO = "https://cdn.deepseek.com/policies/en-US/deepseek-privacy-policy.html";

    function lO() {
      const {
        t: OO
      } = (0, XO.D)();
      return (0, bK.jsxs)(bK.Fragment, {
        children: [OO("superBotXd:deepSeekNotice"), " ", (0, bK.jsxs)("a", {
          className: "WorldCodeAiDeepSeekPolicyLink",
          href: eO,
          target: "_blank",
          rel: "noreferrer noopener",
          children: [OO("superBotXd:deepSeekPrivacyPolicy"), " ", (0, bK.jsx)("span", {
            "aria-hidden": "true",
            children: "\u2197"
          })]
        })]
      })
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);