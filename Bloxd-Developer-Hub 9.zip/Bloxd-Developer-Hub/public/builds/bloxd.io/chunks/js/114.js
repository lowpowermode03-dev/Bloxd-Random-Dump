export const id = 114;
export const ids = [114];
export const modules = {
  5680: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(1051),
      lO = pO(976);

    function vK(OO) {
      let {
        item: KO,
        className: pO
      } = OO;
      const {
        t: XO
      } = (0, eO.D)();
      return null === KO.renderId || KO.previewsOutdated ? (0, lO.jsx)("div", {
        className: bK()("ShaderPackPreviewsNotice", pO),
        children: (0, lO.jsx)("span", {
          children: XO(null === KO.renderId ? "shaderPackListing:screenshotsNotGenerated" : "shaderPackListing:screenshotsNotRegenerated")
        })
      }) : null
    }
  },
  5698: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => hO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(5678),
      lO = pO(1051),
      vK = pO(5674),
      CO = pO(976);

    function hO(OO) {
      let {
        selected: KO,
        onSelect: pO,
        imageUrl: XO
      } = OO;
      const {
        t: hO
      } = (0, lO.D)();
      return (0, CO.jsx)("div", {
        className: "ShaderPackViewPicker",
        children: eO.y.map((OO => {
          const eO = XO(OO);
          return (0, CO.jsxs)("button", {
            type: "button",
            "aria-pressed": OO === KO,
            className: bK()("ShaderPackViewOption", {
              Selected: OO === KO
            }),
            onClick: () => {
              pO(OO)
            },
            children: [null !== eO && (0, CO.jsx)("img", {
              src: eO,
              alt: "",
              loading: "lazy",
              draggable: !1
            }), (0, CO.jsx)("span", {
              className: "SmallTextBold",
              children: hO(vK.bb[OO])
            })]
          }, OO)
        }))
      })
    }
  },
  5684: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => aK,
      g: () => oO,
      i: () => MO,
      j: () => FO
    });
    var XO = pO(63),
      bK = pO(5678),
      eO = pO(1329),
      lO = pO(5674),
      vK = pO(5691),
      CO = pO(1004);
    const hO = "shaderPackListingView",
      DO = "shaderPackListingFilterOpen";

    function MO() {
      var OO;
      const [KO, pO] = (0, vK.d)(hO, bK.y[0]);
      return [null !== (OO = bK.y.find((OO => OO === KO))) && void 0 !== OO ? OO : bK.y[0], pO]
    }

    function aK() {
      (0, XO.useEffect)((() => () => {
        window.location.pathname.startsWith(lO.S) || (0, lO.i)()
      }), [])
    }

    function oO() {
      return (0, vK.d)(DO, !1)
    }

    function FO() {
      const {
        userContext: OO,
        isUserContextUpdating: KO
      } = (0, CO.d)(), [pO, bK] = (0, XO.useState)(null), lO = (0, XO.useRef)(new Set);

      function vK(OO, KO) {
        bK((pO => {
          const XO = new Set(pO);
          return KO ? XO.add(OO) : XO.delete(OO), XO
        }))
      }
      return (0, XO.useEffect)((() => {
        if (KO) return;
        let pO = !1;
        return eO.c.getFavouriteShaderPacks(OO).then((OO => {
          pO || bK(new Set(OO))
        })).catch((OO => {
          console.error("Failed to get favourite shader packs", OO), pO || bK(new Set)
        })), () => {
          pO = !0
        }
      }), [OO, KO]), {
        isFavourite: OO => null === pO ? null : pO.has(OO),
        toggle: function(KO) {
          if (null === pO || lO.current.has(KO)) return;
          lO.current.add(KO);
          const XO = !pO.has(KO);
          vK(KO, XO), (XO ? eO.c.favouriteShaderPack(OO, KO) : eO.c.unfavouriteShaderPack(OO, KO)).catch((OO => {
            console.error("Failed to change a favourite shader pack", OO), vK(KO, !XO)
          })).finally((() => {
            lO.current.delete(KO)
          }))
        }
      }
    }
  },
  5674: (OO, KO, pO) => {
    pO.d(KO, {
      $: () => rK,
      B: () => QO,
      C: () => uO,
      G: () => DO,
      I: () => jK,
      M: () => VO,
      O: () => HO,
      Q: () => mK,
      S: () => lO,
      V: () => sO,
      Y: () => CO,
      _: () => vK,
      bb: () => PO,
      cb: () => AO,
      db: () => EO,
      e: () => zK,
      g: () => yK,
      h: () => LO,
      i: () => aK,
      k: () => MO,
      n: () => YO,
      r: () => oO,
      v: () => wO,
      w: () => RO,
      z: () => FO
    });
    var XO = pO(5678),
      bK = pO(149),
      eO = pO(3738);
    const lO = "/shader-packs",
      vK = `${lO}/publish`;

    function CO(OO) {
      return `${lO}/${encodeURIComponent(OO)}`
    }
    let hO = null;

    function DO(OO) {
      hO = OO
    }

    function MO() {
      return hO
    }

    function aK() {
      hO = null
    }

    function oO(OO) {
      return OO.playerHasRank("developer") || OO.playerHasRank("admin")
    }
    const FO = ["terrain", "water", "models", "sunShadows", "strict"],
      VO = {
        terrain: "shaderPackListing:filterTerrain",
        water: "shaderPackListing:filterWater",
        models: "shaderPackListing:filterModels",
        sunShadows: "shaderPackListing:filterShadows",
        strict: "shaderPackListing:filterAllGames"
      };

    function LO(OO, KO) {
      return OO.withFeatures.includes(KO) ? "with" : OO.withoutFeatures.includes(KO) ? "without" : null
    }

    function QO(OO) {
      return null === OO ? "with" : "with" === OO ? "without" : null
    }

    function zK(OO) {
      return "with" === OO ? "only" : null === OO ? "include" : void 0
    }

    function AO(OO, KO) {
      const pO = LO(OO, KO),
        XO = OO => OO.filter((OO => OO !== KO));
      return {
        withFeatures: null === pO ? [...OO.withFeatures, KO] : XO(OO.withFeatures),
        withoutFeatures: "with" === pO ? [...OO.withoutFeatures, KO] : XO(OO.withoutFeatures)
      }
    }
    const fO = "section",
      dO = "sort",
      TO = "filters",
      NO = "q",
      IO = "banned",
      yK = "popular",
      gK = "strict";

    function uO(OO) {
      var KO, pO, bK;
      const lO = OO.get(fO),
        vK = (null !== (KO = OO.get(TO)) && void 0 !== KO ? KO : gK).split(","),
        CO = OO.get(IO);
      return {
        section: "favourites" === lO || "mine" === lO ? lO : "explore",
        sort: null !== (pO = XO.v.find((KO => KO === OO.get(dO)))) && void 0 !== pO ? pO : yK,
        withFeatures: FO.filter((OO => vK.includes(OO) && !vK.includes(`-${OO}`))),
        withoutFeatures: FO.filter((OO => vK.includes(`-${OO}`))),
        searchQuery: (null === (bK = OO.get(NO)) || void 0 === bK ? void 0 : bK.slice(0, XO.E)) || null,
        pageNumber: (0, eO.f)(OO.get(eO.d)),
        banned: "only" === CO ? "with" : "include" === CO ? null : "without"
      }
    }

    function EO(OO, KO) {
      var pO;
      const XO = iK(KO);
      (0, eO.g)(OO, fO, "explore" === KO.section ? null : KO.section), (0, eO.g)(OO, dO, KO.sort === yK ? null : KO.sort), (0, eO.g)(OO, TO, XO === gK ? null : XO), (0, eO.g)(OO, NO, KO.searchQuery), (0, eO.g)(OO, IO, null !== (pO = zK(KO.banned)) && void 0 !== pO ? pO : null), (0, eO.k)(OO, KO.pageNumber)
    }

    function jK(OO) {
      const KO = new URLSearchParams;
      return EO(KO, {
        section: "explore",
        sort: yK,
        withFeatures: "strict" === OO ? [OO] : [OO, "strict"],
        withoutFeatures: [],
        searchQuery: null,
        pageNumber: 1,
        banned: "without"
      }), `${lO}?${KO.toString()}`
    }

    function YO(OO) {
      return iK(OO) === gK
    }

    function wO(OO) {
      return null !== OO.searchQuery || "with" === OO.banned || iK(OO) !== gK
    }

    function iK(OO) {
      return FO.flatMap((KO => {
        const pO = LO(OO, KO);
        return "with" === pO ? [KO] : "without" === pO ? [`-${KO}`] : []
      })).join(",")
    }
    const rK = {
        popular: "shaderPackListing:sortPopular",
        updated: "shaderPackListing:sortUpdated",
        newest: "shaderPackListing:sortNewest"
      },
      PO = {
        forest: "shaderPackListing:viewForest",
        desert: "shaderPackListing:viewDesert",
        water: "shaderPackListing:viewWater",
        night: "shaderPackListing:viewNight",
        cave: "shaderPackListing:viewCave"
      };

    function mK(OO) {
      return Math.round(100 * Math.max(0, 1 - 1 / OO))
    }

    function sO(OO, KO, pO, bK) {
      const eO = [];
      OO.isBanned && eO.push({
        tone: "warning",
        text: bK("shaderPackListing:ownerBanned"),
        detail: null
      });
      const {
        pending: lO
      } = OO;
      if (null === OO.brokenError || lO && !lO.error || eO.push({
          tone: "warning",
          text: bK("shaderPackListing:ownerBroken"),
          detail: OO.brokenError
        }), null !== lO && void 0 !== lO && lO.error) eO.push({
        tone: "warning",
        text: bK(KO ? "shaderPackListing:ownerUpdateFailed" : "shaderPackListing:ownerFirstFailed"),
        detail: (0, XO.m)(lO.error) ? null : lO.error
      });
      else if (lO) {
        const OO = null === lO.renderNotBefore ? 0 : lO.renderNotBefore - pO,
          XO = String(Math.ceil(OO / 6e4)),
          vK = bK(KO ? OO > 0 ? "shaderPackListing:ownerUpdateWaiting" : "shaderPackListing:ownerUpdateSoon" : OO > 0 ? "shaderPackListing:ownerFirstWaiting" : "shaderPackListing:ownerFirstSoon", {
            minutes: XO
          });
        eO.push({
          tone: "info",
          text: vK,
          detail: null
        })
      }
      return OO.listed || eO.push({
        tone: "info",
        text: bK("shaderPackListing:ownerUnlisted"),
        detail: null
      }), eO
    }

    function HO(OO) {
      return Math.max(1, Math.round(OO / 1024))
    }

    function RO(OO, KO, pO) {
      return OO instanceof bK.b && OO.errorMessageForUser ? OO.errorMessageForUser : KO(pO)
    }
  },
  5691: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(63),
      bK = pO(36);

    function eO(OO, KO) {
      var pO;
      const [eO, lO] = (0, XO.useState)(null !== (pO = bK.e.getItem(OO)) && void 0 !== pO ? pO : KO);
      return [eO, KO => {
        bK.e.setItem(OO, KO), lO(KO)
      }]
    }
  },
  5678: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => aK,
      E: () => DO,
      F: () => AO,
      G: () => MO,
      H: () => hO,
      d: () => oO,
      g: () => VO,
      i: () => FO,
      m: () => zK,
      o: () => dO,
      s: () => CO,
      t: () => bK,
      u: () => fO,
      v: () => eO,
      w: () => vK,
      x: () => lO,
      y: () => XO
    });
    const XO = ["forest", "desert", "water", "night", "cave"];
    const bK = {
        full: {
          width: 3840,
          height: 2160
        },
        large: {
          width: 1920,
          height: 1080
        },
        thumb: {
          width: 640,
          height: 360
        }
      },
      eO = ["popular", "updated", "newest"],
      lO = 3,
      vK = 32,
      CO = 300;

    function hO(OO, KO) {
      return OO.slice(0, KO).replace(/[\uD800-\uDBFF]$/, "")
    }
    const DO = 64,
      MO = 512,
      aK = 18e5;
    const oO = "Bloxdhub",
      FO = "https://bloxdhub.com/shaders";

    function VO(OO) {
      return `https://bloxdhub.com/workshop/${encodeURIComponent(OO)}`
    }
    const LO = "Screenshot generation failed.",
      QO = "Its screenshots couldn't be generated:";

    function zK(OO) {
      var KO;
      return OO === LO || null !== (KO = null === OO || void 0 === OO ? void 0 : OO.startsWith(QO)) && void 0 !== KO && KO
    }

    function AO(OO, KO) {
      return `shaderPacks/${OO}/${KO}.json`
    }

    function fO(OO, KO, pO, XO) {
      return null === KO.renderId ? dO(OO, KO.baselineVersion, pO, XO) : `${OO}/${function(OO,KO,pO,XO){return`shaderPacks/${OO}/${KO}/${pO}-${XO}.webp`}(KO.packId,KO.renderId,pO,XO)}`
    }

    function dO(OO, KO, pO, XO) {
      return `${OO}/${function(OO,KO,pO){return`shaderPacks/baseline/${OO}/${KO}-${pO}.webp`}(KO,pO,XO)}`
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);