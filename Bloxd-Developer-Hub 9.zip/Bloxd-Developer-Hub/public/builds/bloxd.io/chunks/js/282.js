export const id = 282;
export const ids = [282];
export const modules = {
  39521: (OO, KO, pO) => {
    pO.d(KO, {
      ensureLocalBloxdTypes: () => QO
    });
    var XO = pO(3906),
      bK = pO(39403),
      eO = pO(39398),
      lO = pO(35348),
      vK = pO(35350),
      CO = pO(35364);
    const hO = JSON.stringify({
      name: "@bloxd",
      types: "index.d.ts"
    }, null, "\t") + "\n";

    function DO(OO) {
      return OO.replace(/^\//, "")
    }

    function MO(OO) {
      return DO((0, vK.t)(OO.name, "")).replace(/\/$/, "")
    }

    function aK(OO) {
      return OO.typesVfsPath.slice(OO.typesVfsPath.lastIndexOf("/") + 1)
    }

    function oO(OO) {
      return JSON.stringify({
        name: OO.specifier,
        types: aK(OO)
      }, null, "\t") + "\n"
    }
    async function FO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
      const pO = [];
      for await (const [XO, bK] of OO.entries()) {
        const OO = KO ? `${KO}/${XO}` : XO;
        "directory" !== bK.kind ? pO.push(OO) : pO.push(...await FO(bK, OO))
      }
      return pO
    }
    async function VO(OO, KO, pO) {
      const XO = MO(KO),
        bK = await (0, CO.m)(OO, XO);
      if (!bK) return;
      const eO = new Set([aK(KO), "package.json"]);
      if (pO)
        for (const CO of Object.keys(KO.files)) eO.add(CO);
      const lO = await FO(bK),
        vK = new Set;
      for (const MO of lO) {
        if (eO.has(MO)) continue;
        await (0, CO.z)(OO, `${XO}/${MO}`);
        const KO = MO.split("/");
        for (let OO = 1; OO < KO.length; OO++) vK.add(KO.slice(0, OO).join("/"))
      }
      const hO = [...vK].sort(((OO, KO) => KO.split("/").length - OO.split("/").length));
      for (const MO of hO) try {
        await (0, CO.z)(OO, `${XO}/${MO}`)
      } catch (DO) {
        if (DO instanceof DOMException && "InvalidModificationError" === DO.name) continue;
        throw DO
      }
    }

    function LO(OO) {
      const KO = {
        "@bloxd": ["./node_modules/@bloxd/index.d.ts"]
      };
      for (const XO of Object.values(lO.e)) KO[XO.specifier] = [`.${XO.typesVfsPath}`];
      const pO = [];
      for (const XO of OO)
        for (const OO of Object.keys(XO.files)) pO.push(DO((0, vK.t)(XO.name, OO)));
      return JSON.stringify({
        compilerOptions: {
          allowJs: !0,
          checkJs: !1,
          strict: !1,
          module: "ESNext",
          moduleResolution: "bundler",
          target: "ES2015",
          noEmit: !0,
          noLib: !0,
          skipLibCheck: !0,
          baseUrl: ".",
          paths: KO
        },
        include: ["./**/*.ts", "./**/*.js", "./**/*.d.ts"],
        files: ["node_modules/@bloxd/globals.d.ts", "node_modules/@bloxd/lib.d.ts", ...pO]
      }, null, "\t") + "\n"
    }
    async function QO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
      const pO = new Set(KO.map((OO => OO.name))),
        aK = Object.values(lO.e).flatMap((KO => {
          const XO = DO(KO.typesVfsPath),
            bK = `${MO(KO)}/package.json`;
          return [...pO.has(KO.name) ? Object.entries(KO.files).map((pO => {
            let [XO, bK] = pO;
            return (0, CO.E)(OO, DO((0, vK.t)(KO.name, XO)), bK)
          })) : [], (0, CO.E)(OO, XO, KO.types), (0, CO.E)(OO, bK, oO(KO))]
        }));
      await Promise.all([(0, CO.E)(OO, "node_modules/@bloxd/index.d.ts", XO.default), (0, CO.E)(OO, "node_modules/@bloxd/globals.d.ts", eO.b), (0, CO.E)(OO, "node_modules/@bloxd/lib.d.ts", bK.e), (0, CO.E)(OO, "node_modules/@bloxd/package.json", hO), (0, CO.E)(OO, "tsconfig.json", LO(KO)), ...aK]), await Promise.all(Object.values(lO.e).map((KO => VO(OO, KO, pO.has(KO.name)))))
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);