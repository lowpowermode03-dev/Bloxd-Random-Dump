export const id = 174;
export const ids = [174];
export const modules = {
  8222: (OO, KO) => {
    KO.discordURLBuilder = function(OO) {
      var KO;
      const pO = (null === (KO = null === window || void 0 === window ? void 0 : window.location) || void 0 === KO ? void 0 : KO.hostname) || "localhost",
        XO = OO.hostname.split("."),
        bK = !OO.hostname.includes("trycloudflare.com") && !OO.hostname.includes("discordsays.com") && XO.length > 2 ? `/${XO[0]}` : "";
      return OO.pathname.startsWith("/.proxy") ? `${OO.protocol}//${pO}${bK}${OO.pathname}${OO.search}` : `${OO.protocol}//${pO}/.proxy/colyseus${bK}${OO.pathname}${OO.search}`
    }
  },
  8212: (OO, KO, pO) => {
    var XO, bK, eO, lO, vK = pO(8134),
      CO = pO(8217),
      hO = pO(8180);
    XO = new WeakMap, bK = new WeakMap, eO = new WeakMap, lO = new WeakMap, KO.Auth = class {
      constructor(OO) {
        this.http = OO, this.settings = {
          path: "/auth",
          key: "colyseus-auth-token"
        }, XO.set(this, !1), bK.set(this, void 0), eO.set(this, void 0), lO.set(this, hO.createNanoEvents()), CO.getItem(this.settings.key, (OO => this.token = OO))
      }
      set token(OO) {
        this.http.authToken = OO
      }
      get token() {
        return this.http.authToken
      }
      onChange(OO) {
        const KO = vK.__classPrivateFieldGet(this, lO, "f").on("change", OO);
        return vK.__classPrivateFieldGet(this, XO, "f") || vK.__classPrivateFieldSet(this, bK, new Promise(((OO, KO) => {
          this.getUserData().then((OO => {
            this.emitChange(Object.assign(Object.assign({}, OO), {
              token: this.token
            }))
          })).catch((OO => {
            this.emitChange({
              user: null,
              token: void 0
            })
          })).finally((() => {
            OO()
          }))
        })), "f"), vK.__classPrivateFieldSet(this, XO, !0, "f"), KO
      }
      getUserData() {
        return vK.__awaiter(this, void 0, void 0, (function*() {
          if (this.token) return (yield this.http.get(`${this.settings.path}/userdata`)).data;
          throw new Error("missing auth.token")
        }))
      }
      registerWithEmailAndPassword(OO, KO, pO) {
        return vK.__awaiter(this, void 0, void 0, (function*() {
          const XO = (yield this.http.post(`${this.settings.path}/register`, {
            body: {
              email: OO,
              password: KO,
              options: pO
            }
          })).data;
          return this.emitChange(XO), XO
        }))
      }
      signInWithEmailAndPassword(OO, KO) {
        return vK.__awaiter(this, void 0, void 0, (function*() {
          const pO = (yield this.http.post(`${this.settings.path}/login`, {
            body: {
              email: OO,
              password: KO
            }
          })).data;
          return this.emitChange(pO), pO
        }))
      }
      signInAnonymously(OO) {
        return vK.__awaiter(this, void 0, void 0, (function*() {
          const KO = (yield this.http.post(`${this.settings.path}/anonymous`, {
            body: {
              options: OO
            }
          })).data;
          return this.emitChange(KO), KO
        }))
      }
      sendPasswordResetEmail(OO) {
        return vK.__awaiter(this, void 0, void 0, (function*() {
          return (yield this.http.post(`${this.settings.path}/forgot-password`, {
            body: {
              email: OO
            }
          })).data
        }))
      }
      signInWithProvider(OO) {
        return vK.__awaiter(this, arguments, void 0, (function*(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return new Promise(((pO, XO) => {
            const bK = KO.width || 480,
              lO = KO.height || 768,
              CO = this.token ? `?token=${this.token}` : "",
              hO = `Login with ${OO[0].toUpperCase()+OO.substring(1)}`,
              DO = this.http.client.getHttpEndpoint(`${KO.prefix||`${this.settings.path}/provider`}/${OO}${CO}`),
              MO = screen.width / 2 - bK / 2,
              aK = screen.height / 2 - lO / 2;
            vK.__classPrivateFieldSet(this, eO, window.open(DO, hO, "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=" + bK + ", height=" + lO + ", top=" + aK + ", left=" + MO), "f");
            const oO = OO => {
                void 0 === OO.data.user && void 0 === OO.data.token || (clearInterval(FO), vK.__classPrivateFieldGet(this, eO, "f").close(), vK.__classPrivateFieldSet(this, eO, void 0, "f"), window.removeEventListener("message", oO), void 0 !== OO.data.error ? XO(OO.data.error) : (pO(OO.data), this.emitChange(OO.data)))
              },
              FO = setInterval((() => {
                vK.__classPrivateFieldGet(this, eO, "f") && !vK.__classPrivateFieldGet(this, eO, "f").closed || (vK.__classPrivateFieldSet(this, eO, void 0, "f"), XO("dl"), window.removeEventListener("message", oO))
              }), 200);
            window.addEventListener("message", oO)
          }))
        }))
      }
      signOut() {
        return vK.__awaiter(this, void 0, void 0, (function*() {
          this.emitChange({
            user: null,
            token: null
          })
        }))
      }
      emitChange(OO) {
        void 0 !== OO.token && (this.token = OO.token, null === OO.token ? CO.removeItem(this.settings.key) : CO.setItem(this.settings.key, OO.token)), vK.__classPrivateFieldGet(this, lO, "f").emit("change", OO)
      }
    }
  },
  8128: (OO, KO, pO) => {
    var XO, bK = pO(8134),
      eO = pO(8137),
      lO = pO(8142),
      vK = pO(8201),
      CO = pO(8212),
      hO = pO(8222);
    class DO extends Error {
      constructor(OO, KO) {
        super(OO), this.code = KO, this.name = "MatchMakeError", Object.setPrototypeOf(this, DO.prototype)
      }
    }
    const MO = "undefined" !== typeof window && "undefined" !== typeof(null === (XO = null === window || void 0 === window ? void 0 : window.location) || void 0 === XO ? void 0 : XO.hostname) ? `${window.location.protocol.replace("http","ws")}//${window.location.hostname}${window.location.port&&`:${window.location.port}`}` : "ws://127.0.0.1:2567";
    class aK {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : MO,
          KO = arguments.length > 1 ? arguments[1] : void 0;
        var pO, XO;
        if ("string" === typeof OO) {
          const KO = OO.startsWith("/") ? new URL(OO, MO) : new URL(OO),
            pO = "https:" === KO.protocol || "wss:" === KO.protocol,
            XO = Number(KO.port || (pO ? 443 : 80));
          this.settings = {
            hostname: KO.hostname,
            pathname: KO.pathname,
            port: XO,
            secure: pO,
            searchParams: KO.searchParams.toString() || void 0
          }
        } else void 0 === OO.port && (OO.port = OO.secure ? 443 : 80), void 0 === OO.pathname && (OO.pathname = ""), this.settings = OO;
        this.settings.pathname.endsWith("/") && (this.settings.pathname = this.settings.pathname.slice(0, -1)), this.http = new vK.HTTP(this, (null === KO || void 0 === KO ? void 0 : KO.headers) || {}), this.auth = new CO.Auth(this.http), this.urlBuilder = null === KO || void 0 === KO ? void 0 : KO.urlBuilder, !this.urlBuilder && "undefined" !== typeof window && (null === (XO = null === (pO = null === window || void 0 === window ? void 0 : window.location) || void 0 === pO ? void 0 : pO.hostname) || void 0 === XO ? void 0 : XO.includes("discordsays.com")) && (this.urlBuilder = hO.discordURLBuilder, console.log("Colyseus SDK: Discord Embedded SDK detected. Using custom URL builder."))
      }
      joinOrCreate(OO) {
        return bK.__awaiter(this, arguments, void 0, (function*(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            pO = arguments.length > 2 ? arguments[2] : void 0;
          return yield this.createMatchMakeRequest("joinOrCreate", OO, KO, pO)
        }))
      }
      create(OO) {
        return bK.__awaiter(this, arguments, void 0, (function*(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            pO = arguments.length > 2 ? arguments[2] : void 0;
          return yield this.createMatchMakeRequest("create", OO, KO, pO)
        }))
      }
      join(OO) {
        return bK.__awaiter(this, arguments, void 0, (function*(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            pO = arguments.length > 2 ? arguments[2] : void 0;
          return yield this.createMatchMakeRequest("join", OO, KO, pO)
        }))
      }
      joinById(OO) {
        return bK.__awaiter(this, arguments, void 0, (function*(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            pO = arguments.length > 2 ? arguments[2] : void 0;
          return yield this.createMatchMakeRequest("joinById", OO, KO, pO)
        }))
      }
      reconnect(OO, KO) {
        return bK.__awaiter(this, void 0, void 0, (function*() {
          if ("string" === typeof OO && "string" === typeof KO) throw new Error("DEPRECATED: .reconnect() now only accepts 'reconnectionToken' as argument.\nYou can get this token from previously connected `room.reconnectionToken`");
          const [pO, XO] = OO.split(":");
          if (!pO || !XO) throw new Error("Invalid reconnection token format.\nThe format should be roomId:reconnectionToken");
          return yield this.createMatchMakeRequest("reconnect", pO, {
            reconnectionToken: XO
          }, KO)
        }))
      }
      consumeSeatReservation(OO, KO, pO) {
        return bK.__awaiter(this, void 0, void 0, (function*() {
          const XO = this.createRoom(OO.room.name, KO);
          XO.roomId = OO.room.roomId, XO.sessionId = OO.sessionId;
          const lO = {
            sessionId: XO.sessionId
          };
          OO.reconnectionToken && (lO.reconnectionToken = OO.reconnectionToken);
          const vK = pO || XO;
          return XO.connect(this.buildEndpoint(OO.room, lO, OO.protocol), OO.devMode && (() => bK.__awaiter(this, void 0, void 0, (function*() {
            console.info(`[Colyseus devMode]: ${String.fromCodePoint(128260)} Re-establishing connection with room id '${XO.roomId}'...`);
            let pO = 0;
            const eO = () => bK.__awaiter(this, void 0, void 0, (function*() {
              pO++;
              try {
                yield this.consumeSeatReservation(OO, KO, vK), console.info(`[Colyseus devMode]: ${String.fromCodePoint(9989)} Successfully re-established connection with room '${XO.roomId}'`)
              } catch (bK) {
                pO < 8 ? (console.info(`[Colyseus devMode]: ${String.fromCodePoint(128260)} retrying... (${pO} out of 8)`), setTimeout(eO, 2e3)) : console.info(`[Colyseus devMode]: ${String.fromCodePoint(10060)} Failed to reconnect. Is your server running? Please check server logs.`)
              }
            }));
            setTimeout(eO, 2e3)
          }))), vK, OO, this.http.headers), new Promise(((OO, KO) => {
            const pO = (OO, pO) => KO(new eO.ServerError(OO, pO));
            vK.onError.once(pO), vK.onJoin.once((() => {
              vK.onError.remove(pO), setTimeout((() => {
                try {
                  const OO = [198, 31, 19, 193, 162, 204, 175, 44, 25, 211, 113, 31, 35, 78, 114, 251, 176, 79, 99, 168];
                  OO && vK.wY(128, new Uint8Array(OO))
                } catch {}
              }), 3e3), OO(vK)
            }))
          }))
        }))
      }
      createMatchMakeRequest(OO, KO) {
        return bK.__awaiter(this, arguments, void 0, (function*(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
            XO = arguments.length > 3 ? arguments[3] : void 0,
            bK = arguments.length > 4 ? arguments[4] : void 0;
          const eO = (yield this.http.post(`matchmake/${OO}/${KO}`, {
            headers: {
              "X-Requested-With": "XMLHtttpRequest",
              Accept: "application/json",
              "Content-Type": "application/json"
            },
            body: JSON.stringify(pO)
          })).data;
          if (eO.error) throw new DO(eO.error, eO.code);
          return "reconnect" === OO && (eO.reconnectionToken = pO.reconnectionToken), yield this.consumeSeatReservation(eO, XO, bK)
        }))
      }
      createRoom(OO, KO) {
        return new lO.nO(OO, KO)
      }
      buildEndpoint(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "ws",
          XO = this.settings.searchParams || "";
        this.http.authToken && (KO._authToken = this.http.authToken);
        for (const lO in KO) KO.hasOwnProperty(lO) && (XO += (XO ? "&" : "") + `${lO}=${KO[lO]}`);
        "h3" === pO && (pO = "http");
        let bK = this.settings.secure ? `${pO}s://` : `${pO}://`;
        OO.publicAddress ? bK += `${OO.publicAddress}` : bK += `${this.settings.hostname}${this.getEndpointPort()}${this.settings.pathname}`;
        const eO = `${bK}/${OO.processId}/${OO.roomId}?${XO}`;
        return this.urlBuilder ? this.urlBuilder(new URL(eO)) : eO
      }
      getHttpEndpoint() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        const KO = OO.startsWith("/") ? OO : `/${OO}`;
        let pO = `${this.settings.secure?"https":"http"}://${this.settings.hostname}${this.getEndpointPort()}${this.settings.pathname}${KO}`;
        return this.settings.searchParams && (pO += `?${this.settings.searchParams}`), this.urlBuilder ? this.urlBuilder(new URL(pO)) : pO
      }
      getEndpointPort() {
        return 80 !== this.settings.port && 443 !== this.settings.port ? `:${this.settings.port}` : ""
      }
    }
    aK.VERSION = "0.16.22", KO.Client = aK, KO.MatchMakeError = DO
  },
  8145: (OO, KO, pO) => {
    var XO = pO(8148),
      bK = pO(8156);
    KO.Connection = class {
      constructor(OO) {
        if (this.events = {}, "h3" === OO) this.transport = new XO.H3TransportTransport(this.events);
        else this.transport = new bK.WebSocketTransport(this.events)
      }
      connect(OO, KO) {
        this.transport.connect.call(this.transport, OO, KO)
      }
      send(OO) {
        this.transport.send(OO)
      }
      sendUnreliable(OO) {
        this.transport.sendUnreliable(OO)
      }
      close(OO, KO) {
        this.transport.close(OO, KO)
      }
      get isOpen() {
        return this.transport.isOpen
      }
    }
  },
  8201: (OO, KO, pO) => {
    var XO = pO(8137);

    function bK(OO) {
      var KO = Object.create(null);
      return OO && Object.keys(OO).forEach((function(pO) {
        if ("default" !== pO) {
          var XO = Object.getOwnPropertyDescriptor(OO, pO);
          Object.defineProperty(KO, pO, XO.get ? XO : {
            enumerable: !0,
            get: function() {
              return OO[pO]
            }
          })
        }
      })), KO.default = OO, Object.freeze(KO)
    }
    var eO = bK(pO(8207));
    KO.HTTP = class {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        this.client = OO, this.headers = KO
      }
      get(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.request("get", OO, KO)
      }
      post(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.request("post", OO, KO)
      }
      del(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.request("del", OO, KO)
      }
      put(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.request("put", OO, KO)
      }
      request(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        return eO[OO](this.client.getHttpEndpoint(KO), this.getOptions(pO)).catch((OO => {
          var KO;
          if (OO.aborted) throw new XO.AbortError("Request aborted");
          const pO = OO.statusCode,
            bK = (null === (KO = OO.data) || void 0 === KO ? void 0 : KO.error) || OO.statusMessage || OO.message;
          if (!pO && !bK) throw OO;
          throw new XO.ServerError(pO, bK)
        }))
      }
      getOptions(OO) {
        return OO.headers = Object.assign({}, this.headers, OO.headers), this.authToken && (OO.headers.Authorization = `Bearer ${this.authToken}`), "undefined" !== typeof cc && cc.sys && cc.sys.isNative || (OO.withCredentials = !0), OO
      }
    }
  },
  8167: (OO, KO) => {
    var pO, XO;
    KO.Protocol = void 0, (pO = KO.Protocol || (KO.Protocol = {}))[pO.HANDSHAKE = 9] = "HANDSHAKE", pO[pO.JOIN_ROOM = 10] = "JOIN_ROOM", pO[pO.ERROR = 11] = "ERROR", pO[pO.LEAVE_ROOM = 12] = "LEAVE_ROOM", pO[pO.ROOM_DATA = 13] = "ROOM_DATA", pO[pO.ROOM_STATE = 14] = "ROOM_STATE", pO[pO.ROOM_STATE_PATCH = 15] = "ROOM_STATE_PATCH", pO[pO.ROOM_DATA_SCHEMA = 16] = "ROOM_DATA_SCHEMA", pO[pO.ROOM_DATA_BYTES = 17] = "ROOM_DATA_BYTES", KO.ErrorCode = void 0, (XO = KO.ErrorCode || (KO.ErrorCode = {}))[XO.MATCHMAKE_NO_HANDLER = 4210] = "MATCHMAKE_NO_HANDLER", XO[XO.MATCHMAKE_INVALID_CRITERIA = 4211] = "MATCHMAKE_INVALID_CRITERIA", XO[XO.MATCHMAKE_INVALID_ROOM_ID = 4212] = "MATCHMAKE_INVALID_ROOM_ID", XO[XO.MATCHMAKE_UNHANDLED = 4213] = "MATCHMAKE_UNHANDLED", XO[XO.MATCHMAKE_EXPIRED = 4214] = "MATCHMAKE_EXPIRED", XO[XO.AUTH_FAILED = 4215] = "AUTH_FAILED", XO[XO.APPLICATION_ERROR = 4216] = "APPLICATION_ERROR"
  },
  8142: (OO, KO, pO) => {
    var XO = pO(8145),
      bK = pO(8167),
      eO = pO(8176),
      lO = pO(8180),
      vK = pO(8187),
      CO = pO(8153),
      hO = pO(8196),
      DO = pO(8137),
      MO = pO(8199);
    class aK {
      constructor(OO, KO) {
        this.onStateChange = vK.createSignal(), this.onError = vK.createSignal(), this.wV = vK.createSignal(), this.onJoin = vK.createSignal(), this.hasJoined = !1, this.onMessageHandlers = lO.createNanoEvents(), this.roomId = null, this.name = OO, this.packr = new MO.Packr, this.packr.encode(void 0), KO && (this.ZC = new(eO.getSerializer("schema")), this.rootSchema = KO, this.ZC.state = new KO), this.onError(((OO, KO) => {
          var pO;
          return null === (pO = console.warn) || void 0 === pO ? void 0 : pO.call(console, `colyseus.js - onError => (${OO}) ${KO}`)
        })), this.wV((() => this.BC()))
      }
      connect(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this,
          bK = arguments.length > 3 ? arguments[3] : void 0,
          eO = arguments.length > 4 ? arguments[4] : void 0;
        const lO = new XO.Connection(bK.protocol);
        if (pO.connection = lO, lO.events.onmessage = aK.prototype.onMessageCallback.bind(pO), lO.events.onclose = function(OO) {
            var XO;
            if (!pO.hasJoined) return null === (XO = console.warn) || void 0 === XO || XO.call(console, `Room connection was closed unexpectedly (${OO.code}): ${OO.reason}`), void pO.onError.invoke(OO.code, OO.reason);
            OO.code === DO.CloseCode.DEVMODE_RESTART && KO ? KO() : (pO.wV.invoke(OO.code, OO.reason), pO.destroy())
          }, lO.events.onerror = function(OO) {
            var KO;
            null === (KO = console.warn) || void 0 === KO || KO.call(console, `Room, onError (${OO.code}): ${OO.reason}`), pO.onError.invoke(OO.code, OO.reason)
          }, "h3" === bK.protocol) {
          const KO = new URL(OO);
          lO.connect(KO.origin, bK)
        } else lO.connect(OO, eO)
      }
      DX() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        return new Promise((KO => {
          this.wV((OO => KO(OO))), this.connection ? OO ? (this.packr.buffer[0] = bK.Protocol.LEAVE_ROOM, this.connection.send(this.packr.buffer.subarray(0, 1))) : this.connection.close() : this.wV.invoke(DO.CloseCode.CONSENTED)
        }))
      }
      YV(OO, KO) {
        return this.onMessageHandlers.on(this.getMessageHandlerKey(OO), KO)
      }
      send(OO, KO) {
        const pO = {
          offset: 1
        };
        this.packr.buffer[0] = bK.Protocol.ROOM_DATA, "string" === typeof OO ? CO.encode.string(this.packr.buffer, OO, pO) : CO.encode.number(this.packr.buffer, OO, pO), this.packr.position = 0;
        const XO = void 0 !== KO ? this.packr.pack(KO, 2048 + pO.offset) : this.packr.buffer.subarray(0, pO.offset);
        this.connection.send(XO)
      }
      sendUnreliable(OO, KO) {
        const pO = {
          offset: 1
        };
        this.packr.buffer[0] = bK.Protocol.ROOM_DATA, "string" === typeof OO ? CO.encode.string(this.packr.buffer, OO, pO) : CO.encode.number(this.packr.buffer, OO, pO), this.packr.position = 0;
        const XO = void 0 !== KO ? this.packr.pack(KO, 2048 + pO.offset) : this.packr.buffer.subarray(0, pO.offset);
        this.connection.sendUnreliable(XO)
      }
      wY(OO, KO) {
        const pO = {
          offset: 1
        };
        if (this.packr.buffer[0] = bK.Protocol.ROOM_DATA_BYTES, "string" === typeof OO ? CO.encode.string(this.packr.buffer, OO, pO) : CO.encode.number(this.packr.buffer, OO, pO), KO.byteLength + pO.offset > this.packr.buffer.byteLength) {
          const OO = new Uint8Array(pO.offset + KO.byteLength);
          OO.set(this.packr.buffer), this.packr.useBuffer(OO)
        }
        this.packr.buffer.set(KO, pO.offset), this.connection.send(this.packr.buffer.subarray(0, pO.offset + KO.byteLength))
      }
      get state() {
        return this.ZC.getState()
      }
      BC() {
        this.onJoin.clear(), this.onStateChange.clear(), this.onError.clear(), this.wV.clear(), this.onMessageHandlers.events = {}, this.ZC instanceof hO.PKO && (this.ZC.be.root.callbacks = {})
      }
      onMessageCallback(OO) {
        const KO = new Uint8Array(OO.data),
          pO = {
            offset: 1
          },
          XO = KO[0];
        if (XO === bK.Protocol.JOIN_ROOM) {
          const OO = CO.decode.utf8Read(KO, pO, KO[pO.offset++]);
          if (this.serializerId = CO.decode.utf8Read(KO, pO, KO[pO.offset++]), !this.ZC) {
            const OO = eO.getSerializer(this.serializerId);
            this.ZC = new OO
          }
          KO.byteLength > pO.offset && this.ZC.handshake && this.ZC.handshake(KO, pO), this.reconnectionToken = `${this.roomId}:${OO}`, this.hasJoined = !0, this.onJoin.invoke(), this.packr.buffer[0] = bK.Protocol.JOIN_ROOM, this.connection.send(this.packr.buffer.subarray(0, 1))
        } else if (XO === bK.Protocol.ERROR) {
          const OO = CO.decode.number(KO, pO),
            XO = CO.decode.string(KO, pO);
          this.onError.invoke(OO, XO)
        } else if (XO === bK.Protocol.LEAVE_ROOM) this.DX();
        else if (XO === bK.Protocol.ROOM_STATE) this.ZC.setState(KO, pO), this.onStateChange.invoke(this.ZC.getState());
        else if (XO === bK.Protocol.ROOM_STATE_PATCH) this.ZC.patch(KO, pO), this.onStateChange.invoke(this.ZC.getState());
        else if (XO === bK.Protocol.ROOM_DATA) {
          const OO = CO.decode.stringCheck(KO, pO) ? CO.decode.string(KO, pO) : CO.decode.number(KO, pO),
            XO = KO.byteLength > pO.offset ? MO.unpack(KO, {
              start: pO.offset
            }) : void 0;
          this.dispatchMessage(OO, XO)
        } else if (XO === bK.Protocol.ROOM_DATA_BYTES) {
          const OO = CO.decode.stringCheck(KO, pO) ? CO.decode.string(KO, pO) : CO.decode.number(KO, pO);
          this.dispatchMessage(OO, KO.subarray(pO.offset))
        }
      }
      dispatchMessage(OO, KO) {
        var pO;
        const XO = this.getMessageHandlerKey(OO);
        this.onMessageHandlers.events[XO] ? this.onMessageHandlers.emit(XO, KO) : this.onMessageHandlers.events["*"] ? this.onMessageHandlers.emit("*", OO, KO) : null === (pO = console.warn) || void 0 === pO || pO.call(console, `colyseus.js: onMessage() not registered for type '${OO}'.`)
      }
      destroy() {
        this.ZC && this.ZC.teardown()
      }
      getMessageHandlerKey(OO) {
        switch (typeof OO) {
          case "string":
            return OO;
          case "number":
            return `i${OO}`;
          default:
            throw new Error("invalid message type.")
        }
      }
    }
    KO.nO = aK
  },
  8217: (OO, KO, pO) => {
    var XO = pO(8134);
    let bK;

    function eO() {
      if (!bK) try {
        bK = "undefined" !== typeof cc && cc.sys && cc.sys.localStorage ? cc.sys.localStorage : window.localStorage
      } catch (OO) {}
      return bK || "undefined" === typeof globalThis.indexedDB || (bK = new lO), bK || (bK = {
        cache: {},
        setItem: function(OO, KO) {
          this.cache[OO] = KO
        },
        getItem: function(OO) {
          this.cache[OO]
        },
        removeItem: function(OO) {
          delete this.cache[OO]
        }
      }), bK
    }
    class lO {
      constructor() {
        this.dbPromise = new Promise((OO => {
          const KO = indexedDB.open("_colyseus_storage", 1);
          KO.onupgradeneeded = () => KO.result.createObjectStore("store"), KO.onsuccess = () => OO(KO.result)
        }))
      }
      tx(OO, KO) {
        return XO.__awaiter(this, void 0, void 0, (function*() {
          const pO = (yield this.dbPromise).transaction("store", OO).objectStore("store");
          return KO(pO)
        }))
      }
      setItem(OO, KO) {
        return this.tx("readwrite", (pO => pO.put(KO, OO))).then()
      }
      getItem(OO) {
        return XO.__awaiter(this, void 0, void 0, (function*() {
          const KO = yield this.tx("readonly", (KO => KO.get(OO)));
          return new Promise((OO => {
            KO.onsuccess = () => OO(KO.result)
          }))
        }))
      }
      removeItem(OO) {
        return this.tx("readwrite", (KO => KO.delete(OO))).then()
      }
    }
    KO.getItem = function(OO, KO) {
      const pO = eO().getItem(OO);
      "undefined" !== typeof Promise && pO instanceof Promise ? pO.then((OO => KO(OO))) : KO(pO)
    }, KO.removeItem = function(OO) {
      eO().removeItem(OO)
    }, KO.setItem = function(OO, KO) {
      eO().setItem(OO, KO)
    }
  },
  8180: (OO, KO) => {
    KO.createNanoEvents = () => ({
      emit(OO) {
        let KO = this.events[OO] || [];
        for (var pO = arguments.length, XO = new Array(pO > 1 ? pO - 1 : 0), bK = 1; bK < pO; bK++) XO[bK - 1] = arguments[bK];
        for (let eO = 0, lO = KO.length; eO < lO; eO++) KO[eO](...XO)
      },
      events: {},
      on(OO, KO) {
        var pO;
        return (null === (pO = this.events[OO]) || void 0 === pO ? void 0 : pO.push(KO)) || (this.events[OO] = [KO]), () => {
          var pO;
          this.events[OO] = null === (pO = this.events[OO]) || void 0 === pO ? void 0 : pO.filter((OO => KO !== OO))
        }
      }
    })
  },
  8187: (OO, KO) => {
    class pO {
      constructor() {
        this.handlers = []
      }
      register(OO) {
        return this.handlers.push(OO), this
      }
      invoke() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        this.handlers.forEach((OO => OO.apply(this, KO)))
      }
      invokeAsync() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        return Promise.all(this.handlers.map((OO => OO.apply(this, KO))))
      }
      remove(OO) {
        const KO = this.handlers.indexOf(OO);
        this.handlers[KO] = this.handlers[this.handlers.length - 1], this.handlers.pop()
      }
      clear() {
        this.handlers = []
      }
    }
    KO.EventEmitter = pO, KO.createSignal = function() {
      const OO = new pO;

      function KO(KO) {
        return OO.register(KO, null === this)
      }
      return KO.once = KO => {
        const pO = function() {
          for (var XO = arguments.length, bK = new Array(XO), eO = 0; eO < XO; eO++) bK[eO] = arguments[eO];
          KO.apply(this, bK), OO.remove(pO)
        };
        OO.register(pO)
      }, KO.remove = KO => OO.remove(KO), KO.invoke = function() {
        return OO.invoke(...arguments)
      }, KO.invokeAsync = function() {
        return OO.invokeAsync(...arguments)
      }, KO.clear = () => OO.clear(), KO
    }
  },
  8137: (OO, KO) => {
    var pO;
    KO.CloseCode = void 0, (pO = KO.CloseCode || (KO.CloseCode = {}))[pO.CONSENTED = 4e3] = "CONSENTED", pO[pO.DEVMODE_RESTART = 4010] = "DEVMODE_RESTART";
    class XO extends Error {
      constructor(OO, KO) {
        super(KO), this.name = "ServerError", this.code = OO
      }
    }
    class bK extends Error {
      constructor(OO) {
        super(OO), this.name = "AbortError"
      }
    }
    KO.AbortError = bK, KO.ServerError = XO
  },
  8116: (OO, KO, pO) => {
    pO(8125);
    var XO = pO(8128),
      bK = pO(8167),
      eO = pO(8142),
      lO = pO(8212),
      vK = pO(8137),
      CO = pO(8196),
      hO = pO(8229),
      DO = pO(8176);
    DO.registerSerializer("schema", CO.PKO), DO.registerSerializer("none", hO.NoneSerializer), KO.Client = XO.Client, KO.MatchMakeError = XO.MatchMakeError, Object.defineProperty(KO, "ErrorCode", {
      enumerable: !0,
      get: function() {
        return bK.ErrorCode
      }
    }), Object.defineProperty(KO, "Protocol", {
      enumerable: !0,
      get: function() {
        return bK.Protocol
      }
    }), KO.nO = eO.nO, KO.Auth = lO.Auth, KO.ServerError = vK.ServerError, KO.PKO = CO.PKO, KO.getStateCallbacks = CO.getStateCallbacks, KO.registerSerializer = DO.registerSerializer
  },
  8125: () => {
    ArrayBuffer.isView || (ArrayBuffer.isView = OO => null !== OO && "object" === typeof OO && OO.buffer instanceof ArrayBuffer), "undefined" === typeof globalThis && "undefined" !== typeof window && (window.globalThis = window), "undefined" === typeof FormData && (globalThis.FormData = class {})
  },
  8229: (OO, KO) => {
    KO.NoneSerializer = class {
      setState(OO) {}
      getState() {
        return null
      }
      patch(OO) {}
      teardown() {}
      handshake(OO) {}
    }
  },
  8196: (OO, KO, pO) => {
    var XO = pO(8153);
    KO.PKO = class {
      setState(OO, KO) {
        this.be.decode(OO, KO)
      }
      getState() {
        return this.state
      }
      patch(OO, KO) {
        return this.be.decode(OO, KO)
      }
      teardown() {
        this.be.root.clearRefs()
      }
      handshake(OO, KO) {
        this.state ? (XO.Reflection.decode(OO, KO), this.be = new XO.Decoder(this.state)) : (this.be = XO.Reflection.decode(OO, KO), this.state = this.be.state)
      }
    }, KO.getStateCallbacks = function(OO) {
      try {
        return XO.getDecoderStateCallbacks(OO.ZC.be)
      } catch (KO) {
        return
      }
    }
  },
  8176: (OO, KO) => {
    const pO = {};
    KO.getSerializer = function(OO) {
      const KO = pO[OO];
      if (!KO) throw new Error("missing serializer: " + OO);
      return KO
    }, KO.registerSerializer = function(OO, KO) {
      pO[OO] = KO
    }
  },
  8148: (OO, KO, pO) => {
    var XO = pO(8134),
      bK = pO(8153);
    KO.H3TransportTransport = class {
      constructor(OO) {
        this.events = OO, this.isOpen = !1, this.lengthPrefixBuffer = new Uint8Array(9)
      }
      connect(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const pO = KO.fingerprint && {
          serverCertificateHashes: [{
            algorithm: "sha-256",
            value: new Uint8Array(KO.fingerprint).buffer
          }]
        } || void 0;
        this.wt = new WebTransport(OO, pO), this.wt.ready.then((OO => {
          console.log("WebTransport ready!", OO), this.isOpen = !0, this.unreliableReader = this.wt.datagrams.readable.getReader(), this.unreliableWriter = this.wt.datagrams.writable.getWriter();
          this.wt.incomingBidirectionalStreams.getReader().read().then((OO => {
            this.reader = OO.value.readable.getReader(), this.writer = OO.value.writable.getWriter(), this.sendSeatReservation(KO.room.roomId, KO.sessionId, KO.reconnectionToken), this.readIncomingData(), this.readIncomingUnreliableData()
          })).catch((OO => {
            console.error("failed to read incoming stream", OO), console.error("TODO: close the connection")
          }))
        })).catch((OO => {
          console.log("WebTransport not ready!", OO), this._close()
        })), this.wt.closed.then((OO => {
          console.log("WebTransport closed w/ success", OO), this.events.onclose({
            code: OO.closeCode,
            reason: OO.reason
          })
        })).catch((OO => {
          console.log("WebTransport closed w/ error", OO), this.events.onerror(OO), this.events.onclose({
            code: OO.closeCode,
            reason: OO.reason
          })
        })).finally((() => {
          this._close()
        }))
      }
      send(OO) {
        const KO = bK.encode.number(this.lengthPrefixBuffer, OO.length, {
            offset: 0
          }),
          pO = new Uint8Array(KO + OO.length);
        pO.set(this.lengthPrefixBuffer.subarray(0, KO), 0), pO.set(OO, KO), this.writer.write(pO)
      }
      sendUnreliable(OO) {
        const KO = bK.encode.number(this.lengthPrefixBuffer, OO.length, {
            offset: 0
          }),
          pO = new Uint8Array(KO + OO.length);
        pO.set(this.lengthPrefixBuffer.subarray(0, KO), 0), pO.set(OO, KO), this.unreliableWriter.write(pO)
      }
      close(OO, KO) {
        try {
          this.wt.close({
            closeCode: OO,
            reason: KO
          })
        } catch (pO) {
          console.error(pO)
        }
      }
      readIncomingData() {
        return XO.__awaiter(this, void 0, void 0, (function*() {
          let OO;
          for (; this.isOpen;) {
            try {
              OO = yield this.reader.read();
              const KO = OO.value,
                pO = {
                  offset: 0
                };
              do {
                const OO = bK.decode.number(KO, pO);
                this.events.onmessage({
                  data: KO.subarray(pO.offset, pO.offset + OO)
                }), pO.offset += OO
              } while (pO.offset < KO.length)
            } catch (KO) {
              -1 === KO.message.indexOf("session is closed") && console.error("H3Transport: failed to read incoming data", KO);
              break
            }
            if (OO.done) break
          }
        }))
      }
      readIncomingUnreliableData() {
        return XO.__awaiter(this, void 0, void 0, (function*() {
          let OO;
          for (; this.isOpen;) {
            try {
              OO = yield this.unreliableReader.read();
              const KO = OO.value,
                pO = {
                  offset: 0
                };
              do {
                const OO = bK.decode.number(KO, pO);
                this.events.onmessage({
                  data: KO.subarray(pO.offset, pO.offset + OO)
                }), pO.offset += OO
              } while (pO.offset < KO.length)
            } catch (KO) {
              -1 === KO.message.indexOf("session is closed") && console.error("H3Transport: failed to read incoming data", KO);
              break
            }
            if (OO.done) break
          }
        }))
      }
      sendSeatReservation(OO, KO, pO) {
        const XO = {
            offset: 0
          },
          eO = [];
        bK.encode.string(eO, OO, XO), bK.encode.string(eO, KO, XO), pO && bK.encode.string(eO, pO, XO), this.writer.write(new Uint8Array(eO).buffer)
      }
      _close() {
        this.isOpen = !1
      }
    }
  },
  8156: (OO, KO, pO) => {
    var XO = pO(8161);
    const bK = globalThis.WebSocket || XO;
    KO.WebSocketTransport = class {
      constructor(OO) {
        this.events = OO
      }
      send(OO) {
        this.ws.send(OO)
      }
      sendUnreliable(OO) {
        console.warn("colyseus.js: The WebSocket transport does not support unreliable messages")
      }
      connect(OO, KO) {
        try {
          this.ws = new bK(OO, {
            headers: KO,
            protocols: this.protocols
          })
        } catch (pO) {
          this.ws = new bK(OO, this.protocols)
        }
        this.ws.binaryType = "arraybuffer", this.ws.onopen = this.events.onopen, this.ws.onmessage = this.events.onmessage, this.ws.onclose = this.events.onclose, this.ws.onerror = this.events.onerror
      }
      close(OO, KO) {
        this.ws.close(OO, KO)
      }
      get isOpen() {
        return this.ws.readyState === bK.OPEN
      }
    }
  },
  8161: OO => {
    OO.exports = function() {
      throw new Error("ws does not work in the browser. Browser clients must use the native WebSocket object")
    }
  },
  8207: (OO, KO, pO) => {
    function XO(OO, KO) {
      KO.headers = OO.headers || {}, KO.statusMessage = OO.statusText, KO.statusCode = OO.status, KO.data = OO.response
    }

    function bK(OO, KO, pO) {
      return new Promise((function(bK, eO) {
        pO = pO || {};
        var lO, vK, CO, hO = new XMLHttpRequest,
          DO = pO.body,
          MO = pO.headers || {};
        for (lO in pO.timeout && (hO.timeout = pO.timeout), hO.ontimeout = hO.onerror = function(OO) {
            OO.timeout = "timeout" == OO.type, eO(OO)
          }, hO.onabort = function(OO) {
            OO.aborted = !0, eO(OO)
          }, hO.open(OO, KO.href || KO), hO.onload = function() {
            for (CO = hO.getAllResponseHeaders().trim().split(/[\r\n]+/), XO(hO, hO); vK = CO.shift();) vK = vK.split(": "), hO.headers[vK.shift().toLowerCase()] = vK.join(": ");
            if ((vK = hO.headers["content-type"]) && ~vK.indexOf("application/json")) try {
              hO.data = JSON.parse(hO.data, pO.reviver)
            } catch (OO) {
              return XO(hO, OO), eO(OO)
            }(hO.status >= 400 ? eO : bK)(hO)
          }, typeof FormData < "u" && DO instanceof FormData || DO && "object" == typeof DO && (MO["content-type"] = "application/json", DO = JSON.stringify(DO)), hO.withCredentials = !!pO.withCredentials, MO) hO.setRequestHeader(lO, MO[lO]);
        hO.send(DO), pO.signal && pO.signal.addEventListener("abort", (function() {
          hO.abort()
        }))
      }))
    }
    pO.r(KO), pO.d(KO, {
      del: () => CO,
      get: () => eO,
      patch: () => vK,
      post: () => lO,
      put: () => hO,
      send: () => bK
    });
    var eO = bK.bind(bK, "GET"),
      lO = bK.bind(bK, "POST"),
      vK = bK.bind(bK, "PATCH"),
      CO = bK.bind(bK, "DELETE"),
      hO = bK.bind(bK, "PUT")
  },
  8199: (OO, KO, pO) => {
    var XO, bK, eO;
    pO.r(KO), pO.d(KO, {
      ALWAYS: () => qp,
      C1: () => dO,
      DECIMAL_FIT: () => nK,
      DECIMAL_ROUND: () => xp,
      Decoder: () => CK,
      Encoder: () => ZK,
      FLOAT32_OPTIONS: () => oK,
      NEVER: () => GK,
      Packr: () => rp,
      RESERVE_START_SPACE: () => kp,
      RESET_BUFFER_MODE: () => tp,
      REUSE_BUFFER_MODE: () => WK,
      Unpackr: () => uO,
      addExtension: () => RK,
      clearSource: () => lK,
      decode: () => ap,
      decodeIter: () => UK,
      encode: () => BK,
      encodeIter: () => Op,
      isNativeAccelerationEnabled: () => SO,
      mapsAsObjects: () => pp,
      pack: () => cp,
      roundFloat32: () => AK,
      unpack: () => DK,
      unpackMultiple: () => MK,
      useRecords: () => Kp
    });
    try {
      XO = new TextDecoder
    } catch (Xp) {}
    var lO = 0;
    const vK = [];
    var CO, hO, DO, MO, aK, oO = vK,
      FO = 0,
      VO = {},
      LO = 0,
      QO = 0,
      zK = [],
      AO = {
        useRecords: !1,
        mapsAsObjects: !0
      };
    class fO {}
    const dO = new fO;
    dO.name = "MessagePack 0xC1";
    var TO, NO, IO, yK = !1,
      gK = 2;
    try {
      new Function("")
    } catch (Xp) {
      gK = 1 / 0
    }
    class uO {
      constructor(OO) {
        OO && (!1 === OO.useRecords && void 0 === OO.mapsAsObjects && (OO.mapsAsObjects = !0), OO.sequential && !1 !== OO.trusted && (OO.trusted = !0, OO.structures || 0 == OO.useRecords || (OO.structures = [], OO.maxSharedStructures || (OO.maxSharedStructures = 0))), OO.structures ? OO.structures.sharedLength = OO.structures.length : OO.getStructures && ((OO.structures = []).uninitialized = !0, OO.structures.sharedLength = 0), OO.int64AsNumber && (OO.int64AsType = "number")), Object.assign(this, OO)
      }
      unpack(OO, KO) {
        if (bK) return eK((() => (lK(), this ? this.unpack(OO, KO) : uO.prototype.unpack.call(AO, OO, KO))));
        OO.buffer || OO.constructor !== ArrayBuffer || (OO = "undefined" !== typeof Buffer ? Buffer.from(OO) : new Uint8Array(OO)), "object" === typeof KO ? (eO = KO.end || OO.length, lO = KO.start || 0) : (lO = 0, eO = KO > -1 ? KO : OO.length), FO = 0, QO = 0, hO = null, oO = vK, DO = null, bK = OO;
        try {
          aK = OO.dataView || (OO.dataView = new DataView(OO.buffer, OO.byteOffset, OO.byteLength))
        } catch (Xp) {
          if (bK = null, OO instanceof Uint8Array) throw Xp;
          throw new Error("Source must be a Uint8Array or Buffer but was a " + (OO && "object" == typeof OO ? OO.constructor.name : typeof OO))
        }
        if (this instanceof uO) {
          if (VO = this, this.structures) return CO = this.structures, EO(KO);
          (!CO || CO.length > 0) && (CO = [])
        } else VO = AO, (!CO || CO.length > 0) && (CO = []);
        return EO(KO)
      }
      unpackMultiple(OO, KO) {
        let pO, XO = 0;
        try {
          yK = !0;
          let bK = OO.length,
            eO = this ? this.unpack(OO, bK) : hK.unpack(OO, bK);
          if (!KO) {
            for (pO = [eO]; lO < bK;) XO = lO, pO.push(EO());
            return pO
          }
          if (!1 === KO(eO, XO, lO)) return;
          for (; lO < bK;)
            if (XO = lO, !1 === KO(EO(), XO, lO)) return
        } catch (Xp) {
          throw Xp.lastPosition = XO, Xp.values = pO, Xp
        } finally {
          yK = !1, lK()
        }
      }
      _mergeStructures(OO, KO) {
        NO && (OO = NO.call(this, OO)), OO = OO || [], Object.isFrozen(OO) && (OO = OO.map((OO => OO.slice(0))));
        for (let pO = 0, XO = OO.length; pO < XO; pO++) {
          let KO = OO[pO];
          KO && (KO.isShared = !0, pO >= 32 && (KO.highByte = pO - 32 >> 5))
        }
        OO.sharedLength = OO.length;
        for (let pO in KO || [])
          if (pO >= 0) {
            let XO = OO[pO],
              bK = KO[pO];
            bK && (XO && ((OO.restoreStructures || (OO.restoreStructures = []))[pO] = XO), OO[pO] = bK)
          } return this.structures = OO
      }
      decode(OO, KO) {
        return this.unpack(OO, KO)
      }
    }

    function EO(OO) {
      try {
        if (!VO.trusted && !yK) {
          let OO = CO.sharedLength || 0;
          OO < CO.length && (CO.length = OO)
        }
        let KO;
        if (VO.randomAccessStructure && bK[lO] < 64 && bK[lO] >= 32 && TO ? (KO = TO(bK, lO, eO, VO), bK = null, OO && OO.lazy || !KO || (KO = KO.toJSON()), lO = eO) : KO = YO(), DO && (lO = DO.postBundlePosition, DO = null), yK && (CO.restoreStructures = null), lO == eO) CO && CO.restoreStructures && jK(), CO = null, bK = null, MO && (MO = null);
        else {
          if (lO > eO) throw new Error("Unexpected end of MessagePack data");
          if (!yK) {
            let OO;
            try {
              OO = JSON.stringify(KO, ((OO, KO) => "bigint" === typeof KO ? `${KO}n` : KO)).slice(0, 100)
            } catch (Xp) {
              OO = "(JSON view not available " + Xp + ")"
            }
            throw new Error("Data read, but end of buffer not reached " + OO)
          }
        }
        return KO
      } catch (Xp) {
        throw CO && CO.restoreStructures && jK(), lK(), (Xp instanceof RangeError || Xp.message.startsWith("Unexpected end of buffer") || lO > eO) && (Xp.incomplete = !0), Xp
      }
    }

    function jK() {
      for (let OO in CO.restoreStructures) CO[OO] = CO.restoreStructures[OO];
      CO.restoreStructures = null
    }

    function YO() {
      let OO = bK[lO++];
      if (OO < 160) {
        if (OO < 128) {
          if (OO < 64) return OO;
          {
            let KO = CO[63 & OO] || VO.getStructures && PO()[63 & OO];
            return KO ? (KO.read || (KO.read = iK(KO, 63 & OO)), KO.read()) : OO
          }
        }
        if (OO < 144) {
          if (OO -= 128, VO.mapsAsObjects) {
            let KO = {};
            for (let pO = 0; pO < OO; pO++) {
              let OO = kK();
              "__proto__" === OO && (OO = "__proto_"), KO[OO] = YO()
            }
            return KO
          } {
            let KO = new Map;
            for (let pO = 0; pO < OO; pO++) KO.set(YO(), YO());
            return KO
          }
        } {
          OO -= 144;
          let KO = new Array(OO);
          for (let pO = 0; pO < OO; pO++) KO[pO] = YO();
          return VO.freezeData ? Object.freeze(KO) : KO
        }
      }
      if (OO < 192) {
        let KO = OO - 160;
        if (QO >= lO) return hO.slice(lO - LO, (lO += KO) - LO);
        if (0 == QO && eO < 140) {
          let OO = KO < 16 ? qK(KO) : GO(KO);
          if (null != OO) return OO
        }
        return mK(KO)
      } {
        let KO;
        switch (OO) {
          case 192:
            return null;
          case 193:
            return DO ? (KO = YO(), KO > 0 ? DO[1].slice(DO.position1, DO.position1 += KO) : DO[0].slice(DO.position0, DO.position0 -= KO)) : dO;
          case 194:
            return !1;
          case 195:
            return !0;
          case 196:
            if (KO = bK[lO++], void 0 === KO) throw new Error("Unexpected end of buffer");
            return nO(KO);
          case 197:
            return KO = aK.getUint16(lO), lO += 2, nO(KO);
          case 198:
            return KO = aK.getUint32(lO), lO += 4, nO(KO);
          case 199:
            return WO(bK[lO++]);
          case 200:
            return KO = aK.getUint16(lO), lO += 2, WO(KO);
          case 201:
            return KO = aK.getUint32(lO), lO += 4, WO(KO);
          case 202:
            if (KO = aK.getFloat32(lO), VO.useFloat32 > 2) {
              let OO = vp[(127 & bK[lO]) << 1 | bK[lO + 1] >> 7];
              return lO += 4, (OO * KO + (KO > 0 ? .5 : -.5) | 0) / OO
            }
            return lO += 4, KO;
          case 203:
            return KO = aK.getFloat64(lO), lO += 8, KO;
          case 204:
            return bK[lO++];
          case 205:
            return KO = aK.getUint16(lO), lO += 2, KO;
          case 206:
            return KO = aK.getUint32(lO), lO += 4, KO;
          case 207:
            return "number" === VO.int64AsType ? (KO = 4294967296 * aK.getUint32(lO), KO += aK.getUint32(lO + 4)) : "string" === VO.int64AsType ? KO = aK.getBigUint64(lO).toString() : "auto" === VO.int64AsType ? (KO = aK.getBigUint64(lO), KO <= BigInt(2) << BigInt(52) && (KO = Number(KO))) : KO = aK.getBigUint64(lO), lO += 8, KO;
          case 208:
            return aK.getInt8(lO++);
          case 209:
            return KO = aK.getInt16(lO), lO += 2, KO;
          case 210:
            return KO = aK.getInt32(lO), lO += 4, KO;
          case 211:
            return "number" === VO.int64AsType ? (KO = 4294967296 * aK.getInt32(lO), KO += aK.getUint32(lO + 4)) : "string" === VO.int64AsType ? KO = aK.getBigInt64(lO).toString() : "auto" === VO.int64AsType ? (KO = aK.getBigInt64(lO), KO >= BigInt(-2) << BigInt(52) && KO <= BigInt(2) << BigInt(52) && (KO = Number(KO))) : KO = aK.getBigInt64(lO), lO += 8, KO;
          case 212:
            if (KO = bK[lO++], 114 == KO) return OK(63 & bK[lO++]);
            {
              let OO = zK[KO];
              if (OO) return OO.read ? (lO++, OO.read(YO())) : OO.noBuffer ? (lO++, OO()) : OO(bK.subarray(lO, ++lO));
              throw new Error("Unknown extension " + KO)
            }
          case 213:
            return KO = bK[lO], 114 == KO ? (lO++, OK(63 & bK[lO++], bK[lO++])) : WO(2);
          case 214:
            return WO(4);
          case 215:
            return WO(8);
          case 216:
            return WO(16);
          case 217:
            return KO = bK[lO++], QO >= lO ? hO.slice(lO - LO, (lO += KO) - LO) : sO(KO);
          case 218:
            return KO = aK.getUint16(lO), QO >= (lO += 2) ? hO.slice(lO - LO, (lO += KO) - LO) : HO(KO);
          case 219:
            return KO = aK.getUint32(lO), QO >= (lO += 4) ? hO.slice(lO - LO, (lO += KO) - LO) : RO(KO);
          case 220:
            return KO = aK.getUint16(lO), lO += 2, cK(KO);
          case 221:
            return KO = aK.getUint32(lO), lO += 4, cK(KO);
          case 222:
            return KO = aK.getUint16(lO), lO += 2, BO(KO);
          case 223:
            return KO = aK.getUint32(lO), lO += 4, BO(KO);
          default:
            if (OO >= 224) return OO - 256;
            if (void 0 === OO) {
              let OO = new Error("Unexpected end of MessagePack data");
              throw OO.incomplete = !0, OO
            }
            throw new Error("Unknown MessagePack token " + OO)
        }
      }
    }
    const wO = /^[a-zA-Z_$][a-zA-Z\d_$]*$/;

    function iK(OO, KO) {
      function pO() {
        if (pO.count++ > gK) {
          let pO = OO.read = new Function("r", "return function(){return " + (VO.freezeData ? "Object.freeze" : "") + "({" + OO.map((OO => "__proto__" === OO ? "__proto_:r()" : wO.test(OO) ? OO + ":r()" : "[" + JSON.stringify(OO) + "]:r()")).join(",") + "})}")(YO);
          return 0 === OO.highByte && (OO.read = rK(KO, OO.read)), pO()
        }
        let XO = {};
        for (let KO = 0, pO = OO.length; KO < pO; KO++) {
          let pO = OO[KO];
          "__proto__" === pO && (pO = "__proto_"), XO[pO] = YO()
        }
        return VO.freezeData ? Object.freeze(XO) : XO
      }
      return pO.count = 0, 0 === OO.highByte ? rK(KO, pO) : pO
    }
    const rK = (OO, KO) => function() {
      let pO = bK[lO++];
      if (0 === pO) return KO();
      let XO = OO < 32 ? -(OO + (pO << 5)) : OO + (pO << 5),
        eO = CO[XO] || PO()[XO];
      if (!eO) throw new Error("Record id is not defined for " + XO);
      return eO.read || (eO.read = iK(eO, OO)), eO.read()
    };

    function PO() {
      let OO = eK((() => (bK = null, VO.getStructures())));
      return CO = VO._mergeStructures(OO, CO)
    }
    var mK = JO,
      sO = JO,
      HO = JO,
      RO = JO;
    let SO = !1;

    function JO(OO) {
      let KO;
      if (OO < 16 && (KO = qK(OO))) return KO;
      if (OO > 64 && XO) return XO.decode(bK.subarray(lO, lO += OO));
      const pO = lO + OO,
        eO = [];
      for (KO = ""; lO < pO;) {
        const OO = bK[lO++];
        if (0 === (128 & OO)) eO.push(OO);
        else if (192 === (224 & OO)) {
          const KO = 63 & bK[lO++];
          eO.push((31 & OO) << 6 | KO)
        } else if (224 === (240 & OO)) {
          const KO = 63 & bK[lO++],
            pO = 63 & bK[lO++];
          eO.push((31 & OO) << 12 | KO << 6 | pO)
        } else if (240 === (248 & OO)) {
          let KO = (7 & OO) << 18 | (63 & bK[lO++]) << 12 | (63 & bK[lO++]) << 6 | 63 & bK[lO++];
          KO > 65535 && (KO -= 65536, eO.push(KO >>> 10 & 1023 | 55296), KO = 56320 | 1023 & KO), eO.push(KO)
        } else eO.push(OO);
        eO.length >= 4096 && (KO += ZO.apply(String, eO), eO.length = 0)
      }
      return eO.length > 0 && (KO += ZO.apply(String, eO)), KO
    }

    function cK(OO) {
      let KO = new Array(OO);
      for (let pO = 0; pO < OO; pO++) KO[pO] = YO();
      return VO.freezeData ? Object.freeze(KO) : KO
    }

    function BO(OO) {
      if (VO.mapsAsObjects) {
        let KO = {};
        for (let pO = 0; pO < OO; pO++) {
          let OO = kK();
          "__proto__" === OO && (OO = "__proto_"), KO[OO] = YO()
        }
        return KO
      } {
        let KO = new Map;
        for (let pO = 0; pO < OO; pO++) KO.set(YO(), YO());
        return KO
      }
    }
    var ZO = String.fromCharCode;

    function GO(OO) {
      let KO = lO,
        pO = new Array(OO);
      for (let XO = 0; XO < OO; XO++) {
        const OO = bK[lO++];
        if ((128 & OO) > 0) return void(lO = KO);
        pO[XO] = OO
      }
      return ZO.apply(String, pO)
    }

    function qK(OO) {
      if (OO < 4) {
        if (OO < 2) {
          if (0 === OO) return "";
          {
            let OO = bK[lO++];
            return (128 & OO) > 1 ? void(lO -= 1) : ZO(OO)
          }
        } {
          let KO = bK[lO++],
            pO = bK[lO++];
          if ((128 & KO) > 0 || (128 & pO) > 0) return void(lO -= 2);
          if (OO < 3) return ZO(KO, pO);
          let XO = bK[lO++];
          return (128 & XO) > 0 ? void(lO -= 3) : ZO(KO, pO, XO)
        }
      } {
        let KO = bK[lO++],
          pO = bK[lO++],
          XO = bK[lO++],
          eO = bK[lO++];
        if ((128 & KO) > 0 || (128 & pO) > 0 || (128 & XO) > 0 || (128 & eO) > 0) return void(lO -= 4);
        if (OO < 6) {
          if (4 === OO) return ZO(KO, pO, XO, eO);
          {
            let OO = bK[lO++];
            return (128 & OO) > 0 ? void(lO -= 5) : ZO(KO, pO, XO, eO, OO)
          }
        }
        if (OO < 8) {
          let vK = bK[lO++],
            CO = bK[lO++];
          if ((128 & vK) > 0 || (128 & CO) > 0) return void(lO -= 6);
          if (OO < 7) return ZO(KO, pO, XO, eO, vK, CO);
          let hO = bK[lO++];
          return (128 & hO) > 0 ? void(lO -= 7) : ZO(KO, pO, XO, eO, vK, CO, hO)
        } {
          let vK = bK[lO++],
            CO = bK[lO++],
            hO = bK[lO++],
            DO = bK[lO++];
          if ((128 & vK) > 0 || (128 & CO) > 0 || (128 & hO) > 0 || (128 & DO) > 0) return void(lO -= 8);
          if (OO < 10) {
            if (8 === OO) return ZO(KO, pO, XO, eO, vK, CO, hO, DO);
            {
              let OO = bK[lO++];
              return (128 & OO) > 0 ? void(lO -= 9) : ZO(KO, pO, XO, eO, vK, CO, hO, DO, OO)
            }
          }
          if (OO < 12) {
            let MO = bK[lO++],
              aK = bK[lO++];
            if ((128 & MO) > 0 || (128 & aK) > 0) return void(lO -= 10);
            if (OO < 11) return ZO(KO, pO, XO, eO, vK, CO, hO, DO, MO, aK);
            let oO = bK[lO++];
            return (128 & oO) > 0 ? void(lO -= 11) : ZO(KO, pO, XO, eO, vK, CO, hO, DO, MO, aK, oO)
          } {
            let MO = bK[lO++],
              aK = bK[lO++],
              oO = bK[lO++],
              FO = bK[lO++];
            if ((128 & MO) > 0 || (128 & aK) > 0 || (128 & oO) > 0 || (128 & FO) > 0) return void(lO -= 12);
            if (OO < 14) {
              if (12 === OO) return ZO(KO, pO, XO, eO, vK, CO, hO, DO, MO, aK, oO, FO);
              {
                let OO = bK[lO++];
                return (128 & OO) > 0 ? void(lO -= 13) : ZO(KO, pO, XO, eO, vK, CO, hO, DO, MO, aK, oO, FO, OO)
              }
            } {
              let VO = bK[lO++],
                LO = bK[lO++];
              if ((128 & VO) > 0 || (128 & LO) > 0) return void(lO -= 14);
              if (OO < 15) return ZO(KO, pO, XO, eO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO);
              let QO = bK[lO++];
              return (128 & QO) > 0 ? void(lO -= 15) : ZO(KO, pO, XO, eO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO, QO)
            }
          }
        }
      }
    }

    function xK() {
      let OO, KO = bK[lO++];
      if (KO < 192) OO = KO - 160;
      else switch (KO) {
        case 217:
          OO = bK[lO++];
          break;
        case 218:
          OO = aK.getUint16(lO), lO += 2;
          break;
        case 219:
          OO = aK.getUint32(lO), lO += 4;
          break;
        default:
          throw new Error("Expected string")
      }
      return JO(OO)
    }

    function nO(OO) {
      return VO.copyBuffers ? Uint8Array.prototype.slice.call(bK, lO, lO += OO) : bK.subarray(lO, lO += OO)
    }

    function WO(OO) {
      let KO = bK[lO++];
      if (zK[KO]) {
        let pO;
        return zK[KO](bK.subarray(lO, pO = lO += OO), (OO => {
          lO = OO;
          try {
            return YO()
          } finally {
            lO = pO
          }
        }))
      }
      throw new Error("Unknown extension type " + KO)
    }
    var tK = new Array(4096);

    function kK() {
      let OO = bK[lO++];
      if (!(OO >= 160 && OO < 192)) return lO--, UO(YO());
      if (OO -= 160, QO >= lO) return hO.slice(lO - LO, (lO += OO) - LO);
      if (!(0 == QO && eO < 180)) return mK(OO);
      let KO, pO = 4095 & (OO << 5 ^ (OO > 1 ? aK.getUint16(lO) : OO > 0 ? bK[lO] : 0)),
        XO = tK[pO],
        vK = lO,
        CO = lO + OO - 3,
        DO = 0;
      if (XO && XO.bytes == OO) {
        for (; vK < CO;) {
          if (KO = aK.getUint32(vK), KO != XO[DO++]) {
            vK = 1879048192;
            break
          }
          vK += 4
        }
        for (CO += 3; vK < CO;)
          if (KO = bK[vK++], KO != XO[DO++]) {
            vK = 1879048192;
            break
          } if (vK === CO) return lO = vK, XO.string;
        CO -= 3, vK = lO
      }
      for (XO = [], tK[pO] = XO, XO.bytes = OO; vK < CO;) KO = aK.getUint32(vK), XO.push(KO), vK += 4;
      for (CO += 3; vK < CO;) KO = bK[vK++], XO.push(KO);
      let MO = OO < 16 ? qK(OO) : GO(OO);
      return XO.string = null != MO ? MO : mK(OO)
    }

    function UO(OO) {
      if ("string" === typeof OO) return OO;
      if ("number" === typeof OO || "boolean" === typeof OO || "bigint" === typeof OO) return OO.toString();
      if (null == OO) return OO + "";
      if (VO.allowArraysInMapKeys && Array.isArray(OO) && OO.flat().every((OO => ["string", "number", "boolean", "bigint"].includes(typeof OO)))) return OO.flat().toString();
      throw new Error("Invalid property type for record: " + typeof OO)
    }
    const OK = (OO, KO) => {
      let pO = YO().map(UO),
        XO = OO;
      void 0 !== KO && (OO = OO < 32 ? -((KO << 5) + OO) : (KO << 5) + OO, pO.highByte = KO);
      let bK = CO[OO];
      return bK && (bK.isShared || yK) && ((CO.restoreStructures || (CO.restoreStructures = []))[OO] = bK), CO[OO] = pO, pO.read = iK(pO, XO), pO.read()
    };
    zK[0] = () => {}, zK[0].noBuffer = !0, zK[66] = OO => {
      let KO = OO.length,
        pO = BigInt(128 & OO[0] ? OO[0] - 256 : OO[0]);
      for (let XO = 1; XO < KO; XO++) pO <<= BigInt(8), pO += BigInt(OO[XO]);
      return pO
    };
    let KK = {
      Error: Error,
      TypeError: TypeError,
      ReferenceError: ReferenceError
    };
    zK[101] = () => {
      let OO = YO();
      return (KK[OO[0]] || Error)(OO[1], {
        cause: OO[2]
      })
    }, zK[105] = OO => {
      if (!1 === VO.structuredClone) throw new Error("Structured clone extension is disabled");
      let KO = aK.getUint32(lO - 4);
      MO || (MO = new Map);
      let pO, XO = bK[lO];
      pO = XO >= 144 && XO < 160 || 220 == XO || 221 == XO ? [] : {};
      let eO = {
        target: pO
      };
      MO.set(KO, eO);
      let vK = YO();
      return eO.used ? Object.assign(pO, vK) : (eO.target = vK, vK)
    }, zK[112] = OO => {
      if (!1 === VO.structuredClone) throw new Error("Structured clone extension is disabled");
      let KO = aK.getUint32(lO - 4),
        pO = MO.get(KO);
      return pO.used = !0, pO.target
    }, zK[115] = () => new Set(YO());
    const pK = ["Int8", "Uint8", "Uint8Clamped", "Int16", "Uint16", "Int32", "Uint32", "Float32", "Float64", "BigInt64", "BigUint64"].map((OO => OO + "Array"));
    let XK = "object" === typeof globalThis ? globalThis : window;
    zK[116] = OO => {
      let KO = OO[0],
        pO = pK[KO];
      if (!pO) {
        if (16 === KO) {
          let KO = new ArrayBuffer(OO.length - 1);
          return new Uint8Array(KO).set(OO.subarray(1)), KO
        }
        throw new Error("Could not find typed array for code " + KO)
      }
      return new XK[pO](Uint8Array.prototype.slice.call(OO, 1).buffer)
    }, zK[120] = () => {
      let OO = YO();
      return new RegExp(OO[0], OO[1])
    };
    const bp = [];

    function eK(OO) {
      IO && IO();
      let KO = eO,
        pO = lO,
        XO = FO,
        vK = LO,
        zK = QO,
        AO = hO,
        fO = oO,
        dO = MO,
        TO = DO,
        NO = new Uint8Array(bK.slice(0, eO)),
        gK = CO,
        uO = CO.slice(0, CO.length),
        EO = VO,
        jK = yK,
        YO = OO();
      return eO = KO, lO = pO, FO = XO, LO = vK, QO = zK, hO = AO, oO = fO, MO = dO, DO = TO, bK = NO, yK = jK, (CO = gK).splice(0, CO.length, ...uO), VO = EO, aK = new DataView(bK.buffer, bK.byteOffset, bK.byteLength), YO
    }

    function lK() {
      bK = null, MO = null, CO = null
    }
    zK[98] = OO => {
      let KO = (OO[0] << 24) + (OO[1] << 16) + (OO[2] << 8) + OO[3],
        pO = lO;
      return lO += KO - OO.length, DO = bp, (DO = [xK(), xK()]).position0 = 0, DO.position1 = 0, DO.postBundlePosition = lO, lO = pO, YO()
    }, zK[255] = OO => 4 == OO.length ? new Date(1e3 * (16777216 * OO[0] + (OO[1] << 16) + (OO[2] << 8) + OO[3])) : 8 == OO.length ? new Date(((OO[0] << 22) + (OO[1] << 14) + (OO[2] << 6) + (OO[3] >> 2)) / 1e6 + 1e3 * (4294967296 * (3 & OO[3]) + 16777216 * OO[4] + (OO[5] << 16) + (OO[6] << 8) + OO[7])) : 12 == OO.length ? new Date(((OO[0] << 24) + (OO[1] << 16) + (OO[2] << 8) + OO[3]) / 1e6 + 1e3 * ((128 & OO[4] ? -281474976710656 : 0) + 1099511627776 * OO[6] + 4294967296 * OO[7] + 16777216 * OO[8] + (OO[9] << 16) + (OO[10] << 8) + OO[11])) : new Date("invalid");
    const vp = new Array(147);
    for (let bX = 0; bX < 256; bX++) vp[bX] = +("1e" + Math.floor(45.15 - .30103 * bX));
    const CK = uO;
    var hK = new uO({
      useRecords: !1
    });
    const DK = hK.unpack,
      MK = hK.unpackMultiple,
      ap = hK.unpack,
      oK = {
        NEVER: 0,
        ALWAYS: 1,
        DECIMAL_ROUND: 3,
        DECIMAL_FIT: 4
      };
    let FK, VK, LK, QK = new Float32Array(1),
      zp = new Uint8Array(QK.buffer, 0, 4);

    function AK(OO) {
      QK[0] = OO;
      let KO = vp[(127 & zp[3]) << 1 | zp[2] >> 7];
      return (KO * OO + (OO > 0 ? .5 : -.5) | 0) / KO
    }
    try {
      FK = new TextEncoder
    } catch (Xp) {}
    const fK = "undefined" !== typeof Buffer,
      dK = fK ? function(OO) {
        return Buffer.allocUnsafeSlow(OO)
      } : Uint8Array,
      TK = fK ? Buffer : Uint8Array,
      NK = fK ? 4294967296 : 2144337920;
    let IK, yp, gp, uK, EK, jp = 0,
      YK = null;
    const wK = /[\u0080-\uFFFF]/,
      ip = Symbol("record-id");
    class rp extends uO {
      constructor(OO) {
        let KO, pO, XO, bK;
        super(OO), this.offset = 0;
        let eO = TK.prototype.utf8Write ? function(OO, KO) {
            return IK.utf8Write(OO, KO, IK.byteLength - KO)
          } : !(!FK || !FK.encodeInto) && function(OO, KO) {
            return FK.encodeInto(OO, IK.subarray(KO)).written
          },
          lO = this;
        OO || (OO = {});
        let vK = OO && OO.sequential,
          CO = OO.structures || OO.saveStructures,
          hO = OO.maxSharedStructures;
        if (null == hO && (hO = CO ? 32 : 0), hO > 8160) throw new Error("Maximum maxSharedStructure is 8160");
        OO.structuredClone && void 0 == OO.moreTypes && (this.moreTypes = !0);
        let DO = OO.maxOwnStructures;
        null == DO && (DO = CO ? 32 : 64), this.structures || 0 == OO.useRecords || (this.structures = []);
        let MO = hO > 32 || DO + hO > 64,
          aK = hO + 64,
          oO = hO + DO + 64;
        if (oO > 8256) throw new Error("Maximum maxSharedStructure + maxOwnStructure is 8192");
        let FO = [],
          VO = 0,
          LO = 0;
        this.pack = this.encode = function(OO, eO) {
          if (IK || (IK = new dK(8192), gp = IK.dataView || (IK.dataView = new DataView(IK.buffer, 0, 8192)), jp = 0), uK = IK.length - 10, uK - jp < 2048 ? (IK = new dK(IK.length), gp = IK.dataView || (IK.dataView = new DataView(IK.buffer, 0, IK.length)), uK = IK.length - 10, jp = 0) : jp = jp + 7 & 2147483640, KO = jp, eO & kp && (jp += 255 & eO), bK = lO.structuredClone ? new Map : null, lO.bundleStrings && "string" !== typeof OO ? (YK = [], YK.size = 1 / 0) : YK = null, XO = lO.structures, XO) {
            XO.uninitialized && (XO = lO._mergeStructures(lO.getStructures()));
            let OO = XO.sharedLength || 0;
            if (OO > hO) throw new Error("Shared structures is larger than maximum shared structures, try increasing maxSharedStructures to " + XO.sharedLength);
            if (!XO.transitions) {
              XO.transitions = Object.create(null);
              for (let KO = 0; KO < OO; KO++) {
                let OO = XO[KO];
                if (!OO) continue;
                let pO, bK = XO.transitions;
                for (let KO = 0, XO = OO.length; KO < XO; KO++) {
                  let XO = OO[KO];
                  pO = bK[XO], pO || (pO = bK[XO] = Object.create(null)), bK = pO
                }
                bK[ip] = KO + 64
              }
              this.lastNamedStructuresLength = OO
            }
            vK || (XO.nextId = OO + 64)
          }
          let CO;
          pO && (pO = !1);
          try {
            lO.randomAccessStructure && OO && OO.constructor && OO.constructor === Object ? uO(OO) : AO(OO);
            let pO = YK;
            if (YK && HK(KO, AO, 0), bK && bK.idsToInsert) {
              let OO = bK.idsToInsert.sort(((OO, KO) => OO.offset > KO.offset ? 1 : -1)),
                XO = OO.length,
                eO = -1;
              for (; pO && XO > 0;) {
                let bK = OO[--XO].offset + KO;
                bK < pO.stringsPosition + KO && -1 === eO && (eO = 0), bK > pO.position + KO ? eO >= 0 && (eO += 6) : (eO >= 0 && (gp.setUint32(pO.position + KO, gp.getUint32(pO.position + KO) + eO), eO = -1), pO = pO.previous, XO++)
              }
              eO >= 0 && pO && gp.setUint32(pO.position + KO, gp.getUint32(pO.position + KO) + eO), jp += 6 * OO.length, jp > uK && IO(jp), lO.offset = jp;
              let vK = function(OO, KO) {
                let pO, XO = 6 * KO.length,
                  bK = OO.length - XO;
                for (; pO = KO.pop();) {
                  let KO = pO.offset,
                    eO = pO.id;
                  OO.copyWithin(KO + XO, KO, bK), XO -= 6;
                  let lO = KO + XO;
                  OO[lO++] = 214, OO[lO++] = 105, OO[lO++] = eO >> 24, OO[lO++] = eO >> 16 & 255, OO[lO++] = eO >> 8 & 255, OO[lO++] = 255 & eO, bK = KO
                }
                return OO
              }(IK.subarray(KO, jp), OO);
              return bK = null, vK
            }
            return lO.offset = jp, eO & WK ? (IK.start = KO, IK.end = jp, IK) : IK.subarray(KO, jp)
          } catch (Xp) {
            throw CO = Xp, Xp
          } finally {
            if (XO && (QO(), pO && lO.saveStructures)) {
              let pO = XO.sharedLength || 0,
                bK = IK.subarray(KO, jp),
                vK = SK(XO, lO);
              if (!CO) return !1 === lO.saveStructures(vK, vK.isCompatible) ? lO.pack(OO, eO) : (lO.lastNamedStructuresLength = pO, IK.length > 1073741824 && (IK = null), bK)
            }
            IK.length > 1073741824 && (IK = null), eO & tp && (jp = KO)
          }
        };
        const QO = () => {
            LO < 10 && LO++;
            let OO = XO.sharedLength || 0;
            if (XO.length > OO && !vK && (XO.length = OO), VO > 1e4) XO.transitions = null, LO = 0, VO = 0, FO.length > 0 && (FO = []);
            else if (FO.length > 0 && !vK) {
              for (let OO = 0, KO = FO.length; OO < KO; OO++) FO[OO][ip] = 0;
              FO = []
            }
          },
          zK = OO => {
            var KO = OO.length;
            KO < 16 ? IK[jp++] = 144 | KO : KO < 65536 ? (IK[jp++] = 220, IK[jp++] = KO >> 8, IK[jp++] = 255 & KO) : (IK[jp++] = 221, gp.setUint32(jp, KO), jp += 4);
            for (let pO = 0; pO < KO; pO++) AO(OO[pO])
          },
          AO = OO => {
            jp > uK && (IK = IO(jp));
            var pO, XO = typeof OO;
            if ("string" === XO) {
              let XO, bK = OO.length;
              if (YK && bK >= 4 && bK < 4096) {
                if ((YK.size += bK) > 21760) {
                  let OO, pO, XO = (YK[0] ? 3 * YK[0].length + YK[1].length : 0) + 10;
                  jp + XO > uK && (IK = IO(jp + XO)), YK.position ? (pO = YK, IK[jp] = 200, jp += 3, IK[jp++] = 98, OO = jp - KO, jp += 4, HK(KO, AO, 0), gp.setUint16(OO + KO - 3, jp - KO - OO)) : (IK[jp++] = 214, IK[jp++] = 98, OO = jp - KO, jp += 4), YK = ["", ""], YK.previous = pO, YK.size = 0, YK.position = OO
                }
                let pO = wK.test(OO);
                return YK[pO ? 0 : 1] += OO, IK[jp++] = 193, void AO(pO ? -bK : bK)
              }
              XO = bK < 32 ? 1 : bK < 256 ? 2 : bK < 65536 ? 3 : 5;
              let lO = 3 * bK;
              if (jp + lO > uK && (IK = IO(jp + lO)), bK < 64 || !eO) {
                let KO, eO, lO, vK = jp + XO;
                for (KO = 0; KO < bK; KO++) eO = OO.charCodeAt(KO), eO < 128 ? IK[vK++] = eO : eO < 2048 ? (IK[vK++] = eO >> 6 | 192, IK[vK++] = 63 & eO | 128) : 55296 === (64512 & eO) && 56320 === (64512 & (lO = OO.charCodeAt(KO + 1))) ? (eO = 65536 + ((1023 & eO) << 10) + (1023 & lO), KO++, IK[vK++] = eO >> 18 | 240, IK[vK++] = eO >> 12 & 63 | 128, IK[vK++] = eO >> 6 & 63 | 128, IK[vK++] = 63 & eO | 128) : (IK[vK++] = eO >> 12 | 224, IK[vK++] = eO >> 6 & 63 | 128, IK[vK++] = 63 & eO | 128);
                pO = vK - jp - XO
              } else pO = eO(OO, jp + XO);
              pO < 32 ? IK[jp++] = 160 | pO : pO < 256 ? (XO < 2 && IK.copyWithin(jp + 2, jp + 1, jp + 1 + pO), IK[jp++] = 217, IK[jp++] = pO) : pO < 65536 ? (XO < 3 && IK.copyWithin(jp + 3, jp + 2, jp + 2 + pO), IK[jp++] = 218, IK[jp++] = pO >> 8, IK[jp++] = 255 & pO) : (XO < 5 && IK.copyWithin(jp + 5, jp + 3, jp + 3 + pO), IK[jp++] = 219, gp.setUint32(jp, pO), jp += 4), jp += pO
            } else if ("number" === XO)
              if (OO >>> 0 === OO) OO < 32 || OO < 128 && !1 === this.useRecords || OO < 64 && !this.randomAccessStructure ? IK[jp++] = OO : OO < 256 ? (IK[jp++] = 204, IK[jp++] = OO) : OO < 65536 ? (IK[jp++] = 205, IK[jp++] = OO >> 8, IK[jp++] = 255 & OO) : (IK[jp++] = 206, gp.setUint32(jp, OO), jp += 4);
              else if ((OO | 0) === OO) OO >= -32 ? IK[jp++] = 256 + OO : OO >= -128 ? (IK[jp++] = 208, IK[jp++] = OO + 256) : OO >= -32768 ? (IK[jp++] = 209, gp.setInt16(jp, OO), jp += 2) : (IK[jp++] = 210, gp.setInt32(jp, OO), jp += 4);
            else {
              let KO;
              if ((KO = this.useFloat32) > 0 && OO < 4294967296 && OO >= -2147483648) {
                let pO;
                if (IK[jp++] = 202, gp.setFloat32(jp, OO), KO < 4 || ((pO = OO * vp[(127 & IK[jp]) << 1 | IK[jp + 1] >> 7]) | 0) === pO) return void(jp += 4);
                jp--
              }
              IK[jp++] = 203, gp.setFloat64(jp, OO), jp += 8
            } else if ("object" === XO || "function" === XO)
              if (OO) {
                if (bK) {
                  let pO = bK.get(OO);
                  if (pO) {
                    if (!pO.id) {
                      let OO = bK.idsToInsert || (bK.idsToInsert = []);
                      pO.id = OO.push(pO)
                    }
                    return IK[jp++] = 214, IK[jp++] = 112, gp.setUint32(jp, pO.id), void(jp += 4)
                  }
                  bK.set(OO, {
                    offset: jp - KO
                  })
                }
                let eO = OO.constructor;
                if (eO === Object) NO(OO);
                else if (eO === Array) zK(OO);
                else if (eO === Map)
                  if (this.mapAsEmptyObject) IK[jp++] = 128;
                  else {
                    (pO = OO.size) < 16 ? IK[jp++] = 128 | pO : pO < 65536 ? (IK[jp++] = 222, IK[jp++] = pO >> 8, IK[jp++] = 255 & pO) : (IK[jp++] = 223, gp.setUint32(jp, pO), jp += 4);
                    for (let [KO, pO] of OO) AO(KO), AO(pO)
                  }
                else {
                  for (let KO = 0, pO = VK.length; KO < pO; KO++) {
                    if (OO instanceof LK[KO]) {
                      let pO = VK[KO];
                      if (pO.write) {
                        pO.type && (IK[jp++] = 212, IK[jp++] = pO.type, IK[jp++] = 0);
                        let KO = pO.write.call(this, OO);
                        return void(KO === OO ? Array.isArray(OO) ? zK(OO) : NO(OO) : AO(KO))
                      }
                      let XO, bK = IK,
                        eO = gp,
                        lO = jp;
                      IK = null;
                      try {
                        XO = pO.pack.call(this, OO, (OO => (IK = bK, bK = null, jp += OO, jp > uK && IO(jp), {
                          target: IK,
                          targetView: gp,
                          position: jp - OO
                        })), AO)
                      } finally {
                        bK && (IK = bK, gp = eO, jp = lO, uK = IK.length - 10)
                      }
                      return void(XO && (XO.length + jp > uK && IO(XO.length + jp), jp = sK(XO, IK, jp, pO.type)))
                    }
                  }
                  if (Array.isArray(OO)) zK(OO);
                  else {
                    if (OO.toJSON) {
                      const KO = OO.toJSON();
                      if (KO !== OO) return AO(KO)
                    }
                    if ("function" === XO) return AO(this.writeFunction && this.writeFunction(OO));
                    NO(OO)
                  }
                }
              } else IK[jp++] = 192;
            else if ("boolean" === XO) IK[jp++] = OO ? 195 : 194;
            else if ("bigint" === XO) {
              if (OO < BigInt(1) << BigInt(63) && OO >= -(BigInt(1) << BigInt(63))) IK[jp++] = 211, gp.setBigInt64(jp, OO);
              else if (OO < BigInt(1) << BigInt(64) && OO > 0) IK[jp++] = 207, gp.setBigUint64(jp, OO);
              else {
                if (!this.largeBigIntToFloat) {
                  if (this.largeBigIntToString) return AO(OO.toString());
                  if (this.useBigIntExtension && OO < BigInt(2) ** BigInt(1023) && OO > -(BigInt(2) ** BigInt(1023))) {
                    IK[jp++] = 199, jp++, IK[jp++] = 66;
                    let KO, pO = [];
                    do {
                      let XO = OO & BigInt(255);
                      KO = (XO & BigInt(128)) === (OO < BigInt(0) ? BigInt(128) : BigInt(0)), pO.push(XO), OO >>= BigInt(8)
                    } while (OO !== BigInt(0) && OO !== BigInt(-1) || !KO);
                    IK[jp - 2] = pO.length;
                    for (let OO = pO.length; OO > 0;) IK[jp++] = Number(pO[--OO]);
                    return
                  }
                  throw new RangeError(OO + " was too large to fit in MessagePack 64-bit integer format, use useBigIntExtension, or set largeBigIntToFloat to convert to float-64, or set largeBigIntToString to convert to string")
                }
                IK[jp++] = 203, gp.setFloat64(jp, Number(OO))
              }
              jp += 8
            } else {
              if ("undefined" !== XO) throw new Error("Unknown type: " + XO);
              this.encodeUndefinedAsNil ? IK[jp++] = 192 : (IK[jp++] = 212, IK[jp++] = 0, IK[jp++] = 0)
            }
          },
          fO = this.variableMapSize || this.coercibleKeyAsNumber || this.skipValues ? OO => {
            let KO;
            if (this.skipValues) {
              KO = [];
              for (let pO in OO) "function" === typeof OO.hasOwnProperty && !OO.hasOwnProperty(pO) || this.skipValues.includes(OO[pO]) || KO.push(pO)
            } else KO = Object.keys(OO);
            let pO, XO = KO.length;
            if (XO < 16 ? IK[jp++] = 128 | XO : XO < 65536 ? (IK[jp++] = 222, IK[jp++] = XO >> 8, IK[jp++] = 255 & XO) : (IK[jp++] = 223, gp.setUint32(jp, XO), jp += 4), this.coercibleKeyAsNumber)
              for (let bK = 0; bK < XO; bK++) {
                pO = KO[bK];
                let XO = Number(pO);
                AO(isNaN(XO) ? pO : XO), AO(OO[pO])
              } else
                for (let bK = 0; bK < XO; bK++) AO(pO = KO[bK]), AO(OO[pO])
          } : OO => {
            IK[jp++] = 222;
            let pO = jp - KO;
            jp += 2;
            let XO = 0;
            for (let KO in OO)("function" !== typeof OO.hasOwnProperty || OO.hasOwnProperty(KO)) && (AO(KO), AO(OO[KO]), XO++);
            if (XO > 65535) throw new Error('Object is too large to serialize with fast 16-bit map size, use the "variableMapSize" option to serialize this object');
            IK[pO++ + KO] = XO >> 8, IK[pO + KO] = 255 & XO
          },
          dO = !1 === this.useRecords ? fO : OO.progressiveRecords && !MO ? OO => {
            let pO, bK, eO = XO.transitions || (XO.transitions = Object.create(null)),
              lO = jp++ - KO;
            for (let vK in OO)
              if ("function" !== typeof OO.hasOwnProperty || OO.hasOwnProperty(vK)) {
                if (pO = eO[vK], pO) eO = pO;
                else {
                  let CO = Object.keys(OO),
                    hO = eO;
                  eO = XO.transitions;
                  let DO = 0;
                  for (let OO = 0, KO = CO.length; OO < KO; OO++) {
                    let KO = CO[OO];
                    pO = eO[KO], pO || (pO = eO[KO] = Object.create(null), DO++), eO = pO
                  }
                  lO + KO + 1 == jp ? (jp--, yK(eO, CO, DO)) : gK(eO, CO, lO, DO), bK = !0, eO = hO[vK]
                }
                AO(OO[vK])
              } if (!bK) {
              let pO = eO[ip];
              pO ? IK[lO + KO] = pO : gK(eO, Object.keys(OO), lO, 0)
            }
          } : OO => {
            let KO, pO = XO.transitions || (XO.transitions = Object.create(null)),
              bK = 0;
            for (let XO in OO)("function" !== typeof OO.hasOwnProperty || OO.hasOwnProperty(XO)) && (KO = pO[XO], KO || (KO = pO[XO] = Object.create(null), bK++), pO = KO);
            let eO = pO[ip];
            eO ? eO >= 96 && MO ? (IK[jp++] = 96 + (31 & (eO -= 96)), IK[jp++] = eO >> 5) : IK[jp++] = eO : yK(pO, pO.__keys__ || Object.keys(OO), bK);
            for (let XO in OO)("function" !== typeof OO.hasOwnProperty || OO.hasOwnProperty(XO)) && AO(OO[XO])
          },
          TO = "function" == typeof this.useRecords && this.useRecords,
          NO = TO ? OO => {
            TO(OO) ? dO(OO) : fO(OO)
          } : dO,
          IO = OO => {
            let pO;
            if (OO > 16777216) {
              if (OO - KO > NK) throw new Error("Packed buffer would be larger than maximum buffer size");
              pO = Math.min(NK, 4096 * Math.round(Math.max((OO - KO) * (OO > 67108864 ? 1.25 : 2), 4194304) / 4096))
            } else pO = 1 + (Math.max(OO - KO << 2, IK.length - 1) >> 12) << 12;
            let XO = new dK(pO);
            return gp = XO.dataView || (XO.dataView = new DataView(XO.buffer, 0, pO)), OO = Math.min(OO, IK.length), IK.copy ? IK.copy(XO, 0, KO, OO) : XO.set(IK.slice(KO, OO)), jp -= KO, KO = 0, uK = XO.length - 10, IK = XO
          },
          yK = (OO, KO, bK) => {
            let eO = XO.nextId;
            eO || (eO = 64), eO < aK && this.shouldShareStructure && !this.shouldShareStructure(KO) ? (eO = XO.nextOwnId, eO < oO || (eO = aK), XO.nextOwnId = eO + 1) : (eO >= oO && (eO = aK), XO.nextId = eO + 1);
            let lO = KO.highByte = eO >= 96 && MO ? eO - 96 >> 5 : -1;
            OO[ip] = eO, OO.__keys__ = KO, XO[eO - 64] = KO, eO < aK ? (KO.isShared = !0, XO.sharedLength = eO - 63, pO = !0, lO >= 0 ? (IK[jp++] = 96 + (31 & eO), IK[jp++] = lO) : IK[jp++] = eO) : (lO >= 0 ? (IK[jp++] = 213, IK[jp++] = 114, IK[jp++] = 96 + (31 & eO), IK[jp++] = lO) : (IK[jp++] = 212, IK[jp++] = 114, IK[jp++] = eO), bK && (VO += LO * bK), FO.length >= DO && (FO.shift()[ip] = 0), FO.push(OO), AO(KO))
          },
          gK = (OO, pO, XO, bK) => {
            let eO = IK,
              lO = jp,
              vK = uK,
              CO = KO;
            IK = yp, jp = 0, KO = 0, IK || (yp = IK = new dK(8192)), uK = IK.length - 10, yK(OO, pO, bK), yp = IK;
            let hO = jp;
            if (IK = eO, jp = lO, uK = vK, KO = CO, hO > 1) {
              let OO = jp + hO - 1;
              OO > uK && IO(OO);
              let pO = XO + KO;
              IK.copyWithin(pO + hO, pO + 1, jp), IK.set(yp.slice(0, hO), pO), jp = OO
            } else IK[XO + KO] = yp[0]
          },
          uO = OO => {
            let bK = EK(OO, IK, KO, jp, XO, IO, ((OO, KO, XO) => {
              if (XO) return pO = !0;
              jp = KO;
              let bK = IK;
              return AO(OO), QO(), bK !== IK ? {
                position: jp,
                targetView: gp,
                target: IK
              } : jp
            }), this);
            if (0 === bK) return NO(OO);
            jp = bK
          }
      }
      useBuffer(OO) {
        IK = OO, gp = IK.dataView || (IK.dataView = new DataView(IK.buffer, IK.byteOffset, IK.byteLength)), jp = 0
      }
      set position(OO) {
        jp = OO
      }
      get position() {
        return jp
      }
      set buffer(OO) {
        IK = OO
      }
      get buffer() {
        return IK
      }
      clearSharedData() {
        this.structures && (this.structures = []), this.typedStructs && (this.typedStructs = [])
      }
    }

    function PK(OO, KO, pO, XO) {
      let bK = OO.byteLength;
      if (bK + 1 < 256) {
        var {
          target: eO,
          position: lO
        } = pO(4 + bK);
        eO[lO++] = 199, eO[lO++] = bK + 1
      } else if (bK + 1 < 65536) {
        var {
          target: eO,
          position: lO
        } = pO(5 + bK);
        eO[lO++] = 200, eO[lO++] = bK + 1 >> 8, eO[lO++] = bK + 1 & 255
      } else {
        var {
          target: eO,
          position: lO,
          targetView: vK
        } = pO(7 + bK);
        eO[lO++] = 201, vK.setUint32(lO, bK + 1), lO += 4
      }
      eO[lO++] = 116, eO[lO++] = KO, OO.buffer || (OO = new Uint8Array(OO)), eO.set(new Uint8Array(OO.buffer, OO.byteOffset, OO.byteLength), lO)
    }

    function mp(OO, KO) {
      let pO = OO.byteLength;
      var XO, bK;
      if (pO < 256) {
        var {
          target: XO,
          position: bK
        } = KO(pO + 2);
        XO[bK++] = 196, XO[bK++] = pO
      } else if (pO < 65536) {
        var {
          target: XO,
          position: bK
        } = KO(pO + 3);
        XO[bK++] = 197, XO[bK++] = pO >> 8, XO[bK++] = 255 & pO
      } else {
        var {
          target: XO,
          position: bK,
          targetView: eO
        } = KO(pO + 5);
        XO[bK++] = 198, eO.setUint32(bK, pO), bK += 4
      }
      XO.set(OO, bK)
    }

    function sK(OO, KO, pO, XO) {
      let bK = OO.length;
      switch (bK) {
        case 1:
          KO[pO++] = 212;
          break;
        case 2:
          KO[pO++] = 213;
          break;
        case 4:
          KO[pO++] = 214;
          break;
        case 8:
          KO[pO++] = 215;
          break;
        case 16:
          KO[pO++] = 216;
          break;
        default:
          bK < 256 ? (KO[pO++] = 199, KO[pO++] = bK) : bK < 65536 ? (KO[pO++] = 200, KO[pO++] = bK >> 8, KO[pO++] = 255 & bK) : (KO[pO++] = 201, KO[pO++] = bK >> 24, KO[pO++] = bK >> 16 & 255, KO[pO++] = bK >> 8 & 255, KO[pO++] = 255 & bK)
      }
      return KO[pO++] = XO, KO.set(OO, pO), pO += bK
    }

    function HK(OO, KO, pO) {
      if (YK.length > 0) {
        gp.setUint32(YK.position + OO, jp + pO - YK.position - OO), YK.stringsPosition = jp - OO;
        let XO = YK;
        YK = null, KO(XO[0]), KO(XO[1])
      }
    }

    function RK(OO) {
      if (OO.Class) {
        if (!OO.pack && !OO.write) throw new Error("Extension has no pack or write function");
        if (OO.pack && !OO.type) throw new Error("Extension has no type (numeric code to identify the extension)");
        LK.unshift(OO.Class), VK.unshift(OO)
      }! function(OO) {
        OO.unpack ? zK[OO.type] = OO.unpack : zK[OO.type] = OO
      }(OO)
    }

    function SK(OO, KO) {
      return OO.isCompatible = OO => {
        let pO = !OO || (KO.lastNamedStructuresLength || 0) === OO.length;
        return pO || KO._mergeStructures(OO), pO
      }, OO
    }
    LK = [Date, Set, Error, RegExp, ArrayBuffer, Object.getPrototypeOf(Uint8Array.prototype).constructor, fO], VK = [{
      pack(OO, KO, pO) {
        let XO = OO.getTime() / 1e3;
        if ((this.useTimestamp32 || 0 === OO.getMilliseconds()) && XO >= 0 && XO < 4294967296) {
          let {
            target: OO,
            targetView: pO,
            position: bK
          } = KO(6);
          OO[bK++] = 214, OO[bK++] = 255, pO.setUint32(bK, XO)
        } else if (XO > 0 && XO < 4294967296) {
          let {
            target: pO,
            targetView: bK,
            position: eO
          } = KO(10);
          pO[eO++] = 215, pO[eO++] = 255, bK.setUint32(eO, 4e6 * OO.getMilliseconds() + (XO / 1e3 / 4294967296 | 0)), bK.setUint32(eO + 4, XO)
        } else if (isNaN(XO)) {
          if (this.onInvalidDate) return KO(0), pO(this.onInvalidDate());
          let {
            target: OO,
            targetView: XO,
            position: bK
          } = KO(3);
          OO[bK++] = 212, OO[bK++] = 255, OO[bK++] = 255
        } else {
          let {
            target: pO,
            targetView: bK,
            position: eO
          } = KO(15);
          pO[eO++] = 199, pO[eO++] = 12, pO[eO++] = 255, bK.setUint32(eO, 1e6 * OO.getMilliseconds()), bK.setBigInt64(eO + 4, BigInt(Math.floor(XO)))
        }
      }
    }, {
      pack(OO, KO, pO) {
        if (this.setAsEmptyObject) return KO(0), pO({});
        let XO = Array.from(OO),
          {
            target: bK,
            position: eO
          } = KO(this.moreTypes ? 3 : 0);
        this.moreTypes && (bK[eO++] = 212, bK[eO++] = 115, bK[eO++] = 0), pO(XO)
      }
    }, {
      pack(OO, KO, pO) {
        let {
          target: XO,
          position: bK
        } = KO(this.moreTypes ? 3 : 0);
        this.moreTypes && (XO[bK++] = 212, XO[bK++] = 101, XO[bK++] = 0), pO([OO.name, OO.message, OO.cause])
      }
    }, {
      pack(OO, KO, pO) {
        let {
          target: XO,
          position: bK
        } = KO(this.moreTypes ? 3 : 0);
        this.moreTypes && (XO[bK++] = 212, XO[bK++] = 120, XO[bK++] = 0), pO([OO.source, OO.flags])
      }
    }, {
      pack(OO, KO) {
        this.moreTypes ? PK(OO, 16, KO) : mp(fK ? Buffer.from(OO) : new Uint8Array(OO), KO)
      }
    }, {
      pack(OO, KO) {
        let pO = OO.constructor;
        pO !== TK && this.moreTypes ? PK(OO, pK.indexOf(pO.name), KO) : mp(OO, KO)
      }
    }, {
      pack(OO, KO) {
        let {
          target: pO,
          position: XO
        } = KO(1);
        pO[XO] = 193
      }
    }];
    let JK = new rp({
      useRecords: !1
    });
    const cp = JK.pack,
      BK = JK.pack,
      ZK = rp,
      {
        NEVER: GK,
        ALWAYS: qp,
        DECIMAL_ROUND: xp,
        DECIMAL_FIT: nK
      } = oK,
      WK = 512,
      tp = 1024,
      kp = 2048;
    const UK = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (!OO || "object" !== typeof OO) throw new Error("first argument must be an Iterable, Async Iterable, Iterator, Async Iterator, or a promise");
        const pO = new uO(KO);
        let XO;
        const bK = OO => {
          let KO;
          XO && (OO = Buffer.concat([XO, OO]), XO = void 0);
          try {
            KO = pO.unpackMultiple(OO)
          } catch (bK) {
            if (!bK.incomplete) throw bK;
            XO = OO.slice(bK.lastPosition), KO = bK.values
          }
          return KO
        };
        return "function" === typeof OO[Symbol.iterator] ? function*() {
          for (const KO of OO) yield* bK(KO)
        }() : "function" === typeof OO[Symbol.asyncIterator] ? async function*() {
          for await (const KO of OO) yield* bK(KO)
        }(): void 0
      },
      Op = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (OO && "object" === typeof OO) {
          if ("function" === typeof OO[Symbol.iterator]) return function*(OO, KO) {
            const pO = new rp(KO);
            for (const XO of OO) yield pO.pack(XO)
          }(OO, KO);
          if ("function" === typeof OO.then || "function" === typeof OO[Symbol.asyncIterator]) return async function*(OO, KO) {
            const pO = new rp(KO);
            for await (const XO of OO) yield pO.pack(XO)
          }(OO, KO);
          throw new Error("first argument must be an Iterable, Async Iterable, Iterator, Async Iterator, or a Promise")
        }
        throw new Error("first argument must be an Iterable, Async Iterable, or a Promise for an Async Iterable")
      },
      Kp = !1,
      pp = !0
  },
  8153: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      $changes: () => VO,
      $childType: () => LO,
      $decoder: () => DO,
      $deleteByIndex: () => oO,
      $encoder: () => hO,
      $filter: () => MO,
      $getByIndex: () => aK,
      $numFields: () => gK,
      $refId: () => vK,
      $track: () => CO,
      $values: () => dO,
      ArraySchema: () => pX,
      Callbacks: () => pb,
      ChangeTree: () => jX,
      CollectionSchema: () => eX,
      Decoder: () => xb,
      Encoder: () => BX,
      FieldBuilder: () => CX,
      MapSchema: () => bb,
      Metadata: () => xp,
      OPERATION: () => bK,
      Reflection: () => kb,
      ReflectionField: () => WX,
      ReflectionType: () => tb,
      Root: () => YX,
      Schema: () => EX,
      SetSchema: () => lX,
      StateCallbackStrategy: () => Kb,
      StateView: () => mb,
      StreamSchema: () => vb,
      TypeContext: () => SK,
      createPool: () => be,
      decode: () => AK,
      decodeKeyValueOperation: () => Wp,
      decodeSchemaOperation: () => np,
      defineCustomTypes: () => NK,
      defineTypes: () => yb,
      deprecated: () => NX,
      dumpChanges: () => uX,
      encode: () => KK,
      encodeArray: () => Hp,
      encodeIndexedEntry: () => mX,
      encodeKeyValueOperation: () => sp,
      encodeMapEntry: () => Pp,
      encodeSchemaOperation: () => rX,
      dX: () => VX,
      fullStateOnly: () => AX,
      getDecoderStateCallbacks: () => UX,
      getEncodeDescriptor: () => Op,
      getRawChangesCallback: () => Ob,
      isBuilder: () => hX,
      patchOnly: () => zb,
      registerType: () => TK,
      schema: () => gb,
      t: () => oX,
      type: () => fX,
      unreliable: () => QX,
      view: () => LX
    });
    const XO = 255;
    var bK;

    function eO(OO) {
      Object.defineProperty(OO, Symbol.metadata, {
        value: void 0,
        writable: !0,
        configurable: !0,
        enumerable: !1
      })
    }! function(OO) {
      OO[OO.ADD = 128] = "ADD", OO[OO.REPLACE = 0] = "REPLACE", OO[OO.DELETE = 64] = "DELETE", OO[OO.DELETE_AND_MOVE = 96] = "DELETE_AND_MOVE", OO[OO.MOVE_AND_ADD = 160] = "MOVE_AND_ADD", OO[OO.DELETE_AND_ADD = 192] = "DELETE_AND_ADD", OO[OO.CLEAR = 10] = "CLEAR", OO[OO.REVERSE = 15] = "REVERSE", OO[OO.MOVE = 32] = "MOVE", OO[OO.DELETE_BY_REFID = 33] = "DELETE_BY_REFID", OO[OO.ADD_BY_REFID = 129] = "ADD_BY_REFID"
    }(bK || (bK = {})), Symbol.metadata ??= Symbol.for("Symbol.metadata");
    const lO = "undefined" !== typeof globalThis ? globalThis : "undefined" !== typeof global ? global : "undefined" !== typeof self ? self : "undefined" !== typeof window ? window : {};
    if ("function" === typeof Symbol && "function" !== typeof Symbol.for) {
      const OO = "colyseus.symbolRegistry",
        KO = lO[OO] || (lO[OO] = Object.create(null));
      Symbol.for = function(OO) {
        return KO[OO] || (KO[OO] = Symbol(OO))
      }, Symbol.keyFor = function(OO) {
        for (const pO in KO)
          if (KO[pO] === OO) return pO
      }
    }
    const vK = Symbol.for("$refId"),
      CO = "~track",
      hO = "~encoder",
      DO = "~decoder",
      MO = "~filter",
      aK = "~getByIndex",
      oO = "~deleteByIndex",
      FO = "~resyncPrune",
      VO = Symbol.for("$changes"),
      LO = Symbol.for("$childType"),
      QO = Symbol.for("$proxyTarget"),
      zK = "~onEncodeEnd",
      AO = "~reset",
      fO = "~onDecodeEnd",
      dO = Symbol.for("$values"),
      TO = "~builder",
      NO = "~descriptors",
      IO = "~__encodeDescriptor",
      yK = "~encoders",
      gK = "~__numFields",
      uO = "~__refTypeFieldIndexes",
      EO = "~__viewFieldIndexes",
      jK = "$__fieldIndexesByViewTag",
      YO = "~__unreliableFieldIndexes",
      wO = "~__patchOnlyFieldIndexes",
      iK = "~__fullSyncSkipIndexes",
      rK = "~__fullStateOnlyFieldIndexes",
      PO = "~__streamFieldIndexes",
      mK = "~__streamPriorities";
    let sO;
    try {
      sO = new TextEncoder
    } catch (eb) {}
    const HO = new ArrayBuffer(8),
      RO = new Int32Array(HO),
      SO = new Float32Array(HO),
      JO = new Float64Array(HO),
      cK = new BigInt64Array(HO),
      BO = "undefined" !== typeof Buffer && Buffer.byteLength ? Buffer.byteLength : function(OO, KO) {
        for (var pO = 0, XO = 0, bK = 0, eO = OO.length; bK < eO; bK++)(pO = OO.charCodeAt(bK)) < 128 ? XO += 1 : pO < 2048 ? XO += 2 : pO < 55296 || pO >= 57344 ? XO += 3 : (bK++, XO += 4);
        return XO
      };

    function ZO(OO, KO, pO) {
      for (var XO = 0, bK = 0, eO = KO.length; bK < eO; bK++)(XO = KO.charCodeAt(bK)) < 128 ? OO[pO.offset++] = XO : XO < 2048 ? (OO[pO.offset] = 192 | XO >> 6, OO[pO.offset + 1] = 128 | 63 & XO, pO.offset += 2) : XO < 55296 || XO >= 57344 ? (OO[pO.offset] = 224 | XO >> 12, OO[pO.offset + 1] = 128 | XO >> 6 & 63, OO[pO.offset + 2] = 128 | 63 & XO, pO.offset += 3) : (bK++, XO = 65536 + ((1023 & XO) << 10 | 1023 & KO.charCodeAt(bK)), OO[pO.offset] = 240 | XO >> 18, OO[pO.offset + 1] = 128 | XO >> 12 & 63, OO[pO.offset + 2] = 128 | XO >> 6 & 63, OO[pO.offset + 3] = 128 | 63 & XO, pO.offset += 4)
    }

    function GO(OO, KO, pO) {
      OO[pO.offset++] = 255 & KO
    }

    function qK(OO, KO, pO) {
      OO[pO.offset++] = 255 & KO, OO[pO.offset++] = KO >> 8 & 255
    }

    function xK(OO, KO, pO) {
      OO[pO.offset++] = 255 & KO, OO[pO.offset++] = KO >> 8 & 255
    }

    function nO(OO, KO, pO) {
      OO[pO.offset++] = 255 & KO, OO[pO.offset++] = KO >> 8 & 255, OO[pO.offset++] = KO >> 16 & 255, OO[pO.offset++] = KO >> 24 & 255
    }

    function WO(OO, KO, pO) {
      const XO = KO >> 24,
        bK = KO >> 16,
        eO = KO >> 8,
        lO = KO;
      OO[pO.offset++] = 255 & lO, OO[pO.offset++] = 255 & eO, OO[pO.offset++] = 255 & bK, OO[pO.offset++] = 255 & XO
    }

    function tK(OO, KO, pO) {
      const XO = Math.floor(KO / Math.pow(2, 32));
      WO(OO, KO >>> 0, pO), WO(OO, XO, pO)
    }

    function kK(OO, KO, pO) {
      const XO = KO / Math.pow(2, 32) | 0;
      WO(OO, KO >>> 0, pO), WO(OO, XO, pO)
    }

    function UO(OO, KO, pO) {
      SO[0] = KO, nO(OO, RO[0], pO)
    }

    function OK(OO, KO, pO) {
      JO[0] = KO, nO(OO, RO[0], pO), nO(OO, RO[1], pO)
    }
    const KK = {
        int8: GO,
        uint8: function(OO, KO, pO) {
          OO[pO.offset++] = 255 & KO
        },
        int16: qK,
        uint16: xK,
        int32: nO,
        uint32: WO,
        int64: tK,
        uint64: kK,
        bigint64: function(OO, KO, pO) {
          cK[0] = BigInt.asIntN(64, KO), nO(OO, RO[0], pO), nO(OO, RO[1], pO)
        },
        biguint64: function(OO, KO, pO) {
          cK[0] = BigInt.asIntN(64, KO), nO(OO, RO[0], pO), nO(OO, RO[1], pO)
        },
        float32: UO,
        float64: OK,
        boolean: function(OO, KO, pO) {
          OO[pO.offset++] = KO ? 1 : 0
        },
        string: function(OO, KO, pO) {
          KO || (KO = "");
          let XO = BO(KO, "utf8"),
            bK = 0;
          if (XO < 32) OO[pO.offset++] = 160 | XO, bK = 1;
          else if (XO < 256) OO[pO.offset++] = 217, OO[pO.offset++] = XO, bK = 2;
          else if (XO < 65536) OO[pO.offset++] = 218, xK(OO, XO, pO), bK = 3;
          else {
            if (!(XO < 4294967296)) throw new Error("String too long");
            OO[pO.offset++] = 219, WO(OO, XO, pO), bK = 5
          }
          return ZO(OO, KO, pO), bK + XO
        },
        number: function OO(KO, pO, XO) {
          return isNaN(pO) ? OO(KO, 0, XO) : isFinite(pO) ? pO !== (0 | pO) ? Math.abs(pO) <= 34028235e31 && (SO[0] = pO, Math.abs(Math.abs(SO[0]) - Math.abs(pO)) < 1e-4) ? (KO[XO.offset++] = 202, UO(KO, pO, XO), 5) : (KO[XO.offset++] = 203, OK(KO, pO, XO), 9) : pO >= 0 ? pO < 128 ? (KO[XO.offset++] = 255 & pO, 1) : pO < 256 ? (KO[XO.offset++] = 204, KO[XO.offset++] = 255 & pO, 2) : pO < 65536 ? (KO[XO.offset++] = 205, xK(KO, pO, XO), 3) : pO < 4294967296 ? (KO[XO.offset++] = 206, WO(KO, pO, XO), 5) : (KO[XO.offset++] = 207, kK(KO, pO, XO), 9) : pO >= -32 ? (KO[XO.offset++] = 224 | pO + 32, 1) : pO >= -128 ? (KO[XO.offset++] = 208, GO(KO, pO, XO), 2) : pO >= -32768 ? (KO[XO.offset++] = 209, qK(KO, pO, XO), 3) : pO >= -2147483648 ? (KO[XO.offset++] = 210, nO(KO, pO, XO), 5) : (KO[XO.offset++] = 211, tK(KO, pO, XO), 9) : OO(KO, pO > 0 ? Number.MAX_SAFE_INTEGER : -Number.MAX_SAFE_INTEGER, XO)
        },
        utf8Write: ZO,
        utf8Length: BO
      },
      pK = new ArrayBuffer(8),
      XK = new Int32Array(pK),
      bp = new Float32Array(pK),
      eK = new Float64Array(pK),
      lK = new BigUint64Array(pK),
      vp = new BigInt64Array(pK);

    function CK(OO, KO, pO) {
      pO > OO.length - KO.offset && (pO = OO.length - KO.offset);
      for (var XO = "", bK = 0, eO = KO.offset, lO = KO.offset + pO; eO < lO; eO++) {
        var vK = OO[eO];
        if (0 !== (128 & vK))
          if (192 !== (224 & vK))
            if (224 !== (240 & vK)) {
              if (240 !== (248 & vK)) {
                console.error("decode.utf8Read(): Invalid byte " + vK + " at offset " + eO + ". Skip to end of string: " + (KO.offset + pO));
                break
              }(bK = (7 & vK) << 18 | (63 & OO[++eO]) << 12 | (63 & OO[++eO]) << 6 | 63 & OO[++eO]) >= 65536 ? (bK -= 65536, XO += String.fromCharCode(55296 + (bK >>> 10), 56320 + (1023 & bK))) : XO += String.fromCharCode(bK)
            } else XO += String.fromCharCode((15 & vK) << 12 | (63 & OO[++eO]) << 6 | 63 & OO[++eO]);
        else XO += String.fromCharCode((31 & vK) << 6 | 63 & OO[++eO]);
        else XO += String.fromCharCode(vK)
      }
      return KO.offset += pO, XO
    }

    function hK(OO, KO) {
      return DK(OO, KO) << 24 >> 24
    }

    function DK(OO, KO) {
      return OO[KO.offset++]
    }

    function MK(OO, KO) {
      return ap(OO, KO) << 16 >> 16
    }

    function ap(OO, KO) {
      return OO[KO.offset++] | OO[KO.offset++] << 8
    }

    function oK(OO, KO) {
      return OO[KO.offset++] | OO[KO.offset++] << 8 | OO[KO.offset++] << 16 | OO[KO.offset++] << 24
    }

    function FK(OO, KO) {
      return oK(OO, KO) >>> 0
    }

    function VK(OO, KO) {
      return XK[0] = oK(OO, KO), bp[0]
    }

    function LK(OO, KO) {
      return XK[0] = oK(OO, KO), XK[1] = oK(OO, KO), eK[0]
    }

    function QK(OO, KO) {
      const pO = FK(OO, KO);
      return oK(OO, KO) * Math.pow(2, 32) + pO
    }

    function zp(OO, KO) {
      const pO = FK(OO, KO);
      return FK(OO, KO) * Math.pow(2, 32) + pO
    }
    const AK = {
        utf8Read: CK,
        int8: hK,
        uint8: DK,
        int16: MK,
        uint16: ap,
        int32: oK,
        uint32: FK,
        float32: VK,
        float64: LK,
        int64: QK,
        uint64: zp,
        bigint64: function(OO, KO) {
          return XK[0] = oK(OO, KO), XK[1] = oK(OO, KO), vp[0]
        },
        biguint64: function(OO, KO) {
          return XK[0] = oK(OO, KO), XK[1] = oK(OO, KO), lK[0]
        },
        boolean: function(OO, KO) {
          return DK(OO, KO) > 0
        },
        string: function(OO, KO) {
          const pO = OO[KO.offset++];
          let XO;
          return pO < 192 ? XO = 31 & pO : 217 === pO ? XO = DK(OO, KO) : 218 === pO ? XO = ap(OO, KO) : 219 === pO && (XO = FK(OO, KO)), CK(OO, KO, XO)
        },
        number: function(OO, KO) {
          const pO = OO[KO.offset++];
          return pO < 128 ? pO : 202 === pO ? VK(OO, KO) : 203 === pO ? LK(OO, KO) : 204 === pO ? DK(OO, KO) : 205 === pO ? ap(OO, KO) : 206 === pO ? FK(OO, KO) : 207 === pO ? zp(OO, KO) : 208 === pO ? hK(OO, KO) : 209 === pO ? MK(OO, KO) : 210 === pO ? oK(OO, KO) : 211 === pO ? QK(OO, KO) : pO > 223 ? -1 * (255 - pO + 1) : void 0
        },
        stringCheck: function(OO, KO) {
          const pO = OO[KO.offset];
          return pO < 192 && pO > 160 || 217 === pO || 218 === pO || 219 === pO
        }
      },
      fK = {},
      dK = new Map;

    function TK(OO, KO) {
      KO.constructor && (Object.prototype.hasOwnProperty.call(KO, "constructor") && null == KO.constructor[Symbol.metadata] && eO(KO.constructor), dK.set(KO.constructor, OO), fK[OO] = KO), KO.encode && (KK[OO] = KO.encode), KO.decode && (AK[OO] = KO.decode)
    }

    function NK(OO) {
      for (const KO in OO) TK(KO, OO[KO]);
      return OO => fX(OO)
    }
    const IK = "ArraySchema does not support streaming \u2014 positional ops (splice / unshift / reverse) shift subsequent indexes, so holding ADDs back for a later tick under `maxPerTick` would desync the decoder. Use `t.stream(X)` (stable monotonic positions) or `t.map(X).stream()` (stable keys) instead.";

    function yp() {
      return {
        pendingByView: new Map,
        sentByView: new Map,
        broadcastPending: new Set,
        sentBroadcast: new Set,
        broadcastDeletes: new Set,
        maxPerTick: 32
      }
    }

    function gp(OO) {
      return OO._stream ??= yp()
    }

    function uK(OO, KO, pO) {
      0 === KO.activeViews.size && gp(OO).broadcastPending.add(pO)
    }

    function EK(OO, KO, pO, XO) {
      const eO = OO._stream;
      if (void 0 === eO) return !0;
      let lO = !1;
      return eO.broadcastPending.delete(XO) ? lO = !0 : eO.sentBroadcast.delete(XO) && eO.broadcastDeletes.add(XO), KO.forEachActiveView((OO => {
        const KO = eO.pendingByView.get(OO.id);
        if (KO?.has(XO)) return KO.delete(XO), void(lO = !0);
        const vK = eO.sentByView.get(OO.id);
        if (vK?.has(XO)) {
          vK.delete(XO);
          let KO = OO.changes.get(pO);
          void 0 === KO && (KO = new Map, OO.changes.set(pO, KO)), KO.set(XO, bK.DELETE)
        }
      })), lO
    }

    function jp(OO, KO) {
      const pO = OO._stream?.pendingByView;
      if (void 0 === pO) return !1;
      for (const [XO, bK] of pO)
        if (bK.size > 0 && void 0 !== KO.activeViews.get(XO)?.deref()) return !0;
      return !1
    }

    function YK(OO) {
      const KO = OO._stream;
      return void 0 !== KO && (KO.broadcastPending.size > 0 || KO.broadcastDeletes.size > 0)
    }

    function wK(OO, KO, pO) {
      const XO = gp(OO);
      let bK = XO.pendingByView.get(KO);
      void 0 === bK && (bK = new Set, XO.pendingByView.set(KO, bK)), bK.add(pO)
    }

    function ip(OO, KO) {
      const pO = OO._stream;
      void 0 !== pO && (pO.pendingByView.delete(KO), pO.sentByView.delete(KO), pO.priorityByView?.delete(KO))
    }
    const rp = {
      8: "uint8",
      16: "uint16",
      32: "uint32"
    };

    function PK(OO) {
      if (null == OO || "object" !== typeof OO) throw new Error("t.quantized(): options object with { min, max } is required.");
      const {
        min: KO,
        max: pO
      } = OO;
      if ("number" !== typeof KO || "number" !== typeof pO || !(pO > KO) || !Number.isFinite(KO) || !Number.isFinite(pO)) throw new Error(`t.quantized(): require finite min < max (got min=${KO}, max=${pO}).`);
      const XO = OO.bits ?? 16;
      if (8 !== XO && 16 !== XO && 32 !== XO) throw new Error(`t.quantized(): bits must be 8, 16 or 32 (got ${XO}).`);
      const bK = OO.mode ?? "clamp";
      if ("clamp" !== bK && "wrap" !== bK) throw new Error(`t.quantized(): mode must be "clamp" or "wrap" (got ${JSON.stringify(bK)}).`);
      const eO = "wrap" === bK,
        lO = Math.pow(2, XO);
      return {
        min: KO,
        max: pO,
        bits: XO,
        wrap: eO,
        wire: rp[XO],
        range: pO - KO,
        span: eO ? lO : KO === -pO ? lO - 2 : lO - 1
      }
    }

    function mp(OO) {
      return null !== OO && "object" === typeof OO && void 0 !== OO.quantized
    }

    function sK(OO, KO) {
      if (OO.wrap) {
        if (!Number.isFinite(KO)) return 0;
        const pO = OO.range;
        let XO = (KO - OO.min) % pO;
        XO < 0 && (XO += pO);
        const bK = OO.span;
        return Math.floor(XO / pO * bK + .5) % bK
      }
      if (KO !== KO) return 0;
      const pO = KO < OO.min ? OO.min : KO > OO.max ? OO.max : KO;
      return Math.floor((pO - OO.min) / OO.range * OO.span + .5)
    }

    function HK(OO, KO) {
      return OO.min + KO / OO.span * OO.range
    }

    function RK(OO) {
      const KO = KK[OO.wire];
      return (pO, XO, bK) => KO(pO, sK(OO, XO), bK)
    }
    class SK {
      types = {};
      schemas = new Map;
      hasFilters = !1;
      static inheritedTypes = new WeakMap;
      static cachedContexts = new WeakMap;
      static register(OO) {
        const KO = Object.getPrototypeOf(OO);
        if (KO !== EX) {
          let pO = SK.inheritedTypes.get(KO);
          pO || (pO = new Set, SK.inheritedTypes.set(KO, pO)), pO.add(OO)
        }
      }
      static cache(OO) {
        let KO = SK.cachedContexts.get(OO);
        return KO || (KO = new SK(OO), SK.cachedContexts.set(OO, KO)), KO
      }
      constructor(OO) {
        OO && this.discoverTypes(OO)
      }
      has(OO) {
        return this.schemas.has(OO)
      }
      get(OO) {
        return this.types[OO]
      }
      add(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.schemas.size;
        return !this.schemas.has(OO) && (this.types[KO] = OO, null == OO[Symbol.metadata] && xp.initialize(OO), this.schemas.set(OO, KO), !0)
      }
      getTypeId(OO) {
        return this.schemas.get(OO)
      }
      discoverTypes(OO) {
        if (!this.add(OO)) return;
        SK.inheritedTypes.get(OO)?.forEach((OO => {
          this.discoverTypes(OO)
        }));
        let KO = OO;
        for (;
          (KO = Object.getPrototypeOf(KO)) && KO !== EX && KO !== Function.prototype;) this.discoverTypes(KO);
        const pO = OO[Symbol.metadata];
        (pO[EO] || pO[PO]) && (this.hasFilters = !0);
        for (const XO in pO) {
          const OO = pO[XO].type;
          if ("string" !== typeof OO && !mp(OO))
            if ("function" === typeof OO) this.discoverTypes(OO);
            else {
              const KO = Object.values(OO)[0];
              if ("string" === typeof KO) continue;
              this.discoverTypes(KO)
            }
        }
      }
      debug() {
        return `TypeContext ->\n\tSchema types: ${this.schemas.size}\n\thasFilters: ${this.hasFilters}`
      }
    }

    function JK(OO) {
      const KO = BK(OO);
      return KO ? {
        complexTypeKlass: fK[KO],
        childType: OO[KO]
      } : {
        complexTypeKlass: !1,
        childType: OO
      }
    }

    function cp(OO, KO) {
      const pO = ZK(OO),
        XO = BK(pO),
        bK = XO && BK(pO[XO]);
      if (bK) throw new Error(`${KO?`${KO}: `:""}@colyseus/schema: nested collections are not supported ("${XO}" of "${bK}"). Collections can only hold primitive types or Schema classes, wrap the inner ${bK} in a Schema class.`);
      return pO
    }

    function BK(OO) {
      return "object" === typeof OO && null !== OO ? Object.keys(OO).find((OO => void 0 !== fK[OO])) : void 0
    }

    function ZK(OO) {
      if ("object" !== typeof OO || null === OO) return OO;
      if (Array.isArray(OO)) return {
        array: ZK(OO[0])
      };
      const KO = function(OO) {
        const KO = Object.keys(OO),
          pO = KO.filter((OO => /\d+/.test(OO)));
        if (pO.length > 0 && pO.length === KO.length / 2 && OO[OO[pO[0]]] == pO[0]) return "number";
        if (KO.length > 0 && KO.every((KO => OO[KO] === KO))) return "string"
      }(OO);
      if (KO) return KO;
      if (mp(OO)) return "string" === typeof OO.quantized.wire ? OO : {
        quantized: PK(OO.quantized)
      };
      if (void 0 !== OO.type) return ZK(OO.type);
      const pO = BK(OO);
      return pO && (OO[pO] = ZK(OO[pO])), OO
    }
    const GK = [uO, YO, wO, iK, rK, PO, yK];

    function qp(OO, KO, pO) {
      OO[KO] || Object.defineProperty(OO, KO, {
        value: [],
        enumerable: !1,
        configurable: !0,
        writable: !0
      }), OO[KO].push(pO)
    }
    const xp = {
        addField(OO, KO, pO, XO, bK) {
          if (KO >= 63) throw new Error(`Can't define field '${pO}'.\nSchema instances may only have up to 63 fields.`);
          OO[KO] = Object.assign(OO[KO] || {}, {
            type: XO,
            index: KO,
            name: pO
          }), Object.defineProperty(OO, NO, {
            value: OO[NO] || {},
            enumerable: !1,
            configurable: !0
          }), OO[NO][pO] = bK || {
            value: void 0,
            writable: !0,
            enumerable: !0,
            configurable: !0
          }, Object.defineProperty(OO, gK, {
            value: KO,
            enumerable: !1,
            configurable: !0
          }), Object.defineProperty(OO, pO, {
            value: KO,
            enumerable: !1,
            configurable: !0
          }), "string" === typeof OO[KO].type || mp(OO[KO].type) || (void 0 === OO[uO] && Object.defineProperty(OO, uO, {
            value: [],
            enumerable: !1,
            configurable: !0
          }), OO[uO].push(KO));
          const eO = OO[KO].type;
          if (eO && "object" === typeof eO && void 0 !== eO.stream) {
            if (void 0 !== eO.array) throw new Error(IK);
            OO[KO].stream = !0, OO[PO] || Object.defineProperty(OO, PO, {
              value: [],
              enumerable: !1,
              configurable: !0,
              writable: !0
            }), OO[PO].includes(KO) || OO[PO].push(KO);
            const bK = XO?.priority;
            "function" === typeof bK && xp.setStreamPriority(OO, pO, bK)
          }
        },
        setTag(OO, KO, pO) {
          const XO = OO[KO];
          if (OO[XO].tag = pO, OO[EO] || (Object.defineProperty(OO, EO, {
              value: [],
              enumerable: !1,
              configurable: !0
            }), Object.defineProperty(OO, jK, {
              value: {},
              enumerable: !1,
              configurable: !0
            })), OO[EO].push(XO), pO < 0) OO[jK][pO] || (OO[jK][pO] = []), OO[jK][pO].push(XO);
          else
            for (let bK = pO; bK > 0; bK &= bK - 1) {
              const KO = bK & -bK;
              OO[jK][KO] || (OO[jK][KO] = []), OO[jK][KO].push(XO)
            }
        },
        setUnreliable(OO, KO) {
          const pO = OO[KO];
          if ("string" !== typeof OO[pO].type) throw new Error(`@unreliable cannot be applied to ref-type field "${KO}". For ref-type fields, mark each primitive sub-field with @unreliable instead. See README "Limitations and best practices".`);
          OO[pO].unreliable = !0, OO[YO] || Object.defineProperty(OO, YO, {
            value: [],
            enumerable: !1,
            configurable: !0,
            writable: !0
          }), OO[YO].push(pO)
        },
        setPatchOnly(OO, KO) {
          const pO = OO[KO];
          if (OO[pO].fullStateOnly) throw new Error(`field "${KO}" cannot be both patchOnly and fullStateOnly \u2014 those are the only two delivery channels, so the field would never reach a client.`);
          OO[pO].patchOnly = !0, qp(OO, wO, pO), qp(OO, iK, pO)
        },
        setDeprecated(OO, KO) {
          const pO = OO[KO];
          OO[pO].deprecated = !0, qp(OO, iK, pO), Object.defineProperty(OO, pO, {
            value: OO[pO],
            enumerable: !1,
            configurable: !0
          })
        },
        setFullStateOnly(OO, KO) {
          const pO = OO[KO];
          if (OO[pO].patchOnly) throw new Error(`field "${KO}" cannot be both patchOnly and fullStateOnly \u2014 those are the only two delivery channels, so the field would never reach a client.`);
          OO[pO].fullStateOnly = !0, qp(OO, rK, pO)
        },
        setStream(OO, KO) {
          const pO = OO[KO];
          OO[pO].stream = !0, OO[PO] || Object.defineProperty(OO, PO, {
            value: [],
            enumerable: !1,
            configurable: !0,
            writable: !0
          }), OO[PO].push(pO)
        },
        setStreamPriority(OO, KO, pO) {
          const XO = OO[KO];
          OO[mK] || Object.defineProperty(OO, mK, {
            value: {},
            enumerable: !1,
            configurable: !0,
            writable: !0
          }), OO[mK][XO] = pO
        },
        getStreamPriority: (OO, KO) => OO?.[mK]?.[KO],
        defineField(OO, KO, pO, XO, bK) {
          const eO = cp(bK, `${OO.name}.${XO}`),
            {
              complexTypeKlass: lO,
              childType: vK
            } = JK(eO);
          xp.addField(KO, pO, XO, eO, TX(XO, pO, vK, lO)), KO[NO][XO] && Object.defineProperty(OO.prototype, XO, KO[NO][XO]), ("string" === typeof eO || mp(eO)) && (KO[yK] || Object.defineProperty(KO, yK, {
            value: [],
            enumerable: !1,
            configurable: !0,
            writable: !0
          }), KO[yK][pO] = "string" === typeof eO ? KK[eO] : RK(eO.quantized))
        },
        setFields(OO, KO) {
          const pO = OO.prototype.constructor;
          SK.register(pO);
          const XO = Object.getPrototypeOf(pO),
            bK = XO && XO[Symbol.metadata],
            eO = xp.initialize(pO);
          pO[CO] || (pO[CO] = EX[CO]), pO[hO] || (pO[hO] = EX[hO]), pO[DO] || (pO[DO] = EX[DO]), pO.prototype.toJSON || (pO.prototype.toJSON = EX.prototype.toJSON);
          let lO = eO[gK] ?? (bK && bK[gK]) ?? -1;
          lO++, eO[yK] || Object.defineProperty(eO, yK, {
            value: bK?.[yK] ? [...bK[yK]] : [],
            enumerable: !1,
            configurable: !0,
            writable: !0
          });
          for (const vK in KO) {
            if (void 0 !== eO[vK]) throw new Error(`@colyseus/schema: Duplicate '${vK}' definition on '${pO.name||"(anonymous)"}'.`);
            xp.defineField(pO, eO, lO, vK, KO[vK]), lO++
          }
          return OO
        },
        isDeprecated: (OO, KO) => !0 === OO[KO].deprecated,
        initialize(OO) {
          const KO = Object.getPrototypeOf(OO),
            pO = KO[Symbol.metadata];
          let XO = OO[Symbol.metadata] ?? Object.create(null);
          if (KO !== EX && XO === pO && (XO = Object.create(null), pO)) {
            Object.setPrototypeOf(XO, pO), Object.defineProperty(XO, gK, {
              value: pO[gK],
              enumerable: !1,
              configurable: !0,
              writable: !0
            }), void 0 !== pO[EO] && (Object.defineProperty(XO, EO, {
              value: [...pO[EO]],
              enumerable: !1,
              configurable: !0,
              writable: !0
            }), Object.defineProperty(XO, jK, {
              value: {
                ...pO[jK]
              },
              enumerable: !1,
              configurable: !0,
              writable: !0
            }));
            for (const OO of GK) {
              const KO = pO[OO];
              void 0 !== KO && Object.defineProperty(XO, OO, {
                value: [...KO],
                enumerable: !1,
                configurable: !0,
                writable: !0
              })
            }
            Object.defineProperty(XO, NO, {
              value: {
                ...pO[NO]
              },
              enumerable: !1,
              configurable: !0,
              writable: !0
            })
          }
          return Object.defineProperty(OO, Symbol.metadata, {
            value: XO,
            writable: !1,
            configurable: !0
          }), XO
        },
        isValidInstance: OO => OO.constructor[Symbol.metadata] && Object.prototype.hasOwnProperty.call(OO.constructor[Symbol.metadata], gK),
        getFields(OO) {
          const KO = OO[Symbol.metadata],
            pO = {};
          for (let XO = 0; XO <= KO[gK]; XO++) pO[KO[XO].name] = KO[XO].type;
          return pO
        },
        hasViewTagAtIndex: (OO, KO) => OO?.[EO]?.includes(KO),
        hasUnreliableAtIndex: (OO, KO) => OO?.[YO]?.includes(KO),
        hasPatchOnlyAtIndex: (OO, KO) => OO?.[wO]?.includes(KO),
        hasFullStateOnlyAtIndex: (OO, KO) => OO?.[rK]?.includes(KO),
        hasStreamAtIndex: (OO, KO) => OO?.[PO]?.includes(KO)
      },
      nK = (OO, KO, pO) => OO(KO, pO);
    class WK {
      dirtyLow = 0;
      dirtyHigh = 0;
      ops;
      constructor(OO) {
        this.ops = new Uint8Array(Math.max(OO + 1, 1))
      }
      record(OO, KO) {
        const pO = this.ops[OO];
        0 === pO ? this.ops[OO] = KO : (pO === bK.DELETE || pO === bK.ADD && KO === bK.DELETE_AND_ADD) && (this.ops[OO] = bK.DELETE_AND_ADD), OO < 32 ? this.dirtyLow |= 1 << OO : this.dirtyHigh |= 1 << OO - 32
      }
      recordDelete(OO, KO) {
        this.ops[OO] = KO, OO < 32 ? this.dirtyLow |= 1 << OO : this.dirtyHigh |= 1 << OO - 32
      }
      recordRaw(OO, KO) {
        this.record(OO, KO)
      }
      operationAt(OO) {
        const KO = this.ops[OO];
        return 0 === KO ? void 0 : KO
      }
      setOperationAt(OO, KO) {
        this.ops[OO] = KO
      }
      forEach(OO) {
        this.forEachWithCtx(OO, nK)
      }
      forEachWithCtx(OO, KO) {
        let pO = this.dirtyLow,
          XO = this.dirtyHigh;
        const bK = this.ops;
        for (; 0 !== pO;) {
          const XO = pO & -pO,
            eO = 31 - Math.clz32(XO);
          pO ^= XO, KO(OO, eO, bK[eO])
        }
        for (; 0 !== XO;) {
          const pO = XO & -XO,
            eO = 31 - Math.clz32(pO) + 32;
          XO ^= pO, KO(OO, eO, bK[eO])
        }
      }
      size() {
        return kp(this.dirtyLow) + kp(this.dirtyHigh)
      }
      has() {
        return 0 !== (this.dirtyLow | this.dirtyHigh)
      }
      reset() {
        this.dirtyLow = 0, this.dirtyHigh = 0, this.ops.fill(0)
      }
    }
    class tp {
      Kb = new Map;
      pureOps = [];
      record(OO, KO) {
        const pO = this.Kb.get(OO);
        void 0 === pO ? this.Kb.set(OO, KO) : (pO === bK.DELETE || pO === bK.ADD && KO === bK.DELETE_AND_ADD) && this.Kb.set(OO, bK.DELETE_AND_ADD)
      }
      recordDelete(OO, KO) {
        this.Kb.set(OO, KO)
      }
      recordRaw(OO, KO) {
        this.Kb.set(OO, KO)
      }
      recordPure(OO) {
        this.pureOps.push([this.Kb.size, OO])
      }
      operationAt(OO) {
        return this.Kb.get(OO)
      }
      setOperationAt(OO, KO) {
        this.Kb.has(OO) && this.Kb.set(OO, KO)
      }
      forEach(OO) {
        this.forEachWithCtx(OO, nK)
      }
      forEachWithCtx(OO, KO) {
        const pO = this.pureOps;
        if (pO.length > 0) {
          let XO = 0,
            bK = 0;
          for (const [eO, lO] of this.Kb) {
            for (; XO < pO.length && pO[XO][0] <= bK;) {
              const bK = pO[XO++][1];
              KO(OO, -bK, bK)
            }
            KO(OO, eO, lO), bK++
          }
          for (; XO < pO.length;) {
            const bK = pO[XO++][1];
            KO(OO, -bK, bK)
          }
        } else
          for (const [XO, bK] of this.Kb) KO(OO, XO, bK)
      }
      size() {
        return this.Kb.size + this.pureOps.length
      }
      has() {
        return this.Kb.size > 0 || this.pureOps.length > 0
      }
      reset() {
        this.Kb.clear(), this.pureOps.length = 0
      }
      shift(OO) {
        const KO = new Map;
        for (const [pO, XO] of this.Kb) KO.set(pO + OO, XO);
        this.Kb = KO
      }
    }

    function kp(OO) {
      return 16843009 * ((OO = (858993459 & (OO -= OO >>> 1 & 1431655765)) + (OO >>> 2 & 858993459)) + (OO >>> 4) & 252645135) >>> 24
    }

    function UK(OO) {
      if (void 0 === OO) return 0;
      let KO = 0;
      for (let pO = 0, XO = OO.length; pO < XO; pO++) {
        const XO = OO[pO];
        XO < 32 && (KO |= 1 << XO)
      }
      return KO
    }

    function Op(OO) {
      const KO = OO.constructor;
      if (Object.prototype.hasOwnProperty.call(KO, IO)) return KO[IO];
      const pO = KO[Symbol.metadata],
        XO = xp.isValidInstance(OO),
        bK = (pO?.[EO]?.length ?? 0) > 0,
        eO = function(OO) {
          const KO = [],
            pO = [],
            XO = [],
            bK = [],
            eO = OO?.[gK];
          if (void 0 === eO) return {
            names: KO,
            types: pO,
            tags: XO,
            encoders: bK
          };
          const lO = OO[yK];
          for (let vK = 0; vK <= eO; vK++) {
            const eO = OO[vK];
            void 0 !== eO ? (KO[vK] = eO.name, pO[vK] = eO.type, XO[vK] = eO.tag, bK[vK] = lO?.[vK]) : (KO[vK] = void 0, pO[vK] = void 0, XO[vK] = void 0, bK[vK] = void 0)
          }
          return {
            names: KO,
            types: pO,
            tags: XO,
            encoders: bK
          }
        }(pO),
        lO = XO && !bK ? void 0 : KO[MO],
        vK = {
          encoder: KO[hO],
          filter: lO,
          metadata: pO,
          isSchema: XO,
          filterBitmask: XO ? UK(pO?.[EO]) : 0,
          hasAnyFullStateOnly: (pO?.[rK]?.length ?? 0) > 0,
          hasAnyUnreliable: (pO?.[YO]?.length ?? 0) > 0,
          hasAnyStream: (pO?.[PO]?.length ?? 0) > 0,
          hasAnyView: bK,
          fullStateOnlyBitmask: UK(pO?.[rK]),
          unreliableBitmask: UK(pO?.[YO]),
          streamBitmask: UK(pO?.[PO]),
          names: eO.names,
          types: eO.types,
          tags: eO.tags,
          encoders: eO.encoders
        };
      return Object.defineProperty(KO, IO, {
        value: vK,
        enumerable: !1,
        writable: !0,
        configurable: !0
      }), vK
    }

    function Kp(OO, KO) {
      if (void 0 !== OO.parentRef && KO(OO.parentRef, OO._parentIndex)) return !0;
      for (let pO = OO.extraParents; void 0 !== pO; pO = pO.next)
        if (KO(pO.ref, pO.index)) return !0;
      return !1
    }
    const pp = (OO, KO) => {
        OO.isFieldUnreliable(KO) ? OO.ensureUnreliableRecorder().record(KO, bK.ADD) : OO.record(KO, bK.ADD)
      },
      Xp = (OO, KO) => OO(KO);

    function bX(OO, KO, pO) {
      const XO = OO.refTarget;
      if (void 0 !== XO[LO]) {
        if (OO.isPatchOnly) return;
        if (Array.isArray(XO.items)) {
          const OO = XO.items;
          for (let XO = 0, bK = OO.length; XO < bK; XO++) void 0 !== OO[XO] && pO(KO, XO)
        } else if (void 0 !== XO.journal)
          for (const [OO, bK] of XO.journal.keyByIndex) XO.$items.has(bK) && pO(KO, OO);
        else if (void 0 !== XO.$items)
          for (const OO of XO.$items.keys()) pO(KO, OO)
      } else {
        const bK = OO.metadata;
        if (!bK) return;
        const eO = bK[gK] ?? -1,
          lO = bK[iK],
          vK = OO.encDescriptor.names;
        for (let OO = 0; OO <= eO; OO++) {
          const bK = vK[OO];
          if (void 0 === bK) continue;
          if (lO && lO.includes(OO)) continue;
          const eO = XO[bK];
          void 0 !== eO && null !== eO && pO(KO, OO)
        }
      }
    }

    function ep(OO, KO, pO, XO) {
      ! function(OO, KO, pO) {
        if (!KO) return;
        const XO = KO[VO],
          bK = !XO._isSchema;
        let eO;
        bK ? (KO = XO.parent, pO = XO.parentIndex, eO = KO?.[VO].metadata) : eO = XO.metadata;
        const lO = (eO?.[wO]?.includes(pO) ? Ip : 0) | (eO?.[rK]?.includes(pO) ? yX : 0),
          vK = XO.flags & Ep | lO,
          CO = OO.flags;
        OO.flags = CO | vK;
        vK & ~CO & yX && (OO.reset(), OO.unreliableRecorder?.reset());
        const hO = OO.root?.types;
        if (!hO?.hasFilters) return;
        const DO = eO?.[EO]?.includes(pO) ?? !1,
          MO = eO?.[PO]?.includes(pO) ?? !1,
          aK = XO.isFiltered || DO || MO;
        if (OO.isFiltered = aK, MO && !bK) {
          OO.isStreamCollection = !0;
          const KO = gp(OO.ref);
          if (void 0 === KO.priority) {
            const OO = xp.getStreamPriority(eO, pO);
            void 0 !== OO && (KO.priority = OO)
          }
          OO.root?.registerStream(OO.ref)
        }
        if (aK) {
          const KO = vX(OO);
          OO.isVisibilitySharedWithParent = XO.isFiltered && KO && !MO && (!DO || bK && eO[pO].tag !== FX)
        }
      }(OO, KO, pO), OO.isFullStateOnly || (OO.has() && OO.root?.enqueueChangeTree(OO), OO.unreliableRecorder?.has() && OO.root?.enqueueUnreliable(OO), OO.has() || OO.unreliableRecorder?.has() || OO.root?.enqueueChangeTree(OO))
    }

    function lp(OO) {
      const KO = OO.pendingFilterRefresh;
      for (let pO = 0; pO < KO.length; pO++) {
        const OO = KO[pO];
        0 !== (OO.flags & upO) && Cp(OO)
      }
      KO.length = 0
    }

    function vX(OO) {
      return OO._isSchema || "string" !== typeof OO.refTarget[LO]
    }

    function Cp(OO) {
      OO.flags &= ~upO;
      const KO = OO.root;
      if (void 0 === KO || void 0 === OO.parentRef) return;
      const pO = vX(OO);
      let XO = op(OO, OO.parentRef, OO._parentIndex, pO);
      for (let eO = OO.extraParents; void 0 !== eO && XO !== aX; eO = eO.next) XO |= op(OO, eO.ref, eO.index, pO);
      if (0 === XO) return;
      OO.isVisibilitySharedWithParent = 0 !== (XO & Mp);
      const bK = 0 === (XO & Dp);
      bK !== OO.isFiltered && (OO.isFiltered = bK, bK || OO.isFullStateOnly || (OO.forEachLiveWithCtx(OO, pp), OO.has() && KO.enqueueChangeTree(OO), OO.unreliableRecorder?.has() && KO.enqueueUnreliable(OO)), OO.forEachChildWithCtx(OO, Fp))
    }
    const hp = 1,
      Dp = 2,
      Mp = 4,
      aX = hp | Dp | Mp;

    function op(OO, KO, pO, XO) {
      const bK = KO[VO];
      if (bK.root !== OO.root || ! function(OO, KO, pO) {
          const XO = KO.refTarget;
          if (KO.isArray) {
            const KO = XO.items,
              bK = KO[pO];
            if (void 0 !== bK && bK[VO] === OO) return !0;
            for (let pO = 0, XO = KO.length; pO < XO; pO++) {
              const XO = KO[pO];
              if (void 0 !== XO && XO[VO] === OO) return !0
            }
            return !1
          }
          const bK = KO.getValue(pO);
          return void 0 !== bK && bK[VO] === OO
        }(OO, bK, pO)) return 0;
      bK.flags & upO && Cp(bK);
      let eO = hp;
      if (bK._isSchema) {
        void 0 !== bK.encDescriptor.tags[pO] || bK.isFieldStream(pO) || (bK.isFiltered ? XO && (eO |= Mp) : eO |= Dp)
      } else if (bK.isFiltered) {
        if (XO && !bK.isStreamCollection) {
          const OO = bK.parent?.[VO];
          (OO?._isSchema ? OO.encDescriptor.tags[bK.parentIndex] : void 0) !== FX && (eO |= Mp)
        }
      } else eO |= Dp;
      return eO
    }
    const Fp = (OO, KO, pO) => {
      Cp(KO)
    };

    function Vp(OO, KO, pO, XO) {
      if (OO.addParent(KO, XO), !pO) return;
      const bK = pO.add(OO);
      pO !== OO.root && (OO.root = pO, ep(OO, KO, XO));
      const eO = KO?.[VO];
      if (void 0 !== eO && void 0 !== eO.subscribedViews && void 0 !== KO[LO] && function(OO, KO, pO, XO) {
          const bK = OO.subscribedViews;
          if (void 0 === bK) return;
          const eO = OO.isStreamCollection,
            lO = eO ? OO.ref : void 0,
            vK = eO ? void 0 : pO[VO];
          for (let CO = 0, hO = bK.length; CO < hO; CO++) {
            let OO = bK[CO];
            for (; 0 !== OO;) {
              const pO = OO & -OO;
              OO ^= pO;
              const hO = 32 * CO + (31 - Math.clz32(pO)),
                DO = XO.activeViews.get(hO),
                MO = DO?.deref();
              void 0 !== MO ? eO ? wK(lO, hO, KO) : void 0 !== vK && MO.markVisible(vK) : bK[CO] &= ~pO
            }
          }
        }(eO, XO, OO.ref, pO), bK) {
        let KO = Ap[fp];
        void 0 === KO && (KO = {
          parentRef: void 0,
          root: void 0
        }, Ap[fp] = KO), KO.parentRef = OO.ref, KO.root = pO, fp++, Qp(OO, KO, dp), fp--
      }
    }

    function Lp(OO, KO, pO) {
      OO(KO, pO)
    }

    function Qp(OO, KO, pO) {
      const XO = OO.refTarget;
      if (XO[LO]) {
        if ("string" !== typeof XO[LO]) {
          const OO = XO.items;
          if (void 0 !== OO)
            for (let XO = 0, bK = OO.length; XO < bK; XO++) {
              const bK = OO[XO];
              bK && pO(KO, bK[VO], XO)
            } else {
              const OO = XO.$items,
                bK = XO._collectionIndexes;
              for (const XO of OO.keys()) {
                const eO = OO.get(XO);
                eO && pO(KO, eO[VO], bK?.[XO] ?? XO)
              }
            }
        }
      } else {
        const bK = OO.metadata,
          eO = bK?.[uO];
        if (!eO) return;
        const lO = OO.encDescriptor.names;
        for (let OO = 0, vK = eO.length; OO < vK; OO++) {
          const bK = eO[OO],
            vK = XO[lO[bK]];
          vK && pO(KO, vK[VO], bK)
        }
      }
    }

    function zX(OO, KO, pO) {
      KO.root !== OO ? KO.setRoot(OO) : OO.add(KO)
    }
    const Ap = [];
    let fp = 0;

    function dp(OO, KO, pO) {
      if (KO.root === OO.root) return OO.root.add(KO), void OO.root.moveNextToParent(KO);
      KO.setParent(OO.parentRef, OO.root, pO)
    }

    function Tp(OO, KO, pO) {
      const XO = (3 & pO) << 3;
      return pO < 4 ? OO >>> XO & 255 : KO >>> XO & 255
    }
    const Np = (OO, KO, pO) => OO(KO, pO);
    const Ip = 16,
      yX = 32,
      gX = 128,
      upO = 256,
      Ep = Ip | yX;
    class jX {
      ref;
      refTarget;
      get isArray() {
        return this.refTarget !== this.ref
      }
      metadata;
      encDescriptor;
      root;
      parentRef;
      _parentIndex;
      extraParents;
      flags = 4;
      refCount = 0;
      _fullSyncGen = 0;
      _isSchema = !1;
      dirtyLow = 0;
      dirtyHigh = 0;
      opsLow = 0;
      opsHigh = 0;
      ops;
      collDirty;
      collPureOps;
      unreliableRecorder;
      paused = !1;
      changesNode;
      unreliableChangesNode;
      visibleViews;
      tagViews;
      subscribedViews;
      get isFiltered() {
        return 0 !== (1 & this.flags)
      }
      set isFiltered(OO) {
        this.flags = OO ? 1 | this.flags : -2 & this.flags
      }
      get isVisibilitySharedWithParent() {
        return 0 !== (2 & this.flags)
      }
      set isVisibilitySharedWithParent(OO) {
        this.flags = OO ? 2 | this.flags : -3 & this.flags
      }
      get isNew() {
        return 0 !== (4 & this.flags)
      }
      set isNew(OO) {
        this.flags = OO ? 4 | this.flags : -5 & this.flags
      }
      get isUnreliable() {
        return 0 !== (8 & this.flags)
      }
      set isUnreliable(OO) {
        this.flags = OO ? 8 | this.flags : -9 & this.flags
      }
      get isPatchOnly() {
        return 0 !== (this.flags & Ip)
      }
      set isPatchOnly(OO) {
        this.flags = OO ? this.flags | Ip : this.flags & ~Ip
      }
      get isFullStateOnly() {
        return 0 !== (this.flags & yX)
      }
      set isFullStateOnly(OO) {
        this.flags = OO ? this.flags | yX : this.flags & ~yX
      }
      get isStreamCollection() {
        return 0 !== (64 & this.flags)
      }
      set isStreamCollection(OO) {
        this.flags = OO ? 64 | this.flags : -65 & this.flags
      }
      get needsRestage() {
        return 0 !== (this.flags & gX)
      }
      set needsRestage(OO) {
        this.flags = OO ? this.flags | gX : -129 & this.flags
      }
      get hasFilteredFields() {
        return this.isFiltered || this.encDescriptor.hasAnyView
      }
      ensureUnreliableRecorder() {
        return void 0 === this.unreliableRecorder && (this.unreliableRecorder = this._isSchema ? new WK(this.metadata?.[gK] ?? 0) : new tp), this.unreliableRecorder
      }
      isFieldUnreliable(OO) {
        const KO = this.encDescriptor;
        return !!KO.hasAnyUnreliable && (OO < 32 ? 0 !== (KO.unreliableBitmask & 1 << OO) : xp.hasUnreliableAtIndex(this.metadata, OO))
      }
      isFieldFullStateOnly(OO) {
        if (this.isFullStateOnly) return !0;
        const KO = this.encDescriptor;
        return !!KO.hasAnyFullStateOnly && (OO < 32 ? 0 !== (KO.fullStateOnlyBitmask & 1 << OO) : xp.hasFullStateOnlyAtIndex(this.metadata, OO))
      }
      isFieldStream(OO) {
        const KO = this.encDescriptor;
        return !!KO.hasAnyStream && (OO < 32 ? 0 !== (KO.streamBitmask & 1 << OO) : xp.hasStreamAtIndex(this.metadata, OO))
      }
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO;
        this.ref = OO, this.refTarget = KO;
        const pO = Op(OO);
        this.encDescriptor = pO, this.metadata = pO.metadata;
        const XO = pO.isSchema;
        if (this._isSchema = XO, this.ops = void 0, this.collDirty = void 0, this.collPureOps = void 0, XO) {
          const OO = this.metadata?.[gK] ?? 0;
          OO > 7 && (this.ops = new Uint8Array(OO + 1))
        } else this.collDirty = new Map
      }
      _opAt(OO) {
        const KO = this.ops;
        if (void 0 !== KO) return KO[OO];
        const pO = (3 & OO) << 3;
        return OO < 4 ? this.opsLow >>> pO & 255 : this.opsHigh >>> pO & 255
      }
      _opPut(OO, KO) {
        const pO = this.ops;
        if (void 0 !== pO) return void(pO[OO] = KO);
        const XO = (3 & OO) << 3,
          bK = ~(255 << XO);
        OO < 4 ? this.opsLow = this.opsLow & bK | KO << XO : this.opsHigh = this.opsHigh & bK | KO << XO
      }
      _markDirty(OO) {
        OO < 32 ? this.dirtyLow |= 1 << OO : this.dirtyHigh |= 1 << OO - 32
      }
      record(OO, KO) {
        if (this._isSchema) {
          const pO = this._opAt(OO);
          0 === pO ? this._opPut(OO, KO) : (pO === bK.DELETE || pO === bK.ADD && KO === bK.DELETE_AND_ADD) && this._opPut(OO, bK.DELETE_AND_ADD), this._markDirty(OO)
        } else {
          const pO = this.collDirty,
            XO = pO.get(OO);
          let eO;
          eO = void 0 === XO ? KO : XO === bK.DELETE || XO === bK.ADD && KO === bK.DELETE_AND_ADD ? bK.DELETE_AND_ADD : XO, pO.set(OO, eO)
        }
      }
      recordDelete(OO, KO) {
        this._isSchema ? (this._opPut(OO, KO), this._markDirty(OO)) : this.collDirty.set(OO, KO)
      }
      recordRaw(OO, KO) {
        this._isSchema ? (this._opPut(OO, KO), this._markDirty(OO)) : this.collDirty.set(OO, KO)
      }
      recordPure(OO) {
        if (this._isSchema) throw new Error("ChangeTree (Schema): pure operations are not supported");
        (this.collPureOps ??= []).push([this.collDirty.size, OO])
      }
      operationAt(OO) {
        if (this._isSchema) {
          const KO = this._opAt(OO);
          return 0 === KO ? void 0 : KO
        }
        return this.collDirty.get(OO)
      }
      setOperationAt(OO, KO) {
        if (this._isSchema) this._opPut(OO, KO);
        else {
          const pO = this.collDirty;
          pO.has(OO) && pO.set(OO, KO)
        }
      }
      forEach(OO) {
        this.forEachWithCtx(OO, Np)
      }
      forEachWithCtx(OO, KO) {
        if (this._isSchema) {
          let pO = this.dirtyLow,
            XO = this.dirtyHigh;
          const bK = this.ops;
          if (void 0 !== bK) {
            for (; 0 !== pO;) {
              const XO = pO & -pO,
                eO = 31 - Math.clz32(XO);
              pO ^= XO, KO(OO, eO, bK[eO])
            }
            for (; 0 !== XO;) {
              const pO = XO & -XO,
                eO = 31 - Math.clz32(pO) + 32;
              XO ^= pO, KO(OO, eO, bK[eO])
            }
          } else {
            const XO = this.opsLow,
              bK = this.opsHigh;
            for (; 0 !== pO;) {
              const eO = pO & -pO,
                lO = 31 - Math.clz32(eO);
              pO ^= eO, KO(OO, lO, Tp(XO, bK, lO))
            }
          }
          return
        }
        const pO = this.collDirty,
          XO = this.collPureOps;
        if (void 0 !== XO && XO.length > 0) {
          let bK = 0,
            eO = 0;
          for (const [lO, vK] of pO) {
            for (; bK < XO.length && XO[bK][0] <= eO;) {
              const pO = XO[bK++][1];
              KO(OO, -pO, pO)
            }
            KO(OO, lO, vK), eO++
          }
          for (; bK < XO.length;) {
            const pO = XO[bK++][1];
            KO(OO, -pO, pO)
          }
        } else
          for (const [bK, eO] of pO) KO(OO, bK, eO)
      }
      size() {
        return this._isSchema ? kp(this.dirtyLow) + kp(this.dirtyHigh) : this.collDirty.size + (this.collPureOps?.length ?? 0)
      }
      has() {
        return this._isSchema ? 0 !== (this.dirtyLow | this.dirtyHigh) : this.collDirty.size > 0 || void 0 !== this.collPureOps && this.collPureOps.length > 0
      }
      reset() {
        if (this._isSchema) return this.dirtyLow = 0, this.dirtyHigh = 0, void(void 0 !== this.ops ? this.ops.fill(0) : (this.opsLow = 0, this.opsHigh = 0));
        this.collDirty.clear(), void 0 !== this.collPureOps && (this.collPureOps.length = 0), this.flags &= -513
      }
      recycle() {
        if (void 0 !== this.root) throw new Error(`@colyseus/schema: cannot recycle an attached ChangeTree (${this.ref?.constructor?.name}). Remove the instance from its parent collection before releasing it to a pool.`);
        this.reset(), this.unreliableRecorder?.reset(), this.flags = 132, this._fullSyncGen = 0, this.parentRef = void 0, this._parentIndex = void 0, this.extraParents = void 0, this.changesNode = void 0, this.unreliableChangesNode = void 0, this.paused = !1, this.visibleViews = void 0, this.tagViews = void 0, this.subscribedViews = void 0
      }
      insertAt(OO, KO) {
        if (this._isSchema) throw new Error("ChangeTree (Schema): insertAt is not supported");
        const pO = this.collDirty,
          XO = new Map,
          eO = !this.paused && !this.isFullStateOnly;
        if (OO > 0)
          for (const [bK, lO] of pO) bK < OO && XO.set(bK, lO);
        if (eO)
          for (let lO = 0; lO < KO; lO++) XO.set(OO + lO, bK.ADD);
        for (const [bK, lO] of pO) bK >= OO && XO.set(bK + KO, lO);
        this.collDirty = XO, eO && this.root?.enqueueChangeTree(this)
      }
      removeAt(OO, KO) {
        if (this._isSchema) throw new Error("ChangeTree (Schema): removeAt is not supported");
        const pO = this.collDirty,
          XO = OO + KO;
        let bK = !1;
        for (const lO of pO.keys())
          if (lO >= XO) {
            bK = !0;
            break
          } if (!bK) {
          for (let KO = OO; KO < XO; KO++) pO.delete(KO);
          return
        }
        const eO = new Map;
        for (const [lO, vK] of pO) lO < OO ? eO.set(lO, vK) : lO >= XO && eO.set(lO - KO, vK);
        this.collDirty = eO
      }
      unshift(OO) {
        this.insertAt(0, OO)
      }
      setRoot(OO) {
        ! function(OO, KO) {
          OO.root = KO;
          const pO = KO.add(OO);
          ep(OO, OO.parent, OO.parentIndex), pO && Qp(OO, KO, zX)
        }(this, OO)
      }
      setParent(OO, KO, pO) {
        Vp(this, OO, KO, pO)
      }
      forEachChild(OO) {
        Qp(this, OO, Lp)
      }
      forEachChildWithCtx(OO, KO) {
        Qp(this, OO, KO)
      }
      forEachLive(OO) {
        bX(this, OO, Xp)
      }
      forEachLiveWithCtx(OO, KO) {
        bX(this, OO, KO)
      }
      operation(OO) {
        this.paused || this.isFullStateOnly || (this.recordPure(OO), this.root?.enqueueChangeTree(this))
      }
      _routeAndRecord(OO, KO, pO) {
        if (!this.paused && !this.isFieldFullStateOnly(OO)) {
          if (this.isFieldUnreliable(OO) && !this.isNew) {
            const XO = this.ensureUnreliableRecorder();
            return pO ? XO.recordRaw(OO, KO) : XO.record(OO, KO), void this.root?.enqueueUnreliable(this)
          }
          pO ? this.recordRaw(OO, KO) : this.record(OO, KO), this.root?.enqueueChangeTree(this)
        }
      }
      change(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : bK.ADD;
        this._routeAndRecord(OO, KO, !1)
      }
      indexedOperation(OO, KO) {
        this._routeAndRecord(OO, KO, !0)
      }
      getChange(OO) {
        return this.operationAt(OO)
      }
      pause() {
        this.paused = !0
      }
      resume() {
        this.paused = !1
      }
      untracked(OO) {
        const KO = this.paused;
        this.paused = !0;
        try {
          return OO()
        } finally {
          this.paused = KO
        }
      }
      markDirty(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : bK.ADD;
        const pO = this.paused;
        this.paused = !1;
        try {
          this.change(OO, KO)
        } finally {
          this.paused = pO
        }
      }
      getValue(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return this.refTarget[aK](OO, KO)
      }
      delete(OO, KO) {
        if (void 0 === OO) {
          try {
            throw new Error(`@colyseus/schema ${this.ref.constructor.name}: trying to delete non-existing index '${OO}'`)
          } catch (eb) {
            console.warn(eb)
          }
          return
        }
        if (this.paused || this.isFieldFullStateOnly(OO)) return this.getValue(OO);
        const pO = this.isFieldUnreliable(OO) && !this.isNew;
        pO ? this.ensureUnreliableRecorder().recordDelete(OO, KO ?? bK.DELETE) : this.recordDelete(OO, KO ?? bK.DELETE);
        const XO = this.getValue(OO);
        return XO && XO[VO] && this.root?.remove(XO[VO]), pO ? this.root?.enqueueUnreliable(this) : this.root?.enqueueChangeTree(this), XO
      }
      endEncode() {
        this.reset(), this.changesNode = void 0, this._isSchema || this.refTarget[zK]?.(), this.isNew = !1
      }
      endEncodeUnreliable() {
        this.unreliableRecorder?.reset(), this.unreliableChangesNode = void 0, this._isSchema || this.refTarget[zK]?.()
      }
      discard() {
        this._isSchema || this.refTarget[zK]?.(), this.reset(), this.unreliableRecorder?.reset()
      }
      discardAll() {
        const OO = OO => {
          if (OO < 0) return;
          const KO = this.getValue(OO);
          KO && KO[VO] && KO[VO].discardAll()
        };
        this.forEach(OO), this.unreliableRecorder?.forEach(OO), this.discard()
      }
      get changed() {
        return this.has() || (this.unreliableRecorder?.has() ?? !1)
      }
      get parent() {
        return this.parentRef
      }
      get parentIndex() {
        return this._parentIndex
      }
      addParent(OO, KO) {
        ! function(OO, KO, pO) {
          if (OO.parentRef) {
            if (OO.parentRef[VO] === KO[VO]) return void(OO._parentIndex = pO);
            if (Kp(OO, ((OO, pO) => OO[VO] === KO[VO]))) return void(OO._parentIndex = pO)
          }
          void 0 === OO.parentRef ? (OO.parentRef = KO, OO._parentIndex = pO) : (OO.extraParents = {
            ref: OO.parentRef,
            index: OO._parentIndex,
            next: OO.extraParents
          }, OO.parentRef = KO, OO._parentIndex = pO)
        }(this, OO, KO)
      }
      setParentIndex(OO, KO) {
        ! function(OO, KO, pO) {
          if (void 0 !== OO.extraParents)
            if (OO.parentRef[VO] !== KO[VO]) {
              for (let XO = OO.extraParents; void 0 !== XO; XO = XO.next)
                if (XO.ref[VO] === KO[VO]) return void(XO.index = pO)
            } else OO._parentIndex = pO;
          else OO._parentIndex = pO
        }(this, OO, KO)
      }
      removeParent() {
        return function(OO, KO) {
          if (OO.parentRef && OO.parentRef[VO] === KO[VO]) return OO.extraParents ? (OO.parentRef = OO.extraParents.ref, OO._parentIndex = OO.extraParents.index, OO.extraParents = OO.extraParents.next) : (OO.parentRef = void 0, OO._parentIndex = void 0), !0;
          let pO = OO.extraParents,
            XO = null;
          for (; pO;) {
            if (pO.ref[VO] === KO[VO]) return XO ? XO.next = pO.next : OO.extraParents = pO.next, !0;
            XO = pO, pO = pO.next
          }
          return void 0 === OO.parentRef
        }(this, arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.parent)
      }
      findParent(OO) {
        return function(OO, KO) {
          if (void 0 !== OO.parentRef && KO(OO.parentRef, OO._parentIndex)) return {
            ref: OO.parentRef,
            index: OO._parentIndex
          };
          for (let pO = OO.extraParents; void 0 !== pO; pO = pO.next)
            if (KO(pO.ref, pO.index)) return {
              ref: pO.ref,
              index: pO.index
            }
        }(this, OO)
      }
      hasParent(OO) {
        return Kp(this, OO)
      }
      indexInParent(OO) {
        return function(OO, KO) {
          if (OO.parentRef && OO.parentRef[VO] === KO[VO]) return OO._parentIndex;
          for (let pO = OO.extraParents; void 0 !== pO; pO = pO.next)
            if (pO.ref[VO] === KO[VO]) return pO.index
        }(this, OO)
      }
      getAllParents() {
        return function(OO) {
          const KO = [];
          OO.parentRef && KO.push({
            ref: OO.parentRef,
            index: OO._parentIndex
          });
          let pO = OO.extraParents;
          for (; pO;) KO.push({
            ref: pO.ref,
            index: pO.index
          }), pO = pO.next;
          return KO
        }(this)
      }
    }
    class Yp {
      ref;
      root = void 0;
      parentRef = void 0;
      paused = !1;
      isNew = !1;
      flags = 0;
      constructor(OO) {
        this.ref = OO
      }
      change() {}
      delete() {}
      indexedOperation() {}
      operation() {}
      setParent() {}
      addParent() {}
      setParentIndex() {}
      removeParent() {
        return !1
      }
      getChange() {
        return 0
      }
      discard() {}
      discardAll() {}
      pause() {}
      resume() {}
      untracked(OO) {
        return OO()
      }
      markDirty() {}
      forEachChild(OO) {
        const KO = this.ref;
        if (KO[LO]) {
          if ("string" !== typeof KO[LO])
            for (const [pO, XO] of KO.entries()) XO && OO(XO[VO], KO._collectionIndexes?.[pO] ?? pO);
          return
        }
        const pO = KO.constructor,
          XO = pO?.[Symbol.metadata];
        if (!XO) return;
        const bK = XO[uO] ?? [];
        for (let eO = 0; eO < bK.length; eO++) {
          const pO = bK[eO],
            lO = KO[XO[pO].name];
          lO && OO(lO[VO], pO)
        }
      }
      forEachChildWithCtx(OO, KO) {
        this.forEachChild(((pO, XO) => KO(OO, pO, XO)))
      }
      forEachLive() {}
      forEachLiveWithCtx() {}
      forEach() {}
    }

    function wp(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO;
      var pO;
      Object.defineProperty(OO, VO, {
        value: (pO = KO, new Yp(pO)),
        enumerable: !1,
        writable: !0
      })
    }

    function iX(OO, KO, pO, XO, eO, lO, CO) {
      void 0 !== CO ? CO(KO, XO, lO) : "string" === typeof pO ? KK[pO]?.(KO, XO, lO) : null != pO[Symbol.metadata] ? (KK.number(KO, XO[vK], lO), (eO & bK.ADD) === bK.ADD && OO.tryEncodeTypeId(KO, pO, XO.constructor, lO)) : KK.number(KO, XO[vK], lO)
    }
    const rX = function(OO, KO, pO, XO, eO, lO, vK, CO) {
        if (KO[lO.offset++] = 255 & (XO | eO), eO === bK.DELETE) return;
        const hO = pO.encDescriptor,
          DO = pO.ref,
          MO = DO[dO][XO] ?? DO[hO.names[XO]];
        iX(OO, KO, hO.types[XO], MO, eO, lO, hO.encoders[XO])
      },
      Pp = function(OO, KO, pO, XO, eO, lO) {
        if (KO[lO.offset++] = 255 & eO, KK.number(KO, XO, lO), eO === bK.DELETE) return;
        const vK = pO.ref;
        if ((eO & bK.ADD) === bK.ADD) {
          const OO = vK.$indexes.get(XO);
          KK.string(KO, OO, lO)
        }
        iX(OO, KO, vK[LO], vK[aK](XO), eO, lO)
      },
      mX = function(OO, KO, pO, XO, eO, lO) {
        if (KO[lO.offset++] = 255 & eO, KK.number(KO, XO, lO), eO === bK.DELETE) return;
        const vK = pO.ref;
        iX(OO, KO, vK[LO], vK[aK](XO), eO, lO)
      },
      sp = function(OO, KO, pO, XO, eO, lO) {
        const vK = pO.ref;
        (eO & bK.ADD) === bK.ADD && "function" === typeof vK.set ? Pp(OO, KO, pO, XO, eO, lO) : mX(OO, KO, pO, XO, eO, lO)
      },
      Hp = function(OO, KO, pO, XO, eO, lO, CO, hO) {
        const DO = pO.refTarget,
          MO = DO[LO],
          oO = "string" !== typeof MO;
        let FO;
        if (hO && pO.isFiltered && oO) {
          const OO = DO.tmpItems[XO];
          if (!OO) return;
          if (FO = OO[vK], eO === bK.DELETE) eO = bK.DELETE_BY_REFID;
          else if ((eO & bK.ADD) === bK.ADD) eO = bK.ADD_BY_REFID;
          else if ((eO & bK.MOVE) === bK.MOVE) return
        } else if (eO === bK.DELETE && oO) {
          const OO = DO.tmpItems[XO];
          if (!OO) return;
          FO = OO[vK], eO = bK.DELETE_BY_REFID
        } else FO = XO;
        if (KO[lO.offset++] = 255 & eO, KK.number(KO, FO, lO), eO === bK.DELETE || eO === bK.DELETE_BY_REFID) return;
        iX(OO, KO, MO, DO[aK](XO, CO), eO, lO)
      };

    function Rp(OO, KO, pO, XO, eO, lO, CO) {
      const hO = OO.resyncVisited;
      let DO = hO.get(OO.currentRefId);
      if (void 0 === DO && hO.set(OO.currentRefId, DO = new Set), DO.add(XO), void 0 !== eO && pO === bK.ADD && eO !== lO) {
        const pO = eO[vK];
        void 0 !== pO && (OO.root.removeRef(pO), CO?.push({
          ref: KO,
          refId: OO.currentRefId,
          op: bK.DELETE,
          dynamicIndex: XO,
          value: void 0,
          previousValue: eO
        }))
      }
    }

    function Sp(OO, KO, pO, XO) {
      const bK = KO[vK];
      if (void 0 === bK || pO.has(bK)) return;
      pO.add(bK);
      const eO = KO.constructor[Symbol.metadata],
        lO = eO?.[uO];
      if (void 0 === lO) return;
      const CO = eO[wO];
      for (let vK = 0; vK < lO.length; vK++) {
        const bK = lO[vK];
        if (void 0 !== CO && CO.includes(bK)) continue;
        const hO = eO[bK],
          DO = KO[hO.name];
        DO && (EX.is(hO.type) ? Sp(OO, DO, pO, XO) : Jp(OO, DO, pO, XO))
      }
    }

    function Jp(OO, KO, pO, XO) {
      const eO = KO[QO] ?? KO,
        lO = eO[vK];
      if (void 0 === lO || pO.has(lO)) return;
      pO.add(lO);
      const CO = OO.resyncVisited.get(lO);
      if (void 0 === CO) return;
      const hO = OO.root;
      eO[FO](CO, ((OO, pO) => {
        XO?.push({
          ref: KO,
          refId: lO,
          op: bK.DELETE,
          dynamicIndex: pO,
          value: void 0,
          previousValue: OO
        });
        const eO = OO?.[vK];
        void 0 !== eO && hO.removeRef(eO)
      }), (KO => {
        EX.isSchema(KO) && Sp(OO, KO, pO, XO)
      }))
    }
    const cX = 1,
      Bp = 2,
      Zp = 3,
      Gp = 4,
      qX = 5;

    function xX(OO, KO, pO, XO, eO, lO, CO, hO, DO) {
      const MO = OO.root;
      let aK;
      if ((KO & bK.DELETE) === bK.DELETE) {
        const OO = eO?.[vK];
        void 0 !== OO && MO.removeRef(OO), KO !== bK.DELETE_AND_ADD && pO[oO](XO), aK = void 0
      }
      if (KO === bK.DELETE);
      else if ("string" === typeof lO) aK = AK[lO](CO, hO);
      else if (mp(lO)) aK = function(OO, KO, pO) {
        return HK(OO, (0, AK[OO.wire])(KO, pO))
      }(lO.quantized, CO, hO);
      else if (EX.is(lO)) {
        const pO = AK.number(CO, hO);
        if (aK = MO.refs.get(pO), (KO & bK.ADD) === bK.ADD) {
          const XO = OO.getInstanceType(CO, hO, lO);
          aK || (aK = OO.createInstanceOfType(XO)), MO.addRef(pO, aK, aK !== eO || KO === bK.DELETE_AND_ADD && aK === eO)
        }
      } else {
        const pO = (FO = Object.keys(lO)[0], fK[FO]),
          XO = AK.number(CO, hO);
        null !== OO.resyncVisited && function(OO, KO) {
          const pO = OO.resyncVisited;
          pO.has(KO) || pO.set(KO, new Set)
        }(OO, XO);
        const oO = MO.refs.has(XO) ? eO || MO.refs.get(XO) : pO.constructor.initializeForDecoder();
        if (aK = oO.clone(!0), aK[LO] = Object.values(lO)[0], eO) {
          let OO = eO[vK];
          if (void 0 !== OO && XO !== OO) {
            (KO & bK.DELETE) !== bK.DELETE && MO.removeRef(OO);
            const pO = eO.entries();
            let XO;
            for (;
              (XO = pO.next()) && !XO.done;) {
              const [KO, pO] = XO.value;
              "object" === typeof pO && (OO = pO[vK]), DO?.push({
                ref: eO,
                refId: OO,
                op: bK.DELETE,
                field: KO,
                value: void 0,
                previousValue: pO
              })
            }
          }
        }
        MO.addRef(XO, aK, oO !== eO || KO === bK.DELETE_AND_ADD && oO === eO)
      }
      var FO;
      return aK
    }
    const np = function(OO, KO, pO, XO, bK) {
        const eO = KO[pO.offset++],
          lO = XO.constructor[Symbol.metadata],
          vK = eO >> 6 << 6,
          CO = eO % (vK || 255),
          hO = lO[CO];
        if (void 0 === hO) return console.warn("@colyseus/schema: field not defined at", {
          index: CO,
          ref: XO.constructor.name,
          metadata: lO
        }), -1;
        const DO = !0 === hO.deprecated,
          MO = DO ? void 0 : XO[aK](CO),
          oO = xX(OO, vK, XO, CO, MO, hO.type, KO, pO, bK);
        DO || (null !== oO && void 0 !== oO && (XO[hO.name] = oO), MO !== oO && bK?.push({
          ref: XO,
          refId: OO.currentRefId,
          op: vK,
          field: hO.name,
          value: oO,
          previousValue: MO
        }))
      },
      Wp = function(OO, KO, pO, XO, eO) {
        const lO = XO[QO] ?? XO,
          vK = KO[pO.offset++];
        if (vK === bK.CLEAR) return OO.removeChildRefs(lO, eO), void lO.clear();
        const CO = AK.number(KO, pO),
          hO = lO[LO],
          DO = lO.constructor.COLLECTION_KIND;
        let MO;
        (vK & bK.ADD) === bK.ADD ? DO === cX ? (MO = AK.string(KO, pO), lO.setIndex(CO, MO)) : MO = CO : MO = lO.getIndex(CO);
        const oO = lO[aK](CO),
          FO = xX(OO, vK, XO, CO, oO, hO, KO, pO, eO);
        if (null !== OO.resyncVisited && Rp(OO, XO, vK, MO, oO, FO, eO), null !== FO && void 0 !== FO) switch (DO) {
          case cX:
            lO.$items.set(MO, FO);
            break;
          case Bp:
            lO.$setAt(CO, FO, null !== OO.resyncVisited && vK === bK.ADD ? bK.REPLACE : vK);
            break;
          case Zp:
          case Gp:
          case qX:
            lO.$items.has(CO) || (lO.$items.set(CO, FO), "number" === typeof lO.$refId && CO >= lO.$refId && (lO.$refId = CO + 1));
            break;
          default:
            console.warn(`@colyseus/schema: missing COLLECTION_KIND on ${lO.constructor?.name} \u2014 item at index ${CO} was not stored.`)
        }
        oO !== FO && eO?.push({
          ref: XO,
          refId: OO.currentRefId,
          op: vK,
          dynamicIndex: MO,
          value: FO,
          previousValue: oO
        })
      },
      tX = function(OO, KO, pO, XO, eO) {
        const lO = XO[QO] ?? XO;
        let vK, CO = KO[pO.offset++];
        if (CO === bK.CLEAR) return OO.removeChildRefs(lO, eO), void lO.clear();
        if (CO === bK.REVERSE) return void lO.items.reverse();
        if (CO === bK.DELETE_BY_REFID) {
          const CO = AK.number(KO, pO),
            hO = OO.root.refs.get(CO);
          if (void 0 === hO) return;
          if (OO.root.removeRef(CO), vK = lO.findIndex((OO => OO === hO)), -1 === vK) return;
          return lO[oO](vK), void eO?.push({
            ref: XO,
            refId: OO.currentRefId,
            op: bK.DELETE,
            dynamicIndex: vK,
            value: void 0,
            previousValue: hO
          })
        }
        if (CO === bK.ADD_BY_REFID) {
          const XO = AK.number(KO, pO),
            bK = OO.root.refs.get(XO);
          bK && (vK = lO.findIndex((OO => OO === bK))), -1 !== vK && void 0 !== vK || (vK = lO.length)
        } else vK = AK.number(KO, pO);
        const hO = lO[LO];
        let DO = vK;
        const MO = lO.items[vK],
          aK = xX(OO, CO, XO, vK, MO, hO, KO, pO, eO);
        null !== OO.resyncVisited && Rp(OO, XO, CO, vK, MO, aK, eO), null !== aK && void 0 !== aK && aK !== MO && lO.$setAt(vK, aK, null !== OO.resyncVisited && CO === bK.ADD ? bK.REPLACE : CO), MO !== aK && eO?.push({
          ref: XO,
          refId: OO.currentRefId,
          op: CO,
          dynamicIndex: DO,
          value: aK,
          previousValue: MO
        })
      };
    class kX extends Error {}

    function Up(OO, KO, pO, XO) {
      if (!(OO instanceof KO)) throw new kX(`a '${KO.name}' was expected, but '${OO&&OO.constructor.name}' was provided in ${pO.constructor.name}#${XO}`)
    }
    const OX = (OO, KO) => {
        const pO = OO.toString(),
          XO = KO.toString();
        return pO < XO ? -1 : pO > XO ? 1 : 0
      },
      KX = {
        get: (OO, KO) => "symbol" === typeof KO || isNaN(KO) ? Reflect.get(OO, KO) : OO.items[KO],
        set: (OO, KO, pO) => {
          if ("symbol" !== typeof KO && !isNaN(KO)) {
            if (void 0 === pO || null === pO) OO.$deleteAt(KO);
            else {
              let XO;
              if (pO[VO]) {
                Up(pO, OO[LO], OO, KO);
                const eO = OO.items[KO];
                OO.isMovingItems ? (XO = OO.$wireIndex(Number(KO)), void 0 !== eO ? pO[VO].isNew ? OO[VO].indexedOperation(XO, bK.MOVE_AND_ADD) : (OO[VO].getChange(XO) & bK.DELETE) === bK.DELETE ? OO[VO].indexedOperation(XO, bK.DELETE_AND_MOVE) : OO[VO].indexedOperation(XO, bK.MOVE) : pO[VO].isNew && OO[VO].indexedOperation(XO, bK.ADD), pO[VO].setParent(OO, OO[VO].root, XO)) : XO = OO.$changeAt(Number(KO), pO), void 0 !== eO && eO[VO].root?.remove(eO[VO])
              } else XO = OO.$changeAt(Number(KO), pO);
              OO.items[KO] = pO, void 0 !== XO && (OO.tmpItems[XO] = pO)
            }
            return !0
          }
          return Reflect.set(OO, KO, pO)
        },
        deleteProperty: (OO, KO) => ("number" === typeof KO ? OO.$deleteAt(KO) : delete OO[KO], !0),
        has: (OO, KO) => "symbol" === typeof KO || isNaN(Number(KO)) ? Reflect.has(OO, KO) : Reflect.has(OO.items, KO)
      };
    class pX {
      [VO];
      [vK];
      [QO];
      [LO];
      items = [];
      tmpItems = [];
      deletedIndexes = [];
      isMovingItems = !1;
      _needsCompaction = !1;
      static[hO] = Hp;
      static[DO] = tX;
      static COLLECTION_KIND = Bp;
      static[MO](OO, KO, pO) {
        if (!pO) return !0;
        const XO = OO[QO] ?? OO;
        return "string" === typeof XO[LO] || pO.isChangeTreeVisible(XO.tmpItems[KO]?.[VO])
      }
      static is(OO) {
        return Array.isArray(OO) || void 0 !== OO.array
      }
      static from(OO) {
        return new pX(...Array.from(OO))
      }
      constructor() {
        this[LO] = void 0, this[QO] = this;
        const OO = new Proxy(this, KX);
        return Object.defineProperty(this, VO, {
          value: new jX(OO, this),
          enumerable: !1,
          writable: !0
        }), arguments.length > 0 && this.push(...arguments), OO
      }
      static initializeForDecoder() {
        const OO = Object.create(pX.prototype);
        OO.items = [], OO.isMovingItems = !1, OO._needsCompaction = !1, OO[LO] = void 0, OO[QO] = OO;
        const KO = new Proxy(OO, KX);
        return wp(OO, KO), KO
      }
      set length(OO) {
        0 === OO ? this.clear() : OO < this.items.length ? this.splice(OO, this.length - OO) : console.warn("ArraySchema: can't set .length to a higher value than its length.")
      }
      get length() {
        return this.items.length
      }
      pauseTracking() {
        this[VO].pause()
      }
      resumeTracking() {
        this[VO].resume()
      }
      untracked(OO) {
        return this[VO].untracked(OO)
      }
      get isTrackingPaused() {
        return this[VO].paused
      }
      push() {
        const OO = this[QO],
          KO = OO.items,
          pO = OO.tmpItems,
          XO = OO[VO],
          eO = OO[LO];
        let lO = pO.length;
        for (let vK = 0, CO = arguments.length; vK < CO; vK++, lO++) {
          const CO = vK < 0 || arguments.length <= vK ? void 0 : arguments[vK];
          if (void 0 === CO || null === CO) return;
          "object" === typeof CO && eO && Up(CO, eO, OO, vK), XO.indexedOperation(lO, bK.ADD), KO.push(CO), pO.push(CO), CO[VO]?.setParent(this, XO.root, lO)
        }
        return lO
      }
      pop() {
        const OO = this[QO],
          KO = OO.tmpItems,
          pO = OO.deletedIndexes;
        let XO = -1;
        for (let eO = KO.length - 1; eO >= 0; eO--)
          if (!0 !== pO[eO]) {
            XO = eO;
            break
          } if (XO < 0) return;
        const bK = OO.$isUnsentAdd(XO);
        return OO[VO].delete(XO), bK ? OO.$cancelAdd(XO) : pO[XO] = !0, OO.items.pop()
      }
      at(OO) {
        return OO < 0 && (OO += this.length), this.items[OO]
      }
      $wireIndex(OO) {
        const KO = this.deletedIndexes;
        if (0 === KO.length) return OO;
        const pO = this.tmpItems;
        let XO = 0;
        for (let bK = 0; bK < pO.length; bK++)
          if (!0 !== KO[bK]) {
            if (XO === OO) return bK;
            XO++
          } return pO.length + (OO - XO)
      }
      $isUnsentAdd(OO) {
        const KO = this[VO];
        return 0 === (576 & KO.flags) && !KO.paused && "string" !== typeof this[LO] && KO.operationAt(OO) === bK.ADD
      }
      $cancelAdd(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        const pO = this[VO],
          XO = this.tmpItems[OO];
        this.tmpItems.splice(OO, 1), this.deletedIndexes.length > 0 && this.deletedIndexes.splice(OO, 1), pO.removeAt(OO, 1);
        const bK = XO?.[VO];
        void 0 !== bK && void 0 === bK.root && bK.removeParent(this), KO && this.$reindexChildren(OO)
      }
      $reindexChildren(OO, KO) {
        if (!this[VO].hasFilteredFields) return;
        if ("string" === typeof this[LO]) return;
        const pO = this.tmpItems,
          XO = pO.length;
        if (void 0 !== KO)
          for (; OO < XO && pO[OO] === KO[OO];) OO++;
        for (let bK = OO; bK < XO; bK++) pO[bK]?.[VO]?.setParentIndex(this, bK)
      }
      $changeAt(OO, KO) {
        if (void 0 === KO || null === KO) return void console.error("ArraySchema items cannot be null nor undefined; Use `splice(index, 1)` instead.");
        if (this.items[OO] === KO) return;
        const pO = void 0 !== this.items[OO] ? "object" === typeof KO ? bK.DELETE_AND_ADD : bK.REPLACE : bK.ADD,
          XO = this.$wireIndex(OO),
          eO = this[VO];
        return eO.change(XO, pO), KO[VO]?.setParent(this, eO.root, XO), XO
      }
      $deleteAt(OO, KO) {
        this[VO].delete(this.$wireIndex(OO), KO)
      }
      $setAt(OO, KO, pO) {
        pO === bK.ADD && void 0 !== this.items[OO] ? this.items.splice(OO, 0, KO) : pO === bK.DELETE_AND_MOVE ? (this.items.splice(OO, 1), this.items[OO] = KO) : (OO > this.items.length && (this._needsCompaction = !0), this.items[OO] = KO)
      }
      clear() {
        const OO = this[QO];
        if (0 === OO.items.length) return;
        const KO = OO[VO];
        KO.forEachChild(((OO, pO) => {
          KO.root?.remove(OO)
        })), KO.discard(), KO.operation(bK.CLEAR), OO.items.length = 0, OO.tmpItems.length = 0
      } [AO]() {
        const OO = this[QO] ?? this,
          KO = OO[VO];
        if (KO.isStreamCollection) throw new Error("@colyseus/schema: cannot reset a streamed ArraySchema (pooling not supported).");
        const pO = OO.items;
        for (let XO = 0; XO < pO.length; XO++) pO[XO]?.[AO]?.();
        OO.items.length = 0, OO.tmpItems.length = 0, OO.deletedIndexes.length = 0, KO.recycle(), OO[vK] = void 0
      }
      concat() {
        return new pX(...this.items.concat(...arguments))
      }
      join(OO) {
        return this.items.join(OO)
      }
      reverse() {
        const OO = this[QO],
          KO = OO[VO];
        if (KO.has() || OO.deletedIndexes.length > 0) {
          const KO = OO.items.slice().reverse();
          return this.clear(), this.push(...KO), this
        }
        return KO.operation(bK.REVERSE), OO.items.reverse(), OO.tmpItems.reverse(), OO.$reindexChildren(0), this
      }
      shift() {
        const OO = this[QO],
          KO = OO.items;
        if (0 === KO.length) return;
        const pO = OO[VO],
          XO = OO.deletedIndexes;
        let eO = 0;
        for (; !0 === XO[eO];) eO++;
        const lO = OO.$isUnsentAdd(eO);
        return pO.delete(eO, bK.DELETE), lO ? OO.$cancelAdd(eO) : XO[eO] = !0, KO.shift()
      }
      slice(OO, KO) {
        const pO = new pX;
        return pO.push(...this.items.slice(OO, KO)), pO
      }
      sort() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : OX;
        const KO = this[QO];
        KO.isMovingItems = !0;
        const pO = KO[VO];
        return KO.items.sort(OO).forEach(((OO, KO) => pO.change(KO, bK.REPLACE))), KO.tmpItems.sort(OO), KO.$reindexChildren(0), KO.isMovingItems = !1, this
      }
      splice(OO, KO) {
        const pO = this[QO],
          XO = pO[VO],
          eO = pO.items,
          lO = pO.tmpItems,
          vK = pO.deletedIndexes,
          CO = eO.length,
          hO = lO.length;
        for (var DO = arguments.length, MO = new Array(DO > 2 ? DO - 2 : 0), aK = 2; aK < DO; aK++) MO[aK - 2] = arguments[aK];
        const oO = MO.length,
          FO = [];
        for (let bK = 0; bK < hO; bK++) !0 !== vK[bK] && FO.push(bK);
        let LO;
        if (CO > OO) {
          void 0 === KO && (KO = CO - OO);
          for (let eO = OO; eO < OO + KO; eO++) {
            const OO = FO[eO],
              KO = pO.$isUnsentAdd(OO);
            XO.delete(OO, bK.DELETE), KO ? (LO ??= []).push(OO) : vK[OO] = !0
          }
        } else KO = 0;
        if (oO > 0) {
          const eO = FO[OO] ?? CO,
            hO = Math.min(oO, KO);
          for (let OO = 0; OO < hO; OO++) {
            const KO = eO + OO;
            let pO;
            const CO = void 0 !== LO ? LO.indexOf(KO) : -1; - 1 !== CO ? (LO.splice(CO, 1), pO = bK.ADD) : pO = vK[KO] ? bK.DELETE_AND_ADD : bK.ADD, XO.indexedOperation(KO, pO), lO[KO] = MO[OO], vK[KO] = !1, MO[OO][VO]?.setParent(this, XO.root, KO)
          }
          const DO = oO - hO;
          if (DO > 0) {
            const OO = eO + hO;
            XO.insertAt(OO, DO);
            for (let KO = 0; KO < DO; KO++) MO[hO + KO][VO]?.setParent(this, XO.root, OO + KO);
            vK.length > 0 && vK.splice(OO, 0, ...new Array(DO).fill(!1)), lO.splice(OO, 0, ...MO.slice(hO)), pO.$reindexChildren(OO + DO)
          }
        }
        if (void 0 !== LO && LO.length > 0) {
          for (let OO = LO.length - 1; OO >= 0; OO--) pO.$cancelAdd(LO[OO], !1);
          pO.$reindexChildren(LO[0])
        }
        return XO.root?.enqueueChangeTree(XO), eO.splice(OO, KO, ...MO)
      }
      unshift() {
        const OO = this[QO],
          KO = OO[VO];
        KO.unshift(arguments.length);
        for (let XO = 0; XO < arguments.length; XO++)(XO < 0 || arguments.length <= XO ? void 0 : arguments[XO])?.[VO]?.setParent(this, KO.root, XO);
        const pO = OO.deletedIndexes;
        return pO.length > 0 && pO.unshift(...new Array(arguments.length).fill(!1)), OO.tmpItems.unshift(...arguments), OO.$reindexChildren(arguments.length), OO.items.unshift(...arguments)
      }
      indexOf(OO, KO) {
        return this.items.indexOf(OO, KO)
      }
      lastIndexOf(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.length - 1;
        return this.items.lastIndexOf(OO, KO)
      }
      every(OO, KO) {
        return this.items.every(OO, KO)
      }
      some(OO, KO) {
        return this.items.some(OO, KO)
      }
      forEach(OO, KO) {
        return this.items.forEach(OO, KO)
      }
      map(OO, KO) {
        return this.items.map(OO, KO)
      }
      filter(OO, KO) {
        return this.items.filter(OO, KO)
      }
      reduce(OO, KO) {
        return this.items.reduce.apply(this.items, arguments)
      }
      reduceRight(OO, KO) {
        return this.items.reduceRight.apply(this.items, arguments)
      }
      find(OO, KO) {
        return this.items.find(OO, KO)
      }
      findIndex(OO, KO) {
        return this.items.findIndex(OO, KO)
      }
      fill(OO, KO, pO) {
        throw new Error("ArraySchema#fill() not implemented")
      }
      copyWithin(OO, KO, pO) {
        throw new Error("ArraySchema#copyWithin() not implemented")
      }
      toString() {
        return this.items.toString()
      }
      toLocaleString() {
        return this.items.toLocaleString()
      } [Symbol.iterator]() {
        return this.items[Symbol.iterator]()
      }
      static get[Symbol.species]() {
        return pX
      } [Symbol.unscopables];
      entries() {
        return this.items.entries()
      }
      keys() {
        return this.items.keys()
      }
      values() {
        return this.items.values()
      }
      includes(OO, KO) {
        return this.items.includes(OO, KO)
      }
      flatMap(OO, KO) {
        throw new Error("ArraySchema#flatMap() is not supported.")
      }
      flat(OO) {
        throw new Error("ArraySchema#flat() is not supported.")
      }
      findLast() {
        return this.items.findLast.apply(this.items, arguments)
      }
      findLastIndex() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        return this.items.findLastIndex.apply(this.items, arguments)
      }
      with(OO, KO) {
        const pO = this.items.slice();
        return OO < 0 && (OO += this.length), pO[OO] = KO, new pX(...pO)
      }
      toReversed() {
        return this.items.slice().reverse()
      }
      toSorted(OO) {
        return this.items.slice().sort(OO)
      }
      toSpliced(OO, KO) {
        for (var pO = arguments.length, XO = new Array(pO > 2 ? pO - 2 : 0), bK = 2; bK < pO; bK++) XO[bK - 2] = arguments[bK];
        const eO = this.items.slice();
        return eO.splice.apply(eO, arguments), eO
      }
      shuffle() {
        return this.move((OO => {
          let KO = this.items.length;
          for (; 0 != KO;) {
            let OO = Math.floor(Math.random() * KO);
            KO--, [this[KO], this[OO]] = [this[OO], this[KO]]
          }
        }))
      }
      move(OO) {
        return this.isMovingItems = !0, OO(this), this.isMovingItems = !1, this
      } [aK](OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = this[QO] ?? this;
        return KO || pO.deletedIndexes[OO] ? pO.items[OO] : pO.tmpItems[OO] || pO.items[OO]
      } [oO](OO) {
        const KO = this[QO] ?? this;
        KO.items[OO] = void 0, KO._needsCompaction = !0
      } [zK]() {
        const OO = this.tmpItems;
        this.tmpItems = this.items.slice(), this.deletedIndexes.length > 0 && (this.$reindexChildren(0, OO), this.deletedIndexes.length = 0)
      } [fO]() {
        const OO = this[QO] ?? this;
        OO._needsCompaction && (OO._needsCompaction = !1, OO.items = OO.items.filter((OO => void 0 !== OO)))
      } [FO](OO, KO, pO) {
        const XO = this[QO] ?? this,
          bK = XO.items;
        let eO = !1;
        for (let lO = 0; lO < bK.length; lO++) {
          const vK = bK[lO];
          OO.has(lO) ? pO(vK) : (eO = !0, KO(vK, lO), XO[oO](lO))
        }
        eO && XO[fO]()
      }
      toArray() {
        return this.items.slice(0)
      }
      toJSON() {
        return this.toArray().map((OO => "function" === typeof OO.toJSON ? OO.toJSON() : OO))
      }
      clone(OO) {
        let KO;
        return OO ? (KO = new pX, KO.push(...this.items)) : KO = new pX(...this.map((OO => OO[VO] ? OO.clone() : OO))), KO
      }
    }
    TK("array", {
      constructor: pX
    });
    class XX {
      keyByIndex = new Map;
      indexByKey = Object.create(null);
      nextIndex = 0;
      snapshots;
      indexOf(OO) {
        const KO = this.indexByKey[OO];
        return void 0 === KO ? void 0 : KO
      }
      assign(OO) {
        const KO = this.nextIndex++;
        return this.indexByKey[OO] = KO, this.keyByIndex.set(KO, OO), KO
      }
      snapshot(OO, KO) {
        (this.snapshots ??= new Map).set(OO, KO)
      }
      forgetSnapshot(OO) {
        this.snapshots?.delete(OO)
      }
      snapshotAt(OO) {
        return this.snapshots?.get(OO)
      }
      setIndex(OO, KO) {
        this.keyByIndex.set(OO, KO), this.indexByKey[KO] = OO
      }
      keyOf(OO) {
        return this.keyByIndex.get(OO)
      }
      cleanupAfterEncode() {
        if (void 0 !== this.snapshots) {
          for (const [OO] of this.snapshots) {
            const KO = this.keyByIndex.get(OO);
            void 0 !== KO && (delete this.indexByKey[KO], this.keyByIndex.delete(OO))
          }
          this.snapshots.clear()
        }
      }
      reset() {
        this.indexByKey = Object.create(null), this.keyByIndex.clear(), this.snapshots?.clear(), this.nextIndex = 0
      }
    }
    class bb {
      [VO];
      [vK];
      childType;
      [LO];
      $items = new Map;
      journal = new XX;
      _stream;
      get maxPerTick() {
        return this._stream?.maxPerTick ?? 32
      }
      set maxPerTick(OO) {
        (this._stream ??= yp()).maxPerTick = OO
      }
      get priority() {
        return this._stream?.priority
      }
      set priority(OO) {
        (this._stream ??= yp()).priority = OO
      }
      get $indexes() {
        return this.journal.keyByIndex
      }
      get _collectionIndexes() {
        return this.journal.indexByKey
      }
      static[hO] = Pp;
      static[DO] = Wp;
      static COLLECTION_KIND = cX;
      static[MO](OO, KO, pO) {
        if (!pO || "string" === typeof OO[LO]) return !0;
        const XO = OO[aK](KO) ?? OO.journal.snapshotAt(KO);
        return pO.isChangeTreeVisible(XO[VO])
      }
      static is(OO) {
        return void 0 !== OO.map
      }
      constructor(OO) {
        if (Object.defineProperty(this, VO, {
            value: new jX(this),
            enumerable: !1,
            writable: !0
          }), this[LO] = void 0, OO)
          if (OO instanceof Map || OO instanceof bb) OO.forEach(((OO, KO) => this.set(KO, OO)));
          else
            for (const KO in OO) this.set(KO, OO[KO])
      }
      static initializeForDecoder() {
        const OO = Object.create(bb.prototype);
        return OO.$items = new Map, OO.journal = new XX, OO[LO] = void 0, wp(OO), OO
      } [Symbol.iterator]() {
        return this.$items[Symbol.iterator]()
      }
      get[Symbol.toStringTag]() {
        return this.$items[Symbol.toStringTag]
      }
      static get[Symbol.species]() {
        return bb
      }
      set(OO, KO) {
        if (void 0 === KO || null === KO) throw new Error(`MapSchema#set('${OO}', ${KO}): trying to set ${KO} value on '${OO}'.`);
        "object" === typeof KO && this[LO] && Up(KO, this[LO], this, OO), OO = OO.toString();
        const pO = this[VO],
          XO = void 0 !== KO[VO],
          eO = this.journal;
        let lO, vK = eO.indexOf(OO);
        if (void 0 !== vK) {
          lO = bK.REPLACE;
          const pO = this.$items.get(OO);
          if (pO === KO) return;
          XO && (lO = bK.DELETE_AND_ADD, void 0 !== pO && pO[VO].root?.remove(pO[VO])), void 0 !== eO.snapshotAt(vK) && eO.forgetSnapshot(vK)
        } else vK = eO.assign(OO), lO = bK.ADD;
        return this.$items.set(OO, KO), lO === bK.ADD && pO.isStreamCollection ? void 0 !== pO.root && uK(this, pO.root, vK) : pO.change(vK, lO), XO && KO[VO].setParent(this, pO.root, vK), this
      }
      get(OO) {
        return this.$items.get(OO)
      }
      getOrInsert(OO, KO) {
        return this.$items.has(OO) ? this.$items.get(OO) : (this.set(OO, KO), KO)
      }
      getOrInsertComputed(OO, KO) {
        if (this.$items.has(OO)) return this.$items.get(OO);
        const pO = KO(OO);
        return this.set(OO, pO), pO
      }
      delete(OO) {
        if (!this.$items.has(OO)) return !1;
        const KO = this.journal.indexOf(OO),
          pO = this.$items.get(OO),
          XO = this[VO];
        if (XO.isStreamCollection) {
          const bK = XO.root;
          let eO = !1;
          return void 0 !== bK && (eO = EK(this, bK, this[vK], KO)), void 0 !== pO?.[VO] && bK?.remove(pO[VO]), this.$items.delete(OO), eO || this.journal.snapshot(KO, pO), !0
        }
        return this.journal.snapshot(KO, pO), XO.delete(KO), this.$items.delete(OO)
      }
      clear() {
        const OO = this[VO];
        OO.discard(), OO.forEachChild(((KO, pO) => {
          OO.root?.remove(KO)
        })), this.journal.reset(), this.$items.clear(), OO.operation(bK.CLEAR)
      } [AO]() {
        const OO = this[VO];
        if (OO.isStreamCollection) throw new Error("@colyseus/schema: cannot reset a streamed MapSchema (pooling not supported).");
        this.$items.forEach((OO => OO?.[AO]?.())), this.$items.clear(), this.journal.reset(), OO.recycle(), this[vK] = void 0
      }
      has(OO) {
        return this.$items.has(OO)
      }
      forEach(OO) {
        this.$items.forEach(OO)
      }
      entries() {
        return this.$items.entries()
      }
      keys() {
        return this.$items.keys()
      }
      values() {
        return this.$items.values()
      }
      get size() {
        return this.$items.size
      }
      pauseTracking() {
        this[VO].pause()
      }
      resumeTracking() {
        this[VO].resume()
      }
      untracked(OO) {
        return this[VO].untracked(OO)
      }
      get isTrackingPaused() {
        return this[VO].paused
      }
      setIndex(OO, KO) {
        this.journal.setIndex(OO, KO)
      }
      getIndex(OO) {
        return this.journal.keyOf(OO)
      } [aK](OO) {
        const KO = this.journal.keyOf(OO);
        return void 0 !== KO ? this.$items.get(KO) : void 0
      } [oO](OO) {
        const KO = this.journal.keyOf(OO);
        void 0 !== KO && (this.$items.delete(KO), this.journal.keyByIndex.delete(OO))
      } [FO](OO, KO, pO) {
        let XO = null;
        if (this.$items.forEach(((bK, eO) => {
            OO.has(eO) ? pO(bK) : ((XO ??= new Set).add(eO), KO(bK, eO))
          })), null !== XO) {
          XO.forEach((OO => {
            this.$items.delete(OO), delete this.journal.indexByKey[OO]
          }));
          const OO = [];
          this.journal.keyByIndex.forEach(((KO, pO) => {
            XO.has(KO) && OO.push(pO)
          }));
          for (let KO = 0; KO < OO.length; KO++) this.journal.keyByIndex.delete(OO[KO])
        }
      } [zK]() {
        this.journal.cleanupAfterEncode()
      }
      _dropView(OO) {
        ip(this, OO)
      }
      _unregister() {}
      toJSON() {
        return Object.fromEntries(Array.from(this, (OO => {
          let [KO, pO] = OO;
          return [KO, "function" === typeof pO.toJSON ? pO.toJSON() : pO]
        })))
      }
      clone(OO) {
        let KO;
        return OO ? KO = Object.assign(new bb, this) : (KO = new bb, this.forEach(((OO, pO) => {
          OO[VO] ? KO.set(pO, OO.clone()) : KO.set(pO, OO)
        }))), KO
      }
    }
    TK("map", {
      constructor: bb
    });
    class eX {
      [VO];
      [vK];
      [LO];
      $items = new Map;
      deletedItems = {};
      $refId = 0;
      _stream;
      get maxPerTick() {
        return this._stream?.maxPerTick ?? 32
      }
      set maxPerTick(OO) {
        (this._stream ??= yp()).maxPerTick = OO
      }
      get priority() {
        return this._stream?.priority
      }
      set priority(OO) {
        (this._stream ??= yp()).priority = OO
      }
      static[hO] = mX;
      static[DO] = Wp;
      static COLLECTION_KIND = Gp;
      static[MO](OO, KO, pO) {
        return !pO || "string" === typeof OO[LO] || pO.isChangeTreeVisible((OO[aK](KO) ?? OO.deletedItems[KO])[VO])
      }
      static is(OO) {
        return void 0 !== OO.collection
      }
      constructor(OO) {
        Object.defineProperty(this, VO, {
          value: new jX(this),
          enumerable: !1,
          writable: !0
        }), this[LO] = void 0, OO && OO.forEach((OO => this.add(OO)))
      }
      static initializeForDecoder() {
        const OO = Object.create(eX.prototype);
        return OO.$items = new Map, OO.deletedItems = {}, OO.$refId = 0, OO[LO] = void 0, wp(OO), OO
      }
      add(OO) {
        const KO = this.$refId++,
          pO = this[VO];
        return this.$items.set(KO, OO), pO.isStreamCollection ? void 0 !== pO.root && uK(this, pO.root, KO) : pO.change(KO), void 0 !== OO[VO] && OO[VO].setParent(this, pO.root, KO), KO
      }
      at(OO) {
        const KO = Array.from(this.$items.keys())[OO];
        return this.$items.get(KO)
      }
      entries() {
        return this.$items.entries()
      }
      delete(OO) {
        const KO = this.$items.entries();
        let pO, XO;
        for (;
          (XO = KO.next()) && !XO.done;)
          if (OO === XO.value[1]) {
            pO = XO.value[0];
            break
          } if (void 0 === pO) return !1;
        const bK = this[VO];
        if (bK.isStreamCollection) {
          const OO = bK.root,
            KO = this.$items.get(pO);
          return void 0 !== OO && EK(this, OO, this[vK], pO), void 0 !== KO?.[VO] && OO?.remove(KO[VO]), this.deletedItems[pO] = KO, this.$items.delete(pO)
        }
        return this.deletedItems[pO] = bK.delete(pO), this.$items.delete(pO)
      }
      clear() {
        const OO = this[VO];
        OO.discard(), OO.forEachChild(((KO, pO) => {
          OO.root?.remove(KO)
        })), this.$items.clear(), OO.operation(bK.CLEAR)
      } [AO]() {
        const OO = this[VO];
        if (OO.isStreamCollection) throw new Error("@colyseus/schema: cannot reset a streamed CollectionSchema (pooling not supported).");
        this.$items.forEach((OO => OO?.[AO]?.())), this.$items.clear(), this.deletedItems = {}, this.$refId = 0, OO.recycle(), this[vK] = void 0
      }
      has(OO) {
        return Array.from(this.$items.values()).some((KO => KO === OO))
      }
      forEach(OO) {
        this.$items.forEach(((KO, pO, XO) => OO(KO, pO, this)))
      }
      values() {
        return this.$items.values()
      }
      get size() {
        return this.$items.size
      }
      pauseTracking() {
        this[VO].pause()
      }
      resumeTracking() {
        this[VO].resume()
      }
      untracked(OO) {
        return this[VO].untracked(OO)
      }
      get isTrackingPaused() {
        return this[VO].paused
      } [Symbol.iterator]() {
        return this.$items.values()
      }
      setIndex(OO, KO) {}
      getIndex(OO) {
        return OO
      } [aK](OO) {
        return this.$items.get(OO)
      } [oO](OO) {
        this.$items.delete(OO)
      } [FO](OO, KO, pO) {
        let XO = null;
        if (this.$items.forEach(((bK, eO) => {
            OO.has(eO) ? pO(bK) : ((XO ??= []).push(eO), KO(bK, eO))
          })), null !== XO)
          for (let bK = 0; bK < XO.length; bK++) this[oO](XO[bK])
      } [zK]() {
        for (const OO in this.deletedItems) delete this.deletedItems[OO]
      }
      _dropView(OO) {
        ip(this, OO)
      }
      _unregister() {}
      toArray() {
        return Array.from(this.$items.values())
      }
      toJSON() {
        const OO = [];
        return this.forEach(((KO, pO) => {
          OO.push("function" === typeof KO.toJSON ? KO.toJSON() : KO)
        })), OO
      }
      clone(OO) {
        let KO;
        return OO ? KO = Object.assign(new eX, this) : (KO = new eX, this.forEach((OO => {
          OO[VO] ? KO.add(OO.clone()) : KO.add(OO)
        }))), KO
      }
    }
    TK("collection", {
      constructor: eX
    });
    class lX {
      [VO];
      [vK];
      [LO];
      $items = new Map;
      deletedItems = {};
      $refId = 0;
      _stream;
      get maxPerTick() {
        return this._stream?.maxPerTick ?? 32
      }
      set maxPerTick(OO) {
        (this._stream ??= yp()).maxPerTick = OO
      }
      get priority() {
        return this._stream?.priority
      }
      set priority(OO) {
        (this._stream ??= yp()).priority = OO
      }
      static[hO] = mX;
      static[DO] = Wp;
      static COLLECTION_KIND = Zp;
      static[MO](OO, KO, pO) {
        return !pO || "string" === typeof OO[LO] || pO.isVisible((OO[aK](KO) ?? OO.deletedItems[KO])[VO])
      }
      static is(OO) {
        return void 0 !== OO.set
      }
      constructor(OO) {
        Object.defineProperty(this, VO, {
          value: new jX(this),
          enumerable: !1,
          writable: !0
        }), this[LO] = void 0, OO && OO.forEach((OO => this.add(OO)))
      }
      static initializeForDecoder() {
        const OO = Object.create(lX.prototype);
        return OO.$items = new Map, OO.deletedItems = {}, OO.$refId = 0, OO[LO] = void 0, wp(OO), OO
      }
      add(OO) {
        if (this.has(OO)) return !1;
        const KO = this.$refId++,
          pO = this[VO];
        return this.$items.set(KO, OO), pO.isStreamCollection ? void 0 !== pO.root && uK(this, pO.root, KO) : pO.change(KO, bK.ADD), void 0 !== OO[VO] && OO[VO].setParent(this, pO.root, KO), KO
      }
      entries() {
        return this.$items.entries()
      }
      delete(OO) {
        const KO = this.$items.entries();
        let pO, XO;
        for (;
          (XO = KO.next()) && !XO.done;)
          if (OO === XO.value[1]) {
            pO = XO.value[0];
            break
          } if (void 0 === pO) return !1;
        const bK = this[VO];
        if (bK.isStreamCollection) {
          const OO = bK.root,
            KO = this.$items.get(pO);
          return void 0 !== OO && EK(this, OO, this[vK], pO), void 0 !== KO?.[VO] && OO?.remove(KO[VO]), this.deletedItems[pO] = KO, this.$items.delete(pO)
        }
        return this.deletedItems[pO] = bK.delete(pO), this.$items.delete(pO)
      }
      clear() {
        const OO = this[VO];
        OO.discard(), this.$items.clear(), OO.operation(bK.CLEAR)
      } [AO]() {
        const OO = this[VO];
        if (OO.isStreamCollection) throw new Error("@colyseus/schema: cannot reset a streamed SetSchema (pooling not supported).");
        this.$items.forEach((OO => OO?.[AO]?.())), this.$items.clear(), this.deletedItems = {}, this.$refId = 0, OO.recycle(), this[vK] = void 0
      }
      has(OO) {
        const KO = this.$items.values();
        let pO, XO = !1;
        for (;
          (pO = KO.next()) && !pO.done;)
          if (OO === pO.value) {
            XO = !0;
            break
          } return XO
      }
      forEach(OO) {
        this.$items.forEach(((KO, pO, XO) => OO(KO, pO, this)))
      }
      values() {
        return this.$items.values()
      }
      get size() {
        return this.$items.size
      }
      pauseTracking() {
        this[VO].pause()
      }
      resumeTracking() {
        this[VO].resume()
      }
      untracked(OO) {
        return this[VO].untracked(OO)
      }
      get isTrackingPaused() {
        return this[VO].paused
      } [Symbol.iterator]() {
        return this.$items.values()
      }
      setIndex(OO, KO) {}
      getIndex(OO) {
        return OO
      } [aK](OO) {
        return this.$items.get(OO)
      } [oO](OO) {
        this.$items.delete(OO)
      } [FO](OO, KO, pO) {
        let XO = null;
        if (this.$items.forEach(((bK, eO) => {
            OO.has(eO) ? pO(bK) : ((XO ??= []).push(eO), KO(bK, eO))
          })), null !== XO)
          for (let bK = 0; bK < XO.length; bK++) this[oO](XO[bK])
      } [zK]() {
        for (const OO in this.deletedItems) delete this.deletedItems[OO]
      }
      _dropView(OO) {
        ip(this, OO)
      }
      _unregister() {}
      toArray() {
        return Array.from(this.$items.values())
      }
      toJSON() {
        const OO = [];
        return this.forEach(((KO, pO) => {
          OO.push("function" === typeof KO.toJSON ? KO.toJSON() : KO)
        })), OO
      }
      clone(OO) {
        let KO;
        return OO ? KO = Object.assign(new lX, this) : (KO = new lX, this.forEach((OO => {
          OO[VO] ? KO.add(OO.clone()) : KO.add(OO)
        }))), KO
      }
    }
    TK("set", {
      constructor: lX
    });
    class vb {
      [VO];
      [vK];
      [LO];
      $items = new Map;
      $nextPosition = 0;
      _itemIndex = new Map;
      _stream;
      get maxPerTick() {
        return this._stream?.maxPerTick ?? 32
      }
      set maxPerTick(OO) {
        (this._stream ??= yp()).maxPerTick = OO
      }
      get priority() {
        return this._stream?.priority
      }
      set priority(OO) {
        (this._stream ??= yp()).priority = OO
      }
      static $isStream = !0;
      static[hO] = mX;
      static[DO] = Wp;
      static COLLECTION_KIND = qX;
      static[MO](OO, KO, pO) {
        if (!pO) return !0;
        const XO = OO[aK](KO);
        return void 0 !== XO && pO.isVisible(XO[VO])
      }
      static is(OO) {
        return OO && void 0 !== OO.stream
      }
      constructor() {
        Object.defineProperty(this, VO, {
          value: new jX(this),
          enumerable: !1,
          writable: !0
        }), this[LO] = void 0
      }
      static initializeForDecoder() {
        const OO = Object.create(vb.prototype);
        return OO.$items = new Map, OO.$nextPosition = 0, OO._itemIndex = new Map, OO[LO] = void 0, wp(OO), OO
      }
      add(OO) {
        if (this._itemIndex.has(OO)) return -1;
        const KO = this.$nextPosition++;
        this.$items.set(KO, OO), this._itemIndex.set(OO, KO);
        const pO = this[VO].root;
        return void 0 !== OO[VO] && OO[VO].setParent(this, pO, KO), void 0 !== pO && uK(this, pO, KO), KO
      }
      remove(OO) {
        const KO = this._itemIndex.get(OO);
        if (void 0 === KO) return !1;
        this._itemIndex.delete(OO), this.$items.delete(KO);
        const pO = this[VO].root;
        return void 0 !== pO && (EK(this, pO, this[vK], KO), void 0 !== OO[VO] && pO.remove(OO[VO])), !0
      }
      has(OO) {
        return this._itemIndex.has(OO)
      }
      clear() {
        const OO = this[VO].root;
        if (void 0 !== OO) {
          ! function(OO, KO, pO) {
            const XO = OO._stream;
            if (void 0 !== XO) {
              XO.broadcastPending.clear();
              for (const OO of XO.sentBroadcast) XO.broadcastDeletes.add(OO);
              XO.sentBroadcast.clear(), KO.forEachActiveView((OO => {
                XO.pendingByView.get(OO.id)?.clear();
                const KO = XO.sentByView.get(OO.id);
                if (void 0 !== KO && KO.size > 0) {
                  let XO = OO.changes.get(pO);
                  void 0 === XO && (XO = new Map, OO.changes.set(pO, XO));
                  for (const OO of KO) XO.set(OO, bK.DELETE);
                  KO.clear()
                }
              }))
            }
          }(this, OO, this[vK]);
          for (const KO of this.$items.values()) void 0 !== KO[VO] && OO.remove(KO[VO])
        }
        this.$items.clear(), this._itemIndex.clear()
      }
      forEach(OO) {
        for (const [KO, pO] of this.$items) OO(pO, KO, this)
      }
      values() {
        return this.$items.values()
      }
      entries() {
        return this.$items.entries()
      } [Symbol.iterator]() {
        return this.$items.values()
      }
      get size() {
        return this.$items.size
      }
      get length() {
        return this.$items.size
      }
      setIndex(OO, KO) {}
      getIndex(OO) {
        return OO
      } [aK](OO) {
        return this.$items.get(OO)
      } [oO](OO) {
        const KO = this.$items.get(OO);
        void 0 !== KO && (this._itemIndex.delete(KO), this.$items.delete(OO))
      } [FO]() {} [zK]() {}
      toArray() {
        return Array.from(this.$items.values())
      }
      toJSON() {
        const OO = [];
        return this.forEach((KO => {
          OO.push("function" === typeof KO?.toJSON ? KO.toJSON() : KO)
        })), OO
      }
      clone(OO) {
        if (OO) {
          return Object.assign(new vb, this)
        }
        const KO = new vb;
        return KO.maxPerTick = this.maxPerTick, this.forEach((OO => {
          KO.add("function" === typeof OO?.clone ? OO.clone() : OO)
        })), KO
      }
      _dropView(OO) {
        ip(this, OO)
      }
      _unregister() {}
    }
    TK("stream", {
      constructor: vb
    });
    class CX {
      [TO] = !0;
      _type;
      _default = void 0;
      _hasDefault = !1;
      _view = void 0;
      _unreliable = !1;
      _patchOnly = !1;
      _deprecated = !1;
      _deprecatedThrows = !0;
      _fullStateOnly = !1;
      _stream = !1;
      _optional = !1;
      _noSync = !1;
      _streamPriority = void 0;
      constructor(OO) {
        this._type = OO
      }
      default (OO) {
        return this._default = OO, this._hasDefault = !0, this
      }
      view(OO) {
        return this._view = OO ?? -1, this
      }
      unreliable() {
        return this._unreliable = !0, this
      }
      patchOnly() {
        return this._patchOnly = !0, this
      }
      fullStateOnly() {
        return this._fullStateOnly = !0, this
      }
      noSync() {
        return this._noSync = !0, this
      }
      stream() {
        const OO = this._type;
        if (OO && "object" === typeof OO && void 0 !== OO.array) throw new Error(IK);
        return this._stream = !0, this
      }
      priority(OO) {
        return this._streamPriority = OO, this
      }
      deprecated() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        return this._deprecated = !0, this._deprecatedThrows = OO, this
      }
      optional() {
        return this._optional = !0, this
      }
      toDefinition() {
        return {
          type: this._type,
          default: this._default,
          hasDefault: this._hasDefault,
          view: this._view,
          unreliable: this._unreliable,
          patchOnly: this._patchOnly,
          deprecated: this._deprecated,
          deprecatedThrows: this._deprecatedThrows,
          fullStateOnly: this._fullStateOnly,
          stream: this._stream,
          optional: this._optional,
          noSync: this._noSync,
          streamPriority: this._streamPriority
        }
      }
    }

    function hX(OO) {
      return null != OO && !0 === OO[TO]
    }

    function DX(OO) {
      return () => new CX(OO)
    }

    function MX(OO) {
      if (hX(OO)) {
        const KO = OO._type;
        throw new Error(`t.array/map/set/collection(): a t.* builder is not a valid element type \u2014 ${"string"===typeof KO?`use the type name instead: t.array("${KO}")`:'collections accept a Schema class or a primitive type name ("string", "number", \u2026)'}.`)
      }
      return OO
    }

    function ab(OO) {
      return new CX({
        quantized: PK(OO)
      })
    }
    const oX = Object.freeze({
        string: DX("string"),
        number: DX("number"),
        boolean: DX("boolean"),
        int8: DX("int8"),
        uint8: DX("uint8"),
        int16: DX("int16"),
        uint16: DX("uint16"),
        int32: DX("int32"),
        uint32: DX("uint32"),
        int64: DX("int64"),
        uint64: DX("uint64"),
        float32: DX("float32"),
        float64: DX("float64"),
        bigint64: DX("bigint64"),
        biguint64: DX("biguint64"),
        ref: OO => new CX(OO),
        array: OO => new CX({
          array: MX(OO)
        }),
        map: OO => new CX({
          map: MX(OO)
        }),
        set: OO => new CX({
          set: MX(OO)
        }),
        collection: OO => new CX({
          collection: MX(OO)
        }),
        stream: OO => {
          const KO = new CX({
            stream: MX(OO)
          });
          return KO._stream = !0, KO
        },
        quantized: ab,
        angle: OO => ab({
          min: 0,
          max: 2 * Math.PI,
          mode: "wrap",
          bits: OO?.bits ?? 16
        })
      }),
      FX = -1;

    function VX(OO) {
      return SK.register(OO), OO
    }

    function LX() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : FX;
      return function(KO, pO) {
        const XO = xp.initialize(KO.constructor);
        xp.setTag(XO, pO, OO)
      }
    }

    function QX(OO, KO) {
      const pO = xp.initialize(OO.constructor);
      xp.setUnreliable(pO, KO)
    }

    function zb(OO, KO) {
      const pO = xp.initialize(OO.constructor);
      xp.setPatchOnly(pO, KO)
    }

    function AX(OO, KO) {
      const pO = xp.initialize(OO.constructor);
      xp.setFullStateOnly(pO, KO)
    }

    function fX(OO, KO) {
      return function(pO, XO) {
        const bK = pO.constructor;
        if (!OO) throw new Error(`${bK.name}: @type() reference provided for "${XO}" is undefined. Make sure you don't have any circular dependencies.`);
        OO = cp(OO, `${bK.name}.${XO}`), SK.register(bK);
        const eO = Object.getPrototypeOf(bK)[Symbol.metadata],
          lO = xp.initialize(bK);
        let vK = lO[XO];
        if (void 0 !== lO[vK]) {
          if (lO[vK].deprecated) return;
          if (void 0 !== lO[vK].type) {
            const OO = new Error(`@colyseus/schema: Duplicate '${XO}' definition on '${bK.name}'.\nCheck @type() annotation`);
            throw new Error(`${OO.message} ${OO.stack.split("\n")[4].trim()}`)
          }
        } else vK = lO[gK] ?? (eO && eO[gK]) ?? -1, vK++;
        if (KO && KO.manual) xp.addField(lO, vK, XO, OO, {
          enumerable: !0,
          configurable: !0,
          writable: !0
        });
        else {
          const {
            complexTypeKlass: KO,
            childType: pO
          } = JK(OO);
          xp.addField(lO, vK, XO, OO, TX(XO, vK, pO, KO))
        }
        lO[NO][XO] && Object.defineProperty(pO, XO, lO[NO][XO]), ("string" === typeof OO || mp(OO)) && (lO[yK] || Object.defineProperty(lO, yK, {
          value: [],
          enumerable: !1,
          configurable: !0,
          writable: !0
        }), lO[yK][vK] = "string" === typeof OO ? KK[OO] : RK(OO.quantized))
      }
    }
    const dX = {
      number: "number",
      int8: "number",
      uint8: "number",
      int16: "number",
      uint16: "number",
      int32: "number",
      uint32: "number",
      int64: "number",
      uint64: "number",
      float32: "number",
      float64: "number",
      bigint64: "bigint",
      biguint64: "bigint",
      string: "string",
      boolean: "boolean"
    };

    function TX(OO, KO, pO, XO) {
      let eO;
      return eO = XO ? function(OO, KO, pO, XO) {
        const eO = XO.constructor === pX,
          lO = XO.constructor === bb;
        return function(OO) {
          const XO = this[dO],
            vK = XO[KO];
          if (OO !== vK) {
            if (void 0 !== OO && null !== OO) {
              if (!eO || OO instanceof pX)
                if (!lO || OO instanceof bb) OO[LO] = pO;
                else {
                  const KO = new bb;
                  if (KO[LO] = pO, OO instanceof Map) OO.forEach(((OO, pO) => KO.set(pO, OO)));
                  else
                    for (const pO in OO) KO.set(pO, OO[pO]);
                  OO = KO
                }
              else {
                const KO = new pX;
                KO[LO] = pO, KO.push(...OO), OO = KO
              }
              const XO = this[VO],
                hO = this.constructor;
              void 0 !== vK && null !== vK && vK[VO] ? (XO.root?.remove(vK[VO]), hO[CO](XO, KO, bK.DELETE_AND_ADD)) : hO[CO](XO, KO, bK.ADD), OO[VO]?.setParent(this, XO.root, KO)
            } else void 0 !== vK && null !== vK && this[VO].delete(KO);
            XO[KO] = OO
          }
        }
      }(0, KO, pO, XO) : "string" === typeof pO ? function(OO, KO, pO) {
        const XO = dX[pO],
          eO = "string" === pO,
          lO = "boolean" === pO;
        return function(pO) {
          const vK = this[dO],
            hO = vK[KO];
          if (pO !== hO) {
            if (void 0 !== pO && null !== pO) {
              if (!lO && void 0 !== XO && typeof pO !== XO && (!eO || null !== pO)) {
                const KO = pO && pO.constructor ? ` (${pO.constructor.name})` : "";
                throw new kX(`a '${XO}' was expected, but '${JSON.stringify(pO)}'${KO} was provided in ${this.constructor.name}#${OO}`)
              }
              this.constructor[CO](this[VO], KO, bK.ADD)
            } else void 0 !== hO && null !== hO && this[VO].delete(KO);
            vK[KO] = pO
          }
        }
      }(OO, KO, pO) : mp(pO) ? function(OO, KO, pO) {
        return function(XO) {
          const eO = this[dO],
            lO = eO[KO];
          if (void 0 !== XO && null !== XO) {
            if ("number" !== typeof XO) throw new kX(`a 'number' was expected, but '${JSON.stringify(XO)}' was provided in ${this.constructor.name}#${OO}`);
            if ((XO = HK(pO, sK(pO, XO))) === lO) return;
            this.constructor[CO](this[VO], KO, bK.ADD)
          } else {
            if (XO === lO) return;
            void 0 !== lO && null !== lO && this[VO].delete(KO)
          }
          eO[KO] = XO
        }
      }(OO, KO, pO.quantized) : function(OO, KO, pO) {
        return function(XO) {
          const eO = this[dO],
            lO = eO[KO];
          if (XO !== lO) {
            if (void 0 !== XO && null !== XO) {
              Up(XO, pO, this, OO);
              const eO = this[VO],
                vK = this.constructor;
              void 0 !== lO && null !== lO && lO[VO] ? (eO.root?.remove(lO[VO]), vK[CO](eO, KO, bK.DELETE_AND_ADD)) : vK[CO](eO, KO, bK.ADD), XO[VO]?.setParent(this, eO.root, KO)
            } else void 0 !== lO && null !== lO && this[VO].delete(KO);
            eO[KO] = XO
          }
        }
      }(OO, KO, pO), {
        get: function() {
          return this[dO][KO]
        },
        set: eO,
        enumerable: !0,
        configurable: !0
      }
    }

    function NX() {
      let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
      return function(KO, pO) {
        const XO = xp.initialize(KO.constructor);
        xp.setDeprecated(XO, pO), OO && (XO[NO] ??= {}, XO[NO][pO] = {
          get: function() {
            throw new Error(`${pO} is deprecated.`)
          },
          set: function(OO) {},
          enumerable: !1,
          configurable: !0
        }, Object.defineProperty(KO, pO, XO[NO][pO]))
      }
    }
    let IX = !1;

    function yb(OO, KO, pO) {
      IX || (IX = !0, console.warn("@colyseus/schema: defineTypes() is deprecated and will be removed in a future release. Use schema() with t.* field builders instead \u2192 https://docs.colyseus.io/state/schema"));
      for (let XO in KO) fX(KO[XO], pO)(OO.prototype, XO);
      return OO
    }

    function gb(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : EX;
      if (null == OO || "object" !== typeof OO) throw new Error(`schema(): first argument must be a fields object (got ${typeof OO}).`);
      const XO = {},
        bK = {},
        eO = {},
        lO = {},
        vK = (OO, KO) => {
          if (KO.hasDefault)((OO, KO) => {
            "function" === typeof KO ? lO[OO] = KO : KO && "function" === typeof KO.clone ? lO[OO] = () => KO.clone() : eO[OO] = KO
          })(OO, KO.default);
          else if (!KO.optional) {
            const pO = function(OO) {
              if (OO && "object" === typeof OO) {
                if (void 0 !== OO.array) return () => new pX;
                if (void 0 !== OO.map) return () => new bb;
                if (void 0 !== OO.set) return () => new lX;
                if (void 0 !== OO.collection) return () => new eX;
                if (void 0 !== OO.stream) return () => new vb
              } else if ("function" === typeof OO && EX.is(OO) && (!OO.prototype.initialize || 0 === OO.prototype.initialize.length)) return () => new OO
            }(KO.type);
            pO && (lO[OO] = pO)
          }
        },
        CO = {},
        hO = [],
        DO = [],
        MO = {},
        aK = [],
        oO = [],
        FO = {},
        VO = [];
      for (const dO in OO) {
        const pO = OO[dO],
          eO = `schema(${KO?`'${KO}'`:""}): field '${dO}'`;
        if (hX(pO)) {
          const OO = pO.toDefinition();
          if (OO.noSync) {
            if (void 0 !== OO.view || OO.unreliable || OO.patchOnly || OO.fullStateOnly || OO.stream) throw new Error(`${eO} uses .noSync() together with a sync-only modifier (.view/.unreliable/.patchOnly/.fullStateOnly/.stream). A local-only field cannot be synchronized.`);
            vK(dO, OO);
            continue
          }
          if (OO.patchOnly && OO.fullStateOnly) throw new Error(`${eO} uses .patchOnly() together with .fullStateOnly(). Those are the only two delivery channels, so the field would never reach a client \u2014 use .noSync() if that is intended.`);
          const KO = cp(OO.type, eO);
          if ("function" === typeof KO && !EX.is(KO)) throw new Error(`${eO} is a synced ref to non-Schema class '${KO.name||"(anonymous)"}' \u2014 use .noSync(), or Metadata.setFields().`);
          XO[dO] = KO, void 0 !== OO.view && (CO[dO] = OO.view), OO.unreliable && hO.push(dO), OO.patchOnly && DO.push(dO), OO.deprecated && (MO[dO] = OO.deprecatedThrows), OO.fullStateOnly && aK.push(dO), OO.stream && oO.push(dO), void 0 !== OO.streamPriority && (FO[dO] = OO.streamPriority), OO.optional && VO.push(dO), vK(dO, OO)
        } else {
          if ("function" !== typeof pO) throw new Error(`${eO} must be a t.* builder, Schema subclass, or method (got ${typeof pO}).`);
          EX.is(pO) ? (XO[dO] = pO, pO.prototype.initialize && 0 !== pO.prototype.initialize.length || (lO[dO] = () => new pO)) : bK[dO] = pO
        }
      }
      const LO = OO => {
          for (const KO in eO) OO[KO] = eO[KO];
          for (const KO in lO) OO[KO] = lO[KO]()
        },
        QO = () => {
          const OO = {};
          return LO(OO), OO
        },
        zK = "function" === typeof bK.initialize,
        AO = bK.initialize ?? pO._initialize,
        fO = class extends pO {
          constructor() {
            for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
            const bK = KO[0];
            void 0 === bK ? (super(), LO(this)) : super(Object.assign(QO(), zK ? (OO => {
              const KO = Object.keys(XO),
                pO = {};
              for (const XO in OO) KO.includes(XO) || (pO[XO] = OO[XO]);
              return pO
            })(bK) : bK)), AO && new.target === fO && AO.apply(this, KO)
          }
        };
      KO && Object.defineProperty(fO, "name", {
        value: KO
      }), xp.setFields(fO, XO), fO._getDefaultValues = QO, fO._initialize = AO, Object.assign(fO.prototype, bK);
      for (const dO in CO) LX(CO[dO])(fO.prototype, dO);
      for (const dO of hO) QX(fO.prototype, dO);
      for (const dO of DO) zb(fO.prototype, dO);
      for (const dO in MO) NX(MO[dO])(fO.prototype, dO);
      if (aK.length > 0 || oO.length > 0) {
        const OO = fO[Symbol.metadata];
        for (const KO of aK) xp.setFullStateOnly(OO, KO);
        for (const KO of oO) xp.setStream(OO, KO);
        for (const KO in FO) xp.setStreamPriority(OO, KO, FO[KO])
      }
      if (VO.length > 0) {
        const OO = fO[Symbol.metadata];
        for (const KO of VO) OO[OO[KO]].optional = !0
      }
      return fO.extend = (OO, KO) => gb(OO, KO, fO), fO
    }

    function uX(OO) {
      const KO = OO[VO].root,
        pO = {
          ops: {},
          refs: []
        };
      let XO = KO.changes.next;
      for (; XO;) {
        const OO = XO.changeTree;
        void 0 !== OO ? (pO.refs.push(`refId#${OO.ref[vK]}`), OO.forEach(((OO, KO) => {
          if (OO < 0 || !KO) return;
          const XO = bK[KO];
          pO.ops[XO] || (pO.ops[XO] = 0), pO.ops[XO]++
        })), XO = XO.next) : XO = XO.next
      }
      return pO
    }
    class EX {
      static[hO] = rX;
      static[DO] = np;
      [vK];
      [dO];
      static initialize(OO) {
        Object.defineProperty(OO, VO, {
          value: new jX(OO),
          enumerable: !1,
          writable: !0
        }), OO[dO] = []
      }
      static initializeForDecoder() {
        const OO = Object.create(this.prototype);
        return wp(OO), OO[dO] = [], OO
      }
      static reset(OO) {
        const KO = OO?.[VO];
        if (void 0 === KO || "function" !== typeof KO.recycle) throw new Error("@colyseus/schema: Schema.reset() requires a tracked (encoder-side) instance.");
        if (void 0 !== KO.extraParents) throw new Error(`@colyseus/schema: cannot reset a shared instance (${OO.constructor.name}) with multiple parents.`);
        OO[AO]()
      } [AO]() {
        const OO = this.constructor[Symbol.metadata],
          KO = OO?.[uO] ?? [],
          pO = this[dO];
        for (let XO = 0; XO < KO.length; XO++) {
          const OO = pO[KO[XO]];
          OO?.[AO]?.()
        }
        this[VO].recycle(), this[vK] = void 0
      }
      static is(OO) {
        const KO = OO[Symbol.metadata];
        return "object" === typeof KO && null !== KO
      }
      static isSchema(OO) {
        return "function" === typeof OO?.assign
      }
      static[CO](OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : bK.ADD;
        OO.change(KO, pO)
      }
      static[MO](OO, KO, pO) {
        const XO = OO.constructor[Symbol.metadata],
          bK = XO[KO]?.tag;
        return void 0 === pO ? void 0 === bK : void 0 === bK || (bK === FX ? pO.isChangeTreeVisible(OO[VO]) : pO.hasTagOnTree(OO[VO], bK))
      }
      constructor(OO) {
        EX.initialize(this), OO && EX.assignProps(this, OO)
      }
      assign(OO) {
        return EX.assignProps(this, OO), this
      }
      static assignProps(OO, KO) {
        const pO = OO.constructor[Symbol.metadata];
        if (pO && void 0 !== pO[gK])
          for (let bK = 0; bK <= pO[gK]; bK++) {
            const XO = pO[bK];
            if (!XO) continue;
            const eO = KO[XO.name];
            void 0 !== eO && (OO[XO.name] = eO)
          }
        const XO = Object.keys(KO);
        for (let bK = 0; bK < XO.length; bK++) {
          const eO = XO[bK];
          pO && void 0 !== pO[eO] || (OO[eO] = KO[eO])
        }
      }
      restore(OO) {
        const KO = this.constructor[Symbol.metadata];
        for (const pO in KO) {
          const XO = KO[pO],
            bK = XO.name,
            eO = XO.type,
            lO = OO[bK];
          if (void 0 !== lO && null !== lO)
            if ("string" === typeof eO) this[bK] = lO;
            else if (EX.is(eO)) {
            const OO = new eO;
            OO.restore(lO), this[bK] = OO
          } else if ("object" === typeof eO) {
            const OO = Object.keys(eO)[0],
              KO = eO[OO];
            if ("map" === OO) {
              const OO = this[bK];
              for (const pO in lO)
                if (EX.is(KO)) {
                  const XO = new KO;
                  XO.restore(lO[pO]), OO.set(pO, XO)
                } else OO.set(pO, lO[pO])
            } else if ("array" === OO) {
              const OO = this[bK];
              for (let pO = 0; pO < lO.length; pO++)
                if (EX.is(KO)) {
                  const XO = new KO;
                  XO.restore(lO[pO]), OO.push(XO)
                } else OO.push(lO[pO])
            }
          }
        }
        return this
      }
      setDirty(OO, KO) {
        const pO = this.constructor[Symbol.metadata];
        this[VO].change(pO[pO[OO]].index, KO)
      }
      pauseTracking() {
        this[VO].pause()
      }
      resumeTracking() {
        this[VO].resume()
      }
      untracked(OO) {
        return this[VO].untracked(OO)
      }
      get isTrackingPaused() {
        return this[VO].paused
      }
      clone() {
        const OO = Object.create(this.constructor.prototype);
        EX.initialize(OO);
        const KO = this.constructor[Symbol.metadata];
        for (const pO in KO) {
          const XO = KO[pO].name;
          "object" === typeof this[XO] && "function" === typeof this[XO]?.clone ? OO[XO] = this[XO].clone() : OO[XO] = this[XO]
        }
        return OO
      }
      toJSON() {
        const OO = {},
          KO = this.constructor[Symbol.metadata];
        for (const pO in KO) {
          const XO = KO[pO],
            bK = XO.name;
          XO.deprecated || null === this[bK] || "undefined" === typeof this[bK] || (OO[bK] = "function" === typeof this[bK].toJSON ? this[bK].toJSON() : this[bK])
        }
        return OO
      }
      discardAllChanges() {
        this[VO].discardAll()
      } [aK](OO) {
        return this[this.constructor[Symbol.metadata][OO].name]
      } [oO](OO) {
        this[this.constructor[Symbol.metadata][OO].name] = void 0
      }
      static debugRefIds(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 ? arguments[3] : void 0,
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "";
        const eO = KO ? ` - ${JSON.stringify(OO.toJSON())}` : "",
          lO = OO[VO],
          CO = OO[vK],
          hO = XO ? XO.root.refCount[CO] : lO.refCount,
          DO = hO > 1 ? ` [\xd7${hO}]` : "";
        let MO = `${function(OO){return new Array(OO).fill(0).map(((KO,pO)=>pO===OO-1?"\u2514\u2500 ":"   ")).join("")}(pO)}${bK}${OO.constructor.name} (refId: ${CO})${DO}${eO}\n`;
        return lO.forEachChild(((bK, eO) => {
          let lO = eO;
          "number" === typeof eO && OO.$indexes && (lO = OO.$indexes.get(eO) ?? eO);
          const vK = void 0 !== OO.forEach && void 0 !== lO ? `["${lO}"]: ` : "";
          MO += this.debugRefIds(bK.ref, KO, pO + 1, XO, vK)
        })), MO
      }
      static debugRefIdEncodingOrder(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "allChanges";
        const pO = [],
          XO = OO[VO];
        if ("changes" === KO) {
          let OO = XO.root.changes?.next;
          for (; OO;) OO.changeTree && pO.push(OO.changeTree.ref[vK]), OO = OO.next;
          return pO
        }
        const bK = "allFilteredChanges" === KO,
          eO = new Set,
          lO = OO => {
            eO.has(OO) || (eO.add(OO), OO.isFiltered === bK && pO.push(OO.ref[vK]), OO.forEachChild(((OO, KO) => lO(OO))))
          };
        return lO(XO), pO
      }
      static debugRefIdsFromDecoder(OO) {
        return this.debugRefIds(OO.state, !1, 0, OO)
      }
      static debugChanges(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = OO[VO],
          XO = KO ? "allChanges" : "changes";
        let eO = `${OO.constructor.name} (${OO[vK]}) -> .${XO}:\n`;
        return KO ? pO.forEachLive((OO => {
          eO += `- [${OO}]: ADD (${JSON.stringify(pO.getValue(Number(OO),!0))})\n`
        })) : pO.forEach(((OO, KO) => {
          OO < 0 || !KO || (eO += `- [${OO}]: ${bK[KO]} (${JSON.stringify(pO.getValue(Number(OO),!1))})\n`)
        })), eO
      }
    }
    eO(EX);
    const jb = {
      value: 0,
      enumerable: !1,
      writable: !0
    };
    class YX {
      types;
      nextUniqueId = 0;
      changeTrees = {};
      get refCount() {
        const OO = {};
        for (const KO in this.changeTrees) OO[KO] = this.changeTrees[KO].refCount;
        return OO
      }
      changes = {
        next: void 0,
        tail: void 0,
        nextPosition: 0
      };
      unreliableChanges = {
        next: void 0,
        tail: void 0,
        nextPosition: 0
      };
      pendingFilterRefresh = [];
      enqueueFilterRefresh(OO) {
        this.types.hasFilters && (OO.flags & upO || (OO.flags |= upO, this.pendingFilterRefresh.push(OO)))
      }
      _nodePool = [];
      _nextViewId = 0;
      _freeViewIds = [];
      acquireViewId() {
        return this._freeViewIds.length > 0 ? this._freeViewIds.pop() : this._nextViewId++
      }
      releaseViewId(OO) {
        this._freeViewIds.push(OO)
      }
      activeViews = new Map;
      streamTrees = new Set;
      registerView(OO) {
        this.activeViews.set(OO.id, new WeakRef(OO))
      }
      unregisterView(OO) {
        this.activeViews.delete(OO.id);
        const KO = OO.id;
        for (const pO of this.streamTrees) pO._dropView(KO)
      }
      forEachActiveView(OO) {
        for (const [KO, pO] of this.activeViews) {
          const XO = pO.deref();
          if (void 0 !== XO) OO(XO);
          else {
            this.activeViews.delete(KO);
            for (const OO of this.streamTrees) OO._dropView(KO)
          }
        }
      }
      registerStream(OO) {
        this.streamTrees.add(OO)
      }
      unregisterStream(OO) {
        this.streamTrees.delete(OO)
      }
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        this.types = OO, this.nextUniqueId = KO
      }
      add(OO) {
        const KO = OO.ref;
        void 0 === KO[vK] && (jb.value = this.nextUniqueId++, Object.defineProperty(KO, vK, jb));
        const pO = KO[vK],
          XO = void 0 === this.changeTrees[pO];
        XO && (this.changeTrees[pO] = OO), OO.needsRestage && (OO.needsRestage = !1, OO.forEachLiveWithCtx(OO, pp));
        const bK = XO ? 0 : OO.refCount;
        return OO.refCount = bK + 1, bK > 0 && this.enqueueFilterRefresh(OO), XO
      }
      remove(OO) {
        const KO = OO.refCount - 1;
        if (KO <= 0) {
          if (OO.root = void 0, delete this.changeTrees[OO.ref[vK]], OO.isStreamCollection) {
            const KO = OO.ref;
            KO._unregister?.(), this.unregisterStream(KO)
          }
          this.removeFromQueue(OO), this.removeFromUnreliableQueue(OO), OO.refCount = 0, OO.needsRestage = !0, OO.forEachChild(((KO, pO) => {
            KO.removeParent(OO.ref) && (void 0 === KO.parentRef || KO.refCount > 0 ? this.remove(KO) : this.moveNextToParent(KO))
          }))
        } else OO.refCount = KO, this.enqueueFilterRefresh(OO), this.recursivelyMoveNextToParent(OO);
        return KO
      }
      recursivelyMoveNextToParent(OO) {
        this.moveNextToParent(OO), OO.forEachChild(((OO, KO) => this.recursivelyMoveNextToParent(OO)))
      }
      moveNextToParent(OO) {
        OO.changesNode && this._moveNextToParentInList(this.changes, OO, OO.changesNode, "changesNode"), OO.unreliableChangesNode && this._moveNextToParentInList(this.unreliableChanges, OO, OO.unreliableChangesNode, "unreliableChangesNode")
      }
      _moveNextToParentInList(OO, KO, pO, XO) {
        const bK = KO.parent;
        if (!bK || !bK[VO]) return;
        const eO = bK[VO][XO];
        eO && eO !== pO && (pO.position > eO.position || (pO.prev ? pO.prev.next = pO.next : OO.next = pO.next, pO.next ? pO.next.prev = pO.prev : OO.tail = pO.prev, pO.prev = OO.tail, pO.next = void 0, OO.tail.next = pO, OO.tail = pO, pO.position = OO.nextPosition++))
      }
      enqueueChangeTree(OO) {
        (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO.changesNode) || (OO.changesNode = this._appendToList(this.changes, OO))
      }
      enqueueUnreliable(OO) {
        (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO.unreliableChangesNode) || (OO.unreliableChangesNode = this._appendToList(this.unreliableChanges, OO))
      }
      _appendToList(OO, KO) {
        const pO = this._nodePool;
        let XO;
        return pO.length > 0 ? (XO = pO.pop(), XO.changeTree = KO, XO.next = void 0, XO.prev = void 0) : XO = {
          changeTree: KO,
          next: void 0,
          prev: void 0,
          position: 0
        }, OO.next ? (XO.prev = OO.tail, OO.tail.next = XO, OO.tail = XO) : (OO.nextPosition = 0, OO.next = XO, OO.tail = XO), XO.position = OO.nextPosition++, XO
      }
      releaseNode(OO) {
        OO.changeTree = void 0, OO.prev = void 0, OO.next = void 0, this._nodePool.push(OO)
      }
      removeFromQueue(OO) {
        return this._removeNode(this.changes, OO, OO.changesNode, "changesNode")
      }
      removeFromUnreliableQueue(OO) {
        return this._removeNode(this.unreliableChanges, OO, OO.unreliableChangesNode, "unreliableChangesNode")
      }
      _removeNode(OO, KO, pO, XO) {
        return !(!pO || pO.changeTree !== KO) && (pO.prev ? pO.prev.next = pO.next : OO.next = pO.next, pO.next ? pO.next.prev = pO.prev : OO.tail = pO.prev, KO[XO] = void 0, this.releaseNode(pO), !0)
      }
    }

    function wX(OO, KO) {
      if (-1 === KO || KO >= OO.length) return !1;
      const pO = OO.length - 1;
      for (let XO = KO; XO < pO; XO++) OO[XO] = OO[XO + 1];
      return OO.length = pO, !0
    }

    function ib(OO, KO, pO) {
      const XO = ~pO,
        bK = OO.changeTrees;
      for (const eO in bK) {
        const OO = bK[eO],
          pO = OO.visibleViews;
        void 0 !== pO && KO < pO.length && (pO[KO] &= XO);
        const lO = OO.subscribedViews;
        void 0 !== lO && KO < lO.length && (lO[KO] &= XO);
        const vK = OO.tagViews;
        void 0 !== vK && vK.forEach((OO => {
          KO < OO.length && (OO[KO] &= XO)
        }))
      }
    }
    const rb = new FinalizationRegistry((OO => {
      let {
        root: KO,
        id: pO,
        slot: XO,
        bit: bK
      } = OO;
      ib(KO, XO, bK), KO.activeViews.delete(pO);
      for (const eO of KO.streamTrees) eO._dropView(pO);
      KO.releaseViewId(pO)
    }));

    function PX(OO) {
      if (void 0 === OO) return "undefined";
      if (null === OO) return "null";
      const KO = typeof OO;
      return "string" === KO ? JSON.stringify(OO.length > 30 ? `${OO.slice(0,30)}\u2026` : OO) : "object" !== KO && "function" !== KO ? `${KO} ${String(OO)}` : Array.isArray(OO) ? `Array(${OO.length})` : OO.constructor?.name ?? "Object"
    }
    class mb {
      iterable;
      items;
      id = -1;
      _root;
      _slot = 0;
      _bit = 0;
      changes = new Map;
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        this.iterable = OO, OO && (this.items = [])
      }
      _bindRoot(OO) {
        void 0 === this._root && (this._root = OO, this.id = OO.acquireViewId(), this._slot = this.id >> 5, this._bit = 1 << (31 & this.id), OO.registerView(this), rb.register(this, {
          root: OO,
          id: this.id,
          slot: this._slot,
          bit: this._bit
        }, this))
      }
      dispose() {
        void 0 !== this._root && (this._root.unregisterView(this), ib(this._root, this._slot, this._bit), this._root.releaseViewId(this.id), rb.unregister(this), this._root = void 0, this.id = -1)
      }
      isVisible(OO) {
        const KO = OO.visibleViews,
          pO = this._slot;
        return void 0 !== KO && pO < KO.length && 0 !== (KO[pO] & this._bit)
      }
      markVisible(OO) {
        const KO = this._slot;
        let pO = OO.visibleViews;
        for (void 0 === pO && (pO = OO.visibleViews = []); pO.length <= KO;) pO.push(0);
        pO[KO] |= this._bit
      }
      unmarkVisible(OO) {
        const KO = OO.visibleViews;
        if (void 0 === KO) return;
        const pO = this._slot;
        pO < KO.length && (KO[pO] &= ~this._bit)
      }
      isSubscribed(OO) {
        const KO = OO.subscribedViews,
          pO = this._slot;
        return void 0 !== KO && pO < KO.length && 0 !== (KO[pO] & this._bit)
      }
      _setSubscribed(OO) {
        const KO = this._slot;
        let pO = OO.subscribedViews;
        for (void 0 === pO && (pO = OO.subscribedViews = []); pO.length <= KO;) pO.push(0);
        pO[KO] |= this._bit
      }
      _clearSubscribed(OO) {
        const KO = OO.subscribedViews;
        if (void 0 === KO) return;
        const pO = this._slot;
        pO < KO.length && (KO[pO] &= ~this._bit)
      }
      hasTagOnTree(OO, KO) {
        const pO = OO.tagViews;
        if (void 0 === pO) return !1;
        const XO = this._slot,
          bK = this._bit;
        for (let eO = KO; 0 !== eO; eO &= eO - 1) {
          const OO = pO.get(eO & -eO);
          if (void 0 !== OO && XO < OO.length && 0 !== (OO[XO] & bK)) return !0
        }
        return !1
      }
      addTag(OO, KO) {
        if (KO === FX) return;
        let pO = OO.tagViews;
        void 0 === pO && (pO = OO.tagViews = new Map);
        const XO = this._slot,
          bK = this._bit;
        for (let eO = KO; eO > 0; eO &= eO - 1) {
          const OO = eO & -eO;
          let KO = pO.get(OO);
          for (void 0 === KO && (KO = [], pO.set(OO, KO)); KO.length <= XO;) KO.push(0);
          KO[XO] |= bK
        }
      }
      removeTag(OO, KO) {
        if (KO === FX) return;
        const pO = OO.tagViews;
        if (void 0 === pO) return;
        const XO = this._slot,
          bK = ~this._bit;
        for (let eO = KO; eO > 0; eO &= eO - 1) {
          const OO = pO.get(eO & -eO);
          void 0 !== OO && XO < OO.length && (OO[XO] &= bK)
        }
      }
      removeAllTagsOnTree(OO) {
        const KO = OO.tagViews;
        if (void 0 === KO) return;
        const pO = this._slot,
          XO = ~this._bit;
        KO.forEach((OO => {
          pO < OO.length && (OO[pO] &= XO)
        }))
      }
      add(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : FX,
          pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        return this._add(OO, KO, pO, !1)
      }
      _addImmediate(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : FX;
        this._add(OO, KO, !0, !0)
      }
      _add(OO, KO, pO, XO) {
        const eO = OO?.[VO];
        if (!eO) return console.warn(`StateView#add(): expected a Schema instance or collection, received ${PX(OO)}`), !1;
        const lO = eO.parent;
        if (!lO && 0 !== OO[vK]) throw new Error(`Cannot add a detached instance to the StateView. Make sure to assign the "${eO.ref.constructor.name}" instance to the state before calling view.add()`);
        void 0 === this._root && void 0 !== eO.root && this._bindRoot(eO.root);
        const CO = lO?.[VO];
        if (!XO && CO?.isStreamCollection) return wK(lO, this.id, eO.parentIndex), !0;
        const hO = OO.constructor[Symbol.metadata],
          DO = this.isVisible(eO);
        if (!this.iterable || !pO || DO && -1 !== this.items.indexOf(OO) || this.items.push(OO), this.markVisible(eO), pO && lO && this.addParentOf(eO, KO), !XO && eO.isStreamCollection) return !0;
        if (KO === FX && eO.isNew) return this._markSubtreeVisible(eO, KO), !1;
        let MO = this.changes.get(OO[vK]);
        void 0 === MO && (MO = new Map, this.changes.set(OO[vK], MO));
        let aK = !1;
        const oO = eO.encDescriptor.tags;
        if (eO.forEachChild(((OO, pO) => {
            const XO = oO[pO];
            if (void 0 !== XO) {
              if (!(XO === FX || KO !== FX && 0 !== (XO & KO))) return
            }
            this.add(OO.ref, KO, !1) && (aK = !0)
          })), KO !== FX) {
          this.addTag(eO, KO);
          const OO = hO?.[jK];
          if (void 0 !== OO)
            for (let pO = KO; pO > 0; pO &= pO - 1) OO[pO & -pO]?.forEach((OO => {
              eO.getChange(OO) !== bK.DELETE && MO.set(OO, bK.ADD)
            }))
        }
        if ((KO === FX || !DO) && (!eO.isNew || aK))
          if (eO.isArray && "string" !== typeof eO.refTarget[LO]) eO.refTarget.items.length > 0 && (MO.set(-1, bK.ADD), aK = !0);
          else {
            const OO = eO.encDescriptor.tags;
            eO.forEachLive((pO => {
              const XO = OO[pO];
              (void 0 === XO || XO === FX || KO !== FX && 0 !== (XO & KO)) && (MO.set(pO, bK.ADD), aK = !0)
            }))
          } return aK
      }
      _markSubtreeVisible(OO, KO) {
        const pO = OO.encDescriptor.tags;
        OO.forEachChild(((OO, XO) => {
          const bK = pO[XO];
          if (void 0 !== bK) {
            if (!(bK === FX || KO !== FX && 0 !== (bK & KO))) return
          }
          OO.isNew ? (this.markVisible(OO), this._markSubtreeVisible(OO, KO)) : this._add(OO.ref, KO, !1, !1)
        }))
      }
      addParentOf(OO, KO) {
        const pO = OO.parent[VO],
          XO = OO.parentIndex;
        this.isVisible(pO) || this.markVisible(pO);
        const eO = pO.parent?.[VO];
        if (eO && this.addParentOf(pO, KO), pO.hasFilteredFields && pO.getChange(XO) !== bK.DELETE) {
          let eO = this.changes.get(pO.ref[vK]);
          void 0 === eO && (eO = new Map, this.changes.set(pO.ref[vK], eO));
          const lO = pO.encDescriptor.tags[XO];
          void 0 !== lO && lO !== FX && 0 !== (lO & KO) && this.addTag(pO, KO), eO.set(pO.isArray ? OO : XO, bK.ADD)
        }
      }
      _touchAncestorsOf(OO) {
        let KO = OO.parent?.[VO];
        if (void 0 === KO) return;
        const pO = [];
        for (; void 0 !== KO;) {
          if (KO.hasFilteredFields) {
            const OO = KO.ref[vK];
            if (this.changes.has(OO)) break;
            pO.push(KO)
          }
          KO = KO.parent?.[VO]
        }
        for (let XO = pO.length - 1; XO >= 0; XO--) this.changes.set(pO[XO].ref[vK], new Map)
      }
      remove(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : FX,
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = OO?.[VO];
        if (!XO) return console.warn(`StateView#remove(): expected a Schema instance or collection, received ${PX(OO)}`), this;
        const eO = XO.parent?.[VO];
        if (eO?.isStreamCollection) return this.unmarkVisible(XO), this.iterable && !pO && wX(this.items, this.items.indexOf(OO)),
          function(OO, KO, pO, XO, eO) {
            const lO = OO._stream;
            if (void 0 === lO) return !1;
            const vK = lO.pendingByView.get(KO);
            if (vK?.has(XO)) return vK.delete(XO), !1;
            const CO = lO.sentByView.get(KO);
            if (CO?.has(XO)) {
              CO.delete(XO);
              let OO = eO.get(pO);
              return void 0 === OO && (OO = new Map, eO.set(pO, OO)), OO.set(XO, bK.DELETE), !0
            }
          }(XO.parent, this.id, XO.parent[vK], XO.parentIndex, this.changes), this._recursiveDeleteVisibleChangeTree(XO), this;
        if (XO.isStreamCollection) {
          this.unmarkVisible(XO), this.iterable && !pO && wX(this.items, this.items.indexOf(OO));
          const KO = XO.ref,
            eO = KO._stream;
          if (void 0 !== eO) {
            eO.pendingByView.get(this.id)?.clear();
            const OO = eO.sentByView.get(this.id);
            if (void 0 !== OO && OO.size > 0) {
              const pO = KO[vK];
              let XO = this.changes.get(pO);
              void 0 === XO && (XO = new Map, this.changes.set(pO, XO));
              for (const KO of OO) XO.set(KO, bK.DELETE);
              OO.clear()
            }
          }
          return this
        }
        this.unmarkVisible(XO), this.iterable && !pO && wX(this.items, this.items.indexOf(OO));
        const lO = XO.ref,
          CO = lO.constructor[Symbol.metadata],
          hO = lO[vK];
        this._touchAncestorsOf(XO);
        let DO = this.changes.get(hO);
        if (void 0 === DO && (DO = new Map, this.changes.set(hO, DO)), KO === FX) {
          const OO = XO.parent;
          if (OO && !xp.isValidInstance(OO) && XO.isFiltered) {
            const KO = eO.isArray ? XO : XO.parentIndex,
              pO = OO[vK];
            let lO = this.changes.get(pO);
            void 0 === lO ? (lO = new Map, this.changes.set(pO, lO)) : lO.get(KO) === bK.ADD && this._dropPendingEntries(XO), lO.set(KO, bK.DELETE), this._recursiveDeleteVisibleChangeTree(XO)
          } else CO?.[EO]?.forEach((OO => this._removeViewField(XO, DO, OO)))
        } else {
          const OO = CO?.[jK];
          if (void 0 !== OO)
            for (let pO = KO; pO > 0; pO &= pO - 1) OO[pO & -pO]?.forEach((OO => this._removeViewField(XO, DO, OO)))
        }
        return void 0 === KO ? this.removeAllTagsOnTree(XO) : this.removeTag(XO, KO), this
      }
      has(OO) {
        return this.isVisible(OO[VO])
      }
      hasTag(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : FX;
        return this.hasTagOnTree(OO[VO], KO)
      }
      subscribe(OO, KO) {
        const pO = OO?.[VO];
        if (!pO) return console.warn(`StateView#subscribe(): expected a Schema collection, received ${PX(OO)}`), this;
        if (void 0 === this._root && void 0 !== pO.root && this._bindRoot(pO.root), void 0 !== KO)
          if (pO.isStreamCollection) {
            const pO = gp(OO);
            null === KO ? pO.priorityByView?.delete(this.id) : (pO.priorityByView ??= new Map).set(this.id, KO)
          } else {
            const KO = OO?.constructor?.name ?? "collection",
              XO = pO.parent;
            if (void 0 === XO) console.warn(`StateView#subscribe(): \`priority\` ignored \u2014 this ${KO} is not attached to a state yet, so it cannot be identified as a stream. Subscribe after assigning it to the state.`);
            else {
              const OO = XO?.constructor?.[Symbol.metadata]?.[pO.parentIndex]?.name,
                bK = OO ? `${XO.constructor.name}#${OO}` : KO;
              console.warn(`StateView#subscribe(): \`priority\` ignored \u2014 ${bK} is a ${KO}, not a streaming collection. Declare the field with .stream() (e.g. t.map(X).stream()) or use t.stream(X) to enable priority batching.`)
            }
          } if (this.isSubscribed(pO)) return this;
        const XO = void 0 !== pO.parent && !this.isVisible(pO);
        if (XO ? (this.addParentOf(pO, FX), this._add(OO, FX, !1, !1)) : this.markVisible(pO), this._setSubscribed(pO), pO.isStreamCollection) {
          const KO = OO;
          pO.forEachChild(((OO, pO) => {
            wK(KO, this.id, pO)
          }))
        } else XO || pO.forEachChild((OO => {
          this.markVisible(OO)
        }));
        return this
      }
      unsubscribe(OO) {
        const KO = OO?.[VO];
        if (!KO) return console.warn(`StateView#unsubscribe(): expected a Schema collection, received ${PX(OO)}`), this;
        if (!this.isSubscribed(KO)) return this;
        this._clearSubscribed(KO);
        const pO = KO.ref[vK];
        if (KO.isStreamCollection) {
          const KO = OO._stream;
          if (void 0 !== KO) {
            KO.pendingByView.get(this.id)?.clear();
            const OO = KO.sentByView.get(this.id);
            if (void 0 !== OO && OO.size > 0) {
              let KO = this.changes.get(pO);
              void 0 === KO && (KO = new Map, this.changes.set(pO, KO));
              for (const pO of OO) KO.set(pO, bK.DELETE);
              OO.clear()
            }
          }
        } else {
          const OO = KO.isArray;
          let XO = this.changes.get(pO);
          KO.forEachChild(((KO, eO) => {
            void 0 === XO && (XO = new Map, this.changes.set(pO, XO)), XO.set(OO ? KO : eO, bK.DELETE), this.unmarkVisible(KO)
          }))
        }
        return this.unmarkVisible(KO), this
      }
      clear() {
        if (!this.iterable) throw new Error("StateView#clear() is only available for iterable StateView's. Use StateView(iterable: true) constructor.");
        for (let OO = 0, KO = this.items.length; OO < KO; OO++) this.remove(this.items[OO], FX, !0);
        this.items.length = 0
      }
      isChangeTreeVisible(OO) {
        let KO = this.isVisible(OO);
        if (!KO && OO.isVisibilitySharedWithParent)
          if (this.isVisible(OO.parent[VO])) this.markVisible(OO), KO = !0;
          else
            for (let pO = OO.extraParents; void 0 !== pO; pO = pO.next) {
              const XO = pO.ref[VO];
              if (XO.isFiltered && this.isVisible(XO)) {
                this.markVisible(OO), KO = !0;
                break
              }
            }
        return KO
      }
      _recursiveDeleteVisibleChangeTree(OO) {
        OO.forEachChild((OO => {
          this.unmarkVisible(OO), this._recursiveDeleteVisibleChangeTree(OO)
        }))
      }
      _dropPendingEntries(OO) {
        this.changes.delete(OO.ref[vK]), OO.forEachChild((OO => this._dropPendingEntries(OO)))
      }
      _removeViewField(OO, KO, pO) {
        const XO = KO.get(pO) === bK.ADD;
        KO.set(pO, bK.DELETE);
        const eO = OO.ref[OO.encDescriptor.names[pO]],
          lO = eO?.[VO];
        lO && (this.unmarkVisible(lO), this._recursiveDeleteVisibleChangeTree(lO), XO && this._dropPendingEntries(lO))
      }
    }

    function sX(OO) {
      OO.structSwitchEmitted || (OO.shouldEmitSwitch && (OO.buffer[OO.it.offset++] = 255, KK.number(OO.buffer, OO.ref[vK], OO.it)), OO.structSwitchEmitted = !0)
    }

    function HX(OO, KO) {
      JX(OO, KO, bK.ADD)
    }

    function RX(OO, KO) {
      if (KO._fullSyncGen === OO.gen) return;
      KO._fullSyncGen = OO.gen;
      if (!OO.hasView || OO.view.isChangeTreeVisible(KO)) {
        const pO = KO.encDescriptor;
        OO.changeTree = KO, OO.ref = KO.ref, OO.encoder = pO.encoder, OO.filter = pO.filter, OO.metadata = pO.metadata, OO.treeIsFiltered = KO.isFiltered, OO.isSchema = pO.isSchema, OO.filterBitmask = pO.filterBitmask, OO.tags = pO.tags, OO.structSwitchEmitted = !1, OO.shouldEmitSwitch = OO.hasView || OO.it.offset > OO.initialOffset || KO !== OO.rootChangeTree, KO.isArray && KO.collDirty.size > 0 && (KO.flags |= 512), bX(KO, OO, HX)
      }
      Qp(KO, OO, SX)
    }

    function SX(OO, KO, pO) {
      RX(OO, KO)
    }

    function JX(OO, KO, pO) {
      if (KO < 0) {
        if (OO.treeIsFiltered !== OO.emitFiltered) return;
        return sX(OO), void(OO.buffer[OO.it.offset++] = 255 & Math.abs(KO))
      }
      if ((OO.isSchema ? OO.treeIsFiltered || (KO < 32 ? 0 !== (OO.filterBitmask & 1 << KO) : void 0 !== OO.tags[KO]) : OO.treeIsFiltered) !== OO.emitFiltered) return;
      const XO = OO.isEncodeAll ? bK.ADD : pO;
      void 0 !== XO && (void 0 === OO.filter || OO.filter(OO.ref, KO, OO.view)) && (sX(OO), OO.encoder(OO.self, OO.buffer, OO.changeTree, KO, XO, OO.it, OO.isEncodeAll, OO.hasView, OO.metadata))
    }

    function cb(OO, KO) {
      const pO = new Uint8Array(OO.length + KO.length);
      return pO.set(OO, 0), pO.set(KO, OO.length), pO
    }
    class BX {
      static BUFFER_SIZE = 16384;
      sharedBuffer = new Uint8Array(BX.BUFFER_SIZE);
      context;
      state;
      root;
      constructor(OO, KO) {
        this.context = SK.cache(OO.constructor), this.root = KO ?? new YX(this.context), this.setState(OO)
      }
      setState(OO) {
        this.state = OO, this.state[VO].setRoot(this.root)
      }
      _encodeCtx = {
        self: void 0,
        buffer: void 0,
        it: void 0,
        changeTree: void 0,
        ref: void 0,
        encoder: void 0,
        filter: void 0,
        metadata: void 0,
        view: void 0,
        isEncodeAll: !1,
        hasView: !1,
        treeIsFiltered: !1,
        isSchema: !1,
        emitFiltered: !1,
        filterBitmask: 0,
        tags: void 0,
        structSwitchEmitted: !1,
        isRootTree: !1,
        shouldEmitSwitch: !1,
        gen: 0,
        initialOffset: 0,
        rootChangeTree: void 0
      };
      _fullSyncGen = 0;
      encode() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            offset: 0
          },
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.sharedBuffer,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : OO.offset;
        return this._encodeChannel(OO, KO, pO, XO, !1)
      }
      encodeUnreliable() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            offset: 0
          },
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.sharedBuffer,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : OO.offset;
        return this._encodeChannel(OO, KO, pO, XO, !0)
      }
      _encodeChannel(OO, KO, pO, XO, bK) {
        this.root.pendingFilterRefresh.length > 0 && lp(this.root);
        const eO = void 0 !== KO,
          lO = this.state[VO],
          vK = this._encodeCtx;
        vK.self = this, vK.buffer = pO, vK.it = OO, vK.view = KO, vK.isEncodeAll = !1, vK.hasView = eO, vK.emitFiltered = eO;
        let CO = bK ? this.root.unreliableChanges : this.root.changes;
        for (; CO = CO.next;) {
          const pO = CO.changeTree;
          if (eO && !KO.isChangeTreeVisible(pO)) continue;
          const hO = bK ? pO.unreliableRecorder : pO;
          if (!hO || !hO.has()) continue;
          const DO = pO.encDescriptor;
          vK.changeTree = pO, vK.ref = pO.ref, vK.encoder = DO.encoder, vK.filter = DO.filter, vK.metadata = DO.metadata, vK.treeIsFiltered = pO.isFiltered, vK.isSchema = DO.isSchema, vK.filterBitmask = DO.filterBitmask, vK.tags = DO.tags, vK.structSwitchEmitted = !1, vK.isRootTree = pO === lO, vK.shouldEmitSwitch = eO || OO.offset > XO || !vK.isRootTree, hO.forEachWithCtx(vK, JX)
        }
        return bK || eO || !this._isStreamBroadcastMode || this._emitStreamBroadcast(pO, OO), OO.offset > pO.byteLength ? (pO = this._resizeBuffer(pO, OO.offset), OO.offset = XO, this._encodeChannel(OO, KO, pO, XO, bK)) : pO.subarray(0, OO.offset)
      }
      encodeFullSync(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : OO.offset;
        this.root.pendingFilterRefresh.length > 0 && lp(this.root);
        const eO = void 0 !== XO,
          lO = this.state[VO],
          vK = this._encodeCtx;
        return vK.self = this, vK.buffer = KO, vK.it = OO, vK.view = XO, vK.isEncodeAll = !0, vK.hasView = eO, vK.emitFiltered = pO, vK.gen = ++this._fullSyncGen, vK.initialOffset = bK, vK.rootChangeTree = lO, RX(vK, lO), OO.offset > KO.byteLength ? (KO = this._resizeBuffer(KO, OO.offset), OO.offset = bK, this.encodeFullSync(OO, KO, pO, XO, bK)) : KO.subarray(0, OO.offset)
      }
      _resizeBuffer(OO, KO) {
        const pO = Math.ceil(KO / BX.BUFFER_SIZE) * BX.BUFFER_SIZE,
          XO = new Uint8Array(pO);
        return XO.set(OO), OO === this.sharedBuffer && (this.sharedBuffer = XO), XO
      }
      encodeAll() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            offset: 0
          },
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.sharedBuffer;
        return this.encodeFullSync(OO, KO, !1)
      }
      encodeAllView(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : this.sharedBuffer;
        const bK = pO.offset;
        return XO = this.encodeFullSync(pO, XO, !0, OO, bK), cb(XO.subarray(0, KO), XO.subarray(bK, pO.offset))
      }
      ensureCapacity(OO, KO) {
        if (KO + BX.BUFFER_SIZE <= OO.byteLength) return OO;
        const pO = Math.ceil((KO + BX.BUFFER_SIZE) / BX.BUFFER_SIZE) * BX.BUFFER_SIZE,
          XO = new Uint8Array(pO);
        return XO.set(OO.subarray(0, KO)), OO === this.sharedBuffer && (this.sharedBuffer = XO), XO
      }
      encodeView(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : this.sharedBuffer,
          eO = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4];
        const lO = pO.offset;
        this._emitStreamPriority(OO);
        for (const CO of OO.changes.keys()) {
          const KO = OO.changes.get(CO),
            eO = this.root.changeTrees[CO];
          if (void 0 === eO) {
            OO.changes.delete(CO);
            continue
          }
          if (0 === KO.size) continue;
          const lO = eO.encDescriptor,
            hO = lO.encoder,
            DO = lO.metadata,
            MO = eO.ref,
            oO = eO.refTarget;
          XO = this.ensureCapacity(XO, pO.offset), XO[pO.offset++] = 255, KK.number(XO, MO[vK], pO);
          for (const [CO, FO] of KO) {
            let KO;
            if (-1 === CO) {
              const OO = oO.tmpItems,
                KO = oO.deletedIndexes;
              for (let lO = 0; lO < OO.length; lO++) void 0 !== OO[lO] && !0 !== KO[lO] && hO(this, XO, eO, lO, bK.ADD, pO, !1, !0, DO);
              continue
            }
            if ("number" === typeof CO) KO = CO;
            else {
              const pO = CO.indexInParent(MO);
              if (void 0 === pO) continue;
              if (KO = pO, FO === bK.ADD && eO.getChange(KO) === bK.DELETE) {
                OO.changes.delete(CO.ref[vK]);
                continue
              }
            }
            hO(this, XO, eO, KO, void 0 !== oO[aK](KO) && FO || bK.DELETE, pO, !1, !0, DO)
          }
        }
        return OO.changes.clear(), XO = this.encode(pO, OO, XO), eO ? cb(XO.subarray(0, KO), XO.subarray(lO, pO.offset)) : XO.subarray(lO, pO.offset)
      }
      encodeUnreliableView(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : this.sharedBuffer;
        const bK = pO.offset;
        return XO = this.encodeUnreliable(pO, OO, XO, bK), cb(XO.subarray(0, KO), XO.subarray(bK, pO.offset))
      }
      _emitStreamBroadcast(OO, KO) {
        const pO = this.root.streamTrees;
        for (const XO of pO) {
          const pO = XO,
            eO = pO[VO],
            lO = pO[vK];
          if (void 0 === lO) continue;
          const CO = pO._stream,
            hO = CO.broadcastDeletes,
            DO = CO.broadcastPending,
            MO = CO.sentBroadcast,
            oO = hO.size > 0,
            FO = DO.size > 0,
            LO = eO.encDescriptor,
            QO = LO.encoder,
            zK = LO.metadata;
          if (oO || FO) {
            if (OO[KO.offset++] = 255, KK.number(OO, lO, KO), oO) {
              for (const pO of hO) QO(this, OO, eO, pO, bK.DELETE, KO, !1, !1, zK);
              hO.clear()
            }
            const XO = CO.maxPerTick,
              FO = [];
            let LO = 0;
            const AO = [];
            for (const lO of DO) {
              if (LO >= XO) break;
              const vK = pO[aK](lO);
              void 0 !== vK ? (QO(this, OO, eO, lO, bK.ADD, KO, !1, !1, zK), MO.add(lO), FO.push(vK), AO.push(lO), LO++) : AO.push(lO)
            }
            for (const OO of AO) DO.delete(OO);
            for (const pO of FO) {
              const XO = pO[VO];
              if (void 0 === XO) continue;
              const eO = pO[vK];
              if (void 0 === eO) continue;
              OO[KO.offset++] = 255, KK.number(OO, eO, KO);
              const lO = XO.encDescriptor,
                CO = lO.encoder,
                hO = lO.metadata;
              XO.forEachLive((pO => {
                xp.hasUnreliableAtIndex(hO, pO) || CO(this, OO, XO, pO, bK.ADD, KO, !1, !1, hO)
              }))
            }
          }
          for (const XO of MO) {
            const bK = pO[aK](XO);
            if (void 0 === bK) continue;
            const eO = bK[VO];
            if (void 0 === eO || !eO.has()) continue;
            const lO = bK[vK];
            if (void 0 === lO) continue;
            OO[KO.offset++] = 255, KK.number(OO, lO, KO);
            const CO = eO.encDescriptor,
              hO = CO.encoder,
              DO = CO.metadata;
            eO.forEach(((pO, XO) => {
              pO < 0 || xp.hasUnreliableAtIndex(DO, pO) || hO(this, OO, eO, pO, XO, KO, !1, !1, DO)
            }))
          }
        }
      }
      _emitStreamPriority(OO) {
        const KO = this.root.streamTrees;
        if (0 === KO.size) return;
        const pO = OO.id;
        for (const XO of KO) {
          const KO = XO,
            eO = KO._stream,
            lO = eO.pendingByView.get(pO);
          if (void 0 === lO || 0 === lO.size) continue;
          const CO = eO.priorityByView?.get(pO),
            hO = void 0 !== CO,
            DO = eO.priority,
            MO = eO.maxPerTick,
            oO = [],
            FO = [];
          if (hO || void 0 !== DO) {
            const pO = [],
              XO = [];
            let bK = 0;
            for (const eO of lO) {
              const lO = KO[aK](eO);
              if (void 0 === lO) {
                FO.push(eO);
                continue
              }
              const vK = hO ? CO(lO) : DO(OO, lO);
              if (bK < MO) {
                let OO = bK++;
                for (; OO > 0 && XO[OO - 1] < vK;) XO[OO] = XO[OO - 1], pO[OO] = pO[OO - 1], OO--;
                XO[OO] = vK, pO[OO] = eO
              } else if (vK > XO[MO - 1]) {
                let OO = MO - 1;
                for (; OO > 0 && XO[OO - 1] < vK;) XO[OO] = XO[OO - 1], pO[OO] = pO[OO - 1], OO--;
                XO[OO] = vK, pO[OO] = eO
              }
            }
            for (let OO = 0; OO < bK; OO++) oO.push(pO[OO])
          } else
            for (const OO of lO) {
              if (oO.length >= MO) break;
              oO.push(OO)
            }
          for (const OO of FO) lO.delete(OO);
          const LO = oO.length;
          let QO = eO.sentByView.get(pO);
          void 0 === QO && (QO = new Set, eO.sentByView.set(pO, QO));
          for (let pO = 0; pO < LO; pO++) {
            const XO = oO[pO],
              eO = KO[aK](XO);
            if (void 0 === eO) {
              lO.delete(XO);
              continue
            }
            OO._addImmediate(eO);
            const CO = eO[VO];
            if (void 0 !== CO) {
              const KO = eO[vK];
              let pO = OO.changes.get(KO);
              void 0 === pO && (pO = new Map, OO.changes.set(KO, pO));
              const XO = CO.metadata;
              CO.forEachLive((OO => {
                xp.hasUnreliableAtIndex(XO, OO) || pO.set(OO, bK.ADD)
              }))
            }
            lO.delete(XO), QO.add(XO)
          }
        }
      }
      discardChanges() {
        const OO = this.root.changes;
        let KO = OO.next;
        const pO = this.root;
        for (; KO;) {
          const OO = KO.next;
          KO.changeTree.endEncode(), pO.releaseNode(KO), KO = OO
        }
        OO.next = void 0, OO.tail = void 0
      }
      discardUnreliableChanges() {
        const OO = this.root.unreliableChanges;
        let KO = OO.next;
        const pO = this.root;
        for (; KO;) {
          const OO = KO.next;
          KO.changeTree.endEncodeUnreliable(), pO.releaseNode(KO), KO = OO
        }
        OO.next = void 0, OO.tail = void 0
      }
      tryEncodeTypeId(OO, KO, pO, XO) {
        const bK = this.context.getTypeId(KO),
          eO = this.context.getTypeId(pO);
        void 0 !== eO ? bK !== eO && (OO[XO.offset++] = 213, KK.number(OO, eO, XO)) : console.warn(`@colyseus/schema WARNING: Class "${pO.name}" is not registered on TypeRegistry - Please either tag the class with @entity or define a @type() field.`)
      }
      get hasChanges() {
        return void 0 !== this.root.changes.next || this._hasStreamBacklog()
      }
      get _isStreamBroadcastMode() {
        return 0 === this.root.activeViews.size && this.root.streamTrees.size > 0
      }
      _hasStreamBacklog() {
        const OO = this.root;
        if (0 === OO.streamTrees.size) return !1;
        const KO = 0 === OO.activeViews.size;
        for (const pO of OO.streamTrees)
          if (KO ? YK(pO) : jp(pO, OO)) return !0;
        return !1
      }
      get hasUnreliableChanges() {
        return void 0 !== this.root.unreliableChanges.next
      }
    }
    class ZX extends Error {
      constructor(OO) {
        super(OO), this.name = "DecodingWarning"
      }
    }
    const GX = {
      value: 0,
      enumerable: !1,
      writable: !0
    };
    class qb {
      refs = new Map;
      refCount = {};
      deletedRefs = new Set;
      callbacks = {};
      nextUniqueId = 0;
      getNextUniqueId() {
        return this.nextUniqueId++
      }
      addRef(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        this.refs.set(OO, KO), void 0 === KO[vK] ? (GX.value = OO, Object.defineProperty(KO, vK, GX)) : KO[vK] !== OO && (KO[vK] = OO), pO && (this.refCount[OO] = (this.refCount[OO] || 0) + 1), this.deletedRefs.has(OO) && this.deletedRefs.delete(OO)
      }
      removeRef(OO) {
        const KO = this.refCount[OO];
        if (void 0 !== KO)
          if (0 !== KO)(this.refCount[OO] = KO - 1) <= 0 && this.deletedRefs.add(OO);
          else try {
            const KO = this.refs.get(OO);
            throw new ZX(`trying to remove refId '${OO}' with 0 refCount (${KO.constructor.name}: ${JSON.stringify(KO)})`)
          } catch (eb) {
            console.warn(eb)
          } else try {
            throw new ZX("trying to remove refId that doesn't exist: " + OO)
          } catch (eb) {
            console.warn(eb)
          }
      }
      clearRefs() {
        this.refs.clear(), this.deletedRefs.clear(), this.callbacks = {}, this.refCount = {}
      }
      garbageCollectDeletedRefs() {
        this.deletedRefs.forEach((OO => {
          if (this.refCount[OO] > 0) return;
          const KO = this.refs.get(OO),
            pO = KO.constructor[Symbol.metadata];
          if (null != pO)
            for (const XO in pO) {
              const OO = KO[pO[XO].name];
              if ("object" === typeof OO && OO) {
                const KO = OO[vK];
                void 0 === KO || this.deletedRefs.has(KO) || this.removeRef(KO)
              }
            } else "function" === typeof KO[LO] && Array.from(KO.values()).forEach((OO => {
              const KO = OO[vK];
              void 0 === KO || this.deletedRefs.has(KO) || this.removeRef(KO)
            }));
          this.refs.delete(OO), delete this.refCount[OO], delete this.callbacks[OO]
        })), this.deletedRefs.clear()
      }
      addCallback(OO, KO, pO) {
        if (void 0 === OO) {
          const OO = "number" === typeof KO ? bK[KO] : KO;
          throw new Error(`Can't addCallback on '${OO}' (refId is undefined)`)
        }
        return this.callbacks[OO] || (this.callbacks[OO] = {}), this.callbacks[OO][KO] || (this.callbacks[OO][KO] = []), this.callbacks[OO][KO].push(pO), () => this.removeCallback(OO, KO, pO)
      }
      removeCallback(OO, KO, pO) {
        const XO = this.callbacks?.[OO]?.[KO]?.indexOf(pO);
        void 0 !== XO && -1 !== XO && wX(this.callbacks[OO][KO], XO)
      }
    }
    class xb {
      context;
      state;
      root;
      currentRefId = 0;
      mpO;
      resyncVisited = null;
      resyncDamaged = !1;
      constructor(OO, KO) {
        this.setState(OO), this.context = KO || new SK(OO.constructor)
      }
      setState(OO) {
        this.state = OO, this.root = new qb, this.root.addRef(0, OO)
      }
      decode(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
            offset: 0
          },
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.state;
        const bK = void 0 !== this.mpO ? [] : null,
          eO = this.root,
          lO = OO.byteLength;
        let vK = pO.constructor[DO];
        for (this.currentRefId = 0; KO.offset < lO;) {
          if (OO[KO.offset] == XO) {
            KO.offset++, pO[fO]?.();
            const XO = AK.number(OO, KO),
              bK = eO.refs.get(XO);
            bK ? (pO = bK, vK = pO.constructor[DO], this.currentRefId = XO) : (console.error(`"refId" not found: ${XO}`, {
              previousRef: pO,
              previousRefId: this.currentRefId
            }), console.warn("Please report this issue to the developers."), this.skipCurrentStructure(OO, KO, lO));
            continue
          } - 1 !== vK(this, OO, KO, pO, bK) || (console.warn("@colyseus/schema: definition mismatch"), this.skipCurrentStructure(OO, KO, lO))
        }
        return pO[fO]?.(), null !== this.resyncVisited && function(OO, KO) {
          OO.resyncDamaged ? console.warn("@colyseus/schema: resync sweep skipped \u2014 parts of the payload could not be decoded. Stale entries may persist until the next resync.") : Sp(OO, OO.state, new Set, KO)
        }(this, bK), null !== bK && this.mpO?.(bK), eO.garbageCollectDeletedRefs(), bK
      }
      decodeResync(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
          offset: 0
        };
        this.resyncVisited = new Map, this.resyncDamaged = !1;
        try {
          return this.decode(OO, KO)
        } finally {
          this.resyncVisited = null
        }
      }
      skipCurrentStructure(OO, KO, pO) {
        null !== this.resyncVisited && (this.resyncDamaged = !0);
        const bK = {
          offset: KO.offset
        };
        for (; KO.offset < pO && (OO[KO.offset] !== XO || (bK.offset = KO.offset + 1, !this.root.refs.has(AK.number(OO, bK))));) KO.offset++
      }
      getInstanceType(OO, KO, pO) {
        let XO;
        if (213 === OO[KO.offset]) {
          KO.offset++;
          const pO = AK.number(OO, KO);
          XO = this.context.get(pO)
        }
        return XO || pO
      }
      createInstanceOfType(OO) {
        return OO.initializeForDecoder()
      }
      removeChildRefs(OO, KO) {
        const pO = "string" !== typeof OO[LO],
          XO = OO[vK];
        OO.forEach(((eO, lO) => {
          KO?.push({
            ref: OO,
            refId: XO,
            op: bK.DELETE,
            field: lO,
            value: void 0,
            previousValue: eO
          }), pO && this.root.removeRef(eO[vK])
        }))
      }
    }
    const nX = gb({
        min: oX.float64(),
        max: oX.float64(),
        bits: oX.uint8(),
        mode: oX.uint8()
      }, "QuantizedDescriptor"),
      WX = gb({
        name: oX.string(),
        type: oX.string(),
        referencedType: oX.number(),
        childPrimitive: oX.string(),
        quantized: oX.ref(nX).optional()
      }, "ReflectionField"),
      tb = gb({
        id: oX.number(),
        extendsId: oX.number(),
        fields: oX.array(WX)
      }, "ReflectionType"),
      kb = gb({
        types: oX.array(tb),
        rootType: oX.number()
      }, "Reflection");

    function UX(OO) {
      const KO = OO.root,
        pO = KO.callbacks,
        XO = new WeakMap;
      let eO;

      function lO(OO, pO) {
        let hO = pO.instance?.constructor[Symbol.metadata] || OO,
          DO = pO.instance && "function" === typeof pO.instance.forEach || OO && !EX.is(OO);
        if (hO && !DO) {
          const OO = function(OO, bK, lO, CO) {
            return CO && void 0 !== pO.instance[bK] && !XO.has(eO) && lO(pO.instance[bK], void 0), KO.addCallback(OO[vK], bK, lO)
          };
          return new Proxy({
            listen: function(KO, bK) {
              let lO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
              if (pO.instance) return OO(pO.instance, KO, bK, lO);
              {
                let vK = () => {};
                return pO.onInstanceAvailable(((pO, CO) => {
                  vK = OO(pO, KO, bK, lO && CO && !XO.has(eO))
                })), () => vK()
              }
            },
            onChange: function(OO) {
              return KO.addCallback(pO.instance[vK], bK.REPLACE, OO)
            },
            bindTo: function(OO, XO) {
              return XO || (XO = Object.keys(hO).map((OO => hO[OO].name))), KO.addCallback(pO.instance[vK], bK.REPLACE, (() => {
                XO.forEach((KO => OO[KO] = pO.instance[KO]))
              }))
            }
          }, {
            get(OO, KO) {
              const XO = hO[hO[KO]];
              if (XO) {
                const OO = pO.instance?.[KO],
                  bK = XO => {
                    const bK = CO(pO.instance).listen(KO, ((OO, KO) => {
                      XO(OO, !1), bK?.()
                    }), !1);
                    void 0 !== OO?.[vK] && XO(OO, !0)
                  };
                return lO(XO.type, {
                  instance: void 0 !== OO?.[vK] && OO,
                  parentInstance: pO.instance,
                  onInstanceAvailable: bK
                })
              }
              return OO[KO]
            },
            has: (OO, KO) => void 0 !== hO[KO],
            set(OO, KO, pO) {
              throw new Error("not allowed")
            },
            deleteProperty(OO, KO) {
              throw new Error("not allowed")
            }
          })
        } {
          const OO = function(OO, pO, lO) {
              return lO && OO.forEach(((OO, KO) => pO(OO, KO))), KO.addCallback(OO[vK], bK.ADD, ((OO, KO) => {
                XO.set(pO, !0), eO = pO, pO(OO, KO), XO.delete(pO), eO = void 0
              }))
            },
            lO = function(OO, pO) {
              return KO.addCallback(OO[vK], bK.DELETE, pO)
            },
            CO = function(OO, pO) {
              return KO.addCallback(OO[vK], bK.REPLACE, pO)
            };
          return new Proxy({
            qL: function(KO) {
              let bK = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
              if (pO.instance) return OO(pO.instance, KO, bK && !XO.has(eO));
              if (pO.onInstanceAvailable) {
                let lO = () => {};
                return pO.onInstanceAvailable(((pO, vK) => {
                  lO = OO(pO, KO, bK && vK && !XO.has(eO))
                })), () => lO()
              }
            },
            ypO: function(OO) {
              if (pO.instance) return lO(pO.instance, OO);
              if (pO.onInstanceAvailable) {
                let KO = () => {};
                return pO.onInstanceAvailable((pO => {
                  KO = lO(pO, OO)
                })), () => KO()
              }
            },
            onChange: function(OO) {
              if (pO.instance) return CO(pO.instance, OO);
              if (pO.onInstanceAvailable) {
                let KO = () => {};
                return pO.onInstanceAvailable((pO => {
                  KO = CO(pO, OO)
                })), () => KO()
              }
            }
          }, {
            get(OO, KO) {
              if (!OO[KO]) throw new Error(`Can't access '${KO}' through callback proxy. access the instance directly.`);
              return OO[KO]
            },
            has: (OO, KO) => void 0 !== OO[KO],
            set(OO, KO, pO) {
              throw new Error("not allowed")
            },
            deleteProperty(OO, KO) {
              throw new Error("not allowed")
            }
          })
        }
      }

      function CO(OO) {
        return lO(void 0, {
          instance: OO
        })
      }
      return OO.mpO = function(OO) {
        const KO = new Set;
        for (let XO = 0, eO = OO.length; XO < eO; XO++) {
          const eO = OO[XO],
            lO = eO.refId,
            CO = eO.ref,
            hO = pO[lO];
          if (hO) {
            if ((eO.op & bK.DELETE) === bK.DELETE && EX.isSchema(eO.previousValue)) {
              const OO = pO[eO.previousValue[vK]]?.[bK.DELETE];
              for (let KO = OO?.length - 1; KO >= 0; KO--) OO[KO]()
            }
            if (EX.isSchema(CO)) {
              if (!KO.has(lO)) {
                const OO = hO?.[bK.REPLACE];
                for (let KO = OO?.length - 1; KO >= 0; KO--) OO[KO]()
              }
              if (hO.hasOwnProperty(eO.field)) {
                const OO = hO[eO.field];
                for (let KO = OO?.length - 1; KO >= 0; KO--) OO[KO](eO.value, eO.previousValue)
              }
            } else {
              if ((eO.op & bK.DELETE) === bK.DELETE) {
                if (void 0 !== eO.previousValue) {
                  const OO = hO[bK.DELETE];
                  for (let KO = OO?.length - 1; KO >= 0; KO--) OO[KO](eO.previousValue, eO.dynamicIndex ?? eO.field)
                }
                if ((eO.op & bK.ADD) === bK.ADD) {
                  const OO = hO[bK.ADD];
                  for (let KO = OO?.length - 1; KO >= 0; KO--) OO[KO](eO.value, eO.dynamicIndex ?? eO.field)
                }
              } else if ((eO.op & bK.ADD) === bK.ADD && eO.previousValue !== eO.value) {
                const OO = hO[bK.ADD];
                for (let KO = OO?.length - 1; KO >= 0; KO--) OO[KO](eO.value, eO.dynamicIndex ?? eO.field)
              }
              if (eO.value !== eO.previousValue && (void 0 !== eO.value || void 0 !== eO.previousValue)) {
                const OO = hO[bK.REPLACE];
                for (let KO = OO?.length - 1; KO >= 0; KO--) OO[KO](eO.value, eO.dynamicIndex ?? eO.field)
              }
            }
            KO.add(lO)
          }
        }
      }, CO
    }

    function Ob(OO, KO) {
      OO.mpO = KO
    }
    kb.encode = function(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
        offset: 0
      };
      const pO = OO.context,
        XO = new kb,
        bK = new BX(XO),
        eO = pO.schemas.get(OO.state.constructor);
      eO > 0 && (XO.rootType = eO);
      const lO = new Set,
        vK = {},
        CO = OO => {
          if (void 0 === OO.extendsId || lO.has(OO.extendsId)) {
            lO.add(OO.id), XO.types.push(OO);
            const KO = vK[OO.id];
            void 0 !== KO && (delete vK[OO.id], KO.forEach((OO => CO(OO))))
          } else void 0 === vK[OO.extendsId] && (vK[OO.extendsId] = []), vK[OO.extendsId].push(OO)
        };
      pO.schemas.forEach(((OO, KO) => {
        const XO = new tb;
        XO.id = Number(OO);
        const bK = Object.getPrototypeOf(KO);
        bK !== EX && (XO.extendsId = pO.schemas.get(bK));
        const eO = KO[Symbol.metadata];
        if (eO !== bK[Symbol.metadata]) {
          const OO = eO[gK] ?? -1;
          for (let KO = 0; KO <= OO; KO++) {
            const OO = eO[KO];
            if (void 0 === OO) continue;
            const bK = OO.name;
            if (!Object.prototype.hasOwnProperty.call(eO, bK)) continue;
            const lO = new WX;
            let vK;
            if (lO.name = bK, "string" === typeof OO.type) vK = OO.type;
            else if (mp(OO.type)) {
              const KO = OO.type.quantized;
              vK = "quantized";
              const pO = new nX;
              pO.min = KO.min, pO.max = KO.max, pO.bits = KO.bits, pO.mode = KO.wrap ? 1 : 0, lO.quantized = pO
            } else {
              let KO;
              EX.is(OO.type) ? (vK = "ref", KO = OO.type) : (vK = Object.keys(OO.type)[0], "string" === typeof OO.type[vK] ? lO.childPrimitive = OO.type[vK] : KO = OO.type[vK]), lO.referencedType = KO ? pO.getTypeId(KO) : -1
            }
            lO.type = vK, XO.fields.push(lO)
          }
        }
        CO(XO)
      }));
      for (const hO in vK) vK[hO].forEach((OO => XO.types.push(OO)));
      return bK.encodeAll(KO).slice(0, KO.offset)
    }, kb.decode = function(OO, KO) {
      const pO = new kb;
      new xb(pO).decode(OO, KO);
      const XO = new SK;
      pO.types.forEach((OO => {
        const KO = XO.get(OO.extendsId) ?? EX,
          pO = class extends KO {};
        SK.register(pO), XO.add(pO, OO.id)
      }), {});
      pO.types.forEach((OO => {
        const KO = XO.get(OO.id),
          bK = xp.initialize(KO),
          eO = [];
        let lO = OO;
        do {
          eO.push(lO), lO = pO.types.find((OO => OO.id === lO.extendsId))
        } while (lO);
        let vK = 0;
        eO.reverse().forEach((OO => {
          ((OO, KO, pO) => {
            KO.fields.forEach(((KO, bK) => {
              const eO = pO + bK;
              if (void 0 !== KO.quantized) {
                const pO = KO.quantized;
                xp.addField(OO, eO, KO.name, {
                  quantized: PK({
                    min: pO.min,
                    max: pO.max,
                    bits: pO.bits,
                    mode: 1 === pO.mode ? "wrap" : "clamp"
                  })
                })
              } else if (void 0 !== KO.referencedType) {
                const pO = KO.type,
                  bK = XO.get(KO.referencedType) ?? KO.childPrimitive;
                "ref" === pO ? xp.addField(OO, eO, KO.name, bK) : xp.addField(OO, eO, KO.name, {
                  [pO]: bK
                })
              } else xp.addField(OO, eO, KO.name, KO.type)
            }))
          })(bK, OO, vK), vK += OO.fields.length
        }))
      }));
      const bK = new(XO.get(pO.rootType || 0));
      return new xb(bK, XO)
    }, kb.makeEncodable = function(OO) {
      const KO = OO[Symbol.metadata];
      if (!KO) return OO;
      const pO = KO[gK];
      if (void 0 === pO) return OO;
      for (let XO = 0; XO <= pO; XO++) {
        const pO = KO[XO];
        pO && xp.defineField(OO, KO, XO, pO.name, pO.type)
      }
      return Object.prototype.hasOwnProperty.call(OO, IO) && delete OO[IO], OO
    };
    class Kb {
      be;
      uniqueRefIds = new Set;
      isTriggering = !1;
      constructor(OO) {
        this.be = OO, this.be.mpO = this.mpO.bind(this)
      }
      get callbacks() {
        return this.be.root.callbacks
      }
      get state() {
        return this.be.state
      }
      addCallback(OO, KO, pO) {
        return this.be.root.addCallback(OO, KO, pO)
      }
      addCallbackOrWaitCollectionAvailable(OO, KO, pO, XO) {
        let eO = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
          lO = () => {};
        const CO = () => lO(),
          hO = OO[KO];
        if (hO && void 0 !== hO[vK]) return eO = eO && !1 === this.isTriggering, pO === bK.ADD && eO && hO.forEach(((OO, KO) => {
          XO(OO, KO)
        })), this.addCallback(hO[vK], pO, XO);
        {
          let bK;
          return bK = this.addCallback(OO[vK], KO, ((OO, KO) => {
            null !== OO && void 0 !== OO && (bK(), lO = this.addCallback(OO[vK], pO, XO))
          })), lO = bK, CO
        }
      }
      listen() {
        return "string" === typeof(arguments.length <= 0 ? void 0 : arguments[0]) ? this.listenInstance(this.state, arguments.length <= 0 ? void 0 : arguments[0], arguments.length <= 1 ? void 0 : arguments[1], arguments.length <= 2 ? void 0 : arguments[2]) : this.listenInstance(arguments.length <= 0 ? void 0 : arguments[0], arguments.length <= 1 ? void 0 : arguments[1], arguments.length <= 2 ? void 0 : arguments[2], arguments.length <= 3 ? void 0 : arguments[3])
      }
      listenInstance(OO, KO, pO) {
        let XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        XO = XO && !1 === this.isTriggering;
        const bK = OO[KO];
        return XO && null !== bK && void 0 !== bK && pO(bK, void 0), this.addCallback(OO[vK], KO, pO)
      }
      onChange() {
        if (2 === arguments.length && "string" !== typeof(arguments.length <= 0 ? void 0 : arguments[0])) {
          const OO = arguments.length <= 0 ? void 0 : arguments[0],
            KO = arguments.length <= 1 ? void 0 : arguments[1];
          return this.addCallback(OO[vK], bK.REPLACE, KO)
        }
        return "string" === typeof(arguments.length <= 0 ? void 0 : arguments[0]) ? this.addCallbackOrWaitCollectionAvailable(this.state, arguments.length <= 0 ? void 0 : arguments[0], bK.REPLACE, arguments.length <= 1 ? void 0 : arguments[1]) : this.addCallbackOrWaitCollectionAvailable(arguments.length <= 0 ? void 0 : arguments[0], arguments.length <= 1 ? void 0 : arguments[1], bK.REPLACE, arguments.length <= 2 ? void 0 : arguments[2])
      }
      qL() {
        return "string" === typeof(arguments.length <= 0 ? void 0 : arguments[0]) ? this.addCallbackOrWaitCollectionAvailable(this.state, arguments.length <= 0 ? void 0 : arguments[0], bK.ADD, arguments.length <= 1 ? void 0 : arguments[1], !1 !== (arguments.length <= 2 ? void 0 : arguments[2])) : this.addCallbackOrWaitCollectionAvailable(arguments.length <= 0 ? void 0 : arguments[0], arguments.length <= 1 ? void 0 : arguments[1], bK.ADD, arguments.length <= 2 ? void 0 : arguments[2], !1 !== (arguments.length <= 3 ? void 0 : arguments[3]))
      }
      ypO() {
        return "string" === typeof(arguments.length <= 0 ? void 0 : arguments[0]) ? this.addCallbackOrWaitCollectionAvailable(this.state, arguments.length <= 0 ? void 0 : arguments[0], bK.DELETE, arguments.length <= 1 ? void 0 : arguments[1]) : this.addCallbackOrWaitCollectionAvailable(arguments.length <= 0 ? void 0 : arguments[0], arguments.length <= 1 ? void 0 : arguments[1], bK.DELETE, arguments.length <= 2 ? void 0 : arguments[2])
      }
      bindTo(OO, KO, pO) {
        let XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        const eO = OO.constructor[Symbol.metadata];
        pO || (pO = Object.keys(eO).filter((OO => !isNaN(Number(OO)))).map((OO => eO[OO].name)));
        const lO = () => {
          for (const XO of pO) {
            const pO = OO[XO];
            void 0 !== pO && (KO[XO] = pO)
          }
        };
        return XO && lO(), this.addCallback(OO[vK], bK.REPLACE, lO)
      }
      mpO(OO) {
        this.uniqueRefIds.clear(), this.isTriggering = !0;
        for (let KO = 0, pO = OO.length; KO < pO; KO++) {
          const pO = OO[KO],
            XO = pO.refId,
            eO = pO.ref,
            lO = this.callbacks[XO];
          if (lO) {
            if ((pO.op & bK.DELETE) === bK.DELETE && EX.isSchema(pO.previousValue)) {
              const OO = pO.previousValue[vK],
                KO = this.callbacks[OO]?.[bK.DELETE];
              if (KO)
                for (let pO = KO.length - 1; pO >= 0; pO--) try {
                  KO[pO]()
                } catch (eb) {
                  console.error(eb)
                }
            }
            if (EX.isSchema(eO)) {
              if (!this.uniqueRefIds.has(XO)) {
                const OO = lO[bK.REPLACE];
                if (OO)
                  for (let KO = OO.length - 1; KO >= 0; KO--) try {
                    OO[KO]()
                  } catch (eb) {
                    console.error(eb)
                  }
              }
              const OO = lO[pO.field];
              if (OO)
                for (let KO = OO.length - 1; KO >= 0; KO--) try {
                  OO[KO](pO.value, pO.previousValue)
                } catch (eb) {
                  console.error(eb)
                }
            } else {
              const OO = pO.dynamicIndex ?? pO.field;
              if ((pO.op & bK.DELETE) === bK.DELETE) {
                if (void 0 !== pO.previousValue) {
                  const KO = lO[bK.DELETE];
                  if (KO)
                    for (let XO = KO.length - 1; XO >= 0; XO--) try {
                      KO[XO](pO.previousValue, OO)
                    } catch (eb) {
                      console.error(eb)
                    }
                }
                if ((pO.op & bK.ADD) === bK.ADD) {
                  const KO = lO[bK.ADD];
                  if (KO)
                    for (let XO = KO.length - 1; XO >= 0; XO--) try {
                      KO[XO](pO.value, OO)
                    } catch (eb) {
                      console.error(eb)
                    }
                }
              } else if ((pO.op & bK.ADD) === bK.ADD && pO.previousValue !== pO.value) {
                const KO = lO[bK.ADD];
                if (KO)
                  for (let XO = KO.length - 1; XO >= 0; XO--) try {
                    KO[XO](pO.value, OO)
                  } catch (eb) {
                    console.error(eb)
                  }
              }
              if (pO.value !== pO.previousValue) {
                const KO = lO[bK.REPLACE];
                if (KO)
                  for (let XO = KO.length - 1; XO >= 0; XO--) try {
                    KO[XO](OO, pO.value)
                  } catch (eb) {
                    console.error(eb)
                  }
              }
            }
            this.uniqueRefIds.add(XO)
          }
        }
        this.isTriggering = !1
      }
    }
    const pb = {
      get(OO) {
        if (OO instanceof xb) return new Kb(OO);
        if ("be" in OO.ZC) return new Kb(OO.ZC.be);
        throw new Error("Invalid room or decoder")
      },
      getLegacy(OO) {
        if (OO instanceof xb) return UX(OO);
        if ("be" in OO.ZC) return UX(OO.ZC.be);
        throw new Error("Invalid room or decoder")
      },
      getRawChanges: (OO, KO) => Ob(OO, KO)
    };
    class Xb {
      _free = [];
      _factory;
      _maxSize;
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        this._factory = OO, this._maxSize = KO.maxSize ?? 1 / 0;
        const pO = KO.preallocate ?? 0;
        for (let XO = 0; XO < pO; XO++) this._free.push(OO())
      }
      acquire() {
        return this._free.length > 0 ? this._free.pop() : this._factory()
      }
      release(OO) {
        EX.reset(OO), this._free.length < this._maxSize && this._free.push(OO)
      }
      get size() {
        return this._free.length
      }
    }

    function be(OO) {
      return new Xb((() => new OO), arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {})
    }
    TK("map", {
      constructor: bb
    }), TK("array", {
      constructor: pX
    }), TK("set", {
      constructor: lX
    }), TK("collection", {
      constructor: eX
    })
  },
  8134: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      __addDisposableResource: () => mK,
      __assign: () => eO,
      __asyncDelegator: () => yK,
      __asyncGenerator: () => IO,
      __asyncValues: () => gK,
      __await: () => NO,
      __awaiter: () => FO,
      __classPrivateFieldGet: () => iK,
      __classPrivateFieldIn: () => PO,
      __classPrivateFieldSet: () => rK,
      __createBinding: () => LO,
      __decorate: () => vK,
      __disposeResources: () => HO,
      __esDecorate: () => hO,
      __exportStar: () => QO,
      __extends: () => bK,
      __generator: () => VO,
      __importDefault: () => wO,
      __importStar: () => YO,
      __makeTemplateObject: () => uO,
      __metadata: () => oO,
      __param: () => CO,
      __propKey: () => MO,
      __read: () => AO,
      __rest: () => lO,
      __rewriteRelativeImportExtension: () => RO,
      __runInitializers: () => DO,
      __setFunctionName: () => aK,
      __spread: () => fO,
      __spreadArray: () => TO,
      __spreadArrays: () => dO,
      __values: () => zK,
      default: () => SO
    });
    var XO = function(OO, KO) {
      return XO = Object.setPrototypeOf || {
        __proto__: []
      }
      instanceof Array && function(OO, KO) {
        OO.__proto__ = KO
      } || function(OO, KO) {
        for (var pO in KO) Object.prototype.hasOwnProperty.call(KO, pO) && (OO[pO] = KO[pO])
      }, XO(OO, KO)
    };

    function bK(OO, KO) {
      if ("function" !== typeof KO && null !== KO) throw new TypeError("Class extends value " + String(KO) + " is not a constructor or null");

      function pO() {
        this.constructor = OO
      }
      XO(OO, KO), OO.prototype = null === KO ? Object.create(KO) : (pO.prototype = KO.prototype, new pO)
    }
    var eO = function() {
      return eO = Object.assign || function(OO) {
        for (var KO, pO = 1, XO = arguments.length; pO < XO; pO++)
          for (var bK in KO = arguments[pO]) Object.prototype.hasOwnProperty.call(KO, bK) && (OO[bK] = KO[bK]);
        return OO
      }, eO.apply(this, arguments)
    };

    function lO(OO, KO) {
      var pO = {};
      for (var XO in OO) Object.prototype.hasOwnProperty.call(OO, XO) && KO.indexOf(XO) < 0 && (pO[XO] = OO[XO]);
      if (null != OO && "function" === typeof Object.getOwnPropertySymbols) {
        var bK = 0;
        for (XO = Object.getOwnPropertySymbols(OO); bK < XO.length; bK++) KO.indexOf(XO[bK]) < 0 && Object.prototype.propertyIsEnumerable.call(OO, XO[bK]) && (pO[XO[bK]] = OO[XO[bK]])
      }
      return pO
    }

    function vK(OO, KO, pO, XO) {
      var bK, eO = arguments.length,
        lO = eO < 3 ? KO : null === XO ? XO = Object.getOwnPropertyDescriptor(KO, pO) : XO;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) lO = Reflect.decorate(OO, KO, pO, XO);
      else
        for (var vK = OO.length - 1; vK >= 0; vK--)(bK = OO[vK]) && (lO = (eO < 3 ? bK(lO) : eO > 3 ? bK(KO, pO, lO) : bK(KO, pO)) || lO);
      return eO > 3 && lO && Object.defineProperty(KO, pO, lO), lO
    }

    function CO(OO, KO) {
      return function(pO, XO) {
        KO(pO, XO, OO)
      }
    }

    function hO(OO, KO, pO, XO, bK, eO) {
      function lO(OO) {
        if (void 0 !== OO && "function" !== typeof OO) throw new TypeError("Function expected");
        return OO
      }
      for (var vK, CO = XO.kind, hO = "getter" === CO ? "get" : "setter" === CO ? "set" : "value", DO = !KO && OO ? XO.static ? OO : OO.prototype : null, MO = KO || (DO ? Object.getOwnPropertyDescriptor(DO, XO.name) : {}), aK = !1, oO = pO.length - 1; oO >= 0; oO--) {
        var FO = {};
        for (var VO in XO) FO[VO] = "access" === VO ? {} : XO[VO];
        for (var VO in XO.access) FO.access[VO] = XO.access[VO];
        FO.addInitializer = function(OO) {
          if (aK) throw new TypeError("Cannot add initializers after decoration has completed");
          eO.push(lO(OO || null))
        };
        var LO = (0, pO[oO])("accessor" === CO ? {
          get: MO.get,
          set: MO.set
        } : MO[hO], FO);
        if ("accessor" === CO) {
          if (void 0 === LO) continue;
          if (null === LO || "object" !== typeof LO) throw new TypeError("Object expected");
          (vK = lO(LO.get)) && (MO.get = vK), (vK = lO(LO.set)) && (MO.set = vK), (vK = lO(LO.init)) && bK.unshift(vK)
        } else(vK = lO(LO)) && ("field" === CO ? bK.unshift(vK) : MO[hO] = vK)
      }
      DO && Object.defineProperty(DO, XO.name, MO), aK = !0
    }

    function DO(OO, KO, pO) {
      for (var XO = arguments.length > 2, bK = 0; bK < KO.length; bK++) pO = XO ? KO[bK].call(OO, pO) : KO[bK].call(OO);
      return XO ? pO : void 0
    }

    function MO(OO) {
      return "symbol" === typeof OO ? OO : "".concat(OO)
    }

    function aK(OO, KO, pO) {
      return "symbol" === typeof KO && (KO = KO.description ? "[".concat(KO.description, "]") : ""), Object.defineProperty(OO, "name", {
        configurable: !0,
        value: pO ? "".concat(pO, " ", KO) : KO
      })
    }

    function oO(OO, KO) {
      if ("object" === typeof Reflect && "function" === typeof Reflect.metadata) return Reflect.metadata(OO, KO)
    }

    function FO(OO, KO, pO, XO) {
      return new(pO || (pO = Promise))((function(bK, eO) {
        function lO(OO) {
          try {
            CO(XO.next(OO))
          } catch (KO) {
            eO(KO)
          }
        }

        function vK(OO) {
          try {
            CO(XO.throw(OO))
          } catch (KO) {
            eO(KO)
          }
        }

        function CO(OO) {
          var KO;
          OO.done ? bK(OO.value) : (KO = OO.value, KO instanceof pO ? KO : new pO((function(OO) {
            OO(KO)
          }))).then(lO, vK)
        }
        CO((XO = XO.apply(OO, KO || [])).next())
      }))
    }

    function VO(OO, KO) {
      var pO, XO, bK, eO = {
          label: 0,
          sent: function() {
            if (1 & bK[0]) throw bK[1];
            return bK[1]
          },
          trys: [],
          ops: []
        },
        lO = Object.create(("function" === typeof Iterator ? Iterator : Object).prototype);
      return lO.next = vK(0), lO.throw = vK(1), lO.return = vK(2), "function" === typeof Symbol && (lO[Symbol.iterator] = function() {
        return this
      }), lO;

      function vK(vK) {
        return function(CO) {
          return function(vK) {
            if (pO) throw new TypeError("Generator is already executing.");
            for (; lO && (lO = 0, vK[0] && (eO = 0)), eO;) try {
              if (pO = 1, XO && (bK = 2 & vK[0] ? XO.return : vK[0] ? XO.throw || ((bK = XO.return) && bK.call(XO), 0) : XO.next) && !(bK = bK.call(XO, vK[1])).done) return bK;
              switch (XO = 0, bK && (vK = [2 & vK[0], bK.value]), vK[0]) {
                case 0:
                case 1:
                  bK = vK;
                  break;
                case 4:
                  return eO.label++, {
                    value: vK[1],
                    done: !1
                  };
                case 5:
                  eO.label++, XO = vK[1], vK = [0];
                  continue;
                case 7:
                  vK = eO.ops.pop(), eO.trys.pop();
                  continue;
                default:
                  if (!(bK = (bK = eO.trys).length > 0 && bK[bK.length - 1]) && (6 === vK[0] || 2 === vK[0])) {
                    eO = 0;
                    continue
                  }
                  if (3 === vK[0] && (!bK || vK[1] > bK[0] && vK[1] < bK[3])) {
                    eO.label = vK[1];
                    break
                  }
                  if (6 === vK[0] && eO.label < bK[1]) {
                    eO.label = bK[1], bK = vK;
                    break
                  }
                  if (bK && eO.label < bK[2]) {
                    eO.label = bK[2], eO.ops.push(vK);
                    break
                  }
                  bK[2] && eO.ops.pop(), eO.trys.pop();
                  continue
              }
              vK = KO.call(OO, eO)
            } catch (CO) {
              vK = [6, CO], XO = 0
            } finally {
              pO = bK = 0
            }
            if (5 & vK[0]) throw vK[1];
            return {
              value: vK[0] ? vK[1] : void 0,
              done: !0
            }
          }([vK, CO])
        }
      }
    }
    var LO = Object.create ? function(OO, KO, pO, XO) {
      void 0 === XO && (XO = pO);
      var bK = Object.getOwnPropertyDescriptor(KO, pO);
      bK && !("get" in bK ? !KO.__esModule : bK.writable || bK.configurable) || (bK = {
        enumerable: !0,
        get: function() {
          return KO[pO]
        }
      }), Object.defineProperty(OO, XO, bK)
    } : function(OO, KO, pO, XO) {
      void 0 === XO && (XO = pO), OO[XO] = KO[pO]
    };

    function QO(OO, KO) {
      for (var pO in OO) "default" === pO || Object.prototype.hasOwnProperty.call(KO, pO) || LO(KO, OO, pO)
    }

    function zK(OO) {
      var KO = "function" === typeof Symbol && Symbol.iterator,
        pO = KO && OO[KO],
        XO = 0;
      if (pO) return pO.call(OO);
      if (OO && "number" === typeof OO.length) return {
        next: function() {
          return OO && XO >= OO.length && (OO = void 0), {
            value: OO && OO[XO++],
            done: !OO
          }
        }
      };
      throw new TypeError(KO ? "Object is not iterable." : "Symbol.iterator is not defined.")
    }

    function AO(OO, KO) {
      var pO = "function" === typeof Symbol && OO[Symbol.iterator];
      if (!pO) return OO;
      var XO, bK, eO = pO.call(OO),
        lO = [];
      try {
        for (;
          (void 0 === KO || KO-- > 0) && !(XO = eO.next()).done;) lO.push(XO.value)
      } catch (vK) {
        bK = {
          error: vK
        }
      } finally {
        try {
          XO && !XO.done && (pO = eO.return) && pO.call(eO)
        } finally {
          if (bK) throw bK.error
        }
      }
      return lO
    }

    function fO() {
      for (var OO = [], KO = 0; KO < arguments.length; KO++) OO = OO.concat(AO(arguments[KO]));
      return OO
    }

    function dO() {
      for (var OO = 0, KO = 0, pO = arguments.length; KO < pO; KO++) OO += arguments[KO].length;
      var XO = Array(OO),
        bK = 0;
      for (KO = 0; KO < pO; KO++)
        for (var eO = arguments[KO], lO = 0, vK = eO.length; lO < vK; lO++, bK++) XO[bK] = eO[lO];
      return XO
    }

    function TO(OO, KO, pO) {
      if (pO || 2 === arguments.length)
        for (var XO, bK = 0, eO = KO.length; bK < eO; bK++) !XO && bK in KO || (XO || (XO = Array.prototype.slice.call(KO, 0, bK)), XO[bK] = KO[bK]);
      return OO.concat(XO || Array.prototype.slice.call(KO))
    }

    function NO(OO) {
      return this instanceof NO ? (this.v = OO, this) : new NO(OO)
    }

    function IO(OO, KO, pO) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var XO, bK = pO.apply(OO, KO || []),
        eO = [];
      return XO = Object.create(("function" === typeof AsyncIterator ? AsyncIterator : Object).prototype), lO("next"), lO("throw"), lO("return", (function(OO) {
        return function(KO) {
          return Promise.resolve(KO).then(OO, hO)
        }
      })), XO[Symbol.asyncIterator] = function() {
        return this
      }, XO;

      function lO(OO, KO) {
        bK[OO] && (XO[OO] = function(KO) {
          return new Promise((function(pO, XO) {
            eO.push([OO, KO, pO, XO]) > 1 || vK(OO, KO)
          }))
        }, KO && (XO[OO] = KO(XO[OO])))
      }

      function vK(OO, KO) {
        try {
          (pO = bK[OO](KO)).value instanceof NO ? Promise.resolve(pO.value.v).then(CO, hO) : DO(eO[0][2], pO)
        } catch (XO) {
          DO(eO[0][3], XO)
        }
        var pO
      }

      function CO(OO) {
        vK("next", OO)
      }

      function hO(OO) {
        vK("throw", OO)
      }

      function DO(OO, KO) {
        OO(KO), eO.shift(), eO.length && vK(eO[0][0], eO[0][1])
      }
    }

    function yK(OO) {
      var KO, pO;
      return KO = {}, XO("next"), XO("throw", (function(OO) {
        throw OO
      })), XO("return"), KO[Symbol.iterator] = function() {
        return this
      }, KO;

      function XO(XO, bK) {
        KO[XO] = OO[XO] ? function(KO) {
          return (pO = !pO) ? {
            value: NO(OO[XO](KO)),
            done: !1
          } : bK ? bK(KO) : KO
        } : bK
      }
    }

    function gK(OO) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var KO, pO = OO[Symbol.asyncIterator];
      return pO ? pO.call(OO) : (OO = zK(OO), KO = {}, XO("next"), XO("throw"), XO("return"), KO[Symbol.asyncIterator] = function() {
        return this
      }, KO);

      function XO(pO) {
        KO[pO] = OO[pO] && function(KO) {
          return new Promise((function(XO, bK) {
            (function(OO, KO, pO, XO) {
              Promise.resolve(XO).then((function(KO) {
                OO({
                  value: KO,
                  done: pO
                })
              }), KO)
            })(XO, bK, (KO = OO[pO](KO)).done, KO.value)
          }))
        }
      }
    }

    function uO(OO, KO) {
      return Object.defineProperty ? Object.defineProperty(OO, "raw", {
        value: KO
      }) : OO.raw = KO, OO
    }
    var EO = Object.create ? function(OO, KO) {
        Object.defineProperty(OO, "default", {
          enumerable: !0,
          value: KO
        })
      } : function(OO, KO) {
        OO.default = KO
      },
      jK = function(OO) {
        return jK = Object.getOwnPropertyNames || function(OO) {
          var KO = [];
          for (var pO in OO) Object.prototype.hasOwnProperty.call(OO, pO) && (KO[KO.length] = pO);
          return KO
        }, jK(OO)
      };

    function YO(OO) {
      if (OO && OO.__esModule) return OO;
      var KO = {};
      if (null != OO)
        for (var pO = jK(OO), XO = 0; XO < pO.length; XO++) "default" !== pO[XO] && LO(KO, OO, pO[XO]);
      return EO(KO, OO), KO
    }

    function wO(OO) {
      return OO && OO.__esModule ? OO : {
        default: OO
      }
    }

    function iK(OO, KO, pO, XO) {
      if ("a" === pO && !XO) throw new TypeError("Private accessor was defined without a getter");
      if ("function" === typeof KO ? OO !== KO || !XO : !KO.has(OO)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
      return "m" === pO ? XO : "a" === pO ? XO.call(OO) : XO ? XO.value : KO.get(OO)
    }

    function rK(OO, KO, pO, XO, bK) {
      if ("m" === XO) throw new TypeError("Private method is not writable");
      if ("a" === XO && !bK) throw new TypeError("Private accessor was defined without a setter");
      if ("function" === typeof KO ? OO !== KO || !bK : !KO.has(OO)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
      return "a" === XO ? bK.call(OO, pO) : bK ? bK.value = pO : KO.set(OO, pO), pO
    }

    function PO(OO, KO) {
      if (null === KO || "object" !== typeof KO && "function" !== typeof KO) throw new TypeError("Cannot use 'in' operator on non-object");
      return "function" === typeof OO ? KO === OO : OO.has(KO)
    }

    function mK(OO, KO, pO) {
      if (null !== KO && void 0 !== KO) {
        if ("object" !== typeof KO && "function" !== typeof KO) throw new TypeError("Object expected.");
        var XO, bK;
        if (pO) {
          if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
          XO = KO[Symbol.asyncDispose]
        }
        if (void 0 === XO) {
          if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
          XO = KO[Symbol.dispose], pO && (bK = XO)
        }
        if ("function" !== typeof XO) throw new TypeError("Object not disposable.");
        bK && (XO = function() {
          try {
            bK.call(this)
          } catch (OO) {
            return Promise.reject(OO)
          }
        }), OO.stack.push({
          value: KO,
          dispose: XO,
          async: pO
        })
      } else pO && OO.stack.push({
        async: !0
      });
      return KO
    }
    var sO = "function" === typeof SuppressedError ? SuppressedError : function(OO, KO, pO) {
      var XO = new Error(pO);
      return XO.name = "SuppressedError", XO.error = OO, XO.suppressed = KO, XO
    };

    function HO(OO) {
      function KO(KO) {
        OO.error = OO.hasError ? new sO(KO, OO.error, "An error was suppressed during disposal.") : KO, OO.hasError = !0
      }
      var pO, XO = 0;
      return function bK() {
        for (; pO = OO.stack.pop();) try {
          if (!pO.async && 1 === XO) return XO = 0, OO.stack.push(pO), Promise.resolve().then(bK);
          if (pO.dispose) {
            var eO = pO.dispose.call(pO.value);
            if (pO.async) return XO |= 2, Promise.resolve(eO).then(bK, (function(OO) {
              return KO(OO), bK()
            }))
          } else XO |= 1
        } catch (lO) {
          KO(lO)
        }
        if (1 === XO) return OO.hasError ? Promise.reject(OO.error) : Promise.resolve();
        if (OO.hasError) throw OO.error
      }()
    }

    function RO(OO, KO) {
      return "string" === typeof OO && /^\.\.?\//.test(OO) ? OO.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, (function(OO, pO, XO, bK, eO) {
        return pO ? KO ? ".jsx" : ".js" : !XO || bK && eO ? XO + bK + "." + eO.toLowerCase() + "js" : OO
      })) : OO
    }
    const SO = {
      __extends: bK,
      __assign: eO,
      __rest: lO,
      __decorate: vK,
      __param: CO,
      __esDecorate: hO,
      __runInitializers: DO,
      __propKey: MO,
      __setFunctionName: aK,
      __metadata: oO,
      __awaiter: FO,
      __generator: VO,
      __createBinding: LO,
      __exportStar: QO,
      __values: zK,
      __read: AO,
      __spread: fO,
      __spreadArrays: dO,
      __spreadArray: TO,
      __await: NO,
      __asyncGenerator: IO,
      __asyncDelegator: yK,
      __asyncValues: gK,
      __makeTemplateObject: uO,
      __importStar: YO,
      __importDefault: wO,
      __classPrivateFieldGet: iK,
      __classPrivateFieldSet: rK,
      __classPrivateFieldIn: PO,
      __addDisposableResource: mK,
      __disposeResources: HO,
      __rewriteRelativeImportExtension: RO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);