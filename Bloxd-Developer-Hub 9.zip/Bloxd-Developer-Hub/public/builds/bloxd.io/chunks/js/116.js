export const id = 116;
export const ids = [116, 119, 120, 123];
export const modules = {
  5721: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO.h,
      d: () => bK,
      h: () => XO.q
    });
    var XO = pO(5709);
    const bK = [!1, !0].flatMap((OO => ["terrain", "liquid", "model"].map((KO => ({
      strict: OO,
      program: KO
    })))))
  },
  38595: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => MO,
      installListedShaderPack: () => DO
    });
    var XO = pO(5678),
      bK = pO(5709),
      eO = pO(1056),
      lO = pO(5739),
      vK = pO(5721),
      CO = pO(5791),
      hO = pO(5786);
    async function DO(OO) {
      const KO = await (0, lO.loadPageShaderPackCompiler)();
      if (null === KO) return {
        kind: "failed",
        reason: "compiler"
      };
      const pO = await MO(OO, KO);
      return "failed" === pO.kind ? pO : await (0, CO.saveShaderPack)(pO.stored, KO) ? ((0, CO.markShaderPackChangePending)(), pO) : {
        kind: "failed",
        reason: "save"
      }
    }
    async function MO(OO, KO) {
      const pO = await async function(OO) {
        let {
          packId: KO,
          sourceHash: pO
        } = OO;
        try {
          const OO = await fetch(`${eO.clientSideServerUrls.s3Url}/${(0,XO.F)(KO,pO)}`, {
            headers: {
              Accept: "application/json"
            }
          });
          if (!OO.ok) return console.error(`Failed to download shader pack ${KO} (${OO.status})`), null;
          const bK = await OO.json();
          return "object" !== typeof bK || null === bK ? (console.error(`Shader pack ${KO}'s source isn't an object`), null) : bK
        } catch (bK) {
          return console.error(`Failed to download shader pack ${KO}`, bK), null
        }
      }(OO);
      if (null === pO) return {
        kind: "failed",
        reason: "download"
      };
      if (!(0, vK.h)(pO.apiVersion)) return {
        kind: "failed",
        reason: "apiVersion"
      };
      const lO = (0, bK.t)(pO.files);
      if ("string" === typeof lO) return console.error(`A listed shader pack breaks the pack rules: ${lO}`), {
        kind: "failed",
        reason: "invalid"
      };
      const DO = await (0, hO.f)(KO, lO);
      if (!1 === (null === DO || void 0 === DO ? void 0 : DO.ok)) return {
        kind: "failed",
        reason: "errors"
      };
      const MO = {
        manifest: {
          apiVersion: pO.apiVersion,
          name: OO.name,
          author: OO.ownerName,
          description: OO.description || null,
          keepCircleShadows: !0 === pO.keepCircleShadows
        },
        files: lO
      };
      return {
        kind: "loaded",
        stored: (0, CO.toStoredShaderPack)(MO, DO, {
          packId: OO.packId,
          sourceHash: OO.sourceHash
        })
      }
    }
  },
  39221: (OO, KO, pO) => {
    pO.d(KO, {
      followListingUpdates: () => aK
    });
    var XO = pO(641),
      bK = pO(22),
      eO = pO(1329),
      lO = pO(1008),
      vK = pO(5739),
      CO = pO(5721),
      hO = pO(38595),
      DO = pO(5791);
    const MO = ["apiVersion", "invalid", "errors"];
    async function aK(OO, KO) {
      const pO = await lO.userContextManager.getCurrentUserContext(),
        aK = await eO.c.getShaderPackVersions(pO, [KO.packId]),
        oO = function(OO, KO, pO) {
          var XO;
          if (void 0 === pO || "unlisted" === pO.status) return {
            kind: "none"
          };
          if ("banned" === pO.status) return {
            kind: "remove"
          };
          if (!(0, CO.h)(pO.apiVersion)) return {
            kind: "none"
          };
          const {
            sourceHash: bK,
            name: eO,
            ownerName: lO,
            description: vK
          } = pO;
          return bK !== KO.sourceHash && bK !== KO.rejectedSourceHash ? {
            kind: "update",
            sourceHash: bK,
            name: eO,
            ownerName: lO,
            description: vK
          } : eO !== OO.manifest.name || lO !== OO.manifest.author || (vK || null) !== (null !== (XO = OO.manifest.description) && void 0 !== XO ? XO : null) ? {
            kind: "rename",
            name: eO,
            ownerName: lO,
            description: vK
          } : {
            kind: "none"
          }
        }(OO, KO, (0, XO.e)(aK, KO.packId));
      if ("update" === oO.kind && "landingPage" !== bK.d.get("gameState")) return !1;
      const FO = "update" === oO.kind || "rename" === oO.kind,
        VO = FO ? await (0, vK.loadPageShaderPackCompiler)() : null;
      if (FO && null === VO) return console.warn(`Didn't follow shader pack ${KO.packId}'s listing: the shader pack compiler couldn't load`), !0;
      const LO = await async function(OO, KO, pO, XO) {
        switch (pO.kind) {
          case "none":
            return;
          case "remove":
            return null;
          case "rename":
            return {
              ...OO, manifest: {
                ...OO.manifest,
                name: pO.name,
                author: pO.ownerName,
                description: pO.description || null
              }
            };
          case "update": {
            if (null === XO) return;
            const {
              sourceHash: bK,
              name: eO,
              ownerName: lO,
              description: vK
            } = pO, CO = await (0, hO.e)({
              packId: KO.packId,
              sourceHash: bK,
              name: eO,
              ownerName: lO,
              description: vK
            }, XO);
            if ("loaded" === CO.kind && null !== CO.stored.validation) return CO.stored;
            const DO = "failed" === CO.kind ? CO.reason : "no WebGPU device could check it";
            return console.warn(`Didn't update shader pack ${KO.packId}: ${DO}`), "failed" === CO.kind && MO.includes(CO.reason) ? {
              ...OO,
              listing: {
                ...KO,
                rejectedSourceHash: bK
              }
            } : void 0
          }
        }
      }(OO, KO, oO, VO);
      return void 0 === LO || (await (0, DO.replaceShaderPack)(OO, LO, VO) ? (null !== LO && LO.files === OO.files || (0, DO.markShaderPackChangePending)(), !0) : (console.warn("Didn't apply the shader pack listing's update: the stored pack changed or couldn't be written"), !0))
    }
  },
  5791: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      forgetShaderPackActiveHint: () => EO,
      isOtherApiVersion: () => IO,
      isShaderPackActive: () => fO,
      isShaderPackChangePending: () => NO,
      markShaderPackChangePending: () => TO,
      pageShaderPackValidationVersion: () => yK,
      reconcileStoredShaderPackHint: () => uO,
      removeShaderPack: () => AO,
      replaceShaderPack: () => LO,
      saveShaderPack: () => VO,
      shaderPackNeedsCheck: () => gK,
      storedPackOutcome: () => dO,
      storedShaderPackFiles: () => aK,
      toStoredShaderPack: () => MO
    });
    var XO = pO(5709),
      bK = pO(5721),
      eO = pO(36),
      lO = pO(2668),
      vK = pO(5800),
      CO = pO(5763);
    const hO = "shaderPackChangePending";
    let DO = null;

    function MO(OO, KO, pO) {
      return {
        manifest: OO.manifest,
        files: (0, XO.v)(OO.files),
        validation: KO,
        ...pO && {
          listing: pO
        }
      }
    }

    function aK(OO) {
      return Object.keys(OO.files).map((KO => ({
        path: KO,
        source: OO.files[KO]
      })))
    }
    let oO = Promise.resolve();

    function FO(OO) {
      const KO = oO.then(OO);
      return oO = KO.catch((() => {})), KO
    }

    function VO(OO, KO) {
      return FO((() => QO(OO, KO)))
    }

    function LO(OO, KO, pO) {
      return FO((async () => JSON.stringify(await (0, vK.h)()) === JSON.stringify(OO) && (null === KO ? (await zK(), !0) : QO(KO, pO))))
    }
    async function QO(OO, KO) {
      const pO = await eO.d.setItem(vK.e, OO);
      return pO && jK(OO, KO), pO
    }
    async function zK() {
      await eO.d.removeItem(vK.e), eO.e.removeItem(lO.b)
    }

    function AO() {
      return FO(zK)
    }

    function fO(OO, KO) {
      return "active" === dO(OO, KO).kind
    }

    function dO(OO, KO) {
      var pO;
      return null === OO ? {
        kind: "none",
        reason: "nothingStored"
      } : IO(OO) ? {
        kind: "none",
        reason: "otherApiVersion"
      } : !1 !== (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.ok) || OO.validation.fromRecheck ? null === KO ? {
        kind: "none",
        reason: "noCompiler"
      } : gK(OO, KO) ? {
        kind: "blocked",
        messageKey: "shaderPack:failedUnchecked"
      } : OO.validation.ok ? {
        kind: "active"
      } : {
        kind: "blocked",
        messageKey: "shaderPack:failedValidation"
      } : {
        kind: "none",
        reason: "failedWhenLoaded"
      }
    }

    function TO() {
      eO.h.setItem(hO, performance.timeOrigin)
    }

    function NO() {
      return eO.h.getItem(hO) === performance.timeOrigin
    }

    function IO(OO) {
      return !(0, bK.h)(OO.manifest.apiVersion)
    }

    function yK(OO) {
      return DO ??= OO.sKO((0, CO.shaderPackTextures)()), DO
    }

    function gK(OO, KO) {
      var pO;
      return (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.headerVersion) !== yK(KO)
    }

    function uO(OO) {
      return FO((async () => {
        jK(await (0, vK.h)(!0), OO)
      }))
    }

    function EO() {
      return FO((async () => {
        eO.e.removeItem(lO.b)
      }))
    }

    function jK(OO, KO) {
      fO(OO, KO) ? eO.e.setItem(lO.b, !0) : eO.e.removeItem(lO.b)
    }
  },
  5763: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      loadShaderPackTextures: () => lO,
      shaderPackTextures: () => vK
    });
    var XO = pO(5709);
    let bK = null,
      eO = null;

    function lO() {
      return eO ??= Promise.all([pO.e(62), pO.e(182)]).then((() => pO(38591))).then((OO => {
        let {
          FORMER_BLOCK_IMAGE_NAMES: KO,
          textureNameToIndex: pO,
          textureAnimationData: eO
        } = OO;
        return bK ??= (0, XO.k)(pO, eO, KO), bK
      })), eO
    }

    function vK() {
      if (null === bK) throw new Error("Shader pack textures read before loadShaderPackTextures");
      return bK
    }
  },
  5786: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => CO,
      f: () => vK
    });
    var XO = pO(5791),
      bK = pO(5763),
      eO = pO(115);
    const lO = 100;
    async function vK(OO, KO) {
      var pO;
      let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null !== (pO = navigator.gpu) && void 0 !== pO ? pO : null;
      const lO = OO.GlO(KO, (0, bK.shaderPackTextures)());
      if (lO.errors.length > 0) return hO(OO, lO.errors, lO.offInStrict);
      const vK = await async function(OO) {
        if (!OO) return null;
        try {
          const KO = await (0, eO.m)(OO);
          return KO ? await KO.requestDevice() : null
        } catch (KO) {
          return console.error("Couldn't get a WebGPU device to validate the shader pack.", KO), null
        }
      }(XO);
      if (!vK) return null;
      let CO = !1;
      vK.lost.then((() => {
        CO = !0
      }));
      try {
        const KO = await Promise.all(lO.validationModules.map((KO => async function(OO, KO, pO) {
          KO.pushErrorScope("validation");
          const XO = KO.createShaderModule({
              code: pO.code
            }),
            bK = KO.popErrorScope(),
            {
              messages: eO
            } = await XO.getCompilationInfo(),
            lO = eO.filter((OO => "error" === OO.type)).map((KO => OO.mapValidationMessage(pO, KO))),
            vK = await bK;
          vK && 0 === lO.length && lO.push({
            file: null,
            line: 0,
            message: vK.message,
            variants: [pO.key]
          });
          return lO
        }(OO, vK, KO))));
        return CO ? null : hO(OO, OO.JhO(KO.flat()), lO.offInStrict)
      } catch (DO) {
        return console.error("Couldn't validate the shader pack on WebGPU.", DO), null
      } finally {
        vK.destroy()
      }
    }
    async function CO(OO, KO) {
      var pO;
      if (!(0, XO.shaderPackNeedsCheck)(OO, KO) || (0, XO.isOtherApiVersion)(OO)) return OO;
      const bK = await vK(KO, (0, XO.storedShaderPackFiles)(OO));
      if (!bK) return OO;
      const eO = !1 === (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.ok) && !OO.validation.fromRecheck,
        lO = {
          ...OO,
          validation: eO ? bK : {
            ...bK,
            fromRecheck: !0
          }
        };
      return await (0, XO.replaceShaderPack)(OO, lO, KO) || console.warn("Didn't save the shader pack's validation result: the stored pack changed or couldn't be written"), lO
    }

    function hO(OO, KO, pO) {
      return {
        headerVersion: (0, XO.pageShaderPackValidationVersion)(OO),
        ok: 0 === KO.length,
        errors: KO.slice(0, lO),
        moreErrors: Math.max(0, KO.length - lO),
        offInStrict: pO
      }
    }
  },
  5678: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => aK,
      E: () => DO,
      F: () => AO,
      G: () => MO,
      H: () => hO,
      d: () => oO,
      g: () => VO,
      i: () => FO,
      m: () => zK,
      o: () => dO,
      s: () => CO,
      t: () => bK,
      u: () => fO,
      v: () => eO,
      w: () => vK,
      x: () => lO,
      y: () => XO
    });
    const XO = ["forest", "desert", "water", "night", "cave"];
    const bK = {
        full: {
          width: 3840,
          height: 2160
        },
        large: {
          width: 1920,
          height: 1080
        },
        thumb: {
          width: 640,
          height: 360
        }
      },
      eO = ["popular", "updated", "newest"],
      lO = 3,
      vK = 32,
      CO = 300;

    function hO(OO, KO) {
      return OO.slice(0, KO).replace(/[\uD800-\uDBFF]$/, "")
    }
    const DO = 64,
      MO = 512,
      aK = 18e5;
    const oO = "Bloxdhub",
      FO = "https://bloxdhub.com/shaders";

    function VO(OO) {
      return `https://bloxdhub.com/workshop/${encodeURIComponent(OO)}`
    }
    const LO = "Screenshot generation failed.",
      QO = "Its screenshots couldn't be generated:";

    function zK(OO) {
      var KO;
      return OO === LO || null !== (KO = null === OO || void 0 === OO ? void 0 : OO.startsWith(QO)) && void 0 !== KO && KO
    }

    function AO(OO, KO) {
      return `shaderPacks/${OO}/${KO}.json`
    }

    function fO(OO, KO, pO, XO) {
      return null === KO.renderId ? dO(OO, KO.baselineVersion, pO, XO) : `${OO}/${function(OO,KO,pO,XO){return`shaderPacks/${OO}/${KO}/${pO}-${XO}.webp`}(KO.packId,KO.renderId,pO,XO)}`
    }

    function dO(OO, KO, pO, XO) {
      return `${OO}/${function(OO,KO,pO){return`shaderPacks/baseline/${OO}/${KO}-${pO}.webp`}(KO,pO,XO)}`
    }
  },
  5709: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      f: () => eO,
      h: () => XO,
      k: () => FO,
      m: () => DO,
      q: () => bK,
      t: () => CO,
      v: () => hO,
      w: () => MO
    });
    const XO = 5;

    function bK(OO) {
      return OO === XO
    }
    const eO = 262144,
      lO = 256,
      vK = 256;

    function CO(OO) {
      if ("object" !== typeof OO || null === OO || Array.isArray(OO)) return "The pack has no files.";
      const KO = [];
      for (const [pO, XO] of Object.entries(OO)) {
        if ("string" !== typeof XO) return `${pO} isn't text.`;
        KO.push({
          path: pO,
          source: XO
        })
      }
      return KO.sort(((OO, KO) => DO(OO.path, KO.path))),
        function(OO) {
          if (0 === OO.length) return "The pack has no .wgsl files.";
          if (OO.length > lO) return `The pack has more than ${lO} .wgsl files.`;
          const KO = new Set;
          for (const {
              path: pO
            }
            of OO) {
            const OO = aK(pO);
            if (null !== OO) return OO;
            if (KO.has(pO)) return `The pack has two files at ${pO}.`;
            KO.add(pO)
          }
          return MO(OO) > eO ? `The pack's .wgsl files are over ${eO/1024} KB in total.` : null
        }(KO) ?? KO
    }

    function hO(OO) {
      const KO = {};
      for (const pO of OO) KO[pO.path] = pO.source;
      return KO
    }

    function DO(OO, KO) {
      return OO < KO ? -1 : OO > KO ? 1 : 0
    }

    function MO(OO) {
      const KO = new TextEncoder;
      let pO = 0;
      for (const {
          source: XO
        }
        of OO) pO += KO.encode(XO).byteLength;
      return pO
    }

    function aK(OO) {
      if (!OO.toLowerCase().endsWith(".wgsl")) return `${OO} isn't a .wgsl file.`;
      if (OO.length > vK) return `A file path is over ${vK} characters.`;
      if (OO.includes("\\") || /[\u0000-\u001f]/.test(OO)) return `${OO} isn't a valid file path.`;
      return OO.split("/").some((OO => "" === OO || "." === OO || ".." === OO)) ? `${OO} isn't a valid file path.` : null
    }
    const oO = /^(.*)\[rot\[([1-4])$/;

    function FO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new Map;
      const XO = new Map;
      KO.forEach(((OO, KO) => {
        let {
          numAnimStates: pO,
          animStartIdx: bK
        } = OO;
        for (let eO = 1; eO < pO; eO++) XO.set(bK + eO - 1, KO)
      }));
      const bK = Object.entries(OO),
        eO = new Map;
      for (const [VO, LO] of bK) {
        const OO = oO.exec(VO);
        "1" === OO?.[2] && eO.set(OO[1], LO + 1)
      }
      const lO = OO => {
          const KO = oO.exec(OO);
          return KO && eO.has(KO[1]) ? {
            root: KO[1],
            rotation: Number(KO[2]) - 1
          } : null
        },
        vK = new Set(bK.map((OO => {
          let [KO] = OO;
          return lO(KO)?.root ?? KO
        }))),
        CO = (OO, pO) => {
          const XO = OO.replace(/_?0$/, "");
          return (KO[pO]?.numAnimStates ?? 0) > 1 && !vK.has(XO) ? XO : OO
        },
        hO = new Map;
      for (const [oO, VO] of bK) hO.set(VO, CO(lO(oO)?.root ?? oO, VO));
      const DO = bK.reduce(((OO, KO) => {
          let [, pO] = KO;
          return Math.max(OO, pO + 1)
        }), 0),
        MO = Array.from({
          length: DO
        }, ((OO, KO) => ({
          id: KO + 1,
          rotation: 0
        }))),
        aK = new Map,
        FO = new Map;
      for (const [oO, VO] of bK) {
        const OO = lO(oO),
          KO = XO.get(VO);
        if (void 0 !== KO) {
          const pO = hO.get(KO);
          FO.set(oO, {
            name: oO,
            texture: pO,
            kind: "frame"
          }), OO && !FO.has(OO.root) && FO.set(OO.root, {
            name: OO.root,
            texture: pO,
            kind: "frame"
          });
          continue
        }
        const pO = hO.get(VO),
          bK = OO?.root ?? oO;
        if (pO !== bK && FO.set(bK, {
            name: bK,
            texture: pO,
            kind: "frame"
          }), OO) {
          const KO = eO.get(OO.root);
          MO[VO] = {
            id: KO,
            rotation: OO.rotation
          }, aK.set(pO, KO), FO.set(oO, {
            name: oO,
            texture: pO,
            kind: "rotation"
          })
        } else aK.set(pO, VO + 1)
      }
      for (const oO of aK.keys()) FO.delete(oO);
      for (const [oO, VO] of pO) {
        const OO = aK.get(VO);
        void 0 === OO || aK.has(oO) || (aK.set(oO, OO), FO.delete(oO))
      }
      return {
        named: [...aK].sort(((OO, KO) => {
          let [pO] = OO, [XO] = KO;
          return pO < XO ? -1 : pO > XO ? 1 : 0
        })).map((OO => {
          let [KO, pO] = OO;
          return {
            name: KO,
            id: pO
          }
        })),
        aliases: [...FO.values()],
        layers: MO
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);