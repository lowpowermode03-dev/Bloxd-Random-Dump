export const id = 6;
export const ids = [6];
export const modules = {
  41282: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_webgl_bg.f3318ee94cfc467f4129.wasm"
  },
  41280: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      bloxdWasmWebgl: () => wK
    });
    var XO = {};
    pO.r(XO), pO.d(XO, {
      Gl: () => bK,
      kaO: () => eO,
      Renderer: () => lO,
      aK: () => vK,
      default: () => YK,
      initSync: () => jp,
      oO: () => CO,
      UMO: () => hO,
      FO: () => DO,
      VO: () => MO,
      LO: () => aK,
      QO: () => oO,
      zK: () => FO,
      fO: () => VO,
      dO: () => LO,
      OaO: () => QO,
      yK: () => zK,
      KaO: () => AO,
      paO: () => fO,
      taO: () => dO,
      XaO: () => TO,
      boO: () => NO,
      eaO: () => IO,
      laO: () => yK,
      voO: () => gK,
      uO: () => uO,
      EO: () => EO
    });
    class bK {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, PO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        gp.qMYT(OO, 0)
      }
      static CaO() {
        return gp.vYel() >>> 0
      }
      haO() {
        return gp.DIZO(this.__wbg_ptr)
      }
      KMO() {
        return gp.UivD(this.__wbg_ptr) >>> 0
      }
      MaO(OO, KO, pO) {
        return gp.Rrk7(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      sK(OO, KO, pO) {
        return gp.AQDJ(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      aoO() {
        return gp.YVxP(this.__wbg_ptr) >>> 0
      }
      XMO(OO, KO, pO, XO, bK, eO, lO) {
        return gp.BxxT(this.__wbg_ptr, OO, KO, pO, XO, bK, eO, lO)
      }
      oaO(OO, KO, pO) {
        return gp.KKNb(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      FaO() {
        return gp.cCQL(this.__wbg_ptr) >>> 0
      }
      VaO() {
        return gp.Fvy7(this.__wbg_ptr) >>> 0
      }
      QaO() {
        return gp.XJwL(this.__wbg_ptr) >>> 0
      }
      craft(OO, KO, pO) {
        return gp.izHB(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      hMO(OO, KO, pO) {
        return gp.aUFU(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      baO() {
        return gp.UYkr(this.__wbg_ptr) >>> 0
      }
      eMO(OO) {
        return gp.NJUJ(this.__wbg_ptr, OO) >>> 0
      }
      lMO(OO, KO, pO, XO, bK, eO) {
        return gp.rfdq(this.__wbg_ptr, OO, KO, pO, XO, bK, eO) >>> 0
      }
      pMO() {
        return gp.qV2b(this.__wbg_ptr) >>> 0
      }
      zoO() {
        return gp.EQmF(this.__wbg_ptr) >>> 0
      }
      AaO(OO) {
        return gp.Mgd5(this.__wbg_ptr, OO) >>> 0
      }
      MMO(OO) {
        return gp.Pc1U(this.__wbg_ptr, OO) >>> 0
      }
      daO(OO) {
        return gp.z04w(this.__wbg_ptr, OO) >>> 0
      }
      TaO(OO) {
        return gp.eEFZ(this.__wbg_ptr, OO) >>> 0
      }
      frame(OO, KO, pO, XO, bK, eO) {
        return gp.o8dK(this.__wbg_ptr, OO, KO, pO, XO, bK, eO) >>> 0
      }
      IaO(OO) {
        return 0 !== gp.PHPv(this.__wbg_ptr, OO)
      }
      yoO(OO, KO) {
        return gp.iRZl(this.__wbg_ptr, OO, KO) >>> 0
      }
      goO(OO) {
        return gp.ZP9p(this.__wbg_ptr, OO) >>> 0
      }
      yX() {
        return gp.LdZI(this.__wbg_ptr) >>> 0
      }
      uaO() {
        return gp.pzYS(this.__wbg_ptr) >>> 0
      }
      ZO() {
        return gp.zuCj(this.__wbg_ptr) >>> 0
      }
      EaO(OO, KO, pO, XO, bK) {
        return gp.RbSH(this.__wbg_ptr, OO, KO, pO, XO, bK) >>> 0
      }
      joO(OO, KO, pO) {
        return gp.LMr9(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      YaO(OO, KO, pO, XO) {
        return gp.oyNF(this.__wbg_ptr, OO, KO, pO, XO) >>> 0
      }
      waO(OO, KO, pO) {
        return gp.ZR89(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      ioO(OO, KO) {
        return gp.cG27(this.__wbg_ptr, OO, KO) >>> 0
      }
      DMO(OO) {
        return gp.S7d8(this.__wbg_ptr, OO) >>> 0
      }
      FE() {
        return gp.RHVE(this.__wbg_ptr) >>> 0
      }
      roO() {
        return gp.qyyR(this.__wbg_ptr) >>> 0
      }
      PaO() {
        return gp.OnQG(this.__wbg_ptr) >>> 0
      }
      moO() {
        return gp.OyYa(this.__wbg_ptr) >>> 0
      }
      constructor(OO, KO) {
        const pO = gp.J9gx(OO, KO);
        return this.__wbg_ptr = pO, PO.register(this, this.__wbg_ptr, this), this
      }
      saO(OO) {
        return gp.jr5i(this.__wbg_ptr, OO) >>> 0
      }
      Ul() {
        return gp.CiCB(this.__wbg_ptr) >>> 0
      }
      EMO(OO, KO) {
        return gp.G17R(this.__wbg_ptr, OO, KO) >>> 0
      }
      NMO(OO) {
        return gp.DrRq(this.__wbg_ptr, OO) >>> 0
      }
      HaO(OO, KO, pO, XO) {
        return gp.Dx2S(this.__wbg_ptr, OO, KO, pO, XO) >>> 0
      }
      iaO(OO) {
        return gp.qlQM(this.__wbg_ptr, OO) >>> 0
      }
      LMO() {
        gp.mbah(this.__wbg_ptr)
      }
      sMO(OO) {
        gp.Nkml(this.__wbg_ptr, OO)
      }
      maO(OO) {
        return gp.dQRC(this.__wbg_ptr, OO)
      }
      VMO() {
        return gp.YvMY(this.__wbg_ptr) >>> 0
      }
      qv() {
        return gp.R92r(this.__wbg_ptr) >>> 0
      }
      YMO() {
        return gp.bVBf(this.__wbg_ptr) >>> 0
      }
      LaO(OO) {
        return gp.fBsg(this.__wbg_ptr, OO) >>> 0
      }
      RaO(OO) {
        return gp.LFiJ(this.__wbg_ptr, OO) >>> 0
      }
      SaO(OO) {
        return gp.bm30(this.__wbg_ptr, OO) >>> 0
      }
      JaO(OO) {
        return gp.AH7x(this.__wbg_ptr, OO) >>> 0
      }
      salvage(OO, KO, pO) {
        return gp.DRQG(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      oMO(OO) {
        return gp.xJ2U(this.__wbg_ptr, OO) >>> 0
      }
      OMO() {
        return gp.JlgU(this.__wbg_ptr) >>> 0
      }
      coO(OO) {
        return gp.FlMi(this.__wbg_ptr, OO) >>> 0
      }
      BaO(OO) {
        gp.Cpjb(this.__wbg_ptr, OO)
      }
      ZaO(OO) {
        return 0 !== gp.BK4Y(this.__wbg_ptr, HO(OO))
      }
      Cp(OO, KO, pO, XO) {
        return gp.NmpD(this.__wbg_ptr, OO, KO, pO, XO) >>> 0
      }
      qoO(OO, KO, pO) {
        const XO = zp(OO, gp.tyHa, gp.iGiR),
          bK = uK,
          eO = VK(KO, gp.tyHa),
          lO = uK,
          vK = function(OO, KO) {
            const pO = KO(8 * OO.length, 8) >>> 0;
            return UO().set(OO, pO / 8), uK = OO.length, pO
          }(pO, gp.tyHa),
          CO = uK;
        return 0 !== gp.ikvr(this.__wbg_ptr, XO, bK, eO, lO, vK, CO)
      }
      xoO(OO) {
        gp.tGcd(this.__wbg_ptr, OO)
      }
      naO(OO, KO) {
        return 0 !== gp.S0Mi(this.__wbg_ptr, OO, KO)
      }
      WaO(OO) {
        return gp.DdSQ(this.__wbg_ptr, OO) >>> 0
      }
      NaO(OO) {
        gp.WYCI(this.__wbg_ptr, HO(OO))
      }
      toO(OO) {
        gp.IOq8(this.__wbg_ptr, OO)
      }
      koO(OO) {
        gp.U0wL(this.__wbg_ptr, OO)
      }
      CMO(OO, KO, pO) {
        return gp.XKJL(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      FMO(OO) {
        return gp.AJXe(this.__wbg_ptr, OO) >>> 0
      }
      UaO(OO) {
        gp.qgnk(this.__wbg_ptr, OO)
      }
      OoO(OO) {
        RO(OO, lO);
        var KO = OO.__destroy_into_raw();
        gp.duOV(this.__wbg_ptr, KO)
      }
      GDO(OO, KO, pO, XO, bK, eO) {
        var lO = oK(OO) ? 0 : LK(OO, gp.tyHa),
          vK = uK;
        const CO = LK(KO, gp.tyHa),
          hO = uK,
          DO = QK(pO, gp.tyHa),
          MO = uK,
          aK = VK(XO, gp.tyHa),
          oO = uK;
        return 0 !== gp.Y25L(this.__wbg_ptr, lO, vK, CO, hO, DO, MO, aK, oO, bK, eO)
      }
      poO(OO, KO, pO, XO, bK) {
        var eO = oK(bK) ? 0 : LK(bK, gp.tyHa),
          lO = uK;
        gp.Ipic(this.__wbg_ptr, OO, KO, pO, XO, eO, lO)
      }
      XoO(OO, KO, pO) {
        const XO = QK(OO, gp.tyHa),
          bK = uK,
          eO = VK(KO, gp.tyHa),
          lO = uK,
          vK = QK(pO, gp.tyHa),
          CO = uK;
        return 0 !== gp.mERv(this.__wbg_ptr, XO, bK, eO, lO, vK, CO)
      }
      bFO(OO) {
        const KO = zp(OO, gp.tyHa, gp.iGiR),
          pO = uK;
        return 0 !== gp.lf2V(this.__wbg_ptr, KO, pO)
      }
      eoO(OO) {
        return gp.BDi1(this.__wbg_ptr, OO) >>> 0
      }
      loK() {
        return gp.MdgR(this.__wbg_ptr) >>> 0
      }
      vFO() {
        const OO = gp.hCR9(this.__wbg_ptr);
        var KO = qK(OO[0], OO[1]).slice();
        return gp.jgZv(OO[0], 4 * OO[1], 4), KO
      }
      hoO() {
        const OO = gp.I8Hd(this.__wbg_ptr);
        var KO = BO(OO[0], OO[1]).slice();
        return gp.jgZv(OO[0], 8 * OO[1], 8), KO
      }
      DoO() {
        const OO = gp.mrcc(this.__wbg_ptr);
        var KO = GO(OO[0], OO[1]);
        return gp.jgZv(OO[0], 4 * OO[1], 4), KO
      }
      MoO(OO, KO, pO, XO, bK) {
        return gp.m4x2(this.__wbg_ptr, OO, KO, pO, XO, bK) >>> 0
      }
      aFO() {
        const OO = gp.LJVJ(this.__wbg_ptr);
        var KO = GO(OO[0], OO[1]);
        return gp.jgZv(OO[0], 4 * OO[1], 4), KO
      }
      ooO() {
        return gp.soZh(this.__wbg_ptr) >>> 0
      }
      VoO() {
        return gp.sudo(this.__wbg_ptr) >>> 0
      }
    }
    Symbol.dispose && (bK.prototype[Symbol.dispose] = bK.prototype.free);
    class eO {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, mK.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        gp.vhq0(OO, 0)
      }
      attach(OO) {
        RO(OO, bK);
        return 0 !== gp.qFsA(this.__wbg_ptr, OO.__wbg_ptr)
      }
      attached() {
        return 0 !== gp.HkhU(this.__wbg_ptr)
      }
      close(OO) {
        const KO = gp.XdDw(this.__wbg_ptr, OO);
        var pO = xK(KO[0], KO[1]).slice();
        return gp.jgZv(KO[0], 1 * KO[1], 1), pO
      }
      detach() {
        gp.y96F(this.__wbg_ptr)
      }
      LoO() {
        return gp.ef71(this.__wbg_ptr) >>> 0
      }
      QoO() {
        return gp.wRwB(this.__wbg_ptr) >>> 0
      }
      frame(OO) {
        return gp.QRBu(this.__wbg_ptr, OO) >>> 0
      }
      zFO(OO, KO, pO, XO) {
        const bK = LK(XO, gp.tyHa),
          eO = uK;
        return gp.rM2W(this.__wbg_ptr, OO, KO, pO, bK, eO)
      }
      AoO() {
        return 0 !== gp.bYeP(this.__wbg_ptr)
      }
      foO(OO, KO) {
        const pO = LK(KO, gp.tyHa),
          XO = uK;
        gp.C4bd(this.__wbg_ptr, OO, pO, XO)
      }
      constructor() {
        const OO = gp.p2xt();
        return this.__wbg_ptr = OO, mK.register(this, this.__wbg_ptr, this), this
      }
      open(OO, KO, pO, XO) {
        return 0 !== gp.TDla(this.__wbg_ptr, OO, KO, pO, XO)
      }
      orbit(OO) {
        const KO = gp.iZOi(this.__wbg_ptr, OO);
        var pO = BO(KO[0], KO[1]).slice();
        return gp.jgZv(KO[0], 8 * KO[1], 8), pO
      }
      replay(OO) {
        return gp.zacy(this.__wbg_ptr, OO) >>> 0
      }
      resize(OO, KO, pO) {
        gp.dGpb(this.__wbg_ptr, OO, KO, pO)
      }
      doO(OO) {
        const KO = LK(OO, gp.tyHa),
          pO = uK;
        return 0 !== gp.fZOy(this.__wbg_ptr, KO, pO)
      }
      NoO(OO, KO, pO, XO, bK) {
        const eO = zp(KO, gp.tyHa, gp.iGiR),
          lO = uK;
        return gp.aGXc(this.__wbg_ptr, OO, eO, lO, pO, XO, bK) >>> 0
      }
      IoO(OO) {
        gp.eGJg(this.__wbg_ptr, OO)
      }
      yFO(OO, KO, pO, XO, bK) {
        const eO = zp(pO, gp.tyHa, gp.iGiR),
          lO = uK;
        return gp.Ztch(this.__wbg_ptr, OO, KO, eO, lO, XO, bK) >>> 0
      }
      gFO(OO, KO, pO, XO) {
        gp.kzYB(this.__wbg_ptr, OO, KO, pO, XO)
      }
      uoO(OO, KO, pO, XO, bK) {
        const eO = zp(pO, gp.tyHa, gp.iGiR),
          lO = uK,
          vK = zp(XO, gp.tyHa, gp.iGiR),
          CO = uK;
        return gp.PpZw(this.__wbg_ptr, OO, KO, eO, lO, vK, CO, bK) >>> 0
      }
      ToO(OO, KO, pO, XO) {
        const bK = zp(KO, gp.tyHa, gp.iGiR),
          eO = uK,
          lO = VK(pO, gp.tyHa),
          vK = uK;
        return gp.nKtf(this.__wbg_ptr, OO, bK, eO, lO, vK, XO) >>> 0
      }
      OoO(OO) {
        RO(OO, lO);
        var KO = OO.__destroy_into_raw();
        return 0 !== gp.Za1V(this.__wbg_ptr, KO)
      }
      GDO(OO, KO, pO, XO, bK) {
        var eO = oK(OO) ? 0 : LK(OO, gp.tyHa),
          lO = uK;
        const vK = LK(KO, gp.tyHa),
          CO = uK,
          hO = QK(pO, gp.tyHa),
          DO = uK,
          MO = VK(XO, gp.tyHa),
          aK = uK;
        return 0 !== gp.EqkU(this.__wbg_ptr, eO, lO, vK, CO, hO, DO, MO, aK, bK)
      }
      jFO() {
        const OO = gp.MMDQ(this.__wbg_ptr);
        var KO = qK(OO[0], OO[1]).slice();
        return gp.jgZv(OO[0], 4 * OO[1], 4), KO
      }
      YoO(OO) {
        const KO = gp.HbSi(this.__wbg_ptr, OO);
        var pO = xK(KO[0], KO[1]).slice();
        return gp.jgZv(KO[0], 1 * KO[1], 1), pO
      }
      woO(OO) {
        const KO = gp.xZNo(this.__wbg_ptr, OO);
        var pO = qK(KO[0], KO[1]).slice();
        return gp.jgZv(KO[0], 4 * KO[1], 4), pO
      }
    }
    Symbol.dispose && (eO.prototype[Symbol.dispose] = eO.prototype.free);
    class lO {
      static __wrap(OO) {
        const KO = Object.create(lO.prototype);
        return KO.__wbg_ptr = OO, sO.register(KO, KO.__wbg_ptr, KO), KO
      }
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, sO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        gp.FwV4(OO, 0)
      }
    }

    function vK(OO, KO) {
      const pO = zp(OO, gp.tyHa, gp.iGiR),
        XO = uK,
        bK = gp.CiLj(pO, XO, KO);
      if (bK[1]) throw AK(bK[0])
    }

    function CO() {
      gp.sHfG()
    }

    function hO() {
      return gp.wBGn()
    }

    function DO() {
      return gp.mXpw() >>> 0
    }

    function MO(OO) {
      return 0 !== gp.VQEW(OO)
    }

    function aK(OO) {
      return 0 !== gp.tANY(OO)
    }

    function oO(OO) {
      gp.ApZq(OO)
    }

    function FO() {
      return gp.jvma() >>> 0
    }

    function VO() {
      return gp.gdht() >>> 0
    }

    function LO() {
      return 0 !== gp.QuEW()
    }

    function QO(OO, KO, pO, XO, bK) {
      return AK(gp.qDMC(HO(OO), KO, HO(pO), XO, oK(bK) ? Number.MAX_SAFE_INTEGER : bK >>> 0))
    }

    function zK() {
      return gp.cM2M() >>> 0
    }

    function AO(OO, KO) {
      gp.NYBB(OO, HO(KO))
    }

    function fO(OO, KO) {
      gp.yW2Y(OO, HO(KO))
    }

    function dO(OO) {
      gp.W8hj(OO)
    }

    function TO(OO) {
      gp.BSzG(OO)
    }

    function NO(OO) {
      const KO = LK(OO, gp.tyHa),
        pO = uK;
      return 0 !== gp.pnL6(KO, pO)
    }

    function IO(OO) {
      var KO = oK(OO) ? 0 : LK(OO, gp.tyHa),
        pO = uK;
      const XO = gp.QbDp(KO, pO);
      let bK;
      return 0 !== XO[0] && (bK = GO(XO[0], XO[1]), gp.jgZv(XO[0], 4 * XO[1], 4)), bK
    }

    function yK() {
      const OO = gp.y51V();
      let KO;
      return 0 !== OO[0] && (KO = XK(OO[0], OO[1]), gp.jgZv(OO[0], 1 * OO[1], 1)), KO
    }

    function gK(OO, KO) {
      const pO = gp.UEnC(OO, KO);
      let XO;
      return 0 !== pO[0] && (XO = XK(pO[0], pO[1]), gp.jgZv(pO[0], 1 * pO[1], 1)), XO
    }

    function uO() {
      let OO, KO;
      try {
        const pO = gp.MsQ2();
        return OO = pO[0], KO = pO[1], XK(pO[0], pO[1])
      } finally {
        gp.jgZv(OO, KO, 1)
      }
    }

    function EO(OO) {
      gp.cpf0(HO(OO))
    }

    function jK() {
      const OO = {
        __proto__: null,
        ha4r: function(OO, KO) {
          return HO(Error(XK(OO, KO)))
        },
        rOMj: function(OO) {
          const KO = hK(OO),
            pO = "boolean" === typeof KO ? KO : void 0;
          return oK(pO) ? 16777215 : pO ? 1 : 0
        },
        ZLZR: function(OO, KO) {
          const pO = zp(JO(hK(KO)), gp.tyHa, gp.iGiR),
            XO = uK;
          WO().setInt32(OO + 4, XO, !0), WO().setInt32(OO + 0, pO, !0)
        },
        wi3G: function(OO) {
          return "function" === typeof hK(OO)
        },
        rRtf: function(OO) {
          const KO = hK(OO);
          return "object" === typeof KO && null !== KO
        },
        PN0w: function(OO) {
          return void 0 === hK(OO)
        },
        fhvf: function(OO, KO) {
          const pO = hK(KO),
            XO = "number" === typeof pO ? pO : void 0;
          WO().setFloat64(OO + 8, oK(XO) ? 0 : XO, !0), WO().setInt32(OO + 0, !oK(XO), !0)
        },
        t0iV: function(OO) {
          throw AK(OO)
        },
        iLXP: function(OO, KO) {
          const pO = hK(KO),
            XO = "string" === typeof pO ? pO : void 0;
          var bK = oK(XO) ? 0 : zp(XO, gp.tyHa, gp.iGiR),
            eO = uK;
          WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
        },
        pPUr: function(OO, KO) {
          throw new Error(XK(OO, KO))
        },
        ZiQ5: function(OO) {
          hK(OO)._wbg_cb_unref()
        },
        pAtT: function(OO, KO) {
          hK(OO).activeTexture(KO >>> 0)
        },
        DhAK: function(OO, KO) {
          hK(OO).activeTexture(KO >>> 0)
        },
        tnLv: function() {
          return DK((function(OO, KO, pO, XO) {
            hK(OO).addEventListener(XK(KO, pO), hK(XO))
          }), arguments)
        },
        hrzN: function(OO, KO, pO) {
          hK(OO).attachShader(hK(KO), hK(pO))
        },
        PK4H: function(OO, KO, pO) {
          hK(OO).attachShader(hK(KO), hK(pO))
        },
        LSfw: function(OO, KO, pO) {
          hK(OO).beginQuery(KO >>> 0, hK(pO))
        },
        XAOs: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).bindBufferRange(KO >>> 0, pO >>> 0, hK(XO), bK, eO)
        },
        kpco: function(OO, KO, pO) {
          hK(OO).bindBuffer(KO >>> 0, hK(pO))
        },
        Mh4Y: function(OO, KO, pO) {
          hK(OO).bindBuffer(KO >>> 0, hK(pO))
        },
        yCcR: function(OO, KO, pO) {
          hK(OO).bindFramebuffer(KO >>> 0, hK(pO))
        },
        ATmK: function(OO, KO, pO) {
          hK(OO).bindFramebuffer(KO >>> 0, hK(pO))
        },
        jJ0z: function(OO, KO, pO) {
          hK(OO).bindRenderbuffer(KO >>> 0, hK(pO))
        },
        hhsI: function(OO, KO, pO) {
          hK(OO).bindRenderbuffer(KO >>> 0, hK(pO))
        },
        RItC: function(OO, KO, pO) {
          hK(OO).bindSampler(KO >>> 0, hK(pO))
        },
        KTxn: function(OO, KO, pO) {
          hK(OO).bindTexture(KO >>> 0, hK(pO))
        },
        bJIU: function(OO, KO, pO) {
          hK(OO).bindTexture(KO >>> 0, hK(pO))
        },
        oO6O: function(OO, KO) {
          hK(OO).bindVertexArrayOES(hK(KO))
        },
        WQq5: function(OO, KO) {
          hK(OO).bindVertexArray(hK(KO))
        },
        zYrH: function(OO, KO, pO) {
          hK(OO).blendEquationSeparate(KO >>> 0, pO >>> 0)
        },
        ESKK: function(OO, KO, pO) {
          hK(OO).blendEquationSeparate(KO >>> 0, pO >>> 0)
        },
        NOEW: function(OO, KO, pO, XO, bK) {
          hK(OO).blendFuncSeparate(KO >>> 0, pO >>> 0, XO >>> 0, bK >>> 0)
        },
        ipx8: function(OO, KO, pO, XO, bK) {
          hK(OO).blendFuncSeparate(KO >>> 0, pO >>> 0, XO >>> 0, bK >>> 0)
        },
        j6xw: function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
          hK(OO).blitFramebuffer(KO, pO, XO, bK, eO, lO, vK, CO, hO >>> 0, DO >>> 0)
        },
        DdA8: function(OO, KO, pO, XO) {
          hK(OO).bufferData(KO >>> 0, pO, XO >>> 0)
        },
        IEvy: function(OO, KO, pO, XO) {
          hK(OO).bufferData(KO >>> 0, pO, XO >>> 0)
        },
        l6Hs: function(OO, KO, pO, XO, bK) {
          hK(OO).bufferSubData(KO >>> 0, pO, xK(XO, bK))
        },
        zdds: function() {
          return DK((function(OO, KO, pO, XO, bK, eO) {
            return HO(hK(OO).call(hK(KO), hK(pO), hK(XO), hK(bK), hK(eO)))
          }), arguments)
        },
        oR93: function() {
          return DK((function(OO, KO, pO) {
            return HO(hK(OO).call(hK(KO), hK(pO)))
          }), arguments)
        },
        IBqT: function(OO) {
          hK(OO).call()
        },
        Or9Q: function(OO, KO, pO, XO, bK) {
          hK(OO).clearBufferfv(KO >>> 0, pO, cK(XO, bK))
        },
        MMET: function(OO, KO, pO, XO, bK) {
          hK(OO).clearRect(KO, pO, XO, bK)
        },
        RydQ: function(OO, KO, pO, XO, bK) {
          hK(OO).colorMask(0 !== KO, 0 !== pO, 0 !== XO, 0 !== bK)
        },
        Skoy: function(OO, KO, pO, XO, bK) {
          hK(OO).colorMask(0 !== KO, 0 !== pO, 0 !== XO, 0 !== bK)
        },
        SIpO: function(OO, KO) {
          hK(OO).compileShader(hK(KO))
        },
        MADc: function(OO, KO) {
          hK(OO).compileShader(hK(KO))
        },
        YUL0: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).copyBufferSubData(KO >>> 0, pO >>> 0, XO, bK, eO)
        },
        G3bJ: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
          hK(OO).copyTexSubImage2D(KO >>> 0, pO, XO, bK, eO, lO, vK, CO)
        },
        fB56: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
          hK(OO).copyTexSubImage2D(KO >>> 0, pO, XO, bK, eO, lO, vK, CO)
        },
        w0LM: function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
          hK(OO).copyTexSubImage3D(KO >>> 0, pO, XO, bK, eO, lO, vK, CO, hO)
        },
        fC6V: function(OO) {
          const KO = hK(OO).createBuffer();
          return oK(KO) ? 0 : HO(KO)
        },
        ILir: function(OO) {
          const KO = hK(OO).createBuffer();
          return oK(KO) ? 0 : HO(KO)
        },
        bnCx: function() {
          return DK((function(OO, KO, pO) {
            return HO(hK(OO).createElement(XK(KO, pO)))
          }), arguments)
        },
        mXCH: function(OO) {
          const KO = hK(OO).createFramebuffer();
          return oK(KO) ? 0 : HO(KO)
        },
        ee86: function(OO) {
          const KO = hK(OO).createFramebuffer();
          return oK(KO) ? 0 : HO(KO)
        },
        vaKm: function(OO) {
          const KO = hK(OO).createProgram();
          return oK(KO) ? 0 : HO(KO)
        },
        mgEW: function(OO) {
          const KO = hK(OO).createProgram();
          return oK(KO) ? 0 : HO(KO)
        },
        xqtT: function(OO) {
          const KO = hK(OO).createQuery();
          return oK(KO) ? 0 : HO(KO)
        },
        FDgA: function(OO) {
          const KO = hK(OO).createRenderbuffer();
          return oK(KO) ? 0 : HO(KO)
        },
        jyKe: function(OO) {
          const KO = hK(OO).createRenderbuffer();
          return oK(KO) ? 0 : HO(KO)
        },
        lLgG: function(OO) {
          const KO = hK(OO).createSampler();
          return oK(KO) ? 0 : HO(KO)
        },
        cUOQ: function(OO, KO) {
          const pO = hK(OO).createShader(KO >>> 0);
          return oK(pO) ? 0 : HO(pO)
        },
        loiv: function(OO, KO) {
          const pO = hK(OO).createShader(KO >>> 0);
          return oK(pO) ? 0 : HO(pO)
        },
        BbR4: function(OO) {
          const KO = hK(OO).createTexture();
          return oK(KO) ? 0 : HO(KO)
        },
        kGSj: function(OO) {
          const KO = hK(OO).createTexture();
          return oK(KO) ? 0 : HO(KO)
        },
        dFwj: function(OO) {
          const KO = hK(OO).createVertexArrayOES();
          return oK(KO) ? 0 : HO(KO)
        },
        amFH: function(OO) {
          const KO = hK(OO).createVertexArray();
          return oK(KO) ? 0 : HO(KO)
        },
        O8DO: function(OO, KO) {
          hK(OO).cullFace(KO >>> 0)
        },
        jzIT: function(OO, KO) {
          hK(OO).cullFace(KO >>> 0)
        },
        GnXD: function(OO, KO) {
          hK(OO).deleteBuffer(hK(KO))
        },
        hOYn: function(OO, KO) {
          hK(OO).deleteBuffer(hK(KO))
        },
        zcpW: function(OO, KO) {
          hK(OO).deleteFramebuffer(hK(KO))
        },
        b88N: function(OO, KO) {
          hK(OO).deleteFramebuffer(hK(KO))
        },
        ZFBS: function(OO, KO) {
          hK(OO).deleteQuery(hK(KO))
        },
        e9FI: function(OO, KO) {
          hK(OO).deleteRenderbuffer(hK(KO))
        },
        v6pc: function(OO, KO) {
          hK(OO).deleteRenderbuffer(hK(KO))
        },
        REvp: function(OO, KO) {
          hK(OO).deleteSampler(hK(KO))
        },
        ojeu: function(OO, KO) {
          hK(OO).deleteShader(hK(KO))
        },
        BxIc: function(OO, KO) {
          hK(OO).deleteShader(hK(KO))
        },
        fSvJ: function(OO, KO) {
          hK(OO).deleteSync(hK(KO))
        },
        TIzK: function(OO, KO) {
          hK(OO).deleteTexture(hK(KO))
        },
        b7eh: function(OO, KO) {
          hK(OO).deleteTexture(hK(KO))
        },
        Rz5K: function(OO, KO) {
          hK(OO).deleteVertexArrayOES(hK(KO))
        },
        WiR6: function(OO, KO) {
          hK(OO).deleteVertexArray(hK(KO))
        },
        uEDe: function(OO, KO) {
          hK(OO).depthFunc(KO >>> 0)
        },
        x3tL: function(OO, KO) {
          hK(OO).depthFunc(KO >>> 0)
        },
        CHYG: function(OO, KO) {
          hK(OO).depthMask(0 !== KO)
        },
        jeSB: function(OO, KO) {
          hK(OO).depthMask(0 !== KO)
        },
        lDAF: function(OO, KO, pO) {
          hK(OO).depthRange(KO, pO)
        },
        WHEb: function(OO, KO, pO) {
          hK(OO).depthRange(KO, pO)
        },
        qTjx: function(OO, KO, pO) {
          hK(OO).detachShader(hK(KO), hK(pO))
        },
        cT0R: function(OO, KO, pO) {
          hK(OO).detachShader(hK(KO), hK(pO))
        },
        PXc4: function(OO, KO) {
          hK(OO).disable(KO >>> 0)
        },
        ZrmQ: function(OO, KO) {
          hK(OO).disable(KO >>> 0)
        },
        hXB1: function(OO) {
          const KO = hK(OO).document;
          return oK(KO) ? 0 : HO(KO)
        },
        ZMXq: function(OO, KO, pO, XO, bK) {
          hK(OO).drawArraysInstancedANGLE(KO >>> 0, pO, XO, bK)
        },
        C28x: function(OO, KO, pO, XO, bK) {
          hK(OO).drawArraysInstanced(KO >>> 0, pO, XO, bK)
        },
        bEmA: function(OO, KO, pO, XO) {
          hK(OO).drawArrays(KO >>> 0, pO, XO)
        },
        hYvv: function(OO, KO, pO, XO) {
          hK(OO).drawArrays(KO >>> 0, pO, XO)
        },
        Pj89: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).drawElementsInstancedANGLE(KO >>> 0, pO, XO >>> 0, bK, eO)
        },
        lvrN: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).drawElementsInstanced(KO >>> 0, pO, XO >>> 0, bK, eO)
        },
        gpIK: function(OO, KO, pO, XO, bK) {
          hK(OO).drawElements(KO >>> 0, pO, XO >>> 0, bK)
        },
        Njjr: function(OO, KO, pO, XO, bK) {
          hK(OO).drawElements(KO >>> 0, pO, XO >>> 0, bK)
        },
        WS1a: function() {
          return DK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            hK(OO).drawImage(hK(KO), pO, XO, bK, eO, lO, vK, CO, hO)
          }), arguments)
        },
        TnTF: function(OO) {
          return hK(OO).drawingBufferHeight
        },
        nlOj: function(OO) {
          return hK(OO).drawingBufferWidth
        },
        oRjd: function(OO, KO) {
          hK(OO).enableVertexAttribArray(KO >>> 0)
        },
        rIF8: function(OO, KO) {
          hK(OO).enableVertexAttribArray(KO >>> 0)
        },
        pdpw: function(OO, KO) {
          hK(OO).enable(KO >>> 0)
        },
        wslF: function(OO, KO) {
          hK(OO).enable(KO >>> 0)
        },
        GM1p: function(OO, KO) {
          hK(OO).endQuery(KO >>> 0)
        },
        llwr: function(OO) {
          console.error(hK(OO))
        },
        cRFC: function(OO, KO) {
          console.error(XK(OO, KO))
        },
        PmCJ: function(OO, KO, pO) {
          const XO = hK(OO).fenceSync(KO >>> 0, pO >>> 0);
          return oK(XO) ? 0 : HO(XO)
        },
        mzux: function(OO, KO, pO, XO, bK) {
          hK(OO).framebufferRenderbuffer(KO >>> 0, pO >>> 0, XO >>> 0, hK(bK))
        },
        ZTvf: function(OO, KO, pO, XO, bK) {
          hK(OO).framebufferRenderbuffer(KO >>> 0, pO >>> 0, XO >>> 0, hK(bK))
        },
        mqum: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).framebufferTexture2D(KO >>> 0, pO >>> 0, XO >>> 0, hK(bK), eO)
        },
        bXkT: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).framebufferTexture2D(KO >>> 0, pO >>> 0, XO >>> 0, hK(bK), eO)
        },
        pY7a: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).framebufferTextureLayer(KO >>> 0, pO >>> 0, hK(XO), bK, eO)
        },
        QRog: function(OO, KO) {
          hK(OO).frontFace(KO >>> 0)
        },
        hHEm: function(OO, KO) {
          hK(OO).frontFace(KO >>> 0)
        },
        wnoT: function() {
          return DK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            return hK(OO).gameCall(KO >>> 0, pO, XO, bK, eO, lO, vK, CO, hO)
          }), arguments)
        },
        k6nY: function() {
          return DK((function(OO, KO, pO, XO) {
            return HO(hK(OO).getActiveUniformBlockParameter(hK(KO), pO >>> 0, XO >>> 0))
          }), arguments)
        },
        zWbJ: function(OO, KO, pO, XO) {
          hK(OO).getBufferSubData(KO >>> 0, pO, hK(XO))
        },
        NdC0: function() {
          return DK((function(OO, KO, pO, XO) {
            const bK = hK(OO).getContext(XK(KO, pO), hK(XO));
            return oK(bK) ? 0 : HO(bK)
          }), arguments)
        },
        Jau0: function() {
          return DK((function(OO, KO, pO, XO) {
            const bK = hK(OO).getContext(XK(KO, pO), hK(XO));
            return oK(bK) ? 0 : HO(bK)
          }), arguments)
        },
        NyIb: function() {
          return DK((function(OO, KO, pO) {
            const XO = hK(OO).getContext(XK(KO, pO));
            return oK(XO) ? 0 : HO(XO)
          }), arguments)
        },
        lkjM: function(OO) {
          return hK(OO).getError()
        },
        uDJW: function(OO) {
          return hK(OO).getError()
        },
        SUg8: function() {
          return DK((function(OO, KO, pO) {
            const XO = hK(OO).getExtension(XK(KO, pO));
            return oK(XO) ? 0 : HO(XO)
          }), arguments)
        },
        hVv8: function() {
          return DK((function(OO, KO, pO, XO) {
            const bK = hK(KO).getItem(XK(pO, XO));
            var eO = oK(bK) ? 0 : zp(bK, gp.tyHa, gp.iGiR),
              lO = uK;
            WO().setInt32(OO + 4, lO, !0), WO().setInt32(OO + 0, eO, !0)
          }), arguments)
        },
        PmMq: function() {
          return DK((function(OO, KO) {
            return HO(hK(OO).getParameter(KO >>> 0))
          }), arguments)
        },
        pueb: function() {
          return DK((function(OO, KO) {
            return HO(hK(OO).getParameter(KO >>> 0))
          }), arguments)
        },
        y00K: function(OO, KO, pO) {
          const XO = hK(KO).getProgramInfoLog(hK(pO));
          var bK = oK(XO) ? 0 : zp(XO, gp.tyHa, gp.iGiR),
            eO = uK;
          WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
        },
        VGfY: function(OO, KO, pO) {
          const XO = hK(KO).getProgramInfoLog(hK(pO));
          var bK = oK(XO) ? 0 : zp(XO, gp.tyHa, gp.iGiR),
            eO = uK;
          WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
        },
        l1XK: function(OO, KO, pO) {
          return HO(hK(OO).getProgramParameter(hK(KO), pO >>> 0))
        },
        JxZx: function(OO, KO, pO) {
          return HO(hK(OO).getProgramParameter(hK(KO), pO >>> 0))
        },
        tbeI: function() {
          return DK((function(OO, KO, pO, XO) {
            const bK = zp(hK(KO).getPropertyValue(XK(pO, XO)), gp.tyHa, gp.iGiR),
              eO = uK;
            WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
          }), arguments)
        },
        WNbp: function(OO, KO, pO) {
          return HO(hK(OO).getQueryParameter(hK(KO), pO >>> 0))
        },
        SBRw: function(OO, KO, pO) {
          const XO = hK(KO).getShaderInfoLog(hK(pO));
          var bK = oK(XO) ? 0 : zp(XO, gp.tyHa, gp.iGiR),
            eO = uK;
          WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
        },
        ETNR: function(OO, KO, pO) {
          const XO = hK(KO).getShaderInfoLog(hK(pO));
          var bK = oK(XO) ? 0 : zp(XO, gp.tyHa, gp.iGiR),
            eO = uK;
          WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
        },
        Wmtu: function(OO) {
          const KO = hK(OO).getSupportedExtensions();
          return oK(KO) ? 0 : HO(KO)
        },
        KyMN: function(OO, KO, pO) {
          return HO(hK(OO).getSyncParameter(hK(KO), pO >>> 0))
        },
        pY2V: function(OO, KO, pO, XO) {
          return hK(OO).getUniformBlockIndex(hK(KO), XK(pO, XO))
        },
        fKSR: function(OO, KO, pO, XO) {
          const bK = hK(OO).getUniformLocation(hK(KO), XK(pO, XO));
          return oK(bK) ? 0 : HO(bK)
        },
        rKfD: function(OO, KO, pO, XO) {
          const bK = hK(OO).getUniformLocation(hK(KO), XK(pO, XO));
          return oK(bK) ? 0 : HO(bK)
        },
        cYL2: function() {
          return DK((function(OO, KO) {
            return HO(Reflect.get(hK(OO), hK(KO)))
          }), arguments)
        },
        Urt3: function(OO, KO) {
          return HO(hK(OO)[KO >>> 0])
        },
        cYVt: function(OO, KO, pO, XO) {
          const bK = hK(KO).get(XK(pO, XO));
          var eO = oK(bK) ? 0 : zp(bK, gp.tyHa, gp.iGiR),
            lO = uK;
          WO().setInt32(OO + 4, lO, !0), WO().setInt32(OO + 0, eO, !0)
        },
        xF0I: function(OO, KO) {
          return HO(hK(OO)[KO >>> 0])
        },
        DeiA: function() {
          return DK((function(OO, KO) {
            return Reflect.has(hK(OO), hK(KO))
          }), arguments)
        },
        paMf: function(OO) {
          return hK(OO).height
        },
        wDFt: function(OO) {
          return hK(OO).height
        },
        YIoJ: function(OO) {
          return hK(OO).height
        },
        w6qh: function(OO) {
          console.info(hK(OO))
        },
        mrrb: function(OO) {
          let KO;
          try {
            KO = hK(OO) instanceof CanvasRenderingContext2D
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        LnEP: function(OO) {
          let KO;
          try {
            KO = hK(OO) instanceof Error
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        bns9: function(OO) {
          let KO;
          try {
            KO = hK(OO) instanceof HTMLCanvasElement
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        GYY3: function(OO) {
          let KO;
          try {
            KO = hK(OO) instanceof ImageBitmap
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        Bu9i: function(OO) {
          let KO;
          try {
            KO = hK(OO) instanceof OffscreenCanvas
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        p6VT: function(OO) {
          let KO;
          try {
            KO = hK(OO) instanceof Performance
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        TlE1: function(OO) {
          let KO;
          try {
            KO = hK(OO) instanceof WebGL2RenderingContext
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        v1kn: function(OO) {
          let KO;
          try {
            KO = hK(OO) instanceof Window
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        b7Zq: function() {
          return DK((function(OO, KO, pO) {
            hK(OO).invalidateFramebuffer(KO >>> 0, hK(pO))
          }), arguments)
        },
        DOat: function(OO) {
          return Array.isArray(hK(OO))
        },
        dC3E: function(OO) {
          return hK(OO).isContextLost()
        },
        rcju: function(OO) {
          return hK(OO).length
        },
        hNHi: function(OO) {
          return hK(OO).length
        },
        hRKT: function(OO, KO) {
          hK(OO).linkProgram(hK(KO))
        },
        RAym: function(OO, KO) {
          hK(OO).linkProgram(hK(KO))
        },
        oPyO: function() {
          return DK((function(OO) {
            const KO = hK(OO).localStorage;
            return oK(KO) ? 0 : HO(KO)
          }), arguments)
        },
        qAOx: function(OO) {
          return HO(hK(OO).location)
        },
        rUaq: function(OO) {
          return HO(hK(OO).message)
        },
        klRN: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
          hK(OO).multiDrawArraysWEBGL(KO >>> 0, ZO(pO, XO), bK >>> 0, ZO(eO, lO), vK >>> 0, CO)
        },
        BDUw: function(OO) {
          return HO(hK(OO).name)
        },
        Fh87: function(OO, KO) {
          return HO(new Error(XK(OO, KO)))
        },
        hDPc: function() {
          return HO(new Object)
        },
        y5mB: function() {
          return DK((function(OO, KO) {
            return HO(new OffscreenCanvas(OO >>> 0, KO >>> 0))
          }), arguments)
        },
        MxMA: function() {
          return HO(new Array)
        },
        tBF4: function(OO, KO) {
          return HO(new Uint8Array(xK(OO, KO)))
        },
        f17d: function(OO, KO) {
          try {
            var pO = {
              a: OO,
              b: KO
            };
            const XO = new Promise(((OO, KO) => {
              const XO = pO.a;
              pO.a = 0;
              try {
                return function(OO, KO, pO, XO) {
                  gp.hfa4(OO, KO, HO(pO), HO(XO))
                }(XO, pO.b, OO, KO)
              } finally {
                pO.a = XO
              }
            }));
            return HO(XO)
          } finally {
            pO.a = 0
          }
        },
        syLa: function() {
          return DK((function(OO, KO) {
            return HO(new URLSearchParams(XK(OO, KO)))
          }), arguments)
        },
        hjL9: function() {
          return performance.now()
        },
        tLoL: function(OO) {
          return Performance.prototype.now.call(hK(OO))
        },
        wxFH: function() {
          return Date.now()
        },
        o9AR: function() {
          return Date.now()
        },
        AeJJ: function(OO, KO, pO) {
          hK(OO).pixelStorei(KO >>> 0, pO)
        },
        s0UJ: function(OO, KO, pO) {
          hK(OO).pixelStorei(KO >>> 0, pO)
        },
        Vpeu: function(OO, KO, pO) {
          hK(OO).polygonOffset(KO, pO)
        },
        IWLK: function(OO, KO, pO) {
          hK(OO).polygonOffset(KO, pO)
        },
        zZbl: function(OO) {
          hK(OO).preventDefault()
        },
        SELx: function(OO, KO, pO, XO) {
          return hK(OO).probe(KO >>> 0, pO >>> 0, XO >>> 0)
        },
        z1o7: function(OO, KO, pO) {
          Uint8Array.prototype.set.call(xK(OO, KO), hK(pO))
        },
        J524: function(OO, KO) {
          return hK(OO).push(hK(KO))
        },
        rioT: function(OO) {
          return HO(hK(OO).queueMicrotask)
        },
        lThV: function(OO) {
          queueMicrotask(hK(OO))
        },
        UpZg: function() {
          return DK((function(OO, KO, pO, XO) {
            hK(OO).removeEventListener(XK(KO, pO), hK(XO))
          }), arguments)
        },
        d9ko: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).renderbufferStorageMultisample(KO >>> 0, pO, XO >>> 0, bK, eO)
        },
        BU9q: function(OO, KO, pO, XO, bK) {
          hK(OO).renderbufferStorage(KO >>> 0, pO >>> 0, XO, bK)
        },
        PRPy: function(OO, KO, pO, XO, bK) {
          hK(OO).renderbufferStorage(KO >>> 0, pO >>> 0, XO, bK)
        },
        x8Q7: function(OO) {
          return HO(lO.__wrap(OO))
        },
        NmZ8: function(OO) {
          return HO(Promise.resolve(hK(OO)))
        },
        RBmj: function(OO, KO, pO, XO) {
          hK(OO).samplerParameterf(hK(KO), pO >>> 0, XO)
        },
        E8md: function(OO, KO, pO, XO) {
          hK(OO).samplerParameteri(hK(KO), pO >>> 0, XO)
        },
        Hiji: function() {
          return DK((function(OO, KO) {
            const pO = zp(hK(KO).search, gp.tyHa, gp.iGiR),
              XO = uK;
            WO().setInt32(OO + 4, XO, !0), WO().setInt32(OO + 0, pO, !0)
          }), arguments)
        },
        EJH9: function() {
          return DK((function(OO, KO, pO) {
            return hK(OO).setTimeout(hK(KO), pO)
          }), arguments)
        },
        sJca: function() {
          return DK((function(OO, KO, pO) {
            return Reflect.set(hK(OO), hK(KO), hK(pO))
          }), arguments)
        },
        a5hM: function(OO, KO) {
          hK(OO).alpha = 0 !== KO
        },
        YZqX: function(OO, KO) {
          hK(OO).antialias = 0 !== KO
        },
        zXFi: function(OO, KO) {
          hK(OO).depth = 0 !== KO
        },
        FyEh: function(OO, KO) {
          hK(OO).height = KO >>> 0
        },
        g9eN: function(OO, KO) {
          hK(OO).powerPreference = rK[KO]
        },
        KVnr: function(OO, KO) {
          hK(OO).premultipliedAlpha = 0 !== KO
        },
        IZNi: function(OO, KO) {
          hK(OO).preserveDrawingBuffer = 0 !== KO
        },
        xXAJ: function(OO, KO) {
          hK(OO).stencil = 0 !== KO
        },
        uIxt: function(OO, KO) {
          hK(OO).width = KO >>> 0
        },
        H3vY: function(OO, KO, pO, XO) {
          hK(OO).shaderSource(hK(KO), XK(pO, XO))
        },
        gltP: function(OO, KO, pO, XO) {
          hK(OO).shaderSource(hK(KO), XK(pO, XO))
        },
        ynPT: function() {
          const OO = "undefined" === typeof global ? null : global;
          return oK(OO) ? 0 : HO(OO)
        },
        Yrbc: function() {
          const OO = "undefined" === typeof globalThis ? null : globalThis;
          return oK(OO) ? 0 : HO(OO)
        },
        Vw3e: function() {
          const OO = "undefined" === typeof self ? null : self;
          return oK(OO) ? 0 : HO(OO)
        },
        J25L: function() {
          const OO = "undefined" === typeof window ? null : window;
          return oK(OO) ? 0 : HO(OO)
        },
        EaLs: function(OO) {
          return HO(hK(OO).style)
        },
        atPL: function(OO, KO, pO) {
          return HO(hK(OO).subarray(KO >>> 0, pO >>> 0))
        },
        GbOg: function(OO, KO, pO, XO) {
          hK(OO).texParameterf(KO >>> 0, pO >>> 0, XO)
        },
        JVgJ: function(OO, KO, pO, XO) {
          hK(OO).texParameterf(KO >>> 0, pO >>> 0, XO)
        },
        RgFu: function(OO, KO, pO, XO) {
          hK(OO).texParameteri(KO >>> 0, pO >>> 0, XO)
        },
        Cdl8: function(OO, KO, pO, XO) {
          hK(OO).texParameteri(KO >>> 0, pO >>> 0, XO)
        },
        euYa: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).texStorage2D(KO >>> 0, pO, XO >>> 0, bK, eO)
        },
        fEfi: function(OO, KO, pO, XO, bK, eO, lO) {
          hK(OO).texStorage3D(KO >>> 0, pO, XO >>> 0, bK, eO, lO)
        },
        NOuw: function() {
          return DK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            hK(OO).texSubImage2D(KO >>> 0, pO, XO, bK, eO, lO, vK >>> 0, CO >>> 0, hK(hO))
          }), arguments)
        },
        d88m: function() {
          return DK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            hK(OO).texSubImage2D(KO >>> 0, pO, XO, bK, eO, lO, vK >>> 0, CO >>> 0, hK(hO))
          }), arguments)
        },
        eE5Z: function() {
          return DK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            hK(OO).texSubImage2D(KO >>> 0, pO, XO, bK, eO, lO, vK >>> 0, CO >>> 0, hK(hO))
          }), arguments)
        },
        bO2h: function() {
          return DK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            hK(OO).texSubImage2D(KO >>> 0, pO, XO, bK, eO, lO, vK >>> 0, CO >>> 0, hK(hO))
          }), arguments)
        },
        m18k: function() {
          return DK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO) {
            hK(OO).texSubImage3D(KO >>> 0, pO, XO, bK, eO, lO, vK, CO, hO >>> 0, DO >>> 0, hK(MO))
          }), arguments)
        },
        eGCi: function() {
          return DK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO) {
            hK(OO).texSubImage3D(KO >>> 0, pO, XO, bK, eO, lO, vK, CO, hO >>> 0, DO >>> 0, hK(MO))
          }), arguments)
        },
        Jkrg: function() {
          return DK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO) {
            hK(OO).texSubImage3D(KO >>> 0, pO, XO, bK, eO, lO, vK, CO, hO >>> 0, DO >>> 0, hK(MO))
          }), arguments)
        },
        EHbC: function() {
          return DK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO) {
            hK(OO).texSubImage3D(KO >>> 0, pO, XO, bK, eO, lO, vK, CO, hO >>> 0, DO >>> 0, hK(MO))
          }), arguments)
        },
        dlEm: function(OO, KO) {
          return HO(hK(OO).then(hK(KO)))
        },
        xXD5: function(OO, KO, pO) {
          hK(OO).uniform1f(hK(KO), pO)
        },
        EzIe: function(OO, KO, pO) {
          hK(OO).uniform1f(hK(KO), pO)
        },
        iznW: function(OO, KO, pO) {
          hK(OO).uniform1i(hK(KO), pO)
        },
        gpkX: function(OO, KO, pO) {
          hK(OO).uniform1i(hK(KO), pO)
        },
        gQn7: function(OO, KO, pO) {
          hK(OO).uniform1ui(hK(KO), pO >>> 0)
        },
        h8RV: function(OO, KO, pO, XO) {
          hK(OO).uniform2f(hK(KO), pO, XO)
        },
        ghcZ: function(OO, KO, pO, XO) {
          hK(OO).uniform2f(hK(KO), pO, XO)
        },
        dpB8: function(OO, KO, pO, XO) {
          hK(OO).uniformBlockBinding(hK(KO), pO >>> 0, XO >>> 0)
        },
        O1lM: function(OO, KO) {
          hK(OO).useProgram(hK(KO))
        },
        TOtm: function(OO, KO) {
          hK(OO).useProgram(hK(KO))
        },
        y2bf: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).vertexAttrib4f(KO >>> 0, pO, XO, bK, eO)
        },
        beVU: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).vertexAttrib4f(KO >>> 0, pO, XO, bK, eO)
        },
        TRIT: function(OO, KO, pO) {
          hK(OO).vertexAttribDivisorANGLE(KO >>> 0, pO >>> 0)
        },
        MfeZ: function(OO, KO, pO) {
          hK(OO).vertexAttribDivisor(KO >>> 0, pO >>> 0)
        },
        Hanv: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).vertexAttribI4i(KO >>> 0, pO, XO, bK, eO)
        },
        c8y9: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).vertexAttribI4ui(KO >>> 0, pO >>> 0, XO >>> 0, bK >>> 0, eO >>> 0)
        },
        hjJT: function(OO, KO, pO, XO, bK, eO) {
          hK(OO).vertexAttribIPointer(KO >>> 0, pO, XO >>> 0, bK, eO)
        },
        AAJm: function(OO, KO, pO, XO, bK, eO, lO) {
          hK(OO).vertexAttribPointer(KO >>> 0, pO, XO >>> 0, 0 !== bK, eO, lO)
        },
        ElYQ: function(OO, KO, pO, XO, bK, eO, lO) {
          hK(OO).vertexAttribPointer(KO >>> 0, pO, XO >>> 0, 0 !== bK, eO, lO)
        },
        HXyv: function(OO, KO, pO, XO, bK) {
          hK(OO).viewport(KO, pO, XO, bK)
        },
        jNma: function(OO, KO, pO, XO, bK) {
          hK(OO).viewport(KO, pO, XO, bK)
        },
        WjEo: function(OO, KO) {
          console.warn(XK(OO, KO))
        },
        JjvQ: function(OO) {
          return hK(OO).width
        },
        I2CA: function(OO) {
          return hK(OO).width
        },
        avIx: function(OO) {
          return hK(OO).width
        },
        B5kO: function(OO, KO) {
          return HO(FK(OO, KO, iK))
        },
        oDt0: function(OO, KO) {
          return HO(FK(OO, KO, wO))
        },
        eVGo: function(OO, KO) {
          return HO(FK(OO, KO, YO))
        },
        VKwN: function(OO) {
          return HO(OO)
        },
        rcjP: function(OO, KO) {
          return HO(cK(OO, KO))
        },
        O6QG: function(OO, KO) {
          var pO, XO;
          return HO((pO = OO, XO = KO, pO >>>= 0, (null !== OK && 0 !== OK.byteLength || (OK = new Int16Array(gp.memory.buffer)), OK).subarray(pO / 2, pO / 2 + XO)))
        },
        T7XC: function(OO, KO) {
          return HO(ZO(OO, KO))
        },
        dOV5: function(OO, KO) {
          var pO, XO;
          return HO((pO = OO, XO = KO, pO >>>= 0, (null !== pK && 0 !== pK.byteLength || (pK = new Int8Array(gp.memory.buffer)), pK).subarray(pO / 1, pO / 1 + XO)))
        },
        JLNK: function(OO, KO) {
          var pO, XO;
          return HO((pO = OO, XO = KO, pO >>>= 0, (null !== bp && 0 !== bp.byteLength || (bp = new Uint16Array(gp.memory.buffer)), bp).subarray(pO / 2, pO / 2 + XO)))
        },
        iS2F: function(OO, KO) {
          return HO(qK(OO, KO))
        },
        RHZv: function(OO, KO) {
          return HO(xK(OO, KO))
        },
        aXyy: function(OO, KO) {
          return HO(XK(OO, KO))
        },
        yWUq: function(OO) {
          return HO(hK(OO))
        },
        DVC6: function(OO) {
          AK(OO)
        }
      };
      return {
        __proto__: null,
        UDIe: OO
      }
    }

    function YO(OO, KO) {
      gp.MBCI(OO, KO)
    }

    function wO(OO, KO, pO) {
      gp.UQ3f(OO, KO, HO(pO))
    }

    function iK(OO, KO, pO) {
      const XO = gp.mHkU(OO, KO, HO(pO));
      if (XO[1]) throw AK(XO[0])
    }
    Symbol.dispose && (lO.prototype[Symbol.dispose] = lO.prototype.free);
    const rK = ["default", "low-power", "high-performance"],
      PO = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => gp.qMYT(OO, 1))),
      mK = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => gp.vhq0(OO, 1))),
      sO = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => gp.FwV4(OO, 1)));

    function HO(OO) {
      ap === MK.length && MK.push(MK.length + 1);
      const KO = ap;
      return ap = MK[KO], MK[KO] = OO, KO
    }

    function RO(OO, KO) {
      if (!(OO instanceof KO)) throw new Error(`expected instance of ${KO.name}`)
    }
    const SO = "undefined" === typeof FinalizationRegistry ? {
      register: () => {},
      unregister: () => {}
    } : new FinalizationRegistry((OO => gp.I4iJ(OO.a, OO.b)));

    function JO(OO) {
      const KO = typeof OO;
      if ("number" == KO || "boolean" == KO || null == OO) return `${OO}`;
      if ("string" == KO) return `"${OO}"`;
      if ("symbol" == KO) {
        const KO = OO.description;
        return null == KO ? "Symbol" : `Symbol(${KO})`
      }
      if ("function" == KO) {
        const KO = OO.name;
        return "string" == typeof KO && KO.length > 0 ? `Function(${KO})` : "Function"
      }
      if (Array.isArray(OO)) {
        const KO = OO.length;
        let pO = "[";
        KO > 0 && (pO += JO(OO[0]));
        for (let XO = 1; XO < KO; XO++) pO += ", " + JO(OO[XO]);
        return pO += "]", pO
      }
      const pO = /\[object ([^\]]+)\]/.exec(toString.call(OO));
      let XO;
      if (!(pO && pO.length > 1)) return toString.call(OO);
      if (XO = pO[1], "Object" == XO) try {
        return "Object(" + JSON.stringify(OO) + ")"
      } catch (bK) {
        return "Object"
      }
      return OO instanceof Error ? `${OO.name}: ${OO.message}\n${OO.stack}` : XO
    }

    function cK(OO, KO) {
      return OO >>>= 0,
        function() {
          null !== tK && 0 !== tK.byteLength || (tK = new Float32Array(gp.memory.buffer));
          return tK
        }().subarray(OO / 4, OO / 4 + KO)
    }

    function BO(OO, KO) {
      return OO >>>= 0, UO().subarray(OO / 8, OO / 8 + KO)
    }

    function ZO(OO, KO) {
      return OO >>>= 0,
        function() {
          null !== KK && 0 !== KK.byteLength || (KK = new Int32Array(gp.memory.buffer));
          return KK
        }().subarray(OO / 4, OO / 4 + KO)
    }

    function GO(OO, KO) {
      OO >>>= 0;
      const pO = WO(),
        XO = [];
      for (let bK = OO; bK < OO + 4 * KO; bK += 4) XO.push(AK(pO.getUint32(bK, !0)));
      return XO
    }

    function qK(OO, KO) {
      return OO >>>= 0, lK().subarray(OO / 4, OO / 4 + KO)
    }

    function xK(OO, KO) {
      return OO >>>= 0, CK().subarray(OO / 1, OO / 1 + KO)
    }
    let nO = null;

    function WO() {
      return (null === nO || !0 === nO.buffer.detached || void 0 === nO.buffer.detached && nO.buffer !== gp.memory.buffer) && (nO = new DataView(gp.memory.buffer)), nO
    }
    let tK = null;
    let kK = null;

    function UO() {
      return null !== kK && 0 !== kK.byteLength || (kK = new Float64Array(gp.memory.buffer)), kK
    }
    let OK = null;
    let KK = null;
    let pK = null;

    function XK(OO, KO) {
      return function(OO, KO) {
        TK += KO, TK >= dK && (fK = new TextDecoder("utf-8", {
          ignoreBOM: !0,
          fatal: !0
        }), fK.decode(), TK = KO);
        return fK.decode(CK().subarray(OO, OO + KO))
      }(OO >>> 0, KO)
    }
    let bp = null;
    let eK = null;

    function lK() {
      return null !== eK && 0 !== eK.byteLength || (eK = new Uint32Array(gp.memory.buffer)), eK
    }
    let vp = null;

    function CK() {
      return null !== vp && 0 !== vp.byteLength || (vp = new Uint8Array(gp.memory.buffer)), vp
    }

    function hK(OO) {
      return MK[OO]
    }

    function DK(OO, KO) {
      try {
        return OO.apply(this, KO)
      } catch (pO) {
        gp.N5Co(HO(pO))
      }
    }
    let MK = new Array(1024).fill(void 0);
    MK.push(void 0, null, !0, !1);
    let ap = MK.length;

    function oK(OO) {
      return void 0 === OO || null === OO
    }

    function FK(OO, KO, pO) {
      const XO = {
          a: OO,
          b: KO,
          cnt: 1
        },
        bK = function() {
          XO.cnt++;
          const OO = XO.a;
          XO.a = 0;
          try {
            for (var KO = arguments.length, eO = new Array(KO), lO = 0; lO < KO; lO++) eO[lO] = arguments[lO];
            return pO(OO, XO.b, ...eO)
          } finally {
            XO.a = OO, bK._wbg_cb_unref()
          }
        };
      return bK._wbg_cb_unref = () => {
        0 === --XO.cnt && (gp.I4iJ(XO.a, XO.b), XO.a = 0, SO.unregister(XO))
      }, SO.register(bK, XO, XO), bK
    }

    function VK(OO, KO) {
      const pO = KO(4 * OO.length, 4) >>> 0;
      return lK().set(OO, pO / 4), uK = OO.length, pO
    }

    function LK(OO, KO) {
      const pO = KO(1 * OO.length, 1) >>> 0;
      return CK().set(OO, pO / 1), uK = OO.length, pO
    }

    function QK(OO, KO) {
      const pO = KO(4 * OO.length, 4) >>> 0,
        XO = WO();
      for (let bK = 0; bK < OO.length; bK++) XO.setUint32(pO + 4 * bK, HO(OO[bK]), !0);
      return uK = OO.length, pO
    }

    function zp(OO, KO, pO) {
      if (void 0 === pO) {
        const pO = NK.encode(OO),
          XO = KO(pO.length, 1) >>> 0;
        return CK().subarray(XO, XO + pO.length).set(pO), uK = pO.length, XO
      }
      let XO = OO.length,
        bK = KO(XO, 1) >>> 0;
      const eO = CK();
      let lO = 0;
      for (; lO < XO; lO++) {
        const KO = OO.charCodeAt(lO);
        if (KO > 127) break;
        eO[bK + lO] = KO
      }
      if (lO !== XO) {
        0 !== lO && (OO = OO.slice(lO)), bK = pO(bK, XO, XO = lO + 3 * OO.length, 1) >>> 0;
        const KO = CK().subarray(bK + lO, bK + XO);
        lO += NK.encodeInto(OO, KO).written, bK = pO(bK, XO, lO, 1) >>> 0
      }
      return uK = lO, bK
    }

    function AK(OO) {
      const KO = hK(OO);
      return function(OO) {
        OO < 1028 || (MK[OO] = ap, ap = OO)
      }(OO), KO
    }
    let fK = new TextDecoder("utf-8", {
      ignoreBOM: !0,
      fatal: !0
    });
    fK.decode();
    const dK = 2146435072;
    let TK = 0;
    const NK = new TextEncoder;
    "encodeInto" in NK || (NK.encodeInto = function(OO, KO) {
      const pO = NK.encode(OO);
      return KO.set(pO), {
        read: OO.length,
        written: pO.length
      }
    });
    let IK, yp, gp, uK = 0;

    function EK(OO, KO) {
      return yp = OO, gp = OO.exports, IK = KO, nO = null, tK = null, kK = null, OK = null, KK = null, pK = null, bp = null, eK = null, vp = null, gp.UsfZ(), gp
    }

    function jp(OO) {
      if (void 0 !== gp) return gp;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module: OO
      } = OO) : console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));
      const KO = jK();
      OO instanceof WebAssembly.Module || (OO = new WebAssembly.Module(OO));
      return EK(new WebAssembly.Instance(OO, KO), OO)
    }
    async function YK(OO) {
      if (void 0 !== gp) return gp;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module_or_path: OO
      } = OO) : console.warn("using deprecated parameters for the initialization function; pass a single object instead"));
      const KO = jK();
      ("string" === typeof OO || "function" === typeof Request && OO instanceof Request || "function" === typeof URL && OO instanceof URL) && (OO = fetch(OO));
      const {
        instance: pO,
        module: XO
      } = await async function(OO, KO) {
        if ("function" === typeof Response && OO instanceof Response) {
          if (!OO.ok) throw new Error(`failed to fetch Wasm: ${OO.status} ${OO.statusText} fetching '${OO.url}'`);
          if ("function" === typeof WebAssembly.instantiateStreaming) try {
            return await WebAssembly.instantiateStreaming(OO, KO)
          } catch (pO) {
            if (! function(OO) {
                switch (OO) {
                  case "basic":
                  case "cors":
                  case "default":
                    return !0
                }
                return !1
              }(OO.type) || "application/wasm" === OO.headers.get("Content-Type")) throw pO;
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", pO)
          }
          const XO = await OO.arrayBuffer();
          return await WebAssembly.instantiate(XO, KO)
        } {
          const pO = await WebAssembly.instantiate(OO, KO);
          return pO instanceof WebAssembly.Instance ? {
            instance: pO,
            module: OO
          } : pO
        }
      }(await OO, KO);
      return EK(pO, XO)
    }
    const wK = {
      name: "bloxd_wasm_webgl",
      url: () => new pO.U(pO(41282)),
      init: YK,
      MX: XO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);