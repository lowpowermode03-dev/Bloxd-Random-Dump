export const id = 110;
export const ids = [110];
export const modules = {
  5662: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => eO
    });
    var XO = pO(1051),
      bK = pO(976);

    function eO() {
      const {
        t: OO
      } = (0, XO.D)();
      return (0, bK.jsxs)("div", {
        className: "LegalText",
        children: [(0, bK.jsx)("div", {
          className: "BloxdInformationHeader FullyFancyText",
          children: OO("homePage:termsOfService")
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsx)("em", {
            children: "Last updated: July 15, 2025"
          })
        }), (0, bK.jsx)("p", {
          children: 'These Terms of Service ("Terms") govern your access to and use of the Bloxd.io website and services (the "Services"). These Terms form a legally binding agreement between you and Bloxd LTD ("we," "us" or "our"). By using our Services, you agree to these Terms in full. If you do not agree, you may not access or use our Services.'
        }), (0, bK.jsx)("h3", {
          children: "1. General Information"
        }), (0, bK.jsx)("p", {
          children: "We may update these Terms at any time. When we do, we\u2019ll post the revised version on our website with the new effective date. Your continued use of Bloxd.io after the changes take effect means you accept the updated Terms. If you do not agree to the changes, you must stop using the Services."
        }), (0, bK.jsx)("h3", {
          children: "2. Definitions"
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: '"Account" means the account you create to access the Services on Bloxd.io.'
            }), (0, bK.jsx)("li", {
              children: '"Company" refers to Bloxd LTD and its affiliates, subsidiaries, and associated entities.'
            }), (0, bK.jsx)("li", {
              children: '"Services" includes the Bloxd.io website, games, content, and related services provided by us.'
            }), (0, bK.jsx)("li", {
              children: '"User", "you", or "your" refers to anyone using the Services.'
            }), (0, bK.jsx)("li", {
              children: '"Content" means all text, graphics, logos, images, software, and other material found on Bloxd.io.'
            }), (0, bK.jsx)("li", {
              children: '"Virtual Goods" refers to virtual items available for purchase within Bloxd.io, such as game items and in-game currency.'
            })]
          })
        }), (0, bK.jsx)("h3", {
          children: "3. Age Requirements"
        }), (0, bK.jsx)("p", {
          children: "To use Bloxd.io, you must be at least 13 years old. If you are under 13, you need permission from a parent or guardian. By using our Services, you confirm that you meet this age or permission requirement."
        }), (0, bK.jsx)("h3", {
          children: "4. Account Creation and Security"
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "Account Information: You agree to provide accurate and complete information when creating your account. You are responsible for keeping your account information secure and confidential."
            }), (0, bK.jsx)("li", {
              children: "Account Security: Notify us immediately if you suspect unauthorized access to your account. We are not liable for any loss or damage arising from your failure to secure your account."
            })]
          })
        }), (0, bK.jsx)("h3", {
          children: "5. User Conduct and Community Guidelines"
        }), (0, bK.jsx)("p", {
          children: "We are committed to creating a fun, safe, and inclusive environment for everyone. By using Bloxd.io, you agree to follow our Community Conduct Guidelines and adhere to the following rules:"
        }), (0, bK.jsx)("h4", {
          children: "Expected Behavior"
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "Show Respect: Treat others with kindness and consideration in all interactions."
            }), (0, bK.jsx)("li", {
              children: "Promote Positivity: Engage in activities that contribute to a positive community experience."
            }), (0, bK.jsx)("li", {
              children: "Play Fairly: Participate honestly and with integrity, respecting the rules and spirit of the game."
            })]
          })
        }), (0, bK.jsx)("h4", {
          children: "Prohibited Behavior"
        }), (0, bK.jsxs)("p", {
          children: ["To maintain a safe and welcoming environment, the following actions are strictly prohibited:", (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "Harassment and Threats: Any form of bullying, stalking, or harassment, including making threats or inciting violence."
            }), (0, bK.jsx)("li", {
              children: "Discrimination and Hate Speech: Discriminating against or mocking others based on age, race, ethnicity, gender, sexual orientation, religion, disability, or any other protected characteristic."
            }), (0, bK.jsx)("li", {
              children: "Inappropriate Content and Behavior: Sharing or promoting content that is sexually explicit, violent, or otherwise inappropriate."
            }), (0, bK.jsx)("li", {
              children: "Impersonation: Impersonating other players, staff, or developers with the intent to deceive or harm."
            }), (0, bK.jsx)("li", {
              children: "Account Security and Privacy: Sharing, selling, or trading accounts, or using someone else's account without permission."
            }), (0, bK.jsx)("li", {
              children: "Spam and Advertising: Spamming chat, boards, or other communication channels with repetitive or irrelevant messages."
            }), (0, bK.jsx)("li", {
              children: "Inappropriate World Creation: Creating worlds or lobbies with inappropriate or offensive themes or content."
            })]
          })]
        }), (0, bK.jsx)("h4", {
          children: "Cheating and Unfair Play"
        }), (0, bK.jsxs)("p", {
          children: ["You may not make, use, share, or promote any cheats, hacks, bots, scripts, or other tools that change how the game works or give players an unfair advantage.", (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "This includes trying to bypass any form of security - including, but not limited to, protections related to client integrity or gameplay action security."
            }), (0, bK.jsx)("li", {
              children: "It also includes trying to reverse engineer our game's code in any way, or trying to gain unauthorised access to our systems."
            }), (0, bK.jsx)("li", {
              children: "If you do any of these things, we may suspend or ban your account, and we reserve the right to take civil and/or criminal legal action for your actions harming our game, our players, and our business."
            }), (0, bK.jsx)("li", {
              children: "If you break these rules - like hacking, cheating, or trying to mess with our game or servers - you agree to pay us \xa325,000 for each violation. This is because it's hard to measure exactly how much damage those actions cause, and this amount is a fair estimate of the harm they can do. This doesn't stop us from taking other legal steps if needed, like our right to seek injunctive relief or any other remedy available at law or in equity."
            }), (0, bK.jsx)("li", {
              children: "These rules apply to everyone, whether or not you have a game account, and even if you used a bot or other automated tool to do it."
            })]
          })]
        }), (0, bK.jsx)("h3", {
          children: "6. Software License and IP Restrictions"
        }), (0, bK.jsxs)("ul", {
          children: [(0, bK.jsx)("li", {
            children: "License Grant: We grant you a limited, non-exclusive, non-transferable right to download and run the Bloxd game client solely to access and play our Services."
          }), (0, bK.jsx)("li", {
            children: "What You Can't Do: You may not copy, modify, distribute, or create derivative works of the game client, or attempt to reverse-engineer, decompile, disassemble, hack, bypass security, inject cheats, bots, scripts, or any unauthorized tools. Any such action automatically terminates your license and may lead to legal remedies. For the avoidance of doubt, any use of hacks and cheats including but not limited to killaura, fly exploits, and speed exploits automatically terminates your license and may lead to legal remedies."
          }), (0, bK.jsx)("li", {
            children: "Our Ownership: All intellectual property rights in the game client and Services stay with Bloxd LTD. You get no ownership or other rights here beyond this limited license."
          })]
        }), (0, bK.jsx)("h3", {
          children: "7. Virtual Goods and In-Game Purchases"
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "Purchases: Virtual Goods can be purchased within the Services. All purchases are final and non-refundable unless required by law."
            }), (0, bK.jsx)("li", {
              children: "License: When you purchase Virtual Goods, you receive a limited, non-transferable license to use them within the Services."
            }), (0, bK.jsx)("li", {
              children: "Termination: We may terminate your access to Virtual Goods if you violate these Terms or our Community Conduct Guidelines."
            })]
          })
        }), (0, bK.jsx)("h3", {
          children: "8. Modifications and Updates"
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "Service Changes: We may update or modify the Services at any time without prior notice. We are not liable for any changes, suspensions, or discontinuations of the Services."
            }), (0, bK.jsx)("li", {
              children: "Terms Updates: These Terms may be updated periodically. We will notify you of significant changes, and your continued use of the Services constitutes your acceptance of the new Terms."
            })]
          })
        }), (0, bK.jsx)("h3", {
          children: "9. Termination"
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "Termination by You: You can terminate your account at any time by contacting us."
            }), (0, bK.jsx)("li", {
              children: "Termination by Us: We reserve the right to terminate or suspend your account if you violate these Terms, the Community Conduct Guidelines, or engage in harmful behavior."
            })]
          })
        }), (0, bK.jsx)("h3", {
          children: "10. Reporting and Consequences"
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "Reporting Violations: If you encounter behavior that violates these Terms or the Community Conduct Guidelines, report it using the in-game tools. Your reports help us maintain a high-quality, enjoyable experience for everyone."
            }), (0, bK.jsx)("li", {
              children: "Consequences for Violations: Breaking these guidelines can result in penalties ranging from temporary suspensions to permanent bans. Players who demonstrate positive behavior over time may see a reduction in penalties."
            })]
          })
        }), (0, bK.jsx)("h3", {
          children: "11. Disclaimer of Warranties"
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: 'As-Is Basis: The Services are provided "as is" and "as available", without any warranties, either express or implied.'
            }), (0, bK.jsx)("li", {
              children: "No Warranty: We do not guarantee that the Services will be uninterrupted or error-free."
            })]
          })
        }), (0, bK.jsx)("h3", {
          children: "12. Limitation of Liability"
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "No Liability: To the maximum extent permitted by law, we are not liable for any indirect, incidental, special, or consequential damages arising from your use of the Services."
            }), (0, bK.jsx)("li", {
              children: "Total Liability: Our total liability to you for any claims related to the Services is limited to the amount you paid us in the past 12 months."
            })]
          })
        }), (0, bK.jsx)("h3", {
          children: "13. Governing Law and Dispute Resolution"
        }), (0, bK.jsx)("p", {
          children: (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "Governing Law: These Terms are governed by the laws of England and Wales."
            }), (0, bK.jsx)("li", {
              children: "Small-Claims Court Option: If you or we seek only money damages up to the small-claims track limit set by the Civil Procedure Rules (currently \xa310,000), you may choose to bring that claim in the County Court small-claims track in England and Wales. This does not cover any other kinds of relief (like injunctions), nor can you split one dispute into several small claims to get around this limit."
            }), (0, bK.jsx)("li", {
              children: "Dispute Resolution: Any other disputes arising from these Terms will be resolved through binding arbitration in London, United Kingdom. You waive any right to participate in a class action or jury trial."
            }), (0, bK.jsx)("li", {
              children: "Equitable Relief for Bloxd: Even though we agree to arbitrate all other non-small claim disputes, only Bloxd LTD (not you) may go to an English or Welsh court for urgent orders - like injunctions or specific-performance - to protect our IP, confidential data, account security, gameplay experience, or the integrity of our service. Asking a court for such relief won't count as breaking our arbitration agreement."
            }), (0, bK.jsx)("li", {
              children: "Identity Verification: If the arbitrator issues any award against you (including for hacks, cheats, or other breaches), you agree that upon request you will promptly provide your full legal name, current address, relevant IP logs, and a copy of a government-issued photo ID to confirm your identity and enable enforcement of the award (including collection of any monetary damages)."
            })]
          })
        }), (0, bK.jsx)("h3", {
          children: "14. Severability"
        }), (0, bK.jsx)("p", {
          children: "If any part of these Terms is found to be unenforceable, the remaining provisions will continue to be in full force and effect."
        }), (0, bK.jsx)("h3", {
          children: "15. Contact Information"
        }), (0, bK.jsxs)("p", {
          children: ["If you have any questions about these Terms, please contact us at:", (0, bK.jsxs)("ul", {
            children: [(0, bK.jsx)("li", {
              children: "Email: privacy@bloxd.io"
            }), (0, bK.jsx)("li", {
              children: "Address: Bloxd LTD, 86-90 Paul Street, London, England, United Kingdom, EC2A 4NE"
            })]
          })]
        }), (0, bK.jsx)("h3", {
          children: "16. Entire Agreement"
        }), (0, bK.jsx)("p", {
          children: "These Terms, together with our Privacy Policy and Community Conduct Guidelines, constitute the entire agreement between you and Bloxd LTD regarding your use of the Services. They supersede any prior agreements or communications."
        })]
      })
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);