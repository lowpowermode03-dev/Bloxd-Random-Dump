export const id = 21;
export const ids = [21];
export const modules = {
  35130: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      h: () => FO,
      i: () => aK,
      k: () => MO
    });
    var XO = pO(8311),
      bK = pO(35137),
      eO = pO(35139),
      lO = pO(7854),
      vK = pO(1263),
      CO = pO(63),
      hO = pO(77),
      DO = pO(976);

    function MO() {
      var OO;
      return (0, vK.h)(bK.d, (0, bK.l)()), (0, DO.jsx)(DO.Fragment, {
        children: null === (OO = (0, bK.l)()) || void 0 === OO ? void 0 : OO.content
      })
    }

    function aK(OO) {
      var KO;
      let {
        show: pO
      } = OO;
      (0, vK.h)(bK.d, (0, bK.l)());
      const hO = null === (KO = (0, bK.l)()) || void 0 === KO ? void 0 : KO.menu;
      return (0, CO.useEffect)((() => {
        var OO;
        pO || (null === hO || void 0 === hO || null === (OO = hO.onClose) || void 0 === OO || OO.call(hO), (0, eO.q)())
      }), [pO, hO]), (0, CO.useEffect)((() => pO ? (0, lO.f)(eO.y, eO.f) : void 0), [pO]), (0, DO.jsx)(XO.e, {
        showing: pO,
        globallyUniqueKey: "clientGameMenu",
        children: null === hO || void 0 === hO ? void 0 : hO.content
      })
    }

    function oO(OO) {
      let {
        placement: KO = "bottom"
      } = OO;
      return (0, DO.jsx)("div", {
        id: `clientGameHud-${KO}`,
        style: {
          display: "contents"
        }
      })
    }

    function FO(OO) {
      let {
        children: KO,
        placement: pO = "bottom"
      } = OO;
      const [XO, bK] = (0, CO.useState)(null);
      return (0, CO.useEffect)((() => {
        bK(document.getElementById(`clientGameHud-${pO}`))
      }), [pO]), XO ? (0, hO.createPortal)(KO, XO) : null
    }
  },
  8311: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(3725),
      bK = pO(3730);

    function eO(OO) {
      let {
        children: KO,
        showing: pO,
        globallyUniqueKey: eO,
        alwaysMountChildren: lO = !1,
        doGameplayStartStopOnShow: vK = !0,
        keepsMovement: CO = !1
      } = OO;
      return (0, bK.b)(!0, pO, eO, CO), (0, XO.e)(vK, pO), pO || lO ? KO : null
    }
  },
  35238: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      g: () => lO,
      h: () => vK,
      l: () => CO
    });
    var XO = pO(63),
      bK = pO(1e3);
    const eO = 8,
      lO = "InGameHeaderContainer",
      vK = "TopRightElements";

    function CO(OO) {
      const [KO] = (0, bK.c)(), [pO, CO] = (0, XO.useState)(!1);
      return (0, XO.useLayoutEffect)((() => {
        if (!OO) return;
        const KO = document.querySelector(`.${lO}`),
          pO = document.querySelector(`.${vK}`),
          XO = () => {
            const XO = OO.getBoundingClientRect(),
              bK = KO ? KO.getBoundingClientRect().right : 0,
              lO = pO ? pO.getBoundingClientRect().left : window.innerWidth,
              vK = XO.left < bK + eO,
              hO = XO.right > lO - eO;
            CO(vK || hO)
          };
        XO();
        const bK = new ResizeObserver(XO);
        return bK.observe(OO), KO && bK.observe(KO), pO && bK.observe(pO), () => {
          bK.disconnect()
        }
      }), [OO, KO]), pO
    }
  },
  7854: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      f: () => bK
    });
    let XO = null;
    const bK = function(OO) {
        const KO = {
          cycle: OO,
          canCycle: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => !0
        };
        return XO = KO, () => {
          XO === KO && (XO = null)
        }
      },
      eO = () => {
        var OO;
        return null !== (OO = XO) && void 0 !== OO && OO.canCycle() ? XO.cycle : null
      }
  },
  35139: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => zK,
      c: () => eO,
      f: () => VO,
      i: () => LO,
      m: () => vK,
      n: () => aK,
      q: () => QO,
      s: () => MO,
      u: () => AO,
      y: () => FO
    });
    var XO = pO(22),
      bK = pO(26);
    const eO = "clientGameInventoryButtonsChanged",
      lO = new Map;

    function vK() {
      return [...lO.values()].sort(((OO, KO) => {
        var pO, XO;
        return (null !== (pO = OO.order) && void 0 !== pO ? pO : 0) - (null !== (XO = KO.order) && void 0 !== XO ? XO : 0)
      }))
    }
    let CO = null;

    function hO(OO) {
      CO = OO
    }
    let DO = !1;

    function MO(OO) {
      DO = !0;
      try {
        OO.onClick()
      } finally {
        DO = !1
      }
      OO.panel && "clientGame" === XO.d.get("openInGameMenuName") && hO(OO.id)
    }

    function aK() {
      return DO
    }

    function oO() {
      return vK().filter((OO => OO.panel && !OO.disabled))
    }

    function FO(OO) {
      const KO = oO(),
        pO = KO.findIndex((OO => OO.id === CO));
      return !(pO < 0 || KO.length < 2) && (MO(KO[(pO + OO + KO.length) % KO.length]), !0)
    }

    function VO() {
      return null !== CO && oO().length > 1
    }

    function LO() {
      hO(null)
    }

    function QO() {
      "inventory" !== XO.d.get("openInGameMenuName") && hO(null)
    }

    function zK() {
      const OO = CO;
      return hO(null), OO
    }

    function AO(OO) {
      return lO.set(OO.id, OO), bK.i.pl(eO, vK(), !0), () => {
        lO.get(OO.id) === OO && (lO.delete(OO.id), bK.i.pl(eO, vK()))
      }
    }
  },
  35137: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      g: () => LO,
      j: () => QO,
      k: () => aK,
      l: () => hO,
      o: () => VO,
      p: () => oO,
      q: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(1136),
      lO = pO(35139);
    const vK = "clientGameUiChanged";
    let CO = null;

    function hO() {
      return CO
    }

    function DO(OO, KO) {
      const pO = {
        content: OO,
        menu: KO
      };
      return CO = pO, bK.i.pl(vK, CO, !0), () => {
        CO === pO && (CO = null, FO = !1, LO(), bK.i.pl(vK, null))
      }
    }
    let MO = null;

    function aK() {
      return MO
    }

    function oO(OO) {
      return MO = OO, () => {
        MO === OO && (MO = null)
      }
    }
    let FO = !1;

    function VO() {
      const OO = XO.d.get("openInGameMenuName");
      "clientGame" !== OO && (FO = "inventory" === OO), (0, lO.n)() || (0, lO.i)(), (0, eO.k)("InGameMenu"), XO.d.set({
        openInGameMenuName: "clientGame",
        openEverythingMenuName: null
      })
    }

    function LO() {
      zK(!1)
    }

    function QO() {
      zK(FO)
    }

    function zK(OO) {
      "clientGame" === XO.d.get("openInGameMenuName") && XO.d.set({
        openInGameMenuName: OO ? "inventory" : null
      }), OO || (0, lO.i)(), FO = !1
    }
  },
  36904: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO,
      f: () => vK,
      g: () => CO
    });
    const XO = [1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1],
      bK = [0, 1, 2, 0, 2, 3],
      eO = [4, 5];

    function lO(OO, KO, pO, XO, bK) {
      for (let lO = 0; lO < 6; lO++) eO.includes(lO) === bK && hO(OO, KO, pO, XO, lO)
    }

    function vK(OO, KO, pO, XO) {
      for (let bK = 0; bK < 6; bK++) hO(OO, KO, pO, XO, bK)
    }

    function CO(OO, KO, pO, eO, lO) {
      for (let vK = 0; vK < 6; vK++)
        for (const CO of [0, 1]) {
          const [hO, DO, MO] = [CO + 2, CO + 1, (CO + 3) % 4], aK = OO.length / 3;
          for (const [KO, bK] of [
              [CO, DO],
              [hO, DO],
              [hO, MO],
              [CO, MO]
            ])
            for (let CO = 0; CO < 3; CO++) {
              const hO = XO[3 * (4 * vK + KO) + CO],
                DO = XO[3 * (4 * vK + bK) + CO];
              OO.push((hO + (DO - hO) * lO) * eO / 2 + pO[CO])
            }
          for (const OO of bK) KO.push(aK + OO)
        }
    }

    function hO(OO, KO, pO, eO, lO) {
      let [vK, CO, hO] = pO, [DO, MO, aK] = eO;
      const oO = OO.length / 3;
      for (let bK = 4 * lO; bK < 4 * lO + 4; bK++) OO.push(XO[3 * bK] * DO / 2 + vK, XO[3 * bK + 1] * MO / 2 + CO, XO[3 * bK + 2] * aK / 2 + hO);
      for (const XO of bK) KO.push(oO + XO)
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);