export const id = 131;
export const ids = [131];
export const modules = {
  7165: (OO, KO, pO) => {
    pO.d(KO, {
      encodeBinaryMessageWithMetricsCookies: () => bK
    });
    var XO = pO(3006);

    function bK(OO) {
      return XO.m.toBuffer(OO)
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);