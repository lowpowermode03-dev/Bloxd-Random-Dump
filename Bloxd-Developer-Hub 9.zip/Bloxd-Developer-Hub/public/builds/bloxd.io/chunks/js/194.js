export const id = 194;
export const ids = [194];
export const modules = {
  34925: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      CreateCustomLobby: () => jK
    });
    pO(34932);
    var XO = pO(3812),
      bK = pO(63),
      eO = pO(1475),
      lO = pO(918),
      vK = pO.n(lO),
      CO = pO(2430),
      hO = pO(1008),
      DO = pO(1056),
      MO = pO(3764),
      aK = pO(1271),
      oO = pO(34934),
      FO = pO(1051),
      VO = pO(1165),
      LO = pO(1344),
      QO = pO(22),
      zK = pO(1273),
      AO = pO(533),
      fO = pO(4059),
      dO = pO(638),
      TO = pO(1098),
      NO = pO(1077),
      IO = pO(4070),
      yK = pO(933),
      gK = pO(34940),
      uO = pO(34948),
      EO = pO(976);

    function jK(OO) {
      var KO, pO, lO, jK;
      let {
        gameNameWithVariation: YO,
        close: wO,
        initialDefaultGamemode: iK
      } = OO;
      const {
        t: rK
      } = (0, FO.D)(), PO = (0, LO.useNavigatePreserveSearch)(), [mK, sO] = (0, bK.useState)("Enter"), [HO, RO] = (0, bK.useState)(""), SO = bK.useRef(null), JO = null === (KO = dO.e[YO]) || void 0 === KO ? void 0 : KO.showWorldsInsteadOfCustomLobbies, cK = JO ? 1 : null === (pO = dO.e[YO]) || void 0 === pO ? void 0 : pO.customLobbyCustomSchematicLimit, [BO, ZO] = (0, bK.useState)(!JO);
      iK || (iK = "classic_creative" === YO || "classic_creativeFlat" === YO ? "creative" : "classic" === YO ? "peaceful" : "survival");
      const GO = {
        baseOptions: {
          gameNameWithVariation: JO ? "classic" : YO,
          name: "",
          visibility: "unlisted"
        },
        listedOptions: {
          description: "",
          color: "",
          emojis: ""
        },
        mapOptions: {
          mapType: "classic_creativeFlat" === YO ? "flat" : "default",
          schematicIdList: []
        },
        worldOptions: null
      };
      JO && (GO.worldOptions = {
        defaultGamemode: iK,
        disableProtectors: !1,
        spawnProtection: !0,
        disableTpRequests: !1,
        disableTribeCreation: !1,
        disableLobbySpawn: !1,
        voidDeathHeight: -1e4,
        worldBorder: null,
        disableFallDamage: !0,
        disableMobs: !1,
        worldGenSeed: "",
        enableSmpMarketplace: !1,
        enableSurvivalGuns: !1,
        enableSpawnReset: !1,
        enableDayNight: !0
      });
      const [qK, xK] = (0, bK.useState)(GO), [nO, WO] = (0, bK.useState)(null);

      function tK(OO, KO) {
        xK({
          ...qK,
          baseOptions: {
            ...qK.baseOptions,
            [OO]: KO
          }
        })
      }

      function kK(OO, KO) {
        xK({
          ...qK,
          listedOptions: {
            ...qK.listedOptions,
            [OO]: KO
          }
        })
      }

      function UO(OO, KO) {
        xK({
          ...qK,
          worldOptions: {
            ...qK.worldOptions,
            [OO]: KO
          }
        })
      }

      function OK(OO) {
        xK({
          ...qK,
          mapOptions: {
            ...qK.mapOptions,
            ...OO
          }
        })
      }(0, bK.useEffect)((() => {
        MO.e.getNewStarterName().then((OO => {
          xK((KO => "" !== KO.baseOptions.name ? KO : {
            ...KO,
            baseOptions: {
              ...KO.baseOptions,
              name: OO
            }
          }))
        })).catch((OO => {
          console.error("Error getting new starter name:", OO)
        }))
      }), []), (0, bK.useEffect)((() => {
        "customSchematic" === qK.mapOptions.mapType && null === nO && (0, hO.postJsonWithMetricsCookiesAndJsonResponse)(`${DO.clientSideServerUrls.indexUrl}/index/schematic/get-owned-schematics`, {}, {
          retries: 0,
          minTimeout: 3e3
        }).then((OO => {
          WO(OO)
        }))
      }), [qK.mapOptions.mapType, nO]);
      const KK = {
          tpRequests: {
            isEnabled: () => !qK.worldOptions.disableTpRequests,
            WE: OO => {
              UO("disableTpRequests", !OO)
            }
          },
          spawnProtection: {
            isEnabled: () => qK.worldOptions.spawnProtection,
            WE: OO => {
              UO("spawnProtection", OO)
            }
          },
          spawnReset: {
            isEnabled: () => qK.worldOptions.enableSpawnReset,
            WE: OO => {
              UO("enableSpawnReset", OO)
            }
          },
          smpMarketplace: {
            isEnabled: () => qK.worldOptions.enableSmpMarketplace,
            WE: OO => {
              UO("enableSmpMarketplace", OO)
            }
          },
          survivalGuns: {
            isEnabled: () => qK.worldOptions.enableSurvivalGuns,
            WE: OO => {
              UO("enableSurvivalGuns", OO)
            }
          },
          fallDamage: {
            isEnabled: () => !qK.worldOptions.disableFallDamage,
            WE: OO => {
              UO("disableFallDamage", !OO)
            }
          },
          dayNight: {
            isEnabled: () => qK.worldOptions.enableDayNight,
            WE: OO => {
              UO("enableDayNight", OO)
            }
          }
        },
        pK = "Enter" !== mK,
        XK = (0, EO.jsx)(fO.e, {
          className: "NameInput",
          label: "general:name",
          disabled: "Enter" !== mK,
          children: (0, EO.jsx)(eO.e, {
            domRef: SO,
            onValueChange: (OO, KO) => {
              const pO = (0, NO.kb)(OO);
              tK("name", pO), SO.current.value = pO
            },
            maxLength: NO.K,
            defaultValue: qK.baseOptions.name
          })
        });
      return (0, EO.jsxs)("div", {
        className: vK()("CreateCustomLobby", {
          CreateCustomLobbySuccess: "Success" === mK,
          AdvancedMode: BO
        }),
        children: ["Success" === mK && (0, EO.jsxs)("div", {
          className: "CreateCustomLobbySuccessOverlay",
          children: [(0, EO.jsxs)("div", {
            className: "CreateCustomLobbySuccessTitle FullyFancyText AnimFadeInScaleUp",
            children: [(0, EO.jsx)(yK.d, {
              name: "check"
            }), (0, EO.jsx)(zK.b, {})]
          }), (0, EO.jsx)("div", {
            className: "CreateCustomLobbySuccessButtons AnimFadeInScaleUp",
            children: (0, EO.jsx)(aK.m, {
              padDefaultFocus: !0,
              onClick: () => {
                (0, QO.j)("worldCreation"), PO((0, VO.b)(YO, qK.baseOptions.name))
              },
              children: rK("homePage:joinLobbyName", {
                lobbyName: qK.baseOptions.name
              })
            })
          })]
        }), (0, EO.jsx)("div", {
          className: "CreateCustomLobbyTitleContainer",
          children: (0, EO.jsx)("div", {
            className: "CreateCustomLobbyTitle",
            children: rK(JO ? "homePage:createWorld" : "homePage:createCustomLobby")
          })
        }), (0, EO.jsx)(uO.b, {
          locked: pK,
          children: (0, EO.jsxs)("div", {
            className: "CreateCustomLobbyFields",
            children: [!BO && XK, BO && (0, EO.jsxs)("div", {
              className: "BloxdForm",
              children: [(0, EO.jsx)("div", {
                className: "SectionTitle",
                children: rK("customLobby:generalOptions")
              }), (0, EO.jsxs)("div", {
                className: "SectionBody",
                children: [XK, (0, EO.jsx)(fO.e, {
                  label: "customLobby:visibility",
                  circleInfoText: rK("customLobby:visibilityDescription"),
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)(CO.b, {
                    options: XO.n.map((OO => ({
                      value: OO,
                      label: XO.d[OO]
                    }))),
                    value: qK.baseOptions.visibility,
                    onChange: OO => {
                      tK("visibility", OO.value)
                    }
                  })
                })]
              })]
            }), JO && (0, EO.jsx)(gK.b, {
              value: qK.worldOptions.defaultGamemode,
              onChange: OO => {
                UO("defaultGamemode", OO)
              },
              showAll: BO,
              disabled: pK
            }), (JO || !(0, AO.I)(cK) && cK > 0) && (0, EO.jsx)(gK.c, {
              mapTypes: JO ? XO.C : XO.k,
              value: qK.mapOptions.mapType,
              onChange: OO => {
                const KO = {
                  mapType: OO
                };
                "customSchematic" !== OO && (KO.schematicIdList = []), OK(KO)
              },
              showAll: BO,
              disabled: pK,
              children: "customSchematic" === qK.mapOptions.mapType && (0, EO.jsxs)(EO.Fragment, {
                children: [(0, EO.jsxs)("div", {
                  className: "SchematicListTitle AnimFadeIn",
                  children: [JO && rK("customLobby:selectWorldSchematic"), !JO && rK("customLobby:selectCustomLobbySchematics", {
                    schematicLimit: cK
                  })]
                }), (0, EO.jsx)("div", {
                  className: vK()("SchematicListContainer AnimFadeIn", {
                    SchematicListContainerDisabled: "Enter" !== mK
                  }),
                  children: (0, EO.jsx)(oO.c, {
                    loading: null === nO,
                    schematics: null !== nO && void 0 !== nO ? nO : [],
                    onSchematicPicked: function(OO) {
                      const KO = qK.mapOptions.schematicIdList;
                      if (KO.includes(OO.schematicId)) OK({
                        schematicIdList: KO.filter((KO => KO !== OO.schematicId))
                      });
                      else {
                        if (cK && qK.mapOptions.schematicIdList.length >= cK) return;
                        OK({
                          schematicIdList: [...qK.mapOptions.schematicIdList, OO.schematicId]
                        })
                      }
                    },
                    selectedSchematicIdList: qK.mapOptions.schematicIdList,
                    disableAutoExport: !0
                  })
                })]
              })
            }), BO && (0, EO.jsxs)("div", {
              className: "BloxdForm",
              children: [(0, EO.jsx)("div", {
                className: "SectionTitle",
                children: rK("customLobby:listedOptions")
              }), (0, EO.jsxs)("div", {
                className: "SectionBody",
                children: [(0, EO.jsx)(fO.e, {
                  label: "general:description",
                  className: "CustomLobbyDescription",
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)(eO.e, {
                    onValueChange: (OO, KO) => {
                      kK("description", OO)
                    },
                    maxLength: 100,
                    defaultValue: qK.listedOptions.description
                  })
                }), (0, EO.jsx)(fO.e, {
                  label: "general:color",
                  circleInfoText: "customLobby:lobbyColorDescription",
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)("div", {
                    className: "OtherInput",
                    children: (0, EO.jsx)("input", {
                      type: "color",
                      value: qK.listedOptions.color,
                      onChange: OO => {
                        kK("color", OO.target.value)
                      }
                    })
                  })
                }), (0, EO.jsx)(fO.e, {
                  label: "general:emojis",
                  circleInfoText: "customLobby:lobbyEmojisDescription",
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)(eO.e, {
                    onValueChange: (OO, KO) => {
                      kK("emojis", OO)
                    },
                    maxLength: 6,
                    defaultValue: qK.listedOptions.emojis
                  })
                })]
              })]
            }), BO && JO && (0, EO.jsxs)("div", {
              className: "BloxdForm",
              children: [(0, EO.jsx)("div", {
                className: "SectionTitle",
                children: rK("customLobby:advancedOptions")
              }), (0, EO.jsxs)("div", {
                className: "SectionBody",
                children: [(0, EO.jsx)(fO.e, {
                  label: "classic:worldGenSeed",
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)(eO.e, {
                    onValueChange: (OO, KO) => {
                      UO("worldGenSeed", OO)
                    },
                    maxLength: NO.K
                  })
                }), (0, EO.jsx)(fO.e, {
                  label: "classic:disableProtectors",
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)(fO.b, {
                    checked: qK.worldOptions.disableProtectors,
                    setChecked: OO => {
                      UO("disableProtectors", OO)
                    }
                  })
                }), (0, EO.jsx)(fO.e, {
                  label: "classic:disableTribeCreation",
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)(fO.b, {
                    checked: qK.worldOptions.disableTribeCreation,
                    setChecked: OO => {
                      UO("disableTribeCreation", OO)
                    }
                  })
                }), (0, EO.jsx)(fO.e, {
                  label: "classic:voidDeathHeight",
                  circleInfoText: "classic:voidDeathHeightDescription",
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)("input", {
                    type: "number",
                    max: TO.F,
                    value: null !== (lO = qK.worldOptions.voidDeathHeight) && void 0 !== lO ? lO : "",
                    onChange: OO => {
                      const KO = parseInt(OO.target.value);
                      UO("voidDeathHeight", isNaN(KO) ? null : KO)
                    }
                  })
                }), (0, EO.jsx)(fO.e, {
                  label: "classic:disableLobbySpawn",
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)(fO.b, {
                    checked: qK.worldOptions.disableLobbySpawn,
                    setChecked: OO => {
                      UO("disableLobbySpawn", OO)
                    }
                  })
                }), (0, EO.jsx)(fO.e, {
                  label: "classic:worldBorder",
                  circleInfoText: "classic:worldBorderDescription",
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)("input", {
                    type: "number",
                    min: TO.K,
                    max: TO.G,
                    value: null !== (jK = qK.worldOptions.worldBorder) && void 0 !== jK ? jK : "",
                    onChange: OO => {
                      const KO = parseInt(OO.target.value);
                      UO("worldBorder", isNaN(KO) ? null : KO)
                    }
                  })
                }), (0, EO.jsx)(fO.e, {
                  label: "classic:disableMobs",
                  disabled: "Enter" !== mK,
                  children: (0, EO.jsx)(fO.b, {
                    checked: qK.worldOptions.disableMobs,
                    setChecked: OO => {
                      UO("disableMobs", OO)
                    }
                  })
                })]
              })]
            }), JO && (0, EO.jsx)(IO.b, {
              callbacks: KK,
              disabled: "Enter" !== mK,
              advancedMode: BO
            })]
          })
        }), (0, EO.jsxs)("div", {
          className: "CreateCustomLobbyFooter",
          children: [(0, EO.jsx)(aK.m, {
            className: "CreateCustomLobbyButton",
            padDefaultFocus: !0,
            loading: "Enter" !== mK,
            onClick: () => {
              !async function() {
                if ("Enter" === mK) {
                  sO("Loading"), RO("");
                  try {
                    await MO.e.createCustomLobby(qK), sO("Success")
                  } catch (OO) {
                    RO(OO.message), console.error(OO.message), sO("Enter")
                  }
                }
              }()
            },
            children: rK("general:create")
          }), JO && (0, EO.jsx)("div", {
            className: "CreateCustomLobbyAdvancedToggle",
            "data-pad-ignore": pK || void 0,
            children: (0, EO.jsx)(fO.e, {
              label: "customLobby:showAdvancedOptions",
              disabled: pK,
              onLabelClick: () => {
                ZO(!BO)
              },
              children: (0, EO.jsx)(fO.b, {
                checked: BO,
                setChecked: ZO
              })
            })
          }), HO && (0, EO.jsx)("div", {
            className: "CreateCustomLobbyError AnimFadeInScaleUp",
            children: HO
          })]
        })]
      })
    }
  },
  34948: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(63),
      lO = pO(3755),
      vK = pO(976);

    function CO(OO) {
      let {
        locked: KO,
        children: pO
      } = OO;
      const XO = (0, eO.useRef)(null),
        CO = (0, lO.d)(XO, "y");
      return (0, vK.jsx)("div", {
        ref: XO,
        className: bK()("CreateCustomLobbyBody", {
          CreateCustomLobbyBodyMoreAbove: CO.before,
          CreateCustomLobbyBodyMoreBelow: CO.after
        }),
        "data-pad-ignore": KO || void 0,
        children: pO
      })
    }
  },
  34934: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => DO,
      d: () => aK
    });
    var XO = pO(63),
      bK = pO(1187),
      eO = pO(1051),
      lO = pO(1180),
      vK = pO(2730),
      CO = pO(4054),
      hO = pO(976);

    function DO(OO) {
      let {
        loading: KO,
        schematics: pO,
        onSchematicPicked: XO,
        selectedSchematicIdList: bK = [],
        disableAutoExport: CO
      } = OO;
      const {
        t: DO
      } = (0, eO.D)();
      return (0, hO.jsxs)("div", {
        className: "SchematicList",
        children: [KO && (0, hO.jsx)(lO.e, {}), !KO && 0 === pO.length && (0, hO.jsx)("div", {
          className: "NoSchematicsText",
          children: DO("worldBuilder:noSavedSchematic")
        }), !KO && pO.map((OO => (0, hO.jsx)(vK.f, {
          source: {
            type: "schematic",
            schematic: OO
          },
          gameWidth: "25%",
          useLongRatio: !0,
          onClick: () => {
            XO(OO)
          },
          isSelected: bK.includes(OO.schematicId),
          hideCcu: !0,
          hideFavourites: !0,
          showPublishedChip: !0,
          hideUnpublishedChip: !0,
          disabled: OO.isAutoExported && CO,
          disabledReason: "worldBuilder:autoExportDisabled"
        }, OO.schematicId)))]
      })
    }

    function MO(OO) {
      let {
        ownedSchematics: KO,
        currentWorldSchematicId: pO,
        onClose: bK
      } = OO;
      const {
        t: lO
      } = (0, eO.D)(), [vK, MO] = (0, XO.useState)(null);
      return (0, hO.jsxs)("div", {
        className: "SchematicListWindow",
        children: [null === vK && (0, hO.jsxs)(hO.Fragment, {
          children: [(0, hO.jsx)("h1", {
            className: "SchematicPopupTitle",
            children: lO("worldBuilder:schematicList")
          }), (0, hO.jsx)("h2", {
            className: "SchematicPopupSubtitle",
            children: lO("worldBuilder:clickSchematicForOptions")
          }), (0, hO.jsx)("div", {
            className: "SchematicPopupSchematicListContainer",
            children: (0, hO.jsx)(DO, {
              loading: !1,
              schematics: KO,
              onSchematicPicked: OO => {
                MO(OO)
              },
              disableAutoExport: !1
            })
          })]
        }), null !== vK && (0, hO.jsx)(CO.f, {
          schematic: vK,
          inSourceWorld: vK.schematicId === pO,
          onSchematicUpdate: OO => {
            MO(OO)
          },
          onClose: () => {
            MO(null), bK()
          }
        })]
      })
    }

    function aK(OO) {
      let {
        ownedSchematics: KO,
        currentWorldSchematicId: pO,
        onClose: XO
      } = OO;
      bK.NotificationProvider.showCustomPopup({
        body: OO => (0, hO.jsx)(MO, {
          ownedSchematics: KO,
          currentWorldSchematicId: pO,
          onClose: OO
        }),
        middleScreenPopupClassName: "SchematicPopup",
        onClose: XO,
        unlockPointerKey: "schematicListPopup"
      })
    }
  },
  34940: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO,
      c: () => DO
    });
    pO(63);
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(3812),
      lO = pO(243),
      vK = pO(1051),
      CO = pO(976);

    function hO(OO) {
      let {
        value: KO,
        onChange: pO,
        showAll: XO,
        disabled: hO = !1
      } = OO;
      const {
        t: DO
      } = (0, vK.D)();
      return (0, CO.jsxs)("div", {
        className: bK()("BloxdForm GamemodeForm", {
          BasicOptions: !XO
        }),
        children: [(0, CO.jsx)("div", {
          className: "SectionTitle",
          children: DO("classic:defaultGamemode")
        }), (0, CO.jsx)("div", {
          className: "SectionBody",
          children: eO.B.map((OO => XO || (0, eO.t)(OO) ? (0, CO.jsx)("button", {
            type: "button",
            className: bK()("WorldGamemode", {
              Selected: KO === OO
            }),
            disabled: hO,
            onClick: () => {
              pO(OO)
            },
            style: {
              "--background-image": `url(${lO.s[OO]})`
            },
            children: lO.r[OO]
          }, OO) : null))
        })]
      })
    }

    function DO(OO) {
      let {
        mapTypes: KO,
        value: pO,
        onChange: XO,
        showAll: hO,
        disabled: DO = !1,
        children: MO
      } = OO;
      const {
        t: aK
      } = (0, vK.D)();
      return (0, CO.jsxs)("div", {
        className: bK()("BloxdForm MapTypeForm", {
          BasicOptions: !hO
        }),
        children: [(0, CO.jsx)("div", {
          className: "SectionTitle",
          children: aK("customLobby:mapType")
        }), (0, CO.jsx)("div", {
          className: "SectionBody",
          children: KO.map((OO => hO || (0, eO.w)(OO) ? (0, CO.jsx)("button", {
            type: "button",
            className: bK()("MapType", {
              Selected: pO === OO
            }),
            disabled: DO,
            onClick: () => {
              XO(OO)
            },
            style: {
              "--background-image": `url(${lO.n[OO]})`
            },
            children: lO.j[OO]
          }, OO) : null))
        }), MO]
      })
    }
  },
  34932: () => {}
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);