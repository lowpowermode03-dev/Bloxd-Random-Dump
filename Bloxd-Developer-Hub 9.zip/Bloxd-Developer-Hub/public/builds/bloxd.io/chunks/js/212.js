export const id = 212;
export const ids = [212, 217, 221];
export const modules = {
  38330: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO,
      c: () => vK
    });
    var XO = pO(37061),
      bK = pO(38077),
      eO = pO(38294),
      lO = {};
    class vK {
      constructor(OO) {
        this.attachedToElement = !1, this.attached = {}, this.camera = OO, this.checkInputs = () => {}
      }
      add(OO) {
        const KO = OO.getSimpleName();
        this.attached[KO] ? XO.b.Warn("camera input of type " + KO + " already exists on camera") : (this.attached[KO] = OO, OO.camera = this.camera, OO.checkInputs && (this.checkInputs = this._addCheckInputs(OO.checkInputs.bind(OO))), this.attachedToElement && OO.attachControl(this.noPreventDefault))
      }
      remove(OO) {
        for (const KO in this.attached) {
          const pO = this.attached[KO];
          if (pO === OO) return pO.detachControl(), pO.camera = null, delete this.attached[KO], void this.rebuildInputCheck()
        }
      }
      removeByType(OO) {
        for (const KO in this.attached) {
          const pO = this.attached[KO];
          pO.getClassName() === OO && (pO.detachControl(), pO.camera = null, delete this.attached[KO], this.rebuildInputCheck())
        }
      }
      _addCheckInputs(OO) {
        const KO = this.checkInputs;
        return () => {
          KO(), OO()
        }
      }
      attachInput(OO) {
        this.attachedToElement && OO.attachControl(this.noPreventDefault)
      }
      attachElement() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        if (!this.attachedToElement) {
          OO = !eO.c.ForceAttachControlToAlwaysPreventDefault && OO, this.attachedToElement = !0, this.noPreventDefault = OO;
          for (const KO in this.attached) this.attached[KO].attachControl(OO)
        }
      }
      detachElement() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        for (const KO in this.attached) this.attached[KO].detachControl(), OO && (this.attached[KO].camera = null);
        this.attachedToElement = !1
      }
      rebuildInputCheck() {
        this.checkInputs = () => {};
        for (const OO in this.attached) {
          const KO = this.attached[OO];
          KO.checkInputs && (this.checkInputs = this._addCheckInputs(KO.checkInputs.bind(KO)))
        }
      }
      clear() {
        this.attachedToElement && this.detachElement(!0), this.attached = {}, this.attachedToElement = !1, this.checkInputs = () => {}
      }
      serialize(OO) {
        const KO = {};
        for (const pO in this.attached) {
          const OO = this.attached[pO],
            XO = bK.c.Serialize(OO);
          KO[OO.getClassName()] = XO
        }
        OO.inputsmgr = KO
      }
      parse(OO) {
        const KO = OO.inputsmgr;
        if (KO) {
          this.clear();
          for (const OO in KO) {
            const pO = lO[OO];
            if (pO) {
              const XO = KO[OO],
                eO = bK.c.Parse((() => new pO), XO, null);
              this.add(eO)
            }
          }
        } else
          for (const pO in this.attached) {
            const KO = lO[this.attached[pO].getClassName()];
            if (KO) {
              const XO = bK.c.Parse((() => new KO), OO, null);
              this.remove(this.attached[pO]), this.add(XO)
            }
          }
      }
    }
  },
  38338: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO.d
    });
    var XO = pO(38343);
    (0, XO.h)()
  },
  38343: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      h: () => aK
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35632),
      lO = pO(35688),
      vK = pO(38347),
      CO = pO(38301),
      hO = pO(35676);
    let DO = (() => {
        var OO;
        let KO, pO, CO = vK.b,
          hO = [],
          DO = [],
          MO = [],
          aK = [];
        return OO = class extends CO {
          constructor(OO, KO, pO, bK) {
            super(OO, pO, bK), this.groundColor = (0, XO.i)(this, hO, new lO.e(0, 0, 0)), this.direction = ((0, XO.i)(this, DO), (0, XO.i)(this, MO, void 0)), (0, XO.i)(this, aK), this.direction = KO || eO.o.Up()
          }
          _buildUniformLayout() {
            this._uniformBuffer.addUniform("vLightData", 4), this._uniformBuffer.addUniform("vLightDiffuse", 4), this._uniformBuffer.addUniform("vLightSpecular", 4), this._uniformBuffer.addUniform("vLightGround", 3), this._uniformBuffer.addUniform("shadowsInfo", 3), this._uniformBuffer.addUniform("depthValues", 2), this._uniformBuffer.create()
          }
          getClassName() {
            return "HemisphericLight"
          }
          setDirectionToTarget(OO) {
            return this.direction = eO.o.Normalize(OO.subtract(eO.o.Zero())), this.direction
          }
          getShadowGenerator() {
            return null
          }
          transferToEffect(OO, KO) {
            const pO = eO.o.Normalize(this.direction);
            return this._uniformBuffer.updateFloat4("vLightData", pO.x, pO.y, pO.z, 0, KO), this._uniformBuffer.updateColor3("vLightGround", this.groundColor.scale(this.intensity), KO), this
          }
          transferToNodeMaterialEffect(OO, KO) {
            const pO = eO.o.Normalize(this.direction);
            return OO.setFloat3(KO, pO.x, pO.y, pO.z), this
          }
          computeWorldMatrix() {
            return this._worldMatrix || (this._worldMatrix = eO.c.Identity()), this._worldMatrix
          }
          getTypeID() {
            return vK.b.LIGHTTYPEID_HEMISPHERICLIGHT
          }
          prepareLightSpecificDefines(OO, KO) {
            OO["HEMILIGHT" + KO] = !0
          }
        }, (() => {
          const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(CO[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.r)()], pO = [(0, bK.L)()], (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "groundColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "groundColor" in OO,
              get: OO => OO.groundColor,
              set: (OO, KO) => {
                OO.groundColor = KO
              }
            },
            metadata: eO
          }, hO, DO), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "direction",
            static: !1,
            private: !1,
            access: {
              has: OO => "direction" in OO,
              get: OO => OO.direction,
              set: (OO, KO) => {
                OO.direction = KO
              }
            },
            metadata: eO
          }, MO, aK), eO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: eO
          })
        })(), OO
      })(),
      MO = !1;

    function aK() {
      MO || (MO = !0, CO.c.AddNodeConstructor("Light_Type_3", ((OO, KO) => () => new DO(OO, eO.o.Zero(), KO))), (0, hO.h)("BABYLON.HemisphericLight", DO))
    }
  },
  35680: (OO, KO, pO) => {
    pO.d(KO, {
      Color3: () => XO.e,
      c: () => XO.g
    });
    var XO = pO(35688);
    (0, XO.h)()
  },
  36142: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(36146);
    class bK {
      static GetPlanes(OO) {
        const KO = [];
        for (let pO = 0; pO < 6; pO++) KO.push(new XO.d(0, 0, 0, 0));
        return bK.GetPlanesToRef(OO, KO), KO
      }
      static GetNearPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[2], KO.normal.y = pO[7] + pO[6], KO.normal.z = pO[11] + pO[10], KO.d = pO[15] + pO[14], KO.normalize()
      }
      static GetFarPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[2], KO.normal.y = pO[7] - pO[6], KO.normal.z = pO[11] - pO[10], KO.d = pO[15] - pO[14], KO.normalize()
      }
      static GetLeftPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[0], KO.normal.y = pO[7] + pO[4], KO.normal.z = pO[11] + pO[8], KO.d = pO[15] + pO[12], KO.normalize()
      }
      static GetRightPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[0], KO.normal.y = pO[7] - pO[4], KO.normal.z = pO[11] - pO[8], KO.d = pO[15] - pO[12], KO.normalize()
      }
      static GetTopPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[1], KO.normal.y = pO[7] - pO[5], KO.normal.z = pO[11] - pO[9], KO.d = pO[15] - pO[13], KO.normalize()
      }
      static GetBottomPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[1], KO.normal.y = pO[7] + pO[5], KO.normal.z = pO[11] + pO[9], KO.d = pO[15] + pO[13], KO.normalize()
      }
      static GetPlanesToRef(OO, KO) {
        bK.GetNearPlaneToRef(OO, KO[0]), bK.GetFarPlaneToRef(OO, KO[1]), bK.GetLeftPlaneToRef(OO, KO[2]), bK.GetRightPlaneToRef(OO, KO[3]), bK.GetTopPlaneToRef(OO, KO[4]), bK.GetBottomPlaneToRef(OO, KO[5])
      }
      static IsPointInFrustum(OO, KO) {
        for (let pO = 0; pO < 6; pO++)
          if (KO[pO].dotCoordinate(OO) < 0) return !1;
        return !0
      }
    }
  },
  36146: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK
    });
    var XO = pO(35632);
    class bK {
      constructor(OO, KO, pO, bK) {
        this.normal = new XO.o(OO, KO, pO), this.d = bK
      }
      WhO() {
        return [this.normal.x, this.normal.y, this.normal.z, this.d]
      }
      clone() {
        return new bK(this.normal.x, this.normal.y, this.normal.z, this.d)
      }
      getClassName() {
        return "Plane"
      }
      getHashCode() {
        let OO = this.normal.getHashCode();
        return OO = 397 * OO ^ this.d, OO
      }
      normalize() {
        const OO = Math.sqrt(this.normal.x * this.normal.x + this.normal.y * this.normal.y + this.normal.z * this.normal.z);
        let KO = 0;
        return 0 !== OO && (KO = 1 / OO), this.normal.x *= KO, this.normal.y *= KO, this.normal.z *= KO, this.d *= KO, this
      }
      transform(OO) {
        const KO = bK._TmpMatrix;
        OO.invertToRef(KO);
        const pO = KO.m,
          XO = this.normal.x,
          eO = this.normal.y,
          lO = this.normal.z,
          vK = this.d,
          CO = XO * pO[0] + eO * pO[1] + lO * pO[2] + vK * pO[3],
          hO = XO * pO[4] + eO * pO[5] + lO * pO[6] + vK * pO[7],
          DO = XO * pO[8] + eO * pO[9] + lO * pO[10] + vK * pO[11],
          MO = XO * pO[12] + eO * pO[13] + lO * pO[14] + vK * pO[15];
        return new bK(CO, hO, DO, MO)
      }
      dotCoordinate(OO) {
        return this.normal.x * OO.x + this.normal.y * OO.y + this.normal.z * OO.z + this.d
      }
      copyFromPoints(OO, KO, pO) {
        const XO = KO.x - OO.x,
          bK = KO.y - OO.y,
          eO = KO.z - OO.z,
          lO = pO.x - OO.x,
          vK = pO.y - OO.y,
          CO = pO.z - OO.z,
          hO = bK * CO - eO * vK,
          DO = eO * lO - XO * CO,
          MO = XO * vK - bK * lO,
          aK = Math.sqrt(hO * hO + DO * DO + MO * MO);
        let oO;
        return oO = 0 !== aK ? 1 / aK : 0, this.normal.x = hO * oO, this.normal.y = DO * oO, this.normal.z = MO * oO, this.d = -(this.normal.x * OO.x + this.normal.y * OO.y + this.normal.z * OO.z), this
      }
      isFrontFacingTo(OO, KO) {
        return XO.o.Dot(this.normal, OO) <= KO
      }
      signedDistanceTo(OO) {
        return XO.o.Dot(OO, this.normal) + this.d
      }
      static FromArray(OO) {
        return new bK(OO[0], OO[1], OO[2], OO[3])
      }
      static FromPoints(OO, KO, pO) {
        const XO = new bK(0, 0, 0, 0);
        return XO.copyFromPoints(OO, KO, pO), XO
      }
      static FromPositionAndNormal(OO, KO) {
        const pO = new bK(0, 0, 0, 0);
        return this.FromPositionAndNormalToRef(OO, KO, pO)
      }
      static FromPositionAndNormalToRef(OO, KO, pO) {
        return pO.normal.NhO(KO), pO.normal.normalize(), pO.d = -OO.dot(pO.normal), pO
      }
      static SignedDistanceToPlaneFromPositionAndNormal(OO, KO, pO) {
        const bK = -(KO.x * OO.x + KO.y * OO.y + KO.z * OO.z);
        return XO.o.Dot(pO, KO) + bK
      }
    }
    bK._TmpMatrix = XO.c.Identity()
  },
  35624: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      Matrix: () => XO.c,
      Quaternion: () => XO.g,
      RegisterMathVector: () => XO.i,
      TmpVectors: () => XO.j,
      Vector2: () => XO.m,
      WX: () => XO.o,
      Vector4: () => XO.s
    });
    var XO = pO(35632);
    (0, XO.i)()
  },
  36513: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    class XO {
      constructor(OO, KO, pO, XO) {
        this.x = OO, this.y = KO, this.width = pO, this.height = XO
      }
      toGlobal(OO, KO) {
        return new XO(this.x * OO, this.y * KO, this.width * OO, this.height * KO)
      }
      toGlobalToRef(OO, KO, pO) {
        return pO.x = this.x * OO, pO.y = this.y * KO, pO.width = this.width * OO, pO.height = this.height * KO, this
      }
      clone() {
        return new XO(this.x, this.y, this.width, this.height)
      }
    }
  },
  38499: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => hO
    });
    var XO = pO(35632),
      bK = pO(35688),
      eO = pO(38502),
      lO = pO(38511),
      vK = pO(38530);

    function CO(OO) {
      let KO = [0, 1, 2, 0, 2, 3, 4, 5, 6, 4, 6, 7, 8, 9, 10, 8, 10, 11, 12, 13, 14, 12, 14, 15, 16, 17, 18, 16, 18, 19, 20, 21, 22, 20, 22, 23];
      const pO = [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0],
        eO = [],
        CO = OO.width || OO.size || 1,
        hO = OO.height || OO.size || 1,
        DO = OO.depth || OO.size || 1,
        MO = OO.wrap || !1;
      let aK = void 0 === OO.topBaseAt ? 1 : OO.topBaseAt,
        oO = void 0 === OO.bottomBaseAt ? 0 : OO.bottomBaseAt;
      aK = (aK + 4) % 4, oO = (oO + 4) % 4;
      let FO = [2, 0, 3, 1][aK],
        VO = [2, 0, 1, 3][oO],
        LO = [1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1];
      if (MO) {
        KO = [2, 3, 0, 2, 0, 1, 4, 5, 6, 4, 6, 7, 9, 10, 11, 9, 11, 8, 12, 14, 15, 12, 13, 14], LO = [-1, 1, 1, 1, 1, 1, 1, -1, 1, -1, -1, 1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, 1, 1, 1, -1, 1, -1, -1, 1, -1, 1, -1, 1, -1, -1, 1, 1, -1, -1, 1, -1, -1, -1];
        let OO = [
            [1, 1, 1],
            [-1, 1, 1],
            [-1, 1, -1],
            [1, 1, -1]
          ],
          pO = [
            [-1, -1, 1],
            [1, -1, 1],
            [1, -1, -1],
            [-1, -1, -1]
          ];
        const XO = [17, 18, 19, 16],
          bK = [22, 23, 20, 21];
        for (; FO > 0;) OO.unshift(OO.pop()), XO.unshift(XO.pop()), FO--;
        for (; VO > 0;) pO.unshift(pO.pop()), bK.unshift(bK.pop()), VO--;
        OO = OO.flat(), pO = pO.flat(), LO = LO.concat(OO).concat(pO), KO.push(XO[0], XO[2], XO[3], XO[0], XO[1], XO[2]), KO.push(bK[0], bK[2], bK[3], bK[0], bK[1], bK[2])
      }
      const QO = [CO / 2, hO / 2, DO / 2],
        zK = LO.reduce(((OO, KO, pO) => OO.concat(KO * QO[pO % 3])), []),
        AO = 0 === OO.sideOrientation ? 0 : OO.sideOrientation || lO.e.DEFAULTSIDE,
        fO = OO.faceUV || new Array(6),
        dO = OO.faceColors,
        TO = [];
      for (let lO = 0; lO < 6; lO++) void 0 === fO[lO] && (fO[lO] = new XO.s(0, 0, 1, 1)), dO && void 0 === dO[lO] && (dO[lO] = new bK.g(1, 1, 1, 1));
      for (let XO = 0; XO < 6; XO++)
        if (eO.push(fO[XO].z, vK.b ? 1 - fO[XO].w : fO[XO].w), eO.push(fO[XO].x, vK.b ? 1 - fO[XO].w : fO[XO].w), eO.push(fO[XO].x, vK.b ? 1 - fO[XO].y : fO[XO].y), eO.push(fO[XO].z, vK.b ? 1 - fO[XO].y : fO[XO].y), dO)
          for (let OO = 0; OO < 4; OO++) TO.push(dO[XO].r, dO[XO].g, dO[XO].b, dO[XO].a);
      lO.e._ComputeSides(AO, zK, KO, pO, eO, OO.frontUVs, OO.backUVs);
      const NO = new lO.e;
      if (NO.indices = KO, NO.positions = zK, NO.normals = pO, NO.uvs = eO, dO) {
        const OO = AO === lO.e.DOUBLESIDE ? TO.concat(TO) : TO;
        NO.colors = OO
      }
      return NO
    }

    function hO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
      const XO = new eO.c(OO, pO);
      KO.sideOrientation = eO.c._GetDefaultSideOrientation(KO.sideOrientation), XO._originalBuilderSideOrientation = KO.sideOrientation;
      return CO(KO).applyToMesh(XO, KO.updatable), XO
    }
    let DO = !1;
    DO || (DO = !0, lO.e.CreateBox = CO, eO.c.CreateBox = function(OO, KO) {
      return hO(OO, {
        size: KO,
        sideOrientation: arguments.length > 4 ? arguments[4] : void 0,
        updatable: arguments.length > 3 ? arguments[3] : void 0
      }, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null)
    })
  },
  38557: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => MO
    });
    var XO = pO(35632),
      bK = pO(38502),
      eO = pO(38511),
      lO = pO(38564),
      vK = pO(38216),
      CO = pO(37061);

    function hO(OO) {
      const KO = [],
        pO = [],
        XO = OO.lines,
        bK = OO.colors,
        lO = [];
      let vK = 0;
      for (let eO = 0; eO < XO.length; eO++) {
        const OO = XO[eO];
        for (let XO = 0; XO < OO.length; XO++) {
          const {
            x: CO,
            y: hO,
            z: DO
          } = OO[XO];
          if (pO.push(CO, hO, DO), bK) {
            const OO = bK[eO],
              {
                r: KO,
                g: pO,
                b: vK,
                a: CO
              } = OO[XO];
            lO.push(KO, pO, vK, CO)
          }
          XO > 0 && (KO.push(vK - 1), KO.push(vK)), vK++
        }
      }
      const CO = new eO.e;
      return CO.indices = KO, CO.positions = pO, bK && (CO.colors = lO), CO
    }

    function DO(OO) {
      const KO = OO.dashSize || 3,
        pO = OO.gapSize || 1,
        bK = OO.dashNb || 200,
        lO = OO.points,
        vK = [],
        CO = [],
        hO = XO.o.Zero();
      let DO, MO, aK, oO = 0,
        FO = 0;
      for (aK = 0; aK < lO.length - 1; aK++) lO[aK + 1].subtractToRef(lO[aK], hO), oO += hO.length();
      const VO = oO / bK,
        LO = KO * VO / (KO + pO);
      for (aK = 0; aK < lO.length - 1; aK++) {
        lO[aK + 1].subtractToRef(lO[aK], hO), DO = Math.floor(hO.length() / VO), hO.normalize();
        for (let OO = 0; OO < DO; OO++) MO = VO * OO, vK.push(lO[aK].x + MO * hO.x, lO[aK].y + MO * hO.y, lO[aK].z + MO * hO.z), vK.push(lO[aK].x + (MO + LO) * hO.x, lO[aK].y + (MO + LO) * hO.y, lO[aK].z + (MO + LO) * hO.z), CO.push(FO, FO + 1), FO += 2
      }
      const QO = new eO.e;
      return QO.positions = vK, QO.indices = CO, QO
    }

    function MO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
      const XO = KO.instance,
        bK = KO.lines,
        eO = KO.colors;
      if (XO) {
        const OO = XO.getVerticesData(vK.j.PositionKind);
        let KO, pO;
        eO && (KO = XO.getVerticesData(vK.j.ColorKind));
        let lO = 0,
          CO = 0;
        for (let XO = 0; XO < bK.length; XO++) {
          const vK = bK[XO];
          for (let bK = 0; bK < vK.length; bK++) OO[lO] = vK[bK].x, OO[lO + 1] = vK[bK].y, OO[lO + 2] = vK[bK].z, eO && KO && (pO = eO[XO], KO[CO] = pO[bK].r, KO[CO + 1] = pO[bK].g, KO[CO + 2] = pO[bK].b, KO[CO + 3] = pO[bK].a, CO += 4), lO += 3
        }
        return XO.updateVerticesData(vK.j.PositionKind, OO, !1, !1), eO && KO && XO.updateVerticesData(vK.j.ColorKind, KO, !1, !1), XO.refreshBoundingInfo(), XO
      }
      const CO = !!eO,
        DO = new lO.d(OO, pO, null, void 0, void 0, CO, KO.useVertexAlpha, KO.material);
      return hO(KO).applyToMesh(DO, KO.updatable), DO
    }

    function aK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
      const XO = KO.colors ? [KO.colors] : null;
      return MO(OO, {
        lines: [KO.points],
        updatable: KO.updatable,
        instance: KO.instance,
        colors: XO,
        useVertexAlpha: KO.useVertexAlpha,
        material: KO.material
      }, pO)
    }

    function oO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
      const eO = KO.points,
        vK = KO.instance,
        hO = KO.gapSize || 1,
        MO = KO.dashSize || 3;
      if (vK) {
        const OO = OO => {
          const KO = XO.o.Zero(),
            pO = OO.length / 6;
          let bK, lO, CO, hO, DO = 0,
            MO = 0;
          for (CO = 0; CO < eO.length - 1; CO++) eO[CO + 1].subtractToRef(eO[CO], KO), DO += KO.length();
          const aK = DO / pO,
            oO = vK._creationDataStorage.dashSize,
            FO = oO * aK / (oO + vK._creationDataStorage.gapSize);
          for (CO = 0; CO < eO.length - 1; CO++)
            for (eO[CO + 1].subtractToRef(eO[CO], KO), bK = Math.floor(KO.length() / aK), KO.normalize(), hO = 0; hO < bK && MO < OO.length;) lO = aK * hO, OO[MO] = eO[CO].x + lO * KO.x, OO[MO + 1] = eO[CO].y + lO * KO.y, OO[MO + 2] = eO[CO].z + lO * KO.z, OO[MO + 3] = eO[CO].x + (lO + FO) * KO.x, OO[MO + 4] = eO[CO].y + (lO + FO) * KO.y, OO[MO + 5] = eO[CO].z + (lO + FO) * KO.z, MO += 6, hO++;
          for (; MO < OO.length;) OO[MO] = eO[CO].x, OO[MO + 1] = eO[CO].y, OO[MO + 2] = eO[CO].z, MO += 3
        };
        return (KO.dashNb || KO.dashSize || KO.gapSize || KO.useVertexAlpha || KO.material) && CO.b.Warn("You have used an option other than points with the instance option. Please be aware that these other options will be ignored."), vK.updateMeshPositions(OO, !1), vK
      }
      const aK = new lO.d(OO, pO, null, void 0, void 0, void 0, KO.useVertexAlpha, KO.material);
      return DO(KO).applyToMesh(aK, KO.updatable), aK._creationDataStorage = new bK.g, aK._creationDataStorage.dashSize = MO, aK._creationDataStorage.gapSize = hO, aK
    }
    let FO = !1;
    FO || (FO = !0, eO.e.CreateLineSystem = hO, eO.e.CreateDashedLines = DO, bK.c.CreateLines = function(OO, KO) {
      return aK(OO, {
        points: KO,
        updatable: arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
        instance: arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null
      }, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null)
    }, bK.c.CreateDashedLines = function(OO, KO, pO, XO, bK) {
      return oO(OO, {
        points: KO,
        dashSize: pO,
        gapSize: XO,
        dashNb: bK,
        updatable: arguments.length > 6 ? arguments[6] : void 0,
        instance: arguments.length > 7 ? arguments[7] : void 0
      }, arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null)
    })
  },
  38564: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => aK,
      g: () => VO
    });
    var XO, bK, eO = pO(35688),
      lO = pO(38216),
      vK = pO(38502),
      CO = pO(38568),
      hO = pO(38382),
      DO = pO(38572),
      MO = pO(37938);
    class aK extends vK.c {
      _isShaderMaterial(OO) {
        return !!OO && "ShaderMaterial" === OO.getClassName()
      }
      constructor(OO) {
        let KO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
          XO = arguments.length > 5 ? arguments[5] : void 0,
          bK = arguments.length > 6 ? arguments[6] : void 0,
          vK = arguments.length > 7 ? arguments[7] : void 0;
        super(OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null, KO, arguments.length > 4 ? arguments[4] : void 0), this.useVertexColor = XO, this.useVertexAlpha = bK, this.color = new eO.e(1, 1, 1), this.alpha = 1, this._shaderLanguage = 0, this._ownsMaterial = !1, KO && (this.color = KO.color.clone(), this.alpha = KO.alpha, this.useVertexColor = KO.useVertexColor, this.useVertexAlpha = KO.useVertexAlpha), this.intersectionThreshold = .1;
        const CO = {
          attributes: [lO.j.PositionKind],
          uniforms: ["world", "viewProjection"],
          needAlphaBlending: !0,
          defines: [],
          useClipPlane: null,
          shaderLanguage: 0
        };
        if (this.useVertexAlpha ? CO.defines.push("#define VERTEXALPHA") : CO.needAlphaBlending = !1, this.useVertexColor ? (CO.defines.push("#define VERTEXCOLOR"), CO.attributes.push(lO.j.ColorKind)) : (CO.uniforms.push("color"), this._color4 = new eO.g), vK) this.material = vK;
        else {
          this.JKO().qb().isWebGPU && !aK.ForceGLSL && (this._shaderLanguage = 1), CO.shaderLanguage = this._shaderLanguage, CO.extraInitializationsAsync = async () => {
            1 === this._shaderLanguage ? await Promise.all([pO.e(324).then((() => pO(40588))), pO.e(330).then((() => pO(40592)))]) : await Promise.all([pO.e(306).then((() => pO(40598))), pO.e(312).then((() => pO(40604)))])
          };
          const OO = new DO.m("colorShader", this.JKO(), "color", CO, !1);
          OO.doNotSerialize = !0, this._ownsMaterial = !0, this._setInternalMaterial(OO)
        }
      }
      getClassName() {
        return "LinesMesh"
      }
      get material() {
        return this._internalAbstractMeshDataInfo._material
      }
      set material(OO) {
        const KO = this.material;
        if (KO === OO) return;
        const pO = KO && this._ownsMaterial;
        this._ownsMaterial = !1, this._setInternalMaterial(OO), pO && KO?.dispose()
      }
      _setInternalMaterial(OO) {
        this._setMaterial(OO), this.material && (this.material.fillMode = hO.b.LineListDrawMode, this.material.disableLighting = !0)
      }
      get checkCollisions() {
        return !1
      }
      set checkCollisions(OO) {}
      _bind(OO, KO) {
        if (!this._geometry) return this;
        const pO = this.isUnIndexed ? null : this._geometry.getIndexBuffer();
        if (!this._userInstancedBuffersStorage || this.hasThinInstances ? this._geometry._bind(KO, pO) : this._geometry._bind(KO, pO, this._userInstancedBuffersStorage.vertexBuffers, this._userInstancedBuffersStorage.vertexArrayObjects), !this.useVertexColor && this._isShaderMaterial(this.material)) {
          const {
            r: OO,
            g: KO,
            b: pO
          } = this.color;
          this._color4.set(OO, KO, pO, this.alpha), this.material.setColor4("color", this._color4)
        }
        return this
      }
      _draw(OO, KO, pO) {
        if (!this._geometry || !this._geometry.getVertexBuffers() || !this._unIndexed && !this._geometry.getIndexBuffer()) return this;
        const XO = this.JKO().qb();
        return this._unIndexed ? XO.drawArraysType(hO.b.LineListDrawMode, OO.verticesStart, OO.verticesCount, pO) : XO.drawElementsType(hO.b.LineListDrawMode, OO.indexStart, OO.indexCount, pO), this
      }
      dispose(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        (arguments.length > 2 ? arguments[2] : void 0) || (this._ownsMaterial || KO) && this.material?.dispose(!1, !1, !0), super.dispose(OO)
      }
      clone(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        if (KO && void 0 === KO._addToSceneRootNodes) {
          const pO = KO;
          return pO.source = this, new aK(OO, this.JKO(), pO.parent, pO.source, pO.doNotCloneChildren)
        }
        return new aK(OO, this.JKO(), KO, this, pO)
      }
      createInstance(OO) {
        const KO = new oO(OO, this);
        if (this.lpO) {
          KO.lpO = {};
          for (const OO in this.lpO) KO.lpO[OO] = this.lpO[OO]
        }
        return KO
      }
      serialize(OO) {
        super.serialize(OO), OO.color = this.color.WhO(), OO.alpha = this.alpha
      }
      static Parse(OO, KO) {
        const pO = new aK(OO.name, KO);
        return pO.color = eO.e.FromArray(OO.color), pO.alpha = OO.alpha, pO
      }
    }
    aK.ForceGLSL = !1;
    class oO extends CO.d {
      constructor(OO, KO) {
        super(OO, KO), this.intersectionThreshold = KO.intersectionThreshold
      }
      getClassName() {
        return "InstancedLinesMesh"
      }
    }
    let FO = !1;

    function VO() {
      FO || (FO = !0, vK.c._LinesMeshParser = (OO, KO) => aK.Parse(OO, KO))
    }(XO = aK.prototype).enableEdgesRendering ?? (XO.enableEdgesRendering = (0, MO.h)("LinesMesh", "enableEdgesRendering")), (bK = oO.prototype).enableEdgesRendering ?? (bK.enableEdgesRendering = (0, MO.h)("InstancedLinesMesh", "enableEdgesRendering"))
  },
  37055: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(37061);
    const bK = (OO, KO, pO) => OO ? OO.getClassName && "Mesh" === OO.getClassName() ? null : !OO.getClassName || "SubMesh" !== OO.getClassName() && "PhysicsBody" !== OO.getClassName() ? OO.clone ? OO.clone() : Array.isArray(OO) ? OO.slice() : pO && "object" === typeof OO ? {
      ...OO
    } : null : OO.clone(KO) : null;
    class eO {
      static DeepCopy(OO, KO, pO, eO) {
        let lO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        const vK = function(OO) {
          const KO = [];
          do {
            const pO = Object.getOwnPropertyNames(OO);
            for (const OO of pO) - 1 === KO.indexOf(OO) && KO.push(OO)
          } while (OO = Object.getPrototypeOf(OO));
          return KO
        }(OO);
        for (const hO of vK) {
          if ("_" === hO[0] && (!eO || -1 === eO.indexOf(hO))) continue;
          if (hO.endsWith("Observable")) continue;
          if (pO && -1 !== pO.indexOf(hO)) continue;
          const vK = OO[hO],
            DO = typeof vK;
          if ("function" !== DO) try {
            if ("object" === DO)
              if (vK instanceof Uint8Array) KO[hO] = Uint8Array.from(vK);
              else if (vK instanceof Array) {
              if (KO[hO] = [], vK.length > 0)
                if ("object" == typeof vK[0])
                  for (let OO = 0; OO < vK.length; OO++) {
                    const pO = bK(vK[OO], KO, lO); - 1 === KO[hO].indexOf(pO) && KO[hO].push(pO)
                  } else KO[hO] = vK.slice(0)
            } else KO[hO] = bK(vK, KO, lO);
            else KO[hO] = vK
          } catch (CO) {
            XO.b.Warn(CO.message)
          }
        }
      }
    }
  },
  36274: (OO, KO, pO) => {
    function XO() {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (OO => {
        const KO = 16 * Math.random() | 0;
        return ("x" === OO ? KO : 3 & KO | 8).toString(16)
      }))
    }
    pO.d(KO, {
      b: () => XO
    })
  },
  37061: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      static _CheckLimit(OO, KO) {
        let pO = XO._LogLimitOutputs[OO];
        return pO ? pO.current++ : (pO = {
          limit: KO,
          current: 1
        }, XO._LogLimitOutputs[OO] = pO), pO.current <= pO.limit
      }
      static _GenerateLimitMessage(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        const pO = XO._LogLimitOutputs[OO];
        if (!pO || !XO.MessageLimitReached) return;
        const bK = this._Levels[KO];
        pO.current === pO.limit && XO[bK.name](XO.MessageLimitReached.replace(/%LIMIT%/g, "" + pO.limit).replace(/%TYPE%/g, bK.name ?? ""))
      }
      static _AddLogEntry(OO) {
        XO._LogCache = OO + XO._LogCache, XO.OnNewCacheEntry && XO.OnNewCacheEntry(OO)
      }
      static _FormatMessage(OO) {
        const KO = OO => OO < 10 ? "0" + OO : "" + OO,
          pO = new Date;
        return "[" + KO(pO.getHours()) + ":" + KO(pO.getMinutes()) + ":" + KO(pO.getSeconds()) + "]: " + OO
      }
      static _LogDisabled(OO, KO) {}
      static _LogEnabled() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const bK = Array.isArray(KO) ? KO[0] : KO;
        if (void 0 !== pO && !XO._CheckLimit(bK, pO)) return;
        const eO = XO._FormatMessage(bK),
          lO = this._Levels[OO],
          vK = Array.isArray(KO) ? KO.slice(1) : [];
        lO.logFunc && lO.logFunc("BJS - " + eO, ...vK);
        const CO = `<div style='color:${lO.color}'>${eO}</div><br>`;
        XO._AddLogEntry(CO), XO._GenerateLimitMessage(bK, OO)
      }
      static get LogCache() {
        return XO._LogCache
      }
      static ClearLogCache() {
        XO._LogCache = "", XO._LogLimitOutputs = {}, XO.errorsCount = 0
      }
      static set LogLevels(OO) {
        XO.Log = XO._LogDisabled, XO.Warn = XO._LogDisabled, XO.Error = XO._LogDisabled;
        const KO = [XO.MessageLogLevel, XO.WarningLogLevel, XO.ErrorLogLevel];
        for (const pO of KO)
          if ((OO & pO) === pO) {
            const OO = this._Levels[pO];
            XO[OO.name] = XO._LogEnabled.bind(XO, pO)
          }
      }
    }
    XO.NoneLogLevel = 0, XO.MessageLogLevel = 1, XO.WarningLogLevel = 2, XO.ErrorLogLevel = 4, XO.AllLogLevel = 7, XO.MessageLimitReached = "Too many %TYPE%s (%LIMIT%), no more %TYPE%s will be reported for this message.", XO._LogCache = "", XO._LogLimitOutputs = {}, XO._Levels = [{}, {
      color: "white",
      logFunc: console.log,
      name: "Log"
    }, {
      color: "orange",
      logFunc: console.warn,
      name: "Warn"
    }, {}, {
      color: "red",
      logFunc: console.error,
      name: "Error"
    }], XO.errorsCount = 0, XO.Log = XO._LogEnabled.bind(XO, XO.MessageLogLevel), XO.Warn = XO._LogEnabled.bind(XO, XO.WarningLogLevel), XO.Error = XO._LogEnabled.bind(XO, XO.ErrorLogLevel)
  },
  38162: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO.e
    });
    var XO = pO(38170);
    (0, XO.c)()
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);