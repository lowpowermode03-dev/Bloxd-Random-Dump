export const id = 142;
export const ids = [142];
export const modules = {
  7229: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      AditudeSdkAdaptor: () => lO
    });
    var XO = pO(1158),
      bK = pO(1044);
    const eO = {
      video: "pb-slot-interstitial-video",
      rewarded: "pb-slot-rewarded-video"
    };
    class lO extends XO.c {
      constructor() {
        super(), this.name = "aditude"
      }
      static async setup() {
        return window.tude = window.tude || {
          cmd: []
        }, await (0, bK.e)("https://edge.aditude.io/site/bloxd-Jf9xJheMSn/bloxd-longform/bloxd.io/prod/load.js"), new lO
      }
      playVideoAd(OO, KO) {
        this.playVideoOrRewarded("video", OO, OO)
      }
      playRewarded(OO, KO) {
        this.playVideoOrRewarded("rewarded", OO, KO)
      }
      renderBanner(OO) {
        const KO = this.getBaseDivId(OO.adId, OO.width, OO.height);
        window.tude.cmd.push((function() {
          window.tude.refreshAdsViaDivMappings([{
            divId: OO.divId,
            baseDivId: KO
          }])
        }))
      }
      getBaseDivId(OO, KO, pO) {
        return `pb-slot-bloxdio-${KO}-${pO}${OO>1?`-${OO}`:""}`
      }
      playVideoOrRewarded(OO, KO, pO) {
        var XO;
        let bK = !1;
        const lO = () => {
            document.getElementById("GenericVideoWrapper").style.display = "none", bK = !0
          },
          vK = (OO, KO) => {
            console.error(`AD: Error while playing Aditude video ad: ${OO}:`, KO), lO(), pO()
          };
        if (console.log(`AD: Requesting Aditude ${OO} ad`), void 0 === (null === (XO = window.tude) || void 0 === XO ? void 0 : XO.requestInstreamPlayer)) return console.log(`AD: Aditude ad lib not loaded, no ${OO} ad playing`), void vK("Aditude ad lib not loaded", null);
        document.getElementById("GenericVideoWrapper").style.display = "flex", document.getElementById("GenericVideoInner").classList.add("AditudeVideo"), window.tude.cmd.push((function() {
          console.log("AD: Inside Aditude window.tude.cmd.push");
          try {
            window.tude.requestInstreamPlayer({
              code: eO[OO],
              divId: "GenericVideoInner",
              mode: "adOnly"
            }).then((pO => {
              console.log("AD: Inside Aditude window.tude.requestInstreamPlayer.then"), pO.on("playerClose", ((pO, XO) => {
                console.log("AD: Inside Aditude player.on playerClose"), console.log(`AD: Successfully finished Aditude ${OO} ad`), lO(), KO()
              })).on("adPrefetchError", ((OO, KO) => {
                console.log("AD: Inside Aditude player.on adPrefetchError"), vK("Prefetch error", KO)
              })).on("adError", ((OO, KO) => {
                console.log("AD: Inside Aditude player.on adError"), vK("Generic error", KO)
              }));
              const XO = OO => {
                setTimeout((() => {
                  bK || pO.setVideoVolume(.5)
                }), OO)
              };
              XO(500), XO(1e3), XO(1500), XO(2e3)
            })).catch((OO => {
              vK("Error occurred while requesting instream player", OO)
            }))
          } catch (pO) {
            vK("Failed to request instream player", pO)
          }
        }))
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);