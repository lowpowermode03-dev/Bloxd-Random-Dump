export const id = 236;
export const ids = [236];
export const modules = {
  38180: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO
    });
    var XO = pO(37061),
      bK = pO(35676);
    class eO {
      static Instantiate(OO) {
        if (this.RegisteredExternalClasses && this.RegisteredExternalClasses[OO]) return this.RegisteredExternalClasses[OO];
        const KO = (0, bK.e)(OO);
        if (KO) return KO;
        XO.b.Warn(OO + " not found, you may have missed an import.");
        const pO = OO.split(".");
        let eO = "undefined" !== typeof window ? window : "undefined" !== typeof globalThis ? globalThis : this;
        for (let XO = 0, bK = pO.length; XO < bK; XO++) eO = eO[pO[XO]];
        return "function" !== typeof eO ? null : eO
      }
    }
    eO.RegisteredExternalClasses = {}
  },
  37966: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK
    });
    var XO = pO(37918);
    class bK {
      static get Now() {
        return (0, XO.n)() && window.performance && window.performance.now ? window.performance.now() : Date.now()
      }
    }
  },
  37996: (OO, KO, pO) => {
    function XO(OO) {
      let KO = 1;
      do {
        KO *= 2
      } while (KO < OO);
      return KO === OO
    }

    function bK(OO, KO, pO) {
      return OO * (1 - pO) + KO * pO
    }

    function eO(OO) {
      const KO = lO(OO),
        pO = vK(OO);
      return KO - OO > OO - pO ? pO : KO
    }

    function lO(OO) {
      return OO--, OO |= OO >> 1, OO |= OO >> 2, OO |= OO >> 4, OO |= OO >> 8, OO |= OO >> 16, ++OO
    }

    function vK(OO) {
      return OO |= OO >> 1, OO |= OO >> 2, OO |= OO >> 4, OO |= OO >> 8, (OO |= OO >> 16) - (OO >> 1)
    }

    function CO(OO, KO) {
      let pO;
      switch (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2) {
        case 1:
          pO = vK(OO);
          break;
        case 2:
          pO = eO(OO);
          break;
        default:
          pO = lO(OO)
      }
      return Math.min(pO, KO)
    }
    pO.d(KO, {
      e: () => vK,
      i: () => CO,
      j: () => XO,
      l: () => bK,
      o: () => eO
    })
  },
  38172: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => AO,
      i: () => dO,
      k: () => QO,
      o: () => zK
    });
    var XO, bK = pO(35660),
      eO = pO(37918),
      lO = pO(37061),
      vK = pO(37055),
      CO = pO(37966),
      hO = pO(37938),
      DO = pO(38112),
      MO = pO(35653),
      aK = pO(38104),
      oO = pO(37955),
      FO = pO(38180),
      VO = pO(36274),
      LO = pO(37996);
    class QO {
      static get BaseUrl() {
        return aK.f.BaseUrl
      }
      static set BaseUrl(OO) {
        aK.f.BaseUrl = OO
      }
      static get CleanUrl() {
        return aK.f.CleanUrl
      }
      static set CleanUrl(OO) {
        aK.f.CleanUrl = OO
      }
      static IsAbsoluteUrl(OO) {
        return 0 === OO.indexOf("//") || -1 !== OO.indexOf("://") && (-1 !== OO.indexOf(".") && (-1 !== OO.indexOf("/") && (!(OO.indexOf(":") > OO.indexOf("/")) && (OO.indexOf("://") < OO.indexOf(".") || (0 === OO.indexOf("data:") || 0 === OO.indexOf("blob:"))))))
      }
      static set ScriptBaseUrl(OO) {
        aK.f.ScriptBaseUrl = OO
      }
      static get ScriptBaseUrl() {
        return aK.f.ScriptBaseUrl
      }
      static set CDNBaseUrl(OO) {
        XO.ScriptBaseUrl = OO, XO.AssetBaseUrl = OO
      }
      static set ScriptPreprocessUrl(OO) {
        aK.f.ScriptPreprocessUrl = OO
      }
      static get ScriptPreprocessUrl() {
        return aK.f.ScriptPreprocessUrl
      }
      static get DefaultRetryStrategy() {
        return aK.f.DefaultRetryStrategy
      }
      static set DefaultRetryStrategy(OO) {
        aK.f.DefaultRetryStrategy = OO
      }
      static get CorsBehavior() {
        return aK.f.CorsBehavior
      }
      static set CorsBehavior(OO) {
        aK.f.CorsBehavior = OO
      }
      static get UseFallbackTexture() {
        return MO.c.UseFallbackTexture
      }
      static set UseFallbackTexture(OO) {
        MO.c.UseFallbackTexture = OO
      }
      static get RegisteredExternalClasses() {
        return FO.b.RegisteredExternalClasses
      }
      static set RegisteredExternalClasses(OO) {
        FO.b.RegisteredExternalClasses = OO
      }
      static get fallbackTexture() {
        return MO.c.FallbackTexture
      }
      static set fallbackTexture(OO) {
        MO.c.FallbackTexture = OO
      }
      static FetchToRef(OO, KO, pO, XO, bK, eO) {
        const lO = 4 * ((Math.abs(OO) * pO % pO | 0) + (Math.abs(KO) * XO % XO | 0) * pO);
        eO.r = bK[lO] / 255, eO.g = bK[lO + 1] / 255, eO.b = bK[lO + 2] / 255, eO.a = bK[lO + 3] / 255
      }
      static Mix(OO, KO, pO) {
        return 0
      }
      static Instantiate(OO) {
        return FO.b.Instantiate(OO)
      }
      static SetImmediate(OO) {
        oO.c.SetImmediate(OO)
      }
      static IsExponentOfTwo(OO) {
        return !0
      }
      static FloatRound(OO) {
        return Math.fround(OO)
      }
      static GetFilename(OO) {
        const KO = OO.lastIndexOf("/");
        return KO < 0 ? OO : OO.substring(KO + 1)
      }
      static GetFolderPath(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = OO.lastIndexOf("/");
        return pO < 0 ? KO ? OO : "" : OO.substring(0, pO + 1)
      }
      static ToDegrees(OO) {
        return 180 * OO / Math.PI
      }
      static ToRadians(OO) {
        return OO * Math.PI / 180
      }
      static SmoothAngleChange(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : .9;
        const XO = this.ToRadians(OO),
          bK = this.ToRadians(KO);
        return this.ToDegrees(Math.atan2((1 - pO) * Math.sin(bK) + pO * Math.sin(XO), (1 - pO) * Math.cos(bK) + pO * Math.cos(XO)))
      }
      static MakeArray(OO, KO) {
        return !0 === KO || void 0 !== OO && null != OO ? Array.isArray(OO) ? OO : [OO] : null
      }
      static GetPointerPrefix(OO) {
        return (0, eO.n)() && !window.PointerEvent ? "mouse" : "pointer"
      }
      static SetCorsBehavior(OO, KO) {
        (0, aK.B)(OO, KO)
      }
      static SetReferrerPolicyBehavior(OO, KO) {
        KO.referrerPolicy = OO
      }
      static get PreprocessUrl() {
        return aK.f.PreprocessUrl
      }
      static set PreprocessUrl(OO) {
        aK.f.PreprocessUrl = OO
      }
      static LoadImage(OO, KO, pO, XO, bK, eO) {
        return (0, aK.s)(OO, KO, pO, XO, bK, eO)
      }
      static LoadFile(OO, KO, pO, XO, bK, eO) {
        return (0, aK.o)(OO, KO, pO, XO, bK, eO)
      }
      static async LoadFileAsync(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        return await new Promise(((pO, XO) => {
          (0, aK.o)(OO, (OO => {
            pO(OO)
          }), void 0, void 0, KO, ((OO, KO) => {
            XO(KO)
          }))
        }))
      }
      static GetAssetUrl(OO) {
        if (!OO) return "";
        if (XO.AssetBaseUrl && OO.startsWith(XO._DefaultAssetsUrl)) {
          const KO = XO.AssetBaseUrl.endsWith("/") ? XO.AssetBaseUrl.slice(0, -1) : XO.AssetBaseUrl;
          return OO.replace(XO._DefaultAssetsUrl, KO)
        }
        return OO
      }
      static GetBabylonScriptURL(OO, KO) {
        if (!OO) return "";
        if (OO.startsWith(XO._DefaultCdnUrl))
          if (XO.ScriptBaseUrl) {
            const KO = XO.ScriptBaseUrl.endsWith("/") ? XO.ScriptBaseUrl.slice(0, -1) : XO.ScriptBaseUrl;
            OO = OO.replace(XO._DefaultCdnUrl, KO)
          } else if (XO._CdnVersion) {
          const KO = `${XO._DefaultCdnUrl}/v${XO._CdnVersion}`;
          OO.startsWith(KO) || (OO = OO.replace(XO._DefaultCdnUrl, KO))
        }
        return OO = XO.ScriptPreprocessUrl(OO), KO && !XO.IsAbsoluteUrl(OO) && (OO = XO.GetAbsoluteUrl(OO)), OO
      }
      static LoadBabylonScript(OO, KO, pO, bK) {
        OO = XO.GetBabylonScriptURL(OO), XO.LoadScript(OO, KO, pO)
      }
      static async LoadBabylonScriptAsync(OO) {
        return OO = XO.GetBabylonScriptURL(OO), await XO.LoadScriptAsync(OO)
      }
      static _LoadScriptNative(OO, KO, pO, bK) {
        if (_native) {
          if (arguments.length > 4 && void 0 !== arguments[4] && arguments[4]) {
            const OO = "Loading a script as an ES module is not supported in Babylon Native";
            return void pO?.(OO, new Error(OO))
          }
          XO.LoadFile(OO, (OO => {
            try {
              Function(OO).apply(null), KO && KO()
            } catch (XO) {
              pO && pO("LoadScript Error", XO)
            }
          }), void 0, void 0, !1, ((OO, KO) => {
            pO && pO("LoadScript Error", KO)
          }))
        }
      }
      static _LoadScriptWeb(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        if ("function" === typeof importScripts) {
          try {
            importScripts(OO), KO && KO()
          } catch (CO) {
            pO?.(`Unable to load script '${OO}' in worker`, CO)
          }
          return
        }
        if (!(0, eO.n)()) return void pO?.(`Cannot load script '${OO}' outside of a window or a worker`);
        const lO = document.getElementsByTagName("head")[0],
          vK = document.createElement("script");
        bK ? (vK.setAttribute("type", "module"), vK.innerText = OO) : (vK.setAttribute("type", "text/javascript"), vK.setAttribute("src", OO)), XO && (vK.id = XO), vK.onload = () => {
          KO && KO()
        }, vK.onerror = KO => {
          pO && pO(`Unable to load script '${OO}'`, KO)
        }, lO.appendChild(vK)
      }
      static async LoadScriptAsync(OO, KO) {
        return await new Promise(((pO, XO) => {
          this.LoadScript(OO, (() => {
            pO()
          }), ((OO, KO) => {
            XO(KO || new Error(OO))
          }), KO)
        }))
      }
      static ReadFileAsDataURL(OO, KO, pO) {
        const XO = new FileReader,
          eO = {
            onCompleteObservable: new bK.e,
            abort: () => XO.abort()
          };
        return XO.onloadend = () => {
          eO.onCompleteObservable.notifyObservers(eO)
        }, XO.onload = OO => {
          KO(OO.target.result)
        }, XO.onprogress = pO, XO.readAsDataURL(OO), eO
      }
      static ReadFile(OO, KO, pO, XO, bK) {
        return (0, aK.u)(OO, KO, pO, XO, bK)
      }
      static FileAsURL(OO) {
        const KO = new Blob([OO]);
        return window.URL.createObjectURL(KO)
      }
      static Format(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
        return OO.toFixed(KO)
      }
      static DeepCopy(OO, KO, pO, XO) {
        vK.d.DeepCopy(OO, KO, pO, XO)
      }
      static IsEmpty(OO) {
        for (const KO in OO)
          if (Object.prototype.hasOwnProperty.call(OO, KO)) return !1;
        return !0
      }
      static RegisterTopRootEvents(OO, KO) {
        for (let XO = 0; XO < KO.length; XO++) {
          const bK = KO[XO];
          OO.addEventListener(bK.name, bK.handler, !1);
          try {
            window.parent && window.parent.addEventListener(bK.name, bK.handler, !1)
          } catch (pO) {}
        }
      }
      static UnregisterTopRootEvents(OO, KO) {
        for (let XO = 0; XO < KO.length; XO++) {
          const bK = KO[XO];
          OO.removeEventListener(bK.name, bK.handler);
          try {
            OO.parent && OO.parent.removeEventListener(bK.name, bK.handler)
          } catch (pO) {}
        }
      }
      static async DumpFramebuffer(OO, KO, pO, XO) {
        throw (0, hO.j)("DumpTools")
      }
      static DumpData(OO, KO, pO, XO) {
        throw (0, hO.j)("DumpTools")
      }
      static async DumpDataAsync(OO, KO, pO) {
        throw (0, hO.j)("DumpTools")
      }
      static _IsOffScreenCanvas(OO) {
        return void 0 !== OO.convertToBlob
      }
      static ToBlob(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "image/png",
          bK = arguments.length > 3 ? arguments[3] : void 0;
        XO._IsOffScreenCanvas(OO) || OO.toBlob || (OO.toBlob = function(OO, KO, pO) {
          setTimeout((() => {
            const XO = atob(this.toDataURL(KO, pO).split(",")[1]),
              bK = XO.length,
              eO = new Uint8Array(bK);
            for (let OO = 0; OO < bK; OO++) eO[OO] = XO.charCodeAt(OO);
            OO(new Blob([eO]))
          }))
        }), XO._IsOffScreenCanvas(OO) ? OO.convertToBlob({
          type: pO,
          quality: bK
        }).then((OO => KO(OO))) : OO.toBlob((function(OO) {
          KO(OO)
        }), pO, bK)
      }
      static DownloadBlob(OO, KO) {
        if ("download" in document.createElement("a")) {
          if (!KO) {
            const OO = new Date;
            KO = "screenshot_" + ((OO.getFullYear() + "-" + (OO.getMonth() + 1)).slice(2) + "-" + OO.getDate() + "_" + OO.getHours() + "-" + ("0" + OO.getMinutes()).slice(-2)) + ".png"
          }
          XO.Download(OO, KO)
        } else if (OO && "undefined" !== typeof URL) {
          const KO = URL.createObjectURL(OO),
            pO = window.open("");
          if (!pO) return;
          const XO = pO.document.createElement("img");
          XO.onload = function() {
            URL.revokeObjectURL(KO)
          }, XO.src = KO, pO.document.body.appendChild(XO)
        }
      }
      static EncodeScreenshotCanvasData(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "image/png",
          bK = arguments.length > 3 ? arguments[3] : void 0,
          eO = arguments.length > 4 ? arguments[4] : void 0;
        if ("string" !== typeof bK && KO) {
          if (KO) {
            if (XO._IsOffScreenCanvas(OO)) return void OO.convertToBlob({
              type: pO,
              quality: eO
            }).then((OO => {
              const pO = new FileReader;
              pO.readAsDataURL(OO), pO.onloadend = () => {
                const OO = pO.result;
                KO(OO)
              }
            }));
            const bK = OO.toDataURL(pO, eO);
            KO(bK)
          }
        } else this.ToBlob(OO, (function(OO) {
          OO && XO.DownloadBlob(OO, bK), KO && KO("")
        }), pO, eO)
      }
      static Download(OO, KO) {
        if ("undefined" === typeof URL) return;
        const pO = window.URL.createObjectURL(OO),
          XO = document.createElement("a");
        document.body.appendChild(XO), XO.style.display = "none", XO.href = pO, XO.download = KO, XO.addEventListener("click", (() => {
          XO.parentElement && XO.parentElement.removeChild(XO)
        })), XO.click(), window.URL.revokeObjectURL(pO)
      }
      static BackCompatCameraNoPreventDefault(OO) {
        return "boolean" === typeof OO[0] ? OO[0] : "boolean" === typeof OO[1] && OO[1]
      }
      static CreateScreenshot(OO, KO, pO, XO) {
        throw (0, hO.j)("ScreenshotTools")
      }
      static async CreateScreenshotAsync(OO, KO, pO) {
        throw (0, hO.j)("ScreenshotTools")
      }
      static CreateScreenshotUsingRenderTarget(OO, KO, pO, XO) {
        throw (0, hO.j)("ScreenshotTools")
      }
      static async CreateScreenshotUsingRenderTargetAsync(OO, KO, pO) {
        throw (0, hO.j)("ScreenshotTools")
      }
      static RandomId() {
        return (0, VO.b)()
      }
      static IsBase64(OO) {
        return (0, aK.m)(OO)
      }
      static DecodeBase64(OO) {
        return (0, aK.e)(OO)
      }
      static get errorsCount() {
        return lO.b.errorsCount
      }
      static Log(OO) {
        lO.b.Log(OO)
      }
      static Warn(OO) {
        lO.b.Warn(OO)
      }
      static Error(OO) {
        lO.b.Error(OO)
      }
      static get LogCache() {
        return lO.b.LogCache
      }
      static ClearLogCache() {
        lO.b.ClearLogCache()
      }
      static set LogLevels(OO) {
        lO.b.LogLevels = OO
      }
      static set PerformanceLogLevel(OO) {
        (OO & XO.PerformanceUserMarkLogLevel) !== XO.PerformanceUserMarkLogLevel ? (OO & XO.PerformanceConsoleLogLevel) !== XO.PerformanceConsoleLogLevel ? (XO.StartPerformanceCounter = XO._StartPerformanceCounterDisabled, XO.EndPerformanceCounter = XO._EndPerformanceCounterDisabled, _native?.disablePerformanceLogging?.()) : _native?.enablePerformanceLogging ? (_native.enablePerformanceLogging(2), XO.StartPerformanceCounter = XO._StartMarkNative, XO.EndPerformanceCounter = XO._EndMarkNative) : (XO.StartPerformanceCounter = XO._StartPerformanceConsole, XO.EndPerformanceCounter = XO._EndPerformanceConsole) : _native?.enablePerformanceLogging ? (_native.enablePerformanceLogging(1), XO.StartPerformanceCounter = XO._StartMarkNative, XO.EndPerformanceCounter = XO._EndMarkNative) : (XO.StartPerformanceCounter = XO._StartUserMark, XO.EndPerformanceCounter = XO._EndUserMark)
      }
      static _StartPerformanceCounterDisabled(OO, KO) {}
      static _EndPerformanceCounterDisabled(OO, KO) {}
      static _StartUserMark(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (!XO._Performance) {
          if (!(0, eO.n)()) return;
          XO._Performance = window.performance
        }
        KO && XO._Performance.mark && XO._Performance.mark(OO + "-Begin")
      }
      static _EndUserMark(OO) {
        (!(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1]) && XO._Performance.mark && (XO._Performance.mark(OO + "-End"), XO._Performance.measure(OO, OO + "-Begin", OO + "-End"))
      }
      static _StartPerformanceConsole(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        KO && (XO._StartUserMark(OO, KO), console.time && console.time(OO))
      }
      static _EndPerformanceConsole(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        KO && (XO._EndUserMark(OO, KO), console.timeEnd(OO))
      }
      static _StartMarkNative(OO) {
        if ((!(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1]) && _native?.startPerformanceCounter)
          if (XO._NativePerformanceCounterHandles.has(OO)) XO.Warn(`Performance counter with name ${OO} is already started.`);
          else {
            const KO = _native.startPerformanceCounter(OO);
            XO._NativePerformanceCounterHandles.set(OO, KO)
          }
      }
      static _EndMarkNative(OO) {
        if ((!(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1]) && _native?.endPerformanceCounter) {
          const KO = XO._NativePerformanceCounterHandles.get(OO);
          KO ? (_native.endPerformanceCounter(KO), XO._NativePerformanceCounterHandles.delete(OO)) : XO.Warn(`Performance counter with name ${OO} was not started.`)
        }
      }
      static get Now() {
        return CO.d.Now
      }
      static GetClassName(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = null;
        if (!KO && OO.getClassName) pO = OO.getClassName();
        else {
          if (OO instanceof Object) {
            pO = (KO ? OO : Object.getPrototypeOf(OO)).constructor.__bjsclassName__
          }
          pO || (pO = typeof OO)
        }
        return pO
      }
      static First(OO, KO) {
        for (const pO of OO)
          if (KO(pO)) return pO;
        return null
      }
      static getFullClassName(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = null,
          XO = null;
        if (!KO && OO.getClassName) pO = OO.getClassName();
        else {
          if (OO instanceof Object) {
            const bK = KO ? OO : Object.getPrototypeOf(OO);
            pO = bK.constructor.__bjsclassName__, XO = bK.constructor.__bjsmoduleName__
          }
          pO || (pO = typeof OO)
        }
        return pO ? (null != XO ? XO + "." : "") + pO : null
      }
      static async DelayAsync(OO) {
        await new Promise((KO => {
          setTimeout((() => {
            KO()
          }), OO)
        }))
      }
      static IsSafari() {
        return !!(0, eO.k)() && /^((?!chrome|android).)*safari/i.test(navigator.userAgent)
      }
    }

    function zK(OO, KO) {
      return pO => {
        pO.__bjsclassName__ = OO, pO.__bjsmoduleName__ = null != KO ? KO : null
      }
    }
    XO = QO, QO.AssetBaseUrl = "", QO.UseCustomRequestHeaders = !1, QO.CustomRequestHeaders = DO.b.CustomRequestHeaders, QO.GetDOMTextContent = eO.e, QO._DefaultCdnUrl = "https://cdn.babylonjs.com", QO._CdnVersion = "9.28.0", QO._DefaultAssetsUrl = "https://assets.babylonjs.com/core", QO.LoadScript = "undefined" === typeof _native ? XO._LoadScriptWeb : XO._LoadScriptNative, QO.GetAbsoluteUrl = "object" === typeof document ? OO => {
      const KO = document.createElement("a");
      return KO.href = OO, KO.href
    } : "function" === typeof URL && "object" === typeof location ? OO => new URL(OO, location.origin).href : () => {
      throw new Error("Unable to get absolute URL. Override BABYLON.Tools.GetAbsoluteUrl to a custom implementation for the current context.")
    }, QO.NoneLogLevel = lO.b.NoneLogLevel, QO.MessageLogLevel = lO.b.MessageLogLevel, QO.WarningLogLevel = lO.b.WarningLogLevel, QO.ErrorLogLevel = lO.b.ErrorLogLevel, QO.AllLogLevel = lO.b.AllLogLevel, QO.IsWindowObjectExist = eO.n, QO.PerformanceNoneLogLevel = 0, QO.PerformanceUserMarkLogLevel = 1, QO.PerformanceConsoleLogLevel = 2, QO._NativePerformanceCounterHandles = new Map, QO.StartPerformanceCounter = XO._StartPerformanceCounterDisabled, QO.EndPerformanceCounter = XO._EndPerformanceCounterDisabled;
    class AO {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        this.iterations = OO, this.index = XO - 1, this._done = !1, this._fn = KO, this._successCallback = pO
      }
      executeNext() {
        this._done || (this.index + 1 < this.iterations ? (++this.index, this._fn(this)) : this.breakLoop())
      }
      breakLoop() {
        this._done = !0, this._successCallback()
      }
      static Run(OO, KO, pO) {
        const XO = new AO(OO, KO, pO, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0);
        return XO.executeNext(), XO
      }
      static SyncAsyncForLoop(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0;
        return AO.Run(Math.ceil(OO / KO), (XO => {
          bK && bK() ? XO.breakLoop() : setTimeout((() => {
            for (let eO = 0; eO < KO; ++eO) {
              const lO = XO.index * KO + eO;
              if (lO >= OO) break;
              if (pO(lO), bK && bK()) {
                XO.breakLoop();
                break
              }
            }
            XO.executeNext()
          }), eO)
        }), XO)
      }
    }
    let fO = !1;

    function dO() {
      fO || (fO = !0, QO.Mix = LO.l, QO.IsExponentOfTwo = LO.j, MO.c.FallbackTexture = "data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4QBmRXhpZgAATU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAAExAAIAAAAQAAAATgAAAAAAAABgAAAAAQAAAGAAAAABcGFpbnQubmV0IDQuMC41AP/bAEMABAIDAwMCBAMDAwQEBAQFCQYFBQUFCwgIBgkNCw0NDQsMDA4QFBEODxMPDAwSGBITFRYXFxcOERkbGRYaFBYXFv/bAEMBBAQEBQUFCgYGChYPDA8WFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFv/AABEIAQABAAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APH6KKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FCiiigD6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++gooooA+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gUKKKKAPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76CiiigD5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BQooooA+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/voKKKKAPl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FCiiigD6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++gooooA+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gUKKKKAPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76CiiigD5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BQooooA+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/voKKKKAPl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FCiiigD6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++gooooA+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gUKKKKAPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76P//Z")
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);