export const id = 204;
export const ids = [204];
export const modules = {
  35402: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => dO,
      f: () => fO
    });
    var XO = pO(3533),
      bK = pO(1263),
      eO = pO(63),
      lO = pO(5628),
      vK = pO(3523),
      CO = pO(1136),
      hO = pO(1556),
      DO = pO(1533),
      MO = pO(1271),
      aK = pO(1051),
      oO = pO(35409),
      FO = pO(918),
      VO = pO.n(FO),
      LO = pO(1152),
      QO = pO(933),
      zK = pO(1134),
      AO = pO(976);
    const fO = "SleepingOverlay";

    function dO() {
      const {
        t: OO
      } = (0, aK.D)(), [KO, pO] = (0, eO.useState)(!1), [FO, dO] = (0, eO.useState)(null), [NO, IO] = (0, eO.useState)(1), [yK, gK] = (0, eO.useState)(!1), [uO, EO] = (0, eO.useState)(!1), jK = (0, eO.useRef)(0), YO = (0, eO.useRef)(!1), wO = (0, eO.useRef)(!1), iK = (0, eO.useRef)(), rK = (0, eO.useRef)(null);

      function PO() {
        const OO = null !== FO && void 0 !== FO ? FO : "Rested Speed";
        hO.gameBridge.send("wakeUp", uO ? OO : null), rK.current = null, pO(!1), dO(null), IO(1), gK(!1), EO(!1)
      }

      function mK() {
        return !yK && (PO(), !0)
      }
      return (0, bK.f)("PlayerPhysicsTypeUpdate", (OO => {
        OO !== rK.current && (rK.current = OO, OO === lO.p.SLEEPING ? (wO.current || (jK.current = hO.gameBridge.lookup("cameraZoom", null), wO.current = !0), YO.current = !0, hO.gameBridge.send("setCameraZoom", 3), pO(!0), IO(function() {
          for (const OO of hO.gameBridge.lookup("blocksStandingOn", null)) {
            if (oO.d.leafBeds.includes(OO)) return console.log(`Found leaf bed: ${OO}`), 1;
            if (oO.d.woolBeds.includes(OO)) return console.log(`Found woold bed: ${OO}`), 2;
            if (oO.d.strongBeds.includes(OO)) return console.log(`Found strong bed ${OO}`), 3
          }
          return 1
        }())) : (wO.current = !1, pO(!1), dO(null), IO(1)))
      })), (0, eO.useEffect)((() => () => {
        (0, CO.j)(fO)
      }), []), (0, eO.useEffect)((() => {
        KO ? (0, CO.k)(fO) : ((0, CO.j)(fO), YO.current && (hO.gameBridge.send("setCameraZoom", jK.current), YO.current = !1))
      }), [KO]), (0, zK.q)("overlay", iK, mK, KO), (0, AO.jsx)(XO.d, {
        className: "SleepingOverlay",
        "data-camera-keeper": "",
        in: KO,
        timeout: 300,
        nodeRef: iK,
        unmountOnExit: !0,
        children: (0, AO.jsx)("div", {
          ref: iK,
          onClick: OO => {
            mK() && OO.stopPropagation()
          },
          children: (0, AO.jsxs)("div", {
            className: "SleepingOverlayBody",
            children: [(0, AO.jsx)("div", {
              className: "SleepingOverlayPerkList",
              children: vK.f.map((KO => (0, AO.jsxs)(TO, {
                restedEffect: KO,
                LJ: FO,
                setChosenRestedEffect: dO,
                children: [(0, AO.jsxs)("div", {
                  className: "SleepingOverlayPerkTitle",
                  children: [(0, AO.jsx)(DO.d, {
                    text: [{
                      icon: KO
                    }]
                  }), vK.d[KO].shortName]
                }), (0, AO.jsx)("div", {
                  className: "SleepingOverlayPerkDescription",
                  children: OO(vK.d[KO].description, {
                    time: vK.d[KO].effectLevelDurations[NO] / 6e4
                  })
                })]
              }, KO)))
            }), (0, AO.jsxs)("div", {
              className: "SleepingOverlayPerkBottom",
              children: [(0, AO.jsx)("div", {
                className: "SleepingOverlayPerkBottomSide"
              }), (0, AO.jsxs)(MO.d, {
                className: "SleepingOverlayWakeUpButton",
                onClick: OO => {
                  uO ? PO() : (gK(!0), (0, LO.mb)((() => {
                    gK(!1), EO(!0)
                  }), !0)), OO.stopPropagation()
                },
                loading: yK,
                children: [!uO && (0, AO.jsxs)(AO.Fragment, {
                  children: [(0, AO.jsx)(QO.d, {
                    name: "film"
                  }), " ", OO("classicGame:watchAdToGetRestedPerk")]
                }), uO && OO("classicGame:wakeUp")]
              }), (0, AO.jsxs)("div", {
                className: "SleepingOverlayPerkBottomSide",
                children: [(0, AO.jsx)("div", {
                  className: VO()("SleepingOverlayBedIcon", {
                    SleepingOverlayBedIconActive: 1 === NO
                  }),
                  children: (0, AO.jsx)(DO.d, {
                    text: [{
                      icon: "Leaf Bed"
                    }]
                  })
                }), (0, AO.jsx)("div", {
                  className: VO()("SleepingOverlayBedIcon", {
                    SleepingOverlayBedIconActive: 2 === NO
                  }),
                  children: (0, AO.jsx)(DO.d, {
                    text: [{
                      icon: "Red Bed"
                    }]
                  })
                }), (0, AO.jsx)("div", {
                  className: VO()("SleepingOverlayBedIcon", {
                    SleepingOverlayBedIconActive: 3 === NO
                  }),
                  children: (0, AO.jsx)(DO.d, {
                    text: [{
                      icon: "Red Strongbed"
                    }]
                  })
                })]
              })]
            })]
          })
        })
      })
    }
    const TO = (0, eO.memo)((function(OO) {
      let {
        children: KO,
        restedEffect: pO,
        LJ: XO,
        setChosenRestedEffect: bK
      } = OO;
      return pO === XO ? (0, AO.jsx)(MO.m, {
        onClick: OO => {
          OO.stopPropagation()
        },
        children: KO
      }) : (0, AO.jsx)(MO.e, {
        onClick: OO => {
          bK(pO), OO.stopPropagation()
        },
        children: KO
      })
    }))
  },
  38658: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => xK
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(3546),
      lO = pO(243),
      vK = pO(1441),
      CO = pO(7263),
      hO = pO(3562),
      DO = pO(7838),
      MO = pO(7291),
      aK = pO(7275),
      oO = pO(7299),
      FO = pO(1479),
      VO = pO(7307),
      LO = pO(7748),
      QO = pO(7886),
      zK = pO(7847),
      AO = pO(7893),
      fO = pO(1556),
      dO = pO(7255),
      TO = pO(7793),
      NO = pO(7789),
      IO = pO(7842);
    class yK {
      constructor() {
        this.lostAtMs = null
      }
      update(OO, KO) {
        return OO ? (this.lostAtMs = null, !1) : (this.lostAtMs ??= KO, KO - this.lostAtMs >= 250)
      }
      reset() {
        this.lostAtMs = null
      }
    }
    class gK {
      constructor(OO, KO) {
        this.press = OO, this.release = KO, this.downAtMs = null, this.token = null, this.latched = !1
      }
      update(OO, KO, pO, XO) {
        if (OO && null === this.downAtMs) return this.downAtMs = pO, this.latched = XO, void(this.token = this.press());
        null !== this.downAtMs && (this.latched ? OO && this.end() : !KO && pO - this.downAtMs >= 40 && this.end())
      }
      isLatched() {
        return null !== this.downAtMs && this.latched
      }
      unlatch() {
        this.latched = !1
      }
      cancel() {
        null !== this.downAtMs && this.end()
      }
      end() {
        const OO = this.token;
        this.downAtMs = null, this.token = null, this.latched = !1, this.release(OO)
      }
    }
    const uO = {
        kind: "specialAction",
        action: "SpecialAction2"
      },
      EO = OO => {
        let KO = null;
        const pO = new IO.b,
          XO = () => {
            KO && (((OO, KO, pO) => {
              switch (pO.kind) {
                case "reload":
                  return void KO.specialActionUp("SpecialAction1");
                case "specialAction":
                  return void KO.specialActionUp(pO.action);
                case "customButton":
                  return void fO.gameBridge.send("pressCustomButton", {
                    id: pO.id,
                    down: !1
                  });
                case "touchButton":
                  OO.pressTouchButton(!1)
              }
            })(OO, KO.bodies, KO.action), KO = null)
          },
          eO = (pO, bK, eO, lO) => {
            XO(), KO = {
              action: bK,
              bodies: pO,
              heldBy: eO,
              atMs: lO
            }, ((OO, KO, pO) => {
              switch (pO.kind) {
                case "reload":
                  return KO.reloadGun(), void KO.specialActionDown("SpecialAction1");
                case "specialAction":
                  return void KO.specialActionDown(pO.action);
                case "customButton":
                  return void fO.gameBridge.send("pressCustomButton", {
                    id: pO.id,
                    down: !0
                  });
                case "touchButton":
                  OO.pressTouchButton(!0)
              }
            })(OO, pO, bK)
          };
        return {
          update: (lO, vK, hO, DO) => {
            var aK;
            const oO = (0, TO.o)(OO.contextActionInputs()),
              FO = null !== (aK = oO[0]) && void 0 !== aK ? aK : uO;
            (0, NO.d)((0, TO.h)(FO) ? FO : null);
            const VO = (0, TO.e)(oO);
            (0, NO.e)(VO);
            const LO = (0, CO.j)("actionButton");
            if (VO) {
              const OO = pO.update(vK.wasPressed(LO), vK.isHeld(LO), hO, DO);
              "tap" === OO ? eO(lO, FO, [LO], hO) : "hold" === OO && (MO.c.consumeButton(LO), bK.i.pl(AO.k, oO))
            } else pO.release(), vK.wasPressed(LO) && eO(lO, FO, [LO], hO);
            KO && hO - KO.atMs >= 40 && !KO.heldBy.some((OO => (0, dO.J)(vK.frame.values, OO))) && XO()
          },
          pressPicked: (OO, KO) => {
            eO(OO, KO, [(0, CO.j)("menuConfirm"), (0, CO.j)("actionButton")], performance.now())
          },
          release: () => {
            pO.release(), XO(), (0, NO.d)(null), (0, NO.e)(!1)
          }
        }
      };
    var jK = pO(7252);
    var YO = pO(38653),
      wO = pO(7806),
      iK = pO(7289),
      rK = pO(7927);
    var PO = pO(38648),
      mK = pO(7935),
      sO = pO(38662),
      HO = pO(7913),
      RO = pO(7811),
      SO = pO(7817),
      JO = pO(7819),
      cK = pO(7750);
    const BO = () => cK.d[(0, aK.i)().tapHoldTime].wheelMs,
      ZO = () => ((0, DO.c)(), new Event("controllerMenuKey")),
      GO = (OO, KO, pO) => new gK((() => {
        const pO = OO.bodies();
        return {
          bodies: pO,
          press: KO(pO)
        }
      }), (OO => {
        let {
          bodies: KO,
          press: XO
        } = OO;
        pO(KO, XO)
      })),
      qK = {
        running: !1,
        latchedAtMs: -1 / 0
      },
      xK = OO => {
        const KO = {
          x: 0,
          y: 0,
          magnitude: 0,
          headingOffset: 0,
          jumpHeld: !1,
          jumpPressed: !1,
          running: !1,
          sprintHeld: !1
        };
        let pO = qK;
        const DO = new sO.e,
          fO = bK.i.subscribe("appManagerUpdated|activeInputDevice", (KO => {
            OO.deviceChanged(KO)
          }));
        let TO = null,
          NO = 0;
        const gK = () => {
          TO = null, (0, RO.f)(null)
        };
        let uO = !1;
        const xK = new yK,
          nO = OO.look,
          WO = new IO.b,
          tK = new IO.b,
          kK = EO(OO),
          UO = bK.i.subscribe(AO.l, (KO => {
            kK.pressPicked(OO.bodies(), KO)
          })),
          OK = GO(OO, (OO => OO.primaryFireDown()), ((OO, KO) => {
            OO.primaryFireUp(KO)
          })),
          KK = GO(OO, (OO => OO.altFireDown()), ((OO, KO) => {
            OO.altFireUp(KO)
          }));
        let pK = !1,
          XK = !1,
          bp = !1;
        const eK = (0, LO.b)(dO.bb),
          lK = (0, LO.b)(dO.bb),
          vp = new IO.b;
        let CK = !1;
        const hK = () => {
            eK.reset(), lK.reset(), vp.release(), (0, JO.d)(!1), nO.release(), OK.cancel(), (0, SO.h)(!1), KK.cancel(), kK.release(), WO.release(), tK.release(), gK()
          },
          DK = function() {
            let XO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            hK(), XK = !1, XO || (pK = !1, pO = qK, Object.assign(KO, {
              x: 0,
              y: 0,
              magnitude: 0,
              headingOffset: 0,
              jumpHeld: !1,
              jumpPressed: !1,
              running: !1,
              sprintHeld: !1
            }), OO.stopMoving())
          },
          MK = function(XO, bK, eO) {
            let lO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
            const vK = (0, aK.i)(),
              hO = (0, PO.g)(bK, vK.moveDeadzone),
              MO = (0, CO.j)("sprint");
            pO = (0, PO.p)(pO, {
              sprintPressed: XO.wasPressed(MO),
              magnitude: hO.magnitude,
              autoSprint: vK.autoSprint,
              nowMs: eO
            }), KO.running = pO.running, KO.sprintHeld = XO.isHeld(MO), KO.x = hO.x, KO.y = hO.y, KO.magnitude = hO.speed, KO.headingOffset = hO.headingOffset, pK = hO.magnitude > 0;
            const oO = (0, CO.j)("jump");
            if (KO.jumpHeld = XO.isHeld(oO), KO.jumpPressed = XO.wasPressed(oO), KO.jumpPressed && OO.bodies().jumpDown(), lO) return void OO.move(KO, null);
            const FO = (0, CO.j)("sneak"),
              VO = DO.filter({
                sneakHeld: XO.isHeld(FO),
                sneakPressed: XO.wasPressed(FO),
                sneakTogglePressed: XO.wasPressed((0, CO.j)("sneakToggle"))
              }, eO);
            OO.move(KO, {
              ...VO,
              mode: vK.sneakMode
            })
          },
          ap = (OO, KO) => {
            const pO = (0, CO.j)("chat");
            if ("off" === (0, aK.i)().quickChat) return void(OO.wasPressed(pO) && (MO.c.consumeButton(pO), bK.i.pl(wO.d)));
            const XO = WO.update(OO.wasPressed(pO), OO.isHeld(pO), KO, BO());
            "tap" === XO || "hold" === XO && null === (0, FO.d)() ? bK.i.pl(wO.d) : "hold" === XO && (MO.c.consumeButton(pO), bK.i.pl(zK.o))
          },
          oK = (KO, pO) => {
            ((OO, KO) => {
              const pO = (0, QO.c)(),
                XO = (0, CO.j)("emoteWheel");
              if ("wheel" === (0, aK.i)().emoteButton) return OO.wasPressed(XO) && (MO.c.consumeButton(XO), bK.i.pl("requestEmoteWheelPadOpen", !0)), (0, QO.c)() !== pO;
              const eO = tK.update(OO.wasPressed(XO), OO.isHeld(XO), KO, BO());
              return "tap" === eO ? bK.i.pl("requestEmoteRepeatLast") : "hold" === eO && (MO.c.consumeButton(XO), bK.i.pl("requestEmoteWheelPadOpen", !1)), (0, QO.c)() !== pO
            })(KO, pO) || ap(KO, pO), KO.wasPressed((0, CO.j)("inventory")) && (MO.c.consumeButton((0, CO.j)("inventory")), (0, vK.t)(ZO(), "inventory", OO.hasFullInventory())), KO.wasPressed((0, CO.j)("pause")) && (MO.c.consumeButton((0, CO.j)("pause")), (0, hO.d)() === lO.o.SOCIAL ? (0, vK.p)(ZO(), lO.o.SOCIAL) : (0, vK.f)(ZO())), KO.wasPressed((0, CO.j)("leaderboard")) && !(0, eO.h)() && (MO.c.consumeButton((0, CO.j)("leaderboard")), ((OO, KO) => {
              if ("shop" === (0, iK.b)()) return bK.i.pl(rK.f), void(0, vK.p)(OO, lO.o.SHOP, !0);
              (0, vK.p)(OO, lO.o.LOBBY_LEADERBOARD, KO)
            })(ZO(), OO.hasLobbyLeaderboard()))
          },
          FK = (KO, pO) => {
            const XO = OO.bodies();
            ((KO, pO) => {
              const XO = (0, CO.j)("attack"),
                bK = KO.wasPressed(XO);
              bK && !OK.isLatched() && (uO = OO.targetsBlock()), OK.update(bK, KO.isHeld(XO), pO, "toggle" === (0, aK.i)().attackMode), OK.isLatched() && uO ? xK.update(OO.targetsBlock(), pO) && OK.unlatch() : xK.reset(), (0, SO.h)(OK.isLatched())
            })(KO, pO), KK.update(KO.wasPressed((0, CO.j)("use")), KO.isHeld((0, CO.j)("use")), pO, !1), eK.update(KO.isHeld((0, CO.j)("hotbarPrevious")), pO) && OO.scrollHotbar(-1), lK.update(KO.isHeld((0, CO.j)("hotbarNext")), pO) && OO.scrollHotbar(1), ((KO, pO, XO) => {
              const bK = (0, CO.j)("perspective"),
                eO = (0, CO.j)("XM"),
                lO = OO.pickBlockAllowed();
              (0, JO.d)(lO && !CK && OO.targetsBlock());
              const vK = () => {
                pO.XM() && (CK = !0, (0, JO.d)(!1))
              };
              if (!lO || eO !== bK) return vp.release(), KO.wasPressed(bK) && pO.swapCameraZoom(), void(lO && KO.wasPressed(eO) && vK());
              const hO = vp.update(KO.wasPressed(eO), KO.isHeld(eO), XO, BO());
              "tap" === hO ? vK() : "hold" === hO && pO.swapCameraZoom()
            })(KO, XO, pO), ((KO, pO, XO) => {
              const bK = (0, CO.j)("drop");
              if (KO.wasPressed(bK)) {
                pO.dropItem(!1);
                const OO = (0, aK.i)();
                "off" !== OO.buttonRepeat && (TO = XO, NO = cK.d[OO.tapHoldTime].dropStackMs, (0, RO.f)(NO))
              }
              null !== TO && (!KO.isHeld(bK) || OO.selectedSlotEmpty() ? gK() : XO - TO >= NO && (gK(), pO.dropItem(!0)))
            })(KO, XO, pO), kK.update(XO, KO, pO, BO()), oK(KO, pO)
          },
          VK = MO.c.register({
            name: "gameplay",
            isActive: () => {
              const KO = pK && "keyboardMouse" === XO.d.get("activeInputDevice") && !(0, oO.K)(),
                pO = (0, oO.o)() ? [YO.b] : [];
              return ((0, oO.o)() || KO) && (0, VO.g)(pO) && OO.hasPlayer()
            },
            onFrame: OO => {
              const KO = performance.now(),
                pO = (0, aK.i)(),
                XO = (0, PO.s)(OO, (0, PO.k)(pO, (0, CO.j)("pause"), (0, mK.e)().isSupported())),
                bK = (0, PO.h)(XO, pO.swapSticks);
              return (0, oO.o)() ? (XK = !1, (0, VO.g)() ? (bp = !1, nO.update(bK.look, pO, XO.isHeld((0, CO.j)("use"))), MK(XO, bK.move, KO), void FK(XO, KO)) : (bp || (bp = !0, DO.lostToPadScreen(), DK()), void ap(XO, KO))) : (XK || (hK(), XK = !0), void MK(XO, bK.move, KO))
            },
            onDeactivate: OO => {
              (0, oO.o)() && DO.lostToPadScreen(), DK(OO)
            },
            onPeekFrame: KO => {
              (0, oO.o)() && (0, VO.g)(YO.h) && OO.hasPlayer() ? MK(KO, (0, PO.h)(KO, (0, aK.i)().swapSticks).move, performance.now(), !0) : DK()
            }
          }),
          LK = (0, YO.d)(OO),
          QK = (() => {
            const OO = bK.i.subscribe(jK.c, (OO => {
              !OO && (0, oO.o)() && "inGame" === XO.d.get("gameState") && bK.i.pl("showBottomMessage", {
                message: [{
                  translationKey: "controller:disconnected"
                }],
                timeoutLength: 3e3,
                type: "Warning"
              })
            }));
            return () => {
              bK.i.unsubscribe(OO)
            }
          })();
        return () => {
          DK(), OO.uninstall(), (0, HO.i)(!1), (0, JO.d)(!1), bK.i.unsubscribe(fO), bK.i.unsubscribe(UO), VK(), LK(), QK(), nO.uninstall()
        }
      }
  },
  38653: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => FO,
      d: () => LO,
      h: () => oO
    });
    var XO = pO(1136),
      bK = pO(3546),
      eO = pO(7872),
      lO = pO(35402),
      vK = pO(1152),
      CO = pO(1046),
      hO = pO(7307),
      DO = pO(7847),
      MO = pO(7893);
    const aK = {
        emoteWheel: eO.g,
        quickChatWheel: DO.b,
        actionWheel: MO.o
      },
      oO = Object.keys(aK),
      FO = "dead",
      VO = OO => (0, XO.i)().includes(OO),
      LO = OO => {
        const KO = [(0, hO.k)(FO, (() => OO.hasPlayer() && OO.isPlayerDead())), (0, hO.k)("sleeping", (() => VO(lO.f))), (0, hO.k)("turnstile", (() => VO(CO.g))), (0, hO.k)("videoAd", vK.S), (0, hO.k)("replay", (() => (0, bK.h)() || OO.isReplayMode())), (0, hO.k)("freeCamera", (() => OO.isFreeCameraOn())), ...Object.entries(aK).map((OO => {
          let [KO, pO] = OO;
          return (0, hO.k)(KO, pO)
        }))];
        return () => {
          for (const OO of KO) OO()
        }
      }
  },
  38648: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      g: () => CO,
      h: () => vK,
      k: () => DO,
      m: () => lO,
      n: () => eO,
      p: () => hO,
      s: () => MO
    });
    var XO = pO(7255);
    class bK {
      constructor() {
        this.fullTiltSinceMs = null
      }
      update(OO, KO, pO) {
        const bK = (0, XO.g)(OO, KO.lookDeadzone);
        if (Math.hypot(bK.x, bK.y) < .9 || Math.abs(bK.x) < Math.abs(bK.y)) return this.fullTiltSinceMs = null, 1;
        null === this.fullTiltSinceMs && (this.fullTiltSinceMs = pO);
        const eO = (lO = KO.lookSensitivityX, Math.min(1, 100 / lO));
        var lO;
        return 1 + (1.6 - 1) * Math.max(0, Math.min(1, (pO - this.fullTiltSinceMs - 250 * eO) / (200 * eO)))
      }
      reset() {
        this.fullTiltSinceMs = null
      }
    }
    const eO = (OO, KO, pO, bK, eO) => {
        let lO = 1;
        return "boost" === pO.lookCurve ? lO = OO.update(KO, pO, eO) : OO.reset(),
          function(OO, KO) {
            let {
              yawBoost: pO = 1,
              aiming: bK = !1
            } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            const eO = (0, XO.f)((0, XO.g)(OO, KO.lookDeadzone), KO.lookCurve),
              lO = 220 * Math.PI / 180,
              vK = bK ? KO.aimLookSensitivity / 100 : 1,
              CO = KO.lookSensitivityX / 100 * vK,
              hO = KO.lookSensitivityY / 100 * vK;
            return {
              yawRadPerSec: eO.x * lO * CO * pO * (KO.invertLookX ? -1 : 1),
              pitchRadPerSec: eO.y * lO * .7 * hO * (KO.invertLookY ? -1 : 1)
            }
          }(KO, pO, {
            yawBoost: lO,
            aiming: bK
          })
      },
      lO = (OO, KO) => {
        const pO = Math.max(0, Math.min(250, KO)) / 1e3;
        return {
          wKO: OO.yawRadPerSec * pO,
          ipO: OO.pitchRadPerSec * pO
        }
      },
      vK = (OO, KO) => KO ? {
        move: OO.rightStick,
        look: OO.leftStick
      } : {
        move: OO.leftStick,
        look: OO.rightStick
      },
      CO = (OO, KO) => {
        const pO = (0, XO.g)(OO, KO),
          bK = Math.min(1, Math.hypot(pO.x, pO.y));
        return {
          magnitude: bK,
          speed: Math.min(1, bK / .8),
          headingOffset: 0 === bK ? 0 : Math.atan2(pO.x, -pO.y),
          x: pO.x,
          y: pO.y
        }
      },
      hO = (OO, KO) => {
        let {
          sprintPressed: pO,
          magnitude: XO,
          autoSprint: bK,
          nowMs: eO
        } = KO;
        const lO = pO ? eO : OO.latchedAtMs,
          vK = (OO => {
            let {
              running: KO,
              magnitude: pO,
              sprintPressed: XO,
              autoSprint: bK
            } = OO;
            return !(pO < .5) && (!!XO || !!(bK && pO >= .9) || KO)
          })({
            running: OO.running,
            magnitude: XO,
            sprintPressed: eO - lO <= 1e3,
            autoSprint: bK
          });
        return {
          running: vK,
          latchedAtMs: vK ? -1 / 0 : lO
        }
      },
      DO = (OO, KO, pO) => pO && OO.gyroAiming && "button" === OO.gyroActivation && OO.gyroButton !== KO ? OO.gyroButton : null,
      MO = (OO, KO) => KO ? {
        ...OO,
        isHeld: pO => pO !== KO && OO.isHeld(pO),
        wasPressed: pO => pO !== KO && OO.wasPressed(pO),
        wasReleased: pO => pO !== KO && OO.wasReleased(pO),
        value: pO => pO === KO ? 0 : OO.value(pO)
      } : OO
  },
  38662: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      g: () => XO
    });
    const XO = OO => {
      let {
        mode: KO,
        sneakHeld: pO,
        sneakPressed: XO,
        sneakTogglePressed: bK,
        descending: eO,
        canCrouch: lO,
        toggled: vK
      } = OO;
      return lO ? eO ? {
        crouchHeld: pO,
        toggled: !1
      } : "hold" === KO ? {
        crouchHeld: pO,
        toggled: bK ? !vK : vK
      } : {
        crouchHeld: !1,
        toggled: XO || bK ? !vK : vK
      } : {
        crouchHeld: !1,
        toggled: !1
      }
    };
    class bK {
      constructor() {
        this.regainPending = !1, this.regainedAtMs = -1 / 0, this.graceEndsMs = -1 / 0, this.ignoringHeld = !1
      }
      lostToPadScreen() {
        this.regainPending = !0
      }
      filter(OO, KO) {
        this.regainPending && (this.regainPending = !1, this.regainedAtMs = KO, this.graceEndsMs = KO + 500);
        const pO = KO < this.graceEndsMs;
        return pO && (OO.sneakPressed || OO.sneakTogglePressed) && (this.graceEndsMs = Math.min(this.regainedAtMs + 1e3, Math.max(this.graceEndsMs, KO + 300))), OO.sneakHeld ? pO && OO.sneakPressed && (this.ignoringHeld = !0) : this.ignoringHeld = !1, {
          sneakHeld: OO.sneakHeld && !this.ignoringHeld,
          sneakPressed: OO.sneakPressed && !this.ignoringHeld,
          sneakTogglePressed: OO.sneakTogglePressed && !pO
        }
      }
    }
  },
  38642: (OO, KO, pO) => {
    pO(7935)
  },
  38644: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => AO
    });
    var XO = pO(26),
      bK = pO(7872),
      eO = pO(7880),
      lO = pO(7263),
      vK = pO(7291),
      CO = pO(7275),
      hO = pO(38648),
      DO = pO(38653),
      MO = pO(7307),
      aK = pO(7255),
      oO = pO(7847),
      FO = pO(7893);
    const VO = [{
        isOpen: bK.h,
        openButton: () => (0, lO.j)("emoteWheel"),
        aim: OO => {
          XO.i.pl("emoteWheelPadAim", OO)
        },
        commit: OO => {
          XO.i.pl("requestEmoteWheelPadCommit", OO)
        },
        close: () => {
          XO.i.pl("requestEmoteWheelClose")
        }
      }, {
        isOpen: oO.b,
        openButton: () => (0, lO.j)("chat"),
        aim: OO => {
          XO.i.pl(oO.e, OO)
        },
        commit: OO => {
          XO.i.pl(oO.m, OO)
        },
        close: () => {
          XO.i.pl(oO.i)
        },
        keptOpenBy: [DO.b]
      }, {
        isOpen: FO.o,
        openButton: () => (0, lO.j)("actionButton"),
        aim: OO => {
          XO.i.pl(FO.d, OO)
        },
        commit: OO => {
          XO.i.pl(FO.j, OO)
        },
        close: () => {
          XO.i.pl(FO.h)
        }
      }],
      LO = () => {
        var OO;
        return null !== (OO = VO.find((OO => OO.isOpen()))) && void 0 !== OO ? OO : null
      },
      QO = OO => (0, lO.K)(OO.openButton()),
      zK = (OO, KO) => !(0, aK.J)(OO.frame.values, KO),
      AO = () => {
        let OO = null,
          KO = !1,
          pO = !1;
        return vK.c.register({
          name: "wheel",
          isActive: () => null !== LO(),
          peek: () => {
            const OO = LO();
            return OO && QO(OO) ? null : {
              over: "gameplay",
              stick: (0, CO.i)().swapSticks ? "right" : "left"
            }
          },
          onFrame: XO => {
            var bK;
            const aK = LO();
            if (!aK) return;
            if (null !== (0, MO.d)([...DO.h, ...null !== (bK = aK.keptOpenBy) && void 0 !== bK ? bK : []])) return void aK.close();
            const oO = aK.openButton(),
              FO = (0, hO.h)(XO.frame, (0, CO.i)().swapSticks),
              VO = QO(aK) ? FO.move : FO.look;
            OO !== aK ? (OO = aK, KO = !zK(XO, oO) || Math.hypot(VO.x, VO.y) >= eO.D, pO = !1) : pO && (pO = !1, zK(XO, oO) && (KO = !1)), aK.aim(VO);
            const AO = (0, lO.j)("menuConfirm"),
              fO = (0, lO.j)("menuBack");
            return XO.wasPressed(fO) ? (vK.c.consumeButton(fO), void aK.close()) : XO.wasPressed(AO) || XO.wasPressed(oO) ? (vK.c.consumeButton(AO), vK.c.consumeButton(oO), void aK.commit(!1)) : void(KO && zK(XO, oO) && (KO = !1, aK.commit(!0)))
          },
          onDeactivate: () => {
            pO = null !== OO && LO() === OO, pO || (OO = null, KO = !1)
          }
        })
      }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);