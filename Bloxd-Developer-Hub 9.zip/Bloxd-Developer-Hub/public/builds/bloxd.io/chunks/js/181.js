export const id = 181;
export const ids = [181];
export const modules = {
  37869: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      emptyColumnHeight: () => fO,
      loadHeatmapSchematic: () => dO,
      readSchematicBlocks: () => TO
    });
    var XO = pO(3013),
      bK = pO.n(XO),
      eO = pO(2988),
      lO = pO(36111),
      vK = pO(171),
      CO = pO(8365);
    const hO = [{
        name: "x",
        type: "int"
      }, {
        name: "y",
        type: "int"
      }, {
        name: "z",
        type: "int"
      }],
      DO = [{
        name: "name",
        type: "string"
      }, {
        name: "startOffset",
        type: {
          type: "record",
          fields: hO
        }
      }, {
        name: "dimensions",
        type: {
          type: "record",
          fields: hO
        }
      }, {
        name: "chunkData",
        type: {
          type: "array",
          items: {
            type: "record",
            fields: [...hO, {
              name: "rle",
              type: "bytes"
            }]
          }
        }
      }],
      MO = bK().Type.forSchema({
        type: "record",
        fields: DO
      }),
      aK = bK().Type.forSchema({
        type: "record",
        fields: [...DO, {
          name: "blockData",
          type: {
            type: "array",
            items: {
              type: "record",
              fields: [...hO, {
                name: "data",
                type: "bytes"
              }]
            }
          }
        }, {
          name: "pasteOffset",
          type: {
            type: "record",
            fields: hO
          }
        }]
      }),
      oO = 2,
      FO = 6,
      VO = {
        Water: [63, 118, 228],
        Lava: [232, 110, 30]
      },
      LO = [150, 150, 150],
      QO = 16,
      zK = 4096,
      AO = vK.h.SX,
      fO = -2147483648;
    async function dO(OO) {
      const KO = await TO(new Uint8Array(await OO.arrayBuffer()), await async function() {
        const {
          averageColors: OO
        } = await pO.e(187).then((() => pO(33017))), KO = new Map;
        return pO => {
          var XO, bK, eO, lO, vK;
          const hO = KO.get(pO);
          if (void 0 !== hO) return hO;
          const DO = null !== (XO = null === (bK = CO.l[pO]) || void 0 === bK ? void 0 : bK.name) && void 0 !== XO ? XO : "",
            MO = null !== (eO = OO[DO]) && void 0 !== eO ? eO : OO[DO.split("|")[0]],
            aK = VO[DO.split("|")[0]],
            oO = null !== (lO = null !== (vK = null === MO || void 0 === MO ? void 0 : MO[0]) && void 0 !== vK ? vK : aK) && void 0 !== lO ? lO : 0 === (null === MO || void 0 === MO ? void 0 : MO.length) ? null : LO;
          return KO.set(pO, oO), oO
        }
      }());
      return {
        surface: KO.surface,
        topDown: IO(KO.columnTops)
      }
    }
    async function TO(OO, KO) {
      var pO;
      if (OO.byteLength < 4) throw new Error("The file is too short to be a schematic.");
      const XO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength).getUint32(0, !0);
      if (XO > FO) throw new Error("The file isn't a schematic this version of Bloxd can read.");
      const bK = (XO >= oO ? aK : MO).decode(eO.jb.from(OO.subarray(4)), 0).value;
      if (!bK) throw new Error("The file isn't a schematic.");
      if (0 === bK.chunkData.length) throw new Error("The schematic has no blocks in it.");
      const vK = null !== (pO = bK.pasteOffset) && void 0 !== pO ? pO : {
          x: 0,
          y: 0,
          z: 0
        },
        CO = [vK.x, vK.y, vK.z].map((OO => Math.floor(OO / AO))),
        hO = bK.chunkData.map((OO => ({
          x: OO.x + CO[0],
          y: OO.y + CO[1],
          z: OO.z + CO[2],
          rle: OO.rle
        }))),
        DO = new Map;
      for (const [eO, MO] of hO.entries()) {
        const OO = new Uint16Array(AO ** 3);
        lO.decode(MO.rle, OO), DO.set(`${MO.x},${MO.y},${MO.z}`, OO), eO % QO === QO - 1 && await yK()
      }
      const VO = (OO, KO, pO) => OO * AO * AO + KO * AO + pO,
        LO = (OO, KO, pO) => {
          var XO, bK;
          const eO = Math.floor(OO / AO),
            lO = Math.floor(KO / AO),
            vK = Math.floor(pO / AO);
          return null !== (XO = null === (bK = DO.get(`${eO},${lO},${vK}`)) || void 0 === bK ? void 0 : bK[VO(OO - eO * AO, KO - lO * AO, pO - vK * AO)]) && void 0 !== XO ? XO : 0
        },
        zK = new Map,
        dO = [],
        TO = [];
      for (const [eO, lO] of hO.entries()) {
        const OO = DO.get(`${lO.x},${lO.y},${lO.z}`),
          pO = [lO.x * AO, lO.y * AO, lO.z * AO],
          XO = (KO, XO, bK) => KO < 0 || XO < 0 || bK < 0 || KO >= AO || XO >= AO || bK >= AO ? LO(pO[0] + KO, pO[1] + XO, pO[2] + bK) : OO[VO(KO, XO, bK)],
          bK = `${lO.x},${lO.z}`;
        let vK = zK.get(bK);
        void 0 === vK && (vK = {
          chunkX: lO.x,
          chunkZ: lO.z,
          heights: new Int32Array(AO * AO).fill(fO),
          colours: new Uint8Array(AO * AO * 3)
        }, zK.set(bK, vK));
        for (let eO = 0; eO < AO; eO++)
          for (let bK = 0; bK < AO; bK++)
            for (let lO = 0; lO < AO; lO++) {
              const CO = OO[VO(eO, bK, lO)];
              if (0 === CO) continue;
              const hO = pO[0] + eO,
                DO = pO[1] + bK,
                MO = pO[2] + lO,
                aK = KO(CO);
              if (null === aK) continue;
              const oO = lO * AO + eO;
              DO > vK.heights[oO] && (vK.heights[oO] = DO, vK.colours.set(aK, 3 * oO));
              !NO(CO) && (NO(XO(eO + 1, bK, lO)) || NO(XO(eO - 1, bK, lO)) || NO(XO(eO, bK + 1, lO)) || NO(XO(eO, bK - 1, lO)) || NO(XO(eO, bK, lO + 1)) || NO(XO(eO, bK, lO - 1))) && (dO.push(hO, DO, MO), TO.push(aK[0], aK[1], aK[2]))
            }
        eO % QO === QO - 1 && await yK()
      }
      if (0 === dO.length) throw new Error("The schematic has no blocks in it.");
      return {
        name: bK.name,
        surface: {
          positions: Int32Array.from(dO),
          colours: Uint8Array.from(TO),
          count: dO.length / 3
        },
        columnTops: [...zK.values()]
      }
    }

    function NO(OO) {
      if (0 === OO) return !0;
      const KO = CO.l[OO];
      return void 0 === KO || KO.Lp || KO.transTex || !1 === KO.solid
    }

    function IO(OO) {
      let KO = 1 / 0,
        pO = -1 / 0,
        XO = 1 / 0,
        bK = -1 / 0;
      for (const {
          chunkX: FO,
          chunkZ: VO,
          heights: LO
        }
        of OO) LO.forEach(((OO, eO) => {
        if (OO === fO) return;
        const lO = FO * AO + eO % AO,
          vK = VO * AO + Math.floor(eO / AO);
        KO = Math.min(KO, lO), pO = Math.max(pO, lO), XO = Math.min(XO, vK), bK = Math.max(bK, vK)
      }));
      const eO = pO - KO + 1,
        lO = bK - XO + 1,
        vK = Math.max(1, Math.ceil(eO / zK), Math.ceil(lO / zK)),
        CO = Math.ceil(eO / vK),
        hO = Math.ceil(lO / vK),
        DO = document.createElement("canvas");
      DO.width = CO, DO.height = hO;
      const MO = DO.getContext("2d");
      if (!MO) throw new Error("Couldn't draw the schematic from above.");
      const aK = MO.createImageData(CO, hO),
        oO = new Int32Array(CO * hO).fill(fO);
      for (const {
          chunkX: FO,
          chunkZ: VO,
          heights: LO,
          colours: QO
        }
        of OO) LO.forEach(((OO, KO) => {
        const bK = FO * AO + KO % AO,
          eO = VO * AO + Math.floor(KO / AO),
          lO = Math.floor((eO - XO) / vK) * CO + Math.floor((pO - bK) / vK);
        OO === fO || OO <= oO[lO] || (oO[lO] = OO, aK.data.set(QO.subarray(3 * KO, 3 * KO + 3), 4 * lO), aK.data[4 * lO + 3] = 255)
      }));
      return MO.putImageData(aK, 0, 0), {
        maxX: pO,
        minZ: XO,
        width: CO * vK,
        depth: hO * vK,
        canvas: DO
      }
    }

    function yK() {
      return new Promise((OO => {
        setTimeout(OO, 0)
      }))
    }
  },
  8461: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => eO
    });
    var XO = pO(8411);
    const bK = "Air",
      eO = Object.freeze(new XO.f(bK, 0, "", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null))
  },
  36111: (OO, KO, pO) => {
    var XO = pO(36117);

    function bK(OO) {
      for (var KO, pO, bK = 0, eO = OO.length, lO = 0; lO < OO.length;) {
        for (KO = OO[lO], pO = 0; lO < eO && OO[lO] === KO;) ++lO, ++pO;
        bK += XO.log2(pO) / 7 | 0, bK += XO.log2(KO >>> 0) / 7 | 0, bK += 2
      }
      return bK
    }
    KO.size = bK, KO.encode = function(OO, KO) {
      KO || (KO = new Uint8Array(bK(OO)));
      for (var pO, XO, eO = 0, lO = KO.length, vK = 0; vK < OO.length;) {
        for (pO = OO[vK], XO = 0; vK < OO.length && OO[vK] === pO;) ++vK, ++XO;
        for (; eO < lO && XO >= 128;) KO[eO++] = 128 + (127 & XO), XO >>>= 7;
        if (eO >= lO) throw new Error("RLE buffer overflow");
        for (KO[eO++] = XO, pO >>>= 0; eO < lO && pO >= 128;) KO[eO++] = 128 + (127 & pO), pO >>>= 7;
        if (eO >= lO) throw new Error("RLE buffer overflow");
        KO[eO++] = pO
      }
      return KO
    }, KO.decode = function(OO, KO) {
      for (var pO, XO, bK, eO, lO = KO.length, vK = OO.length, CO = 0, hO = 0; hO < vK;) {
        for (pO = 0, XO = 0; hO < vK && OO[hO] >= 128;) pO += (127 & OO[hO++]) << XO, XO += 7;
        if (pO += OO[hO++] << XO, hO >= vK) throw new Error("RLE buffer underrun");
        if (CO + pO > lO) throw new Error("Chunk buffer overflow");
        for (bK = 0, XO = 0; hO < vK && OO[hO] >= 128;) bK += (127 & OO[hO++]) << XO, XO += 7;
        if (hO >= vK) throw new Error("RLE buffer underrun");
        for (bK += OO[hO++] << XO, eO = 0; eO < pO; ++eO) KO[CO++] = bK
      }
      return KO
    }
  },
  36117: (OO, KO) => {
    function pO(OO) {
      var KO = 32;
      return (OO &= -OO) && KO--, 65535 & OO && (KO -= 16), 16711935 & OO && (KO -= 8), 252645135 & OO && (KO -= 4), 858993459 & OO && (KO -= 2), 1431655765 & OO && (KO -= 1), KO
    }
    KO.INT_BITS = 32, KO.INT_MAX = 2147483647, KO.INT_MIN = -1 << 31, KO.sign = function(OO) {
      return (OO > 0) - (OO < 0)
    }, KO.abs = function(OO) {
      var KO = OO >> 31;
      return (OO ^ KO) - KO
    }, KO.min = function(OO, KO) {
      return KO ^ (OO ^ KO) & -(OO < KO)
    }, KO.max = function(OO, KO) {
      return OO ^ (OO ^ KO) & -(OO < KO)
    }, KO.isPow2 = function(OO) {
      return !(OO & OO - 1) && !!OO
    }, KO.log2 = function(OO) {
      var KO, pO;
      return KO = (OO > 65535) << 4, KO |= pO = ((OO >>>= KO) > 255) << 3, KO |= pO = ((OO >>>= pO) > 15) << 2, (KO |= pO = ((OO >>>= pO) > 3) << 1) | (OO >>>= pO) >> 1
    }, KO.log10 = function(OO) {
      return OO >= 1e9 ? 9 : OO >= 1e8 ? 8 : OO >= 1e7 ? 7 : OO >= 1e6 ? 6 : OO >= 1e5 ? 5 : OO >= 1e4 ? 4 : OO >= 1e3 ? 3 : OO >= 100 ? 2 : OO >= 10 ? 1 : 0
    }, KO.popCount = function(OO) {
      return 16843009 * ((OO = (858993459 & (OO -= OO >>> 1 & 1431655765)) + (OO >>> 2 & 858993459)) + (OO >>> 4) & 252645135) >>> 24
    }, KO.countTrailingZeros = pO, KO.nextPow2 = function(OO) {
      return OO += 0 === OO, --OO, OO |= OO >>> 1, OO |= OO >>> 2, OO |= OO >>> 4, OO |= OO >>> 8, (OO |= OO >>> 16) + 1
    }, KO.prevPow2 = function(OO) {
      return OO |= OO >>> 1, OO |= OO >>> 2, OO |= OO >>> 4, OO |= OO >>> 8, (OO |= OO >>> 16) - (OO >>> 1)
    }, KO.parity = function(OO) {
      return OO ^= OO >>> 16, OO ^= OO >>> 8, OO ^= OO >>> 4, 27030 >>> (OO &= 15) & 1
    };
    var XO = new Array(256);
    ! function(OO) {
      for (var KO = 0; KO < 256; ++KO) {
        var pO = KO,
          XO = KO,
          bK = 7;
        for (pO >>>= 1; pO; pO >>>= 1) XO <<= 1, XO |= 1 & pO, --bK;
        OO[KO] = XO << bK & 255
      }
    }(XO), KO.reverse = function(OO) {
      return XO[255 & OO] << 24 | XO[OO >>> 8 & 255] << 16 | XO[OO >>> 16 & 255] << 8 | XO[OO >>> 24 & 255]
    }, KO.interleave2 = function(OO, KO) {
      return (OO = 1431655765 & ((OO = 858993459 & ((OO = 252645135 & ((OO = 16711935 & ((OO &= 65535) | OO << 8)) | OO << 4)) | OO << 2)) | OO << 1)) | (KO = 1431655765 & ((KO = 858993459 & ((KO = 252645135 & ((KO = 16711935 & ((KO &= 65535) | KO << 8)) | KO << 4)) | KO << 2)) | KO << 1)) << 1
    }, KO.deinterleave2 = function(OO, KO) {
      return (OO = 65535 & ((OO = 16711935 & ((OO = 252645135 & ((OO = 858993459 & ((OO = OO >>> KO & 1431655765) | OO >>> 1)) | OO >>> 2)) | OO >>> 4)) | OO >>> 16)) << 16 >> 16
    }, KO.interleave3 = function(OO, KO, pO) {
      return OO = 1227133513 & ((OO = 3272356035 & ((OO = 251719695 & ((OO = 4278190335 & ((OO &= 1023) | OO << 16)) | OO << 8)) | OO << 4)) | OO << 2), (OO |= (KO = 1227133513 & ((KO = 3272356035 & ((KO = 251719695 & ((KO = 4278190335 & ((KO &= 1023) | KO << 16)) | KO << 8)) | KO << 4)) | KO << 2)) << 1) | (pO = 1227133513 & ((pO = 3272356035 & ((pO = 251719695 & ((pO = 4278190335 & ((pO &= 1023) | pO << 16)) | pO << 8)) | pO << 4)) | pO << 2)) << 2
    }, KO.deinterleave3 = function(OO, KO) {
      return (OO = 1023 & ((OO = 4278190335 & ((OO = 251719695 & ((OO = 3272356035 & ((OO = OO >>> KO & 1227133513) | OO >>> 2)) | OO >>> 4)) | OO >>> 8)) | OO >>> 16)) << 22 >> 22
    }, KO.nextCombination = function(OO) {
      var KO = OO | OO - 1;
      return KO + 1 | (~KO & -~KO) - 1 >>> pO(OO) + 1
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);