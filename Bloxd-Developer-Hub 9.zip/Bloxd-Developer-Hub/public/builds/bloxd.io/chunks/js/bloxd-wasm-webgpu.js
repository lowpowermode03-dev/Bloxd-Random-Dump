export const id = 8;
export const ids = [8];
export const modules = {
  41272: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_webgpu_bg.ad9b686eb33cc0862714.wasm"
  },
  41268: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      bloxdWasmWebgpu: () => ep
    });
    var XO = {};
    pO.r(XO), pO.d(XO, {
      Gl: () => bK,
      kaO: () => eO,
      Renderer: () => lO,
      aK: () => vK,
      default: () => bX,
      initSync: () => Xp,
      oO: () => CO,
      UMO: () => hO,
      FO: () => DO,
      VO: () => MO,
      LO: () => aK,
      QO: () => oO,
      zK: () => FO,
      fO: () => VO,
      dO: () => LO,
      OaO: () => QO,
      yK: () => zK,
      KaO: () => AO,
      paO: () => fO,
      taO: () => dO,
      XaO: () => TO,
      boO: () => NO,
      eaO: () => IO,
      laO: () => yK,
      voO: () => gK,
      uO: () => uO,
      EO: () => EO
    });
    class bK {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, FK.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        Op.ewr4(OO, 0)
      }
      static CaO() {
        return Op.RksK() >>> 0
      }
      haO() {
        return Op.tBw4(this.__wbg_ptr)
      }
      KMO() {
        return Op.BRdR(this.__wbg_ptr) >>> 0
      }
      MaO(OO, KO, pO) {
        return Op.l5Ci(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      sK(OO, KO, pO) {
        return Op.HPV7(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      aoO() {
        return Op.JjEy(this.__wbg_ptr) >>> 0
      }
      XMO(OO, KO, pO, XO, bK, eO, lO) {
        return Op.jmrg(this.__wbg_ptr, OO, KO, pO, XO, bK, eO, lO)
      }
      oaO(OO, KO, pO) {
        return Op.dERn(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      FaO() {
        return Op.Fc2x(this.__wbg_ptr) >>> 0
      }
      VaO() {
        return Op.d610(this.__wbg_ptr) >>> 0
      }
      QaO() {
        return Op.FFmZ(this.__wbg_ptr) >>> 0
      }
      craft(OO, KO, pO) {
        return Op.ksNP(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      hMO(OO, KO, pO) {
        return Op.DLa8(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      baO() {
        return Op.YPLm(this.__wbg_ptr) >>> 0
      }
      eMO(OO) {
        return Op.Pfma(this.__wbg_ptr, OO) >>> 0
      }
      lMO(OO, KO, pO, XO, bK, eO) {
        return Op.gRWj(this.__wbg_ptr, OO, KO, pO, XO, bK, eO) >>> 0
      }
      pMO() {
        return Op.yMG9(this.__wbg_ptr) >>> 0
      }
      zoO() {
        return Op.QK5i(this.__wbg_ptr) >>> 0
      }
      AaO(OO) {
        return Op.O3rN(this.__wbg_ptr, OO) >>> 0
      }
      MMO(OO) {
        return Op.tJAu(this.__wbg_ptr, OO) >>> 0
      }
      daO(OO) {
        return Op.DOQH(this.__wbg_ptr, OO) >>> 0
      }
      TaO(OO) {
        return Op.VcjW(this.__wbg_ptr, OO) >>> 0
      }
      frame(OO, KO, pO, XO, bK, eO) {
        return Op.VeC8(this.__wbg_ptr, OO, KO, pO, XO, bK, eO) >>> 0
      }
      IaO(OO) {
        return 0 !== Op.z1xG(this.__wbg_ptr, OO)
      }
      yoO(OO, KO) {
        return Op.D9pG(this.__wbg_ptr, OO, KO) >>> 0
      }
      goO(OO) {
        return Op.iJMi(this.__wbg_ptr, OO) >>> 0
      }
      yX() {
        return Op.LTXH(this.__wbg_ptr) >>> 0
      }
      uaO() {
        return Op.p2pe(this.__wbg_ptr) >>> 0
      }
      ZO() {
        return Op.fA8y(this.__wbg_ptr) >>> 0
      }
      EaO(OO, KO, pO, XO, bK) {
        return Op.mNiN(this.__wbg_ptr, OO, KO, pO, XO, bK) >>> 0
      }
      joO(OO, KO, pO) {
        return Op.peei(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      YaO(OO, KO, pO, XO) {
        return Op.pBX1(this.__wbg_ptr, OO, KO, pO, XO) >>> 0
      }
      waO(OO, KO, pO) {
        return Op.VR6E(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      ioO(OO, KO) {
        return Op.kBgr(this.__wbg_ptr, OO, KO) >>> 0
      }
      DMO(OO) {
        return Op.IfwN(this.__wbg_ptr, OO) >>> 0
      }
      FE() {
        return Op.QHhs(this.__wbg_ptr) >>> 0
      }
      roO() {
        return Op.VG7c(this.__wbg_ptr) >>> 0
      }
      PaO() {
        return Op.X9hD(this.__wbg_ptr) >>> 0
      }
      moO() {
        return Op.TcWj(this.__wbg_ptr) >>> 0
      }
      constructor(OO, KO) {
        const pO = Op.qlNP(OO, KO);
        return this.__wbg_ptr = pO, FK.register(this, this.__wbg_ptr, this), this
      }
      saO(OO) {
        return Op.qqg0(this.__wbg_ptr, OO) >>> 0
      }
      Ul() {
        return Op.Ddj6(this.__wbg_ptr) >>> 0
      }
      EMO(OO, KO) {
        return Op.kEKC(this.__wbg_ptr, OO, KO) >>> 0
      }
      NMO(OO) {
        return Op.G4Lk(this.__wbg_ptr, OO) >>> 0
      }
      HaO(OO, KO, pO, XO) {
        return Op.AcR5(this.__wbg_ptr, OO, KO, pO, XO) >>> 0
      }
      iaO(OO) {
        return Op.JAvp(this.__wbg_ptr, OO) >>> 0
      }
      LMO() {
        Op.hHPY(this.__wbg_ptr)
      }
      sMO(OO) {
        Op.llR9(this.__wbg_ptr, OO)
      }
      maO(OO) {
        return Op.zGPX(this.__wbg_ptr, OO)
      }
      VMO() {
        return Op.VzEy(this.__wbg_ptr) >>> 0
      }
      qv() {
        return Op.rKS7(this.__wbg_ptr) >>> 0
      }
      YMO() {
        return Op.rBiy(this.__wbg_ptr) >>> 0
      }
      LaO(OO) {
        return Op.L7wu(this.__wbg_ptr, OO) >>> 0
      }
      RaO(OO) {
        return Op.mW7a(this.__wbg_ptr, OO) >>> 0
      }
      SaO(OO) {
        return Op.b0vO(this.__wbg_ptr, OO) >>> 0
      }
      JaO(OO) {
        return Op.TvJv(this.__wbg_ptr, OO) >>> 0
      }
      salvage(OO, KO, pO) {
        return Op.us3l(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      oMO(OO) {
        return Op.bOll(this.__wbg_ptr, OO) >>> 0
      }
      OMO() {
        return Op.Hlqv(this.__wbg_ptr) >>> 0
      }
      coO(OO) {
        return Op.TUoF(this.__wbg_ptr, OO) >>> 0
      }
      BaO(OO) {
        Op.JoJh(this.__wbg_ptr, OO)
      }
      ZaO(OO) {
        return 0 !== Op.RrBN(this.__wbg_ptr, QK(OO))
      }
      Cp(OO, KO, pO, XO) {
        return Op.rfu7(this.__wbg_ptr, OO, KO, pO, XO) >>> 0
      }
      qoO(OO, KO, pO) {
        const XO = GK(OO, Op.F2gY, Op.HaBM),
          bK = Kp,
          eO = cp(KO, Op.F2gY),
          lO = Kp,
          vK = function(OO, KO) {
            const pO = KO(8 * OO.length, 8) >>> 0;
            return jp().set(OO, pO / 8), Kp = OO.length, pO
          }(pO, Op.F2gY),
          CO = Kp;
        return 0 !== Op.djnV(this.__wbg_ptr, XO, bK, eO, lO, vK, CO)
      }
      xoO(OO) {
        Op.wTzT(this.__wbg_ptr, OO)
      }
      naO(OO, KO) {
        return 0 !== Op.cF3Q(this.__wbg_ptr, OO, KO)
      }
      WaO(OO) {
        return Op.h6uQ(this.__wbg_ptr, OO) >>> 0
      }
      NaO(OO) {
        Op.YIki(this.__wbg_ptr, QK(OO))
      }
      toO(OO) {
        Op.LAbK(this.__wbg_ptr, OO)
      }
      koO(OO) {
        Op.cES4(this.__wbg_ptr, OO)
      }
      CMO(OO, KO, pO) {
        return Op.py3f(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      FMO(OO) {
        return Op.iwkK(this.__wbg_ptr, OO) >>> 0
      }
      UaO(OO) {
        Op.TnGM(this.__wbg_ptr, OO)
      }
      OoO(OO) {
        zp(OO, lO);
        var KO = OO.__destroy_into_raw();
        Op.SoSZ(this.__wbg_ptr, KO)
      }
      GDO(OO, KO, pO, XO, bK, eO) {
        var lO = SK(OO) ? 0 : BK(OO, Op.F2gY),
          vK = Kp;
        const CO = BK(KO, Op.F2gY),
          hO = Kp,
          DO = ZK(pO, Op.F2gY),
          MO = Kp,
          aK = cp(XO, Op.F2gY),
          oO = Kp;
        return 0 !== Op.KolW(this.__wbg_ptr, lO, vK, CO, hO, DO, MO, aK, oO, bK, eO)
      }
      poO(OO, KO, pO, XO, bK) {
        var eO = SK(bK) ? 0 : BK(bK, Op.F2gY),
          lO = Kp;
        Op.FLFj(this.__wbg_ptr, OO, KO, pO, XO, eO, lO)
      }
      XoO(OO, KO, pO) {
        const XO = ZK(OO, Op.F2gY),
          bK = Kp,
          eO = cp(KO, Op.F2gY),
          lO = Kp,
          vK = ZK(pO, Op.F2gY),
          CO = Kp;
        return 0 !== Op.Rg1F(this.__wbg_ptr, XO, bK, eO, lO, vK, CO)
      }
      bFO(OO) {
        const KO = GK(OO, Op.F2gY, Op.HaBM),
          pO = Kp;
        return 0 !== Op.BGcU(this.__wbg_ptr, KO, pO)
      }
      eoO(OO) {
        return Op.WFZt(this.__wbg_ptr, OO) >>> 0
      }
      loK() {
        return Op.JFnm(this.__wbg_ptr) >>> 0
      }
      vFO() {
        const OO = Op.KWb9(this.__wbg_ptr);
        var KO = IK(OO[0], OO[1]).slice();
        return Op.sojV(OO[0], 4 * OO[1], 4), KO
      }
      hoO() {
        const OO = Op.hv0e(this.__wbg_ptr);
        var KO = dK(OO[0], OO[1]).slice();
        return Op.sojV(OO[0], 8 * OO[1], 8), KO
      }
      DoO() {
        const OO = Op.CS9u(this.__wbg_ptr);
        var KO = TK(OO[0], OO[1]);
        return Op.sojV(OO[0], 4 * OO[1], 4), KO
      }
      MoO(OO, KO, pO, XO, bK) {
        return Op.rBWB(this.__wbg_ptr, OO, KO, pO, XO, bK) >>> 0
      }
      aFO() {
        const OO = Op.ZK2Z(this.__wbg_ptr);
        var KO = TK(OO[0], OO[1]);
        return Op.sojV(OO[0], 4 * OO[1], 4), KO
      }
      ooO() {
        return Op.cWF4(this.__wbg_ptr) >>> 0
      }
      VoO() {
        return Op.nvzm(this.__wbg_ptr) >>> 0
      }
    }
    Symbol.dispose && (bK.prototype[Symbol.dispose] = bK.prototype.free);
    class eO {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, VK.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        Op.oLNN(OO, 0)
      }
      attach(OO) {
        zp(OO, bK);
        return 0 !== Op.Mreo(this.__wbg_ptr, OO.__wbg_ptr)
      }
      attached() {
        return 0 !== Op.T172(this.__wbg_ptr)
      }
      close(OO) {
        const KO = Op.s6OI(this.__wbg_ptr, OO);
        var pO = yp(KO[0], KO[1]).slice();
        return Op.sojV(KO[0], 1 * KO[1], 1), pO
      }
      detach() {
        Op.pvYC(this.__wbg_ptr)
      }
      LoO() {
        return Op.xVpD(this.__wbg_ptr) >>> 0
      }
      QoO() {
        return Op.RN88(this.__wbg_ptr) >>> 0
      }
      frame(OO) {
        return Op.rNtm(this.__wbg_ptr, OO) >>> 0
      }
      zFO(OO, KO, pO, XO) {
        const bK = BK(XO, Op.F2gY),
          eO = Kp;
        return Op.q16A(this.__wbg_ptr, OO, KO, pO, bK, eO)
      }
      AoO() {
        return 0 !== Op.h8Lp(this.__wbg_ptr)
      }
      foO(OO, KO) {
        const pO = BK(KO, Op.F2gY),
          XO = Kp;
        Op.XQrA(this.__wbg_ptr, OO, pO, XO)
      }
      constructor() {
        const OO = Op.u2GT();
        return this.__wbg_ptr = OO, VK.register(this, this.__wbg_ptr, this), this
      }
      open(OO, KO, pO, XO) {
        return 0 !== Op.puA3(this.__wbg_ptr, OO, KO, pO, XO)
      }
      orbit(OO) {
        const KO = Op.r1Ep(this.__wbg_ptr, OO);
        var pO = dK(KO[0], KO[1]).slice();
        return Op.sojV(KO[0], 8 * KO[1], 8), pO
      }
      replay(OO) {
        return Op.YLh1(this.__wbg_ptr, OO) >>> 0
      }
      resize(OO, KO, pO) {
        Op.o7Fx(this.__wbg_ptr, OO, KO, pO)
      }
      doO(OO) {
        const KO = BK(OO, Op.F2gY),
          pO = Kp;
        return 0 !== Op.XM08(this.__wbg_ptr, KO, pO)
      }
      NoO(OO, KO, pO, XO, bK) {
        const eO = GK(KO, Op.F2gY, Op.HaBM),
          lO = Kp;
        return Op.peTC(this.__wbg_ptr, OO, eO, lO, pO, XO, bK) >>> 0
      }
      IoO(OO) {
        Op.bEK7(this.__wbg_ptr, OO)
      }
      yFO(OO, KO, pO, XO, bK) {
        const eO = GK(pO, Op.F2gY, Op.HaBM),
          lO = Kp;
        return Op.IeJP(this.__wbg_ptr, OO, KO, eO, lO, XO, bK) >>> 0
      }
      gFO(OO, KO, pO, XO) {
        Op.cQu5(this.__wbg_ptr, OO, KO, pO, XO)
      }
      uoO(OO, KO, pO, XO, bK) {
        const eO = GK(pO, Op.F2gY, Op.HaBM),
          lO = Kp,
          vK = GK(XO, Op.F2gY, Op.HaBM),
          CO = Kp;
        return Op.brLS(this.__wbg_ptr, OO, KO, eO, lO, vK, CO, bK) >>> 0
      }
      ToO(OO, KO, pO, XO) {
        const bK = GK(KO, Op.F2gY, Op.HaBM),
          eO = Kp,
          lO = cp(pO, Op.F2gY),
          vK = Kp;
        return Op.Gsup(this.__wbg_ptr, OO, bK, eO, lO, vK, XO) >>> 0
      }
      OoO(OO) {
        zp(OO, lO);
        var KO = OO.__destroy_into_raw();
        return 0 !== Op.Ydjd(this.__wbg_ptr, KO)
      }
      GDO(OO, KO, pO, XO, bK) {
        var eO = SK(OO) ? 0 : BK(OO, Op.F2gY),
          lO = Kp;
        const vK = BK(KO, Op.F2gY),
          CO = Kp,
          hO = ZK(pO, Op.F2gY),
          DO = Kp,
          MO = cp(XO, Op.F2gY),
          aK = Kp;
        return 0 !== Op.tkzE(this.__wbg_ptr, eO, lO, vK, CO, hO, DO, MO, aK, bK)
      }
      jFO() {
        const OO = Op.Neb0(this.__wbg_ptr);
        var KO = IK(OO[0], OO[1]).slice();
        return Op.sojV(OO[0], 4 * OO[1], 4), KO
      }
      YoO(OO) {
        const KO = Op.Tdpl(this.__wbg_ptr, OO);
        var pO = yp(KO[0], KO[1]).slice();
        return Op.sojV(KO[0], 1 * KO[1], 1), pO
      }
      woO(OO) {
        const KO = Op.wL7q(this.__wbg_ptr, OO);
        var pO = IK(KO[0], KO[1]).slice();
        return Op.sojV(KO[0], 4 * KO[1], 4), pO
      }
    }
    Symbol.dispose && (eO.prototype[Symbol.dispose] = eO.prototype.free);
    class lO {
      static __wrap(OO) {
        const KO = Object.create(lO.prototype);
        return KO.__wbg_ptr = OO, LK.register(KO, KO.__wbg_ptr, KO), KO
      }
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, LK.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        Op.NqJy(OO, 0)
      }
    }

    function vK(OO, KO) {
      const pO = GK(OO, Op.F2gY, Op.HaBM),
        XO = Kp,
        bK = Op.kyY9(pO, XO, KO);
      if (bK[1]) throw qp(bK[0])
    }

    function CO() {
      Op.SkGO()
    }

    function hO() {
      return Op.Z2QD()
    }

    function DO() {
      return Op.bQyN() >>> 0
    }

    function MO(OO) {
      return 0 !== Op.UtwB(OO)
    }

    function aK(OO) {
      return 0 !== Op.NPp5(OO)
    }

    function oO(OO) {
      Op.bZ1y(OO)
    }

    function FO() {
      return Op.n5w9() >>> 0
    }

    function VO() {
      return Op.tbQk() >>> 0
    }

    function LO() {
      return 0 !== Op.LHfW()
    }

    function QO(OO, KO, pO, XO, bK) {
      return qp(Op.iPrp(QK(OO), KO, QK(pO), XO, SK(bK) ? Number.MAX_SAFE_INTEGER : bK >>> 0))
    }

    function zK() {
      return Op.kxHO() >>> 0
    }

    function AO(OO, KO) {
      Op.Kgfm(OO, QK(KO))
    }

    function fO(OO, KO) {
      Op.TJVI(OO, QK(KO))
    }

    function dO(OO) {
      Op.ssTU(OO)
    }

    function TO(OO) {
      Op.uvt2(OO)
    }

    function NO(OO) {
      const KO = BK(OO, Op.F2gY),
        pO = Kp;
      return 0 !== Op.K72d(KO, pO)
    }

    function IO(OO) {
      var KO = SK(OO) ? 0 : BK(OO, Op.F2gY),
        pO = Kp;
      const XO = Op.NExw(KO, pO);
      let bK;
      return 0 !== XO[0] && (bK = TK(XO[0], XO[1]), Op.sojV(XO[0], 4 * XO[1], 4)), bK
    }

    function yK() {
      const OO = Op.e3np();
      let KO;
      return 0 !== OO[0] && (KO = YK(OO[0], OO[1]), Op.sojV(OO[0], 1 * OO[1], 1)), KO
    }

    function gK(OO, KO) {
      const pO = Op.GGBh(OO, KO);
      let XO;
      return 0 !== pO[0] && (XO = YK(pO[0], pO[1]), Op.sojV(pO[0], 1 * pO[1], 1)), XO
    }

    function uO() {
      let OO, KO;
      try {
        const pO = Op.t1lT();
        return OO = pO[0], KO = pO[1], YK(pO[0], pO[1])
      } finally {
        Op.sojV(OO, KO, 1)
      }
    }

    function EO(OO) {
      Op.zb6g(QK(OO))
    }

    function jK() {
      const OO = {
        __proto__: null,
        mhgr: function(OO, KO) {
          return QK(Error(YK(OO, KO)))
        },
        STcP: function(OO) {
          return QK(mp(OO).Window)
        },
        rnAy: function(OO) {
          return QK(mp(OO).WorkerGlobalScope)
        },
        AslE: function(OO, KO) {
          const pO = GK(fK(mp(KO)), Op.F2gY, Op.HaBM),
            XO = Kp;
          uK().setInt32(OO + 4, XO, !0), uK().setInt32(OO + 0, pO, !0)
        },
        Pk3s: function(OO) {
          return "function" === typeof mp(OO)
        },
        YybD: function(OO) {
          return null === mp(OO)
        },
        vxVQ: function(OO) {
          const KO = mp(OO);
          return "object" === typeof KO && null !== KO
        },
        cjdk: function(OO) {
          return "string" === typeof mp(OO)
        },
        rsTH: function(OO) {
          return void 0 === mp(OO)
        },
        lf3v: function(OO, KO) {
          const pO = mp(KO),
            XO = "number" === typeof pO ? pO : void 0;
          uK().setFloat64(OO + 8, SK(XO) ? 0 : XO, !0), uK().setInt32(OO + 0, !SK(XO), !0)
        },
        gmrJ: function(OO) {
          throw qp(OO)
        },
        wKvO: function(OO, KO) {
          const pO = mp(KO),
            XO = "string" === typeof pO ? pO : void 0;
          var bK = SK(XO) ? 0 : GK(XO, Op.F2gY, Op.HaBM),
            eO = Kp;
          uK().setInt32(OO + 4, eO, !0), uK().setInt32(OO + 0, bK, !0)
        },
        lD3n: function(OO, KO) {
          throw new Error(YK(OO, KO))
        },
        Nf1q: function(OO) {
          mp(OO)._wbg_cb_unref()
        },
        EhZv: function(OO, KO) {
          return QK(mp(OO).beginComputePass(mp(KO)))
        },
        OzKX: function() {
          return sK((function(OO, KO) {
            return QK(mp(OO).beginRenderPass(mp(KO)))
          }), arguments)
        },
        v5G8: function() {
          return sK((function(OO, KO, pO, XO, bK, eO) {
            return QK(mp(OO).call(mp(KO), mp(pO), mp(XO), mp(bK), mp(eO)))
          }), arguments)
        },
        WjqA: function() {
          return sK((function(OO, KO, pO) {
            return QK(mp(OO).call(mp(KO), mp(pO)))
          }), arguments)
        },
        tV2U: function(OO) {
          mp(OO).call()
        },
        klJN: function() {
          return sK((function(OO, KO) {
            mp(OO).configure(mp(KO))
          }), arguments)
        },
        P2b1: function() {
          return sK((function(OO, KO, pO, XO, bK, eO) {
            mp(OO).copyBufferToBuffer(mp(KO), pO, mp(XO), bK, eO)
          }), arguments)
        },
        sOb7: function() {
          return sK((function(OO, KO, pO, XO) {
            mp(OO).copyExternalImageToTexture(mp(KO), mp(pO), mp(XO))
          }), arguments)
        },
        UJF1: function() {
          return sK((function(OO, KO, pO, XO) {
            mp(OO).copyTextureToTexture(mp(KO), mp(pO), mp(XO))
          }), arguments)
        },
        ldRY: function() {
          return sK((function(OO, KO) {
            return QK(mp(OO).createBindGroupLayout(mp(KO)))
          }), arguments)
        },
        PagJ: function(OO, KO) {
          return QK(mp(OO).createBindGroup(mp(KO)))
        },
        RBn6: function() {
          return sK((function(OO, KO) {
            return QK(mp(OO).createBuffer(mp(KO)))
          }), arguments)
        },
        H7CM: function(OO, KO) {
          return QK(mp(OO).createCommandEncoder(mp(KO)))
        },
        lFx8: function(OO, KO) {
          return QK(mp(OO).createComputePipeline(mp(KO)))
        },
        Pmdy: function() {
          return sK((function(OO, KO, pO) {
            return QK(mp(OO).createElement(YK(KO, pO)))
          }), arguments)
        },
        ZiKY: function(OO, KO) {
          return QK(mp(OO).createPipelineLayout(mp(KO)))
        },
        ZOZw: function() {
          return sK((function(OO, KO) {
            return QK(mp(OO).createQuerySet(mp(KO)))
          }), arguments)
        },
        OBXO: function() {
          return sK((function(OO, KO) {
            return QK(mp(OO).createRenderBundleEncoder(mp(KO)))
          }), arguments)
        },
        WODV: function() {
          return sK((function(OO, KO) {
            return QK(mp(OO).createRenderPipeline(mp(KO)))
          }), arguments)
        },
        ypWm: function(OO, KO) {
          return QK(mp(OO).createSampler(mp(KO)))
        },
        px4O: function(OO, KO) {
          return QK(mp(OO).createShaderModule(mp(KO)))
        },
        np8C: function() {
          return sK((function(OO, KO) {
            return QK(mp(OO).createTexture(mp(KO)))
          }), arguments)
        },
        Dxne: function() {
          return sK((function(OO, KO) {
            return QK(mp(OO).createView(mp(KO)))
          }), arguments)
        },
        QcxN: function() {
          return sK((function(OO, KO) {
            return Reflect.deleteProperty(mp(OO), mp(KO))
          }), arguments)
        },
        p4it: function(OO, KO) {
          const pO = GK(mp(KO).description, Op.F2gY, Op.HaBM),
            XO = Kp;
          uK().setInt32(OO + 4, XO, !0), uK().setInt32(OO + 0, pO, !0)
        },
        BVHM: function(OO) {
          mp(OO).destroy()
        },
        K5Pl: function(OO) {
          mp(OO).destroy()
        },
        vnUp: function(OO, KO, pO, XO) {
          mp(OO).dispatchWorkgroups(KO >>> 0, pO >>> 0, XO >>> 0)
        },
        jVtn: function(OO) {
          const KO = mp(OO).document;
          return SK(KO) ? 0 : QK(KO)
        },
        Wi1w: function(OO, KO, pO) {
          mp(OO).drawIndexedIndirect(mp(KO), pO)
        },
        YkIp: function(OO, KO, pO, XO, bK, eO) {
          mp(OO).drawIndexed(KO >>> 0, pO >>> 0, XO >>> 0, bK, eO >>> 0)
        },
        Knkm: function(OO, KO, pO, XO, bK) {
          mp(OO).draw(KO >>> 0, pO >>> 0, XO >>> 0, bK >>> 0)
        },
        I4J5: function(OO) {
          mp(OO).end()
        },
        WC24: function(OO) {
          mp(OO).end()
        },
        aJOI: function(OO, KO) {
          console.error(YK(OO, KO))
        },
        vdb6: function(OO, KO, pO) {
          mp(OO).executeBundles(NK(KO, pO))
        },
        vzOb: function(OO) {
          return QK(mp(OO).features)
        },
        SFBr: function(OO) {
          return QK(mp(OO).features)
        },
        l9an: function(OO) {
          return QK(mp(OO).finish())
        },
        B0hy: function(OO) {
          return QK(mp(OO).finish())
        },
        W4SF: function(OO, KO) {
          return QK(mp(OO).finish(mp(KO)))
        },
        oioX: function() {
          return sK((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            return mp(OO).gameCall(KO >>> 0, pO, XO, bK, eO, lO, vK, CO, hO)
          }), arguments)
        },
        xlYG: function() {
          return sK((function(OO, KO, pO, XO) {
            const bK = mp(OO).getContext(YK(KO, pO), mp(XO));
            return SK(bK) ? 0 : QK(bK)
          }), arguments)
        },
        JdZo: function() {
          return sK((function(OO, KO, pO, XO) {
            const bK = mp(OO).getContext(YK(KO, pO), mp(XO));
            return SK(bK) ? 0 : QK(bK)
          }), arguments)
        },
        YlAw: function() {
          return sK((function(OO, KO, pO) {
            const XO = mp(OO).getContext(YK(KO, pO));
            return SK(XO) ? 0 : QK(XO)
          }), arguments)
        },
        HG3Z: function() {
          return sK((function(OO, KO, pO) {
            const XO = mp(OO).getContext(YK(KO, pO));
            return SK(XO) ? 0 : QK(XO)
          }), arguments)
        },
        noPL: function() {
          return sK((function(OO) {
            return QK(mp(OO).getCurrentTexture())
          }), arguments)
        },
        ROcv: function() {
          return sK((function(OO, KO, pO) {
            return QK(mp(OO).getMappedRange(KO, pO))
          }), arguments)
        },
        XCti: function(OO) {
          const KO = mp(OO).getPreferredCanvasFormat();
          return (hK.indexOf(KO) + 1 || 102) - 1
        },
        tWul: function() {
          return sK((function(OO, KO) {
            return QK(Reflect.get(mp(OO), mp(KO)))
          }), arguments)
        },
        FWTV: function(OO, KO) {
          return QK(mp(OO)[KO >>> 0])
        },
        LFCk: function(OO, KO, pO, XO) {
          const bK = mp(KO).get(YK(pO, XO));
          var eO = SK(bK) ? 0 : GK(bK, Op.F2gY, Op.HaBM),
            lO = Kp;
          uK().setInt32(OO + 4, lO, !0), uK().setInt32(OO + 0, eO, !0)
        },
        wrab: function(OO) {
          return QK(mp(OO).gpu)
        },
        vTkM: function(OO, KO, pO) {
          return mp(OO).has(YK(KO, pO))
        },
        SjNr: function(OO) {
          return mp(OO).height
        },
        cUJD: function(OO) {
          console.info(mp(OO))
        },
        HFse: function(OO) {
          return QK(mp(OO).info)
        },
        U3iS: function(OO) {
          let KO;
          try {
            KO = mp(OO) instanceof Error
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        ojPP: function(OO) {
          let KO;
          try {
            KO = mp(OO) instanceof GPUOutOfMemoryError
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        k0QB: function(OO) {
          let KO;
          try {
            KO = mp(OO) instanceof GPUValidationError
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        tJ5u: function(OO) {
          let KO;
          try {
            KO = mp(OO) instanceof HTMLCanvasElement
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        UNgk: function(OO) {
          let KO;
          try {
            KO = mp(OO) instanceof ImageBitmap
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        f8BL: function(OO) {
          let KO;
          try {
            KO = mp(OO) instanceof OffscreenCanvas
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        RrRT: function(OO) {
          let KO;
          try {
            KO = mp(OO) instanceof Performance
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        D3Bi: function(OO) {
          let KO;
          try {
            KO = mp(OO) instanceof Promise
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        xBmV: function(OO) {
          let KO;
          try {
            KO = mp(OO) instanceof TypeError
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        aSUs: function(OO) {
          let KO;
          try {
            KO = mp(OO) instanceof Window
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        Cnz1: function(OO) {
          return Array.isArray(mp(OO))
        },
        bMLZ: function(OO) {
          return mp(OO).isFallbackAdapter
        },
        XAYp: function(OO, KO) {
          const pO = GK(mp(KO).label, Op.F2gY, Op.HaBM),
            XO = Kp;
          uK().setInt32(OO + 4, XO, !0), uK().setInt32(OO + 0, pO, !0)
        },
        HtJu: function(OO) {
          return mp(OO).length
        },
        oTzk: function(OO) {
          return QK(mp(OO).limits)
        },
        pqG0: function(OO) {
          return QK(mp(OO).limits)
        },
        HAER: function(OO) {
          return QK(mp(OO).location)
        },
        bx4S: function(OO) {
          return QK(mp(OO).lost)
        },
        Y61W: function(OO, KO, pO, XO) {
          return QK(mp(OO).mapAsync(KO >>> 0, pO, XO))
        },
        R6Ga: function(OO) {
          return mp(OO).maxBindGroupsPlusVertexBuffers
        },
        Bxq5: function(OO) {
          return mp(OO).maxBindGroups
        },
        ZyNe: function(OO) {
          return mp(OO).maxBindingsPerBindGroup
        },
        Exf4: function(OO) {
          return mp(OO).maxBufferSize
        },
        US16: function(OO) {
          return mp(OO).maxColorAttachmentBytesPerSample
        },
        fCkJ: function(OO) {
          return mp(OO).maxColorAttachments
        },
        puSl: function(OO) {
          return mp(OO).maxComputeInvocationsPerWorkgroup
        },
        cZT1: function(OO) {
          return mp(OO).maxComputeWorkgroupSizeX
        },
        imIa: function(OO) {
          return mp(OO).maxComputeWorkgroupSizeY
        },
        KzjU: function(OO) {
          return mp(OO).maxComputeWorkgroupSizeZ
        },
        ulDU: function(OO) {
          return mp(OO).maxComputeWorkgroupStorageSize
        },
        IfHU: function(OO) {
          return mp(OO).maxComputeWorkgroupsPerDimension
        },
        ml1R: function(OO) {
          return mp(OO).maxDynamicStorageBuffersPerPipelineLayout
        },
        nuvp: function(OO) {
          return mp(OO).maxDynamicUniformBuffersPerPipelineLayout
        },
        EKNn: function(OO) {
          return mp(OO).maxInterStageShaderVariables
        },
        KSZ0: function(OO) {
          return mp(OO).maxSampledTexturesPerShaderStage
        },
        vMsG: function(OO) {
          return mp(OO).maxSamplersPerShaderStage
        },
        gBIz: function(OO) {
          return mp(OO).maxStorageBufferBindingSize
        },
        uToM: function(OO) {
          return mp(OO).maxStorageBuffersPerShaderStage
        },
        UsAI: function(OO) {
          return mp(OO).maxStorageTexturesPerShaderStage
        },
        NNwI: function(OO) {
          return mp(OO).maxTextureArrayLayers
        },
        FEVY: function(OO) {
          return mp(OO).maxTextureDimension1D
        },
        LHPR: function(OO) {
          return mp(OO).maxTextureDimension2D
        },
        uNtw: function(OO) {
          return mp(OO).maxTextureDimension3D
        },
        mb4W: function(OO) {
          return mp(OO).maxUniformBufferBindingSize
        },
        Vjbc: function(OO) {
          return mp(OO).maxUniformBuffersPerShaderStage
        },
        Svl7: function(OO) {
          return mp(OO).maxVertexAttributes
        },
        ogBd: function(OO) {
          return mp(OO).maxVertexBufferArrayStride
        },
        DQSb: function(OO) {
          return mp(OO).maxVertexBuffers
        },
        aAfT: function(OO, KO) {
          const pO = GK(mp(KO).message, Op.F2gY, Op.HaBM),
            XO = Kp;
          uK().setInt32(OO + 4, XO, !0), uK().setInt32(OO + 0, pO, !0)
        },
        z9kE: function(OO) {
          return QK(mp(OO).message)
        },
        rYnt: function(OO, KO) {
          const pO = GK(mp(KO).message, Op.F2gY, Op.HaBM),
            XO = Kp;
          uK().setInt32(OO + 4, XO, !0), uK().setInt32(OO + 0, pO, !0)
        },
        shso: function(OO) {
          return mp(OO).minStorageBufferOffsetAlignment
        },
        i11d: function(OO) {
          return mp(OO).minUniformBufferOffsetAlignment
        },
        YFZi: function(OO) {
          return QK(mp(OO).name)
        },
        PdCA: function(OO) {
          return QK(mp(OO).navigator)
        },
        wSyZ: function(OO) {
          return QK(mp(OO).navigator)
        },
        zfzj: function(OO, KO) {
          return QK(new Error(YK(OO, KO)))
        },
        oBgf: function() {
          return QK(new Object)
        },
        r24X: function() {
          return sK((function(OO, KO) {
            return QK(new OffscreenCanvas(OO >>> 0, KO >>> 0))
          }), arguments)
        },
        JmiD: function() {
          return QK(new Array)
        },
        PXxF: function(OO, KO) {
          return QK(new Uint8Array(yp(OO, KO)))
        },
        jdlo: function() {
          return QK(new Object)
        },
        WKp0: function(OO, KO) {
          try {
            var pO = {
              a: OO,
              b: KO
            };
            const XO = new Promise(((OO, KO) => {
              const XO = pO.a;
              pO.a = 0;
              try {
                return function(OO, KO, pO, XO) {
                  Op.sn6m(OO, KO, QK(pO), QK(XO))
                }(XO, pO.b, OO, KO)
              } finally {
                pO.a = XO
              }
            }));
            return QK(XO)
          } finally {
            pO.a = 0
          }
        },
        BjTJ: function(OO, KO, pO) {
          return QK(new Uint8Array(mp(OO), KO >>> 0, pO >>> 0))
        },
        K9q0: function() {
          return sK((function(OO, KO) {
            return QK(new URLSearchParams(YK(OO, KO)))
          }), arguments)
        },
        OCzI: function() {
          return performance.now()
        },
        tf5M: function(OO) {
          return Performance.prototype.now.call(mp(OO))
        },
        k4j6: function() {
          return Date.now()
        },
        zcpm: function(OO) {
          return QK(mp(OO).onSubmittedWorkDone())
        },
        gdmx: function(OO) {
          return QK(mp(OO).popErrorScope())
        },
        GxnZ: function(OO) {
          return QK(mp(OO).popErrorScope())
        },
        T0Gv: function(OO, KO, pO, XO) {
          return mp(OO).probe(KO >>> 0, pO >>> 0, XO >>> 0)
        },
        YNWp: function(OO, KO, pO) {
          Uint8Array.prototype.set.call(yp(OO, KO), mp(pO))
        },
        Aut0: function(OO, KO, pO) {
          mp(OO).pushErrorScope(YK(KO, pO))
        },
        x4Ob: function(OO, KO) {
          mp(OO).pushErrorScope(xK[KO])
        },
        Fe2K: function(OO, KO) {
          return mp(OO).push(mp(KO))
        },
        CZIw: function(OO) {
          return QK(mp(OO).queueMicrotask)
        },
        ekDi: function(OO) {
          queueMicrotask(mp(OO))
        },
        M1k8: function(OO) {
          return QK(mp(OO).queue)
        },
        vJZg: function(OO) {
          const KO = mp(OO).reason;
          return (qK.indexOf(KO) + 1 || 3) - 1
        },
        JAQV: function(OO) {
          return QK(Promise.reject(mp(OO)))
        },
        L1re: function(OO) {
          return QK(lO.__wrap(OO))
        },
        sc4i: function(OO, KO) {
          return QK(mp(OO).requestAdapter(mp(KO)))
        },
        sfrj: function(OO) {
          return QK(mp(OO).requestAdapter())
        },
        mS2u: function(OO, KO) {
          return QK(mp(OO).requestDevice(mp(KO)))
        },
        Fb6T: function(OO, KO, pO, XO, bK, eO) {
          mp(OO).resolveQuerySet(mp(KO), pO >>> 0, XO >>> 0, mp(bK), eO >>> 0)
        },
        Dhpp: function(OO) {
          return QK(Promise.resolve(mp(OO)))
        },
        vIRJ: function() {
          return sK((function(OO, KO) {
            const pO = GK(mp(KO).search, Op.F2gY, Op.HaBM),
              XO = Kp;
            uK().setInt32(OO + 4, XO, !0), uK().setInt32(OO + 0, pO, !0)
          }), arguments)
        },
        WZCh: function() {
          return sK((function(OO, KO, pO, XO, bK, eO, lO) {
            mp(OO).setBindGroup(KO >>> 0, mp(pO), IK(XO, bK), eO, lO >>> 0)
          }), arguments)
        },
        El7A: function(OO, KO, pO) {
          mp(OO).setBindGroup(KO >>> 0, mp(pO))
        },
        C76K: function(OO, KO, pO) {
          mp(OO).setBindGroup(KO >>> 0, mp(pO))
        },
        l3Dm: function() {
          return sK((function(OO, KO, pO, XO, bK, eO, lO) {
            mp(OO).setBindGroup(KO >>> 0, mp(pO), IK(XO, bK), eO, lO >>> 0)
          }), arguments)
        },
        d5Cx: function(OO, KO, pO) {
          mp(OO).setBindGroup(KO >>> 0, mp(pO))
        },
        abAW: function(OO, KO, pO, XO, bK) {
          mp(OO).setIndexBuffer(mp(KO), tK[pO], XO, bK)
        },
        ceJx: function(OO, KO, pO, XO, bK) {
          mp(OO).setIndexBuffer(mp(KO), tK[pO], XO, bK)
        },
        PeOJ: function(OO, KO) {
          mp(OO).setPipeline(mp(KO))
        },
        QoB7: function(OO, KO) {
          mp(OO).setPipeline(mp(KO))
        },
        ouhs: function(OO, KO) {
          mp(OO).setPipeline(mp(KO))
        },
        YSTg: function(OO, KO, pO, XO, bK) {
          mp(OO).setVertexBuffer(KO >>> 0, mp(pO), XO, bK)
        },
        bWAB: function(OO, KO, pO, XO, bK) {
          mp(OO).setVertexBuffer(KO >>> 0, mp(pO), XO, bK)
        },
        M8BC: function(OO, KO, pO, XO, bK, eO, lO) {
          mp(OO).setViewport(KO, pO, XO, bK, eO, lO)
        },
        yLPx: function() {
          return sK((function(OO, KO, pO) {
            return Reflect.set(mp(OO), mp(KO), mp(pO))
          }), arguments)
        },
        evrY: function(OO, KO, pO) {
          mp(OO).set(mp(KO), pO >>> 0)
        },
        w8OC: function(OO, KO) {
          mp(OO).a = KO
        },
        oY88: function(OO, KO) {
          mp(OO).access = eK[KO]
        },
        ZdaV: function(OO, KO) {
          mp(OO).addressModeU = sO[KO]
        },
        VGQJ: function(OO, KO) {
          mp(OO).addressModeV = sO[KO]
        },
        VKua: function(OO, KO) {
          mp(OO).addressModeW = sO[KO]
        },
        WJVO: function(OO, KO) {
          mp(OO).alpha = mp(KO)
        },
        UGv3: function(OO, KO) {
          mp(OO).alphaMode = cK[KO]
        },
        DRao: function(OO, KO) {
          mp(OO).alphaToCoverageEnabled = 0 !== KO
        },
        Hdrx: function(OO, KO) {
          mp(OO).arrayLayerCount = KO >>> 0
        },
        RqSo: function(OO, KO) {
          mp(OO).arrayStride = KO
        },
        wnwf: function(OO, KO) {
          mp(OO).aspect = vp[KO]
        },
        s01D: function(OO, KO) {
          mp(OO).aspect = vp[KO]
        },
        NvD6: function(OO, KO, pO) {
          mp(OO).attributes = NK(KO, pO)
        },
        Cf4o: function(OO, KO) {
          mp(OO).b = KO
        },
        NXkR: function(OO, KO) {
          mp(OO).baseArrayLayer = KO >>> 0
        },
        mhpL: function(OO, KO) {
          mp(OO).baseMipLevel = KO >>> 0
        },
        JGY1: function(OO, KO) {
          mp(OO).beginningOfPassWriteIndex = KO >>> 0
        },
        LiIV: function(OO, KO) {
          mp(OO).beginningOfPassWriteIndex = KO >>> 0
        },
        Av5i: function(OO, KO, pO) {
          mp(OO).bindGroupLayouts = NK(KO, pO)
        },
        WmH7: function(OO, KO) {
          mp(OO).binding = KO >>> 0
        },
        Ed3u: function(OO, KO) {
          mp(OO).binding = KO >>> 0
        },
        qqSo: function(OO, KO) {
          mp(OO).blend = mp(KO)
        },
        mGbe: function(OO, KO) {
          mp(OO).buffer = mp(KO)
        },
        IQab: function(OO, KO) {
          mp(OO).buffer = mp(KO)
        },
        n8eo: function(OO, KO, pO) {
          mp(OO).buffers = NK(KO, pO)
        },
        Q5te: function(OO, KO) {
          mp(OO).bytesPerRow = KO >>> 0
        },
        sETV: function(OO, KO) {
          mp(OO).clearValue = mp(KO)
        },
        re8J: function(OO, KO, pO) {
          mp(OO).code = YK(KO, pO)
        },
        xy7s: function(OO, KO) {
          mp(OO).color = mp(KO)
        },
        rW49: function(OO, KO, pO) {
          mp(OO).colorAttachments = NK(KO, pO)
        },
        uc2E: function(OO, KO, pO) {
          mp(OO).colorFormats = NK(KO, pO)
        },
        uG5y: function(OO, KO) {
          mp(OO).compare = ZO[KO]
        },
        yly2: function(OO, KO) {
          mp(OO).compute = mp(KO)
        },
        r0Uq: function(OO, KO) {
          mp(OO).count = KO >>> 0
        },
        ZDV6: function(OO, KO) {
          mp(OO).count = KO >>> 0
        },
        mtmh: function(OO, KO) {
          mp(OO).cullMode = GO[KO]
        },
        X6IZ: function(OO, KO) {
          mp(OO).depthBias = KO
        },
        RqQX: function(OO, KO) {
          mp(OO).depthBiasClamp = KO
        },
        b6vw: function(OO, KO) {
          mp(OO).depthBiasSlopeScale = KO
        },
        HvmP: function(OO, KO) {
          mp(OO).depthClearValue = KO
        },
        ikEk: function(OO, KO) {
          mp(OO).depthCompare = ZO[KO]
        },
        dIOz: function(OO, KO) {
          mp(OO).depthFailOp = bp[KO]
        },
        kLEa: function(OO, KO) {
          mp(OO).depthLoadOp = kK[KO]
        },
        M70C: function(OO, KO) {
          mp(OO).depthOrArrayLayers = KO >>> 0
        },
        hzgo: function(OO, KO) {
          mp(OO).depthReadOnly = 0 !== KO
        },
        Uk3h: function(OO, KO) {
          mp(OO).depthReadOnly = 0 !== KO
        },
        yFIw: function(OO, KO) {
          mp(OO).depthStencilAttachment = mp(KO)
        },
        jAMa: function(OO, KO) {
          mp(OO).depthStencil = mp(KO)
        },
        QT79: function(OO, KO) {
          mp(OO).depthStencilFormat = hK[KO]
        },
        aEeA: function(OO, KO) {
          mp(OO).depthStoreOp = lK[KO]
        },
        dSHi: function(OO, KO) {
          mp(OO).depthWriteEnabled = 0 !== KO
        },
        LGzK: function(OO, KO) {
          mp(OO).device = mp(KO)
        },
        HjxP: function(OO, KO) {
          mp(OO).dimension = CK[KO]
        },
        Sz0y: function(OO, KO) {
          mp(OO).dimension = MK[KO]
        },
        Q2dL: function(OO, KO) {
          mp(OO).dstFactor = RO[KO]
        },
        nf1r: function(OO, KO) {
          mp(OO).endOfPassWriteIndex = KO >>> 0
        },
        idvB: function(OO, KO) {
          mp(OO).endOfPassWriteIndex = KO >>> 0
        },
        e42T: function(OO, KO, pO) {
          mp(OO).entries = NK(KO, pO)
        },
        PwAd: function(OO, KO, pO) {
          mp(OO).entries = NK(KO, pO)
        },
        Gqsl: function(OO, KO, pO) {
          mp(OO).entryPoint = YK(KO, pO)
        },
        TZ5P: function(OO, KO, pO) {
          mp(OO).entryPoint = YK(KO, pO)
        },
        c9tY: function(OO, KO, pO) {
          mp(OO).entryPoint = YK(KO, pO)
        },
        IxeC: function(OO, KO) {
          mp(OO).externalTexture = mp(KO)
        },
        xArV: function(OO, KO) {
          mp(OO).failOp = bp[KO]
        },
        bcrv: function(OO, KO) {
          mp(OO).format = hK[KO]
        },
        cALm: function(OO, KO) {
          mp(OO).format = hK[KO]
        },
        S80C: function(OO, KO) {
          mp(OO).format = ap[KO]
        },
        fE9v: function(OO, KO) {
          mp(OO).format = hK[KO]
        },
        YT3o: function(OO, KO) {
          mp(OO).format = hK[KO]
        },
        vef5: function(OO, KO) {
          mp(OO).format = hK[KO]
        },
        WRCU: function(OO, KO) {
          mp(OO).format = hK[KO]
        },
        ffF4: function(OO, KO) {
          mp(OO).fragment = mp(KO)
        },
        erKV: function(OO, KO) {
          mp(OO).frontFace = WO[KO]
        },
        DYXi: function(OO, KO) {
          mp(OO).g = KO
        },
        Ehnf: function(OO, KO) {
          mp(OO).hasDynamicOffset = 0 !== KO
        },
        a5P7: function(OO, KO) {
          mp(OO).height = KO >>> 0
        },
        Hge0: function(OO, KO) {
          mp(OO).height = KO >>> 0
        },
        UX33: function(OO, KO) {
          mp(OO).height = KO >>> 0
        },
        pIFT: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        gC3y: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        MVo8: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        wJcy: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        veiK: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        NWeH: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        SNJm: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        rqzj: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        qC06: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        Q6c2: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        IdPJ: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        QnOk: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        C3Ay: function(OO, KO, pO) {
          mp(OO).label = YK(KO, pO)
        },
        mNp3: function(OO, KO) {
          mp(OO).layout = mp(KO)
        },
        QQz1: function(OO, KO) {
          mp(OO).layout = mp(KO)
        },
        zxmO: function(OO, KO) {
          mp(OO).layout = mp(KO)
        },
        WQYM: function(OO, KO) {
          mp(OO).layout = HO[KO]
        },
        IsUC: function(OO, KO) {
          mp(OO).layout = HO[KO]
        },
        LHZW: function(OO, KO) {
          mp(OO).loadOp = kK[KO]
        },
        sEOH: function(OO, KO) {
          mp(OO).lodMaxClamp = KO
        },
        k0e1: function(OO, KO) {
          mp(OO).lodMinClamp = KO
        },
        zmib: function(OO, KO) {
          mp(OO).magFilter = nO[KO]
        },
        MNza: function(OO, KO) {
          mp(OO).mappedAtCreation = 0 !== KO
        },
        dhfS: function(OO, KO) {
          mp(OO).mask = KO >>> 0
        },
        Cgp0: function(OO, KO) {
          mp(OO).maxAnisotropy = KO
        },
        ugqy: function(OO, KO) {
          mp(OO).minBindingSize = KO
        },
        cnPC: function(OO, KO) {
          mp(OO).minFilter = nO[KO]
        },
        NQxH: function(OO, KO) {
          mp(OO).mipLevelCount = KO >>> 0
        },
        gTFo: function(OO, KO) {
          mp(OO).mipLevelCount = KO >>> 0
        },
        T4QA: function(OO, KO) {
          mp(OO).mipLevel = KO >>> 0
        },
        c1yI: function(OO, KO) {
          mp(OO).mipmapFilter = UO[KO]
        },
        eVlk: function(OO, KO) {
          mp(OO).mode = BO[KO]
        },
        jOpx: function(OO, KO) {
          mp(OO).module = mp(KO)
        },
        tuBc: function(OO, KO) {
          mp(OO).module = mp(KO)
        },
        OX3H: function(OO, KO) {
          mp(OO).module = mp(KO)
        },
        vZUv: function(OO, KO) {
          mp(OO).multisample = mp(KO)
        },
        I3iP: function(OO, KO) {
          mp(OO).multisampled = 0 !== KO
        },
        Yh4f: function(OO, KO) {
          mp(OO).offset = KO
        },
        pHM9: function(OO, KO) {
          mp(OO).offset = KO
        },
        BAK1: function(OO, KO) {
          mp(OO).offset = KO
        },
        clP1: function(OO, KO) {
          mp(OO).operation = SO[KO]
        },
        Gd34: function(OO, KO) {
          mp(OO).origin = mp(KO)
        },
        ed1v: function(OO, KO) {
          mp(OO).passOp = bp[KO]
        },
        PrSp: function(OO, KO) {
          mp(OO).powerPreference = OK[KO]
        },
        nZyM: function(OO, KO) {
          mp(OO).primitive = mp(KO)
        },
        hHiX: function(OO, KO) {
          mp(OO).querySet = mp(KO)
        },
        m2iM: function(OO, KO) {
          mp(OO).querySet = mp(KO)
        },
        UnbE: function(OO, KO) {
          mp(OO).r = KO
        },
        xTyv: function(OO, KO, pO) {
          mp(OO).requiredFeatures = NK(KO, pO)
        },
        gp3g: function(OO, KO) {
          mp(OO).requiredLimits = mp(KO)
        },
        FuTn: function(OO, KO) {
          mp(OO).resolveTarget = mp(KO)
        },
        r2y7: function(OO, KO) {
          mp(OO).resource = mp(KO)
        },
        Dy2r: function(OO, KO) {
          mp(OO).resource = mp(KO)
        },
        NXcP: function(OO, KO) {
          mp(OO).resource = mp(KO)
        },
        BPX3: function(OO, KO) {
          mp(OO).rowsPerImage = KO >>> 0
        },
        taNg: function(OO, KO) {
          mp(OO).sampleCount = KO >>> 0
        },
        UqdY: function(OO, KO) {
          mp(OO).sampleCount = KO >>> 0
        },
        K7yN: function(OO, KO) {
          mp(OO).sampleType = DK[KO]
        },
        oOe2: function(OO, KO) {
          mp(OO).sampler = mp(KO)
        },
        DzOq: function(OO, KO) {
          mp(OO).shaderLocation = KO >>> 0
        },
        KV3S: function(OO, KO) {
          mp(OO).size = KO
        },
        YpnK: function(OO, KO) {
          mp(OO).size = KO
        },
        DcUU: function(OO, KO) {
          mp(OO).size = mp(KO)
        },
        slYM: function(OO, KO) {
          mp(OO).srcFactor = RO[KO]
        },
        QgTa: function(OO, KO) {
          mp(OO).stencilBack = mp(KO)
        },
        g54b: function(OO, KO) {
          mp(OO).stencilClearValue = KO >>> 0
        },
        p0pb: function(OO, KO) {
          mp(OO).stencilFront = mp(KO)
        },
        v7PX: function(OO, KO) {
          mp(OO).stencilLoadOp = kK[KO]
        },
        hXpX: function(OO, KO) {
          mp(OO).stencilReadMask = KO >>> 0
        },
        cjRB: function(OO, KO) {
          mp(OO).stencilReadOnly = 0 !== KO
        },
        tpwE: function(OO, KO) {
          mp(OO).stencilReadOnly = 0 !== KO
        },
        gzNp: function(OO, KO) {
          mp(OO).stencilStoreOp = lK[KO]
        },
        Gc1J: function(OO, KO) {
          mp(OO).stencilWriteMask = KO >>> 0
        },
        oNOZ: function(OO, KO) {
          mp(OO).stepMode = oK[KO]
        },
        tsMf: function(OO, KO) {
          mp(OO).storageTexture = mp(KO)
        },
        cmX8: function(OO, KO) {
          mp(OO).storeOp = lK[KO]
        },
        VrRj: function(OO, KO) {
          mp(OO).stripIndexFormat = tK[KO]
        },
        mSGa: function(OO, KO, pO) {
          mp(OO).targets = NK(KO, pO)
        },
        pTo0: function(OO, KO) {
          mp(OO).texture = mp(KO)
        },
        YVg4: function(OO, KO) {
          mp(OO).texture = mp(KO)
        },
        ooT6: function(OO, KO) {
          mp(OO).timestampWrites = mp(KO)
        },
        usco: function(OO, KO) {
          mp(OO).timestampWrites = mp(KO)
        },
        ikNY: function(OO, KO) {
          mp(OO).toneMapping = mp(KO)
        },
        ECX4: function(OO, KO) {
          mp(OO).topology = KK[KO]
        },
        nVWZ: function(OO, KO) {
          mp(OO).type = XK[KO]
        },
        QM19: function(OO, KO) {
          mp(OO).type = JO[KO]
        },
        sFj3: function(OO, KO) {
          mp(OO).type = pK[KO]
        },
        kXjn: function(OO, KO) {
          mp(OO).unclippedDepth = 0 !== KO
        },
        Sflt: function(OO, KO) {
          mp(OO).usage = KO >>> 0
        },
        zzej: function(OO, KO) {
          mp(OO).usage = KO >>> 0
        },
        dMJN: function(OO, KO) {
          mp(OO).usage = KO >>> 0
        },
        fAnp: function(OO, KO) {
          mp(OO).usage = KO >>> 0
        },
        OsoW: function(OO, KO) {
          mp(OO).vertex = mp(KO)
        },
        UBMI: function(OO, KO) {
          mp(OO).viewDimension = MK[KO]
        },
        MDoL: function(OO, KO) {
          mp(OO).viewDimension = MK[KO]
        },
        OLQC: function(OO, KO, pO) {
          mp(OO).viewFormats = NK(KO, pO)
        },
        k1ZL: function(OO, KO, pO) {
          mp(OO).viewFormats = NK(KO, pO)
        },
        WwJq: function(OO, KO) {
          mp(OO).view = mp(KO)
        },
        MDMR: function(OO, KO) {
          mp(OO).view = mp(KO)
        },
        KftO: function(OO, KO) {
          mp(OO).visibility = KO >>> 0
        },
        O3Sj: function(OO, KO) {
          mp(OO).width = KO >>> 0
        },
        QPrK: function(OO, KO) {
          mp(OO).width = KO >>> 0
        },
        uIHY: function(OO, KO) {
          mp(OO).width = KO >>> 0
        },
        kKDF: function(OO, KO) {
          mp(OO).writeMask = KO >>> 0
        },
        UaiZ: function(OO, KO) {
          mp(OO).x = KO >>> 0
        },
        RG7e: function(OO, KO) {
          mp(OO).y = KO >>> 0
        },
        X2fF: function(OO, KO) {
          mp(OO).z = KO >>> 0
        },
        eTKl: function() {
          const OO = "undefined" === typeof global ? null : global;
          return SK(OO) ? 0 : QK(OO)
        },
        M7sU: function() {
          const OO = "undefined" === typeof globalThis ? null : globalThis;
          return SK(OO) ? 0 : QK(OO)
        },
        GQpK: function() {
          const OO = "undefined" === typeof self ? null : self;
          return SK(OO) ? 0 : QK(OO)
        },
        U1Fq: function() {
          const OO = "undefined" === typeof window ? null : window;
          return SK(OO) ? 0 : QK(OO)
        },
        gUfD: function(OO, KO, pO) {
          return QK(mp(OO).subarray(KO >>> 0, pO >>> 0))
        },
        RqyV: function(OO) {
          return mp(OO).subgroupMaxSize
        },
        LndQ: function(OO) {
          return mp(OO).subgroupMinSize
        },
        zAhq: function(OO, KO, pO) {
          mp(OO).submit(NK(KO, pO))
        },
        hyN8: function(OO, KO) {
          return QK(mp(OO).then(mp(KO)))
        },
        V3n4: function(OO, KO, pO) {
          return QK(mp(OO).then(mp(KO), mp(pO)))
        },
        S5qj: function(OO, KO) {
          return QK(mp(OO).then(mp(KO)))
        },
        Y3N9: function(OO) {
          mp(OO).unconfigure()
        },
        B22h: function(OO) {
          mp(OO).unmap()
        },
        vv7r: function(OO) {
          console.warn(mp(OO))
        },
        R8O7: function(OO, KO) {
          console.warn(YK(OO, KO))
        },
        ETDL: function(OO) {
          return mp(OO).width
        },
        pTiH: function() {
          return sK((function(OO, KO, pO, XO, bK, eO, lO) {
            mp(OO).writeBuffer(mp(KO), pO, yp(XO, bK), eO, lO)
          }), arguments)
        },
        HHXT: function() {
          return sK((function(OO, KO, pO, XO, bK, eO) {
            mp(OO).writeTexture(mp(KO), yp(pO, XO), mp(bK), mp(eO))
          }), arguments)
        },
        PtA7: function(OO, KO) {
          return QK(JK(OO, KO, iK))
        },
        Kawu: function(OO, KO) {
          return QK(JK(OO, KO, wO))
        },
        wFXM: function(OO, KO) {
          return QK(JK(OO, KO, rK))
        },
        MyUR: function(OO, KO) {
          return QK(JK(OO, KO, YO))
        },
        wgFy: function(OO, KO) {
          return QK(JK(OO, KO, PO))
        },
        LtVF: function(OO, KO) {
          return QK(JK(OO, KO, mK))
        },
        c0kK: function(OO) {
          return QK(OO)
        },
        UwzY: function(OO, KO) {
          return QK(yp(OO, KO))
        },
        FBge: function(OO, KO) {
          return QK(YK(OO, KO))
        },
        NtuN: function(OO) {
          return QK(mp(OO))
        },
        g2q5: function(OO) {
          qp(OO)
        }
      };
      return {
        __proto__: null,
        gP3s: OO
      }
    }

    function YO(OO, KO, pO) {
      Op.s2Yp(OO, KO, QK(pO))
    }

    function wO(OO, KO, pO) {
      return qp(Op.WPkF(OO, KO, QK(pO)))
    }

    function iK(OO, KO, pO) {
      const XO = Op.LYrT(OO, KO, QK(pO));
      if (XO[1]) throw qp(XO[0])
    }

    function rK(OO, KO, pO) {
      const XO = Op.bBDX(OO, KO, QK(pO));
      if (XO[1]) throw qp(XO[0])
    }

    function PO(OO, KO, pO) {
      const XO = Op.o5Xz(OO, KO, QK(pO));
      if (XO[1]) throw qp(XO[0])
    }

    function mK(OO, KO, pO) {
      const XO = Op.I45H(OO, KO, QK(pO));
      if (XO[1]) throw qp(XO[0])
    }
    Symbol.dispose && (lO.prototype[Symbol.dispose] = lO.prototype.free);
    const sO = ["clamp-to-edge", "repeat", "mirror-repeat"],
      HO = ["auto"],
      RO = ["zero", "one", "src", "one-minus-src", "src-alpha", "one-minus-src-alpha", "dst", "one-minus-dst", "dst-alpha", "one-minus-dst-alpha", "src-alpha-saturated", "constant", "one-minus-constant", "src1", "one-minus-src1", "src1-alpha", "one-minus-src1-alpha"],
      SO = ["add", "subtract", "reverse-subtract", "min", "max"],
      JO = ["uniform", "storage", "read-only-storage"],
      cK = ["opaque", "premultiplied"],
      BO = ["standard", "extended"],
      ZO = ["never", "less", "equal", "less-equal", "greater", "not-equal", "greater-equal", "always"],
      GO = ["none", "front", "back"],
      qK = ["unknown", "destroyed"],
      xK = ["validation", "out-of-memory", "internal"],
      nO = ["nearest", "linear"],
      WO = ["ccw", "cw"],
      tK = ["uint16", "uint32"],
      kK = ["load", "clear"],
      UO = ["nearest", "linear"],
      OK = ["low-power", "high-performance"],
      KK = ["point-list", "line-list", "line-strip", "triangle-list", "triangle-strip"],
      pK = ["occlusion", "timestamp"],
      XK = ["filtering", "non-filtering", "comparison"],
      bp = ["keep", "zero", "replace", "invert", "increment-clamp", "decrement-clamp", "increment-wrap", "decrement-wrap"],
      eK = ["write-only", "read-only", "read-write"],
      lK = ["store", "discard"],
      vp = ["all", "stencil-only", "depth-only"],
      CK = ["1d", "2d", "3d"],
      hK = ["r8unorm", "r8snorm", "r8uint", "r8sint", "r16unorm", "r16snorm", "r16uint", "r16sint", "r16float", "rg8unorm", "rg8snorm", "rg8uint", "rg8sint", "r32uint", "r32sint", "r32float", "rg16unorm", "rg16snorm", "rg16uint", "rg16sint", "rg16float", "rgba8unorm", "rgba8unorm-srgb", "rgba8snorm", "rgba8uint", "rgba8sint", "bgra8unorm", "bgra8unorm-srgb", "rgb9e5ufloat", "rgb10a2uint", "rgb10a2unorm", "rg11b10ufloat", "rg32uint", "rg32sint", "rg32float", "rgba16unorm", "rgba16snorm", "rgba16uint", "rgba16sint", "rgba16float", "rgba32uint", "rgba32sint", "rgba32float", "stencil8", "depth16unorm", "depth24plus", "depth24plus-stencil8", "depth32float", "depth32float-stencil8", "bc1-rgba-unorm", "bc1-rgba-unorm-srgb", "bc2-rgba-unorm", "bc2-rgba-unorm-srgb", "bc3-rgba-unorm", "bc3-rgba-unorm-srgb", "bc4-r-unorm", "bc4-r-snorm", "bc5-rg-unorm", "bc5-rg-snorm", "bc6h-rgb-ufloat", "bc6h-rgb-float", "bc7-rgba-unorm", "bc7-rgba-unorm-srgb", "etc2-rgb8unorm", "etc2-rgb8unorm-srgb", "etc2-rgb8a1unorm", "etc2-rgb8a1unorm-srgb", "etc2-rgba8unorm", "etc2-rgba8unorm-srgb", "eac-r11unorm", "eac-r11snorm", "eac-rg11unorm", "eac-rg11snorm", "astc-4x4-unorm", "astc-4x4-unorm-srgb", "astc-5x4-unorm", "astc-5x4-unorm-srgb", "astc-5x5-unorm", "astc-5x5-unorm-srgb", "astc-6x5-unorm", "astc-6x5-unorm-srgb", "astc-6x6-unorm", "astc-6x6-unorm-srgb", "astc-8x5-unorm", "astc-8x5-unorm-srgb", "astc-8x6-unorm", "astc-8x6-unorm-srgb", "astc-8x8-unorm", "astc-8x8-unorm-srgb", "astc-10x5-unorm", "astc-10x5-unorm-srgb", "astc-10x6-unorm", "astc-10x6-unorm-srgb", "astc-10x8-unorm", "astc-10x8-unorm-srgb", "astc-10x10-unorm", "astc-10x10-unorm-srgb", "astc-12x10-unorm", "astc-12x10-unorm-srgb", "astc-12x12-unorm", "astc-12x12-unorm-srgb"],
      DK = ["float", "unfilterable-float", "depth", "sint", "uint"],
      MK = ["1d", "2d", "2d-array", "cube", "cube-array", "3d"],
      ap = ["uint8", "uint8x2", "uint8x4", "sint8", "sint8x2", "sint8x4", "unorm8", "unorm8x2", "unorm8x4", "snorm8", "snorm8x2", "snorm8x4", "uint16", "uint16x2", "uint16x4", "sint16", "sint16x2", "sint16x4", "unorm16", "unorm16x2", "unorm16x4", "snorm16", "snorm16x2", "snorm16x4", "float16", "float16x2", "float16x4", "float32", "float32x2", "float32x3", "float32x4", "uint32", "uint32x2", "uint32x3", "uint32x4", "sint32", "sint32x2", "sint32x3", "sint32x4", "unorm10-10-10-2", "unorm8x4-bgra"],
      oK = ["vertex", "instance"],
      FK = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => Op.ewr4(OO, 1))),
      VK = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => Op.oLNN(OO, 1))),
      LK = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => Op.NqJy(OO, 1)));

    function QK(OO) {
      RK === HK.length && HK.push(HK.length + 1);
      const KO = RK;
      return RK = HK[KO], HK[KO] = OO, KO
    }

    function zp(OO, KO) {
      if (!(OO instanceof KO)) throw new Error(`expected instance of ${KO.name}`)
    }
    const AK = "undefined" === typeof FinalizationRegistry ? {
      register: () => {},
      unregister: () => {}
    } : new FinalizationRegistry((OO => Op.LClu(OO.a, OO.b)));

    function fK(OO) {
      const KO = typeof OO;
      if ("number" == KO || "boolean" == KO || null == OO) return `${OO}`;
      if ("string" == KO) return `"${OO}"`;
      if ("symbol" == KO) {
        const KO = OO.description;
        return null == KO ? "Symbol" : `Symbol(${KO})`
      }
      if ("function" == KO) {
        const KO = OO.name;
        return "string" == typeof KO && KO.length > 0 ? `Function(${KO})` : "Function"
      }
      if (Array.isArray(OO)) {
        const KO = OO.length;
        let pO = "[";
        KO > 0 && (pO += fK(OO[0]));
        for (let XO = 1; XO < KO; XO++) pO += ", " + fK(OO[XO]);
        return pO += "]", pO
      }
      const pO = /\[object ([^\]]+)\]/.exec(toString.call(OO));
      let XO;
      if (!(pO && pO.length > 1)) return toString.call(OO);
      if (XO = pO[1], "Object" == XO) try {
        return "Object(" + JSON.stringify(OO) + ")"
      } catch (bK) {
        return "Object"
      }
      return OO instanceof Error ? `${OO.name}: ${OO.message}\n${OO.stack}` : XO
    }

    function dK(OO, KO) {
      return OO >>>= 0, jp().subarray(OO / 8, OO / 8 + KO)
    }

    function TK(OO, KO) {
      OO >>>= 0;
      const pO = uK(),
        XO = [];
      for (let bK = OO; bK < OO + 4 * KO; bK += 4) XO.push(qp(pO.getUint32(bK, !0)));
      return XO
    }

    function NK(OO, KO) {
      OO >>>= 0;
      const pO = uK(),
        XO = [];
      for (let bK = OO; bK < OO + 4 * KO; bK += 4) XO.push(mp(pO.getUint32(bK, !0)));
      return XO
    }

    function IK(OO, KO) {
      return OO >>>= 0, ip().subarray(OO / 4, OO / 4 + KO)
    }

    function yp(OO, KO) {
      return OO >>>= 0, PK().subarray(OO / 1, OO / 1 + KO)
    }
    let gp = null;

    function uK() {
      return (null === gp || !0 === gp.buffer.detached || void 0 === gp.buffer.detached && gp.buffer !== Op.memory.buffer) && (gp = new DataView(Op.memory.buffer)), gp
    }
    let EK = null;

    function jp() {
      return null !== EK && 0 !== EK.byteLength || (EK = new Float64Array(Op.memory.buffer)), EK
    }

    function YK(OO, KO) {
      return function(OO, KO) {
        WK += KO, WK >= nK && (xp = new TextDecoder("utf-8", {
          ignoreBOM: !0,
          fatal: !0
        }), xp.decode(), WK = KO);
        return xp.decode(PK().subarray(OO, OO + KO))
      }(OO >>> 0, KO)
    }
    let wK = null;

    function ip() {
      return null !== wK && 0 !== wK.byteLength || (wK = new Uint32Array(Op.memory.buffer)), wK
    }
    let rp = null;

    function PK() {
      return null !== rp && 0 !== rp.byteLength || (rp = new Uint8Array(Op.memory.buffer)), rp
    }

    function mp(OO) {
      return HK[OO]
    }

    function sK(OO, KO) {
      try {
        return OO.apply(this, KO)
      } catch (pO) {
        Op.vMKq(QK(pO))
      }
    }
    let HK = new Array(1024).fill(void 0);
    HK.push(void 0, null, !0, !1);
    let RK = HK.length;

    function SK(OO) {
      return void 0 === OO || null === OO
    }

    function JK(OO, KO, pO) {
      const XO = {
          a: OO,
          b: KO,
          cnt: 1
        },
        bK = function() {
          XO.cnt++;
          const OO = XO.a;
          XO.a = 0;
          try {
            for (var KO = arguments.length, eO = new Array(KO), lO = 0; lO < KO; lO++) eO[lO] = arguments[lO];
            return pO(OO, XO.b, ...eO)
          } finally {
            XO.a = OO, bK._wbg_cb_unref()
          }
        };
      return bK._wbg_cb_unref = () => {
        0 === --XO.cnt && (Op.LClu(XO.a, XO.b), XO.a = 0, AK.unregister(XO))
      }, AK.register(bK, XO, XO), bK
    }

    function cp(OO, KO) {
      const pO = KO(4 * OO.length, 4) >>> 0;
      return ip().set(OO, pO / 4), Kp = OO.length, pO
    }

    function BK(OO, KO) {
      const pO = KO(1 * OO.length, 1) >>> 0;
      return PK().set(OO, pO / 1), Kp = OO.length, pO
    }

    function ZK(OO, KO) {
      const pO = KO(4 * OO.length, 4) >>> 0,
        XO = uK();
      for (let bK = 0; bK < OO.length; bK++) XO.setUint32(pO + 4 * bK, QK(OO[bK]), !0);
      return Kp = OO.length, pO
    }

    function GK(OO, KO, pO) {
      if (void 0 === pO) {
        const pO = tp.encode(OO),
          XO = KO(pO.length, 1) >>> 0;
        return PK().subarray(XO, XO + pO.length).set(pO), Kp = pO.length, XO
      }
      let XO = OO.length,
        bK = KO(XO, 1) >>> 0;
      const eO = PK();
      let lO = 0;
      for (; lO < XO; lO++) {
        const KO = OO.charCodeAt(lO);
        if (KO > 127) break;
        eO[bK + lO] = KO
      }
      if (lO !== XO) {
        0 !== lO && (OO = OO.slice(lO)), bK = pO(bK, XO, XO = lO + 3 * OO.length, 1) >>> 0;
        const KO = PK().subarray(bK + lO, bK + XO);
        lO += tp.encodeInto(OO, KO).written, bK = pO(bK, XO, lO, 1) >>> 0
      }
      return Kp = lO, bK
    }

    function qp(OO) {
      const KO = mp(OO);
      return function(OO) {
        OO < 1028 || (HK[OO] = RK, RK = OO)
      }(OO), KO
    }
    let xp = new TextDecoder("utf-8", {
      ignoreBOM: !0,
      fatal: !0
    });
    xp.decode();
    const nK = 2146435072;
    let WK = 0;
    const tp = new TextEncoder;
    "encodeInto" in tp || (tp.encodeInto = function(OO, KO) {
      const pO = tp.encode(OO);
      return KO.set(pO), {
        read: OO.length,
        written: pO.length
      }
    });
    let kp, UK, Op, Kp = 0;

    function pp(OO, KO) {
      return UK = OO, Op = OO.exports, kp = KO, gp = null, EK = null, wK = null, rp = null, Op.Txvx(), Op
    }

    function Xp(OO) {
      if (void 0 !== Op) return Op;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module: OO
      } = OO) : console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));
      const KO = jK();
      OO instanceof WebAssembly.Module || (OO = new WebAssembly.Module(OO));
      return pp(new WebAssembly.Instance(OO, KO), OO)
    }
    async function bX(OO) {
      if (void 0 !== Op) return Op;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module_or_path: OO
      } = OO) : console.warn("using deprecated parameters for the initialization function; pass a single object instead"));
      const KO = jK();
      ("string" === typeof OO || "function" === typeof Request && OO instanceof Request || "function" === typeof URL && OO instanceof URL) && (OO = fetch(OO));
      const {
        instance: pO,
        module: XO
      } = await async function(OO, KO) {
        if ("function" === typeof Response && OO instanceof Response) {
          if (!OO.ok) throw new Error(`failed to fetch Wasm: ${OO.status} ${OO.statusText} fetching '${OO.url}'`);
          if ("function" === typeof WebAssembly.instantiateStreaming) try {
            return await WebAssembly.instantiateStreaming(OO, KO)
          } catch (pO) {
            if (! function(OO) {
                switch (OO) {
                  case "basic":
                  case "cors":
                  case "default":
                    return !0
                }
                return !1
              }(OO.type) || "application/wasm" === OO.headers.get("Content-Type")) throw pO;
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", pO)
          }
          const XO = await OO.arrayBuffer();
          return await WebAssembly.instantiate(XO, KO)
        } {
          const pO = await WebAssembly.instantiate(OO, KO);
          return pO instanceof WebAssembly.Instance ? {
            instance: pO,
            module: OO
          } : pO
        }
      }(await OO, KO);
      return pp(pO, XO)
    }
    const ep = {
      name: "bloxd_wasm_webgpu",
      url: () => new pO.U(pO(41272)),
      init: bX,
      MX: XO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);