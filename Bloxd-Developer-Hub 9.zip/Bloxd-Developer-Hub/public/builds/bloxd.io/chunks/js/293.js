export const id = 293;
export const ids = [293];
export const modules = {
  39859: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      _KTXTextureLoader: () => FO
    });
    var XO = pO(37061);
    class bK {
      constructor(OO, KO) {
        if (this.data = OO, this.isInvalid = !1, !bK.IsValid(OO)) return this.isInvalid = !0, void XO.b.Error("texture missing KTX identifier");
        const pO = Uint32Array.BYTES_PER_ELEMENT,
          eO = new DataView(this.data.buffer, this.data.byteOffset + 12, 13 * pO),
          lO = 67305985 === eO.getUint32(0, !0);
        return this.glType = eO.getUint32(1 * pO, lO), this.glTypeSize = eO.getUint32(2 * pO, lO), this.glFormat = eO.getUint32(3 * pO, lO), this.glInternalFormat = eO.getUint32(4 * pO, lO), this.glBaseInternalFormat = eO.getUint32(5 * pO, lO), this.pixelWidth = eO.getUint32(6 * pO, lO), this.pixelHeight = eO.getUint32(7 * pO, lO), this.pixelDepth = eO.getUint32(8 * pO, lO), this.numberOfArrayElements = eO.getUint32(9 * pO, lO), this.numberOfFaces = eO.getUint32(10 * pO, lO), this.numberOfMipmapLevels = eO.getUint32(11 * pO, lO), this.bytesOfKeyValueData = eO.getUint32(12 * pO, lO), 0 !== this.glType ? (XO.b.Error("only compressed formats currently supported"), void(this.isInvalid = !0)) : (this.numberOfMipmapLevels = Math.max(1, this.numberOfMipmapLevels), 0 === this.pixelHeight || 0 !== this.pixelDepth ? (XO.b.Error("only 2D textures currently supported"), void(this.isInvalid = !0)) : 0 !== this.numberOfArrayElements ? (XO.b.Error("texture arrays not currently supported"), void(this.isInvalid = !0)) : this.numberOfFaces !== KO ? (XO.b.Error("number of faces expected" + KO + ", but found " + this.numberOfFaces), void(this.isInvalid = !0)) : void(this.loadType = bK.COMPRESSED_2D))
      }
      uploadLevels(OO, KO) {
        switch (this.loadType) {
          case bK.COMPRESSED_2D:
            this._upload2DCompressedLevels(OO, KO);
          case bK.TEX_2D:
          case bK.COMPRESSED_3D:
          case bK.TEX_3D:
        }
      }
      _upload2DCompressedLevels(OO, KO) {
        let pO = bK.HEADER_LEN + this.bytesOfKeyValueData,
          XO = this.pixelWidth,
          eO = this.pixelHeight;
        const lO = KO ? this.numberOfMipmapLevels : 1;
        for (let bK = 0; bK < lO; bK++) {
          const KO = new Int32Array(this.data.buffer, this.data.byteOffset + pO, 1)[0];
          pO += 4;
          for (let lO = 0; lO < this.numberOfFaces; lO++) {
            const vK = new Uint8Array(this.data.buffer, this.data.byteOffset + pO, KO);
            OO.qb()._uploadCompressedDataToTextureDirectly(OO, OO.format, XO, eO, vK, lO, bK), pO += KO, pO += 3 - (KO + 3) % 4
          }
          XO = Math.max(1, .5 * XO), eO = Math.max(1, .5 * eO)
        }
      }
      static IsValid(OO) {
        if (OO.byteLength >= 12) {
          const KO = new Uint8Array(OO.buffer, OO.byteOffset, 12);
          if (171 === KO[0] && 75 === KO[1] && 84 === KO[2] && 88 === KO[3] && 32 === KO[4] && 49 === KO[5] && 49 === KO[6] && 187 === KO[7] && 13 === KO[8] && 10 === KO[9] && 26 === KO[10] && 10 === KO[11]) return !0
        }
        return !1
      }
    }
    bK.HEADER_LEN = 64, bK.COMPRESSED_2D = 0, bK.COMPRESSED_3D = 1, bK.TEX_2D = 2, bK.TEX_3D = 3;
    var eO, lO, vK, CO = pO(39862),
      hO = pO(38172);

    function DO(OO, KO) {
      const pO = KO?.jsDecoderModule || KTX2DECODER;
      OO && (OO.wasmBaseUrl && (pO.Transcoder.WasmBaseUrl = OO.wasmBaseUrl), OO.wasmUASTCToASTC && (pO.LiteTranscoder_UASTC_ASTC.WasmModuleURL = OO.wasmUASTCToASTC), OO.wasmUASTCToBC7 && (pO.LiteTranscoder_UASTC_BC7.WasmModuleURL = OO.wasmUASTCToBC7), OO.wasmUASTCToRGBA_UNORM && (pO.LiteTranscoder_UASTC_RGBA_UNORM.WasmModuleURL = OO.wasmUASTCToRGBA_UNORM), OO.wasmUASTCToRGBA_SRGB && (pO.LiteTranscoder_UASTC_RGBA_SRGB.WasmModuleURL = OO.wasmUASTCToRGBA_SRGB), OO.wasmUASTCToR8_UNORM && (pO.LiteTranscoder_UASTC_R8_UNORM.WasmModuleURL = OO.wasmUASTCToR8_UNORM), OO.wasmUASTCToRG8_UNORM && (pO.LiteTranscoder_UASTC_RG8_UNORM.WasmModuleURL = OO.wasmUASTCToRG8_UNORM), OO.jsMSCTranscoder && (pO.MSCTranscoder.JSModuleURL = OO.jsMSCTranscoder), OO.wasmMSCTranscoder && (pO.MSCTranscoder.WasmModuleURL = OO.wasmMSCTranscoder), OO.wasmZSTDDecoder && (pO.ZSTDDecoder.WasmModuleURL = OO.wasmZSTDDecoder)), KO && (KO.wasmUASTCToASTC && (pO.LiteTranscoder_UASTC_ASTC.WasmBinary = KO.wasmUASTCToASTC), KO.wasmUASTCToBC7 && (pO.LiteTranscoder_UASTC_BC7.WasmBinary = KO.wasmUASTCToBC7), KO.wasmUASTCToRGBA_UNORM && (pO.LiteTranscoder_UASTC_RGBA_UNORM.WasmBinary = KO.wasmUASTCToRGBA_UNORM), KO.wasmUASTCToRGBA_SRGB && (pO.LiteTranscoder_UASTC_RGBA_SRGB.WasmBinary = KO.wasmUASTCToRGBA_SRGB), KO.wasmUASTCToR8_UNORM && (pO.LiteTranscoder_UASTC_R8_UNORM.WasmBinary = KO.wasmUASTCToR8_UNORM), KO.wasmUASTCToRG8_UNORM && (pO.LiteTranscoder_UASTC_RG8_UNORM.WasmBinary = KO.wasmUASTCToRG8_UNORM), KO.jsMSCTranscoder && (pO.MSCTranscoder.JSModule = KO.jsMSCTranscoder), KO.wasmMSCTranscoder && (pO.MSCTranscoder.WasmBinary = KO.wasmMSCTranscoder), KO.wasmZSTDDecoder && (pO.ZSTDDecoder.WasmBinary = KO.wasmZSTDDecoder))
    }

    function MO(OO) {
      let KO;
      "undefined" === typeof OO && "undefined" !== typeof KTX2DECODER && (OO = KTX2DECODER), onmessage = pO => {
        if (pO.data) switch (pO.data.action) {
          case "init": {
            const XO = pO.data.urls;
            XO && (XO.jsDecoderModule && "undefined" === typeof OO && (importScripts(XO.jsDecoderModule), OO = KTX2DECODER), DO(XO)), pO.data.wasmBinaries && DO(void 0, {
              ...pO.data.wasmBinaries,
              jsDecoderModule: OO
            }), KO = new OO.KTX2Decoder, postMessage({
              action: "init"
            });
            break
          }
          case "setDefaultDecoderOptions":
            OO.KTX2Decoder.DefaultDecoderOptions = pO.data.options;
            break;
          case "decode":
            KO.decode(pO.data.data, pO.data.caps, pO.data.options).then((OO => {
              const KO = [];
              for (let pO = 0; pO < OO.mipmaps.length; ++pO) {
                const XO = OO.mipmaps[pO];
                XO && XO.data && KO.push(XO.data.buffer)
              }
              postMessage({
                action: "decoded",
                success: !0,
                decodedData: OO
              }, KO)
            })).catch((OO => {
              postMessage({
                action: "decoded",
                success: !1,
                Tl: OO
              })
            }))
        }
      }
    }! function(OO) {
      OO[OO.ETC1S = 0] = "ETC1S", OO[OO.UASTC4x4 = 1] = "UASTC4x4", OO[OO.RGBA32 = 2] = "RGBA32"
    }(eO || (eO = {})),
    function(OO) {
      OO[OO.ASTC_4X4_RGBA = 0] = "ASTC_4X4_RGBA", OO[OO.ASTC_4x4_RGBA = 0] = "ASTC_4x4_RGBA", OO[OO.BC7_RGBA = 1] = "BC7_RGBA", OO[OO.BC3_RGBA = 2] = "BC3_RGBA", OO[OO.BC1_RGB = 3] = "BC1_RGB", OO[OO.PVRTC1_4_RGBA = 4] = "PVRTC1_4_RGBA", OO[OO.PVRTC1_4_RGB = 5] = "PVRTC1_4_RGB", OO[OO.ETC2_RGBA = 6] = "ETC2_RGBA", OO[OO.ETC1_RGB = 7] = "ETC1_RGB", OO[OO.RGBA32 = 8] = "RGBA32", OO[OO.R8 = 9] = "R8", OO[OO.RG8 = 10] = "RG8"
    }(lO || (lO = {})),
    function(OO) {
      OO[OO.COMPRESSED_RGBA_BPTC_UNORM_EXT = 36492] = "COMPRESSED_RGBA_BPTC_UNORM_EXT", OO[OO.COMPRESSED_RGBA_ASTC_4X4_KHR = 37808] = "COMPRESSED_RGBA_ASTC_4X4_KHR", OO[OO.COMPRESSED_RGB_S3TC_DXT1_EXT = 33776] = "COMPRESSED_RGB_S3TC_DXT1_EXT", OO[OO.COMPRESSED_RGBA_S3TC_DXT5_EXT = 33779] = "COMPRESSED_RGBA_S3TC_DXT5_EXT", OO[OO.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG = 35842] = "COMPRESSED_RGBA_PVRTC_4BPPV1_IMG", OO[OO.COMPRESSED_RGB_PVRTC_4BPPV1_IMG = 35840] = "COMPRESSED_RGB_PVRTC_4BPPV1_IMG", OO[OO.COMPRESSED_RGBA8_ETC2_EAC = 37496] = "COMPRESSED_RGBA8_ETC2_EAC", OO[OO.COMPRESSED_RGB8_ETC2 = 37492] = "COMPRESSED_RGB8_ETC2", OO[OO.COMPRESSED_RGB_ETC1_WEBGL = 36196] = "COMPRESSED_RGB_ETC1_WEBGL", OO[OO.RGBA8Format = 32856] = "RGBA8Format", OO[OO.R8Format = 33321] = "R8Format", OO[OO.RG8Format = 33323] = "RG8Format"
    }(vK || (vK = {}));
    class aK {
      static GetDefaultNumWorkers() {
        return "object" === typeof navigator && navigator.hardwareConcurrency ? Math.min(Math.floor(.5 * navigator.hardwareConcurrency), 4) : 1
      }
      static _Initialize(OO) {
        if (aK._WorkerPoolPromise || aK._DecoderModulePromise) return;
        const KO = {
          wasmBaseUrl: hO.k.ScriptBaseUrl,
          jsDecoderModule: hO.k.GetBabylonScriptURL(this.URLConfig.jsDecoderModule, !0),
          wasmUASTCToASTC: hO.k.GetBabylonScriptURL(this.URLConfig.wasmUASTCToASTC, !0),
          wasmUASTCToBC7: hO.k.GetBabylonScriptURL(this.URLConfig.wasmUASTCToBC7, !0),
          wasmUASTCToRGBA_UNORM: hO.k.GetBabylonScriptURL(this.URLConfig.wasmUASTCToRGBA_UNORM, !0),
          wasmUASTCToRGBA_SRGB: hO.k.GetBabylonScriptURL(this.URLConfig.wasmUASTCToRGBA_SRGB, !0),
          wasmUASTCToR8_UNORM: hO.k.GetBabylonScriptURL(this.URLConfig.wasmUASTCToR8_UNORM, !0),
          wasmUASTCToRG8_UNORM: hO.k.GetBabylonScriptURL(this.URLConfig.wasmUASTCToRG8_UNORM, !0),
          jsMSCTranscoder: hO.k.GetBabylonScriptURL(this.URLConfig.jsMSCTranscoder, !0),
          wasmMSCTranscoder: hO.k.GetBabylonScriptURL(this.URLConfig.wasmMSCTranscoder, !0),
          wasmZSTDDecoder: hO.k.GetBabylonScriptURL(this.URLConfig.wasmZSTDDecoder, !0)
        };
        OO && "function" === typeof Worker && "undefined" !== typeof URL ? aK._WorkerPoolPromise = new Promise((pO => {
          const XO = `${DO}(${MO})()`,
            bK = URL.createObjectURL(new Blob([XO], {
              type: "application/javascript"
            }));
          pO(new CO.b(OO, (async () => await async function(OO, KO, pO) {
            return await new Promise(((XO, bK) => {
              const eO = KO => {
                  OO.removeEventListener("error", eO), OO.removeEventListener("message", lO), bK(KO)
                },
                lO = KO => {
                  "init" === KO.data.action && (OO.removeEventListener("error", eO), OO.removeEventListener("message", lO), XO(OO))
                };
              OO.addEventListener("error", eO), OO.addEventListener("message", lO), OO.postMessage({
                action: "init",
                urls: pO,
                wasmBinaries: KO
              })
            }))
          }(new Worker(bK), void 0, KO))))
        })) : "undefined" === typeof aK._KTX2DecoderModule ? aK._DecoderModulePromise = hO.k.LoadBabylonScriptAsync(KO.jsDecoderModule).then((() => (aK._KTX2DecoderModule = KTX2DECODER, aK._KTX2DecoderModule.MSCTranscoder.UseFromWorkerThread = !1, aK._KTX2DecoderModule.WASMMemoryManager.LoadBinariesFromCurrentThread = !0, DO(KO, aK._KTX2DecoderModule), new aK._KTX2DecoderModule.KTX2Decoder))) : (aK._KTX2DecoderModule.MSCTranscoder.UseFromWorkerThread = !1, aK._KTX2DecoderModule.WASMMemoryManager.LoadBinariesFromCurrentThread = !0, aK._DecoderModulePromise = Promise.resolve(new aK._KTX2DecoderModule.KTX2Decoder))
      }
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : aK.DefaultNumWorkers;
        this._engine = OO;
        const pO = "object" === typeof KO && KO.workerPool || aK.WorkerPool;
        if (pO) aK._WorkerPoolPromise = Promise.resolve(pO);
        else {
          "object" === typeof KO ? aK._KTX2DecoderModule = KO?.binariesAndModulesContainer?.jsDecoderModule : "undefined" !== typeof KTX2DECODER && (aK._KTX2DecoderModule = KTX2DECODER);
          const OO = "number" === typeof KO ? KO : KO.numWorkers ?? aK.DefaultNumWorkers;
          aK._Initialize(OO)
        }
      }
      async _uploadAsync(OO, KO, pO) {
        const XO = await this._decodeAsync(OO, pO);
        this._createTexture(XO, KO, pO)
      }
      async _decodeAsync(OO, KO) {
        const pO = this._engine.getCaps(),
          XO = {
            astc: !!pO.astc,
            bptc: !!pO.bptc,
            s3tc: !!pO.s3tc,
            pvrtc: !!pO.pvrtc,
            etc2: !!pO.etc2,
            etc1: !!pO.etc1
          };
        if (aK._WorkerPoolPromise) {
          const pO = await aK._WorkerPoolPromise;
          return await new Promise(((bK, eO) => {
            pO.push(((pO, lO) => {
              const vK = OO => {
                  pO.removeEventListener("error", vK), pO.removeEventListener("message", CO), eO(OO), lO()
                },
                CO = OO => {
                  "decoded" === OO.data.action && (pO.removeEventListener("error", vK), pO.removeEventListener("message", CO), OO.data.success ? bK(OO.data.decodedData) : eO({
                    message: OO.data.Tl
                  }), lO())
                };
              pO.addEventListener("error", vK), pO.addEventListener("message", CO), pO.postMessage({
                action: "setDefaultDecoderOptions",
                options: aK.DefaultDecoderOptions._getKTX2DecoderOptions()
              });
              const hO = new Uint8Array(OO.byteLength);
              hO.set(new Uint8Array(OO.buffer, OO.byteOffset, OO.byteLength)), pO.postMessage({
                action: "decode",
                data: hO,
                caps: XO,
                options: KO
              }, [hO.buffer])
            }))
          }))
        }
        if (aK._DecoderModulePromise) {
          const XO = await aK._DecoderModulePromise;
          return aK.DefaultDecoderOptions.isDirty && (aK._KTX2DecoderModule.KTX2Decoder.DefaultDecoderOptions = aK.DefaultDecoderOptions._getKTX2DecoderOptions()), await new Promise(((bK, eO) => {
            XO.decode(OO, pO, KO).then((OO => {
              bK(OO)
            })).catch((OO => {
              eO({
                message: OO
              })
            }))
          }))
        }
        throw new Error("KTX2 decoder module is not available")
      }
      _createTexture(OO, KO, pO) {
        if ((OO.layerCount ?? 1) > 1) throw new Error("KTX2 container - array textures are not supported by this texture loader.");
        this._engine._bindTextureDirectly(3553, KO), pO && (pO.transcodedFormat = OO.transcodedFormat, pO.isInGammaSpace = OO.isInGammaSpace, pO.hasAlpha = OO.hasAlpha, pO.transcoderName = OO.transcoderName);
        let XO = !0;
        switch (OO.transcodedFormat) {
          case 32856:
            KO.type = 0, KO.format = 5;
            break;
          case 33321:
            KO.type = 0, KO.format = 6;
            break;
          case 33323:
            KO.type = 0, KO.format = 7;
            break;
          default:
            KO.format = OO.transcodedFormat, XO = !1
        }
        if (KO._gammaSpace = OO.isInGammaSpace, KO.generateMipMaps = OO.mipmaps.length > 1, KO.width = OO.mipmaps[0].width, KO.height = OO.mipmaps[0].height, OO.errors) throw new Error("KTX2 container - could not transcode the data. " + OO.errors);
        for (let bK = 0; bK < OO.mipmaps.length; ++bK) {
          const pO = OO.mipmaps[bK];
          if (!pO || !pO.data) throw new Error("KTX2 container - could not transcode one of the image");
          XO ? (KO.width = pO.width, KO.height = pO.height, this._engine._uploadDataToTextureDirectly(KO, pO.data, 0, bK, void 0, !0)) : this._engine._uploadCompressedDataToTextureDirectly(KO, OO.transcodedFormat, pO.width, pO.height, pO.data, 0, bK)
        }
        KO._extension = ".ktx2", KO.isReady = !0, this._engine._bindTextureDirectly(3553, null)
      }
      static IsValid(OO) {
        if (OO.byteLength >= 12) {
          const KO = new Uint8Array(OO.buffer, OO.byteOffset, 12);
          if (171 === KO[0] && 75 === KO[1] && 84 === KO[2] && 88 === KO[3] && 32 === KO[4] && 50 === KO[5] && 48 === KO[6] && 187 === KO[7] && 13 === KO[8] && 10 === KO[9] && 26 === KO[10] && 10 === KO[11]) return !0
        }
        return !1
      }
    }

    function oO(OO) {
      switch (OO) {
        case 35916:
          return 33776;
        case 35918:
          return 33778;
        case 35919:
          return 33779;
        case 37493:
          return 37492;
        case 37497:
          return 37496;
        case 37495:
          return 37494;
        case 37840:
          return 37808;
        case 37841:
          return 37809;
        case 37842:
          return 37810;
        case 37843:
          return 37811;
        case 37844:
          return 37812;
        case 37845:
          return 37813;
        case 37846:
          return 37814;
        case 37847:
          return 37815;
        case 37848:
          return 37816;
        case 37849:
          return 37817;
        case 37850:
          return 37818;
        case 37851:
          return 37819;
        case 37852:
          return 37820;
        case 37853:
          return 37821;
        case 36493:
          return 36492
      }
      return null
    }
    aK.URLConfig = {
      jsDecoderModule: "https://cdn.babylonjs.com/babylon.ktx2Decoder.js",
      wasmUASTCToASTC: null,
      wasmUASTCToBC7: null,
      wasmUASTCToRGBA_UNORM: null,
      wasmUASTCToRGBA_SRGB: null,
      wasmUASTCToR8_UNORM: null,
      wasmUASTCToRG8_UNORM: null,
      jsMSCTranscoder: null,
      wasmMSCTranscoder: null,
      wasmZSTDDecoder: null
    }, aK.DefaultNumWorkers = aK.GetDefaultNumWorkers(), aK.DefaultDecoderOptions = new class {
      constructor() {
        this._isDirty = !0, this._useRGBAIfOnlyBC1BC3AvailableWhenUASTC = !0, this._ktx2DecoderOptions = {}
      }
      get isDirty() {
        return this._isDirty
      }
      get useRGBAIfASTCBC7NotAvailableWhenUASTC() {
        return this._useRGBAIfASTCBC7NotAvailableWhenUASTC
      }
      set useRGBAIfASTCBC7NotAvailableWhenUASTC(OO) {
        this._useRGBAIfASTCBC7NotAvailableWhenUASTC !== OO && (this._useRGBAIfASTCBC7NotAvailableWhenUASTC = OO, this._isDirty = !0)
      }
      get useRGBAIfOnlyBC1BC3AvailableWhenUASTC() {
        return this._useRGBAIfOnlyBC1BC3AvailableWhenUASTC
      }
      set useRGBAIfOnlyBC1BC3AvailableWhenUASTC(OO) {
        this._useRGBAIfOnlyBC1BC3AvailableWhenUASTC !== OO && (this._useRGBAIfOnlyBC1BC3AvailableWhenUASTC = OO, this._isDirty = !0)
      }
      get forceRGBA() {
        return this._forceRGBA
      }
      set forceRGBA(OO) {
        this._forceRGBA !== OO && (this._forceRGBA = OO, this._isDirty = !0)
      }
      get forceR8() {
        return this._forceR8
      }
      set forceR8(OO) {
        this._forceR8 !== OO && (this._forceR8 = OO, this._isDirty = !0)
      }
      get forceRG8() {
        return this._forceRG8
      }
      set forceRG8(OO) {
        this._forceRG8 !== OO && (this._forceRG8 = OO, this._isDirty = !0)
      }
      get bypassTranscoders() {
        return this._bypassTranscoders
      }
      set bypassTranscoders(OO) {
        this._bypassTranscoders !== OO && (this._bypassTranscoders = OO, this._isDirty = !0)
      }
      _getKTX2DecoderOptions() {
        if (!this._isDirty) return this._ktx2DecoderOptions;
        this._isDirty = !1;
        const OO = {};
        return void 0 !== this._useRGBAIfASTCBC7NotAvailableWhenUASTC && (OO.useRGBAIfASTCBC7NotAvailableWhenUASTC = this._useRGBAIfASTCBC7NotAvailableWhenUASTC), void 0 !== this._forceRGBA && (OO.forceRGBA = this._forceRGBA), void 0 !== this._forceR8 && (OO.forceR8 = this._forceR8), void 0 !== this._forceRG8 && (OO.forceRG8 = this._forceRG8), void 0 !== this._bypassTranscoders && (OO.bypassTranscoders = this._bypassTranscoders), this.useRGBAIfOnlyBC1BC3AvailableWhenUASTC && (OO.transcodeFormatDecisionTree = {
          UASTC: {
            transcodeFormat: [lO.BC1_RGB, lO.BC3_RGBA],
            yes: {
              transcodeFormat: lO.RGBA32,
              engineFormat: 32856,
              roundToMultiple4: !1
            }
          }
        }), this._ktx2DecoderOptions = OO, OO
      }
    };
    class FO {
      constructor() {
        this.supportCascades = !1
      }
      loadCubeData(OO, KO, pO, XO) {
        if (Array.isArray(OO)) return;
        KO._invertVScale = !KO.invertY;
        const eO = KO.qb(),
          lO = new bK(OO, 6),
          vK = oO(lO.glInternalFormat);
        null !== vK ? (KO.format = vK, KO._useSRGBBuffer = eO._getUseSRGBBuffer(!0, !KO.generateMipMaps), KO._gammaSpace = !0) : KO.format = lO.glInternalFormat;
        const CO = lO.numberOfMipmapLevels > 1 && KO.generateMipMaps;
        eO._unpackFlipY(!0), lO.uploadLevels(KO, KO.generateMipMaps), KO.width = lO.pixelWidth, KO.height = lO.pixelHeight, eO._setCubeMapTextureParams(KO, CO, lO.numberOfMipmapLevels - 1), KO.isReady = !0, KO.onLoadedObservable.notifyObservers(KO), KO.onLoadedObservable.clear(), XO && XO()
      }
      loadData(OO, KO, pO, eO) {
        if (bK.IsValid(OO)) {
          KO._invertVScale = !KO.invertY;
          const XO = new bK(OO, 1),
            eO = oO(XO.glInternalFormat);
          null !== eO ? (KO.format = eO, KO._useSRGBBuffer = KO.qb()._getUseSRGBBuffer(!0, !KO.generateMipMaps), KO._gammaSpace = !0) : KO.format = XO.glInternalFormat, pO(XO.pixelWidth, XO.pixelHeight, KO.generateMipMaps, !0, (() => {
            XO.uploadLevels(KO, KO.generateMipMaps)
          }), XO.isInvalid)
        } else if (aK.IsValid(OO)) {
          new aK(KO.qb())._uploadAsync(OO, KO, eO).then((() => {
            pO(KO.width, KO.height, KO.generateMipMaps, !0, (() => {}), !1)
          }), (OO => {
            XO.b.Warn(`Failed to load KTX2 texture data: ${OO.message}`), pO(0, 0, !1, !1, (() => {}), !0)
          }))
        } else XO.b.Error("texture missing KTX identifier"), pO(0, 0, !1, !1, (() => {}), !0)
      }
    }
  },
  39862: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK
    });
    class XO {
      constructor(OO) {
        this._pendingActions = new Array, this._workerInfos = OO.map((OO => ({
          workerPromise: Promise.resolve(OO),
          idle: !0
        })))
      }
      dispose() {
        for (const OO of this._workerInfos) OO.workerPromise.then((OO => {
          OO.terminate()
        }));
        this._workerInfos.length = 0, this._pendingActions.length = 0
      }
      push(OO) {
        this._executeOnIdleWorker(OO) || this._pendingActions.push(OO)
      }
      _executeOnIdleWorker(OO) {
        for (const KO of this._workerInfos)
          if (KO.idle) return this._execute(KO, OO), !0;
        return !1
      }
      _execute(OO, KO) {
        OO.idle = !1, OO.workerPromise.then((pO => {
          KO(pO, (() => {
            const KO = this._pendingActions.shift();
            KO ? this._execute(OO, KO) : OO.idle = !0
          }))
        }))
      }
    }
    class bK extends XO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : bK.DefaultOptions;
        super([]), this._maxWorkers = OO, this._createWorkerAsync = KO, this._options = pO
      }
      push(OO) {
        if (!this._executeOnIdleWorker(OO))
          if (this._workerInfos.length < this._maxWorkers) {
            const KO = {
              workerPromise: this._createWorkerAsync(),
              idle: !1
            };
            this._workerInfos.push(KO), this._execute(KO, OO)
          } else this._pendingActions.push(OO)
      }
      _execute(OO, KO) {
        OO.timeoutId && (clearTimeout(OO.timeoutId), delete OO.timeoutId), super._execute(OO, ((pO, XO) => {
          KO(pO, (() => {
            XO(), OO.idle && (OO.timeoutId = setTimeout((() => {
              OO.workerPromise.then((OO => {
                OO.terminate()
              }));
              const KO = this._workerInfos.indexOf(OO); - 1 !== KO && this._workerInfos.splice(KO, 1)
            }), this._options.idleTimeElapsedBeforeRelease))
          }))
        }))
      }
    }
    bK.DefaultOptions = {
      idleTimeElapsedBeforeRelease: 1e3
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);