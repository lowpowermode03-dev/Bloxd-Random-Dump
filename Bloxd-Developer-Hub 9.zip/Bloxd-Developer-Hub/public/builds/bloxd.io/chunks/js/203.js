export const id = 203;
export const ids = [203];
export const modules = {
  39548: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      MobPreview: () => MO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(39553),
      vK = pO(35338),
      CO = pO(39555),
      hO = pO(976);

    function DO(OO) {
      return vK.e.openMob(OO)
    }
    const MO = (0, XO.memo)((function(OO) {
      let {
        mobType: KO,
        variation: pO = null,
        animation: bK = CO.h,
        className: vK
      } = OO;
      const MO = (0, XO.useRef)(null),
        aK = (0, XO.useMemo)((() => ({
          mobType: KO,
          variation: pO,
          animation: bK
        })), [KO, pO, bK]);
      return (0, lO.b)(MO, DO, aK), (0, hO.jsx)("div", {
        className: eO()("MobPreview", vK),
        ref: MO
      })
    }))
  },
  39553: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO
    });
    var XO = pO(63),
      bK = pO(2209);

    function eO(OO, KO, pO) {
      const eO = (0, XO.useRef)(null),
        {
          width: lO,
          height: vK
        } = (0, bK.d)(OO);
      (0, XO.useEffect)((() => {
        const pO = KO(OO.current);
        return eO.current = pO, () => {
          pO.close(), eO.current = null
        }
      }), [OO, KO]), (0, XO.useEffect)((() => {
        lO <= 0 || vK <= 0 || eO.current.resize(lO, vK)
      }), [lO, vK]), (0, XO.useEffect)((() => {
        eO.current.show(pO)
      }), [pO])
    }
  },
  39555: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => aK,
      f: () => MO,
      h: () => CO
    });
    var XO = pO(35966),
      bK = pO(37020);

    function eO(OO, KO) {
      let [pO, XO, bK] = OO;
      return [0, .5, 1].map((OO => ({
        timeFraction: OO,
        rotation: {
          U6: "catmull-rom-spline",
          point: [pO, XO, bK + (.5 === OO ? KO : 0)]
        }
      })))
    }

    function lO(OO, KO, pO) {
      return {
        w6: 3200,
        loop: !0,
        r4: {
          Root: {
            timeline: [0, .5, 1].map((OO => ({
              timeFraction: OO,
              position: {
                U6: "catmull-rom-spline",
                point: [0, .5 === OO ? .18 : 0, 0]
              }
            })))
          },
          HeadMesh: {
            timeline: [0, .25, .75, 1].map((OO => ({
              timeFraction: OO,
              rotation: {
                U6: "catmull-rom-spline",
                point: [0, .25 === OO ? .12 : .75 === OO ? -.12 : 0, 0]
              }
            })))
          },
          ArmLeftMesh: {
            timeline: eO(OO, pO)
          },
          ArmRightMesh: {
            timeline: eO(KO, -pO)
          }
        }
      }
    }
    const vK = lO([0, 0, 0], [0, 0, 0], .07),
      CO = (0, bK.d)((0, XO.g)(vK), "mobIdle"),
      hO = lO([-.2 * Math.PI, -.15 * Math.PI, 0], [-.1 * Math.PI, .18 * Math.PI, 0], .02),
      DO = lO([-.4 * Math.PI, -.15 * Math.PI, 0], [-.3 * Math.PI, .18 * Math.PI, 0], .02),
      MO = (0, bK.d)((0, XO.g)(hO), "gunReady"),
      aK = (0, bK.d)((0, XO.g)(DO), "gunAimed")
  },
  35338: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO.b
    });
    var XO = pO(35340);
    class bK {
      constructor(OO) {
        this.load = OO, this.loaded = null, this.loading = null
      }
      run(OO) {
        return null !== this.loaded ? OO(this.loaded) : (this.loading ??= this.load().then((OO => (this.loaded = OO, OO)), (OO => {
          throw this.loading = null, OO
        })), this.loading.then(OO))
      }
    }
    class eO {
      constructor() {
        this.mobScene = new bK((() => Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(65), pO.e(233), pO.e(63), pO.e(64), pO.e(243), pO.e(237), pO.e(242), pO.e(240), pO.e(232), pO.e(206), pO.e(271), pO.e(211), pO.e(225), pO.e(238), pO.e(241), pO.e(127), pO.e(183), pO.e(207), pO.e(219), pO.e(205), pO.e(105), pO.e(103), pO.e(272), pO.e(147)]).then((() => pO(39228))))), this.characterScene = new bK((() => Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(65), pO.e(233), pO.e(63), pO.e(64), pO.e(243), pO.e(237), pO.e(242), pO.e(240), pO.e(232), pO.e(206), pO.e(271), pO.e(211), pO.e(225), pO.e(238), pO.e(241), pO.e(127), pO.e(183), pO.e(207), pO.e(219), pO.e(205), pO.e(105), pO.e(103), pO.e(272), pO.e(146)]).then((() => pO(39319)))))
      }
      openMob(OO) {
        return this.mobScene.run((KO => KO.openMobPreview(OO)))
      }
      openPet(OO) {
        return this.mobScene.run((KO => KO.openPetPreview(OO)))
      }
      openMobLineup(OO) {
        return this.mobScene.run((KO => KO.openMobLineupPreview(OO)))
      }
      openCharacter(OO) {
        return this.characterScene.run((KO => KO.openCharacterPreview(OO)))
      }
    }
    XO.b.setDefaultHost((() => new eO))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);