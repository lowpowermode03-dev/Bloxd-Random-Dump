export const id = 207;
export const ids = [207];
export const modules = {
  36873: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => FO
    });
    var XO = pO(171),
      bK = pO(36011);
    const eO = 1.2,
      lO = {
        poseRig: "golem",
        physicsBodyDimensions: {
          width: .5,
          height: 2.5
        },
        hitBoxDimensions: {
          width: 2.2,
          height: 2.8
        },
        eyeHeight: 2.3,
        rideHeight: 2.3,
        Re: .5,
        QCO: !1
      },
      vK = {
        physicsBodyDimensions: {
          width: .5,
          height: 2.5
        },
        hitBoxDimensions: {
          width: 1.8,
          height: 2.6
        },
        eyeHeight: 2.3,
        rideHeight: 2.3,
        Re: .5,
        QCO: !1
      },
      CO = {
        physicsBodyDimensions: {
          width: XO.h.gM,
          height: XO.h.uD
        },
        hitBoxDimensions: {
          width: XO.h.gM + .4,
          height: XO.h.uD + .6
        },
        eyeHeight: XO.h.uD * XO.h.playerEyeToHeightRatio,
        rideHeight: XO.h.uD - .3,
        Re: .5,
        QCO: !1
      },
      hO = {
        physicsBodyDimensions: {
          width: .5,
          height: .95
        },
        hitBoxDimensions: {
          width: 1.6,
          height: 1.1
        },
        eyeHeight: .9,
        rideHeight: .5,
        Re: .5,
        QCO: !1
      },
      DO = {
        physicsBodyDimensions: {
          width: .5,
          height: 1.8
        },
        hitBoxDimensions: {
          width: 1.7,
          height: 1.9
        },
        eyeHeight: 1.3,
        rideHeight: 1.3,
        Re: .5,
        QCO: !1
      },
      MO = {
        physicsBodyDimensions: {
          width: .5,
          height: 1.9
        },
        hitBoxDimensions: {
          width: 1.5,
          height: 2.1
        },
        eyeHeight: 1.9,
        rideHeight: 1,
        Re: .5,
        QCO: !1
      },
      aK = {
        physicsBodyDimensions: {
          width: .5,
          height: 1.9
        },
        hitBoxDimensions: {
          width: 1.5,
          height: 2.4
        },
        eyeHeight: 2,
        rideHeight: 1.8,
        Re: .5,
        QCO: !1
      },
      oO = {
        Player: {
          defaultName: "Player",
          physicsBodyDimensions: {
            width: XO.h.gM,
            height: XO.h.uD
          },
          hitBoxDimensions: {
            width: XO.h.gM + .4,
            height: XO.h.uD + .6
          },
          eyeHeight: XO.h.uD * XO.h.playerEyeToHeightRatio,
          rideHeight: XO.h.uD - .1,
          Re: bK.d.Re,
          QCO: !0
        },
        Pig: {
          poseNameRise: {
            sitting: 1.4
          },
          physicsBodyDimensions: {
            width: .5,
            height: .8
          },
          hitBoxDimensions: {
            width: 1.5,
            height: 1.2
          },
          eyeHeight: .8,
          rideHeight: .5,
          Re: .5,
          QCO: !1
        },
        Cow: {
          physicsBodyDimensions: {
            width: .5,
            height: 1.1
          },
          hitBoxDimensions: {
            width: 1.6,
            height: 1.4
          },
          eyeHeight: 1.2,
          rideHeight: 1,
          Re: .5,
          QCO: !1
        },
        Sheep: {
          physicsBodyDimensions: {
            width: .5,
            height: 1.1
          },
          hitBoxDimensions: {
            width: 1.6,
            height: 1.3
          },
          eyeHeight: 1.2,
          rideHeight: .8,
          Re: .5,
          QCO: !1
        },
        Horse: {
          physicsBodyDimensions: {
            width: .5,
            height: 1.9
          },
          hitBoxDimensions: {
            width: 1.5,
            height: 2.1
          },
          eyeHeight: 1.9,
          rideHeight: .9,
          Re: .5,
          QCO: !1
        },
        Camel: {
          modelScale: eO,
          physicsBodyDimensions: {
            width: .6,
            height: 2.52
          },
          hitBoxDimensions: {
            width: 1.92,
            height: 2.76
          },
          eyeHeight: 2.52,
          rideHeight: 1.7999999999999998,
          Re: .5,
          QCO: !1
        },
        Slime: {
          physicsBodyDimensions: {
            width: .6,
            height: .8
          },
          hitBoxDimensions: {
            width: 1,
            height: .9
          },
          eyeHeight: .5,
          rideHeight: .5,
          Re: .5,
          QCO: !1
        },
        "Cave Golem": lO,
        "Draugr Zombie": {
          ...CO,
          defaultPose: "zombie"
        },
        "Draugr Skeleton": CO,
        "Frost Golem": lO,
        "Frost Zombie": {
          ...CO,
          defaultPose: "zombie"
        },
        "Frost Skeleton": CO,
        "Draugr Knight": {
          physicsBodyDimensions: {
            width: XO.h.gM,
            height: XO.h.uD
          },
          hitBoxDimensions: {
            width: XO.h.gM + .4,
            height: 2.8
          },
          eyeHeight: 1.9,
          rideHeight: 1.8,
          Re: .5,
          QCO: !1
        },
        Wolf: hO,
        Bear: DO,
        Deer: {
          physicsBodyDimensions: {
            width: .5,
            height: 1.9
          },
          hitBoxDimensions: {
            width: 1.5,
            height: 2.1
          },
          eyeHeight: 1.8,
          rideHeight: .8,
          Re: .5,
          QCO: !1
        },
        Stag: MO,
        "Gold Watermelon Stag": {
          physicsBodyDimensions: {
            width: .5,
            height: 1.9
          },
          hitBoxDimensions: {
            width: 1.5,
            height: 2.1
          },
          eyeHeight: 1.9,
          rideHeight: 1,
          Re: .5,
          QCO: !1
        },
        Gorilla: aK,
        Wildcat: {
          physicsBodyDimensions: {
            width: .5,
            height: .7
          },
          hitBoxDimensions: {
            width: 1.5,
            height: .7
          },
          eyeHeight: .55,
          rideHeight: .4,
          Re: .5,
          QCO: !1
        },
        "Draugr Huntress": CO,
        "Magma Golem": lO,
        "Spirit Golem": lO,
        "Spirit Wolf": hO,
        "Spirit Bear": DO,
        "Spirit Stag": MO,
        "Spirit Gorilla": aK,
        "Draugr Warper": {
          physicsBodyDimensions: {
            width: .5,
            height: 2.5
          },
          hitBoxDimensions: {
            width: .6,
            height: 3
          },
          eyeHeight: 2.4,
          rideHeight: 2.8,
          Re: .5,
          QCO: !1
        },
        "Frost Wraith": {
          poseRig: "wraith",
          physicsBodyDimensions: {
            width: .5,
            height: 2.7
          },
          hitBoxDimensions: {
            width: .6,
            height: 2.8
          },
          eyeHeight: 2.3,
          rideHeight: 2.6,
          Re: .5,
          QCO: !1
        },
        "Draugr Reaver": {
          physicsBodyDimensions: {
            width: .5,
            height: 2.6
          },
          hitBoxDimensions: {
            width: .6,
            height: 2.7
          },
          eyeHeight: 2.2,
          rideHeight: 2.5,
          Re: .5,
          QCO: !1
        },
        NPC: {
          physicsBodyDimensions: {
            width: XO.h.gM,
            height: XO.h.uD
          },
          hitBoxDimensions: {
            width: XO.h.gM + .4,
            height: XO.h.uD + .6
          },
          eyeHeight: XO.h.uD * XO.h.playerEyeToHeightRatio,
          rideHeight: XO.h.uD - .1,
          Re: .5,
          QCO: !1
        },
        67: {
          physicsBodyDimensions: {
            width: .5,
            height: 2.5
          },
          hitBoxDimensions: {
            width: 3,
            height: 2.5
          },
          eyeHeight: 1.9,
          rideHeight: 2.5,
          Re: .5,
          QCO: !1
        },
        "Bobino Musculino": {
          physicsBodyDimensions: {
            width: XO.h.gM,
            height: XO.h.uD
          },
          hitBoxDimensions: {
            width: XO.h.gM + .4,
            height: XO.h.uD + .6
          },
          eyeHeight: XO.h.uD * XO.h.playerEyeToHeightRatio,
          rideHeight: XO.h.uD - .1,
          Re: .5,
          QCO: !1
        },
        "Capitano Explovissimo": {
          physicsBodyDimensions: {
            width: .5,
            height: 1.8
          },
          hitBoxDimensions: {
            width: .5,
            height: 2.5
          },
          eyeHeight: 1.5,
          rideHeight: 2,
          Re: .5,
          QCO: !1
        },
        "Desert Fennec": {
          physicsBodyDimensions: {
            width: .4,
            height: .8
          },
          hitBoxDimensions: {
            width: .8,
            height: .8
          },
          eyeHeight: .65,
          rideHeight: .6,
          Re: .5,
          QCO: !1
        },
        "Armour Collector": {
          physicsBodyDimensions: {
            width: 1,
            height: 3.5
          },
          hitBoxDimensions: {
            width: 2,
            height: 3.7
          },
          eyeHeight: 3.1,
          rideHeight: 3.6,
          Re: .5,
          QCO: !1
        },
        "Furnace Knight": {
          physicsBodyDimensions: {
            width: .8,
            height: 2.4
          },
          hitBoxDimensions: {
            width: 1.6,
            height: 2.5
          },
          eyeHeight: 2,
          rideHeight: 2.45,
          Re: .5,
          QCO: !1
        },
        "Lil Knight": {
          physicsBodyDimensions: {
            width: .8,
            height: 2.4
          },
          hitBoxDimensions: {
            width: 1.6,
            height: 2.55
          },
          eyeHeight: 2,
          rideHeight: 2.5,
          Re: .5,
          QCO: !1
        },
        "Glass Gremlin": {
          physicsBodyDimensions: {
            width: .6,
            height: 2.5
          },
          hitBoxDimensions: {
            width: 1,
            height: 2.6
          },
          eyeHeight: 2.2,
          rideHeight: 2.55,
          Re: .5,
          QCO: !1
        },
        "Glass Bro": {
          physicsBodyDimensions: {
            width: .8,
            height: 2.1
          },
          hitBoxDimensions: {
            width: 1.3,
            height: 2.2
          },
          eyeHeight: 1.8,
          rideHeight: 2.1,
          Re: .5,
          QCO: !1
        },
        "Lord Vulcan": {
          physicsBodyDimensions: {
            width: 1.2,
            height: 5.4
          },
          hitBoxDimensions: {
            width: 2.4,
            height: 5.4
          },
          eyeHeight: 4.1,
          rideHeight: 5.4,
          Re: .5,
          QCO: !1
        },
        Zombie: {
          ...CO,
          defaultPose: "zombie"
        },
        Skeleton: CO,
        Mummy: {
          ...CO,
          defaultPose: "zombie"
        },
        Scorpion: {
          physicsBodyDimensions: {
            width: 1,
            height: .9
          },
          hitBoxDimensions: {
            width: 1.6,
            height: 1.4
          },
          eyeHeight: .6,
          rideHeight: .9,
          Re: .5,
          QCO: !1
        },
        Vulcanite: {
          physicsBodyDimensions: {
            width: .8,
            height: 2
          },
          hitBoxDimensions: {
            width: 1.3,
            height: 2.1
          },
          eyeHeight: 1.6,
          rideHeight: 2.1,
          Re: .5,
          QCO: !1
        },
        "Evil Tome": {
          physicsBodyDimensions: {
            width: .6,
            height: .9
          },
          hitBoxDimensions: {
            width: .9,
            height: .95
          },
          eyeHeight: .6,
          rideHeight: .95,
          Re: .5,
          QCO: !1
        },
        "Magma Toad": {
          physicsBodyDimensions: {
            width: 1,
            height: 1
          },
          hitBoxDimensions: {
            width: 1.5,
            height: 1.15
          },
          eyeHeight: 1,
          rideHeight: 1.1,
          Re: .5,
          QCO: !1
        },
        Stalker: {
          physicsBodyDimensions: {
            width: .5,
            height: 2.6
          },
          hitBoxDimensions: {
            width: .6,
            height: 2.9
          },
          eyeHeight: 2.4,
          rideHeight: 2.5,
          Re: .5,
          QCO: !1
        },
        Crone: {
          turnRate: 1.2,
          physicsBodyDimensions: {
            width: .6,
            height: 2.9
          },
          hitBoxDimensions: {
            width: .7,
            height: 3.2
          },
          eyeHeight: 2.7,
          rideHeight: 2.8,
          Re: .5,
          QCO: !1
        },
        "Iron Guardian": vK,
        "Gold Guardian": vK,
        "Diamond Guardian": vK,
        "Moonstone Guardian": vK,
        "Iron Goofy Golem": vK,
        "Gold Goofy Golem": vK,
        "Diamond Goofy Golem": vK,
        "Moonstone Goofy Golem": vK,
        "Tiki Terror": {
          poseRig: "tiki",
          physicsBodyDimensions: {
            width: 1,
            height: 4.3
          },
          hitBoxDimensions: {
            width: 2.4,
            height: 4.5
          },
          eyeHeight: 3.9,
          rideHeight: 4.3,
          Re: .5,
          QCO: !1
        }
      };

    function FO(OO) {
      return oO[OO]
    }
  },
  35526: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    const XO = {
      "skyblock:forged:astral-astral-astral": {
        name: "Heart of the Cosmos",
        lore: "Three shards of the night sky, forged as one. The stars answer whoever holds it.",
        damageMultiplier: 1.8,
        cooldownMultiplier: .8,
        ability: "starfall"
      },
      "skyblock:forged:astral-moonstone-sanguine": {
        name: "Eclipse Edge",
        lore: "Moonlight over starlight over blood: the sky goes dark wherever it is drawn.",
        damageMultiplier: 1.7,
        cooldownMultiplier: .81,
        ability: "eclipseField"
      },
      "skyblock:forged:astral-diamond-moonstone": {
        name: "Starcutter",
        lore: "A blade so sharp the Forge Mother swears it once cut a falling star in two.",
        damageMultiplier: 1.65,
        cooldownMultiplier: .83,
        ability: "starfall"
      },
      "skyblock:forged:astral-sanguine-magmasteel": {
        name: "Triune Flame",
        lore: "Each of Lord Vulcan's three faces, bound into one burning edge.",
        damageMultiplier: 1.65,
        cooldownMultiplier: .83,
        ability: "magmaWave"
      },
      "skyblock:forged:magmasteel-magmasteel-magmasteel": {
        name: "Vulcan's Bane",
        lore: "Forged in the heat of his own rift. It remembers the way down.",
        damageMultiplier: 1.56,
        cooldownMultiplier: .83,
        ability: "magmaWave"
      },
      "skyblock:forged:magmasteel-astral-sanguine": {
        name: "Comet's Wake",
        lore: "It leaves a trail of fire through the air, like something falling from very far up.",
        damageMultiplier: 1.56,
        cooldownMultiplier: .83,
        ability: "starfall"
      },
      "skyblock:forged:magmasteel-sanguine-astral": {
        name: "Vulcan's Ruin",
        lore: "The Forge Mother made only one, then sat down for a long while.",
        damageMultiplier: 1.6,
        cooldownMultiplier: .83,
        ability: "warcry"
      },
      "skyblock:forged:magmasteel-iron-stone": {
        name: "Forgehand",
        lore: "A smith's sword: plain to look at, and it hits like a hammer.",
        damageMultiplier: 1.4,
        cooldownMultiplier: .9,
        ability: "quake"
      },
      "skyblock:forged:sanguine-sanguine-sanguine": {
        name: "Crimson Covenant",
        lore: "It drinks, and so do you.",
        damageMultiplier: 1.53,
        cooldownMultiplier: .83,
        ability: "bloodPact"
      },
      "skyblock:forged:sanguine-astral-moonstone": {
        name: "Nightbloom",
        lore: "A red flower that only opens after dark.",
        damageMultiplier: 1.56,
        cooldownMultiplier: .83,
        ability: "eclipseField"
      },
      "skyblock:forged:sanguine-iron-wood": {
        name: "Butcher's Oath",
        lore: "Heavy, honest and always hungry.",
        damageMultiplier: 1.35,
        cooldownMultiplier: .95,
        ability: "bloodPact"
      },
      "skyblock:forged:moonstone-moonstone-moonstone": {
        name: "Lunar Requiem",
        lore: "Swung, it leaves a pale arc that lingers like a second moon.",
        damageMultiplier: 1.35,
        cooldownMultiplier: .85,
        ability: "moonDash"
      },
      "skyblock:forged:moonstone-astral-moonstone": {
        name: "Silver Tide",
        lore: "Pulled by the same moon that pulls the sea.",
        damageMultiplier: 1.4,
        cooldownMultiplier: .84,
        ability: "moonDash"
      },
      "skyblock:forged:diamond-diamond-diamond": {
        name: "Prism Fang",
        lore: "Every facet catches a different light, and every strike finds a different weakness.",
        damageMultiplier: 1.29,
        cooldownMultiplier: .88,
        ability: "gildedEdge",
        traits: {
          crit: 1.8
        }
      },
      "skyblock:forged:diamond-moonstone-gold": {
        name: "Jeweller's Pride",
        lore: "Too pretty to fight with. Fight with it anyway.",
        damageMultiplier: 1.24,
        cooldownMultiplier: .91,
        ability: "gildedEdge"
      },
      "skyblock:forged:gold-gold-gold": {
        name: "King's Ransom",
        lore: "Worth more than the treasure it guards.",
        damageMultiplier: 1.18,
        cooldownMultiplier: .91,
        ability: "gildedEdge",
        traits: {
          coins: 2.5
        }
      },
      "skyblock:forged:gold-moonstone-gold": {
        name: "Midas Moon",
        lore: "Mobs it fells seem to rattle with coins.",
        damageMultiplier: 1.18,
        cooldownMultiplier: .92,
        ability: "gildedEdge",
        traits: {
          coins: 2,
          bossBane: .6
        }
      },
      "skyblock:forged:iron-iron-iron": {
        name: "Old Faithful",
        lore: "It has never let anyone down. It never will.",
        damageMultiplier: 1.15,
        cooldownMultiplier: .94,
        ability: "warcry"
      },
      "skyblock:forged:iron-wood-wood": {
        name: "Militia Blade",
        lore: "Handed out at the outpost gate when the rift first opened.",
        damageMultiplier: 1.09,
        cooldownMultiplier: .97,
        ability: "warcry"
      },
      "skyblock:forged:stone-stone-stone": {
        name: "Quarryman's Cleaver",
        lore: "Chipped from one block of stone, handle and all.",
        damageMultiplier: 1.09,
        cooldownMultiplier: .97,
        ability: "quake"
      },
      "skyblock:forged:wood-wood-wood": {
        name: "Lorenzo's Lesson",
        lore: "Courage matters more than the blade. This one is mostly courage.",
        damageMultiplier: 1.06,
        cooldownMultiplier: .97,
        ability: "warcry"
      }
    }
  },
  36020: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(266),
      bK = pO.n(XO),
      eO = pO(1531);
    let lO;
    var vK, CO, hO, DO, MO, aK, oO, FO, VO;
    const LO = [0, 1, 8, 255, "length", "b", "c", "d", 50, "e", "undefined", void 0, 4, 3, 63, 6, "fromCodePoint", 7, 12, "push", 164, 79, "h", "a", 9, "g", 91, 188, 8191, 88, 13, 14, 166, 2, 16, 27, 57, "i", 158, 211, 109, 102, 94, 82, 5, 138, 39, null, 10, 171, 147, 231, !1, 122, 116, 127, 128, 129, 130, 124, 125, 126, 131, 132, 133, 142, 143, 144, 145, 146, "Cl", 115, 72, 55, 207, 217, 24, "f", 68, "js", 151, 205, 153, 249, 202, 179, 17, 120, 18, "j", 222, 206, 192, 236, 105, 44, 214, 137, "?", "on"];

    function QO(...OO) {
      return OO[LO[4]] = LO[1], typeof vK[OO[LO[0]]] === LO[10] ? vK[OO[LO[0]]] = function(OO) {
        var KO, pO, XO, bK, eO, lO, vK;
        for (EO(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = LO[0], eO = LO[0], lO = -LO[1]), vK = LO[0]; vK < pO; vK++) {
          var CO = 'FDAy^M9g1${uIj#T[wJ*zp`B(ha|X:W&>_6c/?EC+n4l]Vx5<sUGt2!Pk"=fOrLodYq;vQ)73}m,%8bH@ZN.0~SKRie'.indexOf(KO[vK]);
          if (CO !== -LO[1])
            if (lO < LO[0]) lO = CO;
            else {
              EO(lO += CO * LO[26], bK |= lO << eO, eO += (lO & LO[28]) > LO[29] ? LO[30] : LO[31]);
              do {
                EO(XO.push(bK & LO[3]), bK >>= LO[2], eO -= LO[2])
              } while (eO > LO[17]);
              lO = -LO[1]
            }
        }
        return lO > -LO[1] && XO.push((bK | lO << eO) & LO[3]), zK(XO)
      }(CO[OO[LO[0]]]) : vK[OO[LO[0]]]
    }

    function zK(...OO) {
      return OO[LO[4]] = LO[1], typeof DO !== LO[10] && DO ? (new DO).decode(new MO(OO[LO[0]])) : typeof aK !== LO[10] && aK ? aK.from(OO[LO[0]]).toString("utf-8") : VO(OO[LO[0]])
    }

    function AO() {}
    EO(vK = {}, CO = ['eu(_ZP4+iY?6uUe/#$08L0jQFq38"Z3*fYK$*L%9Ou2X1yIh(O@Gh', 'm9#t7Zu**d"}+5C*Sf]gTU>([Ij,)hIC$m($h+>I$P6%B5":J>Cs:}F', "~f^mIUfcd$S/<yg?A:$|_v%(fuF7yaLWo+y", "Nfg%:rF", "3uR$qL=mPjr", "!V)s8U:5G!XgB#qWCL+W9/!A@2R`%|rcWxu>0%x=G!F[Y3dWhxwGp~F", "[ll>}%:2TT", 'J")}4N%68k4@"O~c*Tv:lN8GTIFvM<;WhYvPNL@t,zQJZ@]C*:p&DSsD)*', "Xx6,|.F", 'u"Qt0U9/u#({6h;&p+^mcb|Q<O)o17%CTx[!GoF', "9^oXf6F", 'tBt{%<snKdng2[^?U<$!`U"50"zQv|cw@Ytg', "kGEX&rO=6THZcAch[!jt$L<t@O+wC)D([7c3E5R@AIq)?r>(Zyk$", 'rBWtVsD2|#TYi<)E"F', "$B1_iV8DZID58/#a/I08h~E@eLm^!rc?vV]{m<z@,u,::^u", ">v[$5sDhx2Gul)^lpobg", "EmW^PN9(q*mm|A", "AIJ>U8.Dh#ea&Euhq+k!F6u*8L<^uA(4V&5^", '"a>W(%)vxJ82%7kc}F', "NzLX@/)J)jvX`Zk4J7^&!)#/bJ", 'ZXLtt=Rtc"@h5#~+GV($16CjJ!v@DhBn@F', "O$I8.LGc{#_#CE%E=$?g#/&cYIFAla5aI?>}zQNtUo+#I|]*EYD", 'A!5!PN7"@2HOD', "8kK9>cKDjL&yGN/(zx,m#Qu2b2GQ]71&gvWtX~jg,LcQI0J67<r{o=pD[p", ">!MtLma1_Tx%V3S+OLb76+Gj^d^vf)owwx(|0UbtYOG", "JG~XV,=JCzms;EXB4+(!0%Yjy*%2l=#", 'm?^MTU9WOwH^SZ_Bk#{3=2}G<T<c"[Y/2!n34,l*v$yGn<i:g!`$|', ":BS^^P.jPzs(@.c&g!)tL3eI]1R823g?xYL%+,/JWf>", "*TS^S~ugLk^6i<Q*27/g2?1(>O>tWr8|MTp&I", 'y$1bA3hZ1z"8wZ:cjI%myxXWLJ', "~G+WwEXA", "U+,8tkvJ%2S)$/::}9KX;xGcHJimKTR:)!X8U=o:=w]Lh^", '#OL&O8OxN!jj|U;W9"!&{/|:&pl', 'BOI&c~wh:L`9pOa4b}^UpU=J{Y63"^S|?7y>K%:c2!sX#rA/tGy', "*:wbxoT2nwh{7aY&>v]{F=at<p*,vOKnID", "Py|8C}^Jjqz9Y^", 'Em=Gh"$Q+=e:k|7(LYt8YZt=L1j6Ah`+ZyO:to3I9P7Dbh_?N?J3{ZF/(w', "+9u8A6`/4zYp5#XW*>7%HU<AWoa3_[/W0VR9M<]+Q!><D", '"+1b]r+/gz{rcE|n', "0zV&rGYDcO0:z7Y/", 'c!$>KVXS^dIv6r*6aYrgS~c"4#', '{:@sIL/teL~I"<jCDOw|&c]x${', "aO^mZ%~w#JN;z7d(!G/g", '[76G#LemVfS)6UA/<YR$v3#1m#(<fEjzxLxP1<kWv$rgdTXcu"s!h+>tbk4', '`$wbn?bm{z#v9Zx+6$Om}%v9A"6Qty|/7G_>>+q=0$UpD[lCTaot0tlgMj', '{>R}N_2o."fpI|VCx+^8&tw:[p*?&Ax+5GOg', '["_,xs~n5O7D/y26Fo%&]c)9d"LDw<ow;?y>O8dIuzz(@y>?P7)sO6rD', 'nmBtt?n"Dq1=P=yJY6u3Lmn*@oH),ap6z!)&]NHg*dAj^|R6n78g', "gvU3DZm(b2tk.A", 'TlE&h+roaL]<)j[zI7Egh}7g5klcJrF4I?@$ZLC"uL(', '8fu8OCfc["!gsOIEDsosAZKcr#=c#Mx*;w~&$StJ8J', "~fy:>bT2wT4Pf)!+*7gWzt8nE*", ".Yb%M2whVJ.U*aIziL:m#PZc9d}ueZkcGV|>$Z9WM{1y7#S`?a1blcF", ":TR$t,zA", "@fhWt0YGsI", "|$n!`%4A", "%G0U)2.~[qY@dTz|T$?{)<EJ&pH)V[LWP!j%8/2c:f$,yE#", ")yG3HP,naL_Yzf7*NYl3[", "MT5t%L7nPz", "h:)t07vxIwz?Ur{", "Hf43/ruj3wayJMXBFp^8eb+AIpixlEq(XOy", "xzB}x)`1NIBL|Am*wlU|EN+I|L78xj#*XTLPa!tA", "o!.8^H$*O#wzR.e[qX^UUkF", "&O.UCr>J8#A?[fUXGV7tR5U=awFzxheco!1G*7|:nwO@F", "%6Qg=0MgN!;@lf4h7G196+jnyds&JrKctym>uLJ(c$|Y0y1&mVD|#", "BvV^c,},gjaPTA;?p7~a7mvvYTa", "3!O:h+LA8Jxq+|{**+J|Q/::)d08j<^(U&;8FHF", "RC3}]v:oR=%x%T_J.GM%ZV#dufVw5EY?p7)7Xc}n<J;XD", "%V*mzUD*f#;p)hc?ypR!kC[tYI?", "IoW$E5I)HT", 'TsU:Z"icizIGHaVCl+P$O)7D', "/$~&&~9JDI", "l&V&H/!+$#D3W#O:4LA", "[O;2Px/W|w@)yNF/v$=>0.|g$#f8!h>wMs2tQ<UWjLv88/hn:vQ%!6gD", "mYBXhtSxD$@huNRX*9(W^O4JdJ@^mQcJ;}W^MHF", ">G7tnr(/p=v>F7mhAl&^mEGj[ol", ".yVPB.>W0$a|2^k6RF", '0}LXP?"nlYN>Ljo:s!m>4kY:Do=t4?>WD"]&OG5*{Y[|RTT', '5&`g4,uZBj8/M[=/mvb$?@{Wy"^3zy9&3yRs3P0@G*<Lgacw,Lz&(7|njLpwD', 'euWPy6Rt^*fJr3sCcI(bl,"DIwDvof_w|+r{', 'DsrPwQZcmfW&8^}at+9%Z"I(v!=u|aYWgxi1', 'TsT$0E&"/d_QwOLwn"@}{Q#)_"KZ[yQJ<&`^', "F^3}`tu*kw<pn^e:<a,>%Ejhg=|=.apn", ".Y87}<]A", '??"!"3F', '^"?Pt)ZDhz4gBE9Js!pP[L06}LSOi<a/M>E&)6F', "QXK%K_P5]#$z1|&wjD", "@y2mQm+A", "aXtvz=af", ".MihEIK|", "@o0%Ls+|", 'pi<v"o,|', "U`04+Gq)", "Z6[uG1^)", "6_0%D;D7CO9W|", "@$ujp3^)Ti~mf", "(F5CX@^hIDrof", "m$nv)b^hb:Eo|", "^}W~AKdmfqJ^|", "ItavJo^huEmVf", '(QH~]a&)BRLpo5F~j}"4{<cl6Sh#$7h', "jRN4IW/owIY^,Zz`7#opB9Z_<jP^ySF", 'ddE1vnhn"DLp)pq:(##ve9MOjizOkah', "c$Oy}9hn4i*@5*]:J5Z17nwzmr<a@*.", "J5yp|!pl6SR^,Zz`7#JpB9Z_XTMVmUT", "E}yp=&vMdizOY6m8Jgsx59dh8APVf", "E#VKW?na", "&yY{FTea", "+qBWuR,,", "qGE&8ZzA", "URxt)/=A", '",*.%UvF', "Lq8P", "iO*PwH=", "L,Zr", '`7.mW7"D', "<5lJ/q7", "tGkpU<bA", "VGi9X`bA", "GGgp", "tG6h4dIA", "KG#<b<{A", "w@6h[ZYA", "23ch{", "tG6hb<{A", "w@kpV|cA", "Ix!S2`tA", "|w!22ZIA", "qMR2$htA", "]M`<ha{A", "9@h&+65A", "Exi91|{A", "2*`</h)F", "_BB2L", "zGkp", "gG6&j", "x3E2z", "9^nMkYyA", "R/=JL", "tG6h4dRji", "1b.gH&n|i", "33?JG&jai", "ExM2v0UA", "2JMSz`7", "ExM2LZVA", "w@!2[<3F", "9@o2,|^A", "z*`</h7", 'w"sK', "ljAt", "]08p", "k*At", "sI.})1(6", "iv>[8B(!", "b2gf?Lxx", "TQ.*7", "DU.p", "ZTyK", "#/oS", "XGchZaxA", "FNrpy_(A", "Vbq<aabA", "oJmS", "Ox=J", "]3M2O65A", "R&mS", "V3m2d<n|fc", ":f;hR`)4ij", "^x|JH&3HW", "c*7RX<jF", "0A[>G2te", "Bd~>rTxtlS:aP){iVufskk+yMmE[Q6{iM`LFMVBX]5[HI,Vd6d^8s", "Bd~>rTxtlS:aP){iVufskk+yMmE[Q6{iaoRF$$=eVr:.qLP7?4", "no[>a%YX0Kf<7~MccoI(@kae:W_.`aV@CpP.F", "{h|w", "~)hUkHDR", "&Phi", "4R}h9%WK", "@2DqCSu", "boCKQpmR", "S=hU:6,R", "8ng_Ida0", "K;bV7$NLJl|9A", "|[O<az+hcyzWA", "~S&Wo{&&q6l9g", "0/3DEzbY]n", '/&CjPsP"(~rX|)r2y0t', 'Hg8;i2U"vy,!|)V/@9g', "Y<6V|v1Fv`W?g0soj1t", "r2ABrLV$?p,9|)SJK<g", "},G4MKf|cSw8?=@4pH2*%oa9_i", "uF9!a.I9/+becvy4@,9!NrD_!B", '?<6$z:gnDJrrIK)40slDh:1"Bm', "}!!VdrR~pJ7~eK4qtbctG:H)Bm", ".!!V7XA1oP@9tU*JO?u*bjD_AB", '?<6$#L]7HJ):I:C`tb8tkrC&"J', '"!<vcraHy5,:l|C`n=I;:jWHiB', "8Puic^0", 'nk"P~1HB', "puF}[", "0M`<ha{A", "V3m2oheA"]), EO(hO = function(...OO) {
      EO(OO[LO[4]] = LO[0], OO[-LO[8]] = [function() {
        return globalThis
      }, function() {
        return global
      }, function() {
        return window
      }, function() {
        return new Function("return this")()
      }], OO[LO[5]] = LO[11], OO[LO[6]] = []);
      try {
        EO(OO[LO[5]] = Object, OO[LO[6]][LO[19]]("".__proto__.constructor.name))
      } catch (CO) {}
      OO: for (OO[LO[7]] = LO[0]; OO[LO[7]] < OO[-LO[8]][LO[4]]; OO[LO[7]]++) try {
        for (OO[LO[5]] = OO[-LO[8]][OO[LO[7]]](), OO[LO[9]] = LO[0]; OO[LO[9]] < OO[LO[6]][LO[4]]; OO[LO[9]]++)
          if (typeof OO[LO[5]][OO[LO[6]][OO[LO[9]]]] === LO[10]) continue OO;
        return OO[LO[5]]
      } catch (CO) {}
      return OO[LO[5]] || this
    }() || {}, DO = hO.TextDecoder, MO = hO.Uint8Array, aK = hO.jb, oO = hO.String || String, FO = hO.Array || Array, VO = function(...OO) {
      return EO(OO[LO[4]] = LO[0], OO[LO[20]] = new FO(LO[56]), OO[LO[5]] = oO[LO[16]] || oO.fromCharCode, OO[LO[6]] = []),
        function(...KO) {
          for (EO(KO[LO[4]] = LO[1], KO[LO[1]] = LO[11], KO[LO[5]] = LO[11], KO[LO[13]] = KO[LO[0]][LO[4]], OO[LO[6]][LO[4]] = LO[0]), KO[LO[12]] = LO[0]; KO[LO[12]] < KO[LO[13]];) EO(KO[LO[5]] = KO[LO[0]][KO[LO[12]]++], KO[LO[5]] <= LO[55] ? KO[LO[1]] = KO[LO[5]] : KO[LO[5]] <= 223 ? KO[LO[1]] = (31 & KO[LO[5]]) << LO[15] | KO[LO[0]][KO[LO[12]]++] & LO[14] : KO[LO[5]] <= 239 ? KO[LO[1]] = (15 & KO[LO[5]]) << LO[18] | (KO[LO[0]][KO[LO[12]]++] & LO[14]) << LO[15] | KO[LO[0]][KO[LO[12]]++] & LO[14] : oO[LO[16]] ? KO[LO[1]] = (KO[LO[5]] & LO[17]) << LO[88] | (KO[LO[0]][KO[LO[12]]++] & LO[14]) << LO[18] | (KO[LO[0]][KO[LO[12]]++] & LO[14]) << LO[15] | KO[LO[0]][KO[LO[12]]++] & LO[14] : (KO[LO[1]] = LO[14], KO[LO[12]] += LO[13]), OO[LO[6]][LO[19]](OO[LO[20]][KO[LO[1]]] || (OO[LO[20]][KO[LO[1]]] = OO[LO[5]](KO[LO[1]]))));
          return OO[LO[6]].join("")
        }
    }()), QO(87) in AO && function(...OO) {
      function KO(...OO) {
        for (EO(OO[LO[4]] = LO[1], OO[LO[23]] = 'f|)xZ.hTXA>NF*:Q8iqw{?/}7$4v9(y%~+`6!5&[<,2"0]^z#pClrEJjdVURISDOnWLH3@o1bg_=u;GKactYkMmPsBe', OO[-LO[21]] = "" + (OO[LO[0]] || ""), OO[LO[6]] = OO[-LO[21]].length, OO[LO[32]] = [], OO[LO[1]] = LO[0], OO[-LO[27]] = LO[0], OO[LO[25]] = -LO[1]), OO[LO[22]] = LO[0]; OO[LO[22]] < OO[LO[6]]; OO[LO[22]]++)
          if (OO[LO[24]] = OO[LO[23]].indexOf(OO[-LO[21]][OO[LO[22]]]), OO[LO[24]] !== -LO[1])
            if (OO[LO[25]] < LO[0]) OO[LO[25]] = OO[LO[24]];
            else {
              EO(OO[LO[25]] += OO[LO[24]] * LO[26], OO[LO[1]] |= OO[LO[25]] << OO[-LO[27]], OO[-LO[27]] += (OO[LO[25]] & LO[28]) > LO[29] ? LO[30] : LO[31]);
              do {
                EO(OO[LO[32]].push(OO[LO[1]] & LO[3]), OO[LO[1]] >>= LO[2], OO[-LO[27]] -= LO[2])
              } while (OO[-LO[27]] > LO[17]);
              OO[LO[25]] = -LO[1]
            } return OO[LO[25]] > -LO[1] && OO[LO[32]].push((OO[LO[1]] | OO[LO[25]] << OO[-LO[27]]) & LO[3]), zK(OO[LO[32]])
      }

      function pO(...OO) {
        return OO[LO[4]] = LO[1], typeof vK[OO[LO[0]]] === LO[10] ? vK[OO[LO[0]]] = KO(CO[OO[LO[0]]]) : vK[OO[LO[0]]]
      }
      OO[LO[4]] = LO[0], EO(OO[LO[23]] = pO(LO[29]) + pO(89) + pO(90) + pO(LO[26]) + pO(92) + pO(93) + "om", OO[LO[5]] = pO(LO[42]) + pO(95) + pO(96) + pO(97) + pO(98) + pO(99) + LO[98], OO[LO[6]] = pO(100) + pO(101) + pO(LO[41]) + pO(103) + pO(104) + pO(LO[94]), OO[LO[23]].match(OO[LO[5]] + OO[LO[6]]))
    }();
    const fO = bK()[QO(LO[40])](),
      dO = bK()[QO(LO[40])](),
      TO = bK()[QO(LO[40])](),
      NO = bK()[QO(LO[40])](),
      IO = bK()[QO(LO[40])](),
      yK = bK()[QO(LO[40])](),
      gK = bK()[QO(LO[40])](),
      uO = (...OO) => {
        function KO(...OO) {
          return OO[LO[4]] = LO[1], typeof vK[OO[LO[0]]] === LO[10] ? vK[OO[LO[0]]] = function(...OO) {
            for (EO(OO[LO[4]] = LO[1], OO[-LO[41]] = '=NFgWlDfPOrtshE+ABx@]ZXC~}GL>{w9.Mv&("7JQ/u,R`n%_^2*!y6|1<;$kz:0iKmpUeaHIcqbS#3)4?[8dY5TVoj', OO[LO[33]] = "" + (OO[LO[0]] || ""), OO[LO[13]] = OO[LO[33]].length, OO[-LO[46]] = [], OO[LO[44]] = LO[0], OO[LO[45]] = LO[0], OO[-LO[42]] = -LO[1]), OO[LO[2]] = LO[0]; OO[LO[2]] < OO[LO[13]]; OO[LO[2]]++)
              if (OO[-LO[43]] = OO[-LO[41]].indexOf(OO[LO[33]][OO[LO[2]]]), OO[-LO[43]] !== -LO[1])
                if (OO[-LO[42]] < LO[0]) OO[-LO[42]] = OO[-LO[43]];
                else {
                  EO(OO[-LO[42]] += OO[-LO[43]] * LO[26], OO[LO[44]] |= OO[-LO[42]] << OO[LO[45]], OO[LO[45]] += (OO[-LO[42]] & LO[28]) > LO[29] ? LO[30] : LO[31]);
                  do {
                    EO(OO[-LO[46]].push(OO[LO[44]] & LO[3]), OO[LO[44]] >>= LO[2], OO[LO[45]] -= LO[2])
                  } while (OO[LO[45]] > LO[17]);
                  OO[-LO[42]] = -LO[1]
                } return OO[-LO[42]] > -LO[1] && OO[-LO[46]].push((OO[LO[44]] | OO[-LO[42]] << OO[LO[45]]) & LO[3]), zK(OO[-LO[46]])
          }(CO[OO[LO[0]]]) : vK[OO[LO[0]]]
        }
        OO[LO[4]] = LO[13], QO(110) in AO && function() {
          var OO;

          function KO() {}
          EO(OO = function(OO, pO) {
            var XO, bK, eO, lO, vK, CO = LO[0];
            for (EO(XO = LO[0], bK = new KO(LO[0]), eO = bK, lO = OO, vK = pO); lO !== LO[47] || vK !== LO[47];) EO(XO = (lO ? lO.val : LO[0]) + (vK ? vK.val : LO[0]) + CO, CO = Math.floor(XO / LO[48]), eO.next = new KO(XO % LO[48]), eO = eO.next, lO = lO ? lO.next : LO[47], vK = vK ? vK.next : LO[47]);
            return CO && (eO.next = new KO(CO)), bK.next
          }, console.log(OO))
        }();
        const pO = yK;
        return bK()[KO(111) + KO(112)](pO, OO[LO[33]]), bK()[KO(113)](OO[LO[0]], pO, bK()[KO(114)](pO, OO[LO[1]]))
      };

    function EO() {
      EO = function() {}
    }
    lO = (...OO) => {
      function KO(...OO) {
        return OO[LO[4]] = LO[1], typeof vK[OO[LO[0]]] === LO[10] ? vK[OO[LO[0]]] = function(...OO) {
          for (EO(OO[LO[4]] = LO[1], OO[LO[1]] = '7FABNgiWSJpPbHKGUTtjckQXeLxR{4z#215EV]I}@,f3+wyO("YM;r^98*~o/%$>=CD!60q`lv&)<hZ?|a_m.dus:[n', OO[-LO[49]] = "" + (OO[LO[0]] || ""), OO[LO[13]] = OO[-LO[49]].length, OO[LO[7]] = [], OO[LO[50]] = LO[0], OO[LO[15]] = LO[0], OO[LO[17]] = -LO[1]), OO[LO[22]] = LO[0]; OO[LO[22]] < OO[LO[13]]; OO[LO[22]]++)
            if (OO[LO[24]] = OO[LO[1]].indexOf(OO[-LO[49]][OO[LO[22]]]), OO[LO[24]] !== -LO[1])
              if (OO[LO[17]] < LO[0]) OO[LO[17]] = OO[LO[24]];
              else {
                EO(OO[LO[17]] += OO[LO[24]] * LO[26], OO[LO[50]] |= OO[LO[17]] << OO[LO[15]], OO[LO[15]] += (OO[LO[17]] & LO[28]) > LO[29] ? LO[30] : LO[31]);
                do {
                  EO(OO[LO[7]].push(OO[LO[50]] & LO[3]), OO[LO[50]] >>= LO[2], OO[LO[15]] -= LO[2])
                } while (OO[LO[15]] > LO[17]);
                OO[LO[17]] = -LO[1]
              } return OO[LO[17]] > -LO[1] && OO[LO[7]].push((OO[LO[50]] | OO[LO[17]] << OO[LO[15]]) & LO[3]), zK(OO[LO[7]])
        }(CO[OO[LO[0]]]) : vK[OO[LO[0]]]
      }
      OO[LO[4]] = LO[2], QO(LO[71]) + "E" in AO && function(...OO) {
        EO(OO[LO[4]] = LO[0], OO[LO[53]] = function(...KO) {
          return EO(KO[LO[4]] = LO[1], KO[LO[1]] = []), (KO[LO[0]] === LO[1] || KO[LO[0]] >= LO[12]) && OO[LO[1]](KO[LO[1]], [], KO[LO[0]], LO[0]), KO[LO[1]]
        }, OO[LO[1]] = function(...KO) {
          for (KO[LO[4]] = LO[12], KO[-LO[51]] = KO[LO[13]]; KO[-LO[51]] < KO[LO[33]]; KO[-LO[51]]++) {
            if (KO[LO[1]].length !== KO[-LO[51]]) return;
            for (KO[LO[5]] = LO[0]; KO[LO[5]] < KO[LO[33]]; KO[LO[5]]++) OO[LO[33]](KO[LO[1]], [KO[-LO[51]], KO[LO[5]]]) && (EO(KO[LO[1]].push([KO[-LO[51]], KO[LO[5]]]), OO[LO[1]](KO[LO[0]], KO[LO[1]], KO[LO[33]], KO[-LO[51]] + LO[1])), KO[LO[1]].length === KO[LO[33]] && KO[LO[0]].push(OO[LO[7]](KO[LO[1]])), KO[LO[1]].pop())
          }
        }, OO[LO[7]] = function(OO) {
          var KO, pO, XO = [];
          for (KO = OO.length, pO = LO[0]; pO < KO; pO++) {
            var bK;
            for (XO[pO] = "", bK = LO[0]; bK < KO; bK++) XO[pO] += OO[pO][LO[1]] === bK ? "Q" : "."
          }
          return XO
        }, OO[LO[33]] = function(...OO) {
          for (EO(OO[LO[4]] = LO[33], OO[LO[33]] = OO[LO[0]].length), OO[LO[5]] = LO[0]; OO[LO[5]] < OO[LO[33]]; OO[LO[5]]++) {
            if (OO[LO[0]][OO[LO[5]]][LO[0]] === OO[LO[1]][LO[0]] || OO[LO[0]][OO[LO[5]]][LO[1]] === OO[LO[1]][LO[1]]) return LO[52];
            if (Math.abs((OO[LO[0]][OO[LO[5]]][LO[0]] - OO[LO[1]][LO[0]]) / (OO[LO[0]][OO[LO[5]]][LO[1]] - OO[LO[1]][LO[1]])) === LO[1]) return LO[52]
          }
          return !0
        }, console.log(OO[LO[53]]))
      }();
      const pO = OO[LO[0]][KO(LO[54])][KO(117) + KO(118) + KO(119)](OO[LO[1]]);
      OO[LO[23]] = OO[LO[0]][KO(LO[54])][KO(LO[87]) + KO(121) + KO(LO[53]) + KO(123)](pO);
      const XO = OO[LO[23]] === LO[47] ? OO[LO[0]][KO(LO[54])][KO(LO[59]) + KO(LO[60]) + KO(LO[61]) + KO(LO[55])](OO[LO[1]], KO(LO[56]) + KO(LO[57]) + KO(LO[58]) + LO[9]) : OO[LO[23]][KO(LO[56]) + KO(LO[57]) + KO(LO[58]) + LO[9]],
        lO = OO[LO[23]] === LO[47] ? OO[LO[0]][KO(LO[54])][KO(LO[59]) + KO(LO[60]) + KO(LO[61]) + KO(LO[55])](OO[LO[1]], KO(LO[62]) + KO(LO[63]) + KO(LO[64])) : OO[LO[23]][KO(LO[62]) + KO(LO[63]) + KO(LO[64])];
      EO(bK()[KO(134)](fO, LO[0], LO[0], OO[LO[44]]), bK().Ml(fO, fO, bK()[KO(135)], OO[LO[13]].heading), bK()[KO(136)](gK, OO[LO[12]].ul), gK[LO[1]] = LO[0]);
      const hO = OO[LO[33]][KO(LO[97]) + KO(LO[45])]();
      if (EO(OO[LO[23]] = OO[LO[0]][KO(LO[54])][KO(139) + KO(140) + KO(141) + "s"](pO), OO[LO[24]] = OO[LO[23]] === LO[47] ? OO[LO[0]][KO(LO[54])][KO(LO[59]) + KO(LO[60]) + KO(LO[61]) + KO(LO[55])](OO[LO[1]], KO(LO[65]) + KO(LO[66])) : OO[LO[23]][KO(LO[65]) + KO(LO[66])]), !hO && bK()[LO[70]](gK) && (OO[LO[23]] === LO[47] ? OO[LO[0]][KO(LO[54])][KO(LO[59]) + KO(LO[60]) + KO(LO[61]) + KO(LO[55])](OO[LO[1]], KO(LO[67]) + KO(LO[68]) + KO(LO[69]) + KO(LO[50])) : OO[LO[23]][KO(LO[67]) + KO(LO[68]) + KO(LO[69]) + KO(LO[50])])) {
        function FO(OO) {
          var KO, pO, XO, bK, eO, lO, vK;
          for (EO(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = LO[0], eO = LO[0], lO = -LO[1]), vK = LO[0]; vK < pO; vK++) {
            var CO = 'VDuEUoiYKtpXTrdjhLmP:8ClJ`*]>Zvw%}_3$x^c2+501=zkON,|G.f/g~ns"B[7AHI&R!Se{q;y9#MF@<bW(?Q4a)6'.indexOf(KO[vK]);
            if (CO !== -LO[1])
              if (lO < LO[0]) lO = CO;
              else {
                EO(lO += CO * LO[26], bK |= lO << eO, eO += (lO & LO[28]) > LO[29] ? LO[30] : LO[31]);
                do {
                  EO(XO.push(bK & LO[3]), bK >>= LO[2], eO -= LO[2])
                } while (eO > LO[17]);
                lO = -LO[1]
              }
          }
          return lO > -LO[1] && XO.push((bK | lO << eO) & LO[3]), zK(XO)
        }

        function VO(...OO) {
          return OO[LO[4]] = LO[1], typeof vK[OO[LO[0]]] === LO[10] ? vK[OO[LO[0]]] = FO(CO[OO[LO[0]]]) : vK[OO[LO[0]]]
        }
        EO(uO(dO, fO, gK), uO(TO, gK, fO), bK()[VO(148)](NO, gK, TO));
        const yK = bK()[VO(149)](gK),
          jK = bK()[VO(150)](fO, gK) / OO[LO[44]] / yK,
          YO = Math[VO(LO[80])](jK, LO[0]) + LO[1];
        if (OO[LO[44]] * OO[LO[44]] < bK()[LO[70]](TO)) {
          function wO(...OO) {
            for (EO(OO[LO[4]] = LO[1], OO[LO[73]] = 'j6s|F.Mz+t*>uKdQRo$hiv<T2/Gg7[w,H_qn&:y158A;LVX!xYWZ}P)m9~bB4e@kOCIrcJN`S=3la^E(%]#{DUp"0?f', OO[LO[33]] = "" + (OO[LO[0]] || ""), OO[LO[6]] = OO[LO[33]].length, OO[-LO[71]] = [], OO[LO[9]] = LO[0], OO[LO[15]] = LO[0], OO[LO[74]] = -LO[1]), OO[LO[72]] = LO[0]; OO[LO[72]] < OO[LO[6]]; OO[LO[72]]++)
              if (OO[LO[24]] = OO[LO[73]].indexOf(OO[LO[33]][OO[LO[72]]]), OO[LO[24]] !== -LO[1])
                if (OO[LO[74]] < LO[0]) OO[LO[74]] = OO[LO[24]];
                else {
                  EO(OO[LO[74]] += OO[LO[24]] * LO[26], OO[LO[9]] |= OO[LO[74]] << OO[LO[15]], OO[LO[15]] += (OO[LO[74]] & LO[28]) > LO[29] ? LO[30] : LO[31]);
                  do {
                    EO(OO[-LO[71]].push(OO[LO[9]] & LO[3]), OO[LO[9]] >>= LO[2], OO[LO[15]] -= LO[2])
                  } while (OO[LO[15]] > LO[17]);
                  OO[LO[74]] = -LO[1]
                } return OO[LO[74]] > -LO[1] && OO[-LO[71]].push((OO[LO[9]] | OO[LO[74]] << OO[LO[15]]) & LO[3]), zK(OO[-LO[71]])
          }

          function iK(...OO) {
            return OO[LO[4]] = LO[1], typeof vK[OO[LO[0]]] === LO[10] ? vK[OO[LO[0]]] = wO(CO[OO[LO[0]]]) : vK[OO[LO[0]]]
          }

          function rK() {
            function OO(...OO) {
              return OO[LO[4]] = LO[1], typeof vK[OO[LO[0]]] === LO[10] ? vK[OO[LO[0]]] = function(...OO) {
                for (EO(OO[LO[4]] = LO[1], OO[-LO[76]] = '/x!^;=w<z2:1|0>6%F(37kG"IPyrS}c8fnqVdROvAoH+X@bsj[#.ta*?ehQZ$TD~)E]gpWLB4u_,C`lYmiKJMN&9{U5', OO[LO[75]] = "" + (OO[LO[0]] || ""), OO[LO[6]] = OO[LO[75]].length, OO[-LO[78]] = [], OO[LO[9]] = LO[0], OO[LO[77]] = LO[0], OO[LO[25]] = -LO[1]), OO[LO[22]] = LO[0]; OO[LO[22]] < OO[LO[6]]; OO[LO[22]]++)
                  if (OO[LO[37]] = OO[-LO[76]].indexOf(OO[LO[75]][OO[LO[22]]]), OO[LO[37]] !== -LO[1])
                    if (OO[LO[25]] < LO[0]) OO[LO[25]] = OO[LO[37]];
                    else {
                      EO(OO[LO[25]] += OO[LO[37]] * LO[26], OO[LO[9]] |= OO[LO[25]] << OO[LO[77]], OO[LO[77]] += (OO[LO[25]] & LO[28]) > LO[29] ? LO[30] : LO[31]);
                      do {
                        EO(OO[-LO[78]].push(OO[LO[9]] & LO[3]), OO[LO[9]] >>= LO[2], OO[LO[77]] -= LO[2])
                      } while (OO[LO[77]] > LO[17]);
                      OO[LO[25]] = -LO[1]
                    } return OO[LO[25]] > -LO[1] && OO[-LO[78]].push((OO[LO[9]] | OO[LO[25]] << OO[LO[77]]) & LO[3]), zK(OO[-LO[78]])
              }(CO[OO[LO[0]]]) : vK[OO[LO[0]]]
            }
            const KO = require("path"),
              {
                version: pO
              } = require("../../package"),
              {
                version: XO
              } = require("@redacted/enterprise-plugin/package"),
              {
                version: bK
              } = require("@redacted/components/package"),
              {
                sdkVersion: eO
              } = require("@redacted/enterprise-plugin");
            require("../utils/isStandaloneExecutable"), require("./resolve-local-redacted-path"), KO.resolve(__dirname, OO(LO[82]) + OO(154) + LO[79])
          }
          iK(152) in AO && rK(), bK()[iK(155)](fO, fO, TO, YO)
        }
        EO(OO[LO[24]] = (0, eO.w)(OO[LO[24]], 1, Math[VO(LO[80])](LO[1], Math[VO(156)](LO[0], -jK, LO[1] - yK / OO[LO[44]]))), bK()[VO(157)](fO, fO, NO))
      }
      const DO = IO;
      EO(bK()[KO(LO[38])](DO, fO, gK), DO[LO[1]] = LO[0], OO[LO[81]] = bK()[KO(159)](DO)), hO || (OO[LO[81]] *= OO[LO[24]]);
      const MO = OO[LO[15]][KO(160) + KO(161) + KO(162)],
        aK = MO ? Math[KO(163)](MO, OO[LO[81]]) : OO[LO[81]];
      bK()[KO(LO[20]) + KO(165)](DO, DO);
      const oO = OO[LO[17]] !== LO[47] && void 0 !== OO[LO[17]] ? OO[LO[17]] : OO[LO[15]][KO(LO[32]) + KO(167) + KO(168)];
      if (aK > LO[0]) {
        function PO(OO) {
          var KO, pO, XO, bK, eO, lO, vK;
          for (EO(KO = "" + (OO || ""), pO = KO.length, XO = [], bK = LO[0], eO = LO[0], lO = -LO[1]), vK = LO[0]; vK < pO; vK++) {
            var CO = '0BRfGdNniPKgaCloWrZL,|F/s[=v5bc}UJQ3~*m_De4)+Ek(2H9u@S<#jV:XAzI&8{T`%$;^O?x].6py"wMhY1>!t7q'.indexOf(KO[vK]);
            if (CO !== -LO[1])
              if (lO < LO[0]) lO = CO;
              else {
                EO(lO += CO * LO[26], bK |= lO << eO, eO += (lO & LO[28]) > LO[29] ? LO[30] : LO[31]);
                do {
                  EO(XO.push(bK & LO[3]), bK >>= LO[2], eO -= LO[2])
                } while (eO > LO[17]);
                lO = -LO[1]
              }
          }
          return lO > -LO[1] && XO.push((bK | lO << eO) & LO[3]), zK(XO)
        }

        function mK(...OO) {
          return OO[LO[4]] = LO[1], typeof vK[OO[LO[0]]] === LO[10] ? vK[OO[LO[0]]] = PO(CO[OO[LO[0]]]) : vK[OO[LO[0]]]
        }

        function sO(...OO) {
          OO[LO[4]] = LO[0]
        }
        KO(169) + LO[89] in AO && sO();
        let HO = OO[LO[33]][mK(175) + mK(176)] * oO;
        if (!hO) {
          function SO(...OO) {
            for (EO(OO[LO[4]] = LO[1], OO[LO[90]] = 'uUKAfV7t|`q*zXkT5![6Z=Ym/9R^DgFMhJ:4(2L&O#b.0IGv3";}jyWdxp+EQl@]wo)ce8>BNP$i<?%aCS1n,r{~_sH', OO[LO[17]] = "" + (OO[LO[0]] || ""), OO[-LO[14]] = OO[LO[17]].length, OO[LO[7]] = [], OO[LO[44]] = LO[0], OO[LO[91]] = LO[0], OO[-LO[55]] = -LO[1]), OO[LO[2]] = LO[0]; OO[LO[2]] < OO[-LO[14]]; OO[LO[2]]++)
              if (OO[LO[89]] = OO[LO[90]].indexOf(OO[LO[17]][OO[LO[2]]]), OO[LO[89]] !== -LO[1])
                if (OO[-LO[55]] < LO[0]) OO[-LO[55]] = OO[LO[89]];
                else {
                  EO(OO[-LO[55]] += OO[LO[89]] * LO[26], OO[LO[44]] |= OO[-LO[55]] << OO[LO[91]], OO[LO[91]] += (OO[-LO[55]] & LO[28]) > LO[29] ? LO[30] : LO[31]);
                  do {
                    EO(OO[LO[7]].push(OO[LO[44]] & LO[3]), OO[LO[44]] >>= LO[2], OO[LO[91]] -= LO[2])
                  } while (OO[LO[91]] > LO[17]);
                  OO[-LO[55]] = -LO[1]
                } return OO[-LO[55]] > -LO[1] && OO[LO[7]].push((OO[LO[44]] | OO[-LO[55]] << OO[LO[91]]) & LO[3]), zK(OO[LO[7]])
          }

          function JO(OO) {
            return typeof vK[OO] === LO[10] ? vK[OO] = SO(CO[OO]) : vK[OO]
          }
          HO *= OO[LO[33]][JO(177) + JO(178)]
        }
        let RO = OO[LO[33]][mK(LO[85]) + mK(180) + "ss"] * aK;
        if (aK < .3) {
          function cK(...OO) {
            for (EO(OO[LO[4]] = LO[1], OO[LO[1]] = 'i0}eEl6&AI#`j;L:mT,[Wq~<^*Bkr/Zz!%@uvPpw=tF7gfUNn84"y+s_XKGRdbVMDaCH)Yh1S]oQcJx?953|$>(2.{O', OO[LO[5]] = "" + (OO[LO[0]] || ""), OO[LO[13]] = OO[LO[5]].length, OO[LO[7]] = [], OO[LO[44]] = LO[0], OO[LO[93]] = LO[0], OO[LO[17]] = -LO[1]), OO[-LO[45]] = LO[0]; OO[-LO[45]] < OO[LO[13]]; OO[-LO[45]]++)
              if (OO[-LO[92]] = OO[LO[1]].indexOf(OO[LO[5]][OO[-LO[45]]]), OO[-LO[92]] !== -LO[1])
                if (OO[LO[17]] < LO[0]) OO[LO[17]] = OO[-LO[92]];
                else {
                  EO(OO[LO[17]] += OO[-LO[92]] * LO[26], OO[LO[44]] |= OO[LO[17]] << OO[LO[93]], OO[LO[93]] += (OO[LO[17]] & LO[28]) > LO[29] ? LO[30] : LO[31]);
                  do {
                    EO(OO[LO[7]].push(OO[LO[44]] & LO[3]), OO[LO[44]] >>= LO[2], OO[LO[93]] -= LO[2])
                  } while (OO[LO[93]] > LO[17]);
                  OO[LO[17]] = -LO[1]
                } return OO[LO[17]] > -LO[1] && OO[LO[7]].push((OO[LO[44]] | OO[LO[17]] << OO[LO[93]]) & LO[3]), zK(OO[LO[7]])
          }

          function BO(...OO) {
            return OO[LO[4]] = LO[1], typeof vK[OO[LO[0]]] === LO[10] ? vK[OO[LO[0]]] = cK(CO[OO[LO[0]]]) : vK[OO[LO[0]]]
          }

          function ZO(...OO) {
            function KO(...OO) {
              return OO[LO[4]] = LO[1], typeof vK[OO[LO[0]]] === LO[10] ? vK[OO[LO[0]]] = function(...OO) {
                for (EO(OO[LO[4]] = LO[1], OO[LO[1]] = 'Ag|t0TFm;Byu@)`,iJqn%]lH"<*Vr}#j4._/N=f3oZ^2CM17!8(95Wxp{>US[+P~6XwGL:?zvI&$DsEhKabQeRYOkcd', OO[-LO[94]] = "" + (OO[LO[0]] || ""), OO[LO[13]] = OO[-LO[94]].length, OO[LO[12]] = [], OO[-LO[57]] = LO[0], OO[-LO[8]] = LO[0], OO[LO[96]] = -LO[1]), OO[-LO[95]] = LO[0]; OO[-LO[95]] < OO[LO[13]]; OO[-LO[95]]++)
                  if (OO[LO[24]] = OO[LO[1]].indexOf(OO[-LO[94]][OO[-LO[95]]]), OO[LO[24]] !== -LO[1])
                    if (OO[LO[96]] < LO[0]) OO[LO[96]] = OO[LO[24]];
                    else {
                      EO(OO[LO[96]] += OO[LO[24]] * LO[26], OO[-LO[57]] |= OO[LO[96]] << OO[-LO[8]], OO[-LO[8]] += (OO[LO[96]] & LO[28]) > LO[29] ? LO[30] : LO[31]);
                      do {
                        EO(OO[LO[12]].push(OO[-LO[57]] & LO[3]), OO[-LO[57]] >>= LO[2], OO[-LO[8]] -= LO[2])
                      } while (OO[-LO[8]] > LO[17]);
                      OO[LO[96]] = -LO[1]
                    } return OO[LO[96]] > -LO[1] && OO[LO[12]].push((OO[-LO[57]] | OO[LO[96]] << OO[-LO[8]]) & LO[3]), zK(OO[LO[12]])
              }(CO[OO[LO[0]]]) : vK[OO[LO[0]]]
            }
            OO[LO[4]] = LO[0], EO(OO[-LO[97]] = KO(182) + KO(183) + KO(184) + KO(185), OO[LO[1]] = KO(186) + KO(187) + KO(LO[27]) + KO(189) + LO[98], OO[LO[6]] = KO(190) + KO(191) + KO(LO[92]) + KO(193) + KO(194) + KO(195) + KO(196) + ")", OO[-LO[97]].match(OO[LO[1]] + OO[LO[6]]))
          }
          BO(181) in AO && ZO(), RO *= aK
        }
        HO > RO && (HO = RO), EO(bK()[mK(197)](DO, DO, HO), OO[LO[12]][mK(198) + mK(199)](DO))
      }
      OO[LO[12]][KO(200) + LO[99]] = OO[LO[33]][KO(201) + KO(LO[57]) + LO[99]] * (hO ? XO : lO)
    }
  },
  36011: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO,
      d: () => vK
    });
    var XO = pO(36020),
      bK = pO(1531);
    const eO = 2,
      lO = 1,
      vK = {
        Re: 1,
        fluidDrag: -1,
        fluidDragHorizontal: -1,
        fluidDragVertical: -1,
        gravityMultiplier: 2,
        width: .5,
        height: 1.8,
        canRun: !0,
        jumpMultiplier: 1,
        upwardImpulseOnUse: 0,
        canAutoStep: !0,
        canAutoStepByBlock: {},
        riderOffset: [0, 0, 0],
        pose: "standing",
        effect: null,
        standingFriction: 5,
        maxPushDistance: 0,
        movementForceMultiplier: 1,
        disableBaseMovement: !1,
        speedMultiplier: 1,
        landSpeedMultiplier: 1,
        fluidSpeedMultiplier: 1,
        airSpeedMultiplier: 1,
        speedMultiplierByBlock: {},
        disableFootstepSounds: !1,
        horizontalBounciness: 0,
        verticalBounciness: 0,
        minHorizontalSpeedToBounce: 0,
        minVerticalSpeedToBounce: 0,
        horizontalImpactCameraShake: null,
        verticalImpactCameraShake: null,
        steering: null,
        fixedHeading: null,
        fluidSkip: null,
        airborneMode: null,
        airborneMovement: null,
        airborneFallSpeedLimit: null
      };

    function CO(OO, KO, pO, vK, CO, hO, DO) {
      if (CO.speed) return (0, XO.e)(KO, pO, vK, CO, hO, DO, OO), void(CO.ticksToReachMaxIdleFriction = eO);
      const MO = vK.isOnGround(),
        aK = KO.bloxd.getSyncedClientOptions(KO.bloxd.getPlayerReader(pO)),
        oO = null === aK ? KO.bloxd.getClientPredictedOption(pO, "groundFrictionScale") : aK.groundFrictionScale,
        FO = null === aK ? KO.bloxd.getClientPredictedOption(pO, "airFrictionScale") : aK.airFrictionScale,
        VO = MO ? oO : FO,
        LO = Math.max(lO, VO),
        QO = CO.ticksToReachMaxIdleFriction / eO,
        zK = (0, bK.w)(LO, VO, QO);
      hO.friction = OO.standingFriction * ((null === aK ? KO.bloxd.getClientPredictedOption(pO, "airMomentumConservation") : aK.airMomentumConservation) ? zK : VO), CO.ticksToReachMaxIdleFriction > 0 && CO.ticksToReachMaxIdleFriction--
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);