export const id = 201;
export const ids = [201];
export const modules = {
  37843: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      g: () => bK
    });
    const XO = "The world isn't loaded, so no blocks can be seen.",
      bK = "The world isn't loaded, so nothing in it can be seen."
  },
  35301: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      e: () => bK
    });
    let XO = () => null;

    function bK(OO) {
      XO = OO
    }

    function eO(OO, KO) {
      return XO(OO, KO)
    }
  },
  38689: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => VO,
      f: () => AO,
      j: () => zK,
      l: () => LO
    });
    var XO = pO(26),
      bK = pO(38698),
      eO = pO(38674),
      lO = pO(38700),
      vK = pO(38680),
      CO = pO(38709),
      hO = pO(38723);

    function DO(OO) {
      var KO, pO;
      const XO = (0, eO.g)();
      return XO ? null === (KO = (0, bK.b)(XO.api, OO[0], OO[1], OO[2])) || void 0 === KO || null === (pO = KO.persisted) || void 0 === pO ? void 0 : pO.shared : void 0
    }

    function MO(OO) {
      return `${OO[0]},${OO[1]},${OO[2]}`
    }
    const aK = new Map;
    let oO = null,
      FO = 0;

    function VO() {
      return FO
    }

    function LO(OO) {
      const KO = null !== oO && oO.key === MO(OO.pos) ? oO.type : null;
      if (null === KO) return OO;
      let pO = null;
      if ("Iron" === KO) {
        const {
          cachedPasskey: KO,
          ...XO
        } = QO(OO.pos);
        pO = {
          pC: null !== KO && void 0 !== KO ? KO : [0, 0, 0, 0],
          ...XO
        }
      }
      return {
        ...OO,
        type: KO,
        ironChest: pO
      }
    }

    function QO(OO) {
      const KO = DO(OO),
        pO = null === KO || void 0 === KO ? void 0 : KO.ownerDbId,
        XO = function(OO) {
          var KO;
          let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : DO(OO);
          const XO = MO(OO),
            bK = aK.get(XO);
          return bK ? bK.lastOpened < (null !== (KO = null === pO || void 0 === pO ? void 0 : pO.passkeyLastUpdated) && void 0 !== KO ? KO : 0) ? (aK.delete(XO), null) : [...bK.pC] : null
        }(OO, KO);
      return void 0 === pO ? {
        cachedPasskey: XO
      } : {
        ownerDbId: pO,
        cachedPasskey: XO
      }
    }(0, hO.n)(lO.e, (OO => {
      const KO = (0, CO.d)(lO.e, OO);
      if (!(0, CO.b)(KO) || KO.AOO) return;
      if (FO++, !KO.VOO || null === KO.hiO) return void(oO = null);
      const pO = MO(KO.hiO);
      oO = {
        key: pO,
        type: KO.QOO
      }, null !== KO.zKO && aK.set(pO, {
        pC: [...KO.zKO],
        lastOpened: Date.now()
      })
    })), (0, hO.g)((() => {
      aK.clear(), oO = null, FO++
    })), (0, hO.k)((() => {
      null !== oO && (oO = null, FO++, XO.i.pl("chestToggleFromServer", !1, !0))
    }));
    const zK = {
        boardEditRequested: {
          watch: OO => (0, XO.j)("EditBoard", (KO => {
            let {
              pos: pO
            } = KO;
            if (null === pO) return void OO(null);
            const XO = (0, eO.g)(),
              bK = (0, eO.s)();
            XO && bK && OO(bK.readBoardToEdit(XO.api, XO.chunks, pO))
          }))
        },
        ironChestOpenRequested: {
          watch: OO => (0, XO.j)("OpenIronChest", (KO => {
            let {
              pos: pO
            } = KO;
            OO(function(OO) {
              return {
                pos: OO,
                ...QO(OO)
              }
            }(pO))
          }))
        }
      },
      AO = {
        writeOnBoard(OO) {
          var KO;
          let {
            pos: pO,
            text: XO,
            textSize: bK
          } = OO;
          null === (KO = (0, eO.g)()) || void 0 === KO || KO.send(vK.b.UpdateBoard, (0, vK.V)({
            aZ: pO,
            oB: XO,
            uB: bK
          }))
        },
        writeBook(OO) {
          var KO;
          let {
            pages: pO,
            title: XO,
            published: bK
          } = OO;
          null === (KO = (0, eO.g)()) || void 0 === KO || KO.send(vK.b.UpdateBook, (0, vK.Z)({
            uZ: pO,
            jG: XO,
            wZ: bK
          }))
        },
        writeNameTag(OO) {
          var KO;
          null === (KO = (0, eO.g)()) || void 0 === KO || KO.send(vK.b.UpdateNameTag, OO)
        },
        setCustomLobbyBlock(OO) {
          let {
            pos: KO,
            blockName: pO
          } = OO;
          const XO = (0, eO.s)(),
            bK = (0, eO.g)();
          XO && bK && bK.send(vK.b.SetCustomLobbyBlock, (0, vK.F)({
            yl: XO.blockIdOf(pO),
            NJ: KO
          }))
        }
      }
  },
  38745: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => CO,
      d: () => lO,
      e: () => vK
    });
    var XO = pO(38667),
      bK = pO(3923),
      eO = pO(38674);

    function lO() {
      var OO;
      const KO = null === (OO = (0, eO.g)()) || void 0 === OO ? void 0 : OO.api.localId;
      return void 0 === KO || KO === XO.Vc ? null : String(KO)
    }

    function vK(OO) {
      const KO = (0, eO.g)();
      if (null !== KO) return OO(KO);
      let pO = null;
      const XO = (0, bK.u)((() => {
        const KO = (0, eO.g)();
        null !== KO && null === pO && (XO(), pO = OO(KO))
      }));
      return () => {
        var OO;
        XO(), null === (OO = pO) || void 0 === OO || OO()
      }
    }

    function CO(OO, KO, pO) {
      return {
        current: () => {
          const pO = (0, eO.g)();
          return null === pO ? KO : OO(pO)()
        },
        watch: KO => vK((XO => {
          const bK = OO(XO);
          let eO = bK();
          return KO(eO), pO((() => {
            const OO = bK();
            OO !== eO && (eO = OO, KO(OO))
          }))
        }))
      }
    }
  },
  38741: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => hO
    });
    var XO = pO(38674),
      bK = pO(38745),
      eO = pO(38748);

    function lO() {
      var OO, KO;
      return null !== (OO = null === (KO = (0, XO.g)()) || void 0 === KO ? void 0 : KO.itemBridgeSources) && void 0 !== OO ? OO : eO.c
    }

    function vK(OO) {
      return {
        current: () => lO().states[OO].current(),
        watch: KO => (0, bK.e)((pO => {
          const XO = pO.itemBridgeSources.states[OO];
          return KO(XO.current()), XO.watch(KO)
        }))
      }
    }

    function CO(OO) {
      return {
        watch: KO => (0, bK.e)((pO => pO.itemBridgeSources.events[OO].watch(KO)))
      }
    }
    const hO = {
      states: {
        inventory: vK("inventory"),
        hotbar: vK("hotbar"),
        crafting: vK("crafting"),
        heldItemAim: vK("heldItemAim")
      },
      events: {
        hotbarSlotRequested: CO("hotbarSlotRequested"),
        hotbarScrolled: CO("hotbarScrolled"),
        numberKeyPressed: CO("numberKeyPressed"),
        inventoryDropRequested: CO("inventoryDropRequested"),
        chestToggled: CO("chestToggled"),
        chestRefreshed: CO("chestRefreshed"),
        inventorySynced: CO("inventorySynced"),
        enchantingTableOpened: CO("enchantingTableOpened")
      },
      commands: {
        selectHotbarSlot: OO => lO().commands.selectHotbarSlot(OO),
        removeInventoryItem: OO => lO().commands.removeInventoryItem(OO),
        swapInventorySlots: OO => lO().commands.swapInventorySlots(OO),
        moveInventoryItem: OO => lO().commands.moveInventoryItem(OO),
        quickMoveInventoryItem: OO => lO().commands.quickMoveInventoryItem(OO),
        closeChest: OO => lO().commands.closeChest(OO),
        focusCrafting: OO => lO().commands.focusCrafting(OO),
        craftRecipe: OO => lO().commands.craftRecipe(OO),
        salvageItem: OO => lO().commands.salvageItem(OO),
        enchantItem: OO => lO().commands.enchantItem(OO)
      },
      queries: {
        enchantingOffer: OO => lO().queries.enchantingOffer(OO)
      }
    }
  },
  38748: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK
    });
    var XO = pO(37843);

    function bK(OO) {
      return {
        current: () => OO,
        watch: () => () => {}
      }
    }

    function eO() {}
    const lO = Object.freeze([0, 0, 0]),
      vK = {
        states: {
          health: bK({
            health: null,
            maxHealth: null,
            shield: null,
            maxShield: null
          }),
          inventory: bK({
            player: [],
            chestOrCreative: [],
            chest: null,
            creative: !1,
            selectedSlot: 0,
            freeSlots: 0
          }),
          hotbar: bK({
            items: [],
            ammo: 0,
            selectedSlot: null
          }),
          stationItems: bK({
            enchantable: {},
            salvageable: {}
          }),
          itemInfo: bK({}),
          creativeVisibility: bK({
            publicLobby: !1,
            shownInGame: {}
          }),
          aura: bK(null),
          heldItemAim: bK({
            gun: !1,
            aimable: !1,
            chargeName: null
          }),
          crouching: bK(!1),
          gliderBoostFuel: bK(0),
          flight: bK({
            canFly: !1,
            flying: !1
          }),
          crafting: bK({
            focus: null,
            recipes: [],
            detail: null
          }),
          players: bK({
            ids: [],
            byId: {},
            localId: null
          }),
          lobbyLeaderboardRows: bK({}),
          fullInventory: bK(!1),
          crosshairTarget: bK({
            interactPrompt: null,
            blockText: null,
            neededTool: null
          }),
          localPlayerAlive: bK(!0),
          replay: bK(null),
          replayEdits: bK(null),
          replayRecorder: bK({
            recording: !1,
            clipping: !1,
            hasClipBuffer: !1,
            seconds: 0
          }),
          replayVideoExporting: bK(!1)
        },
        events: {
          hotbarSlotRequested: {
            watch: () => () => {}
          },
          hotbarScrolled: {
            watch: () => () => {}
          },
          hotbarDropRequested: {
            watch: () => () => {}
          },
          inventoryDropRequested: {
            watch: () => () => {}
          },
          numberKeyPressed: {
            watch: () => () => {}
          },
          chestToggled: {
            watch: () => () => {}
          },
          chestRefreshed: {
            watch: () => () => {}
          },
          inventorySynced: {
            watch: () => () => {}
          },
          enchantingTableOpened: {
            watch: () => () => {}
          },
          cosmeticsUpdated: {
            watch: () => () => {}
          },
          shotDamageToShow: {
            watch: () => () => {}
          },
          boardEditRequested: {
            watch: () => () => {}
          },
          kill: {
            watch: () => () => {}
          },
          chatReceived: {
            watch: () => () => {}
          },
          ironChestOpenRequested: {
            watch: () => () => {}
          },
          localEffectUpdated: {
            watch: () => () => {}
          },
          localPlayerAliveSet: {
            watch: () => () => {}
          },
          replayUiActionRequested: {
            watch: () => () => {}
          },
          replayViewerRequested: {
            watch: () => () => {}
          }
        },
        commands: {
          selectHotbarSlot: eO,
          removeInventoryItem: () => !1,
          swapInventorySlots: () => !1,
          moveInventoryItem: () => !1,
          quickMoveInventoryItem: () => null,
          closeChest: eO,
          setInventoryOpen: eO,
          changeIronChestPasskey: eO,
          dragReplayCamera: eO,
          applyTemporaryThirdPerson: eO,
          holdEmoteWheel: eO,
          recordFlyingMiddleText: eO,
          focusCrafting: eO,
          craftRecipe: () => ({
            kR: 0,
            uq: null,
            amountAddedToSlot: 0
          }),
          salvageItem: () => !1,
          enchantItem: eO,
          setShopOpen: eO,
          buyShopItem: eO,
          sendChatMessage: eO,
          ignorePlayer: eO,
          reportPlayer: eO,
          reportWorldCodeChat: eO,
          requestDiscordReportKey: eO,
          reportLobbyOrGame: eO,
          playEmote: eO,
          updateMyCosmetic: eO,
          writeOnBoard: eO,
          writeBook: eO,
          writeNameTag: eO,
          setCustomLobbyBlock: eO,
          openIronChest: eO,
          sendCodeCollab: eO,
          clickCodeBlock: eO,
          bindCustomButtonKeys: eO,
          pressCustomButton: eO,
          moveReplayFreecam: eO,
          holdReplayFreecamVertical: eO,
          respawn: eO,
          wakeUp: eO,
          requestLeaderboard: eO,
          completeTask: eO,
          setServerCookie: eO,
          answerUiRequest: eO,
          chooseRewardedAd: eO,
          setCameraZoom: eO,
          setCrosshairInteractPrompt: eO,
          setLookSensitivity: eO,
          replayAction: eO,
          setReplayPlaying: eO,
          seekReplay: eO,
          setReplayCameraMode: eO,
          syncReplayCameraMode: eO,
          setReplayCameraKeyframe: eO,
          moveReplayCameraKeyframe: eO,
          deleteReplayCameraKeyframes: eO,
          setReplayPlaybackMark: eO,
          cropReplay: () => !1,
          holdReplayForShaderPackFailure: eO,
          exportReplayVideo: eO,
          toggleRecording: eO,
          saveClip: eO,
          setRecorderPrefs: eO,
          setReplayViewerOpen: eO
        },
        queries: {
          enchantingOffer: () => ({
            perks: [],
            options: []
          }),
          worldCodeAiChunk: () => XO.d,
          worldCodeAiGameState: () => XO.g
        },
        lookups: {
          localPos: () => lO,
          momentumFrac: () => 0,
          screenPos: () => ({
            x: 0,
            y: 0
          }),
          cameraZoom: () => 0,
          blocksStandingOn: () => [],
          dropAhead: () => !1,
          replayCamera: () => null,
          leaveGameReloadsPage: () => !1,
          codeBlockClickable: () => !1
        }
      }
  },
  38671: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => yK,
      e: () => IO,
      f: () => gK,
      g: () => NO,
      i: () => dO
    });
    var XO = pO(37577),
      bK = pO(1077),
      eO = pO(1569),
      lO = pO(1579),
      vK = pO(2560),
      CO = pO(35301),
      hO = pO(1163),
      DO = pO(38674),
      MO = pO(3962),
      aK = pO(1964),
      oO = pO(38680),
      FO = pO(38689),
      VO = pO(38741);
    let LO = null;

    function QO(OO) {
      const KO = new Map,
        pO = pO => {
          if ("string" !== typeof pO) return;
          let XO = KO.get(pO);
          return void 0 === XO && (XO = OO(pO), void 0 !== XO && KO.set(pO, XO)), XO
        };
      return new Proxy({}, {
        get: (OO, KO) => pO(KO),
        has: (OO, KO) => void 0 !== pO(KO)
      })
    }

    function zK(OO) {
      const KO = (0, vK.c)(OO);
      return void 0 !== KO && (0, vK.e)(KO) === OO
    }

    function AO(OO) {
      var KO;
      const pO = null === (KO = (0, DO.g)()) || void 0 === KO ? void 0 : KO.tables;
      if (void 0 === pO || !zK(OO)) return;
      const XO = {
          displayName: pO.getDisplayName(OO)
        },
        bK = pO.getItemStat(OO, "description");
      void 0 !== bK && null !== bK && (XO.description = bK);
      const {
        rootName: eO
      } = pO.getMetaInfo(OO);
      eO !== OO && (XO.rootName = eO);
      const lO = pO.getItemStat(OO, "armourReduction");
      return void 0 !== lO && null !== lO && (XO.armourReduction = lO), XO
    }(0, DO.v)((OO => {
      LO = OO
    }));
    const fO = (0, lO.j)("DisplayName", "Description");

    function dO() {
      return Boolean(eO.c.get("useInventory") && eO.c.get("useFullInventory"))
    }
    let TO = null;
    const NO = {
        inventory: function() {
          const OO = VO.c.states.inventory;
          let KO = null;
          const pO = OO => {
            var pO;
            return null === OO.chest ? OO : ((null === (pO = KO) || void 0 === pO ? void 0 : pO.from) === OO && KO.chestVersion === (0, FO.e)() || (KO = {
              from: OO,
              chestVersion: (0, FO.e)(),
              view: {
                ...OO,
                chest: (0, FO.l)(OO.chest)
              }
            }), KO.view)
          };
          return {
            current: () => pO(OO.current()),
            watch: KO => OO.watch((OO => {
              KO(pO(OO))
            }))
          }
        }(),
        crafting: VO.c.states.crafting,
        stationItems: {
          current() {
            var OO;
            return (null === (OO = TO) || void 0 === OO ? void 0 : OO.namesVersion) !== (0, vK.f)() && (TO = {
              namesVersion: (0, vK.f)(),
              items: {
                enchantable: QO((OO => {
                  const KO = (0, vK.c)(OO);
                  return void 0 !== KO && null !== LO && LO.enchantmentPerksOf(KO).length > 0 || void 0
                })),
                salvageable: QO((OO => !(!zK(OO) || null === (0, CO.c)(OO)) || void 0))
              }
            }), TO.items
          },
          watch: () => () => {}
        },
        itemInfo: function() {
          let OO = null;
          const KO = () => {
            var KO;
            return (null === (KO = OO) || void 0 === KO ? void 0 : KO.namesVersion) !== (0, vK.f)() && (OO = {
              namesVersion: (0, vK.f)(),
              infos: QO(AO)
            }), OO.infos
          };
          return {
            current: KO,
            watch: pO => (0, lO.s)((XO => {
              XO.some(fO) && (OO = null, pO(KO()))
            }))
          }
        }(),
        creativeVisibility: (0, lO.o)((function() {
          const OO = {};
          for (const bK of null !== (KO = null === (pO = LO) || void 0 === pO ? void 0 : pO.creativeItemIds()) && void 0 !== KO ? KO : []) {
            var KO, pO, lO, CO;
            const hO = (0, vK.e)(bK);
            if (void 0 === hO) continue;
            const DO = null !== (lO = eO.c.get((0, XO.d)(hO, "showInCreativeInven"))) && void 0 !== lO ? lO : null === (CO = LO) || void 0 === CO ? void 0 : CO.showInCreativeInvenOf(bK);
            "boolean" === typeof DO && (OO[hO] = DO)
          }
          return {
            publicLobby: (0, bK.J)((0, hO.b)().lobbyName),
            shownInGame: OO
          }
        }), ["connectedGameChanged"], (0, lO.j)("ShowInCreativeInven")),
        fullInventory: (0, lO.o)(dO, [], (0, lO.n)("useInventory", "useFullInventory"))
      },
      IO = {
        inventoryDropRequested: VO.c.events.inventoryDropRequested,
        chestToggled: VO.c.events.chestToggled,
        chestRefreshed: VO.c.events.chestRefreshed,
        inventorySynced: VO.c.events.inventorySynced,
        enchantingTableOpened: VO.c.events.enchantingTableOpened
      },
      yK = {
        removeInventoryItem: VO.c.commands.removeInventoryItem,
        swapInventorySlots: VO.c.commands.swapInventorySlots,
        moveInventoryItem: VO.c.commands.moveInventoryItem,
        quickMoveInventoryItem: VO.c.commands.quickMoveInventoryItem,
        closeChest: VO.c.commands.closeChest,
        setInventoryOpen(OO) {
          (0, MO.j)(aK.u.InventoryOpen, OO ? aK.u.InventoryOpen : 0)
        },
        focusCrafting: VO.c.commands.focusCrafting,
        craftRecipe: VO.c.commands.craftRecipe,
        salvageItem: VO.c.commands.salvageItem,
        enchantItem: VO.c.commands.enchantItem,
        changeIronChestPasskey(OO) {
          var KO;
          let {
            pos: pO,
            pC: XO
          } = OO;
          null === (KO = (0, DO.g)()) || void 0 === KO || KO.send(oO.b.ChangeIronChestPasskey, (0, oO.e)({
            hiO: pO,
            pC: XO
          }))
        },
        openIronChest(OO) {
          var KO;
          let {
            pos: pO,
            pC: XO
          } = OO;
          null === (KO = (0, DO.g)()) || void 0 === KO || KO.send(oO.b.OpenIronChest, (0, oO.B)({
            hiO: pO,
            pC: XO
          }))
        }
      },
      gK = {
        enchantingOffer: VO.c.queries.enchantingOffer
      }
  },
  38732: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO,
      h: () => MO,
      i: () => vK,
      l: () => eO,
      m: () => bK,
      p: () => CO,
      r: () => DO
    });
    class XO extends Error {
      constructor() {
        super(...arguments), this.name = "CoreCorruption"
      }
    }

    function bK(OO) {
      return OO instanceof RangeError && /call stack/i.test(OO.message) || OO instanceof Error && "InternalError" === OO.name && /recursion/i.test(OO.message)
    }

    function eO(OO) {
      return /out of (executable )?memory|could not allocate memory|array buffer allocation failed/i.test(String(OO))
    }
    const lO = /wasm:\/\/|wasm-function\[|\[wasm code\]/;

    function vK(OO) {
      var KO;
      return OO instanceof WebAssembly.RuntimeError || OO instanceof XO || bK(OO) && lO.test(null !== (KO = OO.stack) && void 0 !== KO ? KO : "")
    }

    function CO(OO, KO) {
      if (vK(OO)) throw OO;
      console.error(KO, OO)
    }

    function hO(OO, KO, pO, bK, eO) {
      if (KO % bK !== 0 || KO + pO > OO.byteLength) throw new XO(`${eO}: ${pO} bytes at ${KO}, ${bK}-aligned, outside ${OO.byteLength} bytes of memory`)
    }

    function DO(OO, KO, pO, XO, bK) {
      return 0 === pO ? null : (hO(KO, pO, XO * OO.BYTES_PER_ELEMENT, OO.BYTES_PER_ELEMENT, bK), new OO(KO, pO, XO))
    }

    function MO(OO, KO, pO, XO, bK) {
      return 0 === KO ? null : (hO(OO, KO, pO, XO, bK), new DataView(OO, KO, pO))
    }
  },
  38674: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO,
      e: () => QO,
      g: () => VO,
      k: () => LO,
      o: () => aK,
      r: () => oO,
      s: () => DO,
      v: () => MO,
      y: () => FO
    });
    class XO extends Error {
      constructor(OO) {
        super(`the join's code did not load: ${OO instanceof Error?OO.message:String(OO)}`, {
          cause: OO
        }), this.request = void 0, this.name = "GameCodeLoadError", this.request = null === OO || void 0 === OO ? void 0 : OO.request
      }
    }
    let bK = null,
      eO = null,
      lO = null;
    const vK = [];
    let CO = null;

    function hO(OO, KO) {
      try {
        OO(KO)
      } catch (pO) {
        console.error("[bloxd-wasm-client] the game chunk's listener failed", pO)
      }
    }

    function DO() {
      return CO
    }

    function MO(OO) {
      vK.push(OO), null !== CO && hO(OO, CO)
    }

    function aK(OO) {
      return bK ??= Promise.all([pO.e(62), pO.e(64), pO.e(83), pO.e(198), pO.e(127), pO.e(219), pO.e(199), pO.e(200), pO.e(107), pO.e(81), pO.e(126), pO.e(229), pO.e(178), pO.e(76), pO.e(130), pO.e(184), pO.e(106), pO.e(226), pO.e(48)]).then((() => pO(40610))).then((KO => {
        KO.loadAudio(OO), CO = KO;
        for (const OO of vK) hO(OO, KO);
        return KO
      })).catch((OO => {
        throw bK = null, OO
      })), bK
    }
    async function oO(OO, KO) {
      try {
        const pO = await aK(OO);
        await pO.loadClientGame(KO)
      } catch (pO) {
        throw new XO(pO)
      }
    }

    function FO(OO, KO) {
      eO = {
        running: OO,
        shell: KO
      }
    }

    function VO() {
      return lO
    }
    async function LO(OO) {
      const KO = eO;
      if ((null === KO || void 0 === KO ? void 0 : KO.running) !== OO) throw new Error("the core's session has ended");
      const pO = await aK(KO.shell.audio).catch((OO => {
        throw new XO(OO)
      }));
      if (null !== lO) return lO;
      if (eO !== KO || OO.isStopped) throw new Error("the core stopped while the game code loaded");
      if (lO = pO.startGameHost(OO, KO.shell), null === lO) throw new Error("the core's shared tables didn't read, so the game can't start");
      return lO
    }

    function QO() {
      null !== lO && (null !== CO ? CO.endGameHost(lO) : lO.closeGame()), lO = null, eO = null
    }
  },
  38680: (OO, KO, pO) => {
    pO.d(KO, {
      $: () => AO,
      B: () => jK,
      C: () => fO,
      D: () => dO,
      F: () => LO,
      J: () => gK,
      K: () => wO,
      O: () => FO,
      R: () => rK,
      V: () => zK,
      Z: () => QO,
      b: () => bK,
      d: () => iK,
      db: () => TO,
      e: () => YO,
      g: () => oO,
      j: () => VO,
      l: () => EO,
      p: () => IO,
      t: () => uO,
      x: () => yK,
      y: () => NO
    });
    var XO = pO(2325);
    const bK = {
      Chat: 49,
      UiRequestResponded: 91,
      CodeCollab: 89,
      SetCustomLobbyBlock: 60,
      UpdateBook: 56,
      UpdateBoard: 33,
      UpdateMyCosmetic: 45,
      PlayEmote: 90,
      ReqDiscordReportKey: 9,
      UserReport: 11,
      LobbyReport: 12,
      CustomGameReport: 13,
      IgnoreUser: 34,
      ShopMenuChanged: 26,
      GeneralCookieSet: 72,
      CompleteTask: 69,
      OpenIronChest: 80,
      ChangeIronChestPasskey: 81,
      StopSleeping: 78,
      AnalyticsUpdate: 3,
      UiRequestResp: 15,
      QteResponse: 16,
      ItemBought: 25,
      LeaderboardRequest: 40,
      UpdateNameTag: 53
    };

    function eO(OO, KO) {
      return !ArrayBuffer.isView(OO) || OO instanceof DataView ? Array.isArray(OO) ? OO.map((OO => KO(OO))) : OO : Array.from(OO, (OO => KO(OO)))
    }

    function lO(OO) {
      if ("string" !== typeof OO) return OO;
      for (let KO = 0; KO < OO.length; KO++) {
        const pO = OO.charCodeAt(KO);
        if (pO >= 55296 && pO <= 57343) return CO.decode(vK.encode(OO))
      }
      return OO
    }
    const vK = new TextEncoder,
      CO = new TextDecoder;

    function hO(OO) {
      return OO
    }
    let DO;

    function MO(OO) {
      return null === OO || "object" !== typeof OO ? OO : [lO(OO.LX), lO(OO.Ur)]
    }

    function aK(OO) {
      return null === OO || "object" !== typeof OO ? OO : [eO(OO.hiO, hO), eO(OO.pC, hO)]
    }

    function oO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.Tl), lO(KO.QG)];
      var KO
    }

    function FO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [KO.id, KO.lV];
      var KO
    }

    function VO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [KO.Zm, lO(KO.Wm), KO.Xs, lO(KO.Fs), KO.Qs, KO.jH, KO.qH, lO(KO.xH), lO(KO.Ws)];
      var KO
    }

    function LO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [eO(KO.NJ, hO), KO.yl];
      var KO
    }

    function QO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [eO(KO.uZ, (OO => lO(OO))), lO(KO.jG), KO.wZ];
      var KO
    }

    function zK(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [eO(KO.aZ, hO), lO(KO.oB), KO.uB];
      var KO
    }

    function AO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.oV), lO(KO.VV)];
      var KO
    }

    function fO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.GV)];
      var KO
    }

    function dO(OO) {
      return lO(OO)
    }

    function TO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.WG), lO(KO.lq), lO(KO.LX), lO(KO.Ur)];
      var KO
    }

    function NO(OO) {
      return MO(OO)
    }

    function IO(OO) {
      return MO(OO)
    }

    function yK(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.sH)];
      var KO
    }

    function gK(OO) {
      return OO
    }

    function uO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.zq), lO(KO.YG)];
      var KO
    }

    function EO(OO) {
      return lO(OO)
    }

    function jK(OO) {
      return aK(OO)
    }

    function YO(OO) {
      return aK(OO)
    }

    function wO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.LJ)];
      var KO
    }

    function iK(OO) {
      return (DO ??= (0, XO.e)().map((OO => OO.name)), DO).map((KO => {
        return "string" === typeof(pO = OO[KO]) ? lO(pO) : eO(pO, hO);
        var pO
      }))
    }

    function rK(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [KO.lY, KO.hY, KO.FY];
      var KO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);