export const id = 28;
export const ids = [28];
export const modules = {
  7153: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      BaseExtension: () => Op,
      BaseInstrumentation: () => Kp,
      BaseTransport: () => te,
      CSPInstrumentation: () => Ib,
      ConsoleInstrumentation: () => wp,
      ConsoleTransport: () => pe,
      EVENT_CLICK: () => AK,
      EVENT_NAVIGATION: () => fK,
      EVENT_ROUTE_CHANGE: () => gp,
      EVENT_SESSION_EXTEND: () => IK,
      EVENT_SESSION_RESUME: () => NK,
      EVENT_SESSION_START: () => TK,
      EVENT_VIEW_CHANGED: () => dK,
      ErrorsInstrumentation: () => rX,
      FetchTransport: () => fe,
      InternalLoggerLevel: () => ZK,
      LogLevel: () => Ap,
      MAX_SESSION_PERSISTENCE_TIME: () => CO,
      NavigationInstrumentation: () => Sb,
      Observable: () => zX,
      PerformanceInstrumentation: () => qb,
      PersistentSessionsManager: () => sK,
      SESSION_EXPIRATION_TIME: () => eO,
      SESSION_INACTIVITY_TIME: () => lO,
      STORAGE_KEY: () => bK,
      SessionInstrumentation: () => Xp,
      TransportItemType: () => ke,
      UserActionInstrumentation: () => Nb,
      UserActionState: () => Fb,
      VERSION: () => pp,
      ViewInstrumentation: () => mX,
      VolatileSessionsManager: () => HK,
      WebVitalsInstrumentation: () => ib,
      allLogLevels: () => dp,
      browserMeta: () => qe,
      buildStackFrame: () => bX,
      captureMetas: () => ml,
      createInternalLogger: () => yl,
      createPromiseBuffer: () => al,
      createSession: () => nb,
      deepEqual: () => zp,
      defaultEventDomain: () => XO,
      defaultExceptionType: () => yX,
      defaultGlobalObjectKey: () => gl,
      defaultInternalLoggerLevel: () => qp,
      defaultLogLevel: () => fp,
      faro: () => VO,
      genShortID: () => QK,
      getCurrentTimestamp: () => FK,
      getDataFromSafariExtensions: () => aX,
      getIgnoreUrls: () => xK,
      getInternalFaroFromGlobalObject: () => aK,
      getStackFramesFromError: () => Fp,
      getTransportBody: () => Ke,
      getUrlFromResource: () => WO,
      getWebInstrumentations: () => Jb,
      globalObject: () => DO,
      initializeFaro: () => tl,
      internalGlobalObjectKey: () => MO,
      isArray: () => jK,
      isBoolean: () => yK,
      isDomError: () => RO,
      isDomException: () => SO,
      isElement: () => cK,
      isElementDefined: () => JO,
      fX: () => qK,
      isError: () => sO,
      isErrorDefined: () => mK,
      isErrorEvent: () => HO,
      isEvent: () => PO,
      isEventDefined: () => rK,
      isFunction: () => EO,
      isInstanceOf: () => AO,
      isInt: () => IO,
      isInternalFaroOnGlobalObject: () => FO,
      isMap: () => ZO,
      isMapDefined: () => BO,
      isNull: () => dO,
      isNumber: () => NO,
      isObject: () => uO,
      isPrimitive: () => iK,
      isRegExp: () => YO,
      isString: () => TO,
      isSymbol: () => gK,
      isSyntheticEvent: () => GO,
      isThenable: () => wO,
      isToString: () => zK,
      isTypeof: () => QO,
      isUndefined: () => fO,
      makeCoreConfig: () => jl,
      noop: () => BK,
      osMeta: () => xe,
      parseStacktrace: () => Vp,
      sdkMeta: () => Wb,
      setInternalFaroOnGlobalObject: () => oO,
      transportItemTypeToBodyKey: () => Ub,
      unknownString: () => Pp,
      userActionDataAttribute: () => xb,
      userActionTimeoutDataAttribute: () => nX
    });
    const XO = "browser",
      bK = "com.grafana.faro.session",
      eO = 144e5,
      lO = 9e5,
      vK = 1e3,
      CO = lO,
      hO = {
        enabled: !0,
        persistent: !1,
        maxSessionPersistenceTime: CO
      };
    const DO = "undefined" !== typeof globalThis ? globalThis : "undefined" !== typeof pO.g ? pO.g : "undefined" !== typeof self ? self : void 0;
    const MO = "_faroInternal";

    function aK() {
      return DO[MO]
    }

    function oO(OO) {
      OO.config.isolate ? OO.internalLogger.debug("Skipping registering internal Faro instance on global object") : (OO.internalLogger.debug("Registering internal Faro instance on global object"), Object.defineProperty(DO, MO, {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: OO
      }))
    }

    function FO() {
      return MO in DO
    }
    let VO = {
      api: {
        pushLog: () => {},
        pushError: () => {},
        changeStacktraceParser: () => {},
        getStacktraceParser: () => {},
        pushMeasurement: () => {},
        pushTraces: () => {},
        getOTEL: () => {},
        getTraceContext: () => {},
        initOTEL: () => {},
        isOTELInitialized: () => !1,
        setUser: () => {},
        resetUser: () => {},
        setSession: () => {},
        resetSession: () => {},
        getSession: () => {},
        setView: () => {},
        getView: () => {},
        setPage: () => {},
        getPage: () => {},
        pushEvent: () => {},
        startUserAction: () => {},
        getActiveUserAction: () => {}
      }
    };

    function LO(OO, KO, pO, XO, bK, eO, lO) {
      return KO.debug("Initializing Faro"), VO = {
          api: eO,
          config: pO,
          instrumentations: lO,
          internalLogger: KO,
          metas: XO,
          pause: bK.pause,
          transports: bK,
          unpatchedConsole: OO,
          unpause: bK.unpause
        }, oO(VO),
        function(OO) {
          if (OO.config.preventGlobalExposure) OO.internalLogger.debug("Skipping registering public Faro instance in the global scope");
          else {
            if (OO.internalLogger.debug(`Registering public faro reference in the global scope using "${OO.config.globalObjectKey}" key`), OO.config.globalObjectKey in DO) return void OO.internalLogger.warn(`Skipping global registration due to key "${OO.config.globalObjectKey}" being used already. Please set "globalObjectKey" to something else or set "preventGlobalExposure" to "true"`);
            Object.defineProperty(DO, OO.config.globalObjectKey, {
              configurable: !1,
              writable: !1,
              value: OO
            })
          }
        }(VO), VO
    }

    function QO(OO, KO) {
      return typeof OO === KO
    }

    function zK(OO, KO) {
      return Object.prototype.toString.call(OO) === `[object ${KO}]`
    }

    function AO(OO, KO) {
      try {
        return OO instanceof KO
      } catch (pO) {
        return !1
      }
    }
    const fO = OO => QO(OO, "undefined"),
      dO = OO => QO(OO, "null"),
      TO = OO => QO(OO, "string"),
      NO = OO => QO(OO, "number") && !isNaN(OO) || QO(OO, "bigint"),
      IO = OO => NO(OO) && Number.isInteger(OO),
      yK = OO => QO(OO, "boolean"),
      gK = OO => QO(OO, "symbol"),
      uO = OO => !dO(OO) && QO(OO, "object"),
      EO = OO => QO(OO, "function"),
      jK = OO => zK(OO, "Array"),
      YO = OO => zK(OO, "RegExp"),
      wO = OO => EO(null === OO || void 0 === OO ? void 0 : OO.then),
      iK = OO => !uO(OO) && !EO(OO),
      rK = "undefined" !== typeof Event,
      PO = OO => rK && AO(OO, Event),
      mK = "undefined" !== typeof Error,
      sO = OO => mK && AO(OO, Error),
      HO = OO => zK(OO, "ErrorEvent"),
      RO = OO => zK(OO, "DOMError"),
      SO = OO => zK(OO, "DOMException"),
      JO = "undefined" !== typeof Element,
      cK = OO => JO && AO(OO, Element),
      BO = "undefined" !== typeof Map,
      ZO = OO => BO && AO(OO, Map),
      GO = OO => uO(OO) && "nativeEvent" in OO && "preventDefault" in OO && "stopPropagation" in OO;

    function qK(OO) {
      return null == OO || (jK(OO) || TO(OO) ? 0 === OO.length : !!uO(OO) && 0 === Object.keys(OO).length)
    }

    function xK() {
      return VO.transports.transports.flatMap((OO => OO.getIgnoreUrls()))
    }

    function nO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
      return xK().some((KO => OO && null != OO.match(KO)))
    }

    function WO(OO) {
      return TO(OO) ? OO : OO instanceof URL ? OO.href : !qK(OO) && EO(null === OO || void 0 === OO ? void 0 : OO.toString) ? OO.toString() : void 0
    }
    const tK = "sessionStorage",
      kK = "localStorage";

    function UO(OO) {
      try {
        let KO;
        KO = window[OO];
        const pO = "__faro_storage_test__";
        return KO.setItem(pO, pO), KO.removeItem(pO), !0
      } catch (pO) {
        var KO;
        return null === (KO = VO.internalLogger) || void 0 === KO || KO.info(`Web storage of type ${OO} is not available. Reason: ${pO}`), !1
      }
    }

    function OK(OO, KO) {
      return eK(KO) ? window[KO].getItem(OO) : null
    }

    function KK(OO, KO, pO) {
      if (eK(pO)) try {
        window[pO].setItem(OO, KO)
      } catch (XO) {}
    }

    function pK(OO, KO) {
      eK(KO) && window[KO].removeItem(OO)
    }
    const XK = UO(kK),
      bp = UO(tK);

    function eK(OO) {
      return OO === kK ? XK : OO === tK && bp
    }

    function lK(OO) {
      return lK = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(OO) {
        return typeof OO
      } : function(OO) {
        return OO && "function" == typeof Symbol && OO.constructor === Symbol && OO !== Symbol.prototype ? "symbol" : typeof OO
      }, lK(OO)
    }

    function vp(OO) {
      var KO = function(OO, KO) {
        if ("object" != lK(OO) || !OO) return OO;
        var pO = OO[Symbol.toPrimitive];
        if (void 0 !== pO) {
          var XO = pO.call(OO, KO || "default");
          if ("object" != lK(XO)) return XO;
          throw new TypeError("@@toPrimitive must return a primitive value.")
        }
        return ("string" === KO ? String : Number)(OO)
      }(OO, "string");
      return "symbol" == lK(KO) ? KO : KO + ""
    }

    function CK(OO, KO, pO) {
      return (KO = vp(KO)) in OO ? Object.defineProperty(OO, KO, {
        value: pO,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }) : OO[KO] = pO, OO
    }

    function hK(OO, KO) {
      var pO = Object.keys(OO);
      if (Object.getOwnPropertySymbols) {
        var XO = Object.getOwnPropertySymbols(OO);
        KO && (XO = XO.filter((function(KO) {
          return Object.getOwnPropertyDescriptor(OO, KO).enumerable
        }))), pO.push.apply(pO, XO)
      }
      return pO
    }

    function DK(OO) {
      for (var KO = 1; KO < arguments.length; KO++) {
        var pO = null != arguments[KO] ? arguments[KO] : {};
        KO % 2 ? hK(Object(pO), !0).forEach((function(KO) {
          CK(OO, KO, pO[KO])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(OO, Object.getOwnPropertyDescriptors(pO)) : hK(Object(pO)).forEach((function(KO) {
          Object.defineProperty(OO, KO, Object.getOwnPropertyDescriptor(pO, KO))
        }))
      }
      return OO
    }

    function MK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : VO;
      var KO, pO, XO;
      const bK = OO.config.sessionTracking,
        eO = null !== (KO = null !== (pO = null === bK || void 0 === bK || null === (XO = bK.sampler) || void 0 === XO ? void 0 : XO.call(bK, {
          metas: OO.metas.value
        })) && void 0 !== pO ? pO : null === bK || void 0 === bK ? void 0 : bK.samplingRate) && void 0 !== KO ? KO : 1,
        lO = "number" === typeof eO ? function(OO) {
          return Math.min(1, Math.max(0, OO))
        }(eO) : 0;
      if (!(lO > 0)) return !1;
      if (1 === lO) return !0;
      try {
        const OO = "undefined" !== typeof window ? window.crypto : void 0;
        if ("function" === typeof(null === OO || void 0 === OO ? void 0 : OO.getRandomValues)) {
          const KO = new Uint32Array(1);
          return OO.getRandomValues(KO), KO[0] / Math.pow(2, 32) < lO
        }
      } catch (vK) {}
      return Math.random() < lO
    }

    function ap() {
      return Date.now()
    }

    function oK() {
      return "undefined" !== typeof performance && "function" === typeof performance.now ? performance.now() : Date.now()
    }

    function FK() {
      return (new Date).toISOString()
    }

    function VK(OO) {
      return new Date(OO).toISOString()
    }
    const LK = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ0123456789";

    function QK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 10;
      const KO = new Uint32Array(OO),
        pO = "undefined" !== typeof globalThis ? globalThis.crypto : void 0;
      if (null === pO || void 0 === pO ? void 0 : pO.getRandomValues) pO.getRandomValues(KO);
      else
        for (let bK = 0; bK < OO; bK++) KO[bK] = Math.floor(4294967296 * Math.random());
      let XO = "";
      for (let bK = 0; bK < OO; bK++) XO += LK[KO[bK] % 59];
      return XO
    }

    function zp(OO, KO) {
      if (OO === KO) return !0;
      if (QO(OO, "number") && isNaN(OO)) return QO(KO, "number") && isNaN(KO);
      const pO = jK(OO),
        XO = jK(KO);
      if (pO !== XO) return !1;
      if (pO && XO) {
        const pO = OO.length;
        if (pO !== KO.length) return !1;
        for (let XO = pO; 0 !== XO--;)
          if (!zp(OO[XO], KO[XO])) return !1;
        return !0
      }
      const bK = uO(OO),
        eO = uO(KO);
      if (bK !== eO) return !1;
      if (OO && KO && bK && eO) {
        const pO = Object.keys(OO),
          XO = Object.keys(KO);
        if (pO.length !== XO.length) return !1;
        for (let OO of pO)
          if (!XO.includes(OO)) return !1;
        for (let bK of pO)
          if (!zp(OO[bK], KO[bK])) return !1;
        return !0
      }
      return !1
    }
    const AK = "click",
      fK = "navigation",
      dK = "view_changed",
      TK = "session_start",
      NK = "session_resume",
      IK = "session_extend",
      yp = "service_name_override",
      gp = "route_change";

    function uK() {
      let {
        sessionId: OO,
        started: KO,
        lastActivity: pO,
        isSampled: XO = !0
      } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, bK = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : VO;
      var eO;
      const lO = ap(),
        vK = null === (eO = bK.config) || void 0 === eO || null === (eO = eO.sessionTracking) || void 0 === eO ? void 0 : eO.generateSessionId;
      return null == OO && (OO = "function" === typeof vK ? vK() : QK()), {
        sessionId: OO,
        lastActivity: null !== pO && void 0 !== pO ? pO : lO,
        started: null !== KO && void 0 !== KO ? KO : lO,
        isSampled: XO
      }
    }

    function EK(OO) {
      if (null == OO) return !1;
      const KO = ap();
      return KO - OO.started < 144e5 && KO - OO.lastActivity < lO
    }

    function jp(OO) {
      let {
        fetchUserSession: KO,
        storeUserSession: pO,
        adoptSession: XO,
        updateInterval: bK = 0
      } = OO, vK = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : VO, CO = 0;
      return function() {
        let {
          forceSessionExtend: OO = !1,
          refreshActivity: hO = !0
        } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        var DO, MO;
        if (!KO || !pO) return;
        const aK = ap();
        if (!OO && aK < CO && CO - aK <= bK) return;
        const oO = vK.config.sessionTracking,
          FO = null === oO || void 0 === oO ? void 0 : oO.persistent;
        if (FO && !XK || !FO && !bp) return;
        const VO = KO();
        if (CO = Math.min(aK + bK, (null !== (DO = null === VO || void 0 === VO ? void 0 : VO.started) && void 0 !== DO ? DO : aK) + eO, (null !== (MO = null === VO || void 0 === VO ? void 0 : VO.lastActivity) && void 0 !== MO ? MO : aK) + lO), !1 === OO && EK(VO)) {
          var LO;
          hO && pO(DK(DK({}, VO), {}, {
            lastActivity: aK
          }));
          const OO = null === (LO = vK.metas.value.session) || void 0 === LO ? void 0 : LO.id;
          null != XO && null != VO.sessionMeta && VO.sessionId !== OO && XO(VO.sessionMeta)
        } else {
          var QO, zK, AO;
          let OO = wK(uK({
            isSampled: MK(vK)
          }, vK), VO, vK);
          CO = aK + bK, pO(OO), null === (QO = vK.api) || void 0 === QO || QO.setSession(OO.sessionMeta), null === oO || void 0 === oO || null === (zK = oO.onSessionChange) || void 0 === zK || zK.call(oO, null !== (AO = null === VO || void 0 === VO ? void 0 : VO.sessionMeta) && void 0 !== AO ? AO : null, OO.sessionMeta)
        }
      }
    }

    function YK(OO) {
      let KO, {
          fetchUserSession: pO,
          storeUserSession: XO,
          updateInterval: bK = 0
        } = OO,
        eO = 0;
      return OO => {
        const lO = ap();
        if (OO === KO && lO < eO && eO - lO <= bK) return;
        KO = OO, eO = lO + bK;
        const vK = pO();
        (null === vK || void 0 === vK ? void 0 : vK.sessionId) === OO && EK(vK) && XO(DK(DK({}, vK), {}, {
          lastActivity: lO
        }))
      }
    }

    function wK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : VO;
      var XO, bK, eO, lO, vK, CO;
      const hO = DK(DK({}, OO), {}, {
          sessionMeta: {
            id: OO.sessionId,
            attributes: rp(DK(DK(DK({}, null === (XO = pO.config.sessionTracking) || void 0 === XO || null === (XO = XO.session) || void 0 === XO ? void 0 : XO.attributes), null !== (bK = null === (eO = pO.metas.value.session) || void 0 === eO ? void 0 : eO.attributes) && void 0 !== bK ? bK : {}), {}, {
              isSampled: OO.isSampled.toString()
            }))
          }
        }),
        DO = null !== (lO = null === (vK = pO.metas.value.session) || void 0 === vK ? void 0 : vK.overrides) && void 0 !== lO ? lO : null === KO || void 0 === KO || null === (CO = KO.sessionMeta) || void 0 === CO ? void 0 : CO.overrides;
      qK(DO) || (hO.sessionMeta.overrides = DO);
      const MO = null === KO || void 0 === KO ? void 0 : KO.sessionId;
      return null != MO && (hO.sessionMeta.attributes.previousSession = MO), hO
    }

    function ip(OO) {
      let {
        fetchUserSession: KO,
        storeUserSession: pO
      } = OO, XO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : VO, bK = !1;
      return function(OO) {
        if (bK) return;
        const eO = OO.session,
          lO = KO();
        let vK = null === eO || void 0 === eO ? void 0 : eO.id;
        const CO = null === eO || void 0 === eO ? void 0 : eO.attributes,
          hO = null === eO || void 0 === eO ? void 0 : eO.overrides,
          DO = null === lO || void 0 === lO ? void 0 : lO.sessionMeta,
          MO = null === DO || void 0 === DO ? void 0 : DO.overrides,
          aK = !!hO && !zp(hO, MO),
          oO = !!CO && !zp(CO, null === DO || void 0 === DO ? void 0 : DO.attributes);
        if (eO && vK !== (null === lO || void 0 === lO ? void 0 : lO.sessionId) || oO || aK) {
          var FO, VO;
          const OO = null != lO && vK === lO.sessionId,
            KO = wK(OO ? lO : uK({
              sessionId: vK,
              isSampled: MK(XO)
            }, XO), lO, XO),
            eO = null === lO || void 0 === lO || null === (FO = lO.sessionMeta) || void 0 === FO || null === (FO = FO.attributes) || void 0 === FO ? void 0 : FO.previousSession;
          OO && null != eO && eO !== KO.sessionId && (KO.sessionMeta.attributes.previousSession = eO), (null === (VO = KO.sessionMeta.attributes) || void 0 === VO ? void 0 : VO.previousSession) === KO.sessionId && delete KO.sessionMeta.attributes.previousSession, pO(KO),
            function(OO, KO) {
              let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
              var bK, eO, lO;
              if (!KO) return;
              const vK = pO.serviceName,
                CO = null !== (bK = null !== (eO = XO.serviceName) && void 0 !== eO ? eO : null === (lO = OO.metas.value.app) || void 0 === lO ? void 0 : lO.name) && void 0 !== bK ? bK : "";
              vK && vK !== CO && OO.api.pushEvent(yp, {
                serviceName: vK,
                previousServiceName: CO
              })
            }(XO, aK, hO, MO), bK = !0;
          try {
            XO.api.setSession(KO.sessionMeta)
          } finally {
            bK = !1
          }
        }
      }
    }

    function rp(OO) {
      const KO = {};
      for (const pO of Object.keys(OO)) {
        const XO = OO[pO];
        void 0 !== XO && (KO[pO] = XO)
      }
      return KO
    }

    function PK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      return JSON.stringify(null !== OO && void 0 !== OO ? OO : {}, function() {
        const OO = new WeakSet;
        return function(KO, pO) {
          if (uO(pO) && null !== pO) {
            if (OO.has(pO)) return null;
            OO.add(pO)
          }
          return pO
        }
      }())
    }

    function mp() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      const KO = {};
      for (const [pO, XO] of Object.entries(OO)) KO[pO] = uO(XO) && null !== XO ? PK(XO) : String(XO);
      return KO
    }
    var sK = class OO {
      constructor() {
        var KO = this;
        let pO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : VO;
        this.context = pO, this.adopting = !1, this.isAdopting = () => this.adopting, this.adoptSession = OO => {
          this.adopting = !0;
          try {
            var KO;
            null === (KO = this.context.api) || void 0 === KO || KO.setSession(OO)
          } finally {
            this.adopting = !1
          }
        }, this.updateSession = function() {
          let {
            refreshActivity: OO = !0
          } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          return KO.updateUserSession({
            refreshActivity: OO
          })
        }, this.recordActivity = YK({
          fetchUserSession: OO.fetchUserSession,
          storeUserSession: OO.storeUserSession,
          updateInterval: vK
        }), this.updateUserSession = jp({
          fetchUserSession: OO.fetchUserSession,
          storeUserSession: OO.storeUserSession,
          adoptSession: this.adoptSession,
          updateInterval: vK
        }, pO), this.init()
      }
      static removeUserSession() {
        pK(bK, OO.storageTypeLocal)
      }
      static storeUserSession(KO) {
        KK(bK, PK(KO), OO.storageTypeLocal)
      }
      static fetchUserSession() {
        const KO = OK(bK, OO.storageTypeLocal);
        return KO ? JSON.parse(KO) : null
      }
      init() {
        document.addEventListener("visibilitychange", (() => {
          if ("visible" === document.visibilityState) {
            var OO;
            this.updateSession({
              refreshActivity: !1
            });
            const KO = null === (OO = this.context.api) || void 0 === OO || null === (OO = OO.getSession()) || void 0 === OO ? void 0 : OO.id;
            KO && this.recordActivity(KO)
          }
        })), this.context.metas.addListener(ip({
          fetchUserSession: OO.fetchUserSession,
          storeUserSession: OO.storeUserSession
        }, this.context))
      }
    };
    sK.storageTypeLocal = kK;
    var HK = class OO {
      constructor() {
        var KO = this;
        let pO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : VO;
        this.context = pO, this.isAdopting = () => !1, this.updateSession = function() {
          let {
            refreshActivity: OO = !0
          } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          return KO.updateUserSession({
            refreshActivity: OO
          })
        }, this.recordActivity = YK({
          fetchUserSession: OO.fetchUserSession,
          storeUserSession: OO.storeUserSession,
          updateInterval: vK
        }), this.updateUserSession = jp({
          fetchUserSession: OO.fetchUserSession,
          storeUserSession: OO.storeUserSession,
          updateInterval: vK
        }, pO), this.init()
      }
      static removeUserSession() {
        pK(bK, OO.storageTypeSession)
      }
      static storeUserSession(KO) {
        KK(bK, PK(KO), OO.storageTypeSession)
      }
      static fetchUserSession() {
        const KO = OK(bK, OO.storageTypeSession);
        return KO ? JSON.parse(KO) : null
      }
      init() {
        document.addEventListener("visibilitychange", (() => {
          if ("visible" === document.visibilityState) {
            var OO;
            this.updateSession({
              refreshActivity: !1
            });
            const KO = null === (OO = this.context.api) || void 0 === OO || null === (OO = OO.getSession()) || void 0 === OO ? void 0 : OO.id;
            KO && this.recordActivity(KO)
          }
        })), this.context.metas.addListener(ip({
          fetchUserSession: OO.fetchUserSession,
          storeUserSession: OO.storeUserSession
        }, this.context))
      }
    };
    HK.storageTypeSession = tK;
    const RK = new WeakMap;

    function SK(OO) {
      let KO = RK.get(OO);
      if (!KO) {
        let pO = [],
          XO = [];
        KO = {
          addSessionUpdateListener: OO => {
            pO.push(OO)
          },
          removeSessionUpdateListener: OO => {
            pO = pO.filter((KO => KO !== OO))
          },
          notifySessionUpdate: OO => {
            pO.forEach((KO => KO(OO)))
          },
          shouldCapture: () => XO.every((OO => OO())),
          addCaptureFilter: OO => {
            XO.push(OO)
          },
          removeCaptureFilter: OO => {
            XO = XO.filter((KO => KO !== OO))
          }
        }, RK.set(OO, KO)
      }
      return KO
    }
    var JK = class {
      constructor(OO, KO, pO) {
        this.metas = OO, this.transports = KO, this.onActivate = pO, this.waiting = !1, this.shouldCapture = () => !document.prerendering, this.discard = () => null, this.recordUpdate = OO => {
          var KO, pO, XO;
          const bK = this.pending;
          var eO, lO;
          if ("overrides" === OO.type) return void(this.pending = {
            reset: null !== (eO = null === bK || void 0 === bK ? void 0 : bK.reset) && void 0 !== eO && eO,
            inheritOverrides: null === (lO = null === bK || void 0 === bK ? void 0 : bK.inheritOverrides) || void 0 === lO || lO,
            session: DK(DK({}, null === bK || void 0 === bK ? void 0 : bK.session), {}, {
              overrides: DK(DK({}, null === bK || void 0 === bK ? void 0 : bK.session.overrides), OO.overrides)
            })
          });
          const vK = OO.session,
            CO = qK(vK) || null != vK && "id" in vK && !vK.id,
            hO = null !== (KO = null === vK || void 0 === vK ? void 0 : vK.overrides) && void 0 !== KO ? KO : null === bK || void 0 === bK ? void 0 : bK.session.overrides;
          this.pending = {
            reset: CO || !(null === vK || void 0 === vK ? void 0 : vK.id) && null !== (pO = null === bK || void 0 === bK ? void 0 : bK.reset) && void 0 !== pO && pO,
            inheritOverrides: !(!OO.overrides && void 0 !== (null === vK || void 0 === vK ? void 0 : vK.overrides)) && (null === (XO = null === bK || void 0 === bK ? void 0 : bK.inheritOverrides) || void 0 === XO || XO),
            session: {
              id: null === vK || void 0 === vK ? void 0 : vK.id,
              attributes: (null === vK || void 0 === vK ? void 0 : vK.attributes) && DK({}, vK.attributes),
              overrides: OO.overrides ? DK(DK({}, null === bK || void 0 === bK ? void 0 : bK.session.overrides), OO.overrides) : hO && DK({}, hO)
            }
          }
        }, this.activate = () => {
          this.waiting && this.shouldCapture() && (this.destroy(), this.onActivate(this.pending))
        }
      }
      initialize() {
        var OO, KO;
        this.waiting = !0, SK(this.metas).addSessionUpdateListener(this.recordUpdate), SK(this.metas).addCaptureFilter(this.shouldCapture), this.transports.addBeforeSendHooks(this.discard), document.addEventListener("prerenderingchange", this.activate), null === (OO = (KO = this.metas).addCaptureListener) || void 0 === OO || OO.call(KO, this.activate), this.activate()
      }
      destroy() {
        var OO, KO;
        this.waiting = !1, document.removeEventListener("prerenderingchange", this.activate), SK(this.metas).removeSessionUpdateListener(this.recordUpdate), null === (OO = (KO = this.metas).removeCaptureListener) || void 0 === OO || OO.call(KO, this.activate), SK(this.metas).removeCaptureFilter(this.shouldCapture), this.transports.removeBeforeSendHooks(this.discard)
      }
    };

    function cp(OO) {
      return (null === OO || void 0 === OO ? void 0 : OO.persistent) ? sK : HK
    }

    function BK() {}
    let ZK = function(OO) {
      return OO[OO.OFF = 0] = "OFF", OO[OO.ERROR = 1] = "ERROR", OO[OO.WARN = 2] = "WARN", OO[OO.INFO = 3] = "INFO", OO[OO.VERBOSE = 4] = "VERBOSE", OO
    }({});
    const GK = {
        debug: BK,
        error: BK,
        info: BK,
        prefix: "Faro",
        warn: BK
      },
      qp = 1;

    function xp(OO) {
      return xp = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(OO) {
        return typeof OO
      } : function(OO) {
        return OO && "function" == typeof Symbol && OO.constructor === Symbol && OO !== Symbol.prototype ? "symbol" : typeof OO
      }, xp(OO)
    }

    function nK(OO) {
      var KO = function(OO, KO) {
        if ("object" != xp(OO) || !OO) return OO;
        var pO = OO[Symbol.toPrimitive];
        if (void 0 !== pO) {
          var XO = pO.call(OO, KO || "default");
          if ("object" != xp(XO)) return XO;
          throw new TypeError("@@toPrimitive must return a primitive value.")
        }
        return ("string" === KO ? String : Number)(OO)
      }(OO, "string");
      return "symbol" == xp(KO) ? KO : KO + ""
    }

    function WK(OO, KO, pO) {
      return (KO = nK(KO)) in OO ? Object.defineProperty(OO, KO, {
        value: pO,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }) : OO[KO] = pO, OO
    }

    function tp(OO, KO) {
      var pO = Object.keys(OO);
      if (Object.getOwnPropertySymbols) {
        var XO = Object.getOwnPropertySymbols(OO);
        KO && (XO = XO.filter((function(KO) {
          return Object.getOwnPropertyDescriptor(OO, KO).enumerable
        }))), pO.push.apply(pO, XO)
      }
      return pO
    }

    function kp(OO) {
      for (var KO = 1; KO < arguments.length; KO++) {
        var pO = null != arguments[KO] ? arguments[KO] : {};
        KO % 2 ? tp(Object(pO), !0).forEach((function(KO) {
          WK(OO, KO, pO[KO])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(OO, Object.getOwnPropertyDescriptors(pO)) : tp(Object(pO)).forEach((function(KO) {
          Object.defineProperty(OO, KO, Object.getOwnPropertyDescriptor(pO, KO))
        }))
      }
      return OO
    }
    const UK = kp({}, console);
    var Op = class {
        constructor() {
          this.unpatchedConsole = UK, this.internalLogger = GK, this.config = {}, this.metas = {}
        }
        logDebug() {
          for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
          this.internalLogger.debug(`${this.name}\n`, ...KO)
        }
        logInfo() {
          for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
          this.internalLogger.info(`${this.name}\n`, ...KO)
        }
        logWarn() {
          for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
          this.internalLogger.warn(`${this.name}\n`, ...KO)
        }
        logError() {
          for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
          this.internalLogger.error(`${this.name}\n`, ...KO)
        }
      },
      Kp = class extends Op {
        constructor() {
          super(...arguments), this.api = {}, this.transports = {}
        }
      };
    const pp = "2.12.1";
    var Xp = class extends Kp {
      constructor() {
        super(...arguments), this.name = "@grafana/faro-web-sdk:instrumentation-session", this.version = pp, this.isAdoptingSession = () => !1
      }
      sendSessionStartEvent(OO) {
        var KO;
        const pO = OO.session;
        if (pO && pO.id !== (null === (KO = this.notifiedSession) || void 0 === KO ? void 0 : KO.id)) {
          var XO;
          if (this.isAdoptingSession()) return void(this.notifiedSession = pO);
          if (this.notifiedSession && this.notifiedSession.id === (null === (XO = pO.attributes) || void 0 === XO ? void 0 : XO.previousSession)) return this.api.pushEvent(IK, {}, void 0, {
            skipDedupe: !0
          }), void(this.notifiedSession = pO);
          this.notifiedSession = pO, this.api.pushEvent(TK, {}, void 0, {
            skipDedupe: !0
          })
        }
      }
      createInitialSession(OO, KO, pO) {
        const XO = null === pO || void 0 === pO ? void 0 : pO.session;
        let bK, eO, lO = OO.fetchUserSession();
        if (KO.persistent && KO.maxSessionPersistenceTime && lO) {
          const OO = ap();
          lO.lastActivity < OO - KO.maxSessionPersistenceTime && (sK.removeUserSession(), lO = null)
        }
        const vK = EK(lO);
        if ((null === pO || void 0 === pO ? void 0 : pO.reset) || !vK || (null === XO || void 0 === XO ? void 0 : XO.id) && XO.id !== (null === lO || void 0 === lO ? void 0 : lO.sessionId)) {
          var CO, hO, DO, MO, aK, oO;
          eO = uK({
            sessionId: (null === pO || void 0 === pO ? void 0 : pO.reset) ? void 0 : null !== (CO = null === XO || void 0 === XO ? void 0 : XO.id) && void 0 !== CO ? CO : null === (hO = KO.session) || void 0 === hO ? void 0 : hO.id,
            isSampled: MK(this)
          }, this);
          const OO = eO.sessionId,
            FO = pO && vK ? null === lO || void 0 === lO || null === (DO = lO.sessionMeta) || void 0 === DO ? void 0 : DO.overrides : void 0,
            VO = FO ? DK(DK({}, null === (MO = KO.session) || void 0 === MO ? void 0 : MO.overrides), FO) : null === (aK = KO.session) || void 0 === aK ? void 0 : aK.overrides;
          eO.sessionMeta = DK({
            id: OO,
            attributes: DK({
              isSampled: eO.isSampled.toString()
            }, null === (oO = KO.session) || void 0 === oO ? void 0 : oO.attributes)
          }, VO ? {
            overrides: VO
          } : {}), bK = TK
        } else {
          var FO, VO;
          const OO = null === lO || void 0 === lO ? void 0 : lO.sessionId;
          eO = uK({
            sessionId: OO,
            isSampled: lO.isSampled || !1,
            started: null === lO || void 0 === lO ? void 0 : lO.started
          }, this);
          const pO = null === lO || void 0 === lO ? void 0 : lO.sessionMeta,
            XO = DK(DK({}, null === (FO = KO.session) || void 0 === FO ? void 0 : FO.overrides), null === pO || void 0 === pO ? void 0 : pO.overrides);
          eO.sessionMeta = DK(DK({}, KO.session), {}, {
            id: OO,
            attributes: DK(DK(DK({}, null === (VO = KO.session) || void 0 === VO ? void 0 : VO.attributes), null === pO || void 0 === pO ? void 0 : pO.attributes), {}, {
              isSampled: eO.isSampled.toString()
            }),
            overrides: XO
          }), bK = NK
        }
        var LO;
        if (XO && (eO.sessionMeta = DK(DK({}, eO.sessionMeta), {}, {
            attributes: DK(DK(DK({}, null === (LO = eO.sessionMeta) || void 0 === LO ? void 0 : LO.attributes), XO.attributes), {}, {
              isSampled: eO.isSampled.toString()
            })
          }), XO.overrides)) {
          const OO = (null === pO || void 0 === pO ? void 0 : pO.inheritOverrides) ? DK(DK({}, eO.sessionMeta.overrides), XO.overrides) : XO.overrides;
          Object.keys(OO).length > 0 ? eO.sessionMeta.overrides = OO : delete eO.sessionMeta.overrides
        }
        return {
          initialSession: eO,
          lifecycleType: bK
        }
      }
      registerBeforeSendHook(OO) {
        var KO;
        this.beforeSendHook = KO => {
          var pO, XO;
          const bK = null === (pO = KO.meta.session) || void 0 === pO ? void 0 : pO.id;
          bK && !this.transports.isPaused() && OO(bK);
          const eO = null === (XO = KO.meta.session) || void 0 === XO ? void 0 : XO.attributes;
          if (eO && "true" === (null === eO || void 0 === eO ? void 0 : eO.isSampled)) {
            var lO;
            let OO = JSON.parse(JSON.stringify(KO));
            const pO = null === (lO = OO.meta.session) || void 0 === lO ? void 0 : lO.attributes;
            var vK;
            if (null === pO || void 0 === pO || delete pO.isSampled, 0 === Object.keys(null !== pO && void 0 !== pO ? pO : {}).length) null === (vK = OO.meta.session) || void 0 === vK || delete vK.attributes;
            return OO
          }
          return null
        }, null === (KO = this.transports) || void 0 === KO || KO.addBeforeSendHooks(this.beforeSendHook)
      }
      initialize() {
        var OO;
        this.logDebug("init session instrumentation");
        const KO = document.prerendering;
        var pO;
        if ((null === (OO = this.config.sessionTracking) || void 0 === OO ? void 0 : OO.enabled) && (KO || this.prerenderSession)) return null !== (pO = this.prerenderSession) && void 0 !== pO || (this.prerenderSession = new JK(this.metas, this.transports, (OO => {
          this.prerenderSession = void 0, this.initializeSession(OO)
        }))), void this.prerenderSession.initialize();
        this.initializeSession()
      }
      initializeSession(OO) {
        const KO = this.config.sessionTracking;
        if (null === KO || void 0 === KO ? void 0 : KO.enabled) {
          var pO, XO;
          const bK = cp(KO),
            eO = new bK(this);
          this.isAdoptingSession = eO.isAdopting, this.registerBeforeSendHook(eO.recordActivity);
          const {
            initialSession: lO,
            lifecycleType: vK
          } = this.createInitialSession(bK, KO, OO);
          bK.storeUserSession(lO);
          const CO = lO.sessionMeta;
          this.notifiedSession = CO, this.api.setSession(CO), this.captureListener = () => {
            this.transports.isPaused() || eO.updateSession({
              refreshActivity: !1
            })
          }, null === (pO = (XO = this.metas).addCaptureListener) || void 0 === pO || pO.call(XO, this.captureListener), vK === TK && this.api.pushEvent(TK, {}, void 0, {
            skipDedupe: !0
          }), vK === NK && this.api.pushEvent(NK, {}, void 0, {
            skipDedupe: !0
          })
        }
        this.sessionStartListener = this.sendSessionStartEvent.bind(this), this.metas.addListener(this.sessionStartListener)
      }
      destroy() {
        var OO, KO, pO;
        (null === (OO = this.prerenderSession) || void 0 === OO || OO.destroy(), this.captureListener) && (null === (KO = (pO = this.metas).removeCaptureListener) || void 0 === KO || KO.call(pO, this.captureListener), this.captureListener = void 0);
        this.beforeSendHook && (this.transports.removeBeforeSendHooks(this.beforeSendHook), this.beforeSendHook = void 0), this.sessionStartListener && (this.metas.removeListener(this.sessionStartListener), this.sessionStartListener = void 0)
      }
    };

    function bX(OO, KO, pO, XO) {
      const bK = {
        filename: OO || document.location.href,
        function: KO || "?"
      };
      return void 0 !== pO && (bK.lineno = pO), void 0 !== XO && (bK.colno = XO), bK
    }
    const ep = /^\s*at (?:(?![a-z]+:\/\/)([^(]+?) ?\((?:address at )?)?((?:file|https?|blob|chrome-extension|address|native|eval|webpack|<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
      lp = /\((\S*)(?::(\d+))(?::(\d+))\)/,
      vX = /^(?=[\s\S]*?(?:\/|bundle|\.js|\[native code]))\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:file|https?|blob|chrome|webpack|resource|moz-extension|safari-extension|safari-web-extension|capacitor)?:\/.*?|\[native code]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
      Cp = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
      hp = "safari-extension",
      Dp = "safari-web-extension",
      Mp = /Minified React error #\d+;/i;

    function aX(OO, KO) {
      const pO = null === OO || void 0 === OO ? void 0 : OO.includes(hp),
        XO = !pO && (null === OO || void 0 === OO ? void 0 : OO.includes("safari-web-extension"));
      return pO || XO ? [(null === OO || void 0 === OO ? void 0 : OO.includes("@")) ? OO.split("@")[0] : OO, pO ? `${hp}:${KO}` : `${Dp}:${KO}`] : [OO, KO]
    }
    const op = 1024;

    function Fp(OO) {
      let KO = [];
      OO.stacktrace ? KO = OO.stacktrace.split("\n").filter(((OO, KO) => KO % 2 === 0)) : OO.stack && (KO = OO.stack.split("\n"));
      const pO = KO.reduce(((KO, pO, XO) => {
        if (pO.length > op) return KO;
        let bK, eO, lO, vK, CO;
        if (bK = ep.exec(pO)) {
          if (eO = bK[1], lO = bK[2], vK = bK[3], CO = bK[4], null === lO || void 0 === lO ? void 0 : lO.startsWith("eval")) {
            const OO = lp.exec(lO);
            OO && (lO = OO[1], vK = OO[2], CO = OO[3])
          }
          lO = (null === lO || void 0 === lO ? void 0 : lO.startsWith("address at ")) ? lO.substring(11) : lO, [eO, lO] = aX(eO, lO)
        } else if (bK = vX.exec(pO)) {
          if (eO = bK[1], lO = bK[3], vK = bK[4], CO = bK[5], lO && lO.includes(" > eval")) {
            const OO = Cp.exec(lO);
            OO && (eO = eO || "eval", lO = OO[1], vK = OO[2])
          } else 0 === XO && !CO && NO(OO.columnNumber) && (CO = String(OO.columnNumber + 1));
          [eO, lO] = aX(eO, lO)
        }
        return (lO || eO) && KO.push(bX(lO, eO, vK ? Number(vK) : void 0, CO ? Number(CO) : void 0)), KO
      }), []);
      return Mp.test(OO.message) ? pO.slice(1) : pO
    }

    function Vp(OO) {
      return {
        frames: Fp(OO)
      }
    }
    const Lp = "http-request-start",
      Qp = "http-request-end";
    var zX = class OO {
      constructor() {
        this.subscribers = []
      }
      subscribe(OO) {
        return this.subscribers.push(OO), {
          unsubscribe: () => this.unsubscribe(OO)
        }
      }
      unsubscribe(OO) {
        this.subscribers = this.subscribers.filter((KO => KO !== OO))
      }
      notify(OO) {
        this.subscribers.forEach((KO => KO(OO)))
      }
      first() {
        const KO = new OO,
          pO = OO => {
            KO.notify(OO), XO.unsubscribe()
          },
          XO = this.subscribe(pO),
          bK = KO.unsubscribe.bind(KO);
        return this.withUnsubscribeOverride(KO, bK, pO)
      }
      takeWhile(KO) {
        const pO = new OO,
          XO = OO => {
            KO(OO) ? pO.notify(OO) : pO.unsubscribe(XO)
          };
        this.subscribe(XO);
        const bK = pO.unsubscribe.bind(pO);
        return this.withUnsubscribeOverride(pO, bK, XO)
      }
      filter(KO) {
        const pO = new OO,
          XO = OO => {
            KO(OO) && pO.notify(OO)
          };
        this.subscribe(XO);
        const bK = pO.unsubscribe.bind(pO);
        return this.withUnsubscribeOverride(pO, bK, XO)
      }
      merge() {
        const KO = new OO,
          pO = [];
        for (var XO = arguments.length, bK = new Array(XO), eO = 0; eO < XO; eO++) bK[eO] = arguments[eO];
        bK.forEach((OO => {
          const XO = OO.subscribe((OO => {
            KO.notify(OO)
          }));
          pO.push(XO)
        }));
        const lO = KO.unsubscribeAll.bind(KO);
        return KO.unsubscribe = () => {
          pO.forEach((OO => OO.unsubscribe())), lO()
        }, KO
      }
      withUnsubscribeOverride(OO, KO, pO) {
        return OO.unsubscribe = OO => {
          KO(OO), this.unsubscribe(pO)
        }, OO
      }
      unsubscribeAll() {
        this.subscribers = []
      }
    };
    let Ap = function(OO) {
      return OO.TRACE = "trace", OO.DEBUG = "debug", OO.INFO = "info", OO.LOG = "log", OO.WARN = "warn", OO.ERROR = "error", OO
    }({});
    const fp = "log",
      dp = ["trace", "debug", "info", "log", "warn", "error"];
    let Tp, Np = !1;
    const Ip = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/i,
      yX = "Error",
      gX = OO => OO.map((OO => uO(OO) ? PK(OO) : String(OO))).join(" ");

    function upO(OO) {
      let KO, pO, XO, bK, eO = [];
      if (HO(OO) && OO.error) KO = OO.error.message, pO = OO.error.name, eO = Fp(OO.error);
      else if ((XO = RO(OO)) || SO(OO)) {
        const {
          name: bK,
          message: eO
        } = OO;
        pO = null !== bK && void 0 !== bK ? bK : XO ? "DOMError" : "DOMException", KO = eO ? `${pO}: ${eO}` : pO
      } else sO(OO) ? (pO = OO.name, KO = OO.message, eO = Fp(OO)) : (uO(OO) || (bK = PO(OO))) && (pO = bK ? OO.constructor.name : void 0, KO = `Non-Error exception captured with keys: ${Object.keys(OO)}`);
      return [KO, pO, eO]
    }

    function Ep(OO) {
      const [KO, pO, XO, bK, eO] = OO;
      let lO, vK, CO = [];
      const hO = TO(KO),
        DO = bX(pO, "?", XO, bK);
      return eO || !hO ? ([lO, vK, CO] = upO(null !== eO && void 0 !== eO ? eO : KO), 0 === CO.length && (CO = [DO])) : hO && ([lO, vK] = function(OO) {
        var KO, pO;
        const XO = OO.match(Ip),
          bK = null !== (KO = null === XO || void 0 === XO ? void 0 : XO[1]) && void 0 !== KO ? KO : yX;
        return [null !== (pO = null === XO || void 0 === XO ? void 0 : XO[2]) && void 0 !== pO ? pO : OO, bK]
      }(KO), CO = [DO]), {
        value: lO,
        type: vK,
        stackFrames: CO
      }
    }

    function jX(OO, KO) {
      return sO(OO[0]) ? Ep(OO) : {
        value: KO(OO)
      }
    }
    const Yp = OO => OO.map((OO => {
      try {
        return String(OO)
      } catch (KO) {
        return ""
      }
    })).join(" ");
    var wp = class OO extends Kp {
      constructor() {
        super(...arguments), this.name = "@grafana/faro-web-sdk:instrumentation-console", this.version = pp, this.errorSerializer = Yp
      }
      initialize() {
        var KO, pO;
        const XO = this.config.consoleInstrumentation,
          bK = (null === XO || void 0 === XO ? void 0 : XO.serializeErrors) || !!(null === XO || void 0 === XO ? void 0 : XO.errorSerializer);
        this.errorSerializer = bK ? null !== (KO = null === XO || void 0 === XO ? void 0 : XO.errorSerializer) && void 0 !== KO ? KO : gX : Yp;
        const eO = null !== (pO = null === XO || void 0 === XO ? void 0 : XO.disabledLevels) && void 0 !== pO ? pO : OO.defaultDisabledLevels,
          lO = function(OO) {
            if (Tp || (Tp = new zX), !Np) {
              const KO = null !== OO && void 0 !== OO ? OO : UK;
              dp.forEach((OO => {
                console[OO] = function() {
                  for (var pO, XO = arguments.length, bK = new Array(XO), eO = 0; eO < XO; eO++) bK[eO] = arguments[eO];
                  Tp.notify({
                    type: "console",
                    level: OO,
                    args: bK
                  }), null === (pO = KO[OO]) || void 0 === pO || pO.apply(console, bK)
                }
              })), Np = !0
            }
            return Tp
          }(this.unpatchedConsole);
        this.subscription = lO.subscribe((KO => {
          let {
            level: pO,
            args: bK
          } = KO;
          if (!eO.includes(pO)) try {
            if (pO !== Ap.ERROR || (null === XO || void 0 === XO ? void 0 : XO.consoleErrorAsLog))
              if (pO === Ap.ERROR && (null === XO || void 0 === XO ? void 0 : XO.consoleErrorAsLog)) {
                const {
                  value: KO,
                  type: XO,
                  stackFrames: eO
                } = jX(bK, this.errorSerializer);
                this.api.pushLog(KO ? [OO.consoleErrorPrefix + KO] : bK, {
                  level: pO,
                  context: {
                    value: null !== KO && void 0 !== KO ? KO : "",
                    type: null !== XO && void 0 !== XO ? XO : "",
                    stackFrames: (null === eO || void 0 === eO ? void 0 : eO.length) ? gX(eO) : ""
                  }
                })
              } else this.api.pushLog(bK, {
                level: pO
              });
            else {
              const {
                value: KO,
                type: pO,
                stackFrames: XO
              } = jX(bK, this.errorSerializer);
              if (KO && !pO && !XO) return void this.api.pushError(new Error(OO.consoleErrorPrefix + KO));
              this.api.pushError(new Error(OO.consoleErrorPrefix + KO), {
                type: pO,
                stackFrames: XO
              })
            }
          } catch (lO) {
            this.logError(lO)
          }
        }))
      }
      destroy() {
        var OO;
        null === (OO = this.subscription) || void 0 === OO || OO.unsubscribe(), this.subscription = void 0
      }
    };
    wp.defaultDisabledLevels = [Ap.DEBUG, Ap.TRACE, Ap.LOG], wp.consoleErrorPrefix = "console.error: ";
    const iX = [];
    var rX = class extends Kp {
      constructor() {
        super(...arguments), this.name = "@grafana/faro-web-sdk:instrumentation-errors", this.version = pp
      }
      initialize() {
        this.logDebug("Initializing"),
          function(OO) {
            const KO = window.onerror;
            window.onerror = function() {
              for (var pO = arguments.length, XO = new Array(pO), bK = 0; bK < pO; bK++) XO[bK] = arguments[bK];
              try {
                const {
                  value: KO,
                  type: pO,
                  stackFrames: bK
                } = Ep(XO), eO = XO[4];
                if (KO) {
                  const XO = {
                    type: pO,
                    stackFrames: bK
                  };
                  null != eO && (XO.originalError = eO), OO.pushError(new Error(KO), XO)
                }
              } finally {
                null === KO || void 0 === KO || KO.apply(window, XO)
              }
            }
          }(this.api),
          function(OO) {
            const KO = KO => {
              var pO;
              let XO, bK, eO = KO;
              if (eO.reason) eO = KO.reason;
              else if (null === (pO = KO.detail) || void 0 === pO ? void 0 : pO.reason) {
                var lO;
                eO = null === (lO = KO.detail) || void 0 === lO ? void 0 : lO.reason
              }
              let vK = [];
              iK(eO) ? (XO = `Non-Error promise rejection captured with value: ${String(eO)}`, bK = "UnhandledRejection") : [XO, bK, vK] = upO(eO), XO && OO.pushError(new Error(XO), {
                type: bK,
                stackFrames: vK
              })
            };
            window.addEventListener("unhandledrejection", KO), iX.push(KO)
          }(this.api)
      }
    };
    const Pp = "unknown";
    var mX = class extends Kp {
      constructor() {
        super(...arguments), this.name = "@grafana/faro-web-sdk:instrumentation-view", this.version = pp, this.waitingForActivation = !1, this.sendViewChangedEvent = OO => {
          var KO;
          if (this.waitingForActivation || document.prerendering) return;
          const pO = OO.view;
          if (pO && pO.name !== (null === (KO = this.notifiedView) || void 0 === KO ? void 0 : KO.name)) {
            var XO, bK, eO;
            const OO = null !== (XO = null === (bK = this.notifiedView) || void 0 === bK ? void 0 : bK.name) && void 0 !== XO ? XO : Pp;
            this.notifiedView = pO, this.api.pushEvent(dK, {
              fromView: OO,
              toView: null !== (eO = pO.name) && void 0 !== eO ? eO : Pp
            }, void 0, {
              skipDedupe: !0
            })
          }
        }, this.prerenderListener = () => {
          window.queueMicrotask((() => {
            this.waitingForActivation && (this.waitingForActivation = !1, this.sendViewChangedEvent(this.metas.value))
          }))
        }
      }
      initialize() {
        this.metas.addListener(this.sendViewChangedEvent), document.prerendering && (this.waitingForActivation = !0, document.addEventListener("prerenderingchange", this.prerenderListener, {
          once: !0
        }))
      }
      destroy() {
        this.waitingForActivation = !1, this.metas.removeListener(this.sendViewChangedEvent), document.removeEventListener("prerenderingchange", this.prerenderListener)
      }
    };
    class sp {
      t;
      o = 0;
      i = [];
      l(OO) {
        if (OO.hadRecentInput) return;
        const KO = this.i[0],
          pO = this.i.at(-1);
        this.o && KO && pO && OO.startTime - pO.startTime < 1e3 && OO.startTime - KO.startTime < 5e3 ? (this.o += OO.value, this.i.push(OO)) : (this.o = OO.value, this.i = [OO]), this.t?.(OO)
      }
    }
    const Hp = () => {
        const OO = performance.getEntriesByType("navigation")[0];
        if (OO && OO.responseStart > 0 && OO.responseStart < performance.now()) return OO
      },
      Rp = OO => {
        if ("loading" === document.readyState) return "loading";
        const KO = Hp();
        if (KO) {
          if (OO < KO.domInteractive) return "loading";
          if (0 === KO.domContentLoadedEventStart || OO < KO.domContentLoadedEventStart) return "dom-interactive";
          if (0 === KO.domComplete || OO < KO.domComplete) return "dom-content-loaded"
        }
        return "complete"
      },
      Sp = OO => {
        const KO = OO.nodeName;
        return 1 === OO.nodeType ? KO.toLowerCase() : KO.toUpperCase().replace(/^#/, "")
      },
      Jp = OO => {
        let KO = "";
        try {
          for (; 9 !== OO?.nodeType;) {
            const pO = OO,
              XO = pO.id ? "#" + pO.id : [Sp(pO), ...Array.from(pO.classList ?? []).sort()].join(".");
            if (KO.length + XO.length > 99) return KO || XO;
            if (KO = KO ? XO + ">" + KO : XO, pO.id) break;
            OO = pO.parentNode
          }
        } catch {}
        return KO
      },
      cX = new WeakMap;

    function Bp(OO, KO) {
      let pO = cX.get(KO);
      return pO || (pO = new WeakMap, cX.set(KO, pO)), pO.get(OO) || pO.set(OO, new KO), pO.get(OO)
    }
    let Zp = -1;
    const Gp = () => Zp,
      qX = OO => {
        addEventListener("pageshow", (KO => {
          KO.persisted && (Zp = KO.timeStamp, OO(KO))
        }), !0)
      },
      xX = (OO, KO, pO, XO) => {
        let bK, eO;
        return lO => {
          KO.value >= 0 && (lO || XO) && (eO = KO.value - (bK ?? 0), (eO || void 0 === bK) && (bK = KO.value, KO.delta = eO, KO.rating = ((OO, KO) => OO > KO[1] ? "poor" : OO > KO[0] ? "needs-improvement" : "good")(KO.value, pO), OO(KO)))
        }
      },
      np = OO => {
        requestAnimationFrame((() => requestAnimationFrame((() => OO()))))
      },
      Wp = () => Hp()?.activationStart ?? 0;
    let tX = -1;
    const kX = new Set,
      Up = () => "hidden" !== document.visibilityState || document.prerendering ? 1 / 0 : 0,
      OX = OO => {
        if ("hidden" === document.visibilityState) {
          if ("visibilitychange" === OO.type)
            for (const OO of kX) OO();
          isFinite(tX) || (tX = "visibilitychange" === OO.type ? OO.timeStamp : 0, removeEventListener("prerenderingchange", OX, !0))
        }
      },
      KX = function() {
        if (arguments.length > 0 && void 0 !== arguments[0] && arguments[0] && (tX = 1 / 0), tX < 0) {
          const OO = Wp(),
            KO = document.prerendering ? void 0 : globalThis.performance.getEntriesByType("visibility-state").find((KO => "hidden" === KO.name && KO.startTime >= OO))?.startTime;
          tX = KO ?? Up(), addEventListener("visibilitychange", OX, !0), addEventListener("prerenderingchange", OX, !0), qX((() => {
            setTimeout((() => {
              tX = Up()
            }))
          }))
        }
        return {
          get firstHiddenTime() {
            return tX
          },
          onHidden(OO) {
            kX.add(OO)
          }
        }
      },
      pX = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
          bK = arguments.length > 4 ? arguments[4] : void 0,
          eO = arguments.length > 5 ? arguments[5] : void 0,
          lO = arguments.length > 6 ? arguments[6] : void 0;
        const vK = Hp(),
          CO = vK?.navigationId || 0;
        let hO = "navigate";
        return pO ? hO = pO : Gp() >= 0 ? hO = "back-forward-cache" : vK && (document.prerendering || Wp() > 0 ? hO = "prerender" : document.wasDiscarded ? hO = "restore" : vK.type && (hO = vK.type.replace(/_/g, "-"))), {
          name: OO,
          value: KO,
          rating: "good",
          delta: 0,
          entries: [],
          id: `v6-${Date.now()}-${Math.floor(8999999999999*Math.random())+1e12}`,
          navigationType: hO,
          navigationId: XO || CO,
          navigationInteractionId: bK,
          navigationURL: eO || vK?.name,
          navigationStartTime: lO || 0
        }
      },
      XX = function(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        try {
          const XO = OO.filter((OO => PerformanceObserver.supportedEntryTypes.includes(OO)));
          if (XO.length > 0) {
            const OO = new PerformanceObserver((OO => {
              queueMicrotask((() => {
                const pO = OO.getEntries();
                XO.length > 1 && pO.sort(((OO, KO) => OO.startTime + OO.duration - (KO.startTime + KO.duration))), KO(pO)
              }))
            }));
            for (const KO of XO) OO.observe({
              type: KO,
              buffered: !0,
              ...pO
            });
            return OO
          }
        } catch {}
      },
      bb = OO => globalThis.PerformanceObserver?.supportedEntryTypes?.includes("soft-navigation") && "function" == typeof globalThis.PerformanceSoftNavigation?.prototype?.getLargestInteractionContentfulPaint && OO && OO.reportSoftNavs,
      eX = (OO, KO) => {
        if (OO.set(KO.navigationId, KO), OO.size > 2) {
          const KO = OO.keys().next().value;
          void 0 !== KO && OO.delete(KO)
        }
      },
      lX = OO => {
        let KO = !1;
        return () => {
          KO || (OO(), KO = !0)
        }
      };
    class vb {
      u
    }
    const CX = OO => {
        document.prerendering ? addEventListener("prerenderingchange", OO, !0) : OO()
      },
      hX = [1800, 3e3],
      DX = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const pO = bb(KO);
        CX((() => {
          const XO = Bp(KO, vb),
            bK = KX();
          let eO, lO = pX("FCP");
          const vK = XX(["paint"], (OO => {
            for (const KO of OO) "first-contentful-paint" === KO.name && (vK.disconnect(), KO.startTime < bK.firstHiddenTime && (lO.value = Math.max(KO.startTime - Wp(), 0), lO.entries.push(KO), lO.navigationId = KO.navigationId || lO.navigationId, eO(!0)))
          }));
          vK && (eO = xX(OO, lO, hX, KO.reportAllChanges), qX((pO => {
            lO = pX("FCP", -1, "back-forward-cache", lO.navigationId, lO.navigationInteractionId, lO.navigationURL, Gp()), eO = xX(OO, lO, hX, KO.reportAllChanges), np((() => {
              lO.value = performance.now() - pO.timeStamp, eO(!0)
            }))
          }))), pO && XX(["soft-navigation"], (pO => {
            pO.forEach((pO => {
              XO.u && pO.navigationId && eX(XO.u, pO);
              const bK = Math.max((pO.presentationTime || pO.paintTime || 0) - pO.startTime, 0);
              lO = pX("FCP", bK, "soft-navigation", pO.navigationId, pO.interactionId, pO.name, pO.startTime), eO = xX(OO, lO, hX, KO.reportAllChanges), eO(!0)
            }))
          }), KO)
        }))
      },
      MX = [.1, .25],
      ab = OO => OO.find((OO => 1 === OO.node?.nodeType)) || OO[0];
    let oX = 0,
      FX = 1 / 0,
      VX = 0;
    const LX = OO => {
      for (const KO of OO) KO.interactionId && (FX = Math.min(FX, KO.interactionId), VX = Math.max(VX, KO.interactionId), oX = VX ? (VX - FX) / 7 + 1 : 0)
    };
    let QX;
    const zb = () => QX ? oX : performance.interactionCount ?? 0;
    class AX {
      h = 0;
      v = [];
      p = new Map;
      m;
      M;
      T() {
        return zb() - this.h
      }
      D() {
        this.h = zb(), this.v.length = 0, this.p.clear()
      }
      S(OO) {
        const KO = this.T(),
          pO = Math.min(this.v.length - 1, Math.floor(KO / 50));
        return !KO || -1 !== pO || "soft-navigation" !== OO && "back-forward-cache" !== OO ? this.v[pO] : {
          k: 8,
          id: -1,
          entries: []
        }
      }
      l(OO) {
        if (this.m?.(OO), !OO.interactionId) return;
        const KO = this.v.at(-1);
        let pO = this.p.get(OO.interactionId);
        if (pO || this.v.length < 10 || OO.duration > KO.k) {
          if (pO ? OO.duration > pO.k ? (pO.entries = [OO], pO.k = OO.duration) : OO.duration === pO.k && OO.startTime === pO.entries[0].startTime && pO.entries.push(OO) : (pO = {
              id: OO.interactionId,
              entries: [OO],
              k: OO.duration
            }, this.p.set(pO.id, pO), this.v.push(pO)), this.v.sort(((OO, KO) => KO.k - OO.k)), this.v.length > 10) {
            const OO = this.v.splice(10);
            for (const KO of OO) this.p.delete(KO.id)
          }
          this.M?.(pO)
        }
      }
    }
    const fX = OO => {
        const KO = "requestIdleCallback" in globalThis ? 1e3 : 0,
          pO = globalThis.requestIdleCallback || setTimeout,
          XO = globalThis.cancelIdleCallback || clearTimeout;
        if ("hidden" === document.visibilityState) OO();
        else {
          const bK = lX(OO);
          let eO = -1;
          const lO = () => {
            XO(eO), bK()
          };
          addEventListener("visibilitychange", lO, {
            once: !0,
            capture: !0
          }), eO = pO((() => {
            removeEventListener("visibilitychange", lO, {
              capture: !0
            }), bK()
          }), {
            timeout: KO
          })
        }
      },
      dX = [200, 500],
      TX = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const pO = Bp(KO = Object.assign({}, KO), AX);
        let XO = [],
          bK = [],
          eO = 0;
        const lO = new WeakMap,
          vK = new WeakMap;
        let CO = !1;
        const hO = () => {
            CO || (CO = !0, fX(DO))
          },
          DO = () => {
            const OO = new Set(pO.v.map((OO => lO.get(OO.entries[0])))),
              KO = bK.length - 10;
            bK = bK.filter(((pO, XO) => XO >= KO || OO.has(pO)));
            const vK = new Set;
            for (const pO of bK) {
              const OO = MO(pO.startTime, pO.processingEnd);
              for (const KO of OO) vK.add(KO)
            }
            const hO = XO.length - 10;
            XO = XO.filter(((OO, KO) => vK.has(OO) || KO >= hO && OO.startTime > eO)), CO = !1
          };
        pO.m = OO => {
          const pO = OO.startTime + OO.duration;
          let XO;
          eO = Math.max(eO, OO.processingEnd);
          for (let eO = bK.length - 1; eO >= 0; eO--) {
            const lO = bK[eO];
            if (Math.abs(pO - lO.renderTime) <= 8) {
              XO = lO, XO.startTime = Math.min(OO.startTime, XO.startTime), XO.processingStart = Math.min(OO.processingStart, XO.processingStart), XO.processingEnd = Math.max(OO.processingEnd, XO.processingEnd), KO.includeProcessedEventEntries && XO.entries.push(OO);
              break
            }
          }
          XO || (XO = {
            startTime: OO.startTime,
            processingStart: OO.processingStart,
            processingEnd: OO.processingEnd,
            renderTime: pO,
            entries: KO.includeProcessedEventEntries ? [OO] : []
          }, bK.push(XO)), OO.interactionId && lO.set(OO, XO), hO()
        }, pO.M = OO => {
          if (!vK.get(OO)) {
            const pO = OO.entries.find((OO => OO.target))?.target;
            if (pO) {
              const XO = KO.generateTarget?.(pO) ?? Jp(pO);
              vK.set(OO, XO)
            } else {
              const KO = OO.entries.find((OO => OO.targetSelector))?.targetSelector;
              KO && vK.set(OO, KO)
            }
          }
        };
        const MO = (OO, KO) => {
          const pO = [];
          for (const bK of XO)
            if (!(bK.startTime + bK.duration < OO)) {
              if (bK.startTime > KO) break;
              pO.push(bK)
            } return pO
        };
        XX(["long-animation-frame"], (OO => {
            XO = XO.concat(OO), hO()
          }), KO),
          function(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            if (!globalThis.PerformanceEventTiming || !("interactionId" in PerformanceEventTiming.prototype)) return;
            const pO = KX();
            CX((() => {
              "interactionCount" in performance || QX || (QX = XX(["event"], LX, {
                durationThreshold: 0
              }));
              let XO, bK = pX("INP");
              const eO = Bp(KO, AX),
                lO = (pO, lO, vK, CO, hO) => {
                  eO.D(), bK = pX("INP", -1, pO, lO, vK, CO, hO), XO = xX(OO, bK, dX, KO.reportAllChanges)
                },
                vK = () => {
                  const OO = eO.S(bK.navigationType);
                  OO && OO.k !== bK.value && (bK.value = OO.k, bK.entries = OO.entries, XO())
                },
                CO = OO => {
                  vK(), XO(!0), lO("soft-navigation", OO.navigationId, OO.interactionId, OO.name, OO.startTime)
                },
                hO = function(OO) {
                  let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                  fX((() => {
                    for (const KO of OO) "soft-navigation" !== KO.entryType ? eO.l(KO) : CO(KO);
                    vK(), KO && XO(!0)
                  }))
                },
                DO = ["event", "first-input"];
              bb(KO) && DO.push("soft-navigation");
              const MO = XX(DO, hO, {
                ...KO,
                durationThreshold: KO.durationThreshold ?? 40
              });
              XO = xX(OO, bK, dX, KO.reportAllChanges), MO && (pO.onHidden((() => {
                hO(MO.takeRecords(), !0)
              })), qX((() => {
                lO("back-forward-cache", bK.navigationId, bK.navigationInteractionId, bK.navigationURL, Gp())
              })))
            }))
          }((KO => {
            OO((OO => {
              if (0 === OO.entries.length) {
                const KO = OO.navigationStartTime || 0,
                  pO = {
                    processedEventEntries: [],
                    longAnimationFrameEntries: [],
                    inputDelay: 0,
                    processingDuration: 0,
                    presentationDelay: OO.value,
                    loadState: Rp(KO)
                  };
                return Object.assign(OO, {
                  attribution: pO
                })
              }
              const KO = OO.entries[0],
                XO = lO.get(KO),
                bK = Math.max(XO.processingStart, KO.startTime),
                eO = Math.max(KO.startTime + KO.duration, bK),
                CO = Math.min(XO.processingEnd, eO),
                hO = XO.entries.sort(((OO, KO) => OO.processingStart - KO.processingStart)),
                DO = MO(KO.startTime, CO),
                aK = pO.p.get(KO.interactionId),
                oO = {
                  interactionTarget: vK.get(aK),
                  interactionType: KO.name.startsWith("key") ? "keyboard" : "pointer",
                  interactionTime: KO.startTime,
                  nextPaintTime: eO,
                  processedEventEntries: hO,
                  longAnimationFrameEntries: DO,
                  inputDelay: bK - KO.startTime,
                  processingDuration: CO - bK,
                  presentationDelay: eO - CO,
                  loadState: Rp(KO.startTime),
                  longestScript: void 0,
                  totalScriptDuration: void 0,
                  totalStyleAndLayoutDuration: void 0,
                  totalPaintDuration: void 0,
                  totalUnattributedDuration: void 0
                };
              return (OO => {
                const KO = OO.interactionTime,
                  pO = OO.nextPaintTime;
                if (!OO.longAnimationFrameEntries?.length || !KO || !pO) return;
                const XO = OO.inputDelay,
                  bK = OO.processingDuration;
                let eO, lO, vK = 0,
                  CO = 0,
                  hO = 0,
                  DO = 0;
                for (const oO of OO.longAnimationFrameEntries) {
                  CO = CO + oO.startTime + oO.duration - oO.styleAndLayoutStart;
                  for (const OO of oO.scripts) {
                    const pO = OO.startTime + OO.duration;
                    if (pO < KO) continue;
                    const hO = pO - Math.max(KO, OO.startTime),
                      MO = OO.duration ? hO / OO.duration * OO.forcedStyleAndLayoutDuration : 0;
                    vK += hO - MO, CO += MO, hO > DO && (lO = OO.startTime < KO + XO ? "input-delay" : OO.startTime >= KO + XO + bK ? "presentation-delay" : "processing-duration", eO = OO, DO = hO)
                  }
                }
                const MO = OO.longAnimationFrameEntries.at(-1),
                  aK = MO ? MO.startTime + MO.duration : 0;
                aK >= KO + XO + bK && (hO = pO - aK), eO && lO && (OO.longestScript = {
                  entry: eO,
                  subpart: lO,
                  intersectingDuration: DO
                }), OO.totalScriptDuration = vK, OO.totalStyleAndLayoutDuration = CO, OO.totalPaintDuration = hO, OO.totalUnattributedDuration = pO - KO - vK - CO - hO
              })(oO), Object.assign(OO, {
                attribution: oO
              })
            })(KO))
          }), KO)
      };
    class NX {
      m;
      u;
      l(OO) {
        this.m?.(OO)
      }
    }
    const IX = [2500, 4e3];
    let yb = 50;
    const gb = [];
    XX(["resource"], (OO => {
      for (const KO of OO) gb.push(KO), gb.length > yb && gb.shift()
    }));
    const uX = [800, 1800],
      EX = OO => {
        document.prerendering ? CX((() => EX(OO))) : "complete" !== document.readyState ? addEventListener("load", (() => EX(OO)), !0) : setTimeout(OO)
      },
      jb = "load_state",
      YX = "time_to_first_byte";
    var wX = class {
        constructor(OO, KO) {
          this.corePushMeasurement = OO, this.webVitalConfig = KO
        }
        initialize() {
          this.measureCLS(), this.measureFCP(), this.measureINP(), this.measureLCP(), this.measureTTFB()
        }
        measureCLS() {
          var OO;
          ! function(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            const pO = Bp(KO = Object.assign({}, KO), sp),
              XO = new WeakMap;
            pO.t = OO => {
                if (OO?.sources?.length) {
                  const pO = ab(OO.sources),
                    bK = pO?.node;
                  if (bK) {
                    const OO = KO.generateTarget?.(bK) ?? Jp(bK);
                    XO.set(pO, OO)
                  }
                }
              },
              function(OO) {
                let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                const pO = KX();
                DX(lX((() => {
                  let XO, bK = pX("CLS", 0);
                  const eO = Bp(KO, sp),
                    lO = (pO, lO, vK, CO, hO) => {
                      bK = pX("CLS", 0, pO, lO, vK, CO, hO), eO.o = 0, XO = xX(OO, bK, MX, KO.reportAllChanges)
                    },
                    vK = function() {
                      let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                      eO.o > bK.value && (bK.value = eO.o, bK.entries = eO.i), XO(OO)
                    },
                    CO = OO => {
                      vK(!0), lO("soft-navigation", OO.navigationId, OO.interactionId, OO.name, OO.startTime)
                    },
                    hO = OO => {
                      for (const KO of OO) "soft-navigation" !== KO.entryType ? eO.l(KO) : CO(KO);
                      vK()
                    },
                    DO = ["layout-shift"];
                  bb(KO) && DO.push("soft-navigation");
                  const MO = XX(DO, hO);
                  MO && (XO = xX(OO, bK, MX, KO.reportAllChanges), pO.onHidden((() => {
                    hO(MO.takeRecords()), XO(!0)
                  })), qX((() => {
                    lO("back-forward-cache", bK.navigationId, bK.navigationInteractionId, bK.navigationURL, Gp()), np(XO)
                  })), setTimeout(XO))
                })))
              }((KO => {
                OO((OO => {
                  let KO = {};
                  if (OO.entries.length) {
                    const pO = OO.entries.reduce(((OO, KO) => OO.value > KO.value ? OO : KO));
                    if (pO?.sources?.length) {
                      const OO = ab(pO.sources);
                      OO && (KO = {
                        largestShiftTarget: XO.get(OO),
                        largestShiftTime: pO.startTime,
                        largestShiftValue: pO.value,
                        largestShiftSource: OO,
                        largestShiftEntry: pO,
                        loadState: Rp(pO.startTime)
                      })
                    }
                  }
                  return Object.assign(OO, {
                    attribution: KO
                  })
                })(KO))
              }), KO)
          }((OO => {
            const {
              loadState: KO,
              largestShiftValue: pO,
              largestShiftTime: XO,
              largestShiftTarget: bK
            } = OO.attribution, eO = this.buildInitialValues(OO);
            this.addIfPresent(eO, "largest_shift_value", pO), this.addIfPresent(eO, "largest_shift_time", XO);
            const lO = this.buildInitialContext(OO);
            this.addIfPresent(lO, jb, KO), this.addIfPresent(lO, "largest_shift_target", bK), this.pushMeasurement(eO, lO)
          }), {
            reportAllChanges: null === (OO = this.webVitalConfig) || void 0 === OO ? void 0 : OO.reportAllChanges
          })
        }
        measureFCP() {
          var OO;
          ! function(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            const pO = Bp(KO = Object.assign({}, KO), vb);
            bb(KO) && (pO.u = new Map), DX((KO => {
              OO((OO => {
                let KO = {
                  timeToFirstByte: 0,
                  firstByteToFCP: OO.value,
                  loadState: Rp(Gp())
                };
                if ("soft-navigation" !== OO.navigationType) {
                  if (OO.entries.length) {
                    const pO = Hp(),
                      XO = OO.entries.at(-1);
                    if (pO) {
                      const bK = pO.responseStart,
                        eO = pO.activationStart || 0,
                        lO = Math.max(0, bK - eO);
                      KO = {
                        timeToFirstByte: lO,
                        firstByteToFCP: OO.value - lO,
                        loadState: Rp(OO.entries[0].startTime),
                        navigationEntry: pO,
                        fcpEntry: XO
                      }
                    }
                  }
                } else {
                  const XO = pO.u?.get(OO.navigationId);
                  XO && (KO = {
                    timeToFirstByte: 0,
                    firstByteToFCP: OO.value,
                    loadState: "complete",
                    navigationEntry: XO
                  })
                }
                return Object.assign(OO, {
                  attribution: KO
                })
              })(KO))
            }), KO)
          }((OO => {
            const {
              firstByteToFCP: KO,
              timeToFirstByte: pO,
              loadState: XO
            } = OO.attribution, bK = this.buildInitialValues(OO);
            this.addIfPresent(bK, "first_byte_to_fcp", KO), this.addIfPresent(bK, YX, pO);
            const eO = this.buildInitialContext(OO);
            this.addIfPresent(eO, jb, XO), this.pushMeasurement(bK, eO)
          }), {
            reportAllChanges: null === (OO = this.webVitalConfig) || void 0 === OO ? void 0 : OO.reportAllChanges
          })
        }
        measureINP() {
          var OO;
          TX((OO => {
            var KO;
            const {
              interactionTime: pO,
              presentationDelay: XO,
              inputDelay: bK,
              processingDuration: eO,
              nextPaintTime: lO,
              loadState: vK,
              interactionTarget: CO,
              interactionType: hO,
              totalScriptDuration: DO,
              totalStyleAndLayoutDuration: MO,
              totalPaintDuration: aK,
              totalUnattributedDuration: oO,
              longestScript: FO
            } = OO.attribution, VO = this.buildInitialValues(OO);
            this.addIfPresent(VO, "interaction_time", pO), this.addIfPresent(VO, "presentation_delay", XO), this.addIfPresent(VO, "input_delay", bK), this.addIfPresent(VO, "processing_duration", eO), this.addIfPresent(VO, "next_paint_time", lO), this.addNumberIfDefined(VO, "total_script_duration", DO), this.addNumberIfDefined(VO, "total_style_and_layout_duration", MO), this.addNumberIfDefined(VO, "total_paint_duration", aK), this.addNumberIfDefined(VO, "total_unattributed_duration", oO), this.addNumberIfDefined(VO, "longest_script_intersecting_duration", null === FO || void 0 === FO ? void 0 : FO.intersectingDuration);
            const LO = this.buildInitialContext(OO);
            this.addIfPresent(LO, jb, vK), this.addIfPresent(LO, "interaction_target", CO), this.addIfPresent(LO, "interaction_type", hO), this.addIfPresent(LO, "longest_script_subpart", null === FO || void 0 === FO ? void 0 : FO.subpart), this.addIfPresent(LO, "longest_script_invoker_type", null === FO || void 0 === FO ? void 0 : FO.entry.invokerType), (null === (KO = this.webVitalConfig) || void 0 === KO ? void 0 : KO.trackAttributionSources) && (this.addIfPresent(LO, "longest_script_invoker", null === FO || void 0 === FO ? void 0 : FO.entry.invoker), this.addIfPresent(LO, "longest_script_source_url", null === FO || void 0 === FO ? void 0 : FO.entry.sourceURL), this.addIfPresent(LO, "longest_script_source_function_name", null === FO || void 0 === FO ? void 0 : FO.entry.sourceFunctionName), this.addIfPresent(LO, "longest_script_source_char_position", void 0 !== (null === FO || void 0 === FO ? void 0 : FO.entry.sourceCharPosition) ? String(FO.entry.sourceCharPosition) : void 0)), this.pushMeasurement(VO, LO)
          }), {
            reportAllChanges: null === (OO = this.webVitalConfig) || void 0 === OO ? void 0 : OO.reportAllChanges
          })
        }
        measureLCP() {
          var OO;
          ! function(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            null != (KO = Object.assign({}, KO)).resourceBufferSize && (yb = KO.resourceBufferSize);
            const pO = Bp(KO, NX),
              XO = new WeakMap;
            bb(KO) && (pO.u = new Map), pO.m = OO => {
                const pO = OO.element;
                if (pO) {
                  const bK = KO.generateTarget?.(pO) ?? Jp(pO);
                  XO.set(OO, bK)
                } else OO.id && XO.set(OO, `#${OO.id}`)
              },
              function(OO) {
                let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                  pO = !1;
                const XO = bb(KO);
                CX((() => {
                  let bK, eO = KX(),
                    lO = pX("LCP");
                  const vK = Bp(KO, NX),
                    CO = (XO, vK, CO, hO, DO) => {
                      lO = pX("LCP", -1, XO, vK, CO, hO, DO), bK = xX(OO, lO, IX, KO.reportAllChanges), pO = !1, "soft-navigation" === XO && (eO = KX(!0))
                    },
                    hO = OO => {
                      vK.u && OO.navigationId && eX(vK.u, OO), pO || bK(!0), CO("soft-navigation", OO.navigationId, OO.interactionId, OO.name, OO.startTime);
                      const KO = OO.getLargestInteractionContentfulPaint?.();
                      KO && DO([KO])
                    },
                    DO = OO => {
                      KO.reportAllChanges || XO || (OO = OO.slice(-1));
                      for (const KO of OO) {
                        if (!KO) continue;
                        if ("soft-navigation" === KO.entryType) {
                          hO(KO);
                          continue
                        }
                        let OO = 0,
                          pO = [],
                          XO = KO.startTime;
                        if ("largest-contentful-paint" === KO.entryType) OO = Math.max(KO.startTime - Wp(), 0), vK.l(KO), pO = [KO];
                        else if ("interaction-contentful-paint" === KO.entryType) {
                          const bK = KO;
                          if (!lO.navigationId) continue;
                          if ("interactionId" in bK && bK.interactionId != lO.navigationInteractionId) continue;
                          XO = bK.largestContentfulPaint?.renderTime || 0, OO = Math.max(XO - KO.startTime, 0), bK.largestContentfulPaint && (vK.l(bK.largestContentfulPaint), pO = [bK.largestContentfulPaint])
                        }
                        XO < eO.firstHiddenTime && (lO.value = OO, lO.entries = pO, bK())
                      }
                    },
                    MO = ["largest-contentful-paint"];
                  XO && MO.push("interaction-contentful-paint", "soft-navigation");
                  const aK = XX(MO, DO);
                  if (aK) {
                    bK = xX(OO, lO, IX, KO.reportAllChanges);
                    const eO = ["keydown", "click", "visibilitychange"],
                      vK = OO => {
                        if (OO.isTrusted && !pO) {
                          const OO = lO.id;
                          fX((() => {
                            if (!pO) {
                              if (!XO) {
                                aK.disconnect();
                                for (const OO of eO) removeEventListener(OO, vK, {
                                  capture: !0
                                })
                              }
                              OO === lO.id && (pO = !0, bK(!0))
                            }
                          }))
                        }
                      };
                    for (const OO of eO) addEventListener(OO, vK, {
                      capture: !0
                    });
                    qX((XO => {
                      CO("back-forward-cache", lO.navigationId, lO.navigationInteractionId, lO.navigationURL, Gp()), bK = xX(OO, lO, IX, KO.reportAllChanges), np((() => {
                        lO.value = performance.now() - XO.timeStamp, pO = !0, bK(!0)
                      }))
                    }))
                  }
                }))
              }((KO => {
                OO((OO => {
                  let KO = {
                    timeToFirstByte: 0,
                    resourceLoadDelay: 0,
                    resourceLoadDuration: 0,
                    elementRenderDelay: OO.value
                  };
                  if (OO.entries.length) {
                    const bK = OO.entries.at(-1),
                      eO = OO => OO.name === bK.url && (OO.requestStart || OO.startTime) <= bK.startTime,
                      lO = bK.url && (gb.findLast(eO) || performance.getEntriesByType("resource").findLast(eO));
                    let vK;
                    KO.target = XO.get(bK), KO.lcpEntry = bK, bK.url && (KO.url = bK.url), lO && (KO.lcpResourceEntry = lO);
                    let CO = 0,
                      hO = 0;
                    if ("soft-navigation" !== OO.navigationType ? (vK = Hp(), CO = vK?.activationStart ?? 0, hO = vK?.responseStart ?? 0) : (CO = OO.navigationStartTime || 0, vK = pO.u?.get(OO.navigationId)), vK) {
                      const pO = Math.max(0, hO - CO),
                        XO = Math.max(pO, lO ? (lO.requestStart || lO.startTime) - CO : 0),
                        bK = Math.min(OO.value, Math.max(XO, lO ? lO.responseEnd - CO : 0));
                      KO = {
                        ...KO,
                        timeToFirstByte: pO,
                        resourceLoadDelay: XO - pO,
                        resourceLoadDuration: bK - XO,
                        elementRenderDelay: OO.value - bK,
                        navigationEntry: vK
                      }
                    }
                  }
                  return Object.assign(OO, {
                    attribution: KO
                  })
                })(KO))
              }), KO)
          }((OO => {
            var KO;
            const {
              elementRenderDelay: pO,
              resourceLoadDelay: XO,
              resourceLoadDuration: bK,
              timeToFirstByte: eO,
              target: lO,
              url: vK,
              lcpResourceEntry: CO
            } = OO.attribution, hO = this.buildInitialValues(OO);
            this.addIfPresent(hO, "element_render_delay", pO), this.addIfPresent(hO, "resource_load_delay", XO), this.addIfPresent(hO, "resource_load_duration", bK), this.addIfPresent(hO, YX, eO);
            const DO = this.buildInitialContext(OO);
            this.addIfPresent(DO, "element", lO), (null === (KO = this.webVitalConfig) || void 0 === KO ? void 0 : KO.trackAttributionSources) && (this.addIfPresent(DO, "resource_url", vK), this.addIfPresent(DO, "resource_delivery_type", null === CO || void 0 === CO ? void 0 : CO.deliveryType), this.addIfPresent(DO, "resource_initiator_type", null === CO || void 0 === CO ? void 0 : CO.initiatorType)), this.pushMeasurement(hO, DO)
          }), {
            reportAllChanges: null === (OO = this.webVitalConfig) || void 0 === OO ? void 0 : OO.reportAllChanges
          })
        }
        measureTTFB() {
          var OO;
          ! function(OO) {
            ! function(OO) {
              let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
              const pO = bb(KO);
              let XO = pX("TTFB"),
                bK = xX(OO, XO, uX, KO.reportAllChanges);
              EX((() => {
                const eO = Hp();
                if (eO) {
                  const lO = eO.responseStart;
                  XO.value = Math.max(lO - Wp(), 0), XO.entries = [eO], bK(!0), qX((() => {
                    XO = pX("TTFB", 0, "back-forward-cache", XO.navigationId, XO.navigationInteractionId, XO.navigationURL, Gp()), bK = xX(OO, XO, uX, KO.reportAllChanges), bK(!0)
                  })), pO && XX(["soft-navigation"], (pO => {
                    pO.forEach((pO => {
                      pO.navigationId && (XO = pX("TTFB", 0, "soft-navigation", pO.navigationId, pO.interactionId, pO.name, pO.startTime), XO.entries = [pO], bK = xX(OO, XO, uX, KO.reportAllChanges), bK(!0))
                    }))
                  }), KO)
                }
              }))
            }((KO => {
              OO((OO => {
                const KO = OO.entries[0];
                let pO = {
                  waitingDuration: 0,
                  cacheDuration: 0,
                  dnsDuration: 0,
                  connectionDuration: 0,
                  requestDuration: 0,
                  navigationEntry: KO
                };
                if (OO.entries.length && KO instanceof PerformanceNavigationTiming) {
                  const XO = KO.activationStart || 0,
                    bK = Math.max((KO.workerStart || KO.fetchStart || 0) - XO, 0),
                    eO = Math.max(KO.domainLookupStart - XO, 0),
                    lO = Math.max(KO.connectStart - XO, 0),
                    vK = Math.max(KO.connectEnd - XO, 0);
                  pO = {
                    waitingDuration: bK,
                    cacheDuration: eO - bK,
                    dnsDuration: lO - eO,
                    connectionDuration: vK - lO,
                    requestDuration: OO.value - vK,
                    navigationEntry: KO
                  }
                }
                return Object.assign(OO, {
                  attribution: pO
                })
              })(KO))
            }), arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {})
          }((OO => {
            const {
              dnsDuration: KO,
              connectionDuration: pO,
              requestDuration: XO,
              waitingDuration: bK,
              cacheDuration: eO
            } = OO.attribution, lO = this.buildInitialValues(OO);
            this.addIfPresent(lO, "dns_duration", KO), this.addIfPresent(lO, "connection_duration", pO), this.addIfPresent(lO, "request_duration", XO), this.addIfPresent(lO, "waiting_duration", bK), this.addIfPresent(lO, "cache_duration", eO);
            const vK = this.buildInitialContext(OO);
            this.pushMeasurement(lO, vK)
          }), {
            reportAllChanges: null === (OO = this.webVitalConfig) || void 0 === OO ? void 0 : OO.reportAllChanges
          })
        }
        buildInitialValues(OO) {
          return {
            [OO.name.toLowerCase()]: OO.value,
            delta: OO.delta
          }
        }
        buildInitialContext(OO) {
          var KO;
          const pO = null !== (KO = OK("com.grafana.faro.lastNavigationId", tK)) && void 0 !== KO ? KO : Pp;
          return {
            id: OO.id,
            rating: OO.rating,
            navigation_type: OO.navigationType,
            navigation_entry_id: pO
          }
        }
        pushMeasurement(OO, KO) {
          this.corePushMeasurement({
            type: "web-vitals",
            values: OO
          }, {
            context: KO
          })
        }
        addIfPresent(OO, KO, pO) {
          pO && (OO[KO] = pO)
        }
        addNumberIfDefined(OO, KO, pO) {
          void 0 !== pO && (OO[KO] = pO)
        }
      },
      ib = class extends Kp {
        constructor() {
          super(...arguments), this.name = "@grafana/faro-web-sdk:instrumentation-web-vitals", this.version = pp
        }
        initialize() {
          this.logDebug("Initializing"), new wX(this.api.pushMeasurement, this.config.webVitalsInstrumentation).initialize()
        }
      };
    const rb = /^00-[a-f0-9]{32}-[a-f0-9]{16}-[0-9]{1,2}$/;

    function PX() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
      for (const KO of OO)
        if ("traceparent" === KO.name) {
          if (!rb.test(KO.description)) continue;
          const [, OO, pO] = KO.description.split("-");
          if (null != OO && null != pO) return {
            traceId: OO,
            spanId: pO
          };
          break
        }
    }

    function mb(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
        wallNow: Date.now(),
        monoNow: performance.now()
      };
      const {
        wallNow: pO,
        monoNow: XO
      } = KO;
      return Math.min(pO, pO - (XO - OO))
    }

    function sX(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      for (const [pO, XO] of Object.entries(KO)) {
        const KO = OO[pO];
        return null != KO && (jK(XO) ? XO.includes(KO) : KO === XO)
      }
      return !0
    }

    function HX(OO) {
      const {
        connectEnd: KO,
        connectStart: pO,
        decodedBodySize: XO,
        domainLookupEnd: bK,
        domainLookupStart: eO,
        duration: lO,
        encodedBodySize: vK,
        fetchStart: CO,
        initiatorType: hO,
        name: DO,
        nextHopProtocol: MO,
        redirectEnd: aK,
        redirectStart: oO,
        renderBlockingStatus: FO,
        requestStart: VO,
        responseEnd: LO,
        responseStart: QO,
        responseStatus: zK,
        secureConnectionStart: AO,
        transferSize: fO,
        workerStart: dO
      } = OO;
      return {
        name: DO,
        httpHost: SX(DO),
        duration: JX(lO),
        tcpHandshakeTime: JX(KO - pO),
        dnsLookupTime: JX(bK - eO),
        tlsNegotiationTime: JX(KO - AO),
        responseStatus: JX(zK),
        redirectTime: JX(aK - oO),
        requestTime: JX(QO - VO),
        responseTime: JX(LO - QO),
        fetchTime: JX(LO - CO),
        serviceWorkerTime: JX(dO > 0 ? CO - dO : 0),
        decodedBodySize: JX(XO),
        encodedBodySize: JX(vK),
        cacheHitStatus: function() {
          let OO = "fullLoad";
          0 === fO ? XO > 0 && (OO = "cache") : null != zK ? 304 === zK && (OO = "conditionalFetch") : vK > 0 && fO < vK && (OO = "conditionalFetch");
          return OO
        }(),
        renderBlockingStatus: JX(FO),
        protocol: MO,
        initiatorType: hO,
        visibilityState: document.visibilityState,
        ttfb: JX(QO - VO),
        transferSize: JX(fO)
      }
    }

    function RX(OO) {
      const {
        activationStart: KO,
        domComplete: pO,
        domContentLoadedEventEnd: XO,
        domContentLoadedEventStart: bK,
        domInteractive: eO,
        fetchStart: lO,
        loadEventEnd: vK,
        loadEventStart: CO,
        responseStart: hO,
        type: DO
      } = OO, MO = function() {
        var OO;
        return null != (null === (OO = performance.timing) || void 0 === OO ? void 0 : OO.domLoading) ? performance.timing.domLoading - performance.timeOrigin : null
      }();
      return DK(DK({}, HX(OO)), {}, {
        pageLoadTime: JX(pO - lO),
        documentParsingTime: JX(MO ? eO - MO : null),
        domProcessingTime: JX(pO - eO),
        domContentLoadHandlerTime: JX(XO - bK),
        onLoadTime: JX(vK - CO),
        ttfb: JX(Math.max(hO - (null !== KO && void 0 !== KO ? KO : 0), 0)),
        type: DO
      })
    }

    function SX(OO) {
      try {
        return new URL(OO).host || Pp
      } catch (KO) {
        return Pp
      }
    }

    function JX(OO) {
      return null == OO ? Pp : "number" === typeof OO ? Math.round(OO > 0 ? OO : 0).toString() : OO.toString()
    }
    const cb = {
      initiatorType: ["xmlhttprequest", "fetch"]
    };

    function BX(OO, KO, pO, XO, bK, eO, lO) {
      try {
        var vK = OO[eO](lO),
          CO = vK.value
      } catch (OO) {
        return void pO(OO)
      }
      vK.done ? KO(CO) : Promise.resolve(CO).then(XO, bK)
    }

    function ZX(OO) {
      return function() {
        var KO = this,
          pO = arguments;
        return new Promise((function(XO, bK) {
          var eO = OO.apply(KO, pO);

          function lO(OO) {
            BX(eO, XO, bK, lO, vK, "next", OO)
          }

          function vK(OO) {
            BX(eO, XO, bK, lO, vK, "throw", OO)
          }
          lO(void 0)
        }))
      }
    }
    const GX = new zX;
    var qb = class extends Kp {
      constructor() {
        super(...arguments), this.name = "@grafana/faro-web-sdk:instrumentation-performance", this.version = pp
      }
      initialize() {
        var OO = this;
        if (!("PerformanceObserver" in window)) return void this.logDebug("performance observer not supported. Disable performance instrumentation.");
        let KO = !1;
        const pO = () => {
          ! function(OO) {
            if ("complete" === document.readyState) OO();
            else {
              const KO = () => {
                "complete" === document.readyState && (OO(), document.removeEventListener("readystatechange", KO))
              };
              document.addEventListener("readystatechange", KO)
            }
          }(ZX((function*() {
            if (KO) return;
            const pO = OO.api.pushEvent,
              {
                faroNavigationId: XO
              } = yield function(OO) {
                let KO;
                const pO = new Promise((OO => {
                  KO = OO
                }));
                return new PerformanceObserver((pO => {
                  var XO;
                  const [bK] = pO.getEntries();
                  if (null == bK || nO(bK.name)) return;
                  const eO = bK.toJSON();
                  let lO = PX(null === eO || void 0 === eO ? void 0 : eO.serverTiming);
                  const vK = null !== (XO = OK("com.grafana.faro.lastNavigationId", tK)) && void 0 !== XO ? XO : Pp,
                    CO = DK(DK({}, RX(eO)), {}, {
                      faroNavigationId: QK(),
                      faroPreviousNavigationId: vK
                    });
                  KK("com.grafana.faro.lastNavigationId", CO.faroNavigationId, tK), OO("faro.performance.navigation", CO, void 0, {
                    spanContext: lO,
                    timestampOverwriteMs: mb(eO.startTime)
                  }), KO(CO)
                })).observe({
                  type: "navigation",
                  buffered: !0
                }), pO
              }(pO);
            KO || null == XO || function(OO, KO, pO, XO) {
              const bK = XO.trackResources;
              new PerformanceObserver((XO => {
                const eO = XO.getEntries(),
                  lO = {
                    wallNow: Date.now(),
                    monoNow: performance.now()
                  };
                for (const vK of eO) {
                  if (nO(vK.name)) continue;
                  null === pO || void 0 === pO || pO.notify({
                    type: "resource"
                  });
                  const XO = vK.toJSON();
                  let eO = PX(null === XO || void 0 === XO ? void 0 : XO.serverTiming);
                  (null == bK && sX(XO, cb) || bK) && KO("faro.performance.resource", DK(DK({}, HX(XO)), {}, {
                    faroNavigationId: OO,
                    faroResourceId: QK()
                  }), void 0, {
                    spanContext: eO,
                    timestampOverwriteMs: mb(XO.startTime, lO)
                  })
                }
              })).observe({
                type: "resource",
                buffered: !0
              })
            }(XO, pO, GX, OO.config)
          })))
        };
        this.cancelInitialization = () => {
          KO = !0, document.removeEventListener("prerenderingchange", pO)
        }, document.prerendering ? document.addEventListener("prerenderingchange", pO, {
          once: !0
        }) : pO()
      }
      destroy() {
        var OO;
        null === (OO = this.cancelInitialization) || void 0 === OO || OO.call(this), this.cancelInitialization = void 0
      }
    };
    const xb = "data-faro-user-action-name",
      nX = xb.replace(/-name$/, "-timeout"),
      WX = 1e3;

    function tb(OO) {
      return `data-${(OO.startsWith("data-")?OO.slice(5):OO).replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`
    }

    function kb(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 100,
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : BK;
      if (void 0 === OO) return KO;
      let XO = NaN;
      try {
        XO = "string" === typeof OO && "" === OO.trim() ? NaN : Number(OO)
      } catch (bK) {}
      return !Number.isFinite(XO) || XO <= 0 ? (pO(`initialActivityTimeout must be a finite number greater than zero; using ${KO} ms`), KO) : XO > 1e3 ? (pO(`initialActivityTimeout cannot exceed ${WX} ms; clamping to the maximum`), WX) : XO
    }

    function UX(OO, KO, pO) {
      return void 0 !== OO && window.clearTimeout(OO), window.setTimeout((() => {
        KO()
      }), pO)
    }

    function Ob(OO) {
      return OO.type === Qp
    }
    let Kb, pb;

    function Xb() {
      return Kb || (Kb = new zX), pb || (pb = new MutationObserver(((OO, KO) => {
        Kb.notify({
          type: "dom-mutation"
        })
      })), pb.observe(document, {
        attributes: !0,
        childList: !0,
        subtree: !0,
        characterData: !0
      })), Kb
    }
    const be = "fetch",
      eb = "xhr";
    let lb, ve, Cb, hb, Db = !1;

    function Mb() {
      if (lb) return lb;

      function OO(OO) {
        lb.notify({
          type: Lp,
          request: OO
        })
      }

      function KO(OO) {
        lb.notify({
          type: Qp,
          request: OO
        })
      }
      return lb = new zX, Db || (! function(OO) {
        let {
          onRequestEnd: KO,
          onRequestStart: pO
        } = OO;
        Cb || (Cb = window.fetch);
        window.fetch = function() {
          var OO, XO;
          const bK = null !== (OO = WO(arguments[0])) && void 0 !== OO ? OO : "",
            eO = nO(bK),
            lO = (null !== (XO = arguments[1]) && void 0 !== XO ? XO : {}).method,
            vK = QK();
          return eO || pO({
            url: bK,
            method: lO,
            requestId: vK,
            apiType: be
          }), Cb.apply(this, arguments).then((OO => (eO || KO({
            url: bK,
            method: lO,
            requestId: vK,
            apiType: be
          }), OO))).catch((OO => {
            throw eO || KO({
              url: bK,
              method: lO,
              requestId: vK,
              apiType: be
            }), OO
          }))
        }
      }({
        onRequestStart: OO,
        onRequestEnd: KO
      }), function(OO) {
        let {
          onRequestStart: KO,
          onRequestEnd: pO
        } = OO;
        ve || (ve = XMLHttpRequest.prototype.open);
        XMLHttpRequest.prototype.open = function() {
          const OO = arguments[1],
            XO = nO(OO),
            bK = arguments[0],
            eO = QK();
          this.addEventListener("loadstart", (function() {
            XO || KO({
              url: OO,
              method: bK,
              requestId: eO,
              apiType: eb
            })
          })), this.addEventListener("load", (function() {
            XO || pO({
              url: OO,
              method: bK,
              requestId: eO,
              apiType: eb
            })
          })), this.addEventListener("error", (function() {
            XO || pO({
              url: OO,
              method: bK,
              requestId: eO,
              apiType: eb
            })
          })), this.addEventListener("abort", (function() {
            XO || pO({
              url: OO,
              method: bK,
              requestId: eO,
              apiType: eb
            })
          })), ve.apply(this, arguments)
        }
      }({
        onRequestStart: OO,
        onRequestEnd: KO
      }), Db = !0), lb
    }
    let ae, ob = !1;
    let Fb = function(OO) {
      return OO[OO.Started = 0] = "Started", OO[OO.Halted = 1] = "Halted", OO[OO.Cancelled = 2] = "Cancelled", OO[OO.Ended = 3] = "Ended", OO
    }({});
    var Vb = class {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 100;
        this.userAction = OO, this.logDebug = KO, this.initialActivityTimeout = pO, this.http = Mb(), this.dom = Xb(), this.perf = (hb || (hb = new zX), ob || (ae = GX.subscribe((OO => {
          "resource" === OO.type && hb.notify({
            type: "resource-entry"
          })
        })), ob = !0), hb), this.isValid = !1, this.runningRequests = new Map
      }
      attach() {
        this.allMonitorsSub = (new zX).merge(this.http, this.dom, this.perf).takeWhile((() => [Fb.Started, Fb.Halted].includes(this.userAction.getState()))).filter((OO => !!(this.userAction.getState() !== Fb.Halted || Ob(OO) && this.runningRequests.has(OO.request.requestId)))).subscribe((OO => {
          (function(OO) {
            return OO.type === Lp
          })(OO) && this.runningRequests.set(OO.request.requestId, OO.request), Ob(OO) && this.runningRequests.delete(OO.request.requestId), Ob(OO) ? this.userAction.getState() === Fb.Halted && 0 === this.runningRequests.size && this.endAction() : (this.isValid || (this.isValid = !0, this.clearTimer(this.startupTid)), this.scheduleFollowUp())
        })), this.stateSub = this.userAction.filter((OO => [Fb.Ended, Fb.Cancelled].includes(OO))).first().subscribe((() => this.cleanup())), this.startupTid = UX(this.startupTid, (() => {
          this.logDebug("User action not sent; no DOM, resource, or HTTP activity:", this.userAction.name), this.cancelAction()
        }), this.initialActivityTimeout)
      }
      scheduleFollowUp() {
        this.clearTimer(this.followUpTid), this.followUpTid = window.setTimeout((() => {
          this.userAction.getState() === Fb.Started && this.runningRequests.size > 0 ? this.haltAction() : this.isValid ? this.endAction() : this.cancelAction()
        }), 100)
      }
      haltAction() {
        this.userAction.getState() === Fb.Started && (this.userAction.halt(), this.startHaltTimeout())
      }
      startHaltTimeout() {
        this.clearTimer(this.haltTid), this.haltTid = UX(this.haltTid, (() => {
          this.userAction.getState() === Fb.Halted && this.endAction()
        }), 1e4)
      }
      endAction() {
        this.userAction.end(), this.cleanup()
      }
      cancelAction() {
        this.userAction.cancel(), this.cleanup()
      }
      cleanup() {
        var OO, KO;
        this.clearTimer(this.startupTid), this.clearTimer(this.followUpTid), this.clearTimer(this.haltTid), null === (OO = this.allMonitorsSub) || void 0 === OO || OO.unsubscribe(), null === (KO = this.stateSub) || void 0 === KO || KO.unsubscribe(), this.allMonitorsSub = void 0, this.stateSub = void 0, this.runningRequests.clear()
      }
      clearTimer(OO) {
        void 0 !== OO && window.clearTimeout(OO)
      }
    };

    function Lb(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : BK;
      var pO;
      const {
        api: XO,
        config: bK,
        internalLogger: eO
      } = OO, lO = kb(null === (pO = bK.userActionsInstrumentation) || void 0 === pO ? void 0 : pO.initialActivityTimeout, 100, KO);
      return {
        processUserEvent: function(OO) {
          var KO, pO;
          const eO = null !== (KO = null === (pO = bK.userActionsInstrumentation) || void 0 === pO ? void 0 : pO.dataAttributeName) && void 0 !== KO ? KO : xb,
            lO = OO.target;
          if (!(lO instanceof Element)) return;
          const vK = function(OO, KO) {
              let pO = OO;
              for (; pO;) {
                if (pO.hasAttribute(KO)) return pO;
                pO = pO.parentElement
              }
              return null
            }(lO, tb(eO)),
            CO = function(OO, KO) {
              if (!OO) return;
              const pO = function(OO) {
                  return tb(OO).slice(5).replace(/-(.)/g, ((OO, KO) => KO.toUpperCase()))
                }(KO),
                XO = OO.dataset;
              for (const bK in XO)
                if (bK === pO) return XO[bK]
            }(vK, eO);
          if (!vK || !CO) return;
          const hO = function(OO, KO) {
            const pO = OO.getAttribute(function(OO) {
              const KO = tb(OO);
              return KO.endsWith("-name") ? `${KO.slice(0,-5)}-timeout` : `${KO}-timeout`
            }(KO));
            return null === pO ? void 0 : Number(pO)
          }(vK, eO);
          XO.startUserAction(CO, {}, {
            triggerName: OO.type,
            initialActivityTimeout: hO
          })
        },
        processUserActionStarted: function(OO, pO) {
          const XO = OO,
            bK = kb(pO, lO, KO);
          new Vb(XO, eO.debug, bK).attach()
        }
      }
    }
    const Qb = "user_action_start",
      ze = {
        Normal: "normal",
        Critical: "critical"
      };
    var Ab = class {
        constructor() {
          this.buffer = []
        }
        addItem(OO) {
          this.buffer.push(OO)
        }
        flushBuffer(OO) {
          if (EO(OO))
            for (const KO of this.buffer) OO(KO);
          this.buffer.length = 0
        }
        size() {
          return this.buffer.length
        }
      },
      fb = class extends zX {
        constructor(OO) {
          let {
            name: KO,
            parentId: pO,
            trigger: XO,
            transports: bK,
            attributes: eO,
            trackUserActionsExcludeItem: lO,
            importance: vK = ze.Normal,
            pushEvent: CO
          } = OO;
          super(), this.name = KO, this.attributes = eO, this.id = QK(), this.trigger = XO, this.parentId = null !== pO && void 0 !== pO ? pO : this.id, this.trackUserActionsExcludeItem = lO, this.importance = vK, this._pushEvent = CO, this._itemBuffer = new Ab, this._transports = bK, this._state = 0, this._start()
        }
        addItem(OO) {
          return 0 === this._state && (this._itemBuffer.addItem(OO), !0)
        }
        _start() {
          this._state = 0, 0 === this._state && (this.startTime = ap(), this._startTimeMono = oK())
        }
        halt() {
          0 === this._state && (this._state = 1, this.notify(this._state))
        }
        cancel() {
          0 === this._state && this._itemBuffer.flushBuffer((OO => {
            this._transports.execute(OO)
          })), this._state = 2, this.notify(this._state)
        }
        end() {
          if (2 === this._state) return;
          const OO = ap(),
            KO = oK() - this._startTimeMono;
          this._state = 3, this._itemBuffer.flushBuffer((OO => {
            if (function(OO, KO) {
                return (null === KO || void 0 === KO ? void 0 : KO(OO)) || "measurement" === OO.type && "web-vitals" === OO.payload.type
              }(OO, this.trackUserActionsExcludeItem)) return void this._transports.execute(OO);
            const KO = kp(kp({}, OO), {}, {
              payload: kp(kp({}, OO.payload), {}, {
                action: {
                  parentId: this.id,
                  name: this.name
                }
              })
            });
            this._transports.execute(KO)
          })), this._state = 3, this.notify(this._state), this._pushEvent("faro.user.action", kp({
            userActionName: this.name,
            userActionStartTime: this.startTime.toString(),
            userActionEndTime: OO.toString(),
            userActionDuration: KO.toString(),
            userActionTrigger: this.trigger,
            userActionImportance: this.importance
          }, mp(this.attributes)), void 0, {
            timestampOverwriteMs: this.startTime,
            customPayloadTransformer: OO => (OO.action = {
              id: this.id,
              name: this.name
            }, OO)
          })
        }
        getState() {
          return this._state
        }
      };
    const db = new zX;

    function Tb(OO, KO) {
      return !!OO && (0 === (null === OO || void 0 === OO ? void 0 : OO.getState()) && (OO.addItem(KO), !0))
    }
    var Nb = class extends Kp {
        constructor() {
          super(...arguments), this.name = "@grafana/faro-web-sdk:instrumentation-user-action", this.version = pp
        }
        initialize() {
          const {
            processUserEvent: OO,
            processUserActionStarted: KO
          } = Lb(VO, (OO => this.logWarn(OO)));
          this._processUserEvent = OO, this._processKeydown = KO => {
            [" ", "Enter"].includes(KO.key) && OO(KO)
          }, window.addEventListener("pointerdown", this._processUserEvent), window.addEventListener("keydown", this._processKeydown), this._userActionSub = db.subscribe((OO => {
            let {
              type: pO,
              userAction: XO,
              initialActivityTimeout: bK
            } = OO;
            "user_action_start" === pO && KO(XO, bK)
          }))
        }
        destroy() {
          var OO;
          this._processUserEvent && window.removeEventListener("pointerdown", this._processUserEvent), this._processKeydown && window.removeEventListener("keydown", this._processKeydown), null === (OO = this._userActionSub) || void 0 === OO || OO.unsubscribe()
        }
      },
      Ib = class extends Kp {
        constructor() {
          super(), this.name = "@grafana/faro-web-sdk:instrumentation-csp", this.version = pp, this.boundSecuritypolicyviolationHandler = this.securitypolicyviolationHandler.bind(this)
        }
        initialize() {
          document.addEventListener("securitypolicyviolation", this.boundSecuritypolicyviolationHandler)
        }
        destroy() {
          document.removeEventListener("securitypolicyviolation", this.boundSecuritypolicyviolationHandler)
        }
        securitypolicyviolationHandler(OO) {
          const KO = {
            blockedURI: OO.blockedURI,
            columnNumber: OO.columnNumber,
            disposition: OO.disposition,
            documentURI: OO.documentURI,
            effectiveDirective: OO.effectiveDirective,
            lineNumber: OO.lineNumber,
            originalPolicy: OO.originalPolicy,
            referrer: OO.referrer,
            sample: OO.sample,
            sourceFile: OO.sourceFile,
            statusCode: OO.statusCode,
            violatedDirective: OO.violatedDirective
          };
          this.api.pushEvent("securitypolicyviolation", mp(KO))
        }
      };
    var ye = class extends zX {
      constructor(OO, KO) {
        var pO, XO, bK, eO;
        super(), this._tracking = !1, this.eventsObservable = OO, this._options = {
          inactivityMs: null !== (pO = null === KO || void 0 === KO ? void 0 : KO.inactivityMs) && void 0 !== pO ? pO : 100,
          drainTimeoutMs: null !== (XO = null === KO || void 0 === KO ? void 0 : KO.drainTimeoutMs) && void 0 !== XO ? XO : 1e4,
          isOperationStart: null !== (bK = null === KO || void 0 === KO ? void 0 : KO.isOperationStart) && void 0 !== bK ? bK : () => {},
          isOperationEnd: null !== (eO = null === KO || void 0 === KO ? void 0 : KO.isOperationEnd) && void 0 !== eO ? eO : () => {}
        }, this._initialize()
      }
      _initialize() {
        this.eventsObservable.filter((() => this._tracking)).subscribe((OO => {
          var KO;
          this._lastEventTime = oK(), null === (KO = this._currentEvents) || void 0 === KO || KO.push(OO);
          const pO = this._options.isOperationStart(OO);
          var XO;
          pO && (null === (XO = this._activeOperations) || void 0 === XO || XO.set(pO, !0));
          const bK = this._options.isOperationEnd(OO);
          var eO;
          bK && (null === (eO = this._activeOperations) || void 0 === eO || eO.delete(bK));
          this._scheduleInactivityCheck()
        }))
      }
      startTracking() {
        this._tracking || (this._tracking = !0, this._startTime = oK(), this._lastEventTime = this._startTime, this.notify({
          message: "tracking-started"
        }), this._currentEvents = [], this._activeOperations = new Map, this._scheduleInactivityCheck())
      }
      stopTracking() {
        let OO;
        this._tracking = !1, this._clearTimer(this._inactivityTid), this._clearTimer(this._drainTid), OO = this.hasActiveOperations() ? oK() - this._startTime : this._lastEventTime ? this._lastEventTime - this._startTime : 0, this.notify({
          message: "tracking-ended",
          events: this._currentEvents,
          duration: OO
        })
      }
      _scheduleInactivityCheck() {
        this._inactivityTid = ge(this._inactivityTid, (() => {
          this.hasActiveOperations() ? this._startDrainTimeout() : this.stopTracking()
        }), this._options.inactivityMs)
      }
      _startDrainTimeout() {
        this._drainTid = ge(this._drainTid, (() => {
          this.stopTracking()
        }), this._options.drainTimeoutMs)
      }
      hasActiveOperations() {
        return !!this._activeOperations && this._activeOperations.size > 0
      }
      _clearTimer(OO) {
        OO && clearTimeout(OO)
      }
    };

    function ge(OO, KO, pO) {
      return OO && clearTimeout(OO), OO = setTimeout((() => {
        KO()
      }), pO)
    }
    let ub;
    const Eb = new Set,
      je = new Map;
    let Yb, wb, ie, re, Pb, me, sb, Hb, Rb = !1;
    var Sb = class extends Kp {
      constructor() {
        super(...arguments), this.name = "@grafana/faro-web-sdk:instrumentation-navigation", this.version = pp
      }
      initialize() {
        const OO = Mb(),
          KO = Xb(),
          pO = function() {
            function OO(OO, KO) {
              const pO = null !== KO && void 0 !== KO ? KO : location.href;
              pO !== wb && (Yb.notify({
                type: "url-change",
                from: wb,
                to: pO,
                trigger: OO
              }), wb = pO)
            }
            if (Yb || (Yb = new zX, wb = location.href), !Rb)
              if ("navigation" in window && "NavigateEvent" in window) {
                sb = KO => {
                  try {
                    const pO = null === KO || void 0 === KO ? void 0 : KO.destination;
                    (null === pO || void 0 === pO ? void 0 : pO.sameDocument) && "string" === typeof pO.url && OO("navigate", pO.url)
                  } catch (pO) {}
                }, window.navigation.addEventListener("navigate", sb);
                const KO = window.NavigateEvent;
                KO && KO.prototype && "function" === typeof KO.prototype.intercept && (Hb || (Hb = KO.prototype.intercept), KO.prototype.intercept = function(KO) {
                  try {
                    const KO = !!(null === this || void 0 === this ? void 0 : this.canIntercept),
                      pO = null === this || void 0 === this ? void 0 : this.destination;
                    KO && pO && !1 === pO.sameDocument && "string" === typeof pO.url && OO("navigate-intercept", pO.url)
                  } catch (pO) {}
                  return Hb.call(this, KO)
                }), Rb = !0
              } else ie || (ie = window.history.pushState), window.history.pushState = function() {
                for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
                const bK = ie.apply(window.history, pO);
                return OO("pushState"), bK
              }, re || (re = window.history.replaceState), window.history.replaceState = function() {
                for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
                const bK = re.apply(window.history, pO);
                return OO("replaceState"), bK
              }, Pb = () => OO("popstate"), me = () => OO("hashchange"), window.addEventListener("popstate", Pb), window.addEventListener("hashchange", me), Rb = !0;
            return Yb
          }(),
          XO = (bK = ["pointerdown", "keydown"], ub || (ub = new zX), bK.forEach((OO => {
            if (!Eb.has(OO)) {
              const KO = () => {
                ub.notify({
                  type: "interaction",
                  name: OO
                })
              };
              window.addEventListener(OO, KO), Eb.add(OO), je.set(OO, KO)
            }
          })), ub);
        var bK;
        const eO = new ye((new zX).merge(OO, KO, pO), {
          inactivityMs: 100,
          drainTimeoutMs: 1e4,
          isOperationStart: OO => function(OO) {
            return OO.type === Lp
          }(OO) ? OO.request.requestId : void 0,
          isOperationEnd: OO => function(OO) {
            return OO.type === Qp
          }(OO) ? OO.request.requestId : void 0
        });
        eO.filter((OO => "tracking-ended" === OO.message)).subscribe((OO => {
          var KO, pO;
          if ((null === (KO = OO.events) || void 0 === KO ? void 0 : KO.some((OO => "url-change" === OO.type))) && (null === (pO = OO.events) || void 0 === pO ? void 0 : pO.some((OO => "dom-mutation" === OO.type)))) {
            var XO;
            const KO = null === (XO = OO.events) || void 0 === XO ? void 0 : XO.find((OO => "url-change" === OO.type));
            VO.api.pushEvent("faro.navigation", {
              fromUrl: null === KO || void 0 === KO ? void 0 : KO.from,
              toUrl: null === KO || void 0 === KO ? void 0 : KO.to,
              sameDocument: String(!0),
              duration: OO.duration
            })
          }
        })), XO.subscribe((() => {
          eO.startTracking()
        }))
      }
    };

    function Jb() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      const KO = [new Nb, new rX, new ib, new Xp, new mX, new Sb];
      return !1 !== OO.enablePerformanceInstrumentation && KO.unshift(new qb), !1 !== OO.enableContentSecurityPolicyInstrumentation && KO.push(new Ib), !1 !== OO.captureConsole && KO.push(new wp), KO
    }
    var ce = pO(7159);
    let Bb, Zb;

    function Gb() {
      const OO = "undefined" !== typeof navigator ? navigator.userAgent : "";
      return Bb === OO && Zb || (Zb = new ce.UAParser(OO).getResult(), Bb = OO), Zb
    }
    const qe = () => {
        const {
          browser: OO,
          os: KO,
          ua: pO
        } = Gb(), {
          name: XO,
          version: bK
        } = OO, {
          name: eO,
          version: lO
        } = KO, vK = navigator.language, CO = pO.includes("Mobi"), hO = function() {
          if (!XO || !bK) return;
          if ("userAgentData" in navigator && navigator.userAgentData) return navigator.userAgentData.brands
        }();
        return {
          browser: {
            name: null !== XO && void 0 !== XO ? XO : Pp,
            version: null !== bK && void 0 !== bK ? bK : Pp,
            os: `${null!==eO&&void 0!==eO?eO:Pp} ${null!==lO&&void 0!==lO?lO:Pp}`,
            userAgent: null !== pO && void 0 !== pO ? pO : Pp,
            language: null !== vK && void 0 !== vK ? vK : Pp,
            mobile: CO,
            brands: null !== hO && void 0 !== hO ? hO : Pp,
            viewportWidth: `${window.innerWidth}`,
            viewportHeight: `${window.innerHeight}`
          }
        }
      },
      xe = () => {
        const {
          name: OO,
          version: KO
        } = Gb().os;
        if (!OO && !KO) return {};
        const pO = {};
        return OO && (pO.name = OO), KO && (pO.version = KO), {
          os: pO
        }
      };

    function nb(OO) {
      var KO, pO, XO;
      return {
        id: null !== (KO = null === (pO = VO.config) || void 0 === pO || null === (pO = pO.sessionTracking) || void 0 === pO || null === (XO = pO.generateSessionId) || void 0 === XO ? void 0 : XO.call(pO)) && void 0 !== KO ? KO : QK(),
        attributes: OO
      }
    }
    const Wb = () => ({
      sdk: {
        name: "faro-web",
        version: pp
      }
    });
    var te = class extends Op {
      isBatched() {
        return !1
      }
      getIgnoreUrls() {
        return []
      }
    };
    let ke = function(OO) {
      return OO.EXCEPTION = "exception", OO.LOG = "log", OO.MEASUREMENT = "measurement", OO.TRACE = "trace", OO.EVENT = "event", OO
    }({});
    const Ub = {
      exception: "exceptions",
      log: "logs",
      measurement: "measurements",
      trace: "traces",
      event: "events"
    };

    function Oe(OO, KO) {
      var pO, XO;
      if (void 0 === KO) return OO;
      if (void 0 === OO) return {
        resourceSpans: KO
      };
      const bK = null === (pO = OO.resourceSpans) || void 0 === pO ? void 0 : pO[0];
      if (void 0 === bK) return OO;
      const eO = (null === bK || void 0 === bK ? void 0 : bK.scopeSpans) || [],
        lO = (null === KO || void 0 === KO || null === (XO = KO[0]) || void 0 === XO ? void 0 : XO.scopeSpans) || [];
      return kp(kp({}, OO), {}, {
        resourceSpans: [kp(kp({}, bK), {}, {
          scopeSpans: [...eO, ...lO]
        })]
      })
    }

    function Ke(OO) {
      let KO = {
        meta: {}
      };
      return void 0 !== OO[0] && (KO.meta = OO[0].meta), OO.forEach((OO => {
        switch (OO.type) {
          case "log":
          case "event":
          case "exception":
          case "measurement": {
            const pO = Ub[OO.type],
              XO = KO[pO];
            KO = kp(kp({}, KO), {}, {
              [pO]: void 0 === XO ? [OO.payload] : [...XO, OO.payload]
            });
            break
          }
          case "trace":
            KO = kp(kp({}, KO), {}, {
              traces: Oe(KO.traces, OO.payload.resourceSpans)
            })
        }
      })), KO
    }
    var pe = class extends te {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        super(), this.options = OO, this.name = "@grafana/faro-web-sdk:transport-console", this.version = pp
      }
      send(OO) {
        var KO;
        return this.unpatchedConsole[null !== (KO = this.options.level) && void 0 !== KO ? KO : Ap.DEBUG]("New event", Ke([OO]))
      }
    };
    const Xe = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), ([0-9]{2}) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ([0-9]{4}) ([0-9]{2}):([0-9]{2}):([0-9]{2}) GMT$/,
      bl = /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), ([0-9]{2})-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-([0-9]{2}) ([0-9]{2}):([0-9]{2}):([0-9]{2}) GMT$/,
      ee = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (?:(?:([0-9]{2}))|(?: ([0-9]))) ([0-9]{2}):([0-9]{2}):([0-9]{2}) ([0-9]{4})$/,
      le = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      vl = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      Ce = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    function he(OO) {
      let {
        weekday: KO,
        day: pO,
        month: XO,
        year: bK,
        hour: eO,
        minute: lO,
        second: vK
      } = OO;
      if (bK < 1900 || pO < 1 || eO > 23 || lO > 59 || vK > 60) return;
      const CO = 60 === vK,
        hO = new Date(0);
      return hO.setUTCFullYear(bK, XO, pO), hO.setUTCHours(eO, lO, CO ? 59 : vK, 0), hO.getUTCDay() === KO && hO.getUTCDate() === pO && hO.getUTCMonth() === XO && hO.getUTCFullYear() === bK && hO.getUTCHours() === eO && hO.getUTCMinutes() === lO && hO.getUTCSeconds() === (CO ? 59 : vK) ? hO.getTime() + (CO ? 1e3 : 0) : void 0
    }
    var De = class {
      constructor(OO) {
        this.options = OO, this.admitted = 0, this.inProgress = 0, this.sequence = 0, this.nextSendAt = 0, this.attemptQueue = [], this.waiting = [], this.unloading = !1
      }
      reserve() {
        var OO = this;
        if (this.admitted >= this.options.bufferSize) return;
        this.admitted++;
        const KO = this.sequence++;
        let pO = !1;
        return {
          deliver: function() {
            var pO = ZX((function*(pO) {
              const XO = OO.options.getNow();
              let bK, eO = 0;
              for (;;) {
                var lO, vK, CO;
                const hO = OO.options.retry.maxAttempts - eO,
                  DO = yield OO.runAttempt((() => pO(hO, OO.unloading)), eO > 0);
                if (eO += DO.attemptsMade, "success" === DO.kind) return {
                  kind: "success",
                  attempts: eO,
                  elapsedTimeMs: OO.options.getNow() - XO
                };
                if (bK = DO.failure, "terminal" === DO.kind || OO.unloading) return {
                  kind: "terminal",
                  attempts: eO,
                  elapsedTimeMs: OO.options.getNow() - XO,
                  failure: bK
                };
                if (eO >= OO.options.retry.maxAttempts) return {
                  kind: "terminal",
                  attempts: eO,
                  elapsedTimeMs: OO.options.getNow() - XO,
                  failure: bK,
                  reason: "retries-exhausted"
                };
                if (null != DO.retryAfterMs && DO.retryAfterMs > OO.options.retry.maxBackoffMs) return {
                  kind: "terminal",
                  attempts: eO,
                  elapsedTimeMs: OO.options.getNow() - XO,
                  failure: bK,
                  reason: "retry-after-too-long"
                };
                const MO = Math.min(null !== (lO = DO.retryAfterMs) && void 0 !== lO ? lO : OO.options.retry.initialBackoffMs * Math.pow(OO.options.retry.backoffMultiplier, eO - 1), OO.options.retry.maxBackoffMs);
                if (null === (vK = (CO = OO.options).onRetry) || void 0 === vK || vK.call(CO, MO, eO + 1), yield OO.waitForTurn(KO, MO)) {
                  const KO = OO.options.retry.maxAttempts - eO,
                    bK = yield OO.runAttempt((() => pO(KO, !0)));
                  return eO += bK.attemptsMade, {
                    kind: "success" === bK.kind ? "success" : "terminal",
                    attempts: eO,
                    elapsedTimeMs: OO.options.getNow() - XO,
                    failure: "success" === bK.kind ? void 0 : bK.failure
                  }
                }
              }
            }));
            return function(OO) {
              return pO.apply(this, arguments)
            }
          }(),
          release: () => {
            pO || (pO = !0, this.admitted--)
          }
        }
      }
      flush() {
        this.unloading = !0, this.nextSendAt = 0;
        const OO = this.waiting.splice(0);
        null != this.redeliveryTimer && (clearTimeout(this.redeliveryTimer), this.redeliveryTimer = void 0), null != this.waitingTimer && (clearTimeout(this.waitingTimer), this.waitingTimer = void 0);
        for (const KO of OO) KO.resolve(!0);
        this.runNextAttempt()
      }
      resume() {
        this.unloading = !1
      }
      runAttempt(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return new Promise(((pO, XO) => {
          this.attemptQueue.push({
            run: () => {
              this.inProgress++;
              const KO = () => {
                this.inProgress--, this.runNextAttempt()
              };
              OO().then((OO => {
                KO(), pO(OO)
              }), (OO => {
                KO(), XO(OO)
              }))
            },
            isRedelivery: KO
          }), this.runNextAttempt()
        }))
      }
      runNextAttempt() {
        for (null != this.redeliveryTimer && (clearTimeout(this.redeliveryTimer), this.redeliveryTimer = void 0); this.inProgress < this.options.concurrency && this.attemptQueue.length > 0;) {
          const OO = this.options.getNow(),
            KO = this.attemptQueue.findIndex((KO => {
              let {
                isRedelivery: pO
              } = KO;
              return this.unloading || !pO || OO >= this.nextSendAt
            }));
          if (KO < 0) return void(this.redeliveryTimer = setTimeout((() => {
            this.redeliveryTimer = void 0, this.runNextAttempt()
          }), Math.max(0, this.nextSendAt - OO)));
          const [pO] = this.attemptQueue.splice(KO, 1);
          pO.isRedelivery && !this.unloading && (this.nextSendAt = OO + 1), pO.run()
        }
      }
      waitForTurn(OO, KO) {
        const pO = Math.min(KO * (1 + .2 * this.options.getRandom()), this.options.retry.maxBackoffMs);
        return new Promise((KO => {
          this.waiting.push({
            sequence: OO,
            readyAt: this.options.getNow() + pO,
            resolve: KO
          }), this.waiting.sort(((OO, KO) => OO.readyAt === KO.readyAt ? OO.sequence - KO.sequence : OO.readyAt - KO.readyAt)), null != this.waitingTimer && (clearTimeout(this.waitingTimer), this.waitingTimer = void 0), this.scheduleNext()
        }))
      }
      scheduleNext() {
        if (null != this.waitingTimer || 0 === this.waiting.length) return;
        const OO = this.waiting[0],
          KO = OO.readyAt;
        this.waitingTimer = setTimeout((() => {
          this.waitingTimer = void 0;
          const KO = this.waiting.indexOf(OO);
          KO >= 0 && this.waiting.splice(KO, 1), OO.resolve(!1), this.scheduleNext()
        }), Math.max(0, KO - this.options.getNow()))
      }
    };

    function Me(OO, KO) {
      if (null == OO) return {};
      var pO, XO, bK = function(OO, KO) {
        if (null == OO) return {};
        var pO = {};
        for (var XO in OO)
          if ({}.hasOwnProperty.call(OO, XO)) {
            if (KO.includes(XO)) continue;
            pO[XO] = OO[XO]
          } return pO
      }(OO, KO);
      if (Object.getOwnPropertySymbols) {
        var eO = Object.getOwnPropertySymbols(OO);
        for (XO = 0; XO < eO.length; XO++) pO = eO[XO], KO.includes(pO) || {}.propertyIsEnumerable.call(OO, pO) && (bK[pO] = OO[pO])
      }
      return bK
    }

    function al(OO) {
      const {
        size: KO,
        concurrency: pO
      } = OO, XO = [];
      let bK = 0;
      const eO = () => {
        if (bK < pO && XO.length) {
          const {
            producer: OO,
            resolve: KO,
            reject: pO
          } = XO.shift();
          bK++, OO().then((OO => {
            bK--, eO(), KO(OO)
          }), (OO => {
            bK--, eO(), pO(OO)
          }))
        }
      };
      return {
        add: OO => {
          if (XO.length + bK >= KO) throw new Error("Task buffer full");
          return new Promise(((KO, pO) => {
            XO.push({
              producer: OO,
              resolve: KO,
              reject: pO
            }), eO()
          }))
        }
      }
    }
    const oe = ["headers"],
      Fe = ["keepalive", "signal"],
      Ve = new Set([408, 425, 429, 500, 502, 503, 504]),
      Le = new Set([429, 503]);
    let Qe = 0,
      zl = 0;
    var Ae = class extends Error {};
    var fe = class extends te {
      constructor(OO) {
        var KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO, QO;
        super(), this.options = OO, this.name = "@grafana/faro-web-sdk:transport-fetch", this.version = pp, this.pendingCustomSends = 0, this.getNow = null !== (KO = OO.getNow) && void 0 !== KO ? KO : Date.now, this.requestTimeoutMs = null !== (pO = OO.requestTimeoutMs) && void 0 !== pO ? pO : 1e4, this.compressionEnabled = null !== (XO = OO.requestCompression) && void 0 !== XO && XO && "undefined" !== typeof CompressionStream, OO.requestCompression && !this.compressionEnabled && this.logWarn("requestCompression is enabled but CompressionStream is not available. Falling back to uncompressed."), this.requestTimeoutMs > 0 && "undefined" === typeof AbortController && this.logWarn("AbortController is unavailable. Requests will be sent without the configured timeout."), this.deliveryQueue = new De({
          bufferSize: null !== (bK = OO.bufferSize) && void 0 !== bK ? bK : 30,
          concurrency: null !== (eO = OO.concurrency) && void 0 !== eO ? eO : 5,
          retry: {
            maxAttempts: null !== (lO = null === (vK = OO.retry) || void 0 === vK ? void 0 : vK.maxAttempts) && void 0 !== lO ? lO : 3,
            initialBackoffMs: null !== (CO = null !== (hO = null === (DO = OO.retry) || void 0 === DO ? void 0 : DO.initialBackoffMs) && void 0 !== hO ? hO : OO.defaultRateLimitBackoffMs) && void 0 !== CO ? CO : 1e3,
            maxBackoffMs: null !== (MO = null === (aK = OO.retry) || void 0 === aK ? void 0 : aK.maxBackoffMs) && void 0 !== MO ? MO : 3e4,
            backoffMultiplier: null !== (oO = null === (FO = OO.retry) || void 0 === FO ? void 0 : FO.backoffMultiplier) && void 0 !== oO ? oO : 2
          },
          getNow: this.getNow,
          getRandom: null !== (VO = OO.getRandom) && void 0 !== VO ? VO : Math.random,
          onRetry: (OO, KO) => {
            this.logDebug(`Retrying failed request after ${OO}ms. Attempt ${KO}.`)
          }
        }), this.customPromiseBuffer = al({
          size: null !== (LO = OO.bufferSize) && void 0 !== LO ? LO : 30,
          concurrency: null !== (QO = OO.concurrency) && void 0 !== QO ? QO : 5
        }), this.defaultPromiseBuffer = {
          add: OO => {
            if (this.promiseBuffer !== this.defaultPromiseBuffer || this.promiseBuffer.add !== this.defaultBufferAdd || this.pendingCustomSends > 0) return this.customPromiseBuffer.add(OO);
            const KO = this.deliveryQueue.reserve();
            if (!KO) throw new Error("Task buffer full");
            return this.runBufferedTask(KO, OO)
          }
        }, this.defaultBufferAdd = this.defaultPromiseBuffer.add, this.promiseBuffer = this.defaultPromiseBuffer, "undefined" !== typeof window && (window.addEventListener("pagehide", (() => this.deliveryQueue.flush())), window.addEventListener("pageshow", (OO => {
          OO.persisted && this.deliveryQueue.resume()
        })))
      }
      send(OO) {
        var KO = this;
        return ZX((function*() {
          const pO = KO.promiseBuffer;
          if (pO !== KO.defaultPromiseBuffer || pO.add !== KO.defaultBufferAdd) {
            KO.pendingCustomSends++;
            try {
              yield pO.add((() => KO.deliver(OO)))
            } catch (XO) {
              KO.logError("Permanent delivery failure", {
                error: XO,
                attempts: 0,
                elapsedTimeMs: 0
              })
            } finally {
              KO.pendingCustomSends--
            }
          } else yield KO.deliver(OO)
        }))()
      }
      runBufferedTask(OO, KO) {
        return ZX((function*() {
          let pO;
          try {
            return yield OO.deliver(ZX((function*() {
              return pO = yield KO(), {
                kind: "success",
                attemptsMade: 1
              }
            }))), pO
          } finally {
            OO.release()
          }
        }))()
      }
      deliver(OO) {
        var KO = this;
        return ZX((function*() {
          const pO = KO.deliveryQueue.reserve();
          if (pO) try {
            const XO = yield KO.prepareRequest(OO), bK = yield pO.deliver(((OO, pO) => KO.performAttempt(XO, OO, pO)));
            "terminal" === bK.kind && KO.logError("retries-exhausted" === bK.reason ? "Delivery retries exhausted" : "Permanent delivery failure", DK(DK({}, bK.failure), {}, {
              reason: bK.reason,
              attempts: bK.attempts,
              elapsedTimeMs: bK.elapsedTimeMs
            }))
          } catch (XO) {
            KO.logError("Permanent delivery failure", {
              error: XO,
              attempts: 0,
              elapsedTimeMs: 0
            })
          } finally {
            pO.release()
          } else KO.logError("Permanent delivery failure", {
            error: "Reliable delivery queue is full",
            attempts: 0,
            elapsedTimeMs: 0
          })
        }))()
      }
      getIgnoreUrls() {
        var OO;
        return [this.options.url].concat(null !== (OO = this.config.ignoreUrls) && void 0 !== OO ? OO : [])
      }
      isBatched() {
        return !0
      }
      prepareRequest(OO) {
        var KO = this;
        return ZX((function*() {
          var pO, XO;
          const bK = Ke(OO),
            eO = null === (pO = bK.meta.session) || void 0 === pO ? void 0 : pO.id,
            lO = JSON.stringify(bK),
            vK = null !== (XO = KO.options.requestOptions) && void 0 !== XO ? XO : {},
            {
              headers: CO = {}
            } = vK,
            hO = Me(vK, oe),
            {
              keepalive: DO,
              signal: MO
            } = hO,
            aK = Me(hO, Fe),
            oO = {};
          for (const [OO, KO] of Object.entries(CO)) oO[OO] = "function" === typeof KO ? yield KO(): KO;
          let FO = lO,
            VO = function(OO) {
              return "undefined" === typeof TextEncoder ? OO.length : (new TextEncoder).encode(OO).byteLength
            }(lO);
          const LO = {};
          return KO.compressionEnabled && (FO = yield KO.compress(lO), VO = FO.size, LO["Content-Encoding"] = "gzip"), {
            bodySize: VO,
            sessionId: eO,
            requestInit: DK({
              method: "POST",
              headers: DK(DK(DK(DK(DK({
                "Content-Type": "application/json"
              }, LO), oO), KO.options.apiKey ? {
                "x-api-key": KO.options.apiKey
              } : {}), eO ? {
                "x-faro-session-id": eO
              } : {}), {}, {
                "Idempotency-Key": QK(20)
              }),
              body: FO
            }, aK)
          }
        }))()
      }
      performAttempt(OO, KO, pO) {
        var XO = this;
        return ZX((function*() {
          var bK;
          const eO = null === (bK = XO.options.requestOptions) || void 0 === bK ? void 0 : bK.signal;
          if (null === eO || void 0 === eO ? void 0 : eO.aborted) return {
            kind: "terminal",
            failure: {
              error: eO.reason
            },
            attemptsMade: 0
          };
          let lO = 0;
          try {
            var vK;
            const bK = yield XO.fetchWithKeepaliveFallback(OO.requestInit, OO.bodySize, !!pO || (null === (vK = XO.options.requestOptions) || void 0 === vK ? void 0 : vK.keepalive), KO, (() => lO++));
            if (XO.handleResponse(bK, OO.sessionId), bK.status >= 200 && bK.status < 300) return {
              kind: "success",
              attemptsMade: lO
            };
            const eO = {
              status: bK.status
            };
            return !Ve.has(bK.status) || pO ? {
              kind: "terminal",
              failure: eO,
              attemptsMade: lO
            } : {
              kind: "retry",
              failure: eO,
              attemptsMade: lO,
              retryAfterMs: Le.has(bK.status) ? XO.getRetryAfterDelayMs(bK) : void 0
            }
          } catch (CO) {
            const OO = {
              error: CO
            };
            return (null === eO || void 0 === eO ? void 0 : eO.aborted) || !XO.isFetchNetworkError(CO) || pO ? {
              kind: "terminal",
              failure: OO,
              attemptsMade: lO
            } : {
              kind: "retry",
              failure: OO,
              attemptsMade: lO
            }
          }
        }))()
      }
      fetchWithKeepaliveFallback(OO, KO, pO, XO, bK) {
        var eO = this;
        return ZX((function*() {
          const lO = eO.getNow(),
            vK = eO.reserveKeepalive(KO, pO);
          try {
            return yield eO.fetchWithTimeout(DK(DK({}, OO), {}, {
              keepalive: vK.keepalive
            }), eO.requestTimeoutMs, bK)
          } catch (hO) {
            var CO;
            if (vK.keepalive && XO > 1 && eO.isFetchNetworkError(hO) && !(hO instanceof Ae) && !(null === (CO = eO.options.requestOptions) || void 0 === CO || null === (CO = CO.signal) || void 0 === CO ? void 0 : CO.aborted)) {
              eO.logDebug("Retrying failed keepalive request with keepalive disabled.");
              const KO = eO.requestTimeoutMs - (eO.getNow() - lO);
              return eO.fetchWithTimeout(DK(DK({}, OO), {}, {
                keepalive: !1
              }), KO, bK)
            }
            throw hO
          } finally {
            vK.release()
          }
        }))()
      }
      fetchWithTimeout(OO, KO, pO) {
        var XO = this;
        return ZX((function*() {
          var bK;
          const eO = null === (bK = XO.options.requestOptions) || void 0 === bK ? void 0 : bK.signal;
          if (XO.requestTimeoutMs <= 0 || "undefined" === typeof AbortController) return pO(), fetch(XO.options.url, DK(DK({}, OO), {}, {
            signal: eO
          }));
          if (KO <= 0) throw new Ae("Request timed out");
          const lO = new AbortController,
            vK = () => lO.abort(null === eO || void 0 === eO ? void 0 : eO.reason);
          null === eO || void 0 === eO || eO.addEventListener("abort", vK, {
            once: !0
          });
          let CO = !1;
          const hO = setTimeout((() => {
            CO = !0, lO.abort()
          }), KO);
          try {
            return pO(), yield fetch(XO.options.url, DK(DK({}, OO), {}, {
              signal: lO.signal
            }))
          } catch (DO) {
            if (CO && !(null === eO || void 0 === eO ? void 0 : eO.aborted)) throw new Ae("Request timed out");
            throw DO
          } finally {
            clearTimeout(hO), null === eO || void 0 === eO || eO.removeEventListener("abort", vK)
          }
        }))()
      }
      getRetryAfterDelayMs(OO) {
        const KO = OO.headers.get("Retry-After");
        if (!KO) return;
        if (/^\d+$/.test(KO)) {
          const OO = 1e3 * Number(KO);
          return Number.isFinite(OO) ? OO : Number.POSITIVE_INFINITY
        }
        const pO = this.getNow(),
          XO = function(OO, KO) {
            const pO = Xe.exec(OO);
            if (pO) {
              const [, OO, KO, XO, bK, eO, lO, vK] = pO;
              return he({
                weekday: le.indexOf(OO),
                day: Number(KO),
                month: Ce.indexOf(XO),
                year: Number(bK),
                hour: Number(eO),
                minute: Number(lO),
                second: Number(vK)
              })
            }
            const XO = bl.exec(OO);
            if (XO) {
              const [, OO, pO, lO, vK, CO, hO, DO] = XO, MO = new Date(KO);
              if (Number.isNaN(MO.getTime())) return;
              const aK = MO.getUTCFullYear();
              let oO = 100 * Math.floor(aK / 100) + Number(vK);
              oO < aK && (oO += 100);
              const FO = Ce.indexOf(lO),
                VO = {
                  month: FO,
                  day: Number(pO),
                  hour: Number(CO),
                  minute: Number(hO),
                  second: Number(DO),
                  millisecond: 0
                },
                LO = {
                  month: MO.getUTCMonth(),
                  day: MO.getUTCDate(),
                  hour: MO.getUTCHours(),
                  minute: MO.getUTCMinutes(),
                  second: MO.getUTCSeconds(),
                  millisecond: MO.getUTCMilliseconds()
                };
              return (oO > aK + 50 || oO === aK + 50 && (eO = LO, ((bK = VO).month - eO.month || bK.day - eO.day || bK.hour - eO.hour || bK.minute - eO.minute || bK.second - eO.second || bK.millisecond - eO.millisecond) > 0)) && (oO -= 100), he({
                weekday: vl.indexOf(OO),
                day: Number(pO),
                month: FO,
                year: oO,
                hour: Number(CO),
                minute: Number(hO),
                second: Number(DO)
              })
            }
            var bK, eO;
            const lO = ee.exec(OO);
            if (!lO) return;
            const [, vK, CO, hO, DO, MO, aK, oO, FO] = lO;
            return he({
              weekday: le.indexOf(vK),
              day: Number(null !== hO && void 0 !== hO ? hO : DO),
              month: Ce.indexOf(CO),
              year: Number(FO),
              hour: Number(MO),
              minute: Number(aK),
              second: Number(oO)
            })
          }(KO, pO);
        return null == XO ? void 0 : Math.max(0, XO - pO)
      }
      reserveKeepalive(OO, KO) {
        if (!1 === KO || OO > 6e4 || Qe + OO > 6e4 || zl >= 9) return {
          keepalive: !1,
          release: BK
        };
        Qe += OO, zl++;
        let pO = !1;
        return {
          keepalive: !0,
          release: () => {
            pO || (pO = !0, Qe -= OO, zl--)
          }
        }
      }
      handleResponse(OO, KO) {
        202 === OO.status && "invalid" === OO.headers.get("X-Faro-Session-Status") && this.extendFaroSession(this.config, this.logDebug.bind(this), KO), OO.text().catch(BK)
      }
      isFetchNetworkError(OO) {
        return OO instanceof TypeError || OO instanceof Ae || OO instanceof DOMException && "AbortError" === OO.name
      }
      compress(OO) {
        return ZX((function*() {
          const KO = [],
            pO = new ReadableStream({
              start(KO) {
                KO.enqueue((new TextEncoder).encode(OO)), KO.close()
              }
            }).pipeThrough(new CompressionStream("gzip")).getReader();
          for (;;) {
            const {
              done: OO,
              value: XO
            } = yield pO.read();
            if (OO) return new Blob(KO);
            KO.push(XO)
          }
        }))()
      }
      extendFaroSession(OO, KO, pO) {
        var XO, bK;
        const eO = OO.sessionTracking;
        if (!(null === eO || void 0 === eO ? void 0 : eO.enabled)) return void KO("Session expired.");
        const {
          fetchUserSession: lO,
          storeUserSession: vK
        } = cp(eO), CO = null === (XO = this.metas.value.session) || void 0 === XO ? void 0 : XO.id, hO = null === (bK = lO()) || void 0 === bK ? void 0 : bK.sessionId;
        pO && pO === CO && pO === hO ? (jp({
          fetchUserSession: lO,
          storeUserSession: vK
        })({
          forceSessionExtend: !0
        }), KO("Session expired; created new session.")) : KO("Ignoring stale or cross-tab session-invalid response; request session no longer current.")
      }
    };
    const de = () => {
      const OO = window.k6;
      return {
        k6: DK({
          isK6Browser: !0
        }, (null === OO || void 0 === OO ? void 0 : OO.testRunId) && {
          testRunId: null === OO || void 0 === OO ? void 0 : OO.testRunId
        })
      }
    };
    let Te, Ne;

    function Ie() {
      let {
        generatePageId: OO,
        initialPageMeta: KO
      } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      return () => {
        const pO = location.href;
        return EO(OO) && Te !== pO && (Te = pO, Ne = OO(location)), {
          page: DK(DK({
            url: pO
          }, Ne ? {
            id: Ne
          } : {}), KO)
        }
      }
    }

    function yl() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : UK,
        KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
      const pO = GK;
      return KO > 0 && (pO.error = KO >= 1 ? function() {
        for (var KO = arguments.length, XO = new Array(KO), bK = 0; bK < KO; bK++) XO[bK] = arguments[bK];
        OO.error(`${pO.prefix}\n`, ...XO)
      } : BK, pO.warn = KO >= 2 ? function() {
        for (var KO = arguments.length, XO = new Array(KO), bK = 0; bK < KO; bK++) XO[bK] = arguments[bK];
        OO.warn(`${pO.prefix}\n`, ...XO)
      } : BK, pO.info = KO >= 3 ? function() {
        for (var KO = arguments.length, XO = new Array(KO), bK = 0; bK < KO; bK++) XO[bK] = arguments[bK];
        OO.info(`${pO.prefix}\n`, ...XO)
      } : BK, pO.debug = KO >= 4 ? function() {
        for (var KO = arguments.length, XO = new Array(KO), bK = 0; bK < KO; bK++) XO[bK] = arguments[bK];
        OO.debug(`${pO.prefix}\n`, ...XO)
      } : BK), pO
    }
    const gl = "faro",
      ue = {
        enabled: !0,
        sendTimeout: 250,
        itemLimit: 50
      },
      Ee = ["dedupe", "eventDomain", "globalObjectKey", "instrumentations", "internalLoggerLevel", "isolate", "logArgsSerializer", "metas", "paused", "preventGlobalExposure", "unpatchedConsole", "url", "experimental"];

    function jl(OO) {
      var KO, pO, bK, eO, lO, vK;
      const CO = [],
        DO = yl(OO.unpatchedConsole, OO.internalLoggerLevel);
      OO.transports ? ((OO.url || OO.apiKey) && DO.error('if "transports" is defined, "url" and "apiKey" should not be defined'), CO.push(...OO.transports)) : OO.url ? CO.push(new fe({
        url: OO.url,
        apiKey: OO.apiKey,
        requestCompression: OO.requestCompression
      })) : DO.error('either "url" or "transports" must be defined');
      const {
        dedupe: MO = !0,
        eventDomain: aK = XO,
        globalObjectKey: oO = gl,
        instrumentations: FO = Jb(),
        internalLoggerLevel: VO = qp,
        isolate: LO = !1,
        logArgsSerializer: QO = Yp,
        metas: zK = we(OO),
        paused: AO = !1,
        preventGlobalExposure: fO = !1,
        unpatchedConsole: dO = UK,
        url: TO,
        experimental: NO
      } = OO, IO = Me(OO, Ee), yK = null !== (KO = null === NO || void 0 === NO ? void 0 : NO.trackNavigation) && void 0 !== KO && KO, gK = {
        dataAttributeName: tb(null !== (pO = null === (bK = OO.userActionsInstrumentation) || void 0 === bK ? void 0 : bK.dataAttributeName) && void 0 !== pO ? pO : xb),
        excludeItem: null === (eO = OO.userActionsInstrumentation) || void 0 === eO ? void 0 : eO.excludeItem,
        initialActivityTimeout: kb(null === (lO = OO.userActionsInstrumentation) || void 0 === lO ? void 0 : lO.initialActivityTimeout, 100, (OO => DO.warn(OO)))
      };
      return DK(DK({}, IO), {}, {
        batching: DK(DK({}, ue), OO.batching),
        dedupe: MO,
        globalObjectKey: oO,
        instrumentations: Ye(FO, OO),
        internalLoggerLevel: VO,
        isolate: LO,
        logArgsSerializer: QO,
        metas: zK,
        parseStacktrace: Vp,
        paused: AO,
        preventGlobalExposure: fO,
        transports: CO,
        unpatchedConsole: dO,
        eventDomain: aK,
        ignoreUrls: [...null !== (vK = OO.ignoreUrls) && void 0 !== vK ? vK : [], ...TO ? [TO] : [], /\/collect(?:\/[\w]*)?$/],
        sessionTracking: DK(DK(DK({}, hO), OO.sessionTracking), il({
          trackGeolocation: OO.trackGeolocation,
          sessionTracking: OO.sessionTracking
        })),
        userActionsInstrumentation: gK,
        experimental: {
          trackNavigation: yK
        }
      })
    }

    function Ye(OO, KO) {
      let {
        experimental: pO
      } = KO;
      var XO;
      const bK = null !== (XO = null === pO || void 0 === pO ? void 0 : pO.trackNavigation) && void 0 !== XO && XO;
      return OO.filter((OO => !("@grafana/faro-web-sdk:instrumentation-navigation" === OO.name && !bK)))
    }

    function we(OO) {
      var KO, pO, XO;
      const {
        page: bK,
        generatePageId: eO
      } = null !== (KO = null === OO || void 0 === OO ? void 0 : OO.pageTracking) && void 0 !== KO ? KO : {}, lO = [qe, xe, Ie({
        generatePageId: eO,
        initialPageMeta: bK
      }), ...null !== (pO = OO.metas) && void 0 !== pO ? pO : [], Wb];
      return uO(null === (XO = window) || void 0 === XO ? void 0 : XO.k6) ? [...lO, de] : lO
    }

    function il(OO) {
      let {
        trackGeolocation: KO,
        sessionTracking: pO
      } = OO;
      var XO;
      const bK = {};
      return yK(KO) && (bK.geoLocationTrackingEnabled = KO), qK(bK) ? {} : {
        session: DK(DK({}, null !== (XO = null === pO || void 0 === pO ? void 0 : pO.session) && void 0 !== XO ? XO : {}), {}, {
          overrides: bK
        })
      }
    }
    const rl = new WeakSet;

    function Pe(OO) {
      return rl.add(OO), OO
    }

    function ml(OO, KO) {
      if (OO.capture) return Pe(OO.capture(KO));
      const pO = Pe(OO.value);
      return null === KO || void 0 === KO || KO(), pO
    }

    function se(OO) {
      const KO = `__faroBundleId_${OO}`,
        pO = null === DO || void 0 === DO ? void 0 : DO[KO];
      if ("string" === typeof pO && "" !== pO) return pO;
      const XO = "undefined" !== typeof window ? window[KO] : void 0;
      return "string" === typeof XO && "" !== XO ? XO : void 0
    }

    function He(OO) {
      var KO, pO;
      const XO = OO.config.app.name,
        bK = XO ? function(OO) {
          return null === DO || void 0 === DO ? void 0 : DO[`__faroGitHash_${OO}`]
        }(XO) : void 0,
        eO = {
          sdk: {
            version: pp,
            name: "faro"
          },
          app: kp({
            bundleId: XO && se(XO)
          }, void 0 !== bK ? {
            gitHash: bK
          } : {})
        },
        lO = null === (KO = OO.config.sessionTracking) || void 0 === KO ? void 0 : KO.session;
      lO && OO.api.setSession(lO), OO.config.app && (eO.app = kp(kp({}, OO.config.app), eO.app)), OO.config.user && (eO.user = OO.config.user), OO.config.view && (eO.view = OO.config.view), OO.metas.add(eO, ...null !== (pO = OO.config.metas) && void 0 !== pO ? pO : [])
    }
    var Re = class {
      constructor(OO, KO) {
        var pO, XO;
        this.signalBuffer = [], this.itemLimit = null !== (pO = null === KO || void 0 === KO ? void 0 : KO.itemLimit) && void 0 !== pO ? pO : 50, this.sendTimeout = null !== (XO = null === KO || void 0 === KO ? void 0 : KO.sendTimeout) && void 0 !== XO ? XO : 250, this.paused = (null === KO || void 0 === KO ? void 0 : KO.paused) || !1, this.sendFn = OO, this.paused || this.start(), "undefined" !== typeof document && document.addEventListener("visibilitychange", (() => {
          "hidden" === document.visibilityState && this.flush()
        }))
      }
      addItem(OO) {
        this.paused || (this.signalBuffer.push(OO), this.signalBuffer.length >= this.itemLimit && this.flush())
      }
      start() {
        this.paused = !1, this.sendTimeout > 0 && (this.flushInterval = setInterval((() => this.flush()), this.sendTimeout))
      }
      pause() {
        this.paused = !0, clearInterval(this.flushInterval)
      }
      groupItems(OO) {
        const KO = new Map;
        return OO.forEach((OO => {
          const pO = JSON.stringify(OO.meta);
          let XO = KO.get(pO);
          XO = void 0 === XO ? [OO] : [...XO, OO], KO.set(pO, XO)
        })), Array.from(KO.values())
      }
      flush() {
        if (this.paused || 0 === this.signalBuffer.length) return;
        const OO = this.signalBuffer;
        this.signalBuffer = [];
        try {
          this.groupItems(OO).forEach(this.sendFn)
        } catch (KO) {
          throw this.signalBuffer = [...OO, ...this.signalBuffer], this.trimBufferToLimit(), KO
        }
      }
      trimBufferToLimit() {
        this.signalBuffer.length > this.itemLimit && (this.signalBuffer = this.signalBuffer.slice(0, this.itemLimit))
      }
    };

    function Se(OO, KO, pO, XO) {
      var bK;
      KO.debug("Initializing transports");
      const eO = [];
      let lO = [];
      const vK = OO => {
        let KO = OO;
        for (const XO of lO) {
          const OO = KO.map(XO).filter(Boolean);
          if (0 === OO.length) return [];
          KO = Je(OO, pO)
        }
        return KO
      };
      let CO;
      (null === (bK = pO.batching) || void 0 === bK ? void 0 : bK.enabled) && (CO = new Re((OO => {
        const pO = vK(OO);
        if (0 !== pO.length)
          for (const XO of eO) KO.debug(`Transporting item using ${XO.name}\n`, pO), XO.isBatched() && XO.send(pO)
      }), {
        sendTimeout: pO.batching.sendTimeout,
        itemLimit: pO.batching.itemLimit,
        paused: pO.paused
      }));
      return {
        add: function() {
          KO.debug("Adding transports");
          for (var bK = arguments.length, lO = new Array(bK), vK = 0; vK < bK; vK++) lO[vK] = arguments[vK];
          lO.forEach((bK => {
            KO.debug(`Adding "${bK.name}" transport`), eO.some((OO => OO === bK)) ? KO.warn(`Transport ${bK.name} is already added`) : (bK.unpatchedConsole = OO, bK.internalLogger = KO, bK.config = pO, bK.metas = XO, eO.push(bK))
          }))
        },
        addBeforeSendHooks: function() {
          KO.debug("Adding beforeSendHooks\n", lO);
          for (var OO = arguments.length, pO = new Array(OO), XO = 0; XO < OO; XO++) pO[XO] = arguments[XO];
          pO.forEach((OO => {
            OO && lO.push(OO)
          }))
        },
        getBeforeSendHooks: () => [...lO],
        execute: OO => {
          var bK;
          if (!pO.paused && SK(XO).shouldCapture()) {
            if (MO = OO.meta, !rl.has(MO)) {
              var lO, hO, DO;
              const KO = null === (lO = XO.value.session) || void 0 === lO ? void 0 : lO.id,
                bK = ml(XO);
              if (pO.paused) return;
              const eO = kp({}, OO.meta);
              (null === (hO = eO.session) || void 0 === hO ? void 0 : hO.id) === KO && (null === (DO = bK.session) || void 0 === DO ? void 0 : DO.id) !== KO && (void 0 === bK.session ? delete eO.session : eO.session = bK.session), OO = kp(kp({}, OO), {}, {
                meta: Pe(eO)
              })
            }
            var MO;
            (null === (bK = pO.batching) || void 0 === bK ? void 0 : bK.enabled) && (null === CO || void 0 === CO || CO.addItem(OO)), (OO => {
              var XO;
              if ((null === (XO = pO.batching) || void 0 === XO ? void 0 : XO.enabled) && eO.every((OO => OO.isBatched()))) return;
              const [bK] = vK([OO]);
              if (void 0 !== bK)
                for (const vK of eO) {
                  var lO;
                  KO.debug(`Transporting item using ${vK.name}\n`, bK), vK.isBatched() ? (null === (lO = pO.batching) || void 0 === lO ? void 0 : lO.enabled) || vK.send([bK]) : vK.send(bK)
                }
            })(OO)
          }
        },
        isPaused: () => pO.paused,
        pause: () => {
          KO.debug("Pausing transports"), null === CO || void 0 === CO || CO.pause(), pO.paused = !0
        },
        remove: function() {
          KO.debug("Removing transports");
          for (var OO = arguments.length, pO = new Array(OO), XO = 0; XO < OO; XO++) pO[XO] = arguments[XO];
          pO.forEach((OO => {
            KO.debug(`Removing "${OO.name}" transport`);
            const pO = eO.indexOf(OO); - 1 !== pO ? eO.splice(pO, 1) : KO.warn(`Transport "${OO.name}" is not added`)
          }))
        },
        removeBeforeSendHooks: function() {
          for (var OO = arguments.length, pO = new Array(OO), XO = 0; XO < OO; XO++) pO[XO] = arguments[XO];
          KO.debug("Removing beforeSendHooks"), lO = lO.filter((OO => !pO.includes(OO)))
        },
        get transports() {
          return [...eO]
        },
        unpause: () => {
          KO.debug("Unpausing transports"), null === CO || void 0 === CO || CO.start(), pO.paused = !1
        }
      }
    }

    function Je(OO, KO) {
      if (KO.preserveOriginalError)
        for (const pO of OO) "exception" === pO.type && delete pO.payload.originalError;
      return OO
    }
    let cl = UK;

    function Be(OO) {
      var KO;
      return cl = null !== (KO = OO.unpatchedConsole) && void 0 !== KO ? KO : cl, cl
    }
    let Ze, Ge = GK;

    function ql(OO, KO) {
      return Ge = yl(OO, KO.internalLoggerLevel), Ge
    }

    function xl(OO) {
      let {
        internalLogger: KO,
        config: pO,
        metas: XO,
        transports: bK,
        tracesApi: eO,
        userActionsApi: lO
      } = OO;
      var vK;
      KO.debug("Initializing exceptions API");
      let CO = null;
      Ze = null !== (vK = pO.parseStacktrace) && void 0 !== vK ? vK : Ze;
      const hO = OO => {
          KO.debug("Changing stacktrace parser"), Ze = null !== OO && void 0 !== OO ? OO : Ze
        },
        {
          ignoreErrors: DO = [],
          preserveOriginalError: MO
        } = pO;
      return hO(pO.parseStacktrace), {
        changeStacktraceParser: hO,
        getStacktraceParser: () => Ze,
        pushError: function(OO) {
          let {
            skipDedupe: vK,
            stackFrames: hO,
            type: aK,
            context: oO,
            spanContext: FO,
            timestampOverwriteMs: VO,
            originalError: LO,
            fingerprint: QO,
            fatal: zK
          } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          if (! function(OO, KO) {
              const {
                message: pO,
                name: XO,
                stack: bK
              } = KO;
              return eO = OO, lO = pO + " " + XO + " " + bK, eO.some((OO => TO(OO) ? lO.includes(OO) : !!lO.match(OO)));
              var eO, lO
            }(DO, null !== LO && void 0 !== LO ? LO : OO)) try {
            var AO, fO;
            if (!SK(XO).shouldCapture()) return;
            const DO = mp(kp(kp({}, function(OO) {
                let KO = OO.cause;
                sO(KO) ? KO = OO.cause.toString() : null !== KO && (uO(OO.cause) || jK(OO.cause)) ? KO = PK(OO.cause) : null != KO && (KO = OO.cause.toString());
                return null == KO ? {} : {
                  cause: KO
                }
              }(null !== LO && void 0 !== LO ? LO : OO)), null !== oO && void 0 !== oO ? oO : {})),
              TO = kp(kp(kp(kp({
                type: aK || OO.name || "Error",
                value: OO.message,
                timestamp: VO ? VK(VO) : FK(),
                trace: FO ? {
                  trace_id: FO.traceId,
                  span_id: FO.spanId
                } : eO.getTraceContext()
              }, qK(DO) ? {} : {
                context: DO
              }), MO ? {
                originalError: LO
              } : {}), QO ? {
                fingerprint: QO
              } : {}), void 0 !== zK ? {
                fatal: zK
              } : {});
            hO = null !== (AO = hO) && void 0 !== AO ? AO : OO.stack ? null === Ze || void 0 === Ze ? void 0 : Ze(OO).frames : void 0, (null === hO || void 0 === hO ? void 0 : hO.length) && (TO.stacktrace = {
              frames: hO
            });
            const NO = {
              type: TO.type,
              value: TO.value,
              stacktrace: TO.stacktrace,
              context: TO.context,
              fingerprint: TO.fingerprint,
              fatal: null !== (fO = TO.fatal) && void 0 !== fO && fO
            };
            if (!vK && pO.dedupe && !dO(CO) && zp(NO, CO)) return void KO.debug("Skipping error push because it is the same as the last one\n", TO);
            const IO = CO,
              yK = ml(XO);
            if (CO !== IO && !vK && pO.dedupe && zp(NO, CO)) return;
            CO = NO;
            const gK = {
              meta: yK,
              payload: TO,
              type: "exception"
            };
            KO.debug("Pushing exception\n", gK), Tb(lO.getActiveUserAction(), gK) || bK.execute(gK)
          } catch (NO) {
            KO.error("Error pushing event", NO)
          }
        }
      }
    }

    function ne(OO, KO, pO, XO, bK) {
      KO.debug("Initializing API");
      let eO = null;
      const lO = function(OO) {
          let {
            transports: KO,
            internalLogger: pO,
            config: XO,
            pushEvent: bK
          } = OO;
          var eO;
          const lO = null === (eO = XO.userActionsInstrumentation) || void 0 === eO ? void 0 : eO.excludeItem;
          let vK;
          const CO = () => vK;
          return {
            startUserAction: (OO, XO, eO) => {
              if (void 0 === CO()) {
                const pO = new fb({
                  name: OO,
                  transports: KO,
                  attributes: XO,
                  trigger: (null === eO || void 0 === eO ? void 0 : eO.triggerName) || "faroApiCall",
                  importance: (null === eO || void 0 === eO ? void 0 : eO.importance) || ze.Normal,
                  trackUserActionsExcludeItem: lO,
                  pushEvent: bK
                });
                return pO.filter((OO => [3, 2].includes(OO))).first().subscribe((() => {
                  vK = void 0
                })), db.notify({
                  type: Qb,
                  userAction: pO,
                  initialActivityTimeout: null === eO || void 0 === eO ? void 0 : eO.initialActivityTimeout
                }), vK = pO, vK
              }
              pO.error("Attempted to create a new user action while one is already running. This is not possible.")
            },
            getActiveUserAction: CO
          }
        }({
          transports: bK,
          config: pO,
          internalLogger: KO,
          pushEvent: (OO, pO, XO, bK) => {
            eO ? eO(OO, pO, XO, bK) : KO.warn("pushEventImpl is not initialized. Event dropped:", {
              name: OO,
              attributes: pO,
              domain: XO,
              options: bK
            })
          }
        }),
        vK = function(OO, KO, pO, XO, bK) {
          let eO;
          return KO.debug("Initializing traces API"), {
            getOTEL: () => eO,
            getTraceContext: () => {
              const OO = null === eO || void 0 === eO ? void 0 : eO.trace.getSpanContext(eO.context.active());
              return OO ? {
                trace_id: OO.traceId,
                span_id: OO.spanId
              } : void 0
            },
            initOTEL: (OO, pO) => {
              KO.debug("Initializing OpenTelemetry"), eO = {
                trace: OO,
                context: pO
              }
            },
            isOTELInitialized: () => !!eO,
            pushTraces: OO => {
              try {
                if (!SK(XO).shouldCapture()) return;
                const pO = {
                  type: "trace",
                  payload: OO,
                  meta: ml(XO)
                };
                KO.debug("Pushing trace\n", pO), bK.execute(pO)
              } catch (pO) {
                KO.error("Error pushing trace\n", pO)
              }
            }
          }
        }(0, KO, 0, XO, bK),
        CO = {
          unpatchedConsole: OO,
          internalLogger: KO,
          userActionsApi: lO,
          config: pO,
          metas: XO,
          transports: bK,
          tracesApi: vK
        },
        hO = function(OO) {
          let {
            internalLogger: KO,
            config: pO,
            metas: XO,
            transports: bK,
            tracesApi: eO,
            userActionsApi: lO
          } = OO, vK = null;
          return {
            pushEvent: function(OO, CO, hO) {
              let {
                skipDedupe: DO,
                spanContext: MO,
                timestampOverwriteMs: aK,
                customPayloadTransformer: oO = OO => OO
              } = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
              try {
                if (!SK(XO).shouldCapture()) return;
                const FO = mp(CO),
                  VO = oO({
                    name: OO,
                    domain: null !== hO && void 0 !== hO ? hO : pO.eventDomain,
                    attributes: qK(FO) ? void 0 : FO,
                    timestamp: aK ? VK(aK) : FK(),
                    trace: MO ? {
                      trace_id: MO.traceId,
                      span_id: MO.spanId
                    } : eO.getTraceContext()
                  }),
                  LO = {
                    name: VO.name,
                    attributes: VO.attributes,
                    domain: VO.domain
                  };
                if (!DO && pO.dedupe && !dO(vK) && zp(LO, vK)) return void KO.debug("Skipping event push because it is the same as the last one\n", VO);
                const QO = vK,
                  zK = ml(XO);
                if (vK !== QO && !DO && pO.dedupe && zp(LO, vK)) return;
                vK = LO;
                const AO = {
                  meta: zK,
                  payload: VO,
                  type: "event"
                };
                KO.debug("Pushing event\n", AO), Tb(lO.getActiveUserAction(), AO) || bK.execute(AO)
              } catch (FO) {
                KO.error("Error pushing event", FO)
              }
            }
          }
        }(CO);
      return eO = hO.pushEvent, kp(kp(kp(kp(kp(kp(kp({}, vK), xl(CO)), function(OO) {
        let KO, pO, XO, bK, {
          internalLogger: eO,
          metas: lO
        } = OO;
        eO.debug("Initializing meta API");
        const vK = OO => {
            pO && lO.remove(pO), pO = {
              user: OO
            }, lO.add(pO)
          },
          CO = (OO, pO) => {
            var XO;
            const bK = null === pO || void 0 === pO ? void 0 : pO.overrides,
              eO = bK ? {
                overrides: kp(kp({}, null === KO || void 0 === KO || null === (XO = KO.session) || void 0 === XO ? void 0 : XO.overrides), bK)
              } : {};
            KO && lO.remove(KO), KO = {
              session: kp(kp({}, qK(OO) ? void 0 : OO), eO)
            }, lO.add(KO)
          },
          hO = (OO, KO) => {
            SK(lO).notifySessionUpdate({
              type: "replace",
              session: OO,
              overrides: null === KO || void 0 === KO ? void 0 : KO.overrides
            }), CO(OO, KO)
          },
          DO = () => lO.value.session,
          MO = () => lO.value.page;
        return {
          setUser: vK,
          resetUser: vK,
          setSession: hO,
          resetSession: hO,
          getSession: DO,
          setView: (OO, KO) => {
            var pO;
            if ((null === KO || void 0 === KO ? void 0 : KO.overrides) && (SK(lO).notifySessionUpdate({
                type: "overrides",
                overrides: KO.overrides
              }), CO(DO(), {
                overrides: KO.overrides
              })), (null === XO || void 0 === XO || null === (pO = XO.view) || void 0 === pO ? void 0 : pO.name) === (null === OO || void 0 === OO ? void 0 : OO.name)) return;
            const bK = XO;
            XO = {
              view: OO
            }, lO.add(XO), bK && lO.remove(bK)
          },
          getView: () => lO.value.view,
          setPage: OO => {
            var KO;
            const pO = TO(OO) ? kp(kp({}, null !== (KO = null === bK || void 0 === bK ? void 0 : bK.page) && void 0 !== KO ? KO : MO()), {}, {
              id: OO
            }) : OO;
            bK && lO.remove(bK), bK = {
              page: pO
            }, lO.add(bK)
          },
          getPage: MO
        }
      }(CO)), function(OO) {
        let {
          internalLogger: KO,
          config: pO,
          metas: XO,
          transports: bK,
          tracesApi: eO,
          userActionsApi: lO
        } = OO;
        var vK;
        KO.debug("Initializing logs API");
        let CO = null;
        const hO = null !== (vK = pO.logArgsSerializer) && void 0 !== vK ? vK : Yp;
        return {
          pushLog: function(OO) {
            let {
              context: vK,
              level: DO,
              skipDedupe: MO,
              spanContext: aK,
              timestampOverwriteMs: oO
            } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            try {
              if (!SK(XO).shouldCapture()) return;
              const FO = mp(vK),
                VO = {
                  message: hO(OO),
                  level: null !== DO && void 0 !== DO ? DO : "log",
                  context: qK(FO) ? void 0 : FO,
                  timestamp: oO ? VK(oO) : FK(),
                  trace: aK ? {
                    trace_id: aK.traceId,
                    span_id: aK.spanId
                  } : eO.getTraceContext()
                },
                LO = {
                  message: VO.message,
                  level: VO.level,
                  context: VO.context
                };
              if (!MO && pO.dedupe && !dO(CO) && zp(LO, CO)) return void KO.debug("Skipping log push because it is the same as the last one\n", VO);
              const QO = CO,
                zK = ml(XO);
              if (CO !== QO && !MO && pO.dedupe && zp(LO, CO)) return;
              CO = LO;
              const AO = {
                type: "log",
                payload: VO,
                meta: zK
              };
              KO.debug("Pushing log\n", AO), Tb(lO.getActiveUserAction(), AO) || bK.execute(AO)
            } catch (FO) {
              KO.error("Error pushing log\n", FO)
            }
          }
        }
      }(CO)), function(OO) {
        let {
          internalLogger: KO,
          config: pO,
          metas: XO,
          transports: bK,
          tracesApi: eO,
          userActionsApi: lO
        } = OO;
        KO.debug("Initializing measurements API");
        let vK = null;
        return {
          pushMeasurement: function(OO) {
            let {
              skipDedupe: CO,
              context: hO,
              spanContext: DO,
              timestampOverwriteMs: MO
            } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            try {
              if (!SK(XO).shouldCapture()) return;
              const aK = mp(hO),
                oO = kp(kp({}, OO), {}, {
                  trace: DO ? {
                    trace_id: DO.traceId,
                    span_id: DO.spanId
                  } : eO.getTraceContext(),
                  timestamp: MO ? VK(MO) : FK(),
                  context: qK(aK) ? void 0 : aK
                }),
                FO = {
                  type: oO.type,
                  values: oO.values,
                  context: oO.context
                };
              if (!CO && pO.dedupe && !dO(vK) && zp(FO, vK)) return void KO.debug("Skipping measurement push because it is the same as the last one\n", oO);
              const VO = vK,
                LO = ml(XO);
              if (vK !== VO && !CO && pO.dedupe && zp(FO, vK)) return;
              vK = FO;
              const QO = {
                type: "measurement",
                payload: oO,
                meta: LO
              };
              KO.debug("Pushing measurement\n", QO), Tb(lO.getActiveUserAction(), QO) || bK.execute(QO)
            } catch (aK) {
              KO.error("Error pushing measurement\n", aK)
            }
          }
        }
      }(CO)), hO), lO)
    }

    function We(OO) {
      const KO = Be(OO),
        pO = ql(KO, OO);
      if (FO() && !OO.isolate) return void pO.error('Faro is already registered. Either add instrumentations, transports etc. to the global faro instance or use the "isolate" property');
      pO.debug("Initializing");
      const XO = function(OO, KO) {
          let pO, XO = [],
            bK = [],
            eO = [],
            lO = 0,
            vK = 0;
          const CO = () => XO.reduce(((OO, KO) => Object.assign(OO, EO(KO) ? KO() : KO)), {}),
            hO = () => {
              if (bK.length) {
                const OO = CO();
                bK.forEach((KO => KO(OO)))
              }
            };
          return {
            add: function() {
              for (var OO = arguments.length, pO = new Array(OO), bK = 0; bK < OO; bK++) pO[bK] = arguments[bK];
              KO.debug("Adding metas\n", pO), XO.push(...pO), hO()
            },
            remove: function() {
              for (var OO = arguments.length, pO = new Array(OO), bK = 0; bK < OO; bK++) pO[bK] = arguments[bK];
              KO.debug("Removing metas\n", pO), XO = XO.filter((OO => !pO.includes(OO))), hO()
            },
            addListener: OO => {
              KO.debug("Adding metas listener\n", OO), bK.push(OO)
            },
            removeListener: OO => {
              KO.debug("Removing metas listener\n", OO), bK = bK.filter((KO => KO !== OO))
            },
            capture: OO => {
              var KO;
              const XO = void 0 !== pO,
                bK = null !== (KO = pO) && void 0 !== KO ? KO : eO;
              XO || (pO = bK, lO = 0, vK = bK.length);
              try {
                for (; lO < vK;) {
                  const OO = bK[lO++];
                  null === OO || void 0 === OO || OO()
                }
                const KO = Pe(CO());
                return null === OO || void 0 === OO || OO(), KO
              } finally {
                XO || (pO = void 0)
              }
            },
            addCaptureListener: OO => {
              eO.push(OO)
            },
            removeCaptureListener: OO => {
              eO = eO.filter((KO => KO !== OO))
            },
            get value() {
              return CO()
            }
          }
        }(0, pO),
        bK = Se(KO, pO, OO, XO),
        eO = ne(KO, pO, OO, XO, bK),
        lO = function(OO, KO, pO, XO, bK, eO) {
          KO.debug("Initializing instrumentations");
          const lO = [];
          return {
            add: function() {
              KO.debug("Adding instrumentations");
              for (var vK = arguments.length, CO = new Array(vK), hO = 0; hO < vK; hO++) CO[hO] = arguments[hO];
              CO.forEach((vK => {
                KO.debug(`Adding "${vK.name}" instrumentation`), lO.some((OO => OO.name === vK.name)) ? KO.warn(`Instrumentation ${vK.name} is already added`) : (vK.unpatchedConsole = OO, vK.internalLogger = KO, vK.config = pO, vK.metas = XO, vK.transports = bK, vK.api = eO, lO.push(vK), vK.initialize())
              }))
            },
            get instrumentations() {
              return [...lO]
            },
            remove: function() {
              KO.debug("Removing instrumentations");
              for (var OO = arguments.length, pO = new Array(OO), XO = 0; XO < OO; XO++) pO[XO] = arguments[XO];
              pO.forEach((OO => {
                var pO, XO;
                KO.debug(`Removing "${OO.name}" instrumentation`);
                const bK = lO.reduce(((KO, pO, XO) => null === KO && pO.name === OO.name ? XO : null), null);
                null !== bK ? (null === (pO = (XO = lO[bK]).destroy) || void 0 === pO || pO.call(XO), lO.splice(bK, 1)) : KO.warn(`Instrumentation "${OO.name}" is not added`)
              }))
            }
          }
        }(KO, pO, OO, XO, bK, eO),
        vK = LO(KO, pO, OO, XO, bK, eO, lO);
      return He(vK),
        function(OO) {
          OO.transports.add(...OO.config.transports), OO.transports.addBeforeSendHooks(OO.config.beforeSend)
        }(vK),
        function(OO) {
          OO.instrumentations.add(...OO.config.instrumentations)
        }(vK), vK
    }

    function tl(OO) {
      const KO = jl(OO);
      if (KO) return We(KO)
    }
  },
  7159: function(OO, KO, pO) {
    var XO;
    ! function(bK, eO) {
      var lO = "function",
        vK = "undefined",
        CO = "object",
        hO = "string",
        DO = "major",
        MO = "model",
        aK = "name",
        oO = "type",
        FO = "vendor",
        VO = "version",
        LO = "architecture",
        QO = "console",
        zK = "mobile",
        AO = "tablet",
        fO = "smarttv",
        dO = "wearable",
        TO = "embedded",
        NO = "Amazon",
        IO = "Apple",
        yK = "ASUS",
        gK = "BlackBerry",
        uO = "Browser",
        EO = "Chrome",
        jK = "Firefox",
        YO = "Google",
        wO = "Honor",
        iK = "Huawei",
        rK = "LG",
        PO = "Microsoft",
        mK = "Motorola",
        sO = "Nvidia",
        HO = "OnePlus",
        RO = "Opera",
        SO = "OPPO",
        JO = "Samsung",
        cK = "Sharp",
        BO = "Sony",
        ZO = "Xiaomi",
        GO = "Zebra",
        qK = "Facebook",
        xK = "Chromium OS",
        nO = "Mac OS",
        WO = " Browser",
        tK = function(OO) {
          for (var KO = {}, pO = 0; pO < OO.length; pO++) KO[OO[pO].toUpperCase()] = OO[pO];
          return KO
        },
        kK = function(OO, KO) {
          return typeof OO === hO && -1 !== UO(KO).indexOf(UO(OO))
        },
        UO = function(OO) {
          return OO.toLowerCase()
        },
        OK = function(OO, KO) {
          if (typeof OO === hO) return OO = OO.replace(/^\s\s*/, ""), typeof KO === vK ? OO : OO.substring(0, 500)
        },
        KK = function(OO, KO) {
          for (var pO, XO, bK, vK, hO, DO, MO = 0; MO < KO.length && !hO;) {
            var aK = KO[MO],
              oO = KO[MO + 1];
            for (pO = XO = 0; pO < aK.length && !hO && aK[pO];)
              if (hO = aK[pO++].exec(OO))
                for (bK = 0; bK < oO.length; bK++) DO = hO[++XO], typeof(vK = oO[bK]) === CO && vK.length > 0 ? 2 === vK.length ? typeof vK[1] == lO ? this[vK[0]] = vK[1].call(this, DO) : this[vK[0]] = vK[1] : 3 === vK.length ? typeof vK[1] !== lO || vK[1].exec && vK[1].test ? this[vK[0]] = DO ? DO.replace(vK[1], vK[2]) : eO : this[vK[0]] = DO ? vK[1].call(this, DO, vK[2]) : eO : 4 === vK.length && (this[vK[0]] = DO ? vK[3].call(this, DO.replace(vK[1], vK[2])) : eO) : this[vK] = DO || eO;
            MO += 2
          }
        },
        pK = function(OO, KO) {
          for (var pO in KO)
            if (typeof KO[pO] === CO && KO[pO].length > 0) {
              for (var XO = 0; XO < KO[pO].length; XO++)
                if (kK(KO[pO][XO], OO)) return "?" === pO ? eO : pO
            } else if (kK(KO[pO], OO)) return "?" === pO ? eO : pO;
          return KO.hasOwnProperty("*") ? KO["*"] : OO
        },
        XK = {
          ME: "4.90",
          "NT 3.11": "NT3.51",
          "NT 4.0": "NT4.0",
          2e3: "NT 5.0",
          XP: ["NT 5.1", "NT 5.2"],
          Vista: "NT 6.0",
          7: "NT 6.1",
          8: "NT 6.2",
          8.1: "NT 6.3",
          10: ["NT 6.4", "NT 10.0"],
          RT: "ARM"
        },
        bp = {
          browser: [
            [/\b(?:crmo|crios)\/([\w\.]+)/i],
            [VO, [aK, "Chrome"]],
            [/edg(?:e|ios|a)?\/([\w\.]+)/i],
            [VO, [aK, "Edge"]],
            [/(opera mini)\/([-\w\.]+)/i, /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i, /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i],
            [aK, VO],
            [/opios[\/ ]+([\w\.]+)/i],
            [VO, [aK, RO + " Mini"]],
            [/\bop(?:rg)?x\/([\w\.]+)/i],
            [VO, [aK, RO + " GX"]],
            [/\bopr\/([\w\.]+)/i],
            [VO, [aK, RO]],
            [/\bb[ai]*d(?:uhd|[ub]*[aekoprswx]{5,6})[\/ ]?([\w\.]+)/i],
            [VO, [aK, "Baidu"]],
            [/\b(?:mxbrowser|mxios|myie2)\/?([-\w\.]*)\b/i],
            [VO, [aK, "Maxthon"]],
            [/(kindle)\/([\w\.]+)/i, /(lunascape|maxthon|netfront|jasmine|blazer|sleipnir)[\/ ]?([\w\.]*)/i, /(avant|iemobile|slim(?:browser|boat|jet))[\/ ]?([\d\.]*)/i, /(?:ms|\()(ie) ([\w\.]+)/i, /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|duckduckgo|klar|helio|(?=comodo_)?dragon)\/([-\w\.]+)/i, /(heytap|ovi|115)browser\/([\d\.]+)/i, /(weibo)__([\d\.]+)/i],
            [aK, VO],
            [/quark(?:pc)?\/([-\w\.]+)/i],
            [VO, [aK, "Quark"]],
            [/\bddg\/([\w\.]+)/i],
            [VO, [aK, "DuckDuckGo"]],
            [/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],
            [VO, [aK, "UC" + uO]],
            [/microm.+\bqbcore\/([\w\.]+)/i, /\bqbcore\/([\w\.]+).+microm/i, /micromessenger\/([\w\.]+)/i],
            [VO, [aK, "WeChat"]],
            [/konqueror\/([\w\.]+)/i],
            [VO, [aK, "Konqueror"]],
            [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],
            [VO, [aK, "IE"]],
            [/ya(?:search)?browser\/([\w\.]+)/i],
            [VO, [aK, "Yandex"]],
            [/slbrowser\/([\w\.]+)/i],
            [VO, [aK, "Smart Lenovo " + uO]],
            [/(avast|avg)\/([\w\.]+)/i],
            [
              [aK, /(.+)/, "$1 Secure " + uO], VO
            ],
            [/\bfocus\/([\w\.]+)/i],
            [VO, [aK, jK + " Focus"]],
            [/\bopt\/([\w\.]+)/i],
            [VO, [aK, RO + " Touch"]],
            [/coc_coc\w+\/([\w\.]+)/i],
            [VO, [aK, "Coc Coc"]],
            [/dolfin\/([\w\.]+)/i],
            [VO, [aK, "Dolphin"]],
            [/coast\/([\w\.]+)/i],
            [VO, [aK, RO + " Coast"]],
            [/miuibrowser\/([\w\.]+)/i],
            [VO, [aK, "MIUI" + WO]],
            [/fxios\/([\w\.-]+)/i],
            [VO, [aK, jK]],
            [/\bqihoobrowser\/?([\w\.]*)/i],
            [VO, [aK, "360"]],
            [/\b(qq)\/([\w\.]+)/i],
            [
              [aK, /(.+)/, "$1Browser"], VO
            ],
            [/(oculus|sailfish|huawei|vivo|pico)browser\/([\w\.]+)/i],
            [
              [aK, /(.+)/, "$1" + WO], VO
            ],
            [/samsungbrowser\/([\w\.]+)/i],
            [VO, [aK, JO + " Internet"]],
            [/metasr[\/ ]?([\d\.]+)/i],
            [VO, [aK, "Sogou Explorer"]],
            [/(sogou)mo\w+\/([\d\.]+)/i],
            [
              [aK, "Sogou Mobile"], VO
            ],
            [/(electron)\/([\w\.]+) safari/i, /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i, /m?(qqbrowser|2345(?=browser|chrome|explorer))\w*[\/ ]?v?([\w\.]+)/i],
            [aK, VO],
            [/(lbbrowser|rekonq)/i, /\[(linkedin)app\]/i],
            [aK],
            [/ome\/([\w\.]+) \w* ?(iron) saf/i, /ome\/([\w\.]+).+qihu (360)[es]e/i],
            [VO, aK],
            [/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i],
            [
              [aK, qK], VO
            ],
            [/(Klarna)\/([\w\.]+)/i, /(kakao(?:talk|story))[\/ ]([\w\.]+)/i, /(naver)\(.*?(\d+\.[\w\.]+).*\)/i, /(daum)apps[\/ ]([\w\.]+)/i, /safari (line)\/([\w\.]+)/i, /\b(line)\/([\w\.]+)\/iab/i, /(alipay)client\/([\w\.]+)/i, /(twitter)(?:and| f.+e\/([\w\.]+))/i, /(chromium|instagram|snapchat)[\/ ]([-\w\.]+)/i],
            [aK, VO],
            [/\bgsa\/([\w\.]+) .*safari\//i],
            [VO, [aK, "GSA"]],
            [/musical_ly(?:.+app_?version\/|_)([\w\.]+)/i],
            [VO, [aK, "TikTok"]],
            [/headlesschrome(?:\/([\w\.]+)| )/i],
            [VO, [aK, EO + " Headless"]],
            [/ wv\).+(chrome)\/([\w\.]+)/i],
            [
              [aK, EO + " WebView"], VO
            ],
            [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],
            [VO, [aK, "Android " + uO]],
            [/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i],
            [aK, VO],
            [/version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i],
            [VO, [aK, "Mobile Safari"]],
            [/version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i],
            [VO, aK],
            [/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],
            [aK, [VO, pK, {
              "1.0": "/8",
              1.2: "/1",
              1.3: "/3",
              "2.0": "/412",
              "2.0.2": "/416",
              "2.0.3": "/417",
              "2.0.4": "/419",
              "?": "/"
            }]],
            [/(webkit|khtml)\/([\w\.]+)/i],
            [aK, VO],
            [/(navigator|netscape\d?)\/([-\w\.]+)/i],
            [
              [aK, "Netscape"], VO
            ],
            [/(wolvic|librewolf)\/([\w\.]+)/i],
            [aK, VO],
            [/mobile vr; rv:([\w\.]+)\).+firefox/i],
            [VO, [aK, jK + " Reality"]],
            [/ekiohf.+(flow)\/([\w\.]+)/i, /(swiftfox)/i, /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror)[\/ ]?([\w\.\+]+)/i, /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i, /(firefox)\/([\w\.]+)/i, /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i, /(amaya|dillo|doris|icab|ladybird|lynx|mosaic|netsurf|obigo|polaris|w3m|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i, /\b(links) \(([\w\.]+)/i],
            [aK, [VO, /_/g, "."]],
            [/(cobalt)\/([\w\.]+)/i],
            [aK, [VO, /master.|lts./, ""]]
          ],
          cpu: [
            [/\b((amd|x|x86[-_]?|wow|win)64)\b/i],
            [
              [LO, "amd64"]
            ],
            [/(ia32(?=;))/i, /\b((i[346]|x)86)(pc)?\b/i],
            [
              [LO, "ia32"]
            ],
            [/\b(aarch64|arm(v?[89]e?l?|_?64))\b/i],
            [
              [LO, "arm64"]
            ],
            [/\b(arm(v[67])?ht?n?[fl]p?)\b/i],
            [
              [LO, "armhf"]
            ],
            [/( (ce|mobile); ppc;|\/[\w\.]+arm\b)/i],
            [
              [LO, "arm"]
            ],
            [/((ppc|powerpc)(64)?)( mac|;|\))/i],
            [
              [LO, /ower/, "", UO]
            ],
            [/ sun4\w[;\)]/i],
            [
              [LO, "sparc"]
            ],
            [/\b(avr32|ia64(?=;)|68k(?=\))|\barm(?=v([1-7]|[5-7]1)l?|;|eabi)|(irix|mips|sparc)(64)?\b|pa-risc)/i],
            [
              [LO, UO]
            ]
          ],
          device: [
            [/\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i],
            [MO, [FO, JO],
              [oO, AO]
            ],
            [/\b((?:s[cgp]h|gt|sm)-(?![lr])\w+|sc[g-]?[\d]+a?|galaxy nexus)/i, /samsung[- ]((?!sm-[lr])[-\w]+)/i, /sec-(sgh\w+)/i],
            [MO, [FO, JO],
              [oO, zK]
            ],
            [/(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i],
            [MO, [FO, IO],
              [oO, zK]
            ],
            [/\((ipad);[-\w\),; ]+apple/i, /applecoremedia\/[\w\.]+ \((ipad)/i, /\b(ipad)\d\d?,\d\d?[;\]].+ios/i],
            [MO, [FO, IO],
              [oO, AO]
            ],
            [/(macintosh);/i],
            [MO, [FO, IO]],
            [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],
            [MO, [FO, cK],
              [oO, zK]
            ],
            [/\b((?:brt|eln|hey2?|gdi|jdn)-a?[lnw]09|(?:ag[rm]3?|jdn2|kob2)-a?[lw]0[09]hn)(?: bui|\)|;)/i],
            [MO, [FO, wO],
              [oO, AO]
            ],
            [/honor([-\w ]+)[;\)]/i],
            [MO, [FO, wO],
              [oO, zK]
            ],
            [/\b((?:ag[rs][2356]?k?|bah[234]?|bg[2o]|bt[kv]|cmr|cpn|db[ry]2?|jdn2|got|kob2?k?|mon|pce|scm|sht?|[tw]gr|vrd)-[ad]?[lw][0125][09]b?|605hw|bg2-u03|(?:gem|fdr|m2|ple|t1)-[7a]0[1-4][lu]|t1-a2[13][lw]|mediapad[\w\. ]*(?= bui|\)))\b(?!.+d\/s)/i],
            [MO, [FO, iK],
              [oO, AO]
            ],
            [/(?:huawei)([-\w ]+)[;\)]/i, /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i],
            [MO, [FO, iK],
              [oO, zK]
            ],
            [/oid[^\)]+; (2[\dbc]{4}(182|283|rp\w{2})[cgl]|m2105k81a?c)(?: bui|\))/i, /\b((?:red)?mi[-_ ]?pad[\w- ]*)(?: bui|\))/i],
            [
              [MO, /_/g, " "],
              [FO, ZO],
              [oO, AO]
            ],
            [/\b(poco[\w ]+|m2\d{3}j\d\d[a-z]{2})(?: bui|\))/i, /\b; (\w+) build\/hm\1/i, /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i, /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i, /oid[^\)]+; (m?[12][0-389][01]\w{3,6}[c-y])( bui|; wv|\))/i, /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite|pro)?)(?: bui|\))/i, / ([\w ]+) miui\/v?\d/i],
            [
              [MO, /_/g, " "],
              [FO, ZO],
              [oO, zK]
            ],
            [/; (\w+) bui.+ oppo/i, /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i],
            [MO, [FO, SO],
              [oO, zK]
            ],
            [/\b(opd2(\d{3}a?))(?: bui|\))/i],
            [MO, [FO, pK, {
                OnePlus: ["304", "403", "203"],
                "*": SO
              }],
              [oO, AO]
            ],
            [/vivo (\w+)(?: bui|\))/i, /\b(v[12]\d{3}\w?[at])(?: bui|;)/i],
            [MO, [FO, "Vivo"],
              [oO, zK]
            ],
            [/\b(rmx[1-3]\d{3})(?: bui|;|\))/i],
            [MO, [FO, "Realme"],
              [oO, zK]
            ],
            [/\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i, /\bmot(?:orola)?[- ](\w*)/i, /((?:moto(?! 360)[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i],
            [MO, [FO, mK],
              [oO, zK]
            ],
            [/\b(mz60\d|xoom[2 ]{0,2}) build\//i],
            [MO, [FO, mK],
              [oO, AO]
            ],
            [/((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i],
            [MO, [FO, rK],
              [oO, AO]
            ],
            [/(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i, /\blg[-e;\/ ]+((?!browser|netcast|android tv|watch)\w+)/i, /\blg-?([\d\w]+) bui/i],
            [MO, [FO, rK],
              [oO, zK]
            ],
            [/(ideatab[-\w ]+|602lv|d-42a|a101lv|a2109a|a3500-hv|s[56]000|pb-6505[my]|tb-?x?\d{3,4}(?:f[cu]|xu|[av])|yt\d?-[jx]?\d+[lfmx])( bui|;|\)|\/)/i, /lenovo ?(b[68]0[08]0-?[hf]?|tab(?:[\w- ]+?)|tb[\w-]{6,7})( bui|;|\)|\/)/i],
            [MO, [FO, "Lenovo"],
              [oO, AO]
            ],
            [/(nokia) (t[12][01])/i],
            [FO, MO, [oO, AO]],
            [/(?:maemo|nokia).*(n900|lumia \d+|rm-\d+)/i, /nokia[-_ ]?(([-\w\. ]*))/i],
            [
              [MO, /_/g, " "],
              [oO, zK],
              [FO, "Nokia"]
            ],
            [/(pixel (c|tablet))\b/i],
            [MO, [FO, YO],
              [oO, AO]
            ],
            [/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],
            [MO, [FO, YO],
              [oO, zK]
            ],
            [/droid.+; (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i],
            [MO, [FO, BO],
              [oO, zK]
            ],
            [/sony tablet [ps]/i, /\b(?:sony)?sgp\w+(?: bui|\))/i],
            [
              [MO, "Xperia Tablet"],
              [FO, BO],
              [oO, AO]
            ],
            [/ (kb2005|in20[12]5|be20[12][59])\b/i, /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i],
            [MO, [FO, HO],
              [oO, zK]
            ],
            [/(alexa)webm/i, /(kf[a-z]{2}wi|aeo(?!bc)\w\w)( bui|\))/i, /(kf[a-z]+)( bui|\)).+silk\//i],
            [MO, [FO, NO],
              [oO, AO]
            ],
            [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],
            [
              [MO, /(.+)/g, "Fire Phone $1"],
              [FO, NO],
              [oO, zK]
            ],
            [/(playbook);[-\w\),; ]+(rim)/i],
            [MO, FO, [oO, AO]],
            [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i],
            [MO, [FO, gK],
              [oO, zK]
            ],
            [/(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i],
            [MO, [FO, yK],
              [oO, AO]
            ],
            [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],
            [MO, [FO, yK],
              [oO, zK]
            ],
            [/(nexus 9)/i],
            [MO, [FO, "HTC"],
              [oO, AO]
            ],
            [/(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i, /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i, /(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i],
            [FO, [MO, /_/g, " "],
              [oO, zK]
            ],
            [/droid [\w\.]+; ((?:8[14]9[16]|9(?:0(?:48|60|8[01])|1(?:3[27]|66)|2(?:6[69]|9[56])|466))[gqswx])\w*(\)| bui)/i],
            [MO, [FO, "TCL"],
              [oO, AO]
            ],
            [/(itel) ((\w+))/i],
            [
              [FO, UO], MO, [oO, pK, {
                tablet: ["p10001l", "w7001"],
                "*": "mobile"
              }]
            ],
            [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],
            [MO, [FO, "Acer"],
              [oO, AO]
            ],
            [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i],
            [MO, [FO, "Meizu"],
              [oO, zK]
            ],
            [/; ((?:power )?armor(?:[\w ]{0,8}))(?: bui|\))/i],
            [MO, [FO, "Ulefone"],
              [oO, zK]
            ],
            [/; (energy ?\w+)(?: bui|\))/i, /; energizer ([\w ]+)(?: bui|\))/i],
            [MO, [FO, "Energizer"],
              [oO, zK]
            ],
            [/; cat (b35);/i, /; (b15q?|s22 flip|s48c|s62 pro)(?: bui|\))/i],
            [MO, [FO, "Cat"],
              [oO, zK]
            ],
            [/((?:new )?andromax[\w- ]+)(?: bui|\))/i],
            [MO, [FO, "Smartfren"],
              [oO, zK]
            ],
            [/droid.+; (a(?:015|06[35]|142p?))/i],
            [MO, [FO, "Nothing"],
              [oO, zK]
            ],
            [/; (x67 5g|tikeasy \w+|ac[1789]\d\w+)( b|\))/i, /archos ?(5|gamepad2?|([\w ]*[t1789]|hello) ?\d+[\w ]*)( b|\))/i],
            [MO, [FO, "Archos"],
              [oO, AO]
            ],
            [/archos ([\w ]+)( b|\))/i, /; (ac[3-6]\d\w{2,8})( b|\))/i],
            [MO, [FO, "Archos"],
              [oO, zK]
            ],
            [/(imo) (tab \w+)/i, /(infinix) (x1101b?)/i],
            [FO, MO, [oO, AO]],
            [/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus(?! zenw)|dell|jolla|meizu|motorola|polytron|infinix|tecno|micromax|advan)[-_ ]?([-\w]*)/i, /; (hmd|imo) ([\w ]+?)(?: bui|\))/i, /(hp) ([\w ]+\w)/i, /(microsoft); (lumia[\w ]+)/i, /(lenovo)[-_ ]?([-\w ]+?)(?: bui|\)|\/)/i, /(oppo) ?([\w ]+) bui/i],
            [FO, MO, [oO, zK]],
            [/(kobo)\s(ereader|touch)/i, /(hp).+(touchpad(?!.+tablet)|tablet)/i, /(kindle)\/([\w\.]+)/i, /(nook)[\w ]+build\/(\w+)/i, /(dell) (strea[kpr\d ]*[\dko])/i, /(le[- ]+pan)[- ]+(\w{1,9}) bui/i, /(trinity)[- ]*(t\d{3}) bui/i, /(gigaset)[- ]+(q\w{1,9}) bui/i, /(vodafone) ([\w ]+)(?:\)| bui)/i],
            [FO, MO, [oO, AO]],
            [/(surface duo)/i],
            [MO, [FO, PO],
              [oO, AO]
            ],
            [/droid [\d\.]+; (fp\du?)(?: b|\))/i],
            [MO, [FO, "Fairphone"],
              [oO, zK]
            ],
            [/(u304aa)/i],
            [MO, [FO, "AT&T"],
              [oO, zK]
            ],
            [/\bsie-(\w*)/i],
            [MO, [FO, "Siemens"],
              [oO, zK]
            ],
            [/\b(rct\w+) b/i],
            [MO, [FO, "RCA"],
              [oO, AO]
            ],
            [/\b(venue[\d ]{2,7}) b/i],
            [MO, [FO, "Dell"],
              [oO, AO]
            ],
            [/\b(q(?:mv|ta)\w+) b/i],
            [MO, [FO, "Verizon"],
              [oO, AO]
            ],
            [/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],
            [MO, [FO, "Barnes & Noble"],
              [oO, AO]
            ],
            [/\b(tm\d{3}\w+) b/i],
            [MO, [FO, "NuVision"],
              [oO, AO]
            ],
            [/\b(k88) b/i],
            [MO, [FO, "ZTE"],
              [oO, AO]
            ],
            [/\b(nx\d{3}j) b/i],
            [MO, [FO, "ZTE"],
              [oO, zK]
            ],
            [/\b(gen\d{3}) b.+49h/i],
            [MO, [FO, "Swiss"],
              [oO, zK]
            ],
            [/\b(zur\d{3}) b/i],
            [MO, [FO, "Swiss"],
              [oO, AO]
            ],
            [/\b((zeki)?tb.*\b) b/i],
            [MO, [FO, "Zeki"],
              [oO, AO]
            ],
            [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i],
            [
              [FO, "Dragon Touch"], MO, [oO, AO]
            ],
            [/\b(ns-?\w{0,9}) b/i],
            [MO, [FO, "Insignia"],
              [oO, AO]
            ],
            [/\b((nxa|next)-?\w{0,9}) b/i],
            [MO, [FO, "NextBook"],
              [oO, AO]
            ],
            [/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],
            [
              [FO, "Voice"], MO, [oO, zK]
            ],
            [/\b(lvtel\-)?(v1[12]) b/i],
            [
              [FO, "LvTel"], MO, [oO, zK]
            ],
            [/\b(ph-1) /i],
            [MO, [FO, "Essential"],
              [oO, zK]
            ],
            [/\b(v(100md|700na|7011|917g).*\b) b/i],
            [MO, [FO, "Envizen"],
              [oO, AO]
            ],
            [/\b(trio[-\w\. ]+) b/i],
            [MO, [FO, "MachSpeed"],
              [oO, AO]
            ],
            [/\btu_(1491) b/i],
            [MO, [FO, "Rotor"],
              [oO, AO]
            ],
            [/((?:tegranote|shield t(?!.+d tv))[\w- ]*?)(?: b|\))/i],
            [MO, [FO, sO],
              [oO, AO]
            ],
            [/(sprint) (\w+)/i],
            [FO, MO, [oO, zK]],
            [/(kin\.[onetw]{3})/i],
            [
              [MO, /\./g, " "],
              [FO, PO],
              [oO, zK]
            ],
            [/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
            [MO, [FO, GO],
              [oO, AO]
            ],
            [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],
            [MO, [FO, GO],
              [oO, zK]
            ],
            [/smart-tv.+(samsung)/i],
            [FO, [oO, fO]],
            [/hbbtv.+maple;(\d+)/i],
            [
              [MO, /^/, "SmartTV"],
              [FO, JO],
              [oO, fO]
            ],
            [/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i],
            [
              [FO, rK],
              [oO, fO]
            ],
            [/(apple) ?tv/i],
            [FO, [MO, IO + " TV"],
              [oO, fO]
            ],
            [/crkey/i],
            [
              [MO, EO + "cast"],
              [FO, YO],
              [oO, fO]
            ],
            [/droid.+aft(\w+)( bui|\))/i],
            [MO, [FO, NO],
              [oO, fO]
            ],
            [/(shield \w+ tv)/i],
            [MO, [FO, sO],
              [oO, fO]
            ],
            [/\(dtv[\);].+(aquos)/i, /(aquos-tv[\w ]+)\)/i],
            [MO, [FO, cK],
              [oO, fO]
            ],
            [/(bravia[\w ]+)( bui|\))/i],
            [MO, [FO, BO],
              [oO, fO]
            ],
            [/(mi(tv|box)-?\w+) bui/i],
            [MO, [FO, ZO],
              [oO, fO]
            ],
            [/Hbbtv.*(technisat) (.*);/i],
            [FO, MO, [oO, fO]],
            [/\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i, /hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i],
            [
              [FO, OK],
              [MO, OK],
              [oO, fO]
            ],
            [/droid.+; ([\w- ]+) (?:android tv|smart[- ]?tv)/i],
            [MO, [oO, fO]],
            [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],
            [
              [oO, fO]
            ],
            [/(ouya)/i, /(nintendo) ([wids3utch]+)/i],
            [FO, MO, [oO, QO]],
            [/droid.+; (shield)( bui|\))/i],
            [MO, [FO, sO],
              [oO, QO]
            ],
            [/(playstation \w+)/i],
            [MO, [FO, BO],
              [oO, QO]
            ],
            [/\b(xbox(?: one)?(?!; xbox))[\); ]/i],
            [MO, [FO, PO],
              [oO, QO]
            ],
            [/\b(sm-[lr]\d\d[0156][fnuw]?s?|gear live)\b/i],
            [MO, [FO, JO],
              [oO, dO]
            ],
            [/((pebble))app/i, /(asus|google|lg|oppo) ((pixel |zen)?watch[\w ]*)( bui|\))/i],
            [FO, MO, [oO, dO]],
            [/(ow(?:19|20)?we?[1-3]{1,3})/i],
            [MO, [FO, SO],
              [oO, dO]
            ],
            [/(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i],
            [MO, [FO, IO],
              [oO, dO]
            ],
            [/(opwwe\d{3})/i],
            [MO, [FO, HO],
              [oO, dO]
            ],
            [/(moto 360)/i],
            [MO, [FO, mK],
              [oO, dO]
            ],
            [/(smartwatch 3)/i],
            [MO, [FO, BO],
              [oO, dO]
            ],
            [/(g watch r)/i],
            [MO, [FO, rK],
              [oO, dO]
            ],
            [/droid.+; (wt63?0{2,3})\)/i],
            [MO, [FO, GO],
              [oO, dO]
            ],
            [/droid.+; (glass) \d/i],
            [MO, [FO, YO],
              [oO, dO]
            ],
            [/(pico) (4|neo3(?: link|pro)?)/i],
            [FO, MO, [oO, dO]],
            [/; (quest( \d| pro)?)/i],
            [MO, [FO, qK],
              [oO, dO]
            ],
            [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],
            [FO, [oO, TO]],
            [/(aeobc)\b/i],
            [MO, [FO, NO],
              [oO, TO]
            ],
            [/(homepod).+mac os/i],
            [MO, [FO, IO],
              [oO, TO]
            ],
            [/windows iot/i],
            [
              [oO, TO]
            ],
            [/droid .+?; ([^;]+?)(?: bui|; wv\)|\) applew).+? mobile safari/i],
            [MO, [oO, zK]],
            [/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i],
            [MO, [oO, AO]],
            [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],
            [
              [oO, AO]
            ],
            [/(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i],
            [
              [oO, zK]
            ],
            [/droid .+?; ([\w\. -]+)( bui|\))/i],
            [MO, [FO, "Generic"]]
          ],
          engine: [
            [/windows.+ edge\/([\w\.]+)/i],
            [VO, [aK, "EdgeHTML"]],
            [/(arkweb)\/([\w\.]+)/i],
            [aK, VO],
            [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
            [VO, [aK, "Blink"]],
            [/(presto)\/([\w\.]+)/i, /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna|servo)\/([\w\.]+)/i, /ekioh(flow)\/([\w\.]+)/i, /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i, /(icab)[\/ ]([23]\.[\d\.]+)/i, /\b(libweb)/i],
            [aK, VO],
            [/ladybird\//i],
            [
              [aK, "LibWeb"]
            ],
            [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
            [VO, aK]
          ],
          os: [
            [/microsoft (windows) (vista|xp)/i],
            [aK, VO],
            [/(windows (?:phone(?: os)?|mobile|iot))[\/ ]?([\d\.\w ]*)/i],
            [aK, [VO, pK, XK]],
            [/windows nt 6\.2; (arm)/i, /windows[\/ ]([ntce\d\. ]+\w)(?!.+xbox)/i, /(?:win(?=3|9|n)|win 9x )([nt\d\.]+)/i],
            [
              [VO, pK, XK],
              [aK, "Windows"]
            ],
            [/[adehimnop]{4,7}\b(?:.*os ([\w]+) like mac|; opera)/i, /(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i, /cfnetwork\/.+darwin/i],
            [
              [VO, /_/g, "."],
              [aK, "iOS"]
            ],
            [/(mac os x) ?([\w\. ]*)/i, /(macintosh|mac_powerpc\b)(?!.+haiku)/i],
            [
              [aK, nO],
              [VO, /_/g, "."]
            ],
            [/droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i],
            [VO, aK],
            [/(ubuntu) ([\w\.]+) like android/i],
            [
              [aK, /(.+)/, "$1 Touch"], VO
            ],
            [/(android|bada|blackberry|kaios|maemo|meego|openharmony|qnx|rim tablet os|sailfish|series40|symbian|tizen|webos)\w*[-\/; ]?([\d\.]*)/i],
            [aK, VO],
            [/\(bb(10);/i],
            [VO, [aK, gK]],
            [/(?:symbian ?os|symbos|s60(?=;)|series ?60)[-\/ ]?([\w\.]*)/i],
            [VO, [aK, "Symbian"]],
            [/mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i],
            [VO, [aK, jK + " OS"]],
            [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
            [VO, [aK, "webOS"]],
            [/watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i],
            [VO, [aK, "watchOS"]],
            [/crkey\/([\d\.]+)/i],
            [VO, [aK, EO + "cast"]],
            [/(cros) [\w]+(?:\)| ([\w\.]+)\b)/i],
            [
              [aK, xK], VO
            ],
            [/panasonic;(viera)/i, /(netrange)mmh/i, /(nettv)\/(\d+\.[\w\.]+)/i, /(nintendo|playstation) ([wids345portablevuch]+)/i, /(xbox); +xbox ([^\);]+)/i, /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i, /(mint)[\/\(\) ]?(\w*)/i, /(mageia|vectorlinux)[; ]/i, /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i, /(hurd|linux)(?: arm\w*| x86\w*| ?)([\w\.]*)/i, /(gnu) ?([\w\.]*)/i, /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, /(haiku) (\w+)/i],
            [aK, VO],
            [/(sunos) ?([\w\.\d]*)/i],
            [
              [aK, "Solaris"], VO
            ],
            [/((?:open)?solaris)[-\/ ]?([\w\.]*)/i, /(aix) ((\d)(?=\.|\)| )[\w\.])*/i, /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i, /(unix) ?([\w\.]*)/i],
            [aK, VO]
          ]
        },
        eK = function(OO, KO) {
          if (typeof OO === CO && (KO = OO, OO = eO), !(this instanceof eK)) return new eK(OO, KO).getResult();
          var pO = typeof bK !== vK && bK.navigator ? bK.navigator : eO,
            XO = OO || (pO && pO.userAgent ? pO.userAgent : ""),
            QO = pO && pO.userAgentData ? pO.userAgentData : eO,
            fO = KO ? function(OO, KO) {
              var pO = {};
              for (var XO in OO) KO[XO] && KO[XO].length % 2 === 0 ? pO[XO] = KO[XO].concat(OO[XO]) : pO[XO] = OO[XO];
              return pO
            }(bp, KO) : bp,
            dO = pO && pO.userAgent == XO;
          return this.getBrowser = function() {
            var OO, KO = {};
            return KO[aK] = eO, KO[VO] = eO, KK.call(KO, XO, fO.browser), KO[DO] = typeof(OO = KO[VO]) === hO ? OO.replace(/[^\d\.]/g, "").split(".")[0] : eO, dO && pO && pO.brave && typeof pO.brave.isBrave == lO && (KO[aK] = "Brave"), KO
          }, this.getCPU = function() {
            var OO = {};
            return OO[LO] = eO, KK.call(OO, XO, fO.cpu), OO
          }, this.getDevice = function() {
            var OO = {};
            return OO[FO] = eO, OO[MO] = eO, OO[oO] = eO, KK.call(OO, XO, fO.device), dO && !OO[oO] && QO && QO.mobile && (OO[oO] = zK), dO && "Macintosh" == OO[MO] && pO && typeof pO.standalone !== vK && pO.maxTouchPoints && pO.maxTouchPoints > 2 && (OO[MO] = "iPad", OO[oO] = AO), OO
          }, this.qb = function() {
            var OO = {};
            return OO[aK] = eO, OO[VO] = eO, KK.call(OO, XO, fO.engine), OO
          }, this.getOS = function() {
            var OO = {};
            return OO[aK] = eO, OO[VO] = eO, KK.call(OO, XO, fO.os), dO && !OO[aK] && QO && QO.platform && "Unknown" != QO.platform && (OO[aK] = QO.platform.replace(/chrome os/i, xK).replace(/macos/i, nO)), OO
          }, this.getResult = function() {
            return {
              ua: this.getUA(),
              browser: this.getBrowser(),
              engine: this.qb(),
              os: this.getOS(),
              device: this.getDevice(),
              cpu: this.getCPU()
            }
          }, this.getUA = function() {
            return XO
          }, this.setUA = function(OO) {
            return XO = typeof OO === hO && OO.length > 500 ? OK(OO, 500) : OO, this
          }, this.setUA(XO), this
        };
      eK.VERSION = "1.0.41", eK.BROWSER = tK([aK, VO, DO]), eK.CPU = tK([LO]), eK.DEVICE = tK([MO, FO, oO, QO, zK, fO, AO, dO, TO]), eK.ENGINE = eK.OS = tK([aK, VO]), typeof KO !== vK ? (OO.exports && (KO = OO.exports = eK), KO.UAParser = eK) : pO.amdO ? (XO = function() {
        return eK
      }.call(KO, pO, KO, OO)) === eO || (OO.exports = XO) : typeof bK !== vK && (bK.UAParser = eK);
      var lK = typeof bK !== vK && (bK.jQuery || bK.Zepto);
      if (lK && !lK.ua) {
        var vp = new eK;
        lK.ua = vp.getResult(), lK.ua.get = function() {
          return vp.getUA()
        }, lK.ua.set = function(OO) {
          vp.setUA(OO);
          var KO = vp.getResult();
          for (var pO in KO) lK.ua[pO] = KO[pO]
        }
      }
    }("object" === typeof window ? window : this)
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);