export const id = 238;
export const ids = [238];
export const modules = {
  38330: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO,
      c: () => vK
    });
    var XO = pO(37061),
      bK = pO(38077),
      eO = pO(38294),
      lO = {};
    class vK {
      constructor(OO) {
        this.attachedToElement = !1, this.attached = {}, this.camera = OO, this.checkInputs = () => {}
      }
      add(OO) {
        const KO = OO.getSimpleName();
        this.attached[KO] ? XO.b.Warn("camera input of type " + KO + " already exists on camera") : (this.attached[KO] = OO, OO.camera = this.camera, OO.checkInputs && (this.checkInputs = this._addCheckInputs(OO.checkInputs.bind(OO))), this.attachedToElement && OO.attachControl(this.noPreventDefault))
      }
      remove(OO) {
        for (const KO in this.attached) {
          const pO = this.attached[KO];
          if (pO === OO) return pO.detachControl(), pO.camera = null, delete this.attached[KO], void this.rebuildInputCheck()
        }
      }
      removeByType(OO) {
        for (const KO in this.attached) {
          const pO = this.attached[KO];
          pO.getClassName() === OO && (pO.detachControl(), pO.camera = null, delete this.attached[KO], this.rebuildInputCheck())
        }
      }
      _addCheckInputs(OO) {
        const KO = this.checkInputs;
        return () => {
          KO(), OO()
        }
      }
      attachInput(OO) {
        this.attachedToElement && OO.attachControl(this.noPreventDefault)
      }
      attachElement() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        if (!this.attachedToElement) {
          OO = !eO.c.ForceAttachControlToAlwaysPreventDefault && OO, this.attachedToElement = !0, this.noPreventDefault = OO;
          for (const KO in this.attached) this.attached[KO].attachControl(OO)
        }
      }
      detachElement() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        for (const KO in this.attached) this.attached[KO].detachControl(), OO && (this.attached[KO].camera = null);
        this.attachedToElement = !1
      }
      rebuildInputCheck() {
        this.checkInputs = () => {};
        for (const OO in this.attached) {
          const KO = this.attached[OO];
          KO.checkInputs && (this.checkInputs = this._addCheckInputs(KO.checkInputs.bind(KO)))
        }
      }
      clear() {
        this.attachedToElement && this.detachElement(!0), this.attached = {}, this.attachedToElement = !1, this.checkInputs = () => {}
      }
      serialize(OO) {
        const KO = {};
        for (const pO in this.attached) {
          const OO = this.attached[pO],
            XO = bK.c.Serialize(OO);
          KO[OO.getClassName()] = XO
        }
        OO.inputsmgr = KO
      }
      parse(OO) {
        const KO = OO.inputsmgr;
        if (KO) {
          this.clear();
          for (const OO in KO) {
            const pO = lO[OO];
            if (pO) {
              const XO = KO[OO],
                eO = bK.c.Parse((() => new pO), XO, null);
              this.add(eO)
            }
          }
        } else
          for (const pO in this.attached) {
            const KO = lO[this.attached[pO].getClassName()];
            if (KO) {
              const XO = bK.c.Parse((() => new KO), OO, null);
              this.remove(this.attached[pO]), this.add(XO)
            }
          }
      }
    }
  },
  39276: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => AO
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(37955),
      lO = pO(35632),
      vK = pO(38056),
      CO = pO(38580),
      hO = pO(35676),
      DO = pO(35660),
      MO = pO(38077),
      aK = pO(37889),
      oO = pO(37061),
      FO = pO(38104),
      VO = pO(36274),
      LO = pO(38157);
    var QO = pO(37962);
    let zK = !1;
    let AO = (() => {
        var OO;
        let KO, pO, hO, AO, fO, dO, TO, NO, IO, yK = vK.d,
          gK = [],
          uO = [],
          EO = [],
          jK = [],
          YO = [],
          wO = [],
          iK = [],
          rK = [],
          PO = [],
          mK = [],
          sO = [],
          HO = [],
          RO = [],
          SO = [],
          JO = [];
        return OO = class extends yK {
          set boundingBoxSize(OO) {
            if (this._boundingBoxSize && this._boundingBoxSize.equals(OO)) return;
            this._boundingBoxSize = OO;
            const KO = this.JKO();
            KO && KO.markAllMaterialsAsDirty(1)
          }
          get boundingBoxSize() {
            return this._boundingBoxSize
          }
          set rotationY(OO) {
            this._rotationY = OO, this.setReflectionTextureMatrix(lO.c.RotationY(this._rotationY))
          }
          get rotationY() {
            return this._rotationY
          }
          get noMipmap() {
            return this._noMipmap
          }
          get forcedExtension() {
            return this._forcedExtension
          }
          constructor(OO, KO) {
            let pO, bK = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
              eO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
              vK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
              hO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
              MO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null,
              AO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 5,
              fO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8],
              dO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : null,
              TO = arguments.length > 10 && void 0 !== arguments[10] && arguments[10],
              NO = arguments.length > 11 && void 0 !== arguments[11] ? arguments[11] : .8,
              IO = arguments.length > 12 && void 0 !== arguments[12] ? arguments[12] : 0,
              yK = arguments.length > 13 ? arguments[13] : void 0,
              cK = arguments.length > 14 ? arguments[14] : void 0;
            super(KO), this._delayedOnLoad = (0, XO.i)(this, gK), this.onLoadObservable = new DO.e, this.url = (0, XO.i)(this, uO, void 0), this.boundingBoxPosition = ((0, XO.i)(this, EO), (0, XO.i)(this, jK, lO.o.Zero())), this._boundingBoxSize = (0, XO.i)(this, YO), this._rotationY = 0, this._files = (0, XO.i)(this, wO, null), this._forcedExtension = ((0, XO.i)(this, iK), (0, XO.i)(this, rK, null)), this._extensions = ((0, XO.i)(this, PO), (0, XO.i)(this, mK, null)), this._textureMatrix = ((0, XO.i)(this, sO), (0, XO.i)(this, HO, void 0)), this._textureMatrixRefraction = ((0, XO.i)(this, RO), (0, XO.i)(this, SO, new lO.c)), this._format = (0, XO.i)(this, JO), this._buffer = null, zK || (zK = !0, QO.e.prototype._partialLoadFile = function(OO, KO, pO, XO) {
              let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
              this._loadFile(OO, (OO => {
                pO[KO] = OO, pO._internalCount++, 6 === pO._internalCount && XO(pO)
              }), void 0, void 0, !0, ((OO, KO) => {
                bK && OO && bK(OO.status + " " + OO.statusText, KO)
              }))
            }, QO.e.prototype._cascadeLoadFiles = function(OO, KO, pO) {
              let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
              const bK = [];
              bK._internalCount = 0;
              for (let eO = 0; eO < 6; eO++) this._partialLoadFile(pO[eO], eO, bK, KO, XO)
            }, QO.e.prototype._cascadeLoadImgs = function(OO, KO, pO, XO) {
              let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
                eO = arguments.length > 5 ? arguments[5] : void 0;
              const lO = [];
              lO._internalCount = 0;
              for (let vK = 0; vK < 6; vK++) this._partialLoadImg(XO[vK], vK, lO, OO, KO, pO, bK, eO)
            }, QO.e.prototype._partialLoadImg = function(OO, KO, pO, XO, bK, eO) {
              let lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null,
                vK = arguments.length > 7 ? arguments[7] : void 0;
              const CO = (0, VO.b)();
              (0, FO.s)(OO, (OO => {
                pO[KO] = OO, pO._internalCount++, XO && XO.removePendingData(CO), 6 === pO._internalCount && eO && eO(bK, pO)
              }), ((OO, KO) => {
                XO && XO.removePendingData(CO), lO && lO(OO, KO)
              }), XO ? XO.offlineProvider : null, vK), XO && XO.addPendingData(CO)
            }, QO.e.prototype.createCubeTextureBase = function(OO, KO, pO, XO) {
              let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
                eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
                lO = arguments.length > 6 ? arguments[6] : void 0,
                vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
                CO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8],
                hO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0,
                DO = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : 0,
                MO = arguments.length > 11 && void 0 !== arguments[11] ? arguments[11] : null,
                FO = arguments.length > 12 && void 0 !== arguments[12] ? arguments[12] : null,
                VO = arguments.length > 13 && void 0 !== arguments[13] ? arguments[13] : null,
                QO = arguments.length > 14 && void 0 !== arguments[14] && arguments[14],
                zK = arguments.length > 15 && void 0 !== arguments[15] ? arguments[15] : null;
              const AO = MO || new aK.e(this, 7);
              AO.isCube = !0, AO.url = OO, AO.generateMipMaps = !XO, AO._lodGenerationScale = hO, AO._lodGenerationOffset = DO, AO._useSRGBBuffer = !!QO && this._caps.supportSRGBBuffers && (this.version > 1 || this.isWebGPU || !!XO), AO !== MO && (AO.label = OO.substring(0, 60)), this._doNotHandleContextLost || (AO._extension = vK, AO._files = pO, AO._buffer = zK);
              const fO = OO;
              this._transformTextureUrl && !MO && (OO = this._transformTextureUrl(OO));
              const dO = vK ?? function(OO) {
                  const KO = OO.split("?")[0],
                    pO = KO.lastIndexOf(".");
                  return pO > -1 ? KO.substring(pO).toLowerCase() : ""
                }(OO),
                TO = (0, LO.e)(dO),
                NO = (OO, KO) => {
                  AO.dispose(), eO ? eO(OO, KO) : OO && oO.b.Warn(OO)
                },
                IO = (eO, MO) => {
                  OO === fO ? eO && NO(eO.status + " " + eO.statusText, MO) : (oO.b.Warn(`Failed to load ${OO}, falling back to the ${fO}`), this.createCubeTextureBase(fO, KO, pO, !!XO, bK, NO, lO, vK, CO, hO, DO, AO, FO, VO, QO, zK))
                };
              if (TO) TO.then((XO => {
                const eO = OO => {
                  FO && FO(AO, OO), XO.loadCubeData(OO, AO, CO, bK, ((OO, KO) => {
                    NO(OO, KO)
                  }))
                };
                zK ? eO(zK) : pO && 6 === pO.length ? XO.supportCascades ? this._cascadeLoadFiles(KO, (OO => eO(OO.map((OO => new Uint8Array(OO))))), pO, NO) : NO("Textures type does not support cascades.") : this._loadFile(OO, (OO => eO(new Uint8Array(OO))), void 0, KO ? KO.offlineProvider || null : void 0, !0, IO)
              }));
              else {
                if (!pO || 0 === pO.length) throw new Error("Cannot load cubemap because files were not defined, or the correct loader was not found.");
                this._cascadeLoadImgs(KO, AO, ((OO, KO) => {
                  VO && VO(OO, KO)
                }), pO, NO)
              }
              return this._internalTexturesCache.push(AO), AO
            }), this.name = OO, this.url = OO, this._noMipmap = eO, this.hasAlpha = !1, this.isCube = !0, this._textureMatrix = lO.c.Identity(), this.coordinatesMode = CO.e.CUBIC_MODE;
            let BO = null;
            null === bK || Array.isArray(bK) ? (this._noMipmap = eO, this._format = AO, this._createPolynomials = TO, pO = bK, this._loaderOptions = yK, this._useSRGBBuffer = cK, this._lodScale = NO, this._lodOffset = IO) : (pO = bK.extensions ?? null, this._noMipmap = bK.noMipmap ?? !1, vK = bK.files ?? null, BO = bK.buffer ?? null, this._format = bK.format ?? 5, fO = bK.prefiltered ?? !1, dO = bK.forcedExtension ?? null, this._createPolynomials = bK.createPolynomials ?? !1, this._lodScale = bK.lodScale ?? .8, this._lodOffset = bK.lodOffset ?? 0, this._loaderOptions = bK.loaderOptions, this._useSRGBBuffer = bK.useSRGBBuffer, this._sphericalPolynomialTargetSize = bK.sphericalPolynomialTargetSize ?? 0, hO = bK.onLoad ?? null, MO = bK.onError ?? null), (OO || vK) && this.updateURL(OO, dO, hO, fO, MO, pO, this.JKO()?.useDelayedTextureLoading, vK, BO)
          }
          getClassName() {
            return "CubeTexture"
          }
          updateURL(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
              pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
              XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
              bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
              eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
              lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
              vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
              CO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : null;
            this.name && !this.name.startsWith("data:") || (this.name = OO), this.url = OO, KO && (this._forcedExtension = KO);
            const hO = OO.lastIndexOf("."),
              DO = KO || (hO > -1 ? OO.substring(hO).toLowerCase() : ""),
              MO = 0 === DO.indexOf(".dds"),
              aK = 0 === DO.indexOf(".env"),
              oO = 0 === DO.indexOf(".basis");
            if (aK ? (this.gammaSpace = !1, this._prefiltered = !1, this.anisotropicFilteringLevel = 1) : (this._prefiltered = XO, XO && (this.gammaSpace = !1, this.anisotropicFilteringLevel = 1)), vK) this._files = vK;
            else if (oO || aK || MO || eO || (eO = ["_px.jpg", "_py.jpg", "_pz.jpg", "_nx.jpg", "_ny.jpg", "_nz.jpg"]), this._files = this._files || [], this._files.length = 0, eO) {
              for (let KO = 0; KO < eO.length; KO++) this._files.push(OO + eO[KO]);
              this._extensions = eO
            }
            this._buffer = CO, lO ? (this.delayLoadState = 4, this._delayedOnLoad = pO, this._delayedOnError = bK) : this._loadTexture(pO, bK)
          }
          delayLoad(OO) {
            4 === this.delayLoadState && (OO && (this._forcedExtension = OO), this.delayLoadState = 1, this._loadTexture(this._delayedOnLoad, this._delayedOnError))
          }
          getReflectionTextureMatrix() {
            return this._textureMatrix
          }
          setReflectionTextureMatrix(OO) {
            if (OO.updateFlag === this._textureMatrix.updateFlag) return;
            if (OO.isIdentity() !== this._textureMatrix.isIdentity() && this.JKO()?.markAllMaterialsAsDirty(1, (OO => -1 !== OO.getActiveTextures().indexOf(this))), this._textureMatrix = OO, !this.JKO()?.useRightHandedSystem) return;
            const KO = lO.j.WX[0],
              pO = lO.j.Quaternion[0],
              XO = lO.j.WX[1];
            this._textureMatrix.decompose(KO, pO, XO), pO.z *= -1, pO.w *= -1, lO.c.ComposeToRef(KO, pO, XO, this._textureMatrixRefraction)
          }
          getRefractionTextureMatrix() {
            return this.JKO()?.useRightHandedSystem ? this._textureMatrixRefraction : this._textureMatrix
          }
          _loadTexture() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
              KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
            const pO = this.JKO(),
              XO = this._texture;
            this._texture = this._getFromCache(this.url, this._noMipmap, void 0, void 0, this._useSRGBBuffer, this.isCube);
            const bK = () => {
                this.onLoadObservable.notifyObservers(this), XO && (XO.dispose(), this.JKO()?.markAllMaterialsAsDirty(1)), OO && OO()
              },
              lO = (OO, pO) => {
                this._loadingError = !0, this._errorObject = {
                  message: OO,
                  exception: pO
                }, KO && KO(OO, pO), CO.e.OnTextureLoadErrorObservable.notifyObservers(this)
              };
            this._texture ? this._texture.isReady ? eO.c.SetImmediate((() => bK())) : this._texture.onLoadedObservable.add((() => bK())) : (this._prefiltered ? this._texture = this._getEngine().createPrefilteredCubeTexture(this.url, pO, this._lodScale, this._lodOffset, OO, lO, this._format, this._forcedExtension, this._createPolynomials, this._buffer) : this._texture = this._getEngine().createCubeTexture(this.url, pO, this._files, this._noMipmap, OO, lO, this._format, this._forcedExtension, !1, this._lodScale, this._lodOffset, null, this._loaderOptions, !!this._useSRGBBuffer, this._buffer), this._texture?.onLoadedObservable.add((() => this.onLoadObservable.notifyObservers(this))))
          }
          clone() {
            let KO = 0;
            const pO = this.irradianceTexture,
              XO = MO.c.Clone((() => {
                const pO = new OO(this.url, this.JKO() || this._getEngine(), this._extensions, this._noMipmap, this._files);
                return KO = pO.uniqueId, pO
              }), this);
            return XO.uniqueId = KO, pO && !this.irradianceTexture && (this.irradianceTexture = pO), XO
          }
        }, (() => {
          const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(yK[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.M)()], pO = [(0, bK.L)()], hO = [(0, bK.L)()], AO = [(0, bK.M)("rotationY")], fO = [(0, bK.M)("files")], dO = [(0, bK.M)("forcedExtension")], TO = [(0, bK.M)("extensions")], NO = [(0, bK.z)("textureMatrix")], IO = [(0, bK.z)("textureMatrixRefraction")], (0, XO.f)(OO, null, hO, {
            kind: "getter",
            name: "boundingBoxSize",
            static: !1,
            private: !1,
            access: {
              has: OO => "boundingBoxSize" in OO,
              get: OO => OO.boundingBoxSize
            },
            metadata: eO
          }, null, gK), (0, XO.f)(OO, null, AO, {
            kind: "setter",
            name: "rotationY",
            static: !1,
            private: !1,
            access: {
              has: OO => "rotationY" in OO,
              set: (OO, KO) => {
                OO.rotationY = KO
              }
            },
            metadata: eO
          }, null, gK), (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "url",
            static: !1,
            private: !1,
            access: {
              has: OO => "url" in OO,
              get: OO => OO.url,
              set: (OO, KO) => {
                OO.url = KO
              }
            },
            metadata: eO
          }, uO, EO), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "boundingBoxPosition",
            static: !1,
            private: !1,
            access: {
              has: OO => "boundingBoxPosition" in OO,
              get: OO => OO.boundingBoxPosition,
              set: (OO, KO) => {
                OO.boundingBoxPosition = KO
              }
            },
            metadata: eO
          }, jK, YO), (0, XO.f)(null, null, fO, {
            kind: "field",
            name: "_files",
            static: !1,
            private: !1,
            access: {
              has: OO => "_files" in OO,
              get: OO => OO._files,
              set: (OO, KO) => {
                OO._files = KO
              }
            },
            metadata: eO
          }, wO, iK), (0, XO.f)(null, null, dO, {
            kind: "field",
            name: "_forcedExtension",
            static: !1,
            private: !1,
            access: {
              has: OO => "_forcedExtension" in OO,
              get: OO => OO._forcedExtension,
              set: (OO, KO) => {
                OO._forcedExtension = KO
              }
            },
            metadata: eO
          }, rK, PO), (0, XO.f)(null, null, TO, {
            kind: "field",
            name: "_extensions",
            static: !1,
            private: !1,
            access: {
              has: OO => "_extensions" in OO,
              get: OO => OO._extensions,
              set: (OO, KO) => {
                OO._extensions = KO
              }
            },
            metadata: eO
          }, mK, sO), (0, XO.f)(null, null, NO, {
            kind: "field",
            name: "_textureMatrix",
            static: !1,
            private: !1,
            access: {
              has: OO => "_textureMatrix" in OO,
              get: OO => OO._textureMatrix,
              set: (OO, KO) => {
                OO._textureMatrix = KO
              }
            },
            metadata: eO
          }, HO, RO), (0, XO.f)(null, null, IO, {
            kind: "field",
            name: "_textureMatrixRefraction",
            static: !1,
            private: !1,
            access: {
              has: OO => "_textureMatrixRefraction" in OO,
              get: OO => OO._textureMatrixRefraction,
              set: (OO, KO) => {
                OO._textureMatrixRefraction = KO
              }
            },
            metadata: eO
          }, SO, JO), eO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: eO
          })
        })(), OO
      })(),
      fO = !1;

    function dO(OO, KO, pO) {
      let XO = "";
      for (const bK of OO) XO += bK;
      return new AO(XO, KO, null, pO, OO)
    }

    function TO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
        XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
      const bK = KO.useDelayedTextureLoading;
      KO.useDelayedTextureLoading = !1;
      const eO = new AO(OO, KO, null, !1, null, null, null, void 0, !0, pO, XO);
      return KO.useDelayedTextureLoading = bK, eO
    }

    function NO(OO, KO, pO) {
      const XO = MO.c.Parse((() => {
        let XO = !1;
        return OO.prefiltered && (XO = OO.prefiltered), new AO(pO + (OO.url ?? OO.name), KO, OO.extensions, !1, OO.files || null, null, null, void 0, XO, OO.forcedExtension)
      }), OO, KO);
      if (OO.boundingBoxPosition && (XO.boundingBoxPosition = lO.o.FromArray(OO.boundingBoxPosition)), OO.boundingBoxSize && (XO.boundingBoxSize = lO.o.FromArray(OO.boundingBoxSize)), OO.animations)
        for (let bK = 0; bK < OO.animations.length; bK++) {
          const KO = OO.animations[bK],
            pO = (0, hO.e)("BABYLON.Animation");
          pO && XO.animations.push(pO.Parse(KO))
        }
      return XO
    }
    fO || (fO = !0, AO.CreateFromImages = dO, AO.CreateFromPrefilteredData = TO, AO.Parse = NO, CO.e._CubeTextureParser = NO, (0, hO.h)("BABYLON.CubeTexture", AO))
  },
  39317: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => hO
    });
    var XO = pO(37061),
      bK = pO(38580),
      eO = pO(37996),
      lO = pO(37899),
      vK = pO(37889);
    let CO = !1;
    class hO extends bK.e {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          hO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 3,
          DO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 5,
          MO = arguments.length > 6 ? arguments[6] : void 0;
        const aK = !pO || pO._isScene;
        super(null, aK ? pO : pO?.Ce, aK ? !XO : pO, MO, hO, void 0, void 0, void 0, void 0, DO), CO || (CO = !0, lO.ThinEngine.prototype.createDynamicTexture = function(OO, KO, pO, XO) {
          const bK = new vK.e(this, 4);
          return bK.baseWidth = OO, bK.baseHeight = KO, pO && (OO = this.needPOTTextures ? (0, eO.i)(OO, this._caps.maxTextureSize) : OO, KO = this.needPOTTextures ? (0, eO.i)(KO, this._caps.maxTextureSize) : KO), bK.width = OO, bK.height = KO, bK.isReady = !1, bK.generateMipMaps = pO, bK.samplingMode = XO, this.updateTextureSamplingMode(XO, bK), this._internalTexturesCache.push(bK), bK
        }, lO.ThinEngine.prototype.updateDynamicTexture = function(OO, KO, pO) {
          let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
            bK = arguments.length > 4 ? arguments[4] : void 0,
            eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
          if (!OO) return;
          const lO = this._gl,
            vK = lO.TEXTURE_2D,
            CO = this._bindTextureDirectly(vK, OO, !0, eO);
          this._unpackFlipY(void 0 === pO ? OO.invertY : pO), XO && lO.pixelStorei(lO.UNPACK_PREMULTIPLY_ALPHA_WEBGL, 1);
          const hO = this._getWebGLTextureType(OO.type),
            DO = this._getInternalFormat(bK || OO.format),
            MO = this._getRGBABufferInternalSizedFormat(OO.type, DO);
          lO.texImage2D(vK, 0, MO, DO, hO, KO), OO.generateMipMaps && lO.generateMipmap(vK), CO || this._bindTextureDirectly(vK, null), XO && lO.pixelStorei(lO.UNPACK_PREMULTIPLY_ALPHA_WEBGL, 0), bK && (OO.format = bK), OO._dynamicTextureSource = KO, OO._premulAlpha = XO, OO.invertY = pO || !1, OO.isReady = !0
        }), this.name = OO, this.wrapU = bK.e.CLAMP_ADDRESSMODE, this.wrapV = bK.e.CLAMP_ADDRESSMODE, this._generateMipMaps = XO;
        const oO = this._getEngine();
        if (!oO) return;
        if (KO.getContext) this._canvas = KO, this._ownCanvas = !1, this._texture = oO.createDynamicTexture(this._canvas.width, this._canvas.height, XO, hO);
        else {
          this._canvas = oO.createCanvas(1, 1), this._ownCanvas = !0;
          const OO = KO;
          OO.width || 0 === OO.width ? this._texture = oO.createDynamicTexture(OO.width, OO.height, XO, hO) : this._texture = oO.createDynamicTexture(KO, KO, XO, hO)
        }
        const FO = this.getSize();
        this._canvas.width !== FO.width && (this._canvas.width = FO.width), this._canvas.height !== FO.height && (this._canvas.height = FO.height), this._context = this._canvas.getContext("2d")
      }
      getClassName() {
        return "DynamicTexture"
      }
      get canRescale() {
        return !0
      }
      _recreate(OO) {
        this._canvas.width = OO.width, this._canvas.height = OO.height, this.releaseInternalTexture(), this._texture = this._getEngine().createDynamicTexture(OO.width, OO.height, this._generateMipMaps, this.samplingMode)
      }
      scale(OO) {
        const KO = this.getSize();
        KO.width *= OO, KO.height *= OO, this._recreate(KO)
      }
      scaleTo(OO, KO) {
        const pO = this.getSize();
        pO.width = OO, pO.height = KO, this._recreate(pO)
      }
      getContext() {
        return this._context
      }
      clear(OO) {
        const KO = this.getSize();
        OO && (this._context.fillStyle = OO), this._context.clearRect(0, 0, KO.width, KO.height)
      }
      update(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        this._texture && this._getEngine().updateDynamicTexture(this._texture, this._canvas, void 0 === OO || OO, KO, this._format || void 0, void 0, pO)
      }
      drawText(OO, KO, pO, XO, bK, eO, lO) {
        let vK = !(arguments.length > 7 && void 0 !== arguments[7]) || arguments[7];
        const CO = this.getSize();
        if (eO && (this._context.fillStyle = eO, this._context.fillRect(0, 0, CO.width, CO.height)), this._context.font = XO, null === KO || void 0 === KO) {
          const pO = this._context.measureText(OO);
          KO = (CO.width - pO.width) / 2
        }
        if (null === pO || void 0 === pO) {
          const OO = parseInt(XO.replace(/\D/g, ""));
          pO = CO.height / 2 + OO / 3.65
        }
        this._context.fillStyle = bK || "", this._context.fillText(OO, KO, pO), vK && this.update(lO)
      }
      dispose() {
        super.dispose(), this._ownCanvas && this._canvas?.remove?.(), this._canvas = null, this._context = null
      }
      clone() {
        const OO = this.JKO();
        if (!OO) return this;
        const KO = this.getSize(),
          pO = new hO(this.name, KO, OO, this._generateMipMaps);
        return pO.hasAlpha = this.hasAlpha, pO.level = this.level, pO.wrapU = this.wrapU, pO.wrapV = this.wrapV, pO
      }
      serialize() {
        const OO = this.JKO();
        OO && !OO.isReady() && XO.b.Warn("The scene must be ready before serializing the dynamic texture");
        const KO = super.serialize();
        return hO._IsCanvasElement(this._canvas) && (KO.base64String = this._canvas.toDataURL()), KO.invertY = this._invertY, KO.samplingMode = this.samplingMode, KO
      }
      static _IsCanvasElement(OO) {
        return void 0 !== OO.toDataURL
      }
      _rebuild() {
        this.update()
      }
    }
  },
  39291: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(38580);
    class bK extends XO.e {
      get depth() {
        return this._depth
      }
      constructor(OO, KO, pO, bK, eO, lO) {
        let vK = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6],
          CO = arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
          hO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : XO.e.TRILINEAR_SAMPLINGMODE,
          DO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0,
          MO = arguments.length > 10 ? arguments[10] : void 0,
          aK = arguments.length > 11 ? arguments[11] : void 0;
        super(null, lO, !vK, CO), this.format = eO, this._texture = lO.qb().createRawTexture2DArray(OO, KO, pO, bK, eO, vK, CO, hO, null, DO, MO ?? 0, aK), this._depth = bK, this.is2DArray = !0
      }
      update(OO) {
        this.updateMipLevel(OO, 0)
      }
      updateMipLevel(OO, KO) {
        this._texture && this._getEngine().updateRawTexture2DArray(this._texture, OO, this._texture.format, this._texture.invertY, null, this._texture.type, KO)
      }
      static CreateRGBATexture(OO, KO, pO, XO, eO) {
        return new bK(OO, KO, pO, XO, 5, eO, !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5], arguments.length > 6 && void 0 !== arguments[6] && arguments[6], arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 3, arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0)
      }
    }
  },
  39285: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO.c
    });
    var XO = pO(38456);
    (0, XO.f)()
  },
  38162: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO.e
    });
    var XO = pO(38170);
    (0, XO.c)()
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);