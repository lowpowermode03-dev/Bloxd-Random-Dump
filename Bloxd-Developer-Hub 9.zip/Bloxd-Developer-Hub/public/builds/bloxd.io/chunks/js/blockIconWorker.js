(() => {
  (() => {
    if ("undefined" !== typeof __webpack_require__) {
      var OO = __webpack_require__.u,
        KO = __webpack_require__.e,
        pO = {},
        XO = {};
      __webpack_require__.u = function(KO) {
        return OO(KO) + (pO.hasOwnProperty(KO) ? "?" + pO[KO] : "")
      }, __webpack_require__.e = function(bK) {
        return KO(bK).catch((function(KO) {
          var eO = XO.hasOwnProperty(bK) ? XO[bK] : 4;
          if (eO < 1) {
            var lO = OO(bK);
            throw KO.message = "Loading chunk " + bK + " failed after 4 retries.\n(" + lO + ")", KO.request = lO, pO[bK] = "cache-bust=" + Date.now(), setTimeout((function() {
              delete XO[bK]
            }), 0), KO
          }
          return new Promise((function(OO) {
            var KO = 4 - eO + 1;
            setTimeout((function() {
              var KO = "cache-bust=" + Date.now();
              pO[bK] = KO, XO[bK] = eO - 1, OO(__webpack_require__.e(bK))
            }), function(OO) {
              return 500 * Math.pow(2, OO)
            }(KO))
          }))
        }))
      }
    }
  })();
  const OO = [15, 15, 15],
    KO = {
      top: 1,
      left: .85,
      right: .7
    };

  function pO(KO, pO, XO) {
    let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : OO => 0 !== KO[4 * OO + 3];
    const eO = (OO, KO) => OO < 0 || KO < 0 || OO >= pO || KO >= pO || !bK(KO * pO + OO),
      lO = [];
    for (let OO = 0; OO < pO; OO++)
      for (let KO = 0; KO < pO; KO++)
        if (!eO(KO, OO)) OO: for (let bK = -XO; bK <= XO; bK++) {
          const vK = XO - Math.abs(bK);
          for (let XO = -vK; XO <= vK; XO++)
            if (eO(KO + XO, OO + bK)) {
              lO.push(OO * pO + KO);
              break OO
            }
        }
    for (const vK of lO) KO.set(OO, 4 * vK), KO[4 * vK + 3] = 255
  }
  const XO = Math.SQRT1_2,
    bK = Math.sqrt(3) / 2,
    eO = {
      boxes: [
        [0, 0, 0, 1, 1, 1]
      ],
      cropFaces: !1
    },
    lO = {
      boxes: [
        [0, 0, 0, 1, .5, 1]
      ],
      cropFaces: !1
    },
    vK = {
      boxes: [
        [0, 0, 0, 1, .5, 1],
        [0, .5, 0, .5, 1, 1]
      ],
      cropFaces: !0
    };
  const CO = 1e-6;

  function hO(OO, KO, pO, XO) {
    let {
      origin: bK,
      across: eO,
      down: lO,
      texture: vK,
      rect: [hO, DO, MO, aK],
      shade: oO
    } = XO;
    const FO = eO.x * lO.y - eO.y * lO.x;
    if (Math.abs(FO) < 1e-9) return;
    const VO = [bK.x, bK.x + eO.x, bK.x + lO.x, bK.x + eO.x + lO.x],
      LO = [bK.y, bK.y + eO.y, bK.y + lO.y, bK.y + eO.y + lO.y],
      QO = Math.max(0, Math.floor(Math.min(...VO))),
      zK = Math.min(pO - 1, Math.ceil(Math.max(...VO))),
      AO = Math.max(0, Math.floor(Math.min(...LO))),
      fO = Math.min(pO - 1, Math.ceil(Math.max(...LO)));
    for (let dO = AO; dO <= fO; dO++)
      for (let XO = QO; XO <= zK; XO++) {
        const VO = XO + .5 - bK.x,
          LO = dO + .5 - bK.y,
          QO = (VO * lO.y - LO * lO.x) / FO,
          zK = (eO.x * LO - eO.y * VO) / FO;
        if (QO < -CO || QO > 1 + CO || zK < -CO || zK > 1 + CO) continue;
        const AO = dO * pO + XO;
        KO[AO] = 1;
        const fO = hO + Math.min(Math.max(QO, 0), 1) * (MO - hO),
          TO = DO + Math.min(Math.max(zK, 0), 1) * (aK - DO),
          NO = Math.min(vK.width - 1, Math.floor(fO * vK.width)),
          IO = 4 * (Math.min(vK.height - 1, Math.floor(TO * vK.height)) * vK.width + NO),
          yK = vK.pixels[IO + 3] / 255;
        if (0 === yK) continue;
        const gK = 4 * AO,
          uO = OO[gK + 3] / 255 * (1 - yK),
          EO = yK + uO;
        for (let KO = 0; KO < 3; KO++) OO[gK + KO] = (vK.pixels[IO + KO] * oO * yK + OO[gK + KO] * uO) / EO;
        OO[gK + 3] = 255 * EO
      }
  }

  function DO(OO, KO, pO) {
    const XO = OO.get(KO);
    if (void 0 === XO) throw new Error(`no ${pO} was sent for ${KO.slice(0,100)}`);
    return XO
  }
  const MO = {
      pixelsOf(OO) {
        const KO = new OffscreenCanvas(OO.width, OO.height),
          pO = KO.getContext("2d");
        if (!pO) throw new Error("no 2D context");
        return pO.drawImage(OO, 0, 0), OO.close(), {
          width: KO.width,
          height: KO.height,
          pixels: pO.getImageData(0, 0, KO.width, KO.height).data
        }
      },
      async encode(OO, KO) {
        const pO = new OffscreenCanvas(KO, KO),
          XO = pO.getContext("2d");
        if (!XO) throw new Error("no 2D context");
        XO.putImageData(new ImageData(OO, KO, KO), 0, 0);
        const bK = await pO.convertToBlob();
        return new Promise(((OO, KO) => {
          const pO = new FileReader;
          pO.onload = () => {
            OO(pO.result)
          }, pO.onerror = () => {
            var OO;
            KO(null !== (OO = pO.error) && void 0 !== OO ? OO : new Error("the icon did not encode"))
          }, pO.readAsDataURL(bK)
        }))
      }
    },
    aK = globalThis.WorkerGlobalScope;
  void 0 !== aK && globalThis instanceof aK && function(OO, CO) {
    const MO = new Map,
      aK = new Map,
      oO = (KO, pO, XO) => {
        (async () => {
          try {
            OO.postMessage({
              type: "drawn",
              id: KO,
              url: await CO.encode(XO(), pO)
            })
          } catch (bK) {
            OO.postMessage({
              type: "failed",
              message: String(bK)
            })
          }
        })()
      };
    OO.onmessage = OO => {
      let {
        data: FO
      } = OO;
      if ("texture" === FO.type) MO.set(FO.url, CO.pixelsOf(FO.bitmap));
      else if ("model" === FO.type) aK.set(FO.name, {
        geometry: FO.geometry,
        texture: CO.pixelsOf(FO.bitmap)
      });
      else if ("draw" === FO.type) {
        const {
          id: OO,
          top: CO,
          left: aK,
          right: VO,
          itemType: LO,
          size: QO,
          outlineWidth: zK
        } = FO;
        oO(OO, QO, (() => function(OO, eO, lO, vK) {
          const CO = .6 * lO,
            DO = CO * XO,
            MO = CO * XO * .5,
            aK = CO * bK,
            oO = Math.max(...eO.boxes.map((OO => OO[4]))),
            FO = DO / 2 + (lO - DO) / 2,
            VO = MO + (lO - MO - MO - oO * aK) / 2,
            LO = (OO, KO, pO) => ({
              x: FO + (OO - pO) * DO,
              y: VO - MO + (OO + pO) * MO + (oO - KO) * aK
            }),
            QO = (OO, KO, pO, XO, bK, lO) => ({
              origin: OO,
              across: {
                x: KO.x - OO.x,
                y: KO.y - OO.y
              },
              down: {
                x: pO.x - OO.x,
                y: pO.y - OO.y
              },
              texture: XO,
              rect: eO.cropFaces ? bK : [0, 0, 1, 1],
              shade: lO
            }),
            zK = new Uint8ClampedArray(lO * lO * 4),
            AO = new Uint8Array(lO * lO),
            fO = KO;
          for (const [KO, pO, XO, bK, dO, TO] of eO.boxes) {
            const eO = QO(LO(bK, dO, TO), LO(bK, dO, XO), LO(bK, pO, TO), OO.right, [1 - TO, 1 - dO, 1 - XO, 1 - pO], fO.right),
              vK = QO(LO(KO, dO, TO), LO(bK, dO, TO), LO(KO, pO, TO), OO.left, [KO, 1 - dO, bK, 1 - pO], fO.left),
              CO = QO(LO(KO, dO, XO), LO(bK, dO, XO), LO(KO, dO, TO), OO.top, [KO, XO, bK, TO], fO.top);
            for (const OO of [eO, vK, CO]) hO(zK, AO, lO, OO)
          }
          return pO(zK, lO, vK, (OO => 1 === AO[OO])), zK
        }({
          top: DO(MO, CO, "texture"),
          left: DO(MO, aK, "texture"),
          right: DO(MO, VO, "texture")
        }, function(OO) {
          return "SlabBlock" === OO ? lO : "StairsBlock" === OO ? vK : eO
        }(LO), QO, zK)))
      } else {
        const {
          id: OO,
          name: KO,
          size: XO,
          outlineWidth: bK
        } = FO;
        oO(OO, XO, (() => {
          const {
            geometry: OO,
            texture: eO
          } = DO(aK, KO, "model");
          return function(OO, KO, XO, bK) {
            const {
              vertices: eO,
              uvs: lO,
              indices: vK,
              shades: CO
            } = OO, hO = .03125 * XO, DO = XO - 2 * hO, MO = new Float32Array(eO.length);
            for (let pO = 0; pO < eO.length; pO += 3) MO[pO] = hO + eO[pO] * DO, MO[pO + 1] = hO + eO[pO + 1] * DO, MO[pO + 2] = eO[pO + 2];
            const aK = new Float32Array(XO * XO).fill(-1 / 0),
              oO = new Uint8ClampedArray(XO * XO * 4),
              FO = 255 * OO.alphaCutoff;
            for (let pO = 0; pO < vK.length; pO += 3) {
              const [OO, bK, eO] = [vK[pO], vK[pO + 1], vK[pO + 2]], [hO, DO, VO] = [3 * OO, 3 * bK, 3 * eO], [LO, QO, zK, AO, fO, dO] = [MO[hO], MO[hO + 1], MO[DO], MO[DO + 1], MO[VO], MO[VO + 1]], TO = (zK - LO) * (dO - QO) - (fO - LO) * (AO - QO);
              if (Math.abs(TO) < 1e-9) continue;
              const NO = CO[pO / 3],
                [IO, yK, gK, uO, EO, jK] = [lO[2 * OO], lO[2 * OO + 1], lO[2 * bK], lO[2 * bK + 1], lO[2 * eO], lO[2 * eO + 1]],
                YO = Math.max(0, Math.floor(Math.min(LO, zK, fO))),
                wO = Math.min(XO - 1, Math.ceil(Math.max(LO, zK, fO))),
                iK = Math.max(0, Math.floor(Math.min(QO, AO, dO))),
                rK = Math.min(XO - 1, Math.ceil(Math.max(QO, AO, dO)));
              for (let pO = iK; pO <= rK; pO++)
                for (let OO = YO; OO <= wO; OO++) {
                  const [bK, eO] = [OO + .5, pO + .5], lO = ((bK - LO) * (dO - QO) - (fO - LO) * (eO - QO)) / TO, vK = ((zK - LO) * (eO - QO) - (bK - LO) * (AO - QO)) / TO, CO = 1 - lO - vK;
                  if (CO < 0 || lO < 0 || vK < 0) continue;
                  const YO = CO * MO[hO + 2] + lO * MO[DO + 2] + vK * MO[VO + 2],
                    wO = pO * XO + OO;
                  if (YO <= aK[wO]) continue;
                  const iK = Math.max(0, Math.min(KO.width - 1, Math.floor((CO * IO + lO * gK + vK * EO) * KO.width))),
                    rK = 4 * (Math.max(0, Math.min(KO.height - 1, Math.floor((CO * yK + lO * uO + vK * jK) * KO.height))) * KO.width + iK);
                  KO.pixels[rK + 3] < FO || (aK[wO] = YO, oO[4 * wO] = KO.pixels[rK] * NO, oO[4 * wO + 1] = KO.pixels[rK + 1] * NO, oO[4 * wO + 2] = KO.pixels[rK + 2] * NO, oO[4 * wO + 3] = 255)
                }
            }
            return pO(oO, XO, bK), oO
          }(OO, eO, XO, bK)
        }))
      }
    }, OO.postMessage({
      type: "started"
    })
  }(globalThis, MO)
})();