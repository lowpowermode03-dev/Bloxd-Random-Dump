export const id = 234;
export const ids = [234, 333];
export const modules = {
  37907: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      static GetShadersRepository() {
        return 0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0) ? XO.ShadersRepository : XO.ShadersRepositoryWGSL
      }
      static GetShadersStore() {
        return 0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0) ? XO.ShadersStore : XO.ShadersStoreWGSL
      }
      static GetIncludesShadersStore() {
        return 0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0) ? XO.IncludesShadersStore : XO.IncludesShadersStoreWGSL
      }
    }
    XO.ShadersRepository = "src/Shaders/", XO.ShadersStore = {}, XO.IncludesShadersStore = {}, XO.ShadersRepositoryWGSL = "src/ShadersWGSL/", XO.ShadersStoreWGSL = {}, XO.IncludesShadersStoreWGSL = {}
  },
  59068: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      postprocessVertexShader: () => lO
    });
    var XO = pO(37907);
    const bK = "postprocessVertexShader",
      eO = "attribute vec2 position;uniform vec2 scale;varying vec2 vUV;const vec2 madd=vec2(0.5,0.5);\n#define CUSTOM_VERTEX_DEFINITIONS\nvoid main(void) {\n#define CUSTOM_VERTEX_MAIN_BEGIN\nvUV=(position*madd+madd)*scale;gl_Position=vec4(position,0.0,1.0);\n#define CUSTOM_VERTEX_MAIN_END\n}";
    XO.b.ShadersStore[bK] || (XO.b.ShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);