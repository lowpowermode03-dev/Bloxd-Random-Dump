export const id = 41;
export const ids = [41];
export const modules = {
  41349: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      MAX_LAYER_WIDTH: () => CO,
      PackTextures: () => AO,
      layerWidthFor: () => MO,
      packFileUrl: () => VO,
      packFilesOf: () => zK,
      packTerrainSources: () => LO,
      resheet: () => aK,
      webgl1GridColumns: () => hO,
      webgl1LayerWidth: () => DO
    });
    var XO = pO(38859),
      bK = pO(39047),
      eO = pO(41353),
      lO = pO(39035),
      vK = pO(41355);
    const CO = {
      webgpu: 128,
      webgl: 128,
      webgl1: 64
    };

    function hO(OO) {
      const KO = Math.ceil(Math.log2(Math.max(1, OO)));
      return 2 ** Math.ceil(KO / 2)
    }

    function DO(OO, KO, pO) {
      const bK = null !== pO && pO > 0 ? pO : XO.d.limits.MAX_TEXTURE_SIZE;
      return MO(Math.max(1, Math.floor(bK / hO(KO))), OO)
    }

    function MO(OO, KO) {
      let pO = 1;
      for (; 2 * pO <= Math.min(OO, KO);) pO *= 2;
      return pO
    }
    async function aK(OO, KO, pO, XO) {
      const bK = MO(KO, XO),
        eO = [];
      for (const MO of OO) eO.push(bK === KO ? MO : await FO(MO, KO, bK));
      const lO = bK * bK * 4,
        vK = bK * Math.max(0, ...pO),
        CO = pO.map((() => ({
          width: bK,
          height: vK,
          pixels: new Uint8Array(bK * vK * 4)
        })));
      let hO = 0,
        DO = 0;
      for (const MO of eO) {
        let OO = 0;
        const KO = Math.floor(MO.byteLength / lO);
        for (; OO < KO && hO < CO.length;) {
          const XO = Math.min(pO[hO] - DO, KO - OO);
          CO[hO].pixels.set(MO.subarray(OO * lO, (OO + XO) * lO), DO * lO), OO += XO, DO += XO, DO === pO[hO] && (hO++, DO = 0)
        }
      }
      return CO
    }
    const oO = 16;
    async function FO(OO, KO, pO) {
      const XO = Math.floor(OO.byteLength / (KO * KO * 4)),
        bK = new Uint8Array(pO * pO * 4 * XO),
        eO = [0, 0, 0, 0];
      for (let lO = 0; lO < XO; lO++) {
        lO > 0 && lO % oO === 0 && await new Promise((OO => {
          setTimeout(OO, 0)
        }));
        const XO = lO * KO;
        for (let vK = 0; vK < pO; vK++) {
          const CO = Math.floor(vK * KO / pO),
            hO = Math.max(CO + 1, Math.floor((vK + 1) * KO / pO));
          for (let DO = 0; DO < pO; DO++) {
            const MO = Math.floor(DO * KO / pO),
              aK = Math.max(MO + 1, Math.floor((DO + 1) * KO / pO));
            eO.fill(0);
            for (let pO = CO; pO < hO; pO++) {
              const bK = (XO + pO) * KO * 4;
              for (let KO = MO; KO < aK; KO++)
                for (let pO = 0; pO < 4; pO++) eO[pO] += OO[bK + 4 * KO + pO]
            }
            const oO = (hO - CO) * (aK - MO),
              FO = 4 * ((lO * pO + vK) * pO + DO);
            for (let OO = 0; OO < 4; OO++) bK[FO + OO] = Math.round(eO[OO] / oO)
          }
        }
      }
      return bK
    }

    function VO(OO, KO) {
      return "string" !== typeof OO || "" === OO ? null : "player" === KO || (0, eO.d)(OO) ? OO : null
    }
    async function LO(OO, KO, XO) {
      const eO = await pO.e(187).then((() => pO(33017)));
      let vK = null;
      return {
        atlasSheets: [],
        texture: KO => {
          var pO, lO, vK;
          return null !== (pO = null !== (lO = null !== (vK = VO(OO.terrain.texture(KO), XO)) && void 0 !== vK ? vK : eO.animatedBlockTextures[KO]) && void 0 !== lO ? lO : eO.rotatedBlockTextures[KO]) && void 0 !== pO ? pO : function(OO, KO, pO) {
            var XO, eO;
            const lO = null !== (XO = bK.b[OO]) && void 0 !== XO ? XO : null;
            return null === lO ? null : null !== (eO = VO(KO.texture(OO), pO)) && void 0 !== eO ? eO : lO
          }(KO, OO, XO)
        },
        decoded: pO => {
          const bK = (0, lO.g)(pO);
          return null === bK ? null : (vK ??= (async () => {
            const pO = await Promise.all(OO.terrain.atlasSheets.map((async (KO, pO) => {
              const bK = OO.sheetPixels[pO];
              if (bK) return new Uint8Array(bK.buffer, bK.byteOffset, bK.byteLength);
              const eO = VO(KO, XO);
              if (null === eO) throw new Error(`the pack's atlas sheet ${pO} isn't a pack file`);
              return (await (0, lO.k)(eO)).pixels
            })));
            return OO.sheetPixels.fill(null), aK(pO, OO.sheetWidth, eO.imagesPerAtlas, KO)
          })(), vK).then((OO => {
            const KO = OO.at(bK);
            if (void 0 === KO) throw new Error(`the built atlas has no sheet ${bK}`);
            return KO
          }))
        }
      }
    }
    const QO = new WeakMap;

    function zK(OO, KO) {
      if (null === OO) return null;
      let pO = QO.get(OO);
      void 0 === pO && (pO = {}, QO.set(OO, pO));
      const XO = pO[KO];
      if (void 0 !== XO) return XO;
      const {
        armourAtlasUrl: bK,
        texture: eO,
        model: lO
      } = OO, vK = {
        armourAtlasUrl: () => VO(bK, KO),
        textureUrl: OO => VO(eO(OO), KO),
        modelUrl: OO => VO(lO(OO), KO)
      };
      return pO[KO] = vK, vK
    }
    class AO {
      constructor(OO) {
        this.host = OO, this.assets = null, this.owner = "player", this.latest = 0, this.swapping = 0, this.ended = !1, this.maxWidth = null
      }
      maxLayerWidth() {
        return this.maxWidth ??= (async (OO, KO, XO) => {
          const {
            backend: bK
          } = this.host, eO = CO[bK];
          if ("webgl1" !== bK) return eO;
          const [lO, vK] = await Promise.all([pO.e(187).then((() => pO(33017))), null !== (OO = null === (KO = (XO = this.host).maxTextureSize) || void 0 === KO ? void 0 : KO.call(XO)) && void 0 !== OO ? OO : null]);
          return DO(eO, lO.imagesPerAtlas.length * Math.max(0, ...lO.imagesPerAtlas), vK)
        })().catch((OO => {
          throw this.maxWidth = null, OO
        })), this.maxWidth
      }
      files() {
        return zK(this.assets, this.owner)
      }
      iconOverrides() {
        const OO = this.files();
        return null === OO ? null : {
          itemSprite: OO.textureUrl,
          blockTexture: OO.textureUrl,
          model: OO.modelUrl
        }
      }
      start() {
        const OO = this.host.feed.subscribe((OO => {
          const KO = ++this.latest;
          this.host.settling(), this.assetsFor(OO).then((pO => this.apply(KO, pO, OO).catch((OO => {
            this.host.warn("the texture pack landed, but reloading what it overrides failed", OO)
          }))), (pO => {
            this.host.warn("the texture pack's atlas couldn't be generated: the textures in stay", pO), this.settled(KO, OO, null, !0)
          }))
        }));
        return () => {
          OO(), this.latest++, this.ended = !0
        }
      }
      async apply(OO, KO, pO) {
        const {
          host: XO
        } = this;
        if (OO !== this.latest || XO.stopped()) return;
        const bK = (0, eO.l)(pO);
        if (this.texturesIn(KO, bK) && 0 === this.swapping) return void this.settled(OO, pO, zK(KO, bK));
        let vK;
        this.swapping++;
        try {
          vK = await XO.terrain.swap((OO => {
            var KO;
            XO.warn(`texture pack texture ${null!==(KO=OO.name)&&void 0!==KO?KO:"(all)"} failed`, OO.error)
          }), (async () => XO.sourcesOf ? XO.sourcesOf(KO) : null === KO ? (0, lO.h)() : LO(KO, await this.maxLayerWidth(), bK)), {
            wholeAtlas: null !== KO,
            wanted: () => OO === this.latest
          })
        } catch (CO) {
          return XO.warn("the texture pack's swap failed: the textures in stay", CO), void this.settled(OO, pO, null, !0)
        } finally {
          this.swapping--
        }
        if (!0 !== vK || this.ended) this.settled(OO, pO, null, !0);
        else {
          XO.landed(), this.assets = KO, this.owner = bK;
          try {
            XO.packSwapped()
          } finally {
            this.settled(OO, pO, this.files())
          }
        }
      }
      async assetsFor(OO) {
        var KO;
        return (null !== (KO = this.host.assetsOf) && void 0 !== KO ? KO : vK.g)(OO, await this.maxLayerWidth())
      }
      texturesIn(OO, KO) {
        return OO === this.assets && (null === OO || KO === this.owner)
      }
      settled(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        OO !== this.latest || this.ended || this.host.stopped() || this.host.settled(KO, pO, XO)
      }
    }
  },
  41363: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      followPagePackFiles: () => eO
    });
    var XO = pO(41349),
      bK = pO(41355);

    function eO(OO, KO, pO, eO, lO) {
      let vK, CO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : OO => (0, bK.g)(OO, XO.MAX_LAYER_WIDTH[pO]),
        hO = 0,
        DO = null;
      const MO = () => {
          if (null === DO || null !== DO.gameSource && !KO.showsPage()) return;
          const pO = null === DO.gameSource ? DO : OO.playerState();
          if (pO.pack === vK) return;
          vK = pO.pack;
          const bK = ++hO;
          CO(pO).then((OO => {
            bK === hO && eO((0, XO.packFilesOf)(OO, "player"))
          }), (OO => {
            bK === hO && (vK = void 0), lO("the texture pack's files couldn't be had for the previews: the files in stay", OO)
          }))
        },
        aK = OO.subscribe((OO => {
          DO = OO, MO()
        })),
        oO = OO.onPlayerPackChange(MO),
        FO = KO.onPageShown(MO);
      return () => {
        aK(), oO(), FO(), hO++
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);