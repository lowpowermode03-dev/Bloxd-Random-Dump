export const id = 25;
export const ids = [25];
export const modules = {
  37761: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => vK
    });
    var XO = pO(8333);
    const bK = 1e3 / 3;

    function eO(OO, KO, pO) {
      if ("parenthetical-seconds" === KO) return ` (${OO}s)`;
      const XO = `${Math.floor(OO/60)}:${(OO%60).toString().padStart(2,"0")}`;
      return pO ? `${pO}${XO}` : XO
    }

    function lO(OO, KO, pO, bK, eO) {
      var lO;
      const vK = {
        ...bK.baseNametag
      };
      vK.content = [...null !== (lO = bK.baseNametag.content) && void 0 !== lO ? lO : [], {
        str: " "
      }, {
        icon: "Gold Coin"
      }, {
        str: `: ${(0,XO.c)(eO)}`
      }], OO.setOtherEntitySetting(KO, pO, "nameTagInfo", vK)
    }
    const vK = function(OO, KO, pO, XO) {
      let vK, {
        localPlayerId: CO
      } = XO;
      const hO = new Map,
        DO = new Map;
      let MO = 0,
        aK = 0;
      return {
        onCreate: OO => {
          vK = OO
        },
        KK: OO => {
          const KO = Date.now();
          for (const [XO, bK] of hO) {
            const OO = Math.floor((KO - bK.startTime) / 1e3),
              lO = Math.max(0, bK.remainingSeconds - OO);
            if (lO === bK.lastRenderedSecond) continue;
            bK.lastRenderedSecond = lO;
            const DO = {
                str: eO(lO, bK.format, bK.prefix),
                style: bK.style
              },
              MO = {
                ...bK.baseNametag
              };
            var pO;
            if ("content" === bK.location) MO.content = [...null !== (pO = bK.baseNametag.content) && void 0 !== pO ? pO : [], DO];
            else MO.subtitle = [DO];
            vK.setOtherEntitySetting(CO, XO, "nameTagInfo", MO), lO <= 0 && hO.delete(XO)
          }
          if (DO.size > 0 && KO - MO >= bK) {
            MO = KO, aK = (aK + 1) % 3;
            let OO = 0;
            for (const [pO, XO] of DO) {
              if (OO++ % 3 !== aK) continue;
              const bK = Math.floor((KO - XO.startTime) / 1e3);
              if (bK === XO.lastRenderedSecond) continue;
              XO.lastRenderedSecond = bK;
              const eO = XO.accumulatedIncome + XO.incomePerSecond * BigInt(bK);
              lO(vK, CO, pO, XO, eO)
            }
          }
        },
        onReceivedMessageFromServer: (OO, KO) => {
          if ("startCountdown" === OO) hO.set(KO.eId, {
            baseNametag: KO.baseNametag,
            remainingSeconds: KO.remainingSeconds,
            startTime: Date.now(),
            format: KO.format,
            location: KO.location,
            prefix: KO.prefix,
            style: KO.style,
            lastRenderedSecond: -1
          });
          else if ("stopCountdown" === OO) hO.delete(KO.eId);
          else if ("startIncomeTicking" === OO) {
            const OO = {
              baseNametag: KO.baseNametag,
              accumulatedIncome: BigInt(KO.accumulatedIncome),
              incomePerSecond: BigInt(KO.incomePerSecond),
              startTime: Date.now(),
              lastRenderedSecond: -1
            };
            DO.set(KO.eId, OO), lO(vK, CO, KO.eId, OO, OO.accumulatedIncome)
          } else "stopIncomeTicking" === OO && DO.delete(KO.eId) && vK.setOtherEntitySetting(CO, KO.eId, "nameTagInfo", {
            content: []
          })
        },
        onPlayerAltAction: (OO, KO, pO, XO, bK, eO) => {
          if (eO && "Mesh" === vK.getEntityType(eO)) {
            const KO = vK.getEntityName(eO);
            "Upgrades" === KO ? vK.openShop(OO, !1, "Upgrades") : "Items" === KO ? vK.openShop(OO, !1, "Items") : "Prestige" === KO ? vK.openShop(OO, !1, "Prestige") : "Collections" === KO ? vK.openShop(OO, !1, "Collections") : "Base Skins" === KO ? vK.openShop(OO, !1, "Base Skins") : "Gauntlet" === KO ? vK.openShop(OO, !1, "Gauntlet") : "Diamond Shop" === KO && vK.openShop(OO, !1, "Diamond Shop")
          }
        }
      }
    }
  },
  8333: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => lO
    });
    const XO = [{
      threshold: 10n ** 180n,
      suffix: "NoQig"
    }, {
      threshold: 10n ** 177n,
      suffix: "OcQig"
    }, {
      threshold: 10n ** 174n,
      suffix: "SpQig"
    }, {
      threshold: 10n ** 171n,
      suffix: "SQig"
    }, {
      threshold: 10n ** 168n,
      suffix: "QiQig"
    }, {
      threshold: 10n ** 165n,
      suffix: "QaQig"
    }, {
      threshold: 10n ** 162n,
      suffix: "TQig"
    }, {
      threshold: 10n ** 159n,
      suffix: "DQig"
    }, {
      threshold: 10n ** 156n,
      suffix: "UQig"
    }, {
      threshold: 10n ** 153n,
      suffix: "Qig"
    }, {
      threshold: 10n ** 150n,
      suffix: "NoQag"
    }, {
      threshold: 10n ** 147n,
      suffix: "OcQag"
    }, {
      threshold: 10n ** 144n,
      suffix: "SpQag"
    }, {
      threshold: 10n ** 141n,
      suffix: "SQag"
    }, {
      threshold: 10n ** 138n,
      suffix: "QiQag"
    }, {
      threshold: 10n ** 135n,
      suffix: "QaQag"
    }, {
      threshold: 10n ** 132n,
      suffix: "TQag"
    }, {
      threshold: 10n ** 129n,
      suffix: "DQag"
    }, {
      threshold: 10n ** 126n,
      suffix: "UQag"
    }, {
      threshold: 10n ** 123n,
      suffix: "Qag"
    }, {
      threshold: 10n ** 120n,
      suffix: "NoTg"
    }, {
      threshold: 10n ** 117n,
      suffix: "OcTg"
    }, {
      threshold: 10n ** 114n,
      suffix: "SpTg"
    }, {
      threshold: 10n ** 111n,
      suffix: "STg"
    }, {
      threshold: 10n ** 108n,
      suffix: "QiTg"
    }, {
      threshold: 10n ** 105n,
      suffix: "QaTg"
    }, {
      threshold: 10n ** 102n,
      suffix: "TTg"
    }, {
      threshold: 10n ** 99n,
      suffix: "DTg"
    }, {
      threshold: 10n ** 96n,
      suffix: "UTg"
    }, {
      threshold: 10n ** 93n,
      suffix: "Tg"
    }, {
      threshold: 10n ** 90n,
      suffix: "NoVg"
    }, {
      threshold: 10n ** 87n,
      suffix: "OcVg"
    }, {
      threshold: 10n ** 84n,
      suffix: "SpVg"
    }, {
      threshold: 10n ** 81n,
      suffix: "SVg"
    }, {
      threshold: 10n ** 78n,
      suffix: "QiVg"
    }, {
      threshold: 10n ** 75n,
      suffix: "QaVg"
    }, {
      threshold: 10n ** 72n,
      suffix: "TVg"
    }, {
      threshold: 10n ** 69n,
      suffix: "DVg"
    }, {
      threshold: 10n ** 66n,
      suffix: "UVg"
    }, {
      threshold: 10n ** 63n,
      suffix: "Vg"
    }, {
      threshold: 10n ** 60n,
      suffix: "NoD"
    }, {
      threshold: 10n ** 57n,
      suffix: "OcD"
    }, {
      threshold: 10n ** 54n,
      suffix: "SpD"
    }, {
      threshold: 10n ** 51n,
      suffix: "SD"
    }, {
      threshold: 10n ** 48n,
      suffix: "QiD"
    }, {
      threshold: 10n ** 45n,
      suffix: "QaD"
    }, {
      threshold: 10n ** 42n,
      suffix: "TD"
    }, {
      threshold: 10n ** 39n,
      suffix: "DD"
    }, {
      threshold: 10n ** 36n,
      suffix: "UD"
    }, {
      threshold: 10n ** 33n,
      suffix: "D"
    }, {
      threshold: 10n ** 30n,
      suffix: "No"
    }, {
      threshold: 10n ** 27n,
      suffix: "Oc"
    }, {
      threshold: 10n ** 24n,
      suffix: "Sep"
    }, {
      threshold: 10n ** 21n,
      suffix: "S"
    }, {
      threshold: 10n ** 18n,
      suffix: "Qi"
    }, {
      threshold: 10n ** 15n,
      suffix: "Qa"
    }, {
      threshold: 10n ** 12n,
      suffix: "T"
    }, {
      threshold: 10n ** 9n,
      suffix: "B"
    }, {
      threshold: 10n ** 6n,
      suffix: "M"
    }, {
      threshold: 1000n,
      suffix: "K"
    }];

    function bK(OO) {
      let KO, pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 3;
      if ("number" === typeof OO) {
        if (!Number.isFinite(OO)) return "0";
        if (Math.abs(OO) < 100) {
          const KO = OO < 0 ? "-" : "",
            pO = Math.abs(OO);
          return pO >= 10 ? `${KO}${pO.toFixed(1).replace(/\.0$/,"")}` : `${KO}${pO.toFixed(2).replace(/\.?0+$/,"")}`
        }
        KO = BigInt(Math.floor(OO))
      } else KO = OO;
      const bK = KO < 0n ? -KO : KO,
        eO = KO < 0n ? "-" : "",
        lO = bK.toString();
      if (lO.length <= pO) return `${eO}${lO}`;
      const vK = 3 * Math.floor((lO.length - 1) / 3);
      if (vK < 3) return `${eO}${lO}`;
      if (vK > 3 * XO.length) {
        const OO = lO[0],
          KO = lO.slice(1, 3).replace(/0+$/, "");
        return `${eO}${KO?`${OO}.${KO}`:OO}e${lO.length-1}`
      }
      const {
        threshold: CO,
        suffix: hO
      } = XO[XO.length - vK / 3], DO = bK / CO, MO = Number(1000n * (bK % CO) / CO), aK = Number(DO) + MO / 1e3;
      let oO;
      return oO = aK >= 100 ? Math.floor(aK).toString() : aK >= 10 ? aK.toFixed(1).replace(/\.0$/, "") : aK.toFixed(2).replace(/\.?0+$/, ""), `${eO}${oO}${hO}`
    }
    const eO = XO.map((OO => {
      let {
        threshold: KO,
        suffix: pO
      } = OO;
      return {
        threshold: Number(KO),
        suffix: pO
      }
    })).filter((OO => {
      let {
        threshold: KO
      } = OO;
      return Number.isFinite(KO)
    }));

    function lO(OO) {
      const KO = Math.abs(OO),
        pO = OO < 0 ? "-" : "";
      for (const {
          threshold: XO,
          suffix: bK
        }
        of eO)
        if (KO >= XO) {
          const OO = KO / XO;
          if (OO >= 1e3) return `${pO}${KO.toExponential(2).replace("e+","e")}`;
          let eO;
          return eO = OO >= 100 ? Math.floor(OO).toString() : OO >= 10 ? OO.toFixed(1).replace(/\.0$/, "") : OO.toFixed(2).replace(/\.?0+$/, ""), `${pO}${eO}${bK}`
        } return `${pO}${KO}`
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);