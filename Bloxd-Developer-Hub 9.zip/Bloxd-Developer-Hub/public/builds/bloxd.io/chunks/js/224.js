export const id = 224;
export const ids = [224];
export const modules = {
  36892: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO
    });
    var XO = pO(36895);
    const bK = [0, 0, 0];
    class eO {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : bK;
        this.pool = OO, this.origin = KO, this.count = 0, this.free = []
      }
      take() {
        var OO;
        const KO = null !== (OO = this.free.pop()) && void 0 !== OO ? OO : this.count++;
        return KO >= this.pool.YO && this.pool.grow(Math.max(2 * this.pool.YO, KO + 1)), this.hide(KO), KO
      }
      release(OO) {
        this.hide(OO), this.free.push(OO)
      }
      write(OO, KO, pO, bK) {
        const {
          records: eO
        } = this.pool, {
          origin: lO
        } = this, vK = OO * XO.d;
        eO[vK] = KO - lO[0], eO[vK + 1] = pO - lO[1], eO[vK + 2] = bK - lO[2], eO[vK + XO.h] = 0, this.pool.markDirty(OO)
      }
      hide(OO) {
        this.pool.records[OO * XO.d + XO.h] = 1, this.pool.markDirty(OO)
      }
      commit() {
        this.pool.commit(this.count)
      }
      dispose() {
        this.pool.dispose()
      }
    }
    class lO {
      constructor(OO, KO, pO) {
        this.api = OO, this.model = KO, this.initialCapacity = pO, this.kinds = new Map, this.origin = [0, 0, 0]
      }
      kindOf(OO) {
        let KO = this.kinds.get(OO);
        if (void 0 === KO) {
          const pO = this.api.createInstancePool({
            ...this.model,
            item: OO
          }, this.initialCapacity);
          null === pO || void 0 === pO || pO.setOrigin(this.origin[0], this.origin[1], this.origin[2]), KO = pO && new eO(pO, this.origin), this.kinds.set(OO, KO)
        }
        return KO
      }
      follow(OO) {
        const {
          origin: KO
        } = this;
        if (Math.abs(OO[0] - KO[0]) <= 512 && Math.abs(OO[1] - KO[1]) <= 512 && Math.abs(OO[2] - KO[2]) <= 512) return !1;
        KO[0] = Math.floor(OO[0]), KO[1] = Math.floor(OO[1]), KO[2] = Math.floor(OO[2]);
        for (const pO of this.kinds.values()) null === pO || void 0 === pO || pO.pool.setOrigin(KO[0], KO[1], KO[2]);
        return !0
      }
      commit() {
        for (const OO of this.kinds.values()) null === OO || void 0 === OO || OO.commit()
      }
      dispose() {
        for (const OO of this.kinds.values()) null === OO || void 0 === OO || OO.dispose();
        this.kinds.clear()
      }
    }
  },
  36904: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO,
      f: () => vK,
      g: () => CO
    });
    const XO = [1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1],
      bK = [0, 1, 2, 0, 2, 3],
      eO = [4, 5];

    function lO(OO, KO, pO, XO, bK) {
      for (let lO = 0; lO < 6; lO++) eO.includes(lO) === bK && hO(OO, KO, pO, XO, lO)
    }

    function vK(OO, KO, pO, XO) {
      for (let bK = 0; bK < 6; bK++) hO(OO, KO, pO, XO, bK)
    }

    function CO(OO, KO, pO, eO, lO) {
      for (let vK = 0; vK < 6; vK++)
        for (const CO of [0, 1]) {
          const [hO, DO, MO] = [CO + 2, CO + 1, (CO + 3) % 4], aK = OO.length / 3;
          for (const [KO, bK] of [
              [CO, DO],
              [hO, DO],
              [hO, MO],
              [CO, MO]
            ])
            for (let CO = 0; CO < 3; CO++) {
              const hO = XO[3 * (4 * vK + KO) + CO],
                DO = XO[3 * (4 * vK + bK) + CO];
              OO.push((hO + (DO - hO) * lO) * eO / 2 + pO[CO])
            }
          for (const OO of bK) KO.push(aK + OO)
        }
    }

    function hO(OO, KO, pO, eO, lO) {
      let [vK, CO, hO] = pO, [DO, MO, aK] = eO;
      const oO = OO.length / 3;
      for (let bK = 4 * lO; bK < 4 * lO + 4; bK++) OO.push(XO[3 * bK] * DO / 2 + vK, XO[3 * bK + 1] * MO / 2 + CO, XO[3 * bK + 2] * aK / 2 + hO);
      for (const XO of bK) KO.push(oO + XO)
    }
  },
  36883: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => pz
    });
    var XO = pO(63);
    const bK = [{
        nameKey: "tierBurner",
        cost: [],
        islandRadius: 11.5,
        machineAllowance: 16,
        beltAllowance: 64,
        newDeposits: [],
        unlocks: [],
        reward: null
      }, {
        nameKey: "tierCurrent",
        cost: [{
          item: "Iron Bar",
          amount: 40
        }, {
          item: "Glass",
          amount: 12
        }, {
          item: "Copper Bar",
          amount: 10
        }],
        islandRadius: 17,
        machineAllowance: 40,
        beltAllowance: 256,
        newDeposits: [{
          block: "Copper Deposit",
          offset: [-14, 0, 4]
        }],
        unlocks: ["Parts Bench", "Generator", "Wire Mill", "Press", "Motor", "Splitter", "Recycler", "Belt Lift", "Belt Drop", "Crop Harvester", "Iron Hammer"],
        reward: null
      }, {
        nameKey: "tierPrecision",
        cost: [{
          item: "Motor",
          amount: 8
        }, {
          item: "Copper Wire",
          amount: 32
        }, {
          item: "Iron Plate",
          amount: 32
        }, {
          item: "Gold Bar",
          amount: 4
        }, {
          item: "Relay Coil",
          amount: 2
        }],
        islandRadius: 24,
        machineAllowance: 80,
        beltAllowance: 384,
        newDeposits: [{
          block: "Gold Deposit",
          offset: [16, 0, -14]
        }, {
          block: "Coal Deposit",
          offset: [-20, 0, 10]
        }],
        unlocks: ["Alloy Kiln", "Electric Drill", "Assembler", "Power Coupler", "Sorting Gate", "Belt Loader", "Storage Silo", "Solar Panel", "Logic Board", "Machine Hull", "Ore Lens", "Vein Breaker", "Arc Caster"],
        reward: null
      }, {
        nameKey: "tierVoltaic",
        cost: [{
          item: "Logic Board",
          amount: 12
        }, {
          item: "Steel Bar",
          amount: 48
        }, {
          item: "Motor",
          amount: 16
        }, {
          item: "Raw Voltite",
          amount: 8
        }, {
          item: "Diamond",
          amount: 2
        }],
        islandRadius: 32,
        machineAllowance: 140,
        beltAllowance: 512,
        newDeposits: [{
          block: "Iron Deposit",
          offset: [-22, 0, -20]
        }, {
          block: "Voltite Deposit",
          offset: [26, 0, 12]
        }],
        unlocks: ["Volt Engine", "Deep Drill", "Shatter Mill", "Sky Tap", "Fast Belt", "Charging Pad", "Voltite Cell", "Sky Pack", "Charge Vault", "Homing Beacon", "Pull Charm"],
        reward: null
      }, {
        nameKey: "tierStarforge",
        cost: [{
          item: "Voltite Cell",
          amount: 12
        }, {
          item: "Logic Board",
          amount: 16
        }, {
          item: "Machine Hull",
          amount: 8
        }, {
          item: "Steel Bar",
          amount: 128
        }, {
          item: "Moonstone",
          amount: 4
        }, {
          item: "Diamond",
          amount: 4
        }],
        islandRadius: 42,
        machineAllowance: 220,
        beltAllowance: 768,
        newDeposits: [{
          block: "Copper Deposit",
          offset: [30, 0, 22]
        }, {
          block: "Stone Deposit",
          offset: [-36, 0, 8]
        }],
        unlocks: ["Crystal Vat", "Star Alloy", "Comet Core", "Starbore Drill", "Voltplate Helmet", "Voltplate Chestplate", "Voltplate Gauntlets", "Voltplate Leggings", "Voltplate Boots"],
        reward: null
      }, {
        nameKey: "tierStage1",
        stage: 1,
        cost: [{
          item: "Star Alloy",
          amount: 8
        }, {
          item: "Machine Hull",
          amount: 20
        }, {
          item: "Comet Core",
          amount: 1
        }],
        charge: {
          items: [{
            item: "Steel Bar",
            amount: 60
          }],
          powerPerS: 0,
          seconds: 90
        },
        islandRadius: 46,
        machineAllowance: 248,
        beltAllowance: 912,
        newDeposits: [],
        unlocks: ["Belt Tunnel"],
        reward: null
      }, {
        nameKey: "tierStage2",
        stage: 2,
        cost: [{
          item: "Star Alloy",
          amount: 12
        }, {
          item: "Diamond",
          amount: 6
        }, {
          item: "Voltite Cell",
          amount: 32
        }, {
          item: "Comet Core",
          amount: 1
        }],
        charge: {
          items: [{
            item: "Iron Plate",
            amount: 60
          }, {
            item: "Copper Wire",
            amount: 120
          }],
          powerPerS: 0,
          seconds: 90
        },
        islandRadius: 50,
        machineAllowance: 280,
        beltAllowance: 1072,
        newDeposits: [{
          block: "Gold Deposit",
          offset: [-8, 0, 46]
        }],
        unlocks: [],
        reward: "Iron Trophy"
      }, {
        nameKey: "tierStage3",
        stage: 3,
        cost: [{
          item: "Star Alloy",
          amount: 16
        }, {
          item: "Logic Board",
          amount: 48
        }, {
          item: "Motor",
          amount: 32
        }, {
          item: "Comet Core",
          amount: 2
        }],
        charge: {
          items: [{
            item: "Logic Board",
            amount: 20
          }],
          powerPerS: 0,
          seconds: 120
        },
        islandRadius: 54,
        machineAllowance: 316,
        beltAllowance: 1248,
        newDeposits: [],
        unlocks: [],
        reward: "Gold Trophy"
      }, {
        nameKey: "tierStage4",
        stage: 4,
        cost: [{
          item: "Star Alloy",
          amount: 24
        }, {
          item: "Diamond",
          amount: 12
        }, {
          item: "Moonstone",
          amount: 8
        }, {
          item: "Comet Core",
          amount: 2
        }],
        charge: {
          items: [{
            item: "Voltite Cell",
            amount: 20
          }],
          powerPerS: 200,
          seconds: 120
        },
        islandRadius: 58,
        machineAllowance: 356,
        beltAllowance: 1440,
        newDeposits: [],
        unlocks: [],
        reward: "Diamond Trophy"
      }, {
        nameKey: "tierStage5",
        stage: 5,
        cost: [{
          item: "Star Alloy",
          amount: 32
        }, {
          item: "Voltite Cell",
          amount: 64
        }, {
          item: "Machine Hull",
          amount: 20
        }, {
          item: "Comet Core",
          amount: 3
        }],
        charge: {
          items: [{
            item: "Star Alloy",
            amount: 10
          }, {
            item: "Voltite Cell",
            amount: 10
          }, {
            item: "Steel Bar",
            amount: 60
          }],
          powerPerS: 300,
          seconds: 120
        },
        islandRadius: 62,
        machineAllowance: 400,
        beltAllowance: 1648,
        newDeposits: [],
        unlocks: ["Forge Hopper", "Starframe"],
        reward: "Moonstone Trophy"
      }, {
        nameKey: "tierIsotope",
        reactorTier: 1,
        cost: [{
          item: "Uranium Grit",
          amount: 256
        }, {
          item: "Star Alloy",
          amount: 8
        }, {
          item: "Comet Core",
          amount: 3
        }, {
          item: "Glass",
          amount: 16
        }],
        charge: {
          items: [{
            item: "Uranium Grit",
            amount: 24
          }, {
            item: "Star Alloy",
            amount: 4
          }],
          powerPerS: 200,
          seconds: 180
        },
        islandRadius: 66,
        machineAllowance: 448,
        beltAllowance: 1872,
        newDeposits: [{
          block: "Uranium Deposit",
          offset: [45, 0, 44]
        }, {
          block: "Uranium Deposit",
          offset: [-44, 0, -45]
        }],
        unlocks: ["Atomic Bench", "Condenser", "Fluid Pipe", "Fluid Tank", "Centrifuge", "Heat Exchanger", "Synthesizer", "Containment Plate", "Battery Cell"],
        reward: null
      }, {
        nameKey: "tierFission",
        reactorTier: 2,
        cost: [{
          item: "Uranium Pellet",
          amount: 16
        }, {
          item: "Heat Exchanger",
          amount: 8
        }, {
          item: "Star Alloy",
          amount: 16
        }, {
          item: "Comet Core",
          amount: 2
        }],
        charge: {
          items: [{
            item: "Uranium Pellet",
            amount: 6
          }],
          powerPerS: 300,
          seconds: 120
        },
        islandRadius: 70,
        machineAllowance: 500,
        beltAllowance: 2112,
        newDeposits: [{
          block: "Uranium Deposit",
          offset: [0, 0, 67]
        }],
        unlocks: ["Graphite Block", "Fuel Rod", "Coolant Channel", "Reactor Frame", "Reactor Glass", "Reactor Port", "Jet Chestplate", "Mob Farm", "Mob Cage"],
        reward: null
      }, {
        nameKey: "tierCritical",
        reactorTier: 3,
        cost: [{
          item: "Uranium Pellet",
          amount: 24
        }, {
          item: "Spent Pellet",
          amount: 8
        }, {
          item: "Star Alloy",
          amount: 24
        }, {
          item: "Comet Core",
          amount: 3
        }],
        charge: {
          items: [{
            item: "Uranium Pellet",
            amount: 4
          }],
          powerPerS: 2e3,
          seconds: 120
        },
        islandRadius: 74,
        machineAllowance: 556,
        beltAllowance: 2368,
        newDeposits: [{
          block: "Uranium Deposit",
          offset: [71, 0, 0]
        }],
        unlocks: ["Express Belt", "Fast Loader", "Advanced Coupler", "Dense Silo", "Uranium Glass", "Glow Lamp", "Reactor Blueprint", "Coolant Mixer"],
        reward: null
      }, {
        nameKey: "tierCollider",
        reactorTier: 4,
        cost: [{
          item: "Plutonium Pellet",
          amount: 2
        }, {
          item: "Battery Cell",
          amount: 4
        }, {
          item: "Star Alloy",
          amount: 16
        }, {
          item: "Glow Dust",
          amount: 16
        }, {
          item: "Comet Core",
          amount: 3
        }],
        charge: {
          items: [{
            item: "Glow Dust",
            amount: 4
          }],
          powerPerS: 1e4,
          seconds: 120
        },
        islandRadius: 78,
        machineAllowance: 616,
        beltAllowance: 2640,
        newDeposits: [{
          block: "Uranium Deposit",
          offset: [53, 0, -53]
        }],
        unlocks: ["Collider", "Laser", "Focus Lens", "Wireless Terminal", "Comet Beacon"],
        reward: null
      }, {
        nameKey: "tierNovaCore",
        reactorTier: 5,
        cost: [{
          item: "Nova Matter",
          amount: 8
        }, {
          item: "Uranium Pellet",
          amount: 32
        }, {
          item: "Plutonium Pellet",
          amount: 6
        }, {
          item: "Comet Core",
          amount: 3
        }],
        charge: {
          items: [{
            item: "Spent Pellet",
            amount: 4
          }, {
            item: "Plutonium Pellet",
            amount: 1
          }],
          powerPerS: 1e4,
          seconds: 120
        },
        islandRadius: 80,
        machineAllowance: 680,
        beltAllowance: 2928,
        newDeposits: [],
        unlocks: ["Nova Helmet", "Nova Chestplate", "Nova Gauntlets", "Nova Leggings", "Nova Boots", "Nova Blade", "Nova Jet Chestplate", "Nova Multitool", "Nova Coupler", "Pocket Terminal", "Atomic Bomb", "Nova Wrench"],
        reward: "Deposit Seed (Uranium)"
      }],
      eO = 10;
    let lO = !0;

    function vK() {
      return lO
    }

    function CO(OO) {
      lO = OO
    }
    const hO = {
      11: "uraniumLine",
      12: "centrifuge",
      13: "reactorOnline",
      14: "cryoCoolant",
      15: "moreLasers"
    };

    function DO() {
      return lO ? bK.length : eO
    }

    function MO(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = bK[OO - 1]) || void 0 === pO ? void 0 : pO.reactorTier) && void 0 !== KO ? KO : 0
    }

    function aK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : MO(OO) > 0;
      return pO && !lO ? "hidden" : OO <= KO ? "open" : pO ? KO < 5 ? "hidden" : KO < eO ? "teaser" : "locked" : "locked"
    }

    function oO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      const {
        kind: XO,
        n: bK
      } = LO(OO);
      return {
        key: KO[XO],
        params: {
          [XO]: pO ? String(bK) : bK
        }
      }
    }
    const FO = {
      tier: "coreTierName",
      stage: "coreStageName",
      atomic: "coreAtomicName"
    };

    function VO(OO, KO) {
      return MO(OO) > 0 && KO < eO
    }

    function LO(OO) {
      const KO = MO(OO);
      if (KO > 0) return {
        kind: "atomic",
        n: KO,
        short: `A${KO}`
      };
      const pO = function(OO) {
        return OO >= 6 && OO <= 10 ? OO - 6 + 1 : 0
      }(OO);
      return pO > 0 ? {
        kind: "stage",
        n: pO,
        short: `S${pO}`
      } : {
        kind: "tier",
        n: OO,
        short: String(OO)
      }
    }

    function QO(OO) {
      return bK[Math.max(1, Math.min(OO, bK.length)) - 1]
    }

    function zK(OO, KO) {
      return OO < KO ? function(OO) {
        var KO;
        return null !== (KO = bK[OO]) && void 0 !== KO ? KO : null
      }(OO) : null
    }
    const AO = "baf2coresubmit",
      fO = "baf2corebankpause",
      dO = "baf2coredeposit",
      TO = "baf2corechargepause";

    function NO(OO) {
      var KO;
      return null !== (KO = OO.baf2CoreOpen) && void 0 !== KO ? KO : eO
    }
    const IO = ["Machine Bench", "Parts Bench", "Tool Bench", "Atomic Bench"];

    function yK(OO) {
      return IO.includes(OO)
    }
    const gK = (OO, KO) => KO.map((KO => [KO, [OO]])),
      uO = Object.fromEntries([...gK("Furnace", ["Iron Bar", "Gold Bar", "Copper Bar"]), ...gK("Workbench", ["Machine Bench", "Parts Bench", "Tool Bench", "Atomic Bench"]), ...gK("Machine Bench", ["Burner Drill", "Crusher", "Smelter", "Conveyor Belt", "Tree Cutter", "Generator", "Wire Mill", "Press", "Splitter", "Alloy Kiln", "Electric Drill", "Assembler", "Sorting Gate", "Belt Loader", "Storage Silo", "Solar Panel", "Charge Vault", "Volt Engine", "Deep Drill", "Shatter Mill", "Sky Tap", "Fast Belt", "Charging Pad", "Crystal Vat", "Forge Hopper", "Recycler", "Belt Lift", "Belt Drop", "Crop Harvester", "Belt Tunnel"]), ...gK("Parts Bench", ["Motor", "Logic Board", "Machine Hull", "Power Coupler", "Voltite Cell", "Star Alloy", "Starframe", "Comet Core"]), ...gK("Tool Bench", ["Recall Beacon", "Wrench", "Iron Hammer", "Ore Lens", "Homing Beacon", "Pull Charm", "Vein Breaker", "Sky Pack", "Starbore Drill", "Arc Caster", "Voltplate Helmet", "Voltplate Chestplate", "Voltplate Gauntlets", "Voltplate Leggings", "Voltplate Boots"]), ...gK("Machine Bench", ["Condenser", "Fluid Pipe", "Fluid Tank", "Centrifuge", "Synthesizer", "Coolant Mixer"]), ...gK("Parts Bench", ["Heat Exchanger", "Containment Plate"]), ...gK("Parts Bench", ["Focus Lens"]), ...gK("Machine Bench", ["Laser", "Collider"]), ...gK("Atomic Bench", ["Graphite Block", "Fuel Rod", "Coolant Channel", "Reactor Frame", "Reactor Glass", "Reactor Port", "Battery Cell", "Reactor Blueprint", "Atomic Bomb"]), ...gK("Tool Bench", ["Jet Chestplate", "Nova Helmet", "Nova Chestplate", "Nova Gauntlets", "Nova Leggings", "Nova Boots", "Nova Blade", "Nova Jet Chestplate", "Nova Multitool"]), ...gK("Machine Bench", ["Express Belt", "Fast Loader", "Dense Silo", "Mob Farm", "Wireless Terminal", "Uranium Glass", "Glow Lamp"]), ...gK("Parts Bench", ["Advanced Coupler", "Nova Coupler"]), ...gK("Tool Bench", ["Mob Cage"]), ...gK("Tool Bench", ["Pocket Terminal"]), ...gK("Tool Bench", ["Comet Beacon"]), ...gK("Tool Bench", ["Nova Wrench"])]);
    new Set(["Recall Beacon", "Iron Hammer", "Wrench"]);

    function EO(OO) {
      var KO;
      return null !== (KO = uO[OO]) && void 0 !== KO ? KO : ["Workbench"]
    }

    function jK(OO) {
      return EO(OO)[0]
    }
    bK.slice(1).map(((OO, KO) => `Core Tier ${KO+2}`));
    var YO = pO(8365);
    const wO = ["on", "hud", "off"];

    function iK(OO) {
      return "on" === OO
    }
    var rK = pO(256);
    const PO = "Mob Farm",
      mK = {
        Pig: 1,
        Cow: 1,
        Sheep: 1,
        Deer: 1,
        Stag: 1,
        "Draugr Zombie": 2,
        "Draugr Skeleton": 2,
        "Cave Golem": 3,
        "Magma Golem": 3
      },
      sO = ["Pig", "Cow", "Sheep", "Deer", "Stag"],
      HO = {
        1: 20,
        2: 60,
        3: 120
      },
      RO = "baf2farmvoid",
      SO = "Caged ",
      JO = " Spawner Block";

    function cK(OO) {
      return `lifeform:${(0,rK.ke)(OO)}`
    }

    function BO(OO) {
      if (!OO) return null;
      if (OO.startsWith(SO)) {
        const KO = OO.slice(6);
        return sO.includes(KO) ? KO : null
      }
      if (OO.endsWith(JO)) {
        const KO = OO.slice(0, -14);
        return void 0 !== mK[KO] ? KO : null
      }
      return null
    }

    function ZO(OO) {
      return !0 === OO.mobFarm
    }

    function GO(OO, KO) {
      return HO[mK[KO]] * OO.opMs / 1e3
    }
    const qK = new Map;
    const xK = "baf2islands",
      nO = "baf2islandnew";

    function WO(OO) {
      const KO = bK.findIndex((KO => KO.unlocks.includes(OO)));
      return KO < 0 ? 1 : KO + 1
    }

    function tK(OO) {
      return Math.floor(OO).toLocaleString("en-US")
    }
    var kK = pO(36818);
    const UO = "baf2terminaltake",
      OK = ["one", "stack", "fill"];

    function KK(OO, KO, pO) {
      return `${UO} ${OO} ${KO} ${pO}`
    }

    function pK(OO) {
      const [KO, pO, ...XO] = OO.trim().split(" "), bK = Number(KO), eO = function(OO) {
        if (OK.includes(OO)) return OO;
        const KO = Number(OO);
        return /^\d+$/.test(OO) && Number.isSafeInteger(KO) && KO > 0 ? KO : null
      }(null !== pO && void 0 !== pO ? pO : "");
      return !Number.isSafeInteger(bK) || bK <= 0 || null === eO || 0 === XO.length ? null : {
        seq: bK,
        mode: eO,
        item: XO.join(" ")
      }
    }
    const XK = "baf2rx";

    function bp(OO, KO) {
      for (var pO = arguments.length, XO = new Array(pO > 2 ? pO - 2 : 0), bK = 2; bK < pO; bK++) XO[bK - 2] = arguments[bK];
      return [XK, OO[0], OO[1], OO[2], KO, ...XO].join(" ")
    }
    const eK = 2,
      lK = 4,
      vp = 8,
      CK = 16,
      hK = 32,
      DK = 64,
      MK = 128,
      ap = 256,
      oK = 512,
      FK = [{
        item: "Raw Voltite",
        chance: .55
      }, {
        item: "Raw Gold",
        chance: .43
      }, {
        item: "Diamond",
        chance: .02
      }],
      VK = [{
        item: "Raw Voltite",
        chance: .545
      }, {
        item: "Raw Gold",
        chance: .43
      }, {
        item: "Diamond",
        chance: .02
      }, {
        item: "Comet Shard",
        chance: .0025
      }, {
        item: "Dusk Moss",
        chance: .0025
      }];
    const LK = "Biomass",
      QK = ["Dandelion", "Poppy", "Red Tulip", "Pink Tulip", "White Tulip", "Orange Tulip", "Daisy", "Bluebell", "Forget-me-not", "Allium", "Azure Bluet", "Lily of the Valley", "Shadow Rose", "Grass", "Tall Grass", "Pine Grass", "Spectral Grass", "Jungle Tall Grass", "Pine Fern", "Autumn Fern", "Dead Bush", "Cactus", "Red Mushroom", "Brown Mushroom", "Vines", "Aspen Sapling", "Maple Sapling", "Jungle Sapling", "Plum Sapling", "Pine Sapling", "Cedar Sapling", "Palm Sapling", "Pear Sapling", "Cherry Sapling", "Spectral Sapling", "Mango Sapling"];

    function zp(OO) {
      return {
        input: LK,
        inputAmount: 1,
        output: OO,
        outputAmount: 1
      }
    }
    const AK = "baf2synth",
      fK = ["Burner Drill", "Crusher", "Smelter", "Generator", "Press", "Wire Mill", "Alloy Kiln", "Electric Drill", "Assembler", "Tree Cutter", "Volt Engine", "Deep Drill", "Shatter Mill", "Sky Tap", "Crystal Vat", "Recycler", "Crop Harvester", "Condenser", "Centrifuge", "Synthesizer", "Mob Farm", "Coolant Mixer"],
      dK = ["Raw Porkchop", "Raw Beef", "Raw Mutton", "Raw Venison"],
      TK = ["Cooked Porkchop", "Steak", "Cooked Mutton", "Cooked Venison"],
      NK = function(OO, KO) {
        return {
          input: OO,
          inputAmount: arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
          output: KO,
          outputAmount: arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
          bonus: arguments.length > 4 ? arguments[4] : void 0
        }
      },
      IK = function(OO, KO) {
        return {
          ...NK(OO, KO, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1),
          nuclear: !0
        }
      },
      yp = {
        "Burner Drill": {
          kind: "Burner Drill",
          opMs: 4e3,
          inputSlot: null,
          fuelSlot: 0,
          outputSlots: [1, 2, 3],
          recipes: []
        },
        Crusher: {
          kind: "Crusher",
          opMs: 4e3,
          inputSlot: 0,
          fuelSlot: 1,
          outputSlots: [2, 3, 4],
          recipes: [NK("Raw Iron", "Iron Grit", 2, 1, {
            item: "Gold Grit",
            chance: .05
          }), NK("Raw Copper", "Copper Grit", 2, 1, {
            item: "Iron Grit",
            chance: .1
          }), NK("Raw Gold", "Gold Grit", 2), NK("Messy Stone", "Sand"), NK("Gravel", "Sand"), NK("Raw Voltite", "Voltite Dust", 2), NK("Moonstone", "Moonstone Dust", 4), NK("Wheat Seeds", "Fertiliser"), NK("Raw Uranium", "Uranium Grit", 2), IK("Mossy Messy Stone", "Sand"), ...dK.map((OO => IK(OO, "Biomass", 2)))],
          couplable: !0
        },
        Smelter: {
          kind: "Smelter",
          opMs: 2e3,
          inputSlot: 0,
          fuelSlot: 1,
          outputSlots: [2, 3, 4],
          recipes: [NK("Iron Grit", "Iron Bar"), NK("Copper Grit", "Copper Bar"), NK("Gold Grit", "Gold Bar"), NK("Raw Iron", "Iron Bar"), NK("Raw Copper", "Copper Bar"), NK("Raw Gold", "Gold Bar"), NK("Sand", "Glass"), NK("Messy Stone", "Stone"), ...rK.Nc.map((OO => NK(OO, "Charcoal", 1, 4))), NK("Wheat", "Bread", 1, 2), ...dK.map(((OO, KO) => IK(OO, TK[KO])))],
          couplable: !0
        },
        Generator: {
          kind: "Generator",
          opMs: 4e3,
          inputSlot: null,
          fuelSlot: 0,
          outputSlots: [],
          recipes: [],
          fuels: ["Coal", "Charcoal"],
          powerMade: 80
        },
        Press: {
          kind: "Press",
          opMs: 3e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3],
          recipes: [NK("Iron Bar", "Iron Plate"), NK("Gold Bar", "Gold Plate")],
          powerPerOp: 24
        },
        "Wire Mill": {
          kind: "Wire Mill",
          opMs: 3e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3],
          recipes: [NK("Copper Bar", "Copper Wire", 3)],
          powerPerOp: 24
        },
        "Alloy Kiln": {
          kind: "Alloy Kiln",
          opMs: 4e3,
          inputSlot: 0,
          fuelSlot: 1,
          outputSlots: [2, 3, 4],
          recipes: [NK("Iron Grit", "Steel Bar", 1, 2)],
          fuels: ["Coal", "Charcoal"],
          couplable: !0
        },
        "Electric Drill": {
          kind: "Electric Drill",
          opMs: 2e3,
          inputSlot: null,
          fuelSlot: null,
          outputSlots: [0, 1, 2],
          recipes: [],
          powerPerOp: 16
        },
        Assembler: {
          kind: "Assembler",
          opMs: 6e3,
          inputSlot: null,
          inputSlots: [0, 1, 2, 3],
          fuelSlot: null,
          outputSlots: [4, 5, 6],
          recipes: [],
          powerPerOp: 48,
          bench: null
        },
        "Tree Cutter": {
          kind: "Tree Cutter",
          opMs: 4e3,
          inputSlot: null,
          fuelSlot: 0,
          outputSlots: [1, 2, 3],
          recipes: [],
          treeCutter: !0
        },
        "Volt Engine": {
          kind: "Volt Engine",
          opMs: 4e3,
          inputSlot: null,
          fuelSlot: 0,
          outputSlots: [],
          recipes: [],
          fuels: ["Voltite Cell"],
          powerMade: 400
        },
        "Deep Drill": {
          kind: "Deep Drill",
          opMs: 1e3,
          inputSlot: null,
          fuelSlot: null,
          outputSlots: [0, 1, 2],
          recipes: [],
          powerPerOp: 24
        },
        "Shatter Mill": {
          kind: "Shatter Mill",
          opMs: 1e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3],
          recipes: [NK("Raw Iron", "Iron Grit", 3, 1, {
            item: "Gold Grit",
            chance: .05
          }), NK("Raw Copper", "Copper Grit", 3, 1, {
            item: "Iron Grit",
            chance: .1
          }), NK("Raw Gold", "Gold Grit", 3), NK("Raw Voltite", "Voltite Dust", 3), NK("Messy Stone", "Sand", 2), NK("Gravel", "Sand", 2), NK("Moonstone", "Moonstone Dust", 6), NK("Raw Uranium", "Uranium Grit", 3)],
          powerPerOp: 24
        },
        "Sky Tap": {
          kind: "Sky Tap",
          opMs: 12e3,
          inputSlot: null,
          fuelSlot: null,
          outputSlots: [0, 1, 2],
          recipes: [],
          powerPerOp: 72,
          table: FK
        },
        "Crystal Vat": {
          kind: "Crystal Vat",
          opMs: 12e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3],
          recipes: [NK("Coal", "Diamond", 1, 24), NK("Voltite Dust", "Moonstone", 1, 12)],
          powerPerOp: 1200
        },
        Recycler: {
          kind: "Recycler",
          opMs: 6e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3],
          recipes: [],
          powerPerOp: 48,
          recycles: !0
        },
        "Crop Harvester": {
          kind: "Crop Harvester",
          opMs: 2e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3],
          recipes: [],
          powerPerOp: 16,
          field: !0
        },
        "Mob Farm": {
          kind: "Mob Farm",
          opMs: 12e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3, 4, 5, 6],
          recipes: [],
          powerPerOp: 240,
          mobFarm: !0
        },
        ...kK.h
      },
      gp = {
        Crusher: [NK("Spent Pellet", "Glow Dust"), NK("Wheat Seeds", "Biomass"), NK("Wheat", "Biomass"), NK("Dead Bush", "Biomass"), NK("Dusk Moss", "Biomass"), NK("Rotten Flesh", "Biomass"), NK("Bone", "Biomass", 2)],
        "Shatter Mill": [NK("Spent Pellet", "Glow Dust"), NK("Wheat Seeds", "Biomass"), NK("Wheat", "Biomass"), NK("Dead Bush", "Biomass"), NK("Dusk Moss", "Biomass"), NK("Rotten Flesh", "Biomass"), NK("Bone", "Biomass", 2), ...rK.Nc.map((OO => NK(OO, "Biomass")))],
        Smelter: [NK("Biomass", "Fertiliser", 2)],
        Press: [NK("Coal", "Graphite", 1, 4)]
      },
      uK = "Power Coupler",
      EK = "Advanced Coupler",
      jp = "Nova Coupler",
      YK = [{
        item: uK,
        level: 1,
        divisor: 2,
        powerPerS: 8
      }, {
        item: EK,
        level: 2,
        divisor: 4,
        powerPerS: 32
      }, {
        item: jp,
        level: 3,
        divisor: 8,
        powerPerS: 128
      }];
    const wK = new Map;

    function ip(OO) {
      var KO, pO;
      return null !== (KO = null !== (pO = OO.fuelSlot) && void 0 !== pO ? pO : OO.couplerSlot) && void 0 !== KO ? KO : null
    }

    function rp(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
      if (!OO.couplable) throw new Error(`${OO.kind} takes no Power Coupler`);
      let pO = wK.get(OO);
      pO || (pO = [], wK.set(OO, pO));
      let XO = pO[KO];
      if (!XO) {
        var bK;
        const {
          divisor: eO,
          powerPerS: lO
        } = YK[KO - 1], vK = OO.opMs / eO, CO = void 0 !== OO.fluidMade || void 0 !== OO.cryoMade ? OO.powerPerOp : lO * vK / 1e3;
        XO = {
          ...OO,
          fuelSlot: null,
          couplerSlot: null !== (bK = ip(OO)) && void 0 !== bK ? bK : void 0,
          opMs: vK,
          powerPerOp: CO,
          coupled: !0
        }, KO > 1 && (XO = {
          ...XO,
          couplerLevel: KO
        }), pO[KO] = XO
      }
      return XO
    }
    const PK = new Map;
    const mp = new Map;

    function sK(OO, KO) {
      if (null === KO || (pO = KO, !QK.includes(pO))) return OO;
      var pO;
      let XO = mp.get(KO);
      return XO || (XO = {
        ...OO,
        recipes: [zp(KO)]
      }, mp.set(KO, XO)), XO
    }

    function HK(OO) {
      return !0 === OO.synth
    }
    const RK = (OO, KO, pO, XO) => ({
        output: OO,
        outputAmount: KO,
        tier: pO,
        inputs: XO.map((OO => {
          let [KO, pO] = OO;
          return {
            item: KO,
            amount: pO
          }
        }))
      }),
      SK = Object.fromEntries([RK("Conveyor Belt", 4, 1, [
        ["Iron Bar", 2]
      ]), RK("Motor", 1, 2, [
        ["Iron Plate", 2],
        ["Copper Wire", 6],
        ["Iron Bar", 1]
      ]), RK("Splitter", 2, 2, [
        ["Conveyor Belt", 2],
        ["Iron Plate", 1]
      ]), RK("Logic Board", 1, 3, [
        ["Gold Plate", 1],
        ["Copper Wire", 6],
        ["Glass", 1]
      ]), RK("Machine Hull", 1, 3, [
        ["Steel Bar", 4],
        ["Iron Plate", 2]
      ]), RK("Power Coupler", 1, 3, [
        ["Logic Board", 1],
        ["Copper Wire", 4],
        ["Iron Plate", 2]
      ]), RK("Sorting Gate", 2, 3, [
        ["Iron Plate", 2],
        ["Copper Wire", 4]
      ]), RK("Belt Loader", 1, 3, [
        ["Iron Plate", 2],
        ["Motor", 1]
      ]), RK("Voltite Cell", 1, 4, [
        ["Voltite Dust", 2],
        ["Steel Bar", 1],
        ["Copper Wire", 4]
      ]), RK("Fast Belt", 4, 4, [
        ["Conveyor Belt", 4],
        ["Motor", 1],
        ["Steel Bar", 1]
      ]), RK("Star Alloy", 1, 5, [
        ["Moonstone Dust", 1],
        ["Steel Bar", 2],
        ["Voltite Cell", 1]
      ]), RK("Starframe", 1, 10, [
        ["Star Alloy", 4],
        ["Machine Hull", 2]
      ]), RK("Comet Core", 1, 5, [
        ["Comet Shard", 8]
      ]), RK("Belt Lift", 2, 2, [
        ["Conveyor Belt", 2],
        ["Iron Plate", 2]
      ]), RK("Belt Drop", 2, 2, [
        ["Conveyor Belt", 2],
        ["Iron Plate", 1]
      ]), RK("Belt Tunnel", 2, 6, [
        ["Conveyor Belt", 2],
        ["Steel Bar", 4],
        ["Machine Hull", 1]
      ]), RK("Fluid Pipe", 8, 11, [
        ["Iron Plate", 2],
        ["Glass", 1]
      ]), RK("Fluid Tank", 1, 11, [
        ["Glass", 4],
        ["Iron Plate", 2],
        ["Steel Bar", 1]
      ]), RK("Heat Exchanger", 1, 11, [
        ["Copper Wire", 4],
        ["Iron Plate", 2],
        ["Glass", 1]
      ]), RK("Containment Plate", 2, 11, [
        ["Steel Bar", 2],
        ["Star Alloy", 1]
      ]), RK("Focus Lens", 1, 14, [
        ["Diamond", 3],
        ["Moonstone", 2],
        ["Glass", 2],
        ["Glow Dust", 1]
      ]), RK("Graphite Block", 1, 12, [
        ["Graphite", 4]
      ]), RK("Fuel Rod", 1, 12, [
        ["Uranium Pellet", 1],
        ["Graphite", 1],
        ["Steel Bar", 2]
      ]), RK("Coolant Channel", 1, 12, [
        ["Heat Exchanger", 1],
        ["Steel Bar", 1]
      ]), RK("Reactor Frame", 4, 12, [
        ["Containment Plate", 1],
        ["Steel Bar", 1]
      ]), RK("Reactor Glass", 4, 12, [
        ["Glass", 2],
        ["Steel Bar", 1]
      ]), RK("Reactor Port", 1, 12, [
        ["Containment Plate", 2],
        ["Motor", 1],
        ["Logic Board", 1]
      ]), RK("Battery Cell", 1, 11, [
        ["Voltite Cell", 1],
        ["Containment Plate", 1],
        ["Logic Board", 1]
      ]), RK("Advanced Coupler", 1, 13, [
        ["Power Coupler", 1],
        ["Star Alloy", 1],
        ["Logic Board", 2]
      ]), RK("Nova Coupler", 1, 15, [
        ["Nova Matter", 1],
        ["Star Alloy", 2],
        ["Logic Board", 1]
      ])].map((OO => [OO.output, OO]))),
      JK = new Map;

    function cp(OO, KO) {
      let pO = yp[OO];
      if (KO.atomic && (pO = function(OO) {
          const KO = gp[OO.kind];
          if (!KO) return OO;
          let pO = PK.get(OO.kind);
          if (!pO) {
            const XO = new Set(KO.map((OO => OO.input))),
              bK = OO.recipes.filter((OO => !XO.has(OO.input)));
            pO = {
              ...OO,
              recipes: [...bK, ...KO]
            }, PK.set(OO.kind, pO)
          }
          return pO
        }(pO)), pO.synth) return sK(pO, KO.taught);
      if (KO.coupled && pO.couplable) return rp(pO, KO.level);
      const XO = pO.inputSlots && null !== KO.taught ? SK[KO.taught] : void 0;
      if (!XO) return pO;
      const bK = `${OO}|${XO.output}`;
      let eO = JK.get(bK);
      return eO || (eO = {
        ...pO,
        bench: XO
      }, JK.set(bK, eO)), eO
    }
    const BK = ["Diamond", "Moonstone"];

    function ZK(OO) {
      return new Set(OO.flatMap((OO => OO.bonus ? [OO.output, OO.bonus.item] : [OO.output])).filter((OO => !BK.includes(OO))))
    }
    const GK = Object.values(yp).flatMap((OO => OO.recipes));
    ZK(GK.filter((OO => !0 !== OO.nuclear))), ZK([...GK.filter((OO => !0 === OO.nuclear)), ...Object.values(gp).flat()]);

    function qp(OO) {
      return null === OO.inputSlot && void 0 === OO.inputSlots && void 0 === OO.powerMade && void 0 === OO.fluidMade && !OO.treeCutter && void 0 === OO.table
    }

    function xp(OO) {
      return !0 === OO.treeCutter
    }
    const nK = ["Voltite Cell"];

    function WK(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = OO.fuels) || void 0 === pO ? void 0 : pO.some((OO => nK.includes(OO)))) && void 0 !== KO && KO
    }
    const tp = {
        Coal: 32e3,
        Charcoal: 32e3,
        ...Object.fromEntries(rK.Nc.map((OO => [OO, 8e3]))),
        ...Object.fromEntries(rK.ld.map((OO => [OO, 2e3]))),
        "Voltite Cell": 12e4
      },
      kp = {
        "Coal Deposit": "Coal",
        "Iron Deposit": "Raw Iron",
        "Stone Deposit": "Messy Stone",
        "Copper Deposit": "Raw Copper",
        "Gold Deposit": "Raw Gold",
        "Voltite Deposit": "Raw Voltite",
        "Uranium Deposit": "Raw Uranium"
      },
      UK = {
        "Uranium Deposit": 4e3
      };

    function Op(OO) {
      var KO;
      return null !== (KO = Object.keys(kp).find((KO => kp[KO] === OO))) && void 0 !== KO ? KO : null
    }

    function Kp(OO) {
      return fK.includes(OO)
    }

    function pp(OO) {
      return !0 !== OO.nuclear || vK()
    }
    var Xp = pO(243);
    var bX = pO(8449),
      ep = pO(8370),
      lp = pO(8458),
      vX = pO(8440);
    const Cp = "Reactor Controller",
      hp = "Reactor Port",
      Dp = "Battery Cell",
      Mp = ["fuel", "water", "waste"],
      aX = {
        fuel: hp,
        water: "Reactor Port|meta|rot1|Water",
        waste: "Reactor Port|meta|rot1|Waste"
      },
      op = {
        1: [0, 0, 1],
        2: [1, 0, 0],
        3: [0, 0, -1],
        4: [-1, 0, 0]
      },
      Fp = {
        reactor: {
          min: 4,
          max: 12
        },
        battery: {
          min: 2,
          max: 12
        }
      },
      Vp = "Reactor Frame",
      Lp = "Reactor Glass",
      Qp = {
        edge: [Vp],
        cap: [Lp, hp],
        wall: [Lp, hp],
        inside: ["Fuel Rod", "Graphite Block", "Coolant Channel", "Air"],
        ctrl: [Cp]
      },
      zX = {
        edge: [Dp],
        cap: [Dp],
        wall: [Dp],
        inside: [Dp],
        ctrl: [Dp]
      },
      Ap = ["edge", "cap", "wall", "inside"],
      fp = ["Reactor Slag"];

    function dp(OO) {
      return fp.includes(Tp(OO))
    }

    function Tp(OO) {
      const KO = OO.indexOf("|");
      return KO < 0 ? OO : OO.slice(0, KO)
    }

    function Np(OO) {
      return Tp(OO) === Cp ? "reactor" : null
    }

    function Ip(OO) {
      return Tp(OO) !== hp ? null : OO.endsWith("|Water") ? "water" : OO.endsWith("|Waste") ? "waste" : "fuel"
    }

    function yX(OO) {
      const KO = Ip(OO);
      return null === KO ? null : Ep(aX[Mp[(Mp.indexOf(KO) + 1) % Mp.length]], function(OO) {
        return OO.includes(gX)
      }(OO))
    }
    const gX = "|meta|rot1|Formed",
      upO = new Set([Vp, Lp, hp]);

    function Ep(OO, KO) {
      var pO;
      const XO = Tp(OO);
      if (!upO.has(XO)) return OO;
      if (XO !== hp) return KO ? XO + gX : XO;
      const bK = null !== (pO = Ip(OO)) && void 0 !== pO ? pO : "fuel";
      return KO ? "fuel" === bK ? XO + gX : `${XO}${gX}|${"water"===bK?"Water":"Waste"}` : aX[bK]
    }

    function jX(OO, KO) {
      const pO = np(OO, KO);
      if ("Air" === pO) return !1;
      const XO = "reactor" === OO ? Qp : zX;
      return Ap.some((OO => XO[OO].includes(pO))) || "reactor" === OO && fp.includes(pO)
    }

    function Yp(OO) {
      return Fp[OO]
    }

    function wp(OO) {
      var KO;
      return null !== (KO = op[OO]) && void 0 !== KO ? KO : op[1]
    }

    function iX(OO) {
      const [KO, , pO] = wp(OO);
      return [pO, 0, -KO]
    }

    function rX(OO, KO, pO, XO, bK, eO) {
      return {
        ctrl: [OO[0], OO[1], OO[2]],
        rot: op[KO] ? KO : 1,
        w: pO,
        h: XO,
        d: bK,
        cu: eO[0],
        cv: eO[1]
      }
    }

    function Pp(OO, KO) {
      return "reactor" === OO ? [Math.floor((KO - 1) / 2), 0] : [0, 0]
    }

    function mX(OO, KO, pO, XO, bK) {
      let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : OO.rot;
      if (pO === OO.w && XO === OO.h && bK === OO.d && eO === OO.rot) return OO;
      const [lO] = Pp(KO, OO.w);
      if (OO.cu === lO && OO.cv <= 1) return rX(OO.ctrl, eO, pO, XO, bK, Pp(KO, pO));
      const vK = (OO, KO) => Math.max(1, Math.min(KO, OO));
      return rX(OO.ctrl, eO, pO, XO, bK, [vK(OO.cu, pO - 2), 0 === OO.cv ? 0 : vK(OO.cv, XO - 2)])
    }
    const sp = 11,
      Hp = 2 * sp + 1;
    new Uint8Array(Hp * Hp * Hp);

    function Rp(OO) {
      return OO.w * OO.h * OO.d
    }

    function Sp(OO) {
      const KO = iX(OO.rot);
      return [OO.ctrl[0] - KO[0] * OO.cu, OO.ctrl[1] - OO.cv, OO.ctrl[2] - KO[2] * OO.cu]
    }

    function Jp(OO) {
      return OO.cv * OO.d * OO.w + OO.cu
    }

    function cX(OO, KO) {
      const pO = KO % OO.w,
        XO = Math.floor(KO / OO.w) % OO.d;
      return [pO, Math.floor(KO / (OO.w * OO.d)), XO]
    }

    function Bp(OO, KO) {
      const [pO, XO, bK] = cX(OO, KO), eO = Sp(OO), lO = wp(OO.rot), vK = iX(OO.rot);
      return [eO[0] + vK[0] * pO - lO[0] * bK, eO[1] + XO, eO[2] + vK[2] * pO - lO[2] * bK]
    }

    function Zp(OO, KO) {
      const pO = Sp(OO),
        XO = wp(OO.rot),
        bK = iX(OO.rot),
        eO = KO[0] - pO[0],
        lO = KO[2] - pO[2],
        vK = eO * bK[0] + lO * bK[2],
        CO = -(eO * XO[0] + lO * XO[2]),
        hO = KO[1] - pO[1];
      return vK < 0 || vK >= OO.w || hO < 0 || hO >= OO.h || CO < 0 || CO >= OO.d ? -1 : (hO * OO.d + CO) * OO.w + vK
    }

    function Gp(OO, KO) {
      if (KO === Jp(OO)) return "ctrl";
      const [pO, XO, bK] = cX(OO, KO), eO = 0 === XO || XO === OO.h - 1, lO = Number(0 === pO || pO === OO.w - 1) + Number(eO) + Number(0 === bK || bK === OO.d - 1);
      return lO >= 2 ? "edge" : 1 === lO ? eO ? "cap" : "wall" : "inside"
    }

    function qX(OO, KO) {
      const [pO, XO, bK] = cX(OO, KO);
      return 0 === pO || pO === OO.w - 1 || 0 === XO || XO === OO.h - 1 || 0 === bK || bK === OO.d - 1 ? -1 : ((XO - 1) * (OO.d - 2) + (bK - 1)) * (OO.w - 2) + (pO - 1)
    }

    function xX(OO, KO) {
      const pO = OO.w - 2,
        XO = OO.d - 2,
        bK = KO % pO + 1,
        eO = Math.floor(KO / pO) % XO + 1;
      return ((Math.floor(KO / (pO * XO)) + 1) * OO.d + eO) * OO.w + bK
    }

    function np(OO, KO) {
      const pO = Tp(KO);
      return "reactor" === OO && pO === Cp ? Vp : pO
    }

    function Wp(OO, KO, pO) {
      const XO = "ctrl" === KO ? Tp(pO) : np(OO, pO);
      return ("reactor" === OO ? Qp : zX)[KO].includes(XO) ? "ok" : "Air" === XO ? "missing" : jX(OO, pO) ? "wrong" : "blocked"
    }

    function tX(OO, KO) {
      return "battery" === OO ? Dp : "inside" === KO ? null : function(OO, KO) {
        if ("inside" === KO || "ctrl" === KO || "battery" === OO) return null;
        return "edge" === KO ? Vp : Lp
      }(OO, KO)
    }
    const kX = {
        LASER_DRAW: 5e3,
        FOCUS_BY_LASERS: [0, 1e3, 2500, 5e3, 8e3],
        NOVA_FOCUS: 48e4,
        NOVA_SA: 16,
        NOVA_GD: 4,
        SA_CAP: 128,
        GD_CAP: 32,
        OUT_CAP: 16,
        MIN_SPOTS: 2,
        LASER_D: 3,
        RESERVE_MIN: 8e3,
        RESERVE_CAP_SHARE: .5,
        SHORT_BACKOFF_MS: 5e3,
        BEAM_OFF_MS: 7e3,
        HIT_MS: 250,
        HIT_HP: 10,
        WARN_CLEAR_MS: 1e4,
        GHOST_REACH: 12,
        MAX_PER_ISLAND: 8
      },
      Up = "Collider",
      OX = "Laser",
      KX = "Star Alloy",
      pX = "Glow Dust",
      XX = [Up, "_Collider Focus"];

    function bb(OO) {
      return XX.indexOf(Tp(OO))
    }

    function eX(OO) {
      return Tp(OO) === OX
    }

    function lX(OO) {
      return [
        [OO[0], OO[1], OO[2]],
        [OO[0], OO[1] + 1, OO[2]]
      ]
    }
    const vb = [
      [0, 0, -1],
      [1, 0, 0],
      [0, 0, 1],
      [-1, 0, 0]
    ];

    function CX(OO, KO, pO) {
      const XO = vb[KO];
      return [OO[0] + XO[0] * pO, OO[1], OO[2] + XO[2] * pO]
    }

    function hX(OO, KO) {
      if (KO[1] !== OO[1]) return null;
      const pO = KO[0] - OO[0],
        XO = KO[2] - OO[2];
      if (0 !== pO === (0 !== XO)) return null;
      const bK = Math.abs(pO + XO);
      if (bK > kX.LASER_D) return null;
      return {
        dir: XO < 0 ? 0 : pO > 0 ? 1 : XO > 0 ? 2 : 3,
        OO: bK
      }
    }

    function DX(OO, KO, pO) {
      const XO = KO => Math.abs(OO[0] - KO[0]) <= 1 && Math.abs(OO[1] - KO[1]) <= 1;
      return XO(KO) || XO(pO)
    }

    function MX(OO, KO) {
      return function(OO, KO, pO, XO) {
        return [0, 1, 2, 3].map((bK => {
          for (let eO = 1; eO <= kX.LASER_D; eO++) {
            const lO = CX(OO, bK, eO);
            if (DX([lO[0], lO[2]], KO, pO) || !XO(lO)) return !1
          }
          return !0
        }))
      }(lX(OO)[1], KO.spawnXZ, KO.coreXZ, (OO => OO[1] >= bX.u && OO[1] < bX.u + bX.y && OO[0] >= KO.minXZ[0] && OO[0] <= KO.maxXZ[0] && OO[2] >= KO.minXZ[1] && OO[2] <= KO.maxXZ[1]))
    }
    const ab = ["Storage Silo", "Solar Panel", "Charge Vault", "Charging Pad", "Forge Hopper", "Fluid Tank", "Fluid Pipe", "Collider", "Laser", "Dense Silo", "Wireless Terminal"];

    function oX(OO) {
      return Math.max(48 + 16 * OO, QO(OO).machineAllowance)
    }
    const FX = ["_Solar Panel SE", "_Solar Panel NW", "_Solar Panel NE"];

    function VX(OO) {
      const KO = OO.split("|")[0];
      return FX.includes(KO) ? "Solar Panel" : KO === lp.e ? "Fluid Pipe" : bb(KO) >= 0 ? "Collider" : (pO = KO, ab.includes(pO) ? KO : null);
      var pO
    }
    const LX = "buildAFactory2Game:solarPanelDescription";
    const QX = ["Wood Pickaxe", "Stone Pickaxe", "Iron Pickaxe", "Gold Pickaxe", "Diamond Pickaxe"];

    function zb(OO, KO) {
      var pO;
      return null !== (pO = QX.find((pO => {
        var XO;
        return (null !== (XO = OO.level(pO)) && void 0 !== XO ? XO : 0) >= KO
      }))) && void 0 !== pO ? pO : null
    }
    const AX = "buildAFactory2Game:";
    let fX = null;
    const dX = {
        Workbench: "lookWorkbench",
        Furnace: "lookFurnace",
        Chest: "lookChest",
        Stone: "lookStone",
        "Messy Stone": "lookMessyStone",
        Gravel: "lookGravel",
        Sand: "lookSand",
        "Tilled Soil": "lookTilledSoil",
        "Fertilised Soil": "lookFertilisedSoil",
        "Wheat Seeds": "lookWheatGrowing",
        Wheat: "lookWheatRipe",
        "Loot Chest": "lookRuinChest"
      },
      TX = {
        "Mob Farm": "lookFarmEmpty",
        "Dense Silo": "lookDenseSilo",
        "Glow Lamp": "lookGlowLamp"
      },
      NX = {
        "Forge Hopper": "lookForgeHopperNuclear"
      },
      IX = {
        "Loot Chest": `${AX}lookRuinChestName`
      };

    function yb(OO) {
      return "object" === typeof OO && null !== OO && "translationKey" in OO && "string" === typeof OO.translationKey ? OO.translationKey : null
    }

    function gb(OO, KO) {
      var pO;
      return null !== (pO = yb(OO.displayName(KO))) && void 0 !== pO ? pO : `item:${(0,rK.ke)(KO)}`
    }

    function uX(OO, KO) {
      var pO, XO, bK, eO;
      let lO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : KO;
      if ("Solar Panel" === VX(KO)) return {
        name: yb(OO.displayName("Solar Panel")),
        detail: LX,
        detailItem: null
      };
      const CO = KO.endsWith(" Ore"),
        hO = (fX ??= new Set([...Object.keys((0, ep.i)()), ...Object.keys((0, lp.z)())].map((OO => OO.split("|")[0]))), fX).has(KO),
        DO = CO || hO ? null : function(OO) {
          var KO;
          return OO.endsWith(" Log") && !OO.startsWith("Barkless ") ? "lookLog" : OO.endsWith(" Sapling") ? "lookSapling" : OO.startsWith("Wheat_stage") ? "lookWheatGrowing" : null !== (KO = dX[OO]) && void 0 !== KO ? KO : null
        }(KO);
      if (!OO.isBlock(KO) || !CO && !hO && null === DO) return null;
      const MO = null !== (pO = null !== (XO = IX[KO]) && void 0 !== XO ? XO : yb(null !== (bK = OO.displayName(lO)) && void 0 !== bK ? bK : OO.displayName(KO))) && void 0 !== pO ? pO : `item:${(0,rK.ke)(KO)}`;
      if (null !== DO) return {
        name: MO,
        detail: `${AX}${DO}`,
        detailItem: null
      };
      const aK = null !== (eO = TX[KO]) && void 0 !== eO ? eO : vK() ? NX[KO] : void 0;
      if (hO && void 0 !== aK) return {
        name: MO,
        detail: `${AX}${aK}`,
        detailItem: null
      };
      const oO = kp[KO];
      if (void 0 !== oO) return {
        name: MO,
        detail: `${AX}lookDeposit`,
        detailItem: gb(OO, oO)
      };
      const FO = OO.harvestLevel(KO);
      if (CO && "rock" === OO.harvestType(KO) && 0 !== FO) {
        const KO = zb(OO, null !== FO && void 0 !== FO ? FO : 0);
        if (KO === QX[0]) return {
          name: MO,
          detail: `${AX}lookAnyPickaxe`,
          detailItem: null
        };
        if (null !== KO) return {
          name: MO,
          detail: `${AX}lookPickaxe`,
          detailItem: gb(OO, KO)
        }
      }
      return {
        name: MO,
        detail: yb(OO.description(KO)),
        detailItem: null
      }
    }

    function EX(OO) {
      return OO < bX.u - 24
    }
    const jb = new Set(["Comet Ore", "Comet Heart", "Isotope Comet Ore", "Isotope Comet Heart"]);
    const YX = "Wrench",
      wX = "Nova Wrench";

    function ib(OO) {
      return OO === YX || OO === wX
    }
    const rb = [...bX.P, "Belt Lift", "Belt Drop"];
    const PX = ["Belt Lift", "Belt Drop"],
      mb = {
        leftRight: "leftFront",
        leftFront: "frontRight",
        frontRight: null
      };

    function sX(OO) {
      return OO.split("|")[0]
    }

    function HX(OO) {
      const KO = /\|rot(\d)/.exec(OO);
      return KO ? Number(KO[1]) : 1
    }

    function RX(OO) {
      return OO % 4 + 1
    }

    function SX(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
      return 1 === KO && "" === pO ? OO : `${OO}|meta|rot${KO}${pO}`
    }

    function JX(OO) {
      return sX(OO) === bX.H ? (0, bX.X)(OO) ? "gateRight" : "gateLeft" : (0, bX.bb)(OO)
    }

    function cb(OO) {
      const KO = sX(OO),
        pO = HX(OO);
      if (bX.P.includes(KO)) return (0, bX.T)(KO, RX(pO), null);
      if (KO === bX.j) return (0, bX.ib)(RX(pO), (0, bX.Z)(OO));
      if (KO === bX.I) {
        const XO = mb[(0, bX.bb)(OO)];
        return null === XO ? SX(KO, RX(pO)) : SX(KO, pO, bX.K[XO])
      }
      return KO === bX.H ? (0, bX.X)(OO) ? SX(KO, RX(pO)) : SX(KO, pO, bX.r) : vX.d.includes(KO) && !PX.includes(KO) || Kp(KO) ? SX(KO, RX(pO)) : null
    }

    function BX(OO) {
      return vX.d.includes(OO) || Kp(OO) || null !== VX(OO)
    }

    function ZX(OO) {
      return "Solar Panel" === VX(OO)
    }
    const GX = "buildAFactory2Game:",
      qb = {
        leftFront: `${GX}lookSplitDetail_leftFront`,
        frontRight: `${GX}lookSplitDetail_frontRight`,
        gateRight: `${GX}lookGateDetail_gateRight`
      };

    function xb(OO, KO) {
      var pO;
      let XO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      const bK = JX(OO),
        eO = null === bK ? null : `${GX}${bK.startsWith("gate")?"lookGateMode_":"lookSplitMode_"}${bK}`,
        lO = null === bK ? null : null !== (pO = qb[bK]) && void 0 !== pO ? pO : null;
      if (ib(KO) && XO) {
        const pO = sX(OO);
        return KO === wX && vK() && function(OO) {
          return rb.includes(sX(OO))
        }(OO) ? {
          mode: eO,
          detail: lO,
          next: `${GX}lookNovaWrenchRun`,
          nextState: null
        } : {
          mode: eO,
          detail: lO,
          next: BX(pO) && !ZX(pO) ? `${GX}lookWrenchPickUp` : null,
          nextState: null
        }
      }
      const CO = ib(KO) ? cb(OO) : null;
      if (null === CO) return {
        mode: eO,
        detail: lO,
        next: null,
        nextState: null
      };
      const hO = JX(CO);
      return null === hO || HX(CO) !== HX(OO) ? {
        mode: eO,
        detail: lO,
        next: `${GX}lookWrenchTurn`,
        nextState: null
      } : {
        mode: eO,
        detail: lO,
        next: `${GX}lookWrenchNext`,
        nextState: `${GX}lookWrenchState_${hO}`
      }
    }
    const nX = ["running", "noFuel", "noInput", "outputFull", "noDeposit", "badInput", "noPower", "powerFull", "notTaught", "noTree", "treeGrowing", "noSky", "noCrops", "cropsGrowing", "fluidFull", "noWater", "noSpring", "allVoided", "noOutlet"],
      WX = ["running", "slowed", "noPower", "noInput", "outputFull", "noLasers", "blocked", "hold"];

    function tb(OO) {
      return [0, 1, 2, 3].map((KO => 0 !== (OO & 1 << KO)))
    }

    function kb(OO) {
      const KO = [];
      for (let pO = 8; pO + 2 < OO.length; pO += 3) KO.push([OO[pO], OO[pO + 1], OO[pO + 2]]);
      return {
        focus: [OO[0], OO[1], OO[2]],
        lasers: tb(OO[3]),
        open: tb(OO[4]),
        live: tb(OO[5]),
        on: 1 === OO[6],
        state: WX[OO[7]],
        blockers: KO
      }
    }
    const UX = "Arc Caster",
      Ob = {
        Helmet: "Voltplate Helmet",
        Chestplate: "Voltplate Chestplate",
        Gauntlets: "Voltplate Gauntlets",
        Leggings: "Voltplate Leggings",
        Boots: "Voltplate Boots"
      },
      Kb = (Object.values(Ob), "Jet Chestplate"),
      pb = "Nova Jet Chestplate",
      Xb = {
        Helmet: "Nova Helmet",
        Chestplate: "Nova Chestplate",
        Gauntlets: "Nova Gauntlets",
        Leggings: "Nova Leggings",
        Boots: "Nova Boots"
      },
      be = Object.values(Xb);

    function eb(OO, KO, pO) {
      return Math.min(function(OO) {
        return vK() && MO(OO) >= 5 ? 20 : 10
      }(pO), Math.floor(function(OO, KO) {
        return Math.max(0, OO) + (vK() ? Math.max(0, KO) : 0)
      }(OO, KO) / 5))
    }

    function lb(OO, KO, pO) {
      const XO = eb(KO, pO, OO),
        bK = MO(OO),
        eO = (bK >= 3 ? 55 : bK >= 1 ? 50 : OO >= 8 ? 45 : 30) + XO,
        lO = Math.max(100 + XO, 2 * eO);
      return {
        arcDamage: eO,
        arcPierce: OO >= 7 ? 2 : 1,
        arcChain: OO >= 10,
        barrierMax: (bK >= 4 ? 100 : bK >= 2 ? 90 : OO >= 9 ? 80 : OO >= 6 ? 60 : 40) + 5 * XO,
        barrierRegenPerS: bK >= 5 ? 20 : OO >= 9 ? 16 : 8,
        novaShieldMax: 150 + 5 * XO,
        novaShieldRegenPerS: 32,
        bladeDamage: lO,
        bladePunch: Math.round(.5 * lO),
        forgeRank: XO
      }
    }
    const ve = {
      6: "gearPerkStage1",
      7: "gearPerkStage2",
      8: "gearPerkStage3",
      9: "gearPerkStage4",
      10: "gearPerkStage5",
      11: "gearPerkAtomic1",
      12: "gearPerkAtomic2",
      13: "gearPerkAtomic3",
      14: "gearPerkAtomic4",
      15: "gearPerkAtomic5"
    };
    var Cb = pO(35322),
      hb = pO(35139),
      Db = pO(35137),
      Mb = pO(22),
      ae = pO(1441),
      ob = pO(918),
      Fb = pO.n(ob);

    function Vb(OO) {
      return !0 === OO.field
    }
    const Lb = new Set(["Iron Bar", "Copper Bar", "Gold Bar", "Steel Bar", "Iron Plate", "Motor", "Logic Board", "Relay Coil", "Machine Hull", "Voltite Cell", "Diamond", "Comet Core", "Fluid Tank", "Uranium Pellet", "Spent Pellet", "Plutonium Pellet", "Heat Exchanger", "Battery Cell", "Containment Plate", "Focus Lens", "Fuel Rod"]);

    function Qb(OO) {
      return Lb.has(OO) ? `buildAFactory2Game:itemPlural_${(0,rK.ke)(OO)}` : null
    }
    var ze = pO(1051),
      Ab = pO(933),
      fb = pO(1546),
      db = pO(1533),
      Tb = pO(35312),
      Nb = pO(35319),
      Ib = pO(26),
      ye = pO(35308);
    const ge = "baf2QuestView",
      ub = "baf2PlayerY",
      Eb = new Set(["stepGoHomeFirst", "stepCometOwedFalling"]);
    class je {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : () => {};
        this.requestBook = OO, this.view = {
          name: null,
          rows: [],
          reward: null,
          goal: null,
          pulse: 0,
          itemNames: {},
          side: null,
          tier: null,
          core: null,
          chapters: null,
          also: [],
          depth: null,
          tutorial: "on",
          tutorialKnown: !1
        }, this.pickedTutorial = null, this.pickSeq = 0, this.serverTutorial = "on", this.pickTimer = null, this.clearTimer = null, this.playerY = null
      }
      get() {
        return this.view
      }
      set(OO, KO) {
        var pO, XO, bK, eO, lO, vK, CO, hO;
        const DO = JSON.stringify(OO.baf2QuestName) === JSON.stringify(this.view.name),
          MO = new Set(this.view.rows.filter((OO => OO.done)).map((OO => OO.id))),
          aK = new Set(this.view.rows.filter((OO => OO.justFinished)).map((OO => OO.id))),
          oO = OO.baf2QuestSide,
          FO = null !== oO && !0 === OO.baf2QuestSideFocus;
        let VO = !1,
          LO = 0;
        const QO = OO.baf2QuestSteps.map((OO => {
            const KO = sb(OO, Eb.has(OO[0]) ? OO[0] : "" + LO++),
              pO = DO && KO.done && !MO.has(KO.id);
            return KO.justFinished = pO || DO && KO.done && aK.has(KO.id), VO ||= pO, KO
          })),
          zK = me(QO);
        zK >= 0 && !FO && (QO[zK].current = !0);
        const AO = !DO && null !== OO.baf2QuestName,
          fO = JSON.stringify(oO && [oO[0], oO[1]]) === JSON.stringify(null !== (pO = null === (XO = this.view.side) || void 0 === XO ? void 0 : XO.name) && void 0 !== pO ? pO : null);
        this.serverTutorial = null !== (bK = OO.baf2QuestTutorial) && void 0 !== bK ? bK : "on", (null !== (eO = OO.baf2QuestTutorialSeq) && void 0 !== eO ? eO : 0) >= this.pickSeq && this.endPick();
        const dO = !DO || !fO || OO.baf2QuestTier !== this.view.tier;
        this.view = {
          name: OO.baf2QuestName,
          rows: QO,
          reward: OO.baf2QuestReward,
          goal: OO.baf2QuestGoal,
          pulse: this.view.pulse + (VO || AO ? 1 : 0),
          itemNames: KO,
          side: oO && {
            name: [oO[0], oO[1]],
            row: {
              ...sb(oO[2], "side"),
              current: FO
            },
            goal: null !== (lO = oO[3]) && void 0 !== lO ? lO : null
          },
          tier: OO.baf2QuestTier,
          core: OO.baf2QuestCore,
          chapters: this.view.chapters,
          also: null !== (vK = OO.baf2QuestAlso) && void 0 !== vK ? vK : [],
          depth: null !== (CO = OO.baf2QuestDepth) && void 0 !== CO ? CO : null,
          tutorial: null !== (hO = this.pickedTutorial) && void 0 !== hO ? hO : this.serverTutorial,
          tutorialKnown: !0
        }, this.pl(), VO && this.scheduleClear(), dO && this.requestBook()
      }
      setTutorial(OO) {
        return this.endPick(), this.pickedTutorial = OO, this.pickSeq = Math.max(this.pickSeq + 1, Date.now()), this.pickTimer = setTimeout((() => {
          this.pickTimer = null, this.pickedTutorial = null, this.view = {
            ...this.view,
            tutorial: this.serverTutorial
          }, this.pl()
        }), 1e4), this.view = {
          ...this.view,
          tutorial: OO
        }, this.pl(), this.pickSeq
      }
      onPlayerY(OO) {
        const KO = Math.floor(OO);
        KO !== this.playerY && (this.playerY = KO, this.view.depth && Ib.i.pl(ub, KO))
      }
      lastPlayerY() {
        return this.playerY
      }
      setBook(OO) {
        this.view = {
          ...this.view,
          chapters: OO.baf2BookChapters
        }, this.pl()
      }
      dispose() {
        this.stopClear(), this.endPick()
      }
      endPick() {
        this.pickedTutorial = null, null !== this.pickTimer && (clearTimeout(this.pickTimer), this.pickTimer = null)
      }
      stopClear() {
        null !== this.clearTimer && (clearTimeout(this.clearTimer), this.clearTimer = null)
      }
      scheduleClear() {
        this.stopClear(), this.clearTimer = setTimeout((() => {
          this.clearTimer = null, this.view = {
            ...this.view,
            rows: this.view.rows.map((OO => OO.justFinished ? {
              ...OO,
              justFinished: !1
            } : OO))
          }, this.pl()
        }), 2400)
      }
      pl() {
        Ib.i.pl(ge, this.view, !0)
      }
    }

    function Yb(OO) {
      return (null === OO.name || wb(OO)) && null === OO.side && null !== OO.chapters
    }

    function wb(OO) {
      var KO;
      return "quest_forgeOngoing" === (null === (KO = OO.name) || void 0 === KO ? void 0 : KO[0])
    }

    function ie(OO) {
      return OO.filter((OO => !Eb.has(OO.key)))
    }

    function re(OO) {
      return OO.key.startsWith("stepCraft")
    }

    function Pb(OO, KO) {
      const pO = new Set,
        XO = OO.side ? [...OO.rows, OO.side.row] : OO.rows;
      for (const eO of XO)
        if (!eO.done) {
          !eO.item || KO && !re(eO) || pO.add(eO.item);
          for (const [OO, KO, XO] of null !== (bK = eO.chips) && void 0 !== bK ? bK : []) {
            var bK;
            KO < XO && pO.add(OO)
          }
        } return pO
    }

    function me(OO) {
      const KO = OO.findIndex((OO => !OO.done && !OO.away));
      return KO >= 0 ? KO : OO.findIndex((OO => !OO.done))
    }

    function sb(OO, KO) {
      let [pO, XO, bK, eO, lO, vK, CO, hO, DO, MO] = OO;
      return {
        id: KO,
        key: pO,
        params: XO,
        item: bK,
        amount: eO,
        total: lO,
        done: vK,
        chips: null !== CO && void 0 !== CO ? CO : null,
        current: !1,
        away: !0 === hO,
        madeFor: null !== DO && void 0 !== DO ? DO : [],
        also: null !== MO && void 0 !== MO ? MO : [],
        justFinished: !1
      }
    }
    const Hb = "baf2QuestItems",
      Rb = new Set;
    let Sb = new Set,
      Jb = null;

    function ce(OO) {
      const KO = iK(OO.tutorial),
        pO = KO ? Pb(OO, !0) : Rb;
      "inventory" === Mb.d.get("openInGameMenuName") ? (Jb = null, (0, ye.r)(pO)) : Jb = pO;
      const XO = KO ? Pb(OO, !1) : Rb;
      (0, Nb.c)(XO, Sb) || (Sb = XO, Ib.i.pl(Hb, Sb))
    }

    function Bb() {
      return (0, Tb.b)(Hb, (() => Sb))
    }
    var Zb = pO(35217),
      Gb = pO(2560);

    function qe(OO) {
      const KO = (0, Gb.c)(OO),
        pO = void 0 === KO ? void 0 : (0, Zb.displayNameOf)(KO);
      return "object" === typeof pO && null !== pO && "translationKey" in pO && "string" === typeof pO.translationKey ? pO.translationKey : `item:${(0,rK.ke)(OO)}`
    }

    function xe(OO, KO) {
      return OO(qe(KO))
    }
    const nb = [{
      item: "Relay Coil",
      amount: 1,
      weight: 25,
      fromTier: 1,
      untilTier: 2,
      prize: !0
    }, {
      item: "Iron Bar",
      amount: 4,
      weight: 12,
      fromTier: 1,
      later: {
        tier: 3,
        weight: 2
      }
    }, {
      item: "Copper Bar",
      amount: 4,
      weight: 14,
      fromTier: 1,
      later: {
        tier: 3,
        weight: 2
      }
    }, {
      item: "Copper Wire",
      amount: 6,
      weight: 12,
      fromTier: 2,
      later: {
        tier: 3,
        weight: 2
      }
    }, {
      item: "Iron Plate",
      amount: 3,
      weight: 12,
      fromTier: 2,
      later: {
        tier: 3,
        weight: 2
      }
    }, {
      item: "Gold Bar",
      amount: 2,
      weight: 10,
      fromTier: 2,
      later: {
        tier: 3,
        weight: 2
      }
    }, {
      item: "Motor",
      amount: 1,
      weight: 8,
      fromTier: 2,
      later: {
        tier: 3,
        weight: 2
      }
    }, {
      item: "Deposit Seed (Copper)",
      amount: 1,
      weight: 4,
      fromTier: 2,
      later: {
        tier: 3,
        weight: 6
      },
      prize: !0
    }, {
      item: "Steel Bar",
      amount: 2,
      weight: 2,
      fromTier: 3
    }, {
      item: "Logic Board",
      amount: 1,
      weight: 6,
      fromTier: 3
    }, {
      item: "Raw Voltite",
      amount: 2,
      weight: 10,
      fromTier: 3,
      later: {
        tier: 4,
        weight: 3
      }
    }, {
      item: "Machine Hull",
      amount: 1,
      weight: 4,
      fromTier: 3
    }, {
      item: "Diamond",
      amount: 1,
      weight: 6,
      fromTier: 3,
      prize: !0
    }, {
      item: "Deposit Seed (Gold)",
      amount: 1,
      weight: 6,
      fromTier: 3,
      prize: !0
    }, {
      item: "Deposit Seed (Voltite)",
      amount: 1,
      weight: 6,
      fromTier: 4,
      prize: !0
    }, {
      item: "Voltite Cell",
      amount: 1,
      weight: 4,
      fromTier: 4
    }, {
      item: "Dusk Moss",
      amount: 1,
      weight: 6,
      fromTier: 4,
      prize: !0
    }, {
      item: "Moonstone",
      amount: 1,
      weight: 12,
      fromTier: 4,
      later: {
        tier: 5,
        weight: 6
      },
      prize: !0
    }, {
      item: "Comet Shard",
      amount: 2,
      weight: 12,
      fromTier: 5,
      prize: !0
    }];

    function Wb(OO, KO) {
      return [`Deposit Seed (${OO})`, {
        item: kp[`${OO} Deposit`],
        amount: KO
      }]
    }
    const te = Object.fromEntries([Wb("Coal", 8), Wb("Iron", 8), Wb("Copper", 8), Wb("Gold", 6), Wb("Voltite", 4), Wb("Uranium", 4)]),
      ke = "Relay Coil",
      Ub = new Map;

    function Oe(OO) {
      let KO = Ub.get(OO);
      if (!KO) {
        const pO = Math.max(1, OO);
        KO = nb.filter((OO => {
          var KO;
          return pO >= OO.fromTier && pO <= (null !== (KO = OO.untilTier) && void 0 !== KO ? KO : 1 / 0)
        })).map((OO => OO.later && pO >= OO.later.tier ? {
          ...OO,
          weight: OO.later.weight
        } : OO)), Ub.set(OO, KO)
      }
      return KO
    }

    function Ke(OO) {
      return Oe(OO).some((OO => {
        let {
          item: KO
        } = OO;
        return KO === ke
      }))
    }

    function pe(OO) {
      return OO.startsWith("Deposit Seed (")
    }

    function Xe(OO, KO) {
      const pO = Oe(OO);
      return KO ? pO.filter((OO => KO(OO.item))) : pO
    }

    function bl(OO) {
      return OO.reduce(((OO, KO) => OO + KO.weight), 0)
    }

    function ee(OO, KO) {
      const pO = Xe(OO, KO),
        XO = bl(pO);
      return pO.map((OO => ({
        find: OO,
        chance: OO.weight / XO
      })))
    }
    const le = 6e4,
      vl = new Intl.NumberFormat("en-US");

    function Ce(OO, KO) {
      const pO = OO >= 10 ? Math.round(OO) : Math.round(10 * OO) / 10;
      return 0 === pO ? "0" : `${KO}${vl.format(pO)}`
    }

    function he(OO) {
      return OO < (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e5) ? vl.format(OO) : OO < 1e6 ? `${OO<1e5?Math.floor(OO/100)/10:Math.floor(OO/1e3)}k` : Math.floor(OO / 1e5) / 10 + "M"
    }

    function De(OO) {
      return OO < 0 ? "\u2212" + -OO : String(OO)
    }

    function Me(OO, KO) {
      const pO = Math.max(1, Math.round(KO));
      if (pO < 60) return OO("buildAFactory2Game:durationSeconds", {
        seconds: String(pO)
      });
      const XO = Math.round(pO / 60);
      if (XO < 60) return OO("buildAFactory2Game:durationMinutes", {
        minutes: String(XO)
      });
      const bK = String(Math.floor(XO / 60));
      return XO % 60 === 0 ? OO("buildAFactory2Game:durationWholeHours", {
        hours: bK
      }) : OO("buildAFactory2Game:durationHours", {
        hours: bK,
        minutes: String(XO % 60)
      })
    }
    const al = "(max-height: 420px), (max-width: 650px)";

    function oe() {
      return "undefined" !== typeof window && window.matchMedia(al).matches
    }

    function Fe(OO) {
      const KO = window.matchMedia(al),
        pO = () => {
          OO(KO.matches)
        };
      return KO.addEventListener("change", pO), () => {
        KO.removeEventListener("change", pO)
      }
    }
    var Ve = pO(976);

    function Le(OO, KO) {
      return null !== OO && OO > KO + 1
    }

    function Qe(OO) {
      const KO = 100 * OO;
      return String(KO <= 0 || KO >= 1 ? Math.round(KO) : Math.max(.1, Math.round(10 * KO) / 10))
    }

    function zl(OO) {
      let {
        item: KO,
        amount: pO
      } = OO;
      return (0, Ve.jsxs)("span", {
        className: "Baf2RecipeItem",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2RecipeIcon",
          children: (0, Ve.jsx)(fb.b, {
            itemName: KO,
            amount: 0
          })
        }), pO > 1 && (0, Ve.jsxs)("span", {
          className: "Baf2RecipeAmount",
          children: ["\xd7", pO]
        })]
      })
    }

    function Ae(OO) {
      let {
        label: KO,
        names: pO
      } = OO;
      const [bK, eO] = (0, XO.useState)(!1), lO = pO.join(" / ");
      return (0, Ve.jsxs)(Ve.Fragment, {
        children: [(0, Ve.jsx)("button", {
          type: "button",
          className: "Baf2RecipeMore",
          title: lO,
          "aria-expanded": bK,
          onClick: () => {
            eO(!bK)
          },
          children: KO
        }), bK && (0, Ve.jsx)("span", {
          className: "Baf2RecipeAlts",
          children: lO
        })]
      })
    }

    function fe(OO) {
      let {
        tier: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)(), {
        key: XO,
        params: bK
      } = oO(KO, {
        tier: "recipeLockedTier",
        stage: "recipeLockedStage",
        atomic: "recipeLockedAtomic"
      }), eO = pO(`buildAFactory2Game:${XO}`, bK);
      return (0, Ve.jsxs)("span", {
        className: "Baf2TierTag Baf2RecipeLock",
        children: [(0, Ve.jsx)(Ab.d, {
          name: "lock"
        }), eO]
      })
    }
    const de = (0, XO.createContext)(null);

    function Te() {
      const {
        t: OO
      } = (0, ze.D)(), KO = (0, XO.useContext)(de);
      return (0, XO.useEffect)((() => null === KO || void 0 === KO ? void 0 : KO()), [KO]), (0, Ve.jsx)("span", {
        className: "Baf2RecipeQuest",
        role: "img",
        title: OO("buildAFactory2Game:recipeForQuest"),
        "aria-label": OO("buildAFactory2Game:recipeForQuest"),
        children: "!"
      })
    }

    function Ne(OO) {
      let {
        title: KO,
        count: pO,
        children: bK,
        startOpen: eO = !0
      } = OO;
      const {
        t: lO
      } = (0, ze.D)(), [vK, CO] = (0, XO.useState)((() => eO && !oe())), [hO, DO] = (0, XO.useState)(0), MO = (0, XO.useCallback)((() => (DO((OO => OO + 1)), () => {
        DO((OO => OO - 1))
      })), []);
      return (0, Ve.jsxs)("div", {
        className: Fb()("Baf2Recipes", {
          Open: vK
        }),
        children: [(0, Ve.jsxs)("button", {
          type: "button",
          className: "Baf2RecipesToggle SmallTextBold",
          onClick: () => {
            CO(!vK)
          },
          "aria-expanded": vK,
          children: [lO("buildAFactory2Game:recipesToggle", {
            title: KO,
            count: String(pO)
          }), (0, Ve.jsx)("span", {
            className: "Baf2RecipesChevron",
            children: vK ? "\u25be" : "\u25b8"
          })]
        }), vK && (0, Ve.jsxs)(de.Provider, {
          value: MO,
          children: [(0, Ve.jsx)("ul", {
            className: "Baf2RecipeList",
            children: bK
          }), hO > 0 && (0, Ve.jsxs)("div", {
            className: "Baf2RecipeQuestNote",
            children: [(0, Ve.jsx)("span", {
              className: "Baf2RecipeQuest",
              "aria-hidden": "true",
              children: "!"
            }), lO("buildAFactory2Game:recipeForQuest")]
          })]
        })]
      })
    }
    const Ie = "buildAFactory2Game:",
      yl = new Set(["Coal Deposit", "Iron Deposit", "Stone Deposit"]);
    const gl = {
        "Moonstone Dust": "Star Alloy",
        Fertiliser: "Crop Harvester"
      },
      ue = {
        "Uranium Grit": eO,
        "Raw Uranium": eO
      };

    function Ee(OO) {
      var KO;
      return null !== (KO = ue[OO]) && void 0 !== KO ? KO : Math.max(WO(OO), gl[OO] ? WO(gl[OO]) : 1, function(OO) {
        const KO = bK.findIndex((KO => KO.cost.some((KO => KO.item === OO))));
        return KO > eO ? KO : 1
      }(OO))
    }

    function jl(OO, KO) {
      return Ye(KO) ? Ee(KO) : function(OO) {
        if (yl.has(OO)) return 1;
        const KO = bK.findIndex((KO => KO.newDeposits.some((KO => {
          let {
            block: pO
          } = KO;
          return pO === OO
        }))));
        return KO < 0 ? 1 : KO + 1
      }(OO)
    }

    function Ye(OO) {
      return OO in ue || MO(Ee(OO)) > 0
    }

    function we(OO, KO) {
      return cp(OO, {
        coupled: !1,
        taught: null,
        atomic: vK() && KO >= 11
      }).recipes
    }

    function il(OO, KO) {
      const pO = aK(OO, KO, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : MO(OO) > 0);
      return "open" === pO || "locked" === pO
    }

    function rl(OO, KO) {
      return OO.map(((OO, pO) => ({
        value: OO,
        idx: pO,
        tier: KO(OO)
      }))).sort(((OO, KO) => OO.tier - KO.tier || OO.idx - KO.idx)).map((OO => {
        let {
          value: KO
        } = OO;
        return KO
      }))
    }

    function Pe(OO, KO, pO) {
      const XO = aK(OO, KO);
      if ("hidden" === XO || "open" === XO) return null;
      if ("teaser" === XO) return {
        tag: {
          translationKey: `${Ie}${pO?"craftLockAtomicTeaserShort":"craftLockAtomicTeaser"}`
        },
        reason: {
          translationKey: `${Ie}recipeLockedAtomicTeaser`
        },
        hideIngredients: !0
      };
      const bK = oO(OO, {
          tier: pO ? "craftLockTierShort" : "craftLockTier",
          stage: "craftLockStage",
          atomic: "craftLockAtomic"
        }),
        eO = oO(OO, {
          tier: "recipeLockedTier",
          stage: "recipeLockedStage",
          atomic: "recipeLockedAtomic"
        });
      return {
        tag: {
          translationKey: `${Ie}${bK.key}`,
          params: bK.params
        },
        reason: {
          translationKey: `${Ie}${eO.key}`,
          params: eO.params
        }
      }
    }

    function ml(OO) {
      return !pe(OO)
    }

    function se(OO) {
      let {
        seconds: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)();
      return (0, Ve.jsx)(Ne, {
        title: pO("buildAFactory2Game:recipesCuts", {
          seconds: KO
        }),
        count: 1,
        children: (0, Ve.jsxs)("li", {
          className: "Baf2Recipe",
          children: [(0, Ve.jsx)(zl, {
            item: "Maple Sapling",
            amount: 1
          }), (0, Ve.jsx)("span", {
            className: "Baf2RecipeArrow",
            children: "\u2192"
          }), (0, Ve.jsx)(zl, {
            item: "Maple Log",
            amount: 1
          }), (0, Ve.jsx)("span", {
            className: "Baf2RecipeName",
            children: pO("buildAFactory2Game:recipeAnyTree")
          })]
        })
      })
    }

    function He(OO) {
      let {
        fertilised: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)();
      return (0, Ve.jsxs)(Ne, {
        title: pO("buildAFactory2Game:recipesHarvests"),
        count: 2,
        children: [(0, Ve.jsxs)("li", {
          className: "Baf2Recipe",
          children: [(0, Ve.jsx)(zl, {
            item: "Wheat Seeds",
            amount: 1
          }), (0, Ve.jsx)("span", {
            className: "Baf2RecipeArrow",
            children: "\u2192"
          }), (0, Ve.jsx)(zl, {
            item: "Wheat",
            amount: 1
          }), (0, Ve.jsx)(zl, {
            item: "Wheat Seeds",
            amount: 1
          }), (0, Ve.jsx)("span", {
            className: "Baf2RecipeName",
            children: pO("buildAFactory2Game:recipeField")
          })]
        }), (0, Ve.jsxs)("li", {
          className: Fb()("Baf2Recipe", {
            InUse: KO
          }),
          children: [(0, Ve.jsx)(zl, {
            item: "Fertiliser",
            amount: 1
          }), (0, Ve.jsx)("span", {
            className: "Baf2RecipeName",
            children: pO("buildAFactory2Game:recipeFieldFertiliser")
          })]
        })]
      })
    }

    function Re(OO) {
      let {
        tier: KO,
        seconds: pO
      } = OO;
      const {
        t: XO
      } = (0, ze.D)(), bK = function(OO) {
        return OO >= 5 ? VK : FK
      }(KO);
      return (0, Ve.jsx)(Ne, {
        title: XO("buildAFactory2Game:recipesBringsUp", {
          seconds: pO
        }),
        count: bK.length,
        children: bK.map((OO => {
          let {
            item: KO,
            chance: pO
          } = OO;
          return (0, Ve.jsxs)("li", {
            className: "Baf2Recipe",
            children: [(0, Ve.jsx)(zl, {
              item: KO,
              amount: 1
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeName",
              children: xe(XO, KO)
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeBonus",
              children: XO("buildAFactory2Game:recipeChance", {
                percent: Qe(pO)
              })
            })]
          }, KO)
        }))
      })
    }

    function Se(OO) {
      let {
        tier: KO,
        seconds: pO,
        noSeeds: XO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)(), eO = Bb(), lO = ee(KO, XO ? ml : void 0), vK = XO && ee(KO).length > lO.length, CO = Ke(KO);
      return (0, Ve.jsxs)(Ne, {
        title: bK("buildAFactory2Game:recipesRecycles", {
          seconds: pO
        }),
        count: lO.length,
        children: [lO.map((OO => {
          let {
            find: KO,
            chance: pO
          } = OO;
          return (0, Ve.jsxs)("li", {
            className: "Baf2Recipe",
            children: [eO.has(KO.item) && (0, Ve.jsx)(Te, {}), (0, Ve.jsx)(zl, {
              item: KO.item,
              amount: KO.amount
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeName",
              children: xe(bK, KO.item)
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeBonus",
              children: bK("buildAFactory2Game:recipeChance", {
                percent: Qe(pO)
              })
            })]
          }, KO.item)
        })), vK && (0, Ve.jsx)("li", {
          className: "Baf2Recipe",
          children: (0, Ve.jsx)("span", {
            className: "Baf2RecipeName",
            children: bK("buildAFactory2Game:recipesRecyclerNoSeeds")
          })
        }), CO && (0, Ve.jsx)("li", {
          className: "Baf2Recipe",
          children: (0, Ve.jsx)("span", {
            className: "Baf2RecipeName",
            children: bK("buildAFactory2Game:recipesRecyclerPity", {
              amount: String(2)
            })
          })
        })]
      })
    }

    function Je(OO) {
      let {
        tier: KO,
        seconds: pO
      } = OO;
      const {
        t: XO
      } = (0, ze.D)(), bK = Object.entries(te).filter((OO => {
        let [, {
          item: pO
        }] = OO;
        return il(Ee(pO), KO, Ye(pO))
      }));
      return (0, Ve.jsx)(Ne, {
        title: XO("buildAFactory2Game:recipesRecyclesSeeds", {
          seconds: pO
        }),
        count: bK.length,
        children: bK.map((OO => {
          let [KO, {
            item: pO,
            amount: bK
          }] = OO;
          return (0, Ve.jsxs)("li", {
            className: "Baf2Recipe",
            children: [(0, Ve.jsx)(zl, {
              item: KO,
              amount: 1
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeArrow",
              children: "\u2192"
            }), (0, Ve.jsx)(zl, {
              item: pO,
              amount: bK
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeName",
              children: xe(XO, pO)
            })]
          }, KO)
        }))
      })
    }

    function cl(OO) {
      let {
        tier: KO,
        seconds: pO
      } = OO;
      const {
        t: XO
      } = (0, ze.D)(), bK = Bb(), eO = rl(Object.entries(kp).filter((OO => {
        let [pO, XO] = OO;
        return il(jl(pO, XO), KO, Ye(XO))
      })), (OO => {
        let [KO, pO] = OO;
        return jl(KO, pO)
      }));
      return (0, Ve.jsx)(Ne, {
        title: XO("buildAFactory2Game:recipesDigs", {
          seconds: pO
        }),
        count: eO.length,
        children: eO.map((OO => {
          let [pO, eO] = OO;
          const lO = jl(pO, eO),
            vK = lO > KO ? lO : null,
            CO = UK[pO],
            hO = null === vK && bK.has(eO);
          return (0, Ve.jsxs)("li", {
            className: Fb()("Baf2Recipe", {
              Locked: null !== vK,
              Far: Le(vK, KO)
            }),
            children: [hO && (0, Ve.jsx)(Te, {}), (0, Ve.jsx)(zl, {
              item: pO,
              amount: 1
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeArrow",
              children: "\u2192"
            }), (0, Ve.jsx)(zl, {
              item: eO,
              amount: 1
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeName",
              children: xe(XO, eO)
            }), void 0 !== CO && (0, Ve.jsx)("span", {
              className: "Baf2RecipeMore",
              children: XO("buildAFactory2Game:recipesDigsFixed", {
                perMin: String(6e4 / CO)
              })
            }), null !== vK && (0, Ve.jsx)(fe, {
              tier: vK
            })]
          }, pO)
        }))
      })
    }

    function Be(OO) {
      var KO;
      let {
        def: pO,
        seconds: XO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)();
      return (0, Ve.jsx)("ul", {
        className: "Baf2RecipeList Baf2GeneratorRecipe",
        children: (0, Ve.jsxs)("li", {
          className: "Baf2Recipe",
          children: [(null !== (KO = pO.fuels) && void 0 !== KO ? KO : []).map((OO => (0, Ve.jsx)(zl, {
            item: OO,
            amount: 1
          }, OO))), (0, Ve.jsx)("span", {
            className: "Baf2RecipeArrow",
            children: "\u2192"
          }), (0, Ve.jsxs)("span", {
            className: "Baf2RecipeName",
            children: [(0, Ve.jsx)(Ab.d, {
              name: "bolt"
            }), bK("buildAFactory2Game:recipePower", {
              power: tK(pO.powerMade),
              seconds: XO
            })]
          })]
        })
      })
    }

    function Ze(OO) {
      let {
        def: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)();
      return (0, Ve.jsx)("ul", {
        className: "Baf2RecipeList Baf2GeneratorRecipe",
        children: (0, Ve.jsx)("li", {
          className: "Baf2Recipe",
          children: (0, Ve.jsxs)("span", {
            className: "Baf2RecipeName",
            children: [(0, Ve.jsx)(Ab.d, {
              name: "bolt"
            }), pO("buildAFactory2Game:recipeMixer", {
              cryo: Ce((0, kK.D)(KO, KO.cryoMade), "")
            })]
          })
        })
      })
    }

    function Ge(OO) {
      let {
        def: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)();
      return (0, Ve.jsx)("ul", {
        className: "Baf2RecipeList Baf2GeneratorRecipe",
        children: (0, Ve.jsx)("li", {
          className: "Baf2Recipe",
          children: (0, Ve.jsxs)("span", {
            className: "Baf2RecipeName",
            children: [(0, Ve.jsx)(Ab.d, {
              name: "bolt"
            }), pO("buildAFactory2Game:recipeCondenser", {
              power: Ce((0, kK.D)(KO, KO.powerPerOp), ""),
              water: Ce((0, kK.D)(KO, KO.fluidMade), "")
            })]
          })
        })
      })
    }

    function ql(OO) {
      let {
        kind: KO,
        def: pO,
        input: XO,
        tier: bK,
        noSeeds: eO = !1
      } = OO;
      const lO = String(pO.opMs / 1e3);
      return xp(pO) ? (0, Ve.jsx)(se, {
        seconds: lO
      }) : pO.field ? (0, Ve.jsx)(He, {
        fertilised: null !== XO
      }) : pO.table ? (0, Ve.jsx)(Re, {
        tier: bK,
        seconds: lO
      }) : pO.recycles ? (0, Ve.jsxs)(Ve.Fragment, {
        children: [(0, Ve.jsx)(Se, {
          tier: bK,
          seconds: lO,
          noSeeds: eO
        }), (0, Ve.jsx)(Je, {
          tier: bK,
          seconds: lO
        })]
      }) : qp(pO) ? (0, Ve.jsx)(cl, {
        tier: bK,
        seconds: lO
      }) : void 0 !== pO.fluidMade ? (0, Ve.jsx)(Ge, {
        def: pO
      }) : void 0 !== pO.cryoMade ? (0, Ve.jsx)(Ze, {
        def: pO
      }) : void 0 !== pO.powerMade ? (0, Ve.jsx)(Be, {
        def: pO,
        seconds: lO
      }) : (0, Ve.jsx)(xl, {
        kind: KO,
        input: XO,
        tier: bK,
        seconds: lO
      })
    }

    function xl(OO) {
      let {
        kind: KO,
        input: pO,
        tier: XO,
        seconds: bK
      } = OO;
      const {
        t: eO
      } = (0, ze.D)(), lO = Bb(), vK = rl(function(OO) {
        const KO = new Map;
        for (const bK of OO) {
          var pO, XO;
          const OO = [bK.output, bK.outputAmount, bK.inputAmount, null === (pO = bK.bonus) || void 0 === pO ? void 0 : pO.item, null === (XO = bK.bonus) || void 0 === XO ? void 0 : XO.chance].join("|"),
            eO = KO.get(OO);
          eO ? eO.inputs.push(bK.input) : KO.set(OO, {
            inputs: [bK.input],
            inputAmount: bK.inputAmount,
            output: bK.output,
            outputAmount: bK.outputAmount,
            bonus: bK.bonus
          })
        }
        return [...KO.values()]
      }(we(KO, XO).filter(pp)), (OO => Ee(OO.output))).filter((OO => il(Ee(OO.output), XO, Ye(OO.output))));
      return (0, Ve.jsx)(Ne, {
        title: eO("buildAFactory2Game:recipesEach", {
          seconds: bK
        }),
        count: vK.length,
        children: vK.map((OO => {
          const KO = null !== pO && OO.inputs.includes(pO),
            bK = OO.inputs.length > 3 ? [KO ? pO : OO.inputs[0]] : OO.inputs,
            vK = Ee(OO.output) > XO ? Ee(OO.output) : null,
            CO = null === vK && lO.has(OO.output);
          return (0, Ve.jsxs)("li", {
            className: Fb()("Baf2Recipe", {
              InUse: KO,
              Locked: null !== vK,
              Far: Le(vK, XO)
            }),
            children: [CO && (0, Ve.jsx)(Te, {}), bK.map(((KO, pO) => (0, Ve.jsxs)("span", {
              className: "Baf2RecipeInput",
              children: [pO > 0 && (0, Ve.jsx)("span", {
                className: "Baf2RecipeOr",
                children: "/"
              }), (0, Ve.jsx)(zl, {
                item: KO,
                amount: OO.inputAmount
              })]
            }, KO))), bK.length < OO.inputs.length && (0, Ve.jsx)(Ae, {
              label: eO("buildAFactory2Game:recipeMore", {
                count: String(OO.inputs.length - bK.length)
              }),
              names: OO.inputs.filter((OO => !bK.includes(OO))).map((OO => xe(eO, OO)))
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeArrow",
              children: "\u2192"
            }), (0, Ve.jsx)(zl, {
              item: OO.output,
              amount: OO.outputAmount
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeName",
              children: xe(eO, OO.output)
            }), OO.bonus && (0, Ve.jsxs)("span", {
              className: "Baf2RecipeBonus",
              children: [eO("buildAFactory2Game:recipeBonus", {
                percent: Qe(OO.bonus.chance)
              }), (0, Ve.jsx)(zl, {
                item: OO.bonus.item,
                amount: 1
              })]
            }), null !== vK && (0, Ve.jsx)(fe, {
              tier: vK
            })]
          }, `${OO.output}|${OO.inputs[0]}`)
        }))
      })
    }

    function ne(OO) {
      let {
        taught: KO,
        tier: pO
      } = OO;
      const {
        t: XO
      } = (0, ze.D)(), bK = Bb(), eO = rl(Object.values(SK), (OO => OO.tier)).filter((OO => il(OO.tier, pO)));
      return (0, Ve.jsx)(Ne, {
        title: XO("buildAFactory2Game:benchCanMake"),
        count: eO.length,
        startOpen: !1,
        children: eO.map((OO => {
          const eO = OO.tier > pO,
            lO = !eO && bK.has(OO.output);
          return (0, Ve.jsxs)("li", {
            className: Fb()("Baf2Recipe", {
              InUse: OO.output === KO,
              Locked: eO,
              Far: Le(eO ? OO.tier : null, pO)
            }),
            children: [lO && (0, Ve.jsx)(Te, {}), (0, Ve.jsx)(zl, {
              item: OO.output,
              amount: OO.outputAmount
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeName",
              children: xe(XO, OO.output)
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeArrow",
              children: "\u2190"
            }), OO.inputs.map((OO => (0, Ve.jsx)(zl, {
              item: OO.item,
              amount: OO.amount
            }, OO.item))), eO && (0, Ve.jsx)(fe, {
              tier: OO.tier
            })]
          }, OO.output)
        }))
      })
    }
    var We, tl, kl, Ue, Ol;
    const Kl = yp.Generator,
      pl = ["buildAFactory2Game:powerCoupledName", "buildAFactory2Game:powerCoupledNameAdvanced", "buildAFactory2Game:powerCoupledNameNova"],
      Xl = 1e3 * (null !== (We = Kl.powerMade) && void 0 !== We ? We : 0) / Kl.opMs,
      bv = Math.min(...(null !== (tl = Kl.fuels) && void 0 !== tl ? tl : []).map((OO => tp[OO]))) / 1e3,
      el = yp["Volt Engine"],
      ll = 1e3 * (null !== (kl = el.powerMade) && void 0 !== kl ? kl : 0) / el.opMs,
      vv = tp[null !== (Ue = null === (Ol = el.fuels) || void 0 === Ol ? void 0 : Ol[0]) && void 0 !== Ue ? Ue : ""] / 1e3;

    function Cl(OO) {
      let {
        item: KO,
        label: pO,
        value: XO,
        note: bK,
        dim: eO
      } = OO;
      return (0, Ve.jsxs)("li", {
        className: Fb()("Baf2PowerRow", {
          Dim: eO
        }),
        children: [(0, Ve.jsx)("span", {
          className: "Baf2PowerRowIcon",
          children: (0, Ve.jsx)(fb.b, {
            itemName: KO,
            amount: 0
          })
        }), (0, Ve.jsxs)("span", {
          className: "Baf2PowerRowText",
          children: [(0, Ve.jsx)("span", {
            className: "Baf2PowerRowLabel",
            children: pO
          }), bK && (0, Ve.jsx)("span", {
            className: "Baf2PowerRowNote",
            children: bK
          })]
        }), (0, Ve.jsx)("span", {
          className: "Baf2PowerRowValue",
          children: XO
        })]
      })
    }

    function hl(OO, KO, pO, XO) {
      var bK;
      const eO = void 0 === XO ? yp[OO] : function(OO, KO) {
          if (null === KO) return OO;
          let pO = qK.get(KO);
          return pO || (pO = {
            ...OO,
            powerPerOp: GO(OO, KO),
            farmMob: KO
          }, qK.set(KO, pO)), pO
        }(yp[OO], XO),
        lO = KO && eO.couplable ? rp(eO, pO) : eO;
      return 1e3 * (null !== (bK = lO.powerPerOp) && void 0 !== bK ? bK : 0) / lO.opMs
    }

    function Dl(OO) {
      var KO, pO, XO, bK, eO, lO, vK, CO;
      let {
        message: hO
      } = OO;
      const {
        t: DO
      } = (0, ze.D)(), MO = (OO, KO) => DO("buildAFactory2Game:powerPerSecond", {
        rate: Ce(OO, KO)
      }), [aK, oO] = hO.baf2PowerGenerators, FO = hO.baf2PowerGeneratorFuel, VO = hO.baf2PowerSunPanels, LO = null !== (KO = hO.baf2PowerSunShare) && void 0 !== KO ? KO : 1, QO = hO.baf2PowerVaults, zK = hO.baf2PowerUsers, [AO, fO] = null !== (pO = hO.baf2PowerEngines) && void 0 !== pO ? pO : [0, 0], dO = null !== (XO = hO.baf2PowerEngineCells) && void 0 !== XO ? XO : 0, TO = null !== (bK = hO.baf2PowerPads) && void 0 !== bK ? bK : 0, NO = null !== (eO = hO.baf2PowerCharge) && void 0 !== eO ? eO : 0, [IO, yK] = null !== (lO = hO.baf2PowerReactors) && void 0 !== lO ? lO : [0, 0], [gK, uO] = null !== (vK = hO.baf2PowerBatteries) && void 0 !== vK ? vK : [0, 0];
      let EO = DO("buildAFactory2Game:powerEngineCells", {
        amount: String(dO)
      });
      dO > 0 && fO > 0 && (EO = DO("buildAFactory2Game:powerEngineCellsTime", {
        amount: String(dO),
        time: Me(DO, dO * vv / fO)
      }));
      let jK = DO("buildAFactory2Game:powerGeneratorFuel", {
        amount: String(FO)
      });
      FO > 0 && oO > 0 && (jK = DO("buildAFactory2Game:powerGeneratorFuelTime", {
        amount: String(FO),
        time: Me(DO, FO * bv / oO)
      }));
      const YO = aK + AO + VO + IO;
      return (0, Ve.jsxs)("div", {
        className: "Baf2PowerDetails",
        children: [(0, Ve.jsxs)("section", {
          children: [(0, Ve.jsxs)("h3", {
            children: [DO("buildAFactory2Game:powerMaking"), (0, Ve.jsx)("span", {
              children: MO(hO.baf2PowerMadePerS, "+")
            })]
          }), (0, Ve.jsxs)("ul", {
            children: [0 === YO && (0, Ve.jsx)("li", {
              className: "Baf2PowerEmpty",
              children: DO("buildAFactory2Game:powerNoMakers")
            }), aK > 0 && (0, Ve.jsx)(Cl, {
              item: "Generator",
              label: `${xe(DO,"Generator")} \xd7${aK}`,
              note: `${DO("buildAFactory2Game:powerRunning",{amount:String(oO)})} \xb7 ${jK}`,
              value: MO(oO * Xl, "+"),
              dim: 0 === oO
            }), AO > 0 && (0, Ve.jsx)(Cl, {
              item: "Volt Engine",
              label: `${xe(DO,"Volt Engine")} \xd7${AO}`,
              note: `${DO("buildAFactory2Game:powerRunning",{amount:String(fO)})} \xb7 ${EO}`,
              value: MO(fO * ll, "+"),
              dim: 0 === fO
            }), VO > 0 && (0, Ve.jsx)(Cl, {
              item: "Solar Panel",
              label: `${xe(DO,"Solar Panel")} \xd7${VO}`,
              note: DO(LO < 1 ? "buildAFactory2Game:powerSunNoteNight" : "buildAFactory2Game:powerSunNote", {
                rate: String(4),
                night: String(2)
              }),
              value: MO(4 * VO * LO, "+")
            }), IO > 0 && (0, Ve.jsx)(Cl, {
              item: "Reactor Frame",
              label: `${DO("buildAFactory2Game:powerReactors")} \xd7${IO}`,
              note: DO("buildAFactory2Game:powerRunning", {
                amount: String(yK)
              }),
              value: MO(null !== (CO = hO.baf2PowerReactorPerS) && void 0 !== CO ? CO : 0, "+"),
              dim: 0 === yK
            })]
          })]
        }), (0, Ve.jsxs)("section", {
          children: [(0, Ve.jsxs)("h3", {
            children: [DO("buildAFactory2Game:powerStorage"), (0, Ve.jsx)("span", {
              children: tK(hO.baf2PowerCap)
            })]
          }), (QO > 0 || gK > 0) && (0, Ve.jsxs)("ul", {
            children: [QO > 0 && (0, Ve.jsx)(Cl, {
              item: "Charge Vault",
              label: `${xe(DO,"Charge Vault")} \xd7${QO}`,
              value: `+${tK(8e3*QO)}`
            }), gK > 0 && (0, Ve.jsx)(Cl, {
              item: "Battery Cell",
              label: `${DO("buildAFactory2Game:powerBatteries")} \xd7${gK}`,
              value: `+${tK(uO)}`
            })]
          })]
        }), (0, Ve.jsxs)("section", {
          children: [(0, Ve.jsxs)("h3", {
            children: [DO("buildAFactory2Game:powerUsing"), (0, Ve.jsx)("span", {
              children: MO(hO.baf2PowerUsedPerS, "\u2212")
            })]
          }), (0, Ve.jsxs)("ul", {
            children: [0 === zK.length && 0 === TO && 0 === NO && (0, Ve.jsx)("li", {
              className: "Baf2PowerEmpty",
              children: DO("buildAFactory2Game:powerNoUsers")
            }), zK.map((OO => {
              let [KO, pO, XO, bK, eO = 1, lO] = OO, vK = pO ? DO(pl[eO - 1], {
                name: xe(DO, KO)
              }) : xe(DO, KO);
              return void 0 !== lO && (vK = DO("buildAFactory2Game:powerFarmName", {
                name: vK,
                mob: DO(cK(lO))
              })), (0, Ve.jsx)(Cl, {
                item: KO,
                label: `${vK} \xd7${XO}`,
                note: DO("buildAFactory2Game:powerRunning", {
                  amount: String(bK)
                }),
                value: bK > 0 ? MO(bK * hl(KO, pO, eO, lO), "\u2212") : DO("buildAFactory2Game:powerIdle"),
                dim: 0 === bK
              }, `${KO}|${pO}|${eO}|${lO}`)
            })), TO > 0 && (0, Ve.jsx)(Cl, {
              item: "Charging Pad",
              label: `${xe(DO,"Charging Pad")} \xd7${TO}`,
              value: DO("buildAFactory2Game:powerPadRate", {
                amount: String(60)
              })
            }), NO > 0 && (0, Ve.jsx)(Cl, {
              item: "Homestead Core",
              label: DO("buildAFactory2Game:powerCharge"),
              value: MO(NO, "\u2212")
            }), hO.baf2PowerStarved > 0 && (0, Ve.jsxs)("li", {
              className: "Baf2PowerStarved",
              children: [(0, Ve.jsx)(Ab.d, {
                name: "triangle-exclamation"
              }), DO("buildAFactory2Game:powerStarved", {
                amount: String(hO.baf2PowerStarved)
              })]
            })]
          })]
        })]
      })
    }
    var Ml = pO(3719),
      av = pO(1271);
    class ol {
      constructor() {
        this.message = null, this.listeners = new Set
      }
      set(OO) {
        this.message = OO;
        for (const KO of this.listeners) KO()
      }
      get() {
        return this.message
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
    }
    class Fl extends ol {}

    function Vl(OO, KO) {
      const pO = () => {
          const pO = OO.get();
          if (!pO || !KO) return pO;
          const [XO, bK, eO] = pO.baf2PowerAt;
          return XO === KO[0] && bK === KO[1] && eO === KO[2] ? pO : null
        },
        [bK, eO] = (0, XO.useState)(pO);
      return (0, XO.useEffect)((() => (eO(pO()), OO.subscribe((() => {
        eO(pO())
      })))), [OO, ...null !== KO && void 0 !== KO ? KO : []]), bK
    }

    function Ll(OO) {
      return {
        stored: OO.baf2PowerStored,
        cap: OO.baf2PowerCap,
        madePerS: OO.baf2PowerMadePerS,
        usedPerS: OO.baf2PowerUsedPerS
      }
    }

    function Ql(OO) {
      let {
        stored: KO,
        cap: pO
      } = OO;
      return (0, Ve.jsx)("div", {
        className: "Baf2PowerBar",
        children: (0, Ve.jsx)("div", {
          style: {
            width: `${Math.min(100,100*KO/Math.max(1,pO))}%`
          }
        })
      })
    }

    function zv(OO) {
      let {
        figures: KO,
        labelled: pO = !1
      } = OO;
      const {
        t: XO
      } = (0, ze.D)(), bK = KO.madePerS - KO.usedPerS, {
        text: eO,
        draining: lO
      } = function(OO, KO) {
        let {
          stored: pO,
          cap: XO,
          madePerS: bK,
          usedPerS: eO
        } = KO;
        const lO = bK - eO;
        return pO >= XO ? {
          text: OO("buildAFactory2Game:powerFull"),
          draining: !1
        } : lO > .05 ? {
          text: OO("buildAFactory2Game:powerFullIn", {
            time: Me(OO, (XO - pO) / lO)
          }),
          draining: !1
        } : lO < -.05 ? {
          text: OO("buildAFactory2Game:powerEmptyIn", {
            time: Me(OO, pO / -lO)
          }),
          draining: !0
        } : {
          text: OO("buildAFactory2Game:powerSteady"),
          draining: !1
        }
      }(XO, KO);
      return (0, Ve.jsxs)("div", {
        className: "Baf2PowerHeadline",
        children: [(0, Ve.jsx)(Ql, {
          stored: KO.stored,
          cap: KO.cap
        }), (0, Ve.jsxs)("div", {
          className: "Baf2PowerNumbers",
          children: [(0, Ve.jsx)("span", {
            children: XO(pO ? "buildAFactory2Game:powerStoredLabelled" : "buildAFactory2Game:powerStored", {
              stored: tK(KO.stored),
              cap: tK(KO.cap)
            })
          }), (0, Ve.jsxs)("span", {
            className: Fb()("Baf2PowerNet", {
              Draining: lO
            }),
            children: [XO("buildAFactory2Game:powerPerSecond", {
              rate: Ce(Math.abs(bK), bK < 0 ? "\u2212" : "+")
            }), " \xb7 ", eO]
          })]
        })]
      })
    }

    function Al(OO) {
      let {
        stored: KO,
        cap: pO,
        rates: XO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)();
      return XO ? (0, Ve.jsx)("div", {
        className: "Baf2PowerStrip",
        children: (0, Ve.jsx)(zv, {
          figures: {
            stored: KO,
            cap: pO,
            madePerS: XO[0],
            usedPerS: XO[1]
          },
          labelled: !0
        })
      }) : (0, Ve.jsx)("div", {
        className: "Baf2PowerStrip",
        children: (0, Ve.jsxs)("div", {
          className: "Baf2PowerHeadline",
          children: [(0, Ve.jsx)(Ql, {
            stored: KO,
            cap: pO
          }), (0, Ve.jsx)("div", {
            className: "Baf2PowerNumbers",
            children: (0, Ve.jsx)("span", {
              children: bK("buildAFactory2Game:powerStoredLabelled", {
                stored: tK(KO),
                cap: tK(pO)
              })
            })
          })]
        })
      })
    }

    function fl(OO) {
      let {
        store: KO,
        close: pO
      } = OO;
      const {
        t: XO
      } = (0, ze.D)(), bK = Vl(KO);
      return (0, Ve.jsx)(Ml.d, {
        close: pO,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay",
        children: (0, Ve.jsxs)("section", {
          className: "Baf2Panel Baf2PowerPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2PowerTitle",
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsxs)("div", {
              children: [(0, Ve.jsx)("h2", {
                id: "baf2PowerTitle",
                children: XO("buildAFactory2Game:powerTitle")
              }), (0, Ve.jsx)("p", {
                children: XO("buildAFactory2Game:powerSubtitle")
              })]
            }), (0, Ve.jsx)(av.i, {
              onClick: pO
            })]
          }), bK && (0, Ve.jsxs)("div", {
            className: "Baf2PowerBody",
            children: [(0, Ve.jsx)(zv, {
              figures: Ll(bK)
            }), (0, Ve.jsx)(Dl, {
              message: bK
            })]
          })]
        })
      })
    }

    function dl(OO) {
      var KO;
      let {
        kind: pO,
        def: bK,
        hiO: eO,
        power: lO,
        stored: vK,
        cap: CO
      } = OO;
      const {
        t: hO
      } = (0, ze.D)(), DO = Vl(lO, eO), [MO, aK] = (0, XO.useState)(!1);
      return (0, Ve.jsxs)("div", {
        className: "Baf2GeneratorPower",
        children: [(0, Ve.jsx)(ql, {
          kind: pO,
          def: bK,
          input: null,
          tier: null !== (KO = null === DO || void 0 === DO ? void 0 : DO.baf2PowerTier) && void 0 !== KO ? KO : 1
        }), (0, Ve.jsx)("div", {
          className: "Baf2PowerCardTitle SmallTextBold",
          children: hO("buildAFactory2Game:powerTitle")
        }), DO && (0, Ve.jsx)(zv, {
          figures: Ll(DO)
        }), !DO && (0, Ve.jsx)(Al, {
          stored: vK,
          cap: CO,
          rates: null
        }), DO && (0, Ve.jsx)("button", {
          type: "button",
          className: "Baf2PowerDetailsToggle SmallTextBold",
          onClick: () => {
            aK(!MO)
          },
          "aria-expanded": MO,
          children: hO(MO ? "buildAFactory2Game:powerHideDetails" : "buildAFactory2Game:powerDetails")
        }), DO && MO && (0, Ve.jsx)(Dl, {
          message: DO
        })]
      })
    }
    const Tl = 2500,
      Nl = 17500,
      Il = `${dO} `;
    const yv = ["plan", "throttle"];

    function gv(OO) {
      if (OO.startsWith(`${AK} `)) return OO.slice(0, OO.lastIndexOf(" "));
      const KO = OO.split(" ");
      return KO[0] === XK && yv.includes(KO[4]) ? KO.slice(0, 5).join(" ") : null
    }
    class ul {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now;
        this.send = OO, this.now = KO, this.tokens = 5, this.refilledAt = void 0, this.pending = [], this.timer = null, this.vaO = 0, this.urgent = 0, this.reserves = 0, this.lastTicket = 0, this.leftTimes = new Map, this.refilledAt = KO()
      }
      enqueue(OO) {
        this.queue(OO, this.nextTicket());
        const KO = this.vaO + this.pending.length;
        return this.flush(), KO
      }
      track(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const pO = this.nextTicket();
        if (!KO.urgent) return this.queue(OO, pO), this.flush(), pO;
        const {
          supersedes: XO
        } = KO;
        for (let eO = this.pending.length - 1; eO >= this.urgent; eO--) {
          const KO = this.pending[eO];
          (KO.command === OO || null !== XO && void 0 !== XO && XO(KO.command)) && (this.pending.splice(eO, 1), this.markLeft(KO.tickets))
        }
        const bK = this.pending.findIndex((KO => {
          let {
            command: pO
          } = KO;
          return pO === OO
        }));
        return -1 !== bK ? this.pending[bK].tickets.push(pO) : (this.pending.splice(this.urgent, 0, {
          command: OO,
          tickets: [pO]
        }), this.urgent += 1), this.flush(), pO
      }
      leftAt(OO) {
        const KO = this.leftTimes.get(OO);
        return void 0 !== KO ? KO : this.pending.some((KO => {
          let {
            tickets: pO
          } = KO;
          return pO.includes(OO)
        })) ? null : -1 / 0
      }
      holdReserve() {
        this.reserves += 1;
        let OO = !0;
        return () => {
          OO && (OO = !1, this.reserves -= 1, this.flush())
        }
      }
      isWaitingLast(OO) {
        var KO;
        return (null === (KO = this.pending.at(-1)) || void 0 === KO ? void 0 : KO.command) === OO
      }
      sent() {
        return this.vaO
      }
      clear() {
        for (const {
            tickets: OO
          }
          of this.pending) this.markLeft(OO);
        this.pending.length = 0, this.urgent = 0, null !== this.timer && (clearTimeout(this.timer), this.timer = null)
      }
      nextTicket() {
        return this.lastTicket += 1, this.lastTicket
      }
      markLeft(OO) {
        const KO = this.now();
        for (const pO of OO) this.leftTimes.set(pO, KO);
        for (; this.leftTimes.size > 256;) this.leftTimes.delete(this.leftTimes.keys().next().value)
      }
      queue(OO, KO) {
        const pO = this.pending.length > this.urgent ? this.pending.at(-1) : void 0;
        if ((null === pO || void 0 === pO ? void 0 : pO.command) === OO) return void(! function(OO) {
          return OO === TO || OO.startsWith(`${fO} `) || OO.startsWith(`${RO} `)
        }(OO) ? pO.tickets.push(KO) : (this.pending.pop(), this.markLeft([...pO.tickets, KO])));
        const XO = void 0 === pO ? null : function(OO, KO) {
          const pO = `${UO} `;
          if (!OO.startsWith(pO) || !KO.startsWith(pO)) return null;
          const XO = pK(OO.slice(pO.length)),
            bK = pK(KO.slice(pO.length));
          return XO && bK && XO.item === bK.item ? KK(bK.seq, function(OO, KO) {
            const pO = OO => "number" === typeof OO ? OO : "one" === OO ? 1 : 99;
            return "fill" === OO || "fill" === KO ? "fill" : pO(OO) + pO(KO)
          }(XO.mode, bK.mode), bK.item) : null
        }(pO.command, OO);
        if (null !== XO && void 0 !== pO) return pO.command = XO, void pO.tickets.push(KO);
        const bK = gv(OO);
        if (null !== bK && void 0 !== pO && gv(pO.command) === bK) return pO.command = OO, void pO.tickets.push(KO);
        if (null !== pO && void 0 !== pO && pO.command.startsWith(Il) && OO.startsWith(Il)) {
          const XO = OO.slice(Il.length);
          if (pO.command.slice(Il.length).split(",").includes(XO)) return void pO.tickets.push(KO);
          const bK = `${pO.command},${XO}`;
          if (bK.length <= 119) return pO.command = bK, void pO.tickets.push(KO)
        }
        this.pending.push({
          command: OO,
          tickets: [KO]
        })
      }
      flush() {
        const OO = this.now();
        for (this.tokens = Math.min(5, this.tokens + (OO - this.refilledAt) / Tl), this.refilledAt = OO; this.pending.length > 0 && this.tokens >= this.tokensNeeded();) {
          this.tokens -= 1, this.vaO += 1, this.urgent > 0 && (this.urgent -= 1);
          const {
            command: OO,
            tickets: KO
          } = this.pending.shift();
          this.markLeft(KO), this.send(OO)
        }
        this.pending.length > 0 && null === this.timer && (this.timer = setTimeout((() => {
          this.timer = null, this.flush()
        }), Math.ceil((this.tokensNeeded() - this.tokens) * Tl)))
      }
      tokensNeeded() {
        return this.urgent > 0 || 0 === this.reserves ? 1 : 2
      }
    }
    class El {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now;
        this.queue = void 0, this.islandEdits = {
          count: 0,
          lastAtMs: -1 / 0
        }, this.queue = new ul(OO, KO)
      }
      send(OO) {
        return this.queue.enqueue(OO)
      }
      sent() {
        return this.queue.sent()
      }
      track(OO, KO) {
        return this.queue.track(OO, KO)
      }
      leftAt(OO) {
        return this.queue.leftAt(OO)
      }
      holdUrgentReserve() {
        return this.queue.holdReserve()
      }
      sendIslandEdit(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now();
        return this.queue.isWaitingLast(OO) || (this.islandEdits.count += 1), this.islandEdits.lastAtMs = KO, this.send(OO), this.islandEdits.count
      }
      syncIslandEdits(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now();
        const {
          islandEdits: pO
        } = this, XO = KO - pO.lastAtMs < Nl;
        pO.count = XO ? Math.max(pO.count, OO) : OO
      }
      clear() {
        this.queue.clear()
      }
    }
    const jv = (0, XO.createContext)(null);

    function Yl() {
      const OO = (0, XO.useContext)(jv);
      if (!OO) throw new Error("A Build a Factory 2 panel outside Baf2Menu");
      return OO
    }

    function wl(OO, KO) {
      return null !== KO && void 0 !== KO ? KO : 1 === OO
    }

    function iv(OO, KO) {
      return OO.every((OO => {
        var pO;
        let [XO, , bK] = OO;
        return !wl(bK, null === (pO = KO.get(XO)) || void 0 === pO ? void 0 : pO.Sp)
      }))
    }

    function rv(OO, KO, pO) {
      if (0 === OO.size) return OO;
      const XO = new Map(OO);
      for (const [bK, eO] of OO) {
        const OO = KO.find((OO => {
          let [KO] = OO;
          return KO === bK
        }));
        (!OO || eO.Sp === (1 === OO[2]) || eO.atMs < pO) && XO.delete(bK)
      }
      return XO
    }

    function Pl(OO) {
      var KO;
      let {
        hiO: pO,
        input: bK,
        drops: eO,
        seconds: lO
      } = OO;
      const {
        t: vK
      } = (0, ze.D)(), CO = Yl(), [hO, DO] = (0, XO.useState)(new Map);
      (0, XO.useEffect)((() => {
        eO && DO((OO => rv(OO, eO, Date.now() - Nl)))
      }), [eO]), (0, XO.useEffect)((() => {
        const OO = function(OO, KO) {
          let pO = null;
          for (const {
              atMs: XO
            }
            of OO.values()) pO = null === pO ? XO : Math.min(pO, XO);
          return null === pO ? null : pO + KO
        }(hO, Nl);
        if (null === OO || !eO) return;
        const KO = setTimeout((() => {
          DO((OO => rv(OO, eO, Date.now() - Nl)))
        }), Math.max(0, OO - Date.now()) + 1);
        return () => {
          clearTimeout(KO)
        }
      }), [hO, eO]);
      const MO = BO(bK),
        aK = null !== MO && null !== eO && iv(eO, hO),
        oO = function(OO, KO, pO) {
          return null === OO || null === KO || iv(KO, pO) ? 0 : HO[mK[OO]]
        }(MO, eO, hO);
      return (0, Ve.jsxs)(Ne, {
        title: vK("buildAFactory2Game:farmDropsTitle", {
          seconds: lO
        }),
        count: null !== (KO = null === eO || void 0 === eO ? void 0 : eO.length) && void 0 !== KO ? KO : 0,
        children: [oO > 0 && (0, Ve.jsx)("li", {
          className: "Baf2Recipe Baf2FarmPower SmallTextLight",
          children: vK("buildAFactory2Game:farmDropsPower", {
            power: String(oO)
          })
        }), (null === MO || !eO) && (0, Ve.jsx)("li", {
          className: "Baf2Recipe SmallTextLight",
          children: vK("buildAFactory2Game:farmDropsEmpty")
        }), aK && (0, Ve.jsx)("li", {
          className: "Baf2Recipe Baf2FarmWarning SmallTextBold",
          children: vK("buildAFactory2Game:farmDropsAllVoided")
        }), null !== MO && (null === eO || void 0 === eO ? void 0 : eO.map((OO => {
          var KO;
          let [XO, bK, eO] = OO;
          const lO = bK < .1 ? "buildAFactory2Game:farmDropRateLow" : "buildAFactory2Game:farmDropRate",
            MO = wl(eO, null === (KO = hO.get(XO)) || void 0 === KO ? void 0 : KO.Sp);
          return (0, Ve.jsxs)("li", {
            className: Fb()("Baf2Recipe Baf2FarmDrop", {
              Voided: !MO
            }),
            children: [(0, Ve.jsx)(zl, {
              item: XO,
              amount: 1
            }), (0, Ve.jsx)("span", {
              className: "Baf2RecipeName",
              children: xe(vK, XO)
            }), (0, Ve.jsx)("span", {
              className: "Baf2FarmRate",
              children: vK(lO, {
                amount: String(bK)
              })
            }), (0, Ve.jsx)("button", {
              type: "button",
              className: Fb()("Baf2FarmToggle SmallTextBold", {
                Kept: MO
              }),
              "aria-pressed": MO,
              onClick: () => {
                DO(new Map(hO).set(XO, {
                  Sp: !MO,
                  atMs: Date.now()
                })), CO.send(function(OO, KO, pO, XO) {
                  return `${RO} ${OO} ${KO} ${pO} ${XO}`
                }(pO[0], pO[1], pO[2], XO))
              },
              children: vK(MO ? "buildAFactory2Game:farmDropKeep" : "buildAFactory2Game:farmDropVoid")
            })]
          }, XO)
        })))]
      })
    }
    var mv;
    const sl = String(null !== (mv = yp.Synthesizer.waterPerOp) && void 0 !== mv ? mv : 0);

    function Hl(OO) {
      let {
        hiO: KO,
        taught: pO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)(), eO = Yl(), [lO, vK] = (0, XO.useState)(null);
      (0, XO.useEffect)((() => {
        null !== lO && pO === lO && vK(null)
      }), [lO, pO]);
      const CO = null !== lO && void 0 !== lO ? lO : pO;
      let hO = bK("buildAFactory2Game:synthPick");
      return null !== CO && (hO = bK("buildAFactory2Game:synthGrows", {
        name: xe(bK, CO),
        input: xe(bK, LK),
        water: sl
      })), (0, Ve.jsxs)("div", {
        className: "Baf2SynthPicker",
        children: [(0, Ve.jsx)("div", {
          className: Fb()("Baf2SynthHeader SmallTextBold", {
            Untaught: null === CO
          }),
          children: hO
        }), (0, Ve.jsx)("ul", {
          className: "Baf2SynthGrid",
          children: QK.map(((OO, pO) => {
            const XO = xe(bK, OO),
              lO = OO === CO;
            return (0, Ve.jsx)("li", {
              children: (0, Ve.jsx)("button", {
                type: "button",
                className: Fb()("Baf2SynthTile", {
                  Selected: lO
                }),
                title: XO,
                "aria-label": XO,
                "aria-pressed": lO,
                onClick: () => {
                  lO || (vK(OO), eO.send(`${AK} ${KO[0]} ${KO[1]} ${KO[2]} ${pO}`))
                },
                children: (0, Ve.jsx)(fb.b, {
                  itemName: OO,
                  amount: 0
                })
              })
            }, OO)
          }))
        })]
      })
    }
    const Rl = ["buildAFactory2Game:machineCoupled", "buildAFactory2Game:machineCoupledAdvanced", "buildAFactory2Game:machineCoupledNova"];

    function Sl(OO) {
      let {
        kind: KO,
        tier: pO,
        coupled: XO,
        level: bK,
        slot: eO
      } = OO;
      const {
        t: lO
      } = (0, ze.D)(), CO = WO(uK);
      if (!XO && null !== pO && pO < CO) return (0, Ve.jsxs)("div", {
        className: "Baf2UpgradeSocket Locked",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2UpgradeLock",
          children: (0, Ve.jsx)(Ab.d, {
            name: "lock"
          })
        }), (0, Ve.jsx)("div", {
          className: "Baf2UpgradeCaption SmallTextLight",
          children: lO("buildAFactory2Game:upgradeLocked")
        }), (0, Ve.jsx)("span", {
          className: "Baf2TierTag",
          children: lO("buildAFactory2Game:tierTag", {
            tier: String(CO)
          })
        })]
      });
      const hO = function(OO, KO) {
          if (vK() && "Crusher" !== OO && null !== KO) {
            if (Jl(jp, KO)) return {
              item: jp,
              emptyKey: "buildAFactory2Game:upgradeEmptyNova"
            };
            if (Jl(EK, KO)) return {
              item: EK,
              emptyKey: "buildAFactory2Game:upgradeEmptyAdvanced"
            }
          }
          return {
            item: uK,
            emptyKey: "buildAFactory2Game:upgradeEmpty"
          }
        }(KO, pO),
        DO = lO(XO ? Rl[bK - 1] : hO.emptyKey),
        MO = null !== pO ? function(OO, KO, pO, XO) {
          if (!vK() || !pO || "Crusher" === OO || KO < 10) return null;
          const bK = WO(jp);
          if (XO < 3 && bK > 1 && (2 === XO || KO >= bK)) return {
            tier: bK,
            lockedKey: "buildAFactory2Game:upgradeNovaLocked",
            nextKey: "buildAFactory2Game:upgradeNovaNext"
          };
          const eO = WO(EK);
          if (1 === XO && eO > 1) return {
            tier: eO,
            lockedKey: "buildAFactory2Game:upgradeAdvancedLocked",
            nextKey: "buildAFactory2Game:upgradeAdvancedNext"
          };
          return null
        }(KO, pO, XO, bK) : null;
      return (0, Ve.jsxs)("div", {
        className: Fb()("Baf2UpgradeSocket", {
          Fitted: XO
        }),
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2UpgradeSlot",
          children: [XO && eO, !XO && (0, Ve.jsx)("div", {
            className: "Baf2UpgradeGhost",
            children: (0, Ve.jsx)(fb.b, {
              itemName: hO.item,
              amount: 0
            })
          })]
        }), (0, Ve.jsxs)("div", {
          className: "Baf2UpgradeText",
          children: [(0, Ve.jsx)("div", {
            className: "Baf2UpgradeTitle SmallTextBold",
            children: lO("buildAFactory2Game:upgradeTitle")
          }), (0, Ve.jsx)("div", {
            className: "Baf2UpgradeCaption SmallTextLight",
            children: DO
          }), XO && bK >= 2 && "Crusher" === KO && (0, Ve.jsx)("div", {
            className: "Baf2UpgradeCaption SmallTextLight",
            children: lO("buildAFactory2Game:couplerCrusherHint")
          }), MO && null !== pO && pO < MO.tier && (0, Ve.jsxs)("div", {
            className: "Baf2UpgradeNext Locked SmallTextLight",
            children: [(0, Ve.jsx)("span", {
              className: "Baf2UpgradeLock",
              children: (0, Ve.jsx)(Ab.d, {
                name: "lock"
              })
            }), lO(MO.lockedKey), (0, Ve.jsx)("span", {
              className: "Baf2TierTag",
              children: lO("buildAFactory2Game:tierTag", {
                tier: String(MO.tier)
              })
            })]
          }), MO && null !== pO && pO >= MO.tier && (0, Ve.jsx)("div", {
            className: "Baf2UpgradeNext SmallTextLight",
            children: lO(MO.nextKey)
          })]
        })]
      })
    }

    function Jl(OO, KO) {
      const pO = WO(OO);
      return pO > 1 && KO >= pO
    }
    var cv = pO(35501);
    const Bl = (0, kK.D)(yp.Condenser, yp.Condenser.fluidMade),
      Zl = .05;
    class Gl extends ol {}

    function qv(OO) {
      return Ce(OO, "")
    }

    function xv(OO, KO, pO) {
      return OO(KO ? "buildAFactory2Game:cryoPerS" : "buildAFactory2Game:waterPerS", {
        rate: pO
      })
    }

    function nl(OO, KO, pO, XO) {
      return pO <= Zl && XO <= Zl ? null : XO <= Zl || pO <= Zl ? xv(OO, KO, XO <= Zl ? Ce(pO, "+") : Ce(XO, "\u2212")) : OO(KO ? "buildAFactory2Game:cryoRates" : "buildAFactory2Game:waterRates", {
        made: qv(pO),
        used: qv(XO)
      })
    }

    function Wl(OO, KO) {
      return Math.min(100, 100 * OO / Math.max(1, KO))
    }

    function tv(OO) {
      let {
        stored: KO,
        cap: pO,
        netPerS: XO,
        rates: bK,
        cryo: eO
      } = OO;
      const {
        t: lO
      } = (0, ze.D)(), vK = function(OO, KO, pO, XO) {
        return pO <= 0 ? OO("buildAFactory2Game:waterNoStorage") : KO >= pO ? OO("buildAFactory2Game:powerFull") : XO > Zl ? OO("buildAFactory2Game:powerFullIn", {
          time: Me(OO, (pO - KO) / XO)
        }) : XO < -.05 ? KO <= 0 ? OO("buildAFactory2Game:waterEmpty") : OO("buildAFactory2Game:powerEmptyIn", {
          time: Me(OO, KO / -XO)
        }) : OO("buildAFactory2Game:powerSteady")
      }(lO, KO, pO, XO), CO = pO > 0 && KO < pO && Math.abs(XO) <= Zl, hO = lO(eO ? "buildAFactory2Game:cryoNoFlow" : "buildAFactory2Game:waterNoFlow"), DO = null !== bK ? `${bK} \xb7 ${vK}` : CO ? hO : `${hO} \xb7 ${vK}`;
      return (0, Ve.jsxs)(Ve.Fragment, {
        children: [(0, Ve.jsx)("div", {
          className: "Baf2WaterBar",
          children: (0, Ve.jsx)("div", {
            style: {
              width: `${Wl(KO,pO)}%`
            }
          })
        }), (0, Ve.jsxs)("div", {
          className: "Baf2WaterNumbers",
          children: [(0, Ve.jsx)("span", {
            children: pO > 0 && lO("buildAFactory2Game:powerStored", {
              stored: (0, kK.N)(KO),
              cap: (0, kK.N)(pO)
            })
          }), (0, Ve.jsx)("span", {
            className: Fb()("Baf2WaterNet", {
              Draining: XO < -.05
            }),
            children: DO
          })]
        })]
      })
    }

    function kv(OO) {
      let {
        water: KO,
        at: pO,
        side: XO = null
      } = OO;
      const {
        t: bK
      } = (0, ze.D)(), eO = Yl(), [lO, vK, CO] = KO;
      return (0, Ve.jsxs)("div", {
        className: "Baf2WaterStrip",
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2WaterStripHead",
          children: [(0, Ve.jsx)("span", {
            className: "Baf2WaterStripTitle SmallTextBold",
            children: bK(null === XO ? "buildAFactory2Game:waterTitle" : `buildAFactory2Game:${XO}`)
          }), (0, Ve.jsx)("button", {
            type: "button",
            className: "Baf2WaterStripOpen SmallTextBold",
            onClick: () => {
              eO.send(`${kK.z} ${pO[0]} ${pO[1]} ${pO[2]}${"cryoOut"===XO?" cryo":""}`)
            },
            children: bK("buildAFactory2Game:waterDetails")
          })]
        }), (0, Ve.jsx)(tv, {
          stored: lO,
          cap: vK,
          netPerS: CO,
          rates: xv(bK, "cryoOut" === XO, Ce(Math.abs(CO), CO < 0 ? "\u2212" : "+")),
          cryo: "cryoOut" === XO
        })]
      })
    }

    function Ul(OO, KO) {
      var pO, XO, bK;
      const eO = !0 === KO.baf2WaterCryo,
        lO = null !== (pO = null === (XO = KO.baf2WaterMakers.find((OO => OO[0] === (eO ? kK.e : "Condenser")))) || void 0 === XO ? void 0 : XO[1]) && void 0 !== pO ? pO : 0,
        vK = [],
        CO = (KO, pO, XO) => {
          KO > 0 && vK.push(OO(1 === KO ? pO : XO, {
            count: String(KO)
          }))
        };
      return eO ? CO(lO, "buildAFactory2Game:cryoMixer", "buildAFactory2Game:cryoMixers") : CO(lO, "buildAFactory2Game:waterCondenser", "buildAFactory2Game:waterCondensers"), CO(null !== (bK = KO.baf2WaterPipes) && void 0 !== bK ? bK : 0, "buildAFactory2Game:waterPipe", "buildAFactory2Game:waterPipes"), CO(KO.baf2WaterTanks, "buildAFactory2Game:waterTank", "buildAFactory2Game:waterTanks"), vK.join(" \xb7 ")
    }

    function Ov(OO, KO) {
      if (!0 === KO.baf2WaterCryo) return function(OO, KO) {
        const pO = yp[kK.e];
        switch (KO.baf2WaterThis) {
          case "pipe":
            return {
              text: OO("buildAFactory2Game:cryoThisPipe"), bad: !1
            };
          case "condenserFull":
            return {
              text: OO("buildAFactory2Game:cryoThisMixerFull"), bad: !1
            };
          case "condenserNoPower":
            return {
              text: OO("buildAFactory2Game:cryoThisMixerNoPower"), bad: !0
            };
          case "condenserNoOutlet":
            return {
              text: OO("buildAFactory2Game:cryoThisMixerNoOutlet"), bad: !0
            };
          case "mixerNoInput":
            return {
              text: OO("buildAFactory2Game:cryoThisMixerNoInput"), bad: !0
            };
          case "mixerBadInput":
            return {
              text: OO("buildAFactory2Game:cryoThisMixerBadInput"), bad: !0
            };
          case "mixerNoWater":
            return {
              text: OO("buildAFactory2Game:cryoThisMixerNoWater"), bad: !0
            };
          case "condenser": {
            var XO;
            const [bK, eO] = null !== (XO = KO.baf2WaterThisRates) && void 0 !== XO ? XO : [(0, kK.D)(pO, pO.cryoMade), (0, kK.D)(pO, pO.powerPerOp)];
            return !0 === KO.baf2WaterDriven ? {
              text: OO("buildAFactory2Game:cryoThisMixerDriven", {
                rate: qv(bK)
              }),
              bad: !1
            } : {
              text: OO("buildAFactory2Game:cryoThisMixer", {
                rate: qv(bK),
                power: qv(eO)
              }),
              bad: !1
            }
          }
          default:
            return {
              text: OO("buildAFactory2Game:cryoThisUser"), bad: !1
            }
        }
      }(OO, KO);
      const pO = !0 === KO.baf2WaterDriven,
        XO = yp.Condenser;
      switch (KO.baf2WaterThis) {
        case "pipe":
          return {
            text: OO("buildAFactory2Game:waterThisPipe"), bad: !1
          };
        case "condenserFull":
          return {
            text: OO("buildAFactory2Game:waterThisCondenserFull"), bad: !1
          };
        case "condenserNoPower":
          return {
            text: OO("buildAFactory2Game:waterThisCondenserNoPower"), bad: !0
          };
        case "condenserNoOutlet":
          return {
            text: OO("buildAFactory2Game:waterThisCondenserNoOutlet"), bad: !0
          };
        case "tank":
          return {
            text: OO("buildAFactory2Game:waterThisTank", {
              tank: (0, kK.N)(kK.p),
              cap: (0, kK.N)(KO.baf2WaterCap)
            }), bad: !1
          };
        case "condenser": {
          var bK;
          const [eO, lO] = null !== (bK = KO.baf2WaterThisRates) && void 0 !== bK ? bK : [Bl, (0, kK.D)(XO, XO.powerPerOp)];
          return pO ? {
            text: OO("buildAFactory2Game:waterThisCondenserDriven", {
              rate: qv(eO)
            }),
            bad: !1
          } : {
            text: OO("buildAFactory2Game:waterThisCondenser", {
              rate: qv(eO),
              power: qv(lO)
            }),
            bad: !1
          }
        }
        default:
          return {
            text: OO("buildAFactory2Game:waterThisUser"), bad: !1
          }
      }
    }

    function Kv(OO, KO) {
      const pO = KO.baf2WaterMakers.some((OO => !0 === OO[5]));
      if (!0 === KO.baf2WaterCryo) {
        const XO = KO.baf2WaterUsedPerS - KO.baf2WaterMadePerS,
          bK = pO || XO <= Zl ? 0 : (0, kK.A)(XO);
        return 0 === bK ? null : bK > 1 ? OO("buildAFactory2Game:cryoNextMixers", {
          mixers: String(bK)
        }) : OO("buildAFactory2Game:cryoNextOne")
      }
      const XO = pO ? null : function(OO, KO) {
        const pO = KO - OO;
        return pO <= Zl ? null : Math.ceil(pO / Bl)
      }(KO.baf2WaterMadePerS, KO.baf2WaterUsedPerS);
      return null === XO ? null : XO > 1 ? OO("buildAFactory2Game:waterNextCondensers", {
        condensers: String(XO)
      }) : OO("buildAFactory2Game:waterNextOne")
    }

    function pv(OO) {
      let {
        item: KO,
        label: pO,
        note: XO,
        value: bK,
        dim: eO,
        bad: lO
      } = OO;
      return (0, Ve.jsxs)("li", {
        className: Fb()("Baf2WaterRow", {
          Dim: eO,
          Bad: lO
        }),
        children: [(0, Ve.jsx)("span", {
          className: "Baf2WaterRowIcon",
          children: (0, Ve.jsx)(fb.b, {
            itemName: KO,
            amount: 0
          })
        }), (0, Ve.jsxs)("span", {
          className: "Baf2WaterRowText",
          children: [(0, Ve.jsx)("span", {
            className: "Baf2WaterRowLabel",
            children: pO
          }), XO && (0, Ve.jsx)("span", {
            className: "Baf2WaterRowNote",
            children: XO
          })]
        }), (0, Ve.jsx)("span", {
          className: "Baf2WaterRowValue",
          children: bK
        })]
      })
    }

    function Xv(OO) {
      return cv.p[OO] ? OO : "Reactor Port"
    }

    function bC(OO) {
      let {
        message: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)(), XO = !0 === KO.baf2WaterCryo, bK = (OO, KO) => xv(pO, XO, Ce(OO, KO));
      return (0, Ve.jsxs)("div", {
        className: "Baf2WaterLists",
        children: [(0, Ve.jsxs)("section", {
          children: [(0, Ve.jsxs)("h3", {
            children: [pO("buildAFactory2Game:waterMakes"), (0, Ve.jsx)("span", {
              children: bK(KO.baf2WaterMadePerS, "+")
            })]
          }), (0, Ve.jsxs)("ul", {
            children: [0 === KO.baf2WaterMakers.length && (0, Ve.jsx)("li", {
              className: "Baf2WaterEmpty",
              children: pO(XO ? "buildAFactory2Game:cryoNoMakers" : "buildAFactory2Game:waterNoMakers")
            }), KO.baf2WaterMakers.map((OO => {
              let [KO, XO, eO, lO, vK, CO] = OO;
              const hO = pO("buildAFactory2Game:powerRunning", {
                amount: String(eO)
              });
              let DO = vK > 0 ? pO("buildAFactory2Game:waterMakerPower", {
                running: hO,
                power: qv(vK)
              }) : hO;
              return CO && (DO = pO(0 === eO && lO <= 0 ? "buildAFactory2Game:waterMakerNoPower" : "buildAFactory2Game:waterMakerShort")), (0, Ve.jsx)(pv, {
                item: KO,
                label: `${xe(pO,KO)} \xd7${XO}`,
                note: DO,
                value: eO > 0 || CO && lO > 0 ? bK(lO, "+") : pO("buildAFactory2Game:powerIdle"),
                dim: 0 === eO && !CO,
                bad: CO
              }, KO)
            }))]
          })]
        }), (0, Ve.jsxs)("section", {
          children: [(0, Ve.jsxs)("h3", {
            children: [pO("buildAFactory2Game:waterUses"), (0, Ve.jsx)("span", {
              children: bK(KO.baf2WaterUsedPerS, "\u2212")
            })]
          }), (0, Ve.jsxs)("ul", {
            children: [0 === KO.baf2WaterUsers.length && (0, Ve.jsx)("li", {
              className: "Baf2WaterEmpty",
              children: pO(XO ? "buildAFactory2Game:cryoNoUsers" : "buildAFactory2Game:waterNoUsers")
            }), KO.baf2WaterUsers.map((OO => {
              let [KO, XO, eO, lO] = OO;
              const vK = cv.p[KO] ? xe(pO, KO) : KO;
              return (0, Ve.jsx)(pv, {
                item: Xv(KO),
                label: XO > 1 ? `${vK} \xd7${XO}` : vK,
                note: lO ? pO("buildAFactory2Game:waterPortFirst") : void 0,
                value: eO > 0 ? bK(eO, "\u2212") : pO("buildAFactory2Game:powerIdle"),
                dim: 0 === eO
              }, KO)
            }))]
          })]
        })]
      })
    }

    function ev(OO) {
      var KO, pO, bK, eO, lO;
      let {
        store: vK,
        close: CO
      } = OO;
      const {
        t: hO
      } = (0, ze.D)(), DO = function(OO) {
        const [KO, pO] = (0, XO.useState)((() => OO.get()));
        return (0, XO.useEffect)((() => (pO(OO.get()), OO.subscribe((() => {
          pO(OO.get())
        })))), [OO]), KO
      }(vK), MO = null !== (KO = null === DO || void 0 === DO ? void 0 : DO.baf2WaterStored) && void 0 !== KO ? KO : 0, aK = null !== (pO = null === DO || void 0 === DO ? void 0 : DO.baf2WaterCap) && void 0 !== pO ? pO : 0, oO = null !== (bK = null === DO || void 0 === DO ? void 0 : DO.baf2WaterMadePerS) && void 0 !== bK ? bK : 0, FO = null !== (eO = null === DO || void 0 === DO ? void 0 : DO.baf2WaterUsedPerS) && void 0 !== eO ? eO : 0, VO = null !== (lO = null === DO || void 0 === DO ? void 0 : DO.baf2WaterNetPerS) && void 0 !== lO ? lO : oO - FO, LO = DO && Ov(hO, DO), QO = DO && Kv(hO, DO), zK = !0 === (null === DO || void 0 === DO ? void 0 : DO.baf2WaterCryo);
      return (0, Ve.jsx)(Ml.d, {
        close: CO,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay",
        children: (0, Ve.jsxs)("section", {
          className: "Baf2Panel Baf2WaterPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2WaterTitle",
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsxs)("div", {
              className: "Baf2WaterTitle",
              children: [null !== DO && aK <= 0 ? (0, Ve.jsx)("span", {
                className: "Baf2TankIcon NoTank"
              }) : (0, Ve.jsx)("span", {
                className: "Baf2TankIcon",
                children: (0, Ve.jsx)(fb.b, {
                  itemName: zK ? lp.g : kK.i,
                  amount: 0
                })
              }), (0, Ve.jsxs)("div", {
                children: [(0, Ve.jsx)("h2", {
                  id: "baf2WaterTitle",
                  children: hO(zK ? "buildAFactory2Game:cryoTitle" : "buildAFactory2Game:waterTitle")
                }), DO && (0, Ve.jsx)("p", {
                  children: Ul(hO, DO)
                })]
              })]
            }), (0, Ve.jsx)(av.i, {
              onClick: CO
            })]
          }), DO && LO && (0, Ve.jsxs)("div", {
            className: "Baf2WaterBody",
            children: [(0, Ve.jsx)("div", {
              className: "Baf2WaterHead",
              children: (0, Ve.jsx)(tv, {
                stored: MO,
                cap: aK,
                netPerS: VO,
                cryo: zK,
                rates: nl(hO, zK, oO, FO)
              })
            }), (0, Ve.jsx)("div", {
              className: Fb()("Baf2WaterThis", {
                Bad: LO.bad
              }),
              children: LO.text
            }), DO.baf2WaterDriven && (0, Ve.jsxs)("div", {
              className: "Baf2WaterDriven",
              children: [(0, Ve.jsx)(Ab.d, {
                name: "bolt"
              }), hO(zK ? "buildAFactory2Game:cryoDriven" : "buildAFactory2Game:waterDriven")]
            }), QO && (0, Ve.jsx)("p", {
              className: "Baf2WaterNext",
              children: QO
            }), (0, Ve.jsx)(bC, {
              message: DO
            })]
          })]
        })
      })
    }
    class lv {
      constructor() {
        this.pos = null, this.view = null, this.updates = 0, this.listeners = new Set
      }
      set(OO, KO) {
        const pO = this.get(OO);
        pO && null === KO.opLeftMs && null === KO.fuelLeftMs && KO.status === pO.status ? KO = {
          ...KO,
          opLeftMs: pO.opLeftMs,
          fuelLeftMs: pO.fuelLeftMs,
          burning: pO.burning
        } : this.updates++, this.pos = OO, this.view = KO;
        for (const XO of this.listeners) XO()
      }
      get(OO) {
        return null !== this.pos && this.pos[0] === OO[0] && this.pos[1] === OO[1] && this.pos[2] === OO[2] ? this.view : null
      }
      forget(OO) {
        null !== this.get(OO) && (this.pos = null, this.view = null)
      }
      get updateCount() {
        return this.updates
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
    }

    function vC(OO, KO, pO, XO) {
      return "noFuel" === KO && XO && !WK(yp[OO]) ? "buildAFactory2Game:machineStatus_noFuelLine" : "outputFull" === KO && !0 === (null === pO || void 0 === pO ? void 0 : pO.coreFull) ? "buildAFactory2Game:machineStatus_outputFullCore" : "noWater" === KO && !0 === (null === pO || void 0 === pO ? void 0 : pO.waterUnpowered) ? "buildAFactory2Game:machineStatus_noWaterPower" : "noPower" === KO && !0 === (null === pO || void 0 === pO ? void 0 : pO.powerShort) ? "buildAFactory2Game:machineStatus_noPowerShort" : "noPower" === KO && !0 === (null === pO || void 0 === pO ? void 0 : pO.powerWait) ? "buildAFactory2Game:machineStatus_noPowerWait" : Cv(KO, pO) ? "buildAFactory2Game:machineStatus_noInputShort" : function(OO, KO) {
        const pO = yp[OO];
        if ("noFuel" === KO && void 0 !== pO.fuels) return WK(pO) ? "buildAFactory2Game:machineStatus_noFuelCell" : "buildAFactory2Game:machineStatus_noFuelCoal";
        if (pO.mobFarm && ("noInput" === KO || "badInput" === KO)) return `buildAFactory2Game:machineStatus_${KO}MobFarm`;
        if ("outputFull" === KO && (void 0 !== pO.table || pO.recycles)) return "buildAFactory2Game:machineStatus_outputFullSkyTap";
        if ("notTaught" === KO && HK(pO)) return "buildAFactory2Game:machineStatus_notTaughtSynth";
        if (void 0 !== pO.cryoMade && ("noInput" === KO || "noOutlet" === KO || "fluidFull" === KO)) return `buildAFactory2Game:machineStatus_${KO}Mixer`;
        return `buildAFactory2Game:machineStatus_${KO}`
      }(OO, KO)
    }

    function Cv(OO, KO) {
      return "noInput" === OO && null !== KO && void 0 !== KO && KO.input && KO.inputShort ? {
        input: KO.input,
        short: KO.inputShort
      } : null
    }

    function hv(OO) {
      return Vb(OO) ? "buildAFactory2Game:machineInputFertiliser" : void 0 !== OO.cryoMade ? "buildAFactory2Game:machineInputBiomass" : "buildAFactory2Game:machineInput"
    }

    function Dv(OO) {
      const KO = (0, rK.ke)(OO);
      return `Baf2Pane Baf2Pane${KO.charAt(0).toUpperCase()}${KO.slice(1)}`
    }

    function Mv(OO, KO) {
      const [pO, bK] = (0, XO.useState)((() => OO.get(KO)));
      return (0, XO.useEffect)((() => {
        bK(OO.get(KO));
        const pO = OO.subscribe((() => {
          bK(OO.get(KO))
        }));
        return () => {
          pO(), OO.forget(KO)
        }
      }), [OO, ...KO]), pO
    }

    function aC(OO, KO, pO, XO) {
      const bK = yp[OO],
        eO = KO && bK.couplable ? rp(bK, pO) : bK,
        lO = null !== XO && qp(eO) ? function(OO, KO) {
          var pO;
          return null !== (pO = null !== KO && qp(OO) ? UK[KO] : void 0) && void 0 !== pO ? pO : OO.opMs
        }(eO, Op(XO)) : eO.opMs;
      return lO === eO.opMs ? eO : {
        ...eO,
        opMs: lO
      }
    }

    function ov(OO) {
      let {
        running: KO,
        opMs: pO,
        opLeftMs: XO,
        updateCount: bK
      } = OO;
      return (0, Ve.jsx)("div", {
        className: Fb()("Baf2MachineProgress", {
          Running: KO
        }),
        children: (0, Ve.jsx)("div", {
          className: "Baf2MachineProgressFill",
          style: {
            animationDuration: pO / 1e3 + "s",
            animationDelay: null === XO ? void 0 : (XO - pO) / 1e3 + "s"
          }
        }, bK)
      })
    }

    function Fv(OO) {
      let {
        running: KO,
        leftMs: pO,
        periodMs: XO,
        updateCount: bK
      } = OO;
      const {
        t: eO
      } = (0, ze.D)(), lO = Math.min(Math.max(null !== pO && void 0 !== pO ? pO : 0, 0), XO), vK = KO && lO > 0, CO = eO("buildAFactory2Game:machineBarFuel");
      return (0, Ve.jsx)("div", {
        className: Fb()("Baf2FuelBurn", {
          Draining: vK
        }),
        role: "img",
        title: CO,
        "aria-label": CO,
        children: (0, Ve.jsx)("div", {
          className: "Baf2FuelBurnFill",
          style: vK ? {
            animationDuration: XO / 1e3 + "s",
            animationDelay: (lO - XO) / 1e3 + "s"
          } : {
            transform: `scaleY(${lO/XO})`
          }
        }, bK)
      })
    }

    function Vv(OO, KO, pO) {
      let [XO, bK] = pO;
      const eO = 1 !== XO ? Qb(KO) : null;
      return {
        amount: XO,
        have: bK,
        item: OO(eO || qe(KO))
      }
    }

    function Lv(OO) {
      return qp(OO) ? "buildAFactory2Game:machineBarMining" : xp(OO) ? "buildAFactory2Game:machineBarCutting" : void 0 !== OO.powerMade ? "buildAFactory2Game:machineBarPower" : "buildAFactory2Game:machineBarMaking"
    }

    function Qv(OO) {
      var KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO, QO, zK, AO;
      let {
        kind: fO,
        hiO: dO,
        store: TO,
        power: NO,
        renderSlot: IO
      } = OO;
      const {
        t: yK
      } = (0, ze.D)(), gK = Mv(TO, dO), uO = yp[fO], EO = null !== (KO = null === gK || void 0 === gK ? void 0 : gK.coupled) && void 0 !== KO && KO, jK = null !== (pO = null === gK || void 0 === gK ? void 0 : gK.couplerLevel) && void 0 !== pO ? pO : 1, YO = aC(fO, EO, jK, null !== (XO = null === gK || void 0 === gK || null === (bK = gK.dug) || void 0 === bK ? void 0 : bK.item) && void 0 !== XO ? XO : null), wO = null !== (eO = null === gK || void 0 === gK ? void 0 : gK.status) && void 0 !== eO ? eO : null, iK = null !== (lO = null === gK || void 0 === gK ? void 0 : gK.power) && void 0 !== lO ? lO : null, rK = null !== (vK = null === gK || void 0 === gK ? void 0 : gK.opLeftMs) && void 0 !== vK ? vK : null, PO = null !== (CO = null === gK || void 0 === gK ? void 0 : gK.dug) && void 0 !== CO ? CO : null, mK = null !== PO && qp(uO) ? UK[null !== (hO = Op(PO.item)) && void 0 !== hO ? hO : ""] : void 0, sO = void 0 === mK ? null : 6e4 / mK, HO = null !== (DO = null === gK || void 0 === gK ? void 0 : gK.powerCap) && void 0 !== DO ? DO : 4e3, RO = null !== (MO = null === gK || void 0 === gK ? void 0 : gK.tier) && void 0 !== MO ? MO : null, SO = void 0 !== YO.powerMade, JO = null !== uO.fuelSlot ? IO(uO.fuelSlot) : null, cK = ip(uO), BO = !EO && !0 === (null === gK || void 0 === gK ? void 0 : gK.fuelFed), GO = !EO && !0 === (null === gK || void 0 === gK ? void 0 : gK.fuelFeeds), qK = null !== uO.fuelSlot && !EO, xK = null !== (aK = null === gK || void 0 === gK ? void 0 : gK.fuelLeftMs) && void 0 !== aK ? aK : null, nO = function(OO, KO, pO) {
        var XO;
        const bK = null === KO ? void 0 : tp[KO];
        return Math.max(null !== (XO = null !== bK && void 0 !== bK ? bK : pO) && void 0 !== XO ? XO : 0, OO.opMs)
      }(YO, null !== (oO = null === gK || void 0 === gK ? void 0 : gK.burning) && void 0 !== oO ? oO : null, xK), WO = null !== (FO = null === gK || void 0 === gK ? void 0 : gK.fuelKeep) && void 0 !== FO ? FO : null, tK = null === wO ? null : vC(fO, wO, gK, BO), kK = null === wO ? null : Cv(wO, gK);
      return (0, Ve.jsxs)("div", {
        className: "Baf2MachinePane",
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2MachineMain",
          children: [(0, Ve.jsx)("div", {
            className: "InvenLeftSideHeader SmallTextBold",
            children: yK(qe(fO))
          }), PO && (0, Ve.jsxs)("div", {
            className: "Baf2MachineDug SmallTextBold",
            children: [yK("Tree Cutter" === fO ? "buildAFactory2Game:machineCutting" : "buildAFactory2Game:machineDigging"), (0, Ve.jsx)("span", {
              className: "Baf2MachineDugIcon",
              children: (0, Ve.jsx)(fb.b, {
                itemName: PO.item,
                amount: 0
              })
            }), (0, Ve.jsx)(db.d, {
              text: PO.name
            })]
          }), null !== sO && (0, Ve.jsx)("div", {
            className: "Baf2MachineDugNote SmallTextLight",
            children: yK("buildAFactory2Game:machineDigsFixed", {
              perMin: String(sO)
            })
          }), (null === gK || void 0 === gK ? void 0 : gK.field) && (0, Ve.jsxs)("div", {
            className: "Baf2MachineDug SmallTextBold",
            children: [(0, Ve.jsx)("span", {
              className: "Baf2MachineDugIcon",
              children: (0, Ve.jsx)(fb.b, {
                itemName: "Wheat",
                amount: 0
              })
            }), yK("buildAFactory2Game:machineField", {
              planted: String(gK.field[0]),
              ripe: String(gK.field[1])
            })]
          }), (0, Ve.jsxs)("div", {
            className: "Baf2MachineRow",
            children: [(0, Ve.jsxs)("div", {
              className: Fb()("Baf2MachineColumn", {
                Baf2Burns: qK
              }),
              children: [null !== YO.inputSlot && (0, Ve.jsxs)("div", {
                className: "Baf2MachineSlot",
                children: [(0, Ve.jsx)("div", {
                  className: "Baf2MachineLabel SmallTextLight",
                  children: yK(hv(YO))
                }), IO(YO.inputSlot)]
              }), null !== uO.fuelSlot && !EO && (0, Ve.jsxs)("div", {
                className: Fb()("Baf2MachineSlot", {
                  Baf2FuelFed: BO
                }),
                children: [(0, Ve.jsxs)("div", {
                  className: "Baf2MachineLabel SmallTextLight",
                  children: [BO && (0, Ve.jsx)(Ab.d, {
                    name: "fire"
                  }), yK("buildAFactory2Game:machineFuel")]
                }), (0, Ve.jsxs)("div", {
                  className: "Baf2FuelSlot",
                  children: [(0, Ve.jsx)(Fv, {
                    running: "running" === wO,
                    leftMs: xK,
                    periodMs: nO,
                    updateCount: TO.updateCount
                  }), JO]
                })]
              }), null !== uO.fuelSlot && EO && (0, Ve.jsxs)("div", {
                className: "Baf2MachineSlot Baf2FuelNotNeeded",
                children: [(0, Ve.jsx)("div", {
                  className: "Baf2MachineLabel SmallTextLight",
                  children: yK("buildAFactory2Game:machineFuel")
                }), (0, Ve.jsx)("div", {
                  className: "Baf2FuelNotNeededBox",
                  role: "img",
                  title: yK("buildAFactory2Game:upgradeFuelNotNeeded"),
                  "aria-label": yK("buildAFactory2Game:upgradeFuelNotNeeded"),
                  children: (0, Ve.jsx)(Ab.d, {
                    name: "bolt"
                  })
                })]
              })]
            }), (0, Ve.jsxs)("div", {
              className: "Baf2MachineMeter",
              children: [(0, Ve.jsx)("div", {
                className: "Baf2MachineLabel SmallTextLight",
                children: yK(Lv(YO))
              }), (0, Ve.jsx)(ov, {
                running: "running" === wO,
                opMs: YO.opMs,
                opLeftMs: rK,
                updateCount: TO.updateCount
              })]
            }), YO.outputSlots.length > 0 && (0, Ve.jsxs)("div", {
              className: "Baf2MachineColumn",
              children: [(0, Ve.jsx)("div", {
                className: "Baf2MachineLabel SmallTextLight",
                children: yK("buildAFactory2Game:machineOutput")
              }), (0, Ve.jsx)("div", {
                className: "Baf2MachineOutputs",
                children: YO.outputSlots.map((OO => (0, Ve.jsx)("div", {
                  children: IO(OO)
                }, OO)))
              })]
            }), null !== iK && SO && (0, Ve.jsx)("div", {
              className: "Baf2MachinePowerStore",
              children: (0, Ve.jsx)("div", {
                style: {
                  height: 100 * iK / HO + "%"
                }
              })
            })]
          }), qK && null !== WO && (0, Ve.jsxs)("div", {
            className: "Baf2FuelLine SmallTextLight",
            children: [(0, Ve.jsx)(Ab.d, {
              name: "arrows-rotate"
            }), yK(xp(YO) ? "buildAFactory2Game:machineFuelKeepCut" : "buildAFactory2Game:machineFuelKeepDig", {
              amount: String(WO)
            })]
          }), (BO || GO) && (0, Ve.jsxs)("div", {
            className: "Baf2FuelLine SmallTextLight",
            children: [(0, Ve.jsx)(Ab.d, {
              name: "fire"
            }), yK(BO ? "buildAFactory2Game:machineFuelFed" : "buildAFactory2Game:machineFuelFeeds")]
          }), uO.couplable && (0, Ve.jsx)(Sl, {
            kind: fO,
            tier: RO,
            coupled: EO,
            level: jK,
            slot: cK === uO.fuelSlot ? JO : null !== cK ? IO(cK) : null
          }), null !== iK && !SO && !0 === (null === gK || void 0 === gK ? void 0 : gK.reactorPowered) && (0, Ve.jsx)("div", {
            className: "Baf2PowerStrip SmallTextBold",
            children: yK("buildAFactory2Game:machineReactorPowered")
          }), null !== iK && !SO && !0 !== (null === gK || void 0 === gK ? void 0 : gK.reactorPowered) && (0, Ve.jsx)(Al, {
            stored: iK,
            cap: HO,
            rates: null !== (VO = null === gK || void 0 === gK ? void 0 : gK.powerRates) && void 0 !== VO ? VO : null
          }), (null === gK || void 0 === gK ? void 0 : gK.water) && (0, Ve.jsx)(kv, {
            water: gK.water,
            at: dO,
            side: gK.cryo ? "waterIn" : null
          }), (null === gK || void 0 === gK ? void 0 : gK.cryo) && (0, Ve.jsx)(kv, {
            water: gK.cryo,
            at: dO,
            side: "cryoOut"
          }), null !== gK && void 0 !== gK && gK.inertCoupler ? (0, Ve.jsx)("div", {
            className: "Baf2MachineStatus Stalled SmallTextBold",
            children: yK("buildAFactory2Game:machineStatus_couplerOff", {
              item: xe(yK, gK.inertCoupler)
            })
          }) : null !== tK && (0, Ve.jsx)("div", {
            className: Fb()("Baf2MachineStatus SmallTextBold", {
              Stalled: "running" !== wO
            }),
            children: yK(tK, kK ? Vv(yK, kK.input, kK.short) : void 0)
          })]
        }), (0, Ve.jsxs)("div", {
          className: Fb()("Baf2MachineSide", {
            Baf2SynthSide: HK(uO)
          }),
          children: [HK(uO) && (0, Ve.jsx)(Hl, {
            hiO: dO,
            taught: null !== (LO = null === gK || void 0 === gK ? void 0 : gK.taught) && void 0 !== LO ? LO : null
          }, dO.join(",")), SO && (0, Ve.jsx)(dl, {
            kind: fO,
            def: YO,
            hiO: dO,
            power: NO,
            stored: null !== iK && void 0 !== iK ? iK : 0,
            cap: HO
          }), ZO(uO) && (0, Ve.jsx)(Pl, {
            hiO: dO,
            input: null !== (QO = null === gK || void 0 === gK ? void 0 : gK.input) && void 0 !== QO ? QO : null,
            drops: null !== (zK = null === gK || void 0 === gK ? void 0 : gK.farm) && void 0 !== zK ? zK : null,
            seconds: String(YO.opMs / 1e3)
          }), !SO && !ZO(uO) && !HK(uO) && (0, Ve.jsx)(ql, {
            kind: fO,
            def: YO,
            input: null !== (AO = null === gK || void 0 === gK ? void 0 : gK.input) && void 0 !== AO ? AO : null,
            tier: null !== RO && void 0 !== RO ? RO : 1,
            noSeeds: !0 === (null === gK || void 0 === gK ? void 0 : gK.noSeeds)
          })]
        })]
      })
    }

    function zC(OO, KO, pO, XO) {
      var bK;
      const eO = yp[OO],
        lO = [eO.inputSlot, eO.fuelSlot, ...null !== (bK = eO.inputSlots) && void 0 !== bK ? bK : []].filter((OO => null !== OO));
      return {
        render: bK => {
          let {
            hiO: eO,
            renderSlot: lO
          } = bK;
          return (0, Ve.jsx)(jv.Provider, {
            value: XO,
            children: (0, Ve.jsx)(Qv, {
              kind: OO,
              hiO: eO,
              store: KO,
              power: pO,
              renderSlot: lO
            })
          })
        },
        quickMoveRange: lO.length > 0 ? [Math.min(...lO), Math.max(...lO) + 1] : [0, 0],
        className: Dv(OO)
      }
    }
    const Av = "Assembler";

    function fv(OO) {
      var KO, pO, XO, bK, eO, lO, vK, CO, hO;
      let {
        hiO: DO,
        store: MO,
        renderSlot: aK
      } = OO;
      const {
        t: oO
      } = (0, ze.D)(), FO = Mv(MO, DO), VO = null !== (KO = null === FO || void 0 === FO ? void 0 : FO.tier) && void 0 !== KO ? KO : 1, LO = null !== (pO = null === FO || void 0 === FO ? void 0 : FO.taught) && void 0 !== pO ? pO : null, QO = cp(Av, {
        coupled: !1,
        taught: LO
      }), zK = null !== (XO = QO.bench) && void 0 !== XO ? XO : null, AO = null !== (bK = null === FO || void 0 === FO ? void 0 : FO.status) && void 0 !== bK ? bK : null, fO = null !== (eO = null === FO || void 0 === FO ? void 0 : FO.power) && void 0 !== eO ? eO : null, dO = null !== (lO = null === FO || void 0 === FO ? void 0 : FO.powerCap) && void 0 !== lO ? lO : 4e3;
      return (0, Ve.jsxs)("div", {
        className: "Baf2MachinePane Baf2BenchPane",
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2MachineMain",
          children: [(0, Ve.jsx)("div", {
            className: "InvenLeftSideHeader SmallTextBold",
            children: oO(qe(Av))
          }), zK && (0, Ve.jsxs)("div", {
            className: "Baf2BenchMakes SmallTextBold",
            children: [oO("buildAFactory2Game:benchMakes"), (0, Ve.jsx)("span", {
              className: "Baf2BenchMakesIcon",
              children: (0, Ve.jsx)(fb.b, {
                itemName: zK.output,
                amount: 0
              })
            }), (null === FO || void 0 === FO ? void 0 : FO.taughtName) && (0, Ve.jsx)(db.d, {
              text: FO.taughtName
            }), zK.outputAmount > 1 && (0, Ve.jsxs)("span", {
              children: ["\xd7", zK.outputAmount]
            })]
          }), !zK && (0, Ve.jsx)("div", {
            className: "Baf2BenchMakes Untaught SmallTextBold",
            children: oO("buildAFactory2Game:benchTeachHint")
          }), (0, Ve.jsxs)("div", {
            className: "Baf2MachineRow",
            children: [(0, Ve.jsx)("div", {
              className: "Baf2BenchInputs",
              children: (null !== (vK = QO.inputSlots) && void 0 !== vK ? vK : []).map(((OO, KO) => {
                const pO = null === zK || void 0 === zK ? void 0 : zK.inputs[KO];
                return (0, Ve.jsxs)("div", {
                  className: Fb()("Baf2BenchInput", {
                    Spare: !pO
                  }),
                  children: [(0, Ve.jsxs)("div", {
                    className: "Baf2BenchSlot",
                    children: [aK(OO), pO && (0, Ve.jsx)("div", {
                      className: "Baf2BenchGhost",
                      children: (0, Ve.jsx)(fb.b, {
                        itemName: pO.item,
                        amount: 0
                      })
                    })]
                  }), (0, Ve.jsx)("div", {
                    className: "Baf2BenchNeed SmallTextLight",
                    children: pO ? `\xd7${pO.amount}` : "\xa0"
                  })]
                }, OO)
              }))
            }), (0, Ve.jsx)(ov, {
              running: "running" === AO,
              opMs: QO.opMs,
              opLeftMs: null !== (CO = null === FO || void 0 === FO ? void 0 : FO.opLeftMs) && void 0 !== CO ? CO : null,
              updateCount: MO.updateCount
            }), (0, Ve.jsxs)("div", {
              className: "Baf2MachineColumn",
              children: [(0, Ve.jsx)("div", {
                className: "Baf2MachineLabel SmallTextLight",
                children: oO("buildAFactory2Game:machineOutput")
              }), (0, Ve.jsx)("div", {
                className: "Baf2MachineOutputs",
                children: QO.outputSlots.map((OO => (0, Ve.jsx)("div", {
                  children: aK(OO)
                }, OO)))
              })]
            })]
          }), null !== fO && (0, Ve.jsx)(Al, {
            stored: fO,
            cap: dO,
            rates: null !== (hO = null === FO || void 0 === FO ? void 0 : FO.powerRates) && void 0 !== hO ? hO : null
          }), null !== AO && (0, Ve.jsx)("div", {
            className: Fb()("Baf2MachineStatus SmallTextBold", {
              Stalled: "running" !== AO
            }),
            children: oO(vC(Av, AO, FO, !1))
          }), zK && zK.inputs.length > 1 && (0, Ve.jsx)("div", {
            className: "Baf2BenchTip SmallTextLight",
            children: oO("buildAFactory2Game:benchOneBeltEach")
          })]
        }), (0, Ve.jsxs)("div", {
          className: "Baf2MachineSide",
          children: [(0, Ve.jsx)(ne, {
            taught: LO,
            tier: VO
          }), zK && (0, Ve.jsx)("div", {
            className: "Baf2BenchTeachTip SmallTextLight",
            children: oO("buildAFactory2Game:benchTeachHint")
          })]
        })]
      })
    }

    function dv(OO) {
      var KO;
      const pO = null !== (KO = yp[Av].inputSlots) && void 0 !== KO ? KO : [];
      return {
        render: KO => {
          let {
            hiO: pO,
            renderSlot: XO
          } = KO;
          return (0, Ve.jsx)(fv, {
            hiO: pO,
            store: OO,
            renderSlot: XO
          })
        },
        quickMoveRange: [Math.min(...pO), Math.max(...pO) + 1],
        className: Dv(Av)
      }
    }
    var Tv = pO(94),
      Nv = pO(1004),
      Iv = pO(3520);
    const yC = 600,
      gC = .5,
      uv = 4,
      Ev = 1200,
      jC = 140,
      Yv = 100,
      wv = 32,
      iC = 16,
      rC = 100.5,
      Pv = 90,
      mC = 1.5,
      sv = 50;

    function Hv(OO) {
      switch (Tp(OO)) {
        case "Fuel Rod":
          return 1;
        case "Graphite Block":
          return 2;
        case "Coolant Channel":
          return 3;
        default:
          return 0
      }
    }
    const Rv = [
      [1, 0, 0],
      [-1, 0, 0],
      [0, 1, 0],
      [0, -1, 0],
      [0, 0, 1],
      [0, 0, -1]
    ];

    function Sv(OO) {
      const KO = Math.ceil(60 * OO / Yv);
      return {
        fuel: Math.max(wv, KO),
        waste: Math.max(iC, KO)
      }
    }

    function Jv(OO, KO, pO) {
      const [XO, bK, eO] = [OO - 2, KO - 2, pO - 2];
      return 2 * (XO * bK + bK * eO + eO * XO) * jC
    }

    function cC(OO, KO, pO) {
      return Math.max(0, OO - 2) * Math.max(0, KO - 2) * Math.max(0, pO - 2)
    }

    function Bv(OO, KO) {
      const [pO, XO, bK] = OO, eO = pO * XO * bK, lO = new Float32Array(eO);
      let vK = 0,
        CO = 0,
        hO = 0,
        DO = 0,
        MO = 0;
      const aK = (OO, eO, lO) => OO < 0 || OO >= pO || eO < 0 || eO >= XO || lO < 0 || lO >= bK ? 0 : KO[(eO * bK + lO) * pO + OO];
      for (let LO = 0; LO < XO; LO++)
        for (let OO = 0; OO < bK; OO++)
          for (let XO = 0; XO < pO; XO++) {
            const eO = (LO * bK + OO) * pO + XO,
              oO = KO[eO];
            if (1 === oO) {
              vK++;
              let KO = 0;
              for (const [pO, bK, eO] of Rv) {
                const lO = aK(XO + pO, LO + bK, OO + eO);
                1 !== lO && 2 !== lO || KO++
              }
              lO[eO] = yC * (1 + gC * Math.min(KO, uv)), DO += lO[eO]
            } else if (2 === oO) CO++;
            else if (3 === oO) {
              hO++;
              Rv.some((KO => {
                let [pO, bK, eO] = KO;
                return 1 === aK(XO + pO, LO + bK, OO + eO)
              })) && (MO += Ev)
            }
          }
      const oO = Jv(pO + 2, XO + 2, bK + 2),
        FO = Math.min(DO, MO, oO),
        VO = vK > 0 ? DO * Yv / vK : 0;
      return {
        rods: vK,
        graphite: CO,
        channels: hO,
        fuelHeat: DO,
        cooling: MO,
        size: oO,
        max: FO,
        vol: eO,
        powerPerUnit: VO,
        pelletsPerMin: VO > 0 ? FO / VO * 60 : 0,
        waterPerS: FO * kK.n,
        rodHeat: lO
      }
    }
    const Zv = 0,
      Gv = 1,
      qC = 6,
      xC = 7,
      nv = 8;

    function Wv(OO, KO) {
      const [pO, XO, bK] = OO, eO = new Uint8Array(pO * XO * bK), lO = (OO, eO, lO) => OO < 0 || OO >= pO || eO < 0 || eO >= XO || lO < 0 || lO >= bK ? 0 : KO[(eO * bK + lO) * pO + OO];
      for (let vK = 0; vK < XO; vK++)
        for (let OO = 0; OO < bK; OO++)
          for (let XO = 0; XO < pO; XO++) {
            const CO = (vK * bK + OO) * pO + XO,
              hO = KO[CO];
            if (1 === hO) {
              let KO = 0;
              for (const [pO, bK, eO] of Rv) {
                const CO = lO(XO + pO, vK + bK, OO + eO);
                KO += 1 === CO || 2 === CO ? 1 : 0
              }
              eO[CO] = Gv + Math.min(KO, uv)
            } else if (3 === hO) {
              const KO = Rv.some((KO => {
                let [pO, bK, eO] = KO;
                return 1 === lO(XO + pO, vK + bK, OO + eO)
              }));
              eO[CO] = KO ? qC : xC
            } else 2 === hO && (eO[CO] = nv)
          }
      return eO
    }

    function tC(OO) {
      return OO.fuelHeat <= OO.cooling && OO.fuelHeat <= OO.size ? "fuel" : OO.cooling <= OO.size ? "cooling" : "size"
    }
    const kC = Pv;

    function Uv(OO, KO, pO) {
      return Math.round(OO * KO * pO * 25e3 * (1 + .25 * (Math.min(OO, KO, pO) - 2)))
    }

    function OC(OO) {
      return Math.max(0, Math.min(kK.f, OO))
    }

    function KC(OO, KO, pO) {
      const XO = KO * OC(pO);
      return OO <= 0 ? 0 : XO > 0 ? Math.min(200, 100 * OO / XO) : 200
    }

    function pC(OO, KO) {
      const pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2] ? mC : 1;
      return Math.min(OO.fuelHeat * pO, OO.cooling * OC(KO), OO.size * pO)
    }

    function XC(OO) {
      return 2 + OO / 10
    }
    const bh = "buildAFactory2Game:";

    function eC(OO) {
      var KO;
      return null !== (KO = OO.baf2RxMood) && void 0 !== KO ? KO : function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "off";
        const pO = [
          ["calm", 50],
          ["warm", kC],
          ["hot", rC]
        ];
        for (const [XO, bK] of pO)
          if (OO < bK + (XO === KO ? 3 : 0)) return XO;
        return "alarm"
      }(OO.baf2RxHeat)
    }
    const lC = 120;

    function vh(OO) {
      const KO = OO.baf2RxState;
      if ("running" === KO && OO.baf2RxHeat > rC) return {
        label: `${bh}rxState_tooHot`,
        tone: "bad",
        fix: `${bh}rxFix_tooHot`
      };
      switch (KO) {
        case "running":
          return {
            label: `${bh}rxState_running`, tone: "good", fix: null
          };
        case "idle":
          return {
            label: `${bh}rxState_idle`, tone: "off", fix: `${bh}rxFix_idle`
          };
        case "scram":
          return {
            label: `${bh}rxState_scram`, tone: "off", fix: OO.baf2RxHeat < sv ? `${bh}rxFix_scramCool` : `${bh}rxFix_scram`
          };
        case "paused":
        case "unformed":
          return {
            label: `${bh}rxState_${KO}`, tone: "off", fix: `${bh}rxFix_${KO}`
          };
        case "melted":
          return {
            label: `${bh}rxState_melted`, tone: "bad", fix: `${bh}rxFix_melted`
          };
        default:
          return {
            label: `${bh}rxState_${KO}`, tone: "warn", fix: `${bh}rxFix_${KO}`
          }
      }
    }

    function CC(OO) {
      const [KO, pO, XO] = OO.baf2RxStats;
      return {
        fuelHeat: KO,
        cooling: pO * (OO.baf2RxCryo ? Math.max(1, OC(OO.baf2RxWater / 100)) : 1),
        size: XO
      }
    }

    function hC(OO) {
      var KO;
      const pO = "idle" === OO.baf2RxState || "running" === OO.baf2RxState && OO.baf2RxHeat <= rC || "scram" === OO.baf2RxState && OO.baf2RxHeat < sv;
      if (0 === (OO.baf2RxFlags & oK) || !OO.baf2RxFormed || !pO) return null;
      const {
        fuelHeat: XO,
        cooling: bK,
        size: eO
      } = CC(OO), lO = Math.min(XO, bK, eO), vK = tC({
        fuelHeat: XO,
        cooling: bK,
        size: eO
      }), CO = "cooling" === vK && !0 === OO.baf2RxCryoOpen && !OO.baf2RxCryo, hO = null !== (KO = OO.baf2RxCells) && void 0 !== KO ? KO : "", DO = ("fuel" === vK || "cooling" === vK && !0 === OO.baf2RxCryo) && hO.length > 0 && !hO.includes(String(0)), MO = CO ? "Cryo" : "scram" === OO.baf2RxState ? "Off" : "";
      return lO < 12e3 ? {
        key: `${bh}rxGrow_${DO?"full":vK}${MO}`,
        amount: lO
      } : null
    }

    function DC(OO, KO) {
      return OO[0] === KO[0] && OO[1] === KO[1] && OO[2] === KO[2]
    }

    function MC(OO) {
      return [...OO].sort(((OO, KO) => Number(KO[2] < KO[1]) - Number(OO[2] < OO[1])))
    }

    function ah(OO, KO) {
      return KO.some((KO => {
        let [pO, XO] = KO;
        return !(XO <= 0) && ["edge", "cap", "wall", "inside"].some((KO => pO === tX(OO, KO)))
      }))
    }

    function oC(OO, KO, pO) {
      const XO = OO.baf2RxFuel - OO.baf2RxPu > 0 ? pO : 0;
      return {
        full: OO.baf2RxWaste > KO - 3,
        fullInS: XO > 0 ? Math.max(0, KO - OO.baf2RxWaste) / XO : null
      }
    }
    const FC = {
      frame: {
        size: .4,
        colour: [.2, .24, .32],
        alpha: .55
      },
      casing: {
        size: .4,
        colour: [.9, .94, 1],
        alpha: .55
      },
      cell: {
        size: .35,
        colour: [1, .82, .3],
        alpha: .55
      },
      rod: {
        size: .3,
        colour: [.71, 1, .23],
        alpha: .55
      },
      channel: {
        size: .3,
        colour: [.25, .82, .94],
        alpha: .55
      },
      graphite: {
        size: .3,
        colour: [.12, .12, .14],
        alpha: .6
      },
      wrong: {
        size: 1.04,
        colour: [1, .22, .18],
        alpha: .35
      }
    };

    function VC(OO) {
      return LC[OO]
    }
    const LC = {
      "Reactor Frame": "frame",
      "Reactor Glass": "casing",
      "Battery Cell": "cell",
      "Fuel Rod": "rod",
      "Coolant Channel": "channel",
      "Graphite Block": "graphite"
    };

    function QC(OO) {
      let [KO, pO, XO] = OO;
      return Math.ceil(Jv(KO, pO, XO) * kK.n)
    }

    function zh(OO, KO) {
      return "battery" === OO ? KO[0] * KO[1] * KO[2] : function(OO) {
        let [KO, pO, XO] = OO;
        return KO * pO * XO - Math.max(0, KO - 2) * Math.max(0, pO - 2) * Math.max(0, XO - 2)
      }(KO) - 1
    }

    function AC(OO) {
      const KO = Math.max(0, OO);
      if (KO < 10) return String(Math.round(10 * KO) / 10);
      if (KO < 1e4) return Math.round(KO).toLocaleString("en-US");
      if (KO < 1e6) return `${KO<1e5?(Math.floor(KO/100)/10).toFixed(1):Math.floor(KO/1e3)}k`;
      const pO = KO / 1e6;
      return `${pO<10?(Math.floor(100*pO)/100).toFixed(2):pO<100?(Math.floor(10*pO)/10).toFixed(1):Math.floor(pO)}M`
    }

    function fC(OO) {
      return OO <= 0 ? "0" : OO >= 10 ? String(Math.round(OO)) : OO.toFixed(OO >= 1 ? 1 : 2)
    }

    function dC(OO) {
      const KO = Bp(OO, 0),
        pO = Bp(OO, Rp(OO) - 1);
      return {
        lo: [Math.min(KO[0], pO[0]), Math.min(KO[1], pO[1]), Math.min(KO[2], pO[2])],
        hi: [Math.max(KO[0], pO[0]) + 1, Math.max(KO[1], pO[1]) + 1, Math.max(KO[2], pO[2]) + 1]
      }
    }

    function TC(OO, KO, pO) {
      const XO = [KO[0] - OO[0], KO[1] - OO[1], KO[2] - OO[2]],
        bK = [(OO[0] + KO[0]) / 2, (OO[1] + KO[1]) / 2, (OO[2] + KO[2]) / 2],
        eO = [];
      for (let lO = 0; lO < 3; lO++) {
        const vK = (lO + 1) % 3,
          CO = (lO + 2) % 3;
        for (const hO of [OO[vK], KO[vK]])
          for (const DO of [OO[CO], KO[CO]]) {
            const OO = [0, 0, 0],
              KO = [pO, pO, pO];
            OO[lO] = bK[lO], KO[lO] = XO[lO] + pO, OO[vK] = hO, OO[CO] = DO, eO.push([OO, KO])
          }
      }
      return eO
    }
    const NC = "buildAFactory2Game:",
      IC = [`${NC}colNorth`, `${NC}colEast`, `${NC}colSouth`, `${NC}colWest`];

    function yh(OO, KO) {
      const [pO, XO, bK] = OO.baf2ColAt;
      return `baf2col ${pO} ${XO} ${bK} ${KO}`
    }

    function gh(OO) {
      return function(OO) {
        if (!Number.isFinite(OO)) return "";
        const KO = Math.max(1, Math.round(OO));
        if (KO < 60) return `${KO}s`;
        const pO = KO % 60;
        return 0 === pO ? KO / 60 + "m" : `${Math.floor(KO/60)}m ${pO}s`
      }(function(OO) {
        const KO = kX.FOCUS_BY_LASERS[Math.max(0, Math.min(4, OO))];
        return KO > 0 ? kX.NOVA_FOCUS / KO : 1 / 0
      }(OO))
    }

    function uC(OO) {
      const KO = Math.abs(Math.round(OO));
      return KO < 1e3 ? Math.round(OO).toLocaleString("en-US") : KO < 1e6 ? `${KO<1e5?(OO/1e3).toFixed(1).replace(/\.0$/,""):Math.round(OO/1e3)}k` : `${(OO/1e6).toFixed(KO<1e7?2:1).replace(/\.?0+$/,"")}M`
    }

    function EC(OO, KO, pO) {
      if (bb(KO) >= 0) {
        const KO = function(OO, KO) {
          return OO.find((OO => {
            let {
              focus: pO
            } = OO;
            return pO[0] === KO[0] && pO[2] === KO[2] && (KO[1] === pO[1] || KO[1] === pO[1] - 1)
          }))
        }(OO, pO);
        if (!KO) return null;
        const bK = function(OO) {
          let KO = 0,
            pO = 0;
          for (let XO = 0; XO < 4; XO++) KO += OO.laser[XO] ? 1 : 0, pO += OO.live[XO] ? 1 : 0;
          return {
            lasers: KO,
            live: pO,
            focusPerS: kX.FOCUS_BY_LASERS[pO],
            drawPerS: kX.LASER_DRAW * pO
          }
        }({
          laser: KO.lasers,
          live: KO.live
        });
        if (0 === bK.lasers || "noLasers" === KO.state) return {
          key: `${NC}lookColNoLasers`
        };
        if (0 === bK.live) return {
          key: `${NC}lookColOff_blocked`
        };
        if (!(KO.on && bK.live > 0) && ("running" !== (XO = KO.state) && "slowed" !== XO)) return {
          key: `${NC}lookColOff_${KO.state}`
        };
        if (bK.live < bK.lasers) return {
          key: `${NC}lookColLasersSome`,
          params: {
            lasers: String(bK.lasers),
            live: String(bK.live)
          }
        };
        const eO = KO.open.filter(Boolean).length;
        return eO < 4 ? {
          key: `${NC}lookColLasersSpots`,
          params: {
            live: String(bK.live),
            spots: String(eO),
            time: gh(bK.live)
          }
        } : {
          key: `${NC}lookColLasers`,
          params: {
            live: String(bK.live),
            time: gh(bK.live)
          }
        }
      }
      var XO;
      if (!eX(KO)) return null;
      const bK = function(OO, KO) {
        for (const pO of OO) {
          const OO = hX(pO.focus, [KO[0], KO[1], KO[2]]);
          if (OO && OO.OO === kX.LASER_D && pO.lasers[OO.dir]) return {
            entry: pO,
            dir: OO.dir
          }
        }
        return null
      }(OO, pO);
      if (!bK) return {
        key: `${NC}lookLaserNoCollider`
      };
      const {
        entry: eO,
        dir: lO
      } = bK;
      return eO.open[lO] ? eO.live[lO] ? {
        key: eO.on ? `${NC}lookLaserFiring` : `${NC}lookLaserReady`
      } : {
        key: `${NC}lookLaserBlocked`
      } : {
        key: `${NC}lookLaserClosed`
      }
    }

    function jh(OO, KO) {
      const pO = [];
      for (let XO = 1; XO < kX.LASER_D; XO++) OO & 1 << KO * (kX.LASER_D - 1) + XO - 1 && pO.push(XO);
      return pO
    }
    const YC = {
      firing: `${NC}colSlotFiring`,
      ready: `${NC}colSlotReady`,
      blocked: `${NC}colSlotBlocked`,
      empty: `${NC}colSlotEmpty`,
      closed: `${NC}colSlotClosed`
    };

    function wC(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0;
      const eO = tb(OO),
        lO = tb(KO),
        vK = tb(pO),
        CO = vK.filter(Boolean).length,
        hO = eO.filter(Boolean).length,
        DO = [0, 1, 2, 3].map((OO => lO[OO] ? eO[OO] ? vK[OO] ? XO ? "firing" : "ready" : "blocked" : (OO => jh(bK, OO).length > 0)(OO) ? "blocked" : "empty" : "closed")),
        MO = DO.indexOf("blocked"),
        aK = MO < 0 && hO > 0 ? DO.indexOf("empty") : -1;
      return DO.map(((OO, KO) => {
        const pO = KO === MO ? {
          key: `${NC}colSlotClear`
        } : KO === aK ? {
          key: `${NC}colSlotAdd`,
          params: {
            time: gh(Math.min(4, CO + 1))
          }
        } : null;
        return {
          dir: KO,
          tone: OO,
          title: {
            key: "blocked" !== OO || eO[KO] ? YC[OO] : `${NC}colSlotGap`,
            keys: {
              dir: IC[KO]
            }
          },
          hint: pO
        }
      }))
    }

    function ih(OO) {
      var KO;
      return "noPower" === OO.baf2ColState && OO.baf2ColRxState ? vh({
        baf2RxState: OO.baf2ColRxState,
        baf2RxFlags: 0,
        baf2RxHeat: null !== (KO = OO.baf2ColRxHeat) && void 0 !== KO ? KO : 0
      }) : null
    }

    function rh(OO) {
      const KO = tb(OO.baf2ColSpots).filter(Boolean).length,
        pO = tb(OO.baf2ColLive);
      let XO = 0,
        bK = 0;
      return tb(OO.baf2ColLasers).forEach(((OO, KO) => {
        OO && (XO++, bK += pO[KO] ? 0 : 1)
      })), bK > 0 ? {
        key: `${NC}colSubSome`,
        params: {
          blocked: String(bK),
          lasers: String(XO)
        }
      } : KO < 4 ? {
        key: `${NC}colSubSpots`,
        params: {
          lasers: String(XO),
          spots: String(KO)
        }
      } : {
        key: `${NC}colSub`,
        params: {
          lasers: String(XO)
        }
      }
    }

    function PC(OO) {
      const KO = ih(OO);
      if ("idle" === OO.baf2ColRxState && KO) return {
        key: `${NC}colState_noPowerIdle`
      };
      if (KO) return {
        key: `${NC}colState_noPowerReactor`,
        keys: {
          state: KO.label
        }
      };
      if ("noInput" !== OO.baf2ColState) return {
        key: `${NC}colState_${OO.baf2ColState}`
      };
      const pO = String(Math.max(0, kX.NOVA_SA - OO.baf2ColSa)),
        XO = String(Math.max(0, kX.NOVA_GD - OO.baf2ColGd));
      return "0" !== pO && "0" !== XO ? {
        key: `${NC}colState_noInput`,
        params: {
          sa: pO,
          gd: XO
        }
      } : "0" !== pO ? {
        key: `${NC}colState_noStarAlloy`,
        params: {
          sa: pO
        }
      } : "0" !== XO ? {
        key: `${NC}colState_noGlowDust`,
        params: {
          gd: XO
        }
      } : {
        key: `${NC}colState_running`
      }
    }

    function mh(OO) {
      return OO.baf2ColP < 0 ? `${NC}colNext` : function(OO) {
        const KO = OO.baf2ColState;
        return OO.baf2ColP >= 0 && ("blocked" === KO || "noLasers" === KO || "noPower" === KO)
      }(OO) ? `${NC}colStalled` : null === sC(OO) ? `${NC}colMaking` : `${NC}colNovaIn`
    }

    function sC(OO) {
      if (OO.baf2ColP < 0 || OO.baf2ColWant <= 0) return null;
      const KO = OO.baf2ColFocusPerS * Math.min(1, OO.baf2ColDraw / OO.baf2ColWant);
      return KO > 0 ? Math.max(0, kX.NOVA_FOCUS - OO.baf2ColP) / KO : null
    }

    function HC(OO, KO) {
      const pO = [];
      for (let XO = 1; XO <= 3; XO++) {
        const bK = [OO[0], OO[1] - XO, OO[2]];
        if (!KO(bK)) return pO;
        pO.push(bK)
      }
      return []
    }

    function RC(OO, KO) {
      const pO = {
        free: [],
        blocked: [],
        gaps: [],
        supports: []
      };
      for (let XO = 0; XO < 4; XO++) {
        const bK = XO,
          eO = CX(OO.focus, bK, kX.LASER_D);
        if (OO.lasers[XO] || !OO.open[XO] || !KO(eO)) continue;
        const lO = [];
        for (let pO = 1; pO < kX.LASER_D; pO++) {
          const XO = CX(OO.focus, bK, pO);
          KO(XO) || lO.push(XO)
        }
        pO.supports.push(...HC(eO, KO)), 0 === lO.length ? pO.free.push(eO) : (pO.blocked.push(eO), pO.gaps.push(...lO))
      }
      return pO
    }
    const SC = kX.LASER_D - .25,
      JC = 4,
      ch = 2,
      BC = 16;
    const ZC = {
        colours: [
          [90, 255, 60],
          [30, 200, 40]
        ],
        alpha: .9,
        size: [.07, .14],
        life: [.8, 1.4],
        power: [.2, .45],
        lift: .5,
        spread: .35,
        count: 2,
        blendMode: Iv.d.Standard,
        soft: !0
      },
      GC = {
        green: ZC,
        pink: {
          ...ZC,
          colours: [
            [255, 60, 170],
            [225, 30, 120]
          ],
          alpha: .95
        }
      };

    function qh(OO, KO) {
      const pO = {
        ...KO.params
      };
      for (const [bK, eO] of Object.entries(null !== (XO = KO.keys) && void 0 !== XO ? XO : {})) {
        var XO;
        pO[bK] = OO(eO)
      }
      return pO
    }
    const xh = "buildAFactory2Game:",
      nC = 2 * kX.LASER_D + 1,
      WC = kX.LASER_D;

    function th(OO) {
      return OO(`${xh}colFocusTip`, {
        need: uC(kX.NOVA_FOCUS)
      })
    }

    function kh(OO, KO) {
      return OO(KO.key, qh(OO, KO))
    }

    function UC(OO) {
      const KO = OO.getStatus();
      return {
        status: KO,
        entry: KO ? OO.entryAtRoot(KO.baf2ColAt) : void 0
      }
    }

    function Oh(OO, KO) {
      return {
        left: 100 * (WC + OO) / nC + "%",
        top: 100 * (WC + KO) / nC + "%"
      }
    }

    function Kh(OO) {
      let {
        status: KO,
        entry: pO
      } = OO;
      const XO = tb(KO.baf2ColLasers),
        bK = tb(KO.baf2ColSpots),
        eO = tb(KO.baf2ColLive),
        lO = !0 === (null === pO || void 0 === pO ? void 0 : pO.on),
        vK = kX.LASER_D,
        CO = [];
      for (let oO = 0; oO < 4; oO++) {
        const [OO, , KO] = vb[oO];
        if (eO[oO]) {
          const pO = 100 * (vK - 1) / nC,
            XO = OO + KO > 0 ? 100 * (WC + 1) / nC : 100 * (WC - (vK - 1)) / nC,
            bK = 100 * (WC + .35) / nC,
            eO = 30 / nC,
            hO = 0 !== OO ? {
              left: `${XO}%`,
              width: `${pO}%`,
              top: `${bK}%`,
              height: `${eO}%`
            } : {
              top: `${XO}%`,
              height: `${pO}%`,
              left: `${bK}%`,
              width: `${eO}%`
            };
          CO.push((0, Ve.jsx)("i", {
            className: Fb()("Baf2ColDiagramBeam", {
              Off: !lO
            }),
            style: hO
          }, `beam${oO}`))
        }
        const pO = XO[oO] ? "Baf2ColDiagramLaser" : bK[oO] ? "Baf2ColDiagramGhost" : "Baf2ColDiagramClosed";
        CO.push((0, Ve.jsx)("i", {
          className: pO,
          style: Oh(OO * vK, KO * vK)
        }, `spot${oO}`))
      }
      for (let oO = 0; oO < 4; oO++) {
        if (XO[oO] || !bK[oO]) continue;
        const [OO, , pO] = vb[oO];
        for (const XO of jh(null !== (hO = KO.baf2ColGaps) && void 0 !== hO ? hO : 0, oO)) {
          var hO;
          CO.push((0, Ve.jsx)("i", {
            className: "Baf2ColDiagramBlocker",
            style: Oh(OO * XO, pO * XO)
          }, `gap${oO},${XO}`))
        }
      }
      for (const [oO, , FO] of null !== (DO = null === pO || void 0 === pO ? void 0 : pO.blockers) && void 0 !== DO ? DO : []) {
        var DO, MO, aK;
        const OO = oO - (null !== (MO = null === pO || void 0 === pO ? void 0 : pO.focus[0]) && void 0 !== MO ? MO : 0),
          KO = FO - (null !== (aK = null === pO || void 0 === pO ? void 0 : pO.focus[2]) && void 0 !== aK ? aK : 0);
        CO.push((0, Ve.jsx)("i", {
          className: "Baf2ColDiagramBlocker",
          style: Oh(OO, KO)
        }, `block${OO},${KO}`))
      }
      return (0, Ve.jsxs)("div", {
        className: "Baf2ColDiagram",
        "aria-hidden": "true",
        children: [CO, (0, Ve.jsx)("i", {
          className: "Baf2ColDiagramFocus"
        })]
      })
    }

    function ph(OO) {
      let {
        status: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)(), XO = tb(KO.baf2ColLive).filter(Boolean).length;
      return (0, Ve.jsxs)("div", {
        className: "Baf2ColLadder",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2ColLadderHead",
          title: th(pO),
          children: pO(`${xh}colLadder`)
        }), (0, Ve.jsx)("ul", {
          children: [1, 2, 3, 4].map((OO => (0, Ve.jsx)("li", {
            className: Fb()({
              On: OO === XO
            }),
            children: pO(`${xh}colLadderChip`, {
              lasers: String(OO),
              time: gh(OO)
            })
          }, OO)))
        })]
      })
    }

    function Xh(OO) {
      let {
        item: KO,
        JK: pO,
        need: XO,
        cap: bK
      } = OO;
      const {
        t: eO
      } = (0, ze.D)(), lO = Math.min(pO, XO);
      return (0, Ve.jsxs)("li", {
        className: Fb()("Baf2ColTile", {
          Short: pO < XO
        }),
        children: [(0, Ve.jsx)(bD, {
          item: KO
        }), (0, Ve.jsx)("b", {
          className: "Baf2ColTileValue",
          children: eO(`${xh}colOutOf`, {
            amount: String(lO),
            cap: String(XO)
          })
        }), (0, Ve.jsx)("span", {
          className: "Baf2ColBar",
          children: (0, Ve.jsx)("i", {
            style: {
              width: 100 * lO / XO + "%"
            }
          })
        }), pO > XO && (0, Ve.jsx)("span", {
          className: "Baf2ColTileSoft",
          children: eO(`${xh}colIntakeHeld`, {
            amount: String(pO),
            cap: String(bK)
          })
        })]
      })
    }

    function bD(OO) {
      let {
        item: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)();
      return (0, Ve.jsxs)("span", {
        className: "Baf2ColTileHead",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2ColItemIcon",
          children: (0, Ve.jsx)(fb.b, {
            itemName: KO,
            amount: 0
          })
        }), (0, Ve.jsx)("span", {
          className: "Baf2ColTileName",
          children: xe(pO, KO)
        })]
      })
    }

    function eh(OO) {
      switch (OO.baf2ColState) {
        case "running":
          return "Good";
        case "hold":
          return "Off";
        default:
          return "Warn"
      }
    }

    function lh(OO) {
      var KO, pO, bK;
      let {
        store: eO,
        close: lO
      } = OO;
      const {
        t: vK
      } = (0, ze.D)(), CO = Yl(), {
        status: hO,
        entry: DO
      } = function(OO) {
        const [KO, pO] = (0, XO.useState)((() => UC(OO)));
        return (0, XO.useEffect)((() => (pO(UC(OO)), OO.subscribe((() => {
          pO(UC(OO))
        })))), [OO]), KO
      }(eO), [MO, aK] = (0, XO.useState)(null), oO = null === hO || void 0 === hO ? void 0 : hO.baf2ColHold;
      (0, XO.useEffect)((() => {
        aK(null)
      }), [oO]);
      const FO = (0, XO.useRef)({
          p: -1,
          n: 0
        }),
        VO = null !== (KO = null === hO || void 0 === hO ? void 0 : hO.baf2ColP) && void 0 !== KO ? KO : -1;
      VO < FO.current.p && FO.current.n++, FO.current.p = VO;
      const LO = (0, XO.useRef)(null),
        [QO] = (0, XO.useState)((() => {
          return (OO = eO.heldAtOpen()) === KX || OO === pX ? {
            key: `${NC}colBeltItIn`,
            item: OO
          } : null;
          var OO
        }));
      if (!hO) return null;
      const zK = hO.baf2ColMember,
        AO = hO.baf2ColP >= 0,
        fO = function(OO, KO) {
          if (OO.baf2ColP >= 0 && OO.baf2ColDraw > 0) {
            const KO = OO.baf2ColWant > 0 ? Math.min(1, OO.baf2ColDraw / OO.baf2ColWant) : 0;
            return {
              focus: OO.baf2ColFocusPerS * KO,
              draw: OO.baf2ColDraw,
              beamsOn: !0
            }
          }
          return "running" === OO.baf2ColState && KO && KO.draw > 0 ? {
            ...KO,
            beamsOn: !0
          } : {
            focus: 0,
            draw: 0,
            beamsOn: !1
          }
        }(hO, LO.current);
      LO.current = fO.draw > 0 ? fO : null;
      const dO = "slowed" === hO.baf2ColState || "noPower" === hO.baf2ColState,
        TO = sC(hO),
        NO = null !== MO && void 0 !== MO ? MO : hO.baf2ColHold,
        IO = function(OO) {
          var KO, pO;
          return "idle" === OO.baf2ColRxState ? null : null !== (KO = null === (pO = ih(OO)) || void 0 === pO ? void 0 : pO.fix) && void 0 !== KO ? KO : null
        }(hO),
        yK = null === IO && null === QO ? function(OO) {
          var KO;
          const pO = OO.baf2ColSentTo;
          if (!pO) return null;
          const XO = null !== (KO = OO.baf2ColSentHeld) && void 0 !== KO ? KO : null;
          return {
            key: null === XO ? `${NC}colNovaSentToMachine` : `${NC}colNovaSentTo`,
            target: pO,
            JK: XO
          }
        }(hO) : null,
        gK = AO ? vK(`${xh}colFocusOf`, {
          focus: uC(hO.baf2ColP),
          need: uC(kX.NOVA_FOCUS)
        }) : null;
      return (0, Ve.jsx)(Ml.d, {
        close: lO,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay Baf2ColOverlay",
        children: (0, Ve.jsxs)("section", {
          className: "Baf2Panel Baf2ColliderPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2ColTitle",
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsxs)("div", {
              className: "Baf2ColTitle",
              children: [(0, Ve.jsx)("span", {
                className: "Baf2PanelIcon",
                children: (0, Ve.jsx)(fb.b, {
                  itemName: Up,
                  amount: 0
                })
              }), (0, Ve.jsxs)("div", {
                children: [(0, Ve.jsx)("h2", {
                  id: "baf2ColTitle",
                  children: xe(vK, Up)
                }), (0, Ve.jsx)("p", {
                  children: kh(vK, rh(hO))
                })]
              })]
            }), (0, Ve.jsx)(av.i, {
              onClick: lO
            })]
          }), (0, Ve.jsxs)("div", {
            className: "Baf2ColBody",
            children: [(0, Ve.jsxs)("div", {
              className: "Baf2ColMain",
              children: [(0, Ve.jsxs)("div", {
                className: "Baf2ColHero",
                children: [(0, Ve.jsx)("b", {
                  className: "Baf2ColHeroLine",
                  children: vK(mh(hO), {
                    time: null === TO ? "" : Me(vK, TO)
                  })
                }), (0, Ve.jsx)("span", {
                  className: "Baf2ColBar Big",
                  children: (0, Ve.jsx)("i", {
                    style: {
                      width: (AO ? 100 * hO.baf2ColP / kX.NOVA_FOCUS : 0) + "%"
                    }
                  }, FO.current.n)
                }), (0, Ve.jsxs)("div", {
                  className: "Baf2ColRate",
                  children: [(0, Ve.jsxs)("span", {
                    title: th(vK),
                    children: [(0, Ve.jsx)("b", {
                      children: uC(fO.focus)
                    }), " ", vK(`${xh}colFocusPerS`)]
                  }), (0, Ve.jsxs)("span", {
                    className: Fb()("Baf2ColDraw", {
                      Short: dO
                    }),
                    children: [(0, Ve.jsx)(Ab.d, {
                      name: "bolt"
                    }), dO ? vK(`${xh}colDrawOf`, {
                      draw: uC(hO.baf2ColDraw),
                      want: uC(hO.baf2ColWant)
                    }) : vK(`${xh}colPowerPerS`, {
                      rate: uC(fO.draw)
                    })]
                  }), null !== gK && (0, Ve.jsx)("span", {
                    className: "Soft",
                    children: gK
                  })]
                })]
              }), (0, Ve.jsx)("p", {
                className: Fb()("Baf2ColState", eh(hO)),
                children: kh(vK, PC(hO))
              }), null !== IO && (0, Ve.jsx)("p", {
                className: "Baf2ColStateFix",
                children: vK(IO)
              }), null === IO && null !== QO && (0, Ve.jsx)("p", {
                className: "Baf2ColStateFix",
                children: vK(QO.key, {
                  item: xe(vK, QO.item)
                })
              }), yK && (0, Ve.jsx)("p", {
                className: "Baf2ColStateFix",
                children: vK(yK.key, {
                  target: xe(vK, yK.target),
                  amount: String(null !== (pO = yK.JK) && void 0 !== pO ? pO : 0)
                })
              }), (0, Ve.jsxs)("ul", {
                className: "Baf2ColTiles",
                children: [(0, Ve.jsx)(Xh, {
                  item: KX,
                  JK: hO.baf2ColSa,
                  need: kX.NOVA_SA,
                  cap: kX.SA_CAP
                }), (0, Ve.jsx)(Xh, {
                  item: pX,
                  JK: hO.baf2ColGd,
                  need: kX.NOVA_GD,
                  cap: kX.GD_CAP
                }), (0, Ve.jsxs)("li", {
                  className: "Baf2ColTile",
                  children: [(0, Ve.jsx)(bD, {
                    item: "Nova Matter"
                  }), (0, Ve.jsx)("b", {
                    className: "Baf2ColTileValue",
                    children: vK(`${xh}colNovaHeld`, {
                      amount: String(hO.baf2ColOut),
                      cap: String(kX.OUT_CAP)
                    })
                  }), zK && (0, Ve.jsx)(av.m, {
                    className: "Baf2ColTake",
                    disabled: 0 === hO.baf2ColOut,
                    onClick: () => {
                      CO.send(yh(hO, "take"))
                    },
                    children: vK(`${xh}colTake`)
                  })]
                })]
              }), zK && (0, Ve.jsxs)("button", {
                type: "button",
                role: "switch",
                "aria-checked": NO,
                className: Fb()("Baf2ColHold", {
                  On: NO
                }),
                onClick: OO => {
                  OO.detail > 0 && OO.currentTarget.blur(), aK(!NO), CO.send(yh(hO, "hold " + (NO ? 0 : 1)))
                },
                children: [(0, Ve.jsx)("span", {
                  className: "Baf2ColHoldKnob"
                }), (0, Ve.jsxs)("span", {
                  className: "Baf2ColHoldText",
                  children: [(0, Ve.jsx)("b", {
                    children: vK(`${xh}colHold`)
                  }), (0, Ve.jsx)("span", {
                    children: vK(`${xh}colHoldNote`)
                  })]
                })]
              })]
            }), (0, Ve.jsxs)("div", {
              className: "Baf2ColSide",
              children: [(0, Ve.jsx)(Kh, {
                status: hO,
                entry: DO
              }), (0, Ve.jsx)("ul", {
                className: "Baf2ColSlots",
                children: wC(hO.baf2ColLasers, hO.baf2ColSpots, hO.baf2ColLive, fO.beamsOn, null !== (bK = hO.baf2ColGaps) && void 0 !== bK ? bK : 0).map((OO => (0, Ve.jsxs)("li", {
                  className: OO.tone,
                  children: [(0, Ve.jsx)("b", {
                    children: kh(vK, OO.title)
                  }), null !== OO.hint && (0, Ve.jsx)("span", {
                    children: kh(vK, OO.hint)
                  })]
                }, OO.dir)))
              }), (0, Ve.jsx)(ph, {
                status: hO
              })]
            })]
          })]
        })
      })
    }
    const vD = "buildAFactory2Game:",
      Ch = 36e5,
      hh = 864e5;

    function Dh(OO, KO, pO) {
      return Math.max(0, Math.ceil((OO + KO - Math.max(pO, OO)) / 1e3))
    }

    function Mh(OO) {
      return OO.trim().replace(/\s+/g, " ").slice(0, 24).trim()
    }

    function aD(OO) {
      return "Homestead" === OO
    }

    function oh(OO) {
      return function(OO) {
        let KO = 0;
        for (const pO of OO) {
          const OO = /^Island ([1-9]\d{0,5})$/.exec(pO);
          OO && (KO = Math.max(KO, Number(OO[1])))
        }
        return `Island ${KO+1}`
      }(OO.map((OO => OO.baf2IslandName)))
    }

    function Fh(OO, KO) {
      return function(OO) {
        return `${vD}islandsBlocked${OO[0].toUpperCase()}${OO.slice(1)}`
      }("degraded" === OO && 0 === KO ? "stuck" : OO)
    }

    function Vh(OO) {
      return OO.filter((OO => {
        var KO;
        return !OO.baf2IslandActive && void 0 === OO.baf2IslandUnreadable && void 0 === (null === (KO = OO.baf2IslandCoop) || void 0 === KO ? void 0 : KO.baf2CoopState)
      })).length
    }

    function Lh(OO) {
      return "coopMoving" === OO || "coopUnreachable" === OO
    }

    function Qh(OO, KO) {
      const pO = KO > 0;
      return {
        change: null === OO && !pO,
        switch: (null === OO || "degraded" === OO || Lh(OO)) && !pO,
        rename: "loading" !== OO && "degraded" !== OO && "stuck" !== OO
      }
    }

    function zD(OO, KO) {
      return void 0 === OO || "corrupt" === OO && KO
    }
    const Ah = Nl;

    function fh(OO, KO, pO) {
      if (null !== OO && void 0 !== OO && OO.untilGone) {
        var XO;
        return !("dismiss" === OO.untilGone && void 0 === (null === (XO = KO.baf2IslandCoop) || void 0 === XO ? void 0 : XO.baf2CoopState)) && pO - OO.atMs < 32500
      }
      return void 0 !== OO && pO - OO.atMs < Ah && KO.baf2IslandName === OO.from
    }
    const dh = Nl;

    function Th(OO) {
      return "core" === (null === OO || void 0 === OO ? void 0 : OO.kind) ? OO.core : "islands" === (null === OO || void 0 === OO ? void 0 : OO.kind) ? OO.backToCore : void 0
    }

    function Nh(OO) {
      return `\0${OO}\0`
    }

    function Ih(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      const XO = {
        ...arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}
      };
      for (const eO of Object.keys(pO)) XO[eO] = Nh(eO);
      let bK = Object.keys(XO).length > 0 ? OO(KO, XO) : OO(KO);
      for (const [eO, lO] of Object.entries(pO)) bK = bK.split(Nh(eO)).join(lO);
      return bK
    }

    function yD(OO, KO) {
      return OO ? KO ? "enabled" : "disabled" : "hidden"
    }
    const gD = {
      removed: `${vD}islandsCoopRemoved`,
      deleted: `${vD}islandsCoopDeleted`,
      notReady: `${vD}islandsCoopNotReady`,
      gone: `${vD}islandsCoopGone`
    };

    function uh(OO) {
      var KO;
      return "member" !== (null === (KO = OO.baf2IslandCoop) || void 0 === KO ? void 0 : KO.baf2CoopRole) && "newer" !== OO.baf2IslandUnreadable
    }

    function Eh(OO, KO, pO, XO, bK) {
      const eO = OO.baf2IslandActive,
        lO = OO.baf2IslandUnreadable,
        vK = OO.baf2IslandCoop,
        CO = function(OO, KO, pO) {
          return {
            switch: OO.switch && void 0 === KO,
            delete: OO.change && zD(KO, pO)
          }
        }(KO, lO, XO),
        hO = {
          switch: yD(!eO && void 0 === lO, CO.switch),
          rename: yD(!0, KO.rename),
          delete: yD(!eO, CO.delete),
          deleteWaits: !eO && zD(lO, XO),
          people: yD(void 0 !== OO.baf2IslandInvitable || bK && eO && void 0 === lO && void 0 === vK, !0),
          peopleLabel: "invite",
          DX: "hidden",
          dismiss: "hidden",
          unshare: "hidden",
          remove: !1,
          note: null
        },
        DO = !eO && CO.delete;
      if (void 0 === vK) return pO ? {
        ...hO,
        delete: yD(!eO, !1),
        deleteWaits: !1,
        note: DO ? {
          key: `${vD}islandsCoopKeepOwn`
        } : null
      } : hO;
      const MO = vK.baf2CoopState,
        aK = vK.baf2CoopMembers.length > 1,
        oO = {
          ...hO,
          switch: "hidden",
          rename: "hidden",
          delete: "hidden",
          deleteWaits: !1,
          people: "hidden"
        };
      if (void 0 !== MO && "member" === vK.baf2CoopRole) return {
        ...oO,
        dismiss: yD(!0, KO.rename),
        note: {
          key: gD[MO],
          names: {
            owner: vK.baf2CoopOwner
          }
        }
      };
      if (void 0 !== MO) {
        let OO = {
          key: `${vD}islandsCoopOwnLost`
        };
        return DO && aK ? OO = {
          key: `${vD}islandsCoopDeleteMembers`
        } : DO && pO && (OO = {
          key: `${vD}islandsCoopKeepOwn`
        }), {
          ...oO,
          delete: yD(!eO, CO.delete && !aK && !pO),
          deleteWaits: hO.deleteWaits && !aK && !pO,
          note: OO
        }
      }
      if ("member" === vK.baf2CoopRole) return {
        ...hO,
        rename: "hidden",
        delete: "hidden",
        deleteWaits: !1,
        people: "hidden",
        DX: yD(!0, eO ? KO.switch : KO.rename)
      };
      const FO = vK.baf2CoopManageHere;
      let VO = null;
      var LO;
      FO ? DO && aK ? VO = {
        key: `${vD}islandsCoopDeleteMembers`
      } : DO && pO && (VO = {
        key: `${vD}islandsCoopKeepOwn`
      }) : VO = {
        key: null !== (LO = vK.baf2CoopLeft) && void 0 !== LO && LO.length ? `${vD}islandsCoopManageThereClaim` : `${vD}islandsCoopManageThere`
      };
      return {
        ...hO,
        rename: yD(!0, KO.rename && FO),
        delete: yD(!eO, CO.delete && !aK && !pO),
        deleteWaits: hO.deleteWaits && !aK && !pO,
        people: "enabled",
        peopleLabel: "players",
        unshare: yD(FO && eO && !aK, KO.change),
        remove: FO,
        note: VO
      }
    }

    function jD(OO) {
      var KO;
      const pO = OO.baf2IslandCoop;
      if ("owner" !== (null === pO || void 0 === pO ? void 0 : pO.baf2CoopRole) || void 0 !== pO.baf2CoopState || null === (KO = pO.baf2CoopLeft) || void 0 === KO || !KO.length) return null;
      const XO = OO.baf2IslandActive && pO.baf2CoopManageHere;
      return {
        left: pO.baf2CoopLeft,
        claim: XO,
        goThere: !XO && pO.baf2CoopManageHere
      }
    }

    function Yh(OO) {
      return OO.baf2CoopMembers.length >= OO.baf2CoopMax
    }

    function wh(OO, KO, pO) {
      return void 0 !== OO && KO < OO.answer && pO - OO.atMs < Ah
    }
    const iD = "buildAFactory2Game:";

    function rD(OO, KO) {
      return {
        onKeyDown: pO => {
          pO.stopPropagation(), pO.nativeEvent.isComposing || 229 === pO.nativeEvent.keyCode || ("Enter" === pO.key ? (pO.preventDefault(), OO()) : "Escape" === pO.key && (pO.preventDefault(), KO()))
        }
      }
    }

    function Ph(OO) {
      return {
        onKeyDown: KO => {
          "Escape" !== KO.key || KO.nativeEvent.isComposing || (KO.preventDefault(), KO.stopPropagation(), OO())
        }
      }
    }

    function mD(OO) {
      OO.currentTarget.select()
    }

    function sh(OO, KO) {
      (0, XO.useEffect)((() => {
        var pO;
        OO && (null === (pO = KO.current) || void 0 === pO || pO.scrollIntoView({
          block: "nearest"
        }))
      }), [OO, KO])
    }

    function Hh(OO) {
      const [KO, pO] = (0, XO.useState)(null);
      return (0, XO.useEffect)((() => {
        const KO = document.querySelector(".UiRequests"),
          XO = OO.current;
        if (!KO || !XO || "undefined" === typeof ResizeObserver) return;
        const bK = () => {
          const OO = KO.getBoundingClientRect(),
            bK = XO.getBoundingClientRect(),
            eO = XO.parentElement,
            lO = eO && parseFloat(getComputedStyle(eO).paddingTop) || 0,
            vK = function(OO, KO, pO, XO) {
              if (!OO || OO.height <= 0 || OO.right <= KO.left || OO.left >= KO.right) return null;
              const bK = Math.max(XO, OO.bottom + 8);
              return {
                marginTop: Math.round(bK - XO),
                maxHeight: Math.max(0, Math.floor(pO - bK - XO))
              }
            }(OO, bK, window.innerHeight, lO);
          pO((OO => (null === OO || void 0 === OO ? void 0 : OO.marginTop) === (null === vK || void 0 === vK ? void 0 : vK.marginTop) && (null === OO || void 0 === OO ? void 0 : OO.maxHeight) === (null === vK || void 0 === vK ? void 0 : vK.maxHeight) ? OO : vK))
        };
        bK();
        const eO = new ResizeObserver(bK);
        return eO.observe(KO), window.addEventListener("resize", bK), () => {
          eO.disconnect(), window.removeEventListener("resize", bK)
        }
      }), [OO]), KO
    }

    function Rh(OO) {
      (0, XO.useEffect)((() => {
        var KO;
        null === (KO = OO.current) || void 0 === KO || KO.focus()
      }), [OO])
    }

    function Sh(OO) {
      const [KO, pO] = (0, XO.useState)(Date.now);
      return (0, XO.useEffect)((() => {
        const KO = window.setInterval((() => {
          pO(Date.now())
        }), OO);
        return () => {
          window.clearInterval(KO)
        }
      }), [OO]), KO
    }

    function Jh(OO) {
      let {
        tier: KO,
        t: pO
      } = OO;
      const {
        kind: XO,
        short: bK
      } = LO(KO), eO = oO(KO, FO), lO = pO(`${iD}${eO.key}`, {
        ...eO.params,
        name: pO(`${iD}${QO(KO).nameKey}`)
      });
      return (0, Ve.jsxs)("span", {
        className: "Baf2IslandTier",
        children: [(0, Ve.jsx)("span", {
          className: Fb()("Baf2IslandTierPip", {
            Stage: "tier" !== XO
          }),
          "aria-hidden": "true",
          children: bK
        }), lO]
      })
    }

    function cD(OO) {
      let {
        note: KO,
        className: pO,
        t: XO
      } = OO;
      return (0, Ve.jsx)("p", {
        className: Fb()("Baf2IslandNote", pO),
        children: Ih(XO, KO.key, KO.names, KO.params)
      })
    }
    const Bh = "buildAFactory2Game:";

    function Zh(OO) {
      let {
        message: KO,
        arrivedAtMs: pO,
        close: bK,
        DX: eO
      } = OO;
      const lO = Yl(),
        {
          t: vK
        } = (0, ze.D)(),
        CO = Sh(1e3),
        hO = (0, XO.useRef)(null);
      (0, XO.useEffect)((() => {
        var OO;
        null === (OO = hO.current) || void 0 === OO || OO.focus()
      }), []);
      const DO = Dh(pO, KO.baf2TransferInMs, CO),
        MO = pO + KO.baf2TransferInMs - 1e3,
        [aK, oO] = (0, XO.useState)(null);
      (0, XO.useEffect)((() => {
        const OO = window.setTimeout((() => {
          oO(MO)
        }), Math.max(0, MO - Date.now()));
        return () => {
          window.clearTimeout(OO)
        }
      }), [MO]);
      const FO = aK === MO || CO >= MO,
        VO = KO.baf2TransferIsland,
        LO = KO.baf2TransferOwner;
      return (0, Ve.jsx)(Ml.d, {
        close: bK,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay Baf2IslandsOverlay",
        children: (0, Ve.jsxs)("section", {
          ref: hO,
          tabIndex: -1,
          className: "Baf2Panel Baf2IslandsPanel Baf2TransferPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2TransferTitle",
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsxs)("div", {
              children: [(0, Ve.jsx)("h2", {
                id: "baf2TransferTitle",
                children: void 0 === LO ? Ih(vK, `${Bh}islandsTransferOwn`, {
                  island: VO
                }) : Ih(vK, `${Bh}islandsTransfer`, {
                  island: VO,
                  owner: LO
                })
              }), (0, Ve.jsx)("p", {
                children: FO ? vK(`${Bh}islandsTransferNow`) : vK(`${Bh}islandsTransferIn`, {
                  time: Me(vK, DO)
                })
              })]
            }), (0, Ve.jsx)(av.i, {
              ariaLabel: vK(`${Bh}islandsClose`),
              onClick: bK
            })]
          }), !FO && (0, Ve.jsxs)("div", {
            className: "Baf2IslandsBody",
            children: [(0, Ve.jsx)("p", {
              className: "Baf2TransferNote",
              children: vK(`${Bh}islandsTransferNote`)
            }), (0, Ve.jsx)("div", {
              className: "Baf2IslandButtons",
              children: (0, Ve.jsx)(av.d, {
                onClick: () => {
                  lO.send("baf2coopstay"), eO()
                },
                children: vK(`${Bh}islandsTransferStay`)
              })
            })]
          })]
        })
      })
    }
    var Gh = pO(1263),
      qD = pO(35228),
      xD = pO.n(qD);
    const nh = new Set(["stepItemForCore", "stepItemInCore", "stepBeltItem", "stepBeltItemCarried", "stepBeltCount", "stepBeltCountCarried", "stepHandOverItem", "stepTakeBars", "stepCharge", "stepChargePower", "stepCraftHxForCondenser", "stepCollectFromAssembler"]);
    const Wh = "buildAFactory2Game:",
      tD = {
        "--baf2-quest-step-flash": "1600ms",
        "--baf2-quest-step-pop": "600ms"
      };

    function kD(OO, KO, pO) {
      return void 0 === KO ? pO : "string" === typeof KO ? KO : Array.isArray(KO) ? KO.map((KO => "string" === typeof KO ? KO : "translationKey" in KO ? OO(KO.translationKey) : "")).join("") : OO(KO.translationKey)
    }

    function Uh(OO) {
      const KO = {};
      for (const [pO, XO] of Object.entries(null !== OO && void 0 !== OO ? OO : {})) KO[pO] = XO < 0 ? De(XO) : XO.toLocaleString("en-US");
      return KO
    }
    const OD = (0, XO.memo)((function(OO) {
      let {
        item: KO
      } = OO;
      return (0, Ve.jsx)("span", {
        className: "Baf2QuestStepIcon",
        "aria-hidden": "true",
        children: (0, Ve.jsx)(fb.b, {
          itemName: KO,
          amount: 0
        })
      })
    }));

    function KD(OO) {
      let {
        label: KO,
        percent: pO,
        progress: XO
      } = OO;
      return (0, Ve.jsxs)("span", {
        className: "Baf2QuestStepBar",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2QuestProgressBar",
          role: "progressbar",
          "aria-label": `${KO}: ${XO}`,
          "aria-valuemin": 0,
          "aria-valuemax": 100,
          "aria-valuenow": pO,
          children: (0, Ve.jsx)("span", {
            className: "Baf2QuestProgressBarFill",
            style: {
              width: `${pO}%`
            }
          })
        }), (0, Ve.jsx)("span", {
          className: "Baf2QuestStepBarLabel",
          children: XO
        })]
      })
    }

    function pD(OO) {
      let {
        chips: KO
      } = OO;
      return (0, Ve.jsx)("span", {
        className: "Baf2QuestChips",
        children: KO.map((OO => {
          let [KO, pO, XO] = OO;
          const bK = pO >= XO;
          return (0, Ve.jsxs)("span", {
            className: Fb()("Baf2QuestChip", {
              Met: bK
            }),
            children: [(0, Ve.jsx)(OD, {
              item: KO
            }), (0, Ve.jsx)("span", {
              className: "Baf2QuestChipCount",
              children: bK ? `\u2713${XO}` : `${pO}/${XO}`
            })]
          }, KO)
        }))
      })
    }

    function XD(OO, KO) {
      const {
        key: pO,
        params: XO
      } = oO(KO, {
        tier: "questChapter",
        stage: "questChapterStage",
        atomic: "questChapterAtomic"
      });
      return OO(`${Wh}${pO}`, {
        ...XO,
        name: OO(`${Wh}${QO(KO).nameKey}`)
      })
    }

    function bM(OO) {
      let {
        core: KO,
        t: pO
      } = OO;
      const [XO, bK] = KO, eO = bK > 0 ? Math.floor(100 * XO / bK) : 100;
      return (0, Ve.jsxs)("span", {
        className: "Baf2QuestCore",
        role: "progressbar",
        "aria-label": pO(`${Wh}questCoreLabel`, {
          have: String(XO),
          need: String(bK)
        }),
        "aria-valuemin": 0,
        "aria-valuemax": 100,
        "aria-valuenow": eO,
        children: [(0, Ve.jsx)("span", {
          className: "Baf2QuestCoreText",
          children: pO(`${Wh}questCore`, {
            percent: String(eO)
          })
        }), (0, Ve.jsx)("span", {
          className: "Baf2QuestCoreBar",
          children: (0, Ve.jsx)("span", {
            className: "Baf2QuestCoreBarFill",
            style: {
              width: `${eO}%`
            }
          })
        })]
      })
    }

    function eD(OO) {
      let {
        rows: KO,
        t: pO
      } = OO;
      const XO = KO.filter((OO => OO.done)).length;
      return (0, Ve.jsx)("span", {
        className: "Baf2QuestSegments",
        role: "progressbar",
        "aria-label": pO(`${Wh}questStepsProgress`, {
          done: String(XO),
          total: String(KO.length)
        }),
        "aria-valuemin": 0,
        "aria-valuemax": KO.length,
        "aria-valuenow": XO,
        children: KO.map((OO => (0, Ve.jsx)("span", {
          className: Fb()("Baf2QuestSegment", {
            Done: OO.done,
            Current: OO.current
          })
        }, OO.id)))
      })
    }
    const lD = (0, XO.memo)(CD, vM);

    function vM(OO, KO) {
      const pO = pO => OO.view.itemNames[pO] === KO.view.itemNames[pO];
      return OO.t === KO.t && OO.extra === KO.extra && (null === OO.row.item || pO(OO.row.item)) && OO.row.madeFor.every(pO) && OO.row.also.every(pO) && xD()(OO.row, KO.row)
    }

    function CD(OO) {
      let {
        row: KO,
        view: pO,
        t: XO,
        extra: bK
      } = OO;
      const eO = KO.item ? function(OO, KO, pO) {
          return 1 !== pO && nh.has(OO) ? Qb(KO) : null
        }(KO.key, KO.item, KO.total) : null,
        lO = eO ? XO(eO) : KO.item ? kD(XO, pO.itemNames[KO.item], KO.item) : "",
        vK = KO.also.map((OO => kD(XO, pO.itemNames[OO], OO))),
        CO = vK.join(", "),
        hO = function(OO, KO) {
          var pO;
          return KO.length < 2 ? null !== (pO = KO[0]) && void 0 !== pO ? pO : "" : OO(`${Wh}listAnd`, {
            rest: KO.slice(0, -1).join(OO(`${Wh}listComma`)),
            last: KO[KO.length - 1]
          })
        }(XO, [lO, ...vK]),
        DO = XO(`${Wh}${KO.key}`, {
          ...Uh(KO.params),
          item: lO,
          also: CO,
          itemList: hO,
          total: String(KO.total)
        }),
        [MO, ...aK] = DO.split("\n"),
        oO = KO.total > 1 && !KO.done && !KO.away;
      return (0, Ve.jsxs)("li", {
        className: Fb()("Baf2QuestStep", {
          Done: KO.done,
          Current: KO.current,
          JustFinished: KO.justFinished,
          Away: KO.away
        }),
        children: [!KO.done && null !== KO.item && (0, Ve.jsx)(OD, {
          item: KO.item
        }), (KO.done || null === KO.item) && (0, Ve.jsx)("span", {
          className: "Baf2QuestStepMark",
          "aria-hidden": "true",
          children: KO.done ? "\u2713" : "\u25cb"
        }), (0, Ve.jsxs)("span", {
          className: "Baf2QuestStepBody",
          children: [(0, Ve.jsx)("strong", {
            children: MO
          }), aK.length > 0 && (0, Ve.jsx)("span", {
            className: "Baf2QuestStepNote",
            children: aK.join(" ")
          }), !KO.done && KO.madeFor.length > 0 && (0, Ve.jsx)("span", {
            className: "Baf2QuestStepNote",
            children: XO("buildAFactory2Game:questRowFor", {
              items: KO.madeFor.map((OO => kD(XO, pO.itemNames[OO], OO))).join(" \u2192 ")
            })
          }), oO && (0, Ve.jsx)(KD, {
            label: MO,
            percent: Math.round(100 * KO.amount / KO.total),
            progress: `${KO.amount.toLocaleString("en-US")}/${KO.total.toLocaleString("en-US")}`
          }), !KO.done && !KO.away && KO.chips && KO.chips.length > 0 && (0, Ve.jsx)(pD, {
            chips: KO.chips
          }), bK]
        })]
      })
    }

    function hD(OO, KO) {
      let [pO, XO] = KO;
      return OO(`${Wh}${pO}`, Uh(XO))
    }

    function DD(OO) {
      let [KO, pO] = OO;
      return KO + JSON.stringify(pO)
    }

    function MD(OO) {
      let {
        goal: KO,
        t: pO
      } = OO;
      return KO ? (0, Ve.jsx)("span", {
        className: "Baf2BookGoal",
        children: pO(`${Wh}${KO}`)
      }) : null
    }

    function aM(OO) {
      let {
        view: KO,
        t: pO
      } = OO;
      if (!KO.name) return null;
      const XO = ie(KO.rows);
      return (0, Ve.jsxs)("li", {
        className: "Baf2BookQuest Current",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2BookEyebrow",
          children: pO(`${Wh}currentQuest`)
        }), (0, Ve.jsx)("strong", {
          className: "Baf2BookTitle",
          children: hD(pO, KO.name)
        }), (0, Ve.jsx)(MD, {
          goal: KO.goal,
          t: pO
        }), XO.length > 1 && (0, Ve.jsx)(eD, {
          rows: XO,
          t: pO
        }), (0, Ve.jsx)("ul", {
          className: "Baf2QuestChecklist",
          children: KO.rows.map((OO => (0, Ve.jsx)(lD, {
            row: OO,
            view: KO,
            t: pO
          }, OO.id)))
        }), KO.reward && (0, Ve.jsxs)("span", {
          className: "Baf2BookReward",
          children: [pO(`${Wh}questReward`), (0, Ve.jsx)(OD, {
            item: KO.reward
          }), kD(pO, KO.itemNames[KO.reward], KO.reward)]
        })]
      })
    }

    function oD(OO) {
      let {
        quest: KO,
        upcoming: pO,
        t: XO
      } = OO;
      return (0, Ve.jsxs)("li", {
        className: Fb()("Baf2BookQuest", {
          Done: KO[3],
          Upcoming: pO
        }),
        children: [(0, Ve.jsx)("span", {
          className: "Baf2BookMark",
          "aria-hidden": "true",
          children: KO[3] ? "\u2713" : "\u25cb"
        }), (0, Ve.jsxs)("span", {
          className: "Baf2BookQuestText",
          children: [(0, Ve.jsx)("strong", {
            className: "Baf2BookTitle",
            children: hD(XO, KO)
          }), (0, Ve.jsx)(MD, {
            goal: KO[2],
            t: XO
          })]
        })]
      })
    }

    function FD(OO) {
      let {
        done: KO,
        total: pO,
        t: XO
      } = OO;
      const bK = pO > 0 ? Math.round(100 * KO / pO) : 0,
        eO = XO(`${Wh}questBookChapterProgress`, {
          done: String(KO),
          total: String(pO)
        });
      return (0, Ve.jsxs)("span", {
        className: "Baf2BookProgress",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2BookProgressBar",
          role: "progressbar",
          "aria-label": eO,
          "aria-valuemin": 0,
          "aria-valuemax": pO,
          "aria-valuenow": KO,
          children: (0, Ve.jsx)("span", {
            className: "Baf2BookProgressFill",
            style: {
              width: `${bK}%`
            }
          })
        }), (0, Ve.jsx)("span", {
          className: "Baf2BookProgressText",
          children: eO
        })]
      })
    }

    function VD(OO) {
      let {
        view: KO,
        tier: pO,
        quests: XO,
        t: bK
      } = OO;
      const eO = pO === KO.tier,
        lO = (null !== XO && void 0 !== XO ? XO : []).filter((OO => !OO[4])),
        vK = (null !== XO && void 0 !== XO ? XO : []).filter((OO => OO[4])),
        CO = lO.filter((OO => OO[3])).length,
        hO = eO && KO.name ? DD(KO.name) : null,
        DO = lO.findIndex((OO => !OO[3] && DD(OO) === hO));
      return (0, Ve.jsxs)("div", {
        className: "Baf2BookChapter",
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2BookChapterHead",
          children: [(0, Ve.jsx)("h3", {
            children: XD(bK, pO)
          }), lO.length > 0 && (0, Ve.jsx)(FD, {
            done: CO,
            total: lO.length,
            t: bK
          }), eO && KO.core && (0, Ve.jsx)(bM, {
            core: KO.core,
            t: bK
          })]
        }), (0, Ve.jsxs)("ol", {
          className: "Baf2BookQuests",
          children: [null === XO && eO && (0, Ve.jsx)(aM, {
            view: KO,
            t: bK
          }), lO.map(((OO, pO) => pO === DO ? (0, Ve.jsx)(aM, {
            view: KO,
            t: bK
          }, DD(OO)) : (0, Ve.jsx)(oD, {
            quest: OO,
            upcoming: !OO[3],
            t: bK
          }, DD(OO))))]
        }), eO && KO.side && (0, Ve.jsxs)("div", {
          className: "Baf2BookSide",
          children: [(0, Ve.jsx)("span", {
            className: "Baf2BookEyebrow",
            children: bK(`${Wh}questSide`)
          }), (0, Ve.jsx)("strong", {
            className: "Baf2BookTitle",
            children: hD(bK, KO.side.name)
          }), (0, Ve.jsx)(MD, {
            goal: KO.side.goal,
            t: bK
          }), (0, Ve.jsx)("ul", {
            className: "Baf2QuestChecklist",
            children: (0, Ve.jsx)(lD, {
              row: KO.side.row,
              view: KO,
              t: bK
            })
          })]
        }), vK.length > 0 && (0, Ve.jsxs)(Ve.Fragment, {
          children: [(0, Ve.jsx)("h4", {
            className: "Baf2BookSubhead",
            children: bK(`${Wh}questBookSidesDone`)
          }), (0, Ve.jsx)("ol", {
            className: "Baf2BookQuests",
            children: vK.map((OO => (0, Ve.jsx)(oD, {
              quest: OO,
              upcoming: !1,
              t: bK
            }, DD(OO))))
          })]
        })]
      })
    }

    function LD(OO) {
      var KO, pO, eO;
      let {
        store: lO,
        close: vK
      } = OO;
      const {
        t: CO
      } = (0, ze.D)(), hO = (0, Gh.h)(ge, lO.get()), MO = null !== (KO = hO.tier) && void 0 !== KO ? KO : 1, [aK, oO] = (0, XO.useState)(null), FO = (null === aK || void 0 === aK ? void 0 : aK.at) === MO ? aK.tier : MO, QO = (0, XO.useRef)(null), zK = null !== hO.chapters;
      (0, XO.useEffect)((() => {
        var OO;
        QO.current && (QO.current.scrollTop = 0);
        const KO = null === (OO = QO.current) || void 0 === OO ? void 0 : OO.querySelector(".Baf2BookQuest.Current");
        if (QO.current && KO) {
          const OO = KO.getBoundingClientRect().bottom - QO.current.getBoundingClientRect().bottom;
          OO > 0 && (QO.current.scrollTop += Math.min(OO, KO.getBoundingClientRect().top - QO.current.getBoundingClientRect().top))
        }
      }), [FO, zK]);
      const AO = null === (pO = hO.chapters) || void 0 === pO ? void 0 : pO.find((OO => {
        let [KO] = OO;
        return KO === FO
      }));
      return (0, Ve.jsx)(Ml.d, {
        close: vK,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay",
        children: (0, Ve.jsxs)("section", {
          className: "Baf2Panel Baf2QuestBook",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2QuestBookTitle",
          style: tD,
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsx)("h2", {
              id: "baf2QuestBookTitle",
              children: CO(`${Wh}questBookTitle`)
            }), (0, Ve.jsx)(av.i, {
              onClick: vK
            })]
          }), (0, Ve.jsx)("ol", {
            className: "Baf2BookChapters",
            "aria-label": CO(`${Wh}questBookChapters`),
            children: bK.slice(0, DO()).map(((OO, KO) => {
              const pO = KO + 1,
                {
                  kind: XO,
                  short: bK
                } = LO(pO),
                eO = VO(pO, MO),
                lO = eO ? CO(`${Wh}coreAtomicHidden`) : XD(CO, pO);
              return (0, Ve.jsx)("li", {
                children: (0, Ve.jsx)("button", {
                  type: "button",
                  className: Fb()({
                    Stage: "tier" !== XO,
                    Atomic: "atomic" === XO,
                    Current: pO === MO,
                    Selected: pO === FO
                  }),
                  disabled: pO > MO,
                  "aria-pressed": pO === FO,
                  "aria-label": lO,
                  title: eO ? void 0 : lO,
                  onClick: () => {
                    oO({
                      tier: pO,
                      at: MO
                    })
                  },
                  children: eO ? "?" : bK
                })
              }, OO.nameKey)
            }))
          }), (0, Ve.jsxs)("div", {
            ref: QO,
            className: "Baf2BookBody",
            children: [Yb(hO) && FO === MO && (0, Ve.jsx)("p", {
              className: "Baf2BookEmpty",
              children: CO(`${Wh}questBookAllDone`)
            }), (0, Ve.jsx)(VD, {
              view: hO,
              tier: FO,
              quests: null !== (eO = null === AO || void 0 === AO ? void 0 : AO[1]) && void 0 !== eO ? eO : null,
              t: CO
            })]
          })]
        })
      })
    }
    const QD = "buildAFactory2Game:";

    function zM(OO) {
      let {
        tiers: KO,
        from: pO,
        tier: XO,
        shown: bK,
        Kp: eO
      } = OO;
      const {
        t: lO
      } = (0, ze.D)(), vK = KO.map(((OO, KO) => {
        const vK = pO + KO,
          {
            kind: CO,
            short: hO
          } = LO(vK),
          DO = VO(vK, XO);
        return (0, Ve.jsx)("li", {
          children: (0, Ve.jsx)("button", {
            type: "button",
            className: Fb()({
              Stage: "tier" !== CO,
              Silhouette: DO,
              Reached: vK <= XO,
              Current: vK === XO,
              Next: vK === XO + 1,
              Selected: vK === bK
            }),
            disabled: DO,
            "aria-pressed": vK === bK,
            "aria-label": DO ? lO(`${QD}coreAtomicHidden`) : void 0,
            title: DO ? void 0 : lO(`${QD}${OO.nameKey}`),
            onClick: () => {
              eO(vK)
            },
            children: DO ? "?" : hO
          })
        }, OO.nameKey)
      }));
      return (0, Ve.jsx)(Ve.Fragment, {
        children: vK
      })
    }

    function AD(OO) {
      let {
        id: KO,
        label: pO,
        tiers: XO,
        from: bK,
        ...eO
      } = OO;
      return (0, Ve.jsxs)("div", {
        className: "Baf2CoreLadderGroup",
        children: [(0, Ve.jsx)("span", {
          id: KO,
          className: "Baf2CoreLadderLabel",
          children: pO
        }), (0, Ve.jsx)("ol", {
          "aria-labelledby": KO,
          children: (0, Ve.jsx)(zM, {
            ...eO,
            tiers: XO,
            from: bK
          })
        })]
      })
    }

    function fD(OO) {
      const {
        t: KO
      } = (0, ze.D)(), pO = bK.findIndex((OO => void 0 !== OO.stage)), XO = bK.findIndex((OO => void 0 !== OO.reactorTier)), eO = pO < 0 ? bK : bK.slice(0, pO), lO = pO < 0 ? [] : bK.slice(pO, XO < 0 ? void 0 : XO), CO = XO < 0 || !vK() ? [] : bK.slice(XO);
      return (0, Ve.jsxs)("div", {
        className: "Baf2CoreLadder",
        children: [(0, Ve.jsx)(AD, {
          ...OO,
          id: "baf2CoreTiersLabel",
          label: KO(`${QD}coreTiersLabel`),
          tiers: eO,
          from: 1
        }), lO.length > 0 && (0, Ve.jsx)(AD, {
          ...OO,
          id: "baf2CoreStagesLabel",
          label: KO(`${QD}coreStagesLabel`),
          tiers: lO,
          from: pO + 1
        }), CO.length > 0 && (0, Ve.jsx)(AD, {
          ...OO,
          id: "baf2CoreAtomicLabel",
          label: KO(`${QD}coreAtomicLabel`),
          tiers: CO,
          from: XO + 1
        })]
      })
    }
    const dD = "buildAFactory2Game:";

    function TD(OO) {
      let {
        item: KO,
        itemNames: pO,
        children: XO
      } = OO;
      return (0, Ve.jsxs)("span", {
        className: "Baf2CoreRewardItem",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2PanelIcon",
          children: (0, Ve.jsx)(fb.b, {
            itemName: KO,
            amount: 0
          })
        }), (0, Ve.jsx)(db.d, {
          text: pO[KO]
        }), XO]
      })
    }

    function ND(OO) {
      const KO = new Map;
      for (const {
          block: XO
        }
        of OO.newDeposits) {
        var pO;
        KO.set(XO, (null !== (pO = KO.get(XO)) && void 0 !== pO ? pO : 0) + 1)
      }
      return [...KO]
    }

    function ID(OO) {
      let {
        value: KO,
        label: pO,
        more: XO
      } = OO;
      return (0, Ve.jsxs)("li", {
        children: [(0, Ve.jsx)("strong", {
          children: KO
        }), (0, Ve.jsx)("span", {
          children: pO
        }), XO > 0 && (0, Ve.jsxs)("em", {
          children: ["+", XO]
        })]
      })
    }

    function yM(OO) {
      let {
        items: KO,
        itemNames: pO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)(), [eO, lO] = (0, XO.useState)(null), vK = null !== eO && KO.includes(eO) ? eO : null;
      return (0, Ve.jsxs)("div", {
        className: "Baf2CoreRecipes",
        children: [(0, Ve.jsx)("div", {
          className: "Baf2CoreGainLabel",
          children: bK(`${dD}coreRewardUnlocks`)
        }), (0, Ve.jsx)("ul", {
          children: KO.map((OO => (0, Ve.jsx)("li", {
            children: (0, Ve.jsx)("button", {
              type: "button",
              className: Fb()("Baf2PanelIcon", {
                Picked: OO === vK
              }),
              title: xe(bK, OO),
              "aria-label": xe(bK, OO),
              "aria-pressed": OO === vK,
              onClick: () => {
                lO(OO === vK ? null : OO)
              },
              children: (0, Ve.jsx)(fb.b, {
                itemName: OO,
                amount: 0
              })
            })
          }, OO)))
        }), (0, Ve.jsxs)("p", {
          className: "Baf2CoreRecipeName",
          children: [null !== vK && (0, Ve.jsxs)(Ve.Fragment, {
            children: [(0, Ve.jsx)(db.d, {
              text: pO[vK]
            }), " \xb7 ", (0, Ve.jsx)(db.d, {
              text: pO[jK(vK)]
            })]
          }), null === vK && bK(`${dD}coreRecipeTap`)]
        })]
      })
    }

    function gM(OO) {
      var KO, pO;
      let {
        def: XO,
        tier: bK,
        itemNames: eO
      } = OO;
      const {
        t: lO
      } = (0, ze.D)(), vK = bK > 1 ? QO(bK - 1) : void 0, CO = Math.round(2 * XO.islandRadius), hO = vK ? Math.round(2 * vK.islandRadius) : CO, DO = bK >= 3 ? oX(bK) : null;
      return (0, Ve.jsxs)("div", {
        className: "Baf2CoreGains",
        children: [(0, Ve.jsxs)("ul", {
          className: Fb()("Baf2CoreStats", {
            Four: null !== DO
          }),
          children: [(0, Ve.jsx)(ID, {
            value: `${CO}\xd7${CO}`,
            label: lO(`${dD}coreStatIsland`),
            more: CO - hO
          }), (0, Ve.jsx)(ID, {
            value: String(XO.machineAllowance),
            label: lO(`${dD}coreStatMachines`),
            more: XO.machineAllowance - (null !== (KO = null === vK || void 0 === vK ? void 0 : vK.machineAllowance) && void 0 !== KO ? KO : XO.machineAllowance)
          }), (0, Ve.jsx)(ID, {
            value: String(XO.beltAllowance),
            label: lO(`${dD}coreStatBelts`),
            more: XO.beltAllowance - (null !== (pO = null === vK || void 0 === vK ? void 0 : vK.beltAllowance) && void 0 !== pO ? pO : XO.beltAllowance)
          }), null !== DO && (0, Ve.jsx)(ID, {
            value: String(DO),
            label: lO(`${dD}coreStatStorage`),
            more: DO - (vK ? oX(bK - 1) : DO)
          })]
        }), XO.reward && (0, Ve.jsxs)("div", {
          className: "Baf2CoreGainRow",
          children: [(0, Ve.jsx)("div", {
            className: "Baf2CoreGainLabel",
            children: lO(`${dD}coreRewardItem`)
          }), (0, Ve.jsx)(TD, {
            item: XO.reward,
            itemNames: eO
          })]
        }), XO.newDeposits.length > 0 && (0, Ve.jsxs)("div", {
          className: "Baf2CoreGainRow",
          children: [(0, Ve.jsx)("div", {
            className: "Baf2CoreGainLabel",
            children: lO(XO.newDeposits.length > 1 ? `${dD}coreRewardDeposits` : `${dD}coreRewardDeposit`)
          }), ND(XO).map((OO => {
            let [KO, pO] = OO;
            return (0, Ve.jsx)(TD, {
              item: KO,
              itemNames: eO,
              children: pO > 1 && ` \xd7${pO}`
            }, KO)
          }))]
        }), XO.unlocks.length > 0 && (0, Ve.jsx)(yM, {
          items: XO.unlocks,
          itemNames: eO
        }), (0, Ve.jsx)(uD, {
          tier: bK
        })]
      })
    }

    function uD(OO) {
      let {
        tier: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)(), XO = ve[KO];
      if (!XO) return null;
      const bK = lb(KO, 0, 0).barrierMax !== lb(KO - 1, 0, 0).barrierMax;
      return (0, Ve.jsxs)("span", {
        className: "Baf2CoreRewardItem",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2PanelIcon",
          children: (0, Ve.jsx)(fb.b, {
            itemName: bK ? Ob.Chestplate : UX,
            amount: 0
          })
        }), pO(`${dD}gearPerkLine`, {
          perk: pO(`${dD}${XO}`)
        })]
      })
    }

    function ED(OO, KO) {
      return null === OO ? KO : OO.value
    }

    function jM(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : Object.is;
      return null === OO || pO - OO.atMs >= XO ? null : bK(OO.value, KO) ? OO.armed ? null : OO : OO.armed ? OO : {
        ...OO,
        armed: !0
      }
    }

    function YD(OO, KO) {
      const pO = KO.filter((KO => {
        var pO;
        return !1 !== (null === (pO = OO.get(KO)) || void 0 === pO ? void 0 : pO.value)
      }));
      for (const [XO, bK] of OO) bK.value && !KO.includes(XO) && pO.push(XO);
      return pO
    }

    function wD(OO, KO, pO, bK) {
      const [eO, lO] = (0, XO.useState)((() => new Map)), vK = () => {
        lO((KO => function(OO, KO, pO, XO) {
          var bK;
          let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : Object.is,
            lO = null;
          for (const [vK, CO] of OO) {
            const bK = jM(CO, KO(vK), pO, XO, eO);
            bK !== CO && (lO ??= new Map(OO), null === bK ? lO.delete(vK) : lO.set(vK, bK))
          }
          return null !== (bK = lO) && void 0 !== bK ? bK : OO
        }(KO, OO, Date.now(), pO, bK)))
      };
      (0, XO.useEffect)((() => {
        vK()
      }), [KO, pO]), (0, XO.useEffect)((() => {
        if (0 === eO.size) return;
        const OO = Math.min(...[...eO.values()].map((OO => OO.atMs))),
          KO = setTimeout(vK, Math.max(0, OO + pO - Date.now()) + 1);
        return () => {
          clearTimeout(KO)
        }
      }), [eO, KO, pO]);
      return [eO, (KO, pO) => {
        lO((XO => {
          const eO = new Map(XO);
          return eO.set(KO, function(OO, KO, pO) {
            return {
              value: OO,
              atMs: pO,
              armed: !(arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : Object.is)(OO, KO)
            }
          }(pO, OO(KO), Date.now(), bK)), eO
        }))
      }]
    }
    const iM = "buildAFactory2Game:";

    function rM(OO) {
      let {
        message: KO,
        itemNames: pO
      } = OO;
      const bK = Yl(),
        {
          t: eO
        } = (0, ze.D)(),
        [lO, vK] = (0, XO.useState)(!1),
        [CO, hO] = function(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Nl;
          const [pO, XO] = wD((KO => OO.includes(KO)), OO, KO, Object.is);
          return [YD(pO, OO), XO]
        }(KO.baf2CoreBankPaused),
        DO = new Set(CO),
        MO = [...KO.baf2CoreBanked];
      for (const XO of DO) MO.some((OO => {
        let [KO] = OO;
        return KO === XO
      })) || MO.push([XO, 0]);
      return 0 === MO.length ? null : (0, Ve.jsxs)("div", {
        className: "Baf2CoreBank",
        children: [(0, Ve.jsxs)("button", {
          type: "button",
          className: "Baf2CoreBankSummary",
          "aria-expanded": lO,
          onClick: () => {
            vK(!lO)
          },
          children: [(0, Ve.jsx)("span", {
            className: "Baf2CoreBankTitle",
            children: eO(`${iM}coreBankedLater`)
          }), (0, Ve.jsx)("span", {
            className: "Baf2CoreBankIcons",
            children: MO.map((OO => {
              let [KO, pO] = OO;
              const XO = DO.has(KO);
              return (0, Ve.jsxs)("span", {
                className: Fb()({
                  Paused: XO
                }),
                title: XO ? eO(`${iM}coreBankPausedTag`) : void 0,
                children: [(0, Ve.jsx)("span", {
                  className: "Baf2PanelIcon",
                  children: (0, Ve.jsx)(fb.b, {
                    itemName: KO,
                    amount: 0
                  })
                }), pO, XO && (0, Ve.jsx)(Ab.d, {
                  name: "pause"
                })]
              }, KO)
            }))
          }), (0, Ve.jsx)(Ab.d, {
            name: lO ? "angle-up" : "angle-down"
          })]
        }), lO && (0, Ve.jsxs)(Ve.Fragment, {
          children: [(0, Ve.jsx)("ul", {
            children: MO.map((OO => {
              let [KO, XO] = OO;
              const lO = DO.has(KO);
              return (0, Ve.jsxs)("li", {
                children: [(0, Ve.jsxs)(TD, {
                  item: KO,
                  itemNames: pO,
                  children: [(0, Ve.jsx)("span", {
                    className: "Baf2CoreBankAmount",
                    children: XO
                  }), lO && (0, Ve.jsx)("em", {
                    className: "Baf2CoreBankPausedTag",
                    children: eO(`${iM}coreBankPausedTag`)
                  })]
                }), (0, Ve.jsxs)("span", {
                  className: "Baf2CoreBankActions",
                  children: [(0, Ve.jsx)("button", {
                    type: "button",
                    className: "Baf2CoreBankButton",
                    disabled: 0 === XO,
                    onClick: () => {
                      bK.send(`baf2corewithdraw ${XO} ${KO}`)
                    },
                    children: eO(`${iM}coreTake`)
                  }), (0, Ve.jsx)("button", {
                    type: "button",
                    className: "Baf2CoreBankButton Secondary",
                    onClick: () => {
                      bK.send(`${fO} ${KO}`), hO(KO, !lO)
                    },
                    children: eO(lO ? `${iM}coreBankResume` : `${iM}coreBankStop`)
                  })]
                })]
              }, KO)
            }))
          }), (0, Ve.jsx)("p", {
            className: "Baf2CoreHint",
            children: eO(`${iM}coreBankNote`)
          })]
        })]
      })
    }
    const PD = "buildAFactory2Game:";

    function mM(OO) {
      const KO = Math.max(0, Math.floor(OO));
      return `${Math.floor(KO/60)}:${String(KO%60).padStart(2,"0")}`
    }

    function sD(OO) {
      let {
        item: KO
      } = OO;
      return (0, Ve.jsx)("div", {
        className: "Baf2PanelIcon",
        children: (0, Ve.jsx)(fb.b, {
          itemName: KO,
          amount: 0
        })
      })
    }

    function HD() {
      return (0, Ve.jsx)("div", {
        className: "Baf2PanelIcon Baf2CoreChargeBolt",
        children: (0, Ve.jsx)(Ab.d, {
          name: "bolt"
        })
      })
    }

    function RD(OO) {
      let {
        charge: KO,
        hint: pO,
        itemNames: XO
      } = OO;
      const bK = Yl(),
        {
          t: eO
        } = (0, ze.D)(),
        [lO, vK, CO, hO, DO, MO, aK] = KO,
        [oO, FO] = function(OO) {
          var KO;
          let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Nl,
            XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Object.is;
          const [bK, eO] = wD((() => OO), OO, pO, XO);
          return [ED(null !== (KO = bK.get("")) && void 0 !== KO ? KO : null, OO), OO => {
            eO("", OO)
          }]
        }(aK),
        VO = oO === aK ? MO : !oO,
        LO = hO >= DO,
        QO = lO.find((OO => {
          let [, KO, pO] = OO;
          return pO < .9 * KO
        }));
      let zK = `${PD}coreChargeWaiting`,
        AO = {};
      return LO ? zK = `${PD}coreChargeDone` : oO ? zK = `${PD}coreChargeStopped` : VO && pO ? (zK = `${PD}${pO[0]}`, AO = {
        item: xe(eO, pO[1])
      }) : VO && QO ? (zK = `${PD}coreChargeShort`, AO = {
        item: xe(eO, QO[0])
      }) : VO && vK > 0 && !CO ? zK = `${PD}coreChargePower` : VO && (zK = `${PD}coreChargeRunning`), (0, Ve.jsxs)("div", {
        className: Fb()("Baf2CoreCharge", {
          Waiting: !VO && !LO,
          Done: LO
        }),
        children: [(0, Ve.jsxs)("h4", {
          children: [eO(`${PD}coreChargeTitle`), (0, Ve.jsx)("span", {
            children: eO(`${PD}coreChargeProgress`, {
              done: mM(hO),
              need: mM(DO)
            })
          })]
        }), (0, Ve.jsx)("div", {
          className: "Baf2CoreChargeProgress",
          children: (0, Ve.jsx)("div", {
            style: {
              width: 100 * Math.min(hO, DO) / DO + "%"
            }
          })
        }), (0, Ve.jsxs)("ul", {
          className: "Baf2CoreNeeds",
          children: [lO.map((OO => {
            var KO;
            let [pO, bK, lO] = OO;
            const vK = lO >= .9 * bK;
            return (0, Ve.jsxs)("li", {
              className: Fb()({
                Done: vK,
                Short: VO && !vK
              }),
              children: [(0, Ve.jsx)(sD, {
                item: pO
              }), (0, Ve.jsxs)("div", {
                className: "Baf2CoreNeedText",
                children: [(0, Ve.jsxs)("div", {
                  className: "Baf2CoreNeedName",
                  children: [(0, Ve.jsx)(db.d, {
                    text: null !== (KO = XO[pO]) && void 0 !== KO ? KO : pO
                  }), (0, Ve.jsx)("span", {
                    children: eO(`${PD}coreChargeItem`, {
                      now: String(lO),
                      need: String(bK)
                    })
                  })]
                }), (0, Ve.jsx)("div", {
                  className: "Baf2CoreBar",
                  children: (0, Ve.jsx)("div", {
                    style: {
                      width: `${Math.min(100,100*lO/bK)}%`
                    }
                  })
                })]
              })]
            }, pO)
          })), vK > 0 && (0, Ve.jsxs)("li", {
            className: Fb()("Baf2CoreChargePower", {
              Short: VO && !CO
            }),
            children: [(0, Ve.jsx)(HD, {}), (0, Ve.jsx)("div", {
              className: "Baf2CoreNeedText",
              children: (0, Ve.jsx)("div", {
                className: "Baf2CoreNeedName",
                children: (0, Ve.jsx)("span", {
                  children: eO(`${PD}coreChargePowerRow`, {
                    power: tK(vK)
                  })
                })
              })
            })]
          })]
        }), (0, Ve.jsx)("p", {
          className: "Baf2CoreHint",
          children: eO(zK, AO)
        }), !LO && (VO || oO) && (0, Ve.jsx)("button", {
          type: "button",
          className: Fb()("Baf2CoreChargeToggle", {
            Stopped: oO
          }),
          onClick: () => {
            bK.send(TO), FO(!oO)
          },
          children: eO(oO ? `${PD}coreChargeRestart` : `${PD}coreChargeStop`)
        })]
      })
    }

    function SD(OO) {
      let {
        charge: KO,
        reached: pO,
        itemNames: XO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)();
      return (0, Ve.jsxs)("div", {
        className: Fb()("Baf2CoreCharge", {
          Done: pO
        }),
        children: [(0, Ve.jsxs)("h4", {
          children: [bK(`${PD}coreChargeTitle`), (0, Ve.jsx)("span", {
            children: bK(`${PD}coreChargeSpecTime`, {
              time: mM(KO.seconds)
            })
          })]
        }), (0, Ve.jsxs)("ul", {
          className: "Baf2CoreNeeds",
          children: [KO.items.map((OO => {
            var KO;
            let {
              item: eO,
              amount: lO
            } = OO;
            return (0, Ve.jsxs)("li", {
              className: Fb()({
                Done: pO
              }),
              children: [(0, Ve.jsx)(sD, {
                item: eO
              }), (0, Ve.jsx)("div", {
                className: "Baf2CoreNeedText",
                children: (0, Ve.jsxs)("div", {
                  className: "Baf2CoreNeedName",
                  children: [(0, Ve.jsx)(db.d, {
                    text: null !== (KO = XO[eO]) && void 0 !== KO ? KO : eO
                  }), (0, Ve.jsx)("span", {
                    children: bK(`${PD}coreChargeSpecItem`, {
                      need: String(lO)
                    })
                  })]
                })
              })]
            }, eO)
          })), KO.powerPerS > 0 && (0, Ve.jsxs)("li", {
            className: "Baf2CoreChargePower",
            children: [(0, Ve.jsx)(HD, {}), (0, Ve.jsx)("div", {
              className: "Baf2CoreNeedText",
              children: (0, Ve.jsx)("div", {
                className: "Baf2CoreNeedName",
                children: (0, Ve.jsx)("span", {
                  children: bK(`${PD}coreChargePowerRow`, {
                    power: tK(KO.powerPerS)
                  })
                })
              })
            })]
          })]
        })]
      })
    }
    const JD = "buildAFactory2Game:";

    function cM(OO) {
      let {
        def: KO,
        reached: pO,
        banked: XO,
        itemNames: bK
      } = OO;
      const {
        t: eO
      } = (0, ze.D)();
      return (0, Ve.jsx)("ul", {
        className: "Baf2CoreCost",
        children: KO.cost.map((OO => {
          let {
            item: KO,
            amount: lO
          } = OO;
          const vK = pO ? 0 : XO(KO);
          return (0, Ve.jsx)("li", {
            children: (0, Ve.jsx)(TD, {
              item: KO,
              itemNames: bK,
              children: (0, Ve.jsx)("span", {
                className: "Baf2CoreCostAmount",
                children: vK > 0 ? eO(`${JD}coreBankedFor`, {
                  amount: String(vK),
                  total: String(lO)
                }) : `\xd7${lO}`
              })
            })
          }, KO)
        }))
      })
    }

    function BD(OO, KO) {
      if (KO >= DO()) return OO(`${JD}coreMaxTier`);
      const pO = hO[KO + 1];
      return pO && !pO.startsWith("upgradeCore") ? OO(`${JD}coreGateQuest`, {
        quest: OO(`${JD}quest_${pO}`)
      }) : OO(`${JD}coreGateClosed`)
    }

    function ZD() {
      const {
        t: OO
      } = (0, ze.D)(), KO = Yl(), pO = (0, XO.useRef)(null), bK = (0, XO.useRef)(Date.now());
      return sh(!0, pO), (0, Ve.jsx)("div", {
        ref: pO,
        className: "Baf2CoreGrow",
        children: (0, Ve.jsx)(av.m, {
          className: "Baf2CoreGrowButton",
          onClick: () => {
            Date.now() - bK.current >= 600 && KO.send(AO)
          },
          children: OO(`${JD}coreGrow`)
        })
      })
    }

    function GD(OO) {
      let {
        message: KO,
        itemNames: pO,
        next: XO
      } = OO;
      const bK = Yl(),
        {
          t: eO
        } = (0, ze.D)(),
        lO = KO.baf2CoreTier,
        vK = KO.baf2CoreReady,
        CO = KO.baf2CoreNeeds.filter((OO => {
          let [, KO, pO, XO] = OO;
          return XO > 0 && KO < pO
        })),
        hO = KO.baf2CoreNeeds.every((OO => {
          let [, KO, pO] = OO;
          return KO >= pO
        })),
        DO = KO.baf2CoreKeep;
      return (0, Ve.jsxs)("div", {
        className: "Baf2CoreBody",
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2CoreColumn",
          children: [vK && (0, Ve.jsx)(ZD, {}), (0, Ve.jsx)("h3", {
            children: eO(`${JD}coreBring`)
          }), (0, Ve.jsx)("ul", {
            className: "Baf2CoreNeeds",
            children: KO.baf2CoreNeeds.map((OO => {
              let [KO, XO, lO, vK] = OO;
              return (0, Ve.jsxs)("li", {
                className: Fb()({
                  Done: XO >= lO
                }),
                children: [(0, Ve.jsx)("div", {
                  className: "Baf2PanelIcon",
                  children: (0, Ve.jsx)(fb.b, {
                    itemName: KO,
                    amount: 0
                  })
                }), (0, Ve.jsxs)("div", {
                  className: "Baf2CoreNeedText",
                  children: [(0, Ve.jsxs)("div", {
                    className: "Baf2CoreNeedName",
                    children: [(0, Ve.jsx)(db.d, {
                      text: pO[KO]
                    }), (0, Ve.jsxs)("span", {
                      children: [XO, "/", lO]
                    })]
                  }), (0, Ve.jsxs)("div", {
                    className: "Baf2CoreBar",
                    children: [(0, Ve.jsx)("div", {
                      style: {
                        width: 100 * XO / lO + "%"
                      }
                    }), vK > 0 && (0, Ve.jsx)("div", {
                      className: "Baf2CoreBarHeld",
                      style: {
                        width: 100 * vK / lO + "%"
                      }
                    })]
                  })]
                }), vK > 0 && XO < lO && (0, Ve.jsx)("button", {
                  type: "button",
                  className: "Baf2CoreDepositButton",
                  onClick: () => {
                    bK.send(`${dO} ${KO}`)
                  },
                  children: eO(`${JD}coreDeposit`, {
                    amount: String(vK)
                  })
                })]
              }, KO)
            }))
          }), KO.baf2CoreCharge && (0, Ve.jsx)(RD, {
            charge: KO.baf2CoreCharge,
            hint: KO.baf2CoreChargeHint,
            itemNames: pO
          }), !vK && CO.length > 1 && (0, Ve.jsx)(av.m, {
            className: "Baf2CoreHandOver",
            onClick: () => {
              bK.send(AO)
            },
            children: eO(`${JD}coreHandOver`)
          }), !vK && void 0 !== DO && (0, Ve.jsx)("p", {
            className: "Baf2CoreHint",
            children: eO(`${JD}coreKeepRest`, {
              item: xe(eO, DO)
            })
          }), !vK && !hO && 0 === CO.length && void 0 === DO && (0, Ve.jsx)("p", {
            className: "Baf2CoreHint",
            children: eO(`${JD}coreNothingHeld`)
          }), (0, Ve.jsx)(rM, {
            message: KO,
            itemNames: pO
          })]
        }), (0, Ve.jsxs)("div", {
          className: "Baf2CoreColumn",
          children: [(0, Ve.jsx)("h3", {
            children: eO(`${JD}coreRewards`)
          }), (0, Ve.jsx)(gM, {
            def: XO,
            tier: lO + 1,
            itemNames: pO
          })]
        })]
      })
    }

    function qM(OO) {
      let {
        message: KO,
        itemNames: pO,
        shown: XO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)(), eO = KO.baf2CoreTier, lO = QO(XO), vK = XO <= eO, CO = new Map(KO.baf2CoreBanked), hO = !zK(eO, NO(KO)) && XO === eO;
      return (0, Ve.jsxs)("div", {
        className: Fb()("Baf2CoreBody", {
          Locked: !vK
        }),
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2CoreColumn",
          children: [(0, Ve.jsx)("h3", {
            children: bK(vK ? `${JD}coreItTook` : `${JD}coreItNeeds`)
          }), 0 === lO.cost.length && (0, Ve.jsx)("p", {
            className: "Baf2CoreHint",
            children: bK(`${JD}coreTierStart`)
          }), lO.cost.length > 0 && (0, Ve.jsx)(cM, {
            def: lO,
            reached: vK,
            banked: OO => {
              var KO;
              return function(OO, KO, pO, XO) {
                let bK = OO;
                for (let lO = KO + 2; lO <= pO; lO++) {
                  var eO;
                  const OO = QO(lO).cost.find((OO => OO.item === XO)),
                    KO = Math.min(bK, null !== (eO = null === OO || void 0 === OO ? void 0 : OO.amount) && void 0 !== eO ? eO : 0);
                  if (lO === pO) return KO;
                  bK -= KO
                }
                return 0
              }(null !== (KO = CO.get(OO)) && void 0 !== KO ? KO : 0, eO, XO, OO)
            },
            itemNames: pO
          }), lO.charge && (0, Ve.jsx)(SD, {
            charge: lO.charge,
            reached: vK,
            itemNames: pO
          }), hO && (0, Ve.jsxs)(Ve.Fragment, {
            children: [(0, Ve.jsx)("p", {
              className: "Baf2CoreHint",
              children: BD(bK, eO)
            }), (0, Ve.jsx)(rM, {
              message: KO,
              itemNames: pO
            })]
          })]
        }), (0, Ve.jsxs)("div", {
          className: "Baf2CoreColumn",
          children: [(0, Ve.jsx)("h3", {
            children: bK(vK ? `${JD}coreGave` : `${JD}coreLockedRewards`)
          }), (0, Ve.jsx)(gM, {
            def: lO,
            tier: XO,
            itemNames: pO
          })]
        })]
      })
    }

    function xM(OO, KO) {
      const {
        key: pO,
        params: XO
      } = oO(KO - 1, {
        tier: "coreLockedHint",
        stage: "coreLockedStageHint",
        atomic: "coreLockedAtomicHint"
      });
      return OO(`${JD}${pO}`, XO)
    }
    const nD = "buildAFactory2Game:",
      WD = {
        coreTierReached: "coreStageReached",
        coreTierNext: "coreStageNext",
        coreTierLocked: "coreStageLocked"
      },
      tM = {
        coreTierReached: "coreAtomicReached",
        coreTierNext: "coreAtomicNext",
        coreTierLocked: "coreAtomicLocked"
      };

    function kM(OO) {
      let {
        view: KO,
        close: pO,
        askIslands: bK
      } = OO;
      const {
        t: eO
      } = (0, ze.D)(), [lO, vK] = (0, XO.useState)(!1);
      (0, XO.useEffect)((() => {
        if (!lO) return;
        const OO = window.setTimeout((() => {
          vK(!1)
        }), 5e3);
        return () => {
          window.clearTimeout(OO)
        }
      }), [lO]);
      const {
        message: CO,
        itemNames: hO
      } = KO, DO = CO.baf2CoreTier, MO = QO(DO), aK = zK(DO, NO(CO)), [VO, LO] = CO.baf2CoreMachines, [AO, fO] = CO.baf2CoreBelts, dO = CO.baf2CoreStorage, TO = CO.baf2CoreReady, [IO, yK] = (0, XO.useState)(null), gK = (null === IO || void 0 === IO ? void 0 : IO.at) === DO && IO.ready === TO ? IO.tier : aK ? DO + 1 : DO;
      let uO = "coreTierLocked";
      gK <= DO ? uO = "coreTierReached" : gK === DO + 1 && (uO = "coreTierNext");
      const EO = eO(`${nD}${QO(gK).nameKey}`),
        jK = gK === DO + 1 ? aK : null,
        YO = oO(gK, {
          tier: uO,
          stage: WD[uO],
          atomic: tM[uO]
        }),
        wO = eO(`${nD}${YO.key}`, {
          ...YO.params,
          name: EO
        }),
        iK = oO(DO, FO),
        rK = eO(`${nD}${iK.key}`, {
          ...iK.params,
          name: eO(`${nD}${MO.nameKey}`)
        });
      return (0, Ve.jsx)(Ml.d, {
        close: pO,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay Baf2CoreOverlay",
        children: (0, Ve.jsxs)("section", {
          className: "Baf2Panel Baf2CorePanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2CoreTitle",
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsxs)("div", {
              children: [(0, Ve.jsx)("h2", {
                id: "baf2CoreTitle",
                children: eO(`${nD}coreTitle`)
              }), void 0 !== CO.baf2CoreIslandName && (0, Ve.jsx)("p", {
                className: "Baf2CoreIsland",
                children: CO.baf2CoreIslandName
              }), (0, Ve.jsxs)("p", {
                className: "Baf2CoreStatus",
                children: [(0, Ve.jsx)("span", {
                  children: rK
                }), (0, Ve.jsx)("span", {
                  className: Fb()({
                    Full: VO >= LO
                  }),
                  children: eO(`${nD}coreMachineCount`, {
                    amount: String(VO),
                    total: String(LO)
                  })
                }), (0, Ve.jsx)("span", {
                  className: Fb()({
                    Full: AO >= fO
                  }),
                  children: eO(`${nD}coreBeltCount`, {
                    amount: String(AO),
                    total: String(fO)
                  })
                }), void 0 !== dO && (0, Ve.jsx)("span", {
                  className: Fb()({
                    Full: dO[0] >= dO[1]
                  }),
                  children: eO(`${nD}coreStorageCount`, {
                    amount: String(dO[0]),
                    total: String(dO[1])
                  })
                })]
              })]
            }), (0, Ve.jsxs)("div", {
              className: "Baf2CoreHeaderActions",
              children: [CO.baf2CoreIslands && (0, Ve.jsx)(av.d, {
                className: "Baf2CoreIslandsButton",
                disabled: lO,
                onClick: () => {
                  vK(!0), bK()
                },
                children: eO(`${nD}islandsOpenButton`)
              }), (0, Ve.jsx)(av.i, {
                onClick: pO
              })]
            })]
          }), (0, Ve.jsx)(fD, {
            tier: DO,
            shown: gK,
            Kp: OO => {
              yK({
                tier: OO,
                at: DO,
                ready: TO
              })
            }
          }), (0, Ve.jsxs)("p", {
            className: "Baf2CoreLadderCaption",
            children: [wO, gK > DO + 1 && (0, Ve.jsx)("span", {
              className: "Baf2CoreLockedHint",
              children: xM(eO, gK)
            })]
          }), 6 === gK && gK > DO && (0, Ve.jsx)("p", {
            className: "Baf2CoreLadderCaption Baf2CoreStagesNote",
            children: eO(`${nD}coreStagesNote`)
          }), 11 === gK && gK > DO && (0, Ve.jsx)("p", {
            className: "Baf2CoreLadderCaption Baf2CoreStagesNote",
            children: eO(`${nD}coreAtomicNote`)
          }), jK && (0, Ve.jsx)(GD, {
            message: CO,
            itemNames: hO,
            next: jK
          }), !jK && (0, Ve.jsx)(qM, {
            message: CO,
            itemNames: hO,
            shown: gK
          })]
        })
      })
    }
    const UD = {
      stepDropToRuin: "ruin",
      stepDropToOldWorks: "works",
      stepCometDrop: "comet",
      stepIsotopeAfterComet: "comet",
      stepCometOwedReady: "owed",
      stepIsotopeReady: "owed",
      stepIsotopeAgain: "owed",
      stepIsotopeAgainHome: "owed",
      stepCometThenDig: "owed",
      stepDropToDig: "dig"
    };
    const OM = [{
      item: "Machine Parts",
      nameKey: "item:machineParts",
      useKey: "buildAFactory2Game:dropSalvageParts"
    }, {
      item: ke,
      nameKey: "item:relayCoil",
      useKey: "buildAFactory2Game:dropSalvageCoil",
      params: {
        amount: String(2)
      }
    }, {
      item: "Deposit Seed (Copper)",
      nameKey: "buildAFactory2Game:dropSalvageSeedName",
      useKey: "buildAFactory2Game:dropSalvageSeed"
    }];

    function KM(OO) {
      return OO.baf2DropCometOreOnly ? "dropCometOre" : OO.baf2DropCometIsotope ? "seed" === OO.baf2DropCometIsotope ? "dropCometIsotopeSeed" : "dropCometIsotope" : "dropCometDistance"
    }

    function pM(OO) {
      let {
        message: KO,
        quests: pO,
        close: bK,
        DX: eO
      } = OO;
      const lO = Yl(),
        {
          t: vK
        } = (0, ze.D)(),
        CO = (0, Gh.h)(ge, pO.get()),
        hO = function(OO) {
          var KO;
          if (!iK(OO.tutorial)) return null;
          const pO = OO.rows.find((OO => OO.current)),
            XO = pO ? UD[pO.key] : void 0;
          return null !== (KO = null !== XO && void 0 !== XO ? XO : OO.side ? UD[OO.side.row.key] : void 0) && void 0 !== KO ? KO : null
        }(CO),
        DO = null === CO.tier || Ke(CO.tier),
        MO = DO ? OM : OM.filter((OO => {
          let {
            item: KO
          } = OO;
          return KO !== ke
        })),
        [aK, oO] = (0, XO.useState)(null),
        FO = null !== aK && void 0 !== aK ? aK : !KO.baf2DropFoundSalvage && DO,
        VO = KO.baf2DropRuinDistance,
        LO = KO.baf2DropComet,
        QO = KO.baf2DropOldWorks,
        zK = KO.baf2DropGrove,
        AO = function(OO) {
          return 2 + Number(void 0 !== OO.baf2DropComet) + Number(!!OO.baf2DropOwedComet || void 0 !== OO.baf2DropOwedWaitMinutes) + Number(void 0 !== OO.baf2DropDigDistance) + Number(void 0 !== OO.baf2DropOldWorks) + Number(void 0 !== OO.baf2DropGrove)
        }(KO),
        fO = OO => {
          lO.send(function(OO) {
            return `baf2drop ${OO}`
          }(OO)), eO()
        };
      let dO = vK("buildAFactory2Game:dropRuinNone");
      if (null !== VO) {
        let OO = KO.baf2DropRuinUnderground ? "dropRuinUnderground" : "dropRuinSurface";
        KO.baf2DropRuinOldWorks && (OO = "dropRuinOldWorks");
        const pO = void 0 === KO.baf2DropRuinCluster ? vK("buildAFactory2Game:dropRuinOpen") : vK("buildAFactory2Game:dropRuinCluster", {
          count: String(KO.baf2DropRuinCluster)
        });
        dO = `${vK(`buildAFactory2Game:${OO}`,{distance:String(VO)})} ${pO}`
      }
      let TO = vK("buildAFactory2Game:dropBelowDescription");
      void 0 !== KO.baf2DropBelowLook && (TO = vK("buildAFactory2Game:dropBelowLook", {
        look: vK(KO.baf2DropBelowLook)
      }));
      const NO = "buildAFactory2Game:wildsRegion_survivorGrove" === KO.baf2DropBelowLook ? "dropGroveMiddle" : "dropGroveDescription",
        IO = Me(vK, 60 * function(OO) {
          const [KO, pO] = (0, XO.useState)((() => Date.now())), [bK, eO] = (0, XO.useState)(KO);
          return (0, XO.useEffect)((() => {
            const OO = Date.now();
            pO(OO), eO(OO)
          }), [OO]), (0, XO.useEffect)((() => {
            const OO = window.setInterval((() => {
              eO(Date.now())
            }), 1e4);
            return () => {
              window.clearInterval(OO)
            }
          }), []), Math.max(1, OO.baf2DropRenewMinutes - Math.floor((bK - KO) / 6e4))
        }(KO)),
        yK = function(OO, KO, pO) {
          return "ruin" === OO && !pO || "owed" === OO && !KO.baf2DropOwedComet ? null : OO
        }(hO, KO, null !== VO),
        gK = function(OO) {
          for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
          return Fb()("Baf2DropTile", ...pO, {
            Wanted: yK === OO
          })
        };
      return (0, Ve.jsx)(Ml.d, {
        close: bK,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay",
        children: (0, Ve.jsxs)("section", {
          className: Fb()("Baf2Panel Baf2DropMap", {
            Many: AO >= 5
          }),
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2DropMapTitle",
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsxs)("div", {
              children: [(0, Ve.jsx)("h2", {
                id: "baf2DropMapTitle",
                children: vK("buildAFactory2Game:dropMapTitle")
              }), (0, Ve.jsx)("p", {
                children: vK("buildAFactory2Game:dropMapSubtitle")
              })]
            }), (0, Ve.jsx)(av.i, {
              onClick: bK
            })]
          }), (0, Ve.jsxs)("div", {
            className: "Baf2DropTiles",
            children: [void 0 !== LO && (0, Ve.jsxs)(av.y, {
              className: gK("comet", "Baf2DropComet"),
              onClick: () => {
                fO("comet")
              },
              children: [(0, Ve.jsx)("strong", {
                children: vK("buildAFactory2Game:dropComet")
              }), (0, Ve.jsx)("span", {
                children: vK(`buildAFactory2Game:${KM(KO)}`, {
                  distance: String(LO)
                })
              })]
            }), KO.baf2DropOwedComet && (0, Ve.jsxs)(av.y, {
              className: gK("owed", "Baf2DropComet"),
              onClick: () => {
                fO("owed")
              },
              children: [(0, Ve.jsx)("strong", {
                children: vK("buildAFactory2Game:dropOwedComet")
              }), (0, Ve.jsx)("span", {
                children: KO.baf2DropOwedIsotope ? vK("buildAFactory2Game:dropOwedIsotopeDescription") : vK("buildAFactory2Game:dropOwedCometDescription")
              })]
            }), void 0 !== KO.baf2DropOwedWaitMinutes && (0, Ve.jsxs)(av.y, {
              className: gK("owed", "Baf2DropComet"),
              disabled: !0,
              onClick: () => {},
              children: [(0, Ve.jsx)("strong", {
                children: vK("buildAFactory2Game:dropOwedComet")
              }), (0, Ve.jsx)("span", {
                children: vK("buildAFactory2Game:dropOwedCometWait", {
                  minutes: String(KO.baf2DropOwedWaitMinutes)
                })
              })]
            }), (0, Ve.jsxs)(av.d, {
              className: gK("below"),
              onClick: () => {
                fO("below")
              },
              children: [(0, Ve.jsx)("strong", {
                children: vK("buildAFactory2Game:dropBelow")
              }), (0, Ve.jsx)("span", {
                children: TO
              })]
            }), void 0 !== KO.baf2DropDigDistance && (0, Ve.jsxs)(av.s, {
              className: gK("dig"),
              onClick: () => {
                fO("dig")
              },
              children: [(0, Ve.jsx)("strong", {
                children: vK("buildAFactory2Game:dropDig")
              }), (0, Ve.jsx)("span", {
                children: vK("buildAFactory2Game:dropDigDescription", {
                  distance: String(KO.baf2DropDigDistance),
                  y: De(KO.baf2DropDigY)
                })
              })]
            }), void 0 !== zK && (0, Ve.jsxs)(av.s, {
              className: gK("grove", "Baf2DropGrove"),
              onClick: () => {
                fO("grove")
              },
              children: [(0, Ve.jsx)("strong", {
                children: vK("buildAFactory2Game:dropGrove")
              }), (0, Ve.jsx)("span", {
                children: vK(`buildAFactory2Game:${NO}`, {
                  distance: String(zK)
                })
              })]
            }), (0, Ve.jsxs)(av.m, {
              className: gK("ruin"),
              disabled: null === VO,
              onClick: () => {
                fO("ruin")
              },
              children: [(0, Ve.jsx)("strong", {
                children: vK("buildAFactory2Game:dropRuin")
              }), (0, Ve.jsx)("span", {
                children: dO
              })]
            }), void 0 !== QO && (0, Ve.jsxs)(av.I, {
              className: gK("works"),
              onClick: () => {
                fO("works")
              },
              children: [(0, Ve.jsx)("strong", {
                children: vK("buildAFactory2Game:dropOldWorks")
              }), (0, Ve.jsx)("span", {
                children: vK("buildAFactory2Game:dropOldWorksDescription", {
                  distance: String(QO)
                })
              })]
            })]
          }), (0, Ve.jsx)("p", {
            className: "Baf2DropRenew",
            children: vK("buildAFactory2Game:dropRenew", {
              time: IO
            })
          }), (0, Ve.jsxs)("details", {
            className: "Baf2DropSalvage",
            open: FO,
            onToggle: OO => {
              OO.currentTarget.open !== FO && oO(OO.currentTarget.open)
            },
            children: [(0, Ve.jsx)("summary", {
              children: vK("buildAFactory2Game:dropSalvageWhat")
            }), (0, Ve.jsx)("p", {
              children: vK("buildAFactory2Game:dropSalvageIntro")
            }), (0, Ve.jsx)("ul", {
              children: MO.map((OO => {
                let {
                  item: KO,
                  nameKey: pO,
                  useKey: XO,
                  params: bK
                } = OO;
                return (0, Ve.jsxs)("li", {
                  children: [(0, Ve.jsx)("span", {
                    className: "Baf2PanelIcon",
                    children: (0, Ve.jsx)(fb.b, {
                      itemName: KO,
                      amount: 0
                    })
                  }), (0, Ve.jsxs)("span", {
                    children: [(0, Ve.jsx)("strong", {
                      children: vK(pO)
                    }), ": ", vK(XO, bK)]
                  })]
                }, KO)
              }))
            })]
          })]
        })
      })
    }
    const XM = "buildAFactory2Game:";

    function ba(OO, KO) {
      return OO.sendIslandEdit(`baf2coopleave ${KO.baf2IslandId}`)
    }

    function eM(OO) {
      let {
        card: KO,
        canRename: pO,
        done: bK,
        t: eO
      } = OO;
      const lO = Yl(),
        [vK, CO] = (0, XO.useState)(KO.baf2IslandName),
        hO = Mh(vK),
        DO = "" === hO || aD(hO),
        MO = () => {
          !DO && pO && (hO !== KO.baf2IslandName ? bK(lO.sendIslandEdit(`baf2islandrename ${KO.baf2IslandId} ${hO}`)) : bK(null))
        },
        aK = () => {
          bK(null)
        };
      return (0, Ve.jsxs)("div", {
        className: "Baf2IslandForm",
        ...Ph(aK),
        children: [(0, Ve.jsxs)("label", {
          className: "Baf2IslandFormLabel",
          children: [eO(`${XM}islandsRenameLabel`), (0, Ve.jsx)("input", {
            type: "text",
            className: "Baf2IslandInput",
            value: vK,
            maxLength: 24,
            autoComplete: "off",
            spellCheck: !1,
            enterKeyHint: "done",
            autoFocus: !0,
            onFocus: mD,
            onChange: OO => {
              CO(OO.target.value)
            },
            ...rD(MO, aK)
          })]
        }), "" === hO && (0, Ve.jsx)("p", {
          className: "Baf2IslandFormNote",
          children: eO(`${XM}islandsRenameEmpty`)
        }), aD(hO) && (0, Ve.jsx)("p", {
          className: "Baf2IslandFormNote",
          children: eO(`${XM}islandsNameReserved`)
        }), (0, Ve.jsxs)("div", {
          className: "Baf2IslandButtons",
          children: [(0, Ve.jsx)(av.s, {
            disabled: DO || !pO,
            onClick: MO,
            children: eO(`${XM}islandsRenameSave`)
          }), (0, Ve.jsx)(av.d, {
            onClick: aK,
            children: eO(`${XM}islandsCancel`)
          })]
        })]
      })
    }

    function lM(OO) {
      let {
        card: KO,
        canDelete: pO,
        done: bK,
        t: eO
      } = OO;
      const lO = Yl(),
        [vK, CO] = (0, XO.useState)(""),
        hO = function(OO, KO) {
          return Mh(OO).toLowerCase() === Mh(KO).toLowerCase()
        }(vK, KO.baf2IslandName),
        DO = () => {
          hO && pO && bK(lO.sendIslandEdit(`baf2islanddelete ${KO.baf2IslandId}`))
        },
        MO = () => {
          bK(null)
        },
        aK = Nh("name"),
        [oO, FO = ""] = eO(`${XM}islandsDeleteConfirm`, {
          name: aK
        }).split(aK);
      return (0, Ve.jsxs)("div", {
        className: "Baf2IslandForm Delete",
        ...Ph(MO),
        children: [(0, Ve.jsxs)("label", {
          className: "Baf2IslandFormLabel",
          children: [(0, Ve.jsxs)("span", {
            children: [oO, (0, Ve.jsx)("strong", {
              children: KO.baf2IslandName
            }), FO]
          }), (0, Ve.jsx)("input", {
            type: "text",
            className: "Baf2IslandInput",
            value: vK,
            maxLength: 24,
            autoComplete: "off",
            spellCheck: !1,
            enterKeyHint: "done",
            autoFocus: !0,
            onFocus: mD,
            onChange: OO => {
              CO(OO.target.value)
            },
            ...rD(DO, MO)
          })]
        }), jD(KO) && (0, Ve.jsx)("p", {
          className: "Baf2IslandFormNote Quiet",
          children: eO(`${XM}islandsDeleteLeftBack`)
        }), (0, Ve.jsxs)("div", {
          className: "Baf2IslandButtons",
          children: [(0, Ve.jsx)(av.I, {
            disabled: !hO || !pO,
            onClick: DO,
            children: eO(`${XM}islandsDeleteForGood`)
          }), (0, Ve.jsx)(av.d, {
            onClick: MO,
            children: eO(`${XM}islandsCancel`)
          })]
        })]
      })
    }

    function va(OO) {
      let {
        members: KO,
        t: pO
      } = OO;
      const XO = KO.length;
      return (0, Ve.jsxs)("p", {
        className: "Baf2IslandMembers",
        children: [(0, Ve.jsxs)("span", {
          children: [1 === XO ? pO(`${XM}islandsPlayersOne`) : pO(`${XM}islandsPlayers`, {
            count: String(XO)
          }), " "]
        }), KO.map(((OO, KO) => (0, Ve.jsxs)("span", {
          className: Fb()("Baf2IslandMember", {
            Here: OO.baf2MemberHere
          }),
          title: OO.baf2MemberHere ? pO(`${XM}islandsPlayerHere`) : void 0,
          children: [OO.baf2MemberName, KO < XO - 1 ? ", " : ""]
        }, OO.baf2MemberKey)))]
      })
    }

    function CM(OO) {
      let {
        card: KO,
        answered: pO,
        nowMs: bK,
        t: eO
      } = OO;
      const lO = Yl(),
        [vK, CO] = (0, XO.useState)(new Map),
        hO = jD(KO);
      if (!hO) return null;
      return (0, Ve.jsxs)("div", {
        className: "Baf2IslandLeft",
        children: [(0, Ve.jsx)("p", {
          className: "Baf2IslandFormTitle",
          children: eO(`${XM}islandsLeftTitle`)
        }), (0, Ve.jsx)("ul", {
          className: "Baf2IslandPeopleList",
          children: hO.left.map((OO => {
            const XO = OO.baf2LeftKey,
              DO = wh(vK.get(XO), pO, bK),
              MO = function(OO) {
                return 1 === OO ? [`${vD}islandsLeftItemsOne`] : [`${vD}islandsLeftItems`, {
                  count: String(OO)
                }]
              }(OO.baf2LeftItems);
            return (0, Ve.jsx)("li", {
              className: Fb()("Baf2IslandPerson", {
                Pending: DO
              }),
              children: (0, Ve.jsxs)("div", {
                className: "Baf2IslandPersonRow",
                children: [(0, Ve.jsx)("span", {
                  className: "Baf2IslandPersonName",
                  children: OO.baf2LeftName
                }), (0, Ve.jsx)("span", {
                  className: "Baf2IslandPersonTag",
                  children: eO(MO[0], MO[1])
                }), hO.claim && (0, Ve.jsx)(av.s, {
                  className: "Baf2IslandPersonButton",
                  disabled: DO,
                  onClick: () => {
                    (OO => {
                      const pO = lO.sendIslandEdit(`baf2coopclaim ${KO.baf2IslandId} ${OO}`);
                      CO((KO => new Map(KO).set(OO, {
                        atMs: Date.now(),
                        answer: pO
                      })))
                    })(XO)
                  },
                  children: eO(`${XM}islandsClaim`)
                })]
              })
            }, XO)
          }))
        }), hO.goThere && (0, Ve.jsx)("p", {
          className: "Baf2IslandFormNote Quiet",
          children: eO(`${XM}islandsClaimGoThere`)
        })]
      })
    }

    function hM(OO) {
      let {
        card: KO,
        view: pO,
        blocked: bK,
        maxIslands: eO,
        answered: lO,
        nowMs: vK,
        done: CO,
        openSocial: hO,
        t: DO
      } = OO;
      const MO = Yl(),
        [aK, oO] = (0, XO.useState)(new Map),
        [FO, VO] = (0, XO.useState)(new Map),
        [LO, QO] = (0, XO.useState)(null),
        zK = (0, XO.useRef)(null);
      Rh(zK);
      const AO = KO.baf2IslandId,
        fO = KO.baf2IslandCoop,
        dO = null !== fO && void 0 !== fO && fO.baf2CoopMembers.some((OO => OO.baf2MemberKey === LO)) ? LO : null,
        TO = function(OO, KO) {
          const pO = OO.baf2IslandCoop;
          return pO && Yh(pO) || null !== KO ? void 0 : OO.baf2IslandInvitable
        }(KO, bK),
        NO = function(OO, KO) {
          const pO = OO.baf2IslandCoop;
          return pO && Yh(pO) ? {
            key: `${vD}islandsCoopFull`,
            params: {
              max: String(pO.baf2CoopMax)
            }
          } : void 0 !== OO.baf2IslandInvitable && null === KO || pO && !pO.baf2CoopManageHere ? null : "degraded" === KO || "stuck" === KO ? {
            key: `${vD}islandsInviteNotLoaded`
          } : null === KO || function(OO) {
            return "notHome" === OO || "wilds" === OO || "visiting" === OO
          }(KO) || Lh(KO) ? {
            key: `${vD}islandsInviteGoThere`
          } : {
            key: `${vD}islandsInviteBusy`
          }
        }(KO, bK),
        IO = () => {
          var OO;
          QO(null), null === (OO = zK.current) || void 0 === OO || OO.focus()
        };
      return (0, Ve.jsxs)("div", {
        ref: zK,
        tabIndex: -1,
        className: "Baf2IslandForm Baf2IslandPeople",
        ...Ph(null === dO ? CO : IO),
        children: [fO && (0, Ve.jsxs)(Ve.Fragment, {
          children: [(0, Ve.jsx)("p", {
            className: "Baf2IslandFormTitle",
            children: DO(`${XM}islandsPlayersTitle`, {
              count: String(fO.baf2CoopMembers.length),
              max: String(fO.baf2CoopMax)
            })
          }), (0, Ve.jsx)("ul", {
            className: "Baf2IslandPeopleList",
            children: fO.baf2CoopMembers.map(((OO, KO) => {
              const XO = OO.baf2MemberKey,
                bK = wh(aK.get(XO), lO, vK);
              return (0, Ve.jsxs)("li", {
                className: Fb()("Baf2IslandPerson", {
                  Pending: bK
                }),
                children: [(0, Ve.jsxs)("div", {
                  className: "Baf2IslandPersonRow",
                  children: [(0, Ve.jsx)("span", {
                    className: Fb()("Baf2IslandPersonName", {
                      Here: OO.baf2MemberHere
                    }),
                    children: OO.baf2MemberName
                  }), OO.baf2MemberHere && (0, Ve.jsx)("span", {
                    className: "Baf2IslandPersonTag",
                    children: DO(`${XM}islandsPlayerHere`)
                  }), 0 === KO && (0, Ve.jsx)("span", {
                    className: "Baf2IslandPersonTag Owner",
                    children: DO(`${XM}islandsPlayerOwner`)
                  }), pO.remove && KO > 0 && !bK && dO !== XO && (0, Ve.jsx)(av.M, {
                    className: "Baf2IslandPersonButton",
                    onClick: () => {
                      var OO;
                      QO(XO), null === (OO = zK.current) || void 0 === OO || OO.focus()
                    },
                    children: DO(`${XM}islandsRemove`)
                  })]
                }), dO === XO && (0, Ve.jsxs)("div", {
                  className: "Baf2IslandConfirm",
                  children: [(0, Ve.jsx)("p", {
                    children: Ih(DO, `${XM}islandsRemoveConfirm`, {
                      player: OO.baf2MemberName
                    })
                  }), (0, Ve.jsxs)("div", {
                    className: "Baf2IslandButtons",
                    children: [(0, Ve.jsx)(av.I, {
                      onClick: () => {
                        (OO => {
                          const KO = MO.sendIslandEdit(`baf2coopremove ${AO} ${OO.baf2MemberKey}`);
                          oO((pO => new Map(pO).set(OO.baf2MemberKey, {
                            atMs: Date.now(),
                            answer: KO
                          }))), IO()
                        })(OO)
                      },
                      children: DO(`${XM}islandsRemoveYes`)
                    }), (0, Ve.jsx)(av.d, {
                      onClick: IO,
                      children: DO(`${XM}islandsCancel`)
                    })]
                  })]
                })]
              }, XO)
            }))
          })]
        }), (void 0 !== TO || null !== NO) && (0, Ve.jsx)("p", {
          className: "Baf2IslandFormTitle",
          children: DO(`${XM}islandsInviteTitle`)
        }), !fO && (void 0 !== TO || null !== NO) && (0, Ve.jsx)("p", {
          className: "Baf2IslandFormNote Quiet",
          children: DO(`${XM}islandsInviteShareNote`)
        }), 0 === (null === TO || void 0 === TO ? void 0 : TO.length) && (0, Ve.jsx)(DM, {
          openSocial: hO,
          t: DO
        }), void 0 !== TO && TO.length > 0 && (0, Ve.jsx)("ul", {
          className: "Baf2IslandPeopleList",
          children: TO.map((OO => {
            const KO = !0 === OO.baf2InvitableSent || wh(FO.get(OO.baf2InvitableId), lO, vK);
            return (0, Ve.jsx)("li", {
              className: "Baf2IslandPerson",
              children: (0, Ve.jsxs)("div", {
                className: "Baf2IslandPersonRow",
                children: [(0, Ve.jsx)("span", {
                  className: "Baf2IslandPersonName",
                  children: OO.baf2InvitableName
                }), OO.baf2InvitableFull && !KO && (0, Ve.jsx)("span", {
                  className: "Baf2IslandPersonTag",
                  children: DO(`${XM}islandsInviteTheirFull`, {
                    max: String(eO)
                  })
                }), (KO || !OO.baf2InvitableFull) && (0, Ve.jsx)(av.s, {
                  className: "Baf2IslandPersonButton",
                  disabled: KO,
                  onClick: () => {
                    (OO => {
                      const KO = MO.sendIslandEdit(`baf2coopinvite ${AO} ${OO}`);
                      VO((pO => new Map(pO).set(OO, {
                        atMs: Date.now(),
                        answer: KO
                      })))
                    })(OO.baf2InvitableId)
                  },
                  children: DO(KO ? `${XM}islandsInvited` : `${XM}islandsInvite`)
                })]
              })
            }, OO.baf2InvitableId)
          }))
        }), NO && (0, Ve.jsx)(cD, {
          note: NO,
          t: DO
        }), (0, Ve.jsx)("div", {
          className: "Baf2IslandButtons",
          children: (0, Ve.jsx)(av.d, {
            onClick: CO,
            children: DO(`${XM}islandsDone`)
          })
        })]
      })
    }

    function DM(OO) {
      let {
        openSocial: KO,
        t: pO
      } = OO;
      return (0, Ve.jsxs)(Ve.Fragment, {
        children: [(0, Ve.jsx)("p", {
          className: "Baf2IslandFormNote Quiet",
          children: pO(KO ? `${XM}islandsInviteNobody` : `${XM}islandsInviteNobodyGuest`)
        }), KO && (0, Ve.jsx)("div", {
          className: "Baf2IslandButtons",
          children: (0, Ve.jsx)(av.d, {
            onClick: KO,
            children: pO("socialBar:social")
          })
        })]
      })
    }

    function MM(OO) {
      let {
        className: KO,
        text: pO,
        ConfirmButton: bK,
        confirmLabel: eO,
        canConfirm: lO,
        send: vK,
        done: CO,
        t: hO
      } = OO;
      const DO = (0, XO.useRef)(null);
      Rh(DO);
      const MO = () => {
        CO(null)
      };
      return (0, Ve.jsxs)("div", {
        ref: DO,
        tabIndex: -1,
        className: Fb()("Baf2IslandForm", KO),
        ...Ph(MO),
        children: [(0, Ve.jsx)("p", {
          className: "Baf2IslandConfirmText",
          children: pO
        }), (0, Ve.jsxs)("div", {
          className: "Baf2IslandButtons Stacked",
          children: [(0, Ve.jsx)(bK, {
            disabled: !lO,
            onClick: () => {
              lO && CO(vK())
            },
            children: eO
          }), (0, Ve.jsx)(av.d, {
            onClick: MO,
            children: hO(`${XM}islandsCancel`)
          })]
        })]
      })
    }

    function aa(OO) {
      return "hidden" !== OO
    }

    function oM(OO) {
      var KO, pO;
      let {
        card: bK,
        keepOwn: eO,
        blocked: lO,
        maxIslands: vK,
        serverNowMs: CO,
        nowMs: hO,
        actions: DO,
        full: MO,
        waits: aK,
        answered: oO,
        mode: FO,
        setMode: VO,
        pending: LO,
        onSent: QO,
        switchTo: zK,
        DX: AO,
        coopOn: fO,
        openSocial: dO,
        t: TO
      } = OO;
      const NO = Yl(),
        IO = bK.baf2IslandActive,
        yK = IO ? null : function(OO, KO) {
          if (OO <= 0) return null;
          const pO = KO - OO;
          if (pO < le) return [`${vD}islandsPlayedJustNow`];
          if (pO < Ch) return [`${vD}islandsPlayedMinutes`, {
            minutes: String(Math.floor(pO / le))
          }];
          if (pO < hh) return [`${vD}islandsPlayedHours`, {
            hours: String(Math.floor(pO / Ch))
          }];
          const XO = Math.floor(pO / hh);
          return 1 === XO ? [`${vD}islandsPlayedDay`] : [`${vD}islandsPlayedDays`, {
            days: String(XO)
          }]
        }(bK.baf2IslandLastPlayedMs, CO),
        gK = void 0 === (uO = bK.baf2IslandItems) ? null : 0 === uO ? [`${vD}islandsItemsNone`] : 1 === uO ? [`${vD}islandsItemsOne`] : [`${vD}islandsItems`, {
          count: String(uO)
        }];
      var uO;
      const EO = function(OO) {
          return OO ? 1 === OO ? [`${vD}islandsWaitingOne`] : [`${vD}islandsWaiting`, {
            count: String(OO)
          }] : null
        }(bK.baf2IslandWaiting),
        jK = bK.baf2IslandUnreadable,
        YO = bK.baf2IslandCoop,
        wO = Eh(bK, DO, eO, MO, fO),
        iK = (0, XO.useRef)(null);
      sh(null !== FO, iK);
      const rK = () => {
          var OO;
          VO(null), null === (OO = iK.current) || void 0 === OO || OO.focus()
        },
        PO = (OO, KO) => {
          rK(), null !== OO && QO(OO, KO)
        },
        mK = (OO, KO) => TO(`${XM}${OO}`, {
          time: Me(TO, KO)
        });
      return (0, Ve.jsxs)("li", {
        ref: iK,
        tabIndex: -1,
        className: Fb()("Baf2IslandCard", {
          Active: IO,
          Pending: LO,
          Shared: void 0 !== YO
        }),
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2IslandHead",
          children: [(0, Ve.jsx)("strong", {
            className: "Baf2IslandName",
            children: bK.baf2IslandName
          }), IO && (0, Ve.jsx)("span", {
            className: "Baf2IslandBadge",
            children: TO(`${XM}islandsOnThis`)
          }), YO && (0, Ve.jsx)("span", {
            className: "Baf2IslandBadge Shared",
            children: TO(`${XM}islandsShared`)
          })]
        }), "member" === (null === YO || void 0 === YO ? void 0 : YO.baf2CoopRole) && (0, Ve.jsx)("p", {
          className: "Baf2IslandSharedBy",
          children: Ih(TO, `${XM}islandsSharedBy`, {
            owner: YO.baf2CoopOwner
          })
        }), void 0 !== jK && (0, Ve.jsx)("p", {
          className: "Baf2IslandUnreadable",
          children: TO("newer" === jK ? `${XM}islandsUnreadable` : `${XM}islandsDamaged`)
        }), "corrupt" === jK && MO && (0, Ve.jsx)("p", {
          className: "Baf2IslandStats",
          children: TO(`${XM}islandsDamagedFull`)
        }), void 0 === jK && (0, Ve.jsxs)(Ve.Fragment, {
          children: [(0, Ve.jsx)(Jh, {
            tier: bK.baf2IslandTier,
            t: TO
          }), (0, Ve.jsxs)("p", {
            className: "Baf2IslandStats",
            children: [(0, Ve.jsx)("span", {
              children: 1 === bK.baf2IslandQuestsDone ? TO(`${XM}islandsQuestsDoneOne`) : TO(`${XM}islandsQuestsDone`, {
                count: String(bK.baf2IslandQuestsDone)
              })
            }), (0, Ve.jsx)("span", {
              children: 1 === bK.baf2IslandMachines ? TO(`${XM}islandsMachinesOne`) : TO(`${XM}islandsMachines`, {
                count: String(bK.baf2IslandMachines)
              })
            }), gK && (0, Ve.jsx)("span", {
              children: TO(gK[0], gK[1])
            }), EO && (0, Ve.jsx)("span", {
              className: "Baf2IslandWaiting",
              children: TO(EO[0], EO[1])
            }), yK && (0, Ve.jsx)("span", {
              children: TO(yK[0], yK[1])
            })]
          })]
        }), YO && void 0 === YO.baf2CoopState && "people" !== FO && (0, Ve.jsx)(va, {
          members: YO.baf2CoopMembers,
          t: TO
        }), null === FO && (0, Ve.jsx)(CM, {
          card: bK,
          answered: oO,
          nowMs: hO,
          t: TO
        }), wO.note && (0, Ve.jsx)(cD, {
          note: wO.note,
          className: Fb()({
            Unreachable: void 0 !== (null === YO || void 0 === YO ? void 0 : YO.baf2CoopState)
          }),
          t: TO
        }), "rename" === FO && (0, Ve.jsx)(eM, {
          card: bK,
          canRename: "enabled" === wO.rename,
          done: PO,
          t: TO
        }), "delete" === FO && (0, Ve.jsx)(lM, {
          card: bK,
          canDelete: "enabled" === wO.delete,
          done: OO => {
            PO(OO, YO ? "delete" : void 0)
          },
          t: TO
        }), "people" === FO && (0, Ve.jsx)(hM, {
          card: bK,
          view: wO,
          blocked: lO,
          maxIslands: vK,
          answered: oO,
          nowMs: hO,
          done: rK,
          openSocial: dO,
          t: TO
        }), "DX" === FO && (0, Ve.jsx)(MM, {
          className: "Leave",
          text: Ih(TO, `${XM}islandsLeaveConfirm`, {
            island: bK.baf2IslandName,
            owner: null !== (KO = null === (pO = bK.baf2IslandCoop) || void 0 === pO ? void 0 : pO.baf2CoopOwner) && void 0 !== KO ? KO : ""
          }),
          ConfirmButton: av.I,
          confirmLabel: TO(`${XM}islandsLeaveYes`),
          canConfirm: "enabled" === wO.DX,
          send: () => ba(NO, bK),
          done: OO => {
            PO(OO, "DX"), null !== OO && IO && AO()
          },
          t: TO
        }), "unshare" === FO && (0, Ve.jsx)(MM, {
          className: "Unshare",
          text: Ih(TO, `${XM}islandsStopSharingConfirm`, {
            island: bK.baf2IslandName
          }),
          ConfirmButton: av.s,
          confirmLabel: TO(`${XM}islandsStopSharing`),
          canConfirm: "enabled" === wO.unshare,
          send: () => NO.sendIslandEdit(`baf2coopunshare ${bK.baf2IslandId}`),
          done: OO => {
            PO(OO), null !== OO && AO()
          },
          t: TO
        }), null === FO && !LO && (0, Ve.jsxs)("div", {
          className: "Baf2IslandButtons",
          role: "group",
          "aria-label": bK.baf2IslandName,
          children: [aa(wO.switch) && (0, Ve.jsx)(av.s, {
            disabled: "enabled" !== wO.switch,
            onClick: zK,
            children: aK.switch > 0 ? mK("islandsSwitchIn", aK.switch) : TO(`${XM}islandsSwitch`)
          }), aa(wO.rename) && (0, Ve.jsx)(av.d, {
            disabled: "enabled" !== wO.rename,
            onClick: () => {
              VO("rename")
            },
            children: TO(`${XM}islandsRename`)
          }), aa(wO.people) && (0, Ve.jsx)(av.d, {
            disabled: "enabled" !== wO.people,
            onClick: () => {
              VO("people")
            },
            children: TO("players" === wO.peopleLabel ? `${XM}islandsPlayersButton` : `${XM}islandsInviteButton`)
          }), aa(wO.unshare) && (0, Ve.jsx)(av.d, {
            disabled: "enabled" !== wO.unshare,
            onClick: () => {
              VO("unshare")
            },
            children: TO(`${XM}islandsStopSharing`)
          }), aa(wO.dismiss) && (0, Ve.jsx)(av.d, {
            disabled: "enabled" !== wO.dismiss,
            onClick: () => {
              QO(ba(NO, bK), "dismiss"), IO && AO()
            },
            children: TO(`${XM}islandsDismiss`)
          }), aa(wO.DX) && (0, Ve.jsx)(av.M, {
            className: "Baf2IslandDelete",
            disabled: "enabled" !== wO.DX,
            onClick: () => {
              VO("DX")
            },
            children: IO && aK.switch > 0 ? mK("islandsLeaveIn", aK.switch) : TO(`${XM}islandsLeave`)
          }), aa(wO.delete) && (0, Ve.jsx)(av.M, {
            className: "Baf2IslandDelete",
            disabled: "enabled" !== wO.delete,
            onClick: () => {
              VO("delete")
            },
            children: aK.change > 0 && wO.deleteWaits ? mK("islandsDeleteIn", aK.change) : TO(`${XM}islandsDelete`)
          })]
        })]
      })
    }
    const FM = "buildAFactory2Game:";

    function VM(OO) {
      let {
        invite: KO,
        actions: pO,
        full: bK,
        maxIslands: eO,
        waitSeconds: lO,
        focus: vK,
        focused: CO,
        join: hO,
        decline: DO,
        t: MO
      } = OO;
      const [aK, oO] = (0, XO.useState)(!1), FO = (0, XO.useRef)(null);
      sh(aK, FO), (0, XO.useEffect)((() => {
        var OO;
        vK && (oO(!0), null === (OO = FO.current) || void 0 === OO || OO.focus(), CO())
      }), [vK, CO]);
      const VO = function(OO, KO, pO, XO, bK) {
          return pO ? {
            join: !1,
            note: {
              key: `${vD}islandsJoinTooMany`,
              params: {
                max: String(XO)
              }
            }
          } : OO.baf2InvitePlayers >= bK ? {
            join: !1,
            note: {
              key: `${vD}islandsJoinFull`
            }
          } : {
            join: KO.switch,
            note: null
          }
        }(KO, pO, bK, eO, 10),
        LO = KO.baf2InviteIsland,
        QO = KO.baf2InvitePlayers,
        zK = () => {
          var OO;
          oO(!1), null === (OO = FO.current) || void 0 === OO || OO.focus()
        },
        AO = lO > 0 && null === VO.note ? MO(`${FM}islandsJoinIn`, {
          time: Me(MO, lO)
        }) : MO(`${FM}islandsJoin`);
      return (0, Ve.jsxs)("li", {
        ref: FO,
        tabIndex: -1,
        className: "Baf2IslandCard Invite",
        ...aK ? Ph(zK) : {},
        children: [(0, Ve.jsx)("div", {
          className: "Baf2IslandHead",
          children: (0, Ve.jsx)("strong", {
            className: "Baf2IslandName",
            children: LO
          })
        }), (0, Ve.jsx)("p", {
          className: "Baf2IslandSharedBy",
          children: Ih(MO, `${FM}islandsInvitedBy`, {
            owner: KO.baf2InviteOwner
          })
        }), (0, Ve.jsx)(Jh, {
          tier: KO.baf2InviteTier,
          t: MO
        }), (0, Ve.jsx)("p", {
          className: "Baf2IslandStats",
          children: (0, Ve.jsx)("span", {
            children: 1 === QO ? MO(`${FM}islandsPlayersCountOne`) : MO(`${FM}islandsPlayersCount`, {
              count: String(QO)
            })
          })
        }), VO.note && (0, Ve.jsx)(cD, {
          note: VO.note,
          t: MO
        }), aK && (0, Ve.jsx)("p", {
          className: "Baf2IslandConfirmText",
          children: Ih(MO, `${FM}islandsJoinConfirm`, {
            island: LO
          })
        }), !aK && (0, Ve.jsxs)("div", {
          className: "Baf2IslandButtons",
          role: "group",
          "aria-label": LO,
          children: [(0, Ve.jsx)(av.s, {
            disabled: !VO.join,
            onClick: () => {
              var OO;
              oO(!0), null === (OO = FO.current) || void 0 === OO || OO.focus()
            },
            children: AO
          }), (0, Ve.jsx)(av.d, {
            onClick: DO,
            children: MO(`${FM}islandsDecline`)
          })]
        }), aK && (0, Ve.jsxs)("div", {
          className: "Baf2IslandButtons Stacked",
          children: [(0, Ve.jsx)(av.s, {
            disabled: !VO.join,
            onClick: hO,
            children: MO(`${FM}islandsJoinYes`)
          }), (0, Ve.jsx)(av.d, {
            onClick: zK,
            children: MO(`${FM}islandsCancel`)
          })]
        })]
      })
    }

    function LM(OO) {
      let {
        invites: KO,
        actions: pO,
        full: XO,
        maxIslands: bK,
        waitSeconds: eO,
        focus: lO,
        focused: vK,
        DX: CO,
        declined: hO,
        t: DO
      } = OO;
      const MO = Yl();
      return (0, Ve.jsxs)("section", {
        className: "Baf2IslandInvites",
        "aria-labelledby": "baf2IslandInvitesTitle",
        children: [(0, Ve.jsx)("h3", {
          id: "baf2IslandInvitesTitle",
          children: DO(`${FM}islandsInvitesTitle`)
        }), (0, Ve.jsx)("ul", {
          className: "Baf2IslandCards",
          children: KO.map((OO => {
            const KO = OO.baf2InviteId;
            return (0, Ve.jsx)(VM, {
              invite: OO,
              actions: pO,
              full: XO,
              maxIslands: bK,
              waitSeconds: eO,
              focus: lO === KO,
              focused: vK,
              join: () => {
                MO.send(`baf2coopaccept ${KO}`), CO()
              },
              decline: () => {
                MO.send(`baf2coopdecline ${KO}`), hO(KO)
              },
              t: DO
            }, KO)
          }))
        })]
      })
    }
    const QM = "buildAFactory2Game:";

    function za(OO) {
      let {
        cards: KO,
        activeName: pO,
        canStart: bK,
        waitSeconds: eO,
        DX: lO,
        t: vK
      } = OO;
      const CO = Yl(),
        [hO, DO] = (0, XO.useState)(!1),
        [MO, aK] = (0, XO.useState)(""),
        oO = (0, XO.useRef)(null);
      sh(hO, oO), (0, XO.useEffect)((() => {
        var OO;
        hO && (null === (OO = oO.current) || void 0 === OO || OO.focus())
      }), [hO]);
      const FO = oh(KO),
        VO = Mh(MO),
        LO = aD(VO),
        QO = () => {
          bK && !LO && (CO.send("" === VO || VO === FO ? nO : `${nO} ${VO}`), lO())
        },
        zK = () => {
          var OO;
          DO(!1), null === (OO = oO.current) || void 0 === OO || OO.focus()
        };
      return (0, Ve.jsxs)("li", {
        ref: oO,
        tabIndex: -1,
        className: "Baf2IslandCard New",
        ...hO ? Ph(zK) : {},
        children: [(0, Ve.jsx)("strong", {
          className: "Baf2IslandName",
          children: vK(`${QM}islandsNewTitle`)
        }), !hO && (0, Ve.jsx)("p", {
          className: "Baf2IslandStats",
          children: vK(`${QM}islandsNewNote`)
        }), hO && (0, Ve.jsxs)(Ve.Fragment, {
          children: [(0, Ve.jsx)("p", {
            className: "Baf2IslandNewConfirm",
            children: Ih(vK, `${QM}islandsNewConfirm`, {
              name: pO
            })
          }), (0, Ve.jsxs)("label", {
            className: "Baf2IslandFormLabel",
            children: [vK(`${QM}islandsNewNameLabel`), (0, Ve.jsx)("input", {
              type: "text",
              className: "Baf2IslandInput",
              value: MO,
              placeholder: FO,
              maxLength: 24,
              autoComplete: "off",
              spellCheck: !1,
              enterKeyHint: "go",
              onFocus: mD,
              onChange: OO => {
                aK(OO.target.value)
              },
              ...rD(QO, zK)
            })]
          }), LO && (0, Ve.jsx)("p", {
            className: "Baf2IslandFormNote",
            children: vK(`${QM}islandsNameReserved`)
          })]
        }), (0, Ve.jsxs)("div", {
          className: Fb()("Baf2IslandButtons", {
            Stacked: hO
          }),
          children: [(0, Ve.jsx)(av.s, {
            disabled: !bK || hO && LO,
            onClick: () => {
              if (!hO) return aK(FO), void DO(!0);
              QO()
            },
            children: eO > 0 ? vK(`${QM}islandsNewIn`, {
              time: Me(vK, eO)
            }) : vK(hO ? `${QM}islandsNewConfirmButton` : `${QM}islandsNew`)
          }), hO && (0, Ve.jsx)(av.d, {
            onClick: zK,
            children: vK(`${QM}islandsCancel`)
          })]
        })]
      })
    }

    function AM(OO) {
      var KO, pO;
      let {
        message: bK,
        arrivedAtMs: eO,
        close: lO,
        DX: vK,
        openSocial: CO
      } = OO;
      const hO = Yl(),
        {
          t: DO
        } = (0, ze.D)(),
        MO = Sh(1e3),
        [aK, oO] = (0, XO.useState)(null),
        [FO, VO] = (0, XO.useState)(new Map),
        [LO, QO] = (0, XO.useState)(new Set),
        zK = bK.baf2IslandCards,
        AO = function(OO, KO, pO, XO) {
          return (null !== OO && void 0 !== OO ? OO : []).filter((OO => KO + OO.baf2InviteLeftMs > pO && !XO.has(OO.baf2InviteId)))
        }(bK.baf2IslandsInvites, eO, MO, LO),
        fO = AO.map((OO => OO.baf2InviteId)).join(" "),
        dO = (0, XO.useRef)(null),
        TO = Hh(dO);
      (0, XO.useEffect)((() => {
        var OO, KO;
        null !== (OO = dO.current) && void 0 !== OO && OO.contains(document.activeElement) || (null === (KO = dO.current) || void 0 === KO || KO.focus())
      }), [bK, fO]), (0, XO.useEffect)((() => {
        VO((OO => function(OO, KO, pO, XO) {
          const bK = new Map;
          for (const eO of KO) {
            const KO = OO.get(eO.baf2IslandId);
            KO && (void 0 !== KO.untilGone || XO < KO.answer) && fh(KO, eO, pO) && bK.set(eO.baf2IslandId, KO)
          }
          return bK.size === OO.size ? OO : bK
        }(OO, bK.baf2IslandCards, Date.now(), bK.baf2IslandsAnswered)))
      }), [bK]);
      const NO = Dh(eO, bK.baf2IslandsWaitMs, MO),
        IO = bK.baf2IslandsBlocked,
        yK = Qh(IO, NO),
        gK = function(OO, KO) {
          const pO = Qh(OO, 0);
          return {
            switch: pO.switch ? KO : 0,
            change: pO.change ? KO : 0
          }
        }(IO, NO),
        uO = zK.length >= bK.baf2IslandsMax,
        EO = zK.length > 0,
        jK = function(OO, KO, pO) {
          return OO + Math.max(0, pO - KO)
        }(bK.baf2IslandsNowMs, eO, MO),
        YO = null !== (KO = null === (pO = zK.find((OO => OO.baf2IslandActive))) || void 0 === pO ? void 0 : pO.baf2IslandName) && void 0 !== KO ? KO : "",
        wO = function(OO) {
          const KO = OO.filter(uh).length;
          return KO <= 1 && KO < OO.length
        }(zK),
        iK = !0 === bK.baf2IslandsCoop,
        rK = function(OO, KO) {
          const pO = OO.find((OO => OO.baf2IslandActive)),
            XO = null === pO || void 0 === pO ? void 0 : pO.baf2IslandCoop;
          return pO && "member" === (null === XO || void 0 === XO ? void 0 : XO.baf2CoopRole) ? {
            key: `${vD}islandsKeepOwnMember`,
            names: {
              owner: XO.baf2CoopOwner,
              island: pO.baf2IslandName
            }
          } : {
            key: KO ? `${vD}islandsKeepOwn` : `${vD}islandsKeepOwnSolo`
          }
        }(zK, iK),
        [PO, mK] = (0, XO.useState)(null);
      (0, XO.useEffect)((() => {
        void 0 !== bK.baf2IslandsFocusInvite && mK(bK.baf2IslandsFocusInvite)
      }), [bK]);
      const sO = (0, XO.useCallback)((() => {
          mK(null)
        }), []),
        HO = aK ? zK.find((OO => OO.baf2IslandId === aK.id)) : void 0,
        RO = aK && HO && "hidden" !== Eh(HO, yK, wO, uO, iK)[aK.mode] ? aK : null;
      return (0, Ve.jsx)(Ml.d, {
        close: lO,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay Baf2IslandsOverlay",
        children: (0, Ve.jsxs)("section", {
          ref: dO,
          tabIndex: -1,
          className: "Baf2Panel Baf2IslandsPanel",
          style: TO ? {
            marginTop: `${TO.marginTop}px`,
            maxHeight: `${TO.maxHeight}px`
          } : void 0,
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2IslandsTitle",
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsxs)("div", {
              children: [(0, Ve.jsx)("h2", {
                id: "baf2IslandsTitle",
                children: DO(`${QM}islandsTitle`)
              }), EO && (0, Ve.jsx)("p", {
                children: DO(`${QM}islandsSubtitle`, {
                  count: String(zK.length),
                  max: String(bK.baf2IslandsMax)
                })
              })]
            }), (0, Ve.jsx)(av.i, {
              ariaLabel: DO(`${QM}islandsClose`),
              onClick: lO
            })]
          }), (0, Ve.jsxs)("div", {
            className: "Baf2IslandsBody",
            children: [null !== IO && (0, Ve.jsx)("p", {
              className: "Baf2IslandsBlocked",
              children: Ih(DO, Fh(IO, Vh(zK)), {
                island: YO
              })
            }), EO && AO.length > 0 && (0, Ve.jsx)(LM, {
              invites: AO,
              actions: yK,
              full: uO,
              maxIslands: bK.baf2IslandsMax,
              waitSeconds: gK.switch,
              focus: PO,
              focused: sO,
              DX: vK,
              declined: OO => {
                QO((KO => new Set(KO).add(OO)))
              },
              t: DO
            }), EO && (0, Ve.jsxs)(Ve.Fragment, {
              children: [uO && (0, Ve.jsx)("p", {
                className: "Baf2IslandsNote Full",
                children: DO(`${QM}islandsFull`, {
                  max: String(bK.baf2IslandsMax)
                })
              }), (0, Ve.jsx)("p", {
                className: "Baf2IslandsNote",
                children: Ih(DO, rK.key, rK.names)
              }), (0, Ve.jsxs)("ul", {
                className: "Baf2IslandCards",
                children: [zK.map((OO => {
                  const KO = OO.baf2IslandId;
                  return (0, Ve.jsx)(oM, {
                    card: OO,
                    keepOwn: wO,
                    coopOn: iK,
                    openSocial: CO,
                    blocked: IO,
                    maxIslands: bK.baf2IslandsMax,
                    serverNowMs: jK,
                    nowMs: MO,
                    actions: yK,
                    full: uO,
                    waits: gK,
                    answered: bK.baf2IslandsAnswered,
                    mode: (null === RO || void 0 === RO ? void 0 : RO.id) === KO ? RO.mode : null,
                    setMode: OO => {
                      oO(null === OO ? null : {
                        id: KO,
                        mode: OO
                      })
                    },
                    pending: fh(FO.get(KO), OO, MO),
                    onSent: (pO, XO) => {
                      VO((bK => {
                        const eO = {
                          atMs: Date.now(),
                          from: OO.baf2IslandName,
                          answer: pO
                        };
                        return new Map(bK).set(KO, XO ? {
                          ...eO,
                          untilGone: XO
                        } : eO)
                      }))
                    },
                    DX: vK,
                    switchTo: () => {
                      hO.send(`baf2islandswitch ${KO}`), vK()
                    },
                    t: DO
                  }, KO)
                })), !uO && (0, Ve.jsx)(za, {
                  cards: zK,
                  activeName: YO,
                  canStart: yK.change,
                  waitSeconds: gK.change,
                  DX: vK,
                  t: DO
                })]
              })]
            })]
          })]
        })
      })
    }
    const fM = {
        all: "buildAFactory2Game:terminalChip_all",
        recent: "buildAFactory2Game:terminalChip_recent",
        AO: "buildAFactory2Game:terminalChip_ores",
        bars: "buildAFactory2Game:terminalChip_bars",
        parts: "buildAFactory2Game:terminalChip_parts",
        nuclear: "buildAFactory2Game:terminalChip_nuclear",
        farm: "buildAFactory2Game:terminalChip_farm",
        other: "buildAFactory2Game:terminalChip_other"
      },
      dM = Object.keys(fM),
      TM = new Set([...Object.keys(SK), ...[...yp.Press.recipes, ...yp["Wire Mill"].recipes].map((OO => OO.output))]),
      NM = /Uranium|Plutonium|Pellet|Glow Dust|Nova|Isotope|Graphite|Coolant|Nuclear/,
      IM = / Ore$|^Raw |^Coal$|Voltite|Diamond|Moonstone|Crystal/,
      ya = / Bar$|Alloy$/,
      ga = /Porkchop|Beef|Mutton|Venison|Steak/,
      uM = /Wheat|Seed|Biomass|Fertiliser|Log$|Sapling|Planks|Wool|Leather|Bone|Moss|Bush|Melon|Carrot|Potato|Pumpkin|Apple|Flower/;

    function EM(OO) {
      let {
        item: KO,
        name: pO,
        amount: XO,
        selected: bK,
        small: eO,
        onPick: lO
      } = OO;
      return (0, Ve.jsxs)("button", {
        type: "button",
        className: Fb()("Baf2TermTile", {
          On: bK,
          Small: eO
        }),
        "aria-label": `${pO}: ${XO}`,
        "aria-pressed": bK,
        onClick: lO,
        children: [(0, Ve.jsx)("span", {
          className: "Baf2TermIcon",
          children: (0, Ve.jsx)(fb.b, {
            itemName: KO,
            amount: 0
          })
        }), (0, Ve.jsx)("span", {
          className: "Baf2TermCount",
          children: he(XO, 1e4)
        }), !eO && (0, Ve.jsx)("span", {
          className: "Baf2TermName",
          children: pO
        })]
      })
    }

    function ja(OO) {
      let {
        store: KO,
        close: pO,
        send: bK
      } = OO;
      const {
        t: eO
      } = (0, ze.D)(), {
        isTouchScreen: lO
      } = (0, Mb.l)(["isTouchScreen"]);
      ! function(OO) {
        const [KO, pO] = (0, XO.useState)(OO.version);
        (0, XO.useEffect)((() => (pO(OO.version), OO.subscribe((() => {
          pO(OO.version)
        })))), [OO])
      }(KO);
      const [vK, CO] = (0, XO.useState)("all"), [hO, DO] = (0, XO.useState)(!1), [MO, aK] = (0, XO.useState)(""), [oO, FO] = (0, XO.useState)(""), [VO, LO] = (0, XO.useState)(null), [QO, zK, AO] = function() {
        const OO = (0, XO.useRef)(null),
          [KO, pO] = (0, XO.useState)(!1),
          bK = () => {
            const KO = OO.current;
            pO(null !== KO && KO.scrollLeft + KO.clientWidth < KO.scrollWidth - 1)
          };
        return (0, XO.useEffect)(bK), (0, XO.useEffect)((() => {
          const KO = OO.current;
          if (!KO) return;
          const pO = new ResizeObserver(bK);
          return pO.observe(KO), () => {
            pO.disconnect()
          }
        }), []), [OO, KO, bK]
      }(), fO = (0, XO.useMemo)((() => new Map), [eO]), dO = OO => {
        let KO = fO.get(OO);
        return void 0 === KO && (KO = function(OO, KO) {
          const pO = /^(.+) \((.+)\)$/.exec(OO);
          return pO ? KO(pO[2], pO[1]) : OO
        }(xe(eO, OO), ((OO, KO) => eO("buildAFactory2Game:terminalTileKind", {
          kind: OO,
          base: KO
        }))), fO.set(OO, KO)), KO
      }, TO = KO.isReadOnly(), NO = KO.recent(), IO = KO.items(), yK = oO.trim().toLowerCase(), gK = ("recent" === vK ? NO : IO).filter((OO => {
        const KO = dO(OO);
        return ("all" === vK || "recent" === vK || function(OO) {
          return pe(OO) ? "farm" : NM.test(OO) ? "nuclear" : ya.test(OO) ? "bars" : ga.test(OO) ? "farm" : IM.test(OO) ? "AO" : TM.has(OO) ? "parts" : uM.test(OO) ? "farm" : "other"
        }(OO) === vK) && ("" === yK || KO.toLowerCase().includes(yK)) && ("" === MO || KO.toUpperCase().startsWith(MO))
      })), uO = new Set(IO.map((OO => dO(OO).charAt(0).toUpperCase()))), EO = "recent" !== vK && NO.length > 0, jK = function(OO, KO) {
        return null !== OO && KO.includes(OO) ? OO : null
      }(VO, EO ? [...gK, ...NO] : gK), YO = null === jK ? 0 : KO.amount(jK), wO = OO => {
        LO(jK === OO ? null : OO)
      }, iK = OO => {
        null !== jK && YO > 0 && bK(KO.take(OO, jK))
      }, rK = "" !== MO ? eO("buildAFactory2Game:terminalEmptyLetter", {
        letter: MO
      }) : "" !== yK ? eO("buildAFactory2Game:terminalEmptySearch", {
        query: oO
      }) : eO("buildAFactory2Game:terminalEmpty");
      return (0, Ve.jsx)(Ml.d, {
        close: pO,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay",
        children: (0, Ve.jsxs)("section", {
          className: "Baf2Panel Baf2TerminalPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2TerminalTitle",
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsxs)("div", {
              children: [(0, Ve.jsx)("h2", {
                id: "baf2TerminalTitle",
                children: eO(KO.isPocket() ? "item:pocketTerminal" : "item:wirelessTerminal")
              }), (0, Ve.jsx)("p", {
                children: eO("buildAFactory2Game:terminalSubtitle", {
                  count: String(KO.siloCount())
                })
              })]
            }), (0, Ve.jsx)(av.i, {
              onClick: pO
            })]
          }), (0, Ve.jsxs)("div", {
            className: "Baf2TermBody",
            children: [(0, Ve.jsxs)("div", {
              className: "Baf2TermTools",
              children: [(0, Ve.jsx)("div", {
                ref: QO,
                className: Fb()("Baf2TermChips", {
                  MoreRight: zK
                }),
                onScroll: AO,
                children: hO ? (0, Ve.jsxs)(Ve.Fragment, {
                  children: [(0, Ve.jsx)("button", {
                    type: "button",
                    "aria-label": eO("buildAFactory2Game:terminalCategories"),
                    onClick: () => {
                      DO(!1), aK("")
                    },
                    children: "\u2190"
                  }), [...uO].sort().map((OO => (0, Ve.jsx)("button", {
                    type: "button",
                    className: Fb()({
                      On: MO === OO
                    }),
                    onClick: () => {
                      aK(MO === OO ? "" : OO)
                    },
                    children: OO
                  }, OO)))]
                }) : (0, Ve.jsxs)(Ve.Fragment, {
                  children: [(0, Ve.jsx)("button", {
                    type: "button",
                    onClick: () => {
                      DO(!0)
                    },
                    children: eO("buildAFactory2Game:terminalLetters")
                  }), dM.map((OO => (0, Ve.jsx)("button", {
                    type: "button",
                    className: Fb()({
                      On: vK === OO
                    }),
                    onClick: () => {
                      CO(OO)
                    },
                    children: eO(fM[OO])
                  }, OO)))]
                })
              }), !lO && (0, Ve.jsx)("input", {
                className: "Baf2TermSearch",
                type: "search",
                value: oO,
                placeholder: eO("buildAFactory2Game:terminalSearch"),
                "aria-label": eO("buildAFactory2Game:terminalSearch"),
                onChange: OO => {
                  FO(OO.target.value)
                },
                onKeyDown: OO => {
                  OO.stopPropagation()
                }
              }), (0, Ve.jsx)("button", {
                type: "button",
                className: "Baf2TermResort",
                "aria-label": eO("buildAFactory2Game:terminalResort"),
                title: eO("buildAFactory2Game:terminalResort"),
                onClick: () => {
                  KO.resort()
                },
                children: "\u21c5"
              })]
            }), EO && (0, Ve.jsxs)("div", {
              className: "Baf2TermRecents",
              children: [(0, Ve.jsx)("span", {
                children: eO(fM.recent)
              }), NO.map((OO => (0, Ve.jsx)(EM, {
                item: OO,
                name: dO(OO),
                amount: KO.amount(OO),
                selected: jK === OO,
                small: !0,
                onPick: () => {
                  wO(OO)
                }
              }, OO)))]
            }), (0, Ve.jsx)("div", {
              className: "Baf2TermTiles",
              children: gK.length > 0 ? gK.map((OO => (0, Ve.jsx)(EM, {
                item: OO,
                name: dO(OO),
                amount: KO.amount(OO),
                selected: jK === OO,
                onPick: () => {
                  wO(OO)
                }
              }, OO))) : (0, Ve.jsx)("p", {
                className: "Baf2TermEmpty",
                children: rK
              })
            }), (0, Ve.jsxs)("div", {
              className: "Baf2TermActions",
              children: [(0, Ve.jsx)("span", {
                className: "Baf2TermPicked",
                children: TO ? (0, Ve.jsxs)(Ve.Fragment, {
                  children: [null !== jK && YO > 0 ? dO(jK) : eO("buildAFactory2Game:terminalVisiting"), (0, Ve.jsx)("small", {
                    children: eO("buildAFactory2Game:terminalVisitorNote")
                  })]
                }) : null !== jK && YO > 0 ? (0, Ve.jsxs)(Ve.Fragment, {
                  children: [dO(jK), (0, Ve.jsx)("small", {
                    children: eO("buildAFactory2Game:terminalStored", {
                      amount: YO.toLocaleString()
                    })
                  })]
                }) : eO("buildAFactory2Game:terminalPick")
              }), !TO && (0, Ve.jsxs)(Ve.Fragment, {
                children: [(0, Ve.jsx)(av.d, {
                  className: "Baf2TermTake",
                  disabled: 0 === YO,
                  onClick: () => {
                    iK("one")
                  },
                  children: eO("buildAFactory2Game:terminalTakeOne")
                }), (0, Ve.jsx)(av.d, {
                  className: "Baf2TermTake",
                  disabled: 0 === YO,
                  onClick: () => {
                    iK("stack")
                  },
                  children: eO("buildAFactory2Game:terminalTakeStack", {
                    amount: String(99)
                  })
                }), (0, Ve.jsx)(av.m, {
                  className: "Baf2TermTake",
                  disabled: 0 === YO,
                  onClick: () => {
                    iK("fill")
                  },
                  children: eO("buildAFactory2Game:terminalFill")
                })]
              })]
            })]
          })]
        })
      })
    }

    function YM(OO) {
      let {
        kind: KO,
        icon: pO,
        label: XO,
        number: bK,
        preview: eO,
        note: lO,
        tone: vK = null,
        share: CO,
        onExplain: hO
      } = OO;
      return (0, Ve.jsxs)("button", {
        type: "button",
        className: Fb()("NxLane", KO, {
          Warn: "warn" === vK,
          Danger: "danger" === vK
        }),
        onClick: hO,
        children: [(0, Ve.jsxs)("span", {
          className: "NxLaneHead",
          children: [pO, (0, Ve.jsx)("span", {
            className: "NxLaneLabel",
            children: XO
          })]
        }), (0, Ve.jsxs)("span", {
          className: "NxLaneNum",
          children: [bK, eO && (0, Ve.jsxs)("small", {
            className: "NxLanePreview",
            children: [" \u2192 ", eO]
          })]
        }), (0, Ve.jsx)("span", {
          className: "NxLaneNote",
          children: lO
        }), void 0 !== CO && (0, Ve.jsx)("i", {
          className: "NxLaneFill",
          style: {
            width: 100 * Math.max(0, Math.min(1, CO)) + "%"
          }
        })]
      })
    }

    function wM(OO) {
      let {
        kind: KO,
        step: pO,
        short: XO,
        planned: bK
      } = OO;
      return (0, Ve.jsx)("i", {
        className: Fb()("NxPipe", KO, `Step${pO}`, {
          Short: XO,
          Planned: bK
        }),
        "aria-hidden": "true"
      })
    }

    function ia(OO) {
      let {
        max: KO,
        bands: pO,
        ticks: XO,
        now: bK,
        settle: eO,
        settleTone: lO,
        onExplain: vK
      } = OO;
      const CO = OO => Math.max(0, Math.min(KO, OO)) / KO * 100 + "%";
      let hO = 0;
      return (0, Ve.jsxs)("button", {
        type: "button",
        className: "NxGauge",
        onClick: vK,
        children: [(0, Ve.jsxs)("span", {
          className: "NxGaugeTrack",
          children: [pO.map((OO => {
            const KO = {
              bottom: CO(hO),
              height: `calc(${CO(OO.upTo)} - ${CO(hO)})`
            };
            return hO = OO.upTo, (0, Ve.jsx)("i", {
              className: Fb()("NxGaugeBand", OO.kind),
              style: KO
            }, OO.kind)
          })), null !== bK && (0, Ve.jsx)("i", {
            className: "NxGaugeNow",
            style: {
              bottom: CO(bK)
            }
          }), void 0 !== eO && null !== eO && (0, Ve.jsx)("i", {
            className: Fb()("NxGaugeSettle", {
              Bad: "bad" === lO
            }),
            style: {
              bottom: CO(eO)
            }
          })]
        }), (0, Ve.jsx)("span", {
          className: "NxGaugeTicks",
          children: XO.map((OO => (0, Ve.jsx)("small", {
            style: {
              bottom: CO(OO)
            },
            children: OO
          }, OO)))
        })]
      })
    }

    function ra(OO) {
      const [KO, pO] = (0, XO.useState)(null), [bK, eO] = (0, XO.useState)((() => {
        try {
          return null === window.localStorage.getItem(OO)
        } catch {
          return !1
        }
      })), lO = (0, XO.useRef)(null);
      (0, XO.useEffect)((() => () => {
        null !== lO.current && clearTimeout(lO.current)
      }), []);
      const vK = (0, XO.useCallback)((KO => {
          pO(KO), eO(!1);
          try {
            window.localStorage.setItem(OO, "1")
          } catch {}
          null !== lO.current && clearTimeout(lO.current), lO.current = setTimeout((() => {
            lO.current = null, pO(null)
          }), 5e3)
        }), [OO]),
        CO = (0, XO.useCallback)(((KO, pO) => {
          const XO = `${OO}:${KO}`;
          try {
            if (null !== window.localStorage.getItem(XO)) return;
            window.localStorage.setItem(XO, "1")
          } catch {
            return
          }
          vK(pO)
        }), [vK, OO]);
      return {
        explained: KO,
        hinting: bK,
        explain: vK,
        explainOnce: CO
      }
    }

    function PM(OO) {
      let {
        text: KO,
        tone: pO,
        explained: XO
      } = OO;
      return (0, Ve.jsxs)("p", {
        className: Fb()("NxStatus", null === XO ? pO : "Explain"),
        "aria-live": "polite",
        children: [null !== XO && (0, Ve.jsx)("b", {
          className: "NxStatusWhy",
          children: "?"
        }), null !== XO && void 0 !== XO ? XO : KO]
      })
    }
    const ma = [null, "Fuel Rod", "Graphite Block", "Coolant Channel"];

    function sM(OO, KO) {
      const pO = Number(OO[KO]);
      return 1 === pO || 2 === pO || 3 === pO ? pO : 0
    }

    function HM(OO) {
      return !!ah("reactor", OO.baf2RxNeed) || void 0 !== OO.baf2RxLayout && OO.baf2RxNeed.some((OO => {
        let [KO, pO] = OO;
        return pO > 0 && ma.includes(KO)
      }))
    }
    const RM = "buildAFactory2Game:";

    function SM(OO) {
      let {
        status: KO,
        store: pO,
        busy: XO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)();
      return function(OO) {
        return 0 !== (OO.baf2RxFlags & CK) && (!OO.baf2RxFormed || void 0 !== OO.baf2RxLayout)
      }(KO) ? (0, Ve.jsx)(av.m, {
        disabled: !HM(KO) || XO,
        onClick: () => {
          pO.tap("fill", (() => {
            pO.send("fill")
          }))
        },
        children: bK(void 0 !== KO.baf2RxLayout ? `${RM}rxFillLayout` : `${RM}rxFill`)
      }) : null
    }

    function JM(OO) {
      let {
        status: KO,
        store: pO,
        readOnly: bK,
        bare: eO = !1
      } = OO;
      const {
        t: lO
      } = (0, ze.D)(), vK = KO.baf2RxLayout, [CO, hO, DO] = KO.baf2RxDims, MO = (0, XO.useMemo)((() => {
        if (void 0 === vK) return 0;
        const OO = Uint8Array.from(vK, ((OO, KO) => sM(vK, KO)));
        return Bv([CO - 2, hO - 2, DO - 2], OO).max
      }), [vK, CO, hO, DO]);
      return void 0 === vK ? null : (0, Ve.jsxs)("div", {
        className: "Baf2RxRow",
        children: [!eO && (0, Ve.jsx)("span", {
          className: "Baf2RxHint",
          children: lO(`${RM}rxLayoutLine`, {
            amount: AC(MO)
          })
        }), !bK && (0, Ve.jsx)(av.d, {
          onClick: () => {
            pO.send("layout", 0)
          },
          children: lO(`${RM}rxLayoutHide`)
        })]
      })
    }
    const ca = "buildAFactory2Game:",
      BM = {
        off: {
          colour: "#6b717c",
          rows: ["........", "........", ".oo..oo.", "........", "........", "..oooo..", "........", "........"]
        },
        calm: {
          colour: "#5aa9ff",
          rows: ["........", ".oo..oo.", ".oo..oo.", "........", ".o....o.", "..oooo..", "........", "........"]
        },
        warm: {
          colour: "#ffb020",
          rows: ["........", ".oo..oo.", ".oo..oo.", "........", "........", ".oooooo.", "........", "........"]
        },
        hot: {
          colour: "#ff7a2b",
          rows: [".......w", "oo....ow", ".oo..oo.", "........", "..oooo..", ".o....o.", "........", "........"]
        },
        alarm: {
          colour: "#ff3b30",
          rows: ["o......o", ".oo..oo.", ".oo..oo.", "........", "..oooo..", "..o..o..", "..oooo..", "........"]
        }
      };

    function ZM(OO) {
      let {
        id: KO,
        title: pO,
        body: XO,
        bodyParams: bK,
        yes: eO,
        cancel: lO,
        confirm: vK
      } = OO;
      const {
        t: CO
      } = (0, ze.D)();
      return (0, Ve.jsxs)("div", {
        className: "Baf2RxConfirm",
        role: "alertdialog",
        "aria-labelledby": KO,
        children: [(0, Ve.jsx)("h3", {
          id: KO,
          children: CO(pO)
        }), (0, Ve.jsx)("p", {
          children: CO(XO, bK)
        }), (0, Ve.jsxs)("div", {
          className: "Baf2RxActions",
          children: [(0, Ve.jsx)(av.e, {
            onClick: lO,
            children: CO(`${ca}rxCancel`)
          }), (0, Ve.jsx)(av.I, {
            onClick: vK,
            children: CO(eO)
          })]
        })]
      })
    }

    function GM(OO) {
      const [KO, pO] = (0, XO.useState)((() => OO.get()));
      return (0, XO.useEffect)((() => (pO(OO.get()), OO.subscribe((() => {
        pO(OO.get())
      })))), [OO]), KO
    }

    function qa(OO) {
      let {
        kind: KO,
        cap: pO,
        busy: bK = !1,
        whyNot: eO = null,
        apart: lO
      } = OO;
      const {
        t: vK
      } = (0, ze.D)(), [CO, hO] = (0, XO.useState)(!1), DO = null !== eO, MO = (0, XO.useRef)(null);
      if ((0, XO.useEffect)((() => {
          DO && hO(!1)
        }), [DO]), (0, XO.useLayoutEffect)((() => {
          var OO;
          const KO = null === (OO = MO.current) || void 0 === OO ? void 0 : OO.firstElementChild;
          DO ? null === KO || void 0 === KO || KO.setAttribute("aria-disabled", "true") : bK || null === KO || void 0 === KO || KO.removeAttribute("aria-disabled")
        })), !CO || DO) return (0, Ve.jsx)("span", {
        ref: MO,
        className: "Baf2RxApartWrap",
        children: (0, Ve.jsx)(av.e, {
          disabled: bK,
          className: Fb()({
            Baf2RxNotYet: DO
          }),
          onClick: () => {
            eO ? eO() : hO(!0)
          },
          children: vK(`${ca}rxApart`)
        })
      });
      const aK = "battery" === KO,
        oO = void 0 === pO ? `${ca}batApartConfirmBodyPlan` : `${ca}batApartConfirmBody`;
      return (0, Ve.jsx)(ZM, {
        id: `baf2ApartTitle_${KO}`,
        title: aK ? `${ca}batApartConfirmTitle` : `${ca}rxApartConfirmTitle`,
        body: aK ? oO : `${ca}rxApartConfirmBody`,
        bodyParams: void 0 === pO ? void 0 : {
          cap: pO
        },
        yes: `${ca}rxApart`,
        cancel: () => {
          hO(!1)
        },
        confirm: () => {
          hO(!1), lO()
        }
      })
    }

    function xa(OO) {
      let {
        mood: KO,
        big: pO
      } = OO;
      const XO = BM[KO],
        bK = [];
      return XO.rows.forEach(((OO, KO) => {
        for (let pO = 0; pO < OO.length; pO++) "." !== OO[pO] && bK.push((0, Ve.jsx)("rect", {
          x: pO + 1,
          y: KO + 1,
          width: 1,
          height: 1,
          fill: "w" === OO[pO] ? "#8fd3ff" : XO.colour
        }, `${pO},${KO}`))
      })), (0, Ve.jsxs)("svg", {
        className: Fb()("Baf2RxFace", {
          Big: pO,
          Alarm: "alarm" === KO
        }),
        viewBox: "0 0 10 10",
        shapeRendering: "crispEdges",
        "aria-hidden": "true",
        children: [(0, Ve.jsx)("rect", {
          width: 10,
          height: 10,
          fill: "#2f333a"
        }), (0, Ve.jsx)("rect", {
          x: 1,
          y: 1,
          width: 8,
          height: 8,
          fill: "#14161b"
        }), bK]
      })
    }

    function nM(OO) {
      return Ce(OO, "+").replace("+", "")
    }

    function WM(OO) {
      let {
        kind: KO,
        dims: pO,
        cap: XO,
        disabled: bK,
        compact: eO,
        resize: lO
      } = OO;
      const {
        t: vK
      } = (0, ze.D)(), {
        min: CO,
        max: hO
      } = Yp(KO), DO = Math.min(XO, hO), MO = [`${ca}rxWide`, `${ca}rxTall`, `${ca}rxDeep`], aK = {
        w: String(pO[0]),
        h: String(pO[1]),
        d: String(pO[2]),
        blocks: String(zh(KO, pO))
      };
      return (0, Ve.jsxs)("div", {
        className: "Baf2RxSteppersWrap",
        children: [(0, Ve.jsx)("div", {
          className: "Baf2RxSteppers",
          children: pO.map(((OO, KO) => {
            const eO = XO => {
                const bK = [pO[0], pO[1], pO[2]];
                bK[KO] = OO + XO, lO(bK)
              },
              aK = OO >= DO;
            return (0, Ve.jsxs)("div", {
              className: "Baf2RxStepper",
              children: [(0, Ve.jsx)("button", {
                type: "button",
                "aria-label": vK(`${ca}rxSmaller`),
                disabled: bK || OO <= CO,
                onClick: () => {
                  eO(-1)
                },
                children: "\u2212"
              }), (0, Ve.jsxs)("div", {
                className: "Baf2RxStepperValue",
                children: [OO, (0, Ve.jsx)("small", {
                  children: vK(MO[KO])
                })]
              }), (0, Ve.jsx)("button", {
                type: "button",
                "aria-label": vK(`${ca}rxBigger`),
                disabled: bK || aK,
                onClick: () => {
                  eO(1)
                },
                children: aK && XO < hO ? "\ud83d\udd12" : "+"
              })]
            }, MO[KO])
          }))
        }), !eO && (0, Ve.jsx)("span", {
          className: "Baf2RxHint",
          children: "reactor" === KO ? vK(`${ca}rxSizeLine`, {
            ...aK,
            water: String(QC(pO))
          }) : vK(`${ca}batSizeLine`, aK)
        })]
      })
    }

    function ta(OO) {
      let {
        on: KO,
        label: pO,
        disabled: XO,
        locked: bK,
        pending: eO,
        toggle: lO
      } = OO;
      return (0, Ve.jsxs)("button", {
        type: "button",
        role: "switch",
        "aria-checked": KO,
        disabled: XO,
        "aria-disabled": bK || void 0,
        className: Fb()("Baf2RxSwitch", {
          On: KO,
          Locked: bK,
          Pending: eO
        }),
        onClick: lO,
        children: [(0, Ve.jsx)("span", {
          className: "Baf2RxKnob"
        }), pO]
      })
    }
    const ka = "buildAFactory2Game:",
      UM = .95;

    function Oa(OO, KO) {
      return 0 !== (OO.baf2RxFlags & KO)
    }

    function Ka(OO) {
      return "cryo" === OO ? kK.l : kK.n
    }

    function pa(OO) {
      var KO, pO, XO, bK, eO, lO, vK, CO, hO;
      return OO.baf2RxCryo ? {
        Lp: "cryo",
        usePerS: null !== (bK = OO.baf2RxCryoUse) && void 0 !== bK ? bK : 0,
        needPerS: null !== (eO = OO.baf2RxCryoNeed) && void 0 !== eO ? eO : 0,
        inPerS: null !== (lO = OO.baf2RxCryoIn) && void 0 !== lO ? lO : 0,
        stored: null !== (vK = OO.baf2RxCryoStored) && void 0 !== vK ? vK : 0,
        makersShort: null !== (CO = OO.baf2RxMixersShort) && void 0 !== CO ? CO : 0,
        waterBeside: null !== (hO = OO.baf2RxWaterUse) && void 0 !== hO ? hO : 0,
        pct: OO.baf2RxWater
      } : {
        Lp: "water",
        usePerS: null !== (KO = OO.baf2RxWaterUse) && void 0 !== KO ? KO : 0,
        needPerS: null !== (pO = OO.baf2RxWaterNeed) && void 0 !== pO ? pO : 0,
        inPerS: OO.baf2RxWaterIn,
        stored: OO.baf2RxWaterStored,
        makersShort: null !== (XO = OO.baf2RxCondensersShort) && void 0 !== XO ? XO : 0,
        waterBeside: 0,
        pct: OO.baf2RxWater
      }
    }

    function Xa(OO) {
      const KO = "running" === OO.baf2RxState || "idle" === OO.baf2RxState;
      return OO.baf2RxFormed && OO.baf2RxTarget !== OO.baf2RxThrottle && KO ? bo(OO, OO.baf2RxTarget) : null
    }

    function bo(OO, KO) {
      const [pO, XO, bK, , , , eO, , lO] = OO.baf2RxStats, vK = Oa(OO, lK), CO = pa(OO), hO = CO.pct / 100, {
        gen: DO,
        out: MO,
        load: aK
      } = function(OO, KO, pO, XO) {
        const bK = pO ? mC : 1,
          eO = Math.min(OO.fuelHeat * bK * Math.max(0, Math.min(1, KO)), OO.size * bK);
        return {
          gen: eO,
          out: eO,
          load: KC(eO, OO.cooling, XO)
        }
      }({
        fuelHeat: pO,
        cooling: XO,
        size: bK
      }, KO / 100, vK, hO), oO = XC(eO || cC(...OO.baf2RxDims)), FO = OO.baf2RxHeat, VO = Math.abs(aK - FO), LO = function(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : kK.n;
        const eO = pO ? mC : 1,
          lO = Math.min(OO.fuelHeat * eO * KO / 100, OO.size * eO),
          vK = lO,
          CO = OO.fuelHeat * eO,
          hO = OO.cooling * OC(XO.pct / 100),
          DO = CO > 0 && hO < OO.size * eO ? Math.floor(100 * hO / CO) : 100,
          MO = lO * bK - XO.inPerS;
        return {
          out: vK,
          hotAbove: DO >= 100 ? null : Math.max(0, DO),
          waterSecs: XO.pct >= 100 && MO > 1e-6 ? Math.max(0, XO.stored) / MO : null
        }
      }({
        fuelHeat: pO,
        cooling: XO,
        size: bK
      }, KO, vK, {
        pct: CO.pct,
        inPerS: CO.inPerS,
        stored: CO.stored
      }, Ka(CO.Lp));
      return {
        pct: KO,
        out: MO,
        coolPerS: DO * Ka(CO.Lp),
        pelletsPerMin: lO > 0 ? MO / lO * 60 : 0,
        settle: aK,
        settleS: VO > 2 ? oO * Math.log(VO / 2) : 0,
        overheatS: aK > 100 && FO < 100 ? oO * Math.log((aK - FO) / (aK - 100)) : null,
        hotAbove: LO.hotAbove,
        coolantSecs: LO.waterSecs
      }
    }

    function ea(OO) {
      return OO.baf2RxThrottle <= 0 && "running" !== OO.baf2RxState ? 0 : bo(OO, OO.baf2RxTarget).pelletsPerMin / 60
    }

    function la(OO, KO) {
      if (OO <= 0 || KO <= 0) return 0;
      const pO = OO / KO;
      return pO < .25 ? 1 : pO < .5 ? 2 : pO < .8 ? 3 : 4
    }

    function vo(OO, KO) {
      const pO = {};
      for (const [XO, bK] of Object.entries(KO.params)) pO[XO] = "time" === XO ? Me(OO, bK) : "amount" === XO ? AC(bK) : String(Math.round(bK));
      return OO(KO.key, pO)
    }

    function Ca(OO, KO) {
      return {
        key: `${ka}${OO}`,
        params: arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
        tone: KO
      }
    }

    function ha(OO) {
      var KO;
      const pO = Oa(OO, lK),
        XO = "running" === OO.baf2RxState,
        bK = vh(OO),
        eO = OO.baf2RxHeat;
      var lO;
      if (XO && eO > rC) return {
        key: null !== (lO = bK.fix) && void 0 !== lO ? lO : `${ka}rxFix_tooHot`,
        params: {},
        tone: "bad"
      };
      const vK = XO ? bo(OO, OO.baf2RxTarget).coolantSecs : null,
        CO = "cryo" === pa(OO).Lp;
      if (null !== vK && vK >= 1 && vK <= 30) return Ca(CO ? "rxWarnCryo" : "rxWarnWater", "bad");
      const hO = Sv(cC(...OO.baf2RxDims)).waste,
        DO = XO ? oC(OO, hO, ea(OO)).fullInS : null;
      if (null !== DO && DO <= 120 && OO.baf2RxWaste >= .5 * hO) return Ca("rxWarnWaste", "warn");
      if (null !== vK && vK >= 1) return Ca(CO ? "rxThrottleCryoOut" : "rxThrottleWaterOut", "warn", {
        time: vK
      });
      const MO = "noWater" === OO.baf2RxState && eO > rC;
      if (OO.baf2RxDamage >= 1 && !MO) return Ca("rxDamagedHeals", "warn", {
        pct: OO.baf2RxDamage
      });
      if (OO.baf2RxCryoCut) return Ca("rxFix_cryoCut", "warn");
      const aK = pa(OO);
      if ("noWater" === OO.baf2RxState && "cryo" === aK.Lp) return Ca("noWater" === OO.baf2RxCryoStarved ? "rxFix_cryoLowWater" : "rxFix_noCryo", "warn");
      const oO = bK.fix === `${ka}rxFix_scramCool` || "idle" === OO.baf2RxState && OO.baf2RxTarget <= 0;
      if (oO && OO.baf2RxFuel <= 0) return Ca("rxFix_noFuel", "warn");
      if (oO && OO.baf2RxWaterIn <= 0 && (null !== (KO = OO.baf2RxCryoIn) && void 0 !== KO ? KO : 0) <= 0) return Ca("rxFix_noWater", "warn");
      const FO = bK.fix === `${ka}rxFix_scramCool` ? hC(OO) : null;
      if (null !== FO) return {
        key: FO.key,
        params: {
          amount: FO.amount
        },
        tone: "info"
      };
      if ("running" !== OO.baf2RxState && "idle" !== OO.baf2RxState && null !== bK.fix) return {
        key: bK.fix,
        params: {},
        tone: "scram" === OO.baf2RxState ? "info" : MO ? "bad" : "warn"
      };
      var VO;
      if ("idle" === OO.baf2RxState && OO.baf2RxTarget <= 0) return {
        key: null !== (VO = bK.fix) && void 0 !== VO ? VO : `${ka}rxFix_idle`,
        params: {},
        tone: "info"
      };
      const LO = OO.baf2RxCryoStarved;
      if ("cryo" === aK.Lp && LO && aK.needPerS > 0 && aK.usePerS < UM * aK.needPerS) return Ca("noWater" === LO ? "rxFix_cryoLowWater" : "rxFix_cryoLow", "warn");
      const QO = "cryo" === aK.Lp,
        zK = aK.needPerS > 0 && aK.usePerS < UM * aK.needPerS;
      if (QO ? zK || aK.makersShort > 0 && aK.pct < 100 : aK.pct < 100) {
        const KO = QO && zK ? Math.floor(100 * aK.usePerS / aK.needPerS) : Math.min(100, aK.pct);
        if (aK.makersShort > 0) {
          return Ca(`${QO?"rxCryoShortLine":"rxWaterShortLine"}${1===aK.makersShort?"One":""}${!QO&&OO.baf2RxCryoOpen?"OrCryo":""}`, "warn", {
            pct: KO,
            count: aK.makersShort
          })
        }
        return Ca(QO ? "rxCryoShortPipe" : "rxWaterShortPipe", "warn", {
          pct: KO
        })
      }
      const AO = function(OO) {
        const [KO, pO, XO] = OO.baf2RxStats, bK = pa(OO), eO = pC({
          fuelHeat: KO,
          cooling: pO,
          size: XO
        }, "cryo" === bK.Lp ? kK.f : 1, !0);
        return Math.max(0, eO * Ka(bK.Lp) - bK.inPerS)
      }(OO);
      if (pO && AO > 0) return Ca("cryo" === aK.Lp ? "rxOdShortCryo" : "rxOdShortWater", "warn", {
        rate: Math.ceil(AO)
      });
      if (eO >= kC) return Ca("rxHotLine", "warn");
      const fO = bo(OO, OO.baf2RxTarget);
      var dO;
      if (null !== fO.overheatS) return Ca("rxWillOverheat", "bad", {
        pct: OO.baf2RxTarget,
        time: fO.overheatS,
        safe: null !== (dO = fO.hotAbove) && void 0 !== dO ? dO : 100
      });
      if (Math.abs(fO.settle - eO) >= 3) return Ca("rxSettling", "info", {
        pct: OO.baf2RxTarget,
        heat: Math.round(fO.settle),
        time: fO.settleS
      });
      const TO = hC(OO);
      if (null !== TO) return {
        key: TO.key,
        params: {
          amount: TO.amount
        },
        tone: "info"
      };
      const NO = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        return null !== KO && ("running" !== KO || arguments.length > 2 && void 0 !== arguments[2] && !arguments[2] || arguments.length > 3 && void 0 !== arguments[3] && arguments[3]) ? null : 0 === OO.rods ? `${bh}rxLimitNoRods` : `${bh}rxLimit_${tC(OO)}`
      }({
        rods: OO.baf2RxStats[3],
        ...CC(OO)
      }, OO.baf2RxState, OO.baf2RxOut >= UM * OO.baf2RxMaxNow, !1);
      if (NO === `${ka}rxLimit_size`) {
        const [KO, , pO, XO] = OO.baf2RxStats, bK = XO > 0 && KO > 0 ? Math.ceil(pO / (KO / XO) - 1e-9) : XO, eO = OO.baf2RxDims.every((OO => OO >= Yp("reactor").max));
        if (bK < XO) return Ca(eO ? "rxLimitSizeRodsMax" : "rxLimitSizeRods", "info", {
          rods: bK,
          have: XO
        });
        if (eO) return Ca("rxLimit_sizeMax", "info")
      }
      return null !== NO ? {
        key: NO,
        params: {},
        tone: "info"
      } : Ca("rxSteady", "ok", {
        pct: OO.baf2RxTarget
      })
    }

    function Da(OO) {
      var KO;
      if (OO.melted) return Ca("rxMeltedBody", "bad");
      if (-1 === OO.bad) return Ca("rxFix_noRoom", "warn");
      if (OO.bad > 0) return Ca(1 === OO.bad ? "rxBadOne" : "rxBad", "warn", {
        count: OO.bad
      });
      if (OO.left > 0) {
        const KO = 1 === OO.left ? "One" : "";
        return Ca(OO.canFill ? `rxPlanLeft${KO}` : `rxPlanLeftNoFill${KO}`, "info", {
          count: OO.left
        })
      }
      if (0 === OO.rods) return Ca("rxLimitNoRods", "warn");
      const pO = null !== (KO = OO.idle) && void 0 !== KO ? KO : 0;
      return pO > 0 ? Ca(1 === pO ? "rxIdleChannelOne" : "rxIdleChannels", "warn", {
        count: pO
      }) : Ca("rxPlanReady", "ok")
    }

    function Ma(OO) {
      return Math.floor(Math.max(0, OO[1] - 1) / 2)
    }

    function ao(OO) {
      if (OO >= Gv && OO < qC) {
        const KO = OO - Gv;
        return {
          key: 0 === KO ? `${ka}rxWhy_rodAlone` : 1 === KO ? `${ka}rxWhy_rodOne` : `${ka}rxWhy_rod`,
          params: {
            count: String(KO),
            heat: String(yC * (1 + gC * KO))
          }
        }
      }
      return OO === qC ? {
        key: `${ka}rxWhy_channel`,
        params: {
          amount: String(Ev)
        }
      } : OO === xC ? {
        key: `${ka}rxWhy_deadChannel`,
        params: {}
      } : OO === nv ? {
        key: `${ka}rxWhy_graphite`,
        params: {}
      } : {
        key: `${ka}rxWhy_core`,
        params: {}
      }
    }
    const oa = "buildAFactory2Game:";

    function Fa(OO, KO) {
      return 0 !== (OO.baf2RxFlags & KO)
    }

    function Va(OO) {
      let {
        status: KO,
        pending: pO,
        store: XO,
        explain: bK
      } = OO;
      const {
        t: eO
      } = (0, ze.D)(), lO = Fa(KO, eK), vK = KO.baf2RxTarget, CO = KO.baf2RxThrottle, hO = function(OO) {
        return {
          press: () => {
            OO.throttlePress()
          },
          drag: KO => {
            OO.throttleDrag(KO)
          },
          release: () => {
            OO.throttleRelease()
          }
        }
      }(XO), DO = null === (MO = bo(KO, 100).hotAbove) ? {
        amber: 100,
        red: 100
      } : {
        amber: Math.max(0, MO - 10),
        red: MO
      };
      var MO;
      return (0, Ve.jsxs)("div", {
        className: Fb()("Baf2RxThrottle", {
          Off: lO
        }),
        onClick: () => {
          lO && bK(`${oa}rxWhy_startFirst`)
        },
        children: [(0, Ve.jsx)("span", {
          className: "HideNarrow",
          children: eO(`${oa}rxThrottle`)
        }), (0, Ve.jsxs)("div", {
          className: "Baf2RxSlider",
          children: [(0, Ve.jsx)("input", {
            type: "range",
            min: 0,
            max: 100,
            step: 1,
            value: vK,
            disabled: lO,
            style: lO ? {
              pointerEvents: "none"
            } : void 0,
            "aria-label": eO(`${oa}rxThrottle`),
            onPointerDown: () => {
              hO.press();
              const OO = () => {
                window.removeEventListener("pointerup", OO), window.removeEventListener("pointercancel", OO), hO.release()
              };
              window.addEventListener("pointerup", OO), window.addEventListener("pointercancel", OO)
            },
            onKeyUp: hO.release,
            onChange: OO => {
              hO.drag(Number(OO.target.value))
            }
          }), (0, Ve.jsx)("i", {
            className: "Baf2RxZones",
            style: {
              background: `linear-gradient(90deg, #4cc46a 0 ${DO.amber}%, #ffb020 ${DO.amber}% ${DO.red}%, #ff3b30 ${DO.red}%)`
            },
            "aria-hidden": "true"
          }), (0, Ve.jsx)("i", {
            className: "Baf2RxRodTick",
            style: {
              left: `calc(${CO}% + ${8*(1-CO/50)}px)`
            },
            "aria-hidden": "true"
          })]
        }), (0, Ve.jsxs)("b", {
          children: [`${vK}%`, (0, Ve.jsx)("i", {
            className: Fb()("Baf2RxPendingDot", {
              On: pO
            }),
            "aria-hidden": "true"
          })]
        })]
      })
    }

    function La(OO) {
      let {
        status: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)(), XO = bo(KO, KO.baf2RxTarget), bK = pa(KO).Lp, eO = pO("cryo" === bK ? `${oa}rxRateCryo` : `${oa}rxRateWater`, {
        rate: nM(XO.coolPerS)
      }), lO = pO(`${oa}rxChain`, {
        pct: String(KO.baf2RxTarget),
        out: AC(XO.out),
        heat: String(Math.round(XO.settle)),
        coolant: eO
      }), vK = null !== XO.coolantSecs ? XO.coolantSecs >= 1 ? pO("cryo" === bK ? `${oa}rxThrottleCryoOut` : `${oa}rxThrottleWaterOut`, {
        time: Me(pO, XO.coolantSecs)
      }) : pO("cryo" === bK ? `${oa}rxThrottleCryoDry` : `${oa}rxThrottleWaterDry`) : null;
      return (0, Ve.jsxs)("p", {
        className: "Baf2RxChain",
        children: [lO, null !== vK ? (0, Ve.jsxs)("span", {
          className: "Baf2RxChainWarn",
          children: [" \xb7 ", vK]
        }) : (0, Ve.jsxs)("span", {
          children: [" \xb7 ", pO(`${oa}rxChainPellets`, {
            amount: fC(XO.pelletsPerMin)
          })]
        })]
      })
    }

    function Qa(OO) {
      let {
        view: KO,
        store: pO,
        explain: bK,
        explainOnce: eO
      } = OO;
      const {
        t: lO
      } = (0, ze.D)(), {
        status: vK
      } = KO, [CO, hO] = (0, XO.useState)(!1), DO = Fa(vK, eK), aK = Fa(vK, lK), oO = !Fa(vK, hK), FO = vK.baf2RxHeat > 100;
      return (0, Ve.jsxs)(Ve.Fragment, {
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2RxCtl",
          children: [(0, Ve.jsx)(Va, {
            status: vK,
            pending: KO.throttlePending,
            store: pO,
            explain: bK
          }), (0, Ve.jsx)(ta, {
            on: aK,
            label: aK ? lO(`${oa}rxOdLeft`, {
              time: Me(lO, vK.baf2RxOdLeft)
            }) : lO(`${oa}rxOverdrive`),
            locked: oO,
            pending: 0 !== (KO.pendingFlags & lK),
            toggle: () => {
              oO ? bK(`${oa}rxOverdriveTier`, {
                amount: String(MO(13))
              }) : aK ? pO.setFlag(lK, !1) : KO.odConfirmed ? pO.setFlag(lK, !0) : hO(!0)
            }
          }), DO || KO.startGuard ? (0, Ve.jsx)(av.s, {
            disabled: KO.busy.has("start") || KO.startGuard,
            onClick: () => {
              pO.tap("start", (() => {
                pO.setFlag(eK, !1)
              }))
            },
            children: lO(KO.startGuard ? `${oa}rxStarting` : `${oa}rxStart`)
          }) : (0, Ve.jsx)("span", {
            className: Fb()("Baf2RxScram", {
              Pulse: FO
            }),
            children: (0, Ve.jsx)(av.I, {
              onClick: () => {
                pO.shutDown()
              },
              children: lO(`${oa}rxScram`)
            })
          })]
        }), (0, Ve.jsx)(La, {
          status: vK
        }), CO && (0, Ve.jsx)(ZM, {
          id: "baf2RxOdTitle",
          title: `${oa}rxOdConfirmTitle`,
          body: `${oa}rxOdConfirmBody`,
          yes: `${oa}rxOdConfirm`,
          cancel: () => {
            hO(!1)
          },
          confirm: () => {
            hO(!1), pO.tap("odConfirm", (() => {
              pO.confirmOverdrive(), pO.setFlag(lK, !0)
            })), eO(`${oa}rxWhy_overdrive`)
          }
        })]
      })
    }

    function zo(OO) {
      let {
        view: KO,
        store: pO,
        keepSize: XO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)(), {
        status: eO
      } = KO;
      return (0, Ve.jsxs)("div", {
        className: "Baf2RxCtl Baf2RxBuild",
        children: [(0, Ve.jsx)(WM, {
          kind: "reactor",
          dims: KO.dims,
          cap: eO.baf2RxSizeCap,
          disabled: !1,
          compact: !0,
          resize: OO => {
            pO.resize(OO)
          }
        }), XO ? (0, Ve.jsx)(av.e, {
          onClick: XO,
          children: bK(`${oa}rxKeepSize`)
        }) : (0, Ve.jsxs)(Ve.Fragment, {
          children: [(0, Ve.jsx)(ta, {
            on: KO.guide,
            label: bK(`${oa}rxGuide`),
            toggle: () => {
              pO.toggleGuide()
            }
          }), Fa(eO, MK) && (0, Ve.jsx)(ta, {
            on: KO.starter,
            label: bK(`${oa}rxStarter`),
            toggle: () => {
              pO.toggleStarter()
            }
          }), (0, Ve.jsx)(SM, {
            status: eO,
            store: pO,
            busy: KO.busy.has("fill")
          })]
        })]
      })
    }

    function Aa(OO) {
      let {
        need: KO,
        kind: pO = "reactor",
        explain: XO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)(), eO = KO.length <= 3, lO = KO.reduce(((OO, KO) => {
        let [, pO] = KO;
        return OO + pO
      }), 0);
      return (0, Ve.jsxs)("div", {
        className: Fb()("Baf2RxParts", {
          Compact: !eO
        }),
        onClick: () => {
          XO("battery" === pO ? `${oa}batWhy_store` : `${oa}rxShellHint`)
        },
        children: [lO > 0 && (0, Ve.jsx)("span", {
          className: "Baf2RxPartsSize",
          children: 1 === lO ? bK(`${oa}rxBlocksOne`) : bK(`${oa}rxBlocks`, {
            blocks: String(lO)
          })
        }), 0 === KO.length ? (0, Ve.jsx)("span", {
          className: "Baf2RxShopHave Ok",
          children: bK("battery" === pO ? `${oa}batPartsDone` : `${oa}rxShellDone`)
        }) : MC(KO).map((OO => {
          let [KO, pO, XO] = OO;
          const lO = function(OO) {
            const KO = LC[OO];
            if (void 0 === KO) return null;
            const [pO, XO, bK] = FC[KO].colour.map((OO => Math.round(255 * OO)));
            return `rgb(${pO}, ${XO}, ${bK})`
          }(KO);
          return (0, Ve.jsxs)("span", {
            className: "Baf2RxChip",
            title: xe(bK, KO),
            children: [(0, Ve.jsx)("i", {
              className: "Baf2RxShopSwatch",
              style: null === lO ? {
                visibility: "hidden"
              } : {
                background: lO
              },
              title: bK(`${oa}rxShopGhost`)
            }), (0, Ve.jsx)("span", {
              className: "Baf2PanelIcon Baf2RxShopIcon",
              children: (0, Ve.jsx)(fb.b, {
                itemName: KO,
                amount: 0
              })
            }), (0, Ve.jsx)("span", {
              className: "Baf2RxChipName",
              children: eO ? `${pO} ${vK=xe(bK,KO),vK.replace(/^(Reactor|Battery) (?=\S)/,"")}` : pO
            }), XO >= pO ? (0, Ve.jsx)("span", {
              className: "Baf2RxShopHave Ok",
              children: "\u2713"
            }) : (0, Ve.jsx)("span", {
              className: "Baf2RxShopHave Short",
              children: eO ? bK(`${oa}rxShopShort`, {
                count: String(pO - XO)
              }) : "\u2212" + (pO - XO)
            })]
          }, KO);
          var vK
        }))]
      })
    }
    const fa = "buildAFactory2Game:";

    function da(OO) {
      var KO, pO, bK, eO, lO, vK, CO;
      let {
        store: hO,
        close: DO
      } = OO;
      const {
        t: MO
      } = (0, ze.D)(), aK = Yl(), oO = GM(hO), {
        explained: FO,
        explain: VO
      } = ra("baf2RxExplained"), LO = (0, XO.useCallback)(((OO, KO) => {
        VO(MO(OO, KO))
      }), [VO, MO]), QO = null === oO || void 0 === oO ? void 0 : oO.status, zK = !0 === (null === QO || void 0 === QO ? void 0 : QO.baf2BatReadOnly), AO = OO => {
        QO && aK.send(bp(QO.baf2BatAt, OO))
      }, [fO, dO, TO] = null !== (KO = null === oO || void 0 === oO ? void 0 : oO.dims) && void 0 !== KO ? KO : [0, 0, 0], NO = AC(null !== (pO = null === oO || void 0 === oO ? void 0 : oO.YO) && void 0 !== pO ? pO : 0), IO = !0 === (null === QO || void 0 === QO ? void 0 : QO.baf2BatFormed), yK = null !== (bK = null === QO || void 0 === QO ? void 0 : QO.baf2BatStored) && void 0 !== bK ? bK : 0, gK = Math.max(1, null !== (eO = null === QO || void 0 === QO ? void 0 : QO.baf2BatIslandCap) && void 0 !== eO ? eO : 1), uO = Math.min(100, 100 * yK / gK), EO = null === QO || void 0 === QO ? void 0 : QO.baf2BatNetPerS, jK = function(OO, KO, pO) {
        return pO > 0 && KO >= pO ? "full" : void 0 !== OO && OO >= .05 ? "charging" : void 0 !== OO && OO <= -.05 && KO > 0 ? "draining" : "steady"
      }(EO, yK, null !== (lO = null === QO || void 0 === QO ? void 0 : QO.baf2BatIslandCap) && void 0 !== lO ? lO : 0), YO = null !== (vK = null === QO || void 0 === QO ? void 0 : QO.baf2BatMadePerS) && void 0 !== vK ? vK : 0, wO = null !== (CO = null === QO || void 0 === QO ? void 0 : QO.baf2BatUsedPerS) && void 0 !== CO ? CO : 0;
      let iK, rK = {},
        PO = "info";
      if (QO)
        if (IO) "charging" === jK ? (iK = `${fa}batLine_charging`, rK = {
          time: Me(MO, (gK - yK) / Math.max(.05, null !== EO && void 0 !== EO ? EO : 0))
        }, PO = "ok") : "draining" === jK ? (iK = `${fa}batLine_draining`, rK = {
          time: Me(MO, yK / Math.max(.05, -(null !== EO && void 0 !== EO ? EO : 0)))
        }, PO = "warn") : iK = "full" === jK ? `${fa}batLine_full` : yK <= 0 && wO > 0 ? `${fa}batLine_empty` : `${fa}batLine_steady`;
        else {
          var mK;
          const OO = Da({
            left: QO.baf2BatNeed.reduce(((OO, KO) => {
              let [, pO] = KO;
              return OO + pO
            }), 0),
            bad: QO.baf2BatBad,
            rods: 1,
            canFill: !0 === QO.baf2BatCanFill,
            melted: !1
          });
          iK = OO.key, rK = {
            count: String(null !== (mK = OO.params.count) && void 0 !== mK ? mK : 0)
          }, PO = OO.tone
        }
      else iK = `${fa}batLine_steady`;
      const sO = Math.max(YO, wO, 1);
      return (0, Ve.jsx)(Ml.d, {
        close: DO,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay Baf2RxOverlay",
        children: (0, Ve.jsxs)("section", {
          className: "Baf2Panel Baf2RxPanel Baf2BatPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2BatTitle",
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsxs)("div", {
              className: "Baf2RxTitle",
              children: [(0, Ve.jsx)("span", {
                className: "Baf2PanelIcon",
                children: (0, Ve.jsx)(fb.b, {
                  itemName: "Battery Cell",
                  amount: 0
                })
              }), (0, Ve.jsxs)("div", {
                children: [(0, Ve.jsx)("h2", {
                  id: "baf2BatTitle",
                  children: MO(`${fa}batTitle`)
                }), QO && (0, Ve.jsxs)("p", {
                  className: Fb()("Baf2RxSubtitle", {
                    good: IO && "charging" === jK,
                    warn: IO && "draining" === jK
                  }),
                  children: [fO, "\xd7", dO, "\xd7", TO, " \xb7 ", MO(IO ? `${fa}batState_${jK}` : `${fa}rxSubPlanShort`)]
                })]
              })]
            }), (0, Ve.jsxs)("div", {
              className: "Baf2RxHeadActions",
              children: [QO && !zK && (0, Ve.jsx)(qa, {
                kind: "battery",
                cap: IO ? NO : void 0,
                busy: null === oO || void 0 === oO ? void 0 : oO.busy.has("apart"),
                apart: () => {
                  hO.tap("apart", (() => {
                    AO("apart")
                  }))
                }
              }), (0, Ve.jsx)(av.i, {
                onClick: DO
              })]
            })]
          }), oO && QO && (0, Ve.jsxs)("div", {
            className: "Baf2RxBody",
            children: [(0, Ve.jsxs)("div", {
              className: Fb()("Baf2RxFlow Baf2BatFlow", {
                Plan: !IO
              }),
              children: [(0, Ve.jsx)(YM, {
                kind: "Power",
                label: MO(`${fa}batMade`),
                number: IO ? `\u26a1 ${AC(YO)}/s` : "\u2014",
                note: MO(`${fa}batMadeNote`),
                share: IO ? YO / sO : void 0,
                onExplain: () => {
                  LO(`${fa}batWhy_made`)
                }
              }), (0, Ve.jsx)(wM, {
                kind: "Power",
                step: IO ? la(YO, sO) : 0,
                planned: !IO
              }), (0, Ve.jsxs)("div", {
                className: "Baf2RxCore Baf2BatCore",
                onClick: () => {
                  LO(`${fa}batWhy_store`)
                },
                children: [(0, Ve.jsx)(ia, {
                  max: 100,
                  bands: [{
                    upTo: IO ? uO : 0,
                    kind: "Store"
                  }, {
                    upTo: 100,
                    kind: "Empty"
                  }],
                  ticks: [],
                  now: null
                }), (0, Ve.jsxs)("span", {
                  className: "Baf2BatText",
                  children: [(0, Ve.jsx)("b", {
                    className: "Baf2BatStored",
                    children: IO ? MO(`${fa}batStoredOf`, {
                      amount: AC(yK),
                      cap: AC(QO.baf2BatIslandCap)
                    }) : MO(`${fa}batWillHold`, {
                      cap: NO
                    })
                  }), (0, Ve.jsx)("span", {
                    children: MO(`${fa}batAdds`, {
                      cap: NO
                    })
                  }), IO && (0, Ve.jsx)("small", {
                    children: MO(`${fa}batBreakNote`, {
                      cap: NO
                    })
                  })]
                })]
              }), (0, Ve.jsx)(wM, {
                kind: "Power",
                step: IO ? la(wO, sO) : 0,
                planned: !IO
              }), (0, Ve.jsx)(YM, {
                kind: "Power",
                label: MO(`${fa}batUsed`),
                number: IO ? `\u26a1 ${AC(wO)}/s` : "\u2014",
                note: MO(`${fa}batUsedNote`),
                share: IO ? wO / sO : void 0,
                onExplain: () => {
                  LO(`${fa}batWhy_used`)
                }
              })]
            }), (0, Ve.jsx)(PM, {
              text: MO(iK, rK),
              tone: PO,
              explained: FO
            }), zK ? (0, Ve.jsx)("p", {
              className: "Baf2RxHint Baf2RxNotYours",
              children: MO(`${fa}rxNotYours`)
            }) : !IO && (0, Ve.jsxs)(Ve.Fragment, {
              children: [(0, Ve.jsxs)("div", {
                className: "Baf2RxCtl Baf2RxBuild",
                children: [(0, Ve.jsx)(WM, {
                  kind: "battery",
                  dims: oO.dims,
                  cap: QO.baf2BatSizeCap,
                  disabled: !1,
                  compact: !0,
                  resize: OO => {
                    hO.resize(OO)
                  }
                }), (0, Ve.jsx)(ta, {
                  on: oO.guide,
                  label: MO(`${fa}rxGuide`),
                  toggle: () => {
                    hO.toggleGuide()
                  }
                }), QO.baf2BatCanFill && (0, Ve.jsx)(av.m, {
                  disabled: !ah("battery", QO.baf2BatNeed) || oO.busy.has("fill"),
                  onClick: () => {
                    hO.tap("fill", (() => {
                      AO("fill")
                    }))
                  },
                  children: MO(`${fa}rxFill`)
                })]
              }), (0, Ve.jsx)(Aa, {
                need: QO.baf2BatNeed,
                kind: "battery",
                explain: LO
              })]
            })]
          })]
        })
      })
    }
    const Ta = "buildAFactory2Game:",
      Na = ["#4d7a12", "#6a9e1a", "#8cc42a", "#acdf3c", "#d2ff63"];

    function Ia(OO, KO) {
      return OO === Zv ? null : KO ? "#4a4440" : OO < qC ? Na[OO - Gv] : OO === qC ? "#3fd0f0" : OO === xC ? "#2c3e4c" : "#55585e"
    }

    function yo(OO) {
      let {
        inner: KO,
        looks: pO,
        layer: XO,
        setLayer: bK,
        glow: eO,
        melted: lO,
        explain: vK
      } = OO;
      const {
        t: CO
      } = (0, ze.D)(), [hO, DO, MO] = KO, aK = Math.max(0, Math.min(DO - 1, XO)), oO = [];
      for (let VO = 0; VO < MO; VO++)
        for (let OO = 0; OO < hO; OO++) {
          var FO;
          const KO = null !== (FO = pO[(aK * MO + VO) * hO + OO]) && void 0 !== FO ? FO : Zv,
            XO = Ia(KO, lO),
            bK = KO >= Gv && KO < qC;
          oO.push(null === XO ? (0, Ve.jsx)("circle", {
            cx: OO + .5,
            cy: VO + .5,
            r: .08,
            className: "Baf2RxMapAir"
          }, `${OO},${VO}`) : (0, Ve.jsx)("rect", {
            x: OO + .06,
            y: VO + .06,
            width: .88,
            height: .88,
            fill: XO,
            opacity: bK && !lO ? .5 + .5 * eO : 1,
            onClick: OO => {
              OO.stopPropagation();
              const pO = ao(KO);
              vK(pO.key, pO.params)
            }
          }, `${OO},${VO}`))
        }
      return (0, Ve.jsxs)("div", {
        className: "Baf2RxMap",
        children: [(0, Ve.jsx)("svg", {
          className: Fb()("Baf2RxMapGrid", {
            Melted: lO
          }),
          viewBox: `0 0 ${Math.max(1,hO)} ${Math.max(1,MO)}`,
          shapeRendering: "crispEdges",
          role: "img",
          "aria-label": CO(`${Ta}rxWhy_core`),
          onClick: () => {
            vK(`${Ta}rxWhy_core`, {})
          },
          children: oO
        }), DO > 1 && (0, Ve.jsxs)("div", {
          className: "Baf2RxLayers",
          children: [(0, Ve.jsx)("button", {
            type: "button",
            "aria-label": CO(`${Ta}rxLayerDown`),
            disabled: aK <= 0,
            onClick: () => {
              bK(aK - 1)
            },
            children: "\u25bc"
          }), (0, Ve.jsxs)("span", {
            children: [(0, Ve.jsx)("span", {
              className: "HideNarrow",
              children: CO(`${Ta}rxLayer`, {
                n: String(aK + 1),
                of: String(DO)
              })
            }), (0, Ve.jsx)("span", {
              className: "ShowNarrow",
              children: CO(`${Ta}rxLayerShort`, {
                n: String(aK + 1),
                of: String(DO)
              })
            })]
          }), (0, Ve.jsx)("button", {
            type: "button",
            "aria-label": CO(`${Ta}rxLayerUp`),
            disabled: aK >= DO - 1,
            onClick: () => {
              bK(aK + 1)
            },
            children: "\u25b2"
          })]
        })]
      })
    }
    const go = "buildAFactory2Game:",
      ua = [{
        upTo: 50,
        kind: "cold"
      }, {
        upTo: Pv,
        kind: "warm"
      }, {
        upTo: 100,
        kind: "hot"
      }, {
        upTo: lC,
        kind: "red"
      }],
      Ea = [50, Pv, 100];

    function jo(OO) {
      let {
        stats: KO,
        t: pO,
        explain: XO
      } = OO;
      const bK = tC(KO),
        eO = Math.max(1, KO.fuelHeat, KO.cooling, KO.size),
        lO = [
          ["fuel", `${go}rxBarRods`, KO.fuelHeat],
          ["cooling", `${go}rxBarCooling`, KO.cooling],
          ["size", `${go}rxBarSize`, KO.size]
        ];
      return (0, Ve.jsxs)("button", {
        type: "button",
        className: "Baf2RxMost",
        onClick: () => {
          XO(`${go}rxWhy_bars`)
        },
        children: [(0, Ve.jsx)("span", {
          className: "Baf2RxMostLine",
          children: pO(`${go}rxMost`, {
            amount: AC(Math.min(KO.fuelHeat, KO.cooling, KO.size))
          })
        }), (0, Ve.jsx)("span", {
          className: "Baf2RxMostBars",
          children: lO.map((OO => {
            let [KO, XO, lO] = OO;
            return (0, Ve.jsxs)("span", {
              className: Fb()("Baf2RxMostBar", KO, {
                Low: KO === bK
              }),
              children: [(0, Ve.jsx)("small", {
                children: pO(XO)
              }), (0, Ve.jsx)("i", {
                children: (0, Ve.jsx)("b", {
                  style: {
                    width: 100 * lO / eO + "%"
                  }
                })
              })]
            }, KO)
          }))
        })]
      })
    }

    function Ya(OO) {
      var KO;
      let {
        view: pO,
        heat: bK,
        settle: eO,
        settleLine: lO,
        settleBad: vK,
        explain: CO
      } = OO;
      const {
        t: hO
      } = (0, ze.D)(), {
        status: DO
      } = pO, MO = DO.baf2RxAt.join(","), [aK, oO] = (0, XO.useState)((() => Ma(pO.inner)));
      (0, XO.useEffect)((() => {
        oO(Ma(pO.inner))
      }), [MO, pO.inner[1]]);
      const FO = null !== (KO = pO.plan) && void 0 !== KO ? KO : CC(DO),
        VO = pO.plan ? pO.plan.powerPerUnit : DO.baf2RxStats[8],
        LO = null === bK ? null : "alarm" === (QO = eC(DO)) ? "red" : "hot" === QO ? "hot" : "warm" === QO ? "warm" : "cold";
      var QO;
      const zK = !DO.baf2RxFormed && function(OO, KO) {
          return 0 !== (OO.baf2RxFlags & KO)
        }(DO, vp),
        AO = DO.baf2RxDamage,
        fO = DO.baf2RxDamageTrend;
      return (0, Ve.jsxs)("div", {
        className: Fb()("Baf2RxCore", null !== LO && void 0 !== LO ? LO : "plan"),
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2RxCoreTop",
          children: [(0, Ve.jsx)(yo, {
            inner: pO.inner,
            looks: pO.looks,
            layer: aK,
            setLayer: oO,
            glow: DO.baf2RxFormed ? DO.baf2RxThrottle / 100 : 1,
            melted: zK,
            explain: CO
          }), (0, Ve.jsxs)("button", {
            type: "button",
            className: "Baf2RxHeatText",
            onClick: () => {
              CO(`${go}rxWhy_heat`)
            },
            children: [null !== bK ? (0, Ve.jsxs)(Ve.Fragment, {
              children: [(0, Ve.jsx)("b", {
                children: hO(`${go}rxHeatPct`, {
                  pct: String(bK)
                })
              }), (0, Ve.jsx)("span", {
                className: Fb()("Baf2RxBand", LO),
                children: hO(`${go}rxBand_${LO}`)
              })]
            }) : (0, Ve.jsx)("b", {
              children: hO(`${go}rxHeat`)
            }), null !== lO && (0, Ve.jsx)("span", {
              className: Fb()("Baf2RxSettle", {
                Bad: vK
              }),
              children: lO
            }), AO >= 1 && (0, Ve.jsxs)("span", {
              className: Fb()("Baf2RxDamage", fO),
              children: [hO(`${go}rxDamageLine`, {
                pct: String(AO)
              }), " \xb7 ", hO(`${go}rxDamage_${fO}`), (0, Ve.jsx)("i", {
                children: (0, Ve.jsx)("b", {
                  style: {
                    width: `${Math.min(100,AO)}%`
                  }
                })
              })]
            })]
          }), (0, Ve.jsx)(ia, {
            max: lC,
            bands: ua,
            ticks: Ea,
            now: bK,
            settle: eO,
            settleTone: vK ? "bad" : null,
            onExplain: () => {
              CO(`${go}rxWhy_heat`)
            }
          })]
        }), (0, Ve.jsx)(jo, {
          stats: FO,
          t: hO,
          explain: CO
        }), VO > 0 && (0, Ve.jsx)("button", {
          type: "button",
          className: "Baf2RxPerPellet",
          onClick: () => {
            CO(`${go}rxWhy_perPellet`)
          },
          children: hO(`${go}rxPerPellet`, {
            amount: AC(VO)
          })
        })]
      })
    }

    function wa(OO, KO) {
      var pO;
      if (!OO.baf2RxStore) return {
        note: KO(`${go}rxUpTo`, {
          amount: AC(OO.baf2RxMaxNow)
        }),
        share: void 0
      };
      const [XO, bK] = OO.baf2RxStore, eO = bK > 0 ? XO / bK : 0, lO = String(Math.floor(100 * eO)), vK = null !== (pO = OO.baf2RxStoreNetPerS) && void 0 !== pO ? pO : 0, CO = function(OO) {
        var KO, pO;
        const [XO, bK] = null !== (KO = OO.baf2RxStore) && void 0 !== KO ? KO : [0, 0], eO = null !== (pO = OO.baf2RxStoreNetPerS) && void 0 !== pO ? pO : 0;
        return bK > 0 && XO >= bK - 1 ? "running" === OO.baf2RxState ? `${ka}rxStoreFull` : `${ka}rxStoreFullOnly` : eO > .05 ? `${ka}rxStoreLine` : eO < -.05 ? "running" === OO.baf2RxState ? `${ka}rxStoreUsesMore` : `${ka}rxStoreDraining` : `${ka}rxStorePct`
      }(OO);
      return {
        note: KO(CO, CO === `${go}rxStoreLine` ? {
          pct: lO,
          time: Me(KO, (bK - XO) / vK)
        } : {
          pct: lO
        }),
        share: eO
      }
    }

    function io(OO) {
      let {
        view: KO,
        explain: pO,
        preview: XO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)(), {
        status: eO
      } = KO, lO = Sv(cC(...KO.dims)), vK = ea(eO), CO = Math.min(Math.round(eO.baf2RxFuel), lO.fuel), hO = "running" === eO.baf2RxState, DO = hO ? la(eO.baf2RxOut, eO.baf2RxMaxNow) : 0, MO = function(OO, KO, pO) {
        const XO = pa(OO),
          bK = "cryo" === XO.Lp,
          eO = pO ? pO.coolantSecs : XO.pct >= 100 && OO.baf2RxOut >= 1 ? bo(OO, OO.baf2RxThrottle).coolantSecs : null;
        let lO, vK = !1;
        if (XO.pct < 100) {
          const pO = 1 === XO.makersShort,
            eO = !bK && OO.baf2RxCryoOpen ? "OrCryo" : "";
          lO = XO.makersShort > 0 ? KO(bK ? `${go}rxCryoAddMixer${pO?"":"s"}` : `${go}rxWaterAddCondenser${pO?"":"s"}${eO}`, {
            count: String(XO.makersShort)
          }) : KO(`${go}rxWaterNeeds`, {
            rate: nM(XO.needPerS)
          })
        } else if (null !== eO) lO = KO(`${go}rxWaterRunsOut`, {
          time: Me(KO, eO)
        });
        else if (XO.waterBeside > 0) lO = KO(`${go}rxCryoPlusWater`, {
          rate: nM(XO.waterBeside)
        });
        else {
          const OO = function(OO) {
            return OO.inPerS <= 0 ? "rxWaterNoSupply" : OO.stored > 0 ? "rxWaterOkStored" : "rxWaterOk"
          }(XO);
          vK = "rxWaterNoSupply" === OO, lO = KO(`${go}${OO}`, {
            amount: AC(XO.stored)
          })
        }
        return {
          kind: bK ? "Cryo" : "Water",
          label: KO(bK ? `${go}rxCryo` : `${go}rxWater`),
          number: `${nM(XO.usePerS)}/s`,
          preview: pO ? `${nM(pO.coolPerS)}/s` : null,
          note: lO,
          tone: "noWater" === OO.baf2RxState ? "danger" : vK ? "warn" : (CO = XO.pct, hO = eO, CO < 100 ? "danger" : null === hO ? null : hO < 300 ? "danger" : "warn"),
          share: XO.pct / 100,
          why: bK ? `${go}rxWhy_cryo` : `${go}rxWhy_water`,
          short: XO.pct < 100
        };
        var CO, hO
      }(eO, bK, XO), aK = oC(eO, lO.waste, vK), oO = wa(eO, bK), FO = bo(eO, eO.baf2RxTarget), VO = hO && Math.abs(FO.settle - eO.baf2RxHeat) >= 3, LO = XO ? XO.pelletsPerMin / 60 : null;
      return (0, Ve.jsxs)("div", {
        className: "Baf2RxFlow",
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2RxLanes",
          children: [(0, Ve.jsx)(YM, {
            kind: "Fuel",
            label: bK(`${go}rxFuel`),
            number: String(CO),
            preview: null !== LO && LO > 0 && eO.baf2RxFuel > 0 ? Me(bK, eO.baf2RxFuel / LO) : null,
            note: eO.baf2RxFuel <= 0 ? bK(`${go}rxFuelEmpty`) : vK > 0 ? bK(`${go}rxFuelLeft`, {
              time: Me(bK, eO.baf2RxFuel / vK)
            }) : bK(1 === CO ? `${go}rxFuelPellet` : `${go}rxFuelPellets`),
            tone: "noFuel" === eO.baf2RxState ? "danger" : eO.baf2RxFuel < 2 ? "warn" : null,
            share: eO.baf2RxFuel / lO.fuel,
            onExplain: () => {
              pO(`${go}rxWhy_fuel`)
            }
          }), (0, Ve.jsx)(YM, {
            kind: MO.kind,
            label: MO.label,
            number: MO.number,
            preview: MO.preview,
            note: MO.note,
            tone: MO.tone,
            share: MO.share,
            onExplain: () => {
              pO(MO.why)
            }
          })]
        }), (0, Ve.jsxs)("div", {
          className: "Baf2RxPipes",
          children: [(0, Ve.jsx)(wM, {
            kind: "Fuel",
            step: DO,
            short: "noFuel" === eO.baf2RxState
          }), (0, Ve.jsx)(wM, {
            kind: MO.kind,
            step: DO,
            short: MO.short || "noWater" === eO.baf2RxState
          })]
        }), (0, Ve.jsx)(Ya, {
          view: KO,
          heat: eO.baf2RxHeat,
          settle: Math.min(lC, FO.settle),
          settleLine: VO ? bK(`${go}rxHeatSettles`, {
            pct: String(Math.round(FO.settle)),
            time: Me(bK, FO.settleS)
          }) : null,
          settleBad: FO.settle > 100,
          explain: pO
        }), (0, Ve.jsxs)("div", {
          className: "Baf2RxPipes",
          children: [(0, Ve.jsx)(wM, {
            kind: "Power",
            step: DO
          }), (0, Ve.jsx)(wM, {
            kind: "Waste",
            step: hO && eO.baf2RxFuel - eO.baf2RxPu > 0 ? DO : 0,
            short: aK.full
          })]
        }), (0, Ve.jsxs)("div", {
          className: "Baf2RxLanes",
          children: [(0, Ve.jsx)(YM, {
            kind: "Power",
            label: bK(`${go}rxPowerOut`),
            number: `\u26a1 ${AC(eO.baf2RxOut)}/s`,
            preview: XO ? AC(XO.out) : null,
            note: oO.note,
            share: oO.share,
            onExplain: () => {
              pO(`${go}rxWhy_power`)
            }
          }), (0, Ve.jsx)(YM, {
            kind: "Waste",
            label: bK(`${go}rxWaste`),
            number: `${Math.floor(eO.baf2RxWaste)}/${lO.waste}`,
            note: aK.full ? bK(`${go}rxWasteFull`) : null !== aK.fullInS ? bK(`${go}rxWasteFullIn`, {
              time: Me(bK, aK.fullInS)
            }) : bK(`${go}rxWasteSpent`),
            tone: "wasteFull" === eO.baf2RxState ? "danger" : aK.full ? "warn" : null,
            share: eO.baf2RxWaste / lO.waste,
            onExplain: () => {
              pO(`${go}rxWhy_waste`)
            }
          })]
        })]
      })
    }

    function ro(OO) {
      let {
        view: KO,
        explain: pO
      } = OO;
      const {
        t: XO
      } = (0, ze.D)(), bK = KO.plan;
      if (!bK) return null;
      const eO = bK.fuelHeat <= 0 ? null : bK.cooling > 0 ? Math.min(lC, 100 * bK.fuelHeat / bK.cooling) : lC,
        lO = XO(`${go}rxPlanAtFull`);
      return (0, Ve.jsxs)("div", {
        className: "Baf2RxFlow Plan",
        children: [(0, Ve.jsxs)("div", {
          className: "Baf2RxLanes",
          children: [(0, Ve.jsx)(YM, {
            kind: "Fuel",
            label: XO(`${go}rxFuel`),
            number: XO(`${go}rxPlanPerMin`, {
              amount: fC(bK.pelletsPerMin)
            }),
            note: XO(`${go}rxPlanPellets`),
            onExplain: () => {
              pO(`${go}rxWhy_fuel`)
            }
          }), (0, Ve.jsx)(YM, {
            kind: "Water",
            label: XO(`${go}rxWater`),
            number: `${nM(bK.waterPerS)}/s`,
            note: KO.status.baf2RxCryoOpen && bK.waterPerS > 0 ? XO(`${go}rxPlanOrCryo`, {
              rate: nM(pC(bK, kK.f) * kK.l)
            }) : lO,
            onExplain: () => {
              pO(`${go}rxWhy_water`)
            }
          })]
        }), (0, Ve.jsxs)("div", {
          className: "Baf2RxPipes",
          children: [(0, Ve.jsx)(wM, {
            kind: "Fuel",
            step: 0,
            planned: !0
          }), (0, Ve.jsx)(wM, {
            kind: "Water",
            step: 0,
            planned: !0
          })]
        }), (0, Ve.jsx)(Ya, {
          view: KO,
          heat: null,
          settle: eO,
          settleLine: null === eO ? null : XO(`${go}rxPlanHeat`, {
            pct: String(Math.round(eO))
          }),
          settleBad: null !== eO && eO > 100,
          explain: pO
        }), (0, Ve.jsxs)("div", {
          className: "Baf2RxPipes",
          children: [(0, Ve.jsx)(wM, {
            kind: "Power",
            step: 0,
            planned: !0
          }), (0, Ve.jsx)(wM, {
            kind: "Waste",
            step: 0,
            planned: !0
          })]
        }), (0, Ve.jsxs)("div", {
          className: "Baf2RxLanes",
          children: [(0, Ve.jsx)(YM, {
            kind: "Power",
            label: XO(`${go}rxPowerOut`),
            number: `\u26a1 ${AC(bK.max)}/s`,
            note: lO,
            onExplain: () => {
              pO(`${go}rxWhy_power`)
            }
          }), (0, Ve.jsx)(YM, {
            kind: "Waste",
            label: XO(`${go}rxWaste`),
            number: XO(`${go}rxPlanPerMin`, {
              amount: fC(bK.pelletsPerMin)
            }),
            note: XO(`${go}rxWasteSpent`),
            onExplain: () => {
              pO(`${go}rxWhy_waste`)
            }
          })]
        })]
      })
    }
    const Pa = "buildAFactory2Game:",
      mo = {
        key: `${Pa}rxWaiting`,
        params: {},
        tone: "info"
      };

    function sa(OO, KO) {
      return 0 !== (OO.baf2RxFlags & KO)
    }

    function Ha(OO) {
      var KO, pO;
      let {
        store: bK,
        close: eO
      } = OO;
      const {
        t: lO
      } = (0, ze.D)(), vK = GM(bK), {
        explained: CO,
        hinting: hO,
        explain: DO,
        explainOnce: MO
      } = ra("baf2RxExplained"), aK = (0, XO.useCallback)(((OO, KO) => {
        DO(lO(OO, KO))
      }), [DO, lO]), oO = (0, XO.useCallback)(((OO, KO) => {
        MO(OO, lO(OO, KO))
      }), [MO, lO]), [FO, VO] = (0, XO.useState)(!1), [LO, QO] = (0, XO.useState)(!1), zK = null === vK || void 0 === vK ? void 0 : vK.status, AO = null === zK || void 0 === zK ? void 0 : zK.baf2RxAt.join(","), fO = !0 === (null === zK || void 0 === zK ? void 0 : zK.baf2RxFormed);
      (0, XO.useEffect)((() => {
        QO(!1), VO(!1)
      }), [AO, fO]), (0, XO.useEffect)((() => (bK.opened(), () => {
        bK.closed()
      })), [bK]);
      const dO = void 0 !== zK && sa(zK, DK),
        TO = zK ? fO ? eC(zK) : null !== vK && void 0 !== vK && vK.plan ? function(OO, KO) {
          if (OO <= 0) return "off";
          if (KO <= 0) return "alarm";
          const pO = 100 * OO / KO;
          return pO < 50 ? "calm" : pO < kC ? "warm" : pO <= 100 ? "hot" : "alarm"
        }(vK.plan.fuelHeat, vK.plan.cooling) : "off" : "off",
        NO = zK ? vh(zK) : null,
        IO = vK ? vK.waiting ? mo : fO ? ha(vK.status) : function(OO) {
          var KO, pO;
          const {
            status: XO
          } = OO;
          return Da({
            left: XO.baf2RxNeed.reduce(((OO, KO) => {
              let [, pO] = KO;
              return OO + pO
            }), 0),
            bad: XO.baf2RxBad,
            rods: null !== (KO = null === (pO = OO.plan) || void 0 === pO ? void 0 : pO.rods) && void 0 !== KO ? KO : 0,
            canFill: sa(XO, CK),
            melted: sa(XO, vp),
            idle: OO.looks.reduce(((OO, KO) => OO + (KO === xC ? 1 : 0)), 0)
          })
        }(vK) : null,
        yK = hO && null !== IO && ("ok" === IO.tone || "info" === IO.tone),
        gK = zK ? function(OO) {
          const KO = 0 !== (OO.baf2RxFlags & eK),
            pO = OO.baf2RxHeat < sv;
          return 0 !== (OO.baf2RxFlags & vp) || pO && (KO || !OO.baf2RxFormed) ? null : OO.baf2RxFormed && !KO ? {
            key: `${bh}rxApartScram`,
            params: {}
          } : {
            key: `${bh}rxApartCooling`,
            params: {
              pct: String(sv)
            }
          }
        }(zK) : null,
        [uO, EO, jK] = null !== (KO = null === vK || void 0 === vK ? void 0 : vK.dims) && void 0 !== KO ? KO : [0, 0, 0],
        YO = `${uO}\xd7${EO}\xd7${jK}`;
      return (0, Ve.jsx)(Ml.d, {
        close: eO,
        togglePointerLock: !1,
        className: "Baf2PanelOverlay Baf2RxOverlay",
        children: (0, Ve.jsxs)("section", {
          className: "Baf2Panel Baf2RxPanel",
          role: "dialog",
          "aria-modal": "true",
          "aria-labelledby": "baf2RxTitle",
          children: [(0, Ve.jsxs)("header", {
            className: "Baf2PanelHeader",
            children: [(0, Ve.jsxs)("div", {
              className: "Baf2RxTitle",
              children: [(0, Ve.jsx)(xa, {
                mood: TO
              }), (0, Ve.jsxs)("div", {
                children: [(0, Ve.jsx)("h2", {
                  id: "baf2RxTitle",
                  children: lO(`${Pa}rxTitle`)
                }), vK && (0, Ve.jsxs)("p", {
                  className: Fb()("Baf2RxSubtitle", fO && (null === NO || void 0 === NO ? void 0 : NO.tone)),
                  children: [fO && !dO ? (0, Ve.jsxs)("button", {
                    type: "button",
                    className: "Baf2RxSizeButton",
                    "aria-label": lO(`${Pa}rxChangeSize`),
                    onClick: () => {
                      if (!zK) return;
                      const OO = sa(zK, eK);
                      var KO;
                      (KO = {
                        scram: OO,
                        heat: zK.baf2RxHeat
                      }).scram && KO.heat < sv ? VO(!0) : aK(OO ? `${Pa}rxResizeCooling` : `${Pa}rxResizeHot`, {
                        pct: String(sv)
                      })
                    },
                    children: [YO, " \u270e"]
                  }) : YO, " \xb7 ", lO(fO ? null !== (pO = null === NO || void 0 === NO ? void 0 : NO.label) && void 0 !== pO ? pO : `${Pa}rxState_running` : `${Pa}rxSubPlanShort`)]
                })]
              })]
            }), (0, Ve.jsxs)("div", {
              className: "Baf2RxHeadActions",
              children: [vK && !dO && (0, Ve.jsx)(qa, {
                kind: "reactor",
                busy: vK.busy.has("apart"),
                whyNot: gK ? () => {
                  aK(gK.key, gK.params)
                } : null,
                apart: () => {
                  bK.tap("apart", (() => {
                    bK.send("apart")
                  }))
                }
              }), (0, Ve.jsx)(av.i, {
                onClick: eO
              })]
            })]
          }), vK && IO && (0, Ve.jsxs)("div", {
            className: "Baf2RxBody",
            children: [fO ? (0, Ve.jsx)(io, {
              view: vK,
              explain: aK,
              preview: Xa(vK.status)
            }) : (0, Ve.jsx)(ro, {
              view: vK,
              explain: aK
            }), (0, Ve.jsx)(PM, {
              text: yK ? `${vo(lO,IO)} ${lO(`${Pa}rxTapHint`)}` : vo(lO, IO),
              tone: IO.tone,
              explained: CO
            }), dO ? (0, Ve.jsxs)(Ve.Fragment, {
              children: [(0, Ve.jsx)("p", {
                className: "Baf2RxHint Baf2RxNotYours",
                children: lO(`${Pa}rxNotYours`)
              }), (0, Ve.jsx)(JM, {
                status: vK.status,
                store: bK,
                readOnly: !0
              })]
            }) : fO && !LO ? (0, Ve.jsxs)(Ve.Fragment, {
              children: [(0, Ve.jsx)(Qa, {
                view: vK,
                store: bK,
                explain: aK,
                explainOnce: oO
              }), void 0 !== vK.status.baf2RxLayout && HM(vK.status) && (0, Ve.jsxs)("div", {
                className: "Baf2RxLayoutRow",
                children: [(0, Ve.jsx)(JM, {
                  status: vK.status,
                  store: bK,
                  readOnly: !1,
                  bare: !0
                }), (0, Ve.jsx)(SM, {
                  status: vK.status,
                  store: bK,
                  busy: vK.busy.has("fill")
                })]
              })]
            }) : (0, Ve.jsxs)(Ve.Fragment, {
              children: [(0, Ve.jsx)(zo, {
                view: vK,
                store: bK,
                keepSize: fO ? () => {
                  QO(!1)
                } : void 0
              }), DC(vK.dims, vK.status.baf2RxDims) && (0, Ve.jsx)(Aa, {
                need: vK.status.baf2RxNeed,
                explain: aK
              }), (0, Ve.jsx)(JM, {
                status: vK.status,
                store: bK,
                readOnly: !1
              })]
            }), FO && (0, Ve.jsx)(ZM, {
              id: "baf2ResizeTitle",
              title: `${Pa}rxResizeConfirmTitle`,
              body: `${Pa}rxResizeConfirmBody`,
              yes: `${Pa}rxChangeSize`,
              cancel: () => {
                VO(!1)
              },
              confirm: () => {
                VO(!1), QO(!0)
              }
            })]
          })]
        })
      })
    }
    class Ra {
      constructor() {
        this.view = null, this.listeners = new Set
      }
      set(OO) {
        this.view = OO;
        for (const KO of this.listeners) KO()
      }
      get() {
        return this.view
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
    }

    function Sa(OO) {
      let {
        commands: KO,
        store: pO,
        power: bK,
        water: eO,
        reactor: lO,
        battery: vK,
        collider: CO,
        terminal: hO,
        quests: DO,
        close: MO,
        DX: aK,
        askIslands: oO,
        showCore: FO,
        openSocial: VO
      } = OO;
      const {
        userContext: LO
      } = (0, Nv.d)(), QO = Tv.featureFlags.useSocialFeatures && LO.isLoggedIn(), [zK, AO] = (0, XO.useState)((() => pO.get()));
      (0, XO.useEffect)((() => pO.subscribe((() => {
        AO(pO.get())
      }))), [pO]);
      const fO = "islands" === (null === zK || void 0 === zK ? void 0 : zK.kind) ? zK.backToCore : void 0;
      return (0, Ve.jsxs)(jv.Provider, {
        value: KO,
        children: ["core" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(kM, {
          view: zK.core,
          close: MO,
          askIslands: oO
        }), "dropMap" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(pM, {
          message: zK.dropMap,
          quests: DO,
          close: MO,
          DX: aK
        }), "islands" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(AM, {
          message: zK.islands,
          arrivedAtMs: zK.arrivedAtMs,
          close: fO ? () => {
            FO(fO)
          } : MO,
          DX: aK,
          openSocial: QO ? VO : null
        }), "quests" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(LD, {
          store: DO,
          close: MO
        }), "transfer" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(Zh, {
          message: zK.transfer,
          arrivedAtMs: zK.arrivedAtMs,
          close: MO,
          DX: aK
        }), "power" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(fl, {
          store: bK,
          close: MO
        }), "water" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(ev, {
          store: eO,
          close: MO
        }), "reactor" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(Ha, {
          store: lO,
          close: MO
        }), "battery" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(da, {
          store: vK,
          close: MO
        }), "collider" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(lh, {
          store: CO,
          close: MO
        }), "terminal" === (null === zK || void 0 === zK ? void 0 : zK.kind) && (0, Ve.jsx)(ja, {
          store: hO,
          close: MO,
          send: OO => {
            KO.send(OO)
          }
        })]
      })
    }
    var Ja = pO(36888);

    function co(OO, KO) {
      return OO.distSq - KO.distSq
    }
    class Ba {
      constructor() {
        this.list = [], this.pool = []
      }
      add(OO, KO, pO, XO) {
        let bK = this.pool[this.list.length];
        bK || (bK = {
          x: 0,
          y: 0,
          distSq: 0,
          element: KO,
          liftRem: pO,
          dot: XO
        }, this.pool.push(bK)), bK.x = OO.x, bK.y = OO.y, bK.distSq = OO.distSq, bK.element = KO, bK.liftRem = pO, bK.dot = XO, this.list.push(bK)
      }
    }
    class Za {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        this.hud = OO, this.sizes = new WeakMap, this.observer = new ResizeObserver((OO => {
          this.remPx = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
          for (const KO of OO) {
            const OO = KO.borderBoxSize[0];
            "dot" !== KO.target.dataset.crowded && 0 !== OO.inlineSize && 0 !== OO.blockSize && this.sizes.set(KO.target, {
              width: OO.inlineSize,
              height: OO.blockSize
            })
          }
        })), this.remPx = 16, this.Sp = [], this.pxPerVw = window.innerWidth / 100, this.pxPerVh = window.innerHeight / 100, this.tV = () => {
          this.pxPerVw = window.innerWidth / 100, this.pxPerVh = window.innerHeight / 100
        }, window.addEventListener("resize", this.tV)
      }
      observe(OO) {
        this.observer.observe(OO)
      }
      unobserve(OO) {
        this.observer.unobserve(OO)
      }
      run(OO) {
        const KO = OO.list;
        KO.sort(co);
        const pO = this.pxPerVw,
          XO = this.pxPerVh;
        this.Sp.length = 0, this.hud && this.Sp.push(...this.hud.boxes(performance.now()));
        for (const eO of KO) {
          var bK;
          const OO = this.sizes.get(eO.element);
          let KO = "no";
          if (OO && OO.width > 0) {
            const bK = eO.x * pO,
              lO = eO.y * XO - eO.liftRem * this.remPx;
            this.fit(bK, lO, OO.width, OO.height) || (KO = eO.dot && this.fit(bK, lO, 1.2 * this.remPx, 1.4 * this.remPx) ? "dot" : "hidden")
          }(null !== (bK = eO.element.dataset.crowded) && void 0 !== bK ? bK : "no") !== KO && ("no" === KO ? delete eO.element.dataset.crowded : eO.element.dataset.crowded = KO), "hidden" !== KO && (0, Ja.e)(eO.element, eO.x, eO.y)
        }
        KO.length = 0
      }
      fit(OO, KO, pO, XO) {
        const bK = OO - pO / 2,
          eO = OO + pO / 2,
          lO = KO - XO,
          vK = this.Sp;
        for (let CO = 0; CO < vK.length; CO += 4)
          if (bK < vK[CO + 1] - 2 && eO > vK[CO] + 2 && lO < vK[CO + 3] - 2 && KO > vK[CO + 2] + 2) return !1;
        return vK.push(bK, eO, lO, KO), !0
      }
      dispose() {
        this.observer.disconnect(), window.removeEventListener("resize", this.tV)
      }
    }
    const Ga = ["Baf2QuestTracker", "BottomLeftIcons", "TopRightIconsContainer"];
    class qo {
      constructor() {
        this.cards = Ga.map((OO => document.getElementsByClassName(OO))), this.watched = Ga.map((() => null)), this.hud = null, this.list = [], this.stale = !0, this.refreshedAt = -1 / 0, this.onChange = () => {
          this.stale = !0
        }, this.sizes = new ResizeObserver(this.onChange), this.hudStyle = new MutationObserver(this.onChange), window.addEventListener("resize", this.onChange)
      }
      boxes(OO) {
        OO - this.refreshedAt > 1e3 && (this.refreshedAt = OO, this.stale = !0);
        for (let pO = 0; pO < this.cards.length; pO++) {
          var KO;
          const OO = null !== (KO = this.cards[pO][0]) && void 0 !== KO ? KO : null;
          OO !== this.watched[pO] && this.watch(pO, OO)
        }
        return this.stale && (this.stale = !1, this.measure()), this.list
      }
      dispose() {
        for (let OO = 0; OO < this.watched.length; OO++) this.watch(OO, null);
        this.sizes.disconnect(), window.removeEventListener("resize", this.onChange)
      }
      measure() {
        const OO = this.list;
        OO.length = 0;
        for (const KO of this.watched) {
          if (!KO || KO.closest(".NoRoom")) continue;
          const pO = KO.getBoundingClientRect();
          let XO = pO.top,
            bK = pO.bottom;
          if (KO === this.watched[0] && this.hud) {
            const OO = this.hud.getBoundingClientRect();
            XO = Math.max(XO, OO.top), bK = Math.min(bK, OO.bottom)
          }
          pO.width > 0 && bK > XO && OO.push(pO.left, pO.right, XO, bK)
        }
      }
      watch(OO, KO) {
        const pO = this.watched[OO];
        var XO, bK;
        (pO && this.sizes.unobserve(pO), this.watched[OO] = KO, this.stale = !0, KO && this.sizes.observe(KO), 0 === OO) && (null === (XO = this.hud) || void 0 === XO || XO.removeEventListener("scroll", this.onChange), this.hudStyle.disconnect(), this.hud = null !== (bK = null === KO || void 0 === KO ? void 0 : KO.closest(".Baf2QuestHud")) && void 0 !== bK ? bK : null, this.hud && (this.hud.addEventListener("scroll", this.onChange, {
          passive: !0
        }), this.hudStyle.observe(this.hud, {
          attributes: !0,
          attributeFilter: ["style", "class"]
        })))
      }
    }
    const xo = [0, 0, 0],
      na = {
        x: 0,
        y: 0,
        distSq: 0
      };

    function Wa(OO, KO, pO, XO, bK, eO) {
      let [lO, vK, CO] = XO;
      const hO = (lO + .5 - pO[0]) ** 2 + (vK - pO[1]) ** 2 + (CO + .5 - pO[2]) ** 2;
      let DO = null;
      hO <= eO ** 2 && (xo[0] = lO + .5, xo[1] = vK + bK, xo[2] = CO + .5, DO = KO.projectWorldPosToViewport(xo));
      const MO = null !== DO && DO.x > -5 && DO.x < 105 && DO.y > -5 && DO.y < 105;
      return (0, Ja.g)(OO, !MO), MO ? (na.x = DO.x, na.y = DO.y, na.distSq = hO, na) : null
    }
    class to {
      constructor(OO) {
        this.onElement = OO, this.markers = [], this.keys = new Set, this.elements = new Map, this.refs = new Map, this.listeners = new Set
      }
      set(OO) {
        const KO = [];
        for (let pO = 0; pO + 4 < OO.length; pO += 5) {
          const XO = [OO[pO], OO[pO + 1], OO[pO + 2]];
          KO.push({
            key: XO.join(","),
            pos: XO,
            status: nX[OO[pO + 3]],
            kind: fK[OO[pO + 4]]
          })
        }
        this.markers = KO, this.keys = new Set(KO.map((OO => {
          let {
            key: KO
          } = OO;
          return KO
        }))), this.notify()
      }
      covers(OO) {
        return this.keys.has(OO)
      }
      get() {
        return this.markers
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      bind(OO) {
        let KO = this.refs.get(OO);
        return KO || (KO = KO => {
          const pO = this.elements.get(OO);
          var XO, bK;
          pO && (null === (XO = this.onElement) || void 0 === XO || XO.call(this, pO, !1));
          KO ? (this.elements.set(OO, KO), null === (bK = this.onElement) || void 0 === bK || bK.call(this, KO, !0)) : (this.elements.delete(OO), this.refs.delete(OO))
        }, this.refs.set(OO, KO)), KO
      }
      onAfterRender(OO, KO, pO) {
        for (const XO of this.markers) {
          const bK = this.elements.get(XO.key);
          if (!bK) continue;
          const eO = Wa(bK, OO, KO, XO.pos, 1.05, 24);
          eO && pO.add(eO, bK, .45, !0)
        }
      }
      notify() {
        for (const OO of this.listeners) OO()
      }
    }
    const ko = {
      noFuel: "Coal",
      outputFull: "Chest",
      noDeposit: "Iron Deposit",
      noPower: "Generator",
      noTree: "Maple Log",
      noSky: "Sky Tap",
      noCrops: "Wheat Seeds",
      noWater: "Fluid Tank",
      noOutlet: "Fluid Pipe"
    };
    const Ua = (0, XO.memo)((function(OO) {
        let {
          status: KO,
          kind: pO,
          bindRef: XO
        } = OO;
        const {
          t: bK
        } = (0, ze.D)(), eO = function(OO, KO) {
          var pO;
          if ("noFuel" === OO) {
            var XO, bK;
            const OO = null === (XO = yp[KO]) || void 0 === XO || null === (bK = XO.fuels) || void 0 === bK ? void 0 : bK.find((OO => nK.includes(OO)));
            return null !== OO && void 0 !== OO ? OO : ko.noFuel
          }
          return void 0 !== (null === (pO = yp[KO]) || void 0 === pO ? void 0 : pO.cryoMade) ? "noOutlet" === OO ? "Fluid Pipe" : "noInput" === OO ? "Biomass" : ko[OO] : ko[OO]
        }(KO, pO);
        return (0, Ve.jsxs)("div", {
          className: Fb()("Baf2StallMarker", KO),
          ref: XO,
          hidden: !0,
          children: [eO && (0, Ve.jsx)("div", {
            className: "Baf2StallMarkerIcon",
            children: (0, Ve.jsx)(fb.b, {
              itemName: eO,
              amount: 0
            })
          }), (0, Ve.jsx)("span", {
            className: "Baf2StallMarkerBang",
            children: "notTaught" === KO ? "?" : "!"
          }), (0, Ve.jsx)("span", {
            className: "Baf2StallMarkerTag SmallTextBold",
            children: bK(`buildAFactory2Game:stallTag_${KO}`)
          })]
        })
      })),
      Oo = (0, XO.memo)((function(OO) {
        let {
          controller: KO
        } = OO;
        const [pO, bK] = (0, XO.useState)((() => KO.get()));
        return (0, XO.useEffect)((() => (bK(KO.get()), KO.subscribe((() => {
          bK(KO.get())
        })))), [KO]), (0, Ve.jsx)("div", {
          className: "Baf2StallMarkers",
          children: pO.map((OO => (0, Ve.jsx)(Ua, {
            status: OO.status,
            kind: OO.kind,
            bindRef: KO.bind(OO.key)
          }, OO.key)))
        })
      })),
      Ko = vX.k + 150;
    class po {
      constructor() {
        this.offset = null, this.sampledAt = 0
      }
      sample(OO, KO) {
        const pO = KO - OO;
        null === this.offset || pO < this.offset ? this.offset = pO : this.offset = Math.min(pO, this.offset + .02 * (KO - this.sampledAt)), this.sampledAt = KO
      }
      toLocal(OO) {
        var KO;
        return OO + (null !== (KO = this.offset) && void 0 !== KO ? KO : 0) + Ko
      }
    }
    var Xo = pO(36892);
    const bF = 15 * Math.PI / 180,
      eo = Math.SQRT2,
      loO = [4, 2];

    function vF(OO, KO) {
      const pO = [1 / 0, 1 / 0, 1 / 0],
        XO = [-1 / 0, -1 / 0, -1 / 0];
      for (const CO of OO)
        for (let OO = 0; OO < 3; OO++) pO[OO] = Math.min(pO[OO], CO[OO]), XO[OO] = Math.max(XO[OO], CO[OO]);
      const bK = (pO[0] + XO[0]) / 2,
        eO = (pO[1] + XO[1]) / 2,
        lO = (pO[2] + XO[2]) / 2;
      let vK = 0;
      for (const CO of OO) vK = Math.max(vK, Math.hypot(CO[0] - bK, CO[1] - eO, CO[2] - lO));
      return {
        x: bK,
        y: eO,
        z: lO,
        r: vK + KO
      }
    }

    function Co(OO, KO, pO) {
      const XO = KO.x - OO.x,
        bK = KO.y - OO.y,
        eO = KO.z - OO.z,
        lO = Math.sqrt(XO * XO + bK * bK + eO * eO);
      if (lO <= KO.r + 8) return 1;
      const vK = KO.r / lO,
        CO = Math.sqrt(1 - vK * vK),
        hO = CO < -OO.cosHalf,
        DO = (XO * OO.dx + bK * OO.dy + eO * OO.dz) / lO;
      if (!hO && DO < OO.cosHalf * CO - OO.sinHalf * vK) return 0;
      const MO = pO * eo * OO.frameMs * OO.pxPerBlock / (lO - KO.r);
      for (let aK = 0; aK < loO.length; aK++)
        if (MO * loO[aK] <= 1) return loO[aK];
      return 1
    }

    function ho(OO, KO) {
      return {
        name: OO,
        at: KO,
        kind: null,
        slot: -1,
        hidden: !0,
        drawn: NaN
      }
    }
    const Do = [0, 0, 0];

    function Mo(OO, KO, pO) {
      let [, XO, bK, eO, lO, vK] = KO;
      const CO = vX.f * (null !== lO && void 0 !== lO ? lO : 1),
        hO = [];
      for (let oO = 0; oO < XO.length; oO += 3) hO.push([XO[oO] + .5, XO[oO + 1] + .65, XO[oO + 2] + .5]);
      const DO = [];
      for (let oO = 0; oO < hO.length - 1; oO++) {
        const [OO, KO] = [hO[oO], hO[oO + 1]];
        DO.push([(OO[0] + KO[0]) / 2, (OO[1] + KO[1]) / 2, (OO[2] + KO[2]) / 2])
      }
      const MO = hO.slice(1, -1),
        aK = new Uint8Array(MO.length);
      for (const oO of null !== vK && void 0 !== vK ? vK : []) aK[oO >> 1] |= 1 & oO ? 2 : 1;
      return {
        island: OO,
        length: MO.length,
        loop: eO,
        cellsPerMs: CO,
        edges: DO,
        gp: MO,
        bounds: vF([...DO, ...MO], .3),
        changed: !0,
        culled: !1,
        hide: aK,
        items: bK.map((OO => {
          let [KO, XO] = OO;
          return ho(KO, (0, vX.D)(KO, XO, pO, CO).at)
        }))
      }
    }

    function aF(OO, KO) {
      const {
        items: pO
      } = OO;
      if (0 === pO.length) return;
      const XO = OO.length / OO.cellsPerMs,
        bK = Math.floor((KO - pO[0].at) / XO) - 1;
      if (bK > 0)
        for (const eO of pO) eO.at += bK * XO
    }

    function oo(OO, KO) {
      const pO = Math.min(Math.floor(KO), OO.length - 1),
        XO = OO.hide[pO];
      return 0 !== XO && 0 !== (XO & (KO - pO < .5 ? 1 : 2))
    }

    function Fo(OO, KO) {
      const pO = Math.min(Math.floor(KO), OO.length - 1),
        XO = KO - pO,
        bK = XO < .5,
        eO = bK ? OO.edges[pO] : OO.gp[pO],
        lO = bK ? OO.gp[pO] : OO.edges[pO + 1],
        vK = bK ? 2 * XO : 2 * XO - 1;
      Do[0] = eO[0] + (lO[0] - eO[0]) * vK, Do[1] = eO[1] + (lO[1] - eO[1]) * vK, Do[2] = eO[2] + (lO[2] - eO[2]) * vK
    }
    const Vo = Math.PI / 4;
    class Lo {
      constructor() {
        this.lines = new Map, this.shown = [], this.clock = new po, this.pending = [], this.pendingHead = 0, this.lastPendingAt = -1 / 0, this.view = {
          x: 0,
          y: 0,
          z: 0,
          dx: 0,
          dy: 0,
          dz: 1,
          cosHalf: -1,
          sinHalf: 0,
          pxPerBlock: 0,
          frameMs: 0
        }, this.frame = 0, this.lastRenderAt = 0, this.frameMs = 1e3 / 60, this.pool = null, this.cameraDir = [NaN, NaN, NaN], this.lastDir = [NaN, NaN, NaN], this.width = 0, this.height = 0, this.tV = () => {
          this.width = window.innerWidth, this.height = window.innerHeight
        }
      }
      onLines(OO) {
        const KO = performance.now();
        this.clock.sample(OO.baf2BeltLinesAt, KO), this.queue(OO.baf2BeltLinesAt, OO, 0, null, null, 0), this.applyDue(KO)
      }
      onMoves(OO) {
        const KO = performance.now(),
          pO = OO.baf2BeltMovesAt;
        this.clock.sample(pO, KO);
        for (const [XO, bK, eO, lO] of OO.baf2BeltMoveList) null === bK ? this.queue(pO - eO, null, XO, null, null, null !== lO && void 0 !== lO ? lO : 0) : this.queue(pO - eO, null, XO, bK, null !== lO && void 0 !== lO ? lO : null, 0);
        this.applyDue(KO)
      }
      start(OO) {
        this.pool = new Xo.b(OO, {
          scale: .3,
          yaw: Vo
        }, 64), this.tV(), window.addEventListener("resize", this.tV)
      }
      onAfterRender(OO) {
        const {
          pool: KO
        } = this;
        if (!KO) return;
        const pO = performance.now(),
          XO = pO - this.lastRenderAt;
        this.lastRenderAt = pO, XO < 100 && (this.frameMs += .1 * (XO - this.frameMs));
        const bK = pO + this.frameMs;
        this.applyDue(bK);
        const eO = OO.cameraPosition,
          lO = KO.follow(eO);
        this.setView(OO, eO);
        const vK = this.frame++;
        for (let CO = 0; CO < this.shown.length; CO++) {
          const OO = this.shown[CO],
            pO = Co(this.view, OO.bounds, OO.cellsPerMs),
            XO = OO.culled && 0 !== pO;
          if (OO.culled = 0 === pO, !lO && !OO.changed && !XO && (0 === pO || (vK + CO) % pO !== 0)) continue;
          OO.changed = !1, OO.loop && (aF(OO, bK), (0, vX.x)(OO.items, OO.length, bK, OO.cellsPerMs));
          let eO = OO.length;
          for (let vK = 0; vK < OO.items.length; vK++) {
            const pO = OO.items[vK],
              XO = (0, vX.E)(pO.at, eO, bK, OO.cellsPerMs);
            if (eO = XO - vX.n, oo(OO, XO)) {
              null === pO.kind || pO.hidden || (pO.kind.hide(pO.slot), pO.hidden = !0);
              continue
            }
            let CO = pO.kind;
            if (null === CO) {
              if (CO = KO.kindOf(pO.name), null === CO) continue;
              pO.kind = CO, pO.slot = CO.take(), pO.hidden = !0, pO.drawn = NaN
            } else if (XO === pO.drawn && !pO.hidden && !lO) continue;
            Fo(OO, XO), CO.write(pO.slot, Do[0], Do[1], Do[2]), pO.hidden = !1, pO.drawn = XO
          }
        }
        KO.commit()
      }
      dispose() {
        var OO;
        window.removeEventListener("resize", this.tV), this.lines.clear(), this.shown = [], this.pending.length = 0, this.pendingHead = 0, null === (OO = this.pool) || void 0 === OO || OO.dispose(), this.pool = null
      }
      setView(OO, KO) {
        const {
          cameraDir: pO,
          lastDir: XO
        } = this, bK = OO.cameraDirection;
        for (let DO = 0; DO < 3; DO++) XO[DO] = pO[DO], pO[DO] = bK[DO];
        const eO = pO[0] * XO[0] + pO[1] * XO[1] + pO[2] * XO[2],
          lO = Number.isNaN(eO) ? 0 : Math.acos(Math.min(1, Math.max(-1, eO))),
          {
            width: vK,
            height: CO
          } = this,
          hO = OO.tanHalfFovX;
        ! function(OO, KO, pO, XO, bK, eO, lO) {
          let vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0;
          OO.x = KO[0], OO.y = KO[1], OO.z = KO[2], OO.dx = pO[0], OO.dy = pO[1], OO.dz = pO[2];
          const CO = Math.min(Math.PI, Math.atan(Math.sqrt(XO * XO + bK * bK)) + bF + vK);
          OO.cosHalf = Math.cos(CO), OO.sinHalf = Math.sin(CO), OO.pxPerBlock = eO / (2 * bK), OO.frameMs = lO
        }(this.view, KO, pO, hO, hO * CO / vK, CO * window.devicePixelRatio, this.frameMs, lO)
      }
      queue(OO, KO, pO, XO, bK, eO) {
        const lO = Math.max(this.clock.toLocal(OO), this.lastPendingAt);
        this.lastPendingAt = lO, this.pending.push({
          at: lO,
          lines: KO,
          line: pO,
          name: XO,
          pos: bK,
          idx: eO
        })
      }
      applyDue(OO) {
        const {
          pending: KO
        } = this;
        for (; this.pendingHead < KO.length && KO[this.pendingHead].at <= OO;) {
          const OO = KO[this.pendingHead++];
          if (OO.lines) this.applyLines(OO.lines, OO.at), OO.lines = null;
          else {
            const KO = this.lines.get(OO.line);
            KO && this.applyMove(KO, OO, OO.at)
          }
        }
        this.pendingHead === KO.length ? (KO.length = 0, this.pendingHead = 0) : this.pendingHead > 256 && 2 * this.pendingHead > KO.length && (KO.splice(0, this.pendingHead), this.pendingHead = 0)
      }
      applyLines(OO, KO) {
        this.clearIsland(OO.baf2BeltIsland);
        for (const pO of OO.baf2BeltLineList) this.lines.set(pO[0], Mo(OO.baf2BeltIsland, pO, KO));
        this.shown = [...this.lines.values()]
      }
      applyMove(OO, KO, pO) {
        let {
          name: XO,
          pos: bK,
          idx: eO
        } = KO;
        OO.changed = !0, OO.loop && (aF(OO, pO), (0, vX.x)(OO.items, OO.length, pO, OO.cellsPerMs)), null !== XO && null !== bK ? (0, vX.B)(OO.items, OO.length, ho(XO, pO), bK, pO, OO.cellsPerMs) : null !== XO ? OO.items.push(ho(XO, pO)) : OO.items.length > eO && this.release((0, vX.I)(OO.items, OO.length, pO, OO.cellsPerMs, eO))
      }
      clearIsland(OO) {
        for (const [KO, pO] of this.lines)
          if (pO.island === OO) {
            for (const OO of pO.items) this.release(OO);
            this.lines.delete(KO)
          }
      }
      release(OO) {
        null !== OO.kind && (OO.kind.release(OO.slot), OO.kind = null, OO.slot = -1, OO.hidden = !0, OO.drawn = NaN)
      }
    }
    var Qo = pO(35130),
      zF = pO(36902);

    function Ao(OO) {
      let {
        depth: KO,
        store: pO,
        t: bK
      } = OO;
      const eO = function(OO) {
        const [KO, pO] = (0, XO.useState)(OO.lastPlayerY());
        return (0, Gh.f)(ub, pO), (0, XO.useEffect)((() => {
          pO(OO.lastPlayerY())
        }), [OO]), KO
      }(pO);
      if (null === eO) return null;
      const [lO, vK] = KO, CO = eO > lO ? lO : null !== vK && eO < vK ? vK : null, hO = {
        y: De(eO),
        target: null === CO ? "" : De(CO)
      };
      return (0, Ve.jsx)("span", {
        className: Fb()("Baf2QuestDepth", {
          Reached: null === CO
        }),
        children: bK(`${Wh}${null===CO?"questDepthReached":"questDepth"}`, hO)
      })
    }

    function fo(OO) {
      let {
        also: KO,
        view: pO,
        t: XO
      } = OO;
      return (0, Ve.jsxs)("li", {
        className: "Baf2QuestStep Baf2QuestAlso",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2QuestStepMark",
          "aria-hidden": "true",
          children: "+"
        }), (0, Ve.jsxs)("span", {
          className: "Baf2QuestStepBody",
          children: [(0, Ve.jsx)("strong", {
            children: XO(`${Wh}questAlsoDownHere`)
          }), (0, Ve.jsx)("span", {
            className: "Baf2QuestChips",
            children: KO.map((OO => {
              let [KO, bK, eO, lO] = OO;
              return (0, Ve.jsxs)("span", {
                className: "Baf2QuestChip",
                "aria-label": XO(`${Wh}questAlsoItem`, {
                  item: kD(XO, pO.itemNames[KO], KO),
                  have: String(bK),
                  need: String(eO)
                }),
                children: [(0, Ve.jsx)(OD, {
                  item: KO
                }), (0, Ve.jsx)("span", {
                  className: "Baf2QuestChipCount",
                  children: `${bK}/${eO}`
                }), null !== lO && (0, Ve.jsx)("span", {
                  className: "Baf2QuestChipDepth",
                  children: XO(`${Wh}questAlsoDepth`, {
                    y: De(lO)
                  })
                })]
              }, KO)
            }))
          })]
        })]
      })
    }
    var To = pO(35232);

    function No(OO) {
      let {
        expanded: KO,
        inventoryOpen: pO,
        children: bK
      } = OO;
      const eO = (0, XO.useRef)(null);
      return (0, XO.useEffect)((() => {
        const OO = eO.current,
          KO = null === OO || void 0 === OO ? void 0 : OO.closest(".RightElements"),
          XO = null === OO || void 0 === OO ? void 0 : OO.firstElementChild;
        if (!OO || !KO || !XO) return;
        return (0, zF.d)(".TopRightIconsContainer, .TopRightElementsRight, .CondensedSocialBarInner, .TopRightElements, .TouchComponentsButtons .TouchKeyHit, .InventoryWrapper .Inventory", [KO, XO], (() => {
          const bK = [...document.querySelectorAll(".TopRightIconsContainer, .TopRightElementsRight, .CondensedSocialBarInner")];
          if (0 === bK.length) return;
          const eO = Math.max(...bK.map((OO => OO.getBoundingClientRect().bottom))),
            lO = KO.getBoundingClientRect(),
            vK = pO ? document.querySelector(".InventoryWrapper .Inventory") : null;
          if (vK) {
            const KO = parseFloat(getComputedStyle(XO).marginLeft) + parseFloat(getComputedStyle(XO).marginRight),
              pO = lO.right - vK.getBoundingClientRect().right - 8 - KO;
            OO.style.setProperty("--baf2-quest-room", `${pO}px`), OO.classList.toggle("NoRoom", pO < 150)
          } else OO.style.removeProperty("--baf2-quest-room"), OO.classList.remove("NoRoom");
          const CO = eO - lO.top + 8,
            hO = function(OO, KO, pO) {
              const XO = KO.getBoundingClientRect(),
                bK = OO.getBoundingClientRect(),
                eO = (0, To.e)(bK.left, bK.right, XO.top + pO);
              if (null !== eO && eO < XO.bottom) return eO - XO.top;
              return XO.height - (parseFloat(getComputedStyle(KO).paddingBottom) || 0)
            }(OO, KO, CO) - 8,
            DO = window.innerHeight / 2 - lO.top,
            {
              top: MO,
              maxHeight: aK
            } = function(OO, KO, pO, XO, bK) {
              const eO = Math.min(pO, Math.max(0, KO - OO)),
                lO = bK ? OO : Math.max(OO, Math.min(XO - eO / 2, KO - eO));
              return {
                top: lO,
                maxHeight: Math.max(0, KO - lO)
              }
            }(CO, hO, function(OO) {
              const KO = OO.firstElementChild,
                pO = KO ? KO.scrollHeight - KO.clientHeight : 0;
              return OO.getBoundingClientRect().height + Math.max(0, pO)
            }(XO), DO, oe());
          OO.style.top = `${MO}px`, OO.style.maxHeight = `${aK}px`
        }))
      }), [pO]), (0, Ve.jsx)("div", {
        ref: eO,
        className: Fb()("Baf2QuestHud", {
          Expanded: KO
        }),
        children: bK
      })
    }

    function Io(OO) {
      let {
        amount: KO,
        t: pO
      } = OO;
      return (0, Ve.jsxs)("li", {
        className: "Baf2QuestStep Done Folded",
        children: [(0, Ve.jsx)("span", {
          className: "Baf2QuestStepMark",
          "aria-hidden": "true",
          children: "\u2713"
        }), (0, Ve.jsx)("span", {
          className: "Baf2QuestStepBody",
          children: pO(`${Wh}questStepsDone`, {
            amount: String(KO)
          })
        })]
      })
    }

    function yF(OO) {
      var KO;
      let {
        store: pO
      } = OO;
      const bK = (0, Gh.h)(ge, pO.get()),
        [eO, lO] = (0, XO.useState)(!1),
        {
          t: vK
        } = (0, ze.D)(),
        CO = function() {
          const [OO, KO] = (0, XO.useState)(oe);
          return (0, XO.useEffect)((() => (KO(oe()), Fe(KO))), []), OO
        }(),
        {
          openInGameMenuName: hO,
          openEverythingMenuName: DO
        } = (0, Mb.l)(["openInGameMenuName", "openEverythingMenuName"]),
        MO = "inventory" === hO && null === DO,
        aK = null !== hO && !MO || null !== DO;
      if (! function(OO) {
          return null !== OO.name || null !== OO.side
        }(bK) || aK || "off" === bK.tutorial) return null;
      const oO = ie(bK.rows),
        FO = oO.filter((OO => OO.done)).length,
        VO = function(OO, KO) {
          const pO = me(OO);
          let XO = 0;
          return OO.filter(((OO, bK) => !!OO.justFinished || !(OO.done || bK < pO || XO > KO) && (XO++, !0)))
        }(bK.rows, CO ? 0 : 2),
        LO = CO ? VO : function(OO, KO) {
          const pO = KO.filter((OO => !OO.justFinished));
          if (pO.length < 2) return [...KO];
          const XO = OO.indexOf(pO[0]),
            bK = OO.indexOf(pO[pO.length - 1]),
            eO = new Set(ie(OO));
          return OO.filter(((OO, pO) => KO.includes(OO) || OO.done && eO.has(OO) && pO > XO && pO < bK))
        }(bK.rows, VO),
        QO = eO ? bK.rows : LO,
        zK = eO || CO ? [] : function(OO, KO) {
          const pO = new Array(KO.length + 1).fill(0),
            XO = new Set(ie(OO));
          let bK = 0;
          for (const eO of OO) bK < KO.length && eO === KO[bK] ? bK++ : eO.done && XO.has(eO) && pO[bK]++;
          return pO
        }(bK.rows, LO),
        AO = eO || LO.length < bK.rows.length || null !== bK.reward,
        fO = wb(bK),
        dO = fO ? vK(`${Wh}questLineComplete`) : bK.tier ? XD(vK, bK.tier) : vK(`${Wh}currentQuest`),
        TO = function(OO) {
          var KO, pO;
          if (wb(OO)) return null;
          const XO = null === (KO = OO.chapters) || void 0 === KO ? void 0 : KO.find((KO => {
            let [pO] = KO;
            return pO === OO.tier
          }));
          if (!XO) return null;
          const bK = XO[1].filter((OO => !OO[4]));
          if (0 === bK.length) return null;
          const eO = null === (pO = OO.name) || void 0 === pO ? void 0 : pO[0],
            lO = OO => bK.findIndex((KO => KO[0] === eO && (!OO || !KO[3]))),
            vK = lO(!0),
            CO = vK >= 0 ? vK : lO(!1);
          if (CO >= 0) return [CO + 1, bK.length];
          const hO = bK.filter((OO => OO[3])).length;
          return [Math.min(hO + 1, bK.length), bK.length]
        }(bK);
      return (0, Ve.jsx)(Qo.h, {
        placement: "topRight",
        children: (0, Ve.jsx)(No, {
          expanded: eO,
          inventoryOpen: MO,
          children: (0, Ve.jsxs)("div", {
            className: "Baf2QuestTracker",
            style: tD,
            children: [null !== bK.name && (0, Ve.jsxs)("div", {
              className: "Baf2QuestTrackerBody",
              children: [bK.pulse > 0 && (0, Ve.jsx)("span", {
                className: "Baf2QuestTrackerPulse",
                "aria-hidden": "true"
              }, bK.pulse), (0, Ve.jsx)("div", {
                className: "Baf2QuestTrackerHead",
                children: (0, Ve.jsxs)("span", {
                  className: "Baf2QuestEyebrow",
                  children: [dO, TO && (0, Ve.jsx)("span", {
                    className: "Baf2QuestPlace",
                    role: "img",
                    "aria-label": vK(`${Wh}questPlaceLabel`, {
                      n: String(TO[0]),
                      total: String(TO[1])
                    }),
                    children: vK(`${Wh}questPlace`, {
                      n: String(TO[0]),
                      total: String(TO[1])
                    })
                  }), bK.tier && bK.core && !fO && (0, Ve.jsx)(bM, {
                    core: bK.core,
                    t: vK
                  })]
                })
              }), (0, Ve.jsx)("strong", {
                className: "Baf2QuestTrackerTitle",
                children: vK(`${Wh}${bK.name[0]}`, Uh(bK.name[1]))
              }), (oO.length > 1 || AO) && (0, Ve.jsxs)("div", {
                className: "Baf2QuestStepsLine",
                children: [oO.length > 1 && (0, Ve.jsx)(eD, {
                  rows: oO,
                  t: vK
                }), AO && (0, Ve.jsxs)("button", {
                  type: "button",
                  className: "Baf2QuestToggle",
                  "aria-expanded": eO,
                  onClick: () => {
                    lO(!eO)
                  },
                  children: [(0, Ve.jsx)("span", {
                    className: "Baf2QuestToggleCount",
                    children: vK(`${Wh}questStepsToggle`, {
                      done: String(FO),
                      total: String(oO.length)
                    })
                  }), (0, Ve.jsx)("span", {
                    className: "Baf2QuestToggleChevron",
                    "aria-hidden": "true",
                    children: eO ? "\u25b4" : "\u25be"
                  })]
                })]
              }), (0, Ve.jsxs)("ul", {
                className: "Baf2QuestChecklist",
                children: [QO.map(((OO, KO) => {
                  var eO;
                  const lO = OO.current && bK.depth;
                  return (0, Ve.jsxs)(XO.Fragment, {
                    children: [(null !== (eO = zK[KO]) && void 0 !== eO ? eO : 0) > 0 && (0, Ve.jsx)(Io, {
                      amount: zK[KO],
                      t: vK
                    }), (0, Ve.jsx)(lD, {
                      row: OO,
                      view: bK,
                      t: vK,
                      extra: lO && (0, Ve.jsx)(Ao, {
                        depth: lO,
                        store: pO,
                        t: vK
                      })
                    })]
                  }, OO.id)
                })), (null !== (KO = zK[QO.length]) && void 0 !== KO ? KO : 0) > 0 && (0, Ve.jsx)(Io, {
                  amount: zK[QO.length],
                  t: vK
                }), bK.also.length > 0 && (0, Ve.jsx)(fo, {
                  also: bK.also,
                  view: bK,
                  t: vK
                })]
              }), eO && bK.reward && (0, Ve.jsxs)("span", {
                className: "Baf2QuestReward",
                children: [vK(`${Wh}questReward`), (0, Ve.jsx)(OD, {
                  item: bK.reward
                }), kD(vK, bK.itemNames[bK.reward], bK.reward)]
              })]
            }), bK.side && (0, Ve.jsxs)("div", {
              className: "Baf2QuestTrackerBody Baf2QuestSideCard",
              children: [(0, Ve.jsx)("span", {
                className: "Baf2QuestEyebrow",
                children: vK(`${Wh}questSide`)
              }), (0, Ve.jsx)("strong", {
                className: "Baf2QuestTrackerTitle",
                children: vK(`${Wh}${bK.side.name[0]}`, Uh(bK.side.name[1]))
              }), (0, Ve.jsx)("ul", {
                className: "Baf2QuestChecklist",
                children: (0, Ve.jsx)(lD, {
                  row: bK.side.row,
                  view: bK,
                  t: vK
                })
              })]
            })]
          })
        })
      })
    }
    const gF = "baf2ToastView";
    class uo {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : () => !1;
        this.covered = OO, this.view = null, this.nextId = 1, this.holdUntil = 0, this.pending = null, this.timer = null, this.pendingTimer = null, this.covering = null, this.coveredTimer = null
      }
      get() {
        return this.view
      }
      show(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        if (this.covered()) return this.covering = {
          message: OO,
          holdMs: KO
        }, void(this.coveredTimer ??= setInterval((() => {
          if (this.covered()) return;
          const OO = this.dropCovered();
          OO && this.show(OO.message, OO.holdMs)
        }), 250));
        const pO = this.dropCovered();
        null !== pO && (pO.holdMs > 0 || "baf2ToastCelebrate" === pO.message.baf2ToastStyle) && "baf2ToastCelebrate" !== OO.baf2ToastStyle && this.show(pO.message, pO.holdMs);
        const XO = this.holdUntil - Date.now();
        if (null !== this.view && !this.view.leaving && "baf2ToastCelebrate" !== OO.baf2ToastStyle && XO > 0) return this.pending = {
          message: OO,
          holdMs: KO
        }, void(this.pendingTimer ??= setTimeout((() => {
          this.pendingTimer = null;
          const OO = this.pending;
          this.pending = null, OO && this.present(OO.message, OO.holdMs)
        }), XO));
        this.present(OO, KO)
      }
      dispose() {
        this.clearTimers(), this.dropCovered(), this.pending = null, this.view = null
      }
      present(OO, KO) {
        this.clearTimers(), this.pending = null;
        const pO = null !== this.view && !this.view.leaving;
        this.view = {
          id: this.nextId++,
          text: OO.baf2ToastText,
          style: OO.baf2ToastStyle,
          swapped: pO,
          leaving: !1
        }, this.holdUntil = Date.now() + ("baf2ToastCelebrate" === OO.baf2ToastStyle ? 1500 : KO), this.pl();
        const XO = Math.min(8e3, Math.max(1e3, OO.baf2ToastMs));
        this.timer = setTimeout((() => {
          this.DX()
        }), XO)
      }
      DX() {
        this.view && (this.view = {
          ...this.view,
          leaving: !0
        }, this.pl(), this.timer = setTimeout((() => {
          this.timer = null, this.view = null, this.pl()
        }), 200))
      }
      clearTimers() {
        null !== this.timer && (clearTimeout(this.timer), this.timer = null), null !== this.pendingTimer && (clearTimeout(this.pendingTimer), this.pendingTimer = null)
      }
      dropCovered() {
        null !== this.coveredTimer && (clearInterval(this.coveredTimer), this.coveredTimer = null);
        const OO = this.covering;
        return this.covering = null, OO
      }
      pl() {
        Ib.i.pl(gF, this.view, !0)
      }
    }
    var Eo = pO(77);
    const jF = {
      baf2ToastInfo: "Info",
      baf2ToastWarn: "Warn",
      baf2ToastGold: "Gold",
      baf2ToastCelebrate: "Celebrate"
    };

    function Yo(OO) {
      let {
        store: KO
      } = OO;
      const pO = (0, Gh.h)(gF, KO.get()),
        {
          openInGameMenuName: XO,
          openEverythingMenuName: bK
        } = (0, Mb.l)(["openInGameMenuName", "openEverythingMenuName"]),
        eO = pO && (0, Ve.jsxs)("div", {
          className: Fb()("Baf2Toast", jF[pO.style], {
            Swapped: pO.swapped,
            Leaving: pO.leaving
          }),
          role: "status",
          children: ["baf2ToastCelebrate" === pO.style && (0, Ve.jsx)("span", {
            className: "Baf2ToastStar",
            "aria-hidden": "true",
            children: "\u2605"
          }), (0, Ve.jsx)("span", {
            className: "Baf2ToastText SmallTextBold",
            children: (0, Ve.jsx)(db.d, {
              text: pO.text
            })
          })]
        }, pO.id);
      return null !== XO && null === bK ? (0, Eo.createPortal)((0, Ve.jsx)("div", {
        className: "Baf2ToastAboveMenu",
        children: eO
      }), document.body) : (0, Ve.jsx)(Qo.h, {
        children: eO
      })
    }
    const wo = "baf2AreaView";
    class iF {
      constructor() {
        this.view = null, this.nextId = 1, this.timer = null, this.JK = null
      }
      get() {
        return this.view
      }
      dropHeld() {
        this.JK = null
      }
      arrive(OO, KO) {
        KO && function(OO) {
          return "home" === OO.baf2AreaPlace && void 0 !== OO.baf2AreaNameText
        }(OO) ? this.JK = OO : this.show(OO)
      }
      release() {
        const OO = this.JK;
        null !== OO && this.show(OO)
      }
      show(OO) {
        this.clearTimer(), this.JK = null;
        const KO = void 0 === OO.baf2AreaResetMinutes ? 3800 : 5e3;
        this.view = {
          id: this.nextId++,
          area: OO,
          ms: KO
        }, this.pl(), this.timer = setTimeout((() => {
          this.timer = null, this.view = null, this.pl()
        }), KO)
      }
      dispose() {
        this.clearTimer(), this.JK = null, this.view = null
      }
      clearTimer() {
        null !== this.timer && (clearTimeout(this.timer), this.timer = null)
      }
      pl() {
        Ib.i.pl(wo, this.view, !0)
      }
    }

    function rF(OO) {
      var KO;
      let {
        store: pO
      } = OO;
      const {
        t: XO
      } = (0, ze.D)(), bK = (0, Gh.h)(wo, pO.get());
      if (!bK) return null;
      const {
        area: eO
      } = bK, lO = eO.baf2AreaResetMinutes;
      return (0, Ve.jsxs)("div", {
        className: "Baf2AreaBanner",
        "data-baf2-place": eO.baf2AreaPlace,
        style: {
          "--baf2-area-ms": `${bK.ms}ms`
        },
        role: "status",
        "aria-live": "polite",
        children: [(0, Ve.jsx)("div", {
          className: "Baf2AreaBannerBand",
          "aria-hidden": "true"
        }), eO.baf2AreaHeading && (0, Ve.jsx)("span", {
          className: "Baf2AreaBannerHeading",
          children: XO(eO.baf2AreaHeading)
        }), (0, Ve.jsx)("strong", {
          className: "Baf2AreaBannerName",
          children: null !== (KO = eO.baf2AreaNameText) && void 0 !== KO ? KO : XO(eO.baf2AreaName)
        }), eO.baf2AreaNote && (0, Ve.jsx)("span", {
          className: "Baf2AreaBannerNote",
          children: XO(eO.baf2AreaNote)
        }), void 0 !== lO && (0, Ve.jsx)("span", {
          className: "Baf2AreaBannerReset",
          children: XO("buildAFactory2Game:areaWildsReset", {
            time: Me(XO, 60 * lO)
          })
        })]
      }, bK.id)
    }
    const Po = "baf2GearGauge";
    class mF {
      constructor() {
        this.view = null, this.lingerTimer = null
      }
      get() {
        return this.view
      }
      YV(OO) {
        var KO;
        if (this.clearLinger(), null === OO.gearPowerKind) return void this.set(null);
        const pO = "jetpack" === OO.gearPowerKind && (XO = OO.gearChargeState, bK = OO.gearCharge, "flying" === XO || "charging" === XO || "outOfCharge" === XO || "ceiling" === XO || "offPlot" === XO || "noPower" === XO && bK <= 0);
        var XO, bK;
        const eO = !0 === (null === (KO = this.view) || void 0 === KO ? void 0 : KO.jetShown) && "jetpack" === this.view.gauge.gearPowerKind,
          lO = pO || "jetpack" === OO.gearPowerKind && eO;
        this.set({
          gauge: OO,
          jetShown: lO
        }), lO && !pO && (this.lingerTimer = setTimeout((() => {
          this.lingerTimer = null, this.view && this.set({
            ...this.view,
            jetShown: !1
          })
        }), 1500))
      }
      dispose() {
        this.clearLinger(), this.view = null
      }
      set(OO) {
        this.view = OO, Ib.i.pl(Po, OO, !0)
      }
      clearLinger() {
        null !== this.lingerTimer && (clearTimeout(this.lingerTimer), this.lingerTimer = null)
      }
    }
    const so = {
      charging: "buildAFactory2Game:gearJetCharging",
      noPower: "buildAFactory2Game:gearJetNoPower",
      offPlot: "buildAFactory2Game:gearJetOffPlotLine",
      ceiling: "buildAFactory2Game:gearJetCeilingLine"
    };

    function Ho(OO) {
      let {
        store: KO
      } = OO;
      const pO = (0, Gh.h)(Po, KO.get());
      return pO ? "jetpack" === pO.gauge.gearPowerKind ? (0, Ve.jsx)(Ro, {
        view: pO
      }) : (0, Ve.jsx)(So, {
        gauge: pO.gauge
      }) : null
    }

    function Ro(OO) {
      let {
        view: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)(), {
        gauge: XO
      } = KO, bK = XO.gearChargeMax > 0 ? Math.max(0, Math.min(1, XO.gearCharge / XO.gearChargeMax)) : 0, eO = so[XO.gearChargeState], lO = eO ? pO(eO) : null;
      return (0, Ve.jsxs)("div", {
        className: Fb()("Baf2JetArc", {
          Shown: KO.jetShown,
          Low: bK < .2,
          Warm: bK >= .2 && bK < .5
        }),
        style: {
          "--baf2-jet-fill": "" + 100 * (1 - bK)
        },
        "aria-hidden": !KO.jetShown,
        children: [(0, Ve.jsxs)("svg", {
          viewBox: "-50 -50 100 100",
          children: [(0, Ve.jsx)("path", {
            className: "Baf2JetArcTrack",
            d: Jo,
            pathLength: 100
          }), (0, Ve.jsx)("path", {
            className: "Baf2JetArcFill",
            d: Jo,
            pathLength: 100
          })]
        }), (0, Ve.jsxs)("span", {
          className: "Baf2JetArcPct",
          children: [Math.round(100 * bK), "%"]
        }), lO && (0, Ve.jsx)("span", {
          className: "Baf2JetArcLine SmallTextBold",
          children: lO
        })]
      })
    }

    function So(OO) {
      let {
        gauge: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)(), XO = function(OO, KO) {
        switch (KO.gearPowerKind) {
          case "skyPack":
            return OO("buildAFactory2Game:gearSkyPack", {
              charge: KO.gearCharge,
              max: KO.gearChargeMax
            });
          case "arcCaster":
          case "novaBlade":
            return OO("buildAFactory2Game:gearIslandDraw", {
              power: tK(KO.gearIslandPower),
              cost: tK(KO.gearCostPerUse)
            });
          case "barrier":
            return OO("buildAFactory2Game:gearBarrier", {
              shield: Math.round(KO.gearCharge),
              max: KO.gearChargeMax,
              power: tK(KO.gearIslandPower)
            });
          default:
            return null
        }
      }(pO, KO);
      return null === XO ? null : (0, Ve.jsx)(Qo.h, {
        children: (0, Ve.jsx)("div", {
          className: Fb()("Baf2GearPill SmallTextBold", {
            NoPower: "noPower" === KO.gearChargeState || "outOfCharge" === KO.gearChargeState
          }),
          role: "status",
          children: XO
        })
      })
    }
    const Jo = (() => {
      const OO = OO => {
        const KO = OO * Math.PI / 180;
        return `${(40*Math.cos(KO)).toFixed(2)} ${(40*Math.sin(KO)).toFixed(2)}`
      };
      return `M ${OO(160)} A 40 40 0 1 1 ${OO(380)}`
    })();
    class cF {
      constructor(OO) {
        this.onElement = OO, this.island = null, this.labels = new Map, this.snapshot = [], this.changes = 0, this.elements = new Map, this.refs = new Map, this.countElements = new Map, this.countRefs = new Map, this.countWords = String, this.listeners = new Set
      }
      YV(OO) {
        let KO = OO.baf2LabelsReset || OO.baf2LabelsIsland !== this.island;
        KO && (this.labels.clear(), this.island = OO.baf2LabelsIsland);
        for (const [pO, XO, bK, eO, lO] of OO.baf2LabelsList) {
          const OO = `${pO},${XO},${bK}`,
            vK = this.labels.get(OO);
          null === eO ? KO = this.labels.delete(OO) || KO : vK && vK.item === eO && (vK.count === lO || vK.count >= 0 && lO >= 0) ? vK.count !== lO && (vK.count = lO, this.writeCount(OO, lO)) : (this.labels.set(OO, {
            key: OO,
            pos: [pO, XO, bK],
            item: eO,
            count: lO
          }), this.writeCount(OO, lO), KO = !0)
        }
        if (this.changes++, KO) {
          this.snapshot = [...this.labels.values()];
          for (const OO of this.listeners) OO()
        }
      }
      bindCount(OO) {
        const KO = `${arguments.length>1&&void 0!==arguments[1]?arguments[1]:"bare"}|${OO}`;
        let pO = this.countRefs.get(KO);
        return pO || (pO = pO => {
          var XO, bK;
          pO ? (this.countElements.set(KO, pO), this.writeCount(OO, null !== (XO = null === (bK = this.labels.get(OO)) || void 0 === bK ? void 0 : bK.count) && void 0 !== XO ? XO : -1)) : (this.countElements.delete(KO), this.countRefs.delete(KO))
        }, this.countRefs.set(KO, pO)), pO
      }
      setCountWords(OO) {
        this.countWords = OO;
        for (const [KO, pO] of this.labels) this.writePart(`words|${KO}`, OO(pO.count), pO.count)
      }
      writeCount(OO, KO) {
        this.writePart(`bare|${OO}`, he(KO), KO), this.countElements.has(`words|${OO}`) && this.writePart(`words|${OO}`, this.countWords(KO), KO)
      }
      writePart(OO, KO, pO) {
        const XO = this.countElements.get(OO);
        if (!XO || pO < 0) return;
        const bK = XO.firstChild;
        bK && 3 === bK.nodeType && !bK.nextSibling ? bK.nodeValue !== KO && (bK.nodeValue = KO) : XO.textContent !== KO && (XO.textContent = KO)
      }
      list() {
        return this.snapshot
      }
      at(OO) {
        return this.labels.get(`${OO[0]},${OO[1]},${OO[2]}`)
      }
      version() {
        return this.changes
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      bind(OO) {
        let KO = this.refs.get(OO);
        return KO || (KO = KO => {
          const pO = this.elements.get(OO);
          var XO, bK;
          pO && (null === (XO = this.onElement) || void 0 === XO || XO.call(this, pO, !1));
          KO ? (this.elements.set(OO, KO), null === (bK = this.onElement) || void 0 === bK || bK.call(this, KO, !0)) : (this.elements.delete(OO), this.refs.delete(OO))
        }, this.refs.set(OO, KO)), KO
      }
      onAfterRender(OO, KO, pO, XO) {
        for (const bK of this.snapshot) {
          const eO = this.elements.get(bK.key);
          if (!eO) continue;
          if (XO(bK.key)) {
            (0, Ja.g)(eO, !0);
            continue
          }
          const lO = Wa(eO, OO, KO, bK.pos, 1.1, 24);
          lO && pO.add(lO, eO, 0, !1)
        }
      }
    }
    const Bo = (0, XO.memo)((function(OO) {
        let {
          item: KO
        } = OO;
        return (0, Ve.jsx)("div", {
          className: "Baf2IslandLabelIcon",
          children: (0, Ve.jsx)(fb.b, {
            itemName: KO,
            amount: 0
          })
        })
      })),
      Zo = (0, XO.memo)((function(OO) {
        let {
          label: KO,
          bindRef: pO,
          countRef: XO,
          wordsRef: bK
        } = OO;
        return (0, Ve.jsxs)("div", {
          className: "Baf2IslandLabel",
          ref: pO,
          hidden: !0,
          children: [(0, Ve.jsx)(Bo, {
            item: KO.item
          }), KO.count >= 0 && (0, Ve.jsxs)("span", {
            className: "Baf2IslandLabelCount SmallTextBold",
            children: [(0, Ve.jsx)("span", {
              className: "Baf2IslandLabelWords",
              ref: bK
            }), (0, Ve.jsx)("span", {
              className: "Baf2IslandLabelBare",
              ref: XO
            })]
          })]
        })
      })),
      Go = (0, XO.memo)((function(OO) {
        let {
          store: KO
        } = OO;
        const {
          t: pO
        } = (0, ze.D)(), [bK, eO] = (0, XO.useState)((() => KO.list()));
        return (0, XO.useEffect)((() => (eO(KO.list()), KO.subscribe((() => {
          eO(KO.list())
        })))), [KO]), (0, XO.useEffect)((() => {
          KO.setCountWords((OO => pO("buildAFactory2Game:labelSiloCount", {
            count: he(OO)
          })))
        }), [KO, pO]), (0, Ve.jsx)("div", {
          className: "Baf2IslandLabels",
          children: bK.map((OO => -2 === OO.count ? null : (0, Ve.jsx)(Zo, {
            label: OO,
            bindRef: KO.bind(OO.key),
            countRef: KO.bindCount(OO.key),
            wordsRef: KO.bindCount(OO.key, "words")
          }, OO.key)))
        })
      })),
      qF = {
        read: () => !0,
        write: () => {}
      };

    function xF(OO) {
      return `${OO[0]},${OO[1]},${OO[2]}`
    }

    function no(OO) {
      let [KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, aK] = OO;
      const oO = void 0 === MO || void 0 === aK ? function(OO) {
        return [Math.floor((OO - 1) / 2), 0]
      }(eO) : [MO, aK];
      return {
        kind: 0 === CO ? "reactor" : "battery",
        box: rX([KO, pO, XO], bK, eO, lO, vK, oO),
        formed: 1 === hO,
        level: DO
      }
    }
    class Wo {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : qF;
        this.guideSetting = OO, this.plans = new Map, this.predicted = new Map, this.startersOff = new Set, this.layouts = new Map, this.listeners = new Set, this.version = 0, this.formed = null, this.guide = void 0, this.guide = OO.read()
      }
      YV(OO) {
        var KO;
        const pO = new Map;
        for (const XO of OO.baf2RxPlanList) {
          const OO = no(XO);
          pO.set(xF(OO.box.ctrl), OO)
        }
        this.plans = pO, this.layouts = new Map((null !== (KO = OO.baf2RxLayouts) && void 0 !== KO ? KO : []).map((OO => {
          let [KO, pO, XO, bK] = OO;
          return [xF([KO, pO, XO]), bK]
        }))), this.predicted.clear(), OO.baf2RxFormedAt && (this.formed = {
          ctrl: OO.baf2RxFormedAt,
          receivedAt: performance.now()
        });
        for (const XO of [...this.startersOff]) {
          const OO = pO.get(XO);
          OO && !OO.formed || this.startersOff.delete(XO)
        }
        this.changed()
      }
      all() {
        return [...this.plans.keys()].map((OO => this.planByKey(OO)))
      }
      planAt(OO) {
        return this.planByKey(xF(OO))
      }
      predictSize(OO, KO) {
        this.predicted.set(xF(OO), KO), this.changed()
      }
      unpredict(OO) {
        this.predicted.delete(xF(OO)) && this.changed()
      }
      lastFormed() {
        return this.formed
      }
      layoutOf(OO) {
        var KO;
        const pO = xF(OO);
        return this.predicted.has(pO) ? null : null !== (KO = this.layouts.get(pO)) && void 0 !== KO ? KO : null
      }
      showsStarter(OO) {
        return !this.startersOff.has(xF(OO))
      }
      setStarter(OO, KO) {
        const pO = xF(OO);
        KO ? this.startersOff.delete(pO) : this.startersOff.add(pO), this.changed()
      }
      guideOn() {
        return this.guide
      }
      setGuide(OO) {
        this.guide = OO, this.guideSetting.write(OO), this.changed()
      }
      getVersion() {
        return this.version
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      dispose() {
        this.plans.clear(), this.predicted.clear(), this.startersOff.clear(), this.layouts.clear(), this.listeners.clear(), this.formed = null
      }
      planByKey(OO) {
        const KO = this.plans.get(OO);
        if (!KO) return null;
        const pO = this.predicted.get(OO);
        return pO ? {
          ...KO,
          box: mX(KO.box, KO.kind, pO[0], pO[1], pO[2])
        } : KO
      }
      changed() {
        this.version++;
        for (const OO of this.listeners) OO()
      }
    }
    var tF = pO(171);
    const kF = [1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1];

    function Uo(OO, KO, pO, XO) {
      const bK = OO.length / 3;
      for (let eO = 0; eO < kF.length / 3; eO++) OO.push(kF[3 * eO] * XO[0] / 2 + pO[0], kF[3 * eO + 1] * XO[1] / 2 + pO[1], kF[3 * eO + 2] * XO[2] / 2 + pO[2]);
      for (let eO = bK; eO < bK + 24; eO += 4) KO.push(eO, eO + 1, eO + 2, eO, eO + 2, eO + 3)
    }

    function OF(OO, KO, pO) {
      const XO = KO[0][0],
        bK = [],
        eO = [];
      for (const [lO, vK] of KO) Uo(bK, eO, [lO[0] - XO[0], lO[1] - XO[1], lO[2] - XO[2]], vK);
      return OO.createGameMesh({
        positions: bK,
        indices: eO
      }, pO, XO)
    }

    function KF(OO, KO) {
      const pO = OO.w - 2,
        XO = OO.d - 2;
      return 1 === function(OO, KO, pO, XO) {
        const [bK, eO, lO] = OO;
        if (Number(bK <= 2) + Number(eO <= 2) + Number(lO <= 2) >= 2) return function(OO, KO, pO) {
          return (OO + KO + pO) % 2 === 0 ? 1 : 3
        }(KO, pO, XO);
        const [vK, CO] = bK >= eO && bK >= lO ? [pO, XO] : eO >= lO ? [KO, XO] : [KO, pO];
        return vK % 2 === 0 && CO % 2 === 0 ? 1 : 3
      }([pO, OO.h - 2, XO], KO % pO, Math.floor(KO / (pO * XO)), Math.floor(KO / pO) % XO) ? "rod" : "channel"
    }

    function pF(OO, KO, pO) {
      if ("reactor" !== OO.kind || OO.formed || !KO) return !1;
      const XO = Rp(OO.box);
      for (let bK = 0; bK < XO; bK++) {
        const OO = pO(bK);
        if (null !== OO && dp(OO)) return !1
      }
      return !0
    }

    function XF(OO, KO, pO, XO, bK) {
      var eO;
      let lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null;
      const vK = Gp(OO.box, KO),
        CO = Wp(OO.kind, vK, pO);
      if ("wrong" === CO || "blocked" === CO) return "wrong";
      if (!bK) return null;
      if ("inside" === vK && "reactor" === OO.kind && "Air" === Tp(pO)) {
        if (null !== lO) {
          var hO;
          const pO = ma[sM(lO, qX(OO.box, KO))];
          return pO && null !== (hO = VC(pO)) && void 0 !== hO ? hO : null
        }
        if (XO) return KF(OO.box, qX(OO.box, KO))
      }
      if ("missing" !== CO) return null;
      const DO = tX(OO.kind, vK);
      return null === DO ? null : null !== (eO = VC(DO)) && void 0 !== eO ? eO : null
    }
    const bV = [
      [1, 0, 0],
      [-1, 0, 0],
      [0, 1, 0],
      [0, -1, 0],
      [0, 0, 1],
      [0, 0, -1]
    ];

    function eF(OO, KO, pO) {
      const XO = pO => {
        const XO = KO(Bp(OO.box, pO));
        return null !== XO && function(OO, KO) {
          return "reactor" !== OO.kind || KO !== Jp(OO.box) && "inside" !== Gp(OO.box, KO)
        }(OO, pO) && "ok" !== Wp(OO.kind, Gp(OO.box, pO), XO)
      };
      if (pO) {
        const eO = Zp(OO.box, [Math.floor(pO[0]), Math.floor(pO[1]), Math.floor(pO[2])]);
        if (eO >= 0 && (XO(eO) || (bK = eO, "reactor" === OO.kind && "inside" === Gp(OO.box, bK) && "Air" === KO(Bp(OO.box, bK))))) return eO
      }
      var bK;
      const eO = Rp(OO.box);
      for (let lO = 0; lO < eO; lO++)
        if (XO(lO)) return lO;
      return -1
    }

    function lF(OO, KO) {
      return Math.floor(KO / (OO.w * OO.d))
    }

    function vV(OO, KO, pO) {
      return pO >= 0 && lF(OO, KO) > lF(OO, pO)
    }

    function CF(OO, KO) {
      return KO >= 0 && OO.h >= 3 && lF(OO, KO) === OO.h - 1
    }

    function hF(OO) {
      const KO = Tp(OO);
      return KO === Dp || "Collider" === KO || "Laser" === KO || KO.startsWith("_Collider ")
    }

    function DF(OO, KO, pO, XO) {
      if (XO(OO)) return null;
      if (!bV.every((KO => {
          let [XO, bK, eO] = KO;
          const lO = pO([OO[0] + XO, OO[1] + bK, OO[2] + eO]);
          return null !== lO && !jX("reactor", lO) && "reactor" !== Np(lO)
        }))) return null;
      const bK = Yp("reactor").min,
        eO = rX([OO[0], OO[1], OO[2]], function(OO, KO) {
          const pO = KO[0] - (OO[0] + .5),
            XO = KO[2] - (OO[2] + .5);
          return Math.abs(pO) >= Math.abs(XO) ? pO >= 0 ? 2 : 4 : XO >= 0 ? 1 : 3
        }(OO, KO), bK, bK, bK, Pp("reactor", bK)),
        lO = Jp(eO);
      let vK = !0;
      for (let CO = 0; CO < Rp(eO) && vK; CO++) {
        if (CO === lO) continue;
        const OO = Bp(eO, CO),
          KO = pO(OO);
        vK = !XO(OO) && (null === KO || !hF(KO))
      }
      return {
        box: eO,
        fits: vK
      }
    }
    const MF = FC,
      aV = "baf2Goal",
      oF = [
        [0, 0, 0],
        [1, 0, 0],
        [0, 0, 1],
        [1, 0, 1],
        [0, 1, 0],
        [1, 1, 0],
        [0, 1, 1],
        [1, 1, 1]
      ],
      FF = {
        rgb: [1, .93, .45],
        alpha: 1
      },
      VF = .4;

    function LF(OO, KO) {
      let [pO, XO, bK] = OO;
      const eO = TC([pO - .02, XO - .02, bK - .02], [pO + 1.02, XO + 1.02, bK + 1.02], .07);
      return KO && (eO.push([
        [pO + .5, XO + 1 + .7, bK + .5],
        [.08, 1.4, .08]
      ]), eO.push([
        [pO + .5, XO + 1 + 1.4 + .2, bK + .5],
        [VF, VF, VF]
      ])), eO
    }

    function QF(OO, KO) {
      let [pO, XO, bK] = KO;
      return OO.isBlockInLoadedChunk(pO, XO, bK) ? OO.blockIdToBlockName(OO.getBlockId(pO, XO, bK)) : null
    }
    let zV = null;
    const AF = new Set;
    let fF = null;

    function dF(OO) {
      zV = OO;
      for (const KO of AF) KO(OO)
    }
    class TF {
      constructor(OO) {
        var KO;
        this.plans = OO, this.lastCheckMs = -1 / 0, this.lastRescanMs = -1 / 0, this.storeVersion = -1, this.chunkVersions = new Map, this.shownKey = "", this.meshes = [], this.cues = [], this.goal = null, this.startsBattery = !1, this.unwatch = void 0, this.unwatch = (KO = OO => {
          var KO, pO;
          this.setGoal(null !== (KO = null === OO || void 0 === OO ? void 0 : OO.goal) && void 0 !== KO ? KO : null, null !== (pO = null === OO || void 0 === OO ? void 0 : OO.startsBattery) && void 0 !== pO && pO)
        }, fF ??= [Ib.i.subscribe("setDirectionArrow", (OO => {
          let {
            id: KO,
            position: pO,
            text: XO
          } = OO;
          KO === aV && dF({
            goal: [Math.floor(pO[0]), Math.floor(pO[1]), Math.floor(pO[2])],
            startsBattery: JSON.stringify(null !== XO && void 0 !== XO ? XO : null).includes("arrowStartBattery")
          })
        })), Ib.i.subscribe("clearDirectionArrow", (OO => {
          let {
            id: KO
          } = OO;
          null !== KO && KO !== aV || dF(null)
        }))], AF.add(KO), KO(zV), () => {
          AF.delete(KO)
        })
      }
      onAfterRender(OO, KO) {
        const pO = performance.now();
        if (this.cues.length > 0) {
          const KO = .55 + .45 * Math.sin(pO / 1100 * Math.PI * 2);
          for (const pO of this.cues) OO.setGameMesh(pO, {
            visibility: KO
          })
        }
        if (pO - this.lastCheckMs < 150) return;
        this.lastCheckMs = pO;
        const XO = this.plans.all().filter((OO => {
            const [pO, XO, bK] = OO.box.ctrl;
            return (!OO.formed || null !== this.plans.layoutOf(OO.box.ctrl)) && (pO - KO[0]) ** 2 + (XO - KO[1]) ** 2 + (bK - KO[2]) ** 2 <= 2304
          })),
          bK = function(OO, KO) {
            const pO = tF.h.SX,
              XO = new Map;
            for (const eO of KO) {
              const KO = Bp(eO.box, 0),
                lO = Bp(eO.box, Rp(eO.box) - 1),
                vK = [Math.min(KO[0], lO[0]), Math.min(KO[1], lO[1]), Math.min(KO[2], lO[2])].map((OO => Math.floor(OO / pO))),
                CO = [Math.max(KO[0], lO[0]), Math.max(KO[1], lO[1]), Math.max(KO[2], lO[2])].map((OO => Math.floor(OO / pO)));
              for (let pO = vK[0]; pO <= CO[0]; pO++)
                for (let KO = vK[1]; KO <= CO[1]; KO++)
                  for (let eO = vK[2]; eO <= CO[2]; eO++) {
                    var bK;
                    XO.set(`${pO},${KO},${eO}`, null !== (bK = OO.getChunkVersion(pO, KO, eO)) && void 0 !== bK ? bK : -1)
                  }
            }
            return XO
          }(OO, XO);
        this.plans.getVersion() === this.storeVersion && (function(OO, KO) {
          if (OO.size !== KO.size) return !1;
          for (const [pO, XO] of OO)
            if (KO.get(pO) !== XO) return !1;
          return !0
        }(bK, this.chunkVersions) || pO - this.lastRescanMs < 600) || (this.lastRescanMs = pO, this.storeVersion = this.plans.getVersion(), this.chunkVersions = bK, this.redraw(OO, XO))
      }
      dispose(OO) {
        this.unwatch(), zV = null, this.clearMeshes(OO), this.chunkVersions.clear(), this.shownKey = ""
      }
      setGoal(OO, KO) {
        var pO;
        (null === OO || void 0 === OO ? void 0 : OO.join()) === (null === (pO = this.goal) || void 0 === pO ? void 0 : pO.join()) && KO === this.startsBattery || (this.goal = OO, this.startsBattery = KO, this.storeVersion = -1)
      }
      redraw(OO, KO) {
        const pO = KO => QF(OO, KO),
          XO = new Map,
          bK = [],
          eO = this.plans.guideOn();
        for (const hO of KO) {
          const OO = eO && pF(hO, this.plans.showsStarter(hO.box.ctrl), (OO => pO(Bp(hO.box, OO)))),
            KO = "reactor" === hO.kind ? this.plans.layoutOf(hO.box.ctrl) : null,
            lO = eO && !hO.formed ? eF(hO, pO, this.goal) : -1;
          lO >= 0 && bK.push([Bp(hO.box, lO), CF(hO.box, lO)]);
          const vK = Rp(hO.box);
          for (let bK = 0; bK < vK; bK++) {
            const vK = Bp(hO.box, bK),
              CO = pO(vK),
              DO = null === CO ? null : XF(hO, bK, CO, OO, eO, KO);
            if (null !== DO) {
              const OO = "wrong" !== DO && vV(hO.box, bK, lO),
                KO = OO ? `${DO}Dim` : DO;
              let pO = XO.get(KO);
              pO || (pO = {
                draw: {
                  ghost: DO,
                  dim: OO
                },
                list: []
              }, XO.set(KO, pO)), pO.list.push(vK)
            }
          }
        }
        if (eO && this.startsBattery && this.goal) {
          const [OO, KO, bK] = this.goal, eO = [];
          for (const [XO, lO, vK] of oF) {
            const CO = [OO + XO, KO + lO, bK + vK];
            "Air" === pO(CO) && eO.push(CO)
          }
          if (eO.length > 0) {
            var lO;
            const OO = null !== (lO = XO.get("cell")) && void 0 !== lO ? lO : {
              draw: {
                ghost: "cell",
                dim: !1
              },
              list: []
            };
            OO.list.push(...eO), XO.set("cell", OO)
          }
        }
        const vK = [...XO.keys()].sort(),
          CO = [...vK.map((OO => `${OO}:${XO.get(OO).list.join(";")}`)), `cue:${bK.join(";")}`].join("|");
        if (CO !== this.shownKey) {
          this.shownKey = CO, this.clearMeshes(OO);
          for (const KO of vK) {
            const {
              draw: pO,
              list: bK
            } = XO.get(KO);
            this.meshes.push(this.build(OO, pO, bK))
          }
          for (const [KO, pO] of bK) this.cues.push(OF(OO, LF(KO, pO), FF))
        }
      }
      build(OO, KO, pO) {
        let {
          ghost: XO,
          dim: bK
        } = KO;
        const {
          size: eO,
          colour: lO,
          alpha: vK
        } = MF[XO], CO = pO[0], hO = [], DO = [];
        for (const [MO, aK, oO] of pO) Uo(hO, DO, [MO - CO[0] + .5, aK - CO[1] + .5, oO - CO[2] + .5], [eO, eO, eO]);
        return OO.createGameMesh({
          positions: hO,
          indices: DO
        }, {
          rgb: lO,
          alpha: vK * (bK ? .3 : 1)
        }, CO)
      }
      clearMeshes(OO) {
        for (const KO of [...this.meshes, ...this.cues]) OO.disposeGameMesh(KO);
        this.meshes = [], this.cues = []
      }
    }
    const NF = [.56, .83, 1],
      IF = [1, .3, .25];
    class yV {
      constructor(OO) {
        this.plans = OO, this.meshes = [], this.shownKey = "", this.lastCheckMs = -1 / 0
      }
      onAfterRender(OO, KO, pO) {
        var XO;
        const bK = performance.now();
        if (bK - this.lastCheckMs < 150) return;
        this.lastCheckMs = bK;
        const eO = KO => QF(OO, KO),
          lO = null === (XO = OO.mhO(KO)) || void 0 === XO ? void 0 : XO.name,
          vK = lO && "Reactor Frame" === Tp(lO) ? OO.getTargetedBlock() : null,
          CO = vK ? [vK.Se[0], vK.Se[1], vK.Se[2]] : null,
          hO = null !== CO && "Air" === eO(CO) && CO.every(((OO, KO) => Math.abs(OO + .5 - pO[KO]) <= 8)) ? DF(CO, pO, eO, (OO => this.inPlan(OO))) : null,
          DO = hO ? `${hO.box.ctrl.join()}|${hO.box.rot}|${hO.fits}` : "";
        DO !== this.shownKey && this.show(OO, DO, hO)
      }
      dispose(OO) {
        this.clear(OO), this.shownKey = ""
      }
      inPlan(OO) {
        return this.plans.all().some((KO => Zp(KO.box, OO) >= 0))
      }
      show(OO, KO, pO) {
        if (this.clear(OO), this.shownKey = KO, !pO) return;
        const {
          box: XO,
          fits: bK
        } = pO, eO = bK ? NF : IF, {
          lo: lO,
          hi: vK
        } = dC(XO);
        this.meshes.push(OF(OO, TC(lO, vK, .05), {
          rgb: eO,
          alpha: 1
        }));
        const CO = [],
          hO = Bp(XO, 0)[1];
        for (let DO = 0; DO < XO.w * XO.d; DO++) {
          const [OO, , KO] = Bp(XO, DO);
          CO.push([
            [OO + .5, hO + .02 + .01, KO + .5],
            [.94, .04, .94]
          ])
        }
        this.meshes.push(OF(OO, CO, {
          rgb: eO,
          alpha: .25
        }))
      }
      clear(OO) {
        for (const KO of this.meshes) OO.disposeGameMesh(KO);
        this.meshes = []
      }
    }
    const gV = "buildAFactory2Game:";

    function uF(OO, KO, pO) {
      const XO = OO => {
          const [pO, XO, bK] = OO.box.ctrl;
          return pO === KO[0] && XO === KO[1] && bK === KO[2]
        },
        bK = OO.find((OO => XO(OO) || Zp(OO.box, KO) >= 0));
      if (!bK) return null;
      const eO = function(OO, KO, pO) {
        const {
          w: XO,
          h: bK,
          d: eO
        } = OO.box, lO = "reactor" === OO.kind ? `${gV}rxTitle` : `${gV}batTitle`;
        if (OO.formed) return {
          key: `${gV}lookPlanFormed`,
          kindKey: lO,
          w: XO,
          h: bK,
          d: eO,
          count: 0
        };
        let vK = 0,
          CO = 0;
        for (let DO = 0; DO < Rp(OO.box); DO++) {
          const KO = pO(Bp(OO.box, DO)),
            XO = null === KO ? "ok" : Wp(OO.kind, Gp(OO.box, DO), KO);
          vK += "missing" === XO ? 1 : 0, CO += "wrong" === XO || "blocked" === XO ? 1 : 0
        }
        const hO = function(OO, KO, pO) {
          if (KO < 0 || null === pO) return;
          const XO = Gp(OO.box, KO),
            bK = Wp(OO.kind, XO, pO);
          return "blocked" === bK ? `${gV}lookWhy_blocked` : "wrong" === bK ? "ctrl" === XO ? `${gV}lookWhy_ctrl` : `${gV}lookWhy_reactor_${XO}` : void 0
        }(OO, Zp(OO.box, KO), pO([KO[0], KO[1], KO[2]]));
        if (vK > 0) return {
          key: `${gV}lookPlanToBuild`,
          kindKey: lO,
          w: XO,
          h: bK,
          d: eO,
          count: vK,
          why: hO
        };
        if (CO > 0) return {
          key: `${gV}lookPlanTakeOut`,
          kindKey: lO,
          w: XO,
          h: bK,
          d: eO,
          count: CO,
          why: hO
        };
        return {
          key: "reactor" === OO.kind ? `${gV}lookPlanNoRods` : `${gV}lookPlanDone`,
          kindKey: lO,
          w: XO,
          h: bK,
          d: eO,
          count: 0
        }
      }(bK, KO, pO);
      return "reactor" === bK.kind && XO(bK) ? {
        ...eO,
        ctrl: !0
      } : eO
    }

    function EF(OO, KO) {
      return OO === KO || null !== OO && null !== KO && OO.key === KO.key && OO.kindKey === KO.kindKey && OO.w === KO.w && OO.h === KO.h && OO.d === KO.d && OO.count === KO.count && OO.why === KO.why && OO.ctrl === KO.ctrl
    }

    function jV() {
      return performance.now()
    }
    class YF {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : jV;
        this.ticket = OO, this.sent = KO, this.backstopMs = pO, this.now = XO, this.queuedAt = void 0, this.queuedAt = XO()
      }
      answered() {
        const OO = this.now(),
          KO = this.sent.leftAt(this.ticket);
        return null !== KO && OO - KO > 4e3 || OO - this.queuedAt > this.backstopMs
      }
      age() {
        return this.now() - this.queuedAt
      }
    }
    class wF {
      constructor() {
        this.echoes = []
      }
      add(OO) {
        this.echoes = this.echoes.filter((OO => !OO.answered())), this.echoes.push(OO)
      }
      answered() {
        var OO, KO;
        return null === (OO = null === (KO = this.echoes.at(-1)) || void 0 === KO ? void 0 : KO.answered()) || void 0 === OO || OO
      }
      agreeCounts() {
        return this.echoes.slice(0, -1).every((OO => OO.answered()))
      }
      age() {
        var OO, KO;
        return null !== (OO = null === (KO = this.echoes.at(-1)) || void 0 === KO ? void 0 : KO.age()) && void 0 !== OO ? OO : null
      }
      clear() {
        this.echoes = []
      }
    }
    class iV {
      constructor(OO) {
        this.send = OO, this.value = null, this.sent = null, this.echoes = new wF, this.down = !1, this.timer = null
      }
      shown(OO) {
        return null === this.value ? OO : this.down || this.value !== this.sent ? this.value : OO === this.sent && this.echoes.agreeCounts() || this.echoes.answered() ? (this.value = null, this.sent = null, this.echoes.clear(), OO) : this.value
      }
      pendingFor(OO) {
        return null !== this.value && this.value === this.sent && OO !== this.value ? this.echoes.age() : null
      }
      assume(OO, KO) {
        this.disarm(), this.down = !1, this.value = OO, this.sent = OO, this.echoes.clear(), this.echoes.add(KO)
      }
      press() {
        this.down = !0
      }
      drag(OO) {
        this.value = OO, this.arm(this.down ? 1e3 : 400)
      }
      release() {
        this.down = !1, this.flush()
      }
      flush() {
        this.disarm(), null !== this.value && this.value !== this.sent && (this.sent = this.value, this.echoes.add(this.send(this.value)))
      }
      clear() {
        this.disarm(), this.value = null, this.sent = null, this.echoes.clear(), this.down = !1
      }
      arm(OO) {
        this.disarm(), this.timer = setTimeout((() => {
          this.timer = null, this.flush()
        }), OO)
      }
      disarm() {
        null !== this.timer && (clearTimeout(this.timer), this.timer = null)
      }
    }
    class rV {
      constructor() {
        this.pending = new Map
      }
      set(OO, KO, pO) {
        var XO;
        const bK = null !== (XO = this.pending.get(OO)) && void 0 !== XO ? XO : {
          on: KO,
          echoes: new wF
        };
        bK.on = KO, bK.echoes.add(pO), this.pending.set(OO, bK)
      }
      shown(OO) {
        let KO = OO;
        for (const [pO, {
            on: XO,
            echoes: bK
          }] of this.pending) 0 !== (OO & pO) === XO && bK.agreeCounts() || bK.answered() ? this.pending.delete(pO) : KO = XO ? KO | pO : KO & ~pO;
        return KO
      }
      pendingMask() {
        let OO = 0;
        for (const KO of this.pending.keys()) OO |= KO;
        return OO
      }
      pendingFor(OO) {
        let KO = null;
        for (const [XO, {
            on: bK,
            echoes: eO
          }] of this.pending) {
          if (void 0 !== OO && 0 !== (OO & XO) === bK) continue;
          const lO = eO.age();
          var pO;
          if (null !== lO) KO = Math.max(null !== (pO = KO) && void 0 !== pO ? pO : 0, lO)
        }
        return KO
      }
      clear() {
        this.pending.clear()
      }
    }
    class PF {
      constructor() {
        this.dims = null, this.echoes = new wF, this.unmet = null
      }
      shown(OO) {
        var KO;
        return this.dims && (mV(this.dims, OO) && this.echoes.agreeCounts() || this.echoes.answered()) && (mV(this.dims, OO) || (this.unmet = this.dims), this.dims = null, this.echoes.clear()), null !== (KO = this.dims) && void 0 !== KO ? KO : OO
      }
      takeUnmet() {
        const OO = this.unmet;
        return this.unmet = null, OO
      }
      set(OO, KO) {
        this.dims = OO, this.echoes.add(KO)
      }
      pendingFor(OO) {
        return null === this.dims || OO && mV(this.dims, OO) ? null : this.echoes.age()
      }
      clear() {
        this.dims = null, this.unmet = null, this.echoes.clear()
      }
    }

    function mV(OO, KO) {
      return OO[0] === KO[0] && OO[1] === KO[1] && OO[2] === KO[2]
    }
    class sF {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : jV;
        this.now = OO, this.taps = new Map
      }
      tap(OO, KO, pO) {
        return !this.busy(OO) && (this.taps.set(OO, {
          at: this.now(),
          done: KO
        }), pO(), !0)
      }
      settle(OO) {
        for (const [KO, pO] of [...this.taps]) pO.done(OO) && this.taps.delete(KO)
      }
      busy(OO) {
        const KO = this.taps.get(OO);
        return !!KO && (!(this.now() - KO.at >= 3e3) || (this.taps.delete(OO), !1))
      }
      busyIds() {
        const OO = new Set;
        for (const KO of [...this.taps.keys()]) this.busy(KO) && OO.add(KO);
        return OO
      }
      clear() {
        this.taps.clear()
      }
    }

    function HF(OO) {
      return {
        send: KO => OO.track(KO),
        sendUrgent: (KO, pO) => OO.track(KO, {
          urgent: !0,
          supersedes: pO
        }),
        leftAt: KO => OO.leftAt(KO),
        holdReserve: () => OO.holdUrgentReserve(),
        answerMs: Nl
      }
    }

    function RF() {
      return performance.now()
    }

    function SF(OO) {
      const KO = OO.baf2RxNeed.map((OO => {
        let [KO, pO] = OO;
        return [KO, pO]
      }));
      return JSON.stringify([OO.baf2RxFormed, KO, OO.baf2RxBad, OO.baf2RxCells])
    }

    function JF(OO, KO) {
      const pO = 0 !== (KO & eK),
        XO = 0 !== (OO.baf2RxFlags & eK);
      return !pO || XO || "running" !== OO.baf2RxState && "idle" !== OO.baf2RxState ? !pO && XO && "scram" === OO.baf2RxState && OO.baf2RxFuel > 0 ? "idle" : OO.baf2RxState : "scram"
    }

    function cV(OO) {
      return JSON.stringify([OO.baf2BatFormed, OO.baf2BatNeed, OO.baf2BatBad])
    }

    function BF(OO) {
      return OO.join(",")
    }
    class ZF {
      constructor() {
        this.listeners = new Set
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      notify() {
        for (const OO of this.listeners) OO()
      }
      clear() {
        this.listeners.clear()
      }
    }
    class GF {
      constructor() {
        this.lastAt = -1 / 0, this.lastUntil = -1 / 0
      }
      heard(OO, KO) {
        this.lastAt = OO, this.lastUntil = OO + KO
      }
      answered(OO) {
        return this.lastAt >= OO || OO < this.lastUntil
      }
    }
    class qV {
      constructor(OO, KO) {
        this.link = OO, this.now = KO, this.hold = new PF, this.picked = null, this.notTaken = null
      }
      shown(OO) {
        const KO = this.hold.shown(OO);
        if (this.hold.takeUnmet() && this.picked) {
          var pO;
          const {
            plans: KO,
            ctrl: XO,
            at: bK
          } = this.picked;
          this.picked = null, KO.unpredict(XO), null === (pO = this.notTaken) || void 0 === pO || pO.call(this, OO, bK)
        }
        return KO
      }
      pendingFor(OO) {
        return this.hold.pendingFor(OO)
      }
      Kp(OO, KO, pO) {
        OO.predictSize(KO, pO), this.picked = {
          plans: OO,
          ctrl: KO,
          at: this.now()
        };
        const XO = this.link.send(bp(KO, "plan", ...pO));
        this.hold.set(pO, new YF(XO, this.link, this.link.answerMs, this.now))
      }
      clear() {
        this.hold.clear(), this.picked = null
      }
    }
    class xV {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : RF;
        this.plans = OO, this.readInterior = KO, this.link = pO, this.now = XO, this.view = null, this.raw = null, this.looksOf = null, this.odConfirmed = !1, this.startedAt = null, this.size = void 0, this.flags = new rV, this.throttle = void 0, this.oneShots = void 0, this.listeners = new ZF, this.redraw = null, this.releaseReserve = null, this.size = new qV(pO, XO), this.oneShots = new sF(XO), this.throttle = new iV((OO => this.echo(this.link.send(this.command("throttle", OO)))))
      }
      set(OO) {
        !OO.baf2RxOpen && this.raw && BF(this.raw.baf2RxAt) === BF(OO.baf2RxAt) || (this.size.clear(), this.flags.clear(), this.throttle.clear(), this.oneShots.clear(), this.startedAt = null), this.oneShots.settle(OO), this.pl(OO)
      }
      get() {
        return this.view
      }
      onSizeNotTaken(OO) {
        this.size.notTaken = OO
      }
      resize(OO) {
        this.raw && (this.size.Kp(this.plans, this.raw.baf2RxAt, OO), this.pl(this.raw))
      }
      toggleStarter() {
        if (!this.raw) return;
        const OO = this.raw.baf2RxAt;
        this.plans.setStarter(OO, !this.plans.showsStarter(OO)), this.pl(this.raw)
      }
      toggleGuide() {
        this.plans.setGuide(!this.plans.guideOn()), this.raw && this.pl(this.raw)
      }
      confirmOverdrive() {
        this.odConfirmed = !0, this.raw && this.pl(this.raw)
      }
      send(OO) {
        if (this.raw) {
          for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
          this.link.send(this.command(OO, ...pO))
        }
      }
      tap(OO, KO) {
        this.raw && this.oneShots.tap(OO, function(OO, KO) {
          if ("start" === OO) return OO => 0 === (OO.baf2RxFlags & eK);
          if ("odConfirm" === OO) return OO => 0 !== (OO.baf2RxFlags & lK);
          const pO = SF(KO);
          return OO => SF(OO) !== pO
        }(OO, this.raw), KO) && ("start" === OO && (this.startedAt = this.now()), this.pl(this.raw))
      }
      shutDown() {
        this.startGuard() || this.setFlag(eK, !0)
      }
      startGuard() {
        return null !== this.startedAt && this.now() - this.startedAt < 400
      }
      setFlag(OO, KO) {
        if (!this.raw) return;
        const pO = OO === eK ? this.command(KO ? "scram" : "start") : this.command("od", KO ? 1 : 0),
          XO = KO && OO === eK,
          bK = `${XK} ${this.raw.baf2RxAt.join(" ")} `,
          eO = this.echo(XO ? this.link.sendUrgent(pO, (OO => {
            const KO = OO.startsWith(bK) ? OO.slice(bK.length).split(" ")[0] : null;
            return "throttle" === KO || "start" === KO
          })) : this.link.send(pO));
        this.flags.set(OO, KO, eO), XO && this.throttle.assume(0, eO), this.pl(this.raw)
      }
      throttlePress() {
        this.throttle.press()
      }
      throttleDrag(OO) {
        this.throttle.drag(OO), this.raw && this.pl(this.raw)
      }
      throttleRelease() {
        this.throttle.release(), this.raw && this.pl(this.raw)
      }
      subscribe(OO) {
        return this.listeners.subscribe(OO)
      }
      opened() {
        this.releaseReserve ??= this.link.holdReserve()
      }
      closed() {
        var OO;
        this.throttle.release(), null === (OO = this.releaseReserve) || void 0 === OO || OO.call(this), this.releaseReserve = null
      }
      dispose() {
        this.closed(), this.throttle.clear(), this.flags.clear(), this.oneShots.clear(), null !== this.redraw && (clearTimeout(this.redraw), this.redraw = null), this.view = null, this.raw = null, this.looksOf = null, this.listeners.clear()
      }
      command(OO) {
        for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
        return bp(this.raw.baf2RxAt, OO, ...pO)
      }
      echo(OO) {
        return new YF(OO, this.link, this.link.answerMs, this.now)
      }
      pl(OO) {
        var KO;
        this.raw = OO;
        const pO = this.flags.shown(OO.baf2RxFlags),
          XO = {
            ...OO,
            baf2RxFlags: pO,
            baf2RxTarget: this.throttle.shown(OO.baf2RxTarget),
            baf2RxState: JF(OO, pO)
          },
          bK = this.size.shown(XO.baf2RxDims),
          eO = this.throttle.pendingFor(),
          lO = [this.throttle.pendingFor(OO.baf2RxTarget), this.flags.pendingFor(OO.baf2RxFlags), this.size.pendingFor(OO.baf2RxDims)].filter((OO => null !== OO)),
          vK = lO.length > 0 ? Math.max(...lO) : null,
          CO = this.oneShots.busyIds(),
          hO = XO.baf2RxAt;
        let DO, MO, aK = null,
          oO = [Math.max(0, bK[0] - 2), Math.max(0, bK[1] - 2), Math.max(0, bK[2] - 2)];
        if (XO.baf2RxFormed) {
          const [OO, KO, pO] = XO.baf2RxDims;
          oO = [Math.max(0, OO - 2), Math.max(0, KO - 2), Math.max(0, pO - 2)], DO = Array.from(XO.baf2RxCells, Number), MO = `${oO.join(",")}:${XO.baf2RxCells}`
        } else {
          var FO;
          const OO = null === (FO = this.plans.planAt(hO)) || void 0 === FO ? void 0 : FO.box,
            KO = OO ? mX(OO, "reactor", ...bK) : rX(hO, 1, ...bK, Pp("reactor", bK[0])),
            pO = this.readInterior(KO);
          aK = Bv(oO, pO), DO = pO, MO = `${oO.join(",")}:${pO.join("")}`
        }(null === (KO = this.looksOf) || void 0 === KO ? void 0 : KO.key) !== MO && (this.looksOf = {
          key: MO,
          looks: Wv(oO, DO)
        }), this.view = {
          status: XO,
          dims: bK,
          plan: aK,
          inner: oO,
          looks: this.looksOf.looks,
          starter: this.plans.showsStarter(hO),
          odConfirmed: this.odConfirmed || 0 !== (XO.baf2RxFlags & ap),
          guide: this.plans.guideOn(),
          throttlePending: null !== eO,
          pendingFlags: this.flags.pendingMask(),
          waiting: null !== vK && vK >= 5e3,
          busy: CO,
          startGuard: this.startGuard()
        }, this.listeners.notify(), (null !== vK || CO.size > 0 || this.startGuard()) && null === this.redraw && (this.redraw = setTimeout((() => {
          this.redraw = null, this.raw && this.pl(this.raw)
        }), 250))
      }
    }
    class nF {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : RF;
        this.plans = OO, this.view = null, this.size = void 0, this.oneShots = void 0, this.listeners = new ZF, this.redraw = null, this.size = new qV(KO, pO), this.oneShots = new sF(pO)
      }
      set(OO) {
        !OO.baf2BatOpen && this.view && BF(this.view.status.baf2BatAt) === BF(OO.baf2BatAt) || (this.size.clear(), this.oneShots.clear()), this.oneShots.settle(OO), this.pl(OO)
      }
      tap(OO, KO) {
        if (!this.view) return;
        const pO = cV(this.view.status);
        this.oneShots.tap(OO, (OO => cV(OO) !== pO), KO) && this.pl(this.view.status)
      }
      get() {
        return this.view
      }
      onSizeNotTaken(OO) {
        this.size.notTaken = OO
      }
      resize(OO) {
        this.view && (this.size.Kp(this.plans, this.view.status.baf2BatAt, OO), this.pl(this.view.status))
      }
      toggleGuide() {
        this.plans.setGuide(!this.plans.guideOn()), this.view && this.pl(this.view.status)
      }
      subscribe(OO) {
        return this.listeners.subscribe(OO)
      }
      dispose() {
        this.oneShots.clear(), null !== this.redraw && (clearTimeout(this.redraw), this.redraw = null), this.view = null, this.listeners.clear()
      }
      pl(OO) {
        const KO = this.size.shown(OO.baf2BatDims),
          pO = this.oneShots.busyIds();
        this.view = {
          status: OO,
          dims: KO,
          YO: DC(KO, OO.baf2BatDims) ? OO.baf2BatCapacity : Uv(...KO),
          guide: this.plans.guideOn(),
          busy: pO
        }, this.listeners.notify(), pO.size > 0 && null === this.redraw && (this.redraw = setTimeout((() => {
          this.redraw = null, this.view && this.pl(this.view.status)
        }), 250))
      }
    }
    const WF = "buildAFactory2Game:";

    function tV() {
      var OO;
      const KO = document.querySelector(".Baf2PanelOverlay .Baf2PanelHeader");
      if (!KO) return null;
      const pO = KO.querySelector(".ExitButton");
      return function(OO, KO) {
        const pO = KO ? KO.left - 8 : OO.right;
        return {
          left: OO.left,
          top: OO.top,
          width: Math.max(0, pO - OO.left),
          height: OO.height
        }
      }(KO.getBoundingClientRect(), null !== (OO = null === pO || void 0 === pO ? void 0 : pO.getBoundingClientRect()) && void 0 !== OO ? OO : null)
    }
    const kV = (0, XO.memo)((function(OO) {
      let {
        store: KO
      } = OO;
      const {
        t: pO
      } = (0, ze.D)(), [bK, eO] = (0, XO.useState)((() => KO.get())), [lO, vK] = (0, XO.useState)((() => performance.now()));
      (0, XO.useEffect)((() => (eO(KO.get()), KO.subscribe((() => {
        eO(KO.get()), vK(performance.now())
      })))), [KO]);
      const {
        alarm: CO,
        boomAt: hO
      } = bK, DO = null !== CO && null !== CO.secs, [MO, aK] = (0, XO.useState)(null);
      (0, XO.useEffect)((() => {
        if (!DO) return;
        aK(tV());
        const OO = setInterval((() => {
          vK(performance.now()), aK(tV())
        }), 250);
        return () => {
          clearInterval(OO)
        }
      }), [DO]);
      const [oO, FO] = (0, XO.useState)(!1);
      return (0, XO.useEffect)((() => {
        if (hO === -1 / 0) return;
        FO(!0);
        const OO = setTimeout((() => {
          FO(!1)
        }), 1300);
        return () => {
          clearTimeout(OO)
        }
      }), [hO]), (0, Ve.jsxs)(Ve.Fragment, {
        children: [null !== CO && (0, Ve.jsx)("div", {
          className: "Baf2RxSiren",
          role: "alert",
          children: pO(CO.hot ? `${WF}rxAlarmSiren` : `${WF}rxAlarmDamaged`, {
            amount: String(CO.damage)
          })
        }), null !== CO && null !== CO.secs && (0, Ve.jsx)("div", {
          className: MO ? "Baf2RxCountdown Docked" : "Baf2RxCountdown",
          style: null !== MO && void 0 !== MO ? MO : void 0,
          "aria-live": "assertive",
          children: pO(`${WF}rxAlarmCountdown`, {
            amount: String((VO = CO.secs, LO = lO - CO.receivedAt, Math.max(1, Math.ceil(VO - LO / 1e3))))
          })
        }), oO && (0, Ve.jsx)("div", {
          className: "Baf2RxBoom"
        })]
      });
      var VO, LO
    }));
    class UF {
      constructor() {
        this.byReactor = new Map, this.snapshot = {
          alarm: null,
          boomAt: -1 / 0
        }, this.listeners = new Set
      }
      YV(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : performance.now();
        const pO = OO.baf2RxAlarmAt.join(",");
        let XO = this.snapshot.boomAt;
        if (OO.baf2RxAlarmBoom) this.byReactor.delete(pO), XO = KO;
        else if (OO.baf2RxAlarmDamage <= 0) this.byReactor.delete(pO);
        else {
          var bK;
          this.byReactor.set(pO, {
            damage: OO.baf2RxAlarmDamage,
            secs: null !== (bK = OO.baf2RxAlarmSecs) && void 0 !== bK ? bK : null,
            hot: !0 === OO.baf2RxAlarmHot,
            receivedAt: KO
          })
        }
        this.pl(XO)
      }
      retain(OO) {
        let KO = !1;
        for (const pO of [...this.byReactor.keys()]) OO.has(pO) || (this.byReactor.delete(pO), KO = !0);
        KO && this.pl(this.snapshot.boomAt)
      }
      has(OO) {
        return this.byReactor.has(OO)
      }
      get() {
        return this.snapshot
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      dispose() {
        this.listeners.clear(), this.byReactor.clear()
      }
      pl(OO) {
        let KO = null;
        for (const pO of this.byReactor.values())(!KO || pO.damage > KO.damage) && (KO = pO);
        this.snapshot = {
          alarm: KO,
          boomAt: OO
        };
        for (const pO of this.listeners) pO()
      }
    }
    const OV = {
      formed: {
        colour: [1, 1, .85],
        ms: 1200,
        thick: .18
      },
      on: {
        colour: [.45, 1, .35],
        ms: 900,
        thick: .14
      }
    };

    function KV(OO) {
      return [OO[0], OO[1], OO[2]]
    }

    function pV(OO) {
      return `${OO[0]},${OO[1]},${OO[2]}`
    }
    class XV {
      constructor(OO) {
        if (this.plans = OO, this.flashedAt = 0, this.levels = new Map, this.glows = [], this.devLog = null, this.devAccessor = () => {
            var OO;
            return {
              active: this.glows.flatMap((OO => {
                let {
                  record: KO
                } = OO;
                return KO ? [KO] : []
              })),
              log: [...null !== (OO = this.devLog) && void 0 !== OO ? OO : []]
            }
          }, this.devLog && "undefined" !== typeof window) {
          window.baf2Glows = this.devAccessor
        }
      }
      glowLog() {
        var OO;
        return null !== (OO = this.devLog) && void 0 !== OO ? OO : []
      }
      check(OO, KO, pO) {
        const XO = new Set(KO.map((OO => pV(OO.box.ctrl))));
        for (const lO of function(OO, KO) {
            const pO = [],
              XO = new Map(OO);
            OO.clear();
            for (const bK of KO) {
              const KO = xF(bK.box.ctrl),
                eO = bK.formed ? bK.level : 0;
              OO.set(KO, eO), eO > 0 && 0 === XO.get(KO) && pO.push(bK)
            }
            return pO
          }(this.levels, this.plans.all())) XO.has(pV(lO.box.ctrl)) && this.show(OO, lO, "on", pO);
        const bK = this.plans.lastFormed();
        if (null === bK || bK.receivedAt <= this.flashedAt) return null;
        this.flashedAt = bK.receivedAt;
        const eO = function(OO, KO) {
          var pO;
          const XO = xF(OO);
          return null !== (pO = KO.find((OO => xF(OO.box.ctrl) === XO))) && void 0 !== pO ? pO : null
        }(bK.ctrl, KO);
        return eO && this.show(OO, eO, "formed", pO), eO
      }
      fade(OO, KO) {
        0 !== this.glows.length && (this.glows = this.glows.filter((pO => {
          let {
            mesh: XO,
            glow: bK,
            startMs: eO,
            record: lO
          } = pO;
          const vK = (KO - eO) / OV[bK].ms;
          return vK >= 1 ? (OO.disposeGameMesh(XO), lO && (lO.endMs = KO), !1) : (OO.setGameMesh(XO, {
            visibility: "formed" === bK ? 1 - vK : Math.sin(Math.PI * vK)
          }), !0)
        })))
      }
      dispose(OO) {
        for (const {
            mesh: pO
          }
          of this.glows) OO.disposeGameMesh(pO);
        this.glows = [], this.levels.clear();
        const KO = "undefined" !== typeof window ? window : null;
        (null === KO || void 0 === KO ? void 0 : KO.baf2Glows) === this.devAccessor && delete KO.baf2Glows
      }
      show(OO, KO, pO, XO) {
        const {
          lo: bK,
          hi: eO
        } = dC(KO.box);
        let lO = null;
        this.devLog && (lO = {
          glow: pO,
          ctrl: KV(KO.box.ctrl),
          lo: KV(bK),
          hi: KV(eO),
          startMs: XO,
          endMs: null
        }, this.devLog.push(lO), this.devLog.length > 64 && this.devLog.shift()), this.glows.push({
          mesh: this.build(OO, pO, TC(bK, eO, OV[pO].thick)),
          glow: pO,
          startMs: XO,
          record: lO
        })
      }
      build(OO, KO, pO) {
        const XO = OF(OO, pO, {
          rgb: OV[KO].colour,
          alpha: 1
        });
        return OO.setGameMesh(XO, {
          visibility: 0
        }), XO
      }
    }
    const bL = 1 / .6,
      eV = {
        colours: [
          [150, 150, 156],
          [104, 104, 110]
        ],
        alpha: .55,
        size: [.16, .3],
        life: [1.2, 2],
        power: [.3, .6],
        lift: .15,
        spread: .15,
        count: 1,
        blendMode: Iv.d.Standard,
        soft: !0
      },
      lV = {
        ...eV,
        size: [.25, .4],
        count: 2
      };

    function vL(OO) {
      return {
        colours: [OO, OO],
        alpha: 1,
        size: [.05, .08],
        life: [.4, .7],
        power: [.8, 1.4],
        lift: -3,
        spread: .6,
        count: 2,
        blendMode: Iv.d.Add,
        soft: !1
      }
    }
    const CV = vL([150, 225, 255]),
      hV = vL([185, 145, 255]),
      DV = ["Deep Drill", "Shatter Mill", "Sky Tap"];

    function MV(OO) {
      const KO = yp[OO];
      return null === KO.fuelSlot || WK(KO) ? DV.includes(OO) ? hV : CV : eV
    }
    const aL = {
        kind: "smokePuff"
      },
      oV = [.2, .025, .2];

    function FV(OO, KO) {
      const [
        [pO, XO, bK],
        [eO, lO, vK]
      ] = OO.colours;
      return {
        texture: OO.soft ? aL : "square_particle",
        YO: KO,
        minLifeTime: OO.life[0] / bL,
        maxLifeTime: OO.life[1] / bL,
        minEmitPower: OO.power[0] * bL,
        maxEmitPower: OO.power[1] * bL,
        minSize: OO.size[0],
        maxSize: OO.size[1],
        emitRate: 0,
        gravity: [0, OO.lift * bL * bL, 0],
        dir1: [-OO.spread, 1, -OO.spread],
        dir2: [OO.spread, 1, OO.spread],
        colorGradients: [{
          timeFraction: 0,
          minColor: [pO, XO, bK, OO.alpha],
          maxColor: [eO, lO, vK, OO.alpha]
        }, {
          timeFraction: 1,
          minColor: [pO, XO, bK, 0],
          maxColor: [eO, lO, vK, 0]
        }],
        blendMode: OO.blendMode
      }
    }
    class VV {
      constructor(OO) {
        this.fixed = OO, this.particles = new Map, this.lastFrame = -1, this.at = [0, 0, 0]
      }
      puff(OO, KO, pO) {
        var XO;
        if (pO === this.lastFrame) return !1;
        this.lastFrame = pO;
        const bK = this.at;
        bK[0] = KO[0] + .5, bK[1] = KO[1] + 1.025, bK[2] = KO[2] + .5;
        const eO = null !== (XO = this.fixed) && void 0 !== XO ? XO : vK() ? lV : eV;
        let lO = this.particles.get(eO);
        return lO || (lO = OO.createParticles(function(OO) {
          return FV(OO, Math.ceil(12 * OO.count * OO.life[1]) + OO.count)
        }(eO), {
          pos: bK,
          half: oV
        }), this.particles.set(eO, lO)), lO.moveTo(bK), lO.emit(eO.count), !0
      }
      dispose() {
        for (const OO of this.particles.values()) OO.stop();
        this.particles.clear()
      }
    }
    class LV {
      constructor() {
        this.pufferList = [], this.pufferIndexByStyle = new Map, this.pufferIndexById = new Uint8Array(65536), this.indexed = !1, this.hits = [], this.sources = [], this.found = [], this.origin = [0, 0, 0], this.scanRow = 0, this.cursor = 0, this.budget = 0, this.lastMs = 0, this.frame = 0
      }
      index(OO) {
        this.indexed = !0;
        for (const KO of fK) {
          const pO = MV(KO);
          for (let XO = 1; XO <= 4; XO++) {
            const bK = OO.blockNameToBlockId(`${KO}|meta|rot${XO}|Running`, !0);
            if (null === bK) continue;
            let eO = this.pufferIndexByStyle.get(pO);
            void 0 === eO && (eO = this.pufferList.push(new VV(pO === eV ? null : pO)) - 1, this.pufferIndexByStyle.set(pO, eO)), this.pufferIndexById[bK] = eO + 1
          }
        }
      }
      onAfterRender(OO, KO) {
        this.indexed || this.index(OO);
        const pO = performance.now(),
          XO = 0 === this.lastMs ? 0 : Math.min(pO - this.lastMs, 250) / 1e3;
        this.lastMs = pO, this.frame++, OO.particlesEnabled() ? (this.scan(OO, KO), this.puff(OO, XO)) : this.sources = []
      }
      dispose() {
        for (const OO of this.pufferList) OO.dispose();
        this.sources = [], this.found = []
      }
      scan(OO, KO) {
        0 === this.scanRow && (this.origin = [Math.floor(KO[0]) - 12, Math.floor(KO[1]) - 6, Math.floor(KO[2]) - 12]);
        const pO = Math.min(this.scanRow + 16, 325),
          [XO, bK, eO] = this.origin,
          lO = this.hits;
        lO.length = 0;
        for (let vK = this.scanRow; vK < pO; vK++) {
          const KO = XO + vK % 25,
            pO = bK + Math.floor(vK / 25);
          OO.scanBlocks(KO, pO, eO, KO + 1, pO + 1, eO + 25, this.pufferIndexById, lO)
        }
        for (let vK = 0; vK < lO.length; vK += 4) {
          const OO = lO[vK + 3];
          this.found.push({
            pos: [lO[vK], lO[vK + 1], lO[vK + 2]],
            yl: OO,
            puffer: this.pufferList[this.pufferIndexById[OO] - 1]
          })
        }
        this.scanRow = pO, 325 === pO && (this.sources = this.found, this.found = [], this.scanRow = 0)
      }
      puff(OO, KO) {
        const pO = this.sources.length;
        if (0 !== pO) {
          this.budget = Math.min(this.budget + Math.min(pO / 1.2, 12) * KO, 2);
          for (let KO = 0; KO < pO && this.budget >= 1; KO++) {
            const KO = this.sources[this.cursor % pO];
            this.cursor = (this.cursor + 1) % pO, OO.getBlockId(KO.pos[0], KO.pos[1], KO.pos[2]) === KO.yl && (KO.puffer.puff(OO, KO.pos, this.frame) && this.budget--)
          }
        } else this.budget = 0
      }
    }
    const QV = {
        ...vL([190, 255, 150]),
        size: [.16, .26],
        life: [.6, 1],
        power: [1, 1.8],
        count: 5
      },
      zL = [
        [1, 0, 0],
        [-1, 0, 0],
        [0, 1, 0],
        [0, -1, 0],
        [0, 0, 1],
        [0, 0, -1]
      ];

    function AV(OO) {
      return 0 === OO.spots.length ? 0 : Math.min(1 * OO.level, 4)
    }

    function fV(OO) {
      return 0 === OO.glass.length ? 0 : Math.min(.75 * OO.level, 3)
    }

    function dV(OO) {
      return `${OO.ctrl.join(",")}:${OO.rot}:${OO.cu},${OO.cv}:${OO.w},${OO.h},${OO.d}`
    }

    function TV(OO, KO) {
      const pO = KO.w - 2,
        XO = KO.h - 2,
        bK = KO.d - 2,
        eO = [];
      for (let lO = 0; lO < pO * XO * bK; lO++) {
        const vK = lO % pO,
          CO = Math.floor(lO / pO) % bK,
          hO = Math.floor(lO / (pO * bK));
        if (vK > 0 && vK < pO - 1 && CO > 0 && CO < bK - 1 && hO > 0 && hO < XO - 1) continue;
        const DO = Bp(KO, xX(KO, lO)),
          MO = QF(OO, DO);
        if (null !== MO && "Fuel Rod" === Tp(MO))
          for (const KO of zL) {
            const pO = [DO[0] + KO[0], DO[1] + KO[1], DO[2] + KO[2]];
            IV(OO, pO) && eO.push(yL(pO, KO))
          }
      }
      return eO
    }

    function NV(OO, KO) {
      const {
        lo: pO,
        hi: XO
      } = dC(KO), bK = [];
      for (let eO = pO[0]; eO < XO[0]; eO++)
        for (let KO = pO[1]; KO < XO[1]; KO++) {
          const lO = eO === pO[0] || eO === XO[0] - 1 || KO === pO[1] || KO === XO[1] - 1 ? 1 : Math.max(1, XO[2] - 1 - pO[2]);
          for (let vK = pO[2]; vK < XO[2]; vK += lO) {
            const lO = [eO, KO, vK];
            if (!IV(OO, lO)) continue;
            const CO = eO === pO[0] ? zL[1] : eO === XO[0] - 1 ? zL[0] : vK === pO[2] ? zL[5] : vK === XO[2] - 1 ? zL[4] : KO === pO[1] ? zL[3] : zL[2];
            bK.push(yL(lO, CO))
          }
        }
      return bK
    }

    function IV(OO, KO) {
      const pO = QF(OO, KO);
      return null !== pO && "Reactor Glass" === Tp(pO)
    }

    function yL(OO, KO) {
      return [
        [OO[0] + .5 + .55 * KO[0], OO[1] + .5 + .55 * KO[1], OO[2] + .5 + .55 * KO[2]],
        [0 === KO[0] ? .4 : .02, 0 === KO[1] ? .4 : .02, 0 === KO[2] ? .4 : .02]
      ]
    }
    class gL {
      constructor() {
        this.sparking = [], this.spots = new Map, this.emitter = null, this.lastFrame = -1
      }
      update(OO, KO, pO, XO) {
        const bK = [],
          eO = new Set;
        for (const hO of KO) {
          var lO, vK, CO;
          const {
            box: KO
          } = hO;
          if ("reactor" !== hO.kind || hO.level <= 0 || (KO.ctrl[0] - pO[0]) ** 2 + (KO.ctrl[1] - pO[1]) ** 2 + (KO.ctrl[2] - pO[2]) ** 2 > 576) continue;
          const DO = dV(KO);
          eO.add(DO);
          let MO = this.spots.get(DO);
          if ((!MO || XO - MO.at > 3e3) && (MO = {
              at: XO,
              spots: TV(OO, KO),
              glass: NV(OO, KO)
            }, this.spots.set(DO, MO)), 0 === MO.spots.length && 0 === MO.glass.length) continue;
          const aK = this.sparking.find((OO => OO.key === DO));
          bK.push({
            key: DO,
            level: hO.level,
            spots: MO.spots,
            glass: MO.glass,
            budget: null !== (lO = null === aK || void 0 === aK ? void 0 : aK.budget) && void 0 !== lO ? lO : 0,
            cursor: null !== (vK = null === aK || void 0 === aK ? void 0 : aK.cursor) && void 0 !== vK ? vK : 0,
            glassBudget: null !== (CO = null === aK || void 0 === aK ? void 0 : aK.glassBudget) && void 0 !== CO ? CO : 0
          })
        }
        for (const hO of this.spots.keys()) eO.has(hO) || this.spots.delete(hO);
        this.sparking = bK
      }
      emit(OO, KO, pO) {
        var XO;
        if (0 === this.sparking.length || !OO.particlesEnabled() || pO === this.lastFrame) return;
        this.lastFrame = pO;
        let bK = 0,
          eO = 0;
        for (const FO of this.sparking) bK += AV(FO), eO += fV(FO);
        const lO = bK > 8 ? 8 / bK : 1,
          vK = eO > 6 ? 6 / eO : 1;
        let CO, hO = null,
          DO = null;
        for (const FO of this.sparking) FO.budget = Math.min(FO.budget + AV(FO) * lO * KO, 2), FO.budget >= 1 && (!hO || FO.budget > hO.budget) && (hO = FO), FO.glassBudget = Math.min(FO.glassBudget + fV(FO) * vK * KO, 2), FO.glassBudget >= 1 && (!DO || FO.glassBudget > DO.glassBudget) && (DO = FO);
        if (hO) hO.budget--, CO = hO.spots[hO.cursor++ % hO.spots.length];
        else {
          if (!DO) return;
          DO.glassBudget--, CO = DO.glass[Math.floor(Math.random() * DO.glass.length)]
        }
        const [MO, aK] = CO, oO = null !== (XO = this.emitter) && void 0 !== XO ? XO : this.create(OO, MO, aK);
        oO.moveTo(MO, aK), oO.emit(QV.count)
      }
      dispose() {
        var OO;
        null === (OO = this.emitter) || void 0 === OO || OO.dispose(), this.emitter = null, this.sparking = [], this.spots.clear()
      }
      create(OO, KO, pO) {
        const XO = Math.ceil(14 * QV.count * QV.life[1]) + QV.count;
        return this.emitter = OO.createParticles(FV(QV, XO), {
          pos: KO,
          half: pO
        }), this.emitter
      }
    }
    const uV = [2, 3.2],
      EV = 1 / 3,
      jL = 1 / .6,
      YV = {
        texture: aL,
        YO: Math.ceil(18 * uV[1]) + 4,
        minLifeTime: uV[0] / jL,
        maxLifeTime: uV[1] / jL,
        minEmitPower: 1,
        maxEmitPower: 1.8333333333333335,
        minSize: .5,
        maxSize: .9,
        emitRate: 0,
        gravity: [0, .6944444444444445, 0],
        dir1: [-.2, 1, -.2],
        dir2: [.2, 1, .2],
        colorGradients: [{
          timeFraction: 0,
          minColor: [235, 245, 240, .55],
          maxColor: [215, 232, 226, .5]
        }, {
          timeFraction: 1,
          minColor: [235, 245, 240, 0],
          maxColor: [215, 232, 226, 0]
        }],
        blendMode: Iv.d.Standard
      };
    class wV {
      constructor(OO) {
        this.plans = OO, this.lastCheckMs = -1 / 0, this.outline = void 0, this.plumes = [], this.plumeBudget = 0, this.plumeCursor = 0, this.lastMs = 0, this.steam = null, this.hums = new Map, this.sparks = new gL, this.frame = 0, this.outline = new XV(OO)
      }
      onAfterRender(OO, KO, pO) {
        const XO = performance.now(),
          bK = 0 === this.lastMs ? 0 : Math.min(XO - this.lastMs, 250) / 1e3;
        if (this.lastMs = XO, this.outline.fade(OO, XO), this.puff(OO, bK, pO), this.sparks.emit(OO, bK, this.frame++), XO - this.lastCheckMs < 150) return;
        this.lastCheckMs = XO;
        const eO = this.plans.all().filter((OO => OO.formed && iL(OO.box.ctrl, pO) <= 4096));
        this.plumes = eO.filter((OO => "reactor" === OO.kind && OO.level > 0)).map((OO => ({
          box: OO.box,
          level: OO.level
        }))), this.updateHums(OO, KO, eO, pO), this.sparks.update(OO, eO, pO, XO), this.chimeFormed(OO, KO, eO, XO)
      }
      dispose(OO) {
        var KO;
        this.outline.dispose(OO), null === (KO = this.steam) || void 0 === KO || KO.dispose(), this.steam = null, this.sparks.dispose();
        for (const pO of this.hums.values()) pO.stop();
        this.hums.clear()
      }
      chimeFormed(OO, KO, pO, XO) {
        const bK = this.outline.check(OO, pO, XO);
        bK && OO.playSound(KO, "exp_levelup", .6, 1, {
          I9: [bK.box.ctrl[0] + .5, bK.box.ctrl[1], bK.box.ctrl[2] + .5],
          maxHearDist: 64
        })
      }
      puff(OO, KO, pO) {
        const XO = this.plumes;
        if (0 === XO.length || !OO.particlesEnabled()) return void(this.plumeBudget = 0);
        const bK = XO.reduce(((OO, KO) => OO + 3 * KO.level), 0);
        if (this.plumeBudget = Math.min(this.plumeBudget + bK * KO, 3), this.plumeBudget < 1) return;
        this.plumeBudget--;
        let eO = this.plumeCursor % (bK / 3);
        this.plumeCursor++;
        let lO = XO[0];
        for (const MO of XO) {
          if (eO < MO.level) {
            lO = MO;
            break
          }
          eO -= MO.level
        }
        const {
          lo: vK,
          hi: CO
        } = dC(lO.box);
        if (function(OO, KO, pO) {
            const XO = Math.max(OO[0] - pO[0], 0, pO[0] - KO[0]),
              bK = Math.max(OO[2] - pO[2], 0, pO[2] - KO[2]);
            return Math.hypot(XO, pO[1] - KO[1], bK)
          }(vK, CO, pO) < 6 && Math.random() > EV) return;
        const hO = [(vK[0] + CO[0]) / 2, CO[1] + .05, (vK[2] + CO[2]) / 2],
          DO = [(CO[0] - vK[0]) / 2 - .5, .05, (CO[2] - vK[2]) / 2 - .5];
        this.steam ??= OO.createParticles(YV, {
          pos: hO,
          half: DO
        }), this.steam.moveTo(hO, DO), this.steam.emit(1)
      }
      updateHums(OO, KO, pO, XO) {
        const bK = new Map;
        for (const lO of pO) "reactor" === lO.kind && lO.level > 0 && iL(lO.box.ctrl, XO) <= 576 && bK.set(`${eO=lO.box.ctrl,`${eO[0]},${eO[1]},${eO[2]}`}:${lO.level}`, lO);
        var eO;
        for (const [lO, vK] of this.hums) bK.has(lO) || (vK.stop(), this.hums.delete(lO));
        for (const [lO, vK] of bK) {
          if (this.hums.has(lO)) continue;
          const {
            lo: pO,
            hi: XO
          } = dC(vK.box), bK = [(pO[0] + XO[0]) / 2, pO[1], (pO[2] + XO[2]) / 2], eO = OO.playSound(KO, "rocketEngineLoop", .08 + .06 * vK.level, .55, {
            I9: bK,
            maxHearDist: 26,
            refDistance: 4
          }, !0);
          eO && this.hums.set(lO, eO)
        }
      }
    }

    function iL(OO, KO) {
      return (OO[0] - KO[0]) ** 2 + (OO[1] - KO[1]) ** 2 + (OO[2] - KO[2]) ** 2
    }
    class rL {
      constructor() {
        this.snapshot = {
          fuse: null,
          blast: null
        }, this.listeners = new Set
      }
      YV(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : performance.now();
        const XO = [OO.baf2BombAt[0], OO.baf2BombAt[1], OO.baf2BombAt[2]],
          bK = OO.baf2BombR;
        if (OO.baf2BombBoom) {
          const OO = Math.hypot(KO[0] - XO[0], KO[1] - XO[1], KO[2] - XO[2]);
          this.pl({
            fuse: null,
            blast: {
              at: XO,
              r: bK,
              receivedAt: pO,
              distance: OO,
              flash: OO <= 3 * bK
            }
          })
        } else this.pl({
          ...this.snapshot,
          fuse: OO.baf2BombMs > 0 ? {
            at: XO,
            r: bK,
            endsAt: pO + OO.baf2BombMs
          } : null
        })
      }
      get() {
        return this.snapshot
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      dispose() {
        this.listeners.clear(), this.snapshot = {
          fuse: null,
          blast: null
        }
      }
      pl(OO) {
        this.snapshot = OO;
        for (const KO of this.listeners) KO()
      }
    }
    const PV = (0, XO.memo)((function(OO) {
      var KO;
      let {
        store: pO
      } = OO;
      const {
        t: bK
      } = (0, ze.D)(), [eO, lO] = (0, XO.useState)((() => pO.get())), [vK, CO] = (0, XO.useState)((() => performance.now()));
      (0, XO.useEffect)((() => (lO(pO.get()), pO.subscribe((() => {
        lO(pO.get()), CO(performance.now())
      })))), [pO]);
      const {
        fuse: hO,
        blast: DO
      } = eO;
      (0, XO.useEffect)((() => {
        if (!hO) return;
        const OO = setInterval((() => {
          CO(performance.now())
        }), 250);
        return () => {
          clearInterval(OO)
        }
      }), [hO]);
      const [MO, aK] = (0, XO.useState)(!1);
      (0, XO.useEffect)((() => {
        if (null === DO || void 0 === DO || !DO.flash) return;
        aK(!0);
        const OO = setTimeout((() => {
          aK(!1)
        }), 2500);
        return () => {
          clearTimeout(OO)
        }
      }), [DO]);
      const oO = hO ? function(OO, KO) {
        return OO.endsAt <= KO ? 0 : Math.ceil((OO.endsAt - KO) / 1e3)
      }(hO, vK) : 0;
      return (0, Ve.jsxs)(Ve.Fragment, {
        children: [oO > 0 && (0, Ve.jsx)("div", {
          className: "Baf2RxSiren Baf2BombSiren",
          role: "alert",
          children: bK("buildAFactory2Game:bombCountdown", {
            amount: String(oO),
            radius: String(null !== (KO = null === hO || void 0 === hO ? void 0 : hO.r) && void 0 !== KO ? KO : 0)
          })
        }), MO && (0, Ve.jsx)("div", {
          className: "Baf2RxBoom Baf2BombFlash"
        })]
      })
    }));

    function mL(OO) {
      const KO = Math.min(4, Math.max(1, OO / 32));
      return {
        capHeight: Math.min(160, Math.max(40, 5 * OO / 4)),
        capSpread: Math.min(5 * OO / 8, 24 * KO),
        capThick: 6 * KO,
        stemHalfWidth: 3 * KO,
        puffScale: KO
      }
    }
    class sV {
      constructor() {
        this.JK = !1
      }
      hold(OO) {
        OO.getCameraFar() < 1e3 && (OO.setCameraFar(1e3), this.JK = !0)
      }
      release(OO) {
        this.JK && (this.JK = !1, OO.setCameraFar(null))
      }
    }
    const HV = 1 / .6,
      RV = [.2, .1, .2],
      SV = [
        ["cannonFire1", 1, .3],
        ["cannonFire2", .8, .25]
      ],
      JV = {
        count: 200,
        fromMs: 0,
        toMs: 2e4,
        life: [8, 10],
        size: [3, 5],
        blend: Iv.d.Standard,
        from: [
          [255, 170, 60, .95],
          [255, 120, 40, .9]
        ],
        to: [
          [90, 85, 80, 0],
          [70, 66, 62, 0]
        ],
        gravity: 0
      },
      cL = {
        count: 280,
        fromMs: 2e3,
        toMs: 2e4,
        life: [10, 12],
        size: [7, 11],
        blend: Iv.d.Standard,
        from: [
          [255, 190, 110, .9],
          [200, 150, 110, .85]
        ],
        to: [
          [80, 76, 72, 0],
          [60, 58, 56, 0]
        ],
        gravity: .08
      },
      BV = {
        count: 100,
        fromMs: 0,
        toMs: 900,
        life: [4, 5.5],
        size: [2, 3.5],
        blend: Iv.d.Standard,
        from: [
          [220, 200, 160, .85],
          [200, 180, 140, .8]
        ],
        to: [
          [170, 150, 120, 0],
          [150, 130, 110, 0]
        ],
        gravity: 0
      },
      ZV = {
        texture: aL,
        YO: Math.ceil(120) + 4,
        minLifeTime: 1.62,
        maxLifeTime: 1.7999999999999998,
        minEmitPower: 33.333333333333336,
        maxEmitPower: 33.333333333333336,
        minSize: .6,
        maxSize: 1,
        emitRate: 0,
        colorGradients: [{
          timeFraction: 0,
          minColor: [140, 255, 100, .95],
          maxColor: [90, 255, 120, .9]
        }, {
          timeFraction: 1,
          minColor: [60, 200, 80, 0],
          maxColor: [40, 160, 60, 0]
        }],
        blendMode: Iv.d.Add
      };
    class GV {
      constructor(OO) {
        this.store = OO, this.beacon = null, this.beaconBudget = 0, this.streams = [], this.cloud = null, this.shownBlast = null, this.lastMs = 0, this.ringAngle = 0, this.far = new sV, this.timers = []
      }
      onAfterRender(OO, KO) {
        const pO = performance.now(),
          XO = 0 === this.lastMs ? 0 : Math.min(pO - this.lastMs, 250) / 1e3;
        this.lastMs = pO;
        const {
          fuse: bK,
          blast: eO
        } = this.store.get();
        null !== eO && eO !== this.shownBlast && (this.shownBlast = eO, this.startBlast(OO, KO, eO, pO));
        const lO = OO.particlesEnabled();
        null !== bK && bK.endsAt > pO && lO ? this.emitBeacon(OO, bK, XO, pO) : this.beaconBudget = 0, null !== this.cloud && (pO - this.cloud.startMs > 33e3 ? this.disposeCloud(OO) : (this.far.hold(OO), lO && this.emitCloud(OO, XO, pO)))
      }
      dispose(OO) {
        var KO;
        null === (KO = this.beacon) || void 0 === KO || KO.dispose(), this.beacon = null, this.disposeCloud(OO);
        for (const pO of this.timers) clearTimeout(pO);
        this.timers.length = 0
      }
      emitBeacon(OO, KO, pO, XO) {
        const bK = KO.endsAt - XO < 5e3 ? 350 : 1e3,
          eO = .5 + .5 * Math.sin(2 * Math.PI * XO / bK);
        if (this.beaconBudget = Math.min(this.beaconBudget + 40 * eO * pO, 4), this.beaconBudget < 1) return;
        const lO = Math.floor(this.beaconBudget);
        this.beaconBudget -= lO;
        const [vK, CO, hO] = KO.at, DO = [vK + .5, CO + 1.1, hO + .5];
        this.beacon ??= OO.createParticles(ZV, {
          pos: DO,
          half: RV
        }), this.beacon.moveTo(DO), this.beacon.emit(lO)
      }
      startBlast(OO, KO, pO, XO) {
        var bK;
        null === (bK = this.beacon) || void 0 === bK || bK.dispose(), this.beacon = null, this.disposeCloud(OO);
        const eO = (0, Tv.isMobile)() ? .5 : 1;
        this.streams = [JV, cL, BV].map((OO => {
          const KO = Math.round(OO.count * eO);
          return {
            spec: OO,
            particles: null,
            rate: KO / ((OO.toMs - OO.fromMs) / 1e3),
            budget: 0,
            left: KO
          }
        })), this.cloud = {
          blast: pO,
          startMs: XO
        };
        const lO = Math.max(.25, 1 - pO.distance / (6 * pO.r)),
          vK = pO.distance / 150 * 1e3;
        this.timers.push(setTimeout((() => {
          for (const [pO, XO, bK] of SV) xL(OO, KO, pO, lO * XO, bK)
        }), vK))
      }
      emitCloud(OO, KO, pO) {
        const {
          blast: XO,
          startMs: bK
        } = this.cloud, eO = pO - bK, [lO, vK, CO] = XO.at, hO = mL(XO.r);
        for (const DO of this.streams) {
          const {
            spec: pO
          } = DO;
          if (DO.left <= 0 || eO < pO.fromMs) continue;
          DO.budget += DO.rate * KO;
          const bK = Math.min(Math.floor(DO.budget), DO.left);
          if (bK < 1) continue;
          DO.budget -= bK, DO.left -= bK;
          const MO = DO.particles ??= this.createStream(OO, pO, XO);
          if (pO === JV) {
            const OO = hO.stemHalfWidth;
            MO.moveTo([lO, vK + 1, CO], [OO, 1, OO])
          } else if (pO === cL) {
            const OO = hO.capSpread * Math.min(1, (eO - pO.fromMs) / 3e3),
              KO = Math.sqrt(Math.random()),
              XO = 2 * Math.random() * Math.PI,
              bK = Math.cos(XO) * KO,
              DO = Math.sin(XO) * KO,
              aK = lO + bK * OO,
              oO = CO + DO * OO,
              FO = hO.capThick,
              VO = vK + hO.capHeight + FO * (1 - KO * KO) * 2;
            MO.setDirections([.7 * bK, .05, .7 * DO], [bK, .2, DO]), MO.moveTo([aK, VO, oO], [FO, FO, FO])
          } else {
            this.ringAngle += 2.39996;
            const OO = Math.cos(this.ringAngle),
              KO = Math.sin(this.ringAngle);
            MO.setDirections([OO, .05, KO], [OO, .1, KO]), MO.moveTo([lO + 2 * OO, vK + .5, CO + 2 * KO], [0, .5, 0])
          }
          MO.emit(bK)
        }
      }
      createStream(OO, KO, pO) {
        const {
          r: XO
        } = pO, bK = Math.max(KO.life[0], XO / 25), eO = KO === BV ? [.9 * bK, bK] : KO.life, lO = mL(XO), vK = KO === BV ? 1 : lO.puffScale, CO = {
          texture: aL,
          YO: KO.count + 4,
          minLifeTime: eO[0] / HV,
          maxLifeTime: eO[1] / HV,
          minSize: KO.size[0] * vK,
          maxSize: KO.size[1] * vK,
          minEmitPower: 0,
          maxEmitPower: 0,
          emitRate: 0,
          gravity: [0, KO.gravity * HV * HV, 0],
          colorGradients: [{
            timeFraction: 0,
            minColor: KO.from[0],
            maxColor: KO.from[1]
          }, {
            timeFraction: .6,
            minColor: qL(KO.from[0], KO.to[0]),
            maxColor: qL(KO.from[1], KO.to[1])
          }, {
            timeFraction: 1,
            minColor: KO.to[0],
            maxColor: KO.to[1]
          }],
          blendMode: KO.blend
        };
        if (KO === JV) {
          const OO = lO.capHeight / ((eO[0] + eO[1]) / 2);
          CO.minEmitPower = .9 * OO * HV, CO.maxEmitPower = 1.05 * OO * HV, CO.dir1 = [-.1, 1, -.1], CO.dir2 = [.1, 1, .1]
        } else KO === cL ? (CO.minEmitPower = 1.2, CO.maxEmitPower = 2, CO.dir1 = [-1, .05, -1], CO.dir2 = [1, .2, 1]) : (CO.minEmitPower = 39.583333333333336, CO.maxEmitPower = 41.66666666666667, CO.dir1 = [1, 0, 0], CO.dir2 = [1, 0, 0]);
        return OO.createParticles(CO, {
          pos: pO.at
        })
      }
      disposeCloud(OO) {
        for (const pO of this.streams) {
          var KO;
          null === (KO = pO.particles) || void 0 === KO || KO.dispose()
        }
        this.streams = [], this.cloud = null, this.far.release(OO)
      }
    }

    function qL(OO, KO) {
      return [(OO[0] + KO[0]) / 2, (OO[1] + KO[1]) / 2, (OO[2] + KO[2]) / 2, .75 * OO[3]]
    }

    function xL(OO, KO, pO, XO, bK) {
      try {
        OO.playSound(KO, pO, XO, bK)
      } catch (eO) {
        console.error(eO)
      }
    }
    const nV = {
        YO: 720,
        perS: 100
      },
      WV = {
        YO: 320,
        perS: 44
      };
    class tL {
      constructor() {
        this.zone = null, this.endsAt = 0
      }
      start(OO, KO) {
        this.zone = {
          centre: [...OO.centre],
          r: OO.r,
          band: OO.band ? [OO.band[0], OO.band[1]] : void 0
        }, this.endsAt = KO
      }
      stop() {
        this.zone = null
      }
      YV(OO, KO) {
        const {
          baf2FalloutMs: pO,
          baf2FalloutAt: XO,
          baf2FalloutR: bK,
          baf2FalloutY: eO
        } = OO;
        pO > 0 && XO && void 0 !== bK ? this.start({
          centre: XO,
          r: bK,
          band: eO
        }, KO + pO) : this.stop()
      }
      perS(OO, KO, pO) {
        const XO = this.zone;
        if (!XO) return 0;
        const bK = this.endsAt - OO;
        return bK <= 0 ? (this.zone = null, 0) : XO.band && (KO[1] < XO.band[0] || KO[1] > XO.band[1]) || Math.hypot(KO[0] - XO.centre[0], KO[2] - XO.centre[2]) > XO.r ? 0 : pO.perS * Math.min(1, bK / 5e3)
      }
    }
    const kL = [5, 7],
      UV = [24, 8, 24],
      OL = .5,
      KL = 1 / .6,
      pL = [{
        rgba: [150, 150, 140, .85],
        share: .7
      }, {
        rgba: [120, 225, 90, .9],
        share: .3
      }];
    class XL {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, Tv.isMobile)();
        this.state = new tL, this.tier = void 0, this.systems = null, this.budget = 0, this.lastMs = 0, this.at = [0, 0, 0], this.amounts = [0, 0], this.tier = function(OO) {
          return OO ? WV : nV
        }(OO)
      }
      startFallout(OO, KO) {
        this.state.start(OO, KO)
      }
      stopFallout() {
        this.state.stop()
      }
      YV(OO) {
        this.state.YV(OO, performance.now())
      }
      onAfterRender(OO, KO) {
        var pO;
        const XO = performance.now(),
          bK = 0 === this.lastMs ? 0 : Math.min(XO - this.lastMs, 250) / 1e3;
        this.lastMs = XO;
        const eO = this.state.perS(XO, KO, this.tier);
        if (eO <= 0 || !OO.particlesEnabled()) return void(this.budget = 0);
        this.budget = Math.min(this.budget + eO * bK, eO / 4);
        const lO = Math.floor(this.budget);
        if (lO < 1) return;
        this.budget -= lO;
        const vK = this.at;
        vK[0] = KO[0], vK[1] = KO[1] + 12, vK[2] = KO[2];
        const CO = null !== (pO = this.systems) && void 0 !== pO ? pO : this.create(OO, vK),
          hO = this.amounts;
        hO[0] = 0, hO[1] = 0;
        for (let DO = 0; DO < lO; DO++) hO[Math.random() < .3 ? 1 : 0]++;
        for (let DO = 0; DO < CO.length; DO++) hO[DO] > 0 && (CO[DO].moveTo(vK, UV), CO[DO].emit(hO[DO]))
      }
      dispose() {
        for (const KO of null !== (OO = this.systems) && void 0 !== OO ? OO : []) {
          var OO;
          KO.dispose()
        }
        this.systems = null, this.state.stop()
      }
      create(OO, KO) {
        return this.systems = pL.map((pO => {
          let {
            rgba: [XO, bK, eO, lO],
            share: vK
          } = pO;
          const CO = {
            texture: "square_particle",
            YO: Math.ceil(this.tier.YO * vK),
            minLifeTime: kL[0] / KL,
            maxLifeTime: kL[1] / KL,
            minEmitPower: 1.3333333333333335,
            maxEmitPower: 1.3333333333333335,
            minSize: .16,
            maxSize: .36,
            emitRate: 0,
            gravity: [0, 0, 0],
            dir1: [-.5, -1, -.5],
            dir2: [OL, -1, OL],
            colorGradients: [{
              timeFraction: 0,
              minColor: [XO, bK, eO, 0]
            }, {
              timeFraction: .15,
              minColor: [XO, bK, eO, lO]
            }, {
              timeFraction: .8,
              minColor: [XO, bK, eO, lO]
            }, {
              timeFraction: 1,
              minColor: [XO, bK, eO, 0]
            }],
            blendMode: Iv.d.Standard
          };
          return OO.createParticles(CO, {
            pos: KO,
            half: UV
          })
        })), this.systems
      }
    }
    const bQ = {
      1: [0, 0, 1],
      2: [1, 0, 0],
      3: [0, 0, -1],
      4: [-1, 0, 0]
    };

    function eL(OO) {
      const KO = /\|rot(\d)/.exec(OO);
      return bQ[KO ? Number(KO[1]) : 1]
    }
    var lL = pO(524),
      vQ = pO(36873);
    const CL = new Set(lL.k);

    function hL(OO) {
      if (-2 !== OO.count) return null;
      const KO = BO(OO.item);
      return null !== KO && CL.has(KO) ? KO : null
    }

    function DL(OO) {
      const {
        width: KO,
        height: pO
      } = (0, vQ.c)(OO).hitBoxDimensions;
      return .55 / Math.max(KO, pO)
    }

    function ML(OO, KO, pO) {
      if (!pO) return !1;
      const XO = OO[0] + .5 - KO[0],
        bK = OO[1] + .5 - KO[1],
        eO = OO[2] + .5 - KO[2];
      return XO * XO + bK * bK + eO * eO <= 576
    }

    function aQ(OO, KO) {
      return Math.atan2(OO[0], OO[2]) + Math.PI + KO
    }

    function oL(OO, KO) {
      const pO = 2 * Math.PI;
      return (OO + pO * KO / 1e4) % pO
    }
    class FL {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => performance.now();
        this.labels = OO, this.now = KO, this.farms = new Map, this.unsubscribe = void 0, this.checkedMs = -1 / 0, this.frameMs = NaN, this.unsubscribe = OO.subscribe((() => {
          this.sync()
        }))
      }
      onAfterRender(OO, KO) {
        if (0 === this.farms.size) return;
        const pO = this.now(),
          XO = Number.isNaN(this.frameMs) ? 0 : Math.min(pO - this.frameMs, 100);
        this.frameMs = pO, pO - this.checkedMs >= 1e3 && (this.checkedMs = pO, this.check(OO, KO));
        for (const bK of this.farms.values()) bK.shown && bK.running && null !== bK.model && XO > 0 && (bK.spin = oL(bK.spin, XO), bK.model.setPose(bK.feet, aQ(bK.front, bK.spin)))
      }
      dispose() {
        this.unsubscribe();
        for (const OO of this.farms.values()) this.drop(OO);
        this.farms.clear()
      }
      sync() {
        const OO = new Set;
        for (const KO of this.labels.list()) {
          const pO = hL(KO);
          if (null === pO) continue;
          OO.add(KO.key);
          const XO = this.farms.get(KO.key);
          if ((null === XO || void 0 === XO ? void 0 : XO.mob) === pO) continue;
          XO && this.drop(XO);
          const [bK, eO, lO] = KO.pos;
          this.farms.set(KO.key, {
            pos: KO.pos,
            feet: [bK + .5, eO + 1, lO + .5],
            mob: pO,
            model: null,
            shown: !1,
            running: !1,
            front: [0, 0, 1],
            spin: 0
          })
        }
        for (const [KO, pO] of this.farms) OO.has(KO) || (this.drop(pO), this.farms.delete(KO));
        this.checkedMs = -1 / 0
      }
      check(OO, KO) {
        for (const pO of this.farms.values()) {
          const [XO, bK, eO] = pO.pos, lO = QF(OO, pO.pos);
          null !== lO && Tp(lO) === PO && ML(pO.pos, KO, "Air" === QF(OO, [XO, bK + 1, eO])) ? (pO.running = lO.endsWith("|Running"), pO.front = eL(lO), null === pO.model && (pO.model = OO.createMobModel(pO.mob, DL(pO.mob)), null === pO.model) || (pO.model.setPose(pO.feet, aQ(pO.front, pO.spin)), pO.shown || (pO.model.setVisible(!0), pO.shown = !0))) : (pO.shown && null !== pO.model && pO.model.setVisible(!1), pO.shown = !1)
        }
      }
      drop(OO) {
        var KO;
        null === (KO = OO.model) || void 0 === KO || KO.dispose(), OO.model = null, OO.shown = !1
      }
    }
    class VL {
      constructor() {
        this.island = null, this.islandSite = null, this.views = [], this.status = null, this.openHeld = null, this.beamsVersion = 0, this.listeners = new Set
      }
      onBeams(OO) {
        var KO;
        this.island = OO.baf2ColIsland, this.islandSite = (KO = OO.baf2ColSite) && 8 === KO.length ? {
          spawnXZ: [KO[0], KO[1]],
          coreXZ: [KO[2], KO[3]],
          minXZ: [KO[4], KO[5]],
          maxXZ: [KO[6], KO[7]]
        } : null, this.views = OO.baf2ColList.map((OO => ({
          entry: kb(OO)
        }))), this.beamsVersion++, this.emit()
      }
      onStatus(OO) {
        this.status = OO, this.emit()
      }
      onOpen(OO) {
        this.openHeld = OO
      }
      heldAtOpen() {
        return this.openHeld
      }
      site() {
        return this.islandSite
      }
      colliders() {
        return this.views
      }
      entries() {
        return this.views.map((OO => OO.entry))
      }
      entryAtRoot(OO) {
        var KO;
        return null === (KO = this.views.find((KO => {
          let {
            entry: pO
          } = KO;
          return pO.focus[0] === OO[0] && pO.focus[1] === OO[1] + 1 && pO.focus[2] === OO[2]
        }))) || void 0 === KO ? void 0 : KO.entry
      }
      getStatus() {
        return this.status
      }
      version() {
        return this.beamsVersion
      }
      lookLine(OO, KO) {
        return EC(this.entries(), OO, KO)
      }
      lookSource() {
        return {
          handles: OO => bb(OO) >= 0 || eX(OO),
          line: (OO, KO) => this.lookLine(OO, KO),
          version: () => this.beamsVersion
        }
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      dispose() {
        this.listeners.clear(), this.island = null, this.views = [], this.status = null, this.openHeld = null
      }
      emit() {
        for (const OO of this.listeners) OO()
      }
    }
    const LL = {
      positions: [1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1].map((OO => OO / 2)),
      indices: [0, 4, 8, 12, 16, 20].flatMap((OO => [OO, OO + 1, OO + 2, OO, OO + 2, OO + 3]))
    };

    function QL(OO, KO, pO, XO, bK, eO, lO) {
      let vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0;
      const CO = Math.cos(vK),
        hO = Math.sin(vK),
        DO = OO.positions.length / 3,
        {
          positions: MO,
          indices: aK
        } = LL;
      for (let oO = 0; oO < MO.length; oO += 3) {
        const vK = MO[oO] * bK,
          DO = MO[oO + 2] * lO;
        OO.positions.push(KO + vK * CO + DO * hO, pO + MO[oO + 1] * eO, XO - vK * hO + DO * CO)
      }
      for (const oO of aK) OO.indices.push(DO + oO)
    }

    function zQ(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
      return KO < 1 ? {
        rgb: OO,
        alpha: KO
      } : {
        rgb: OO,
        alpha: 1,
        opaque: !0
      }
    }
    class AL {
      constructor(OO, KO) {
        this.style = OO, this.perSource = KO, this.particles = null, this.sources = [], this.budget = 0, this.cursor = 0
      }
      setSources(OO) {
        this.sources = OO, 0 === OO.length && (this.budget = 0)
      }
      KK(OO, KO, pO) {
        const XO = this.sources.length;
        if (0 !== XO) {
          var bK, eO;
          this.budget = Math.min(this.budget + (bK = XO, eO = this.perSource, Math.min(bK * eO, BC) * KO), 2);
          for (let KO = 0; KO < XO && this.budget >= 1; KO++) {
            const KO = this.sources[this.cursor % XO];
            this.cursor = (this.cursor + 1) % XO;
            if (!(Math.max(Math.abs(KO.x - pO[0]), Math.abs(KO.y - pO[1]), Math.abs(KO.z - pO[2])) > 32)) return this.puff(OO, KO), void this.budget--
          }
        }
      }
      dispose() {
        var OO;
        null === (OO = this.particles) || void 0 === OO || OO.dispose(), this.particles = null, this.sources = []
      }
      puff(OO, KO) {
        let {
          x: pO,
          y: XO,
          z: bK,
          h: eO,
          faces: lO
        } = KO;
        const vK = function(OO, KO, pO, XO, bK) {
            const [eO, lO, vK] = bK[Math.floor(Math.random() * bK.length)], CO = .04, hO = (OO, KO, pO) => OO > 0 ? KO + pO + CO : OO < 0 ? KO - CO : KO + .1, DO = (OO, KO, pO) => OO > 0 ? KO + pO + CO : OO < 0 ? KO - CO : KO + pO - .1, MO = [hO(eO, OO, 1), hO(lO, KO, XO), hO(vK, pO, 1)], aK = [DO(eO, OO, 1), DO(lO, KO, XO), DO(vK, pO, 1)];
            return {
              pos: [(MO[0] + aK[0]) / 2, (MO[1] + aK[1]) / 2, (MO[2] + aK[2]) / 2],
              half: [(aK[0] - MO[0]) / 2, (aK[1] - MO[1]) / 2, (aK[2] - MO[2]) / 2],
              out: [eO, lO, vK]
            }
          }(pO, XO, bK, eO, lO),
          {
            style: CO
          } = this,
          hO = this.particles ??= OO.createParticles(FV(CO, Math.ceil(CO.count * BC * CO.life[1]) + 4), vK);
        hO.moveTo(vK.pos, vK.half);
        const [DO, MO, aK] = vK.out, oO = CO.spread;
        hO.setDirections([DO - oO, .6 + MO, aK - oO], [DO + oO, 1 + MO, aK + oO]), hO.emit(CO.count)
      }
    }
    const fL = [
      [1, 0, 0],
      [-1, 0, 0],
      [0, 0, 1],
      [0, 0, -1],
      [0, 1, 0]
    ];
    class dL {
      constructor() {
        this.green = new AL(GC.green, JC), this.pink = new AL(GC.pink, ch), this.colliders = [], this.lastMs = 0
      }
      setSources(OO) {
        this.colliders = OO;
        const KO = [],
          pO = [];
        for (const XO of OO) {
          const [OO, bK, eO] = XO.focus;
          KO.push({
            x: OO,
            y: bK - 1,
            z: eO,
            h: 2,
            faces: fL
          });
          for (let KO = 0; KO < 4; KO++) {
            if (!XO.live[KO]) continue;
            const [OO, bK, eO] = CX(XO.focus, KO, kX.LASER_D), [lO, , vK] = vb[KO], CO = fL.filter((OO => OO[0] !== lO || OO[2] !== vK || 0 !== OO[1]));
            pO.push({
              x: OO,
              y: bK,
              z: eO,
              h: 1,
              faces: CO
            })
          }
        }
        this.green.setSources(KO), this.pink.setSources(pO)
      }
      onAfterRender(OO) {
        const KO = performance.now(),
          pO = 0 === this.lastMs ? 0 : Math.min(KO - this.lastMs, 250) / 1e3;
        if (this.lastMs = KO, 0 === this.colliders.length || !OO.particlesEnabled()) return;
        const XO = OO.getCameraPosition();
        this.green.KK(OO, pO, XO), this.pink.KK(OO, pO, XO)
      }
      dispose() {
        this.green.dispose(), this.pink.dispose(), this.colliders = []
      }
    }
    const TL = 1.04,
      NL = zQ([1, 120 / 255, 220 / 255]),
      IL = zQ([1, .25, .25], .35);
    class yQ {
      constructor(OO) {
        this.store = OO, this.meshes = [], this.beams = [], this.builtVersion = -1, this.glow = new dL
      }
      onAfterRender(OO) {
        this.store.version() !== this.builtVersion && this.rebuild(OO);
        const KO = performance.now();
        for (const pO of this.beams) {
          const XO = 1 + .35 * Math.sin(KO / 700 * Math.PI * 2 + pO.phase);
          OO.setGameMesh(pO.mesh, {
            scale: [pO.alongX ? 1 : XO, XO, pO.alongX ? XO : 1]
          })
        }
        this.glow.onAfterRender(OO)
      }
      dispose(OO) {
        this.clear(OO), this.glow.dispose(), this.builtVersion = -1
      }
      rebuild(OO) {
        this.clear(OO), this.builtVersion = this.store.version();
        const KO = [];
        for (const {
            entry: pO
          }
          of this.store.colliders()) pO.on && pO.live.some(Boolean) && (this.addBeams(OO, pO), KO.push(pO)), pO.blockers.length > 0 && this.addMarkers(OO, pO);
        this.glow.setSources(KO)
      }
      addBeams(OO, KO) {
        const [pO, XO, bK] = KO.focus, eO = SC - .25, lO = (.25 + SC) / 2;
        for (let vK = 0; vK < 4; vK++) {
          if (!KO.live[vK]) continue;
          const [CO, , hO] = vb[vK], DO = 0 !== CO, MO = {
            positions: [],
            indices: []
          };
          QL(MO, 0, 0, 0, DO ? eO : .2, .2, DO ? .2 : eO);
          const aK = [pO + .5 + CO * lO, XO + .5, bK + .5 + hO * lO],
            oO = OO.createGameMesh(MO, NL, aK);
          this.meshes.push(oO), this.beams.push({
            mesh: oO,
            alongX: DO,
            phase: vK * Math.PI / 2
          })
        }
      }
      addMarkers(OO, KO) {
        const pO = KO.blockers[0],
          XO = {
            positions: [],
            indices: []
          };
        for (const [bK, eO, lO] of KO.blockers) QL(XO, bK - pO[0] + .5, eO - pO[1] + .5, lO - pO[2] + .5, TL, TL, TL);
        this.meshes.push(OO.createGameMesh(XO, IL, pO))
      }
      clear(OO) {
        for (const KO of this.meshes) OO.disposeGameMesh(KO);
        this.meshes = [], this.beams = []
      }
    }
    const gQ = [.56, .83, 1],
      uL = [1, .73, .08],
      EL = [1, .25, .25],
      jQ = [.85, .85, .85],
      YL = [.3, .45, .6];

    function wL(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : .9,
        eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : .05;
      const lO = bK / 2,
        vK = bK + eO;
      for (const CO of [-lO, lO])
        for (const bK of [-lO, lO]) QL(OO, KO, pO + CO, XO + bK, vK, eO, eO), QL(OO, KO + CO, pO, XO + bK, eO, vK, eO), QL(OO, KO + CO, pO + bK, XO, eO, eO, vK)
    }

    function iQ(OO) {
      return KO => OO.isBlockInLoadedChunk(KO[0], KO[1], KO[2]) && 0 === OO.getBlockId(KO[0], KO[1], KO[2])
    }

    function rQ(OO) {
      return OO.map((OO => {
        let {
          free: KO,
          blocked: pO,
          gaps: XO,
          supports: bK
        } = OO;
        return `${KO.join(";")}|${pO.join(";")}|${XO.join(";")}|${bK.join(";")}`
      })).join("/")
    }

    function PL(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : .9,
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : .05;
      const eO = KO[0],
        lO = {
          positions: [],
          indices: []
        };
      for (const [vK, CO, hO] of KO) wL(lO, vK - eO[0] + .5, CO - eO[1] + .5, hO - eO[2] + .5, XO, bK);
      return OO.createGameMesh(lO, pO, eO)
    }
    class mQ {
      constructor(OO) {
        this.store = OO, this.meshes = [], this.pulses = [], this.shownKey = "", this.lastCheckMs = -1 / 0
      }
      onAfterRender(OO, KO, pO) {
        var XO;
        const bK = null === (XO = OO.mhO(KO)) || void 0 === XO ? void 0 : XO.name;
        if (bK !== OX && bK !== Up) return void("" !== this.shownKey && this.show(OO, "", []));
        const eO = performance.now();
        if (eO - this.lastCheckMs >= 200 && (this.lastCheckMs = eO, bK === OX ? this.check(OO, pO) : this.preview(OO, pO)), this.pulses.length > 0) {
          const KO = 1 + .12 * Math.sin(eO / 1e3 * 1.25 * Math.PI * 2),
            pO = [KO, KO, KO];
          for (const XO of this.pulses) OO.setGameMesh(XO, {
            scale: pO
          })
        }
      }
      dispose(OO) {
        this.clear(OO), this.shownKey = ""
      }
      check(OO, KO) {
        const pO = iQ(OO),
          XO = [];
        for (const {
            entry: eO
          }
          of this.store.colliders()) {
          eO.focus.every(((OO, pO) => Math.abs(OO + .5 - KO[pO]) <= kX.GHOST_REACH)) && XO.push(RC(eO, pO))
        }
        const bK = rQ(XO);
        bK !== this.shownKey && this.show(OO, bK, XO)
      }
      preview(OO, KO) {
        const pO = OO.getTargetedBlock(),
          XO = pO ? [pO.Se[0], pO.Se[1], pO.Se[2]] : null,
          bK = null !== XO && XO.every(((OO, pO) => Math.abs(OO + .5 - KO[pO]) <= 8)),
          eO = this.store.site(),
          lO = bK && eO ? function(OO, KO, pO) {
            const XO = lX(OO);
            if (!XO.every(KO)) return null;
            const bK = MX(OO, pO);
            return {
              column: XO,
              spots: RC({
                focus: XO[1],
                lasers: [!1, !1, !1, !1],
                open: bK,
                live: [!1, !1, !1, !1],
                on: !1,
                state: "noLasers",
                blockers: []
              }, KO),
              fits: bK.filter(Boolean).length >= kX.MIN_SPOTS
            }
          }(XO, iQ(OO), eO) : null,
          vK = lO ? [lO.spots] : [],
          CO = lO ? `preview ${XO.join(",")}|${lO.fits}|${rQ(vK)}` : "";
        var hO, DO;
        CO !== this.shownKey && this.show(OO, CO, vK, null !== (hO = null === lO || void 0 === lO ? void 0 : lO.column) && void 0 !== hO ? hO : [], null === (DO = null === lO || void 0 === lO ? void 0 : lO.fits) || void 0 === DO || DO)
      }
      show(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [],
          bK = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4];
        this.clear(OO), this.shownKey = KO, XO.length > 0 && this.meshes.push(PL(OO, XO, zQ(bK ? jQ : EL)));
        for (const {
            free: eO,
            blocked: lO,
            gaps: vK,
            supports: CO
          }
          of pO) {
          for (const [KO, pO, XO] of eO) {
            const bK = {
              positions: [],
              indices: []
            };
            wL(bK, 0, 0, 0);
            const eO = OO.createGameMesh(bK, zQ(gQ), [KO + .5, pO + .5, XO + .5]);
            this.meshes.push(eO), this.pulses.push(eO)
          }
          lO.length > 0 && this.meshes.push(PL(OO, lO, zQ(uL))), vK.length > 0 && this.meshes.push(PL(OO, vK, zQ(EL), 1.06, .07)), CO.length > 0 && this.meshes.push(PL(OO, CO, zQ(YL)))
        }
      }
      clear(OO) {
        for (const KO of this.meshes) OO.disposeGameMesh(KO);
        this.meshes = [], this.pulses = []
      }
    }
    class sL {
      constructor() {
        this.stored = new Map, this.pending = [], this.order = [], this.recents = [], this.seq = 0, this.silos = 0, this.readOnly = !0, this.pocket = !1, this.listeners = new Set, this.version = 0
      }
      apply(OO) {
        if (!OO.baf2TermOpen) return !1;
        OO.baf2TermReset && (this.stored.clear(), this.pending = []);
        for (const [KO, pO] of OO.baf2TermItems) pO > 0 ? this.stored.set(KO, pO) : this.stored.delete(KO);
        if (this.pending = this.pending.filter((KO => KO.seq > OO.baf2TermAcked)), this.silos = OO.baf2TermSilos, this.readOnly = OO.baf2TermReadOnly, this.pocket = !0 === OO.baf2TermPocket, OO.baf2TermReset) this.resort();
        else
          for (const KO of this.stored.keys()) this.order.includes(KO) || this.order.push(KO);
        return this.changed(), !0
      }
      resort() {
        this.order = [...this.stored.keys()].sort(((OO, KO) => this.amount(KO) - this.amount(OO) || OO.localeCompare(KO))), this.changed()
      }
      take(OO, KO) {
        const pO = function(OO, KO) {
          const pO = "number" === typeof OO ? OO : "one" === OO ? 1 : "stack" === OO ? 99 : KO;
          return Math.min(KO, pO)
        }(OO, this.amount(KO));
        return this.seq++, this.pending.push({
          seq: this.seq,
          item: KO,
          amount: pO
        }), this.recents = [KO, ...this.recents.filter((OO => OO !== KO))].slice(0, 6), this.changed(), KK(this.seq, OO, KO)
      }
      amount(OO) {
        var KO;
        let pO = null !== (KO = this.stored.get(OO)) && void 0 !== KO ? KO : 0;
        for (const XO of this.pending) XO.item === OO && (pO -= XO.amount);
        return Math.max(0, pO)
      }
      items() {
        return this.order.filter((OO => this.amount(OO) > 0))
      }
      recent() {
        return this.recents.filter((OO => this.amount(OO) > 0))
      }
      siloCount() {
        return this.silos
      }
      isReadOnly() {
        return this.readOnly
      }
      isPocket() {
        return this.pocket
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      changed() {
        this.version++;
        for (const OO of this.listeners) OO()
      }
    }
    var HL = pO(36813);
    const RL = {
      isBlock: OO => void 0 !== YO.l[OO],
      harvestType: OO => {
        var KO;
        return null === (KO = YO.l[OO]) || void 0 === KO ? void 0 : KO.harvestType
      },
      harvestLevel: OO => {
        var KO;
        return null === (KO = YO.l[OO]) || void 0 === KO ? void 0 : KO.harvestLevel
      },
      dropsNothing: OO => {
        var KO;
        return null === (null === (KO = YO.l[OO]) || void 0 === KO ? void 0 : KO.drops)
      },
      displayName: OO => {
        var KO;
        return null === (KO = cv.p[OO]) || void 0 === KO ? void 0 : KO.displayName
      },
      description: OO => {
        var KO;
        return null === (KO = cv.p[OO]) || void 0 === KO ? void 0 : KO.description
      },
      harvests: OO => {
        var KO;
        return null === (KO = cv.p[OO]) || void 0 === KO ? void 0 : KO.harvests
      },
      level: OO => {
        var KO;
        return null === (KO = cv.p[OO]) || void 0 === KO ? void 0 : KO.level
      }
    };

    function SL(OO, KO, pO) {
      return function(OO, KO, pO, XO) {
        var bK, eO;
        const lO = KO.split("|")[0],
          vK = OO.isBlock(KO) ? KO : OO.isBlock(lO) ? lO : null;
        if (null === vK || "rock" !== OO.harvestType(vK) || OO.dropsNothing(vK) && !jb.has(lO)) return null;
        const CO = pO && "rock" === OO.harvests(pO) ? null !== (bK = OO.level(pO)) && void 0 !== bK ? bK : 0 : null,
          hO = null !== (eO = null !== XO && void 0 !== XO ? XO : OO.harvestLevel(vK)) && void 0 !== eO ? eO : 0;
        return (null !== CO ? hO <= CO : 0 === OO.harvestLevel(vK)) ? null : zb(OO, hO)
      }(RL, OO, KO, pO)
    }

    function JL(OO, KO) {
      return function(OO, KO, pO) {
        if (KO === QX[0]) return [(0, rK.Qd)({
          translationKey: "buildAFactory2Game:toolNeededAny"
        }, rK.J.whiteUiText)];
        const XO = pO.split("|")[0],
          bK = OO.isBlock(XO) ? OO.displayName(XO) : void 0,
          eO = "string" === typeof bK ? bK : bK && "translationKey" in bK ? `$t(${bK.translationKey})` : XO;
        return [(0, rK.Qd)({
          translationKey: "buildAFactory2Game:toolNeeded",
          params: {
            block: eO
          }
        }, rK.J.whiteUiText), (0, rK.Qd)({
          translationKey: `item:${(0,rK.ke)(KO)}`
        }, rK.J.yellowUiText)]
      }(RL, OO, KO)
    }
    const cQ = "buildAFactory2Game:";
    const BL = [
      [1, 0, 0],
      [-1, 0, 0],
      [0, 1, 0],
      [0, -1, 0],
      [0, 0, 1],
      [0, 0, -1]
    ];

    function ZL(OO) {
      return OO.endsWith(" Ore")
    }
    const GL = {
        mode: null,
        detail: null,
        next: null,
        nextState: null
      },
      qQ = [],
      xQ = {
        info: null,
        visible: !1,
        tool: null,
        live: null,
        wrench: GL,
        plan: null,
        atomic: qQ
      },
      nL = "buildAFactory2Game:",
      WL = new Set(["Splitter", "Sorting Gate"]),
      tQ = [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1]
      ];
    class kQ {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => null,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => null;
        this.live = OO, this.planAt = KO, this.tierOf = pO, this.yl = 0, this.missesMaker = !1, this.afloat = !1, this.afloatKey = "", this.afloatAt = -1 / 0, this.afloatByRoot = new Map, this.besideMakerById = new Map, this.JK = null, this.express = !1, this.crouching = !1, this.tier = null, this.snapshot = xQ, this.rowsByKey = new Map, this.byRootId = new Map, this.listeners = new Set, this.livePos = [NaN, NaN, NaN], this.liveVersion = -1, this.targetsLive = !1, this.planPos = "", this.planMs = -1 / 0, this.plan = null
      }
      onAfterRender(OO, KO, pO) {
        var XO, bK, eO;
        let lO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        const vK = null !== (XO = null === (bK = OO.mhO(KO)) || void 0 === bK ? void 0 : bK.name) && void 0 !== XO ? XO : null,
          CO = OO.isPlayerCrouching(KO),
          hO = 0 === pO ? null : this.resolve(OO, pO),
          DO = null !== hO && null !== lO && WL.has(hO.rootName) && function(OO, KO) {
            return tQ.some((pO => {
              let [XO, bK] = pO;
              const eO = OO.getBlockId(KO[0] + XO, KO[1], KO[2] + bK);
              return 0 !== eO && "Express Belt" === OO.getMetaInfo(eO).rootName
            }))
          }(OO, lO),
          MO = this.updatePlan(0 === pO ? null : lO),
          aK = this.tierOf(),
          oO = null === lO ? null : (0, HL.f)(pO),
          FO = null !== oO && null !== lO && (0, HL.h)(function(OO) {
            return (KO, pO, XO) => OO.getBlockId(KO, pO, XO)
          }(OO), lO[0], lO[1], lO[2], oO),
          VO = this.readAfloat(OO, pO, lO);
        if (pO === this.yl && FO === this.missesMaker && VO === this.afloat && vK === this.JK && CO === this.crouching && DO === this.express && aK === this.tier && !MO && (!this.targetsLive || !this.liveMoved(lO))) return;
        this.yl = pO, this.missesMaker = FO, this.afloat = VO, this.JK = vK, this.crouching = CO, this.express = DO;
        const LO = DO && hO ? function(OO) {
          if (null === OO.info) return null;
          return OO.express ??= {
            ...OO.info,
            detail: `${nL}lookKeepsUpExpress`,
            detailItem: null
          }, OO.express
        }(hO) : null !== hO && FO && null !== oO ? this.besideMaker(hO, pO, oO) : null !== hO && VO ? this.hanging(hO) : null !== (eO = null === hO || void 0 === hO ? void 0 : hO.info) && void 0 !== eO ? eO : null;
        this.tier = aK;
        const QO = hO && LO ? function(OO, KO) {
          var pO, XO;
          const bK = YO.l[OO];
          if (!OO.endsWith(" Ore") || "rock" !== (null === bK || void 0 === bK ? void 0 : bK.harvestType) || 0 === bK.harvestLevel) return null;
          const eO = null !== (pO = bK.harvestLevel) && void 0 !== pO ? pO : 0,
            lO = KO ? cv.p[KO] : void 0;
          if ("rock" === (null === lO || void 0 === lO ? void 0 : lO.harvests) && (null !== (XO = lO.level) && void 0 !== XO ? XO : 0) >= eO) return null;
          const vK = (CO = eO, zb(RL, CO));
          var CO;
          if (null === vK) return null;
          const hO = qe(vK),
            DO = /^[AEIOU]/.test(vK) ? "An" : "";
          if ("rock" === (null === lO || void 0 === lO ? void 0 : lO.harvests) && KO) return {
            key: `${nL}lookToolTooWeak${DO}`,
            JK: qe(KO),
            needed: hO
          };
          return {
            key: vK === QX[0] ? `${nL}lookNeedAnyPickaxe` : `${nL}lookNeedPickaxe${DO}`,
            JK: null,
            needed: hO
          }
        }(hO.rootName, vK) : null;
        this.targetsLive = !0 === (null === hO || void 0 === hO ? void 0 : hO.live) && null !== lO;
        let zK = null;
        this.targetsLive && hO && lO && this.live && (this.livePos[0] = lO[0], this.livePos[1] = lO[1], this.livePos[2] = lO[2], this.liveVersion = this.live.version(), zK = this.live.line(hO.rootName, lO));
        const AO = null === LO ? GL : function(OO, KO, pO) {
            const XO = function(OO, KO, pO) {
              const XO = Ip(OO);
              if (null === XO) return null;
              const bK = `${cQ}lookPortMode_${XO}`,
                eO = ib(KO);
              if (eO && pO) return {
                mode: null,
                detail: bK,
                next: `${cQ}lookWrenchPickUp`,
                nextState: null
              };
              const lO = yX(OO),
                vK = null === lO ? null : Ip(lO);
              return null === vK ? {
                mode: null,
                detail: bK,
                next: null,
                nextState: null
              } : {
                mode: null,
                detail: bK,
                next: eO ? `${cQ}lookWrenchNext` : `${cQ}lookPortWrench`,
                nextState: `${cQ}lookPortState_${vK}`
              }
            }(OO, KO, pO);
            if (null !== XO) return XO;
            const bK = xb(OO, KO, pO);
            return null === bK.mode && null === bK.next ? GL : bK
          }(OO.blockIdToBlockName(pO), vK, CO),
          fO = this.plan,
          dO = hO && LO ? this.rowsOf(hO.rootName, aK) : qQ,
          TO = this.snapshot;
        if (!(null === LO ? !TO.visible : TO.visible && LO === TO.info && (NO = QO, IO = TO.tool, NO === IO || null !== NO && null !== IO && NO.key === IO.key && NO.JK === IO.JK && NO.needed === IO.needed) && function(OO, KO) {
            return OO === KO || null !== OO && null !== KO && OO.key === KO.key && JSON.stringify([OO.params, OO.keys]) === JSON.stringify([KO.params, KO.keys])
          }(zK, TO.live) && function(OO, KO) {
            return OO.mode === KO.mode && OO.detail === KO.detail && OO.next === KO.next && OO.nextState === KO.nextState
          }(AO, TO.wrench) && EF(fO, TO.plan) && dO === TO.atomic)) {
          var NO, IO;
          this.snapshot = null === LO ? {
            ...TO,
            visible: !1
          } : {
            info: LO,
            visible: !0,
            tool: QO,
            live: zK,
            wrench: AO,
            plan: fO,
            atomic: dO
          };
          for (const OO of this.listeners) OO()
        }
      }
      get() {
        return this.snapshot
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      dispose() {
        this.listeners.clear(), this.byRootId.clear(), this.besideMakerById.clear(), this.missesMaker = !1, this.afloatByRoot.clear(), this.afloat = !1, this.afloatKey = "", this.afloatAt = -1 / 0, this.rowsByKey.clear(), this.snapshot = xQ, this.yl = 0, this.JK = null, this.express = !1, this.crouching = !1, this.targetsLive = !1, this.plan = null, this.planPos = ""
      }
      readAfloat(OO, KO, pO) {
        if (null === pO || 0 === KO || !vK() || !ZL(this.resolve(OO, KO).rootName)) return !1;
        const XO = `${pO[0]},${pO[1]},${pO[2]},${KO}`,
          bK = performance.now();
        return XO === this.afloatKey && bK - this.afloatAt < UL ? this.afloat : (this.afloatKey = XO, this.afloatAt = bK, function(OO, KO) {
          for (const [pO, XO, bK] of BL) {
            const eO = KO(OO[0] + pO, OO[1] + XO, OO[2] + bK);
            if (void 0 === eO || null !== eO && !ZL(eO)) return !1
          }
          return !0
        }(pO, ((KO, pO, XO) => function(OO, KO, pO, XO) {
          if (!OO.isBlockInLoadedChunk(KO, pO, XO)) return;
          const bK = OO.getBlockId(KO, pO, XO);
          return 0 === bK ? null : OO.getMetaInfo(bK).rootName
        }(OO, KO, pO, XO))))
      }
      liveMoved(OO) {
        var KO;
        const {
          livePos: pO
        } = this;
        return null === OO || OO[0] !== pO[0] || OO[1] !== pO[1] || OO[2] !== pO[2] || (null === (KO = this.live) || void 0 === KO ? void 0 : KO.version()) !== this.liveVersion
      }
      updatePlan(OO) {
        const KO = null === OO ? "" : OO.join(","),
          pO = performance.now();
        if (KO === this.planPos && pO - this.planMs < 250) return !1;
        this.planPos = KO, this.planMs = pO;
        const XO = null === OO ? null : this.planAt([OO[0], OO[1], OO[2]]),
          bK = !EF(XO, this.plan);
        return this.plan = XO, bK
      }
      besideMaker(OO, KO, pO) {
        let {
          info: XO
        } = OO;
        if (null === XO) return null;
        let bK = this.besideMakerById.get(KO);
        if (void 0 === bK) {
          const OO = "cryo" === pO ? "lookPipeMixerSide" : "lookPipeCondenserSide";
          bK = {
            ...XO,
            detail: `${nL}${OO}`,
            detailItem: null
          }, this.besideMakerById.set(KO, bK)
        }
        return bK
      }
      hanging(OO) {
        let {
          info: KO,
          rootName: pO
        } = OO;
        if (null === KO) return null;
        let XO = this.afloatByRoot.get(pO);
        return void 0 === XO && (XO = {
          ...KO,
          detail: `${nL}lookOreAfloat`,
          detailItem: null
        }, this.afloatByRoot.set(pO, XO)), XO
      }
      rowsOf(OO, KO) {
        if (null === KO) return qQ;
        const pO = `${OO}|${KO}`;
        let XO = this.rowsByKey.get(pO);
        if (void 0 === XO) {
          const bK = function(OO, KO) {
            var pO;
            if (!(OO in yp)) return [];
            const XO = null !== (pO = gp[OO]) && void 0 !== pO ? pO : [],
              bK = new Map;
            for (const lO of we(OO, KO))
              if ((XO.includes(lO) || Ye(lO.output) && Ee(lO.output) > WO(OO)) && Ee(lO.output) <= KO) {
                var eO;
                const OO = null !== (eO = bK.get(lO.output)) && void 0 !== eO ? eO : [];
                OO.push(lO.input), bK.set(lO.output, OO)
              } return rl([...bK], (OO => {
              let [KO] = OO;
              return -Ee(KO)
            })).map((OO => {
              let [KO, pO] = OO;
              return {
                output: KO,
                inputs: pO
              }
            }))
          }(OO, KO);
          XO = bK.length > 0 ? bK : qQ, this.rowsByKey.set(pO, XO)
        }
        return XO
      }
      resolve(OO, KO) {
        const {
          rootId: pO,
          rootName: XO
        } = OO.getMetaInfo(KO), bK = (0, lp.n)(XO) ? KO : pO;
        let eO = this.byRootId.get(bK);
        const lO = vK();
        if (void 0 === eO || eO.nuclear !== lO) {
          var CO;
          const pO = function(OO) {
            return uX(RL, OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO)
          }(XO, OO.blockIdToBlockName(KO));
          eO = {
            info: pO,
            rootName: XO,
            live: null !== pO && !0 === (null === (CO = this.live) || void 0 === CO ? void 0 : CO.handles(XO)),
            nuclear: lO
          }, this.byRootId.set(bK, eO)
        }
        return eO
      }
    }
    const UL = 500;
    const OQ = (0, XO.memo)((function(OO) {
      var KO, pO;
      let {
        store: bK
      } = OO;
      const {
        t: eO
      } = (0, ze.D)(), [lO, vK] = (0, XO.useState)((() => bK.get()));
      (0, XO.useEffect)((() => (vK(bK.get()), bK.subscribe((() => {
        vK(bK.get())
      })))), [bK]);
      const {
        openInGameMenuName: CO,
        openEverythingMenuName: hO,
        isTouchScreen: DO
      } = (0, Mb.l)(["openInGameMenuName", "openEverythingMenuName", "isTouchScreen"]), {
        info: MO,
        tool: aK,
        live: oO,
        wrench: FO,
        atomic: VO
      } = lO, LO = lO.visible && null === CO && null === hO;
      if (null === MO) return null;
      const QO = null !== FO.detail ? eO(FO.detail) : null !== (KO = lO.plan) && void 0 !== KO && KO.ctrl ? eO("buildAFactory2Game:lookPlanCtrl") : null !== MO.detail ? eO(MO.detail, null === MO.detailItem ? void 0 : {
        item: eO(MO.detailItem)
      }) : null;
      return (0, Ve.jsxs)("div", {
        className: Fb()("Baf2LookTarget", {
          Visible: LO
        }),
        "aria-hidden": !LO,
        children: [(0, Ve.jsx)("div", {
          className: "Baf2LookTargetName SmallTextBold",
          children: eO(MO.name)
        }), null !== lO.plan && (0, Ve.jsx)("div", {
          className: "Baf2LookTargetDetail",
          children: eO(lO.plan.key, {
            kind: eO(lO.plan.kindKey),
            w: String(lO.plan.w),
            h: String(lO.plan.h),
            d: String(lO.plan.d),
            count: String(lO.plan.count)
          })
        }), void 0 !== (null === (pO = lO.plan) || void 0 === pO ? void 0 : pO.why) && (0, Ve.jsx)("div", {
          className: "Baf2LookTargetDetail Warning",
          children: eO(lO.plan.why)
        }), null !== FO.mode && (0, Ve.jsx)("div", {
          className: "Baf2LookTargetDetail",
          children: eO(FO.mode)
        }), null !== aK ? (0, Ve.jsx)("div", {
          className: "Baf2LookTargetDetail Warning",
          children: eO(aK.key, {
            item: eO(aK.needed),
            JK: null === aK.JK ? "" : eO(aK.JK)
          })
        }) : null !== oO ? (0, Ve.jsx)("div", {
          className: "Baf2LookTargetDetail",
          children: eO(oO.key, qh(eO, oO))
        }) : null !== QO && (0, Ve.jsx)("div", {
          className: "Baf2LookTargetDetail",
          children: QO
        }), VO.length > 0 && (0, Ve.jsx)("div", {
          className: "Baf2LookTargetDetail",
          children: eO("buildAFactory2Game:lookAtomicRecipes", {
            list: VO.map((OO => {
              let {
                output: KO,
                inputs: pO
              } = OO;
              const XO = pO.length > 1 ? ` ${eO("buildAFactory2Game:recipeMore",{count:String(pO.length-1)})}` : "";
              return `${eO(qe(pO[0]))}${XO} \u2192 ${eO(qe(KO))}`
            })).join(", ")
          })
        }), null !== FO.next && (0, Ve.jsx)("div", {
          className: "Baf2LookTargetDetail",
          children: eO(FO.next, {
            state: null === FO.nextState ? "" : eO(FO.nextState),
            use: eO(DO ? "buildAFactory2Game:lookUse_touch" : "buildAFactory2Game:lookUse_mouse")
          })
        })]
      })
    }));
    var KQ = pO(36904);
    const pQ = [],
      XQ = [
        [0, -1, 0]
      ];

    function bz(OO) {
      const KO = [OO];
      for (let pO = 1; pO <= 4; pO++) pO > 1 && KO.push(`${OO}|meta|rot${pO}`), KO.push(`${OO}|meta|rot${pO}|Running`);
      return KO
    }

    function eQ(OO, KO) {
      return [Math.floor(OO[0] / KO), Math.floor(OO[1] / KO), Math.floor(OO[2] / KO)]
    }

    function lQ(OO, KO, pO) {
      return `${OO},${KO},${pO}`
    }

    function vz(OO) {
      const KO = OO.split("|")[0];
      if (!Kp(KO)) return pQ;
      const pO = yp[KO];
      if (qp(pO)) return XQ;
      const XO = eL(OO);
      return xp(pO) ? [
        [-XO[0], -XO[1], -XO[2]]
      ] : Vb(pO) ? function(OO, KO) {
        const pO = OO[0] - 2 * KO[0],
          XO = OO[2] - 2 * KO[2],
          bK = [];
        for (let eO = -1; eO <= 1; eO++)
          for (let KO = -1; KO <= 1; KO++) bK.push([pO + eO, OO[1], XO + KO]);
        return bK
      }([0, 0, 0], XO) : pQ
    }
    const CQ = [.5, .5, .5],
      hQ = [.2, .8, .3],
      DQ = [.45, 1, .5];
    class MQ {
      constructor() {
        this.offsetsIndexById = new Uint8Array(65536), this.indexed = !1, this.offsetsList = [], this.hits = [], this.chunks = new Map, this.cellChunks = new Map, this.lastCheckMs = -1 / 0, this.checks = 0, this.scanFrom = 0, this.shownKey = "", this.meshes = []
      }
      index(OO) {
        this.indexed = !0;
        for (const KO of fK)
          for (const pO of bz(KO)) {
            const KO = OO.blockNameToBlockId(pO, !0),
              XO = vz(pO);
            null !== KO && XO.length > 0 && (this.offsetsList.push(XO), this.offsetsIndexById[KO] = this.offsetsList.length)
          }
      }
      onAfterRender(OO, KO) {
        this.indexed || this.index(OO);
        const pO = performance.now();
        if (pO - this.lastCheckMs < 100) return;
        this.lastCheckMs = pO, this.checks++;
        const XO = tF.h.SX,
          [bK, eO, lO] = eQ(KO, XO);
        let vK = !1;
        const CO = [];
        let hO = 0;
        for (let DO = bK - 2; DO <= bK + 2; DO++)
          for (let KO = eO - 1; KO <= eO + 1; KO++)
            for (let bK = lO - 2; bK <= lO + 2; bK++) {
              const eO = hO++,
                lO = lQ(DO, KO, bK),
                MO = OO.getChunkVersion(DO, KO, bK);
              let aK = this.chunks.get(lO);
              null !== MO ? (aK || (aK = {
                checkedVersion: -1,
                scannedVersion: -1,
                scannedAt: -1 / 0,
                machines: [],
                cellChunks: [],
                seenAt: 0
              }, this.chunks.set(lO, aK)), aK.seenAt = this.checks, aK.checkedVersion !== MO && (aK.checkedVersion = MO, vK = !0), aK.scannedVersion !== MO && pO - aK.scannedAt >= 500 && CO.push({
                slot: eO,
                entry: aK,
                origin: [DO * XO, KO * XO, bK * XO]
              })) : (vK ||= void 0 !== aK, this.chunks.delete(lO))
            }
        this.scanDue(OO, CO) && (vK = !0);
        for (const [DO, MO] of this.chunks) MO.seenAt !== this.checks && (vK ||= MO.machines.length > 0, this.chunks.delete(DO));
        for (const DO of this.chunks.values())
          for (const [KO, pO, XO] of DO.cellChunks)(Math.abs(KO - bK) > 2 || Math.abs(pO - eO) > 1 || Math.abs(XO - lO) > 2) && this.watchCellChunk(OO, KO, pO, XO) && (vK = !0);
        for (const [DO, MO] of this.cellChunks) MO.seenAt !== this.checks && this.cellChunks.delete(DO);
        vK && this.refresh(OO)
      }
      dispose(OO) {
        this.clearMeshes(OO), this.chunks.clear(), this.cellChunks.clear(), this.shownKey = ""
      }
      scanDue(OO, KO) {
        const pO = Math.max(KO.findIndex((OO => {
          let {
            slot: KO
          } = OO;
          return KO >= this.scanFrom
        })), 0);
        let XO = 96;
        for (let bK = 0; bK < KO.length; bK++) {
          const {
            slot: eO,
            entry: lO,
            origin: vK
          } = KO[(pO + bK) % KO.length];
          if (XO -= this.scan(OO, lO, vK), XO <= 0) {
            this.scanFrom = eO + 1;
            break
          }
        }
        return KO.length > 0
      }
      scan(OO, KO, pO) {
        let [XO, bK, eO] = pO;
        const lO = tF.h.SX,
          vK = this.hits;
        vK.length = 0;
        const CO = OO.scanBlocks(XO, bK, eO, XO + lO, bK + lO, eO + lO, this.offsetsIndexById, vK),
          hO = [];
        for (let DO = 0; DO < vK.length; DO += 4) hO.push({
          pos: [vK[DO], vK[DO + 1], vK[DO + 2]],
          offsets: this.offsetsList[this.offsetsIndexById[vK[DO + 3]] - 1]
        });
        return KO.machines = hO, KO.cellChunks = function(OO, KO) {
          const pO = new Set,
            XO = [];
          for (const {
              pos: bK,
              offsets: eO
            }
            of OO)
            for (const [OO, lO, vK] of eO) {
              const eO = eQ([bK[0] + OO, bK[1] + lO, bK[2] + vK], KO),
                CO = lQ(...eO);
              pO.has(CO) || (pO.add(CO), XO.push(eO))
            }
          return XO
        }(hO, lO), KO.scannedVersion = KO.checkedVersion, KO.scannedAt = performance.now(), Math.max(CO, 1)
      }
      watchCellChunk(OO, KO, pO, XO) {
        const bK = lQ(KO, pO, XO),
          eO = OO.getChunkVersion(KO, pO, XO),
          lO = this.cellChunks.get(bK);
        return null === eO ? this.cellChunks.delete(bK) : (null === lO || void 0 === lO ? void 0 : lO.version) === eO ? (lO.seenAt = this.checks, !1) : (this.cellChunks.set(bK, {
          version: eO,
          seenAt: this.checks
        }), !0)
      }
      refresh(OO) {
        const KO = function(OO, KO) {
            const pO = new Set,
              XO = [];
            for (const {
                pos: bK,
                offsets: eO
              }
              of OO)
              for (const [OO, lO, vK] of eO) {
                const eO = bK[0] + OO,
                  CO = bK[1] + lO,
                  hO = bK[2] + vK,
                  DO = `${eO},${CO},${hO}`;
                pO.has(DO) || (pO.add(DO), KO(eO, CO, hO) && XO.push([eO, CO, hO]))
              }
            return XO
          }([...this.chunks.values()].flatMap((OO => OO.machines)), ((KO, pO, XO) => OO.isBlockInLoadedChunk(KO, pO, XO) && 0 === OO.getBlockId(KO, pO, XO))),
          pO = KO.join(";");
        pO !== this.shownKey && (this.shownKey = pO, this.clearMeshes(OO), KO.length > 0 && (this.meshes = [this.build(OO, KO, !1), this.build(OO, KO, !0)]))
      }
      build(OO, KO, pO) {
        const XO = KO[0],
          bK = [],
          eO = [];
        for (const [lO, vK, CO] of KO)(0, KQ.b)(bK, eO, [lO - XO[0] + .5, vK - XO[1] + .5, CO - XO[2] + .5], CQ, pO);
        return OO.createGameMesh({
          positions: bK,
          indices: eO
        }, {
          rgb: pO ? DQ : hQ,
          alpha: .4
        }, XO)
      }
      clearMeshes(OO) {
        for (const KO of this.meshes) OO.disposeGameMesh(KO);
        this.meshes = []
      }
    }
    const az = 1 / .6,
      oQ = 200,
      FQ = {
        colours: [
          [127, 233, 255],
          [180, 140, 255]
        ],
        life: [.12, .22],
        size: [.12, .2],
        perBlock: 3
      },
      VQ = {
        colours: [
          [120, 255, 150],
          [200, 255, 120]
        ],
        life: [.3, .5],
        size: [.25, .4],
        perBlock: 6
      },
      LQ = 2 * Math.PI / 3;
    class QQ {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : FQ;
        this.style = OO, this.particles = null, this.points = new Float32Array(800), this.budget = oQ, this.lastMs = 0
      }
      static blade() {
        return new QQ(VQ)
      }
      YV(OO, KO) {
        const pO = Math.min(KO.arcStruck, KO.arcPoints.length);
        this.draw(OO, [KO.arcFrom, ...KO.arcPoints], KO.arcPoints.slice(0, pO))
      }
      onBlade(OO, KO) {
        const [pO, XO, bK] = KO.bladeCentre, [eO, lO] = KO.bladeFacing, vK = pO - 1.5 * eO, CO = bK - 1.5 * lO, hO = Math.atan2(lO, eO), DO = [];
        for (let MO = 0; MO <= 8; MO++) {
          const OO = hO - LQ / 2 + LQ * MO / 8;
          DO.push([vK + 2.5 * Math.cos(OO), XO, CO + 2.5 * Math.sin(OO)])
        }
        this.draw(OO, DO, KO.bladeStruck)
      }
      dispose() {
        var OO;
        null === (OO = this.particles) || void 0 === OO || OO.stop(), this.particles = null
      }
      draw(OO, KO, pO) {
        if (!OO.particlesEnabled() || KO.length < 2) return;
        const XO = performance.now();
        this.budget = Math.min(oQ, this.budget + (XO - this.lastMs) / 1e3 * oQ), this.lastMs = XO;
        const bK = [];
        let eO = 0,
          lO = KO[0];
        for (const QO of KO.slice(1)) {
          const OO = Math.min(48, Math.round(Math.hypot(QO[0] - lO[0], QO[1] - lO[1], QO[2] - lO[2]) * this.style.perBlock));
          bK.push([lO, QO, OO]), eO += OO, lO = QO
        }
        const vK = pO.length;
        eO += 10 * vK;
        const CO = eO > this.budget ? this.budget / eO : 1;
        if (0 === eO || CO * eO < 1) return;
        const hO = KO[0],
          [DO, MO, aK] = hO,
          oO = this.points;
        let FO = 0;
        const VO = (OO, KO, pO, XO) => {
          const bK = 4 * FO;
          oO[bK] = OO - DO, oO[bK + 1] = KO - MO, oO[bK + 2] = pO - aK, oO[bK + 3] = XO, FO++
        };
        bK.forEach(((OO, KO) => {
          let [pO, XO, bK] = OO;
          const eO = Math.min(Math.floor(bK * CO), oQ - FO),
            lO = Math.hypot(XO[0] - pO[0], XO[1] - pO[1], XO[2] - pO[2]),
            vK = 0 === KO && lO > 0 ? Math.min(.5, .1 * lO) / lO : 0;
          for (let CO = 0; CO < eO; CO++) {
            const OO = vK + (CO + .5) / eO * (1 - vK);
            VO(pO[0] + (XO[0] - pO[0]) * OO, pO[1] + (XO[1] - pO[1]) * OO, pO[2] + (XO[2] - pO[2]) * OO, .15)
          }
        }));
        const LO = Math.floor(10 * CO);
        for (let QO = 0; QO < vK; QO++) {
          const [OO, KO, XO] = pO[QO];
          for (let pO = 0; pO < LO && FO < oQ; pO++) VO(OO, KO, XO, 2.5)
        }
        this.budget -= FO, this.particles ??= OO.createParticles(function(OO) {
          const [KO, pO] = OO.colours;
          return {
            texture: "square_particle",
            YO: 400,
            minLifeTime: OO.life[0] / az,
            maxLifeTime: OO.life[1] / az,
            minSize: OO.size[0],
            maxSize: OO.size[1],
            minEmitPower: 1,
            maxEmitPower: 1,
            emitRate: 0,
            colorGradients: [{
              timeFraction: 0,
              minColor: [KO[0], KO[1], KO[2], 1],
              maxColor: [pO[0], pO[1], pO[2], 1]
            }, {
              timeFraction: 1,
              minColor: [KO[0], KO[1], KO[2], 0],
              maxColor: [pO[0], pO[1], pO[2], 0]
            }],
            blendMode: Iv.d.Add
          }
        }(this.style), {
          pos: hO
        }), this.particles.emitPoints(hO, oO, FO)
      }
    }
    const zz = new Set(["Sky Spring"]);

    function AQ(OO, KO, pO) {
      const XO = OO.split("|")[0];
      return "Air" !== KO || pO || ! function(OO) {
        const KO = OO.split("|")[0];
        return void 0 !== kp[KO] || zz.has(KO)
      }(XO) ? null : OO
    }
    class fQ {
      constructor() {
        this.lastTapAt = -1 / 0
      }
      isNewPress(OO) {
        const KO = OO - this.lastTapAt >= 300;
        return this.lastTapAt = OO, KO
      }
    }
    class dQ {
      constructor() {
        this.presses = new fQ, this.predicted = null
      }
      tap(OO, KO) {
        const pO = this.presses.isNewPress(KO);
        return pO && (this.predicted = {
          station: OO,
          at: KO
        }), pO
      }
      consumeServerOpen(OO, KO) {
        const pO = this.predicted;
        return !(null === pO || pO.station !== OO || KO - pO.at > 2e3) && (this.predicted = null, !0)
      }
    }
    class TQ {
      constructor() {
        this.thrustAt = -1 / 0
      }
      lit(OO, KO) {
        return OO && (this.thrustAt = KO), KO - this.thrustAt < 200
      }
    }
    const NQ = [.1, .05, .1],
      IQ = {
        texture: "effect_5",
        YO: Math.ceil(48),
        minLifeTime: .35,
        maxLifeTime: .8,
        minEmitPower: 1,
        maxEmitPower: 2,
        minSize: .2,
        maxSize: .45,
        emitRate: 0,
        gravity: [0, -2, 0],
        dir1: [-.15, -1, -.15],
        dir2: [.15, -1, .15],
        colorGradients: [{
          timeFraction: 0,
          minColor: [255, 217, 77, 1],
          maxColor: [255, 242, 128, 1]
        }, {
          timeFraction: 1,
          minColor: [120, 30, 0, 1],
          maxColor: [150, 45, 5, 1]
        }],
        blendMode: Iv.d.OneOne
      };
    class yz {
      constructor() {
        this.flames = new Map, this.lit = new Set, this.hold = new TQ, this.pos = [0, 0, 0], this.camera = [0, 0, 0], this.at = [0, 0, 0]
      }
      YV(OO, KO) {
        for (const [pO, XO] of KO.baf2JetFlames) OO.isLocalPlayer(pO) || (XO ? this.lit.add(pO) : this.lit.delete(pO))
      }
      onAfterRender(OO, KO) {
        const pO = performance.now(),
          XO = this.hold.lit(this.selfThrusting(OO, KO), pO);
        for (const [bK, eO] of this.flames)(bK === KO ? XO : this.lit.has(bK)) || this.setEmitting(eO, !1), bK === KO || OO.getPositionView(bK) ? !eO.emitting && pO - eO.offAt >= 1300 && (eO.particles.stop(), this.flames.delete(bK)) : (eO.particles.dispose(), this.flames.delete(bK), this.lit.delete(bK));
        XO && this.draw(OO, KO, KO);
        for (const bK of this.lit) this.draw(OO, KO, bK)
      }
      dispose() {
        for (const OO of this.flames.values()) OO.particles.dispose();
        this.flames.clear(), this.lit.clear()
      }
      selfThrusting(OO, KO) {
        var pO;
        const XO = OO.getLocalPlayerMovement();
        return !!XO && (null !== (bK = {
          option: null !== (pO = OO.getClientOption(KO, "jumpHoldThrust")) && void 0 !== pO ? pO : null,
          jumping: XO.jumpHeld,
          onGround: XO.onGround,
          alive: OO.isAlive(KO)
        }).option && bK.option.maxUpSpeed >= 0 && bK.jumping && !bK.onGround && bK.alive);
        var bK
      }
      draw(OO, KO, pO) {
        var XO, bK;
        const eO = this.pos;
        if (!OO.readDrawnPosition(pO, eO)) return;
        const lO = OO.readDrawnPosition(KO, this.camera) ? this.camera : eO;
        if (!((eO[0] - lO[0]) ** 2 + (eO[1] - lO[1]) ** 2 + (eO[2] - lO[2]) ** 2 < 1600) || !OO.particlesEnabled()) {
          const OO = this.flames.get(pO);
          return void(OO && this.setEmitting(OO, !1))
        }
        const vK = null !== (XO = this.flames.get(pO)) && void 0 !== XO ? XO : this.create(OO, pO, eO),
          CO = null !== (bK = OO.getDrawnHeading(pO)) && void 0 !== bK ? bK : 0,
          hO = this.at;
        hO[0] = eO[0] - .35 * Math.sin(CO), hO[1] = eO[1] + 1.05, hO[2] = eO[2] - .35 * Math.cos(CO), vK.particles.moveTo(hO), this.setEmitting(vK, !0)
      }
      setEmitting(OO, KO) {
        OO.emitting !== KO && (OO.emitting = KO, KO || (OO.offAt = performance.now()), OO.particles.setEmitRate(KO ? 60 : 0))
      }
      create(OO, KO, pO) {
        const XO = {
          particles: OO.createParticles(IQ, {
            pos: pO,
            half: NQ
          }),
          emitting: !1,
          offAt: performance.now()
        };
        return this.flames.set(KO, XO), XO
      }
    }

    function gz(OO) {
      return "Reactor Frame" === np("reactor", OO)
    }

    function uQ(OO) {
      return jX("reactor", OO) && !gz(OO) && (OO.startsWith("Reactor Glass") || OO.startsWith("Reactor Port"))
    }
    const EQ = "baf2Goal";
    class jz {
      constructor() {
        this.goal = null, this.open = null, this.checkedAt = -1 / 0, this.subs = [Ib.i.subscribe("setDirectionArrow", (OO => {
          let {
            id: KO,
            position: pO
          } = OO;
          KO === EQ && (this.goal = pO, this.checkedAt = -1 / 0)
        })), Ib.i.subscribe("clearDirectionArrow", (OO => {
          let {
            id: KO
          } = OO;
          null !== KO && KO !== EQ || (this.goal = null, this.open = null)
        }))]
      }
      dispose() {
        for (const OO of this.subs) Ib.i.unsubscribe(OO)
      }
      sideOf(OO, KO, pO, XO) {
        const bK = this.goal;
        if (!bK) return 0;
        pO - this.checkedAt > 1e3 && (this.checkedAt = pO, this.open = function(OO, KO) {
          const [pO, XO, bK] = OO.map(Math.floor);
          if (!uQ(KO(pO, XO, bK))) return null;
          for (const [eO, lO] of [
              [1, 0],
              [0, 1]
            ]) {
            const OO = KO(pO + eO, XO, bK + lO),
              vK = KO(pO - eO, XO, bK - lO);
            if (gz(vK) && uQ(OO)) return [eO, 0, lO];
            if (gz(OO) && uQ(vK)) return [0 - eO, 0, 0 - lO]
          }
          return null
        }(bK, ((KO, pO, XO) => OO.blockIdToBlockName(OO.getBlockId(KO, pO, XO)))));
        const eO = this.open;
        if (!eO) return 0;
        const lO = XO(bK);
        if (Math.abs(lO.x - KO.x) > .05 || Math.abs(lO.y - KO.y) > .05) return 0;
        const vK = XO([bK[0] + eO[0], bK[1], bK[2] + eO[2]]).x - lO.x;
        return Math.abs(vK) < .3 ? 0 : vK > 0 ? 1 : -1
      }
    }
    class YQ {
      constructor() {
        this.arrows = document.getElementsByClassName("DirectionArrow"), this.trackers = document.getElementsByClassName("Baf2QuestTracker"), this.statBars = document.getElementsByClassName("BottomScreenStatBarList"), this.toasts = document.getElementsByClassName("Baf2Toast"), this.moved = new Map, this.sideLabels = new Map, this.labelOffsets = new WeakMap, this.side = new jz, this.project = null, this.api = null, this.anchors = new WeakMap, this.halfWidths = new WeakMap, this.labels = new Set, this.queued = !1, this.YX = !1, this.em = 12, this.refreshedAt = -1 / 0, this.tracker = null, this.hud = null, this.box = null, this.boxStale = !0, this.bars = null, this.barsStale = !0, this.toastEl = null, this.toast = null, this.onChange = () => {
          this.boxStale = !0
        }, this.innerWidth = window.innerWidth, this.innerHeight = window.innerHeight, this.tV = () => {
          this.boxStale = !0, this.barsStale = !0, this.innerWidth = window.innerWidth, this.innerHeight = window.innerHeight
        }, this.sizes = new ResizeObserver((OO => {
          for (const KO of OO) KO.target === this.tracker ? this.boxStale = !0 : this.halfWidths.set(KO.target, KO.borderBoxSize[0].inlineSize / 2)
        })), this.hudStyle = new MutationObserver(this.onChange), this.run = () => {
          this.queued = !1, this.YX || this.clear()
        }, window.addEventListener("resize", this.tV)
      }
      onAfterRender(OO, KO) {
        var pO;
        this.api = OO, this.project = null !== (pO = null === KO || void 0 === KO ? void 0 : KO.projectWorldPosToScreenPos) && void 0 !== pO ? pO : null, this.queued || this.YX || (this.queued = !0, queueMicrotask(this.run))
      }
      dispose() {
        this.YX = !0;
        for (const OO of this.moved.keys()) OO.style.transform = "";
        this.moved.clear();
        for (const OO of this.sideLabels.keys()) OO.style.transform = "";
        this.sideLabels.clear(), this.side.dispose(), this.watch(null), this.sizes.disconnect(), window.removeEventListener("resize", this.tV)
      }
      clear() {
        for (const eO of this.moved.keys()) eO.isConnected || this.moved.delete(eO);
        for (const eO of this.sideLabels.keys()) eO.isConnected || this.sideLabels.delete(eO);
        if (0 === this.arrows.length) return;
        const OO = performance.now(),
          KO = OO - this.refreshedAt > 1e3;
        KO && (this.refreshedAt = OO, this.boxStale = !0, this.barsStale = !0, this.forgetGoneLabels());
        const pO = this.trackerBox(),
          XO = this.barsBox(),
          bK = this.toastBox(KO);
        (pO || XO || bK) && KO && (this.em = parseFloat(getComputedStyle(this.arrows[0]).fontSize) || this.em);
        for (let eO = 0; eO < this.arrows.length; eO++) {
          const KO = this.arrows[eO];
          this.labelOffsets.set(KO, this.runLabelAside(KO, OO));
          const lO = (pO ? this.shiftLeftOf(KO, pO) : 0) || this.shiftOnScreen(KO),
            vK = Math.min(XO ? this.liftAbove(KO, XO, lO) : 0, bK ? this.liftAbove(KO, bK, lO) : 0),
            CO = this.moved.get(KO);
          if (0 !== lO || 0 !== vK) {
            const OO = 0 === vK ? `translateX(${lO}px)` : `translate(${lO}px, ${vK}px)`;
            CO !== OO && (KO.style.transform = OO, this.moved.set(KO, OO))
          } else void 0 !== CO && (KO.style.transform = "", this.moved.delete(KO))
        }
      }
      trackerBox() {
        var OO, KO;
        const pO = null !== (OO = this.tracker) && void 0 !== OO && OO.isConnected ? this.tracker : null !== (KO = this.trackers[0]) && void 0 !== KO ? KO : null;
        if (pO !== this.tracker && this.watch(pO), this.boxStale && pO) {
          var XO, bK, eO;
          this.boxStale = !1;
          const OO = pO.closest(".NoRoom") ? null : pO.getBoundingClientRect(),
            KO = OO && OO.width > 0 ? null === (XO = this.hud) || void 0 === XO ? void 0 : XO.getBoundingClientRect() : void 0,
            lO = OO && KO ? Math.max(OO.top, KO.top) : null !== (bK = null === OO || void 0 === OO ? void 0 : OO.top) && void 0 !== bK ? bK : 0,
            vK = OO && KO ? Math.min(OO.bottom, KO.bottom) : null !== (eO = null === OO || void 0 === OO ? void 0 : OO.bottom) && void 0 !== eO ? eO : 0;
          this.box = OO && OO.width > 0 && vK > lO ? {
            left: OO.left,
            top: lO,
            right: OO.right,
            bottom: vK
          } : null
        }
        return pO ? this.box : null
      }
      barsBox() {
        if (this.barsStale) {
          var OO;
          this.barsStale = !1;
          const KO = null === (OO = this.statBars[0]) || void 0 === OO ? void 0 : OO.getBoundingClientRect();
          this.bars = KO && KO.width > 0 && KO.height > 0 ? {
            left: KO.left,
            top: KO.top,
            right: KO.right,
            bottom: KO.bottom
          } : null
        }
        return this.bars
      }
      toastBox(OO) {
        var KO;
        const pO = null !== (KO = this.toasts[0]) && void 0 !== KO ? KO : null;
        if (pO !== this.toastEl || OO && pO) {
          this.toastEl = pO;
          const OO = null === pO || void 0 === pO ? void 0 : pO.getBoundingClientRect();
          this.toast = OO && OO.width > 0 && OO.height > 0 ? {
            left: OO.left,
            top: OO.top,
            right: OO.right,
            bottom: OO.bottom
          } : null
        }
        return this.toast
      }
      liftAbove(OO, KO, pO) {
        var XO;
        const bK = this.anchorOf(OO);
        if (!bK) return 0;
        const eO = bK.x + pO + (null !== (XO = this.labelOffsets.get(OO)) && void 0 !== XO ? XO : 0),
          {
            halfWidth: lO,
            labelled: vK
          } = this.extentOf(OO),
          CO = bK.y + this.em * (vK ? 6.2 : 3);
        return CO < KO.top - 6 || eO + lO < KO.left - 6 || eO - lO > KO.right + 6 ? 0 : KO.top - 6 - CO
      }
      watch(OO) {
        var KO, pO;
        this.tracker && this.sizes.unobserve(this.tracker), null === (KO = this.hud) || void 0 === KO || KO.removeEventListener("scroll", this.onChange), this.hudStyle.disconnect(), this.tracker = OO, this.hud = null !== (pO = null === OO || void 0 === OO ? void 0 : OO.closest(".Baf2QuestHud")) && void 0 !== pO ? pO : null, this.box = null, this.boxStale = !0, OO && this.sizes.observe(OO), this.hud && (this.hud.addEventListener("scroll", this.onChange, {
          passive: !0
        }), this.hudStyle.observe(this.hud, {
          attributes: !0,
          attributeFilter: ["style", "class"]
        }))
      }
      shiftLeftOf(OO, KO) {
        var pO;
        const XO = this.anchorOf(OO);
        if (!XO) return 0;
        const {
          y: bK
        } = XO, eO = XO.x + (null !== (pO = this.labelOffsets.get(OO)) && void 0 !== pO ? pO : 0), lO = this.em, {
          halfWidth: vK,
          labelled: CO
        } = this.extentOf(OO), hO = bK - lO, DO = eO + vK;
        return bK + lO * (CO ? 6.2 : 3) < KO.top || hO > KO.bottom || DO < KO.left - 6 || eO - vK > KO.right ? 0 : Math.max(KO.left - 6 - DO, 6 - (eO - vK))
      }
      shiftOnScreen(OO) {
        var KO;
        const pO = this.anchorOf(OO);
        if (!pO) return 0;
        const {
          halfWidth: XO
        } = this.extentOf(OO), bK = pO.x + (null !== (KO = this.labelOffsets.get(OO)) && void 0 !== KO ? KO : 0), eO = bK + XO - (this.innerWidth - 6);
        return eO > 0 ? -eO : Math.max(0, 6 - (bK - XO))
      }
      runLabelAside(OO, KO) {
        var pO;
        let XO = null;
        for (let lO = 0; lO < OO.children.length; lO++) OO.children[lO].classList.contains("DirectionArrowLabel") && (XO = OO.children[lO]);
        if (!XO) return 0;
        const bK = OO.classList.contains("DirectionArrowOnScreen") && this.project ? this.anchorOf(OO) : null,
          eO = (bK && this.api ? this.side.sideOf(this.api, {
            x: bK.x / this.innerWidth * 100,
            y: bK.y / this.innerHeight * 100
          }, KO, this.project) : 0) * this.halfWidthOf(XO);
        return eO !== (null !== (pO = this.sideLabels.get(XO)) && void 0 !== pO ? pO : 0) && (XO.style.transform = 0 === eO ? "" : `translateX(-50%) translateX(${eO}px)`, 0 === eO ? this.sideLabels.delete(XO) : this.sideLabels.set(XO, eO)), eO
      }
      extentOf(OO) {
        let KO = this.em,
          pO = !1;
        for (let XO = 0; XO < OO.children.length; XO++) {
          const bK = OO.children[XO],
            eO = bK.classList.contains("DirectionArrowLabel");
          pO ||= eO, (eO || bK.classList.contains("DirectionArrowDistance")) && (KO = Math.max(KO, this.halfWidthOf(bK)))
        }
        return {
          halfWidth: KO,
          labelled: pO
        }
      }
      halfWidthOf(OO) {
        let KO = this.halfWidths.get(OO);
        return void 0 === KO && (KO = OO.offsetWidth / 2, this.halfWidths.set(OO, KO), this.sizes.observe(OO), this.labels.add(OO)), KO
      }
      forgetGoneLabels() {
        for (const OO of this.labels) OO.isConnected || (this.sizes.unobserve(OO), this.halfWidths.delete(OO), this.labels.delete(OO))
      }
      anchorOf(OO) {
        const KO = OO.style.translate,
          pO = this.anchors.get(OO);
        if (pO && pO.translate === KO && pO.innerWidth === this.innerWidth && pO.innerHeight === this.innerHeight) return pO;
        const XO = /^(-?[\d.]+)vw (-?[\d.]+)vh$/.exec(KO);
        if (!XO) return null;
        const bK = {
          translate: KO,
          x: parseFloat(XO[1]) / 100 * this.innerWidth,
          y: parseFloat(XO[2]) / 100 * this.innerHeight,
          innerWidth: this.innerWidth,
          innerHeight: this.innerHeight
        };
        return this.anchors.set(OO, bK), bK
      }
    }
    const wQ = "Baf2ArrowText";

    function iz(OO, KO) {
      const pO = OO.rows.find((OO => OO.current));
      return iK(OO.tutorial) && null !== pO && void 0 !== pO && pO.item && re(pO) && EO(pO.item).includes(KO) ? pO.item : null
    }
    const rz = new class {
      constructor(OO) {
        this.select = OO, this.picks = new Map
      }
      open(OO, KO, pO) {
        const XO = iz(KO, OO);
        null !== XO && this.Kp(OO, XO, pO)
      }
      follow(OO, KO) {
        if (vK())
          for (const [pO, {
              item: XO,
              had: bK
            }] of this.picks) {
            const eO = iz(OO, pO);
            eO !== XO && (null !== eO && KO(XO) > bK ? this.Kp(pO, eO, KO) : this.picks.delete(pO))
          } else this.picks.clear()
      }
      clear() {
        this.picks.clear()
      }
      Kp(OO, KO, pO) {
        this.picks.set(OO, {
          item: KO,
          had: pO(KO)
        }), this.select(OO, KO)
      }
    }(ye.l);

    function PQ(OO) {
      return KO => {
        let pO = 0;
        for (const XO of OO.getInventoryItems())(null === XO || void 0 === XO ? void 0 : XO.name) === KO && (pO += null === XO.amount ? 1 : Math.max(XO.amount, 0));
        return pO
      }
    }

    function mz(OO, KO, pO, XO) {
      OO.getClientOption(KO, "canCraft") && "inventory" !== Mb.d.get("openInGameMenuName") && (rz.open(pO, XO.get(), PQ(OO)), Ib.i.pl("toggleMenu", `inventory|${pO}`))
    }
    let sQ = null,
      HQ = !1;

    function RQ(OO) {
      const KO = oe();
      OO === sQ && KO === HQ || (sQ = OO, HQ = KO, (0, ye.o)(function(OO, KO) {
        const pO = new Map;
        for (let XO = OO + 1; XO <= bK.length; XO++) {
          const bK = Pe(XO, OO, KO);
          if (bK)
            for (const KO of QO(XO).unlocks) pO.set(KO, {
              ...bK,
              stepsAway: XO - OO
            })
        }
        return pO
      }(OO, KO)))
    }

    function SQ() {
      return (0, ye.t)(rl(Object.keys(uO), Ee)), () => {
        (0, ye.t)([])
      }
    }
    const JQ = "buildAFactory2Game:",
      cz = {
        on: "lightbulb",
        hud: "list",
        off: "eye-slash"
      },
      BQ = {
        on: `${JQ}tutorialButtonOn`,
        hud: `${JQ}tutorialButtonHud`,
        off: `${JQ}tutorialButtonOff`
      },
      ZQ = {
        on: `${JQ}tutorialPickedOn`,
        hud: `${JQ}tutorialPickedHud`,
        off: `${JQ}tutorialPickedOff`
      };

    function GQ(OO, KO, pO) {
      let XO = null,
        bK = () => {};
      const eO = eO => {
        var lO;
        let {
          tutorial: vK,
          tutorialKnown: CO
        } = eO;
        (null === (lO = XO) || void 0 === lO ? void 0 : lO.tutorial) === vK && XO.tutorialKnown === CO || (XO = {
          tutorial: vK,
          tutorialKnown: CO
        }, bK = (0, hb.u)({
          id: "baf2Tutorial",
          order: -1,
          labelKey: BQ[vK],
          icon: {
            kind: "icon",
            name: cz[vK]
          },
          iconOnly: !0,
          disabled: !CO,
          className: "Baf2TutorialButton",
          onClick: () => {
            var XO;
            (XO => {
              const bK = KO.setTutorial(XO);
              OO.send(`baf2tutorial ${XO} ${bK}`), pO.show({
                baf2ToastText: [(0, rK.Qd)({
                  translationKey: ZQ[XO]
                }, rK.J.whiteUiText)],
                baf2ToastMs: 3e3,
                baf2ToastStyle: "baf2ToastInfo"
              })
            })((XO = KO.get().tutorial, wO[(wO.indexOf(XO) + 1) % wO.length]))
          }
        }))
      };
      eO(KO.get());
      const lO = Ib.i.subscribe(ge, eO);
      return () => {
        Ib.i.unsubscribe(lO), bK()
      }
    }

    function qz(OO, KO, pO) {
      var XO, bK;
      const eO = OO.getTargetedBlock();
      if (!eO || ! function(OO, KO, pO) {
          if ("Chest" !== KO) return !1;
          const XO = OO.split("|")[0];
          if (!Kp(XO) || 0 === yp[XO].outputSlots.length) return !1;
          const bK = eL(OO);
          return pO[0] === bK[0] && pO[1] === bK[1] && pO[2] === bK[2]
        }(pO, null === (XO = OO.mhO(KO)) || void 0 === XO ? void 0 : XO.name, eO.normal)) return !1;
      const [lO, vK, CO] = eO.Se, hO = OO.getBlockId(lO, vK, CO);
      return 0 === hO || !0 === (null === (bK = YO.l[hO]) || void 0 === bK ? void 0 : bK.canBePlacedOver)
    }
    var xz = pO(35264);
    const nQ = new Set(vX.d);
    class WQ {
      constructor(OO) {
        this.toasts = OO, this.lastAt = -1 / 0
      }
      onAltAction(OO, KO, pO) {
        const XO = OO.getTargetedBlock();
        if (!XO || function(OO) {
            const KO = OO.split("|")[0];
            return Kp(KO) || null !== VX(KO) || yK(KO) || vX.d.includes(KO)
          }(pO) && !nQ.has(pO.split("|")[0])) return;
        const bK = OO.mhO(KO);
        if (!bK || !nQ.has(bK.name.split("|")[0]) || Date.now() - this.lastAt < 4e3) return;
        const eO = bK.typeObj.id,
          [lO, vK, CO] = XO.Se,
          hO = OO.getBlockId(lO, vK, CO),
          DO = YO.l[hO];
        (0 === hO || null !== DO && void 0 !== DO && DO.Lp || null !== DO && void 0 !== DO && DO.canBePlacedOver) && OO.isSolidToPlayerBlockId(eO) && OO.canModifyBlockAt(lO, vK, CO) && OO.XCO(lO, vK, CO, eO) && !OO.XCO(lO, vK, CO, eO, KO) && (this.lastAt = Date.now(), this.toasts.show({
          baf2ToastText: [(0, rK.Qd)({
            translationKey: "buildAFactory2Game:beltStepBack"
          }, rK.J.whiteUiText)],
          baf2ToastMs: 2500,
          baf2ToastStyle: "baf2ToastInfo"
        }))
      }
    }
    class tz {
      constructor(OO) {
        this.show = OO, this.started = null, this.gatedThisHold = new Set, this.hintedAt = new Map
      }
      onMining(OO, KO, pO) {
        var XO;
        if (!KO) return this.started = null, void this.gatedThisHold.clear();
        if (!OO) return void(this.started = null);
        const bK = `${OO.x},${OO.y},${OO.z},${OO.JK}`;
        if (bK === this.started) return;
        this.started = bK;
        const eO = EX(OO.y) ? SL(OO.block, OO.JK, OO.level) : null;
        if (null === eO || this.gatedThisHold.has(bK)) return;
        this.gatedThisHold.add(bK);
        const lO = OO.block.split("|")[0];
        pO - (null !== (XO = this.hintedAt.get(lO)) && void 0 !== XO ? XO : -1 / 0) < 5e3 || (this.hintedAt.set(lO, pO), this.show({
          baf2ToastText: JL(eO, OO.block),
          baf2ToastMs: 2500,
          baf2ToastStyle: "baf2ToastWarn"
        }))
      }
    }
    var kz = pO(36);

    function UQ(OO, KO) {
      const pO = [...OO.baf2CoreBankPaused];
      for (const [bK] of OO.baf2CoreBanked) pO.push(bK);
      for (const lO of bK) {
        for (const {
            item: OO
          }
          of lO.cost) pO.push(OO);
        for (const OO of lO.newDeposits) pO.push(OO.block);
        for (const OO of lO.unlocks) pO.push(OO, jK(OO));
        lO.reward && pO.push(lO.reward);
        for (const {
            item: OO
          }
          of null !== (XO = null === (eO = lO.charge) || void 0 === eO ? void 0 : eO.items) && void 0 !== XO ? XO : []) {
          var XO, eO;
          pO.push(OO)
        }
      }
      return {
        message: OO,
        itemNames: KO([...new Set(pO)])
      }
    }
    const Oz = "baf2MultiblockGuide";
    const Kz = new Map;
    const pz = function(OO, KO, pO, bK) {
      let {
        localPlayerId: eO
      } = bK;
      const lO = new lv,
        vK = new Ra,
        hO = new qo,
        DO = new Za(hO),
        MO = (OO, KO) => {
          KO ? DO.observe(OO) : DO.unobserve(OO)
        },
        aK = new Ba,
        oO = new to(MO),
        FO = OO => oO.covers(OO),
        VO = new Lo;
      let LO;
      const QO = new El((OO => {
          LO.sendCommand(OO)
        })),
        zK = () => {
          QO.send("baf2questbook")
        },
        AO = OO => function(OO, KO, pO) {
          const XO = {};
          for (const bK of pO) {
            let pO = Kz.get(bK);
            void 0 === pO && (pO = OO.getItemStat(KO, bK, "displayName"), Kz.set(bK, pO)), XO[bK] = pO
          }
          return XO
        }(LO, eO, OO),
        fO = new je(zK),
        dO = new uo((() => Mb.d.get("loadingOverlayVisible"))),
        TO = new iF,
        NO = new WQ(dO),
        IO = new tz((OO => {
          dO.show(OO, OO.baf2ToastMs)
        })),
        gK = new cF(MO),
        uO = new FL(gK),
        EO = new Fl,
        jK = new sL,
        wO = new Gl,
        iK = new Wo({
          read: () => !1 !== kz.e.getItem(Oz),
          write: OO => {
            kz.e.setItem(Oz, OO)
          }
        }),
        mK = new TF(iK),
        sO = new yV(iK),
        HO = new xV(iK, (OO => function(OO, KO) {
          const pO = cC(KO.w, KO.h, KO.d),
            XO = new Uint8Array(pO);
          for (let bK = 0; bK < pO; bK++) {
            const pO = QF(OO, Bp(KO, xX(KO, bK)));
            XO[bK] = null === pO ? 0 : Hv(pO)
          }
          return XO
        }(LO, OO)), HF(QO)),
        RO = new nF(iK, HF(QO)),
        SO = new GF,
        JO = (OO, KO) => {
          let [pO, XO, bK] = OO;
          SO.answered(KO) || dO.show({
            baf2ToastText: [(0, rK.Qd)({
              translationKey: "buildAFactory2Game:rxSizeNotTaken",
              params: {
                w: pO,
                h: XO,
                d: bK
              }
            }, rK.J.whiteUiText)],
            baf2ToastMs: 4e3,
            baf2ToastStyle: "baf2ToastWarn"
          })
        };
      HO.onSizeNotTaken(JO), RO.onSizeNotTaken(JO);
      const ZO = new UF,
        GO = new wV(iK),
        qK = new rL,
        nO = new GV(qK),
        WO = new XL,
        tK = new VL,
        UO = new yQ(tK),
        OK = new mQ(tK),
        KK = tK.lookSource(),
        pK = new kQ({
          handles: OO => KK.handles(OO) || OO === PO,
          line: (OO, KO) => OO === PO ? function(OO, KO, pO) {
            var XO;
            const bK = BO(null === (XO = KO.at(pO)) || void 0 === XO ? void 0 : XO.item);
            return null === bK ? {
              key: `${nL}lookFarmEmpty`
            } : {
              key: OO.blockIdToBlockName(OO.getBlockId(pO[0], pO[1], pO[2])).endsWith("|Running") ? `${nL}lookFarmRunning` : `${nL}lookFarmWaiting`,
              keys: {
                mob: cK(bK)
              }
            }
          }(LO, gK, KO) : KK.line(OO, KO),
          version: () => KK.version() + gK.version()
        }, (OO => uF(iK.all(), OO, (OO => QF(LO, OO)))), (() => fO.get().tier)),
        XK = new LV,
        eK = new MQ,
        lK = new QQ,
        vp = QQ.blade(),
        CK = new yz,
        hK = new mF,
        DK = new YQ,
        MK = new dQ,
        ap = new fQ;
      let oK = -1 / 0,
        FK = 0,
        VK = -1 / 0,
        LK = -1 / 0;
      const QK = () => {
          QO.send("baf2islandsclose"), LK = Date.now()
        },
        zp = [];

      function AK(OO) {
        var KO, pO, XO, bK, eO, lO, CO;
        "core" === (null === (KO = vK.get()) || void 0 === KO ? void 0 : KO.kind) && "core" !== (null === OO || void 0 === OO ? void 0 : OO.kind) && QO.send("baf2coreclose"), "power" === (null === (pO = vK.get()) || void 0 === pO ? void 0 : pO.kind) && "power" !== (null === OO || void 0 === OO ? void 0 : OO.kind) && QO.send("baf2powerclose"), "water" === (null === (XO = vK.get()) || void 0 === XO ? void 0 : XO.kind) && "water" !== (null === OO || void 0 === OO ? void 0 : OO.kind) && QO.send(kK.q), "terminal" === (null === (bK = vK.get()) || void 0 === bK ? void 0 : bK.kind) && "terminal" !== (null === OO || void 0 === OO ? void 0 : OO.kind) && QO.send("baf2terminalclose"), "islands" === (null === (eO = vK.get()) || void 0 === eO ? void 0 : eO.kind) && "islands" !== (null === OO || void 0 === OO ? void 0 : OO.kind) && QK();
        const hO = tK.getStatus();
        "collider" === (null === (lO = vK.get()) || void 0 === lO ? void 0 : lO.kind) && "collider" !== (null === OO || void 0 === OO ? void 0 : OO.kind) && hO && QO.send(yh(hO, "close"));
        const DO = OO => "reactor" === OO || "battery" === OO;
        if (DO(null === (CO = vK.get()) || void 0 === CO ? void 0 : CO.kind) && !DO(null === OO || void 0 === OO ? void 0 : OO.kind)) {
          var MO, aK, oO;
          const OO = "reactor" === (null === (MO = vK.get()) || void 0 === MO ? void 0 : MO.kind) ? null === (aK = HO.get()) || void 0 === aK ? void 0 : aK.status.baf2RxAt : null === (oO = RO.get()) || void 0 === oO ? void 0 : oO.status.baf2BatAt;
          OO && QO.send(bp(OO, "close"))
        }
        "quests" === (null === OO || void 0 === OO ? void 0 : OO.kind) && zK(), vK.set(OO), null === OO && TO.release()
      }

      function dK() {
        (0, Db.g)(), AK(null)
      }
      let TK = new Set,
        NK = !1;
      const IK = {
        onCreate: OO => {
          LO = OO, LO.setGroundArrowStyle({
            width: .6,
            alpha: .5,
            endAtSolidFace: !0
          });
          for (const KO of fK) {
            const OO = yp[KO].inputSlots ? dv(lO) : zC(KO, lO, EO, QO);
            zp.push((0, Cb.h)(KO, OO))
          }
          zp.push((0, Db.q)((0, XO.createElement)(XO.Fragment, null, (0, XO.createElement)(Oo, {
            controller: oO
          }), (0, XO.createElement)(Go, {
            store: gK
          }), (0, XO.createElement)(OQ, {
            store: pK
          }), (0, XO.createElement)(yF, {
            store: fO
          }), (0, XO.createElement)(Yo, {
            store: dO
          }), (0, XO.createElement)(rF, {
            store: TO
          }), (0, XO.createElement)(Ho, {
            store: hK
          }), (0, XO.createElement)(kV, {
            store: ZO
          }), (0, XO.createElement)(PV, {
            store: qK
          })), {
            content: (0, XO.createElement)(Sa, {
              commands: QO,
              store: vK,
              power: EO,
              water: wO,
              reactor: HO,
              battery: RO,
              collider: tK,
              terminal: jK,
              quests: fO,
              close: Db.j,
              DX: () => {
                TO.dropHeld(), (0, Db.g)()
              },
              askIslands: () => {
                LK = -1 / 0, oK = Date.now(), FK = QO.send(xK)
              },
              openSocial: () => {
                (0, Db.g)(), Mb.d.set({
                  openEverythingMenuName: Xp.o.SOCIAL
                })
              },
              showCore: OO => {
                AK({
                  kind: "core",
                  core: OO
                }), QO.send("baf2corereopen")
              }
            }),
            onClose: () => {
              AK(null)
            }
          })), zp.push((0, hb.u)({
            id: "baf2Quests",
            labelKey: "buildAFactory2Game:questBookTitle",
            icon: {
              kind: "item",
              name: "Book"
            },
            className: "Baf2QuestsButton",
            onClick: () => {
              AK({
                kind: "quests"
              }), (0, Db.o)()
            }
          })), zp.push(GQ(QO, fO, dO)), NK = !1, zp.push(Fe((() => {
            null !== sQ && RQ(sQ)
          }))), zp.push(SQ()), zp.push(function() {
            const OO = Ib.i.subscribe(ge, ce),
              KO = () => {
                if (Jb) {
                  const OO = Jb;
                  Jb = null, (0, ye.r)(OO)
                }
              },
              pO = Ib.i.subscribe("toggleMenu", (OO => {
                "inventory" === (null === OO || void 0 === OO ? void 0 : OO.split("|")[0]) && KO()
              })),
              XO = Ib.i.subscribe("appManagerUpdated|openInGameMenuName", (OO => {
                "inventory" === OO && KO()
              }));
            return () => {
              Ib.i.unsubscribe(OO), Ib.i.unsubscribe(pO), Ib.i.unsubscribe(XO)
            }
          }()), zp.push(function(OO) {
            const KO = PQ(OO),
              pO = Ib.i.subscribe(ge, (OO => {
                rz.follow(OO, KO)
              }));
            return () => {
              Ib.i.unsubscribe(pO), rz.clear()
            }
          }(LO)), zp.push(function() {
            const OO = document.documentElement,
              KO = (0, zF.d)(".InvenBodyRight", [], (() => {
                const KO = document.querySelector(".InvenBodyRight");
                KO && OO.style.setProperty("--baf2-backpack-width", `${KO.offsetWidth}px`)
              }));
            return () => {
              KO(), OO.style.removeProperty("--baf2-backpack-width")
            }
          }()), zp.push(function() {
            const OO = document.documentElement;
            return OO.classList.add(wQ), () => {
              OO.classList.remove(wQ)
            }
          }()), zp.push((() => {
            DO.dispose(), hO.dispose()
          })), VO.start(LO), zp.push((() => {
            VO.dispose(), CK.dispose(), uO.dispose()
          }))
        },
        onClose: () => {
          (0, ye.r)([]), Jb = null, Sb = new Set, sQ = null, (0, ye.o)(new Map), Kz.clear();
          for (const OO of zp) OO();
          fO.dispose(), pK.dispose(), dO.dispose(), TO.dispose(), XK.dispose(), eK.dispose(LO), mK.dispose(LO), sO.dispose(LO), GO.dispose(LO), nO.dispose(LO), qK.dispose(), WO.dispose(), iK.dispose(), HO.dispose(), RO.dispose(), ZO.dispose(), lK.dispose(), vp.dispose(), hK.dispose(), UO.dispose(LO), OK.dispose(LO), tK.dispose(), DK.dispose(), QO.clear()
        },
        onAfterRender: (OO, KO) => {
          var pO, XO, bK;
          try {
            VO.onAfterRender(KO)
          } catch (hO) {
            console.error("Error drawing BAF2 belt items", hO)
          }
          try {
            CK.onAfterRender(LO, eO)
          } catch (hO) {
            console.error("Error drawing BAF2 jet flames", hO)
          }
          NK || (NK = !0, QO.send("baf2clientready"));
          const lO = LO.getPositionView(eO);
          oO.onAfterRender(KO, lO, aK), gK.onAfterRender(KO, lO, aK, FO), DO.run(aK), XK.onAfterRender(LO, lO), eK.onAfterRender(LO, lO), uO.onAfterRender(LO, lO), mK.onAfterRender(LO, lO), sO.onAfterRender(LO, eO, lO), GO.onAfterRender(LO, eO, lO), nO.onAfterRender(LO, eO), WO.onAfterRender(LO, lO), fO.onPlayerY(lO[1]), UO.onAfterRender(LO), OK.onAfterRender(LO, eO, lO);
          const CO = LO.getTargetedBlock();
          pK.onAfterRender(LO, eO, null !== (pO = null === CO || void 0 === CO ? void 0 : CO.blO) && void 0 !== pO ? pO : 0, null !== (XO = null === CO || void 0 === CO ? void 0 : CO.position) && void 0 !== XO ? XO : null), DK.onAfterRender(LO, KO), IO.onMining(function(OO, KO) {
            var pO, XO;
            const bK = OO.getMiningBlock();
            if (!bK) return null;
            const eO = (0, YO.h)(OO.getBlockId(bK[0], bK[1], bK[2])),
              lO = null !== (pO = null === (XO = OO.mhO(KO)) || void 0 === XO ? void 0 : XO.name) && void 0 !== pO ? pO : null,
              vK = OO.getItemStat(KO, eO.split("|")[0], "harvestLevel");
            return {
              block: eO,
              x: bK[0],
              y: bK[1],
              z: bK[2],
              JK: lO,
              level: vK
            }
          }(LO, eO), LO.isMining(), performance.now()), "dropMap" === (null === (bK = vK.get()) || void 0 === bK ? void 0 : bK.kind) && EX(lO[1]) && dK()
        },
        onPlayerChangeBlock: (OO, KO, pO, XO, bK, lO) => {
          OO === eO && function(OO, KO, pO, XO, bK, eO, lO) {
            const vK = AQ(eO, lO, OO.isPlayerCrouching(KO));
            if (null === vK) return;
            if (OO.EKO(pO, XO, bK, vK), !OO.getClientOption(KO, "canPickUpItems")) return;
            const CO = kp[vK.split("|")[0]];
            var hO, DO, MO;
            void 0 !== CO && (hO = OO.getInventoryItems(), DO = CO, MO = tF.h.maxItemStackSize, OO.getInventoryFreeSlotCount(KO) > 0 || hO.some((OO => null !== OO && OO.name === DO && null !== OO.amount && OO.amount < MO))) && OO.playSound(KO, (0, xz.d)("pickUp"), .5, 1)
          }(LO, OO, KO, pO, XO, bK, lO)
        },
        onPlayerAltAction: (OO, KO, pO, XO, bK) => {
          var lO, vK;
          if (!LO.getClientOption(eO, "canPickUpItems")) return;
          const CO = null !== (lO = null === (vK = LO.mhO(eO)) || void 0 === vK ? void 0 : vK.name) && void 0 !== lO ? lO : null,
            hO = function(OO, KO) {
              const pO = OO.split("|")[0];
              return yK(pO) && KO !== UX && "Sky Pack" !== KO ? pO : null
            }(bK, CO);
          if (null !== hO) return void(MK.tap(hO, performance.now()) && mz(LO, eO, hO, fO));
          if (!ib(CO)) return;
          const DO = ap.isNewPress(performance.now()),
            MO = function(OO, KO, pO) {
              return !ib(KO) || pO ? null : cb(OO)
            }(bK, CO, LO.isPlayerCrouching(eO));
          null !== MO && DO && LO.EKO(KO, pO, XO, MO)
        },
        onPlayerAttemptAltAction: (OO, KO, pO, XO, bK) => {
          if (function(OO, KO, pO, XO, bK) {
              "Workbench" === XO.split("|")[0] && OO.getClientOption(pO, "canCraft") && (rz.open("Workbench", bK.get(), PQ(OO)), KO.send("baf2station Workbench"))
            }(LO, QO, eO, bK, fO), qz(LO, eO, bK)) return "preventAction";
          NO.onAltAction(LO, eO, bK)
        },
        onReceivedMessageFromServer: (OO, KO) => {
          if ("baf2MachineStatus" === OO) {
            var pO, XO, bK, hO, DO, MO, aK, FO, zK, NO, IO, yK, uO, YO, rK, PO;
            const OO = KO,
              eO = OO.baf2MachineTaught;
            lO.set(OO.baf2MachinePos, {
              status: OO.baf2MachineStatus,
              power: null !== (pO = OO.baf2MachinePower) && void 0 !== pO ? pO : null,
              opLeftMs: null !== (XO = OO.baf2MachineOpLeftMs) && void 0 !== XO ? XO : null,
              dug: OO.baf2MachineYield ? {
                item: OO.baf2MachineYield,
                name: AO([OO.baf2MachineYield])[OO.baf2MachineYield]
              } : null,
              powerCap: null !== (bK = OO.baf2MachinePowerCap) && void 0 !== bK ? bK : null,
              powerRates: null !== (hO = OO.baf2MachinePowerRates) && void 0 !== hO ? hO : null,
              coupled: !0 === OO.baf2MachineCoupled,
              couplerLevel: null !== (DO = OO.baf2MachineCoupler) && void 0 !== DO ? DO : 1,
              taught: eO,
              taughtName: eO ? AO([eO])[eO] : null,
              tier: null !== (MO = OO.baf2MachineTier) && void 0 !== MO ? MO : null,
              input: null !== (aK = OO.baf2MachineInput) && void 0 !== aK ? aK : null,
              inertCoupler: null !== (FO = OO.baf2MachineInertCoupler) && void 0 !== FO ? FO : null,
              inputShort: null !== (zK = OO.baf2MachineInputShort) && void 0 !== zK ? zK : null,
              field: null !== (NO = OO.baf2MachineField) && void 0 !== NO ? NO : null,
              noSeeds: !0 === OO.baf2MachineNoSeeds,
              fuelFed: !0 === OO.baf2MachineFuelFed,
              fuelFeeds: !0 === OO.baf2MachineFuelFeeds,
              coreFull: !0 === OO.baf2MachineCoreFull,
              waterUnpowered: !0 === OO.baf2MachineWaterUnpowered,
              powerShort: !0 === OO.baf2MachinePowerShort,
              powerWait: !0 === OO.baf2MachinePowerWait,
              reactorPowered: !0 === OO.baf2MachineReactorPowered,
              fuelLeftMs: null !== (IO = OO.baf2MachineFuelLeftMs) && void 0 !== IO ? IO : null,
              burning: null !== (yK = OO.baf2MachineBurning) && void 0 !== yK ? yK : null,
              fuelKeep: null !== (uO = OO.baf2MachineFuelKeep) && void 0 !== uO ? uO : null,
              water: null !== (YO = OO.baf2MachineWater) && void 0 !== YO ? YO : null,
              farm: null !== (rK = OO.baf2MachineFarm) && void 0 !== rK ? rK : null,
              cryo: null !== (PO = OO.baf2MachineCryo) && void 0 !== PO ? PO : null
            })
          } else if ("baf2StationOpen" === OO) {
            const OO = KO.baf2Station;
            MK.consumeServerOpen(OO, performance.now()) || mz(LO, eO, OO, fO)
          } else if ("baf2Power" === OO) {
            const OO = KO;
            EO.set(OO), OO.baf2PowerOpen && (AK({
              kind: "power"
            }), (0, Db.o)())
          } else if (OO === kK.w) {
            const OO = KO;
            wO.set(OO), OO.baf2WaterOpen && (AK({
              kind: "water"
            }), (0, Db.o)())
          } else if ("baf2RxPlans" === OO) {
            var mK, sO, JO;
            const OO = KO;
            iK.YV(OO);
            const pO = new Set(OO.baf2RxPlanList.map((OO => {
              let [KO, pO, XO] = OO;
              return `${KO},${pO},${XO}`
            })));
            ZO.retain(pO);
            const XO = null === (mK = vK.get()) || void 0 === mK ? void 0 : mK.kind,
              bK = "reactor" === XO ? null === (sO = HO.get()) || void 0 === sO ? void 0 : sO.status.baf2RxAt : "battery" === XO ? null === (JO = RO.get()) || void 0 === JO ? void 0 : JO.status.baf2BatAt : void 0;
            bK && TK.has(bK.join(",")) && !pO.has(bK.join(",")) && dK(), TK = pO
          } else if ("baf2RxStatus" === OO) {
            const OO = KO;
            HO.set(OO), OO.baf2RxOpen && (AK({
              kind: "reactor"
            }), (0, Db.o)())
          } else if ("baf2BatStatus" === OO) {
            const OO = KO;
            RO.set(OO), OO.baf2BatOpen && (AK({
              kind: "battery"
            }), (0, Db.o)())
          } else if ("baf2RxAlarm" === OO) ZO.YV(KO);
          else if ("baf2Bomb" === OO) qK.YV(KO, LO.getPositionView(eO));
          else if ("baf2Fallout" === OO) WO.YV(KO);
          else if ("baf2ColBeams" === OO) tK.onBeams(KO);
          else if ("baf2ColStatus" === OO) {
            const OO = KO;
            var cK, BO;
            if (tK.onStatus(OO), OO.baf2ColOpen) tK.onOpen(null !== (cK = null === (BO = LO.mhO(eO)) || void 0 === BO ? void 0 : BO.name) && void 0 !== cK ? cK : null), AK({
              kind: "collider"
            }), (0, Db.o)()
          } else if ("baf2Terminal" === OO) {
            const OO = KO;
            var GO;
            if (jK.apply(OO)) OO.baf2TermReset && (AK({
              kind: "terminal"
            }), (0, Db.o)());
            else "terminal" === (null === (GO = vK.get()) || void 0 === GO ? void 0 : GO.kind) && (vK.set(null), (0, Db.g)())
          } else if ("baf2Core" === OO) {
            var nO;
            const OO = KO;
            if (CO(!0 === OO.baf2CoreNuclear), function(OO, KO) {
                return "core" === (null === OO || void 0 === OO ? void 0 : OO.kind) && KO.baf2CoreTier > OO.core.message.baf2CoreTier
              }(vK.get(), OO)) return void(0, Db.g)();
            if (OO.baf2CoreRefresh && "core" !== (null === (nO = vK.get()) || void 0 === nO ? void 0 : nO.kind)) return;
            AK({
              kind: "core",
              core: UQ(OO, AO)
            }), OO.baf2CoreRefresh || (0, Db.o)()
          } else if ("baf2WrenchUndo" === OO) {
            const {
              baf2WrenchPos: OO,
              baf2WrenchBlock: pO
            } = KO;
            LO.EKO(OO[0], OO[1], OO[2], pO)
          } else if ("baf2Toast" === OO) {
            const OO = KO;
            SO.heard(performance.now(), OO.baf2ToastMs), dO.show(OO)
          } else if ("baf2Area" === OO) TO.arrive(KO, null !== vK.get());
          else if ("baf2Quest" === OO) {
            const OO = KO;
            CO(!0 === OO.baf2QuestNuclear), fO.set(OO, function(OO, KO) {
              var pO, XO, bK, eO, lO;
              const vK = [];
              for (const [, , DO, , , , , , MO, aK] of OO.baf2QuestSteps) null !== DO && vK.push(DO), vK.push(...null !== MO && void 0 !== MO ? MO : [], ...null !== aK && void 0 !== aK ? aK : []);
              OO.baf2QuestReward && vK.push(OO.baf2QuestReward);
              const CO = null === (pO = OO.baf2QuestSide) || void 0 === pO ? void 0 : pO[2][2];
              CO && vK.push(CO), vK.push(...null !== (XO = null === (bK = OO.baf2QuestSide) || void 0 === bK ? void 0 : bK[2][8]) && void 0 !== XO ? XO : [], ...null !== (eO = null === (lO = OO.baf2QuestSide) || void 0 === lO ? void 0 : lO[2][9]) && void 0 !== eO ? eO : []);
              for (const [DO] of null !== (hO = OO.baf2QuestAlso) && void 0 !== hO ? hO : []) {
                var hO;
                vK.push(DO)
              }
              return KO(vK)
            }(OO, AO)), RQ(OO.baf2QuestTier)
          } else if ("baf2Route" === OO) ! function(OO, KO) {
            let {
              baf2RouteCells: pO,
              baf2RouteInto: XO
            } = KO;
            0 !== pO.length && XO ? OO.setRouteChevrons({
              cells: pO.map(((OO, KO) => {
                const [bK, , eO] = function(OO, KO, pO) {
                  const XO = pO + 1 < OO.length ? OO[pO + 1] : KO;
                  return [XO[0] - OO[pO][0], 0, XO[2] - OO[pO][2]]
                }(pO, XO, KO);
                return {
                  pos: OO,
                  way: [bK, eO]
                }
              })),
              colour: "#ffd640",
              alpha: .8
            }) : OO.setRouteChevrons(null)
          }(LO, KO);
          else if ("baf2QuestBook" === OO) fO.setBook(KO);
          else if ("baf2Stalls" === OO) oO.set(KO.baf2StallCells);
          else if (OO === vX.m) VO.onMoves(KO);
          else if (OO === vX.g) VO.onLines(KO);
          else if ("baf2Labels" === OO) gK.YV(KO);
          else if ("baf2DropMap" === OO) AK({
            kind: "dropMap",
            dropMap: KO
          }), (0, Db.o)();
          else if ("baf2Islands" === OO) {
            var UO, OK;
            const OO = KO;
            if (QO.syncIslandEdits(OO.baf2IslandsAnswered), !OO.baf2IslandsOpen && "islands" !== (null === (UO = vK.get()) || void 0 === UO ? void 0 : UO.kind)) return;
            if (OO.baf2IslandsOpen) {
              var KK, pK;
              const KO = Mb.d.get("openEverythingMenuName"),
                pO = QO.sent() >= FK,
                XO = "other" !== (zp = {
                  askedAtMs: oK,
                  askSent: pO,
                  reaskedAtMs: VK,
                  nowMs: Date.now(),
                  panel: null !== (KK = null === (pK = vK.get()) || void 0 === pK ? void 0 : pK.kind) && void 0 !== KK ? KK : null,
                  inGameMenu: Mb.d.get("openInGameMenuName"),
                  everythingMenu: null === KO ? null : KO === Xp.o.SHOP ? "shop" : "other",
                  focusInvite: void 0 !== OO.baf2IslandsFocusInvite
                }).everythingMenu && (!!zp.focusInvite || "islands" === zp.panel && "clientGame" === zp.inGameMenu || !(zp.nowMs - zp.reaskedAtMs < dh) && (zp.askSent && zp.nowMs - zp.askedAtMs < dh ? "core" === zp.panel && "clientGame" === zp.inGameMenu && null === zp.everythingMenu : "shop" === zp.everythingMenu || null === zp.inGameMenu));
              if (pO && (oK = -1 / 0), VK = -1 / 0, !XO) return void QK()
            }
            const pO = (bp = OO.baf2IslandsOpen, eK = "islands" === (null === (OK = vK.get()) || void 0 === OK ? void 0 : OK.kind), DK = LK, ap = Date.now(), bp && !eK && ap - DK < dh);
            AK({
              kind: "islands",
              islands: OO,
              arrivedAtMs: Date.now(),
              backToCore: Th(vK.get())
            }), pO && (LK = -1 / 0, VK = Date.now(), QO.send(xK)), OO.baf2IslandsOpen && ("clientGame" !== Mb.d.get("openInGameMenuName") && (0, ae.e)(), (0, Db.o)())
          } else if ("baf2CoopTransfer" === OO) {
            var XK;
            const OO = KO;
            OO.baf2TransferOn ? (AK({
              kind: "transfer",
              transfer: OO,
              arrivedAtMs: Date.now()
            }), (0, Db.o)()) : "transfer" === (null === (XK = vK.get()) || void 0 === XK ? void 0 : XK.kind) && (0, Db.g)()
          } else "baf2IslandLeft" === OO ? (TO.dropHeld(), null !== vK.get() && dK(), "inventory" === Mb.d.get("openInGameMenuName") && (0, ae.e)()) : "baf2Arc" === OO ? lK.YV(LO, KO) : "baf2Blade" === OO ? vp.onBlade(LO, KO) : "baf2JetFlame" === OO ? CK.YV(LO, KO) : "baf2GearPower" === OO && hK.YV(KO);
          var bp, eK, DK, ap, zp
        }
      };
      return IK
    }
  },
  36902: (OO, KO, pO) => {
    function XO(OO, KO, pO) {
      const XO = new Set,
        bK = new ResizeObserver(pO),
        eO = () => {
          const KO = new Set(document.querySelectorAll(OO));
          let eO = !1;
          for (const OO of XO) KO.has(OO) || (bK.unobserve(OO), XO.delete(OO), eO = !0);
          for (const OO of KO) XO.has(OO) || (bK.observe(OO), lO.observe(OO, {
            attributes: !0,
            attributeFilter: ["class", "style"]
          }), XO.add(OO));
          eO && pO()
        },
        lO = new MutationObserver((KO => {
          KO.some((OO => "attributes" === OO.type)) && pO(), KO.some((KO => function(OO, KO, pO) {
            if ("childList" !== OO.type) return !1;
            for (const XO of OO.addedNodes)
              if (XO instanceof Element && (XO.matches(KO) || XO.querySelector(KO))) return !0;
            for (const XO of OO.removedNodes)
              if (XO instanceof Element)
                for (const OO of pO)
                  if (XO.contains(OO)) return !0;
            return !1
          }(KO, OO, XO))) && eO()
        }));
      lO.observe(document.body, {
        childList: !0,
        subtree: !0
      });
      for (const vK of KO) bK.observe(vK);
      return window.addEventListener("resize", pO), eO(), pO(), () => {
        bK.disconnect(), lO.disconnect(), window.removeEventListener("resize", pO)
      }
    }
    pO.d(KO, {
      d: () => XO
    })
  },
  36888: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      g: () => eO
    });
    const XO = new WeakMap;

    function bK(OO) {
      let KO = XO.get(OO);
      return KO || (KO = {
        hidden: OO.hidden,
        x: NaN,
        y: NaN
      }, XO.set(OO, KO)), KO
    }

    function eO(OO, KO) {
      const pO = bK(OO);
      pO.hidden !== KO && (pO.hidden = KO, OO.hidden = KO)
    }

    function lO(OO, KO, pO) {
      const XO = bK(OO);
      XO.x === KO && XO.y === pO || (XO.x = KO, XO.y = pO, OO.style.translate = `${KO}vw ${pO}vh`)
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);