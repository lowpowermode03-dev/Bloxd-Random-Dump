export const id = 14;
export const ids = [14];
export const modules = {
  37638: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => bK
    });
    const XO = [
        [25, 8, 56],
        [25, 8, 54]
      ],
      bK = function(OO, KO, pO) {
        let bK;
        return {
          onCreate: OO => {
            bK = OO
          },
          onPlayerAltAction: (OO, KO, pO, eO, lO, vK) => {
            XO.some((OO => OO[0] === KO && OO[2] === eO)) && bK.openShop(OO, !1)
          }
        }
      }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);