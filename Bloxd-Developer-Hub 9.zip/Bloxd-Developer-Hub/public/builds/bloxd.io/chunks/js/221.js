export const id = 221;
export const ids = [221];
export const modules = {
  36142: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(36146);
    class bK {
      static GetPlanes(OO) {
        const KO = [];
        for (let pO = 0; pO < 6; pO++) KO.push(new XO.d(0, 0, 0, 0));
        return bK.GetPlanesToRef(OO, KO), KO
      }
      static GetNearPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[2], KO.normal.y = pO[7] + pO[6], KO.normal.z = pO[11] + pO[10], KO.d = pO[15] + pO[14], KO.normalize()
      }
      static GetFarPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[2], KO.normal.y = pO[7] - pO[6], KO.normal.z = pO[11] - pO[10], KO.d = pO[15] - pO[14], KO.normalize()
      }
      static GetLeftPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[0], KO.normal.y = pO[7] + pO[4], KO.normal.z = pO[11] + pO[8], KO.d = pO[15] + pO[12], KO.normalize()
      }
      static GetRightPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[0], KO.normal.y = pO[7] - pO[4], KO.normal.z = pO[11] - pO[8], KO.d = pO[15] - pO[12], KO.normalize()
      }
      static GetTopPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[1], KO.normal.y = pO[7] - pO[5], KO.normal.z = pO[11] - pO[9], KO.d = pO[15] - pO[13], KO.normalize()
      }
      static GetBottomPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[1], KO.normal.y = pO[7] + pO[5], KO.normal.z = pO[11] + pO[9], KO.d = pO[15] + pO[13], KO.normalize()
      }
      static GetPlanesToRef(OO, KO) {
        bK.GetNearPlaneToRef(OO, KO[0]), bK.GetFarPlaneToRef(OO, KO[1]), bK.GetLeftPlaneToRef(OO, KO[2]), bK.GetRightPlaneToRef(OO, KO[3]), bK.GetTopPlaneToRef(OO, KO[4]), bK.GetBottomPlaneToRef(OO, KO[5])
      }
      static IsPointInFrustum(OO, KO) {
        for (let pO = 0; pO < 6; pO++)
          if (KO[pO].dotCoordinate(OO) < 0) return !1;
        return !0
      }
    }
  },
  36146: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK
    });
    var XO = pO(35632);
    class bK {
      constructor(OO, KO, pO, bK) {
        this.normal = new XO.o(OO, KO, pO), this.d = bK
      }
      WhO() {
        return [this.normal.x, this.normal.y, this.normal.z, this.d]
      }
      clone() {
        return new bK(this.normal.x, this.normal.y, this.normal.z, this.d)
      }
      getClassName() {
        return "Plane"
      }
      getHashCode() {
        let OO = this.normal.getHashCode();
        return OO = 397 * OO ^ this.d, OO
      }
      normalize() {
        const OO = Math.sqrt(this.normal.x * this.normal.x + this.normal.y * this.normal.y + this.normal.z * this.normal.z);
        let KO = 0;
        return 0 !== OO && (KO = 1 / OO), this.normal.x *= KO, this.normal.y *= KO, this.normal.z *= KO, this.d *= KO, this
      }
      transform(OO) {
        const KO = bK._TmpMatrix;
        OO.invertToRef(KO);
        const pO = KO.m,
          XO = this.normal.x,
          eO = this.normal.y,
          lO = this.normal.z,
          vK = this.d,
          CO = XO * pO[0] + eO * pO[1] + lO * pO[2] + vK * pO[3],
          hO = XO * pO[4] + eO * pO[5] + lO * pO[6] + vK * pO[7],
          DO = XO * pO[8] + eO * pO[9] + lO * pO[10] + vK * pO[11],
          MO = XO * pO[12] + eO * pO[13] + lO * pO[14] + vK * pO[15];
        return new bK(CO, hO, DO, MO)
      }
      dotCoordinate(OO) {
        return this.normal.x * OO.x + this.normal.y * OO.y + this.normal.z * OO.z + this.d
      }
      copyFromPoints(OO, KO, pO) {
        const XO = KO.x - OO.x,
          bK = KO.y - OO.y,
          eO = KO.z - OO.z,
          lO = pO.x - OO.x,
          vK = pO.y - OO.y,
          CO = pO.z - OO.z,
          hO = bK * CO - eO * vK,
          DO = eO * lO - XO * CO,
          MO = XO * vK - bK * lO,
          aK = Math.sqrt(hO * hO + DO * DO + MO * MO);
        let oO;
        return oO = 0 !== aK ? 1 / aK : 0, this.normal.x = hO * oO, this.normal.y = DO * oO, this.normal.z = MO * oO, this.d = -(this.normal.x * OO.x + this.normal.y * OO.y + this.normal.z * OO.z), this
      }
      isFrontFacingTo(OO, KO) {
        return XO.o.Dot(this.normal, OO) <= KO
      }
      signedDistanceTo(OO) {
        return XO.o.Dot(OO, this.normal) + this.d
      }
      static FromArray(OO) {
        return new bK(OO[0], OO[1], OO[2], OO[3])
      }
      static FromPoints(OO, KO, pO) {
        const XO = new bK(0, 0, 0, 0);
        return XO.copyFromPoints(OO, KO, pO), XO
      }
      static FromPositionAndNormal(OO, KO) {
        const pO = new bK(0, 0, 0, 0);
        return this.FromPositionAndNormalToRef(OO, KO, pO)
      }
      static FromPositionAndNormalToRef(OO, KO, pO) {
        return pO.normal.NhO(KO), pO.normal.normalize(), pO.d = -OO.dot(pO.normal), pO
      }
      static SignedDistanceToPlaneFromPositionAndNormal(OO, KO, pO) {
        const bK = -(KO.x * OO.x + KO.y * OO.y + KO.z * OO.z);
        return XO.o.Dot(pO, KO) + bK
      }
    }
    bK._TmpMatrix = XO.c.Identity()
  },
  37055: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(37061);
    const bK = (OO, KO, pO) => OO ? OO.getClassName && "Mesh" === OO.getClassName() ? null : !OO.getClassName || "SubMesh" !== OO.getClassName() && "PhysicsBody" !== OO.getClassName() ? OO.clone ? OO.clone() : Array.isArray(OO) ? OO.slice() : pO && "object" === typeof OO ? {
      ...OO
    } : null : OO.clone(KO) : null;
    class eO {
      static DeepCopy(OO, KO, pO, eO) {
        let lO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        const vK = function(OO) {
          const KO = [];
          do {
            const pO = Object.getOwnPropertyNames(OO);
            for (const OO of pO) - 1 === KO.indexOf(OO) && KO.push(OO)
          } while (OO = Object.getPrototypeOf(OO));
          return KO
        }(OO);
        for (const hO of vK) {
          if ("_" === hO[0] && (!eO || -1 === eO.indexOf(hO))) continue;
          if (hO.endsWith("Observable")) continue;
          if (pO && -1 !== pO.indexOf(hO)) continue;
          const vK = OO[hO],
            DO = typeof vK;
          if ("function" !== DO) try {
            if ("object" === DO)
              if (vK instanceof Uint8Array) KO[hO] = Uint8Array.from(vK);
              else if (vK instanceof Array) {
              if (KO[hO] = [], vK.length > 0)
                if ("object" == typeof vK[0])
                  for (let OO = 0; OO < vK.length; OO++) {
                    const pO = bK(vK[OO], KO, lO); - 1 === KO[hO].indexOf(pO) && KO[hO].push(pO)
                  } else KO[hO] = vK.slice(0)
            } else KO[hO] = bK(vK, KO, lO);
            else KO[hO] = vK
          } catch (CO) {
            XO.b.Warn(CO.message)
          }
        }
      }
    }
  },
  36274: (OO, KO, pO) => {
    function XO() {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (OO => {
        const KO = 16 * Math.random() | 0;
        return ("x" === OO ? KO : 3 & KO | 8).toString(16)
      }))
    }
    pO.d(KO, {
      b: () => XO
    })
  },
  37061: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      static _CheckLimit(OO, KO) {
        let pO = XO._LogLimitOutputs[OO];
        return pO ? pO.current++ : (pO = {
          limit: KO,
          current: 1
        }, XO._LogLimitOutputs[OO] = pO), pO.current <= pO.limit
      }
      static _GenerateLimitMessage(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        const pO = XO._LogLimitOutputs[OO];
        if (!pO || !XO.MessageLimitReached) return;
        const bK = this._Levels[KO];
        pO.current === pO.limit && XO[bK.name](XO.MessageLimitReached.replace(/%LIMIT%/g, "" + pO.limit).replace(/%TYPE%/g, bK.name ?? ""))
      }
      static _AddLogEntry(OO) {
        XO._LogCache = OO + XO._LogCache, XO.OnNewCacheEntry && XO.OnNewCacheEntry(OO)
      }
      static _FormatMessage(OO) {
        const KO = OO => OO < 10 ? "0" + OO : "" + OO,
          pO = new Date;
        return "[" + KO(pO.getHours()) + ":" + KO(pO.getMinutes()) + ":" + KO(pO.getSeconds()) + "]: " + OO
      }
      static _LogDisabled(OO, KO) {}
      static _LogEnabled() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const bK = Array.isArray(KO) ? KO[0] : KO;
        if (void 0 !== pO && !XO._CheckLimit(bK, pO)) return;
        const eO = XO._FormatMessage(bK),
          lO = this._Levels[OO],
          vK = Array.isArray(KO) ? KO.slice(1) : [];
        lO.logFunc && lO.logFunc("BJS - " + eO, ...vK);
        const CO = `<div style='color:${lO.color}'>${eO}</div><br>`;
        XO._AddLogEntry(CO), XO._GenerateLimitMessage(bK, OO)
      }
      static get LogCache() {
        return XO._LogCache
      }
      static ClearLogCache() {
        XO._LogCache = "", XO._LogLimitOutputs = {}, XO.errorsCount = 0
      }
      static set LogLevels(OO) {
        XO.Log = XO._LogDisabled, XO.Warn = XO._LogDisabled, XO.Error = XO._LogDisabled;
        const KO = [XO.MessageLogLevel, XO.WarningLogLevel, XO.ErrorLogLevel];
        for (const pO of KO)
          if ((OO & pO) === pO) {
            const OO = this._Levels[pO];
            XO[OO.name] = XO._LogEnabled.bind(XO, pO)
          }
      }
    }
    XO.NoneLogLevel = 0, XO.MessageLogLevel = 1, XO.WarningLogLevel = 2, XO.ErrorLogLevel = 4, XO.AllLogLevel = 7, XO.MessageLimitReached = "Too many %TYPE%s (%LIMIT%), no more %TYPE%s will be reported for this message.", XO._LogCache = "", XO._LogLimitOutputs = {}, XO._Levels = [{}, {
      color: "white",
      logFunc: console.log,
      name: "Log"
    }, {
      color: "orange",
      logFunc: console.warn,
      name: "Warn"
    }, {}, {
      color: "red",
      logFunc: console.error,
      name: "Error"
    }], XO.errorsCount = 0, XO.Log = XO._LogEnabled.bind(XO, XO.MessageLogLevel), XO.Warn = XO._LogEnabled.bind(XO, XO.WarningLogLevel), XO.Error = XO._LogEnabled.bind(XO, XO.ErrorLogLevel)
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);