export const id = 53;
export const ids = [53];
export const modules = {
  40666: (OO, KO, pO) => {
    var XO = {
      "./Air Walk.png": 40671,
      "./Antlers Bonus.png": 40673,
      "./Arrow Damage Enchantment.png": 40675,
      "./Arrow Speed Enchantment.png": 40680,
      "./Attack Speed Enchantment.png": 40686,
      "./Blindness.png": 40694,
      "./Boating.png": 40696,
      "./Bounciness.png": 40705,
      "./Brain Rot.png": 40708,
      "./Break Speed Enchantment.png": 40713,
      "./Bunny Hop.png": 40721,
      "./Critical Damage Enchantment.png": 40727,
      "./Cross.png": 40730,
      "./Damage Enchantment.png": 40734,
      "./Damage Reduction.png": 40743,
      "./Damage.png": 40750,
      "./Digging Aura Enchantment.png": 40755,
      "./Dotted Friendship.png": 40758,
      "./Double Jump.png": 40761,
      "./Double Poop.png": 40770,
      "./Draugr Knight Head.png": 40775,
      "./Draugr Warper Head.png": 40784,
      "./Empty Hunger.png": 40787,
      "./FallDamage.png": 40791,
      "./Farming Aura Enchantment.png": 40794,
      "./Farming Yield Enchantment.png": 40797,
      "./Feather Falling.png": 40800,
      "./Feed Aura.png": 40802,
      "./Firecracker Boost Enchantment.png": 40811,
      "./Firecracker Cooldown Enchantment.png": 40813,
      "./Fist.png": 40817,
      "./Friends.png": 40822,
      "./Friendship.png": 40826,
      "./Frozen.png": 40830,
      "./Gliding Speed Enchantment.png": 40837,
      "./Gliding.png": 40840,
      "./Glowing.png": 40848,
      "./Haste.png": 40857,
      "./Healing Pulse.png": 40865,
      "./Health Enchantment.png": 40874,
      "./Health Regen Enchantment.png": 40878,
      "./Health Regen.png": 40887,
      "./Health.png": 40889,
      "./HealthShield.png": 40891,
      "./Heat Resistance.png": 40898,
      "./Horizontal Knockback Enchantment.png": 40903,
      "./Hunger.png": 40910,
      "./Hydrated.png": 40912,
      "./Invisible.png": 40919,
      "./Irradiated.png": 40926,
      "./Jump Boost.png": 40935,
      "./Knockback Resist Enchantment.png": 40944,
      "./Lifesteal.png": 40948,
      "./Lumber Aura Enchantment.png": 40950,
      "./Magma Golem Head.png": 40959,
      "./Max Health.png": 40961,
      "./Mining Aura Enchantment.png": 40966,
      "./Mining Yield Enchantment.png": 40970,
      "./Mining Yield.png": 40974,
      "./Mob Slayer.png": 40983,
      "./Mob Yield.png": 40986,
      "./Momentum Enchantment.png": 40989,
      "./Mystery Fish.png": 40994,
      "./Night Vision.png": 40996,
      "./Obsidian Boating.png": 41e3,
      "./Pack Leader.png": 41007,
      "./Pickpocketer.png": 41014,
      "./Pixelated Heart.png": 41017,
      "./Poison Claws.png": 41023,
      "./Poisoned.png": 41029,
      "./Poopy.png": 41033,
      "./Protection Enchantment.png": 41038,
      "./Question Mark.png": 41040,
      "./Quick Charge Enchantment.png": 41049,
      "./Rainbow Wool.png": 41052,
      "./Rested Aura.png": 41056,
      "./Rested Damage.png": 41062,
      "./Rested Farming Yield.png": 41070,
      "./Rested Haste.png": 41075,
      "./Rested Speed.png": 41084,
      "./Riding Speed.png": 41091,
      "./Riding.png": 41096,
      "./Self Yield.png": 41100,
      "./Slowness.png": 41107,
      "./Speed.png": 41113,
      "./Stomp Damage Enchantment.png": 41118,
      "./Thief.png": 41125,
      "./Thorns.png": 41134,
      "./Trader Black.png": 41137,
      "./Trader Blue.png": 41139,
      "./Trader Piggy.png": 41143,
      "./Vertical Knockback Enchantment.png": 41148,
      "./VoidJump.png": 41154,
      "./Wall Climbing.png": 41158,
      "./Weakness.png": 41160,
      "./X-Ray Vision.png": 41165
    };

    function bK(OO) {
      var KO = eO(OO);
      return pO(KO)
    }

    function eO(OO) {
      if (!pO.o(XO, OO)) {
        var KO = new Error("Cannot find module '" + OO + "'");
        throw KO.code = "MODULE_NOT_FOUND", KO
      }
      return XO[OO]
    }
    bK.keys = function() {
      return Object.keys(XO)
    }, bK.resolve = eO, OO.exports = bK, bK.id = 40666
  },
  41177: (OO, KO, pO) => {
    var XO = {
      "./arrow.png": 41183,
      "./bubble.png": 41189,
      "./critical_hit.png": 41195,
      "./drift.png": 41203,
      "./effect_5.png": 41206,
      "./fishingFishSilhouette.png": 41213,
      "./generic_2.png": 41222,
      "./glint.png": 41231,
      "./heart.png": 41235,
      "./scary_face.png": 41243,
      "./soul_0.png": 41250,
      "./square_particle.png": 41257,
      "./z-particle.png": 41266
    };

    function bK(OO) {
      var KO = eO(OO);
      return pO(KO)
    }

    function eO(OO) {
      if (!pO.o(XO, OO)) {
        var KO = new Error("Cannot find module '" + OO + "'");
        throw KO.code = "MODULE_NOT_FOUND", KO
      }
      return XO[OO]
    }
    bK.keys = function() {
      return Object.keys(XO)
    }, bK.resolve = eO, OO.exports = bK, bK.id = 41177
  },
  40661: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      blockTextureUrl: () => FO,
      ingameIconUrl: () => aK,
      itemSpriteUrl: () => MO,
      loadBundledTextures: () => CO,
      notFoundUrl: () => oO,
      particleUrl: () => VO
    });
    var XO = pO(38831),
      bK = pO(1561),
      eO = pO(2463);
    let lO = null,
      vK = null;

    function CO() {
      vK ??= Promise.all([pO.e(62), pO.e(183), pO.e(85)]).then((() => pO(8362))).then((OO => {
        lO = OO, (0, bK.d)()
      }), (OO => {
        console.warn("[bloxd-wasm-client] the default texture pack did not load, so item icons load file by file", OO)
      }))
    }

    function hO(OO, KO) {
      if (null === lO) return null;
      try {
        return lO.getDefaultTexture(OO, KO).url
      } catch {
        return null
      }
    }

    function DO(OO, KO) {
      return `${pO.p}${OO}${encodeURIComponent(KO)}.png`
    }

    function MO(OO) {
      var KO;
      const pO = "static/items/f8c148434246a2c1/";
      return (0, XO.e)(OO) ? null !== (KO = function(OO) {
        return hO(OO, eO.g.ITEM)
      }(OO)) && void 0 !== KO ? KO : DO(pO, OO) : null
    }

    function aK(OO) {
      try {
        return pO(40666)(`./${OO}.png`)
      } catch {
        return null
      }
    }

    function oO() {
      return pO(41171)
    }

    function FO(OO) {
      var KO;
      const pO = "static/blocks/7a8698da99f6d2c7/";
      return OO.includes("[") ? null : null !== (KO = function(OO) {
        return hO(OO, eO.g.BLOCK)
      }(OO)) && void 0 !== KO ? KO : DO(pO, OO)
    }

    function VO(OO) {
      try {
        return pO(41177)(`./${OO}.png`)
      } catch {
        return null
      }
    }
  },
  40671: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Air Walk.550feb574b0c57b1066d.png"
  },
  40673: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Antlers Bonus.d20354fe227ace54a650.png"
  },
  40675: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Arrow Damage Enchantment.60d80fa6d2105c83ecf9.png"
  },
  40680: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Arrow Speed Enchantment.92f45068bd17d5c115fa.png"
  },
  40686: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Attack Speed Enchantment.4516cbbd641b12538dd6.png"
  },
  40694: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Blindness.edd267f2a314651c7a3a.png"
  },
  40696: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Boating.239280fa7d4f9d416cc1.png"
  },
  40705: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Bounciness.5ed861e592682c9790c3.png"
  },
  40708: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Brain Rot.e808bf985c93f347827b.png"
  },
  40713: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Break Speed Enchantment.0be5f4506d0e55985ff7.png"
  },
  40721: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Bunny Hop.53fd14a37006962c7a02.png"
  },
  40727: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Critical Damage Enchantment.f4959f22b41d48786b52.png"
  },
  40730: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Cross.895f1f5171aa98ed7656.png"
  },
  40734: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Damage Enchantment.a997683423a180ae8dc5.png"
  },
  40743: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Damage Reduction.fdbbf84ca4b04f307011.png"
  },
  40750: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Damage.5edf768f57c9823c01b7.png"
  },
  40755: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Digging Aura Enchantment.f2c32b1eea67ca29484a.png"
  },
  40758: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Dotted Friendship.70a85d66cd72a860aa11.png"
  },
  40761: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Double Jump.76e9fdd557728ed63fd9.png"
  },
  40770: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Double Poop.258b70e2a2b25de790aa.png"
  },
  40775: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Draugr Knight Head.2641191943e1366ee4e5.png"
  },
  40784: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Draugr Warper Head.1752981f98e52c3d6575.png"
  },
  40787: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Empty Hunger.6214e340b2dcc2477290.png"
  },
  40791: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/FallDamage.955f91b22d5d0bb98f74.png"
  },
  40794: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Farming Aura Enchantment.ff9393e619e7aff7be5d.png"
  },
  40797: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Farming Yield Enchantment.6e5498b2f625c337751a.png"
  },
  40800: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Feather Falling.f111d0dd95648157d19c.png"
  },
  40802: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Feed Aura.b1729965a912206f1c9c.png"
  },
  40811: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Firecracker Boost Enchantment.1b191a71953b48f5278c.png"
  },
  40813: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Firecracker Cooldown Enchantment.d6783c7e4b6d6e854ae9.png"
  },
  40817: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Fist.3f0a4cf0dd50a037aa44.png"
  },
  40822: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Friends.200ac187e210aa5b0bd1.png"
  },
  40826: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Friendship.52c43bf51d729a07c65a.png"
  },
  40830: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Frozen.83e94281a770969902d6.png"
  },
  40837: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Gliding Speed Enchantment.1e0eb8fe31980d26b33a.png"
  },
  40840: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Gliding.4fd01858ea61b5229451.png"
  },
  40848: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Glowing.b7249a4b1bbc31a99a8c.png"
  },
  40857: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Haste.205c848b0798acf1b67b.png"
  },
  40865: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Healing Pulse.04c584a6ec7fd91c9bb1.png"
  },
  40874: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Health Enchantment.ae4eebca87d7ad0d6dfa.png"
  },
  40878: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Health Regen Enchantment.74f637edccd03a30df6a.png"
  },
  40887: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Health Regen.04c584a6ec7fd91c9bb1.png"
  },
  40889: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Health.cfa3a685af898f2c717f.png"
  },
  40891: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/HealthShield.c30608f8335b027ed219.png"
  },
  40898: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Heat Resistance.cb2e5a2b1509726c6a39.png"
  },
  40903: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Horizontal Knockback Enchantment.cc7b6bf291e3785cd1ed.png"
  },
  40910: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Hunger.4cafabb66831618423a1.png"
  },
  40912: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Hydrated.3d7c4351a4ce829a6a4f.png"
  },
  40919: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Invisible.5ac436c34320f5cdf3c9.png"
  },
  40926: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Irradiated.730dcc3697877f63d0a3.png"
  },
  40935: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Jump Boost.cf4fa5b773fadddbd26f.png"
  },
  40944: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Knockback Resist Enchantment.ccb0ea3ed38c02c191f3.png"
  },
  40948: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Lifesteal.f4fd17f147ddc53867c1.png"
  },
  40950: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Lumber Aura Enchantment.6f7a9a2c2777625f6928.png"
  },
  40959: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Magma Golem Head.1734c2842e8cd4c6ee67.png"
  },
  40961: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Max Health.ea03a9596b884a00e4bd.png"
  },
  40966: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Mining Aura Enchantment.bedc28cf636e6a310953.png"
  },
  40970: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Mining Yield Enchantment.bb1a5afdce1ff7e6651a.png"
  },
  40974: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Mining Yield.bb1a5afdce1ff7e6651a.png"
  },
  40983: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Mob Slayer.18771a2f81150e240788.png"
  },
  40986: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Mob Yield.09a9dd5f676e7da4dc89.png"
  },
  40989: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Momentum Enchantment.31e6209b4886925f5037.png"
  },
  40994: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Mystery Fish.94e499ddfeed1d82b470.png"
  },
  40996: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Night Vision.87d04612426328963c01.png"
  },
  41e3: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Obsidian Boating.1eaf502e4a8bd95edb7c.png"
  },
  41007: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Pack Leader.cf0973d1d9a032cafca3.png"
  },
  41014: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Pickpocketer.33ad49b78ba0f52e6863.png"
  },
  41017: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Pixelated Heart.f8050bc55b1a60ff519e.png"
  },
  41023: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Poison Claws.5bcab630c82c57276c74.png"
  },
  41029: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Poisoned.99dd6b76273278f4f61e.png"
  },
  41033: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Poopy.4110620c7b5fcbeb321c.png"
  },
  41038: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Protection Enchantment.8fe12f5d7c6926a6a2df.png"
  },
  41040: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Question Mark.029fa6a29c3200287f61.png"
  },
  41049: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Quick Charge Enchantment.95a9a0260b2c8e5817df.png"
  },
  41052: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Rainbow Wool.d428fbfaaa4e4bc5270a.png"
  },
  41056: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Rested Aura.be920aee50ba66b6f61b.png"
  },
  41062: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Rested Damage.44a0d79b8f277cd5be20.png"
  },
  41070: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Rested Farming Yield.2d375b3c962829564e88.png"
  },
  41075: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Rested Haste.3e768908f57bbf567993.png"
  },
  41084: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Rested Speed.98ae08f7e365812506b0.png"
  },
  41091: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Riding Speed.00fca2421d140ff4146e.png"
  },
  41096: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Riding.4e1c3c296ffec6cda94f.png"
  },
  41100: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Self Yield.edb63094d10ccfd450a2.png"
  },
  41107: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Slowness.0d456812d4290180d6d3.png"
  },
  41113: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Speed.a6a755966a05dfbdd49b.png"
  },
  41118: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Stomp Damage Enchantment.a902b51f29b3383b6a3b.png"
  },
  41125: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Thief.c608f1b1a94e2bfe6026.png"
  },
  41134: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Thorns.95905a8c472f77dad6c9.png"
  },
  41137: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Trader Black.05eae9921339e319fe8c.png"
  },
  41139: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Trader Blue.fad0d45789e0f36926af.png"
  },
  41143: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Trader Piggy.d2b90ae063e91d2f7649.png"
  },
  41148: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Vertical Knockback Enchantment.a2c31475d0871a616460.png"
  },
  41154: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/VoidJump.f8c253294acf34dd1a82.png"
  },
  41158: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Wall Climbing.6729badd0cee7f131293.png"
  },
  41160: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Weakness.234bdb740d34da3f932f.png"
  },
  41165: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/X-Ray Vision.4b90a144f53e8d21c74a.png"
  },
  41183: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/arrow.ffce0168131507e37783.png"
  },
  41189: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bubble.a0edea14e8be26e3947a.png"
  },
  41195: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/critical_hit.f394a2f1eaca8443c07b.png"
  },
  41203: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/drift.400e35d1039dd77946d5.png"
  },
  41206: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/effect_5.6b1b1cd3befeee44b56b.png"
  },
  41213: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/fishingFishSilhouette.3664653c612c6ec59331.png"
  },
  41222: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/generic_2.af3899f6d4599c1123b1.png"
  },
  41231: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/glint.2bf5fd952ada4f09d258.png"
  },
  41235: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/heart.8bcd1acb52c8b040b6d7.png"
  },
  41243: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/scary_face.da8edc3f0050e2ac9f24.png"
  },
  41250: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/soul_0.e9e43a364bd6cafde7a8.png"
  },
  41257: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/square_particle.a87e53ddb61836a91c95.png"
  },
  41266: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/z-particle.97556df0d813e0f3b5de.png"
  },
  41171: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/textureNotFound.029fa6a29c3200287f61.png"
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);