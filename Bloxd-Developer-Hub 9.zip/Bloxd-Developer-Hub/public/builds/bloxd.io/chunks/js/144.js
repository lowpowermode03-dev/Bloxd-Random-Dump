export const id = 144;
export const ids = [144];
export const modules = {
  35139: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => zK,
      c: () => eO,
      f: () => VO,
      i: () => LO,
      m: () => vK,
      n: () => aK,
      q: () => QO,
      s: () => MO,
      u: () => AO,
      y: () => FO
    });
    var XO = pO(22),
      bK = pO(26);
    const eO = "clientGameInventoryButtonsChanged",
      lO = new Map;

    function vK() {
      return [...lO.values()].sort(((OO, KO) => {
        var pO, XO;
        return (null !== (pO = OO.order) && void 0 !== pO ? pO : 0) - (null !== (XO = KO.order) && void 0 !== XO ? XO : 0)
      }))
    }
    let CO = null;

    function hO(OO) {
      CO = OO
    }
    let DO = !1;

    function MO(OO) {
      DO = !0;
      try {
        OO.onClick()
      } finally {
        DO = !1
      }
      OO.panel && "clientGame" === XO.d.get("openInGameMenuName") && hO(OO.id)
    }

    function aK() {
      return DO
    }

    function oO() {
      return vK().filter((OO => OO.panel && !OO.disabled))
    }

    function FO(OO) {
      const KO = oO(),
        pO = KO.findIndex((OO => OO.id === CO));
      return !(pO < 0 || KO.length < 2) && (MO(KO[(pO + OO + KO.length) % KO.length]), !0)
    }

    function VO() {
      return null !== CO && oO().length > 1
    }

    function LO() {
      hO(null)
    }

    function QO() {
      "inventory" !== XO.d.get("openInGameMenuName") && hO(null)
    }

    function zK() {
      const OO = CO;
      return hO(null), OO
    }

    function AO(OO) {
      return lO.set(OO.id, OO), bK.i.pl(eO, vK(), !0), () => {
        lO.get(OO.id) === OO && (lO.delete(OO.id), bK.i.pl(eO, vK()))
      }
    }
  },
  35137: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      g: () => LO,
      j: () => QO,
      k: () => aK,
      l: () => hO,
      o: () => VO,
      p: () => oO,
      q: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(1136),
      lO = pO(35139);
    const vK = "clientGameUiChanged";
    let CO = null;

    function hO() {
      return CO
    }

    function DO(OO, KO) {
      const pO = {
        content: OO,
        menu: KO
      };
      return CO = pO, bK.i.pl(vK, CO, !0), () => {
        CO === pO && (CO = null, FO = !1, LO(), bK.i.pl(vK, null))
      }
    }
    let MO = null;

    function aK() {
      return MO
    }

    function oO(OO) {
      return MO = OO, () => {
        MO === OO && (MO = null)
      }
    }
    let FO = !1;

    function VO() {
      const OO = XO.d.get("openInGameMenuName");
      "clientGame" !== OO && (FO = "inventory" === OO), (0, lO.n)() || (0, lO.i)(), (0, eO.k)("InGameMenu"), XO.d.set({
        openInGameMenuName: "clientGame",
        openEverythingMenuName: null
      })
    }

    function LO() {
      zK(!1)
    }

    function QO() {
      zK(FO)
    }

    function zK(OO) {
      "clientGame" === XO.d.get("openInGameMenuName") && XO.d.set({
        openInGameMenuName: OO ? "inventory" : null
      }), OO || (0, lO.i)(), FO = !1
    }
  },
  7824: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(7833),
      bK = pO(533),
      eO = pO(142);

    function lO(OO) {
      var KO, pO;
      if ((0, bK.I)(OO)) return !0;
      const lO = null !== (KO = null === (pO = eO.p[eO.t]) || void 0 === pO ? void 0 : pO.adConfig.showRewardedAds) && void 0 !== KO && KO;
      for (const bK in OO) {
        const KO = OO[bK];
        if (null !== KO && void 0 !== KO && KO.items)
          for (const OO in KO.items)
            if ((0, XO.i)(KO.items[OO], lO)) return !1
      }
      return !0
    }
  },
  40640: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      getClientGameMapKey: () => XO.k,
      shopIsEmpty: () => bK.e
    });
    var XO = pO(35137),
      bK = pO(7824)
  },
  7833: (OO, KO, pO) => {
    function XO(OO, KO) {
      return !OO.hidden && (KO || !OO.isRewardedAd)
    }

    function bK(OO) {
      return "object" === typeof OO ? OO.option : OO
    }

    function eO(OO, KO) {
      var pO;
      if ("dropdown" === (null === (pO = OO.userInput) || void 0 === pO ? void 0 : pO.type) && "object" === typeof OO.userInput.dropdownOptions[0]) {
        for (const pO of OO.userInput.dropdownOptions)
          if (bK(pO) === KO) return "object" === typeof pO ? pO.cost : OO.cost;
        console.error("Didn't find matching option for dropdown item. Item:", OO, "input:", KO)
      }
      return OO.cost
    }

    function lO(OO, KO, pO) {
      var XO;
      const bK = null !== (XO = pO.excludedPlayers) && void 0 !== XO ? XO : [KO];
      return OO.filter((OO => !bK.includes(OO)))
    }
    pO.d(KO, {
      e: () => eO,
      f: () => bK,
      g: () => lO,
      i: () => XO
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);