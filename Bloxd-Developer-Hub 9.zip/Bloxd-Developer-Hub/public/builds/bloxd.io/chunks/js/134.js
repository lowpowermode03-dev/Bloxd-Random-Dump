export const id = 134;
export const ids = [134];
export const modules = {
  7179: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      BloxdDiscordActivitySdk: () => zK
    });
    var XO = pO(7186),
      bK = pO(1086),
      eO = pO(1051),
      lO = pO(533),
      vK = pO(1109),
      CO = pO(1481),
      hO = pO(1163),
      DO = pO(638),
      MO = pO(22),
      aK = pO(1063),
      oO = function(OO) {
        return OO.APPLICATION_COMMANDS = "applications.commands", OO.IDENTIFY = "identify", OO.EMAIL = "email", OO.GUILDS = "guilds", OO.READ_DM_CHANNELS = "dm_channels.read", OO.WRITE_ACTIVITIES = "rpc.activities.write", OO
      }(oO || {}),
      FO = function(OO) {
        return OO[OO.CLOSE_NORMAL = 1e3] = "CLOSE_NORMAL", OO[OO.CLOSE_UNSUPPORTED = 1003] = "CLOSE_UNSUPPORTED", OO[OO.CLOSE_ABNORMAL = 1006] = "CLOSE_ABNORMAL", OO[OO.INVALID_CLIENTID = 4e3] = "INVALID_CLIENTID", OO[OO.INVALID_ORIGIN = 4001] = "INVALID_ORIGIN", OO[OO.RATELIMITED = 4002] = "RATELIMITED", OO[OO.TOKEN_REVOKED = 4003] = "TOKEN_REVOKED", OO[OO.INVALID_VERSION = 4004] = "INVALID_VERSION", OO[OO.INVALID_ENCODING = 4005] = "INVALID_ENCODING", OO
      }(FO || {}),
      VO = function(OO) {
        return OO[OO.PLAYING = 0] = "PLAYING", OO[OO.STREAMING = 1] = "STREAMING", OO[OO.LISTENING = 2] = "LISTENING", OO[OO.WATCHING = 3] = "WATCHING", OO[OO.CUSTOM = 4] = "CUSTOM", OO[OO.COMPETING = 5] = "COMPETING", OO
      }(VO || {});
    const LO = {
        Minigames: "Playing",
        Puzzle: "Solving",
        Escape: "Escaping",
        Parkour: "Parkouring",
        "Cool Parkour": "Parkouring",
        "Two Player Parkour": "Parkouring",
        "Clutch Parkour": "Parkouring",
        "Challenging Parkour": "Parkouring",
        "Progressive Parkour": "Parkouring",
        "Themed Parkour": "Parkouring",
        Obby: "Parkouring",
        Tower: "Climbing",
        Roleplay: "Roleplaying",
        Arena: "Battling",
        Duels: "Duelling",
        Shooting: "Shooting",
        Survival: "Surviving",
        Simulator: "Grinding",
        Tycoon: "Building",
        Clicker: "Clicking",
        PvE: "Battling",
        Building: "Building",
        Horror: "Surviving",
        "Lucky Block": "Battling",
        Racing: "Racing",
        Driving: "Driving",
        "Cool Build": "Building",
        Adventure: "Adventuring",
        Other: "Being mischievous"
      },
      QO = {
        goalRush: "Playing",
        heroesvbrainrots: "Battling",
        hideseek: "Playing",
        bingo: "Playing"
      };
    class zK {
      constructor(OO) {
        this.discordSdk = OO, this.guildNameCache = {}, this.startTime = Date.now(), this.cachedAccessToken = null
      }
      static async setup() {
        console.log("Setting up Discord SDK with client id", aK.e.discordClientID);
        const OO = new XO.b(aK.e.discordClientID);
        let KO = !1;
        setTimeout((() => {
          KO || (console.warn("Discord SDK took too long to initialize"), (0, CO.reloadBloxd)())
        }), 15e3), await OO.ready(), KO = !0;
        try {
          const {
            enabled: KO
          } = await OO.commands.encourageHardwareAcceleration();
          KO || console.warn("Hardware acceleration not enabled in the Discord client")
        } catch (bK) {
          console.error("Failed to encourage hardware acceleration in the Discord client", bK)
        }
        const pO = new zK(OO);
        return pO.isMobilePlatform() && (pO.applyDiscordSafeAreaNotch(), window.addEventListener("resize", (() => {
          pO.applyDiscordSafeAreaNotch()
        }))), pO
      }
      async updateActivityDescription(OO) {
        let KO, pO;
        switch (OO) {
          case "homePage":
            KO = "Chilling in the Main Menu";
            break;
          case "inGame": {
            const OO = await this.getInGameDescriptions();
            KO = OO.primary, pO = OO.secondary;
            break
          }
        }
        await this.discordSdk.commands.setActivity({
          activity: {
            type: VO.PLAYING,
            details: KO,
            state: pO,
            assets: {
              large_image: "icon",
              large_text: KO
            },
            timestamps: {
              start: this.startTime
            }
          }
        }).catch((OO => {
          console.error(`Failed to update Discord activity rich presence with description="${KO}":`, OO)
        }))
      }
      async getInGameDescriptions() {
        var OO;
        const {
          requestedGameNameWithVariation: KO
        } = (0, hO.b)(), pO = (0, DO.p)(KO), XO = null !== (OO = QO[KO]) && void 0 !== OO ? OO : LO[pO.type], bK = await (0, eO.C)(vK.c.ENGLISH, pO.title), CO = (0, hO.b)();
        if ((0, hO.j)(CO)) return {
          primary: `${XO} in a Discord World`
        };
        const MO = `${XO} in ${bK}`;
        return (0, lO.I)(CO.lobbyName) ? {
          primary: MO
        } : {
          primary: MO,
          secondary: `Lobby ${CO.lobbyName}`
        }
      }
      getCurrentChannelType() {
        const {
          channelId: OO,
          guildId: KO
        } = this.getCurrentChannelAndGuild();
        return null !== KO ? bK.b.GUILD : null !== OO ? bK.b.DM : null
      }
      getRequiredScopeForCurrentChannel() {
        const OO = this.getCurrentChannelType(),
          KO = [oO.APPLICATION_COMMANDS, oO.IDENTIFY, oO.EMAIL, oO.GUILDS, oO.WRITE_ACTIVITIES];
        switch (OO) {
          case bK.b.DM:
          case bK.b.GUILD:
            return [...KO];
          default:
            throw new Error(`Unknown Discord channel type: ${OO}`)
        }
      }
      getCurrentChannelAndGuild() {
        const {
          channelId: OO,
          guildId: KO
        } = this.discordSdk;
        return {
          channelId: null !== OO && void 0 !== OO ? OO : null,
          guildId: null !== KO && void 0 !== KO ? KO : null
        }
      }
      getInstanceId() {
        return this.discordSdk.instanceId
      }
      async askDiscordUserForAuthorization() {
        const OO = this.getRequiredScopeForCurrentChannel(),
          {
            code: KO
          } = await this.discordSdk.commands.authorize({
            client_id: aK.e.discordClientID,
            response_type: "code",
            state: "",
            prompt: "none",
            scope: OO
          });
        return KO
      }
      getCachedAccessToken() {
        return this.cachedAccessToken
      }
      setCachedAccessToken(OO) {
        this.cachedAccessToken = OO
      }
      registerGuild(OO, KO) {
        this.guildNameCache[OO] = KO
      }
      async authenticate(OO) {
        return this.discordSdk.commands.authenticate({
          access_token: OO
        }).then((OO => null !== OO))
      }
      async getUserLocale() {
        try {
          const {
            locale: OO
          } = await this.discordSdk.commands.userSettingsGetLocale();
          return OO
        } catch (OO) {
          return console.error("Failed to get user locale from Discord:", OO.stack), null
        }
      }
      async getChannelName(OO) {
        return this.discordSdk.commands.getChannel({
          channel_id: OO
        }).then((OO => OO.name)).catch((OO => "Your Current Discord Chat"))
      }
      async getDiscordContextFromChannelId(OO) {
        const KO = await this.getChannelName(OO);
        return bK.e.from({
          type: bK.b.DM,
          channelId: OO,
          channelName: KO
        })
      }
      getDiscordContextFromGuildId(OO) {
        const KO = this.guildNameCache[OO];
        return (0, lO.I)(KO) ? null : bK.d.from({
          type: bK.b.GUILD,
          guildId: OO,
          guildName: KO
        })
      }
      async getCurrentDiscordContext() {
        const {
          channelId: OO,
          guildId: KO
        } = this.getCurrentChannelAndGuild();
        return null !== KO ? this.getDiscordContextFromGuildId(KO) : null !== OO ? this.getDiscordContextFromChannelId(OO) : null
      }
      exit(OO) {
        console.log("Exiting Discord Activity:", OO), this.discordSdk.close(FO.CLOSE_NORMAL, OO)
      }
      isMobilePlatform() {
        return this.discordSdk.platform === XO.d.MOBILE
      }
      applyDiscordSafeAreaNotch() {
        const OO = getComputedStyle(document.documentElement),
          KO = (KO, pO) => {
            const XO = parseFloat(OO.getPropertyValue(`--discord-safe-area-inset-${KO}`));
            return isNaN(XO) || 0 === pO ? 0 : XO / pO * 100
          };
        MO.d.set({
          notchSize: {
            top: KO("top", window.innerHeight),
            right: Math.max(KO("right", window.innerWidth), 7),
            bottom: 0,
            left: KO("left", window.innerWidth)
          }
        })
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);