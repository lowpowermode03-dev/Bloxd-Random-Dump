export const id = 285;
export const ids = [285];
export const modules = {
  39724: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => aK,
      d: () => QO,
      h: () => oO,
      k: () => FO,
      l: () => AO,
      m: () => zK
    });
    var XO = pO(39684);
    var bK = "Babylon Lite v1.32.0",
      eO = pO(39728);

    function lO(OO) {
      return "clientWidth" in OO
    }
    var vK = 1;

    function CO(OO, KO, pO) {
      const CO = KO.getContext("webgpu");
      CO || (0, XO.d)(54), lO(KO) && KO.setAttribute("data-engine", bK);
      const hO = pO?.format ?? navigator.gpu.getPreferredCanvasFormat(),
        DO = pO?.srgb ? (MO = hO).endsWith("-srgb") ? MO : `${MO}-srgb` : hO;
      var MO;
      const aK = pO?.alphaMode ?? "opaque";
      CO.configure({
        device: OO._device,
        format: hO,
        alphaMode: aK,
        viewFormats: [DO]
      });
      const oO = 1 === pO?.msaaSamples ? 1 : 4,
        FO = (0, eO.d)({
          lbl: "swapchain",
          format: DO,
          samples: 1,
          size: {
            width: 0,
            height: 0
          }
        });
      return FO._eager = !0, {
        engine: OO,
        canvas: KO,
        format: DO,
        msaaSamples: oO,
        scRT: FO,
        maxDevicePixelRatio: pO?.maxDevicePixelRatio ?? 1 / 0,
        _uniqueId: vK++,
        _context: CO,
        _configureFormat: hO,
        _alphaMode: aK,
        _renderingContexts: []
      }
    }

    function hO(OO) {
      const KO = OO._context.getCurrentTexture(),
        pO = OO.scRT;
      pO._colorTexture = KO, pO._colorView = KO.createView({
        format: OO.format
      }), pO._width = KO.width, pO._height = KO.height
    }

    function DO(OO) {
      const KO = OO.canvas;
      if (!lO(KO)) return;
      const pO = OO._w ?? KO.clientWidth,
        XO = OO._h ?? KO.clientHeight;
      if (!(pO > 0 && XO > 0)) return;
      const bK = Math.min(globalThis.devicePixelRatio || 1, OO.maxDevicePixelRatio);
      MO(OO, pO * bK | 0, XO * bK | 0)
    }

    function MO(OO, KO, pO) {
      const XO = OO.canvas,
        bK = 0 | KO,
        eO = 0 | pO;
      if (bK > 0 && eO > 0 && (bK !== XO.width || eO !== XO.height)) {
        XO.width = bK, XO.height = eO, OO.scRT._width = bK, OO.scRT._height = eO;
        for (const KO of OO._renderingContexts) KO._resize?.()
      }
    }
    var aK = 0;

    function oO(OO, KO) {
      return -1 !== OO._renderingContexts.indexOf(KO)
    }

    function FO(OO, KO) {
      return -1 === OO._renderingContexts.indexOf(KO) && (OO._renderingContexts.push(KO), !0)
    }
    var VO = null;
    var LO = ["float32-filterable", "texture-compression-astc", "texture-compression-bc", "texture-compression-etc2", "texture-compression-unaligned", "timestamp-query", "primitive-index"];
    async function QO(OO, KO) {
      const eO = await navigator.gpu.requestAdapter({
        powerPreference: "high-performance",
        ...VO ? VO() : {}
      });
      eO || (0, XO.d)(47);
      const lO = VO?.deviceFeatures?.(eO, KO) ?? function(OO) {
          return LO.filter((KO => OO.features.has(KO)))
        }(eO),
        vK = await eO.requestDevice({
          requiredFeatures: lO,
          requiredLimits: KO?.requiredLimits
        });
      console.log(`${bK} - WebGPU engine`);
      const MO = !!KO?.useHighPrecisionMatrix,
        aK = !!KO?.useFloatingOrigin;
      if (aK && !MO && (0, XO.d)(48), MO) {
        const {
          allocateF64Mat4: OO
        } = await pO.e(337).then((() => pO(59139)));
        0
      }
      let oO, FO, QO, zK;
      if (aK) {
        const [{
          wrapRenderableForFO: OO,
          lightFoVersion: KO,
          applyLightFoOffset: XO
        }, {
          makePackMeshWorld: bK
        }] = await Promise.all([pO.e(338).then((() => pO(59146))), pO.e(339).then((() => pO(59150)))]);
        oO = OO, FO = bK, QO = KO, zK = XO
      }
      const AO = {
          _device: vK
        },
        fO = [AO];
      return Object.assign(AO, {
        engine: AO,
        surfaces: fO,
        _surfaces: fO,
        _device: vK,
        _options: KO,
        drawCallCount: 0,
        gpuFrameTimeMs: 0,
        useHighPrecisionMatrix: MO,
        useFloatingOrigin: aK,
        _animFrameId: 0,
        _renderFn: null,
        _currentEncoder: void 0,
        _currentDelta: 0,
        _cbs: [],
        _wrapRenderableForFO: oO,
        _makePackMeshWorld: FO,
        _lightFoVersion: QO,
        _applyLightFoOffset: zK
      }, CO(AO, OO, KO)), DO(AO), hO(AO), AO
    }

    function zK(OO, KO, pO) {
      MO(OO, KO, pO)
    }

    function AO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : OO.surfaces;
      if (pO !== OO.surfaces)
        for (let bK = pO.length; bK--;) pO[bK].engine !== OO && (0, XO.d)(49);
      fO(OO, KO, pO)
    }

    function fO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : OO._surfaces,
        XO = 0;
      for (let eO = pO.length; eO--;) XO += pO[eO]._renderingContexts.length;
      if (!XO) return OO.drawCallCount = 0, OO._flushGpuRetirements?.(OO);
      const bK = OO._device.createCommandEncoder({
        label: "frame"
      });
      OO._currentEncoder = bK, OO._currentDelta = KO;
      try {
        OO._gpuTimerBegin?.(bK), XO = 0;
        for (let OO = 0; OO < pO.length; OO++) {
          const KO = pO[OO];
          KO._capturePreFrame?.(KO), hO(KO);
          const bK = KO._renderingContexts;
          for (let OO = 0; OO < bK.length; OO++) {
            const KO = bK[OO];
            KO._update(), XO += KO._drawCallsPre + KO._record()
          }
        }
        const KO = OO._currentEncoder;
        for (let OO = 0; OO < pO.length; OO++) {
          const XO = pO[OO];
          XO._captureService?.(XO, KO)
        }
        OO._gpuTimerEnd?.(KO), OO._cbs[0] = KO.finish(), OO._device.queue.submit(OO._cbs), OO._flushGpuRetirements?.(OO), OO.drawCallCount = XO, OO._gpuTimerResolve?.()
      } finally {
        OO._currentEncoder = void 0
      }
    }
  },
  39687: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK,
      f: () => eO,
      g: () => XO
    });
    var XO = globalThis.GPUTextureUsage,
      bK = globalThis.GPUBufferUsage,
      eO = globalThis.GPUShaderStage;
    globalThis.GPUColorWrite
  },
  39742: (OO, KO, pO) => {
    function XO(OO) {
      bK(OO.splice(0))
    }

    function bK(OO) {
      for (const pO of OO) try {
        pO()
      } catch (KO) {
        console.error("GPU resource retirement failed.", KO)
      }
    }

    function eO(OO, KO) {
      OO._flushGpuRetirements ??= lO, (OO._retirements ??= []).push(KO)
    }

    function lO(OO) {
      const KO = OO._retirements;
      if (!KO) return;
      OO._retirements = null;
      const pO = OO._retiring ??= new Set;
      pO.add(KO), queueMicrotask((() => {
        OO._device.queue.onSubmittedWorkDone().then((() => {
          pO.delete(KO), XO(KO)
        })).catch((() => {}))
      }))
    }
    pO.d(KO, {
      d: () => eO
    })
  },
  39728: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      e: () => lO,
      h: () => vK
    });
    var XO = pO(39687);

    function bK(OO) {
      const KO = OO.size;
      return "canvas" in KO ? KO.canvas : KO
    }

    function eO(OO) {
      return {
        _descriptor: OO,
        _resolveSize: bK,
        _colorTexture: null,
        _colorView: null,
        _depthTexture: null,
        _depthView: null,
        _width: 0,
        _height: 0
      }
    }

    function lO(OO, KO) {
      if (OO._eager) return void OO._syncEager?.(KO);
      vK(OO);
      const pO = OO._descriptor,
        {
          width: eO,
          height: lO
        } = (OO._resolveSize ?? bK)(pO);
      OO._width = eO, OO._height = lO;
      const CO = KO._device;
      pO.format && (OO._colorTexture = CO.createTexture({
        label: pO.lbl,
        size: {
          width: eO,
          height: lO
        },
        format: pO.format,
        sampleCount: pO.samples,
        usage: XO.g.RENDER_ATTACHMENT | XO.g.TEXTURE_BINDING | XO.g.COPY_SRC | XO.g.COPY_DST
      }), OO._colorView = OO._colorTexture.createView()), pO.dFormat && (OO._depthTexture = CO.createTexture({
        label: pO.lbl,
        size: {
          width: eO,
          height: lO
        },
        format: pO.dFormat,
        sampleCount: pO.samples,
        usage: XO.g.RENDER_ATTACHMENT | XO.g.TEXTURE_BINDING
      }), OO._depthView = OO._depthTexture.createView())
    }

    function vK(OO) {
      if (!OO || OO._eager && !OO._disposeAttachments) return;
      const KO = OO._colorTexture,
        pO = OO._depthTexture;
      if (OO._colorTexture = OO._depthTexture = null, OO._colorView = OO._depthView = null, OO._width = OO._height = 0, OO._disposeAttachments) OO._disposeAttachments(KO, pO);
      else try {
        KO?.destroy()
      } finally {
        !1 !== OO._ownsDepthTexture && pO?.destroy()
      }
    }
  },
  39739: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO,
      f: () => bK,
      g: () => eO
    });
    var XO = Float32Array,
      bK = Float64Array,
      eO = Uint32Array
  },
  39747: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    var XO = 16
  },
  39684: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK
    });
    var XO = null;

    function bK(OO) {
      for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), bK = 1; bK < KO; bK++) pO[bK - 1] = arguments[bK];
      const eO = new Error(XO?.(OO, pO) ?? `#${OO}`);
      throw eO.lite = pO, eO
    }
  },
  39714: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(39695);

    function bK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      const pO = KO.compare,
        bK = KO.lodMinClamp ?? 0,
        eO = KO.lodMaxClamp ?? 32,
        lO = void 0 !== pO || 0 !== bK || 32 !== eO ? `${pO??""}:${bK}:${eO}` : "";
      return (0, XO.c)(OO, KO, lO)
    }
  },
  39690: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = null;

    function bK(OO) {
      const KO = XO ??= new WeakMap;
      KO.set(OO, (KO.get(OO) ?? 0) + 1)
    }

    function eO(OO) {
      bK(OO.texture)
    }
  },
  39695: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK
    });
    var XO = null,
      bK = "nearest",
      eO = "clamp-to-edge",
      lO = {
        minFilter: bK,
        magFilter: bK,
        mipmapFilter: bK,
        addressModeU: eO,
        addressModeV: eO,
        addressModeW: eO,
        maxAnisotropy: 1
      };

    function vK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
      const bK = OO._device,
        eO = XO ??= new WeakMap;
      let vK = eO.get(bK);
      vK || eO.set(bK, vK = new Map);
      let CO = pO;
      for (const XO in lO) {
        const OO = XO;
        CO += `:${KO[OO]??lO[OO]}`
      }
      let hO = vK.get(CO);
      return hO || vK.set(CO, hO = bK.createSampler(KO)), hO
    }
  },
  39736: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => sO,
      f: () => SO
    });
    var XO = pO(39728),
      bK = pO(39724);

    function eO(OO, KO) {
      KO._passes.length = 0, OO._currentProcessedTask = KO;
      try {
        KO.record()
      } finally {
        OO._currentProcessedTask = null
      }
    }
    var lO = pO(39739);

    function vK(OO) {
      const KO = OO.worldMatrixVersion;
      if (OO._viewVer === KO) return OO._viewCache;
      const pO = OO._viewCache,
        XO = OO.worldMatrix,
        bK = OO._useFloatingOrigin,
        eO = bK ? 0 : XO[12],
        lO = bK ? 0 : XO[13],
        vK = bK ? 0 : XO[14];
      return pO[0] = XO[0], pO[1] = XO[4], pO[2] = XO[8], pO[3] = 0, pO[4] = XO[1], pO[5] = XO[5], pO[6] = XO[9], pO[7] = 0, pO[8] = XO[2], pO[9] = XO[6], pO[10] = XO[10], pO[11] = 0, pO[12] = -(XO[0] * eO + XO[1] * lO + XO[2] * vK), pO[13] = -(XO[4] * eO + XO[5] * lO + XO[6] * vK), pO[14] = -(XO[8] * eO + XO[9] * lO + XO[10] * vK), pO[15] = 1, OO._viewVer = KO, pO
    }
    var CO = null;

    function hO(OO) {
      return OO._projFov === OO.fov && OO._projNear === OO.nearPlane && OO._projFar === OO.farPlane || (OO._projFov = OO.fov, OO._projNear = OO.nearPlane, OO._projFar = OO.farPlane, OO._projRev = (OO._projRev ?? 0) + 1), OO.worldMatrixVersion + (OO._projRev ?? 0)
    }

    function DO(OO, KO) {
      const pO = hO(OO);
      if (OO._projVer === pO && OO._projAspect === KO) return OO._projCache;
      const XO = OO._projCache;
      return null !== CO && OO.ortho ? CO(OO, KO, XO) : function(OO, KO, pO, XO, bK) {
        const eO = 1 / Math.tan(.5 * KO),
          lO = bK - XO;
        OO[0] = eO / pO, OO[5] = eO, OO[10] = -XO / lO, OO[11] = 1, OO[14] = bK * XO / lO
      }(XO, OO.fov, KO, OO.nearPlane, OO.farPlane), OO._projVer = pO, OO._projAspect = KO, XO
    }
    var MO = pO(39687);

    function aK(OO, KO, pO) {
      return OO._device.createBuffer({
        label: pO,
        size: (XO = KO, bK = 16, Math.ceil(XO / bK) * bK),
        usage: MO.b.UNIFORM | MO.b.COPY_DST
      });
      var XO, bK
    }
    var oO = pO(39742),
      FO = null;

    function VO(OO) {
      const KO = OO._device,
        pO = FO ??= new WeakMap;
      let XO = pO.get(KO);
      return XO || (XO = KO.createBindGroupLayout({
        label: "Ce",
        entries: [{
          binding: 0,
          visibility: MO.f.VERTEX | MO.f.FRAGMENT,
          buffer: {
            type: "uniform"
          }
        }, {
          binding: 1,
          visibility: MO.f.FRAGMENT,
          buffer: {
            type: "uniform"
          }
        }]
      }), pO.set(KO, XO)), XO
    }

    function LO(OO, KO, pO) {
      const XO = OO._device,
        bK = aK(OO, KO.byteLength, pO);
      try {
        XO.queue.writeBuffer(bK, 0, KO.buffer, KO.byteOffset, KO.byteLength)
      } catch (eO) {
        throw bK.destroy(), eO
      }
      return bK
    }
    var QO = pO(39747),
      zK = new lO.g(1),
      AO = new lO.b(zK.buffer);

    function fO(OO) {
      let KO = 0;
      for (const pO of OO) KO += pO._lightVersion ?? 0;
      return KO
    }

    function dO(OO, KO) {
      OO.fill(0);
      let pO = 0;
      for (const XO of KO) {
        if (pO >= QO.b) break;
        XO._writeLightUbo && (XO._writeLightUbo(OO, 4 + 16 * pO), pO++)
      }
      zK[0] = pO, OO[0] = AO[0]
    }

    function TO(OO, KO) {
      let pO = KO._lightGpuState;
      const XO = 16 + 16 * QO.b * 4;
      if (pO && pO._byteSize === XO) return pO;
      const bK = !pO;
      pO?._buffer.destroy();
      const eO = new lO.b(XO / 4);
      return dO(eO, KO.lights), OO._applyLightFoOffset?.(eO, KO), pO = {
        _buffer: LO(OO, eO),
        _scratch: eO,
        npO: fO(KO.lights) + (OO._lightFoVersion?.(KO) ?? 0),
        _listVersion: KO._lightListVersion ?? 0,
        _lightCount: KO.lights.length,
        _byteSize: XO
      }, KO._lightGpuState = pO, bK && KO._disposables.push((() => {
        KO._lightGpuState?._buffer.destroy(), KO._lightGpuState = void 0
      })), pO
    }

    function NO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
        XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
      const bK = KO;
      if (0 === XO && 16 === bK.length) return void OO.set(bK, pO);
      const eO = XO,
        lO = pO;
      OO[lO + 0] = bK[eO + 0], OO[lO + 1] = bK[eO + 1], OO[lO + 2] = bK[eO + 2], OO[lO + 3] = bK[eO + 3], OO[lO + 4] = bK[eO + 4], OO[lO + 5] = bK[eO + 5], OO[lO + 6] = bK[eO + 6], OO[lO + 7] = bK[eO + 7], OO[lO + 8] = bK[eO + 8], OO[lO + 9] = bK[eO + 9], OO[lO + 10] = bK[eO + 10], OO[lO + 11] = bK[eO + 11], OO[lO + 12] = bK[eO + 12], OO[lO + 13] = bK[eO + 13], OO[lO + 14] = bK[eO + 14], OO[lO + 15] = bK[eO + 15]
    }

    function IO(OO, KO, pO, XO, bK) {
      OO.fill(0);
      const eO = function(OO, KO) {
          const pO = hO(OO);
          if (OO._vpVer === pO && OO._vpAspect === KO) return OO._vpCache;
          const XO = OO._vpCache;
          return function(OO, KO, pO, XO, bK, eO) {
            const lO = pO[XO],
              vK = pO[XO + 1],
              CO = pO[XO + 2],
              hO = pO[XO + 3],
              DO = pO[XO + 4],
              MO = pO[XO + 5],
              aK = pO[XO + 6],
              oO = pO[XO + 7],
              FO = pO[XO + 8],
              VO = pO[XO + 9],
              LO = pO[XO + 10],
              QO = pO[XO + 11],
              zK = pO[XO + 12],
              AO = pO[XO + 13],
              fO = pO[XO + 14],
              dO = pO[XO + 15];
            let TO = bK[eO],
              NO = bK[eO + 1],
              IO = bK[eO + 2],
              yK = bK[eO + 3];
            OO[KO] = lO * TO + DO * NO + FO * IO + zK * yK, OO[KO + 1] = vK * TO + MO * NO + VO * IO + AO * yK, OO[KO + 2] = CO * TO + aK * NO + LO * IO + fO * yK, OO[KO + 3] = hO * TO + oO * NO + QO * IO + dO * yK, TO = bK[eO + 4], NO = bK[eO + 5], IO = bK[eO + 6], yK = bK[eO + 7], OO[KO + 4] = lO * TO + DO * NO + FO * IO + zK * yK, OO[KO + 5] = vK * TO + MO * NO + VO * IO + AO * yK, OO[KO + 6] = CO * TO + aK * NO + LO * IO + fO * yK, OO[KO + 7] = hO * TO + oO * NO + QO * IO + dO * yK, TO = bK[eO + 8], NO = bK[eO + 9], IO = bK[eO + 10], yK = bK[eO + 11], OO[KO + 8] = lO * TO + DO * NO + FO * IO + zK * yK, OO[KO + 9] = vK * TO + MO * NO + VO * IO + AO * yK, OO[KO + 10] = CO * TO + aK * NO + LO * IO + fO * yK, OO[KO + 11] = hO * TO + oO * NO + QO * IO + dO * yK, TO = bK[eO + 12], NO = bK[eO + 13], IO = bK[eO + 14], yK = bK[eO + 15], OO[KO + 12] = lO * TO + DO * NO + FO * IO + zK * yK, OO[KO + 13] = vK * TO + MO * NO + VO * IO + AO * yK, OO[KO + 14] = CO * TO + aK * NO + LO * IO + fO * yK, OO[KO + 15] = hO * TO + oO * NO + QO * IO + dO * yK
          }(XO, 0, DO(OO, KO), 0, vK(OO), 0), OO._vpVer = pO, OO._vpAspect = KO, XO
        }(XO, bK),
        lO = vK(XO),
        CO = XO.worldMatrix;
      NO(OO, eO, 0), NO(OO, lO, 16), KO.useFloatingOrigin ? (OO[32] = 0, OO[33] = 0, OO[34] = 0) : (OO[32] = CO[12], OO[33] = CO[13], OO[34] = CO[14]), OO[87] = KO.canvas.width;
      const MO = pO.imageProcessing;
      OO[76] = MO.exposure, OO[77] = MO.contrast, OO[78] = pO._envTextures?.lodGenerationScale ?? .8, OO[79] = +MO.toneMappingEnabled, OO[37] = KO.canvas.height
    }

    function yK(OO, KO) {
      return {
        _renderables: OO,
        _opaqueBindings: [],
        _directBindings: [],
        _transparentBindings: [],
        _ob: [],
        _lastVersion: KO
      }
    }

    function gK(OO, KO, pO) {
      OO.clr ??= !0;
      const bK = OO.rt._descriptor,
        eO = OO.depth?._descriptor,
        CO = {
          _colorFormat: bK.format,
          _depthStencilFormat: eO?.dFormat ?? bK.dFormat,
          _depthCompare: bK.depthCompare ?? eO?.depthCompare,
          _sampleCount: bK.samples
        },
        DO = {
          loadOp: "clear",
          storeOp: "store"
        },
        MO = {
          ...yK([], -1),
          name: OO.name,
          _config: OO,
          _ownsTargets: !OO.sharedRt,
          engine: KO,
          Ce: pO,
          _passes: [],
          _renderPassDescriptor: {
            colorAttachments: [DO]
          },
          _colorAttachment: DO,
          _sceneUBO: aK(KO, 368),
          _suData: new lO.b(92),
          _sceneUboCacheKey: [],
          _targetSignature: CO,
          _updateContext: {
            targetWidth: 0,
            targetHeight: 0
          },
          record() {
            if (MO._disposed) throw new Error("RenderTask has been disposed.");
            MO._recordExplicit ? MO._recordExplicit(MO, !0) : jK(MO, !1 !== OO.autoMirror ? pO._renderables.slice() : MO._renderables, !0)
          },
          execute: () => function(OO, KO, pO) {
            if (!1 === OO.enabled) return 0;
            const XO = OO.Ce;
            ! function(OO, KO, pO) {
              const XO = OO.Ce;
              !1 !== OO._config.autoMirror && OO._lastVersion !== XO._renderableVersion && jK(OO, XO._renderables.slice());
              wO(OO, KO);
              const bK = OO._updateContext,
                eO = OO._config.cam ?? XO.camera;
              pO._colorFormat && (OO._config._skipClusteredLights || XO._clusteredLightUpdater?.(eO, bK.targetWidth, bK.targetHeight), function(OO, KO) {
                const pO = TO(OO, KO),
                  XO = fO(KO.lights) + (OO._lightFoVersion?.(KO) ?? 0),
                  bK = KO._lightListVersion ?? 0;
                XO === pO.npO && bK === pO._listVersion && KO.lights.length === pO._lightCount || (pO.npO = XO, pO._listVersion = bK, pO._lightCount = KO.lights.length, dO(pO._scratch, KO.lights), OO._applyLightFoOffset?.(pO._scratch, KO), OO._device.queue.writeBuffer(pO._buffer, 0, pO._scratch)), pO._buffer
              }(KO, XO));
              (function(OO, KO, pO, XO) {
                if (!XO) return;
                const bK = XO.viewport,
                  eO = OO._config.rt,
                  lO = (OO._config.cs ? KO.canvas.width / KO.canvas.height : eO._width / eO._height) * (bK ? bK.width / bK.height : 1),
                  vK = pO.fog,
                  CO = pO.imageProcessing,
                  DO = hO(XO),
                  MO = pO._envTextures,
                  aK = OO._sceneUboCacheKey;
                if (aK[0] === XO && aK[1] === vK && aK[2] === DO && aK[3] === lO && aK[4] === CO.exposure && aK[5] === CO.contrast && aK[6] === MO) return;
                aK[0] = XO, aK[1] = vK, aK[2] = DO, aK[3] = lO, aK[4] = CO.exposure, aK[5] = CO.contrast, aK[6] = MO;
                const oO = OO._suData;
                IO(oO, KO, pO, XO, lO);
                const FO = pO._sceneUboContributors;
                if (FO)
                  for (const hO of FO) hO(oO, pO);
                KO._device.queue.writeBuffer(OO._sceneUBO, 0, oO)
              })(OO, KO, XO, eO), bK.ZbO = eO, OO._batchState?._reset(), iK(OO._opaqueBindings, bK), iK(OO._directBindings, bK), iK(OO._transparentBindings, bK), OO._batchState?._flush(KO),
                function(OO, KO) {
                  const pO = OO._transparentBindings;
                  if (pO.length <= 1 || !KO) return;
                  const XO = vK(KO);
                  for (const bK of pO) {
                    const OO = bK.renderable._worldCenter;
                    bK._sortDistance = OO ? OO[0] * XO[2] + OO[1] * XO[6] + OO[2] * XO[10] + XO[14] : 0
                  }
                  pO.sort(uO)
                }(OO, eO)
            }(OO, KO, pO);
            const bK = OO._colorAttachment,
              eO = OO._config;
            eO.rt._colorView && (eO.rt === XO.surface.scRT && (bK.view = eO.rt._colorView), bK.resolveTarget = eO.rst?._colorView ?? void 0, bK.clearValue = eO.clrColor ?? XO.clearColor, bK.loadOp = eO.clr ? "clear" : "load");
            if (OO._executeWithTransmission) return OO._executeWithTransmission(pO._sampleCount);
            const lO = KO._currentEncoder.beginRenderPass(OO._renderPassDescriptor),
              CO = YO(OO, lO);
            return lO.end(), CO
          }(MO, KO, CO),
          dispose() {
            if (MO._disposed) return;
            MO._disposed = !0;
            const KO = MO._pendingMeshes;
            KO && (KO.length = 0);
            for (const OO of MO._renderables) MO._retireRenderable?.(MO.engine, OO);
            MO._passes.length = MO._opaqueBindings.length = MO._directBindings.length = 0, MO._transparentBindings.length = MO._renderables.length = MO._ob.length = 0, MO._ownsTargets && ((0, XO.h)(OO.rt), (0, XO.h)(OO.rst)), OO.depth?._eager || (0, XO.h)(OO.depth);
            const pO = MO._sceneUBO;
            (0, oO.d)(MO.engine, (() => pO.destroy())), MO._batchState?._release(MO.engine), MO._batchState = void 0
          }
        };
      return MO
    }

    function uO(OO, KO) {
      return KO._sortDistance - OO._sortDistance || OO.renderable.order - KO.renderable.order
    }

    function EO(OO, KO) {
      return OO.renderable.order - KO.renderable.order
    }

    function jK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO._renderables,
        pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
        bK = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
        eO = arguments.length > 4 ? arguments[4] : void 0;
      const lO = OO._config,
        vK = lO.rt,
        CO = OO._batchState,
        hO = yK(KO, OO.Ce._renderableVersion);
      if (pO) {
        const KO = (KO, pO) => {
          KO && (pO || OO._ownsTargets || KO._eager) && (0, XO.e)(KO, OO.engine)
        };
        KO(vK), vK._descriptor.samples > 1 && KO(lO.rst), KO(lO.depth, !0)
      }
      const {
        _opaqueBindings: DO,
        _directBindings: MO,
        _transparentBindings: aK
      } = hO;
      try {
        for (const pO of KO) {
          const KO = pO.bind(OO.engine, OO._targetSignature);
          hO._batchState = OO._targetSignature._collectBatches?.(hO._batchState, KO), pO.isTransparent || pO._transmissive ? aK.push(KO) : pO._direct ? MO.push(KO) : DO.push(KO)
        }
        DO.sort(EO), MO.sort(EO), pO && wO(OO, OO.engine, !1)
      } catch (oO) {
        throw hO._batchState?._release(void 0, eO ?? [CO]), oO
      }
      return pO && (! function(OO, KO) {
        const pO = OO._config,
          XO = OO._colorAttachment;
        XO.view = KO._colorView, OO._renderPassDescriptor.colorAttachments = KO._colorView ? [XO] : [];
        const bK = pO.depth ?? KO,
          eO = bK._depthView;
        let lO;
        if (eO) {
          const OO = bK._descriptor,
            KO = (pO.depth ? bK._eager : !1 === pO.depthClear) ? "load" : "clear";
          lO = {
            view: eO,
            depthClearValue: OO.depthClearValue ?? 0,
            depthLoadOp: KO,
            depthStoreOp: "store"
          }, OO.dFormat?.includes("stencil") && (lO.stencilClearValue = 0, lO.stencilLoadOp = KO, lO.stencilStoreOp = "store")
        }
        OO._renderPassDescriptor.depthStencilAttachment = lO
      }(OO, vK), OO._updateContext.targetWidth = vK._width, OO._updateContext.targetHeight = vK._height), bK && (Object.assign(OO, hO), CO?._release(OO.engine, [hO._batchState])), hO
    }

    function YO(OO, KO) {
      const pO = OO.engine,
        XO = OO._config,
        eO = XO.rt,
        lO = OO.Ce,
        vK = OO._opaqueBindings,
        CO = OO._ob,
        hO = OO._sceneBG;
      if (function(OO, KO, pO, XO) {
          const bK = KO?.viewport;
          if (!bK) return;
          const eO = Math.floor(bK.x * pO),
            lO = Math.floor((1 - bK.y - bK.height) * XO),
            vK = Math.ceil((bK.x + bK.width) * pO) - eO,
            CO = Math.ceil((1 - bK.y) * XO) - lO;
          OO.setViewport(eO, lO, vK, CO, 0, 1), OO.setScissorRect(eO, lO, vK, CO)
        }(KO, XO.cam ?? lO.camera, eO._width, eO._height), KO.setBindGroup(0, hO), OO._lastVis !== bK.c || !CO.length) {
        const KO = eO._descriptor,
          XO = pO._device.createRenderBundleEncoder({
            colorFormats: KO.format ? [KO.format] : [],
            depthStencilFormat: OO._targetSignature._depthStencilFormat,
            sampleCount: KO.samples
          });
        XO.setBindGroup(0, hO), rK(XO, vK, pO), CO[0] = XO.finish(), OO._lastVis = bK.c
      }
      let DO = vK.length;
      return KO.executeBundles(CO), KO.setBindGroup(0, hO), DO += rK(KO, OO._directBindings, pO), DO += rK(KO, OO._transparentBindings, pO), DO
    }

    function wO(OO, KO) {
      let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
      const XO = TO(KO, OO.Ce)._buffer;
      if (XO === OO._lightsUBO) return;
      const bK = KO._device.createBindGroup({
        layout: VO(KO),
        entries: [{
          binding: 0,
          resource: {
            buffer: OO._sceneUBO
          }
        }, {
          binding: 1,
          resource: {
            buffer: XO
          }
        }]
      });
      OO._lightsUBO = XO, OO._sceneBG = bK, pO && (OO._ob = [])
    }

    function iK(OO, KO) {
      for (const pO of OO) pO.update?.(KO)
    }

    function rK(OO, KO, pO) {
      let XO = null,
        bK = 0;
      for (const eO of KO) {
        const KO = eO.renderable.mesh;
        KO && !1 === KO.visible || (eO.pipeline !== XO && (OO.setPipeline(eO.pipeline), XO = eO.pipeline), bK += eO.draw(OO, pO))
      }
      return bK
    }

    function PO(OO) {
      const KO = OO._materialSwapQueue;
      if (!KO[0] || OO._runtimeBuilds?.w) return;
      let XO, bK, eO;
      const lO = OO._renderables;
      for (const pO of KO) {
        const KO = pO.material;
        if (!KO) continue;
        const vK = pO._runtimeThinBuild;
        if (vK) {
          bK = vK(OO, pO, bK);
          continue
        }
        const CO = OO._groups.get(KO._buildGroup),
          hO = CO?.r;
        if (!hO) {
          (eO ??= []).push(pO);
          continue
        }
        if (CO._w?.(pO)) {
          (eO ??= []).push([pO, KO]);
          continue
        }
        const DO = OO._meshDisposables.get(pO);
        DO && (OO._meshDisposables.delete(pO), (0, oO.d)(OO.surface.engine, (() => DO.forEach((OO => OO())))));
        const MO = CO.o;
        let aK;
        for (let OO = lO.length; OO--;) lO[OO].mesh === pO && (aK = lO.splice(OO, 1)[0]);
        KO._csmGen = -~KO._csmGen;
        const FO = hO(OO, pO);
        if (MO) {
          const OO = MO.indexOf(aK);
          OO < 0 ? MO.push(FO) : MO[OO] = FO
        }
        XO = lO.push(FO)
      }
      if (XO && (lO.sort(((OO, KO) => OO.order - KO.order)), OO._renderableVersion++, OO._materialEpoch++), KO.length = 0, !eO) return bK;
      const vK = eO;
      return pO.e(343).then((() => pO(59165))).then((KO => {
        let {
          C: pO
        } = KO;
        return pO(OO, vK, bK)
      }), (KO => {
        const pO = OO._runtimeBuilds;
        pO ? pO._x(KO) : console.error(KO)
      }))
    }
    var mK = null;

    function sO(OO, KO) {
      const pO = OO.engine,
        bK = {
          _kind: "Ce",
          surface: OO,
          clearColor: {
            r: .2,
            g: .2,
            b: .3,
            a: 1
          },
          camera: null,
          lights: [],
          meshes: [],
          animationGroups: [],
          fog: null,
          clipPlane: null,
          shadowGenerators: [],
          imageProcessing: {
            exposure: 1,
            contrast: 1,
            toneMappingEnabled: !1
          },
          _renderables: [],
          _prePasses: [],
          _pickSources: [],
          _uniformUpdaters: [],
          fixedDeltaMs: 0,
          _beforeRender: [],
          _deferredBuilders: [],
          _groups: new Map,
          _disposables: [],
          _meshDisposables: new Map,
          _materialSwapQueue: [],
          _renderableVersion: 0,
          _materialEpoch: 0,
          _built: !1,
          _drawCallsPre: 0,
          _update() {
            pO.useFloatingOrigin && bK.camera && !bK.camera._useFloatingOrigin && (bK.camera._useFloatingOrigin = !0, bK.camera._viewVer = -1, bK.camera._vpVer = -1);
            const OO = bK.fixedDeltaMs > 0 ? bK.fixedDeltaMs : pO._currentDelta,
              KO = pO._currentEncoder;
            let XO = 0;
            for (const pO of bK._beforeRender) pO(OO);
            bK._materialSwapQueue.length && PO(bK);
            for (const eO of bK._prePasses) XO += eO.execute(KO, pO);
            for (const eO of bK._uniformUpdaters) eO.update(pO);
            bK._drawCallsPre = XO
          },
          _record: () => bK._frameGraph.execute(),
          _resize() {
            bK._frameGraph.build()
          }
        },
        lO = function() {
          const OO = {
            _tasks: [],
            _currentProcessedTask: null,
            build() {
              for (let KO = 0; KO < OO._tasks.length; KO++) eO(OO, OO._tasks[KO]);
              for (const KO of OO._tasks)
                for (const OO of KO._passes) OO._initialize()
            },
            execute() {
              let KO = 0;
              for (const pO of OO._tasks)
                if (!1 !== pO.executionEnabled)
                  if (pO.execute) KO += pO.execute();
                  else
                    for (const OO of pO._passes) KO += OO._execute();
              return KO
            },
            dispose() {
              for (const KO of OO._tasks) KO.dispose();
              OO._tasks.length = 0, OO._currentProcessedTask = null
            }
          };
          return OO
        }();
      if (bK._frameGraph = lO, !1 !== KO?.defaultRenderTask) {
        const KO = OO.msaaSamples > 1,
          eO = KO ? (0, XO.d)({
            lbl: "scene-color",
            format: OO.format,
            dFormat: "depth24plus-stencil8",
            samples: OO.msaaSamples,
            size: OO
          }) : OO.scRT,
          vK = KO ? void 0 : (0, XO.d)({
            lbl: "scene-depth",
            dFormat: "depth24plus-stencil8",
            samples: 1,
            size: OO
          });
        ! function(OO, KO) {
          OO._tasks.push(KO)
        }(lO, gK({
          name: "Ce",
          rt: eO,
          rst: KO ? OO.scRT : void 0,
          depth: vK
        }, pO, bK))
      }
      return bK._disposables.push((() => lO.dispose())), bK
    }
    async function HO(OO) {
      const KO = OO;
      for (KO._built || (KO._materialSwapQueue.length = 0); KO._deferredBuilders.length;) {
        const OO = KO._deferredBuilders.splice(0);
        await Promise.all(OO.map((OO => OO())))
      }
      await PO(KO), mK?.get(KO)?.() || (KO._runtimeBuilds?._e(), KO._renderableVersion++, KO._built = !0), await (KO._rebuildHook?.(KO))
    }
    var RO = null;
    async function SO(OO) {
      const KO = OO,
        XO = KO.surface;
      (0, bK.h)(XO, KO) || (await HO(OO), KO._renderables.sort(JO), await Promise.all(KO._frameGraph._tasks.map((OO => OO._preload?.()))), RO && await RO(KO), KO._frameGraph.build(), XO._renderingContexts[0] && (await pO.e(341).then((() => pO(59156)))).configureSwapchainOverlayScene(XO, KO), mK?.get(KO)?.() || (0, bK.k)(XO, KO))
    }
    var JO = (OO, KO) => OO.order - KO.order
  },
  39722: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO,
      f: () => DO
    });
    var XO = pO(39684),
      bK = pO(39687),
      eO = pO(39690),
      lO = pO(39695),
      vK = pO(39700),
      CO = pO(39708);

    function hO(OO, KO, pO) {
      let vK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
      (KO < 1 || pO < 1) && (0, XO.d)(676, KO, pO);
      const hO = OO._device,
        DO = vK.mipMaps ?? !1,
        MO = vK.srgb ? "rgba8unorm-srgb" : "rgba8unorm",
        aK = DO ? (0, CO.c)(KO, pO) : 1,
        oO = hO.createTexture({
          size: {
            width: KO,
            height: pO
          },
          format: MO,
          mipLevelCount: aK,
          usage: bK.g.TEXTURE_BINDING | bK.g.COPY_DST | bK.g.RENDER_ATTACHMENT
        }),
        FO = {
          addressModeU: vK.addressModeU ?? "clamp-to-edge",
          addressModeV: vK.addressModeV ?? "clamp-to-edge",
          minFilter: vK.minFilter ?? "linear",
          magFilter: vK.magFilter ?? "linear",
          mipmapFilter: DO ? "linear" : "nearest"
        },
        VO = (0, lO.c)(OO, FO),
        LO = {
          texture: oO,
          view: oO.createView(),
          sampler: VO,
          width: KO,
          height: pO
        };
      return (0, eO.e)(LO), OO._dlr && OO._dlr.t(LO, {
        kind: "dynamic",
        width: KO,
        height: pO,
        format: MO,
        levels: aK,
        samplerDesc: FO,
        source: null,
        flipY: !0,
        premultipliedAlpha: !1
      }), LO
    }

    function DO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
      const bK = XO.invertY ?? !0,
        eO = XO.premultiplyAlpha ?? !1;
      OO._device.queue.copyExternalImageToTexture({
        source: pO,
        flipY: bK
      }, {
        texture: KO.texture,
        premultipliedAlpha: eO
      }, [KO.width, KO.height]);
      const lO = KO._recoverySource;
      lO && "dynamic" === lO.kind && (lO.source = pO, lO.flipY = bK, lO.premultipliedAlpha = eO), KO.texture.mipLevelCount > 1 && (0, vK.generateMipmaps)(OO, KO.texture)
    }
  },
  39719: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO
    });
    var XO = pO(39684),
      bK = pO(39687),
      eO = pO(39690),
      lO = pO(39695),
      vK = pO(39708);
    async function CO(OO, KO) {
      let CO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      const [hO, DO] = function(OO) {
        const KO = OO,
          pO = [
            [KO.displayWidth, KO.displayHeight],
            [KO.videoWidth, KO.videoHeight],
            [KO.naturalWidth, KO.naturalHeight],
            [KO.width, KO.height]
          ];
        for (const [XO, bK] of pO)
          if (void 0 !== XO && void 0 !== bK && Number.isInteger(XO) && Number.isInteger(bK) && XO > 0 && bK > 0) return [XO, bK];
        throw new TypeError("createTexture2DFromExternalImage: source has no supported positive intrinsic dimensions")
      }(KO), [MO, aK] = function(OO, KO, pO) {
        if (void 0 === pO) return [OO, KO];
        if (!Number.isInteger(pO) || pO < 1) throw new TypeError(`createTexture2DFromExternalImage: maxDimension must be a positive integer (got ${pO})`);
        if (Math.max(OO, KO) <= pO) return [OO, KO];
        const XO = pO / Math.max(OO, KO);
        return OO >= KO ? [pO, Math.max(1, Math.round(KO * XO))] : [Math.max(1, Math.round(OO * XO)), pO]
      }(hO, DO, CO.maxDimension), oO = CO.mipMaps ?? !0, FO = CO.premultiplyAlpha ?? !1;
      let VO = KO,
        LO = null;
      const QO = {
        texture: null
      };
      try {
        MO === hO && aK === DO || (LO = await createImageBitmap(KO, {
          resizeWidth: MO,
          resizeHeight: aK,
          resizeQuality: "high",
          premultiplyAlpha: FO ? "premultiply" : "none",
          colorSpaceConversion: "none"
        }), VO = LO);
        const zK = OO._device,
          AO = CO.srgb ? "rgba8unorm-srgb" : "rgba8unorm",
          fO = oO ? (0, vK.c)(MO, aK) : 1,
          dO = fO > 1 ? (await Promise.resolve().then((() => pO(39700)))).generateMipmaps : null,
          TO = {
            addressModeU: CO.addressModeU ?? "repeat",
            addressModeV: CO.addressModeV ?? "repeat",
            minFilter: CO.minFilter ?? "linear",
            magFilter: CO.magFilter ?? "linear",
            mipmapFilter: oO ? "linear" : "nearest"
          };
        TO.maxAnisotropy = "linear" === TO.minFilter && "linear" === TO.magFilter && "linear" === TO.mipmapFilter ? 4 : 1;
        const NO = CO.invertY ?? !0,
          IO = async KO => {
            let pO;
            zK.pushErrorScope("validation"), zK.pushErrorScope("out-of-memory");
            let eO = null;
            try {
              const pO = QO.texture = zK.createTexture({
                size: {
                  width: MO,
                  height: aK
                },
                format: AO,
                mipLevelCount: fO,
                usage: bK.g.TEXTURE_BINDING | bK.g.COPY_DST | bK.g.RENDER_ATTACHMENT
              });
              zK.queue.copyExternalImageToTexture({
                source: KO,
                flipY: NO
              }, {
                texture: pO,
                premultipliedAlpha: FO
              }, {
                width: MO,
                height: aK
              }), dO && dO(OO, pO), eO = (0, lO.c)(OO, TO)
            } catch (oO) {
              pO = oO
            }
            const [vK, CO] = await Promise.all([zK.popErrorScope(), zK.popErrorScope()]);
            if (pO) throw pO;
            const hO = CO ?? vK;
            if (hO) throw new Error(`createTexture2DFromExternalImage: GPU upload failed: ${hO.message}`, {
              cause: hO
            });
            const DO = QO.texture;
            return DO && eO || (0, XO.d)(677), {
              texture: DO,
              view: DO.createView(),
              sampler: eO,
              width: MO,
              height: aK
            }
          }, yK = await (OO._dlr?.x(VO, MO, aK, AO, fO, TO, NO, FO, IO)) ?? await IO(VO);
        return (0, eO.e)(yK), yK
      } catch (zK) {
        throw QO.texture?.destroy(), zK
      } finally {
        LO?.close()
      }
    }
  },
  39700: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      generateMipmaps: () => oO,
      recordMipmaps: () => FO
    });
    var XO = pO(39687),
      bK = pO(39695),
      eO = {
        magFilter: "linear",
        minFilter: "linear"
      };
    var lO = "@group(0)@binding(0)var t:texture_2d<f32>;@group(0)@binding(1)var s:sampler;struct V{@builtin(position)p:vec4f,@location(0)u:vec2f};@vertex fn vs(@builtin(vertex_index)i:u32)->V{let p=array<vec2f,3>(vec2f(-1,-1),vec2f(3,-1),vec2f(-1,3))[i];return V(vec4f(p,0,1),p*vec2f(.5,-.5)+.5);}@fragment fn fs(v:V)->@location(0)vec4f{return textureSample(t,s,v.u);}",
      vK = null,
      CO = null,
      hO = null,
      DO = null,
      MO = null;

    function aK(OO) {
      const KO = OO._device;
      KO !== MO && (vK?.clear(), vK = null, CO = null, hO = null, DO = null, MO = null, MO = KO), CO ??= KO.createShaderModule({
        code: lO
      }), hO ??= function(OO) {
        return (0, bK.c)(OO, eO)
      }(OO), DO ??= KO.createBindGroupLayout({
        entries: [{
          binding: 0,
          visibility: XO.f.FRAGMENT,
          texture: {
            sampleType: "float"
          }
        }, {
          binding: 1,
          visibility: XO.f.FRAGMENT,
          sampler: {}
        }]
      })
    }

    function oO(OO, KO, pO) {
      const XO = OO._device,
        bK = XO.createCommandEncoder();
      FO(OO, KO, bK, pO), XO.queue.submit([bK.finish()])
    }

    function FO(OO, KO, pO, XO) {
      if (KO.mipLevelCount <= 1) return;
      const bK = OO._device,
        eO = function(OO, KO) {
          const pO = OO._device;
          aK(OO), vK ??= new Map;
          let XO = vK.get(KO);
          return XO || (XO = pO.createRenderPipeline({
            layout: pO.createPipelineLayout({
              bindGroupLayouts: [DO]
            }),
            vertex: {
              module: CO,
              entryPoint: "vs"
            },
            fragment: {
              module: CO,
              entryPoint: "fs",
              targets: [{
                format: KO
              }]
            },
            primitive: {
              topology: "triangle-list"
            }
          }), vK.set(KO, XO)), XO
        }(OO, KO.format),
        lO = null != XO ? {
          dimension: "2d",
          baseArrayLayer: XO,
          arrayLayerCount: 1
        } : {};
      for (let vK = 1; vK < KO.mipLevelCount; vK++) {
        const OO = KO.createView({
            baseMipLevel: vK - 1,
            mipLevelCount: 1,
            ...lO
          }),
          XO = KO.createView({
            baseMipLevel: vK,
            mipLevelCount: 1,
            ...lO
          }),
          CO = bK.createBindGroup({
            layout: DO,
            entries: [{
              binding: 0,
              resource: OO
            }, {
              binding: 1,
              resource: hO
            }]
          }),
          MO = pO.beginRenderPass({
            colorAttachments: [{
              view: XO,
              loadOp: "clear",
              storeOp: "store",
              clearValue: {
                r: 0,
                g: 0,
                b: 0,
                a: 0
              }
            }]
          });
        MO.setPipeline(eO), MO.setBindGroup(0, CO), MO.draw(3), MO.end()
      }
    }
  },
  39708: (OO, KO, pO) => {
    function XO(OO, KO) {
      return Math.floor(Math.log2(Math.max(OO, KO))) + 1
    }
    pO.d(KO, {
      c: () => XO
    })
  },
  39676: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => hO,
      h: () => DO
    });
    var XO = pO(39684),
      bK = pO(39687),
      eO = pO(39690),
      lO = pO(39695),
      vK = pO(39700),
      CO = pO(39708);

    function hO(OO, KO, pO, vK) {
      let hO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
      (KO < 1 || pO < 1 || vK < 1) && (0, XO.d)(722, KO, pO, vK);
      const DO = OO._device,
        MO = hO.mipMaps ?? !0,
        aK = hO.srgb ? "rgba8unorm-srgb" : "rgba8unorm",
        oO = DO.createTexture({
          size: {
            width: KO,
            height: pO,
            depthOrArrayLayers: vK
          },
          dimension: "2d",
          format: aK,
          mipLevelCount: MO ? (0, CO.c)(KO, pO) : 1,
          usage: bK.g.TEXTURE_BINDING | bK.g.COPY_DST | bK.g.RENDER_ATTACHMENT
        }),
        FO = (0, lO.c)(OO, {
          addressModeU: hO.addressModeU ?? "repeat",
          addressModeV: hO.addressModeV ?? "repeat",
          minFilter: hO.minFilter ?? "linear",
          magFilter: hO.magFilter ?? "linear",
          mipmapFilter: MO ? "linear" : "nearest"
        }),
        VO = {
          texture: oO,
          view: oO.createView({
            dimension: "2d-array"
          }),
          sampler: FO,
          width: KO,
          height: pO,
          layers: vK
        };
      return (0, eO.e)(VO), VO
    }

    function DO(OO, KO, pO, bK) {
      let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
      (pO < 0 || pO >= KO.layers || (0 | pO) !== pO) && (0, XO.d)(723, KO.layers, pO);
      const lO = eO.invertY ?? !0,
        CO = eO.premultiplyAlpha ?? !1;
      OO._device.queue.copyExternalImageToTexture({
        source: bK,
        flipY: lO
      }, {
        texture: KO.texture,
        origin: [0, 0, pO],
        premultipliedAlpha: CO
      }, [KO.width, KO.height, 1]), KO.texture.mipLevelCount > 1 && (0, vK.generateMipmaps)(OO, KO.texture, pO)
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);