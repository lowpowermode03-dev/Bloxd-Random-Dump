export const id = 289;
export const ids = [289];
export const modules = {
  39787: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      _IESTextureLoader: () => vK
    });
    var XO = pO(35664);

    function bK(OO) {
      return OO.split(" ").filter((OO => "" !== OO)).map((OO => parseFloat(OO)))
    }

    function eO(OO, KO, pO) {
      for (; pO.length !== KO;) {
        const KO = bK(OO.lines[OO.index++]);
        pO.push(...KO)
      }
    }

    function lO(OO, KO, pO) {
      let bK = 0,
        eO = 0,
        lO = 0,
        vK = 0,
        CO = 0,
        hO = 0;
      for (let XO = 0; XO < OO.numberOfHorizontalAngles - 1; XO++)
        if (pO < OO.horizontalAngles[XO + 1] || XO === OO.numberOfHorizontalAngles - 2) {
          eO = XO, lO = OO.horizontalAngles[XO], vK = OO.horizontalAngles[XO + 1];
          break
        } for (let XO = 0; XO < OO.numberOfVerticalAngles - 1; XO++)
        if (KO < OO.verticalAngles[XO + 1] || XO === OO.numberOfVerticalAngles - 2) {
          bK = XO, CO = OO.verticalAngles[XO], hO = OO.verticalAngles[XO + 1];
          break
        } const DO = vK - lO,
        MO = hO - CO;
      if (0 === MO) return 0;
      const aK = 0 === DO ? 0 : (pO - lO) / DO,
        oO = (KO - CO) / MO,
        FO = 0 === DO ? eO : eO + 1,
        VO = (0, XO.Lerp)(OO.candelaValues[eO][bK], OO.candelaValues[FO][bK], aK),
        LO = (0, XO.Lerp)(OO.candelaValues[eO][bK + 1], OO.candelaValues[FO][bK + 1], aK);
      return (0, XO.Lerp)(VO, LO, oO)
    }
    class vK {
      constructor() {
        this.supportCascades = !1
      }
      loadCubeData() {
        throw ".ies not supported in Cube."
      }
      loadData(OO, KO, pO) {
        const XO = function(OO) {
          const KO = {
              lines: new TextDecoder("utf-8").decode(OO).split("\n"),
              index: 0
            },
            pO = {
              version: KO.lines[0],
              candelaValues: [],
              horizontalAngles: [],
              verticalAngles: [],
              numberOfHorizontalAngles: 0,
              numberOfVerticalAngles: 0
            };
          for (KO.index = 1; KO.lines.length > 0 && !KO.lines[KO.index].includes("TILT=");) KO.index++;
          KO.lines[KO.index].includes("INCLUDE"), KO.index++;
          const XO = bK(KO.lines[KO.index++]);
          pO.numberOfLights = XO[0], pO.lumensPerLamp = XO[1], pO.numberOfVerticalAngles = XO[3], pO.numberOfHorizontalAngles = XO[4], pO.photometricType = XO[5], pO.unitsType = XO[6], pO.width = XO[7], pO.length = XO[8], pO.height = XO[9], KO.index++;
          for (let bK = 0; bK < pO.numberOfHorizontalAngles; bK++) pO.candelaValues[bK] = [];
          eO(KO, pO.numberOfVerticalAngles, pO.verticalAngles), eO(KO, pO.numberOfHorizontalAngles, pO.horizontalAngles);
          for (let bK = 0; bK < pO.numberOfHorizontalAngles; bK++) eO(KO, pO.numberOfVerticalAngles, pO.candelaValues[bK]);
          let vK = -1;
          for (let bK = 0; bK < pO.numberOfHorizontalAngles; bK++)
            for (let OO = 0; OO < pO.numberOfVerticalAngles; OO++) vK = Math.max(vK, pO.candelaValues[bK][OO]);
          if (vK > 0)
            for (let bK = 0; bK < pO.numberOfHorizontalAngles; bK++)
              for (let OO = 0; OO < pO.numberOfVerticalAngles; OO++) pO.candelaValues[bK][OO] /= vK;
          const CO = 180,
            hO = 360,
            DO = new Float32Array(64800),
            MO = pO.horizontalAngles[0],
            aK = pO.horizontalAngles[pO.numberOfHorizontalAngles - 1];
          for (let bK = 0; bK < 64800; bK++) {
            let OO = bK % hO;
            const KO = Math.floor(bK / hO);
            aK - MO !== 0 && (OO < MO || OO >= aK) && (OO %= 2 * aK, OO > aK && (OO = 2 * aK - OO)), DO[KO + OO * CO] = lO(pO, KO, OO)
          }
          return {
            width: 180,
            height: 1,
            data: DO
          }
        }(new Uint8Array(OO.buffer, OO.byteOffset, OO.byteLength));
        pO(XO.width, XO.height, !!KO.useMipMaps, !1, (() => {
          const OO = KO.qb();
          KO.type = 1, KO.format = 6, KO._gammaSpace = !1, OO._uploadDataToTextureDirectly(KO, XO.data)
        }))
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);