export const id = 127;
export const ids = [127];
export const modules = {
  5754: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => ap,
      f: () => wK,
      j: () => fK,
      m: () => QK,
      o: () => dK,
      p: () => hK,
      r: () => VK,
      v: () => YK,
      z: () => jp,
      C: () => CK
    });
    var XO = pO(2947),
      bK = pO(2959);
    const eO = Function.prototype.toString,
      lO = RegExp.prototype.exec,
      vK = Reflect.apply,
      CO = Function.prototype.call,
      hO = Function.prototype.apply,
      DO = Function.prototype.bind,
      MO = Object.defineProperty,
      aK = Uint8Array;
    let oO, FO;
    try {
      oO = globalThis.crypto, FO = void 0 === oO || null === oO ? void 0 : oO.getRandomValues
    } catch {}
    const VO = "bloxdBindApply";
    let LO;
    try {
      const OO = CO;
      MO(OO, VO, {
        __proto__: null,
        value: DO,
        configurable: !0
      });
      try {
        LO = OO[VO](hO)
      } finally {
        delete OO[VO]
      }
    } catch {}
    const QO = 16,
      zK = 256,
      AO = 0,
      fO = 1,
      dO = 2,
      TO = 3;
    let NO, IO = AO,
      yK = vK,
      gK = 0;

    function uO(OO, KO) {
      return OO === `function ${KO}() { [native code] }` || OO === `function ${KO}() {\n    [native code]\n}`
    }
    const EO = 0,
      jK = 1,
      YO = 2;
    let wO = EO;

    function iK(OO, KO, pO) {
      if (wO === YO && IO === fO && ! function() {
          const OO = NO;
          return gK >= zK && (yK(FO, oO, [OO]), gK = 0), OO[gK++] < 256 / QO
        }()) return function(OO, KO, pO) {
        return yK(OO, KO, pO ?? 0)
      }(...arguments);
      if (wO === EO || IO === dO) return vK(OO, KO, pO);
      let XO;
      wO = EO;
      try {
        IO === AO && (IO = TO, IO = function() {
          const OO = vK(eO, vK, []);
          if (uO(OO, "apply")) return dO;
          if (null === vK(lO, /\(\.\.\.arguments\)/, [OO]) && null === vK(lO, /^function\s*\(\.\.\.[\w$]+\)/, [OO])) return dO;
          if ("function" !== typeof LO || "function" !== typeof CO || "function" !== typeof hO || "function" !== typeof DO || "function" !== typeof MO || "function" !== typeof FO || "function" !== typeof aK || !uO(vK(eO, CO, []), "call") || !uO(vK(eO, hO, []), "apply") || !uO(vK(eO, DO, []), "bind") || !uO(vK(eO, MO, []), "defineProperty") || !uO(vK(eO, FO, []), "getRandomValues") || !uO(vK(eO, aK, []), "Uint8Array")) return dO;
          const KO = LO,
            pO = {},
            XO = function(OO) {
              return this === pO && OO === pO
            };
          try {
            if (!0 !== KO(XO, pO, [pO])) return dO;
            const OO = new aK(zK);
            KO(FO, oO, [OO]), NO = OO
          } catch {
            return dO
          }
          return yK = KO, fO
        }()), XO = vK(OO, KO, pO)
      } catch (bK) {
        throw IO = dO, bK
      }
      return wO = YO, XO
    }
    let rK = vK;

    function PO() {
      return (rK === vK ? 0 : 3) + wO
    }

    function mK() {
      const OO = PO();
      return rK = vK, OO
    }

    function sO(OO) {
      rK = OO >= 3 ? iK : vK, wO = OO % 3
    }
    const HO = Function.prototype.toString,
      RO = Object.getOwnPropertyDescriptor,
      SO = RegExp.prototype.exec,
      JO = Object.prototype.hasOwnProperty,
      cK = Set.prototype.has,
      BO = Reflect.get,
      ZO = Object.getPrototypeOf,
      GO = "undefined" === typeof WebAssembly ? void 0 : WebAssembly;

    function qK(OO, KO, pO) {
      return {
        code: OO,
        holder: KO,
        key: pO,
        ...arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
        native: new RegExp(`^function (get )?${pO}\\(\\) \\{\\s*\\[native code\\]\\s*\\}$`)
      }
    }

    function xK() {
      return GO
    }
    const nO = GO?.Instance.prototype,
      WO = GO?.Memory.prototype;

    function tK() {
      return WO
    }
    let kK, UO;
    try {
      const OO = globalThis.crypto,
        KO = OO?.subtle;
      kK = OO ? ZO(OO) : void 0, UO = KO ? ZO(KO) : void 0
    } catch {}
    const OK = [qK("in", xK, "instantiate", {
      tier: "weighted",
      onNamespace: !0
    }), qK("is", xK, "instantiateStreaming", {
      tier: "weighted",
      onNamespace: !0
    }), qK("co", xK, "compile", {
      tier: "weighted",
      onNamespace: !0
    }), qK("cs", xK, "compileStreaming", {
      tier: "weighted",
      onNamespace: !0
    }), qK("mo", xK, "Module", {
      isConstructor: !0,
      tier: "punished",
      onNamespace: !0
    }), qK("it", xK, "Instance", {
      isConstructor: !0,
      tier: "punished",
      onNamespace: !0
    }), qK("me", xK, "Memory", {
      isConstructor: !0,
      tier: "punished",
      onNamespace: !0
    }), qK("ex", (function() {
      return nO
    }), "exports", {
      isGetter: !0,
      tier: "punished"
    }), qK("bu", tK, "buffer", {
      isGetter: !0,
      tier: "punished"
    }), qK("gr", tK, "grow", {
      tier: "punished"
    }), qK("rc", (function() {
      return "undefined" === typeof Response ? void 0 : Response.prototype
    }), "clone"), qK("cr", (function() {
      return globalThis
    }), "crypto", {
      isGetter: !0,
      tier: "punished",
      inSecureContext: !0
    }), qK("su", (function() {
      return kK
    }), "subtle", {
      isGetter: !0,
      tier: "punished",
      inSecureContext: !0
    }), qK("dg", (function() {
      return UO
    }), "digest", {
      tier: "punished",
      inSecureContext: !0
    })];

    function KK(OO) {
      let KO;
      try {
        const pO = BO(globalThis, OO);
        KO = "function" === typeof pO ? pO.prototype : void 0
      } catch {}
      return () => KO
    }

    function pK(OO, KO, pO) {
      return pO.map((pO => qK(OO, KO, pO)))
    }
    const XK = qK("rx", KK("HTMLCanvasElement"), "getContext"),
      bp = ["createShader", "shaderSource", "compileShader", "createProgram", "linkProgram", "useProgram", "drawArrays", "drawElements", "depthFunc", "depthMask", "enable", "disable", "blendFuncSeparate", "colorMask"],
      eK = {
        webgpu: [...pK("gd", KK("GPUDevice"), ["createShaderModule", "createRenderPipeline", "createCommandEncoder"]), ...pK("gq", KK("GPUQueue"), ["submit", "writeBuffer"]), ...pK("ge", KK("GPUCommandEncoder"), ["beginRenderPass", "finish"]), ...pK("gp", KK("GPURenderPassEncoder"), ["setPipeline", "setBindGroup", "draw", "drawIndexed", "drawIndirect", "drawIndexedIndirect", "executeBundles"]), XK],
        webgl: [...pK("g2", KK("WebGL2RenderingContext"), [...bp, "drawArraysInstanced", "drawElementsInstanced"]), XK],
        webgl1: [...pK("g1", KK("WebGLRenderingContext"), bp), XK]
      };
    let lK = [];
    const vp = new Set(Object.values(eK).flatMap((OO => OO.map((OO => `wh:${OO.code}`)))));

    function CK(OO) {
      lK = eK[OO]
    }

    function hK(OO) {
      const KO = mK();
      try {
        return rK(cK, vp, [OO])
      } finally {
        sO(KO)
      }
    }

    function DK(OO) {
      return new Set(OK.filter((KO => KO.tier === OO)).map((OO => `wh:${OO.code}`)))
    }
    const MK = DK("punished"),
      ap = !1,
      oK = new Set(bK.e),
      FK = DK("weighted");

    function VK(OO) {
      const KO = mK();
      try {
        return LK(OO)
      } finally {
        sO(KO)
      }
    }

    function LK(OO) {
      return rK(cK, FK, [OO])
    }

    function QK(OO) {
      const KO = mK();
      try {
        return zp(OO)
      } finally {
        sO(KO)
      }
    }

    function zp(OO) {
      return rK(cK, oK, [OO])
    }

    function AK(OO) {
      return "wb" === OO || rK(cK, MK, [OO])
    }

    function fK(OO) {
      const KO = mK();
      try {
        return AK(OO) || zp(OO)
      } finally {
        sO(KO)
      }
    }

    function dK(OO) {
      const KO = mK();
      try {
        return "wb" === OO || ap && AK(OO)
      } finally {
        sO(KO)
      }
    }

    function TK(OO, KO) {
      let {
        isConstructor: pO,
        native: XO
      } = KO;
      return "function" === typeof OO && (!(!pO && rK(JO, OO, ["prototype"])) && null !== rK(SO, XO, [rK(HO, OO, [])]))
    }

    function NK(OO) {
      const {
        holder: KO,
        key: pO,
        isGetter: XO,
        onNamespace: bK,
        inSecureContext: eO
      } = OO, lO = KO(), vK = function(OO, KO) {
        for (let pO = OO; void 0 !== pO && null !== pO; pO = ZO(pO)) {
          const OO = RO(pO, KO);
          if (OO) return OO
        }
      }(lO, pO);
      if (!vK) return !(eO && !0 === globalThis.isSecureContext);
      const CO = XO ? vK.get : vK.value;
      if (!TK(CO, OO)) return !1;
      if (bK) {
        const KO = globalThis.WebAssembly;
        if (KO !== lO && null !== KO && ("object" === typeof KO || "function" === typeof KO)) {
          const XO = BO(KO, pO);
          return XO === CO || void 0 === XO || TK(XO, OO)
        }
      }
      return !0
    }
    let IK = null,
      yp = !1;

    function gp(OO) {
      try {
        return NK(OO)
      } catch {
        return !1
      }
    }

    function uK() {
      if (void 0 === GO) return null;
      let OO = function() {
        try {
          return globalThis.WebAssembly === GO
        } catch {
          return !1
        }
      }() ? null : "wh:wa";
      const KO = KO => {
        null !== KO && (null === OO || EK(KO) > EK(OO)) && (OO = KO)
      };
      for (let pO = 0; pO < OK.length; pO++) {
        const OO = OK[pO];
        void 0 === OO || gp(OO) || KO(`wh:${OO.code}`)
      }
      KO((0, bK.n)());
      for (let pO = 0; pO < lK.length; pO++) {
        const OO = lK[pO];
        void 0 === OO || gp(OO) || KO(`wh:${OO.code}`)
      }
      return OO
    }

    function EK(OO) {
      return AK(OO) ? 5 : LK(OO) ? 4 : zp(OO) ? 3 : function(OO) {
        return rK(cK, vp, [OO])
      }(OO) ? "wh:rx" === OO ? 0 : 1 : 2
    }

    function jp() {
      const OO = function() {
        const OO = PO();
        return IO === AO || IO === fO ? (rK = iK, wO = jK) : rK = vK, OO
      }();
      try {
        if (null === IK || !AK(IK)) {
          const OO = uK();
          (null === IK || null !== OO && EK(OO) > EK(IK)) && (IK = OO)
        }
      } finally {
        sO(OO)
      }
    }

    function YK() {
      yp = !0
    }

    function wK() {
      if (yp) return "wb";
      if ((!(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0]) && jp(), null !== IK) return IK;
      if (void 0 === GO) return "wn:unsupported";
      const OO = (0, XO.n)();
      return null === OO ? null : `wn:${OO}`
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);