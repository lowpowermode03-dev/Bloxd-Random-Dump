export const id = 64;
export const ids = [64];
export const modules = {
  35512: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO,
      d: () => bK
    });
    const XO = ["Boat", "Obsidian Boat", "Hovercraft", "Yellow Kart", "White Kart", "Red Kart", "Purple Kart", "Pink Kart", "Orange Kart", "Magenta Kart", "Lime Kart", "Light Gray Kart", "Light Blue Kart", "Green Kart", "Gray Kart", "Cyan Kart", "Brown Kart", "Blue Kart", "Black Kart", "Off Roader", "Gold Mining Drill", "Iron Mining Drill", "Diamond Mining Drill", "Moonstone Mining Drill", "Armored Car", "Light Blue Car", "Speedboat"],
      bK = 35 == pO.j ? ["canAutoStep", "speedMultiplier"] : null
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);