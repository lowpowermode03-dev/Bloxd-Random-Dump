export const id = 19;
export const ids = [19];
export const modules = {
  37670: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => bK
    });
    var XO = pO(26);
    const bK = function(OO, KO, pO) {
      let bK;
      return {
        onCreate: OO => {
          bK = OO
        },
        onPlayerClick: (OO, KO, pO, eO, lO, vK) => {
          KO || "Workbench" !== bK.getMetaInfo(vK).rootName || XO.i.pl("toggleMenu", "inventory|Workbench")
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);