export const id = 216;
export const ids = [216];
export const modules = {
  35653: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(35660);
    class bK {
      static get LastCreatedEngine() {
        return 0 === this.Instances.length ? null : this.Instances[this.Instances.length - 1]
      }
      static get LastCreatedScene() {
        return this._LastCreatedScene
      }
    }
    bK.Instances = [], bK.OnEnginesDisposedObservable = new XO.e, bK._LastCreatedScene = null, bK.UseFallbackTexture = !0, bK.FallbackTexture = ""
  },
  37055: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(37061);
    const bK = (OO, KO, pO) => OO ? OO.getClassName && "Mesh" === OO.getClassName() ? null : !OO.getClassName || "SubMesh" !== OO.getClassName() && "PhysicsBody" !== OO.getClassName() ? OO.clone ? OO.clone() : Array.isArray(OO) ? OO.slice() : pO && "object" === typeof OO ? {
      ...OO
    } : null : OO.clone(KO) : null;
    class eO {
      static DeepCopy(OO, KO, pO, eO) {
        let lO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        const vK = function(OO) {
          const KO = [];
          do {
            const pO = Object.getOwnPropertyNames(OO);
            for (const OO of pO) - 1 === KO.indexOf(OO) && KO.push(OO)
          } while (OO = Object.getPrototypeOf(OO));
          return KO
        }(OO);
        for (const hO of vK) {
          if ("_" === hO[0] && (!eO || -1 === eO.indexOf(hO))) continue;
          if (hO.endsWith("Observable")) continue;
          if (pO && -1 !== pO.indexOf(hO)) continue;
          const vK = OO[hO],
            DO = typeof vK;
          if ("function" !== DO) try {
            if ("object" === DO)
              if (vK instanceof Uint8Array) KO[hO] = Uint8Array.from(vK);
              else if (vK instanceof Array) {
              if (KO[hO] = [], vK.length > 0)
                if ("object" == typeof vK[0])
                  for (let OO = 0; OO < vK.length; OO++) {
                    const pO = bK(vK[OO], KO, lO); - 1 === KO[hO].indexOf(pO) && KO[hO].push(pO)
                  } else KO[hO] = vK.slice(0)
            } else KO[hO] = bK(vK, KO, lO);
            else KO[hO] = vK
          } catch (CO) {
            XO.b.Warn(CO.message)
          }
        }
      }
    }
  },
  36274: (OO, KO, pO) => {
    function XO() {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (OO => {
        const KO = 16 * Math.random() | 0;
        return ("x" === OO ? KO : 3 & KO | 8).toString(16)
      }))
    }
    pO.d(KO, {
      b: () => XO
    })
  },
  37061: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      static _CheckLimit(OO, KO) {
        let pO = XO._LogLimitOutputs[OO];
        return pO ? pO.current++ : (pO = {
          limit: KO,
          current: 1
        }, XO._LogLimitOutputs[OO] = pO), pO.current <= pO.limit
      }
      static _GenerateLimitMessage(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        const pO = XO._LogLimitOutputs[OO];
        if (!pO || !XO.MessageLimitReached) return;
        const bK = this._Levels[KO];
        pO.current === pO.limit && XO[bK.name](XO.MessageLimitReached.replace(/%LIMIT%/g, "" + pO.limit).replace(/%TYPE%/g, bK.name ?? ""))
      }
      static _AddLogEntry(OO) {
        XO._LogCache = OO + XO._LogCache, XO.OnNewCacheEntry && XO.OnNewCacheEntry(OO)
      }
      static _FormatMessage(OO) {
        const KO = OO => OO < 10 ? "0" + OO : "" + OO,
          pO = new Date;
        return "[" + KO(pO.getHours()) + ":" + KO(pO.getMinutes()) + ":" + KO(pO.getSeconds()) + "]: " + OO
      }
      static _LogDisabled(OO, KO) {}
      static _LogEnabled() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const bK = Array.isArray(KO) ? KO[0] : KO;
        if (void 0 !== pO && !XO._CheckLimit(bK, pO)) return;
        const eO = XO._FormatMessage(bK),
          lO = this._Levels[OO],
          vK = Array.isArray(KO) ? KO.slice(1) : [];
        lO.logFunc && lO.logFunc("BJS - " + eO, ...vK);
        const CO = `<div style='color:${lO.color}'>${eO}</div><br>`;
        XO._AddLogEntry(CO), XO._GenerateLimitMessage(bK, OO)
      }
      static get LogCache() {
        return XO._LogCache
      }
      static ClearLogCache() {
        XO._LogCache = "", XO._LogLimitOutputs = {}, XO.errorsCount = 0
      }
      static set LogLevels(OO) {
        XO.Log = XO._LogDisabled, XO.Warn = XO._LogDisabled, XO.Error = XO._LogDisabled;
        const KO = [XO.MessageLogLevel, XO.WarningLogLevel, XO.ErrorLogLevel];
        for (const pO of KO)
          if ((OO & pO) === pO) {
            const OO = this._Levels[pO];
            XO[OO.name] = XO._LogEnabled.bind(XO, pO)
          }
      }
    }
    XO.NoneLogLevel = 0, XO.MessageLogLevel = 1, XO.WarningLogLevel = 2, XO.ErrorLogLevel = 4, XO.AllLogLevel = 7, XO.MessageLimitReached = "Too many %TYPE%s (%LIMIT%), no more %TYPE%s will be reported for this message.", XO._LogCache = "", XO._LogLimitOutputs = {}, XO._Levels = [{}, {
      color: "white",
      logFunc: console.log,
      name: "Log"
    }, {
      color: "orange",
      logFunc: console.warn,
      name: "Warn"
    }, {}, {
      color: "red",
      logFunc: console.error,
      name: "Error"
    }], XO.errorsCount = 0, XO.Log = XO._LogEnabled.bind(XO, XO.MessageLogLevel), XO.Warn = XO._LogEnabled.bind(XO, XO.WarningLogLevel), XO.Error = XO._LogEnabled.bind(XO, XO.ErrorLogLevel)
  },
  35660: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    const XO = "undefined" !== typeof WeakRef;
    class bK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        this.initialize(OO, KO, pO, XO)
      }
      initialize(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        return this.mask = OO, this.skipNextObservers = KO, this.target = pO, this.currentTarget = XO, this
      }
    }
    class eO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        this.callback = OO, this.mask = KO, this.scope = pO, this._willBeUnregistered = !1, this.unregisterOnNextCall = !1, this._remove = null
      }
      remove() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        this._remove && this._remove(OO)
      }
    }
    class lO {
      static FromPromise(OO, KO) {
        const pO = new lO;
        return OO.then((OO => {
          pO.notifyObservers(OO)
        })).catch((OO => {
          if (!KO) throw OO;
          KO.notifyObservers(OO)
        })), pO
      }
      get observers() {
        return this._observers
      }
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        this.notifyIfTriggered = KO, this._observers = new Array, this._numObserversMarkedAsDeleted = 0, this._hasNotified = !1, this._eventState = new bK(0), OO && (this._onObserverAdded = OO)
      }
      add(OO) {
        let KO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          pO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        if (!OO) return null;
        const bK = new eO(OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null);
        bK.unregisterOnNextCall = pO, KO ? this._observers.unshift(bK) : this._observers.push(bK), this._onObserverAdded && this._onObserverAdded(bK), this._hasNotified && this.notifyIfTriggered && this.notifyObserver(bK, this._lastNotifiedValue);
        const lO = XO ? new WeakRef(this) : {
          deref: () => this
        };
        return bK._remove = function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          const KO = lO.deref();
          KO && (OO ? KO.remove(bK) : KO._remove(bK))
        }, bK
      }
      addOnce(OO) {
        return this.add(OO, void 0, void 0, void 0, !0)
      }
      remove(OO) {
        if (!OO) return !1;
        OO._remove = null;
        return -1 !== this._observers.indexOf(OO) && (this._deferUnregister(OO), !0)
      }
      removeCallback(OO, KO) {
        for (let pO = 0; pO < this._observers.length; pO++) {
          const XO = this._observers[pO];
          if (!XO._willBeUnregistered && (XO.callback === OO && (!KO || KO === XO.scope))) return this._deferUnregister(XO), !0
        }
        return !1
      }
      _deferUnregister(OO) {
        OO._willBeUnregistered || (this._numObserversMarkedAsDeleted++, OO.unregisterOnNextCall = !1, OO._willBeUnregistered = !0, setTimeout((() => {
          this._remove(OO)
        }), 0))
      }
      _remove(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (!OO) return !1;
        const pO = this._observers.indexOf(OO);
        return -1 !== pO && (KO && this._numObserversMarkedAsDeleted--, this._observers.splice(pO, 1), !0)
      }
      makeObserverTopPriority(OO) {
        this._remove(OO, !1), this._observers.unshift(OO)
      }
      makeObserverBottomPriority(OO) {
        this._remove(OO, !1), this._observers.push(OO)
      }
      notifyObservers(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0,
          bK = arguments.length > 4 ? arguments[4] : void 0;
        if (this.notifyIfTriggered && (this._hasNotified = !0, this._lastNotifiedValue = OO), !this._observers.length) return !0;
        const eO = this._eventState;
        eO.mask = KO, eO.target = pO, eO.currentTarget = XO, eO.skipNextObservers = !1, eO.lastReturnValue = OO, eO.userInfo = bK;
        for (const lO of this._observers)
          if (!lO._willBeUnregistered && (lO.mask & KO && (lO.unregisterOnNextCall && this._deferUnregister(lO), lO.scope ? eO.lastReturnValue = lO.callback.apply(lO.scope, [OO, eO]) : eO.lastReturnValue = lO.callback(OO, eO)), eO.skipNextObservers)) return !1;
        return !0
      }
      notifyObserver(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : -1;
        if (this.notifyIfTriggered && (this._hasNotified = !0, this._lastNotifiedValue = KO), OO._willBeUnregistered) return;
        const XO = this._eventState;
        XO.mask = pO, XO.skipNextObservers = !1, OO.unregisterOnNextCall && this._deferUnregister(OO), OO.callback(KO, XO)
      }
      hasObservers() {
        return this._observers.length - this._numObserversMarkedAsDeleted > 0
      }
      clear() {
        for (; this._observers.length;) {
          const OO = this._observers.pop();
          OO && (OO._remove = null)
        }
        this._onObserverAdded = null, this._numObserversMarkedAsDeleted = 0, this.cleanLastNotifiedState()
      }
      cleanLastNotifiedState() {
        this._hasNotified = !1, this._lastNotifiedValue = void 0
      }
      clone() {
        const OO = new lO;
        return OO._observers = this._observers.slice(0), OO
      }
      hasSpecificMask() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : -1;
        for (const KO of this._observers)
          if (KO.mask & OO || KO.mask === OO) return !0;
        return !1
      }
    }
  },
  59055: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      AsyncLoop: () => XO.e,
      RegisterTools: () => XO.i,
      Tools: () => XO.k,
      className: () => XO.o
    });
    var XO = pO(38172);
    (0, XO.i)()
  },
  35676: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      h: () => bK
    });
    const XO = {};

    function bK(OO, KO) {
      XO[OO] = KO
    }

    function eO(OO) {
      return XO[OO]
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);