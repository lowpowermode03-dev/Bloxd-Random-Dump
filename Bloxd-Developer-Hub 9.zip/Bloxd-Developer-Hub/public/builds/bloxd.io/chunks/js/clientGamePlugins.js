export const id = 26;
export const ids = [26];
export const modules = {
  3972: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => rK,
      g: () => iK
    });
    var XO = pO(3977),
      bK = pO(243);
    const eO = 120,
      lO = 260,
      vK = 1.15,
      CO = 1.2,
      hO = 2,
      DO = 1.08,
      MO = .8,
      aK = .95,
      oO = 8,
      FO = "[\"')\\]\u300d\u300f\uff09]*",
      VO = new RegExp(`[.!?\u2026\u3002\uff01\uff1f]${FO}$`),
      LO = new RegExp(`[?\uff1f]${FO}$`),
      QO = new RegExp(`[!\uff01]${FO}$`),
      zK = /[,;:\u3001\uff0c\uff1b\uff1a]$/,
      AO = "\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uac00-\\ud7af\\uf900-\\ufaff",
      fO = new RegExp(`[${AO}]`),
      dO = new RegExp(`[${AO}]|[^${AO}]+`, "g"),
      TO = /[aeiouy\u0430\u0435\u0438\u043e\u0443\u044b\u044d\u044e\u044f\u03b1\u03b5\u03b7\u03b9\u03bf\u03c5\u03c9]+/g;

    function NO(OO) {
      let KO = 2166136261;
      for (let pO = 0; pO < OO.length; pO++) KO ^= OO.charCodeAt(pO), KO = Math.imul(KO, 16777619);
      return (KO >>> 0) / 4294967295 * 2 - 1
    }

    function IO(OO) {
      var KO;
      if (fO.test(OO)) return 1;
      const pO = OO.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase(),
        XO = pO.replace(/[^0-9]/g, "");
      if (XO.length > 0 && !/\p{L}/u.test(pO)) return Math.min(XO.length, 4);
      const bK = null !== (KO = pO.match(TO)) && void 0 !== KO ? KO : [];
      if (0 === bK.length) {
        var eO, lO;
        const OO = null !== (eO = null === (lO = pO.match(/\p{L}/gu)) || void 0 === lO ? void 0 : lO.length) && void 0 !== eO ? eO : 0;
        return 0 === OO ? 0 : Math.min(Math.max(1, Math.round(OO / 2.5)), oO)
      }
      const vK = pO.replace(/[^\p{L}]/gu, ""),
        CO = bK.length > 1 && "e" === bK.at(-1) && vK.endsWith("e") && !vK.endsWith("le") && !/[\u00e9\u00e8\u00ea]$/i.test(OO.replace(/[^\p{L}]/gu, ""));
      return Math.min(bK.length - (CO ? 1 : 0), oO)
    }

    function yK(OO) {
      return OO.toLowerCase().replace(/[^\p{L}\p{N}]/gu, "")
    }

    function gK(OO) {
      const KO = OO.replace(/[^\p{L}]/gu, "");
      return KO.length >= 2 && KO === KO.toUpperCase() && KO !== KO.toLowerCase()
    }

    function uO(OO, KO) {
      var pO;
      const oO = KO && (0, XO.l)(KO),
        FO = null !== (pO = null === oO || void 0 === oO ? void 0 : oO.syllableMs) && void 0 !== pO ? pO : XO.d,
        AO = function(OO) {
          const KO = [];
          for (const XO of (0, bK.cc)(OO))
            if ("string" === typeof XO)
              for (const OO of XO.split(/(\s+)/)) {
                if ("" === OO) continue;
                if (/^\s+$/.test(OO)) {
                  KO.push({
                    kind: "space",
                    text: OO
                  });
                  continue
                }
                if (!fO.test(OO)) {
                  KO.push({
                    kind: "word",
                    text: OO,
                    delayMs: 0
                  });
                  continue
                }
                let XO = !0;
                for (const bK of null !== (pO = OO.match(dO)) && void 0 !== pO ? pO : []) {
                  var pO;
                  const OO = KO.at(-1);
                  XO || "word" !== (null === OO || void 0 === OO ? void 0 : OO.kind) || fO.test(bK) || /[\p{L}\p{N}]/u.test(bK) ? (XO || KO.push({
                    kind: "space",
                    text: "\u200b"
                  }), KO.push({
                    kind: "word",
                    text: bK,
                    delayMs: 0
                  }), XO = !1) : OO.text += bK
                }
              } else KO.push({
                kind: "icon",
                text: XO.icon,
                delayMs: 0
              });
          return KO
        }(OO),
        TO = [];
      let uO = [];
      for (const XO of AO) "space" !== XO.kind && (uO.push(XO), VO.test(XO.text) && (TO.push(uO), uO = []));
      TO.push(uO);
      const EO = [];
      let jK = 0;
      for (const XO of TO) {
        var YO, wO;
        const OO = null !== (YO = null === (wO = XO.at(-1)) || void 0 === wO ? void 0 : wO.text) && void 0 !== YO ? YO : "",
          KO = LO.test(OO),
          pO = QO.test(OO),
          bK = XO.map((OO => "word" === OO.kind ? IO(OO.text) : 1)),
          AO = bK.findLastIndex((OO => OO > 0));
        for (const [LO, QO] of XO.entries()) {
          const OO = "word" === QO.kind,
            XO = bK[LO];
          QO.delayMs = jK;
          for (let bK = 0; oO && bK < XO; bK++) {
            const {
              intonation: eO
            } = oO;
            let lO = AO > 0 ? -eO.declineSemitones * (LO / AO) : 0;
            lO += NO(`${yK(QO.text)}|${bK}`) * eO.variationSemitones;
            const VO = Math.min(1, eO.variationSemitones);
            let zK = oO.glideSemitones,
              fO = 1;
            pO && (lO += eO.exclaimLiftSemitones, fO *= vK), KO && LO === AO && (lO += eO.questionRiseSemitones * (XO > 1 ? .5 + .5 * bK / (XO - 1) : 1), bK === XO - 1 && (zK = Math.abs(zK) + eO.questionRiseSemitones / 2)), OO && gK(QO.text) && (lO += hO * VO, fO *= CO), XO > 1 && 0 === bK && (lO += MO * VO, fO *= DO), EO.push({
              atMs: jK + bK * FO,
              semitones: lO,
              glideSemitones: zK,
              durationMs: bK < XO - 1 ? Math.min(oO.durationMs, FO * aK) : oO.durationMs,
              level: fO
            })
          }
          jK += XO * FO + (VO.test(QO.text) ? lO : zK.test(QO.text) ? eO : 0)
        }
      }
      return {
        pieces: AO.map((OO => "space" === OO.kind ? OO : "icon" === OO.kind ? {
          kind: "icon",
          icon: OO.text,
          delayMs: OO.delayMs
        } : {
          kind: "word",
          text: OO.text,
          delayMs: OO.delayMs
        })),
        blips: EO
      }
    }
    var EO = pO(1051),
      jK = pO(1109),
      YO = pO(1558);

    function wO(OO) {
      if ("string" === typeof OO) return OO;
      const KO = jK.f.get().getCurrentLanguageCode();
      return (0, EO.s)(KO, OO.translationKey, (0, EO.q)(OO.params, YO.c.shown))
    }

    function iK(OO) {
      const KO = void 0 === OO.voice ? null : (0, XO.m)(OO.voice),
        pO = KO && (0, XO.l)(KO);
      return {
        plan: uO(wO(OO.line), pO),
        synth: pO
      }
    }

    function rK(OO) {
      const KO = [];
      let pO = [];
      for (const [bK, eO] of OO.entries()) {
        var XO;
        "space" === eO.kind && (" " !== eO.text || "icon" !== (null === (XO = OO[bK + 1]) || void 0 === XO ? void 0 : XO.kind)) ? (pO.length > 0 && KO.push(pO), KO.push([eO]), pO = []) : pO.push(eO)
      }
      return pO.length > 0 && KO.push(pO), KO
    }
  },
  3984: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => DO,
      g: () => MO
    });
    var XO = pO(3988),
      bK = pO(22);
    const eO = .25,
      lO = .85,
      vK = .02,
      CO = .01;

    function hO(OO, KO, pO, XO, bK, eO, vK) {
      const {
        waveform: CO,
        pitchHz: hO,
        attackMs: DO,
        releaseMs: MO,
        lowpassHz: aK
      } = pO, oO = bK + XO.durationMs / 1e3, FO = hO * 2 ** (XO.semitones / 12), VO = OO.createOscillator();
      VO.type = CO, VO.frequency.setValueAtTime(FO, bK), VO.frequency.exponentialRampToValueAtTime(FO * 2 ** (XO.glideSemitones / 12), oO);
      const LO = bK + Math.min(DO, XO.durationMs) / 1e3,
        QO = OO.createGain();
      QO.gain.setValueAtTime(0, bK), QO.gain.linearRampToValueAtTime(eO, LO), QO.gain.linearRampToValueAtTime(eO * lO, Math.max(LO, oO - MO / 1e3)), QO.gain.linearRampToValueAtTime(0, oO);
      const zK = [VO];
      if (null !== aK) {
        const KO = OO.createBiquadFilter();
        KO.type = "lowpass", KO.frequency.value = aK, zK.push(KO)
      }
      zK.push(QO, KO);
      for (let lO = 1; lO < zK.length; lO++) zK[lO - 1].connect(zK[lO]);
      return VO.onended = () => {
        for (const OO of zK.slice(0, -1)) OO.disconnect();
        vK()
      }, VO.start(bK), VO.stop(oO), VO
    }

    function DO(OO, KO, pO, XO, bK, lO) {
      if (0 === XO.length) return lO(), () => {};
      const DO = eO * pO.volume * bK,
        MO = OO.createGain();
      MO.connect(KO);
      const aK = OO.currentTime + vK,
        oO = new Set;
      for (const eO of XO) {
        const KO = hO(OO, MO, pO, eO, aK + eO.atMs / 1e3, DO * eO.level, (() => {
          oO.delete(KO), 0 === oO.size && (MO.disconnect(), lO())
        }));
        oO.add(KO)
      }
      return () => {
        const KO = OO.currentTime;
        MO.gain.setTargetAtTime(0, KO, CO);
        for (const OO of oO) try {
          OO.stop(KO + 5 * CO)
        } catch {}
      }
    }

    function MO(OO, KO) {
      var pO;
      const eO = XO.b.ctx,
        lO = XO.b.masterGain;
      if (!eO || !lO || !bK.d.get("soundOnFromAd")) return () => {};
      const vK = XO.b;
      return null === (pO = vK._autoResume) || void 0 === pO || pO.call(vK), DO(eO, lO, OO, KO, bK.d.get("soundVolume"), (() => {
        var OO;
        null === (OO = vK._autoSuspend) || void 0 === OO || OO.call(vK)
      }))
    }
  },
  37495: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      closeClientGame: () => PO,
      createDefaultClientPlugins: () => rK
    });
    var XO = pO(256);

    function bK() {
      let OO;
      return {
        onCreate(KO) {
          OO = KO
        },
        altVetoBlocks: ["Iron Chest"],
        onPlayerAttemptAltAction(KO, pO, bK, eO, lO, vK) {
          var CO, hO;
          if ("Iron Chest" !== OO.getMetaInfo(lO).rootName) return;
          if (!OO.hasEffect(KO, "Thief")) return;
          const DO = OO.getBlockData(pO, bK, eO);
          return OO.getPlayerDbId(KO) !== (null === DO || void 0 === DO || null === (CO = DO.persisted) || void 0 === CO || null === (hO = CO.shared) || void 0 === hO ? void 0 : hO.ownerDbId) ? (OO.sendMessage(KO, [{
            str: {
              translationKey: "ironChest:thievesCannotOpen"
            },
            style: {
              color: XO.J.redUiText
            }
          }]), "preventAction") : void 0
        }
      }
    }
    var eO = pO(3520),
      lO = pO(1098);
    const vK = 8.4,
      CO = 1e-4,
      hO = .15,
      DO = .04,
      MO = [.12, .04, .12],
      aK = 26,
      oO = {
        texture: "fishingFishSilhouette",
        mipmaps: !1,
        YO: 1,
        minLifeTime: CO,
        maxLifeTime: CO,
        minSize: .55,
        maxSize: .55,
        minEmitPower: 0,
        maxEmitPower: 0,
        emitRate: 0,
        colorGradients: [{
          timeFraction: 0,
          minColor: [255, 255, 255, 1]
        }, {
          timeFraction: 1,
          minColor: [0, 0, 0, 1]
        }],
        blendMode: eO.d.Standard
      },
      FO = {
        texture: "bubble",
        mipmaps: !1,
        YO: 96,
        minLifeTime: .3,
        maxLifeTime: .65,
        minSize: .08,
        maxSize: .19,
        minEmitPower: .2,
        maxEmitPower: .55,
        emitRate: aK,
        gravity: [0, .3, 0],
        dir1: [-.3, .3, -.3],
        dir2: [.3, .7, .3],
        colorGradients: [{
          timeFraction: 0,
          minColor: [216.75, 242.25, 255, 1]
        }, {
          timeFraction: .4,
          minColor: [216.75, 242.25, 255, .9]
        }, {
          timeFraction: 1,
          minColor: [178.5, 229.5, 255, 0]
        }],
        blendMode: eO.d.Standard
      },
      VO = [0, 0, 0],
      LO = [0, 0, 0];

    function QO(OO) {
      const KO = new Map;
      let pO = null;

      function XO(OO) {
        var KO, pO;
        null === (KO = OO.bubbles) || void 0 === KO || KO.stop(), null === (pO = OO.fish) || void 0 === pO || pO.stop()
      }

      function bK(pO) {
        if (!pO.readDrawnPosition(OO, LO)) {
          for (const OO of KO.values()) {
            var XO;
            null === (XO = OO.bubbles) || void 0 === XO || XO.setEmitRate(0)
          }
          return
        }
        const bK = performance.now();
        for (const [OO, lO] of KO) {
          var eO;
          if (null === (eO = lO.bubbles) || void 0 === eO || eO.setEmitRate(0), !pO.readDrawnPosition(OO, VO)) continue;
          if (!((VO[0] - LO[0]) ** 2 + (VO[1] - LO[1]) ** 2 + (VO[2] - LO[2]) ** 2 < 900)) continue;
          const KO = Math.max(0, lO.biteAt - bK),
            XO = lO.approachDurationMs > 0 ? Math.min(1, 1 - KO / lO.approachDurationMs) : 1,
            CO = (lO.approachDurationMs - KO) / 1e3,
            QO = lO.phase + .25 * Math.sin(1.7 * CO + lO.phase),
            zK = Math.min(lO.approachDurationMs / 3e3 * 2.8, vK) * (1 - XO) * (1 + .15 * Math.sin(2.1 * CO + lO.phase)),
            AO = Math.min(1, 4 * (1 - XO)),
            fO = (.45 * Math.sin(4.1 * CO + lO.phase) + .18 * Math.sin(9.7 * CO + 2 * lO.phase)) * AO,
            dO = VO[0] + Math.cos(QO) * zK - Math.sin(QO) * fO,
            TO = Math.ceil(lO.surfaceY),
            NO = VO[2] + Math.sin(QO) * zK + Math.cos(QO) * fO,
            {
              fishAt: IO,
              bubblesAt: yK
            } = lO;
          IO[0] = yK[0] = dO, IO[1] = TO + hO, yK[1] = TO + DO, IO[2] = yK[2] = NO, lO.fish ??= pO.createParticles(oO, {
            pos: IO
          }), lO.fish.moveTo(IO), lO.fish.emit(1), lO.bubbles ??= pO.createParticles(FO, {
            pos: yK,
            half: MO
          }), lO.bubbles.moveTo(yK), lO.bubbles.setEmitRate(aK + 32 * (.5 + .5 * Math.sin(9 * CO + lO.phase)) ** 4 + 13 * XO)
        }
      }
      return {
        onCreate(OO) {
          pO = OO
        },
        onAfterRender() {
          pO && bK(pO)
        },
        onClose() {
          for (const OO of KO.values()) XO(OO);
          KO.clear(), pO = null
        },
        onReceivedMessageFromServer(OO, pO) {
          if (OO !== lO.C) return;
          const {
            hookId: bK,
            waiting: eO
          } = pO;
          if (eO) KO.has(bK) || KO.set(bK, {
            bubbles: null,
            fish: null,
            fishAt: [0, 0, 0],
            bubblesAt: [0, 0, 0],
            biteAt: performance.now() + eO.remainingMs,
            approachDurationMs: eO.durationMs,
            surfaceY: eO.surfaceY,
            phase: Math.random() * Math.PI * 2
          });
          else {
            const OO = KO.get(bK);
            OO && XO(OO), KO.delete(bK)
          }
        }
      }
    }
    var zK = pO(3984),
      AO = pO(3972);

    function fO(OO) {
      let KO, pO = null,
        XO = null;
      const bK = () => {
        var OO;
        null === (OO = XO) || void 0 === OO || OO(), XO = null
      };
      return {
        onCreate(XO) {
          KO = XO, pO = KO.getClientOption(OO, "dialogue")
        },
        onAfterRender() {
          if (!KO) return;
          const eO = KO.getClientOption(OO, "dialogue");
          if (eO === pO) return;
          if (pO = eO, bK(), !eO || !1 === eO.animateIn) return;
          const {
            plan: lO,
            synth: vK
          } = (0, AO.g)(eO);
          vK && (XO = (0, zK.g)(vK, lO.blips))
        },
        onClose: bK
      }
    }
    var dO = pO(37499);
    const TO = [
        [-.3125, -.25],
        [.3125, -.25],
        [.3125, .25],
        [-.3125, .25]
      ],
      NO = [0, 1 / 3, 1, 1 / 3, 1, 0, 0, 0],
      IO = [0, 1, 2, 0, 2, 3];

    function yK(OO, KO, pO) {
      var XO;
      let [bK, eO, lO] = KO;
      if (OO.hasPackModel("Furnace")) return null;
      const vK = ((null !== (XO = OO.getMetaInfo(pO).rot) && void 0 !== XO ? XO : 1) - 1) * Math.PI / 2,
        CO = Math.PI + vK,
        hO = Math.cos(CO),
        DO = Math.sin(CO),
        MO = [];
      for (const [FO, VO] of TO) MO.push(FO * hO, VO, -FO * DO);
      const aK = {
          positions: MO,
          indices: IO,
          uvs: NO
        },
        oO = [bK + .5 + .51 * Math.sin(vK), eO + .375, lO + .5 + .51 * Math.cos(vK)];
      return OO.createGameMesh(aK, {
        kind: "furnaceFire"
      }, oO)
    }

    function gK(OO) {
      return Math.floor(OO / 200) % 3
    }

    function uO(OO, KO, pO) {
      OO.setGameMesh(KO, {
        uvOffset: [0, pO / 3]
      })
    }
    const EO = [.12, .025, .12],
      jK = [{
        style: {
          colours: [
            [176, 176, 182],
            [128, 128, 134]
          ],
          alpha: .6,
          size: [.18, .32],
          life: [1.6, 2.6],
          power: [.5, .8],
          lift: .12,
          spread: .12,
          count: 6,
          blendMode: eO.d.Standard,
          soft: !0
        },
        perSecond: 7
      }, {
        style: {
          colours: [
            [255, 190, 80],
            [255, 110, 35]
          ],
          alpha: 1,
          size: [.04, .07],
          life: [.6, 1.1],
          power: [1, 1.8],
          lift: -.6,
          spread: .35,
          count: 10,
          blendMode: eO.d.Add,
          soft: !1
        },
        perSecond: 6
      }];
    class YO {
      constructor() {
        this.puffers = null, this.smokes = [], this.renderFrame = 0, this.shownFireFrame = -1, this.centre = [0, 0, 0]
      }
      start(OO, KO) {
        const pO = OO.getBlockId(KO[0], KO[1], KO[2]);
        if ("Furnace" !== OO.getMetaInfo(pO).rootName) return;
        const XO = performance.now();
        let bK = this.smokes.find((OO => OO.pos[0] === KO[0] && OO.pos[1] === KO[1] && OO.pos[2] === KO[2] && OO.yl === pO));
        if (bK || (bK = {
            pos: [KO[0], KO[1], KO[2]],
            yl: pO,
            endMs: XO,
            lastBurstMs: -1 / 0,
            pending: new Array(jK.length).fill(0),
            fire: yK(OO, KO, pO)
          }, this.smokes.push(bK), null !== bK.fire && (uO(OO, bK.fire, gK(XO)), this.shownFireFrame = -1)), bK.endMs = XO + 6e3, this.smokes.length > 4) {
          const KO = this.smokes.reduce(((OO, KO) => KO.endMs < OO.endMs ? KO : OO));
          wO(OO, KO), this.smokes.splice(this.smokes.indexOf(KO), 1)
        }
        XO - bK.lastBurstMs >= 300 && (bK.lastBurstMs = XO, jK.forEach(((OO, KO) => {
          bK.pending[KO] += OO.style.count
        })))
      }
      onAfterRender(OO, KO) {
        if (0 === this.smokes.length) return;
        this.renderFrame++;
        const pO = performance.now();
        this.smokes = this.smokes.filter((KO => {
          const [XO, bK, eO] = KO.pos, lO = pO < KO.endMs && OO.getBlockId(XO, bK, eO) === KO.yl;
          return lO || wO(OO, KO), lO
        }));
        const XO = gK(pO);
        if (XO !== this.shownFireFrame) {
          this.shownFireFrame = XO;
          for (const KO of this.smokes) null !== KO.fire && uO(OO, KO.fire, XO)
        }
        if (!OO.particlesEnabled()) {
          for (const OO of this.smokes) OO.pending.fill(0);
          return
        }
        const bK = Math.min(KO, 250) / 1e3;
        for (const eO of this.smokes) {
          const [KO, XO, lO] = eO.pos;
          if (0 !== OO.getBlockId(KO, XO + 1, lO)) {
            eO.pending.fill(0);
            continue
          }
          const vK = (eO.endMs - pO) / 6e3,
            CO = this.centre;
          CO[0] = KO + .5, CO[1] = XO + 1.275, CO[2] = lO + .5, jK.forEach(((KO, pO) => {
            eO.pending[pO] += KO.perSecond * vK * bK;
            const XO = Math.floor(eO.pending[pO]);
            XO > 0 && this.emit(OO, pO, CO, XO) && (eO.pending[pO] -= XO)
          }))
        }
      }
      dispose(OO) {
        for (const pO of this.smokes) wO(OO, pO);
        this.smokes = [];
        for (const pO of null !== (KO = this.puffers) && void 0 !== KO ? KO : []) {
          var KO;
          pO.dispose()
        }
        this.puffers = null
      }
      emit(OO, KO, pO, XO) {
        return this.puffers ??= jK.map((OO => {
          let {
            style: KO,
            perSecond: pO
          } = OO;
          const XO = (KO.count / .3 + pO) * KO.life[1];
          return new dO.c(KO, Math.ceil(4 * XO), EO)
        })), this.puffers[KO].emit(OO, pO, this.renderFrame, XO)
      }
    }

    function wO(OO, KO) {
      null !== KO.fire && (OO.disposeGameMesh(KO.fire), KO.fire = null)
    }

    function iK() {
      let OO;
      const KO = new YO;
      return {
        onCreate(KO) {
          OO = KO
        },
        onReceivedMessageFromServer(pO, XO) {
          pO === lO.D && KO.start(OO, XO)
        },
        onAfterRender(pO) {
          KO.onAfterRender(OO, pO)
        },
        onClose() {
          KO.dispose(OO)
        }
      }
    }

    function rK(OO, KO, pO, XO) {
      return {
        dialogue: fO(XO.localPlayerId),
        fishing: QO(XO.localPlayerId),
        furnaceSmoke: iK(),
        ironChest: bK()
      }
    }

    function PO(OO, KO) {
      for (const bK of [OO, ...null !== KO && void 0 !== KO ? KO : []]) try {
        var pO;
        null === bK || void 0 === bK || null === (pO = bK.onClose) || void 0 === pO || pO.call(bK)
      } catch (XO) {
        console.error("Error in client onClose callback", XO)
      }
    }
  },
  37499: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO,
      c: () => eO
    });
    const XO = 1 / .6,
      bK = {
        kind: "smokePuff"
      };
    class eO {
      constructor(OO, KO, pO) {
        this.style = OO, this.YO = KO, this.half = pO, this.particles = null, this.lastFrame = -1
      }
      emit(OO, KO, pO) {
        let eO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : this.style.count;
        return pO !== this.lastFrame && (this.lastFrame = pO, this.particles || (this.particles = OO.createParticles(function(OO, KO) {
          const [
            [pO, eO, lO],
            [vK, CO, hO]
          ] = OO.colours;
          return {
            texture: OO.soft ? bK : "square_particle",
            YO: KO,
            minLifeTime: OO.life[0] / XO,
            maxLifeTime: OO.life[1] / XO,
            minEmitPower: OO.power[0] * XO,
            maxEmitPower: OO.power[1] * XO,
            minSize: OO.size[0],
            maxSize: OO.size[1],
            emitRate: 0,
            gravity: [0, OO.lift * XO * XO, 0],
            dir1: [-OO.spread, 1, -OO.spread],
            dir2: [OO.spread, 1, OO.spread],
            colorGradients: [{
              timeFraction: 0,
              minColor: [pO, eO, lO, OO.alpha],
              maxColor: [vK, CO, hO, OO.alpha]
            }, {
              timeFraction: 1,
              minColor: [pO, eO, lO, 0],
              maxColor: [vK, CO, hO, 0]
            }],
            blendMode: OO.blendMode
          }
        }(this.style, this.YO), {
          pos: KO,
          half: this.half
        })), this.particles.moveTo(KO, this.half), this.particles.emit(eO), !0)
      }
      dispose() {
        var OO;
        null === (OO = this.particles) || void 0 === OO || OO.stop(), this.particles = null
      }
    }
  },
  3977: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      g: () => XO,
      k: () => eO,
      l: () => CO,
      m: () => lO
    });
    const XO = ["sine", "triangle", "square", "sawtooth"],
      bK = 55,
      eO = {
        soft: {
          waveform: "sine",
          pitchHz: 300,
          glideSemitones: -.5,
          durationMs: 80,
          attackMs: 6,
          releaseMs: 18,
          lowpassHz: null,
          volume: .6,
          intonation: {
            variationSemitones: 1.2,
            declineSemitones: 1.5,
            questionRiseSemitones: 3.5,
            exclaimLiftSemitones: 1.5
          },
          syllableMs: 60
        },
        regular: {
          waveform: "triangle",
          pitchHz: 195,
          glideSemitones: -.6,
          durationMs: 70,
          attackMs: 2,
          releaseMs: 12,
          lowpassHz: null,
          volume: 1,
          intonation: {
            variationSemitones: 1.5,
            declineSemitones: 2,
            questionRiseSemitones: 4,
            exclaimLiftSemitones: 2
          },
          syllableMs: 52
        },
        dark: {
          waveform: "sawtooth",
          pitchHz: 80,
          glideSemitones: -.6,
          durationMs: 85,
          attackMs: 6,
          releaseMs: 16,
          lowpassHz: 420,
          volume: 1.05,
          intonation: {
            variationSemitones: 1,
            declineSemitones: 3.5,
            questionRiseSemitones: 2.5,
            exclaimLiftSemitones: 1
          },
          syllableMs: 64
        },
        "high-pitched": {
          waveform: "triangle",
          pitchHz: 300,
          glideSemitones: -.8,
          durationMs: 55,
          attackMs: 2,
          releaseMs: 10,
          lowpassHz: null,
          volume: .8,
          intonation: {
            variationSemitones: 2.2,
            declineSemitones: 2,
            questionRiseSemitones: 5,
            exclaimLiftSemitones: 3
          },
          syllableMs: 44
        },
        gruff: {
          waveform: "sawtooth",
          pitchHz: 105,
          glideSemitones: -.8,
          durationMs: 75,
          attackMs: 4,
          releaseMs: 14,
          lowpassHz: 900,
          volume: .85,
          intonation: {
            variationSemitones: 1.2,
            declineSemitones: 3,
            questionRiseSemitones: 3,
            exclaimLiftSemitones: 2
          },
          syllableMs: 58
        },
        lively: {
          waveform: "square",
          pitchHz: 230,
          glideSemitones: .6,
          durationMs: 55,
          attackMs: 2,
          releaseMs: 10,
          lowpassHz: 2400,
          volume: .5,
          intonation: {
            variationSemitones: 2.6,
            declineSemitones: 1.5,
            questionRiseSemitones: 5,
            exclaimLiftSemitones: 3.5
          },
          syllableMs: 44
        },
        posh: {
          waveform: "triangle",
          pitchHz: 175,
          glideSemitones: 1.2,
          durationMs: 90,
          attackMs: 6,
          releaseMs: 20,
          lowpassHz: 2e3,
          volume: 1,
          intonation: {
            variationSemitones: 2,
            declineSemitones: 4,
            questionRiseSemitones: 5,
            exclaimLiftSemitones: 2.5
          },
          syllableMs: 60
        },
        mechanical: {
          waveform: "square",
          pitchHz: 140,
          glideSemitones: 0,
          durationMs: 60,
          attackMs: 0,
          releaseMs: 4,
          lowpassHz: 1400,
          volume: .55,
          intonation: {
            variationSemitones: 0,
            declineSemitones: 0,
            questionRiseSemitones: 0,
            exclaimLiftSemitones: 0
          },
          syllableMs: 62
        }
      };

    function lO(OO) {
      return "string" !== typeof OO ? OO : Object.hasOwn(eO, OO) ? eO[OO] : null
    }

    function vK(OO, KO, pO) {
      return Math.min(pO, Math.max(KO, OO))
    }

    function CO(OO) {
      const KO = vK(OO.durationMs, 10, 500),
        pO = vK(OO.attackMs, 0, KO),
        {
          intonation: bK
        } = OO;
      return {
        waveform: XO.includes(OO.waveform) ? OO.waveform : "sine",
        pitchHz: vK(OO.pitchHz, 20, 4e3),
        glideSemitones: vK(OO.glideSemitones, -24, 24),
        durationMs: KO,
        attackMs: pO,
        releaseMs: vK(OO.releaseMs, 0, KO - pO),
        lowpassHz: null === OO.lowpassHz ? null : vK(OO.lowpassHz, 20, 2e4),
        volume: vK(OO.volume, 0, 2),
        intonation: {
          variationSemitones: vK(bK.variationSemitones, 0, 6),
          declineSemitones: vK(bK.declineSemitones, 0, 12),
          questionRiseSemitones: vK(bK.questionRiseSemitones, 0, 12),
          exclaimLiftSemitones: vK(bK.exclaimLiftSemitones, 0, 12)
        },
        syllableMs: vK(OO.syllableMs, 25, 200)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);