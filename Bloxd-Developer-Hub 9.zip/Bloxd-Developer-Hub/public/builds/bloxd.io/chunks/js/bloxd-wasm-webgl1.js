export const id = 7;
export const ids = [7];
export const modules = {
  41292: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_webgl1_bg.e5a6184daf6e6427d4d4.wasm"
  },
  41287: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      bloxdWasmWebgl1: () => EK
    });
    var XO = {};
    pO.r(XO), pO.d(XO, {
      Gl: () => bK,
      kaO: () => eO,
      Renderer: () => lO,
      aK: () => vK,
      default: () => uK,
      initSync: () => gp,
      oO: () => CO,
      UMO: () => hO,
      FO: () => DO,
      VO: () => MO,
      LO: () => aK,
      QO: () => oO,
      zK: () => FO,
      fO: () => VO,
      dO: () => LO,
      OaO: () => QO,
      yK: () => zK,
      KaO: () => AO,
      paO: () => fO,
      taO: () => dO,
      XaO: () => TO,
      boO: () => NO,
      eaO: () => IO,
      laO: () => yK,
      voO: () => gK,
      uO: () => uO,
      EO: () => EO
    });
    class bK {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, PO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        NK.EMLI(OO, 0)
      }
      static CaO() {
        return NK.DeUf() >>> 0
      }
      haO() {
        return NK.jTSo(this.__wbg_ptr)
      }
      KMO() {
        return NK.s9X0(this.__wbg_ptr) >>> 0
      }
      MaO(OO, KO, pO) {
        return NK.Cx6P(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      sK(OO, KO, pO) {
        return NK.LEpp(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      aoO() {
        return NK.eNf8(this.__wbg_ptr) >>> 0
      }
      XMO(OO, KO, pO, XO, bK, eO, lO) {
        return NK.AJFN(this.__wbg_ptr, OO, KO, pO, XO, bK, eO, lO)
      }
      oaO(OO, KO, pO) {
        return NK.zrML(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      FaO() {
        return NK.ays1(this.__wbg_ptr) >>> 0
      }
      VaO() {
        return NK.j3FS(this.__wbg_ptr) >>> 0
      }
      QaO() {
        return NK.clvh(this.__wbg_ptr) >>> 0
      }
      craft(OO, KO, pO) {
        return NK.bI1Y(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      hMO(OO, KO, pO) {
        return NK.fTpa(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      baO() {
        return NK.DaMG(this.__wbg_ptr) >>> 0
      }
      eMO(OO) {
        return NK.vZ1J(this.__wbg_ptr, OO) >>> 0
      }
      lMO(OO, KO, pO, XO, bK, eO) {
        return NK.Vbb2(this.__wbg_ptr, OO, KO, pO, XO, bK, eO) >>> 0
      }
      pMO() {
        return NK.lG07(this.__wbg_ptr) >>> 0
      }
      zoO() {
        return NK.UXfG(this.__wbg_ptr) >>> 0
      }
      AaO(OO) {
        return NK.LhiV(this.__wbg_ptr, OO) >>> 0
      }
      MMO(OO) {
        return NK.s33h(this.__wbg_ptr, OO) >>> 0
      }
      daO(OO) {
        return NK.IlIO(this.__wbg_ptr, OO) >>> 0
      }
      TaO(OO) {
        return NK.rsGZ(this.__wbg_ptr, OO) >>> 0
      }
      frame(OO, KO, pO, XO, bK, eO) {
        return NK.EMo7(this.__wbg_ptr, OO, KO, pO, XO, bK, eO) >>> 0
      }
      IaO(OO) {
        return 0 !== NK.xFCO(this.__wbg_ptr, OO)
      }
      yoO(OO, KO) {
        return NK.XNTz(this.__wbg_ptr, OO, KO) >>> 0
      }
      goO(OO) {
        return NK.BqqY(this.__wbg_ptr, OO) >>> 0
      }
      yX() {
        return NK.twd3(this.__wbg_ptr) >>> 0
      }
      uaO() {
        return NK.VnXP(this.__wbg_ptr) >>> 0
      }
      ZO() {
        return NK.e1mJ(this.__wbg_ptr) >>> 0
      }
      EaO(OO, KO, pO, XO, bK) {
        return NK.lVoY(this.__wbg_ptr, OO, KO, pO, XO, bK) >>> 0
      }
      joO(OO, KO, pO) {
        return NK.coDJ(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      YaO(OO, KO, pO, XO) {
        return NK.Orep(this.__wbg_ptr, OO, KO, pO, XO) >>> 0
      }
      waO(OO, KO, pO) {
        return NK.a1Lp(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      ioO(OO, KO) {
        return NK.A8d5(this.__wbg_ptr, OO, KO) >>> 0
      }
      DMO(OO) {
        return NK.H6x8(this.__wbg_ptr, OO) >>> 0
      }
      FE() {
        return NK.XVlB(this.__wbg_ptr) >>> 0
      }
      roO() {
        return NK.eXTg(this.__wbg_ptr) >>> 0
      }
      PaO() {
        return NK.apIO(this.__wbg_ptr) >>> 0
      }
      moO() {
        return NK.soNH(this.__wbg_ptr) >>> 0
      }
      constructor(OO, KO) {
        const pO = NK.iHVN(OO, KO);
        return this.__wbg_ptr = pO, PO.register(this, this.__wbg_ptr, this), this
      }
      saO(OO) {
        return NK.OVSx(this.__wbg_ptr, OO) >>> 0
      }
      Ul() {
        return NK.eAin(this.__wbg_ptr) >>> 0
      }
      EMO(OO, KO) {
        return NK.LVBn(this.__wbg_ptr, OO, KO) >>> 0
      }
      NMO(OO) {
        return NK.UM0x(this.__wbg_ptr, OO) >>> 0
      }
      HaO(OO, KO, pO, XO) {
        return NK.H2dB(this.__wbg_ptr, OO, KO, pO, XO) >>> 0
      }
      iaO(OO) {
        return NK.cmbj(this.__wbg_ptr, OO) >>> 0
      }
      LMO() {
        NK.jvMX(this.__wbg_ptr)
      }
      sMO(OO) {
        NK.qxsS(this.__wbg_ptr, OO)
      }
      maO(OO) {
        return NK.GLNz(this.__wbg_ptr, OO)
      }
      VMO() {
        return NK.JjYP(this.__wbg_ptr) >>> 0
      }
      qv() {
        return NK.PWPa(this.__wbg_ptr) >>> 0
      }
      YMO() {
        return NK.LD3E(this.__wbg_ptr) >>> 0
      }
      LaO(OO) {
        return NK.Rz18(this.__wbg_ptr, OO) >>> 0
      }
      RaO(OO) {
        return NK.RvcH(this.__wbg_ptr, OO) >>> 0
      }
      SaO(OO) {
        return NK.v6PG(this.__wbg_ptr, OO) >>> 0
      }
      JaO(OO) {
        return NK.emD4(this.__wbg_ptr, OO) >>> 0
      }
      salvage(OO, KO, pO) {
        return NK.V80s(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      oMO(OO) {
        return NK.F6F9(this.__wbg_ptr, OO) >>> 0
      }
      OMO() {
        return NK.kAxO(this.__wbg_ptr) >>> 0
      }
      coO(OO) {
        return NK.Iz2z(this.__wbg_ptr, OO) >>> 0
      }
      BaO(OO) {
        NK.LvU1(this.__wbg_ptr, OO)
      }
      ZaO(OO) {
        return 0 !== NK.Eg2t(this.__wbg_ptr, HO(OO))
      }
      Cp(OO, KO, pO, XO) {
        return NK.HNoD(this.__wbg_ptr, OO, KO, pO, XO) >>> 0
      }
      qoO(OO, KO, pO) {
        const XO = VK(OO, NK.fDH5, NK.ruFu),
          bK = IK,
          eO = ap(KO, NK.fDH5),
          lO = IK,
          vK = function(OO, KO) {
            const pO = KO(8 * OO.length, 8) >>> 0;
            return UO().set(OO, pO / 8), IK = OO.length, pO
          }(pO, NK.fDH5),
          CO = IK;
        return 0 !== NK.oR0t(this.__wbg_ptr, XO, bK, eO, lO, vK, CO)
      }
      xoO(OO) {
        NK.NO6A(this.__wbg_ptr, OO)
      }
      naO(OO, KO) {
        return 0 !== NK.vdgr(this.__wbg_ptr, OO, KO)
      }
      WaO(OO) {
        return NK.NIPH(this.__wbg_ptr, OO) >>> 0
      }
      NaO(OO) {
        NK.CQgq(this.__wbg_ptr, HO(OO))
      }
      toO(OO) {
        NK.Ghug(this.__wbg_ptr, OO)
      }
      koO(OO) {
        NK.j1zP(this.__wbg_ptr, OO)
      }
      CMO(OO, KO, pO) {
        return NK.mkOL(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      FMO(OO) {
        return NK.v2jz(this.__wbg_ptr, OO) >>> 0
      }
      UaO(OO) {
        NK.lkuO(this.__wbg_ptr, OO)
      }
      OoO(OO) {
        RO(OO, lO);
        var KO = OO.__destroy_into_raw();
        NK.n37H(this.__wbg_ptr, KO)
      }
      GDO(OO, KO, pO, XO, bK, eO) {
        var lO = DK(OO) ? 0 : oK(OO, NK.fDH5),
          vK = IK;
        const CO = oK(KO, NK.fDH5),
          hO = IK,
          DO = FK(pO, NK.fDH5),
          MO = IK,
          aK = ap(XO, NK.fDH5),
          oO = IK;
        return 0 !== NK.hzZ6(this.__wbg_ptr, lO, vK, CO, hO, DO, MO, aK, oO, bK, eO)
      }
      poO(OO, KO, pO, XO, bK) {
        var eO = DK(bK) ? 0 : oK(bK, NK.fDH5),
          lO = IK;
        NK.dQDB(this.__wbg_ptr, OO, KO, pO, XO, eO, lO)
      }
      XoO(OO, KO, pO) {
        const XO = FK(OO, NK.fDH5),
          bK = IK,
          eO = ap(KO, NK.fDH5),
          lO = IK,
          vK = FK(pO, NK.fDH5),
          CO = IK;
        return 0 !== NK.Y40r(this.__wbg_ptr, XO, bK, eO, lO, vK, CO)
      }
      bFO(OO) {
        const KO = VK(OO, NK.fDH5, NK.ruFu),
          pO = IK;
        return 0 !== NK.Hgh0(this.__wbg_ptr, KO, pO)
      }
      eoO(OO) {
        return NK.qOFW(this.__wbg_ptr, OO) >>> 0
      }
      loK() {
        return NK.lPBh(this.__wbg_ptr) >>> 0
      }
      vFO() {
        const OO = NK.DAxZ(this.__wbg_ptr);
        var KO = qK(OO[0], OO[1]).slice();
        return NK.IQAV(OO[0], 4 * OO[1], 4), KO
      }
      hoO() {
        const OO = NK.qZPt(this.__wbg_ptr);
        var KO = BO(OO[0], OO[1]).slice();
        return NK.IQAV(OO[0], 8 * OO[1], 8), KO
      }
      DoO() {
        const OO = NK.a8HI(this.__wbg_ptr);
        var KO = GO(OO[0], OO[1]);
        return NK.IQAV(OO[0], 4 * OO[1], 4), KO
      }
      MoO(OO, KO, pO, XO, bK) {
        return NK.sNNZ(this.__wbg_ptr, OO, KO, pO, XO, bK) >>> 0
      }
      aFO() {
        const OO = NK.f9yq(this.__wbg_ptr);
        var KO = GO(OO[0], OO[1]);
        return NK.IQAV(OO[0], 4 * OO[1], 4), KO
      }
      ooO() {
        return NK.VOnA(this.__wbg_ptr) >>> 0
      }
      VoO() {
        return NK.fzJD(this.__wbg_ptr) >>> 0
      }
    }
    Symbol.dispose && (bK.prototype[Symbol.dispose] = bK.prototype.free);
    class eO {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, mK.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        NK.GSLd(OO, 0)
      }
      attach(OO) {
        RO(OO, bK);
        return 0 !== NK.oUYM(this.__wbg_ptr, OO.__wbg_ptr)
      }
      attached() {
        return 0 !== NK.V8rZ(this.__wbg_ptr)
      }
      close(OO) {
        const KO = NK.WEEG(this.__wbg_ptr, OO);
        var pO = xK(KO[0], KO[1]).slice();
        return NK.IQAV(KO[0], 1 * KO[1], 1), pO
      }
      detach() {
        NK.qoqC(this.__wbg_ptr)
      }
      LoO() {
        return NK.XwMu(this.__wbg_ptr) >>> 0
      }
      QoO() {
        return NK.ppuB(this.__wbg_ptr) >>> 0
      }
      frame(OO) {
        return NK.JQg0(this.__wbg_ptr, OO) >>> 0
      }
      zFO(OO, KO, pO, XO) {
        const bK = oK(XO, NK.fDH5),
          eO = IK;
        return NK.EvMk(this.__wbg_ptr, OO, KO, pO, bK, eO)
      }
      AoO() {
        return 0 !== NK.TgTr(this.__wbg_ptr)
      }
      foO(OO, KO) {
        const pO = oK(KO, NK.fDH5),
          XO = IK;
        NK.AhfC(this.__wbg_ptr, OO, pO, XO)
      }
      constructor() {
        const OO = NK.L6fX();
        return this.__wbg_ptr = OO, mK.register(this, this.__wbg_ptr, this), this
      }
      open(OO, KO, pO, XO) {
        return 0 !== NK.NBdm(this.__wbg_ptr, OO, KO, pO, XO)
      }
      orbit(OO) {
        const KO = NK.x1ux(this.__wbg_ptr, OO);
        var pO = BO(KO[0], KO[1]).slice();
        return NK.IQAV(KO[0], 8 * KO[1], 8), pO
      }
      replay(OO) {
        return NK.dfO2(this.__wbg_ptr, OO) >>> 0
      }
      resize(OO, KO, pO) {
        NK.PS49(this.__wbg_ptr, OO, KO, pO)
      }
      doO(OO) {
        const KO = oK(OO, NK.fDH5),
          pO = IK;
        return 0 !== NK.fX1W(this.__wbg_ptr, KO, pO)
      }
      NoO(OO, KO, pO, XO, bK) {
        const eO = VK(KO, NK.fDH5, NK.ruFu),
          lO = IK;
        return NK.JOAK(this.__wbg_ptr, OO, eO, lO, pO, XO, bK) >>> 0
      }
      IoO(OO) {
        NK.VESA(this.__wbg_ptr, OO)
      }
      yFO(OO, KO, pO, XO, bK) {
        const eO = VK(pO, NK.fDH5, NK.ruFu),
          lO = IK;
        return NK.SMhJ(this.__wbg_ptr, OO, KO, eO, lO, XO, bK) >>> 0
      }
      gFO(OO, KO, pO, XO) {
        NK.ygPn(this.__wbg_ptr, OO, KO, pO, XO)
      }
      uoO(OO, KO, pO, XO, bK) {
        const eO = VK(pO, NK.fDH5, NK.ruFu),
          lO = IK,
          vK = VK(XO, NK.fDH5, NK.ruFu),
          CO = IK;
        return NK.Ibcv(this.__wbg_ptr, OO, KO, eO, lO, vK, CO, bK) >>> 0
      }
      ToO(OO, KO, pO, XO) {
        const bK = VK(KO, NK.fDH5, NK.ruFu),
          eO = IK,
          lO = ap(pO, NK.fDH5),
          vK = IK;
        return NK.vI2E(this.__wbg_ptr, OO, bK, eO, lO, vK, XO) >>> 0
      }
      OoO(OO) {
        RO(OO, lO);
        var KO = OO.__destroy_into_raw();
        return 0 !== NK.JJ84(this.__wbg_ptr, KO)
      }
      GDO(OO, KO, pO, XO, bK) {
        var eO = DK(OO) ? 0 : oK(OO, NK.fDH5),
          lO = IK;
        const vK = oK(KO, NK.fDH5),
          CO = IK,
          hO = FK(pO, NK.fDH5),
          DO = IK,
          MO = ap(XO, NK.fDH5),
          aK = IK;
        return 0 !== NK.Nszr(this.__wbg_ptr, eO, lO, vK, CO, hO, DO, MO, aK, bK)
      }
      jFO() {
        const OO = NK.jyU5(this.__wbg_ptr);
        var KO = qK(OO[0], OO[1]).slice();
        return NK.IQAV(OO[0], 4 * OO[1], 4), KO
      }
      YoO(OO) {
        const KO = NK.sQue(this.__wbg_ptr, OO);
        var pO = xK(KO[0], KO[1]).slice();
        return NK.IQAV(KO[0], 1 * KO[1], 1), pO
      }
      woO(OO) {
        const KO = NK.WMca(this.__wbg_ptr, OO);
        var pO = qK(KO[0], KO[1]).slice();
        return NK.IQAV(KO[0], 4 * KO[1], 4), pO
      }
    }
    Symbol.dispose && (eO.prototype[Symbol.dispose] = eO.prototype.free);
    class lO {
      static __wrap(OO) {
        const KO = Object.create(lO.prototype);
        return KO.__wbg_ptr = OO, sO.register(KO, KO.__wbg_ptr, KO), KO
      }
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, sO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        NK.WNOO(OO, 0)
      }
    }

    function vK(OO, KO) {
      const pO = VK(OO, NK.fDH5, NK.ruFu),
        XO = IK,
        bK = NK.HR54(pO, XO, KO);
      if (bK[1]) throw LK(bK[0])
    }

    function CO() {
      NK.EwhI()
    }

    function hO() {
      return NK.Qx1d()
    }

    function DO() {
      return NK.TAYF() >>> 0
    }

    function MO(OO) {
      return 0 !== NK.yyTC(OO)
    }

    function aK(OO) {
      return 0 !== NK.a2w1(OO)
    }

    function oO(OO) {
      NK.ufDy(OO)
    }

    function FO() {
      return NK.XBhr() >>> 0
    }

    function VO() {
      return NK.fzQU() >>> 0
    }

    function LO() {
      return 0 !== NK.zMmL()
    }

    function QO(OO, KO, pO, XO, bK) {
      return LK(NK.CHMb(HO(OO), KO, HO(pO), XO, DK(bK) ? Number.MAX_SAFE_INTEGER : bK >>> 0))
    }

    function zK() {
      return NK.sdiq() >>> 0
    }

    function AO(OO, KO) {
      NK.Hqoo(OO, HO(KO))
    }

    function fO(OO, KO) {
      NK.xOTK(OO, HO(KO))
    }

    function dO(OO) {
      NK.VefY(OO)
    }

    function TO(OO) {
      NK.Iqo1(OO)
    }

    function NO(OO) {
      const KO = oK(OO, NK.fDH5),
        pO = IK;
      return 0 !== NK.KXNc(KO, pO)
    }

    function IO(OO) {
      var KO = DK(OO) ? 0 : oK(OO, NK.fDH5),
        pO = IK;
      const XO = NK.SDR4(KO, pO);
      let bK;
      return 0 !== XO[0] && (bK = GO(XO[0], XO[1]), NK.IQAV(XO[0], 4 * XO[1], 4)), bK
    }

    function yK() {
      const OO = NK.O66D();
      let KO;
      return 0 !== OO[0] && (KO = KK(OO[0], OO[1]), NK.IQAV(OO[0], 1 * OO[1], 1)), KO
    }

    function gK(OO, KO) {
      const pO = NK.pr0r(OO, KO);
      let XO;
      return 0 !== pO[0] && (XO = KK(pO[0], pO[1]), NK.IQAV(pO[0], 1 * pO[1], 1)), XO
    }

    function uO() {
      let OO, KO;
      try {
        const pO = NK.pETU();
        return OO = pO[0], KO = pO[1], KK(pO[0], pO[1])
      } finally {
        NK.IQAV(OO, KO, 1)
      }
    }

    function EO(OO) {
      NK.SvTR(HO(OO))
    }

    function jK() {
      const OO = {
        __proto__: null,
        MhMp: function(OO, KO) {
          return HO(Error(KK(OO, KO)))
        },
        QpMp: function(OO) {
          const KO = lK(OO),
            pO = "boolean" === typeof KO ? KO : void 0;
          return DK(pO) ? 16777215 : pO ? 1 : 0
        },
        B07o: function(OO, KO) {
          const pO = VK(JO(lK(KO)), NK.fDH5, NK.ruFu),
            XO = IK;
          WO().setInt32(OO + 4, XO, !0), WO().setInt32(OO + 0, pO, !0)
        },
        f7T0: function(OO) {
          return "function" === typeof lK(OO)
        },
        rf60: function(OO) {
          const KO = lK(OO);
          return "object" === typeof KO && null !== KO
        },
        dXdw: function(OO) {
          return void 0 === lK(OO)
        },
        x8ho: function(OO, KO) {
          const pO = lK(KO),
            XO = "number" === typeof pO ? pO : void 0;
          WO().setFloat64(OO + 8, DK(XO) ? 0 : XO, !0), WO().setInt32(OO + 0, !DK(XO), !0)
        },
        ayRO: function(OO) {
          throw LK(OO)
        },
        ygD2: function(OO, KO) {
          const pO = lK(KO),
            XO = "string" === typeof pO ? pO : void 0;
          var bK = DK(XO) ? 0 : VK(XO, NK.fDH5, NK.ruFu),
            eO = IK;
          WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
        },
        hrSl: function(OO, KO) {
          throw new Error(KK(OO, KO))
        },
        QAAY: function(OO) {
          lK(OO)._wbg_cb_unref()
        },
        lqs2: function(OO, KO) {
          lK(OO).activeTexture(KO >>> 0)
        },
        LXC7: function(OO, KO) {
          lK(OO).activeTexture(KO >>> 0)
        },
        O7vR: function() {
          return vp((function(OO, KO, pO, XO) {
            lK(OO).addEventListener(KK(KO, pO), lK(XO))
          }), arguments)
        },
        qdzV: function(OO, KO, pO) {
          lK(OO).attachShader(lK(KO), lK(pO))
        },
        vbfI: function(OO, KO, pO) {
          lK(OO).attachShader(lK(KO), lK(pO))
        },
        EHmR: function(OO, KO, pO) {
          lK(OO).beginQuery(KO >>> 0, lK(pO))
        },
        OyQK: function(OO, KO, pO, XO, bK) {
          lK(OO).bindAttribLocation(lK(KO), pO >>> 0, KK(XO, bK))
        },
        n8EF: function(OO, KO, pO, XO, bK) {
          lK(OO).bindAttribLocation(lK(KO), pO >>> 0, KK(XO, bK))
        },
        fT7w: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).bindBufferRange(KO >>> 0, pO >>> 0, lK(XO), bK, eO)
        },
        ae3m: function(OO, KO, pO) {
          lK(OO).bindBuffer(KO >>> 0, lK(pO))
        },
        PHq0: function(OO, KO, pO) {
          lK(OO).bindBuffer(KO >>> 0, lK(pO))
        },
        ngvZ: function(OO, KO, pO) {
          lK(OO).bindFramebuffer(KO >>> 0, lK(pO))
        },
        sFUJ: function(OO, KO, pO) {
          lK(OO).bindFramebuffer(KO >>> 0, lK(pO))
        },
        VXDN: function(OO, KO, pO) {
          lK(OO).bindRenderbuffer(KO >>> 0, lK(pO))
        },
        rZ61: function(OO, KO, pO) {
          lK(OO).bindRenderbuffer(KO >>> 0, lK(pO))
        },
        O1Hn: function(OO, KO, pO) {
          lK(OO).bindTexture(KO >>> 0, lK(pO))
        },
        m1Q6: function(OO, KO, pO) {
          lK(OO).bindTexture(KO >>> 0, lK(pO))
        },
        nnHh: function(OO, KO) {
          lK(OO).bindVertexArrayOES(lK(KO))
        },
        jDPx: function(OO, KO) {
          lK(OO).bindVertexArray(lK(KO))
        },
        Def2: function(OO, KO, pO) {
          lK(OO).blendEquationSeparate(KO >>> 0, pO >>> 0)
        },
        TyZc: function(OO, KO, pO) {
          lK(OO).blendEquationSeparate(KO >>> 0, pO >>> 0)
        },
        NtCa: function(OO, KO, pO, XO, bK) {
          lK(OO).blendFuncSeparate(KO >>> 0, pO >>> 0, XO >>> 0, bK >>> 0)
        },
        qfAg: function(OO, KO, pO, XO, bK) {
          lK(OO).blendFuncSeparate(KO >>> 0, pO >>> 0, XO >>> 0, bK >>> 0)
        },
        tcrM: function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
          lK(OO).blitFramebuffer(KO, pO, XO, bK, eO, lO, vK, CO, hO >>> 0, DO >>> 0)
        },
        cbIF: function(OO, KO, pO, XO) {
          lK(OO).bufferData(KO >>> 0, pO, XO >>> 0)
        },
        PnfH: function(OO, KO, pO, XO) {
          lK(OO).bufferData(KO >>> 0, lK(pO), XO >>> 0)
        },
        cGBA: function(OO, KO, pO, XO) {
          lK(OO).bufferData(KO >>> 0, lK(pO), XO >>> 0)
        },
        JOYC: function(OO, KO, pO, XO) {
          lK(OO).bufferData(KO >>> 0, pO, XO >>> 0)
        },
        OfpQ: function(OO, KO, pO, XO, bK) {
          lK(OO).bufferSubData(KO >>> 0, pO, xK(XO, bK))
        },
        ZHir: function() {
          return vp((function(OO, KO, pO, XO, bK, eO) {
            return HO(lK(OO).call(lK(KO), lK(pO), lK(XO), lK(bK), lK(eO)))
          }), arguments)
        },
        cdW2: function() {
          return vp((function(OO, KO, pO) {
            return HO(lK(OO).call(lK(KO), lK(pO)))
          }), arguments)
        },
        BVn6: function(OO) {
          lK(OO).call()
        },
        C1ue: function(OO, KO, pO, XO, bK) {
          lK(OO).clearColor(KO, pO, XO, bK)
        },
        F63I: function(OO, KO, pO, XO, bK) {
          lK(OO).clearColor(KO, pO, XO, bK)
        },
        cgdM: function(OO, KO) {
          lK(OO).clearDepth(KO)
        },
        TU1d: function(OO, KO) {
          lK(OO).clearDepth(KO)
        },
        NR86: function(OO, KO, pO, XO, bK) {
          lK(OO).clearRect(KO, pO, XO, bK)
        },
        Yofk: function(OO, KO) {
          lK(OO).clear(KO >>> 0)
        },
        hUFP: function(OO, KO) {
          lK(OO).clear(KO >>> 0)
        },
        EP1v: function(OO, KO, pO, XO, bK) {
          lK(OO).colorMask(0 !== KO, 0 !== pO, 0 !== XO, 0 !== bK)
        },
        XDht: function(OO, KO, pO, XO, bK) {
          lK(OO).colorMask(0 !== KO, 0 !== pO, 0 !== XO, 0 !== bK)
        },
        rkUE: function(OO, KO) {
          lK(OO).compileShader(lK(KO))
        },
        HDfl: function(OO, KO) {
          lK(OO).compileShader(lK(KO))
        },
        PtQA: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
          lK(OO).copyTexSubImage2D(KO >>> 0, pO, XO, bK, eO, lO, vK, CO)
        },
        KzHT: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
          lK(OO).copyTexSubImage2D(KO >>> 0, pO, XO, bK, eO, lO, vK, CO)
        },
        ewOa: function(OO) {
          const KO = lK(OO).createBuffer();
          return DK(KO) ? 0 : HO(KO)
        },
        H6hm: function(OO) {
          const KO = lK(OO).createBuffer();
          return DK(KO) ? 0 : HO(KO)
        },
        FX6S: function() {
          return vp((function(OO, KO, pO) {
            return HO(lK(OO).createElement(KK(KO, pO)))
          }), arguments)
        },
        AjSB: function(OO) {
          const KO = lK(OO).createFramebuffer();
          return DK(KO) ? 0 : HO(KO)
        },
        uFJR: function(OO) {
          const KO = lK(OO).createFramebuffer();
          return DK(KO) ? 0 : HO(KO)
        },
        I3gx: function(OO) {
          const KO = lK(OO).createProgram();
          return DK(KO) ? 0 : HO(KO)
        },
        AkHR: function(OO) {
          const KO = lK(OO).createProgram();
          return DK(KO) ? 0 : HO(KO)
        },
        w8RT: function(OO) {
          const KO = lK(OO).createQuery();
          return DK(KO) ? 0 : HO(KO)
        },
        AZFb: function(OO) {
          const KO = lK(OO).createRenderbuffer();
          return DK(KO) ? 0 : HO(KO)
        },
        zWaB: function(OO) {
          const KO = lK(OO).createRenderbuffer();
          return DK(KO) ? 0 : HO(KO)
        },
        KfrA: function(OO, KO) {
          const pO = lK(OO).createShader(KO >>> 0);
          return DK(pO) ? 0 : HO(pO)
        },
        K2uJ: function(OO, KO) {
          const pO = lK(OO).createShader(KO >>> 0);
          return DK(pO) ? 0 : HO(pO)
        },
        vBiC: function(OO) {
          const KO = lK(OO).createTexture();
          return DK(KO) ? 0 : HO(KO)
        },
        dOLe: function(OO) {
          const KO = lK(OO).createTexture();
          return DK(KO) ? 0 : HO(KO)
        },
        Xlrd: function(OO) {
          const KO = lK(OO).createVertexArrayOES();
          return DK(KO) ? 0 : HO(KO)
        },
        vDqu: function(OO) {
          const KO = lK(OO).createVertexArray();
          return DK(KO) ? 0 : HO(KO)
        },
        rxwO: function(OO, KO) {
          lK(OO).cullFace(KO >>> 0)
        },
        ArFv: function(OO, KO) {
          lK(OO).cullFace(KO >>> 0)
        },
        Q32p: function(OO, KO) {
          lK(OO).deleteBuffer(lK(KO))
        },
        KL7k: function(OO, KO) {
          lK(OO).deleteBuffer(lK(KO))
        },
        j3ie: function(OO, KO) {
          lK(OO).deleteFramebuffer(lK(KO))
        },
        LfMz: function(OO, KO) {
          lK(OO).deleteFramebuffer(lK(KO))
        },
        THcf: function(OO, KO) {
          lK(OO).deleteProgram(lK(KO))
        },
        SCG1: function(OO, KO) {
          lK(OO).deleteProgram(lK(KO))
        },
        cZ5d: function(OO, KO) {
          lK(OO).deleteQuery(lK(KO))
        },
        pUPR: function(OO, KO) {
          lK(OO).deleteRenderbuffer(lK(KO))
        },
        Gb86: function(OO, KO) {
          lK(OO).deleteRenderbuffer(lK(KO))
        },
        IS2u: function(OO, KO) {
          lK(OO).deleteSampler(lK(KO))
        },
        dBO6: function(OO, KO) {
          lK(OO).deleteShader(lK(KO))
        },
        PlbN: function(OO, KO) {
          lK(OO).deleteShader(lK(KO))
        },
        SogR: function(OO, KO) {
          lK(OO).deleteTexture(lK(KO))
        },
        QoB7: function(OO, KO) {
          lK(OO).deleteTexture(lK(KO))
        },
        dhQf: function(OO, KO) {
          lK(OO).deleteVertexArrayOES(lK(KO))
        },
        XOBF: function(OO, KO) {
          lK(OO).deleteVertexArray(lK(KO))
        },
        Bgdd: function(OO, KO) {
          lK(OO).depthFunc(KO >>> 0)
        },
        b9RK: function(OO, KO) {
          lK(OO).depthFunc(KO >>> 0)
        },
        Q4kO: function(OO, KO) {
          lK(OO).depthMask(0 !== KO)
        },
        Oas2: function(OO, KO) {
          lK(OO).depthMask(0 !== KO)
        },
        YVAY: function(OO, KO, pO) {
          lK(OO).depthRange(KO, pO)
        },
        VURR: function(OO, KO, pO) {
          lK(OO).depthRange(KO, pO)
        },
        VMZD: function(OO, KO, pO) {
          lK(OO).detachShader(lK(KO), lK(pO))
        },
        PWOj: function(OO, KO, pO) {
          lK(OO).detachShader(lK(KO), lK(pO))
        },
        vWym: function(OO, KO) {
          lK(OO).disable(KO >>> 0)
        },
        YaFp: function(OO, KO) {
          lK(OO).disable(KO >>> 0)
        },
        jXjg: function(OO) {
          const KO = lK(OO).document;
          return DK(KO) ? 0 : HO(KO)
        },
        h4Dx: function(OO, KO, pO, XO, bK) {
          lK(OO).drawArraysInstancedANGLE(KO >>> 0, pO, XO, bK)
        },
        LoKr: function(OO, KO, pO, XO, bK) {
          lK(OO).drawArraysInstanced(KO >>> 0, pO, XO, bK)
        },
        eawD: function(OO, KO, pO, XO) {
          lK(OO).drawArrays(KO >>> 0, pO, XO)
        },
        NwD4: function(OO, KO, pO, XO) {
          lK(OO).drawArrays(KO >>> 0, pO, XO)
        },
        fSwV: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).drawElementsInstancedANGLE(KO >>> 0, pO, XO >>> 0, bK, eO)
        },
        fmXX: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).drawElementsInstanced(KO >>> 0, pO, XO >>> 0, bK, eO)
        },
        cVMv: function(OO, KO, pO, XO, bK) {
          lK(OO).drawElements(KO >>> 0, pO, XO >>> 0, bK)
        },
        e2eY: function(OO, KO, pO, XO, bK) {
          lK(OO).drawElements(KO >>> 0, pO, XO >>> 0, bK)
        },
        YNEa: function() {
          return vp((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            lK(OO).drawImage(lK(KO), pO, XO, bK, eO, lO, vK, CO, hO)
          }), arguments)
        },
        tZIV: function(OO) {
          return lK(OO).drawingBufferHeight
        },
        Fgs9: function(OO) {
          return lK(OO).drawingBufferWidth
        },
        RPaT: function(OO, KO) {
          lK(OO).enableVertexAttribArray(KO >>> 0)
        },
        nwVn: function(OO, KO) {
          lK(OO).enableVertexAttribArray(KO >>> 0)
        },
        ub2o: function(OO, KO) {
          lK(OO).enable(KO >>> 0)
        },
        TPsQ: function(OO, KO) {
          lK(OO).enable(KO >>> 0)
        },
        jbo5: function(OO, KO) {
          lK(OO).endQuery(KO >>> 0)
        },
        uJJW: function(OO) {
          console.error(lK(OO))
        },
        wdBW: function(OO, KO) {
          console.error(KK(OO, KO))
        },
        SroY: function(OO, KO, pO, XO, bK) {
          lK(OO).framebufferRenderbuffer(KO >>> 0, pO >>> 0, XO >>> 0, lK(bK))
        },
        KDFN: function(OO, KO, pO, XO, bK) {
          lK(OO).framebufferRenderbuffer(KO >>> 0, pO >>> 0, XO >>> 0, lK(bK))
        },
        tPiC: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).framebufferTexture2D(KO >>> 0, pO >>> 0, XO >>> 0, lK(bK), eO)
        },
        HYwY: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).framebufferTexture2D(KO >>> 0, pO >>> 0, XO >>> 0, lK(bK), eO)
        },
        GHk7: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).framebufferTextureLayer(KO >>> 0, pO >>> 0, lK(XO), bK, eO)
        },
        F1J1: function(OO, KO) {
          lK(OO).frontFace(KO >>> 0)
        },
        YmnE: function(OO, KO) {
          lK(OO).frontFace(KO >>> 0)
        },
        D8Fa: function() {
          return vp((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            return lK(OO).gameCall(KO >>> 0, pO, XO, bK, eO, lO, vK, CO, hO)
          }), arguments)
        },
        ZCBV: function(OO, KO) {
          lK(OO).generateMipmap(KO >>> 0)
        },
        mdx9: function(OO, KO) {
          lK(OO).generateMipmap(KO >>> 0)
        },
        QSbr: function(OO, KO, pO) {
          const XO = lK(OO).getActiveUniform(lK(KO), pO >>> 0);
          return DK(XO) ? 0 : HO(XO)
        },
        u5YR: function(OO, KO, pO) {
          const XO = lK(OO).getActiveUniform(lK(KO), pO >>> 0);
          return DK(XO) ? 0 : HO(XO)
        },
        Id8q: function() {
          return vp((function(OO, KO, pO, XO) {
            const bK = lK(OO).getContext(KK(KO, pO), lK(XO));
            return DK(bK) ? 0 : HO(bK)
          }), arguments)
        },
        UUT2: function() {
          return vp((function(OO, KO, pO, XO) {
            const bK = lK(OO).getContext(KK(KO, pO), lK(XO));
            return DK(bK) ? 0 : HO(bK)
          }), arguments)
        },
        iP0r: function() {
          return vp((function(OO, KO, pO) {
            const XO = lK(OO).getContext(KK(KO, pO));
            return DK(XO) ? 0 : HO(XO)
          }), arguments)
        },
        pG9J: function(OO) {
          return lK(OO).getError()
        },
        llaN: function(OO) {
          return lK(OO).getError()
        },
        gtdx: function() {
          return vp((function(OO, KO, pO) {
            const XO = lK(OO).getExtension(KK(KO, pO));
            return DK(XO) ? 0 : HO(XO)
          }), arguments)
        },
        tjnr: function() {
          return vp((function(OO, KO, pO, XO) {
            const bK = lK(KO).getItem(KK(pO, XO));
            var eO = DK(bK) ? 0 : VK(bK, NK.fDH5, NK.ruFu),
              lO = IK;
            WO().setInt32(OO + 4, lO, !0), WO().setInt32(OO + 0, eO, !0)
          }), arguments)
        },
        Plew: function() {
          return vp((function(OO, KO) {
            return HO(lK(OO).getParameter(KO >>> 0))
          }), arguments)
        },
        KU2m: function() {
          return vp((function(OO, KO) {
            return HO(lK(OO).getParameter(KO >>> 0))
          }), arguments)
        },
        o0W1: function(OO, KO, pO) {
          const XO = lK(KO).getProgramInfoLog(lK(pO));
          var bK = DK(XO) ? 0 : VK(XO, NK.fDH5, NK.ruFu),
            eO = IK;
          WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
        },
        IWKA: function(OO, KO, pO) {
          const XO = lK(KO).getProgramInfoLog(lK(pO));
          var bK = DK(XO) ? 0 : VK(XO, NK.fDH5, NK.ruFu),
            eO = IK;
          WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
        },
        FSSn: function(OO, KO, pO) {
          return HO(lK(OO).getProgramParameter(lK(KO), pO >>> 0))
        },
        tquF: function(OO, KO, pO) {
          return HO(lK(OO).getProgramParameter(lK(KO), pO >>> 0))
        },
        jWDO: function() {
          return vp((function(OO, KO, pO, XO) {
            const bK = VK(lK(KO).getPropertyValue(KK(pO, XO)), NK.fDH5, NK.ruFu),
              eO = IK;
            WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
          }), arguments)
        },
        alqP: function(OO, KO, pO) {
          return HO(lK(OO).getQueryParameter(lK(KO), pO >>> 0))
        },
        VJdb: function(OO, KO, pO) {
          const XO = lK(KO).getShaderInfoLog(lK(pO));
          var bK = DK(XO) ? 0 : VK(XO, NK.fDH5, NK.ruFu),
            eO = IK;
          WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
        },
        Cdvv: function(OO, KO, pO) {
          const XO = lK(KO).getShaderInfoLog(lK(pO));
          var bK = DK(XO) ? 0 : VK(XO, NK.fDH5, NK.ruFu),
            eO = IK;
          WO().setInt32(OO + 4, eO, !0), WO().setInt32(OO + 0, bK, !0)
        },
        iDa4: function(OO, KO, pO) {
          const XO = lK(OO).getShaderPrecisionFormat(KO >>> 0, pO >>> 0);
          return DK(XO) ? 0 : HO(XO)
        },
        VnkK: function(OO, KO, pO) {
          const XO = lK(OO).getShaderPrecisionFormat(KO >>> 0, pO >>> 0);
          return DK(XO) ? 0 : HO(XO)
        },
        g9l5: function(OO) {
          const KO = lK(OO).getSupportedExtensions();
          return DK(KO) ? 0 : HO(KO)
        },
        nyzH: function(OO, KO, pO, XO) {
          const bK = lK(OO).getUniformLocation(lK(KO), KK(pO, XO));
          return DK(bK) ? 0 : HO(bK)
        },
        LDSK: function(OO, KO, pO, XO) {
          const bK = lK(OO).getUniformLocation(lK(KO), KK(pO, XO));
          return DK(bK) ? 0 : HO(bK)
        },
        uQlH: function() {
          return vp((function(OO, KO) {
            return HO(Reflect.get(lK(OO), lK(KO)))
          }), arguments)
        },
        UFNT: function(OO, KO) {
          return HO(lK(OO)[KO >>> 0])
        },
        dEmb: function(OO, KO, pO, XO) {
          const bK = lK(KO).get(KK(pO, XO));
          var eO = DK(bK) ? 0 : VK(bK, NK.fDH5, NK.ruFu),
            lO = IK;
          WO().setInt32(OO + 4, lO, !0), WO().setInt32(OO + 0, eO, !0)
        },
        qU3p: function(OO, KO) {
          return HO(lK(OO)[KO >>> 0])
        },
        WZXy: function() {
          return vp((function(OO, KO) {
            return Reflect.has(lK(OO), lK(KO))
          }), arguments)
        },
        gNge: function(OO) {
          return lK(OO).height
        },
        Jfzx: function(OO) {
          return lK(OO).height
        },
        tKuI: function(OO) {
          return lK(OO).height
        },
        JTiJ: function(OO) {
          console.info(lK(OO))
        },
        JCHj: function(OO) {
          let KO;
          try {
            KO = lK(OO) instanceof CanvasRenderingContext2D
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        DH1F: function(OO) {
          let KO;
          try {
            KO = lK(OO) instanceof Error
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        YC62: function(OO) {
          let KO;
          try {
            KO = lK(OO) instanceof HTMLCanvasElement
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        r5lv: function(OO) {
          let KO;
          try {
            KO = lK(OO) instanceof ImageBitmap
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        HjKU: function(OO) {
          let KO;
          try {
            KO = lK(OO) instanceof OffscreenCanvas
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        OoY0: function(OO) {
          let KO;
          try {
            KO = lK(OO) instanceof Performance
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        Ky7D: function(OO) {
          let KO;
          try {
            KO = lK(OO) instanceof WebGLRenderingContext
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        te8r: function(OO) {
          let KO;
          try {
            KO = lK(OO) instanceof Window
          } catch (pO) {
            KO = !1
          }
          return KO
        },
        LpJ6: function(OO) {
          return Array.isArray(lK(OO))
        },
        xDxC: function(OO) {
          return lK(OO).isContextLost()
        },
        TpCm: function(OO) {
          return lK(OO).length
        },
        u4fm: function(OO) {
          return lK(OO).length
        },
        OKCS: function(OO, KO) {
          lK(OO).linkProgram(lK(KO))
        },
        XsmO: function(OO, KO) {
          lK(OO).linkProgram(lK(KO))
        },
        vJzX: function() {
          return vp((function(OO) {
            const KO = lK(OO).localStorage;
            return DK(KO) ? 0 : HO(KO)
          }), arguments)
        },
        dxmA: function(OO) {
          return HO(lK(OO).location)
        },
        yBPZ: function(OO) {
          return HO(lK(OO).message)
        },
        hgAQ: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
          lK(OO).multiDrawArraysWEBGL(KO >>> 0, ZO(pO, XO), bK >>> 0, ZO(eO, lO), vK >>> 0, CO)
        },
        tJzJ: function(OO, KO) {
          const pO = VK(lK(KO).name, NK.fDH5, NK.ruFu),
            XO = IK;
          WO().setInt32(OO + 4, XO, !0), WO().setInt32(OO + 0, pO, !0)
        },
        izJg: function(OO) {
          return HO(lK(OO).name)
        },
        mcF1: function(OO, KO) {
          return HO(new Error(KK(OO, KO)))
        },
        Z3tY: function() {
          return HO(new Object)
        },
        NcM8: function() {
          return vp((function(OO, KO) {
            return HO(new OffscreenCanvas(OO >>> 0, KO >>> 0))
          }), arguments)
        },
        Vcfv: function(OO, KO) {
          return HO(new Uint8Array(xK(OO, KO)))
        },
        OwCF: function(OO, KO) {
          try {
            var pO = {
              a: OO,
              b: KO
            };
            const XO = new Promise(((OO, KO) => {
              const XO = pO.a;
              pO.a = 0;
              try {
                return function(OO, KO, pO, XO) {
                  NK.LwQ6(OO, KO, HO(pO), HO(XO))
                }(XO, pO.b, OO, KO)
              } finally {
                pO.a = XO
              }
            }));
            return HO(XO)
          } finally {
            pO.a = 0
          }
        },
        M9v8: function() {
          return vp((function(OO, KO) {
            return HO(new URLSearchParams(KK(OO, KO)))
          }), arguments)
        },
        iIYP: function() {
          return performance.now()
        },
        yCB1: function(OO) {
          return Performance.prototype.now.call(lK(OO))
        },
        RtCf: function() {
          return Date.now()
        },
        UkAW: function() {
          return Date.now()
        },
        Okte: function(OO, KO, pO) {
          lK(OO).pixelStorei(KO >>> 0, pO)
        },
        Vjau: function(OO, KO, pO) {
          lK(OO).pixelStorei(KO >>> 0, pO)
        },
        JUmi: function(OO, KO, pO) {
          lK(OO).polygonOffset(KO, pO)
        },
        qkYn: function(OO, KO, pO) {
          lK(OO).polygonOffset(KO, pO)
        },
        NbQt: function(OO) {
          return lK(OO).precision
        },
        Z6p7: function(OO) {
          lK(OO).preventDefault()
        },
        CyB0: function(OO, KO, pO, XO) {
          return lK(OO).probe(KO >>> 0, pO >>> 0, XO >>> 0)
        },
        znBv: function(OO, KO, pO) {
          Uint8Array.prototype.set.call(xK(OO, KO), lK(pO))
        },
        p641: function(OO) {
          return HO(lK(OO).queueMicrotask)
        },
        yJtd: function(OO) {
          queueMicrotask(lK(OO))
        },
        zlh8: function(OO) {
          return lK(OO).rangeMax
        },
        RNt1: function(OO) {
          return lK(OO).rangeMin
        },
        tnt4: function() {
          return vp((function(OO, KO, pO, XO, bK, eO, lO, vK) {
            lK(OO).readPixels(KO, pO, XO, bK, eO >>> 0, lO >>> 0, lK(vK))
          }), arguments)
        },
        yIYF: function() {
          return vp((function(OO, KO, pO, XO, bK, eO, lO, vK) {
            lK(OO).readPixels(KO, pO, XO, bK, eO >>> 0, lO >>> 0, lK(vK))
          }), arguments)
        },
        VzE4: function() {
          return vp((function(OO, KO, pO, XO, bK, eO, lO, vK) {
            lK(OO).readPixels(KO, pO, XO, bK, eO >>> 0, lO >>> 0, vK)
          }), arguments)
        },
        hzTZ: function() {
          return vp((function(OO, KO, pO, XO) {
            lK(OO).removeEventListener(KK(KO, pO), lK(XO))
          }), arguments)
        },
        ehg2: function(OO, KO, pO, XO, bK) {
          lK(OO).renderbufferStorage(KO >>> 0, pO >>> 0, XO, bK)
        },
        vtEJ: function(OO, KO, pO, XO, bK) {
          lK(OO).renderbufferStorage(KO >>> 0, pO >>> 0, XO, bK)
        },
        Ow5Q: function(OO) {
          return HO(lO.__wrap(OO))
        },
        S0lN: function(OO) {
          return HO(Promise.resolve(lK(OO)))
        },
        B529: function() {
          return vp((function(OO, KO) {
            const pO = VK(lK(KO).search, NK.fDH5, NK.ruFu),
              XO = IK;
            WO().setInt32(OO + 4, XO, !0), WO().setInt32(OO + 0, pO, !0)
          }), arguments)
        },
        bHKQ: function() {
          return vp((function(OO, KO, pO) {
            return lK(OO).setTimeout(lK(KO), pO)
          }), arguments)
        },
        cko0: function() {
          return vp((function(OO, KO, pO) {
            return Reflect.set(lK(OO), lK(KO), lK(pO))
          }), arguments)
        },
        bceW: function(OO, KO) {
          lK(OO).alpha = 0 !== KO
        },
        E3vd: function(OO, KO) {
          lK(OO).antialias = 0 !== KO
        },
        cPlI: function(OO, KO) {
          lK(OO).depth = 0 !== KO
        },
        ZUKc: function(OO, KO) {
          lK(OO).height = KO >>> 0
        },
        BDmE: function(OO, KO) {
          lK(OO).powerPreference = rK[KO]
        },
        umQ1: function(OO, KO) {
          lK(OO).premultipliedAlpha = 0 !== KO
        },
        jwmv: function(OO, KO) {
          lK(OO).preserveDrawingBuffer = 0 !== KO
        },
        dgjH: function(OO, KO) {
          lK(OO).stencil = 0 !== KO
        },
        XEL1: function(OO, KO) {
          lK(OO).width = KO >>> 0
        },
        vWLG: function(OO, KO, pO, XO) {
          lK(OO).shaderSource(lK(KO), KK(pO, XO))
        },
        ly8i: function(OO, KO, pO, XO) {
          lK(OO).shaderSource(lK(KO), KK(pO, XO))
        },
        xT8B: function(OO) {
          return lK(OO).size
        },
        flIW: function() {
          const OO = "undefined" === typeof global ? null : global;
          return DK(OO) ? 0 : HO(OO)
        },
        wgzm: function() {
          const OO = "undefined" === typeof globalThis ? null : globalThis;
          return DK(OO) ? 0 : HO(OO)
        },
        Cd0l: function() {
          const OO = "undefined" === typeof self ? null : self;
          return DK(OO) ? 0 : HO(OO)
        },
        WZRo: function() {
          const OO = "undefined" === typeof window ? null : window;
          return DK(OO) ? 0 : HO(OO)
        },
        C04o: function(OO) {
          return HO(lK(OO).style)
        },
        eCiE: function(OO, KO, pO) {
          return HO(lK(OO).subarray(KO >>> 0, pO >>> 0))
        },
        AElB: function() {
          return vp((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            lK(OO).texImage2D(KO >>> 0, pO, XO, bK, eO, lO, vK >>> 0, CO >>> 0, lK(hO))
          }), arguments)
        },
        UAXs: function(OO, KO, pO, XO) {
          lK(OO).texParameterf(KO >>> 0, pO >>> 0, XO)
        },
        yxOG: function(OO, KO, pO, XO) {
          lK(OO).texParameterf(KO >>> 0, pO >>> 0, XO)
        },
        gU6f: function(OO, KO, pO, XO) {
          lK(OO).texParameteri(KO >>> 0, pO >>> 0, XO)
        },
        APHH: function(OO, KO, pO, XO) {
          lK(OO).texParameteri(KO >>> 0, pO >>> 0, XO)
        },
        t9GV: function() {
          return vp((function(OO, KO, pO, XO, bK, eO, lO, vK) {
            lK(OO).texSubImage2D(KO >>> 0, pO, XO, bK, eO >>> 0, lO >>> 0, lK(vK))
          }), arguments)
        },
        OygK: function() {
          return vp((function(OO, KO, pO, XO, bK, eO, lO, vK) {
            lK(OO).texSubImage2D(KO >>> 0, pO, XO, bK, eO >>> 0, lO >>> 0, lK(vK))
          }), arguments)
        },
        n81F: function() {
          return vp((function(OO, KO, pO, XO, bK, eO, lO, vK) {
            lK(OO).texSubImage2D(KO >>> 0, pO, XO, bK, eO >>> 0, lO >>> 0, lK(vK))
          }), arguments)
        },
        JOmq: function() {
          return vp((function(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
            lK(OO).texSubImage2D(KO >>> 0, pO, XO, bK, eO, lO, vK >>> 0, CO >>> 0, lK(hO))
          }), arguments)
        },
        Hc1r: function(OO, KO) {
          return HO(lK(OO).then(lK(KO)))
        },
        qegF: function(OO) {
          return lK(OO).type
        },
        BeIb: function(OO, KO, pO) {
          lK(OO).uniform1f(lK(KO), pO)
        },
        zEU1: function(OO, KO, pO) {
          lK(OO).uniform1f(lK(KO), pO)
        },
        fX7k: function(OO, KO, pO) {
          lK(OO).uniform1i(lK(KO), pO)
        },
        b3Vy: function(OO, KO, pO) {
          lK(OO).uniform1i(lK(KO), pO)
        },
        mi1H: function(OO, KO, pO) {
          lK(OO).uniform1ui(lK(KO), pO >>> 0)
        },
        iyac: function(OO, KO, pO, XO) {
          lK(OO).uniform2f(lK(KO), pO, XO)
        },
        fpfI: function(OO, KO, pO, XO) {
          lK(OO).uniform2f(lK(KO), pO, XO)
        },
        Abyj: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).uniform4f(lK(KO), pO, XO, bK, eO)
        },
        r6Ui: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).uniform4f(lK(KO), pO, XO, bK, eO)
        },
        cfUh: function(OO, KO, pO, XO) {
          lK(OO).uniform4fv(lK(KO), cK(pO, XO))
        },
        ATOq: function(OO, KO, pO, XO) {
          lK(OO).uniform4fv(lK(KO), cK(pO, XO))
        },
        kHkH: function(OO, KO) {
          lK(OO).useProgram(lK(KO))
        },
        tzTw: function(OO, KO) {
          lK(OO).useProgram(lK(KO))
        },
        OrOk: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).vertexAttrib4f(KO >>> 0, pO, XO, bK, eO)
        },
        Z0CS: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).vertexAttrib4f(KO >>> 0, pO, XO, bK, eO)
        },
        jOwM: function(OO, KO, pO) {
          lK(OO).vertexAttribDivisorANGLE(KO >>> 0, pO >>> 0)
        },
        UT2I: function(OO, KO, pO) {
          lK(OO).vertexAttribDivisor(KO >>> 0, pO >>> 0)
        },
        X6Rw: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).vertexAttribI4i(KO >>> 0, pO, XO, bK, eO)
        },
        R9WM: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).vertexAttribI4ui(KO >>> 0, pO >>> 0, XO >>> 0, bK >>> 0, eO >>> 0)
        },
        JNut: function(OO, KO, pO, XO, bK, eO) {
          lK(OO).vertexAttribIPointer(KO >>> 0, pO, XO >>> 0, bK, eO)
        },
        OQn3: function(OO, KO, pO, XO, bK, eO, lO) {
          lK(OO).vertexAttribPointer(KO >>> 0, pO, XO >>> 0, 0 !== bK, eO, lO)
        },
        Y3dT: function(OO, KO, pO, XO, bK, eO, lO) {
          lK(OO).vertexAttribPointer(KO >>> 0, pO, XO >>> 0, 0 !== bK, eO, lO)
        },
        isSf: function(OO, KO, pO, XO, bK) {
          lK(OO).viewport(KO, pO, XO, bK)
        },
        XPcg: function(OO, KO, pO, XO, bK) {
          lK(OO).viewport(KO, pO, XO, bK)
        },
        sKjo: function(OO, KO) {
          console.warn(KK(OO, KO))
        },
        I77x: function(OO) {
          return lK(OO).width
        },
        Tpa7: function(OO) {
          return lK(OO).width
        },
        Waqn: function(OO) {
          return lK(OO).width
        },
        fWJM: function(OO, KO) {
          return HO(MK(OO, KO, iK))
        },
        ddlu: function(OO, KO) {
          return HO(MK(OO, KO, wO))
        },
        oSxq: function(OO, KO) {
          return HO(MK(OO, KO, YO))
        },
        Wcnp: function(OO, KO) {
          return HO(xK(OO, KO))
        },
        vJdr: function(OO, KO) {
          return HO(KK(OO, KO))
        },
        qtDG: function(OO) {
          return HO(lK(OO))
        },
        bajJ: function(OO) {
          LK(OO)
        }
      };
      return {
        __proto__: null,
        Kr3a: OO
      }
    }

    function YO(OO, KO) {
      NK.jb9K(OO, KO)
    }

    function wO(OO, KO, pO) {
      NK.dXHI(OO, KO, HO(pO))
    }

    function iK(OO, KO, pO) {
      const XO = NK.lks1(OO, KO, HO(pO));
      if (XO[1]) throw LK(XO[0])
    }
    Symbol.dispose && (lO.prototype[Symbol.dispose] = lO.prototype.free);
    const rK = ["default", "low-power", "high-performance"],
      PO = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => NK.EMLI(OO, 1))),
      mK = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => NK.GSLd(OO, 1))),
      sO = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => NK.WNOO(OO, 1)));

    function HO(OO) {
      hK === CK.length && CK.push(CK.length + 1);
      const KO = hK;
      return hK = CK[KO], CK[KO] = OO, KO
    }

    function RO(OO, KO) {
      if (!(OO instanceof KO)) throw new Error(`expected instance of ${KO.name}`)
    }
    const SO = "undefined" === typeof FinalizationRegistry ? {
      register: () => {},
      unregister: () => {}
    } : new FinalizationRegistry((OO => NK.uXK3(OO.a, OO.b)));

    function JO(OO) {
      const KO = typeof OO;
      if ("number" == KO || "boolean" == KO || null == OO) return `${OO}`;
      if ("string" == KO) return `"${OO}"`;
      if ("symbol" == KO) {
        const KO = OO.description;
        return null == KO ? "Symbol" : `Symbol(${KO})`
      }
      if ("function" == KO) {
        const KO = OO.name;
        return "string" == typeof KO && KO.length > 0 ? `Function(${KO})` : "Function"
      }
      if (Array.isArray(OO)) {
        const KO = OO.length;
        let pO = "[";
        KO > 0 && (pO += JO(OO[0]));
        for (let XO = 1; XO < KO; XO++) pO += ", " + JO(OO[XO]);
        return pO += "]", pO
      }
      const pO = /\[object ([^\]]+)\]/.exec(toString.call(OO));
      let XO;
      if (!(pO && pO.length > 1)) return toString.call(OO);
      if (XO = pO[1], "Object" == XO) try {
        return "Object(" + JSON.stringify(OO) + ")"
      } catch (bK) {
        return "Object"
      }
      return OO instanceof Error ? `${OO.name}: ${OO.message}\n${OO.stack}` : XO
    }

    function cK(OO, KO) {
      return OO >>>= 0,
        function() {
          null !== tK && 0 !== tK.byteLength || (tK = new Float32Array(NK.memory.buffer));
          return tK
        }().subarray(OO / 4, OO / 4 + KO)
    }

    function BO(OO, KO) {
      return OO >>>= 0, UO().subarray(OO / 8, OO / 8 + KO)
    }

    function ZO(OO, KO) {
      return OO >>>= 0,
        function() {
          null !== OK && 0 !== OK.byteLength || (OK = new Int32Array(NK.memory.buffer));
          return OK
        }().subarray(OO / 4, OO / 4 + KO)
    }

    function GO(OO, KO) {
      OO >>>= 0;
      const pO = WO(),
        XO = [];
      for (let bK = OO; bK < OO + 4 * KO; bK += 4) XO.push(LK(pO.getUint32(bK, !0)));
      return XO
    }

    function qK(OO, KO) {
      return OO >>>= 0, XK().subarray(OO / 4, OO / 4 + KO)
    }

    function xK(OO, KO) {
      return OO >>>= 0, eK().subarray(OO / 1, OO / 1 + KO)
    }
    let nO = null;

    function WO() {
      return (null === nO || !0 === nO.buffer.detached || void 0 === nO.buffer.detached && nO.buffer !== NK.memory.buffer) && (nO = new DataView(NK.memory.buffer)), nO
    }
    let tK = null;
    let kK = null;

    function UO() {
      return null !== kK && 0 !== kK.byteLength || (kK = new Float64Array(NK.memory.buffer)), kK
    }
    let OK = null;

    function KK(OO, KO) {
      return function(OO, KO) {
        AK += KO, AK >= zp && (QK = new TextDecoder("utf-8", {
          ignoreBOM: !0,
          fatal: !0
        }), QK.decode(), AK = KO);
        return QK.decode(eK().subarray(OO, OO + KO))
      }(OO >>> 0, KO)
    }
    let pK = null;

    function XK() {
      return null !== pK && 0 !== pK.byteLength || (pK = new Uint32Array(NK.memory.buffer)), pK
    }
    let bp = null;

    function eK() {
      return null !== bp && 0 !== bp.byteLength || (bp = new Uint8Array(NK.memory.buffer)), bp
    }

    function lK(OO) {
      return CK[OO]
    }

    function vp(OO, KO) {
      try {
        return OO.apply(this, KO)
      } catch (pO) {
        NK.i60R(HO(pO))
      }
    }
    let CK = new Array(1024).fill(void 0);
    CK.push(void 0, null, !0, !1);
    let hK = CK.length;

    function DK(OO) {
      return void 0 === OO || null === OO
    }

    function MK(OO, KO, pO) {
      const XO = {
          a: OO,
          b: KO,
          cnt: 1
        },
        bK = function() {
          XO.cnt++;
          const OO = XO.a;
          XO.a = 0;
          try {
            for (var KO = arguments.length, eO = new Array(KO), lO = 0; lO < KO; lO++) eO[lO] = arguments[lO];
            return pO(OO, XO.b, ...eO)
          } finally {
            XO.a = OO, bK._wbg_cb_unref()
          }
        };
      return bK._wbg_cb_unref = () => {
        0 === --XO.cnt && (NK.uXK3(XO.a, XO.b), XO.a = 0, SO.unregister(XO))
      }, SO.register(bK, XO, XO), bK
    }

    function ap(OO, KO) {
      const pO = KO(4 * OO.length, 4) >>> 0;
      return XK().set(OO, pO / 4), IK = OO.length, pO
    }

    function oK(OO, KO) {
      const pO = KO(1 * OO.length, 1) >>> 0;
      return eK().set(OO, pO / 1), IK = OO.length, pO
    }

    function FK(OO, KO) {
      const pO = KO(4 * OO.length, 4) >>> 0,
        XO = WO();
      for (let bK = 0; bK < OO.length; bK++) XO.setUint32(pO + 4 * bK, HO(OO[bK]), !0);
      return IK = OO.length, pO
    }

    function VK(OO, KO, pO) {
      if (void 0 === pO) {
        const pO = fK.encode(OO),
          XO = KO(pO.length, 1) >>> 0;
        return eK().subarray(XO, XO + pO.length).set(pO), IK = pO.length, XO
      }
      let XO = OO.length,
        bK = KO(XO, 1) >>> 0;
      const eO = eK();
      let lO = 0;
      for (; lO < XO; lO++) {
        const KO = OO.charCodeAt(lO);
        if (KO > 127) break;
        eO[bK + lO] = KO
      }
      if (lO !== XO) {
        0 !== lO && (OO = OO.slice(lO)), bK = pO(bK, XO, XO = lO + 3 * OO.length, 1) >>> 0;
        const KO = eK().subarray(bK + lO, bK + XO);
        lO += fK.encodeInto(OO, KO).written, bK = pO(bK, XO, lO, 1) >>> 0
      }
      return IK = lO, bK
    }

    function LK(OO) {
      const KO = lK(OO);
      return function(OO) {
        OO < 1028 || (CK[OO] = hK, hK = OO)
      }(OO), KO
    }
    let QK = new TextDecoder("utf-8", {
      ignoreBOM: !0,
      fatal: !0
    });
    QK.decode();
    const zp = 2146435072;
    let AK = 0;
    const fK = new TextEncoder;
    "encodeInto" in fK || (fK.encodeInto = function(OO, KO) {
      const pO = fK.encode(OO);
      return KO.set(pO), {
        read: OO.length,
        written: pO.length
      }
    });
    let dK, TK, NK, IK = 0;

    function yp(OO, KO) {
      return TK = OO, NK = OO.exports, dK = KO, nO = null, tK = null, kK = null, OK = null, pK = null, bp = null, NK.nYkx(), NK
    }

    function gp(OO) {
      if (void 0 !== NK) return NK;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module: OO
      } = OO) : console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));
      const KO = jK();
      OO instanceof WebAssembly.Module || (OO = new WebAssembly.Module(OO));
      return yp(new WebAssembly.Instance(OO, KO), OO)
    }
    async function uK(OO) {
      if (void 0 !== NK) return NK;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module_or_path: OO
      } = OO) : console.warn("using deprecated parameters for the initialization function; pass a single object instead"));
      const KO = jK();
      ("string" === typeof OO || "function" === typeof Request && OO instanceof Request || "function" === typeof URL && OO instanceof URL) && (OO = fetch(OO));
      const {
        instance: pO,
        module: XO
      } = await async function(OO, KO) {
        if ("function" === typeof Response && OO instanceof Response) {
          if (!OO.ok) throw new Error(`failed to fetch Wasm: ${OO.status} ${OO.statusText} fetching '${OO.url}'`);
          if ("function" === typeof WebAssembly.instantiateStreaming) try {
            return await WebAssembly.instantiateStreaming(OO, KO)
          } catch (pO) {
            if (! function(OO) {
                switch (OO) {
                  case "basic":
                  case "cors":
                  case "default":
                    return !0
                }
                return !1
              }(OO.type) || "application/wasm" === OO.headers.get("Content-Type")) throw pO;
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", pO)
          }
          const XO = await OO.arrayBuffer();
          return await WebAssembly.instantiate(XO, KO)
        } {
          const pO = await WebAssembly.instantiate(OO, KO);
          return pO instanceof WebAssembly.Instance ? {
            instance: pO,
            module: OO
          } : pO
        }
      }(await OO, KO);
      return yp(pO, XO)
    }
    const EK = {
      name: "bloxd_wasm_webgl1",
      url: () => new pO.U(pO(41292)),
      init: uK,
      MX: XO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);