export const id = 188;
export const ids = [188];
export const modules = {
  34864: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      WasmTextureWorker: () => zK
    });
    var XO = pO(518),
      bK = pO(2478),
      eO = pO(34866),
      lO = pO.n(eO);

    function vK() {
      return lO()('(()=>{var OO={d:(KO,pO)=>{for(var XO in pO)OO.o(pO,XO)&&!OO.o(KO,XO)&&Object.defineProperty(KO,XO,{enumerable:!0,get:pO[XO]})},o:(OO,KO)=>Object.prototype.hasOwnProperty.call(OO,KO),r:OO=>{"undefined"!==typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(OO,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(OO,"__esModule",{value:!0})}},KO={};OO.r(KO),OO.d(KO,{op:()=>pO,aK:()=>XO,default:()=>YO,initSync:()=>jK,oO:()=>bK});class pO{__destroy_into_raw(){const OO=this.__wbg_ptr;return this.__wbg_ptr=0,lO.unregister(this),OO}free(){const OO=this.__destroy_into_raw();gK.GhCr(OO,0)}mb(OO){const KO=function(OO,KO){const pO=KO(1*OO.length,1)>>>0;return FO().set(OO,pO/1),uO=OO.length,pO}(OO,gK.f1Q3),pO=uO;return gK.UXSa(this.__wbg_ptr,KO,pO)>>>0}re(){const OO=gK.ch33(this.__wbg_ptr);var KO=vK(OO[0],OO[1]).slice();return gK.JxIp(OO[0],4*OO[1],4),KO}me(){let OO,KO;try{const pO=gK.WmBX(this.__wbg_ptr);return OO=pO[0],KO=pO[1],DO(pO[0],pO[1])}finally{gK.JxIp(OO,KO,1)}}gl(){return gK.DXEV(this.__wbg_ptr)>>>0}Ee(){return gK.G9tK(this.__wbg_ptr)>>>0}we(){let OO,KO;try{const pO=gK.jioI(this.__wbg_ptr);return OO=pO[0],KO=pO[1],DO(pO[0],pO[1])}finally{gK.JxIp(OO,KO,1)}}se(){const OO=gK.Gwp4(this.__wbg_ptr);var KO=vK(OO[0],OO[1]).slice();return gK.JxIp(OO[0],4*OO[1],4),KO}We(){const OO=gK.IGFO(this.__wbg_ptr);var KO,pO,XO=(KO=OO[0],pO=OO[1],KO>>>=0,hO().subarray(KO/8,KO/8+pO)).slice();return gK.JxIp(OO[0],8*OO[1],8),XO}ll(){return gK.aJHd(this.__wbg_ptr)>>>0}Il(){return gK.xMJx(this.__wbg_ptr)>>>0}Yl(){const OO=gK.ng1l(this.__wbg_ptr);if(OO[1])throw AO(OO[0])}gv(OO){const KO=gK.wVXB(this.__wbg_ptr,OO);if(KO[1])throw AO(KO[0])}wl(OO){let KO,pO;try{const eO=gK.K5SF(this.__wbg_ptr,OO);var XO=eO[0],bK=eO[1];if(eO[3])throw XO=0,bK=0,AO(eO[2]);return KO=XO,pO=bK,DO(XO,bK)}finally{gK.JxIp(KO,pO,1)}}iv(OO){return gK.VTR9(this.__wbg_ptr,OO)>>>0}rv(OO){return gK.stpH(this.__wbg_ptr,OO)>>>0}Pl(){const OO=gK.FoNI(this.__wbg_ptr);var KO=vK(OO[0],OO[1]).slice();return gK.JxIp(OO[0],4*OO[1],4),KO}mv(){return 0!==gK.MZCt(this.__wbg_ptr)}constructor(OO,KO,pO,XO,bK,eO){const vK=zK(OO,gK.f1Q3,gK.ApSC),CO=uO,DO=QO(KO,gK.f1Q3),MO=uO,aK=function(OO,KO){const pO=KO(8*OO.length,8)>>>0;return hO().set(OO,pO/8),uO=OO.length,pO}(pO,gK.f1Q3),oO=uO,FO=QO(XO,gK.f1Q3),VO=uO,LO=QO(bK,gK.f1Q3),fO=uO,dO=gK.iZ0b(vK,CO,DO,MO,aK,oO,FO,VO,LO,fO,eO);if(dO[2])throw AO(dO[1]);return this.__wbg_ptr=dO[0],lO.register(this,this.__wbg_ptr,this),this}sl(){let OO,KO;try{const pO=gK.ZXxI(this.__wbg_ptr);return OO=pO[0],KO=pO[1],DO(pO[0],pO[1])}finally{gK.JxIp(OO,KO,1)}}Hl(OO,KO){const pO=zK(OO,gK.f1Q3,gK.ApSC),XO=uO,bK=QO(KO,gK.f1Q3),eO=uO,lO=gK.td4A(this.__wbg_ptr,pO,XO,bK,eO);if(lO[1])throw AO(lO[0])}warnings(){let OO,KO;try{const pO=gK.rp4t(this.__wbg_ptr);return OO=pO[0],KO=pO[1],DO(pO[0],pO[1])}finally{gK.JxIp(OO,KO,1)}}}function XO(OO,KO){const pO=zK(OO,gK.f1Q3,gK.ApSC),XO=uO,bK=gK.IFDQ(pO,XO,KO);if(bK[1])throw AO(bK[0])}function bK(){gK.HbzT()}function eO(){return{__proto__:null,mdfa:{__proto__:null,wKXW:function(OO,KO){return function(OO){LO===VO.length&&VO.push(VO.length+1);const KO=LO;return LO=VO[KO],VO[KO]=OO,KO}(Error(DO(OO,KO)))},CO7L:function(OO,KO){throw new Error(DO(OO,KO))},ZqwX:function(OO,KO){console.error(DO(OO,KO))}}}}Symbol.dispose&&(pO.prototype[Symbol.dispose]=pO.prototype.free);const lO="undefined"===typeof FinalizationRegistry?{register:()=>{},unregister:()=>{}}:new FinalizationRegistry((OO=>gK.GhCr(OO,1)));function vK(OO,KO){return OO>>>=0,aK().subarray(OO/4,OO/4+KO)}let CO=null;function hO(){return null!==CO&&0!==CO.byteLength||(CO=new Float64Array(gK.memory.buffer)),CO}function DO(OO,KO){return function(OO,KO){TO+=KO,TO>=dO&&(fO=new TextDecoder("utf-8",{ignoreBOM:!0,fatal:!0}),fO.decode(),TO=KO);return fO.decode(FO().subarray(OO,OO+KO))}(OO>>>0,KO)}let MO=null;function aK(){return null!==MO&&0!==MO.byteLength||(MO=new Uint32Array(gK.memory.buffer)),MO}let oO=null;function FO(){return null!==oO&&0!==oO.byteLength||(oO=new Uint8Array(gK.memory.buffer)),oO}let VO=new Array(1024).fill(void 0);VO.push(void 0,null,!0,!1);let LO=VO.length;function QO(OO,KO){const pO=KO(4*OO.length,4)>>>0;return aK().set(OO,pO/4),uO=OO.length,pO}function zK(OO,KO,pO){if(void 0===pO){const pO=NO.encode(OO),XO=KO(pO.length,1)>>>0;return FO().subarray(XO,XO+pO.length).set(pO),uO=pO.length,XO}let XO=OO.length,bK=KO(XO,1)>>>0;const eO=FO();let lO=0;for(;lO<XO;lO++){const KO=OO.charCodeAt(lO);if(KO>127)break;eO[bK+lO]=KO}if(lO!==XO){0!==lO&&(OO=OO.slice(lO)),bK=pO(bK,XO,XO=lO+3*OO.length,1)>>>0;const KO=FO().subarray(bK+lO,bK+XO);lO+=NO.encodeInto(OO,KO).written,bK=pO(bK,XO,lO,1)>>>0}return uO=lO,bK}function AO(OO){const KO=function(OO){return VO[OO]}(OO);return function(OO){OO<1028||(VO[OO]=LO,LO=OO)}(OO),KO}let fO=new TextDecoder("utf-8",{ignoreBOM:!0,fatal:!0});fO.decode();const dO=2146435072;let TO=0;const NO=new TextEncoder;"encodeInto"in NO||(NO.encodeInto=function(OO,KO){const pO=NO.encode(OO);return KO.set(pO),{read:OO.length,written:pO.length}});let IO,yK,gK,uO=0;function EO(OO,KO){return yK=OO,gK=OO.exports,IO=KO,CO=null,MO=null,oO=null,gK.refx(),gK}function jK(OO){if(void 0!==gK)return gK;void 0!==OO&&(Object.getPrototypeOf(OO)===Object.prototype?({module:OO}=OO):console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));const KO=eO();OO instanceof WebAssembly.Module||(OO=new WebAssembly.Module(OO));return EO(new WebAssembly.Instance(OO,KO),OO)}async function YO(OO){if(void 0!==gK)return gK;void 0!==OO&&(Object.getPrototypeOf(OO)===Object.prototype?({module_or_path:OO}=OO):console.warn("using deprecated parameters for the initialization function; pass a single object instead"));const KO=eO();("string"===typeof OO||"function"===typeof Request&&OO instanceof Request||"function"===typeof URL&&OO instanceof URL)&&(OO=fetch(OO));const{instance:pO,module:XO}=await async function(OO,KO){if("function"===typeof Response&&OO instanceof Response){if(!OO.ok)throw new Error(`failed to fetch Wasm: ${OO.status} ${OO.statusText} fetching \'${OO.url}\'`);if("function"===typeof WebAssembly.instantiateStreaming)try{return await WebAssembly.instantiateStreaming(OO,KO)}catch(pO){if(!function(OO){switch(OO){case"basic":case"cors":case"default":return!0}return!1}(OO.type)||"application/wasm"===OO.headers.get("Content-Type"))throw pO;console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\\n",pO)}const XO=await OO.arrayBuffer();return await WebAssembly.instantiate(XO,KO)}{const pO=await WebAssembly.instantiate(OO,KO);return pO instanceof WebAssembly.Instance?{instance:pO,module:OO}:pO}}(await OO,KO);return EO(pO,XO)}let wO=null,iK=null;function rK(OO){if(null!==iK)throw iK;if(null===wO)try{const{memory:pO}=jK({module:OO});wO={wasm:KO,memory:pO}}catch(pO){throw iK=function(OO,KO){return new Error(`${OO}: ${KO instanceof Error?`${KO.name}: ${KO.message}`:String(KO)}`,{cause:KO})}("instantiate",pO),iK}return wO}function PO(OO){return OO instanceof Error?OO.message:String(OO)}const mK=0,sO=1,HO=2,RO=3,SO=4;Error;function JO(OO){return`the texture module didn\'t load (${PO(OO)})`}function cK(OO){return""===OO?[]:OO.split("\\0")}const BO=self;let ZO=null,GO=mK,qK=0;function xK(OO){const KO=performance.now();(OO!==GO||KO-qK>=1e3)&&(GO=OO,qK=KO,BO.postMessage({type:"progress",stage:OO}))}function nO(OO){let KO;xK(sO);try{KO=rK(OO.module)}catch(lO){return void BO.postMessage({type:"failed",reason:JO(lO),moduleLoad:!0})}xK(HO);const{assets:pO,layerCap:XO,warnings:bK,generator:eO}=function(OO,KO,pO,XO,bK,eO){const{wasm:lO,memory:vK}=OO,{strings:CO,blocks:hO,numbers:DO,index:MO,armour:aK}=KO,oO=new lO.op(CO,hO,DO,MO,aK,pO),FO=XO.sources.map((OO=>(null===eO||void 0===eO||eO(HO),oO.mb(OO)))),VO=new Uint32Array(2*XO.sourceOfName.length);for(const[NO,IO]of XO.sourceOfName.entries())VO[2*NO]=NO,VO[2*NO+1]=FO[IO];oO.Hl(XO.names,VO),null===eO||void 0===eO||eO(RO),oO.gv(bK),null===eO||void 0===eO||eO(SO);const LO={};for(const[NO,IO]of cK(oO.sl()).entries())null===eO||void 0===eO||eO(SO),LO[IO]=oO.wl(NO);const QO={},zK=oO.re(),AO=new Map;for(const[NO,IO]of cK(oO.me()).entries()){const OO=zK[NO];AO.has(OO)||(null===eO||void 0===eO||eO(SO),AO.set(OO,oO.wl(OO))),QO[IO]=AO.get(OO)}const fO=oO.Il(),dO=[],TO=[];for(let NO=fO;NO<fO+oO.Ee();NO++){null===eO||void 0===eO||eO(SO),dO.push(oO.wl(NO));const OO=oO.rv(NO),KO=oO.iv(NO);TO.push(new Uint8ClampedArray(vK.buffer,OO,KO).slice())}return{assets:{rotatedBlockTextures:LO,animatedBlockTextures:QO,blockAtlasArr:dO,blockAtlasPixels:TO,armourAtlas:oO.wl(oO.gl()),imagesPerAtlas:Array.from(oO.Pl()),blockAtlasWidth:oO.ll()},layerCap:oO.mv()?bK:0,warnings:oO.warnings(),generator:oO}}(KO,OO.inputs,OO.isDefaultPack,{sources:OO.sources,names:OO.names,sourceOfName:OO.sourceOfName},OO.maxLayerWidth,xK);ZO=eO,BO.postMessage({type:"required",assets:pO,layerCap:XO,warnings:bK},pO.blockAtlasPixels.map((OO=>OO.buffer)))}self.onmessageerror=()=>{BO.postMessage({type:"failed",reason:"the request couldn\'t be deserialised"})},self.onmessage=OO=>{let{data:KO}=OO;try{"required"===KO.type?nO(KO):function(){if(!ZO)throw new Error("No required assets to follow");const{colours:OO,warnings:KO}=function(OO){return OO.Yl(),{colours:{blocks:OO.we(),counts:OO.se(),values:OO.We()},warnings:OO.warnings()}}(ZO);BO.postMessage({type:"optional",...OO,warnings:KO},[OO.counts.buffer,OO.values.buffer])}()}catch(pO){const OO=PO(pO);BO.postMessage({type:"failed",reason:pO instanceof WebAssembly.RuntimeError?`wasm trapped (${OO})`:OO})}}})();', "Worker", void 0, pO.p + "generation.worker.0d9189e6.worker.js")
    }
    var CO = pO(34875),
      hO = pO(2514),
      DO = pO(2536),
      MO = pO(2533),
      aK = pO(2487);

    function oO(OO) {
      return "" === OO ? [] : OO.split("\0")
    }

    function FO(OO) {
      if ("" !== OO)
        for (const KO of OO.split("\n")) console.error(KO)
    }

    function VO(OO, KO) {
      return async function(OO, KO) {
        const pO = Object.keys(OO),
          XO = [],
          bK = new Map,
          eO = new Uint32Array(pO.length);
        for (const [lO, vK] of pO.entries()) {
          const {
            url: KO
          } = OO[vK];
          bK.has(KO) || (bK.set(KO, XO.length), XO.push(KO)), eO[lO] = bK.get(KO)
        }
        return {
          sources: await KO(XO),
          names: pO.join("\0"),
          sourceOfName: eO
        }
      }(OO, (async OO => {
        const pO = await async function(OO, KO) {
          const pO = new AbortController,
            XO = () => {
              pO.abort()
            };
          KO.addEventListener("abort", XO);
          try {
            const KO = await Promise.all(OO.map((async OO => {
              try {
                const KO = await fetch(OO, {
                  signal: pO.signal
                });
                if (!KO.ok) throw new Error(`HTTP ${KO.status}`);
                return [OO, await KO.blob()]
              } catch (KO) {
                throw pO.abort(), new DO.l(DO.h.Fetch, `fetching ${OO} failed: ${(0,MO.c)(KO)}`)
              }
            })));
            return new Map(KO)
          } finally {
            KO.removeEventListener("abort", XO)
          }
        }(OO.filter((OO => !OO.startsWith("data:"))), KO);
        return Promise.all(OO.map((OO => {
          var KO;
          return (0, aK.g)(null !== (KO = pO.get(OO)) && void 0 !== KO ? KO : OO)
        })))
      }))
    }

    function LO(OO, KO) {
      const pO = OO instanceof DO.l ? OO : new DO.l(KO ? DO.h.Optional : DO.h.Error, (0, MO.c)(OO));
      return pO.code !== DO.h.Fetch && pO.code !== DO.h.Error && (0, hO.h)(pO.message), pO
    }

    function QO(OO) {
      return OO.message ? new Error(`the texture worker failed: ${OO.message}`) : new DO.l(DO.h.Load, "the texture worker failed to start")
    }
    class zK {
      constructor(OO) {
        this.worker = OO, this.failure = void 0, this.abandonStep = null, OO.addEventListener("error", (OO => {
          OO.preventDefault(), this.failure ??= QO(OO)
        }))
      }
      static async generateRequired(OO, KO, pO, eO) {
        let lO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : DO.c;
        const hO = (0, CO.k)();
        if (null !== hO) throw LO(new DO.l(DO.h.Load, hO), !1);
        let aK;
        const oO = new AbortController;
        try {
          aK = new zK(function() {
            try {
              return new vK
            } catch (OO) {
              throw new DO.l(DO.h.Load, `the texture worker failed to start: ${(0,MO.c)(OO)}`)
            }
          }());
          const hO = (0, CO.b)().catch((OO => {
              throw new DO.l(DO.h.Load, function(OO) {
                return `the texture module didn't load (${(0,MO.c)(OO)})`
              }(OO))
            })),
            LO = (async () => {
              const eO = function(OO, KO, pO) {
                const XO = [],
                  bK = new Map,
                  eO = OO => {
                    let KO = bK.get(OO);
                    return void 0 === KO && (KO = XO.length, XO.push(OO), bK.set(OO, KO)), KO
                  },
                  lO = [],
                  vK = [],
                  CO = new Map,
                  hO = (OO, KO) => {
                    const pO = "object" === typeof OO && null !== OO && "animTextures" in OO ? OO.animTextures : void 0;
                    if (!Array.isArray(pO) || !pO.every((OO => "string" === typeof OO))) throw new Error(`Block ${KO} has textureInfo the encoding doesn't cover`);
                    lO.push(pO.length, ...pO.map(eO))
                  };
                let DO = 0;
                for (const oO in OO) {
                  const KO = OO[oO];
                  lO.push(eO(oO));
                  const pO = (KO.transTex ? 1 : 0) | (KO.Lp ? 2 : 0) | (KO.particlesIgnoreBlack ? 4 : 0),
                    XO = "string" === typeof KO.itemTexture ? eO(KO.itemTexture) : 4294967295,
                    bK = `${pO},${XO}`,
                    MO = KO.textureInfo,
                    aK = CO.get(MO);
                  if ((null === aK || void 0 === aK ? void 0 : aK.fields) !== bK)
                    if (CO.set(MO, {
                        entry: DO++,
                        fields: bK
                      }), lO.push(1, pO, XO), "string" === typeof MO) lO.push(1, eO(MO));
                    else if (Array.isArray(MO)) {
                    lO.push(3, MO.length);
                    for (const OO of MO) "string" === typeof OO ? lO.push(0, eO(OO)) : "number" === typeof OO ? (lO.push(2, vK.length), vK.push(OO)) : (lO.push(1), hO(OO, oO))
                  } else MO ? (lO.push(2), hO(MO, oO)) : lO.push(0);
                  else lO.push(0, aK.entry), DO++
                }
                const MO = [];
                for (const oO in KO) MO.push(eO(oO), KO[oO]);
                const aK = new Uint32Array(pO.map(eO));
                return {
                  strings: XO.join("\0"),
                  blocks: new Uint32Array(lO),
                  numbers: new Float64Array(vK),
                  index: new Uint32Array(MO),
                  armour: aK
                }
              }(OO, KO, XO.d.map(bK.e));
              return {
                inputs: eO,
                sources: await VO(pO, oO.signal)
              }
            })(),
            [QO, {
              inputs: AO,
              sources: fO
            }] = await Promise.all([hO, LO]),
            dO = [AO.blocks.buffer, AO.numbers.buffer, AO.index.buffer, AO.armour.buffer, fO.sourceOfName.buffer];
          for (const OO of fO.sources) dO.push(OO.buffer);
          const {
            assets: TO,
            layerCap: NO,
            warnings: IO
          } = await aK.request({
            type: "required",
            module: QO,
            inputs: AO,
            isDefaultPack: eO,
            maxLayerWidth: lO,
            ...fO
          }, dO);
          return FO(IO), {
            assets: TO,
            layerCap: NO,
            worker: aK
          }
        } catch (AO) {
          var QO;
          throw oO.abort(), null === (QO = aK) || void 0 === QO || QO.terminate(), LO(AO, !1)
        }
      }
      async generateOptional() {
        let OO;
        try {
          OO = await this.request({
            type: "optional"
          }, [])
        } catch (KO) {
          throw LO(KO, !0)
        } finally {
          this.terminate()
        }
        return FO(OO.warnings),
          function(OO) {
            let {
              blocks: KO,
              counts: pO,
              values: XO
            } = OO;
            const bK = {};
            let eO = 0;
            for (const [lO, vK] of oO(KO).entries()) {
              const OO = [];
              for (let KO = 0; KO < pO[lO]; KO++, eO += 3) OO.push([XO[eO], XO[eO + 1], XO[eO + 2]]);
              bK[vK] = OO
            }
            return bK
          }(OO)
      }
      terminate() {
        var OO;
        this.worker.terminate(), null === (OO = this.abandonStep) || void 0 === OO || OO.call(this)
      }
      request(OO, KO) {
        return new Promise(((pO, XO) => {
          if (void 0 !== this.failure) return void XO(this.failure);
          let bK = DO.n.None,
            eO = null;
          const lO = () => {
            var OO;
            null === (OO = eO) || void 0 === OO || OO.stop(), this.abandonStep = null, this.worker.onmessage = null, this.worker.onerror = null, this.worker.onmessageerror = null
          };
          this.abandonStep = () => {
            lO(), XO(new Error("the texture worker was terminated"))
          }, this.worker.onmessage = KO => {
            let {
              data: vK
            } = KO;
            var CO;
            if ("progress" === vK.type) return bK = vK.stage, void(null === (CO = eO) || void 0 === CO || CO.restart(bK === DO.n.Generating ? DO.d : DO.g));
            lO(), "failed" === vK.type ? XO(vK.moduleLoad ? new DO.l(DO.h.Load, vK.reason) : new Error(vK.reason)) : vK.type !== OO.type ? XO(new Error(`the texture worker answered ${vK.type} to ${OO.type}`)) : pO(vK)
          }, this.worker.onerror = OO => {
            lO(), XO(QO(OO))
          }, this.worker.onmessageerror = () => {
            lO(), XO(new Error("the texture worker's answer couldn't be read"))
          };
          try {
            this.worker.postMessage(OO, KO), eO = (0, DO.p)((() => {
              lO();
              const KO = new DO.l("required" === OO.type ? `${DO.h.Stalled}${bK}` : DO.h.Optional, "the texture worker stopped responding");
              XO(KO)
            }))
          } catch (vK) {
            lO(), XO(vK)
          }
        }))
      }
    }
  },
  34866: OO => {
    OO.exports = function(OO, KO, pO, XO) {
      var bK = self || window;
      try {
        try {
          var eO;
          try {
            eO = new bK.Blob([OO])
          } catch (hO) {
            (eO = new(bK.BlobBuilder || bK.WebKitBlobBuilder || bK.MozBlobBuilder || bK.MSBlobBuilder)).append(OO), eO = eO.getBlob()
          }
          var lO = bK.URL || bK.webkitURL,
            vK = lO.createObjectURL(eO),
            CO = new bK[KO](vK, pO);
          return lO.revokeObjectURL(vK), CO
        } catch (hO) {
          return new bK[KO]("data:application/javascript,".concat(encodeURIComponent(OO)), pO)
        }
      } catch (hO) {
        if (!XO) throw Error("Inline worker is not supported");
        return new bK[KO](XO, pO)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);