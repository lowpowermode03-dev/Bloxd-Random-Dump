export const id = 367;
export const ids = [367];
export const modules = {
  59737: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      textureMergerPixelShaderWGSL: () => lO
    });
    var XO = pO(37907);
    const bK = "textureMergerPixelShader",
      eO = "#ifdef USE_TEXTURE0\nvar inputTexture0Sampler: sampler;var inputTexture0: texture_2d<f32>;\n#endif\n#ifdef USE_TEXTURE1\nvar inputTexture1Sampler: sampler;var inputTexture1: texture_2d<f32>;\n#endif\n#ifdef USE_TEXTURE2\nvar inputTexture2Sampler: sampler;var inputTexture2: texture_2d<f32>;\n#endif\n#ifdef USE_TEXTURE3\nvar inputTexture3Sampler: sampler;var inputTexture3: texture_2d<f32>;\n#endif\n#ifdef RED_FROM_TEXTURE\nuniform redTextureIndex: i32;uniform redSourceChannel: i32;\n#else\nuniform redConstantValue: f32;\n#endif\n#ifdef GREEN_FROM_TEXTURE\nuniform greenTextureIndex: i32;uniform greenSourceChannel: i32;\n#else\nuniform greenConstantValue: f32;\n#endif\n#ifdef BLUE_FROM_TEXTURE\nuniform blueTextureIndex: i32;uniform blueSourceChannel: i32;\n#else\nuniform blueConstantValue: f32;\n#endif\n#ifdef ALPHA_FROM_TEXTURE\nuniform alphaTextureIndex: i32;uniform alphaSourceChannel: i32;\n#else\nuniform alphaConstantValue: f32;\n#endif\nvarying vUV: vec2f;\n#if defined(RED_FROM_TEXTURE) || defined(GREEN_FROM_TEXTURE) || defined(BLUE_FROM_TEXTURE) || defined(ALPHA_FROM_TEXTURE)\nfn sampleTexture(textureIndex: i32,uv: vec2f)->vec4f {switch (textureIndex) {\n#ifdef USE_TEXTURE0\ncase 0: {return textureSample(inputTexture0,inputTexture0Sampler,uv);}\n#endif\n#ifdef USE_TEXTURE1\ncase 1: {return textureSample(inputTexture1,inputTexture1Sampler,uv);}\n#endif\n#ifdef USE_TEXTURE2\ncase 2: {return textureSample(inputTexture2,inputTexture2Sampler,uv);}\n#endif\n#ifdef USE_TEXTURE3\ncase 3: {return textureSample(inputTexture3,inputTexture3Sampler,uv);}\n#endif\ndefault: {return vec4f(0.0,0.0,0.0,1.0); }}}\nfn extractChannel(color: vec4f,channelIndex: i32)->f32 {switch (channelIndex) {case 0: {return color.r; }\ncase 1: {return color.g; }\ncase 2: {return color.b; }\ndefault: {return color.a; }}}\n#endif\n@fragment\nfn main(input: FragmentInputs)->FragmentOutputs {let uv: vec2f=input.vUV;\n#ifdef RED_FROM_TEXTURE\nlet redSample: vec4f=sampleTexture(uniforms.redTextureIndex,uv);let r: f32=extractChannel(redSample,uniforms.redSourceChannel);\n#else\nlet r: f32=uniforms.redConstantValue;\n#endif\n#ifdef GREEN_FROM_TEXTURE\nlet greenSample: vec4f=sampleTexture(uniforms.greenTextureIndex,uv);let g: f32=extractChannel(greenSample,uniforms.greenSourceChannel);\n#else\nlet g: f32=uniforms.greenConstantValue;\n#endif\n#ifdef BLUE_FROM_TEXTURE\nlet blueSample: vec4f=sampleTexture(uniforms.blueTextureIndex,uv);let b: f32=extractChannel(blueSample,uniforms.blueSourceChannel);\n#else\nlet b: f32=uniforms.blueConstantValue;\n#endif\n#ifdef ALPHA_FROM_TEXTURE\nlet alphaSample: vec4f=sampleTexture(uniforms.alphaTextureIndex,uv);let a: f32=extractChannel(alphaSample,uniforms.alphaSourceChannel);\n#else\nlet a: f32=uniforms.alphaConstantValue;\n#endif\nfragmentOutputs.color=vec4f(r,g,b,a);}";
    XO.b.ShadersStoreWGSL[bK] || (XO.b.ShadersStoreWGSL[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);