export const id = 337;
export const ids = [337];
export const modules = {
  59139: (OO, KO, pO) => {
    pO.d(KO, {
      allocateF64Mat4: () => bK
    });
    var XO = pO(39739);

    function bK() {
      return new XO.f(16)
    }
    bK["@@MAT4_STORAGE_F64@@"] = !0
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);