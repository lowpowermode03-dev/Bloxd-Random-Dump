export const id = 232;
export const ids = [232];
export const modules = {
  38294: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => LO,
      f: () => AO
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(38186),
      lO = pO(35660),
      vK = pO(35632),
      CO = pO(38301),
      hO = pO(37061),
      DO = pO(35676),
      MO = pO(37938),
      aK = pO(36513),
      oO = pO(36142),
      FO = pO(38021),
      VO = pO(38077);
    let LO = (() => {
      var OO;
      let KO, pO, DO, LO, QO, zK, AO, fO, dO, TO, NO, IO, yK, gK, uO, EO, jK, YO, wO = CO.c,
        iK = [],
        rK = [],
        PO = [],
        mK = [],
        sO = [],
        HO = [],
        RO = [],
        SO = [],
        JO = [],
        cK = [],
        BO = [],
        ZO = [],
        GO = [],
        qK = [],
        xK = [],
        nO = [],
        WO = [],
        tK = [],
        kK = [],
        UO = [],
        OK = [],
        KK = [],
        pK = [],
        XK = [],
        bp = [];
      return OO = class extends wO {
        get position() {
          return this._position
        }
        set position(OO) {
          this._position = OO
        }
        set upVector(OO) {
          this._upVector = OO
        }
        get upVector() {
          return this._upVector
        }
        get screenArea() {
          let KO, pO;
          if (this.mode === OO.PERSPECTIVE_CAMERA) this.fovMode === OO.FOVMODE_VERTICAL_FIXED ? (pO = 2 * this.minZ * Math.tan(this.fov / 2), KO = this.qb().getAspectRatio(this) * pO) : (KO = 2 * this.minZ * Math.tan(this.fov / 2), pO = KO / this.qb().getAspectRatio(this));
          else {
            const OO = this.qb().getRenderWidth() / 2,
              XO = this.qb().getRenderHeight() / 2;
            KO = (this.orthoRight ?? OO) - (this.orthoLeft ?? -OO), pO = (this.orthoTop ?? XO) - (this.orthoBottom ?? -XO)
          }
          return KO * pO
        }
        set orthoLeft(OO) {
          this._orthoLeft = OO;
          for (const KO of this._rigCameras) KO.orthoLeft = OO
        }
        get orthoLeft() {
          return this._orthoLeft
        }
        set orthoRight(OO) {
          this._orthoRight = OO;
          for (const KO of this._rigCameras) KO.orthoRight = OO
        }
        get orthoRight() {
          return this._orthoRight
        }
        set orthoBottom(OO) {
          this._orthoBottom = OO;
          for (const KO of this._rigCameras) KO.orthoBottom = OO
        }
        get orthoBottom() {
          return this._orthoBottom
        }
        set orthoTop(OO) {
          this._orthoTop = OO;
          for (const KO of this._rigCameras) KO.orthoTop = OO
        }
        get orthoTop() {
          return this._orthoTop
        }
        setFocalLength(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 36;
          this.fov = 2 * Math.atan(KO / (2 * OO))
        }
        get inertia() {
          return this._baseInertia
        }
        set inertia(OO) {
          this._baseInertia = OO
        }
        set mode(OO) {
          this._mode = OO;
          for (const KO of this._rigCameras) KO.mode = OO
        }
        get mode() {
          return this._mode
        }
        get hasMoved() {
          return this._hasMoved
        }
        constructor(KO, pO, bK) {
          let CO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
          (0, FO.e)(), super(KO, bK, !1), this.inputs = (0, XO.i)(this, iK), this._position = (0, XO.i)(this, rK, vK.o.Zero()), this._upVector = ((0, XO.i)(this, PO), (0, XO.i)(this, mK, vK.o.Up())), this.oblique = ((0, XO.i)(this, sO), null), this._orthoLeft = null, this._orthoRight = null, this._orthoBottom = null, this._orthoTop = null, this.fov = (0, XO.i)(this, HO, .8), this.projectionPlaneTilt = ((0, XO.i)(this, RO), (0, XO.i)(this, SO, 0)), this.minZ = ((0, XO.i)(this, JO), (0, XO.i)(this, cK, 1)), this.maxZ = ((0, XO.i)(this, BO), (0, XO.i)(this, ZO, 1e4)), this._baseInertia = ((0, XO.i)(this, GO), .9), this._mode = OO.PERSPECTIVE_CAMERA, this.isIntermediate = !1, this.viewport = new aK.d(0, 0, 1, 1), this.layerMask = (0, XO.i)(this, qK, 268435455), this.fovMode = ((0, XO.i)(this, xK), (0, XO.i)(this, nO, OO.FOVMODE_VERTICAL_FIXED)), this.cameraRigMode = ((0, XO.i)(this, WO), (0, XO.i)(this, tK, OO.RIG_MODE_NONE)), this.interaxialDistance = ((0, XO.i)(this, kK), (0, XO.i)(this, UO, void 0)), this.isStereoscopicSideBySide = ((0, XO.i)(this, OK), (0, XO.i)(this, KK, void 0)), this.ignoreCameraMaxZ = ((0, XO.i)(this, pK), (0, XO.i)(this, XK, !1)), this.customRenderTargets = ((0, XO.i)(this, bp), []), this.outputRenderTarget = null, this.onViewMatrixChangedObservable = new lO.e, this.onProjectionMatrixChangedObservable = new lO.e, this.onAfterCheckInputsObservable = new lO.e, this.onRestoreStateObservable = new lO.e, this.isRigCamera = !1, this._hasMoved = !1, this._rigCameras = new Array, this._skipRendering = !1, this._projectionMatrix = new vK.c, this._postProcesses = new Array, this._activeMeshes = new eO.e(256), this._globalPosition = vK.o.Zero(), this._computedViewMatrix = vK.c.Identity(), this._doNotComputeProjectionMatrix = !1, this._transformMatrix = vK.c.Zero(), this._refreshFrustumPlanes = !0, this._absoluteRotation = vK.g.Identity(), this._isCamera = !0, this._isLeftCamera = !1, this._isRightCamera = !1, this.layerMask = this.JKO().defaultCameraLayerMask, this.JKO().addCamera(this), CO && !this.JKO().activeCamera && (this.JKO().activeCamera = this), this.position = pO, this.renderPassId = this.JKO().qb().createRenderPassId(`Camera ${KO}`)
        }
        storeState() {
          return this._stateStored = !0, this._storedFov = this.fov, this
        }
        hasStateStored() {
          return !!this._stateStored
        }
        _restoreStateValues() {
          return !!this._stateStored && (this.fov = this._storedFov, !0)
        }
        restoreState() {
          return !!this._restoreStateValues() && (this.onRestoreStateObservable.notifyObservers(this), !0)
        }
        getClassName() {
          return "xv"
        }
        toString(OO) {
          let KO = "Name: " + this.name;
          if (KO += ", type: " + this.getClassName(), this.animations)
            for (let pO = 0; pO < this.animations.length; pO++) KO += ", animation[0]: " + this.animations[pO].toString(OO);
          return KO
        }
        applyVerticalCorrection() {
          const OO = this.absoluteRotation.toEulerAngles();
          this.projectionPlaneTilt = this._scene.useRightHandedSystem ? -OO.x : OO.x
        }
        get globalPosition() {
          return this._globalPosition
        }
        getActiveMeshes() {
          return this._activeMeshes
        }
        isActiveMesh(OO) {
          return -1 !== this._activeMeshes.indexOf(OO)
        }
        isReady() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          if (OO)
            for (const KO of this._postProcesses)
              if (KO && !KO.isReady()) return !1;
          return super.isReady(OO)
        }
        _initCache() {
          super._initCache(), this._cache.position = new vK.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), this._cache.upVector = new vK.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), this._cache.mode = void 0, this._cache.minZ = void 0, this._cache.maxZ = void 0, this._cache.fov = void 0, this._cache.fovMode = void 0, this._cache.aspectRatio = void 0, this._cache.orthoLeft = void 0, this._cache.orthoRight = void 0, this._cache.orthoBottom = void 0, this._cache.orthoTop = void 0, this._cache.obliqueAngle = void 0, this._cache.obliqueLength = void 0, this._cache.obliqueOffset = void 0, this._cache.renderWidth = void 0, this._cache.renderHeight = void 0
        }
        _updateCache(OO) {
          OO || super._updateCache(), this._cache.position.NhO(this.position), this._cache.upVector.NhO(this.upVector)
        }
        _isSynchronized() {
          return this._isSynchronizedViewMatrix() && this._isSynchronizedProjectionMatrix()
        }
        _isSynchronizedViewMatrix() {
          return !!super._isSynchronized() && (this._cache.position.equals(this.position) && this._cache.upVector.equals(this.upVector) && this.isSynchronizedWithParent())
        }
        _isSynchronizedProjectionMatrix() {
          const KO = this.ignoreCameraMaxZ ? 0 : this.maxZ;
          let pO = this._cache.mode === this.mode && this._cache.minZ === this.minZ && this._cache.maxZ === KO;
          if (!pO) return !1;
          const XO = this.qb();
          return this.mode === OO.PERSPECTIVE_CAMERA ? pO = this._cache.fov === this.fov && this._cache.fovMode === this.fovMode && this._cache.aspectRatio === XO.getAspectRatio(this) && this._cache.projectionPlaneTilt === this.projectionPlaneTilt : (pO = this._cache.orthoLeft === this.orthoLeft && this._cache.orthoRight === this.orthoRight && this._cache.orthoBottom === this.orthoBottom && this._cache.orthoTop === this.orthoTop && this._cache.renderWidth === XO.getRenderWidth() && this._cache.renderHeight === XO.getRenderHeight(), this.oblique && (pO = pO && this._cache.obliqueAngle === this.oblique.angle && this._cache.obliqueLength === this.oblique.length && this._cache.obliqueOffset === this.oblique.offset)), pO
        }
        attachControl(OO, KO) {}
        detachControl(OO) {}
        update() {
          this._hasMoved = !1, this._checkInputs(), this.cameraRigMode !== OO.RIG_MODE_NONE && this._updateRigCameras(), this.getViewMatrix(), this.getProjectionMatrix()
        }
        _checkInputs() {
          this.onAfterCheckInputsObservable.notifyObservers(this)
        }
        get rigCameras() {
          return this._rigCameras
        }
        get rigPostProcess() {
          return this._rigPostProcess
        }
        _getFirstPostProcess() {
          for (let OO = 0; OO < this._postProcesses.length; OO++)
            if (null !== this._postProcesses[OO]) return this._postProcesses[OO];
          return null
        }
        _cascadePostProcessesToRigCams() {
          const OO = this._getFirstPostProcess();
          OO && OO.markTextureDirty();
          for (let KO = 0, pO = this._rigCameras.length; KO < pO; KO++) {
            const OO = this._rigCameras[KO],
              pO = OO._rigPostProcess;
            if (pO) {
              "pass" === pO.getEffectName() && (OO.isIntermediate = 0 === this._postProcesses.length), OO._postProcesses = this._postProcesses.slice(0).concat(pO), pO.markTextureDirty()
            } else OO._postProcesses = this._postProcesses.slice(0)
          }
        }
        attachPostProcess(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          return !OO.isReusable() && this._postProcesses.indexOf(OO) > -1 ? (hO.b.Error("You're trying to reuse a post process not defined as reusable."), 0) : (null == KO || KO < 0 ? this._postProcesses.push(OO) : null === this._postProcesses[KO] ? this._postProcesses[KO] = OO : this._postProcesses.splice(KO, 0, OO), this._cascadePostProcessesToRigCams(), this._scene.prePassRenderer && this._scene.prePassRenderer.jhO(), this._postProcesses.indexOf(OO))
        }
        detachPostProcess(OO) {
          const KO = this._postProcesses.indexOf(OO); - 1 !== KO && (this._postProcesses[KO] = null), this._scene.prePassRenderer && this._scene.prePassRenderer.jhO(), this._cascadePostProcessesToRigCams()
        }
        getWorldMatrix() {
          return this._isSynchronizedViewMatrix() || this.getViewMatrix(), this._worldMatrix
        }
        _getViewMatrix() {
          return vK.c.Identity()
        }
        getViewMatrix(OO) {
          return !OO && this._isSynchronizedViewMatrix() || (this._hasMoved = !0, this.updateCache(), this._computedViewMatrix = this._getViewMatrix(), this._currentRenderId = this.JKO().getRenderId(), this._childUpdateId++, this._refreshFrustumPlanes = !0, this._cameraRigParams && this._cameraRigParams.vrPreViewMatrix && this._computedViewMatrix.multiplyToRef(this._cameraRigParams.vrPreViewMatrix, this._computedViewMatrix), this.parent && this.parent.onViewMatrixChangedObservable && this.parent.onViewMatrixChangedObservable.notifyObservers(this.parent), this.onViewMatrixChangedObservable.notifyObservers(this), this._computedViewMatrix.invertToRef(this._worldMatrix), this._worldMatrix.getTranslationToRef(this._globalPosition)), this._computedViewMatrix
        }
        freezeProjectionMatrix(OO) {
          this._doNotComputeProjectionMatrix = !0, void 0 !== OO && (this._projectionMatrix = OO)
        }
        unfreezeProjectionMatrix() {
          this._doNotComputeProjectionMatrix = !1
        }
        getProjectionMatrix(KO) {
          if (this._doNotComputeProjectionMatrix || !KO && this._isSynchronizedProjectionMatrix()) return this._projectionMatrix;
          const pO = this.ignoreCameraMaxZ ? 0 : this.maxZ;
          this._cache.mode = this.mode, this._cache.minZ = this.minZ, this._cache.maxZ = pO, this._refreshFrustumPlanes = !0;
          const XO = this.qb(),
            bK = this.JKO(),
            eO = XO.BhO;
          if (this.mode === OO.PERSPECTIVE_CAMERA) {
            let KO;
            this._cache.fov = this.fov, this._cache.fovMode = this.fovMode, this._cache.aspectRatio = XO.getAspectRatio(this), this._cache.projectionPlaneTilt = this.projectionPlaneTilt, this.minZ <= 0 && (this.minZ = .1), KO = bK.useRightHandedSystem ? vK.c.PerspectiveFovRHToRef : vK.c.PerspectiveFovLHToRef, KO(this.fov, XO.getAspectRatio(this), eO ? pO : this.minZ, eO ? this.minZ : pO, this._projectionMatrix, this.fovMode === OO.FOVMODE_VERTICAL_FIXED, XO.isNDCHalfZRange, this.projectionPlaneTilt, eO)
          } else {
            const OO = XO.getRenderWidth() / 2,
              KO = XO.getRenderHeight() / 2;
            bK.useRightHandedSystem ? this.oblique ? vK.c.ObliqueOffCenterRHToRef(this.orthoLeft ?? -OO, this.orthoRight ?? OO, this.orthoBottom ?? -KO, this.orthoTop ?? KO, eO ? pO : this.minZ, eO ? this.minZ : pO, this.oblique.length, this.oblique.angle, this._computeObliqueDistance(this.oblique.offset), this._projectionMatrix, XO.isNDCHalfZRange) : vK.c.OrthoOffCenterRHToRef(this.orthoLeft ?? -OO, this.orthoRight ?? OO, this.orthoBottom ?? -KO, this.orthoTop ?? KO, eO ? pO : this.minZ, eO ? this.minZ : pO, this._projectionMatrix, XO.isNDCHalfZRange) : this.oblique ? vK.c.ObliqueOffCenterLHToRef(this.orthoLeft ?? -OO, this.orthoRight ?? OO, this.orthoBottom ?? -KO, this.orthoTop ?? KO, eO ? pO : this.minZ, eO ? this.minZ : pO, this.oblique.length, this.oblique.angle, this._computeObliqueDistance(this.oblique.offset), this._projectionMatrix, XO.isNDCHalfZRange) : vK.c.OrthoOffCenterLHToRef(this.orthoLeft ?? -OO, this.orthoRight ?? OO, this.orthoBottom ?? -KO, this.orthoTop ?? KO, eO ? pO : this.minZ, eO ? this.minZ : pO, this._projectionMatrix, XO.isNDCHalfZRange), this._cache.orthoLeft = this.orthoLeft, this._cache.orthoRight = this.orthoRight, this._cache.orthoBottom = this.orthoBottom, this._cache.orthoTop = this.orthoTop, this._cache.obliqueAngle = this.oblique?.angle, this._cache.obliqueLength = this.oblique?.length, this._cache.obliqueOffset = this.oblique?.offset, this._cache.renderWidth = XO.getRenderWidth(), this._cache.renderHeight = XO.getRenderHeight()
          }
          return this.onProjectionMatrixChangedObservable.notifyObservers(this), this._projectionMatrix
        }
        getTransformationMatrix() {
          return this._computedViewMatrix.multiplyToRef(this._projectionMatrix, this._transformMatrix), this._transformMatrix
        }
        _computeObliqueDistance(OO) {
          return (this.radius || (this.target ? vK.o.Distance(this.position, this.target) : this.position.length())) + OO
        }
        _updateFrustumPlanes() {
          this._refreshFrustumPlanes && (this.getTransformationMatrix(), this._frustumPlanes ? oO.e.GetPlanesToRef(this._transformMatrix, this._frustumPlanes) : this._frustumPlanes = oO.e.GetPlanes(this._transformMatrix), this._refreshFrustumPlanes = !1)
        }
        isInFrustum(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          if (this._updateFrustumPlanes(), KO && this.rigCameras.length > 0) {
            let KO = !1;
            for (const pO of this.rigCameras) pO._updateFrustumPlanes(), KO = KO || OO.isInFrustum(pO._frustumPlanes);
            return KO
          }
          return OO.isInFrustum(this._frustumPlanes)
        }
        isCompletelyInFrustum(OO) {
          return this._updateFrustumPlanes(), OO.isCompletelyInFrustum(this._frustumPlanes)
        }
        getForwardRay() {
          throw (0, MO.j)("Ray")
        }
        getForwardRayToRef(OO) {
          throw (0, MO.j)("Ray")
        }
        dispose(KO) {
          let pO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          for (this.onViewMatrixChangedObservable.clear(), this.onProjectionMatrixChangedObservable.clear(), this.onAfterCheckInputsObservable.clear(), this.onRestoreStateObservable.clear(), this.inputs && this.inputs.clear(), this.JKO().stopAnimation(this), this.JKO().removeCamera(this); this._rigCameras.length > 0;) {
            const OO = this._rigCameras.pop();
            OO && OO.dispose()
          }
          if (this._parentContainer) {
            const OO = this._parentContainer.cameras.indexOf(this);
            OO > -1 && this._parentContainer.cameras.splice(OO, 1), this._parentContainer = null
          }
          if (this._rigPostProcess) this._rigPostProcess.dispose(this), this._rigPostProcess = null, this._postProcesses.length = 0;
          else if (this.cameraRigMode !== OO.RIG_MODE_NONE) this._rigPostProcess = null, this._postProcesses.length = 0;
          else {
            let OO = this._postProcesses.length;
            for (; --OO >= 0;) {
              const KO = this._postProcesses[OO];
              KO && KO.dispose(this)
            }
          }
          let XO = this.customRenderTargets.length;
          for (; --XO >= 0;) this.customRenderTargets[XO].dispose();
          this.customRenderTargets.length = 0, this._activeMeshes.dispose(), this.JKO().qb().releaseRenderPassId(this.renderPassId), super.dispose(KO, pO)
        }
        get isLeftCamera() {
          return this._isLeftCamera
        }
        get isRightCamera() {
          return this._isRightCamera
        }
        get leftCamera() {
          return this._rigCameras.length < 1 ? null : this._rigCameras[0]
        }
        get rightCamera() {
          return this._rigCameras.length < 2 ? null : this._rigCameras[1]
        }
        getLeftTarget() {
          return this._rigCameras.length < 1 ? null : this._rigCameras[0].getTarget()
        }
        getRightTarget() {
          return this._rigCameras.length < 2 ? null : this._rigCameras[1].getTarget()
        }
        setCameraRigMode(KO, pO) {
          if (this.cameraRigMode !== KO) {
            for (; this._rigCameras.length > 0;) {
              const OO = this._rigCameras.pop();
              OO && OO.dispose()
            }
            if (this.cameraRigMode = KO, this._cameraRigParams = {}, this._cameraRigParams.interaxialDistance = pO.interaxialDistance || .0637, this._cameraRigParams.stereoHalfAngle = this._cameraRigParams.interaxialDistance / .0637 * (Math.PI / 180), this.cameraRigMode !== OO.RIG_MODE_NONE) {
              const OO = this.createRigCamera(this.name + "_L", 0);
              OO && (OO._isLeftCamera = !0);
              const KO = this.createRigCamera(this.name + "_R", 1);
              KO && (KO._isRightCamera = !0), OO && KO && (this._rigCameras.push(OO), this._rigCameras.push(KO))
            }
            this._setRigMode(pO), this._cascadePostProcessesToRigCams(), this.update()
          }
        }
        _setRigMode(OO) {}
        _getVRProjectionMatrix() {
          return vK.c.PerspectiveFovLHToRef(this._cameraRigParams.vrMetrics.aspectRatioFov, this._cameraRigParams.vrMetrics.aspectRatio, this.minZ, this.ignoreCameraMaxZ ? 0 : this.maxZ, this._cameraRigParams.vrWorkMatrix, !0, this.qb().isNDCHalfZRange), this._cameraRigParams.vrWorkMatrix.multiplyToRef(this._cameraRigParams.vrHMatrix, this._projectionMatrix), this._projectionMatrix
        }
        setCameraRigParameter(OO, KO) {
          this._cameraRigParams || (this._cameraRigParams = {}), this._cameraRigParams[OO] = KO, "interaxialDistance" === OO && (this._cameraRigParams.stereoHalfAngle = KO / .0637 * (Math.PI / 180))
        }
        createRigCamera(OO, KO) {
          return null
        }
        _updateRigCameras() {
          for (let OO = 0; OO < this._rigCameras.length; OO++) this._rigCameras[OO].minZ = this.minZ, this._rigCameras[OO].maxZ = this.ignoreCameraMaxZ ? 0 : this.maxZ, this._rigCameras[OO].fov = this.fov, this._rigCameras[OO].upVector.NhO(this.upVector);
          this.cameraRigMode === OO.RIG_MODE_STEREOSCOPIC_ANAGLYPH && (this._rigCameras[0].viewport = this._rigCameras[1].viewport = this.viewport)
        }
        _setupInputs() {}
        serialize() {
          const OO = VO.c.Serialize(this);
          return OO.uniqueId = this.uniqueId, OO.type = this.getClassName(), this.parent && this.parent._serializeAsParent(OO), this.inputs && this.inputs.serialize(OO), VO.c.AppendSerializedAnimations(this, OO), OO.Xl = this.serializeAnimationRanges(), OO.isEnabled = this.isEnabled(), OO
        }
        clone(KO) {
          let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          const XO = VO.c.Clone(OO.GetConstructorFromName(this.getClassName(), KO, this.JKO(), this.interaxialDistance, this.isStereoscopicSideBySide), this);
          return XO.name = KO, XO.parent = pO, this.onClonedObservable.notifyObservers(XO), XO
        }
        YbO(OO) {
          const KO = vK.o.Zero();
          return this.getDirectionToRef(OO, KO), KO
        }
        get absoluteRotation() {
          return this.getWorldMatrix().decompose(void 0, this._absoluteRotation), this._absoluteRotation
        }
        getDirectionToRef(OO, KO) {
          vK.o.TransformNormalToRef(OO, this.getWorldMatrix(), KO)
        }
        static GetConstructorFromName(KO, pO, XO) {
          let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
            eO = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4];
          const lO = CO.c.Construct(KO, pO, XO, {
            interaxial_distance: bK,
            isStereoscopicSideBySide: eO
          });
          return lO || (() => OO._CreateDefaultParsedCamera(pO, XO))
        }
        computeWorldMatrix() {
          return this.getWorldMatrix()
        }
        _calculateHandednessMultiplier() {
          let OO = this.JKO().useRightHandedSystem ? -1 : 1;
          return this.parent && this.parent._getWorldMatrixDeterminant() < 0 && (OO *= -1), OO
        }
      }, (() => {
        const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(wO[Symbol.metadata] ?? null) : void 0;
        KO = [(0, bK.L)("position")], pO = [(0, bK.L)("upVector")], DO = [(0, bK.M)()], LO = [(0, bK.M)()], QO = [(0, bK.M)()], zK = [(0, bK.M)()], AO = [(0, bK.M)()], fO = [(0, bK.M)()], dO = [(0, bK.M)()], TO = [(0, bK.M)()], NO = [(0, bK.M)()], IO = [(0, bK.M)()], yK = [(0, bK.M)()], gK = [(0, bK.M)()], uO = [(0, bK.M)()], EO = [(0, bK.M)()], jK = [(0, bK.M)()], YO = [(0, bK.M)()], (0, XO.f)(OO, null, DO, {
          kind: "getter",
          name: "orthoLeft",
          static: !1,
          private: !1,
          access: {
            has: OO => "orthoLeft" in OO,
            get: OO => OO.orthoLeft
          },
          metadata: eO
        }, null, iK), (0, XO.f)(OO, null, LO, {
          kind: "getter",
          name: "orthoRight",
          static: !1,
          private: !1,
          access: {
            has: OO => "orthoRight" in OO,
            get: OO => OO.orthoRight
          },
          metadata: eO
        }, null, iK), (0, XO.f)(OO, null, QO, {
          kind: "getter",
          name: "orthoBottom",
          static: !1,
          private: !1,
          access: {
            has: OO => "orthoBottom" in OO,
            get: OO => OO.orthoBottom
          },
          metadata: eO
        }, null, iK), (0, XO.f)(OO, null, zK, {
          kind: "getter",
          name: "orthoTop",
          static: !1,
          private: !1,
          access: {
            has: OO => "orthoTop" in OO,
            get: OO => OO.orthoTop
          },
          metadata: eO
        }, null, iK), (0, XO.f)(OO, null, NO, {
          kind: "getter",
          name: "inertia",
          static: !1,
          private: !1,
          access: {
            has: OO => "inertia" in OO,
            get: OO => OO.inertia
          },
          metadata: eO
        }, null, iK), (0, XO.f)(OO, null, IO, {
          kind: "getter",
          name: "mode",
          static: !1,
          private: !1,
          access: {
            has: OO => "mode" in OO,
            get: OO => OO.mode
          },
          metadata: eO
        }, null, iK), (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "_position",
          static: !1,
          private: !1,
          access: {
            has: OO => "_position" in OO,
            get: OO => OO._position,
            set: (OO, KO) => {
              OO._position = KO
            }
          },
          metadata: eO
        }, rK, PO), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "_upVector",
          static: !1,
          private: !1,
          access: {
            has: OO => "_upVector" in OO,
            get: OO => OO._upVector,
            set: (OO, KO) => {
              OO._upVector = KO
            }
          },
          metadata: eO
        }, mK, sO), (0, XO.f)(null, null, AO, {
          kind: "field",
          name: "fov",
          static: !1,
          private: !1,
          access: {
            has: OO => "fov" in OO,
            get: OO => OO.fov,
            set: (OO, KO) => {
              OO.fov = KO
            }
          },
          metadata: eO
        }, HO, RO), (0, XO.f)(null, null, fO, {
          kind: "field",
          name: "projectionPlaneTilt",
          static: !1,
          private: !1,
          access: {
            has: OO => "projectionPlaneTilt" in OO,
            get: OO => OO.projectionPlaneTilt,
            set: (OO, KO) => {
              OO.projectionPlaneTilt = KO
            }
          },
          metadata: eO
        }, SO, JO), (0, XO.f)(null, null, dO, {
          kind: "field",
          name: "minZ",
          static: !1,
          private: !1,
          access: {
            has: OO => "minZ" in OO,
            get: OO => OO.minZ,
            set: (OO, KO) => {
              OO.minZ = KO
            }
          },
          metadata: eO
        }, cK, BO), (0, XO.f)(null, null, TO, {
          kind: "field",
          name: "maxZ",
          static: !1,
          private: !1,
          access: {
            has: OO => "maxZ" in OO,
            get: OO => OO.maxZ,
            set: (OO, KO) => {
              OO.maxZ = KO
            }
          },
          metadata: eO
        }, ZO, GO), (0, XO.f)(null, null, yK, {
          kind: "field",
          name: "layerMask",
          static: !1,
          private: !1,
          access: {
            has: OO => "layerMask" in OO,
            get: OO => OO.layerMask,
            set: (OO, KO) => {
              OO.layerMask = KO
            }
          },
          metadata: eO
        }, qK, xK), (0, XO.f)(null, null, gK, {
          kind: "field",
          name: "fovMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "fovMode" in OO,
            get: OO => OO.fovMode,
            set: (OO, KO) => {
              OO.fovMode = KO
            }
          },
          metadata: eO
        }, nO, WO), (0, XO.f)(null, null, uO, {
          kind: "field",
          name: "cameraRigMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "cameraRigMode" in OO,
            get: OO => OO.cameraRigMode,
            set: (OO, KO) => {
              OO.cameraRigMode = KO
            }
          },
          metadata: eO
        }, tK, kK), (0, XO.f)(null, null, EO, {
          kind: "field",
          name: "interaxialDistance",
          static: !1,
          private: !1,
          access: {
            has: OO => "interaxialDistance" in OO,
            get: OO => OO.interaxialDistance,
            set: (OO, KO) => {
              OO.interaxialDistance = KO
            }
          },
          metadata: eO
        }, UO, OK), (0, XO.f)(null, null, jK, {
          kind: "field",
          name: "isStereoscopicSideBySide",
          static: !1,
          private: !1,
          access: {
            has: OO => "isStereoscopicSideBySide" in OO,
            get: OO => OO.isStereoscopicSideBySide,
            set: (OO, KO) => {
              OO.isStereoscopicSideBySide = KO
            }
          },
          metadata: eO
        }, KK, pK), (0, XO.f)(null, null, YO, {
          kind: "field",
          name: "ignoreCameraMaxZ",
          static: !1,
          private: !1,
          access: {
            has: OO => "ignoreCameraMaxZ" in OO,
            get: OO => OO.ignoreCameraMaxZ,
            set: (OO, KO) => {
              OO.ignoreCameraMaxZ = KO
            }
          },
          metadata: eO
        }, XK, bp), eO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: eO
        })
      })(), OO._CreateDefaultParsedCamera = (OO, KO) => {
        throw (0, MO.j)("UniversalCamera")
      }, OO.PERSPECTIVE_CAMERA = 0, OO.ORTHOGRAPHIC_CAMERA = 1, OO.FOVMODE_VERTICAL_FIXED = 0, OO.FOVMODE_HORIZONTAL_FIXED = 1, OO.RIG_MODE_NONE = 0, OO.RIG_MODE_STEREOSCOPIC_ANAGLYPH = 10, OO.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_PARALLEL = 11, OO.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_CROSSEYED = 12, OO.RIG_MODE_STEREOSCOPIC_OVERUNDER = 13, OO.RIG_MODE_STEREOSCOPIC_INTERLACED = 14, OO.RIG_MODE_VR = 20, OO.RIG_MODE_CUSTOM = 22, OO.ForceAttachControlToAlwaysPreventDefault = !1, OO
    })();

    function QO(OO, KO) {
      const pO = OO.type,
        XO = LO.GetConstructorFromName(pO, OO.name, KO, OO.interaxial_distance, OO.isStereoscopicSideBySide),
        bK = VO.c.Parse(XO, OO, KO);
      if (void 0 !== OO.parentId && (bK._waitingParentId = OO.parentId), void 0 !== OO.parentInstanceIndex && (bK._waitingParentInstanceIndex = OO.parentInstanceIndex), bK.inputs && (bK.inputs.parse(OO), bK._setupInputs()), OO.upVector && (bK.upVector = vK.o.FromArray(OO.upVector)), bK.setPosition && (bK.position.rvO(0, 0, 0), bK.setPosition(vK.o.FromArray(OO.position))), OO.target && bK.setTarget && bK.setTarget(vK.o.FromArray(OO.target)), OO.cameraRigMode) {
        const KO = OO.interaxial_distance ? {
          interaxialDistance: OO.interaxial_distance
        } : {};
        bK.setCameraRigMode(OO.cameraRigMode, KO)
      }
      if (OO.animations) {
        for (let KO = 0; KO < OO.animations.length; KO++) {
          const pO = OO.animations[KO],
            XO = (0, DO.e)("BABYLON.Animation");
          XO && bK.animations.push(XO.Parse(pO))
        }
        CO.c.ParseAnimationRanges(bK, OO, KO)
      }
      return OO.autoAnimate && KO.beginAnimation(bK, OO.autoAnimateFrom, OO.autoAnimateTo, OO.autoAnimateLoop, OO.autoAnimateSpeed || 1), void 0 !== OO.isEnabled && bK.WE(OO.isEnabled), bK
    }
    let zK = !1;

    function AO() {
      zK || (zK = !0, LO.Parse = QO)
    }
  },
  38319: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(35632);
    class bK {
      constructor(OO, KO, pO) {
        this._cameraPosition = KO, this._behavior = pO, this.activeInput = !1, this.speed = 1, this.ObO = 1, this.panSpeed = 1, this.rotationXSpeed = 1, this.rotationYSpeed = 1, this._zoomSpeedMultiplier = 1, this._panSpeedMultiplier = 1, this.zoomInertia = .9, this.panInertia = .9, this.rotationInertia = .9, this.zoomAccumulatedPixels = 0, this.panAccumulatedPixels = new XO.o, this.rotationAccumulatedPixels = new XO.o, this.zoomDeltaCurrentFrame = 0, this.panDeltaCurrentFrame = XO.o.Zero(), this.rotationDeltaCurrentFrame = XO.o.Zero(), this._zoomVelocity = 0, this._panVelocity = new XO.o, this.referenceFrameRate = 60, this._rotationVelocity = new XO.o, this._prevFrameTimeMs = 0, this._scene = OO
      }
      computeCurrentFrameDeltas() {
        const OO = this._scene.qb().getDeltaTime(),
          KO = this._getEffectiveDeltaMs(OO);
        if (0 === this._zoomVelocity && 0 === this.zoomAccumulatedPixels && 0 === this._panVelocity.x && 0 === this._panVelocity.y && 0 === this._panVelocity.z && 0 === this.panAccumulatedPixels.x && 0 === this.panAccumulatedPixels.y && 0 === this.panAccumulatedPixels.z && 0 === this._rotationVelocity.x && 0 === this._rotationVelocity.y && 0 === this._rotationVelocity.z && 0 === this.rotationAccumulatedPixels.x && 0 === this.rotationAccumulatedPixels.y && 0 === this.rotationAccumulatedPixels.z && !this.activeInput) return this.panDeltaCurrentFrame.plO(0), this.rotationDeltaCurrentFrame.plO(0), this.zoomDeltaCurrentFrame = 0, void(OO > 0 && (this._prevFrameTimeMs = OO));
        this.panDeltaCurrentFrame.plO(0), this.rotationDeltaCurrentFrame.plO(0), this.zoomDeltaCurrentFrame = 0;
        (this.panAccumulatedPixels.lengthSquared() > 0 || this.rotationAccumulatedPixels.lengthSquared() > 0 || 0 !== this.zoomAccumulatedPixels) && this._behavior?.isInterpolating && this._behavior.stopAllAnimations(), this._panVelocity.rvO(this._calculateCurrentVelocity(this._panVelocity.x, this.panAccumulatedPixels.x, this.panInertia), this._calculateCurrentVelocity(this._panVelocity.y, this.panAccumulatedPixels.y, this.panInertia), this._calculateCurrentVelocity(this._panVelocity.z, this.panAccumulatedPixels.z, this.panInertia)), this._panVelocity.scaleToRef(this.speed * this.panSpeed * this._panSpeedMultiplier * KO, this.panDeltaCurrentFrame), this._rotationVelocity.rvO(this._calculateCurrentVelocity(this._rotationVelocity.x, this.rotationAccumulatedPixels.x, this.rotationInertia), this._calculateCurrentVelocity(this._rotationVelocity.y, this.rotationAccumulatedPixels.y, this.rotationInertia), this._calculateCurrentVelocity(this._rotationVelocity.z, this.rotationAccumulatedPixels.z, this.rotationInertia)), this.rotationDeltaCurrentFrame.rvO(this._rotationVelocity.x * this.speed * this.rotationXSpeed * KO, this._rotationVelocity.y * this.speed * this.rotationYSpeed * KO, 0), this._zoomVelocity = this._calculateCurrentVelocity(this._zoomVelocity, this.zoomAccumulatedPixels, this.zoomInertia), this.zoomDeltaCurrentFrame = this._zoomVelocity * (this.speed * this.ObO * this._zoomSpeedMultiplier) * KO, OO > 0 && (this._prevFrameTimeMs = OO), this.zoomAccumulatedPixels = 0, this.panAccumulatedPixels.plO(0), this.rotationAccumulatedPixels.plO(0), this.activeInput = !1
      }
      resetRotationVelocity() {
        this._rotationVelocity.plO(0), this.rotationAccumulatedPixels.plO(0)
      }
      resetPanVelocity() {
        this._panVelocity.plO(0), this.panAccumulatedPixels.plO(0)
      }
      resetZoomVelocity() {
        this._zoomVelocity = 0, this.zoomAccumulatedPixels = 0
      }
      get isInterpolating() {
        return !!this._behavior?.isInterpolating
      }
      getFrameIndependentDecay(OO) {
        const KO = this._scene.qb().getDeltaTime(),
          pO = this._getEffectiveDeltaMs(KO),
          XO = 1e3 / this.referenceFrameRate;
        return Math.pow(OO, pO / XO)
      }
      getFrameIndependentInputScale(OO) {
        const KO = 1 - OO;
        if (KO <= 0) return 1;
        return (1 - this.getFrameIndependentDecay(OO)) / KO
      }
      _getEffectiveDeltaMs(OO) {
        return OO > 0 ? OO : this._prevFrameTimeMs > 0 ? this._prevFrameTimeMs : 1e3 / this.referenceFrameRate
      }
      _calculateCurrentVelocity(OO, KO, pO) {
        let XO = OO;
        const bK = this._scene.qb().getDeltaTime(),
          eO = this._getEffectiveDeltaMs(bK);
        if (0 === eO) return XO;
        const lO = this.getFrameIndependentDecay(pO);
        if (XO *= lO, 0 !== KO || this.activeInput) {
          const OO = 1 - pO;
          XO += KO / eO * (OO > 0 ? (1 - lO) / OO : 1)
        } else Math.abs(XO) < 1e-6 && (XO = 0);
        return XO
      }
    }
  },
  38322: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    class XO {
      constructor(OO, KO) {
        this.inputMap = [], this.handlers = OO, this._createDefaultEntries = KO, this.resetInputMap()
      }
      resolveInteraction(OO, KO) {
        for (const pO of this.inputMap)
          if (pO.source === OO && this._entryMatches(pO, KO)) return pO;
        return null
      }
      resetInputMap() {
        this.inputMap = this._createDefaultEntries?.() ?? []
      }
      getEntry(OO, KO, pO) {
        const XO = this.inputMap;
        for (let bK = 0; bK < XO.length; bK++) {
          const eO = XO[bK];
          if (eO.source === OO && eO.interaction === KO && this._entryConditionsMatch(eO, pO)) return eO
        }
      }
      getEntries(OO, KO, pO) {
        const XO = [],
          bK = this.inputMap;
        for (let eO = 0; eO < bK.length; eO++) {
          const lO = bK[eO];
          lO.source === OO && lO.interaction === KO && this._entryConditionsMatch(lO, pO) && XO.push(lO)
        }
        return XO
      }
      addEntry(OO) {
        const KO = this._entrySpecificity(OO);
        let pO = this.inputMap.length;
        for (let XO = 0; XO < this.inputMap.length; XO++)
          if (this._entrySpecificity(this.inputMap[XO]) < KO) {
            pO = XO;
            break
          } this.inputMap.splice(pO, 0, OO)
      }
      setInteraction(OO, KO, pO) {
        const XO = this.resolveInteraction(OO, KO);
        return XO && this._entryCoversAllConditionsOf(XO, KO) ? (XO.interaction = pO, !0) : (this.addEntry({
          source: OO,
          ...KO ?? {},
          interaction: pO
        }), !0)
      }
      _entryCoversAllConditionsOf(OO, KO) {
        if (!KO) return !0;
        const pO = OO;
        for (const XO of Object.keys(KO)) {
          const OO = KO[XO];
          if (void 0 !== OO)
            if ("modifiers" === XO) {
              const KO = pO.modifiers ?? {};
              for (const pO of Object.keys(OO))
                if (void 0 !== OO[pO] && void 0 === KO[pO]) return !1
            } else if (void 0 === pO[XO]) return !1
        }
        return !0
      }
      setInteractions(OO, KO, pO) {
        let XO = 0;
        const bK = this.inputMap;
        for (let eO = 0; eO < bK.length; eO++) {
          const lO = bK[eO];
          lO.source === OO && this._entryMatches(lO, KO) && (lO.interaction = pO, XO++)
        }
        return XO
      }
      _entryMatches(OO, KO) {
        switch (OO.source) {
          case "pointer":
            return (void 0 === OO.button || OO.button === KO?.button) && this._matchModifiers(OO.modifiers, KO?.modifiers);
          case "wheel":
            return this._matchModifiers(OO.modifiers, KO?.modifiers);
          case "touch":
            return void 0 === OO.touchCount || OO.touchCount === KO?.touchCount;
          case "keyboard":
            return (void 0 === OO.key || (Array.isArray(OO.key) ? -1 !== OO.key.indexOf(KO?.key ?? -1) : OO.key === KO?.key)) && this._matchModifiers(OO.modifiers, KO?.modifiers)
        }
      }
      _entryConditionsMatch(OO, KO) {
        if (!KO) return !0;
        switch (OO.source) {
          case "pointer":
            return (!("button" in KO) || OO.button === KO.button) && (!("modifiers" in KO) || this._entryModifiersMatch(OO.modifiers, KO.modifiers));
          case "wheel":
            return !("modifiers" in KO) || this._entryModifiersMatch(OO.modifiers, KO.modifiers);
          case "touch":
            return !("touchCount" in KO) || OO.touchCount === KO.touchCount;
          case "keyboard":
            if ("key" in KO) {
              if (void 0 === OO.key) return void 0 === KO.key;
              if (void 0 === KO.key || (Array.isArray(OO.key) ? -1 === OO.key.indexOf(KO.key) : OO.key !== KO.key)) return !1
            }
            return !("modifiers" in KO) || this._entryModifiersMatch(OO.modifiers, KO.modifiers)
        }
      }
      _entrySpecificity(OO) {
        let KO = 0;
        return "button" in OO && void 0 !== OO.button && KO++, "key" in OO && void 0 !== OO.key && KO++, "touchCount" in OO && void 0 !== OO.touchCount && KO++, "modifiers" in OO && OO.modifiers && KO++, KO
      }
      _matchModifiers(OO, KO) {
        return !OO || (void 0 === OO.ctrl || OO.ctrl === (KO?.ctrl ?? !1)) && ((void 0 === OO.shift || OO.shift === (KO?.shift ?? !1)) && (void 0 === OO.alt || OO.alt === (KO?.alt ?? !1)))
      }
      _entryModifiersMatch(OO, KO) {
        if (!KO) return !OO;
        return void 0 !== KO.ctrl || void 0 !== KO.shift || void 0 !== KO.alt ? (void 0 === KO.ctrl || OO?.ctrl === KO.ctrl) && ((void 0 === KO.shift || OO?.shift === KO.shift) && (void 0 === KO.alt || OO?.alt === KO.alt)) : !OO || void 0 === OO.ctrl && void 0 === OO.shift && void 0 === OO.alt
      }
    }
  },
  38287: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => QO,
      f: () => VO
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(38294),
      lO = pO(35632),
      vK = pO(35639),
      CO = pO(38310),
      hO = pO(38301),
      DO = pO(38319),
      MO = pO(38322);
    class aK extends DO.c {
      constructor(OO, KO, pO) {
        super(OO, KO, pO), this.input = new MO.e({
          translate: (OO, KO, pO) => {
            this.panAccumulatedPixels.x += OO, this.panAccumulatedPixels.y += KO, this.panAccumulatedPixels.z += pO
          },
          rotate: (OO, KO) => {
            this.rotationAccumulatedPixels.x += OO, this.rotationAccumulatedPixels.y += KO
          }
        }, (() => this._createDefaultInputMap()))
      }
      _createDefaultInputMap() {
        return [{
          source: "pointer",
          interaction: "rotate"
        }, {
          source: "keyboard",
          interaction: "translate"
        }, {
          source: "keyboard",
          interaction: "rotate"
        }, {
          source: "touch",
          interaction: "rotate"
        }, {
          source: "touch",
          interaction: "translate"
        }]
      }
    }
    const oO = lO.c.Zero(),
      FO = lO.g.Identity();
    let VO = (() => {
        var OO;
        let KO, pO, hO, DO, MO = eO.c,
          VO = [],
          LO = [],
          QO = [],
          zK = [],
          AO = [],
          fO = [],
          dO = [],
          TO = [];
        return OO = class extends MO {
          get inertia() {
            return this._targetInertia
          }
          set inertia(OO) {
            this._targetInertia = OO, this.movement && (this.movement.panInertia = OO, this.movement.rotationInertia = OO)
          }
          constructor(OO, KO, pO) {
            super(OO, KO, pO, !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3]), this.cameraDirection = new lO.o(0, 0, 0), this.cameraRotation = new lO.m(0, 0), this._targetInertia = .9, this.updateUpVectorFromRotation = (0, XO.i)(this, VO, !1), this.rotation = ((0, XO.i)(this, LO), (0, XO.i)(this, QO, void 0)), this.rotationQuaternion = (0, XO.i)(this, zK), this.speed = (0, XO.i)(this, AO, 2), this.noRotationConstraint = ((0, XO.i)(this, fO), !1), this.invertRotation = !1, this.inverseRotationSpeed = .2, this._panningEpsilon = vK.c, this._rotationEpsilon = vK.c, this.lockedTarget = (0, XO.i)(this, dO, null), this._currentTarget = ((0, XO.i)(this, TO), lO.o.Zero()), this._initialFocalDistance = 1, this._viewMatrix = lO.c.Zero(), this._cameraTransformMatrix = lO.c.Zero(), this._cameraRotationMatrix = lO.c.Zero(), this._transformedReferencePoint = lO.o.Zero(), this._deferredPositionUpdate = new lO.o, this._deferredRotationQuaternionUpdate = new lO.g, this._deferredRotationUpdate = new lO.o, this._deferredUpdated = !1, this._deferOnly = !1, this._cachedRotationZ = 0, this._cachedQuaternionRotationZ = 0, this._referencePoint = lO.o.Forward(this.JKO().useRightHandedSystem), this.rotation = new lO.o(0, this.JKO().useRightHandedSystem ? Math.PI : 0, 0), this.movement = new aK(this.JKO(), this.position), this.movement.panInertia = this.inertia, this.movement.rotationInertia = this.inertia
          }
          getFrontPosition(OO) {
            this.getWorldMatrix();
            const KO = lO.j.WX[0],
              pO = lO.j.WX[1];
            return pO.set(0, 0, this._scene.useRightHandedSystem ? -1 : 1), this.getDirectionToRef(pO, KO), KO.scaleInPlace(OO), this.globalPosition.add(KO)
          }
          _getLockedTargetPosition() {
            if (!this.lockedTarget) return null;
            if (this.lockedTarget.absolutePosition) {
              const OO = this.lockedTarget;
              OO.computeWorldMatrix().getTranslationToRef(OO.absolutePosition)
            }
            return this.lockedTarget.absolutePosition || this.lockedTarget
          }
          storeState() {
            return this._storedPosition = this.position.clone(), this._storedRotation = this.rotation.clone(), this.rotationQuaternion && (this._storedRotationQuaternion = this.rotationQuaternion.clone()), super.storeState()
          }
          _restoreStateValues() {
            return !!super._restoreStateValues() && (this.position = this._storedPosition.clone(), this.rotation = this._storedRotation.clone(), this.rotationQuaternion && this._storedRotationQuaternion && (this.rotationQuaternion = this._storedRotationQuaternion.clone()), this.cameraDirection.rvO(0, 0, 0), this.cameraRotation.rvO(0, 0), !0)
          }
          _initCache() {
            super._initCache(), this._cache.lockedTarget = new lO.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), this._cache.rotation = new lO.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), this._cache.rotationQuaternion = new lO.g(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE)
          }
          _updateCache(OO) {
            OO || super._updateCache();
            const KO = this._getLockedTargetPosition();
            KO ? this._cache.lockedTarget ? this._cache.lockedTarget.NhO(KO) : this._cache.lockedTarget = KO.clone() : this._cache.lockedTarget = null, this._cache.rotation.NhO(this.rotation), this.rotationQuaternion && this._cache.rotationQuaternion.NhO(this.rotationQuaternion)
          }
          _isSynchronizedViewMatrix() {
            if (!super._isSynchronizedViewMatrix()) return !1;
            const OO = this._getLockedTargetPosition();
            return (this._cache.lockedTarget ? this._cache.lockedTarget.equals(OO) : !OO) && (this.rotationQuaternion ? this.rotationQuaternion.equals(this._cache.rotationQuaternion) : this._cache.rotation.equals(this.rotation))
          }
          _computeLocalCameraSpeed() {
            const OO = this.qb();
            return this.speed * Math.sqrt(OO.getDeltaTime() / (100 * OO.getFps()))
          }
          setTarget(OO) {
            this.upVector.normalize(), this._initialFocalDistance = OO.subtract(this.position).length(), this.position.z === OO.z && (this.position.z += vK.c), this._referencePoint.normalize().scaleInPlace(this._initialFocalDistance), this.JKO().useRightHandedSystem ? lO.c.LookAtRHToRef(this.position, OO, lO.o.UpReadOnly, oO) : lO.c.LookAtLHToRef(this.position, OO, lO.o.UpReadOnly, oO), oO.invert();
            const KO = this.rotationQuaternion || FO;
            lO.g.FromRotationMatrixToRef(oO, KO), KO.toEulerAnglesToRef(this.rotation), this.rotation.z = 0
          }
          get target() {
            return this.getTarget()
          }
          set target(OO) {
            this.setTarget(OO)
          }
          getTarget() {
            return this._currentTarget
          }
          _decideIfNeedsToMove() {
            return Math.abs(this.cameraDirection.x) > 0 || Math.abs(this.cameraDirection.y) > 0 || Math.abs(this.cameraDirection.z) > 0
          }
          _updatePosition() {
            if (this.parent) return this.parent.getWorldMatrix().invertToRef(lO.j.Matrix[0]), lO.o.TransformNormalToRef(this.cameraDirection, lO.j.Matrix[0], lO.j.WX[0]), this._deferredPositionUpdate.addInPlace(lO.j.WX[0]), void(this._deferOnly ? this._deferredUpdated = !0 : this.position.NhO(this._deferredPositionUpdate));
            this._deferredPositionUpdate.addInPlace(this.cameraDirection), this._deferOnly ? this._deferredUpdated = !0 : this.position.NhO(this._deferredPositionUpdate)
          }
          _checkInputs() {
            const OO = this.movement,
              KO = 0 !== this.cameraDirection.x || 0 !== this.cameraDirection.y || 0 !== this.cameraDirection.z;
            OO.panAccumulatedPixels.addInPlace(this.cameraDirection), OO.rotationAccumulatedPixels.x += this.cameraRotation.x, OO.rotationAccumulatedPixels.y += this.cameraRotation.y, OO.computeCurrentFrameDeltas(), this.cameraDirection.NhO(OO.panDeltaCurrentFrame), this.cameraRotation.set(OO.rotationDeltaCurrentFrame.x, OO.rotationDeltaCurrentFrame.y);
            const pO = this.speed * this._panningEpsilon;
            !KO && Math.abs(this.cameraDirection.x) < pO && Math.abs(this.cameraDirection.y) < pO && Math.abs(this.cameraDirection.z) < pO && (this.cameraDirection.plO(0), OO.resetPanVelocity());
            const XO = this.invertRotation ? -this.inverseRotationSpeed : 1,
              bK = this._decideIfNeedsToMove(),
              eO = !(!this.cameraRotation.x && !this.cameraRotation.y);
            if (this._deferredUpdated = !1, this._deferredRotationUpdate.NhO(this.rotation), this._deferredPositionUpdate.NhO(this.position), this.rotationQuaternion && this._deferredRotationQuaternionUpdate.NhO(this.rotationQuaternion), bK && this._updatePosition(), eO) {
              if (this.rotationQuaternion && this.rotationQuaternion.toEulerAnglesToRef(this._deferredRotationUpdate), this._deferredRotationUpdate.x += this.cameraRotation.x * XO, this._deferredRotationUpdate.y += this.cameraRotation.y * XO, !this.noRotationConstraint) {
                const OO = 1.570796;
                this._deferredRotationUpdate.x > OO && (this._deferredRotationUpdate.x = OO), this._deferredRotationUpdate.x < -OO && (this._deferredRotationUpdate.x = -OO)
              }
              if (this._deferOnly ? this._deferredUpdated = !0 : this.rotation.NhO(this._deferredRotationUpdate), this.rotationQuaternion) {
                this._deferredRotationUpdate.lengthSquared() && (lO.g.RotationYawPitchRollToRef(this._deferredRotationUpdate.y, this._deferredRotationUpdate.x, this._deferredRotationUpdate.z, this._deferredRotationQuaternionUpdate), this._deferOnly ? this._deferredUpdated = !0 : this.rotationQuaternion.NhO(this._deferredRotationQuaternionUpdate))
              }
            }
            this.cameraDirection.plO(0), this.cameraRotation.set(0, 0), super._checkInputs()
          }
          _updateCameraRotationMatrix() {
            this.rotationQuaternion ? this.rotationQuaternion.toRotationMatrix(this._cameraRotationMatrix) : lO.c.RotationYawPitchRollToRef(this.rotation.y, this.rotation.x, this.rotation.z, this._cameraRotationMatrix)
          }
          _rotateUpVectorWithCameraRotationMatrix() {
            return lO.o.TransformNormalToRef(lO.o.UpReadOnly, this._cameraRotationMatrix, this.upVector), this
          }
          _getViewMatrix() {
            return this.lockedTarget && this.setTarget(this._getLockedTargetPosition()), this._updateCameraRotationMatrix(), this.rotationQuaternion && this._cachedQuaternionRotationZ != this.rotationQuaternion.z ? (this._rotateUpVectorWithCameraRotationMatrix(), this._cachedQuaternionRotationZ = this.rotationQuaternion.z) : this._cachedRotationZ !== this.rotation.z && (this._rotateUpVectorWithCameraRotationMatrix(), this._cachedRotationZ = this.rotation.z), lO.o.TransformCoordinatesToRef(this._referencePoint, this._cameraRotationMatrix, this._transformedReferencePoint), this.position.addToRef(this._transformedReferencePoint, this._currentTarget), this.updateUpVectorFromRotation && (this.rotationQuaternion ? CO.b.Y.rotateByQuaternionToRef(this.rotationQuaternion, this.upVector) : (lO.g.FromEulerVectorToRef(this.rotation, FO), CO.b.Y.rotateByQuaternionToRef(FO, this.upVector))), this._computeViewMatrix(this.position, this._currentTarget, this.upVector), this._viewMatrix
          }
          _computeViewMatrix(OO, KO, pO) {
            if (this.JKO().useRightHandedSystem ? lO.c.LookAtRHToRef(OO, KO, pO, this._viewMatrix) : lO.c.LookAtLHToRef(OO, KO, pO, this._viewMatrix), this.parent) {
              const OO = this.parent.getWorldMatrix();
              this._viewMatrix.invert(), this._viewMatrix.multiplyToRef(OO, this._viewMatrix), this._viewMatrix.invert(), this._markSyncedWithParent()
            }
          }
          createRigCamera(KO, pO) {
            if (this.cameraRigMode !== eO.c.RIG_MODE_NONE) {
              const pO = new OO(KO, this.position.clone(), this.JKO());
              return pO.isRigCamera = !0, pO.rigParent = this, this.cameraRigMode === eO.c.RIG_MODE_VR && (this.rotationQuaternion || (this.rotationQuaternion = new lO.g), pO._cameraRigParams = {}, pO.rotationQuaternion = new lO.g), pO.mode = this.mode, pO.orthoLeft = this.orthoLeft, pO.orthoRight = this.orthoRight, pO.orthoTop = this.orthoTop, pO.orthoBottom = this.orthoBottom, pO
            }
            return null
          }
          _updateRigCameras() {
            const OO = this._rigCameras[0],
              KO = this._rigCameras[1];
            switch (this.computeWorldMatrix(), this.cameraRigMode) {
              case eO.c.RIG_MODE_STEREOSCOPIC_ANAGLYPH:
              case eO.c.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_PARALLEL:
              case eO.c.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_CROSSEYED:
              case eO.c.RIG_MODE_STEREOSCOPIC_OVERUNDER:
              case eO.c.RIG_MODE_STEREOSCOPIC_INTERLACED: {
                const pO = this.cameraRigMode === eO.c.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_CROSSEYED ? 1 : -1,
                  XO = this.cameraRigMode === eO.c.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_CROSSEYED ? -1 : 1;
                this._getRigCamPositionAndTarget(this._cameraRigParams.stereoHalfAngle * pO, OO), this._getRigCamPositionAndTarget(this._cameraRigParams.stereoHalfAngle * XO, KO);
                break
              }
              case eO.c.RIG_MODE_VR:
                OO.rotationQuaternion && KO.rotationQuaternion && this.rotationQuaternion ? (OO.rotationQuaternion.NhO(this.rotationQuaternion), KO.rotationQuaternion.NhO(this.rotationQuaternion)) : (OO.rotation.NhO(this.rotation), KO.rotation.NhO(this.rotation)), OO.position.NhO(this.position), KO.position.NhO(this.position)
            }
            super._updateRigCameras()
          }
          _getRigCamPositionAndTarget(KO, pO) {
            this.getTarget().subtractToRef(this.position, OO._TargetFocalPoint), OO._TargetFocalPoint.normalize().scaleInPlace(this._initialFocalDistance);
            const XO = OO._TargetFocalPoint.addInPlace(this.position);
            lO.c.TranslationToRef(-XO.x, -XO.y, -XO.z, OO._TargetTransformMatrix), OO._TargetTransformMatrix.multiplyToRef(lO.c.RotationAxis(pO.upVector, KO), OO._RigCamTransformMatrix), lO.c.TranslationToRef(XO.x, XO.y, XO.z, OO._TargetTransformMatrix), OO._RigCamTransformMatrix.multiplyToRef(OO._TargetTransformMatrix, OO._RigCamTransformMatrix), lO.o.TransformCoordinatesToRef(this.position, OO._RigCamTransformMatrix, pO.position), pO.setTarget(XO)
          }
          getClassName() {
            return "TargetCamera"
          }
        }, (() => {
          const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(MO[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.M)()], pO = [(0, bK.L)()], hO = [(0, bK.M)()], DO = [(0, bK.D)("lockedTargetId")], (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "updateUpVectorFromRotation",
            static: !1,
            private: !1,
            access: {
              has: OO => "updateUpVectorFromRotation" in OO,
              get: OO => OO.updateUpVectorFromRotation,
              set: (OO, KO) => {
                OO.updateUpVectorFromRotation = KO
              }
            },
            metadata: eO
          }, VO, LO), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "rotation",
            static: !1,
            private: !1,
            access: {
              has: OO => "rotation" in OO,
              get: OO => OO.rotation,
              set: (OO, KO) => {
                OO.rotation = KO
              }
            },
            metadata: eO
          }, QO, zK), (0, XO.f)(null, null, hO, {
            kind: "field",
            name: "speed",
            static: !1,
            private: !1,
            access: {
              has: OO => "speed" in OO,
              get: OO => OO.speed,
              set: (OO, KO) => {
                OO.speed = KO
              }
            },
            metadata: eO
          }, AO, fO), (0, XO.f)(null, null, DO, {
            kind: "field",
            name: "lockedTarget",
            static: !1,
            private: !1,
            access: {
              has: OO => "lockedTarget" in OO,
              get: OO => OO.lockedTarget,
              set: (OO, KO) => {
                OO.lockedTarget = KO
              }
            },
            metadata: eO
          }, dO, TO), eO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: eO
          })
        })(), OO._RigCamTransformMatrix = new lO.c, OO._TargetTransformMatrix = new lO.c, OO._TargetFocalPoint = new lO.o, OO
      })(),
      LO = !1;

    function QO() {
      LO || (LO = !0, hO.c.AddNodeConstructor("TargetCamera", ((OO, KO) => () => new VO(OO, lO.o.Zero(), KO))))
    }
  },
  38016: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO
    });
    var XO = pO(37962);
    let bK = !1;

    function eO() {
      bK || (bK = !0, XO.e.prototype.getInputElement = function() {
        return this._renderingCanvas
      }, XO.e.prototype.getRenderingCanvasClientRect = function() {
        return this._renderingCanvas ? this._renderingCanvas.getBoundingClientRect() : null
      }, XO.e.prototype.getInputElementClientRect = function() {
        return this._renderingCanvas ? this.getInputElement().getBoundingClientRect() : null
      }, XO.e.prototype.getAspectRatio = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = OO.viewport;
        return this.getRenderWidth(KO) * pO.width / (this.getRenderHeight(KO) * pO.height)
      }, XO.e.prototype.getScreenAspectRatio = function() {
        return this.getRenderWidth(!0) / this.getRenderHeight(!0)
      }, XO.e.prototype._verifyPointerLock = function() {
        this._onPointerLockChange?.()
      })
    }
  },
  38099: (OO, KO, pO) => {
    var XO = pO(37962),
      bK = pO(38104);
    let eO = !1;
    eO || (eO = !0, (0, bK.v)(), XO.e.prototype._loadFileAsync = async function(OO, KO, pO) {
      return await new Promise(((XO, bK) => {
        this._loadFile(OO, (OO => {
          XO(OO)
        }), void 0, KO, pO, ((OO, KO) => {
          bK(KO)
        }))
      }))
    })
  },
  38092: (OO, KO, pO) => {
    (0, pO(38021).e)()
  },
  38021: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(37962);
    let bK = !1;

    function eO() {
      bK || (bK = !0, XO.e.prototype.getRenderPassNames = function() {
        return this._renderPassNames
      }, XO.e.prototype.getCurrentRenderPassName = function() {
        return this._renderPassNames[this.currentRenderPassId]
      }, XO.e.prototype.createRenderPassId = function(OO) {
        const KO = ++XO.e._RenderPassIdCounter;
        return this._renderPassNames[KO] = OO ?? "NONAME", KO
      }, XO.e.prototype.releaseRenderPassId = function(OO) {
        this._renderPassNames[OO] = void 0;
        for (let KO = 0; KO < this.scenes.length; ++KO) {
          const pO = this.scenes[KO];
          for (let KO = 0; KO < pO.meshes.length; ++KO) {
            const XO = pO.meshes[KO];
            if (XO._releaseRenderPassId(OO), XO.au)
              for (let KO = 0; KO < XO.au.length; ++KO) {
                XO.au[KO]._removeDrawWrapper(OO)
              }
          }
        }
        this._onReleaseRenderPassObservable?.notifyObservers(OO)
      })
    }
  },
  38149: (OO, KO, pO) => {
    var XO = pO(38157),
      bK = pO(37962);
    let eO = !1;
    eO || (eO = !0, bK.e.GetCompatibleTextureLoader = XO.e)
  },
  38024: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO
    });
    var XO = pO(37899);
    let bK = !1;

    function eO() {
      bK || (bK = !0, XO.ThinEngine.prototype.setAlphaMode = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        if (this._alphaMode[pO] === OO) {
          if (!KO) {
            const KO = 0 === OO;
            this.depthCullingState.depthMask !== KO && (this.depthCullingState.depthMask = KO)
          }
          return
        }
        const XO = 0 === OO;
        this._alphaState.setAlphaBlend(!XO, pO), this._alphaState.setAlphaMode(OO, pO), KO || (this.depthCullingState.depthMask = XO), this._alphaMode[pO] = OO
      })
    }
  },
  38038: (OO, KO, pO) => {
    var XO = pO(37889),
      bK = pO(37061),
      eO = pO(37899),
      lO = pO(38041),
      vK = pO(38004);
    class CO extends lO.c {
      setDepthStencilTexture(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (super.setDepthStencilTexture(OO, KO), !OO) return;
        const pO = this._engine,
          XO = this._context,
          bK = OO._hardwareTexture;
        if (bK && OO._autoMSAAManagement && this._MSAAFramebuffer) {
          const KO = pO._currentFramebuffer;
          pO._bindUnboundFramebuffer(this._MSAAFramebuffer), XO.framebufferRenderbuffer(XO.FRAMEBUFFER, (0, vK.d)(OO.format) ? XO.DEPTH_STENCIL_ATTACHMENT : XO.DEPTH_ATTACHMENT, XO.RENDERBUFFER, bK.getMSAARenderBuffer()), pO._bindUnboundFramebuffer(KO)
        }
      }
      constructor(OO, KO, pO, XO, bK) {
        super(OO, KO, pO, XO), this._framebuffer = null, this._depthStencilBuffer = null, this._MSAAFramebuffer = null, this._colorTextureArray = null, this._depthStencilTextureArray = null, this._disposeOnlyFramebuffers = !1, this._currentLOD = 0, this._context = bK
      }
      _cloneRenderTargetWrapper() {
        let OO;
        return this._colorTextureArray && this._depthStencilTextureArray ? (OO = this._engine.createMultiviewRenderTargetTexture(this.width, this.height), OO.texture.isReady = !0) : OO = super._cloneRenderTargetWrapper(), OO
      }
      _swapRenderTargetWrapper(OO) {
        super._swapRenderTargetWrapper(OO), OO._framebuffer = this._framebuffer, OO._depthStencilBuffer = this._depthStencilBuffer, OO._MSAAFramebuffer = this._MSAAFramebuffer, OO._colorTextureArray = this._colorTextureArray, OO._depthStencilTextureArray = this._depthStencilTextureArray, this._framebuffer = this._depthStencilBuffer = this._MSAAFramebuffer = this._colorTextureArray = this._depthStencilTextureArray = null
      }
      createDepthStencilTexture() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 14,
          eO = arguments.length > 5 ? arguments[5] : void 0;
        if (this._depthStencilBuffer) {
          const OO = this._engine,
            KO = OO._currentFramebuffer,
            pO = this._context;
          OO._bindUnboundFramebuffer(this._framebuffer), pO.framebufferRenderbuffer(pO.FRAMEBUFFER, pO.DEPTH_STENCIL_ATTACHMENT, pO.RENDERBUFFER, null), pO.framebufferRenderbuffer(pO.FRAMEBUFFER, pO.DEPTH_ATTACHMENT, pO.RENDERBUFFER, null), pO.framebufferRenderbuffer(pO.FRAMEBUFFER, pO.STENCIL_ATTACHMENT, pO.RENDERBUFFER, null), OO._bindUnboundFramebuffer(KO), pO.deleteRenderbuffer(this._depthStencilBuffer), this._depthStencilBuffer = null
        }
        return super.createDepthStencilTexture(OO, KO, pO, XO, bK, eO)
      }
      shareDepth(OO) {
        super.shareDepth(OO);
        const KO = this._context,
          pO = this._depthStencilBuffer,
          XO = OO._MSAAFramebuffer || OO._framebuffer,
          bK = this._engine;
        OO._depthStencilBuffer && OO._depthStencilBuffer !== pO && KO.deleteRenderbuffer(OO._depthStencilBuffer), OO._depthStencilBuffer = pO;
        const eO = OO._generateStencilBuffer ? KO.DEPTH_STENCIL_ATTACHMENT : KO.DEPTH_ATTACHMENT;
        bK._bindUnboundFramebuffer(XO), KO.framebufferRenderbuffer(KO.FRAMEBUFFER, eO, KO.RENDERBUFFER, pO), bK._bindUnboundFramebuffer(null)
      }
      _bindTextureRenderTarget(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        const bK = OO._hardwareTexture;
        if (!bK) return;
        const eO = this._framebuffer,
          lO = this._engine,
          vK = lO._currentFramebuffer;
        let CO;
        if (lO._bindUnboundFramebuffer(eO), lO.ye > 1) {
          const eO = this._context;
          CO = eO["COLOR_ATTACHMENT" + KO], OO.is2DArray || OO.is3D ? (pO = pO ?? this.layerIndices?.[KO] ?? 0, eO.framebufferTextureLayer(eO.FRAMEBUFFER, CO, bK.underlyingResource, XO, pO)) : OO.isCube ? (pO = pO ?? this.faceIndices?.[KO] ?? 0, eO.framebufferTexture2D(eO.FRAMEBUFFER, CO, eO.TEXTURE_CUBE_MAP_POSITIVE_X + pO, bK.underlyingResource, XO)) : eO.framebufferTexture2D(eO.FRAMEBUFFER, CO, eO.TEXTURE_2D, bK.underlyingResource, XO)
        } else {
          const OO = this._context;
          CO = OO["COLOR_ATTACHMENT" + KO + "_WEBGL"];
          const eO = void 0 !== pO ? OO.TEXTURE_CUBE_MAP_POSITIVE_X + pO : OO.TEXTURE_2D;
          OO.framebufferTexture2D(OO.FRAMEBUFFER, CO, eO, bK.underlyingResource, XO)
        }
        if (OO._autoMSAAManagement && this._MSAAFramebuffer) {
          const OO = this._context;
          lO._bindUnboundFramebuffer(this._MSAAFramebuffer), OO.framebufferRenderbuffer(OO.FRAMEBUFFER, CO, OO.RENDERBUFFER, bK.getMSAARenderBuffer())
        }
        lO._bindUnboundFramebuffer(vK)
      }
      setTexture(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        super.setTexture(OO, KO, pO), this._bindTextureRenderTarget(OO, KO)
      }
      setLayerAndFaceIndices(OO, KO) {
        if (super.setLayerAndFaceIndices(OO, KO), !this.textures || !this.layerIndices || !this.faceIndices) return;
        const pO = this._attachments?.length ?? this.textures.length;
        for (let XO = 0; XO < pO; XO++) {
          const OO = this.textures[XO];
          OO && (OO.is2DArray || OO.is3D ? this._bindTextureRenderTarget(OO, XO, this.layerIndices[XO]) : OO.isCube ? this._bindTextureRenderTarget(OO, XO, this.faceIndices[XO]) : this._bindTextureRenderTarget(OO, XO))
        }
      }
      setLayerAndFaceIndex() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        if (super.setLayerAndFaceIndex(OO, KO, pO), !this.textures || !this.layerIndices || !this.faceIndices) return;
        const XO = this.textures[OO];
        XO.is2DArray || XO.is3D ? this._bindTextureRenderTarget(this.textures[OO], OO, this.layerIndices[OO]) : XO.isCube && this._bindTextureRenderTarget(this.textures[OO], OO, this.faceIndices[OO])
      }
      resolveMSAATextures() {
        const OO = this._engine,
          KO = OO._currentFramebuffer;
        OO._bindUnboundFramebuffer(this._MSAAFramebuffer), super.resolveMSAATextures(), OO._bindUnboundFramebuffer(KO)
      }
      dispose() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._disposeOnlyFramebuffers;
        const KO = this._context;
        OO || (this._colorTextureArray && (this._context.deleteTexture(this._colorTextureArray), this._colorTextureArray = null), this._depthStencilTextureArray && (this._context.deleteTexture(this._depthStencilTextureArray), this._depthStencilTextureArray = null)), this._framebuffer && (KO.deleteFramebuffer(this._framebuffer), this._framebuffer = null), this._depthStencilBuffer && (KO.deleteRenderbuffer(this._depthStencilBuffer), this._depthStencilBuffer = null), this._MSAAFramebuffer && (KO.deleteFramebuffer(this._MSAAFramebuffer), this._MSAAFramebuffer = null), super.dispose(OO)
      }
    }
    let hO = !1;
    hO || (hO = !0, eO.ThinEngine.prototype._createHardwareRenderTargetWrapper = function(OO, KO, pO) {
      const XO = new CO(OO, KO, pO, this, this._gl);
      return this._renderTargetWrapperCache.push(XO), XO
    }, eO.ThinEngine.prototype.createRenderTargetTexture = function(OO, KO) {
      const pO = this._createHardwareRenderTargetWrapper(!1, !1, OO);
      let XO, bK, eO = !0,
        lO = !1,
        vK = !1,
        CO = 1;
      void 0 !== KO && "object" === typeof KO && (eO = KO.generateDepthBuffer ?? !0, lO = !!KO.generateStencilBuffer, vK = !!KO.noColorAttachment, XO = KO.colorAttachment, CO = KO.samples ?? 1, bK = KO.label);
      const hO = XO || (vK ? null : this._createInternalTexture(OO, KO, !0, 5)),
        DO = OO.width || OO,
        MO = OO.height || OO,
        aK = this._currentFramebuffer,
        oO = this._gl,
        FO = oO.createFramebuffer();
      if (this._bindUnboundFramebuffer(FO), pO._depthStencilBuffer = this._setupFramebufferDepthAttachments(lO, eO, DO, MO), !hO || hO.is2DArray || hO.is3D || oO.framebufferTexture2D(oO.FRAMEBUFFER, oO.COLOR_ATTACHMENT0, oO.TEXTURE_2D, hO._hardwareTexture.underlyingResource, 0), this._bindUnboundFramebuffer(aK), pO.label = bK ?? "RenderTargetWrapper", pO._framebuffer = FO, pO._generateDepthBuffer = eO, pO._generateStencilBuffer = lO, pO.setTextures(hO), XO) {
        if (pO._samples = XO.samples, XO.samples > 1) {
          const OO = XO._hardwareTexture.getMSAARenderBuffer(0);
          pO._MSAAFramebuffer = oO.createFramebuffer(), this._bindUnboundFramebuffer(pO._MSAAFramebuffer), oO.framebufferRenderbuffer(oO.FRAMEBUFFER, oO.COLOR_ATTACHMENT0, oO.RENDERBUFFER, OO), this._bindUnboundFramebuffer(null)
        }
      } else this.updateRenderTargetTextureSampleCount(pO, CO);
      return pO
    }, eO.ThinEngine.prototype._createDepthStencilTexture = function(OO, KO, pO) {
      const eO = this._gl,
        lO = OO.layers || 0,
        CO = OO.depth || 0;
      let hO = eO.TEXTURE_2D;
      0 !== lO ? hO = eO.TEXTURE_2D_ARRAY : 0 !== CO && (hO = eO.TEXTURE_3D);
      const DO = new XO.e(this, 12);
      if (DO.label = KO.label, !this._caps.depthTextureExtension) return bK.b.Error("Depth texture is not supported by your browser or hardware."), DO;
      const MO = {
        bilinearFiltering: !1,
        comparisonFunction: 0,
        generateStencil: !1,
        ...KO
      };
      if (this._bindTextureDirectly(hO, DO, !0), this._setupDepthStencilTexture(DO, OO, 0 !== MO.comparisonFunction && MO.bilinearFiltering, MO.comparisonFunction, MO.samples), void 0 !== MO.depthTextureFormat) {
        if (15 !== MO.depthTextureFormat && 16 !== MO.depthTextureFormat && 17 !== MO.depthTextureFormat && 13 !== MO.depthTextureFormat && 14 !== MO.depthTextureFormat && 18 !== MO.depthTextureFormat) return bK.b.Error(`Depth texture ${MO.depthTextureFormat} format is not supported.`), DO;
        DO.format = MO.depthTextureFormat
      } else DO.format = MO.generateStencil ? 13 : 16;
      const aK = (0, vK.d)(DO.format),
        oO = this._getWebGLTextureTypeFromDepthTextureFormat(DO.format),
        FO = aK ? eO.DEPTH_STENCIL : eO.DEPTH_COMPONENT,
        VO = this._getInternalFormatFromDepthTextureFormat(DO.format, !0, aK);
      return DO.is2DArray ? eO.texImage3D(hO, 0, VO, DO.width, DO.height, lO, 0, FO, oO, null) : DO.is3D ? eO.texImage3D(hO, 0, VO, DO.width, DO.height, CO, 0, FO, oO, null) : eO.texImage2D(hO, 0, VO, DO.width, DO.height, 0, FO, oO, null), this._bindTextureDirectly(hO, null), this._internalTexturesCache.push(DO), pO._depthStencilBuffer && (eO.deleteRenderbuffer(pO._depthStencilBuffer), pO._depthStencilBuffer = null), this._bindUnboundFramebuffer(pO._MSAAFramebuffer ?? pO._framebuffer), pO._generateStencilBuffer = aK, pO._depthStencilTextureWithStencil = aK, pO._depthStencilBuffer = this._setupFramebufferDepthAttachments(pO._generateStencilBuffer, pO._generateDepthBuffer, pO.width, pO.height, pO.samples, DO.format), this._bindUnboundFramebuffer(null), DO
    }, eO.ThinEngine.prototype.updateRenderTargetTextureSampleCount = function(OO, KO) {
      if (this.ye < 2 || !OO) return 1;
      if (OO.samples === KO) return KO;
      const pO = this._gl;
      KO = Math.min(KO, this.getCaps().maxMSAASamples), OO._depthStencilBuffer && (pO.deleteRenderbuffer(OO._depthStencilBuffer), OO._depthStencilBuffer = null), OO._MSAAFramebuffer && (pO.deleteFramebuffer(OO._MSAAFramebuffer), OO._MSAAFramebuffer = null);
      const XO = OO.texture?._hardwareTexture;
      if (XO?.releaseMSAARenderBuffers(), OO.texture && KO > 1 && "function" === typeof pO.renderbufferStorageMultisample) {
        const bK = pO.createFramebuffer();
        if (!bK) throw new Error("Unable to create multi sampled framebuffer");
        OO._MSAAFramebuffer = bK, this._bindUnboundFramebuffer(OO._MSAAFramebuffer);
        const eO = this._createRenderBuffer(OO.texture.width, OO.texture.height, KO, -1, this._getRGBABufferInternalSizedFormat(OO.texture.type, OO.texture.format, OO.texture._useSRGBBuffer), pO.COLOR_ATTACHMENT0, !1);
        if (!eO) throw new Error("Unable to create multi sampled framebuffer");
        XO?.addMSAARenderBuffer(eO)
      }
      this._bindUnboundFramebuffer(OO._MSAAFramebuffer ?? OO._framebuffer), OO.texture && (OO.texture.samples = KO), OO._samples = KO;
      const bK = OO._depthStencilTexture ? OO._depthStencilTexture.format : void 0;
      return OO._depthStencilBuffer = this._setupFramebufferDepthAttachments(OO._generateStencilBuffer, OO._generateDepthBuffer, OO.width, OO.height, KO, bK), this._bindUnboundFramebuffer(null), KO
    }, eO.ThinEngine.prototype._setupDepthStencilTexture = function(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1;
      const eO = KO.width ?? KO,
        lO = KO.height ?? KO,
        vK = KO.layers || 0,
        CO = KO.depth || 0;
      OO.baseWidth = eO, OO.baseHeight = lO, OO.width = eO, OO.height = lO, OO.is2DArray = vK > 0, OO.depth = vK || CO, OO.isReady = !0, OO.samples = bK, OO.generateMipMaps = !1, OO.samplingMode = pO ? 2 : 1, OO.type = 0, OO._comparisonFunction = XO;
      const hO = this._gl,
        DO = this._getTextureTarget(OO),
        MO = this._getSamplingParameters(OO.samplingMode, !1);
      hO.texParameteri(DO, hO.TEXTURE_MAG_FILTER, MO.mag), hO.texParameteri(DO, hO.TEXTURE_MIN_FILTER, MO.min), hO.texParameteri(DO, hO.TEXTURE_WRAP_S, hO.CLAMP_TO_EDGE), hO.texParameteri(DO, hO.TEXTURE_WRAP_T, hO.CLAMP_TO_EDGE), this.ye > 1 && (0 === XO ? (hO.texParameteri(DO, hO.TEXTURE_COMPARE_FUNC, 515), hO.texParameteri(DO, hO.TEXTURE_COMPARE_MODE, hO.NONE)) : (hO.texParameteri(DO, hO.TEXTURE_COMPARE_FUNC, XO), hO.texParameteri(DO, hO.TEXTURE_COMPARE_MODE, hO.COMPARE_REF_TO_TEXTURE)))
    })
  },
  37880: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO.d
    });
    var XO = pO(37887);
    (0, pO(38024).c)();
    var bK = pO(37899);
    let eO = !1;
    ! function() {
      if (eO) return;
      eO = !0;
      const OO = new WeakMap,
        KO = new WeakMap,
        pO = new WeakMap,
        XO = new WeakMap;
      bK.ThinEngine.prototype.getAlphaToCoverage = function() {
        return OO.get(this) ?? !1
      }, bK.ThinEngine.prototype.setAlphaToCoverage = function(pO) {
        (OO.get(this) !== pO || this._gl && KO.get(this) !== this._gl) && (OO.set(this, pO), this._gl && (pO ? this._gl.enable(this._gl.SAMPLE_ALPHA_TO_COVERAGE) : this._gl.disable(this._gl.SAMPLE_ALPHA_TO_COVERAGE), KO.set(this, this._gl)))
      }, Object.defineProperty(bK.ThinEngine.prototype, "currentSampleCount", {
        get: function() {
          return this._currentRenderTarget ? this._currentRenderTarget.samples : this._gl ? (XO.get(this) !== this._gl && (pO.set(this, this._gl.getContextAttributes()?.antialias ? Math.max(1, this._gl.getParameter(this._gl.SAMPLES)) : 1), XO.set(this, this._gl)), pO.get(this)) : 1
        },
        enumerable: !1,
        configurable: !0
      })
    }();
    var lO = pO(37889),
      vK = pO(37061),
      CO = pO(37996);
    let hO = !1;
    ! function() {
      function OO(OO, KO, pO, XO) {
        let bK, eO = 1;
        1 === XO ? bK = new Float32Array(KO * pO * 4) : 2 === XO ? (bK = new Uint16Array(KO * pO * 4), eO = 15360) : bK = 7 === XO ? new Uint32Array(KO * pO * 4) : new Uint8Array(KO * pO * 4);
        for (let lO = 0; lO < KO; lO++)
          for (let XO = 0; XO < pO; XO++) {
            const pO = 3 * (XO * KO + lO),
              vK = 4 * (XO * KO + lO);
            bK[vK + 0] = OO[pO + 0], bK[vK + 1] = OO[pO + 1], bK[vK + 2] = OO[pO + 2], bK[vK + 3] = eO
          }
        return bK
      }

      function KO(OO) {
        return function(KO, pO, XO, bK, eO, vK, CO, hO) {
          let DO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : null,
            MO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0;
          const aK = OO ? this._gl.TEXTURE_3D : this._gl.TEXTURE_2D_ARRAY,
            oO = OO ? 10 : 11,
            FO = new lO.e(this, oO);
          FO.baseWidth = pO, FO.baseHeight = XO, FO.baseDepth = bK, FO.width = pO, FO.height = XO, FO.depth = bK, FO.format = eO, FO.type = MO, FO.generateMipMaps = vK, FO.samplingMode = hO, OO ? FO.is3D = !0 : FO.is2DArray = !0, this._doNotHandleContextLost || (FO._bufferView = KO), OO ? this.updateRawTexture3D(FO, KO, eO, CO, DO, MO) : this.updateRawTexture2DArray(FO, KO, eO, CO, DO, MO), this._bindTextureDirectly(aK, FO, !0);
          const VO = this._getSamplingParameters(hO, vK);
          return this._gl.texParameteri(aK, this._gl.TEXTURE_MAG_FILTER, VO.mag), this._gl.texParameteri(aK, this._gl.TEXTURE_MIN_FILTER, VO.min), vK && this._gl.generateMipmap(aK), this._bindTextureDirectly(aK, null), this._internalTexturesCache.push(FO), FO
        }
      }

      function pO(OO) {
        return function(KO, pO, XO, bK) {
          let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
            lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0;
          const vK = OO ? this._gl.TEXTURE_3D : this._gl.TEXTURE_2D_ARRAY,
            CO = this._getWebGLTextureType(lO),
            hO = this._getInternalFormat(XO),
            DO = this._getRGBABufferInternalSizedFormat(lO, XO);
          this._bindTextureDirectly(vK, KO, !0), this._unpackFlipY(void 0 === bK || !!bK), this._doNotHandleContextLost || (KO._bufferView = pO, KO.format = XO, KO.invertY = bK, KO._compression = eO), KO.width % 4 !== 0 && this._gl.pixelStorei(this._gl.UNPACK_ALIGNMENT, 1), eO && pO ? this._gl.compressedTexImage3D(vK, 0, this.getCaps().s3tc[eO], KO.width, KO.height, KO.depth, 0, pO) : this._gl.texImage3D(vK, 0, DO, KO.width, KO.height, KO.depth, 0, hO, CO, pO), KO.generateMipMaps && this._gl.generateMipmap(vK), this._bindTextureDirectly(vK, null), KO.isReady = !0
        }
      }
      hO || (hO = !0, bK.ThinEngine.prototype.updateRawTexture = function(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
          lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
        if (!OO) return;
        const vK = this._getRGBABufferInternalSizedFormat(eO, pO, lO),
          CO = this._getInternalFormat(pO),
          hO = this._getWebGLTextureType(eO);
        this._bindTextureDirectly(this._gl.TEXTURE_2D, OO, !0), this._unpackFlipY(void 0 === XO || !!XO), this._doNotHandleContextLost || (OO._bufferView = KO, OO.format = pO, OO.type = eO, OO.invertY = XO, OO._compression = bK), OO.width % 4 !== 0 && this._gl.pixelStorei(this._gl.UNPACK_ALIGNMENT, 1), bK && KO ? this._gl.compressedTexImage2D(this._gl.TEXTURE_2D, 0, this.getCaps().s3tc[bK], OO.width, OO.height, 0, KO) : this._gl.texImage2D(this._gl.TEXTURE_2D, 0, vK, OO.width, OO.height, 0, CO, hO, KO), OO.generateMipMaps && this._gl.generateMipmap(this._gl.TEXTURE_2D), this._bindTextureDirectly(this._gl.TEXTURE_2D, null), OO.isReady = !0
      }, bK.ThinEngine.prototype.createRawTexture = function(OO, KO, pO, XO, bK, eO, vK) {
        let CO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
          hO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0,
          DO = arguments.length > 10 && void 0 !== arguments[10] && arguments[10];
        const MO = new lO.e(this, 3);
        MO.baseWidth = KO, MO.baseHeight = pO, MO.width = KO, MO.height = pO, MO.format = XO, MO.generateMipMaps = bK, MO.samplingMode = vK, MO.invertY = eO, MO._compression = CO, MO.type = hO, MO._useSRGBBuffer = this._getUseSRGBBuffer(DO, !bK), this._doNotHandleContextLost || (MO._bufferView = OO), this.updateRawTexture(MO, OO, XO, eO, CO, hO, MO._useSRGBBuffer), this._bindTextureDirectly(this._gl.TEXTURE_2D, MO, !0);
        const aK = this._getSamplingParameters(vK, bK);
        return this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MAG_FILTER, aK.mag), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MIN_FILTER, aK.min), bK && this._gl.generateMipmap(this._gl.TEXTURE_2D), this._bindTextureDirectly(this._gl.TEXTURE_2D, null), this._internalTexturesCache.push(MO), MO
      }, bK.ThinEngine.prototype.createRawCubeTexture = function(OO, KO, pO, XO, bK, eO, hO) {
        let DO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null;
        const MO = this._gl,
          aK = new lO.e(this, 8);
        aK.isCube = !0, aK.format = pO, aK.type = XO, this._doNotHandleContextLost || (aK._bufferViewArray = OO);
        const oO = this._getWebGLTextureType(XO);
        let FO = this._getInternalFormat(pO);
        FO === MO.RGB && (FO = MO.RGBA), oO !== MO.FLOAT || this._caps.textureFloatLinearFiltering ? oO !== this._gl.HALF_FLOAT_OES || this._caps.textureHalfFloatLinearFiltering ? oO !== MO.FLOAT || this._caps.textureFloatRender ? oO !== MO.HALF_FLOAT || this._caps.colorBufferFloat || (bK = !1, vK.b.Warn("Render to half float textures is not supported. Mipmap generation forced to false.")) : (bK = !1, vK.b.Warn("Render to float textures is not supported. Mipmap generation forced to false.")) : (bK = !1, hO = 1, vK.b.Warn("Half float texture filtering is not supported. Mipmap generation and sampling mode are forced to false and TEXTURE_NEAREST_SAMPLINGMODE, respectively.")) : (bK = !1, hO = 1, vK.b.Warn("Float texture filtering is not supported. Mipmap generation and sampling mode are forced to false and TEXTURE_NEAREST_SAMPLINGMODE, respectively."));
        const VO = KO,
          LO = VO;
        aK.width = VO, aK.height = LO, aK.invertY = eO, aK._compression = DO;
        if (!this.needPOTTextures || (0, CO.j)(aK.width) && (0, CO.j)(aK.height) || (bK = !1), OO) this.updateRawCubeTexture(aK, OO, pO, XO, eO, DO);
        else {
          const OO = this._getRGBABufferInternalSizedFormat(XO),
            KO = 0;
          this._bindTextureDirectly(MO.TEXTURE_CUBE_MAP, aK, !0);
          for (let pO = 0; pO < 6; pO++) DO ? MO.compressedTexImage2D(MO.TEXTURE_CUBE_MAP_POSITIVE_X + pO, KO, this.getCaps().s3tc[DO], aK.width, aK.height, 0, void 0) : MO.texImage2D(MO.TEXTURE_CUBE_MAP_POSITIVE_X + pO, KO, OO, aK.width, aK.height, 0, FO, oO, null);
          this._bindTextureDirectly(this._gl.TEXTURE_CUBE_MAP, null)
        }
        this._bindTextureDirectly(this._gl.TEXTURE_CUBE_MAP, aK, !0), OO && bK && this._gl.generateMipmap(this._gl.TEXTURE_CUBE_MAP);
        const QO = this._getSamplingParameters(hO, bK);
        return MO.texParameteri(MO.TEXTURE_CUBE_MAP, MO.TEXTURE_MAG_FILTER, QO.mag), MO.texParameteri(MO.TEXTURE_CUBE_MAP, MO.TEXTURE_MIN_FILTER, QO.min), MO.texParameteri(MO.TEXTURE_CUBE_MAP, MO.TEXTURE_WRAP_S, MO.CLAMP_TO_EDGE), MO.texParameteri(MO.TEXTURE_CUBE_MAP, MO.TEXTURE_WRAP_T, MO.CLAMP_TO_EDGE), this._bindTextureDirectly(MO.TEXTURE_CUBE_MAP, null), aK.generateMipMaps = bK, aK.samplingMode = hO, aK.isReady = !0, aK
      }, bK.ThinEngine.prototype.updateRawCubeTexture = function(KO, pO, XO, bK, eO) {
        let lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
          vK = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0;
        KO._bufferViewArray = pO, KO.format = XO, KO.type = bK, KO.invertY = eO, KO._compression = lO;
        const hO = this._gl,
          DO = this._getWebGLTextureType(bK);
        let MO = this._getInternalFormat(XO);
        const aK = this._getRGBABufferInternalSizedFormat(bK);
        let oO = !1;
        MO === hO.RGB && (MO = hO.RGBA, oO = !0), this._bindTextureDirectly(hO.TEXTURE_CUBE_MAP, KO, !0), this._unpackFlipY(void 0 === eO || !!eO), KO.width % 4 !== 0 && hO.pixelStorei(hO.UNPACK_ALIGNMENT, 1);
        for (let CO = 0; CO < 6; CO++) {
          let XO = pO[CO];
          lO ? hO.compressedTexImage2D(hO.TEXTURE_CUBE_MAP_POSITIVE_X + CO, vK, this.getCaps().s3tc[lO], KO.width, KO.height, 0, XO) : (oO && (XO = OO(XO, KO.width, KO.height, bK)), hO.texImage2D(hO.TEXTURE_CUBE_MAP_POSITIVE_X + CO, vK, aK, KO.width, KO.height, 0, MO, DO, XO))
        }(!this.needPOTTextures || (0, CO.j)(KO.width) && (0, CO.j)(KO.height)) && KO.generateMipMaps && 0 === vK && this._gl.generateMipmap(this._gl.TEXTURE_CUBE_MAP), this._bindTextureDirectly(this._gl.TEXTURE_CUBE_MAP, null), KO.isReady = !0
      }, bK.ThinEngine.prototype.createRawCubeTextureFromUrl = function(KO, pO, XO, bK, eO, lO, vK, CO) {
        let hO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : null,
          DO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : null,
          MO = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : 3,
          aK = arguments.length > 11 && void 0 !== arguments[11] && arguments[11];
        const oO = this._gl,
          FO = this.createRawCubeTexture(null, XO, bK, eO, !lO, aK, MO, null);
        pO?.addPendingData(FO), FO.url = KO, FO.isReady = !1, this._internalTexturesCache.push(FO);
        const VO = (OO, KO) => {
            pO?.removePendingData(FO), DO && DO(OO ? OO.status + " " + OO.statusText : "Failed to parse texture data", KO)
          },
          LO = async KO => {
            if (!FO._hardwareTexture) return;
            const XO = vK(KO);
            if (!XO) return;
            const lO = XO instanceof Promise ? await XO : XO,
              DO = FO.width;
            if (CO) {
              const KO = this._getWebGLTextureType(eO);
              let pO = this._getInternalFormat(bK);
              const XO = this._getRGBABufferInternalSizedFormat(eO);
              let vK = !1;
              pO === oO.RGB && (pO = oO.RGBA, vK = !0), this._bindTextureDirectly(oO.TEXTURE_CUBE_MAP, FO, !0), this._unpackFlipY(!1);
              const hO = CO(lO);
              for (let bK = 0; bK < hO.length; bK++) {
                const lO = DO >> bK;
                for (let CO = 0; CO < 6; CO++) {
                  let DO = hO[bK][CO];
                  vK && (DO = OO(DO, lO, lO, eO)), oO.texImage2D(CO, bK, XO, lO, lO, 0, pO, KO, DO)
                }
              }
              this._bindTextureDirectly(oO.TEXTURE_CUBE_MAP, null)
            } else this.updateRawCubeTexture(FO, lO, bK, eO, aK);
            FO.isReady = !0, pO?.removePendingData(FO), FO.onLoadedObservable.notifyObservers(FO), FO.onLoadedObservable.clear(), hO && hO()
          };
        return this._loadFile(KO, (OO => {
          LO(OO).catch((OO => {
            VO(void 0, OO)
          }))
        }), void 0, pO?.offlineProvider, !0, VO), FO
      }, bK.ThinEngine.prototype.createRawTexture2DArray = KO(!1), bK.ThinEngine.prototype.createRawTexture3D = KO(!0), bK.ThinEngine.prototype.updateRawTexture2DArray = pO(!1), bK.ThinEngine.prototype.updateRawTexture3D = pO(!0))
    }();
    var DO = pO(37930);
    let MO = !1;
    MO || (MO = !0, bK.ThinEngine.prototype._readTexturePixelsSync = function(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : -1,
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
        eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
        lO = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6],
        vK = arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
        CO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0,
        hO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0;
      const MO = this._gl;
      if (!MO) throw new Error("Engine does not have gl rendering context.");
      if (!this._dummyFramebuffer) {
        const OO = MO.createFramebuffer();
        if (!OO) throw new Error("Unable to create dummy framebuffer");
        this._dummyFramebuffer = OO
      }
      MO.bindFramebuffer(MO.FRAMEBUFFER, this._dummyFramebuffer), XO > -1 && (OO.is2DArray || OO.is3D) ? MO.framebufferTextureLayer(MO.FRAMEBUFFER, MO.COLOR_ATTACHMENT0, OO._hardwareTexture?.underlyingResource, bK, XO) : XO > -1 ? MO.framebufferTexture2D(MO.FRAMEBUFFER, MO.COLOR_ATTACHMENT0, MO.TEXTURE_CUBE_MAP_POSITIVE_X + XO, OO._hardwareTexture?.underlyingResource, bK) : MO.framebufferTexture2D(MO.FRAMEBUFFER, MO.COLOR_ATTACHMENT0, MO.TEXTURE_2D, OO._hardwareTexture?.underlyingResource, bK);
      let aK = void 0 !== OO.type ? this._getWebGLTextureType(OO.type) : MO.UNSIGNED_BYTE;
      return vK ? eO || (eO = (0, DO.n)(OO.type, 4 * KO * pO)) : aK === MO.UNSIGNED_BYTE ? (eO || (eO = new Uint8Array(4 * KO * pO)), aK = MO.UNSIGNED_BYTE) : (eO || (eO = new Float32Array(4 * KO * pO)), aK = MO.FLOAT), lO && this.flushFramebuffer(), MO.readPixels(CO, hO, KO, pO, MO.RGBA, aK, eO), MO.bindFramebuffer(MO.FRAMEBUFFER, this._currentFramebuffer), eO
    }, bK.ThinEngine.prototype._readTexturePixels = function(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : -1,
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
        eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
        lO = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6],
        vK = arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
        CO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0,
        hO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0;
      return Promise.resolve(this._readTexturePixelsSync(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO))
    }), (0, pO(38031).d)();
    let aK = !1;
    aK || (aK = !0, bK.ThinEngine.prototype._createDepthStencilCubeTexture = function(OO, KO) {
      const pO = new lO.e(this, 12);
      if (pO.isCube = !0, 1 === this.ye) return vK.b.Error("Depth cube texture is not supported by WebGL 1."), pO;
      const XO = {
          bilinearFiltering: !1,
          comparisonFunction: 0,
          generateStencil: !1,
          ...KO
        },
        bK = this._gl;
      this._bindTextureDirectly(bK.TEXTURE_CUBE_MAP, pO, !0), this._setupDepthStencilTexture(pO, OO, XO.bilinearFiltering, XO.comparisonFunction);
      for (let eO = 0; eO < 6; eO++) XO.generateStencil ? bK.texImage2D(bK.TEXTURE_CUBE_MAP_POSITIVE_X + eO, 0, bK.DEPTH24_STENCIL8, OO, OO, 0, bK.DEPTH_STENCIL, bK.UNSIGNED_INT_24_8, null) : bK.texImage2D(bK.TEXTURE_CUBE_MAP_POSITIVE_X + eO, 0, bK.DEPTH_COMPONENT24, OO, OO, 0, bK.DEPTH_COMPONENT, bK.UNSIGNED_INT, null);
      return this._bindTextureDirectly(bK.TEXTURE_CUBE_MAP, null), this._internalTexturesCache.push(pO), pO
    }, bK.ThinEngine.prototype._setCubeMapTextureParams = function(OO, KO, pO) {
      const XO = this._gl;
      XO.texParameteri(XO.TEXTURE_CUBE_MAP, XO.TEXTURE_MAG_FILTER, XO.LINEAR), XO.texParameteri(XO.TEXTURE_CUBE_MAP, XO.TEXTURE_MIN_FILTER, KO ? XO.LINEAR_MIPMAP_LINEAR : XO.LINEAR), XO.texParameteri(XO.TEXTURE_CUBE_MAP, XO.TEXTURE_WRAP_S, XO.CLAMP_TO_EDGE), XO.texParameteri(XO.TEXTURE_CUBE_MAP, XO.TEXTURE_WRAP_T, XO.CLAMP_TO_EDGE), OO.samplingMode = KO ? 3 : 2, KO && this.getCaps().textureMaxLevel && void 0 !== pO && pO > 0 && (XO.texParameteri(XO.TEXTURE_CUBE_MAP, XO.TEXTURE_MAX_LEVEL, pO), OO._maxLodLevel = pO), this._bindTextureDirectly(XO.TEXTURE_CUBE_MAP, null)
    }, bK.ThinEngine.prototype.createCubeTexture = function(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
        eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
        lO = arguments.length > 6 ? arguments[6] : void 0,
        hO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
        DO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8],
        MO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0,
        aK = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : 0,
        oO = arguments.length > 11 && void 0 !== arguments[11] ? arguments[11] : null,
        FO = arguments.length > 13 && void 0 !== arguments[13] && arguments[13],
        VO = arguments.length > 14 && void 0 !== arguments[14] ? arguments[14] : null;
      const LO = this._gl;
      return this.createCubeTextureBase(OO, KO, pO, !!XO, bK, eO, lO, hO, DO, MO, aK, oO, (OO => this._bindTextureDirectly(LO.TEXTURE_CUBE_MAP, OO, !0)), ((OO, KO) => {
        const pO = this.needPOTTextures ? (0, CO.i)(KO[0].width, this._caps.maxCubemapTextureSize) : KO[0].width,
          eO = pO,
          hO = [LO.TEXTURE_CUBE_MAP_POSITIVE_X, LO.TEXTURE_CUBE_MAP_POSITIVE_Y, LO.TEXTURE_CUBE_MAP_POSITIVE_Z, LO.TEXTURE_CUBE_MAP_NEGATIVE_X, LO.TEXTURE_CUBE_MAP_NEGATIVE_Y, LO.TEXTURE_CUBE_MAP_NEGATIVE_Z];
        this._bindTextureDirectly(LO.TEXTURE_CUBE_MAP, OO, !0), this._unpackFlipY(!1);
        const DO = lO ? this._getInternalFormat(lO, OO._useSRGBBuffer) : OO._useSRGBBuffer ? this._glSRGBExtensionValues.SRGB8_ALPHA8 : LO.RGBA;
        let MO = lO ? this._getInternalFormat(lO) : LO.RGBA;
        OO._useSRGBBuffer && 1 === this.ye && (MO = DO);
        for (let XO = 0; XO < hO.length; XO++)
          if (KO[XO].width !== pO || KO[XO].height !== eO) {
            if (this._prepareWorkingCanvas(), !this._workingCanvas || !this._workingContext) return void vK.b.Warn("Cannot create canvas to resize texture.");
            this._workingCanvas.width = pO, this._workingCanvas.height = eO, this._workingContext.drawImage(KO[XO], 0, 0, KO[XO].width, KO[XO].height, 0, 0, pO, eO), LO.texImage2D(hO[XO], 0, DO, MO, LO.UNSIGNED_BYTE, this._workingCanvas)
          } else LO.texImage2D(hO[XO], 0, DO, MO, LO.UNSIGNED_BYTE, KO[XO]);
        XO || LO.generateMipmap(LO.TEXTURE_CUBE_MAP), this._setCubeMapTextureParams(OO, !XO), OO.width = pO, OO.height = eO, OO.isReady = !0, lO && (OO.format = lO), OO.onLoadedObservable.notifyObservers(OO), OO.onLoadedObservable.clear(), bK && bK()
      }), !!FO, VO)
    }, bK.ThinEngine.prototype.generateMipMapsForCubemap = function(OO) {
      let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      if (OO.generateMipMaps) {
        const pO = this._gl;
        this._bindTextureDirectly(pO.TEXTURE_CUBE_MAP, OO, !0), pO.generateMipmap(pO.TEXTURE_CUBE_MAP), KO && this._bindTextureDirectly(pO.TEXTURE_CUBE_MAP, null)
      }
    });
    pO(38038);
    let oO = !1;
    oO || (oO = !0, bK.ThinEngine.prototype.setDepthStencilTexture = function(OO, KO, pO, XO) {
      void 0 !== OO && (KO && (this._boundUniforms[OO] = KO), pO && pO.depthStencilTexture ? this._setTexture(OO, pO, !1, !0, XO) : this._setTexture(OO, null, void 0, void 0, XO))
    });
    let FO = !1;
    FO || (FO = !0, bK.ThinEngine.prototype.createRenderTargetCubeTexture = function(OO, KO) {
      const pO = this._createHardwareRenderTargetWrapper(!1, !0, OO),
        XO = {
          generateMipMaps: !0,
          generateDepthBuffer: !0,
          generateStencilBuffer: !1,
          type: 0,
          samplingMode: 3,
          format: 5,
          ...KO
        };
      XO.generateStencilBuffer = XO.generateDepthBuffer && XO.generateStencilBuffer, (1 !== XO.type || this._caps.textureFloatLinearFiltering) && (2 !== XO.type || this._caps.textureHalfFloatLinearFiltering) || (XO.samplingMode = 1);
      const bK = this._gl,
        eO = new lO.e(this, 5);
      this._bindTextureDirectly(bK.TEXTURE_CUBE_MAP, eO, !0);
      const CO = this._getSamplingParameters(XO.samplingMode, XO.generateMipMaps);
      1 !== XO.type || this._caps.textureFloat || (XO.type = 0, vK.b.Warn("Float textures are not supported. Cube render target forced to TEXTURETYPE_UNESIGNED_BYTE type")), bK.texParameteri(bK.TEXTURE_CUBE_MAP, bK.TEXTURE_MAG_FILTER, CO.mag), bK.texParameteri(bK.TEXTURE_CUBE_MAP, bK.TEXTURE_MIN_FILTER, CO.min), bK.texParameteri(bK.TEXTURE_CUBE_MAP, bK.TEXTURE_WRAP_S, bK.CLAMP_TO_EDGE), bK.texParameteri(bK.TEXTURE_CUBE_MAP, bK.TEXTURE_WRAP_T, bK.CLAMP_TO_EDGE);
      for (let lO = 0; lO < 6; lO++) bK.texImage2D(bK.TEXTURE_CUBE_MAP_POSITIVE_X + lO, 0, this._getRGBABufferInternalSizedFormat(XO.type, XO.format), OO, OO, 0, this._getInternalFormat(XO.format), this._getWebGLTextureType(XO.type), null);
      const hO = bK.createFramebuffer();
      return this._bindUnboundFramebuffer(hO), pO._depthStencilBuffer = this._setupFramebufferDepthAttachments(XO.generateStencilBuffer, XO.generateDepthBuffer, OO, OO), XO.generateMipMaps && bK.generateMipmap(bK.TEXTURE_CUBE_MAP), this._bindTextureDirectly(bK.TEXTURE_CUBE_MAP, null), this._bindUnboundFramebuffer(null), pO._framebuffer = hO, pO._generateDepthBuffer = XO.generateDepthBuffer, pO._generateStencilBuffer = XO.generateStencilBuffer, eO.width = OO, eO.height = OO, eO.isReady = !0, eO.isCube = !0, eO.samples = 1, eO.generateMipMaps = XO.generateMipMaps, eO.samplingMode = XO.samplingMode, eO.type = XO.type, eO.format = XO.format, this._internalTexturesCache.push(eO), pO.setTextures(eO), pO
    });
    var VO = pO(38048),
      LO = pO(38056);
    let QO = !1;
    QO || (QO = !0, bK.ThinEngine.prototype.createPrefilteredCubeTexture = function(OO, KO, XO, bK) {
      let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
        CO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
        hO = arguments.length > 6 ? arguments[6] : void 0,
        DO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
        MO = !(arguments.length > 8 && void 0 !== arguments[8]) || arguments[8],
        aK = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : null;
      return this.createCubeTexture(OO, KO, null, !1, (async OO => {
        if (!OO) return void(eO && eO(null));
        const CO = OO.texture;
        if (MO ? OO.info.sphericalPolynomial && (CO._sphericalPolynomial = OO.info.sphericalPolynomial) : CO._sphericalPolynomial = CO._sphericalPolynomial ?? new VO.f, CO._source = 9, this.getCaps().textureLOD) return void(eO && eO(CO));
        const hO = this._gl,
          DO = OO.width;
        if (!DO) return;
        const {
          DDSTools: aK
        } = await pO.e(286).then((() => pO(39775))), oO = [];
        for (let pO = 0; pO < 3; pO++) {
          const eO = 1 - pO / 2,
            MO = bK,
            FO = Math.log2(DO) * XO + bK,
            VO = MO + (FO - MO) * eO,
            QO = Math.round(Math.min(Math.max(VO, 0), FO)),
            zK = new lO.e(this, 2);
          if (zK.type = CO.type, zK.format = CO.format, zK.width = Math.pow(2, Math.max(Math.log2(DO) - QO, 0)), zK.height = zK.width, zK.isCube = !0, zK._cachedWrapU = 0, zK._cachedWrapV = 0, this._bindTextureDirectly(hO.TEXTURE_CUBE_MAP, zK, !0), zK.samplingMode = 2, hO.texParameteri(hO.TEXTURE_CUBE_MAP, hO.TEXTURE_MAG_FILTER, hO.LINEAR), hO.texParameteri(hO.TEXTURE_CUBE_MAP, hO.TEXTURE_MIN_FILTER, hO.LINEAR), hO.texParameteri(hO.TEXTURE_CUBE_MAP, hO.TEXTURE_WRAP_S, hO.CLAMP_TO_EDGE), hO.texParameteri(hO.TEXTURE_CUBE_MAP, hO.TEXTURE_WRAP_T, hO.CLAMP_TO_EDGE), OO.isDDS) {
            const KO = OO.info,
              pO = OO.data;
            this._unpackFlipY(KO.isCompressed), aK.UploadDDSLevels(this, zK, pO, KO, !0, 6, QO)
          } else vK.b.Warn("DDS is the only prefiltered cube map supported so far.");
          this._bindTextureDirectly(hO.TEXTURE_CUBE_MAP, null);
          const AO = new LO.d(KO);
          AO._isCube = !0, AO._texture = zK, zK.isReady = !0, oO.push(AO)
        }
        CO._lodTextureHigh = oO[2], CO._lodTextureMid = oO[1], CO._lodTextureLow = oO[0], eO && eO(CO)
      }), CO, hO, DO, MO, XO, bK, null, void 0, !1, aK)
    });
    var zK = pO(37984);
    let AO = !1;
    AO || (AO = !0, bK.ThinEngine.prototype.createUniformBuffer = function(OO, KO) {
      const pO = this._gl.createBuffer();
      if (!pO) throw new Error("Unable to create uniform buffer");
      const XO = new zK.e(pO);
      return this.bindUniformBuffer(XO), OO instanceof Float32Array ? this._gl.bufferData(this._gl.UNIFORM_BUFFER, OO, this._gl.STATIC_DRAW) : this._gl.bufferData(this._gl.UNIFORM_BUFFER, new Float32Array(OO), this._gl.STATIC_DRAW), this.bindUniformBuffer(null), XO.references = 1, XO
    }, bK.ThinEngine.prototype.createDynamicUniformBuffer = function(OO, KO) {
      const pO = this._gl.createBuffer();
      if (!pO) throw new Error("Unable to create dynamic uniform buffer");
      const XO = new zK.e(pO);
      return this.bindUniformBuffer(XO), OO instanceof Float32Array ? this._gl.bufferData(this._gl.UNIFORM_BUFFER, OO, this._gl.DYNAMIC_DRAW) : this._gl.bufferData(this._gl.UNIFORM_BUFFER, new Float32Array(OO), this._gl.DYNAMIC_DRAW), this.bindUniformBuffer(null), XO.references = 1, XO
    }, bK.ThinEngine.prototype.updateUniformBuffer = function(OO, KO, pO, XO) {
      this.bindUniformBuffer(OO), void 0 === pO && (pO = 0), void 0 === XO ? KO instanceof Float32Array ? this._gl.bufferSubData(this._gl.UNIFORM_BUFFER, pO, KO) : this._gl.bufferSubData(this._gl.UNIFORM_BUFFER, pO, new Float32Array(KO)) : KO instanceof Float32Array ? this._gl.bufferSubData(this._gl.UNIFORM_BUFFER, 0, KO.subarray(pO, pO + XO)) : this._gl.bufferSubData(this._gl.UNIFORM_BUFFER, 0, new Float32Array(KO).subarray(pO, pO + XO)), this.bindUniformBuffer(null)
    }, bK.ThinEngine.prototype.bindUniformBuffer = function(OO) {
      this._gl.bindBuffer(this._gl.UNIFORM_BUFFER, OO ? OO.underlyingResource : null)
    }, bK.ThinEngine.prototype.bindUniformBufferBase = function(OO, KO, pO) {
      this._gl.bindBufferBase(this._gl.UNIFORM_BUFFER, KO, OO ? OO.underlyingResource : null)
    }, bK.ThinEngine.prototype.bindUniformBlock = function(OO, KO, pO) {
      const XO = OO.program,
        bK = this._gl.getUniformBlockIndex(XO, KO);
      4294967295 !== bK && this._gl.uniformBlockBinding(XO, bK, pO)
    });
    var fO = pO(37918),
      dO = pO(37962);
    let TO = !1;
    TO || (TO = !0, dO.e.prototype.displayLoadingUI = function() {
      if (!(0, fO.n)()) return;
      const OO = this.loadingScreen;
      OO && OO.displayLoadingUI()
    }, dO.e.prototype.hideLoadingUI = function() {
      if (!(0, fO.n)()) return;
      const OO = this._loadingScreen;
      OO && OO.hideLoadingUI()
    }, Object.defineProperty(dO.e.prototype, "loadingScreen", {
      get: function() {
        return !this._loadingScreen && this._renderingCanvas && (this._loadingScreen = dO.e.DefaultLoadingScreenFactory(this._renderingCanvas)), this._loadingScreen
      },
      set: function(OO) {
        this._loadingScreen = OO
      },
      enumerable: !0,
      configurable: !0
    }), Object.defineProperty(dO.e.prototype, "loadingUIText", {
      set: function(OO) {
        this.loadingScreen.loadingUIText = OO
      },
      enumerable: !0,
      configurable: !0
    }), Object.defineProperty(dO.e.prototype, "loadingUIBackgroundColor", {
      set: function(OO) {
        this.loadingScreen.loadingUIBackgroundColor = OO
      },
      enumerable: !0,
      configurable: !0
    })), (0, pO(38016).c)();
    let NO = !1;
    NO || (NO = !0, dO.e.prototype.getInputElement = function() {
      return this._renderingCanvas
    }, dO.e.prototype.getDepthFunction = function() {
      return this._depthCullingState.depthFunc
    }, dO.e.prototype.setDepthFunction = function(OO) {
      this._depthCullingState.depthFunc = OO
    }, dO.e.prototype.setDepthFunctionToGreater = function() {
      this.setDepthFunction(516)
    }, dO.e.prototype.setDepthFunctionToGreaterOrEqual = function() {
      this.setDepthFunction(518)
    }, dO.e.prototype.setDepthFunctionToLess = function() {
      this.setDepthFunction(513)
    }, dO.e.prototype.setDepthFunctionToLessOrEqual = function() {
      this.setDepthFunction(515)
    }, dO.e.prototype.getDepthWrite = function() {
      return this._depthCullingState.depthMask
    }, dO.e.prototype.setDepthWrite = function(OO) {
      this._depthCullingState.depthMask = OO
    }, dO.e.prototype.setAlphaConstants = function(OO, KO, pO, XO) {
      this._alphaState.setAlphaBlendConstants(OO, KO, pO, XO)
    }, dO.e.prototype.getAlphaMode = function() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
      return this._alphaMode[OO]
    }, dO.e.prototype.getAlphaEquation = function() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
      return this._alphaEquation[OO]
    });
    let IO = !1;
    IO || (IO = !0, dO.e.prototype.getStencilBuffer = function() {
      return this._stencilState.stencilTest
    }, dO.e.prototype.setStencilBuffer = function(OO) {
      this._stencilState.stencilTest = OO
    }, dO.e.prototype.getStencilMask = function() {
      return this._stencilState.stencilMask
    }, dO.e.prototype.setStencilMask = function(OO) {
      this._stencilState.stencilMask = OO
    }, dO.e.prototype.getStencilFunction = function() {
      return this._stencilState.stencilFunc
    }, dO.e.prototype.getStencilBackFunction = function() {
      return this._stencilState.stencilBackFunc
    }, dO.e.prototype.getStencilFunctionReference = function() {
      return this._stencilState.stencilFuncRef
    }, dO.e.prototype.getStencilFunctionMask = function() {
      return this._stencilState.stencilFuncMask
    }, dO.e.prototype.setStencilFunction = function(OO) {
      this._stencilState.stencilFunc = OO
    }, dO.e.prototype.setStencilBackFunction = function(OO) {
      this._stencilState.stencilBackFunc = OO
    }, dO.e.prototype.setStencilFunctionReference = function(OO) {
      this._stencilState.stencilFuncRef = OO
    }, dO.e.prototype.setStencilFunctionMask = function(OO) {
      this._stencilState.stencilFuncMask = OO
    }, dO.e.prototype.getStencilOperationFail = function() {
      return this._stencilState.stencilOpStencilFail
    }, dO.e.prototype.getStencilBackOperationFail = function() {
      return this._stencilState.stencilBackOpStencilFail
    }, dO.e.prototype.getStencilOperationDepthFail = function() {
      return this._stencilState.stencilOpDepthFail
    }, dO.e.prototype.getStencilBackOperationDepthFail = function() {
      return this._stencilState.stencilBackOpDepthFail
    }, dO.e.prototype.getStencilOperationPass = function() {
      return this._stencilState.stencilOpStencilDepthPass
    }, dO.e.prototype.getStencilBackOperationPass = function() {
      return this._stencilState.stencilBackOpStencilDepthPass
    }, dO.e.prototype.setStencilOperationFail = function(OO) {
      this._stencilState.stencilOpStencilFail = OO
    }, dO.e.prototype.setStencilBackOperationFail = function(OO) {
      this._stencilState.stencilBackOpStencilFail = OO
    }, dO.e.prototype.setStencilOperationDepthFail = function(OO) {
      this._stencilState.stencilOpDepthFail = OO
    }, dO.e.prototype.setStencilBackOperationDepthFail = function(OO) {
      this._stencilState.stencilBackOpDepthFail = OO
    }, dO.e.prototype.setStencilOperationPass = function(OO) {
      this._stencilState.stencilOpStencilDepthPass = OO
    }, dO.e.prototype.setStencilBackOperationPass = function(OO) {
      this._stencilState.stencilBackOpStencilDepthPass = OO
    }, dO.e.prototype.cacheStencilState = function() {
      this._cachedStencilBuffer = this.getStencilBuffer(), this._cachedStencilFunction = this.getStencilFunction(), this._cachedStencilMask = this.getStencilMask(), this._cachedStencilOperationPass = this.getStencilOperationPass(), this._cachedStencilOperationFail = this.getStencilOperationFail(), this._cachedStencilOperationDepthFail = this.getStencilOperationDepthFail(), this._cachedStencilReference = this.getStencilFunctionReference()
    }, dO.e.prototype.restoreStencilState = function() {
      this.setStencilFunction(this._cachedStencilFunction), this.setStencilMask(this._cachedStencilMask), this.setStencilBuffer(this._cachedStencilBuffer), this.setStencilOperationPass(this._cachedStencilOperationPass), this.setStencilOperationFail(this._cachedStencilOperationFail), this.setStencilOperationDepthFail(this._cachedStencilOperationDepthFail), this.setStencilFunctionReference(this._cachedStencilReference)
    });
    pO(38092);
    let yK = !1;
    yK || (yK = !0, dO.e.prototype.createDepthStencilTexture = function(OO, KO, pO) {
      if (KO.isCube) {
        const pO = OO.width || OO;
        return this._createDepthStencilCubeTexture(pO, KO)
      }
      return this._createDepthStencilTexture(OO, KO, pO)
    });
    pO(38099), pO(38149);
    let gK = !1;
    gK || (gK = !0, bK.ThinEngine.prototype.enableScissor = function(OO, KO, pO, XO) {
      const bK = this._gl;
      bK.enable(bK.SCISSOR_TEST), bK.scissor(OO, KO, pO, XO)
    }, bK.ThinEngine.prototype.disableScissor = function() {
      const OO = this._gl;
      OO.disable(OO.SCISSOR_TEST)
    })
  },
  37887: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => dO
    });
    var XO = pO(37889),
      bK = pO(35653),
      eO = pO(37899),
      lO = pO(37966);
    class vK {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 30;
        this._enabled = !0, this._rollingFrameTime = new CO(OO)
      }
      sampleFrame() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.d.Now;
        if (this._enabled) {
          if (null != this._lastFrameTimeMs) {
            const KO = OO - this._lastFrameTimeMs;
            this._rollingFrameTime.add(KO)
          }
          this._lastFrameTimeMs = OO
        }
      }
      get averageFrameTime() {
        return this._rollingFrameTime.average
      }
      get averageFrameTimeVariance() {
        return this._rollingFrameTime.variance
      }
      get instantaneousFrameTime() {
        return this._rollingFrameTime.history(0)
      }
      get averageFPS() {
        return 1e3 / this._rollingFrameTime.average
      }
      get instantaneousFPS() {
        const OO = this._rollingFrameTime.history(0);
        return 0 === OO ? 0 : 1e3 / OO
      }
      get isSaturated() {
        return this._rollingFrameTime.isSaturated()
      }
      enable() {
        this._enabled = !0
      }
      disable() {
        this._enabled = !1, this._lastFrameTimeMs = null
      }
      get isEnabled() {
        return this._enabled
      }
      reset() {
        this._lastFrameTimeMs = null, this._rollingFrameTime.reset()
      }
    }
    class CO {
      constructor(OO) {
        this._samples = new Array(OO), this.reset()
      }
      add(OO) {
        let KO;
        if (this.isSaturated()) {
          const OO = this._samples[this._pos];
          KO = OO - this.average, this.average -= KO / (this._sampleCount - 1), this._m2 -= KO * (OO - this.average)
        } else this._sampleCount++;
        KO = OO - this.average, this.average += KO / this._sampleCount, this._m2 += KO * (OO - this.average), this.variance = this._m2 / (this._sampleCount - 1), this._samples[this._pos] = OO, this._pos++, this._pos %= this._samples.length
      }
      history(OO) {
        if (OO >= this._sampleCount || OO >= this._samples.length) return 0;
        const KO = this._wrapPosition(this._pos - 1);
        return this._samples[this._wrapPosition(KO - OO)]
      }
      isSaturated() {
        return this._sampleCount >= this._samples.length
      }
      reset() {
        this.average = 0, this.variance = 0, this._sampleCount = 0, this._pos = 0, this._m2 = 0
      }
      _wrapPosition(OO) {
        const KO = this._samples.length;
        return (OO % KO + KO) % KO
      }
    }
    var hO = pO(37984),
      DO = pO(37061),
      MO = pO(38001),
      aK = pO(37962),
      oO = pO(37918);

    function FO(OO) {
      const KO = function(OO) {
        if (!(0, oO.g)() || !document.body) return null;
        const KO = document.createElement("span");
        KO.textContent = "Hg", KO.style.font = OO;
        const pO = document.createElement("div");
        pO.style.display = "inline-block", pO.style.width = "1px", pO.style.height = "0px", pO.style.verticalAlign = "bottom";
        const XO = document.createElement("div");
        let bK, eO;
        XO.style.whiteSpace = "nowrap", XO.appendChild(KO), XO.appendChild(pO), document.body.appendChild(XO);
        try {
          eO = pO.getBoundingClientRect().top - KO.getBoundingClientRect().top, pO.style.verticalAlign = "baseline", bK = pO.getBoundingClientRect().top - KO.getBoundingClientRect().top
        } finally {
          document.body.removeChild(XO)
        }
        const lO = {
          ascent: bK,
          height: eO,
          descent: eO - bK
        };
        return VO(lO) ? lO : null
      }(OO);
      if (KO) return KO;
      const pO = function(OO) {
        let KO = null;
        try {
          "undefined" !== typeof OffscreenCanvas ? KO = new OffscreenCanvas(64, 64) : (0, oO.g)() && "function" === typeof document.createElement && (KO = document.createElement("canvas"), KO.width = 64, KO.height = 64);
          const pO = KO?.getContext("2d");
          if (!pO) return null;
          pO.font = OO;
          const XO = pO.measureText("Hg"),
            bK = Number(XO.actualBoundingBoxAscent ?? XO.fontBoundingBoxAscent),
            eO = Number(XO.actualBoundingBoxDescent ?? XO.fontBoundingBoxDescent),
            lO = {
              ascent: bK,
              height: bK + eO,
              descent: eO
            };
          return VO(lO) ? lO : null
        } catch {
          return null
        } finally {
          const OO = KO;
          "function" === typeof OO?.dispose && OO.dispose()
        }
      }(OO);
      return pO || function(OO) {
        const KO = Math.max(1, function(OO) {
            const KO = /(?:^|\s)([0-9]+(?:\.[0-9]+)?)px(?:\/|\s|$)/.exec(String(OO || ""));
            return KO ? Number(KO[1]) : 16
          }(OO)),
          pO = .8 * KO,
          XO = .2 * KO;
        return {
          ascent: pO,
          height: pO + XO,
          descent: XO
        }
      }(OO)
    }

    function VO(OO) {
      return Number.isFinite(OO.ascent) && Number.isFinite(OO.height) && Number.isFinite(OO.descent) && OO.height > 0
    }

    function LO(OO) {
      if (OO.requestPointerLock) {
        const KO = OO.requestPointerLock();
        KO instanceof Promise ? KO.then((() => {
          OO.focus()
        })).catch((() => {})) : OO.focus()
      }
    }
    var QO = pO(38011),
      zK = pO(37955),
      AO = pO(38016),
      fO = pO(38021);
    class dO extends eO.ThinEngine {
      static get NpmPackage() {
        return aK.e.NpmPackage
      }
      static get Version() {
        return aK.e.Version
      }
      static get Instances() {
        return bK.c.Instances
      }
      static get LastCreatedEngine() {
        return bK.c.LastCreatedEngine
      }
      static get LastCreatedScene() {
        return bK.c.LastCreatedScene
      }
      static DefaultLoadingScreenFactory(OO) {
        return aK.e.DefaultLoadingScreenFactory(OO)
      }
      get _supportsHardwareTextureRescaling() {
        return !!dO._RescalePostProcessFactory
      }
      _measureFps() {
        this._performanceMonitor.sampleFrame(), this._fps = this._performanceMonitor.averageFPS, this._deltaTime = this._performanceMonitor.instantaneousFrameTime || 0
      }
      get performanceMonitor() {
        return this._performanceMonitor
      }
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        (0, AO.c)(), (0, fO.e)(), super(OO, KO, pO, XO), this._performanceMonitor = new vK, this._drawCalls = new QO.c, OO && (this._features.supportRenderPasses = !0)
      }
      _initGLContext() {
        super._initGLContext(), this._rescalePostProcess = null
      }
      _sharedInit(OO) {
        super._sharedInit(OO),
          function(OO, KO, pO) {
            OO._onCanvasFocus = () => {
              OO.onCanvasFocusObservable.notifyObservers(OO)
            }, OO._onCanvasBlur = () => {
              OO.onCanvasBlurObservable.notifyObservers(OO)
            }, OO._onCanvasContextMenu = KO => {
              OO.disableContextMenu && KO.preventDefault()
            }, KO.addEventListener("focus", OO._onCanvasFocus), KO.addEventListener("blur", OO._onCanvasBlur), KO.addEventListener("contextmenu", OO._onCanvasContextMenu), OO._onBlur = () => {
              OO.disablePerformanceMonitorInBackground && OO.performanceMonitor.disable(), OO._windowIsBackground = !0
            }, OO._onFocus = () => {
              OO.disablePerformanceMonitorInBackground && OO.performanceMonitor.enable(), OO._windowIsBackground = !1
            }, OO._onCanvasPointerOut = pO => {
              document.elementFromPoint(pO.clientX, pO.clientY) !== KO && OO.onCanvasPointerOutObservable.notifyObservers(pO)
            };
            const XO = OO.getHostWindow();
            XO && "function" === typeof XO.addEventListener && (XO.addEventListener("blur", OO._onBlur), XO.addEventListener("focus", OO._onFocus)), KO.addEventListener("pointerout", OO._onCanvasPointerOut), pO.doNotHandleTouchAction || function(OO) {
              OO && OO.setAttribute && (OO.setAttribute("touch-action", "none"), OO.style.touchAction = "none", OO.style.webkitTapHighlightColor = "transparent")
            }(KO), !aK.e.audioEngine && pO.audioEngine && aK.e.AudioEngineFactory && (aK.e.audioEngine = aK.e.AudioEngineFactory(OO.getRenderingCanvas(), OO.getAudioContext(), OO.getAudioDestination())), (0, oO.g)() && (OO._onFullscreenChange = () => {
              OO.isFullscreen = !!document.fullscreenElement, OO.isFullscreen && OO._pointerLockRequested && KO && LO(KO)
            }, document.addEventListener("fullscreenchange", OO._onFullscreenChange, !1), document.addEventListener("webkitfullscreenchange", OO._onFullscreenChange, !1), OO._onPointerLockChange = () => {
              OO.isPointerLock = document.pointerLockElement === KO
            }, document.addEventListener("pointerlockchange", OO._onPointerLockChange, !1), document.addEventListener("webkitpointerlockchange", OO._onPointerLockChange, !1)), OO.enableOfflineSupport = void 0 !== aK.e.OfflineProviderFactory, OO._deterministicLockstep = !!pO.deterministicLockstep, OO._lockstepMaxSteps = pO.lockstepMaxSteps || 0, OO._timeStep = pO.timeStep || 1 / 60
          }(this, OO, this._creationOptions)
      }
      resizeImageBitmap(OO, KO, pO) {
        return function(OO, KO, pO, XO) {
          const bK = OO.createCanvas(pO, XO).getContext("2d");
          if (!bK) throw new Error("Unable to get 2d context for resizeImageBitmap");
          return bK.drawImage(KO, 0, 0), bK.getImageData(0, 0, pO, XO).data
        }(this, OO, KO, pO)
      }
      async _createImageBitmapFromSource(OO, KO) {
        return await async function(OO, KO, pO) {
          return await new Promise(((XO, bK) => {
            const eO = new Image;
            eO.onload = () => {
              eO.decode().then((() => {
                OO.createImageBitmap(eO, pO).then((OO => {
                  XO(OO)
                }))
              }))
            }, eO.onerror = () => {
              bK(`Error loading image ${eO.src}`)
            }, eO.src = KO
          }))
        }(this, OO, KO)
      }
      switchFullscreen(OO) {
        this.isFullscreen ? this.exitFullscreen() : this.enterFullscreen(OO)
      }
      enterFullscreen(OO) {
        this.isFullscreen || (this._pointerLockRequested = OO, this._renderingCanvas && function(OO) {
          const KO = OO.requestFullscreen || OO.webkitRequestFullscreen;
          KO && KO.call(OO)
        }(this._renderingCanvas))
      }
      exitFullscreen() {
        this.isFullscreen && function() {
          const OO = document;
          document.exitFullscreen ? document.exitFullscreen() : OO.webkitCancelFullScreen && OO.webkitCancelFullScreen()
        }()
      }
      setDitheringState(OO) {
        OO ? this._gl.enable(this._gl.DITHER) : this._gl.disable(this._gl.DITHER)
      }
      setRasterizerState(OO) {
        OO ? this._gl.disable(this._gl.RASTERIZER_DISCARD) : this._gl.enable(this._gl.RASTERIZER_DISCARD)
      }
      setDirectViewport(OO, KO, pO, XO) {
        const bK = this._cachedViewport;
        return this._cachedViewport = null, this._viewport(OO, KO, pO, XO), bK
      }
      scissorClear(OO, KO, pO, XO, bK) {
        this.enableScissor(OO, KO, pO, XO), this.clear(bK, !0, !0, !0), this.disableScissor()
      }
      getVertexShaderSource(OO) {
        const KO = this._gl.getAttachedShaders(OO);
        return KO ? this._gl.getShaderSource(KO[0]) : null
      }
      getFragmentShaderSource(OO) {
        const KO = this._gl.getAttachedShaders(OO);
        return KO ? this._gl.getShaderSource(KO[1]) : null
      }
      set framebufferDimensionsObject(OO) {
        this._framebufferDimensionsObject = OO, this._framebufferDimensionsObject && this.onResizeObservable.notifyObservers(this)
      }
      _rebuildBuffers() {
        for (const OO of this.scenes) OO.resetCachedMaterial(), OO._rebuildGeometries();
        for (const OO of this._virtualScenes) OO.resetCachedMaterial(), OO._rebuildGeometries();
        super._rebuildBuffers()
      }
      getFontOffset(OO) {
        return FO(OO)
      }
      enterPointerlock() {
        this._renderingCanvas && LO(this._renderingCanvas)
      }
      exitPointerlock() {
        document.exitPointerLock && document.exitPointerLock()
      }
      uL() {
        this._measureFps(), super.uL()
      }
      _deletePipelineContext(OO) {
        const KO = OO;
        KO && KO.program && KO.transformFeedback && (this.deleteTransformFeedback(KO.transformFeedback), KO.transformFeedback = null), super._deletePipelineContext(OO)
      }
      createShaderProgram(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null;
        bK = bK || this._gl, this.onBeforeShaderCompilationObservable.notifyObservers(this);
        const lO = super.createShaderProgram(OO, KO, pO, XO, bK, eO);
        return this.onAfterShaderCompilationObservable.notifyObservers(this), lO
      }
      _createShaderProgram(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
        const eO = XO.createProgram();
        if (OO.program = eO, !eO) throw new Error("Unable to create program");
        if (XO.attachShader(eO, KO), XO.attachShader(eO, pO), this.ye > 1 && bK) {
          const KO = this.createTransformFeedback();
          this.bindTransformFeedback(KO), this.setTranformFeedbackVaryings(eO, bK), OO.transformFeedback = KO
        }
        return XO.linkProgram(eO), this.ye > 1 && bK && this.bindTransformFeedback(null), OO.context = XO, OO.vertexShader = KO, OO.fragmentShader = pO, OO.isParallelCompiled || this._finalizePipelineContext(OO), eO
      }
      _releaseTexture(OO) {
        super._releaseTexture(OO)
      }
      _releaseRenderTargetWrapper(OO) {
        super._releaseRenderTargetWrapper(OO);
        for (const KO of this.scenes) {
          for (const pO of KO.postProcesses) pO._outputTexture === OO && (pO._outputTexture = null);
          for (const pO of KO.cameras)
            for (const KO of pO._postProcesses) KO && KO._outputTexture === OO && (KO._outputTexture = null)
        }
      }
      _rescaleTexture(OO, KO, pO, XO, bK) {
        this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MAG_FILTER, this._gl.LINEAR), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MIN_FILTER, this._gl.LINEAR), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_S, this._gl.CLAMP_TO_EDGE), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_T, this._gl.CLAMP_TO_EDGE);
        const eO = this.createRenderTargetTexture({
          width: KO.width,
          height: KO.height
        }, {
          generateMipMaps: !1,
          type: 0,
          samplingMode: 2,
          generateDepthBuffer: !1,
          generateStencilBuffer: !1
        });
        if (!this._rescalePostProcess && dO._RescalePostProcessFactory && (this._rescalePostProcess = dO._RescalePostProcessFactory(this)), this._rescalePostProcess) {
          this._rescalePostProcess.externalTextureSamplerBinding = !0;
          const lO = () => {
              this._rescalePostProcess.onApply = function(KO) {
                KO._bindTexture("textureSampler", OO)
              };
              let lO = pO;
              lO || (lO = this.scenes[this.scenes.length - 1]), lO.postProcessManager.directRender([this._rescalePostProcess], eO, !0), this._bindTextureDirectly(this._gl.TEXTURE_2D, KO, !0), this._gl.copyTexImage2D(this._gl.TEXTURE_2D, 0, XO, 0, 0, KO.width, KO.height, 0), this.unBindFramebuffer(eO), eO.dispose(), bK && bK()
            },
            vK = this._rescalePostProcess.getEffect();
          vK ? vK.executeWhenCompiled(lO) : this._rescalePostProcess.onEffectCreatedObservable.addOnce((OO => {
            OO.executeWhenCompiled(lO)
          }))
        }
      }
      wrapWebGLTexture(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 3,
          bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
          eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0;
        const lO = new MO.c(OO, this._gl),
          vK = new XO.e(this, 15, !0);
        return vK._hardwareTexture = lO, vK.baseWidth = bK, vK.baseHeight = eO, vK.width = bK, vK.height = eO, vK.isReady = !0, vK.useMipMaps = KO, this.updateTextureSamplingMode(pO, vK), vK
      }
      updateWrappedWebGLTexture(OO, KO) {
        if (15 !== OO.source) throw new Error("updateWrappedWebGLTexture: target InternalTexture was not produced by wrapWebGLTexture.");
        for (const XO of this._renderTargetWrapperCache)
          if (XO.textures?.includes(OO)) {
            if (XO.isMulti) throw new Error("updateWrappedWebGLTexture: wrapped texture is part of a multi render-target; not supported. Dispose and re-wrap.");
            if (XO._depthStencilTexture) throw new Error("updateWrappedWebGLTexture: wrapped texture's render-target wrapper has a depth/stencil texture; not supported. Dispose and re-wrap.")
          } OO._hardwareTexture = new MO.c(KO, this._gl), OO.isReady = !0, OO._cachedCoordinatesMode = null, OO._cachedWrapU = null, OO._cachedWrapV = null, OO._cachedWrapR = null, OO._cachedAnisotropicFilteringLevel = null;
        for (const XO in this._boundTexturesCache) this._boundTexturesCache[XO] === OO && (this._boundTexturesCache[XO] = null);
        this.updateTextureSamplingMode(OO.samplingMode, OO);
        const pO = this._gl;
        for (const XO of this._renderTargetWrapperCache) {
          if (XO.texture !== OO) continue;
          const bK = XO,
            eO = XO.samples,
            lO = eO > 1;
          bK._framebuffer && pO.deleteFramebuffer(bK._framebuffer), !lO && bK._depthStencilBuffer && (pO.deleteRenderbuffer(bK._depthStencilBuffer), bK._depthStencilBuffer = null);
          const vK = this._currentFramebuffer,
            CO = pO.createFramebuffer();
          this._bindUnboundFramebuffer(CO), pO.framebufferTexture2D(pO.FRAMEBUFFER, pO.COLOR_ATTACHMENT0, pO.TEXTURE_2D, KO, 0), lO || (bK._depthStencilBuffer = this._setupFramebufferDepthAttachments(XO._generateStencilBuffer, XO._generateDepthBuffer, XO.width, XO.height)), this._bindUnboundFramebuffer(vK), bK._framebuffer = CO, lO && (XO._samples = 1, this.updateRenderTargetTextureSampleCount(bK, eO))
        }
      }
      _uploadImageToTexture(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        const bK = this._gl,
          eO = this._getWebGLTextureType(OO.type),
          lO = this._getInternalFormat(OO.format),
          vK = this._getRGBABufferInternalSizedFormat(OO.type, lO),
          CO = OO.isCube ? bK.TEXTURE_CUBE_MAP : bK.TEXTURE_2D;
        this._bindTextureDirectly(CO, OO, !0), this._unpackFlipY(OO.invertY);
        let hO = bK.TEXTURE_2D;
        OO.isCube && (hO = bK.TEXTURE_CUBE_MAP_POSITIVE_X + pO), bK.texImage2D(hO, XO, vK, lO, eO, KO), this._bindTextureDirectly(CO, null, !0)
      }
      updateTextureComparisonFunction(OO, KO) {
        if (1 === this.ye) return void DO.b.Error("WebGL 1 does not support texture comparison.");
        const pO = this._gl;
        OO.isCube ? (this._bindTextureDirectly(this._gl.TEXTURE_CUBE_MAP, OO, !0), 0 === KO ? (pO.texParameteri(pO.TEXTURE_CUBE_MAP, pO.TEXTURE_COMPARE_FUNC, 515), pO.texParameteri(pO.TEXTURE_CUBE_MAP, pO.TEXTURE_COMPARE_MODE, pO.NONE)) : (pO.texParameteri(pO.TEXTURE_CUBE_MAP, pO.TEXTURE_COMPARE_FUNC, KO), pO.texParameteri(pO.TEXTURE_CUBE_MAP, pO.TEXTURE_COMPARE_MODE, pO.COMPARE_REF_TO_TEXTURE)), this._bindTextureDirectly(this._gl.TEXTURE_CUBE_MAP, null)) : (this._bindTextureDirectly(this._gl.TEXTURE_2D, OO, !0), 0 === KO ? (pO.texParameteri(pO.TEXTURE_2D, pO.TEXTURE_COMPARE_FUNC, 515), pO.texParameteri(pO.TEXTURE_2D, pO.TEXTURE_COMPARE_MODE, pO.NONE)) : (pO.texParameteri(pO.TEXTURE_2D, pO.TEXTURE_COMPARE_FUNC, KO), pO.texParameteri(pO.TEXTURE_2D, pO.TEXTURE_COMPARE_MODE, pO.COMPARE_REF_TO_TEXTURE)), this._bindTextureDirectly(this._gl.TEXTURE_2D, null)), OO._comparisonFunction = KO
      }
      createInstancesBuffer(OO) {
        const KO = this._gl.createBuffer();
        if (!KO) throw new Error("Unable to create instance buffer");
        const pO = new hO.e(KO);
        return pO.YO = OO, this.bindArrayBuffer(pO), this._gl.bufferData(this._gl.ARRAY_BUFFER, OO, this._gl.DYNAMIC_DRAW), pO.references = 1, pO
      }
      deleteInstancesBuffer(OO) {
        this._gl.deleteBuffer(OO)
      }
      async _clientWaitAsync(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 10;
        const XO = this._gl;
        return await new Promise(((bK, eO) => {
          (0, zK.e)((() => {
            const pO = XO.clientWaitSync(OO, KO, 0);
            if (pO == XO.WAIT_FAILED) throw new Error("clientWaitSync failed");
            return pO != XO.TIMEOUT_EXPIRED
          }), bK, eO, pO)
        }))
      }
      _readPixelsAsync(OO, KO, pO, XO, bK, eO, lO) {
        if (this._webGLVersion < 2) throw new Error("_readPixelsAsync only work on WebGL2+");
        const vK = this._gl,
          CO = vK.createBuffer();
        vK.bindBuffer(vK.PIXEL_PACK_BUFFER, CO), vK.bufferData(vK.PIXEL_PACK_BUFFER, lO.byteLength, vK.STREAM_READ), vK.readPixels(OO, KO, pO, XO, bK, eO, 0), vK.bindBuffer(vK.PIXEL_PACK_BUFFER, null);
        const hO = vK.fenceSync(vK.SYNC_GPU_COMMANDS_COMPLETE, 0);
        return hO ? (vK.flush(), this._clientWaitAsync(hO, 0, 10).then((() => (vK.deleteSync(hO), vK.bindBuffer(vK.PIXEL_PACK_BUFFER, CO), vK.getBufferSubData(vK.PIXEL_PACK_BUFFER, 0, lO), vK.bindBuffer(vK.PIXEL_PACK_BUFFER, null), vK.deleteBuffer(CO), lO)))) : null
      }
      dispose() {
        this.hideLoadingUI?.(), this._rescalePostProcess && this._rescalePostProcess.dispose(),
          function(OO, KO) {
            1 === bK.c.Instances.length && aK.e.audioEngine && (aK.e.audioEngine.dispose(), aK.e.audioEngine = null);
            const pO = OO.getHostWindow();
            pO && "function" === typeof pO.removeEventListener && (pO.removeEventListener("blur", OO._onBlur), pO.removeEventListener("focus", OO._onFocus)), KO && (KO.removeEventListener("focus", OO._onCanvasFocus), KO.removeEventListener("blur", OO._onCanvasBlur), KO.removeEventListener("pointerout", OO._onCanvasPointerOut), KO.removeEventListener("contextmenu", OO._onCanvasContextMenu)), (0, oO.g)() && (document.removeEventListener("fullscreenchange", OO._onFullscreenChange), document.removeEventListener("mozfullscreenchange", OO._onFullscreenChange), document.removeEventListener("webkitfullscreenchange", OO._onFullscreenChange), document.removeEventListener("msfullscreenchange", OO._onFullscreenChange), document.removeEventListener("pointerlockchange", OO._onPointerLockChange), document.removeEventListener("mspointerlockchange", OO._onPointerLockChange), document.removeEventListener("mozpointerlockchange", OO._onPointerLockChange), document.removeEventListener("webkitpointerlockchange", OO._onPointerLockChange))
          }(this, this._renderingCanvas), super.dispose()
      }
    }
    dO.ALPHA_DISABLE = 0, dO.ALPHA_ADD = 1, dO.ALPHA_COMBINE = 2, dO.ALPHA_SUBTRACT = 3, dO.ALPHA_MULTIPLY = 4, dO.ALPHA_MAXIMIZED = 5, dO.ALPHA_ONEONE = 6, dO.ALPHA_PREMULTIPLIED = 7, dO.ALPHA_PREMULTIPLIED_PORTERDUFF = 8, dO.ALPHA_INTERPOLATE = 9, dO.ALPHA_SCREENMODE = 10, dO.DELAYLOADSTATE_NONE = 0, dO.DELAYLOADSTATE_LOADED = 1, dO.DELAYLOADSTATE_LOADING = 2, dO.DELAYLOADSTATE_NOTLOADED = 4, dO.NEVER = 512, dO.ALWAYS = 519, dO.LESS = 513, dO.EQUAL = 514, dO.LEQUAL = 515, dO.GREATER = 516, dO.GEQUAL = 518, dO.NOTEQUAL = 517, dO.KEEP = 7680, dO.REPLACE = 7681, dO.INCR = 7682, dO.DECR = 7683, dO.INVERT = 5386, dO.INCR_WRAP = 34055, dO.DECR_WRAP = 34056, dO.TEXTURE_CLAMP_ADDRESSMODE = 0, dO.TEXTURE_WRAP_ADDRESSMODE = 1, dO.TEXTURE_MIRROR_ADDRESSMODE = 2, dO.TEXTUREFORMAT_ALPHA = 0, dO.TEXTUREFORMAT_LUMINANCE = 1, dO.TEXTUREFORMAT_LUMINANCE_ALPHA = 2, dO.TEXTUREFORMAT_RGB = 4, dO.TEXTUREFORMAT_RGBA = 5, dO.TEXTUREFORMAT_RED = 6, dO.TEXTUREFORMAT_R = 6, dO.TEXTUREFORMAT_R16_UNORM = 33322, dO.TEXTUREFORMAT_RG16_UNORM = 33324, dO.TEXTUREFORMAT_RGB16_UNORM = 32852, dO.TEXTUREFORMAT_RGBA16_UNORM = 32859, dO.TEXTUREFORMAT_R16_SNORM = 36760, dO.TEXTUREFORMAT_RG16_SNORM = 36761, dO.TEXTUREFORMAT_RGB16_SNORM = 36762, dO.TEXTUREFORMAT_RGBA16_SNORM = 36763, dO.TEXTUREFORMAT_RG = 7, dO.TEXTUREFORMAT_RED_INTEGER = 8, dO.TEXTUREFORMAT_R_INTEGER = 8, dO.TEXTUREFORMAT_RG_INTEGER = 9, dO.TEXTUREFORMAT_RGB_INTEGER = 10, dO.TEXTUREFORMAT_RGBA_INTEGER = 11, dO.TEXTURETYPE_UNSIGNED_BYTE = 0, dO.TEXTURETYPE_UNSIGNED_INT = 0, dO.TEXTURETYPE_FLOAT = 1, dO.TEXTURETYPE_HALF_FLOAT = 2, dO.TEXTURETYPE_BYTE = 3, dO.TEXTURETYPE_SHORT = 4, dO.TEXTURETYPE_UNSIGNED_SHORT = 5, dO.TEXTURETYPE_INT = 6, dO.TEXTURETYPE_UNSIGNED_INTEGER = 7, dO.TEXTURETYPE_UNSIGNED_SHORT_4_4_4_4 = 8, dO.TEXTURETYPE_UNSIGNED_SHORT_5_5_5_1 = 9, dO.TEXTURETYPE_UNSIGNED_SHORT_5_6_5 = 10, dO.TEXTURETYPE_UNSIGNED_INT_2_10_10_10_REV = 11, dO.TEXTURETYPE_UNSIGNED_INT_24_8 = 12, dO.TEXTURETYPE_UNSIGNED_INT_10F_11F_11F_REV = 13, dO.TEXTURETYPE_UNSIGNED_INT_5_9_9_9_REV = 14, dO.TEXTURETYPE_FLOAT_32_UNSIGNED_INT_24_8_REV = 15, dO.TEXTURE_NEAREST_SAMPLINGMODE = 1, dO.TEXTURE_BILINEAR_SAMPLINGMODE = 2, dO.TEXTURE_TRILINEAR_SAMPLINGMODE = 3, dO.TEXTURE_NEAREST_NEAREST_MIPLINEAR = 8, dO.TEXTURE_LINEAR_LINEAR_MIPNEAREST = 11, dO.TEXTURE_LINEAR_LINEAR_MIPLINEAR = 3, dO.TEXTURE_NEAREST_NEAREST_MIPNEAREST = 4, dO.TEXTURE_NEAREST_LINEAR_MIPNEAREST = 5, dO.TEXTURE_NEAREST_LINEAR_MIPLINEAR = 6, dO.TEXTURE_NEAREST_LINEAR = 7, dO.TEXTURE_NEAREST_NEAREST = 1, dO.TEXTURE_LINEAR_NEAREST_MIPNEAREST = 9, dO.TEXTURE_LINEAR_NEAREST_MIPLINEAR = 10, dO.TEXTURE_LINEAR_LINEAR = 2, dO.TEXTURE_LINEAR_NEAREST = 12, dO.TEXTURE_EXPLICIT_MODE = 0, dO.TEXTURE_SPHERICAL_MODE = 1, dO.TEXTURE_PLANAR_MODE = 2, dO.TEXTURE_CUBIC_MODE = 3, dO.TEXTURE_PROJECTION_MODE = 4, dO.TEXTURE_SKYBOX_MODE = 5, dO.TEXTURE_INVCUBIC_MODE = 6, dO.TEXTURE_EQUIRECTANGULAR_MODE = 7, dO.TEXTURE_FIXED_EQUIRECTANGULAR_MODE = 8, dO.TEXTURE_FIXED_EQUIRECTANGULAR_MIRRORED_MODE = 9, dO.SCALEMODE_FLOOR = 1, dO.SCALEMODE_NEAREST = 2, dO.SCALEMODE_CEILING = 3
  },
  38041: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(38004);
    class bK {
      get depthStencilTexture() {
        return this._depthStencilTexture
      }
      setDepthStencilTexture(OO) {
        (!(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1]) && this._depthStencilTexture && this._depthStencilTexture.dispose(), this._depthStencilTexture = OO, this._generateDepthBuffer = this._generateStencilBuffer = this._depthStencilTextureWithStencil = !1, OO && (this._generateDepthBuffer = !0, this._generateStencilBuffer = this._depthStencilTextureWithStencil = (0, XO.d)(OO.format))
      }
      get depthStencilTextureWithStencil() {
        return this._depthStencilTextureWithStencil
      }
      get isCube() {
        return this._isCube
      }
      get isMulti() {
        return this._isMulti
      }
      get is2DArray() {
        return this.layers > 0
      }
      get is3D() {
        return this.depth > 0
      }
      get size() {
        return this.width
      }
      get width() {
        return this._size.width ?? this._size
      }
      get height() {
        return this._size.height ?? this._size
      }
      get layers() {
        return this._size.layers || 0
      }
      get depth() {
        return this._size.depth || 0
      }
      get texture() {
        return this._textures?.[0] ?? null
      }
      get textures() {
        return this._textures
      }
      get faceIndices() {
        return this._faceIndices
      }
      get layerIndices() {
        return this._layerIndices
      }
      getBaseArrayLayer(OO) {
        if (!this._textures) return -1;
        const KO = this._textures[OO],
          pO = this._layerIndices?.[OO] ?? 0,
          XO = this._faceIndices?.[OO] ?? 0;
        return KO.isCube ? 6 * pO + XO : KO.is3D ? 0 : pO
      }
      get samples() {
        return this._samples
      }
      setSamples(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (this.samples === OO && !pO) return OO;
        const XO = this._isMulti ? this._engine.updateMultipleRenderTargetTextureSampleCount(this, OO, KO) : this._engine.updateRenderTargetTextureSampleCount(this, OO);
        return this._samples = OO, XO
      }
      resolveMSAATextures() {
        this.isMulti ? this._engine.resolveMultiFramebuffer(this) : this._engine.resolveFramebuffer(this)
      }
      generateMipMaps() {
        this._engine._currentRenderTarget === this && (this.isMulti ? this._engine.unBindMultiColorAttachmentFramebuffer(this, !0) : this._engine.unBindFramebuffer(this, !0)), this.isMulti ? this._engine.generateMipMapsMultiFramebuffer(this) : this._engine.generateMipMapsFramebuffer(this)
      }
      constructor(OO, KO, pO, XO, bK) {
        this._textures = null, this._faceIndices = null, this._layerIndices = null, this._samples = 1, this._attachments = null, this._generateStencilBuffer = !1, this._generateDepthBuffer = !1, this._depthStencilTextureWithStencil = !1, this.disableAutomaticMSAAResolve = !1, this.resolveMSAAColors = !0, this.resolveMSAADepth = !1, this.resolveMSAAStencil = !1, this.depthReadOnly = !1, this.stencilReadOnly = !1, this._isMulti = OO, this._isCube = KO, this._size = pO, this._engine = XO, this._depthStencilTexture = null, this.label = bK
      }
      setTextures(OO) {
        Array.isArray(OO) ? this._textures = OO : this._textures = OO ? [OO] : null
      }
      setTexture(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        this._textures || (this._textures = []), this._textures[KO] !== OO && (this._textures[KO] && pO && this._textures[KO].dispose(), this._textures[KO] = OO)
      }
      setLayerAndFaceIndices(OO, KO) {
        this._layerIndices = OO, this._faceIndices = KO
      }
      setLayerAndFaceIndex() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        this._layerIndices || (this._layerIndices = []), this._faceIndices || (this._faceIndices = []), void 0 !== KO && KO >= 0 && (this._layerIndices[OO] = KO), void 0 !== pO && pO >= 0 && (this._faceIndices[OO] = pO)
      }
      createDepthStencilTexture() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 14,
          eO = arguments.length > 5 ? arguments[5] : void 0;
        return this._depthStencilTexture?.dispose(), this._depthStencilTextureWithStencil = pO, this._depthStencilTextureLabel = eO, this._depthStencilTexture = this._engine.createDepthStencilTexture(this._size, {
          bilinearFiltering: KO,
          comparisonFunction: OO,
          generateStencil: pO,
          isCube: this._isCube,
          samples: XO,
          depthTextureFormat: bK,
          label: eO
        }, this), this._depthStencilTexture
      }
      _shareDepth(OO) {
        this.shareDepth(OO)
      }
      shareDepth(OO) {
        this._depthStencilTexture && (OO._depthStencilTexture && OO._depthStencilTexture.dispose(), OO._depthStencilTexture = this._depthStencilTexture, OO._depthStencilTextureWithStencil = this._depthStencilTextureWithStencil, this._depthStencilTexture.incrementReferences())
      }
      _swapAndDie(OO) {
        this.texture && this.texture._swapAndDie(OO), this._textures = null, this.dispose(!0)
      }
      _cloneRenderTargetWrapper() {
        let OO = null;
        if (this._isMulti) {
          const KO = this.textures;
          if (KO && KO.length > 0) {
            let pO = !1,
              XO = KO.length,
              bK = -1;
            const eO = KO[KO.length - 1]._source;
            14 !== eO && 12 !== eO || (pO = !0, bK = KO[KO.length - 1].format, XO--);
            const lO = [],
              vK = [],
              CO = [],
              hO = [],
              DO = [],
              MO = [],
              aK = [],
              oO = {};
            for (let OO = 0; OO < XO; ++OO) {
              const pO = KO[OO];
              lO.push(pO.samplingMode), vK.push(pO.type), CO.push(pO.format);
              void 0 !== oO[pO.uniqueId] ? (hO.push(-1), aK.push(0)) : (oO[pO.uniqueId] = OO, pO.is2DArray ? (hO.push(35866), aK.push(pO.depth)) : pO.isCube ? (hO.push(34067), aK.push(0)) : pO.is3D ? (hO.push(32879), aK.push(pO.depth)) : (hO.push(3553), aK.push(0))), this._faceIndices && DO.push(this._faceIndices[OO] ?? 0), this._layerIndices && MO.push(this._layerIndices[OO] ?? 0)
            }
            const FO = {
                samplingModes: lO,
                generateMipMaps: KO[0].generateMipMaps,
                generateDepthBuffer: this._generateDepthBuffer,
                generateStencilBuffer: this._generateStencilBuffer,
                generateDepthTexture: pO,
                depthTextureFormat: bK,
                types: vK,
                formats: CO,
                PoO: XO,
                targetTypes: hO,
                faceIndex: DO,
                layerIndex: MO,
                layerCounts: aK,
                label: this.label
              },
              VO = {
                width: this.width,
                height: this.height,
                depth: this.depth
              };
            OO = this._engine.createMultipleRenderTarget(VO, FO);
            for (let LO = 0; LO < XO; ++LO) {
              if (-1 !== hO[LO]) continue;
              const pO = oO[KO[LO].uniqueId];
              OO.setTexture(OO.textures[pO], LO)
            }
          }
        } else {
          const KO = {};
          if (KO.generateDepthBuffer = this._generateDepthBuffer, KO.generateMipMaps = this.texture?.generateMipMaps ?? !1, KO.generateStencilBuffer = this._generateStencilBuffer, KO.samplingMode = this.texture?.samplingMode, KO.type = this.texture?.type, KO.format = this.texture?.format, KO.noColorAttachment = !this._textures, KO.label = this.label, this.isCube) OO = this._engine.createRenderTargetCubeTexture(this.width, KO);
          else {
            const pO = {
              width: this.width,
              height: this.height,
              layers: this.is2DArray || this.is3D ? this.texture?.depth : void 0
            };
            OO = this._engine.createRenderTargetTexture(pO, KO)
          }
          OO.texture && (OO.texture.isReady = !0)
        }
        return OO
      }
      _swapRenderTargetWrapper(OO) {
        if (this._textures && OO._textures)
          for (let KO = 0; KO < this._textures.length; ++KO) this._textures[KO]._swapAndDie(OO._textures[KO], !1), OO._textures[KO].isReady = !0;
        this._depthStencilTexture && OO._depthStencilTexture && (this._depthStencilTexture._swapAndDie(OO._depthStencilTexture), OO._depthStencilTexture.isReady = !0), this._textures = null, this._depthStencilTexture = null
      }
      _rebuild() {
        const OO = this._cloneRenderTargetWrapper();
        if (OO) {
          if (this._depthStencilTexture) {
            const KO = this._depthStencilTexture.samplingMode,
              pO = this._depthStencilTexture.format,
              XO = 2 === KO || 3 === KO || 11 === KO;
            OO.createDepthStencilTexture(this._depthStencilTexture._comparisonFunction, XO, this._depthStencilTextureWithStencil, this._depthStencilTexture.samples, pO, this._depthStencilTextureLabel)
          }
          this.samples > 1 && OO.setSamples(this.samples), OO._swapRenderTargetWrapper(this), OO.dispose()
        }
      }
      releaseTextures() {
        if (this._textures)
          for (let OO = 0; OO < this._textures.length; ++OO) this._textures[OO].dispose();
        this._textures = null
      }
      dispose() {
        arguments.length > 0 && void 0 !== arguments[0] && arguments[0] || (this._depthStencilTexture?.dispose(), this._depthStencilTexture = null, this.releaseTextures()), this._engine._releaseRenderTargetWrapper(this)
      }
    }
  },
  38521: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    class XO {
      static get ForceFullSceneLoadingForIncremental() {
        return XO._ForceFullSceneLoadingForIncremental
      }
      static set ForceFullSceneLoadingForIncremental(OO) {
        XO._ForceFullSceneLoadingForIncremental = OO
      }
      static get ShowLoadingScreen() {
        return XO._ShowLoadingScreen
      }
      static set ShowLoadingScreen(OO) {
        XO._ShowLoadingScreen = OO
      }
      static get loggingLevel() {
        return XO._LoggingLevel
      }
      static set loggingLevel(OO) {
        XO._LoggingLevel = OO
      }
      static get CleanBoneMatrixWeights() {
        return XO._CleanBoneMatrixWeights
      }
      static set CleanBoneMatrixWeights(OO) {
        XO._CleanBoneMatrixWeights = OO
      }
    }
    XO._ForceFullSceneLoadingForIncremental = !1, XO._ShowLoadingScreen = !0, XO._CleanBoneMatrixWeights = !1, XO._LoggingLevel = 0
  },
  38157: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(37061);
    const bK = new Map;

    function eO(OO, KO) {
      (function(OO) {
        return bK.delete(OO)
      })(OO) && XO.b.Warn(`Extension with the name '${OO}' already exists`), bK.set(OO, KO)
    }

    function lO(OO, KO) {
      "image/ktx" !== KO && "image/ktx2" !== KO || (OO = ".ktx"), bK.has(OO) || (OO.endsWith(".ies") && eO(".ies", (async () => await pO.e(289).then((() => pO(39787))).then((OO => new OO._IESTextureLoader)))), OO.endsWith(".dds") && eO(".dds", (async () => await pO.e(287).then((() => pO(39795))).then((OO => new OO._DDSTextureLoader)))), OO.endsWith(".basis") && eO(".basis", (async () => await pO.e(290).then((() => pO(39801))).then((OO => new OO._BasisTextureLoader)))), OO.endsWith(".env") && eO(".env", (async () => await Promise.all([pO.e(291), pO.e(288)]).then((() => pO(39803))).then((OO => new OO._ENVTextureLoader)))), OO.endsWith(".hdr") && eO(".hdr", (async () => await pO.e(292).then((() => pO(39851))).then((OO => new OO._HDRTextureLoader)))), (OO.endsWith(".ktx") || OO.endsWith(".ktx2")) && (eO(".ktx", (async () => await pO.e(293).then((() => pO(39859))).then((OO => new OO._KTXTextureLoader)))), eO(".ktx2", (async () => await pO.e(293).then((() => pO(39859))).then((OO => new OO._KTXTextureLoader))))), OO.endsWith(".tga") && eO(".tga", (async () => await pO.e(294).then((() => pO(39865))).then((OO => new OO._TGATextureLoader)))), OO.endsWith(".exr") && eO(".exr", (async () => await pO.e(295).then((() => pO(39873))).then((OO => new OO._ExrTextureLoader)))));
      const XO = bK.get(OO);
      return XO ? Promise.resolve(XO(KO)) : null
    }
  },
  38552: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      f: () => hO
    });
    var XO = pO(38382),
      bK = pO(38085),
      eO = pO(35676);
    class lO extends XO.b {
      get jvO() {
        return this._subMaterials
      }
      set jvO(OO) {
        this._subMaterials = OO, this._hookArray(OO)
      }
      getChildren() {
        return this.jvO
      }
      constructor(OO, KO) {
        super(OO, KO, !0), this._waitingSubMaterialsUniqueIds = [], this.JKO().addMultiMaterial(this), this.jvO = [], this._storeEffectOnSubMeshes = !0
      }
      _hookArray(OO) {
        var KO = this;
        const pO = OO.push;
        OO.push = function() {
          for (var XO = arguments.length, bK = new Array(XO), eO = 0; eO < XO; eO++) bK[eO] = arguments[eO];
          const lO = pO.apply(OO, bK);
          return KO._markAllSubMeshesAsTexturesDirty(), lO
        };
        const XO = OO.splice;
        OO.splice = (KO, pO) => {
          const bK = XO.call(OO, KO, pO ?? OO.length);
          return this._markAllSubMeshesAsTexturesDirty(), bK
        }
      }
      getSubMaterial(OO) {
        return OO < 0 || OO >= this.jvO.length ? this.JKO().defaultMaterial : this.jvO[OO]
      }
      getActiveTextures() {
        return super.getActiveTextures().concat(...this.jvO.map((OO => OO ? OO.getActiveTextures() : [])))
      }
      hasTexture(OO) {
        if (super.hasTexture(OO)) return !0;
        for (let KO = 0; KO < this.jvO.length; KO++)
          if (this.jvO[KO]?.hasTexture(OO)) return !0;
        return !1
      }
      getClassName() {
        return "MultiMaterial"
      }
      isReadyForSubMesh(OO, KO, pO) {
        for (let XO = 0; XO < this.jvO.length; XO++) {
          const bK = this.jvO[XO];
          if (bK) {
            if (bK._storeEffectOnSubMeshes) {
              if (!bK.isReadyForSubMesh(OO, KO, pO)) return !1;
              continue
            }
            if (!bK.isReady(OO)) return !1
          }
        }
        return !0
      }
      clone(OO, KO) {
        const pO = new lO(OO, this.JKO());
        for (let XO = 0; XO < this.jvO.length; XO++) {
          let bK;
          const eO = this.jvO[XO];
          bK = KO && eO ? eO.clone(OO + "-" + eO.name) : this.jvO[XO], pO.jvO.push(bK)
        }
        return pO
      }
      serialize() {
        const OO = {};
        OO.name = this.name, OO.id = this.id, OO.uniqueId = this.uniqueId, bK.b && (OO.tags = bK.b.GetTags(this)), OO.materialsUniqueIds = [], OO.materials = [];
        for (let KO = 0; KO < this.jvO.length; KO++) {
          const pO = this.jvO[KO];
          pO ? (OO.materialsUniqueIds.push(pO.uniqueId), OO.materials.push(pO.id)) : (OO.materialsUniqueIds.push(null), OO.materials.push(null))
        }
        return OO
      }
      dispose(OO, KO, pO) {
        const XO = this.JKO();
        if (!XO) return;
        if (pO)
          for (let eO = 0; eO < this.jvO.length; eO++) {
            const pO = this.jvO[eO];
            pO && pO.dispose(OO, KO)
          }
        const bK = XO.multiMaterials.indexOf(this);
        bK >= 0 && XO.multiMaterials.splice(bK, 1), super.dispose(OO, KO)
      }
    }
    let vK = !1;

    function CO(OO, KO) {
      const pO = new lO(OO.name, KO);
      if (pO.id = OO.id, pO._loadedUniqueId = OO.uniqueId, bK.b && bK.b.AddTagsTo(pO, OO.tags), OO.materialsUniqueIds) pO._waitingSubMaterialsUniqueIds = OO.materialsUniqueIds;
      else
        for (const XO of OO.materials) pO.jvO.push(KO.getLastMaterialById(XO));
      return pO
    }

    function hO() {
      vK || (vK = !0, lO.ParseMultiMaterial = CO, (0, eO.h)("BABYLON.MultiMaterial", lO))
    }
  },
  38310: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO
    });
    var XO, bK, eO = pO(35632);
    ! function(OO) {
      OO[OO.LOCAL = 0] = "LOCAL", OO[OO.WORLD = 1] = "WORLD", OO[OO.BONE = 2] = "BONE"
    }(XO || (XO = {}));
    class lO {}
    lO.X = new eO.o(1, 0, 0), lO.Y = new eO.o(0, 1, 0), lO.Z = new eO.o(0, 0, 1),
      function(OO) {
        OO[OO.X = 0] = "X", OO[OO.Y = 1] = "Y", OO[OO.Z = 2] = "Z"
      }(bK || (bK = {}))
  },
  38048: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => CO,
      f: () => hO
    });
    var XO = pO(35632);
    const bK = [Math.sqrt(1 / (4 * Math.PI)), -Math.sqrt(3 / (4 * Math.PI)), Math.sqrt(3 / (4 * Math.PI)), -Math.sqrt(3 / (4 * Math.PI)), Math.sqrt(15 / (4 * Math.PI)), -Math.sqrt(15 / (4 * Math.PI)), Math.sqrt(5 / (16 * Math.PI)), -Math.sqrt(15 / (4 * Math.PI)), Math.sqrt(15 / (16 * Math.PI))],
      eO = [() => 1, OO => OO.y, OO => OO.z, OO => OO.x, OO => OO.x * OO.y, OO => OO.y * OO.z, OO => 3 * OO.z * OO.z - 1, OO => OO.x * OO.z, OO => OO.x * OO.x - OO.y * OO.y],
      lO = (OO, KO) => bK[OO] * eO[OO](KO),
      vK = [Math.PI, 2 * Math.PI / 3, 2 * Math.PI / 3, 2 * Math.PI / 3, Math.PI / 4, Math.PI / 4, Math.PI / 4, Math.PI / 4, Math.PI / 4];
    class CO {
      constructor() {
        this.preScaled = !1, this.l00 = XO.o.Zero(), this.l1_1 = XO.o.Zero(), this.l10 = XO.o.Zero(), this.l11 = XO.o.Zero(), this.l2_2 = XO.o.Zero(), this.l2_1 = XO.o.Zero(), this.l20 = XO.o.Zero(), this.l21 = XO.o.Zero(), this.l22 = XO.o.Zero()
      }
      addLight(OO, KO, pO) {
        XO.j.WX[0].set(KO.r, KO.g, KO.b);
        const bK = XO.j.WX[0],
          eO = XO.j.WX[1];
        bK.scaleToRef(pO, eO), eO.scaleToRef(lO(0, OO), XO.j.WX[2]), this.l00.addInPlace(XO.j.WX[2]), eO.scaleToRef(lO(1, OO), XO.j.WX[2]), this.l1_1.addInPlace(XO.j.WX[2]), eO.scaleToRef(lO(2, OO), XO.j.WX[2]), this.l10.addInPlace(XO.j.WX[2]), eO.scaleToRef(lO(3, OO), XO.j.WX[2]), this.l11.addInPlace(XO.j.WX[2]), eO.scaleToRef(lO(4, OO), XO.j.WX[2]), this.l2_2.addInPlace(XO.j.WX[2]), eO.scaleToRef(lO(5, OO), XO.j.WX[2]), this.l2_1.addInPlace(XO.j.WX[2]), eO.scaleToRef(lO(6, OO), XO.j.WX[2]), this.l20.addInPlace(XO.j.WX[2]), eO.scaleToRef(lO(7, OO), XO.j.WX[2]), this.l21.addInPlace(XO.j.WX[2]), eO.scaleToRef(lO(8, OO), XO.j.WX[2]), this.l22.addInPlace(XO.j.WX[2])
      }
      scaleInPlace(OO) {
        this.l00.scaleInPlace(OO), this.l1_1.scaleInPlace(OO), this.l10.scaleInPlace(OO), this.l11.scaleInPlace(OO), this.l2_2.scaleInPlace(OO), this.l2_1.scaleInPlace(OO), this.l20.scaleInPlace(OO), this.l21.scaleInPlace(OO), this.l22.scaleInPlace(OO)
      }
      convertIncidentRadianceToIrradiance() {
        this.l00.scaleInPlace(vK[0]), this.l1_1.scaleInPlace(vK[1]), this.l10.scaleInPlace(vK[2]), this.l11.scaleInPlace(vK[3]), this.l2_2.scaleInPlace(vK[4]), this.l2_1.scaleInPlace(vK[5]), this.l20.scaleInPlace(vK[6]), this.l21.scaleInPlace(vK[7]), this.l22.scaleInPlace(vK[8])
      }
      convertIrradianceToLambertianRadiance() {
        this.scaleInPlace(1 / Math.PI)
      }
      preScaleForRendering() {
        this.preScaled = !0, this.l00.scaleInPlace(bK[0]), this.l1_1.scaleInPlace(bK[1]), this.l10.scaleInPlace(bK[2]), this.l11.scaleInPlace(bK[3]), this.l2_2.scaleInPlace(bK[4]), this.l2_1.scaleInPlace(bK[5]), this.l20.scaleInPlace(bK[6]), this.l21.scaleInPlace(bK[7]), this.l22.scaleInPlace(bK[8])
      }
      updateFromArray(OO) {
        return XO.o.FromArrayToRef(OO[0], 0, this.l00), XO.o.FromArrayToRef(OO[1], 0, this.l1_1), XO.o.FromArrayToRef(OO[2], 0, this.l10), XO.o.FromArrayToRef(OO[3], 0, this.l11), XO.o.FromArrayToRef(OO[4], 0, this.l2_2), XO.o.FromArrayToRef(OO[5], 0, this.l2_1), XO.o.FromArrayToRef(OO[6], 0, this.l20), XO.o.FromArrayToRef(OO[7], 0, this.l21), XO.o.FromArrayToRef(OO[8], 0, this.l22), this
      }
      updateFromFloatsArray(OO) {
        return XO.o.FromFloatsToRef(OO[0], OO[1], OO[2], this.l00), XO.o.FromFloatsToRef(OO[3], OO[4], OO[5], this.l1_1), XO.o.FromFloatsToRef(OO[6], OO[7], OO[8], this.l10), XO.o.FromFloatsToRef(OO[9], OO[10], OO[11], this.l11), XO.o.FromFloatsToRef(OO[12], OO[13], OO[14], this.l2_2), XO.o.FromFloatsToRef(OO[15], OO[16], OO[17], this.l2_1), XO.o.FromFloatsToRef(OO[18], OO[19], OO[20], this.l20), XO.o.FromFloatsToRef(OO[21], OO[22], OO[23], this.l21), XO.o.FromFloatsToRef(OO[24], OO[25], OO[26], this.l22), this
      }
      static FromArray(OO) {
        return (new CO).updateFromArray(OO)
      }
      static FromPolynomial(OO) {
        const KO = new CO;
        return KO.l00 = OO.xx.scale(.376127).add(OO.yy.scale(.376127)).add(OO.zz.scale(.376126)), KO.l1_1 = OO.y.scale(.977204), KO.l10 = OO.z.scale(.977204), KO.l11 = OO.x.scale(.977204), KO.l2_2 = OO.xy.scale(1.16538), KO.l2_1 = OO.yz.scale(1.16538), KO.l20 = OO.zz.scale(1.34567).subtract(OO.xx.scale(.672834)).subtract(OO.yy.scale(.672834)), KO.l21 = OO.zx.scale(1.16538), KO.l22 = OO.xx.scale(1.16538).subtract(OO.yy.scale(1.16538)), KO.l1_1.scaleInPlace(-1), KO.l11.scaleInPlace(-1), KO.l2_1.scaleInPlace(-1), KO.l21.scaleInPlace(-1), KO.scaleInPlace(Math.PI), KO
      }
    }
    class hO {
      constructor() {
        this.x = XO.o.Zero(), this.y = XO.o.Zero(), this.z = XO.o.Zero(), this.xx = XO.o.Zero(), this.yy = XO.o.Zero(), this.zz = XO.o.Zero(), this.xy = XO.o.Zero(), this.yz = XO.o.Zero(), this.zx = XO.o.Zero()
      }
      get preScaledHarmonics() {
        return this._harmonics || (this._harmonics = CO.FromPolynomial(this)), this._harmonics.preScaled || this._harmonics.preScaleForRendering(), this._harmonics
      }
      addAmbient(OO) {
        XO.j.WX[0].rvO(OO.r, OO.g, OO.b);
        const KO = XO.j.WX[0];
        this.xx.addInPlace(KO), this.yy.addInPlace(KO), this.zz.addInPlace(KO)
      }
      scaleInPlace(OO) {
        this.x.scaleInPlace(OO), this.y.scaleInPlace(OO), this.z.scaleInPlace(OO), this.xx.scaleInPlace(OO), this.yy.scaleInPlace(OO), this.zz.scaleInPlace(OO), this.yz.scaleInPlace(OO), this.zx.scaleInPlace(OO), this.xy.scaleInPlace(OO)
      }
      updateFromHarmonics(OO) {
        return this._harmonics = OO, this.x.NhO(OO.l11), this.x.scaleInPlace(1.02333).scaleInPlace(-1), this.y.NhO(OO.l1_1), this.y.scaleInPlace(1.02333).scaleInPlace(-1), this.z.NhO(OO.l10), this.z.scaleInPlace(1.02333), this.xx.NhO(OO.l00), XO.j.WX[0].NhO(OO.l20).scaleInPlace(.247708), XO.j.WX[1].NhO(OO.l22).scaleInPlace(.429043), this.xx.scaleInPlace(.886277).oDO(XO.j.WX[0]).addInPlace(XO.j.WX[1]), this.yy.NhO(OO.l00), this.yy.scaleInPlace(.886277).oDO(XO.j.WX[0]).oDO(XO.j.WX[1]), this.zz.NhO(OO.l00), XO.j.WX[0].NhO(OO.l20).scaleInPlace(.495417), this.zz.scaleInPlace(.886277).addInPlace(XO.j.WX[0]), this.yz.NhO(OO.l2_1), this.yz.scaleInPlace(.858086).scaleInPlace(-1), this.zx.NhO(OO.l21), this.zx.scaleInPlace(.858086).scaleInPlace(-1), this.xy.NhO(OO.l2_2), this.xy.scaleInPlace(.858086), this.scaleInPlace(1 / Math.PI), this
      }
      static FromHarmonics(OO) {
        return (new hO).updateFromHarmonics(OO)
      }
      static FromArray(OO) {
        const KO = new hO;
        return XO.o.FromArrayToRef(OO[0], 0, KO.x), XO.o.FromArrayToRef(OO[1], 0, KO.y), XO.o.FromArrayToRef(OO[2], 0, KO.z), XO.o.FromArrayToRef(OO[3], 0, KO.xx), XO.o.FromArrayToRef(OO[4], 0, KO.yy), XO.o.FromArrayToRef(OO[5], 0, KO.zz), XO.o.FromArrayToRef(OO[6], 0, KO.yz), XO.o.FromArrayToRef(OO[7], 0, KO.zx), XO.o.FromArrayToRef(OO[8], 0, KO.xy), KO
      }
    }
  },
  38537: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => wO,
      f: () => rK
    });
    var XO = pO(38063),
      bK = pO(35660),
      eO = pO(35632),
      lO = pO(38216),
      vK = pO(38511),
      CO = pO(38544),
      hO = pO(38209),
      DO = pO(38400),
      MO = pO(38206);
    class aK {
      constructor() {
        this._checkCollisions = !1, this._collisionMask = -1, this._collisionGroup = -1, this._surroundingMeshes = null, this._collider = null, this._oldPositionForCollisions = new eO.o(0, 0, 0), this._diffPositionForCollisions = new eO.o(0, 0, 0), this._collisionResponse = !0
      }
    }
    var oO, FO, VO, LO = pO(37938),
      QO = pO(38140),
      zK = pO(38413),
      AO = pO(35688),
      fO = pO(35639),
      dO = pO(38310),
      TO = pO(37061),
      NO = pO(38066),
      IO = pO(37962),
      yK = pO(35676);

    function gK(OO, KO) {
      return OO - Math.floor(OO / KO) * KO
    }

    function uO(OO, KO, pO) {
      OO instanceof Float32Array ? eO.c.FromArrayToRef(OO, KO, pO) : pO.rvO((0, QO.d)(OO[KO]), (0, QO.d)(OO[KO + 1]), (0, QO.d)(OO[KO + 2]), (0, QO.d)(OO[KO + 3]), (0, QO.d)(OO[KO + 4]), (0, QO.d)(OO[KO + 5]), (0, QO.d)(OO[KO + 6]), (0, QO.d)(OO[KO + 7]), (0, QO.d)(OO[KO + 8]), (0, QO.d)(OO[KO + 9]), (0, QO.d)(OO[KO + 10]), (0, QO.d)(OO[KO + 11]), (0, QO.d)(OO[KO + 12]), (0, QO.d)(OO[KO + 13]), (0, QO.d)(OO[KO + 14]), (0, QO.d)(OO[KO + 15]))
    }

    function EO(OO, KO, pO, XO, bK, vK, CO, hO, DO) {
      const MO = pO.texture,
        aK = MO?.getInternalTexture(),
        oO = aK?._bufferView;
      if (!(oO instanceof Float32Array) && !(oO instanceof Uint16Array)) return TO.b.Warn("Baked vertex animation bounding info requires CPU-readable Float32Array or Uint16Array texture data.", 1), !1;
      const FO = MO.getSize(),
        VO = function(OO, KO) {
          const pO = OO.y - OO.x + 1,
            XO = KO * OO.w / pO,
            bK = XO < 1 ? 0 : 1,
            eO = pO - bK;
          let lO = gK(XO - Math.floor(XO), 1) * eO;
          return lO = gK(lO + OO.z, eO), Math.floor(lO) + OO.x + bK
        }(XO, pO.time);
      if (!isFinite(VO) || VO < 0 || VO >= FO.height) return TO.b.Warn("Baked vertex animation bounding info could not be refreshed because the computed frame is outside the texture.", 1), !1;
      const LO = eO.j.WX[0],
        QO = eO.j.Matrix[0],
        zK = eO.j.Matrix[1],
        AO = VO * FO.width * 4,
        fO = KO === lO.j.NormalKind ? eO.o.TransformNormalFromFloatsToRef : eO.o.TransformCoordinatesFromFloatsToRef;
      for (let eO = 0, lO = 0; eO < OO.length; eO += 3, lO += 4) {
        let KO, pO;
        for (QO.reset(), KO = 0; KO < 4 && KO < DO; KO++) pO = vK[lO + KO], pO > 0 && (uO(oO, AO + 16 * Math.floor(bK[lO + KO]), zK), zK.scaleAndAddToRef(pO, QO));
        if (CO && hO)
          for (KO = 0; KO < 4 && KO + 4 < DO; KO++) pO = hO[lO + KO], pO > 0 && (uO(oO, AO + 16 * Math.floor(CO[lO + KO]), zK), zK.scaleAndAddToRef(pO, QO));
        fO(OO[eO], OO[eO + 1], OO[eO + 2], QO, LO), LO.toArray(OO, eO)
      }
      return !0
    }
    class jK {
      constructor() {
        this.facetNb = 0, this.partitioningSubdivisions = 10, this.partitioningBBoxRatio = 1.01, this.facetDataEnabled = !1, this.facetParameters = {}, this.bbSize = eO.o.Zero(), this.subDiv = {
          max: 1,
          X: 1,
          Y: 1,
          Z: 1
        }, this.facetDepthSort = !1, this.facetDepthSortEnabled = !1
      }
    }
    class YO {
      constructor() {
        this._hasVertexAlpha = !1, this._useVertexColors = !0, this._numBoneInfluencers = 4, this._applyFog = !0, this._receiveShadows = !1, this._facetData = new jK, this._visibility = 1, this._skeleton = null, this._layerMask = 268435455, this._computeBonesUsingShaders = !0, this._isActive = !1, this._onlyForInstances = !1, this._isActiveIntermediate = !1, this._onlyForInstancesIntermediate = !1, this._actAsRegularMesh = !1, this._currentLOD = new Map, this._collisionRetryCount = 3, this._morphTargetManager = null, this._renderingGroupId = 0, this._meshBlendingTag = 0, this._bakedVertexAnimationManager = null, this._material = null, this._positions = null, this._pointerOverDisableMeshTesting = !1, this._meshCollisionData = new aK, this._enableDistantPicking = !1, this._rawBoundingInfo = null, this._sideOrientationHint = !1, this._wasActiveLastFrame = !1
      }
    }
    let wO = (() => {
        var OO;
        let KO, aK = CO.i,
          oO = [];
        return OO = class extends aK {
          static get BILLBOARDMODE_NONE() {
            return CO.i.BILLBOARDMODE_NONE
          }
          static get BILLBOARDMODE_X() {
            return CO.i.BILLBOARDMODE_X
          }
          static get BILLBOARDMODE_Y() {
            return CO.i.BILLBOARDMODE_Y
          }
          static get BILLBOARDMODE_Z() {
            return CO.i.BILLBOARDMODE_Z
          }
          static get BILLBOARDMODE_ALL() {
            return CO.i.BILLBOARDMODE_ALL
          }
          static get BILLBOARDMODE_USE_POSITION() {
            return CO.i.BILLBOARDMODE_USE_POSITION
          }
          get facetNb() {
            return this._internalAbstractMeshDataInfo._facetData.facetNb
          }
          get partitioningSubdivisions() {
            return this._internalAbstractMeshDataInfo._facetData.partitioningSubdivisions
          }
          set partitioningSubdivisions(OO) {
            this._internalAbstractMeshDataInfo._facetData.partitioningSubdivisions = OO
          }
          get partitioningBBoxRatio() {
            return this._internalAbstractMeshDataInfo._facetData.partitioningBBoxRatio
          }
          set partitioningBBoxRatio(OO) {
            this._internalAbstractMeshDataInfo._facetData.partitioningBBoxRatio = OO
          }
          get mustDepthSortFacets() {
            return this._internalAbstractMeshDataInfo._facetData.facetDepthSort
          }
          set mustDepthSortFacets(OO) {
            this._internalAbstractMeshDataInfo._facetData.facetDepthSort = OO
          }
          get facetDepthSortFrom() {
            return this._internalAbstractMeshDataInfo._facetData.facetDepthSortFrom
          }
          set facetDepthSortFrom(OO) {
            this._internalAbstractMeshDataInfo._facetData.facetDepthSortFrom = OO
          }
          get collisionRetryCount() {
            return this._internalAbstractMeshDataInfo._collisionRetryCount
          }
          set collisionRetryCount(OO) {
            this._internalAbstractMeshDataInfo._collisionRetryCount = OO
          }
          get isFacetDataEnabled() {
            return this._internalAbstractMeshDataInfo._facetData.facetDataEnabled
          }
          get morphTargetManager() {
            return this._internalAbstractMeshDataInfo._morphTargetManager
          }
          set morphTargetManager(OO) {
            this._internalAbstractMeshDataInfo._morphTargetManager !== OO && (this._internalAbstractMeshDataInfo._morphTargetManager = OO, this._syncGeometryWithMorphTargetManager())
          }
          get bakedVertexAnimationManager() {
            return this._internalAbstractMeshDataInfo._bakedVertexAnimationManager
          }
          set bakedVertexAnimationManager(OO) {
            this._internalAbstractMeshDataInfo._bakedVertexAnimationManager !== OO && (this._internalAbstractMeshDataInfo._bakedVertexAnimationManager = OO, this._markSubMeshesAsAttributesDirty())
          }
          _syncGeometryWithMorphTargetManager() {}
          _updateNonUniformScalingState(OO) {
            return !!super._updateNonUniformScalingState(OO) && (this._markSubMeshesAsMiscDirty(), !0)
          }
          get rawBoundingInfo() {
            return this._internalAbstractMeshDataInfo._rawBoundingInfo
          }
          set rawBoundingInfo(OO) {
            this._internalAbstractMeshDataInfo._rawBoundingInfo = OO
          }
          set QK(OO) {
            this._internalAbstractMeshDataInfo._meshCollisionData._onCollideObserver && this.onCollideObservable.remove(this._internalAbstractMeshDataInfo._meshCollisionData._onCollideObserver), this._internalAbstractMeshDataInfo._meshCollisionData._onCollideObserver = this.onCollideObservable.add(OO)
          }
          set onCollisionPositionChange(OO) {
            this._internalAbstractMeshDataInfo._meshCollisionData._onCollisionPositionChangeObserver && this.onCollisionPositionChangeObservable.remove(this._internalAbstractMeshDataInfo._meshCollisionData._onCollisionPositionChangeObserver), this._internalAbstractMeshDataInfo._meshCollisionData._onCollisionPositionChangeObserver = this.onCollisionPositionChangeObservable.add(OO)
          }
          get visibility() {
            return this._internalAbstractMeshDataInfo._visibility
          }
          set visibility(OO) {
            if (this._internalAbstractMeshDataInfo._visibility === OO) return;
            const KO = this._internalAbstractMeshDataInfo._visibility;
            this._internalAbstractMeshDataInfo._visibility = OO, (1 === KO && 1 !== OO || 1 !== KO && 1 === OO) && this._markSubMeshesAsDirty((OO => {
              OO.markAsMiscDirty(), OO.markAsPrePassDirty()
            }))
          }
          get pointerOverDisableMeshTesting() {
            return this._internalAbstractMeshDataInfo._pointerOverDisableMeshTesting
          }
          set pointerOverDisableMeshTesting(OO) {
            this._internalAbstractMeshDataInfo._pointerOverDisableMeshTesting = OO
          }
          get renderingGroupId() {
            return this._internalAbstractMeshDataInfo._renderingGroupId
          }
          set renderingGroupId(OO) {
            this._internalAbstractMeshDataInfo._renderingGroupId = OO
          }
          get meshBlendingTag() {
            return this._internalAbstractMeshDataInfo._meshBlendingTag
          }
          set meshBlendingTag(OO) {
            if (!Number.isInteger(OO) || OO < 0 || OO > 255 || 0 !== OO && 0 === (63 & OO)) throw new RangeError("Mesh-blending tag must be 0 or contain a group ID between 1 and 63.");
            this._internalAbstractMeshDataInfo._meshBlendingTag = OO
          }
          get material() {
            return this._internalAbstractMeshDataInfo._material
          }
          set material(OO) {
            this._setMaterial(OO)
          }
          _setMaterial(OO) {
            this._internalAbstractMeshDataInfo._material !== OO && (this._internalAbstractMeshDataInfo._material && this._internalAbstractMeshDataInfo._material.meshMap && (this._internalAbstractMeshDataInfo._material.meshMap[this.uniqueId] = void 0), this._internalAbstractMeshDataInfo._material = OO, OO && OO.meshMap && (OO.meshMap[this.uniqueId] = this), this.onMaterialChangedObservable.hasObservers() && this.onMaterialChangedObservable.notifyObservers(this), this.au && (this.resetDrawCache(void 0, null == OO), this._unBindEffect()))
          }
          getMaterialForRenderPass(OO) {
            return this._internalAbstractMeshDataInfo._materialForRenderPass?.[OO]
          }
          setMaterialForRenderPass(OO, KO) {
            this.resetDrawCache(OO), this._internalAbstractMeshDataInfo._materialForRenderPass || (this._internalAbstractMeshDataInfo._materialForRenderPass = []);
            const pO = this._internalAbstractMeshDataInfo._materialForRenderPass[OO];
            pO?.meshMap?.[this.uniqueId] && (pO.meshMap[this.uniqueId] = void 0), this._internalAbstractMeshDataInfo._materialForRenderPass[OO] = KO, KO && KO.meshMap && (KO.meshMap[this.uniqueId] = this)
          }
          get receiveShadows() {
            return this._internalAbstractMeshDataInfo._receiveShadows
          }
          set receiveShadows(OO) {
            this._internalAbstractMeshDataInfo._receiveShadows !== OO && (this._internalAbstractMeshDataInfo._receiveShadows = OO, this._markSubMeshesAsLightDirty())
          }
          get hasVertexAlpha() {
            return this._internalAbstractMeshDataInfo._hasVertexAlpha
          }
          set hasVertexAlpha(OO) {
            this._internalAbstractMeshDataInfo._hasVertexAlpha !== OO && (this._internalAbstractMeshDataInfo._hasVertexAlpha = OO, this._markSubMeshesAsAttributesDirty(), this._markSubMeshesAsMiscDirty())
          }
          get useVertexColors() {
            return this._internalAbstractMeshDataInfo._useVertexColors
          }
          set useVertexColors(OO) {
            this._internalAbstractMeshDataInfo._useVertexColors !== OO && (this._internalAbstractMeshDataInfo._useVertexColors = OO, this._markSubMeshesAsAttributesDirty())
          }
          get computeBonesUsingShaders() {
            return this._internalAbstractMeshDataInfo._computeBonesUsingShaders
          }
          set computeBonesUsingShaders(OO) {
            this._internalAbstractMeshDataInfo._computeBonesUsingShaders !== OO && (this._internalAbstractMeshDataInfo._computeBonesUsingShaders = OO, this._markSubMeshesAsAttributesDirty())
          }
          get numBoneInfluencers() {
            return this._internalAbstractMeshDataInfo._numBoneInfluencers
          }
          set numBoneInfluencers(OO) {
            this._internalAbstractMeshDataInfo._numBoneInfluencers !== OO && (this._internalAbstractMeshDataInfo._numBoneInfluencers = OO, this._markSubMeshesAsAttributesDirty())
          }
          get applyFog() {
            return this._internalAbstractMeshDataInfo._applyFog
          }
          set applyFog(OO) {
            this._internalAbstractMeshDataInfo._applyFog !== OO && (this._internalAbstractMeshDataInfo._applyFog = OO, this._markSubMeshesAsMiscDirty())
          }
          get enableDistantPicking() {
            return this._internalAbstractMeshDataInfo._enableDistantPicking
          }
          set enableDistantPicking(OO) {
            this._internalAbstractMeshDataInfo._enableDistantPicking = OO
          }
          get layerMask() {
            return this._internalAbstractMeshDataInfo._layerMask
          }
          set layerMask(OO) {
            OO !== this._internalAbstractMeshDataInfo._layerMask && (this._internalAbstractMeshDataInfo._layerMask = OO, this._resyncLightSources())
          }
          get collisionMask() {
            return this._internalAbstractMeshDataInfo._meshCollisionData._collisionMask
          }
          set collisionMask(OO) {
            this._internalAbstractMeshDataInfo._meshCollisionData._collisionMask = isNaN(OO) ? -1 : OO
          }
          get collisionResponse() {
            return this._internalAbstractMeshDataInfo._meshCollisionData._collisionResponse
          }
          set collisionResponse(OO) {
            this._internalAbstractMeshDataInfo._meshCollisionData._collisionResponse = OO
          }
          get collisionGroup() {
            return this._internalAbstractMeshDataInfo._meshCollisionData._collisionGroup
          }
          set collisionGroup(OO) {
            this._internalAbstractMeshDataInfo._meshCollisionData._collisionGroup = isNaN(OO) ? -1 : OO
          }
          get surroundingMeshes() {
            return this._internalAbstractMeshDataInfo._meshCollisionData._surroundingMeshes
          }
          set surroundingMeshes(OO) {
            this._internalAbstractMeshDataInfo._meshCollisionData._surroundingMeshes = OO
          }
          get lightSources() {
            return this._lightSources
          }
          set skeleton(OO) {
            const KO = this._internalAbstractMeshDataInfo._skeleton;
            KO && KO.needInitialSkinMatrix && KO._unregisterMeshWithPoseMatrix(this), OO && OO.needInitialSkinMatrix && OO._registerMeshWithPoseMatrix(this), this._internalAbstractMeshDataInfo._skeleton = OO, this._internalAbstractMeshDataInfo._skeleton || (this._bonesTransformMatrices = null), this._markSubMeshesAsAttributesDirty()
          }
          get skeleton() {
            return this._internalAbstractMeshDataInfo._skeleton
          }
          constructor(KO) {
            var pO;
            let XO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
            switch (super(KO, XO, !1), pO = this, this._internalAbstractMeshDataInfo = new YO, this._waitingMaterialId = null, this._waitingMorphTargetManagerId = null, this._waitingSkeletonId = null, this._waitingSkeletonUniqueId = null, this.cullingStrategy = OO.CULLINGSTRATEGY_BOUNDINGSPHERE_ONLY, this.onCollideObservable = new bK.e, this.onCollisionPositionChangeObservable = new bK.e, this.onMaterialChangedObservable = new bK.e, this.definedFacingForward = !0, this._occlusionQuery = null, this._renderingGroup = null, this.alphaIndex = Number.MAX_VALUE, this.De = OO.DefaultIsPickable, this.isNearPickable = !1, this.isNearGrabbable = !1, this.showSubMeshesBoundingBox = !1, this.isBlocker = !1, this.enablePointerMoveEvents = !1, this.outlineColor = AO.e.Red(), this.outlineWidth = .02, this.overlayColor = AO.e.Red(), this.overlayAlpha = .5, this.useOctreeForRenderingSelection = !0, this.useOctreeForPicking = !0, this.useOctreeForCollisions = !0, this.xb = !1, this.kb = !1, this.actionManager = null, this.ellipsoid = new eO.o(.5, 1, .5), this.ellipsoidOffset = new eO.o(0, 0, 0), this.edgesWidth = 1, this.edgesColor = new AO.g(1, 0, 0, 1), this._edgesRenderer = null, this._masterMesh = null, this._boundingInfo = null, this._boundingInfoIsDirty = !0, this._renderId = 0, this._intersectionsInProgress = new Array, this._unIndexed = !1, this._lightSources = new Array, this._waitingData = {
                lods: null,
                actions: null,
                qpO: null
              }, this._bonesTransformMatrices = null, this._transformMatrixTexture = null, this.onRebuildObservable = new bK.e, this._onCollisionPositionChange = function(OO, KO) {
                let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
                KO.subtractToRef(pO._internalAbstractMeshDataInfo._meshCollisionData._oldPositionForCollisions, pO._internalAbstractMeshDataInfo._meshCollisionData._diffPositionForCollisions), pO._internalAbstractMeshDataInfo._meshCollisionData._diffPositionForCollisions.length() > IO.e.CollisionsEpsilon && pO.position.addInPlace(pO._internalAbstractMeshDataInfo._meshCollisionData._diffPositionForCollisions), XO && pO.onCollideObservable.notifyObservers(XO), pO.onCollisionPositionChangeObservable.notifyObservers(pO.position)
              }, XO = this.JKO(), this.layerMask = XO.defaultRenderableLayerMask, XO.GhO(this), this._resyncLightSources(), this._uniformBuffer = new MO.d(this.JKO().qb(), void 0, void 0, KO, !this.JKO().qb().isWebGPU), this._buildUniformLayout(), XO.performancePriority) {
              case 2:
                this.kb = !0;
              case 1:
                this.xb = !0, this.De = !1
            }
          }
          _buildUniformLayout() {
            this._uniformBuffer.addUniform("world", 16), this._uniformBuffer.addUniform("visibility", 1), this._uniformBuffer.create()
          }
          transferToEffect(OO) {
            const KO = this._uniformBuffer;
            KO.AlO("world", OO), KO.updateFloat("visibility", this._internalAbstractMeshDataInfo._visibility), KO.update()
          }
          getMeshUniformBuffer() {
            return this._uniformBuffer
          }
          get _isGaussianSplatting() {
            return !1
          }
          getClassName() {
            return "AbstractMesh"
          }
          toString(OO) {
            let KO = "Name: " + this.name + ", isInstance: " + ("InstancedMesh" === this.getClassName() ? "YES" : "NO");
            KO += ", # of submeshes: " + (this.au ? this.au.length : 0);
            const pO = this._internalAbstractMeshDataInfo._skeleton;
            return pO && (KO += ", skeleton: " + pO.name), OO && (KO += ", billboard mode: " + ["NONE", "X", "Y", null, "Z", null, null, "ALL"][this.billboardMode], KO += ", freeze wrld mat: " + (this._isWorldMatrixFrozen || this._waitingData.qpO ? "YES" : "NO")), KO
          }
          _getEffectiveParent() {
            return this._masterMesh && this.billboardMode !== CO.i.BILLBOARDMODE_NONE ? this._masterMesh : super._getEffectiveParent()
          }
          _getActionManagerForTrigger(OO) {
            let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
            if (this.actionManager && (KO || this.actionManager.isRecursive)) {
              if (!OO) return this.actionManager;
              if (this.actionManager.hasSpecificTrigger(OO)) return this.actionManager
            }
            return this.parent ? this.parent._getActionManagerForTrigger(OO, !1) : null
          }
          _releaseRenderPassId(OO) {}
          _rebuild() {
            if (this.onRebuildObservable.notifyObservers(this), null !== this._occlusionQuery && (this._occlusionQuery = null), this.au) {
              for (const OO of this.au) OO._rebuild();
              this.resetDrawCache()
            }
          }
          _resyncLightSources() {
            this._lightSources.length = 0;
            for (const OO of this.JKO().lights) OO.isEnabled() && OO.canAffectMesh(this) && this._lightSources.push(OO);
            this._markSubMeshesAsLightDirty()
          }
          _resyncLightSource(OO) {
            const KO = OO.isEnabled() && OO.canAffectMesh(this),
              pO = this._lightSources.indexOf(OO);
            let XO = !1;
            if (-1 === pO) {
              if (!KO) return;
              this._lightSources.push(OO)
            } else {
              if (KO) return;
              XO = !0, this._lightSources.splice(pO, 1)
            }
            this._markSubMeshesAsLightDirty(XO)
          }
          _unBindEffect() {
            for (const OO of this.au) OO.setEffect(null)
          }
          _removeLightSource(OO, KO) {
            const pO = this._lightSources.indexOf(OO); - 1 !== pO && (this._lightSources.splice(pO, 1), this._markSubMeshesAsLightDirty(KO))
          }
          _markSubMeshesAsDirty(OO) {
            if (this.au)
              for (const KO of this.au)
                for (let pO = 0; pO < KO._drawWrappers.length; ++pO) {
                  const XO = KO._drawWrappers[pO];
                  XO && XO.defines && XO.defines.markAllAsDirty && OO(XO.defines)
                }
          }
          _markSubMeshesAsLightDirty() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            this._markSubMeshesAsDirty((KO => KO.markAsLightDirty(OO)))
          }
          _markSubMeshesAsAttributesDirty() {
            this._markSubMeshesAsDirty((OO => OO.markAsAttributesDirty()))
          }
          _markSubMeshesAsMiscDirty() {
            this._markSubMeshesAsDirty((OO => OO.markAsMiscDirty()))
          }
          jhO(OO) {
            return this._currentRenderId = Number.MAX_VALUE, super.jhO(OO), this._isDirty = !0, this
          }
          resetDrawCache(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if (this.au)
              for (const pO of this.au) pO.resetDrawCache(OO, KO)
          }
          get isBlocked() {
            return !1
          }
          getLOD(OO) {
            return this
          }
          getTotalVertices() {
            return 0
          }
          getTotalIndices() {
            return 0
          }
          rFO() {
            return null
          }
          getVerticesData(OO) {
            return null
          }
          setVerticesData(OO, KO, pO, XO) {
            return this
          }
          updateVerticesData(OO, KO, pO, XO) {
            return this
          }
          setIndices(OO, KO) {
            return this
          }
          isVerticesDataPresent(OO) {
            return !1
          }
          hpO() {
            return this._masterMesh ? this._masterMesh.hpO() : (this._boundingInfoIsDirty && (this._boundingInfoIsDirty = !1, this._updateBoundingInfo()), this._boundingInfo)
          }
          getRawBoundingInfo() {
            return this.rawBoundingInfo ?? this.hpO()
          }
          setBoundingInfo(OO) {
            return this._boundingInfo = OO, this
          }
          get hasBoundingInfo() {
            return null !== this._boundingInfo
          }
          buildBoundingInfo(OO, KO, pO) {
            return this._boundingInfo = new DO.d(OO, KO, pO), this._boundingInfo
          }
          normalizeToUnitCube() {
            let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
              KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              pO = arguments.length > 2 ? arguments[2] : void 0;
            return super.normalizeToUnitCube(OO, KO, pO)
          }
          get useBones() {
            return this.skeleton && this.JKO().skeletonsEnabled && this.isVerticesDataPresent(lO.j.MatricesIndicesKind) && this.isVerticesDataPresent(lO.j.MatricesWeightsKind)
          }
          _preActivate() {}
          _preActivateForIntermediateRendering(OO) {}
          _activate(OO, KO) {
            return this._renderId = OO, !0
          }
          _postActivate() {}
          _freeze() {}
          _unFreeze() {}
          getWorldMatrix() {
            return this._masterMesh && this.billboardMode === CO.i.BILLBOARDMODE_NONE ? this._masterMesh.getWorldMatrix() : super.getWorldMatrix()
          }
          _getWorldMatrixDeterminant() {
            return this._masterMesh ? this._masterMesh._getWorldMatrixDeterminant() : super._getWorldMatrixDeterminant()
          }
          get BKO() {
            return !1
          }
          get RDO() {
            return !1
          }
          get hasThinInstances() {
            return !1
          }
          movePOV(OO, KO, pO) {
            return this.position.addInPlace(this.calcMovePOV(OO, KO, pO)), this
          }
          calcMovePOV(OO, KO, pO) {
            const XO = new eO.c;
            (this.rotationQuaternion ? this.rotationQuaternion : eO.g.RotationYawPitchRoll(this.rotation.y, this.rotation.x, this.rotation.z)).toRotationMatrix(XO);
            const bK = eO.o.Zero(),
              lO = this.definedFacingForward ? -1 : 1;
            return eO.o.TransformCoordinatesFromFloatsToRef(OO * lO, KO, pO * lO, XO, bK), bK
          }
          rotatePOV(OO, KO, pO) {
            return this.rotation.addInPlace(this.calcRotatePOV(OO, KO, pO)), this
          }
          calcRotatePOV(OO, KO, pO) {
            const XO = this.definedFacingForward ? 1 : -1;
            return new eO.o(OO * XO, KO, pO * XO)
          }
          _refreshBoundingInfo(OO, KO) {
            if (OO) {
              const pO = (0, zK.c)(OO, 0, this.getTotalVertices(), KO);
              this._boundingInfo ? this._boundingInfo.reConstruct(pO.minimum, pO.maximum) : this._boundingInfo = new DO.d(pO.minimum, pO.maximum)
            }
            if (this.au)
              for (let pO = 0; pO < this.au.length; pO++) this.au[pO].refreshBoundingInfo(OO);
            this._updateBoundingInfo()
          }
          _refreshBoundingInfoDirect(OO) {
            if (this._boundingInfo ? this._boundingInfo.reConstruct(OO.minimum, OO.maximum) : this._boundingInfo = new DO.d(OO.minimum, OO.maximum), this.au)
              for (let KO = 0; KO < this.au.length; KO++) this.au[KO].refreshBoundingInfo(null);
            this._updateBoundingInfo()
          }
          static _ApplySkeleton(OO, KO, pO, XO, bK, vK, CO) {
            ! function(OO, KO, pO, XO, bK, vK, CO) {
              const hO = eO.j.WX[0],
                DO = eO.j.Matrix[0],
                MO = eO.j.Matrix[1],
                aK = KO === lO.j.NormalKind ? eO.o.TransformNormalFromFloatsToRef : eO.o.TransformCoordinatesFromFloatsToRef;
              for (let lO = 0, oO = 0; lO < OO.length; lO += 3, oO += 4) {
                let KO, FO;
                for (DO.reset(), KO = 0; KO < 4; KO++) FO = bK[oO + KO], FO > 0 && (eO.c.FromFloat32ArrayToRefScaled(pO, Math.floor(16 * XO[oO + KO]), FO, MO), DO.addToSelf(MO));
                if (vK && CO)
                  for (KO = 0; KO < 4; KO++) FO = CO[oO + KO], FO > 0 && (eO.c.FromFloat32ArrayToRefScaled(pO, Math.floor(16 * vK[oO + KO]), FO, MO), DO.addToSelf(MO));
                aK(OO[lO], OO[lO + 1], OO[lO + 2], DO, hO), hO.toArray(OO, lO)
              }
            }(OO, KO, pO, XO, bK, vK, CO)
          }
          _getData(KO, pO) {
            let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : lO.j.PositionKind;
            const bK = KO.cache,
              vK = OO => {
                if (bK) {
                  const KO = bK._vertexData || (bK._vertexData = {});
                  return KO[OO] || this.copyVerticesData(OO, KO), KO[OO]
                }
                return this.getVerticesData(OO)
              };
            if (pO || (pO = vK(XO)), !pO) return null;
            bK ? (bK._outputData ? bK._outputData.set(pO) : bK._outputData = new Float32Array(pO), pO = bK._outputData) : (KO.applyMorph && this.morphTargetManager || KO.applySkeleton && this.skeleton || KO.applyBakedVertexAnimation && this.bakedVertexAnimationManager?.isEnabled) && (pO = pO.slice()), KO.applyMorph && this.morphTargetManager && function(OO, KO, pO) {
              let XO;
              switch (KO) {
                case lO.j.PositionKind:
                  XO = OO => OO.getPositions();
                  break;
                case lO.j.NormalKind:
                  XO = OO => OO.getNormals();
                  break;
                case lO.j.TangentKind:
                  XO = OO => OO.getTangents();
                  break;
                case lO.j.UVKind:
                  XO = OO => OO.getUVs();
                  break;
                case lO.j.UV2Kind:
                  XO = OO => OO.getUV2s();
                  break;
                case lO.j.ColorKind:
                  XO = OO => OO.getColors();
                  break;
                default:
                  return
              }
              for (let bK = 0; bK < OO.length; bK++) {
                let KO = OO[bK];
                for (let eO = 0; eO < pO.numTargets; eO++) {
                  const lO = pO.getTarget(eO),
                    vK = lO.influence;
                  if (0 !== vK) {
                    const pO = XO(lO);
                    pO && (KO += (pO[bK] - OO[bK]) * vK)
                  }
                }
                OO[bK] = KO
              }
            }(pO, XO, this.morphTargetManager);
            const CO = this.bakedVertexAnimationManager;
            let hO = !1;
            if (KO.applyBakedVertexAnimation && CO?.isEnabled) {
              const OO = vK(lO.j.MatricesIndicesKind),
                bK = vK(lO.j.MatricesWeightsKind);
              if (bK && OO) {
                const eO = this.numBoneInfluencers > 4,
                  DO = eO ? vK(lO.j.MatricesIndicesExtraKind) : null,
                  MO = eO ? vK(lO.j.MatricesWeightsExtraKind) : null;
                hO = EO(pO, XO, CO, KO.bakedVertexAnimationSettings ?? CO.animationParameters, OO, bK, DO, MO, this.numBoneInfluencers)
              }
            }
            if (!hO && KO.applySkeleton && this.skeleton) {
              const KO = vK(lO.j.MatricesIndicesKind),
                bK = vK(lO.j.MatricesWeightsKind);
              if (bK && KO) {
                const eO = this.numBoneInfluencers > 4,
                  CO = eO ? vK(lO.j.MatricesIndicesExtraKind) : null,
                  hO = eO ? vK(lO.j.MatricesWeightsExtraKind) : null,
                  DO = this.skeleton.getTransformMatrices(this);
                OO._ApplySkeleton(pO, XO, DO, KO, bK, CO, hO)
              }
            }
            if (!1 !== KO.updatePositionsArray && XO === lO.j.PositionKind) {
              const OO = this._internalAbstractMeshDataInfo._positions || [],
                KO = OO.length;
              if (OO.length = pO.length / 3, KO < OO.length)
                for (let pO = KO; pO < OO.length; pO++) OO[pO] = new eO.o;
              for (let XO = 0, bK = 0; XO < OO.length; XO++, bK += 3) OO[XO].rvO(pO[bK], pO[bK + 1], pO[bK + 2]);
              this._internalAbstractMeshDataInfo._positions = OO
            }
            return pO
          }
          getNormalsData() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
              KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            return this._getData({
              applySkeleton: OO,
              applyMorph: KO,
              updatePositionsArray: !1
            }, null, lO.j.NormalKind)
          }
          beO() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
              KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
            return this._getData({
              applySkeleton: OO,
              applyMorph: KO,
              updatePositionsArray: !1
            }, pO, lO.j.PositionKind)
          }
          _updateBoundingInfo() {
            return this._boundingInfo ? this._boundingInfo.update(this.worldMatrixFromCache) : this._boundingInfo = new DO.d(eO.o.Zero(), eO.o.Zero(), this.worldMatrixFromCache), this._updateSubMeshesBoundingInfo(this.worldMatrixFromCache), this
          }
          _updateSubMeshesBoundingInfo(OO) {
            if (!this.au) return this;
            const KO = this.au.length;
            for (let pO = 0; pO < KO; pO++) {
              const XO = this.au[pO];
              (KO > 1 || !XO.IsGlobal) && XO.updateBoundingInfo(OO)
            }
            return this
          }
          _afterComputeWorldMatrix() {
            this.kb || (this._boundingInfoIsDirty = !0)
          }
          isInFrustum(OO) {
            return this.hpO().isInFrustum(OO, this.cullingStrategy)
          }
          isCompletelyInFrustum(OO) {
            return this.hpO().isCompletelyInFrustum(OO)
          }
          iMO(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              pO = arguments.length > 2 ? arguments[2] : void 0;
            const XO = this.hpO(),
              bK = OO.hpO();
            if (XO.intersects(bK, KO)) return !0;
            if (pO)
              for (const eO of this.getChildMeshes())
                if (eO.iMO(OO, KO, !0)) return !0;
            return !1
          }
          intersectsPoint(OO) {
            return this.hpO().intersectsPoint(OO)
          }
          get checkCollisions() {
            return this._internalAbstractMeshDataInfo._meshCollisionData._checkCollisions
          }
          set checkCollisions(OO) {
            this._internalAbstractMeshDataInfo._meshCollisionData._checkCollisions = OO
          }
          get collider() {
            return this._internalAbstractMeshDataInfo._meshCollisionData._collider
          }
          moveWithCollisions(OO) {
            let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
            this.getAbsolutePosition().addToRef(this.ellipsoidOffset, this._internalAbstractMeshDataInfo._meshCollisionData._oldPositionForCollisions);
            const pO = this.JKO().collisionCoordinator;
            return this._internalAbstractMeshDataInfo._meshCollisionData._collider || (this._internalAbstractMeshDataInfo._meshCollisionData._collider = pO.createCollider()), this._internalAbstractMeshDataInfo._meshCollisionData._collider._radius = this.ellipsoid, pO.getNewPosition(this._internalAbstractMeshDataInfo._meshCollisionData._oldPositionForCollisions, OO, this._internalAbstractMeshDataInfo._meshCollisionData._collider, this.collisionRetryCount, this, this._onCollisionPositionChange, this.uniqueId, KO), this
          }
          _collideForSubMesh(OO, KO, pO) {
            if (this._generatePointsArray(), !this._positions) return this;
            if (!OO._lastColliderWorldVertices || !OO._lastColliderTransformMatrix.equals(KO)) {
              OO._lastColliderTransformMatrix = KO.clone(), OO._lastColliderWorldVertices = [], OO._trianglePlanes = [];
              const pO = OO.verticesStart,
                XO = OO.verticesStart + OO.verticesCount;
              for (let bK = pO; bK < XO; bK++) OO._lastColliderWorldVertices.push(eO.o.TransformCoordinates(this._positions[bK], KO))
            }
            return pO._collide(OO._trianglePlanes, OO._lastColliderWorldVertices, this.rFO(), OO.indexStart, OO.indexStart + OO.indexCount, OO.verticesStart, !!OO.UX(), this, this._shouldConvertRHS(), 7 === OO.UX()?.fillMode), this
          }
          _processCollisionsForSubMeshes(OO, KO) {
            const pO = this._scene.getCollidingSubMeshCandidates(this, OO),
              XO = pO.length;
            for (let bK = 0; bK < XO; bK++) {
              const eO = pO.data[bK];
              XO > 1 && !eO._checkCollision(OO) || this._collideForSubMesh(eO, KO, OO)
            }
            return this
          }
          _shouldConvertRHS() {
            return !1
          }
          _checkCollision(OO) {
            if (!this.hpO()._checkCollision(OO)) return this;
            const KO = eO.j.Matrix[0],
              pO = eO.j.Matrix[1];
            return eO.c.ScalingToRef(1 / OO._radius.x, 1 / OO._radius.y, 1 / OO._radius.z, KO), this.worldMatrixFromCache.multiplyToRef(KO, pO), this._processCollisionsForSubMeshes(OO, pO), this
          }
          _generatePointsArray() {
            return !1
          }
          intersects(OO, KO, pO) {
            let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
              bK = arguments.length > 4 ? arguments[4] : void 0,
              lO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
            const vK = new hO.c,
              CO = this.getClassName(),
              DO = "InstancedLinesMesh" === CO || "LinesMesh" === CO || "GreasedLineMesh" === CO ? this.intersectionThreshold : 0,
              MO = this.hpO();
            if (!this.au) return vK;
            if (!lO && (!OO.intersectsSphere(MO.QDO, DO) || !OO.intersectsBox(MO.boundingBox, DO))) return vK;
            if (XO) return vK.hit = !lO, vK.pickedMesh = lO ? null : this, vK.distance = lO ? 0 : eO.o.Distance(OO.origin, MO.QDO.center), vK.subMeshId = 0, vK;
            if (!this._generatePointsArray()) return vK;
            let aK = null;
            const oO = this._scene.getIntersectingSubMeshCandidates(this, OO),
              FO = oO.length;
            let VO = !1;
            for (let eO = 0; eO < FO; eO++) {
              const OO = oO.data[eO].UX();
              if (OO && (7 == OO.fillMode || 0 == OO.fillMode || 1 == OO.fillMode || 2 == OO.fillMode || 4 == OO.fillMode)) {
                VO = !0;
                break
              }
            }
            if (!VO) return vK.hit = !0, vK.pickedMesh = this, vK.distance = eO.o.Distance(OO.origin, MO.QDO.center), vK.subMeshId = -1, vK;
            for (let eO = 0; eO < FO; eO++) {
              const XO = oO.data[eO];
              if (FO > 1 && !lO && !XO.canIntersects(OO)) continue;
              const bK = XO.intersects(OO, this._positions, this.rFO(), KO, pO);
              if (bK && (KO || !aK || bK.distance < aK.distance) && (aK = bK, aK.subMeshId = XO._id, aK._internalSubMeshId = eO, KO)) break
            }
            if (aK) {
              const KO = bK ?? this.getWorldMatrix(),
                pO = eO.j.WX[0],
                XO = eO.j.WX[1];
              eO.o.TransformCoordinatesToRef(OO.origin, KO, pO), OO.direction.scaleToRef(aK.distance, XO);
              const lO = eO.o.TransformNormal(XO, KO).addInPlace(pO);
              return vK.hit = !0, vK.distance = eO.o.Distance(pO, lO), vK.pickedPoint = lO, vK.pickedMesh = this, vK.bu = aK.bu || 0, vK.bv = aK.bv || 0, vK.subMeshFaceId = aK.faceId, vK.faceId = aK.faceId + oO.data[aK._internalSubMeshId].indexStart / (-1 !== this.getClassName().indexOf("LinesMesh") ? 2 : 3), vK.subMeshId = aK.subMeshId, vK
            }
            return vK
          }
          clone(OO, KO, pO) {
            return null
          }
          releaseSubMeshes() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (this.au)
              for (; this.au.length;) this.au[0].dispose(OO);
            else this.au = [];
            return this
          }
          dispose(OO) {
            let KO, pO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            const XO = this.JKO();
            for (this._scene.useMaterialMeshMap && this._internalAbstractMeshDataInfo._material && this._internalAbstractMeshDataInfo._material.meshMap && (this._internalAbstractMeshDataInfo._material.meshMap[this.uniqueId] = void 0), XO.freeActiveMeshes(), XO.freeRenderingGroups(), XO.renderingManager.maintainStateBetweenFrames && XO.renderingManager.restoreDispachedFlags(), void 0 !== this.actionManager && null !== this.actionManager && (this.actionManager.disposeWhenUnowned && !this._scene.meshes.some((OO => OO !== this && OO.actionManager === this.actionManager)) && this.actionManager.dispose(), this.actionManager = null), this._internalAbstractMeshDataInfo._skeleton = null, this._transformMatrixTexture && (this._transformMatrixTexture.dispose(), this._transformMatrixTexture = null), KO = 0; KO < this._intersectionsInProgress.length; KO++) {
              const OO = this._intersectionsInProgress[KO],
                pO = OO._intersectionsInProgress.indexOf(this);
              OO._intersectionsInProgress.splice(pO, 1)
            }
            this._intersectionsInProgress.length = 0;
            const bK = XO.lights;
            for (const lO of bK) {
              let OO = lO.includedOnlyMeshes.indexOf(this); - 1 !== OO && lO.includedOnlyMeshes.splice(OO, 1), OO = lO.excludedMeshes.indexOf(this), -1 !== OO && lO.excludedMeshes.splice(OO, 1);
              const KO = lO.getShadowGenerators();
              if (KO) {
                const pO = KO.values();
                for (let KO = pO.next(); !0 !== KO.done; KO = pO.next()) {
                  const pO = KO.value.getShadowMap();
                  pO && pO.renderList && (OO = pO.renderList.indexOf(this), -1 !== OO && pO.renderList.splice(OO, 1))
                }
              }
            }
            this.releaseSubMeshes(XO._isDisposing);
            const eO = XO.qb();
            if (null !== this._occlusionQuery && (this.isOcclusionQueryInProgress = !1, eO.deleteQuery(this._occlusionQuery), this._occlusionQuery = null), eO.wipeCaches(), XO.nKO(this), this._parentContainer) {
              const OO = this._parentContainer.meshes.indexOf(this);
              OO > -1 && this._parentContainer.meshes.splice(OO, 1), this._parentContainer = null
            }
            if (pO && this.material && ("MultiMaterial" === this.material.getClassName() ? this.material.dispose(!1, !0, !0) : this.material.dispose(!1, !0)), !OO)
              for (KO = 0; KO < XO.ku.length; KO++) XO.ku[KO].emitter === this && (XO.ku[KO].dispose(), KO--);
            this._internalAbstractMeshDataInfo._facetData.facetDataEnabled && this.disableFacetData(), this._uniformBuffer.dispose(), this.onAfterWorldMatrixUpdateObservable.clear(), this.onCollideObservable.clear(), this.onCollisionPositionChangeObservable.clear(), this.onRebuildObservable.clear(), super.dispose(OO, pO)
          }
          _initFacetData() {
            const OO = this._internalAbstractMeshDataInfo._facetData;
            OO.facetNormals || (OO.facetNormals = []), OO.facetPositions || (OO.facetPositions = []), OO.facetPartitioning || (OO.facetPartitioning = new Array), OO.facetNb = this.rFO().length / 3 | 0, OO.partitioningSubdivisions = OO.partitioningSubdivisions ? OO.partitioningSubdivisions : 10, OO.partitioningBBoxRatio = OO.partitioningBBoxRatio ? OO.partitioningBBoxRatio : 1.01;
            for (let KO = 0; KO < OO.facetNb; KO++) OO.facetNormals[KO] = eO.o.Zero(), OO.facetPositions[KO] = eO.o.Zero();
            return OO.facetDataEnabled = !0, this
          }
          updateFacetData() {
            const OO = this._internalAbstractMeshDataInfo._facetData;
            OO.facetDataEnabled || this._initFacetData();
            const KO = this.getVerticesData(lO.j.PositionKind),
              pO = this.rFO(),
              XO = this.getVerticesData(lO.j.NormalKind)?.slice(),
              bK = this.hpO();
            if (OO.facetDepthSort && !OO.facetDepthSortEnabled) {
              if (OO.facetDepthSortEnabled = !0, pO instanceof Uint16Array) OO.depthSortedIndices = new Uint16Array(pO);
              else if (pO instanceof Uint32Array) OO.depthSortedIndices = new Uint32Array(pO);
              else {
                let KO = !1;
                for (let OO = 0; OO < pO.length; OO++)
                  if (pO[OO] > 65535) {
                    KO = !0;
                    break
                  } OO.depthSortedIndices = KO ? new Uint32Array(pO) : new Uint16Array(pO)
              }
              if (OO.facetDepthSortFunction = function(OO, KO) {
                  return KO.sqDistance - OO.sqDistance
                }, !OO.facetDepthSortFrom) {
                const KO = this.JKO().activeCamera;
                OO.facetDepthSortFrom = KO ? KO.position : eO.o.Zero()
              }
              OO.depthSortedFacets = [];
              for (let KO = 0; KO < OO.facetNb; KO++) {
                const pO = {
                  ind: 3 * KO,
                  sqDistance: 0
                };
                OO.depthSortedFacets.push(pO)
              }
              OO.invertedMatrix = eO.c.Identity(), OO.facetDepthSortOrigin = eO.o.Zero()
            }
            OO.bbSize.x = bK.maximum.x - bK.minimum.x > fO.c ? bK.maximum.x - bK.minimum.x : fO.c, OO.bbSize.y = bK.maximum.y - bK.minimum.y > fO.c ? bK.maximum.y - bK.minimum.y : fO.c, OO.bbSize.z = bK.maximum.z - bK.minimum.z > fO.c ? bK.maximum.z - bK.minimum.z : fO.c;
            let CO = OO.bbSize.x > OO.bbSize.y ? OO.bbSize.x : OO.bbSize.y;
            if (CO = CO > OO.bbSize.z ? CO : OO.bbSize.z, OO.subDiv.max = OO.partitioningSubdivisions, OO.subDiv.X = Math.floor(OO.subDiv.max * OO.bbSize.x / CO), OO.subDiv.Y = Math.floor(OO.subDiv.max * OO.bbSize.y / CO), OO.subDiv.Z = Math.floor(OO.subDiv.max * OO.bbSize.z / CO), OO.subDiv.X = OO.subDiv.X < 1 ? 1 : OO.subDiv.X, OO.subDiv.Y = OO.subDiv.Y < 1 ? 1 : OO.subDiv.Y, OO.subDiv.Z = OO.subDiv.Z < 1 ? 1 : OO.subDiv.Z, OO.facetParameters.facetNormals = this.getFacetLocalNormals(), OO.facetParameters.facetPositions = this.getFacetLocalPositions(), OO.facetParameters.facetPartitioning = this.getFacetLocalPartitioning(), OO.facetParameters.bInfo = bK, OO.facetParameters.bbSize = OO.bbSize, OO.facetParameters.subDiv = OO.subDiv, OO.facetParameters.ratio = this.partitioningBBoxRatio, OO.facetParameters.depthSort = OO.facetDepthSort, OO.facetDepthSort && OO.facetDepthSortEnabled && (this.computeWorldMatrix(!0), this._worldMatrix.invertToRef(OO.invertedMatrix), eO.o.TransformCoordinatesToRef(OO.facetDepthSortFrom, OO.invertedMatrix, OO.facetDepthSortOrigin), OO.facetParameters.distanceTo = OO.facetDepthSortOrigin), OO.facetParameters.depthSortedFacets = OO.depthSortedFacets, XO && vK.e.ComputeNormals(KO, pO, XO, OO.facetParameters), OO.facetDepthSort && OO.facetDepthSortEnabled) {
              OO.depthSortedFacets.sort(OO.facetDepthSortFunction);
              const KO = OO.depthSortedIndices.length / 3 | 0;
              for (let XO = 0; XO < KO; XO++) {
                const KO = OO.depthSortedFacets[XO].ind;
                OO.depthSortedIndices[3 * XO] = pO[KO], OO.depthSortedIndices[3 * XO + 1] = pO[KO + 1], OO.depthSortedIndices[3 * XO + 2] = pO[KO + 2]
              }
              this.updateIndices(OO.depthSortedIndices, void 0, !0)
            }
            return this
          }
          getFacetLocalNormals() {
            const OO = this._internalAbstractMeshDataInfo._facetData;
            return OO.facetNormals || this.updateFacetData(), OO.facetNormals
          }
          getFacetLocalPositions() {
            const OO = this._internalAbstractMeshDataInfo._facetData;
            return OO.facetPositions || this.updateFacetData(), OO.facetPositions
          }
          getFacetLocalPartitioning() {
            const OO = this._internalAbstractMeshDataInfo._facetData;
            return OO.facetPartitioning || this.updateFacetData(), OO.facetPartitioning
          }
          getFacetPosition(OO) {
            const KO = eO.o.Zero();
            return this.getFacetPositionToRef(OO, KO), KO
          }
          getFacetPositionToRef(OO, KO) {
            const pO = this.getFacetLocalPositions()[OO],
              XO = this.getWorldMatrix();
            return eO.o.TransformCoordinatesToRef(pO, XO, KO), this
          }
          getFacetNormal(OO) {
            const KO = eO.o.Zero();
            return this.getFacetNormalToRef(OO, KO), KO
          }
          getFacetNormalToRef(OO, KO) {
            const pO = this.getFacetLocalNormals()[OO];
            return eO.o.TransformNormalToRef(pO, this.getWorldMatrix(), KO), this
          }
          getFacetsAtLocalCoordinates(OO, KO, pO) {
            const XO = this.hpO(),
              bK = this._internalAbstractMeshDataInfo._facetData,
              eO = Math.floor((OO - XO.minimum.x * bK.partitioningBBoxRatio) * bK.subDiv.X * bK.partitioningBBoxRatio / bK.bbSize.x),
              lO = Math.floor((KO - XO.minimum.y * bK.partitioningBBoxRatio) * bK.subDiv.Y * bK.partitioningBBoxRatio / bK.bbSize.y),
              vK = Math.floor((pO - XO.minimum.z * bK.partitioningBBoxRatio) * bK.subDiv.Z * bK.partitioningBBoxRatio / bK.bbSize.z);
            return eO < 0 || eO > bK.subDiv.max || lO < 0 || lO > bK.subDiv.max || vK < 0 || vK > bK.subDiv.max ? null : bK.facetPartitioning[eO + bK.subDiv.max * lO + bK.subDiv.max * bK.subDiv.max * vK]
          }
          getClosestFacetAtCoordinates(OO, KO, pO, XO) {
            let bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
              lO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5];
            const vK = this.getWorldMatrix(),
              CO = eO.j.Matrix[5];
            vK.invertToRef(CO);
            const hO = eO.j.WX[8];
            eO.o.TransformCoordinatesFromFloatsToRef(OO, KO, pO, CO, hO);
            const DO = this.getClosestFacetAtLocalCoordinates(hO.x, hO.y, hO.z, XO, bK, lO);
            return XO && eO.o.TransformCoordinatesFromFloatsToRef(XO.x, XO.y, XO.z, vK, XO), DO
          }
          getClosestFacetAtLocalCoordinates(OO, KO, pO, XO) {
            let bK, eO, lO, vK, CO, hO, DO, MO, aK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
              oO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
              FO = null;
            const VO = this.getFacetLocalPositions(),
              LO = this.getFacetLocalNormals(),
              QO = this.getFacetsAtLocalCoordinates(OO, KO, pO);
            if (!QO) return null;
            let zK, AO, fO, dO, TO = Number.MAX_VALUE;
            for (let NO = 0; NO < QO.length; NO++) AO = QO[NO], fO = LO[AO], dO = VO[AO], vK = (OO - dO.x) * fO.x + (KO - dO.y) * fO.y + (pO - dO.z) * fO.z, (!aK || aK && oO && vK >= 0 || aK && !oO && vK <= 0) && (vK = fO.x * dO.x + fO.y * dO.y + fO.z * dO.z, CO = -(fO.x * OO + fO.y * KO + fO.z * pO - vK) / (fO.x * fO.x + fO.y * fO.y + fO.z * fO.z), hO = OO + fO.x * CO, DO = KO + fO.y * CO, MO = pO + fO.z * CO, bK = hO - OO, eO = DO - KO, lO = MO - pO, zK = bK * bK + eO * eO + lO * lO, zK < TO && (TO = zK, FO = AO, XO && (XO.x = hO, XO.y = DO, XO.z = MO)));
            return FO
          }
          getFacetDataParameters() {
            return this._internalAbstractMeshDataInfo._facetData.facetParameters
          }
          disableFacetData() {
            const OO = this._internalAbstractMeshDataInfo._facetData;
            return OO.facetDataEnabled && (OO.facetDataEnabled = !1, OO.facetPositions = [], OO.facetNormals = [], OO.facetPartitioning = new Array, OO.facetParameters = {}, OO.depthSortedIndices = new Uint32Array(0)), this
          }
          updateIndices(OO, KO) {
            return this
          }
          createNormals(OO) {
            const KO = this.getVerticesData(lO.j.PositionKind),
              pO = this.rFO();
            let XO;
            return XO = this.isVerticesDataPresent(lO.j.NormalKind) ? this.getVerticesData(lO.j.NormalKind) : [], vK.e.ComputeNormals(KO, pO, XO, {
              useRightHandedSystem: this.JKO().useRightHandedSystem
            }), this.setVerticesData(lO.j.NormalKind, XO, OO), this
          }
          async optimizeIndicesAsync() {
            const OO = this.rFO();
            if (!OO) return this;
            const {
              OptimizeIndices: KO
            } = await pO.e(331).then((() => pO(40579)));
            return KO(OO), this.setIndices(OO, this.getTotalVertices()), this
          }
          alignWithNormal(OO, KO) {
            KO || (KO = dO.b.Y);
            const pO = eO.j.WX[0],
              XO = eO.j.WX[1];
            return eO.o.CrossToRef(KO, OO, XO), eO.o.CrossToRef(OO, XO, pO), this.rotationQuaternion ? eO.g.RotationQuaternionFromAxisToRef(pO, OO, XO, this.rotationQuaternion) : eO.o.RotationFromAxisToRef(pO, OO, XO, this.rotation), this
          }
          _checkOcclusionQuery() {
            return !1
          }
          disableEdgesRendering() {
            throw (0, LO.j)("EdgesRenderer")
          }
          enableEdgesRendering(OO, KO, pO) {
            throw (0, LO.j)("EdgesRenderer")
          }
          getConnectedParticleSystems() {
            return this._scene.ku.filter((OO => OO.emitter === this))
          }
        }, (() => {
          const pO = "function" === typeof Symbol && Symbol.metadata ? Object.create(aK[Symbol.metadata] ?? null) : void 0;
          KO = [NO.l.filter((function() {
            return !Array.isArray(arguments.length <= 0 ? void 0 : arguments[0]) && !Array.isArray(arguments.length <= 3 ? void 0 : arguments[3]) && !Array.isArray(arguments.length <= 4 ? void 0 : arguments[4]) && !Array.isArray(arguments.length <= 5 ? void 0 : arguments[5]) && !Array.isArray(arguments.length <= 6 ? void 0 : arguments[6])
          }))], (0, XO.f)(OO, null, KO, {
            kind: "method",
            name: "_ApplySkeleton",
            static: !0,
            private: !1,
            access: {
              has: OO => "_ApplySkeleton" in OO,
              get: OO => OO._ApplySkeleton
            },
            metadata: pO
          }, null, oO), pO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: pO
          })
        })(), OO.OCCLUSION_TYPE_NONE = ((0, XO.i)(OO, oO), 0), OO.OCCLUSION_TYPE_OPTIMISTIC = 1, OO.OCCLUSION_TYPE_STRICT = 2, OO.OCCLUSION_ALGORITHM_TYPE_ACCURATE = 0, OO.OCCLUSION_ALGORITHM_TYPE_CONSERVATIVE = 1, OO.CULLINGSTRATEGY_STANDARD = 0, OO.CULLINGSTRATEGY_BOUNDINGSPHERE_ONLY = 1, OO.CULLINGSTRATEGY_OPTIMISTIC_INCLUSION = 2, OO.CULLINGSTRATEGY_OPTIMISTIC_INCLUSION_THEN_BSPHERE_ONLY = 3, OO.DefaultIsPickable = !0, OO
      })(),
      iK = !1;

    function rK() {
      iK || (iK = !0, (0, yK.h)("BABYLON.AbstractMesh", wO))
    }(oO = wO.prototype).createOrUpdateSubmeshesOctree ?? (oO.createOrUpdateSubmeshesOctree = (0, LO.h)("AbstractMesh", "createOrUpdateSubmeshesOctree")), (FO = wO.prototype).getPhysicsImpostor ?? (FO.getPhysicsImpostor = (0, LO.h)("AbstractMesh", "getPhysicsImpostor")), (VO = wO.prototype).setPhysicsLinkWith ?? (VO.setPhysicsLinkWith = (0, LO.h)("AbstractMesh", "setPhysicsLinkWith")), Object.getOwnPropertyDescriptor(wO.prototype, "occlusionRetryCount") || Object.defineProperty(wO.prototype, "occlusionRetryCount", (0, LO.e)("AbstractMesh", "occlusionRetryCount")), Object.getOwnPropertyDescriptor(wO.prototype, "occlusionType") || Object.defineProperty(wO.prototype, "occlusionType", (0, LO.e)("AbstractMesh", "occlusionType")), Object.getOwnPropertyDescriptor(wO.prototype, "occlusionQueryAlgorithmType") || Object.defineProperty(wO.prototype, "occlusionQueryAlgorithmType", (0, LO.e)("AbstractMesh", "occlusionQueryAlgorithmType")), Object.getOwnPropertyDescriptor(wO.prototype, "isOccluded") || Object.defineProperty(wO.prototype, "isOccluded", (0, LO.e)("AbstractMesh", "isOccluded")), Object.getOwnPropertyDescriptor(wO.prototype, "isOcclusionQueryInProgress") || Object.defineProperty(wO.prototype, "isOcclusionQueryInProgress", (0, LO.e)("AbstractMesh", "isOcclusionQueryInProgress")), Object.getOwnPropertyDescriptor(wO.prototype, "forceRenderingWhenOccluded") || Object.defineProperty(wO.prototype, "forceRenderingWhenOccluded", (0, LO.e)("AbstractMesh", "forceRenderingWhenOccluded")), Object.getOwnPropertyDescriptor(wO.prototype, "occlusionForRenderPassId") || Object.defineProperty(wO.prototype, "occlusionForRenderPassId", (0, LO.e)("AbstractMesh", "occlusionForRenderPassId")), Object.getOwnPropertyDescriptor(wO.prototype, "decalMap") || Object.defineProperty(wO.prototype, "decalMap", (0, LO.e)("AbstractMesh", "decalMap")), Object.getOwnPropertyDescriptor(wO.prototype, "lpO") || Object.defineProperty(wO.prototype, "lpO", (0, LO.e)("AbstractMesh", "lpO")), Object.getOwnPropertyDescriptor(wO.prototype, "physicsImpostor") || Object.defineProperty(wO.prototype, "physicsImpostor", (0, LO.e)("AbstractMesh", "physicsImpostor")), Object.getOwnPropertyDescriptor(wO.prototype, "showBoundingBox") || Object.defineProperty(wO.prototype, "showBoundingBox", (0, LO.e)("AbstractMesh", "showBoundingBox")), Object.getOwnPropertyDescriptor(wO.prototype, "edgesRenderer") || Object.defineProperty(wO.prototype, "edgesRenderer", (0, LO.e)("AbstractMesh", "edgesRenderer")), Object.getOwnPropertyDescriptor(wO.prototype, "renderOutline") || Object.defineProperty(wO.prototype, "renderOutline", (0, LO.e)("AbstractMesh", "renderOutline")), Object.getOwnPropertyDescriptor(wO.prototype, "renderOverlay") || Object.defineProperty(wO.prototype, "renderOverlay", (0, LO.e)("AbstractMesh", "renderOverlay"))
  },
  38517: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => QO
    });
    var XO = pO(35632),
      bK = pO(35688),
      eO = pO(38511),
      lO = pO(38216),
      vK = pO(38388),
      CO = pO(38521),
      hO = pO(38400),
      DO = pO(38172),
      MO = pO(37061),
      aK = pO(38085),
      oO = pO(38413),
      FO = pO(35653),
      VO = pO(38530),
      LO = pO(38136);
    class QO {
      get boundingBias() {
        return this._boundingBias
      }
      set boundingBias(OO) {
        this._boundingBias ? this._boundingBias.NhO(OO) : this._boundingBias = OO.clone(), this._updateBoundingInfo(!0, null)
      }
      static CreateGeometryForMesh(OO) {
        const KO = new QO(QO.RandomId(), OO.JKO());
        return KO.applyToMesh(OO), KO
      }
      get meshes() {
        return this._meshes
      }
      constructor(OO, KO, pO) {
        let bK = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
          lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null;
        this.delayLoadState = 0, this._totalVertices = 0, this._isDisposed = !1, this._extend = {
          minimum: new XO.o(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE),
          maximum: new XO.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE)
        }, this._indexBufferIsUpdatable = !1, this._positionsCache = [], this._parentContainer = null, this.useBoundingInfoFromGeometry = !1, this._scene = KO || FO.c.LastCreatedScene, this._scene && (this.id = OO, this.uniqueId = this._scene.getUniqueId(), this._engine = this._scene.qb(), this._meshes = [], this._vertexBuffers = {}, this._indices = [], this._updatable = bK, null !== lO && (this._totalVertices = lO), pO ? this.setAllVerticesData(pO, bK) : null === lO && (this._totalVertices = 0), this._engine.getCaps().vertexArrayObject && (this._vertexArrayObjects = {}), eO && (this.applyToMesh(eO), eO.computeWorldMatrix(!0)))
      }
      get extend() {
        return this._extend
      }
      JKO() {
        return this._scene
      }
      qb() {
        return this._engine
      }
      isReady() {
        return 1 === this.delayLoadState || 0 === this.delayLoadState
      }
      get doNotSerialize() {
        for (let OO = 0; OO < this._meshes.length; OO++)
          if (!this._meshes[OO].doNotSerialize) return !1;
        return !0
      }
      _rebuild() {
        this._vertexArrayObjects && (this._vertexArrayObjects = {}), 0 !== this._meshes.length && this._indices && (this._indexBuffer = this._engine.createIndexBuffer(this._indices, this._updatable, "Geometry_" + this.id + "_IndexBuffer"));
        const OO = new Set;
        for (const KO in this._vertexBuffers) OO.add(this._vertexBuffers[KO].getWrapperBuffer());
        OO.forEach((OO => {
          OO._rebuild()
        }))
      }
      setAllVerticesData(OO, KO) {
        OO.applyToGeometry(this, KO), this._notifyUpdate()
      }
      setVerticesData(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 ? arguments[3] : void 0;
        pO && Array.isArray(KO) && (KO = new Float32Array(KO));
        const bK = new lO.j(this._engine, KO, OO, {
          updatable: pO,
          postponeInternalCreation: 0 === this._meshes.length,
          stride: XO,
          label: "Geometry_" + this.id + "_" + OO
        });
        this.setVerticesBuffer(bK)
      }
      removeVerticesData(OO) {
        this._vertexBuffers[OO] && (this._vertexBuffers[OO].dispose(), delete this._vertexBuffers[OO]), this._vertexArrayObjects && this._disposeVertexArrayObjects()
      }
      setVerticesBuffer(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        const bK = OO.getKind();
        this._vertexBuffers[bK] && pO && this._vertexBuffers[bK].dispose(), OO._buffer && OO._ownsBuffer && OO._buffer._increaseReferences(), this._vertexBuffers[bK] = OO;
        const eO = this._meshes,
          vK = eO.length;
        if (bK === lO.j.PositionKind) {
          this._totalVertices = KO ?? OO._maxVerticesCount, this._updateExtend(this.useBoundingInfoFromGeometry && this._boundingInfo ? null : OO.getFloatData(this._totalVertices)), this._resetPointsArrayCache();
          const pO = this._extend && this._extend.minimum || new XO.o(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE),
            bK = this._extend && this._extend.maximum || new XO.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE);
          for (let OO = 0; OO < vK; OO++) {
            const KO = eO[OO];
            KO.buildBoundingInfo(pO, bK), KO._createGlobalSubMesh(KO.isUnIndexed), KO.computeWorldMatrix(!0), KO.synchronizeInstances()
          }
        }
        this._notifyUpdate(bK)
      }
      updateVerticesDataDirectly(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        const bK = this.getVertexBuffer(OO);
        bK && (bK.updateDirectly(KO, pO, XO), this._notifyUpdate(OO))
      }
      updateVerticesData(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = this.getVertexBuffer(OO);
        XO && (XO.update(KO), OO === lO.j.PositionKind && this._updateBoundingInfo(pO, KO), this._notifyUpdate(OO))
      }
      _updateBoundingInfo(OO, KO) {
        if (OO && this._updateExtend(KO), this._resetPointsArrayCache(), OO) {
          const OO = this._meshes;
          for (const KO of OO) {
            KO.hasBoundingInfo ? KO.hpO().reConstruct(this._extend.minimum, this._extend.maximum) : KO.buildBoundingInfo(this._extend.minimum, this._extend.maximum);
            const OO = KO.au;
            for (const KO of OO) KO.refreshBoundingInfo()
          }
        }
      }
      _bind(OO, KO, pO, XO) {
        if (!OO) return;
        void 0 === KO && (KO = this._indexBuffer);
        const bK = this.getVertexBuffers();
        if (!bK) return;
        if (KO != this._indexBuffer || !this._vertexArrayObjects && !XO) return void this._engine.bindBuffers(bK, KO, OO, pO);
        const eO = XO || this._vertexArrayObjects,
          lO = this._engine;
        eO[OO.key] || (eO[OO.key] = lO.recordVertexArrayObject(bK, KO, OO, pO)), lO.bindVertexArrayObject(eO[OO.key], KO)
      }
      getTotalVertices() {
        return this.isReady() ? this._totalVertices : 0
      }
      getVerticesData(OO, KO, pO) {
        const XO = this.getVertexBuffer(OO);
        return XO ? XO.getFloatData(this._totalVertices, pO || KO && 1 !== this._meshes.length) : null
      }
      copyVerticesData(OO, KO) {
        const pO = this.getVertexBuffer(OO);
        if (!pO) return;
        KO[OO] || (KO[OO] = new Float32Array(this._totalVertices * pO.getSize()));
        const XO = pO.getData();
        XO && (0, LO.d)(XO, pO.getSize(), pO.type, pO.byteOffset, pO.byteStride, pO.normalized, this._totalVertices, KO[OO])
      }
      isVertexBufferUpdatable(OO) {
        const KO = this._vertexBuffers[OO];
        return !!KO && KO.isUpdatable()
      }
      getVertexBuffer(OO) {
        return this.isReady() ? this._vertexBuffers[OO] : null
      }
      getVertexBuffers() {
        return this.isReady() ? this._vertexBuffers : null
      }
      isVerticesDataPresent(OO) {
        return this._vertexBuffers ? void 0 !== this._vertexBuffers[OO] : !!this._delayInfo && -1 !== this._delayInfo.indexOf(OO)
      }
      getVerticesDataKinds() {
        const OO = [];
        let KO;
        if (!this._vertexBuffers && this._delayInfo)
          for (KO in this._delayInfo) OO.push(KO);
        else
          for (KO in this._vertexBuffers) OO.push(KO);
        return OO
      }
      updateIndices(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (this._indexBuffer)
          if (this._indexBufferIsUpdatable) {
            const XO = OO.length !== this._indices.length;
            if (pO || (this._indices = OO.slice()), this._engine.updateDynamicIndexBuffer(this._indexBuffer, OO, KO), XO)
              for (const OO of this._meshes) OO._createGlobalSubMesh(!0)
          } else this.setIndices(OO, null, !0)
      }
      setIndexBuffer(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        this._indices = [], this._indexBufferIsUpdatable = !1, this._indexBuffer = OO, this._totalVertices = KO, this._totalIndices = pO, OO.is32Bits = null === XO ? KO > 65535 : XO;
        for (const bK of this._meshes) bK._createGlobalSubMesh(!0), bK.synchronizeInstances();
        this._notifyUpdate()
      }
      setIndices(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        this._indexBuffer && this._engine._releaseBuffer(this._indexBuffer), this._indices = OO, this._indexBufferIsUpdatable = pO, 0 !== this._meshes.length && this._indices && (this._indexBuffer = this._engine.createIndexBuffer(this._indices, pO, "Geometry_" + this.id + "_IndexBuffer")), void 0 != KO && (this._totalVertices = KO);
        for (const bK of this._meshes) bK._createGlobalSubMesh(!XO), bK.synchronizeInstances();
        this._notifyUpdate()
      }
      getTotalIndices() {
        return this.isReady() ? void 0 !== this._totalIndices ? this._totalIndices : this._indices.length : 0
      }
      rFO(OO, KO) {
        if (!this.isReady()) return null;
        const pO = this._indices;
        return KO || OO && 1 !== this._meshes.length ? pO.slice() : pO
      }
      getIndexBuffer() {
        return this.isReady() ? this._indexBuffer : null
      }
      _releaseVertexArrayObject() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        OO && this._vertexArrayObjects && this._vertexArrayObjects[OO.key] && (this._engine.releaseVertexArrayObject(this._vertexArrayObjects[OO.key]), delete this._vertexArrayObjects[OO.key])
      }
      releaseForMesh(OO, KO) {
        const pO = this._meshes,
          XO = pO.indexOf(OO); - 1 !== XO && (pO.splice(XO, 1), this._vertexArrayObjects && OO._invalidateInstanceVertexArrayObject(), OO._geometry = null, 0 === pO.length && KO && this.dispose())
      }
      applyToMesh(OO) {
        if (OO._geometry === this) return;
        const KO = OO._geometry;
        KO && KO.releaseForMesh(OO), this._vertexArrayObjects && OO._invalidateInstanceVertexArrayObject();
        const pO = this._meshes;
        OO._geometry = this, OO._internalAbstractMeshDataInfo._positions = null, this._scene.pushGeometry(this), pO.push(OO), this.isReady() ? this._applyToMesh(OO) : this._boundingInfo && OO.setBoundingInfo(this._boundingInfo)
      }
      _updateExtend() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        if (this.useBoundingInfoFromGeometry && this._boundingInfo) this._extend = {
          minimum: this._boundingInfo.minimum.clone(),
          maximum: this._boundingInfo.maximum.clone()
        };
        else {
          if (!OO && (OO = this.getVerticesData(lO.j.PositionKind), !OO)) return;
          this._extend = (0, oO.c)(OO, 0, this._totalVertices, this.boundingBias, 3)
        }
      }
      _applyToMesh(OO) {
        for (const KO in this._vertexBuffers) {
          const pO = this._vertexBuffers[KO];
          pO._buffer.getBuffer() || pO.create(), KO === lO.j.PositionKind && (this._extend || this._updateExtend(), OO.buildBoundingInfo(this._extend.minimum, this._extend.maximum), OO._createGlobalSubMesh(OO.isUnIndexed), OO._updateBoundingInfo())
        }!this._indexBuffer && this._indices && this._indices.length > 0 && (this._indexBuffer = this._engine.createIndexBuffer(this._indices, this._updatable, "Geometry_" + this.id + "_IndexBuffer")), OO._syncGeometryWithMorphTargetManager(), OO.synchronizeInstances()
      }
      _notifyUpdate(OO) {
        this.onGeometryUpdated && this.onGeometryUpdated(this, OO), this._vertexArrayObjects && this._disposeVertexArrayObjects();
        for (const KO of this._meshes) KO._markSubMeshesAsAttributesDirty()
      }
      load(OO, KO) {
        2 !== this.delayLoadState && (this.isReady() ? KO && KO() : (this.delayLoadState = 2, this._queueLoad(OO, KO)))
      }
      _queueLoad(OO, KO) {
        this.delayLoadingFile && (OO.addPendingData(this), (async () => {
          try {
            const pO = await OO._loadDelayedFileAsync(this.delayLoadingFile, !1, !0);
            if (!this._delayLoadingFunction) return void OO.removePendingData(this);
            this._delayLoadingFunction(JSON.parse(pO), this), this.delayLoadState = 1, this._delayInfo = [], OO.removePendingData(this);
            const XO = this._meshes,
              bK = XO.length;
            for (let OO = 0; OO < bK; OO++) this._applyToMesh(XO[OO]);
            KO && KO()
          } catch (pO) {
            OO.removePendingData(this), OO.FhO || MO.b.Error(`Unable to delay load geometry "${this.id}" from "${this.delayLoadingFile}": ${pO}`)
          }
        })())
      }
      toLeftHanded() {
        const OO = this.rFO(!1);
        if (null != OO && OO.length > 0) {
          for (let KO = 0; KO < OO.length; KO += 3) {
            const pO = OO[KO + 0];
            OO[KO + 0] = OO[KO + 2], OO[KO + 2] = pO
          }
          this.setIndices(OO)
        }
        const KO = this.getVerticesData(lO.j.PositionKind, !1);
        if (null != KO && KO.length > 0) {
          for (let OO = 0; OO < KO.length; OO += 3) KO[OO + 2] = -KO[OO + 2];
          this.setVerticesData(lO.j.PositionKind, KO, !1)
        }
        const pO = this.getVerticesData(lO.j.NormalKind, !1);
        if (null != pO && pO.length > 0) {
          for (let OO = 0; OO < pO.length; OO += 3) pO[OO + 2] = -pO[OO + 2];
          this.setVerticesData(lO.j.NormalKind, pO, !1)
        }
      }
      _resetPointsArrayCache() {
        this._positions = null
      }
      _generatePointsArray() {
        if (this._positions) return !0;
        const OO = this.getVerticesData(lO.j.PositionKind);
        if (!OO || 0 === OO.length) return !1;
        for (let KO = 3 * this._positionsCache.length, pO = this._positionsCache.length; KO < OO.length; KO += 3, ++pO) this._positionsCache[pO] = XO.o.FromArray(OO, KO);
        for (let KO = 0, pO = 0; KO < OO.length; KO += 3, ++pO) this._positionsCache[pO].set(OO[0 + KO], OO[1 + KO], OO[2 + KO]);
        return this._positionsCache.length = OO.length / 3, this._positions = this._positionsCache, !0
      }
      FhO() {
        return this._isDisposed
      }
      _disposeVertexArrayObjects() {
        if (this._vertexArrayObjects) {
          for (const pO in this._vertexArrayObjects) this._engine.releaseVertexArrayObject(this._vertexArrayObjects[pO]);
          this._vertexArrayObjects = {};
          const OO = this._meshes,
            KO = OO.length;
          for (let pO = 0; pO < KO; pO++) OO[pO]._invalidateInstanceVertexArrayObject()
        }
      }
      dispose() {
        const OO = this._meshes,
          KO = OO.length;
        let pO;
        for (pO = 0; pO < KO; pO++) this.releaseForMesh(OO[pO]);
        this._meshes.length = 0, this._disposeVertexArrayObjects();
        for (const XO in this._vertexBuffers) this._vertexBuffers[XO].dispose();
        if (this._vertexBuffers = {}, this._totalVertices = 0, this._indexBuffer && this._engine._releaseBuffer(this._indexBuffer), this._indexBuffer = null, this._indices = [], this.delayLoadState = 0, this.delayLoadingFile = null, this._delayLoadingFunction = null, this._delayInfo = [], this._boundingInfo = null, this._scene.removeGeometry(this), this._parentContainer) {
          const OO = this._parentContainer.geometries.indexOf(this);
          OO > -1 && this._parentContainer.geometries.splice(OO, 1), this._parentContainer = null
        }
        this._isDisposed = !0
      }
      copy(OO) {
        const KO = new QO(OO, this._scene),
          pO = this.rFO(void 0, !0);
        pO && KO.setIndices(pO);
        let XO, bK = !1;
        for (XO in this._vertexBuffers) {
          const OO = this.getVertexBuffer(XO),
            pO = OO.getData();
          if (!pO) continue;
          const eO = OO.isUpdatable(),
            vK = OO.getSize(),
            {
              type: CO,
              byteOffset: hO,
              byteStride: DO,
              normalized: MO
            } = OO;
          bK = bK || eO;
          let aK = this._totalVertices;
          if (OO.getIsInstanced()) {
            let OO;
            OO = pO instanceof Array ? 4 * pO.length : pO.byteLength, aK = OO / DO
          }
          const oO = (0, LO.u)(pO, vK, CO, hO, DO, aK, !0),
            FO = new lO.j(this._engine, oO, XO, {
              updatable: eO,
              useBytes: !1,
              stride: vK,
              size: vK,
              offset: 0,
              type: CO,
              normalized: MO,
              takeBufferOwnership: !0,
              instanced: OO.getIsInstanced()
            });
          KO.setVerticesBuffer(FO, aK)
        }
        for (XO in KO._updatable = bK, KO.delayLoadState = this.delayLoadState, KO.delayLoadingFile = this.delayLoadingFile, KO._delayLoadingFunction = this._delayLoadingFunction, this._delayInfo) KO._delayInfo = KO._delayInfo || [], KO._delayInfo.push(XO);
        return KO._boundingInfo = new hO.d(this._extend.minimum, this._extend.maximum), KO
      }
      serialize() {
        const OO = {};
        return OO.id = this.id, OO.uniqueId = this.uniqueId, OO.updatable = this._updatable, aK.b && aK.b.HasTags(this) && (OO.tags = aK.b.GetTags(this)), OO
      }
      _toNumberArray(OO) {
        return Array.isArray(OO) ? OO : Array.prototype.slice.call(OO)
      }
      clearCachedData() {
        this._totalIndices = this._indices.length, this._indices = [], this._resetPointsArrayCache();
        for (const OO in this._vertexBuffers) Object.prototype.hasOwnProperty.call(this._vertexBuffers, OO) && (this._vertexBuffers[OO]._buffer._data = null)
      }
      serializeVerticeData() {
        const OO = this.serialize();
        return this.isVerticesDataPresent(lO.j.PositionKind) && (OO.positions = this._toNumberArray(this.getVerticesData(lO.j.PositionKind)), this.isVertexBufferUpdatable(lO.j.PositionKind) && (OO.positionsUpdatable = !0)), this.isVerticesDataPresent(lO.j.NormalKind) && (OO.normals = this._toNumberArray(this.getVerticesData(lO.j.NormalKind)), this.isVertexBufferUpdatable(lO.j.NormalKind) && (OO.normalsUpdatable = !0)), this.isVerticesDataPresent(lO.j.TangentKind) && (OO.tangents = this._toNumberArray(this.getVerticesData(lO.j.TangentKind)), this.isVertexBufferUpdatable(lO.j.TangentKind) && (OO.tangentsUpdatable = !0)), this.isVerticesDataPresent(lO.j.UVKind) && (OO.uvs = this._toNumberArray(this.getVerticesData(lO.j.UVKind)), this.isVertexBufferUpdatable(lO.j.UVKind) && (OO.uvsUpdatable = !0)), this.isVerticesDataPresent(lO.j.UV2Kind) && (OO.uvs2 = this._toNumberArray(this.getVerticesData(lO.j.UV2Kind)), this.isVertexBufferUpdatable(lO.j.UV2Kind) && (OO.uvs2Updatable = !0)), this.isVerticesDataPresent(lO.j.UV3Kind) && (OO.uvs3 = this._toNumberArray(this.getVerticesData(lO.j.UV3Kind)), this.isVertexBufferUpdatable(lO.j.UV3Kind) && (OO.uvs3Updatable = !0)), this.isVerticesDataPresent(lO.j.UV4Kind) && (OO.uvs4 = this._toNumberArray(this.getVerticesData(lO.j.UV4Kind)), this.isVertexBufferUpdatable(lO.j.UV4Kind) && (OO.uvs4Updatable = !0)), this.isVerticesDataPresent(lO.j.UV5Kind) && (OO.uvs5 = this._toNumberArray(this.getVerticesData(lO.j.UV5Kind)), this.isVertexBufferUpdatable(lO.j.UV5Kind) && (OO.uvs5Updatable = !0)), this.isVerticesDataPresent(lO.j.UV6Kind) && (OO.uvs6 = this._toNumberArray(this.getVerticesData(lO.j.UV6Kind)), this.isVertexBufferUpdatable(lO.j.UV6Kind) && (OO.uvs6Updatable = !0)), this.isVerticesDataPresent(lO.j.ColorKind) && (OO.colors = this._toNumberArray(this.getVerticesData(lO.j.ColorKind)), this.isVertexBufferUpdatable(lO.j.ColorKind) && (OO.colorsUpdatable = !0)), this.isVerticesDataPresent(lO.j.MatricesIndicesKind) && (OO.matricesIndices = this._toNumberArray(this.getVerticesData(lO.j.MatricesIndicesKind)), OO.matricesIndicesExpanded = !0, this.isVertexBufferUpdatable(lO.j.MatricesIndicesKind) && (OO.matricesIndicesUpdatable = !0)), this.isVerticesDataPresent(lO.j.MatricesWeightsKind) && (OO.matricesWeights = this._toNumberArray(this.getVerticesData(lO.j.MatricesWeightsKind)), this.isVertexBufferUpdatable(lO.j.MatricesWeightsKind) && (OO.matricesWeightsUpdatable = !0)), OO.indices = this._toNumberArray(this.rFO()), OO
      }
      static ExtractFromMesh(OO, KO) {
        const pO = OO._geometry;
        return pO ? pO.copy(KO) : null
      }
      static RandomId() {
        return DO.k.RandomId()
      }
      static _GetGeometryByLoadedUniqueId(OO, KO) {
        for (let pO = 0; pO < KO.geometries.length; pO++)
          if (KO.geometries[pO]._loadedUniqueId === OO) return KO.geometries[pO];
        return null
      }
      static _ImportGeometry(OO, KO) {
        const pO = KO.JKO(),
          XO = OO.geometryUniqueId,
          eO = OO.geometryId;
        if (XO || eO) {
          const OO = XO ? this._GetGeometryByLoadedUniqueId(XO, pO) : pO.getGeometryById(eO);
          OO && OO.applyToMesh(KO)
        } else if (OO instanceof ArrayBuffer) {
          const pO = KO._binaryInfo;
          if (pO.positionsAttrDesc && pO.positionsAttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.positionsAttrDesc.offset, pO.positionsAttrDesc.count);
            KO.setVerticesData(lO.j.PositionKind, XO, !1)
          }
          if (pO.normalsAttrDesc && pO.normalsAttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.normalsAttrDesc.offset, pO.normalsAttrDesc.count);
            KO.setVerticesData(lO.j.NormalKind, XO, !1)
          }
          if (pO.tangetsAttrDesc && pO.tangetsAttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.tangetsAttrDesc.offset, pO.tangetsAttrDesc.count);
            KO.setVerticesData(lO.j.TangentKind, XO, !1)
          }
          if (pO.uvsAttrDesc && pO.uvsAttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.uvsAttrDesc.offset, pO.uvsAttrDesc.count);
            if (VO.b)
              for (let OO = 1; OO < XO.length; OO += 2) XO[OO] = 1 - XO[OO];
            KO.setVerticesData(lO.j.UVKind, XO, !1)
          }
          if (pO.uvs2AttrDesc && pO.uvs2AttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.uvs2AttrDesc.offset, pO.uvs2AttrDesc.count);
            if (VO.b)
              for (let OO = 1; OO < XO.length; OO += 2) XO[OO] = 1 - XO[OO];
            KO.setVerticesData(lO.j.UV2Kind, XO, !1)
          }
          if (pO.uvs3AttrDesc && pO.uvs3AttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.uvs3AttrDesc.offset, pO.uvs3AttrDesc.count);
            if (VO.b)
              for (let OO = 1; OO < XO.length; OO += 2) XO[OO] = 1 - XO[OO];
            KO.setVerticesData(lO.j.UV3Kind, XO, !1)
          }
          if (pO.uvs4AttrDesc && pO.uvs4AttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.uvs4AttrDesc.offset, pO.uvs4AttrDesc.count);
            if (VO.b)
              for (let OO = 1; OO < XO.length; OO += 2) XO[OO] = 1 - XO[OO];
            KO.setVerticesData(lO.j.UV4Kind, XO, !1)
          }
          if (pO.uvs5AttrDesc && pO.uvs5AttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.uvs5AttrDesc.offset, pO.uvs5AttrDesc.count);
            if (VO.b)
              for (let OO = 1; OO < XO.length; OO += 2) XO[OO] = 1 - XO[OO];
            KO.setVerticesData(lO.j.UV5Kind, XO, !1)
          }
          if (pO.uvs6AttrDesc && pO.uvs6AttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.uvs6AttrDesc.offset, pO.uvs6AttrDesc.count);
            if (VO.b)
              for (let OO = 1; OO < XO.length; OO += 2) XO[OO] = 1 - XO[OO];
            KO.setVerticesData(lO.j.UV6Kind, XO, !1)
          }
          if (pO.colorsAttrDesc && pO.colorsAttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.colorsAttrDesc.offset, pO.colorsAttrDesc.count);
            KO.setVerticesData(lO.j.ColorKind, XO, !1, pO.colorsAttrDesc.stride)
          }
          if (pO.matricesIndicesAttrDesc && pO.matricesIndicesAttrDesc.count > 0) {
            const XO = new Int32Array(OO, pO.matricesIndicesAttrDesc.offset, pO.matricesIndicesAttrDesc.count),
              bK = [];
            for (let OO = 0; OO < XO.length; OO++) {
              const KO = XO[OO];
              bK.push(255 & KO), bK.push((65280 & KO) >> 8), bK.push((16711680 & KO) >> 16), bK.push(KO >> 24 & 255)
            }
            KO.setVerticesData(lO.j.MatricesIndicesKind, bK, !1)
          }
          if (pO.matricesIndicesExtraAttrDesc && pO.matricesIndicesExtraAttrDesc.count > 0) {
            const XO = new Int32Array(OO, pO.matricesIndicesExtraAttrDesc.offset, pO.matricesIndicesExtraAttrDesc.count),
              bK = [];
            for (let OO = 0; OO < XO.length; OO++) {
              const KO = XO[OO];
              bK.push(255 & KO), bK.push((65280 & KO) >> 8), bK.push((16711680 & KO) >> 16), bK.push(KO >> 24 & 255)
            }
            KO.setVerticesData(lO.j.MatricesIndicesExtraKind, bK, !1)
          }
          if (pO.matricesWeightsAttrDesc && pO.matricesWeightsAttrDesc.count > 0) {
            const XO = new Float32Array(OO, pO.matricesWeightsAttrDesc.offset, pO.matricesWeightsAttrDesc.count);
            KO.setVerticesData(lO.j.MatricesWeightsKind, XO, !1)
          }
          if (pO.indicesAttrDesc && pO.indicesAttrDesc.count > 0) {
            const XO = new Int32Array(OO, pO.indicesAttrDesc.offset, pO.indicesAttrDesc.count);
            KO.setIndices(XO, null)
          }
          if (pO.subMeshesAttrDesc && pO.subMeshesAttrDesc.count > 0) {
            const XO = new Int32Array(OO, pO.subMeshesAttrDesc.offset, 5 * pO.subMeshesAttrDesc.count);
            KO.au = [];
            for (let OO = 0; OO < pO.subMeshesAttrDesc.count; OO++) {
              const pO = XO[5 * OO + 0],
                bK = XO[5 * OO + 1],
                eO = XO[5 * OO + 2],
                lO = XO[5 * OO + 3],
                CO = XO[5 * OO + 4];
              vK.b.AddToMesh(pO, bK, eO, lO, CO, KO)
            }
          }
        } else if (OO.positions && OO.normals && OO.indices) {
          if (KO.setVerticesData(lO.j.PositionKind, OO.positions, OO.positions._updatable || OO.positionsUpdatable), KO.setVerticesData(lO.j.NormalKind, OO.normals, OO.normals._updatable || OO.normalsUpdatable), OO.tangents && KO.setVerticesData(lO.j.TangentKind, OO.tangents, OO.tangents._updatable || OO.tangentsUpdatable), OO.uvs && KO.setVerticesData(lO.j.UVKind, OO.uvs, OO.uvs._updatable || OO.uvsUpdatable), OO.uvs2 && KO.setVerticesData(lO.j.UV2Kind, OO.uvs2, OO.uvs2._updatable || OO.uvs2Updatable), OO.uvs3 && KO.setVerticesData(lO.j.UV3Kind, OO.uvs3, OO.uvs3._updatable || OO.uvs3Updatable), OO.uvs4 && KO.setVerticesData(lO.j.UV4Kind, OO.uvs4, OO.uvs4._updatable || OO.uvs4Updatable), OO.uvs5 && KO.setVerticesData(lO.j.UV5Kind, OO.uvs5, OO.uvs5._updatable || OO.uvs5Updatable), OO.uvs6 && KO.setVerticesData(lO.j.UV6Kind, OO.uvs6, OO.uvs6._updatable || OO.uvs6Updatable), OO.colors && KO.setVerticesData(lO.j.ColorKind, bK.g.CheckColors4(OO.colors, OO.positions.length / 3), OO.colors._updatable), OO.matricesIndices)
            if (OO.matricesIndices._isExpanded || OO.matricesIndicesExpanded) delete OO.matricesIndices._isExpanded, delete OO.matricesIndicesExpanded, KO.setVerticesData(lO.j.MatricesIndicesKind, OO.matricesIndices, OO.matricesIndices._updatable || OO.matricesIndicesUpdatable);
            else {
              const pO = [];
              for (let KO = 0; KO < OO.matricesIndices.length; KO++) {
                const XO = OO.matricesIndices[KO];
                pO.push(255 & XO), pO.push((65280 & XO) >> 8), pO.push((16711680 & XO) >> 16), pO.push(XO >> 24 & 255)
              }
              KO.setVerticesData(lO.j.MatricesIndicesKind, pO, OO.matricesIndices._updatable || OO.matricesIndicesUpdatable)
            } if (OO.matricesIndicesExtra)
            if (OO.matricesIndicesExtraExpanded || OO.matricesIndicesExtra._isExpanded) delete OO.matricesIndices._isExpanded, delete OO.matricesIndicesExtraExpanded, KO.setVerticesData(lO.j.MatricesIndicesExtraKind, OO.matricesIndicesExtra, OO.matricesIndicesExtra._updatable || OO.matricesIndicesExtraUpdatable);
            else {
              const pO = [];
              for (let KO = 0; KO < OO.matricesIndicesExtra.length; KO++) {
                const XO = OO.matricesIndicesExtra[KO];
                pO.push(255 & XO), pO.push((65280 & XO) >> 8), pO.push((16711680 & XO) >> 16), pO.push(XO >> 24 & 255)
              }
              KO.setVerticesData(lO.j.MatricesIndicesExtraKind, pO, OO.matricesIndicesExtra._updatable || OO.matricesIndicesExtraUpdatable)
            } OO.matricesWeights && (QO._CleanMatricesWeights(OO, KO), KO.setVerticesData(lO.j.MatricesWeightsKind, OO.matricesWeights, OO.matricesWeights._updatable)), OO.matricesWeightsExtra && KO.setVerticesData(lO.j.MatricesWeightsExtraKind, OO.matricesWeightsExtra, OO.matricesWeights._updatable), KO.setIndices(OO.indices, null)
        }
        if (OO.au) {
          KO.au = [];
          for (let pO = 0; pO < OO.au.length; pO++) {
            const XO = OO.au[pO];
            vK.b.AddToMesh(XO.materialIndex, XO.verticesStart, XO.verticesCount, XO.indexStart, XO.indexCount, KO)
          }
        }
        KO._shouldGenerateFlatShading && (KO.convertToFlatShadedMesh(), KO._shouldGenerateFlatShading = !1), KO.computeWorldMatrix(!0), pO.onMeshImportedObservable.notifyObservers(KO)
      }
      static _CleanMatricesWeights(OO, KO) {
        const pO = .001;
        if (!CO.d.CleanBoneMatrixWeights) return;
        let XO;
        if (!(OO.skeletonId > -1)) return;
        {
          const pO = KO.JKO().getLastSkeletonById(OO.skeletonId);
          if (!pO) return;
          XO = pO.bones.length
        }
        const bK = KO.getVerticesData(lO.j.MatricesIndicesKind),
          eO = KO.getVerticesData(lO.j.MatricesIndicesExtraKind),
          vK = OO.matricesWeights,
          hO = OO.matricesWeightsExtra,
          DO = OO.numBoneInfluencer,
          MO = vK.length;
        for (let lO = 0; lO < MO; lO += 4) {
          let OO = 0,
            KO = -1;
          for (let XO = 0; XO < 4; XO++) {
            const bK = vK[lO + XO];
            OO += bK, bK < pO && KO < 0 && (KO = XO)
          }
          if (hO)
            for (let XO = 0; XO < 4; XO++) {
              const bK = hO[lO + XO];
              OO += bK, bK < pO && KO < 0 && (KO = XO + 4)
            }
          if ((KO < 0 || KO > DO - 1) && (KO = DO - 1), OO > pO) {
            const KO = 1 / OO;
            for (let OO = 0; OO < 4; OO++) vK[lO + OO] *= KO;
            if (hO)
              for (let OO = 0; OO < 4; OO++) hO[lO + OO] *= KO
          } else KO >= 4 ? (hO[lO + KO - 4] = 1 - OO, eO[lO + KO - 4] = XO) : (vK[lO + KO] = 1 - OO, bK[lO + KO] = XO)
        }
        KO.setVerticesData(lO.j.MatricesIndicesKind, bK), OO.matricesWeightsExtra && KO.setVerticesData(lO.j.MatricesIndicesExtraKind, eO)
      }
      static Parse(OO, KO, pO) {
        const bK = new QO(OO.id, KO, void 0, OO.updatable);
        return bK._loadedUniqueId = OO.uniqueId, aK.b && aK.b.AddTagsTo(bK, OO.tags), OO.delayLoadingFile ? (bK.delayLoadState = 4, bK.delayLoadingFile = pO + OO.delayLoadingFile, bK._boundingInfo = new hO.d(XO.o.FromArray(OO.boundingBoxMinimum), XO.o.FromArray(OO.boundingBoxMaximum)), bK._delayInfo = [], OO.hasUVs && bK._delayInfo.push(lO.j.UVKind), OO.hasUVs2 && bK._delayInfo.push(lO.j.UV2Kind), OO.hasUVs3 && bK._delayInfo.push(lO.j.UV3Kind), OO.hasUVs4 && bK._delayInfo.push(lO.j.UV4Kind), OO.hasUVs5 && bK._delayInfo.push(lO.j.UV5Kind), OO.hasUVs6 && bK._delayInfo.push(lO.j.UV6Kind), OO.hasColors && bK._delayInfo.push(lO.j.ColorKind), OO.hasMatricesIndices && bK._delayInfo.push(lO.j.MatricesIndicesKind), OO.hasMatricesWeights && bK._delayInfo.push(lO.j.MatricesWeightsKind), bK._delayLoadingFunction = eO.e.ImportVertexData) : eO.e.ImportVertexData(OO, bK), KO.pushGeometry(bK, !0), bK
      }
    }
  },
  38568: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => MO,
      f: () => FO
    });
    var XO = pO(35632),
      bK = pO(37061),
      eO = pO(38537),
      lO = pO(38502),
      vK = pO(37055),
      CO = pO(38544),
      hO = pO(38216),
      DO = pO(35676);
    class MO extends eO.d {
      constructor(OO, KO) {
        super(OO, KO.JKO()), this._indexInSourceMeshInstanceArray = -1, this._distanceToCamera = 0, KO.FlO(this), this._sourceMesh = KO, this._unIndexed = KO._unIndexed, this.position.NhO(KO.position), this.rotation.NhO(KO.rotation), this.ol.NhO(KO.ol), KO.rotationQuaternion && (this.rotationQuaternion = KO.rotationQuaternion.clone()), this.animations = KO.animations.slice();
        for (const pO of KO.getAnimationRanges()) null != pO && this.createAnimationRange(pO.name, pO.from, pO.to);
        if (this.infiniteDistance = KO.infiniteDistance, this.setPivotMatrix(KO.getPivotMatrix()), KO.skeleton || KO.morphTargetManager || !KO.hasBoundingInfo) this.refreshBoundingInfo(!0, !0);
        else {
          const OO = KO.hpO();
          this.buildBoundingInfo(OO.minimum, OO.maximum)
        }
        this._syncSubMeshes()
      }
      getClassName() {
        return "InstancedMesh"
      }
      get lightSources() {
        return this._sourceMesh._lightSources
      }
      _resyncLightSources() {}
      _resyncLightSource() {}
      _removeLightSource() {}
      get receiveShadows() {
        return this._sourceMesh.receiveShadows
      }
      set receiveShadows(OO) {
        this._sourceMesh?.receiveShadows !== OO && bK.b.Warn("Setting receiveShadows on an instanced mesh has no effect")
      }
      get material() {
        return this._sourceMesh.material
      }
      set material(OO) {
        this._sourceMesh?.material !== OO && bK.b.Warn("Setting material on an instanced mesh has no effect")
      }
      get visibility() {
        return this._sourceMesh.visibility
      }
      set visibility(OO) {
        this._sourceMesh?.visibility !== OO && bK.b.Warn("Setting visibility on an instanced mesh has no effect")
      }
      get skeleton() {
        return this._sourceMesh.skeleton
      }
      set skeleton(OO) {
        this._sourceMesh?.skeleton !== OO && bK.b.Warn("Setting skeleton on an instanced mesh has no effect")
      }
      get renderingGroupId() {
        return this._sourceMesh.renderingGroupId
      }
      set renderingGroupId(OO) {
        this._sourceMesh && OO !== this._sourceMesh.renderingGroupId && bK.b.Warn("Note - setting renderingGroupId of an instanced mesh has no effect on the scene")
      }
      get meshBlendingTag() {
        return this._sourceMesh.meshBlendingTag
      }
      set meshBlendingTag(OO) {
        this._sourceMesh && OO !== this._sourceMesh.meshBlendingTag && bK.b.Warn("Setting meshBlendingTag on an instanced mesh has no effect")
      }
      getTotalVertices() {
        return this._sourceMesh ? this._sourceMesh.getTotalVertices() : 0
      }
      getTotalIndices() {
        return this._sourceMesh.getTotalIndices()
      }
      get SDO() {
        return this._sourceMesh
      }
      get geometry() {
        return this._sourceMesh._geometry
      }
      createInstance(OO) {
        return this._sourceMesh.createInstance(OO)
      }
      isReady() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        return this._sourceMesh.isReady(OO, !0)
      }
      getVerticesData(OO, KO, pO) {
        return this._sourceMesh.getVerticesData(OO, KO, pO)
      }
      copyVerticesData(OO, KO) {
        this._sourceMesh.copyVerticesData(OO, KO)
      }
      getVertexBuffer(OO, KO) {
        return this._sourceMesh.getVertexBuffer(OO, KO)
      }
      setVerticesData(OO, KO, pO, XO) {
        return this.SDO && this.SDO.setVerticesData(OO, KO, pO, XO), this.SDO
      }
      updateVerticesData(OO, KO, pO, XO) {
        return this.SDO && this.SDO.updateVerticesData(OO, KO, pO, XO), this.SDO
      }
      setIndices(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        return this.SDO && this.SDO.setIndices(OO, KO), this.SDO
      }
      isVerticesDataPresent(OO) {
        return this._sourceMesh.isVerticesDataPresent(OO)
      }
      rFO() {
        return this._sourceMesh.rFO()
      }
      get _positions() {
        return this._sourceMesh._positions
      }
      refreshBoundingInfo() {
        let OO, KO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          pO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (this.hasBoundingInfo && this.hpO().isLocked) return this;
        OO = "object" === typeof KO ? KO : {
          applySkeleton: KO,
          applyMorph: pO
        };
        const XO = this._sourceMesh.geometry ? this._sourceMesh.geometry.boundingBias : null;
        return this._refreshBoundingInfo(this._sourceMesh._getData(OO, null, hO.j.PositionKind), XO), this
      }
      _preActivate() {
        return this._currentLOD && this._currentLOD._preActivate(), this
      }
      _activate(OO, KO) {
        if (super._activate(OO, KO), this._sourceMesh.au || bK.b.Warn("Instances should only be created for meshes with geometry."), this._currentLOD) {
          if (this._currentLOD._getWorldMatrixDeterminant() >= 0 !== this._getWorldMatrixDeterminant() >= 0) return this._internalAbstractMeshDataInfo._actAsRegularMesh = !0, !0;
          if (this._internalAbstractMeshDataInfo._actAsRegularMesh = !1, this._currentLOD._registerInstanceForRenderId(this, OO), KO) {
            if (!this._currentLOD._internalAbstractMeshDataInfo._isActiveIntermediate) return this._currentLOD._internalAbstractMeshDataInfo._onlyForInstancesIntermediate = !0, !0
          } else if (!this._currentLOD._internalAbstractMeshDataInfo._isActive) return this._currentLOD._internalAbstractMeshDataInfo._onlyForInstances = !0, !0
        }
        return !1
      }
      _postActivate() {
        this._sourceMesh.edgesShareWithInstances && this._sourceMesh._edgesRenderer && this._sourceMesh._edgesRenderer.isEnabled && this._sourceMesh._renderingGroup ? (this._sourceMesh._renderingGroup._edgesRenderers.pushNoDuplicate(this._sourceMesh._edgesRenderer), this._sourceMesh._edgesRenderer.customInstances.push(this.getWorldMatrix())) : this._edgesRenderer && this._edgesRenderer.isEnabled && this._sourceMesh._renderingGroup && this._sourceMesh._renderingGroup._edgesRenderers.push(this._edgesRenderer)
      }
      getWorldMatrix() {
        if (this._currentLOD && this._currentLOD !== this._sourceMesh && this._currentLOD.billboardMode !== CO.i.BILLBOARDMODE_NONE && this._currentLOD._masterMesh !== this) {
          this._billboardWorldMatrix || (this._billboardWorldMatrix = new XO.c);
          const OO = this._currentLOD._masterMesh;
          return this._currentLOD._masterMesh = this, XO.j.WX[7].NhO(this._currentLOD.position), this._currentLOD.position.set(0, 0, 0), this._billboardWorldMatrix.NhO(this._currentLOD.computeWorldMatrix(!0)), this._currentLOD.position.NhO(XO.j.WX[7]), this._currentLOD._masterMesh = OO, this._billboardWorldMatrix
        }
        return super.getWorldMatrix()
      }
      get BKO() {
        return !0
      }
      getLOD(OO) {
        if (!OO) return this;
        const KO = this.SDO.getLODLevels();
        if (KO && 0 !== KO.length) {
          const KO = this.hpO();
          this._currentLOD = this.SDO.getLOD(OO, KO.QDO)
        } else this._currentLOD = this.SDO;
        return this._currentLOD
      }
      _preActivateForIntermediateRendering(OO) {
        return this.SDO._preActivateForIntermediateRendering(OO)
      }
      _syncSubMeshes() {
        if (this.releaseSubMeshes(), this._sourceMesh.au)
          for (let OO = 0; OO < this._sourceMesh.au.length; OO++) this._sourceMesh.au[OO].clone(this, this._sourceMesh);
        return this
      }
      _generatePointsArray() {
        return this._sourceMesh._generatePointsArray()
      }
      _updateBoundingInfo() {
        return this.hasBoundingInfo ? this.hpO().update(this.worldMatrixFromCache) : this.buildBoundingInfo(this.absolutePosition, this.absolutePosition, this.worldMatrixFromCache), this._updateSubMeshesBoundingInfo(this.worldMatrixFromCache), this
      }
      clone(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const XO = ((arguments.length > 3 ? arguments[3] : void 0) || this._sourceMesh).createInstance(OO);
        if (vK.d.DeepCopy(this, XO, ["name", "au", "uniqueId", "parent", "lightSources", "receiveShadows", "material", "visibility", "skeleton", "SDO", "BKO", "facetNb", "isFacetDataEnabled", "isBlocked", "useBones", "RDO", "collider", "edgesRenderer", "forward", "up", "right", "absolutePosition", "absoluteScaling", "absoluteRotationQuaternion", "JoO", "nonUniformScaling", "behaviors", "worldMatrixFromCache", "hasThinInstances", "hasBoundingInfo", "geometry"], []), KO && (XO.parent = KO), !pO)
          for (let bK = 0; bK < this.JKO().meshes.length; bK++) {
            const OO = this.JKO().meshes[bK];
            OO.parent === this && OO.clone(OO.name, XO)
          }
        return XO.computeWorldMatrix(!0), this.onClonedObservable.notifyObservers(XO), XO
      }
      dispose(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        this._sourceMesh.zvO(this), super.dispose(OO, KO)
      }
      _serializeAsParent(OO) {
        super._serializeAsParent(OO), OO.parentId = this._sourceMesh.uniqueId, OO.parentInstanceIndex = this._indexInSourceMeshInstanceArray
      }
      instantiateHierarchy() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const XO = this.clone("Clone of " + (this.name || this.id), OO || this.parent, !0, KO && KO.newSourcedMesh);
        XO && pO && pO(this, XO);
        for (const bK of this.getChildTransformNodes(!0)) bK.instantiateHierarchy(XO, KO, pO);
        return XO
      }
    }
    let aK = !1;

    function oO(OO, KO, pO, XO, bK) {
      for (let eO = 0; eO < KO.length; eO++) {
        const lO = OO[KO[eO]] ?? 0,
          vK = bK + pO[eO];
        lO.toArray ? lO.toArray(XO, vK) : lO.copyToArray ? lO.copyToArray(XO, vK) : XO[vK] = lO
      }
    }

    function FO() {
      aK || (aK = !0, lO.c._instancedMeshFactory = (OO, KO) => {
        const pO = new MO(OO, KO);
        if (KO.lpO) {
          pO.lpO = {};
          for (const OO in KO.lpO) pO.lpO[OO] = KO.lpO[OO]
        }
        return pO
      }, lO.c.prototype.epO = function(OO, KO) {
        if (!this.lpO) {
          this.lpO = {};
          for (const OO of this.instances) OO.lpO = {}
        }
        this._userInstancedBuffersStorage || (this._userInstancedBuffersStorage = {
          data: {},
          vertexBuffers: {},
          strides: {},
          sizes: {},
          vertexArrayObjects: this.qb().getCaps().vertexArrayObject ? {} : void 0
        }), this.lpO[OO] = null, this._userInstancedBuffersStorage.strides[OO] = KO;
        const pO = this._userInstancedBuffersStorage;
        pO.interleavedKinds = [], pO.interleavedOffsets = [], pO.interleavedRowStride = 0;
        for (const XO in pO.strides) pO.interleavedKinds.push(XO), pO.interleavedOffsets.push(pO.interleavedRowStride), pO.interleavedRowStride += pO.strides[XO];
        pO.interleavedData = new Float32Array(32 * pO.interleavedRowStride);
        for (const XO in pO.interleavedBuffers) pO.interleavedBuffers[XO].buffer.dispose();
        pO.interleavedBuffers = {}, pO.vertexBuffers[OO] = null;
        for (const XO of this.instances) XO.lpO[OO] = null;
        this._invalidateInstanceVertexArrayObject(), this._markSubMeshesAsAttributesDirty()
      }, lO.c.prototype._processInstancedBuffers = function(OO, KO) {
        const pO = this._userInstancedBuffersStorage,
          XO = pO.interleavedRowStride;
        if (!XO) return;
        const bK = OO ? OO.length : 0,
          eO = (bK + 1) * XO;
        let lO = pO.interleavedData;
        if (lO.length < eO) {
          let OO = lO.length;
          for (; OO < eO;) OO *= 2;
          lO = pO.interleavedData = new Float32Array(OO)
        }
        const vK = pO.interleavedKinds,
          CO = pO.interleavedOffsets;
        let DO = 0;
        KO && (oO(this.lpO, vK, CO, lO, DO), DO += XO);
        for (let hO = 0; hO < bK; hO++) oO(OO[hO].lpO, vK, CO, lO, DO), DO += XO;
        let MO = "shared",
          aK = pO.vertexBuffers;
        this._instanceDataStorage.useMonoDataStorageRenderPass || (MO = this._instanceDataStorage.engine.currentRenderPassId, pO.renderPasses || (pO.renderPasses = {}), pO.renderPasses[MO] || (pO.renderPasses[MO] = {}), aK = pO.renderPasses[MO]);
        const FO = pO.interleavedBuffers[MO];
        let VO = !FO || FO.data !== lO;
        for (let hO = 0; !VO && hO < vK.length; hO++) VO = !aK[vK[hO]];
        if (!VO) return void FO.buffer.updateDirectly(lO, 0);
        FO?.buffer.dispose();
        const LO = new hO.b(this.qb(), lO, !0, XO, !1, !0);
        for (let hO = 0; hO < vK.length; hO++) {
          const OO = vK[hO],
            KO = LO.createVertexBuffer(OO, CO[hO], pO.strides[OO]);
          KO.hashCode += KO.byteOffset * 2 ** 24, aK[OO] = KO
        }
        pO.interleavedBuffers[MO] = {
          buffer: LO,
          data: lO
        }, this._invalidateInstanceVertexArrayObject()
      }, lO.c.prototype._invalidateInstanceVertexArrayObject = function() {
        if (this._userInstancedBuffersStorage && void 0 !== this._userInstancedBuffersStorage.vertexArrayObjects) {
          for (const OO in this._userInstancedBuffersStorage.vertexArrayObjects) this.qb().releaseVertexArrayObject(this._userInstancedBuffersStorage.vertexArrayObjects[OO]);
          this._userInstancedBuffersStorage.vertexArrayObjects = {}
        }
      }, lO.c.prototype._disposeInstanceSpecificData = function() {
        for (const KO in this._instanceDataStorage.renderPasses) this._instanceDataStorage.renderPasses[KO].instancesBuffer?.dispose();
        for (this._instanceDataStorage.renderPasses = {}, this._instanceDataStorage.dataStorageRenderPass?.instancesBuffer?.dispose(); this.instances.length;) this.instances[0].dispose();
        for (const KO in this.lpO) this._userInstancedBuffersStorage.vertexBuffers[KO] && this._userInstancedBuffersStorage.vertexBuffers[KO].dispose();
        const OO = this._userInstancedBuffersStorage?.interleavedBuffers;
        if (OO) {
          for (const KO in OO) OO[KO].buffer.dispose();
          this._userInstancedBuffersStorage.interleavedBuffers = {}
        }
        this._invalidateInstanceVertexArrayObject(), this.lpO = {}
      }, (0, DO.h)("BABYLON.InstancedMesh", MO))
    }
  },
  38502: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => tK,
      f: () => UO,
      g: () => BO
    });
    var XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO, QO = pO(35660),
      zK = pO(38172),
      AO = pO(38104),
      fO = pO(37055),
      dO = pO(38085),
      TO = pO(38506),
      NO = pO(38294),
      IO = pO(35632),
      yK = pO(35688),
      gK = pO(38301),
      uO = pO(38216),
      EO = pO(38511),
      jK = pO(38517),
      YO = pO(38537),
      wO = pO(38388),
      iK = pO(38382),
      rK = pO(38471),
      PO = pO(38552),
      mK = pO(38521),
      sO = pO(38077),
      HO = pO(37061),
      RO = pO(35676),
      SO = pO(37938),
      JO = pO(38250);
    class cK {
      constructor(OO, KO) {
        this.distanceOrScreenCoverage = OO, this.mesh = KO
      }
    }
    class BO {}
    class ZO {
      constructor() {
        this.batchCache = new qK(this), this.batchCacheReplacementModeInFrozenMode = new qK(this), this.instancesBufferSize = 2048
      }
    }
    class GO {
      constructor() {
        this.renderPasses = {}
      }
    }
    class qK {
      constructor(OO) {
        this.parent = OO, this.mustReturn = !1, this.visibleInstances = new Array, this.renderSelf = [], this.hardwareInstancedRendering = []
      }
    }
    class xK {
      constructor() {
        this.instancesCount = 0, this.matrixBuffer = null, this.previousMatrixBuffer = null, this.matrixBufferSize = 512, this.matrixData = null, this.boundingVectors = [], this.worldMatrices = null
      }
    }
    class nO {
      constructor() {
        this._areNormalsFrozen = !1, this._source = null, this.meshMap = null, this._preActivateId = -1, this._LODLevels = new Array, this._useLODScreenCoverage = !1, this._effectiveMaterial = null, this._forcedInstanceCount = 0, this._overrideRenderingFillMode = null
      }
    }
    const WO = {
      source: null,
      parent: null,
      doNotCloneChildren: !1,
      clonePhysicsImpostor: !0,
      cloneThinInstances: !1
    };
    class tK extends YO.d {
      static _GetDefaultSideOrientation(OO) {
        return OO || tK.FRONTSIDE
      }
      get useLODScreenCoverage() {
        return this._internalMeshDataInfo._useLODScreenCoverage
      }
      set useLODScreenCoverage(OO) {
        this._internalMeshDataInfo._useLODScreenCoverage = OO, this._sortLODLevels()
      }
      get computeBonesUsingShaders() {
        return this._internalAbstractMeshDataInfo._computeBonesUsingShaders
      }
      set computeBonesUsingShaders(OO) {
        this._internalAbstractMeshDataInfo._computeBonesUsingShaders !== OO && (OO && this._internalMeshDataInfo._sourcePositions && (this.setVerticesData(uO.j.PositionKind, this._internalMeshDataInfo._sourcePositions, !0), this._internalMeshDataInfo._sourceNormals && this.setVerticesData(uO.j.NormalKind, this._internalMeshDataInfo._sourceNormals, !0), this._internalMeshDataInfo._sourcePositions = null, this._internalMeshDataInfo._sourceNormals = null), this._internalAbstractMeshDataInfo._computeBonesUsingShaders = OO, this._markSubMeshesAsAttributesDirty())
      }
      get onBeforeRenderObservable() {
        return this._internalMeshDataInfo._onBeforeRenderObservable || (this._internalMeshDataInfo._onBeforeRenderObservable = new QO.e), this._internalMeshDataInfo._onBeforeRenderObservable
      }
      get onBeforeBindObservable() {
        return this._internalMeshDataInfo._onBeforeBindObservable || (this._internalMeshDataInfo._onBeforeBindObservable = new QO.e), this._internalMeshDataInfo._onBeforeBindObservable
      }
      get onAfterRenderObservable() {
        return this._internalMeshDataInfo._onAfterRenderObservable || (this._internalMeshDataInfo._onAfterRenderObservable = new QO.e), this._internalMeshDataInfo._onAfterRenderObservable
      }
      get onBetweenPassObservable() {
        return this._internalMeshDataInfo._onBetweenPassObservable || (this._internalMeshDataInfo._onBetweenPassObservable = new QO.e), this._internalMeshDataInfo._onBetweenPassObservable
      }
      get onBeforeDrawObservable() {
        return this._internalMeshDataInfo._onBeforeDrawObservable || (this._internalMeshDataInfo._onBeforeDrawObservable = new QO.e), this._internalMeshDataInfo._onBeforeDrawObservable
      }
      set onBeforeDraw(OO) {
        this._onBeforeDrawObserver && this.onBeforeDrawObservable.remove(this._onBeforeDrawObserver), this._onBeforeDrawObserver = this.onBeforeDrawObservable.add(OO)
      }
      get RDO() {
        return this.instances.length > 0
      }
      get hasThinInstances() {
        return (this.forcedInstanceCount || this._thinInstanceDataStorage.instancesCount || 0) > 0
      }
      get forcedInstanceCount() {
        return this._internalMeshDataInfo._forcedInstanceCount
      }
      set forcedInstanceCount(OO) {
        this._internalMeshDataInfo._forcedInstanceCount = OO
      }
      get sideOrientation() {
        return this._internalMeshDataInfo._sideOrientation
      }
      set sideOrientation(OO) {
        this._internalMeshDataInfo._sideOrientation = OO, this._internalAbstractMeshDataInfo._sideOrientationHint = this._scene.useRightHandedSystem && 1 === OO || !this._scene.useRightHandedSystem && 0 === OO
      }
      get _effectiveSideOrientation() {
        return this._internalMeshDataInfo._effectiveSideOrientation
      }
      get overrideMaterialSideOrientation() {
        return this.sideOrientation
      }
      set overrideMaterialSideOrientation(OO) {
        this.sideOrientation = OO, this.material && (this.material.sideOrientation = null)
      }
      get overrideRenderingFillMode() {
        return this._internalMeshDataInfo._overrideRenderingFillMode
      }
      set overrideRenderingFillMode(OO) {
        this._internalMeshDataInfo._overrideRenderingFillMode = OO
      }
      get material() {
        return this._internalAbstractMeshDataInfo._material
      }
      set material(OO) {
        OO && (this.material && null === this.material.sideOrientation || this._internalAbstractMeshDataInfo._sideOrientationHint) && (OO.sideOrientation = null), this._setMaterial(OO)
      }
      get source() {
        return this._internalMeshDataInfo._source
      }
      get cloneMeshMap() {
        return this._internalMeshDataInfo.meshMap
      }
      get isUnIndexed() {
        return this._unIndexed
      }
      set isUnIndexed(OO) {
        this._unIndexed !== OO && (this._unIndexed = OO, this._markSubMeshesAsAttributesDirty())
      }
      get worldMatrixInstancedBuffer() {
        const OO = this._instanceDataStorage.useMonoDataStorageRenderPass ? this._instanceDataStorage.dataStorageRenderPass : this._instanceDataStorage.renderPasses[this._instanceDataStorage.engine.currentRenderPassId];
        return OO ? OO.instancesData : void 0
      }
      get previousWorldMatrixInstancedBuffer() {
        const OO = this._instanceDataStorage.useMonoDataStorageRenderPass ? this._instanceDataStorage.dataStorageRenderPass : this._instanceDataStorage.renderPasses[this._instanceDataStorage.engine.currentRenderPassId];
        return OO ? OO.instancesPreviousData : void 0
      }
      get manualUpdateOfWorldMatrixInstancedBuffer() {
        return this._instanceDataStorage.manualUpdate
      }
      set manualUpdateOfWorldMatrixInstancedBuffer(OO) {
        this._instanceDataStorage.manualUpdate = OO
      }
      get manualUpdateOfPreviousWorldMatrixInstancedBuffer() {
        return this._instanceDataStorage.previousManualUpdate
      }
      set manualUpdateOfPreviousWorldMatrixInstancedBuffer(OO) {
        this._instanceDataStorage.previousManualUpdate = OO
      }
      get forceWorldMatrixInstancedBufferUpdate() {
        return this._instanceDataStorage.forceMatrixUpdates
      }
      set forceWorldMatrixInstancedBufferUpdate(OO) {
        this._instanceDataStorage.forceMatrixUpdates = OO
      }
      _copySource(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        const bK = this.JKO();
        if (OO._geometry && OO._geometry.applyToMesh(this), fO.d.DeepCopy(OO, this, ["name", "material", "skeleton", "instances", "parent", "uniqueId", "source", "metadata", "morphTargetManager", "RDO", "worldMatrixInstancedBuffer", "previousWorldMatrixInstancedBuffer", "hasLODLevels", "geometry", "isBlocked", "areNormalsFrozen", "facetNb", "isFacetDataEnabled", "lightSources", "useBones", "BKO", "collider", "edgesRenderer", "forward", "up", "right", "absolutePosition", "absoluteScaling", "absoluteRotationQuaternion", "JoO", "nonUniformScaling", "behaviors", "worldMatrixFromCache", "hasThinInstances", "cloneMeshMap", "hasBoundingInfo", "physicsBody", "physicsImpostor"], ["_poseMatrix"]), this._internalMeshDataInfo._source = OO, bK.useClonedMeshMap && (OO._internalMeshDataInfo.meshMap || (OO._internalMeshDataInfo.meshMap = {}), OO._internalMeshDataInfo.meshMap[this.uniqueId] = this), this._originalBuilderSideOrientation = OO._originalBuilderSideOrientation, this._creationDataStorage = OO._creationDataStorage, OO._ranges) {
          const KO = OO._ranges;
          for (const OO in KO) Object.prototype.hasOwnProperty.call(KO, OO) && KO[OO] && this.createAnimationRange(OO, KO[OO].from, KO[OO].to)
        }
        if (OO.metadata && OO.metadata.clone ? this.metadata = OO.metadata.clone() : this.metadata = OO.metadata, this._internalMetadata = OO._internalMetadata, this.meshBlendingTag = OO.meshBlendingTag, dO.b && dO.b.HasTags(OO) && dO.b.AddTagsTo(this, dO.b.GetTags(OO, !0)), this.WE(OO.isEnabled(!1)), this.parent = OO.parent, this.setPivotMatrix(OO.getPivotMatrix(), this._postMultiplyPivotMatrix), this.id = this.name + "." + OO.id, this.material = OO.material, !KO) {
          const bK = OO.getDescendants(!0);
          for (let OO = 0; OO < bK.length; OO++) {
            const eO = bK[OO];
            eO._isMesh ? (WO.parent = this, WO.doNotCloneChildren = KO, WO.clonePhysicsImpostor = pO, WO.cloneThinInstances = XO, eO.clone(this.name + "." + eO.name, WO)) : eO.clone && eO.clone(this.name + "." + eO.name, this)
          }
        }
        if (OO.morphTargetManager && (this.morphTargetManager = OO.morphTargetManager), (0, SO.b)(bK.getPhysicsEngine)) {
          const KO = bK.getPhysicsEngine();
          if (pO && KO)
            if (1 === KO.getPluginVersion()) {
              const pO = KO.getImpostorForPhysicsObject(OO);
              pO && (this.physicsImpostor = pO.clone(this))
            } else 2 === KO.getPluginVersion() && OO.physicsBody && OO.physicsBody.clone(this)
        }
        for (let eO = 0; eO < bK.ku.length; eO++) {
          const KO = bK.ku[eO];
          KO.emitter === OO && KO.clone(KO.name, this)
        }
        if (this.skeleton = OO.skeleton, XO && (OO._thinInstanceDataStorage.matrixData ? (this.ulO("matrix", new Float32Array(OO._thinInstanceDataStorage.matrixData), 16, !OO._thinInstanceDataStorage.matrixBuffer.isUpdatable()), this._thinInstanceDataStorage.matrixBufferSize = OO._thinInstanceDataStorage.matrixBufferSize, this._thinInstanceDataStorage.instancesCount = OO._thinInstanceDataStorage.instancesCount) : this._thinInstanceDataStorage.matrixBufferSize = OO._thinInstanceDataStorage.matrixBufferSize, OO._userThinInstanceBuffersStorage)) {
          const KO = OO._userThinInstanceBuffersStorage;
          for (const OO in KO.data) this.ulO(OO, new Float32Array(KO.data[OO]), KO.strides[OO], !KO.vertexBuffers?.[OO]?.isUpdatable()), this._userThinInstanceBuffersStorage.sizes[OO] = KO.sizes[OO]
        }
        this.refreshBoundingInfo(!0, !0), this.computeWorldMatrix(!0)
      }
      constructor(OO) {
        let KO, pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
          eO = arguments.length > 4 ? arguments[4] : void 0,
          lO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5];
        super(OO, pO), this._internalMeshDataInfo = new nO, this.delayLoadState = 0, this.instances = [], this._creationDataStorage = null, this._geometry = null, this._thinInstanceDataStorage = new xK, this._shouldGenerateFlatShading = !1, this._originalBuilderSideOrientation = tK.DEFAULTSIDE, this.ignoreCameraMaxZ = !1, pO = this.JKO(), this._instanceDataStorage = new GO, this._instanceDataStorage.engine = pO.qb(), this._instanceDataStorage.useMonoDataStorageRenderPass = !this._instanceDataStorage.engine.isWebGPU, this._instanceDataStorage.useMonoDataStorageRenderPass && (this._instanceDataStorage.dataStorageRenderPass = new ZO), this._scene.useRightHandedSystem ? this.sideOrientation = 0 : this.sideOrientation = 1, this._onBeforeDraw = (OO, KO, pO) => {
          OO && pO && (this._uniformBuffer ? this.transferToEffect(KO) : pO.bindOnlyWorldMatrix(KO))
        };
        let vK = !1;
        if (XO && void 0 === XO._addToSceneRootNodes) {
          const OO = XO;
          KO = OO.parent ?? null, bK = OO.source ?? null, eO = OO.doNotCloneChildren ?? !1, lO = OO.clonePhysicsImpostor ?? !0, vK = OO.cloneThinInstances ?? !1
        } else KO = XO;
        bK && this._copySource(bK, eO, lO, vK), null !== KO && (this.parent = KO), this._instanceDataStorage.hardwareInstancedRendering = this.qb().getCaps().instancedArrays, this._internalMeshDataInfo._onMeshReadyObserverAdded = OO => {
          OO.unregisterOnNextCall = !0, this.isReady(!0) ? this.onMeshReadyObservable.notifyObservers(this) : this._internalMeshDataInfo._checkReadinessObserver || (this._internalMeshDataInfo._checkReadinessObserver = this._scene.onBeforeRenderObservable.add((() => {
            this.isReady(!0) && (this._scene.onBeforeRenderObservable.remove(this._internalMeshDataInfo._checkReadinessObserver), this._internalMeshDataInfo._checkReadinessObserver = null, this.onMeshReadyObservable.notifyObservers(this))
          })))
        }, this.onMeshReadyObservable = new QO.e(this._internalMeshDataInfo._onMeshReadyObserverAdded), bK && bK.onClonedObservable.notifyObservers(this)
      }
      instantiateHierarchy() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const XO = 0 === this.getTotalVertices() || KO && KO.doNotInstantiate && (!0 === KO.doNotInstantiate || KO.doNotInstantiate(this)) ? this.clone("Clone of " + (this.name || this.id), OO || this.parent, !0) : this.createInstance("instance of " + (this.name || this.id));
        XO.parent = OO || this.parent, XO.position = this.position.clone(), XO.ol = this.ol.clone(), this.rotationQuaternion ? XO.rotationQuaternion = this.rotationQuaternion.clone() : XO.rotation = this.rotation.clone(), pO && pO(this, XO);
        for (const bK of this.getChildTransformNodes(!0)) "InstancedMesh" === bK.getClassName() && "Mesh" === XO.getClassName() && bK.SDO === this ? bK.instantiateHierarchy(XO, {
          doNotInstantiate: KO && KO.doNotInstantiate || !1,
          newSourcedMesh: XO
        }, pO) : bK.instantiateHierarchy(XO, KO, pO);
        return XO
      }
      getClassName() {
        return "Mesh"
      }
      get _isMesh() {
        return !0
      }
      toString(OO) {
        let KO = super.toString(OO);
        if (KO += ", n vertices: " + this.getTotalVertices(), KO += ", parent: " + (this._waitingParentId ? this._waitingParentId : this.parent ? this.parent.name : "NONE"), this.animations)
          for (let pO = 0; pO < this.animations.length; pO++) KO += ", animation[0]: " + this.animations[pO].toString(OO);
        if (OO)
          if (this._geometry) {
            const OO = this.rFO(),
              pO = this.getVerticesData(uO.j.PositionKind);
            pO && OO && (KO += ", flat shading: " + (pO.length / 3 === OO.length ? "YES" : "NO"))
          } else KO += ", flat shading: UNKNOWN";
        return KO
      }
      _unBindEffect() {
        super._unBindEffect();
        for (const OO of this.instances) OO._unBindEffect()
      }
      get hasLODLevels() {
        return this._internalMeshDataInfo._LODLevels.length > 0
      }
      getLODLevels() {
        return this._internalMeshDataInfo._LODLevels
      }
      _sortLODLevels() {
        const OO = this._internalMeshDataInfo._useLODScreenCoverage ? -1 : 1;
        this._internalMeshDataInfo._LODLevels.sort(((KO, pO) => KO.distanceOrScreenCoverage < pO.distanceOrScreenCoverage ? OO : KO.distanceOrScreenCoverage > pO.distanceOrScreenCoverage ? -OO : 0))
      }
      addLODLevel(OO, KO) {
        if (KO && KO._masterMesh) return HO.b.Warn("You cannot use a mesh as LOD level twice"), this;
        const pO = new cK(OO, KO);
        return this._internalMeshDataInfo._LODLevels.push(pO), KO && (KO._masterMesh = this), this._sortLODLevels(), this
      }
      getLODLevelAtDistance(OO) {
        const KO = this._internalMeshDataInfo;
        for (let pO = 0; pO < KO._LODLevels.length; pO++) {
          const XO = KO._LODLevels[pO];
          if (XO.distanceOrScreenCoverage === OO) return XO.mesh
        }
        return null
      }
      removeLODLevel(OO) {
        const KO = this._internalMeshDataInfo;
        for (let pO = 0; pO < KO._LODLevels.length; pO++) KO._LODLevels[pO].mesh === OO && (KO._LODLevels.splice(pO, 1), OO && (OO._masterMesh = null));
        return this._sortLODLevels(), this
      }
      getLOD(OO, KO) {
        const pO = this._internalMeshDataInfo;
        if (!pO._LODLevels || 0 === pO._LODLevels.length) return this;
        const XO = KO || this.hpO().QDO,
          bK = OO.mode === NO.c.ORTHOGRAPHIC_CAMERA ? OO.minZ : XO.centerWorld.subtract(OO.globalPosition).length();
        let eO = bK,
          lO = 1;
        if (pO._useLODScreenCoverage) {
          const KO = OO.screenArea;
          let pO = XO.radiusWorld * OO.minZ / bK;
          pO = pO * pO * Math.PI, eO = pO / KO, lO = -1
        }
        if (lO * pO._LODLevels[pO._LODLevels.length - 1].distanceOrScreenCoverage > lO * eO) return this.onLODLevelSelection && this.onLODLevelSelection(eO, this, this), this;
        for (let vK = 0; vK < pO._LODLevels.length; vK++) {
          const OO = pO._LODLevels[vK];
          if (lO * OO.distanceOrScreenCoverage < lO * eO) {
            if (OO.mesh) {
              if (4 === OO.mesh.delayLoadState) return OO.mesh._checkDelayState(), this;
              if (2 === OO.mesh.delayLoadState) return this;
              OO.mesh._preActivate(), OO.mesh._updateSubMeshesBoundingInfo(this.worldMatrixFromCache)
            }
            return this.onLODLevelSelection && this.onLODLevelSelection(eO, this, OO.mesh), OO.mesh
          }
        }
        return this.onLODLevelSelection && this.onLODLevelSelection(eO, this, this), this
      }
      get geometry() {
        return this._geometry
      }
      getTotalVertices() {
        return null === this._geometry || void 0 === this._geometry ? 0 : this._geometry.getTotalVertices()
      }
      getVerticesData(OO, KO, pO, XO) {
        if (!this._geometry) return null;
        let bK = XO ? void 0 : this._userInstancedBuffersStorage?.vertexBuffers[OO]?.getFloatData(this.instances.length + 1, pO || KO && 1 !== this._geometry.meshes.length);
        return bK || (bK = this._geometry.getVerticesData(OO, KO, pO)), bK
      }
      copyVerticesData(OO, KO) {
        this._geometry && this._geometry.copyVerticesData(OO, KO)
      }
      getVertexBuffer(OO, KO) {
        return this._geometry ? (KO ? void 0 : this._userInstancedBuffersStorage?.vertexBuffers[OO]) ?? this._geometry.getVertexBuffer(OO) : null
      }
      isVerticesDataPresent(OO, KO) {
        return this._geometry ? !KO && void 0 !== this._userInstancedBuffersStorage?.vertexBuffers[OO] || this._geometry.isVerticesDataPresent(OO) : !!this._delayInfo && -1 !== this._delayInfo.indexOf(OO)
      }
      isVertexBufferUpdatable(OO, KO) {
        if (!this._geometry) return !!this._delayInfo && -1 !== this._delayInfo.indexOf(OO);
        if (!KO) {
          const KO = this._userInstancedBuffersStorage?.vertexBuffers[OO];
          if (KO) return KO.isUpdatable()
        }
        return this._geometry.isVertexBufferUpdatable(OO)
      }
      getVerticesDataKinds(OO) {
        if (!this._geometry) {
          const OO = [];
          if (this._delayInfo)
            for (const KO of this._delayInfo) OO.push(KO);
          return OO
        }
        const KO = this._geometry.getVerticesDataKinds();
        if (!OO && this._userInstancedBuffersStorage)
          for (const pO in this._userInstancedBuffersStorage.vertexBuffers) - 1 === KO.indexOf(pO) && KO.push(pO);
        return KO
      }
      getTotalIndices() {
        return this._geometry ? this._geometry.getTotalIndices() : 0
      }
      rFO(OO, KO) {
        return this._geometry ? this._geometry.rFO(OO, KO) : []
      }
      get isBlocked() {
        return null !== this._masterMesh && void 0 !== this._masterMesh
      }
      isReady() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (2 === this.delayLoadState) return !1;
        if (!super.isReady(OO)) return !1;
        if (!this.au || 0 === this.au.length) return !0;
        if (!OO) return !0;
        const pO = this.qb(),
          XO = this.JKO(),
          bK = KO || pO.getCaps().instancedArrays && (this.instances.length > 0 || this.hasThinInstances);
        this.computeWorldMatrix();
        const eO = this.material || XO.defaultMaterial;
        if (eO)
          if (eO._storeEffectOnSubMeshes)
            for (const vK of this.au) {
              const OO = vK.UX();
              if (OO)
                if (OO._storeEffectOnSubMeshes) {
                  if (!OO.isReadyForSubMesh(this, vK, bK)) return !1
                } else if (!OO.isReady(this, bK)) return !1
            } else if (!eO.isReady(this, bK)) return !1;
        const lO = pO.currentRenderPassId;
        for (const vK of this.lightSources) {
          const OO = vK.getShadowGenerators();
          if (!OO) continue;
          const KO = OO.values();
          for (let XO = KO.next(); !0 !== XO.done; XO = KO.next()) {
            const OO = XO.value;
            if (OO && (!OO.getShadowMap()?.renderList || OO.getShadowMap()?.renderList && -1 !== OO.getShadowMap()?.renderList?.indexOf(this))) {
              const KO = OO.getShadowMap().renderPassIds ?? [pO.currentRenderPassId];
              for (let XO = 0; XO < KO.length; ++XO) {
                pO.currentRenderPassId = KO[XO];
                for (const KO of this.au)
                  if (!OO.isReady(KO, bK, KO.UX()?.needAlphaBlendingForMesh(this) ?? !1)) return pO.currentRenderPassId = lO, !1
              }
              pO.currentRenderPassId = lO
            }
          }
        }
        for (const vK of this._internalMeshDataInfo._LODLevels)
          if (vK.mesh && !vK.mesh.isReady(bK)) return !1;
        return !0
      }
      get areNormalsFrozen() {
        return this._internalMeshDataInfo._areNormalsFrozen
      }
      Ob() {
        return this._internalMeshDataInfo._areNormalsFrozen = !0, this
      }
      unfreezeNormals() {
        return this._internalMeshDataInfo._areNormalsFrozen = !1, this
      }
      set overridenInstanceCount(OO) {
        this._instanceDataStorage.overridenInstanceCount = OO
      }
      _getInstanceDataStorage() {
        if (this._instanceDataStorage.useMonoDataStorageRenderPass) return this._instanceDataStorage.dataStorageRenderPass;
        const OO = this._instanceDataStorage.engine.currentRenderPassId;
        let KO = this._instanceDataStorage.renderPasses[OO];
        return KO || (KO = new ZO, this._instanceDataStorage.renderPasses[OO] = KO), KO
      }
      _preActivate() {
        const OO = this._internalMeshDataInfo,
          KO = this.JKO().getRenderId();
        return OO._preActivateId === KO || (OO._preActivateId = KO, this._instanceDataStorage.useMonoDataStorageRenderPass ? this._instanceDataStorage.dataStorageRenderPass.visibleInstances = null : this._getInstanceDataStorage().visibleInstances = null), this
      }
      _preActivateForIntermediateRendering(OO) {
        const KO = this._instanceDataStorage.useMonoDataStorageRenderPass ? this._instanceDataStorage.dataStorageRenderPass : this._getInstanceDataStorage();
        return KO.visibleInstances && (KO.visibleInstances.intermediateDefaultRenderId = OO), this
      }
      _registerInstanceForRenderId(OO, KO) {
        const pO = this._instanceDataStorage.useMonoDataStorageRenderPass ? this._instanceDataStorage.dataStorageRenderPass : this._getInstanceDataStorage();
        return pO.visibleInstances || (pO.visibleInstances = {
          defaultRenderId: KO,
          selfDefaultRenderId: this._renderId,
          intermediateDefaultRenderId: -1
        }), pO.visibleInstances[KO] || (void 0 === pO.previousRenderId || this._instanceDataStorage.useMonoDataStorageRenderPass && !this._instanceDataStorage.isFrozen || delete pO.visibleInstances[pO.previousRenderId], pO.previousRenderId = KO, pO.visibleInstances[KO] = new Array), pO.visibleInstances[KO].push(OO), this
      }
      _afterComputeWorldMatrix() {
        super._afterComputeWorldMatrix(), this.hasThinInstances && (this.kb || this.thinInstanceRefreshBoundingInfo(!1))
      }
      _postActivate() {
        this.edgesShareWithInstances && this.edgesRenderer && this.edgesRenderer.isEnabled && this._renderingGroup && (this._renderingGroup._edgesRenderers.pushNoDuplicate(this.edgesRenderer), this.edgesRenderer.customInstances.push(this.getWorldMatrix()))
      }
      refreshBoundingInfo() {
        let OO, KO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          pO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (this.hasBoundingInfo && this.hpO().isLocked) return this;
        OO = "object" === typeof KO ? KO : {
          applySkeleton: KO,
          applyMorph: pO
        };
        const XO = this.geometry ? this.geometry.boundingBias : null;
        return this._refreshBoundingInfo(this._getData(OO, null, uO.j.PositionKind), XO), this
      }
      _createGlobalSubMesh(OO) {
        const KO = this.getTotalVertices();
        if (!KO || !this.rFO()) return null;
        if (this.au && this.au.length > 0) {
          const pO = this.rFO();
          if (!pO) return null;
          const XO = pO.length;
          let bK = !1;
          if (OO) bK = !0;
          else
            for (const OO of this.au) {
              if (OO.indexStart + OO.indexCount > XO) {
                bK = !0;
                break
              }
              if (OO.verticesStart + OO.verticesCount > KO) {
                bK = !0;
                break
              }
            }
          if (!bK) return this.au[0]
        }
        return this.releaseSubMeshes(), new wO.b(0, 0, KO, 0, this.getTotalIndices() || (this.isUnIndexed ? KO : 0), this)
      }
      subdivide(OO) {
        if (OO < 1) return;
        const KO = this.getTotalIndices();
        let pO = KO / OO | 0,
          XO = 0;
        for (; pO % 3 !== 0;) pO++;
        this.releaseSubMeshes();
        for (let bK = 0; bK < OO && !(XO >= KO); bK++) wO.b.CreateFromIndices(0, XO, XO + pO >= KO ? KO - XO : pO, this, void 0, !1), XO += pO;
        this.refreshBoundingInfo(), this.synchronizeInstances()
      }
      setVerticesData(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 ? arguments[3] : void 0;
        if (this._geometry) this._geometry.setVerticesData(OO, KO, pO, XO);
        else {
          const XO = new EO.e;
          XO.set(KO, OO);
          const bK = this.JKO();
          new jK.e(jK.e.RandomId(), bK, XO, pO, this)
        }
        return this
      }
      removeVerticesData(OO) {
        this._geometry && this._geometry.removeVerticesData(OO)
      }
      markVerticesDataAsUpdatable(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        const pO = this.getVertexBuffer(OO);
        pO && pO.isUpdatable() !== KO && this.setVerticesData(OO, this.getVerticesData(OO), KO)
      }
      setVerticesBuffer(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        return this._geometry || (this._geometry = jK.e.CreateGeometryForMesh(this)), this._geometry.setVerticesBuffer(OO, pO, KO), this
      }
      updateVerticesData(OO, KO, pO, XO) {
        return this._geometry ? (XO ? (this.makeGeometryUnique(), this.updateVerticesData(OO, KO, pO, !1)) : this._geometry.updateVerticesData(OO, KO, pO), this) : this
      }
      updateMeshPositions(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        const pO = this.getVerticesData(uO.j.PositionKind);
        if (!pO) return this;
        if (OO(pO), this.updateVerticesData(uO.j.PositionKind, pO, !1, !1), KO) {
          const OO = this.rFO(),
            KO = this.getVerticesData(uO.j.NormalKind);
          if (!KO) return this;
          EO.e.ComputeNormals(pO, OO, KO), this.updateVerticesData(uO.j.NormalKind, KO, !1, !1)
        }
        return this
      }
      makeGeometryUnique() {
        if (!this._geometry) return this;
        if (1 === this._geometry.meshes.length) return this;
        const OO = this._geometry,
          KO = this._geometry.copy(jK.e.RandomId());
        return OO.releaseForMesh(this, !0), KO.applyToMesh(this), this
      }
      setIndexBuffer(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
          bK = this._geometry;
        bK || (bK = new jK.e(jK.e.RandomId(), this.JKO(), void 0, void 0, this)), bK.setIndexBuffer(OO, KO, pO, XO)
      }
      setIndices(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        if (this._geometry) this._geometry.setIndices(OO, KO, pO, XO);
        else {
          const XO = new EO.e;
          XO.indices = OO;
          const bK = this.JKO();
          new jK.e(jK.e.RandomId(), bK, XO, pO, this, KO)
        }
        return this
      }
      updateIndices(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        return this._geometry ? (this._geometry.updateIndices(OO, KO, pO), this) : this
      }
      toLeftHanded() {
        return this._geometry ? (this._geometry.toLeftHanded(), this) : this
      }
      _bind(OO, KO, pO) {
        let XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        if (!this._geometry) return this;
        const bK = this.JKO().qb();
        let eO;
        if (this._unIndexed)
          if (this._getRenderingFillMode(pO) === iK.b.WireFrameFillMode) eO = OO._getLinesIndexBuffer(this.rFO(), bK);
          else eO = null;
        else switch (this._getRenderingFillMode(pO)) {
          case iK.b.PointFillMode:
            eO = null;
            break;
          case iK.b.WireFrameFillMode:
            eO = OO._getLinesIndexBuffer(this.rFO(), bK);
            break;
          default:
          case iK.b.TriangleFillMode:
            eO = this._geometry.getIndexBuffer()
        }
        return this._bindDirect(KO, eO, XO)
      }
      _bindDirect(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        if (!this._geometry) return this;
        if (this.morphTargetManager && this.morphTargetManager.isUsingTextureForTargets && this.morphTargetManager._bind(OO), pO && this._userInstancedBuffersStorage && !this.hasThinInstances) {
          if (!this._instanceDataStorage.useMonoDataStorageRenderPass && this._userInstancedBuffersStorage.renderPasses && this._userInstancedBuffersStorage.renderPasses[this._instanceDataStorage.engine.currentRenderPassId]) {
            const OO = this._userInstancedBuffersStorage.renderPasses[this._instanceDataStorage.engine.currentRenderPassId];
            for (const KO in OO) this._userInstancedBuffersStorage.vertexBuffers[KO] = OO[KO]
          }
          this._geometry._bind(OO, KO, this._userInstancedBuffersStorage.vertexBuffers, this._userInstancedBuffersStorage.vertexArrayObjects)
        } else this._geometry._bind(OO, KO);
        return this
      }
      _draw(OO, KO, pO) {
        if (!this._geometry || !this._geometry.getVertexBuffers() || !this._unIndexed && !this._geometry.getIndexBuffer()) return this;
        this._internalMeshDataInfo._onBeforeDrawObservable && this._internalMeshDataInfo._onBeforeDrawObservable.notifyObservers(this);
        const XO = this.JKO().qb(),
          bK = XO._currentMaterialContext,
          eO = bK && bK.useVertexPulling;
        return this._unIndexed && KO !== iK.b.WireFrameFillMode || KO == iK.b.PointFillMode ? XO.drawArraysType(KO, OO.verticesStart, OO.verticesCount, this.forcedInstanceCount || pO) : KO == iK.b.WireFrameFillMode ? XO.drawElementsType(KO, 0, OO._linesIndexCount, this.forcedInstanceCount || pO) : eO ? XO.drawArraysType(KO, OO.indexStart, OO.indexCount, this.forcedInstanceCount || pO) : XO.drawElementsType(KO, OO.indexStart, OO.indexCount, this.forcedInstanceCount || pO), this
      }
      registerBeforeRender(OO) {
        return this.onBeforeRenderObservable.add(OO), this
      }
      unregisterBeforeRender(OO) {
        return this.onBeforeRenderObservable.removeCallback(OO), this
      }
      registerAfterRender(OO) {
        return this.onAfterRenderObservable.add(OO), this
      }
      unregisterAfterRender(OO) {
        return this.onAfterRenderObservable.removeCallback(OO), this
      }
      _getInstancesRenderList(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = this._instanceDataStorage.useMonoDataStorageRenderPass ? this._instanceDataStorage.dataStorageRenderPass : this._getInstanceDataStorage();
        if (this._instanceDataStorage.isFrozen) {
          if (KO) return pO.batchCacheReplacementModeInFrozenMode.hardwareInstancedRendering[OO] = !1, pO.batchCacheReplacementModeInFrozenMode.renderSelf[OO] = !0, pO.batchCacheReplacementModeInFrozenMode;
          if (pO.previousBatch) return pO.previousBatch
        }
        const XO = this.JKO(),
          bK = XO._isInIntermediateRendering(),
          eO = bK ? this._internalAbstractMeshDataInfo._onlyForInstancesIntermediate : this._internalAbstractMeshDataInfo._onlyForInstances,
          lO = pO.batchCache;
        if (lO.mustReturn = !1, lO.renderSelf[OO] = KO || !eO && this.isEnabled() && this.isVisible, lO.visibleInstances[OO] = null, pO.visibleInstances && !KO) {
          const KO = pO.visibleInstances,
            eO = XO.getRenderId(),
            vK = bK ? KO.intermediateDefaultRenderId : KO.defaultRenderId;
          lO.visibleInstances[OO] = KO[eO], !lO.visibleInstances[OO] && vK && (lO.visibleInstances[OO] = KO[vK])
        }
        return lO.hardwareInstancedRendering[OO] = !KO && this._instanceDataStorage.hardwareInstancedRendering && null !== lO.visibleInstances[OO] && void 0 !== lO.visibleInstances[OO], pO.previousBatch = lO, lO
      }
      _updateInstancedBuffers(OO, KO, pO, XO, bK, eO) {
        const lO = KO.visibleInstances[OO._id],
          vK = lO ? lO.length : 0,
          CO = KO.parent,
          hO = this._instanceDataStorage;
        let DO = CO.instancesBuffer,
          MO = CO.instancesPreviousBuffer,
          aK = 0,
          oO = 0;
        const FO = KO.renderSelf[OO._id],
          VO = this._scene.floatingOriginOffset,
          LO = !DO || pO !== CO.instancesBufferSize || this._scene.needsPreviousWorldMatrices && !CO.instancesPreviousBuffer;
        if (this._instanceDataStorage.manualUpdate || hO.isFrozen && !LO) oO = (FO ? 1 : 0) + vK;
        else {
          const KO = this.getWorldMatrix();
          if (FO) {
            this._scene.needsPreviousWorldMatrices && (hO.masterMeshPreviousWorldMatrix ? (hO.masterMeshPreviousWorldMatrix.copyToArray(CO.instancesPreviousData, aK), hO.masterMeshPreviousWorldMatrix.NhO(KO)) : (hO.masterMeshPreviousWorldMatrix = KO.clone(), hO.masterMeshPreviousWorldMatrix.copyToArray(CO.instancesPreviousData, aK))), KO.copyToArray(CO.instancesData, aK);
            const OO = KO.WhO();
            CO.instancesData[aK + 12] = OO[12] - VO.x, CO.instancesData[aK + 13] = OO[13] - VO.y, CO.instancesData[aK + 14] = OO[14] - VO.z, aK += 16, oO++
          }
          if (lO) {
            if (tK.INSTANCEDMESH_SORT_TRANSPARENT && this._scene.activeCamera && OO.UX()?.needAlphaBlendingForMesh(OO.getRenderingMesh())) {
              const OO = this._scene.activeCamera.globalPosition;
              for (let KO = 0; KO < lO.length; KO++) {
                const pO = lO[KO];
                pO._distanceToCamera = IO.o.Distance(pO.hpO().QDO.centerWorld, OO)
              }
              lO.sort(((OO, KO) => OO._distanceToCamera > KO._distanceToCamera ? -1 : OO._distanceToCamera < KO._distanceToCamera ? 1 : 0))
            }
            for (let OO = 0; OO < lO.length; OO++) {
              const KO = lO[OO],
                pO = KO.getWorldMatrix();
              pO.copyToArray(CO.instancesData, aK), this._scene.needsPreviousWorldMatrices && (KO._previousWorldMatrix ? (KO._previousWorldMatrix.copyToArray(CO.instancesPreviousData, aK), KO._previousWorldMatrix.NhO(pO)) : (KO._previousWorldMatrix = pO.clone(), KO._previousWorldMatrix.copyToArray(CO.instancesPreviousData, aK)));
              const XO = pO.WhO();
              CO.instancesData[aK + 12] = XO[12] - VO.x, CO.instancesData[aK + 13] = XO[13] - VO.y, CO.instancesData[aK + 14] = XO[14] - VO.z, aK += 16, oO++
            }
          }
        }
        if (LO) {
          let OO;
          if (DO && DO.dispose(), MO && MO.dispose(), DO = new uO.b(XO, CO.instancesData, !0, 16, !1, !0), CO.instancesBuffer = DO, this._userInstancedBuffersStorage || (this._userInstancedBuffersStorage = {
              data: {},
              vertexBuffers: {},
              strides: {},
              sizes: {},
              vertexArrayObjects: this.qb().getCaps().vertexArrayObject ? {} : void 0
            }), this._instanceDataStorage.useMonoDataStorageRenderPass) OO = this._userInstancedBuffersStorage.vertexBuffers;
          else {
            this._userInstancedBuffersStorage.renderPasses || (this._userInstancedBuffersStorage.renderPasses = {});
            const KO = this._instanceDataStorage.engine.currentRenderPassId;
            OO = this._userInstancedBuffersStorage.renderPasses[KO], OO || (this._userInstancedBuffersStorage.renderPasses[KO] = OO = {})
          }
          OO.world0 = DO.createVertexBuffer("world0", 0, 4), OO.world1 = DO.createVertexBuffer("world1", 4, 4), OO.world2 = DO.createVertexBuffer("world2", 8, 4), OO.world3 = DO.createVertexBuffer("world3", 12, 4), this._scene.needsPreviousWorldMatrices && (MO = new uO.b(XO, CO.instancesPreviousData, !0, 16, !1, !0), CO.instancesPreviousBuffer = MO, OO.previousWorld0 = MO.createVertexBuffer("previousWorld0", 0, 4), OO.previousWorld1 = MO.createVertexBuffer("previousWorld1", 4, 4), OO.previousWorld2 = MO.createVertexBuffer("previousWorld2", 8, 4), OO.previousWorld3 = MO.createVertexBuffer("previousWorld3", 12, 4)), this._invalidateInstanceVertexArrayObject()
        } else this._instanceDataStorage.isFrozen && !this._instanceDataStorage.forceMatrixUpdates || (DO.updateDirectly(CO.instancesData, 0, oO), !this._scene.needsPreviousWorldMatrices || this._instanceDataStorage.manualUpdate && !this._instanceDataStorage.previousManualUpdate || MO.updateDirectly(CO.instancesPreviousData, 0, oO));
        this._processInstancedBuffers(lO, FO), eO && void 0 !== bK && (this.JKO()._activeIndices.addCount(OO.indexCount * oO, !1), XO._currentDrawContext && (XO._currentDrawContext.useInstancing = !0), this._bind(OO, eO, bK), this._draw(OO, bK, oO)), !this._scene.needsPreviousWorldMatrices || LO || !this._instanceDataStorage.manualUpdate || this._instanceDataStorage.isFrozen && !this._instanceDataStorage.forceMatrixUpdates || this._instanceDataStorage.previousManualUpdate || MO.updateDirectly(CO.instancesData, 0, oO)
      }
      _renderWithInstances(OO, KO, pO, XO, bK) {
        const eO = pO.visibleInstances[OO._id],
          lO = eO ? eO.length : 0,
          vK = pO.parent,
          CO = vK.instancesBufferSize,
          hO = 16 * (lO + 1) * 4;
        for (; vK.instancesBufferSize < hO;) vK.instancesBufferSize *= 2;
        return vK.instancesData && CO == vK.instancesBufferSize || (vK.instancesData = new Float32Array(vK.instancesBufferSize / 4)), (this._scene.needsPreviousWorldMatrices && !vK.instancesPreviousData || CO != vK.instancesBufferSize) && (vK.instancesPreviousData = new Float32Array(vK.instancesBufferSize / 4)), this._updateInstancedBuffers(OO, pO, CO, bK, KO, XO), bK.unbindInstanceAttributes(), this
      }
      _renderWithThinInstances(OO, KO, pO, XO) {
        const bK = this._thinInstanceDataStorage?.instancesCount ?? 0;
        this.JKO()._activeIndices.addCount(OO.indexCount * bK, !1), XO._currentDrawContext && (XO._currentDrawContext.useInstancing = !0), this._bind(OO, pO, KO), this._draw(OO, KO, bK), this._scene.needsPreviousWorldMatrices && !this._thinInstanceDataStorage.previousMatrixData && this._thinInstanceDataStorage.matrixData && (this._thinInstanceDataStorage.previousMatrixBuffer ? this._thinInstanceDataStorage.previousMatrixBuffer.updateDirectly(this._thinInstanceDataStorage.matrixData, 0, bK) : this._thinInstanceDataStorage.previousMatrixBuffer = this._thinInstanceCreateMatrixBuffer("previousWorld", this._thinInstanceDataStorage.matrixData, !1)), XO.unbindInstanceAttributes()
      }
      _processInstancedBuffers(OO, KO) {}
      _processRendering(OO, KO, pO, XO, bK, eO, lO, vK) {
        const CO = this.JKO(),
          hO = CO.qb();
        if (XO = this._getRenderingFillMode(XO), eO && KO.getRenderingMesh().hasThinInstances) return this._renderWithThinInstances(KO, XO, pO, hO), this;
        if (eO) this._renderWithInstances(KO, XO, bK, pO, hO);
        else {
          hO._currentDrawContext && (hO._currentDrawContext.useInstancing = !1);
          let pO = 0;
          bK.renderSelf[KO._id] && (lO && lO(!1, OO.getWorldMatrix(), vK), pO++, this._draw(KO, XO, this._instanceDataStorage.overridenInstanceCount));
          const eO = bK.visibleInstances[KO._id];
          if (eO) {
            const OO = eO.length;
            pO += OO;
            for (let pO = 0; pO < OO; pO++) {
              const OO = eO[pO].getWorldMatrix();
              lO && lO(!0, OO, vK), this._draw(KO, XO)
            }
          }
          CO._activeIndices.addCount(KO.indexCount * pO, !1)
        }
        return this
      }
      _disposeInstanceDataStorageRenderPass(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        OO?.instancesBuffer && (KO && OO.instancesBuffer.dispose(), OO.instancesBuffer = null), OO?.instancesPreviousBuffer && (KO && OO.instancesPreviousBuffer.dispose(), OO.instancesPreviousBuffer = null)
      }
      _rebuild() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        for (const KO in this._instanceDataStorage.renderPasses) {
          const pO = this._instanceDataStorage.renderPasses[KO];
          this._disposeInstanceDataStorageRenderPass(pO, OO)
        }
        if (this._disposeInstanceDataStorageRenderPass(this._instanceDataStorage.dataStorageRenderPass, OO), this._userInstancedBuffersStorage) {
          for (const KO in this._userInstancedBuffersStorage.vertexBuffers) {
            const pO = this._userInstancedBuffersStorage.vertexBuffers[KO];
            pO && (OO && pO.dispose(), this._userInstancedBuffersStorage.vertexBuffers[KO] = null)
          }
          this._userInstancedBuffersStorage.vertexArrayObjects && (this._userInstancedBuffersStorage.vertexArrayObjects = {})
        }
        this._internalMeshDataInfo._effectiveMaterial = null, super._rebuild(OO)
      }
      _releaseRenderPassId(OO) {
        const KO = this._instanceDataStorage.renderPasses[OO];
        if (KO && (this._disposeInstanceDataStorageRenderPass(KO, !0), delete this._instanceDataStorage.renderPasses[OO]), this._userInstancedBuffersStorage?.renderPasses) {
          const KO = this._userInstancedBuffersStorage.renderPasses[OO];
          if (KO)
            for (const OO in KO) KO[OO]?.dispose();
          delete this._userInstancedBuffersStorage.renderPasses[OO]
        }
        const pO = this._userInstancedBuffersStorage?.interleavedBuffers;
        pO?.[OO] && (pO[OO].buffer.dispose(), delete pO[OO])
      }
      _freeze() {
        if (this.au) {
          for (let OO = 0; OO < this.au.length; OO++) this._getInstancesRenderList(OO);
          this._internalMeshDataInfo._effectiveMaterial = null, this._instanceDataStorage.isFrozen = !0
        }
      }
      _unFreeze() {
        this._instanceDataStorage.isFrozen = !1;
        for (const OO in this._instanceDataStorage.renderPasses) {
          this._instanceDataStorage.renderPasses[OO].previousBatch = null
        }
        this._instanceDataStorage.dataStorageRenderPass && (this._instanceDataStorage.dataStorageRenderPass.previousBatch = null)
      }
      renderWithRenderPassId(OO, KO, pO, XO) {
        let bK = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4];
        const eO = this._scene.qb(),
          lO = eO.currentRenderPassId;
        if (void 0 !== OO && (eO.currentRenderPassId = OO), XO)(!bK || bK && XO.isInFrustum(this._scene._frustumPlanes)) && this.render(XO, !!KO, pO);
        else
          for (let vK = 0; vK < this.au.length; vK++) {
            const OO = this.au[vK];
            (!bK || bK && OO.isInFrustum(this._scene._frustumPlanes)) && this.render(OO, !!KO, pO)
          }
        return void 0 !== OO && (eO.currentRenderPassId = lO), this
      }
      directRender() {
        if (!this.au) return this;
        for (const OO of this.au) this.render(OO, !1);
        return this
      }
      render(OO, KO, pO) {
        const XO = this.JKO(),
          bK = XO.qb();
        this._internalAbstractMeshDataInfo._isActiveIntermediate ? this._internalAbstractMeshDataInfo._isActiveIntermediate = !1 : this._internalAbstractMeshDataInfo._isActive = !1;
        const eO = XO.activeCameras?.length ?? 0,
          lO = eO > 1 && XO.activeCamera === XO.activeCameras[0] || eO <= 1,
          vK = this._occlusionDataStorage && -1 !== this._occlusionDataStorage.occlusionForRenderPassId && this._occlusionDataStorage.occlusionForRenderPassId !== bK.currentRenderPassId;
        if (lO && this._checkOcclusionQuery(vK) && !this._occlusionDataStorage.forceRenderingWhenOccluded) return this;
        const CO = this._getInstancesRenderList(OO._id, !!pO);
        if (CO.mustReturn) return this;
        if (!this._geometry || !this._geometry.getVertexBuffers() || !this._unIndexed && !this._geometry.getIndexBuffer()) return this;
        let hO = 0,
          DO = null;
        this.ignoreCameraMaxZ && XO.activeCamera && !XO._isInIntermediateRendering() && (hO = XO.activeCamera.maxZ, DO = XO.activeCamera, XO.activeCamera.maxZ = 0, XO.updateTransformMatrix(!0)), this._internalMeshDataInfo._onBeforeRenderObservable && this._internalMeshDataInfo._onBeforeRenderObservable.notifyObservers(this);
        const MO = OO.getRenderingMesh(),
          aK = CO.hardwareInstancedRendering[OO._id] || MO.hasThinInstances || !!this._userInstancedBuffersStorage && !OO.getMesh()._internalAbstractMeshDataInfo._actAsRegularMesh,
          oO = this._instanceDataStorage,
          FO = OO.UX();
        if (!FO) return DO && (DO.maxZ = hO, XO.updateTransformMatrix(!0)), this;
        if (oO.isFrozen && this._internalMeshDataInfo._effectiveMaterial && this._internalMeshDataInfo._effectiveMaterial === FO) {
          if (FO._storeEffectOnSubMeshes && !OO._drawWrapper?._wasPreviouslyReady || !FO._storeEffectOnSubMeshes && !FO._getDrawWrapper()._wasPreviouslyReady) return DO && (DO.maxZ = hO, XO.updateTransformMatrix(!0)), this
        } else {
          if (FO._storeEffectOnSubMeshes) {
            if (!FO.isReadyForSubMesh(this, OO, aK)) return DO && (DO.maxZ = hO, XO.updateTransformMatrix(!0)), this
          } else if (!FO.isReady(this, aK)) return DO && (DO.maxZ = hO, XO.updateTransformMatrix(!0)), this;
          this._internalMeshDataInfo._effectiveMaterial = FO
        }
        if (KO) {
          const OO = this._internalMeshDataInfo._effectiveMaterial;
          if (1 === OO.alphaModes.length) bK.setAlphaMode(OO.alphaMode);
          else
            for (let KO = 0; KO < OO.alphaModes.length; KO++) {
              const pO = OO.alphaModes[KO];
              bK.setAlphaMode(void 0 !== pO ? pO : 2, !1, KO)
            }
        }
        let VO;
        VO = this._internalMeshDataInfo._effectiveMaterial._storeEffectOnSubMeshes ? OO._drawWrapper : this._internalMeshDataInfo._effectiveMaterial._getDrawWrapper();
        const LO = VO?.effect ?? null;
        for (let NO = 0, IO = XO._beforeRenderingMeshStage; NO < IO.length; NO++) {
          IO[NO].action(this, OO, CO, LO)
        }
        if (!VO || !LO) return DO && (DO.maxZ = hO, XO.updateTransformMatrix(!0)), this;
        const QO = pO || this;
        let zK;
        if (!oO.isFrozen && (this._internalMeshDataInfo._effectiveMaterial.backFaceCulling || null !== this._internalMeshDataInfo._effectiveMaterial.sideOrientation || this._internalMeshDataInfo._effectiveMaterial._twoSidedLighting)) {
          const OO = QO._getWorldMatrixDeterminant();
          zK = this._internalMeshDataInfo._effectiveMaterial._getEffectiveOrientation(this), OO < 0 && (zK = zK === iK.b.ClockWiseSideOrientation ? iK.b.CounterClockWiseSideOrientation : iK.b.ClockWiseSideOrientation), this._internalMeshDataInfo._effectiveSideOrientation = zK
        }
        const AO = this._internalMeshDataInfo._effectiveMaterial._preBind(VO, this._internalMeshDataInfo._effectiveSideOrientation);
        this._internalMeshDataInfo._effectiveMaterial.forceDepthWrite && bK.setDepthWrite(!0);
        const fO = this._internalMeshDataInfo._effectiveMaterial,
          dO = fO.fillMode;
        this._internalMeshDataInfo._onBeforeBindObservable && this._internalMeshDataInfo._onBeforeBindObservable.notifyObservers(this), aK || this._bind(OO, LO, dO, !1);
        const TO = QO.getWorldMatrix();
        fO._storeEffectOnSubMeshes ? fO.bindForSubMesh(TO, this, OO) : fO.bind(TO, this);
        try {
          rK.d._BindAttachmentsForEffect(bK, LO) && (!fO.backFaceCulling && fO.separateCullingPass && (bK.setState(!0, fO.zOffset, !1, !AO, fO.cullBackFaces, fO.stencil, fO.zOffsetUnits), this._processRendering(this, OO, LO, dO, CO, aK, this._onBeforeDraw, this._internalMeshDataInfo._effectiveMaterial), bK.setState(!0, fO.zOffset, !1, AO, fO.cullBackFaces, fO.stencil, fO.zOffsetUnits), this._internalMeshDataInfo._onBetweenPassObservable && this._internalMeshDataInfo._onBetweenPassObservable.notifyObservers(OO)), this._processRendering(this, OO, LO, dO, CO, aK, this._onBeforeDraw, this._internalMeshDataInfo._effectiveMaterial))
        } finally {
          rK.d._RestoreAttachments(bK)
        }
        this._internalMeshDataInfo._effectiveMaterial.unbind();
        for (let NO = 0, IO = XO._afterRenderingMeshStage; NO < IO.length; NO++) {
          IO[NO].action(this, OO, CO, LO)
        }
        return this._internalMeshDataInfo._onAfterRenderObservable && this._internalMeshDataInfo._onAfterRenderObservable.notifyObservers(this), DO && (DO.maxZ = hO, XO.updateTransformMatrix(!0)), 2 !== XO.performancePriority || oO.isFrozen || this._freeze(), this
      }
      _renderRunFollower(OO, KO) {
        const pO = this._scene,
          XO = pO._engine;
        if (XO.isWebGPU || OO._mesh !== this || 0 !== this.instances.length || this.render !== tK.prototype.render) return !1;
        const bK = OO.UX();
        if (!bK || bK !== pO._cachedMaterial || void 0 === bK._canBindRunFollower) return !1;
        const eO = OO._drawWrapper,
          lO = eO?.effect;
        if (!lO || lO !== pO._cachedEffect || this.visibility !== pO._cachedVisibility || eO._forceRebindOnNextCall) return !1;
        const vK = this.hasThinInstances;
        if (!vK && this._userInstancedBuffersStorage) return !1;
        if (!eO._wasPreviouslyReady || eO._wasPreviouslyUsingInstances !== vK) return !1;
        const CO = this._internalMeshDataInfo;
        if (this.ignoreCameraMaxZ || this.morphTargetManager || this._instanceDataStorage.isFrozen || pO._isInIntermediateRendering() || 0 !== pO._beforeRenderingMeshStage.length || 0 !== pO._afterRenderingMeshStage.length || CO._onBeforeRenderObservable?.hasObservers() || CO._onBeforeBindObservable?.hasObservers() || CO._onAfterRenderObservable?.hasObservers()) return !1;
        const hO = this.occlusionType;
        if (void 0 !== hO && hO !== YO.d.OCCLUSION_TYPE_NONE || !bK._canBindRunFollower(pO, XO, this, OO, lO)) return !1;
        const DO = this._internalAbstractMeshDataInfo,
          MO = DO._isActiveIntermediate;
        MO ? DO._isActiveIntermediate = !1 : DO._isActive = !1;
        const aK = pO.activeCameras?.length ?? 0;
        (aK > 1 && pO.activeCamera === pO.activeCameras[0] || aK <= 1) && this._checkOcclusionQuery(!1);
        const oO = this._getInstancesRenderList(OO._id);
        if (oO.mustReturn) return !0;
        if (!vK && !oO.renderSelf[OO._id]) return MO ? DO._isActiveIntermediate = !0 : DO._isActive = !0, !1;
        if (!this._geometry || !this._geometry.getVertexBuffers() || !this._unIndexed && !this._geometry.getIndexBuffer()) return !0;
        if (CO._effectiveMaterial = bK, KO)
          if (1 === bK.alphaModes.length) XO.setAlphaMode(bK.alphaMode);
          else
            for (let VO = 0; VO < bK.alphaModes.length; VO++) {
              const OO = bK.alphaModes[VO];
              XO.setAlphaMode(void 0 !== OO ? OO : 2, !1, VO)
            }
        if (bK.backFaceCulling || null !== bK.sideOrientation || bK._twoSidedLighting) {
          const OO = this._getWorldMatrixDeterminant();
          let KO = bK._getEffectiveOrientation(this);
          OO < 0 && (KO = KO === iK.b.ClockWiseSideOrientation ? iK.b.CounterClockWiseSideOrientation : iK.b.ClockWiseSideOrientation), CO._effectiveSideOrientation = KO
        }
        bK._preBind(eO, CO._effectiveSideOrientation), bK.forceDepthWrite && XO.setDepthWrite(!0);
        const FO = bK.fillMode;
        return vK || this._bind(OO, lO, FO, !1), bK._bindRunFollower(this.getWorldMatrix(), this, OO, lO), this._processRendering(this, OO, lO, FO, oO, vK, this._onBeforeDraw, bK), bK.unbind(), 2 === pO.performancePriority && this._freeze(), !0
      }
      cleanMatrixWeights() {
        this.isVerticesDataPresent(uO.j.MatricesWeightsKind) && (this.isVerticesDataPresent(uO.j.MatricesWeightsExtraKind) ? this._normalizeSkinWeightsAndExtra() : this._normalizeSkinFourWeights())
      }
      _normalizeSkinFourWeights() {
        const OO = this.getVerticesData(uO.j.MatricesWeightsKind),
          KO = OO.length;
        for (let pO = 0; pO < KO; pO += 4) {
          const KO = OO[pO] + OO[pO + 1] + OO[pO + 2] + OO[pO + 3];
          if (0 === KO) OO[pO] = 1;
          else {
            const XO = 1 / KO;
            OO[pO] *= XO, OO[pO + 1] *= XO, OO[pO + 2] *= XO, OO[pO + 3] *= XO
          }
        }
        this.setVerticesData(uO.j.MatricesWeightsKind, OO)
      }
      _normalizeSkinWeightsAndExtra() {
        const OO = this.getVerticesData(uO.j.MatricesWeightsExtraKind),
          KO = this.getVerticesData(uO.j.MatricesWeightsKind),
          pO = KO.length;
        for (let XO = 0; XO < pO; XO += 4) {
          let pO = KO[XO] + KO[XO + 1] + KO[XO + 2] + KO[XO + 3];
          if (pO += OO[XO] + OO[XO + 1] + OO[XO + 2] + OO[XO + 3], 0 === pO) KO[XO] = 1;
          else {
            const bK = 1 / pO;
            KO[XO] *= bK, KO[XO + 1] *= bK, KO[XO + 2] *= bK, KO[XO + 3] *= bK, OO[XO] *= bK, OO[XO + 1] *= bK, OO[XO + 2] *= bK, OO[XO + 3] *= bK
          }
        }
        this.setVerticesData(uO.j.MatricesWeightsKind, KO), this.setVerticesData(uO.j.MatricesWeightsKind, OO)
      }
      validateSkinning() {
        const OO = this.getVerticesData(uO.j.MatricesWeightsExtraKind),
          KO = this.getVerticesData(uO.j.MatricesWeightsKind);
        if (null === KO || null == this.skeleton) return {
          skinned: !1,
          valid: !0,
          CX: "not skinned"
        };
        const pO = KO.length;
        let XO = 0,
          bK = 0,
          eO = 0,
          lO = 0;
        const vK = null === OO ? 4 : 8,
          CO = [];
        for (let oO = 0; oO <= vK; oO++) CO[oO] = 0;
        for (let oO = 0; oO < pO; oO += 4) {
          let pO = KO[oO],
            hO = pO,
            DO = 0 === hO ? 0 : 1;
          for (let bK = 1; bK < vK; bK++) {
            const eO = bK < 4 ? KO[oO + bK] : OO[oO + bK - 4];
            eO > pO && XO++, 0 !== eO && DO++, hO += eO, pO = eO
          }
          if (CO[DO]++, DO > eO && (eO = DO), 0 === hO) bK++;
          else {
            const pO = 1 / hO;
            let XO = 0;
            for (let bK = 0; bK < vK; bK++) XO += bK < 4 ? Math.abs(KO[oO + bK] - KO[oO + bK] * pO) : Math.abs(OO[oO + bK - 4] - OO[oO + bK - 4] * pO);
            XO > .001 && lO++
          }
        }
        const hO = this.skeleton.bones.length,
          DO = this.getVerticesData(uO.j.MatricesIndicesKind),
          MO = this.getVerticesData(uO.j.MatricesIndicesExtraKind);
        let aK = 0;
        for (let oO = 0; oO < pO; oO += 4)
          for (let OO = 0; OO < vK; OO++) {
            const KO = OO < 4 ? DO[oO + OO] : MO[oO + OO - 4];
            (KO >= hO || KO < 0) && aK++
          }
        return {
          skinned: !0,
          valid: 0 === bK && 0 === lO && 0 === aK,
          CX: "Number of Weights = " + pO / 4 + "\nMaximum influences = " + eO + "\nMissing Weights = " + bK + "\nNot Sorted = " + XO + "\nNot Normalized = " + lO + "\nWeightCounts = [" + CO + "]\nNumber of bones = " + hO + "\nBad Bone Indices = " + aK
        }
      }
      _checkDelayState() {
        const OO = this.JKO();
        return this._geometry ? this._geometry.load(OO) : 4 === this.delayLoadState && (this.delayLoadState = 2, this._queueLoad(OO)), this
      }
      _queueLoad(OO) {
        OO.addPendingData(this);
        const KO = -1 !== this.delayLoadingFile.indexOf(".babylonbinarymeshdata");
        return (async () => {
          try {
            const pO = await OO._loadDelayedFileAsync(this.delayLoadingFile, KO, !0);
            pO instanceof ArrayBuffer ? this._delayLoadingFunction(pO, this) : this._delayLoadingFunction(JSON.parse(pO), this);
            for (const OO of this.instances) OO.refreshBoundingInfo(), OO._syncSubMeshes();
            this.delayLoadState = 1, OO.removePendingData(this)
          } catch (pO) {
            OO.removePendingData(this), OO.FhO || HO.b.Error(`Unable to delay load geometry data for mesh "${this.name}" from "${this.delayLoadingFile}": ${pO}`)
          }
        })(), this
      }
      isInFrustum(OO) {
        return 2 !== this.delayLoadState && (!!super.isInFrustum(OO) && (this._checkDelayState(), !0))
      }
      setMaterialById(OO) {
        const KO = this.JKO().materials;
        let pO;
        for (pO = KO.length - 1; pO > -1; pO--)
          if (KO[pO].id === OO) return this.material = KO[pO], this;
        const XO = this.JKO().multiMaterials;
        for (pO = XO.length - 1; pO > -1; pO--)
          if (XO[pO].id === OO) return this.material = XO[pO], this;
        return this
      }
      getAnimatables() {
        const OO = [];
        return this.material && OO.push(this.material), this.skeleton && OO.push(this.skeleton), OO
      }
      bakeTransformIntoVertices(OO) {
        if (!this.isVerticesDataPresent(uO.j.PositionKind)) return this;
        const KO = this.au.splice(0);
        this._resetPointsArrayCache();
        let pO = this.getVerticesData(uO.j.PositionKind);
        const XO = IO.o.Zero();
        let bK;
        for (bK = 0; bK < pO.length; bK += 3) IO.o.TransformCoordinatesFromFloatsToRef(pO[bK], pO[bK + 1], pO[bK + 2], OO, XO).toArray(pO, bK);
        if (this.setVerticesData(uO.j.PositionKind, pO, this.getVertexBuffer(uO.j.PositionKind).isUpdatable()), this.isVerticesDataPresent(uO.j.NormalKind)) {
          for (pO = this.getVerticesData(uO.j.NormalKind), bK = 0; bK < pO.length; bK += 3) IO.o.TransformNormalFromFloatsToRef(pO[bK], pO[bK + 1], pO[bK + 2], OO, XO).normalize().toArray(pO, bK);
          this.setVerticesData(uO.j.NormalKind, pO, this.getVertexBuffer(uO.j.NormalKind).isUpdatable())
        }
        if (this.isVerticesDataPresent(uO.j.TangentKind)) {
          for (pO = this.getVerticesData(uO.j.TangentKind), bK = 0; bK < pO.length; bK += 4) IO.o.TransformNormalFromFloatsToRef(pO[bK], pO[bK + 1], pO[bK + 2], OO, XO).normalize().toArray(pO, bK);
          this.setVerticesData(uO.j.TangentKind, pO, this.getVertexBuffer(uO.j.TangentKind).isUpdatable())
        }
        return OO.determinant() < 0 && this.flipFaces(), this.releaseSubMeshes(), this.au = KO, this
      }
      bakeCurrentTransformIntoVertices() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        return arguments.length > 1 && void 0 !== arguments[1] && arguments[1] && this.makeGeometryUnique(), this.bakeTransformIntoVertices(this.computeWorldMatrix(!0)), this.resetLocalMatrix(OO), this
      }
      get _positions() {
        return this._internalAbstractMeshDataInfo._positions || this._geometry && this._geometry._positions || null
      }
      _resetPointsArrayCache() {
        return this._geometry && this._geometry._resetPointsArrayCache(), this
      }
      _generatePointsArray() {
        return !!this._geometry && this._geometry._generatePointsArray()
      }
      clone() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        if (KO && void 0 === KO._addToSceneRootNodes) {
          const pO = KO;
          return WO.source = this, WO.doNotCloneChildren = pO.doNotCloneChildren, WO.clonePhysicsImpostor = pO.clonePhysicsImpostor, WO.cloneThinInstances = pO.cloneThinInstances, new tK(OO, this.JKO(), WO)
        }
        return new tK(OO, this.JKO(), KO, this, pO, XO)
      }
      dispose(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        this.morphTargetManager = null, this._geometry && this._geometry.releaseForMesh(this, !0);
        const pO = this._internalMeshDataInfo;
        if (pO._onBeforeDrawObservable && pO._onBeforeDrawObservable.clear(), pO._onBeforeBindObservable && pO._onBeforeBindObservable.clear(), pO._onBeforeRenderObservable && pO._onBeforeRenderObservable.clear(), pO._onAfterRenderObservable && pO._onAfterRenderObservable.clear(), pO._onBetweenPassObservable && pO._onBetweenPassObservable.clear(), this._scene.useClonedMeshMap) {
          if (pO.meshMap)
            for (const OO in pO.meshMap) {
              const KO = pO.meshMap[OO];
              KO && (KO._internalMeshDataInfo._source = null, pO.meshMap[OO] = void 0)
            }
          pO._source && pO._source._internalMeshDataInfo.meshMap && (pO._source._internalMeshDataInfo.meshMap[this.uniqueId] = void 0)
        } else {
          const OO = this.JKO().meshes;
          for (const KO of OO) {
            const OO = KO;
            OO._internalMeshDataInfo && OO._internalMeshDataInfo._source && OO._internalMeshDataInfo._source === this && (OO._internalMeshDataInfo._source = null)
          }
        }
        pO._source = null, this._disposeInstanceSpecificData(), this._disposeThinInstanceSpecificData(), this._internalMeshDataInfo._checkReadinessObserver && this._scene.onBeforeRenderObservable.remove(this._internalMeshDataInfo._checkReadinessObserver), super.dispose(OO, KO)
      }
      _disposeInstanceSpecificData() {}
      _disposeThinInstanceSpecificData() {}
      _invalidateInstanceVertexArrayObject() {}
      applyDisplacementMap(OO, KO, pO, XO, bK, eO) {
        let lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
          vK = arguments.length > 7 ? arguments[7] : void 0;
        const CO = this.JKO();
        return (0, AO.s)(OO, (OO => {
          const vK = OO.width,
            CO = OO.height,
            hO = this.qb().createCanvas(vK, CO).getContext("2d");
          hO.drawImage(OO, 0, 0);
          const DO = hO.getImageData(0, 0, vK, CO).data;
          this.applyDisplacementMapFromBuffer(DO, vK, CO, KO, pO, bK, eO, lO), XO && XO(this)
        }), vK || (() => {}), CO.offlineProvider), this
      }
      applyDisplacementMapFromBuffer(OO, KO, pO, XO, bK, eO, lO) {
        let vK = arguments.length > 7 && void 0 !== arguments[7] && arguments[7];
        if (!this.isVerticesDataPresent(uO.j.PositionKind) || !this.isVerticesDataPresent(uO.j.NormalKind) || !this.isVerticesDataPresent(uO.j.UVKind)) return HO.b.Warn("Cannot call applyDisplacementMap: Given mesh is not complete. Position, Normal or UV are missing"), this;
        const CO = this.getVerticesData(uO.j.PositionKind, !0, !0),
          hO = this.getVerticesData(uO.j.NormalKind),
          DO = this.getVerticesData(uO.j.UVKind);
        let MO = IO.o.Zero();
        const aK = IO.o.Zero(),
          oO = IO.m.Zero();
        eO = eO || IO.m.Zero(), lO = lO || new IO.m(1, 1);
        for (let FO = 0; FO < CO.length; FO += 3) {
          IO.o.FromArrayToRef(CO, FO, MO), IO.o.FromArrayToRef(hO, FO, aK), IO.m.FromArrayToRef(DO, FO / 3 * 2, oO);
          const vK = 4 * ((Math.abs(oO.x * lO.x + eO.x % 1) * (KO - 1) % KO | 0) + (Math.abs(oO.y * lO.y + eO.y % 1) * (pO - 1) % pO | 0) * KO),
            VO = .3 * (OO[vK] / 255) + .59 * (OO[vK + 1] / 255) + .11 * (OO[vK + 2] / 255);
          aK.normalize(), aK.scaleInPlace(XO + (bK - XO) * VO), MO = MO.add(aK), MO.toArray(CO, FO)
        }
        return EO.e.ComputeNormals(CO, this.rFO(), hO), vK ? (this.setVerticesData(uO.j.PositionKind, CO), this.setVerticesData(uO.j.NormalKind, hO), this.setVerticesData(uO.j.UVKind, DO)) : (this.updateVerticesData(uO.j.PositionKind, CO), this.updateVerticesData(uO.j.NormalKind, hO)), this
      }
      _getFlattenedNormals(OO, KO) {
        const pO = new Float32Array(3 * OO.length);
        let XO = 0;
        const bK = this.sideOrientation === (this._scene.useRightHandedSystem ? 1 : 0);
        for (let eO = 0; eO < OO.length; eO += 3) {
          const lO = IO.o.FromArray(KO, 3 * OO[eO]),
            vK = IO.o.FromArray(KO, 3 * OO[eO + 1]),
            CO = IO.o.FromArray(KO, 3 * OO[eO + 2]),
            hO = lO.subtract(vK),
            DO = CO.subtract(vK),
            MO = IO.o.Normalize(IO.o.Cross(hO, DO));
          bK && MO.scaleInPlace(-1);
          for (let OO = 0; OO < 3; OO++) pO[XO++] = MO.x, pO[XO++] = MO.y, pO[XO++] = MO.z
        }
        return pO
      }
      _convertToUnIndexedMesh() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = this.getVerticesDataKinds().filter((OO => !this.getVertexBuffer(OO)?.getIsInstanced())),
          pO = this.rFO(!1, !0),
          XO = {},
          bK = (OO, KO) => {
            const XO = new Float32Array(pO.length * KO);
            let bK = 0;
            for (let eO = 0; eO < pO.length; eO++)
              for (let lO = 0; lO < KO; lO++) XO[bK++] = OO[pO[eO] * KO + lO];
            return XO
          },
          eO = this.hpO(),
          lO = this.geometry ? this.au.slice(0) : [];
        for (const vK of KO) XO[vK] = this.getVerticesData(vK);
        for (const vK of KO) {
          const KO = this.getVertexBuffer(vK),
            eO = KO.getSize();
          if (OO && vK === uO.j.NormalKind) {
            const OO = this._getFlattenedNormals(pO, XO[uO.j.PositionKind]);
            this.setVerticesData(uO.j.NormalKind, OO, KO.isUpdatable(), eO)
          } else this.setVerticesData(vK, bK(XO[vK], eO), KO.isUpdatable(), eO)
        }
        if (this.morphTargetManager) {
          for (let KO = 0; KO < this.morphTargetManager.numTargets; KO++) {
            const XO = this.morphTargetManager.getTarget(KO),
              eO = XO.getPositions();
            XO.mFO(bK(eO, 3));
            const lO = XO.getNormals();
            lO && XO.setNormals(OO ? this._getFlattenedNormals(pO, eO) : bK(lO, 3));
            const vK = XO.getTangents();
            vK && XO.setTangents(bK(vK, 3));
            const CO = XO.getUVs();
            CO && XO.setUVs(bK(CO, 2));
            const hO = XO.getColors();
            hO && XO.setColors(bK(hO, 4))
          }
          this.morphTargetManager.synchronize()
        }
        for (let vK = 0; vK < pO.length; vK++) pO[vK] = vK;
        this.setIndices(pO), this._unIndexed = !0, this.releaseSubMeshes();
        for (const vK of lO) {
          const OO = vK.hpO();
          wO.b.AddToMesh(vK.materialIndex, vK.indexStart, vK.indexCount, vK.indexStart, vK.indexCount, this).setBoundingInfo(OO)
        }
        return this.setBoundingInfo(eO), this.synchronizeInstances(), this
      }
      convertToFlatShadedMesh() {
        return this._convertToUnIndexedMesh(!0)
      }
      convertToUnIndexedMesh() {
        return this._convertToUnIndexedMesh()
      }
      flipFaces() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = EO.e.ExtractFromMesh(this);
        let pO;
        if (OO && this.isVerticesDataPresent(uO.j.NormalKind) && KO.normals) {
          for (pO = 0; pO < KO.normals.length; pO++) KO.normals[pO] *= -1;
          this.setVerticesData(uO.j.NormalKind, KO.normals, this.isVertexBufferUpdatable(uO.j.NormalKind))
        }
        if (KO.indices) {
          let OO;
          for (pO = 0; pO < KO.indices.length; pO += 3) OO = KO.indices[pO + 1], KO.indices[pO + 1] = KO.indices[pO + 2], KO.indices[pO + 2] = OO;
          this.setIndices(KO.indices, null, this.isVertexBufferUpdatable(uO.j.PositionKind), !0)
        }
        return this
      }
      increaseVertices() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
        const KO = EO.e.ExtractFromMesh(this),
          pO = KO.indices && !Array.isArray(KO.indices) && Array.from ? Array.from(KO.indices) : KO.indices,
          XO = KO.positions && !Array.isArray(KO.positions) && Array.from ? Array.from(KO.positions) : KO.positions,
          bK = KO.uvs && !Array.isArray(KO.uvs) && Array.from ? Array.from(KO.uvs) : KO.uvs,
          eO = KO.normals && !Array.isArray(KO.normals) && Array.from ? Array.from(KO.normals) : KO.normals;
        if (pO && XO) {
          KO.indices = pO, KO.positions = XO, bK && (KO.uvs = bK), eO && (KO.normals = eO);
          const lO = OO + 1,
            vK = [];
          for (let OO = 0; OO < lO + 1; OO++) vK[OO] = [];
          let CO, hO;
          const DO = new IO.o(0, 0, 0),
            MO = new IO.o(0, 0, 0),
            aK = new IO.m(0, 0),
            oO = [],
            FO = [],
            VO = [];
          let LO, QO, zK, AO = XO.length;
          bK && (QO = bK.length), eO && (zK = eO.length);
          for (let OO = 0; OO < pO.length; OO += 3) {
            FO[0] = pO[OO], FO[1] = pO[OO + 1], FO[2] = pO[OO + 2];
            for (let OO = 0; OO < 3; OO++)
              if (CO = FO[OO], hO = FO[(OO + 1) % 3], void 0 === VO[CO] && void 0 === VO[hO] ? (VO[CO] = [], VO[hO] = []) : (void 0 === VO[CO] && (VO[CO] = []), void 0 === VO[hO] && (VO[hO] = [])), void 0 === VO[CO][hO] && void 0 === VO[hO][CO]) {
                VO[CO][hO] = [], DO.x = (XO[3 * hO] - XO[3 * CO]) / lO, DO.y = (XO[3 * hO + 1] - XO[3 * CO + 1]) / lO, DO.z = (XO[3 * hO + 2] - XO[3 * CO + 2]) / lO, eO && (MO.x = (eO[3 * hO] - eO[3 * CO]) / lO, MO.y = (eO[3 * hO + 1] - eO[3 * CO + 1]) / lO, MO.z = (eO[3 * hO + 2] - eO[3 * CO + 2]) / lO), bK && (aK.x = (bK[2 * hO] - bK[2 * CO]) / lO, aK.y = (bK[2 * hO + 1] - bK[2 * CO + 1]) / lO), VO[CO][hO].push(CO);
                for (let OO = 1; OO < lO; OO++) VO[CO][hO].push(XO.length / 3), XO[AO++] = XO[3 * CO] + OO * DO.x, XO[AO++] = XO[3 * CO + 1] + OO * DO.y, XO[AO++] = XO[3 * CO + 2] + OO * DO.z, eO && (eO[zK++] = eO[3 * CO] + OO * MO.x, eO[zK++] = eO[3 * CO + 1] + OO * MO.y, eO[zK++] = eO[3 * CO + 2] + OO * MO.z), bK && (bK[QO++] = bK[2 * CO] + OO * aK.x, bK[QO++] = bK[2 * CO + 1] + OO * aK.y);
                VO[CO][hO].push(hO), VO[hO][CO] = [], LO = VO[CO][hO].length;
                for (let OO = 0; OO < LO; OO++) VO[hO][CO][OO] = VO[CO][hO][LO - 1 - OO]
              } vK[0][0] = pO[OO], vK[1][0] = VO[pO[OO]][pO[OO + 1]][1], vK[1][1] = VO[pO[OO]][pO[OO + 2]][1];
            for (let KO = 2; KO < lO; KO++) {
              vK[KO][0] = VO[pO[OO]][pO[OO + 1]][KO], vK[KO][KO] = VO[pO[OO]][pO[OO + 2]][KO], DO.x = (XO[3 * vK[KO][KO]] - XO[3 * vK[KO][0]]) / KO, DO.y = (XO[3 * vK[KO][KO] + 1] - XO[3 * vK[KO][0] + 1]) / KO, DO.z = (XO[3 * vK[KO][KO] + 2] - XO[3 * vK[KO][0] + 2]) / KO, eO && (MO.x = (eO[3 * vK[KO][KO]] - eO[3 * vK[KO][0]]) / KO, MO.y = (eO[3 * vK[KO][KO] + 1] - eO[3 * vK[KO][0] + 1]) / KO, MO.z = (eO[3 * vK[KO][KO] + 2] - eO[3 * vK[KO][0] + 2]) / KO), bK && (aK.x = (bK[2 * vK[KO][KO]] - bK[2 * vK[KO][0]]) / KO, aK.y = (bK[2 * vK[KO][KO] + 1] - bK[2 * vK[KO][0] + 1]) / KO);
              for (let OO = 1; OO < KO; OO++) vK[KO][OO] = XO.length / 3, XO[AO++] = XO[3 * vK[KO][0]] + OO * DO.x, XO[AO++] = XO[3 * vK[KO][0] + 1] + OO * DO.y, XO[AO++] = XO[3 * vK[KO][0] + 2] + OO * DO.z, eO && (eO[zK++] = eO[3 * vK[KO][0]] + OO * MO.x, eO[zK++] = eO[3 * vK[KO][0] + 1] + OO * MO.y, eO[zK++] = eO[3 * vK[KO][0] + 2] + OO * MO.z), bK && (bK[QO++] = bK[2 * vK[KO][0]] + OO * aK.x, bK[QO++] = bK[2 * vK[KO][0] + 1] + OO * aK.y)
            }
            vK[lO] = VO[pO[OO + 1]][pO[OO + 2]], oO.push(vK[0][0], vK[1][0], vK[1][1]);
            for (let OO = 1; OO < lO; OO++) {
              let KO;
              for (KO = 0; KO < OO; KO++) oO.push(vK[OO][KO], vK[OO + 1][KO], vK[OO + 1][KO + 1]), oO.push(vK[OO][KO], vK[OO + 1][KO + 1], vK[OO][KO + 1]);
              oO.push(vK[OO][KO], vK[OO + 1][KO], vK[OO + 1][KO + 1])
            }
          }
          KO.indices = oO, KO.applyToMesh(this, this.isVertexBufferUpdatable(uO.j.PositionKind))
        } else HO.b.Warn("Couldn't increase number of vertices : VertexData must contain at least indices and positions")
      }
      forceSharedVertices() {
        const OO = EO.e.ExtractFromMesh(this),
          KO = OO.uvs,
          pO = OO.indices,
          XO = OO.positions,
          bK = OO.colors,
          eO = OO.matricesIndices,
          lO = OO.matricesWeights,
          vK = OO.matricesIndicesExtra,
          CO = OO.matricesWeightsExtra;
        if (void 0 === pO || void 0 === XO || null === pO || null === XO) HO.b.Warn("VertexData contains empty entries");
        else {
          const hO = [],
            DO = [],
            MO = [],
            aK = [],
            oO = [],
            FO = [],
            VO = [],
            LO = [];
          let QO, zK = 0;
          const AO = {};
          let fO, dO;
          for (let OO = 0; OO < pO.length; OO += 3) {
            dO = [pO[OO], pO[OO + 1], pO[OO + 2]], QO = [];
            for (let OO = 0; OO < 3; OO++) {
              QO[OO] = "";
              for (let KO = 0; KO < 3; KO++) Math.abs(XO[3 * dO[OO] + KO]) < 1e-8 && (XO[3 * dO[OO] + KO] = 0), QO[OO] += XO[3 * dO[OO] + KO] + "|"
            }
            if (QO[0] != QO[1] && QO[0] != QO[2] && QO[1] != QO[2])
              for (let OO = 0; OO < 3; OO++) {
                if (fO = AO[QO[OO]], void 0 === fO) {
                  AO[QO[OO]] = zK, fO = zK++;
                  for (let KO = 0; KO < 3; KO++) hO.push(XO[3 * dO[OO] + KO]);
                  if (null !== bK && void 0 !== bK)
                    for (let KO = 0; KO < 4; KO++) aK.push(bK[4 * dO[OO] + KO]);
                  if (null !== KO && void 0 !== KO)
                    for (let pO = 0; pO < 2; pO++) MO.push(KO[2 * dO[OO] + pO]);
                  if (null !== eO && void 0 !== eO)
                    for (let KO = 0; KO < 4; KO++) oO.push(eO[4 * dO[OO] + KO]);
                  if (null !== lO && void 0 !== lO)
                    for (let KO = 0; KO < 4; KO++) FO.push(lO[4 * dO[OO] + KO]);
                  if (null !== vK && void 0 !== vK)
                    for (let KO = 0; KO < 4; KO++) VO.push(vK[4 * dO[OO] + KO]);
                  if (null !== CO && void 0 !== CO)
                    for (let KO = 0; KO < 4; KO++) LO.push(CO[4 * dO[OO] + KO])
                }
                DO.push(fO)
              }
          }
          const TO = [];
          EO.e.ComputeNormals(hO, DO, TO), OO.positions = hO, OO.indices = DO, OO.normals = TO, null !== KO && void 0 !== KO && (OO.uvs = MO), null !== bK && void 0 !== bK && (OO.colors = aK), null !== eO && void 0 !== eO && (OO.matricesIndices = oO), null !== lO && void 0 !== lO && (OO.matricesWeights = FO), null !== vK && void 0 !== vK && (OO.matricesIndicesExtra = VO), null !== lO && void 0 !== lO && (OO.matricesWeightsExtra = LO), OO.applyToMesh(this, this.isVertexBufferUpdatable(uO.j.PositionKind))
        }
      }
      static _instancedMeshFactory(OO, KO) {
        throw (0, SO.j)("InstancedMesh")
      }
      static _PhysicsImpostorParser(OO, KO, pO) {
        throw (0, SO.j)("PhysicsImpostor")
      }
      createInstance(OO) {
        const KO = tK._instancedMeshFactory(OO, this);
        return KO.parent = this.parent, KO
      }
      synchronizeInstances() {
        for (let OO = 0; OO < this.instances.length; OO++) {
          this.instances[OO]._syncSubMeshes()
        }
        return this
      }
      optimizeIndices(OO) {
        const KO = this.rFO(),
          pO = this.getVerticesData(uO.j.PositionKind);
        if (!pO || !KO) return this;
        const XO = [];
        for (let eO = 0; eO < pO.length; eO += 3) XO.push(IO.o.FromArray(pO, eO));
        const bK = [];
        return zK.e.SyncAsyncForLoop(XO.length, 40, (OO => {
          const KO = XO.length - 1 - OO,
            pO = XO[KO];
          for (let eO = 0; eO < KO; ++eO) {
            const OO = XO[eO];
            if (pO.equals(OO)) {
              bK[KO] = eO;
              break
            }
          }
        }), (() => {
          for (let OO = 0; OO < KO.length; ++OO) KO[OO] = bK[KO[OO]] || KO[OO];
          const pO = this.au.slice(0);
          this.setIndices(KO), this.au = pO, OO && OO(this)
        })), this
      }
      serialize() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        OO.name = this.name, OO.id = this.id, OO.uniqueId = this.uniqueId, OO.type = this.getClassName(), dO.b && dO.b.HasTags(this) && (OO.tags = dO.b.GetTags(this)), OO.position = this.position.WhO(), this.rotationQuaternion ? OO.rotationQuaternion = this.rotationQuaternion.WhO() : this.rotation && (OO.rotation = this.rotation.WhO()), OO.ol = this.ol.WhO(), this._postMultiplyPivotMatrix ? OO.pivotMatrix = this.getPivotMatrix().WhO() : OO.localMatrix = this.getPivotMatrix().WhO(), OO.isEnabled = this.isEnabled(!1), OO.isVisible = this.isVisible, OO.infiniteDistance = this.infiniteDistance, OO.pickable = this.De, OO.receiveShadows = this.receiveShadows, OO.billboardMode = this.billboardMode, OO.visibility = this.visibility, OO.xb = this.xb, OO.checkCollisions = this.checkCollisions, OO.ellipsoid = this.ellipsoid.WhO(), OO.ellipsoidOffset = this.ellipsoidOffset.WhO(), OO.kb = this.kb, OO.isBlocker = this.isBlocker, OO.sideOrientation = this.sideOrientation, this._isWorldMatrixFrozen && (OO.qpO = !0), this.parent && this.parent._serializeAsParent(OO), OO.isUnIndexed = this.isUnIndexed;
        const KO = this._geometry;
        if (KO && this.au) {
          OO.geometryUniqueId = KO.uniqueId, OO.geometryId = KO.id, OO.au = [];
          for (let KO = 0; KO < this.au.length; KO++) {
            const pO = this.au[KO];
            OO.au.push({
              materialIndex: pO.materialIndex,
              verticesStart: pO.verticesStart,
              verticesCount: pO.verticesCount,
              indexStart: pO.indexStart,
              indexCount: pO.indexCount
            })
          }
        }
        if (this.material ? this.material.doNotSerialize || (OO.materialUniqueId = this.material.uniqueId, OO.materialId = this.material.id) : (this.material = null, OO.materialUniqueId = this._scene.defaultMaterial.uniqueId, OO.materialId = this._scene.defaultMaterial.id), this.morphTargetManager && (OO.morphTargetManagerId = this.morphTargetManager.uniqueId), this.skeleton && (OO.skeletonId = this.skeleton.id, OO.skeletonUniqueId = this.skeleton.uniqueId, OO.numBoneInfluencers = this.numBoneInfluencers), this.JKO()._getComponent(JO.d.NAME_PHYSICSENGINE)) {
          const KO = this.getPhysicsImpostor?.();
          KO && (OO.physicsMass = KO.getParam("Re"), OO.physicsFriction = KO.getParam("friction"), OO.physicsRestitution = KO.getParam("Re"), OO.physicsImpostor = KO.type)
        }
        this.metadata && (OO.metadata = this.metadata), 0 !== this.meshBlendingTag && (OO.meshBlendingTag = this.meshBlendingTag), OO.instances = [];
        for (let pO = 0; pO < this.instances.length; pO++) {
          const KO = this.instances[pO];
          if (KO.doNotSerialize) continue;
          const XO = {
            name: KO.name,
            id: KO.id,
            isEnabled: KO.isEnabled(!1),
            isVisible: KO.isVisible,
            De: KO.De,
            checkCollisions: KO.checkCollisions,
            position: KO.position.WhO(),
            ol: KO.ol.WhO()
          };
          if (KO.parent && KO.parent._serializeAsParent(XO), KO.rotationQuaternion ? XO.rotationQuaternion = KO.rotationQuaternion.WhO() : KO.rotation && (XO.rotation = KO.rotation.WhO()), this.JKO()._getComponent(JO.d.NAME_PHYSICSENGINE)) {
            const OO = KO.getPhysicsImpostor?.();
            OO && (XO.physicsMass = OO.getParam("Re"), XO.physicsFriction = OO.getParam("friction"), XO.physicsRestitution = OO.getParam("Re"), XO.physicsImpostor = OO.type)
          }
          KO.metadata && (XO.metadata = KO.metadata), KO.actionManager && (XO.actions = KO.actionManager.serialize(KO.name)), OO.instances.push(XO), sO.c.AppendSerializedAnimations(KO, XO), XO.Xl = KO.serializeAnimationRanges()
        }
        if (this._thinInstanceDataStorage.instancesCount && this._thinInstanceDataStorage.matrixData && (OO.thinInstances = {
            instancesCount: this._thinInstanceDataStorage.instancesCount,
            matrixData: Array.from(this._thinInstanceDataStorage.matrixData),
            matrixBufferSize: this._thinInstanceDataStorage.matrixBufferSize,
            enablePicking: this.fCO
          }, this._userThinInstanceBuffersStorage)) {
          const KO = {
            data: {},
            sizes: {},
            strides: {}
          };
          for (const OO in this._userThinInstanceBuffersStorage.data) KO.data[OO] = Array.from(this._userThinInstanceBuffersStorage.data[OO]), KO.sizes[OO] = this._userThinInstanceBuffersStorage.sizes[OO], KO.strides[OO] = this._userThinInstanceBuffersStorage.strides[OO];
          OO.thinInstances.userThinInstance = KO
        }
        return sO.c.AppendSerializedAnimations(this, OO), OO.Xl = this.serializeAnimationRanges(), OO.layerMask = this.layerMask, OO.alphaIndex = this.alphaIndex, OO.hasVertexAlpha = this.hasVertexAlpha, OO.overlayAlpha = this.overlayAlpha, OO.overlayColor = this.overlayColor.WhO(), OO.renderOverlay = this.renderOverlay, OO.applyFog = this.applyFog, this.actionManager && (OO.actions = this.actionManager.serialize(this.name)), OO
      }
      _syncGeometryWithMorphTargetManager() {
        if (!this.geometry) return;
        this._markSubMeshesAsAttributesDirty();
        const OO = this._internalAbstractMeshDataInfo._morphTargetManager;
        if (OO && OO.vertexCount) {
          if (OO.vertexCount !== this.getTotalVertices()) return HO.b.Error("Mesh is incompatible with morph targets. Targets and mesh must all have the same vertices count."), void(this.morphTargetManager = null);
          if (OO.isUsingTextureForTargets) return;
          for (let KO = 0; KO < OO.numInfluencers; KO++) {
            const pO = OO.getActiveTarget(KO),
              XO = pO.getPositions();
            if (!XO) return void HO.b.Error("Invalid morph target. Target must have positions.");
            this.geometry.setVerticesData(uO.j.PositionKind + KO, XO, !1, 3);
            const bK = pO.getNormals();
            bK && this.geometry.setVerticesData(uO.j.NormalKind + KO, bK, !1, 3);
            const eO = pO.getTangents();
            eO && this.geometry.setVerticesData(uO.j.TangentKind + KO, eO, !1, 3);
            const lO = pO.getUVs();
            lO && this.geometry.setVerticesData(uO.j.UVKind + "_" + KO, lO, !1, 2);
            const vK = pO.getUV2s();
            vK && this.geometry.setVerticesData(uO.j.UV2Kind + "_" + KO, vK, !1, 2);
            const CO = pO.getColors();
            CO && this.geometry.setVerticesData(uO.j.ColorKind + KO, CO, !1, 4)
          }
        } else {
          let OO = 0;
          for (; this.geometry.isVerticesDataPresent(uO.j.PositionKind + OO);) this.geometry.removeVerticesData(uO.j.PositionKind + OO), this.geometry.isVerticesDataPresent(uO.j.NormalKind + OO) && this.geometry.removeVerticesData(uO.j.NormalKind + OO), this.geometry.isVerticesDataPresent(uO.j.TangentKind + OO) && this.geometry.removeVerticesData(uO.j.TangentKind + OO), this.geometry.isVerticesDataPresent(uO.j.UVKind + "_" + OO) && this.geometry.removeVerticesData(uO.j.UVKind + "_" + OO), this.geometry.isVerticesDataPresent(uO.j.UV2Kind + "_" + OO) && this.geometry.removeVerticesData(uO.j.UV2Kind + "_" + OO), this.geometry.isVerticesDataPresent(uO.j.ColorKind + OO) && this.geometry.removeVerticesData(uO.j.ColorKind + OO), OO++
        }
      }
      static Parse(OO, KO, pO) {
        let XO, bK = !1;
        if (OO.type && "LinesMesh" === OO.type ? XO = tK._LinesMeshParser(OO, KO) : OO.type && "GroundMesh" === OO.type ? XO = tK._GroundMeshParser(OO, KO) : OO.type && "GoldbergMesh" === OO.type ? XO = tK._GoldbergMeshParser(OO, KO) : OO.type && "GreasedLineMesh" === OO.type ? XO = tK._GreasedLineMeshParser(OO, KO) : OO.type && "TrailMesh" === OO.type ? XO = tK._TrailMeshParser(OO, KO) : OO.type && "GaussianSplattingMesh" === OO.type ? (XO = OO._isCompound ? tK._GaussianSplattingCompoundMeshParser(OO, KO) : tK._GaussianSplattingMeshParser(OO, KO), bK = !0) : OO.type && "GaussianSplattingPartProxyMesh" === OO.type ? (XO = tK._GaussianSplattingPartProxyMeshParser(OO, KO), bK = !0) : XO = new tK(OO.name, KO), XO.id = OO.id, XO._waitingParsedUniqueId = OO.uniqueId, dO.b && dO.b.AddTagsTo(XO, OO.tags), XO.position = IO.o.FromArray(OO.position), void 0 !== OO.metadata && (XO.metadata = OO.metadata), void 0 !== OO.meshBlendingTag && (XO.meshBlendingTag = OO.meshBlendingTag), OO.rotationQuaternion ? XO.rotationQuaternion = IO.g.FromArray(OO.rotationQuaternion) : OO.rotation && (XO.rotation = IO.o.FromArray(OO.rotation)), XO.ol = IO.o.FromArray(OO.ol), OO.localMatrix ? XO.setPreTransformMatrix(IO.c.FromArray(OO.localMatrix)) : OO.pivotMatrix && XO.setPivotMatrix(IO.c.FromArray(OO.pivotMatrix)), XO.WE(OO.isEnabled), XO.isVisible = OO.isVisible, XO.infiniteDistance = OO.infiniteDistance, XO.xb = !!OO.xb, XO.showBoundingBox = OO.showBoundingBox, XO.showSubMeshesBoundingBox = OO.showSubMeshesBoundingBox, void 0 !== OO.applyFog && (XO.applyFog = OO.applyFog), void 0 !== OO.pickable && (XO.De = OO.pickable), void 0 !== OO.alphaIndex && (XO.alphaIndex = OO.alphaIndex), XO.receiveShadows = OO.receiveShadows, void 0 !== OO.billboardMode && (XO.billboardMode = OO.billboardMode), void 0 !== OO.visibility && (XO.visibility = OO.visibility), XO.checkCollisions = OO.checkCollisions, XO.kb = !!OO.kb, OO.ellipsoid && (XO.ellipsoid = IO.o.FromArray(OO.ellipsoid)), OO.ellipsoidOffset && (XO.ellipsoidOffset = IO.o.FromArray(OO.ellipsoidOffset)), null != OO.overrideMaterialSideOrientation && (XO.sideOrientation = OO.overrideMaterialSideOrientation), void 0 !== OO.sideOrientation && (XO.sideOrientation = OO.sideOrientation), void 0 !== OO.isBlocker && (XO.isBlocker = OO.isBlocker), XO._shouldGenerateFlatShading = OO.useFlatShading, OO.qpO && (XO._waitingData.qpO = OO.qpO), void 0 !== OO.parentId && (XO._waitingParentId = OO.parentId), void 0 !== OO.parentInstanceIndex && (XO._waitingParentInstanceIndex = OO.parentInstanceIndex), void 0 !== OO.actions && (XO._waitingData.actions = OO.actions), void 0 !== OO.overlayAlpha && (XO.overlayAlpha = OO.overlayAlpha), void 0 !== OO.overlayColor && (XO.overlayColor = yK.e.FromArray(OO.overlayColor)), void 0 !== OO.renderOverlay && (XO.renderOverlay = OO.renderOverlay), XO.isUnIndexed = !!OO.isUnIndexed, XO.hasVertexAlpha = OO.hasVertexAlpha, OO.delayLoadingFile ? (XO.delayLoadState = 4, XO.delayLoadingFile = pO + OO.delayLoadingFile, XO.buildBoundingInfo(IO.o.FromArray(OO.boundingBoxMinimum), IO.o.FromArray(OO.boundingBoxMaximum)), OO._binaryInfo && (XO._binaryInfo = OO._binaryInfo), XO._delayInfo = [], OO.hasUVs && XO._delayInfo.push(uO.j.UVKind), OO.hasUVs2 && XO._delayInfo.push(uO.j.UV2Kind), OO.hasUVs3 && XO._delayInfo.push(uO.j.UV3Kind), OO.hasUVs4 && XO._delayInfo.push(uO.j.UV4Kind), OO.hasUVs5 && XO._delayInfo.push(uO.j.UV5Kind), OO.hasUVs6 && XO._delayInfo.push(uO.j.UV6Kind), OO.hasColors && XO._delayInfo.push(uO.j.ColorKind), OO.hasMatricesIndices && XO._delayInfo.push(uO.j.MatricesIndicesKind), OO.hasMatricesWeights && XO._delayInfo.push(uO.j.MatricesWeightsKind), XO._delayLoadingFunction = jK.e._ImportGeometry, mK.d.ForceFullSceneLoadingForIncremental && XO._checkDelayState()) : bK || jK.e._ImportGeometry(OO, XO), OO.materialUniqueId ? XO._waitingMaterialId = OO.materialUniqueId : OO.materialId && (XO._waitingMaterialId = OO.materialId), OO.morphTargetManagerId > -1 && (XO._waitingMorphTargetManagerId = OO.morphTargetManagerId), void 0 !== OO.skeletonId && null !== OO.skeletonId && (XO.skeleton = KO.getLastSkeletonById(OO.skeletonId), XO._waitingSkeletonId = OO.skeletonId, OO.numBoneInfluencers && (XO.numBoneInfluencers = OO.numBoneInfluencers)), void 0 !== OO.skeletonUniqueId && null !== OO.skeletonUniqueId && (XO._waitingSkeletonUniqueId = OO.skeletonUniqueId), OO.animations) {
          for (let KO = 0; KO < OO.animations.length; KO++) {
            const pO = OO.animations[KO],
              bK = (0, RO.e)("BABYLON.Animation");
            bK && XO.animations.push(bK.Parse(pO))
          }
          gK.c.ParseAnimationRanges(XO, OO, KO)
        }
        if (OO.autoAnimate && KO.beginAnimation(XO, OO.autoAnimateFrom, OO.autoAnimateTo, OO.autoAnimateLoop, OO.autoAnimateSpeed || 1), OO.layerMask && !isNaN(OO.layerMask) ? XO.layerMask = Math.abs(parseInt(OO.layerMask)) : XO.layerMask = 268435455, OO.physicsImpostor && (XO.physicsImpostor = tK._PhysicsImpostorParser(KO, XO, OO)), OO.lodMeshIds && (XO._waitingData.lods = {
            ids: OO.lodMeshIds,
            distances: OO.lodDistances ? OO.lodDistances : null,
            coverages: OO.lodCoverages ? OO.lodCoverages : null
          }), OO.instances)
          for (let eO = 0; eO < OO.instances.length; eO++) {
            const pO = OO.instances[eO],
              bK = XO.createInstance(pO.name);
            if (pO.id && (bK.id = pO.id), dO.b && (pO.tags ? dO.b.AddTagsTo(bK, pO.tags) : dO.b.AddTagsTo(bK, OO.tags)), bK.position = IO.o.FromArray(pO.position), void 0 !== pO.metadata && (bK.metadata = pO.metadata), void 0 !== pO.parentId && (bK._waitingParentId = pO.parentId), void 0 !== pO.parentInstanceIndex && (bK._waitingParentInstanceIndex = pO.parentInstanceIndex), void 0 !== pO.isEnabled && null !== pO.isEnabled && bK.WE(pO.isEnabled), void 0 !== pO.isVisible && null !== pO.isVisible && (bK.isVisible = pO.isVisible), void 0 !== pO.De && null !== pO.De && (bK.De = pO.De), pO.rotationQuaternion ? bK.rotationQuaternion = IO.g.FromArray(pO.rotationQuaternion) : pO.rotation && (bK.rotation = IO.o.FromArray(pO.rotation)), bK.ol = IO.o.FromArray(pO.ol), void 0 != pO.checkCollisions && null != pO.checkCollisions && (bK.checkCollisions = pO.checkCollisions), void 0 != pO.pickable && null != pO.pickable && (bK.De = pO.pickable), void 0 != pO.showBoundingBox && null != pO.showBoundingBox && (bK.showBoundingBox = pO.showBoundingBox), void 0 != pO.showSubMeshesBoundingBox && null != pO.showSubMeshesBoundingBox && (bK.showSubMeshesBoundingBox = pO.showSubMeshesBoundingBox), void 0 != pO.alphaIndex && null != pO.showSubMeshesBoundingBox && (bK.alphaIndex = pO.alphaIndex), pO.physicsImpostor && (bK.physicsImpostor = tK._PhysicsImpostorParser(KO, bK, pO)), void 0 !== pO.actions && (bK._waitingData.actions = pO.actions), pO.animations) {
              for (let OO = 0; OO < pO.animations.length; OO++) {
                const KO = pO.animations[OO],
                  XO = (0, RO.e)("BABYLON.Animation");
                XO && bK.animations.push(XO.Parse(KO))
              }
              gK.c.ParseAnimationRanges(bK, pO, KO), pO.autoAnimate && KO.beginAnimation(bK, pO.autoAnimateFrom, pO.autoAnimateTo, pO.autoAnimateLoop, pO.autoAnimateSpeed || 1)
            }
          }
        if (OO.thinInstances) {
          const KO = OO.thinInstances;
          if (XO.fCO = !!KO.enablePicking, KO.matrixData ? (XO.ulO("matrix", new Float32Array(KO.matrixData), 16, !1), XO._thinInstanceDataStorage.matrixBufferSize = KO.matrixBufferSize, XO._thinInstanceDataStorage.instancesCount = KO.instancesCount) : XO._thinInstanceDataStorage.matrixBufferSize = KO.matrixBufferSize, OO.thinInstances.userThinInstance) {
            const KO = OO.thinInstances.userThinInstance;
            for (const OO in KO.data) XO.ulO(OO, new Float32Array(KO.data[OO]), KO.strides[OO], !1), XO._userThinInstanceBuffersStorage.sizes[OO] = KO.sizes[OO]
          }
        }
        return XO
      }
      setPositionsForCPUSkinning() {
        const OO = this._internalMeshDataInfo;
        if (!OO._sourcePositions) {
          const KO = this.getVerticesData(uO.j.PositionKind);
          if (!KO) return OO._sourcePositions;
          OO._sourcePositions = new Float32Array(KO), this.isVertexBufferUpdatable(uO.j.PositionKind) || this.setVerticesData(uO.j.PositionKind, KO, !0)
        }
        return OO._sourcePositions
      }
      setNormalsForCPUSkinning() {
        const OO = this._internalMeshDataInfo;
        if (!OO._sourceNormals) {
          const KO = this.getVerticesData(uO.j.NormalKind);
          if (!KO) return OO._sourceNormals;
          OO._sourceNormals = new Float32Array(KO), this.isVertexBufferUpdatable(uO.j.NormalKind) || this.setVerticesData(uO.j.NormalKind, KO, !0)
        }
        return OO._sourceNormals
      }
      applySkeleton(OO) {
        if (!this.geometry) return this;
        if (this.geometry._softwareSkinningFrameId == this.JKO().getFrameId()) return this;
        if (this.geometry._softwareSkinningFrameId = this.JKO().getFrameId(), !this.isVerticesDataPresent(uO.j.PositionKind)) return this;
        if (!this.isVerticesDataPresent(uO.j.MatricesIndicesKind)) return this;
        if (!this.isVerticesDataPresent(uO.j.MatricesWeightsKind)) return this;
        const KO = this.isVerticesDataPresent(uO.j.NormalKind),
          pO = this._internalMeshDataInfo;
        if (!pO._sourcePositions) {
          const OO = this.au.slice();
          this.setPositionsForCPUSkinning(), this.au = OO
        }
        KO && !pO._sourceNormals && this.setNormalsForCPUSkinning();
        let XO = this.getVerticesData(uO.j.PositionKind);
        if (!XO) return this;
        XO instanceof Float32Array || (XO = new Float32Array(XO));
        let bK = this.getVerticesData(uO.j.NormalKind);
        if (KO) {
          if (!bK) return this;
          bK instanceof Float32Array || (bK = new Float32Array(bK))
        }
        const eO = this.getVerticesData(uO.j.MatricesIndicesKind),
          lO = this.getVerticesData(uO.j.MatricesWeightsKind);
        if (!lO || !eO) return this;
        const vK = this.numBoneInfluencers > 4,
          CO = vK ? this.getVerticesData(uO.j.MatricesIndicesExtraKind) : null,
          hO = vK ? this.getVerticesData(uO.j.MatricesWeightsExtraKind) : null,
          DO = OO.getTransformMatrices(this),
          MO = IO.o.Zero(),
          aK = new IO.c,
          oO = new IO.c;
        let FO, VO = 0;
        for (let LO = 0; LO < XO.length; LO += 3, VO += 4) {
          let OO;
          for (FO = 0; FO < 4; FO++) OO = lO[VO + FO], OO > 0 && (IO.c.FromFloat32ArrayToRefScaled(DO, Math.floor(16 * eO[VO + FO]), OO, oO), aK.addToSelf(oO));
          if (vK)
            for (FO = 0; FO < 4; FO++) OO = hO[VO + FO], OO > 0 && (IO.c.FromFloat32ArrayToRefScaled(DO, Math.floor(16 * CO[VO + FO]), OO, oO), aK.addToSelf(oO));
          IO.o.TransformCoordinatesFromFloatsToRef(pO._sourcePositions[LO], pO._sourcePositions[LO + 1], pO._sourcePositions[LO + 2], aK, MO), MO.toArray(XO, LO), KO && (IO.o.TransformNormalFromFloatsToRef(pO._sourceNormals[LO], pO._sourceNormals[LO + 1], pO._sourceNormals[LO + 2], aK, MO), MO.toArray(bK, LO)), aK.reset()
        }
        return this.updateVerticesData(uO.j.PositionKind, XO), KO && this.updateVerticesData(uO.j.NormalKind, bK), this
      }
      static MinMax(OO) {
        let KO = null,
          pO = null;
        for (const XO of OO) {
          const OO = XO.hpO().boundingBox;
          KO && pO ? (KO.minimizeInPlace(OO.minimumWorld), pO.maximizeInPlace(OO.maximumWorld)) : (KO = OO.minimumWorld.clone(), pO = OO.maximumWorld.clone())
        }
        return KO && pO ? {
          min: KO,
          max: pO
        } : {
          min: IO.o.Zero(),
          max: IO.o.Zero()
        }
      }
      static Center(OO) {
        const KO = OO instanceof Array ? tK.MinMax(OO) : OO;
        return IO.o.Center(KO.min, KO.max)
      }
      static MergeMeshes(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0,
          bK = arguments.length > 4 ? arguments[4] : void 0,
          eO = arguments.length > 5 ? arguments[5] : void 0;
        return (0, TO.k)(tK._MergeMeshesCoroutine(OO, KO, pO, XO, bK, eO, !1))
      }
      static async MergeMeshesAsync(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0,
          bK = arguments.length > 4 ? arguments[4] : void 0,
          eO = arguments.length > 5 ? arguments[5] : void 0;
        return await (0, TO.i)(tK._MergeMeshesCoroutine(OO, KO, pO, XO, bK, eO, !0), (0, TO.e)())
      }
      static * _MergeMeshesCoroutine(OO) {
        let KO, pO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          XO = arguments.length > 2 ? arguments[2] : void 0,
          bK = arguments.length > 3 ? arguments[3] : void 0,
          eO = arguments.length > 4 ? arguments[4] : void 0,
          lO = arguments.length > 5 ? arguments[5] : void 0,
          vK = arguments.length > 6 ? arguments[6] : void 0;
        if (0 === (OO = OO.filter(Boolean)).length) return null;
        if (!XO) {
          let pO = 0;
          for (KO = 0; KO < OO.length; KO++)
            if (pO += OO[KO].getTotalVertices(), pO >= 65536) return HO.b.Warn("Cannot merge meshes because resulting mesh will have more than 65536 vertices. Please use allow32BitsIndices = true to use 32 bits indices"), null
        }
        const CO = OO[0];
        lO && (eO = !1, OO.sort(((OO, KO) => (OO.material?.uniqueId ?? -1) - (KO.material?.uniqueId ?? -1))));
        const hO = new Array,
          DO = new Array,
          MO = new Array,
          aK = OO[0].sideOrientation;
        for (KO = 0; KO < OO.length; KO++) {
          const pO = OO[KO];
          if (pO.BKO) return HO.b.Warn("Cannot merge instance meshes."), null;
          if (aK !== pO.sideOrientation) return HO.b.Warn("Cannot merge meshes with different sideOrientation values."), null;
          if (eO || lO) {
            const OO = MO.reduce(((OO, KO) => Math.max(OO, KO.start + KO.count)), 0);
            if (lO)
              if (pO.material) {
                const KO = pO.material;
                if (KO instanceof PO.d) {
                  for (let OO = 0; OO < KO.jvO.length; OO++) hO.indexOf(KO.jvO[OO]) < 0 && hO.push(KO.jvO[OO]);
                  for (let XO = 0; XO < pO.au.length; XO++) DO.push(hO.indexOf(KO.jvO[pO.au[XO].materialIndex])), MO.push({
                    start: OO + pO.au[XO].indexStart,
                    count: pO.au[XO].indexCount
                  })
                } else {
                  hO.indexOf(KO) < 0 && hO.push(KO);
                  for (let XO = 0; XO < pO.au.length; XO++) DO.push(hO.indexOf(KO)), MO.push({
                    start: OO + pO.au[XO].indexStart,
                    count: pO.au[XO].indexCount
                  })
                }
              } else
                for (let KO = 0; KO < pO.au.length; KO++) DO.push(0), MO.push({
                  start: OO + pO.au[KO].indexStart,
                  count: pO.au[KO].indexCount
                });
            else MO.push({
              start: OO,
              count: pO.getTotalIndices()
            })
          }
        }
        if (lO && MO.length > 1) {
          let OO = 0;
          for (let KO = 1; KO < MO.length; KO++) {
            const pO = MO[OO],
              XO = MO[KO];
            DO[KO] === DO[OO] && pO.start + pO.count === XO.start ? pO.count += XO.count : (OO++, MO[OO] = XO, DO[OO] = DO[KO])
          }
          MO.length = OO + 1, DO.length = OO + 1
        }
        const oO = OO => {
            const KO = OO.computeWorldMatrix(!0);
            return {
              vertexData: EO.e.ExtractFromMesh(OO, !1, !1),
              transform: KO
            }
          },
          {
            vertexData: FO,
            transform: VO
          } = oO(OO[0]);
        vK && (yield);
        const LO = new Array(OO.length - 1);
        for (let TO = 1; TO < OO.length; TO++) LO[TO - 1] = oO(OO[TO]), vK && (yield);
        const QO = FO._mergeCoroutine(VO, LO, XO, vK, !pO);
        let zK = QO.next();
        for (; !zK.done;) vK && (yield), zK = QO.next();
        const AO = zK.value;
        bK || (bK = new tK(CO.name + "_merged", CO.JKO()));
        const fO = AO._applyToCoroutine(bK, void 0, vK);
        let dO = fO.next();
        for (; !dO.done;) vK && (yield), dO = fO.next();
        if (bK.checkCollisions = CO.checkCollisions, bK.sideOrientation = CO.sideOrientation, pO)
          for (KO = 0; KO < OO.length; KO++) OO[KO].dispose();
        if (eO || lO) {
          for (bK.releaseSubMeshes(), KO = 0; KO < MO.length;) wO.b.CreateFromIndices(0, MO[KO].start, MO[KO].count, bK, void 0, !1), KO++;
          for (const OO of bK.au) OO.refreshBoundingInfo();
          bK.computeWorldMatrix(!0)
        }
        if (lO) {
          const OO = new PO.d(CO.name + "_merged", CO.JKO());
          OO.jvO = hO;
          for (let KO = 0; KO < bK.au.length; KO++) bK.au[KO].materialIndex = DO[KO];
          bK.material = OO
        } else bK.material = CO.material;
        return bK
      }
      FlO(OO) {
        OO._indexInSourceMeshInstanceArray = this.instances.length, this.instances.push(OO)
      }
      zvO(OO) {
        const KO = OO._indexInSourceMeshInstanceArray;
        if (-1 != KO) {
          if (KO !== this.instances.length - 1) {
            const OO = this.instances[this.instances.length - 1];
            this.instances[KO] = OO, OO._indexInSourceMeshInstanceArray = KO
          }
          OO._indexInSourceMeshInstanceArray = -1, this.instances.pop()
        }
      }
      _shouldConvertRHS() {
        return this._scene.useRightHandedSystem && this.sideOrientation === iK.b.CounterClockWiseSideOrientation
      }
      _getRenderingFillMode(OO) {
        const KO = this.JKO();
        return KO.forcePointsCloud ? iK.b.PointFillMode : KO.forceWireframe ? iK.b.WireFrameFillMode : this.overrideRenderingFillMode ?? OO
      }
      setMaterialByID(OO) {
        return this.setMaterialById(OO)
      }
      static CreateRibbon(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateDisc(OO, KO, pO, XO, bK, eO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateBox(OO, KO, pO, XO, bK) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateSphere(OO, KO, pO, XO, bK, eO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateHemisphere(OO, KO, pO, XO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateCylinder(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateTorus(OO, KO, pO, XO, bK, eO, lO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateTorusKnot(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateLines(OO, KO, pO, XO, bK) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateDashedLines(OO, KO, pO, XO, bK, eO, lO, vK) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreatePolygon(OO, KO, pO, XO, bK, eO, lO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static ExtrudePolygon(OO, KO, pO, XO, bK, eO, lO, vK) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static ExtrudeShape(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static ExtrudeShapeCustom(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateLathe(OO, KO, pO, XO, bK, eO, lO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreatePlane(OO, KO, pO, XO, bK) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateGround(OO, KO, pO, XO, bK, eO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateTiledGround(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateGroundFromHeightMap(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateTube(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreatePolyhedron(OO, KO, pO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateIcoSphere(OO, KO, pO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateDecal(OO, KO, pO, XO, bK, eO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static CreateCapsule(OO, KO, pO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
      static ExtendToGoldberg(OO) {
        throw new Error("Import MeshBuilder to populate this function")
      }
    }
    tK.FRONTSIDE = EO.e.FRONTSIDE, tK.BACKSIDE = EO.e.BACKSIDE, tK.DOUBLESIDE = EO.e.DOUBLESIDE, tK.DEFAULTSIDE = EO.e.DEFAULTSIDE, tK.NO_CAP = 0, tK.CAP_START = 1, tK.CAP_END = 2, tK.CAP_ALL = 3, tK.NO_FLIP = 0, tK.FLIP_TILE = 1, tK.ROTATE_TILE = 2, tK.FLIP_ROW = 3, tK.ROTATE_ROW = 4, tK.FLIP_N_ROTATE_TILE = 5, tK.FLIP_N_ROTATE_ROW = 6, tK.CENTER = 0, tK.LEFT = 1, tK.RIGHT = 2, tK.TOP = 3, tK.BOTTOM = 4, tK.INSTANCEDMESH_SORT_TRANSPARENT = !1, tK._GroundMeshParser = (OO, KO) => {
      throw (0, SO.j)("GroundMesh")
    }, tK._GoldbergMeshParser = (OO, KO) => {
      throw (0, SO.j)("GoldbergMesh")
    }, tK._LinesMeshParser = (OO, KO) => {
      throw (0, SO.j)("LinesMesh")
    }, tK._GreasedLineMeshParser = (OO, KO) => {
      throw (0, SO.j)("GreasedLineMesh")
    }, tK._GreasedLineRibbonMeshParser = (OO, KO) => {
      throw (0, SO.j)("GreasedLineRibbonMesh")
    }, tK._TrailMeshParser = (OO, KO) => {
      throw (0, SO.j)("TrailMesh")
    }, tK._GaussianSplattingMeshParser = (OO, KO) => {
      throw (0, SO.j)("GaussianSplattingMesh")
    }, tK._GaussianSplattingPartProxyMeshParser = (OO, KO) => {
      throw (0, SO.j)("GaussianSplattingPartProxyMesh")
    }, tK._GaussianSplattingCompoundMeshParser = (OO, KO) => {
      throw (0, SO.j)("GaussianSplattingCompoundMesh")
    };
    let kK = !1;

    function UO() {
      kK || (kK = !0, (0, RO.h)("BABYLON.Mesh", tK))
    }(XO = tK.prototype).epO ?? (XO.epO = (0, SO.h)("Mesh", "epO")), (bK = tK.prototype).simplify ?? (bK.simplify = (0, SO.h)("Mesh", "simplify")), (eO = tK.prototype).thinInstanceAdd ?? (eO.thinInstanceAdd = (0, SO.h)("Mesh", "thinInstanceAdd")), (lO = tK.prototype).thinInstanceAddSelf ?? (lO.thinInstanceAddSelf = (0, SO.h)("Mesh", "thinInstanceAddSelf")), (vK = tK.prototype).thinInstanceRegisterAttribute ?? (vK.thinInstanceRegisterAttribute = (0, SO.h)("Mesh", "thinInstanceRegisterAttribute")), (CO = tK.prototype).thinInstanceSetMatrixAt ?? (CO.thinInstanceSetMatrixAt = (0, SO.h)("Mesh", "thinInstanceSetMatrixAt")), (hO = tK.prototype).thinInstanceSetAttributeAt ?? (hO.thinInstanceSetAttributeAt = (0, SO.h)("Mesh", "thinInstanceSetAttributeAt")), (DO = tK.prototype).ulO ?? (DO.ulO = (0, SO.h)("Mesh", "ulO")), (MO = tK.prototype).thinInstanceGetWorldMatrices ?? (MO.thinInstanceGetWorldMatrices = (0, SO.h)("Mesh", "thinInstanceGetWorldMatrices")), (aK = tK.prototype).TlO ?? (aK.TlO = (0, SO.h)("Mesh", "TlO")), (oO = tK.prototype).thinInstancePartialBufferUpdate ?? (oO.thinInstancePartialBufferUpdate = (0, SO.h)("Mesh", "thinInstancePartialBufferUpdate")), (FO = tK.prototype).thinInstanceRefreshBoundingInfo ?? (FO.thinInstanceRefreshBoundingInfo = (0, SO.h)("Mesh", "thinInstanceRefreshBoundingInfo")), (VO = tK.prototype).getEmittedParticleSystems ?? (VO.getEmittedParticleSystems = (0, SO.h)("Mesh", "getEmittedParticleSystems")), (LO = tK.prototype).getHierarchyEmittedParticleSystems ?? (LO.getHierarchyEmittedParticleSystems = (0, SO.h)("Mesh", "getHierarchyEmittedParticleSystems")), Object.getOwnPropertyDescriptor(tK.prototype, "edgesShareWithInstances") || Object.defineProperty(tK.prototype, "edgesShareWithInstances", (0, SO.e)("Mesh", "edgesShareWithInstances")), Object.getOwnPropertyDescriptor(tK.prototype, "fCO") || Object.defineProperty(tK.prototype, "fCO", (0, SO.e)("Mesh", "fCO")), Object.getOwnPropertyDescriptor(tK.prototype, "thinInstanceAllowAutomaticStaticBufferRecreation") || Object.defineProperty(tK.prototype, "thinInstanceAllowAutomaticStaticBufferRecreation", (0, SO.e)("Mesh", "thinInstanceAllowAutomaticStaticBufferRecreation")), Object.getOwnPropertyDescriptor(tK.prototype, "hlO") || Object.defineProperty(tK.prototype, "hlO", (0, SO.e)("Mesh", "hlO"))
  },
  38511: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => FO
    });
    var XO = pO(38063),
      bK = pO(35632),
      eO = pO(38216),
      lO = pO(37938),
      vK = pO(35688),
      CO = pO(37061),
      hO = pO(38066),
      DO = pO(38506),
      MO = pO(38120),
      aK = pO(38388);
    class oO {}
    let FO = (() => {
      var OO;
      let KO, pO, FO, VO, LO = [];
      return OO = class {
        constructor() {
          this.uniqueId = 0, this.metadata = {}, this._applyTo = (0, DO.f)(this._applyToCoroutine.bind(this)), this.uniqueId = OO._UniqueIdGenerator, OO._UniqueIdGenerator++
        }
        set(OO, KO) {
          switch (OO.length || CO.b.Warn(`Setting vertex data kind '${KO}' with an empty array`), KO) {
            case eO.j.PositionKind:
              this.positions = OO;
              break;
            case eO.j.NormalKind:
              this.normals = OO;
              break;
            case eO.j.TangentKind:
              this.tangents = OO;
              break;
            case eO.j.UVKind:
              this.uvs = OO;
              break;
            case eO.j.UV2Kind:
              this.uvs2 = OO;
              break;
            case eO.j.UV3Kind:
              this.uvs3 = OO;
              break;
            case eO.j.UV4Kind:
              this.uvs4 = OO;
              break;
            case eO.j.UV5Kind:
              this.uvs5 = OO;
              break;
            case eO.j.UV6Kind:
              this.uvs6 = OO;
              break;
            case eO.j.ColorKind:
              this.colors = OO;
              break;
            case eO.j.MatricesIndicesKind:
              this.matricesIndices = OO;
              break;
            case eO.j.MatricesWeightsKind:
              this.matricesWeights = OO;
              break;
            case eO.j.MatricesIndicesExtraKind:
              this.matricesIndicesExtra = OO;
              break;
            case eO.j.MatricesWeightsExtraKind:
              this.matricesWeightsExtra = OO
          }
        }
        applyToMesh(OO, KO) {
          return this._applyTo(OO, KO, !1), this
        }
        applyToGeometry(OO, KO) {
          return this._applyTo(OO, KO, !1), this
        }
        updateMesh(OO) {
          return this._update(OO), this
        }
        updateGeometry(OO) {
          return this._update(OO), this
        }* _applyToCoroutine(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            pO = arguments.length > 2 ? arguments[2] : void 0;
          if (this.positions && (OO.setVerticesData(eO.j.PositionKind, this.positions, KO), pO && (yield)), this.normals && (OO.setVerticesData(eO.j.NormalKind, this.normals, KO), pO && (yield)), this.tangents && (OO.setVerticesData(eO.j.TangentKind, this.tangents, KO), pO && (yield)), this.uvs && (OO.setVerticesData(eO.j.UVKind, this.uvs, KO), pO && (yield)), this.uvs2 && (OO.setVerticesData(eO.j.UV2Kind, this.uvs2, KO), pO && (yield)), this.uvs3 && (OO.setVerticesData(eO.j.UV3Kind, this.uvs3, KO), pO && (yield)), this.uvs4 && (OO.setVerticesData(eO.j.UV4Kind, this.uvs4, KO), pO && (yield)), this.uvs5 && (OO.setVerticesData(eO.j.UV5Kind, this.uvs5, KO), pO && (yield)), this.uvs6 && (OO.setVerticesData(eO.j.UV6Kind, this.uvs6, KO), pO && (yield)), this.colors) {
            const XO = this.positions && this.colors.length === this.positions.length ? 3 : 4;
            OO.setVerticesData(eO.j.ColorKind, this.colors, KO, XO), this.hasVertexAlpha && void 0 !== OO.hasVertexAlpha && (OO.hasVertexAlpha = !0), pO && (yield)
          }
          if (this.matricesIndices && (OO.setVerticesData(eO.j.MatricesIndicesKind, this.matricesIndices, KO), pO && (yield)), this.matricesWeights && (OO.setVerticesData(eO.j.MatricesWeightsKind, this.matricesWeights, KO), pO && (yield)), this.matricesIndicesExtra && (OO.setVerticesData(eO.j.MatricesIndicesExtraKind, this.matricesIndicesExtra, KO), pO && (yield)), this.matricesWeightsExtra && (OO.setVerticesData(eO.j.MatricesWeightsExtraKind, this.matricesWeightsExtra, KO), pO && (yield)), this.indices ? (OO.setIndices(this.indices, null, KO), pO && (yield)) : OO.setIndices([], null), OO.au && this.materialInfos && this.materialInfos.length > 1) {
            const KO = OO;
            KO.au = [];
            for (const OO of this.materialInfos) new aK.b(OO.materialIndex, OO.verticesStart, OO.verticesCount, OO.indexStart, OO.indexCount, KO)
          }
          return this
        }
        _update(OO, KO, pO) {
          return this.positions && OO.updateVerticesData(eO.j.PositionKind, this.positions, KO, pO), this.normals && OO.updateVerticesData(eO.j.NormalKind, this.normals, KO, pO), this.tangents && OO.updateVerticesData(eO.j.TangentKind, this.tangents, KO, pO), this.uvs && OO.updateVerticesData(eO.j.UVKind, this.uvs, KO, pO), this.uvs2 && OO.updateVerticesData(eO.j.UV2Kind, this.uvs2, KO, pO), this.uvs3 && OO.updateVerticesData(eO.j.UV3Kind, this.uvs3, KO, pO), this.uvs4 && OO.updateVerticesData(eO.j.UV4Kind, this.uvs4, KO, pO), this.uvs5 && OO.updateVerticesData(eO.j.UV5Kind, this.uvs5, KO, pO), this.uvs6 && OO.updateVerticesData(eO.j.UV6Kind, this.uvs6, KO, pO), this.colors && OO.updateVerticesData(eO.j.ColorKind, this.colors, KO, pO), this.matricesIndices && OO.updateVerticesData(eO.j.MatricesIndicesKind, this.matricesIndices, KO, pO), this.matricesWeights && OO.updateVerticesData(eO.j.MatricesWeightsKind, this.matricesWeights, KO, pO), this.matricesIndicesExtra && OO.updateVerticesData(eO.j.MatricesIndicesExtraKind, this.matricesIndicesExtra, KO, pO), this.matricesWeightsExtra && OO.updateVerticesData(eO.j.MatricesWeightsExtraKind, this.matricesWeightsExtra, KO, pO), this.indices && OO.setIndices(this.indices, null), this
        }
        static _TransformVector3Coordinates(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : OO.length;
          const eO = bK.j.WX[0],
            lO = bK.j.WX[1];
          for (let vK = pO; vK < pO + XO; vK += 3) bK.o.FromArrayToRef(OO, vK, eO), bK.o.TransformCoordinatesToRef(eO, KO, lO), OO[vK] = lO.x, OO[vK + 1] = lO.y, OO[vK + 2] = lO.z
        }
        static _TransformVector3Normals(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : OO.length;
          const eO = bK.j.WX[0],
            lO = bK.j.WX[1];
          for (let vK = pO; vK < pO + XO; vK += 3) bK.o.FromArrayToRef(OO, vK, eO), bK.o.TransformNormalToRef(eO, KO, lO), OO[vK] = lO.x, OO[vK + 1] = lO.y, OO[vK + 2] = lO.z
        }
        static _TransformVector4Normals(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : OO.length;
          const eO = bK.j.Vector4[0],
            lO = bK.j.Vector4[1];
          for (let vK = pO; vK < pO + XO; vK += 4) bK.s.FromArrayToRef(OO, vK, eO), bK.s.TransformNormalToRef(eO, KO, lO), OO[vK] = lO.x, OO[vK + 1] = lO.y, OO[vK + 2] = lO.z, OO[vK + 3] = lO.w
        }
        static _FlipFaces(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : OO.length;
          for (let XO = KO; XO < KO + pO; XO += 3) {
            const KO = OO[XO + 1];
            OO[XO + 1] = OO[XO + 2], OO[XO + 2] = KO
          }
        }
        transform(KO) {
          const pO = KO.determinant() < 0;
          return this.positions && OO._TransformVector3Coordinates(this.positions, KO), this.normals && OO._TransformVector3Normals(this.normals, KO), this.tangents && OO._TransformVector4Normals(this.tangents, KO), pO && this.indices && OO._FlipFaces(this.indices), this
        }
        splitBasedOnMaterialID() {
          if (!this.materialInfos || this.materialInfos.length < 2) return [this];
          const KO = [];
          for (const pO of this.materialInfos) {
            const XO = new OO;
            if (this.positions && (XO.positions = this.positions.slice(3 * pO.verticesStart, 3 * (pO.verticesCount + pO.verticesStart))), this.normals && (XO.normals = this.normals.slice(3 * pO.verticesStart, 3 * (pO.verticesCount + pO.verticesStart))), this.tangents && (XO.tangents = this.tangents.slice(4 * pO.verticesStart, 4 * (pO.verticesCount + pO.verticesStart))), this.colors && (XO.colors = this.colors.slice(4 * pO.verticesStart, 4 * (pO.verticesCount + pO.verticesStart))), this.uvs && (XO.uvs = this.uvs.slice(2 * pO.verticesStart, 2 * (pO.verticesCount + pO.verticesStart))), this.uvs2 && (XO.uvs2 = this.uvs2.slice(2 * pO.verticesStart, 2 * (pO.verticesCount + pO.verticesStart))), this.uvs3 && (XO.uvs3 = this.uvs3.slice(2 * pO.verticesStart, 2 * (pO.verticesCount + pO.verticesStart))), this.uvs4 && (XO.uvs4 = this.uvs4.slice(2 * pO.verticesStart, 2 * (pO.verticesCount + pO.verticesStart))), this.uvs5 && (XO.uvs5 = this.uvs5.slice(2 * pO.verticesStart, 2 * (pO.verticesCount + pO.verticesStart))), this.uvs6 && (XO.uvs6 = this.uvs6.slice(2 * pO.verticesStart, 2 * (pO.verticesCount + pO.verticesStart))), this.matricesIndices && (XO.matricesIndices = this.matricesIndices.slice(4 * pO.verticesStart, 4 * (pO.verticesCount + pO.verticesStart))), this.matricesIndicesExtra && (XO.matricesIndicesExtra = this.matricesIndicesExtra.slice(4 * pO.verticesStart, 4 * (pO.verticesCount + pO.verticesStart))), this.matricesWeights && (XO.matricesWeights = this.matricesWeights.slice(4 * pO.verticesStart, 4 * (pO.verticesCount + pO.verticesStart))), this.matricesWeightsExtra && (XO.matricesWeightsExtra = this.matricesWeightsExtra.slice(4 * pO.verticesStart, 4 * (pO.verticesCount + pO.verticesStart))), this.indices) {
              XO.indices = [];
              for (let OO = pO.indexStart; OO < pO.indexStart + pO.indexCount; OO++) XO.indices.push(this.indices[OO] - pO.verticesStart)
            }
            const bK = new oO;
            bK.indexStart = 0, bK.indexCount = XO.indices ? XO.indices.length : 0, bK.materialIndex = pO.materialIndex, bK.verticesStart = 0, bK.verticesCount = (XO.positions ? XO.positions.length : 0) / 3, XO.materialInfos = [bK], KO.push(XO)
          }
          return KO
        }
        merge(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
            XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
            bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
          const eO = Array.isArray(OO) ? OO.map((OO => ({
            vertexData: OO
          }))) : [{
            vertexData: OO
          }];
          return (0, DO.k)(this._mergeCoroutine(void 0, eO, KO, !1, pO, XO, bK))
        }* _mergeCoroutine(KO, pO) {
          let XO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
            bK = arguments.length > 3 ? arguments[3] : void 0,
            lO = arguments.length > 4 ? arguments[4] : void 0,
            vK = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
            CO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
          this._validate();
          let hO = pO.map((OO => OO.vertexData)),
            DO = this;
          if (CO)
            for (const OO of hO) OO && (OO._validate(), !this.normals && OO.normals && (this.normals = new Float32Array(this.positions.length)), !this.tangents && OO.tangents && (this.tangents = new Float32Array(this.positions.length / 3 * 4)), !this.uvs && OO.uvs && (this.uvs = new Float32Array(this.positions.length / 3 * 2)), !this.uvs2 && OO.uvs2 && (this.uvs2 = new Float32Array(this.positions.length / 3 * 2)), !this.uvs3 && OO.uvs3 && (this.uvs3 = new Float32Array(this.positions.length / 3 * 2)), !this.uvs4 && OO.uvs4 && (this.uvs4 = new Float32Array(this.positions.length / 3 * 2)), !this.uvs5 && OO.uvs5 && (this.uvs5 = new Float32Array(this.positions.length / 3 * 2)), !this.uvs6 && OO.uvs6 && (this.uvs6 = new Float32Array(this.positions.length / 3 * 2)), !this.colors && OO.colors && (this.colors = new Float32Array(this.positions.length / 3 * 4), this.colors.fill(1)), !this.matricesIndices && OO.matricesIndices && (this.matricesIndices = new Float32Array(this.positions.length / 3 * 4)), !this.matricesWeights && OO.matricesWeights && (this.matricesWeights = new Float32Array(this.positions.length / 3 * 4)), !this.matricesIndicesExtra && OO.matricesIndicesExtra && (this.matricesIndicesExtra = new Float32Array(this.positions.length / 3 * 4)), !this.matricesWeightsExtra && OO.matricesWeightsExtra && (this.matricesWeightsExtra = new Float32Array(this.positions.length / 3 * 4)));
          for (const OO of hO)
            if (OO)
              if (CO) this.normals && !OO.normals && (OO.normals = new Float32Array(OO.positions.length)), this.tangents && !OO.tangents && (OO.tangents = new Float32Array(OO.positions.length / 3 * 4)), this.uvs && !OO.uvs && (OO.uvs = new Float32Array(OO.positions.length / 3 * 2)), this.uvs2 && !OO.uvs2 && (OO.uvs2 = new Float32Array(OO.positions.length / 3 * 2)), this.uvs3 && !OO.uvs3 && (OO.uvs3 = new Float32Array(OO.positions.length / 3 * 2)), this.uvs4 && !OO.uvs4 && (OO.uvs4 = new Float32Array(OO.positions.length / 3 * 2)), this.uvs5 && !OO.uvs5 && (OO.uvs5 = new Float32Array(OO.positions.length / 3 * 2)), this.uvs6 && !OO.uvs6 && (OO.uvs6 = new Float32Array(OO.positions.length / 3 * 2)), this.colors && !OO.colors && (OO.colors = new Float32Array(OO.positions.length / 3 * 4), OO.colors.fill(1)), this.matricesIndices && !OO.matricesIndices && (OO.matricesIndices = new Float32Array(OO.positions.length / 3 * 4)), this.matricesWeights && !OO.matricesWeights && (OO.matricesWeights = new Float32Array(OO.positions.length / 3 * 4)), this.matricesIndicesExtra && !OO.matricesIndicesExtra && (OO.matricesIndicesExtra = new Float32Array(OO.positions.length / 3 * 4)), this.matricesWeightsExtra && !OO.matricesWeightsExtra && (OO.matricesWeightsExtra = new Float32Array(OO.positions.length / 3 * 4));
              else if (OO._validate(), !this.normals !== !OO.normals || !this.tangents !== !OO.tangents || !this.uvs !== !OO.uvs || !this.uvs2 !== !OO.uvs2 || !this.uvs3 !== !OO.uvs3 || !this.uvs4 !== !OO.uvs4 || !this.uvs5 !== !OO.uvs5 || !this.uvs6 !== !OO.uvs6 || !this.colors !== !OO.colors || !this.matricesIndices !== !OO.matricesIndices || !this.matricesWeights !== !OO.matricesWeights || !this.matricesIndicesExtra !== !OO.matricesIndicesExtra || !this.matricesWeightsExtra !== !OO.matricesWeightsExtra) throw new Error("Cannot merge vertex data that do not have the same set of attributes");
          if (vK) {
            let OO, XO = 0,
              bK = 0;
            const eO = [];
            let lO = null;
            const vK = [];
            for (const pO of this.splitBasedOnMaterialID()) vK.push({
              vertexData: pO,
              transform: KO
            });
            for (const KO of pO)
              if (KO.vertexData)
                for (const OO of KO.vertexData.splitBasedOnMaterialID()) vK.push({
                  vertexData: OO,
                  transform: KO.transform
                });
            vK.sort(((OO, KO) => {
              const pO = OO.vertexData.materialInfos ? OO.vertexData.materialInfos[0].materialIndex : 0,
                XO = KO.vertexData.materialInfos ? KO.vertexData.materialInfos[0].materialIndex : 0;
              return pO > XO ? 1 : pO === XO ? 0 : -1
            }));
            for (const KO of vK) {
              const pO = KO.vertexData;
              if (OO = pO.materialInfos ? pO.materialInfos[0].materialIndex : 0, lO && lO.materialIndex === OO) lO.indexCount += pO.indices.length, lO.verticesCount += pO.positions.length / 3;
              else {
                const KO = new oO;
                KO.materialIndex = OO, KO.indexStart = XO, KO.indexCount = pO.indices.length, KO.verticesStart = bK, KO.verticesCount = pO.positions.length / 3, eO.push(KO), lO = KO
              }
              XO += pO.indices.length, bK += pO.positions.length / 3
            }
            const CO = vK.splice(0, 1)[0];
            DO = CO.vertexData, KO = CO.transform, hO = vK.map((OO => OO.vertexData)), pO = vK, this.materialInfos = eO
          }
          const MO = hO.reduce(((OO, KO) => OO + (KO.indices?.length ?? 0)), DO.indices?.length ?? 0);
          let aK = lO || hO.some((OO => OO.indices === DO.indices)) ? DO.indices?.slice() : DO.indices;
          if (MO > 0) {
            let eO = aK?.length ?? 0;
            if (aK || (aK = new Array(MO)), aK.length !== MO) {
              if (Array.isArray(aK)) aK.length = MO;
              else {
                const OO = XO || aK instanceof Uint32Array ? new Uint32Array(MO) : new Uint16Array(MO);
                OO.set(aK), aK = OO
              }
              KO && KO.determinant() < 0 && OO._FlipFaces(aK, 0, eO)
            }
            let lO = DO.positions ? DO.positions.length / 3 : 0;
            for (const {
                vertexData: KO,
                transform: XO
              }
              of pO)
              if (KO.indices) {
                for (let OO = 0; OO < KO.indices.length; OO++) aK[eO + OO] = KO.indices[OO] + lO;
                XO && XO.determinant() < 0 && OO._FlipFaces(aK, eO, KO.indices.length), lO += KO.positions.length / 3, eO += KO.indices.length, bK && (yield)
              }
          }
          return this.indices = aK, this.positions = OO._MergeElement(eO.j.PositionKind, DO.positions, KO, pO.map((OO => [OO.vertexData.positions, OO.transform]))), bK && (yield), DO.normals && (this.normals = OO._MergeElement(eO.j.NormalKind, DO.normals, KO, pO.map((OO => [OO.vertexData.normals, OO.transform]))), bK && (yield)), DO.tangents && (this.tangents = OO._MergeElement(eO.j.TangentKind, DO.tangents, KO, pO.map((OO => [OO.vertexData.tangents, OO.transform]))), bK && (yield)), DO.uvs && (this.uvs = OO._MergeElement(eO.j.UVKind, DO.uvs, KO, pO.map((OO => [OO.vertexData.uvs, OO.transform]))), bK && (yield)), DO.uvs2 && (this.uvs2 = OO._MergeElement(eO.j.UV2Kind, DO.uvs2, KO, pO.map((OO => [OO.vertexData.uvs2, OO.transform]))), bK && (yield)), DO.uvs3 && (this.uvs3 = OO._MergeElement(eO.j.UV3Kind, DO.uvs3, KO, pO.map((OO => [OO.vertexData.uvs3, OO.transform]))), bK && (yield)), DO.uvs4 && (this.uvs4 = OO._MergeElement(eO.j.UV4Kind, DO.uvs4, KO, pO.map((OO => [OO.vertexData.uvs4, OO.transform]))), bK && (yield)), DO.uvs5 && (this.uvs5 = OO._MergeElement(eO.j.UV5Kind, DO.uvs5, KO, pO.map((OO => [OO.vertexData.uvs5, OO.transform]))), bK && (yield)), DO.uvs6 && (this.uvs6 = OO._MergeElement(eO.j.UV6Kind, DO.uvs6, KO, pO.map((OO => [OO.vertexData.uvs6, OO.transform]))), bK && (yield)), DO.colors && (this.colors = OO._MergeElement(eO.j.ColorKind, DO.colors, KO, pO.map((OO => [OO.vertexData.colors, OO.transform]))), (void 0 !== DO.hasVertexAlpha || pO.some((OO => void 0 !== OO.vertexData.hasVertexAlpha))) && (this.hasVertexAlpha = DO.hasVertexAlpha || pO.some((OO => OO.vertexData.hasVertexAlpha))), bK && (yield)), DO.matricesIndices && (this.matricesIndices = OO._MergeElement(eO.j.MatricesIndicesKind, DO.matricesIndices, KO, pO.map((OO => [OO.vertexData.matricesIndices, OO.transform]))), bK && (yield)), DO.matricesWeights && (this.matricesWeights = OO._MergeElement(eO.j.MatricesWeightsKind, DO.matricesWeights, KO, pO.map((OO => [OO.vertexData.matricesWeights, OO.transform]))), bK && (yield)), DO.matricesIndicesExtra && (this.matricesIndicesExtra = OO._MergeElement(eO.j.MatricesIndicesExtraKind, DO.matricesIndicesExtra, KO, pO.map((OO => [OO.vertexData.matricesIndicesExtra, OO.transform]))), bK && (yield)), DO.matricesWeightsExtra && (this.matricesWeightsExtra = OO._MergeElement(eO.j.MatricesWeightsExtraKind, DO.matricesWeightsExtra, KO, pO.map((OO => [OO.vertexData.matricesWeightsExtra, OO.transform])))), this
        }
        static _MergeElement(KO, pO, XO, bK) {
          const lO = bK.filter((OO => null !== OO[0] && void 0 !== OO[0]));
          if (!pO && 0 == lO.length) return pO;
          if (!pO) return this._MergeElement(KO, lO[0][0], lO[0][1], lO.slice(1));
          const vK = lO.reduce(((OO, KO) => OO + KO[0].length), pO.length),
            CO = KO === eO.j.PositionKind ? OO._TransformVector3Coordinates : KO === eO.j.NormalKind ? OO._TransformVector3Normals : KO === eO.j.TangentKind ? OO._TransformVector4Normals : () => {};
          if (pO instanceof Float32Array) {
            const OO = new Float32Array(vK);
            OO.set(pO), XO && CO(OO, XO, 0, pO.length);
            let KO = pO.length;
            for (const [pO, XO] of lO) OO.set(pO, KO), XO && CO(OO, XO, KO, pO.length), KO += pO.length;
            return OO
          } {
            const OO = new Array(vK);
            for (let XO = 0; XO < pO.length; XO++) OO[XO] = pO[XO];
            XO && CO(OO, XO, 0, pO.length);
            let KO = pO.length;
            for (const [pO, XO] of lO) {
              for (let XO = 0; XO < pO.length; XO++) OO[KO + XO] = pO[XO];
              XO && CO(OO, XO, KO, pO.length), KO += pO.length
            }
            return OO
          }
        }
        _validate() {
          if (!this.positions) throw new MO.g("Positions are required", MO.d.MeshInvalidPositionsError);
          const OO = (OO, KO) => {
              const pO = (0, eO.f)(OO);
              if (KO.length % pO !== 0) throw new Error("The " + OO + "s array count must be a multiple of " + pO);
              return KO.length / pO
            },
            KO = OO(eO.j.PositionKind, this.positions),
            pO = (pO, XO) => {
              const bK = OO(pO, XO);
              if (bK !== KO) throw new Error("The " + pO + "s element count (" + bK + ") does not match the positions count (" + KO + ")")
            };
          this.normals && pO(eO.j.NormalKind, this.normals), this.tangents && pO(eO.j.TangentKind, this.tangents), this.uvs && pO(eO.j.UVKind, this.uvs), this.uvs2 && pO(eO.j.UV2Kind, this.uvs2), this.uvs3 && pO(eO.j.UV3Kind, this.uvs3), this.uvs4 && pO(eO.j.UV4Kind, this.uvs4), this.uvs5 && pO(eO.j.UV5Kind, this.uvs5), this.uvs6 && pO(eO.j.UV6Kind, this.uvs6), this.colors && pO(eO.j.ColorKind, this.colors), this.matricesIndices && pO(eO.j.MatricesIndicesKind, this.matricesIndices), this.matricesWeights && pO(eO.j.MatricesWeightsKind, this.matricesWeights), this.matricesIndicesExtra && pO(eO.j.MatricesIndicesExtraKind, this.matricesIndicesExtra), this.matricesWeightsExtra && pO(eO.j.MatricesWeightsExtraKind, this.matricesWeightsExtra)
        }
        clone() {
          const KO = this.serialize();
          return OO.Parse(KO)
        }
        serialize() {
          const OO = {};
          if (this.positions && (OO.positions = Array.from(this.positions)), this.normals && (OO.normals = Array.from(this.normals)), this.tangents && (OO.tangents = Array.from(this.tangents)), this.uvs && (OO.uvs = Array.from(this.uvs)), this.uvs2 && (OO.uvs2 = Array.from(this.uvs2)), this.uvs3 && (OO.uvs3 = Array.from(this.uvs3)), this.uvs4 && (OO.uvs4 = Array.from(this.uvs4)), this.uvs5 && (OO.uvs5 = Array.from(this.uvs5)), this.uvs6 && (OO.uvs6 = Array.from(this.uvs6)), this.colors && (OO.colors = Array.from(this.colors), OO.hasVertexAlpha = this.hasVertexAlpha), this.matricesIndices && (OO.matricesIndices = Array.from(this.matricesIndices), OO.matricesIndicesExpanded = !0), this.matricesWeights && (OO.matricesWeights = Array.from(this.matricesWeights)), this.matricesIndicesExtra && (OO.matricesIndicesExtra = Array.from(this.matricesIndicesExtra), OO.matricesIndicesExtraExpanded = !0), this.matricesWeightsExtra && (OO.matricesWeightsExtra = Array.from(this.matricesWeightsExtra)), OO.indices = this.indices ? Array.from(this.indices) : [], this.materialInfos) {
            OO.materialInfos = [];
            for (const KO of this.materialInfos) {
              const pO = {
                indexStart: KO.indexStart,
                indexCount: KO.indexCount,
                materialIndex: KO.materialIndex,
                verticesStart: KO.verticesStart,
                verticesCount: KO.verticesCount
              };
              OO.materialInfos.push(pO)
            }
          }
          return OO
        }
        static ExtractFromMesh(KO, pO, XO) {
          return OO._ExtractFrom(KO, pO, XO)
        }
        static ExtractFromGeometry(KO, pO, XO) {
          return OO._ExtractFrom(KO, pO, XO)
        }
        static _ExtractFrom(KO, pO, XO) {
          const bK = new OO;
          if (KO.isVerticesDataPresent(eO.j.PositionKind) && (bK.positions = KO.getVerticesData(eO.j.PositionKind, pO, XO)), KO.isVerticesDataPresent(eO.j.NormalKind) && (bK.normals = KO.getVerticesData(eO.j.NormalKind, pO, XO)), KO.isVerticesDataPresent(eO.j.TangentKind) && (bK.tangents = KO.getVerticesData(eO.j.TangentKind, pO, XO)), KO.isVerticesDataPresent(eO.j.UVKind) && (bK.uvs = KO.getVerticesData(eO.j.UVKind, pO, XO)), KO.isVerticesDataPresent(eO.j.UV2Kind) && (bK.uvs2 = KO.getVerticesData(eO.j.UV2Kind, pO, XO)), KO.isVerticesDataPresent(eO.j.UV3Kind) && (bK.uvs3 = KO.getVerticesData(eO.j.UV3Kind, pO, XO)), KO.isVerticesDataPresent(eO.j.UV4Kind) && (bK.uvs4 = KO.getVerticesData(eO.j.UV4Kind, pO, XO)), KO.isVerticesDataPresent(eO.j.UV5Kind) && (bK.uvs5 = KO.getVerticesData(eO.j.UV5Kind, pO, XO)), KO.isVerticesDataPresent(eO.j.UV6Kind) && (bK.uvs6 = KO.getVerticesData(eO.j.UV6Kind, pO, XO)), KO.isVerticesDataPresent(eO.j.ColorKind)) {
            const OO = KO.geometry || KO,
              lO = OO.getVertexBuffer(eO.j.ColorKind),
              vK = OO.getVerticesData(eO.j.ColorKind, pO, XO);
            if (3 === lO.getSize()) {
              const OO = new Float32Array(4 * vK.length / 3);
              for (let KO = 0, pO = 0; KO < vK.length; KO += 3, pO += 4) OO[pO] = vK[KO], OO[pO + 1] = vK[KO + 1], OO[pO + 2] = vK[KO + 2], OO[pO + 3] = 1;
              bK.colors = OO
            } else {
              if (4 !== lO.getSize()) throw new Error(`Unexpected number of color components: ${lO.getSize()}`);
              bK.colors = vK
            }
          }
          return KO.isVerticesDataPresent(eO.j.MatricesIndicesKind) && (bK.matricesIndices = KO.getVerticesData(eO.j.MatricesIndicesKind, pO, XO)), KO.isVerticesDataPresent(eO.j.MatricesWeightsKind) && (bK.matricesWeights = KO.getVerticesData(eO.j.MatricesWeightsKind, pO, XO)), KO.isVerticesDataPresent(eO.j.MatricesIndicesExtraKind) && (bK.matricesIndicesExtra = KO.getVerticesData(eO.j.MatricesIndicesExtraKind, pO, XO)), KO.isVerticesDataPresent(eO.j.MatricesWeightsExtraKind) && (bK.matricesWeightsExtra = KO.getVerticesData(eO.j.MatricesWeightsExtraKind, pO, XO)), bK.indices = KO.rFO(pO, XO), bK
        }
        static CreateRibbon(OO) {
          throw (0, lO.j)("ribbonBuilder")
        }
        static CreateBox(OO) {
          throw (0, lO.j)("boxBuilder")
        }
        static CreateTiledBox(OO) {
          throw (0, lO.j)("tiledBoxBuilder")
        }
        static CreateTiledPlane(OO) {
          throw (0, lO.j)("tiledPlaneBuilder")
        }
        static CreateSphere(OO) {
          throw (0, lO.j)("sphereBuilder")
        }
        static CreateCylinder(OO) {
          throw (0, lO.j)("cylinderBuilder")
        }
        static CreateTorus(OO) {
          throw (0, lO.j)("torusBuilder")
        }
        static CreateLineSystem(OO) {
          throw (0, lO.j)("linesBuilder")
        }
        static CreateDashedLines(OO) {
          throw (0, lO.j)("linesBuilder")
        }
        static CreateGround(OO) {
          throw (0, lO.j)("groundBuilder")
        }
        static CreateTiledGround(OO) {
          throw (0, lO.j)("groundBuilder")
        }
        static CreateGroundFromHeightMap(OO) {
          throw (0, lO.j)("groundBuilder")
        }
        static CreatePlane(OO) {
          throw (0, lO.j)("planeBuilder")
        }
        static CreateDisc(OO) {
          throw (0, lO.j)("discBuilder")
        }
        static CreatePolygon(OO, KO, pO, XO, bK, eO, vK) {
          throw (0, lO.j)("polygonBuilder")
        }
        static CreateIcoSphere(OO) {
          throw (0, lO.j)("icoSphereBuilder")
        }
        static CreatePolyhedron(OO) {
          throw (0, lO.j)("polyhedronBuilder")
        }
        static CreateCapsule() {
          arguments.length > 0 && void 0 !== arguments[0] || bK.o.Up();
          throw (0, lO.j)("capsuleBuilder")
        }
        static CreateTorusKnot(OO) {
          throw (0, lO.j)("torusKnotBuilder")
        }
        static ComputeNormals(OO, KO, pO, XO) {
          let eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO, QO, zK, AO, fO, dO, TO, NO, IO, yK = !1,
            gK = !1,
            uO = !1,
            EO = !1,
            jK = 1,
            YO = 0,
            wO = null;
          XO && (yK = !!XO.facetNormals, gK = !!XO.facetPositions, uO = !!XO.facetPartitioning, jK = !0 === XO.useRightHandedSystem ? -1 : 1, YO = XO.ratio || 0, EO = !!XO.depthSort, wO = XO.distanceTo, EO && void 0 === wO && (wO = bK.o.Zero()));
          let iK = 0,
            rK = 0,
            PO = 0,
            mK = 0;
          for (uO && XO && XO.bbSize && (iK = XO.subDiv.X * YO / XO.bbSize.x, rK = XO.subDiv.Y * YO / XO.bbSize.y, PO = XO.subDiv.Z * YO / XO.bbSize.z, mK = XO.subDiv.max * XO.subDiv.max, XO.facetPartitioning.length = 0), eO = 0; eO < OO.length; eO++) pO[eO] = 0;
          const sO = KO.length / 3 | 0;
          for (eO = 0; eO < sO; eO++) {
            if (LO = 3 * KO[3 * eO], QO = LO + 1, zK = LO + 2, AO = 3 * KO[3 * eO + 1], fO = AO + 1, dO = AO + 2, TO = 3 * KO[3 * eO + 2], NO = TO + 1, IO = TO + 2, lO = OO[LO] - OO[AO], vK = OO[QO] - OO[fO], CO = OO[zK] - OO[dO], hO = OO[TO] - OO[AO], DO = OO[NO] - OO[fO], MO = OO[IO] - OO[dO], aK = jK * (vK * MO - CO * DO), oO = jK * (CO * hO - lO * MO), FO = jK * (lO * DO - vK * hO), VO = Math.sqrt(aK * aK + oO * oO + FO * FO), VO = 0 === VO ? 1 : VO, aK /= VO, oO /= VO, FO /= VO, yK && XO && (XO.facetNormals[eO].x = aK, XO.facetNormals[eO].y = oO, XO.facetNormals[eO].z = FO), gK && XO && (XO.facetPositions[eO].x = (OO[LO] + OO[AO] + OO[TO]) / 3, XO.facetPositions[eO].y = (OO[QO] + OO[fO] + OO[NO]) / 3, XO.facetPositions[eO].z = (OO[zK] + OO[dO] + OO[IO]) / 3), uO && XO) {
              const KO = Math.floor((XO.facetPositions[eO].x - XO.bInfo.minimum.x * YO) * iK),
                pO = Math.floor((XO.facetPositions[eO].y - XO.bInfo.minimum.y * YO) * rK),
                bK = Math.floor((XO.facetPositions[eO].z - XO.bInfo.minimum.z * YO) * PO),
                lO = Math.floor((OO[LO] - XO.bInfo.minimum.x * YO) * iK),
                vK = Math.floor((OO[QO] - XO.bInfo.minimum.y * YO) * rK),
                CO = Math.floor((OO[zK] - XO.bInfo.minimum.z * YO) * PO),
                hO = Math.floor((OO[AO] - XO.bInfo.minimum.x * YO) * iK),
                DO = Math.floor((OO[fO] - XO.bInfo.minimum.y * YO) * rK),
                MO = Math.floor((OO[dO] - XO.bInfo.minimum.z * YO) * PO),
                aK = Math.floor((OO[TO] - XO.bInfo.minimum.x * YO) * iK),
                oO = Math.floor((OO[NO] - XO.bInfo.minimum.y * YO) * rK),
                FO = Math.floor((OO[IO] - XO.bInfo.minimum.z * YO) * PO),
                VO = lO + XO.subDiv.max * vK + mK * CO,
                yK = hO + XO.subDiv.max * DO + mK * MO,
                gK = aK + XO.subDiv.max * oO + mK * FO,
                uO = KO + XO.subDiv.max * pO + mK * bK;
              XO.facetPartitioning[uO] = XO.facetPartitioning[uO] ? XO.facetPartitioning[uO] : [], XO.facetPartitioning[VO] = XO.facetPartitioning[VO] ? XO.facetPartitioning[VO] : [], XO.facetPartitioning[yK] = XO.facetPartitioning[yK] ? XO.facetPartitioning[yK] : [], XO.facetPartitioning[gK] = XO.facetPartitioning[gK] ? XO.facetPartitioning[gK] : [], XO.facetPartitioning[VO].push(eO), yK != VO && XO.facetPartitioning[yK].push(eO), gK != yK && gK != VO && XO.facetPartitioning[gK].push(eO), uO != VO && uO != yK && uO != gK && XO.facetPartitioning[uO].push(eO)
            }
            if (EO && XO && XO.facetPositions) {
              const OO = XO.depthSortedFacets[eO];
              OO.ind = 3 * eO, OO.sqDistance = bK.o.DistanceSquared(XO.facetPositions[eO], wO)
            }
            pO[LO] += aK, pO[QO] += oO, pO[zK] += FO, pO[AO] += aK, pO[fO] += oO, pO[dO] += FO, pO[TO] += aK, pO[NO] += oO, pO[IO] += FO
          }
          for (eO = 0; eO < pO.length / 3; eO++) aK = pO[3 * eO], oO = pO[3 * eO + 1], FO = pO[3 * eO + 2], VO = Math.sqrt(aK * aK + oO * oO + FO * FO), VO = 0 === VO ? 1 : VO, aK /= VO, oO /= VO, FO /= VO, pO[3 * eO] = aK, pO[3 * eO + 1] = oO, pO[3 * eO + 2] = FO
        }
        static _ComputeSides(KO, pO, XO, eO, lO, vK, CO) {
          const hO = XO.length,
            DO = eO.length;
          let MO, aK;
          switch (KO = KO || OO.DEFAULTSIDE) {
            case OO.FRONTSIDE:
              break;
            case OO.BACKSIDE:
              for (MO = 0; MO < hO; MO += 3) {
                const OO = XO[MO];
                XO[MO] = XO[MO + 2], XO[MO + 2] = OO
              }
              for (aK = 0; aK < DO; aK++) eO[aK] = -eO[aK];
              break;
            case OO.DOUBLESIDE: {
              const OO = pO.length,
                KO = OO / 3;
              for (let XO = 0; XO < OO; XO++) pO[OO + XO] = pO[XO];
              for (MO = 0; MO < hO; MO += 3) XO[MO + hO] = XO[MO + 2] + KO, XO[MO + 1 + hO] = XO[MO + 1] + KO, XO[MO + 2 + hO] = XO[MO] + KO;
              for (aK = 0; aK < DO; aK++) eO[DO + aK] = -eO[aK];
              const oO = lO.length;
              let FO;
              for (FO = 0; FO < oO; FO++) lO[FO + oO] = lO[FO];
              for (vK = vK || new bK.s(0, 0, 1, 1), CO = CO || new bK.s(0, 0, 1, 1), FO = 0, MO = 0; MO < oO / 2; MO++) lO[FO] = vK.x + (vK.z - vK.x) * lO[FO], lO[FO + 1] = vK.y + (vK.w - vK.y) * lO[FO + 1], lO[FO + oO] = CO.x + (CO.z - CO.x) * lO[FO + oO], lO[FO + oO + 1] = CO.y + (CO.w - CO.y) * lO[FO + oO + 1], FO += 2;
              break
            }
          }
        }
        static Parse(KO) {
          const pO = new OO,
            XO = KO.positions;
          XO && pO.set(XO, eO.j.PositionKind);
          const bK = KO.normals;
          bK && pO.set(bK, eO.j.NormalKind);
          const lO = KO.tangents;
          lO && pO.set(lO, eO.j.TangentKind);
          const CO = KO.uvs;
          CO && pO.set(CO, eO.j.UVKind);
          const hO = KO.uvs2;
          hO && pO.set(hO, eO.j.UV2Kind);
          const DO = KO.uvs3;
          DO && pO.set(DO, eO.j.UV3Kind);
          const MO = KO.uvs4;
          MO && pO.set(MO, eO.j.UV4Kind);
          const aK = KO.uvs5;
          aK && pO.set(aK, eO.j.UV5Kind);
          const FO = KO.uvs6;
          FO && pO.set(FO, eO.j.UV6Kind);
          const VO = KO.colors;
          VO && (pO.set(vK.g.CheckColors4(VO, XO.length / 3), eO.j.ColorKind), void 0 !== KO.hasVertexAlpha && (pO.hasVertexAlpha = KO.hasVertexAlpha));
          const LO = KO.matricesIndices;
          LO && pO.set(LO, eO.j.MatricesIndicesKind);
          const QO = KO.matricesWeights;
          QO && pO.set(QO, eO.j.MatricesWeightsKind);
          const zK = KO.indices;
          zK && (pO.indices = zK);
          const AO = KO.materialInfos;
          if (AO) {
            pO.materialInfos = [];
            for (const OO of AO) {
              const KO = new oO;
              KO.indexCount = OO.indexCount, KO.indexStart = OO.indexStart, KO.verticesCount = OO.verticesCount, KO.verticesStart = OO.verticesStart, KO.materialIndex = OO.materialIndex, pO.materialInfos.push(KO)
            }
          }
          return pO
        }
        static ImportVertexData(KO, pO) {
          const XO = OO.Parse(KO);
          pO.setAllVerticesData(XO, KO.updatable)
        }
      }, (() => {
        const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [hO.l.filter((function() {
          return !Array.isArray(arguments.length <= 0 ? void 0 : arguments[0])
        }))], pO = [hO.l.filter((function() {
          return !Array.isArray(arguments.length <= 0 ? void 0 : arguments[0])
        }))], FO = [hO.l.filter((function() {
          return !Array.isArray(arguments.length <= 0 ? void 0 : arguments[0])
        }))], VO = [hO.l.filter((function() {
          return !Array.isArray(arguments.length <= 0 ? void 0 : arguments[0])
        }))], (0, XO.f)(OO, null, KO, {
          kind: "method",
          name: "_TransformVector3Coordinates",
          static: !0,
          private: !1,
          access: {
            has: OO => "_TransformVector3Coordinates" in OO,
            get: OO => OO._TransformVector3Coordinates
          },
          metadata: bK
        }, null, LO), (0, XO.f)(OO, null, pO, {
          kind: "method",
          name: "_TransformVector3Normals",
          static: !0,
          private: !1,
          access: {
            has: OO => "_TransformVector3Normals" in OO,
            get: OO => OO._TransformVector3Normals
          },
          metadata: bK
        }, null, LO), (0, XO.f)(OO, null, FO, {
          kind: "method",
          name: "_TransformVector4Normals",
          static: !0,
          private: !1,
          access: {
            has: OO => "_TransformVector4Normals" in OO,
            get: OO => OO._TransformVector4Normals
          },
          metadata: bK
        }, null, LO), (0, XO.f)(OO, null, VO, {
          kind: "method",
          name: "_FlipFaces",
          static: !0,
          private: !1,
          access: {
            has: OO => "_FlipFaces" in OO,
            get: OO => OO._FlipFaces
          },
          metadata: bK
        }, null, LO), bK && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: bK
        })
      })(), OO.FRONTSIDE = ((0, XO.i)(OO, LO), 0), OO.BACKSIDE = 1, OO.DOUBLESIDE = 2, OO.DEFAULTSIDE = 0, OO._UniqueIdGenerator = 0, OO
    })()
  },
  38587: (OO, KO, pO) => {
    var XO = pO(35632),
      bK = pO(37061),
      eO = pO(38400),
      lO = pO(38502),
      vK = pO(38216);
    const CO = "bakedVertexAnimationSettingsInstanced";

    function hO(OO) {
      const KO = OO.bakedVertexAnimationManager?.texture?.getInternalTexture()?._bufferView;
      return KO instanceof Float32Array || KO instanceof Uint16Array
    }

    function DO(OO, KO, pO, XO) {
      pO.plO(Number.POSITIVE_INFINITY), XO.plO(Number.NEGATIVE_INFINITY);
      for (let bK = 0; bK < 3 * KO; bK += 3) {
        const KO = OO[bK],
          eO = OO[bK + 1],
          lO = OO[bK + 2];
        KO < pO.x && (pO.x = KO), eO < pO.y && (pO.y = eO), lO < pO.z && (pO.z = lO), KO > XO.x && (XO.x = KO), eO > XO.y && (XO.y = eO), lO > XO.z && (XO.z = lO)
      }
    }

    function MO(OO, KO, pO) {
      pO && (OO.x -= OO.x * pO.x + pO.y, OO.y -= OO.y * pO.x + pO.y, OO.z -= OO.z * pO.x + pO.y, KO.x += KO.x * pO.x + pO.y, KO.y += KO.y * pO.x + pO.y, KO.z += KO.z * pO.x + pO.y)
    }

    function aK(OO, KO, pO, bK, eO) {
      const lO = XO.j.WX[7],
        vK = XO.j.WX[8];
      for (let CO = 0; CO < 2; ++CO)
        for (let hO = 0; hO < 2; ++hO)
          for (let DO = 0; DO < 2; ++DO) lO.set(CO ? KO.x : OO.x, hO ? KO.y : OO.y, DO ? KO.z : OO.z), XO.o.TransformCoordinatesToRef(lO, pO, vK), bK.minimizeInPlace(vK), eO.maximizeInPlace(vK)
    }

    function oO(OO, KO, pO, bK, eO) {
      const lO = XO.j.WX[7];
      for (let vK = 0; vK < 3 * KO; vK += 3) XO.o.TransformCoordinatesFromFloatsToRef(OO[vK], OO[vK + 1], OO[vK + 2], pO, lO), bK.minimizeInPlace(lO), eO.maximizeInPlace(lO)
    }
    let FO = !1;
    FO || (FO = !0, lO.c.prototype.thinInstanceAdd = function(OO) {
      let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      if (!this.JKO().qb().getCaps().instancedArrays) return bK.b.Error("Thin Instances are not supported on this device as Instanced Array extension not supported"), -1;
      this._thinInstanceUpdateBufferSize("matrix", Array.isArray(OO) ? OO.length : 1);
      const pO = this._thinInstanceDataStorage.instancesCount;
      if (Array.isArray(OO))
        for (let XO = 0; XO < OO.length; ++XO) this.thinInstanceSetMatrixAt(this._thinInstanceDataStorage.instancesCount++, OO[XO], XO === OO.length - 1 && KO);
      else this.thinInstanceSetMatrixAt(this._thinInstanceDataStorage.instancesCount++, OO, KO);
      return pO
    }, lO.c.prototype.thinInstanceAddSelf = function() {
      let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
      return this.thinInstanceAdd(XO.c.IdentityReadOnly, OO)
    }, lO.c.prototype.thinInstanceRegisterAttribute = function(OO, KO) {
      OO === vK.j.ColorKind && (OO = vK.j.ColorInstanceKind), this.removeVerticesData(OO), this._thinInstanceInitializeUserStorage(), this._userThinInstanceBuffersStorage.strides[OO] = KO, this._userThinInstanceBuffersStorage.sizes[OO] = KO * Math.max(32, this._thinInstanceDataStorage.instancesCount), this._userThinInstanceBuffersStorage.data[OO] = new Float32Array(this._userThinInstanceBuffersStorage.sizes[OO]), this._userThinInstanceBuffersStorage.vertexBuffers[OO] = new vK.j(this.qb(), this._userThinInstanceBuffersStorage.data[OO], OO, !0, !1, KO, !0), this.setVerticesBuffer(this._userThinInstanceBuffersStorage.vertexBuffers[OO])
    }, lO.c.prototype.thinInstanceSetMatrixAt = function(OO, KO) {
      let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
      if (!this._thinInstanceDataStorage.matrixData || OO >= this._thinInstanceDataStorage.instancesCount) return !1;
      const XO = this._thinInstanceDataStorage.matrixData;
      return KO.copyToArray(XO, 16 * OO), this._thinInstanceDataStorage.worldMatrices && (this._thinInstanceDataStorage.worldMatrices[OO] = KO), pO && (this.TlO("matrix"), this.kb || this.thinInstanceRefreshBoundingInfo(!1)), !0
    }, lO.c.prototype.thinInstanceSetAttributeAt = function(OO, KO, pO) {
      let XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
      return OO === vK.j.ColorKind && (OO = vK.j.ColorInstanceKind), !(!this._userThinInstanceBuffersStorage || !this._userThinInstanceBuffersStorage.data[OO] || KO >= this._thinInstanceDataStorage.instancesCount) && (this._thinInstanceUpdateBufferSize(OO, 0), this._userThinInstanceBuffersStorage.data[OO].set(pO, KO * this._userThinInstanceBuffersStorage.strides[OO]), XO && this.TlO(OO), !0)
    }, Object.defineProperty(lO.c.prototype, "hlO", {
      get: function() {
        return this._thinInstanceDataStorage.instancesCount
      },
      set: function(OO) {
        const KO = this._thinInstanceDataStorage.matrixData ?? this.source?._thinInstanceDataStorage.matrixData;
        OO <= (KO ? KO.length / 16 : 0) && (this._thinInstanceDataStorage.instancesCount = OO)
      },
      enumerable: !0,
      configurable: !0
    }), lO.c.prototype._thinInstanceCreateMatrixBuffer = function(OO, KO) {
      let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
      const XO = new vK.b(this.qb(), KO, !pO, 16, !1, !0);
      for (let bK = 0; bK < 4; bK++) this.setVerticesBuffer(XO.createVertexBuffer(OO + bK, 4 * bK, 4));
      return XO
    }, lO.c.prototype.ulO = function(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
        XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
      if (pO = pO || 16, "matrix" === OO) this._thinInstanceDataStorage.matrixBuffer?.dispose(), this._thinInstanceDataStorage.matrixBuffer = null, this._thinInstanceDataStorage.matrixBufferSize = KO ? KO.length : 32 * pO, this._thinInstanceDataStorage.matrixData = KO, this._thinInstanceDataStorage.worldMatrices = null, null !== KO ? (this._thinInstanceDataStorage.instancesCount = KO.length / pO, this._thinInstanceDataStorage.matrixBuffer = this._thinInstanceCreateMatrixBuffer("world", KO, XO), this.kb || this.thinInstanceRefreshBoundingInfo(!1)) : (this._thinInstanceDataStorage.instancesCount = 0, this.kb || this.refreshBoundingInfo());
      else if ("previousMatrix" === OO) this._thinInstanceDataStorage.previousMatrixBuffer?.dispose(), this._thinInstanceDataStorage.previousMatrixBuffer = null, this._thinInstanceDataStorage.previousMatrixData = KO, null !== KO && (this._thinInstanceDataStorage.previousMatrixBuffer = this._thinInstanceCreateMatrixBuffer("previousWorld", KO, XO));
      else if ("splatIndex" === OO && KO) {
        this._thinInstanceInitializeUserStorage(), this._thinInstanceDataStorage.instancesCount = KO.length / pO, this._userThinInstanceBuffersStorage.data[OO] = KO, this._userThinInstanceBuffersStorage.strides[OO] = pO, this._userThinInstanceBuffersStorage.sizes[OO] = KO.length;
        const XO = new vK.b(this.qb(), KO, !0, 16, !1, !0);
        this._thinInstanceDataStorage.matrixBuffer = XO;
        for (let KO = 0; KO < 4; KO++) this.setVerticesBuffer(XO.createVertexBuffer(OO + KO, 4 * KO, 4))
      } else OO === vK.j.ColorKind && (OO = vK.j.ColorInstanceKind), null === KO ? this._userThinInstanceBuffersStorage?.data[OO] && (this.removeVerticesData(OO), delete this._userThinInstanceBuffersStorage.data[OO], delete this._userThinInstanceBuffersStorage.strides[OO], delete this._userThinInstanceBuffersStorage.sizes[OO], delete this._userThinInstanceBuffersStorage.vertexBuffers[OO]) : (this._thinInstanceInitializeUserStorage(), this._userThinInstanceBuffersStorage.data[OO] = KO, this._userThinInstanceBuffersStorage.strides[OO] = pO, this._userThinInstanceBuffersStorage.sizes[OO] = KO.length, this._userThinInstanceBuffersStorage.vertexBuffers[OO] = new vK.j(this.qb(), KO, OO, !XO, !1, pO, !0), this.setVerticesBuffer(this._userThinInstanceBuffersStorage.vertexBuffers[OO]))
    }, lO.c.prototype.TlO = function(OO) {
      "matrix" === OO ? (this.thinInstanceAllowAutomaticStaticBufferRecreation && this._thinInstanceDataStorage.matrixBuffer && !this._thinInstanceDataStorage.matrixBuffer.isUpdatable() && this._thinInstanceRecreateBuffer(OO), this._thinInstanceDataStorage.matrixBuffer?.updateDirectly(this._thinInstanceDataStorage.matrixData, 0, this._thinInstanceDataStorage.instancesCount)) : "previousMatrix" === OO ? (this.thinInstanceAllowAutomaticStaticBufferRecreation && this._thinInstanceDataStorage.previousMatrixBuffer && !this._thinInstanceDataStorage.previousMatrixBuffer.isUpdatable() && this._thinInstanceRecreateBuffer(OO), this._thinInstanceDataStorage.previousMatrixBuffer?.updateDirectly(this._thinInstanceDataStorage.previousMatrixData, 0, this._thinInstanceDataStorage.instancesCount)) : "splatIndex" === OO ? this._thinInstanceDataStorage.matrixBuffer?.updateDirectly(this._userThinInstanceBuffersStorage.data[OO], 0, this._thinInstanceDataStorage.instancesCount) : (OO === vK.j.ColorKind && (OO = vK.j.ColorInstanceKind), this._userThinInstanceBuffersStorage?.vertexBuffers[OO] && (this.thinInstanceAllowAutomaticStaticBufferRecreation && !this._userThinInstanceBuffersStorage.vertexBuffers[OO].isUpdatable() && this._thinInstanceRecreateBuffer(OO), this._userThinInstanceBuffersStorage.vertexBuffers[OO].updateDirectly(this._userThinInstanceBuffersStorage.data[OO], 0)))
    }, lO.c.prototype.thinInstancePartialBufferUpdate = function(OO, KO, pO) {
      if ("matrix" === OO) this._thinInstanceDataStorage.matrixBuffer && ("number" === typeof KO ? this._thinInstanceDataStorage.matrixBuffer.updateDirectly(new Float32Array(this._thinInstanceDataStorage.matrixData.buffer, this._thinInstanceDataStorage.matrixData.byteOffset + 16 * pO * Float32Array.BYTES_PER_ELEMENT, 16 * KO), 16 * pO) : this._thinInstanceDataStorage.matrixBuffer.updateDirectly(KO, pO));
      else if (OO === vK.j.ColorKind && (OO = vK.j.ColorInstanceKind), this._userThinInstanceBuffersStorage?.vertexBuffers[OO]) {
        const XO = this._userThinInstanceBuffersStorage.vertexBuffers[OO];
        if ("number" === typeof KO) {
          const XO = new Float32Array(this._userThinInstanceBuffersStorage.data[OO].buffer, this._userThinInstanceBuffersStorage.data[OO].byteOffset + pO * this._userThinInstanceBuffersStorage.strides[OO] * Float32Array.BYTES_PER_ELEMENT, KO * this._userThinInstanceBuffersStorage.strides[OO]);
          this._userThinInstanceBuffersStorage.vertexBuffers[OO].updateDirectly(XO, pO * this._userThinInstanceBuffersStorage.strides[OO])
        } else XO.updateDirectly(KO, pO)
      }
    }, lO.c.prototype.thinInstanceGetWorldMatrices = function() {
      if (!this._thinInstanceDataStorage.matrixData || !this._thinInstanceDataStorage.matrixBuffer) return [];
      const OO = this._thinInstanceDataStorage.matrixData;
      if (!this._thinInstanceDataStorage.worldMatrices) {
        this._thinInstanceDataStorage.worldMatrices = [];
        for (let KO = 0; KO < this._thinInstanceDataStorage.instancesCount; ++KO) this._thinInstanceDataStorage.worldMatrices[KO] = XO.c.FromArray(OO, 16 * KO)
      }
      return this._thinInstanceDataStorage.worldMatrices
    }, lO.c.prototype.thinInstanceRefreshBoundingInfo = function() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
        KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
        bK = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      if (!this._thinInstanceDataStorage.matrixData || !this._thinInstanceDataStorage.matrixBuffer) return;
      const lO = this._thinInstanceDataStorage.boundingVectors;
      if (OO || !this.rawBoundingInfo) {
        if (lO.length = 0, bK && function(OO, KO, pO) {
            const bK = OO._userThinInstanceBuffersStorage,
              lO = bK?.data[CO],
              FO = bK?.strides[CO];
            if (!lO || !FO || FO < 4 || !hO(OO)) return !1;
            const VO = OO._thinInstanceDataStorage.matrixData;
            if (!VO) return !1;
            const LO = {},
              QO = XO.j.Vector4[0],
              zK = XO.j.WX[1],
              AO = XO.j.WX[2],
              fO = XO.j.WX[3],
              dO = XO.j.WX[4],
              TO = XO.j.WX[5],
              NO = XO.j.WX[6],
              IO = XO.j.Matrix[2],
              yK = OO.geometry ? OO.geometry.boundingBias : null,
              gK = OO.getTotalVertices();
            zK.plO(Number.POSITIVE_INFINITY), AO.plO(Number.NEGATIVE_INFINITY), fO.plO(Number.POSITIVE_INFINITY), dO.plO(Number.NEGATIVE_INFINITY);
            for (let eO = 0; eO < OO._thinInstanceDataStorage.instancesCount; ++eO) {
              const KO = eO * FO;
              QO.set(lO[KO], lO[KO + 1], lO[KO + 2], lO[KO + 3]);
              const bK = OO._getData({
                applyMorph: pO,
                applyBakedVertexAnimation: !0,
                bakedVertexAnimationSettings: QO,
                updatePositionsArray: !1,
                cache: LO
              }, null, vK.j.PositionKind);
              if (!bK) return !1;
              DO(bK, gK, TO, NO), MO(TO, NO, yK), zK.minimizeInPlace(TO), AO.maximizeInPlace(NO), XO.c.FromArrayToRef(VO, 16 * eO, IO), yK ? aK(TO, NO, IO, fO, dO) : oO(bK, gK, IO, fO, dO)
            }
            return !(!isFinite(zK.x) || !isFinite(fO.x)) && (OO.hpO().reConstruct(fO, dO), OO.rawBoundingInfo = new eO.d(zK, AO), function(OO, KO) {
              OO.length = 0;
              for (let pO = 0; pO < KO.boundingBox.vectors.length; ++pO) OO.push(KO.boundingBox.vectors[pO].clone())
            }(KO, OO.rawBoundingInfo), OO._updateBoundingInfo(), !0)
          }(this, lO, pO)) return;
        bK && this.bakedVertexAnimationManager?.isEnabled && hO(this) ? this.refreshBoundingInfo({
          applySkeleton: KO,
          applyMorph: pO,
          applyBakedVertexAnimation: !0,
          updatePositionsArray: !1
        }) : this.refreshBoundingInfo(KO, pO);
        const OO = this.hpO();
        this.rawBoundingInfo = new eO.d(OO.minimum, OO.maximum)
      }
      const FO = this.hpO(),
        VO = this._thinInstanceDataStorage.matrixData;
      if (0 === lO.length)
        for (let XO = 0; XO < FO.boundingBox.vectors.length; ++XO) lO.push(FO.boundingBox.vectors[XO].clone());
      XO.j.WX[0].plO(Number.POSITIVE_INFINITY), XO.j.WX[1].plO(Number.NEGATIVE_INFINITY);
      for (let eO = 0; eO < this._thinInstanceDataStorage.instancesCount; ++eO) {
        XO.c.FromArrayToRef(VO, 16 * eO, XO.j.Matrix[0]);
        for (let OO = 0; OO < lO.length; ++OO) XO.o.TransformCoordinatesToRef(lO[OO], XO.j.Matrix[0], XO.j.WX[2]), XO.j.WX[0].minimizeInPlace(XO.j.WX[2]), XO.j.WX[1].maximizeInPlace(XO.j.WX[2])
      }
      FO.reConstruct(XO.j.WX[0], XO.j.WX[1]), this._updateBoundingInfo()
    }, lO.c.prototype._thinInstanceRecreateBuffer = function(OO) {
      let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      "matrix" === OO ? (this._thinInstanceDataStorage.matrixBuffer?.dispose(), this._thinInstanceDataStorage.matrixBuffer = this._thinInstanceCreateMatrixBuffer("world", this._thinInstanceDataStorage.matrixData, KO)) : "previousMatrix" === OO ? this._scene.needsPreviousWorldMatrices && (this._thinInstanceDataStorage.previousMatrixBuffer?.dispose(), this._thinInstanceDataStorage.previousMatrixBuffer = this._thinInstanceCreateMatrixBuffer("previousWorld", this._thinInstanceDataStorage.previousMatrixData ?? this._thinInstanceDataStorage.matrixData, KO)) : (OO === vK.j.ColorKind && (OO = vK.j.ColorInstanceKind), this._userThinInstanceBuffersStorage.vertexBuffers[OO]?.dispose(), this._userThinInstanceBuffersStorage.vertexBuffers[OO] = new vK.j(this.qb(), this._userThinInstanceBuffersStorage.data[OO], OO, !KO, !1, this._userThinInstanceBuffersStorage.strides[OO], !0), this.setVerticesBuffer(this._userThinInstanceBuffersStorage.vertexBuffers[OO]))
    }, lO.c.prototype._thinInstanceUpdateBufferSize = function(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
      OO === vK.j.ColorKind && (OO = vK.j.ColorInstanceKind);
      const pO = "matrix" === OO;
      if (!pO && (!this._userThinInstanceBuffersStorage || !this._userThinInstanceBuffersStorage.strides[OO])) return;
      const XO = pO ? 16 : this._userThinInstanceBuffersStorage.strides[OO],
        bK = pO ? this._thinInstanceDataStorage.matrixBufferSize : this._userThinInstanceBuffersStorage.sizes[OO];
      let eO = pO ? this._thinInstanceDataStorage.matrixData : this._userThinInstanceBuffersStorage.data[OO];
      const lO = (this._thinInstanceDataStorage.instancesCount + KO) * XO;
      let CO = bK;
      for (; CO < lO;) CO *= 2;
      if (!eO || bK != CO) {
        if (eO) {
          const OO = new Float32Array(CO);
          OO.set(eO, 0), eO = OO
        } else eO = new Float32Array(CO);
        pO ? (this._thinInstanceDataStorage.matrixBuffer?.dispose(), this._thinInstanceDataStorage.matrixBuffer = this._thinInstanceCreateMatrixBuffer("world", eO, !1), this._thinInstanceDataStorage.matrixData = eO, this._thinInstanceDataStorage.matrixBufferSize = CO, this._scene.needsPreviousWorldMatrices && !this._thinInstanceDataStorage.previousMatrixData && (this._thinInstanceDataStorage.previousMatrixBuffer?.dispose(), this._thinInstanceDataStorage.previousMatrixBuffer = this._thinInstanceCreateMatrixBuffer("previousWorld", eO, !1))) : (this._userThinInstanceBuffersStorage.vertexBuffers[OO]?.dispose(), this._userThinInstanceBuffersStorage.data[OO] = eO, this._userThinInstanceBuffersStorage.sizes[OO] = CO, this._userThinInstanceBuffersStorage.vertexBuffers[OO] = new vK.j(this.qb(), eO, OO, !0, !1, XO, !0), this.setVerticesBuffer(this._userThinInstanceBuffersStorage.vertexBuffers[OO]))
      }
    }, lO.c.prototype._thinInstanceInitializeUserStorage = function() {
      this._userThinInstanceBuffersStorage || (this._userThinInstanceBuffersStorage = {
        data: {},
        sizes: {},
        vertexBuffers: {},
        strides: {}
      })
    }, lO.c.prototype._disposeThinInstanceSpecificData = function() {
      this._thinInstanceDataStorage?.matrixBuffer && (this._thinInstanceDataStorage.matrixBuffer.dispose(), this._thinInstanceDataStorage.matrixBuffer = null), this._thinInstanceDataStorage?.previousMatrixBuffer && (this._thinInstanceDataStorage.previousMatrixBuffer.dispose(), this._thinInstanceDataStorage.previousMatrixBuffer = null)
    })
  },
  38544: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => zK,
      i: () => VO
    });
    var XO, bK, eO, lO, vK = pO(38063),
      CO = pO(38066),
      hO = pO(38077),
      DO = pO(35660),
      MO = pO(35632),
      aK = pO(38301),
      oO = pO(35676),
      FO = pO(37938);
    let VO = (() => {
      var OO;
      let KO, pO, XO, bK, eO, lO, oO, FO, VO, LO = aK.c,
        QO = [],
        zK = [],
        AO = [],
        fO = [],
        dO = [],
        TO = [],
        NO = [],
        IO = [],
        yK = [],
        gK = [],
        uO = [],
        EO = [],
        jK = [],
        YO = [],
        wO = [],
        iK = [],
        rK = [],
        PO = [];
      return OO = class extends LO {
        get billboardMode() {
          return this._billboardMode
        }
        set billboardMode(KO) {
          this._billboardMode !== KO && (this._billboardMode = KO, this._cache.useBillboardPosition = 0 !== (this._billboardMode & OO.BILLBOARDMODE_USE_POSITION))
        }
        get infiniteDistance() {
          return this._infiniteDistance
        }
        set infiniteDistance(OO) {
          this._infiniteDistance !== OO && (this._infiniteDistance = OO)
        }
        constructor(KO) {
          let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
          super(KO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, !1), this._forward = new MO.o(0, 0, 1), this._up = new MO.o(0, 1, 0), this._right = new MO.o(1, 0, 0), this._position = (0, vK.i)(this, QO, MO.o.Zero()), this._rotation = ((0, vK.i)(this, zK), (0, vK.i)(this, AO, MO.o.Zero())), this._rotationQuaternion = ((0, vK.i)(this, fO), (0, vK.i)(this, dO, null)), this._scaling = ((0, vK.i)(this, TO), (0, vK.i)(this, NO, MO.o.One())), this._transformToBoneReferal = ((0, vK.i)(this, IO), null), this._isAbsoluteSynced = !1, this._billboardMode = (0, vK.i)(this, yK, OO.BILLBOARDMODE_NONE), this.scalingDeterminant = ((0, vK.i)(this, gK), (0, vK.i)(this, uO, 1)), this._infiniteDistance = ((0, vK.i)(this, EO), (0, vK.i)(this, jK, !1)), this.ignoreNonUniformScaling = ((0, vK.i)(this, YO), (0, vK.i)(this, wO, !1)), this.reIntegrateRotationIntoRotationQuaternion = ((0, vK.i)(this, iK), (0, vK.i)(this, rK, !1)), this._poseMatrix = ((0, vK.i)(this, PO), null), this._localMatrix = MO.c.Zero(), this._usePivotMatrix = !1, this._absolutePosition = MO.o.Zero(), this._absoluteScaling = MO.o.Zero(), this._absoluteRotationQuaternion = MO.g.Identity(), this._pivotMatrix = MO.c.Identity(), this._postMultiplyPivotMatrix = !1, this._isWorldMatrixFrozen = !1, this._indexInSceneTransformNodesArray = -1, this.onAfterWorldMatrixUpdateObservable = new DO.e, this._nonUniformScaling = !1, pO && this.JKO().addTransformNode(this)
        }
        getClassName() {
          return "TransformNode"
        }
        get position() {
          return this._position
        }
        set position(OO) {
          this._position = OO, this._markAsDirtyInternal()
        }
        isUsingPivotMatrix() {
          return this._usePivotMatrix
        }
        isUsingPostMultiplyPivotMatrix() {
          return this._postMultiplyPivotMatrix
        }
        get rotation() {
          return this._rotation
        }
        set rotation(OO) {
          this._rotation = OO, this._rotationQuaternion = null, this._markAsDirtyInternal()
        }
        get ol() {
          return this._scaling
        }
        set ol(OO) {
          this._scaling = OO, this._markAsDirtyInternal()
        }
        get rotationQuaternion() {
          return this._rotationQuaternion
        }
        set rotationQuaternion(OO) {
          this._rotationQuaternion = OO, OO && this._rotation.plO(0), this._markAsDirtyInternal()
        }
        _markAsDirtyInternal() {
          this._isDirty || (this._isDirty = !0, this.customMarkAsDirty && this.customMarkAsDirty())
        }
        get forward() {
          return MO.o.TransformNormalFromFloatsToRef(0, 0, this.JKO().useRightHandedSystem ? -1 : 1, this.getWorldMatrix(), this._forward), this._forward.normalize()
        }
        get up() {
          return MO.o.TransformNormalFromFloatsToRef(0, 1, 0, this.getWorldMatrix(), this._up), this._up.normalize()
        }
        get right() {
          return MO.o.TransformNormalFromFloatsToRef(this.JKO().useRightHandedSystem ? -1 : 1, 0, 0, this.getWorldMatrix(), this._right), this._right.normalize()
        }
        updatePoseMatrix(OO) {
          return this._poseMatrix ? (this._poseMatrix.NhO(OO), this) : (this._poseMatrix = OO.clone(), this)
        }
        getPoseMatrix() {
          return this._poseMatrix || (this._poseMatrix = MO.c.Identity()), this._poseMatrix
        }
        _isSynchronized() {
          const KO = this._cache;
          return this._billboardMode === KO.billboardMode && this._billboardMode === OO.BILLBOARDMODE_NONE && (!KO.pivotMatrixUpdated && (!this._infiniteDistance && (!this._position._isDirty && (!this._scaling._isDirty && !(this._rotationQuaternion && this._rotationQuaternion._isDirty || this._rotation._isDirty)))))
        }
        _initCache() {
          super._initCache();
          const OO = this._cache;
          OO.localMatrixUpdated = !1, OO.billboardMode = -1, OO.infiniteDistance = !1, OO.useBillboardPosition = !1
        }
        get absolutePosition() {
          return this.getAbsolutePosition()
        }
        get absoluteScaling() {
          return this._syncAbsoluteScalingAndRotation(), this._absoluteScaling
        }
        get absoluteRotationQuaternion() {
          return this._syncAbsoluteScalingAndRotation(), this._absoluteRotationQuaternion
        }
        setPreTransformMatrix(OO) {
          return this.setPivotMatrix(OO, !1)
        }
        setPivotMatrix(OO) {
          let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          return this._pivotMatrix.NhO(OO), this._usePivotMatrix = !this._pivotMatrix.isIdentity(), this._cache.pivotMatrixUpdated = !0, this._postMultiplyPivotMatrix = KO, this._postMultiplyPivotMatrix && (this._pivotMatrixInverse ? this._pivotMatrix.invertToRef(this._pivotMatrixInverse) : this._pivotMatrixInverse = MO.c.Invert(this._pivotMatrix)), this
        }
        getPivotMatrix() {
          return this._pivotMatrix
        }
        instantiateHierarchy() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
            KO = arguments.length > 1 ? arguments[1] : void 0,
            pO = arguments.length > 2 ? arguments[2] : void 0;
          const XO = this.clone("Clone of " + (this.name || this.id), OO || this.parent, !0);
          XO && pO && pO(this, XO);
          for (const bK of this.getChildTransformNodes(!0)) bK.instantiateHierarchy(XO, KO, pO);
          return XO
        }
        qpO() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
          return OO ? arguments.length > 1 && void 0 !== arguments[1] && arguments[1] ? (this._rotation.plO(0), this._rotationQuaternion = this._rotationQuaternion || MO.g.Identity(), OO.decompose(this._scaling, this._rotationQuaternion, this._position), this.computeWorldMatrix(!0)) : (this._worldMatrix = OO, this._absolutePosition.rvO(this._worldMatrix.m[12], this._worldMatrix.m[13], this._worldMatrix.m[14]), this._afterComputeWorldMatrix()) : (this._isWorldMatrixFrozen = !1, this.computeWorldMatrix(!0)), this._isDirty = !1, this._isWorldMatrixFrozen = !0, this
        }
        unfreezeWorldMatrix() {
          return this._isWorldMatrixFrozen = !1, this.computeWorldMatrix(!0), this
        }
        get JoO() {
          return this._isWorldMatrixFrozen
        }
        getAbsolutePosition() {
          return this.computeWorldMatrix(), this._absolutePosition
        }
        setAbsolutePosition(OO) {
          if (!OO) return this;
          let KO, pO, XO;
          if (void 0 === OO.x) {
            if (arguments.length < 3) return this;
            KO = arguments[0], pO = arguments[1], XO = arguments[2]
          } else KO = OO.x, pO = OO.y, XO = OO.z;
          if (this.parent) {
            const OO = MO.j.Matrix[0];
            this.parent.getWorldMatrix().invertToRef(OO), MO.o.TransformCoordinatesFromFloatsToRef(KO, pO, XO, OO, this.position)
          } else this.position.x = KO, this.position.y = pO, this.position.z = XO;
          return this._absolutePosition.NhO(OO), this
        }
        setPositionWithLocalVector(OO) {
          return this.computeWorldMatrix(), this.position = MO.o.TransformNormal(OO, this._localMatrix), this
        }
        getPositionExpressedInLocalSpace() {
          this.computeWorldMatrix();
          const OO = MO.j.Matrix[0];
          return this._localMatrix.invertToRef(OO), MO.o.TransformNormal(this.position, OO)
        }
        locallyTranslate(OO) {
          return this.computeWorldMatrix(!0), this.position = MO.o.TransformCoordinates(OO, this._localMatrix), this
        }
        lookAt(KO) {
          let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
            XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
            eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0;
          const lO = OO._LookAtVectorCache,
            vK = 0 === eO ? this.position : this.getAbsolutePosition();
          if (KO.subtractToRef(vK, lO), this.setDirection(lO, pO, XO, bK), 1 === eO && this.parent)
            if (this.rotationQuaternion) {
              const OO = MO.j.Matrix[0];
              this.rotationQuaternion.toRotationMatrix(OO);
              const KO = MO.j.Matrix[1];
              this.parent.getWorldMatrix().getRotationMatrixToRef(KO), KO.invert(), OO.multiplyToRef(KO, OO), this.rotationQuaternion.fromRotationMatrix(OO)
            } else {
              const OO = MO.j.Quaternion[0];
              MO.g.FromEulerVectorToRef(this.rotation, OO);
              const KO = MO.j.Matrix[0];
              OO.toRotationMatrix(KO);
              const pO = MO.j.Matrix[1];
              this.parent.getWorldMatrix().getRotationMatrixToRef(pO), pO.invert(), KO.multiplyToRef(pO, KO), OO.fromRotationMatrix(KO), OO.toEulerAnglesToRef(this.rotation)
            } return this
        }
        YbO(OO) {
          const KO = MO.o.Zero();
          return this.getDirectionToRef(OO, KO), KO
        }
        getDirectionToRef(OO, KO) {
          return MO.o.TransformNormalToRef(OO, this.getWorldMatrix(), KO), this
        }
        setDirection(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
          const bK = -Math.atan2(OO.z, OO.x) + Math.PI / 2,
            eO = Math.sqrt(OO.x * OO.x + OO.z * OO.z),
            lO = -Math.atan2(OO.y, eO);
          return this.rotationQuaternion ? MO.g.RotationYawPitchRollToRef(bK + KO, lO + pO, XO, this.rotationQuaternion) : (this.rotation.x = lO + pO, this.rotation.y = bK + KO, this.rotation.z = XO), this
        }
        setPivotPoint(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
          0 == this.JKO().getRenderId() && this.computeWorldMatrix(!0);
          const pO = this.getWorldMatrix();
          if (1 == KO) {
            const KO = MO.j.Matrix[0];
            pO.invertToRef(KO), OO = MO.o.TransformCoordinates(OO, KO)
          }
          return this.setPivotMatrix(MO.c.Translation(-OO.x, -OO.y, -OO.z), !0)
        }
        getPivotPoint() {
          const OO = MO.o.Zero();
          return this.getPivotPointToRef(OO), OO
        }
        getPivotPointToRef(OO) {
          return OO.x = -this._pivotMatrix.m[12], OO.y = -this._pivotMatrix.m[13], OO.z = -this._pivotMatrix.m[14], this
        }
        getAbsolutePivotPoint() {
          const OO = MO.o.Zero();
          return this.getAbsolutePivotPointToRef(OO), OO
        }
        getAbsolutePivotPointToRef(OO) {
          return this.getPivotPointToRef(OO), MO.o.TransformCoordinatesToRef(OO, this.getWorldMatrix(), OO), this
        }
        jhO(OO) {
          if (this._isDirty) return this;
          if (this._children)
            for (const KO of this._children) KO.jhO(OO);
          return super.jhO(OO)
        }
        setParent(KO) {
          let pO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            XO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
          if (!KO && !this.parent) return this;
          const bK = MO.j.Quaternion[0],
            eO = MO.j.WX[0],
            lO = MO.j.WX[1],
            vK = MO.j.Matrix[1];
          MO.c.IdentityToRef(vK);
          const CO = MO.j.Matrix[0];
          this.computeWorldMatrix(!0);
          let hO = this.rotationQuaternion;
          return hO || (hO = OO._TmpRotation, MO.g.RotationYawPitchRollToRef(this._rotation.y, this._rotation.x, this._rotation.z, hO)), MO.c.ComposeToRef(this.ol, hO, this.position, CO), this.parent && CO.multiplyToRef(this.parent.computeWorldMatrix(!0), CO), KO && (KO.computeWorldMatrix(!0).invertToRef(vK), CO.multiplyToRef(vK, CO)), CO.decompose(lO, bK, eO, pO ? this : void 0), this.rotationQuaternion ? this.rotationQuaternion.NhO(bK) : bK.toEulerAnglesToRef(this.rotation), this.ol.NhO(lO), this.position.NhO(eO), this.parent = KO, XO && this.setPivotMatrix(MO.c.Identity()), this
        }
        addChild(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          return OO.setParent(this, KO), this
        }
        removeChild(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          return OO.parent !== this || OO.setParent(null, KO), this
        }
        get nonUniformScaling() {
          return this._nonUniformScaling
        }
        _updateNonUniformScalingState(OO) {
          return this._nonUniformScaling !== OO && (this._nonUniformScaling = OO, !0)
        }
        attachToBone(OO, KO) {
          return this._currentParentWhenAttachingToBone = this.parent, this._transformToBoneReferal = KO, this.parent = OO, OO.getSkeleton().prepare(!0), OO.getFinalMatrix().determinant() < 0 && (this.scalingDeterminant *= -1), this
        }
        detachFromBone() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          return this.parent ? (this.parent.getWorldMatrix().determinant() < 0 && (this.scalingDeterminant *= -1), this._transformToBoneReferal = null, this.parent = OO ? this._currentParentWhenAttachingToBone : null, this) : (OO && (this.parent = this._currentParentWhenAttachingToBone), this)
        }
        rotate(KO, pO, XO) {
          let bK;
          if (KO.normalize(), this.rotationQuaternion || (this.rotationQuaternion = this.rotation.toQuaternion(), this.rotation.plO(0)), XO && 0 !== XO) {
            if (this.parent) {
              const OO = this.parent.getWorldMatrix(),
                XO = MO.j.Matrix[0];
              OO.invertToRef(XO), KO = MO.o.TransformNormal(KO, XO), OO.determinant() < 0 && (pO *= -1)
            }
            bK = MO.g.RotationAxisToRef(KO, pO, OO._RotationAxisCache), bK.multiplyToRef(this.rotationQuaternion, this.rotationQuaternion)
          } else bK = MO.g.RotationAxisToRef(KO, pO, OO._RotationAxisCache), this.rotationQuaternion.multiplyToRef(bK, this.rotationQuaternion);
          return this
        }
        rotateAround(OO, KO, pO) {
          KO.normalize(), this.rotationQuaternion || (this.rotationQuaternion = MO.g.RotationYawPitchRoll(this.rotation.y, this.rotation.x, this.rotation.z), this.rotation.plO(0));
          const XO = MO.j.WX[0],
            bK = MO.j.WX[1],
            eO = MO.j.WX[2],
            lO = MO.j.Quaternion[0],
            vK = MO.j.Matrix[0],
            CO = MO.j.Matrix[1],
            hO = MO.j.Matrix[2],
            DO = MO.j.Matrix[3];
          return OO.subtractToRef(this.position, XO), MO.c.TranslationToRef(XO.x, XO.y, XO.z, vK), MO.c.TranslationToRef(-XO.x, -XO.y, -XO.z, CO), MO.c.RotationAxisToRef(KO, pO, hO), CO.multiplyToRef(hO, DO), DO.multiplyToRef(vK, DO), DO.decompose(bK, lO, eO), this.position.addInPlace(eO), lO.multiplyToRef(this.rotationQuaternion, this.rotationQuaternion), this
        }
        translate(OO, KO, pO) {
          const XO = OO.scale(KO);
          if (pO && 0 !== pO) this.setAbsolutePosition(this.getAbsolutePosition().add(XO));
          else {
            const OO = this.getPositionExpressedInLocalSpace().add(XO);
            this.setPositionWithLocalVector(OO)
          }
          return this
        }
        addRotation(OO, KO, pO) {
          let XO;
          this.rotationQuaternion ? XO = this.rotationQuaternion : (XO = MO.j.Quaternion[1], MO.g.RotationYawPitchRollToRef(this.rotation.y, this.rotation.x, this.rotation.z, XO));
          const bK = MO.j.Quaternion[0];
          return MO.g.RotationYawPitchRollToRef(KO, OO, pO, bK), XO.multiplyInPlace(bK), this.rotationQuaternion || XO.toEulerAnglesToRef(this.rotation), this
        }
        _getEffectiveParent() {
          return this.parent
        }
        isWorldMatrixCameraDependent() {
          return this._infiniteDistance && !this.parent || this._billboardMode !== OO.BILLBOARDMODE_NONE
        }
        computeWorldMatrix() {
          let KO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
            pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          if (this._isWorldMatrixFrozen && !this._isDirty) return this._worldMatrix;
          const XO = this.JKO().getRenderId();
          if (!this._isDirty && !KO && (this._currentRenderId === XO || this.isSynchronized())) return this._currentRenderId = XO, this._worldMatrix;
          pO = pO || this.JKO().activeCamera, this._updateCache();
          const bK = this._cache;
          bK.pivotMatrixUpdated = !1, bK.billboardMode = this.billboardMode, bK.infiniteDistance = this.infiniteDistance, bK.parent = this._parentNode, this._currentRenderId = XO, this._childUpdateId += 1, this._isDirty = !1, this._position._isDirty = !1, this._rotation._isDirty = !1, this._scaling._isDirty = !1;
          const eO = this._getEffectiveParent(),
            lO = OO._TmpScaling;
          let vK, CO = this._position;
          if (this._infiniteDistance && !this.parent && pO) {
            const KO = pO.getWorldMatrix().m;
            CO = OO._TmpTranslation, CO.rvO(this._position.x + KO[12], this._position.y + KO[13], this._position.z + KO[14])
          }
          if (lO.rvO(this._scaling.x * this.scalingDeterminant, this._scaling.y * this.scalingDeterminant, this._scaling.z * this.scalingDeterminant), this._rotationQuaternion) {
            if (this._rotationQuaternion._isDirty = !1, vK = this._rotationQuaternion, this.reIntegrateRotationIntoRotationQuaternion) {
              this.rotation.lengthSquared() && (this._rotationQuaternion.multiplyInPlace(MO.g.RotationYawPitchRoll(this._rotation.y, this._rotation.x, this._rotation.z)), this._rotation.rvO(0, 0, 0))
            }
          } else vK = OO._TmpRotation, MO.g.RotationYawPitchRollToRef(this._rotation.y, this._rotation.x, this._rotation.z, vK);
          if (this._usePivotMatrix) {
            const OO = MO.j.Matrix[1];
            MO.c.ScalingToRef(lO.x, lO.y, lO.z, OO);
            const KO = MO.j.Matrix[0];
            vK.toRotationMatrix(KO), this._pivotMatrix.multiplyToRef(OO, MO.j.Matrix[4]), MO.j.Matrix[4].multiplyToRef(KO, this._localMatrix), this._postMultiplyPivotMatrix && this._localMatrix.multiplyToRef(this._pivotMatrixInverse, this._localMatrix), this._localMatrix.addTranslationFromFloats(CO.x, CO.y, CO.z)
          } else MO.c.ComposeToRef(lO, vK, CO, this._localMatrix);
          if (eO && eO.getWorldMatrix) {
            if (KO && eO.computeWorldMatrix(KO), this.billboardMode) {
              if (this._transformToBoneReferal) {
                const OO = this.parent;
                OO.getSkeleton().prepare(), OO.getFinalMatrix().multiplyToRef(this._transformToBoneReferal.getWorldMatrix(), MO.j.Matrix[7])
              } else MO.j.Matrix[7].NhO(eO.getWorldMatrix());
              const KO = MO.j.WX[5],
                pO = MO.j.WX[6],
                XO = MO.j.Quaternion[0];
              MO.j.Matrix[7].decompose(pO, XO, KO), MO.c.ScalingToRef(pO.x, pO.y, pO.z, MO.j.Matrix[7]), MO.j.Matrix[7].setTranslation(KO), OO.BillboardUseParentOrientation && (this._position.applyRotationQuaternionToRef(XO, KO), this._localMatrix.setTranslation(KO)), this._localMatrix.multiplyToRef(MO.j.Matrix[7], this._worldMatrix)
            } else if (this._transformToBoneReferal) {
              const OO = this.parent;
              OO.getSkeleton().prepare(), this._localMatrix.multiplyToRef(OO.getFinalMatrix(), MO.j.Matrix[6]), MO.j.Matrix[6].multiplyToRef(this._transformToBoneReferal.getWorldMatrix(), this._worldMatrix)
            } else this._localMatrix.multiplyToRef(eO.getWorldMatrix(), this._worldMatrix);
            this._markSyncedWithParent()
          } else this._worldMatrix.NhO(this._localMatrix);
          if (pO && this.billboardMode)
            if (bK.useBillboardPosition) {
              const KO = MO.j.WX[0];
              this._worldMatrix.getTranslationToRef(KO);
              const XO = pO.globalPosition;
              this._worldMatrix.invertToRef(MO.j.Matrix[1]);
              const bK = MO.j.WX[1];
              MO.o.TransformCoordinatesToRef(XO, MO.j.Matrix[1], bK), bK.normalize();
              const eO = -Math.atan2(bK.z, bK.x) + Math.PI / 2,
                lO = Math.sqrt(bK.x * bK.x + bK.z * bK.z),
                vK = -Math.atan2(bK.y, lO);
              if (MO.g.RotationYawPitchRollToRef(eO, vK, 0, MO.j.Quaternion[0]), (this.billboardMode & OO.BILLBOARDMODE_ALL) !== OO.BILLBOARDMODE_ALL) {
                const KO = MO.j.WX[1];
                MO.j.Quaternion[0].toEulerAnglesToRef(KO), (this.billboardMode & OO.BILLBOARDMODE_X) !== OO.BILLBOARDMODE_X && (KO.x = 0), (this.billboardMode & OO.BILLBOARDMODE_Y) !== OO.BILLBOARDMODE_Y && (KO.y = 0), (this.billboardMode & OO.BILLBOARDMODE_Z) !== OO.BILLBOARDMODE_Z && (KO.z = 0), MO.c.RotationYawPitchRollToRef(KO.y, KO.x, KO.z, MO.j.Matrix[0])
              } else MO.c.FromQuaternionToRef(MO.j.Quaternion[0], MO.j.Matrix[0]);
              this._worldMatrix.setTranslationFromFloats(0, 0, 0), this._worldMatrix.multiplyToRef(MO.j.Matrix[0], this._worldMatrix), this._worldMatrix.setTranslation(MO.j.WX[0])
            } else {
              const KO = MO.j.WX[0];
              this._worldMatrix.getTranslationToRef(KO), MO.j.Matrix[1].NhO(pO.getViewMatrix());
              const XO = this.JKO().useRightHandedSystem;
              if (XO && MO.j.Matrix[1].multiplyToRef(OO._TmpRHRestore, MO.j.Matrix[1]), MO.j.Matrix[1].setTranslationFromFloats(0, 0, 0), MO.j.Matrix[1].invertToRef(MO.j.Matrix[0]), (this.billboardMode & OO.BILLBOARDMODE_ALL) !== OO.BILLBOARDMODE_ALL) {
                MO.j.Matrix[0].decompose(void 0, MO.j.Quaternion[0], void 0);
                const KO = MO.j.WX[1];
                MO.j.Quaternion[0].toEulerAnglesToRef(KO), (this.billboardMode & OO.BILLBOARDMODE_X) !== OO.BILLBOARDMODE_X && (KO.x = 0), (this.billboardMode & OO.BILLBOARDMODE_Y) !== OO.BILLBOARDMODE_Y && (KO.y = 0), (this.billboardMode & OO.BILLBOARDMODE_Z) !== OO.BILLBOARDMODE_Z && (KO.z = 0), XO && (KO.y += Math.PI), MO.c.RotationYawPitchRollToRef(KO.y, KO.x, KO.z, MO.j.Matrix[0])
              }
              this._worldMatrix.setTranslationFromFloats(0, 0, 0), this._worldMatrix.multiplyToRef(MO.j.Matrix[0], this._worldMatrix), this._worldMatrix.setTranslation(MO.j.WX[0])
            } return this.ignoreNonUniformScaling ? this._updateNonUniformScalingState(!1) : this._scaling.isNonUniformWithinEpsilon(1e-6) ? this._updateNonUniformScalingState(!0) : eO && eO._nonUniformScaling ? this._updateNonUniformScalingState(eO._nonUniformScaling) : this._updateNonUniformScalingState(!1), this._afterComputeWorldMatrix(), this._absolutePosition.rvO(this._worldMatrix.m[12], this._worldMatrix.m[13], this._worldMatrix.m[14]), this._isAbsoluteSynced = !1, this.onAfterWorldMatrixUpdateObservable.notifyObservers(this), this._poseMatrix || (this._poseMatrix = MO.c.Invert(this._worldMatrix)), this._worldMatrixDeterminantIsDirty = !0, this._worldMatrix
        }
        resetLocalMatrix() {
          let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
          if (this.computeWorldMatrix(), OO) {
            const OO = this.getChildren();
            for (let KO = 0; KO < OO.length; ++KO) {
              const pO = OO[KO];
              if (pO) {
                pO.computeWorldMatrix();
                const OO = MO.j.Matrix[0];
                pO._localMatrix.multiplyToRef(this._localMatrix, OO);
                const KO = MO.j.Quaternion[0];
                OO.decompose(pO.ol, KO, pO.position), pO.rotationQuaternion ? pO.rotationQuaternion.NhO(KO) : KO.toEulerAnglesToRef(pO.rotation)
              }
            }
          }
          this.ol.rvO(1, 1, 1), this.position.rvO(0, 0, 0), this.rotation.rvO(0, 0, 0), this.rotationQuaternion && (this.rotationQuaternion = MO.g.Identity()), this._worldMatrix = MO.c.Identity()
        }
        _afterComputeWorldMatrix() {}
        registerAfterWorldMatrixUpdate(OO) {
          return this.onAfterWorldMatrixUpdateObservable.add(OO), this
        }
        unregisterAfterWorldMatrixUpdate(OO) {
          return this.onAfterWorldMatrixUpdateObservable.removeCallback(OO), this
        }
        getPositionInCameraSpace() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
          return OO || (OO = this.JKO().activeCamera), MO.o.TransformCoordinates(this.getAbsolutePosition(), OO.getViewMatrix())
        }
        getDistanceToCamera() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
          return OO || (OO = this.JKO().activeCamera), this.getAbsolutePosition().subtract(OO.globalPosition).length()
        }
        clone(KO, pO, XO) {
          const bK = hO.c.Clone((() => new OO(KO, this.JKO())), this);
          if (bK.name = KO, bK.id = KO, pO && (bK.parent = pO), !XO) {
            const OO = this.getDescendants(!0);
            for (let pO = 0; pO < OO.length; pO++) {
              const XO = OO[pO];
              XO.clone && XO.clone(KO + "." + XO.name, bK)
            }
          }
          return bK
        }
        serialize(OO) {
          const KO = hO.c.Serialize(this, OO);
          return KO.type = this.getClassName(), KO.uniqueId = this.uniqueId, this.parent && this.parent._serializeAsParent(KO), KO.localMatrix = this.getPivotMatrix().WhO(), KO.isEnabled = this.isEnabled(), this._isWorldMatrixFrozen && (KO.qpO = !0), hO.c.AppendSerializedAnimations(this, KO), KO.Xl = this.serializeAnimationRanges(), KO
        }
        getChildTransformNodes(KO, pO) {
          const XO = [];
          return this._getDescendants(XO, KO, (KO => (!pO || pO(KO)) && KO instanceof OO)), XO
        }
        dispose(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          if (this.JKO().stopAnimation(this), this.JKO().removeTransformNode(this), this._parentContainer) {
            const OO = this._parentContainer.transformNodes.indexOf(this);
            OO > -1 && this._parentContainer.transformNodes.splice(OO, 1), this._parentContainer = null
          }
          if (this.onAfterWorldMatrixUpdateObservable.clear(), OO) {
            const OO = this.getChildTransformNodes(!0);
            for (const KO of OO) KO.parent = null, KO.computeWorldMatrix(!0)
          }
          super.dispose(OO, KO)
        }
        normalizeToUnitCube() {
          let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            pO = arguments.length > 2 ? arguments[2] : void 0,
            XO = null,
            bK = null;
          KO && (this.rotationQuaternion ? (bK = this.rotationQuaternion.clone(), this.rotationQuaternion.rvO(0, 0, 0, 1)) : this.rotation && (XO = this.rotation.clone(), this.rotation.rvO(0, 0, 0)));
          const eO = this.getHierarchyBoundingVectors(OO, pO),
            lO = eO.max.subtract(eO.min),
            vK = Math.max(lO.x, lO.y, lO.z);
          if (0 === vK) return this;
          const CO = 1 / vK;
          return this.ol.scaleInPlace(CO), KO && (this.rotationQuaternion && bK ? this.rotationQuaternion.NhO(bK) : this.rotation && XO && this.rotation.NhO(XO)), this
        }
        _syncAbsoluteScalingAndRotation() {
          this._isAbsoluteSynced || (this._worldMatrix.decompose(this._absoluteScaling, this._absoluteRotationQuaternion), this._isAbsoluteSynced = !0)
        }
      }, (() => {
        const hO = "function" === typeof Symbol && Symbol.metadata ? Object.create(LO[Symbol.metadata] ?? null) : void 0;
        KO = [(0, CO.L)("position")], pO = [(0, CO.L)("rotation")], XO = [(0, CO.E)("rotationQuaternion")], bK = [(0, CO.L)("ol")], eO = [(0, CO.M)("billboardMode")], lO = [(0, CO.M)()], oO = [(0, CO.M)("infiniteDistance")], FO = [(0, CO.M)()], VO = [(0, CO.M)()], (0, vK.f)(null, null, KO, {
          kind: "field",
          name: "_position",
          static: !1,
          private: !1,
          access: {
            has: OO => "_position" in OO,
            get: OO => OO._position,
            set: (OO, KO) => {
              OO._position = KO
            }
          },
          metadata: hO
        }, QO, zK), (0, vK.f)(null, null, pO, {
          kind: "field",
          name: "_rotation",
          static: !1,
          private: !1,
          access: {
            has: OO => "_rotation" in OO,
            get: OO => OO._rotation,
            set: (OO, KO) => {
              OO._rotation = KO
            }
          },
          metadata: hO
        }, AO, fO), (0, vK.f)(null, null, XO, {
          kind: "field",
          name: "_rotationQuaternion",
          static: !1,
          private: !1,
          access: {
            has: OO => "_rotationQuaternion" in OO,
            get: OO => OO._rotationQuaternion,
            set: (OO, KO) => {
              OO._rotationQuaternion = KO
            }
          },
          metadata: hO
        }, dO, TO), (0, vK.f)(null, null, bK, {
          kind: "field",
          name: "_scaling",
          static: !1,
          private: !1,
          access: {
            has: OO => "_scaling" in OO,
            get: OO => OO._scaling,
            set: (OO, KO) => {
              OO._scaling = KO
            }
          },
          metadata: hO
        }, NO, IO), (0, vK.f)(null, null, eO, {
          kind: "field",
          name: "_billboardMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "_billboardMode" in OO,
            get: OO => OO._billboardMode,
            set: (OO, KO) => {
              OO._billboardMode = KO
            }
          },
          metadata: hO
        }, yK, gK), (0, vK.f)(null, null, lO, {
          kind: "field",
          name: "scalingDeterminant",
          static: !1,
          private: !1,
          access: {
            has: OO => "scalingDeterminant" in OO,
            get: OO => OO.scalingDeterminant,
            set: (OO, KO) => {
              OO.scalingDeterminant = KO
            }
          },
          metadata: hO
        }, uO, EO), (0, vK.f)(null, null, oO, {
          kind: "field",
          name: "_infiniteDistance",
          static: !1,
          private: !1,
          access: {
            has: OO => "_infiniteDistance" in OO,
            get: OO => OO._infiniteDistance,
            set: (OO, KO) => {
              OO._infiniteDistance = KO
            }
          },
          metadata: hO
        }, jK, YO), (0, vK.f)(null, null, FO, {
          kind: "field",
          name: "ignoreNonUniformScaling",
          static: !1,
          private: !1,
          access: {
            has: OO => "ignoreNonUniformScaling" in OO,
            get: OO => OO.ignoreNonUniformScaling,
            set: (OO, KO) => {
              OO.ignoreNonUniformScaling = KO
            }
          },
          metadata: hO
        }, wO, iK), (0, vK.f)(null, null, VO, {
          kind: "field",
          name: "reIntegrateRotationIntoRotationQuaternion",
          static: !1,
          private: !1,
          access: {
            has: OO => "reIntegrateRotationIntoRotationQuaternion" in OO,
            get: OO => OO.reIntegrateRotationIntoRotationQuaternion,
            set: (OO, KO) => {
              OO.reIntegrateRotationIntoRotationQuaternion = KO
            }
          },
          metadata: hO
        }, rK, PO), hO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: hO
        })
      })(), OO.BILLBOARDMODE_NONE = 0, OO.BILLBOARDMODE_X = 1, OO.BILLBOARDMODE_Y = 2, OO.BILLBOARDMODE_Z = 4, OO.BILLBOARDMODE_ALL = 7, OO.BILLBOARDMODE_USE_POSITION = 128, OO.BillboardUseParentOrientation = !1, OO._TmpRotation = MO.g.Zero(), OO._TmpScaling = MO.o.Zero(), OO._TmpTranslation = MO.o.Zero(), OO._TmpRHRestore = MO.c.Scaling(1, 1, -1), OO._LookAtVectorCache = new MO.o(0, 0, 0), OO._RotationAxisCache = new MO.g, OO
    })();

    function LO(OO, KO, pO) {
      const XO = hO.c.Parse((() => new VO(OO.name, KO)), OO, KO, pO);
      if (OO.localMatrix ? XO.setPreTransformMatrix(MO.c.FromArray(OO.localMatrix)) : OO.pivotMatrix && XO.setPivotMatrix(MO.c.FromArray(OO.pivotMatrix)), XO.WE(OO.isEnabled), XO._waitingParsedUniqueId = OO.uniqueId, void 0 !== OO.parentId && (XO._waitingParentId = OO.parentId), void 0 !== OO.parentInstanceIndex && (XO._waitingParentInstanceIndex = OO.parentInstanceIndex), OO.qpO && (XO._waitingFreezeWorldMatrix = OO.qpO), OO.animations) {
        for (let KO = 0; KO < OO.animations.length; KO++) {
          const pO = OO.animations[KO],
            bK = (0, oO.e)("BABYLON.Animation");
          bK && XO.animations.push(bK.Parse(pO))
        }
        aK.c.ParseAnimationRanges(XO, OO, KO)
      }
      return OO.autoAnimate && KO.beginAnimation(XO, OO.autoAnimateFrom, OO.autoAnimateTo, OO.autoAnimateLoop, OO.autoAnimateSpeed || 1), XO
    }
    let QO = !1;

    function zK() {
      QO || (QO = !0, VO.Parse = LO)
    }(XO = VO.prototype).XXO ?? (XO.XXO = (0, FO.h)("TransformNode", "XXO")), (bK = VO.prototype).applyImpulse ?? (bK.applyImpulse = (0, FO.h)("TransformNode", "applyImpulse")), (eO = VO.prototype).applyAngularImpulse ?? (eO.applyAngularImpulse = (0, FO.h)("TransformNode", "applyAngularImpulse")), (lO = VO.prototype).applyTorque ?? (lO.applyTorque = (0, FO.h)("TransformNode", "applyTorque")), Object.getOwnPropertyDescriptor(VO.prototype, "physicsBody") || Object.defineProperty(VO.prototype, "physicsBody", (0, FO.e)("TransformNode", "physicsBody"))
  },
  38506: (OO, KO, pO) => {
    function XO(OO, KO, pO) {
      try {
        const XO = OO.next();
        XO.done ? KO(XO) : XO.value ? XO.value.then((() => {
          XO.value = void 0, KO(XO)
        }), pO) : KO(XO)
      } catch (XO) {
        pO(XO)
      }
    }

    function bK() {
      let OO, KO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 25;
      return (pO, bK, eO) => {
        const lO = performance.now();
        void 0 === OO || lO - OO > KO ? (OO = lO, setTimeout((() => {
          XO(pO, bK, eO)
        }), 0)) : XO(pO, bK, eO)
      }
    }

    function eO(OO, KO, pO, XO, bK) {
      const eO = () => {
        let lO;
        const vK = OO => {
          OO.done ? pO(OO.value) : void 0 === lO ? lO = !0 : eO()
        };
        do {
          lO = void 0, bK && bK.aborted ? XO(new Error("Aborted")) : KO(OO, vK, XO), void 0 === lO && (lO = !1)
        } while (lO)
      };
      eO()
    }

    function lO(OO, KO) {
      let pO;
      return eO(OO, XO, (OO => pO = OO), (OO => {
        throw OO
      }), KO), pO
    }
    async function vK(OO, KO, pO) {
      return await new Promise(((XO, bK) => {
        eO(OO, KO, XO, bK, pO)
      }))
    }

    function CO(OO, KO) {
      return function() {
        return lO(OO(...arguments), KO)
      }
    }
    pO.d(KO, {
      e: () => bK,
      f: () => CO,
      i: () => vK,
      k: () => lO
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);