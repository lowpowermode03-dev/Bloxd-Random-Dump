export const id = 341;
export const ids = [341];
export const modules = {
  59156: (OO, KO, pO) => {
    function XO(OO, KO) {
      for (const pO of OO._frameGraph._tasks)
        if (pO?._config && pO._colorAttachment && (pO._config.rt === KO.scRT || pO._config.rst === KO.scRT)) return pO
    }

    function bK(OO, KO) {
      const pO = OO._renderingContexts[OO._renderingContexts.length - 1];
      if (!pO?._frameGraph) return;
      const bK = XO(KO, OO);
      if (!bK) return;
      if (1 === OO.msaaSamples) return void(bK._config.clr = !1);
      const eO = bK.enabled;
      bK._config.clr = !0, bK.enabled = !1, KO._beforeRender.unshift((() => {
        const KO = XO(pO, OO),
          lO = KO?._config.rst === OO.scRT && KO._config.rt._colorView;
        bK.enabled = !!lO && eO, bK._config.clr = !lO, lO && (bK._colorAttachment.view = lO)
      }))
    }
    pO.r(KO), pO.d(KO, {
      configureSwapchainOverlayScene: () => bK
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);