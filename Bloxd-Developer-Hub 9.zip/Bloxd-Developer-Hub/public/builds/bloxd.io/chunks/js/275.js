export const id = 275;
export const ids = [275];
export const modules = {
  39338: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => zp,
      h: () => wO,
      ChangeSet: () => iK,
      i: () => jp,
      j: () => JO,
      m: () => rp,
      n: () => ZO,
      r: () => YO,
      u: () => bp,
      y: () => JK,
      v: () => cp,
      A: () => mp,
      C: () => dK,
      G: () => kK,
      I: () => VO,
      M: () => TK,
      N: () => gK,
      P: () => EO,
      T: () => PK,
      U: () => Op,
      Y: () => yK,
      _: () => Kp,
      ab: () => uO
    });
    let XO = [],
      bK = [];

    function eO(OO) {
      if (OO < 768) return !1;
      for (let KO = 0, pO = XO.length;;) {
        let eO = KO + pO >> 1;
        if (OO < XO[eO]) pO = eO;
        else {
          if (!(OO >= bK[eO])) return !0;
          KO = eO + 1
        }
        if (KO == pO) return !1
      }
    }

    function lO(OO) {
      return OO >= 127462 && OO <= 127487
    }(() => {
      let OO = "lc,34,7n,7,7b,19,,,,2,,2,,,20,b,1c,l,g,,2t,7,2,6,2,2,,4,z,,u,r,2j,b,1m,9,9,,o,4,,9,,3,,5,17,3,3b,f,,w,1j,,,,4,8,4,,3,7,a,2,t,,1m,,,,2,4,8,,9,,a,2,q,,2,2,1l,,4,2,4,2,2,3,3,,u,2,3,,b,2,1l,,4,5,,2,4,,k,2,m,6,,,1m,,,2,,4,8,,7,3,a,2,u,,1n,,,,c,,9,,14,,3,,1l,3,5,3,,4,7,2,b,2,t,,1m,,2,,2,,3,,5,2,7,2,b,2,s,2,1l,2,,,2,4,8,,9,,a,2,t,,20,,4,,2,3,,,8,,29,,2,7,c,8,2q,,2,9,b,6,22,2,r,,,,,,1j,e,,5,,2,5,b,,10,9,,2u,4,,6,,2,2,2,p,2,4,3,g,4,d,,2,2,6,,f,,jj,3,qa,3,t,3,t,2,u,2,1s,2,,7,8,,2,b,9,,19,3,3b,2,y,,3a,3,4,2,9,,6,3,63,2,2,,1m,,,7,,,,,2,8,6,a,2,,1c,h,1r,4,1c,7,,,5,,14,9,c,2,w,4,2,2,,3,1k,,,2,3,,,3,1m,8,2,2,48,3,,d,,7,4,,6,,3,2,5i,1m,,5,ek,,5f,x,2da,3,3x,,2o,w,fe,6,2x,2,n9w,4,,a,w,2,28,2,7k,,3,,4,,p,2,5,,47,2,q,i,d,,12,8,p,b,1a,3,1c,,2,4,2,2,13,,1v,6,2,2,2,2,c,,8,,1b,,1f,,,3,2,2,5,2,,,16,2,8,,6m,,2,,4,,fn4,,kh,g,g,g,a6,2,gt,,6a,,45,5,1ae,3,,2,5,4,14,3,4,,4l,2,fx,4,ar,2,49,b,4w,,1i,f,1k,3,1d,4,2,2,1x,3,10,5,,8,1q,,c,2,1g,9,a,4,2,,2n,3,2,,,2,6,,4g,,3,8,l,2,1l,2,,,,,m,,e,7,3,5,5f,8,2,3,,,n,,29,,2,6,,,2,,,2,,2,6j,,2,4,6,2,,2,r,2,2d,8,2,,,2,2y,,,,2,6,,,2t,3,2,4,,5,77,9,,2,6t,,a,2,,,4,,40,4,2,2,4,,w,a,14,6,2,4,8,,9,6,2,3,1a,d,,2,ba,7,,6,,,2a,m,2,7,,2,,2,3e,6,3,,,2,,7,,,20,2,3,,,,9n,2,f0b,5,1n,7,t4,,1r,4,29,,f5k,2,43q,,,3,4,5,8,8,2,7,u,4,44,3,1iz,1j,4,1e,8,,e,,m,5,,f,11s,7,,h,2,7,,2,,5,79,7,c5,4,15s,7,31,7,240,5,gx7k,2o,3k,6o".split(",").map((OO => OO ? parseInt(OO, 36) : 1));
      for (let KO = 0, pO = 0; KO < OO.length; KO++)(KO % 2 ? bK : XO).push(pO += OO[KO])
    })();
    const vK = 8205;

    function CO(OO, KO) {
      return (!(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2] ? hO : DO)(OO, KO, !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3])
    }

    function hO(OO, KO, pO) {
      if (KO == OO.length) return KO;
      KO && aK(OO.charCodeAt(KO)) && oO(OO.charCodeAt(KO - 1)) && KO--;
      let XO = MO(OO, KO);
      for (KO += FO(XO); KO < OO.length;) {
        let bK = MO(OO, KO);
        if (XO == vK || bK == vK || pO && eO(bK)) KO += FO(bK), XO = bK;
        else {
          if (!lO(bK)) break;
          {
            let pO = 0,
              XO = KO - 2;
            for (; XO >= 0 && lO(MO(OO, XO));) pO++, XO -= 2;
            if (pO % 2 == 0) break;
            KO += 2
          }
        }
      }
      return KO
    }

    function DO(OO, KO, pO) {
      for (; KO > 0;) {
        let XO = hO(OO, KO - 2, pO);
        if (XO < KO) return XO;
        KO--
      }
      return 0
    }

    function MO(OO, KO) {
      let pO = OO.charCodeAt(KO);
      if (!oO(pO) || KO + 1 == OO.length) return pO;
      let XO = OO.charCodeAt(KO + 1);
      return aK(XO) ? XO - 56320 + (pO - 55296 << 10) + 65536 : pO
    }

    function aK(OO) {
      return OO >= 56320 && OO < 57344
    }

    function oO(OO) {
      return OO >= 55296 && OO < 56320
    }

    function FO(OO) {
      return OO < 65536 ? 1 : 2
    }
    class VO {
      lineAt(OO) {
        if (OO < 0 || OO > this.length) throw new RangeError(`Invalid position ${OO} in document of length ${this.length}`);
        return this.lineInner(OO, !1, 1, 0)
      }
      line(OO) {
        if (OO < 1 || OO > this.lines) throw new RangeError(`Invalid line number ${OO} in ${this.lines}-line document`);
        return this.lineInner(OO, !0, 1, 0)
      }
      replace(OO, KO, pO) {
        [OO, KO] = IO(this, OO, KO);
        let XO = [];
        return this.decompose(0, OO, XO, 2), pO.length && pO.decompose(0, pO.length, XO, 3), this.decompose(KO, this.length, XO, 1), QO.from(XO, this.length - (KO - OO) + pO.length)
      }
      append(OO) {
        return this.replace(this.length, this.length, OO)
      }
      slice(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.length;
        [OO, KO] = IO(this, OO, KO);
        let pO = [];
        return this.decompose(OO, KO, pO, 0), QO.from(pO, KO - OO)
      }
      eq(OO) {
        if (OO == this) return !0;
        if (OO.length != this.length || OO.lines != this.lines) return !1;
        let KO = this.scanIdentical(OO, 1),
          pO = this.length - this.scanIdentical(OO, -1),
          XO = new fO(this),
          bK = new fO(OO);
        for (let eO = KO, lO = KO;;) {
          if (XO.next(eO), bK.next(eO), eO = 0, XO.lineBreak != bK.lineBreak || XO.done != bK.done || XO.value != bK.value) return !1;
          if (lO += XO.value.length, XO.done || lO >= pO) return !0
        }
      }
      iter() {
        return new fO(this, arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1)
      }
      iterRange(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.length;
        return new dO(this, OO, KO)
      }
      iterLines(OO, KO) {
        let pO;
        if (null == OO) pO = this.iter();
        else {
          null == KO && (KO = this.lines + 1);
          let XO = this.line(OO).from;
          pO = this.iterRange(XO, Math.max(XO, KO == this.lines + 1 ? this.length : KO <= 1 ? 0 : this.line(KO - 1).to))
        }
        return new TO(pO)
      }
      toString() {
        return this.sliceString(0)
      }
      toJSON() {
        let OO = [];
        return this.flatten(OO), OO
      }
      constructor() {}
      static of (OO) {
        if (0 == OO.length) throw new RangeError("A document must have at least one line");
        return 1 != OO.length || OO[0] ? OO.length <= 32 ? new LO(OO) : QO.from(LO.split(OO, [])) : VO.empty
      }
    }
    class LO extends VO {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function(OO) {
          let KO = -1;
          for (let pO of OO) KO += pO.length + 1;
          return KO
        }(OO);
        super(), this.text = OO, this.length = KO
      }
      get lines() {
        return this.text.length
      }
      get children() {
        return null
      }
      lineInner(OO, KO, pO, XO) {
        for (let bK = 0;; bK++) {
          let eO = this.text[bK],
            lO = XO + eO.length;
          if ((KO ? pO : lO) >= OO) return new NO(XO, lO, pO, eO);
          XO = lO + 1, pO++
        }
      }
      decompose(OO, KO, pO, XO) {
        let bK = OO <= 0 && KO >= this.length ? this : new LO(AO(this.text, OO, KO), Math.min(KO, this.length) - Math.max(0, OO));
        if (1 & XO) {
          let OO = pO.pop(),
            KO = zK(bK.text, OO.text.slice(), 0, bK.length);
          if (KO.length <= 32) pO.push(new LO(KO, OO.length + bK.length));
          else {
            let OO = KO.length >> 1;
            pO.push(new LO(KO.slice(0, OO)), new LO(KO.slice(OO)))
          }
        } else pO.push(bK)
      }
      replace(OO, KO, pO) {
        if (!(pO instanceof LO)) return super.replace(OO, KO, pO);
        [OO, KO] = IO(this, OO, KO);
        let XO = zK(this.text, zK(pO.text, AO(this.text, 0, OO)), KO),
          bK = this.length + pO.length - (KO - OO);
        return XO.length <= 32 ? new LO(XO, bK) : QO.from(LO.split(XO, []), bK)
      }
      sliceString(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.length,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "\n";
        [OO, KO] = IO(this, OO, KO);
        let XO = "";
        for (let bK = 0, eO = 0; bK <= KO && eO < this.text.length; eO++) {
          let lO = this.text[eO],
            vK = bK + lO.length;
          bK > OO && eO && (XO += pO), OO < vK && KO > bK && (XO += lO.slice(Math.max(0, OO - bK), KO - bK)), bK = vK + 1
        }
        return XO
      }
      flatten(OO) {
        for (let KO of this.text) OO.push(KO)
      }
      scanIdentical() {
        return 0
      }
      static split(OO, KO) {
        let pO = [],
          XO = -1;
        for (let bK of OO) pO.push(bK), XO += bK.length + 1, 32 == pO.length && (KO.push(new LO(pO, XO)), pO = [], XO = -1);
        return XO > -1 && KO.push(new LO(pO, XO)), KO
      }
    }
    class QO extends VO {
      constructor(OO, KO) {
        super(), this.children = OO, this.length = KO, this.lines = 0;
        for (let pO of OO) this.lines += pO.lines
      }
      lineInner(OO, KO, pO, XO) {
        for (let bK = 0;; bK++) {
          let eO = this.children[bK],
            lO = XO + eO.length,
            vK = pO + eO.lines - 1;
          if ((KO ? vK : lO) >= OO) return eO.lineInner(OO, KO, pO, XO);
          XO = lO + 1, pO = vK + 1
        }
      }
      decompose(OO, KO, pO, XO) {
        for (let bK = 0, eO = 0; eO <= KO && bK < this.children.length; bK++) {
          let lO = this.children[bK],
            vK = eO + lO.length;
          if (OO <= vK && KO >= eO) {
            let bK = XO & ((eO <= OO ? 1 : 0) | (vK >= KO ? 2 : 0));
            eO >= OO && vK <= KO && !bK ? pO.push(lO) : lO.decompose(OO - eO, KO - eO, pO, bK)
          }
          eO = vK + 1
        }
      }
      replace(OO, KO, pO) {
        if ([OO, KO] = IO(this, OO, KO), pO.lines < this.lines)
          for (let XO = 0, bK = 0; XO < this.children.length; XO++) {
            let eO = this.children[XO],
              lO = bK + eO.length;
            if (OO >= bK && KO <= lO) {
              let vK = eO.replace(OO - bK, KO - bK, pO),
                CO = this.lines - eO.lines + vK.lines;
              if (vK.lines < CO >> 4 && vK.lines > CO >> 6) {
                let bK = this.children.slice();
                return bK[XO] = vK, new QO(bK, this.length - (KO - OO) + pO.length)
              }
              return super.replace(bK, lO, vK)
            }
            bK = lO + 1
          }
        return super.replace(OO, KO, pO)
      }
      sliceString(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.length,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "\n";
        [OO, KO] = IO(this, OO, KO);
        let XO = "";
        for (let bK = 0, eO = 0; bK < this.children.length && eO <= KO; bK++) {
          let lO = this.children[bK],
            vK = eO + lO.length;
          eO > OO && bK && (XO += pO), OO < vK && KO > eO && (XO += lO.sliceString(OO - eO, KO - eO, pO)), eO = vK + 1
        }
        return XO
      }
      flatten(OO) {
        for (let KO of this.children) KO.flatten(OO)
      }
      scanIdentical(OO, KO) {
        if (!(OO instanceof QO)) return 0;
        let pO = 0,
          [XO, bK, eO, lO] = KO > 0 ? [0, 0, this.children.length, OO.children.length] : [this.children.length - 1, OO.children.length - 1, -1, -1];
        for (;; XO += KO, bK += KO) {
          if (XO == eO || bK == lO) return pO;
          let vK = this.children[XO],
            CO = OO.children[bK];
          if (vK != CO) return pO + vK.scanIdentical(CO, KO);
          pO += vK.length + 1
        }
      }
      static from(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO.reduce(((OO, KO) => OO + KO.length + 1), -1),
          pO = 0;
        for (let aK of OO) pO += aK.lines;
        if (pO < 32) {
          let pO = [];
          for (let KO of OO) KO.flatten(pO);
          return new LO(pO, KO)
        }
        let XO = Math.max(32, pO >> 5),
          bK = XO << 1,
          eO = XO >> 1,
          lO = [],
          vK = 0,
          CO = -1,
          hO = [];

        function DO(OO) {
          let KO;
          if (OO.lines > bK && OO instanceof QO)
            for (let pO of OO.children) DO(pO);
          else OO.lines > eO && (vK > eO || !vK) ? (MO(), lO.push(OO)) : OO instanceof LO && vK && (KO = hO[hO.length - 1]) instanceof LO && OO.lines + KO.lines <= 32 ? (vK += OO.lines, CO += OO.length + 1, hO[hO.length - 1] = new LO(KO.text.concat(OO.text), KO.length + 1 + OO.length)) : (vK + OO.lines > XO && MO(), vK += OO.lines, CO += OO.length + 1, hO.push(OO))
        }

        function MO() {
          0 != vK && (lO.push(1 == hO.length ? hO[0] : QO.from(hO, CO)), CO = -1, vK = hO.length = 0)
        }
        for (let aK of OO) DO(aK);
        return MO(), 1 == lO.length ? lO[0] : new QO(lO, KO)
      }
    }

    function zK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
        XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1e9;
      for (let bK = 0, eO = 0, lO = !0; eO < OO.length && bK <= XO; eO++) {
        let vK = OO[eO],
          CO = bK + vK.length;
        CO >= pO && (CO > XO && (vK = vK.slice(0, XO - bK)), bK < pO && (vK = vK.slice(pO - bK)), lO ? (KO[KO.length - 1] += vK, lO = !1) : KO.push(vK)), bK = CO + 1
      }
      return KO
    }

    function AO(OO, KO, pO) {
      return zK(OO, [""], KO, pO)
    }
    VO.empty = new LO([""], 0);
    class fO {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        this.dir = KO, this.done = !1, this.lineBreak = !1, this.value = "", this.nodes = [OO], this.offsets = [KO > 0 ? 1 : (OO instanceof LO ? OO.text.length : OO.children.length) << 1]
      }
      nextInner(OO, KO) {
        for (this.done = this.lineBreak = !1;;) {
          let pO = this.nodes.length - 1,
            XO = this.nodes[pO],
            bK = this.offsets[pO],
            eO = bK >> 1,
            lO = XO instanceof LO ? XO.text.length : XO.children.length;
          if (eO == (KO > 0 ? lO : 0)) {
            if (0 == pO) return this.done = !0, this.value = "", this;
            KO > 0 && this.offsets[pO - 1]++, this.nodes.pop(), this.offsets.pop()
          } else if ((1 & bK) == (KO > 0 ? 0 : 1)) {
            if (this.offsets[pO] += KO, 0 == OO) return this.lineBreak = !0, this.value = "\n", this;
            OO--
          } else if (XO instanceof LO) {
            let bK = XO.text[eO + (KO < 0 ? -1 : 0)];
            if (this.offsets[pO] += KO, bK.length > Math.max(0, OO)) return this.value = 0 == OO ? bK : KO > 0 ? bK.slice(OO) : bK.slice(0, bK.length - OO), this;
            OO -= bK.length
          } else {
            let bK = XO.children[eO + (KO < 0 ? -1 : 0)];
            OO > bK.length ? (OO -= bK.length, this.offsets[pO] += KO) : (KO < 0 && this.offsets[pO]--, this.nodes.push(bK), this.offsets.push(KO > 0 ? 1 : (bK instanceof LO ? bK.text.length : bK.children.length) << 1))
          }
        }
      }
      next() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return OO < 0 && (this.nextInner(-OO, -this.dir), OO = this.value.length), this.nextInner(OO, this.dir)
      }
    }
    class dO {
      constructor(OO, KO, pO) {
        this.value = "", this.done = !1, this.cursor = new fO(OO, KO > pO ? -1 : 1), this.pos = KO > pO ? OO.length : 0, this.from = Math.min(KO, pO), this.to = Math.max(KO, pO)
      }
      nextInner(OO, KO) {
        if (KO < 0 ? this.pos <= this.from : this.pos >= this.to) return this.value = "", this.done = !0, this;
        OO += Math.max(0, KO < 0 ? this.pos - this.to : this.from - this.pos);
        let pO = KO < 0 ? this.pos - this.from : this.to - this.pos;
        OO > pO && (OO = pO), pO -= OO;
        let {
          value: XO
        } = this.cursor.next(OO);
        return this.pos += (XO.length + OO) * KO, this.value = XO.length <= pO ? XO : KO < 0 ? XO.slice(XO.length - pO) : XO.slice(0, pO), this.done = !this.value, this
      }
      next() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return OO < 0 ? OO = Math.max(OO, this.from - this.pos) : OO > 0 && (OO = Math.min(OO, this.to - this.pos)), this.nextInner(OO, this.cursor.dir)
      }
      get lineBreak() {
        return this.cursor.lineBreak && "" != this.value
      }
    }
    class TO {
      constructor(OO) {
        this.inner = OO, this.afterBreak = !0, this.value = "", this.done = !1
      }
      next() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          {
            done: KO,
            lineBreak: pO,
            value: XO
          } = this.inner.next(OO);
        return KO && this.afterBreak ? (this.value = "", this.afterBreak = !1) : KO ? (this.done = !0, this.value = "") : pO ? this.afterBreak ? this.value = "" : (this.afterBreak = !0, this.next()) : (this.value = XO, this.afterBreak = !1), this
      }
      get lineBreak() {
        return !1
      }
    }
    "undefined" != typeof Symbol && (VO.prototype[Symbol.iterator] = function() {
      return this.iter()
    }, fO.prototype[Symbol.iterator] = dO.prototype[Symbol.iterator] = TO.prototype[Symbol.iterator] = function() {
      return this
    });
    class NO {
      constructor(OO, KO, pO, XO) {
        this.from = OO, this.to = KO, this.number = pO, this.text = XO
      }
      get length() {
        return this.to - this.from
      }
    }

    function IO(OO, KO, pO) {
      return [KO = Math.max(0, Math.min(OO.length, KO)), Math.max(KO, Math.min(OO.length, pO))]
    }

    function yK(OO, KO) {
      return CO(OO, KO, !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2], !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3])
    }

    function gK(OO, KO) {
      let pO = OO.charCodeAt(KO);
      if (!((XO = pO) >= 55296 && XO < 56320) || KO + 1 == OO.length) return pO;
      var XO;
      let bK = OO.charCodeAt(KO + 1);
      return function(OO) {
        return OO >= 56320 && OO < 57344
      }(bK) ? bK - 56320 + (pO - 55296 << 10) + 65536 : pO
    }

    function uO(OO) {
      return OO <= 65535 ? String.fromCharCode(OO) : (OO -= 65536, String.fromCharCode(55296 + (OO >> 10), 56320 + (1023 & OO)))
    }

    function EO(OO) {
      return OO < 65536 ? 1 : 2
    }
    const jK = /\r\n?|\n/;
    var YO = function(OO) {
      return OO[OO.Simple = 0] = "Simple", OO[OO.TrackDel = 1] = "TrackDel", OO[OO.TrackBefore = 2] = "TrackBefore", OO[OO.TrackAfter = 3] = "TrackAfter", OO
    }(YO || (YO = {}));
    class wO {
      constructor(OO) {
        this.sections = OO
      }
      get length() {
        let OO = 0;
        for (let KO = 0; KO < this.sections.length; KO += 2) OO += this.sections[KO];
        return OO
      }
      get newLength() {
        let OO = 0;
        for (let KO = 0; KO < this.sections.length; KO += 2) {
          let pO = this.sections[KO + 1];
          OO += pO < 0 ? this.sections[KO] : pO
        }
        return OO
      }
      get empty() {
        return 0 == this.sections.length || 2 == this.sections.length && this.sections[1] < 0
      }
      iterGaps(OO) {
        for (let KO = 0, pO = 0, XO = 0; KO < this.sections.length;) {
          let bK = this.sections[KO++],
            eO = this.sections[KO++];
          eO < 0 ? (OO(pO, XO, bK), XO += bK) : XO += eO, pO += bK
        }
      }
      iterChangedRanges(OO) {
        mK(this, OO, arguments.length > 1 && void 0 !== arguments[1] && arguments[1])
      }
      get invertedDesc() {
        let OO = [];
        for (let KO = 0; KO < this.sections.length;) {
          let pO = this.sections[KO++],
            XO = this.sections[KO++];
          XO < 0 ? OO.push(pO, XO) : OO.push(XO, pO)
        }
        return new wO(OO)
      }
      composeDesc(OO) {
        return this.empty ? OO : OO.empty ? this : HO(this, OO)
      }
      mapDesc(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return OO.empty ? this : sO(this, OO, KO)
      }
      mapPos(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : YO.Simple,
          XO = 0,
          bK = 0;
        for (let eO = 0; eO < this.sections.length;) {
          let lO = this.sections[eO++],
            vK = this.sections[eO++],
            CO = XO + lO;
          if (vK < 0) {
            if (CO > OO) return bK + (OO - XO);
            bK += lO
          } else {
            if (pO != YO.Simple && CO >= OO && (pO == YO.TrackDel && XO < OO && CO > OO || pO == YO.TrackBefore && XO < OO || pO == YO.TrackAfter && CO > OO)) return null;
            if (CO > OO || CO == OO && KO < 0 && !lO) return OO == XO || KO < 0 ? bK : bK + vK;
            bK += vK
          }
          XO = CO
        }
        if (OO > XO) throw new RangeError(`Position ${OO} is out of range for changeset of length ${XO}`);
        return bK
      }
      touchesRange(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO;
        for (let pO = 0, XO = 0; pO < this.sections.length && XO <= KO;) {
          let bK = XO + this.sections[pO++];
          if (this.sections[pO++] >= 0 && XO <= KO && bK >= OO) return !(XO < OO && bK > KO) || "cover";
          XO = bK
        }
        return !1
      }
      toString() {
        let OO = "";
        for (let KO = 0; KO < this.sections.length;) {
          let pO = this.sections[KO++],
            XO = this.sections[KO++];
          OO += (OO ? " " : "") + pO + (XO >= 0 ? ":" + XO : "")
        }
        return OO
      }
      toJSON() {
        return this.sections
      }
      static fromJSON(OO) {
        if (!Array.isArray(OO) || OO.length % 2 || OO.some((OO => "number" != typeof OO))) throw new RangeError("Invalid JSON representation of ChangeDesc");
        return new wO(OO)
      }
      static create(OO) {
        return new wO(OO)
      }
    }
    class iK extends wO {
      constructor(OO, KO) {
        super(OO), this.inserted = KO
      }
      apply(OO) {
        if (this.length != OO.length) throw new RangeError("Applying change set to a document with the wrong length");
        return mK(this, ((KO, pO, XO, bK, eO) => OO = OO.replace(XO, XO + (pO - KO), eO)), !1), OO
      }
      mapDesc(OO) {
        return sO(this, OO, arguments.length > 1 && void 0 !== arguments[1] && arguments[1], !0)
      }
      invert(OO) {
        let KO = this.sections.slice(),
          pO = [];
        for (let XO = 0, bK = 0; XO < KO.length; XO += 2) {
          let eO = KO[XO],
            lO = KO[XO + 1];
          if (lO >= 0) {
            KO[XO] = lO, KO[XO + 1] = eO;
            let vK = XO >> 1;
            for (; pO.length < vK;) pO.push(VO.empty);
            pO.push(eO ? OO.slice(bK, bK + eO) : VO.empty)
          }
          bK += eO
        }
        return new iK(KO, pO)
      }
      compose(OO) {
        return this.empty ? OO : OO.empty ? this : HO(this, OO, !0)
      }
      map(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return OO.empty ? this : sO(this, OO, KO, !0)
      }
      iterChanges(OO) {
        mK(this, OO, arguments.length > 1 && void 0 !== arguments[1] && arguments[1])
      }
      get desc() {
        return wO.create(this.sections)
      }
      filter(OO) {
        let KO = [],
          pO = [],
          XO = [],
          bK = new RO(this);
        OO: for (let eO = 0, lO = 0;;) {
          let vK = eO == OO.length ? 1e9 : OO[eO++];
          for (; lO < vK || lO == vK && 0 == bK.len;) {
            if (bK.done) break OO;
            let OO = Math.min(bK.len, vK - lO);
            rK(XO, OO, -1);
            let eO = -1 == bK.ins ? -1 : 0 == bK.off ? bK.ins : 0;
            rK(KO, OO, eO), eO > 0 && PO(pO, KO, bK.text), bK.forward(OO), lO += OO
          }
          let CO = OO[eO++];
          for (; lO < CO;) {
            if (bK.done) break OO;
            let OO = Math.min(bK.len, CO - lO);
            rK(KO, OO, -1), rK(XO, OO, -1 == bK.ins ? -1 : 0 == bK.off ? bK.ins : 0), bK.forward(OO), lO += OO
          }
        }
        return {
          changes: new iK(KO, pO),
          filtered: wO.create(XO)
        }
      }
      toJSON() {
        let OO = [];
        for (let KO = 0; KO < this.sections.length; KO += 2) {
          let pO = this.sections[KO],
            XO = this.sections[KO + 1];
          XO < 0 ? OO.push(pO) : 0 == XO ? OO.push([pO]) : OO.push([pO].concat(this.inserted[KO >> 1].toJSON()))
        }
        return OO
      }
      static of (OO, KO, pO) {
        let XO = [],
          bK = [],
          eO = 0,
          lO = null;

        function vK() {
          if (!(arguments.length > 0 && void 0 !== arguments[0] && arguments[0]) && !XO.length) return;
          eO < KO && rK(XO, KO - eO, -1);
          let OO = new iK(XO, bK);
          lO = lO ? lO.compose(OO.map(lO)) : OO, XO = [], bK = [], eO = 0
        }
        return function OO(CO) {
          if (Array.isArray(CO))
            for (let KO of CO) OO(KO);
          else if (CO instanceof iK) {
            if (CO.length != KO) throw new RangeError(`Mismatched change set length (got ${CO.length}, expected ${KO})`);
            vK(), lO = lO ? lO.compose(CO.map(lO)) : CO
          } else {
            let {
              from: OO,
              to: lO = OO,
              insert: hO
            } = CO;
            if (OO > lO || OO < 0 || lO > KO) throw new RangeError(`Invalid change range ${OO} to ${lO} (in doc of length ${KO})`);
            let DO = hO ? "string" == typeof hO ? VO.of(hO.split(pO || jK)) : hO : VO.empty,
              MO = DO.length;
            if (OO == lO && 0 == MO) return;
            OO < eO && vK(), OO > eO && rK(XO, OO - eO, -1), rK(XO, lO - OO, MO), PO(bK, XO, DO), eO = lO
          }
        }(OO), vK(!lO), lO
      }
      static empty(OO) {
        return new iK(OO ? [OO, -1] : [], [])
      }
      static fromJSON(OO) {
        if (!Array.isArray(OO)) throw new RangeError("Invalid JSON representation of ChangeSet");
        let KO = [],
          pO = [];
        for (let XO = 0; XO < OO.length; XO++) {
          let bK = OO[XO];
          if ("number" == typeof bK) KO.push(bK, -1);
          else {
            if (!Array.isArray(bK) || "number" != typeof bK[0] || bK.some(((OO, KO) => KO && "string" != typeof OO))) throw new RangeError("Invalid JSON representation of ChangeSet");
            if (1 == bK.length) KO.push(bK[0], 0);
            else {
              for (; pO.length < XO;) pO.push(VO.empty);
              pO[XO] = VO.of(bK.slice(1)), KO.push(bK[0], pO[XO].length)
            }
          }
        }
        return new iK(KO, pO)
      }
      static createSet(OO, KO) {
        return new iK(OO, KO)
      }
    }

    function rK(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      if (0 == KO && pO <= 0) return;
      let bK = OO.length - 2;
      bK >= 0 && pO <= 0 && pO == OO[bK + 1] ? OO[bK] += KO : bK >= 0 && 0 == KO && 0 == OO[bK] ? OO[bK + 1] += pO : XO ? (OO[bK] += KO, OO[bK + 1] += pO) : OO.push(KO, pO)
    }

    function PO(OO, KO, pO) {
      if (0 == pO.length) return;
      let XO = KO.length - 2 >> 1;
      if (XO < OO.length) OO[OO.length - 1] = OO[OO.length - 1].append(pO);
      else {
        for (; OO.length < XO;) OO.push(VO.empty);
        OO.push(pO)
      }
    }

    function mK(OO, KO, pO) {
      let XO = OO.inserted;
      for (let bK = 0, eO = 0, lO = 0; lO < OO.sections.length;) {
        let vK = OO.sections[lO++],
          CO = OO.sections[lO++];
        if (CO < 0) bK += vK, eO += vK;
        else {
          let hO = bK,
            DO = eO,
            MO = VO.empty;
          for (; hO += vK, DO += CO, CO && XO && (MO = MO.append(XO[lO - 2 >> 1])), !(pO || lO == OO.sections.length || OO.sections[lO + 1] < 0);) vK = OO.sections[lO++], CO = OO.sections[lO++];
          KO(bK, hO, eO, DO, MO), bK = hO, eO = DO
        }
      }
    }

    function sO(OO, KO, pO) {
      let XO = [],
        bK = arguments.length > 3 && void 0 !== arguments[3] && arguments[3] ? [] : null,
        eO = new RO(OO),
        lO = new RO(KO),
        vK = 0;
      for (let CO = -1;;) {
        if (++vK > 2e6) throw new Error("BLOXD CODEMIRROR: mapSet exceeded max iterations - likely malformed ChangeSet");
        if (eO.done && lO.len || lO.done && eO.len) throw new Error("Mismatched change set lengths");
        if (-1 == eO.ins && -1 == lO.ins) {
          let OO = Math.min(eO.len, lO.len);
          rK(XO, OO, -1), eO.forward(OO), lO.forward(OO)
        } else if (lO.ins >= 0 && (eO.ins < 0 || CO == eO.i || 0 == eO.off && (lO.len < eO.len || lO.len == eO.len && !pO))) {
          let OO = lO.len;
          for (rK(XO, lO.ins, -1); OO;) {
            if (++vK > 2e6) throw new Error("BLOXD CODEMIRROR: mapSet exceeded max iterations - inner while-b");
            let KO = Math.min(eO.len, OO);
            eO.ins >= 0 && CO < eO.i && eO.len <= KO && (rK(XO, 0, eO.ins), bK && PO(bK, XO, eO.text), CO = eO.i), eO.forward(KO), OO -= KO
          }
          lO.next()
        } else {
          if (!(eO.ins >= 0)) {
            if (eO.done && lO.done) return bK ? iK.createSet(XO, bK) : wO.create(XO);
            throw new Error("Mismatched change set lengths")
          } {
            let OO = 0,
              KO = eO.len;
            for (; KO;) {
              if (++vK > 2e6) throw new Error("BLOXD CODEMIRROR: mapSet exceeded max iterations - inner while-a");
              if (-1 == lO.ins) {
                let pO = Math.min(KO, lO.len);
                OO += pO, KO -= pO, lO.forward(pO)
              } else {
                if (!(0 == lO.ins && lO.len < KO)) break;
                KO -= lO.len, lO.next()
              }
            }
            rK(XO, OO, CO < eO.i ? eO.ins : 0), bK && CO < eO.i && PO(bK, XO, eO.text), CO = eO.i, eO.forward(eO.len - KO)
          }
        }
      }
    }

    function HO(OO, KO) {
      let pO = [],
        XO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2] ? [] : null,
        bK = new RO(OO),
        eO = new RO(KO),
        lO = 0;
      for (let vK = !1;;) {
        if (++lO > 2e6) throw new Error("BLOXD CODEMIRROR: composeSets exceeded max iterations - likely malformed ChangeSet");
        if (bK.done && eO.done) return XO ? iK.createSet(pO, XO) : wO.create(pO);
        if (0 == bK.ins) rK(pO, bK.len, 0, vK), bK.next();
        else if (0 != eO.len || eO.done) {
          if (bK.done || eO.done) throw new Error("Mismatched change set lengths");
          {
            let OO = Math.min(bK.len2, eO.len),
              KO = pO.length;
            if (-1 == bK.ins) {
              let KO = -1 == eO.ins ? -1 : eO.off ? 0 : eO.ins;
              rK(pO, OO, KO, vK), XO && KO && PO(XO, pO, eO.text)
            } else - 1 == eO.ins ? (rK(pO, bK.off ? 0 : bK.len, OO, vK), XO && PO(XO, pO, bK.textBit(OO))) : (rK(pO, bK.off ? 0 : bK.len, eO.off ? 0 : eO.ins, vK), XO && !eO.off && PO(XO, pO, eO.text));
            vK = (bK.ins > OO || eO.ins >= 0 && eO.len > OO) && (vK || pO.length > KO), bK.forward2(OO), eO.forward(OO)
          }
        } else rK(pO, 0, eO.ins, vK), XO && PO(XO, pO, eO.text), eO.next()
      }
    }
    class RO {
      constructor(OO) {
        this.set = OO, this.i = 0, this.next()
      }
      next() {
        let {
          sections: OO
        } = this.set;
        this.i < OO.length ? (this.len = OO[this.i++], this.ins = OO[this.i++]) : (this.len = 0, this.ins = -2), this.off = 0
      }
      get done() {
        return -2 == this.ins
      }
      get len2() {
        return this.ins < 0 ? this.len : this.ins
      }
      get text() {
        let {
          inserted: OO
        } = this.set, KO = this.i - 2 >> 1;
        return KO >= OO.length ? VO.empty : OO[KO]
      }
      textBit(OO) {
        let {
          inserted: KO
        } = this.set, pO = this.i - 2 >> 1;
        return pO >= KO.length && !OO ? VO.empty : KO[pO].slice(this.off, null == OO ? void 0 : this.off + OO)
      }
      forward(OO) {
        OO == this.len ? this.next() : (this.len -= OO, this.off += OO)
      }
      forward2(OO) {
        -1 == this.ins ? this.forward(OO) : OO == this.ins ? this.next() : (this.ins -= OO, this.off += OO)
      }
    }
    class SO {
      constructor(OO, KO, pO) {
        this.from = OO, this.to = KO, this.flags = pO
      }
      get anchor() {
        return 32 & this.flags ? this.to : this.from
      }
      get head() {
        return 32 & this.flags ? this.from : this.to
      }
      get empty() {
        return this.from == this.to
      }
      get assoc() {
        return 8 & this.flags ? -1 : 16 & this.flags ? 1 : 0
      }
      get bidiLevel() {
        let OO = 7 & this.flags;
        return 7 == OO ? null : OO
      }
      get goalColumn() {
        let OO = this.flags >> 6;
        return 16777215 == OO ? void 0 : OO
      }
      map(OO) {
        let KO, pO, XO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1;
        return this.empty ? KO = pO = OO.mapPos(this.from, XO) : (KO = OO.mapPos(this.from, 1), pO = OO.mapPos(this.to, -1)), KO == this.from && pO == this.to ? this : new SO(KO, pO, this.flags)
      }
      extend(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        if (OO <= this.anchor && KO >= this.anchor) return JO.range(OO, KO, void 0, void 0, pO);
        let XO = Math.abs(OO - this.anchor) > Math.abs(KO - this.anchor) ? OO : KO;
        return JO.range(this.anchor, XO, void 0, void 0, pO)
      }
      eq(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return this.anchor == OO.anchor && this.head == OO.head && this.goalColumn == OO.goalColumn && (!KO || !this.empty || this.assoc == OO.assoc)
      }
      toJSON() {
        return {
          anchor: this.anchor,
          head: this.head
        }
      }
      static fromJSON(OO) {
        if (!OO || "number" != typeof OO.anchor || "number" != typeof OO.head) throw new RangeError("Invalid JSON representation for SelectionRange");
        return JO.range(OO.anchor, OO.head)
      }
      static create(OO, KO, pO) {
        return new SO(OO, KO, pO)
      }
    }
    class JO {
      constructor(OO, KO) {
        this.Xl = OO, this.mainIndex = KO
      }
      map(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1;
        return OO.empty ? this : JO.create(this.Xl.map((pO => pO.map(OO, KO))), this.mainIndex)
      }
      eq(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (this.Xl.length != OO.Xl.length || this.mainIndex != OO.mainIndex) return !1;
        for (let pO = 0; pO < this.Xl.length; pO++)
          if (!this.Xl[pO].eq(OO.Xl[pO], KO)) return !1;
        return !0
      }
      get main() {
        return this.Xl[this.mainIndex]
      }
      asSingle() {
        return 1 == this.Xl.length ? this : new JO([this.main], 0)
      }
      addRange(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        return JO.create([OO].concat(this.Xl), KO ? 0 : this.mainIndex + 1)
      }
      replaceRange(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.mainIndex,
          pO = this.Xl.slice();
        return pO[KO] = OO, JO.create(pO, this.mainIndex)
      }
      toJSON() {
        return {
          Xl: this.Xl.map((OO => OO.toJSON())),
          main: this.mainIndex
        }
      }
      static fromJSON(OO) {
        if (!OO || !Array.isArray(OO.Xl) || "number" != typeof OO.main || OO.main >= OO.Xl.length) throw new RangeError("Invalid JSON representation for EditorSelection");
        return new JO(OO.Xl.map((OO => SO.fromJSON(OO))), OO.main)
      }
      static single(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO;
        return new JO([JO.range(OO, KO)], 0)
      }
      static create(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        if (0 == OO.length) throw new RangeError("A selection needs at least one range");
        for (let pO = 0, XO = 0; XO < OO.length; XO++) {
          let bK = OO[XO];
          if (bK.empty ? bK.from <= pO : bK.from < pO) return JO.normalized(OO.slice(), KO);
          pO = bK.to
        }
        return new JO(OO, KO)
      }
      static cursor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        return SO.create(OO, OO, (0 == KO ? 0 : KO < 0 ? 8 : 16) | (null == pO ? 7 : Math.min(6, pO)) | (null !== XO && void 0 !== XO ? XO : 16777215) << 6)
      }
      static range(OO, KO, pO, XO, bK) {
        let eO = (null !== pO && void 0 !== pO ? pO : 16777215) << 6 | (null == XO ? 7 : Math.min(6, XO));
        return bK || OO == KO || (bK = KO < OO ? 1 : -1), KO < OO ? SO.create(KO, OO, 48 | eO) : SO.create(OO, KO, (bK ? bK < 0 ? 8 : 16 : 0) | eO)
      }
      static normalized(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = OO[KO];
        OO.sort(((OO, KO) => OO.from - KO.from)), KO = OO.indexOf(pO);
        for (let XO = 1; XO < OO.length; XO++) {
          let pO = OO[XO],
            bK = OO[XO - 1];
          if (pO.empty ? pO.from <= bK.to : pO.from < bK.to) {
            let eO = bK.from,
              lO = Math.max(pO.to, bK.to);
            XO <= KO && KO--, OO.splice(--XO, 2, pO.anchor > pO.head ? JO.range(lO, eO) : JO.range(eO, lO))
          }
        }
        return new JO(OO, KO)
      }
    }

    function cK(OO, KO) {
      for (let pO of OO.Xl)
        if (pO.to > KO) throw new RangeError("Selection points outside of document")
    }
    let BO = 0;
    class ZO {
      constructor(OO, KO, pO, XO, bK) {
        this.combine = OO, this.compareInput = KO, this.compare = pO, this.isStatic = XO, this.id = BO++, this.default = OO([]), this.extensions = "function" == typeof bK ? bK(this) : bK
      }
      get reader() {
        return this
      }
      static define() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return new ZO(OO.combine || (OO => OO), OO.compareInput || ((OO, KO) => OO === KO), OO.compare || (OO.combine ? (OO, KO) => OO === KO : GO), !!OO.static, OO.enables)
      }
      of(OO) {
        return new qK([], this, 0, OO)
      }
      compute(OO, KO) {
        if (this.isStatic) throw new Error("Can't compute a static facet");
        return new qK(OO, this, 1, KO)
      }
      computeN(OO, KO) {
        if (this.isStatic) throw new Error("Can't compute a static facet");
        return new qK(OO, this, 2, KO)
      }
      from(OO, KO) {
        return KO || (KO = OO => OO), this.compute([OO], (pO => KO(pO.field(OO))))
      }
    }

    function GO(OO, KO) {
      return OO == KO || OO.length == KO.length && OO.every(((OO, pO) => OO === KO[pO]))
    }
    class qK {
      constructor(OO, KO, pO, XO) {
        this.dependencies = OO, this.facet = KO, this.type = pO, this.value = XO, this.id = BO++
      }
      dynamicSlot(OO) {
        var KO;
        let pO = this.value,
          XO = this.facet.compareInput,
          bK = this.id,
          eO = OO[bK] >> 1,
          lO = 2 == this.type,
          vK = !1,
          CO = !1,
          hO = [];
        for (let DO of this.dependencies) "doc" == DO ? vK = !0 : "selection" == DO ? CO = !0 : 0 == (1 & (null !== (KO = OO[DO.id]) && void 0 !== KO ? KO : 1)) && hO.push(OO[DO.id]);
        return {
          create: OO => (OO.values[eO] = pO(OO), 1),
          update(OO, KO) {
            if (vK && KO.docChanged || CO && (KO.docChanged || KO.selection) || nO(OO, hO)) {
              let KO = pO(OO);
              if (lO ? !xK(KO, OO.values[eO], XO) : !XO(KO, OO.values[eO])) return OO.values[eO] = KO, 1
            }
            return 0
          },
          reconfigure: (OO, KO) => {
            let vK, CO = KO.config.address[bK];
            if (null != CO) {
              let bK = DK(KO, CO);
              if (this.dependencies.every((pO => pO instanceof ZO ? KO.facet(pO) === OO.facet(pO) : !(pO instanceof kK) || KO.field(pO, !1) == OO.field(pO, !1))) || (lO ? xK(vK = pO(OO), bK, XO) : XO(vK = pO(OO), bK))) return OO.values[eO] = bK, 0
            } else vK = pO(OO);
            return OO.values[eO] = vK, 1
          }
        }
      }
    }

    function xK(OO, KO, pO) {
      if (OO.length != KO.length) return !1;
      for (let XO = 0; XO < OO.length; XO++)
        if (!pO(OO[XO], KO[XO])) return !1;
      return !0
    }

    function nO(OO, KO) {
      let pO = !1;
      for (let XO of KO) 1 & hK(OO, XO) && (pO = !0);
      return pO
    }

    function WO(OO, KO, pO) {
      let XO = pO.map((KO => OO[KO.id])),
        bK = pO.map((OO => OO.type)),
        eO = XO.filter((OO => !(1 & OO))),
        lO = OO[KO.id] >> 1;

      function vK(OO) {
        let pO = [];
        for (let KO = 0; KO < XO.length; KO++) {
          let eO = DK(OO, XO[KO]);
          if (2 == bK[KO])
            for (let OO of eO) pO.push(OO);
          else pO.push(eO)
        }
        return KO.combine(pO)
      }
      return {
        create(OO) {
          for (let KO of XO) hK(OO, KO);
          return OO.values[lO] = vK(OO), 1
        },
        update(OO, pO) {
          if (!nO(OO, eO)) return 0;
          let XO = vK(OO);
          return KO.compare(XO, OO.values[lO]) ? 0 : (OO.values[lO] = XO, 1)
        },
        reconfigure(OO, bK) {
          let eO = nO(OO, XO),
            CO = bK.config.facets[KO.id],
            hO = bK.facet(KO);
          if (CO && !eO && GO(pO, CO)) return OO.values[lO] = hO, 0;
          let DO = vK(OO);
          return KO.compare(DO, hO) ? (OO.values[lO] = hO, 0) : (OO.values[lO] = DO, 1)
        }
      }
    }
    const tK = ZO.define({
      static: !0
    });
    class kK {
      constructor(OO, KO, pO, XO, bK) {
        this.id = OO, this.createF = KO, this.updateF = pO, this.compareF = XO, this.spec = bK, this.provides = void 0
      }
      static define(OO) {
        let KO = new kK(BO++, OO.create, OO.update, OO.compare || ((OO, KO) => OO === KO), OO);
        return OO.provide && (KO.provides = OO.provide(KO)), KO
      }
      create(OO) {
        let KO = OO.facet(tK).find((OO => OO.field == this));
        return ((null === KO || void 0 === KO ? void 0 : KO.create) || this.createF)(OO)
      }
      slot(OO) {
        let KO = OO[this.id] >> 1;
        return {
          create: OO => (OO.values[KO] = this.create(OO), 1),
          update: (OO, pO) => {
            let XO = OO.values[KO],
              bK = this.updateF(XO, pO);
            return this.compareF(XO, bK) ? 0 : (OO.values[KO] = bK, 1)
          },
          reconfigure: (OO, pO) => {
            let XO, bK = OO.facet(tK),
              eO = pO.facet(tK);
            return (XO = bK.find((OO => OO.field == this))) && XO != eO.find((OO => OO.field == this)) ? (OO.values[KO] = XO.create(OO), 1) : null != pO.config.address[this.id] ? (OO.values[KO] = pO.field(this), 0) : (OO.values[KO] = this.create(OO), 1)
          }
        }
      }
      init(OO) {
        return [this, tK.of({
          field: this,
          create: OO
        })]
      }
      get extension() {
        return this
      }
    }
    const UO = 4,
      OK = 3,
      KK = 2,
      pK = 1;

    function XK(OO) {
      return KO => new eK(KO, OO)
    }
    const bp = {
      highest: XK(0),
      high: XK(pK),
      default: XK(KK),
      low: XK(OK),
      lowest: XK(UO)
    };
    class eK {
      constructor(OO, KO) {
        this.inner = OO, this.prec = KO
      }
    }
    class lK {
      of(OO) {
        return new vp(this, OO)
      }
      reconfigure(OO) {
        return lK.reconfigure.of({
          compartment: this,
          extension: OO
        })
      }
      get(OO) {
        return OO.config.compartments.get(this)
      }
    }
    class vp {
      constructor(OO, KO) {
        this.compartment = OO, this.inner = KO
      }
    }
    class CK {
      constructor(OO, KO, pO, XO, bK, eO) {
        for (this.base = OO, this.compartments = KO, this.dynamicSlots = pO, this.address = XO, this.staticValues = bK, this.facets = eO, this.statusTemplate = []; this.statusTemplate.length < pO.length;) this.statusTemplate.push(0)
      }
      staticFacet(OO) {
        let KO = this.address[OO.id];
        return null == KO ? OO.default : this.staticValues[KO >> 1]
      }
      static resolve(OO, KO, pO) {
        let XO = [],
          bK = Object.create(null),
          eO = new Map;
        for (let MO of function(OO, KO, pO) {
            let XO = [
                [],
                [],
                [],
                [],
                []
              ],
              bK = new Map;

            function eO(OO, lO) {
              let vK = bK.get(OO);
              if (null != vK) {
                if (vK <= lO) return;
                let KO = XO[vK].indexOf(OO);
                KO > -1 && XO[vK].splice(KO, 1), OO instanceof vp && pO.delete(OO.compartment)
              }
              if (bK.set(OO, lO), Array.isArray(OO))
                for (let KO of OO) eO(KO, lO);
              else if (OO instanceof vp) {
                if (pO.has(OO.compartment)) throw new RangeError("Duplicate use of compartment in extensions");
                let XO = KO.get(OO.compartment) || OO.inner;
                pO.set(OO.compartment, XO), eO(XO, lO)
              } else if (OO instanceof eK) eO(OO.inner, OO.prec);
              else if (OO instanceof kK) XO[lO].push(OO), OO.provides && eO(OO.provides, lO);
              else if (OO instanceof qK) XO[lO].push(OO), OO.facet.extensions && eO(OO.facet.extensions, KK);
              else {
                let KO = OO.extension;
                if (!KO) throw new Error(`Unrecognized extension value in extension set (${OO}). This sometimes happens because multiple instances of @codemirror/state are loaded, breaking instanceof checks.`);
                eO(KO, lO)
              }
            }
            return eO(OO, KK), XO.reduce(((OO, KO) => OO.concat(KO)))
          }(OO, KO, eO)) MO instanceof kK ? XO.push(MO) : (bK[MO.facet.id] || (bK[MO.facet.id] = [])).push(MO);
        let lO = Object.create(null),
          vK = [],
          CO = [];
        for (let MO of XO) lO[MO.id] = CO.length << 1, CO.push((OO => MO.slot(OO)));
        let hO = null === pO || void 0 === pO ? void 0 : pO.config.facets;
        for (let MO in bK) {
          let OO = bK[MO],
            KO = OO[0].facet,
            XO = hO && hO[MO] || [];
          if (OO.every((OO => 0 == OO.type)))
            if (lO[KO.id] = vK.length << 1 | 1, GO(XO, OO)) vK.push(pO.facet(KO));
            else {
              let XO = KO.combine(OO.map((OO => OO.value)));
              vK.push(pO && KO.compare(XO, pO.facet(KO)) ? pO.facet(KO) : XO)
            }
          else {
            for (let KO of OO) 0 == KO.type ? (lO[KO.id] = vK.length << 1 | 1, vK.push(KO.value)) : (lO[KO.id] = CO.length << 1, CO.push((OO => KO.dynamicSlot(OO))));
            lO[KO.id] = CO.length << 1, CO.push((pO => WO(pO, KO, OO)))
          }
        }
        let DO = CO.map((OO => OO(lO)));
        return new CK(OO, eO, DO, lO, vK, bK)
      }
    }

    function hK(OO, KO) {
      if (1 & KO) return 2;
      let pO = KO >> 1,
        XO = OO.status[pO];
      if (4 == XO) throw new Error("Cyclic dependency between fields and/or facets");
      if (2 & XO) return XO;
      OO.status[pO] = 4;
      let bK = OO.computeSlot(OO, OO.config.dynamicSlots[pO]);
      return OO.status[pO] = 2 | bK
    }

    function DK(OO, KO) {
      return 1 & KO ? OO.config.staticValues[KO >> 1] : OO.values[KO >> 1]
    }
    const MK = ZO.define(),
      ap = ZO.define({
        combine: OO => OO.some((OO => OO)),
        static: !0
      }),
      oK = ZO.define({
        combine: OO => OO.length ? OO[0] : void 0,
        static: !0
      }),
      FK = ZO.define(),
      VK = ZO.define(),
      LK = ZO.define(),
      QK = ZO.define({
        combine: OO => !!OO.length && OO[0]
      });
    class zp {
      constructor(OO, KO) {
        this.type = OO, this.value = KO
      }
      static define() {
        return new AK
      }
    }
    class AK {
      of(OO) {
        return new zp(this, OO)
      }
    }
    class fK {
      constructor(OO) {
        this.map = OO
      }
      of(OO) {
        return new dK(this, OO)
      }
    }
    class dK {
      constructor(OO, KO) {
        this.type = OO, this.value = KO
      }
      map(OO) {
        let KO = this.type.map(this.value, OO);
        return void 0 === KO ? void 0 : KO == this.value ? this : new dK(this.type, KO)
      }
      is(OO) {
        return this.type == OO
      }
      static define() {
        return new fK((arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).map || (OO => OO))
      }
      static mapEffects(OO, KO) {
        if (!OO.length) return OO;
        let pO = [];
        for (let XO of OO) {
          let OO = XO.map(KO);
          OO && pO.push(OO)
        }
        return pO
      }
    }
    dK.reconfigure = dK.define(), dK.appendConfig = dK.define();
    class TK {
      constructor(OO, KO, pO, XO, bK, eO) {
        this.startState = OO, this.changes = KO, this.selection = pO, this.effects = XO, this.annotations = bK, this.scrollIntoView = eO, this._doc = null, this._state = null, pO && cK(pO, KO.newLength), bK.some((OO => OO.type == TK.time)) || (this.annotations = bK.concat(TK.time.of(Date.now())))
      }
      static create(OO, KO, pO, XO, bK, eO) {
        return new TK(OO, KO, pO, XO, bK, eO)
      }
      get newDoc() {
        return this._doc || (this._doc = this.changes.apply(this.startState.doc))
      }
      get newSelection() {
        return this.selection || this.startState.selection.map(this.changes)
      }
      get state() {
        return this._state || this.startState.applyTransaction(this), this._state
      }
      annotation(OO) {
        for (let KO of this.annotations)
          if (KO.type == OO) return KO.value
      }
      get docChanged() {
        return !this.changes.empty
      }
      get reconfigured() {
        return this.startState.config != this.state.config
      }
      isUserEvent(OO) {
        let KO = this.annotation(TK.userEvent);
        return !(!KO || !(KO == OO || KO.length > OO.length && KO.slice(0, OO.length) == OO && "." == KO[OO.length]))
      }
    }

    function NK(OO, KO) {
      let pO = [];
      for (let XO = 0, bK = 0;;) {
        let eO, lO;
        if (XO < OO.length && (bK == KO.length || KO[bK] >= OO[XO])) eO = OO[XO++], lO = OO[XO++];
        else {
          if (!(bK < KO.length)) return pO;
          eO = KO[bK++], lO = KO[bK++]
        }!pO.length || pO[pO.length - 1] < eO ? pO.push(eO, lO) : pO[pO.length - 1] < lO && (pO[pO.length - 1] = lO)
      }
    }

    function IK(OO, KO, pO) {
      var XO;
      let bK, eO, lO;
      return pO ? (bK = KO.changes, eO = iK.empty(KO.changes.length), lO = OO.changes.compose(KO.changes)) : (bK = KO.changes.map(OO.changes), eO = OO.changes.mapDesc(KO.changes, !0), lO = OO.changes.compose(bK)), {
        changes: lO,
        selection: KO.selection ? KO.selection.map(eO) : null === (XO = OO.selection) || void 0 === XO ? void 0 : XO.map(bK),
        effects: dK.mapEffects(OO.effects, bK).concat(dK.mapEffects(KO.effects, eO)),
        annotations: OO.annotations.length ? OO.annotations.concat(KO.annotations) : KO.annotations,
        scrollIntoView: OO.scrollIntoView || KO.scrollIntoView
      }
    }

    function yp(OO, KO, pO) {
      let XO = KO.selection,
        bK = EK(KO.annotations);
      return KO.userEvent && (bK = bK.concat(TK.userEvent.of(KO.userEvent))), {
        changes: KO.changes instanceof iK ? KO.changes : iK.of(KO.changes || [], pO, OO.facet(oK)),
        selection: XO && (XO instanceof JO ? XO : JO.single(XO.anchor, XO.head)),
        effects: EK(KO.effects),
        annotations: bK,
        scrollIntoView: !!KO.scrollIntoView
      }
    }

    function gp(OO, KO, pO) {
      let XO = yp(OO, KO.length ? KO[0] : {}, OO.doc.length);
      KO.length && !1 === KO[0].filter && (pO = !1);
      for (let eO = 1; eO < KO.length; eO++) {
        !1 === KO[eO].filter && (pO = !1);
        let bK = !!KO[eO].sequential;
        XO = IK(XO, yp(OO, KO[eO], bK ? XO.changes.newLength : OO.doc.length), bK)
      }
      let bK = TK.create(OO, XO.changes, XO.selection, XO.effects, XO.annotations, XO.scrollIntoView);
      return function(OO) {
        let KO = OO.startState,
          pO = KO.facet(LK),
          XO = OO;
        for (let bK = pO.length - 1; bK >= 0; bK--) {
          let eO = pO[bK](OO);
          eO && Object.keys(eO).length && (XO = IK(XO, yp(KO, eO, OO.changes.newLength), !0))
        }
        return XO == OO ? OO : TK.create(KO, OO.changes, OO.selection, XO.effects, XO.annotations, XO.scrollIntoView)
      }(pO ? function(OO) {
        let KO = OO.startState,
          pO = !0;
        for (let bK of KO.facet(FK)) {
          let KO = bK(OO);
          if (!1 === KO) {
            pO = !1;
            break
          }
          Array.isArray(KO) && (pO = !0 === pO ? KO : NK(pO, KO))
        }
        if (!0 !== pO) {
          let XO, bK;
          if (!1 === pO) bK = OO.changes.invertedDesc, XO = iK.empty(KO.doc.length);
          else {
            let KO = OO.changes.filter(pO);
            XO = KO.changes, bK = KO.filtered.mapDesc(KO.changes).invertedDesc
          }
          OO = TK.create(KO, XO, OO.selection && OO.selection.map(bK), dK.mapEffects(OO.effects, bK), OO.annotations, OO.scrollIntoView)
        }
        let XO = KO.facet(VK);
        for (let bK = XO.length - 1; bK >= 0; bK--) {
          let pO = XO[bK](OO);
          OO = pO instanceof TK ? pO : Array.isArray(pO) && 1 == pO.length && pO[0] instanceof TK ? pO[0] : gp(KO, EK(pO), !1)
        }
        return OO
      }(bK) : bK)
    }
    TK.time = zp.define(), TK.userEvent = zp.define(), TK.addToHistory = zp.define(), TK.remote = zp.define();
    const uK = [];

    function EK(OO) {
      return null == OO ? uK : Array.isArray(OO) ? OO : [OO]
    }
    var jp = function(OO) {
      return OO[OO.Word = 0] = "Word", OO[OO.Space = 1] = "Space", OO[OO.Other = 2] = "Other", OO
    }(jp || (jp = {}));
    const YK = /[\u00df\u0587\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/;
    let wK;
    try {
      wK = new RegExp("[\\p{Alphabetic}\\p{Number}_]", "u")
    } catch (pp) {}

    function ip(OO) {
      return KO => {
        if (!/\S/.test(KO)) return jp.Space;
        if (function(OO) {
            if (wK) return wK.test(OO);
            for (let KO = 0; KO < OO.length; KO++) {
              let pO = OO[KO];
              if (/\w/.test(pO) || pO > "\x80" && (pO.toUpperCase() != pO.toLowerCase() || YK.test(pO))) return !0
            }
            return !1
          }(KO)) return jp.Word;
        for (let pO = 0; pO < OO.length; pO++)
          if (KO.indexOf(OO[pO]) > -1) return jp.Word;
        return jp.Other
      }
    }
    class rp {
      constructor(OO, KO, pO, XO, bK, eO) {
        this.config = OO, this.doc = KO, this.selection = pO, this.values = XO, this.status = OO.statusTemplate.slice(), this.computeSlot = bK, eO && (eO._state = this);
        for (let lO = 0; lO < this.config.dynamicSlots.length; lO++) hK(this, lO << 1);
        this.computeSlot = null
      }
      field(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = this.config.address[OO.id];
        if (null != pO) return hK(this, pO), DK(this, pO);
        if (KO) throw new RangeError("Field is not present in this state")
      }
      update() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        return gp(this, KO, !0)
      }
      applyTransaction(OO) {
        let KO, pO = this.config,
          {
            base: XO,
            compartments: bK
          } = pO;
        for (let lO of OO.effects) lO.is(lK.reconfigure) ? (pO && (bK = new Map, pO.compartments.forEach(((OO, KO) => bK.set(KO, OO))), pO = null), bK.set(lO.value.compartment, lO.value.extension)) : lO.is(dK.reconfigure) ? (pO = null, XO = lO.value) : lO.is(dK.appendConfig) && (pO = null, XO = EK(XO).concat(lO.value));
        if (pO) KO = OO.startState.values.slice();
        else {
          pO = CK.resolve(XO, bK, this), KO = new rp(pO, this.doc, this.selection, pO.dynamicSlots.map((() => null)), ((OO, KO) => KO.reconfigure(OO, this)), null).values
        }
        let eO = OO.startState.facet(ap) ? OO.newSelection : OO.newSelection.asSingle();
        new rp(pO, OO.newDoc, eO, KO, ((KO, pO) => pO.update(KO, OO)), OO)
      }
      replaceSelection(OO) {
        return "string" == typeof OO && (OO = this.toText(OO)), this.changeByRange((KO => ({
          changes: {
            from: KO.from,
            to: KO.to,
            insert: OO
          },
          range: JO.cursor(KO.from + OO.length)
        })))
      }
      changeByRange(OO) {
        let KO = this.selection,
          pO = OO(KO.Xl[0]),
          XO = this.changes(pO.changes),
          bK = [pO.range],
          eO = EK(pO.effects);
        for (let lO = 1; lO < KO.Xl.length; lO++) {
          let pO = OO(KO.Xl[lO]),
            vK = this.changes(pO.changes),
            CO = vK.map(XO);
          for (let OO = 0; OO < lO; OO++) bK[OO] = bK[OO].map(CO);
          let hO = XO.mapDesc(vK, !0);
          bK.push(pO.range.map(hO)), XO = XO.compose(CO), eO = dK.mapEffects(eO, CO).concat(dK.mapEffects(EK(pO.effects), hO))
        }
        return {
          changes: XO,
          selection: JO.create(bK, KO.mainIndex),
          effects: eO
        }
      }
      changes() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return OO instanceof iK ? OO : iK.of(OO, this.doc.length, this.facet(rp.lineSeparator))
      }
      toText(OO) {
        return VO.of(OO.split(this.facet(rp.lineSeparator) || jK))
      }
      sliceDoc() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.doc.length;
        return this.doc.sliceString(OO, KO, this.lineBreak)
      }
      facet(OO) {
        let KO = this.config.address[OO.id];
        return null == KO ? OO.default : (hK(this, KO), DK(this, KO))
      }
      toJSON(OO) {
        let KO = {
          doc: this.sliceDoc(),
          selection: this.selection.toJSON()
        };
        if (OO)
          for (let pO in OO) {
            let XO = OO[pO];
            XO instanceof kK && null != this.config.address[XO.id] && (KO[pO] = XO.spec.toJSON(this.field(OO[pO]), this))
          }
        return KO
      }
      static fromJSON(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          pO = arguments.length > 2 ? arguments[2] : void 0;
        if (!OO || "string" != typeof OO.doc) throw new RangeError("Invalid JSON representation for EditorState");
        let XO = [];
        if (pO)
          for (let bK in pO)
            if (Object.prototype.hasOwnProperty.call(OO, bK)) {
              let KO = pO[bK],
                eO = OO[bK];
              XO.push(KO.init((OO => KO.spec.fromJSON(eO, OO))))
            } return rp.create({
          doc: OO.doc,
          selection: JO.fromJSON(OO.selection),
          extensions: KO.extensions ? XO.concat([KO.extensions]) : XO
        })
      }
      static create() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          KO = CK.resolve(OO.extensions || [], new Map),
          pO = OO.doc instanceof VO ? OO.doc : VO.of((OO.doc || "").split(KO.staticFacet(rp.lineSeparator) || jK)),
          XO = OO.selection ? OO.selection instanceof JO ? OO.selection : JO.single(OO.selection.anchor, OO.selection.head) : JO.single(0);
        return cK(XO, pO.length), KO.staticFacet(ap) || (XO = XO.asSingle()), new rp(KO, pO, XO, KO.dynamicSlots.map((() => null)), ((OO, KO) => KO.create(OO)), null)
      }
      get tabSize() {
        return this.facet(rp.tabSize)
      }
      get lineBreak() {
        return this.facet(rp.lineSeparator) || "\n"
      }
      get readOnly() {
        return this.facet(QK)
      }
      phrase(OO) {
        for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
        for (let bK of this.facet(rp.phrases))
          if (Object.prototype.hasOwnProperty.call(bK, OO)) {
            OO = bK[OO];
            break
          } return pO.length && (OO = OO.replace(/\$(\$|\d*)/g, ((OO, KO) => {
          if ("$" == KO) return "$";
          let XO = +(KO || 1);
          return !XO || XO > pO.length ? OO : pO[XO - 1]
        }))), OO
      }
      languageDataAt(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : -1,
          XO = [];
        for (let bK of this.facet(MK))
          for (let eO of bK(this, KO, pO)) Object.prototype.hasOwnProperty.call(eO, OO) && XO.push(eO[OO]);
        return XO
      }
      charCategorizer(OO) {
        let KO = this.languageDataAt("wordChars", OO);
        return ip(KO.length ? KO[0] : "")
      }
      wordAt(OO) {
        let {
          text: KO,
          from: pO,
          length: XO
        } = this.doc.lineAt(OO), bK = this.charCategorizer(OO), eO = OO - pO, lO = OO - pO;
        for (; eO > 0;) {
          let OO = yK(KO, eO, !1);
          if (bK(KO.slice(OO, eO)) != jp.Word) break;
          eO = OO
        }
        for (; lO < XO;) {
          let OO = yK(KO, lO);
          if (bK(KO.slice(lO, OO)) != jp.Word) break;
          lO = OO
        }
        return eO == lO ? null : JO.range(eO + pO, lO + pO)
      }
    }

    function PK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
        XO = {};
      for (let bK of OO)
        for (let OO of Object.keys(bK)) {
          let KO = bK[OO],
            eO = XO[OO];
          if (void 0 === eO) XO[OO] = KO;
          else if (eO === KO || void 0 === KO);
          else {
            if (!Object.hasOwnProperty.call(pO, OO)) throw new Error("Config merge conflict for field " + OO);
            XO[OO] = pO[OO](eO, KO)
          }
        }
      for (let bK in KO) void 0 === XO[bK] && (XO[bK] = KO[bK]);
      return XO
    }
    rp.allowMultipleSelections = ap, rp.tabSize = ZO.define({
      combine: OO => OO.length ? OO[0] : 4
    }), rp.lineSeparator = oK, rp.readOnly = QK, rp.phrases = ZO.define({
      compare(OO, KO) {
        let pO = Object.keys(OO),
          XO = Object.keys(KO);
        return pO.length == XO.length && pO.every((pO => OO[pO] == KO[pO]))
      }
    }), rp.languageData = MK, rp.changeFilter = FK, rp.transactionFilter = VK, rp.transactionExtender = LK, lK.reconfigure = dK.define();
    class mp {
      eq(OO) {
        return this == OO
      }
      range(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : OO;
        return HK.create(OO, KO, this)
      }
    }

    function sK(OO, KO) {
      return OO == KO || OO.constructor == KO.constructor && OO.eq(KO)
    }
    mp.prototype.startSide = mp.prototype.endSide = 0, mp.prototype.point = !1, mp.prototype.mapMode = YO.TrackDel;
    class HK {
      constructor(OO, KO, pO) {
        this.from = OO, this.to = KO, this.value = pO
      }
      static create(OO, KO, pO) {
        return new HK(OO, KO, pO)
      }
    }

    function RK(OO, KO) {
      return OO.from - KO.from || OO.value.startSide - KO.value.startSide
    }
    class SK {
      constructor(OO, KO, pO, XO) {
        this.from = OO, this.to = KO, this.value = pO, this.tDO = XO
      }
      get length() {
        return this.to[this.to.length - 1]
      }
      findIndex(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
          bK = pO ? this.to : this.from;
        for (let eO = XO, lO = bK.length;;) {
          if (eO == lO) return eO;
          let XO = eO + lO >> 1,
            vK = bK[XO] - OO || (pO ? this.value[XO].endSide : this.value[XO].startSide) - KO;
          if (XO == eO) return vK >= 0 ? eO : lO;
          vK >= 0 ? lO = XO : eO = XO + 1
        }
      }
      between(OO, KO, pO, XO) {
        for (let bK = this.findIndex(KO, -1e9, !0), eO = this.findIndex(pO, 1e9, !1, bK); bK < eO; bK++)
          if (!1 === XO(this.from[bK] + OO, this.to[bK] + OO, this.value[bK])) return !1
      }
      map(OO, KO) {
        let pO = [],
          XO = [],
          bK = [],
          eO = -1,
          lO = -1;
        for (let vK = 0; vK < this.value.length; vK++) {
          let CO, hO, DO = this.value[vK],
            MO = this.from[vK] + OO,
            aK = this.to[vK] + OO;
          if (MO == aK) {
            let OO = KO.mapPos(MO, DO.startSide, DO.mapMode);
            if (null == OO) continue;
            if (CO = hO = OO, DO.startSide != DO.endSide && (hO = KO.mapPos(MO, DO.endSide), hO < CO)) continue
          } else if (CO = KO.mapPos(MO, DO.startSide), hO = KO.mapPos(aK, DO.endSide), CO > hO || CO == hO && DO.startSide > 0 && DO.endSide <= 0) continue;
          (hO - CO || DO.endSide - DO.startSide) < 0 || (eO < 0 && (eO = CO), DO.point && (lO = Math.max(lO, hO - CO)), pO.push(DO), XO.push(CO - eO), bK.push(hO - eO))
        }
        return {
          mapped: pO.length ? new SK(XO, bK, pO, lO) : null,
          pos: eO
        }
      }
    }
    class JK {
      constructor(OO, KO, pO, XO) {
        this.chunkPos = OO, this.chunk = KO, this.nextLayer = pO, this.tDO = XO
      }
      static create(OO, KO, pO, XO) {
        return new JK(OO, KO, pO, XO)
      }
      get length() {
        let OO = this.chunk.length - 1;
        return OO < 0 ? 0 : Math.max(this.chunkEnd(OO), this.nextLayer.length)
      }
      get size() {
        if (this.fX) return 0;
        let OO = this.nextLayer.size;
        for (let KO of this.chunk) OO += KO.value.length;
        return OO
      }
      chunkEnd(OO) {
        return this.chunkPos[OO] + this.chunk[OO].length
      }
      update(OO) {
        let {
          add: KO = [],
          sort: pO = !1,
          filterFrom: XO = 0,
          filterTo: bK = this.length
        } = OO, eO = OO.filter;
        if (0 == KO.length && !eO) return this;
        if (pO && (KO = KO.slice().sort(RK)), this.fX) return KO.length ? JK.of(KO) : this;
        let lO = new ZK(this, null, -1).goto(0),
          vK = 0,
          CO = [],
          hO = new cp;
        for (; lO.value || vK < KO.length;)
          if (vK < KO.length && (lO.from - KO[vK].from || lO.startSide - KO[vK].value.startSide) >= 0) {
            let OO = KO[vK++];
            hO.addInner(OO.from, OO.to, OO.value) || CO.push(OO)
          } else 1 == lO.rangeIndex && lO.chunkIndex < this.chunk.length && (vK == KO.length || this.chunkEnd(lO.chunkIndex) < KO[vK].from) && (!eO || XO > this.chunkEnd(lO.chunkIndex) || bK < this.chunkPos[lO.chunkIndex]) && hO.addChunk(this.chunkPos[lO.chunkIndex], this.chunk[lO.chunkIndex]) ? lO.nextChunk() : ((!eO || XO > lO.to || bK < lO.from || eO(lO.from, lO.to, lO.value)) && (hO.addInner(lO.from, lO.to, lO.value) || CO.push(HK.create(lO.from, lO.to, lO.value))), lO.next());
        return hO.finishInner(this.nextLayer.fX && !CO.length ? JK.empty : this.nextLayer.update({
          add: CO,
          filter: eO,
          filterFrom: XO,
          filterTo: bK
        }))
      }
      map(OO) {
        if (OO.empty || this.fX) return this;
        let KO = [],
          pO = [],
          XO = -1;
        for (let eO = 0; eO < this.chunk.length; eO++) {
          let bK = this.chunkPos[eO],
            lO = this.chunk[eO],
            vK = OO.touchesRange(bK, bK + lO.length);
          if (!1 === vK) XO = Math.max(XO, lO.tDO), KO.push(lO), pO.push(OO.mapPos(bK));
          else if (!0 === vK) {
            let {
              mapped: eO,
              pos: vK
            } = lO.map(bK, OO);
            eO && (XO = Math.max(XO, eO.tDO), KO.push(eO), pO.push(vK))
          }
        }
        let bK = this.nextLayer.map(OO);
        return 0 == KO.length ? bK : new JK(pO, KO, bK || JK.empty, XO)
      }
      between(OO, KO, pO) {
        if (!this.fX) {
          for (let XO = 0; XO < this.chunk.length; XO++) {
            let bK = this.chunkPos[XO],
              eO = this.chunk[XO];
            if (KO >= bK && OO <= bK + eO.length && !1 === eO.between(bK, OO - bK, KO - bK, pO)) return
          }
          this.nextLayer.between(OO, KO, pO)
        }
      }
      iter() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return GK.from([this]).goto(OO)
      }
      get fX() {
        return this.nextLayer == this
      }
      static iter(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return GK.from(OO).goto(KO)
      }
      static compare(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : -1,
          eO = OO.filter((OO => OO.tDO > 0 || !OO.fX && OO.tDO >= bK)),
          lO = KO.filter((OO => OO.tDO > 0 || !OO.fX && OO.tDO >= bK)),
          vK = BK(eO, lO, pO),
          CO = new xp(eO, vK, bK),
          hO = new xp(lO, vK, bK);
        pO.iterGaps(((OO, KO, pO) => nK(CO, OO, hO, KO, pO, XO))), pO.empty && 0 == pO.length && nK(CO, 0, hO, 0, 0, XO)
      }
      static eq(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        null == XO && (XO = 999999999);
        let bK = OO.filter((OO => !OO.fX && KO.indexOf(OO) < 0)),
          eO = KO.filter((KO => !KO.fX && OO.indexOf(KO) < 0));
        if (bK.length != eO.length) return !1;
        if (!bK.length) return !0;
        let lO = BK(bK, eO),
          vK = new xp(bK, lO, 0).goto(pO),
          CO = new xp(eO, lO, 0).goto(pO);
        for (;;) {
          if (vK.to != CO.to || !WK(vK.active, CO.active) || vK.point && (!CO.point || !sK(vK.point, CO.point))) return !1;
          if (vK.to > XO) return !0;
          vK.next(), CO.next()
        }
      }
      static spans(OO, KO, pO, XO) {
        let bK = new xp(OO, null, arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : -1).goto(KO),
          eO = KO,
          lO = bK.openStart;
        for (;;) {
          let OO = Math.min(bK.to, pO);
          if (bK.point) {
            let pO = bK.activeForPoint(bK.to),
              vK = bK.pointFrom < KO ? pO.length + 1 : bK.point.startSide < 0 ? pO.length : Math.min(pO.length, lO);
            XO.point(eO, OO, bK.point, pO, vK, bK.pointRank), lO = Math.min(bK.openEnd(OO), pO.length)
          } else OO > eO && (XO.span(eO, OO, bK.active, lO), lO = bK.openEnd(OO));
          if (bK.to > pO) return lO + (bK.point && bK.to > pO ? 1 : 0);
          eO = bK.to, bK.next()
        }
      }
      static of (OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = new cp;
        for (let XO of OO instanceof HK ? [OO] : KO ? function(OO) {
            if (OO.length > 1)
              for (let KO = OO[0], pO = 1; pO < OO.length; pO++) {
                let XO = OO[pO];
                if (RK(KO, XO) > 0) return OO.slice().sort(RK);
                KO = XO
              }
            return OO
          }(OO) : OO) pO.add(XO.from, XO.to, XO.value);
        return pO.finish()
      }
      static join(OO) {
        if (!OO.length) return JK.empty;
        let KO = OO[OO.length - 1];
        for (let pO = OO.length - 2; pO >= 0; pO--)
          for (let XO = OO[pO]; XO != JK.empty; XO = XO.nextLayer) KO = new JK(XO.chunkPos, XO.chunk, KO, Math.max(XO.tDO, KO.tDO));
        return KO
      }
    }
    JK.empty = new JK([], [], null, -1), JK.empty.nextLayer = JK.empty;
    class cp {
      finishChunk(OO) {
        this.chunks.push(new SK(this.from, this.to, this.value, this.tDO)), this.chunkPos.push(this.chunkStart), this.chunkStart = -1, this.setMaxPoint = Math.max(this.setMaxPoint, this.tDO), this.tDO = -1, OO && (this.from = [], this.to = [], this.value = [])
      }
      constructor() {
        this.chunks = [], this.chunkPos = [], this.chunkStart = -1, this.last = null, this.lastFrom = -1e9, this.lastTo = -1e9, this.from = [], this.to = [], this.value = [], this.tDO = -1, this.setMaxPoint = -1, this.nextLayer = null
      }
      add(OO, KO, pO) {
        this.addInner(OO, KO, pO) || (this.nextLayer || (this.nextLayer = new cp)).add(OO, KO, pO)
      }
      addInner(OO, KO, pO) {
        let XO = OO - this.lastTo || pO.startSide - this.last.endSide;
        if (XO <= 0 && (OO - this.lastFrom || pO.startSide - this.last.startSide) < 0) throw new Error("Ranges must be added sorted by `from` position and `startSide`");
        return !(XO < 0) && (250 == this.from.length && this.finishChunk(!0), this.chunkStart < 0 && (this.chunkStart = OO), this.from.push(OO - this.chunkStart), this.to.push(KO - this.chunkStart), this.last = pO, this.lastFrom = OO, this.lastTo = KO, this.value.push(pO), pO.point && (this.tDO = Math.max(this.tDO, KO - OO)), !0)
      }
      addChunk(OO, KO) {
        if ((OO - this.lastTo || KO.value[0].startSide - this.last.endSide) < 0) return !1;
        this.from.length && this.finishChunk(!0), this.setMaxPoint = Math.max(this.setMaxPoint, KO.tDO), this.chunks.push(KO), this.chunkPos.push(OO);
        let pO = KO.value.length - 1;
        return this.last = KO.value[pO], this.lastFrom = KO.from[pO] + OO, this.lastTo = KO.to[pO] + OO, !0
      }
      finish() {
        return this.finishInner(JK.empty)
      }
      finishInner(OO) {
        if (this.from.length && this.finishChunk(!1), 0 == this.chunks.length) return OO;
        let KO = JK.create(this.chunkPos, this.chunks, this.nextLayer ? this.nextLayer.finishInner(OO) : OO, this.setMaxPoint);
        return this.from = null, KO
      }
    }

    function BK(OO, KO, pO) {
      let XO = new Map;
      for (let eO of OO)
        for (let OO = 0; OO < eO.chunk.length; OO++) eO.chunk[OO].tDO <= 0 && XO.set(eO.chunk[OO], eO.chunkPos[OO]);
      let bK = new Set;
      for (let eO of KO)
        for (let OO = 0; OO < eO.chunk.length; OO++) {
          let KO = XO.get(eO.chunk[OO]);
          null == KO || (pO ? pO.mapPos(KO) : KO) != eO.chunkPos[OO] || (null === pO || void 0 === pO ? void 0 : pO.touchesRange(KO, KO + eO.chunk[OO].length)) || bK.add(eO.chunk[OO])
        }
      return bK
    }
    class ZK {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        this.layer = OO, this.skip = KO, this.kDO = pO, this.rank = XO
      }
      get startSide() {
        return this.value ? this.value.startSide : 0
      }
      get endSide() {
        return this.value ? this.value.endSide : 0
      }
      goto(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1e9;
        return this.chunkIndex = this.rangeIndex = 0, this.gotoInner(OO, KO, !1), this
      }
      gotoInner(OO, KO, pO) {
        for (; this.chunkIndex < this.layer.chunk.length;) {
          let KO = this.layer.chunk[this.chunkIndex];
          if (!(this.skip && this.skip.has(KO) || this.layer.chunkEnd(this.chunkIndex) < OO || KO.tDO < this.kDO)) break;
          this.chunkIndex++, pO = !1
        }
        if (this.chunkIndex < this.layer.chunk.length) {
          let XO = this.layer.chunk[this.chunkIndex].findIndex(OO - this.layer.chunkPos[this.chunkIndex], KO, !0);
          (!pO || this.rangeIndex < XO) && this.setRangeIndex(XO)
        }
        this.next()
      }
      forward(OO, KO) {
        (this.to - OO || this.endSide - KO) < 0 && this.gotoInner(OO, KO, !0)
      }
      next() {
        for (;;) {
          if (this.chunkIndex == this.layer.chunk.length) {
            this.from = this.to = 1e9, this.value = null;
            break
          } {
            let OO = this.layer.chunkPos[this.chunkIndex],
              KO = this.layer.chunk[this.chunkIndex],
              pO = OO + KO.from[this.rangeIndex];
            if (this.from = pO, this.to = OO + KO.to[this.rangeIndex], this.value = KO.value[this.rangeIndex], this.setRangeIndex(this.rangeIndex + 1), this.kDO < 0 || this.value.point && this.to - this.from >= this.kDO) break
          }
        }
      }
      setRangeIndex(OO) {
        if (OO == this.layer.chunk[this.chunkIndex].value.length) {
          if (this.chunkIndex++, this.skip)
            for (; this.chunkIndex < this.layer.chunk.length && this.skip.has(this.layer.chunk[this.chunkIndex]);) this.chunkIndex++;
          this.rangeIndex = 0
        } else this.rangeIndex = OO
      }
      nextChunk() {
        this.chunkIndex++, this.rangeIndex = 0, this.next()
      }
      compare(OO) {
        return this.from - OO.from || this.startSide - OO.startSide || this.rank - OO.rank || this.to - OO.to || this.endSide - OO.endSide
      }
    }
    class GK {
      constructor(OO) {
        this.heap = OO
      }
      static from(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : -1,
          XO = [];
        for (let bK = 0; bK < OO.length; bK++)
          for (let eO = OO[bK]; !eO.fX; eO = eO.nextLayer) eO.tDO >= pO && XO.push(new ZK(eO, KO, pO, bK));
        return 1 == XO.length ? XO[0] : new GK(XO)
      }
      get startSide() {
        return this.value ? this.value.startSide : 0
      }
      goto(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1e9;
        for (let pO of this.heap) pO.goto(OO, KO);
        for (let pO = this.heap.length >> 1; pO >= 0; pO--) qp(this.heap, pO);
        return this.next(), this
      }
      forward(OO, KO) {
        for (let pO of this.heap) pO.forward(OO, KO);
        for (let pO = this.heap.length >> 1; pO >= 0; pO--) qp(this.heap, pO);
        (this.to - OO || this.value.endSide - KO) < 0 && this.next()
      }
      next() {
        if (0 == this.heap.length) this.from = this.to = 1e9, this.value = null, this.rank = -1;
        else {
          let OO = this.heap[0];
          this.from = OO.from, this.to = OO.to, this.value = OO.value, this.rank = OO.rank, OO.value && OO.next(), qp(this.heap, 0)
        }
      }
    }

    function qp(OO, KO) {
      for (let pO = OO[KO];;) {
        let XO = 1 + (KO << 1);
        if (XO >= OO.length) break;
        let bK = OO[XO];
        if (XO + 1 < OO.length && bK.compare(OO[XO + 1]) >= 0 && (bK = OO[XO + 1], XO++), pO.compare(bK) < 0) break;
        OO[XO] = pO, OO[KO] = bK, KO = XO
      }
    }
    class xp {
      constructor(OO, KO, pO) {
        this.kDO = pO, this.active = [], this.activeTo = [], this.activeRank = [], this.minActive = -1, this.point = null, this.pointFrom = 0, this.pointRank = 0, this.to = -1e9, this.endSide = 0, this.openStart = -1, this.cursor = GK.from(OO, KO, pO)
      }
      goto(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1e9;
        return this.cursor.goto(OO, KO), this.active.length = this.activeTo.length = this.activeRank.length = 0, this.minActive = -1, this.to = OO, this.endSide = KO, this.openStart = -1, this.next(), this
      }
      forward(OO, KO) {
        for (; this.minActive > -1 && (this.activeTo[this.minActive] - OO || this.active[this.minActive].endSide - KO) < 0;) this.removeActive(this.minActive);
        this.cursor.forward(OO, KO)
      }
      removeActive(OO) {
        tp(this.active, OO), tp(this.activeTo, OO), tp(this.activeRank, OO), this.minActive = UK(this.active, this.activeTo)
      }
      addActive(OO) {
        let KO = 0,
          {
            value: pO,
            to: XO,
            rank: bK
          } = this.cursor;
        for (; KO < this.activeRank.length && (bK - this.activeRank[KO] || XO - this.activeTo[KO]) > 0;) KO++;
        kp(this.active, KO, pO), kp(this.activeTo, KO, XO), kp(this.activeRank, KO, bK), OO && kp(OO, KO, this.cursor.from), this.minActive = UK(this.active, this.activeTo)
      }
      next() {
        let OO = this.to,
          KO = this.point;
        this.point = null;
        let pO = this.openStart < 0 ? [] : null;
        for (;;) {
          let XO = this.minActive;
          if (XO > -1 && (this.activeTo[XO] - this.cursor.from || this.active[XO].endSide - this.cursor.startSide) < 0) {
            if (this.activeTo[XO] > OO) {
              this.to = this.activeTo[XO], this.endSide = this.active[XO].endSide;
              break
            }
            this.removeActive(XO), pO && tp(pO, XO)
          } else {
            if (!this.cursor.value) {
              this.to = this.endSide = 1e9;
              break
            }
            if (this.cursor.from > OO) {
              this.to = this.cursor.from, this.endSide = this.cursor.startSide;
              break
            } {
              let OO = this.cursor.value;
              if (OO.point) {
                if (!(KO && this.cursor.to == this.to && this.cursor.from < this.cursor.to)) {
                  this.point = OO, this.pointFrom = this.cursor.from, this.pointRank = this.cursor.rank, this.to = this.cursor.to, this.endSide = OO.endSide, this.cursor.next(), this.forward(this.to, this.endSide);
                  break
                }
                this.cursor.next()
              } else this.addActive(pO), this.cursor.next()
            }
          }
        }
        if (pO) {
          this.openStart = 0;
          for (let KO = pO.length - 1; KO >= 0 && pO[KO] < OO; KO--) this.openStart++
        }
      }
      activeForPoint(OO) {
        if (!this.active.length) return this.active;
        let KO = [];
        for (let pO = this.active.length - 1; pO >= 0 && !(this.activeRank[pO] < this.pointRank); pO--)(this.activeTo[pO] > OO || this.activeTo[pO] == OO && this.active[pO].endSide >= this.point.endSide) && KO.push(this.active[pO]);
        return KO.reverse()
      }
      openEnd(OO) {
        let KO = 0;
        for (let pO = this.activeTo.length - 1; pO >= 0 && this.activeTo[pO] > OO; pO--) KO++;
        return KO
      }
    }

    function nK(OO, KO, pO, XO, bK, eO) {
      OO.goto(KO), pO.goto(XO);
      let lO = XO + bK,
        vK = XO,
        CO = XO - KO,
        hO = !!eO.boundChange;
      for (let DO = !1;;) {
        let KO = OO.to + CO - pO.to,
          XO = KO || OO.endSide - pO.endSide,
          bK = XO < 0 ? OO.to + CO : pO.to,
          MO = Math.min(bK, lO);
        if (OO.point || pO.point ? (OO.point && pO.point && sK(OO.point, pO.point) && WK(OO.activeForPoint(OO.to), pO.activeForPoint(pO.to)) || eO.comparePoint(vK, MO, OO.point, pO.point), DO = !1) : (DO && eO.boundChange(vK), MO > vK && !WK(OO.active, pO.active) && eO.compareRange(vK, MO, OO.active, pO.active), hO && MO < lO && (KO || OO.openEnd(bK) != pO.openEnd(bK)) && (DO = !0)), bK > lO) break;
        vK = bK, XO <= 0 && OO.next(), XO >= 0 && pO.next()
      }
    }

    function WK(OO, KO) {
      if (OO.length != KO.length) return !1;
      for (let pO = 0; pO < OO.length; pO++)
        if (OO[pO] != KO[pO] && !sK(OO[pO], KO[pO])) return !1;
      return !0
    }

    function tp(OO, KO) {
      for (let pO = KO, XO = OO.length - 1; pO < XO; pO++) OO[pO] = OO[pO + 1];
      OO.pop()
    }

    function kp(OO, KO, pO) {
      for (let XO = OO.length - 1; XO >= KO; XO--) OO[XO + 1] = OO[XO];
      OO[KO] = pO
    }

    function UK(OO, KO) {
      let pO = -1,
        XO = 1e9;
      for (let bK = 0; bK < KO.length; bK++)(KO[bK] - XO || OO[bK].endSide - OO[pO].endSide) < 0 && (pO = bK, XO = KO[bK]);
      return pO
    }

    function Op(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : OO.length,
        XO = 0;
      for (let bK = 0; bK < pO && bK < OO.length;) 9 == OO.charCodeAt(bK) ? (XO += KO - XO % KO, bK++) : (XO++, bK = yK(OO, bK));
      return XO
    }

    function Kp(OO, KO, pO, XO) {
      for (let bK = 0, eO = 0;;) {
        if (eO >= KO) return bK;
        if (bK == OO.length) break;
        eO += 9 == OO.charCodeAt(bK) ? pO - eO % pO : 1, bK = yK(OO, bK)
      }
      return !0 === XO ? -1 : OO.length
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);