export const id = 180;
export const ids = [180];
export const modules = {
  8355: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      f: () => eO
    });
    var XO = pO(2553);

    function bK() {
      if ("undefined" === typeof BroadcastChannel) return null;
      const OO = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
      try {
        const KO = new BroadcastChannel(XO.h);
        KO.postMessage({
          stored: OO
        }), KO.close()
      } catch {
        return null
      }
      return OO
    }

    function eO(OO) {
      const KO = "object" === typeof OO && null !== OO ? OO.stored : null;
      return "string" === typeof KO ? KO : null
    }
  },
  8347: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      g: () => bK,
      k: () => eO
    });
    var XO = pO(2553);
    async function bK(OO, KO, pO) {
      let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : () => !1;
      const eO = lO(await OO.getItem(XO.f, KO));
      if (null === eO || bK()) return null;
      const vK = await OO.getItem(XO.g, KO);
      return bK() ? null : (await async function(OO) {
        await Promise.all([OO.removeItem(XO.f), OO.removeItem(XO.g)])
      }(OO).catch(pO), {
        pack: eO,
        source: "string" === typeof vK ? vK : null
      })
    }

    function eO(OO) {
      return (0, XO.l)() ? Promise.resolve(null) : bK(OO, !1, (OO => {
        console.error("Error removing temporary texture pack: ", OO)
      }), XO.l)
    }

    function lO(OO) {
      if ("object" !== typeof OO || null === OO) return null;
      const KO = OO.metaData;
      return "object" !== typeof KO || null === KO || "string" !== typeof KO.id ? null : OO
    }
  },
  41353: (OO, KO, pO) => {
    function XO(OO) {
      return null === OO.gameSource ? "player" : "customGame"
    }
    pO.d(KO, {
      d: () => eO,
      e: () => VO,
      h: () => FO,
      l: () => XO
    });
    const bK = /^data:[\w.+/-]*;base64,[A-Za-z0-9+/]*={0,2}$/;

    function eO(OO) {
      return "" === OO || "string" === typeof OO && bK.test(OO)
    }

    function lO(OO) {
      return "object" === typeof OO && null !== OO && ("earth" === OO.type || Object.entries(OO).every((OO => {
        let [KO, pO] = OO;
        return "type" === KO || eO(pO)
      })))
    }
    const vK = /(?:src|image|image-set|cross-fade)\(/i,
      CO = /url\(\s*(?:"(?<doubleQuoted>[^"]*)"|'(?<singleQuoted>[^']*)'|(?<unquoted>[^"'()\s]*))\s*\)/gi,
      hO = /url\(/gi,
      DO = ["https://bloxd.invalid/", "http://bloxd.invalid/"],
      MO = new Set([...DO.map((OO => new URL(OO).origin)), "https://fonts.gstatic.com"]),
      aK = new Set(["https://i.imgur.com/MEcjBFQ.png"]);

    function oO(OO) {
      var KO, pO;
      if (OO.includes("\\") || vK.test(OO)) return !0;
      const XO = [...OO.matchAll(CO)];
      return XO.length !== (null !== (KO = null === (pO = OO.match(hO)) || void 0 === pO ? void 0 : pO.length) && void 0 !== KO ? KO : 0) || !XO.every((OO => {
        var KO, pO, XO;
        let {
          groups: bK
        } = OO;
        return function(OO) {
          try {
            return DO.every((KO => {
              const pO = new URL(OO, KO);
              return "data:" === pO.protocol || MO.has(pO.origin) || aK.has(pO.href)
            }))
          } catch {
            return !1
          }
        }(null !== (KO = null !== (pO = null !== (XO = null === bK || void 0 === bK ? void 0 : bK.doubleQuoted) && void 0 !== XO ? XO : null === bK || void 0 === bK ? void 0 : bK.singleQuoted) && void 0 !== pO ? pO : null === bK || void 0 === bK ? void 0 : bK.unquoted) && void 0 !== KO ? KO : "")
      }))
    }

    function FO(OO) {
      var KO, pO, XO, bK, vK, CO, hO;
      const DO = [...Object.values(null !== (KO = OO.textureOverrides) && void 0 !== KO ? KO : {}), ...Object.values(null !== (pO = OO.modelOverrides) && void 0 !== pO ? pO : {})],
        MO = [...Object.values(null !== (XO = null === (bK = OO.customCss) || void 0 === bK ? void 0 : bK.fontFaces) && void 0 !== XO ? XO : {}), ...Object.values(null !== (vK = null === (CO = OO.customCss) || void 0 === CO ? void 0 : CO.classStyles) && void 0 !== vK ? vK : {})].flatMap((OO => Object.values(null !== OO && void 0 !== OO ? OO : {})));
      return !DO.every(eO) || !Object.values(null !== (hO = OO.skyBoxes) && void 0 !== hO ? hO : {}).every(lO) || MO.some((OO => "string" === typeof OO && oO(OO)))
    }

    function VO(OO, KO) {
      if (null === OO || "player" === KO || !FO(OO)) return OO;
      const pO = {
        ...OO
      };
      return OO.textureOverrides && (pO.textureOverrides = QO(OO.textureOverrides, eO, "texture")), OO.modelOverrides && (pO.modelOverrides = QO(OO.modelOverrides, eO, "model")), OO.skyBoxes && (pO.skyBoxes = QO(OO.skyBoxes, lO, "sky")), OO.customCss && (pO.customCss = function(OO) {
        const KO = OO => QO(OO, (OO => "string" === typeof OO && !oO(OO)), "CSS"),
          {
            fontFaces: pO,
            classStyles: XO
          } = LO(OO) ? OO : {},
          bK = {};
        for (const [eO, lO] of Object.entries(LO(XO) ? XO : {})) bK[eO] = KO(lO);
        return {
          fontFaces: (Array.isArray(pO) ? pO : []).map(KO),
          classStyles: bK
        }
      }(OO.customCss)), pO
    }

    function LO(OO) {
      return "object" === typeof OO && null !== OO && !Array.isArray(OO)
    }

    function QO(OO, KO, pO) {
      const XO = Object.entries(LO(OO) ? OO : {}),
        bK = XO.filter((OO => {
          let [, pO] = OO;
          return !KO(pO)
        }));
      if (bK.length > 0) {
        const OO = bK.map((OO => {
          let [KO] = OO;
          return KO
        }));
        console.warn(`Ignoring a custom game texture pack's ${pO} files that name another site: ${OO.join(", ")}`)
      }
      return Object.fromEntries(XO.filter((OO => {
        let [, pO] = OO;
        return KO(pO)
      })))
    }
  },
  41355: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => FO,
      f: () => AO,
      g: () => zK
    });
    var XO = pO(886),
      bK = pO(2460),
      eO = pO(2536),
      lO = pO(2553),
      vK = pO(8355),
      CO = pO(8347),
      hO = pO(41353),
      DO = pO(39108),
      MO = pO(39101),
      aK = pO(4169);
    const oO = {
      pack: null,
      gameSource: null
    };
    class FO {
      constructor(OO) {
        this.host = OO, this.ready = void 0, this.state = oO, this.playerPack = null, this.onGamePack = !1, this.confirmGamePack = null, this.skippedKey = null, this.ownAnnouncements = new Set, this.listeners = new Map, this.ownListeners = new Set, this.changes = 0, this.picks = 0, this.playerPicked = !1, this.ownChanges = 0, this.YX = !1, (0, lO.i)(), this.ready = this.readStored()
      }
      readyWithin(OO) {
        return Promise.race([this.ready, new Promise((KO => {
          setTimeout(KO, OO)
        }))])
      }
      current() {
        return this.state
      }
      playerState() {
        return {
          pack: this.playerPack,
          gameSource: null
        }
      }
      onPlayerPackChange(OO) {
        return this.ownListeners.add(OO), () => {
          this.ownListeners.delete(OO)
        }
      }
      isUsingCustomGameTexturePack(OO) {
        return (0, MO.f)(this.state, OO)
      }
      setGamePackConfirm(OO) {
        this.confirmGamePack = OO
      }
      subscribe(OO) {
        return this.listeners.set(OO, null), this.ready.then((() => {
          this.deliver(OO)
        })), () => {
          this.listeners.delete(OO)
        }
      }
      async setPlayerPack(OO) {
        const KO = LO(OO) ? null : OO;
        this.picks++, this.playerPicked = !0, this.ownChanges++, this.setOwn(KO), this.change({
          pack: KO,
          gameSource: null
        }, !1);
        const pO = await this.storePlayerPack(KO);
        return pO && this.announce(), pO
      }
      async packForGame(OO, KO, pO) {
        await this.readyWithin(Math.max(0, (null !== pO && void 0 !== pO ? pO : performance.now() + DO.d) - performance.now()));
        const bK = ++this.picks,
          eO = (0, XO.k)(OO) ? (0, XO.o)(OO) : null;
        if (null === eO) return void this.usePlayerPack();
        let lO;
        const vK = function(OO) {
          let KO;
          const pO = new Promise(((pO, XO) => {
            KO = setTimeout((() => {
              XO(new Error(`no answer in ${OO} ms`))
            }), OO)
          }));
          return pO.catch((() => {})), {
            passed: pO,
            clear: () => {
              clearTimeout(KO)
            }
          }
        }(2e4);
        try {
          const OO = await Promise.race([KO.packKey(eO), vK.passed]);
          if (null !== OO && this.onGamePack && this.state.gameSource === OO) return;
          if (null !== OO && OO === this.skippedKey) return void(this.YX || this.picks !== bK || this.usePlayerPack());
          lO = null === OO ? null : await Promise.race([VO(eO, OO, KO), vK.passed])
        } catch (MO) {
          const OO = !this.YX && this.picks === bK && this.holdsOtherGamePack(eO);
          return this.host.warn(`the texture pack of ${eO} didn't load: ${OO?"the player's own shows":"the pack in play stays"}`, MO), void(OO && this.usePlayerPack())
        } finally {
          vK.clear()
        }
        if (this.YX || this.picks !== bK) return;
        null !== lO && (0, hO.h)(lO.pack) && (this.host.warn(`the texture pack of ${eO} names files on other sites: the player's own shows`, null), lO = null);
        const CO = null === lO || await this.confirmed(lO.pack, eO) ? null : lO.key;
        this.YX || this.picks !== bK || (null !== CO && (this.skippedKey = CO, lO = null), null === lO ? this.usePlayerPack() : (this.onGamePack = !0, this.change({
          pack: lO.pack,
          gameSource: lO.key
        }, !0)))
      }
      endGamePack() {
        this.picks++, this.usePlayerPack()
      }
      holdsOtherGamePack(OO) {
        return this.onGamePack && "" !== this.state.gameSource && !this.isUsingCustomGameTexturePack(OO)
      }
      async confirmed(OO, KO) {
        const pO = this.confirmGamePack;
        if (null === pO) return !0;
        try {
          return await pO(OO, KO)
        } catch (XO) {
          return this.host.warn(`the texture pack prompt of ${KO} failed: the pack is skipped`, XO), !1
        }
      }
      async readPlayerPack() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        if (null !== OO && this.ownAnnouncements.delete(OO)) return;
        await this.ready;
        const KO = this.ownChanges;
        let pO;
        try {
          pO = await this.host.store.getItem(lO.d, !0)
        } catch (bK) {
          return void this.host.warn("the stored texture pack didn't read again: the pack in play stays", bK)
        }
        if (this.YX || this.ownChanges !== KO) return;
        const XO = QO(pO);
        (0, aK.b)(XO, this.playerPack) || (this.ownChanges++, this.setOwn(XO), this.onGamePack || this.change({
          pack: XO,
          gameSource: null
        }, !1))
      }
      joinedWithout() {
        this.picks++
      }
      dispose() {
        this.YX = !0, this.listeners.clear()
      }
      async readStored() {
        const {
          store: OO,
          warn: KO
        } = this.host;
        await Promise.all([!1 === this.host.oneShot ? void 0 : (0, CO.g)(OO, !0, (OO => {
          KO("the custom game's texture pack wasn't removed from storage", OO)
        })).then((OO => {
          this.takeOneShot(OO)
        }), (OO => {
          KO("the custom game's texture pack didn't read: the player's own shows", OO)
        })), OO.getItem(lO.d, !0).then((OO => {
          this.takeStoredOwn(OO)
        }), (OO => {
          KO("the stored texture pack didn't read: the default pack shows", OO), this.takeStoredOwn(null)
        }))]), this.update()
      }
      takeOneShot(OO) {
        var KO;
        null === OO || this.YX || this.changes > 0 || this.picks > 0 || ((0, hO.h)(OO.pack) ? this.host.warn("the custom game's texture pack names files on other sites: the player's own shows", null) : (this.onGamePack = !0, this.state = {
          pack: OO.pack,
          gameSource: null !== (KO = OO.source) && void 0 !== KO ? KO : ""
        }))
      }
      takeStoredOwn(OO) {
        if (this.playerPicked || this.YX) return;
        if (this.ownChanges++, this.setOwn(QO(OO)), this.onGamePack) return;
        const KO = {
          pack: this.playerPack,
          gameSource: null
        };
        0 === this.changes ? this.state = KO : this.change(KO, !1)
      }
      async update() {
        const OO = this.playerPack,
          KO = null === OO || void 0 === OO ? void 0 : OO.metaData.id;
        if (!OO || !KO || !this.host.fetchLatest || KO === bK.c || KO === bK.o.CUSTOM) return;
        const pO = bK.p[KO];
        if (void 0 === pO || OO.metaData.version >= pO) return;
        let XO;
        try {
          XO = QO(await this.host.fetchLatest(KO))
        } catch (eO) {
          return void this.host.warn(`texture pack ${KO} didn't update to version ${pO}`, eO)
        }
        null === XO || this.YX || this.playerPack !== OO || (this.ownChanges++, this.setOwn(XO), this.onGamePack || this.change({
          pack: XO,
          gameSource: null
        }, !1), await this.storePlayerPack(XO) && this.announce())
      }
      announce() {
        const OO = (0, vK.c)();
        null !== OO && this.ownAnnouncements.add(OO)
      }
      setOwn(OO) {
        this.playerPack = OO;
        for (const pO of [...this.ownListeners]) try {
          pO()
        } catch (KO) {
          this.host.warn("a texture pack listener threw", KO)
        }
      }
      usePlayerPack() {
        this.onGamePack && this.change({
          pack: this.playerPack,
          gameSource: null
        }, !1)
      }
      async storePlayerPack(OO) {
        try {
          return null === OO ? (await this.host.store.removeItem(lO.d), !0) : await this.host.store.setItem(lO.d, OO)
        } catch (KO) {
          return this.host.warn("the texture pack wasn't stored: it shows until the page reloads", KO), !1
        }
      }
      change(OO, KO) {
        if (!this.YX) {
          this.changes++, this.onGamePack = KO, this.state = OO;
          for (const OO of [...this.listeners.keys()]) this.deliver(OO)
        }
      }
      deliver(OO) {
        if (!this.YX && this.listeners.has(OO) && this.listeners.get(OO) !== this.state) {
          this.listeners.set(OO, this.state);
          try {
            OO(this.state)
          } catch (KO) {
            this.host.warn("a texture pack listener threw", KO)
          }
        }
      }
    }
    async function VO(OO, KO, pO) {
      const XO = (0, CO.e)(await pO.fetchPack(KO));
      if (null !== XO) return {
        pack: XO,
        key: KO
      };
      const bK = await pO.packKey(OO);
      if (null === bK) return null;
      const eO = (0, CO.e)(await pO.fetchPack(bK));
      if (null === eO) throw new Error(`no texture pack at ${bK}`);
      return {
        pack: eO,
        key: bK
      }
    }

    function LO(OO) {
      return null === OO || OO.metaData.id === bK.c
    }

    function QO(OO) {
      const KO = (0, CO.e)(OO);
      return LO(KO) ? null : KO
    }
    async function zK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : eO.c;
      if (null === OO.pack) return null;
      const {
        packAssets: XO
      } = await Promise.all([pO.e(62), pO.e(183), pO.e(85), pO.e(186), pO.e(40)]).then((() => pO(59387)));
      return XO(OO, KO)
    }

    function AO(OO) {
      const KO = (0, lO.o)();
      return null === KO ? () => {} : (KO.onmessage = KO => {
        OO.readPlayerPack((0, vK.f)(KO.data))
      }, () => {
        KO.close()
      })
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);