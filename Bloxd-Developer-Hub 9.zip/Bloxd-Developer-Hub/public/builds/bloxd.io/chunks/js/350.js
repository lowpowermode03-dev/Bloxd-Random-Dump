export const id = 350;
export const ids = [350];
export const modules = {
  59327: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      lodPixelShaderWGSL: () => lO
    });
    var XO = pO(37907);
    const bK = "lodPixelShader",
      eO = "const GammaEncodePowerApprox=1.0/2.2;varying vUV: vec2f;var textureSampler: texture_2d<f32>;uniform lod: f32;uniform gamma: i32;@fragment\nfn main(input: FragmentInputs)->FragmentOutputs {let textureSize=textureDimensions(textureSampler);fragmentOutputs.color=textureLoad(textureSampler,vec2u(fragmentInputs.vUV*vec2f(textureSize)),u32(uniforms.lod));if (uniforms.gamma==0) {fragmentOutputs.color=vec4f(pow(fragmentOutputs.color.rgb,vec3f(GammaEncodePowerApprox)),fragmentOutputs.color.a);}}\n";
    XO.b.ShadersStoreWGSL[bK] || (XO.b.ShadersStoreWGSL[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);