export const id = 9;
export const ids = [9];
export const modules = {
  37611: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => bK
    });
    var XO = pO(36414);
    const bK = function(OO, KO, pO) {
      let bK;
      return {
        plugins: {
          placeAgainstBeds: (0, XO.b)()
        },
        onCreate: OO => {
          bK = OO
        },
        onPlayerAltAction: (OO, KO, pO, XO, eO, lO) => {
          ((OO, KO) => {
            if (!KO || "Mesh" !== bK.getEntityType(KO)) return;
            const pO = bK.getEntityName(KO);
            "Upgrades" === pO ? bK.openShop(OO, !1, "Upgrades") : "Items" === pO && bK.openShop(OO, !1, "Recommended")
          })(OO, lO)
        }
      }
    }
  },
  36414: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK
    });
    var XO = pO(256),
      bK = pO(35411),
      eO = pO(3673);
    const lO = ["Leaf Bed", "_Leaf Bed Head", ...XO.Bc.flatMap((OO => [`${OO} Bed`, `_${OO} Bed Head`, `${OO} Strongbed`, `_${OO} Strongbed Head`]))];

    function vK() {
      let OO;
      return {
        onCreate(KO) {
          OO = KO
        },
        altVetoBlocks: lO,
        onPlayerAttemptAltAction(KO, pO, XO, lO, vK, CO) {
          var hO;
          if ((0, bK.c)(OO.getMetaInfo(vK).rootName) && !OO.isEntityInteractable(CO) && (0, eO.f)(null === (hO = OO.mhO(KO)) || void 0 === hO ? void 0 : hO.typeObj.type)) return "preventAction"
        }
      }
    }
  },
  35411: (OO, KO, pO) => {
    function XO(OO) {
      return OO.includes("Leaf Bed")
    }

    function bK(OO) {
      return / Bed(?: Head)?(?:\||$)/.test(OO) && !XO(OO)
    }

    function eO(OO) {
      return OO.includes(" Strongbed")
    }

    function lO(OO) {
      return XO(OO) || bK(OO) || eO(OO)
    }
    pO.d(KO, {
      c: () => lO,
      g: () => XO,
      k: () => eO,
      l: () => bK
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);