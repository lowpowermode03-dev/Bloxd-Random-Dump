export const id = 310;
export const ids = [310];
export const modules = {
  40046: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(37907);
    const bK = "clipPlaneVertex",
      eO = "#ifdef CLIPPLANE\nfClipDistance=dot(worldPos,vClipPlane);\n#endif\n#ifdef CLIPPLANE2\nfClipDistance2=dot(worldPos,vClipPlane2);\n#endif\n#ifdef CLIPPLANE3\nfClipDistance3=dot(worldPos,vClipPlane3);\n#endif\n#ifdef CLIPPLANE4\nfClipDistance4=dot(worldPos,vClipPlane4);\n#endif\n#ifdef CLIPPLANE5\nfClipDistance5=dot(worldPos,vClipPlane5);\n#endif\n#ifdef CLIPPLANE6\nfClipDistance6=dot(worldPos,vClipPlane6);\n#endif\n";
    XO.b.IncludesShadersStore[bK] || (XO.b.IncludesShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  39961: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(37907);
    const bK = "clipPlaneVertexDeclaration",
      eO = "#ifdef CLIPPLANE\nuniform vec4 vClipPlane;varying float fClipDistance;\n#endif\n#ifdef CLIPPLANE2\nuniform vec4 vClipPlane2;varying float fClipDistance2;\n#endif\n#ifdef CLIPPLANE3\nuniform vec4 vClipPlane3;varying float fClipDistance3;\n#endif\n#ifdef CLIPPLANE4\nuniform vec4 vClipPlane4;varying float fClipDistance4;\n#endif\n#ifdef CLIPPLANE5\nuniform vec4 vClipPlane5;varying float fClipDistance5;\n#endif\n#ifdef CLIPPLANE6\nuniform vec4 vClipPlane6;varying float fClipDistance6;\n#endif\n";
    XO.b.IncludesShadersStore[bK] || (XO.b.IncludesShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40051: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(37907);
    const bK = "fogVertex",
      eO = "#ifdef FOG\nvFogDistance=(view*worldPos).xyz;\n#endif\n";
    XO.b.IncludesShadersStore[bK] || (XO.b.IncludesShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  39965: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO
    });
    var XO = pO(37907);
    const bK = "fogVertexDeclaration",
      eO = "#ifdef FOG\nvarying vec3 vFogDistance;\n#endif\n";
    XO.b.IncludesShadersStore[bK] || (XO.b.IncludesShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  39991: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(37907);
    const bK = "logDepthDeclaration",
      eO = "#ifdef LOGARITHMICDEPTH\nuniform float logarithmicDepthConstant;varying float vFragmentDepth;\n#endif\n";
    XO.b.IncludesShadersStore[bK] || (XO.b.IncludesShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40076: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO
    });
    var XO = pO(37907);
    const bK = "logDepthVertex",
      eO = "#ifdef LOGARITHMICDEPTH\nvFragmentDepth=1.0+gl_Position.w;gl_Position.z=log2(max(0.000001,vFragmentDepth))*logarithmicDepthConstant;\n#endif\n";
    XO.b.IncludesShadersStore[bK] || (XO.b.IncludesShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  59116: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      skyVertexShader: () => oO
    });
    var XO = pO(37907),
      bK = pO(39991),
      eO = pO(39961),
      lO = pO(39965),
      vK = pO(40046),
      CO = pO(40076),
      hO = pO(40051);
    const DO = "skyVertexShader",
      MO = "precision highp float;attribute vec3 position;\n#ifdef VERTEXCOLOR\nattribute vec4 color;\n#endif\nuniform mat4 world;uniform mat4 view;uniform mat4 viewProjection;\n#ifdef POINTSIZE\nuniform float pointSize;\n#endif\nvarying vec3 vPositionW;\n#ifdef VERTEXCOLOR\nvarying vec4 vColor;\n#endif\n#include<logDepthDeclaration>\n#include<clipPlaneVertexDeclaration>\n#include<fogVertexDeclaration>\n#define CUSTOM_VERTEX_DEFINITIONS\nvoid main(void) {\n#define CUSTOM_VERTEX_MAIN_BEGIN\ngl_Position=viewProjection*world*vec4(position,1.0);vec4 worldPos=world*vec4(position,1.0);vPositionW=vec3(worldPos);\n#include<clipPlaneVertex>\n#include<logDepthVertex>\n#include<fogVertex>\n#ifdef VERTEXCOLOR\nvColor=color;\n#endif\n#if defined(POINTSIZE) && !defined(WEBGPU)\ngl_PointSize=pointSize;\n#endif\n#define CUSTOM_VERTEX_MAIN_END\n}\n";
    XO.b.ShadersStore[DO] || (XO.b.ShadersStore[DO] = MO);
    const aK = [bK.c, eO.c, lO.b, vK.c, CO.b, hO.c];
    for (const FO of aK) XO.b.IncludesShadersStore[FO.name] || (XO.b.IncludesShadersStore[FO.name] = FO.shader);
    const oO = {
      name: DO,
      shader: MO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);