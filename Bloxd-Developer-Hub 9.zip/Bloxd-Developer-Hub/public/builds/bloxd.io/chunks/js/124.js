export const id = 124;
export const ids = [124];
export const modules = {
  5739: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      loadPageShaderPackCompiler: () => ap
    });
    var XO = {};
    pO.r(XO), pO.d(XO, {
      qMO: () => bK,
      GlO: () => eO,
      default: () => ZO,
      xMO: () => lO,
      nDO: () => vK,
      initSync: () => BO,
      oO: () => CO,
      JhO: () => hO,
      WDO: () => DO,
      tMO: () => MO,
      HKO: () => aK,
      kMO: () => oO,
      sKO: () => FO,
      UDO: () => VO
    });
    class bK {
      static __wrap(OO) {
        const KO = Object.create(bK.prototype);
        return KO.__wbg_ptr = OO, QO.register(KO, KO.__wbg_ptr, KO), KO
      }
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, QO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        SO.iTWH(OO, 0)
      }
      get errorsJson() {
        let OO, KO;
        try {
          const pO = SO.P1Ti(this.__wbg_ptr);
          return OO = pO[0], KO = pO[1], NO(pO[0], pO[1])
        } finally {
          SO.mvIg(OO, KO, 1)
        }
      }
      get features() {
        const OO = SO.F1KC(this.__wbg_ptr);
        var KO = AO(OO[0], OO[1]);
        return SO.mvIg(OO[0], 4 * OO[1], 4), KO
      }
      get hooks() {
        const OO = SO.zEnv(this.__wbg_ptr);
        var KO = fO(OO[0], OO[1]).slice();
        return SO.mvIg(OO[0], 1 * OO[1], 1), KO
      }
      mapValidationMessage(OO, KO, pO, XO, bK) {
        let eO, lO;
        try {
          const hO = SO.jIuz(this.__wbg_ptr, OO, KO, pO, zK(XO), zK(bK));
          var vK = hO[0],
            CO = hO[1];
          if (hO[3]) throw vK = 0, CO = 0, iK(hO[2]);
          return eO = vK, lO = CO, NO(vK, CO)
        } finally {
          SO.mvIg(eO, lO, 1)
        }
      }
      get moduleCodes() {
        const OO = SO.mnU1(this.__wbg_ptr);
        var KO = AO(OO[0], OO[1]);
        return SO.mvIg(OO[0], 4 * OO[1], 4), KO
      }
      get offInStrictJson() {
        let OO, KO;
        try {
          const pO = SO.iYQ3(this.__wbg_ptr);
          return OO = pO[0], KO = pO[1], NO(pO[0], pO[1])
        } finally {
          SO.mvIg(OO, KO, 1)
        }
      }
      get reads() {
        const OO = SO.RJNv(this.__wbg_ptr);
        var KO = AO(OO[0], OO[1]);
        return SO.mvIg(OO[0], 4 * OO[1], 4), KO
      }
      get validationModuleCodes() {
        const OO = SO.dhHw(this.__wbg_ptr);
        var KO = AO(OO[0], OO[1]);
        return SO.mvIg(OO[0], 4 * OO[1], 4), KO
      }
      get validationModuleKeys() {
        const OO = SO.m0zH(this.__wbg_ptr);
        var KO = fO(OO[0], OO[1]).slice();
        return SO.mvIg(OO[0], 1 * OO[1], 1), KO
      }
      get variantFlags() {
        const OO = SO.PDmb(this.__wbg_ptr);
        var KO = fO(OO[0], OO[1]).slice();
        return SO.mvIg(OO[0], 1 * OO[1], 1), KO
      }
    }

    function eO(OO, KO, pO, XO, eO, lO, vK) {
      const CO = wO(OO, SO.nkpu),
        hO = JO,
        DO = wO(KO, SO.nkpu),
        MO = JO,
        aK = wO(pO, SO.nkpu),
        oO = JO,
        FO = YO(XO, SO.nkpu),
        VO = JO,
        LO = wO(eO, SO.nkpu),
        QO = JO,
        zK = wO(lO, SO.nkpu),
        AO = JO,
        fO = wO(vK, SO.nkpu),
        dO = JO,
        TO = SO.TETC(CO, hO, DO, MO, aK, oO, FO, VO, LO, QO, zK, AO, fO, dO);
      if (TO[2]) throw iK(TO[1]);
      return bK.__wrap(TO[0])
    }

    function lO() {
      const OO = SO.NEcM();
      var KO = AO(OO[0], OO[1]);
      return SO.mvIg(OO[0], 4 * OO[1], 4), KO
    }

    function vK() {
      const OO = SO.PIDe();
      var KO = AO(OO[0], OO[1]);
      return SO.mvIg(OO[0], 4 * OO[1], 4), KO
    }

    function CO() {
      SO.Ss1g()
    }

    function hO(OO, KO, pO, XO, bK) {
      let eO, lO;
      try {
        const hO = wO(OO, SO.nkpu),
          DO = JO,
          MO = YO(KO, SO.nkpu),
          aK = JO,
          oO = wO(pO, SO.nkpu),
          FO = JO,
          VO = YO(XO, SO.nkpu),
          LO = JO,
          QO = function(OO, KO) {
            const pO = KO(1 * OO.length, 1) >>> 0;
            return gK().set(OO, pO / 1), JO = OO.length, pO
          }(bK, SO.nkpu),
          zK = JO,
          AO = SO.foKg(hO, DO, MO, aK, oO, FO, VO, LO, QO, zK);
        var vK = AO[0],
          CO = AO[1];
        if (AO[3]) throw vK = 0, CO = 0, iK(AO[2]);
        return eO = vK, lO = CO, NO(vK, CO)
      } finally {
        SO.mvIg(eO, lO, 1)
      }
    }

    function DO() {
      let OO, KO;
      try {
        const pO = SO.Vtre();
        return OO = pO[0], KO = pO[1], NO(pO[0], pO[1])
      } finally {
        SO.mvIg(OO, KO, 1)
      }
    }

    function MO(OO) {
      let KO, pO;
      try {
        const eO = SO.xIA4(OO);
        var XO = eO[0],
          bK = eO[1];
        if (eO[3]) throw XO = 0, bK = 0, iK(eO[2]);
        return KO = XO, pO = bK, NO(XO, bK)
      } finally {
        SO.mvIg(KO, pO, 1)
      }
    }

    function aK() {
      return SO.SBIE() >>> 0
    }

    function oO() {
      let OO, KO;
      try {
        const pO = SO.kvBy();
        return OO = pO[0], KO = pO[1], NO(pO[0], pO[1])
      } finally {
        SO.mvIg(OO, KO, 1)
      }
    }

    function FO(OO, KO) {
      let pO, XO;
      try {
        const lO = wO(OO, SO.nkpu),
          vK = JO,
          CO = YO(KO, SO.nkpu),
          hO = JO,
          DO = SO.b6Pd(lO, vK, CO, hO);
        var bK = DO[0],
          eO = DO[1];
        if (DO[3]) throw bK = 0, eO = 0, iK(DO[2]);
        return pO = bK, XO = eO, NO(bK, eO)
      } finally {
        SO.mvIg(pO, XO, 1)
      }
    }

    function VO(OO) {
      let KO, pO;
      try {
        const eO = SO.PSly(zK(OO));
        var XO = eO[0],
          bK = eO[1];
        if (eO[3]) throw XO = 0, bK = 0, iK(eO[2]);
        return KO = XO, pO = bK, NO(XO, bK)
      } finally {
        SO.mvIg(KO, pO, 1)
      }
    }

    function LO() {
      return {
        __proto__: null,
        eNVY: {
          __proto__: null,
          qlNH: function(OO, KO) {
            return zK(Error(NO(OO, KO)))
          },
          uaWi: function(OO) {
            return null === uO(OO)
          },
          y3PO: function(OO) {
            return "string" === typeof uO(OO)
          },
          ks23: function(OO, KO) {
            const pO = uO(KO),
              XO = "string" === typeof pO ? pO : void 0;
            var bK, eO = void 0 === (bK = XO) || null === bK ? 0 : function(OO, KO, pO) {
                if (void 0 === pO) {
                  const pO = sO.encode(OO),
                    XO = KO(pO.length, 1) >>> 0;
                  return gK().subarray(XO, XO + pO.length).set(pO), JO = pO.length, XO
                }
                let XO = OO.length,
                  bK = KO(XO, 1) >>> 0;
                const eO = gK();
                let lO = 0;
                for (; lO < XO; lO++) {
                  const KO = OO.charCodeAt(lO);
                  if (KO > 127) break;
                  eO[bK + lO] = KO
                }
                if (lO !== XO) {
                  0 !== lO && (OO = OO.slice(lO)), bK = pO(bK, XO, XO = lO + 3 * OO.length, 1) >>> 0;
                  const KO = gK().subarray(bK + lO, bK + XO);
                  lO += sO.encodeInto(OO, KO).written, bK = pO(bK, XO, lO, 1) >>> 0
                }
                return JO = lO, bK
              }(XO, SO.nkpu, SO.Dis4),
              lO = JO;
            TO().setInt32(OO + 4, lO, !0), TO().setInt32(OO + 0, eO, !0)
          },
          nqb1: function(OO, KO) {
            throw new Error(NO(OO, KO))
          },
          nc8a: function(OO, KO) {
            return uO(OO).charCodeAt(KO >>> 0)
          },
          wskE: function(OO, KO) {
            console.error(NO(OO, KO))
          },
          rAES: function(OO) {
            return uO(OO).length
          },
          EQ7K: function(OO, KO) {
            return zK(NO(OO, KO))
          },
          AseE: function(OO) {
            iK(OO)
          }
        }
      }
    }
    Symbol.dispose && (bK.prototype[Symbol.dispose] = bK.prototype.free);
    const QO = "undefined" === typeof FinalizationRegistry ? {
      register: () => {},
      unregister: () => {}
    } : new FinalizationRegistry((OO => SO.iTWH(OO, 1)));

    function zK(OO) {
      jK === EO.length && EO.push(EO.length + 1);
      const KO = jK;
      return jK = EO[KO], EO[KO] = OO, KO
    }

    function AO(OO, KO) {
      OO >>>= 0;
      const pO = TO(),
        XO = [];
      for (let bK = OO; bK < OO + 4 * KO; bK += 4) XO.push(iK(pO.getUint32(bK, !0)));
      return XO
    }

    function fO(OO, KO) {
      return OO >>>= 0, gK().subarray(OO / 1, OO / 1 + KO)
    }
    let dO = null;

    function TO() {
      return (null === dO || !0 === dO.buffer.detached || void 0 === dO.buffer.detached && dO.buffer !== SO.memory.buffer) && (dO = new DataView(SO.memory.buffer)), dO
    }

    function NO(OO, KO) {
      return function(OO, KO) {
        mK += KO, mK >= PO && (rK = new TextDecoder("utf-8", {
          ignoreBOM: !0,
          fatal: !0
        }), rK.decode(), mK = KO);
        return rK.decode(gK().subarray(OO, OO + KO))
      }(OO >>> 0, KO)
    }
    let IO = null;
    let yK = null;

    function gK() {
      return null !== yK && 0 !== yK.byteLength || (yK = new Uint8Array(SO.memory.buffer)), yK
    }

    function uO(OO) {
      return EO[OO]
    }
    let EO = new Array(1024).fill(void 0);
    EO.push(void 0, null, !0, !1);
    let jK = EO.length;

    function YO(OO, KO) {
      const pO = KO(4 * OO.length, 4) >>> 0;
      return (null !== IO && 0 !== IO.byteLength || (IO = new Uint32Array(SO.memory.buffer)), IO).set(OO, pO / 4), JO = OO.length, pO
    }

    function wO(OO, KO) {
      const pO = KO(4 * OO.length, 4) >>> 0,
        XO = TO();
      for (let bK = 0; bK < OO.length; bK++) XO.setUint32(pO + 4 * bK, zK(OO[bK]), !0);
      return JO = OO.length, pO
    }

    function iK(OO) {
      const KO = uO(OO);
      return function(OO) {
        OO < 1028 || (EO[OO] = jK, jK = OO)
      }(OO), KO
    }
    let rK = new TextDecoder("utf-8", {
      ignoreBOM: !0,
      fatal: !0
    });
    rK.decode();
    const PO = 2146435072;
    let mK = 0;
    const sO = new TextEncoder;
    "encodeInto" in sO || (sO.encodeInto = function(OO, KO) {
      const pO = sO.encode(OO);
      return KO.set(pO), {
        read: OO.length,
        written: pO.length
      }
    });
    let HO, RO, SO, JO = 0;

    function cK(OO, KO) {
      return RO = OO, SO = OO.exports, HO = KO, dO = null, IO = null, yK = null, SO.UsLy(), SO
    }

    function BO(OO) {
      if (void 0 !== SO) return SO;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module: OO
      } = OO) : console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));
      const KO = LO();
      OO instanceof WebAssembly.Module || (OO = new WebAssembly.Module(OO));
      return cK(new WebAssembly.Instance(OO, KO), OO)
    }
    async function ZO(OO) {
      if (void 0 !== SO) return SO;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module_or_path: OO
      } = OO) : console.warn("using deprecated parameters for the initialization function; pass a single object instead"));
      const KO = LO();
      ("string" === typeof OO || "function" === typeof Request && OO instanceof Request || "function" === typeof URL && OO instanceof URL) && (OO = fetch(OO));
      const {
        instance: pO,
        module: XO
      } = await async function(OO, KO) {
        if ("function" === typeof Response && OO instanceof Response) {
          if (!OO.ok) throw new Error(`failed to fetch Wasm: ${OO.status} ${OO.statusText} fetching '${OO.url}'`);
          if ("function" === typeof WebAssembly.instantiateStreaming) try {
            return await WebAssembly.instantiateStreaming(OO, KO)
          } catch (pO) {
            if (! function(OO) {
                switch (OO) {
                  case "basic":
                  case "cors":
                  case "default":
                    return !0
                }
                return !1
              }(OO.type) || "application/wasm" === OO.headers.get("Content-Type")) throw pO;
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", pO)
          }
          const XO = await OO.arrayBuffer();
          return await WebAssembly.instantiate(XO, KO)
        } {
          const pO = await WebAssembly.instantiate(OO, KO);
          return pO instanceof WebAssembly.Instance ? {
            instance: pO,
            module: OO
          } : pO
        }
      }(await OO, KO);
      return cK(pO, XO)
    }
    var GO = pO(2951),
      qK = pO(5747);
    class xK extends Error {
      stage;
      constructor(OO, KO) {
        super((0, GO.v)(OO, KO), {
          cause: KO
        }), this.name = "BloxdShaderPackWasmLoadError", this.stage = OO
      }
    }
    let nO = null,
      WO = null;

    function tK() {
      return nO ? Promise.resolve(nO) : (WO || (WO = async function() {
        let OO;
        try {
          OO = await (0, GO.x)(new pO.U(pO(5759)), (0, qK.e)("bloxd_wasm_shader_pack"))
        } catch (KO) {
          throw new xK((0, GO.z)(KO), KO)
        }
        try {
          await ZO({
            module_or_path: OO
          })
        } catch (KO) {
          throw new xK("instantiate", KO)
        }
        return nO = XO, nO
      }(), WO.then(void 0, (() => {
        WO = null
      }))), WO)
    }
    var kK = pO(5771);

    function UO(OO) {
      let [KO, pO, XO, bK] = OO;
      const eO = {
        file: KO,
        line: pO,
        message: XO
      };
      return bK && (eO.variants = bK.map(kK.m)), eO
    }

    function OK(OO) {
      return JSON.parse(OO).map(UO)
    }

    function KK(OO, KO) {
      if (!Number.isInteger(OO) || OO < 0 || OO > 4294967295) throw new Error(`${KO} ${OO} is not a whole number from 0 to 4294967295`);
      return OO
    }

    function pK(OO) {
      return [OO.named.map((OO => OO.name)), Uint32Array.from(OO.named, (OO => KK(OO.id, "Texture ID")))]
    }
    const XK = new WeakMap;
    const bp = new WeakMap,
      eK = new WeakSet;

    function lK(OO, KO) {
      if (eK.has(OO)) throw new Error("The shader pack compiler crashed earlier on this page, so it can't run again until a reload");
      try {
        return KO()
      } catch (pO) {
        throw pO instanceof WebAssembly.RuntimeError && eK.add(OO), pO
      }
    }

    function vp(OO) {
      let KO = bp.get(OO);
      if (!KO) {
        let pO, XO;
        KO = {
          GlO: (KO, pO) => lK(OO, (() => function(OO, KO, pO) {
            const XO = OO.GlO(KO.map((OO => OO.path)), KO.map((OO => OO.source)), ...pK(pO), pO.aliases.map((OO => OO.name)), pO.aliases.map((OO => OO.texture)), pO.aliases.map((OO => OO.kind)));
            let bK = !1;
            try {
              const OO = XO.validationModuleCodes,
                KO = Array.from(XO.validationModuleKeys, ((KO, pO) => ({
                  key: (0, kK.m)(KO),
                  code: OO[pO]
                }))),
                pO = {
                  errors: OK(XO.errorsJson),
                  offInStrict: OK(XO.offInStrictJson),
                  variants: (0, kK.g)(XO),
                  validationModules: KO,
                  features: XO.features
                };
              return KO.forEach(((OO, KO) => {
                XK.set(OO, {
                  pack: XO,
                  index: KO
                })
              })), bK = KO.length > 0, pO
            } finally {
              bK || XO.free()
            }
          }(OO, KO, pO))),
          mapValidationMessage: (KO, pO) => {
            const XO = XK.get(KO);
            if (!XO) throw new Error("mapValidationMessage takes a validation module this compiler made");
            return UO(JSON.parse(lK(OO, (() => XO.pack.mapValidationMessage(XO.index, pO.lineNum, pO.linePos, pO.message, pO.type)))))
          },
          JhO: KO => lK(OO, (() => function(OO, KO) {
            const pO = new Int32Array(KO.length),
              XO = [];
            return KO.forEach(((OO, KO) => {
              pO[KO] = OO.variants ? OO.variants.length : -1;
              for (const pO of OO.variants ?? []) XO.push((0, kK.i)(pO))
            })), OK(OO.JhO(KO.map((OO => OO.file)), Uint32Array.from(KO, (OO => KK(OO.line, "Diagnostic line"))), KO.map((OO => OO.message)), pO, Uint8Array.from(XO)))
          }(OO, KO))),
          sKO: KO => lK(OO, (() => OO.sKO(...pK(KO)))),
          get SHADER_PACK_HEADER_VERSION() {
            return pO ??= lK(OO, (() => OO.kMO())), pO
          },
          get DEFAULT_SHADER_PACK_FILES() {
            return XO ??= lK(OO, (() => {
              const KO = OO.nDO();
              return OO.xMO().map(((OO, pO) => ({
                path: OO,
                source: KO[pO]
              })))
            })), XO
          },
          UDO: KO => lK(OO, (() => OO.UDO(KO))),
          resolveHeader: KO => lK(OO, (() => OO.tMO((0, kK.i)(KO)))),
          WDO: () => lK(OO, (() => OO.WDO()))
        }, bp.set(OO, KO)
      }
      return KO
    }
    var CK = pO(2514),
      hK = pO(5763);
    const DK = "bloxdShaderPackWasmFailureReported";
    let MK = null;

    function ap() {
      return MK ??= async function() {
        if ("undefined" === typeof WebAssembly) return oK("unsupported", "This browser has no WebAssembly"), null;
        const OO = (0, hK.loadShaderPackTextures)().then((() => !0), (OO => (console.error("Could not load the shader pack textures, so shader packs can't run", OO), !1)));
        try {
          const KO = await async function() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : tK;
            return vp(await OO())
          }();
          return await OO ? KO : null
        } catch (KO) {
          const OO = KO instanceof Error ? KO.message : String(KO);
          return oK(CK.d[KO instanceof xK ? KO.stage : "instantiate"], OO), null
        }
      }(), MK
    }

    function oK(OO, KO) {
      (0, CK.k)(DK, `Shader pack wasm ${OO}, so shader packs can't run: ${KO}`, KO, `shader_pack_${OO}`)
    }
  },
  5759: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_shader_pack_bg.01524faea5d66be8faf7.wasm"
  },
  5747: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(2951);
    const bK = {
      bloxd_wasm: () => "ac9f597375b38c338329c51c36d32b24f862e44eebff0f4b8070bfff0ce24e92",
      bloxd_wasm_client: () => "e981deecce97c0a28139db7f8c487a2f1f307b3295318edfa657ecf781f0bce4",
      bloxd_wasm_workers: () => "11a4c5ee562d561d1a564ae8ce4086cba4f264a242fa24e0ae9cdfd0bb313186",
      bloxd_wasm_models: () => "bee0165155b97fd136a7cf0dedea22e1a110c87d8e70a67ca6e7edc58b55e8c7",
      bloxd_wasm_webgpu: () => "4b4c96cc3f4d3f9fc4a3ff616e4c50aa2c87d4131077e77b476abf6704ec291f",
      bloxd_wasm_webgl: () => "c0bb33a3813b8b5918333de6d7e2622ae319a2c772f31975c56b5febf114b7c8",
      bloxd_wasm_webgl1: () => "971c025c2fdfbded0d795677b38da6ca90549b67af60539fae327208414e3132",
      bloxd_wasm_replay: () => "0cb774dff0a4b55ce86f8d87aef4bc59eda1d7a7c4e4115b219a9e7a09e651bf",
      bloxd_wasm_recorder: () => "82c26252e3c6033837d798c44d8bb77c08b2a095b569b6a2ed41666d348b5fa6",
      bloxd_wasm_anim: () => "fc31b88580a805317f744c8d79a3dc71a8b7a05a63ab0e8adfe930888a0cdb3e",
      bloxd_wasm_textures: () => "faf92bedf683183467afa4b668afe838fc10ad79c6cbb331d3174649bb18c10f",
      bloxd_wasm_shader_pack: () => "6cae04de4f8b271d5581ecd7685547570539fb61ec6bee0be5bb136267b6d774"
    };
    var eO = pO(5754);

    function lO(OO) {
      const KO = Object.prototype.hasOwnProperty.call(bK, OO) ? bK[OO]() : void 0;
      if (void 0 !== KO) return {
        sha256: KO,
        onMismatch: eO.v
      };
      throw new XO.l(`${OO} has no release digest, so this build refuses it`)
    }
  },
  5771: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => fO,
      g: () => dO,
      i: () => zK,
      m: () => QO
    });
    var XO = pO(5778);
    const bK = 6,
      eO = 3,
      lO = 1,
      vK = 2,
      CO = 4,
      hO = 8,
      DO = 16,
      MO = 32,
      aK = 64,
      oO = 128,
      FO = ["", "bloxdTerrainVertex", "bloxdTerrainSurface", "bloxdTerrainLight", "bloxdLiquidVertex", "bloxdLiquidSurface", "bloxdLiquidLight", "bloxdModelVertex", "bloxdModelSurface", "bloxdModelLight", "bloxdDefaultSurface", "bloxdDefaultLight"];

    function VO(OO) {
      if (!OO) return 0;
      const KO = FO.indexOf(OO);
      if (KO <= 0) throw new Error(`"${OO}" is not a shader pack hook function`);
      return KO
    }

    function LO(OO) {
      if (0 === OO) return null;
      const KO = FO[OO];
      if (void 0 === KO) throw new Error(`${OO} is not a shader pack hook function id`);
      return KO
    }

    function QO(OO) {
      const KO = XO.e.length;
      return {
        strict: OO >= KO,
        program: XO.e[OO % KO]
      }
    }

    function zK(OO) {
      return Number(OO.strict) * XO.e.length + XO.e.indexOf(OO.program)
    }

    function AO(OO) {
      return "" === OO ? [] : OO.split(" ")
    }

    function fO(OO) {
      const KO = {
        variantFlags: new Uint8Array(bK),
        hooks: new Uint8Array(bK * eO),
        moduleCodes: Array(bK).fill(""),
        reads: Array(2 * bK).fill("")
      };
      for (const pO of OO) {
        const OO = zK(pO.key),
          XO = (OO, KO) => null === pO.hooks.surface || pO.reads.fragment.includes(OO) ? 0 : KO;
        KO.variantFlags[OO] = (pO.sceneDepth ? lO : 0) | (pO.movesVertices ? vK : 0) | (pO.sunShadow ? CO : 0) | (pO.airShadow ? hO : 0) | (pO.discards ? DO : 0) | XO("localPosition", MO) | XO("enchantSpeed", aK) | XO("enchantTier", oO), KO.hooks[OO * eO] = VO(pO.hooks.vertex), KO.hooks[OO * eO + 1] = VO(pO.hooks.surface), KO.hooks[OO * eO + 2] = VO(pO.hooks.light), KO.moduleCodes[OO] = pO.moduleCode, KO.reads[2 * OO] = pO.reads.vertex.join(" "), KO.reads[2 * OO + 1] = pO.reads.fragment.join(" ")
      }
      return KO
    }

    function dO(OO) {
      const {
        hooks: KO,
        moduleCodes: pO,
        reads: XO
      } = OO;
      return Array.from(OO.variantFlags, ((OO, bK) => {
        const MO = bK * eO;
        return {
          key: QO(bK),
          hooks: {
            vertex: LO(KO[MO]),
            surface: LO(KO[MO + 1]),
            light: LO(KO[MO + 2])
          },
          moduleCode: pO[bK],
          sceneDepth: 0 !== (OO & lO),
          sunShadow: 0 !== (OO & CO),
          airShadow: 0 !== (OO & hO),
          movesVertices: 0 !== (OO & vK),
          discards: 0 !== (OO & DO),
          reads: {
            vertex: AO(XO[2 * bK]),
            fragment: AO(XO[2 * bK + 1])
          }
        }
      }))
    }
  },
  5778: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO,
      g: () => bK,
      k: () => eO
    });
    const XO = ["terrain", "liquid", "model"];

    function bK(OO) {
      return !OO.hooks.vertex && !OO.hooks.surface && !OO.hooks.light
    }

    function eO(OO, KO) {
      return "off" !== KO && (null === OO || OO.some((OO => OO.key.strict === ("strict" === KO) && !bK(OO))))
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);