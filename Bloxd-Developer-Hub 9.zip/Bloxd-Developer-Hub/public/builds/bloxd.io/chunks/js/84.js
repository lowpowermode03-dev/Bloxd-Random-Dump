export const id = 84;
export const ids = [84];
export const modules = {
  4004: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => BO
    });
    var XO = pO(63),
      bK = pO(1355),
      eO = pO(256),
      lO = pO(1095),
      vK = pO(1420),
      CO = pO(1123),
      hO = pO(1382),
      DO = pO(1329),
      MO = pO(2139);
    const aK = {
      retries: 2,
      minTimeout: 2e3
    };
    var oO = pO(997),
      FO = pO(1415),
      VO = pO(1004),
      LO = pO(1533),
      QO = pO(1051),
      zK = pO(1077),
      AO = pO(2730),
      fO = pO(1180),
      dO = pO(1271),
      TO = pO(1344),
      NO = pO(2079),
      IO = pO(2093),
      yK = pO(4008),
      gK = pO(1749),
      uO = pO(918),
      EO = pO.n(uO),
      jK = pO(933),
      YO = pO(4012),
      wO = pO(22),
      iK = pO(1556),
      rK = pO(2891),
      PO = pO(1627),
      mK = pO(2846),
      sO = pO(94),
      HO = pO(3732),
      RO = pO(976);
    const SO = [yK];

    function JO(OO) {
      let {
        icon: KO,
        label: pO,
        value: XO
      } = OO;
      return (0, RO.jsxs)("div", {
        className: "PlayerProfileStat",
        children: [(0, RO.jsx)(jK.d, {
          name: KO,
          className: "PlayerProfileStatIcon"
        }), (0, RO.jsxs)("div", {
          className: "PlayerProfileStatText",
          children: [(0, RO.jsx)("div", {
            className: "PlayerProfileStatLabel SmallTextLight",
            children: pO
          }), (0, RO.jsx)("div", {
            className: "PlayerProfileStatValue",
            children: XO
          })]
        })]
      })
    }

    function cK(OO) {
      let {
        profile: KO
      } = OO;
      const {
        t: pO,
        selectedLanguage: XO
      } = (0, QO.D)();
      let bK = pO("homePage:profileUnknown");
      if (KO.lastOnline) {
        const OO = (0, QO.o)(XO.code, "homePage:profileTimeAgo");
        bK = pO("homePage:profileTimeAgo", {
          time: (0, eO.Z)(OO, KO.lastOnline, Date.now())
        })
      }
      let lO = pO("homePage:profileUnknown");
      return KO.accountCreatedAt && (lO = new Date(KO.accountCreatedAt).toLocaleDateString(void 0, {
        year: "numeric",
        month: "short",
        day: "numeric"
      })), (0, RO.jsxs)("div", {
        className: "PlayerProfileStats",
        children: [(0, RO.jsx)(JO, {
          icon: "hourglass",
          label: pO("homePage:profileTimePlayed"),
          value: (0, rK.b)(KO.totalPlayMinutes)
        }), (0, RO.jsx)(JO, {
          icon: "wifi",
          label: pO("homePage:profileLastOnline"),
          value: bK
        }), (0, RO.jsx)(JO, {
          icon: "calendar",
          label: pO("homePage:profileJoined"),
          value: lO
        })]
      })
    }

    function BO() {
      const {
        t: OO
      } = (0, QO.D)(), KO = (0, TO.useNavigatePreserveSearch)(), pO = (0, oO.g)(), {
        playerName: yK,
        playerUrlName: uO
      } = (0, bK.w)(), rK = (0, bK.p)(), JO = (0, lO.h)(rK.pathname), BO = JO && ("urlId" in JO ? `urlId:${JO.urlId}` : `name:${JO.lowerCaseName}`), ZO = (0, XO.useRef)(BO);
      ZO.current = BO;
      const {
        userContext: GO,
        isUserContextUpdating: qK
      } = (0, VO.d)(), xK = (0, XO.useRef)(null), nO = (0, XO.useRef)(null), WO = (0, XO.useRef)(null), tK = (0, XO.useRef)(!1), kK = (0, XO.useRef)((0, eO.$b)(SO)), [UO, OK] = (0, XO.useState)((() => {
        const OO = JO && IO.d.peek(GO, JO);
        return OO ? {
          status: "loaded",
          profile: OO,
          playerKey: BO
        } : {
          status: "loading"
        }
      })), [KK, pK] = (0, XO.useState)(0);
      (0, XO.useEffect)(NO.e, []), (0, XO.useEffect)((() => {
        iK.gameBridge.send("leaveGame", {
          reloadPath: null
        }), wO.d.set({
          gameState: "landingPage",
          openEverythingMenuName: null,
          openInGameMenuName: null
        })
      }), [rK.key]);
      const XK = () => {
        const OO = (0, TO.getPreviousLocation)();
        null === OO || OO.startsWith("/play") ? (0, TO.navigateToHomePage)() : KO(-1)
      };
      (0, HO.e)(XK), (0, XO.useEffect)((() => {
        var OO;
        if (qK) return;
        if (!JO) return void OK({
          status: "notFound",
          playerKey: BO
        });
        const KO = "urlId" in JO && (null === (OO = nO.current) || void 0 === OO ? void 0 : OO.urlId) === JO.urlId && WO.current === GO;
        if (KO && tK.current) return;
        const pO = KO ? null : IO.d.peek(GO, JO);
        let XO = !1;
        const bK = OO => "loaded" === OO.status && (OO.playerKey === BO || "urlId" in JO && OO.profile.urlId === JO.urlId);
        return pO ? (WO.current = GO, tK.current = !1, OK({
          status: "loaded",
          profile: pO,
          playerKey: BO
        }), IO.d.invalidate(JO)) : OK((OO => bK(OO) ? OO : {
          status: "loading"
        })), async function(OO, KO) {
          if ("lowerCaseName" in KO && KO.lowerCaseName.length > CO.f) return {
            status: "notFound"
          };
          try {
            return {
              status: "loaded",
              profile: await DO.c.getPlayerProfile(OO, KO, aK)
            }
          } catch (pO) {
            return (0, MO.d)(pO) ? {
              status: "notFound"
            } : (console.error("Failed to load user profile", pO), {
              status: "failed"
            })
          }
        }(GO, JO).then((OO => {
          XO || ("loaded" === OO.status && (WO.current = GO, tK.current = !0), OK((KO => "failed" === OO.status && bK(KO) ? KO : {
            ...OO,
            playerKey: BO
          })))
        })), () => {
          XO = !0
        }
      }), [qK, BO, GO, KK]);
      const bp = "loading" === UO.status || UO.playerKey === BO || "loaded" === UO.status && !!JO && "urlId" in JO && UO.profile.urlId === JO.urlId ? UO : {
          status: "loading"
        },
        eK = "loaded" === bp.status ? bp.profile : null,
        lK = "loading" === bp.status ? null : function(OO) {
          if ("loaded" === OO.status) {
            const {
              profile: KO
            } = OO;
            return (0, hO.T)({
              urlId: KO.urlId,
              name: KO.player.name,
              ranks: KO.player.ranks,
              socialLinks: KO.socialLinks
            })
          }
          return "notFound" === OO.status ? (0, hO.$)() : null
        }(bp),
        vp = null !== eK && void 0 !== eK && eK.urlId ? (0, lO.l)({
          urlId: eK.urlId,
          name: eK.player.name
        }) : null;
      (0, FO.e)(vp);
      const CK = null !== eK && void 0 !== eK && eK.player.cosmetics.profileEffect ? gK.c[eK.player.cosmetics.profileEffect] : void 0,
        hK = null !== eK && !qK && GO.getPlayerName().toLowerCase() === eK.player.name.toLowerCase(),
        DK = (0, PO.c)(null === eK || void 0 === eK ? void 0 : eK.player.name),
        MK = hK && GO.playerHasRank("youtuber");
      nO.current = eK;
      const ap = (0, XO.useCallback)((() => {
          JO && (IO.d.invalidate(JO), IO.d.get(GO, JO).then((OO => {
            ZO.current === BO && (tK.current = !0, OK({
              status: "loaded",
              profile: OO,
              playerKey: BO
            }))
          })).catch((OO => {
            console.error("Failed to refresh user profile", OO)
          })))
        }), [BO, GO]),
        oK = (0, XO.useCallback)((() => {
          var OO;
          const KO = nO.current;
          return !(!KO || null === (OO = xK.current) || void 0 === OO || !OO.isReady()) && (xK.current.setAllCosmetics(KO.player.cosmetics), !0)
        }), []);
      return (0, XO.useEffect)((() => {
        if (!eK) return;
        let OO, KO = !1;
        const pO = () => {
          KO || oK() || (OO = setTimeout(pO, 100))
        };
        return pO(), () => {
          KO = !0, clearTimeout(OO)
        }
      }), [eK, oK]), (0, RO.jsxs)("div", {
        className: EO()("PlayerProfile", {
          PlayerProfilePortrait: pO
        }),
        children: [lK && (0, RO.jsx)(vK.c, {
          meta: lK
        }), (0, RO.jsxs)("div", {
          className: "PlayerProfileBackgroundContainer",
          children: [CK && (0, RO.jsx)(CK, {}), !CK && (0, RO.jsx)("div", {
            className: "PlayerProfileBackground",
            style: {
              backgroundImage: `url(${kK.current})`
            }
          })]
        }), (0, RO.jsxs)("div", {
          className: "PlayerProfileHeader",
          children: [(0, RO.jsx)(dO.c, {
            onClick: XK,
            children: OO("general:back")
          }), eK && !qK && !hK && sO.featureFlags.useSocialFeatures && (0, RO.jsx)("div", {
            className: "PlayerProfileExclusionActions",
            children: (0, RO.jsx)(mK.c, {
              playerName: eK.player.name,
              className: "SmallTextLight"
            })
          })]
        }), "loading" === bp.status && (0, RO.jsx)("div", {
          className: "PlayerProfileCentredMessage",
          children: (0, RO.jsx)(fO.e, {})
        }), ("notFound" === bp.status || "failed" === bp.status) && (0, RO.jsxs)("div", {
          className: "PlayerProfileCentredMessage PlayerProfileError",
          children: [(0, RO.jsx)(jK.d, {
            name: "face-dizzy"
          }), (0, RO.jsx)("div", {
            className: "PlayerProfileErrorText",
            children: "notFound" === bp.status ? OO("socialBar:playerNotFound", {
              playerName: null !== uO && void 0 !== uO ? uO : yK
            }) : OO("playerProfile:loadFailed")
          }), "failed" === bp.status && (0, RO.jsx)(dO.d, {
            onClick: () => {
              pK((OO => OO + 1))
            },
            children: OO("general:tryAgain")
          })]
        }), eK && (0, RO.jsxs)("div", {
          className: "PlayerProfileContent",
          children: [(0, RO.jsxs)("div", {
            className: "PlayerProfileLeft",
            children: [(0, RO.jsx)("div", {
              className: "PlayerProfileName FullyFancyText",
              children: (0, RO.jsx)(LO.d, {
                text: (0, zK.v)(eK.player.ranks, eK.player.name, eK.player.nameColour),
                friendBadgeFor: DK ? eK.player.name : void 0
              })
            }), (0, RO.jsx)("div", {
              className: "PlayerProfileModel",
              children: (0, RO.jsx)(XO.Suspense, {
                fallback: (0, RO.jsx)("div", {
                  className: "PlayerProfileModelLoading",
                  children: (0, RO.jsx)(fO.e, {})
                }),
                children: (0, RO.jsx)(NO.c, {
                  ref: xK,
                  onReady: () => {
                    oK()
                  }
                })
              })
            })]
          }), (0, RO.jsxs)("div", {
            className: "PlayerProfileRight",
            children: [(0, RO.jsx)(cK, {
              profile: eK
            }), (eK.socialLinks.length > 0 || MK) && (0, RO.jsx)(YO.c, {
              socialLinks: eK.socialLinks,
              editable: MK,
              userContext: GO,
              onLinksUpdated: ap
            }), (0, RO.jsxs)("div", {
              className: "PlayerProfileGames",
              children: [(0, RO.jsx)("div", {
                className: "PlayerProfileGamesTitle SmallTextBold",
                children: OO("homePage:profileReleasedGames")
              }), 0 === eK.releasedGames.length && (0, RO.jsx)("div", {
                className: "PlayerProfileNoGames",
                children: OO("homePage:profileNoReleasedGames")
              }), eK.releasedGames.length > 0 && (0, RO.jsx)("div", {
                className: "PlayerProfileGamesGrid",
                children: eK.releasedGames.map((OO => (0, RO.jsx)(AO.f, {
                  source: {
                    type: "preview",
                    preview: OO
                  },
                  gameWidth: "100%",
                  useLongRatio: !0,
                  hideFavourites: !0,
                  entrySource: "other"
                }, OO.schematicId)))
              })]
            })]
          })]
        })]
      })
    }
  },
  4012: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => LO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(3819),
      lO = pO(1051),
      vK = pO(933),
      CO = pO(1271),
      hO = pO(1329),
      DO = pO(1187),
      MO = pO(2007),
      aK = pO(976);
    const oO = {
      youtube: {
        icon: "youtube",
        color: "#FF0033",
        name: "YouTube"
      },
      tiktok: {
        icon: "tiktok",
        color: "#0F0F0F",
        name: "TikTok"
      },
      instagram: {
        icon: "instagram",
        color: "#E1306C",
        name: "Instagram"
      },
      twitter: {
        icon: "x-twitter",
        color: "#0F0F0F",
        name: "X"
      },
      twitch: {
        icon: "twitch",
        color: "#9146FF",
        name: "Twitch"
      }
    };

    function FO(OO) {
      let {
        platform: KO
      } = OO;
      const pO = "youtube" === KO;
      return (0, aK.jsxs)("span", {
        className: bK()("PlayerProfileSocialLinkIcon", {
          PlayerProfileSocialLinkIconYoutube: pO
        }),
        children: [pO && (0, aK.jsx)(MO.b, {
          variant: "white"
        }), !pO && (0, aK.jsx)(vK.d, {
          name: oO[KO].icon,
          kit: "brands"
        })]
      })
    }

    function VO(OO) {
      let {
        platform: KO,
        link: pO,
        editable: XO,
        userContext: bK,
        onLinksUpdated: MO
      } = OO;
      const {
        t: VO
      } = (0, lO.D)(), LO = oO[KO];
      if (!pO && !XO) return null;

      function QO() {
        var OO;
        if (!bK || !MO) return;
        DO.NotificationProvider.showInputPopup({
          title: "homePage:profileSocialLinkEditTitle",
          textOpts: {
            title: {
              platform: LO.name
            }
          },
          prefixText: eO.A[KO],
          placeholderText: "playBloxd",
          initialValue: null !== (OO = null === pO || void 0 === pO ? void 0 : pO.handle) && void 0 !== OO ? OO : "",
          maxLength: 30,
          submitText: "general:save",
          secondaryButtonText: pO ? "general:remove" : void 0
        }).getResult().then((async OO => {
          if ("notificationTornDown" !== OO && null !== OO) try {
            "submit" === OO.type ? await hO.c.setSocialLink(bK, KO, OO.value) : await hO.c.clearSocialLink(bK, KO), MO()
          } catch (pO) {
            console.error("Failed to update social link", pO), DO.NotificationProvider.showAlertPopup({
              title: pO.errorMessageForUser,
              confirmText: "general:ok"
            })
          }
        }))
      }
      if (pO) {
        const OO = `@${pO.handle}`;
        return (0, aK.jsxs)("a", {
          className: "PlayerProfileSocialLink",
          style: {
            background: LO.color
          },
          href: pO.profileUrl,
          target: "_blank",
          rel: "noopener noreferrer",
          children: [(0, aK.jsxs)("div", {
            className: "PlayerProfileSocialLinkMain",
            children: [(0, aK.jsx)(FO, {
              platform: KO
            }), (0, aK.jsx)("span", {
              className: "PlayerProfileSocialLinkText",
              children: (0, aK.jsx)("span", {
                className: "PlayerProfileSocialLinkName SmallTextBold",
                children: OO
              })
            })]
          }), XO && (0, aK.jsx)("button", {
            type: "button",
            className: "PlayerProfileSocialLinkEditButton",
            ...(0, CO.X)({
              stopPropagation: !0
            }),
            onClick: OO => {
              OO.stopPropagation(), OO.preventDefault(), QO()
            },
            children: (0, aK.jsx)(vK.d, {
              name: "pen-to-square"
            })
          }), !XO && (0, aK.jsx)("span", {
            className: "PlayerProfileSocialLinkArrow",
            children: (0, aK.jsx)(vK.d, {
              name: "arrow-up-right-from-square"
            })
          })]
        })
      }
      return (0, aK.jsxs)("button", {
        type: "button",
        className: "PlayerProfileSocialLink PlayerProfileSocialLinkUnlinked",
        style: {
          background: LO.color
        },
        ...(0, CO.X)(),
        onClick: () => {
          QO()
        },
        children: [(0, aK.jsx)(FO, {
          platform: KO
        }), (0, aK.jsxs)("span", {
          className: "PlayerProfileSocialLinkText",
          children: [(0, aK.jsx)("span", {
            className: "PlayerProfileSocialLinkName SmallTextBold",
            children: LO.name
          }), (0, aK.jsx)("span", {
            className: "PlayerProfileSocialLinkCount SmallTextLight",
            children: VO("homePage:profileSocialLinkAdd")
          })]
        }), (0, aK.jsx)("span", {
          className: "PlayerProfileSocialLinkEditButton",
          children: (0, aK.jsx)(vK.d, {
            name: "pen-to-square"
          })
        })]
      })
    }

    function LO(OO) {
      let {
        socialLinks: KO,
        editable: pO = !1,
        userContext: XO,
        onLinksUpdated: bK
      } = OO;
      if (!pO && 0 === KO.length) return null;
      const lO = new Map(KO.map((OO => [OO.platform, OO]))),
        vK = pO ? eO.w : KO.map((OO => OO.platform));
      return (0, aK.jsx)("div", {
        className: "PlayerProfileSocialLinks",
        children: (0, aK.jsx)("div", {
          className: "PlayerProfileSocialLinksList",
          children: vK.map((OO => (0, aK.jsx)(VO, {
            platform: OO,
            link: lO.get(OO),
            editable: pO,
            userContext: XO,
            onLinksUpdated: bK
          }, OO)))
        })
      })
    }
  },
  4008: OO => {
    OO.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAACXBIWXMAAAPoAAAD6AG1e1JrAAAAQ0lEQVR4nGOws7P7D8Kmpqb/NTU1wTQymwGbAhANwwzIOmAYxQRkCXNzczBGtgrFBGQFKFZgsxtuAi67YY5HMQGbAgCIxWSBYHJzHAAAAABJRU5ErkJggg=="
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);