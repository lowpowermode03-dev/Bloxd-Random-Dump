export const id = 182;
export const ids = [182];
export const modules = {
  38591: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      FORMER_BLOCK_IMAGE_NAMES: () => XO.c,
      textureAnimationData: () => bK.z,
      textureNameToIndex: () => bK.D
    });
    var XO = pO(37100),
      bK = pO(8365)
  },
  8461: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => eO
    });
    var XO = pO(8411);
    const bK = "Air",
      eO = Object.freeze(new XO.f(bK, 0, "", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null))
  },
  37100: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO,
      e: () => bK
    });
    const XO = new Map(["graphite", "football", "torch", "torch_blue", "torch_cyan", "torch_green", "torch_orange", "torch_purple", "torch_red"].map((OO => [OO, `${OO}_block`])));

    function bK(OO) {
      var KO;
      return null !== (KO = XO.get(OO)) && void 0 !== KO ? KO : OO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);