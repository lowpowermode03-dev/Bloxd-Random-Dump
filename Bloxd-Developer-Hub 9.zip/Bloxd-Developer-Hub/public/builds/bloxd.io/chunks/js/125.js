export const id = 125;
export const ids = [125, 192];
export const modules = {
  34879: (OO, KO, pO) => {
    pO.d(KO, {
      reportCappedWasmFailure: () => lO,
      reportWasmFailure: () => eO
    });
    var XO = pO(2516);
    const bK = XO.e - 4;

    function eO(OO, KO, pO) {
      (0, XO.i)(OO, KO, pO, !1)
    }

    function lO(OO, KO, pO) {
      (0, XO.i)(OO, KO, pO, !1, bK)
    }
  },
  34875: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => FO,
      d: () => QO,
      g: () => zK,
      k: () => VO
    });
    var XO = pO(34888),
      bK = pO(2947),
      eO = pO(34905),
      lO = pO(2951),
      vK = pO(34879),
      CO = pO(2308),
      hO = pO(2528),
      DO = pO(2514),
      MO = pO(2831);
    const aK = "bloxdWasmFailureReported";

    function oO() {
      return "undefined" === typeof WebAssembly
    }

    function FO() {
      return (0, XO.g)()
    }

    function VO() {
      if (oO()) return "this browser has no WebAssembly";
      const OO = (0, bK.n)();
      return "compile" === OO || "instantiate" === OO ? `the core wasm didn't load here (${(0,bK.h)()})` : null
    }
    async function LO(OO) {
      return await (0, eO.f)(eO.b, void 0, OO)
    }

    function QO() {
      oO() || (0, MO.d)((() => {
        LO()
      }))
    }

    function zK() {
      if (oO()) return async () => ((0, CO.i)("unsupported", 0), AO("unsupported", "This browser has no WebAssembly"), !1);
      const OO = {
        reloadFailedDownload: !0
      };
      return LO(OO), async () => {
        var KO;
        const pO = performance.now();
        await LO(OO);
        const XO = (performance.now() - pO) / 1e3;
        if ((0, bK.S)()) return (0, CO.i)("ready", XO), (0, lO.D)(eO.b.url()) && (0, vK.reportCappedWasmFailure)("wasm_load", hO.c.message, hO.c.code), !0;
        const MO = DO.d[null !== (KO = (0, bK.n)()) && void 0 !== KO ? KO : "call"];
        return (0, CO.i)(MO, XO), AO(MO, (0, bK.h)()), !1
      }
    }

    function AO(OO, KO) {
      (0, DO.k)(aK, `Bloxd wasm ${OO}, so the game can't start: ${KO}`, KO, OO)
    }
  },
  34914: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_bg.16bfe5416e925bb9d029.wasm"
  },
  34897: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_textures_bg.33dd32223c70718e5850.wasm"
  },
  34910: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => aK,
      h: () => DO
    });
    var XO = pO(2947),
      bK = pO(2951),
      eO = pO(2959),
      lO = pO(5747),
      vK = pO(5754);
    let CO = null,
      hO = !1;

    function DO(OO, KO, pO) {
      return null === CO ? CO = MO(OO, KO) : OO !== CO.build ? console.warn(`Bloxd wasm: ${OO.name} was asked for after ${CO.build.name} started loading, which this thread keeps`) : KO.name !== CO.workers.name && console.warn(`Bloxd wasm: ${KO.name} was asked for workers after ${CO.workers.name}, which this thread keeps`), pO?.reloadFailedDownload && !hO && (0, XO.$)() && (hO = !0, CO = MO(CO.build, CO.workers)), CO.loaded
    }

    function MO(OO, KO) {
      const pO = (0, XO.K)((async () => {
        (0, vK.z)();
        const pO = oO(OO),
          XO = KO.name === OO.name ? pO : oO(KO);
        await (0, eO.f)([pO, XO]);
        const bK = await pO,
          lO = await XO;
        return (0, vK.z)(), {
          module: bK,
          workerModule: lO
        }
      }), OO);
      return {
        build: OO,
        workers: KO,
        loaded: pO
      }
    }
    async function aK(OO) {
      return oO(OO)
    }

    function oO(OO) {
      return (0, bK.x)(OO.url(), (0, lO.e)(OO.name))
    }
  },
  34905: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => uK,
      f: () => EK,
      h: () => jp
    });
    var XO = {};
    pO.r(XO), pO.d(XO, {
      KO: () => bK,
      EnvelopeKind: () => eO,
      pO: () => lO,
      PhysicsEngine: () => vK,
      XO: () => CO,
      bK: () => hO,
      eO: () => DO,
      lO: () => MO,
      vK: () => aK,
      CO: () => oO,
      hO: () => FO,
      DO: () => VO,
      MO: () => LO,
      aK: () => QO,
      default: () => IK,
      initSync: () => NK,
      oO: () => zK,
      FO: () => AO,
      VO: () => fO,
      LO: () => dO,
      QO: () => TO,
      zK: () => NO,
      fO: () => IO,
      dO: () => yK,
      TO: () => gK,
      NO: () => uO,
      IO: () => EO,
      yK: () => jK,
      gK: () => YO,
      uO: () => wO,
      EO: () => iK
    });
    class bK {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, PO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        fK.NcP5(OO, 0)
      }
      jK() {
        const OO = fK.XptT(this.__wbg_ptr);
        if (OO[2]) throw oK(OO[1]);
        return OO[0] >>> 0
      }
      YO() {
        return fK.HUyy(this.__wbg_ptr) >>> 0
      }
      constructor() {
        const OO = fK.H0ZW();
        return this.__wbg_ptr = OO, PO.register(this, this.__wbg_ptr, this), this
      }
      wO() {
        return fK.YFU8(this.__wbg_ptr) >>> 0
      }
      iK(OO) {
        const KO = fK.zge7(this.__wbg_ptr, OO);
        if (KO[2]) throw oK(KO[1]);
        return KO[0] >>> 0
      }
      rK(OO) {
        const KO = fK.kycZ(this.__wbg_ptr, OO);
        if (KO[2]) throw oK(KO[1]);
        return KO[0] >>> 0
      }
    }
    Symbol.dispose && (bK.prototype[Symbol.dispose] = bK.prototype.free);
    const eO = Object.freeze({
      Js: 0,
      0: "Js",
      Error: 1,
      1: "Error",
      LeaveRoom: 2,
      2: "LeaveRoom",
      RoomState: 3,
      3: "RoomState",
      RoomStatePatch: 4,
      4: "RoomStatePatch",
      RoomDataNone: 5,
      5: "RoomDataNone",
      RoomDataBin: 6,
      6: "RoomDataBin",
      RoomDataBytes: 7,
      7: "RoomDataBytes",
      Ignored: 8,
      8: "Ignored",
      StringType: 16,
      16: "StringType"
    });
    class lO {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, mK.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        fK.DrP3(OO, 0)
      }
      sO(OO, KO) {
        const pO = fK.kzyq(this.__wbg_ptr, OO, KO);
        if (pO[2]) throw oK(pO[1]);
        return pO[0] >>> 0
      }
      HO(OO) {
        const KO = fK.nwHI(this.__wbg_ptr, OO);
        if (KO[2]) throw oK(KO[1]);
        return KO[0] >>> 0
      }
      RO() {
        fK.OgT9(this.__wbg_ptr)
      }
      static SO() {
        return fK.vYFV() >>> 0
      }
      JO() {
        return fK.PW8q(this.__wbg_ptr) >>> 0
      }
      cK() {
        const OO = fK.lKkk(this.__wbg_ptr);
        return 0 === OO[0] ? void 0 : OO[1]
      }
      BO() {
        return fK.ZpoU(this.__wbg_ptr) >>> 0
      }
      ZO() {
        return fK.Hazs(this.__wbg_ptr) >>> 0
      }
      static mK() {
        return fK.X3dx() >>> 0
      }
      constructor() {
        const OO = fK.uH5T();
        return this.__wbg_ptr = OO, mK.register(this, this.__wbg_ptr, this), this
      }
      GO() {
        return fK.GNVF(this.__wbg_ptr) >>> 0
      }
      qK() {
        return fK.XsaI(this.__wbg_ptr) >>> 0
      }
      xK() {
        return fK.zSEs(this.__wbg_ptr) >>> 0
      }
      PO(OO) {
        return fK.UGNt(this.__wbg_ptr, OO) >>> 0
      }
      reserve(OO, KO) {
        const pO = fK.NdEh(this.__wbg_ptr, OO, KO);
        if (pO[1]) throw oK(pO[0])
      }
      tK(OO, KO) {
        const pO = hK(OO, fK.TEiC),
          XO = dK;
        fK.hCby(this.__wbg_ptr, pO, XO, KO)
      }
      text() {
        let OO, KO;
        try {
          const pO = fK.DucU(this.__wbg_ptr);
          return OO = pO[0], KO = pO[1], kK(pO[0], pO[1])
        } finally {
          fK.frSG(OO, KO, 1)
        }
      }
    }
    Symbol.dispose && (lO.prototype[Symbol.dispose] = lO.prototype.free);
    class vK {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, sO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        fK.gNZm(OO, 0)
      }
      UO(OO, KO) {
        ZO(KO, bK);
        const pO = fK.vnmU(this.__wbg_ptr, OO, KO.__wbg_ptr);
        if (pO[2]) throw oK(pO[1]);
        return pO[0] >>> 0
      }
      pK() {
        const OO = fK.bM8j(this.__wbg_ptr);
        if (OO[1]) throw oK(OO[0])
      }
      vp(OO, KO, pO, XO, bK, eO, lO, vK, hO, DO, MO) {
        ZO(OO, CO);
        const aK = fK.xU5Z(this.__wbg_ptr, OO.__wbg_ptr, KO, pO, XO, bK, eO, lO, vK, hO, DO, MO);
        if (aK[2]) throw oK(aK[1]);
        return aK[0]
      }
      CK() {
        const OO = fK.xlr3(this.__wbg_ptr);
        var KO = GO(OO[0], OO[1]).slice();
        return fK.frSG(OO[0], 8 * OO[1], 8), KO
      }
      hK() {
        return fK.zKBZ(this.__wbg_ptr) >>> 0
      }
      DK() {
        return fK.CA2Y(this.__wbg_ptr) >>> 0
      }
      MK() {
        return fK.A43W(this.__wbg_ptr) >>> 0
      }
      constructor(OO, KO, pO, XO, bK, eO, lO, vK) {
        const CO = fK.wLhb(OO, KO, pO, XO, bK, eO, lO, vK);
        if (CO[2]) throw oK(CO[1]);
        return this.__wbg_ptr = CO[0], sO.register(this, this.__wbg_ptr, this), this
      }
      FK(OO) {
        ZO(OO, bK);
        const KO = fK.J45c(this.__wbg_ptr, OO.__wbg_ptr);
        if (KO[2]) throw oK(KO[1]);
        return KO[0] >>> 0
      }
      VK(OO) {
        const KO = fK.jblX(this.__wbg_ptr, OO);
        if (KO[1]) throw oK(KO[0])
      }
      LK() {
        return fK.NHxT(this.__wbg_ptr) >>> 0
      }
      resume(OO, KO) {
        ZO(OO, CO), ZO(KO, bK);
        const pO = fK.IFo6(this.__wbg_ptr, OO.__wbg_ptr, KO.__wbg_ptr);
        if (pO[2]) throw oK(pO[1]);
        return pO[0] >>> 0
      }
      dK(OO) {
        const KO = fK.cA6D(this.__wbg_ptr, OO);
        if (KO[1]) throw oK(KO[0])
      }
      IK(OO, KO) {
        ZO(KO, bK);
        const pO = fK.n3DN(this.__wbg_ptr, OO, KO.__wbg_ptr);
        if (pO[1]) throw oK(pO[0])
      }
      EK(OO) {
        const KO = MK(OO, fK.TEiC),
          pO = dK,
          XO = fK.Z9FK(this.__wbg_ptr, KO, pO);
        if (XO[1]) throw oK(XO[0])
      }
      bp(OO, KO, pO, XO, bK, eO) {
        const lO = fK.thq7(this.__wbg_ptr, OO, KO, pO, XO, bK, eO);
        if (lO[1]) throw oK(lO[0])
      }
      eK(OO, KO, pO, XO) {
        const bK = hK(OO, fK.TEiC),
          eO = dK,
          lO = MK(KO, fK.TEiC),
          vK = dK,
          CO = MK(pO, fK.TEiC),
          hO = dK,
          DO = MK(XO, fK.TEiC),
          MO = dK,
          aK = fK.u0L7(this.__wbg_ptr, bK, eO, lO, vK, CO, hO, DO, MO);
        if (aK[1]) throw oK(aK[0])
      }
      YK(OO, KO) {
        ZO(KO, bK);
        const pO = fK.YQJv(this.__wbg_ptr, OO, KO.__wbg_ptr);
        if (pO[1]) throw oK(pO[0])
      }
      oK(OO, KO, pO) {
        const XO = fK.mThx(this.__wbg_ptr, OO, KO, pO);
        if (XO[1]) throw oK(XO[0])
      }
      ip(OO, KO, pO, XO, bK, eO, lO, vK, hO, DO) {
        ZO(OO, CO);
        return fK.ekbi(this.__wbg_ptr, OO.__wbg_ptr, KO, pO, XO, bK, eO, lO, vK, hO, DO)
      }
    }
    Symbol.dispose && (vK.prototype[Symbol.dispose] = vK.prototype.free);
    class CO {
      static __wrap(OO) {
        const KO = Object.create(CO.prototype);
        return KO.__wbg_ptr = OO, HO.register(KO, KO.__wbg_ptr, KO), KO
      }
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, HO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        fK.RjPd(OO, 0)
      }
      mp(OO) {
        const KO = fK.O8AE(this.__wbg_ptr, OO);
        if (KO[2]) throw oK(KO[1]);
        return KO[0] >>> 0
      }
      sK(OO, KO, pO) {
        return fK.cNsz(this.__wbg_ptr, OO, KO, pO)
      }
      HK(OO, KO, pO) {
        return fK.jxKU(this.__wbg_ptr, OO, KO, pO) >>> 0
      }
      RK(OO, KO, pO, XO) {
        return 0 !== fK.w1sh(this.__wbg_ptr, OO, KO, pO, XO)
      }
      SK() {
        fK.f30K(this.__wbg_ptr)
      }
      BK(OO) {
        const KO = fK.E40R(this.__wbg_ptr, OO);
        if (KO[3]) throw oK(KO[2]);
        var pO = xK(KO[0], KO[1]).slice();
        return fK.frSG(KO[0], 1 * KO[1], 1), pO
      }
      evict(OO, KO) {
        return fK.E9F2(this.__wbg_ptr, OO, KO) >>> 0
      }
      ZK() {
        fK.qosq(this.__wbg_ptr)
      }
      GK(OO, KO, pO) {
        fK.yF1V(this.__wbg_ptr, OO, KO, pO)
      }
      qp(OO) {
        const KO = fK.kZRZ(this.__wbg_ptr, OO);
        if (KO[1]) throw oK(KO[0])
      }
      xp() {
        return fK.P4S7(this.__wbg_ptr) >>> 0
      }
      nK() {
        return fK.iMnb(this.__wbg_ptr) >>> 0
      }
      WK(OO, KO, pO) {
        fK.twOX(this.__wbg_ptr, OO, KO, pO)
      }
      tp(OO, KO, pO) {
        fK.Zh0a(this.__wbg_ptr, OO, KO, pO)
      }
      kp() {
        return fK.kSjz(this.__wbg_ptr) >>> 0
      }
      UK() {
        return fK.j5Ae(this.__wbg_ptr) >>> 0
      }
      constructor() {
        const OO = fK.dHdQ();
        return this.__wbg_ptr = OO, HO.register(this, this.__wbg_ptr, this), this
      }
      static Op() {
        const OO = fK.jTg8();
        return CO.__wrap(OO)
      }
      Kp() {
        return fK.FEnG(this.__wbg_ptr) >>> 0
      }
      Xp() {
        return fK.EAIu(this.__wbg_ptr) >>> 0
      }
      bX(OO, KO, pO, XO) {
        const bK = fK.xa6h(this.__wbg_ptr, OO, KO, pO, XO);
        if (bK[1]) throw oK(bK[0])
      }
      lp() {
        return fK.Nhua(this.__wbg_ptr) >>> 0
      }
      vX() {
        return fK.CeBo(this.__wbg_ptr) >>> 0
      }
      Cp(OO, KO, pO, XO) {
        fK.iZXi(this.__wbg_ptr, OO, KO, pO, XO)
      }
      hp(OO) {
        fK.eOhm(this.__wbg_ptr, OO)
      }
      Mp(OO, KO, pO, XO, bK) {
        const eO = DK(KO, fK.TEiC),
          lO = dK,
          vK = hK(pO, fK.TEiC),
          CO = dK,
          hO = MK(XO, fK.TEiC),
          DO = dK,
          MO = fK.qQId(this.__wbg_ptr, OO, eO, lO, vK, CO, hO, DO, bK);
        if (MO[1]) throw oK(MO[0])
      }
      Dp(OO, KO, pO, XO) {
        const bK = DK(OO, fK.TEiC),
          eO = dK,
          lO = hK(KO, fK.TEiC),
          vK = dK,
          CO = MK(pO, fK.TEiC),
          hO = dK,
          DO = DK(XO, fK.TEiC),
          MO = dK,
          aK = fK.fB1P(this.__wbg_ptr, bK, eO, lO, vK, CO, hO, DO, MO);
        if (aK[1]) throw oK(aK[0])
      }
      zX(OO) {
        const KO = DK(OO, fK.TEiC),
          pO = dK,
          XO = fK.RE0Z(this.__wbg_ptr, KO, pO);
        if (XO[1]) throw oK(XO[0])
      }
      Ap() {
        return fK.uV1D(this.__wbg_ptr) >>> 0
      }
      dp(OO) {
        const KO = fK.RlGR(this.__wbg_ptr, OO);
        if (KO[2]) throw oK(KO[1]);
        return KO[0] >>> 0
      }
      steer() {
        return fK.WZLy(this.__wbg_ptr) >>> 0
      }
      Tp() {
        const OO = fK.oPUM(this.__wbg_ptr);
        var KO = GO(OO[0], OO[1]).slice();
        return fK.frSG(OO[0], 8 * OO[1], 8), KO
      }
      Np() {
        return fK.QWqG(this.__wbg_ptr) >>> 0
      }
      zp() {
        const OO = fK.LSQT(this.__wbg_ptr);
        var KO, pO, XO = (KO = OO[0], pO = OO[1], KO >>>= 0, (null !== tK && 0 !== tK.byteLength || (tK = new Int32Array(fK.memory.buffer)), tK).subarray(KO / 4, KO / 4 + pO)).slice();
        return fK.frSG(OO[0], 4 * OO[1], 4), XO
      }
    }
    Symbol.dispose && (CO.prototype[Symbol.dispose] = CO.prototype.free);
    class hO {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, RO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        fK.dX11(OO, 0)
      }
      Ip(OO) {
        const KO = hK(OO, fK.TEiC),
          pO = dK,
          XO = fK.ywi7(this.__wbg_ptr, KO, pO);
        if (XO[1]) throw oK(XO[0])
      }
      yX() {
        return fK.YR9A(this.__wbg_ptr) >>> 0
      }
      gX() {
        return fK.w8Cy(this.__wbg_ptr) >>> 0
      }
      constructor() {
        const OO = fK.oqQM();
        return this.__wbg_ptr = OO, RO.register(this, this.__wbg_ptr, this), this
      }
      run(OO, KO) {
        ZO(OO, CO);
        const pO = fK.w2Y1(this.__wbg_ptr, OO.__wbg_ptr, KO);
        if (pO[2]) throw oK(pO[1]);
        return pO[0] >>> 0
      }
      upO(OO) {
        const KO = hK(OO, fK.TEiC),
          pO = dK;
        fK.LRcK(this.__wbg_ptr, KO, pO)
      }
      Ep(OO) {
        const KO = hK(OO, fK.TEiC),
          pO = dK;
        fK.EjZH(this.__wbg_ptr, KO, pO)
      }
    }
    Symbol.dispose && (hO.prototype[Symbol.dispose] = hO.prototype.free);
    class DO {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, SO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        fK.bnpr(OO, 0)
      }
      Yp(OO, KO) {
        const pO = DK(OO, fK.TEiC),
          XO = dK;
        return fK.gw5S(this.__wbg_ptr, pO, XO, KO) >>> 0
      }
      wp(OO, KO, pO) {
        ZO(OO, CO);
        const XO = DK(pO, fK.TEiC),
          bK = dK,
          eO = fK.x9jF(this.__wbg_ptr, OO.__wbg_ptr, KO, XO, bK);
        if (eO[2]) throw oK(eO[1]);
        return eO[0] >>> 0
      }
      jX(OO) {
        return fK.lAvY(this.__wbg_ptr, OO) >>> 0
      }
      constructor() {
        const OO = fK.t55K();
        return this.__wbg_ptr = OO, SO.register(this, this.__wbg_ptr, this), this
      }
      scan(OO, KO) {
        ZO(OO, CO);
        const pO = fK.v8Yl(this.__wbg_ptr, OO.__wbg_ptr, KO);
        if (pO[2]) throw oK(pO[1]);
        return pO[0] >>> 0
      }
      Pp(OO) {
        const KO = DK(OO, fK.TEiC),
          pO = dK;
        fK.OaUO(this.__wbg_ptr, KO, pO)
      }
      rX() {
        return fK.h0h5(this.__wbg_ptr) >>> 0
      }
      iX() {
        return fK.Pmho(this.__wbg_ptr) >>> 0
      }
    }
    Symbol.dispose && (DO.prototype[Symbol.dispose] = DO.prototype.free);
    class MO {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, JO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        fK.bgxt(OO, 0)
      }
      sp(OO) {
        const KO = fK.O24Y(this.__wbg_ptr, OO);
        if (KO[2]) throw oK(KO[1]);
        return KO[0] >>> 0
      }
      compute(OO, KO, pO, XO) {
        var bK = vp(XO) ? 0 : ap(XO, fK.TEiC, fK.yQEo),
          eO = dK;
        const lO = fK.VOEI(this.__wbg_ptr, OO, vp(KO) ? Number.MAX_SAFE_INTEGER : KO | 0, pO, bK, eO);
        if (lO[2]) throw oK(lO[1]);
        return lO[0] >>> 0
      }
      Rp(OO) {
        const KO = ap(OO, fK.TEiC, fK.yQEo),
          pO = dK;
        fK.kgKC(this.__wbg_ptr, KO, pO)
      }
      Jp() {
        return fK.cFqg(this.__wbg_ptr)
      }
      cX(OO) {
        return fK.hMon(this.__wbg_ptr, OO) >>> 0
      }
      Bp() {
        return fK.RRTp(this.__wbg_ptr) >>> 0
      }
      Zp() {
        return fK.PaGj(this.__wbg_ptr) >>> 0
      }
      Gp(OO, KO) {
        const pO = fK.Si34(this.__wbg_ptr, OO, KO);
        if (pO[1]) throw oK(pO[0])
      }
      xX() {
        return fK.O1z1(this.__wbg_ptr) >>> 0
      }
      np() {
        return fK.aNiR(this.__wbg_ptr) >>> 0
      }
      Wp() {
        return fK.SjLH(this.__wbg_ptr) >>> 0
      }
      Hp(OO, KO, pO) {
        const XO = hK(OO, fK.TEiC),
          bK = dK,
          eO = hK(KO, fK.TEiC),
          lO = dK,
          vK = fK.hQh2(this.__wbg_ptr, XO, bK, eO, lO, pO);
        if (vK[1]) throw oK(vK[0])
      }
      kX() {
        return fK.MsVB(this.__wbg_ptr) >>> 0
      }
      mesh(OO, KO, pO, XO, bK) {
        const eO = fK.yurA(this.__wbg_ptr, OO, KO, pO, XO, bK);
        if (eO[2]) throw oK(eO[1]);
        return eO[0] >>> 0
      }
      constructor(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO, QO, zK, AO) {
        const fO = CK(OO, fK.TEiC),
          dO = dK,
          TO = MK(KO, fK.TEiC),
          NO = dK,
          IO = hK(pO, fK.TEiC),
          yK = dK,
          gK = DK(XO, fK.TEiC),
          uO = dK,
          EO = DK(bK, fK.TEiC),
          jK = dK,
          YO = hK(eO, fK.TEiC),
          wO = dK,
          iK = hK(lO, fK.TEiC),
          rK = dK,
          PO = MK(vK, fK.TEiC),
          mK = dK,
          sO = MK(CO, fK.TEiC),
          HO = dK,
          RO = DK(hO, fK.TEiC),
          SO = dK;
        var cK = vp(DO) ? 0 : CK(DO, fK.TEiC),
          BO = dK;
        const ZO = hK(MO, fK.TEiC),
          GO = dK,
          qK = DK(aK, fK.TEiC),
          xK = dK;
        var nO = vp(oO) ? 0 : DK(oO, fK.TEiC),
          WO = dK;
        const tK = MK(FO, fK.TEiC),
          kK = dK,
          UO = fK.a0bG(fO, dO, TO, NO, IO, yK, gK, uO, EO, jK, YO, wO, iK, rK, PO, mK, sO, HO, RO, SO, cK, BO, ZO, GO, qK, xK, nO, WO, tK, kK, VO, LO, QO, zK, AO);
        if (UO[2]) throw oK(UO[1]);
        return this.__wbg_ptr = UO[0], JO.register(this, this.__wbg_ptr, this), this
      }
      tX(OO, KO) {
        const pO = hK(OO, fK.TEiC),
          XO = dK,
          bK = fK.HFT6(this.__wbg_ptr, pO, XO, KO);
        if (bK[3]) throw oK(bK[2]);
        var eO = xK(bK[0], bK[1]).slice();
        return fK.frSG(bK[0], 1 * bK[1], 1), eO
      }
      Up(OO) {
        fK.w7DT(this.__wbg_ptr, vp(OO) ? 16777215 : OO)
      }
      OX(OO) {
        return fK.yLWM(this.__wbg_ptr, OO) >>> 0
      }
      pX() {
        return fK.yyHD(this.__wbg_ptr) >>> 0
      }
      KX() {
        const OO = fK.On0F(this.__wbg_ptr);
        if (OO[2]) throw oK(OO[1]);
        return 0 !== OO[0]
      }
      XX() {
        return fK.mv5M(this.__wbg_ptr) >>> 0
      }
      bb() {
        return fK.sFQD(this.__wbg_ptr) >>> 0
      }
    }
    Symbol.dispose && (MO.prototype[Symbol.dispose] = MO.prototype.free);
    class aK {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, cK.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        fK.MsmN(OO, 0)
      }
      compute(OO, KO, pO, XO) {
        var bK = vp(XO) ? 0 : ap(XO, fK.TEiC, fK.yQEo),
          eO = dK;
        const lO = fK.w6E5(this.__wbg_ptr, OO, vp(KO) ? Number.MAX_SAFE_INTEGER : KO | 0, pO, bK, eO);
        if (lO[2]) throw oK(lO[1]);
        return lO[0] >>> 0
      }
      Rp(OO) {
        const KO = ap(OO, fK.TEiC, fK.yQEo),
          pO = dK;
        fK.y9Kr(this.__wbg_ptr, KO, pO)
      }
      np() {
        return fK.igXN(this.__wbg_ptr) >>> 0
      }
      Wp() {
        return fK.pZDN(this.__wbg_ptr) >>> 0
      }
      eX(OO) {
        const KO = fK.Q4rD(this.__wbg_ptr, OO);
        if (KO[2]) throw oK(KO[1]);
        return KO[0] >>> 0
      }
      constructor(OO, KO, pO, XO, bK, eO) {
        const lO = CK(OO, fK.TEiC),
          vK = dK,
          CO = MK(KO, fK.TEiC),
          hO = dK,
          DO = hK(pO, fK.TEiC),
          MO = dK,
          aK = DK(XO, fK.TEiC),
          oO = dK,
          FO = fK.aFqQ(lO, vK, CO, hO, DO, MO, aK, oO, bK, eO);
        if (FO[2]) throw oK(FO[1]);
        return this.__wbg_ptr = FO[0], cK.register(this, this.__wbg_ptr, this), this
      }
      pX() {
        return fK.XxD8(this.__wbg_ptr) >>> 0
      }
      KX() {
        const OO = fK.p6E8(this.__wbg_ptr);
        if (OO[2]) throw oK(OO[1]);
        return 0 !== OO[0]
      }
      XX() {
        return fK.QEZE(this.__wbg_ptr) >>> 0
      }
    }

    function oO() {
      const OO = fK.dPxu();
      var KO = qK(OO[0], OO[1]).slice();
      return fK.frSG(OO[0], 4 * OO[1], 4), KO
    }

    function FO(OO, KO) {
      let pO, XO;
      try {
        const bK = CK(OO, fK.TEiC),
          eO = dK,
          lO = ap(KO, fK.TEiC, fK.yQEo),
          vK = dK,
          CO = fK.VLxy(bK, eO, lO, vK);
        return pO = CO[0], XO = CO[1], kK(CO[0], CO[1])
      } finally {
        fK.frSG(pO, XO, 1)
      }
    }

    function VO() {
      const OO = fK.rSeO();
      var KO = qK(OO[0], OO[1]).slice();
      return fK.frSG(OO[0], 4 * OO[1], 4), KO
    }

    function LO(OO) {
      return 0 !== fK.doyc(OO)
    }

    function QO(OO, KO) {
      const pO = ap(OO, fK.TEiC, fK.yQEo),
        XO = dK,
        bK = fK.PjCO(pO, XO, KO);
      if (bK[1]) throw oK(bK[0])
    }

    function zK() {
      fK.tMaY()
    }

    function AO() {
      return fK.j1U6() >>> 0
    }

    function fO(OO) {
      return 0 !== fK.QnU9(OO)
    }

    function dO(OO) {
      return 0 !== fK.CICF(OO)
    }

    function TO(OO) {
      fK.HbtL(OO)
    }

    function NO() {
      return fK.n8H4() >>> 0
    }

    function IO() {
      return fK.BYkg() >>> 0
    }

    function yK() {
      return 0 !== fK.uKkD()
    }

    function gK() {
      const OO = fK.SVjQ();
      var KO = qK(OO[0], OO[1]).slice();
      return fK.frSG(OO[0], 4 * OO[1], 4), KO
    }

    function uO() {
      const OO = fK.va5g();
      var KO = qK(OO[0], OO[1]).slice();
      return fK.frSG(OO[0], 4 * OO[1], 4), KO
    }

    function EO() {
      const OO = fK.tkOe();
      var KO = qK(OO[0], OO[1]).slice();
      return fK.frSG(OO[0], 4 * OO[1], 4), KO
    }

    function jK() {
      return fK.jquX() >>> 0
    }

    function YO() {
      fK.mfW6()
    }

    function wO() {
      let OO, KO;
      try {
        const pO = fK.z81v();
        return OO = pO[0], KO = pO[1], kK(pO[0], pO[1])
      } finally {
        fK.frSG(OO, KO, 1)
      }
    }

    function iK(OO) {
      fK.BIF8(BO(OO))
    }

    function rK() {
      return {
        __proto__: null,
        XaB9: {
          __proto__: null,
          owbD: function(OO, KO) {
            return BO(Error(kK(OO, KO)))
          },
          VOMv: function(OO, KO) {
            throw new Error(kK(OO, KO))
          },
          FIod: function(OO) {
            bp(OO).call()
          },
          Yzck: function(OO, KO) {
            console.error(kK(OO, KO))
          },
          zmEl: function() {
            return performance.now()
          },
          KxWm: function(OO) {
            oK(OO)
          }
        }
      }
    }
    Symbol.dispose && (aK.prototype[Symbol.dispose] = aK.prototype.free);
    const PO = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => fK.NcP5(OO, 1))),
      mK = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => fK.DrP3(OO, 1))),
      sO = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => fK.gNZm(OO, 1))),
      HO = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => fK.RjPd(OO, 1))),
      RO = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => fK.dX11(OO, 1))),
      SO = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => fK.bnpr(OO, 1))),
      JO = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => fK.bgxt(OO, 1))),
      cK = "undefined" === typeof FinalizationRegistry ? {
        register: () => {},
        unregister: () => {}
      } : new FinalizationRegistry((OO => fK.MsmN(OO, 1)));

    function BO(OO) {
      lK === eK.length && eK.push(eK.length + 1);
      const KO = lK;
      return lK = eK[KO], eK[KO] = OO, KO
    }

    function ZO(OO, KO) {
      if (!(OO instanceof KO)) throw new Error(`expected instance of ${KO.name}`)
    }

    function GO(OO, KO) {
      return OO >>>= 0, WO().subarray(OO / 8, OO / 8 + KO)
    }

    function qK(OO, KO) {
      return OO >>>= 0, KK().subarray(OO / 4, OO / 4 + KO)
    }

    function xK(OO, KO) {
      return OO >>>= 0, XK().subarray(OO / 1, OO / 1 + KO)
    }
    let nO = null;

    function WO() {
      return null !== nO && 0 !== nO.byteLength || (nO = new Float64Array(fK.memory.buffer)), nO
    }
    let tK = null;

    function kK(OO, KO) {
      return function(OO, KO) {
        LK += KO, LK >= VK && (FK = new TextDecoder("utf-8", {
          ignoreBOM: !0,
          fatal: !0
        }), FK.decode(), LK = KO);
        return FK.decode(XK().subarray(OO, OO + KO))
      }(OO >>> 0, KO)
    }
    let UO = null;
    let OK = null;

    function KK() {
      return null !== OK && 0 !== OK.byteLength || (OK = new Uint32Array(fK.memory.buffer)), OK
    }
    let pK = null;

    function XK() {
      return null !== pK && 0 !== pK.byteLength || (pK = new Uint8Array(fK.memory.buffer)), pK
    }

    function bp(OO) {
      return eK[OO]
    }
    let eK = new Array(1024).fill(void 0);
    eK.push(void 0, null, !0, !1);
    let lK = eK.length;

    function vp(OO) {
      return void 0 === OO || null === OO
    }

    function CK(OO, KO) {
      const pO = KO(2 * OO.length, 2) >>> 0;
      return (null !== UO && 0 !== UO.byteLength || (UO = new Uint16Array(fK.memory.buffer)), UO).set(OO, pO / 2), dK = OO.length, pO
    }

    function hK(OO, KO) {
      const pO = KO(4 * OO.length, 4) >>> 0;
      return KK().set(OO, pO / 4), dK = OO.length, pO
    }

    function DK(OO, KO) {
      const pO = KO(1 * OO.length, 1) >>> 0;
      return XK().set(OO, pO / 1), dK = OO.length, pO
    }

    function MK(OO, KO) {
      const pO = KO(8 * OO.length, 8) >>> 0;
      return WO().set(OO, pO / 8), dK = OO.length, pO
    }

    function ap(OO, KO, pO) {
      if (void 0 === pO) {
        const pO = QK.encode(OO),
          XO = KO(pO.length, 1) >>> 0;
        return XK().subarray(XO, XO + pO.length).set(pO), dK = pO.length, XO
      }
      let XO = OO.length,
        bK = KO(XO, 1) >>> 0;
      const eO = XK();
      let lO = 0;
      for (; lO < XO; lO++) {
        const KO = OO.charCodeAt(lO);
        if (KO > 127) break;
        eO[bK + lO] = KO
      }
      if (lO !== XO) {
        0 !== lO && (OO = OO.slice(lO)), bK = pO(bK, XO, XO = lO + 3 * OO.length, 1) >>> 0;
        const KO = XK().subarray(bK + lO, bK + XO);
        lO += QK.encodeInto(OO, KO).written, bK = pO(bK, XO, lO, 1) >>> 0
      }
      return dK = lO, bK
    }

    function oK(OO) {
      const KO = bp(OO);
      return function(OO) {
        OO < 1028 || (eK[OO] = lK, lK = OO)
      }(OO), KO
    }
    let FK = new TextDecoder("utf-8", {
      ignoreBOM: !0,
      fatal: !0
    });
    FK.decode();
    const VK = 2146435072;
    let LK = 0;
    const QK = new TextEncoder;
    "encodeInto" in QK || (QK.encodeInto = function(OO, KO) {
      const pO = QK.encode(OO);
      return KO.set(pO), {
        read: OO.length,
        written: pO.length
      }
    });
    let zp, AK, fK, dK = 0;

    function TK(OO, KO) {
      return AK = OO, fK = OO.exports, zp = KO, nO = null, tK = null, UO = null, OK = null, pK = null, fK.Yesr(), fK
    }

    function NK(OO) {
      if (void 0 !== fK) return fK;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module: OO
      } = OO) : console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));
      const KO = rK();
      OO instanceof WebAssembly.Module || (OO = new WebAssembly.Module(OO));
      return TK(new WebAssembly.Instance(OO, KO), OO)
    }
    async function IK(OO) {
      if (void 0 !== fK) return fK;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module_or_path: OO
      } = OO) : console.warn("using deprecated parameters for the initialization function; pass a single object instead"));
      const KO = rK();
      ("string" === typeof OO || "function" === typeof Request && OO instanceof Request || "function" === typeof URL && OO instanceof URL) && (OO = fetch(OO));
      const {
        instance: pO,
        module: XO
      } = await async function(OO, KO) {
        if ("function" === typeof Response && OO instanceof Response) {
          if (!OO.ok) throw new Error(`failed to fetch Wasm: ${OO.status} ${OO.statusText} fetching '${OO.url}'`);
          if ("function" === typeof WebAssembly.instantiateStreaming) try {
            return await WebAssembly.instantiateStreaming(OO, KO)
          } catch (pO) {
            if (! function(OO) {
                switch (OO) {
                  case "basic":
                  case "cors":
                  case "default":
                    return !0
                }
                return !1
              }(OO.type) || "application/wasm" === OO.headers.get("Content-Type")) throw pO;
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", pO)
          }
          const XO = await OO.arrayBuffer();
          return await WebAssembly.instantiate(XO, KO)
        } {
          const pO = await WebAssembly.instantiate(OO, KO);
          return pO instanceof WebAssembly.Instance ? {
            instance: pO,
            module: OO
          } : pO
        }
      }(await OO, KO);
      return TK(pO, XO)
    }
    var yp = pO(2947),
      gp = pO(34910);
    const uK = {
      name: yp.c,
      url: () => new pO.U(pO(34914)),
      init: IK,
      MX: XO
    };

    function EK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : uK,
        KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : uK,
        pO = arguments.length > 2 ? arguments[2] : void 0;
      return (0, gp.h)(OO, KO, pO)
    }

    function jp(OO) {
      return (0, yp.N)((() => OO), XO, uK)
    }
  },
  5747: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(2951);
    const bK = {
      bloxd_wasm: () => "ac9f597375b38c338329c51c36d32b24f862e44eebff0f4b8070bfff0ce24e92",
      bloxd_wasm_client: () => "e981deecce97c0a28139db7f8c487a2f1f307b3295318edfa657ecf781f0bce4",
      bloxd_wasm_workers: () => "11a4c5ee562d561d1a564ae8ce4086cba4f264a242fa24e0ae9cdfd0bb313186",
      bloxd_wasm_models: () => "bee0165155b97fd136a7cf0dedea22e1a110c87d8e70a67ca6e7edc58b55e8c7",
      bloxd_wasm_webgpu: () => "4b4c96cc3f4d3f9fc4a3ff616e4c50aa2c87d4131077e77b476abf6704ec291f",
      bloxd_wasm_webgl: () => "c0bb33a3813b8b5918333de6d7e2622ae319a2c772f31975c56b5febf114b7c8",
      bloxd_wasm_webgl1: () => "971c025c2fdfbded0d795677b38da6ca90549b67af60539fae327208414e3132",
      bloxd_wasm_replay: () => "0cb774dff0a4b55ce86f8d87aef4bc59eda1d7a7c4e4115b219a9e7a09e651bf",
      bloxd_wasm_recorder: () => "82c26252e3c6033837d798c44d8bb77c08b2a095b569b6a2ed41666d348b5fa6",
      bloxd_wasm_anim: () => "fc31b88580a805317f744c8d79a3dc71a8b7a05a63ab0e8adfe930888a0cdb3e",
      bloxd_wasm_textures: () => "faf92bedf683183467afa4b668afe838fc10ad79c6cbb331d3174649bb18c10f",
      bloxd_wasm_shader_pack: () => "6cae04de4f8b271d5581ecd7685547570539fb61ec6bee0be5bb136267b6d774"
    };
    var eO = pO(5754);

    function lO(OO) {
      const KO = Object.prototype.hasOwnProperty.call(bK, OO) ? bK[OO]() : void 0;
      if (void 0 !== KO) return {
        sha256: KO,
        onMismatch: eO.v
      };
      throw new XO.l(`${OO} has no release digest, so this build refuses it`)
    }
  },
  34893: (OO, KO, pO) => {
    function XO(OO, KO) {
      return new Error(`${OO}: ${KO instanceof Error?`${KO.name}: ${KO.message}`:String(KO)}`, {
        cause: KO
      })
    }
    pO.d(KO, {
      e: () => XO
    })
  },
  34888: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      g: () => CO
    });
    var XO = pO(2951),
      bK = pO(5747),
      eO = pO(34893);

    function lO() {
      return new URL(new pO.U(pO(34897)).href, globalThis.location?.href).href
    }
    let vK = null;

    function CO() {
      return vK ??= (async () => (0, XO.x)(new URL(lO()), (0, bK.e)("bloxd_wasm_textures")))().catch((OO => {
        throw (0, eO.e)((0, XO.z)(OO), OO)
      })), vK
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);