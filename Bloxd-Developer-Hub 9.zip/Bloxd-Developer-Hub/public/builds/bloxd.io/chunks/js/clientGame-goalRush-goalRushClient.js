export const id = 17;
export const ids = [17];
export const modules = {
  37656: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => bK
    });
    const XO = .4,
      bK = function(OO, KO, pO, bK) {
        let eO, {
            localPlayerId: lO
          } = bK,
          vK = !1,
          CO = null,
          hO = null,
          DO = null,
          MO = 1,
          aK = null,
          oO = 0,
          FO = 0;

        function VO() {
          if (aK) {
            const OO = aK;
            OO.fade(OO.getVolume(), 0, 500), setTimeout((() => {
              OO.stop()
            }), 500), aK = null
          }
          FO = 0
        }

        function LO(OO) {
          var KO;
          if (!CO || vK || null === hO) return void(aK && VO());
          const pO = Date.now();
          if (!aK || pO - oO > 54e3) {
            if (aK) {
              const OO = aK;
              OO.fade(OO.getVolume(), 0, 2e3), setTimeout((() => {
                OO.stop()
              }), 2e3)
            }
            aK = eO.playSound(lO, "crowdAmbience", XO, 1), oO = pO, FO = XO
          }
          const bK = function() {
              if (null === hO || null === DO || !CO) return 0;
              const OO = eO.getPositionView(CO);
              if (!OO) return 0;
              const KO = Math.abs(OO[2] - hO),
                pO = Math.abs(OO[2] - DO),
                XO = Math.min(KO, pO);
              return Math.max(0, 1 - XO / MO)
            }(),
            LO = OO / 1e3;
          FO += (XO + .6 * bK - FO) * Math.min(1, 2 * LO), null === (KO = aK) || void 0 === KO || KO.setRelativeVolume(FO)
        }
        return {
          onCreate: OO => {
            eO = OO
          },
          onReceivedMessageFromServer: (OO, KO) => {
            var pO;
            "ballState" === OO ? (CO = null !== (pO = KO.eId) && void 0 !== pO ? pO : null, CO || VO()) : "frozen" === OO ? vK = KO.frozen : "pitchInfo" === OO && (hO = KO.goalZRed, DO = KO.goalZBlue, MO = Math.abs(DO - hO) / 2)
          },
          KK: OO => {
            LO(OO)
          }
        }
      }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);