export const id = 342;
export const ids = [342];
export const modules = {
  59162: (OO, KO, pO) => {
    pO.d(KO, {
      createShadowTask: () => eO
    });
    var XO = null;

    function bK(OO) {
      return XO?.get(OO)
    }

    function eO(OO, KO) {
      const pO = new Set;
      0;
      const XO = {
        name: "ab",
        engine: OO,
        Ce: KO,
        _passes: [],
        async _preload() {
          const OO = [];
          for (const pO of KO.lights) {
            const KO = pO.shadowGenerator,
              XO = KO ? bK(KO) : null;
            KO?._preloadShadowTask && XO && OO.push(lO(KO, XO))
          }
          await Promise.all(OO)
        },
        record() {
          XO._passes.length = 0;
          for (const XO of KO.lights) {
            const eO = XO.shadowGenerator,
              lO = eO ? bK(eO) : null;
            if (eO?._ensureShadowTaskState && lO && !eO._preloadPending) {
              pO.add(eO);
              const XO = eO._ensureShadowTaskState(OO, KO, lO),
                bK = KO._renderableVersion;
              XO._task.record(), XO._recordedVersion = bK
            }
          }
        },
        execute() {
          let XO = 0;
          for (const eO of KO.lights) {
            const lO = eO.shadowGenerator,
              vK = lO ? bK(lO) : null;
            if (lO?._ensureShadowTaskState && lO._renderShadowMap && vK && !lO._preloadPending) {
              pO.add(lO);
              const bK = lO._shadowTaskState ?? null,
                eO = lO._ensureShadowTaskState(OO, KO, vK);
              if (eO !== bK || eO._recordedVersion !== KO._renderableVersion) {
                const OO = KO._renderableVersion;
                eO._task.record(), eO._recordedVersion = OO
              }
              XO += lO._renderShadowMap(OO, eO)
            }
          }
          return XO
        },
        dispose() {
          XO._passes.length = 0;
          for (const OO of pO) {
            const KO = OO._shadowTaskState;
            KO && (KO._task.dispose(), OO._shadowTaskState = void 0)
          }
          pO.clear()
        }
      };
      return XO
    }
    async function lO(OO, KO) {
      OO._preloadPending = KO, await (OO._preloadShadowTask?.(KO)), OO._preloadPending === KO && (OO._preloadPending = void 0)
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);