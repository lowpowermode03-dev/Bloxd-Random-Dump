export const id = 185;
export const ids = [185];
export const modules = {
  32997: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      packDisplayName: () => FO,
      packModelMessage: () => VO,
      packModelSummary: () => QO,
      refusedPackModels: () => LO
    });
    var XO = pO(33001),
      bK = pO(33003);
    const eO = "DRACO",
      lO = 0,
      vK = 1,
      CO = 0,
      hO = 1,
      DO = 32768;

    function MO(OO) {
      const KO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength);
      let pO = 0;
      const XO = () => {
          if (pO >= OO.byteLength) throw new RangeError("past the stream");
          return OO[pO++]
        },
        bK = () => {
          if (pO + 4 > OO.byteLength) throw new RangeError("past the stream");
          const XO = KO.getUint32(pO, !0);
          return pO += 4, XO
        },
        MO = () => {
          let OO = 0;
          for (let KO = 0; KO < 35; KO += 7) {
            const pO = XO();
            if (OO += (127 & pO) * 2 ** KO, 0 === (128 & pO)) return OO
          }
          throw new RangeError("varint too long")
        };
      try {
        for (let OO = 0; OO < eO.length; OO++)
          if (XO() !== eO.charCodeAt(OO)) return null;
        const KO = XO(),
          aK = XO(),
          oO = XO(),
          FO = XO(),
          VO = XO() | XO() << 8;
        if (2 !== KO) return null;
        0 !== (VO & DO) && function(OO, KO, pO) {
          const XO = () => {
              KO(pO())
            },
            bK = () => {
              let pO = 1,
                bK = !0;
              for (; pO > 0;) {
                pO--, bK || XO(), bK = !1;
                const eO = OO();
                for (let pO = 0; pO < eO; pO++) XO(), KO(OO());
                pO += OO()
              }
            },
            eO = OO();
          for (let lO = 0; lO < eO; lO++) OO(), bK();
          bK()
        }(MO, (KO => {
          if (pO + KO > OO.byteLength) throw new RangeError("past the stream");
          pO += KO
        }), XO);
        const LO = aK < 2 ? bK : MO;
        if (oO === lO) return {
          faces: 0,
          vertices: bK()
        };
        if (oO !== vK) return null;
        if (FO === CO) {
          return {
            faces: LO(),
            vertices: LO()
          }
        }
        if (FO !== hO) return null;
        XO(), aK < 2 && MO();
        const QO = MO();
        return {
          faces: MO(),
          vertices: QO
        }
      } catch {
        return null
      }
    }

    function aK(OO, KO, pO) {
      var XO, bK;
      if (null === (XO = null === (bK = OO.extensionsUsed) || void 0 === bK ? void 0 : bK.includes("KHR_draco_mesh_compression")) || void 0 === XO || !XO) return null;
      for (const FO of null !== (eO = OO.meshes) && void 0 !== eO ? eO : []) {
        var eO;
        for (const XO of FO.primitives) {
          var lO, vK, CO, hO, DO, aK;
          const bK = null === (lO = XO.extensions) || void 0 === lO ? void 0 : lO.KHR_draco_mesh_compression;
          if ("object" !== typeof bK || null === bK) continue;
          const eO = null === (vK = OO.bufferViews) || void 0 === vK ? void 0 : vK[bK.bufferView];
          if (null === KO || void 0 === eO) return oO;
          const FO = null !== (CO = eO.byteOffset) && void 0 !== CO ? CO : 0,
            VO = MO(KO.subarray(FO, FO + eO.byteLength));
          if (null === VO && !pO) continue;
          const LO = null !== (hO = OO.accessors) && void 0 !== hO ? hO : [],
            QO = null === (DO = LO[XO.attributes.POSITION]) || void 0 === DO ? void 0 : DO.count,
            zK = void 0 === XO.indices ? 0 : null === (aK = LO[XO.indices]) || void 0 === aK ? void 0 : aK.count;
          if (null === VO || void 0 === QO || void 0 === zK || 3 * VO.faces !== zK || VO.vertices > QO) return oO
        }
      }
      return null
    }
    const oO = "has a Draco stream whose counts don't match its accessors";

    function FO(OO) {
      var KO;
      return null !== (KO = OO.name) && void 0 !== KO ? KO : OO.fromFolderName || OO.id
    }

    function VO(OO, KO, pO) {
      return `Texture pack "${OO}": model "${KO}" was not loaded because it ${pO}. The default model is used instead.`
    }

    function LO(OO, KO, pO) {
      let {
        strictDraco: eO = !1
      } = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
      const lO = {};
      for (const [vK, CO] of Object.entries(KO)) {
        let KO;
        if (CO.startsWith("data:")) try {
          const OO = new Uint8Array((0, bK.p)(CO));
          if (KO = (0, XO.b)(OO), null === KO) {
            const {
              json: pO,
              bin: XO
            } = (0, bK.z)(OO);
            KO = aK(pO, XO, eO)
          }
        } catch {
          KO = "is not a binary glTF 2.0 file"
        } else KO = "loads data from outside the file";
        KO && (lO[vK] = KO, pO && console.warn(VO(OO, vK, KO)))
      }
      return lO
    }

    function QO(OO, KO) {
      const pO = Object.keys(KO);
      if (0 === pO.length) return null;
      if (1 === pO.length) return VO(OO, pO[0], KO[pO[0]]);
      const XO = pO.map((OO => `"${OO}" ${KO[OO]}`)).join("; ");
      return `Texture pack "${OO}": ${pO.length} models were not loaded (${XO}). The default models are used instead.`
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);