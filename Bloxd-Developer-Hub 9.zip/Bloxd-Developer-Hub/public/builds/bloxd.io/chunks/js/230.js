export const id = 230;
export const ids = [230];
export const modules = {
  37867: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      playDocsSound: () => vK
    });
    var XO = pO(3988),
      bK = pO(35264),
      eO = pO(1056);
    const lO = new Map;

    function vK(OO, KO, pO, vK, CO) {
      let hO, DO = null,
        MO = 0,
        aK = 0;
      if (KO) hO = new XO.Howl({
        src: [`${eO.clientSideServerUrls.staticUrl}/sounds/music/${OO}.mp3`],
        html5: !0,
        volume: pO
      });
      else {
        var oO;
        DO = (0, bK.g)(OO);
        const KO = (0, bK.f)(DO),
          pO = null !== (oO = KO.sprite[OO]) && void 0 !== oO ? oO : null;
        if (!pO) throw new Error(`Docs sound ${OO} is not in sprite sheet ${DO}`);
        MO = pO[0] / 1e3, aK = pO[1] / 1e3, hO = lO.get(DO), hO || (hO = new XO.Howl({
          ...KO,
          volume: 1
        }), lO.set(DO, hO))
      }
      const FO = KO ? hO.play() : hO.play(OO);
      hO.volume(pO, FO), vK > 0 && hO.seek(MO + vK, FO);
      const VO = () => KO ? hO.duration() : aK;
      let LO = !1;
      const QO = OO => {
          LO || (LO = !0, hO.off("play", zK, FO), hO.off("end", AO, FO), hO.off("loaderror", dO), hO.off("playerror", fO, FO), KO && hO.unload(), CO.onEnd(OO))
        },
        zK = () => {
          CO.onPlay(VO())
        },
        AO = () => {
          QO(!1)
        },
        fO = (KO, pO) => {
          console.error(`Could not play docs sound ${OO}`, pO), QO(!0)
        },
        dO = (OO, KO) => {
          null !== DO && lO.get(DO) === hO && (lO.delete(DO), hO.unload()), fO(OO, KO)
        };
      return hO.on("play", zK, FO), hO.once("end", AO, FO), hO.once("loaderror", dO), hO.once("playerror", fO, FO), {
        pause: () => {
          hO.pause(FO)
        },
        resume: () => {
          hO.play(FO)
        },
        seek: OO => {
          const KO = VO(),
            pO = Math.max(OO, 0);
          hO.seek(MO + (KO > 0 ? Math.min(pO, KO) : pO), FO)
        },
        fV: () => {
          const OO = hO.seek(FO);
          return "number" === typeof OO ? Math.max(0, OO - MO) : 0
        },
        getDuration: VO,
        setVolume: OO => {
          hO.volume(OO, FO)
        },
        stop: () => {
          LO || (hO.stop(FO), QO(!1))
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);