export const id = 251;
export const ids = [251];
export const modules = {
  39631: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => LO,
      e: () => vK,
      f: () => lO,
      j: () => hO
    });
    var XO = pO(35680),
      bK = pO(37085),
      eO = pO(37080);

    function lO(OO, KO, pO, XO) {
      const bK = eO.s;
      KO.fill(0), OO.gravity.toArray(KO, bK.gravity), OO.colorDead.toArray(KO, bK.colorDead), pO[bK.ramp] = OO.useRampGradients ? 1 : 0;
      const lO = OO.getColorGradients(),
        vK = aK(OO, lO, "colour", XO);
      pO[bK.colorCount] = vK;
      for (let eO = 0; eO < vK; eO++) {
        var CO;
        const OO = lO[oO(lO, eO)];
        KO[bK.colorPositions + eO] = OO.gradient, OO.color1.toArray(KO, bK.color1 + 4 * eO), (null !== (CO = OO.color2) && void 0 !== CO ? CO : OO.color1).toArray(KO, bK.color2 + 4 * eO)
      }
      const hO = OO.getVelocityGradients(),
        DO = aK(OO, hO, "ul", XO);
      pO[bK.velocityCount] = DO;
      for (let eO = 0; eO < DO; eO++) zK(KO, bK.ul + 4 * eO, hO[oO(hO, eO)]);
      const MO = OO.useRampGradients ? OO.getColorRemapGradients() : null,
        FO = aK(OO, MO, "colour remap", XO);
      pO[bK.remapCount] = FO;
      for (let eO = 0; eO < FO; eO++) zK(KO, bK.remap + 4 * eO, MO[oO(MO, eO)])
    }

    function vK() {
      return {
        key: [],
        texels: new Uint8Array(4 * eO.l)
      }
    }
    const CO = [];

    function hO(OO, KO) {
      return DO(OO, CO), !QO(CO, KO.key) && (KO.key.length = 0, KO.key.push(...CO), KO.key.length > 0 && function(OO, KO) {
        for (let pO = 0; pO < eO.l; pO++) bK.k.GetCurrentGradient(pO / eO.l, OO, ((OO, KO, pO) => {
          XO.Color3.LerpToRef(OO.color, KO.color, pO, MO)
        })), KO[4 * pO] = 255 * MO.r, KO[4 * pO + 1] = 255 * MO.g, KO[4 * pO + 2] = 255 * MO.b, KO[4 * pO + 3] = 255
      }(OO.getRampGradients(), KO.texels), !0)
    }

    function DO(OO, KO) {
      KO.length = 0;
      const pO = OO.useRampGradients ? OO.getRampGradients() : null;
      if (null !== pO && void 0 !== pO && pO.length) {
        KO.push(pO.length);
        for (const OO of pO) KO.push(OO.gradient, OO.color.r, OO.color.g, OO.color.b)
      }
    }
    const MO = new XO.Color3;

    function aK(OO, KO, pO, XO) {
      return KO ? KO.length > eO.b ? (XO(`particleStops:${pO}`, `GPU particles use the first 2 and last ${eO.b-2} of more than ${eO.b} ${pO} gradient stops (${OO.name})`), eO.b) : KO.length : 0
    }

    function oO(OO, KO) {
      return KO < 2 || OO.length <= eO.b ? KO : OO.length - eO.b + KO
    }
    const FO = new Float32Array(eO.o),
      VO = new Uint32Array(FO.buffer);

    function LO(OO, KO, pO) {
      return lO(OO, FO, VO, pO), KO && QO(VO, KO) ? null : VO.slice()
    }

    function QO(OO, KO) {
      if (OO.length !== KO.length) return !1;
      for (let pO = 0; pO < OO.length; pO++)
        if (OO[pO] !== KO[pO]) return !1;
      return !0
    }

    function zK(OO, KO, pO) {
      var XO;
      OO[KO] = pO.gradient, OO[KO + 1] = pO.factor1, OO[KO + 2] = null !== (XO = pO.factor2) && void 0 !== XO ? XO : pO.factor1
    }
  },
  39624: (OO, KO, pO) => {
    function XO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
      const KO = new Set;
      return (pO, XO) => {
        KO.has(pO) || (KO.add(pO), console.warn(OO + XO))
      }
    }
    pO.d(KO, {
      d: () => XO
    })
  },
  39672: (OO, KO, pO) => {
    pO.d(KO, {
      createLiteRendererAsync: () => EC,
      liteBabylonBackend: () => RO,
      setPipelineFailureHook: () => qe
    });
    var XO = pO(35680),
      bK = pO(35936),
      eO = pO(36267),
      lO = pO(35578),
      vK = pO(36279);
    class CO extends vK.c {
      constructor() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        super(...KO), this.color = new XO.Color3(1, 1, 1), this.alpha = 1, this.material = {
          name: "colorShader",
          uniqueId: KO[0].JKO().getUniqueId(),
          shaderPath: "color",
          fillMode: 4,
          sideOrientation: null,
          alphaMode: 2,
          forceDepthWrite: !1,
          disableDepthWrite: !1,
          backFaceCulling: !0,
          cullBackFaces: !0,
          depthFunction: 0,
          zOffset: 0,
          zOffsetUnits: 0,
          disableColorWrite: !1,
          getClassName: () => "ShaderMaterial",
          needAlphaBlendingForMesh: OO => OO.visibility < 1 || OO.hasVertexAlpha,
          needAlphaTestingForMesh: () => !1,
          dispose: () => {}
        }
      }
      getClassName() {
        return "LinesMesh"
      }
    }
    const hO = ["VERTEXCOLOR", "VERTEXALPHA", "INSTANCES", "THIN_INSTANCES", "INSTANCESCOLOR", "FOG", "LITE_FRONT_LAYER"],
      DO = OO => 1 << hO.indexOf(OO),
      MO = DO("VERTEXCOLOR"),
      aK = DO("INSTANCES"),
      oO = DO("THIN_INSTANCES"),
      FO = DO("INSTANCESCOLOR"),
      VO = DO("FOG"),
      LO = DO("LITE_FRONT_LAYER");

    function QO(OO, KO, pO, XO) {
      let bK = 0;
      return OO.isVerticesDataPresent("color") && (bK |= MO), "none" !== KO && (bK |= aK), "thin" === KO && (bK |= oO, OO.isVerticesDataPresent("instanceColor") && (bK |= FO)), XO.fogEnabled && OO.applyFog && 0 !== XO.fogMode && (bK |= VO), pO >= 1 && (bK |= LO), bK
    }

    function zK(OO, KO) {
      OO.updateColor4("color", KO.color, KO.alpha)
    }
    var AO = pO(36213),
      fO = pO(35765),
      dO = pO(35711),
      TO = pO(35552),
      NO = pO(36194),
      IO = pO(36204),
      yK = pO(35570),
      gK = pO(35573),
      uO = pO(35587);
    const EO = TO.e.GLSL;
    class jK {
      constructor(OO, KO) {
        this.name = OO, this.Ce = KO, this.uniqueId = void 0, this.checkReadyOnlyOnce = !1, this._blockDirtyMechanism = !1, this.disposers = [], this.cpO = {
          addOnce: OO => {
            this.disposers.push(OO)
          }
        }, this.uniqueId = KO.getUniqueId()
      }
      get isFrozen() {
        return this.checkReadyOnlyOnce
      }
      JKO() {
        return this.Ce
      }
      getClassName() {
        return "LiteMaterial"
      }
      freeze() {
        this.checkReadyOnlyOnce = !0
      }
      unfreeze() {
        this.checkReadyOnlyOnce = !1
      }
      markDirty() {}
      get fillMode() {
        return this.model.fillMode
      }
      needAlphaBlendingForMesh(OO) {
        return (0, yK.R)(this.model, OO.visibility, OO.hasVertexAlpha)
      }
      needAlphaTestingForMesh(OO) {
        return (0, yK.V)(this.model, OO.visibility, OO.hasVertexAlpha)
      }
      dispose() {
        (0, fO.j)(this);
        for (const OO of this.disposers.splice(0)) OO()
      }
      get model() {
        return (0, yK.cb)(this)
      }
    }
    const YO = new WeakSet;

    function wO(OO) {
      return YO.has(OO)
    }

    function iK(OO) {
      YO.add(OO)
    }
    const rK = {
      create: (OO, KO) => ((0, dO.q)(OO, new jK(OO.name, KO)), gK.e.defines()),
      write: () => {},
      addFeature: (OO, KO) => {
        const pO = OO.mirror;
        KO.feature === IO.i && KO.state.dirLightCount > 0 && (OO.disableLighting = !0, (0, yK.bb)(OO)), "BLOXD_LIGHTING" in KO.defines && (0, fO.g)(pO), KO.feature === NO.f && ((0, AO.j)(KO.state, EO), function(OO, KO) {
          const pO = OO.JKO().qb();
          KO.textures.forEach(((XO, bK) => {
            setTimeout((() => {
              var eO, lO;
              const {
                url: vK
              } = XO.source;
              pO.atlasArray(vK, null !== (eO = null === (lO = KO.sources.pixels) || void 0 === lO ? void 0 : lO[bK]) && void 0 !== eO ? eO : null, KO.sources.layerWidth).then((pO => {
                (0, AO.e)(OO, KO, bK, pO, pO.layerWidth, pO.layers, EO)
              })).catch((OO => {
                console.error(`Failed to build texture array for atlas ${bK}`, OO)
              }))
            }))
          }))
        }(pO, KO.state))
      },
      texture: (OO, KO, pO) => {
        let {
          data: XO,
          sets: bK
        } = pO;
        var eO;
        (iK(OO), XO) && (OO.uvSet = null !== (eO = null === bK || void 0 === bK ? void 0 : bK.coordinatesIndex) && void 0 !== eO ? eO : 0, (0, dO.fb)(OO.matrix, null !== bK && void 0 !== bK ? bK : {}))
      },
      cube: iK,
      canvas: (OO, KO, pO) => {
        let {
          width: XO,
          height: bK,
          mipmaps: eO,
          samplingMode: lO = uO.i.trilinear,
          hasAlpha: vK = !1,
          wrap: CO = uO.d.clamp
        } = pO;
        const hO = OO.qb().createCanvas(XO, bK),
          DO = new uO.l("2d", {
            kind: "canvas",
            width: XO,
            height: bK,
            canvas: hO
          }, {
            samplingMode: lO,
            wrapU: CO,
            wrapV: CO,
            noMipmap: !eO,
            invertY: !0
          });
        return DO.hasAlpha = vK, iK(DO), DO
      }
    };
    var PO = pO(35776),
      mK = pO(35660);
    class sO {
      constructor(OO, KO, pO) {
        this.engine = OO, this.clearColor = KO, this.ambientColor = pO, this.onBeforeRenderObservable = new mK.e, this.onBeforeCameraRenderObservable = new mK.e, this.onAfterRenderObservable = new mK.e, this.activeCamera = null, this.useRightHandedSystem = !1, this.iblIntensity = 1, this.particlesEnabled = !0, this.meshes = [], this.materials = [], this.textures = [], this.transformNodes = [], this.ku = [], this.frustumPlanes = void 0, this.draw = () => {}, this.frameId = 0, this.animationRatio = 1, this.lastId = 0, this.pending = []
      }
      qb() {
        return this.engine
      }
      getUniqueId() {
        return ++this.lastId
      }
      getFrameId() {
        return this.frameId
      }
      getAnimationRatio() {
        return this.animationRatio
      }
      addPendingData(OO) {
        this.pending.push(OO)
      }
      removePendingData(OO) {
        const KO = this.pending.indexOf(OO); - 1 !== KO && this.pending.splice(KO, 1)
      }
      getWaitingItemsCount() {
        return this.pending.length
      }
      isReady() {
        return 0 === this.pending.length
      }
      getActiveMeshes() {
        return []
      }
      render() {
        this.frameId++, this.animationRatio = .06 * Math.max(1, Math.min(this.engine.getDeltaTime(), 1e3)), this.draw(), this.onAfterRenderObservable.notifyObservers(this)
      }
    }

    function HO() {
      throw new Error("Lite has no WebGL engine, Babylon particles or Babylon picks")
    }
    const RO = {
      jMO: HO,
      uDO: (OO, KO) => {
        const pO = new sO(OO.engine, XO.c.FromArray(KO.clearColor), XO.Color3.FromArray(KO.ambientColor));
        (0, lO.b)(rK, pO), OO.Ce = pO,
          function(OO, KO) {
            const pO = Object.assign((0, PO.j)(OO, "camera"), {
              layerMask: 268435455
            });
            OO.model.nodes.setWorldSource(pO.row, OO.model.view.worldMatrix), OO.camera = KO.activeCamera = pO
          }(OO, pO), (0, bK.j)(OO, ((OO, KO, pO) => (0, eO.h)(OO, KO, pO, vK.c)))
      },
      NDO: () => {},
      setBabylonFog: () => {},
      YDO: HO,
      rMO: () => {},
      linesFromArrays: (OO, KO, pO) => (0, eO.h)(OO, KO, pO, CO),
      he: () => {},
      iMO: HO
    };
    var SO = pO(39724),
      JO = pO(39736);
    class cK {
      constructor(OO) {
        this.deviceLost = void 0, this.refusedFrames = 0, this.refused = void 0;
        const KO = new Promise((OO => {
          this.refused = OO
        }));
        this.deviceLost = Promise.race([OO, KO])
      }
      frameDrawn() {
        this.refusedFrames = 0
      }
      frameFailed(OO) {
        (function(OO) {
          const {
            name: KO,
            message: pO
          } = null !== OO && void 0 !== OO ? OO : {};
          return "InvalidStateError" === KO && "string" === typeof pO && pO.startsWith("GPUDevice.")
        })(OO) && (this.refusedFrames++, 3 === this.refusedFrames && this.refused({
          reason: "unknown",
          message: OO.message,
          framesRefused: !0
        }))
      }
    }
    class BO {
      constructor(OO) {
        this.resources = OO, this.matrixKey = {
          YO: 0
        }, this.attributesKey = {
          YO: 0
        }, this.inputs = Object.create(null);
        for (let KO = 0; KO < 4; KO++) this.inputs[`world${KO}`] = new qK(this.matrixKey, 16 * KO, 64, 4)
      }
      release() {
        this.resources.bufferDeleted(this.matrixKey), this.resources.bufferDeleted(this.attributesKey)
      }
      bind(OO, KO) {
        this.resources.vertexBufferCreated(this.matrixKey, OO, !0), KO && this.resources.vertexBufferCreated(this.attributesKey, KO, !0)
      }
    }
    class ZO extends BO {
      constructor(OO, KO, pO) {
        super(OO), this.mesh = KO, this.rowStride = void 0, this.matrices = null, this.attributes = null;
        const XO = this.inputs;
        let bK = 0;
        for (const {
            size: lO
          }
          of pO) bK += lO;
        for (const {
            name: lO,
            offset: vK,
            size: CO,
            type: hO
          }
          of pO) XO[lO] = new qK(this.attributesKey, 4 * vK, 4 * bK, CO, !0, hO);
        this.rowStride = bK, OO.HeO.set(KO, this);
        const eO = KO.isVerticesDataPresent;
        KO.isVerticesDataPresent = (OO, pO) => OO in XO || eO.call(KO, OO, pO)
      }
      attach(OO, KO) {
        this.matrices = OO, this.attributes = KO, this.bind(OO, KO), this.mirror(OO, OO.length, OO.length / 16)
      }
      flO(OO) {
        this.matrices && this.resources.vertexBufferUpdated(this.matrixKey, this.matrices, 0, OO ? 64 * OO : void 0)
      }
      dlO() {
        this.attributes && this.resources.vertexBufferUpdated(this.attributesKey, this.attributes)
      }
      matrixRows(OO, KO) {
        this.resources.vertexBufferFloatsUpdated(this.matrixKey, this.matrices, 16 * OO, 16 * KO)
      }
      attributeRows(OO, KO) {
        this.resources.vertexBufferFloatsUpdated(this.attributesKey, this.attributes, OO * this.rowStride, KO * this.rowStride)
      }
      release() {
        super.release(), this.matrices = null, this.attributes = null, this.mirror(null, 512, 0)
      }
      mirror(OO, KO, pO) {
        const XO = this.mesh._thinInstanceDataStorage;
        XO.matrixData = OO, XO.matrixBufferSize = KO, XO.worldMatrices = null, XO.instancesCount = pO
      }
    }
    class GO extends BO {
      constructor(OO, KO, pO) {
        var XO, bK, eO, lO;
        super(OO), this.layout = void 0, this.offsets = void 0, this.rowStride = void 0, this.matrices = new Float32Array(512), this.attributes = void 0, this.frame = -1, this.count = 0, this.packedSource = null, this.packedBatch = null, this.layout = null !== (XO = null === pO || void 0 === pO ? void 0 : pO.interleavedKinds) && void 0 !== XO ? XO : null, this.offsets = null !== (bK = null === pO || void 0 === pO ? void 0 : pO.interleavedOffsets) && void 0 !== bK ? bK : [], this.rowStride = null !== (eO = null === pO || void 0 === pO ? void 0 : pO.interleavedRowStride) && void 0 !== eO ? eO : 0, null === (lO = this.layout) || void 0 === lO || lO.forEach(((OO, KO) => {
          this.inputs[OO] = new qK(this.attributesKey, 4 * this.offsets[KO], 4 * this.rowStride, pO.strides[OO])
        })), this.attributes = this.rowStride > 0 ? new Float32Array(32 * this.rowStride) : null, this.bind(this.matrices, this.attributes), OO.batchUploads.set(KO, this), KO.cpO.addOnce((() => {
          this.release()
        }))
      }
      get packedMatrices() {
        return this.matrices
      }
      packedRowMesh(OO) {
        const KO = this.packedBatch;
        return KO.renderSelf ? 0 === OO ? this.packedSource : KO.instances[OO - 1] : KO.instances[OO]
      }
      get packedAttributes() {
        return this.attributes
      }
      pack(OO, KO, pO, XO) {
        const bK = (KO.renderSelf ? 1 : 0) + KO.rows.length;
        if (this.frame = XO, this.count = bK, this.packedSource = OO, this.packedBatch = KO, 0 === bK) return;
        if (OO.getWorldMatrix(), 16 * bK > this.matrices.length) {
          let OO = this.matrices.length / 16;
          for (; OO < bK;) OO *= 2;
          this.matrices = new Float32Array(16 * OO), this.attributes &&= new Float32Array(OO * this.rowStride), this.bind(this.matrices, this.attributes)
        }
        let eO = 0;
        KO.renderSelf && this.packRow(eO++, OO, KO.row, pO);
        for (let lO = 0; lO < KO.rows.length; lO++) this.packRow(eO++, KO.instances[lO], KO.rows[lO], pO);
        this.resources.vertexBufferFloatsUpdated(this.matrixKey, this.matrices, 0, 16 * bK), this.attributes && this.resources.vertexBufferFloatsUpdated(this.attributesKey, this.attributes, 0, bK * this.rowStride)
      }
      packRow(OO, KO, pO, XO) {
        const bK = this.matrices;
        if (pO < 0) bK.set(KO.getWorldMatrix().m, 16 * OO);
        else
          for (let hO = 0; hO < 16; hO++) bK[16 * OO + hO] = XO[16 * pO + hO];
        const eO = this.attributes;
        if (!eO) return;
        const lO = KO.lpO,
          vK = this.layout;
        for (let hO = 0; hO < vK.length; hO++) {
          var CO;
          const KO = null !== (CO = lO[vK[hO]]) && void 0 !== CO ? CO : 0,
            pO = OO * this.rowStride + this.offsets[hO];
          KO.toArray ? KO.toArray(eO, pO) : KO.copyToArray ? KO.copyToArray(eO, pO) : eO[pO] = KO
        }
      }
    }
    class qK {
      constructor(OO, KO, pO, XO) {
        let bK = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 5126,
          lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
        this.key = OO, this.byteOffset = KO, this.byteStride = pO, this.size = XO, this.instanced = bK, this.type = eO, this.normalized = lO
      }
      getBuffer() {
        return this.key
      }
      getSize() {
        return this.size
      }
      getIsInstanced() {
        return this.instanced
      }
    }
    const xK = "CANVAS_ALPHA_ONE",
      nO = `override ${xK}: bool = false;`,
      WO = {
        srcFactor: "zero",
        dstFactor: "one",
        operation: "add"
      };

    function tK(OO, KO, pO) {
      var XO;
      let bK = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
      const eO = null !== (XO = KO._colorFormat) && void 0 !== XO ? XO : "bgra8unorm",
        lO = bK ? 15 : 0;
      return pO ? {
        ...OO,
        targets: [{
          format: eO,
          blend: {
            color: pO,
            alpha: WO
          },
          writeMask: lO
        }]
      } : {
        ...OO,
        constants: {
          ...OO.constants,
          [xK]: 1
        },
        targets: [{
          format: eO,
          writeMask: lO
        }]
      }
    }

    function kK(OO, KO) {
      OO._renderables.push(KO)
    }

    function UO(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = OO._frameGraph) || void 0 === pO ? void 0 : pO._tasks) && void 0 !== KO ? KO : []
    }

    function OK(OO) {
      return OO._currentEncoder
    }

    function KK(OO) {
      return OO.createBindGroupLayout({
        label: "lite-scene-equivalent",
        entries: [{
          binding: 0,
          visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT,
          buffer: {
            type: "uniform"
          }
        }, {
          binding: 1,
          visibility: GPUShaderStage.FRAGMENT,
          buffer: {
            type: "uniform"
          }
        }]
      })
    }
    const pK = "greater-equal",
      XK = 2e5,
      bp = 1e5,
      eK = new WeakMap;

    function lK(OO, KO) {
      let pO = eK.get(OO);
      if (!pO) {
        pO = {
          module: OO.createShaderModule({
            label: "placeholder",
            code: "@vertex fn v() -> @builtin(position) vec4f { return vec4f(0.0, 0.0, 0.0, 1.0); }\n@fragment fn f() -> @location(0) vec4f { return vec4f(0.0); }"
          }),
          pipelines: new Map
        }, eK.set(OO, pO)
      }
      const XO = `${KO._colorFormat}|${KO._depthStencilFormat}|${KO._sampleCount}`;
      let bK = pO.pipelines.get(XO);
      if (!bK) {
        var eO;
        const {
          module: lO
        } = pO;
        bK = OO.createRenderPipeline({
          label: `placeholder ${XO}`,
          layout: OO.createPipelineLayout({
            bindGroupLayouts: []
          }),
          vertex: {
            module: lO,
            entryPoint: "v"
          },
          fragment: {
            module: lO,
            entryPoint: "f",
            targets: [{
              format: null !== (eO = KO._colorFormat) && void 0 !== eO ? eO : "bgra8unorm",
              writeMask: 0
            }]
          },
          depthStencil: KO._depthStencilFormat ? {
            format: KO._depthStencilFormat,
            depthCompare: "always",
            depthWriteEnabled: !1
          } : void 0,
          multisample: {
            count: KO._sampleCount
          }
        }), pO.pipelines.set(XO, bK)
      }
      return bK
    }

    function vp(OO, KO, pO) {
      const XO = KO.eye,
        bK = KO.viewMatrix;
      OO[0] = XO[0] + bK[2] * pO, OO[1] = XO[1] + bK[6] * pO, OO[2] = XO[2] + bK[10] * pO
    }
    var CK = pO(36323),
      hK = pO(39624),
      DK = pO(35568);
    const MK = Math.PI,
      ap = MK / 1.95,
      oK = [5e-4 / 94, 125e-7, 5e-4 / 18],
      FK = [
        [68e-8, .686],
        [55e-8, .678],
        [45e-8, .666]
      ].map((OO => {
        let [KO, pO] = OO;
        return .434 * MK * Math.pow(2 * MK / KO, 2) * pO
      }));

    function VK(OO, KO, pO) {
      const {
        up: XO,
        mieDirectionalG: bK
      } = OO, eO = 1 - zp(1 - Math.exp(KO[1] / 45e4), 0, 1), lO = OO.rayleigh - (1 - eO), vK = Math.hypot(KO[0], KO[1], KO[2]), CO = vK > 0 ? 1 / vK : 0, hO = pO.sunDir;
      for (let oO = 0; oO < 3; oO++) hO[oO] = KO[oO] * CO;
      const DO = hO[0] * XO[0] + hO[1] * XO[1] + hO[2] * XO[2],
        MO = 1e3 * Math.max(0, 1 - Math.exp(-(ap - Math.acos(zp(DO, -1, 1))) / 1.5));
      pO.sunE = MO;
      const aK = .2 * OO.turbidity * 1e-17 * OO.mieCoefficient;
      for (let oO = 0; oO < 3; oO++) {
        const OO = oK[oO] * lO,
          KO = FK[oO] * aK,
          XO = MO / (OO + KO);
        pO.inScatterR[oO] = OO * XO, pO.inScatterM[oO] = KO * XO, pO.extinctionBeta[oO] = 8400 * OO + 1250 * KO
      }
      return pO.sunsetMix = zp(Math.pow(1 - DO, 5), 0, 1), pO.sunDiscE = 19e3 * MO, pO.mieScale = (1 - bK * bK) / (4 * MK), pO.mieBase = 1 + bK * bK, pO.mieSlope = 2 * bK, pO
    }
    const LK = {
      A: .15,
      B: .5,
      C: .1,
      D: .2,
      E: .02,
      F: .3
    };
    const QK = 1 / function(OO) {
      const {
        A: KO,
        B: pO,
        C: XO,
        D: bK,
        E: eO,
        F: lO
      } = LK;
      return (OO * (KO * OO + XO * pO) + bK * eO) / (OO * (KO * OO + pO) + bK * lO) - eO / lO
    }(1e3);

    function zp(OO, KO, pO) {
      return Math.min(Math.max(OO, KO), pO)
    }
    const AK = /^\s*#(ifdef|ifndef|if|elif|else|endif|define|undef)\b(.*)$/;

    function fK(OO, KO) {
      const pO = new Map(KO),
        XO = [],
        bK = [],
        eO = () => 0 === bK.length || bK[bK.length - 1].active;
      let lO = null;
      const vK = () => {
        const OO = [...pO].filter((OO => {
            let [, KO] = OO;
            return !0 !== KO
          })),
          KO = OO.map((OO => {
            let [KO] = OO;
            return KO
          })).join("|");
        lO = OO.length ? new RegExp(`\\b(${KO})\\b`, "g") : null
      };
      vK();
      for (const CO of OO.split("\n")) {
        const OO = AK.exec(CO);
        if (!OO) {
          eO() && XO.push(lO ? dK(CO, lO, pO) : CO);
          continue
        }
        const KO = OO[1],
          hO = OO[2].trim();
        if ("ifdef" === KO || "ifndef" === KO || "if" === KO) {
          const OO = eO(),
            XO = "if" === KO ? TK(hO, pO) : pO.has(hO) === ("ifdef" === KO);
          bK.push({
            active: OO && XO,
            parentActive: OO,
            taken: XO
          })
        } else if ("elif" === KO || "else" === KO) {
          const OO = bK[bK.length - 1];
          if (!OO) throw new Error(`#${KO} without #if`);
          const XO = !OO.taken && ("else" === KO || TK(hO, pO));
          OO.active = OO.parentActive && XO, OO.taken = OO.taken || XO
        } else if ("endif" === KO) {
          if (!bK.pop()) throw new Error("#endif without #if")
        } else if (eO()) {
          const [OO, ...XO] = hO.split(/\s+/);
          "undef" === KO ? pO.delete(OO) : pO.set(OO, !XO.length || XO.join(" ")), vK()
        }
      }
      if (bK.length) throw new Error("Unterminated #if");
      return XO.join("\n")
    }

    function dK(OO, KO, pO) {
      return OO.replace(KO, (OO => {
        const KO = pO.get(OO);
        return "string" === typeof KO ? KO : OO
      }))
    }

    function TK(OO, KO) {
      var pO;
      const XO = null !== (pO = OO.match(/defined|\d+(\.\d+)?|\w+|&&|\|\||==|!=|>=|<=|[()!<>]/g)) && void 0 !== pO ? pO : [];
      let bK = 0;
      const eO = () => XO[bK],
        lO = () => XO[bK++],
        vK = OO => {
          const pO = /^\d/.test(OO) ? OO : KO.get(OO);
          return "string" === typeof pO ? parseInt(pO) : Number.NaN
        },
        CO = () => {
          const OO = lO();
          if ("!" === OO) return !CO();
          if ("(" === OO) {
            const OO = DO();
            return lO(), OO
          }
          if ("defined" === OO) {
            const OO = "(" === eO();
            OO && lO();
            const pO = lO();
            return OO && lO(), KO.has(pO)
          }
          const pO = eO();
          if ("==" === pO || "!=" === pO || ">" === pO || "<" === pO || ">=" === pO || "<=" === pO) {
            lO();
            const KO = vK(OO),
              XO = vK(lO());
            if (Number.isNaN(KO) || Number.isNaN(XO)) return !1;
            switch (pO) {
              case "==":
                return KO === XO;
              case "!=":
                return KO !== XO;
              case ">":
                return KO > XO;
              case "<":
                return KO < XO;
              case ">=":
                return KO >= XO;
              default:
                return KO <= XO
            }
          }
          return KO.has(OO)
        },
        hO = () => {
          let OO = CO();
          for (;
            "&&" === eO();) {
            lO();
            const KO = CO();
            OO = OO && KO
          }
          return OO
        },
        DO = () => {
          let OO = hO();
          for (;
            "||" === eO();) {
            lO();
            const KO = hO();
            OO = OO || KO
          }
          return OO
        },
        MO = DO();
      if (bK !== XO.length) throw new Error(`Cannot evaluate #if ${OO}`);
      return MO
    }
    var NK = pO(35559),
      IK = pO(35845),
      yp = pO(35852),
      gp = pO(38954),
      uK = pO(37122);
    const EK = 32,
      jp = [10, 3, 10],
      YK = [21, 7, 21],
      wK = YK[0] * YK[1] * YK[2],
      ip = 0,
      rp = 1,
      PK = 2,
      mp = 3,
      sK = 64,
      HK = 512,
      RK = 4 * wK,
      SK = 1536,
      JK = RK + wK * SK,
      cp = 1073741824,
      BK = JK + 1;

    function ZK(OO, KO) {
      const pO = OO % KO;
      return pO < 0 ? pO + KO : pO
    }

    function GK(OO, KO, pO) {
      return XO = ZK(OO, YK[0]), bK = ZK(KO, YK[1]), eO = ZK(pO, YK[2]), XO + YK[0] * (bK + YK[1] * eO);
      var XO, bK, eO
    }

    function qp(OO, KO, pO) {
      return OO + 8 * (KO + 8 * pO)
    }

    function xp(OO, KO, pO) {
      return OO + 4 * (KO + 4 * pO)
    }
    const nK = 65535,
      WK = 0,
      tp = 1,
      kp = 2,
      UK = 3;

    function Op(OO) {
      return Math.ceil(OO * OO / 32)
    }
    const Kp = 8192,
      pp = 1 << 18,
      Xp = 65536,
      bX = 294912,
      ep = 128,
      lp = 4096,
      vX = 16,
      Cp = 16385,
      hp = 81921,
      Dp = 147457,
      Mp = 4194304;
    const aX = [0, 0, 0],
      op = [0, 0, 0];

    function Fp(OO, KO, pO, XO) {
      ! function(OO, KO, pO) {
        const [XO, bK, eO] = [OO[0], OO[1], OO[2]];
        let lO, vK, CO;
        Math.abs(bK) < .99 ? (lO = eO, vK = 0, CO = -XO) : (lO = -bK, vK = XO, CO = 0);
        const hO = Math.hypot(lO, vK, CO);
        KO[0] = lO / hO, KO[1] = vK / hO, KO[2] = CO / hO, pO[0] = bK * KO[2] - eO * KO[1], pO[1] = eO * KO[0] - XO * KO[2], pO[2] = XO * KO[1] - bK * KO[0]
      }(XO, aX, op);
      const bK = 1 / 32;
      for (const [eO, lO] of [
          [0, aX],
          [4, op]
        ]) {
        for (let pO = 0; pO < 3; pO++) OO[KO + eO + pO] = lO[pO] * bK;
        OO[KO + eO + 3] = -(lO[0] * pO[0] + lO[1] * pO[1] + lO[2] * pO[2]) * bK
      }
    }
    class Vp {
      constructor() {
        this.words = new Uint32Array(Dp), this.parts = 0, this.refs = 0, this.floats = new Float32Array(this.words.buffer), this.rects = new Int32Array(16384), this.counts = new Uint32Array(16384), this.inverse = new Float64Array(16), this.view = new Float32Array(8), this.viewAt = 0, this.light = [0, 1, 0]
      }
      Ip(OO, KO) {
        this.parts = 0, this.refs = 0, this.view = OO, this.viewAt = KO;
        const pO = OO[KO + 1] * OO[KO + 6] - OO[KO + 2] * OO[KO + 5],
          XO = OO[KO + 2] * OO[KO + 4] - OO[KO] * OO[KO + 6],
          bK = OO[KO] * OO[KO + 5] - OO[KO + 1] * OO[KO + 4],
          eO = Math.hypot(pO, XO, bK) || 1;
        this.light[0] = pO / eO, this.light[1] = XO / eO, this.light[2] = bK / eO
      }
      add(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        if (this.parts >= lp || ! function(OO, KO, pO) {
            const XO = OO[KO],
              bK = OO[KO + 1],
              eO = OO[KO + 2],
              lO = OO[KO + 3],
              vK = OO[KO + 4],
              CO = OO[KO + 5],
              hO = OO[KO + 6],
              DO = OO[KO + 7],
              MO = OO[KO + 8],
              aK = OO[KO + 9],
              oO = OO[KO + 10],
              FO = OO[KO + 11],
              VO = OO[KO + 12],
              LO = OO[KO + 13],
              QO = OO[KO + 14],
              zK = OO[KO + 15],
              AO = XO * CO - bK * vK,
              fO = XO * hO - eO * vK,
              dO = XO * DO - lO * vK,
              TO = bK * hO - eO * CO,
              NO = bK * DO - lO * CO,
              IO = eO * DO - lO * hO,
              yK = MO * LO - aK * VO,
              gK = MO * QO - oO * VO,
              uO = MO * zK - FO * VO,
              EO = aK * QO - oO * LO,
              jK = aK * zK - FO * LO,
              YO = oO * zK - FO * QO,
              wO = AO * YO - fO * jK + dO * EO + TO * uO - NO * gK + IO * yK;
            if (!(Math.abs(wO) > 1e-12)) return !1;
            const iK = 1 / wO;
            return pO[0] = (CO * YO - hO * jK + DO * EO) * iK, pO[1] = (eO * jK - bK * YO - lO * EO) * iK, pO[2] = (LO * IO - QO * NO + zK * TO) * iK, pO[3] = (oO * NO - aK * IO - FO * TO) * iK, pO[4] = (hO * uO - vK * YO - DO * gK) * iK, pO[5] = (XO * YO - eO * uO + lO * gK) * iK, pO[6] = (QO * dO - VO * IO - zK * fO) * iK, pO[7] = (MO * IO - oO * dO + FO * fO) * iK, pO[8] = (vK * jK - CO * uO + DO * yK) * iK, pO[9] = (bK * uO - XO * jK - lO * yK) * iK, pO[10] = (VO * NO - LO * dO + zK * AO) * iK, pO[11] = (aK * dO - MO * NO - FO * AO) * iK, pO[12] = (CO * gK - vK * EO - hO * yK) * iK, pO[13] = (XO * EO - bK * gK + eO * yK) * iK, pO[14] = (LO * fO - VO * TO - QO * AO) * iK, pO[15] = (MO * TO - aK * fO + oO * AO) * iK, !0
          }(KO, pO, this.inverse)) return;
        const {
          view: XO,
          viewAt: bK
        } = this, eO = pO;
        let lO = 1 / 0,
          vK = 1 / 0,
          CO = -1 / 0,
          hO = -1 / 0,
          DO = -1 / 0;
        const [MO, aK, oO] = this.light;
        for (let dO = 0; dO < 8; dO++) {
          const pO = 1 & dO ? OO.hi[0] : OO.lo[0],
            FO = 2 & dO ? OO.hi[1] : OO.lo[1],
            VO = 4 & dO ? OO.hi[2] : OO.lo[2],
            LO = pO * KO[eO] + FO * KO[eO + 4] + VO * KO[eO + 8] + KO[eO + 12],
            QO = pO * KO[eO + 1] + FO * KO[eO + 5] + VO * KO[eO + 9] + KO[eO + 13],
            zK = pO * KO[eO + 2] + FO * KO[eO + 6] + VO * KO[eO + 10] + KO[eO + 14],
            AO = XO[bK] * LO + XO[bK + 1] * QO + XO[bK + 2] * zK + XO[bK + 3],
            fO = XO[bK + 4] * LO + XO[bK + 5] * QO + XO[bK + 6] * zK + XO[bK + 7];
          lO = Math.min(lO, AO), vK = Math.min(vK, fO), CO = Math.max(CO, AO), hO = Math.max(hO, fO), DO = Math.max(DO, MO * LO + aK * QO + oO * zK)
        }
        if (CO < -1 || hO < -1 || lO >= 1 || vK >= 1) return;
        const FO = this.parts++,
          VO = this.rects;
        VO[4 * FO] = Lp(lO), VO[4 * FO + 1] = Lp(vK), VO[4 * FO + 2] = Lp(CO), VO[4 * FO + 3] = Lp(hO);
        const LO = this.inverse,
          {
            cell: QO,
            dims: zK,
            lo: AO
          } = OO,
          fO = hp + FO * vX;
        for (let dO = 0; dO < 3; dO++) this.floats[fO + 4 * dO] = LO[dO] / QO, this.floats[fO + 4 * dO + 1] = LO[4 + dO] / QO, this.floats[fO + 4 * dO + 2] = LO[8 + dO] / QO, this.floats[fO + 4 * dO + 3] = (LO[12 + dO] - AO[dO]) / QO;
        this.words[fO + 12] = OO.at, this.floats[fO + 13] = DO + .001 * (1 + Math.abs(DO)), this.words[fO + 14] = zK[0] | zK[1] << 8 | zK[2] << 16
      }
      finish() {
        const OO = ep,
          {
            counts: KO,
            rects: pO,
            words: XO
          } = this;
        KO.fill(0);
        let bK = 0,
          eO = 0;
        for (; eO < this.parts; eO++) {
          const XO = 4 * eO,
            lO = (pO[XO + 2] - pO[XO] + 1) * (pO[XO + 3] - pO[XO + 1] + 1);
          if (bK + lO > 65536) break;
          bK += lO;
          for (let bK = pO[XO + 1]; bK <= pO[XO + 3]; bK++)
            for (let eO = pO[XO]; eO <= pO[XO + 2]; eO++) KO[bK * OO + eO]++
        }
        let lO = 0;
        for (let CO = 0; CO < 16384; CO++) XO[CO] = lO, lO += KO[CO], KO[CO] = XO[CO];
        XO[16384] = lO;
        for (let CO = 0; CO < eO; CO++) {
          const bK = 4 * CO;
          for (let eO = pO[bK + 1]; eO <= pO[bK + 3]; eO++)
            for (let lO = pO[bK]; lO <= pO[bK + 2]; lO++) XO[Cp + KO[eO * OO + lO]++] = CO
        }
        const vK = this.floats;
        for (let CO = 0; CO < 16384; CO++) {
          const OO = Cp + XO[CO],
            KO = OO + Math.min(XO[CO + 1] - XO[CO], 64);
          for (let pO = OO + 1; pO < KO; pO++) {
            const KO = XO[pO],
              bK = vK[81934 + KO * vX];
            let eO = pO - 1;
            for (; eO >= OO && vK[81934 + XO[eO] * vX] < bK; eO--) XO[eO + 1] = XO[eO];
            XO[eO + 1] = KO
          }
        }
        this.refs = bK
      }
    }

    function Lp(OO) {
      return Math.min(127, Math.max(0, Math.floor((.5 * OO + .5) * ep)))
    }

    function Qp(OO, KO, pO, XO, bK) {
      for (let eO = 0; eO < 4; eO++)
        for (let lO = 0; lO < 4; lO++) bK[4 * eO + lO] = OO[KO + 4 * eO] * pO[XO + lO] + OO[KO + 4 * eO + 1] * pO[XO + 4 + lO] + OO[KO + 4 * eO + 2] * pO[XO + 8 + lO] + OO[KO + 4 * eO + 3] * pO[XO + 12 + lO]
    }

    function zX(OO, KO, pO, XO, bK) {
      const eO = OO[0] - KO,
        lO = OO[1] - pO,
        vK = OO[2] - XO,
        CO = OO[3] - KO,
        hO = OO[4] - pO,
        DO = OO[5] - XO,
        MO = OO[6] - KO,
        aK = OO[7] - pO,
        oO = OO[8] - XO;
      if (Math.min(eO, CO, MO) > bK || Math.max(eO, CO, MO) < -bK) return !1;
      if (Math.min(lO, hO, aK) > bK || Math.max(lO, hO, aK) < -bK) return !1;
      if (Math.min(vK, DO, oO) > bK || Math.max(vK, DO, oO) < -bK) return !1;
      const FO = CO - eO,
        VO = hO - lO,
        LO = DO - vK,
        QO = MO - CO,
        zK = aK - hO,
        AO = oO - DO,
        fO = VO * AO - LO * zK,
        dO = LO * QO - FO * AO,
        TO = FO * zK - VO * QO;
      if (Math.abs(fO * eO + dO * lO + TO * vK) > bK * (Math.abs(fO) + Math.abs(dO) + Math.abs(TO))) return !1;
      const NO = [FO, VO, LO, QO, zK, AO, eO - MO, lO - aK, vK - oO];
      for (let IO = 0; IO < 3; IO++) {
        const OO = NO[3 * IO],
          KO = NO[3 * IO + 1],
          pO = NO[3 * IO + 2];
        for (let XO = 0; XO < 3; XO++) {
          const FO = 0 === XO ? 0 : 1 === XO ? pO : -KO,
            VO = 0 === XO ? -pO : 1 === XO ? 0 : OO,
            LO = 0 === XO ? KO : 1 === XO ? -OO : 0,
            QO = FO * eO + VO * lO + LO * vK,
            zK = FO * CO + VO * hO + LO * DO,
            AO = FO * MO + VO * aK + LO * oO,
            fO = bK * (Math.abs(FO) + Math.abs(VO) + Math.abs(LO));
          if (Math.min(QO, zK, AO) > fO || Math.max(QO, zK, AO) < -fO) return !1
        }
      }
      return !0
    }
    const Ap = new Float32Array(1);
    new Uint32Array(Ap.buffer);
    var fp = pO(37131);

    function dp(OO) {
      const [KO, pO, XO] = fp.r;
      return `struct BloxdSpSunShadow {\n\teyeChunk: vec3i,\n\tstaleCount: u32,\n\tvolumeLo: vec3i,\n\tentityX: vec4f,\n\tentityY: vec4f,\n\tstale: array<vec4i, 4>,\n}\n@group(${OO.group}) @binding(${OO.uniform}) var<uniform> bloxdSpSunShadow: BloxdSpSunShadow;\nfn bloxdSpVolumeTexel(cell: vec3i) -> vec3i {\n\treturn cell & vec3i(${KO-1}, ${pO-1}, ${XO-1});\n}\n`
    }

    function Tp(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
        XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      const [bK, eO, lO] = YK, [vK, CO, hO] = jp, DO = Math.log2(EK), MO = XO ? "var<private> bloxdSpCrossed: bool;\n" : "", aK = XO ? "\t\t\tbloxdSpCrossed = true;\n" : "";
      return `@group(${OO.group}) @binding(${OO.PK}) var<storage, read> bloxdSpShadowVoxels: array<u32>;\n@group(${OO.group}) @binding(${OO.special}) var<storage, read> bloxdSpShadowSpecial: array<u32>;\n${pO?"var<private> bloxdSpPlaneTolerance: f32;\n":""}${MO}struct BloxdSpBoxExit {\n\tt: f32,\n\taxis: i32,\n\tcell: vec3i,\n}\n// inv: 1 / d, 0 where d is, taken once per ray rather than divided per exit\nfn bloxdSpExitBox(o: vec3f, d: vec3f, inv: vec3f, lo: vec3i, offset: vec3i, size: i32) -> BloxdSpBoxExit {\n\tlet low = vec3f(lo - offset);\n\tlet far = select(low, low + f32(size), d > vec3f(0.0));\n\tlet ta = select(vec3f(1e30), (far - o) * inv, d != vec3f(0.0));\n\tvar axis = 0;\n\tvar t = ta.x;\n\tif (ta.y < t) {\n\t\tt = ta.y;\n\t\taxis = 1;\n\t}\n\tif (ta.z < t) {\n\t\tt = ta.z;\n\t\taxis = 2;\n\t}\n\tlet inside = clamp(vec3i(floor(o + t * d)) + offset, lo, lo + vec3i(size - 1));\n\tlet beyond = select(lo - vec3i(1), lo + vec3i(size), d > vec3f(0.0));\n\t// select, not cell[axis] = beyond[axis]: dynamic indexing spills the vector to memory on some drivers (~9% of the frame on Mali)\n\tlet cell = select(inside, beyond, vec3<bool>(axis == 0, axis == 1, axis == 2));\n\treturn BloxdSpBoxExit(t, axis, cell);\n}\nfn bloxdSpMaskBit(word: u32, bit: u32) -> bool {\n\treturn ((bloxdSpShadowSpecial[word + (bit >> 5u)] >> (bit & 31u)) & 1u) == 1u;\n}\nfn bloxdSpCasterBlocks(caster: u32, o: vec3f, d: vec3f, cell: vec3i, offset: vec3i, t0: f32, t1: f32, axis: i32) -> bool {\n\tlet base = 0u + caster * 4u;\n\tlet kind = bloxdSpShadowSpecial[base];\n\tlet data = bloxdSpShadowSpecial[base + 1u];\n\t// Every loop here has a fixed bound, whatever the buffers hold: a GPU stuck in one loses the device\n\tlet count = min(bloxdSpShadowSpecial[base + 2u], 4u);\n\tlet size = bloxdSpShadowSpecial[base + 3u];\n\tlet q = o - vec3f(cell - offset);\n\tif (kind == ${tp}u) {\n\t\tlet qs = q * 8.0;\n\t\tlet ds = d * 8.0;\n\t\tlet invs = select(vec3f(0.0), 1.0 / ds, ds != vec3f(0.0));\n\t\tvar sub = clamp(vec3i(floor(qs + t0 * ds)), vec3i(0), vec3i(7));\n\t\tfor (var step = 0; step < 24; step++) {\n\t\t\tif (bloxdSpMaskBit(data, u32(sub.x + 8 * (sub.y + 8 * sub.z)))) {\n\t\t\t\treturn true;\n\t\t\t}\n\t\t\tlet exit = bloxdSpExitBox(qs, ds, invs, sub, vec3i(0), 1);\n\t\t\t// Only the axis it left by can be out of the shape\n\t\t\tif (exit.t >= t1 || any(exit.cell < vec3i(0)) || any(exit.cell >= vec3i(8))) {\n\t\t\t\treturn false;\n\t\t\t}\n\t\t\tsub = exit.cell;\n\t\t}\n\t\treturn false;\n\t}\n\tlet fs = f32(size);\n\tif (kind == ${kp}u) {\n\t\tfor (var p = 0u; p < count; p++) {\n\t\t\tlet plane = data + p * 4u;\n\t\t\tlet tx = bitcast<f32>(bloxdSpShadowSpecial[plane]);\n\t\t\tlet tz = bitcast<f32>(bloxdSpShadowSpecial[plane + 1u]);\n\t\t\tlet along = bitcast<f32>(bloxdSpShadowSpecial[plane + 2u]);\n\t\t\tlet dn = d.x * tz - d.z * tx;\n\t\t\tif (abs(dn) < 1e-6) {\n\t\t\t\tcontinue;\n\t\t\t}\n\t\t\tlet t = (along - ((q.x - 0.5) * tz - (q.z - 0.5) * tx)) / dn;\n\t\t\t// Not a plane the trace starts on (SUN_SHADOW_PLANE_START), nor in its first cell one within depth's error of it\n\t\t\tif (t < select(t0, t0 + 0.0009765625, axis < 0) || t > t1${pO?" || (axis < 0 && abs(t * dn) < bloxdSpPlaneTolerance)":""}) {\n\t\t\t\tcontinue;\n\t\t\t}\n\t\t\tlet h = q + t * d;\n\t\t\tlet u = (h.x - 0.5) * tx + (h.z - 0.5) * tz + 0.5;\n\t\t\tlet v = 1.0 - h.y;\n\t\t\tif (u < 0.0 || u >= 1.0 || v < 0.0 || v >= 1.0) {\n\t\t\t\tcontinue;\n\t\t\t}\n\t\t\tif (bloxdSpMaskBit(bloxdSpShadowSpecial[plane + 3u], u32(floor(u * fs)) + size * u32(floor(v * fs)))) {\n\t\t\t\treturn true;\n\t\t\t}\n\t\t}\n\t\treturn false;\n\t}\n\tif (kind == ${UK}u && axis >= 0) {\n\t\t// In through the +axis face going down the axis, else the -axis face; faces go +x, -x, +y, -y, +z, -z\n\t\tlet plusFace = d[axis] < 0.0;\n\t\tlet face = u32(2 * axis) + select(1u, 0u, plusFace);\n\t\tlet h = clamp(q + t0 * d, vec3f(0.0), vec3f(1.0));\n\t\t// As terrain samples faces (terrainShader.ts packedUv)\n\t\tvar uv = vec2f(select(h.x, 1.0 - h.x, plusFace), 1.0 - h.y);\n\t\tif (axis == 0) {\n\t\t\tuv = vec2f(select(1.0 - h.z, h.z, plusFace), 1.0 - h.y);\n\t\t} else if (axis == 1) {\n\t\t\tuv = vec2f(select(1.0 - h.x, h.x, plusFace), 1.0 - h.z);\n\t\t}\n\t\tlet texel = min(vec2u(floor(uv * fs)), vec2u(size - 1u));\n\t\treturn bloxdSpMaskBit(data + face * ((size * size + 31u) / 32u), texel.x + size * texel.y);\n\t}\n\treturn false;\n}\nfn bloxdSpWindowSlot(chunk: vec3i) -> u32 {\n\tlet window = vec3i(${bK}, ${eO}, ${lO});\n\tlet r = chunk % window;\n\tlet s = select(r, r + window, r < vec3i(0));\n\treturn u32(s.x + ${bK} * (s.y + ${eO} * s.z));\n}\nfn bloxdSpWindowHas(chunk: vec3i) -> bool {\n\treturn all(abs(chunk - bloxdSpSunShadow.eyeChunk) <= vec3i(${vK}, ${CO}, ${hO}));\n}\nfn bloxdSpCellFull(cell: vec3i) -> bool {\n\tlet chunk = cell >> vec3u(${DO}u);\n\tif (!bloxdSpWindowHas(chunk)) {\n\t\treturn false;\n\t}\n\tlet slot = bloxdSpWindowSlot(chunk);\n\tlet record = slot * 4u;\n\tlet named = all(bitcast<vec3i>(vec3u(bloxdSpShadowVoxels[record], bloxdSpShadowVoxels[record + 1u], bloxdSpShadowVoxels[record + 2u])) == chunk);\n\tlet state = bloxdSpShadowVoxels[record + 3u] & 255u;\n\tif (!named || state != ${mp}u) {\n\t\treturn named && state == ${PK}u;\n\t}\n\tlet local = cell - chunk * 32;\n\tlet brick = u32((local.x >> 2u) + 8 * ((local.y >> 2u) + 8 * (local.z >> 2u)));\n\tlet brickBase = ${RK}u + slot * 1536u + brick * 3u;\n\tlet bit = u32((local.x & 3) + 4 * ((local.y & 3) + 4 * (local.z & 3)));\n\tif (((bloxdSpShadowVoxels[brickBase + (bit >> 5u)] >> (bit & 31u)) & 1u) == 0u) {\n\t\treturn false;\n\t}\n\tlet pool = bloxdSpShadowVoxels[brickBase + 2u];\n\tif (pool == 0u) {\n\t\treturn true;\n\t}\n\tlet entry = bloxdSpShadowSpecial[294912u + (pool - 1u) * 32u + (bit >> 1u)];\n\treturn ((entry >> ((bit & 1u) * 16u)) & 0xffffu) == 65535u;\n}\n// ownCell: whether the caster in the cell it starts in can block it (sunShadowTrace.ts traceSunShadow)\nfn bloxdSpShadowMarch(o: vec3f, d: vec3f, offset: vec3i, maxSteps: i32, ownCell: bool) -> vec4f {\n\tvar cell = vec3i(floor(o)) + offset;\n\tvar t = 0.0;\n\tvar axis = -1;\n\tlet inv = select(vec3f(0.0), 1.0 / d, d != vec3f(0.0));\n\t// The chunk the slot and record were read for: they change only with it\n\tvar cached = vec3i(-2147483647);\n\tvar slot = 0u;\n\tvar named = false;\n\tvar state = 0u;\n\t// Rising above the window's highest cell that may block, it crosses nothing more (0: never written)\n\tlet windowWord = bloxdSpShadowVoxels[${JK}u];\n\tlet windowTop = select(2147483647, bitcast<i32>(windowWord) - 1073741824, d.y > 0.0 && windowWord != 0u);\n${KO?"\tlet exits = bloxdSpRayFresh(o, d, offset);\n":""}\tfor (var step = 0; step < maxSteps; step++) {\n${KO?`\t\tif (exits && step > 0 && step % ${yX} == 0 && bloxdSpVolumeOpenLit(o + t * d, offset)) {\n\t\t\treturn vec4f(o + t * d, -1.0);\n\t\t}\n`:""}\t\tif (cell.y > windowTop) {\n\t\t\treturn vec4f(o + t * d, 1.0);\n\t\t}\n\t\tlet chunk = cell >> vec3u(${DO}u);\n\t\tif (any(chunk != cached)) {\n\t\t\tif (!bloxdSpWindowHas(chunk)) {\n\t\t\t\treturn vec4f(o + t * d, 1.0);\n\t\t\t}\n\t\t\tcached = chunk;\n\t\t\tslot = bloxdSpWindowSlot(chunk);\n\t\t\tlet record = slot * 4u;\n\t\t\tnamed = all(bitcast<vec3i>(vec3u(bloxdSpShadowVoxels[record], bloxdSpShadowVoxels[record + 1u], bloxdSpShadowVoxels[record + 2u])) == chunk);\n\t\t\tstate = bloxdSpShadowVoxels[record + 3u];\n\t\t}\n\t\tlet chunkLo = chunk * 32;\n\t\tlet kind = state & 255u;\n\t\t// Rising above its highest cell that may block, it crosses nothing more in the chunk\n\t\tif (!named || kind == ${ip}u || kind == ${rp}u || (d.y > 0.0 && cell.y - chunkLo.y > i32(state >> 8u))) {\n\t\t\tlet exit = bloxdSpExitBox(o, d, inv, chunkLo, offset, 32);\n\t\t\tt = max(t, exit.t);\n\t\t\taxis = exit.axis;\n\t\t\tcell = exit.cell;\n\t\t\tcontinue;\n\t\t}\n\t\tif (kind == ${PK}u) {\n\t\t\treturn vec4f(o + t * d, 0.0);\n\t\t}\n\t\tlet local = cell - chunkLo;\n\t\tlet brick = u32((local.x >> 2u) + 8 * ((local.y >> 2u) + 8 * (local.z >> 2u)));\n\t\tlet brickBase = ${RK}u + slot * 1536u + brick * 3u;\n\t\tlet low = bloxdSpShadowVoxels[brickBase];\n\t\tlet high = bloxdSpShadowVoxels[brickBase + 1u];\n\t\tif (low == 0u && high == 0u) {\n\t\t\tlet exit = bloxdSpExitBox(o, d, inv, chunkLo + (local & vec3i(~3)), offset, 4);\n\t\t\tt = max(t, exit.t);\n\t\t\taxis = exit.axis;\n\t\t\tcell = exit.cell;\n\t\t\tcontinue;\n\t\t}\n\t\tlet bit = u32((local.x & 3) + 4 * ((local.y & 3) + 4 * (local.z & 3)));\n\t\tlet exit = bloxdSpExitBox(o, d, inv, cell, offset, 1);\n\t\tif (((select(high, low, bit < 32u) >> (bit & 31u)) & 1u) == 1u) {\n\t\t\tlet pool = bloxdSpShadowVoxels[brickBase + 2u];\n\t\t\tif (pool == 0u) {\n\t\t\t\treturn vec4f(o + t * d, 0.0);\n\t\t\t}\n\t\t\tlet entry = bloxdSpShadowSpecial[294912u + (pool - 1u) * 32u + (bit >> 1u)];\n\t\t\tlet caster = (entry >> ((bit & 1u) * 16u)) & 0xffffu;\n\t\t\tif (caster == 65535u || ((ownCell || axis >= 0) && bloxdSpCasterBlocks(caster, o, d, cell, offset, t, exit.t, axis))) {\n\t\t\t\treturn vec4f(o + t * d, 0.0);\n\t\t\t}\n${aK}\t\t}\n\t\tt = max(t, exit.t);\n\t\taxis = exit.axis;\n\t\tcell = exit.cell;\n\t}\n\treturn vec4f(o + t * d, -1.0);\n}\n`
    }
    const Np = {
      group: 0,
      uniform: 0,
      PK: 1,
      special: 2,
      work: 3,
      volume: 4
    };

    function Ip() {
      const OO = Np;
      return `${dp(OO)}${Tp(OO,!1,!1,!0)}struct BloxdSpVolumeBox {\n\tlo: vec3i,\n\tfirst: u32,\n\tsize: vec3u,\n}\nstruct BloxdSpVolumeWork {\n\tlight: vec3f,\n\tboxes: u32,\n\tbox: array<BloxdSpVolumeBox, ${fp.d}>,\n}\n@group(${OO.group}) @binding(${OO.work}) var<uniform> bloxdSpVolumeWork: BloxdSpVolumeWork;\n@group(${OO.group}) @binding(${OO.volume}) var bloxdSpVolumeOut: texture_storage_3d<rgba8unorm, write>;\n@compute @workgroup_size(${fp.k})\nfn main(@builtin(global_invocation_id) id: vec3u) {\n\tvar at = 0u;\n\tlet boxes = min(bloxdSpVolumeWork.boxes, ${fp.d}u);\n\tfor (var b = 1u; b < boxes; b++) {\n\t\tif (id.x >= bloxdSpVolumeWork.box[b].first) {\n\t\t\tat = b;\n\t\t}\n\t}\n\tlet box = bloxdSpVolumeWork.box[at];\n\tlet index = id.x - box.first;\n\tif (index >= box.size.x * box.size.y * box.size.z) {\n\t\treturn;\n\t}\n\tlet r = box.lo + vec3i(vec3u(index % box.size.x, (index / box.size.x) % box.size.y, index / (box.size.x * box.size.y)));\n\t// From the cell's centre, relative to the volume's corner: exact in f32\n\tlet lo = bloxdSpSunShadow.volumeLo;\n\tlet cell = lo + r;\n\tlet open = !bloxdSpCellFull(cell);\n\tvar lit = 0.0;\n\tbloxdSpCrossed = false;\n\tif (open) {\n\t\t// Past its own caster: a cell's light is what reaches it (sunShadowVolume.ts sunShadowVolumeCell)\n\t\tlet march = bloxdSpShadowMarch(vec3f(r) + vec3f(0.5), bloxdSpVolumeWork.light, lo, ${fp.h}, false);\n\t\tlit = select(march.w, 1.0, march.w < 0.0);\n\t}\n\ttextureStore(bloxdSpVolumeOut, bloxdSpVolumeTexel(cell), vec4f(lit, select(0.0, 1.0, open), select(0.0, 1.0, lit == 1.0 && !bloxdSpCrossed), 1.0));\n}\n`
    }
    const yX = 2;
    const gX = "fn bloxdSpNormalCode(n: vec3f) -> f32 {\n\tlet a = abs(n);\n\tif (a.x >= a.y && a.x >= a.z) {\n\t\treturn select(1.0, 0.0, n.x > 0.0);\n\t}\n\tif (a.y >= a.z) {\n\t\treturn select(3.0, 2.0, n.y > 0.0);\n\t}\n\treturn select(5.0, 4.0, n.z > 0.0);\n}\n";

    function upO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "trace";
      const XO = `var<private> bloxdSpShadowPosition: vec3f;\nfn bloxdSpShadowLight() -> vec4f {\n\t// Towards the sun or moon, as the CPU works it out (sunShadowLight)\n\tlet bloxdSpLight = -${KO.shadowDirection};\n\treturn vec4f(bloxdSpLight, smoothstep(0.0, 0.1, bloxdSpLight.y));\n}\n`,
        bK = "trace" === pO || "lit" === pO,
        eO = "maskEdge" === pO ? "bloxdSpMaskEdge()" : "textureLoad(bloxdSpShadowMask, bloxdSpShadowPixel, 0).r",
        lO = bK ? `\tlet bloxdSpOrigin = bloxdSpShadowPosition + bloxdSpShadowNormal * 0.25;\n\tlet bloxdSpMarch = bloxdSpShadowMarch(bloxdSpOrigin, bloxdSpLight.xyz, ${KO.renderOffset}, 64, true);\n\tvar bloxdSpLit = bloxdSpMarch.w;\n\tif (bloxdSpLit < 0.0) {\n\t\t// Out of steps, or open and lit from here: on from the volume, from where it got to\n\t\tbloxdSpLit = bloxdSpVolumeAt(bloxdSpMarch.xyz, ${KO.renderOffset});\n\t}\n\tif (bloxdSpLit > 0.0 && !bloxdSpShadowFirstPerson) {\n\t\t// Lifeforms and items, but not on the first-person held item, which the body you're in would shade as you turn\n\t\tbloxdSpLit *= bloxdSpEntityLight(bloxdSpShadowPosition, bloxdSpLight.xyz, bloxdSpFacingDot);\n\t}\n\treturn ${"lit"===pO?"bloxdSpLit":"bloxdSpLight.w * bloxdSpFacing * bloxdSpLit"};\n` : `\treturn bloxdSpLight.w * bloxdSpFacing * ${eO};\n`;
      return `${XO}${OO.sunShadow?`var<private> bloxdSpShadowNormal: vec3f;\nvar<private> bloxdSpShadowEmissive: bool;\nvar<private> bloxdSpShadowFirstPerson: bool;\n${bK?function(){const[OO,KO,pO]=fp.r;return`fn bloxdSpRayFresh(o: vec3f, d: vec3f, offset: vec3i) -> bool {\n\tif (bloxdSpSunShadow.staleCount > 4u) {\n\t\treturn false;\n\t}\n\tlet inv = select(vec3f(1e30), 1.0 / d, d != vec3f(0.0));\n\tlet count = bloxdSpSunShadow.staleCount;\n\tfor (var b = 0u; b < count; b++) {\n\t\tlet lo = vec3f(bloxdSpSunShadow.stale[b].xyz - offset) - 1.0;\n\t\tlet a = (lo - o) * inv;\n\t\tlet z = (lo + 34.0 - o) * inv;\n\t\tlet near = max(max(min(a.x, z.x), min(a.y, z.y)), min(a.z, z.z));\n\t\tlet far = min(min(max(a.x, z.x), max(a.y, z.y)), max(a.z, z.z));\n\t\tif (far >= max(near, 0.0)) {\n\t\t\treturn false;\n\t\t}\n\t}\n\treturn true;\n}\nfn bloxdSpVolumeOpenLit(p: vec3f, offset: vec3i) -> bool {\n\tlet lo = bloxdSpSunShadow.volumeLo;\n\tlet size = vec3f(${OO}.0, ${KO}.0, ${pO}.0);\n\tlet r = p - vec3f(lo - offset);\n\tif (any(r < vec3f(0.5)) || any(r > size - vec3f(0.5))) {\n\t\treturn false;\n\t}\n\tlet sample = textureSampleLevel(bloxdSpShadowVolume, bloxdSpShadowVolumeSampler, (r + vec3f(bloxdSpVolumeTexel(lo))) / size, 0.0);\n\treturn sample.b >= 0.999;\n}\n`}():""}fn bloxdShadow() -> f32 {\n\tlet bloxdSpLight = bloxdSpShadowLight();\n\t// A face lit by its own light\n\tif (bloxdSpShadowEmissive) {\n\t\treturn 1.0;\n\t}\n\tlet bloxdSpFacingDot = dot(bloxdSpShadowNormal, bloxdSpLight.xyz);\n\tlet bloxdSpFacing = smoothstep(0.0, 0.5, bloxdSpFacingDot);\n\tif (bloxdSpLight.w <= 0.0 || bloxdSpFacing <= 0.0) {\n\t\treturn 0.0;\n\t}\n${lO}}\n`:""}${OO.airShadow?`fn bloxdAirShadow(bloxdSpT: f32) -> f32 {\n\tlet bloxdSpLight = bloxdSpShadowLight();\n\tlet bloxdSpAt = mix(${KO.eyePosition}, bloxdSpShadowPosition, clamp(bloxdSpT, 0.0, 1.0));\n\treturn bloxdSpLight.w * bloxdSpVolumeAt(bloxdSpAt, ${KO.renderOffset});\n}\n`:""}`
    }
    const Ep = "bloxdSpOwnTexture";

    function jX(OO) {
      return `u32(clamp(round(bloxdSpMipLevel), 0.0, f32(textureNumLevels(${OO.texture}) - 1u)))`
    }
    const Yp = `fn bloxdSpFlags(bloxdSpWord: u32) -> BloxdFlags {\n\tvar bloxdSpOut: BloxdFlags;\n${CK.f.map((OO=>{let[KO,pO]=OO;return`\tbloxdSpOut.${KO} = (bloxdSpWord & ${pO}u) != 0u;\n`})).join("")}\treturn bloxdSpOut;\n}\n`;

    function wp(OO) {
      return `bloxdSpFlags(${OO})`
    }
    const iX = `${gp.j}.eyePosition`;

    function rX(OO, KO, pO, XO, bK) {
      const eO = OO.indexOf(KO);
      if (eO < 0 || OO.indexOf(KO, eO + 1) >= 0) throw new Error(`Lite's ${bK} program changed at the shader pack ${XO} hook: ${eO<0?"no":"more than one"} anchor (lite/${bK}ShaderPack.ts)`);
      return OO.slice(0, eO) + pO + OO.slice(eO + KO.length)
    }

    function Pp(OO) {
      return OO.sunShadow || OO.airShadow
    }

    function mX(OO, KO) {
      return KO && Pp(OO)
    }
    const sp = {
      group: gp.d,
      ...gp.s
    };

    function Hp(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "trace";
      if (!Pp(OO)) return "";
      if (KO) {
        const KO = sp,
          bK = "trace" === pO || "lit" === pO;
        let eO = "";
        OO.sunShadow && (eO = bK ? `${Tp(KO,!0,"lit"===pO)}${XO=KO,`@group(${XO.group}) @binding(${XO.entities}) var<storage, read> bloxdSpShadowEntities: array<u32>;\n@group(${XO.group}) @binding(${XO.entityGrids}) var<storage, read> bloxdSpShadowEntityGrids: array<u32>;\nfn bloxdSpEntityRow(i: u32) -> vec4f {\n\treturn bitcast<vec4f>(vec4u(bloxdSpShadowEntities[i], bloxdSpShadowEntities[i + 1u], bloxdSpShadowEntities[i + 2u], bloxdSpShadowEntities[i + 3u]));\n}\nfn bloxdSpEntityLight(p: vec3f, light: vec3f, facing: f32) -> f32 {\n\tlet p4 = vec4f(p, 1.0);\n\tlet across = vec2f(dot(bloxdSpSunShadow.entityX, p4), dot(bloxdSpSunShadow.entityY, p4));\n\tif (any(abs(across) >= vec2f(1.0))) {\n\t\treturn 1.0;\n\t}\n\tlet bin = vec2u(clamp(vec2i(floor((across * 0.5 + 0.5) * 128.0)), vec2i(0), vec2i(127)));\n\tlet b = bin.y * 128u + bin.x;\n\tlet start = bloxdSpShadowEntities[b];\n\tlet count = min(bloxdSpShadowEntities[b + 1u] - start, 64u);\n\tlet along = dot(p, light);\n\tfor (var k = 0u; k < count; k++) {\n\t\tlet base = 81921u + bloxdSpShadowEntities[16385u + start + k] * 16u;\n\t\t// Ending before the fragment along the light, as do those after it: their rays can't meet them\n\t\tif (bitcast<f32>(bloxdSpShadowEntities[base + 13u]) < along) {\n\t\t\tbreak;\n\t\t}\n\t\tlet r0 = bloxdSpEntityRow(base);\n\t\tlet r1 = bloxdSpEntityRow(base + 4u);\n\t\tlet r2 = bloxdSpEntityRow(base + 8u);\n\t\tlet packed = bloxdSpShadowEntities[base + 14u];\n\t\tlet dims = vec3u(packed & 0xffu, (packed >> 8u) & 0xffu, packed >> 16u);\n\t\t// In cells from the grid's low corner, and per unit along the light\n\t\tlet q = vec3f(dot(r0, p4), dot(r1, p4), dot(r2, p4));\n\t\t// Its rows' least squared length: the square of 1 over its largest scale, in cells\n\t\tlet shortest = min(min(dot(r0.xyz, r0.xyz), dot(r1.xyz, r1.xyz)), dot(r2.xyz, r2.xyz));\n\t\tvar dq = vec3f(dot(r0.xyz, light), dot(r1.xyz, light), dot(r2.xyz, light));\n\t\tdq = select(dq, vec3f(1e-9), abs(dq) < vec3f(1e-9));\n\t\tlet inv = 1.0 / dq;\n\t\tlet size = vec3f(dims);\n\t\tlet ta = -q * inv;\n\t\tlet tb = (size - q) * inv;\n\t\tlet tlo = min(ta, tb);\n\t\tlet thi = max(ta, tb);\n\t\t// Off the face's plane, past the cells around its own surface: its largest cells, over how fast the light leaves the\n\t\t// plane (finite as the face turns away)\n\t\tlet t0 = max(max(tlo.x, tlo.y), max(tlo.z, 2.0 * inverseSqrt(shortest) / max(facing, 1e-3)));\n\t\tlet t1 = min(min(thi.x, thi.y), thi.z);\n\t\tif (t0 >= t1) {\n\t\t\tcontinue;\n\t\t}\n\t\tlet up = dq > vec3f(0.0);\n\t\tvar at = vec3i(clamp(floor(q + dq * t0), vec3f(0.0), size - 1.0));\n\t\tlet step = select(vec3i(-1), vec3i(1), up);\n\t\tlet delta = abs(inv);\n\t\tvar next = (vec3f(at) + select(vec3f(0.0), vec3f(1.0), up) - q) * inv;\n\t\tlet data = bloxdSpShadowEntities[base + 12u];\n\t\tfor (var s = 0; s < 198; s++) {\n\t\t\tlet index = u32(at.x) + dims.x * (u32(at.y) + dims.y * u32(at.z));\n\t\t\tif ((bloxdSpShadowEntityGrids[data + (index >> 5u)] & (1u << (index & 31u))) != 0u) {\n\t\t\t\treturn 0.0;\n\t\t\t}\n\t\t\tif (next.x <= next.y && next.x <= next.z) {\n\t\t\t\tat.x += step.x;\n\t\t\t\tnext.x += delta.x;\n\t\t\t} else if (next.y <= next.z) {\n\t\t\t\tat.y += step.y;\n\t\t\t\tnext.y += delta.y;\n\t\t\t} else {\n\t\t\t\tat.z += step.z;\n\t\t\t\tnext.z += delta.z;\n\t\t\t}\n\t\t\tif (any(at < vec3i(0)) || any(at >= vec3i(dims))) {\n\t\t\t\tbreak;\n\t\t\t}\n\t\t}\n\t}\n\treturn 1.0;\n}\n`}` : function(OO, KO, pO) {
          const XO = `@group(${OO}) @binding(${KO}) var bloxdSpShadowMask: texture_2d<f32>;\nvar<private> bloxdSpShadowPixel: vec2i;\n`;
          return pO ? `${XO}var<private> bloxdSpShadowZ: f32;\nvar<private> bloxdSpShadowDz: vec2f;\n${gX}fn bloxdSpMaskEdge() -> f32 {\n\tlet code = bloxdSpNormalCode(bloxdSpShadowNormal);\n\tlet tolerance = abs(bloxdSpShadowDz.x) + abs(bloxdSpShadowDz.y) + 1e-7;\n\tlet m = textureLoad(bloxdSpShadowMask, bloxdSpShadowPixel, 0);\n\tlet mCode = floor(m.r * 0.5);\n\tlet mError = select(1e30, abs(m.g - bloxdSpShadowZ), mCode == code);\n\tif (mError <= tolerance) {\n\t\treturn m.r - mCode * 2.0;\n\t}\n\tlet last = vec2i(textureDimensions(bloxdSpShadowMask)) - 1;\n\tvar lit = m.r - mCode * 2.0;\n\tvar error = mError;\n${["-1, 0","1, 0","0, -1","0, 1"].map((OO=>`\t{\n\t\tlet o = vec2i(${OO});\n\t\tlet q = textureLoad(bloxdSpShadowMask, clamp(bloxdSpShadowPixel + o, vec2i(0), last), 0);\n\t\tlet qCode = floor(q.r * 0.5);\n\t\tlet e = abs(q.g - (bloxdSpShadowZ + dot(vec2f(o), bloxdSpShadowDz)));\n\t\tif (qCode == code && e < error) {\n\t\t\terror = e;\n\t\t\tlit = q.r - qCode * 2.0;\n\t\t}\n\t}\n`)).join("")}\treturn lit;\n}\n` : XO
        }(KO.group, gp.u, "maskEdge" === pO));
        const lO = {
          shadowDirection: `${gp.j}.shadowDirection`,
          renderOffset: `${gp.j}.renderOffset`,
          eyePosition: `${gp.j}.eyePosition`
        };
        return `${dp(KO)}${eO}${function(OO){const[KO,pO,XO]=fp.r;return`@group(${OO.group}) @binding(${OO.volume}) var bloxdSpShadowVolume: texture_3d<f32>;\n@group(${OO.group}) @binding(${OO.sampler}) var bloxdSpShadowVolumeSampler: sampler;\nfn bloxdSpVolumeAt(p: vec3f, offset: vec3i) -> f32 {\n\tlet lo = bloxdSpSunShadow.volumeLo;\n\tlet size = vec3f(${KO}.0, ${pO}.0, ${XO}.0);\n\t// From the volume's low corner, in whole blocks either side, so f32 keeps it exact\n\tlet r = p - vec3f(lo - offset);\n\tif (any(r < vec3f(0.0)) || any(r > size)) {\n\t\treturn 1.0;\n\t}\n\t// Clear of the edges, where filtering would wrap onto the far side\n\tlet uvw = (clamp(r, vec3f(0.5), size - vec3f(0.5)) + vec3f(bloxdSpVolumeTexel(lo))) / size;\n\tlet sample = textureSampleLevel(bloxdSpShadowVolume, bloxdSpShadowVolumeSampler, uvw, 0.0);\n\tif (sample.g < 0.03125) {\n\t\treturn 1.0;\n\t}\n\treturn min(sample.r / sample.g, 1.0);\n}\n`}(KO)}${upO(OO,lO,pO)}`
      }
      var XO;
      return `${OO.sunShadow?"fn bloxdShadow() -> f32 {\n\treturn 1.0;\n}\n":""}${OO.airShadow?"fn bloxdAirShadow(bloxdSpT: f32) -> f32 {\n\treturn 1.0;\n}\n":""}`
    }

    function Rp(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "trace";
      if (!KO) return "";
      const eO = (lO = "fragmentInputs.vPositionW", vK = OO.sunShadow ? {
        normal: pO,
        flags: XO
      } : null, `\n\tbloxdSpShadowPosition = ${lO};\n${vK?`\tbloxdSpShadowNormal = normalize(${vK.normal});\n\tbloxdSpShadowEmissive = (${vK.flags} & ${CK.d.emissive}u) != 0u;\n\tbloxdSpShadowFirstPerson = (${vK.flags} & ${CK.g}u) != 0u;\n`:""}`);
      var lO, vK;
      return OO.sunShadow && ("mask" === bK || "maskEdge" === bK) ? `${eO}${CO="fragmentInputs.position",hO="maskEdge"===bK,`\n\tbloxdSpShadowPixel = vec2i(${CO}.xy);\n${hO?`\tbloxdSpShadowZ = ${CO}.z;\n\tbloxdSpShadowDz = vec2f(dpdx(${CO}.z), dpdy(${CO}.z));\n`:""}`}` : eO;
      var CO, hO
    }
    const Sp = "bloxdSpTextureRotation",
      Jp = "bloxdSpTextureLayers",
      cX = `@group(${gp.d}) @binding(${gp.x}) var<storage, read> ${Jp}: array<u32>;\n`;

    function Bp(OO) {
      return `\tvertexOutputs.vPackTexture = ${Jp}[min(u32(${OO}), arrayLength(&${Jp}) - 1u)];\n`
    }

    function Zp(OO) {
      return void 0 !== OO.uv
    }

    function Gp(OO) {
      if (!OO) return "fn bloxdTextureSize(bloxdSpMipLevel: f32) -> vec2u {\n\treturn vec2u(1u);\n}\nfn bloxdTexel(bloxdSpTextureId: u32, bloxdSpUv: vec2f, bloxdSpMipLevel: f32) -> vec4f {\n\treturn vec4f(1.0);\n}\n";
      if (Zp(OO)) return function(OO) {
        const {
          texture: KO,
          cells: pO,
          layers: XO
        } = OO, bK = `textureDimensions(${KO}, bloxdSpLevel)`, eO = pO ? `max(vec2u(vec2f(${bK}) / ${pO}), vec2u(1u))` : bK, lO = pO ? `fn bloxdSpOwnTexel(bloxdSpCellIndex: f32, bloxdSpUv: vec2f, bloxdSpLevel: u32) -> vec4f {\n\tlet bloxdSpSize = ${eO};\n\tlet bloxdSpIndex = u32(round(bloxdSpCellIndex));\n\tlet bloxdSpAcross = max(u32(round(${pO}.x)), 1u);\n\tlet bloxdSpDown = max(u32(round(${pO}.y)), 1u);\n\tlet bloxdSpAt = min(vec2u(fract(bloxdSpUv) * vec2f(bloxdSpSize)), bloxdSpSize - 1u);\n\tlet bloxdSpCellAt = vec2u(bloxdSpIndex % bloxdSpAcross, bloxdSpIndex / bloxdSpAcross % bloxdSpDown);\n\treturn textureLoad(${KO}, min(bloxdSpCellAt * bloxdSpSize + bloxdSpAt, ${bK} - 1u), bloxdSpLevel);\n}\n` : `fn bloxdSpOwnTexel(bloxdSpUv: vec2f, bloxdSpLevel: u32) -> vec4f {\n\tlet bloxdSpSize = ${eO};\n\tlet bloxdSpAt = min(vec2u(fract(bloxdSpUv) * vec2f(bloxdSpSize)), bloxdSpSize - 1u);\n\treturn textureLoad(${KO}, bloxdSpAt, bloxdSpLevel);\n}\n`;
        let vK;
        if (pO)
          if (1 === XO.length) vK = `\treturn bloxdSpOwnTexel(${XO[0]}, bloxdSpUv, bloxdSpLevel);\n`;
          else {
            const OO = XO.length - 1;
            vK = `\tvar bloxdSpColour = bloxdSpOwnTexel(${XO[OO]}, bloxdSpUv, bloxdSpLevel);\n\tbloxdSpColour = vec4f(bloxdSpColour.rgb * bloxdSpColour.a, bloxdSpColour.a);\n`;
            for (let KO = OO - 1; KO >= 0; KO--) vK += `\t{\n\t\tlet bloxdSpLayer = bloxdSpOwnTexel(${XO[KO]}, bloxdSpUv, bloxdSpLevel);\n\t\tbloxdSpColour = vec4f(mix(bloxdSpColour.rgb, bloxdSpLayer.rgb, bloxdSpLayer.a), bloxdSpLayer.a + bloxdSpColour.a * (1.0 - bloxdSpLayer.a));\n\t}\n`;
            vK += "\treturn vec4f(bloxdSpColour.rgb / max(bloxdSpColour.a, 0.001), bloxdSpColour.a);\n"
          }
        else vK = "\treturn bloxdSpOwnTexel(bloxdSpUv, bloxdSpLevel);\n";
        return `${OO.id?`var<private> ${Ep}: u32;\n`:""}${lO}fn bloxdTextureSize(bloxdSpMipLevel: f32) -> vec2u {\n\tlet bloxdSpLevel = ${jX(OO)};\n\treturn ${eO};\n}\nfn bloxdTexel(bloxdSpTextureId: u32, bloxdSpUv: vec2f, bloxdSpMipLevel: f32) -> vec4f {\n\tif (bloxdSpTextureId != ${OO.id?Ep:"0u"}) {\n\t\treturn vec4f(1.0);\n\t}\n\tlet bloxdSpLevel = ${jX(OO)};\n${vK}}\n`
      }(OO);
      const KO = OO,
        pO = OO => {
          const pO = OO > 0 ? `bloxdSpLayer - ${KO.layers*OO}u` : "bloxdSpLayer";
          return `return textureSampleLevel(textureAtlas${OO}, ${KO.sampler}, bloxdSpTurned, ${pO}, round(bloxdSpMipLevel));`
        };
      let XO = "";
      for (let eO = 0; eO < KO.count - 1; eO++) XO += `\tif (bloxdSpLayer < ${KO.layers*(eO+1)}u) {\n\t\t${pO(eO)}\n\t}\n`;
      const bK = KO.frame ? `${KO.frame("f32(bloxdSpTextureId - 1u)","let bloxdSpFrame = ")}\tlet bloxdSpLayer = u32(round(bloxdSpFrame));\n` : "\tlet bloxdSpLayer = bloxdSpTextureId - 1u;\n";
      return `var<private> ${Sp}: u32;\n${cX}fn bloxdTextureSize(bloxdSpMipLevel: f32) -> vec2u {\n\treturn textureDimensions(textureAtlas0, u32(clamp(round(bloxdSpMipLevel), 0.0, f32(textureNumLevels(textureAtlas0) - 1u))));\n}\nfn bloxdTexel(bloxdSpTextureId: u32, bloxdSpUv: vec2f, bloxdSpMipLevel: f32) -> vec4f {\n\tif (bloxdSpTextureId == 0u) {\n\t\treturn vec4f(1.0);\n\t}\n\t// Each quarter turn clockwise the face shows its texture at reads the unturned texture at (v, 1 - u)\n\tvar bloxdSpTurned = bloxdSpUv;\n\tif (${Sp} == 1u) {\n\t\tbloxdSpTurned = vec2f(bloxdSpUv.y, 1.0 - bloxdSpUv.x);\n\t} else if (${Sp} == 2u) {\n\t\tbloxdSpTurned = 1.0 - bloxdSpUv;\n\t} else if (${Sp} == 3u) {\n\t\tbloxdSpTurned = vec2f(1.0 - bloxdSpUv.y, bloxdSpUv.x);\n\t}\n${bK}${XO}\t${pO(KO.count-1)}\n}\n`
    }

    function qX(OO, KO, pO) {
      return !!OO.surface && "bloxdDefaultSurface" !== OO.surface && function(OO, KO) {
        return "liquid" === KO || !OO
      }(KO, pO)
    }

    function xX(OO, KO) {
      return OO.vertex ? `\n\t{\n\t\tlet bloxdSpVertexIn = BloxdVertexIn(worldPos.xyz, vertexOutputs.vNormalW, ${KO.vertexLocalPosition}, ${wp(KO.vertexFlags)});\n\t\tlet bloxdSpVertex = ${OO.vertex}(bloxdSpVertexIn);\n\t\tworldPos = vec4f(bloxdSpVertex.position, worldPos.w);\n\t}\n` : ""
    }

    function np(OO, KO, pO, XO, bK) {
      if (!OO.surface) return "";
      const eO = (OO, KO) => `\n\tlet bloxdSpTexelUV = ${OO};\n\tlet bloxdSpDdx = dpdx(bloxdSpTexelUV);\n\tlet bloxdSpDdy = dpdy(bloxdSpTexelUV);\n\tlet bloxdSpLod = 0.5 * log2(max(max(dot(bloxdSpDdx, bloxdSpDdx), dot(bloxdSpDdy, bloxdSpDdy)), 1e-10));\n\tlet bloxdSpMipLevel = clamp(bloxdSpLod, 0.0, f32(textureNumLevels(${KO}) - 1u));`;
      let lO = "",
        vK = "0u, 0u, vec2f(0.0), 0.0";
      const CO = XO && Zp(XO) ? XO : null,
        hO = XO && !Zp(XO) ? XO : null;
      if (CO) {
        lO = `${CO.id?`\n\tlet bloxdSpTexture = ${CO.id};\n\t${Ep} = bloxdSpTexture & 0xffffu;`:""}\n\tlet bloxdSpUv = ${CO.uv};${eO(function(OO,KO){var pO;return`${null!==(pO=OO.levelUv)&&void 0!==pO?pO:OO.cells?`${KO} / ${OO.cells}`:KO} * vec2f(textureDimensions(${OO.texture}))`}(CO,"bloxdSpUv"),CO.texture)}`, vK = (CO.id ? `${Ep}, bloxdSpTexture >> 16u` : "0u, 0u") + ", bloxdSpUv, bloxdSpMipLevel"
      } else hO && (lO = `\n\tlet bloxdSpTexture = fragmentInputs.vPackTexture;\n\t${Sp} = bloxdSpTexture >> 16u;${eO(`fragmentInputs.vMainUV1 * ${(0,NK.kb)(hO.width)}`,"textureAtlas0")}`, vK = `bloxdSpTexture & 0xffffu, ${Sp}, fragmentInputs.vMainUV1, bloxdSpMipLevel`);
      const DO = bK.overlayColour,
        MO = DO ? "mix(bloxdSpSurface.colour, bloxdSpSurface.overlayColour.rgb, bloxdSpSurface.overlayColour.a)" : "bloxdSpSurface.colour",
        aK = "bloxdDefaultSurface" !== OO.surface || DO ? `\n\tbaseColor = vec4f(${MO}, baseColor.a);` : "",
        oO = qX(OO, KO, pO) ? `\n\t${bK.alphaOut} = bloxdSpSurface.alpha;` : "";
      return `${lO}\n\tlet bloxdSpSurfaceIn = BloxdSurfaceIn(baseColor.rgb, ${bK.alpha}, ${bK.enchantTier}, ${bK.enchantColour}, ${bK.enchantSpeed}, ${null!==DO&&void 0!==DO?DO:"vec4f(0.0)"}, fragmentInputs.vPositionW, ${bK.normal}, ${bK.localPosition}, ${wp(bK.flags)}, ${vK});\n\tlet bloxdSpSurface = ${OO.surface}(bloxdSpSurfaceIn);${aK}${oO}\n`
    }
    const Wp = "bloxdSpLightIn";

    function tX(OO, KO, pO, XO) {
      if (!OO.light) return "";
      const bK = KO ? `${NK.h}.rgb, ${NK.h}.w, uniforms.uAmbientLightColour, uniforms.uSkyLightColour, ${NK.g}` : "vec3f(0.0), 1.0, vec3f(1.0), vec3f(1.0), vec3f(0.0)",
        {
          lambert: eO,
          diffuse: lO,
          emissive: vK,
          ambient: CO,
          fogColour: hO,
          fogAlpha: DO,
          normal: MO
        } = XO;
      return `\tvar ${Wp} = BloxdLightIn(vec3f(0.0), ${pO?eO:"0.0"}, ${lO}, ${vK}, ${CO}, ${bK}, ${hO}, ${DO}, fragmentInputs.vPositionW, ${MO}, bloxdSpSurfaceIn.localPosition, bloxdSpSurfaceIn.flags, bloxdSpSurfaceIn.textureId, bloxdSpSurfaceIn.textureRotation, bloxdSpSurfaceIn.uv, bloxdSpSurfaceIn.mipLevel);\n\t${Wp}.litColour = bloxdLitColour(bloxdSpSurface, ${Wp});\n`
    }

    function kX(OO) {
      return OO.light ? `\n\t{\n\t\tlet bloxdSpLight = ${OO.light}(bloxdSpSurface, ${Wp});\n\t\tcolor = vec4f(bloxdSpLight.colour, color.a);\n\t}\n` : ""
    }
    const Up = "\tbaseColor = vec4f(baseColor.rgb * fragmentInputs.vColor, baseColor.a);\n",
      OX = "\tcolor = vec4f(mix(uniforms.vFogColor, color.rgb, fog), color.a);\n",
      KX = "\treturn color;\n}",
      pX = {
        vertexFlags: "vertexOutputs.vBlockFlags",
        vertexLocalPosition: "vec3f(0.0)",
        flags: "fragmentInputs.vBlockFlags",
        normal: "normalize(fragmentInputs.vNormalW)",
        alpha: "alpha",
        alphaOut: "alpha",
        lambert: "fragmentInputs.vTerrainLambert",
        diffuse: "material.vDiffuseColor.rgb",
        emissive: "material.emissiveAndLevel.xyz",
        ambient: "ambient",
        fogColour: "select(vec3f(0.0), uniforms.vFogColor, uniforms.vFogInfos.x != 0.0)",
        fogAlpha: "1.0 - fog",
        enchantTier: "0u",
        enchantColour: "vec4f(0.0)",
        enchantSpeed: "0.0",
        localPosition: "vec3f(0.0)",
        overlayColour: null
      };
    const XX = Object.freeze({});

    function bb(OO) {
      var KO;
      return !(null === (KO = (0, uK.e)(OO)) || void 0 === KO || !KO.sceneDepth)
    }

    function eX(OO) {
      const KO = (0, uK.e)(OO);
      return !!KO && qX(KO.hooks, KO.strict, KO.program)
    }

    function lX(OO, KO, pO, XO) {
      return rX(OO, KO, pO, XO, "terrain")
    }

    function vb(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "none";
      const eO = function(OO) {
          return (0, uK.b)(OO.packVariant, OO.liquid ? "liquid" : "terrain")
        }(OO),
        {
          hooks: lO
        } = eO,
        vK = mX(eO, XO),
        CO = "edge" === bK ? "maskEdge" : "plain" === bK ? "mask" : "trace",
        hO = xX(lO, pX);
      hO && (KO = lX(KO, "\tlet worldPos = vec4f(vertexInputs.position + chunk.translation, 1.0);\n\tvertexOutputs.position = liteWorldLayer(scene.viewProjection * worldPos);\n\tvertexOutputs.vPositionW = worldPos.xyz;\n\tvertexOutputs.vNormalW = normalize(vertexInputs.normal.xyz);\n", `\tvar worldPos = vec4f(vertexInputs.position + chunk.translation, 1.0);\n\tvertexOutputs.vNormalW = normalize(vertexInputs.normal.xyz);${hO}\tvertexOutputs.position = liteWorldLayer(scene.viewProjection * worldPos);\n\tvertexOutputs.vPositionW = worldPos.xyz;\n`, "vertex"));
      const DO = "atlas" === OO.texture ? {
          count: OO.atlasCount,
          layers: OO.atlasLayers,
          width: OO.MeO,
          sampler: "atlasSampler",
          frame: OO.animated ? pO : null
        } : null,
        MO = `${eO.sceneDepth?"\n\tbloxdSpPixel = vec2i(fragmentInputs.position.xy);\n\tbloxdSpPositionW = fragmentInputs.vPositionW;\n":""}${Rp(eO,vK,pX.normal,pX.flags,CO)}${np(lO,eO.strict,eO.program,DO,pX)}`;
      MO && (KO = lX(KO, Up, `${Up.slice(0,-1)}${MO}`, "surface"));
      const aK = kX(lO);
      return aK && (KO = lX(KO, OX, `${tX(lO,OO.lighting,OO.dirLightCount>0,pX)}${OX}`, "light input"), KO = lX(KO, KX, `${aK.slice(1)}${KX}`, "light")), `${(0,gp.E)()}${eO.sceneDepth?`@group(${gp.d}) @binding(${gp.o}) var bloxdSpSceneDepth: texture_2d<f32>;\nvar<private> bloxdSpPixel: vec2i;\nvar<private> bloxdSpPositionW: vec3f;\nfn bloxdOpaqueBehind() -> BloxdOpaqueBehind {\n\tlet bloxdSpZ = textureLoad(bloxdSpSceneDepth, bloxdSpPixel, 0).r;\n\tif (bloxdSpZ <= 0.0) {\n\t\treturn BloxdOpaqueBehind(false, vec3f(0.0), 0.0);\n\t}\n\tlet bloxdSpEye = ${iX};\n\tlet bloxdSpScale = max(bloxdSpZ / (scene.view * vec4f(bloxdSpPositionW, 1.0)).z, 1.0);\n\tlet bloxdSpBehind = bloxdSpEye + (bloxdSpPositionW - bloxdSpEye) * bloxdSpScale;\n\treturn BloxdOpaqueBehind(true, bloxdSpBehind, distance(bloxdSpBehind, bloxdSpEye));\n}\n`:""}${Hp(eO,vK,CO)}${Gp(DO)}${Yp}fn bloxdFragmentBlockPosition(bloxdSpPosition: vec3f, bloxdSpNormal: vec3f) -> vec3i {\n\treturn vec3i(floor(bloxdSpPosition - bloxdSpNormal * 0.5)) + bloxdRenderOffset();\n}\n${eO.code}${KO}`
    }
    const CX = TO.e.WGSL;

    function hX(OO) {
      return void 0 !== OO.packVariant
    }
    const DX = {
        PDO: 0,
        mMO: 4,
        sDO: 8,
        HDO: 12,
        fogInfos: 16,
        fogColour: 20,
        outputHeight: 23,
        sceneAmbient: 24,
        dirLights: 28,
        aoLevels: 44
      },
      MX = DX.aoLevels + 4,
      ab = {
        diffuse: 0,
        ambientAndCutoff: 4,
        emissiveAndLevel: 8,
        anim: 12
      },
      oX = "\nstruct TerrainFrameUniforms {\n\tuHeldLightColour: vec4f,\n\tuHeldLightPos: vec4f,\n\tuSkyLightColour: vec3f,\n\tuAmbientLightColour: vec3f,\n\tvFogInfos: vec4f,\n\tvFogColor: vec3f,\n\toutputHeight: f32,\n\tsceneAmbient: vec3f,\n\tuDirLights: array<vec4f, 4>,\n\taoLevels: vec4f,\n}\n",
      FX = "\nstruct TerrainMaterialUniforms {\n\tvDiffuseColor: vec4f,\n\tambientAndCutoff: vec4f,\n\temissiveAndLevel: vec4f,\n\tanim: vec4f,\n}\n",
      VX = "\nstruct LiteSceneUniforms {\n\tviewProjection: mat4x4f,\n\tview: mat4x4f,\n\tvEyePosition: vec4f,\n}\n@group(0) @binding(0) var<uniform> scene: LiteSceneUniforms;\nfn liteWorldLayer(clip: vec4f) -> vec4f {\n\treturn vec4f(clip.xy, clip.z * 0.5, clip.w);\n}\nfn liteFrontLayer(clip: vec4f) -> vec4f {\n\treturn vec4f(clip.xy, (clip.z + clip.w) * 0.5, clip.w);\n}\n",
      LX = "\n\tlet fading = fragmentInputs.vVisibility < 255.0 / 256.0;\n\tif (fading && fragmentInputs.vVisibility < bayerDither(vec2f(fragmentInputs.position.x, uniforms.outputHeight - fragmentInputs.position.y))) {\n\t\tdiscard;\n\t}\n",
      QX = "\nfn calcFogFactor(fogDistance: vec3f) -> f32 {\n\tvar fogCoeff: f32 = 1.0;\n\tlet fogStart = uniforms.vFogInfos.y;\n\tlet fogEnd = uniforms.vFogInfos.z;\n\tlet fogDensity = uniforms.vFogInfos.w;\n\tlet dist = length(fogDistance);\n\tif (uniforms.vFogInfos.x == 3.0) {\n\t\tfogCoeff = (fogEnd - dist) / (fogEnd - fogStart);\n\t} else if (uniforms.vFogInfos.x == 1.0) {\n\t\tfogCoeff = 1.0 / pow(2.71828, dist * fogDensity);\n\t} else if (uniforms.vFogInfos.x == 2.0) {\n\t\tfogCoeff = 1.0 / pow(2.71828, dist * dist * fogDensity * fogDensity);\n\t}\n\treturn clamp(fogCoeff, 0.0, 1.0);\n}\n",
      zb = {
        position: 0,
        normal: 1,
        color: 2,
        uv: 3,
        packedLight: 5,
        blockFlagWords: 7
      },
      AX = 0,
      fX = 3,
      dX = 4,
      TX = 5,
      NX = `\nfn packedNormal(dir: u32) -> vec4f {\n\tlet axis = dir >> 1u;\n\tlet s = 1.0 - 2.0 * f32(dir & 1u);\n\treturn vec4f(select(0.0, s, axis == 0u), select(0.0, s, axis == 1u), select(0.0, s, axis == 2u), 0.0);\n}\nfn packedUv(p: vec3f, dir: u32, corner: u32) -> vec2f {\n\tlet axis = dir >> 1u;\n\tlet s = 1.0 - 2.0 * f32(dir & 1u);\n\tlet du = select(-${IK.d}, ${IK.d}, corner == 0u || corner == 3u);\n\tlet dv = select(-${IK.d}, ${IK.d}, corner < 2u);\n\tif (axis == 0u) {\n\t\treturn vec2f(s * (p.z + du), -(p.y + dv));\n\t}\n\tif (axis == 1u) {\n\t\treturn vec2f(s * (p.x + dv), -(p.z + du));\n\t}\n\treturn vec2f(-s * (p.x + du), -(p.y + dv));\n}\n`,
      IX = `\n@group(1) @binding(2) var<storage, read> quads: array<u32>;\n// A quad's light: its four slots' packed values as u16, two a word, the lower slot in the low half (liteTerrainArena.ts)\n@group(1) @binding(3) var<storage, read> quadLight: array<u32>;\nfn quadSlotLight(quad: u32, slot: u32) -> f32 {\n\tlet pair = quadLight[quad * 2u + (slot >> 1u)];\n\treturn f32((pair >> ((slot & 1u) * 16u)) & 0xffffu);\n}\nfn slotCorner(dir: u32, diagonal: u32, slot: u32) -> u32 {\n\tlet reversed = ((${yp.b}u >> dir) & 1u) == 1u;\n\treturn (diagonal + select(slot, 4u - slot, reversed)) & 3u;\n}\nfn quadCorner(r0: u32, axis: u32, corner: u32) -> vec3f {\n\tlet w = f32(((r0 >> 18u) & 63u) + 1u) * select(0.0, 1.0, corner == 1u || corner == 2u);\n\tlet h = f32(((r0 >> 24u) & 63u) + 1u) * select(0.0, 1.0, corner >= 2u);\n\tlet du = select(vec3f(0.0, 0.0, w), vec3f(w, 0.0, 0.0), axis == 2u);\n\tlet dv = select(vec3f(0.0, h, 0.0), vec3f(h, 0.0, 0.0), axis == 1u);\n\treturn vec3f(f32(r0 & 63u), f32((r0 >> 6u) & 63u), f32((r0 >> 12u) & 63u)) + du + dv;\n}\n`;
    const yb = {
      KK: "material.anim.x",
      stride: "material.anim.y",
      count: "material.anim.z",
      perTexture: OO => `animDataPerTex[${OO}]`
    };

    function gb(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : yb,
        XO = arguments.length > 3 ? arguments[3] : void 0;
      return `\n\tlet atlasIdxIn = ${OO};\n\tlet animTick = ${pO.KK};\n\tlet animTickStride = ${pO.stride};\n\tlet numAnimTextures = ${pO.count};\n\t${(0,NO.d)(TO.e.WGSL,pO.perTexture)}\n\t${KO}animLayer;\n\t${XO?`${XO}animNext;`:""}\n`
    }

    function uX(OO) {
      const KO = OO => `textureSample(diffuseSampler, diffuseSamplerSampler, ${OO})`;
      return OO ? `baseColor = mix(${KO("fragmentInputs.vMainUV1")}, ${KO("fragmentInputs.vMainUV1 + vec2f(0.0, fragmentInputs.vAnimStripNext.x)")}, fragmentInputs.vAnimStripNext.y);` : `baseColor = ${KO("fragmentInputs.vMainUV1")};`
    }

    function EX(OO) {
      const KO = OO.atlasCount > 1 || OO.animated,
        pO = (pO, XO) => {
          const bK = pO > 0 ? `${XO} - ${OO.atlasLayers.toFixed(1)} * ${pO.toFixed(1)}` : XO;
          return `${KO?"textureSampleLevel":"textureSample"}(textureAtlas${pO}, atlasSampler, fragmentInputs.vMainUV1, i32(round(${bK}))${KO?", atlasLod":""})`
        },
        XO = function(KO, XO) {
          let bK = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : OO.atlasCount;
          if (1 === bK) return `${KO} = ${pO(0,XO)};`;
          let eO = "";
          for (let lO = 0; lO < bK; lO++) {
            const bK = OO.atlasLayers * (lO + 1) - .5;
            eO += `${lO>0?" else ":"\n\t"}if (${XO} < ${(0,NK.kb)(bK)}) {\n\t\t${KO} = ${pO(lO,XO)};\n\t}`
          }
          return eO
        },
        bK = KO ? `\n\tlet atlasTexelUV = fragmentInputs.vMainUV1 * ${(0,NK.kb)(OO.MeO)};\n\tlet atlasDdx = dpdx(atlasTexelUV);\n\tlet atlasDdy = dpdy(atlasTexelUV);\n\tlet atlasLod = 0.5 * log2(max(max(dot(atlasDdx, atlasDdx), dot(atlasDdy, atlasDdy)), 1e-10));\n` : "",
        eO = OO.animated ? `\n\tif (fragmentInputs.texAtlasNext.y > 0.0) {\n\t\tvar atlasNextColor: vec4f;\n\t\t${XO("atlasNextColor","fragmentInputs.texAtlasNext.x",OO.nextFrameAtlases)}\n\t\tbaseColor = mix(baseColor, atlasNextColor, fragmentInputs.texAtlasNext.y);\n\t}` : "";
      return `${bK}${XO("baseColor","fragmentInputs.texAtlasIndex")}${eO}`
    }

    function jb(OO) {
      return `terrain-${OO.texture}${"atlas"===OO.texture?OO.atlasCount:""}${OO.animated?"-anim":""}${void 0!==OO.nextFrameAtlases?`n${OO.nextFrameAtlases}`:""}${OO.alphaTest?"-test":""}${OO.lighting?"-lit":""}-dir${OO.dirLightCount}${OO.packed?"-packed":""}${hX(OO)?`-sp${OO.packVariant}`:""}${OO.liquid?"-liquid":""}${OO.resting?"-rest":""}`
    }

    function YX(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "none";
      const XO = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "none";
        const pO = "none" !== OO.texture,
          XO = "atlas" === OO.texture,
          bK = OO.dirLightCount > 0,
          eO = hX(OO);
        if (OO.dirLightCount > 4) throw new Error(`Terrain supports 4 directional lights, not ${OO.dirLightCount}`);
        let lO = 1,
          vK = "@group(2) @binding(0) var<uniform> material: TerrainMaterialUniforms;\n";
        if (XO) {
          OO.animated && (vK += `@group(2) @binding(${lO++}) var<storage, read> animDataPerTex: array<f32>;\n`), vK += `@group(2) @binding(${lO++}) var atlasSampler: sampler;\n`;
          for (let KO = 0; KO < OO.atlasCount; KO++) vK += `@group(2) @binding(${lO++}) var textureAtlas${KO}: texture_2d_array<f32>;\n`
        } else "single" === OO.texture && (vK += `@group(2) @binding(${lO++}) var diffuseSamplerSampler: sampler;\n`, vK += `@group(2) @binding(${lO++}) var diffuseSampler: texture_2d<f32>;\n`);
        const CO = function(OO) {
            const KO = zb,
              pO = "none" !== OO.texture,
              XO = "atlas" === OO.texture,
              bK = hX(OO);
            return OO.packed ? {
              declarations: `\nstruct PackedVertexInputs {\n\t@builtin(instance_index) chunkSlot: u32,\n\t@builtin(vertex_index) vertexIndex: u32,\n}\nstruct VertexInputs {\n\tchunkSlot: u32,\n\tposition: vec3f,\n\tnormal: vec4f,\n\tcolor: vec4f,\n\t${pO?"uv: vec2f,":""}\n\t${XO?"texAtlasIndices: f32,":""}\n\t${OO.lighting?"aPackedLightLevels: f32,":""}\n\t${bK?"blockFlagWords: vec2u,":""}\n}\n${NX}\n${IX}\n${"single"===OO.texture?"\nfn packedFaceUvOffset(r0: u32, dir: u32) -> vec2f {\n\tlet axis = dir >> 1u;\n\tlet s = 1.0 - 2.0 * f32(dir & 1u);\n\tlet x = f32(r0 & 63u);\n\tlet y = f32((r0 >> 6u) & 63u);\n\tlet z = f32((r0 >> 12u) & 63u);\n\tif (axis == 0u) {\n\t\treturn vec2f(-s * z, y + f32(((r0 >> 24u) & 63u) + 1u));\n\t}\n\tif (axis == 1u) {\n\t\treturn vec2f(-s * x, z + f32(((r0 >> 18u) & 63u) + 1u));\n\t}\n\treturn vec2f(s * x, y + f32(((r0 >> 24u) & 63u) + 1u));\n}\n":""}\n`,
              parameter: "packedInputs: PackedVertexInputs",
              decode: `\n\tvar vertexInputs: VertexInputs;\n\tlet part = chunks[packedInputs.chunkSlot];\n\tlet drawn = packedInputs.vertexIndex >> 2u;\n\tlet quad = select(drawn, drawn - part.faceCount, drawn >= part.faceEnd);\n\tlet slot = packedInputs.vertexIndex & 3u;\n\tlet r2 = quads[quad * 3u + 2u];\n\tlet dir = r2 & 7u;\n\tlet corner = slotCorner(dir, (r2 >> 11u) & 1u, slot);\n\tlet position = quadCorner(quads[quad * 3u], dir >> 1u, corner);\n\tlet face = quads[quad * 3u + 1u];\n\tlet ao = (r2 >> (3u + 2u * slot)) & 3u;\n\tvertexInputs.chunkSlot = packedInputs.chunkSlot;\n\tvertexInputs.position = position;\n\tvertexInputs.normal = packedNormal(dir);\n\t// Packed parts are untinted, so the colour is the AO level's, as unorm8 decodes it; its alpha no program reads\n\tvertexInputs.color = vec4f(vec3f(uniforms.aoLevels[ao]), 1.0);\n\t${pO?"vertexInputs.uv = packedUv(position, dir, corner);":""}\n\t${"single"===OO.texture?"vertexInputs.uv += packedFaceUvOffset(quads[quad * 3u], dir);":""}\n\t${XO?"vertexInputs.texAtlasIndices = f32(face & 0xffffu);":""}\n\t${OO.lighting?"vertexInputs.aPackedLightLevels = quadSlotLight(quad, slot);":""}\n\t${bK?"vertexInputs.blockFlagWords = vec2u(face, face << 8u);":""}\n`
            } : {
              declarations: `\nstruct VertexInputs {\n\t@builtin(instance_index) chunkSlot: u32,\n\t@location(${KO.position}) position: vec3f,\n\t@location(${KO.normal}) normal: vec4f,\n\t@location(${KO.color}) color: vec4f,\n\t${pO?`@location(${KO.uv}) uv: vec2f,`:""}\n\t${OO.lighting?`@location(${KO.packedLight}) aPackedLightLevels: f32,`:""}\n\t${bK?`@location(${KO.blockFlagWords}) blockFlagWords: vec2u,`:""}\n}\n`,
              parameter: "vertexInputs: VertexInputs",
              decode: ""
            }
          }(OO),
          hO = `\n${VX}\n${oX}\n${FX}\n@group(1) @binding(0) var<uniform> uniforms: TerrainFrameUniforms;\n/** Per chunk part, indexed by the draw's first instance (TERRAIN_CHUNK_SLOT_WORDS words). */\nstruct TerrainChunk {\n\t/** Into the render frame. */\n\ttranslation: vec3f,\n\t/** The fade-in. */\n\tvisibility: f32,\n\t/** Quad records only: where the part's faces end in its page, in records, and how many it has. */\n\tfaceEnd: u32,\n\tfaceCount: u32,\n}\n@group(1) @binding(1) var<storage, read> chunks: array<TerrainChunk>;\n${vK}\n${nO}\n${CO.declarations}\nstruct Varyings {\n\t${"none"===KO?"":"// Invariant: at 1x the scene's pass draws over the pre-pass's depth with an equal test\n\t@invariant "}@builtin(position) position: vec4f,\n\t// Centroid, as an edge pixel's centre can lie past its face and packs floor this to find the block\n\t@location(0) @interpolate(perspective, centroid) vPositionW: vec3f,\n\t@location(1) vNormalW: vec3f,\n\t@location(2) vColor: vec3f,\n\t@location(3) vFogDistance: vec3f,\n\t${OO.resting?"":"@location(4) @interpolate(flat) vVisibility: f32,"}\n\t${bK?"@location(5) vTerrainLambert: f32,":""}\n\t${pO?"@location(6) @interpolate(perspective, centroid) vMainUV1: vec2f,":""}\n\t${XO?"@location(7) texAtlasIndex: f32,":""}\n\t${OO.lighting?"@location(8) vLightLevels: vec4f,":""}\n\t${eO?"@location(9) @interpolate(flat) vBlockFlags: u32,":""}\n\t${eO&&XO?"@location(10) @interpolate(flat) vPackTexture: u32,":""}\n\t${XO&&OO.animated?"@location(11) texAtlasNext: vec2f,":""}\n\t${"single"===OO.texture&&OO.animated?"@location(11) vAnimStripNext: vec2f,":""}\n}\n\n${OO.resting?"":(0,NK.l)(CX)}\n${QX}\n\n@vertex\nfn mainVertex(${CO.parameter}) -> Varyings {\n\t${CO.decode}\n\tvar vertexOutputs: Varyings;\n\tlet chunk = chunks[vertexInputs.chunkSlot];\n\t${eO?`vertexOutputs.vBlockFlags = ((vertexInputs.blockFlagWords.x >> 24u) << 8u) | (vertexInputs.blockFlagWords.y >> 24u) | ${CK.d.placed}u;`:""}\n\t${eO&&XO?Bp("vertexInputs.texAtlasIndices").trim():""}\n\tlet worldPos = vec4f(vertexInputs.position + chunk.translation, 1.0);\n\tvertexOutputs.position = liteWorldLayer(scene.viewProjection * worldPos);\n\tvertexOutputs.vPositionW = worldPos.xyz;\n\tvertexOutputs.vNormalW = normalize(vertexInputs.normal.xyz);\n\tvertexOutputs.vColor = vertexInputs.color.rgb;\n\tvertexOutputs.vFogDistance = (scene.view * worldPos).xyz;\n\t${OO.resting?"":"vertexOutputs.vVisibility = chunk.visibility;"}\n\t${pO?"vertexOutputs.vMainUV1 = vertexInputs.uv;":""}\n\t${XO?function(OO){return OO?gb("vertexInputs.texAtlasIndices","vertexOutputs.texAtlasIndex = ",yb,"vertexOutputs.texAtlasNext = "):"vertexOutputs.texAtlasIndex = vertexInputs.texAtlasIndices;"}(OO.animated):""}\n\t${"single"===OO.texture&&OO.animated?"\n\tlet animFramePos = material.anim.x / abs(material.anim.z);\n\tlet frameTick = floor(animFramePos);\n\tlet animTexIndex = frameTick - material.anim.y * floor(frameTick / material.anim.y);\n\tlet animNextTexIndex = frameTick + 1.0 - material.anim.y * floor((frameTick + 1.0) / material.anim.y);\n\tvertexOutputs.vMainUV1.y = (vertexOutputs.vMainUV1.y + animTexIndex) / material.anim.y;\n\tvertexOutputs.vAnimStripNext = vec2f((animNextTexIndex - animTexIndex) / material.anim.y, (animFramePos - frameTick) * step(0.0, material.anim.z));\n":""}\n\t${(0,NK.W)(CX)}\n\t${(0,NK.C)(CX,OO.dirLightCount)}\n\treturn vertexOutputs;\n}\n\n@fragment\nfn mainFragment(fragmentInputs: Varyings) -> @location(0) vec4f {\n\t${OO.resting?"":LX}\n\tvar baseColor = vec4f(1.0);\n\tvar alpha = material.vDiffuseColor.a;\n\t${XO?EX(OO):""}\n\t${"single"===OO.texture?uX(OO.animated):""}\n\t${pO?"alpha *= baseColor.a;\n\tbaseColor = vec4f(baseColor.rgb * material.emissiveAndLevel.w, baseColor.a);":""}\n\tbaseColor = vec4f(baseColor.rgb * fragmentInputs.vColor, baseColor.a);\n\t${OO.alphaTest?"if (alpha < material.ambientAndCutoff.w) {\n\t\tdiscard;\n\t}\n\talpha = 1.0;":""}\n\tvar diffuseBase = vec3f(0.0);\n\t${bK?"diffuseBase += vec3f(fragmentInputs.vTerrainLambert);":""}\n\tlet ambient = material.ambientAndCutoff.xyz * uniforms.sceneAmbient;\n\tlet finalDiffuse = clamp(diffuseBase * material.vDiffuseColor.rgb + material.emissiveAndLevel.xyz + ambient, vec3f(0.0), vec3f(1.0)) * baseColor.rgb;\n\t// Nothing past here changes alpha: light, fog and a pack's light hook keep it\n\tvar color = vec4f(finalDiffuse, select(alpha, 1.0, ${xK}));\n\t${hX(OO)?(0,NK.fb)(TO.e.WGSL):(0,NK.P)(CX)}\n\tcolor = vec4f(max(color.rgb, vec3f(0.0)), color.a);\n\tlet fog = calcFogFactor(fragmentInputs.vFogDistance);\n\tcolor = vec4f(mix(uniforms.vFogColor, color.rgb, fog), color.a);\n\treturn color;\n}\n`,
          DO = new Set;
        OO.lighting && DO.add("BLOXD_LIGHTING");
        bK && DO.add("BLOXD_TERRAIN_DIRECTIONAL");
        return fK(hO, new Map([...DO].map((OO => [OO, !0]))))
      }(OO, pO);
      if (!hX(OO)) return XO;
      const bK = vb(OO, XO, gb, KO, pO);
      return "none" === pO ? bK : `${bK}${function(OO){const KO="none"!==OO.texture&&OO.alphaTest;return`\n@fragment\nfn prepassFragment(fragmentInputs: Varyings) -> @location(0) vec4f {\n\t${OO.resting?"":LX}\n\t${OO.alphaTest?`var baseColor = vec4f(1.0);\n\tvar alpha = material.vDiffuseColor.a;\n\t${KO&&"atlas"===OO.texture?EX(OO):""}\n\t${KO&&"single"===OO.texture?uX(OO.animated):""}\n\t${KO?"alpha *= baseColor.a;":""}\n\tif (alpha < material.ambientAndCutoff.w) {\n\t\tdiscard;\n\t}`:""}\n\tlet emissive = (fragmentInputs.vBlockFlags & ${CK.d.emissive}u) != 0u;\n\treturn vec4f(normalize(fragmentInputs.vNormalW) * 0.5 + 0.5, select(0.0, 1.0, emissive));\n}\n`}(OO)}`
    }
    const wX = new Map([
      ["float", {
        wgsl: "f32",
        align: 1,
        floats: 1
      }],
      ["vec2", {
        wgsl: "vec2f",
        align: 2,
        floats: 2
      }],
      ["vec3", {
        wgsl: "vec3f",
        align: 4,
        floats: 3
      }],
      ["vec4", {
        wgsl: "vec4f",
        align: 4,
        floats: 4
      }],
      ["mat4", {
        wgsl: "mat4x4f",
        align: 4,
        floats: 16
      }]
    ]);

    function ib(OO, KO) {
      const pO = new Map;
      let XO = 0;
      const bK = [],
        eO = [],
        lO = [];
      for (const hO of KO) {
        var vK, CO;
        const KO = null !== (vK = hO.type.trim().split(/\s+/).pop()) && void 0 !== vK ? vK : hO.type,
          DO = wX.get(KO);
        if (!DO) throw new Error(`Lite: no uniform layout for ${hO.name}: ${hO.type}`);
        const MO = null !== (CO = hO.arraySize) && void 0 !== CO ? CO : 0,
          aK = MO ? 4 : DO.align;
        XO = Math.ceil(XO / aK) * aK;
        const oO = MO ? 4 * Math.ceil(DO.floats / 4) : DO.floats;
        if (pO.set(hO.name, {
            offset: XO,
            floats: DO.floats,
            arraySize: MO,
            stride: oO
          }), MO && DO.floats <= 2) {
          const KO = `${OO}_${lO.length}_strided`;
          eO.push(`struct ${KO} {\n\t@size(16) el: ${DO.wgsl},\n}`), lO.push(hO.name), bK.push(`\t@align(16) ${hO.name}: array<${KO}, ${MO}>,`)
        } else MO ? bK.push(`\t@align(16) ${hO.name}: array<${DO.wgsl}, ${MO}>,`) : bK.push(`\t${hO.name}: ${DO.wgsl},`);
        XO += MO ? oO * MO : DO.floats
      }
      return {
        slots: pO,
        floats: Math.max(4, 4 * Math.ceil(XO / 4)),
        wgsl: `${eO.join("\n")}\nstruct ${OO} {\n${bK.join("\n")}\n}\n`,
        stridedArrays: lO
      }
    }
    const rb = [{
        name: "vDiffuseColor",
        type: "vec4"
      }, {
        name: "vDiffuseInfos",
        type: "vec2"
      }, {
        name: "alphaCutOff",
        type: "float"
      }, {
        name: "vEmissiveColor",
        type: "vec3"
      }, {
        name: "vAmbientColor",
        type: "vec3"
      }, {
        name: "vSpecularColor",
        type: "vec4"
      }, {
        name: "diffuseMatrix",
        type: "mat4"
      }, {
        name: "vReflectionInfos",
        type: "vec2"
      }, {
        name: "reflectionMatrix",
        type: "mat4"
      }],
      PX = [{
        name: "vOpacityInfos",
        type: "vec2"
      }, {
        name: "opacityMatrix",
        type: "mat4"
      }],
      mb = [{
        name: "vEmissiveInfos",
        type: "vec2"
      }, {
        name: "emissiveMatrix",
        type: "mat4"
      }];

    function sX(OO, KO) {
      return `#if defined(${OO}) && ${OO}DIRECTUV == 0\nvarying v${KO}UV: vec2f;\n#endif`
    }

    function HX(OO, KO, pO) {
      return `#if defined(${OO}) && ${OO}DIRECTUV == 0\nif (uniforms.v${KO}Infos.x==0.)\n{vertexOutputs.v${KO}UV= (uniforms.${pO}Matrix* vec4f(uvUpdated,1.0,0.0)).xy;}\nelse\n{vertexOutputs.v${KO}UV= (uniforms.${pO}Matrix* vec4f(uv2Updated,1.0,0.0)).xy;}\n#endif`
    }

    function RX(OO, KO, pO) {
      return `#ifdef ${OO}\n#if ${OO}DIRECTUV == 1\n#define v${KO}UV vMainUV1\n#elif ${OO}DIRECTUV == 2\n#define v${KO}UV vMainUV2\n#else\nvarying v${KO}UV: vec2f;\n#endif\nvar ${pO}SamplerSampler: sampler;\nvar ${pO}Sampler: texture_2d<f32>;\n#endif`
    }
    const SX = {
        lights: 0,
        lightStride: 12,
        fogInfos: 96,
        fogColour: 100,
        outputHeight: 103,
        animTick: 104,
        timeMs: 105
      },
      JX = 256,
      cb = "\nstruct LiteLight {\n\tvLightData: vec4f,\n\tvLightDiffuse: vec4f,\n\tvLightSpecular: vec4f,\n}\nstruct LiteFrameUniforms {\n\tlights: array<LiteLight, 8>,\n\tvFogInfos: vec4f,\n\tvFogColor: vec3f,\n\toutputHeight: f32,\n\tanimTick: f32,\n\ttimeMs: f32,\n}\n@group(1) @binding(0) var<uniform> frame: LiteFrameUniforms;\nstruct Mesh {\n\tworld: mat4x4f,\n\tvisibility: f32,\n}\n@group(1) @binding(1) var<uniform> mesh: Mesh;\nstruct Internals {\n\tyFactor_: f32,\n\ttextureOutputHeight_: f32,\n}\nconst internals = Internals(1.0, 0.0);\n",
      BX = "#ifdef INSTANCES\nattribute world0: vec4f;\nattribute world1: vec4f;\nattribute world2: vec4f;\nattribute world3: vec4f;\n#ifdef INSTANCESCOLOR\nattribute instanceColor: vec4f;\n#endif\n#endif",
      ZX = "#ifdef INSTANCES\nvar finalWorld=mat4x4<f32>(vertexInputs.world0,vertexInputs.world1,vertexInputs.world2,vertexInputs.world3);\n#ifdef THIN_INSTANCES\nfinalWorld=mesh.world*finalWorld;\n#endif\n#else\nvar finalWorld=mesh.world;\n#endif",
      GX = "#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)\nvertexOutputs.vColor=vec4f(1.0);\n#ifdef VERTEXCOLOR\n#ifdef VERTEXALPHA\nvertexOutputs.vColor*=colorUpdated;\n#else\nvertexOutputs.vColor=vec4f(vertexOutputs.vColor.rgb*colorUpdated.rgb,vertexOutputs.vColor.a);\n#endif\n#endif\n#ifdef INSTANCESCOLOR\nvertexOutputs.vColor*=vertexInputs.instanceColor;\n#endif\n#endif",
      qb = "#ifdef LITE_FRONT_LAYER\nvertexOutputs.position=liteFrontLayer(vertexOutputs.position);\n#else\nvertexOutputs.position=liteWorldLayer(vertexOutputs.position);\n#endif\nreturn vertexOutputs;",
      xb = "#ifdef FOG\nfn CalcFogFactor()->f32\n{var fogCoeff: f32=1.0;\nvar fogStart: f32=frame.vFogInfos.y;\nvar fogEnd: f32=frame.vFogInfos.z;\nvar fogDensity: f32=frame.vFogInfos.w;\nvar fogDistance: f32=length(fragmentInputs.vFogDistance);\nif (3.==frame.vFogInfos.x)\n{fogCoeff=(fogEnd-fogDistance)/(fogEnd-fogStart);\n}\nelse if (1.==frame.vFogInfos.x)\n{fogCoeff=1.0/pow(2.71828,fogDistance*fogDensity);\n}\nelse if (2.==frame.vFogInfos.x)\n{fogCoeff=1.0/pow(2.71828,fogDistance*fogDistance*fogDensity*fogDensity);\n}\nreturn clamp(fogCoeff,0.0,1.0);\n}\n#endif",
      nX = "const LinearEncodePowerApprox: f32=2.2;\nconst GammaEncodePowerApprox: f32=1.0/LinearEncodePowerApprox;\nfn inverseMat3(inMatrix: mat3x3f)->mat3x3f {let a00: f32=inMatrix[0][0];let a01: f32=inMatrix[0][1];let a02: f32=inMatrix[0][2];let a10: f32=inMatrix[1][0];let a11: f32=inMatrix[1][1];let a12: f32=inMatrix[1][2];let a20: f32=inMatrix[2][0];let a21: f32=inMatrix[2][1];let a22: f32=inMatrix[2][2];let b01: f32=a22*a11-a12*a21;let b11: f32=-a22*a10+a12*a20;let b21: f32=a21*a10-a11*a20;let det: f32=a00*b01+a01*b11+a02*b21;return mat3x3f(b01/det,(-a22*a01+a02*a21)/det,(a12*a01-a02*a11)/det,\nb11/det,(a22*a00-a02*a20)/det,(-a12*a00+a02*a10)/det,\nb21/det,(-a21*a00+a01*a20)/det,(a11*a00-a01*a10)/det);}\nfn toLinearSpaceVec3(color: vec3f)->vec3f {return pow(color,vec3f(LinearEncodePowerApprox));}\nfn toGammaSpaceVec3(color: vec3f)->vec3f {return pow(color,vec3f(GammaEncodePowerApprox));}\nfn fromRGBD(rgbd: vec4<f32>)->vec3f {let rgb=toLinearSpaceVec3(rgbd.rgb);return rgb/rgbd.a;}",
      WX = `\nattribute position: vec3f;\n#ifdef NORMAL\nattribute normal: vec3f;\n#endif\n#ifdef UV1\nattribute uv: vec2f;\n#endif\n#ifdef UV2\nattribute uv2: vec2f;\n#endif\n#ifdef VERTEXCOLOR\nattribute color: vec4f;\n#endif\n${BX}\n#ifdef MAINUV1\nvarying vMainUV1: vec2f;\n#endif\n#ifdef MAINUV2\nvarying vMainUV2: vec2f;\n#endif\n#if defined(DIFFUSE) && DIFFUSEDIRECTUV == 0\nvarying vDiffuseUV: vec2f;\n#endif\n${sX("OPACITY","Opacity")}\n${sX("EMISSIVE","Emissive")}\nvarying vPositionW: vec3f;\n#ifdef NORMAL\nvarying vNormalW: vec3f;\n#endif\n#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)\nvarying vColor: vec4f;\n#endif\n#ifdef FOG\nvarying vFogDistance: vec3f;\n#endif\n#ifdef REFLECTIONMAP_SKYBOX\nvarying vPositionUVW: vec3f;\n#endif\n${nX}\n#define CUSTOM_VERTEX_DEFINITIONS\n@vertex\nfn main(input : VertexInputs)->FragmentInputs {\nvertexInputs = input;\n#define CUSTOM_VERTEX_MAIN_BEGIN\nvar positionUpdated: vec3f=vertexInputs.position;\n#ifdef NORMAL\nvar normalUpdated: vec3f=vertexInputs.normal;\n#endif\n#ifdef UV1\nvar uvUpdated: vec2f=vertexInputs.uv;\n#endif\n#ifdef UV2\nvar uv2Updated: vec2f=vertexInputs.uv2;\n#endif\n#ifdef VERTEXCOLOR\nvar colorUpdated: vec4f=vertexInputs.color;\n#endif\n#ifdef REFLECTIONMAP_SKYBOX\nvertexOutputs.vPositionUVW=positionUpdated;\n#endif\n#define CUSTOM_VERTEX_UPDATE_POSITION\n#define CUSTOM_VERTEX_UPDATE_NORMAL\n${ZX}\nvar worldPos: vec4f=finalWorld*vec4f(positionUpdated,1.0);\n#ifdef NORMAL\nvar normalWorld: mat3x3f= mat3x3f(finalWorld[0].xyz,finalWorld[1].xyz,finalWorld[2].xyz);\n#if defined(INSTANCES) && defined(THIN_INSTANCES)\nvertexOutputs.vNormalW=normalUpdated/ vec3f(dot(normalWorld[0],normalWorld[0]),dot(normalWorld[1],normalWorld[1]),dot(normalWorld[2],normalWorld[2]));vertexOutputs.vNormalW=normalize(normalWorld*vertexOutputs.vNormalW);\n#else\n#ifdef NONUNIFORMSCALING\nnormalWorld=transpose(inverseMat3(normalWorld));\n#endif\nvertexOutputs.vNormalW=normalize(normalWorld*normalUpdated);\n#endif\n#endif\n#define CUSTOM_VERTEX_UPDATE_WORLDPOS\nvertexOutputs.position=scene.viewProjection*worldPos;\nvertexOutputs.vPositionW= worldPos.xyz;\n#ifndef UV1\nvar uvUpdated: vec2f=vec2f(0.,0.);\n#endif\n#ifdef MAINUV1\nvertexOutputs.vMainUV1=uvUpdated;\n#endif\n#ifndef UV2\nvar uv2Updated: vec2f=vec2f(0.,0.);\n#endif\n#ifdef MAINUV2\nvertexOutputs.vMainUV2=uv2Updated;\n#endif\n#if defined(DIFFUSE) && DIFFUSEDIRECTUV == 0\nif (uniforms.vDiffuseInfos.x==0.)\n{vertexOutputs.vDiffuseUV= (uniforms.diffuseMatrix* vec4f(uvUpdated,1.0,0.0)).xy;}\nelse\n{vertexOutputs.vDiffuseUV= (uniforms.diffuseMatrix* vec4f(uv2Updated,1.0,0.0)).xy;}\n#endif\n${HX("OPACITY","Opacity","opacity")}\n${HX("EMISSIVE","Emissive","emissive")}\n#ifdef FOG\nvertexOutputs.vFogDistance=(scene.view*worldPos).xyz;\n#endif\n${GX}\n#define CUSTOM_VERTEX_MAIN_END\n${qb}\n}\n`;
    const tb = `\n#ifdef MAINUV1\nvarying vMainUV1: vec2f;\n#endif\n#ifdef MAINUV2\nvarying vMainUV2: vec2f;\n#endif\nvarying vPositionW: vec3f;\n#ifdef NORMAL\nvarying vNormalW: vec3f;\n#endif\n#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)\nvarying vColor: vec4f;\n#endif\n#ifdef FOG\nvarying vFogDistance: vec3f;\n#endif\n#ifdef DIFFUSE\n#if DIFFUSEDIRECTUV == 1\n#define vDiffuseUV vMainUV1\n#elif DIFFUSEDIRECTUV == 2\n#define vDiffuseUV vMainUV2\n#else\nvarying vDiffuseUV: vec2f;\n#endif\nvar diffuseSamplerSampler: sampler;\nvar diffuseSampler: texture_2d<f32>;\n#endif\n${RX("OPACITY","Opacity","opacity")}\n${RX("EMISSIVE","Emissive","emissive")}\nstruct lightingInfo\n{diffuse: vec3f,\n};\nfn computeLighting(viewDirectionW: vec3f,vNormal: vec3f,lightData: vec4f,diffuseColor: vec3f,specularColor: vec3f,range: f32,glossiness: f32)->lightingInfo {var result: lightingInfo;\nvar lightVectorW: vec3f;\nvar attenuation: f32=1.0;\nif (lightData.w==0.)\n{var direction: vec3f=lightData.xyz-fragmentInputs.vPositionW;\nattenuation=max(0.,1.0-length(direction)/range);\nlightVectorW=normalize(direction);\n}\nelse\n{lightVectorW=normalize(-lightData.xyz);\n}\nvar ndl: f32=max(0.,dot(vNormal,lightVectorW));\nresult.diffuse=ndl*diffuseColor*attenuation;\nreturn result;\n}\nfn TEXRD(t: texture_2d<f32>,ts: sampler,uv: vec2f)->vec4f {return textureSample(t,ts,uv);\n}\n#ifdef REFLECTION\nvar reflectionCubeSamplerSampler: sampler;var reflectionCubeSampler: texture_cube<f32>;\n#ifdef REFLECTIONMAP_SKYBOX\nvarying vPositionUVW: vec3f;\n#endif\nfn computeSkyBoxCoords(positionW: vec3f,reflectionMatrix: mat4x4f)->vec3f\n{return (reflectionMatrix* vec4f(positionW,1.)).xyz;}\nfn computeReflectionCoords(worldPos: vec4f,worldNormal: vec3f)->vec3f\n{\n#ifdef REFLECTIONMAP_SKYBOX\nreturn computeSkyBoxCoords(fragmentInputs.vPositionUVW,uniforms.reflectionMatrix);\n#else\nreturn vec3f(0.);\n#endif\n}\n#endif\n${nX}\n${xb}\n#define CUSTOM_FRAGMENT_DEFINITIONS\n@fragment\nfn main(input: FragmentInputs)->FragmentOutputs {\nfragmentInputs = input;\n#define CUSTOM_FRAGMENT_MAIN_BEGIN\nvar viewDirectionW: vec3f=normalize(scene.vEyePosition.xyz-fragmentInputs.vPositionW);var baseColor: vec4f= vec4f(1.,1.,1.,1.);var diffuseColor: vec3f=uniforms.vDiffuseColor.rgb;var alpha: f32=uniforms.vDiffuseColor.a;\n#ifdef NORMAL\nvar normalW: vec3f=normalize(fragmentInputs.vNormalW);\n#else\nvar normalW: vec3f=normalize(cross(dpdx(fragmentInputs.vPositionW),dpdy(fragmentInputs.vPositionW)));\nnormalW=select(-normalW,normalW,dot(normalW,viewDirectionW)>=0.0);\n#endif\n#ifdef TWOSIDEDLIGHTING\nnormalW=select(-normalW,normalW,fragmentInputs.frontFacing);\n#endif\nvar uvOffset: vec2f= vec2f(0.0,0.0);\n#ifdef DIFFUSE\nbaseColor=TEXRD(diffuseSampler,diffuseSamplerSampler,fragmentInputs.vDiffuseUV+uvOffset);\n#if defined(ALPHATEST) && !defined(ALPHATEST_AFTERALLALPHACOMPUTATIONS)\nif (baseColor.a<uniforms.alphaCutOff) {discard;}\n#endif\n#ifdef ALPHAFROMDIFFUSE\nalpha*=baseColor.a;\n#endif\n#define CUSTOM_FRAGMENT_UPDATE_ALPHA\nbaseColor=vec4f(baseColor.rgb*uniforms.vDiffuseInfos.y,baseColor.a);\n#endif\n#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)\nbaseColor=vec4f(baseColor.rgb*fragmentInputs.vColor.rgb,baseColor.a);\n#endif\n#define CUSTOM_FRAGMENT_UPDATE_DIFFUSE\nvar baseAmbientColor: vec3f= vec3f(1.,1.,1.);\n#define CUSTOM_FRAGMENT_BEFORE_LIGHTS\nvar glossiness: f32=uniforms.vSpecularColor.a;var specularColor: vec3f=uniforms.vSpecularColor.rgb;\nvar diffuseBase: vec3f= vec3f(0.,0.,0.);var info: lightingInfo;\nvar shadow: f32=1.;var aggShadow: f32=0.;var numLights: f32=0.;\n${Array.from({length:4},((OO,KO)=>function(OO){const KO=`
    frame.lights[LITE_LIGHT$ {
        OO
      }
      _SLOT] `;return`
    #ifdef LIGHT$ {
      OO
    }\
    nvar diffuse$ {
      OO
    }: vec4f = $ {
      KO
    }.vLightDiffuse;\
    n #define CUSTOM_LIGHT$ {
      OO
    }
    _COLOR\ ninfo = computeLighting(viewDirectionW, normalW, $ {
      KO
    }.vLightData, diffuse$ {
      OO
    }.rgb, $ {
      KO
    }.vLightSpecular.rgb, diffuse$ {
      OO
    }.a, glossiness);\
    nshadow = 1.;\
    naggShadow += shadow;\
    nnumLights += 1.0;\
    ndiffuseBase += info.diffuse * shadow;\
    n #endif`}(KO))).join("\n")}\naggShadow=aggShadow/numLights;var refractionColor: vec4f= vec4f(0.,0.,0.,1.);\nvar reflectionColor: vec4f= vec4f(0.,0.,0.,1.);\n#ifdef REFLECTION\nvar vReflectionUVW: vec3f=computeReflectionCoords( vec4f(fragmentInputs.vPositionW,1.0),normalW);\n#ifdef REFLECTIONMAP_OPPOSITEZ\nvReflectionUVW=vec3f(vReflectionUVW.x,vReflectionUVW.y,vReflectionUVW.z*-1.0);\n#endif\n#ifdef ROUGHNESS\nvar bias: f32=uniforms.vReflectionInfos.y;\nreflectionColor=textureSampleLevel(reflectionCubeSampler,reflectionCubeSamplerSampler,vReflectionUVW,bias);\n#else\nreflectionColor=textureSample(reflectionCubeSampler,reflectionCubeSamplerSampler,vReflectionUVW);\n#endif\n#ifdef LITE_REFLECTION_LUMINANCE\nreflectionColor=vec4f(reflectionColor.rrr,1.0);\n#endif\n#ifdef RGBDREFLECTION\nreflectionColor=vec4f(fromRGBD(reflectionColor),reflectionColor.a);\n#endif\n#ifdef IS_REFLECTION_LINEAR\nreflectionColor=vec4f(toGammaSpaceVec3(reflectionColor.rgb),reflectionColor.a);\n#endif\nreflectionColor=vec4f(reflectionColor.rgb*uniforms.vReflectionInfos.x,reflectionColor.a);\n#endif\n#ifdef OPACITY\nvar opacityMap: vec4f=TEXRD(opacitySampler,opacitySamplerSampler,fragmentInputs.vOpacityUV+uvOffset);\n#ifdef OPACITYRGB\nopacityMap=vec4f(opacityMap.rgb* vec3f(0.3,0.59,0.11),opacityMap.a);alpha*=(opacityMap.x+opacityMap.y+opacityMap.z)* uniforms.vOpacityInfos.y;\n#else\nalpha*=opacityMap.a*uniforms.vOpacityInfos.y;\n#endif\n#endif\n#if defined(VERTEXALPHA) || defined(INSTANCESCOLOR) && defined(INSTANCES)\nalpha*=fragmentInputs.vColor.a;\n#endif\n#ifdef ALPHATEST\n#ifdef ALPHATEST_AFTERALLALPHACOMPUTATIONS\nif (alpha<uniforms.alphaCutOff) {discard;}\n#endif\n#ifndef ALPHABLEND\nalpha=1.0;\n#endif\n#endif\nvar emissiveColor: vec3f=uniforms.vEmissiveColor;\n#ifdef EMISSIVE\nemissiveColor+=TEXRD(emissiveSampler,emissiveSamplerSampler,fragmentInputs.vEmissiveUV+uvOffset).rgb*uniforms.vEmissiveInfos.y;\n#endif\n#ifdef EMISSIVEASILLUMINATION\nvar finalDiffuse: vec3f=clamp(diffuseBase*diffuseColor+uniforms.vAmbientColor,vec3f(0.0),vec3f(1.0))*baseColor.rgb;\n#else\n#ifdef LINKEMISSIVEWITHDIFFUSE\nvar finalDiffuse: vec3f=clamp((diffuseBase+emissiveColor)*diffuseColor+uniforms.vAmbientColor,vec3f(0.0),vec3f(1.0))*baseColor.rgb;\n#else\nvar finalDiffuse: vec3f=clamp(diffuseBase*diffuseColor+emissiveColor+uniforms.vAmbientColor,vec3f(0.0),vec3f(1.0))*baseColor.rgb;\n#endif\n#endif\nvar finalSpecular: vec3f= vec3f(0.0);\n#ifdef REFLECTIONOVERALPHA\nalpha=clamp(alpha+dot(reflectionColor.rgb, vec3f(0.3,0.59,0.11)),0.0,1.0);\n#endif\n#ifdef EMISSIVEASILLUMINATION\nvar color: vec4f= vec4f(clamp(finalDiffuse*baseAmbientColor+finalSpecular+reflectionColor.rgb+emissiveColor+refractionColor.rgb,vec3f(0.0),vec3f(1.0)),alpha);\n#else\nvar color: vec4f= vec4f(finalDiffuse*baseAmbientColor+finalSpecular+reflectionColor.rgb+refractionColor.rgb,alpha);\n#endif\n#define CUSTOM_FRAGMENT_BEFORE_FOG\ncolor=vec4f(max(color.rgb,vec3f(0.)),color.a);\n#ifdef FOG\nvar fog: f32=CalcFogFactor();\ncolor= vec4f(mix(frame.vFogColor,color.rgb,fog),color.a);\n#endif\ncolor=vec4f(color.rgb,color.a*mesh.visibility);\n#ifdef PREMULTIPLYALPHA\ncolor=vec4f(color.rgb*color.a, color.a);\n#endif\n#define CUSTOM_FRAGMENT_BEFORE_FRAGCOLOR\nfragmentOutputs.color=color;\n#define CUSTOM_FRAGMENT_MAIN_END\nreturn fragmentOutputs;\n}\n`, kb = /^([gimus]+)!/, UX = new Set;

    function Ob(OO) {
      UX.has(OO) || (UX.add(OO), console.warn(`Lite: no place for plugin code at ${OO} in the standard shader: it is left out`))
    }

    function Kb(OO, KO) {
      let pO = OO;
      const XO = new Map;
      for (const [eO, lO] of KO) {
        var bK;
        XO.set(eO, `${null!==(bK=XO.get(eO))&&void 0!==bK?bK:""}${lO}\n`)
      }
      for (const [eO, lO] of XO) {
        if (!eO.startsWith("!")) {
          const OO = `#define ${eO}`;
          if (!pO.includes(OO)) {
            Ob(eO);
            continue
          }
          pO = pO.replace(OO, (() => `\n${lO}\n${OO}`));
          continue
        }
        let OO = eO.substring(1),
          KO = "g";
        if (OO.startsWith("!")) KO = "", OO = OO.substring(1);
        else {
          const pO = kb.exec(OO);
          pO && (KO = pO[1], OO = OO.substring(KO.length + 1))
        }
        const XO = new RegExp(OO, KO.includes("g") ? KO : `${KO}g`);
        let bK = XO.exec(pO);
        for (bK || Ob(eO); bK;) {
          const OO = bK,
            KO = lO.replace(/\$(\d+)/g, ((KO, pO) => Number(pO) < OO.length ? OO[Number(pO)] : ""));
          pO = pO.substring(0, OO.index) + KO + pO.substring(OO.index + OO[0].length), XO.lastIndex = OO.index + KO.length, bK = XO.exec(pO)
        }
      }
      return pO
    }
    const pb = /\b(?:(attribute|uniform)|(?:(flat|linear|perspective)\s+)?(?:(center|centroid|sample)\s+)?varying)\s+(\w+)\s*:\s*([\w<>, ]+?)\s*;/g,
      Xb = /\bvar\s+(\w+)\s*:\s*sampler\s*;/g,
      be = /\bvar\s+(\w+)\s*:\s*(texture_\w+(?:<\s*f32\s*>)?)\s*;/g;

    function eb(OO) {
      const KO = {
        attributes: [],
        varyings: [],
        uniforms: [],
        textures: [],
        samplers: new Set,
        body: ""
      };
      let pO = OO.replace(pb, ((OO, pO, XO, bK, eO, lO) => ("attribute" === pO ? KO.attributes.push({
        name: eO,
        type: lO
      }) : void 0 === pO ? KO.varyings.push({
        name: eO,
        type: lO,
        interpolation: ve(lO, XO, bK)
      }) : KO.uniforms.push({
        name: eO,
        type: lb(lO)
      }), "")));
      return pO = pO.replace(Xb, ((OO, pO) => (KO.samplers.add(pO), ""))), pO = pO.replace(be, ((OO, pO, XO) => (KO.textures.push({
        name: pO,
        type: XO
      }), ""))), KO.body = pO, KO
    }

    function lb(OO) {
      const KO = OO.replace(/\s+/g, "").replace("vec2<f32>", "vec2f").replace("vec3<f32>", "vec3f").replace("vec4<f32>", "vec4f").replace("mat4x4<f32>", "mat4x4f"),
        pO = new Map([
          ["f32", "float"],
          ["vec2f", "vec2"],
          ["vec3f", "vec3"],
          ["vec4f", "vec4"],
          ["mat4x4f", "mat4"]
        ]).get(KO);
      if (!pO) throw new Error(`Lite: unsupported uniform type ${OO}`);
      return pO
    }

    function ve(OO, KO, pO) {
      return void 0 === KO && void 0 === pO ? /^(u32|i32|vec\du|vec\di|vec\d<[ui]32>)$/.test(OO.replace(/\s+/g, "")) ? "@interpolate(flat) " : "" : "flat" === KO ? "@interpolate(flat) " : `@interpolate(${null!==KO&&void 0!==KO?KO:"perspective"}, ${null!==pO&&void 0!==pO?pO:"center"}) `
    }

    function Cb(OO) {
      return ae({
        defines: OO.defines,
        vertex: Kb(WX, OO.vertexCode),
        fragment: Kb(tb, OO.fragmentCode),
        members: [...rb, ...OO.defines.has("OPACITY") ? PX : [], ...OO.defines.has("EMISSIVE") ? mb : [], ...OO.pluginUniforms],
        structName: "StandardUniforms"
      })
    }

    function hb(OO) {
      const KO = OO.replace(/\breturn\s+fragmentOutputs\s*;/g, "return canvasOutputs();");
      if (KO === OO) throw new Error("Lite: fragment main has no return");
      return KO
    }
    const Db = `\nattribute position: vec3f;\n#ifdef VERTEXCOLOR\nattribute color: vec4f;\n#endif\n${BX}\n#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)\nvarying vColor: vec4f;\n#endif\n#ifdef FOG\nvarying vFogDistance: vec3f;\n#endif\n@vertex\nfn main(input : VertexInputs)->FragmentInputs {\nvertexInputs = input;\n#ifdef VERTEXCOLOR\nvar colorUpdated: vec4f=vertexInputs.color;\n#endif\n${ZX}\nvar worldPos: vec4f=finalWorld*vec4f(vertexInputs.position,1.0);\nvertexOutputs.position=scene.viewProjection*worldPos;\n#ifdef FOG\nvertexOutputs.vFogDistance=(scene.view*worldPos).xyz;\n#endif\n${GX}\n${qb}\n}\n`,
      Mb = `\nuniform color: vec4f;\n#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)\nvarying vColor: vec4f;\n#endif\n#ifdef FOG\nvarying vFogDistance: vec3f;\n#endif\n${xb}\n@fragment\nfn main(input: FragmentInputs)->FragmentOutputs {\nfragmentInputs = input;\n#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)\nvar color: vec4f=fragmentInputs.vColor;\n#else\nvar color: vec4f=uniforms.color;\n#endif\n#ifdef FOG\ncolor=vec4f(mix(frame.vFogColor,color.rgb,CalcFogFactor()),color.a);\n#endif\nfragmentOutputs.color=color;\nreturn fragmentOutputs;\n}\n`;

    function ae(OO) {
      const KO = OO.defines,
        pO = eb(fK(OO.vertex, KO)),
        XO = eb(fK(OO.fragment, KO)),
        bK = new Map;
      for (const AO of [...pO.varyings, ...XO.varyings]) bK.has(AO.name) || bK.set(AO.name, AO);
      const eO = [...bK.values()].map(((OO, KO) => `\t@location(${KO}) ${OO.interpolation}${OO.name}: ${OO.type},`)),
        lO = [...OO.members];
      for (const AO of [...pO.uniforms, ...XO.uniforms]) lO.some((OO => OO.name === AO.name)) || lO.push(AO);
      const vK = ib(OO.structName, lO),
        CO = [],
        hO = [];
      let DO = 1;
      const MO = new Set;
      for (const AO of [...pO.textures, ...XO.textures]) {
        if (MO.has(AO.name)) continue;
        MO.add(AO.name);
        const OO = `${AO.name}Sampler`,
          KO = DO++,
          pO = DO++,
          XO = AO.type.startsWith("texture_2d_array") ? "2d-array" : AO.type.startsWith("texture_cube") ? "cube" : "2d";
        CO.push({
          name: AO.name,
          binding: KO,
          samplerBinding: pO,
          dimension: XO
        }), hO.push(`@group(2) @binding(${KO}) var ${AO.name}: ${AO.type};`), hO.push(`@group(2) @binding(${pO}) var ${OO}: sampler;`)
      }
      for (const AO of [...pO.samplers, ...XO.samplers])
        if (!MO.has(AO.replace(/Sampler$/, ""))) throw new Error(`Lite: sampler ${AO} has no texture`);
      const aK = [VX, cb, vK.wgsl, `@group(2) @binding(0) var<uniform> uniforms: ${OO.structName};`, ...hO].join("\n"),
        oO = pO.attributes,
        FO = ["struct VertexInputs {", "\t@builtin(vertex_index) vertexIndex: u32,", "\t@builtin(instance_index) instanceIndex: u32,", ...pO.attributes.map(((OO, KO) => `\t@location(${KO}) ${OO.name}: ${OO.type},`)), "}", "var<private> vertexInputs: VertexInputs;"].join("\n"),
        VO = ["struct FragmentInputs {", "\t@builtin(position) position: vec4f,", ...eO, "}", "var<private> vertexOutputs: FragmentInputs;"].join("\n"),
        LO = ["struct FragmentInputs {", "\t@builtin(position) position: vec4f,", ...XO.body.includes("fragmentInputs.frontFacing") ? ["\t@builtin(front_facing) frontFacing: bool,"] : [], ...eO, "}", "var<private> fragmentInputs: FragmentInputs;", "struct FragmentOutputs {", "\t@location(0) color: vec4f,", "}", "var<private> fragmentOutputs: FragmentOutputs;", nO, "fn canvasOutputs() -> FragmentOutputs {", `\tif (${xK}) {`, "\t\tfragmentOutputs.color.a = 1.0;", "\t}", "\treturn fragmentOutputs;", "}"].join("\n"),
        QO = OO => {
          for (const KO of vK.stridedArrays) OO = OO.replace(new RegExp(`\\b${KO}\\s*\\[(.*?)\\]`, "g"), `${KO}[$1].el`);
          return OO
        };
      return {
        vertex: `${aK}\n${FO}\n${VO}\n${QO(pO.body)}`,
        fragment: `diagnostic(off, derivative_uniformity);\n${aK}\n${LO}\n${hb((zK=QO(XO.body),zK.includes("fragmentInputs.position")?zK.replace("fragmentInputs = input;","fragmentInputs = input;\nfragmentInputs.position.y = frame.outputHeight - fragmentInputs.position.y;"):zK))}`,
        attributes: oO,
        material: vK,
        textures: CO
      };
      var zK
    }
    const ob = [6, 4, 5, 7, 6, 5, 0, 2, 3, 1, 0, 3, 5, 1, 3, 7, 5, 3, 0, 4, 6, 2, 0, 6, 3, 2, 6, 7, 3, 6, 0, 1, 5, 4, 0, 5],
      Fb = OO => ({
        name: OO,
        type: "vec3"
      }),
      Vb = OO => ({
        name: OO,
        type: "float"
      }),
      Lb = ib("EarthSkyUniforms", [Fb("viewFrom"), Vb("exposureScale"), Fb("zenithOffset"), Vb("fogOn"), Fb("up"), Vb("ditherOn"), Fb("sun"), Vb("turbidity"), Fb("tint"), Vb("rayleigh"), Fb("sunDir"), Vb("mieStrength"), Fb("inScatterR"), Vb("mieFocus"), Fb("inScatterM"), Vb("sunE"), Fb("extinctionBeta"), Vb("sunsetMix"), Vb("mieScale"), Vb("mieBase"), Vb("mieSlope"), Vb("sunDiscE"), Vb("exposure")]),
      Qb = `${VX}\n${cb}\n${Lb.wgsl}\n@group(2) @binding(0) var<uniform> sky: EarthSkyUniforms;\nstruct EarthSkyVarying {\n\t@builtin(position) position: vec4f,\n\t@location(0) worldPosition: vec3f,\n\t@location(1) fogDistance: vec3f,\n\t@location(2) tint: vec3f,\n}\n`,
      ze = `\n@vertex\nfn main(@builtin(vertex_index) index: u32) -> EarthSkyVarying {\n\tlet corners = array<u32, 36>(${ob.join(", ")});\n\tlet corner = corners[index];\n\tlet position = vec3f(f32(corner & 1u), f32((corner >> 1u) & 1u), f32(corner >> 2u)) - 0.5;\n\tvar out: EarthSkyVarying;\n\tout.position = liteWorldLayer(scene.viewProjection * mesh.world * vec4f(position, 1.0));\n\tlet worldPosition = mesh.world * vec4f(position, 1.0);\n\tout.worldPosition = worldPosition.xyz;\n\tout.fogDistance = (scene.view * worldPosition).xyz;\n\tout.tint = sky.tint;\n\treturn out;\n}\n`,
      Ab = `\n${nO}\nconst PI: f32 = 3.141592653589793238462643383279502884197169;\nconst SUN_DISC_COS: f32 = 0.999956676946448443553574619906976478926848692873900859324;\n${Object.entries(LK).map((OO=>{let[KO,pO]=OO;return`const TONE_${KO}: f32 = ${pO};`})).join(" ")}\n\n// The rest of main's prelude, as it was, for sky pack overrides that use it; the default calls none of it\nconst WAVELENGTHS: vec3f = vec3f(680E-9, 550E-9, 450E-9);\nconst MIE_K: vec3f = vec3f(0.686, 0.678, 0.666);\nconst MIE_V: f32 = 4.0;\nconst RAYLEIGH_ZENITH_LENGTH: f32 = 8.4E3;\nconst MIE_ZENITH_LENGTH: f32 = 1.25E3;\nconst SUN_INTENSITY: f32 = 1000.0;\nconst SUN_CUTOFF: f32 = PI / 1.95;\nconst SUN_STEEPNESS: f32 = 1.5;\nconst TONE_WHITE: f32 = 1000.0;\n\nfn rayleighBeta() -> vec3f { return vec3f(0.0005) / vec3f(94, 40, 18); }\n\nfn rayleighPhase(cosTheta: f32) -> f32 { return (3.0 / (16.0 * PI)) * (1.0 + pow(cosTheta, 2.0)); }\n\nfn mieBeta(wavelengths: vec3f, k: vec3f, turbidity: f32) -> vec3f {\n\tvar c: f32 = (0.2 * turbidity) * 10E-18;\n\treturn 0.434 * c * PI * pow((2.0 * PI) / wavelengths, vec3f(MIE_V - 2.0)) * k;\n}\n\nfn henyeyGreenstein(cosTheta: f32, g: f32) -> f32 {\n\treturn (1.0 / (4.0 * PI)) * ((1.0 - pow(g, 2.0)) / pow(1.0 - 2.0 * g * cosTheta + pow(g, 2.0), 1.5));\n}\n\nfn sunIntensity(zenithAngleCos: f32) -> f32 {\n\treturn SUN_INTENSITY * max(0.0, 1.0 - exp((-(SUN_CUTOFF - acos(zenithAngleCos)) / SUN_STEEPNESS)));\n}\n\n// A sky shader pack can replace earthSkyRadiance (the scattering, over EarthSkyInput) or earthSkyColour (the tonemap) by\n// name. The prelude, EarthSkyInput and both signatures are main's, so a pack written against main compiles unchanged.\nstruct EarthSkyInput {\n\tview: vec3f, zenithView: vec3f, sun: vec3f, up: vec3f,\n\tturbidity: f32, rayleigh: f32, mieStrength: f32, mieFocus: f32,\n}\n\nfn filmic(x: vec3f) -> vec3f {\n\treturn ((x * (TONE_A * x + TONE_C * TONE_B) + TONE_D * TONE_E) / (x * (TONE_A * x + TONE_B) + TONE_D * TONE_F)) - TONE_E / TONE_F;\n}\n\n// The default reads input's view, zenithView and up, and the terms the CPU precomputes from the frame's uniforms\n// (earthSkyDerived.ts) straight from sky: they already include input's sun, turbidity, rayleigh, mieStrength and mieFocus.\nfn earthSkyRadiance(input: EarthSkyInput) -> vec3f {\n\t// cos(acos(x)) is x: the Rayleigh and Mie optical lengths share this denominator\n\tlet cosZenith = max(0.0, dot(input.up, input.zenithView));\n\tlet zenithAngle = acos(cosZenith);\n\tlet opticalLength = 1.0 / (cosZenith + 0.15 * pow(93.885 - ((zenithAngle * 180.0) / PI), -1.253));\n\tlet extinction = exp(-sky.extinctionBeta * opticalLength);\n\tlet cosTheta = dot(input.view, sky.sunDir);\n\tlet rCos = cosTheta * 0.5 + 0.5;\n\tlet rPhase = (3.0 / (16.0 * PI)) * (1.0 + rCos * rCos);\n\tlet mBase = sky.mieBase - sky.mieSlope * cosTheta;\n\tlet mPhase = sky.mieScale * inverseSqrt(mBase) / mBase;\n\tlet scattered = sky.inScatterR * rPhase + sky.inScatterM * mPhase;\n\tlet lit = scattered * (1.0 - extinction);\n\tlet inScattered = lit * sqrt(lit) * mix(vec3f(1.0), sqrt(scattered * extinction), vec3f(sky.sunsetMix));\n\tlet sunDisc = smoothstep(SUN_DISC_COS, SUN_DISC_COS + 0.00002, cosTheta);\n\tlet night = (0.1 + sky.sunDiscE * sunDisc) * extinction;\n\treturn (inScattered + night) * 0.04 + vec3f(0.0, 0.001, 0.0025) * 0.3;\n}\n\n// The contract for overrides: exposure is SkyMaterial's luminance (main passes sky.exposure), as Babylon's tonemap reads it.\n// The default tonemaps with the frame's precomputed sky.exposureScale, its log2(2 / exposure^4), written together with it.\nfn earthSkyColour(radiance: vec3f, exposure: f32) -> vec3f {\n\treturn filmic(sky.exposureScale * radiance) * ${QK};\n}\n\nfn ditherOffset(seed: vec2f, variance: f32) -> f32 {\n\tlet rand: f32 = fract(sin(dot(seed.xy, vec2f(12.9898, 78.233))) * 43758.5453);\n\tlet normVariance: f32 = variance / 255.0;\n\treturn mix(-normVariance, normVariance, rand);\n}\n\nfn fogFactor(fromEye: vec3f) -> f32 {\n\tvar fogCoeff: f32 = 1.0;\n\tlet fogStart = frame.vFogInfos.y;\n\tlet fogEnd = frame.vFogInfos.z;\n\tlet fogDensity = frame.vFogInfos.w;\n\tlet dist = length(fromEye);\n\tif (3.0 == frame.vFogInfos.x) {\n\t\tfogCoeff = (fogEnd - dist) / (fogEnd - fogStart);\n\t} else if (1.0 == frame.vFogInfos.x) {\n\t\tfogCoeff = 1.0 / pow(2.71828, dist * fogDensity);\n\t} else if (2.0 == frame.vFogInfos.x) {\n\t\tfogCoeff = 1.0 / pow(2.71828, dist * dist * fogDensity * fogDensity);\n\t}\n\treturn clamp(fogCoeff, 0.0, 1.0);\n}\n\n@fragment\nfn main(input: EarthSkyVarying) -> @location(0) vec4f {\n\tlet toSky = input.worldPosition - sky.viewFrom;\n\tlet radiance = earthSkyRadiance(EarthSkyInput(normalize(toSky), normalize(toSky + sky.zenithOffset), sky.sun, sky.up, sky.turbidity, sky.rayleigh, sky.mieStrength, sky.mieFocus));\n\t// Parity: off, the dither and fog branches are skipped, as Babylon leaves them out with its defines; the dither reads the WebGL frag coord, as in Babylon\n\tvar dither = 0.0;\n\tif (sky.ditherOn != 0.0) { dither = ditherOffset(vec2f(input.position.x, frame.outputHeight - input.position.y), 0.5); }\n\tvar colour = clamp(vec4f(earthSkyColour(radiance, sky.exposure) * input.tint + dither, 1.0), vec4f(0.0), vec4f(1.0));\n\tif (sky.fogOn != 0.0) { colour = vec4f(mix(frame.vFogColor, colour.rgb, fogFactor(input.fogDistance)), colour.a); }\n\t// The canvas's alpha on the unblended pipeline it draws in (canvasFragment)\n\tif (${xK}) { colour.a = 1.0; }\n\treturn colour;\n}\n`;
    var fb = pO(35624);
    const db = new fb.WX,
      Tb = new fb.WX,
      Nb = new fb.Quaternion,
      Ib = new Float64Array(3),
      ye = new class {
        constructor() {
          this.sunDir = new Float64Array(3), this.sunE = 0, this.inScatterR = new Float64Array(3), this.inScatterM = new Float64Array(3), this.extinctionBeta = new Float64Array(3), this.sunsetMix = 0, this.sunDiscE = 0, this.mieScale = 0, this.mieBase = 0, this.mieSlope = 0
        }
      },
      ge = new Float64Array(16);

    function ub(OO, KO, pO) {
      const XO = pO.worldMatrix;
      var bK;
      OO.updateFloat3("viewFrom", XO[12], XO[13], XO[14]), OO.updateFloatsFrom("zenithOffset", KO.cameraOffset, 0, 3), OO.updateFloatsFrom("up", KO.up, 0, 3), KO.luminance > 0 && (OO.updateFloat("exposure", KO.luminance), OO.updateFloat("exposureScale", (bK = KO.luminance, Math.log2(2 / Math.pow(bK, 4))))), OO.updateFloat("turbidity", KO.turbidity), OO.updateFloat("rayleigh", KO.rayleigh), OO.updateFloat("mieStrength", KO.mieCoefficient), OO.updateFloat("mieFocus", KO.mieDirectionalG), OO.updateFloatsFrom("tint", KO.tint, 0, 3), OO.updateFloat("fogOn", KO.fog && pO.fogEnabled && 0 !== pO.fogMode ? 1 : 0), OO.updateFloat("ditherOn", KO.dithering ? 1 : 0);
      const eO = KO.sunPosition;
      if (db.set(eO[0], eO[1], eO[2]), !KO.useSunPosition) {
        const OO = Math.PI * (KO.inclination - .5),
          pO = 2 * Math.PI * (KO.azimuth - .5);
        db.set(KO.distance * Math.cos(pO) * Math.cos(OO), KO.distance * Math.sin(-OO), KO.distance * Math.sin(pO) * Math.cos(OO)), fb.Quaternion.FromUnitVectorsToRef(fb.WX.UpReadOnly, Tb.set(KO.up[0], KO.up[1], KO.up[2]), Nb), db.rotateByQuaternionToRef(Nb, db)
      }
      OO.updateVector3("sun", db), Ib[0] = db.x, Ib[1] = db.y, Ib[2] = db.z;
      const lO = VK(KO, Ib, ye);
      OO.updateFloatsFrom("sunDir", lO.sunDir, 0, 3), OO.updateFloat("sunE", lO.sunE), OO.updateFloatsFrom("inScatterR", lO.inScatterR, 0, 3), OO.updateFloatsFrom("inScatterM", lO.inScatterM, 0, 3), OO.updateFloatsFrom("extinctionBeta", lO.extinctionBeta, 0, 3), OO.updateFloat("sunsetMix", lO.sunsetMix), OO.updateFloat("sunDiscE", lO.sunDiscE), OO.updateFloat("mieScale", lO.mieScale), OO.updateFloat("mieBase", lO.mieBase), OO.updateFloat("mieSlope", lO.mieSlope)
    }

    function Eb(OO, KO) {
      const pO = ge;
      pO[0] = KO.far, pO[5] = KO.far, pO[10] = KO.far, pO[15] = 1;
      const XO = OO.infiniteDistance;
      for (let bK = 0; bK < 3; bK++) pO[12 + bK] = OO.position[bK] + (XO ? KO.worldMatrix[12 + bK] : 0);
      return ge
    }
    var je = pO(37097);

    function Yb(OO) {
      return Math.max(4, 4 * Math.ceil(OO / 4))
    }

    function wb(OO, KO, pO, XO) {
      const bK = OO.createBuffer({
        label: XO,
        size: Yb(KO.byteLength),
        usage: pO,
        mappedAtCreation: !0
      });
      return new Uint8Array(bK.getMappedRange(), 0, KO.byteLength).set(new Uint8Array(KO.buffer, KO.byteOffset, KO.byteLength)), bK.unmap(), bK
    }

    function ie(OO, KO) {
      return Math.floor(Math.log2(Math.max(OO, KO))) + 1
    }

    function re(OO, KO, pO, XO, bK, eO) {
      const lO = OO.createTexture({
          label: eO,
          size: {
            width: pO,
            height: XO,
            depthOrArrayLayers: bK
          },
          format: "rgba8unorm",
          mipLevelCount: ie(pO, XO),
          usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
        }),
        vK = (KO, pO, XO, eO) => {
          OO.queue.writeTexture({
            texture: lO,
            mipLevel: pO
          }, KO, {
            bytesPerRow: 4 * XO,
            rowsPerImage: eO
          }, {
            width: XO,
            height: eO,
            depthOrArrayLayers: bK
          })
        };
      vK(KO, 0, pO, XO);
      let CO = 1;
      for (const hO of function*(OO, KO, pO, XO) {
          let bK = OO,
            eO = KO,
            lO = pO;
          for (; eO > 1 || lO > 1;) {
            const OO = Math.max(1, eO >> 1),
              KO = Math.max(1, lO >> 1),
              pO = new Uint8Array(OO * KO * XO * 4),
              vK = 4 * eO;
            let CO = 0;
            for (let hO = 0; hO < XO; hO++) {
              const XO = hO * vK * lO;
              for (let hO = 0; hO < KO; hO++) {
                const KO = XO + Math.min(2 * hO, lO - 1) * vK,
                  DO = XO + Math.min(2 * hO + 1, lO - 1) * vK;
                for (let XO = 0; XO < OO; XO++) {
                  const OO = 4 * Math.min(2 * XO, eO - 1),
                    lO = 4 * Math.min(2 * XO + 1, eO - 1);
                  for (let XO = 0; XO < 4; XO++) pO[CO++] = bK[KO + OO + XO] + bK[KO + lO + XO] + bK[DO + OO + XO] + bK[DO + lO + XO] + 2 >> 2
                }
              }
            }
            yield {
              data: pO,
              width: OO,
              height: KO
            }, bK = pO, eO = OO, lO = KO
          }
        }(KO, pO, XO, bK)) vK(hO.data, CO++, hO.width, hO.height);
      return lO
    }
    const Pb = {
      premultiplyAlpha: "none",
      colorSpaceConversion: "none"
    };

    function me(OO) {
      if (OO.startsWith("data:")) {
        const KO = OO.search(/[;,]/);
        return `data:${KO>5?OO.slice(5,KO):""} URL of ${OO.length} characters`
      }
      return OO.length > 80 ? `${OO.slice(0,80)}...` : OO
    }
    async function sb(OO) {
      const KO = await fetch(OO);
      if (!KO.ok) throw new Error(`${me(OO)}: ${KO.status} ${KO.statusText}`);
      return createImageBitmap(await KO.blob(), Pb)
    }
    async function Hb(OO) {
      const KO = await sb(OO),
        pO = new OffscreenCanvas(KO.width, KO.height),
        XO = pO.getContext("2d", {
          willReadFrequently: !0
        });
      if (!XO) throw new Error("No 2D context to decode an image");
      XO.drawImage(KO, 0, 0);
      const {
        data: bK
      } = XO.getImageData(0, 0, KO.width, KO.height);
      return KO.close(), {
        pixels: new Uint8Array(bK.buffer, bK.byteOffset, bK.byteLength),
        width: pO.width,
        height: pO.height
      }
    }
    const Rb = new WeakMap;

    function Sb(OO, KO, pO, XO) {
      var bK;
      const eO = null !== (bK = Rb.get(OO)) && void 0 !== bK ? bK : new Map;
      Rb.set(OO, eO);
      let lO = eO.get(KO);
      return lO || (lO = (async bK => {
        const eO = null !== (bK = function(OO, KO) {
          const pO = OO ? new Uint8Array(OO.buffer, OO.byteOffset, OO.byteLength) : null;
          return null !== pO && void 0 !== pO && pO.byteLength && KO && pO.byteLength % (KO * KO * 4) === 0 ? {
            pixels: pO,
            layerWidth: KO,
            layers: pO.byteLength / (KO * KO * 4)
          } : null
        }(pO, XO)) && void 0 !== bK ? bK : await async function(OO) {
          const {
            pixels: KO,
            width: pO
          } = await Hb(OO);
          return {
            pixels: KO,
            layerWidth: pO,
            layers: KO.byteLength / (pO * pO * 4)
          }
        }(KO), {
          layerWidth: lO,
          layers: vK
        } = eO;
        return {
          texture: re(OO, eO.pixels, lO, lO, vK, `atlas-${KO}`),
          layerWidth: lO,
          layers: vK
        }
      })(), eO.set(KO, lO), lO.catch((() => {
        eO.delete(KO)
      }))), lO
    }
    const Jb = new Map([
        [0, "zero"],
        [1, "one"],
        [768, "src"],
        [769, "one-minus-src"],
        [770, "src-alpha"],
        [771, "one-minus-src-alpha"],
        [772, "dst-alpha"],
        [773, "one-minus-dst-alpha"],
        [774, "dst"],
        [775, "one-minus-dst"],
        [776, "src-alpha-saturated"]
      ]),
      ce = new Map([
        [1, [770, 1, "add"]],
        [2, [770, 771, "add"]],
        [3, [0, 769, "add"]],
        [4, [774, 0, "add"]],
        [5, [770, 769, "add"]],
        [6, [1, 1, "add"]],
        [7, [1, 771, "add"]],
        [8, [1, 771, "add"]],
        [10, [1, 769, "add"]],
        [11, [1, 1, "add"]],
        [14, [1, 771, "add"]],
        [15, [1, 1, "add"]],
        [17, [770, 771, "add"]],
        [18, [1, 1, "min"]],
        [19, [1, 1, "max"]]
      ]);

    function Bb(OO) {
      for (const KO of (0, je.k)(OO))
        if (!ce.has((0, je.j)(KO))) return !1;
      return !0
    }

    function Zb(OO) {
      const KO = ce.get(OO);
      if (!KO) return null;
      const [pO, XO, bK] = KO;
      return {
        srcFactor: Jb.get(pO),
        dstFactor: Jb.get(XO),
        operation: bK
      }
    }
    let Gb = null;

    function qe(OO) {
      Gb = OO
    }

    function xe(OO, KO, pO) {
      var XO;
      null === (XO = Gb) || void 0 === XO || XO(OO, KO, pO, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null)
    }
    class nb {
      constructor() {
        this.pipeline = null, this.materialGroup = null, this.packGroup = null, this.vertexBuffers = [], this.vertexOffsets = [], this.indexBuffer = null
      }
      reset() {
        this.pipeline = null, this.materialGroup = null, this.packGroup = null, this.vertexBuffers.length = 0, this.vertexOffsets.length = 0, this.indexBuffer = null
      }
      bind(OO, KO, pO, XO, bK) {
        pO !== this.pipeline && (OO.setPipeline(pO), this.pipeline = pO), OO.setBindGroup(1, XO, [bK]);
        const eO = KO.material.bindGroup;
        eO !== this.materialGroup && (OO.setBindGroup(2, eO), this.materialGroup = eO);
        const lO = KO.program.packGroup;
        lO && lO !== this.packGroup && (OO.setBindGroup(gp.d, lO), this.packGroup = lO);
        const {
          vertexBuffers: vK,
          vertexOffsets: CO
        } = this;
        for (let hO = 0; hO < KO.vertexBuffers.length; hO++) vK[hO] === KO.vertexBuffers[hO] && CO[hO] === KO.vertexOffsets[hO] || (OO.setVertexBuffer(hO, KO.vertexBuffers[hO], KO.vertexOffsets[hO]), vK[hO] = KO.vertexBuffers[hO], CO[hO] = KO.vertexOffsets[hO]);
        KO.indexBuffer && KO.indexBuffer !== this.indexBuffer && (OO.setIndexBuffer(KO.indexBuffer, KO.indexFormat), this.indexBuffer = KO.indexBuffer)
      }
    }
    class Wb {
      constructor(OO, KO, pO, XO) {
        this.modelMeshes = OO, this.XlO = KO, this.maker = pO, this.warnOnce = XO, this.skyDraws = [], this.opaqueDraws = [], this.transparentDraws = [], this.frontDraws = []
      }
      clear() {
        this.skyDraws.length = 0, this.opaqueDraws.length = 0, this.transparentDraws.length = 0, this.frontDraws.length = 0
      }
      collect(OO) {
        this.collectGroup(OO, -1, this.skyDraws, this.skyDraws, !0), this.collectGroup(OO, 0, this.opaqueDraws, this.transparentDraws, !1), this.collectGroup(OO, 1, this.frontDraws, this.frontDraws, !0);
        for (const KO of this.modelMeshes.groupIds())(KO < -1 || KO > 1) && this.warnOnce(`group:${KO}`, `rendering group ${KO} is not drawn`);
        for (const KO of this.XlO.groupIds())(KO < -1 || KO > 1) && this.warnOnce(`group:${KO}`, `rendering group ${KO} is not drawn`);
        this.opaqueDraws.sort(te), this.transparentDraws.sort(ke)
      }
      collectGroup(OO, KO, pO, XO, bK) {
        const eO = this.modelMeshes.group(KO),
          lO = this.XlO.group(KO),
          vK = 0 === KO ? null === lO || void 0 === lO ? void 0 : lO.opaque : void 0;
        this.collectList(OO, null === eO || void 0 === eO ? void 0 : eO.opaque, vK || null === lO || void 0 === lO ? void 0 : lO.opaque, KO, !1, pO, bK), vK && (this.XlO.drawn += this.maker.bundleDraws(OO, vK, KO)), this.collectList(OO, null === eO || void 0 === eO ? void 0 : eO.alphaTest, void 0, KO, !1, pO, bK), this.collectList(OO, null === eO || void 0 === eO ? void 0 : eO.transparent, null === lO || void 0 === lO ? void 0 : lO.transparent, KO, !0, XO, bK)
      }
      collectList(OO, KO, pO, XO, bK, eO, lO) {
        var vK;
        const CO = eO.length;
        KO && this.maker.pushDraws(OO, KO.units, KO.units.length, XO, bK, eO, KO.rows), pO && (this.XlO.drawn += this.maker.pushDraws(OO, pO, pO.length, XO, bK, eO));
        const hO = bK ? null === (vK = this.modelMeshes.group(XO)) || void 0 === vK ? void 0 : vK.text : void 0;
        hO && this.maker.pushDraws(OO, hO.units, hO.units.length, XO, !0, eO, hO.rows), lO && Ub(eO, CO)
      }
    }

    function te(OO, KO) {
      return OO.program.id - KO.program.id || OO.material.owner.uniqueId - KO.material.owner.uniqueId
    }

    function ke(OO, KO) {
      return OO.material.owner.uniqueId - KO.material.owner.uniqueId
    }

    function Ub(OO, KO) {
      for (let pO = KO + 1; pO < OO.length; pO++) {
        const XO = OO[pO];
        let bK = pO - 1;
        for (; bK >= KO && ke(OO[bK], XO) > 0; bK--) OO[bK + 1] = OO[bK];
        OO[bK + 1] = XO
      }
    }
    const Oe = {};

    function Ke(OO) {
      return OO.hasThinInstances ? "thin" : OO.RDO || OO._userInstancedBuffersStorage ? "instanced" : "none"
    }

    function pe(OO, KO, pO) {
      return OO ? (pO._needUVs = !0, OO.optimizeUVAllocation && (0, uO.G)(OO.matrix) ? (pO[`${KO}DIRECTUV`] = OO.uvSet + 1, pO[`MAINUV${OO.uvSet+1}`] = !0) : pO[`${KO}DIRECTUV`] = 0, !0) : (pO[`${KO}DIRECTUV`] = 0, !1)
    }

    function Xe(OO) {
      const KO = new Map;
      for (const pO in OO) {
        if (95 === pO.charCodeAt(0)) continue;
        const XO = OO[pO],
          bK = typeof XO;
        "number" === bK || "string" === bK ? KO.set(pO, String(XO)) : XO && "function" !== bK && KO.set(pO, !0)
      }
      return KO
    }

    function bl(OO) {
      const KO = {
        markAllAsDirty: () => {}
      };
      for (const {
          defines: pO
        }
        of OO.features)
        for (const OO in pO) KO[OO] = pO[OO];
      return KO
    }

    function ee(OO) {
      const KO = OO.parts.geometry;
      return null !== KO && void 0 !== KO && KO.live ? KO : null
    }

    function le(OO) {
      var KO;
      return null !== (KO = ee(OO)) && void 0 !== KO ? KO : Oe
    }
    class vl {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : () => !1;
        this.resources = OO, this.warnOnce = KO, this.programWithModel = pO, this.packFailed = XO, this.drawStates = new WeakMap, this.view = void 0, this.modelPackVariant = 0
      }
      programFor(OO, KO, pO, XO, bK) {
        const eO = KO.owner;
        let lO = this.drawStates.get(KO);
        if (!lO) {
          const OO = KO.parts.materials[KO.range];
          if (!OO) return this.warnOnce("model", `${pO.name} on ${eO.name} is not a model material, so it is not drawn on WebGPU (adoptModelMaterial); further ones are not reported`), null;
          lO = {
            defines: bl(OO),
            model: OO,
            modelVersion: -1,
            definesKey: "",
            program: null,
            instancing: bK,
            groupId: XO,
            geometry: null,
            instanceLayout: null,
            definesBits: 0,
            packVariant: 0
          }, this.drawStates.set(KO, lO)
        }
        if (this.programCurrent(lO, KO, bK, XO)) return lO.program;
        const {
          model: vK
        } = lO, CO = le(KO), hO = this.instanceLayout(eO, bK), DO = this.definesBits(eO);
        if (!this.prepareModelDefines(OO, eO, vK, lO.defines, XO, bK)) return null;
        lO.instancing = bK, lO.groupId = XO, lO.modelVersion = vK.version, lO.geometry = CO, lO.instanceLayout = hO, lO.definesBits = DO;
        const MO = function(OO) {
          let KO = "";
          for (const [pO, XO] of OO) KO += !0 === XO ? `${pO};` : `${pO}=${XO};`;
          return KO
        }(Xe(lO.defines));
        return MO === lO.definesKey && lO.packVariant === this.modelPackVariant && lO.program && !this.packFailed(lO.program) || (lO.definesKey = MO, lO.packVariant = this.modelPackVariant, lO.program = this.programWithModel(vK, lO.defines, MO)), lO.program
      }
      programCurrent(OO, KO, pO, XO) {
        return null !== OO.program && !this.packFailed(OO.program) && OO.instancing === pO && OO.groupId === XO && this.definesHold(OO, KO, pO)
      }
      definesHold(OO, KO, pO) {
        return OO.modelVersion === OO.model.version && OO.geometry === le(KO) && OO.instanceLayout === this.instanceLayout(KO.owner, pO) && OO.definesBits === this.definesBits(KO.owner) && OO.packVariant === this.modelPackVariant
      }
      modelPackKind(OO) {
        var KO;
        return 0 === this.modelPackVariant ? null : null !== (KO = (0, yK.w)(OO, IO.i.name)) && void 0 !== KO && KO.active ? "placed" : OO.item ? "item" : OO.lifeform ? "lifeform" : OO.box ? "box" : null
      }
      instanceLayout(OO, KO) {
        var pO, XO, bK;
        return "thin" === KO ? null !== (bK = this.resources.HeO.get(OO)) && void 0 !== bK ? bK : null : "instanced" === KO && null !== (pO = null === (XO = OO._userInstancedBuffersStorage) || void 0 === XO ? void 0 : XO.interleavedKinds) && void 0 !== pO ? pO : null
      }
      definesBits(OO) {
        const KO = this.view;
        return (OO.visibility < 1 ? 1 : 0) | (OO.hasVertexAlpha ? 2 : 0) | (OO.applyFog ? 4 : 0) | (OO.useVertexColors ? 8 : 0) | (OO.nonUniformScaling ? 16 : 0) | (KO.fogEnabled && 0 !== KO.fogMode ? 32 : 0) | (KO.lightsEnabled ? 64 : 0) | KO.lightCount << 7
      }
      prepareLightDefines(OO, KO, pO) {
        let XO = 0;
        if (this.view.lightsEnabled && !KO) {
          const KO = Math.min(pO, 4);
          for (; XO < this.view.lightCount && (OO[`LIGHT${XO}`] = !0, OO[`LITE_LIGHT${XO}_SLOT`] = XO, XO++, OO._needNormals = !0, XO !== KO););
        }
        for (let bK = XO; bK < 4; bK++) OO[`LIGHT${bK}`] = !1, OO[`LITE_LIGHT${bK}_SLOT`] = void 0
      }
      prepareModelDefines(OO, KO, pO, XO, bK, eO) {
        const {
          features: lO
        } = pO;
        XO._needNormals = !1, XO._needUVs = !1;
        const vK = this.view;
        this.prepareLightDefines(XO, pO.disableLighting, pO.maxSimultaneousLights), XO.MAINUV1 = !1, XO.MAINUV2 = !1;
        const CO = pO.diffuseTexture;
        CO ? (XO._needUVs = !0, XO.DIFFUSE = !0, CO.optimizeUVAllocation && (0, uO.G)(CO.matrix) ? (XO.DIFFUSEDIRECTUV = CO.uvSet + 1, XO[`MAINUV${CO.uvSet+1}`] = !0) : XO.DIFFUSEDIRECTUV = 0, CO.uvSet > 1 && this.warnOnce(`uvset:${pO.name}`, `${pO.name} samples UV set ${CO.uvSet+1}, which is not supported`)) : (XO.DIFFUSE = !1, XO.DIFFUSEDIRECTUV = 0);
        const hO = pO.opacityTexture,
          DO = pO.emissiveTexture;
        XO.OPACITY = pe(hO, "OPACITY", XO), XO.OPACITYRGB = null !== hO && hO.getAlphaFromRGB, XO.EMISSIVE = pe(DO, "EMISSIVE", XO), (hO && hO.uvSet > 1 || DO && DO.uvSet > 1) && this.warnOnce(`uvset:${pO.name}`, `${pO.name} samples a UV set past 2, which is not supported`);
        const MO = pO.reflectionTexture,
          aK = null !== MO;
        if (aK) {
          if (!this.resources.boundTexture(MO)) return !1;
          XO._needNormals = !0
        }
        XO.REFLECTION = aK, XO.REFLECTIONMAP_3D = aK, XO.REFLECTIONMAP_SKYBOX = aK, XO.REFLECTIONMAP_OPPOSITEZ = aK && (OO.useRightHandedSystem ? !MO.invertZ : MO.invertZ), XO.ROUGHNESS = aK && pO.roughness > 0, XO.REFLECTIONOVERALPHA = aK && pO.useReflectionOverAlpha, XO.LITE_REFLECTION_LUMINANCE = aK && "cube" === MO.source.kind && MO.source.luminance, (KO.skeleton || KO.morphTargetManager) && this.warnOnce(`skin:${KO.name}`, `${KO.name} has bones or morph targets, which are not supported`), XO.FOG = pO.fogEnabled && KO.applyFog && vK.fogEnabled && 0 !== vK.fogMode, XO.NONUNIFORMSCALING = KO.nonUniformScaling;
        const {
          visibility: oO,
          hasVertexAlpha: FO
        } = KO;
        XO.ALPHATEST = (0, yK.V)(pO, oO, FO), XO.ALPHAFROMDIFFUSE = (0, yK.jb)(pO), XO.ALPHATEST_AFTERALLALPHACOMPUTATIONS = null !== pO.transparencyMode, XO.ALPHABLEND = null === pO.transparencyMode || (0, yK.R)(pO, oO, FO), XO.PREMULTIPLYALPHA = 7 === pO.alphaMode || 8 === pO.alphaMode, XO.EMISSIVEASILLUMINATION = pO.useEmissiveAsIllumination, XO.LINKEMISSIVEWITHDIFFUSE = pO.linkEmissiveWithDiffuse, XO.TWOSIDEDLIGHTING = !pO.backFaceCulling && pO.twoSidedLighting, XO.INSTANCES = "none" !== eO, XO.THIN_INSTANCES = "thin" === eO, XO.LITE_FRONT_LAYER = bK >= 1;
        for (const {
            feature: NO,
            state: IO,
            active: yK
          }
          of lO) {
          var VO, LO;
          if (yK) null === (VO = (LO = (0, DK.g)(NO)).prepareDefinesBeforeAttributes) || void 0 === VO || VO.call(LO, IO, XO, OO, KO)
        }
        this.modelPackKind(pO) && (XO._needNormals = !0), XO.NORMAL = XO._needNormals && KO.isVerticesDataPresent("normal"), XO.UV1 = XO._needUVs && KO.isVerticesDataPresent("uv"), XO.UV2 = XO._needUVs && KO.isVerticesDataPresent("uv2");
        const QO = KO.useVertexColors && KO.isVerticesDataPresent("color");
        XO.VERTEXCOLOR = QO, XO.VERTEXALPHA = KO.hasVertexAlpha && QO, XO.INSTANCESCOLOR = "none" !== eO && KO.isVerticesDataPresent("instanceColor");
        for (const {
            feature: NO,
            state: IO,
            active: yK
          }
          of lO) {
          var zK, AO;
          if (yK) null === (zK = (AO = (0, DK.g)(NO)).prepareDefines) || void 0 === zK || zK.call(AO, IO, XO, OO, KO, pO)
        }
        const fO = OO.qb();
        for (const {
            feature: NO,
            state: IO,
            active: yK
          }
          of lO) {
          var dO, TO;
          if (yK && !1 === (null === (dO = (TO = (0, DK.g)(NO)).isReadyForSubMesh) || void 0 === dO ? void 0 : dO.call(TO, IO, XO, OO, fO))) return !1
        }
        return !0
      }
    }

    function Ce(OO, KO, pO) {
      return OO.codeVersion !== KO.version && function(OO, KO) {
        const pO = [],
          XO = [];
        for (const {
            feature: aK,
            state: oO,
            active: FO
          }
          of KO.features) {
          var bK, eO, lO, vK;
          if (FO) he(null === (bK = (eO = (0, DK.g)(aK)).getCustomCode) || void 0 === bK ? void 0 : bK.call(eO, oO, "vertex", TO.e.WGSL), pO), he(null === (lO = (vK = (0, DK.g)(aK)).getCustomCode) || void 0 === lO ? void 0 : lO.call(vK, oO, "fragment", TO.e.WGSL), XO)
        }
        const CO = [];
        for (const {
            feature: aK,
            state: oO
          }
          of KO.features) {
          var hO, DO;
          const OO = null === (hO = (DO = (0, DK.g)(aK)).getUniforms) || void 0 === hO ? void 0 : hO.call(DO, oO, TO.e.WGSL);
          for (const KO of null !== (MO = null === OO || void 0 === OO ? void 0 : OO.ubo) && void 0 !== MO ? MO : []) {
            var MO;
            KO.size && KO.type && CO.push({
              name: KO.name,
              type: KO.type,
              arraySize: KO.arraySize
            })
          }
        }
        OO.vertexCode = pO, OO.fragmentCode = XO, OO.pluginUniforms = CO, OO.codeKey = JSON.stringify([pO, XO, CO]), OO.codeVersion = KO.version
      }(OO, KO), `${pO}#${OO.codeKey}`
    }

    function he(OO, KO) {
      if (OO)
        for (const pO in OO) OO[pO] && KO.push([pO, OO[pO]])
    }
    const De = new Map([
      [512, "never"],
      [513, "greater"],
      [514, "equal"],
      [515, "greater-equal"],
      [516, "less"],
      [517, "not-equal"],
      [518, "less-equal"],
      [519, "always"]
    ]);
    class Me {
      constructor(OO) {
        this.warnOnce = OO, this.states = new Map
      }
      renderState(OO, KO, pO, XO) {
        var bK;
        let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "triangle-list",
          lO = null !== (bK = OO.sideOrientation) && void 0 !== bK ? bK : KO.sideOrientation;
        KO._getWorldMatrixDeterminant() < 0 && (lO = 0 === lO ? 1 : 0);
        const vK = "triangle-list" === eO,
          CO = pO ? OO.alphaMode : 0,
          hO = (!pO || (0 === CO || OO.forceDepthWrite)) && !OO.disableDepthWrite,
          DO = vK && OO.backFaceCulling ? OO.cullBackFaces ? "back" : "front" : "none",
          MO = vK && 0 !== lO ? "ccw" : "cw",
          aK = OO.depthFunction,
          oO = vK ? OO.zOffset : 0,
          FO = vK ? OO.zOffsetUnits : 0,
          VO = !OO.disableColorWrite;
        return XO && XO.alphaMode === CO && XO.depthWrite === hO && XO.depthFunction === aK && XO.cullMode === DO && XO.frontFace === MO && XO.zOffset === oO && XO.zOffsetUnits === FO && XO.colourWrite === VO && XO.topology === eO ? XO : this.stateFor(CO, hO, aK, DO, MO, oO, FO, VO, eO)
      }
      stateFor(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        const hO = `${OO}|${KO}|${pO}|${XO}|${bK}|${eO}|${lO}|${vK}|${CO}`;
        let DO = this.states.get(hO);
        if (!DO) {
          var MO;
          const aK = OO ? Zb(OO) : null;
          OO && !aK && this.warnOnce(`alpha:${OO}`, `alpha mode ${OO} is not supported`), DO = {
            key: hO,
            alphaMode: OO,
            depthFunction: pO,
            zOffset: eO,
            zOffsetUnits: lO,
            topology: CO,
            blend: aK,
            depthWrite: KO,
            depthCompare: pO && null !== (MO = De.get(pO)) && void 0 !== MO ? MO : null,
            cullMode: XO,
            frontFace: bK,
            depthBias: -lO,
            depthBiasSlopeScale: -eO,
            colourWrite: vK
          }, this.states.set(hO, DO)
        }
        return DO
      }
    }
    var al = pO(35772);

    function oe(OO) {
      if (!OO.frozen) return -1;
      let KO = OO.version;
      for (const {
          feature: pO,
          state: XO,
          active: bK
        }
        of OO.features) {
        if (!bK || !pO.bind) continue;
        const OO = (0, DK.g)(pO).uniformsVersion;
        if (!OO) return -1;
        KO += OO(XO)
      }
      return KO
    }
    class Fe {
      constructor(OO, KO, pO) {
        this.slots = OO, this.data = KO, this.textures = pO, this.useUbo = !0, this.currentEffect = null, this.expected = new Set
      }
      updateFloat(OO, KO) {
        this.write4(OO, KO, 0, 0, 0, 1)
      }
      updateFloat2(OO, KO, pO) {
        this.write4(OO, KO, pO, 0, 0, 2)
      }
      updateFloat3(OO, KO, pO, XO) {
        this.write4(OO, KO, pO, XO, 0, 3)
      }
      updateFloat4(OO, KO, pO, XO, bK) {
        this.write4(OO, KO, pO, XO, bK, 4)
      }
      updateVector3(OO, KO) {
        this.write4(OO, KO.x, KO.y, KO.z, 0, 3)
      }
      updateVector4(OO, KO) {
        this.write4(OO, KO.x, KO.y, KO.z, KO.w, 4)
      }
      updateColor3(OO, KO) {
        this.write4(OO, KO.r, KO.g, KO.b, 0, 3)
      }
      updateColor4(OO, KO, pO) {
        this.write4(OO, KO.r, KO.g, KO.b, pO, 4)
      }
      updateFloatsFrom(OO, KO, pO, XO) {
        const bK = this.slots.get(OO);
        if (!bK) return;
        const eO = this.data,
          lO = bK.offset;
        for (let vK = 0; vK < XO; vK++) eO[lO + vK] = KO[pO + vK]
      }
      updateFloat3TimesFloats(OO, KO, pO, XO) {
        const bK = this.slots.get(OO);
        if (!bK) return;
        const eO = this.data,
          lO = bK.offset;
        eO[lO] = KO[pO] * XO[0], eO[lO + 1] = KO[pO + 1] * XO[1], eO[lO + 2] = KO[pO + 2] * XO[2]
      }
      AlO(OO, KO) {
        const pO = this.slots.get(OO);
        pO && this.data.set(KO.m, pO.offset)
      }
      updateMatrixFloats(OO, KO) {
        const pO = this.slots.get(OO);
        pO && this.data.set(KO, pO.offset)
      }
      updateFloatArray(OO, KO) {
        const pO = this.slots.get(OO);
        if (!pO) return;
        if (!pO.arraySize || pO.stride === pO.floats) return void this.data.set(KO, pO.offset);
        const XO = Math.min(KO.length, pO.floats * pO.arraySize);
        for (let bK = 0; bK < XO; bK++) this.data[pO.offset + Math.floor(bK / pO.floats) * pO.stride + bK % pO.floats] = KO[bK]
      }
      updateArray(OO, KO) {
        this.updateFloatArray(OO, KO)
      }
      setTexture(OO, KO) {
        this.textures.set(OO, KO), this.expected.delete(OO)
      }
      expectTexture(OO) {
        this.textures.set(OO, null), this.expected.add(OO)
      }
      write4(OO, KO, pO, XO, bK, eO) {
        const lO = this.slots.get(OO);
        if (!lO) return;
        const vK = this.data,
          CO = lO.offset;
        vK[CO] = KO, eO > 1 && (vK[CO + 1] = pO), eO > 2 && (vK[CO + 2] = XO), eO > 3 && (vK[CO + 3] = bK)
      }
    }

    function Ve(OO, KO) {
      const pO = SX,
        XO = al.l,
        bK = OO.lights,
        eO = Math.min(OO.lightCount, 8);
      for (let lO = 0; lO < eO; lO++) {
        const OO = pO.lights + lO * pO.lightStride,
          eO = lO * al.e;
        KO[OO] = bK[eO + XO.vector], KO[OO + 1] = bK[eO + XO.vector + 1], KO[OO + 2] = bK[eO + XO.vector + 2], KO[OO + 3] = bK[eO + XO.kind] === al.h.directional ? 1 : 0, KO[OO + 4] = bK[eO + XO.diffuse], KO[OO + 5] = bK[eO + XO.diffuse + 1], KO[OO + 6] = bK[eO + XO.diffuse + 2], KO[OO + 7] = bK[eO + XO.range], KO[OO + 8] = bK[eO + XO.specular], KO[OO + 9] = bK[eO + XO.specular + 1], KO[OO + 10] = bK[eO + XO.specular + 2], KO[OO + 11] = bK[eO + XO.range]
      }
      KO[pO.fogInfos] = OO.fogMode, KO[pO.fogInfos + 1] = OO.fogStart, KO[pO.fogInfos + 2] = OO.fogEnd, KO[pO.fogInfos + 3] = OO.fogDensity, KO[pO.fogColour] = OO.fogColour[0], KO[pO.fogColour + 1] = OO.fogColour[1], KO[pO.fogColour + 2] = OO.fogColour[2], KO[pO.outputHeight] = OO.renderHeight, KO[pO.animTick] = OO.animTick, KO[pO.timeMs] = OO.timeMs
    }
    class Le {
      constructor(OO) {
        this.instancesOf = OO
      }
      refreshModelUniforms(OO, KO, pO, XO) {
        const bK = oe(pO);
        if (bK >= 0 && bK === KO.heldVersion && KO.textures.get("diffuseSampler") === pO.diffuseTexture && KO.textures.get("reflectionCubeSampler") === pO.reflectionTexture && KO.textures.get("opacitySampler") === pO.opacityTexture && KO.textures.get("emissiveSampler") === pO.emissiveTexture) return !0;
        if (bK < 0)
          for (const eO of this.instancesOf(pO)) eO.heldVersion = -1;
        return this.writeModelUniforms(OO, KO, pO, XO), KO.heldVersion = bK, !1
      }
      writeModelUniforms(OO, KO, pO, XO) {
        const {
          ubo: bK
        } = KO, eO = pO.diffuseTexture, lO = pO.diffuseColor;
        bK.updateFloat4("vDiffuseColor", lO[0], lO[1], lO[2], pO.alpha), eO && (bK.updateFloat2("vDiffuseInfos", eO.uvSet, eO.level), bK.updateMatrixFloats("diffuseMatrix", eO.matrix)), bK.updateFloat("alphaCutOff", pO.alphaCutOff), bK.updateFloatsFrom("vEmissiveColor", pO.emissiveColor, 0, 3), bK.updateFloat3TimesFloats("vAmbientColor", XO.ambientColour, 0, pO.ambientColor);
        const vK = pO.specularColor;
        bK.updateFloat4("vSpecularColor", vK[0], vK[1], vK[2], pO.specularPower), bK.setTexture("diffuseSampler", eO);
        const CO = pO.opacityTexture;
        CO && (bK.updateFloat2("vOpacityInfos", CO.uvSet, CO.level), bK.updateMatrixFloats("opacityMatrix", CO.matrix)), bK.setTexture("opacitySampler", CO);
        const hO = pO.emissiveTexture;
        hO && (bK.updateFloat2("vEmissiveInfos", hO.uvSet, hO.level), bK.updateMatrixFloats("emissiveMatrix", hO.matrix)), bK.setTexture("emissiveSampler", hO);
        const DO = pO.reflectionTexture;
        DO && bK.updateMatrixFloats("reflectionMatrix", DO.matrix), bK.updateFloat2("vReflectionInfos", DO ? DO.level * OO.iblIntensity : 0, pO.roughness), bK.setTexture("reflectionCubeSampler", DO);
        const MO = OO.qb();
        for (const {
            feature: FO,
            state: VO,
            active: LO
          }
          of pO.features) {
          var aK, oO;
          if (LO) null === (aK = (oO = (0, DK.g)(FO)).bind) || void 0 === aK || aK.call(oO, VO, bK, OO, MO)
        }
      }
    }

    function Qe(OO) {
      const KO = OO.replace(/\s+/g, "");
      return /u32|^vec\du$/.test(KO) ? "u32" : /i32|^vec\di$/.test(KO) ? "i32" : "f32"
    }

    function zl(OO, KO) {
      const pO = OO.getSize(),
        XO = Qe(KO),
        bK = OO => 4 === pO ? `${OO}x4` : 2 === pO ? `${OO}x2` : null;
      if ("f32" === XO) {
        if (5126 === OO.type) return 1 === pO ? "float32" : pO >= 2 && pO <= 4 ? `float32x${pO}` : null;
        if (!OO.normalized) return null;
        switch (OO.type) {
          case 5121:
            return bK("unorm8");
          case 5120:
            return bK("snorm8");
          case 5123:
            return bK("unorm16");
          case 5122:
            return bK("snorm16")
        }
        return null
      }
      const eO = "u32" === XO ? "uint" : "sint";
      switch (OO.type) {
        case 5125:
        case 5124:
          return 1 === pO ? `${eO}32` : pO <= 4 ? `${eO}32x${pO}` : null;
        case 5121:
        case 5120:
          return bK(`${eO}8`);
        case 5123:
        case 5122:
          return bK(`${eO}16`)
      }
      return null
    }

    function Ae(OO) {
      var KO;
      const pO = /(8|16|32)(?:x(\d))?$/.exec(OO);
      return pO ? Number(pO[1]) / 8 * Number(null !== (KO = pO[2]) && void 0 !== KO ? KO : 1) : 4
    }
    class fe {
      constructor(OO, KO, pO) {
        this.resources = OO, this.limits = KO, this.warnOnce = pO, this.layouts = new Map
      }
      resolveInputs(OO, KO, pO, XO) {
        const bK = [],
          eO = pO.program.attributes,
          lO = [];
        for (let DO = 0; DO < eO.length; DO++) {
          const pO = eO[DO],
            vK = pO.optional ? null : this.resources.vertexInput(OO, pO.name, XO);
          if (!vK) {
            const OO = Qe(pO.type),
              KO = "u32" === OO ? "uint32x4" : "i32" === OO ? "sint32x4" : "float32x4";
            lO.push(null);
            const XO = bK.find((OO => null === OO.data));
            XO ? XO.attributes.push({
              shaderLocation: DO,
              offset: 0,
              format: KO
            }) : bK.push({
              data: null,
              base: 0,
              stride: 0,
              step: "vertex",
              attributes: [{
                shaderLocation: DO,
                offset: 0,
                format: KO
              }]
            });
            continue
          }
          const CO = vK.getBuffer();
          lO.push(vK);
          const hO = zl(vK, pO.type);
          if (!hO) return this.warnOnce(`format:${KO}:${pO.name}`, `${KO}'s ${pO.name} (type ${vK.type}, size ${vK.getSize()}) has no WebGPU vertex format`), null;
          const MO = vK.getIsInstanced() ? "instance" : "vertex",
            aK = vK.byteStride,
            oO = Ae(hO),
            FO = bK.find((OO => OO.data === CO && OO.stride === aK && OO.step === MO && vK.byteOffset >= OO.base && vK.byteOffset - OO.base + oO <= aK));
          FO ? FO.attributes.push({
            shaderLocation: DO,
            offset: vK.byteOffset - FO.base,
            format: hO
          }) : bK.push({
            data: CO,
            base: vK.byteOffset,
            stride: aK,
            step: MO,
            attributes: [{
              shaderLocation: DO,
              offset: 0,
              format: hO
            }]
          })
        }
        if (bK.length > this.limits.maxVertexBuffers) return this.warnOnce(`slots:${KO}`, `${KO} needs ${bK.length} vertex buffers`), null;
        let vK = "";
        for (const DO of bK) {
          vK += `${DO.stride}${"instance"===DO.step?"i":"v"}`;
          for (const OO of DO.attributes) vK += `,${OO.shaderLocation}:${OO.offset}:${OO.format}`;
          vK += ";"
        }
        let CO = this.layouts.get(vK);
        CO || (CO = {
          key: vK,
          buffers: bK.map((OO => ({
            arrayStride: OO.stride,
            stepMode: OO.step,
            attributes: OO.attributes
          }))),
          instanceEnds: bK.map((OO => {
            let KO = -1;
            if ("instance" === OO.step)
              for (const pO of OO.attributes) KO = Math.max(KO, pO.offset + Ae(pO.format));
            return KO
          }))
        }, this.layouts.set(vK, CO));
        const hO = bK.map((OO => OO.base));
        return {
          program: pO,
          sources: lO,
          layout: CO,
          slotData: bK.map((OO => OO.data)),
          llO: hO,
          buffers: [],
          offsets: hO,
          ends: [],
          state: null,
          pipelineKey: "",
          pipeline: null,
          pipelineTarget: "",
          geometry: null,
          instanceLayout: null,
          draw: null,
          retained: null,
          gpuVersion: -1,
          fitInstances: 0
        }
      }
    }

    function de(OO, KO, pO, XO) {
      const bK = KO.program.program.attributes;
      for (let eO = 0; eO < bK.length; eO++) {
        if ((bK[eO].optional ? null : pO.vertexInput(OO, bK[eO].name, XO)) !== KO.sources[eO]) return !1
      }
      return !0
    }
    const Te = 64;
    class Ne {
      constructor(OO, KO, pO, XO) {
        this.device = OO, this.layout = KO, this.frameBuffer = pO, this.label = XO, this.data = new Float32Array(4096), this.buffer = void 0, this.bindGroup = void 0, this.buffer = this.createBuffer(), this.bindGroup = this.createBindGroup()
      }
      ensure(OO) {
        if (OO * Te <= this.data.length) return !1;
        let KO = 2 * this.data.length;
        for (; OO * Te > KO;) KO *= 2;
        const pO = new Float32Array(KO);
        return pO.set(this.data), this.data = pO, this.buffer.destroy(), this.buffer = this.createBuffer(), this.bindGroup = this.createBindGroup(), !0
      }
      write(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        const bK = this.data,
          eO = OO * Te;
        let lO = bK[eO + 16] !== pO;
        for (let vK = 0; vK < 16 && !lO; vK++) lO = bK[eO + vK] !== KO[XO + vK];
        if (lO) {
          for (let OO = 0; OO < 16; OO++) bK[eO + OO] = KO[XO + OO];
          bK[eO + 16] = pO
        }
        return lO
      }
      upload(OO, KO) {
        this.device.queue.writeBuffer(this.buffer, OO * JX, this.data, OO * Te, (KO - OO) * Te)
      }
      createBuffer() {
        return this.device.createBuffer({
          label: this.label,
          size: this.data.byteLength,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        })
      }
      createBindGroup() {
        return this.device.createBindGroup({
          label: this.label,
          layout: this.layout,
          entries: [{
            binding: 0,
            resource: {
              buffer: this.frameBuffer
            }
          }, {
            binding: 1,
            resource: {
              buffer: this.buffer,
              size: 80
            }
          }]
        })
      }
    }

    function Ie(OO) {
      return OO.gpu[uO.f.lite] ??= OO.materials.map(((KO, pO) => ({
        parts: OO,
        range: pO,
        owner: OO.owner
      })))
    }

    function yl(OO) {
      var KO, pO, XO;
      return null !== (KO = null !== (pO = null === (XO = OO.parts.materials[OO.range]) || void 0 === XO ? void 0 : XO.mirror) && void 0 !== pO ? pO : OO.owner.material) && void 0 !== KO ? KO : null
    }
    const gl = ["opaque", "alphaTest", "transparent", "text"];
    class ue {
      constructor() {
        this.selectedCount = 0, this.model = null, this.mirror = null, this.groups = new Map, this.batches = new WeakMap, this.rows = new Int32Array(0), this.frame = 0, this.warnOnce = (0, hK.d)("Lite: ")
      }
      attach(OO, KO) {
        this.model = OO, this.mirror = KO
      }
      get worlds() {
        return this.model.nodes.lK
      }
      get visibility() {
        return this.model.meshes.visibility
      }
      group(OO) {
        return this.groups.get(OO)
      }
      groupIds() {
        return this.groups.keys()
      }
      forEachSelected(OO) {
        for (const [KO, pO] of this.groups)
          for (const XO of gl)
            for (const bK of pO[XO].units) OO(bK.owner, "text" === XO ? "transparent" : XO, KO)
      }
      select(OO, KO) {
        this.frame++, this.selectedCount = 0;
        for (const vK of this.groups.values())
          for (const OO of gl) vK[OO].units.length = 0, vK[OO].rows.length = 0;
        const {
          model: pO,
          mirror: XO
        } = this;
        if (!pO || !XO || !OO) return;
        this.rows.length < pO.nodes.YO && (this.rows = new Int32Array(pO.nodes.YO));
        const bK = this.rows,
          eO = pO.meshes;
        for (let vK = 0; vK < eO.looseCount; vK++) {
          const OO = eO.loose[vK],
            pO = XO.nodes[OO];
          pO && !pO.isBlocked && pO.isEnabled() && !pO.ol.hasAZeroComponent && eO.selects(OO, KO.frustum) && (this.activate(pO, OO), this.selectedCount++)
        }
        const lO = eO.selectTextPlanes(KO.frustum, bK);
        for (let vK = 0; vK < lO; vK++) {
          const KO = bK[vK],
            eO = XO.nodes[KO],
            lO = pO.meshes.parts[KO];
          if (!eO.isVisible || !(eO.visibility > 0) || 0 === (eO.layerMask & OO.layerMask) || !lO) continue;
          const CO = this.groupOf(pO.meshes.layer[KO]).text;
          for (const OO of Ie(lO)) CO.units.push(OO), CO.rows.push(KO);
          this.selectedCount++
        }
      }
      instanceBatch(OO) {
        const KO = this.batchOf(OO);
        return KO.dispatched || (KO.dispatched = KO.renderSelf = !0, KO.row = this.rowOf(OO)), KO
      }
      rowOf(OO) {
        return OO.row
      }
      activate(OO, KO) {
        if (!OO.BKO) {
          const pO = OO;
          if (pO.RDO) {
            const OO = this.batchOf(pO);
            OO.dispatched = !0, OO.renderSelf = !0, OO.row = KO
          }
          return void this.dispatch(pO, KO, KO)
        }
        const pO = OO,
          XO = pO.SDO;
        if (XO._getWorldMatrixDeterminant() >= 0 !== pO._getWorldMatrixDeterminant() >= 0) return void this.warnOnce(`mirrored:${XO.name}`, `A mirrored InstancedMesh of ${XO.name} is not drawn yet`);
        const bK = this.batchOf(XO);
        bK.instances.push(pO), bK.rows.push(KO), bK.dispatched || (bK.dispatched = !0, this.dispatch(XO, KO, this.rowOf(XO)))
      }
      batchOf(OO) {
        let KO = this.batches.get(OO);
        return KO || (KO = {
          frame: 0,
          dispatched: !1,
          renderSelf: !1,
          row: -1,
          instances: [],
          rows: []
        }, this.batches.set(OO, KO)), KO.frame !== this.frame && (KO.frame = this.frame, KO.dispatched = !1, KO.renderSelf = !1, KO.instances.length = 0, KO.rows.length = 0), KO
      }
      dispatch(OO, KO, pO) {
        const {
          layer: XO,
          parts: bK
        } = this.model.meshes;
        if (!bK[KO]) return;
        const eO = this.groupOf(XO[KO]),
          lO = OO;
        for (const vK of Ie(bK[KO])) {
          const OO = yl(vK);
          if (!OO) continue;
          const KO = OO.needAlphaBlendingForMesh(lO) ? eO.transparent : OO.needAlphaTestingForMesh(lO) ? eO.alphaTest : eO.opaque;
          KO.units.push(vK), KO.rows.push(pO)
        }
      }
      groupOf(OO) {
        let KO = this.groups.get(OO);
        return KO || (KO = {
          opaque: {
            units: [],
            rows: []
          },
          alphaTest: {
            units: [],
            rows: []
          },
          transparent: {
            units: [],
            rows: []
          },
          text: {
            units: [],
            rows: []
          }
        }, this.groups.set(OO, KO)), KO
      }
    }
    class Ee {
      constructor() {
        this.JK = new Map, this.enabled = [], this.groups = new Map, this.Sp = [], this.warned = new Set, this.selected = 0, this.drawn = 0
      }
      add(OO) {
        if (this.JK.has(OO)) return;
        const KO = {
          mesh: OO,
          observer: OO.onEffectiveEnabledStateChangedObservable.add((OO => {
            this.WE(KO, OO)
          })),
          index: -1,
          steady: null
        };
        this.JK.set(OO, KO), this.WE(KO, OO.isEnabled())
      }
      remove(OO) {
        const KO = this.JK.get(OO);
        KO && (KO.observer.remove(!0), this.WE(KO, !1), this.JK.delete(OO))
      }
      base(OO) {
        return this.JK.get(OO)
      }
      drawStats() {
        return {
          drawn: this.drawn,
          selected: this.selected,
          JK: this.JK.size
        }
      }
      forEachSelected(OO) {
        for (const [KO, pO] of this.groups) {
          for (const XO of pO.opaque) OO(XO.owner, "opaque", KO);
          for (const XO of pO.transparent) OO(XO.owner, "transparent", KO)
        }
        for (const KO of this.Sp) OO(KO.mesh, "opaque", 0)
      }
      group(OO) {
        return this.groups.get(OO)
      }
      groupIds() {
        return this.groups.keys()
      }
      select(OO, KO) {
        this.drawn = 0, this.selected = 0, this.Sp.length = 0;
        for (const XO of this.groups.values()) XO.opaque.length = 0, XO.transparent.length = 0;
        if (!OO) return;
        const pO = this.enabled;
        for (let XO = 0; XO < pO.length; XO++) {
          const bK = pO[XO];
          if (bK.steady && KO(bK, OO)) {
            this.selected++, this.Sp.push(bK);
            continue
          }
          const eO = bK.mesh;
          if (eO.isBlocked || eO.ol.hasAZeroComponent) continue;
          if (!eO.isVisible || eO.visibility <= 0 || 0 === (eO.layerMask & OO.layerMask)) continue;
          if (eO.RDO) {
            this.warned.has(eO.name) || (this.warned.add(eO.name), console.warn(`Lite: thin instance base ${eO.name} has InstancedMeshes and is not drawn`));
            continue
          }
          const {
            parts: lO
          } = eO;
          if (!lO) continue;
          eO.computeWorldMatrix(), this.selected++;
          const vK = this.listsFor(eO.renderingGroupId);
          for (const OO of Ie(lO)) {
            const KO = yl(OO);
            KO && (KO.needAlphaBlendingForMesh(eO) ? vK.transparent.push(OO) : vK.opaque.push(OO))
          }
        }
      }
      WE(OO, KO) {
        if (KO === OO.index >= 0) return;
        OO.steady = null;
        const pO = this.enabled;
        if (KO) OO.index = pO.length, pO.push(OO);
        else {
          const KO = pO.pop();
          KO !== OO && (pO[OO.index] = KO, KO.index = OO.index), OO.index = -1
        }
      }
      listsFor(OO) {
        let KO = this.groups.get(OO);
        return KO || (KO = {
          opaque: [],
          transparent: []
        }, this.groups.set(OO, KO)), KO
      }
    }
    var jl = pO(37786);
    class Ye {
      constructor() {
        this.bundle = null, this.stale = !0, this.JK = new Set
      }
    }
    class we {
      constructor(OO, KO, pO) {
        this.device = OO, this.slots = KO, this.host = pO, this.records = new Map, this.freeSlots = [], this.slotCount = 0, this.slotsFrom = Number.POSITIVE_INFINITY, this.slotsTo = -1, this.args = new Uint32Array(320), this.argsBuffer = void 0, this.argsDirty = !1, this.main = new Ye, this.gpO = new Ye, this.rangedEpoch = -1, this.bundles = [], this.recordedTarget = "", this.recordedSceneGroup = null, this.binder = new nb, this.frame = 0, this.drawn = 0, this.direct = void 0, this.directThisFrame = !1, this.argsBuffer = this.createArgsBuffer(), this.direct = function(OO) {
          var KO, pO;
          let XO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null !== (KO = null === (pO = globalThis.navigator) || void 0 === pO ? void 0 : pO.userAgent) && void 0 !== KO ? KO : "";
          const bK = OO.adapterInfo;
          return "intel" === (null === bK || void 0 === bK ? void 0 : bK.vendor) && "gen-12lp" === bK.architecture && XO.includes("Windows")
        }(OO), (0, jl.F)(this.direct)
      }
      uL() {
        this.frame++, this.drawn = 0, this.directThisFrame = this.direct, (0, jl.F)(this.directThisFrame)
      }
      add(OO, KO, pO, XO) {
        let bK = this.records.get(OO);
        return bK || (bK = this.createRecord(OO), this.records.set(OO, bK)), bK.recorded && rl(bK, KO) || (this.bundleOf(bK).stale = !0), this.place(bK, KO, pO, XO), bK
      }
      bundleOf(OO) {
        return OO.gpO ? this.gpO : this.main
      }
      addAgain(OO, KO, pO, XO) {
        OO.recorded || (this.bundleOf(OO).stale = !0), this.place(OO, KO, pO, XO)
      }
      place(OO, KO, pO, XO) {
        OO.seen = this.frame, OO.gpO && null === OO.draw && (this.gpO.stale = !0), OO.draw = KO, this.drawn++, pO && this.slots.write(OO.slot, pO, XO) && (this.slotsFrom = Math.min(this.slotsFrom, OO.slot), this.slotsTo = Math.max(this.slotsTo, OO.slot));
        const bK = this.args,
          eO = 5 * OO.slot;
        bK[eO] === KO.count && bK[eO + 1] === KO.instances && bK[eO + 2] === KO.first || (bK[eO] = KO.count, bK[eO + 1] = KO.instances, bK[eO + 2] = KO.first, this.argsDirty = !0, this.gpO.stale ||= OO.gpO)
      }
      EL() {
        for (const OO of this.records.values()) OO.seen !== this.frame && (OO.draw && (OO.draw = null, this.args[5 * OO.slot + 1] = 0, this.argsDirty = !0, this.gpO.stale ||= OO.gpO), this.frame - OO.seen > 120 && (this.records.delete(OO.unit), this.freeSlots.push(OO.slot), OO.recorded && (this.bundleOf(OO).stale = !0)));
        this.argsDirty && !this.directThisFrame && (this.device.queue.writeBuffer(this.argsBuffer, 0, this.args, 0, 5 * this.slotCount), this.argsDirty = !1), this.slotsTo >= 0 && (this.slots.upload(this.slotsFrom, this.slotsTo + 1), this.slotsFrom = Number.POSITIVE_INFINITY, this.slotsTo = -1)
      }
      forEachDrawn(OO) {
        for (const KO of this.records.values()) KO.draw && KO.seen === this.frame && !KO.gpO && OO(KO.draw, this.slots.data, KO.slot * JX / 4)
      }
      resourceDestroyed(OO) {
        this.main.stale ||= this.main.JK.has(OO), this.gpO.stale ||= this.gpO.JK.has(OO)
      }
      execute(OO, KO, pO) {
        if (0 === this.drawn) return 0;
        if (this.directThisFrame) return this.encode(OO, KO, pO, "direct"), this.drawn;
        const XO = this.host.sceneGroup(KO);
        if (!XO) return this.main.bundle = null, this.gpO.bundle = null, this.recordedSceneGroup = null, this.encode(OO, KO, pO, "direct"), this.drawn;
        this.recordedTarget === pO && this.recordedSceneGroup === XO || (this.recordedTarget = pO, this.recordedSceneGroup = XO, this.main.stale = !0, this.gpO.stale = !0);
        const bK = this.main,
          eO = this.gpO;
        let lO = !1;
        !bK.stale && bK.bundle || (bK.bundle = this.record(KO, pO, XO, "indirect"), lO = !0);
        const vK = (0, jl.i)();
        return (eO.stale || this.rangedEpoch !== vK) && (this.rangedEpoch = vK, eO.bundle = this.drawsRanged() ? this.record(KO, pO, XO, "gpO") : this.noRangedBundle(), lO = !0), lO && (this.bundles = eO.bundle ? [bK.bundle, eO.bundle] : [bK.bundle]), OO.executeBundles(this.bundles), OO.setBindGroup(0, XO), this.drawn
      }
      record(OO, KO, pO, XO) {
        const bK = this.device.createRenderBundleEncoder({
          label: "gpO" === XO ? "thin-bases-ranged" : "thin-bases",
          colorFormats: OO._colorFormat ? [OO._colorFormat] : [],
          depthStencilFormat: OO._depthStencilFormat,
          sampleCount: OO._sampleCount
        });
        return bK.setBindGroup(0, pO), this.encode(bK, OO, KO, XO), bK.finish()
      }
      noRangedBundle() {
        for (const OO of this.records.values()) OO.gpO && (OO.recorded = !1);
        return this.gpO.JK.clear(), this.gpO.stale = !1, null
      }
      drawsRanged() {
        for (const OO of this.records.values())
          if (OO.gpO && OO.draw) return !0;
        return !1
      }
      encode(OO, KO, pO, XO) {
        const bK = [];
        for (const CO of this.records.values()) "direct" !== XO && CO.gpO !== ("gpO" === XO) || (CO.recorded = !1, CO.draw && bK.push(CO));
        bK.sort(Pe);
        const eO = "direct" === XO ? null : "gpO" === XO ? this.gpO : this.main;
        null === eO || void 0 === eO || eO.JK.clear(), this.binder.reset();
        let lO = !1;
        for (const CO of bK) {
          var vK;
          const bK = CO.draw,
            hO = this.host.pipelineFor(bK, KO, pO);
          if (!hO) {
            this.host.pipelineCompiling(bK, pO) ? lO = !0 : eO && this.keep(CO, bK, eO.JK);
            continue
          }
          let DO;
          if (CO.gpO && "indirect" !== XO) {
            const OO = CO.unit.owner;
            DO = "direct" === XO && (0, jl.s)(OO) || (0, jl.m)(OO) || void 0
          }
          if (eO && this.keep(CO, bK, eO.JK), 0 === (null === (vK = DO) || void 0 === vK ? void 0 : vK.count)) continue;
          this.binder.bind(OO, bK, hO, this.slots.bindGroup, CO.slot * JX);
          const MO = 5 * CO.slot;
          if ("indirect" === XO) {
            bK.indexBuffer ? OO.drawIndexedIndirect(this.argsBuffer, 4 * MO) : OO.drawIndirect(this.argsBuffer, 4 * MO);
            continue
          }
          const aK = this.args;
          DO ? il(OO, null !== bK.indexBuffer, aK, MO, DO) : bK.indexBuffer ? OO.drawIndexed(aK[MO], aK[MO + 1], aK[MO + 2], 0, 0) : OO.draw(aK[MO], aK[MO + 1], aK[MO + 2], 0)
        }
        eO && (eO.stale = lO)
      }
      keep(OO, KO, pO) {
        OO.recorded = !0, OO.pipelineKey = KO.pipelineKey, OO.materialGroup = KO.material.bindGroup, OO.vertexBuffers.length = 0, OO.vertexBuffers.push(...KO.vertexBuffers), OO.vertexOffsets = KO.vertexOffsets, OO.indexBuffer = KO.indexBuffer, OO.indexFormat = KO.indexFormat;
        for (const XO of KO.vertexBuffers) pO.add(XO);
        KO.indexBuffer && pO.add(KO.indexBuffer), pO.add(KO.material.buffer);
        for (const XO of KO.material.bound) XO && pO.add(XO)
      }
      createRecord(OO) {
        let KO = this.freeSlots.pop();
        return void 0 === KO && (KO = this.slotCount++, this.grow()), {
          unit: OO,
          slot: KO,
          gpO: void 0 !== (0, jl.m)(OO.owner),
          seen: -1,
          draw: null,
          recorded: !1,
          pipelineKey: "",
          materialGroup: null,
          vertexBuffers: [],
          vertexOffsets: [],
          indexBuffer: null,
          indexFormat: "uint16"
        }
      }
      grow() {
        if (this.slots.ensure(this.slotCount) && (this.slotsFrom = 0, this.slotsTo = this.slotCount - 1, this.main.stale = !0, this.gpO.stale = !0), 5 * this.slotCount > this.args.length) {
          const OO = new Uint32Array(2 * this.args.length);
          OO.set(this.args), this.args = OO, this.argsBuffer.destroy(), this.argsBuffer = this.createArgsBuffer(), this.argsDirty = !0, this.main.stale = !0
        }
      }
      createArgsBuffer() {
        return this.device.createBuffer({
          label: "thin-bases-args",
          size: this.args.byteLength,
          usage: GPUBufferUsage.INDIRECT | GPUBufferUsage.COPY_DST
        })
      }
    }

    function il(OO, KO, pO, XO, bK) {
      const eO = pO[XO + 1],
        lO = bK.data;
      for (let vK = 0; vK < bK.count; vK++) {
        const bK = Math.min(lO[2 * vK], eO),
          CO = Math.min(lO[2 * vK + 1], eO - bK);
        0 !== CO && (KO ? OO.drawIndexed(pO[XO], CO, pO[XO + 2], 0, bK) : OO.draw(pO[XO], CO, pO[XO + 2], bK))
      }
    }

    function rl(OO, KO) {
      if (OO.pipelineKey !== KO.pipelineKey || OO.materialGroup !== KO.material.bindGroup || OO.indexBuffer !== KO.indexBuffer || OO.indexFormat !== KO.indexFormat || OO.vertexOffsets !== KO.vertexOffsets || OO.vertexBuffers.length !== KO.vertexBuffers.length) return !1;
      for (let pO = 0; pO < OO.vertexBuffers.length; pO++)
        if (OO.vertexBuffers[pO] !== KO.vertexBuffers[pO]) return !1;
      return !0
    }

    function Pe(OO, KO) {
      return te(OO.draw, KO.draw)
    }
    const ml = new WeakMap,
      se = {
        depth: !1,
        sunShadow: !1
      };

    function He(OO, KO) {
      let pO = ml.get(OO);
      pO || (pO = new Map, ml.set(OO, pO));
      const XO = `${KO.depth?"-depth":""}${KO.sunShadow?"-shadow":""}${KO.shadowMask?"-mask":""}`;
      let bK = pO.get(XO);
      if (!bK) {
        const eO = [{
          binding: gp.b,
          visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT,
          buffer: {
            type: "uniform",
            minBindingSize: gp.g
          }
        }, {
          binding: gp.x,
          visibility: GPUShaderStage.VERTEX,
          buffer: {
            type: "read-only-storage"
          }
        }];
        KO.depth && eO.push({
          binding: gp.o,
          visibility: GPUShaderStage.FRAGMENT,
          texture: {
            sampleType: "unfilterable-float"
          }
        }), KO.sunShadow && eO.push(... function() {
          const OO = GPUShaderStage.FRAGMENT,
            KO = gp.s;
          return [{
            binding: KO.uniform,
            visibility: OO,
            buffer: {
              type: "uniform"
            }
          }, {
            binding: KO.PK,
            visibility: OO,
            buffer: {
              type: "read-only-storage"
            }
          }, {
            binding: KO.special,
            visibility: OO,
            buffer: {
              type: "read-only-storage"
            }
          }, {
            binding: KO.volume,
            visibility: OO,
            texture: {
              sampleType: "float",
              viewDimension: "3d"
            }
          }, {
            binding: KO.sampler,
            visibility: OO,
            sampler: {
              type: "filtering"
            }
          }, {
            binding: KO.entities,
            visibility: OO,
            buffer: {
              type: "read-only-storage"
            }
          }, {
            binding: KO.entityGrids,
            visibility: OO,
            buffer: {
              type: "read-only-storage"
            }
          }]
        }()), KO.shadowMask && eO.push({
          binding: gp.u,
          visibility: GPUShaderStage.FRAGMENT,
          texture: {
            sampleType: "unfilterable-float"
          }
        }), bK = OO.createBindGroupLayout({
          label: `${KO.depth?"terrain-":""}shader-pack-inputs${XO}`,
          entries: eO
        }), pO.set(XO, bK)
      }
      return bK
    }

    function Re(OO) {
      return He(OO, se)
    }

    function Se(OO, KO) {
      if (!KO) return !1;
      const pO = (0, uK.e)(OO);
      return !!pO && mX(pO, KO)
    }

    function Je(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
        XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      if (!hX(KO)) return [];
      return [He(OO, {
        depth: bb(KO.packVariant),
        sunShadow: Se(KO.packVariant, pO),
        shadowMask: XO
      })]
    }
    class cl {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        this.device = OO, this.sunShadow = pO, this.bindGroup = void 0, this.buffer = void 0, this.textures = void 0, this.data = new ArrayBuffer(gp.g), this.groups = new Map, this.depthView = null, this.maskView = null, this.buffer = OO.createBuffer({
          label: "shader-pack-inputs",
          size: gp.g,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        });
        const XO = (0, gp.B)(KO);
        this.textures = OO.createBuffer({
          label: "shader-pack-textures",
          size: XO.byteLength,
          usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST
        }), OO.queue.writeBuffer(this.textures, 0, XO), this.bindGroup = OO.createBindGroup({
          label: "shader-pack-inputs",
          layout: Re(OO),
          entries: this.entries()
        })
      }
      entries() {
        return [{
          binding: gp.b,
          resource: {
            buffer: this.buffer
          }
        }, {
          binding: gp.x,
          resource: {
            buffer: this.textures
          }
        }]
      }
      write(OO, KO, pO) {
        (0, gp.H)(this.data, {
          seconds: OO.seconds(),
          lit: pO,
          renderOffset: OO.renderOffset(),
          xvO: OO.xvO(),
          eyePosition: KO,
          shadowDirection: OO.shadowDirection()
        }), this.device.queue.writeBuffer(this.buffer, 0, this.data)
      }
      bindGroupFor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        const XO = KO ? this.sunShadow : null;
        if ((KO || pO) && !XO) throw new Error("A shader pack program binds sun shadows on a page without them");
        if (!OO && !XO) return this.bindGroup;
        (OO && OO !== this.depthView || pO && pO !== this.maskView) && (this.depthView = null !== OO && void 0 !== OO ? OO : this.depthView, this.maskView = null !== pO && void 0 !== pO ? pO : this.maskView, this.groups.clear());
        const bK = (OO ? 1 : 0) | (XO ? 2 : 0) | (pO ? 4 : 0);
        let eO = this.groups.get(bK);
        if (!eO) {
          const KO = this.entries();
          OO && KO.push({
            binding: gp.o,
            resource: OO
          }), XO && KO.push(...XO.entries()), pO && KO.push({
            binding: gp.u,
            resource: pO
          }), eO = this.device.createBindGroup({
            label: `${OO||pO?"terrain-":""}shader-pack-inputs${OO?"-depth":""}${XO?"-shadow":""}${pO?"-mask":""}`,
            layout: He(this.device, {
              depth: !!OO,
              sunShadow: !!XO,
              shadowMask: !!pO
            }),
            entries: KO
          }), this.groups.set(bK, eO)
        }
        return eO
      }
      bind(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        OO.setBindGroup(gp.d, this.bindGroupFor(KO, pO, XO))
      }
    }

    function Be(OO, KO, pO) {
      if (OO.gpuVersion === KO.gpuBuffersVersion) return !0;
      let XO;
      do {
        if (XO = KO.gpuBuffersVersion, !Ze(OO, KO, pO)) return !1
      } while (KO.gpuBuffersVersion !== XO);
      return OO.gpuVersion = XO, OO.fitInstances = 0, !0
    }

    function Ze(OO, KO, pO) {
      let XO = null;
      for (let eO = 0; eO < OO.slotData.length; eO++) {
        var bK;
        const lO = OO.slotData[eO],
          vK = lO ? KO.gpuBuffer(lO) : pO;
        if (!vK) return !1;
        lO && OO.layout.instanceEnds[eO] < 0 && KO.cover(lO, Number.POSITIVE_INFINITY), OO.buffers[eO] = vK;
        const CO = OO.llO[eO] + (lO ? KO.gpuOffset(lO) : 0);
        CO !== (null !== (bK = XO) && void 0 !== bK ? bK : OO.offsets)[eO] && (XO ??= OO.offsets.slice(), XO[eO] = CO), OO.ends[eO] = lO ? KO.gpuEnd(lO) : vK.size
      }
      return XO && (OO.offsets = XO), !0
    }

    function Ge(OO, KO, pO, XO) {
      if (KO <= OO.fitInstances) return null;
      const {
        layout: bK,
        ends: eO,
        offsets: lO,
        slotData: vK,
        llO: CO
      } = OO;
      let hO = !1;
      for (let DO = 0; DO < bK.buffers.length; DO++) {
        const OO = bK.instanceEnds[DO];
        if (OO < 0) continue;
        const XO = (KO - 1) * bK.buffers[DO].arrayStride + OO;
        if (eO[DO] - lO[DO] < XO) return {
          index: DO,
          needed: XO
        };
        const MO = vK[DO];
        MO && pO.cover(MO, CO[DO] + XO) && (hO = !0)
      }
      return hO && Be(OO, pO, XO), OO.fitInstances = KO, null
    }
    var ql = pO(36182),
      xl = pO(36219);
    const ne = "vertexOutputs.position=scene.viewProjection*worldPos;\n",
      We = "var baseAmbientColor: vec3f= vec3f(1.,1.,1.);\n",
      tl = "color=vec4f(color.rgb,color.a*mesh.visibility);\n",
      kl = `((vertexInputs.aPackedLightLevels >> 16u) | ${CK.d.placed}u)`,
      Ue = "u32(vertexInputs.aShaderPackItem.x)",
      Ol = `${CK.d.lifeform}u`;

    function Kl(OO) {
      return "item" === OO.kind ? "bloxdSpItemLocalPosition(positionUpdated, vertexInputs.aShaderPackItem)" : "positionUpdated"
    }
    const pl = "bloxdSpEnchant",
      Xl = "floor(finalWorld[3].xyz)";

    function bv(OO, KO, pO) {
      return "placed" === KO.kind && OO.reads[pO].includes("bloxdFragmentBlockPosition")
    }

    function el(OO, KO) {
      let [pO, XO] = OO;
      return pO === KO.point && XO === KO.code
    }

    function ll(OO, KO) {
      var pO, XO, bK;
      const eO = null === (pO = OO.find((OO => OO.texture))) || void 0 === pO ? void 0 : pO.texture,
        lO = null === (XO = OO.find((OO => OO.enchantTier))) || void 0 === XO ? void 0 : XO.enchantTier,
        vK = null === (bK = OO.find((OO => OO.overlay))) || void 0 === bK ? void 0 : bK.overlay,
        CO = vK ? KO.filter((OO => el(OO, vK))).length : 0;
      return vK && 1 === CO ? {
        texture: eO,
        overlay: vK,
        enchantTier: lO
      } : {
        texture: eO,
        enchantTier: lO
      }
    }

    function vv(OO) {
      if ("item" === OO.kind) {
        return {
          vertexFlags: `(${Ue} & 0xffffu)`,
          varying: "vPackItem",
          value: Ue,
          flags: "(fragmentInputs.vPackItem & 0xffffu)",
          enchantTier: "(fragmentInputs.vPackItem >> 16u)"
        }
      }
      return OO.defines.BLOXD_LIGHT_WORD ? {
        vertexFlags: kl,
        varying: "vPackFlags",
        value: kl,
        flags: "fragmentInputs.vPackFlags",
        enchantTier: "0u"
      } : null
    }

    function Cl(OO) {
      return "lifeform" === OO.kind ? Ol : "0u"
    }

    function hl(OO) {
      return !!OO.BLOXD_PLUGIN_ENCHANTMENT
    }

    function Dl(OO, KO) {
      const {
        enchantTier: pO
      } = KO;
      return pO && hl(KO.defines) && "lifeform" === KO.kind && Ll(OO, "enchantTier") ? pO : null
    }

    function Ml(OO, KO) {
      return hl(KO.defines) && Ll(OO, "enchantSpeed")
    }

    function av(OO) {
      const {
        overlay: KO,
        defines: pO
      } = OO;
      if (!KO || !pO.DIFFUSE) return null;
      const XO = pO.VERTEXCOLOR || pO.INSTANCESCOLOR && pO.INSTANCES;
      return `vec4f(${KO.colour}.rgb * uniforms.vDiffuseInfos.y${XO?" * fragmentInputs.vColor.rgb":""}, ${KO.colour}.a)`
    }
    const ol = "fragmentInputs.vPackTexture";

    function Fl(OO) {
      const {
        atlas: KO,
        defines: pO,
        texture: XO
      } = OO;
      if (KO || !pO.DIFFUSE) return null;
      if (XO) return {
        texture: "diffuseSampler",
        ...XO
      };
      const bK = {
        texture: "diffuseSampler",
        cells: null,
        layers: [],
        uv: `fragmentInputs.${1===pO.DIFFUSEDIRECTUV?"vMainUV1":2===pO.DIFFUSEDIRECTUV?"vMainUV2":"vDiffuseUV"}`
      };
      if ("box" !== OO.kind) return bK;
      if (!pO.BLOXD_PLUGIN_ANIMATED) return {
        ...bK,
        id: ol
      };
      const eO = TO.e.WGSL,
        lO = (0, TO.Cb)(eO, "uAnimStatesNum"),
        vK = (0, TO.hb)(eO, (0, ql.c)(eO), lO),
        CO = "fragmentInputs.vMainUV1";
      return {
        texture: "diffuseSampler",
        cells: `vec2f(1.0, ${lO})`,
        layers: [vK],
        uv: `vec2f(${CO}.x, ${CO}.y * ${lO} - ${vK})`,
        levelUv: CO,
        id: ol
      }
    }

    function Vl(OO, KO) {
      return "box" === KO.kind && !!OO.hooks.surface && null !== Fl(KO)
    }

    function Ll(OO, KO) {
      return OO.reads.fragment.includes(KO)
    }

    function Ql(OO) {
      return !!OO.BLOXD_LIGHTING && !OO.BLOXD_UNLIT
    }

    function zv(OO, KO, pO, XO) {
      const bK = OO.filter((OO => {
        let [pO, XO] = OO;
        return "CUSTOM_FRAGMENT_BEFORE_FOG" === pO && XO === KO
      }));
      if (1 !== bK.length) throw new Error(`A model program for shader packs has ${0===bK.length?"no":"more than one"} ${XO} code before fog (lite/modelShaderPack.ts)`);
      return OO.map((OO => OO === bK[0] ? [OO[0], pO] : OO))
    }

    function Al(OO, KO, pO, XO) {
      const {
        hooks: bK
      } = OO, {
        kind: eO,
        defines: lO
      } = KO, vK = [...pO];
      var CO;
      KO.atlas && bK.surface && vK.push(["CUSTOM_VERTEX_DEFINITIONS", "varying vPackTexture: u32;"], ["CUSTOM_VERTEX_MAIN_END", Bp("atlasIdxIn")]), "item" === eO && vK.push(["CUSTOM_VERTEX_DEFINITIONS", (0, TO.h)(TO.e.WGSL, "aShaderPackItem", "vec4")], ["CUSTOM_VERTEX_DEFINITIONS", "\nfn bloxdSpQuarterTurns(v: vec2f, quarters: u32) -> vec2f {\n    let c = select(select(0.0, -1.0, quarters == 2u), 1.0, quarters == 0u);\n    let s = select(select(0.0, -1.0, quarters == 3u), 1.0, quarters == 1u);\n    return vec2f(v.x * c - v.y * s, v.x * s + v.y * c);\n}\nfn bloxdSpItemLocalPosition(position: vec3f, item: vec4f) -> vec3f {\n    let p = position * item.y + vec3f(0.0, item.z, 0.0);\n    let turn = u32(item.w);\n    let yz = bloxdSpQuarterTurns(p.yz, turn >> 2u);\n    let zx = bloxdSpQuarterTurns(vec2f(yz.y, p.x), turn & 3u);\n    return vec3f(zx.y, yz.x, zx.x);\n}\n"]), Vl(OO, KO) && vK.push(["CUSTOM_VERTEX_DEFINITIONS", (0, TO.h)(TO.e.WGSL, "aShaderPackItem", "vec4")], ["CUSTOM_VERTEX_DEFINITIONS", "varying vPackTexture: u32;"], ["CUSTOM_VERTEX_MAIN_END", (CO = "vertexInputs.aShaderPackItem.x", `\tvertexOutputs.vPackTexture = select(0u, ${Jp}[min(u32(${CO}) - 1u, arrayLength(&${Jp}) - 1u)], ${CO} > 0.5);\n`)]);
      const hO = vv(KO);
      hO && (bK.surface || bK.light) && vK.push(["CUSTOM_VERTEX_DEFINITIONS", `varying ${hO.varying}: u32;`], ["CUSTOM_VERTEX_MAIN_END", `vertexOutputs.${hO.varying} = ${hO.value};`]);
      let DO = XO;
      if (bv(OO, KO, "fragment") && (vK.push(["CUSTOM_VERTEX_DEFINITIONS", "varying vPackCell: vec3i;"], ["CUSTOM_VERTEX_MAIN_END", `vertexOutputs.vPackCell = vec3i(${Xl});`]), DO = [...DO, ["CUSTOM_FRAGMENT_MAIN_BEGIN", "bloxdSpCell = vec3f(fragmentInputs.vPackCell);"]]), Ll(OO, "localPosition") && vK.push(["CUSTOM_VERTEX_DEFINITIONS", "varying vPackLocalPosition: vec3f;"], ["CUSTOM_VERTEX_MAIN_END", `vertexOutputs.vPackLocalPosition = ${Kl(KO)};`]), hl(lO) && bK.surface) {
        Ml(OO, KO) && vK.push(["CUSTOM_VERTEX_DEFINITIONS", "flat varying vPackEnchantSpeed: f32;"], ["CUSTOM_VERTEX_MAIN_END", "vertexOutputs.vPackEnchantSpeed = vertexInputs.aEnchantmentSpeed;"]);
        const pO = Dl(OO, KO);
        pO && vK.push(["CUSTOM_VERTEX_DEFINITIONS", "varying vPackEnchantTier: u32;"], ["CUSTOM_VERTEX_MAIN_END", `vertexOutputs.vPackEnchantTier = u32(${pO});`]);
        const XO = (0, TO.rb)(TO.e.WGSL, "color", "mix(color.xyz, bloxdSpSurface.enchantColour.rgb, bloxdSpSurface.enchantColour.a)");
        DO = [...zv(DO, (0, xl.l)(TO.e.WGSL), XO, "enchantment"), ["CUSTOM_FRAGMENT_DEFINITIONS", (0, xl.e)(pl)]]
      }
      const {
        overlay: MO
      } = KO;
      MO && av(KO) && bK.surface && (DO = DO.filter((OO => !el(OO, MO))));
      const aK = bK.light ? function(OO) {
        return "placed" === OO.kind ? {
          name: "terrain",
          engine: (0, NK.P)(TO.e.WGSL),
          pack: (0, NK.fb)(TO.e.WGSL)
        } : OO.defines.BLOXD_PLUGIN_ENTITY_LIGHT ? {
          name: "entity",
          engine: (0, NK.G)(TO.e.WGSL),
          pack: (0, NK.ab)(TO.e.WGSL)
        } : null
      }(KO) : null;
      if (aK && (DO = zv(DO, aK.engine, aK.pack, `${aK.name} light`), "placed" !== eO && Ql(lO))) {
        const OO = lO.BLOXD_UNIFORM_ENTITY_LIGHT ? (0, TO.Cb)(TO.e.WGSL, "uEntityLightLevels") : (0, TO.Lb)(TO.e.WGSL, "aLightLevels");
        vK.push(["CUSTOM_VERTEX_DEFINITIONS", `varying ${NK.c}: vec4f;`], ["CUSTOM_VERTEX_MAIN_END", (0, NK.cb)(TO.e.WGSL, OO)])
      }
      return {
        vertexCode: vK,
        fragmentCode: DO
      }
    }

    function fl(OO, KO, pO, XO) {
      return rX(OO, KO, pO, XO, "model")
    }
    const dl = "\t@builtin(position) position: vec4f,\n";

    function Tl(OO, KO) {
      const pO = /^(?:(?:diagnostic|enable|requires)\b[^;]*;\n)*/.exec(OO)[0];
      return `${pO}${KO}${OO.slice(pO.length)}`
    }

    function Nl(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      const {
        hooks: bK
      } = KO, eO = mX(KO, XO), {
        kind: lO,
        defines: vK
      } = pO, CO = function(OO, KO) {
        var pO, XO, bK;
        const {
          defines: eO
        } = KO, lO = vv(KO), vK = !!eO.FOG, CO = hl(eO), hO = null !== (pO = null === lO || void 0 === lO ? void 0 : lO.enchantTier) && void 0 !== pO ? pO : Dl(OO, KO) ? "fragmentInputs.vPackEnchantTier" : "0u", DO = "lifeform" === KO.kind && !eO.ALPHAFROMDIFFUSE;
        return {
          vertexFlags: null !== (XO = null === lO || void 0 === lO ? void 0 : lO.vertexFlags) && void 0 !== XO ? XO : Cl(KO),
          vertexLocalPosition: Kl(KO),
          flags: null !== (bK = null === lO || void 0 === lO ? void 0 : lO.flags) && void 0 !== bK ? bK : Cl(KO),
          normal: "normalW",
          alpha: DO ? "alpha * baseColor.a" : "alpha",
          alphaOut: DO ? "baseColor.a" : "alpha",
          lambert: "diffuseBase.r",
          diffuse: "diffuseColor",
          emissive: "emissiveColor",
          ambient: "uniforms.vAmbientColor",
          fogColour: vK ? "frame.vFogColor" : "vec3f(0.0)",
          fogAlpha: vK ? "1.0 - fog" : "0.0",
          enchantTier: hO,
          enchantColour: CO ? `${pl}(fragmentInputs.vEnchantRgbAndRotY, fragmentInputs.vPositionAndAnimTick, baseColor.rgb)` : "vec4f(0.0)",
          enchantSpeed: Ml(OO, KO) ? "fragmentInputs.vPackEnchantSpeed" : "0.0",
          localPosition: Ll(OO, "localPosition") ? "fragmentInputs.vPackLocalPosition" : "vec3f(0.0)",
          overlayColour: av(KO)
        }
      }(KO, pO), hO = OO.textures.filter((OO => /^textureAtlas\d+$/.test(OO.name))).length, DO = pO.atlas && hO > 0 ? {
        count: hO,
        layers: pO.atlas.layers,
        width: pO.atlas.width,
        sampler: "textureAtlas0Sampler",
        frame: OO.material.slots.has("uAnimDataPerTex") ? (KO, pO) => gb(KO, pO, function(OO) {
          const KO = OO.material.stridedArrays.includes("uAnimDataPerTex") ? ".el" : "";
          return {
            KK: "frame.animTick",
            stride: "uniforms.uAnimData.y",
            count: "uniforms.uAnimData.z",
            perTexture: OO => `uniforms.uAnimDataPerTex[${OO}]${KO}`
          }
        }(OO)) : null
      } : null, MO = "placed" === lO ? "var<private> bloxdSpCell: vec3f;\nfn bloxdFragmentBlockPosition(bloxdSpPosition: vec3f, bloxdSpNormal: vec3f) -> vec3i {\n\tlet bloxdSpBehind = bloxdSpPosition - bloxdSpNormal * (1.0 / 64.0);\n\tlet bloxdSpInside = all(abs(bloxdSpBehind - bloxdSpCell - 0.5) <= vec3f(0.5 + 1.0 / 256.0));\n\treturn select(vec3i(floor(bloxdSpBehind)), vec3i(bloxdSpCell), bloxdSpInside) + bloxdRenderOffset();\n}\n" : "fn bloxdFragmentBlockPosition(bloxdSpPosition: vec3f, bloxdSpNormal: vec3f) -> vec3i {\n\treturn vec3i(floor(bloxdSpPosition - bloxdSpNormal * (1.0 / 64.0))) + bloxdRenderOffset();\n}\n", aK = null !== DO && void 0 !== DO ? DO : Fl(pO), oO = function(OO, pO) {
        let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
        return `${(0,gp.E)()}${Hp(KO,pO)}${XO}${Gp(OO)}${Yp}${MO}${KO.code}`
      };
      let {
        vertex: FO,
        fragment: VO
      } = OO;
      const LO = xX(bK, CO);
      if (LO) {
        const OO = bv(KO, pO, "vertex") ? `\tbloxdSpCell = ${Xl};\n` : "";
        FO = fl(FO, ne, `${OO}${LO.slice(1)}${ne}`, "vertex")
      }
      const QO = `${Rp(KO,eO,function(OO,KO){return KO.TWOSIDEDLIGHTING?OO:`select(-(${OO}), ${OO}, fragmentInputs.frontFacing)`}(CO.normal,vK),CO.flags)}${np(bK,KO.strict,KO.program,aK,CO)}`;
      QO && (VO = fl(VO, We, `${QO.slice(1)}${We}`, "surface")), eO && KO.sunShadow && !vK.TWOSIDEDLIGHTING && (VO = fl(VO, dl, `${dl}\t@builtin(front_facing) frontFacing: bool,\n`, "front facing"));
      const zK = kX(bK);
      if (zK) {
        const OO = tX(bK, Ql(vK), !0, CO);
        VO = fl(VO, tl, `${OO}${zK.slice(1)}${tl}`, "light")
      }
      const AO = Vl(KO, pO) ? cX : "";
      return {
        ...OO,
        vertex: Tl(FO, oO(DO, !1, AO)),
        fragment: Tl(VO, oO(aK, eO))
      }
    }
    const Il = {
      name: "earthSky",
      uniqueId: -1
    };
    class yv {
      constructor(OO) {
        this.resources = OO, this.instances = new Map, this.vertexCode = [], this.fragmentCode = [], this.pluginUniforms = [], this.codeKey = "", this.codeVersion = -1
      }
      release() {
        for (const OO of this.instances.values()) OO.released = !0, this.resources.destroyBuffer(OO.buffer);
        this.instances.clear()
      }
    }

    function gv(OO) {
      return OO.failed && null !== OO.packGroup
    }
    class ul {
      constructor(OO, KO, pO) {
        this.device = OO, this.resources = KO, this.skyLastRenderable = void 0, this.opaqueRenderable = void 0, this.transparentRenderable = void 0, this.frontRenderable = void 0, this.XlO = new Ee, this.modelMeshes = new ue, this.thinBundle = void 0, this.binder = new nb, this.sceneLayout = void 0, this.frameLayout = void 0, this.frameUniforms = new Float32Array(108), this.frameBuffer = void 0, this.meshSlots = void 0, this.zeroBuffer = void 0, this.programs = new Map, this.earthSkyProgram = null, this.earthSkyUniforms = null, this.earthSkyFrom = null, this.drawDefines = void 0, this.modelUniforms = new Le((OO => this.modelSlot(OO).instances.values())), this.vertexLayouts = void 0, this.inputs = new WeakMap, this.unbuildable = new Set, this.linePrograms = new Map, this.materials = new WeakMap, this.pipelines = new Map, this.compiling = 0, this.warnOnce = (0, hK.d)("Lite: "), this.renderStates = new Me(this.warnOnce), this.nextProgramId = 0, this.frame = 0, this.packInputs = null, this.sunShadow = null, this.caster = {}, this.casterWorlds = new Float32Array(0), this.view = void 0, this.steadyPhase = 0, this.keepSteadyBase = (OO, KO) => this.keepSteady(OO, KO), this.lists = new Wb(this.modelMeshes, this.XlO, this, this.warnOnce), this.slotCount = 0, this.drawDefines = new vl(KO, this.warnOnce, ((OO, KO, pO) => this.programWithModel(OO, KO, pO)), gv), this.vertexLayouts = new fe(KO, OO.limits, this.warnOnce), this.sceneLayout = KK(OO), this.frameLayout = OO.createBindGroupLayout({
          label: "meshes-frame",
          entries: [{
            binding: 0,
            visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT,
            buffer: {
              type: "uniform"
            }
          }, {
            binding: 1,
            visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT,
            buffer: {
              type: "uniform",
              hasDynamicOffset: !0,
              minBindingSize: 80
            }
          }]
        }), this.frameBuffer = OO.createBuffer({
          label: "meshes-frame",
          size: this.frameUniforms.byteLength,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        }), this.meshSlots = new Ne(OO, this.frameLayout, this.frameBuffer, "meshes-per-draw"), this.zeroBuffer = OO.createBuffer({
          label: "meshes-zero-attribute",
          size: 16,
          usage: GPUBufferUsage.VERTEX
        }), this.thinBundle = new we(OO, new Ne(OO, this.frameLayout, this.frameBuffer, "thin-bases-slots"), {
          pipelineFor: (OO, KO, pO) => this.pipelineFor(OO, KO, pO),
          pipelineCompiling: (OO, KO) => !OO.program.failed && !1 !== this.pipelines.get(`${OO.pipelineKey}|${KO}`),
          sceneGroup: OO => {
            const KO = pO(OO);
            return KO || this.warnOnce("scene-group", "no render task draws to this target: thin bases are drawn without a bundle"), KO
          }
        }), KO.onDestroy = OO => {
          this.thinBundle.resourceDestroyed(OO)
        }, this.skyLastRenderable = this.renderable(1e3, !1, this.lists.skyDraws), this.opaqueRenderable = this.renderable(150, !1, this.lists.opaqueDraws, this.thinBundle), this.transparentRenderable = this.renderable(300, !0, this.lists.transparentDraws), this.frontRenderable = this.renderable(400, !0, this.lists.frontDraws)
      }
      renderable(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        const bK = {
          order: OO,
          isTransparent: KO,
          _direct: !KO,
          bind: (OO, KO) => this.createBinding(bK, KO, pO, XO)
        };
        return bK
      }
      get pipelinesCompiling() {
        return this.compiling
      }
      prepare(OO, KO, pO) {
        var XO;
        let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        this.frame++, this.view = KO, this.drawDefines.view = KO, this.thinBundle.uL(), this.writeFrameUniforms();
        const eO = null !== (XO = null === bK || void 0 === bK ? void 0 : bK.defineFor("model")) && void 0 !== XO ? XO : 0;
        this.drawDefines.modelPackVariant = eO, bK && 0 !== eO && (this.packInputs ??= new cl(this.device, bK.textureLayers(), this.sunShadow), this.packInputs.write(bK, KO.eye, bK.Xe())), this.lists.clear(), this.slotCount = 0;
        const lO = OO.activeCamera;
        this.XlO.select(lO, this.keepSteadyBase), this.modelMeshes.select(lO, KO), pO && this.pushEarthSky(pO), this.lists.collect(OO), this.thinBundle.EL(), this.uploadMeshSlots()
      }
      pushDraws(OO, KO, pO, XO, bK, eO) {
        let lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null;
        const vK = eO.length;
        for (let CO = 0; CO < pO; CO++) {
          const pO = KO[CO];
          let vK = this.retainedDraw(OO, pO, XO, bK);
          if (void 0 === vK && (vK = this.drawFor(OO, pO, XO, bK), this.retain(pO, vK)), vK) {
            const OO = pO.owner,
              KO = lO ? lO[CO] : -1;
            vK.slotOffset = KO < 0 ? this.writeMeshSlot(OO.getWorldMatrix().m, OO.visibility) : this.writeMeshSlot(this.modelMeshes.worlds, this.modelMeshes.visibility[KO], 16 * KO), eO.push(vK)
          }
        }
        return eO.length - vK
      }
      bundleDraws(OO, KO, pO) {
        let XO = 0;
        for (const bK of KO) {
          let KO = this.retainedDraw(OO, bK, pO, !1);
          const eO = void 0 !== KO;
          if (void 0 === KO && (KO = this.drawFor(OO, bK, pO, !1), this.retain(bK, KO)), KO) {
            const OO = bK.owner,
              pO = this.thinBundle.add(bK, KO, OO.getWorldMatrix().m, OO.visibility);
            eO && this.steadyFrom(bK, KO, pO), XO++
          }
        }
        return XO
      }
      steadyFrom(OO, KO, pO) {
        const XO = OO.owner,
          bK = this.XlO.base(XO),
          eO = XO.material,
          {
            drawState: lO,
            instance: vK
          } = KO.inputs.retained;
        if (!bK || !eO || 1 !== OO.parts.materials.length || yl(OO) !== eO) return;
        const CO = bK.steady ??= {
          unit: OO,
          material: eO,
          visibility: 1,
          draw: KO,
          record: pO,
          drawState: lO,
          instance: vK,
          bindGroup: null,
          gpuVersion: -1,
          fitInstances: 0,
          worldFlag: -1,
          handedFrame: -1,
          phase: this.steadyPhase++ % 8
        };
        CO.unit = OO, CO.material = eO, CO.visibility = XO.visibility, CO.draw = KO, CO.record = pO, CO.drawState = lO, CO.instance = vK, CO.bindGroup = vK.bindGroup, CO.gpuVersion = this.resources.gpuBuffersVersion, CO.fitInstances = KO.inputs.fitInstances, CO.worldFlag = XO.getWorldMatrix().updateFlag, CO.handedFrame = this.frame
      }
      keepSteady(OO, KO) {
        const pO = OO.steady;
        if (pO.handedFrame !== this.frame - 1 || (this.frame + pO.phase) % 8 === 0) return !1;
        const XO = OO.mesh,
          {
            unit: bK,
            draw: eO,
            instance: lO,
            drawState: vK
          } = pO,
          CO = XO.forcedInstanceCount || XO.hlO;
        if (!XO.isVisible || XO.RDO || XO.visibility !== pO.visibility || 0 === (XO.layerMask & KO.layerMask) || XO.material !== pO.material || 0 !== XO.renderingGroupId || XO.hasVertexAlpha || !this.drawDefines.definesHold(vK, bK, vK.instancing) || pO.gpuVersion !== this.resources.gpuBuffersVersion || !this.inputsStamped(eO.inputs, bK, vK.instancing, eO.program) || eO.program.failed || lO.released || CO <= 0 || CO > pO.fitInstances) return !1;
        if (lO.frame !== this.frame && this.bindMaterial(lO, this.modelUniforms.refreshModelUniforms(XO.JKO(), lO, lO.model, this.view)), !lO.bindable || lO.bindGroup !== pO.bindGroup) return !1;
        const hO = XO.computeWorldMatrix(),
          DO = hO.updateFlag !== pO.worldFlag;
        return pO.worldFlag = hO.updateFlag, eO.instances = CO, this.thinBundle.addAgain(pO.record, eO, DO ? hO.m : null, pO.visibility), pO.handedFrame = this.frame, this.XlO.drawn++, !0
      }
      retainedDraw(OO, KO, pO, XO) {
        const bK = this.inputs.get(KO),
          eO = null === bK || void 0 === bK ? void 0 : bK.retained;
        if (!bK || !eO) return;
        const {
          drawState: lO,
          program: vK,
          instance: CO,
          instancing: hO
        } = eO, DO = KO.owner;
        if (Ke(DO) !== hO) return;
        const MO = this.instanceCount(DO, hO);
        if (MO <= 0) return null;
        if (CO.released || vK.failed || lO.program !== vK || !this.drawDefines.programCurrent(lO, KO, hO, pO) || !this.inputsStamped(bK, KO, hO, vK) || DO.isUnIndexed !== eO.unIndexed || this.indexKey(KO) !== eO.indexData) return;
        if (eO.indexBuffer && eO.gpuVersion !== this.resources.gpuBuffersVersion) {
          const OO = this.resources.gpuBuffer(eO.indexData);
          if (!OO) return;
          eO.indexBuffer = OO, eO.gpuVersion = this.resources.gpuBuffersVersion
        }
        let aK = !1;
        if (CO.frame !== this.frame && (aK = this.modelUniforms.refreshModelUniforms(OO, CO, CO.model, this.view)), !this.bindMaterial(CO, aK) || !this.withGpuBuffers(bK) || !this.instanceBuffersFit(DO.name, bK, MO)) return null;
        const oO = this.makeDraw(vK, bK, this.renderStates.renderState(lO.model, DO, XO, bK.state), CO, MO);
        return this.setRange(oO, KO, eO.indexBuffer, eO.indexData), oO
      }
      retain(OO, KO) {
        const pO = this.drawDefines.drawStates.get(OO);
        if (!KO || !pO || pO.program !== KO.program) {
          const KO = this.inputs.get(OO);
          return void(KO && (KO.retained = null))
        }
        const XO = OO.owner,
          bK = pO.instancing,
          eO = this.indexKey(OO),
          lO = KO.inputs.retained;
        lO ? (lO.drawState = pO, lO.instancing = bK, lO.program = KO.program, lO.instance = KO.material, lO.indexData = eO, lO.unIndexed = XO.isUnIndexed, lO.indexBuffer = KO.indexBuffer, lO.gpuVersion = this.resources.gpuBuffersVersion) : KO.inputs.retained = {
          drawState: pO,
          instancing: bK,
          program: KO.program,
          instance: KO.material,
          indexData: eO,
          unIndexed: XO.isUnIndexed,
          indexBuffer: KO.indexBuffer,
          gpuVersion: this.resources.gpuBuffersVersion
        }
      }
      drawFor(OO, KO, pO, XO) {
        const bK = KO.owner,
          eO = yl(KO);
        if (!eO) return null;
        const lO = eO.getClassName();
        let vK = null;
        if (function(OO) {
            return "LinesMesh" === OO.getClassName()
          }(bK)) {
          if (! function(OO) {
              return "ShaderMaterial" === OO.getClassName() && "color" === OO.shaderPath
            }(eO)) return this.warnOnce(`lines:${lO}`, `A LinesMesh with a ${lO} is not drawn yet (${eO.name})`), null;
          vK = bK
        } else if ("StandardMaterial" !== lO && "LiteMaterial" !== lO) return this.warnOnce(`class:${lO}`, `${lO} is not drawn yet (${eO.name})`), null;
        const CO = Ke(bK),
          hO = this.instanceCount(bK, CO);
        if (hO <= 0) return null;
        const DO = vK ? this.lineProgramFor(bK, pO, CO) : this.drawDefines.programFor(OO, KO, eO, pO, CO);
        if (!DO || DO.failed) return null;
        const MO = vK ? null : this.drawDefines.drawStates.get(KO).model,
          aK = MO ? this.modelInstance(MO, DO) : this.materialInstance(bK, DO);
        let oO = !1;
        if (aK.frame !== this.frame && (vK ? zK(aK.ubo, vK) : oO = this.modelUniforms.refreshModelUniforms(OO, aK, aK.model, this.view)), !this.bindMaterial(aK, oO)) return null;
        const FO = this.meshInputs(KO, DO, CO);
        if (!FO || !this.instanceBuffersFit(bK.name, FO, hO)) return null;
        const VO = this.indexKey(KO);
        let LO = null;
        if (VO && !bK.isUnIndexed && (LO = this.resources.gpuBuffer(VO), !LO)) return null;
        const QO = this.renderStates.renderState(null !== MO && void 0 !== MO ? MO : eO, bK, XO, FO.state, vK ? "line-list" : "triangle-list"),
          AO = this.makeDraw(DO, FO, QO, aK, hO);
        return this.setRange(AO, KO, LO, VO), AO
      }
      indexKey(OO) {
        const KO = ee(OO);
        return KO ? this.resources.modelIndex(KO) : null
      }
      setRange(OO, KO, pO, XO) {
        pO && (OO.indexBuffer = pO, OO.indexFormat = this.resources.indexFormat(XO));
        const bK = 4 * KO.range + (pO ? 0 : 2);
        OO.unit = KO, OO.first = KO.parts.Xl[bK], OO.count = KO.parts.Xl[bK + 1]
      }
      makeDraw(OO, KO, pO, XO, bK) {
        KO.state !== pO && (KO.state = pO, KO.pipelineKey = `${OO.id}|${KO.layout.key}|${pO.key}`, KO.pipeline = null);
        const eO = KO.draw ??= {
          program: OO,
          inputs: KO,
          pipelineKey: "",
          layout: KO.layout,
          state: pO,
          material: XO,
          slotOffset: 0,
          vertexBuffers: KO.buffers,
          vertexOffsets: KO.offsets,
          indexBuffer: null,
          indexFormat: "uint16",
          first: 0,
          count: 0,
          instances: bK,
          unit: null
        };
        return eO.program = OO, eO.pipelineKey = KO.pipelineKey, eO.state = pO, eO.material = XO, eO.vertexOffsets = KO.offsets, eO.indexBuffer = null, eO.instances = bK, eO
      }
      instanceCount(OO, KO) {
        switch (KO) {
          case "thin":
            return OO.forcedInstanceCount || OO.hlO;
          case "instanced":
            return this.prepareInstances(OO);
          case "none":
            return 1
        }
      }
      prepareInstances(OO) {
        const KO = function(OO, KO) {
          const pO = KO._userInstancedBuffersStorage,
            XO = OO.batchUploads.get(KO);
          if (XO) {
            var bK;
            if (XO.layout === (null !== (bK = null === pO || void 0 === pO ? void 0 : pO.interleavedKinds) && void 0 !== bK ? bK : null)) return XO;
            XO.release()
          }
          return new GO(OO, KO, pO)
        }(this.resources, OO);
        return KO.frame !== this.frame && KO.pack(OO, this.modelMeshes.instanceBatch(OO), this.modelMeshes.worlds, this.frame), KO.count
      }
      programWithModel(OO, KO, pO) {
        const XO = this.modelSlot(OO),
          bK = Ce(XO, OO, pO),
          eO = this.drawDefines.modelPackKind(OO),
          lO = eO ? function(OO, KO, pO, XO) {
            const bK = (0, yK.w)(OO, NO.f.name),
              eO = [];
            for (const {
                feature: CO,
                state: hO,
                active: DO
              }
              of OO.features) {
              var lO, vK;
              const OO = DO ? null === (lO = (vK = (0, DK.g)(CO)).hX) || void 0 === lO ? void 0 : lO.call(vK, hO) : void 0;
              OO && eO.push(OO)
            }
            return {
              kind: KO,
              atlas: null !== bK && void 0 !== bK && bK.active ? (0, NO.c)(bK.state) : null,
              defines: pO,
              ...ll(eO, XO)
            }
          }(OO, eO, KO, XO.fragmentCode) : null;
        if (lO && function(OO) {
            const KO = OO.defines;
            return (null === OO.atlas || !!KO.DIFFUSE && 1 === KO.DIFFUSEDIRECTUV) && !!KO.NORMAL && !KO.REFLECTION && !KO.EMISSIVEASILLUMINATION && !KO.LINKEMISSIVEWITHDIFFUSE
          }(lO)) {
          const pO = this.modelPackProgram(OO, KO, `${bK}#${eO}#sp${this.drawDefines.modelPackVariant}`, XO, lO);
          if (pO && !pO.failed) return pO
        }
        const vK = this.programs.get(bK);
        if (vK || this.unbuildable.has(bK)) return null !== vK && void 0 !== vK ? vK : null;
        let CO;
        try {
          CO = Cb({
            defines: Xe(KO),
            vertexCode: XO.vertexCode,
            fragmentCode: XO.fragmentCode,
            pluginUniforms: XO.pluginUniforms
          })
        } catch (hO) {
          return this.unbuildable.add(bK), this.warnOnce(`build:${bK}`, `could not build a program for ${OO.name}: ${String(hO)}`), null
        }
        return this.createProgram(bK, CO, "standard")
      }
      modelPackProgram(OO, KO, pO, XO, bK) {
        const eO = this.programs.get(pO);
        if (eO || this.unbuildable.has(pO)) return null !== eO && void 0 !== eO ? eO : null;
        const lO = this.drawDefines.modelPackVariant;
        let vK;
        try {
          const OO = function(OO) {
              return (0, uK.b)(OO, "model")
            }(lO),
            pO = Al(OO, bK, XO.vertexCode, XO.fragmentCode);
          vK = Nl(Cb({
            defines: Xe(KO),
            ...pO,
            pluginUniforms: XO.pluginUniforms
          }), OO, bK, !!this.sunShadow)
        } catch (DO) {
          return this.unbuildable.add(pO), this.warnOnce(`build:${pO}`, `could not build a shader pack program for ${OO.name}, which draws without the pack: ${String(DO)}`), null
        }
        const CO = Se(lO, !!this.sunShadow),
          hO = {
            group: this.packInputs.bindGroupFor(null, CO),
            layout: He(this.device, {
              depth: !1,
              sunShadow: CO
            })
          };
        return this.createProgram(pO, vK, function(OO) {
          return `standard-sp${OO}`
        }(lO), hO)
      }
      lineProgramFor(OO, KO, pO) {
        const XO = QO(OO, pO, KO, this.view);
        let bK = this.linePrograms.get(XO);
        var eO;
        return bK || (bK = this.createProgram(`lines#${XO}`, (eO = function(OO) {
          const KO = new Map;
          for (let pO = 0; pO < hO.length; pO++) OO & 1 << pO && KO.set(hO[pO], !0);
          return KO
        }(XO), ae({
          defines: eO,
          vertex: Db,
          fragment: Mb,
          members: [],
          structName: "MaterialUniforms"
        })), "color"), this.linePrograms.set(XO, bK)), bK
      }
      createProgram(OO, KO, pO) {
        var XO;
        let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        const eO = this.nextProgramId++,
          lO = `${pO}-${eO}`,
          vK = GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT,
          CO = [{
            binding: 0,
            visibility: vK,
            buffer: {
              type: "uniform"
            }
          }];
        for (const MO of KO.textures) CO.push({
          binding: MO.binding,
          visibility: vK,
          texture: {
            viewDimension: MO.dimension
          }
        }), CO.push({
          binding: MO.samplerBinding,
          visibility: vK,
          sampler: {}
        });
        const hO = this.device.createBindGroupLayout({
            label: lO,
            entries: CO
          }),
          DO = {
            key: OO,
            id: eO,
            kind: pO,
            program: KO,
            vertex: this.device.createShaderModule({
              label: `${lO}-vertex`,
              code: KO.vertex
            }),
            fragment: this.device.createShaderModule({
              label: `${lO}-fragment`,
              code: KO.fragment
            }),
            materialLayout: hO,
            pipelineLayout: this.device.createPipelineLayout({
              label: lO,
              bindGroupLayouts: [this.sceneLayout, this.frameLayout, hO, ...bK ? [bK.layout] : []]
            }),
            packGroup: null !== (XO = null === bK || void 0 === bK ? void 0 : bK.group) && void 0 !== XO ? XO : null,
            failed: !1
          };
        return this.programs.set(OO, DO), DO
      }
      writeFrameUniforms() {
        const OO = this.frameUniforms;
        Ve(this.view, OO), this.device.queue.writeBuffer(this.frameBuffer, 0, OO)
      }
      materialInstance(OO, KO) {
        let pO = this.materials.get(OO);
        if (!pO) {
          const KO = new Map;
          this.materials.set(OO, KO), OO.cpO.addOnce((() => {
            for (const OO of KO.values()) OO.released = !0, this.resources.destroyBuffer(OO.buffer);
            this.materials.delete(OO)
          })), pO = KO
        }
        let XO = pO.get(KO.key);
        return XO || (XO = this.newMaterialInstance(OO, null, KO), pO.set(KO.key, XO)), XO
      }
      modelInstance(OO, KO) {
        const pO = this.modelSlot(OO);
        let XO = pO.instances.get(KO.key);
        return XO || (XO = this.newMaterialInstance(OO, OO, KO), pO.instances.set(KO.key, XO)), XO
      }
      modelSlot(OO) {
        let KO = OO.gpu[uO.f.lite];
        return KO || (KO = new yv(this.resources), OO.gpu[uO.f.lite] = KO), KO
      }
      newMaterialInstance(OO, KO, pO) {
        const XO = pO.program.material.floats,
          bK = new Float32Array(XO),
          eO = new Map;
        return {
          owner: OO,
          model: KO,
          program: pO,
          data: bK,
          uploaded: new Float32Array(XO).fill(Number.NaN),
          buffer: this.device.createBuffer({
            label: `${OO.name}-uniforms`,
            size: Math.max(16, 4 * XO),
            usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
          }),
          textures: eO,
          ubo: new Fe(pO.program.material.slots, bK, eO),
          bindGroup: null,
          bound: new Array(2 * pO.program.textures.length).fill(null),
          frame: -1,
          bindable: !1,
          released: !1,
          heldVersion: -1
        }
      }
      pushEarthSky(OO) {
        var KO;
        const pO = this.earthSkyProgram ??= this.createProgram("earthSky", {
            vertex: Qb + ze,
            fragment: Qb + Ab,
            attributes: [],
            material: Lb,
            textures: []
          }, "earthSky"),
          XO = this.earthSkyUniforms ??= this.newMaterialInstance(Il, null, pO);
        this.earthSkyFrom !== OO && (this.earthSkyFrom = OO, XO.data.fill(0)), ub(XO.ubo, OO, this.view);
        const bK = this.vertexInputs(pO, Il, "earthSky", pO, null);
        if (pO.failed || !bK || !this.bindMaterial(XO, !1)) return;
        const eO = null !== (KO = bK.state) && void 0 !== KO ? KO : this.renderStates.stateFor(0, !1, 0, "none", "cw", 0, 0, !0, "triangle-list"),
          lO = this.makeDraw(pO, bK, eO, XO, 1);
        lO.count = ob.length;
        const vK = Eb(OO, this.view);
        lO.slotOffset = this.writeMeshSlot(vK, 1), this.lists.skyDraws.push(lO)
      }
      uploadIfChanged(OO) {
        const {
          data: KO,
          uploaded: pO
        } = OO;
        for (let XO = 0; XO < KO.length; XO++)
          if (KO[XO] !== pO[XO]) return pO.set(KO), void this.device.queue.writeBuffer(OO.buffer, 0, KO)
      }
      bindMaterial(OO, KO) {
        return OO.frame !== this.frame && (OO.frame = this.frame, KO || this.uploadIfChanged(OO), OO.bindable = this.bindTextures(OO)), OO.bindable
      }
      bindTextures(OO) {
        const {
          program: KO,
          bound: pO
        } = OO, XO = KO.program.textures;
        let bK = !OO.bindGroup,
          eO = !0;
        for (let lO = 0; lO < XO.length; lO++) {
          const KO = OO.textures.get(XO[lO].name),
            vK = KO ? this.resources.boundTexture(KO) : null;
          vK ? pO[2 * lO] === vK.view && pO[2 * lO + 1] === vK.sampler || (pO[2 * lO] = vK.view, pO[2 * lO + 1] = vK.sampler, bK = !0) : (KO || OO.ubo.expected.has(XO[lO].name) || this.warnOnce(`texture:${OO.owner.name}:${XO[lO].name}`, `${OO.owner.name} has no ${XO[lO].name}`), eO = !1)
        }
        if (!eO) return bK && (OO.bindGroup = null), !1;
        if (bK) {
          const bK = [{
            binding: 0,
            resource: {
              buffer: OO.buffer
            }
          }];
          for (let OO = 0; OO < XO.length; OO++) bK.push({
            binding: XO[OO].binding,
            resource: pO[2 * OO]
          }), bK.push({
            binding: XO[OO].samplerBinding,
            resource: pO[2 * OO + 1]
          });
          OO.bindGroup = this.device.createBindGroup({
            label: `${OO.owner.name}-material`,
            layout: KO.materialLayout,
            entries: bK
          })
        }
        return !0
      }
      writeMeshSlot(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        return this.meshSlots.ensure(this.slotCount + 1), this.meshSlots.write(this.slotCount, OO, KO, pO), this.slotCount++ * JX
      }
      uploadMeshSlots() {
        this.slotCount > 0 && this.meshSlots.upload(0, this.slotCount)
      }
      vertexInputs(OO, KO, pO, XO, bK) {
        let eO = this.inputs.get(OO);
        if (!eO || eO.program !== XO || !de(KO, eO, this.resources, bK)) {
          var lO;
          if (eO = null !== (lO = this.vertexLayouts.resolveInputs(KO, pO, XO, bK)) && void 0 !== lO ? lO : void 0, !eO) return null;
          this.inputs.set(OO, eO)
        }
        return this.withGpuBuffers(eO)
      }
      meshInputs(OO, KO, pO) {
        const XO = this.inputs.get(OO);
        if (XO && this.inputsStamped(XO, OO, pO, KO)) return this.withGpuBuffers(XO);
        const bK = OO.owner,
          eO = ee(OO),
          lO = this.vertexInputs(OO, bK, bK.name, KO, eO);
        return lO && (lO.geometry = le(OO), lO.instanceLayout = this.drawDefines.instanceLayout(bK, pO)), lO
      }
      inputsStamped(OO, KO, pO, XO) {
        return function(OO, KO, pO, XO) {
          return OO.program === pO && OO.geometry === le(KO) && OO.instanceLayout === XO
        }(OO, KO, XO, this.drawDefines.instanceLayout(KO.owner, pO))
      }
      withGpuBuffers(OO) {
        return Be(OO, this.resources, this.zeroBuffer) ? OO : null
      }
      instanceBuffersFit(OO, KO, pO) {
        const XO = Ge(KO, pO, this.resources, this.zeroBuffer);
        if (XO) {
          const bK = KO.ends[XO.index] - KO.offsets[XO.index] + KO.llO[XO.index];
          return this.warnOnce(`overrun:${OO}`, `${OO} draws ${pO} instances from a ${bK}-byte buffer (${XO.needed} needed)`), !1
        }
        return !0
      }
      createBinding(OO, KO, pO, XO) {
        const bK = `${KO._colorFormat}|${KO._depthStencilFormat}|${KO._depthCompare}|${KO._sampleCount}`,
          eO = lK(this.device, KO);
        if (OO === this.skyLastRenderable) {
          let pO = null;
          return {
            renderable: OO,
            pipeline: eO,
            draw: OO => pO ? this.drawSky(OO, KO, bK, pO) : 0,
            update: OO => {
              pO = OO
            }
          }
        }
        return {
          renderable: OO,
          pipeline: eO,
          draw: OO => (XO ? XO.execute(OO, KO, bK) : 0) + this.drawList(OO, KO, bK, pO)
        }
      }
      drawSky(OO, KO, pO, XO) {
        const bK = this.lists.skyDraws,
          eO = bK.length > 0;
        if (eO) {
          var lO;
          const pO = (null !== (lO = KO._depthCompare) && void 0 !== lO ? lO : pK).startsWith("greater") ? 0 : 1;
          OO.setViewport(0, 0, XO.targetWidth, XO.targetHeight, pO, pO)
        }
        const vK = this.drawList(OO, KO, pO, bK);
        return eO && OO.setViewport(0, 0, XO.targetWidth, XO.targetHeight, 0, 1), vK
      }
      drawList(OO, KO, pO, XO) {
        let bK = 0;
        const eO = this.binder;
        eO.reset();
        for (const lO of XO) {
          const XO = this.pipelineFor(lO, KO, pO);
          XO && (eO.bind(OO, lO, XO, this.meshSlots.bindGroup, lO.slotOffset), lO.indexBuffer ? OO.drawIndexed(lO.count, lO.instances, lO.first, 0, 0) : OO.draw(lO.count, lO.instances, lO.first, 0), bK++)
        }
        return bK
      }
      pipelineFor(OO, KO, pO) {
        var XO, bK;
        if (OO.program.failed) return null;
        const eO = OO.inputs;
        if (eO.pipeline && eO.pipelineTarget === pO) return eO.pipeline;
        const lO = `${OO.pipelineKey}|${pO}`,
          vK = this.pipelines.get(lO);
        if (void 0 !== vK) return vK && (eO.pipeline = vK, eO.pipelineTarget = pO), vK || null;
        this.pipelines.set(lO, null);
        const {
          program: CO,
          layout: hO,
          state: DO
        } = OO, MO = {
          label: `standard-${CO.id}`,
          layout: CO.pipelineLayout,
          vertex: {
            module: CO.vertex,
            entryPoint: "main",
            buffers: hO.buffers
          },
          fragment: tK({
            module: CO.fragment,
            entryPoint: "main"
          }, KO, DO.blend, DO.colourWrite),
          depthStencil: KO._depthStencilFormat ? {
            format: KO._depthStencilFormat,
            depthCompare: null !== (XO = null !== (bK = DO.depthCompare) && void 0 !== bK ? bK : KO._depthCompare) && void 0 !== XO ? XO : pK,
            depthWriteEnabled: DO.depthWrite,
            depthBias: DO.depthBias,
            depthBiasSlopeScale: DO.depthBiasSlopeScale
          } : void 0,
          multisample: {
            count: KO._sampleCount
          },
          primitive: {
            topology: DO.topology,
            frontFace: DO.frontFace,
            cullMode: DO.cullMode
          }
        };
        return this.compiling++, this.device.createRenderPipelineAsync(MO).then((OO => {
          this.compiling--, this.pipelines.set(lO, OO)
        }), (OO => {
          this.compiling--, this.reportFailure(CO, lO, OO)
        })), null
      }
      forEachSunShadowCaster(OO) {
        const KO = this.caster,
          pO = (pO, XO, bK) => {
            const eO = pO.unit && function(OO) {
              const KO = OO.material.model;
              return null !== KO && (KO.lifeform || KO.item) && KO.castsSunShadow && "triangle-list" === OO.state.topology
            }(pO) ? ee(pO.unit) : null;
            if (!eO) return;
            const lO = pO.unit.owner;
            switch (KO.geometry = eO, KO.skip = lO.noSunShadowVertices, KO.indexed = null !== pO.indexBuffer, KO.first = pO.first, KO.count = pO.count, KO.lK = XO, KO.worldAt = bK, KO.instances = null, KO.instanceCount = 1, KO.thin = !1, Ke(lO)) {
              case "thin": {
                const OO = lO._thinInstanceDataStorage.matrixData;
                if (!OO) return;
                KO.instances = OO, KO.instanceCount = Math.min(pO.instances, OO.length / 16), KO.thin = !0;
                break
              }
              case "instanced": {
                const OO = this.resources.batchUploads.get(lO);
                if (!OO || OO.frame !== this.frame || !this.writeBatchCasters(OO)) return;
                break
              }
            }
            OO(KO)
          };
        for (const XO of this.lists.opaqueDraws) pO(XO, this.meshSlots.data, XO.slotOffset / 4);
        this.thinBundle.forEachDrawn(pO)
      }
      writeBatchCasters(OO) {
        const {
          caster: KO
        } = this, pO = OO.packedMatrices, XO = OO.count;
        KO.instances = pO, KO.instanceCount = XO;
        let bK = -1;
        for (let eO = 0; eO < XO; eO++) {
          const KO = El(OO.packedRowMesh(eO));
          KO && bK < 0 ? (this.casterWorlds.length < 16 * XO && (this.casterWorlds = new Float32Array(pO.length)), this.casterWorlds.set(pO.subarray(0, 16 * eO)), bK = eO) : !KO && bK >= 0 && (this.casterWorlds.set(pO.subarray(16 * eO, 16 * eO + 16), 16 * bK), bK++)
        }
        return bK >= 0 && (KO.instances = this.casterWorlds, KO.instanceCount = bK), KO.instanceCount > 0
      }
      async reportFailure(OO, KO, pO) {
        const XO = [];
        let bK = !0;
        for (const [eO, lO] of [
            ["vertex", OO.vertex],
            ["fragment", OO.fragment]
          ]) {
          const OO = await lO.getCompilationInfo();
          for (const KO of OO.messages) bK &&= "error" !== KO.type, XO.push(`${eO}:${KO.lineNum}:${KO.linePos} ${KO.type}: ${KO.message}`)
        }
        if (bK && !OO.packGroup) return this.pipelines.set(KO, !1), console.error(`Lite: pipeline ${KO} failed`, pO), void xe("mesh", OO.kind, pO);
        OO.failed || (OO.failed = !0, console.error(`Lite: program ${OO.id} failed`, pO, XO.join("\n"), {
          program: OO.program,
          key: OO.key
        }), xe("mesh", OO.kind, pO, bK ? null : XO[0]))
      }
    }

    function El(OO) {
      var KO, pO;
      const XO = null === (KO = OO.lpO) || void 0 === KO || null === (pO = KO.aShaderPackItem) || void 0 === pO ? void 0 : pO.x;
      return void 0 !== XO && 0 !== (XO & CK.g)
    }
    var jv = pO(39714),
      Yl = pO(39719),
      wl = pO(39722),
      iv = pO(39676);
    const rv = [0, 3, 1, 4, 2, 5];

    function Pl(OO, KO, pO, XO, bK) {
      const eO = pO[0].width;
      try {
        return bK ? function(OO, KO, pO) {
          const XO = (0, iv.d)(OO, pO, pO, 6);
          for (let bK = 0; bK < 6; bK++)(0, iv.h)(OO, XO, bK, KO[rv[bK]], {
            invertY: !1
          });
          return XO.texture
        }(OO, pO, eO) : function(OO, KO, pO, XO) {
          const bK = OO.createTexture({
            label: "sink-cube",
            size: {
              width: pO,
              height: pO,
              depthOrArrayLayers: 6
            },
            format: XO,
            usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT
          });
          for (let eO = 0; eO < 6; eO++) OO.queue.copyExternalImageToTexture({
            source: KO[rv[eO]]
          }, {
            texture: bK,
            origin: {
              x: 0,
              y: 0,
              z: eO
            }
          }, {
            width: pO,
            height: pO
          });
          return bK
        }(KO, pO, eO, 1 === XO ? "r8unorm" : "rgba8unorm")
      } finally {
        mv(pO)
      }
    }

    function mv(OO) {
      for (const KO of null !== OO && void 0 !== OO ? OO : []) null === KO || void 0 === KO || KO.close()
    }
    async function sl(OO) {
      const KO = [],
        pO = [];
      if (await Promise.all(OO.map(((OO, XO) => (KO[XO] = null, OO.then((OO => {
          KO[XO] = OO
        }), (OO => {
          pO.push(OO)
        })))))), pO.length > 0) throw mv(KO), pO[0];
      return KO
    }
    class Hl {
      constructor(OO) {
        this.YO = OO, this.starts = [], this.lengths = [], this.used = 0, OO > 0 && (this.starts.push(0), this.lengths.push(OO))
      }
      allocate(OO) {
        const {
          starts: KO,
          lengths: pO
        } = this;
        for (let XO = 0; XO < KO.length; XO++) {
          if (pO[XO] < OO) continue;
          const bK = KO[XO];
          return pO[XO] === OO ? (KO.splice(XO, 1), pO.splice(XO, 1)) : (KO[XO] += OO, pO[XO] -= OO), this.used += OO, bK
        }
        return -1
      }
      free(OO, KO) {
        this.used -= KO;
        const pO = Math.min(OO + KO, this.YO);
        pO > OO && this.release(OO, pO - OO)
      }
      grow(OO) {
        const KO = this.YO;
        this.YO = OO, this.release(KO, OO - KO)
      }
      truncate(OO) {
        const {
          starts: KO,
          lengths: pO
        } = this;
        for (let XO = KO.length - 1; XO >= 0 && KO[XO] + pO[XO] > OO; XO--) KO[XO] >= OO ? (KO.splice(XO, 1), pO.splice(XO, 1)) : pO[XO] = OO - KO[XO];
        this.YO = OO
      }
      release(OO, KO) {
        const {
          starts: pO,
          lengths: XO
        } = this;
        let bK = 0,
          eO = pO.length;
        for (; bK < eO;) {
          const KO = bK + eO >> 1;
          pO[KO] < OO ? bK = KO + 1 : eO = KO
        }
        const lO = bK,
          vK = lO > 0 && pO[lO - 1] + XO[lO - 1] === OO,
          CO = lO < pO.length && OO + KO === pO[lO];
        vK && CO ? (XO[lO - 1] += KO + XO[lO], pO.splice(lO, 1), XO.splice(lO, 1)) : vK ? XO[lO - 1] += KO : CO ? (pO[lO] = OO, XO[lO] += KO) : (pO.splice(lO, 0, OO), XO.splice(lO, 0, KO))
      }
    }
    const Rl = 256;
    class Sl {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 16384,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1048576;
        this.device = OO, this.onReplaced = KO, this.mergeGap = pO, this.gpu = null, this.bytes = void 0, this.Xl = void 0, this.dirtyStarts = [], this.dirtyEnds = [], this.order = [], this.replaced = [], this.retired = [], this.freed = [], this.holding = !0;
        const bK = Math.max(Rl, Math.ceil(XO / Rl) * Rl);
        this.bytes = new Uint8Array(bK), this.Xl = new Hl(bK / Rl)
      }
      get buffer() {
        return this.gpu ??= this.createGpu(this.bytes.byteLength)
      }
      static slotBytes(OO) {
        return Math.max(1, Math.ceil(OO / Rl)) * Rl
      }
      allocate(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : OO;
        const XO = Sl.slotBytes(OO),
          bK = XO / Rl;
        let eO = this.Xl.allocate(bK);
        eO < 0 && (this.grow(this.Xl.YO + bK), eO = this.Xl.allocate(bK));
        const lO = eO * Rl;
        return this.growTo(lO + Math.max(pO, XO)), this.gpu ??= this.createGpu(this.bytes.byteLength), this.bytes.fill(0, lO, lO + XO), KO && this.bytes.set(new Uint8Array(KO.buffer, KO.byteOffset, Math.min(KO.byteLength, XO)), lO), this.markDirty(lO, lO + XO), lO
      }
      growTo(OO) {
        const KO = Math.ceil(OO / Rl);
        KO > this.Xl.YO && this.grow(KO)
      }
      free(OO, KO) {
        this.freed.push(OO, KO)
      }
      write(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        if (XO <= 0) return;
        this.bytes.set(new Uint8Array(KO.buffer, pO, XO), OO);
        let eO = OO + XO;
        if (bK) {
          const KO = OO + 4 * Math.ceil(XO / 4);
          this.bytes.fill(0, eO, KO), eO = KO
        }
        this.markDirty(OO, eO)
      }
      move(OO, KO, pO) {
        this.bytes.copyWithin(KO, OO, OO + pO), this.markDirty(KO, KO + pO)
      }
      flush() {
        for (const KO of this.retired) this.onReplaced(KO), KO.destroy();
        this.retired.length = 0;
        const OO = this.dirtyStarts.length;
        if (OO > 0) {
          const {
            dirtyStarts: KO,
            dirtyEnds: pO,
            order: XO
          } = this;
          XO.length = OO;
          for (let vK = 0; vK < OO; vK++) XO[vK] = vK;
          OO > 1 && XO.sort(((OO, pO) => KO[OO] - KO[pO]));
          const bK = this.mergeGap;
          let eO = KO[XO[0]],
            lO = pO[XO[0]];
          for (let vK = 1; vK < OO; vK++) {
            const OO = XO[vK];
            KO[OO] - lO <= bK ? lO = Math.max(lO, pO[OO]) : (this.send(eO, lO), eO = KO[OO], lO = pO[OO])
          }
          this.send(eO, lO), KO.length = 0, pO.length = 0
        }
        this.holding = !1
      }
      EL() {
        this.holding = !0, this.retired.push(...this.replaced), this.replaced.length = 0;
        const OO = this.freed;
        for (let KO = 0; KO < OO.length; KO += 2) this.Xl.free(OO[KO] / Rl, OO[KO + 1] / Rl);
        OO.length = 0
      }
      send(OO, KO) {
        this.device.queue.writeBuffer(this.gpu, OO, this.bytes.buffer, OO, KO - OO);
        for (const pO of this.replaced) {
          const XO = Math.min(KO, pO.size);
          XO > OO && this.device.queue.writeBuffer(pO, OO, this.bytes.buffer, OO, XO - OO)
        }
      }
      markDirty(OO, KO) {
        OO &= -4, KO = KO + 3 & -4, this.holding ? (this.dirtyStarts.push(OO), this.dirtyEnds.push(KO)) : this.send(OO, KO)
      }
      grow(OO) {
        const KO = this.Xl.YO,
          pO = Math.max(2 * KO, OO),
          XO = new Uint8Array(pO * Rl);
        XO.set(this.bytes);
        const bK = this.gpu;
        this.gpu = this.createGpu(XO.byteLength), this.bytes = XO, this.Xl.grow(pO), bK && (this.replaced.push(bK), this.onReplaced(bK)), this.dirtyStarts.length = 0, this.dirtyEnds.length = 0, this.markDirty(0, KO * Rl)
      }
      createGpu(OO) {
        return this.device.createBuffer({
          label: "sink-dynamic-arena",
          size: OO,
          usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
        })
      }
    }

    function Jl(OO) {
      return Array.isArray(OO) ? new Float32Array(OO) : OO
    }

    function cv(OO, KO, pO, XO, bK) {
      const eO = Yb(bK),
        lO = Math.min(bK, XO.byteLength);
      if (eO === lO && XO.byteOffset % 4 === 0) return void OO.queue.writeBuffer(KO, pO, XO.buffer, XO.byteOffset, eO);
      const vK = new Uint8Array(eO);
      vK.set(new Uint8Array(XO.buffer, XO.byteOffset, lO)), OO.queue.writeBuffer(KO, pO, vK)
    }

    function Bl(OO, KO, pO) {
      const XO = "linear",
        bK = "nearest";
      let eO = bK,
        lO = bK,
        vK = "nearest",
        CO = !KO;
      switch (OO) {
        case 11:
          eO = XO, lO = XO;
          break;
        case 3:
          eO = XO, lO = XO, vK = KO ? "linear" : "nearest";
          break;
        case 8:
          vK = KO ? "linear" : "nearest";
          break;
        case 4:
          break;
        case 5:
          lO = XO;
          break;
        case 6:
          lO = XO, vK = KO ? "linear" : "nearest";
          break;
        case 7:
          lO = XO, CO = !0;
          break;
        case 9:
          eO = XO;
          break;
        case 10:
          eO = XO, vK = KO ? "linear" : "nearest";
          break;
        case 2:
          eO = XO, lO = XO, pO > 1 ? (vK = "linear", CO = !1) : CO = !0;
          break;
        case 12:
          eO = XO, CO = !0;
          break;
        default:
          CO = !0
      }
      return pO > 1 && !CO ? {
        magFilter: XO,
        minFilter: XO,
        mipmapFilter: "linear",
        maxAnisotropy: pO
      } : {
        magFilter: eO,
        minFilter: lO,
        mipmapFilter: vK,
        ...CO ? {
          lodMinClamp: 0,
          lodMaxClamp: 0
        } : {}
      }
    }

    function Zl(OO) {
      return 0 === OO ? "clamp-to-edge" : 2 === OO ? "mirror-repeat" : "repeat"
    }
    class Gl {
      constructor(OO, KO) {
        let {
          vertexArena: pO = !0
        } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        this.engine = OO, this.device = KO, this.buffers = new WeakMap, this.HeO = new WeakMap, this.batchUploads = new WeakMap, this.textures = new Map, this.samplers = new Map, this.atlasBindings = new WeakMap, this.gpuBuffersVersion = 0, this.onDestroy = null, this.pending = 0, this.firstBindDecodes = 0, this.arena = void 0, this.arena = pO ? new Sl(KO, (OO => {
          var KO;
          null === (KO = this.onDestroy) || void 0 === KO || KO.call(this, OO), this.gpuBuffersVersion++
        })) : null
      }
      flushUploads() {
        var OO;
        null === (OO = this.arena) || void 0 === OO || OO.flush()
      }
      endUploadFrame() {
        var OO;
        null === (OO = this.arena) || void 0 === OO || OO.EL()
      }
      vertexBufferCreated(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : pO ? "sink-dynamic-vertices" : "sink-vertices";
        this.bufferDeleted(OO);
        const bK = Jl(KO);
        OO.YO = bK.byteLength, this.buffers.set(OO, {
          gpu: null,
          slot: -1,
          slotBytes: 0,
          size: 0,
          arena: pO && null !== this.arena,
          pending: bK,
          ownsPending: !1,
          usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC,
          label: XO
        })
      }
      vertexBufferUpdated(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        const bK = this.buffers.get(OO);
        if (!bK) return;
        const eO = Jl(KO),
          lO = void 0 === XO ? eO.byteLength : Math.min(XO, eO.byteLength);
        this.update(bK, eO, pO, lO)
      }
      vertexBufferFloatsUpdated(OO, KO, pO, XO) {
        const bK = this.buffers.get(OO);
        if (!bK) return;
        const eO = pO * Float32Array.BYTES_PER_ELEMENT,
          lO = (XO - pO) * Float32Array.BYTES_PER_ELEMENT;
        bK.slot >= 0 && lO > 0 && eO + lO <= bK.size ? this.writeSlot(bK, eO, KO, KO.byteOffset + eO, lO, !1) : bK.gpu && lO > 0 && eO + lO <= bK.gpu.size ? this.device.queue.writeBuffer(bK.gpu, eO, KO.buffer, KO.byteOffset + eO, lO) : this.update(bK, KO.subarray(pO, XO), eO, lO)
      }
      indexBufferCreated(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "sink-indices";
        this.bufferDeleted(OO);
        const XO = function(OO) {
          if (OO instanceof Uint16Array || OO instanceof Uint32Array) return OO;
          for (let KO = 0; KO < OO.length; KO++)
            if (OO[KO] >= 65535) return new Uint32Array(OO);
          return new Uint16Array(OO)
        }(KO);
        OO.is32Bits = 4 === XO.BYTES_PER_ELEMENT, OO.YO = XO.byteLength, this.buffers.set(OO, {
          gpu: null,
          slot: -1,
          slotBytes: 0,
          size: 0,
          arena: !1,
          pending: XO,
          ownsPending: XO !== KO,
          usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC,
          label: pO
        })
      }
      bufferDeleted(OO) {
        const KO = this.buffers.get(OO);
        null !== KO && void 0 !== KO && KO.gpu ? (this.destroyBuffer(KO.gpu), this.gpuBuffersVersion++) : KO && KO.slot >= 0 && (this.arena.free(KO.slot, KO.slotBytes), this.gpuBuffersVersion++), this.buffers.delete(OO)
      }
      update(OO, KO, pO, XO) {
        if (OO.slot >= 0) this.updateSlot(OO, KO, pO, XO);
        else if (OO.gpu) {
          if (pO + Yb(XO) > OO.gpu.size) {
            const KO = this.device.createBuffer({
                label: OO.label,
                size: Yb(Math.max(2 * OO.gpu.size, pO + XO)),
                usage: OO.usage | GPUBufferUsage.COPY_SRC
              }),
              bK = this.device.createCommandEncoder();
            bK.copyBufferToBuffer(OO.gpu, 0, KO, 0, OO.gpu.size), this.device.queue.submit([bK.finish()]), this.destroyBuffer(OO.gpu), this.gpuBuffersVersion++, OO.gpu = KO
          }
          cv(this.device, OO.gpu, pO, KO, XO)
        } else {
          const eO = new Uint8Array(KO.buffer, KO.byteOffset, XO),
            lO = OO.pending;
          if (lO && OO.ownsPending && pO + XO <= lO.byteLength) new Uint8Array(lO.buffer, lO.byteOffset, lO.byteLength).set(eO, pO);
          else if (lO && 0 === pO && XO === lO.byteLength && KO.byteLength === XO) OO.pending = KO, OO.ownsPending = !1;
          else {
            var bK;
            const KO = new Uint8Array(Math.max(null !== (bK = null === lO || void 0 === lO ? void 0 : lO.byteLength) && void 0 !== bK ? bK : 0, pO + XO));
            lO && KO.set(new Uint8Array(lO.buffer, lO.byteOffset, lO.byteLength)), KO.set(eO, pO), OO.pending = KO, OO.ownsPending = !0
          }
        }
      }
      updateSlot(OO, KO, pO, XO) {
        const bK = this.arena;
        pO + Yb(XO) > OO.size && (OO.size = Yb(Math.max(2 * OO.size, pO + XO)), bK.growTo(OO.slot + OO.size), this.gpuBuffersVersion++), 0 === XO ? this.writeSlot(OO, pO, xv, 0, 4, !1) : this.writeSlot(OO, pO, KO, KO.byteOffset, XO, !0)
      }
      writeSlot(OO, KO, pO, XO, bK, eO) {
        const lO = KO + (eO ? Yb(bK) : bK);
        lO > OO.slotBytes && this.moveSlot(OO, lO), this.arena.write(OO.slot + KO, pO, XO, bK, eO)
      }
      moveSlot(OO, KO) {
        const pO = this.arena,
          XO = Sl.slotBytes(Math.max(KO, Math.min(2 * OO.slotBytes, OO.size))),
          bK = pO.allocate(XO, null, OO.size);
        pO.move(OO.slot, bK, OO.slotBytes), pO.free(OO.slot, OO.slotBytes), OO.slot = bK, OO.slotBytes = XO, this.gpuBuffersVersion++
      }
      cover(OO, KO) {
        const pO = this.buffers.get(OO);
        if (!pO || pO.slot < 0) return !1;
        const XO = Math.min(KO, pO.size);
        return !(XO <= pO.slotBytes) && (this.moveSlot(pO, XO), !0)
      }
      destroyBuffer(OO) {
        var KO;
        null === (KO = this.onDestroy) || void 0 === KO || KO.call(this, OO), OO.destroy()
      }
      gpuBuffer(OO) {
        const KO = this.buffers.get(OO);
        if (!KO) return null;
        if (KO.slot >= 0) return this.arena.buffer;
        if (KO.arena && KO.pending) {
          const OO = KO.pending,
            pO = this.arena;
          return KO.size = Yb(OO.byteLength), KO.slotBytes = Sl.slotBytes(function(OO) {
            const KO = new Uint8Array(OO.buffer, OO.byteOffset, OO.byteLength);
            let pO = KO.length;
            if (OO.byteOffset % 4 === 0) {
              for (; pO % 4 !== 0 && 0 === KO[pO - 1];) pO--;
              if (pO % 4 === 0) {
                const KO = new Uint32Array(OO.buffer, OO.byteOffset, pO / 4);
                let XO = KO.length;
                for (; XO > 0 && 0 === KO[XO - 1];) XO--;
                pO = 4 * XO
              }
            }
            for (; pO > 0 && 0 === KO[pO - 1];) pO--;
            return pO
          }(OO)), KO.slot = pO.allocate(KO.slotBytes, OO, KO.size), KO.pending = null, pO.buffer
        }
        if (!KO.gpu && KO.pending) {
          const OO = KO.pending;
          KO.gpu = this.device.createBuffer({
            label: KO.label,
            size: Yb(OO.byteLength),
            usage: KO.usage
          }), cv(this.device, KO.gpu, 0, OO, OO.byteLength), KO.pending = null
        }
        return KO.gpu
      }
      gpuOffset(OO) {
        var KO, pO;
        const XO = null !== (KO = null === (pO = this.buffers.get(OO)) || void 0 === pO ? void 0 : pO.slot) && void 0 !== KO ? KO : -1;
        return XO < 0 ? 0 : XO
      }
      gpuEnd(OO) {
        var KO, pO;
        const XO = this.buffers.get(OO);
        return XO ? XO.slot >= 0 ? XO.slot + XO.size : null !== (KO = null === (pO = XO.gpu) || void 0 === pO ? void 0 : pO.size) && void 0 !== KO ? KO : 0 : 0
      }
      vertexInput(OO, KO, pO) {
        var XO, bK, eO, lO;
        return null !== (XO = null !== (bK = pO && this.modelInput(pO, KO)) && void 0 !== bK ? bK : null === (eO = null !== (lO = this.HeO.get(OO)) && void 0 !== lO ? lO : this.batchUploads.get(OO)) || void 0 === eO ? void 0 : eO.inputs[KO]) && void 0 !== XO ? XO : null
      }
      modelInput(OO, KO) {
        const pO = this.geometrySlot(OO);
        let XO = pO.inputs.get(KO);
        if (void 0 === XO) {
          const bK = OO.vertexAttributes.find((OO => OO.kind === KO));
          XO = bK ? new qK(this.modelKey(pO, bK.data, !1), bK.offset, bK.stride, bK.components, !1, bK.glType, bK.isNormalized) : null, pO.inputs.set(KO, XO)
        }
        return XO
      }
      modelIndex(OO) {
        return OO.indexData && this.modelKey(this.geometrySlot(OO), OO.indexData, !0)
      }
      geometrySlot(OO) {
        let KO = OO.gpu[uO.f.lite];
        if (!KO) {
          const pO = new Map,
            XO = () => {
              for (const OO of pO.values()) this.bufferDeleted(OO)
            },
            bK = OO => {
              const KO = pO.get(OO);
              KO && this.vertexBufferUpdated(KO, OO)
            };
          KO = {
            keys: pO,
            inputs: new Map,
            release: XO,
            updated: bK
          }, OO.gpu[uO.f.lite] = KO
        }
        return KO
      }
      modelKey(OO, KO, pO) {
        let XO = OO.keys.get(KO);
        if (!XO) {
          if (pO) {
            const OO = {
              YO: 0,
              is32Bits: !1
            };
            this.indexBufferCreated(OO, KO, "model-indices"), XO = OO
          } else XO = {
            YO: 0
          }, this.vertexBufferCreated(XO, KO, !1, "model-vertices");
          OO.keys.set(KO, XO)
        }
        return XO
      }
      indexFormat(OO) {
        return OO.is32Bits ? "uint32" : "uint16"
      }
      get texturesLoading() {
        return this.pending
      }
      releaseSlot(OO, KO) {
        --OO.refs > 0 || (this.releaseTexture(OO), mv(OO.images), null !== KO && this.textures.delete(KO))
      }
      load(OO, KO) {
        const pO = KO.decoded = async function(OO) {
          if ("cube" === OO.kind) return async function(OO) {
            if (6 !== OO.length) throw new Error(`${OO.length} files where six faces were expected`);
            const KO = await sl(OO.map((OO => sb(OO)))),
              pO = KO[0].width;
            return sl(KO.map((async OO => {
              if (OO.width === pO && OO.height === pO) return OO;
              try {
                return await createImageBitmap(OO, {
                  ...Pb,
                  resizeWidth: pO,
                  resizeHeight: pO
                })
              } finally {
                OO.close()
              }
            })))
          }(OO.files);
          if ("data" === OO.kind && OO.data) return [await createImageBitmap(new Blob([OO.data]), Pb)];
          return [await sb(qv(OO))]
        }(OO.source).then((OO => {
          0 === KO.refs ? mv(OO) : KO.images = OO
        }));
        this.track(KO, qv(OO.source), pO, (() => {
          KO.wanted && !KO.failed && KO.refs > 0 && this.upload(OO, KO)
        }))
      }
      canvasUpdated(OO, KO, pO) {
        const {
          state: XO
        } = this.textureSlot(OO);
        XO.dynamicSource = {
          invertY: KO,
          premultiplied: pO
        }, XO.dynamic && this.pushDynamic(OO.source, XO)
      }
      async atlasArray(OO, KO, pO) {
        const XO = await Sb(this.device, OO, KO, pO);
        if (!this.atlasBindings.has(XO)) {
          const OO = (0, jv.e)(this.engine, {
            magFilter: "nearest",
            minFilter: "nearest",
            mipmapFilter: "linear",
            addressModeU: "repeat",
            addressModeV: "repeat"
          });
          this.atlasBindings.set(XO, {
            view: XO.texture.createView({
              dimension: "2d-array"
            }),
            sampler: OO
          })
        }
        return XO
      }
      boundTexture(OO) {
        const KO = this.atlasBindings.get(OO);
        if (KO) return KO;
        const pO = OO;
        if (pO.released) return null;
        const XO = this.textureSlot(pO, !0),
          {
            state: bK
          } = XO;
        if (!bK.view && (bK.wanted = !0, bK.loading || bK.failed || this.upload(pO, bK), !bK.view)) return null;
        const eO = this.chosenSampler(pO, XO),
          lO = XO.bound;
        return lO && lO.view === bK.view && lO.sampler === eO ? lO : (XO.bound = {
          view: bK.view,
          sampler: eO
        }, XO.bound)
      }
      textureLoaded(OO) {
        var KO, pO;
        return null !== (KO = null === (pO = OO.gpu[uO.f.lite]) || void 0 === pO ? void 0 : pO.state.decoded) && void 0 !== KO ? KO : null
      }
      textureFailed(OO) {
        var KO;
        return !0 === (null === (KO = OO.gpu[uO.f.lite]) || void 0 === KO ? void 0 : KO.state.failed)
      }
      chosenSampler(OO, KO) {
        const {
          samplingMode: pO,
          wrapU: XO,
          wrapV: bK
        } = OO.sampler, eO = KO.state.hasMips, lO = function(OO, KO) {
          const {
            bilinear: pO,
            trilinear: XO
          } = uO.i;
          return !KO && OO !== pO || 11 !== OO && OO !== XO && OO !== pO ? 1 : 4
        }(pO, eO), vK = KO.sampler;
        if (vK && vK.samplingMode === pO && vK.hasMips === eO && vK.anisotropy === lO && vK.wrapU === XO && vK.wrapV === bK) return vK.sampler;
        const CO = this.samplerFor(pO, eO, lO, XO, bK);
        return KO.sampler = {
          samplingMode: pO,
          hasMips: eO,
          anisotropy: lO,
          wrapU: XO,
          wrapV: bK,
          sampler: CO
        }, CO
      }
      releaseTexture(OO) {
        var KO, pO;
        OO.view && (null === (pO = this.onDestroy) || void 0 === pO || pO.call(this, OO.view));
        null === (KO = OO.destroy) || void 0 === KO || KO.call(OO)
      }
      textureSlot(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = OO.gpu[uO.f.lite];
        if (pO) return pO;
        const XO = function(OO) {
          let {
            source: KO,
            sampler: pO
          } = OO;
          return "canvas" === KO.kind ? null : `${KO.kind}|${qv(KO)}|${pO.noMipmap}|${pO.samplingMode}|${pO.invertY}`
        }(OO);
        let bK = null === XO ? void 0 : this.textures.get(XO);
        bK || (bK = {
          refs: 0,
          view: null,
          destroy: null,
          loading: !1,
          decoded: null,
          failed: !1,
          wanted: !1,
          hasMips: !1,
          images: null,
          dynamic: null,
          dynamicSource: null
        }, null !== XO && (this.textures.set(XO, bK), this.load(OO, bK), KO && this.firstBindDecodes++)), bK.refs++;
        const eO = bK,
          lO = {
            state: bK,
            bound: null,
            sampler: null,
            release: () => {
              this.releaseSlot(eO, XO)
            }
          };
        return OO.gpu[uO.f.lite] = lO, lO
      }
      samplerFor(OO, KO, pO, XO, bK) {
        const eO = `${OO}|${KO}|${pO}|${XO}|${bK}`;
        let lO = this.samplers.get(eO);
        if (!lO) {
          const vK = {
            ...Bl(OO, KO, pO),
            addressModeU: Zl(XO),
            addressModeV: Zl(bK)
          };
          lO = (0, jv.e)(this.engine, vK), this.samplers.set(eO, lO)
        }
        return lO
      }
      upload(OO, KO) {
        const {
          source: pO,
          sampler: XO
        } = OO;
        KO.hasMips = !XO.noMipmap, "canvas" === pO.kind ? this.createDynamic(pO, KO) : "cube" === pO.kind ? this.uploadCube(KO, pO.luminance) : this.uploadImage(KO, !0 === XO.invertY, pO.url)
      }
      uploadImage(OO, KO, pO) {
        const [XO] = OO.images;
        OO.images = null;
        const bK = (0, Yl.b)(this.engine, XO, {
          mipMaps: OO.hasMips,
          invertY: KO,
          srgb: !1
        }).then((KO => {
          XO.close(), 0 !== OO.refs ? (OO.view = KO.view, OO.destroy = KO.texture.destroy.bind(KO.texture)) : KO.texture.destroy()
        }));
        this.track(OO, pO, bK)
      }
      track(OO, KO, pO, XO) {
        OO.loading = !0, this.pending++, pO.catch((pO => {
          OO.failed = !0, console.warn(`Lite: could not load texture ${me(KO)}`, pO)
        })).finally((() => {
          OO.loading = !1, this.pending--, null === XO || void 0 === XO || XO()
        }))
      }
      uploadCube(OO, KO) {
        const pO = OO.images;
        OO.images = null;
        const XO = Pl(this.engine, this.device, pO, (0, uO.y)(KO), OO.hasMips);
        OO.view = XO.createView({
          dimension: "cube"
        }), OO.destroy = () => {
          XO.destroy()
        }
      }
      createDynamic(OO, KO) {
        const {
          canvas: pO
        } = OO, XO = (0, wl.b)(this.engine, Math.max(1, pO.width), Math.max(1, pO.height), {
          mipMaps: KO.hasMips,
          srgb: !1
        });
        KO.dynamic = XO, KO.view = XO.view, KO.destroy = () => {
          XO.texture.destroy()
        }, this.pushDynamic(OO, KO)
      }
      pushDynamic(OO, KO) {
        const pO = KO.dynamicSource,
          XO = KO.dynamic,
          {
            canvas: bK
          } = OO;
        if (pO && XO && 0 !== bK.width && 0 !== bK.height) return bK.width !== XO.width || bK.height !== XO.height ? (this.releaseTexture(KO), KO.dynamic = null, KO.view = null, void this.createDynamic(OO, KO)) : void(0, wl.f)(this.engine, XO, bK, {
          invertY: pO.invertY,
          premultiplyAlpha: pO.premultiplied
        })
      }
    }

    function qv(OO) {
      return "cube" === OO.kind ? OO.rootUrl : "canvas" === OO.kind ? "canvas" : OO.url
    }
    const xv = new Uint8Array(4);

    function nl(OO) {
      const KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1] ? "store" : "discard";
      OO._colorAttachment.storeOp = OO._targetSignature._sampleCount > 1 ? KO : "store";
      const pO = OO._renderPassDescriptor.depthStencilAttachment;
      pO && (pO.depthStoreOp = KO, pO.stencilStoreOp && (pO.stencilStoreOp = KO))
    }
    var Wl = pO(36146),
      tv = pO(36185),
      kv = pO(35796),
      Ul = pO(37793);
    const Ov = new Float64Array([1, 1, 1]),
      Kv = new Float64Array([0, 1, 0]),
      pv = new Float64Array(4),
      Xv = new Float32Array(16),
      bC = new Float64Array(3),
      ev = new Float64Array(4);

    function lv(OO, KO, pO) {
      OO.fov = KO.fov, OO.near = KO.near, OO.far = KO.far, OO.renderWidth = pO.renderWidth, OO.renderHeight = pO.renderHeight, (0, kv.w)(KO.holderRotation, 0, pv, 0), (0, kv.d)(Ov, 0, pv, 0, KO.holderPosition, 0, Xv);
      const XO = KO.BbO;
      bC[0] = XO[0], bC[1] = XO[1], bC[2] = XO[2] + 1;
      const bK = OO.viewMatrix;
      (0, kv.n)(XO, bC, Kv, bK), (0, kv.j)(bK, 0, bK), (0, kv.o)(bK, Xv, 0, bK), (0, kv.j)(bK, 0, bK);
      const eO = OO.worldMatrix;
      (0, kv.j)(bK, 0, eO), OO.eye[0] = eO[12], OO.eye[1] = eO[13], OO.eye[2] = eO[14], ev[0] = OO.fov, ev[1] = OO.renderWidth / OO.renderHeight, ev[2] = OO.near, ev[3] = OO.far, (0, kv.s)(ev, OO.projectionMatrix), (0, kv.o)(bK, OO.projectionMatrix, 0, OO.viewProjectionMatrix), (0, Ul.f)(OO.viewProjectionMatrix, OO.frustum)
    }

    function vC(OO, KO) {
      let pO = OO.frustumPlanes;
      pO || (pO = OO.frustumPlanes = Array.from({
        length: 6
      }, (() => new Wl.d(0, 0, 0, 0))));
      for (let XO = 0; XO < 6; XO++) {
        const OO = pO[XO].normal;
        OO._x = KO[4 * XO], OO._y = KO[4 * XO + 1], OO._z = KO[4 * XO + 2], OO._isDirty = !0, pO[XO].d = KO[4 * XO + 3]
      }
    }

    function Cv(OO, KO) {
      const pO = KO.clearColor;
      OO.clearColour[0] = pO.r, OO.clearColour[1] = pO.g, OO.clearColour[2] = pO.b, OO.clearColour[3] = pO.a;
      const XO = KO.ambientColor;
      OO.ambientColour[0] = XO.r, OO.ambientColour[1] = XO.g, OO.ambientColour[2] = XO.b, OO.animationRatio = KO.animationRatio, OO.frameId = KO.frameId, OO.version++
    }

    function hv(OO) {
      const KO = OO.model.view;
      return KO.animTick = (0, tv.c)(), KO.timeMs = performance.now(), Cv(KO, OO.Ce), OO.model.update(KO.frameId), KO
    }

    function Dv(OO) {
      const KO = OO.Ce,
        {
          view: pO,
          ceO: XO
        } = OO.model;
      return lv(pO, XO, KO.qb()), KO.onBeforeRenderObservable.notifyObservers(KO), vC(KO, pO.frustum), KO.onBeforeCameraRenderObservable.notifyObservers(KO.activeCamera), hv(OO)
    }
    var Mv = pO(35770),
      aC = pO(35862),
      ov = pO(36178);

    function Fv(OO) {
      var KO, pO;
      const XO = (0, yK.cb)(OO);
      if (!XO || XO.diffuseTexture && (0, ov.f)(OO)) return null;
      const bK = null === (KO = (0, yK.w)(XO, NO.f.name)) || void 0 === KO ? void 0 : KO.state,
        eO = null === (pO = (0, yK.w)(XO, ql.b.name)) || void 0 === pO ? void 0 : pO.state,
        lO = new Float32Array(16);
      return function(OO, KO, pO, XO) {
        var bK, eO;
        const lO = ab;
        XO.set(OO.diffuseColor, lO.diffuse), XO[lO.diffuse + 3] = OO.alpha, XO.set(OO.ambientColor, lO.ambientAndCutoff), XO[lO.ambientAndCutoff + 3] = OO.alphaCutOff, XO.set(OO.emissiveColor, lO.emissiveAndLevel), XO[lO.emissiveAndLevel + 3] = null !== (bK = null === (eO = OO.diffuseTexture) || void 0 === eO ? void 0 : eO.level) && void 0 !== bK ? bK : 1, null !== KO && void 0 !== KO && KO.animDataPerTex ? (XO[lO.anim + 1] = tv.b, XO[lO.anim + 2] = KO.animDataPerTex.length / 3 - 1) : pO && (XO[lO.anim + 1] = pO.numAnimStates, XO[lO.anim + 2] = pO.ticksPerAnimState)
      }(XO, bK, eO, lO), {
        model: XO,
        atlas: bK,
        texture: bK ? "atlas" : XO.diffuseTexture ? "single" : "none",
        animated: bK ? !!bK.animDataPerTex : !!eO,
        liquid: (0, ov.j)(OO),
        customRenderMat: (0, ov.f)(OO),
        uniformData: lO
      }
    }
    var Vv = pO(35755);
    class Lv {
      constructor(OO) {
        this.units = OO, this.buffer = void 0, this.twin = null, this.bufferReady = !1, this.twinReady = !1
      }
      get ready() {
        return this.bufferReady && (!this.twin || this.twinReady)
      }
      destroy() {
        var OO;
        this.buffer.destroy(), null === (OO = this.twin) || void 0 === OO || OO.destroy()
      }
    }
    class Qv {
      constructor(OO, KO) {
        this.arena = OO, this.Xl = void 0, this.buffer = void 0, this.twin = null, this.usable = 0, this.backings = [], this.growable = !0, this.dropped = !1, this.Xl = new Hl(KO);
        const pO = new Lv(KO);
        pO.buffer = this.createBuffer(pO, !1), this.backings.push(pO), this.refresh()
      }
      get YO() {
        return this.Xl.YO
      }
      get canGrow() {
        return this.growable && !this.dropped
      }
      get live() {
        return !this.dropped
      }
      get hasTwin() {
        return null !== this.backings[this.backings.length - 1].twin
      }
      get allocatedBytes() {
        let OO = 0;
        for (const KO of this.backings) OO += KO.units * (this.arena.unitBytes + (KO.twin ? this.arena.twinUnitBytes : 0));
        return OO
      }
      holds(OO) {
        return OO.start + OO.length <= this.usable
      }
      lost(OO) {
        return this.dropped || OO.start + OO.length > this.YO
      }
      write(OO, KO) {
        const {
          device: pO,
          unitBytes: XO
        } = this.arena;
        for (const bK of this.backings) {
          const eO = (bK.units - OO.start) * XO;
          eO > 0 && pO.queue.writeBuffer(bK.buffer, OO.start * XO, KO, 0, Math.min(KO.byteLength, eO))
        }
      }
      writeLight(OO, KO) {
        const {
          device: pO,
          twinUnitBytes: XO,
          verticesPerUnit: bK
        } = this.arena, {
          light: eO,
          count: lO
        } = this.arena.twinLight(KO, Math.min(KO.length, OO.length * bK));
        for (const vK of this.backings) {
          vK.twin || (vK.twin = this.createBuffer(vK, !0));
          const KO = (vK.units - OO.start) * bK;
          KO > 0 && pO.queue.writeBuffer(vK.twin, OO.start * XO, eO, 0, Math.min(lO, KO))
        }
      }
      grow(OO) {
        this.arena.assertNotDrawing();
        const {
          device: KO,
          unitBytes: pO,
          label: XO
        } = this.arena, bK = this.backings[this.backings.length - 1], eO = new Lv(OO), lO = KO.createCommandEncoder({
          label: `${XO}-grow`
        });
        eO.buffer = this.createBuffer(eO, !1), lO.copyBufferToBuffer(bK.buffer, 0, eO.buffer, 0, bK.units * pO), bK.twin && (eO.twin = this.createBuffer(eO, !0), lO.copyBufferToBuffer(bK.twin, 0, eO.twin, 0, bK.units * this.arena.twinUnitBytes)), KO.queue.submit([lO.finish()]), this.backings.push(eO), this.Xl.grow(OO)
      }
      drop() {
        if (!this.dropped) {
          this.dropped = !0;
          for (const OO of this.backings) OO.destroy();
          this.refresh(), this.arena.remove(this)
        }
      }
      createBuffer(OO, KO) {
        const {
          device: pO,
          unitBytes: XO,
          twinUnitBytes: bK,
          usage: eO,
          label: lO
        } = this.arena;
        pO.pushErrorScope("out-of-memory");
        const vK = pO.createBuffer({
          label: KO ? `${lO}-light` : lO,
          size: OO.units * (KO ? bK : XO),
          usage: (KO ? this.arena.twinUsage : eO) | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC
        });
        return this.arena.awaitingVerdict++, pO.popErrorScope().then((pO => {
          this.arena.awaitingVerdict--, this.settle(OO, KO, !pO, !0)
        }), (pO => {
          this.arena.awaitingVerdict--, this.arena.warnOnce("noVerdict", `no out-of-memory verdict for a ${lO} buffer, taken as failed: ${String(pO)}`), this.settle(OO, KO, !1, !1)
        })), vK
      }
      settle(OO, KO, pO, XO) {
        const bK = this.backings.indexOf(OO);
        if (!(this.dropped || bK < 0)) {
          if (!pO) {
            if (XO && this.arena.ranOutOfMemory(OO.units, OO.units * (KO ? this.arena.twinUnitBytes : this.arena.unitBytes)), 0 === bK) return void this.drop();
            for (const OO of this.backings.splice(bK)) OO.destroy();
            return this.Xl.truncate(this.backings[bK - 1].units), this.growable = !1, void this.promote()
          }
          KO ? OO.twinReady = !0 : (OO.bufferReady = !0, this.arena.allocatedBuffer(OO.units)), this.promote()
        }
      }
      promote() {
        const {
          backings: OO
        } = this;
        let KO = 0;
        for (; KO + 1 < OO.length && OO[KO].ready && OO[KO + 1].ready;) KO++;
        for (const pO of OO.splice(0, KO)) pO.destroy();
        this.refresh()
      }
      refresh() {
        const OO = this.backings[0];
        this.buffer = OO.buffer, this.twin = OO.twinReady ? OO.twin : null, this.usable = !this.dropped && OO.bufferReady ? OO.units : 0
      }
    }
    class zC {
      constructor(OO, KO, pO, XO) {
        let {
          verticesPerUnit: bK = 1,
          twinUsage: eO = GPUBufferUsage.VERTEX
        } = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
        if (this.device = OO, this.unitBytes = KO, this.usage = pO, this.label = XO, this.pages = [], this.drawing = !1, this.awaitingVerdict = 0, this.verticesPerUnit = void 0, this.twinUsage = void 0, this.twinValueBytes = void 0, this.twinUnitBytes = void 0, this.limit = -1, this.ceiling = -1, this.failed = 1 / 0, this.shortages = 0, this.forgetFailedAt = 0, this.shortageUntil = -1 / 0, this.warnOnce = (0, hK.d)("Lite terrain: "), this.padded = new Uint16Array(0), this.widened = new Float32Array(0), KO % 4 !== 0) throw new Error(`${XO}: ${KO}-byte units cannot keep every range four-byte aligned`);
        this.verticesPerUnit = bK, this.twinUsage = eO, this.twinValueBytes = bK > 1 ? 2 : 4, this.twinUnitBytes = this.twinValueBytes * bK
      }
      twinLight(OO, KO) {
        if (4 === this.twinValueBytes) return this.widened.length < KO && (this.widened = new Float32Array(Math.max(KO, 2 * this.widened.length))), this.widened.set(OO.subarray(0, KO)), {
          light: this.widened,
          count: KO
        };
        const pO = KO % this.verticesPerUnit;
        if (0 === pO) return {
          light: OO,
          count: KO
        };
        const XO = KO - pO + this.verticesPerUnit;
        return this.padded.length < XO && (this.padded = new Uint16Array(Math.max(XO, 2 * this.padded.length))), this.padded.set(OO.subarray(0, KO)), this.padded.fill(0, KO, XO), {
          light: this.padded,
          count: XO
        }
      }
      allocate(OO) {
        if (this.assertNotDrawing(), this.limit < 0 && (this.limit = this.ceiling = this.pageLimit()), OO > this.limit) return null;
        this.failed !== 1 / 0 && performance.now() >= this.forgetFailedAt && (this.failed = 1 / 0, this.ceiling = this.limit);
        for (const bK of this.pages) {
          const KO = bK.Xl.allocate(OO);
          if (KO >= 0) return {
            page: bK,
            start: KO,
            length: OO
          }
        }
        const KO = this.pages[this.pages.length - 1];
        if (null !== KO && void 0 !== KO && KO.canGrow) {
          const pO = Math.min(this.ceiling, Math.max(2 * KO.YO, KO.YO + OO));
          if (pO - KO.YO >= OO) return KO.grow(pO), {
            page: KO,
            start: KO.Xl.allocate(OO),
            length: OO
          }
        }
        KO && KO !== this.pages[0] && 0 === KO.Xl.used && KO.drop();
        const pO = Math.floor(1048576 / this.unitBytes),
          XO = new Qv(this, Math.max(OO, Math.min(this.ceiling, pO)));
        return this.pages.push(XO), {
          page: XO,
          start: XO.Xl.allocate(OO),
          length: OO
        }
      }
      free(OO) {
        this.assertNotDrawing();
        const {
          page: KO
        } = OO;
        KO.Xl.free(OO.start, OO.length), 0 === KO.Xl.used && KO !== this.pages[0] && KO !== this.pages[this.pages.length - 1] && KO.drop()
      }
      remove(OO) {
        const KO = this.pages.indexOf(OO);
        KO >= 0 && this.pages.splice(KO, 1)
      }
      ranOutOfMemory(OO, KO) {
        this.warnOnce("outOfMemory", `out of GPU memory for a ${KO}-byte ${this.label} buffer; its chunks are meshed again`), this.failed = Math.min(this.failed, OO), this.ceiling = Math.max(1, Math.floor(Math.min(this.ceiling, OO) / 2));
        const pO = performance.now();
        pO >= this.shortageUntil && (this.forgetFailedAt = pO + Math.min(6e5, 3e4 * 2 ** this.shortages++), this.shortageUntil = pO + 1e3)
      }
      allocatedBuffer(OO) {
        OO >= this.failed && (this.failed = 1 / 0);
        const KO = Math.min(2 * OO, Math.floor((OO + this.failed) / 2));
        this.ceiling = Math.min(this.limit, Math.max(this.ceiling, KO))
      }
      stats() {
        let OO = 0,
          KO = 0,
          pO = 0,
          XO = 0;
        for (const bK of this.pages) OO += bK.YO, KO += bK.Xl.used, pO += bK.hasTwin ? bK.YO * this.twinUnitBytes : 0, XO += bK.allocatedBytes;
        return {
          pages: this.pages.length,
          capacityBytes: OO * this.unitBytes,
          usedBytes: KO * this.unitBytes,
          twinBytes: pO,
          allocatedBytes: XO
        }
      }
      assertNotDrawing() {}
      pageLimit() {
        const {
          maxBufferSize: OO,
          maxStorageBufferBindingSize: KO
        } = this.device.limits;
        let pO = Math.floor(Math.min(67108864, OO) / this.unitBytes);
        return this.usage & GPUBufferUsage.STORAGE && (pO = Math.min(pO, Math.floor(KO / this.unitBytes))), this.twinUsage & GPUBufferUsage.STORAGE && (pO = Math.min(pO, Math.floor(KO / this.twinUnitBytes))), pO
      }
    }
    const Av = 16383;

    function fv(OO, KO, pO, XO, bK) {
      let eO = 0;
      for (let lO = pO; lO < XO; lO += Av) OO.drawIndexed(6 * Math.min(Av, XO - lO), 1, 0, KO + 4 * lO, bK), eO++;
      return eO
    }
    class dv {
      constructor(OO, KO) {
        this.recordsGroup = KO, this.vertexArena = void 0, this.quadArena = void 0, this.quadPattern = void 0, this.fullSky = new Uint16Array(0), this.boundVertices = null, this.boundLight = null, this.boundRecords = null, this.boundRecordsLight = null, this.boundPattern = !1;
        const pO = IK.e.strideWithoutAtlas;
        this.vertexArena = new zC(OO, pO, GPUBufferUsage.VERTEX, `terrain-vertices-${pO}`), this.quadArena = new zC(OO, aC.c, GPUBufferUsage.STORAGE, "terrain-quads", {
          verticesPerUnit: 4,
          twinUsage: GPUBufferUsage.STORAGE
        });
        const XO = (0, yp.c)(new Uint16Array(98298), Av);
        this.quadPattern = OO.createBuffer({
          label: "terrain-quad-pattern",
          size: XO.byteLength,
          usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST
        }), OO.queue.writeBuffer(this.quadPattern, 0, XO)
      }
      set(OO, KO) {
        const pO = KO.packedVertices,
          XO = pO ? this.quadArena.allocate(OO.faceCount) : this.vertexArena.allocate(OO.vertexCount);
        if (!XO) return !1;
        OO.vertices = XO;
        const bK = pO ? new Uint8Array(pO.buffer, pO.byteOffset, pO.byteLength) : new Uint8Array(KO.vertices);
        return XO.page.write(XO, bK), !0
      }
      setLight(OO, KO) {
        const {
          vertices: pO
        } = OO;
        pO && 0 !== KO.length && pO.page.live && (KO.length < OO.vertexCount ? pO.page.arena.warnOnce("shortLight", `a part's ${KO.length} light values are fewer than its ${OO.vertexCount} vertices, so its light is left as it was`) : (pO.page.writeLight(pO, KO), OO.lit = !0))
      }
      lightFullSky(OO, KO) {
        this.fullSky.length < KO && (this.fullSky = new Uint16Array(Math.max(KO, 4096)).fill(Vv.i));
        for (const pO of OO) {
          const OO = pO.vertices;
          OO.page.live && (OO.page.writeLight(OO, this.fullSky), pO.lit = !0)
        }
      }
      backed(OO) {
        const {
          vertices: KO
        } = OO;
        return !!KO && KO.page.holds(KO)
      }
      lost(OO) {
        const {
          vertices: KO
        } = OO;
        return !!KO && KO.page.lost(KO)
      }
      release(OO) {
        OO.vertices && OO.vertices.page.arena.free(OO.vertices), OO.vertices = null, OO.lit = !1
      }
      setDrawing(OO) {
        this.forgetBound()
      }
      draw(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : KO.faceCount;
        const eO = KO.vertices,
          lO = eO.page,
          vK = pO ? lO.twin : null;
        if (!lO.holds(eO) || pO && !vK) return 0;
        const {
          verticesPerUnit: CO
        } = lO.arena;
        let hO = eO.start * CO;
        this.boundPattern || (OO.setIndexBuffer(this.quadPattern, "uint16"), this.boundPattern = !0);
        const DO = XO + bK;
        if (CO > 1) return lO.buffer === this.boundRecords && vK === this.boundRecordsLight || (OO.setBindGroup(1, this.recordsGroup(lO.buffer, vK)), this.boundRecords = lO.buffer, this.boundRecordsLight = vK), fv(OO, hO, XO, DO, KO.slot);
        lO.buffer !== this.boundVertices && (OO.setVertexBuffer(0, lO.buffer), this.boundVertices = lO.buffer), vK && vK !== this.boundLight && (OO.setVertexBuffer(1, vK), this.boundLight = vK);
        const MO = KO.faceCount;
        return DO <= MO ? fv(OO, hO, XO, DO, KO.slot) : fv(OO, hO, XO, MO, KO.slot) + fv(OO, hO, Math.max(XO, MO) - MO, DO - MO, KO.slot)
      }
      get buffersAwaitingVerdict() {
        let OO = 0;
        for (const KO of this.arenas()) OO += KO.awaitingVerdict;
        return OO
      }* arenas() {
        yield this.vertexArena, yield this.quadArena
      }
      forgetBound() {
        this.boundVertices = this.boundLight = this.boundRecords = this.boundRecordsLight = null, this.boundPattern = !1
      }
    }
    class Tv {
      constructor(OO, KO, pO, XO) {
        this.device = OO, this.splitBefore = KO, this.wanted = !1, this.pipeline = null, this.building = !0, this.unprojectBuffer = void 0, this.unproject = new Float32Array(2), this.near = 0, this.far = 0, this.copy = null, this.retired = null, this.unprojectBuffer = OO.createBuffer({
          label: "scene-depth-unproject",
          size: 8,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        });
        const bK = OO.createShaderModule({
          label: "scene-depth-copy",
          code: (eO = pO._targetSignature._sampleCount > 1, `\n@group(0) @binding(0) var depth: ${eO?"texture_depth_multisampled_2d":"texture_depth_2d"};\n@group(0) @binding(1) var<uniform> unproject: vec2f;\n\n@vertex\nfn copyVertex(@builtin(vertex_index) i: u32) -> @builtin(position) vec4f {\n\tlet corner = array<vec2f, 3>(vec2f(-1.0, -1.0), vec2f(3.0, -1.0), vec2f(-1.0, 3.0))[i];\n\treturn vec4f(corner, 0.0, 1.0);\n}\n\n@fragment\nfn copyFragment(@builtin(position) pixel: vec4f) -> @location(0) f32 {\n\tlet d = textureLoad(depth, vec2i(pixel.xy), 0);\n\tif (d <= 0.0) {\n\t\treturn 0.0;\n\t}\n\treturn unproject.y / (2.0 * d + unproject.x);\n}\n`)
        });
        var eO;
        OO.createRenderPipelineAsync({
          label: "scene-depth-copy",
          layout: "auto",
          vertex: {
            module: bK,
            entryPoint: "copyVertex"
          },
          fragment: {
            module: bK,
            entryPoint: "copyFragment",
            targets: [{
              format: "r32float"
            }]
          }
        }).then((OO => {
          this.pipeline = OO, this.building = !1
        }), (OO => {
          this.building = !1, console.error("Lite: the scene depth copy failed to build, so liquids find nothing behind them", OO)
        })), pO._executeWithTransmission = () => this.execute(pO, XO)
      }
      get compiling() {
        return this.building
      }
      setWanted(OO) {
        this.wanted = OO
      }
      setPlanes(OO, KO) {
        OO === this.near && KO === this.far || (this.near = OO, this.far = KO, this.unproject[0] = OO / (KO - OO), this.unproject[1] = KO * OO / (KO - OO), this.device.queue.writeBuffer(this.unprojectBuffer, 0, this.unproject))
      }
      get view() {
        var OO, KO;
        return null !== (OO = null === (KO = this.copy) || void 0 === KO ? void 0 : KO.view) && void 0 !== OO ? OO : null
      }
      execute(OO, KO) {
        var pO;
        null === (pO = this.retired) || void 0 === pO || pO.destroy(), this.retired = null;
        const XO = OK(KO),
          bK = OO._transparentBindings,
          eO = this.wanted && this.pipeline ? this.splitIndex(bK) : -1,
          lO = OO._colorAttachment,
          vK = lO.resolveTarget;
        eO >= 0 && (lO.resolveTarget = void 0, nl(OO, !0));
        let CO = XO.beginRenderPass(OO._renderPassDescriptor);
        CO.setBindGroup(0, OO._sceneBG);
        let hO = this.drawList(CO, KO, OO._opaqueBindings, 0, OO._opaqueBindings.length);
        if (hO += this.drawList(CO, KO, OO._directBindings, 0, OO._directBindings.length), hO += this.drawList(CO, KO, bK, 0, eO >= 0 ? eO : bK.length), CO.end(), eO < 0) return hO;
        nl(OO);
        const DO = OO._renderPassDescriptor.depthStencilAttachment,
          {
            depthLoadOp: MO,
            stencilLoadOp: aK
          } = DO,
          oO = lO.loadOp;
        lO.resolveTarget = vK;
        try {
          this.copyDepth(XO, OO), lO.loadOp = "load", DO.depthLoadOp = "load", aK && (DO.stencilLoadOp = "load"), CO = XO.beginRenderPass(OO._renderPassDescriptor), CO.setBindGroup(0, OO._sceneBG), hO += this.drawList(CO, KO, bK, eO, bK.length), CO.end()
        } finally {
          lO.loadOp = oO, DO.depthLoadOp = MO, DO.stencilLoadOp = aK
        }
        return hO
      }
      splitIndex(OO) {
        for (let KO = 0; KO < OO.length; KO++)
          if (OO[KO].renderable === this.splitBefore) return KO;
        return -1
      }
      drawList(OO, KO, pO, XO, bK) {
        let eO = null,
          lO = 0;
        for (let vK = XO; vK < bK; vK++) {
          const XO = pO[vK],
            bK = XO.renderable.mesh;
          bK && !1 === bK.visible || (XO.pipeline !== eO && (OO.setPipeline(XO.pipeline), eO = XO.pipeline), lO += XO.draw(OO, KO))
        }
        return lO
      }
      copyDepth(OO, KO) {
        var pO, XO;
        const bK = (null !== (pO = KO._config.depth) && void 0 !== pO ? pO : KO._config.rt)._depthTexture,
          eO = (null === (XO = this.copy) || void 0 === XO ? void 0 : XO.source) === bK ? this.copy : this.remakeCopy(bK),
          lO = OO.beginRenderPass(eO.pass);
        lO.setPipeline(this.pipeline), lO.setBindGroup(0, eO.bindGroup), lO.draw(3), lO.end()
      }
      remakeCopy(OO) {
        var KO, pO;
        this.retired = null !== (KO = null === (pO = this.copy) || void 0 === pO ? void 0 : pO.texture) && void 0 !== KO ? KO : null;
        const XO = this.device.createTexture({
            label: "scene-depth",
            size: [OO.width, OO.height],
            format: "r32float",
            usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING
          }),
          bK = XO.createView(),
          eO = this.device.createBindGroup({
            label: "scene-depth-copy",
            layout: this.pipeline.getBindGroupLayout(0),
            entries: [{
              binding: 0,
              resource: OO.createView({
                aspect: "depth-only"
              })
            }, {
              binding: 1,
              resource: {
                buffer: this.unprojectBuffer
              }
            }]
          }),
          lO = {
            label: "scene-depth-copy",
            colorAttachments: [{
              view: bK,
              loadOp: "clear",
              storeOp: "store",
              clearValue: [0, 0, 0, 0]
            }]
          };
        return this.copy = {
          source: OO,
          texture: XO,
          view: bK,
          bindGroup: eO,
          pass: lO
        }, this.copy
      }
    }
    const Nv = "rgba8unorm";

    function Iv(OO) {
      return OO ? 15 : 1
    }
    class yC {
      constructor(OO, KO, pO, XO) {
        this.device = OO, this.terrain = XO, this.pipeline = null, this.building = !0, this.edge = void 0, this.layout = void 0, this.empty = void 0, this.cameraBuffer = void 0, this.camera = new Float32Array(16), this.targets = null, this.retired = null, this.edge = KO._targetSignature._sampleCount > 1, this.cameraBuffer = OO.createBuffer({
          label: "sun-shadow-mask-camera",
          size: 64,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        }), this.layout = OO.createBindGroupLayout({
          label: "sun-shadow-mask",
          entries: [{
            binding: 0,
            visibility: GPUShaderStage.FRAGMENT,
            texture: {
              sampleType: "depth"
            }
          }, {
            binding: 1,
            visibility: GPUShaderStage.FRAGMENT,
            buffer: {
              type: "uniform"
            }
          }, {
            binding: 2,
            visibility: GPUShaderStage.FRAGMENT,
            texture: {
              sampleType: "float"
            }
          }]
        });
        const bK = OO.createBindGroupLayout({
          label: "sun-shadow-mask-empty",
          entries: []
        });
        this.empty = OO.createBindGroup({
          label: "sun-shadow-mask-empty",
          layout: bK,
          entries: []
        });
        const eO = OO.createShaderModule({
          label: "sun-shadow-mask",
          code: (lO = this.edge, `${(0,gp.E)()}${Hp({sunShadow:!0,airShadow:!1},!0,"lit")}\n@group(0) @binding(0) var bloxdSmDepth: texture_depth_2d;\nstruct BloxdSmCamera {\n\teye: vec3f,\n\ttolerance: f32,\n\tright: vec3f,\n\tdepthScale: f32,\n\tup: vec3f,\n\tdepthBias: f32,\n\tforward: vec3f,\n}\n@group(0) @binding(1) var<uniform> bloxdSmCamera: BloxdSmCamera;\n@group(0) @binding(2) var bloxdSmNormal: texture_2d<f32>;\n${lO?gX:""}\n@vertex\nfn maskVertex(@builtin(vertex_index) i: u32) -> @builtin(position) vec4f {\n\tlet corner = array<vec2f, 3>(vec2f(-1.0, -1.0), vec2f(3.0, -1.0), vec2f(-1.0, 3.0))[i];\n\treturn vec4f(corner, 0.0, 1.0);\n}\n\n@fragment\nfn maskFragment(@builtin(position) pixel: vec4f) -> @location(0) vec4f {\n\tlet at = vec2i(pixel.xy);\n\tlet d = textureLoad(bloxdSmDepth, at, 0);\n\tif (d <= 0.0) {\n\t\treturn vec4f(${Iv(lO)}.0, 0.0, 0.0, 0.0);\n\t}\n\t// View z from the depth as it is, then along the pixel's ray: an inverse view-projection would round d against 1\n\tlet size = vec2f(textureDimensions(bloxdSmDepth));\n\tlet ndc = vec2f(pixel.x / size.x * 2.0 - 1.0, 1.0 - pixel.y / size.y * 2.0);\n\tlet z = bloxdSmCamera.depthScale / (2.0 * d + bloxdSmCamera.depthBias);\n\tlet packed = textureLoad(bloxdSmNormal, at, 0);\n\tbloxdSpShadowPosition = bloxdSmCamera.eye + z * (bloxdSmCamera.forward + ndc.x * bloxdSmCamera.right + ndc.y * bloxdSmCamera.up);\n\t// Capped well inside the quarter block origins start off their face: past it, a few pixels\n\tbloxdSpPlaneTolerance = min(z * z * bloxdSmCamera.tolerance, 0.125);\n\tbloxdSpShadowNormal = normalize(packed.xyz * 2.0 - 1.0);\n\tbloxdSpShadowEmissive = packed.w > 0.5;\n\treturn ${lO?"vec4f(bloxdSpNormalCode(bloxdSpShadowNormal) * 2.0 + bloxdShadow(), d, 0.0, 0.0)":"vec4f(bloxdShadow())"};\n}\n`)
        });
        var lO;
        OO.createRenderPipelineAsync({
          label: "sun-shadow-mask",
          layout: OO.createPipelineLayout({
            bindGroupLayouts: [this.layout, bK, bK, He(OO, {
              depth: !1,
              sunShadow: !0
            })]
          }),
          vertex: {
            module: eO,
            entryPoint: "maskVertex"
          },
          fragment: {
            module: eO,
            entryPoint: "maskFragment",
            targets: [{
              format: this.maskFormat
            }]
          }
        }).then((OO => {
          this.pipeline = OO, this.building = !1
        }), (OO => {
          this.building = !1, console.error("Lite: the sun shadow mask's trace failed to build, so terrain reading it is lit", OO)
        }));
        const vK = KO._executeWithTransmission;
        KO._executeWithTransmission = OO => this.execute(KO, pO, (() => vK ? vK(OO) : function(OO, KO) {
          const pO = OK(KO).beginRenderPass(OO._renderPassDescriptor);
          pO.setBindGroup(0, OO._sceneBG);
          let XO = gC(pO, KO, OO._opaqueBindings);
          return XO += gC(pO, KO, OO._directBindings), XO += gC(pO, KO, OO._transparentBindings), pO.end(), XO
        }(KO, pO)))
      }
      get compiling() {
        return this.building
      }
      get view() {
        var OO, KO;
        return null !== (OO = null === (KO = this.targets) || void 0 === KO ? void 0 : KO.maskView) && void 0 !== OO ? OO : null
      }
      get maskFormat() {
        return this.edge ? "rg32float" : "r8unorm"
      }
      prepare(OO) {
        ! function(OO, KO) {
          const pO = OO.worldMatrix,
            XO = OO.projectionMatrix,
            bK = 1 / XO[0],
            eO = 1 / XO[5],
            lO = OO.far * OO.near / (OO.far - OO.near);
          KO[0] = OO.eye[0], KO[1] = OO.eye[1], KO[2] = OO.eye[2], KO[3] = 2 ** -23 / lO, KO[4] = pO[0] * bK, KO[5] = pO[1] * bK, KO[6] = pO[2] * bK, KO[7] = lO, KO[8] = pO[4] * eO, KO[9] = pO[5] * eO, KO[10] = pO[6] * eO, KO[11] = OO.near / (OO.far - OO.near), KO[12] = pO[8], KO[13] = pO[9], KO[14] = pO[10], KO[15] = 0
        }(OO, this.camera), this.device.queue.writeBuffer(this.cameraBuffer, 0, this.camera)
      }
      execute(OO, KO, pO) {
        if (this.retire(), !this.terrain.readsMask) return pO();
        const XO = this.targetsFor(OO),
          bK = OK(KO),
          eO = OO._renderPassDescriptor.depthStencilAttachment;
        this.edge || (XO.prepass.depthStencilAttachment.view = eO.view);
        const lO = this.terrain.drawPrepass(bK, XO.prepass, OO._sceneBG);
        if (0 === lO) return pO();
        if (this.trace(bK, XO), this.edge) return lO + 1 + pO();
        const {
          depthLoadOp: vK,
          stencilLoadOp: CO
        } = eO;
        eO.depthLoadOp = "load", CO && (eO.stencilLoadOp = "load");
        try {
          return lO + 1 + pO()
        } finally {
          eO.depthLoadOp = vK, eO.stencilLoadOp = CO
        }
      }
      trace(OO, KO) {
        const pO = this.terrain.sunShadowGroup(),
          XO = OO.beginRenderPass(KO.trace);
        this.pipeline && pO && (XO.setPipeline(this.pipeline), XO.setBindGroup(0, KO.bindGroup), XO.setBindGroup(1, this.empty), XO.setBindGroup(2, this.empty), XO.setBindGroup(3, pO), XO.draw(3)), XO.end()
      }
      retire() {
        const OO = this.retired;
        var KO;
        OO && (OO.mask.destroy(), OO.normals.destroy(), null === (KO = OO.depth) || void 0 === KO || KO.destroy(), this.retired = null)
      }
      targetsFor(OO) {
        var KO, pO;
        const XO = (null !== (KO = OO._config.depth) && void 0 !== KO ? KO : OO._config.rt)._depthTexture;
        return (null === (pO = this.targets) || void 0 === pO ? void 0 : pO.source) === XO ? this.targets : this.remake(OO, XO)
      }
      remake(OO, KO) {
        var pO;
        this.retired = this.targets;
        const XO = [KO.width, KO.height],
          bK = this.device.createTexture({
            label: "sun-shadow-mask",
            size: XO,
            format: this.maskFormat,
            usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING
          }),
          eO = this.device.createTexture({
            label: "sun-shadow-prepass-normals",
            size: XO,
            format: Nv,
            usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING
          }),
          lO = null !== (pO = OO._targetSignature._depthStencilFormat) && void 0 !== pO ? pO : KO.format,
          vK = this.edge ? this.device.createTexture({
            label: "sun-shadow-prepass-depth",
            size: XO,
            format: lO,
            usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING
          }) : null,
          CO = OO._renderPassDescriptor.depthStencilAttachment,
          hO = lO.includes("stencil"),
          DO = {
            label: "sun-shadow-prepass",
            colorAttachments: [{
              view: eO.createView(),
              loadOp: "clear",
              storeOp: "store",
              clearValue: [.5, 1, .5, 0]
            }],
            depthStencilAttachment: {
              view: vK ? vK.createView() : CO.view,
              depthClearValue: CO.depthClearValue,
              depthLoadOp: "clear",
              depthStoreOp: "store",
              ...hO ? {
                stencilClearValue: CO.stencilClearValue,
                stencilLoadOp: "clear",
                stencilStoreOp: "store"
              } : {}
            }
          },
          MO = this.device.createBindGroup({
            label: "sun-shadow-mask",
            layout: this.layout,
            entries: [{
              binding: 0,
              resource: (null !== vK && void 0 !== vK ? vK : KO).createView({
                aspect: "depth-only"
              })
            }, {
              binding: 1,
              resource: {
                buffer: this.cameraBuffer
              }
            }, {
              binding: 2,
              resource: eO.createView()
            }]
          }),
          aK = {
            label: "sun-shadow-mask",
            colorAttachments: [{
              view: bK.createView(),
              loadOp: "clear",
              storeOp: "store",
              clearValue: [Iv(this.edge), 0, 0, 0]
            }]
          };
        return this.targets = {
          source: KO,
          mask: bK,
          maskView: bK.createView(),
          normals: eO,
          depth: vK,
          bindGroup: MO,
          prepass: DO,
          trace: aK
        }, this.targets
      }
    }

    function gC(OO, KO, pO) {
      let XO = null,
        bK = 0;
      for (const eO of pO) {
        const pO = eO.renderable.mesh;
        pO && !1 === pO.visible || (eO.pipeline !== XO && (OO.setPipeline(eO.pipeline), XO = eO.pipeline), bK += eO.draw(OO, KO))
      }
      return bK
    }
    const uv = 6e4,
      Ev = {
        status: "ok"
      },
      jC = {
        status: "skipped"
      };
    async function Yv(OO, KO) {
      const {
        isCancelled: pO
      } = OO;
      if (pO()) return {
        status: "dl"
      };
      const {
        target: XO
      } = KO;
      if (!XO) return console.warn("Shader pack: skipped the compile check, as Lite hasn't bound terrain yet"), {
        status: "skipped"
      };
      const bK = [],
        eO = Promise.all(Array.from(new Set(OO.materials), (async pO => {
          bK.push(await async function(OO, KO, pO, XO) {
            const bK = {
              lighting: OO.lighting,
              dirLightCount: Math.min(OO.dirLightCount, 4),
              hX: OO.runtime
            };
            try {
              const eO = KO.material(XO);
              return eO && hX(KO.programKey(eO, !1, bK)) ? (await eO.ready, OO.isCancelled() ? Ev : eO.bindGroupLayout ? await async function(OO, KO, pO, XO) {
                const {
                  device: bK
                } = OO;
                let eO, lO;
                bK.pushErrorScope("validation");
                try {
                  eO = OO.pipelineBuild(KO, pO, XO)
                } finally {
                  lO = bK.popErrorScope().catch((() => null))
                }
                const [vK, CO] = await Promise.all([lO, eO.built.then((() => null), (OO => null !== OO && void 0 !== OO ? OO : new Error("pipeline failed")))]);
                if (!vK && !CO) return Ev;
                const hO = await wv(eO.module),
                  DO = hO.length > 0 ? hO.map((OO => `${eO.name} ${OO.lineNum}:${OO.linePos}: ${OO.message}`)).join("\n") : `${eO.name}: ${iC(null!==CO&&void 0!==CO?CO:vK)}`;
                return {
                  status: "failed",
                  material: KO.model.name,
                  message: DO
                }
              }(KO, eO, KO.programKey(eO, "none" !== eO.texture, bK), pO): (console.warn(`Shader pack: skipped the compile check for "${XO.name}", whose textures failed to load`), jC)) : Ev
            } catch (eO) {
              return {
                status: "failed",
                material: XO.name,
                message: iC(eO)
              }
            }
          }(OO, KO, XO, pO))
        }))),
        lO = function(OO, KO) {
          let pO, XO, bK = !1;
          const eO = new Promise((eO => {
            var lO;
            pO = setTimeout((() => {
              eO("timeout")
            }), null !== (lO = KO.timeoutMs) && void 0 !== lO ? lO : uv), XO = setInterval((() => {
              KO.isCancelled() && eO("dl")
            }), 50), OO.lost.then((() => {
              bK = !0, eO("lost")
            }))
          }));
          return {
            signal: eO,
            lost: () => bK,
            dispose: () => {
              clearTimeout(pO), clearInterval(XO)
            }
          }
        }(KO.device, OO);
      let vK;
      try {
        vK = await Promise.race([eO.then((() => "done")), lO.signal])
      } finally {
        lO.dispose()
      }
      if ("dl" === vK || pO()) return {
        status: "dl"
      };
      const CO = bK.find((OO => "failed" === OO.status));
      return CO && "lost" !== vK && !lO.lost() && await new Promise((OO => {
        setTimeout(OO, 0)
      })), "lost" === vK || lO.lost() ? (console.warn("Shader pack: skipped the compile check, as the GPU device was lost"), {
        status: "skipped"
      }) : CO ? {
        status: "failed",
        failure: {
          material: CO.material,
          message: CO.message
        }
      } : "timeout" === vK ? (console.warn(`Shader pack: skipped the compile check, which didn't finish in ${(null!==(hO=OO.timeoutMs)&&void 0!==hO?hO:uv)/1e3} s`), {
        status: "skipped"
      }) : bK.some((OO => "skipped" === OO.status)) ? {
        status: "skipped"
      } : {
        status: "ok"
      };
      var hO
    }
    async function wv(OO) {
      if (!OO) return [];
      try {
        return (await OO.getCompilationInfo()).messages.filter((OO => "error" === OO.type))
      } catch {
        return []
      }
    }

    function iC(OO) {
      var KO;
      return null !== (KO = null === OO || void 0 === OO ? void 0 : OO.message) && void 0 !== KO ? KO : String(OO)
    }

    function rC(OO, KO, pO, XO) {
      hX(OO) ? wv(pO).then((OO => {
        const [pO] = OO;
        xe("terrain", KO, XO, pO ? `${pO.lineNum}:${pO.linePos} error: ${pO.message}` : null)
      })) : xe("terrain", KO, XO)
    }
    var Pv = pO(35866),
      mC = pO(35879),
      sv = pO(35895),
      Hv = pO(35819);

    function Rv(OO, KO, pO, XO, bK) {
      const eO = Math.hypot(pO[0], pO[1], pO[2]);
      if (!(eO > 0)) return;
      const lO = [pO[0] / eO, pO[1] / eO, pO[2] / eO],
        vK = [Math.floor(KO[0]), Math.floor(KO[1]), Math.floor(KO[2])],
        CO = [0, 0, 0],
        hO = [1 / 0, 1 / 0, 1 / 0],
        DO = [1 / 0, 1 / 0, 1 / 0];
      for (let oO = 0; oO < 3; oO++) lO[oO] > 0 ? (CO[oO] = 1, hO[oO] = (vK[oO] + 1 - KO[oO]) / lO[oO], DO[oO] = 1 / lO[oO]) : lO[oO] < 0 && (CO[oO] = -1, hO[oO] = (vK[oO] - KO[oO]) / lO[oO], DO[oO] = -1 / lO[oO]);
      const {
        SX: MO
      } = OO;
      let aK = OO.RXO(vK[0], vK[1], vK[2]);
      for (;;) {
        const KO = hO[0] < hO[1] ? hO[0] < hO[2] ? 0 : 2 : hO[1] < hO[2] ? 1 : 2;
        if (hO[KO] > XO) return;
        const pO = CO[KO] > 0 ? vK[KO] + 1 : vK[KO];
        vK[KO] += CO[KO], hO[KO] += DO[KO];
        const eO = OO.RXO(vK[0], vK[1], vK[2]),
          lO = eO !== aK && !(OO.opaque[aK] && OO.opaque[eO]);
        if (lO) {
          const XO = [vK[0], vK[1], vK[2]];
          XO[KO] = pO;
          const eO = Math.floor(XO[0] / MO),
            lO = Math.floor(XO[1] / MO),
            CO = Math.floor(XO[2] / MO);
          !OO.isDrawn(eO, lO, CO) && OO.hasParts(eO, lO, CO) && bK.add(`${eO},${lO},${CO}`)
        }
        if (lO && OO.occluders[eO]) return;
        aK = eO
      }
    }

    function Sv(OO, KO) {
      return OO.group - KO.group || OO.nearest - KO.nearest
    }
    class Jv {
      constructor(OO, KO) {
        this.device = OO, this.tV = KO, this.data = new Float32Array(2048), this.words = new Uint32Array(this.data.buffer), this.buffer = void 0, this.free = [], this.next = 0, this.dirtyMin = 1 / 0, this.dirtyMax = -1, this.buffer = this.createBuffer()
      }
      createBuffer() {
        return this.device.createBuffer({
          label: "terrain-chunk-slots",
          size: this.data.byteLength,
          usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST
        })
      }
      allocate() {
        var OO;
        const KO = null !== (OO = this.free.pop()) && void 0 !== OO ? OO : this.next++;
        if (8 * KO >= this.data.length) {
          const OO = new Float32Array(2 * this.data.length);
          OO.set(this.data), this.data = OO, this.words = new Uint32Array(OO.buffer), this.buffer.destroy(), this.buffer = this.createBuffer(), this.markDirty(0, this.next - 1), this.tV()
        }
        return KO
      }
      release(OO) {
        this.free.push(OO)
      }
      set(OO, KO, pO, XO, bK) {
        const eO = 8 * OO + AX;
        this.data[eO] = KO, this.data[eO + 1] = pO, this.data[eO + 2] = XO, this.setVisibility(OO, bK)
      }
      setVisibility(OO, KO) {
        this.data[8 * OO + fX] = KO, this.markDirty(OO, OO)
      }
      setFaces(OO, KO, pO) {
        const XO = 8 * OO;
        this.words[XO + dX] = KO, this.words[XO + TX] = pO, this.markDirty(OO, OO)
      }
      markDirty(OO, KO) {
        this.dirtyMin = Math.min(this.dirtyMin, OO), this.dirtyMax = Math.max(this.dirtyMax, KO)
      }
      flush() {
        if (this.dirtyMax < this.dirtyMin) return;
        this.device.queue.writeBuffer(this.buffer, 8 * this.dirtyMin * 4, this.data, 8 * this.dirtyMin, 8 * (this.dirtyMax - this.dirtyMin + 1)), this.dirtyMin = 1 / 0, this.dirtyMax = -1
      }
    }
    const cC = zb,
      Bv = !0;
    const Zv = {
        arrayStride: 4,
        stepMode: "vertex",
        attributes: [{
          shaderLocation: cC.packedLight,
          offset: 0,
          format: "float32"
        }]
      },
      Gv = {
        srcFactor: "src-alpha",
        dstFactor: "one-minus-src-alpha",
        operation: "add"
      };
    class qC {
      constructor(OO) {
        this.device = OO, this.opaqueRenderable = void 0, this.transparentRenderable = void 0, this.sceneDepth = null, this.sunShadow = null, this.shadowMask = null, this.chunks = new Map, this.materials = new Map, this.slots = void 0, this.sceneLayout = void 0, this.frameLayout = void 0, this.materialLayouts = new Map, this.frameUniforms = new Float32Array(MX), this.dirLightUniforms = this.frameUniforms.subarray(DX.dirLights, DX.aoLevels), this.frameBuffer = void 0, this.frameBindGroup = void 0, this.recordsGroups = new WeakMap, this.modules = new Map, this.pipelines = new Map, this.prepassOf = new WeakMap, this.maskPipelines = 0, this.builds = new Map, this.target = null, this.compiling = 0, this.sampler = void 0, this.geometry = void 0, this.warnOnce = (0, hK.d)(), this.faceGroups = !0, this.visibilityGraph = Bv, this.visCull = Bv, this.visCheck = !1, this.visCullMinDistance = sv.f, this.visCheckFrame = 0, this.visCandidates = [], this.visCandidateBatches = [], this.visPassable = new Set, this.visBatchDraws = new Map, this.visDrawsMaterial = null, this.visDrawsBits = 0, this.visCulledParts = 0, this.visCulledTriangles = 0, this.visViolations = 0, this.visSweeps = 0, this.submittedTriangles = 0, this.chunkSorter = new tC, this.opaqueBatches = [], this.transparent = [], this.unlit = [], this.lighting = !1, this.dirLightCount = 0, this.aoLevelsWritten = !1, this.originOffset = [0, 0, 0], this.eye = [0, 0, 0], this.faceRanges = new Int32Array(4), this.faceEpoch = 0, this.faceEye = [NaN, NaN, NaN], this.faceFocalPx = NaN, this.hX = null, this.shaderPackInputs = null, this.depthStandIn = null, this.geometry = new dv(OO, ((OO, KO) => this.recordsGroup(OO, KO))), this.slots = new Jv(OO, (() => {
          this.frameBindGroup = this.createFrameBindGroup(), this.recordsGroups = new WeakMap
        })), this.sceneLayout = KK(OO), this.frameLayout = OO.createBindGroupLayout({
          label: "terrain-frame",
          entries: [{
            binding: 0,
            visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT,
            buffer: {
              type: "uniform"
            }
          }, {
            binding: 1,
            visibility: GPUShaderStage.VERTEX,
            buffer: {
              type: "read-only-storage"
            }
          }, {
            binding: 2,
            visibility: GPUShaderStage.VERTEX,
            buffer: {
              type: "read-only-storage"
            }
          }, {
            binding: 3,
            visibility: GPUShaderStage.VERTEX,
            buffer: {
              type: "read-only-storage"
            }
          }]
        }), this.frameBuffer = OO.createBuffer({
          label: "terrain-frame",
          size: this.frameUniforms.byteLength,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        }), this.frameBindGroup = this.createFrameBindGroup(), this.sampler = OO.createSampler({
          label: "terrain",
          magFilter: "nearest",
          minFilter: "nearest",
          mipmapFilter: "linear",
          addressModeU: "repeat",
          addressModeV: "repeat"
        }), this.opaqueRenderable = {
          order: 100,
          isTransparent: !1,
          _direct: !0,
          bind: (OO, KO) => this.createBinding(this.opaqueRenderable, KO, !1)
        }, this.transparentRenderable = {
          order: 200,
          isTransparent: !0,
          _worldCenter: [0, 0, 0],
          bind: (OO, KO) => this.createBinding(this.transparentRenderable, KO, !0)
        }
      }
      installSceneDepth(OO, KO) {
        this.sceneDepth = new Tv(this.device, this.transparentRenderable, OO, KO)
      }
      createFrameBindGroup() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        return this.device.createBindGroup({
          label: "terrain-frame",
          layout: this.frameLayout,
          entries: [{
            binding: 0,
            resource: {
              buffer: this.frameBuffer
            }
          }, {
            binding: 1,
            resource: {
              buffer: this.slots.buffer
            }
          }, {
            binding: 2,
            resource: {
              buffer: null !== OO && void 0 !== OO ? OO : this.slots.buffer
            }
          }, {
            binding: 3,
            resource: {
              buffer: null !== KO && void 0 !== KO ? KO : this.slots.buffer
            }
          }]
        })
      }
      recordsGroup(OO, KO) {
        const pO = null !== KO && void 0 !== KO ? KO : OO;
        let XO = this.recordsGroups.get(pO);
        return XO || (XO = this.createFrameBindGroup(OO, KO), this.recordsGroups.set(pO, XO)), XO
      }
      setChunkMesh(OO, KO, pO) {
        var XO;
        let bK = this.chunks.get(OO);
        bK ? this.geometry.release(bK) : (bK = {
          mesh: OO,
          slot: this.slots.allocate(),
          origin: [pO[0], pO[1], pO[2]],
          material: null,
          vertices: null,
          lit: !1,
          faceCount: 0,
          vertexCount: 0,
          packed: !1,
          lostRemeshes: 0,
          lostRetryAt: 0,
          visibility: OO.visibility,
          distance: 0,
          faceGroups: null,
          planePX: 0,
          planeNX: 0,
          planePY: 0,
          planeNY: 0,
          planePZ: 0,
          planeNZ: 0,
          faceMask: -1,
          faceEpoch: -1,
          rangeCount: 1,
          first0: 0,
          count0: 0,
          first1: 0,
          count1: 0,
          ci: NaN,
          cj: NaN,
          ck: NaN,
          key: NaN
        }, this.chunks.set(OO, bK), this.writeSlot(bK)), bK.material = OO.material ? this.materialFor(OO.material) : null, bK.packed = !!KO.packedVertices, bK.vertexCount = (0, aC.f)(KO), bK.faceCount = bK.vertexCount / 4;
        const eO = null !== (XO = KO.faceGroups) && void 0 !== XO ? XO : null;
        if (bK.faceGroups = eO, eO) {
          const OO = Pv.i;
          bK.planePX = eO[OO], bK.planeNX = eO[OO + 1], bK.planePY = eO[OO + 2], bK.planeNY = eO[OO + 3], bK.planePZ = eO[OO + 4], bK.planeNZ = eO[OO + 5]
        }
        this.drawWhole(bK), 0 !== bK.faceCount && (this.geometry.set(bK, KO) ? (bK.packed && this.slots.setFaces(bK.slot, bK.vertices.start + bK.faceCount, bK.faceCount), KO.TX && this.setChunkMeshLight(OO, KO.TX)) : this.warnOnce("tooBig", `Lite terrain: a chunk of ${bK.vertexCount} vertices is more than a buffer may hold, and is left out.`))
      }
      setChunkMeshLight(OO, KO) {
        const pO = this.chunks.get(OO);
        pO && this.geometry.setLight(pO, KO)
      }
      drawStats() {
        let OO = this.transparent.length;
        for (const KO of this.opaqueBatches) OO += KO.meshes.length;
        return {
          drawn: OO,
          loaded: this.chunks.size,
          triangles: this.submittedTriangles,
          visCulled: this.visCulledParts,
          visCulledTriangles: this.visCulledTriangles,
          visViolations: this.visViolations,
          visSweeps: this.visSweeps,
          visPassable: this.visPassable.size
        }
      }
      get pipelinesCompiling() {
        return this.compiling
      }
      get buffersAwaitingVerdict() {
        return this.geometry.buffersAwaitingVerdict
      }
      removeChunkMesh(OO) {
        const KO = this.chunks.get(OO);
        KO && (this.geometry.release(KO), this.slots.release(KO.slot), this.chunks.delete(OO))
      }
      remeshLost(OO, KO) {
        this.geometry.release(KO), KO.lostRetryAt = performance.now() + Math.min(6e4, 1e3 * 2 ** KO.lostRemeshes++);
        const pO = OO.lK,
          [XO, bK, eO] = pO.cMO(KO.origin[0], KO.origin[1], KO.origin[2]),
          lO = pO.Rb.Sb(XO, bK, eO);
        lO && (lO.sb = !0, lO.qe = !0, pO.Hb(lO, !1))
      }
      chooseFaceRanges(OO, KO, pO) {
        const XO = this.faceRanges;
        OO.faceMask = pO, OO.rangeCount = (0, mC.n)(KO, pO, XO), OO.first0 = XO[0], OO.count0 = XO[1], OO.first1 = XO[2], OO.count1 = XO[3]
      }
      drawWhole(OO) {
        OO.faceMask = -1, OO.faceEpoch = -1, OO.rangeCount = 1, OO.first0 = 0, OO.count0 = OO.faceCount
      }
      writeSlot(OO) {
        const [KO, pO, XO] = this.originOffset;
        this.slots.set(OO.slot, OO.origin[0] - KO, OO.origin[1] - pO, OO.origin[2] - XO, OO.visibility)
      }
      materialFor(OO) {
        const KO = this.materials.get(OO);
        if (KO) return KO;
        const pO = Fv(OO);
        if (!pO) return this.warnOnce(`material:${OO.name}`, `Lite terrain cannot draw material "${OO.name}"; its chunks are skipped.`), null;
        const {
          model: XO,
          atlas: bK,
          texture: eO,
          animated: lO,
          uniformData: vK
        } = pO, CO = {
          id: this.materials.size,
          model: XO,
          texture: eO,
          animated: lO,
          uniformData: vK,
          uniformBuffer: this.device.createBuffer({
            label: `terrain-material-${OO.name}`,
            size: vK.byteLength,
            usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
          }),
          liquid: pO.liquid,
          customRenderMat: pO.customRenderMat,
          atlasCount: 0,
          MeO: 0,
          atlasLayers: 0,
          nextFrameAtlases: void 0,
          bindGroup: null,
          bindGroupLayout: null,
          ready: Promise.resolve()
        };
        return this.materials.set(OO, CO), this.device.queue.writeBuffer(CO.uniformBuffer, 0, vK), CO.ready = this.createMaterialBindGroup(CO, bK).catch((KO => {
          console.error(`Lite terrain failed to load the textures of material "${OO.name}"`, KO)
        })), CO
      }
      materialLayout(OO) {
        const KO = function(OO) {
            const KO = ["uniforms"];
            if ("atlas" === OO.texture) {
              OO.animated && KO.push("animData"), KO.push("sampler");
              for (let pO = 0; pO < OO.atlasCount; pO++) KO.push("textureArray")
            } else "single" === OO.texture && KO.push("sampler", "texture");
            return KO
          }(OO),
          pO = KO.join(",");
        let XO = this.materialLayouts.get(pO);
        if (!XO) {
          const OO = GPUShaderStage.FRAGMENT;
          XO = this.device.createBindGroupLayout({
            label: `terrain-material-${pO}`,
            entries: KO.map(((KO, pO) => {
              switch (KO) {
                case "uniforms":
                  return {
                    binding: pO, visibility: GPUShaderStage.VERTEX | OO, buffer: {
                      type: "uniform"
                    }
                  };
                case "animData":
                  return {
                    binding: pO, visibility: GPUShaderStage.VERTEX | OO, buffer: {
                      type: "read-only-storage"
                    }
                  };
                case "sampler":
                  return {
                    binding: pO, visibility: OO, sampler: {
                      type: "filtering"
                    }
                  };
                case "texture":
                  return {
                    binding: pO, visibility: OO, texture: {
                      sampleType: "float",
                      viewDimension: "2d"
                    }
                  };
                case "textureArray":
                  return {
                    binding: pO, visibility: OO, texture: {
                      sampleType: "float",
                      viewDimension: "2d-array"
                    }
                  }
              }
            }))
          }), this.materialLayouts.set(pO, XO)
        }
        return XO
      }
      async createMaterialBindGroup(OO, KO) {
        const pO = [{
          buffer: OO.uniformBuffer
        }];
        if (KO) {
          const {
            urls: XO,
            pixels: bK,
            layerWidth: eO
          } = KO.sources, lO = await Promise.all(XO.map(((OO, KO) => {
            var pO;
            return Sb(this.device, OO, null !== (pO = null === bK || void 0 === bK ? void 0 : bK[KO]) && void 0 !== pO ? pO : null, eO)
          })));
          OO.atlasCount = lO.length, OO.MeO = lO[0].layerWidth, OO.atlasLayers = lO[0].layers, KO.animDataPerTex && (OO.nextFrameAtlases = (0, NO.j)(KO.animDataPerTex, OO.atlasLayers, OO.atlasCount), pO.push({
            buffer: wb(this.device, Float32Array.from(KO.animDataPerTex), GPUBufferUsage.STORAGE, "terrain-anim")
          })), pO.push(this.sampler);
          for (const OO of lO) pO.push(OO.texture.createView({
            dimension: "2d-array"
          }))
        } else if ("single" === OO.texture) {
          const {
            url: KO
          } = OO.model.diffuseTexture.source, {
            pixels: XO,
            width: bK,
            height: eO
          } = await Hb(KO);
          pO.push(this.sampler), pO.push(re(this.device, XO, bK, eO, 1, `terrain-${KO}`).createView({
            dimension: "2d"
          }))
        }
        const XO = this.materialLayout(this.programKey(OO, !1));
        OO.bindGroupLayout = XO, OO.bindGroup = this.device.createBindGroup({
          label: `terrain-material-${OO.model.name}`,
          layout: XO,
          entries: pO.map(((OO, KO) => ({
            binding: KO,
            resource: OO
          })))
        })
      }
      programKey(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        const XO = pO ? pO.lighting : this.lighting,
          bK = pO ? pO.hX : this.hX,
          eO = {
            texture: OO.texture,
            atlasCount: OO.atlasCount,
            MeO: OO.MeO,
            atlasLayers: OO.atlasLayers,
            nextFrameAtlases: OO.nextFrameAtlases,
            animated: OO.animated,
            alphaTest: OO.model.transparencyMode === yK.p.alphaTest,
            lighting: XO,
            dirLightCount: pO ? pO.dirLightCount : this.dirLightCount,
            packed: KO
          };
        if (!bK) return eO;
        const lO = this.shaderPackFields(OO, bK),
          vK = "atlas" === OO.texture && OO.model.transparencyMode === yK.p.opaque && eX(lO.packVariant);
        return {
          ...eO,
          ...lO,
          alphaTest: eO.alphaTest || vK
        }
      }
      shaderPackFields(OO, KO) {
        return OO.customRenderMat ? XX : function(OO, KO) {
          if (!OO) return XX;
          const pO = OO.defineFor(KO ? "liquid" : "terrain");
          return 0 === pO ? XX : {
            packVariant: pO,
            liquid: KO
          }
        }(KO, OO.liquid)
      }
      isBlended(OO) {
        return OO.model.transparencyMode === yK.p.alphaBlend
      }
      shaderModule(OO, KO) {
        let pO = this.modules.get(OO);
        return pO || (pO = this.device.createShaderModule({
          label: KO,
          code: OO
        }), this.modules.set(OO, pO)), pO
      }
      pipelineFor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        if (!OO.bindGroupLayout) return null;
        const bK = this.programKey(OO, KO);
        if (!XO) return this.pipelineOf(OO, bK, pO);
        const eO = {
            ...bK,
            resting: XO
          },
          lO = this.pipelineId(OO, eO, pO),
          vK = this.pipelines.get(lO);
        if (vK) return vK;
        const CO = this.pipelineOf(OO, bK, pO);
        return CO && void 0 === vK && this.startPipeline(lO, OO, eO, pO), CO
      }
      pipelineOf(OO, KO, pO) {
        const XO = this.pipelineId(OO, KO, pO),
          bK = this.pipelines.get(XO);
        return void 0 !== bK ? bK : (this.startPipeline(XO, OO, KO, pO), null)
      }
      pipelineId(OO, KO, pO) {
        return xC(KO, this.isBlended(OO), OO.model.backFaceCulling, pO)
      }
      pipelineBuild(OO, KO, pO) {
        var XO;
        const bK = this.pipelineId(OO, KO, pO);
        return null !== (XO = this.builds.get(bK)) && void 0 !== XO ? XO : this.startPipeline(bK, OO, KO, pO)
      }
      startPipeline(OO, KO, pO, XO) {
        var bK;
        this.pipelines.set(OO, null);
        const eO = jb(pO),
          lO = this.isBlended(KO),
          vK = this.shadowMask && XO._depthStencilFormat ? function(OO, KO, pO, XO) {
            if (void 0 === OO.packVariant || OO.liquid || KO) return "none";
            const bK = (0, uK.e)(OO.packVariant);
            return null === bK || void 0 === bK || !bK.sunShadow || !mX(bK, pO) || bK.discards || OO.alphaTest && eX(OO.packVariant) ? "none" : XO ? "edge" : "plain"
          }(pO, lO, !!this.sunShadow, XO._sampleCount > 1) : "none";
        let CO;
        try {
          CO = YX(pO, !!this.sunShadow, vK)
        } catch (LO) {
          if (!hX(pO)) throw LO;
          return this.failedPackBuild(OO, pO, eO, LO)
        }
        const hO = this.shaderModule(CO, eO),
          DO = [];
        pO.packed || (DO.push(function(OO, KO) {
          const pO = [{
            shaderLocation: cC.position,
            offset: IK.e.yb,
            format: "float32x3"
          }, {
            shaderLocation: cC.normal,
            offset: IK.e.normalOffset,
            format: "snorm8x4"
          }, {
            shaderLocation: cC.color,
            offset: IK.e.colorOffset,
            format: "unorm8x4"
          }];
          return OO && pO.push({
            shaderLocation: cC.uv,
            offset: IK.e.uvOffset,
            format: "float32x2"
          }), KO && pO.push({
            shaderLocation: cC.blockFlagWords,
            offset: IK.e.normalOffset,
            format: "uint32x2"
          }), {
            arrayStride: IK.e.strideWithoutAtlas,
            stepMode: "vertex",
            attributes: pO
          }
        }("none" !== pO.texture, hX(pO))), pO.lighting && DO.push(Zv));
        const MO = KO.model.backFaceCulling,
          aK = {
            label: eO,
            layout: this.device.createPipelineLayout({
              bindGroupLayouts: [this.sceneLayout, this.frameLayout, KO.bindGroupLayout, ...Je(this.device, pO, !!this.sunShadow, "none" !== vK)]
            }),
            vertex: {
              module: hO,
              entryPoint: "mainVertex",
              buffers: DO
            },
            fragment: tK({
              module: hO,
              entryPoint: "mainFragment"
            }, XO, lO ? Gv : null),
            depthStencil: XO._depthStencilFormat ? {
              format: XO._depthStencilFormat,
              depthCompare: null !== (bK = XO._depthCompare) && void 0 !== bK ? bK : pK,
              depthWriteEnabled: !0
            } : void 0,
            multisample: {
              count: XO._sampleCount
            },
            primitive: {
              topology: "triangle-list",
              frontFace: "ccw",
              cullMode: MO ? "back" : "none"
            }
          },
          oO = pO.resting ? 0 : 1;
        this.compiling += oO;
        const FO = "none" === vK ? this.device.createRenderPipelineAsync(aK) : this.startMaskPipelines(hO, aK, "edge" === vK);
        FO.then((KO => {
          this.compiling -= oO, this.pipelines.set(OO, KO)
        }), (OO => {
          this.compiling -= oO, console.error(`Lite terrain pipeline ${eO} failed`, OO), rC(pO, eO, hO, OO)
        }));
        const VO = {
          name: eO,
          module: hO,
          built: FO
        };
        return this.builds.set(OO, VO), VO
      }
      startMaskPipelines(OO, KO, pO) {
        const XO = KO.depthStencil,
          bK = this.device.createRenderPipelineAsync(pO ? KO : {
            ...KO,
            depthStencil: {
              ...XO,
              depthCompare: "equal",
              depthWriteEnabled: !1
            }
          }),
          eO = this.device.createRenderPipelineAsync({
            ...KO,
            label: `${KO.label}-prepass`,
            fragment: {
              module: OO,
              entryPoint: "prepassFragment",
              targets: [{
                format: Nv
              }]
            },
            multisample: {
              count: 1
            }
          });
        return Promise.all([bK, eO]).then((OO => {
          let [KO, pO] = OO;
          return this.prepassOf.set(KO, pO), this.maskPipelines++, KO
        }))
      }
      failedPackBuild(OO, KO, pO, XO) {
        console.error(`Lite terrain pipeline ${pO} failed`, XO), rC(KO, pO, null, XO);
        const bK = Promise.reject(XO);
        bK.catch((() => {}));
        const eO = {
          name: pO,
          module: null,
          built: bK
        };
        return this.builds.set(OO, eO), eO
      }
      checkShaderPack(OO) {
        return Yv(OO, {
          device: this.device,
          target: this.target,
          material: OO => this.materialFor(OO),
          programKey: (OO, KO, pO) => this.programKey(OO, KO, pO),
          pipelineBuild: (OO, KO, pO) => this.pipelineBuild(OO, KO, pO)
        })
      }
      createBinding(OO, KO, pO) {
        return this.target = KO, {
          renderable: OO,
          pipeline: lK(this.device, KO),
          draw: OO => {
            this.geometry.setDrawing(!0);
            try {
              return pO ? this.drawTransparent(OO, KO) : this.drawOpaque(OO, KO)
            } finally {
              this.geometry.setDrawing(!1)
            }
          }
        }
      }
      prepare(OO, KO) {
        var pO, XO, bK, eO;
        const {
          ap: lO
        } = OO;
        this.lighting = OO.Xe;
        const vK = (0, Mv.y)(KO);
        this.dirLightCount = Math.min(vK, 4), this.hX = null !== (pO = lO.hX) && void 0 !== pO ? pO : null, vK > 4 && this.warnOnce("dirLights", "Lite terrain lights with the first 4 directional lights only."), this.writeFrameUniforms(OO, KO), this.animateMaterials(KO.animTick);
        const CO = lO.jp,
          hO = CO[0] !== this.originOffset[0] || CO[1] !== this.originOffset[1] || CO[2] !== this.originOffset[2];
        hO && (this.originOffset[0] = CO[0], this.originOffset[1] = CO[1], this.originOffset[2] = CO[2]);
        const DO = KO.eye;
        this.eye[0] = DO[0], this.eye[1] = DO[1], this.eye[2] = DO[2], this.writeShaderPackInputs();
        const MO = KO.projectionMatrix,
          aK = 0 === MO[15];
        let oO = 0;
        (hO || this.eye[0] !== this.faceEye[0] || this.eye[1] !== this.faceEye[1] || this.eye[2] !== this.faceEye[2]) && (this.faceEpoch++, this.faceEye[0] = this.eye[0], this.faceEye[1] = this.eye[1], this.faceEye[2] = this.eye[2]);
        let {
          faceEpoch: FO
        } = this;
        vp(this.transparentRenderable._worldCenter, KO, bp), this.resetBatches(aK), this.transparent.length = 0, this.unlit.length = 0;
        const VO = lO.lK.ovO,
          LO = VO / 2 * Math.sqrt(3);
        let QO = 0;
        const zK = !!this.hX && bb(this.hX.defineFor("liquid"));
        let AO = !1;
        const fO = null !== (XO = null === (bK = lO.EQ) || void 0 === bK ? void 0 : bK.visibility) && void 0 !== XO ? XO : null,
          dO = this.visCull && aK && 0 === this.compiling && null !== fO && lO.lK.KDO[0] >= this.visCullMinDistance ? this.target : null,
          TO = this.visPassable,
          NO = this.visCandidates,
          IO = this.visCandidateBatches;
        TO.clear(), this.visBatchDraws.clear(), this.visDrawsMaterial = null;
        let yK = 0;
        this.visCulledParts = 0, this.visCulledTriangles = 0;
        let gK = 0;
        const uO = (OO, pO) => {
          if (!pO) return this.transparent.push(OO), void(gK += 2 * OO.faceCount);
          if (null !== OO.faceGroups && pO.faceCull) {
            if (0 === oO && (oO = (0, mC.c)(MO, KO.renderWidth, KO.renderHeight), oO !== this.faceFocalPx && (this.faceFocalPx = oO, FO = ++this.faceEpoch)), OO.faceEpoch !== FO) {
              OO.faceEpoch = FO;
              const KO = Math.sqrt(OO.distance) + LO,
                pO = (0, mC.h)(OO.planePX, OO.planeNX, OO.planePY, OO.planeNY, OO.planePZ, OO.planeNZ, this.eye[0] - (OO.origin[0] - this.originOffset[0]), this.eye[1] - (OO.origin[1] - this.originOffset[1]), this.eye[2] - (OO.origin[2] - this.originOffset[2]), (0, mC.d)(KO, oO));
              pO !== OO.faceMask && this.chooseFaceRanges(OO, OO.faceGroups, pO)
            }
            if (0 === OO.rangeCount) return
          } else - 1 !== OO.faceMask && this.drawWhole(OO);
          pO.meshes.push(OO), gK += 2 * ((OO.rangeCount > 0 ? OO.count0 : 0) + (OO.rangeCount > 1 ? OO.count1 : 0))
        };
        for (const jK of this.chunks.values()) {
          hO && this.writeSlot(jK);
          const OO = jK.mesh.visibility;
          OO !== jK.visibility && (jK.visibility = OO, this.slots.setVisibility(jK.slot, OO));
          const {
            material: pO
          } = jK;
          this.geometry.lost(jK) && performance.now() >= jK.lostRetryAt && this.remeshLost(lO, jK);
          const XO = !(null === pO || void 0 === pO || !pO.bindGroup) && this.geometry.backed(jK),
            bK = XO && this.lighting && !jK.vertices.page.twin;
          if (dO && (Number.isNaN(jK.key) && (jK.ci = Math.floor(jK.origin[0] / VO), jK.cj = Math.floor(jK.origin[1] / VO), jK.ck = Math.floor(jK.origin[2] / VO), jK.key = (0, Hv.g)(jK.ci, jK.cj, jK.ck)), (!XO || OO < 1 || bK || !this.batchDraws(pO, jK.packed, dO)) && this.visSeeThrough(jK, dO) && TO.add(jK.key)), !XO) continue;
          bK || (jK.lostRemeshes = 0);
          const eO = jK.origin[0] - this.originOffset[0],
            vK = jK.origin[1] - this.originOffset[1],
            CO = jK.origin[2] - this.originOffset[2];
          if (!(0, Ul.c)(KO.frustum, eO, vK, CO, VO)) continue;
          const DO = eO + VO / 2 - this.eye[0],
            MO = vK + VO / 2 - this.eye[1],
            oO = CO + VO / 2 - this.eye[2];
          if (jK.distance = DO * DO + MO * MO + oO * oO, this.lighting && !jK.lit && (QO = Math.max(QO, jK.vertexCount), this.unlit.push(jK)), bK) continue;
          const FO = this.isBlended(pO) ? null : this.batchFor(pO, jK.packed, jK.vertices.page, 1 === OO, aK);
          dO ? (NO[yK] = jK, IO[yK++] = FO) : uO(jK, FO)
        }
        const EO = dO ? this.sweepVisibility(OO, KO, fO) : null;
        null === (eO = (0, jl.u)(lO)) || void 0 === eO || eO.update(KO.frustum, this.originOffset, VO, EO);
        for (let jK = 0; jK < yK; jK++) {
          const OO = NO[jK];
          !EO || EO.isDrawn(OO.ci, OO.cj, OO.ck) ? uO(OO, IO[jK]) : (this.visCulledParts++, this.visCulledTriangles += 2 * OO.faceCount)
        }
        for (const jK of this.transparent) AO ||= zK && jK.material.liquid && !jK.material.customRenderMat;
        this.submittedTriangles = gK, EO && this.visCheck && ++this.visCheckFrame >= 60 && (this.visCheckFrame = 0, this.runVisCheck(OO, KO, EO)), this.slots.flush(), this.sceneDepth ? this.sceneDepth.setWanted(AO) : AO && this.warnOnce("sceneDepth", "Lite: a shader pack reads scene depth on a page that didn't turn it on, so liquids find nothing behind them"), this.lighting && QO > 0 && this.geometry.lightFullSky(this.unlit, QO);
        for (const jK of this.opaqueBatches) this.chunkSorter.sort(jK.meshes, 1) || jK.meshes.sort(nv);
        this.orderBatches(), this.chunkSorter.sort(this.transparent, -1) || this.transparent.sort(Wv)
      }
      sweepVisibility(OO, KO, pO) {
        const {
          lK: XO
        } = OO.ap, bK = XO.ovO, eO = this.visPassable, lO = this.eye[0] + this.originOffset[0], vK = this.eye[1] + this.originOffset[1], CO = this.eye[2] + this.originOffset[2];
        if (!pO.eyeClear(lO, vK, CO, KO.near, KO.projectionMatrix, XO)) return null;
        const [hO, DO] = XO.KDO, MO = pO.update(lO, vK, CO, bK, hO, DO, eO);
        return this.visSweeps = pO.sweeps, MO ? pO : null
      }
      visSeeThrough(OO, KO) {
        const {
          material: pO
        } = OO;
        return (!pO || !this.isBlended(pO)) && (OO.mesh.visibility < 1 || !(null !== pO && void 0 !== pO && pO.bindGroup) || OO.faceCount > 0 && (!this.geometry.backed(OO) || this.lighting && !OO.vertices.page.twin) || !this.batchDraws(pO, OO.packed, KO))
      }
      batchDraws(OO, KO, pO) {
        var XO;
        const bK = KO ? 2 : 0;
        if (OO === this.visDrawsMaterial && function(OO, KO) {
            return 0 !== (OO & 1 << KO)
          }(this.visDrawsBits, bK)) return 0 !== (this.visDrawsBits & 2 << bK);
        let eO = null !== (XO = this.visBatchDraws.get(OO)) && void 0 !== XO ? XO : 0;
        if (!(eO & 1 << bK)) {
          eO |= 1 << bK | (!!OO.bindGroupLayout && this.canDraw(OO, KO) && !!this.pipelines.get(this.pipelineId(OO, this.programKey(OO, KO), pO)) ? 2 << bK : 0), this.visBatchDraws.set(OO, eO)
        }
        return this.visDrawsMaterial = OO, this.visDrawsBits = eO, 0 !== (eO & 2 << bK)
      }
      runVisCheck(OO, KO, pO) {
        const {
          ap: XO
        } = OO, {
          lK: bK
        } = XO, eO = bK.ovO, lO = new Set;
        for (const oO of this.chunks.values()) lO.add(oO.key);
        const vK = fb.Matrix.FromArray(KO.viewProjectionMatrix).invert(),
          [CO, hO, DO] = this.originOffset,
          MO = new fb.WX,
          aK = function(OO, KO, pO, XO) {
            const bK = new Set;
            for (let eO = 0; eO < 27; eO++)
              for (let lO = 0; lO < 48; lO++) {
                const vK = pO((lO + .5) / 48 * 2 - 1, (eO + .5) / 27 * 2 - 1);
                Rv(OO, KO, [vK[0] - KO[0], vK[1] - KO[1], vK[2] - KO[2]], XO, bK)
              }
            return bK
          }({
            RXO: (OO, KO, pO) => bK.RXO(OO, KO, pO),
            occluders: pO.occluders,
            opaque: pO.opaque,
            SX: eO,
            isDrawn: (OO, KO, XO) => pO.isDrawn(OO, KO, XO),
            hasParts: (OO, KO, pO) => lO.has((0, Hv.g)(OO, KO, pO))
          }, [this.eye[0] + CO, this.eye[1] + hO, this.eye[2] + DO], ((OO, KO) => (fb.WX.TransformCoordinatesFromFloatsToRef(OO, KO, .5, vK, MO), [MO.x + CO, MO.y + hO, MO.z + DO])), (bK.KDO[0] + 1) * eO);
        this.visViolations = aK.size;
        for (const oO of aK) this.warnOnce(`vis:${oO}`, `Lite terrain cave culling skipped chunk ${oO}, which a ray from the eye reaches.`)
      }
      writeShaderPackInputs() {
        var OO;
        null !== (OO = this.hX) && void 0 !== OO && OO.isRunning() && (this.shaderPackInputs ??= new cl(this.device, this.hX.textureLayers(), this.sunShadow), this.shaderPackInputs.write(this.hX, this.eye, this.lighting))
      }
      bindShaderPackInputs(OO, KO, pO) {
        var XO, bK, eO, lO;
        let vK = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        const {
          packVariant: CO
        } = this.shaderPackFields(KO, pO);
        if (void 0 === CO) return;
        this.shaderPackInputs || (this.shaderPackInputs = new cl(this.device, pO.textureLayers(), this.sunShadow), this.shaderPackInputs.write(pO, this.eye, this.lighting));
        const hO = bb(CO) ? null !== (XO = null === (bK = this.sceneDepth) || void 0 === bK ? void 0 : bK.view) && void 0 !== XO ? XO : this.standIn() : null,
          DO = vK ? null !== (eO = null === (lO = this.shadowMask) || void 0 === lO ? void 0 : lO.view) && void 0 !== eO ? eO : this.standIn() : null;
        this.shaderPackInputs.bind(OO, hO, Se(CO, !!this.sunShadow), DO)
      }
      standIn() {
        return this.depthStandIn ??= this.device.createTexture({
          label: "scene-depth-stand-in",
          size: [1, 1],
          format: "r32float",
          usage: GPUTextureUsage.TEXTURE_BINDING
        }).createView()
      }
      sunShadowGroup() {
        var OO, KO;
        return null !== (OO = null === (KO = this.shaderPackInputs) || void 0 === KO ? void 0 : KO.bindGroupFor(null, !0)) && void 0 !== OO ? OO : null
      }
      resetBatches(OO) {
        const KO = this.opaqueBatches;
        let pO = 0;
        for (const XO of KO) XO.meshes.length > 0 && (XO.meshes.length = 0, XO.faceCull = this.batchFaceCull(XO.material, OO), KO[pO++] = XO);
        KO.length = pO
      }
      orderBatches() {
        const OO = this.opaqueBatches;
        for (let KO = 0; KO < OO.length; KO++) {
          const pO = OO[KO];
          pO.group = KO;
          for (let XO = 0; XO < KO; XO++) {
            const KO = OO[XO];
            if (KO.material === pO.material && KO.packed === pO.packed) {
              pO.group = KO.group;
              break
            }
          }
          pO.nearest = pO.meshes.length > 0 ? pO.meshes[0].distance : 1 / 0
        }
        OO.sort(Sv)
      }
      batchFor(OO, KO, pO, XO, bK) {
        for (const lO of this.opaqueBatches)
          if (lO.material === OO && lO.packed === KO && lO.page === pO && lO.resting === XO) return lO;
        const eO = {
          material: OO,
          packed: KO,
          page: pO,
          resting: XO,
          meshes: [],
          group: 0,
          nearest: 0,
          faceCull: this.batchFaceCull(OO, bK)
        };
        return this.opaqueBatches.push(eO), eO
      }
      batchFaceCull(OO, KO) {
        return !(!KO || !(0, Pv.k)(OO.model)) && (!this.hX || ! function(OO) {
          var KO;
          return !(null === (KO = (0, uK.e)(OO)) || void 0 === KO || !KO.movesVertices)
        }(this.shaderPackFields(OO, this.hX).packVariant))
      }
      writeFrameUniforms(OO, KO) {
        const pO = this.frameUniforms,
          XO = DX;
        if ((0, Mv.C)(OO, pO), pO[XO.fogInfos] = KO.fogEnabled ? KO.fogMode : 0, pO[XO.fogInfos + 1] = KO.fogStart, pO[XO.fogInfos + 2] = KO.fogEnd, pO[XO.fogInfos + 3] = KO.fogDensity, pO.set(KO.fogColour, XO.fogColour), pO[XO.outputHeight] = KO.renderHeight, pO.set(KO.ambientColour, XO.sceneAmbient), (0, Mv.u)(KO, this.dirLightCount, this.dirLightUniforms), !this.aoLevelsWritten) {
          const KO = (0, aC.i)(OO.ze, OO.BX, OO.ZX);
          for (let OO = 0; OO < 4; OO++) pO[XO.aoLevels + OO] = KO[OO] / 255;
          this.aoLevelsWritten = !0
        }
        this.device.queue.writeBuffer(this.frameBuffer, 0, pO)
      }
      animateMaterials(OO) {
        const KO = ab.anim;
        for (const pO of this.materials.values()) pO.animated && (pO.uniformData[KO] = OO, this.device.queue.writeBuffer(pO.uniformBuffer, 4 * KO, pO.uniformData, KO, 1))
      }
      canDraw(OO, KO) {
        return !("atlas" === OO.texture && !KO) || (this.warnOnce(`stride:${OO.id}`, `Lite terrain: material "${OO.model.name}" samples the atlas but its mesh has no quad records, which hold its atlas indices.`), !1)
      }
      drawOpaque(OO, KO) {
        let pO = 0;
        OO.setBindGroup(1, this.frameBindGroup);
        for (const XO of this.opaqueBatches) {
          if (!XO.meshes.length || !this.canDraw(XO.material, XO.packed)) continue;
          const bK = this.pipelineFor(XO.material, XO.packed, KO, XO.resting);
          bK && (OO.setPipeline(bK), OO.setBindGroup(2, XO.material.bindGroup), this.hX && this.bindShaderPackInputs(OO, XO.material, this.hX, this.prepassOf.has(bK)), pO += this.drawBatch(OO, XO))
        }
        return pO
      }
      get readsMask() {
        return this.maskPipelines > 0
      }
      drawPrepass(OO, KO, pO) {
        const XO = this.target,
          bK = this.hX;
        if (!XO || !bK || 0 === this.maskPipelines) return 0;
        let eO = 0,
          lO = null;
        this.geometry.setDrawing(!0);
        try {
          for (const vK of this.opaqueBatches) {
            if (!vK.meshes.length || !this.canDraw(vK.material, vK.packed)) continue;
            const CO = this.pipelineFor(vK.material, vK.packed, XO, vK.resting),
              hO = CO && this.prepassOf.get(CO);
            hO && (lO || (lO = OO.beginRenderPass(KO), lO.setBindGroup(0, pO), lO.setBindGroup(1, this.frameBindGroup)), lO.setPipeline(hO), lO.setBindGroup(2, vK.material.bindGroup), this.bindShaderPackInputs(lO, vK.material, bK, !0), eO += this.drawBatch(lO, vK))
          }
        } finally {
          var vK;
          null === (vK = lO) || void 0 === vK || vK.end(), this.geometry.setDrawing(!1)
        }
        return eO
      }
      drawBatch(OO, KO) {
        let pO = 0;
        for (const XO of KO.meshes) {
          const {
            rangeCount: KO
          } = XO;
          KO > 0 && (pO += this.geometry.draw(OO, XO, this.lighting, XO.first0, XO.count0), KO > 1 && (pO += this.geometry.draw(OO, XO, this.lighting, XO.first1, XO.count1)))
        }
        return pO
      }
      drawTransparent(OO, KO) {
        let pO = 0,
          XO = null,
          bK = null;
        OO.setBindGroup(1, this.frameBindGroup);
        for (const eO of this.transparent) {
          const lO = eO.material;
          if (!this.canDraw(lO, eO.packed)) continue;
          const vK = this.pipelineFor(lO, eO.packed, KO);
          vK && (vK !== XO && (OO.setPipeline(vK), XO = vK, this.hX && this.bindShaderPackInputs(OO, lO, this.hX)), lO !== bK && (OO.setBindGroup(2, lO.bindGroup), bK = lO), pO += this.geometry.draw(OO, eO, this.lighting))
        }
        return pO
      }
    }

    function xC(OO, KO, pO, XO) {
      return `${jb(OO)}|${OO.atlasLayers}|${OO.MeO}|${KO}|${pO}|${XO._colorFormat}|${XO._depthStencilFormat}|${XO._sampleCount}`
    }

    function nv(OO, KO) {
      return OO.distance - KO.distance
    }

    function Wv(OO, KO) {
      return KO.distance - OO.distance
    }
    class tC {
      constructor() {
        this.left = []
      }
      sort(OO, KO) {
        for (let pO = 0; pO < OO.length; pO++) {
          const KO = OO[pO].distance;
          if (KO - KO !== 0) return !1
        }
        return this.sortRange(OO, 0, OO.length, KO), !0
      }
      sortRange(OO, KO, pO, XO) {
        if (pO - KO <= 16) {
          for (let bK = KO + 1; bK < pO; bK++) {
            const pO = OO[bK],
              eO = XO * pO.distance;
            let lO = bK - 1;
            for (; lO >= KO && XO * OO[lO].distance > eO; lO--) OO[lO + 1] = OO[lO];
            OO[lO + 1] = pO
          }
          return
        }
        const bK = KO + pO >>> 1;
        if (this.sortRange(OO, KO, bK, XO), this.sortRange(OO, bK, pO, XO), XO * OO[bK - 1].distance <= XO * OO[bK].distance) return;
        const {
          left: eO
        } = this, lO = bK - KO;
        for (let DO = 0; DO < lO; DO++) eO[DO] = OO[KO + DO];
        let vK = 0,
          CO = bK,
          hO = KO;
        for (; vK < lO && CO < pO;) OO[hO++] = XO * OO[CO].distance < XO * eO[vK].distance ? OO[CO++] : eO[vK++];
        for (; vK < lO;) OO[hO++] = eO[vK++]
      }
    }
    const kC = Math.ceil(102);

    function Uv(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : KO;
      const eO = Math.min(KO, pO),
        lO = new Uint32Array(Op(XO));
      for (let vK = 0; vK < XO; vK++) {
        const KO = Math.floor(vK * eO / XO),
          pO = Math.max(KO + 1, Math.floor((vK + 1) * eO / XO));
        for (let CO = 0; CO < XO; CO++) {
          const hO = Math.floor(CO * eO / XO),
            DO = Math.max(hO + 1, Math.floor((CO + 1) * eO / XO));
          let MO = 0;
          for (let XO = KO; XO < pO; XO++)
            for (let KO = hO; KO < DO; KO++) OO[XO * bK + KO] >= kC && MO++;
          if (2 * MO >= (pO - KO) * (DO - hO)) {
            const OO = CO + XO * vK;
            lO[OO >>> 5] |= 1 << (31 & OO)
          }
        }
      }
      return lO
    }

    function OC(OO) {
      return Math.max(1, Math.min(16, OO))
    }
    class KC {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : console.warn;
        this.sink = OO, this.loadTexture = KO, this.warn = pO, this.blockCaster = new Uint16Array(1), this.builtVersion = -1, this.byKey = new Map, this.nextCaster = 1, this.nextMaskWord = 0, this.warned = new Set, this.textures = new Map, this.loads = [], this.pending = Promise.resolve(), this.planesLoading = 0
      }
      update(OO, KO) {
        return (OO.npO !== this.builtVersion || this.blockCaster.length !== KO) && (this.build(OO, KO), !0)
      }
      build(OO, KO) {
        this.builtVersion = OO.npO;
        const pO = new Uint16Array(KO),
          XO = new Map;
        for (let bK = 1; bK < KO; bK++) {
          const KO = this.classify(OO, bK, XO);
          if (null === KO || KO === nK) {
            pO[bK] = null === KO ? 0 : nK;
            continue
          }
          let eO = this.byKey.get(KO.key);
          void 0 === eO && (eO = this.allocate(KO), this.byKey.set(KO.key, eO)), pO[bK] = eO
        }
        this.blockCaster = pO, this.pending = Promise.all(this.loads).then((() => {}))
      }
      option(OO, KO) {
        const pO = OO.YeO[KO];
        if ("function" !== typeof pO) return pO;
        try {
          return pO()
        } catch (XO) {
          return this.warnOnce(`Sun shadows: no caster option for block ${KO}: ${XO instanceof Error?XO.message:String(XO)}`), null
        }
      }
      classify(OO, KO, pO) {
        const XO = this.option(OO, KO);
        if ("none" === XO) return null;
        if (XO && XO.planes.length > 0) {
          const OO = XO.planes.slice(0, 4);
          return {
            kind: "planes",
            key: `planes:${JSON.stringify(OO)}`,
            planes: OO
          }
        }
        if (OO.Vp[KO]) return null;
        const bK = OO.Qp[KO] ? OO.tXO(KO) : null;
        if (bK && bK.length >= 6) {
          const OO = function(OO) {
            const KO = new Uint32Array(16);
            for (let pO = 0; pO + 6 <= OO.length; pO += 6) {
              const XO = [0, 1, 2].map((KO => Math.max(0, Math.ceil(8 * OO[pO + KO] - .5)))),
                bK = [0, 1, 2].map((KO => Math.min(7, Math.floor(8 * OO[pO + KO + 3] - .5))));
              for (let OO = XO[2]; OO <= bK[2]; OO++)
                for (let pO = XO[1]; pO <= bK[1]; pO++)
                  for (let eO = XO[0]; eO <= bK[0]; eO++) {
                    const XO = eO + 8 * (pO + 8 * OO);
                    KO[XO >>> 5] |= 1 << (31 & XO)
                  }
            }
            return KO
          }(bK);
          return function(OO) {
            return OO.every((OO => 4294967295 === OO))
          }(OO) ? nK : OO.every((OO => 0 === OO)) ? null : {
            kind: "shape",
            key: `shape:${OO.join(",")}`,
            mask: OO
          }
        }
        if (OO.vbO[KO] || !OO.Ab[KO]) return null;
        const eO = [0, 1, 2, 3, 4, 5].map((XO => {
          const bK = OO.fb[6 * KO + XO];
          let eO = pO.get(bK);
          return void 0 === eO && (eO = function(OO) {
            if (!OO || OO.ie) return null;
            const {
              DeO: KO,
              MeO: pO,
              heO: XO
            } = OO;
            if (!KO || !pO || !(pO > 0) || void 0 === XO || !(XO >= 0)) return null;
            const bK = KO[0],
              eO = pO * pO * 4;
            if (!bK || bK.byteLength < eO) return null;
            const lO = Math.floor(bK.byteLength / eO),
              vK = KO[Math.floor(XO / lO)];
            if (!vK) return null;
            const CO = new Uint8Array(vK.buffer, vK.byteOffset, vK.byteLength),
              hO = XO % lO * eO;
            if (hO + eO > CO.length) return null;
            const DO = new Uint8Array(pO * pO);
            let MO = !1;
            for (let aK = 0; aK < DO.length; aK++) DO[aK] = CO[hO + 4 * aK + 3], MO ||= DO[aK] < kC;
            return MO ? {
              alpha: DO,
              width: pO
            } : null
          }(OO.Yb(bK)), pO.set(bK, eO)), eO
        }));
        if (eO.every((OO => null === OO))) return nK;
        const lO = OC(Math.max(...eO.map((OO => {
            var KO;
            return null !== (KO = null === OO || void 0 === OO ? void 0 : OO.width) && void 0 !== KO ? KO : 1
          })))),
          vK = new Uint32Array(Op(lO)).fill(4294967295),
          CO = eO.map((OO => null === OO ? vK : Uv(OO.alpha, OO.width, OO.width, lO)));
        return {
          kind: "cutout",
          key: `cutout:${lO}:${CO.map((OO=>OO.join(","))).join("|")}`,
          size: lO,
          faces: CO
        }
      }
      allocate(OO) {
        if (this.nextCaster >= Kp) return this.warnOnce("Sun shadows: more than 8191 casters; the rest cast nothing."), 0;
        const KO = this.nextCaster++;
        if (this.writeCaster(KO, WK, 0, 0, 0), "shape" === OO.kind) {
          const pO = this.allocateMask(OO.mask.length);
          pO >= 0 && (this.sink(pO, OO.mask), this.writeCaster(KO, tp, pO, 0, 8))
        } else if ("cutout" === OO.kind) {
          const pO = Op(OO.size),
            XO = this.allocateMask(6 * pO);
          if (XO >= 0) {
            const bK = new Uint32Array(6 * pO);
            OO.faces.forEach(((OO, KO) => {
              bK.set(OO, KO * pO)
            })), this.sink(XO, bK), this.writeCaster(KO, UK, XO, 0, OO.size)
          }
        } else this.planesLoading++, this.loads.push(this.loadPlanes(KO, OO.planes).finally((() => {
          this.planesLoading--
        })));
        return KO
      }
      async loadPlanes(OO, KO) {
        const pO = await Promise.all(KO.map((OO => this.texture(OO.texture))));
        if (pO.some((OO => null === OO))) return;
        const XO = pO,
          bK = OC(Math.max(...XO.map((OO => Math.min(OO.width, OO.height))))),
          eO = Op(bK),
          lO = this.allocateMask(KO.length * (4 + eO));
        if (lO < 0) return;
        const vK = new Uint32Array(KO.length * (4 + eO)),
          CO = 4 * KO.length;
        KO.forEach(((OO, KO) => {
          const pO = lO + CO + KO * eO;
          vK.set(function(OO, KO) {
            const [pO, XO] = OO.tangent, bK = Math.hypot(pO, XO) || 1, eO = pO / bK, lO = XO / bK, vK = OO.centre[0] * lO - OO.centre[1] * eO, CO = new Uint32Array(4);
            return new Float32Array(CO.buffer, 0, 3).set([eO, lO, vK]), CO[3] = KO, CO
          }(OO, pO), 4 * KO), vK.set(Uv(XO[KO].alpha, XO[KO].width, XO[KO].height, bK), CO + KO * eO)
        })), this.sink(lO, vK), this.writeCaster(OO, kp, lO, KO.length, bK)
      }
      texture(OO) {
        let KO = this.textures.get(OO);
        return KO || (KO = this.loadTexture(OO).catch((KO => (this.warn(`Sun shadows: no mask for ${OO}: ${KO instanceof Error?KO.message:String(KO)}`), null))), this.textures.set(OO, KO)), KO
      }
      allocateMask(OO) {
        if (this.nextMaskWord + OO > pp) return this.warnOnce("Sun shadows: casters' masks are over 262144 words; the rest cast nothing."), -1;
        const KO = 32768 + this.nextMaskWord;
        return this.nextMaskWord += OO, KO
      }
      writeCaster(OO, KO, pO, XO, bK) {
        this.sink(0 + 4 * OO, Uint32Array.of(KO, pO, XO, bK))
      }
      warnOnce(OO) {
        this.warned.has(OO) || (this.warned.add(OO), this.warn(OO))
      }
    }
    var pC = pO(36087);

    function XC(OO) {
      return !OO.sb && !OO.BDO && !OO.hb
    }

    function bh() {
      return {
        bricks: new Uint32Array(SK),
        cells: new Uint16Array(32768),
        special: new Uint8Array(HK)
      }
    }
    class eC {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : console.warn;
        this.casters = OO, this.writeVoxels = KO, this.writePool = pO, this.warn = XO, this.eyeChunk = null, this.slotChunk = new Array(wK).fill(null), this.slotVersion = new Float64Array(wK).fill(-1), this.slotPool = new Array(wK).fill(null), this.starved = new Uint8Array(wK), this.queue = [], this.queued = new Uint8Array(wK), this.queueSorted = !0, this.freePool = new Uint32Array(Xp), this.freeCount = Xp, this.casterTable = null, this.warnedPool = !1, this.scratch = bh(), this.victimScratch = bh(), this.record = new Uint32Array(4), this.entry = new Uint32Array(32), this.records = new Int32Array(4 * wK), this.windowTopStale = !0, this.windowTop = new Uint32Array(1), this.encoded = null;
        for (let bK = 0; bK < Xp; bK++) this.freePool[bK] = 65535 - bK
      }
      get queuedCount() {
        return this.queue.length
      }
      get poolInUse() {
        return Xp - this.freeCount
      }
      chunkAdded(OO) {
        if (null === this.eyeChunk || !this.inRadius(OO.i, OO.j, OO.k)) return;
        const KO = GK(OO.i, OO.j, OO.k);
        this.slotChunk[KO] = OO, this.slotVersion[KO] = -1, this.enqueue(KO)
      }
      update(OO, KO, pO) {
        const XO = this.casters.blockCaster;
        if (XO !== this.casterTable) {
          this.casterTable = XO;
          for (let OO = 0; OO < wK; OO++) this.slotVersion[OO] = -1, this.slotChunk[OO] && this.enqueue(OO)
        }
        const bK = Math.floor(OO[0] / 32),
          eO = Math.floor(OO[1] / 32),
          lO = Math.floor(OO[2] / 32);
        (null === this.eyeChunk || this.eyeChunk[0] !== bK || this.eyeChunk[1] !== eO || this.eyeChunk[2] !== lO) && (this.eyeChunk = [bK, eO, lO], this.follow(KO), this.queueSorted = !1, this.requeueStarved(), this.windowTopStale = !0);
        for (let vK = 0; vK < wK; vK++) {
          const OO = this.slotChunk[vK];
          OO && (OO.FhO || OO.ae !== this.slotVersion[vK]) && this.enqueue(vK)
        }
        this.drain(pO), this.windowTopStale && this.writeWindowTop()
      }
      writeRecord(OO, KO) {
        this.records.set(KO, 4 * OO), this.windowTopStale = !0, this.writeVoxels(4 * OO, KO)
      }
      writeWindowTop() {
        this.windowTopStale = !1;
        const OO = this.records;
        let KO = -1 / 0;
        for (let XO = 0; XO < OO.length; XO += 4) {
          const pO = 255 & OO[XO + 3];
          pO !== PK && pO !== mp || !this.inRadius(OO[XO], OO[XO + 1], OO[XO + 2]) || (KO = Math.max(KO, OO[XO + 1] * EK + (OO[XO + 3] >>> 8)))
        }
        const pO = KO === -1 / 0 ? 1 : KO + cp;
        pO !== this.windowTop[0] && (this.windowTop[0] = pO, this.writeVoxels(JK, this.windowTop))
      }
      follow(OO) {
        const KO = this.eyeChunk,
          [pO, XO, bK] = jp;
        for (let lO = -bK; lO <= bK; lO++)
          for (let bK = -XO; bK <= XO; bK++)
            for (let XO = -pO; XO <= pO; XO++) {
              var eO;
              const pO = KO[0] + XO,
                vK = KO[1] + bK,
                CO = KO[2] + lO,
                hO = GK(pO, vK, CO),
                DO = this.slotChunk[hO];
              if (DO && !DO.FhO && DO.i === pO && DO.j === vK && DO.k === CO) continue;
              const MO = null !== (eO = OO(pO, vK, CO)) && void 0 !== eO ? eO : null;
              DO && (DO.i !== pO || DO.j !== vK || DO.k !== CO) && this.slotPool[hO] && (this.release(hO), this.record.fill(0), this.writeRecord(hO, this.record)), this.slotChunk[hO] = MO, this.slotVersion[hO] = -1, (MO || DO) && this.enqueue(hO)
            }
      }
      requeueStarved() {
        for (let OO = 0; OO < wK; OO++) this.starved[OO] && this.slotChunk[OO] && this.enqueue(OO)
      }
      enqueue(OO) {
        this.queued[OO] || (this.queued[OO] = 1, this.queue.push(OO), this.queueSorted = !1)
      }
      drain(OO) {
        if (0 === this.queue.length) return;
        if (!this.queueSorted) {
          const OO = new Map;
          for (const KO of this.queue) OO.set(KO, this.slotDistance(KO));
          this.queue.sort(((KO, pO) => OO.get(pO) - OO.get(KO))), this.queueSorted = !0
        }
        const KO = performance.now();
        let pO = 0;
        const XO = [];
        for (; this.queue.length > 0 && (0 === pO || performance.now() - KO < OO);) {
          const OO = this.queue.pop(),
            KO = this.slotChunk[OO];
          !KO || KO.FhO || XC(KO) ? (this.queued[OO] = 0, this.encodeSlot(OO), pO++) : XO.push(OO)
        }
        for (let bK = XO.length - 1; bK >= 0; bK--) this.queue.push(XO[bK])
      }
      slotDistance(OO) {
        const KO = this.slotChunk[OO],
          pO = this.eyeChunk;
        return KO ? Math.max(Math.abs(KO.i - pO[0]), Math.abs(KO.j - pO[1]), Math.abs(KO.k - pO[2])) : 0
      }
      inRadius(OO, KO, pO) {
        const XO = this.eyeChunk,
          [bK, eO, lO] = jp;
        return Math.abs(OO - XO[0]) <= bK && Math.abs(KO - XO[1]) <= eO && Math.abs(pO - XO[2]) <= lO
      }
      release(OO) {
        const KO = this.slotPool[OO];
        if (KO) {
          for (let OO = KO.length - 1; OO >= 0; OO--) this.freePool[this.freeCount++] = KO[OO];
          this.slotPool[OO] = null
        }
      }
      encodeSlot(OO) {
        var KO, pO, XO, bK, eO;
        let lO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.scratch,
          vK = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        const CO = null !== (KO = null === (pO = this.slotPool[OO]) || void 0 === pO ? void 0 : pO.length) && void 0 !== KO ? KO : 0;
        this.release(OO), this.starved[OO] = 0;
        const hO = this.slotChunk[OO],
          DO = this.record;
        if (!hO || hO.FhO || !hO.PK) return this.slotChunk[OO] = null, this.slotVersion[OO] = -1, DO.fill(0), this.writeRecord(OO, DO), void(CO > 0 && this.requeueStarved());
        this.slotVersion[OO] = hO.ae;
        const MO = this.encodeBricks(hO, OO, lO, vK);
        DO[0] = hO.i, DO[1] = hO.j, DO[2] = hO.k, DO[3] = MO, this.writeRecord(OO, DO), null === (XO = this.encoded) || void 0 === XO || XO.call(this, hO), vK && (null !== (bK = null === (eO = this.slotPool[OO]) || void 0 === eO ? void 0 : eO.length) && void 0 !== bK ? bK : 0) < CO && this.requeueStarved()
      }
      encodeBricks(OO, KO, pO, XO) {
        if (OO.IX) return rp;
        const bK = this.casters.blockCaster,
          {
            data: eO,
            stride: lO,
            offset: vK
          } = OO.PK,
          [CO, hO, DO] = lO,
          MO = EK,
          {
            bricks: aK,
            cells: oO,
            special: FO
          } = pO;
        aK.fill(0), FO.fill(0);
        let VO = 0,
          LO = 0,
          QO = 0;
        for (let zK = 0; zK < MO; zK++) {
          const KO = zK >> 2,
            pO = 3 & zK,
            XO = OO.mX[zK],
            lO = XO === pC.f ? -1 : XO < bK.length ? bK[XO] : 0;
          if (0 !== lO)
            for (let OO = 0; OO < MO; OO++) {
              const XO = OO >> 2,
                AO = 3 & OO;
              let fO = vK + OO * CO + zK * hO;
              for (let OO = 0; OO < MO; OO++, fO += DO) {
                let vK = lO;
                if (vK < 0) {
                  const OO = eO[fO];
                  if (vK = OO < bK.length ? bK[OO] : 0, 0 === vK) continue
                }
                const CO = qp(XO, KO, OO >> 2),
                  hO = xp(AO, pO, 3 & OO);
                aK[3 * CO + (hO >>> 5)] |= 1 << (31 & hO), oO[CO * sK + hO] = vK, VO++, QO = zK, vK === nK ? LO++ : FO[CO] = 1
              }
            }
        }
        return 0 === VO ? rp : 32768 === LO ? PK | QO << 8 : (this.writePoolEntries(KO, pO, XO), this.writeVoxels(RK + KO * SK, aK), mp | QO << 8)
      }
      writePoolEntries(OO, KO, pO) {
        const {
          bricks: XO,
          cells: bK,
          special: eO
        } = KO, lO = this.entry;
        let vK = 0;
        for (let DO = 0; DO < HK; DO++) vK += eO[DO];
        if (0 === vK) return;
        pO && this.freeCount < vK && this.evictBeyond(OO, vK);
        const CO = new Uint32Array(pO ? Math.min(vK, this.freeCount) : 0);
        let hO = 0;
        for (let DO = 0; DO < HK; DO++) {
          if (!eO[DO]) continue;
          const pO = 3 * DO;
          if (hO === CO.length) {
            this.dropSpecials(KO, DO), this.starved[OO] = 1;
            continue
          }
          const vK = this.freePool[--this.freeCount];
          CO[hO++] = vK;
          for (let OO = 0; OO < sK; OO++) {
            const KO = XO[pO + (OO >>> 5)] >>> (31 & OO) & 1 ? bK[DO * sK + OO] : 0;
            1 & OO ? lO[OO >> 1] |= KO << 16 : lO[OO >> 1] = KO
          }
          XO[pO + 2] = vK + 1, this.writePool(bX + 32 * vK, lO)
        }
        CO.length > 0 && (this.slotPool[OO] = CO)
      }
      evictBeyond(OO, KO) {
        const pO = this.slotDistance(OO),
          XO = [];
        for (let bK = 0; bK < wK; bK++) bK !== OO && this.slotPool[bK] && this.slotDistance(bK) > pO && XO.push(bK);
        XO.sort(((OO, KO) => this.slotDistance(KO) - this.slotDistance(OO)));
        for (const bK of XO) {
          if (this.freeCount >= KO) return;
          const OO = this.slotChunk[bK];
          OO && !OO.FhO && OO.PK && (OO.ae === this.slotVersion[bK] || XC(OO)) && this.encodeSlot(bK, this.victimScratch, !1)
        }
      }
      dropSpecials(OO, KO) {
        this.warnedPool || (this.warnedPool = !0, this.warn("Sun shadows: the special pool's 65536 entries are in use; plants and shapes in the furthest chunks cast nothing."));
        const pO = 3 * KO;
        for (let XO = 0; XO < sK; XO++) OO.cells[KO * sK + XO] !== nK && (OO.bricks[pO + (XO >>> 5)] &= ~(1 << (31 & XO)))
      }
    }
    var lC = pO(35807);
    class vh {
      constructor(OO) {
        this.device = OO, this.frameBuffer = void 0, this.gridBuffer = void 0, this.frame = new Vp, this.grids = new WeakMap, this.gridTop = 0, this.gridsFull = !1, this.uploadedEmpty = !1, this.lK = new Float64Array(16), this.bakeDeadline = 0, this.frameBuffer = OO.createBuffer({
          label: "sun-shadow-entities",
          size: 589828,
          usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST
        }), this.gridBuffer = OO.createBuffer({
          label: "sun-shadow-entity-grids",
          size: 16777216,
          usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST
        })
      }
      update(OO, KO, pO) {
        this.gridsFull && (this.gridsFull = !1, this.grids = new WeakMap, this.gridTop = 0), this.bakeDeadline = -1;
        const {
          frame: XO
        } = this;
        XO.Ip(OO, KO), pO.forEachSunShadowCaster((OO => {
          this.add(OO)
        })), XO.finish();
        const bK = 0 === XO.parts;
        if (bK && this.uploadedEmpty) return;
        this.uploadedEmpty = bK;
        const {
          queue: eO
        } = this.device, {
          words: lO
        } = XO;
        eO.writeBuffer(this.frameBuffer, 0, lO, 0, 16385), XO.refs > 0 && eO.writeBuffer(this.frameBuffer, 65540, lO, Cp, XO.refs), bK || eO.writeBuffer(this.frameBuffer, 327684, lO, hp, XO.parts * vX)
      }
      add(OO) {
        const KO = this.gridFor(OO);
        if (!KO) return;
        const {
          frame: pO
        } = this, {
          lK: XO,
          worldAt: bK,
          instances: eO,
          instanceCount: lO,
          thin: vK
        } = OO;
        if (eO)
          for (let CO = 0; CO < lO; CO++) vK ? (Qp(eO, 16 * CO, XO, bK, this.lK), pO.add(KO, this.lK)) : pO.add(KO, eO, 16 * CO);
        else pO.add(KO, XO, bK)
      }
      gridFor(OO) {
        let {
          geometry: KO,
          indexed: pO,
          first: XO,
          count: bK,
          skip: eO
        } = OO, lO = this.grids.get(KO);
        lO || (lO = new Map, this.grids.set(KO, lO));
        const vK = `${pO?XO:-1-XO}:${bK}:${null!==eO&&void 0!==eO?eO:""}`;
        let CO = lO.get(vK);
        if (void 0 !== CO || this.gridsFull) return CO;
        const hO = performance.now();
        if (this.bakeDeadline < 0) this.bakeDeadline = hO + 2;
        else if (hO > this.bakeDeadline) return;
        return CO = this.bake(KO, pO, XO, bK, eO), void 0 !== CO && lO.set(vK, CO), CO
      }
      bake(OO, KO, pO, XO, bK) {
        const eO = OO.vertexAttributes.find((OO => "position" === OO.kind)),
          lO = eO ? function(OO, KO, pO, XO) {
            let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
            const eO = OO => KO ? KO[pO + OO] : pO + OO,
              lO = OO => null !== bK && [0, 1, 2].some((KO => {
                const pO = eO(OO + KO);
                return pO >= bK[0] && pO < bK[1]
              })),
              vK = [1 / 0, 1 / 0, 1 / 0],
              CO = [-1 / 0, -1 / 0, -1 / 0];
            for (let zK = 0; zK + 2 < XO; zK += 3)
              if (!lO(zK))
                for (let KO = 0; KO < 3; KO++) {
                  const pO = eO(zK + KO);
                  for (let KO = 0; KO < 3; KO++) vK[KO] = Math.min(vK[KO], OO[3 * pO + KO]), CO[KO] = Math.max(CO[KO], OO[3 * pO + KO])
                }
            const hO = Math.max(CO[0] - vK[0], CO[1] - vK[1], CO[2] - vK[2]);
            if (!(hO > 0)) return null;
            const DO = hO / 64,
              MO = [0, 0, 0],
              aK = [0, 0, 0],
              oO = [0, 0, 0];
            for (let zK = 0; zK < 3; zK++) MO[zK] = Math.min(65, Math.ceil((CO[zK] - vK[zK]) / DO) + 1), aK[zK] = vK[zK] - DO / 2, oO[zK] = aK[zK] + MO[zK] * DO;
            const FO = new Uint32Array(Math.ceil(MO[0] * MO[1] * MO[2] / 32)),
              VO = new Float64Array(9),
              LO = [0, 0, 0],
              QO = [0, 0, 0];
            for (let zK = 0; zK + 2 < XO; zK += 3)
              if (!lO(zK)) {
                for (let KO = 0; KO < 3; KO++) {
                  const pO = eO(zK + KO);
                  for (let XO = 0; XO < 3; XO++) VO[3 * KO + XO] = OO[3 * pO + XO]
                }
                for (let OO = 0; OO < 3; OO++) {
                  const KO = Math.min(VO[OO], VO[3 + OO], VO[6 + OO]),
                    pO = Math.max(VO[OO], VO[3 + OO], VO[6 + OO]);
                  LO[OO] = Math.max(0, Math.floor((KO - aK[OO]) / DO - 1e-6)), QO[OO] = Math.min(MO[OO] - 1, Math.floor((pO - aK[OO]) / DO + 1e-6))
                }
                for (let OO = LO[2]; OO <= QO[2]; OO++)
                  for (let KO = LO[1]; KO <= QO[1]; KO++)
                    for (let pO = LO[0]; pO <= QO[0]; pO++)
                      if (zX(VO, aK[0] + (pO + .5) * DO, aK[1] + (KO + .5) * DO, aK[2] + (OO + .5) * DO, DO / 2)) {
                        const XO = pO + MO[0] * (KO + MO[1] * OO);
                        FO[XO >>> 5] |= 1 << (31 & XO)
                      }
              } return {
              words: FO,
              lo: aK,
              hi: oO,
              cell: DO,
              dims: MO
            }
          }((0, lC.i)(eO, OO.vertexCount), KO ? OO.indexData : null, pO, XO, bK) : null;
        if (!lO) return null;
        const {
          words: vK,
          ...CO
        } = lO;
        if (this.gridTop + vK.length > Mp) return void(this.gridsFull = !0);
        const hO = this.gridTop;
        return this.gridTop += vK.length, this.device.queue.writeBuffer(this.gridBuffer, 4 * hO, vK), {
          ...CO,
          at: hO
        }
      }
    }
    const CC = Math.cos(1 * Math.PI / 180);

    function hC(OO, KO) {
      return OO[0] * KO[0] + OO[1] * KO[1] + OO[2] * KO[2] < CC
    }
    async function DC(OO) {
      const {
        pixels: KO,
        width: pO,
        height: XO
      } = await Hb(OO), bK = new Uint8Array(pO * XO);
      for (let eO = 0; eO < bK.length; eO++) bK[eO] = KO[4 * eO + 3];
      return {
        width: pO,
        height: XO,
        alpha: bK
      }
    }
    class MC {
      constructor(OO, KO) {
        this.device = OO, this.uniform = void 0, this.voxelBuffer = void 0, this.special = void 0, this.volume = void 0, this.volumeView = void 0, this.volumeSampler = void 0, this.work = void 0, this.workData = new ArrayBuffer(fp.o), this.entities = void 0, this.entityStandIn = void 0, this.entitiesThisFrame = !1, this.window = null, this.casters = null, this.uniformData = new ArrayBuffer(128), this.uniformInts = new Int32Array(this.uniformData), this.uniformFloats = new Float32Array(this.uniformData), this.uniformWritten = null, this.eye = [0, 0, 0], this.warned = !1, this.volumePass = null, this.volumePassStarted = !1, this.volumePassFailed = !1, this.volumeHolds = null, this.slice = 0, this.sweepLeft = 0, this.written = !1, this.sweptChunk = [0, 0, 0], this.sweptLight = [0, 0, 0], this.stale = [], this.staleAll = !1, this.staleAllSwept = 0, this.castersWritten = !1, this.swept = 0, this.fastLeft = 0, this.paced = 0, this.staleNear = [0, 0, 0], this.uniform = OO.createBuffer({
          label: "sun-shadow",
          size: 128,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        }), this.voxelBuffer = OO.createBuffer({
          label: "sun-shadow-voxels",
          size: 4 * BK,
          usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST
        }), this.special = OO.createBuffer({
          label: "sun-shadow-special",
          size: 9568256,
          usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST
        });
        const [pO, XO, bK] = fp.r;
        this.volume = OO.createTexture({
          label: "sun-shadow-volume",
          size: {
            width: pO,
            height: XO,
            depthOrArrayLayers: bK
          },
          dimension: "3d",
          format: "rgba8unorm",
          usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING
        }), this.volumeView = this.volume.createView({
          label: "sun-shadow-volume"
        }), this.volumeSampler = OO.createSampler({
          label: "sun-shadow-volume",
          magFilter: "linear",
          minFilter: "linear",
          addressModeU: "repeat",
          addressModeV: "repeat",
          addressModeW: "repeat"
        }), this.work = OO.createBuffer({
          label: "sun-shadow-volume-work",
          size: fp.o,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        }), this.entities = KO ? new vh(OO) : null, this.entityStandIn = KO ? null : OO.createBuffer({
          label: "sun-shadow-entities-stand-in",
          size: 16,
          usage: GPUBufferUsage.STORAGE
        })
      }
      get tracesEntities() {
        return null !== this.entities
      }
      describePendingWork() {
        var OO, KO;
        const pO = [];
        !this.volumePassStarted || this.volumePass || this.volumePassFailed || pO.push("Lite sun shadow volume pipeline compiling");
        const XO = null !== (OO = null === (KO = this.casters) || void 0 === KO ? void 0 : KO.planesLoading) && void 0 !== OO ? OO : 0;
        return XO > 0 && pO.push(`${XO} Lite sun shadow plane casters loading their textures`), pO
      }
      entries() {
        var OO, KO, pO, XO;
        const bK = gp.s;
        return [{
          binding: bK.uniform,
          resource: {
            buffer: this.uniform
          }
        }, {
          binding: bK.PK,
          resource: {
            buffer: this.voxelBuffer
          }
        }, {
          binding: bK.special,
          resource: {
            buffer: this.special
          }
        }, {
          binding: bK.volume,
          resource: this.volumeView
        }, {
          binding: bK.sampler,
          resource: this.volumeSampler
        }, {
          binding: bK.entities,
          resource: {
            buffer: null !== (OO = null === (KO = this.entities) || void 0 === KO ? void 0 : KO.frameBuffer) && void 0 !== OO ? OO : this.entityStandIn
          }
        }, {
          binding: bK.entityGrids,
          resource: {
            buffer: null !== (pO = null === (XO = this.entities) || void 0 === XO ? void 0 : XO.gridBuffer) && void 0 !== pO ? pO : this.entityStandIn
          }
        }]
      }
      prepare(OO, KO, pO) {
        var XO;
        this.entitiesThisFrame = !1;
        const bK = null !== (XO = null === pO || void 0 === pO ? void 0 : pO.sunShadowReach()) && void 0 !== XO ? XO : {
          sunShadow: !1,
          airShadow: !1
        };
        if (!pO || !bK.sunShadow && !bK.airShadow) return void(this.volumeHolds = null);
        if (OO.lK.ovO !== EK) return void(this.warned || (this.warned = !0, console.warn(`Lite: sun shadows need chunks of 32 blocks, not ${OO.lK.ovO}; everything is lit.`)));
        const eO = this.start(OO);
        this.casters.update(OO.aX, OO.aX.Qp.length);
        const lO = OO.jp;
        for (let aK = 0; aK < 3; aK++) this.eye[aK] = KO[aK] + lO[aK];
        const vK = (0, fp.A)(this.eye);
        this.staleNear = vK;
        const CO = OO.lK.Rb;
        eO.update(this.eye, ((OO, KO, pO) => CO.Sb(OO, KO, pO)), 1);
        const hO = (0, fp.t)(pO.xvO()),
          DO = eO.eyeChunk,
          MO = this.uniformInts;
        for (let aK = 0; aK < 3; aK++) MO[aK] = DO[aK], MO[4 + aK] = vK[aK];
        this.entitiesThisFrame = null !== this.entities && bK.sunShadow, this.entitiesThisFrame && Fp(this.uniformFloats, 8, KO, hO), null !== this.volumeHolds && (this.castersWritten || hC(hO, this.sweptLight)) && (this.staleAll = !0, this.staleAllSwept = this.swept), this.castersWritten = !1, this.writeStale(), this.writeUniform(), this.computeVolume(vK, hO, DO)
      }
      markStale(OO) {
        const KO = this.staleNear,
          pO = EK,
          XO = [OO.i * pO, OO.j * pO, OO.k * pO];
        for (let eO = 0; eO < 3; eO++)
          if (XO[eO] + pO <= KO[eO] - pO || XO[eO] >= KO[eO] + fp.r[eO] + pO) return;
        if (this.staleAll) return void(this.staleAllSwept = this.swept);
        const bK = this.stale;
        for (let eO = 0; eO < bK.length; eO += 4)
          if (bK[eO] === OO.i && bK[eO + 1] === OO.j && bK[eO + 2] === OO.k) return void(bK[eO + 3] = this.swept);
        if (16 === bK.length) return this.staleAll = !0, void(this.staleAllSwept = this.swept);
        bK.push(OO.i, OO.j, OO.k, this.swept)
      }
      writeStale() {
        const OO = this.swept,
          KO = this.stale;
        this.staleAll && OO - this.staleAllSwept >= fp.i && (this.staleAll = !1, KO.length = 0);
        let pO = 0;
        for (let bK = 0; bK < KO.length; bK += 4)
          if (OO - KO[bK + 3] < fp.i) {
            for (let OO = 0; OO < 4; OO++) KO[pO + OO] = KO[bK + OO];
            pO += 4
          } KO.length = pO;
        const XO = this.uniformInts;
        XO[3] = this.staleAll ? 5 : pO / 4;
        for (let bK = 0; bK < 4; bK++)
          for (let OO = 0; OO < 3; OO++) XO[16 + 4 * bK + OO] = 4 * bK < pO ? KO[4 * bK + OO] * EK : 0
      }
      writeUniform() {
        const OO = this.uniformInts;
        let KO = this.uniformWritten;
        if (KO) {
          let pO = !0;
          for (let XO = 0; XO < OO.length && pO; XO++) pO = OO[XO] === KO[XO];
          if (pO) return
        }
        KO ??= this.uniformWritten = new Int32Array(OO.length), KO.set(OO), this.device.queue.writeBuffer(this.uniform, 0, this.uniformData)
      }
      traceEntities(OO) {
        this.entitiesThisFrame && this.entities.update(this.uniformFloats, 8, OO)
      }
      computeVolume(OO, KO, pO) {
        const XO = this.buildVolumePass();
        if (!XO) return void(this.volumeHolds = null);
        const bK = (0, fp.w)(this.volumeHolds, OO);
        this.volumeHolds = OO;
        const eO = 1 === bK.length && bK[0].size.every(((OO, KO) => OO === fp.r[KO])),
          lO = this.sweptChunk,
          vK = this.sweptLight,
          CO = KO[0] !== vK[0] || KO[1] !== vK[1] || KO[2] !== vK[2],
          hO = pO[0] !== lO[0] || pO[1] !== lO[1] || pO[2] !== lO[2],
          DO = CO && hC(KO, vK);
        if ((eO || this.written || hO || DO) && (this.fastLeft = fp.i), eO || this.written || CO || hO) {
          this.written = !1;
          for (let OO = 0; OO < 3; OO++) lO[OO] = pO[OO], vK[OO] = KO[OO];
          this.sweepLeft = eO ? 0 : fp.i
        }
        if (eO ? this.swept += fp.i : this.sweepLeft > 0 && (this.fastLeft > 0 || ++this.paced % 2 === 0) && (this.fastLeft = Math.max(this.fastLeft - 1, 0), this.sweepLeft--, bK.push(...(0, fp.E)(OO, this.slice)), this.slice = (this.slice + 1) % fp.i, this.swept++), 0 === bK.length) return;
        const MO = (0, fp.H)(this.workData, KO, bK);
        this.device.queue.writeBuffer(this.work, 0, this.workData);
        const aK = this.device.createCommandEncoder({
            label: "sun-shadow-volume"
          }),
          oO = aK.beginComputePass({
            label: "sun-shadow-volume"
          });
        oO.setPipeline(XO.pipeline), oO.setBindGroup(Np.group, XO.bindGroup), oO.dispatchWorkgroups(Math.ceil(MO / fp.k)), oO.end(), this.device.queue.submit([aK.finish()])
      }
      buildVolumePass() {
        if (this.volumePass || this.volumePassStarted) return this.volumePass;
        this.volumePassStarted = !0;
        const OO = Np,
          KO = GPUShaderStage.COMPUTE,
          pO = this.device.createBindGroupLayout({
            label: "sun-shadow-volume",
            entries: [{
              binding: OO.uniform,
              visibility: KO,
              buffer: {
                type: "uniform"
              }
            }, {
              binding: OO.PK,
              visibility: KO,
              buffer: {
                type: "read-only-storage"
              }
            }, {
              binding: OO.special,
              visibility: KO,
              buffer: {
                type: "read-only-storage"
              }
            }, {
              binding: OO.work,
              visibility: KO,
              buffer: {
                type: "uniform"
              }
            }, {
              binding: OO.volume,
              visibility: KO,
              storageTexture: {
                access: "write-only",
                format: "rgba8unorm",
                viewDimension: "3d"
              }
            }]
          }),
          XO = this.device.createBindGroup({
            label: "sun-shadow-volume",
            layout: pO,
            entries: [{
              binding: OO.uniform,
              resource: {
                buffer: this.uniform
              }
            }, {
              binding: OO.PK,
              resource: {
                buffer: this.voxelBuffer
              }
            }, {
              binding: OO.special,
              resource: {
                buffer: this.special
              }
            }, {
              binding: OO.work,
              resource: {
                buffer: this.work
              }
            }, {
              binding: OO.volume,
              resource: this.volumeView
            }]
          });
        return this.device.createComputePipelineAsync({
          label: "sun-shadow-volume",
          layout: this.device.createPipelineLayout({
            label: "sun-shadow-volume",
            bindGroupLayouts: [pO]
          }),
          compute: {
            module: this.device.createShaderModule({
              label: "sun-shadow-volume",
              code: Ip()
            }),
            entryPoint: "main"
          }
        }).then((OO => {
          this.volumePass = {
            pipeline: OO,
            bindGroup: XO
          }
        }), (OO => {
          this.volumePassFailed = !0, console.warn(`Lite: sun shadows' visibility volume didn't build, so air shadows and far traces are lit: ${String(OO)}`)
        })), null
      }
      start(OO) {
        if (this.window) return this.window;
        const KO = (OO, KO) => {
          this.written = !0, this.device.queue.writeBuffer(this.special, 4 * OO, KO)
        };
        this.casters = new KC(((OO, pO) => {
          this.castersWritten = !0, KO(OO, pO)
        }), DC);
        const pO = new eC(this.casters, ((OO, KO) => {
          this.written = !0, this.device.queue.writeBuffer(this.voxelBuffer, 4 * OO, KO)
        }), KO);
        return pO.encoded = OO => {
          this.markStale(OO)
        }, OO.lK.on("chunkAdded", (OO => {
          pO.chunkAdded(OO)
        })), this.window = pO, pO
      }
    }
    var ah = pO(37077),
      oC = pO(37080);
    const FC = 0,
      VC = 3,
      LC = 4,
      QC = 5;

    function zh(OO, KO, pO, XO) {
      OO.drawOffset(KO, XO + FC), KO[XO + VC] = OO.drawTime(), pO[XO + LC] = OO.ring.drawStart(), pO[XO + QC] = OO.ring.drawCount()
    }
    const AC = `\n${VX}\n\nconst MAX_STOPS = ${oC.b}u;\n\nstruct SystemUniforms {\n\tgravity: vec3f,\n\tcolorCount: u32,\n\tcolorDead: vec4f,\n\tvelocityCount: u32,\n\tremapCount: u32,\n\tramp: u32,\n\tcolorPositions: array<vec4f, ${oC.b/4}>,\n\tcolor1: array<vec4f, ${oC.b}>,\n\tcolor2: array<vec4f, ${oC.b}>,\n\t// Position, factor and factor2 per stop.\n\tvelocity: array<vec4f, ${oC.b}>,\n\t// Position, min and max per stop.\n\tremap: array<vec4f, ${oC.b}>,\n}\n\n// A particle as spawned: position relative to the frame offset and spawn time; direction times emit power and\n// lifetime; size, random seed and colour.\nstruct Particle {\n\tspawn: vec4f,\n\tvelocity: vec4f,\n\tsize: f32,\n\tseed: u32,\n\tcolour: vec4f,\n}\n\nstruct SystemFrame {\n\toffset: vec3f,\n\tnow: f32,\n\t// The slot drawn first (the oldest), and the slots in use.\n\tstart: u32,\n\tcount: u32,\n}\n\n@group(1) @binding(0) var<uniform> system: SystemUniforms;\n@group(1) @binding(1) var<storage, read> particles: array<Particle>;\n@group(1) @binding(2) var diffuseSampler: sampler;\n@group(1) @binding(3) var diffuseTexture: texture_2d<f32>;\n@group(1) @binding(4) var rampSampler: sampler;\n@group(1) @binding(5) var rampTexture: texture_2d<f32>;\n@group(2) @binding(0) var<uniform> frame: SystemFrame;\n\n// The MULTIPLY pass of BLENDMULTIPLYMODE, which MULTIPLYADD draws before its ADD pass.\noverride MULTIPLY_PASS: bool = false;\n\nstruct VertexOutput {\n\t@builtin(position) position: vec4f,\n\t@location(0) uv: vec2f,\n\t@location(1) colour: vec4f,\n\t@location(2) remap: vec4f,\n}\n\nfn hash(v: u32) -> u32 {\n\tlet state = v * 747796405u + 2891336453u;\n\tlet word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;\n\treturn (word >> 22u) ^ word;\n}\n\n// The particle's own random pick for a gradient stop, as Babylon picks one when the particle reaches it.\nfn random(seed: u32, stop: u32) -> f32 {\n\treturn f32(hash(seed ^ (stop * 0x9e3779b9u)) >> 8u) / 16777216.0;\n}\n\nfn colourPosition(i: u32) -> f32 {\n\treturn system.colorPositions[i / 4u][i % 4u];\n}\n\nfn stopColour(i: u32, seed: u32) -> vec4f {\n\treturn mix(system.color1[i], system.color2[i], random(seed, i));\n}\n\nfn velocityFactor(i: u32, seed: u32) -> f32 {\n\tlet stop = system.velocity[i];\n\treturn mix(stop.y, stop.z, random(seed, MAX_STOPS + i));\n}\n\n// _ProcessColorGradients / _ProcessColor at the particle's age. Babylon's GetCurrentGradient picks stop 0's pair\n// below the first stop, where a particle keeps the colour it was given for the next stop (stop 1's pick); the first\n// segment containing the ratio; or else the last stop.\nfn colourAt(p: Particle, age: f32, ratio: f32, seed: u32) -> vec4f {\n\tlet n = system.colorCount;\n\tvar colour: vec4f;\n\tif (n == 0u) {\n\t\tcolour = mix(p.colour, system.colorDead, ratio);\n\t} else if (age == 0.0) {\n\t\treturn stopColour(0u, seed);\n\t} else if (ratio < colourPosition(0u)) {\n\t\tcolour = stopColour(min(1u, n - 1u), seed);\n\t} else {\n\t\tcolour = stopColour(n - 1u, seed);\n\t\tfor (var i = 0u; i + 1u < n; i++) {\n\t\t\tlet a = colourPosition(i);\n\t\t\tlet b = colourPosition(i + 1u);\n\t\t\tif (ratio >= a && ratio <= b) {\n\t\t\t\tlet scale = select(0.0, (ratio - a) / (b - a), b > a);\n\t\t\t\tcolour = mix(stopColour(i, seed), stopColour(i + 1u, seed), scale);\n\t\t\t\tbreak;\n\t\t\t}\n\t\t}\n\t}\n\tcolour.a = max(colour.a, 0.0);\n\treturn colour;\n}\n\n// The integral of (alpha + beta s)(d + g s) over s0..s1: the distance travelled while the velocity factor is\n// alpha + beta s at age s and the direction d + g s.\nfn travel(alpha: f32, beta: f32, d: vec3f, g: vec3f, s0: f32, s1: f32) -> vec3f {\n\tlet ds = s1 - s0;\n\tlet ds2 = (s1 * s1 - s0 * s0) * 0.5;\n\tlet ds3 = (s1 * s1 * s1 - s0 * s0 * s0) / 3.0;\n\treturn d * (alpha * ds) + (g * alpha + d * beta) * ds2 + g * (beta * ds3);\n}\n\n// Where the particle has moved by its age: each frame Babylon moves it by its direction times the step and the\n// velocity factor, then adds gravity times the step to the direction. The factor is piecewise linear in the age,\n// picked as colourAt picks colours.\nfn displacement(d: vec3f, age: f32, life: f32, seed: u32) -> vec3f {\n\tlet g = system.gravity;\n\tlet n = system.velocityCount;\n\tif (n == 0u) {\n\t\treturn d * age + g * (0.5 * age * age);\n\t}\n\tvar total = vec3f(0.0);\n\tlet first = system.velocity[0u].x * life;\n\tlet beforeFirst = min(age, first);\n\tif (beforeFirst > 0.0) {\n\t\ttotal += travel(velocityFactor(min(1u, n - 1u), seed), 0.0, d, g, 0.0, beforeFirst);\n\t}\n\tfor (var i = 0u; i + 1u < n; i++) {\n\t\tlet a = system.velocity[i].x * life;\n\t\tlet b = system.velocity[i + 1u].x * life;\n\t\tlet lo = max(a, 0.0);\n\t\tlet hi = min(b, age);\n\t\tif (hi > lo) {\n\t\t\tlet fa = velocityFactor(i, seed);\n\t\t\tlet beta = (velocityFactor(i + 1u, seed) - fa) / (b - a);\n\t\t\ttotal += travel(fa - beta * a, beta, d, g, lo, hi);\n\t\t}\n\t}\n\tlet afterLast = max(system.velocity[n - 1u].x * life, 0.0);\n\tif (age > afterLast) {\n\t\ttotal += travel(velocityFactor(n - 1u, seed), 0.0, d, g, afterLast, age);\n\t}\n\treturn total;\n}\n\n// _ProcessRemapGradients: the colour remap's min and range at the ratio; a new particle has (0, 1, 0, 1).\nfn remapAt(age: f32, ratio: f32) -> vec4f {\n\tlet n = system.remapCount;\n\tif (n == 0u || age == 0.0) {\n\t\treturn vec4f(0.0, 1.0, 0.0, 1.0);\n\t}\n\tvar stop = system.remap[n - 1u].yz;\n\tif (ratio < system.remap[0u].x) {\n\t\tstop = system.remap[0u].yz;\n\t} else {\n\t\tfor (var i = 0u; i + 1u < n; i++) {\n\t\t\tlet a = system.remap[i];\n\t\t\tlet b = system.remap[i + 1u];\n\t\t\tif (ratio >= a.x && ratio <= b.x) {\n\t\t\t\tstop = mix(a.yz, b.yz, select(0.0, (ratio - a.x) / (b.x - a.x), b.x > a.x));\n\t\t\t\tbreak;\n\t\t\t}\n\t\t}\n\t}\n\treturn vec4f(stop.x, stop.y - stop.x, 0.0, 1.0);\n}\n\n@vertex\nfn mainVertex(@builtin(vertex_index) vertexIndex: u32, @builtin(instance_index) instanceIndex: u32) -> VertexOutput {\n\tvar out: VertexOutput;\n\tlet p = particles[(frame.start + instanceIndex) % frame.count];\n\tlet age = frame.now - p.spawn.w;\n\tlet life = p.velocity.w;\n\tif (!(age >= 0.0 && age < life)) {\n\t\t// Dead, or not yet written: outside the clip volume.\n\t\tout.position = vec4f(0.0, 0.0, 2.0, 1.0);\n\t\treturn out;\n\t}\n\tlet ratio = age / life;\n\tlet seed = p.seed;\n\tlet centre = frame.offset + p.spawn.xyz + displacement(p.velocity.xyz, age, life, seed);\n\t// ThinParticleSystem's billboard: the corner offset in view space, here along the camera's right and up.\n\tlet corner = vec2f(f32(vertexIndex & 1u), f32(vertexIndex >> 1u));\n\tlet offset = (corner - 0.5) * p.size;\n\tlet right = vec3f(scene.view[0][0], scene.view[1][0], scene.view[2][0]);\n\tlet up = vec3f(scene.view[0][1], scene.view[1][1], scene.view[2][1]);\n\tout.position = liteWorldLayer(scene.viewProjection * vec4f(centre + right * offset.x + up * offset.y, 1.0));\n\tout.uv = corner;\n\tout.colour = colourAt(p, age, ratio, seed);\n\tout.remap = remapAt(age, ratio);\n\treturn out;\n}\n\n// Babylon's particles.fragment with the default texture mask, without fog or image processing.\n@fragment\nfn mainFragment(in: VertexOutput) -> @location(0) vec4f {\n\tlet textureColour = textureSample(diffuseTexture, diffuseSampler, in.uv);\n\tvar colour = textureColour * in.colour;\n\tif (system.ramp != 0u) {\n\t\tlet index = clamp((colour.a - in.remap.x) / in.remap.y, 0.0, 1.0);\n\t\tlet rampColour = textureSample(rampTexture, rampSampler, vec2f(1.0 - index, 0.0));\n\t\tcolour = vec4f(colour.rgb * rampColour.rgb, clamp((colour.a * rampColour.a - in.remap.z) / in.remap.w, 0.0, 1.0));\n\t}\n\tif (MULTIPLY_PASS) {\n\t\tlet sourceAlpha = in.colour.a * textureColour.a;\n\t\tcolour = vec4f(colour.rgb * sourceAlpha + vec3f(1.0 - sourceAlpha), colour.a);\n\t}\n\treturn colour;\n}\n`;
    var fC = pO(39631);
    class dC {
      constructor(OO, KO, pO, XO) {
        this.device = OO, this.system = KO, this.frameIndex = pO, this.MX = XO, this.ring = void 0, this.uniforms = void 0, this.uniformBits = null, this.rampTexels = (0, fC.e)(), this.ramp = null, this.rampView = null, this.bindGroup = null, this.boundView = null, this.boundSampler = null, this.boundRamp = null, this.texture = null, this.pipelines = [], this.count = 0, this.upload = (OO, KO) => {
          this.device.queue.writeBuffer(this.ring, OO * oC.e * 4, this.system.ring.records, OO * oC.e, (KO - OO) * oC.e)
        };
        const {
          name: bK
        } = KO;
        this.ring = OO.createBuffer({
          label: `particles-${bK}`,
          size: KO.ring.records.byteLength,
          usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST
        }), this.uniforms = OO.createBuffer({
          label: `particles-uniforms-${bK}`,
          size: 4 * oC.o,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        })
      }
      writeUniforms(OO) {
        const KO = (0, fC.b)(this.system, this.uniformBits, OO);
        KO && (this.uniformBits = KO, this.device.queue.writeBuffer(this.uniforms, 0, KO))
      }
      bind() {
        const {
          system: OO
        } = this, KO = this.texture;
        (0, fC.j)(OO, this.rampTexels) && this.rampTexels.key.length > 0 && (this.ramp || (this.ramp = this.device.createTexture({
          label: `particles-ramp-${OO.name}`,
          size: [oC.l, 1],
          format: "rgba8unorm",
          usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
        }), this.rampView = this.ramp.createView()), this.device.queue.writeTexture({
          texture: this.ramp
        }, this.rampTexels.texels, {
          bytesPerRow: 4 * oC.l
        }, [oC.l, 1]));
        const pO = this.rampTexels.key.length > 0 && this.rampView ? this.rampView : this.MX.whiteRamp;
        this.bindGroup && this.boundView === KO.view && this.boundSampler === KO.sampler && this.boundRamp === pO || (this.boundView = KO.view, this.boundSampler = KO.sampler, this.boundRamp = pO, this.bindGroup = this.device.createBindGroup({
          label: `particles-${OO.name}`,
          layout: this.MX.layout,
          entries: [{
            binding: 0,
            resource: {
              buffer: this.uniforms
            }
          }, {
            binding: 1,
            resource: {
              buffer: this.ring
            }
          }, {
            binding: 2,
            resource: KO.sampler
          }, {
            binding: 3,
            resource: KO.view
          }, {
            binding: 4,
            resource: this.MX.rampSampler
          }, {
            binding: 5,
            resource: pO
          }]
        }))
      }
      destroy() {
        var OO;
        this.ring.destroy(), this.uniforms.destroy(), null === (OO = this.ramp) || void 0 === OO || OO.destroy()
      }
    }
    class TC {
      constructor(OO, KO) {
        this.device = OO, this.resources = KO, this.renderable = void 0, this.systems = new Map, this.draws = [], this.MX = void 0, this.frameLayout = void 0, this.pipelineLayout = void 0, this.module = void 0, this.pipelines = new Map, this.frameData = new Float32Array(4096), this.frameBits = new Uint32Array(this.frameData.buffer), this.frameBuffer = void 0, this.frameBindGroup = void 0, this.freeFrameIndices = [], this.nextFrameIndex = 0, this.target = null, this.targetPipelines = null, this.preparedTarget = null, this.warnOnce = (0, hK.d)();
        const pO = OO.createBindGroupLayout({
          label: "particles-system",
          entries: [{
            binding: 0,
            visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT,
            buffer: {
              type: "uniform"
            }
          }, {
            binding: 1,
            visibility: GPUShaderStage.VERTEX,
            buffer: {
              type: "read-only-storage"
            }
          }, {
            binding: 2,
            visibility: GPUShaderStage.FRAGMENT,
            sampler: {
              type: "filtering"
            }
          }, {
            binding: 3,
            visibility: GPUShaderStage.FRAGMENT,
            texture: {
              sampleType: "float"
            }
          }, {
            binding: 4,
            visibility: GPUShaderStage.FRAGMENT,
            sampler: {
              type: "filtering"
            }
          }, {
            binding: 5,
            visibility: GPUShaderStage.FRAGMENT,
            texture: {
              sampleType: "float"
            }
          }]
        });
        this.frameLayout = OO.createBindGroupLayout({
          label: "particles-frame",
          entries: [{
            binding: 0,
            visibility: GPUShaderStage.VERTEX,
            buffer: {
              type: "uniform",
              hasDynamicOffset: !0
            }
          }]
        }), this.pipelineLayout = OO.createPipelineLayout({
          bindGroupLayouts: [KK(OO), pO, this.frameLayout]
        }), this.module = OO.createShaderModule({
          label: "particles",
          code: AC
        });
        const XO = OO.createTexture({
          label: "particles-no-ramp",
          size: [1, 1],
          format: "rgba8unorm",
          usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
        });
        OO.queue.writeTexture({
          texture: XO
        }, new Uint8Array([255, 255, 255, 255]), {
          bytesPerRow: 4
        }, [1, 1]), this.MX = {
          layout: pO,
          rampSampler: OO.createSampler({
            label: "particles-ramp",
            magFilter: "nearest",
            minFilter: "nearest",
            addressModeU: "repeat",
            addressModeV: "repeat"
          }),
          whiteRamp: XO.createView()
        }, this.frameBuffer = this.createFrameBuffer(), this.frameBindGroup = this.createFrameBindGroup(), this.renderable = {
          order: 251,
          isTransparent: !0,
          _worldCenter: [0, 0, 0],
          bind: (KO, pO) => (this.bindTarget(pO), {
            renderable: this.renderable,
            pipeline: lK(OO, pO),
            draw: OO => pO === this.preparedTarget ? this.draw(OO) : 0
          })
        }
      }
      get ZDO() {
        return this.systems.size
      }
      reset() {
        for (const OO of this.systems.keys()) OO.reset()
      }
      describePendingWork() {
        return (0, ah.g)(this.systems.keys(), "Lite")
      }
      XpO(OO, KO) {
        const pO = new ah.d(OO, KO, this);
        return this.systems.set(pO, new dC(this.device, pO, this.allocateFrameIndex(), this.MX)), pO
      }
      ivO(OO, KO) {
        for (const pO of this.systems.keys()) pO.ivO(OO, KO)
      }
      canDraw(OO) {
        const KO = this.systems.get(OO),
          pO = OO.texture ? this.resources.boundTexture(OO.texture) : null;
        if (!KO || !pO || !this.targetPipelines) return !1;
        if (KO.texture = pO, KO.pipelines.length = 0, !Bb(OO.blendMode)) return this.warnOnce(`blend:${OO.blendMode}`, `particle blend mode ${OO.blendMode} is not drawn (${OO.name})`), !0;
        const XO = (0, je.k)(OO.blendMode);
        for (const bK of XO) {
          const OO = this.pipelineFor(bK);
          if (!1 === OO) return KO.pipelines.length = 0, !0;
          OO && KO.pipelines.push(OO)
        }
        return KO.pipelines.length === XO.length
      }
      disposeStopped(OO) {
        OO.dispose()
      }
      remove(OO) {
        const KO = this.systems.get(OO);
        KO && (this.systems.delete(OO), KO.destroy(), this.freeFrameIndices.push(KO.frameIndex))
      }
      prepare(OO) {
        const KO = OO.animationRatio || 1;
        vp(this.renderable._worldCenter, OO, XK), this.preparedTarget = this.target, this.draws.length = 0;
        let pO = 0;
        for (const XO of this.systems.values()) {
          const OO = XO.system;
          if (!OO.animateIfActive(KO)) continue;
          if (OO.ring.takeUploads(XO.upload), !OO.hasLiveParticles() || 0 === XO.pipelines.length) continue;
          XO.writeUniforms(this.warnOnce), XO.bind();
          const bK = 64 * XO.frameIndex;
          XO.count = OO.ring.drawCount(), zh(OO, this.frameData, this.frameBits, bK), pO = Math.max(pO, bK + 64), this.draws.push(XO)
        }
        pO > 0 && this.device.queue.writeBuffer(this.frameBuffer, 0, this.frameData, 0, pO)
      }
      draw(OO) {
        let KO = 0,
          pO = null;
        for (const XO of this.draws) {
          OO.setBindGroup(1, XO.bindGroup), OO.setBindGroup(2, this.frameBindGroup, [256 * XO.frameIndex]);
          for (const bK of XO.pipelines) bK !== pO && (OO.setPipeline(bK), pO = bK), OO.draw(4, XO.count), KO++
        }
        return KO
      }
      bindTarget(OO) {
        this.target = OO;
        const KO = `${OO._colorFormat}|${OO._depthStencilFormat}|${OO._depthCompare}|${OO._sampleCount}`;
        let pO = this.pipelines.get(KO);
        pO || (pO = new Map, this.pipelines.set(KO, pO)), this.targetPipelines = pO
      }
      pipelineFor(OO) {
        var KO;
        const pO = this.targetPipelines,
          XO = pO.get(OO);
        if (void 0 !== XO) return XO;
        pO.set(OO, null);
        const bK = this.target,
          eO = OO === je.d,
          lO = null !== (KO = bK._depthCompare) && void 0 !== KO ? KO : pK;
        return this.device.createRenderPipelineAsync({
          label: `particles-${OO}`,
          layout: this.pipelineLayout,
          vertex: {
            module: this.module,
            entryPoint: "mainVertex"
          },
          fragment: tK({
            module: this.module,
            entryPoint: "mainFragment",
            constants: {
              MULTIPLY_PASS: eO ? 1 : 0
            }
          }, bK, Zb((0, je.j)(OO))),
          primitive: {
            topology: "triangle-strip",
            cullMode: "none"
          },
          depthStencil: bK._depthStencilFormat ? {
            format: bK._depthStencilFormat,
            depthCompare: lO,
            depthWriteEnabled: !1
          } : void 0,
          multisample: {
            count: bK._sampleCount
          }
        }).then((KO => {
          pO.set(OO, KO)
        }), (KO => {
          pO.set(OO, !1), console.error("Lite particle pipeline failed", KO), xe("particles", `blend-${OO}`, KO)
        })), null
      }
      allocateFrameIndex() {
        const OO = this.freeFrameIndices.pop();
        if (void 0 !== OO) return OO;
        const KO = this.nextFrameIndex++;
        if (64 * (KO + 1) > this.frameData.length) {
          const OO = new Float32Array(2 * this.frameData.length);
          OO.set(this.frameData), this.frameData = OO, this.frameBits = new Uint32Array(OO.buffer), this.frameBuffer.destroy(), this.frameBuffer = this.createFrameBuffer(), this.frameBindGroup = this.createFrameBindGroup()
        }
        return KO
      }
      createFrameBuffer() {
        return this.device.createBuffer({
          label: "particles-frames",
          size: this.frameData.byteLength,
          usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
        })
      }
      createFrameBindGroup() {
        return this.device.createBindGroup({
          label: "particles-frames",
          layout: this.frameLayout,
          entries: [{
            binding: 0,
            resource: {
              buffer: this.frameBuffer,
              size: 32
            }
          }]
        })
      }
    }
    class NC {
      constructor(OO, KO, pO, XO, bK) {
        this.lite = OO, this.canvas = KO, this.info = pO, this.resources = bK, this.BhO = !1, this.needPOTTextures = !1, this.PeO = !0, this.renderWidth = void 0, this.renderHeight = void 0, this.performanceMonitor = {
          reset: () => {
            this.lastFrameTime = null
          }
        }, this.caps = void 0, this.deltaTime = 0, this.lastFrameTime = null, this.renderWidth = KO.width, this.renderHeight = KO.height, this.caps = {
          maxTextureSize: XO.maxTextureDimension2D,
          texture2DArrayMaxLayerCount: XO.maxTextureArrayLayers
        }
      }
      getCaps() {
        return this.caps
      }
      getRenderWidth() {
        return this.renderWidth
      }
      getRenderHeight() {
        return this.renderHeight
      }
      getHardwareScalingLevel() {
        return 1
      }
      setSize(OO, KO) {
        if (this.renderWidth === OO && this.renderHeight === KO) return !1;
        const pO = this.renderWidth,
          XO = this.renderHeight;
        this.renderWidth = OO, this.renderHeight = KO;
        try {
          (0, SO.m)(this.lite, OO, KO)
        } catch (bK) {
          if (bK instanceof DOMException && "InvalidStateError" === bK.name) {
            this.renderWidth = pO, this.renderHeight = XO;
            try {
              (0, SO.m)(this.lite, pO, XO)
            } catch {
              this.canvas.width = pO, this.canvas.height = XO
            }
            return console.warn("WebGPU could not allocate render targets for resize", OO, KO, bK.message), !1
          }
          throw bK
        }
        return !0
      }
      resize() {}
      getRenderingCanvas() {
        return this.canvas
      }
      getInfo() {
        return this.info
      }
      uL() {
        const OO = performance.now();
        this.deltaTime = null === this.lastFrameTime ? 0 : OO - this.lastFrameTime, this.lastFrameTime = OO
      }
      getDeltaTime() {
        return this.deltaTime
      }
      createCanvas(OO, KO) {
        const pO = document.createElement("canvas");
        return pO.width = OO, pO.height = KO, pO
      }
      HeO(OO, KO) {
        var pO;
        return null !== (pO = this.resources.HeO.get(OO)) && void 0 !== pO ? pO : new ZO(this.resources, OO, KO)
      }
      atlasArray(OO, KO, pO) {
        return this.resources.atlasArray(OO, KO, pO)
      }
    }
    class IC {
      constructor() {
        this.fov = .8, this.nearPlane = 1, this.farPlane = 1e3, this.children = [], this.worldMatrix = new Float32Array(16), this.worldMatrixVersion = 0, this._viewCache = new Float32Array(16), this._projCache = new Float32Array(16), this._vpCache = new Float32Array(16)
      }
      copyFromView(OO) {
        this.fov = OO.fov, this.nearPlane = OO.near, this.farPlane = OO.far;
        const KO = OO.worldMatrix;
        for (let pO = 0; pO < 16; pO++)
          if (this.worldMatrix[pO] !== KO[pO]) return this.worldMatrix.set(KO), void this.worldMatrixVersion++
      }
    }
    class yh {
      constructor(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
        let DO = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : null;
        this.engine = OO, this.Ce = KO, this.sceneTask = pO, this.gpuDevice = XO, this.terrain = bK, this.meshes = eO, this.particles = lO, this.resources = vK, this.sunShadow = DO, this.wCO = void 0, this.backendName = "WebGPU (Lite)", this.XlO = void 0, this.modelMeshes = void 0, this.camera = new IC, this.lastFrameTime = 0, this.refusals = void 0, this.deviceLost = void 0, this.refusals = new cK(XO.lost), this.deviceLost = this.refusals.deviceLost, this.wCO = new NC(OO, CO, hO, XO.limits, vK), (0, uO.F)({
          JK: OO => {
            wO(OO) && vK.textureSlot(OO)
          },
          loaded: OO => wO(OO) ? vK.textureLoaded(OO) : null,
          canvasUpdated: (OO, KO, pO) => {
            wO(OO) && vK.canvasUpdated(OO, KO, pO)
          }
        }), this.XlO = eO.XlO, this.modelMeshes = eO.modelMeshes, KO.camera = this.camera
      }
      get castsEntitySunShadows() {
        var OO, KO;
        return null !== (OO = null === (KO = this.sunShadow) || void 0 === KO ? void 0 : KO.tracesEntities) && void 0 !== OO && OO
      }
      get sampleCount() {
        return this.engine.msaaSamples
      }
      attach(OO) {
        this.modelMeshes.attach(OO.model, OO.sceneMirror);
        const KO = OO.Ce;
        this.setClearColour(KO.clearColor.r, KO.clearColor.g, KO.clearColor.b), KO.draw = () => {
          this.drawFrame(OO, KO)
        }
      }
      render(OO) {
        try {
          this.wCO.uL(), OO.Ce.render()
        } catch (KO) {
          throw this.refusals.frameFailed(KO), KO
        }
        this.refusals.frameDrawn()
      }
      lastFrameDrawCalls() {
        return this.engine.drawCallCount
      }
      describePendingWork() {
        var OO, KO, pO, XO;
        const bK = [...this.particles.describePendingWork(), ...null !== (OO = null === (KO = this.sunShadow) || void 0 === KO ? void 0 : KO.describePendingWork()) && void 0 !== OO ? OO : []],
          eO = this.meshes.pipelinesCompiling + this.terrain.pipelinesCompiling + (null !== (pO = this.terrain.sceneDepth) && void 0 !== pO && pO.compiling ? 1 : 0) + (null !== (XO = this.terrain.shadowMask) && void 0 !== XO && XO.compiling ? 1 : 0);
        eO > 0 && bK.push(`${eO} Lite pipelines compiling`);
        const lO = this.terrain.buffersAwaitingVerdict;
        lO > 0 && bK.push(`${lO} Lite terrain buffers awaiting their out-of-memory verdict`);
        const vK = this.resources.texturesLoading;
        return vK > 0 && bK.push(`${vK} Lite textures loading`), bK
      }
      prepareTexture(OO) {
        return null !== this.resources.boundTexture(OO) || this.resources.textureFailed(OO)
      }
      drawFrame(OO, KO) {
        var pO, XO, bK, eO, lO, vK;
        const CO = Dv(OO);
        this.camera.copyFromView(CO), this.setClearColour(CO.clearColour[0], CO.clearColour[1], CO.clearColour[2]), null === (pO = this.sunShadow) || void 0 === pO || pO.prepare(OO.ap, CO.eye, null !== (XO = OO.ap.hX) && void 0 !== XO ? XO : null), this.terrain.prepare(OO, CO), null === (bK = this.terrain.sceneDepth) || void 0 === bK || bK.setPlanes(CO.near, CO.far), null === (eO = this.terrain.shadowMask) || void 0 === eO || eO.prepare(CO), nl(this.sceneTask), this.meshes.prepare(KO, CO, OO.model.earthSky, null !== (lO = OO.ap.hX) && void 0 !== lO ? lO : null), this.particles.prepare(CO);
        const hO = performance.now();
        this.resources.flushUploads(), null === (vK = this.sunShadow) || void 0 === vK || vK.traceEntities(this.meshes);
        try {
          (0, SO.l)(this.engine, this.lastFrameTime > 0 ? hO - this.lastFrameTime : 0)
        } finally {
          this.resources.endUploadFrame()
        }
        this.lastFrameTime = hO
      }
      setClearColour(OO, KO, pO) {
        const XO = this.Ce.clearColor;
        XO.r = OO, XO.g = KO, XO.b = pO, XO.a = 1
      }
    }
    const gh = "WebGPU device lost while Lite was starting";

    function uC(OO, KO) {
      return "object" === typeof OO && null !== OO ? Object.assign(OO, {
        startStep: KO
      }) : OO
    }
    async function EC(OO, KO) {
      const pO = await navigator.gpu.requestAdapter({
        powerPreference: "high-performance"
      });
      if (!pO) throw uC(new Error("No WebGPU adapter"), "no_adapter");
      const XO = pO.info,
        bK = {
          vendor: (null === XO || void 0 === XO ? void 0 : XO.vendor) || "unknown vendor",
          renderer: (null === XO || void 0 === XO ? void 0 : XO.architecture) || "unknown renderer",
          version: (null === XO || void 0 === XO ? void 0 : XO.description) || "unknown version"
        },
        eO = function(OO) {
          const KO = {};
          for (const pO in OO.limits) {
            const XO = OO.limits[pO];
            "number" === typeof XO && (KO[pO] = XO)
          }
          return KO
        }(pO);
      let lO;
      OO.style.background = "black";
      try {
        lO = await (0, SO.d)(OO, {
          msaaSamples: KO.ohO ? 4 : 1,
          requiredLimits: eO,
          alphaMode: "premultiplied"
        })
      } catch (DO) {
        throw uC(DO, "#47" === (null === (vK = DO) || void 0 === vK ? void 0 : vK.message) ? "no_adapter" : "device")
      }
      var vK;
      const CO = function(OO) {
        return OO._device
      }(lO);
      let hO = null;
      CO.lost.then((OO => {
        hO = OO, console.error(`WebGPU device lost (${OO.reason}): ${OO.message}`)
      }));
      try {
        const pO = await async function(OO, KO, pO, XO, bK, eO) {
          const lO = (0, JO.d)(OO),
            vK = new Gl(OO, KO),
            CO = new qC(KO),
            hO = new ul(KO, vK, (OO => function(OO, KO) {
              for (const XO of UO(OO)) {
                var pO;
                if (XO._targetSignature === KO) return null !== (pO = XO._sceneBG) && void 0 !== pO ? pO : null
              }
              return null
            }(lO, OO))),
            DO = new TC(KO, vK);
          for (const oO of function(OO, KO, pO) {
              return [KO.opaqueRenderable, OO.opaqueRenderable, OO.skyLastRenderable, pO.renderable, KO.transparentRenderable, OO.transparentRenderable, OO.frontRenderable]
            }(hO, CO, DO)) kK(lO, oO);
          const MO = function(OO) {
            for (const KO of UO(OO))
              if ("Ce" === KO.name) return KO;
            throw new Error("Lite: the scene has no render task named scene")
          }(lO);
          bK && CO.installSceneDepth(MO, OO);
          const aK = eO ? new MC(KO, eO.entities) : null;
          CO.sunShadow = aK, aK && null !== eO && void 0 !== eO && eO.entities && (CO.shadowMask = new yC(KO, MO, OO, CO));
          return hO.sunShadow = aK, await (0, JO.f)(lO), new yh(OO, lO, MO, KO, CO, hO, DO, vK, pO, XO, aK)
        }(lO, CO, OO, bK, KO.sceneDepth, KO.sunShadow);
        if (null !== hO) {
          const {
            reason: OO,
            message: KO
          } = hO;
          throw Object.assign(new Error(`${gh} (${OO}): ${KO}`), {
            fallbackReason: gh
          })
        }
        return pO
      } catch (DO) {
        throw CO.destroy(), null === hO ? DO : uC(DO, "device")
      }
    }
  },
  38954: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => VO,
      E: () => oO,
      H: () => FO,
      b: () => bK,
      d: () => XO,
      g: () => aK,
      j: () => DO,
      m: () => LO,
      o: () => eO,
      s: () => vK,
      u: () => CO,
      x: () => lO
    });
    const XO = 3,
      bK = 0,
      eO = 1,
      lO = 2,
      vK = {
        uniform: 3,
        PK: 4,
        special: 5,
        volume: 6,
        sampler: 7,
        entities: 8,
        entityGrids: 9
      },
      CO = 10,
      hO = "BloxdPackInputs",
      DO = "bloxdPackInputs",
      MO = [{
        name: "seconds",
        type: "f32",
        offset: 0
      }, {
        name: "lit",
        type: "u32",
        offset: 4
      }, {
        name: "renderOffset",
        type: "vec3i",
        offset: 16
      }, {
        name: "sunDirection",
        type: "vec3f",
        offset: 32
      }, {
        name: "eyePosition",
        type: "vec3f",
        offset: 48
      }, {
        name: "shadowDirection",
        type: "vec3f",
        offset: 64
      }],
      aK = 80;

    function oO() {
      const OO = MO.map((OO => {
        let {
          name: KO,
          type: pO
        } = OO;
        return `    ${KO}: ${pO},\n`
      })).join("");
      return `struct ${hO} {\n${OO}}\n@group(${XO}) @binding(${bK}) var<uniform> ${DO}: ${hO};\n`
    }

    function FO(OO, KO) {
      const pO = new DataView(OO, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, aK),
        [XO, bK, eO, lO, vK, CO] = MO;
      pO.setFloat32(XO.offset, KO.seconds, !0), pO.setUint32(bK.offset, KO.lit ? 1 : 0, !0);
      for (let hO = 0; hO < 3; hO++) pO.setInt32(eO.offset + 4 * hO, KO.renderOffset[hO], !0), pO.setFloat32(lO.offset + 4 * hO, KO.xvO[hO], !0), pO.setFloat32(vK.offset + 4 * hO, KO.eyePosition[hO], !0), pO.setFloat32(CO.offset + 4 * hO, KO.shadowDirection[hO], !0)
    }

    function VO(OO) {
      const KO = new Uint32Array(Math.max(1, OO.length));
      return OO.forEach(((OO, pO) => {
        let {
          id: XO,
          rotation: bK
        } = OO;
        KO[pO] = 65535 & XO | (3 & bK) << 16
      })), KO
    }
    const LO = {
      off: 0,
      strict: 1,
      allow: 2
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);