export const id = 89;
export const ids = [89];
export const modules = {
  4035: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => aK
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(933),
      lO = pO(1180),
      vK = pO(2748),
      CO = pO(142),
      hO = pO(2780),
      DO = pO(2769),
      MO = pO(976);

    function aK(OO) {
      let {
        game: KO
      } = OO;
      const pO = (0, CO.o)() ? "large" : "small",
        XO = (0, hO.f)(KO, pO),
        aK = (0, vK.c)(XO),
        oO = void 0 !== aK.blurhash;
      return (0, MO.jsxs)("div", {
        className: "SchematicImageContainer",
        children: [aK.isLoading && !oO && (0, MO.jsx)(lO.e, {
          loaderType: "Secondary"
        }), !aK.failed && (null !== aK.src || oO) && (0, MO.jsx)("div", {
          className: bK()("SchematicImage", DO.m, {
            SchematicImageFadeIn: aK.fadeIn && !oO
          }),
          style: (0, DO.i)(aK),
          children: (0, MO.jsx)(DO.e, {
            image: aK
          })
        }), aK.failed && (0, MO.jsx)("div", {
          className: "SchematicImageError",
          children: (0, MO.jsx)(eO.d, {
            name: "face-dizzy"
          })
        })]
      })
    }
  },
  5656: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => HO
    });
    pO(4031);
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(243),
      vK = pO(892),
      CO = pO(1077),
      hO = pO(881),
      DO = pO(1051),
      MO = pO(1329),
      aK = pO(2789),
      oO = pO(1004),
      FO = pO(4035),
      VO = pO(2061),
      LO = pO(1271),
      QO = pO(3746),
      zK = pO(4041),
      AO = pO(1180),
      fO = pO(1344),
      dO = pO(3738),
      TO = pO(2020),
      NO = pO(4048),
      IO = pO(5560),
      yK = pO(1374),
      gK = pO(976);
    const uO = [{
        scope: "customGames",
        title: "studio:leaderboardCustomGames"
      }, {
        scope: "allGames",
        title: "studio:leaderboardAllGames"
      }, {
        scope: "dormantGames",
        title: "studio:leaderboardDormantGames"
      }],
      EO = 25,
      jK = "scope",
      YO = "category",
      wO = "customGames";
    const iK = 7,
      rK = {
        playsPerDay: null,
        avgPlaytimeMinutes: null,
        retention: null
      };

    function PO(OO) {
      let {
        position: KO
      } = OO;
      const pO = IO.e[KO];
      return (0, gK.jsxs)("td", {
        className: eO()("StudioLeaderboardPosition", {
          StudioLeaderboardTopPosition: void 0 !== pO,
          [`StudioLeaderboardTopPosition${KO}`]: void 0 !== pO
        }),
        children: [void 0 !== pO && (0, gK.jsx)("img", {
          className: "StudioLeaderboardPositionItem",
          src: pO,
          alt: ""
        }), KO]
      })
    }

    function mK(OO) {
      let {
        discoverability: KO
      } = OO;
      const {
        playsPerDay: pO,
        avgPlaytimeMinutes: bK,
        retention: eO
      } = null === KO ? rK : (0, aK.n)(KO);
      return (0, gK.jsxs)(XO.Fragment, {
        children: [(0, gK.jsx)("td", {
          children: null !== pO ? (0, aK.d)(pO) : "-"
        }), (0, gK.jsx)("td", {
          children: null !== bK ? (0, aK.h)(bK) : "-"
        }), (0, gK.jsx)("td", {
          children: null !== eO ? (0, aK.l)(eO) : "-"
        })]
      })
    }

    function sO(OO) {
      let {
        discoverability: KO
      } = OO;
      return (0, gK.jsx)("td", {
        className: "StudioLeaderboardEngagementScore",
        children: void 0 !== (null === KO || void 0 === KO ? void 0 : KO.engagementScore) ? (0, CO.L)(Math.round(KO.engagementScore)) : "-"
      })
    }

    function HO() {
      var OO, KO;
      const {
        t: pO
      } = (0, DO.D)(), bK = (0, fO.useNavigatePreserveSearch)(), {
        userContext: eO,
        isUserContextUpdating: IO
      } = (0, oO.d)(), rK = (0, TO.m)(), [HO, RO] = (0, dO.n)(), SO = (JO = HO.get(jK), uO.some((OO => OO.scope === JO)) ? JO : wO);
      var JO;
      const cK = function(OO) {
          return lO.P.includes(OO) ? OO : null
        }(HO.get(YO)),
        BO = (0, dO.f)(HO.get(dO.d)),
        [ZO, GO] = (0, XO.useState)(null),
        [qK, xK] = (0, XO.useState)(!1);

      function nO(OO) {
        RO((KO => {
          (0, dO.g)(KO, jK, OO.scope === wO ? null : OO.scope), (0, dO.g)(KO, YO, OO.category), (0, dO.k)(KO, OO.page)
        }))
      }
      const WO = !IO && eO.playerHasRank("developer"),
        tK = WO && "allGames" === SO,
        kK = WO && "dormantGames" === SO;
      (0, XO.useEffect)((() => {
        if (IO) return;
        let OO = !1;
        return GO(null), xK(!1), MO.c.getPublishedGamePreviews(eO, {
          searchQuery: null,
          pageNumber: BO,
          pageSize: EO,
          onlyFavouriteGames: !1,
          onlyOwnedGames: !1,
          onlyApprovedGames: !1,
          schematicIdsToExclude: [],
          gameCategories: null !== cK ? [cK] : [],
          upAndComing: !1,
          dormantGames: kK,
          sortByEngagementScore: !0,
          firstPartyGameNames: tK ? hO.d : void 0,
          includeOwners: !0
        }).then((KO => {
          OO || GO(KO)
        })).catch((KO => {
          console.error("Failed to load the studio leaderboard", KO), OO || xK(!0)
        })), () => {
          OO = !0
        }
      }), [IO, tK, kK, cK, BO, eO]);
      const UO = null !== (OO = null === ZO || void 0 === ZO ? void 0 : ZO.results) && void 0 !== OO ? OO : null,
        OK = function(OO, KO, pO) {
          const [bK, eO] = (0, XO.useState)({}), lO = pO ? (null !== OO && void 0 !== OO ? OO : []).flatMap((OO => "firstPartyGame" === OO.type ? [(0, vK.c)(OO.gameNameWithVariation, !0)] : [])).join(",") : "", CO = (0, XO.useMemo)((() => "" === lO ? [] : lO.split(",")), [lO]);
          return (0, XO.useEffect)((() => {
            if (0 === CO.length) return void eO({});
            let OO = !1;
            return MO.c.getGamesByAnalyticsIds(KO, CO).then((KO => {
              OO || eO(KO)
            })).catch((OO => {
              console.error("Failed to load first party discoverability for the studio leaderboard", OO)
            })), () => {
              OO = !0
            }
          }), [CO, KO]), bK
        }(UO, eO, WO),
        KK = null !== UO ? function(OO, KO, pO, XO, bK) {
          return OO.map(((OO, eO) => {
            var lO;
            const CO = XO + eO + 1;
            if ("customGame" === OO.type) {
              const KO = OO.preview;
              return {
                key: KO.schematicId,
                position: CO,
                thumbnail: (0, gK.jsx)(FO.b, {
                  game: KO
                }),
                name: KO.name,
                owner: OO.owner,
                category: KO.gameCategory,
                ccu: KO.ccu,
                favourites: KO.favourites,
                discoverability: (0, aK.q)(KO) ? KO : null,
                url: (0, yK.q)((0, vK.b)(KO.schematicId))
              }
            }
            const hO = OO.gameNameWithVariation,
              DO = (0, vK.c)(hO, !0);
            return {
              key: hO,
              position: CO,
              thumbnail: (0, gK.jsx)(NO.e, {
                game: hO
              }),
              name: (0, yK.m)(hO, bK),
              owner: null,
              category: (0, yK.c)(hO),
              ccu: (0, TO.b)(hO, KO),
              favourites: null,
              discoverability: null !== (lO = pO[DO]) && void 0 !== lO ? lO : null,
              url: (0, yK.q)(DO)
            }
          }))
        }(UO, rK, OK, (BO - 1) * EO, pO) : [],
        pK = !qK && null === ZO,
        XK = !pK && !qK && 0 === KK.length,
        bp = null !== (KO = null === ZO || void 0 === ZO ? void 0 : ZO.totalPages) && void 0 !== KO ? KO : 1;
      return (0, gK.jsxs)("div", {
        className: "StudioPage StudioLeaderboard",
        children: [(0, gK.jsx)("div", {
          className: "StudioPageHeader",
          children: (0, gK.jsx)("h1", {
            className: "StudioPageTitle",
            children: pO("studio:leaderboard")
          })
        }), (0, gK.jsxs)("div", {
          className: "StudioLeaderboardBanner",
          children: [!kK && (0, gK.jsx)("div", {
            children: pO("studio:leaderboardBanner")
          }), kK && (0, gK.jsx)("div", {
            children: pO("studio:leaderboardDormantBanner")
          }), (0, gK.jsx)("div", {
            children: pO("studio:leaderboardMetricsBanner", {
              days: iK
            })
          })]
        }), WO && (0, gK.jsx)("div", {
          className: "StudioLeaderboardScopes",
          children: uO.map((OO => (0, gK.jsx)(LO.S, {
            active: SO === OO.scope,
            onClick: () => {
              nO({
                scope: OO.scope,
                category: cK,
                page: 1
              })
            },
            children: pO(OO.title)
          }, OO.scope)))
        }), (0, gK.jsxs)("div", {
          className: "StudioLeaderboardCategories",
          children: [(0, gK.jsx)(LO.S, {
            active: null === cK,
            onClick: () => {
              nO({
                scope: SO,
                category: null,
                page: 1
              })
            },
            children: pO("studio:leaderboardAllCategories")
          }), lO.P.map((OO => (0, gK.jsx)(LO.S, {
            active: cK === OO,
            onClick: () => {
              nO({
                scope: SO,
                category: OO,
                page: 1
              })
            },
            children: (0, lO.cb)(OO)
          }, OO)))]
        }), pK && (0, gK.jsx)("div", {
          className: "StudioPageLoader AnimFadeIn",
          children: (0, gK.jsx)(AO.e, {})
        }), qK && (0, gK.jsx)("div", {
          className: "StudioPageMessage AnimFadeIn",
          children: pO("studio:failedToLoadLeaderboard")
        }), XK && (0, gK.jsx)("div", {
          className: "StudioPageMessage AnimFadeIn",
          children: pO("studio:leaderboardEmpty")
        }), !pK && !qK && !XK && (0, gK.jsx)("div", {
          className: "StudioLeaderboardTableScroll AnimFadeIn",
          children: (0, gK.jsx)(zK.c, {
            className: "StudioTable",
            columns: [{
              key: "position",
              header: "#"
            }, {
              key: "game",
              header: pO("general:game")
            }, {
              key: "owner",
              header: pO("general:owner")
            }, ...null === cK ? [{
              key: "category",
              header: pO("general:category")
            }] : [], ...WO ? [{
              key: "engagementScore",
              header: "engagementScore"
            }] : [], {
              key: "playsPerDay",
              header: pO("studio:leaderboardPlaysPerDay")
            }, {
              key: "sessionLength",
              header: pO("studio:leaderboardSessionLength")
            }, {
              key: "retention",
              header: pO("studio:leaderboardSessionsPerPlayer")
            }, ...kK ? [] : [{
              key: "ccu",
              header: pO("studio:metricCcu")
            }], {
              key: "favourites",
              header: pO("general:favourites")
            }],
            rows: KK,
            getRowKey: OO => OO.key,
            renderRow: OO => (0, gK.jsxs)("tr", {
              onClick: () => {
                bK(OO.url)
              },
              children: [(0, gK.jsx)(PO, {
                position: OO.position
              }), (0, gK.jsx)("td", {
                children: (0, gK.jsx)(NO.h, {
                  thumbnail: OO.thumbnail,
                  name: OO.name
                })
              }), (0, gK.jsxs)("td", {
                className: "StudioLeaderboardOwner",
                children: [null === OO.owner && "-", null !== OO.owner && (0, gK.jsx)(VO.h, {
                  playerSocialPreview: OO.owner,
                  showLocation: !1,
                  opensProfileCard: !1
                })]
              }), null === cK && (0, gK.jsx)("td", {
                children: (0, lO.cb)(OO.category)
              }), WO && (0, gK.jsx)(sO, {
                discoverability: OO.discoverability
              }), (0, gK.jsx)(mK, {
                discoverability: OO.discoverability
              }), !kK && (0, gK.jsx)("td", {
                children: null !== OO.ccu ? (0, CO.L)(OO.ccu) : "-"
              }), (0, gK.jsx)("td", {
                children: null !== OO.favourites ? (0, CO.L)(OO.favourites) : "-"
              })]
            })
          })
        }), !qK && (0, gK.jsx)(QO.e, {
          className: "AnimFadeIn",
          page: BO,
          totalPages: bp,
          onSetPage: OO => {
            nO({
              scope: SO,
              category: cK,
              page: OO
            })
          }
        })]
      })
    }
  },
  4048: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      h: () => eO
    });
    var XO = pO(1374),
      bK = pO(976);

    function eO(OO) {
      let {
        thumbnail: KO,
        name: pO
      } = OO;
      return (0, bK.jsxs)("div", {
        className: "StudioTableGameCell",
        children: [(0, bK.jsx)("div", {
          className: "StudioTableThumbnail",
          children: KO
        }), (0, bK.jsx)("span", {
          className: "StudioTableGameName",
          children: pO
        })]
      })
    }

    function lO(OO) {
      let {
        game: KO
      } = OO;
      return (0, bK.jsx)("img", {
        className: "StudioTableThumbnailImage",
        src: (0, XO.i)(KO),
        alt: ""
      })
    }
  },
  5560: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    const XO = {
      1: pO(5564),
      2: pO(5567),
      3: pO(5574)
    }
  },
  4041: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(976);

    function vK(OO) {
      let {
        columns: KO,
        rows: pO,
        getRowKey: bK,
        renderRow: vK,
        className: CO
      } = OO;
      return (0, lO.jsxs)("table", {
        className: eO()("Table", CO),
        children: [(0, lO.jsx)("thead", {
          children: (0, lO.jsx)("tr", {
            children: KO.map((OO => (0, lO.jsx)("th", {
              children: OO.header
            }, OO.key)))
          })
        }), (0, lO.jsx)("tbody", {
          children: pO.map((OO => (0, lO.jsx)(XO.Fragment, {
            children: vK(OO)
          }, bK(OO))))
        })]
      })
    }
  },
  4031: () => {},
  5564: OO => {
    OO.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAAXNSR0IArs4c6QAAAGVJREFUGJVjYKAZ4LF0YGBgYPiPhrErsn9/8v/Tv5//P/37+b/9+5NYFaMowqaYCaby2Z4fDAwMDAwO684xOKw7hyLGwMDAwIhmKlxSyoWD4aCgOVwNskK4YgYGBhRFuAB2HxMLAPX+QYFf3uJZAAAAAElFTkSuQmCC"
  },
  5567: OO => {
    OO.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAAAXNSR0IArs4c6QAAAKhJREFUOI1jYBhxgJGQAntrHgYGBgaGg0e//EcWDw0NZWRgYGBYvXo1inom6rkNAjBciMtFv18bQhhCEBexMqtgdSlNXYjXRbgAzKUws6juQhZ0AUIu+7HWA6+BtA9DuAthLtr/GatG3rA7WM2iXRiG+AkwMjAwMLCKnsfqUnQX2WhxMjIwMDAcufYdRZz2OSXET4CBgYGBYc2mDyjpEpeL0AHVXTgCAQAJXjDPnoKDuAAAAABJRU5ErkJggg=="
  },
  5574: OO => {
    OO.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAAAXNSR0IArs4c6QAAAK9JREFUOI3l0zEKwjAYhuE3QY+hWEWQ4lwovYE4WY+pDg7iBURwlrYgWtGD1EGCtk3aJZn6jV9+fh5CAp2LaBuY+zMArklW/PfreCUANttdaV7as31TE5pEyf0BwNQbAdCXUit1KmwUmaKkapd1Ya9atMn2h2PjQvdClVv+BCBNM+15vFxoe3fCKAwEgD8ZF/C7S5PIGw4EQP56uxXWfkoUBgCczpfSuzSJqrEu7GA+v28v0x7vVwcAAAAASUVORK5CYII="
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);