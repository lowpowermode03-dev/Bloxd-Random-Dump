export const id = 126;
export const ids = [126];
export const modules = {
  38855: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => RO,
      E: () => sO,
      H: () => SO,
      L: () => tK,
      O: () => BO,
      Q: () => cK,
      S: () => UO,
      T: () => qK,
      X: () => yK,
      e: () => kK,
      h: () => XK,
      k: () => GO,
      o: () => HO,
      q: () => WO,
      s: () => JO,
      t: () => nO,
      v: () => xK,
      w: () => pK
    });
    var XO = pO(243),
      bK = pO(219),
      eO = pO(226),
      lO = pO(22),
      vK = pO(2412),
      CO = pO(2256),
      hO = pO(2668),
      DO = pO(94),
      MO = pO(236),
      aK = pO(36),
      oO = pO(233),
      FO = pO(115),
      VO = pO(541),
      LO = pO(127),
      QO = pO(122),
      zK = pO(3943),
      AO = pO(38859),
      fO = pO(2373),
      dO = pO(38867);
    const TO = "bloxd-webgpuOffAfterLoss",
      NO = "context:webgl",
      IO = "probe:threw";

    function yK(OO) {
      let KO;
      try {
        KO = OO.getContext("webgl", {
          powerPreference: LO.d
        })
      } catch {
        KO = null
      }
      if (null === KO) return null;
      let pO = null;
      try {
        const OO = KO.getParameter(KO.MAX_TEXTURE_SIZE);
        pO = "number" === typeof OO && OO > 0 ? OO : null
      } catch {
        pO = null
      }
      try {
        var XO;
        null === (XO = KO.getExtension("WEBGL_lose_context")) || void 0 === XO || XO.loseContext()
      } catch {}
      return pO
    }
    const gK = new Set(["android_arm", "chromeos_other", "windows_intel_low"]),
      uO = "mali_valhall";

    function EO() {
      var OO;
      return {
        gpu: null !== (OO = navigator.gpu) && void 0 !== OO ? OO : null,
        webgl2: () => {
          try {
            return null !== document.createElement("canvas").getContext("webgl2")
          } catch {
            return !1
          }
        },
        webgl1: () => function(OO) {
          let KO, pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : AO.d;
          try {
            KO = OO.getContext("webgl")
          } catch {
            KO = null
          }
          if (null === KO) return [NO];
          const XO = [];
          try {
            for (const bK of pO.extensions) null === KO.getExtension(bK) && XO.push(bK);
            for (const [bK, eO] of Object.entries(pO.limits)) {
              const OO = KO[bK],
                pO = "number" === typeof OO ? KO.getParameter(OO) : null;
              ("number" !== typeof pO || pO < eO) && XO.push(`limit:${bK}`)
            }
            const OO = KO.getShaderPrecisionFormat(KO.VERTEX_SHADER, KO.HIGH_FLOAT);
            (null === OO || OO.precision < pO.vertexHighFloatBits) && XO.push("precision:vertex_high_float")
          } catch {
            XO.push(IO)
          }
          try {
            var bK;
            null === (bK = KO.getExtension("WEBGL_lose_context")) || void 0 === bK || bK.loseContext()
          } catch {}
          return XO
        }(document.createElement("canvas")),
        offAfterLoss: OO => YO((() => OO ? (0, oO.s)() : lO.d.isWebGpuOffAfterLoss())),
        oldIntelDriver: OO => YO((() => (0, FO.e)(OO))),
        intelGen9: OO => YO((() => (0, FO.h)(OO))),
        gpuClassWebGlArm: OO => function(OO) {
          try {
            return OO()
          } catch {
            return null
          }
        }((() => {
          var KO, pO, XO, lO;
          const vK = null !== (KO = null === (pO = OO.info) || void 0 === pO ? void 0 : pO.vendor) && void 0 !== KO ? KO : "";
          return "windows" === (0, DO.getOperatingSystem)() && "" !== vK && "intel" !== (0, DO.normaliseGpuVendor)(vK) ? null : ((0, DO.seedGpuVendor)(vK), CO = (0, bK.f)(), hO = (0, eO.g)(vK, null !== (XO = null === (lO = OO.info) || void 0 === lO ? void 0 : lO.architecture) && void 0 !== XO ? XO : ""), gK.has(CO) ? "android_arm" === CO && hO === uO ? "webgpu_default" : "webgl_default" : null);
          var CO, hO
        })),
        storeGpuClassVerdict: OO => {
          aK.e.setItem(FO.r, OO)
        },
        gpuClassOnWebGl: OO => (0, VO.c)(OO),
        override: () => jK(!0),
        webGpuSetting: () => {
          const OO = aK.e.getItem(XO.ic);
          return "boolean" === typeof OO ? OO : null
        },
        heldBack: () => VO.e,
        intelGen9OnWebGl: () => VO.h,
        hX: () => YO((() => (0, hO.c)(DO.featureFlags.settings.canUseShaderPacks)))
      }
    }

    function jK(OO) {
      if ((0, vK.q)("render") && "webgl1" === (0, vK.m)("renderer")) return "webgl1";
      const KO = [() => new URLSearchParams(window.location.search).get(CO.d), () => aK.e.getItem(CO.g), () => {
        const KO = localStorage.getItem(TO);
        return null !== KO && OO && localStorage.removeItem(TO), "1" === KO ? "webgl2" : null
      }];
      for (const pO of KO) {
        let OO = null;
        try {
          OO = wO(pO())
        } catch {}
        if (null !== OO) return OO
      }
      return null
    }

    function YO(OO) {
      try {
        return OO()
      } catch {
        return !1
      }
    }

    function wO(OO) {
      return "lite" === OO ? "webgpu" : "webgl2" === OO || "babylon" === OO ? "webgl" : null
    }
    async function iK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : EO();
      const KO = await async function(OO) {
        var KO, pO, XO, bK;
        const eO = PO(OO),
          {
            source: lO
          } = eO,
          vK = !eO.asked,
          CO = function(OO) {
            return {
              reason: OO,
              adapter: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
              source: lO
            }
          };
        if (!("gpu" in eO)) return CO(eO.refused);
        let hO;
        try {
          hO = await (0, fO.d)((0, QO.i)(eO.gpu), OK, `requestAdapter didn't settle in ${OK/1e3} s`)
        } catch {
          return CO("adapter_error")
        }
        if ("string" === typeof hO) return CO(hO);
        const DO = {
          vendor: null !== (KO = null === (pO = hO.info) || void 0 === pO ? void 0 : pO.vendor) && void 0 !== KO ? KO : "",
          architecture: null !== (XO = null === (bK = hO.info) || void 0 === bK ? void 0 : bK.architecture) && void 0 !== XO ? XO : ""
        };
        if ((0, QO.e)(hO)) return CO("software_adapter", DO);
        const MO = OO.intelGen9(hO),
          aK = MO ? null : OO.gpuClassWebGlArm(hO);
        if (OO.storeGpuClassVerdict(null !== aK && void 0 !== aK && aK), vK && OO.oldIntelDriver(hO)) return CO("old_intel_driver", DO);
        if ("default" === lO && OO.intelGen9OnWebGl() && MO) return CO("intel_gen9", DO);
        if ("default" === lO && null !== aK && OO.gpuClassOnWebGl(aK)) return CO("gpu_class_webgl", DO);
        return CO("none", DO)
      }(OO);
      if ("none" === KO.reason) return {
        backend: "webgpu",
        ...KO
      };
      if ("webgl1" !== OO.override() && OO.webgl2()) return {
        backend: "webgl",
        ...KO
      };
      const pO = OO.webgl1();
      return 0 === pO.length ? {
        backend: "webgl1",
        ...KO
      } : {
        missing: pO
      }
    }

    function rK(OO) {
      return "override" === OO || "setting" === OO
    }

    function PO(OO) {
      const KO = OO.override(),
        pO = OO.webGpuSetting(),
        XO = null !== KO ? "override" : !0 === pO ? "setting" : OO.hX() ? "pack" : !1 === pO ? "setting" : "default",
        bK = rK(XO);
      return "webgl" === KO || "webgl1" === KO || "setting" === XO && !1 === pO ? {
        source: XO,
        asked: bK,
        refused: "not_requested"
      } : OO.gpu ? "default" === XO && OO.heldBack() ? {
        source: XO,
        asked: bK,
        refused: "webgl_holdback"
      } : !bK && OO.offAfterLoss("pack" === XO) ? {
        source: XO,
        asked: bK,
        refused: "off_after_loss"
      } : {
        source: XO,
        asked: bK,
        gpu: OO.gpu
      } : {
        source: XO,
        asked: bK,
        refused: "no_webgpu_api"
      }
    }
    const mK = "bloxd-wasmLastPick";

    function sO(OO) {
      if ("override" === OO.source && "webgl1" === OO.backend) return;
      const KO = {
        backend: OO.backend,
        asked: rK(OO.source)
      };
      try {
        localStorage.setItem(mK, JSON.stringify(KO))
      } catch {}
    }

    function HO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
        ...EO(),
        override: () => jK(!1),
        webgl2Api: "undefined" !== typeof WebGL2RenderingContext,
        lastPick: () => {
          var OO, KO;
          let pO = null;
          try {
            var XO;
            pO = JSON.parse(null !== (XO = localStorage.getItem(mK)) && void 0 !== XO ? XO : "null")
          } catch {}
          const bK = null === (OO = pO) || void 0 === OO ? void 0 : OO.backend;
          return "webgpu" !== bK && "webgl" !== bK && "webgl1" !== bK || "boolean" !== typeof(null === (KO = pO) || void 0 === KO ? void 0 : KO.asked) ? null : {
            backend: bK,
            asked: pO.asked
          }
        }
      };
      if ("webgl1" === OO.override()) return "webgl1";
      const KO = OO.lastPick(),
        pO = PO(OO);
      return "gpu" in pO ? null !== KO && KO.asked === pO.asked ? KO.backend : "webgpu" : null !== KO && "webgpu" !== KO.backend ? KO.backend : OO.webgl2Api ? "webgl" : null
    }
    async function RO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : EO();
      if (null === OO) return null;
      const pO = await iK(KO);
      return "missing" in pO ? pO : {
        ...pO,
        load: OO[pO.backend]
      }
    }
    async function SO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : EO().gpu,
        pO = arguments.length > 2 ? arguments[2] : void 0;
      if ("webgpu" !== OO.backend) return !1;
      if (null !== OO.adapter && (0, FO.j)(OO.adapter, pO)) return !0;
      if (null === KO) return !1;
      try {
        var XO;
        const OO = await (0, fO.d)(KO.requestAdapter({
          powerPreference: "low-power"
        }), OK, `the low-power requestAdapter didn't settle in ${OK/1e3} s`);
        return (0, FO.j)(null !== (XO = null === OO || void 0 === OO ? void 0 : OO.info) && void 0 !== XO ? XO : {}, pO)
      } catch (bK) {
        return bK instanceof fO.b
      }
    }

    function JO(OO) {
      return null !== OO && "missing" in OO
    }

    function cK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : lO.d;
      try {
        const pO = KO.turnOffWebGpuAfterDeviceLoss("start_failed" === OO ? "visible" : (0, oO.i)((0, MO.h)()));
        return KO.isWebGpuOffAfterLoss() && "webgpu" === wO(aK.e.getItem(CO.g)) && aK.e.removeItem(CO.g), pO
      } catch {
        return !1
      }
    }

    function BO(OO) {
      return (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : !qK()) ? cK(OO) ? null : "storage won't keep WebGPU off" : "the URL asks for WebGPU"
    }
    const ZO = "framePacing";

    function GO(OO) {
      const KO = new URLSearchParams(OO).get(ZO);
      return null !== KO && /^\d{1,9}$/.test(KO) ? Number(KO) : void 0
    }

    function qK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : window.location.search;
      try {
        return "webgpu" === wO(new URLSearchParams(OO).get(CO.d))
      } catch {
        return !1
      }
    }

    function xK(OO) {
      return !!nO(OO) || OO instanceof Error && !(OO instanceof WebAssembly.RuntimeError) && OO.message.startsWith(`${zK.f.RenderSurfaceUnusable}:`)
    }

    function nO(OO) {
      const {
        name: KO,
        message: pO
      } = null !== OO && void 0 !== OO ? OO : {};
      return "InvalidStateError" === KO && "string" === typeof pO && pO.startsWith("GPUDevice.")
    }

    function WO(OO) {
      const KO = OO;
      return "function" === typeof KO.KaO && "function" === typeof KO.taO ? KO : null
    }

    function tK(OO) {
      return "function" === typeof OO.OaO ? OO : null
    }
    const kK = "openRenderer";

    function UO(OO) {
      const KO = null === OO || void 0 === OO ? void 0 : OO.laO();
      return void 0 === KO ? void 0 : new Error(KO)
    }
    const OK = 5e3,
      KK = 15e3;

    function pK(OO, KO, pO, XO, bK, eO) {
      return (0, fO.d)(function(OO, KO, pO, XO, bK, eO) {
        return (0, dO.f)(OO, KO, (() => OO.OaO(pO, XO, bK, eO.indirectHangs, eO.framesAhead)))
      }(OO, KO, pO, XO, bK, eO), KK, `${zK.f.RenderSurfaceUnusable}: the renderer didn't open in ${KK/1e3} s`, bp)
    }
    async function XK(OO, KO, pO, XO, bK, eO) {
      if ("function" !== typeof OO.OoO) throw new Error("this core has no set_renderer");
      const lO = await pK(KO, kK, pO, bK, XO, eO);
      try {
        OO.OoO(lO)
      } catch (vK) {
        throw bp(lO), vK
      }
    }

    function bp(OO) {
      try {
        OO.free()
      } catch {}
    }
  },
  38859: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    const XO = {
      extensions: ["ANGLE_instanced_arrays", "OES_vertex_array_object", "OES_element_index_uint", "OES_standard_derivatives"],
      limits: {
        MAX_VERTEX_ATTRIBS: 16,
        MAX_TEXTURE_SIZE: 2048,
        MAX_TEXTURE_IMAGE_UNITS: 8,
        MAX_VARYING_VECTORS: 8,
        MAX_VERTEX_UNIFORM_VECTORS: 128,
        MAX_FRAGMENT_UNIFORM_VECTORS: 34
      },
      vertexHighFloatBits: 23
    }
  },
  38867: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK,
      f: () => DO,
      h: () => lO,
      j: () => CO
    });
    var XO = pO(38871);
    class bK extends Error {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        super(`${OO}: the module trapped${pO?" in an earlier call":""}: ${String(KO)}`, {
          cause: KO
        }), this.site = OO, this.trap = KO, this.earlier = pO, this.name = "ModuleTrapError", KO instanceof Error && void 0 !== KO.stack && (this.stack = `${this.name}: ${this.message}\n${KO.stack}`)
      }
    }
    const eO = new WeakMap;

    function lO(OO) {
      return eO.has(OO)
    }

    function vK(OO, KO) {
      eO.has(OO) || eO.set(OO, KO)
    }

    function CO(OO, KO) {
      return !!(0, XO.c)(KO) && (vK(OO, KO), !0)
    }
    const hO = [
      ["error", OO => OO.error],
      ["unhandledrejection", OO => OO.reason]
    ];

    function DO(OO, KO, pO) {
      let lO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "function" === typeof globalThis.addEventListener ? globalThis : null;
      return eO.has(OO) ? Promise.reject(new bK(KO, eO.get(OO), !0)) : new Promise(((eO, CO) => {
        const DO = pO => {
            vK(OO, pO), oO(), CO(new bK(KO, pO))
          },
          MO = OO => {
            OO instanceof WebAssembly.RuntimeError ? DO(OO) : (oO(), CO(OO))
          },
          aK = hO.map((OO => {
            let [KO, pO] = OO;
            return [KO, OO => {
              const KO = pO(OO);
              (0, XO.c)(KO) && DO(KO)
            }]
          })),
          oO = () => {
            for (const [OO, KO] of aK) null === lO || void 0 === lO || lO.removeEventListener(OO, KO)
          };
        for (const [OO, KO] of aK) null === lO || void 0 === lO || lO.addEventListener(OO, KO);
        let FO;
        try {
          FO = pO()
        } catch (VO) {
          return void MO(VO)
        }
        FO.then((OO => {
          oO(), eO(OO)
        }), MO)
      }))
    }
  },
  38873: (OO, KO, pO) => {
    pO.d(KO, {
      C: () => gK,
      F: () => dO,
      H: () => IO,
      J: () => yK,
      e: () => fO,
      g: () => QO,
      h: () => uO,
      l: () => EO,
      m: () => LO,
      p: () => AO,
      s: () => FO,
      w: () => NO,
      z: () => YO
    });
    var XO = pO(22),
      bK = pO(236),
      eO = pO(38855),
      lO = pO(38878),
      vK = pO(38886);
    let CO = null,
      hO = () => {};
    const DO = new Promise((OO => {
        hO = OO
      })),
      MO = new Promise((() => {}));
    let aK = null,
      oO = null;

    function FO(OO) {
      oO = OO
    }
    let VO = !1;

    function LO() {
      VO = !0
    }

    function QO() {
      return VO
    }
    let zK = !1;

    function AO() {
      zK = !0
    }

    function fO() {
      return zK
    }

    function dO() {
      return oO
    }
    let TO = null;

    function NO(OO) {
      TO = OO, (0, bK.b)(OO)
    }

    function IO() {
      return TO
    }

    function yK() {
      return null === CO && ((0, bK.k)(), CO = (0, eO.A)(lO.f).then((OO => (null === OO || (0, eO.s)(OO) || (aK = vK.c[OO.backend], (0, eO.E)(OO), XO.d.followGameGpu("webgpu" === OO.backend ? OO.adapter : null)), OO))), hO(CO.catch((() => null)))), CO
    }

    function gK() {
      return aK
    }
    async function uO() {
      if (null !== CO) {
        const OO = await CO;
        return (0, eO.s)(OO) ? null : {
          build: await EO(OO),
          superseded: MO
        }
      }
      if (null === lO.f) return {
        build: await EO(null),
        superseded: MO
      };
      const OO = (0, eO.o)();
      if (null === OO) return null;
      const KO = await lO.f[OO]();
      if (null !== CO) return null;
      return {
        build: KO,
        superseded: DO.then((KO => null === KO || (0, eO.s)(KO) || KO.backend !== OO ? void 0 : MO))
      }
    }

    function EO(OO) {
      return OO ? OO.load() : Promise.resolve().then((function() {
        var OO = new Error("Cannot find module '@bloxd/wasm/client'");
        throw OO.code = "MODULE_NOT_FOUND", OO
      })).then((OO => OO.bloxdWasmClient))
    }
    let jK = null;

    function YO() {
      return jK ??= yK().then((async OO => ({
        indirectHangs: null !== OO && !(0, eO.s)(OO) && await (0, eO.H)(OO),
        framesAhead: (0, eO.k)(window.location.search)
      }))), jK
    }
  },
  38886: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO
    });
    const XO = {
      webgpu: "rust_webgpu",
      webgl: "rust_webgl2",
      webgl1: "rust_webgl1"
    }
  },
  38878: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK,
      f: () => XO
    });
    const XO = {
        webgpu: async () => (await pO.e(8).then((() => pO(41268)))).bloxdWasmWebgpu,
        webgl: async () => (await pO.e(6).then((() => pO(41280)))).bloxdWasmWebgl,
        webgl1: async () => (await pO.e(7).then((() => pO(41287)))).bloxdWasmWebgl1
      },
      bK = async () => (await pO.e(5).then((() => pO(41299)))).compileAnimationPackInWasm
  },
  38871: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      d: () => lO
    });
    const XO = /wasm-function\[\d+\]|wasm:\/\/|\[wasm code\]/;

    function bK(OO) {
      if (OO instanceof WebAssembly.RuntimeError) return !0;
      const KO = OO instanceof Error ? OO.stack : void 0;
      return "string" === typeof KO && XO.test(KO)
    }
    const eO = 500;

    function lO(OO) {
      let KO = "[object Object]";
      try {
        KO = String(OO)
      } catch {}
      if ("[object Object]" !== KO) return KO;
      try {
        var pO, XO;
        return null !== (pO = null === (XO = JSON.stringify(OO)) || void 0 === XO ? void 0 : XO.slice(0, eO)) && void 0 !== pO ? pO : KO
      } catch {
        return KO
      }
    }
  },
  38852: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_models_bg.a24fdeb1ea4454f3d1d7.wasm"
  },
  38847: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_workers_bg.5800fbd50e2b78ab89a0.wasm"
  },
  34910: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => aK,
      h: () => DO
    });
    var XO = pO(2947),
      bK = pO(2951),
      eO = pO(2959),
      lO = pO(5747),
      vK = pO(5754);
    let CO = null,
      hO = !1;

    function DO(OO, KO, pO) {
      return null === CO ? CO = MO(OO, KO) : OO !== CO.build ? console.warn(`Bloxd wasm: ${OO.name} was asked for after ${CO.build.name} started loading, which this thread keeps`) : KO.name !== CO.workers.name && console.warn(`Bloxd wasm: ${KO.name} was asked for workers after ${CO.workers.name}, which this thread keeps`), pO?.reloadFailedDownload && !hO && (0, XO.$)() && (hO = !0, CO = MO(CO.build, CO.workers)), CO.loaded
    }

    function MO(OO, KO) {
      const pO = (0, XO.K)((async () => {
        (0, vK.z)();
        const pO = oO(OO),
          XO = KO.name === OO.name ? pO : oO(KO);
        await (0, eO.f)([pO, XO]);
        const bK = await pO,
          lO = await XO;
        return (0, vK.z)(), {
          module: bK,
          workerModule: lO
        }
      }), OO);
      return {
        build: OO,
        workers: KO,
        loaded: pO
      }
    }
    async function aK(OO) {
      return oO(OO)
    }

    function oO(OO) {
      return (0, bK.x)(OO.url(), (0, lO.e)(OO.name))
    }
  },
  38841: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      e: () => XO
    });
    const XO = {
      name: "bloxd_wasm_workers",
      url: function() {
        return new pO.U(pO(38847))
      }
    };
    const bK = {
      name: "bloxd_wasm_models",
      url: function() {
        return new pO.U(pO(38852))
      }
    }
  },
  5747: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(2951);
    const bK = {
      bloxd_wasm: () => "ac9f597375b38c338329c51c36d32b24f862e44eebff0f4b8070bfff0ce24e92",
      bloxd_wasm_client: () => "e981deecce97c0a28139db7f8c487a2f1f307b3295318edfa657ecf781f0bce4",
      bloxd_wasm_workers: () => "11a4c5ee562d561d1a564ae8ce4086cba4f264a242fa24e0ae9cdfd0bb313186",
      bloxd_wasm_models: () => "bee0165155b97fd136a7cf0dedea22e1a110c87d8e70a67ca6e7edc58b55e8c7",
      bloxd_wasm_webgpu: () => "4b4c96cc3f4d3f9fc4a3ff616e4c50aa2c87d4131077e77b476abf6704ec291f",
      bloxd_wasm_webgl: () => "c0bb33a3813b8b5918333de6d7e2622ae319a2c772f31975c56b5febf114b7c8",
      bloxd_wasm_webgl1: () => "971c025c2fdfbded0d795677b38da6ca90549b67af60539fae327208414e3132",
      bloxd_wasm_replay: () => "0cb774dff0a4b55ce86f8d87aef4bc59eda1d7a7c4e4115b219a9e7a09e651bf",
      bloxd_wasm_recorder: () => "82c26252e3c6033837d798c44d8bb77c08b2a095b569b6a2ed41666d348b5fa6",
      bloxd_wasm_anim: () => "fc31b88580a805317f744c8d79a3dc71a8b7a05a63ab0e8adfe930888a0cdb3e",
      bloxd_wasm_textures: () => "faf92bedf683183467afa4b668afe838fc10ad79c6cbb331d3174649bb18c10f",
      bloxd_wasm_shader_pack: () => "6cae04de4f8b271d5581ecd7685547570539fb61ec6bee0be5bb136267b6d774"
    };
    var eO = pO(5754);

    function lO(OO) {
      const KO = Object.prototype.hasOwnProperty.call(bK, OO) ? bK[OO]() : void 0;
      if (void 0 !== KO) return {
        sha256: KO,
        onMismatch: eO.v
      };
      throw new XO.l(`${OO} has no release digest, so this build refuses it`)
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);