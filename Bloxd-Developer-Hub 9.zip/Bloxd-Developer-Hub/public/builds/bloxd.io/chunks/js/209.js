export const id = 209;
export const ids = [209];
export const modules = {
  59074: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      DEVTOOLS_SHADERS: () => eO,
      registerDevtoolsShader: () => lO
    });
    var XO = pO(37907),
      bK = pO(35552);
    const eO = {
      devtoolsNormal: function(OO) {
        return {
          vertex: `\n\t\t\t${(0,bK.h)(OO,"position","vec3")}\n\t\t\t${(0,bK.h)(OO,"normal","vec3")}\n\t\t\t${(0,bK.Bb)(OO,"worldViewProjection","mat4")}\n\t\t\t${(0,bK.Bb)(OO,"world","mat4")}\n\t\t\t${(0,bK.Db)(OO,"vNormal","vec3","mediump")}\n\n\t\t\t${(0,bK.Hb)(OO,`\n\t\t\t\t${(0,bK.m)(OO)} = ${(0,bK.Cb)(OO,"worldViewProjection")} * ${(0,bK.q)(OO,"vec4",(0,bK.Lb)(OO,"position"),"1.0")};\n\t\t\t\t${(0,bK.Nb)(OO,"vNormal")} = normalize((${(0,bK.Cb)(OO,"world")} * ${(0,bK.q)(OO,"vec4",(0,bK.Lb)(OO,"normal"),"0.0")}).xyz);\n\t\t\t`)}\n\t\t`,
          fragment: `\n\t\t\t${(0,bK.Db)(OO,"vNormal","vec3","mediump")}\n\n\t\t\t${(0,bK.W)(OO,`\n\t\t\t\t\n\t\t\t\t${(0,bK.I)(OO,"vec3","normalColor",`abs(${(0,bK._)(OO,"vNormal")})`)}\n\t\t\t\t${(0,bK.S)(OO)} = ${(0,bK.q)(OO,"vec4","normalColor","1.0")};\n\t\t\t`)}\n\t\t`
        }
      },
      devtoolsWhite: function(OO) {
        return {
          vertex: `\n\t\t\t${(0,bK.h)(OO,"position","vec3")}\n\t\t\t${(0,bK.Bb)(OO,"worldViewProjection","mat4")}\n\n\t\t\t${(0,bK.Hb)(OO,`\n\t\t\t\t${(0,bK.m)(OO)} = ${(0,bK.Cb)(OO,"worldViewProjection")} * ${(0,bK.q)(OO,"vec4",(0,bK.Lb)(OO,"position"),"1.0")};\n\t\t\t`)}\n\t\t`,
          fragment: `\n\t\t\t${(0,bK.W)(OO,`\n\t\t\t\t${(0,bK.S)(OO)} = ${(0,bK.q)(OO,"vec4","1.0","1.0","1.0","1.0")};\n\t\t\t`)}\n\t\t`
        }
      },
      devtoolsDepth: function(OO) {
        return {
          vertex: `\n\t\t\t${(0,bK.h)(OO,"position","vec3")}\n\t\t\t${(0,bK.Bb)(OO,"worldViewProjection","mat4")}\n\t\t\t${(0,bK.Bb)(OO,"world","mat4")}\n\t\t\t${(0,bK.Bb)(OO,"cameraPosition","vec3")}\n\t\t\t${(0,bK.Db)(OO,"vDepth","float","mediump")}\n\n\t\t\t${(0,bK.Hb)(OO,`\n\t\t\t\t${(0,bK.m)(OO)} = ${(0,bK.Cb)(OO,"worldViewProjection")} * ${(0,bK.q)(OO,"vec4",(0,bK.Lb)(OO,"position"),"1.0")};\n\t\t\t\t${(0,bK.I)(OO,"vec3","worldPosition",`(${(0,bK.Cb)(OO,"world")} * ${(0,bK.q)(OO,"vec4",(0,bK.Lb)(OO,"position"),"1.0")}).xyz`)}\n\t\t\t\t${(0,bK.Nb)(OO,"vDepth")} = distance(worldPosition, ${(0,bK.Cb)(OO,"cameraPosition")});\n\t\t\t`)}\n\t\t`,
          fragment: `\n\t\t\t${(0,bK.Db)(OO,"vDepth","float","mediump")}\n\t\t\t${(0,bK.Bb)(OO,"maxDepth","float")}\n\t\t\t${(0,bK.Bb)(OO,"minDepth","float")}\n\n\t\t\t${(0,bK.W)(OO,`\n\t\t\t\t\n\t\t\t\t${(0,bK.I)(OO,"float","normalizedDepth",`clamp((${(0,bK._)(OO,"vDepth")} - ${(0,bK.Cb)(OO,"minDepth")}) / (${(0,bK.Cb)(OO,"maxDepth")} - ${(0,bK.Cb)(OO,"minDepth")}), 0.0, 1.0)`)}\n\t\t\t\t${(0,bK.I)(OO,"float","gray","1.0 - normalizedDepth")}\n\t\t\t\t${(0,bK.S)(OO)} = ${(0,bK.q)(OO,"vec4","gray","gray","gray","1.0")};\n\t\t\t`)}\n\t\t`
        }
      }
    };

    function lO(OO, KO) {
      const {
        vertex: pO,
        fragment: bK
      } = eO[OO](KO), lO = XO.b.GetShadersStore(KO);
      lO[`${OO}VertexShader`] = pO, lO[`${OO}FragmentShader`] = bK
    }
  },
  35552: (OO, KO, pO) => {
    pO.d(KO, {
      $: () => YO,
      Bb: () => QO,
      Cb: () => jK,
      D: () => oO,
      Db: () => LO,
      H: () => MO,
      Hb: () => AO,
      I: () => DO,
      Lb: () => gK,
      M: () => IO,
      Nb: () => uO,
      Q: () => wO,
      R: () => eO,
      S: () => PO,
      T: () => rK,
      W: () => fO,
      _: () => EO,
      bb: () => HO,
      cb: () => bK,
      e: () => XO,
      fb: () => iK,
      h: () => VO,
      hb: () => SO,
      i: () => yK,
      ib: () => cK,
      lb: () => NO,
      m: () => zK,
      pb: () => TO,
      q: () => CO,
      qb: () => JO,
      rb: () => BO,
      t: () => mK,
      tb: () => RO,
      wb: () => dO,
      x: () => sO,
      z: () => aK,
      zb: () => hO
    });
    const XO = {
      GLSL: 0,
      WGSL: 1
    };

    function bK(OO) {
      return OO === XO.WGSL
    }

    function eO(OO, KO, pO) {
      return bK(OO) ? pO : KO
    }
    const lO = new Map([
      ["int", "i32"],
      ["float", "f32"],
      ["vec2", "vec2f"],
      ["vec3", "vec3f"],
      ["vec4", "vec4f"],
      ["mat2", "mat2x2f"],
      ["mat3", "mat3x3f"],
      ["mat4", "mat4x4f"]
    ]);

    function vK(OO, KO) {
      if (!bK(OO)) return KO;
      const pO = lO.get(KO);
      if (!pO) throw new Error(`No WGSL name for shader type "${KO}"`);
      return pO
    }

    function CO(OO, KO) {
      for (var pO = arguments.length, XO = new Array(pO > 2 ? pO - 2 : 0), bK = 2; bK < pO; bK++) XO[bK - 2] = arguments[bK];
      return `${vK(OO,KO)}(${XO.join(", ")})`
    }

    function hO(OO, KO) {
      return CO(OO, "int", KO)
    }

    function DO(OO, KO, pO, XO, eO) {
      return bK(OO) ? `var ${pO}: ${vK(OO,KO)} = ${XO};` : `${FO(OO,eO)}${KO} ${pO} = ${XO};`
    }

    function MO(OO, KO, pO) {
      return bK(OO) ? `var ${pO}: ${vK(OO,KO)};` : `${KO} ${pO};`
    }

    function aK(OO, KO, pO, XO) {
      return bK(OO) ? `const ${pO}: ${vK(OO,KO)} = ${XO};` : `const ${KO} ${pO} = ${XO};`
    }

    function oO(OO, KO, pO, XO, eO) {
      if (bK(OO)) {
        return `fn ${pO}(${XO.map((KO=>`${KO.name}: ${vK(OO,KO.type)}`)).join(", ")}) -> ${vK(OO,KO)} {${eO}}`
      }
      return `${KO} ${pO}(${XO.map((OO=>`${OO.type} ${OO.name}`)).join(", ")}) {${eO}}`
    }

    function FO(OO, KO) {
      return !KO || bK(OO) ? "" : `${KO} `
    }

    function VO(OO, KO, pO, XO) {
      return bK(OO) ? `attribute ${KO}: ${vK(OO,pO)};` : `attribute ${FO(OO,XO)}${pO} ${KO};`
    }

    function LO(OO, KO, pO, XO) {
      return bK(OO) ? `varying ${KO}: ${vK(OO,pO)};` : `varying ${FO(OO,XO)}${pO} ${KO};`
    }

    function QO(OO, KO, pO) {
      return bK(OO) ? `uniform ${KO}: ${vK(OO,pO)};` : `uniform ${pO} ${KO};`
    }

    function zK(OO) {
      return bK(OO) ? "vertexOutputs.position" : "gl_Position"
    }

    function AO(OO, KO) {
      return bK(OO) ? `@vertex\nfn main(input: VertexInputs) -> FragmentInputs {${KO}}` : `void main() {${KO}}`
    }

    function fO(OO, KO) {
      return bK(OO) ? `@fragment\nfn main(input: FragmentInputs) -> FragmentOutputs {${KO}}` : `void main() {${KO}}`
    }

    function dO(OO, KO, pO) {
      if (bK(OO)) {
        return [`var ${KO}Sampler: sampler;`, `var ${KO}: ${"2dArray"===pO?"texture_2d_array<f32>":"texture_2d<f32>"};`].join("\n")
      }
      return `uniform highp ${"2dArray"===pO?"sampler2DArray":"sampler2D"} ${KO};`
    }

    function TO(OO, KO, pO) {
      return bK(OO) ? `textureSample(${KO}, ${KO}Sampler, ${pO})` : `texture2D(${KO}, ${pO})`
    }

    function NO(OO, KO, pO, XO, eO) {
      if (bK(OO)) {
        return `${eO?"textureSampleLevel":"textureSample"}(${KO}, ${KO}Sampler, ${pO}, ${hO(OO,`round(${XO})`)}${eO?`, ${eO}`:""})`
      }
      const lO = CO(OO, "vec3", pO, XO);
      return eO ? `textureLod(${KO}, ${lO}, ${eO})` : `texture(${KO}, ${lO})`
    }

    function IO(OO) {
      return bK(OO) ? "!baseColor\\=\\w+\\(diffuseSampler,diffuseSamplerSampler,fragmentInputs\\.vDiffuseUV\\+uvOffset\\);" : "!baseColor\\=\\w+\\(diffuseSampler,vDiffuseUV\\+uvOffset\\);"
    }

    function yK(OO) {
      return bK(OO) ? {
        "!varying vMainUV1: vec2f;": "centroid varying vMainUV1: vec2f;"
      } : {
        "!varying vec2 vMainUV1;": "#ifdef WEBGL2\ncentroid varying vec2 vMainUV1;\n#else\nvarying vec2 vMainUV1;\n#endif"
      }
    }

    function gK(OO, KO) {
      return bK(OO) ? `vertexInputs.${KO}` : KO
    }

    function uO(OO, KO) {
      return bK(OO) ? `vertexOutputs.${KO}` : KO
    }

    function EO(OO, KO) {
      return bK(OO) ? `fragmentInputs.${KO}` : KO
    }

    function jK(OO, KO) {
      return bK(OO) ? `uniforms.${KO}` : KO
    }

    function YO(OO, KO, pO) {
      return bK(OO) ? `frame.${KO}` : pO
    }

    function wO(OO) {
      return bK(OO) ? "scene.vEyePosition" : "vEyePosition"
    }

    function iK(OO) {
      return bK(OO) ? "mesh.visibility" : "visibility"
    }

    function rK(OO) {
      return bK(OO) ? "fragmentInputs.position" : "gl_FragCoord"
    }

    function PO(OO) {
      return bK(OO) ? "fragmentOutputs.color" : "gl_FragColor"
    }

    function mK(OO, KO) {
      return bK(OO) ? `dpdx(${KO})` : `dFdx(${KO})`
    }

    function sO(OO, KO) {
      return bK(OO) ? `dpdy(${KO})` : `dFdy(${KO})`
    }

    function HO(OO, KO) {
      return bK(OO) ? `inverseSqrt(${KO})` : `inversesqrt(${KO})`
    }

    function RO(OO, KO, pO, XO) {
      return bK(OO) ? `select(${XO}, ${pO}, ${KO})` : `((${KO}) ? (${pO}) : (${XO}))`
    }

    function SO(OO, KO, pO) {
      return bK(OO) ? `((${KO}) - (${pO}) * floor((${KO}) / (${pO})))` : `mod(${KO}, ${pO})`
    }

    function JO(OO, KO, pO) {
      return bK(OO) ? `${KO} = vec4f(${pO}, ${KO}.a);` : `${KO}.rgb = ${pO};`
    }

    function cK(OO, KO, pO) {
      return bK(OO) ? `${KO} = vec4f(${KO}.rgb * (${pO}), ${KO}.a);` : `${KO}.rgb *= ${pO};`
    }

    function BO(OO, KO, pO) {
      return bK(OO) ? `${KO} = vec4f(${pO}, ${KO}.w);` : `${KO}.xyz = ${pO};`
    }
  },
  37907: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      static GetShadersRepository() {
        return 0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0) ? XO.ShadersRepository : XO.ShadersRepositoryWGSL
      }
      static GetShadersStore() {
        return 0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0) ? XO.ShadersStore : XO.ShadersStoreWGSL
      }
      static GetIncludesShadersStore() {
        return 0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0) ? XO.IncludesShadersStore : XO.IncludesShadersStoreWGSL
      }
    }
    XO.ShadersRepository = "src/Shaders/", XO.ShadersStore = {}, XO.IncludesShadersStore = {}, XO.ShadersRepositoryWGSL = "src/ShadersWGSL/", XO.ShadersStoreWGSL = {}, XO.IncludesShadersStoreWGSL = {}
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);