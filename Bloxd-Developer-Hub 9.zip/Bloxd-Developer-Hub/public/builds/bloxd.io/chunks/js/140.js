export const id = 140;
export const ids = [140];
export const modules = {
  7218: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      AdinPlaySdkAdaptor: () => lO
    });
    var XO = pO(1158),
      bK = pO(1044);
    const eO = ["CN", "VN", "IN", "PK", "ID", "EG", "BD", "SV", "DZ", "EC", "VE", "UA", "MA", "LK", "NG", "BO", "KE", "TN", "RU", "NP", "IQ", "MM", "HN", "UY", "JO", "PY", "PS", "ET", "GH", "JM", "CM", "AS", "SY", "BY", "AO", "MN", "GY", "LB", "MV", "BW", "UG"];
    class lO extends XO.c {
      constructor() {
        super(), this.name = "adinplay", this.bannerAutoRefresh = "disableable", this.noAdCountries = eO
      }
      static async setup() {
        return await (0, bK.e)("https://api.adinplay.com/libs/aiptag/pub/RBN/bloxd.io/tag.min.js"), new lO
      }
      playRewarded(OO, KO) {
        if ("undefined" !== typeof window.aiptag.adplayer) {
          console.log("AD: Requesting AdInPlay preroll ad for rewarded placement");
          const pO = "video_reward";
          window.aiptag.cmd.player.push((function() {
            window.aiptag.adplayer.startPreRoll({
              alias: pO
            })
          })), window.adStartSoPause(OO, {
            onFailCb: KO
          })
        } else console.log("AD: AIP ad lib not loaded, no rewarded ad playing"), KO()
      }
      playVideoAd(OO, KO) {
        "undefined" !== typeof window.aiptag.adplayer ? (console.log("AD: Requesting AdInPlay video ad" + (KO ? ` (alias: ${KO})` : "")), window.aiptag.cmd.player.push((function() {
          window.aiptag.adplayer.startPreRoll({
            alias: KO
          })
        })), window.adStartSoPause(OO)) : (OO(), console.error("AIP ad lib not loaded, no ad playing"))
      }
      renderBanner(OO) {
        if ("undefined" === typeof window.aiptag.adplayer) return void console.log("AD: User has adblock, not requesting new banners");
        const {
          divId: KO,
          alias: pO
        } = OO;
        window.aiptag.cmd.display.push((function() {
          window.aipDisplayTag.display({
            adUnitName: KO,
            alias: pO
          })
        })), console.log("AD: Requested aip banner", document.getElementById(OO.divId), pO ? `(alias: ${pO})` : "")
      }
      clearBanner(OO) {
        "undefined" !== typeof window.aiptag.adplayer ? (window.aiptag.cmd.display.push((function() {
          window.aipDisplayTag.destroy(OO.divId)
        })), console.log(`AD: Clearing aip banner ad ${OO.divId}`)) : console.log("AD: User has adblock, not requesting new banners")
      }
      setBannerAutoRefreshEnabled(OO, KO) {
        window.aiptag.cmd.display.push((function() {
          window.aipDisplayTag.setAutoRefresh(OO.divId, KO)
        }))
      }
      newPageSession() {
        console.log("AD: Requesting new page session"), window.aiptag.cmd.display.push((function() {
          window.__VM.push((function(OO, KO) {
            KO.Instances.pageManager.newPageSession(!1)
          }))
        }))
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);