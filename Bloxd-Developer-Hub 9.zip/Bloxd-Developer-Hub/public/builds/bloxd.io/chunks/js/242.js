export const id = 242;
export const ids = [242];
export const modules = {
  38496: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(38068);

    function bK(OO) {
      return class extends OO {
        constructor() {
          super(...arguments);
          const OO = new.target;
          if (!OO[Symbol.metadata]) {
            const KO = Object.getPrototypeOf(OO)?.[Symbol.metadata];
            OO[Symbol.metadata] = KO ? Object.create(KO) : {}
          }
          const KO = (0, XO.d)(OO[Symbol.metadata]);
          KO._imageProcessingConfiguration || (KO._imageProcessingConfiguration = {
            type: 9,
            sourceName: void 0
          })
        }
        get imageProcessingConfiguration() {
          return this._imageProcessingConfiguration
        }
        set imageProcessingConfiguration(OO) {
          this._attachImageProcessingConfiguration(OO), this._markAllSubMeshesAsImageProcessingDirty && this._markAllSubMeshesAsImageProcessingDirty()
        }
        _attachImageProcessingConfiguration(OO) {
          OO !== this._imageProcessingConfiguration && (this._imageProcessingConfiguration && this._imageProcessingObserver && this._imageProcessingConfiguration.onUpdateParameters.remove(this._imageProcessingObserver), !OO && this.JKO ? this._imageProcessingConfiguration = this.JKO().imageProcessingConfiguration : OO && (this._imageProcessingConfiguration = OO), this._imageProcessingConfiguration && (this._imageProcessingObserver = this._imageProcessingConfiguration.onUpdateParameters.add((() => {
            this._markAllSubMeshesAsImageProcessingDirty && this._markAllSubMeshesAsImageProcessingDirty()
          }))))
        }
        get cameraColorCurvesEnabled() {
          return this.imageProcessingConfiguration.colorCurvesEnabled
        }
        set cameraColorCurvesEnabled(OO) {
          this.imageProcessingConfiguration.colorCurvesEnabled = OO
        }
        get cameraColorGradingEnabled() {
          return this.imageProcessingConfiguration.colorGradingEnabled
        }
        set cameraColorGradingEnabled(OO) {
          this.imageProcessingConfiguration.colorGradingEnabled = OO
        }
        get cameraToneMappingEnabled() {
          return this._imageProcessingConfiguration.toneMappingEnabled
        }
        set cameraToneMappingEnabled(OO) {
          this._imageProcessingConfiguration.toneMappingEnabled = OO
        }
        get cameraExposure() {
          return this._imageProcessingConfiguration.exposure
        }
        set cameraExposure(OO) {
          this._imageProcessingConfiguration.exposure = OO
        }
        get cameraContrast() {
          return this._imageProcessingConfiguration.contrast
        }
        set cameraContrast(OO) {
          this._imageProcessingConfiguration.contrast = OO
        }
        get cameraColorGradingTexture() {
          return this._imageProcessingConfiguration.colorGradingTexture
        }
        set cameraColorGradingTexture(OO) {
          this._imageProcessingConfiguration.colorGradingTexture = OO
        }
        get cameraColorCurves() {
          return this._imageProcessingConfiguration.colorCurves
        }
        set cameraColorCurves(OO) {
          this._imageProcessingConfiguration.colorCurves = OO
        }
      }
    }
  },
  38371: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      f: () => bK
    });
    var XO = pO(38378);

    function bK(OO) {
      return class extends OO {
        constructor() {
          super(...arguments), this.IMAGEPROCESSING = !1, this.WHITEBALANCE = !1, this.VIGNETTE = !1, this.VIGNETTEBLENDMODEMULTIPLY = !1, this.VIGNETTEBLENDMODEOPAQUE = !1, this.TONEMAPPING = 0, this.CONTRAST = !1, this.COLORCURVES = !1, this.COLORGRADING = !1, this.COLORGRADING3D = !1, this.SAMPLER3DGREENDEPTH = !1, this.SAMPLER3DBGRMAP = !1, this.DITHER = !1, this.IMAGEPROCESSINGPOSTPROCESS = !1, this.SKIPFINALCOLORCLAMP = !1, this.EXPOSURE = !1
        }
      }
    }
    class eO extends XO.e {
      constructor() {
        super(), this.IMAGEPROCESSING = !1, this.WHITEBALANCE = !1, this.VIGNETTE = !1, this.VIGNETTEBLENDMODEMULTIPLY = !1, this.VIGNETTEBLENDMODEOPAQUE = !1, this.TONEMAPPING = 0, this.CONTRAST = !1, this.COLORCURVES = !1, this.COLORGRADING = !1, this.COLORGRADING3D = !1, this.SAMPLER3DGREENDEPTH = !1, this.SAMPLER3DBGRMAP = !1, this.DITHER = !1, this.IMAGEPROCESSINGPOSTPROCESS = !1, this.EXPOSURE = !1, this.SKIPFINALCOLORCLAMP = !1, this.rebuild()
      }
    }
  },
  38452: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => MO
    });
    var XO = pO(38063),
      bK = pO(38382),
      eO = pO(38066),
      lO = pO(38439),
      vK = pO(38378),
      CO = pO(38456),
      hO = pO(38424);
    class DO extends vK.e {
      constructor() {
        super(...arguments), this.DETAIL = !1, this.DETAILDIRECTUV = 0, this.DETAIL_NORMALBLENDMETHOD = 0
      }
    }
    let MO = (() => {
      var OO, KO, pO, vK;
      let MO, aK, oO, FO, VO, LO, QO = CO.c,
        zK = [],
        AO = [],
        fO = [],
        dO = [],
        TO = [],
        NO = [],
        IO = [],
        yK = [],
        gK = [],
        uO = [],
        EO = [],
        jK = [];
      return OO = class extends QO {
        get texture() {
          return (0, XO.b)(this, KO, "f")
        }
        set texture(OO) {
          (0, XO.e)(this, KO, OO, "f")
        }
        get normalBlendMethod() {
          return (0, XO.b)(this, pO, "f")
        }
        set normalBlendMethod(OO) {
          (0, XO.e)(this, pO, OO, "f")
        }
        get isEnabled() {
          return (0, XO.b)(this, vK, "f")
        }
        set isEnabled(OO) {
          (0, XO.e)(this, vK, OO, "f")
        }
        _markAllSubMeshesAsTexturesDirty() {
          this._enable(this._isEnabled), this._internalMarkAllSubMeshesAsTexturesDirty()
        }
        isCompatible() {
          return !0
        }
        constructor(OO) {
          let eO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          super(OO, "DetailMap", 140, new DO, eO), this._texture = null, KO.set(this, (0, XO.i)(this, zK, void 0)), this.diffuseBlendLevel = ((0, XO.i)(this, AO), (0, XO.i)(this, fO, 1)), this.roughnessBlendLevel = ((0, XO.i)(this, dO), (0, XO.i)(this, TO, 1)), this.bumpLevel = ((0, XO.i)(this, NO), (0, XO.i)(this, IO, 1)), this._normalBlendMethod = ((0, XO.i)(this, yK), bK.b.MATERIAL_NORMALBLENDMETHOD_WHITEOUT), pO.set(this, (0, XO.i)(this, gK, void 0)), this._isEnabled = ((0, XO.i)(this, uO), !1), vK.set(this, (0, XO.i)(this, EO, !1)), this._internalMarkAllSubMeshesAsTexturesDirty = (0, XO.i)(this, jK), this._internalMarkAllSubMeshesAsTexturesDirty = OO._dirtyCallbacks[1]
        }
        isReadyForSubMesh(OO, KO, pO) {
          return !this._isEnabled || !(OO._areTexturesDirty && KO.texturesEnabled && pO.getCaps().standardDerivatives && this._texture && lO.e.DetailTextureEnabled && !this._texture.isReady())
        }
        prepareDefines(OO, KO) {
          if (this._isEnabled) {
            OO.DETAIL_NORMALBLENDMETHOD = this._normalBlendMethod;
            const pO = KO.qb();
            OO._areTexturesDirty && (pO.getCaps().standardDerivatives && this._texture && lO.e.DetailTextureEnabled && this._isEnabled ? ((0, hO.bb)(this._texture, OO, "DETAIL"), OO.DETAIL_NORMALBLENDMETHOD = this._normalBlendMethod) : OO.DETAIL = !1)
          } else OO.DETAIL = !1
        }
        bindForSubMesh(OO, KO) {
          if (!this._isEnabled) return;
          const pO = this._material.isFrozen;
          OO.useUbo && pO && OO.isSync || this._texture && lO.e.DetailTextureEnabled && (OO.updateFloat4("vDetailInfos", this._texture.coordinatesIndex, this.diffuseBlendLevel, this.bumpLevel, this.roughnessBlendLevel), (0, hO.B)(this._texture, OO, "detail")), KO.texturesEnabled && this._texture && lO.e.DetailTextureEnabled && OO.setTexture("detailSampler", this._texture)
        }
        hasTexture(OO) {
          return this._texture === OO
        }
        getActiveTextures(OO) {
          this._texture && OO.push(this._texture)
        }
        getAnimatables(OO) {
          this._texture && this._texture.animations && this._texture.animations.length > 0 && OO.push(this._texture)
        }
        dispose(OO) {
          OO && this._texture?.dispose()
        }
        getClassName() {
          return "DetailMapConfiguration"
        }
        getSamplers(OO) {
          OO.push("detailSampler")
        }
        getUniforms() {
          return {
            ubo: [{
              name: "vDetailInfos",
              size: 4,
              type: "vec4"
            }, {
              name: "detailMatrix",
              size: 16,
              type: "mat4"
            }]
          }
        }
      }, KO = new WeakMap, pO = new WeakMap, vK = new WeakMap, (() => {
        const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(QO[Symbol.metadata] ?? null) : void 0;
        MO = [(0, eO.I)("detailTexture"), (0, eO.h)("_markAllSubMeshesAsTexturesDirty")], aK = [(0, eO.M)()], oO = [(0, eO.M)()], FO = [(0, eO.M)()], VO = [(0, eO.M)(), (0, eO.h)("_markAllSubMeshesAsTexturesDirty")], LO = [(0, eO.M)(), (0, eO.h)("_markAllSubMeshesAsTexturesDirty")], (0, XO.f)(OO, null, MO, {
          kind: "accessor",
          name: "texture",
          static: !1,
          private: !1,
          access: {
            has: OO => "texture" in OO,
            get: OO => OO.texture,
            set: (OO, KO) => {
              OO.texture = KO
            }
          },
          metadata: KO
        }, zK, AO), (0, XO.f)(OO, null, VO, {
          kind: "accessor",
          name: "normalBlendMethod",
          static: !1,
          private: !1,
          access: {
            has: OO => "normalBlendMethod" in OO,
            get: OO => OO.normalBlendMethod,
            set: (OO, KO) => {
              OO.normalBlendMethod = KO
            }
          },
          metadata: KO
        }, gK, uO), (0, XO.f)(OO, null, LO, {
          kind: "accessor",
          name: "isEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isEnabled" in OO,
            get: OO => OO.isEnabled,
            set: (OO, KO) => {
              OO.isEnabled = KO
            }
          },
          metadata: KO
        }, EO, jK), (0, XO.f)(null, null, aK, {
          kind: "field",
          name: "diffuseBlendLevel",
          static: !1,
          private: !1,
          access: {
            has: OO => "diffuseBlendLevel" in OO,
            get: OO => OO.diffuseBlendLevel,
            set: (OO, KO) => {
              OO.diffuseBlendLevel = KO
            }
          },
          metadata: KO
        }, fO, dO), (0, XO.f)(null, null, oO, {
          kind: "field",
          name: "roughnessBlendLevel",
          static: !1,
          private: !1,
          access: {
            has: OO => "roughnessBlendLevel" in OO,
            get: OO => OO.roughnessBlendLevel,
            set: (OO, KO) => {
              OO.roughnessBlendLevel = KO
            }
          },
          metadata: KO
        }, TO, NO), (0, XO.f)(null, null, FO, {
          kind: "field",
          name: "bumpLevel",
          static: !1,
          private: !1,
          access: {
            has: OO => "bumpLevel" in OO,
            get: OO => OO.bumpLevel,
            set: (OO, KO) => {
              OO.bumpLevel = KO
            }
          },
          metadata: KO
        }, IO, yK), KO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: KO
        })
      })(), OO
    })()
  },
  38378: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    class XO {
      constructor(OO) {
        if (this.VERTEXOUTPUT_INVARIANT = !1, this._keys = [], this._isDirty = !0, this._areLightsDirty = !0, this._areLightsDisposed = !1, this._areAttributesDirty = !0, this._areTexturesDirty = !0, this._areFresnelDirty = !0, this._areMiscDirty = !0, this._arePrePassDirty = !0, this._areImageProcessingDirty = !0, this._normals = !1, this._uvs = !1, this._needNormals = !1, this._needUVs = !1, this._externalProperties = OO, OO)
          for (const KO in OO) Object.prototype.hasOwnProperty.call(OO, KO) && this._setDefaultValue(KO)
      }
      get isDirty() {
        return this._isDirty
      }
      markAsProcessed() {
        this._isDirty = !1, this._areAttributesDirty = !1, this._areTexturesDirty = !1, this._areFresnelDirty = !1, this._areLightsDirty = !1, this._areLightsDisposed = !1, this._areMiscDirty = !1, this._arePrePassDirty = !1, this._areImageProcessingDirty = !1
      }
      markAsUnprocessed() {
        this._isDirty = !0
      }
      markAllAsDirty() {
        this._areTexturesDirty = !0, this._areAttributesDirty = !0, this._areLightsDirty = !0, this._areFresnelDirty = !0, this._areMiscDirty = !0, this._arePrePassDirty = !0, this._areImageProcessingDirty = !0, this._isDirty = !0
      }
      markAsImageProcessingDirty() {
        this._areImageProcessingDirty = !0, this._isDirty = !0
      }
      markAsLightDirty() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        this._areLightsDirty = !0, this._areLightsDisposed = this._areLightsDisposed || OO, this._isDirty = !0
      }
      markAsAttributesDirty() {
        this._areAttributesDirty = !0, this._isDirty = !0
      }
      markAsTexturesDirty() {
        this._areTexturesDirty = !0, this._isDirty = !0
      }
      markAsFresnelDirty() {
        this._areFresnelDirty = !0, this._isDirty = !0
      }
      markAsMiscDirty() {
        this._areMiscDirty = !0, this._isDirty = !0
      }
      markAsPrePassDirty() {
        this._arePrePassDirty = !0, this._isDirty = !0
      }
      rebuild() {
        this._keys.length = 0;
        for (const OO of Object.keys(this)) "_" !== OO[0] && this._keys.push(OO);
        if (this._externalProperties)
          for (const OO in this._externalProperties) - 1 === this._keys.indexOf(OO) && this._keys.push(OO)
      }
      isEqual(OO) {
        if (this._keys.length !== OO._keys.length) return !1;
        for (let KO = 0; KO < this._keys.length; KO++) {
          const pO = this._keys[KO];
          if (this[pO] !== OO[pO]) return !1
        }
        return !0
      }
      cloneTo(OO) {
        this._keys.length !== OO._keys.length && (OO._keys = this._keys.slice(0));
        for (let KO = 0; KO < this._keys.length; KO++) {
          const pO = this._keys[KO];
          OO[pO] = this[pO]
        }
      }
      reset() {
        for (const OO of this._keys) this._setDefaultValue(OO)
      }
      _setDefaultValue(OO) {
        const KO = this._externalProperties?.[OO]?.type ?? typeof this[OO],
          pO = this._externalProperties?.[OO]?.default;
        switch (KO) {
          case "number":
            this[OO] = pO ?? 0;
            break;
          case "string":
            this[OO] = pO ?? "";
            break;
          default:
            this[OO] = pO ?? !1
        }
      }
      toString() {
        let OO = "";
        for (let KO = 0; KO < this._keys.length; KO++) {
          const pO = this._keys[KO],
            XO = this[pO];
          switch (typeof XO) {
            case "number":
            case "string":
              OO += "#define " + pO + " " + XO + "\n";
              break;
            default:
              XO && (OO += "#define " + pO + "\n")
          }
        }
        return OO
      }
    }
  },
  38471: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      g: () => lO,
      h: () => eO
    });
    var XO, bK = pO(35632);

    function eO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 16777215;
      const XO = KO(OO);
      if (!Number.isInteger(XO) || XO < 0 || XO > pO) throw new Error(`Invalid geometry object ID ${XO} for mesh "${OO.name}". Object IDs must be integers between 0 and 0x${pO.toString(16).toUpperCase()}.`);
      return XO
    }

    function lO(OO, KO) {
      const pO = KO(OO);
      if (!Number.isInteger(pO) || pO < 0 || pO > 255 || 0 !== pO && 0 === (63 & pO)) throw new Error(`Invalid geometry mesh-blending tag ${pO} for mesh "${OO.name}". Tags must be 0 or contain a group ID between 1 and 63.`);
      return pO
    }! function(OO) {
      OO[OO.Zero = 0] = "Zero", OO[OO.One = 1] = "One", OO[OO.MaxViewZ = 2] = "MaxViewZ", OO[OO.NoClear = 3] = "NoClear"
    }(XO || (XO = {}));
    class vK {
      static CreateConfiguration(OO) {
        return vK._Configurations[OO] = {
          defines: {},
          previousWorldMatrices: {},
          previousViewProjection: bK.c.Zero(),
          currentViewProjection: bK.c.Zero(),
          previousBones: {},
          lastUpdateFrameId: -1,
          excludedSkinnedMesh: [],
          reverseCulling: !1,
          objectIdIsRedFormat: !1
        }, vK._Configurations[OO]
      }
      static DeleteConfiguration(OO) {
        delete vK._Configurations[OO]
      }
      static GetConfiguration(OO) {
        return vK._Configurations[OO]
      }
      static _PrepareConfiguration(OO, KO, pO) {
        const XO = vK._Configurations[OO];
        XO._attachments = KO, XO._colorAttachments = pO, XO._mrtCount = KO.length;
        let bK = "#define PREPASS\n";
        for (const eO of vK.GeometryTextureDescriptions) {
          const OO = XO.defines[eO.defineIndex];
          void 0 !== OO && (bK += `#define ${eO.define}\n#define ${eO.defineIndex} ${OO}\n`)
        }
        XO.objectIdIsRedFormat && (bK += "#define PREPASS_OBJECT_ID_R8\n"), XO._defines = bK + `#define SCENE_MRT_COUNT ${KO.length}\n`
      }
      static _PrepareStringDefines(OO, KO) {
        const pO = vK._Configurations[OO];
        return !!pO?._defines && (KO.push(pO._defines), !0)
      }
      static _BindAttachmentsForEffect(OO, KO) {
        const pO = vK._Configurations[OO.currentRenderPassId];
        return !pO?._attachments || (OO.bindAttachments(KO._multiTarget ? pO._attachments : pO._colorAttachments), KO._multiTarget || void 0 !== pO.defines.PREPASS_COLOR_INDEX)
      }
      static _RestoreAttachments(OO) {
        const KO = vK._Configurations[OO.currentRenderPassId];
        KO?._colorAttachments && OO.bindAttachments(KO._colorAttachments)
      }
      static _BindColorAttachments(OO) {
        const KO = vK._Configurations[OO.currentRenderPassId];
        return !KO?._colorAttachments || (OO.bindAttachments(KO._colorAttachments), void 0 !== KO.defines.PREPASS_COLOR_INDEX)
      }
      static _IsColorAttachmentEnabled(OO) {
        const KO = vK._Configurations[OO.currentRenderPassId];
        return !KO?._colorAttachments || void 0 !== KO.defines.PREPASS_COLOR_INDEX
      }
      static _BindZeroAlphaDiscard(OO, KO) {
        const pO = vK._Configurations[OO.currentRenderPassId];
        if (!pO) return;
        const XO = OO.getAlphaMode(),
          bK = void 0 === pO.defines.PREPASS_COLOR_INDEX || 2 === XO || 1 === XO || 17 === XO;
        KO.setFloat("geometryZeroAlphaDiscard", bK ? 1 : 0)
      }
      static AddUniformsAndSamplers(OO, KO) {
        OO.push("previousWorld", "previousViewProjection", "mPreviousBones", "objectId", "meshBlendTag")
      }
      static MarkAsDirty(OO, KO) {
        for (const pO of KO)
          if (pO.au)
            for (const KO of pO.au) KO._removeDrawWrapper(OO)
      }
      static PrepareDefines(OO, KO, pO) {
        if (!pO._arePrePassDirty) return;
        const XO = vK._Configurations[OO];
        if (!XO) return;
        pO.PREPASS = !0;
        let bK = 0;
        for (let eO = 0; eO < vK.GeometryTextureDescriptions.length; eO++) {
          const OO = vK.GeometryTextureDescriptions[eO],
            KO = OO.define,
            lO = OO.defineIndex,
            CO = XO.defines[lO];
          void 0 !== CO ? (pO[KO] = !0, pO[lO] = CO, bK++) : (pO[KO] = !1, delete pO[lO])
        }
        pO.PREPASS_OBJECT_ID_R8 = XO.objectIdIsRedFormat, pO.SCENE_MRT_COUNT = XO._mrtCount ?? bK, pO.BONES_VELOCITY_ENABLED = KO.useBones && KO.computeBonesUsingShaders && KO.skeleton && !KO.skeleton.isUsingTextureForMatrices && -1 === XO.excludedSkinnedMesh.indexOf(KO)
      }
      static Bind(OO, KO, pO, XO, bK) {
        const CO = vK._Configurations[OO];
        if (!CO) return;
        const hO = pO.JKO(),
          DO = hO.qb();
        if (CO.reverseCulling && DO.setStateCullFaceType(hO._mirroredCameraPosition ? bK.cullBackFaces : !bK.cullBackFaces), void 0 !== CO.defines.PREPASS_OBJECT_ID_INDEX) {
          const OO = CO.objectIdIsRedFormat ? 255 : 16777215;
          let XO = pO.uniqueId;
          if (CO.objectIdProvider) XO = eO(pO, CO.objectIdProvider, OO);
          else if (XO > OO) throw new Error(`Invalid geometry object ID ${XO} for mesh "${pO.name}". Object IDs must be integers between 0 and 0x${OO.toString(16).toUpperCase()}.`);
          KO.setFloat("objectId", XO)
        }
        if (void 0 !== CO.defines.PREPASS_MESH_BLEND_TAG_INDEX) {
          const OO = CO.meshBlendTagProvider ? lO(pO, CO.meshBlendTagProvider) : pO.meshBlendingTag;
          KO.setInt("meshBlendTag", OO)
        }
        if (void 0 !== CO.defines.PREPASS_VELOCITY_INDEX || void 0 !== CO.defines.PREPASS_VELOCITY_LINEAR_INDEX) {
          const OO = CO._currentWorldMatrices ?? (CO._currentWorldMatrices = {}),
            bK = CO._worldMatrixFrameIds ?? (CO._worldMatrixFrameIds = {});
          if (OO[pO.uniqueId] || (OO[pO.uniqueId] = XO.clone(), CO.previousWorldMatrices[pO.uniqueId] = XO.clone()), bK[pO.uniqueId] !== DO.frameId && (CO.previousWorldMatrices[pO.uniqueId].NhO(OO[pO.uniqueId]), bK[pO.uniqueId] = DO.frameId), OO[pO.uniqueId].NhO(XO), -1 === CO.lastUpdateFrameId ? (CO.lastUpdateFrameId = DO.frameId, CO.previousViewProjection.NhO(hO.getTransformMatrix()), CO.currentViewProjection.NhO(hO.getTransformMatrix())) : CO.currentViewProjection.updateFlag !== hO.getTransformMatrix().updateFlag ? (CO.lastUpdateFrameId = DO.frameId, CO.previousViewProjection.NhO(CO.currentViewProjection), CO.currentViewProjection.NhO(hO.getTransformMatrix())) : CO.lastUpdateFrameId !== DO.frameId && (CO.lastUpdateFrameId = DO.frameId, CO.previousViewProjection.NhO(CO.currentViewProjection)), KO.setMatrix("previousWorld", CO.previousWorldMatrices[pO.uniqueId]), KO.setMatrix("previousViewProjection", CO.previousViewProjection), pO.useBones && pO.computeBonesUsingShaders && pO.skeleton) {
            const OO = pO.skeleton;
            if (!OO.isUsingTextureForMatrices || -1 === KO.getUniformIndex("boneTextureInfo")) {
              const XO = OO.getTransformMatrices(pO);
              XO && (CO.previousBones[pO.uniqueId] || (CO.previousBones[pO.uniqueId] = XO.slice()), KO.setMatrices("mPreviousBones", CO.previousBones[pO.uniqueId]), CO.previousBones[pO.uniqueId].set(XO))
            }
          }
        }
      }
    }
    vK.GeometryTextureDescriptions = [{
      type: 0,
      name: "IrradianceLegacy",
      clearType: 0,
      define: "PREPASS_IRRADIANCE_LEGACY",
      defineIndex: "PREPASS_IRRADIANCE_LEGACY_INDEX"
    }, {
      type: 1,
      name: "WorldPosition",
      clearType: 0,
      define: "PREPASS_POSITION",
      defineIndex: "PREPASS_POSITION_INDEX"
    }, {
      type: 2,
      name: "Velocity",
      clearType: 0,
      define: "PREPASS_VELOCITY",
      defineIndex: "PREPASS_VELOCITY_INDEX"
    }, {
      type: 3,
      name: "Reflectivity",
      clearType: 0,
      define: "PREPASS_REFLECTIVITY",
      defineIndex: "PREPASS_REFLECTIVITY_INDEX"
    }, {
      type: 5,
      name: "ViewDepth",
      clearType: 2,
      define: "PREPASS_DEPTH",
      defineIndex: "PREPASS_DEPTH_INDEX"
    }, {
      type: 6,
      name: "ViewNormal",
      clearType: 0,
      define: "PREPASS_NORMAL",
      defineIndex: "PREPASS_NORMAL_INDEX"
    }, {
      type: 7,
      name: "AlbedoSqrt",
      clearType: 0,
      define: "PREPASS_ALBEDO_SQRT",
      defineIndex: "PREPASS_ALBEDO_SQRT_INDEX"
    }, {
      type: 8,
      name: "WorldNormal",
      clearType: 0,
      define: "PREPASS_WORLD_NORMAL",
      defineIndex: "PREPASS_WORLD_NORMAL_INDEX"
    }, {
      type: 9,
      name: "LocalPosition",
      clearType: 0,
      define: "PREPASS_LOCAL_POSITION",
      defineIndex: "PREPASS_LOCAL_POSITION_INDEX"
    }, {
      type: 10,
      name: "ScreenDepth",
      clearType: 1,
      define: "PREPASS_SCREENSPACE_DEPTH",
      defineIndex: "PREPASS_SCREENSPACE_DEPTH_INDEX"
    }, {
      type: 11,
      name: "LinearVelocity",
      clearType: 0,
      define: "PREPASS_VELOCITY_LINEAR",
      defineIndex: "PREPASS_VELOCITY_LINEAR_INDEX"
    }, {
      type: 12,
      name: "Albedo",
      clearType: 0,
      define: "PREPASS_ALBEDO",
      defineIndex: "PREPASS_ALBEDO_INDEX"
    }, {
      type: 13,
      name: "NormalizedViewDepth",
      clearType: 1,
      define: "PREPASS_NORMALIZED_VIEW_DEPTH",
      defineIndex: "PREPASS_NORMALIZED_VIEW_DEPTH_INDEX"
    }, {
      type: 4,
      name: "Color",
      clearType: 3,
      define: "PREPASS_COLOR",
      defineIndex: "PREPASS_COLOR_INDEX"
    }, {
      type: 14,
      name: "Irradiance",
      clearType: 0,
      define: "PREPASS_IRRADIANCE",
      defineIndex: "PREPASS_IRRADIANCE_INDEX"
    }, {
      type: 15,
      name: "ObjectId",
      clearType: 0,
      define: "PREPASS_OBJECT_ID",
      defineIndex: "PREPASS_OBJECT_ID_INDEX"
    }, {
      type: 16,
      name: "MeshBlendTag",
      clearType: 0,
      define: "PREPASS_MESH_BLEND_TAG",
      defineIndex: "PREPASS_MESH_BLEND_TAG_INDEX"
    }], vK._Configurations = {}
  },
  38456: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => aK,
      f: () => FO
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(37947),
      lO = pO(37907);
    const vK = new RegExp("^([gimus]+)!");
    class CO {
      constructor(OO) {
        this._plugins = [], this._activePlugins = [], this._activePluginsForExtraEvents = [], this._material = OO, this._scene = OO.JKO(), this._engine = this._scene.qb()
      }
      _addPlugin(OO) {
        for (let XO = 0; XO < this._plugins.length; ++XO)
          if (this._plugins[XO].name === OO.name) return !1;
        if (this._material._uniformBufferLayoutBuilt && (this._material.resetDrawCache(), this._material._createUniformBuffer()), !OO.isCompatible(this._material.shaderLanguage)) throw `The plugin "${OO.name}" can't be added to the material "${this._material.name}" because the plugin is not compatible with the shader language of the material.`;
        const KO = OO.getClassName();
        CO._MaterialPluginClassToMainDefine[KO] || (CO._MaterialPluginClassToMainDefine[KO] = "MATERIALPLUGIN_" + ++CO._MaterialPluginCounter), this._material._callbackPluginEventGeneric = (OO, KO) => this._handlePluginEvent(OO, KO), this._plugins.push(OO), this._plugins.sort(((OO, KO) => OO.priority - KO.priority)), this._codeInjectionPoints = {};
        const pO = {};
        pO[CO._MaterialPluginClassToMainDefine[KO]] = {
          type: "boolean",
          default: !0
        };
        for (const XO of this._plugins) XO.collectDefines(pO), this._collectPointNames("vertex", XO.getCustomCode("vertex", this._material.shaderLanguage)), this._collectPointNames("fragment", XO.getCustomCode("fragment", this._material.shaderLanguage));
        return this._defineNamesFromPlugins = pO, !0
      }
      _activatePlugin(OO) {
        -1 === this._activePlugins.indexOf(OO) && (this._activePlugins.push(OO), this._activePlugins.sort(((OO, KO) => OO.priority - KO.priority)), this._material._callbackPluginEventIsReadyForSubMesh = this._handlePluginEventIsReadyForSubMesh.bind(this), this._material._callbackPluginEventPrepareDefinesBeforeAttributes = this._handlePluginEventPrepareDefinesBeforeAttributes.bind(this), this._material._callbackPluginEventPrepareDefines = this._handlePluginEventPrepareDefines.bind(this), this._material._callbackPluginEventBindForSubMesh = this._handlePluginEventBindForSubMesh.bind(this), OO.registerForExtraEvents && (this._activePluginsForExtraEvents.push(OO), this._activePluginsForExtraEvents.sort(((OO, KO) => OO.priority - KO.priority)), this._material._callbackPluginEventHasRenderTargetTextures = this._handlePluginEventHasRenderTargetTextures.bind(this), this._material._callbackPluginEventFillRenderTargetTextures = this._handlePluginEventFillRenderTargetTextures.bind(this), this._material._callbackPluginEventHardBindForSubMesh = this._handlePluginEventHardBindForSubMesh.bind(this)))
      }
      getPlugin(OO) {
        for (let KO = 0; KO < this._plugins.length; ++KO)
          if (this._plugins[KO].name === OO) return this._plugins[KO];
        return null
      }
      _handlePluginEventIsReadyForSubMesh(OO) {
        let KO = !0;
        for (const pO of this._activePlugins) KO = KO && pO.isReadyForSubMesh(OO.defines, this._scene, this._engine, OO.subMesh);
        OO.isReadyForSubMesh = KO
      }
      _handlePluginEventPrepareDefinesBeforeAttributes(OO) {
        for (const KO of this._activePlugins) KO.prepareDefinesBeforeAttributes(OO.defines, this._scene, OO.mesh)
      }
      _handlePluginEventPrepareDefines(OO) {
        for (const KO of this._activePlugins) KO.prepareDefines(OO.defines, this._scene, OO.mesh)
      }
      _handlePluginEventHardBindForSubMesh(OO) {
        for (const KO of this._activePluginsForExtraEvents) KO.hardBindForSubMesh(this._material._uniformBuffer, this._scene, this._engine, OO.subMesh)
      }
      _handlePluginEventBindForSubMesh(OO) {
        for (const KO of this._activePlugins) KO.bindForSubMesh(this._material._uniformBuffer, this._scene, this._engine, OO.subMesh)
      }
      _handlePluginEventHasRenderTargetTextures(OO) {
        let KO = !1;
        for (const pO of this._activePluginsForExtraEvents)
          if (KO = pO.hasRenderTargetTextures(), KO) break;
        OO.hasRenderTargetTextures = KO
      }
      _handlePluginEventFillRenderTargetTextures(OO) {
        for (const KO of this._activePluginsForExtraEvents) KO.fillRenderTargetTextures(OO.renderTargets)
      }
      _handlePluginEvent(OO, KO) {
        switch (OO) {
          case 512: {
            const OO = KO;
            for (const KO of this._activePlugins) KO.getActiveTextures(OO.activeTextures);
            break
          }
          case 256: {
            const OO = KO;
            for (const KO of this._activePlugins) KO.getAnimatables(OO.animatables);
            break
          }
          case 1024: {
            const OO = KO;
            let pO = !1;
            for (const KO of this._activePlugins)
              if (pO = KO.hasTexture(OO.texture), pO) break;
            OO.hasTexture = pO;
            break
          }
          case 2: {
            const OO = KO;
            for (const KO of this._plugins) KO.dispose(OO.forceDisposeTextures);
            break
          }
          case 4:
            KO.defineNames = this._defineNamesFromPlugins;
            break;
          case 128: {
            const OO = KO;
            for (const KO of this._activePlugins) OO.fallbackRank = KO.addFallbacks(OO.defines, OO.fallbacks, OO.fallbackRank), KO.getAttributes(OO.attributes, this._scene, OO.mesh);
            this._uniformList.length > 0 && OO.uniforms.push(...this._uniformList), this._samplerList.length > 0 && OO.samplers.push(...this._samplerList), this._uboList.length > 0 && OO.uniformBuffersNames.push(...this._uboList), OO.customCode = this._injectCustomCode(OO, OO.customCode);
            break
          }
          case 8: {
            const OO = KO;
            this._uboDeclaration = "", this._vertexDeclaration = "", this._fragmentDeclaration = "", this._uniformList = [], this._samplerList = [], this._uboList = [];
            const pO = 1 === this._material.shaderLanguage;
            for (const KO of this._plugins) {
              const XO = KO.getUniforms(this._material.shaderLanguage);
              if (XO) {
                if (XO.ubo)
                  for (const KO of XO.ubo) {
                    if (KO.size && KO.type) {
                      const XO = KO.arraySize ?? 0;
                      if (OO.ubo.addUniform(KO.name, KO.size, XO), pO) {
                        let OO;
                        switch (KO.type) {
                          case "mat4":
                            OO = "mat4x4f";
                            break;
                          case "float":
                            OO = "f32";
                            break;
                          default:
                            OO = `${KO.type}f`
                        }
                        this._uboDeclaration += XO > 0 ? `uniform ${KO.name}: array<${OO}, ${XO}>;\n` : `uniform ${KO.name}: ${OO};\n`
                      } else this._uboDeclaration += `${KO.type} ${KO.name}${XO>0?`[${XO}]`:""};\n`
                    }
                    this._uniformList.push(KO.name)
                  }
                XO.vertex && (this._vertexDeclaration += XO.vertex + "\n"), XO.fragment && (this._fragmentDeclaration += XO.fragment + "\n"), XO.externalUniforms && this._uniformList.push(...XO.externalUniforms)
              }
              KO.getSamplers(this._samplerList), KO.getUniformBuffersNames(this._uboList)
            }
            break
          }
        }
      }
      _collectPointNames(OO, KO) {
        if (KO)
          for (const pO in KO) this._codeInjectionPoints[OO] || (this._codeInjectionPoints[OO] = {}), this._codeInjectionPoints[OO][pO] = !0
      }
      _injectCustomCode(OO, KO) {
        return (pO, XO) => {
          KO && (XO = KO(pO, XO)), this._uboDeclaration && (XO = XO.replace("#define ADDITIONAL_UBO_DECLARATION", this._uboDeclaration)), this._vertexDeclaration && (XO = XO.replace("#define ADDITIONAL_VERTEX_DECLARATION", this._vertexDeclaration)), this._fragmentDeclaration && (XO = XO.replace("#define ADDITIONAL_FRAGMENT_DECLARATION", this._fragmentDeclaration));
          const bK = this._codeInjectionPoints?.[pO];
          if (!bK) return XO;
          let CO = null;
          for (let KO in bK) {
            let bK = "";
            for (const XO of this._activePlugins) {
              const vK = this._material.shaderLanguage;
              let hO = XO.getCustomCode(pO, vK)?.[KO];
              hO && (XO.resolveIncludes && (null === CO && (CO = {
                defines: [],
                indexParameters: OO.indexParameters,
                isFragment: !1,
                shouldUseHighPrecisionShader: this._engine._shouldUseHighPrecisionShader,
                processor: void 0,
                supportsUniformBuffers: this._engine.supportsUniformBuffers,
                shadersRepository: lO.b.GetShadersRepository(vK),
                includesShadersStore: lO.b.GetIncludesShadersStore(vK),
                version: void 0,
                platformName: this._engine.shaderPlatformName,
                processingContext: void 0,
                isNDCHalfZRange: this._engine.isNDCHalfZRange,
                BhO: this._engine.BhO,
                processCodeAfterIncludes: void 0
              }), CO.isFragment = "fragment" === pO, (0, eO.g)(hO, CO, (OO => hO = OO))), bK += hO + "\n")
            }
            if (bK.length > 0)
              if ("!" === KO.charAt(0)) {
                KO = KO.substring(1);
                let OO = "g";
                if ("!" === KO.charAt(0)) OO = "", KO = KO.substring(1);
                else {
                  const pO = vK.exec(KO);
                  pO && pO.length >= 2 && (OO = pO[1], KO = KO.substring(OO.length + 1))
                }
                OO.indexOf("g") < 0 && (OO += "g");
                const pO = new RegExp(KO, OO);
                let eO = pO.exec(XO);
                for (; null !== eO;) {
                  const {
                    index: OO
                  } = eO, KO = hO(bK, eO);
                  XO = XO.substring(0, OO) + KO + XO.substring(OO + eO[0].length), pO.lastIndex = OO + KO.length, eO = pO.exec(XO)
                }
              } else {
                const OO = "#define " + KO;
                XO = XO.replace(OO, "\n" + bK + "\n" + OO)
              }
          }
          return XO
        }
      }
    }
    CO._MaterialPluginClassToMainDefine = {}, CO._MaterialPluginCounter = 0;

    function hO(OO, KO) {
      return OO.replace(/\$(\d+)/g, ((OO, pO) => {
        const XO = Number(pO);
        return XO < KO.length ? KO[XO] : ""
      }))
    }
    var DO = pO(38077),
      MO = pO(35676);
    let aK = (() => {
        var OO;
        let KO, pO, eO, lO, vK = [],
          hO = [],
          MO = [],
          aK = [],
          oO = [],
          FO = [],
          VO = [],
          LO = [];
        return OO = class {
          isCompatible(OO) {
            return 0 === OO
          }
          _enable(OO) {
            OO && this._pluginManager._activatePlugin(this)
          }
          constructor(OO, KO, pO, bK) {
            let eO = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
              lO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
              DO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
            this.name = (0, XO.i)(this, vK, void 0), this.priority = ((0, XO.i)(this, hO), (0, XO.i)(this, MO, 500)), this.resolveIncludes = ((0, XO.i)(this, aK), (0, XO.i)(this, oO, !1)), this.registerForExtraEvents = ((0, XO.i)(this, FO), (0, XO.i)(this, VO, !1)), this.doNotSerialize = ((0, XO.i)(this, LO), !1), this._material = OO, this.name = KO, this.priority = pO, this.resolveIncludes = DO, OO.pluginManager || (OO.pluginManager = new CO(OO), OO.cpO.add((() => {
              OO.pluginManager = void 0
            }))), this._pluginDefineNames = bK, this._pluginManager = OO.pluginManager, eO && this._pluginManager._addPlugin(this), lO && this._enable(!0), this.markAllDefinesAsDirty = OO._dirtyCallbacks[127]
          }
          getClassName() {
            return "MaterialPluginBase"
          }
          isReadyForSubMesh(OO, KO, pO, XO) {
            return !0
          }
          hardBindForSubMesh(OO, KO, pO, XO) {}
          bindForSubMesh(OO, KO, pO, XO) {}
          dispose(OO) {}
          getCustomCode(OO) {
            return null
          }
          collectDefines(OO) {
            if (this._pluginDefineNames)
              for (const KO of Object.keys(this._pluginDefineNames)) {
                if ("_" === KO[0]) continue;
                const pO = typeof this._pluginDefineNames[KO];
                OO[KO] = {
                  type: "number" === pO ? "number" : "string" === pO ? "string" : "boolean" === pO ? "boolean" : "object",
                  default: this._pluginDefineNames[KO]
                }
              }
          }
          prepareDefinesBeforeAttributes(OO, KO, pO) {}
          prepareDefines(OO, KO, pO) {}
          hasTexture(OO) {
            return !1
          }
          hasRenderTargetTextures() {
            return !1
          }
          fillRenderTargetTextures(OO) {}
          getActiveTextures(OO) {}
          getAnimatables(OO) {}
          addFallbacks(OO, KO, pO) {
            return pO
          }
          getSamplers(OO) {}
          getAttributes(OO, KO, pO) {}
          getUniformBuffersNames(OO) {}
          getUniforms() {
            return {}
          }
          copyTo(OO) {
            DO.c.Clone((() => OO), this)
          }
          serialize() {
            return DO.c.Serialize(this)
          }
          parse(OO, KO, pO) {
            DO.c.Parse((() => this), OO, KO, pO)
          }
        }, (() => {
          const CO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          KO = [(0, bK.M)()], pO = [(0, bK.M)()], eO = [(0, bK.M)()], lO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "name",
            static: !1,
            private: !1,
            access: {
              has: OO => "name" in OO,
              get: OO => OO.name,
              set: (OO, KO) => {
                OO.name = KO
              }
            },
            metadata: CO
          }, vK, hO), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "priority",
            static: !1,
            private: !1,
            access: {
              has: OO => "priority" in OO,
              get: OO => OO.priority,
              set: (OO, KO) => {
                OO.priority = KO
              }
            },
            metadata: CO
          }, MO, aK), (0, XO.f)(null, null, eO, {
            kind: "field",
            name: "resolveIncludes",
            static: !1,
            private: !1,
            access: {
              has: OO => "resolveIncludes" in OO,
              get: OO => OO.resolveIncludes,
              set: (OO, KO) => {
                OO.resolveIncludes = KO
              }
            },
            metadata: CO
          }, oO, FO), (0, XO.f)(null, null, lO, {
            kind: "field",
            name: "registerForExtraEvents",
            static: !1,
            private: !1,
            access: {
              has: OO => "registerForExtraEvents" in OO,
              get: OO => OO.registerForExtraEvents,
              set: (OO, KO) => {
                OO.registerForExtraEvents = KO
              }
            },
            metadata: CO
          }, VO, LO), CO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: CO
          })
        })(), OO
      })(),
      oO = !1;

    function FO() {
      oO || (oO = !0, (0, MO.h)("BABYLON.MaterialPluginBase", aK))
    }
  },
  38363: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO
    });
    class XO {
      constructor() {
        this.previousWorldMatrices = {}, this.previousBones = {}
      }
      static AddUniforms(OO) {
        OO.push("previousWorld", "previousViewProjection", "mPreviousBones")
      }
      static AddSamplers(OO) {}
      bindForSubMesh(OO, KO, pO, XO, bK) {
        if (KO.prePassRenderer && KO.prePassRenderer.enabled && KO.prePassRenderer.currentRTisSceneRT && (-1 !== KO.prePassRenderer.getIndex(2) || -1 !== KO.prePassRenderer.getIndex(11))) {
          this.previousWorldMatrices[pO.uniqueId] || (this.previousWorldMatrices[pO.uniqueId] = XO.clone()), this.previousViewProjection || (this.previousViewProjection = KO.getTransformMatrix().clone(), this.currentViewProjection = KO.getTransformMatrix().clone());
          const bK = KO.qb();
          this.currentViewProjection.updateFlag !== KO.getTransformMatrix().updateFlag ? (this._lastUpdateFrameId = bK.frameId, this.previousViewProjection.NhO(this.currentViewProjection), this.currentViewProjection.NhO(KO.getTransformMatrix())) : this._lastUpdateFrameId !== bK.frameId && (this._lastUpdateFrameId = bK.frameId, this.previousViewProjection.NhO(this.currentViewProjection)), OO.setMatrix("previousWorld", this.previousWorldMatrices[pO.uniqueId]), OO.setMatrix("previousViewProjection", this.previousViewProjection), this.previousWorldMatrices[pO.uniqueId] = XO.clone()
        }
      }
    }
  },
  38488: (OO, KO, pO) => {
    function XO(OO) {
      return class extends OO {
        constructor() {
          super(...arguments), this.PREPASS = !1, this.PREPASS_COLOR = !1, this.PREPASS_COLOR_INDEX = -1, this.PREPASS_IRRADIANCE_LEGACY = !1, this.PREPASS_IRRADIANCE_LEGACY_INDEX = -1, this.PREPASS_IRRADIANCE = !1, this.PREPASS_IRRADIANCE_INDEX = -1, this.PREPASS_ALBEDO = !1, this.PREPASS_ALBEDO_INDEX = -1, this.PREPASS_ALBEDO_SQRT = !1, this.PREPASS_ALBEDO_SQRT_INDEX = -1, this.PREPASS_DEPTH = !1, this.PREPASS_DEPTH_INDEX = -1, this.PREPASS_SCREENSPACE_DEPTH = !1, this.PREPASS_SCREENSPACE_DEPTH_INDEX = -1, this.PREPASS_NORMALIZED_VIEW_DEPTH = !1, this.PREPASS_NORMALIZED_VIEW_DEPTH_INDEX = -1, this.PREPASS_NORMAL = !1, this.PREPASS_NORMAL_INDEX = -1, this.PREPASS_NORMAL_WORLDSPACE = !1, this.PREPASS_WORLD_NORMAL = !1, this.PREPASS_WORLD_NORMAL_INDEX = -1, this.PREPASS_POSITION = !1, this.PREPASS_POSITION_INDEX = -1, this.PREPASS_LOCAL_POSITION = !1, this.PREPASS_LOCAL_POSITION_INDEX = -1, this.PREPASS_VELOCITY = !1, this.PREPASS_VELOCITY_INDEX = -1, this.PREPASS_VELOCITY_LINEAR = !1, this.PREPASS_VELOCITY_LINEAR_INDEX = -1, this.PREPASS_REFLECTIVITY = !1, this.PREPASS_REFLECTIVITY_INDEX = -1, this.PREPASS_OBJECT_ID = !1, this.PREPASS_OBJECT_ID_INDEX = -1, this.PREPASS_OBJECT_ID_R8 = !1, this.PREPASS_MESH_BLEND_TAG = !1, this.PREPASS_MESH_BLEND_TAG_INDEX = -1, this.SCENE_MRT_COUNT = 0
        }
      }
    }
    pO.d(KO, {
      c: () => XO
    })
  },
  38355: (OO, KO, pO) => {
    pO.d(KO, {
      StandardMaterial: () => XO.d
    });
    var XO = pO(38360);
    (0, XO.c)()
  },
  38360: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => mK,
      d: () => rK
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(38186),
      lO = pO(38170),
      vK = pO(35688),
      CO = pO(38216),
      hO = pO(38363),
      DO = pO(38371),
      MO = pO(38191),
      aK = pO(38382),
      oO = pO(38378),
      FO = pO(38447),
      VO = pO(38439),
      LO = pO(38449),
      QO = pO(38452),
      zK = pO(38431),
      AO = pO(38460),
      fO = pO(38424),
      dO = pO(38077),
      TO = pO(38464),
      NO = pO(38471),
      IO = pO(38480),
      yK = pO(38488),
      gK = pO(38496),
      uO = pO(35676),
      EO = pO(37938);
    const jK = {
      effect: null,
      subMesh: null
    };
    class YO extends((0, yK.c)((0, IO.c)(oO.e))) {}
    class wO extends((0, DO.f)(YO)) {
      constructor(OO) {
        super(OO), this.DIFFUSE = !1, this.DIFFUSEDIRECTUV = 0, this.BAKED_VERTEX_ANIMATION_TEXTURE = !1, this.AMBIENT = !1, this.AMBIENTDIRECTUV = 0, this.OPACITY = !1, this.OPACITYDIRECTUV = 0, this.OPACITYRGB = !1, this.REFLECTION = !1, this.EMISSIVE = !1, this.EMISSIVEDIRECTUV = 0, this.SPECULAR = !1, this.SPECULARDIRECTUV = 0, this.BUMP = !1, this.BUMPDIRECTUV = 0, this.PARALLAX = !1, this.PARALLAX_RHS = !1, this.PARALLAXOCCLUSION = !1, this.SPECULAROVERALPHA = !1, this.CLIPPLANE = !1, this.CLIPPLANE2 = !1, this.CLIPPLANE3 = !1, this.CLIPPLANE4 = !1, this.CLIPPLANE5 = !1, this.CLIPPLANE6 = !1, this.ALPHATEST = !1, this.DEPTHPREPASS = !1, this.ALPHAFROMDIFFUSE = !1, this.POINTSIZE = !1, this.FOG = !1, this.SPECULARTERM = !1, this.DIFFUSEFRESNEL = !1, this.OPACITYFRESNEL = !1, this.REFLECTIONFRESNEL = !1, this.REFRACTIONFRESNEL = !1, this.EMISSIVEFRESNEL = !1, this.FRESNEL = !1, this.NORMAL = !1, this.TANGENT = !1, this.VERTEXCOLOR = !1, this.VERTEXALPHA = !1, this.NUM_BONE_INFLUENCERS = 0, this.BonesPerMesh = 0, this.BONETEXTURE = !1, this.BONES_VELOCITY_ENABLED = !1, this.INSTANCES = !1, this.THIN_INSTANCES = !1, this.INSTANCESCOLOR = !1, this.GLOSSINESS = !1, this.ROUGHNESS = !1, this.EMISSIVEASILLUMINATION = !1, this.LINKEMISSIVEWITHDIFFUSE = !1, this.REFLECTIONFRESNELFROMSPECULAR = !1, this.LIGHTMAP = !1, this.LIGHTMAPDIRECTUV = 0, this.OBJECTSPACE_NORMALMAP = !1, this.USELIGHTMAPASSHADOWMAP = !1, this.REFLECTIONMAP_3D = !1, this.REFLECTIONMAP_SPHERICAL = !1, this.REFLECTIONMAP_PLANAR = !1, this.REFLECTIONMAP_CUBIC = !1, this.USE_LOCAL_REFLECTIONMAP_CUBIC = !1, this.USE_LOCAL_REFRACTIONMAP_CUBIC = !1, this.REFLECTIONMAP_PROJECTION = !1, this.REFLECTIONMAP_SKYBOX = !1, this.REFLECTIONMAP_EXPLICIT = !1, this.REFLECTIONMAP_EQUIRECTANGULAR = !1, this.REFLECTIONMAP_EQUIRECTANGULAR_FIXED = !1, this.REFLECTIONMAP_MIRROREDEQUIRECTANGULAR_FIXED = !1, this.REFLECTIONMAP_OPPOSITEZ = !1, this.INVERTCUBICMAP = !1, this.LOGARITHMICDEPTH = !1, this.REFRACTION = !1, this.REFRACTIONMAP_3D = !1, this.REFLECTIONOVERALPHA = !1, this.TWOSIDEDLIGHTING = !1, this.SHADOWFLOAT = !1, this.MORPHTARGETS = !1, this.MORPHTARGETS_POSITION = !1, this.MORPHTARGETS_NORMAL = !1, this.MORPHTARGETS_TANGENT = !1, this.MORPHTARGETS_UV = !1, this.MORPHTARGETS_UV2 = !1, this.MORPHTARGETS_COLOR = !1, this.MORPHTARGETTEXTURE_HASPOSITIONS = !1, this.MORPHTARGETTEXTURE_HASNORMALS = !1, this.MORPHTARGETTEXTURE_HASTANGENTS = !1, this.MORPHTARGETTEXTURE_HASUVS = !1, this.MORPHTARGETTEXTURE_HASUV2S = !1, this.MORPHTARGETTEXTURE_HASCOLORS = !1, this.NUM_MORPH_INFLUENCERS = 0, this.MORPHTARGETS_TEXTURE = !1, this.NONUNIFORMSCALING = !1, this.PREMULTIPLYALPHA = !1, this.ALPHATEST_AFTERALLALPHACOMPUTATIONS = !1, this.ALPHABLEND = !0, this.RGBDLIGHTMAP = !1, this.RGBDREFLECTION = !1, this.RGBDREFRACTION = !1, this.MULTIVIEW = !1, this.ORDER_INDEPENDENT_TRANSPARENCY = !1, this.ORDER_INDEPENDENT_TRANSPARENCY_16BITS = !1, this.CAMERA_ORTHOGRAPHIC = !1, this.CAMERA_PERSPECTIVE = !1, this.AREALIGHTSUPPORTED = !0, this.USE_VERTEX_PULLING = !1, this.VERTEX_PULLING_USE_INDEX_BUFFER = !1, this.VERTEX_PULLING_INDEX_BUFFER_32BITS = !1, this.RIGHT_HANDED = !1, this.CLUSTLIGHT_SLICES = 0, this.CLUSTLIGHT_BATCH = 0, this.IS_REFLECTION_LINEAR = !1, this.IS_REFRACTION_LINEAR = !1, this.DECAL_AFTER_DETAIL = !1, this.TEXTURE_REPETITION_MODE = 0, this.rebuild()
      }
    }
    class iK extends((0, gK.e)(FO.d)) {}
    let rK = (() => {
        var OO, KO, DO, oO, IO, yK, gK, uO, EO, YO, rK, PO, mK, sO, HO, RO, SO, JO, cK, BO, ZO, GO, qK, xK, nO, WO, tK, kK, UO, OK, KK, pK, XK;
        let bp, eK, lK, vp, CK, hK, DK, MK, ap, oK, FK, VK, LK, QK, zp, AK, fK, dK, TK, NK, IK, yp, gp, uK, EK, jp, YK, wK, ip, rp, PK, mp, sK, HK, RK, SK, JK, cp, BK, ZK, GK, qp, xp, nK, WK, tp, kp, UK, Op, Kp, pp, Xp, bX, ep, lp, vX, Cp, hp, Dp, Mp, aX, op, Fp, Vp, Lp, Qp, zX, Ap, fp, dp, Tp, Np, Ip, yX = iK,
          gX = [],
          upO = [],
          Ep = [],
          jX = [],
          Yp = [],
          wp = [],
          iX = [],
          rX = [],
          Pp = [],
          mX = [],
          sp = [],
          Hp = [],
          Rp = [],
          Sp = [],
          Jp = [],
          cX = [],
          Bp = [],
          Zp = [],
          Gp = [],
          qX = [],
          xX = [],
          np = [],
          Wp = [],
          tX = [],
          kX = [],
          Up = [],
          OX = [],
          KX = [],
          pX = [],
          XX = [],
          bb = [],
          eX = [],
          lX = [],
          vb = [],
          CX = [],
          hX = [],
          DX = [],
          MX = [],
          ab = [],
          oX = [],
          FX = [],
          VX = [],
          LX = [],
          QX = [],
          zb = [],
          AX = [],
          fX = [],
          dX = [],
          TX = [],
          NX = [],
          IX = [],
          yb = [],
          gb = [],
          uX = [],
          EX = [],
          jb = [],
          YX = [],
          wX = [],
          ib = [],
          rb = [],
          PX = [],
          mb = [],
          sX = [],
          HX = [],
          RX = [],
          SX = [],
          JX = [],
          cb = [],
          BX = [],
          ZX = [],
          GX = [],
          qb = [],
          xb = [],
          nX = [],
          WX = [],
          tb = [],
          kb = [],
          UX = [],
          Ob = [],
          Kb = [],
          pb = [],
          Xb = [],
          be = [],
          eb = [],
          lb = [],
          ve = [],
          Cb = [],
          hb = [],
          Db = [],
          Mb = [],
          ae = [],
          ob = [],
          Fb = [],
          Vb = [],
          Lb = [],
          Qb = [],
          ze = [],
          Ab = [],
          fb = [],
          db = [],
          Tb = [],
          Nb = [],
          Ib = [],
          ye = [],
          ge = [],
          ub = [],
          Eb = [],
          je = [],
          Yb = [],
          wb = [],
          ie = [],
          re = [],
          Pb = [],
          me = [],
          sb = [],
          Hb = [],
          Rb = [],
          Sb = [],
          Jb = [],
          ce = [],
          Bb = [],
          Zb = [],
          Gb = [],
          qe = [],
          xe = [],
          nb = [],
          Wb = [],
          te = [],
          ke = [],
          Ub = [],
          Oe = [],
          Ke = [],
          pe = [],
          Xe = [],
          bl = [],
          ee = [],
          le = [],
          vl = [],
          Ce = [],
          he = [],
          De = [],
          Me = [],
          al = [],
          oe = [],
          Fe = [],
          Ve = [];
        return OO = class extends yX {
          get diffuseTexture() {
            return (0, XO.b)(this, KO, "f")
          }
          set diffuseTexture(OO) {
            (0, XO.e)(this, KO, OO, "f")
          }
          get ambientTexture() {
            return (0, XO.b)(this, DO, "f")
          }
          set ambientTexture(OO) {
            (0, XO.e)(this, DO, OO, "f")
          }
          get opacityTexture() {
            return (0, XO.b)(this, oO, "f")
          }
          set opacityTexture(OO) {
            (0, XO.e)(this, oO, OO, "f")
          }
          get reflectionTexture() {
            return (0, XO.b)(this, IO, "f")
          }
          set reflectionTexture(OO) {
            (0, XO.e)(this, IO, OO, "f")
          }
          get emissiveTexture() {
            return (0, XO.b)(this, yK, "f")
          }
          set emissiveTexture(OO) {
            (0, XO.e)(this, yK, OO, "f")
          }
          get specularTexture() {
            return (0, XO.b)(this, gK, "f")
          }
          set specularTexture(OO) {
            (0, XO.e)(this, gK, OO, "f")
          }
          get bumpTexture() {
            return (0, XO.b)(this, uO, "f")
          }
          set bumpTexture(OO) {
            (0, XO.e)(this, uO, OO, "f")
          }
          get lightmapTexture() {
            return (0, XO.b)(this, EO, "f")
          }
          set lightmapTexture(OO) {
            (0, XO.e)(this, EO, OO, "f")
          }
          get refractionTexture() {
            return (0, XO.b)(this, YO, "f")
          }
          set refractionTexture(OO) {
            (0, XO.e)(this, YO, OO, "f")
          }
          get useAlphaFromDiffuseTexture() {
            return (0, XO.b)(this, rK, "f")
          }
          set useAlphaFromDiffuseTexture(OO) {
            (0, XO.e)(this, rK, OO, "f")
          }
          get useEmissiveAsIllumination() {
            return (0, XO.b)(this, PO, "f")
          }
          set useEmissiveAsIllumination(OO) {
            (0, XO.e)(this, PO, OO, "f")
          }
          get linkEmissiveWithDiffuse() {
            return (0, XO.b)(this, mK, "f")
          }
          set linkEmissiveWithDiffuse(OO) {
            (0, XO.e)(this, mK, OO, "f")
          }
          get useSpecularOverAlpha() {
            return (0, XO.b)(this, sO, "f")
          }
          set useSpecularOverAlpha(OO) {
            (0, XO.e)(this, sO, OO, "f")
          }
          get useReflectionOverAlpha() {
            return (0, XO.b)(this, HO, "f")
          }
          set useReflectionOverAlpha(OO) {
            (0, XO.e)(this, HO, OO, "f")
          }
          get disableLighting() {
            return (0, XO.b)(this, RO, "f")
          }
          set disableLighting(OO) {
            (0, XO.e)(this, RO, OO, "f")
          }
          get useObjectSpaceNormalMap() {
            return (0, XO.b)(this, SO, "f")
          }
          set useObjectSpaceNormalMap(OO) {
            (0, XO.e)(this, SO, OO, "f")
          }
          get useParallax() {
            return (0, XO.b)(this, JO, "f")
          }
          set useParallax(OO) {
            (0, XO.e)(this, JO, OO, "f")
          }
          get useParallaxOcclusion() {
            return (0, XO.b)(this, cK, "f")
          }
          set useParallaxOcclusion(OO) {
            (0, XO.e)(this, cK, OO, "f")
          }
          get roughness() {
            return (0, XO.b)(this, BO, "f")
          }
          set roughness(OO) {
            (0, XO.e)(this, BO, OO, "f")
          }
          get useLightmapAsShadowmap() {
            return (0, XO.b)(this, ZO, "f")
          }
          set useLightmapAsShadowmap(OO) {
            (0, XO.e)(this, ZO, OO, "f")
          }
          get diffuseFresnelParameters() {
            return (0, XO.b)(this, GO, "f")
          }
          set diffuseFresnelParameters(OO) {
            (0, XO.e)(this, GO, OO, "f")
          }
          get opacityFresnelParameters() {
            return (0, XO.b)(this, qK, "f")
          }
          set opacityFresnelParameters(OO) {
            (0, XO.e)(this, qK, OO, "f")
          }
          get reflectionFresnelParameters() {
            return (0, XO.b)(this, xK, "f")
          }
          set reflectionFresnelParameters(OO) {
            (0, XO.e)(this, xK, OO, "f")
          }
          get refractionFresnelParameters() {
            return (0, XO.b)(this, nO, "f")
          }
          set refractionFresnelParameters(OO) {
            (0, XO.e)(this, nO, OO, "f")
          }
          get emissiveFresnelParameters() {
            return (0, XO.b)(this, WO, "f")
          }
          set emissiveFresnelParameters(OO) {
            (0, XO.e)(this, WO, OO, "f")
          }
          get useReflectionFresnelFromSpecular() {
            return (0, XO.b)(this, tK, "f")
          }
          set useReflectionFresnelFromSpecular(OO) {
            (0, XO.e)(this, tK, OO, "f")
          }
          get useGlossinessFromSpecularMapAlpha() {
            return (0, XO.b)(this, kK, "f")
          }
          set useGlossinessFromSpecularMapAlpha(OO) {
            (0, XO.e)(this, kK, OO, "f")
          }
          get maxSimultaneousLights() {
            return (0, XO.b)(this, UO, "f")
          }
          set maxSimultaneousLights(OO) {
            (0, XO.e)(this, UO, OO, "f")
          }
          get invertNormalMapX() {
            return (0, XO.b)(this, OK, "f")
          }
          set invertNormalMapX(OO) {
            (0, XO.e)(this, OK, OO, "f")
          }
          get invertNormalMapY() {
            return (0, XO.b)(this, KK, "f")
          }
          set invertNormalMapY(OO) {
            (0, XO.e)(this, KK, OO, "f")
          }
          get twoSidedLighting() {
            return (0, XO.b)(this, pK, "f")
          }
          set twoSidedLighting(OO) {
            (0, XO.e)(this, pK, OO, "f")
          }
          get applyDecalMapAfterDetailMap() {
            return (0, XO.b)(this, XK, "f")
          }
          set applyDecalMapAfterDetailMap(OO) {
            (0, XO.e)(this, XK, OO, "f")
          }
          get isPrePassCapable() {
            return !this.disableDepthWrite
          }
          get canRenderToMRT() {
            return !0
          }
          constructor(pO, bK) {
            super(pO, bK, void 0, arguments.length > 2 && void 0 !== arguments[2] && arguments[2] || OO.ForceGLSL), this._diffuseTexture = (0, XO.i)(this, gX, null), KO.set(this, ((0, XO.i)(this, upO), (0, XO.i)(this, Ep, void 0))), this._ambientTexture = ((0, XO.i)(this, jX), (0, XO.i)(this, Yp, null)), DO.set(this, ((0, XO.i)(this, wp), (0, XO.i)(this, iX, void 0))), this._opacityTexture = ((0, XO.i)(this, rX), (0, XO.i)(this, Pp, null)), oO.set(this, ((0, XO.i)(this, mX), (0, XO.i)(this, sp, void 0))), this._reflectionTexture = ((0, XO.i)(this, Hp), (0, XO.i)(this, Rp, null)), IO.set(this, ((0, XO.i)(this, Sp), (0, XO.i)(this, Jp, void 0))), this._emissiveTexture = ((0, XO.i)(this, cX), (0, XO.i)(this, Bp, null)), yK.set(this, ((0, XO.i)(this, Zp), (0, XO.i)(this, Gp, void 0))), this._specularTexture = ((0, XO.i)(this, qX), (0, XO.i)(this, xX, null)), gK.set(this, ((0, XO.i)(this, np), (0, XO.i)(this, Wp, void 0))), this._bumpTexture = ((0, XO.i)(this, tX), (0, XO.i)(this, kX, null)), uO.set(this, ((0, XO.i)(this, Up), (0, XO.i)(this, OX, void 0))), this._lightmapTexture = ((0, XO.i)(this, KX), (0, XO.i)(this, pX, null)), EO.set(this, ((0, XO.i)(this, XX), (0, XO.i)(this, bb, void 0))), this._refractionTexture = ((0, XO.i)(this, eX), (0, XO.i)(this, lX, null)), YO.set(this, ((0, XO.i)(this, vb), (0, XO.i)(this, CX, void 0))), this.ambientColor = ((0, XO.i)(this, hX), (0, XO.i)(this, DX, new vK.e(0, 0, 0))), this.diffuseColor = ((0, XO.i)(this, MX), (0, XO.i)(this, ab, new vK.e(1, 1, 1))), this.specularColor = ((0, XO.i)(this, oX), (0, XO.i)(this, FX, new vK.e(1, 1, 1))), this.emissiveColor = ((0, XO.i)(this, VX), (0, XO.i)(this, LX, new vK.e(0, 0, 0))), this.specularPower = ((0, XO.i)(this, QX), (0, XO.i)(this, zb, 64)), this._useAlphaFromDiffuseTexture = ((0, XO.i)(this, AX), (0, XO.i)(this, fX, !1)), rK.set(this, ((0, XO.i)(this, dX), (0, XO.i)(this, TX, void 0))), this._useEmissiveAsIllumination = ((0, XO.i)(this, NX), (0, XO.i)(this, IX, !1)), PO.set(this, ((0, XO.i)(this, yb), (0, XO.i)(this, gb, void 0))), this._linkEmissiveWithDiffuse = ((0, XO.i)(this, uX), (0, XO.i)(this, EX, !1)), mK.set(this, ((0, XO.i)(this, jb), (0, XO.i)(this, YX, void 0))), this._useSpecularOverAlpha = ((0, XO.i)(this, wX), (0, XO.i)(this, ib, !1)), sO.set(this, ((0, XO.i)(this, rb), (0, XO.i)(this, PX, void 0))), this._useReflectionOverAlpha = ((0, XO.i)(this, mb), (0, XO.i)(this, sX, !1)), HO.set(this, ((0, XO.i)(this, HX), (0, XO.i)(this, RX, void 0))), this._disableLighting = ((0, XO.i)(this, SX), (0, XO.i)(this, JX, !1)), RO.set(this, ((0, XO.i)(this, cb), (0, XO.i)(this, BX, void 0))), this._useObjectSpaceNormalMap = ((0, XO.i)(this, ZX), (0, XO.i)(this, GX, !1)), SO.set(this, ((0, XO.i)(this, qb), (0, XO.i)(this, xb, void 0))), this._useParallax = ((0, XO.i)(this, nX), (0, XO.i)(this, WX, !1)), JO.set(this, ((0, XO.i)(this, tb), (0, XO.i)(this, kb, void 0))), this._useParallaxOcclusion = ((0, XO.i)(this, UX), (0, XO.i)(this, Ob, !1)), cK.set(this, ((0, XO.i)(this, Kb), (0, XO.i)(this, pb, void 0))), this.parallaxScaleBias = ((0, XO.i)(this, Xb), (0, XO.i)(this, be, .05)), this._roughness = ((0, XO.i)(this, eb), (0, XO.i)(this, lb, 0)), BO.set(this, ((0, XO.i)(this, ve), (0, XO.i)(this, Cb, void 0))), this.indexOfRefraction = ((0, XO.i)(this, hb), (0, XO.i)(this, Db, .98)), this.invertRefractionY = ((0, XO.i)(this, Mb), (0, XO.i)(this, ae, !0)), this.alphaCutOff = ((0, XO.i)(this, ob), (0, XO.i)(this, Fb, .4)), this._useLightmapAsShadowmap = ((0, XO.i)(this, Vb), (0, XO.i)(this, Lb, !1)), ZO.set(this, ((0, XO.i)(this, Qb), (0, XO.i)(this, ze, void 0))), this._diffuseFresnelParameters = ((0, XO.i)(this, Ab), (0, XO.i)(this, fb, void 0)), GO.set(this, ((0, XO.i)(this, db), (0, XO.i)(this, Tb, void 0))), this._opacityFresnelParameters = ((0, XO.i)(this, Nb), (0, XO.i)(this, Ib, void 0)), qK.set(this, ((0, XO.i)(this, ye), (0, XO.i)(this, ge, void 0))), this._reflectionFresnelParameters = ((0, XO.i)(this, ub), (0, XO.i)(this, Eb, void 0)), xK.set(this, ((0, XO.i)(this, je), (0, XO.i)(this, Yb, void 0))), this._refractionFresnelParameters = ((0, XO.i)(this, wb), (0, XO.i)(this, ie, void 0)), nO.set(this, ((0, XO.i)(this, re), (0, XO.i)(this, Pb, void 0))), this._emissiveFresnelParameters = ((0, XO.i)(this, me), (0, XO.i)(this, sb, void 0)), WO.set(this, ((0, XO.i)(this, Hb), (0, XO.i)(this, Rb, void 0))), this._useReflectionFresnelFromSpecular = ((0, XO.i)(this, Sb), (0, XO.i)(this, Jb, !1)), tK.set(this, ((0, XO.i)(this, ce), (0, XO.i)(this, Bb, void 0))), this._useGlossinessFromSpecularMapAlpha = ((0, XO.i)(this, Zb), (0, XO.i)(this, Gb, !1)), kK.set(this, ((0, XO.i)(this, qe), (0, XO.i)(this, xe, void 0))), this._maxSimultaneousLights = ((0, XO.i)(this, nb), (0, XO.i)(this, Wb, 4)), UO.set(this, ((0, XO.i)(this, te), (0, XO.i)(this, ke, void 0))), this._invertNormalMapX = ((0, XO.i)(this, Ub), (0, XO.i)(this, Oe, !1)), OK.set(this, ((0, XO.i)(this, Ke), (0, XO.i)(this, pe, void 0))), this._invertNormalMapY = ((0, XO.i)(this, Xe), (0, XO.i)(this, bl, !1)), KK.set(this, ((0, XO.i)(this, ee), (0, XO.i)(this, le, void 0))), this._twoSidedLighting = ((0, XO.i)(this, vl), (0, XO.i)(this, Ce, !1)), pK.set(this, ((0, XO.i)(this, he), (0, XO.i)(this, De, void 0))), this._applyDecalMapAfterDetailMap = ((0, XO.i)(this, Me), (0, XO.i)(this, al, !1)), XK.set(this, ((0, XO.i)(this, oe), (0, XO.i)(this, Fe, void 0))), this._vertexPullingMetadata = ((0, XO.i)(this, Ve), null), this._renderTargets = new eO.e(16), this._globalAmbientColor = new vK.e(0, 0, 0), this._cacheHasRenderTargetTextures = !1, this.detailMap = new QO.e(this), this._attachImageProcessingConfiguration(null), this.prePassConfiguration = new hO.c, this.getRenderTargetTextures = () => (this._renderTargets.reset(), OO.ReflectionTextureEnabled && this._reflectionTexture && this._reflectionTexture.isRenderTarget && this._renderTargets.push(this._reflectionTexture), OO.RefractionTextureEnabled && this._refractionTexture && this._refractionTexture.isRenderTarget && this._renderTargets.push(this._refractionTexture), this._eventInfo.renderTargets = this._renderTargets, this._callbackPluginEventFillRenderTargetTextures(this._eventInfo), this._renderTargets)
          }
          get hasRenderTargetTextures() {
            return !!(OO.ReflectionTextureEnabled && this._reflectionTexture && this._reflectionTexture.isRenderTarget) || (!!(OO.RefractionTextureEnabled && this._refractionTexture && this._refractionTexture.isRenderTarget) || this._cacheHasRenderTargetTextures)
          }
          getClassName() {
            return "StandardMaterial"
          }
          needAlphaBlending() {
            return this._hasTransparencyMode ? this._transparencyModeIsBlend : !this._disableAlphaBlending && (this.alpha < 1 || null != this._opacityTexture || this._shouldUseAlphaFromDiffuseTexture() || this._opacityFresnelParameters && this._opacityFresnelParameters.isEnabled)
          }
          needAlphaTesting() {
            return this._hasTransparencyMode ? this._transparencyModeIsTest : this._hasAlphaChannel() && (null == this._transparencyMode || this._transparencyMode === aK.b.MATERIAL_ALPHATEST)
          }
          _shouldUseAlphaFromDiffuseTexture() {
            return null != this._diffuseTexture && this._diffuseTexture.hasAlpha && this._useAlphaFromDiffuseTexture && this._transparencyMode !== aK.b.MATERIAL_OPAQUE
          }
          _hasAlphaChannel() {
            return null != this._diffuseTexture && this._diffuseTexture.hasAlpha || null != this._opacityTexture
          }
          getAlphaTestTexture() {
            return this._diffuseTexture
          }
          isReadyForSubMesh(KO, pO) {
            let XO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
            this._uniformBufferLayoutBuilt || this.buildUniformLayout();
            const bK = pO._drawWrapper;
            if (bK.effect && this.isFrozen && bK._wasPreviouslyReady && bK._wasPreviouslyUsingInstances === XO) return !0;
            pO.materialDefines || (this._callbackPluginEventGeneric(4, this._eventInfo), pO.materialDefines = new wO(this._eventInfo.defineNames));
            const eO = this.JKO(),
              lO = pO.materialDefines;
            if (this._isReadyForSubMesh(pO)) return !0;
            const vK = eO.qb();
            if (lO._needNormals = (0, fO._)(eO, KO, lO, !0, this._maxSimultaneousLights, this._disableLighting), !(0, fO.c)(eO, KO, this._maxSimultaneousLights, this._disableLighting)) return !1;
            (0, fO.hb)(eO, lO);
            const DO = this.needAlphaBlendingForMesh(KO) && this.JKO().useOrderIndependentTransparency;
            if ((0, fO.mb)(eO, lO, this.canRenderToMRT && !DO), (0, fO.ib)(eO, lO, DO), NO.d.PrepareDefines(vK.currentRenderPassId, KO, lO), lO._areTexturesDirty) {
              this._eventInfo.hasRenderTargetTextures = !1, this._callbackPluginEventHasRenderTargetTextures(this._eventInfo), this._cacheHasRenderTargetTextures = this._eventInfo.hasRenderTargetTextures, lO._needUVs = !1;
              for (let OO = 1; OO <= 6; ++OO) lO["MAINUV" + OO] = !1;
              if (eO.texturesEnabled) {
                if (lO.DIFFUSEDIRECTUV = 0, lO.BUMPDIRECTUV = 0, lO.AMBIENTDIRECTUV = 0, lO.OPACITYDIRECTUV = 0, lO.EMISSIVEDIRECTUV = 0, lO.SPECULARDIRECTUV = 0, lO.LIGHTMAPDIRECTUV = 0, this._diffuseTexture && OO.DiffuseTextureEnabled) {
                  if (!this._diffuseTexture.isReadyOrNotBlocking()) return !1;
                  (0, fO.bb)(this._diffuseTexture, lO, "DIFFUSE")
                } else lO.DIFFUSE = !1;
                if (this._ambientTexture && OO.AmbientTextureEnabled) {
                  if (!this._ambientTexture.isReadyOrNotBlocking()) return !1;
                  (0, fO.bb)(this._ambientTexture, lO, "AMBIENT")
                } else lO.AMBIENT = !1;
                if (this._opacityTexture && OO.OpacityTextureEnabled) {
                  if (!this._opacityTexture.isReadyOrNotBlocking()) return !1;
                  (0, fO.bb)(this._opacityTexture, lO, "OPACITY"), lO.OPACITYRGB = this._opacityTexture.getAlphaFromRGB
                } else lO.OPACITY = !1;
                if (this._reflectionTexture && OO.ReflectionTextureEnabled ? (lO.ROUGHNESS = this._roughness > 0, lO.REFLECTIONOVERALPHA = this._useReflectionOverAlpha) : (lO.ROUGHNESS = !1, lO.REFLECTIONOVERALPHA = !1), !(0, fO.Z)(eO, this._reflectionTexture, lO)) return !1;
                if (this._emissiveTexture && OO.EmissiveTextureEnabled) {
                  if (!this._emissiveTexture.isReadyOrNotBlocking()) return !1;
                  (0, fO.bb)(this._emissiveTexture, lO, "EMISSIVE")
                } else lO.EMISSIVE = !1;
                if (this._lightmapTexture && OO.LightmapTextureEnabled) {
                  if (!this._lightmapTexture.isReadyOrNotBlocking()) return !1;
                  (0, fO.bb)(this._lightmapTexture, lO, "LIGHTMAP"), lO.USELIGHTMAPASSHADOWMAP = this._useLightmapAsShadowmap, lO.RGBDLIGHTMAP = this._lightmapTexture.isRGBD
                } else lO.LIGHTMAP = !1;
                if (this._specularTexture && OO.SpecularTextureEnabled) {
                  if (!this._specularTexture.isReadyOrNotBlocking()) return !1;
                  (0, fO.bb)(this._specularTexture, lO, "SPECULAR"), lO.GLOSSINESS = this._useGlossinessFromSpecularMapAlpha
                } else lO.SPECULAR = !1;
                if (eO.qb().getCaps().standardDerivatives && this._bumpTexture && OO.BumpTextureEnabled) {
                  if (!this._bumpTexture.isReady()) return !1;
                  (0, fO.bb)(this._bumpTexture, lO, "BUMP"), lO.PARALLAX = this._useParallax, lO.PARALLAX_RHS = eO.useRightHandedSystem, lO.PARALLAXOCCLUSION = this._useParallaxOcclusion, lO.OBJECTSPACE_NORMALMAP = this._useObjectSpaceNormalMap
                } else lO.BUMP = !1, lO.PARALLAX = !1, lO.PARALLAX_RHS = !1, lO.PARALLAXOCCLUSION = !1;
                if (this._refractionTexture && OO.RefractionTextureEnabled) {
                  if (!this._refractionTexture.isReadyOrNotBlocking()) return !1;
                  lO._needUVs = !0, lO.REFRACTION = !0, lO.REFRACTIONMAP_3D = this._refractionTexture.isCube, lO.RGBDREFRACTION = this._refractionTexture.isRGBD, lO.USE_LOCAL_REFRACTIONMAP_CUBIC = !!this._refractionTexture.boundingBoxSize
                } else lO.REFRACTION = !1;
                lO.TWOSIDEDLIGHTING = !this._backFaceCulling && this._twoSidedLighting
              } else lO.DIFFUSE = !1, lO.AMBIENT = !1, lO.OPACITY = !1, lO.REFLECTION = !1, lO.EMISSIVE = !1, lO.LIGHTMAP = !1, lO.BUMP = !1, lO.REFRACTION = !1;
              lO.ALPHAFROMDIFFUSE = this._shouldUseAlphaFromDiffuseTexture(), lO.EMISSIVEASILLUMINATION = this._useEmissiveAsIllumination, lO.LINKEMISSIVEWITHDIFFUSE = this._linkEmissiveWithDiffuse, lO.SPECULAROVERALPHA = this._useSpecularOverAlpha, lO.PREMULTIPLYALPHA = 7 === this.alphaMode || 8 === this.alphaMode, lO.ALPHATEST_AFTERALLALPHACOMPUTATIONS = null !== this.transparencyMode, lO.ALPHABLEND = null === this.transparencyMode || this.needAlphaBlendingForMesh(KO), lO.TEXTURE_REPETITION_MODE = vK.version > 1 || vK.isWebGPU ? this.textureRepetitionMode : 0
            }
            if (this._eventInfo.isReadyForSubMesh = !0, this._eventInfo.defines = lO, this._eventInfo.subMesh = pO, this._callbackPluginEventIsReadyForSubMesh(this._eventInfo), !this._eventInfo.isReadyForSubMesh) return !1;
            if (lO._areImageProcessingDirty && this._imageProcessingConfiguration) {
              if (!this._imageProcessingConfiguration.isReady()) return !1;
              this._imageProcessingConfiguration.prepareDefines(lO), lO.IS_REFLECTION_LINEAR = null != this.reflectionTexture && !this.reflectionTexture.gammaSpace, lO.IS_REFRACTION_LINEAR = null != this.refractionTexture && !this.refractionTexture.gammaSpace
            }
            if (lO._areFresnelDirty && (OO.FresnelEnabled ? (this._diffuseFresnelParameters || this._opacityFresnelParameters || this._emissiveFresnelParameters || this._refractionFresnelParameters || this._reflectionFresnelParameters) && (lO.DIFFUSEFRESNEL = this._diffuseFresnelParameters && this._diffuseFresnelParameters.isEnabled, lO.OPACITYFRESNEL = this._opacityFresnelParameters && this._opacityFresnelParameters.isEnabled, lO.REFLECTIONFRESNEL = this._reflectionFresnelParameters && this._reflectionFresnelParameters.isEnabled, lO.REFLECTIONFRESNELFROMSPECULAR = this._useReflectionFresnelFromSpecular, lO.REFRACTIONFRESNEL = this._refractionFresnelParameters && this._refractionFresnelParameters.isEnabled, lO.EMISSIVEFRESNEL = this._emissiveFresnelParameters && this._emissiveFresnelParameters.isEnabled, lO._needNormals = !0, lO.FRESNEL = !0) : lO.FRESNEL = !1), lO.AREALIGHTUSED || lO.CLUSTLIGHT_BATCH)
              for (let OO = 0; OO < KO.lightSources.length; OO++)
                if (!KO.lightSources[OO]._isReady()) return !1;
            (0, fO.fb)(KO, eO, this._useLogarithmicDepth, this.pointsCloud, this.fogEnabled, this.needAlphaTestingForMesh(KO), lO, this._applyDecalMapAfterDetailMap, this._useVertexPulling, pO.getRenderingMesh(), this._isVertexOutputInvariant), (0, fO.V)(eO, vK, this, lO, XO, null, pO.getRenderingMesh().hasThinInstances), this._eventInfo.defines = lO, this._eventInfo.mesh = KO, this._callbackPluginEventPrepareDefinesBeforeAttributes(this._eventInfo), (0, fO.S)(KO, lO, !0, !0, !0), this._callbackPluginEventPrepareDefines(this._eventInfo);
            let aK = !1;
            if (lO.isDirty) {
              const XO = lO._areLightsDisposed;
              lO.markAsProcessed();
              const bK = new LO.c;
              lO.REFLECTION && bK.addFallback(0, "REFLECTION"), lO.SPECULAR && bK.addFallback(0, "SPECULAR"), lO.BUMP && bK.addFallback(0, "BUMP"), lO.PARALLAX && bK.addFallback(1, "PARALLAX"), lO.PARALLAX_RHS && bK.addFallback(1, "PARALLAX_RHS"), lO.PARALLAXOCCLUSION && bK.addFallback(0, "PARALLAXOCCLUSION"), lO.SPECULAROVERALPHA && bK.addFallback(0, "SPECULAROVERALPHA"), lO.FOG && bK.addFallback(1, "FOG"), lO.POINTSIZE && bK.addFallback(0, "POINTSIZE"), lO.LOGARITHMICDEPTH && bK.addFallback(0, "LOGARITHMICDEPTH"), (0, fO.F)(lO, bK, this._maxSimultaneousLights), lO.SPECULARTERM && bK.addFallback(0, "SPECULARTERM"), lO.DIFFUSEFRESNEL && bK.addFallback(1, "DIFFUSEFRESNEL"), lO.OPACITYFRESNEL && bK.addFallback(2, "OPACITYFRESNEL"), lO.REFLECTIONFRESNEL && bK.addFallback(3, "REFLECTIONFRESNEL"), lO.EMISSIVEFRESNEL && bK.addFallback(4, "EMISSIVEFRESNEL"), lO.FRESNEL && bK.addFallback(4, "FRESNEL"), lO.MULTIVIEW && bK.addFallback(0, "MULTIVIEW");
              const DO = [CO.j.PositionKind];
              lO.NORMAL && DO.push(CO.j.NormalKind), lO.TANGENT && DO.push(CO.j.TangentKind);
              for (let OO = 1; OO <= 6; ++OO) lO["UV" + OO] && DO.push(`uv${1===OO?"":OO}`);
              lO.VERTEXCOLOR && DO.push(CO.j.ColorKind), (0, fO.H)(DO, KO, lO, bK), (0, fO.L)(DO, lO), (0, fO.N)(DO, KO, lO), (0, fO.G)(DO, KO, lO);
              let oO = "default";
              const FO = ["world", "view", "viewProjection", "vEyePosition", "vLightsType", "vAmbientColor", "vDiffuseColor", "vSpecularColor", "vEmissiveColor", "visibility", "vFogInfos", "vFogColor", "pointSize", "vDiffuseInfos", "vAmbientInfos", "vOpacityInfos", "vEmissiveInfos", "vSpecularInfos", "vBumpInfos", "vLightmapInfos", "vRefractionInfos", "mBones", "diffuseMatrix", "ambientMatrix", "opacityMatrix", "emissiveMatrix", "specularMatrix", "bumpMatrix", "normalMatrix", "lightmapMatrix", "refractionMatrix", "diffuseLeftColor", "diffuseRightColor", "opacityParts", "reflectionLeftColor", "reflectionRightColor", "emissiveLeftColor", "emissiveRightColor", "refractionLeftColor", "refractionRightColor", "vRefractionPosition", "vRefractionSize", "logarithmicDepthConstant", "vTangentSpaceParams", "alphaCutOff", "boneTextureInfo", "morphTargetTextureInfo", "morphTargetTextureIndices", "cameraInfo", "vTextureRepetitionHexTilingParams"],
                VO = ["diffuseSampler", "ambientSampler", "opacitySampler", "reflectionCubeSampler", "reflection2DSampler", "emissiveSampler", "specularSampler", "bumpSampler", "lightmapSampler", "refractionCubeSampler", "refraction2DSampler", "boneSampler", "morphTargets", "oitDepthSampler", "oitFrontColorSampler", "areaLightsLTC1Sampler", "areaLightsLTC2Sampler"];
              (0, fO.rb)(FO, VO, !1);
              const QO = ["Material", "Scene", "Mesh"],
                dO = {
                  maxSimultaneousLights: this._maxSimultaneousLights,
                  maxSimultaneousMorphTargets: lO.NUM_MORPH_INFLUENCERS
                };
              if (this._eventInfo.fallbacks = bK, this._eventInfo.fallbackRank = 0, this._eventInfo.defines = lO, this._eventInfo.uniforms = FO, this._eventInfo.attributes = DO, this._eventInfo.samplers = VO, this._eventInfo.uniformBuffersNames = QO, this._eventInfo.customCode = void 0, this._eventInfo.mesh = KO, this._eventInfo.indexParameters = dO, this._callbackPluginEventGeneric(128, this._eventInfo), NO.d.AddUniformsAndSamplers(FO, VO), hO.c.AddUniforms(FO), hO.c.AddSamplers(VO), MO.d && (MO.d.PrepareUniforms(FO, lO), MO.d.PrepareSamplers(VO, lO)), (0, fO.ub)({
                  uniformsNames: FO,
                  uniformBuffersNames: QO,
                  samplers: VO,
                  defines: lO,
                  maxSimultaneousLights: this._maxSimultaneousLights,
                  shaderLanguage: this._shaderLanguage
                }), (0, zK.c)(FO), this._useVertexPulling) {
                const OO = pO.getRenderingMesh(),
                  KO = OO?.geometry;
                KO && (this._vertexPullingMetadata = (0, AO.e)(KO), this._vertexPullingMetadata && this._vertexPullingMetadata.forEach(((OO, KO) => {
                  FO.push(`vp_${KO}_info`)
                })))
              } else this._vertexPullingMetadata = null;
              const TO = {};
              this.customShaderNameResolve && (oO = this.customShaderNameResolve(oO, FO, QO, VO, lO, DO, TO));
              const IO = lO.toString(),
                yK = pO.effect,
                gK = eO.qb().createEffect(oO, {
                  attributes: DO,
                  uniformsNames: FO,
                  uniformBuffersNames: QO,
                  samplers: VO,
                  defines: IO,
                  fallbacks: bK,
                  onCompiled: this.onCompiled,
                  onError: this.onError,
                  indexParameters: dO,
                  processFinalCode: TO.processFinalCode,
                  processCodeAfterIncludes: this._eventInfo.customCode,
                  multiTarget: lO.PREPASS,
                  shaderLanguage: this._shaderLanguage,
                  extraInitializationsAsync: OO._ShaderLoader.getLoadCallback(this._shaderLanguage)
                }, vK);
              if (this._eventInfo.customCode = void 0, gK)
                if (this._onEffectCreatedObservable && (jK.effect = gK, jK.subMesh = pO, this._onEffectCreatedObservable.notifyObservers(jK)), this.allowShaderHotSwapping && yK && !gK.isReady()) {
                  if (lO.markAsUnprocessed(), aK = this.isFrozen, XO) return lO._areLightsDisposed = !0, !1
                } else eO.resetCachedMaterial(), pO.setEffect(gK, lO, this._materialContext)
            }
            return !(!pO.effect || !pO.effect.isReady()) && (lO._renderId = eO.getRenderId(), bK._wasPreviouslyReady = !aK, bK._wasPreviouslyUsingInstances = XO, this._checkScenePerformancePriority(), !0)
          }
          buildUniformLayout() {
            const OO = this._uniformBuffer;
            OO.addUniform("diffuseLeftColor", 4), OO.addUniform("diffuseRightColor", 4), OO.addUniform("opacityParts", 4), OO.addUniform("reflectionLeftColor", 4), OO.addUniform("reflectionRightColor", 4), OO.addUniform("refractionLeftColor", 4), OO.addUniform("refractionRightColor", 4), OO.addUniform("emissiveLeftColor", 4), OO.addUniform("emissiveRightColor", 4), OO.addUniform("vDiffuseInfos", 2), OO.addUniform("vAmbientInfos", 2), OO.addUniform("vOpacityInfos", 2), OO.addUniform("vEmissiveInfos", 2), OO.addUniform("vLightmapInfos", 2), OO.addUniform("vSpecularInfos", 2), OO.addUniform("vBumpInfos", 3), OO.addUniform("diffuseMatrix", 16), OO.addUniform("ambientMatrix", 16), OO.addUniform("opacityMatrix", 16), OO.addUniform("emissiveMatrix", 16), OO.addUniform("lightmapMatrix", 16), OO.addUniform("specularMatrix", 16), OO.addUniform("bumpMatrix", 16), OO.addUniform("vTangentSpaceParams", 2), OO.addUniform("pointSize", 1), OO.addUniform("alphaCutOff", 1), OO.addUniform("refractionMatrix", 16), OO.addUniform("vRefractionInfos", 4), OO.addUniform("vRefractionPosition", 3), OO.addUniform("vRefractionSize", 3), OO.addUniform("vSpecularColor", 4), OO.addUniform("vEmissiveColor", 3), OO.addUniform("vDiffuseColor", 4), OO.addUniform("vAmbientColor", 3), OO.addUniform("cameraInfo", 4), OO.addUniform("vTextureRepetitionHexTilingParams", 4), (0, fO.nb)(OO, !1, !0), super.buildUniformLayout()
          }
          bindForSubMesh(KO, pO, XO) {
            const bK = this.JKO(),
              eO = XO.materialDefines;
            if (!eO) return;
            const CO = XO.effect;
            if (!CO) return;
            this._activeEffect = CO, pO.getMeshUniformBuffer().bindToEffect(CO, "Mesh"), pO.transferToEffect(KO), this._uniformBuffer.bindToEffect(CO, "Material"), this.prePassConfiguration.bindForSubMesh(this._activeEffect, bK, pO, KO, this.isFrozen), NO.d.Bind(bK.qb().currentRenderPassId, this._activeEffect, pO, KO, this);
            const hO = bK.activeCamera;
            hO ? this._uniformBuffer.updateFloat4("cameraInfo", hO.minZ, hO.maxZ, 0, 0) : this._uniformBuffer.updateFloat4("cameraInfo", 0, 0, 0, 0);
            const DO = this.textureRepetitionHexTilingParams;
            this._uniformBuffer.updateFloat4("vTextureRepetitionHexTilingParams", DO[0], DO[1], DO[2], DO[3]), this._eventInfo.subMesh = XO, this._callbackPluginEventHardBindForSubMesh(this._eventInfo), eO.OBJECTSPACE_NORMALMAP && (KO.toNormalMatrix(this._normalMatrix), this.bindOnlyNormalMatrix(this._normalMatrix));
            const MO = this._mustRebind(bK, CO, XO, pO.visibility),
              aK = bK.qb()._features.needToAlwaysBindUniformBuffers;
            (0, fO.g)(pO, CO), this._vertexPullingMetadata && (0, AO.c)(CO, this._vertexPullingMetadata);
            const oO = this._uniformBuffer;
            if (MO) {
              if (this.bindViewProjection(CO), !oO.useUbo || !this.isFrozen || !oO.isSync || XO._drawWrapper._forceRebindOnNextCall) {
                if (OO.FresnelEnabled && eO.FRESNEL) {
                  if (this.diffuseFresnelParameters && this.diffuseFresnelParameters.isEnabled && (oO.updateColor4("diffuseLeftColor", this.diffuseFresnelParameters.leftColor, this.diffuseFresnelParameters.power), oO.updateColor4("diffuseRightColor", this.diffuseFresnelParameters.rightColor, this.diffuseFresnelParameters.bias)), this.opacityFresnelParameters && this.opacityFresnelParameters.isEnabled) {
                    const OO = vK.j.Color3[0];
                    OO.set(this.opacityFresnelParameters.leftColor.toLuminance(), this.opacityFresnelParameters.rightColor.toLuminance(), this.opacityFresnelParameters.bias), oO.updateColor4("opacityParts", OO, this.opacityFresnelParameters.power)
                  }
                  this.reflectionFresnelParameters && this.reflectionFresnelParameters.isEnabled && (oO.updateColor4("reflectionLeftColor", this.reflectionFresnelParameters.leftColor, this.reflectionFresnelParameters.power), oO.updateColor4("reflectionRightColor", this.reflectionFresnelParameters.rightColor, this.reflectionFresnelParameters.bias)), this.refractionFresnelParameters && this.refractionFresnelParameters.isEnabled && (oO.updateColor4("refractionLeftColor", this.refractionFresnelParameters.leftColor, this.refractionFresnelParameters.power), oO.updateColor4("refractionRightColor", this.refractionFresnelParameters.rightColor, this.refractionFresnelParameters.bias)), this.emissiveFresnelParameters && this.emissiveFresnelParameters.isEnabled && (oO.updateColor4("emissiveLeftColor", this.emissiveFresnelParameters.leftColor, this.emissiveFresnelParameters.power), oO.updateColor4("emissiveRightColor", this.emissiveFresnelParameters.rightColor, this.emissiveFresnelParameters.bias))
                }
                if (eO.ALPHATEST && oO.updateFloat("alphaCutOff", this.alphaCutOff), bK.texturesEnabled && (this._diffuseTexture && OO.DiffuseTextureEnabled && (oO.updateFloat2("vDiffuseInfos", this._diffuseTexture.coordinatesIndex, this._diffuseTexture.level), (0, fO.B)(this._diffuseTexture, oO, "diffuse")), this._ambientTexture && OO.AmbientTextureEnabled && (oO.updateFloat2("vAmbientInfos", this._ambientTexture.coordinatesIndex, this._ambientTexture.level), (0, fO.B)(this._ambientTexture, oO, "ambient")), this._opacityTexture && OO.OpacityTextureEnabled && (oO.updateFloat2("vOpacityInfos", this._opacityTexture.coordinatesIndex, this._opacityTexture.level), (0, fO.B)(this._opacityTexture, oO, "opacity")), (0, fO.k)(bK, eO, oO, vK.e.White(), this._reflectionTexture, !1, !1, !0, !1, !1, !1, this.roughness), this._reflectionTexture && OO.ReflectionTextureEnabled || oO.updateFloat2("vReflectionInfos", 0, this.roughness), this._emissiveTexture && OO.EmissiveTextureEnabled && (oO.updateFloat2("vEmissiveInfos", this._emissiveTexture.coordinatesIndex, this._emissiveTexture.level), (0, fO.B)(this._emissiveTexture, oO, "emissive")), this._lightmapTexture && OO.LightmapTextureEnabled && (oO.updateFloat2("vLightmapInfos", this._lightmapTexture.coordinatesIndex, this._lightmapTexture.level), (0, fO.B)(this._lightmapTexture, oO, "lightmap")), this._specularTexture && OO.SpecularTextureEnabled && (oO.updateFloat2("vSpecularInfos", this._specularTexture.coordinatesIndex, this._specularTexture.level), (0, fO.B)(this._specularTexture, oO, "specular")), this._bumpTexture && bK.qb().getCaps().standardDerivatives && OO.BumpTextureEnabled && (oO.updateFloat3("vBumpInfos", this._bumpTexture.coordinatesIndex, 1 / this._bumpTexture.level, this.parallaxScaleBias), (0, fO.B)(this._bumpTexture, oO, "bump"), bK._mirroredCameraPosition ? oO.updateFloat2("vTangentSpaceParams", this._invertNormalMapX ? 1 : -1, this._invertNormalMapY ? 1 : -1) : oO.updateFloat2("vTangentSpaceParams", this._invertNormalMapX ? -1 : 1, this._invertNormalMapY ? -1 : 1)), this._refractionTexture && OO.RefractionTextureEnabled)) {
                  let OO = 1;
                  if (this._refractionTexture.isCube || (oO.AlO("refractionMatrix", this._refractionTexture.getReflectionTextureMatrix()), this._refractionTexture.depth && (OO = this._refractionTexture.depth)), oO.updateFloat4("vRefractionInfos", this._refractionTexture.level, this.indexOfRefraction, OO, this.invertRefractionY ? -1 : 1), this._refractionTexture.boundingBoxSize) {
                    const OO = this._refractionTexture;
                    oO.updateVector3("vRefractionPosition", OO.boundingBoxPosition), oO.updateVector3("vRefractionSize", OO.boundingBoxSize)
                  }
                }
                this.pointsCloud && oO.updateFloat("pointSize", this.pointSize), oO.updateColor4("vSpecularColor", this.specularColor, this.specularPower), oO.updateColor3("vEmissiveColor", OO.EmissiveTextureEnabled ? this.emissiveColor : vK.e.BlackReadOnly), oO.updateColor4("vDiffuseColor", this.diffuseColor, this.alpha), bK.ambientColor.multiplyToRef(this.ambientColor, this._globalAmbientColor), oO.updateColor3("vAmbientColor", this._globalAmbientColor)
              }
              bK.texturesEnabled && (this._diffuseTexture && OO.DiffuseTextureEnabled && CO.setTexture("diffuseSampler", this._diffuseTexture), this._ambientTexture && OO.AmbientTextureEnabled && CO.setTexture("ambientSampler", this._ambientTexture), this._opacityTexture && OO.OpacityTextureEnabled && CO.setTexture("opacitySampler", this._opacityTexture), this._reflectionTexture && OO.ReflectionTextureEnabled && (this._reflectionTexture.isCube ? CO.setTexture("reflectionCubeSampler", this._reflectionTexture) : CO.setTexture("reflection2DSampler", this._reflectionTexture)), this._emissiveTexture && OO.EmissiveTextureEnabled && CO.setTexture("emissiveSampler", this._emissiveTexture), this._lightmapTexture && OO.LightmapTextureEnabled && CO.setTexture("lightmapSampler", this._lightmapTexture), this._specularTexture && OO.SpecularTextureEnabled && CO.setTexture("specularSampler", this._specularTexture), this._bumpTexture && bK.qb().getCaps().standardDerivatives && OO.BumpTextureEnabled && CO.setTexture("bumpSampler", this._bumpTexture), this._refractionTexture && OO.RefractionTextureEnabled && (this._refractionTexture.isCube ? CO.setTexture("refractionCubeSampler", this._refractionTexture) : CO.setTexture("refraction2DSampler", this._refractionTexture))), this.JKO().useOrderIndependentTransparency && this.needAlphaBlendingForMesh(pO) && this.JKO().depthPeelingRenderer.bind(CO), this._eventInfo.subMesh = XO, this._callbackPluginEventBindForSubMesh(this._eventInfo), (0, zK.e)(CO, this, bK), this.bindEyePosition(CO)
            } else aK && (this._needToBindSceneUbo = !0);
            !MO && this.isFrozen && !aK || !bK.lightsEnabled || this._disableLighting || (0, fO.r)(bK, pO, CO, eO, this._maxSimultaneousLights), !MO && this.isFrozen || ((bK.fogEnabled && pO.applyFog && bK.fogMode !== lO.e.FOGMODE_NONE || this._reflectionTexture || this._refractionTexture || pO.receiveShadows || eO.PREPASS || eO.CLUSTLIGHT_BATCH) && this.bindView(CO), (0, fO.i)(bK, pO, CO), eO.NUM_MORPH_INFLUENCERS && (0, fO.w)(pO, CO), eO.BAKED_VERTEX_ANIMATION_TEXTURE && pO.bakedVertexAnimationManager?.bind(CO, eO.INSTANCES), this.useLogarithmicDepth && (0, fO.s)(eO, CO, bK), this._imageProcessingConfiguration && !this._imageProcessingConfiguration.applyByPostProcess && this._imageProcessingConfiguration.bind(this._activeEffect)), this._afterBind(pO, this._activeEffect, XO), oO.update()
          }
          _canBindRunFollower(KO, pO, XO, bK, eO) {
            const lO = KO.prePassRenderer;
            return this.isFrozen && this._storeEffectOnSubMeshes && this._uniformBufferLayoutBuilt && !this._needToBindSceneUbo && this.isReadyForSubMesh === OO.prototype.isReadyForSubMesh && this.bindForSubMesh === OO.prototype.bindForSubMesh && this._mustRebind === FO.d.prototype._mustRebind && !(!this.backFaceCulling && this.separateCullingPass) && !(this.pluginManager && 0 !== this.pluginManager._activePluginsForExtraEvents.length) && !this._vertexPullingMetadata && !pO._features.needToAlwaysBindUniformBuffers && !(lO && lO.enabled && lO.currentRTisSceneRT) && !NO.d._Configurations[pO.currentRenderPassId] && !bK.materialDefines?.OBJECTSPACE_NORMALMAP && !XO.skeleton && !eO._bonesComputationForcedToCPU
          }
          _bindRunFollower(OO, KO, pO, XO) {
            this._activeEffect = XO, KO.getMeshUniformBuffer().bindToEffect(XO, "Mesh"), KO.transferToEffect(OO);
            const bK = this._uniformBuffer;
            bK.bindToEffect(XO, "Material");
            const eO = this._scene.activeCamera;
            eO ? bK.updateFloat4("cameraInfo", eO.minZ, eO.maxZ, 0, 0) : bK.updateFloat4("cameraInfo", 0, 0, 0, 0);
            const lO = this.textureRepetitionHexTilingParams;
            bK.updateFloat4("vTextureRepetitionHexTilingParams", lO[0], lO[1], lO[2], lO[3]), this._afterBind(KO, XO, pO), bK.update()
          }
          getAnimatables() {
            const OO = super.getAnimatables();
            return this._diffuseTexture && this._diffuseTexture.animations && this._diffuseTexture.animations.length > 0 && OO.push(this._diffuseTexture), this._ambientTexture && this._ambientTexture.animations && this._ambientTexture.animations.length > 0 && OO.push(this._ambientTexture), this._opacityTexture && this._opacityTexture.animations && this._opacityTexture.animations.length > 0 && OO.push(this._opacityTexture), this._reflectionTexture && this._reflectionTexture.animations && this._reflectionTexture.animations.length > 0 && OO.push(this._reflectionTexture), this._emissiveTexture && this._emissiveTexture.animations && this._emissiveTexture.animations.length > 0 && OO.push(this._emissiveTexture), this._specularTexture && this._specularTexture.animations && this._specularTexture.animations.length > 0 && OO.push(this._specularTexture), this._bumpTexture && this._bumpTexture.animations && this._bumpTexture.animations.length > 0 && OO.push(this._bumpTexture), this._lightmapTexture && this._lightmapTexture.animations && this._lightmapTexture.animations.length > 0 && OO.push(this._lightmapTexture), this._refractionTexture && this._refractionTexture.animations && this._refractionTexture.animations.length > 0 && OO.push(this._refractionTexture), OO
          }
          getActiveTextures() {
            const OO = super.getActiveTextures();
            return this._diffuseTexture && OO.push(this._diffuseTexture), this._ambientTexture && OO.push(this._ambientTexture), this._opacityTexture && OO.push(this._opacityTexture), this._reflectionTexture && OO.push(this._reflectionTexture), this._emissiveTexture && OO.push(this._emissiveTexture), this._specularTexture && OO.push(this._specularTexture), this._bumpTexture && OO.push(this._bumpTexture), this._lightmapTexture && OO.push(this._lightmapTexture), this._refractionTexture && OO.push(this._refractionTexture), OO
          }
          hasTexture(OO) {
            return !!super.hasTexture(OO) || (this._diffuseTexture === OO || (this._ambientTexture === OO || (this._opacityTexture === OO || (this._reflectionTexture === OO || (this._emissiveTexture === OO || (this._specularTexture === OO || (this._bumpTexture === OO || (this._lightmapTexture === OO || this._refractionTexture === OO))))))))
          }
          dispose(OO, KO) {
            KO && (this._diffuseTexture?.dispose(), this._ambientTexture?.dispose(), this._opacityTexture?.dispose(), this._reflectionTexture?.dispose(), this._emissiveTexture?.dispose(), this._specularTexture?.dispose(), this._bumpTexture?.dispose(), this._lightmapTexture?.dispose(), this._refractionTexture?.dispose()), this._imageProcessingConfiguration && this._imageProcessingObserver && this._imageProcessingConfiguration.onUpdateParameters.remove(this._imageProcessingObserver), super.dispose(OO, KO)
          }
          clone(KO) {
            let pO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
              XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
            const bK = dO.c.Clone((() => new OO(KO, this.JKO())), this, {
              cloneTexturesOnlyOnce: pO
            });
            return bK.name = KO, bK.id = KO, this.stencil.copyTo(bK.stencil), this._clonePlugins(bK, XO), bK
          }
          static Parse(KO, pO, XO) {
            const bK = dO.c.Parse((() => new OO(KO.name, pO)), KO, pO, XO);
            return KO.stencil && bK.stencil.parse(KO.stencil, pO, XO), aK.b._ParsePlugins(KO, bK, pO, XO), bK
          }
          static get DiffuseTextureEnabled() {
            return VO.e.DiffuseTextureEnabled
          }
          static set DiffuseTextureEnabled(OO) {
            VO.e.DiffuseTextureEnabled = OO
          }
          static get DetailTextureEnabled() {
            return VO.e.DetailTextureEnabled
          }
          static set DetailTextureEnabled(OO) {
            VO.e.DetailTextureEnabled = OO
          }
          static get AmbientTextureEnabled() {
            return VO.e.AmbientTextureEnabled
          }
          static set AmbientTextureEnabled(OO) {
            VO.e.AmbientTextureEnabled = OO
          }
          static get OpacityTextureEnabled() {
            return VO.e.OpacityTextureEnabled
          }
          static set OpacityTextureEnabled(OO) {
            VO.e.OpacityTextureEnabled = OO
          }
          static get ReflectionTextureEnabled() {
            return VO.e.ReflectionTextureEnabled
          }
          static set ReflectionTextureEnabled(OO) {
            VO.e.ReflectionTextureEnabled = OO
          }
          static get EmissiveTextureEnabled() {
            return VO.e.EmissiveTextureEnabled
          }
          static set EmissiveTextureEnabled(OO) {
            VO.e.EmissiveTextureEnabled = OO
          }
          static get SpecularTextureEnabled() {
            return VO.e.SpecularTextureEnabled
          }
          static set SpecularTextureEnabled(OO) {
            VO.e.SpecularTextureEnabled = OO
          }
          static get BumpTextureEnabled() {
            return VO.e.BumpTextureEnabled
          }
          static set BumpTextureEnabled(OO) {
            VO.e.BumpTextureEnabled = OO
          }
          static get LightmapTextureEnabled() {
            return VO.e.LightmapTextureEnabled
          }
          static set LightmapTextureEnabled(OO) {
            VO.e.LightmapTextureEnabled = OO
          }
          static get RefractionTextureEnabled() {
            return VO.e.RefractionTextureEnabled
          }
          static set RefractionTextureEnabled(OO) {
            VO.e.RefractionTextureEnabled = OO
          }
          static get ColorGradingTextureEnabled() {
            return VO.e.ColorGradingTextureEnabled
          }
          static set ColorGradingTextureEnabled(OO) {
            VO.e.ColorGradingTextureEnabled = OO
          }
          static get FresnelEnabled() {
            return VO.e.FresnelEnabled
          }
          static set FresnelEnabled(OO) {
            VO.e.FresnelEnabled = OO
          }
        }, KO = new WeakMap, DO = new WeakMap, oO = new WeakMap, IO = new WeakMap, yK = new WeakMap, gK = new WeakMap, uO = new WeakMap, EO = new WeakMap, YO = new WeakMap, rK = new WeakMap, PO = new WeakMap, mK = new WeakMap, sO = new WeakMap, HO = new WeakMap, RO = new WeakMap, SO = new WeakMap, JO = new WeakMap, cK = new WeakMap, BO = new WeakMap, ZO = new WeakMap, GO = new WeakMap, qK = new WeakMap, xK = new WeakMap, nO = new WeakMap, WO = new WeakMap, tK = new WeakMap, kK = new WeakMap, UO = new WeakMap, OK = new WeakMap, KK = new WeakMap, pK = new WeakMap, XK = new WeakMap, (() => {
          const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(yX[Symbol.metadata] ?? null) : void 0;
          bp = [(0, bK.I)("diffuseTexture")], eK = [(0, bK.h)("_markAllSubMeshesAsTexturesAndMiscDirty")], lK = [(0, bK.I)("ambientTexture")], vp = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], CK = [(0, bK.I)("opacityTexture")], hK = [(0, bK.h)("_markAllSubMeshesAsTexturesAndMiscDirty")], DK = [(0, bK.I)("reflectionTexture")], MK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], ap = [(0, bK.I)("emissiveTexture")], oK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], FK = [(0, bK.I)("specularTexture")], VK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], LK = [(0, bK.I)("bumpTexture")], QK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], zp = [(0, bK.I)("lightmapTexture")], AK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], fK = [(0, bK.I)("refractionTexture")], dK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], TK = [(0, bK.r)("ambient")], NK = [(0, bK.r)("diffuse")], IK = [(0, bK.r)("specular")], yp = [(0, bK.r)("emissive")], gp = [(0, bK.M)()], uK = [(0, bK.M)("useAlphaFromDiffuseTexture")], EK = [() => ({
            init(OO) {
              return void 0 === OO && "_useAlphaFromDiffuseTexture" in this || (this._useAlphaFromDiffuseTexture = OO), OO
            },
            get() {
              return this._useAlphaFromDiffuseTexture
            },
            set(OO) {
              this._useAlphaFromDiffuseTexture = OO
            }
          })], jp = [(0, bK.M)("useEmissiveAsIllumination")], YK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], wK = [(0, bK.M)("linkEmissiveWithDiffuse")], ip = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], rp = [(0, bK.M)("useSpecularOverAlpha")], PK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], mp = [(0, bK.M)("useReflectionOverAlpha")], sK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], HK = [(0, bK.M)("disableLighting")], RK = [(0, bK.h)("_markAllSubMeshesAsLightsDirty")], SK = [(0, bK.M)("useObjectSpaceNormalMap")], JK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], cp = [(0, bK.M)("useParallax")], BK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], ZK = [(0, bK.M)("useParallaxOcclusion")], GK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], qp = [(0, bK.M)()], xp = [(0, bK.M)("roughness")], nK = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], WK = [(0, bK.M)()], tp = [(0, bK.M)()], kp = [(0, bK.M)()], UK = [(0, bK.M)("useLightmapAsShadowmap")], Op = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], Kp = [(0, bK.y)("diffuseFresnelParameters")], pp = [(0, bK.h)("_markAllSubMeshesAsFresnelDirty")], Xp = [(0, bK.y)("opacityFresnelParameters")], bX = [(0, bK.h)("_markAllSubMeshesAsFresnelAndMiscDirty")], ep = [(0, bK.y)("reflectionFresnelParameters")], lp = [(0, bK.h)("_markAllSubMeshesAsFresnelDirty")], vX = [(0, bK.y)("refractionFresnelParameters")], Cp = [(0, bK.h)("_markAllSubMeshesAsFresnelDirty")], hp = [(0, bK.y)("emissiveFresnelParameters")], Dp = [(0, bK.h)("_markAllSubMeshesAsFresnelDirty")], Mp = [(0, bK.M)("useReflectionFresnelFromSpecular")], aX = [(0, bK.h)("_markAllSubMeshesAsFresnelDirty")], op = [(0, bK.M)("useGlossinessFromSpecularMapAlpha")], Fp = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], Vp = [(0, bK.M)("maxSimultaneousLights")], Lp = [(0, bK.h)("_markAllSubMeshesAsLightsDirty")], Qp = [(0, bK.M)("invertNormalMapX")], zX = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], Ap = [(0, bK.M)("invertNormalMapY")], fp = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], dp = [(0, bK.M)("twoSidedLighting")], Tp = [(0, bK.h)("_markAllSubMeshesAsTexturesDirty")], Np = [(0, bK.M)("applyDecalMapAfterDetailMap")], Ip = [(0, bK.h)("_markAllSubMeshesAsMiscDirty")], (0, XO.f)(OO, null, eK, {
            kind: "accessor",
            name: "diffuseTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "diffuseTexture" in OO,
              get: OO => OO.diffuseTexture,
              set: (OO, KO) => {
                OO.diffuseTexture = KO
              }
            },
            metadata: KO
          }, Ep, jX), (0, XO.f)(OO, null, vp, {
            kind: "accessor",
            name: "ambientTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "ambientTexture" in OO,
              get: OO => OO.ambientTexture,
              set: (OO, KO) => {
                OO.ambientTexture = KO
              }
            },
            metadata: KO
          }, iX, rX), (0, XO.f)(OO, null, hK, {
            kind: "accessor",
            name: "opacityTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "opacityTexture" in OO,
              get: OO => OO.opacityTexture,
              set: (OO, KO) => {
                OO.opacityTexture = KO
              }
            },
            metadata: KO
          }, sp, Hp), (0, XO.f)(OO, null, MK, {
            kind: "accessor",
            name: "reflectionTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "reflectionTexture" in OO,
              get: OO => OO.reflectionTexture,
              set: (OO, KO) => {
                OO.reflectionTexture = KO
              }
            },
            metadata: KO
          }, Jp, cX), (0, XO.f)(OO, null, oK, {
            kind: "accessor",
            name: "emissiveTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "emissiveTexture" in OO,
              get: OO => OO.emissiveTexture,
              set: (OO, KO) => {
                OO.emissiveTexture = KO
              }
            },
            metadata: KO
          }, Gp, qX), (0, XO.f)(OO, null, VK, {
            kind: "accessor",
            name: "specularTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularTexture" in OO,
              get: OO => OO.specularTexture,
              set: (OO, KO) => {
                OO.specularTexture = KO
              }
            },
            metadata: KO
          }, Wp, tX), (0, XO.f)(OO, null, QK, {
            kind: "accessor",
            name: "bumpTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "bumpTexture" in OO,
              get: OO => OO.bumpTexture,
              set: (OO, KO) => {
                OO.bumpTexture = KO
              }
            },
            metadata: KO
          }, OX, KX), (0, XO.f)(OO, null, AK, {
            kind: "accessor",
            name: "lightmapTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "lightmapTexture" in OO,
              get: OO => OO.lightmapTexture,
              set: (OO, KO) => {
                OO.lightmapTexture = KO
              }
            },
            metadata: KO
          }, bb, eX), (0, XO.f)(OO, null, dK, {
            kind: "accessor",
            name: "refractionTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "refractionTexture" in OO,
              get: OO => OO.refractionTexture,
              set: (OO, KO) => {
                OO.refractionTexture = KO
              }
            },
            metadata: KO
          }, CX, hX), (0, XO.f)(OO, null, EK, {
            kind: "accessor",
            name: "useAlphaFromDiffuseTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "useAlphaFromDiffuseTexture" in OO,
              get: OO => OO.useAlphaFromDiffuseTexture,
              set: (OO, KO) => {
                OO.useAlphaFromDiffuseTexture = KO
              }
            },
            metadata: KO
          }, TX, NX), (0, XO.f)(OO, null, YK, {
            kind: "accessor",
            name: "useEmissiveAsIllumination",
            static: !1,
            private: !1,
            access: {
              has: OO => "useEmissiveAsIllumination" in OO,
              get: OO => OO.useEmissiveAsIllumination,
              set: (OO, KO) => {
                OO.useEmissiveAsIllumination = KO
              }
            },
            metadata: KO
          }, gb, uX), (0, XO.f)(OO, null, ip, {
            kind: "accessor",
            name: "linkEmissiveWithDiffuse",
            static: !1,
            private: !1,
            access: {
              has: OO => "linkEmissiveWithDiffuse" in OO,
              get: OO => OO.linkEmissiveWithDiffuse,
              set: (OO, KO) => {
                OO.linkEmissiveWithDiffuse = KO
              }
            },
            metadata: KO
          }, YX, wX), (0, XO.f)(OO, null, PK, {
            kind: "accessor",
            name: "useSpecularOverAlpha",
            static: !1,
            private: !1,
            access: {
              has: OO => "useSpecularOverAlpha" in OO,
              get: OO => OO.useSpecularOverAlpha,
              set: (OO, KO) => {
                OO.useSpecularOverAlpha = KO
              }
            },
            metadata: KO
          }, PX, mb), (0, XO.f)(OO, null, sK, {
            kind: "accessor",
            name: "useReflectionOverAlpha",
            static: !1,
            private: !1,
            access: {
              has: OO => "useReflectionOverAlpha" in OO,
              get: OO => OO.useReflectionOverAlpha,
              set: (OO, KO) => {
                OO.useReflectionOverAlpha = KO
              }
            },
            metadata: KO
          }, RX, SX), (0, XO.f)(OO, null, RK, {
            kind: "accessor",
            name: "disableLighting",
            static: !1,
            private: !1,
            access: {
              has: OO => "disableLighting" in OO,
              get: OO => OO.disableLighting,
              set: (OO, KO) => {
                OO.disableLighting = KO
              }
            },
            metadata: KO
          }, BX, ZX), (0, XO.f)(OO, null, JK, {
            kind: "accessor",
            name: "useObjectSpaceNormalMap",
            static: !1,
            private: !1,
            access: {
              has: OO => "useObjectSpaceNormalMap" in OO,
              get: OO => OO.useObjectSpaceNormalMap,
              set: (OO, KO) => {
                OO.useObjectSpaceNormalMap = KO
              }
            },
            metadata: KO
          }, xb, nX), (0, XO.f)(OO, null, BK, {
            kind: "accessor",
            name: "useParallax",
            static: !1,
            private: !1,
            access: {
              has: OO => "useParallax" in OO,
              get: OO => OO.useParallax,
              set: (OO, KO) => {
                OO.useParallax = KO
              }
            },
            metadata: KO
          }, kb, UX), (0, XO.f)(OO, null, GK, {
            kind: "accessor",
            name: "useParallaxOcclusion",
            static: !1,
            private: !1,
            access: {
              has: OO => "useParallaxOcclusion" in OO,
              get: OO => OO.useParallaxOcclusion,
              set: (OO, KO) => {
                OO.useParallaxOcclusion = KO
              }
            },
            metadata: KO
          }, pb, Xb), (0, XO.f)(OO, null, nK, {
            kind: "accessor",
            name: "roughness",
            static: !1,
            private: !1,
            access: {
              has: OO => "roughness" in OO,
              get: OO => OO.roughness,
              set: (OO, KO) => {
                OO.roughness = KO
              }
            },
            metadata: KO
          }, Cb, hb), (0, XO.f)(OO, null, Op, {
            kind: "accessor",
            name: "useLightmapAsShadowmap",
            static: !1,
            private: !1,
            access: {
              has: OO => "useLightmapAsShadowmap" in OO,
              get: OO => OO.useLightmapAsShadowmap,
              set: (OO, KO) => {
                OO.useLightmapAsShadowmap = KO
              }
            },
            metadata: KO
          }, ze, Ab), (0, XO.f)(OO, null, pp, {
            kind: "accessor",
            name: "diffuseFresnelParameters",
            static: !1,
            private: !1,
            access: {
              has: OO => "diffuseFresnelParameters" in OO,
              get: OO => OO.diffuseFresnelParameters,
              set: (OO, KO) => {
                OO.diffuseFresnelParameters = KO
              }
            },
            metadata: KO
          }, Tb, Nb), (0, XO.f)(OO, null, bX, {
            kind: "accessor",
            name: "opacityFresnelParameters",
            static: !1,
            private: !1,
            access: {
              has: OO => "opacityFresnelParameters" in OO,
              get: OO => OO.opacityFresnelParameters,
              set: (OO, KO) => {
                OO.opacityFresnelParameters = KO
              }
            },
            metadata: KO
          }, ge, ub), (0, XO.f)(OO, null, lp, {
            kind: "accessor",
            name: "reflectionFresnelParameters",
            static: !1,
            private: !1,
            access: {
              has: OO => "reflectionFresnelParameters" in OO,
              get: OO => OO.reflectionFresnelParameters,
              set: (OO, KO) => {
                OO.reflectionFresnelParameters = KO
              }
            },
            metadata: KO
          }, Yb, wb), (0, XO.f)(OO, null, Cp, {
            kind: "accessor",
            name: "refractionFresnelParameters",
            static: !1,
            private: !1,
            access: {
              has: OO => "refractionFresnelParameters" in OO,
              get: OO => OO.refractionFresnelParameters,
              set: (OO, KO) => {
                OO.refractionFresnelParameters = KO
              }
            },
            metadata: KO
          }, Pb, me), (0, XO.f)(OO, null, Dp, {
            kind: "accessor",
            name: "emissiveFresnelParameters",
            static: !1,
            private: !1,
            access: {
              has: OO => "emissiveFresnelParameters" in OO,
              get: OO => OO.emissiveFresnelParameters,
              set: (OO, KO) => {
                OO.emissiveFresnelParameters = KO
              }
            },
            metadata: KO
          }, Rb, Sb), (0, XO.f)(OO, null, aX, {
            kind: "accessor",
            name: "useReflectionFresnelFromSpecular",
            static: !1,
            private: !1,
            access: {
              has: OO => "useReflectionFresnelFromSpecular" in OO,
              get: OO => OO.useReflectionFresnelFromSpecular,
              set: (OO, KO) => {
                OO.useReflectionFresnelFromSpecular = KO
              }
            },
            metadata: KO
          }, Bb, Zb), (0, XO.f)(OO, null, Fp, {
            kind: "accessor",
            name: "useGlossinessFromSpecularMapAlpha",
            static: !1,
            private: !1,
            access: {
              has: OO => "useGlossinessFromSpecularMapAlpha" in OO,
              get: OO => OO.useGlossinessFromSpecularMapAlpha,
              set: (OO, KO) => {
                OO.useGlossinessFromSpecularMapAlpha = KO
              }
            },
            metadata: KO
          }, xe, nb), (0, XO.f)(OO, null, Lp, {
            kind: "accessor",
            name: "maxSimultaneousLights",
            static: !1,
            private: !1,
            access: {
              has: OO => "maxSimultaneousLights" in OO,
              get: OO => OO.maxSimultaneousLights,
              set: (OO, KO) => {
                OO.maxSimultaneousLights = KO
              }
            },
            metadata: KO
          }, ke, Ub), (0, XO.f)(OO, null, zX, {
            kind: "accessor",
            name: "invertNormalMapX",
            static: !1,
            private: !1,
            access: {
              has: OO => "invertNormalMapX" in OO,
              get: OO => OO.invertNormalMapX,
              set: (OO, KO) => {
                OO.invertNormalMapX = KO
              }
            },
            metadata: KO
          }, pe, Xe), (0, XO.f)(OO, null, fp, {
            kind: "accessor",
            name: "invertNormalMapY",
            static: !1,
            private: !1,
            access: {
              has: OO => "invertNormalMapY" in OO,
              get: OO => OO.invertNormalMapY,
              set: (OO, KO) => {
                OO.invertNormalMapY = KO
              }
            },
            metadata: KO
          }, le, vl), (0, XO.f)(OO, null, Tp, {
            kind: "accessor",
            name: "twoSidedLighting",
            static: !1,
            private: !1,
            access: {
              has: OO => "twoSidedLighting" in OO,
              get: OO => OO.twoSidedLighting,
              set: (OO, KO) => {
                OO.twoSidedLighting = KO
              }
            },
            metadata: KO
          }, De, Me), (0, XO.f)(OO, null, Ip, {
            kind: "accessor",
            name: "applyDecalMapAfterDetailMap",
            static: !1,
            private: !1,
            access: {
              has: OO => "applyDecalMapAfterDetailMap" in OO,
              get: OO => OO.applyDecalMapAfterDetailMap,
              set: (OO, KO) => {
                OO.applyDecalMapAfterDetailMap = KO
              }
            },
            metadata: KO
          }, Fe, Ve), (0, XO.f)(null, null, bp, {
            kind: "field",
            name: "_diffuseTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_diffuseTexture" in OO,
              get: OO => OO._diffuseTexture,
              set: (OO, KO) => {
                OO._diffuseTexture = KO
              }
            },
            metadata: KO
          }, gX, upO), (0, XO.f)(null, null, lK, {
            kind: "field",
            name: "_ambientTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_ambientTexture" in OO,
              get: OO => OO._ambientTexture,
              set: (OO, KO) => {
                OO._ambientTexture = KO
              }
            },
            metadata: KO
          }, Yp, wp), (0, XO.f)(null, null, CK, {
            kind: "field",
            name: "_opacityTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_opacityTexture" in OO,
              get: OO => OO._opacityTexture,
              set: (OO, KO) => {
                OO._opacityTexture = KO
              }
            },
            metadata: KO
          }, Pp, mX), (0, XO.f)(null, null, DK, {
            kind: "field",
            name: "_reflectionTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_reflectionTexture" in OO,
              get: OO => OO._reflectionTexture,
              set: (OO, KO) => {
                OO._reflectionTexture = KO
              }
            },
            metadata: KO
          }, Rp, Sp), (0, XO.f)(null, null, ap, {
            kind: "field",
            name: "_emissiveTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_emissiveTexture" in OO,
              get: OO => OO._emissiveTexture,
              set: (OO, KO) => {
                OO._emissiveTexture = KO
              }
            },
            metadata: KO
          }, Bp, Zp), (0, XO.f)(null, null, FK, {
            kind: "field",
            name: "_specularTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_specularTexture" in OO,
              get: OO => OO._specularTexture,
              set: (OO, KO) => {
                OO._specularTexture = KO
              }
            },
            metadata: KO
          }, xX, np), (0, XO.f)(null, null, LK, {
            kind: "field",
            name: "_bumpTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_bumpTexture" in OO,
              get: OO => OO._bumpTexture,
              set: (OO, KO) => {
                OO._bumpTexture = KO
              }
            },
            metadata: KO
          }, kX, Up), (0, XO.f)(null, null, zp, {
            kind: "field",
            name: "_lightmapTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_lightmapTexture" in OO,
              get: OO => OO._lightmapTexture,
              set: (OO, KO) => {
                OO._lightmapTexture = KO
              }
            },
            metadata: KO
          }, pX, XX), (0, XO.f)(null, null, fK, {
            kind: "field",
            name: "_refractionTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_refractionTexture" in OO,
              get: OO => OO._refractionTexture,
              set: (OO, KO) => {
                OO._refractionTexture = KO
              }
            },
            metadata: KO
          }, lX, vb), (0, XO.f)(null, null, TK, {
            kind: "field",
            name: "ambientColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "ambientColor" in OO,
              get: OO => OO.ambientColor,
              set: (OO, KO) => {
                OO.ambientColor = KO
              }
            },
            metadata: KO
          }, DX, MX), (0, XO.f)(null, null, NK, {
            kind: "field",
            name: "diffuseColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "diffuseColor" in OO,
              get: OO => OO.diffuseColor,
              set: (OO, KO) => {
                OO.diffuseColor = KO
              }
            },
            metadata: KO
          }, ab, oX), (0, XO.f)(null, null, IK, {
            kind: "field",
            name: "specularColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularColor" in OO,
              get: OO => OO.specularColor,
              set: (OO, KO) => {
                OO.specularColor = KO
              }
            },
            metadata: KO
          }, FX, VX), (0, XO.f)(null, null, yp, {
            kind: "field",
            name: "emissiveColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "emissiveColor" in OO,
              get: OO => OO.emissiveColor,
              set: (OO, KO) => {
                OO.emissiveColor = KO
              }
            },
            metadata: KO
          }, LX, QX), (0, XO.f)(null, null, gp, {
            kind: "field",
            name: "specularPower",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularPower" in OO,
              get: OO => OO.specularPower,
              set: (OO, KO) => {
                OO.specularPower = KO
              }
            },
            metadata: KO
          }, zb, AX), (0, XO.f)(null, null, uK, {
            kind: "field",
            name: "_useAlphaFromDiffuseTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "_useAlphaFromDiffuseTexture" in OO,
              get: OO => OO._useAlphaFromDiffuseTexture,
              set: (OO, KO) => {
                OO._useAlphaFromDiffuseTexture = KO
              }
            },
            metadata: KO
          }, fX, dX), (0, XO.f)(null, null, jp, {
            kind: "field",
            name: "_useEmissiveAsIllumination",
            static: !1,
            private: !1,
            access: {
              has: OO => "_useEmissiveAsIllumination" in OO,
              get: OO => OO._useEmissiveAsIllumination,
              set: (OO, KO) => {
                OO._useEmissiveAsIllumination = KO
              }
            },
            metadata: KO
          }, IX, yb), (0, XO.f)(null, null, wK, {
            kind: "field",
            name: "_linkEmissiveWithDiffuse",
            static: !1,
            private: !1,
            access: {
              has: OO => "_linkEmissiveWithDiffuse" in OO,
              get: OO => OO._linkEmissiveWithDiffuse,
              set: (OO, KO) => {
                OO._linkEmissiveWithDiffuse = KO
              }
            },
            metadata: KO
          }, EX, jb), (0, XO.f)(null, null, rp, {
            kind: "field",
            name: "_useSpecularOverAlpha",
            static: !1,
            private: !1,
            access: {
              has: OO => "_useSpecularOverAlpha" in OO,
              get: OO => OO._useSpecularOverAlpha,
              set: (OO, KO) => {
                OO._useSpecularOverAlpha = KO
              }
            },
            metadata: KO
          }, ib, rb), (0, XO.f)(null, null, mp, {
            kind: "field",
            name: "_useReflectionOverAlpha",
            static: !1,
            private: !1,
            access: {
              has: OO => "_useReflectionOverAlpha" in OO,
              get: OO => OO._useReflectionOverAlpha,
              set: (OO, KO) => {
                OO._useReflectionOverAlpha = KO
              }
            },
            metadata: KO
          }, sX, HX), (0, XO.f)(null, null, HK, {
            kind: "field",
            name: "_disableLighting",
            static: !1,
            private: !1,
            access: {
              has: OO => "_disableLighting" in OO,
              get: OO => OO._disableLighting,
              set: (OO, KO) => {
                OO._disableLighting = KO
              }
            },
            metadata: KO
          }, JX, cb), (0, XO.f)(null, null, SK, {
            kind: "field",
            name: "_useObjectSpaceNormalMap",
            static: !1,
            private: !1,
            access: {
              has: OO => "_useObjectSpaceNormalMap" in OO,
              get: OO => OO._useObjectSpaceNormalMap,
              set: (OO, KO) => {
                OO._useObjectSpaceNormalMap = KO
              }
            },
            metadata: KO
          }, GX, qb), (0, XO.f)(null, null, cp, {
            kind: "field",
            name: "_useParallax",
            static: !1,
            private: !1,
            access: {
              has: OO => "_useParallax" in OO,
              get: OO => OO._useParallax,
              set: (OO, KO) => {
                OO._useParallax = KO
              }
            },
            metadata: KO
          }, WX, tb), (0, XO.f)(null, null, ZK, {
            kind: "field",
            name: "_useParallaxOcclusion",
            static: !1,
            private: !1,
            access: {
              has: OO => "_useParallaxOcclusion" in OO,
              get: OO => OO._useParallaxOcclusion,
              set: (OO, KO) => {
                OO._useParallaxOcclusion = KO
              }
            },
            metadata: KO
          }, Ob, Kb), (0, XO.f)(null, null, qp, {
            kind: "field",
            name: "parallaxScaleBias",
            static: !1,
            private: !1,
            access: {
              has: OO => "parallaxScaleBias" in OO,
              get: OO => OO.parallaxScaleBias,
              set: (OO, KO) => {
                OO.parallaxScaleBias = KO
              }
            },
            metadata: KO
          }, be, eb), (0, XO.f)(null, null, xp, {
            kind: "field",
            name: "_roughness",
            static: !1,
            private: !1,
            access: {
              has: OO => "_roughness" in OO,
              get: OO => OO._roughness,
              set: (OO, KO) => {
                OO._roughness = KO
              }
            },
            metadata: KO
          }, lb, ve), (0, XO.f)(null, null, WK, {
            kind: "field",
            name: "indexOfRefraction",
            static: !1,
            private: !1,
            access: {
              has: OO => "indexOfRefraction" in OO,
              get: OO => OO.indexOfRefraction,
              set: (OO, KO) => {
                OO.indexOfRefraction = KO
              }
            },
            metadata: KO
          }, Db, Mb), (0, XO.f)(null, null, tp, {
            kind: "field",
            name: "invertRefractionY",
            static: !1,
            private: !1,
            access: {
              has: OO => "invertRefractionY" in OO,
              get: OO => OO.invertRefractionY,
              set: (OO, KO) => {
                OO.invertRefractionY = KO
              }
            },
            metadata: KO
          }, ae, ob), (0, XO.f)(null, null, kp, {
            kind: "field",
            name: "alphaCutOff",
            static: !1,
            private: !1,
            access: {
              has: OO => "alphaCutOff" in OO,
              get: OO => OO.alphaCutOff,
              set: (OO, KO) => {
                OO.alphaCutOff = KO
              }
            },
            metadata: KO
          }, Fb, Vb), (0, XO.f)(null, null, UK, {
            kind: "field",
            name: "_useLightmapAsShadowmap",
            static: !1,
            private: !1,
            access: {
              has: OO => "_useLightmapAsShadowmap" in OO,
              get: OO => OO._useLightmapAsShadowmap,
              set: (OO, KO) => {
                OO._useLightmapAsShadowmap = KO
              }
            },
            metadata: KO
          }, Lb, Qb), (0, XO.f)(null, null, Kp, {
            kind: "field",
            name: "_diffuseFresnelParameters",
            static: !1,
            private: !1,
            access: {
              has: OO => "_diffuseFresnelParameters" in OO,
              get: OO => OO._diffuseFresnelParameters,
              set: (OO, KO) => {
                OO._diffuseFresnelParameters = KO
              }
            },
            metadata: KO
          }, fb, db), (0, XO.f)(null, null, Xp, {
            kind: "field",
            name: "_opacityFresnelParameters",
            static: !1,
            private: !1,
            access: {
              has: OO => "_opacityFresnelParameters" in OO,
              get: OO => OO._opacityFresnelParameters,
              set: (OO, KO) => {
                OO._opacityFresnelParameters = KO
              }
            },
            metadata: KO
          }, Ib, ye), (0, XO.f)(null, null, ep, {
            kind: "field",
            name: "_reflectionFresnelParameters",
            static: !1,
            private: !1,
            access: {
              has: OO => "_reflectionFresnelParameters" in OO,
              get: OO => OO._reflectionFresnelParameters,
              set: (OO, KO) => {
                OO._reflectionFresnelParameters = KO
              }
            },
            metadata: KO
          }, Eb, je), (0, XO.f)(null, null, vX, {
            kind: "field",
            name: "_refractionFresnelParameters",
            static: !1,
            private: !1,
            access: {
              has: OO => "_refractionFresnelParameters" in OO,
              get: OO => OO._refractionFresnelParameters,
              set: (OO, KO) => {
                OO._refractionFresnelParameters = KO
              }
            },
            metadata: KO
          }, ie, re), (0, XO.f)(null, null, hp, {
            kind: "field",
            name: "_emissiveFresnelParameters",
            static: !1,
            private: !1,
            access: {
              has: OO => "_emissiveFresnelParameters" in OO,
              get: OO => OO._emissiveFresnelParameters,
              set: (OO, KO) => {
                OO._emissiveFresnelParameters = KO
              }
            },
            metadata: KO
          }, sb, Hb), (0, XO.f)(null, null, Mp, {
            kind: "field",
            name: "_useReflectionFresnelFromSpecular",
            static: !1,
            private: !1,
            access: {
              has: OO => "_useReflectionFresnelFromSpecular" in OO,
              get: OO => OO._useReflectionFresnelFromSpecular,
              set: (OO, KO) => {
                OO._useReflectionFresnelFromSpecular = KO
              }
            },
            metadata: KO
          }, Jb, ce), (0, XO.f)(null, null, op, {
            kind: "field",
            name: "_useGlossinessFromSpecularMapAlpha",
            static: !1,
            private: !1,
            access: {
              has: OO => "_useGlossinessFromSpecularMapAlpha" in OO,
              get: OO => OO._useGlossinessFromSpecularMapAlpha,
              set: (OO, KO) => {
                OO._useGlossinessFromSpecularMapAlpha = KO
              }
            },
            metadata: KO
          }, Gb, qe), (0, XO.f)(null, null, Vp, {
            kind: "field",
            name: "_maxSimultaneousLights",
            static: !1,
            private: !1,
            access: {
              has: OO => "_maxSimultaneousLights" in OO,
              get: OO => OO._maxSimultaneousLights,
              set: (OO, KO) => {
                OO._maxSimultaneousLights = KO
              }
            },
            metadata: KO
          }, Wb, te), (0, XO.f)(null, null, Qp, {
            kind: "field",
            name: "_invertNormalMapX",
            static: !1,
            private: !1,
            access: {
              has: OO => "_invertNormalMapX" in OO,
              get: OO => OO._invertNormalMapX,
              set: (OO, KO) => {
                OO._invertNormalMapX = KO
              }
            },
            metadata: KO
          }, Oe, Ke), (0, XO.f)(null, null, Ap, {
            kind: "field",
            name: "_invertNormalMapY",
            static: !1,
            private: !1,
            access: {
              has: OO => "_invertNormalMapY" in OO,
              get: OO => OO._invertNormalMapY,
              set: (OO, KO) => {
                OO._invertNormalMapY = KO
              }
            },
            metadata: KO
          }, bl, ee), (0, XO.f)(null, null, dp, {
            kind: "field",
            name: "_twoSidedLighting",
            static: !1,
            private: !1,
            access: {
              has: OO => "_twoSidedLighting" in OO,
              get: OO => OO._twoSidedLighting,
              set: (OO, KO) => {
                OO._twoSidedLighting = KO
              }
            },
            metadata: KO
          }, Ce, he), (0, XO.f)(null, null, Np, {
            kind: "field",
            name: "_applyDecalMapAfterDetailMap",
            static: !1,
            private: !1,
            access: {
              has: OO => "_applyDecalMapAfterDetailMap" in OO,
              get: OO => OO._applyDecalMapAfterDetailMap,
              set: (OO, KO) => {
                OO._applyDecalMapAfterDetailMap = KO
              }
            },
            metadata: KO
          }, al, oe), KO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: KO
          })
        })(), OO.ForceGLSL = !1, OO._ShaderLoader = new TO.e((() => [Promise.all([pO.e(297), pO.e(296)]).then((() => pO(39878))), Promise.all([pO.e(302), pO.e(298), pO.e(311), pO.e(301)]).then((() => pO(40084)))]), (() => [Promise.all([pO.e(318), pO.e(313)]).then((() => pO(40228))), Promise.all([pO.e(319), pO.e(329), pO.e(315)]).then((() => pO(40435)))])), OO
      })(),
      PO = !1;

    function mK() {
      PO || (PO = !0, (0, MO.f)(), (0, uO.h)("BABYLON.StandardMaterial", rK), lO.e.DefaultMaterialFactory = OO => new rK("default material", OO))
    }
    Object.getOwnPropertyDescriptor(rK.prototype, "decalMap") || Object.defineProperty(rK.prototype, "decalMap", (0, EO.e)("StandardMaterial", "decalMap"))
  },
  38480: (OO, KO, pO) => {
    function XO(OO) {
      return class extends OO {
        constructor() {
          super(...arguments), this.MAINUV1 = !1, this.MAINUV2 = !1, this.MAINUV3 = !1, this.MAINUV4 = !1, this.MAINUV5 = !1, this.MAINUV6 = !1, this.UV1 = !1, this.UV2 = !1, this.UV3 = !1, this.UV4 = !1, this.UV5 = !1, this.UV6 = !1
        }
      }
    }
    pO.d(KO, {
      c: () => XO
    })
  },
  38464: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    class XO {
      constructor(OO, KO) {
        this._webGL = {
          load: OO,
          loaded: !1,
          loadPromise: null
        }, this._webGPU = {
          load: KO,
          loaded: !1,
          loadPromise: null
        }
      }
      getLoadCallback(OO) {
        const KO = 1 === OO ? this._webGPU : this._webGL;
        return KO.loaded ? void 0 : async () => {
          await this._loadAsync(KO)
        }
      }
      async _loadAsync(OO) {
        if (OO.loaded) return;
        let KO = OO.loadPromise;
        const pO = null === KO;
        pO && (KO = Promise.all(OO.load()), OO.loadPromise = KO);
        let XO = !1;
        try {
          await KO, XO = !0
        } finally {
          pO && this._completeLoad(OO, XO)
        }
      }
      _completeLoad(OO, KO) {
        OO.loaded = KO, OO.loadPromise = null
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);