export const id = 141;
export const ids = [141];
export const modules = {
  7227: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      AdsenseForGamesSdkAdaptor: () => eO
    });
    var XO = pO(1158),
      bK = pO(1044);
    class eO extends XO.c {
      constructor() {
        super(), this.name = "adsense"
      }
      static async setup() {
        return window.adsbygoogle = window.adsbygoogle || [], window.adBreak = window.adConfig = function(OO) {
          window.adsbygoogle.push(OO)
        }, window.adConfig({
          preloadAdBreaks: "on",
          sound: "on",
          onReady: () => {
            console.log("adsense for games ready")
          }
        }), await (0, bK.e)("https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js", {
          "data-ad-client": "ca-pub-5991928098122027",
          "data-ad-frequency-hint": "120s",
          type: "text/javascript"
        }), console.log("Loaded adsense for games"), new eO
      }
      playVideoAd(OO, KO) {
        console.log("playPreroll requested");
        let pO = !1;
        const XO = setTimeout((() => {
          console.log("Calling onEnd from timeout - window.adBreak did not respond after 3 seconds"), pO = !0, OO()
        }), 3e3);
        window.adBreak({
          type: "video_start" === KO ? "start" : "next",
          name: KO,
          beforeAd: () => {
            console.log("beforeAd called"), clearTimeout(XO), window.adStartSoPause(null, {
              preventMovement: !0
            })
          },
          afterAd: () => {
            console.log("afterAd called"), window.adCompleteSoResume()
          },
          adBreakDone: KO => {
            console.log("adBreakDone called", KO), clearTimeout(XO), pO || (console.log("Haven't called onEnd yet, calling it from adBreakDone."), OO())
          }
        })
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);