export const id = 104;
export const ids = [104];
export const modules = {
  38637: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      startWasmPadGameplay: () => sO
    });
    pO(38642);
    var XO = pO(38644),
      bK = pO(38658),
      eO = pO(1569),
      lO = pO(38667),
      vK = pO(3943),
      CO = pO(3923),
      hO = pO(38671),
      DO = pO(38674),
      MO = pO(3955),
      aK = pO(38755),
      oO = pO(1969),
      FO = pO(7935),
      VO = pO(38648),
      LO = pO(7913);
    const QO = OO => {
        const KO = MO.e.indexOf(OO);
        if (KO < 0) throw new Error(`No core action "${OO}"`);
        return KO
      },
      zK = QO("primary-fire"),
      AO = QO("alt-fire"),
      fO = QO("mid-fire"),
      dO = QO("jump"),
      TO = QO("ReloadGun"),
      NO = QO("SwapCameraZoom"),
      IO = QO("TouchAction1"),
      yK = {
        SpecialAction1: QO("SpecialAction1"),
        SpecialAction2: QO("SpecialAction2")
      },
      gK = (OO, KO) => {
        (0, oO.q)(vK.x.PadAction, OO, 0, 0, (0, oO.o)(KO, performance.now()))
      },
      uO = OO => {
        gK(OO, lO.od.Down)
      },
      EO = OO => {
        gK(OO, 0)
      },
      jK = OO => {
        uO(OO), EO(OO)
      },
      YO = () => {
        const OO = (0, DO.g)();
        return null !== OO && void 0 !== OO && OO.isCoreRunning ? OO : null
      },
      wO = OO => lO.t.playerFlags(OO.api.apiView, 0),
      iK = OO => null !== OO && lO.t.targetBlockId(OO.api.apiView, 0) !== lO.Xc,
      rK = () => {
        const OO = (0, FO.e)(),
          KO = new VO.c;
        let pO = !1;
        const XO = (OO, KO) => {
            (0, oO.q)(vK.x.PadLook, lO.wd.Rate, OO, KO, 0)
          },
          bK = () => {
            pO = !1, KO.reset(), XO(0, 0)
          };
        return {
          update: (bK, eO, CO) => {
            pO || (OO.discardPending(), pO = !0);
            const hO = (0, VO.n)(KO, bK, eO, CO, performance.now());
            XO(hO.yawRadPerSec, hO.pitchRadPerSec);
            const DO = OO.drainLookDelta();
            0 === DO.wKO && 0 === DO.ipO || (0, oO.q)(vK.x.PadLook, lO.wd.Gyro, DO.wKO, DO.ipO, 0)
          },
          release: bK,
          uninstall: bK
        }
      },
      PO = () => {
        const OO = YO();
        return null !== OO && 0 !== (wO(OO) & lO.Ad.PadSneakToggled)
      },
      mK = () => {
        const OO = (OO => {
          const KO = OO => function() {
            return (0, aK.d)(), OO(...arguments)
          };
          return {
            primaryFireDown: KO((() => (uO(zK), 0))),
            primaryFireUp: KO((() => {
              EO(zK)
            })),
            altFireDown: KO((() => (uO(AO), 0))),
            altFireUp: KO((() => {
              EO(AO)
            })),
            jumpDown: KO((() => {
              jK(dO)
            })),
            specialActionDown: KO((OO => {
              uO(yK[OO])
            })),
            specialActionUp: KO((OO => {
              EO(yK[OO])
            })),
            reloadGun: KO((() => {
              jK(TO)
            })),
            dropItem: KO((OO => {
              gK(lO.pd.Drop, lO.od.Down | (OO ? lO.od.Stack : 0))
            })),
            swapCameraZoom: KO((() => {
              jK(NO)
            })),
            XM: KO((() => (jK(fO), iK(OO()))))
          }
        })(YO);
        let KO = !1,
          pO = null;
        const XO = () => {
          var OO;
          null === (OO = pO) || void 0 === OO || OO(), pO = null
        };
        return {
          bodies: () => OO,
          look: rK(),
          move: (OO, pO) => {
            var bK;
            XO();
            const {
              bits: eO,
              flips: vK
            } = (OO => {
              if (null === OO) return {
                bits: lO.sd.Peek,
                flips: 0
              };
              const KO = OO.sneakHeld ? lO.sd.SneakHeld : 0;
              return "hold" === OO.mode ? {
                bits: KO | lO.sd.SneakHoldMode,
                flips: OO.sneakTogglePressed ? 1 : 0
              } : {
                bits: KO,
                flips: OO.sneakPressed || OO.sneakTogglePressed ? 1 : 0
              }
            })(pO);
            null !== (bK = YO()) && void 0 !== bK && bK.padMove(OO.x, OO.y, OO.magnitude, OO.headingOffset, (OO => lO.sd.Active | (OO.jumpHeld ? lO.sd.JumpHeld : 0) | (OO.jumpPressed ? lO.sd.JumpPressed : 0) | (OO.running ? lO.sd.Running : 0) | (OO.sprintHeld ? lO.sd.SprintHeld : 0))(OO) | eO, vK) && (KO = !0), (0, LO.i)(PO())
          },
          stopMoving: () => {
            var OO;
            KO && (KO = !(null !== (OO = YO()) && void 0 !== OO && OO.padMove(0, 0, 0, 0, 0, 0)), XO(), pO = (0, CO.v)((() => {
              XO(), (0, LO.i)(PO())
            })))
          },
          uninstall: XO,
          deviceChanged: OO => {
            var pO;
            "touch" === OO ? ((0, LO.i)(!1), null !== (pO = YO()) && void 0 !== pO && pO.padMove(0, 0, 0, 0, lO.sd.EndToggle, 0) && (KO = !1)) : "gamepad" === OO && (0, LO.i)(PO())
          },
          hasPlayer: () => null !== YO(),
          isPlayerDead: () => {
            var OO;
            return !1 === (null === (OO = YO()) || void 0 === OO ? void 0 : OO.localPlayerAlive())
          },
          isReplayMode: () => {
            const OO = YO();
            return null !== OO && 0 !== (wO(OO) & lO.Ad.Replay)
          },
          isFreeCameraOn: () => {
            const OO = YO();
            return null !== OO && 0 !== (wO(OO) & lO.Ad.FreeCam)
          },
          targetsBlock: () => iK(YO()),
          selectedSlotEmpty: () => {
            var OO;
            return !(null !== (OO = YO()) && void 0 !== OO && OO.items.JK())
          },
          pickBlockAllowed: () => !!eO.c.get("creative") && !!eO.c.get("canPickBlocks"),
          scrollHotbar: OO => {
            gK(lO.pd.Hotbar, lO.od.Down | (OO > 0 ? lO.od.Next : 0))
          },
          hasFullInventory: hO.i,
          hasLobbyLeaderboard: () => !!eO.c.get("lobbyLeaderboardInfo"),
          contextActionInputs: () => {
            var OO, KO, pO, XO;
            const bK = YO();
            return {
              holdingGun: !1 !== (null === bK || void 0 === bK ? void 0 : bK.localPlayerAlive()) && "Gun" === (null === bK || void 0 === bK || null === (OO = bK.items.JK()) || void 0 === OO || null === (KO = OO.typeObj) || void 0 === KO ? void 0 : KO.type),
              customButtons: null !== (pO = eO.c.get("customButtons")) && void 0 !== pO ? pO : null,
              touchscreenActionButton: null !== (XO = eO.c.get("touchscreenActionButton")) && void 0 !== XO ? XO : null
            }
          },
          pressTouchButton: OO => {
            OO ? uO(IO) : EO(IO)
          }
        }
      },
      sO = () => {
        const OO = (0, bK.e)(mK()),
          KO = (0, XO.d)(),
          pO = null;
        return () => {
          OO(), KO(), null === pO || void 0 === pO || pO()
        }
      }
  },
  38755: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      e: () => eO,
      h: () => bK
    });
    let XO = null;

    function bK(OO) {
      XO = OO
    }

    function eO(OO) {
      XO === OO && (XO = null)
    }

    function lO() {
      var OO;
      null === (OO = XO) || void 0 === OO || OO()
    }
  },
  8461: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => eO
    });
    var XO = pO(8411);
    const bK = "Air",
      eO = Object.freeze(new XO.f(bK, 0, "", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null))
  },
  35411: (OO, KO, pO) => {
    function XO(OO) {
      return OO.includes("Leaf Bed")
    }

    function bK(OO) {
      return / Bed(?: Head)?(?:\||$)/.test(OO) && !XO(OO)
    }

    function eO(OO) {
      return OO.includes(" Strongbed")
    }

    function lO(OO) {
      return XO(OO) || bK(OO) || eO(OO)
    }
    pO.d(KO, {
      c: () => lO,
      g: () => XO,
      k: () => eO,
      l: () => bK
    })
  },
  35409: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => hO
    });
    var XO = pO(35411),
      bK = pO(8365);
    const eO = [],
      lO = [],
      vK = [],
      CO = [];
    for (const DO of Object.keys(bK.r))(0, XO.g)(DO) ? eO.push(DO) : (0, XO.l)(DO) && lO.push(DO), (0, XO.k)(DO) && vK.push(DO), (DO.includes(" Bed Head") || DO.includes(" Strongbed Head")) && CO.push(DO);
    const hO = {
      leafBeds: eO,
      woolBeds: lO,
      strongBeds: vK,
      beds: [...eO, ...lO, ...vK],
      bedHeads: CO,
      blockRemoveActionRoots: ["Chest", "Loot Chest", "Iron Chest", "Mailbox", "Bookshelf", "Empty Bookshelf"]
    }
  },
  5628: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      f: () => bK,
      j: () => CO,
      m: () => eO,
      o: () => hO,
      p: () => XO,
      q: () => vK
    });
    let XO = function(OO) {
        return OO[OO.DEFAULT = 0] = "DEFAULT", OO[OO.BOAT = 1] = "BOAT", OO[OO.GLIDER = 2] = "GLIDER", OO[OO.BALLOON = 3] = "BALLOON", OO[OO.SLEEPING = 4] = "SLEEPING", OO[OO.RIDING_MOB = 5] = "RIDING_MOB", OO[OO.CAR = 6] = "CAR", OO[OO.HOVERCRAFT = 7] = "HOVERCRAFT", OO
      }({}),
      bK = function(OO) {
        return OO[OO.WOOD = 0] = "WOOD", OO[OO.OBSIDIAN = 1] = "OBSIDIAN", OO[OO.SPEED = 2] = "SPEED", OO
      }({}),
      eO = function(OO) {
        return OO[OO.WOOD = 0] = "WOOD", OO[OO.IRON = 1] = "IRON", OO[OO.GOLD = 2] = "GOLD", OO[OO.DIAMOND = 3] = "DIAMOND", OO
      }({}),
      lO = function(OO) {
        return OO[OO.YELLOW = 0] = "YELLOW", OO[OO.WHITE = 1] = "WHITE", OO[OO.RED = 2] = "RED", OO[OO.PURPLE = 3] = "PURPLE", OO[OO.PINK = 4] = "PINK", OO[OO.ORANGE = 5] = "ORANGE", OO[OO.MAGENTA = 6] = "MAGENTA", OO[OO.LIME = 7] = "LIME", OO[OO.LIGHT_GRAY = 8] = "LIGHT_GRAY", OO[OO.LIGHT_BLUE = 9] = "LIGHT_BLUE", OO[OO.GREEN = 10] = "GREEN", OO[OO.GRAY = 11] = "GRAY", OO[OO.CYAN = 12] = "CYAN", OO[OO.BROWN = 13] = "BROWN", OO[OO.BLUE = 14] = "BLUE", OO[OO.BLACK = 15] = "BLACK", OO
      }({}),
      vK = function(OO) {
        return OO[OO.ROTATION_1 = 0] = "ROTATION_1", OO[OO.ROTATION_2 = 1] = "ROTATION_2", OO[OO.ROTATION_3 = 2] = "ROTATION_3", OO[OO.ROTATION_4 = 3] = "ROTATION_4", OO
      }({}),
      CO = function(OO) {
        return OO[OO.KART = 0] = "KART", OO[OO.OFF_ROADER = 1] = "OFF_ROADER", OO[OO.CAR = 2] = "CAR", OO[OO.GOLD_MINING_DRILL = 3] = "GOLD_MINING_DRILL", OO[OO.ARMORED_CAR = 4] = "ARMORED_CAR", OO[OO.IRON_MINING_DRILL = 5] = "IRON_MINING_DRILL", OO[OO.DIAMOND_MINING_DRILL = 6] = "DIAMOND_MINING_DRILL", OO[OO.MOONSTONE_MINING_DRILL = 7] = "MOONSTONE_MINING_DRILL", OO
      }({});
    XO.DEFAULT, XO.BOAT, bK.SPEED, XO.GLIDER, eO.DIAMOND, XO.BALLOON, lO.BLACK, XO.SLEEPING, vK.ROTATION_4, XO.RIDING_MOB, XO.CAR, CO.MOONSTONE_MINING_DRILL, XO.HOVERCRAFT;
    let hO = function(OO) {
      return OO[OO.NORMAL = 0] = "NORMAL", OO[OO.GLIDING = 1] = "GLIDING", OO[OO.FLOATING = 2] = "FLOATING", OO
    }({})
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);