export const id = 111;
export const ids = [111];
export const modules = {
  5666: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => oO
    });
    var XO = pO(1355),
      bK = pO(1388),
      eO = pO(2329),
      lO = pO(1271),
      vK = pO(1344),
      CO = pO(1004),
      hO = pO(926),
      DO = pO(1051),
      MO = pO(933),
      aK = pO(976);

    function oO() {
      var OO;
      const {
        t: KO
      } = (0, DO.D)(), {
        pack: pO
      } = (0, XO.w)(), {
        userContext: oO
      } = (0, CO.d)();
      if (pO) {
        const OO = bK.e[pO];
        if (null === OO || void 0 === OO || !OO.purchasable) return (0, aK.jsx)(vK.NavigatePreserveSearch, {
          to: "/"
        })
      }
      const FO = pO ? bK.e[pO] : null,
        VO = pO ? eO.j[pO] : null,
        LO = FO ? `Your ${null!==(OO=FO.displayName)&&void 0!==OO?OO:pO} Pack is Ready!` : "Welcome To Super Rank!",
        QO = FO ? "Equip your new cosmetics in the character customisation menu!" : "You can change you name color and cape in the customization menu in game!",
        zK = FO ? !oO.getOwnedCosmeticPacks().includes(pO) : !oO.playerHasRank("super"),
        AO = FO ? "You should get your cosmetics instantly, but it could take up to an hour to apply. If you don't have them after an hour, contact help@bloxd.io." : "You should get Super Rank instantly, but it could take up to an hour to apply. If you don't have Super Rank after an hour, contact help@bloxd.io.";
      return (0, aK.jsxs)("div", {
        className: "PurchaseWelcome AnimFadeInScaleUp",
        children: [VO && (0, aK.jsx)(VO, {}), !FO && (0, aK.jsx)(hO.b, {
          iconName: "bolt",
          iconCountPerGroup: 10,
          animation: "Fall",
          midShowerStart: !0,
          customClass: "SuperRankWelcomeIconShower"
        }), (0, aK.jsx)("div", {
          className: "PurchaseWelcomeTitle FullyFancyText",
          children: LO
        }), (0, aK.jsx)("div", {
          className: "PurchaseWelcomeText",
          children: QO
        }), zK && (0, aK.jsxs)("div", {
          className: "PurchaseWelcomeWarning",
          children: [(0, aK.jsx)(MO.d, {
            name: "circle-info"
          }), (0, aK.jsx)("div", {
            children: AO
          })]
        }), (0, aK.jsx)(vK.LinkPreserveSearch, {
          to: "/",
          children: (0, aK.jsx)(lO.m, {
            className: "PurchaseWelcomeContinue",
            children: KO("general:continue")
          })
        })]
      })
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);