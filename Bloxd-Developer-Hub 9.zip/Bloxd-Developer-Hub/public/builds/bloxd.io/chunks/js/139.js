export const id = 139;
export const ids = [139];
export const modules = {
  7209: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      AdMobSdkAdaptor: () => hO
    });
    var XO = pO(1158),
      bK = pO(1507),
      eO = pO(142),
      lO = pO(2711),
      vK = pO(256);
    const CO = {
      mobileAndroid: {
        banners: {
          leaderboard_1: "ca-app-pub-5991928098122027/7081016880",
          leaderboard_4: "ca-app-pub-5991928098122027/6301601920",
          leaderboard_5: "ca-app-pub-5991928098122027/7592152779",
          skyscraper_1: "ca-app-pub-5991928098122027/1026744422",
          skyscraper_2: "ca-app-pub-5991928098122027/3483866894",
          square_1: "ca-app-pub-5991928098122027/6381115670"
        },
        rewarded: "ca-app-pub-5991928098122027/5726886857",
        interstitial: "ca-app-pub-5991928098122027/1979213537"
      },
      mobileIos: {
        banners: {
          leaderboard_1: "ca-app-pub-5991928098122027/4652945503",
          leaderboard_4: "ca-app-pub-5991928098122027/2921518285",
          leaderboard_5: "ca-app-pub-5991928098122027/7518781992",
          skyscraper_1: "ca-app-pub-5991928098122027/8344778507",
          skyscraper_2: "ca-app-pub-5991928098122027/3781201590",
          square_1: "ca-app-pub-5991928098122027/2468119924"
        },
        rewarded: "ca-app-pub-5991928098122027/5014392212",
        interstitial: "ca-app-pub-5991928098122027/4405533493"
      }
    };
    class hO extends XO.c {
      constructor(OO) {
        super(), this.name = "admob", this.bannerAutoRefresh = "alwaysOn", this.adUnitIds = void 0, this.bannerPlacementByBloxdId = new Map, this.bannerFirstResponseSeen = new Set, this.inflightRewarded = null, this.inflightInterstitial = null, this.adUnitIds = CO[OO], this.subscribeToRNResponses()
      }
      static async setup() {
        const OO = "mobileIos" === eO.t ? "mobileIos" : "mobileAndroid";
        return (0, bK.h)() || console.error(`AD: AdMobSDK initialised on ${OO} but ReactNativeWebView is unavailable; ads will be no-ops`), console.log(`AD: AdMobSDK initialised for ${OO}`), new hO(OO)
      }
      subscribeToRNResponses() {
        (0, bK.q)("renderBanner", (OO => {
          let {
            placementId: KO,
            success: pO,
            error: XO
          } = OO;
          const bK = !this.bannerFirstResponseSeen.has(KO);
          this.bannerFirstResponseSeen.add(KO), bK ? pO ? console.log(`AD ${KO}: AdMob banner loaded`) : console.warn(`AD ${KO}: AdMob banner failed to load: ${XO}`) : pO || console.warn(`AD ${KO}: AdMob banner refresh failed: ${XO}`)
        })), (0, bK.q)("playRewarded", (OO => {
          let {
            placementId: KO,
            completed: pO
          } = OO;
          const XO = this.inflightRewarded;
          null !== XO && XO.placementId === KO ? XO.finish(pO) : console.warn(`AD ${KO}: AdMob rewarded response received with no matching in-flight request`)
        })), (0, bK.q)("playVideoAd", (OO => {
          let {
            placementId: KO,
            completed: pO
          } = OO;
          const XO = this.inflightInterstitial;
          null !== XO && XO.placementId === KO ? XO.finish(pO) : console.warn(`AD ${KO}: AdMob interstitial response received with no matching in-flight request`)
        })), (0, bK.q)("clearBanner", (OO => {
          let {
            placementId: KO,
            success: pO
          } = OO;
          pO || console.log(`AD ${KO}: AdMob clearBanner returned success=false (no active banner)`)
        }))
      }
      playRewarded(OO, KO) {
        const pO = this.adUnitIds.rewarded;
        if (null !== this.inflightRewarded) return console.error(`AD ${pO}: AdMob rewarded already in flight, failing new request`), void KO();
        const XO = pO => {
            clearTimeout(this.inflightRewarded.timeoutHandle), this.inflightRewarded = null, pO ? OO() : KO()
          },
          eO = setTimeout((() => {
            console.warn(`AD ${pO}: AdMob rewarded timed out after 30000ms`), XO(!1)
          }), 3e4);
        this.inflightRewarded = {
          placementId: pO,
          timeoutHandle: eO,
          finish: XO
        }, (0, bK.o)("playRewarded", {
          placementId: pO
        }) || XO(!1)
      }
      playVideoAd(OO, KO) {
        const pO = this.adUnitIds.interstitial;
        if (null !== this.inflightInterstitial) return console.error(`AD ${pO}: AdMob interstitial already in flight, skipping`), void OO();
        let XO = !1;
        const eO = KO => {
            clearTimeout(this.inflightInterstitial.timeoutHandle), this.inflightInterstitial = null, XO || (XO = !0, OO())
          },
          lO = setTimeout((() => {
            console.warn(`AD ${pO}: AdMob interstitial timed out after 30000ms`), eO()
          }), 3e4);
        this.inflightInterstitial = {
          placementId: pO,
          timeoutHandle: lO,
          finish: eO
        }, (0, bK.o)("playVideoAd", {
          placementId: pO
        }) || eO()
      }
      renderBanner(OO) {
        const KO = (0, lO.c)(OO),
          pO = this.adUnitIds.banners[KO];
        if (void 0 === pO) return;
        const XO = document.getElementById(OO.divId);
        if (!XO) return void console.warn(`AD ${KO}: AdMob renderBanner called but div ${OO.divId} is not in DOM`);
        const eO = XO.getBoundingClientRect(),
          CO = window.innerWidth,
          hO = window.innerHeight;
        if (0 === CO || 0 === hO) return void console.warn(`AD ${KO}: AdMob renderBanner skipped \u2014 viewport has zero dimension`);
        const DO = {
          x1: vK.e.clamp(eO.left / CO * 100, 0, 100),
          y1: vK.e.clamp(eO.top / hO * 100, 0, 100),
          x2: vK.e.clamp(eO.right / CO * 100, 0, 100),
          y2: vK.e.clamp(eO.bottom / hO * 100, 0, 100)
        };
        this.bannerPlacementByBloxdId.set(KO, pO), console.log(`AD ${KO}: AdMob renderBanner placementId=${pO} box=`, DO), (0, bK.o)("renderBanner", {
          placementId: pO,
          ...DO
        })
      }
      clearBanner(OO) {
        const KO = (0, lO.c)(OO),
          pO = this.bannerPlacementByBloxdId.get(KO);
        void 0 !== pO && (this.bannerPlacementByBloxdId.delete(KO), this.bannerFirstResponseSeen.delete(pO), console.log(`AD ${KO}: AdMob clearBanner placementId=${pO}`), (0, bK.o)("clearBanner", {
          placementId: pO
        }))
      }
      canShowBloxdAd(OO) {
        return !1
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);