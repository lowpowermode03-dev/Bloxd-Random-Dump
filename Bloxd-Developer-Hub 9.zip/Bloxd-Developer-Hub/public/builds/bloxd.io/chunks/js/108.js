export const id = 108;
export const ids = [108, 377];
export const modules = {
  34920: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => jp
    });
    var XO = pO(243),
      bK = pO(2748),
      eO = pO(2780),
      lO = pO(2771),
      vK = pO(2769),
      CO = pO(1051),
      hO = pO(36),
      DO = pO(1481),
      MO = pO(1195),
      aK = pO(1271),
      oO = pO(918),
      FO = pO.n(oO),
      VO = pO(1475),
      LO = pO(63),
      QO = pO(77),
      zK = pO(1918),
      AO = pO(1165),
      fO = pO(1420),
      dO = pO(1004),
      TO = pO(2680),
      NO = pO(3732),
      IO = pO(2732),
      yK = pO(2737),
      gK = pO(1533),
      uO = pO(2739),
      EO = pO(1487),
      jK = pO(1329),
      YO = pO(1749),
      wO = pO(1180),
      iK = pO(2061),
      rK = pO(4148),
      PO = pO(976);
    const mK = 15e3,
      sO = 2500;

    function HO(OO) {
      var KO;
      let {
        eventName: pO
      } = OO;
      const {
        t: XO
      } = (0, CO.D)(), bK = EO.d[pO], [eO, lO] = (0, LO.useState)((() => Date.now() >= bK.endsAt.getTime())), [vK, hO] = (0, LO.useState)("overall"), DO = function(OO, KO) {
        const {
          userContext: pO,
          isUserContextUpdating: XO
        } = (0, dO.d)(), bK = `${OO}:${KO}`, [eO, lO] = (0, LO.useState)({
          requestKey: bK,
          leaderboard: {
            status: "loading"
          }
        });
        return (0, LO.useEffect)((() => {
          if (XO) return;
          let eO, vK = !1;
          const CO = async () => {
            if ("visible" === document.visibilityState) try {
              const XO = await jK.c.getGameEventLeaderboard(pO, {
                event: OO,
                scope: KO
              });
              vK || lO({
                requestKey: bK,
                leaderboard: {
                  status: "loaded",
                  leaderboard: XO
                }
              })
            } catch {
              vK || lO((OO => OO.requestKey === bK && "loaded" === OO.leaderboard.status ? OO : {
                requestKey: bK,
                leaderboard: {
                  status: "unavailable"
                }
              }))
            }
            vK || (eO = setTimeout(CO, mK))
          };
          return CO(), () => {
            vK = !0, clearTimeout(eO)
          }
        }), [OO, KO, bK, pO, XO]), eO.requestKey === bK ? eO.leaderboard : {
          status: "loading"
        }
      }(pO, vK), MO = function(OO) {
        const KO = (0, LO.useRef)(null),
          pO = (0, LO.useRef)(0),
          XO = (0, LO.useRef)(),
          [bK, eO] = (0, LO.useState)({});
        return (0, LO.useEffect)((() => {
          const bK = null === OO || void 0 === OO ? void 0 : OO.entries;
          if (!bK) return;
          const lO = new Map(bK.map((OO => [OO.player.name, OO.value]))),
            vK = KO.current;
          if (KO.current = lO, null === vK) return;
          const CO = {};
          for (const [OO, KO] of lO) {
            const XO = vK.get(OO);
            void 0 !== XO && KO > XO && (CO[OO] = {
              amount: KO - XO,
              key: pO.current++
            })
          }
          0 !== Object.keys(CO).length && (eO(CO), clearTimeout(XO.current), XO.current = setTimeout((() => {
            eO({})
          }), sO))
        }), [OO]), (0, LO.useEffect)((() => () => {
          clearTimeout(XO.current)
        }), []), bK
      }("loaded" === DO.status ? DO.leaderboard : null), aK = function(OO) {
        const [KO, pO] = (0, LO.useState)(null), XO = "loaded" === OO.status ? OO.leaderboard.goalProgress : void 0;
        return (0, LO.useEffect)((() => {
          XO && pO(XO)
        }), [XO]), KO
      }(DO), oO = YO.c[`profileEffect_${bK.prizePack}`];
      if (eO) return null;
      const VO = "loaded" === DO.status ? DO.leaderboard : null,
        QO = null !== (KO = null === VO || void 0 === VO ? void 0 : VO.entries) && void 0 !== KO ? KO : null,
        zK = null !== VO && void 0 !== VO && VO.own && null !== QO && !QO.some((OO => OO.isOwn)) ? VO.own : null;
      return (0, PO.jsx)("section", {
        className: "GameEventPanel AnimFadeIn",
        children: (0, PO.jsxs)("div", {
          className: "GameEventPanelCard",
          children: [(0, PO.jsxs)("div", {
            className: "GameEventPanelInfo",
            children: [(0, PO.jsxs)("div", {
              className: "GameEventPanelStatus",
              children: [(0, PO.jsxs)("span", {
                className: "GameEventPanelLive",
                children: [(0, PO.jsx)("span", {
                  className: "GameEventPanelLiveDot"
                }), XO("gameEvents:live")]
              }), (0, PO.jsxs)("span", {
                className: "GameEventPanelEndsIn",
                children: [XO("gameEvents:endsIn"), (0, PO.jsx)(IO.b, {
                  toTime: bK.endsAt,
                  onReachEndOfCountdown: () => {
                    lO(!0)
                  }
                })]
              })]
            }), (0, PO.jsx)("h2", {
              className: "GameEventPanelTitle",
              children: XO(bK.titleKey)
            }), (0, PO.jsxs)("div", {
              className: "GameEventPanelPrize",
              children: [(0, PO.jsxs)("div", {
                className: "GameEventPanelPrizeSummary",
                children: [oO && (0, PO.jsx)("div", {
                  className: "GameEventPanelPrizePreview",
                  children: (0, PO.jsx)(oO, {})
                }), (0, PO.jsxs)("div", {
                  className: "GameEventPanelPrizeText",
                  children: [(0, PO.jsx)("div", {
                    className: "GameEventPanelPrizeLabel",
                    children: XO("gameEvents:prize")
                  }), (0, PO.jsx)("div", {
                    className: "GameEventPanelPrizeName",
                    children: XO(bK.prizeNameKey)
                  })]
                })]
              }), (0, PO.jsx)(RO, {
                event: bK,
                progress: aK
              })]
            })]
          }), (0, PO.jsxs)("div", {
            className: "GameEventPanelLeaderboard",
            children: [(0, PO.jsxs)("div", {
              className: "GameEventPanelLeaderboardHeader",
              children: [(0, PO.jsx)("h3", {
                className: "GameEventPanelLeaderboardTitle",
                children: XO(bK.leaderboard.titleKey)
              }), (0, PO.jsx)(rK.c, {
                ariaLabel: XO("gameEvents:leaderboardScope"),
                options: EO.c.map((OO => ({
                  value: OO,
                  label: XO(`gameEvents:${OO}Scope`)
                }))),
                value: vK,
                onChange: hO
              })]
            }), "loading" === DO.status && (0, PO.jsx)("div", {
              className: "GameEventPanelLeaderboardLoader AnimFadeIn",
              children: (0, PO.jsx)(wO.e, {})
            }), ("unavailable" === DO.status || "loaded" === DO.status && null === QO) && (0, PO.jsx)("div", {
              className: "GameEventPanelLeaderboardMessage",
              children: XO("gameEvents:leaderboardUnavailable")
            }), null !== QO && 0 === QO.length && (0, PO.jsx)("div", {
              className: "GameEventPanelLeaderboardMessage",
              children: XO("friends" === vK ? "gameEvents:friendsLeaderboardEmpty" : "gameEvents:leaderboardEmpty")
            }), null !== QO && QO.length > 0 && (0, PO.jsx)("ol", {
              className: "GameEventPanelRows",
              children: QO.map((OO => {
                const KO = MO[OO.player.name];
                return (0, PO.jsxs)("li", {
                  className: FO()("GameEventPanelRow", {
                    GameEventPanelRowOwn: OO.isOwn,
                    GameEventPanelRowTop: OO.rank <= 3
                  }),
                  children: [(0, PO.jsxs)("span", {
                    className: "GameEventPanelRank",
                    children: ["#", OO.rank]
                  }), (0, PO.jsx)("div", {
                    className: "GameEventPanelPlayer",
                    children: (0, PO.jsx)(iK.h, {
                      playerSocialPreview: {
                        ...OO.player,
                        location: {
                          status: "offline"
                        }
                      },
                      showLocation: !1
                    })
                  }), void 0 !== KO && (0, PO.jsxs)("span", {
                    className: "GameEventPanelGain",
                    children: ["+", KO.amount.toLocaleString()]
                  }, KO.key), (0, PO.jsx)("span", {
                    className: "GameEventPanelScore",
                    children: OO.value.toLocaleString()
                  })]
                }, OO.player.name)
              }))
            }), zK && (0, PO.jsxs)("div", {
              className: "GameEventPanelRow GameEventPanelRowOwn GameEventPanelOwnRow",
              children: [(0, PO.jsxs)("span", {
                className: "GameEventPanelRank",
                children: ["#", zK.rank.toLocaleString()]
              }), (0, PO.jsx)("span", {
                className: "GameEventPanelPlayer",
                children: XO("gameEvents:yourPlace")
              }), (0, PO.jsx)("span", {
                className: "GameEventPanelScore",
                children: zK.value.toLocaleString()
              })]
            })]
          })]
        })
      })
    }

    function RO(OO) {
      let {
        event: KO,
        progress: pO
      } = OO;
      const {
        t: XO
      } = (0, CO.D)(), bK = null !== pO && KO.prizeGoals.some(((OO, KO) => pO[KO] >= OO.target));
      return (0, PO.jsxs)("div", {
        className: "GameEventPanelGoals",
        children: [(0, PO.jsx)("div", {
          className: "GameEventPanelGoalsHeading",
          children: XO(bK ? "gameEvents:prizeEarned" : "gameEvents:goalsHeading")
        }), (0, PO.jsx)("div", {
          className: "GameEventPanelGoalRow",
          children: KO.prizeGoals.map(((OO, KO) => {
            const bK = null === pO ? null : Math.min(pO[KO], OO.target);
            return (0, PO.jsxs)(LO.Fragment, {
              children: [KO > 0 && (0, PO.jsx)("div", {
                className: "GameEventPanelGoalsOr",
                children: XO("gameEvents:goalsOr")
              }), (0, PO.jsxs)("div", {
                className: FO()("GameEventPanelGoal", {
                  GameEventPanelGoalDone: bK === OO.target
                }),
                children: [(0, PO.jsx)("span", {
                  className: "GameEventPanelGoalLabel",
                  children: XO(OO.labelKey)
                }), (0, PO.jsxs)("div", {
                  className: "GameEventPanelGoalBar",
                  children: [(0, PO.jsx)("div", {
                    className: "GameEventPanelGoalBarFill",
                    style: {
                      width: (null !== bK && void 0 !== bK ? bK : 0) / OO.target * 100 + "%"
                    }
                  }), null !== bK && (0, PO.jsxs)("span", {
                    className: "GameEventPanelGoalCount",
                    children: [bK.toLocaleString(), " / ", OO.target.toLocaleString()]
                  })]
                })]
              })]
            }, OO.board)
          }))
        })]
      })
    }
    var SO = pO(1382),
      JO = pO(1410),
      cK = pO(906),
      BO = pO(596),
      ZO = pO(2730);

    function GO(OO) {
      let {
        gameNameWithVariation: KO
      } = OO;
      const pO = (0, SO.B)(KO),
        [XO, bK] = (0, LO.useState)(null);
      if ((0, LO.useEffect)((() => {
          if (!pO) return;
          let OO = !0;
          return (0, JO.h)(pO).then((KO => {
            OO && bK(KO)
          })).catch((OO => {
            console.error(`Failed to load the page copy for ${pO.name}`, OO)
          })), () => {
            OO = !1
          }
        }), [pO]), !pO || !XO || XO.name !== pO.name) return null;
      const eO = (0, JO.g)(XO),
        lO = new Set((0, cK.e)((0, BO.h)()).map((OO => (0, SO.q)(OO)))),
        vK = XO.similarGames.filter((OO => lO.has((0, SO.q)(OO))));
      return (0, PO.jsx)("div", {
        className: "GamePageContent",
        children: (0, PO.jsxs)("div", {
          className: "GamePageContentColumns",
          children: [(0, PO.jsxs)("section", {
            className: "GamePageContentSection",
            children: [(0, PO.jsx)("h2", {
              children: eO.whatIs
            }), XO.whatIs.map((OO => (0, PO.jsx)("p", {
              children: OO
            }, OO)))]
          }), (0, PO.jsxs)("section", {
            className: "GamePageContentSection",
            children: [(0, PO.jsx)("h2", {
              children: eO.howToPlay
            }), XO.howToPlay.map((OO => (0, PO.jsx)("p", {
              children: OO
            }, OO)))]
          }), (0, PO.jsxs)("section", {
            className: "GamePageContentSection",
            children: [(0, PO.jsx)("h2", {
              children: eO.features
            }), (0, PO.jsx)("ul", {
              children: XO.features.map((OO => (0, PO.jsx)("li", {
                children: OO
              }, OO)))
            })]
          }), (0, PO.jsxs)("aside", {
            className: "GamePageContentSection",
            children: [(0, PO.jsx)("h2", {
              children: eO.tips
            }), (0, PO.jsx)("ul", {
              children: XO.tips.map((OO => (0, PO.jsx)("li", {
                children: OO
              }, OO)))
            })]
          }), (0, PO.jsxs)("section", {
            className: "GamePageContentSection GamePageContentFaq",
            children: [(0, PO.jsx)("h2", {
              children: eO.faq
            }), XO.faq.map((OO => {
              let {
                question: KO,
                answer: pO
              } = OO;
              return (0, PO.jsxs)("div", {
                className: "GamePageContentFaqItem",
                children: [(0, PO.jsx)("h3", {
                  children: KO
                }), (0, PO.jsx)("p", {
                  children: pO
                })]
              }, KO)
            }))]
          }), vK.length > 0 && (0, PO.jsxs)("nav", {
            className: "GamePageContentSection GamePageContentSimilarGamesSection",
            children: [(0, PO.jsx)("h2", {
              children: eO.similarGames
            }), (0, PO.jsx)("ul", {
              className: "GamePageContentSimilarGames",
              children: vK.map((OO => (0, PO.jsx)("li", {
                children: (0, PO.jsx)(ZO.f, {
                  source: {
                    type: "game",
                    gameNameWithVariation: OO
                  },
                  entrySource: "other",
                  gameWidth: "100%",
                  useLongRatio: !0
                })
              }, OO)))
            })]
          })]
        })
      })
    }
    var qK = pO(933),
      xK = pO(94),
      nO = pO(1008),
      WO = pO(2822),
      tK = pO(1456),
      kK = pO(1355),
      UO = pO(1344),
      OK = pO(1415),
      KK = pO(1280),
      pK = pO(1187),
      XK = pO(34925),
      bp = pO(1095),
      eK = pO(886),
      lK = pO(256),
      vp = pO(892),
      CK = pO(1374),
      hK = pO(7970),
      DK = pO(22),
      MK = pO(2020),
      ap = pO(638),
      oK = pO(1077),
      FK = pO(5653);

    function VK(OO) {
      let {
        preview: KO,
        isBroken: pO
      } = OO;
      const XO = null === KO ? null : (0, eO.f)(KO, "small"),
        lO = (0, bK.c)(null !== XO && void 0 !== XO ? XO : eO.q);
      return null === KO ? (0, PO.jsx)("div", {
        className: FO()("FeaturedGamesPopupSlotThumbnail FeaturedGamesPopupSlotThumbnailEmpty", {
          FeaturedGamesPopupSlotThumbnailBroken: pO
        }),
        children: (0, PO.jsx)(qK.d, {
          name: pO ? "triangle-exclamation" : "star"
        })
      }) : (0, PO.jsx)("div", {
        className: FO()("FeaturedGamesPopupSlotThumbnail", vK.m),
        style: (0, vK.i)(lO),
        role: "img",
        "aria-label": KO.name,
        children: (0, PO.jsx)(vK.e, {
          image: lO
        })
      })
    }

    function LK(OO) {
      let {
        schematicId: KO,
        gameName: pO
      } = OO;
      const {
        userContext: bK
      } = (0, dO.d)(), eO = (0, yK.b)(), [lO, vK] = (0, LO.useState)(null), [CO, hO] = (0, LO.useState)(null), [DO, MO] = (0, LO.useState)(!1), oO = (0, LO.useCallback)((() => {
        hO(null), jK.c.getFeaturedGames(bK).then((OO => {
          eO.current && vK(OO.slots)
        })).catch((OO => {
          console.error("Failed to get featured games", OO), eO.current && hO("Failed to load featured games")
        }))
      }), [bK, eO]);
      (0, LO.useEffect)((() => {
        oO()
      }), [oO]);
      const FO = (OO, KO) => {
        DO || (MO(!0), jK.c.setFeaturedGame(bK, OO, KO).then((() => {
          eO.current && oO()
        })).catch((OO => {
          console.error("Failed to set featured game", OO), eO.current && hO("Failed to update the featured slot")
        })).finally((() => {
          eO.current && MO(!1)
        })))
      };
      return (0, PO.jsxs)("div", {
        className: "FeaturedGamesPopupBody",
        children: [(0, PO.jsx)("h1", {
          className: "FeaturedGamesPopupTitle",
          children: "Featured Games"
        }), !lO && !CO && (0, PO.jsx)("div", {
          className: "FeaturedGamesPopupLoader",
          children: (0, PO.jsx)(wO.e, {})
        }), CO && (0, PO.jsx)("div", {
          className: "FeaturedGamesPopupError",
          children: CO
        }), lO && (0, PO.jsxs)(PO.Fragment, {
          children: [(0, PO.jsx)("div", {
            className: "FeaturedGamesPopupSlots",
            children: lO.map((OO => {
              const pO = OO.schematicId === KO,
                bK = null === OO.schematicId,
                {
                  categoryGroup: eO
                } = XO.E[OO.slotId];
              return (0, PO.jsxs)("div", {
                className: "FeaturedGamesPopupSlot",
                children: [(0, PO.jsx)(VK, {
                  preview: OO.preview,
                  isBroken: !bK
                }), (0, PO.jsxs)("div", {
                  className: "FeaturedGamesPopupSlotText",
                  children: [(0, PO.jsxs)("div", {
                    className: "FeaturedGamesPopupSlotLabel",
                    children: [(0, XO.ib)(eO), " \xb7 position", " ", (0, XO.F)(OO.slotId, XO.Pb) + 1, " of", " ", (0, XO.Mb)(eO, XO.Pb)]
                  }), bK && (0, PO.jsx)("div", {
                    className: "FeaturedGamesPopupSlotEmpty",
                    children: "Empty"
                  }), !bK && null !== OO.preview && (0, PO.jsx)("div", {
                    className: "FeaturedGamesPopupSlotGame",
                    children: OO.preview.name
                  }), !bK && null === OO.preview && (0, PO.jsxs)("div", {
                    className: "FeaturedGamesPopupSlotMissing",
                    children: [(0, PO.jsx)(qK.d, {
                      name: "triangle-exclamation"
                    }), " Pinned game is no longer published"]
                  })]
                }), (0, PO.jsxs)("div", {
                  className: "FeaturedGamesPopupSlotActions",
                  children: [bK && (0, PO.jsxs)(aK.s, {
                    className: "FeaturedGamesPopupSlotButton",
                    onClick: () => {
                      FO(OO.slotId, KO)
                    },
                    disabled: DO,
                    children: [(0, PO.jsx)(qK.d, {
                      name: "star"
                    }), " Feature here"]
                  }), !bK && !pO && (0, PO.jsxs)(aK.S, {
                    className: "FeaturedGamesPopupSlotButton",
                    onClick: () => {
                      FO(OO.slotId, KO)
                    },
                    disabled: DO,
                    children: [(0, PO.jsx)(qK.d, {
                      name: "star"
                    }), " Replace"]
                  }), !bK && (0, PO.jsxs)(aK.I, {
                    className: "FeaturedGamesPopupSlotButton",
                    onClick: () => {
                      FO(OO.slotId, null)
                    },
                    disabled: DO,
                    children: [(0, PO.jsx)(qK.d, {
                      name: "xmark"
                    }), " Clear"]
                  })]
                })]
              }, OO.slotId)
            }))
          }), (0, PO.jsx)("p", {
            className: "FeaturedGamesPopupHint",
            children: "A game leaves its slot once it ranks higher on its own."
          })]
        })]
      })
    }
    var QK = pO(3838),
      zp = pO(3772),
      AK = pO(3781),
      fK = pO(3795),
      dK = pO(3750),
      TK = pO(2815),
      NK = pO(180);
    const IK = {
      skyblock: [pO(34952).d]
    };
    var yp = pO(533);
    const gp = {
      listedVariations: null,
      backgroundImage: eO.q,
      badges: [],
      category: null,
      title: null,
      variationTitle: null,
      description: null,
      ownerSocialPreviewWithoutLocation: null,
      ccu: null,
      favourites: null,
      isFavourite: null,
      useRejoinLastLobbyButton: null,
      showWorldsInsteadOfCustomLobbies: null,
      canCreateCustomLobbies: null,
      countdownInformation: null
    };

    function uK(OO, KO) {
      const pO = ap.h[OO.schematicId];
      return {
        listedVariations: [],
        backgroundImage: (0, eO.f)(OO, "large"),
        badges: [],
        category: OO.gameCategory,
        title: void 0 !== (null === pO || void 0 === pO ? void 0 : pO.title) ? KO(pO.title) : OO.name,
        variationTitle: null,
        description: void 0 !== (null === pO || void 0 === pO ? void 0 : pO.description) ? KO(pO.description) : OO.description,
        ownerSocialPreviewWithoutLocation: "owner" in OO ? OO.owner : null,
        ccu: OO.ccu,
        favourites: OO.favourites,
        isFavourite: null,
        useRejoinLastLobbyButton: "persistWorld" in OO ? OO.persistWorld : null,
        showWorldsInsteadOfCustomLobbies: !1,
        canCreateCustomLobbies: !0,
        countdownInformation: null
      }
    }

    function EK(OO) {
      var KO, pO, XO;
      return null !== (KO = null !== (pO = (0, NK.k)() ? function(OO) {
        for (const [KO, pO] of Object.entries(IK)) {
          const XO = [KO, ...pO.map((OO => (0, lK.Mb)(KO, OO)))];
          if (XO.includes(OO)) return XO
        }
        return null
      }(OO) : null) && void 0 !== pO ? pO : null === (XO = ap.e[OO]) || void 0 === XO ? void 0 : XO.listedVariations) && void 0 !== KO ? KO : null
    }

    function jp() {
      const {
        gameNameWithVariation: OO
      } = (0, kK.w)();
      if ((0, LO.useEffect)(TK.p, []), OO && (0, bp.t)(OO)) return (0, PO.jsx)(YK, {
        urlId: OO
      }, OO);
      const KO = OO && (0, eK.k)(OO) ? OO : "firstParty";
      return (0, PO.jsx)(wK, {}, KO)
    }

    function YK(OO) {
      let {
        urlId: KO
      } = OO;
      const {
        userContext: pO,
        isUserContextUpdating: XO
      } = (0, dO.d)(), bK = (0, LO.useMemo)((() => (0, tK.i)(KO)), [KO]);
      (0, LO.useMemo)((() => {
        if (null === bK) return;
        const OO = nO.userContextManager.peekCurrentUserContext();
        (null !== OO ? jK.c.getGame(OO, bK.schematicId) : nO.userContextManager.getCurrentUserContext().then((OO => jK.c.getGame(OO, bK.schematicId)))).catch((OO => {
          console.error(`Failed to get the custom game ${bK.schematicId}`, OO), (0, tK.f)(KO)
        }))
      }), [bK, KO]);
      const [eO, lO] = (0, LO.useState)(null), [vK, CO] = (0, LO.useState)(!1);
      (0, LO.useLayoutEffect)((() => {
        let OO = !0;
        return (0, WO.b)().then((() => {
          OO && CO(!0)
        })), () => {
          OO = !1
        }
      }), []), (0, LO.useEffect)((() => {
        if (null !== bK || XO) return;
        let OO = !0;
        return jK.c.getGameByUrlId(pO, KO).then((pO => {
          OO && lO({
            urlId: KO,
            game: pO
          })
        })).catch((pO => {
          console.error(`Failed to find the custom game with urlId ${KO}`, pO), OO && (0, UO.navigateToHomePage)()
        })), () => {
          OO = !1
        }
      }), [KO, bK, XO, pO]);
      const hO = null !== bK && void 0 !== bK ? bK : (null === eO || void 0 === eO ? void 0 : eO.urlId) === KO ? eO.game : null;
      return null === hO ? (0, PO.jsx)(wO.e, {}) : vK ? (0, PO.jsx)(wK, {
        gameNameWithVariation: (0, eK.s)(hO.schematicId),
        knownCustomGame: hO
      }, hO.schematicId) : null
    }

    function wK(OO) {
      var KO, pO, lO, oO, EO, YO, wO, rK;
      let {
        gameNameWithVariation: mK,
        knownCustomGame: sO = null
      } = OO;
      const {
        t: RO
      } = (0, CO.D)();
      (0, MK.h)();
      const JO = (0, MK.m)(),
        {
          userContext: cK,
          isUserContextUpdating: ZO
        } = (0, dO.d)(),
        nO = (0, dK.g)(),
        WO = (0, UO.useNavigatePreserveSearch)(),
        tK = (0, kK.w)(),
        KK = (0, LO.useMemo)((() => mK ? {
          gameNameWithVariation: mK
        } : tK), [mK, tK]),
        bp = (0, hK.e)(KK),
        VK = (0, LO.useMemo)((() => {
          const OO = function(OO) {
            var KO, pO;
            const XO = EK(OO);
            if (!XO || 0 === XO.length || XO.includes(OO)) return OO;
            const bK = hO.e.getItem((0, zK.h)(OO));
            if (bK && XO.includes(bK)) return bK;
            return null !== (KO = null === (pO = ap.e[OO]) || void 0 === pO ? void 0 : pO.defaultListedVariation) && void 0 !== KO ? KO : XO[0]
          }(bp.gameNameWithVariation);
          return OO === bp.gameNameWithVariation ? bp : {
            ...bp,
            gameNameWithVariation: OO
          }
        }), [bp]);
      (0, LO.useEffect)((() => {
        const OO = bp.gameNameWithVariation;
        VK.gameNameWithVariation !== OO && OO !== (0, lK.Qb)(OO) && WO((0, SO.u)(VK.gameNameWithVariation), {
          replace: !0
        })
      }), [VK.gameNameWithVariation, bp.gameNameWithVariation, WO]);
      const TK = (0, yK.b)(),
        [NK, IK] = (0, LO.useState)(""),
        jp = LO.useRef(null),
        [YK, wK] = (0, LO.useState)(),
        rp = (0, eK.k)(VK.gameNameWithVariation),
        PK = (0, LO.useMemo)((() => rp ? null : function(OO, KO, pO) {
          var XO, bK;
          const lO = ap.e[OO];
          return (0, yp.I)(lO) ? null : {
            listedVariations: EK(OO),
            backgroundImage: (0, eO.k)(OO, (0, eO.d)(lO)),
            badges: (0, DO.filterBadges)(lO.badges),
            category: lO.type,
            title: pO(lO.title),
            variationTitle: lO.variationTitle ? pO(lO.variationTitle) : null,
            description: pO(lO.description),
            ownerSocialPreviewWithoutLocation: null,
            ccu: null !== KO ? null !== (XO = KO[OO]) && void 0 !== XO ? XO : 0 : null,
            favourites: null,
            isFavourite: null,
            useRejoinLastLobbyButton: lO.useRejoinLastLobbyButton,
            showWorldsInsteadOfCustomLobbies: lO.showWorldsInsteadOfCustomLobbies,
            canCreateCustomLobbies: null === (bK = lO.canCreateCustomLobbies) || void 0 === bK || bK,
            countdownInformation: (0, zK.e)(OO)
          }
        }(VK.gameNameWithVariation, JO, RO)), [rp, VK.gameNameWithVariation, JO, RO]),
        [mp, sK] = (0, LO.useState)(!1),
        [HK, RK] = (0, LO.useState)((() => sO ? uK(sO, RO) : gp)),
        SK = null !== PK && void 0 !== PK ? PK : HK,
        [JK] = (0, LO.useState)(SK === gp),
        cp = (0, bK.c)(SK.backgroundImage, {
          keepPrevious: !0,
          decode: !0
        }),
        {
          recentlyPlayedPublicLobbies: BK,
          recentlyPlayedCustomLobbies: ZK
        } = (0, LO.useMemo)((() => function(OO, KO, pO, XO) {
          var bK;
          const eO = OO => {
              const pO = (0, eK.o)(OO),
                XO = KO.find((KO => "custom" === KO.type ? KO.schematicId === pO : KO.gameNameWithVariation === OO));
              return XO ? [...XO.recentLobbies] : []
            },
            lO = (0, DO.getRecentGameNameWithVariationLobbiesKey)(OO),
            vK = null !== (bK = hO.e.getItem(lO)) && void 0 !== bK ? bK : [],
            CO = [...eO(OO), ...vK],
            MO = [];
          for (const hO of CO)(0, oK.J)(hO) && !MO.includes(hO) && MO.push(hO);
          let aK = CO;
          if (pO) {
            const OO = eO("classic_worlds"),
              KO = CO.filter((KO => !OO.includes(KO)));
            aK = [...OO, ...KO]
          }
          const oO = [],
            FO = !1 === XO ? [] : aK;
          for (const hO of FO)(0, oK.J)(hO) || oO.includes(hO) || oO.push(hO);
          return {
            recentlyPlayedPublicLobbies: MO,
            recentlyPlayedCustomLobbies: oO
          }
        }(VK.gameNameWithVariation, nO, SK.showWorldsInsteadOfCustomLobbies, SK.canCreateCustomLobbies)), [VK.gameNameWithVariation, nO, SK.showWorldsInsteadOfCustomLobbies, SK.canCreateCustomLobbies]),
        [GK, qp] = (0, LO.useState)(!0),
        [xp, nK] = (0, LO.useState)([]),
        [WK, tp] = (0, LO.useState)(null),
        [kp, UK] = (0, LO.useState)("explore"),
        Op = (0, LO.useRef)(!1),
        Kp = (0, LO.useCallback)((OO => {
          (0, QO.unstable_batchedUpdates)((() => {
            wK(OO), RK((KO => ({
              ...uK(OO, RO),
              isFavourite: KO.isFavourite
            })))
          }))
        }), [RO]);
      (0, LO.useEffect)((() => {
        null === DK.d.get("gameEntrySource") && (0, DK.j)("gameInformationPageDirect")
      }), []);
      const pp = (0, LO.useRef)(null);
      (0, LO.useEffect)((() => {
        const OO = OO => {
            pp.current = OO.target instanceof Element ? OO.target.closest("a, button") : null
          },
          KO = OO => {
            "Tab" === OO.key && (pp.current = null)
          };
        return document.addEventListener("pointerdown", OO, !0), document.addEventListener("keydown", KO, !0), () => {
          document.removeEventListener("pointerdown", OO, !0), document.removeEventListener("keydown", KO, !0)
        }
      }), []), (0, TO.b)("Enter", (OO => {
        const KO = OO.target instanceof Element ? OO.target : null;
        if (OO.defaultPrevented || null !== KO && void 0 !== KO && KO.closest("input, textarea, select")) return;
        const pO = null === KO || void 0 === KO ? void 0 : KO.closest("a, button");
        pO && pO !== pp.current || (OO.preventDefault(), Mp())
      })), (0, NO.e)(UO.navigateToHomePage);
      const Xp = !BO.k && (BK.length > 0 || ZK.length > 0),
        bX = !SK.useRejoinLastLobbyButton || 0 === BK.length,
        ep = rp && null === SK.ownerSocialPreviewWithoutLocation,
        lp = cK.getPlayerName() === (null === YK || void 0 === YK || null === (KO = YK.owner) || void 0 === KO ? void 0 : KO.name),
        vX = null !== (pO = null === (lO = SK.badges.find((OO => "event" === OO.type))) || void 0 === lO ? void 0 : lO.event) && void 0 !== pO ? pO : null,
        Cp = bX ? aK.m : aK.d,
        hp = (0, PO.jsx)(MO.g, {
          tooltipInner: (0, PO.jsx)("div", {
            children: RO("homePage:quickPlayInfo")
          }),
          hoverOnly: !0,
          children: (0, PO.jsx)(Cp, {
            className: "GameInformationButton",
            padDefaultFocus: bX,
            showPress: !0,
            onClick: () => {
              Mp()
            },
            children: (0, PO.jsxs)("div", {
              className: "GameInformationButtonInner",
              children: [bX && (0, PO.jsxs)(PO.Fragment, {
                children: [(0, PO.jsx)(qK.d, {
                  name: "play"
                }), " "]
              }), RO("homePage:quickPlay")]
            })
          })
        });
      (0, LO.useEffect)((() => {
        if (!rp || ZO) return;
        let OO = !0;
        const KO = (0, eK.o)(VK.gameNameWithVariation);
        return jK.c.getGame(cK, KO).then((KO => {
          OO && Kp(KO)
        })).catch((KO => {
          console.error("Failed to get Custom Game information", KO), OO && (0, UO.navigateToHomePage)()
        })), jK.c.getFavouriteGames(cK).then((pO => {
          OO && RK((OO => ({
            ...OO,
            isFavourite: pO.includes(KO)
          })))
        })).catch((KO => {
          console.error("Failed to get favourite games", KO), OO && sK(!0)
        })), () => {
          OO = !1
        }
      }), [rp, ZO, VK.gameNameWithVariation, Kp, cK]);
      const Dp = !rp && null === PK;

      function Mp(OO) {
        WO((0, AO.b)(VK.gameNameWithVariation, OO))
      }(0, LO.useEffect)((() => {
        Dp && (0, UO.navigateToHomePage)()
      }), [Dp]), (0, LO.useEffect)((() => {
        !1 !== SK.canCreateCustomLobbies && null !== SK.showWorldsInsteadOfCustomLobbies && (BO.k || !1 !== ZO || (qp(!0), jK.c.getFavouriteLobbies(cK).then((OO => {
          tp(OO)
        })), jK.c.getOpenCustomLobbies(cK, {
          gameNameWithVariation: SK.showWorldsInsteadOfCustomLobbies ? "classic" : VK.gameNameWithVariation,
          onlyOwnedLobbies: "owned" === kp,
          onlyFavouriteLobbies: "favourite" === kp
        }).then((OO => {
          TK.current && nK(OO)
        })).catch((OO => {})).finally((() => {
          TK.current && qp(!1)
        }))))
      }), [ZO, VK, kp, SK.showWorldsInsteadOfCustomLobbies, SK.canCreateCustomLobbies, TK, cK]);
      const aX = (0, LO.useCallback)((async OO => {
          try {
            if (!WK) return;
            WK.includes(OO) ? (jK.c.unfavouriteLobby(cK, OO), tp(WK.filter((KO => KO !== OO)))) : (jK.c.favouriteLobby(cK, OO).catch((OO => {
              console.error("Failed to favourite lobby", OO)
            })), tp([...WK, OO]))
          } catch (KO) {
            console.error("Failed to like lobby", KO)
          }
        }), [cK, WK]),
        op = (null === YK || void 0 === YK ? void 0 : YK.schematicId) === (0, eK.o)(bp.gameNameWithVariation) ? YK : null,
        Fp = op && (0, SO.F)(bp.gameNameWithVariation, (OO => RO(OO)), op);
      (0, OK.e)(op && (0, SO.u)(bp.gameNameWithVariation, op));
      const Vp = !BO.k && xK.featureFlags.canUseCustomLobbies && !0 === SK.canCreateCustomLobbies,
        Lp = (0, PO.jsx)("div", {
          className: "GameInformationPageContentAnchor",
          children: (0, PO.jsx)(GO, {
            gameNameWithVariation: VK.gameNameWithVariation
          })
        });
      return (0, PO.jsx)(PO.Fragment, {
        children: (0, PO.jsxs)("article", {
          className: FO()("GameInformation", {
            GameInformationFadeIn: JK,
            GameInformationReleaseCountdown: "releaseCountdown" === (null === (oO = SK.countdownInformation) || void 0 === oO ? void 0 : oO.type)
          }),
          children: [Fp && (0, PO.jsx)(fO.c, {
            meta: Fp
          }), (0, PO.jsxs)("div", {
            className: "GameInformationInner",
            children: [(0, PO.jsxs)("div", {
              className: "GameInformationTop",
              children: [(0, PO.jsxs)("div", {
                className: "GameInformationTopBackgroundContainer",
                children: [(0, PO.jsx)("div", {
                  className: "GameInformationTopBackgroundColor"
                }), (0, PO.jsx)("div", {
                  className: FO()("GameInformationTopBackgroundImage", vK.m),
                  style: (0, vK.i)(cp),
                  children: (0, PO.jsx)(vK.e, {
                    image: cp
                  })
                })]
              }), (0, PO.jsxs)("div", {
                className: "GameInformationTopLeft",
                children: [(0, PO.jsx)(QK.c, {}), (0, PO.jsxs)("div", {
                  className: "GameInformationTopLeftBody",
                  children: [(0, PO.jsxs)("div", {
                    className: "GameInformationHeader",
                    children: [(0, PO.jsxs)("div", {
                      className: FO()("GameInformationHeaderTagList", {
                        GameInformationHeaderTagListPending: ep
                      }),
                      children: [SK.badges.map((OO => (0, PO.jsx)("div", {
                        className: `GameInformationHeaderTag AnimFadeInScaleUp ${OO.type}`,
                        children: (0, PO.jsx)(uO.d, {
                          badge: OO
                        })
                      }, OO.type))), rp && (0, PO.jsx)("div", {
                        className: "GameInformationHeaderTag playerCrafted AnimFadeInScaleUp",
                        children: (0, PO.jsx)(gK.d, {
                          text: (0, XO.ab)({
                            type: "playerCrafted"
                          })
                        })
                      }), SK.category && (0, PO.jsx)("div", {
                        className: "GameInformationHeaderTag CustomGameCategory AnimFadeInScaleUp",
                        children: (0, PO.jsx)(gK.d, {
                          text: [{
                            str: (0, XO.cb)(SK.category).toUpperCase()
                          }]
                        })
                      }), null !== SK.ccu && (0, PO.jsxs)("div", {
                        className: "CustomGameChip CustomGameChipCcu AnimFadeIn",
                        children: [(0, PO.jsx)(qK.d, {
                          name: "user"
                        }), (0, oK.L)(SK.ccu), " online"]
                      }), null !== SK.ownerSocialPreviewWithoutLocation && (0, PO.jsxs)("div", {
                        className: "CustomGameChip CustomGameChipOwner AnimFadeIn",
                        children: [(0, PO.jsx)("span", {
                          children: "Made by"
                        }), (0, PO.jsx)(iK.h, {
                          playerSocialPreview: {
                            ...SK.ownerSocialPreviewWithoutLocation,
                            location: {
                              status: "offline"
                            }
                          },
                          showLocation: !1,
                          linkToProfile: !0
                        })]
                      }), ep && (0, PO.jsxs)("div", {
                        className: "CustomGameChip CustomGameChipOwner",
                        children: [(0, PO.jsx)("span", {
                          children: "Made by"
                        }), (0, PO.jsx)("div", {
                          className: "CustomGameChipOwnerPlaceholder"
                        })]
                      }), null !== SK.favourites && (null !== SK.isFavourite || rp && !mp) && (0, PO.jsx)(aK.w, {
                        onClick: () => {
                          ! function() {
                            if (!0 !== Op.current && (Op.current = !0, null !== SK.isFavourite)) {
                              const OO = (0, eK.o)(VK.gameNameWithVariation);
                              let KO;
                              SK.isFavourite ? (KO = -1, jK.c.unfavouriteGame(cK, OO).catch((OO => {
                                console.error("Failed to get unfavourite game", OO)
                              })).finally((() => {
                                Op.current = !1
                              }))) : (KO = 1, jK.c.favouriteGame(cK, OO).catch((OO => {
                                console.error("Failed to get favourite game", OO)
                              })).finally((() => {
                                Op.current = !1
                              }))), RK((OO => ({
                                ...OO,
                                isFavourite: !OO.isFavourite
                              }))), RK((OO => ({
                                ...OO,
                                favourites: OO.favourites + KO
                              })))
                            }
                          }()
                        },
                        isLiked: null !== (EO = SK.isFavourite) && void 0 !== EO && EO,
                        disabled: null === SK.isFavourite,
                        className: FO()("CustomGameChip AnimFadeIn", {
                          CustomGameChipPending: null === SK.isFavourite
                        })
                      }, null === SK.isFavourite ? "pending" : "known"), rp && !ep && xK.featureFlags.useSocialFeatures && !lp && (0, PO.jsx)(AK.c, {
                        targetType: "customGame",
                        targetId: (0, eK.o)(VK.gameNameWithVariation),
                        className: "CustomGameChip AnimFadeIn"
                      }), (cK.playerHasRank("developer") || cK.playerHasRank("admin") && lp) && (0, PO.jsxs)(aK.m, {
                        className: "CustomGameChip AnimFadeIn",
                        onClick: () => {
                          WO((0, CK.q)((0, vp.c)(VK.gameNameWithVariation, !0)))
                        },
                        children: [(0, PO.jsx)(qK.d, {
                          name: "star-christmas"
                        }), " ", RO("studio:viewInStudio")]
                      }), rp && cK.playerHasRank("developer") && (0, PO.jsxs)(aK.d, {
                        className: "CustomGameChip AnimFadeIn",
                        onClick: () => {
                          (0, FK.c)({
                            schematicId: (0, eK.o)(VK.gameNameWithVariation),
                            canOverride: !0
                          })
                        },
                        children: [(0, PO.jsx)(qK.d, {
                          name: "circle-info"
                        }), " Approval Info"]
                      }), rp && cK.playerHasRank("developer") && (0, PO.jsxs)(aK.d, {
                        className: "CustomGameChip AnimFadeIn",
                        onClick: () => {
                          pK.NotificationProvider.showCustomPopup({
                            body: () => (0, PO.jsx)(LK, {
                              schematicId: (0, eK.o)(VK.gameNameWithVariation),
                              gameName: SK.title
                            }),
                            middleScreenPopupClassName: "FeaturedGamesPopup",
                            onClose: () => {},
                            unlockPointerKey: "featuredGamesPopup"
                          })
                        },
                        children: [(0, PO.jsx)(qK.d, {
                          name: "star"
                        }), " Featured Games"]
                      }), "updateCountdown" === (null === (YO = SK.countdownInformation) || void 0 === YO ? void 0 : YO.type) && (0, PO.jsxs)("div", {
                        className: "CustomGameChip GameChipUpdateCountdown AnimFadeIn",
                        children: [(0, PO.jsxs)("div", {
                          className: "GameChipUpdateCountdownTop",
                          children: ["Update in ", (0, PO.jsx)(IO.b, {
                            toTime: SK.countdownInformation.countdownToTime
                          })]
                        }), (0, PO.jsx)("div", {
                          className: "GameChipUpdateCountdownBottom",
                          children: SK.countdownInformation.previewText
                        })]
                      })]
                    }, ep ? "pending" : "shown"), (0, PO.jsxs)("header", {
                      className: "GameInformationTitle",
                      children: [(0, PO.jsx)("div", {
                        className: "GameInformationTitleAndChips",
                        children: (0, PO.jsxs)("h1", {
                          className: "GameInformationTitleText FullyFancyText",
                          children: [SK.title, " ", SK.variationTitle && (null === (wO = ap.e[VK.gameNameWithVariation]) || void 0 === wO ? void 0 : wO.variationThumbnailUseBigRatio) && (0, PO.jsx)("span", {
                            className: "GameInformationTitleVariation",
                            children: SK.variationTitle
                          })]
                        })
                      }), SK.listedVariations && SK.listedVariations.length > 0 && (0, PO.jsx)("div", {
                        className: FO()("GameInformationVariationList", {
                          GameInformationVariationListBig: null === (rK = ap.e[VK.gameNameWithVariation]) || void 0 === rK ? void 0 : rK.variationThumbnailUseBigRatio
                        }),
                        children: SK.listedVariations.map((OO => {
                          var KO, pO;
                          return (0, PO.jsxs)(ip, {
                            variation: OO,
                            isSelected: VK.gameNameWithVariation === OO,
                            children: [null !== JO && (0, PO.jsx)("div", {
                              className: "GameInformationVariationCCU AnimFadeIn",
                              children: (0, PO.jsxs)("div", {
                                className: "GameInformationVariationCCUInner",
                                children: [(0, PO.jsx)(qK.d, {
                                  name: "user"
                                }), " ", (0, oK.L)(null !== (KO = JO[OO]) && void 0 !== KO ? KO : 0)]
                              })
                            }), (0, PO.jsx)("div", {
                              className: "GameInformationVariationTitle SmallTextBold",
                              children: RO(null !== (pO = ap.e[OO].variationTitle) && void 0 !== pO ? pO : ap.e[OO].title)
                            }), (0, PO.jsx)("div", {
                              className: "ThumbnailBadgesContainer",
                              children: (0, DO.filterBadges)(ap.e[OO].badges).map((OO => (0, PO.jsx)("div", {
                                className: "ThumbnailBadgeContainer " + OO.type,
                                children: (0, PO.jsx)("div", {
                                  className: "ThumbnailBadgeMain",
                                  children: (0, PO.jsx)(uO.d, {
                                    badge: OO
                                  })
                                })
                              }, OO.type)))
                            })]
                          }, OO)
                        }))
                      })]
                    }), SK.description && (0, PO.jsx)("p", {
                      className: "GameInformationDescription",
                      children: SK.description
                    })]
                  }), (0, PO.jsxs)("div", {
                    className: "GameInformationButtonRows",
                    children: [(0, PO.jsxs)("div", {
                      className: "GameInformationButtonRow GameInformationButtonRowPrimary",
                      children: [!BO.k && !bX && (0, PO.jsx)(MO.g, {
                        tooltipInner: (0, PO.jsx)("div", {
                          children: RO("homePage:rejoinLobbyNumberInfo")
                        }),
                        hoverOnly: !0,
                        children: (0, PO.jsx)(aK.m, {
                          className: "GameInformationButton",
                          padDefaultFocus: !0,
                          showPress: !0,
                          onClick: () => {
                            Mp(BK[0])
                          },
                          children: (0, PO.jsxs)("div", {
                            className: "GameInformationButtonInner",
                            children: [(0, PO.jsx)(qK.d, {
                              name: "play"
                            }), " ", RO("homePage:rejoinLobbyNumber", {
                              number: BK[0]
                            })]
                          })
                        })
                      }), !BO.k && bX && hp]
                    }), (0, PO.jsxs)("div", {
                      className: "GameInformationButtonRow GameInformationButtonRowSecondary",
                      children: [!BO.k && !bX && hp, (0, PO.jsxs)("div", {
                        className: "JoinLobbyContainer",
                        children: [(0, PO.jsx)(qK.d, {
                          name: "magnifying-glass",
                          className: "JoinLobbyInputIcon"
                        }), (0, PO.jsx)(VO.e, {
                          className: "JoinLobbyInput",
                          placeholderText: RO("homePage:lobbyName"),
                          maxLength: oK.K,
                          domRef: jp,
                          onValueChange: OO => {
                            OO = (0, oK.kb)(OO), IK(OO)
                          },
                          onEnter: () => {
                            0 === NK.length ? Mp(BK[0]) : Mp(NK)
                          }
                        }), (0, PO.jsx)(aK.d, {
                          className: "JoinLobbyButton",
                          showPress: !0,
                          onClick: () => {
                            0 === NK.length ? Mp(BK[0]) : Mp(NK)
                          },
                          children: RO("general:join")
                        })]
                      })]
                    }), (0, PO.jsxs)("section", {
                      className: FO()("LobbyCollection RecentLobbyCollection", {
                        LobbyCollectionHidden: !Xp
                      }),
                      children: [(0, PO.jsx)("div", {
                        className: "LobbyCollectionHeader RecentLobbyCollectionHeader",
                        children: (0, PO.jsxs)("div", {
                          className: "LobbyCollectionTitle",
                          children: [(0, PO.jsx)(qK.d, {
                            name: "clock-rotate-left"
                          }), Xp && (0, PO.jsx)("h2", {
                            className: "VisuallyHidden",
                            children: RO("homePage:recentlyPlayedLobbies")
                          })]
                        })
                      }), (0, PO.jsx)(fK.c, {
                        lobbyGroups: [BK, ZK],
                        onLobbyClick: OO => {
                          Mp(OO)
                        },
                        keyPrefix: VK.gameNameWithVariation
                      })]
                    })]
                  })]
                })]
              }), null !== vX && (0, PO.jsx)(HO, {
                eventName: vX
              })]
            }), Vp && (0, PO.jsx)("div", {
              className: "GameInformationBottom",
              children: (0, PO.jsxs)("section", {
                className: "LobbyCollection",
                children: [(0, PO.jsxs)("div", {
                  className: FO()("LobbyCollectionHeader", {
                    SandboxWorldsLobbyCollectionHeader: !0 === SK.showWorldsInsteadOfCustomLobbies
                  }),
                  children: [!0 === SK.showWorldsInsteadOfCustomLobbies && (0, PO.jsxs)("h2", {
                    className: "LobbyCollectionTitle",
                    children: [(0, PO.jsx)(qK.d, {
                      name: "planet-ringed",
                      kit: "duotone"
                    }), (0, PO.jsxs)("div", {
                      className: "LobbyCollectionTitleText",
                      children: [(0, PO.jsx)("div", {
                        className: "LobbyCollectionTitleTextBackground"
                      }), RO("game:worlds")]
                    })]
                  }), !1 === SK.showWorldsInsteadOfCustomLobbies && (0, PO.jsxs)("h2", {
                    className: "LobbyCollectionTitle",
                    children: [(0, PO.jsx)(qK.d, {
                      name: "joystick"
                    }), (0, PO.jsxs)("div", {
                      className: "LobbyCollectionTitleText",
                      children: [(0, PO.jsx)("div", {
                        className: "LobbyCollectionTitleTextBackground"
                      }), RO("homePage:customLobbies")]
                    })]
                  }), (0, PO.jsx)(aK.S, {
                    onClick: () => {
                      UK("explore")
                    },
                    active: "explore" === kp,
                    children: RO("general:explore")
                  }), (0, PO.jsx)(aK.S, {
                    onClick: () => {
                      UK("favourite")
                    },
                    active: "favourite" === kp,
                    children: RO("homePage:favouriteLobbies")
                  }), (0, PO.jsx)(aK.S, {
                    onClick: () => {
                      UK("owned")
                    },
                    active: "owned" === kp,
                    children: RO("homePage:ownedLobbies")
                  })]
                }), (0, PO.jsxs)("div", {
                  className: "CustomLobbyList",
                  children: [(0, PO.jsxs)("div", {
                    className: "CustomLobbyListInner",
                    children: [(0, PO.jsx)(zp.c, {
                      label: "Create",
                      onClick: () => {
                        pK.NotificationProvider.showCustomPopup({
                          body: OO => (0, PO.jsx)(XK.CreateCustomLobby, {
                            gameNameWithVariation: VK.gameNameWithVariation,
                            close: OO
                          }),
                          middleScreenPopupClassName: "CreateCustomLobbyPopup"
                        })
                      }
                    }), !0 === GK && (0, PO.jsx)(zp.i, {}), !1 === GK && xp.length > 0 && xp.map((OO => (0, PO.jsx)(zp.e, {
                      customLobby: OO,
                      favouriteLobbies: WK,
                      toggleLikeLobby: aX,
                      showReport: xK.featureFlags.useSocialFeatures && "owned" !== kp
                    }, OO.name)))]
                  }), Lp]
                })]
              })
            })]
          }), !Vp && Lp]
        })
      })
    }

    function ip(OO) {
      let {
        variation: KO,
        isSelected: pO,
        children: XO
      } = OO;
      const CO = ap.e[KO],
        DO = (0, eO.k)(KO, (0, eO.o)(CO)),
        MO = (0, bK.c)(DO),
        aK = (0, lO.d)([(0, eO.i)(KO, (0, eO.d)(CO))]);
      return (0, PO.jsxs)(UO.LinkPreserveSearch, {
        to: (0, SO.u)(KO),
        replace: !0,
        className: FO()("GameInformationVariation", vK.m, {
          SelectedGameInformationVariation: pO
        }),
        onClick: OO => {
          if (!(0, KK.b)(OO)) return;
          const pO = (0, zK.h)(KO);
          hO.e.setItem(pO, KO)
        },
        onMouseEnter: aK.start,
        onMouseLeave: aK.cancel,
        onFocus: aK.start,
        onBlur: aK.cancel,
        style: (0, vK.i)(MO),
        children: [(0, PO.jsx)(vK.e, {
          image: MO
        }), XO]
      })
    }
  },
  5653: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => QO
    });
    var XO = pO(63),
      bK = pO(1271),
      eO = pO(1329),
      lO = pO(2737),
      vK = pO(1004),
      CO = pO(1180),
      hO = pO(1195),
      DO = pO(933),
      MO = pO(918),
      aK = pO.n(MO),
      oO = pO(976);

    function FO(OO) {
      let {
        info: KO,
        className: pO
      } = OO;
      return (0, oO.jsxs)("div", {
        className: aK()("GameApprovalInfoDetails", pO),
        children: [(0, oO.jsxs)("div", {
          className: aK()("GameApprovalInfoSummary", KO.overallPassed ? "Passed" : "Failed"),
          children: [(0, oO.jsx)(DO.d, {
            name: KO.overallPassed ? "circle-check" : "circle-xmark"
          }), (0, oO.jsx)("span", {
            children: KO.summary
          })]
        }), KO.rows.length > 0 && (0, oO.jsx)("div", {
          className: "GameApprovalInfoRows",
          children: KO.rows.map((OO => (0, oO.jsxs)("div", {
            className: aK()("GameApprovalInfoRow", OO.passed ? "Passed" : "Failed"),
            children: [(0, oO.jsx)(DO.d, {
              name: OO.passed ? "check" : "xmark"
            }), (0, oO.jsxs)("div", {
              className: "GameApprovalInfoRowText",
              children: [(0, oO.jsx)("div", {
                className: "GameApprovalInfoRowLabel",
                children: OO.label
              }), (0, oO.jsx)("div", {
                className: "GameApprovalInfoRowValue",
                children: OO.valueText
              })]
            })]
          }, OO.label)))
        })]
      })
    }
    var VO = pO(1051),
      LO = pO(1187);

    function QO(OO) {
      LO.NotificationProvider.showCustomPopup({
        body: () => (0, oO.jsx)(zK, {
          ...OO
        }),
        middleScreenPopupClassName: "ApprovalInfoPopup",
        onClose: () => {},
        unlockPointerKey: "approvalInfoPopup"
      })
    }

    function zK(OO) {
      let {
        schematicId: KO,
        canOverride: pO,
        onApprovalChanged: MO
      } = OO;
      const {
        t: aK
      } = (0, VO.D)(), {
        userContext: LO
      } = (0, vK.d)(), QO = (0, lO.b)(), [zK, AO] = (0, XO.useState)(null), [fO, dO] = (0, XO.useState)(null), [TO, NO] = (0, XO.useState)(!1), IO = (0, XO.useCallback)((() => {
        dO(null), eO.c.getGameApprovalInfo(LO, KO).then((OO => {
          QO.current && AO(OO)
        })).catch((OO => {
          console.error("Failed to get game approval info", OO), QO.current && dO(aK("studio:approvalLoadFailed"))
        }))
      }), [LO, KO, QO, aK]);
      (0, XO.useEffect)((() => {
        IO()
      }), [IO]);
      const yK = OO => {
        TO || (NO(!0), eO.c.setGameApproval(LO, KO, OO).then((() => {
          null === MO || void 0 === MO || MO(), QO.current && IO()
        })).catch((OO => {
          console.error("Failed to set game approval", OO)
        })).finally((() => {
          QO.current && NO(!1)
        })))
      };
      return (0, oO.jsxs)("div", {
        className: "ApprovalInfoPopupBody",
        children: [(0, oO.jsx)("h1", {
          className: "ApprovalInfoPopupTitle",
          children: aK("studio:approvalTitle")
        }), !zK && !fO && (0, oO.jsx)("div", {
          className: "ApprovalInfoPopupLoader",
          children: (0, oO.jsx)(CO.e, {})
        }), fO && (0, oO.jsx)("div", {
          className: "ApprovalInfoPopupError",
          children: fO
        }), zK && (0, oO.jsxs)(oO.Fragment, {
          children: [(0, oO.jsx)(FO, {
            info: zK
          }), pO && (0, oO.jsxs)("div", {
            className: "ApprovalInfoPopupActions",
            children: [!0 !== zK.manualOverride && (0, oO.jsx)(hO.g, {
              tooltipInner: (0, oO.jsx)("div", {
                children: "Manually approve the game. This will bypass the auto-approval criteria and allow the game to be shown on the home page."
              }),
              children: (0, oO.jsxs)(bK.m, {
                className: "ApprovalInfoPopupActionButton",
                onClick: () => {
                  yK(!0)
                },
                disabled: TO,
                children: [(0, oO.jsx)(DO.d, {
                  name: "check"
                }), " Manually Approve"]
              })
            }), !1 !== zK.manualOverride && (0, oO.jsx)(hO.g, {
              tooltipInner: (0, oO.jsx)("div", {
                children: "Manually deny the game. This forces the game to be hidden from the home page, even if it passes auto-approval."
              }),
              children: (0, oO.jsxs)(bK.I, {
                className: "ApprovalInfoPopupActionButton",
                onClick: () => {
                  yK(!1)
                },
                disabled: TO,
                children: [(0, oO.jsx)(DO.d, {
                  name: "xmark"
                }), " Manually Deny"]
              })
            }), null !== zK.manualOverride && (0, oO.jsx)(hO.g, {
              tooltipInner: (0, oO.jsx)("div", {
                children: "Remove the manual override and revert the game to the auto-approval criteria."
              }),
              children: (0, oO.jsxs)(bK.d, {
                className: "ApprovalInfoPopupActionButton",
                onClick: () => {
                  yK(null)
                },
                disabled: TO,
                children: [(0, oO.jsx)(DO.d, {
                  name: "arrows-rotate"
                }), " Clear Override"]
              })
            })]
          })]
        })]
      })
    }
  },
  7970: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(1165),
      bK = pO(1077),
      eO = pO(533);

    function lO(OO) {
      return OO = function(OO, KO) {
        var pO;
        const XO = new URLSearchParams(KO),
          bK = XO.get("lobby"),
          eO = XO.get("vm"),
          lO = null !== (pO = bK) && void 0 !== pO ? pO : OO.lobbyName,
          vK = null !== eO && void 0 !== eO ? eO : OO.directJoinVmUrl;
        if (lO === OO.lobbyName && vK === OO.directJoinVmUrl) return OO;
        return {
          ...OO,
          lobbyName: lO,
          directJoinVmUrl: vK
        }
      }(OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ""), OO = function(OO) {
        if ((0, eO.I)(OO.directJoinVmUrl)) return OO;
        const KO = (0, bK.Y)(OO.directJoinVmUrl);
        null === KO && (OO.directJoinVmUrl = void 0);
        return OO
      }(OO = function(OO) {
        if ((0, eO.I)(OO.gameNameWithVariation)) return OO;
        return OO.gameNameWithVariation = (0, XO.k)(OO.gameNameWithVariation), OO
      }(OO))
    }
  },
  34952: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      f: () => XO
    });
    const XO = "skyblockSkills",
      bK = "skills_test_gym"
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);