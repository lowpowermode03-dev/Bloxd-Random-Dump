export const id = 215;
export const ids = [215];
export const modules = {
  35688: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => MO,
      g: () => aK,
      h: () => VO,
      j: () => oO
    });
    var XO = pO(35641),
      bK = pO(35639),
      eO = pO(35664),
      lO = pO(35676);

    function vK(OO) {
      return Math.pow(OO, bK.e)
    }

    function CO(OO) {
      return OO <= .04045 ? .0773993808 * OO : Math.pow(.947867299 * (OO + .055), 2.4)
    }

    function hO(OO) {
      return Math.pow(OO, bK.d)
    }

    function DO(OO) {
      return OO <= .0031308 ? 12.92 * OO : 1.055 * Math.pow(OO, .41666) - .055
    }
    class MO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        this.r = OO, this.g = KO, this.b = pO
      }
      toString() {
        return "{R: " + this.r + " G:" + this.g + " B:" + this.b + "}"
      }
      getClassName() {
        return "Color3"
      }
      getHashCode() {
        let OO = 255 * this.r | 0;
        return OO = 397 * OO ^ 255 * this.g, OO = 397 * OO ^ 255 * this.b, OO
      }
      toArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return OO[KO] = this.r, OO[KO + 1] = this.g, OO[KO + 2] = this.b, this
      }
      BCO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return MO.FromArrayToRef(OO, KO, this), this
      }
      toColor4() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
        return new aK(this.r, this.g, this.b, OO)
      }
      WhO() {
        return [this.r, this.g, this.b]
      }
      toLuminance() {
        return .3 * this.r + .59 * this.g + .11 * this.b
      }
      multiply(OO) {
        return new MO(this.r * OO.r, this.g * OO.g, this.b * OO.b)
      }
      multiplyToRef(OO, KO) {
        return KO.r = this.r * OO.r, KO.g = this.g * OO.g, KO.b = this.b * OO.b, KO
      }
      multiplyInPlace(OO) {
        return this.r *= OO.r, this.g *= OO.g, this.b *= OO.b, this
      }
      multiplyByFloats(OO, KO, pO) {
        return new MO(this.r * OO, this.g * KO, this.b * pO)
      }
      divide(OO) {
        throw new ReferenceError("Can not divide a color")
      }
      divideToRef(OO, KO) {
        throw new ReferenceError("Can not divide a color")
      }
      divideInPlace(OO) {
        throw new ReferenceError("Can not divide a color")
      }
      minimizeInPlace(OO) {
        return this.minimizeInPlaceFromFloats(OO.r, OO.g, OO.b)
      }
      maximizeInPlace(OO) {
        return this.maximizeInPlaceFromFloats(OO.r, OO.g, OO.b)
      }
      minimizeInPlaceFromFloats(OO, KO, pO) {
        return this.r = Math.min(OO, this.r), this.g = Math.min(KO, this.g), this.b = Math.min(pO, this.b), this
      }
      maximizeInPlaceFromFloats(OO, KO, pO) {
        return this.r = Math.max(OO, this.r), this.g = Math.max(KO, this.g), this.b = Math.max(pO, this.b), this
      }
      floorToRef(OO) {
        throw new ReferenceError("Can not floor a color")
      }
      floor() {
        throw new ReferenceError("Can not floor a color")
      }
      fractToRef(OO) {
        throw new ReferenceError("Can not fract a color")
      }
      fract() {
        throw new ReferenceError("Can not fract a color")
      }
      equals(OO) {
        return OO && this.r === OO.r && this.g === OO.g && this.b === OO.b
      }
      equalsFloats(OO, KO, pO) {
        return this.soO(OO, KO, pO)
      }
      soO(OO, KO, pO) {
        return this.r === OO && this.g === KO && this.b === pO
      }
      equalsWithEpsilon(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : bK.c;
        return (0, eO.WithinEpsilon)(this.r, OO.r, KO) && (0, eO.WithinEpsilon)(this.g, OO.g, KO) && (0, eO.WithinEpsilon)(this.b, OO.b, KO)
      }
      hl() {
        throw new ReferenceError("Can not negate a color")
      }
      negateInPlace() {
        throw new ReferenceError("Can not negate a color")
      }
      negateToRef(OO) {
        throw new ReferenceError("Can not negate a color")
      }
      scale(OO) {
        return new MO(this.r * OO, this.g * OO, this.b * OO)
      }
      scaleInPlace(OO) {
        return this.r *= OO, this.g *= OO, this.b *= OO, this
      }
      scaleToRef(OO, KO) {
        return KO.r = this.r * OO, KO.g = this.g * OO, KO.b = this.b * OO, KO
      }
      scaleAndAddToRef(OO, KO) {
        return KO.r += this.r * OO, KO.g += this.g * OO, KO.b += this.b * OO, KO
      }
      clampToRef() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        return pO.r = (0, eO.Clamp)(this.r, OO, KO), pO.g = (0, eO.Clamp)(this.g, OO, KO), pO.b = (0, eO.Clamp)(this.b, OO, KO), pO
      }
      add(OO) {
        return new MO(this.r + OO.r, this.g + OO.g, this.b + OO.b)
      }
      addInPlace(OO) {
        return this.r += OO.r, this.g += OO.g, this.b += OO.b, this
      }
      addInPlaceFromFloats(OO, KO, pO) {
        return this.r += OO, this.g += KO, this.b += pO, this
      }
      addToRef(OO, KO) {
        return KO.r = this.r + OO.r, KO.g = this.g + OO.g, KO.b = this.b + OO.b, KO
      }
      subtract(OO) {
        return new MO(this.r - OO.r, this.g - OO.g, this.b - OO.b)
      }
      subtractToRef(OO, KO) {
        return KO.r = this.r - OO.r, KO.g = this.g - OO.g, KO.b = this.b - OO.b, KO
      }
      oDO(OO) {
        return this.r -= OO.r, this.g -= OO.g, this.b -= OO.b, this
      }
      subtractFromFloats(OO, KO, pO) {
        return new MO(this.r - OO, this.g - KO, this.b - pO)
      }
      subtractFromFloatsToRef(OO, KO, pO, XO) {
        return XO.r = this.r - OO, XO.g = this.g - KO, XO.b = this.b - pO, XO
      }
      clone() {
        return new MO(this.r, this.g, this.b)
      }
      NhO(OO) {
        return this.r = OO.r, this.g = OO.g, this.b = OO.b, this
      }
      rvO(OO, KO, pO) {
        return this.r = OO, this.g = KO, this.b = pO, this
      }
      set(OO, KO, pO) {
        return this.rvO(OO, KO, pO)
      }
      plO(OO) {
        return this.r = this.g = this.b = OO, this
      }
      toHexString() {
        const OO = Math.round(255 * this.r),
          KO = Math.round(255 * this.g),
          pO = Math.round(255 * this.b);
        return "#" + (0, eO.ToHex)(OO) + (0, eO.ToHex)(KO) + (0, eO.ToHex)(pO)
      }
      fromHexString(OO) {
        return "#" !== OO.substring(0, 1) || 7 !== OO.length || (this.r = parseInt(OO.substring(1, 3), 16) / 255, this.g = parseInt(OO.substring(3, 5), 16) / 255, this.b = parseInt(OO.substring(5, 7), 16) / 255), this
      }
      toHSV() {
        return this.toHSVToRef(new MO)
      }
      toHSVToRef(OO) {
        const KO = this.r,
          pO = this.g,
          XO = this.b,
          bK = Math.max(KO, pO, XO),
          eO = Math.min(KO, pO, XO);
        let lO = 0,
          vK = 0;
        const CO = bK,
          hO = bK - eO;
        return 0 !== bK && (vK = hO / bK), bK != eO && (bK == KO ? (lO = (pO - XO) / hO, pO < XO && (lO += 6)) : bK == pO ? lO = (XO - KO) / hO + 2 : bK == XO && (lO = (KO - pO) / hO + 4), lO *= 60), OO.r = lO, OO.g = vK, OO.b = CO, OO
      }
      toLinearSpace() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = new MO;
        return this.toLinearSpaceToRef(KO, OO), KO
      }
      toLinearSpaceToRef(OO) {
        return arguments.length > 1 && void 0 !== arguments[1] && arguments[1] ? (OO.r = CO(this.r), OO.g = CO(this.g), OO.b = CO(this.b)) : (OO.r = vK(this.r), OO.g = vK(this.g), OO.b = vK(this.b)), this
      }
      toGammaSpace() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = new MO;
        return this.toGammaSpaceToRef(KO, OO), KO
      }
      toGammaSpaceToRef(OO) {
        return arguments.length > 1 && void 0 !== arguments[1] && arguments[1] ? (OO.r = DO(this.r), OO.g = DO(this.g), OO.b = DO(this.b)) : (OO.r = hO(this.r), OO.g = hO(this.g), OO.b = hO(this.b)), this
      }
      static HSVtoRGBToRef(OO, KO, pO, XO) {
        const bK = pO * KO,
          eO = OO / 60,
          lO = bK * (1 - Math.abs(eO % 2 - 1));
        let vK = 0,
          CO = 0,
          hO = 0;
        eO >= 0 && eO <= 1 ? (vK = bK, CO = lO) : eO >= 1 && eO <= 2 ? (vK = lO, CO = bK) : eO >= 2 && eO <= 3 ? (CO = bK, hO = lO) : eO >= 3 && eO <= 4 ? (CO = lO, hO = bK) : eO >= 4 && eO <= 5 ? (vK = lO, hO = bK) : eO >= 5 && eO <= 6 && (vK = bK, hO = lO);
        const DO = pO - bK;
        return XO.r = vK + DO, XO.g = CO + DO, XO.b = hO + DO, XO
      }
      static FromHSV(OO, KO, pO) {
        const XO = new MO(0, 0, 0);
        return MO.HSVtoRGBToRef(OO, KO, pO, XO), XO
      }
      static FromHexString(OO) {
        return new MO(0, 0, 0).fromHexString(OO)
      }
      static FromArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return new MO(OO[KO], OO[KO + 1], OO[KO + 2])
      }
      static FromArrayToRef(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        pO.r = OO[KO], pO.g = OO[KO + 1], pO.b = OO[KO + 2]
      }
      static FromInts(OO, KO, pO) {
        return new MO(OO / 255, KO / 255, pO / 255)
      }
      static Lerp(OO, KO, pO) {
        const XO = new MO(0, 0, 0);
        return MO.LerpToRef(OO, KO, pO, XO), XO
      }
      static LerpToRef(OO, KO, pO, XO) {
        XO.r = OO.r + (KO.r - OO.r) * pO, XO.g = OO.g + (KO.g - OO.g) * pO, XO.b = OO.b + (KO.b - OO.b) * pO
      }
      static Hermite(OO, KO, pO, XO, bK) {
        const eO = bK * bK,
          lO = bK * eO,
          vK = 2 * lO - 3 * eO + 1,
          CO = -2 * lO + 3 * eO,
          hO = lO - 2 * eO + bK,
          DO = lO - eO,
          aK = OO.r * vK + pO.r * CO + KO.r * hO + XO.r * DO,
          oO = OO.g * vK + pO.g * CO + KO.g * hO + XO.g * DO,
          FO = OO.b * vK + pO.b * CO + KO.b * hO + XO.b * DO;
        return new MO(aK, oO, FO)
      }
      static Hermite1stDerivative(OO, KO, pO, XO, bK) {
        const eO = MO.Black();
        return this.Hermite1stDerivativeToRef(OO, KO, pO, XO, bK, eO), eO
      }
      static Hermite1stDerivativeToRef(OO, KO, pO, XO, bK, eO) {
        const lO = bK * bK;
        eO.r = 6 * (lO - bK) * OO.r + (3 * lO - 4 * bK + 1) * KO.r + 6 * (-lO + bK) * pO.r + (3 * lO - 2 * bK) * XO.r, eO.g = 6 * (lO - bK) * OO.g + (3 * lO - 4 * bK + 1) * KO.g + 6 * (-lO + bK) * pO.g + (3 * lO - 2 * bK) * XO.g, eO.b = 6 * (lO - bK) * OO.b + (3 * lO - 4 * bK + 1) * KO.b + 6 * (-lO + bK) * pO.b + (3 * lO - 2 * bK) * XO.b
      }
      static Red() {
        return new MO(1, 0, 0)
      }
      static Green() {
        return new MO(0, 1, 0)
      }
      static Blue() {
        return new MO(0, 0, 1)
      }
      static Black() {
        return new MO(0, 0, 0)
      }
      static get BlackReadOnly() {
        return MO._BlackReadOnly
      }
      static White() {
        return new MO(1, 1, 1)
      }
      static Purple() {
        return new MO(.5, 0, .5)
      }
      static Magenta() {
        return new MO(1, 0, 1)
      }
      static Yellow() {
        return new MO(1, 1, 0)
      }
      static Gray() {
        return new MO(.5, .5, .5)
      }
      static Teal() {
        return new MO(0, 1, 1)
      }
      static Random() {
        return new MO(Math.random(), Math.random(), Math.random())
      }
    }
    MO._V8PerformanceHack = new MO(.5, .5, .5), MO._BlackReadOnly = MO.Black();
    class aK {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1;
        this.r = OO, this.g = KO, this.b = pO, this.a = XO
      }
      WhO() {
        return [this.r, this.g, this.b, this.a]
      }
      toArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return OO[KO] = this.r, OO[KO + 1] = this.g, OO[KO + 2] = this.b, OO[KO + 3] = this.a, this
      }
      BCO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return this.r = OO[KO], this.g = OO[KO + 1], this.b = OO[KO + 2], this.a = OO[KO + 3], this
      }
      equals(OO) {
        return OO && this.r === OO.r && this.g === OO.g && this.b === OO.b && this.a === OO.a
      }
      add(OO) {
        return new aK(this.r + OO.r, this.g + OO.g, this.b + OO.b, this.a + OO.a)
      }
      addToRef(OO, KO) {
        return KO.r = this.r + OO.r, KO.g = this.g + OO.g, KO.b = this.b + OO.b, KO.a = this.a + OO.a, KO
      }
      addInPlace(OO) {
        return this.r += OO.r, this.g += OO.g, this.b += OO.b, this.a += OO.a, this
      }
      addInPlaceFromFloats(OO, KO, pO, XO) {
        return this.r += OO, this.g += KO, this.b += pO, this.a += XO, this
      }
      subtract(OO) {
        return new aK(this.r - OO.r, this.g - OO.g, this.b - OO.b, this.a - OO.a)
      }
      subtractToRef(OO, KO) {
        return KO.r = this.r - OO.r, KO.g = this.g - OO.g, KO.b = this.b - OO.b, KO.a = this.a - OO.a, KO
      }
      oDO(OO) {
        return this.r -= OO.r, this.g -= OO.g, this.b -= OO.b, this.a -= OO.a, this
      }
      subtractFromFloats(OO, KO, pO, XO) {
        return new aK(this.r - OO, this.g - KO, this.b - pO, this.a - XO)
      }
      subtractFromFloatsToRef(OO, KO, pO, XO, bK) {
        return bK.r = this.r - OO, bK.g = this.g - KO, bK.b = this.b - pO, bK.a = this.a - XO, bK
      }
      scale(OO) {
        return new aK(this.r * OO, this.g * OO, this.b * OO, this.a * OO)
      }
      scaleInPlace(OO) {
        return this.r *= OO, this.g *= OO, this.b *= OO, this.a *= OO, this
      }
      scaleToRef(OO, KO) {
        return KO.r = this.r * OO, KO.g = this.g * OO, KO.b = this.b * OO, KO.a = this.a * OO, KO
      }
      scaleAndAddToRef(OO, KO) {
        return KO.r += this.r * OO, KO.g += this.g * OO, KO.b += this.b * OO, KO.a += this.a * OO, KO
      }
      clampToRef() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        return pO.r = (0, eO.Clamp)(this.r, OO, KO), pO.g = (0, eO.Clamp)(this.g, OO, KO), pO.b = (0, eO.Clamp)(this.b, OO, KO), pO.a = (0, eO.Clamp)(this.a, OO, KO), pO
      }
      multiply(OO) {
        return new aK(this.r * OO.r, this.g * OO.g, this.b * OO.b, this.a * OO.a)
      }
      multiplyToRef(OO, KO) {
        return KO.r = this.r * OO.r, KO.g = this.g * OO.g, KO.b = this.b * OO.b, KO.a = this.a * OO.a, KO
      }
      multiplyInPlace(OO) {
        return this.r *= OO.r, this.g *= OO.g, this.b *= OO.b, this.a *= OO.a, this
      }
      multiplyByFloats(OO, KO, pO, XO) {
        return new aK(this.r * OO, this.g * KO, this.b * pO, this.a * XO)
      }
      divide(OO) {
        throw new ReferenceError("Can not divide a color")
      }
      divideToRef(OO, KO) {
        throw new ReferenceError("Can not divide a color")
      }
      divideInPlace(OO) {
        throw new ReferenceError("Can not divide a color")
      }
      minimizeInPlace(OO) {
        return this.r = Math.min(this.r, OO.r), this.g = Math.min(this.g, OO.g), this.b = Math.min(this.b, OO.b), this.a = Math.min(this.a, OO.a), this
      }
      maximizeInPlace(OO) {
        return this.r = Math.max(this.r, OO.r), this.g = Math.max(this.g, OO.g), this.b = Math.max(this.b, OO.b), this.a = Math.max(this.a, OO.a), this
      }
      minimizeInPlaceFromFloats(OO, KO, pO, XO) {
        return this.r = Math.min(OO, this.r), this.g = Math.min(KO, this.g), this.b = Math.min(pO, this.b), this.a = Math.min(XO, this.a), this
      }
      maximizeInPlaceFromFloats(OO, KO, pO, XO) {
        return this.r = Math.max(OO, this.r), this.g = Math.max(KO, this.g), this.b = Math.max(pO, this.b), this.a = Math.max(XO, this.a), this
      }
      floorToRef(OO) {
        throw new ReferenceError("Can not floor a color")
      }
      floor() {
        throw new ReferenceError("Can not floor a color")
      }
      fractToRef(OO) {
        throw new ReferenceError("Can not fract a color")
      }
      fract() {
        throw new ReferenceError("Can not fract a color")
      }
      hl() {
        throw new ReferenceError("Can not negate a color")
      }
      negateInPlace() {
        throw new ReferenceError("Can not negate a color")
      }
      negateToRef(OO) {
        throw new ReferenceError("Can not negate a color")
      }
      equalsWithEpsilon(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : bK.c;
        return (0, eO.WithinEpsilon)(this.r, OO.r, KO) && (0, eO.WithinEpsilon)(this.g, OO.g, KO) && (0, eO.WithinEpsilon)(this.b, OO.b, KO) && (0, eO.WithinEpsilon)(this.a, OO.a, KO)
      }
      soO(OO, KO, pO, XO) {
        return this.r === OO && this.g === KO && this.b === pO && this.a === XO
      }
      toString() {
        return "{R: " + this.r + " G:" + this.g + " B:" + this.b + " A:" + this.a + "}"
      }
      getClassName() {
        return "Color4"
      }
      getHashCode() {
        let OO = 255 * this.r | 0;
        return OO = 397 * OO ^ 255 * this.g, OO = 397 * OO ^ 255 * this.b, OO = 397 * OO ^ 255 * this.a, OO
      }
      clone() {
        return (new aK).NhO(this)
      }
      NhO(OO) {
        return this.r = OO.r, this.g = OO.g, this.b = OO.b, this.a = OO.a, this
      }
      rvO(OO, KO, pO, XO) {
        return this.r = OO, this.g = KO, this.b = pO, this.a = XO, this
      }
      set(OO, KO, pO, XO) {
        return this.rvO(OO, KO, pO, XO)
      }
      plO(OO) {
        return this.r = this.g = this.b = this.a = OO, this
      }
      toHexString() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = Math.round(255 * this.r),
          pO = Math.round(255 * this.g),
          XO = Math.round(255 * this.b);
        if (OO) return "#" + (0, eO.ToHex)(KO) + (0, eO.ToHex)(pO) + (0, eO.ToHex)(XO);
        const bK = Math.round(255 * this.a);
        return "#" + (0, eO.ToHex)(KO) + (0, eO.ToHex)(pO) + (0, eO.ToHex)(XO) + (0, eO.ToHex)(bK)
      }
      fromHexString(OO) {
        return "#" !== OO.substring(0, 1) || 9 !== OO.length && 7 !== OO.length || (this.r = parseInt(OO.substring(1, 3), 16) / 255, this.g = parseInt(OO.substring(3, 5), 16) / 255, this.b = parseInt(OO.substring(5, 7), 16) / 255, 9 === OO.length && (this.a = parseInt(OO.substring(7, 9), 16) / 255)), this
      }
      toLinearSpace() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = new aK;
        return this.toLinearSpaceToRef(KO, OO), KO
      }
      toLinearSpaceToRef(OO) {
        return arguments.length > 1 && void 0 !== arguments[1] && arguments[1] ? (OO.r = CO(this.r), OO.g = CO(this.g), OO.b = CO(this.b)) : (OO.r = vK(this.r), OO.g = vK(this.g), OO.b = vK(this.b)), OO.a = this.a, this
      }
      toGammaSpace() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = new aK;
        return this.toGammaSpaceToRef(KO, OO), KO
      }
      toGammaSpaceToRef(OO) {
        return arguments.length > 1 && void 0 !== arguments[1] && arguments[1] ? (OO.r = DO(this.r), OO.g = DO(this.g), OO.b = DO(this.b)) : (OO.r = hO(this.r), OO.g = hO(this.g), OO.b = hO(this.b)), OO.a = this.a, this
      }
      static FromHexString(OO) {
        return "#" !== OO.substring(0, 1) || 9 !== OO.length && 7 !== OO.length ? new aK(0, 0, 0, 0) : new aK(0, 0, 0, 1).fromHexString(OO)
      }
      static Lerp(OO, KO, pO) {
        return aK.LerpToRef(OO, KO, pO, new aK)
      }
      static LerpToRef(OO, KO, pO, XO) {
        return XO.r = OO.r + (KO.r - OO.r) * pO, XO.g = OO.g + (KO.g - OO.g) * pO, XO.b = OO.b + (KO.b - OO.b) * pO, XO.a = OO.a + (KO.a - OO.a) * pO, XO
      }
      static Hermite(OO, KO, pO, XO, bK) {
        const eO = bK * bK,
          lO = bK * eO,
          vK = 2 * lO - 3 * eO + 1,
          CO = -2 * lO + 3 * eO,
          hO = lO - 2 * eO + bK,
          DO = lO - eO,
          MO = OO.r * vK + pO.r * CO + KO.r * hO + XO.r * DO,
          oO = OO.g * vK + pO.g * CO + KO.g * hO + XO.g * DO,
          FO = OO.b * vK + pO.b * CO + KO.b * hO + XO.b * DO,
          VO = OO.a * vK + pO.a * CO + KO.a * hO + XO.a * DO;
        return new aK(MO, oO, FO, VO)
      }
      static Hermite1stDerivative(OO, KO, pO, XO, bK) {
        const eO = new aK;
        return this.Hermite1stDerivativeToRef(OO, KO, pO, XO, bK, eO), eO
      }
      static Hermite1stDerivativeToRef(OO, KO, pO, XO, bK, eO) {
        const lO = bK * bK;
        eO.r = 6 * (lO - bK) * OO.r + (3 * lO - 4 * bK + 1) * KO.r + 6 * (-lO + bK) * pO.r + (3 * lO - 2 * bK) * XO.r, eO.g = 6 * (lO - bK) * OO.g + (3 * lO - 4 * bK + 1) * KO.g + 6 * (-lO + bK) * pO.g + (3 * lO - 2 * bK) * XO.g, eO.b = 6 * (lO - bK) * OO.b + (3 * lO - 4 * bK + 1) * KO.b + 6 * (-lO + bK) * pO.b + (3 * lO - 2 * bK) * XO.b, eO.a = 6 * (lO - bK) * OO.a + (3 * lO - 4 * bK + 1) * KO.a + 6 * (-lO + bK) * pO.a + (3 * lO - 2 * bK) * XO.a
      }
      static FromColor3(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        return new aK(OO.r, OO.g, OO.b, KO)
      }
      static FromArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return new aK(OO[KO], OO[KO + 1], OO[KO + 2], OO[KO + 3])
      }
      static FromArrayToRef(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        pO.r = OO[KO], pO.g = OO[KO + 1], pO.b = OO[KO + 2], pO.a = OO[KO + 3]
      }
      static FromInts(OO, KO, pO, XO) {
        return new aK(OO / 255, KO / 255, pO / 255, XO / 255)
      }
      static CheckColors4(OO, KO) {
        if (OO.length === 3 * KO) {
          const KO = [];
          for (let pO = 0; pO < OO.length; pO += 3) {
            const XO = pO / 3 * 4;
            KO[XO] = OO[pO], KO[XO + 1] = OO[pO + 1], KO[XO + 2] = OO[pO + 2], KO[XO + 3] = 1
          }
          return KO
        }
        return OO
      }
    }
    aK._V8PerformanceHack = new aK(.5, .5, .5, .5);
    class oO {}
    oO.Color3 = (0, XO.d)(3, MO.Black), oO.Color4 = (0, XO.d)(3, (() => new aK(0, 0, 0, 0)));
    let FO = !1;

    function VO() {
      FO || (FO = !0, Object.defineProperties(MO.prototype, {
        dimension: {
          value: [3]
        },
        rank: {
          value: 1
        }
      }), Object.defineProperties(aK.prototype, {
        dimension: {
          value: [4]
        },
        rank: {
          value: 1
        }
      }), (0, lO.h)("BABYLON.Color3", MO), (0, lO.h)("BABYLON.Color4", aK))
    }
  },
  35639: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      d: () => XO,
      e: () => bK
    });
    const XO = 1 / 2.2,
      bK = 2.2;
    Math.sqrt(5);
    let eO = .001
  },
  35664: (OO, KO, pO) => {
    function XO(OO) {
      return parseInt(OO.toString().replace(/\W/g, ""))
    }

    function bK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1401298e-51;
      return Math.abs(OO - KO) <= pO
    }

    function eO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1401298e-51;
      return OO < KO - XO || OO > pO + XO
    }

    function lO(OO, KO) {
      return OO === KO ? OO : Math.random() * (KO - OO) + OO
    }

    function vK(OO, KO, pO) {
      return OO + (KO - OO) * pO
    }

    function CO(OO, KO, pO) {
      let XO = LO(KO - OO, 360);
      return XO > 180 && (XO -= 360), OO + XO * aK(pO)
    }

    function hO(OO, KO, pO) {
      let XO;
      return XO = OO != KO ? aK((pO - OO) / (KO - OO)) : 0, XO
    }

    function DO(OO, KO, pO, XO, bK) {
      const eO = bK * bK,
        lO = bK * eO;
      return OO * (2 * lO - 3 * eO + 1) + pO * (-2 * lO + 3 * eO) + KO * (lO - 2 * eO + bK) + XO * (lO - eO)
    }

    function MO(OO, KO, pO, XO, bK) {
      const eO = bK * bK;
      return 6 * (eO - bK) * OO + (3 * eO - 4 * bK + 1) * KO + 6 * (-eO + bK) * pO + (3 * eO - 2 * bK) * XO
    }

    function aK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
      return Math.min(pO, Math.max(KO, OO))
    }

    function oO(OO) {
      return OO -= 2 * Math.PI * Math.floor((OO + Math.PI) / (2 * Math.PI))
    }

    function FO(OO) {
      const KO = OO.toString(16);
      return OO <= 15 ? ("0" + KO).toUpperCase() : KO.toUpperCase()
    }

    function VO(OO) {
      if (Math.log2) return Math.floor(Math.log2(OO));
      if (OO < 0) return NaN;
      if (0 === OO) return -1 / 0;
      let KO = 0;
      if (OO < 1) {
        for (; OO < 1;) KO++, OO *= 2;
        KO = -KO
      } else if (OO > 1)
        for (; OO > 1;) KO++, OO = Math.floor(OO / 2);
      return KO
    }

    function LO(OO, KO) {
      return OO - Math.floor(OO / KO) * KO
    }

    function QO(OO, KO, pO) {
      return (OO - KO) / (pO - KO)
    }

    function zK(OO, KO, pO) {
      return OO * (pO - KO) + KO
    }

    function AO(OO, KO) {
      let pO = LO(KO - OO, 360);
      return pO > 180 && (pO -= 360), pO
    }

    function fO(OO, KO) {
      const pO = LO(OO, 2 * KO);
      return KO - Math.abs(pO - KO)
    }

    function dO(OO, KO, pO) {
      let XO = aK(pO);
      return XO = -2 * XO * XO * XO + 3 * XO * XO, KO * XO + OO * (1 - XO)
    }

    function TO(OO, KO, pO) {
      let XO;
      return XO = Math.abs(KO - OO) <= pO ? KO : OO + Math.sign(KO - OO) * pO, XO
    }

    function NO(OO, KO, pO) {
      const XO = AO(OO, KO);
      let bK;
      return bK = -pO < XO && XO < pO ? KO : TO(OO, KO = OO + XO, pO), bK
    }

    function IO(OO, KO, pO) {
      return (OO - KO) / (pO - KO)
    }

    function yK(OO, KO, pO) {
      return (pO - KO) * OO + KO
    }

    function gK(OO, KO) {
      const pO = OO % KO;
      return 0 === pO ? KO : gK(KO, pO)
    }
    pO.r(KO), pO.d(KO, {
      Clamp: () => aK,
      DeltaAngle: () => AO,
      Denormalize: () => zK,
      ExtractAsInt: () => XO,
      Hermite: () => DO,
      Hermite1stDerivative: () => MO,
      HighestCommonFactor: () => gK,
      ILog2: () => VO,
      InverseLerp: () => hO,
      Lerp: () => vK,
      LerpAngle: () => CO,
      MoveTowards: () => TO,
      MoveTowardsAngle: () => NO,
      Normalize: () => QO,
      NormalizeRadians: () => oO,
      OutsideRange: () => eO,
      PercentToRange: () => yK,
      PingPong: () => fO,
      RandomRange: () => lO,
      RangeToPercent: () => IO,
      Repeat: () => LO,
      SmoothStep: () => dO,
      ToHex: () => FO,
      WithinEpsilon: () => bK
    })
  },
  35641: (OO, KO, pO) => {
    function XO(OO, KO) {
      const pO = [];
      for (let XO = 0; XO < OO; ++XO) pO.push(KO());
      return pO
    }

    function bK(OO, KO) {
      return XO(OO, KO)
    }
    pO.d(KO, {
      d: () => XO,
      f: () => bK,
      g: () => lO
    });
    const eO = ["push", "splice", "pop", "shift", "unshift"];

    function lO(OO, KO) {
      const pO = eO.map((pO => function(OO, KO, pO) {
        const XO = OO[KO];
        if ("function" !== typeof XO) return null;
        const bK = function() {
          const XO = OO.length,
            eO = bK.previous.apply(OO, arguments);
          return pO(KO, XO), eO
        };
        return XO.next = bK, bK.previous = XO, OO[KO] = bK, () => {
          const pO = bK.previous;
          if (!pO) return;
          const XO = bK.next;
          XO ? (pO.next = XO, XO.previous = pO) : (pO.next = void 0, OO[KO] = pO), bK.next = void 0, bK.previous = void 0
        }
      }(OO, pO, KO)));
      return () => {
        for (const OO of pO) OO?.()
      }
    }
  },
  35676: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      h: () => bK
    });
    const XO = {};

    function bK(OO, KO) {
      XO[OO] = KO
    }

    function eO(OO) {
      return XO[OO]
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);