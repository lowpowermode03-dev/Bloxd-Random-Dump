export const id = 95;
export const ids = [95];
export const modules = {
  4126: (OO, KO, pO) => {
    function XO(OO) {
      return XO = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(OO) {
        return typeof OO
      } : function(OO) {
        return OO && "function" == typeof Symbol && OO.constructor === Symbol && OO !== Symbol.prototype ? "symbol" : typeof OO
      }, XO(OO)
    }
    Object.defineProperty(KO, "__esModule", {
      value: !0
    }), KO.default = void 0;
    var bK = MO(pO(918)),
      eO = function(OO, KO) {
        if (!KO && OO && OO.__esModule) return OO;
        if (null === OO || "object" !== XO(OO) && "function" !== typeof OO) return {
          default: OO
        };
        var pO = DO(KO);
        if (pO && pO.has(OO)) return pO.get(OO);
        var bK = {},
          eO = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var lO in OO)
          if ("default" !== lO && Object.prototype.hasOwnProperty.call(OO, lO)) {
            var vK = eO ? Object.getOwnPropertyDescriptor(OO, lO) : null;
            vK && (vK.get || vK.set) ? Object.defineProperty(bK, lO, vK) : bK[lO] = OO[lO]
          } bK.default = OO, pO && pO.set(OO, bK);
        return bK
      }(pO(63)),
      lO = MO(pO(4087)),
      vK = MO(pO(4133)),
      CO = pO(4140),
      hO = pO(976);

    function DO(OO) {
      if ("function" !== typeof WeakMap) return null;
      var KO = new WeakMap,
        pO = new WeakMap;
      return (DO = function(OO) {
        return OO ? pO : KO
      })(OO)
    }

    function MO(OO) {
      return OO && OO.__esModule ? OO : {
        default: OO
      }
    }

    function aK(OO, KO) {
      var pO = "undefined" !== typeof Symbol && OO[Symbol.iterator] || OO["@@iterator"];
      if (!pO) {
        if (Array.isArray(OO) || (pO = function(OO, KO) {
            if (!OO) return;
            if ("string" === typeof OO) return oO(OO, KO);
            var pO = Object.prototype.toString.call(OO).slice(8, -1);
            "Object" === pO && OO.constructor && (pO = OO.constructor.name);
            if ("Map" === pO || "Set" === pO) return Array.from(OO);
            if ("Arguments" === pO || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(pO)) return oO(OO, KO)
          }(OO)) || KO && OO && "number" === typeof OO.length) {
          pO && (OO = pO);
          var XO = 0,
            bK = function() {};
          return {
            s: bK,
            n: function() {
              return XO >= OO.length ? {
                done: !0
              } : {
                done: !1,
                value: OO[XO++]
              }
            },
            e: function(OO) {
              throw OO
            },
            f: bK
          }
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
      }
      var eO, lO = !0,
        vK = !1;
      return {
        s: function() {
          pO = pO.call(OO)
        },
        n: function() {
          var OO = pO.next();
          return lO = OO.done, OO
        },
        e: function(OO) {
          vK = !0, eO = OO
        },
        f: function() {
          try {
            lO || null == pO.return || pO.return()
          } finally {
            if (vK) throw eO
          }
        }
      }
    }

    function oO(OO, KO) {
      (null == KO || KO > OO.length) && (KO = OO.length);
      for (var pO = 0, XO = new Array(KO); pO < KO; pO++) XO[pO] = OO[pO];
      return XO
    }

    function FO(OO, KO) {
      for (var pO = 0; pO < KO.length; pO++) {
        var XO = KO[pO];
        XO.enumerable = XO.enumerable || !1, XO.configurable = !0, "value" in XO && (XO.writable = !0), Object.defineProperty(OO, XO.key, XO)
      }
    }

    function VO(OO, KO) {
      return VO = Object.setPrototypeOf || function(OO, KO) {
        return OO.__proto__ = KO, OO
      }, VO(OO, KO)
    }

    function LO(OO) {
      var KO = function() {
        if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" === typeof Proxy) return !0;
        try {
          return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
        } catch (OO) {
          return !1
        }
      }();
      return function() {
        var pO, bK = zK(OO);
        if (KO) {
          var eO = zK(this).constructor;
          pO = Reflect.construct(bK, arguments, eO)
        } else pO = bK.apply(this, arguments);
        return function(OO, KO) {
          if (KO && ("object" === XO(KO) || "function" === typeof KO)) return KO;
          if (void 0 !== KO) throw new TypeError("Derived constructors may only return object or undefined");
          return QO(OO)
        }(this, pO)
      }
    }

    function QO(OO) {
      if (void 0 === OO) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      return OO
    }

    function zK(OO) {
      return zK = Object.setPrototypeOf ? Object.getPrototypeOf : function(OO) {
        return OO.__proto__ || Object.getPrototypeOf(OO)
      }, zK(OO)
    }

    function AO(OO, KO, pO) {
      return KO in OO ? Object.defineProperty(OO, KO, {
        value: pO,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }) : OO[KO] = pO, OO
    }
    var fO = {
        orientation: {
          horizontal: {
            dimension: "width",
            direction: "left",
            reverseDirection: "right",
            coordinate: "x"
          },
          vertical: {
            dimension: "height",
            direction: "top",
            reverseDirection: "bottom",
            coordinate: "y"
          }
        }
      },
      dO = function(OO) {
        ! function(OO, KO) {
          if ("function" !== typeof KO && null !== KO) throw new TypeError("Super expression must either be null or a function");
          Object.defineProperty(OO, "prototype", {
            value: Object.create(KO && KO.prototype, {
              constructor: {
                value: OO,
                writable: !0,
                configurable: !0
              }
            }),
            writable: !1
          }), KO && VO(OO, KO)
        }(lO, OO);
        var KO, pO, XO, eO = LO(lO);

        function lO(OO, KO) {
          var pO;
          return function(OO, KO) {
            if (!(OO instanceof KO)) throw new TypeError("Cannot call a class as a function")
          }(this, lO), AO(QO(pO = eO.call(this, OO, KO)), "handleFormat", (function(OO) {
            var KO = pO.props.format;
            return KO ? KO(OO) : OO
          })), AO(QO(pO), "handleUpdate", (function() {
            if (pO.slider) {
              var OO = pO.props.orientation,
                KO = (0, CO.capitalize)(fO.orientation[OO].dimension),
                XO = pO.slider["offset".concat(KO)],
                bK = pO.handle["offset".concat(KO)];
              pO.setState({
                limit: XO - bK,
                grab: bK / 2
              })
            }
          })), AO(QO(pO), "handleStart", (function(OO) {
            var KO = pO.props.onChangeStart;
            document.addEventListener("mousemove", pO.handleDrag), document.addEventListener("mouseup", pO.handleEnd), pO.setState({
              active: !0
            }, (function() {
              KO && KO(OO)
            }))
          })), AO(QO(pO), "handleDrag", (function(OO) {
            OO.stopPropagation();
            var KO = pO.props.onChange,
              XO = OO.target,
              bK = XO.className,
              eO = XO.classList,
              lO = XO.dataset;
            if (KO && "rangeslider__labels" !== bK) {
              var vK = pO.position(OO);
              eO && eO.contains("rangeslider__label-item") && lO.value && (vK = parseFloat(lO.value)), KO && KO(vK, OO)
            }
          })), AO(QO(pO), "handleEnd", (function(OO) {
            var KO = pO.props.onChangeComplete;
            pO.setState({
              active: !1
            }, (function() {
              KO && KO(OO)
            })), document.removeEventListener("mousemove", pO.handleDrag), document.removeEventListener("mouseup", pO.handleEnd)
          })), AO(QO(pO), "handleKeyDown", (function(OO) {
            OO.preventDefault();
            var KO, XO = OO.keyCode,
              bK = pO.props,
              eO = bK.value,
              lO = bK.min,
              vK = bK.max,
              CO = bK.step,
              hO = bK.onChange;
            switch (XO) {
              case 38:
              case 39:
                KO = eO + CO > vK ? vK : eO + CO, hO && hO(KO, OO);
                break;
              case 37:
              case 40:
                KO = eO - CO < lO ? lO : eO - CO, hO && hO(KO, OO)
            }
          })), AO(QO(pO), "getPositionFromValue", (function(OO) {
            var KO = pO.state.limit,
              XO = pO.props,
              bK = XO.min,
              eO = (OO - bK) / (XO.max - bK);
            return Math.round(eO * KO)
          })), AO(QO(pO), "getValueFromPosition", (function(OO) {
            var KO = pO.state.limit,
              XO = pO.props,
              bK = XO.orientation,
              eO = XO.min,
              lO = XO.max,
              vK = XO.step,
              hO = (0, CO.clamp)(OO, 0, KO) / (KO || 1),
              DO = vK * Math.round(hO * (lO - eO) / vK),
              MO = "horizontal" === bK ? DO + eO : lO - DO;
            return (0, CO.clamp)(MO, eO, lO)
          })), AO(QO(pO), "position", (function(OO) {
            var KO = pO.state.grab,
              XO = pO.props,
              bK = XO.orientation,
              eO = XO.reverse,
              lO = pO.slider,
              vK = fO.orientation[bK].coordinate,
              hO = eO ? fO.orientation[bK].reverseDirection : fO.orientation[bK].direction,
              DO = "client".concat((0, CO.capitalize)(vK)),
              MO = OO.touches ? OO.touches[0][DO] : OO[DO],
              aK = lO.getBoundingClientRect()[hO],
              oO = eO ? aK - MO - KO : MO - aK - KO;
            return pO.getValueFromPosition(oO)
          })), AO(QO(pO), "coordinates", (function(OO) {
            var KO = pO.state,
              XO = KO.limit,
              bK = KO.grab,
              eO = pO.props.orientation,
              lO = pO.getValueFromPosition(OO),
              vK = pO.getPositionFromValue(lO),
              CO = "horizontal" === eO ? vK + bK : vK;
            return {
              fill: "horizontal" === eO ? CO : XO - CO,
              handle: CO,
              label: CO
            }
          })), AO(QO(pO), "renderLabels", (function(OO) {
            return (0, hO.jsx)("ul", {
              ref: function(OO) {
                pO.labels = OO
              },
              className: (0, bK.default)("rangeslider__labels"),
              children: OO
            })
          })), pO.state = {
            active: !1,
            limit: 0,
            grab: 0
          }, pO
        }
        return KO = lO, (pO = [{
          key: "componentDidMount",
          value: function() {
            this.handleUpdate(), new vK.default(this.handleUpdate).observe(this.slider)
          }
        }, {
          key: "render",
          value: function() {
            var OO = this,
              KO = this.props,
              pO = KO.value,
              XO = KO.orientation,
              eO = KO.className,
              lO = KO.tooltip,
              vK = KO.reverse,
              CO = KO.labels,
              DO = KO.min,
              MO = KO.max,
              oO = KO.handleLabel,
              FO = this.state.active,
              VO = fO.orientation[XO].dimension,
              LO = vK ? fO.orientation[XO].reverseDirection : fO.orientation[XO].direction,
              QO = this.getPositionFromValue(pO),
              zK = this.coordinates(QO),
              dO = AO({}, VO, "".concat(zK.fill, "px")),
              TO = AO({}, LO, "".concat(zK.handle, "px")),
              NO = lO && FO,
              IO = [],
              yK = Object.keys(CO);
            if (yK.length > 0) {
              var gK, uO = aK(yK = yK.sort((function(OO, KO) {
                return vK ? OO - KO : KO - OO
              })));
              try {
                for (uO.s(); !(gK = uO.n()).done;) {
                  var EO = gK.value,
                    jK = this.getPositionFromValue(EO),
                    YO = this.coordinates(jK),
                    wO = AO({}, LO, "".concat(YO.label, "px"));
                  IO.push((0, hO.jsx)("li", {
                    className: (0, bK.default)("rangeslider__label-item"),
                    "data-value": EO,
                    onMouseDown: this.handleDrag,
                    onTouchStart: this.handleStart,
                    onTouchEnd: this.handleEnd,
                    style: wO,
                    children: this.props.labels[EO]
                  }, EO))
                }
              } catch (iK) {
                uO.e(iK)
              } finally {
                uO.f()
              }
            }
            return (0, hO.jsxs)("div", {
              ref: function(KO) {
                OO.slider = KO
              },
              className: (0, bK.default)("rangeslider", "rangeslider-".concat(XO), {
                "rangeslider-reverse": vK
              }, eO),
              onMouseDown: this.handleDrag,
              onMouseUp: this.handleEnd,
              onTouchStart: this.handleStart,
              onTouchEnd: this.handleEnd,
              "aria-valuemin": DO,
              "aria-valuemax": MO,
              "aria-valuenow": pO,
              "aria-orientation": XO,
              children: [(0, hO.jsx)("div", {
                className: "rangeslider__fill",
                style: dO
              }), (0, hO.jsxs)("div", {
                ref: function(KO) {
                  OO.handle = KO
                },
                className: "rangeslider__handle",
                onMouseDown: this.handleStart,
                onTouchMove: this.handleDrag,
                onTouchEnd: this.handleEnd,
                onKeyDown: this.handleKeyDown,
                style: TO,
                tabIndex: 0,
                children: [NO && (0, hO.jsx)("div", {
                  ref: function(KO) {
                    OO.tooltip = KO
                  },
                  className: "rangeslider__handle-tooltip",
                  children: (0, hO.jsx)("span", {
                    children: this.handleFormat(pO)
                  })
                }), (0, hO.jsx)("div", {
                  className: "rangeslider__handle-label",
                  children: oO
                })]
              }), CO && this.renderLabels(IO)]
            })
          }
        }]) && FO(KO.prototype, pO), XO && FO(KO, XO), Object.defineProperty(KO, "prototype", {
          writable: !1
        }), lO
      }(eO.Component);
    AO(dO, "propTypes", {
      min: lO.default.number,
      max: lO.default.number,
      step: lO.default.number,
      value: lO.default.number,
      orientation: lO.default.string,
      tooltip: lO.default.bool,
      reverse: lO.default.bool,
      labels: lO.default.object,
      handleLabel: lO.default.string,
      format: lO.default.func,
      onChangeStart: lO.default.func,
      onChange: lO.default.func,
      onChangeComplete: lO.default.func
    }), AO(dO, "defaultProps", {
      min: 0,
      max: 100,
      step: 1,
      value: 0,
      orientation: "horizontal",
      tooltip: !0,
      reverse: !1,
      labels: {},
      handleLabel: ""
    });
    var TO = dO;
    KO.default = TO
  },
  4123: (OO, KO, pO) => {
    var XO;
    KO.c = void 0;
    var bK = ((XO = pO(4126)) && XO.__esModule ? XO : {
      default: XO
    }).default;
    KO.c = bK
  },
  4140: (OO, KO) => {
    Object.defineProperty(KO, "__esModule", {
      value: !0
    }), KO.capitalize = function(OO) {
      return OO.charAt(0).toUpperCase() + OO.substr(1)
    }, KO.clamp = function(OO, KO, pO) {
      return Math.min(Math.max(OO, KO), pO)
    }
  },
  4095: (OO, KO, pO) => {
    var XO = pO(4100);

    function bK() {}

    function eO() {}
    eO.resetWarningCache = bK, OO.exports = function() {
      function OO(OO, KO, pO, bK, eO, lO) {
        if (lO !== XO) {
          var vK = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
          throw vK.name = "Invariant Violation", vK
        }
      }

      function KO() {
        return OO
      }
      OO.isRequired = OO;
      var pO = {
        array: OO,
        bigint: OO,
        bool: OO,
        func: OO,
        number: OO,
        object: OO,
        string: OO,
        symbol: OO,
        any: OO,
        arrayOf: KO,
        element: OO,
        elementType: OO,
        instanceOf: KO,
        node: OO,
        objectOf: KO,
        oneOf: KO,
        oneOfType: KO,
        shape: KO,
        exact: KO,
        checkPropTypes: eO,
        resetWarningCache: bK
      };
      return pO.PropTypes = pO, pO
    }
  },
  4087: (OO, KO, pO) => {
    OO.exports = pO(4095)()
  },
  4100: OO => {
    OO.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
  },
  4133: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => IO
    });
    var XO = function() {
        if ("undefined" !== typeof Map) return Map;

        function OO(OO, KO) {
          var pO = -1;
          return OO.some((function(OO, XO) {
            return OO[0] === KO && (pO = XO, !0)
          })), pO
        }
        return function() {
          function KO() {
            this.__entries__ = []
          }
          return Object.defineProperty(KO.prototype, "size", {
            get: function() {
              return this.__entries__.length
            },
            enumerable: !0,
            configurable: !0
          }), KO.prototype.get = function(KO) {
            var pO = OO(this.__entries__, KO),
              XO = this.__entries__[pO];
            return XO && XO[1]
          }, KO.prototype.set = function(KO, pO) {
            var XO = OO(this.__entries__, KO);
            ~XO ? this.__entries__[XO][1] = pO : this.__entries__.push([KO, pO])
          }, KO.prototype.delete = function(KO) {
            var pO = this.__entries__,
              XO = OO(pO, KO);
            ~XO && pO.splice(XO, 1)
          }, KO.prototype.has = function(KO) {
            return !!~OO(this.__entries__, KO)
          }, KO.prototype.clear = function() {
            this.__entries__.splice(0)
          }, KO.prototype.forEach = function(OO, KO) {
            void 0 === KO && (KO = null);
            for (var pO = 0, XO = this.__entries__; pO < XO.length; pO++) {
              var bK = XO[pO];
              OO.call(KO, bK[1], bK[0])
            }
          }, KO
        }()
      }(),
      bK = "undefined" !== typeof window && "undefined" !== typeof document && window.document === document,
      eO = "undefined" !== typeof pO.g && pO.g.Math === Math ? pO.g : "undefined" !== typeof self && self.Math === Math ? self : "undefined" !== typeof window && window.Math === Math ? window : Function("return this")(),
      lO = "function" === typeof requestAnimationFrame ? requestAnimationFrame.bind(eO) : function(OO) {
        return setTimeout((function() {
          return OO(Date.now())
        }), 1e3 / 60)
      };
    var vK = ["top", "right", "bottom", "left", "width", "height", "size", "weight"],
      CO = "undefined" !== typeof MutationObserver,
      hO = function() {
        function OO() {
          this.connected_ = !1, this.mutationEventsAdded_ = !1, this.mutationsObserver_ = null, this.observers_ = [], this.onTransitionEnd_ = this.onTransitionEnd_.bind(this), this.refresh = function(OO, KO) {
            var pO = !1,
              XO = !1,
              bK = 0;

            function eO() {
              pO && (pO = !1, OO()), XO && CO()
            }

            function vK() {
              lO(eO)
            }

            function CO() {
              var OO = Date.now();
              if (pO) {
                if (OO - bK < 2) return;
                XO = !0
              } else pO = !0, XO = !1, setTimeout(vK, KO);
              bK = OO
            }
            return CO
          }(this.refresh.bind(this), 20)
        }
        return OO.prototype.addObserver = function(OO) {
          ~this.observers_.indexOf(OO) || this.observers_.push(OO), this.connected_ || this.connect_()
        }, OO.prototype.removeObserver = function(OO) {
          var KO = this.observers_,
            pO = KO.indexOf(OO);
          ~pO && KO.splice(pO, 1), !KO.length && this.connected_ && this.disconnect_()
        }, OO.prototype.refresh = function() {
          this.updateObservers_() && this.refresh()
        }, OO.prototype.updateObservers_ = function() {
          var OO = this.observers_.filter((function(OO) {
            return OO.gatherActive(), OO.hasActive()
          }));
          return OO.forEach((function(OO) {
            return OO.broadcastActive()
          })), OO.length > 0
        }, OO.prototype.connect_ = function() {
          bK && !this.connected_ && (document.addEventListener("transitionend", this.onTransitionEnd_), window.addEventListener("resize", this.refresh), CO ? (this.mutationsObserver_ = new MutationObserver(this.refresh), this.mutationsObserver_.observe(document, {
            attributes: !0,
            childList: !0,
            characterData: !0,
            subtree: !0
          })) : (document.addEventListener("DOMSubtreeModified", this.refresh), this.mutationEventsAdded_ = !0), this.connected_ = !0)
        }, OO.prototype.disconnect_ = function() {
          bK && this.connected_ && (document.removeEventListener("transitionend", this.onTransitionEnd_), window.removeEventListener("resize", this.refresh), this.mutationsObserver_ && this.mutationsObserver_.disconnect(), this.mutationEventsAdded_ && document.removeEventListener("DOMSubtreeModified", this.refresh), this.mutationsObserver_ = null, this.mutationEventsAdded_ = !1, this.connected_ = !1)
        }, OO.prototype.onTransitionEnd_ = function(OO) {
          var KO = OO.propertyName,
            pO = void 0 === KO ? "" : KO;
          vK.some((function(OO) {
            return !!~pO.indexOf(OO)
          })) && this.refresh()
        }, OO.getInstance = function() {
          return this.instance_ || (this.instance_ = new OO), this.instance_
        }, OO.instance_ = null, OO
      }(),
      DO = function(OO, KO) {
        for (var pO = 0, XO = Object.keys(KO); pO < XO.length; pO++) {
          var bK = XO[pO];
          Object.defineProperty(OO, bK, {
            value: KO[bK],
            enumerable: !1,
            writable: !1,
            configurable: !0
          })
        }
        return OO
      },
      MO = function(OO) {
        return OO && OO.ownerDocument && OO.ownerDocument.defaultView || eO
      },
      aK = zK(0, 0, 0, 0);

    function oO(OO) {
      return parseFloat(OO) || 0
    }

    function FO(OO) {
      for (var KO = [], pO = 1; pO < arguments.length; pO++) KO[pO - 1] = arguments[pO];
      return KO.reduce((function(KO, pO) {
        return KO + oO(OO["border-" + pO + "-width"])
      }), 0)
    }

    function VO(OO) {
      var KO = OO.clientWidth,
        pO = OO.clientHeight;
      if (!KO && !pO) return aK;
      var XO = MO(OO).getComputedStyle(OO),
        bK = function(OO) {
          for (var KO = {}, pO = 0, XO = ["top", "right", "bottom", "left"]; pO < XO.length; pO++) {
            var bK = XO[pO],
              eO = OO["padding-" + bK];
            KO[bK] = oO(eO)
          }
          return KO
        }(XO),
        eO = bK.left + bK.right,
        lO = bK.top + bK.bottom,
        vK = oO(XO.width),
        CO = oO(XO.height);
      if ("border-box" === XO.boxSizing && (Math.round(vK + eO) !== KO && (vK -= FO(XO, "left", "right") + eO), Math.round(CO + lO) !== pO && (CO -= FO(XO, "top", "bottom") + lO)), ! function(OO) {
          return OO === MO(OO).document.documentElement
        }(OO)) {
        var hO = Math.round(vK + eO) - KO,
          DO = Math.round(CO + lO) - pO;
        1 !== Math.abs(hO) && (vK -= hO), 1 !== Math.abs(DO) && (CO -= DO)
      }
      return zK(bK.left, bK.top, vK, CO)
    }
    var LO = "undefined" !== typeof SVGGraphicsElement ? function(OO) {
      return OO instanceof MO(OO).SVGGraphicsElement
    } : function(OO) {
      return OO instanceof MO(OO).SVGElement && "function" === typeof OO.getBBox
    };

    function QO(OO) {
      return bK ? LO(OO) ? function(OO) {
        var KO = OO.getBBox();
        return zK(0, 0, KO.width, KO.height)
      }(OO) : VO(OO) : aK
    }

    function zK(OO, KO, pO, XO) {
      return {
        x: OO,
        y: KO,
        width: pO,
        height: XO
      }
    }
    var AO = function() {
        function OO(OO) {
          this.broadcastWidth = 0, this.broadcastHeight = 0, this.contentRect_ = zK(0, 0, 0, 0), this.target = OO
        }
        return OO.prototype.isActive = function() {
          var OO = QO(this.target);
          return this.contentRect_ = OO, OO.width !== this.broadcastWidth || OO.height !== this.broadcastHeight
        }, OO.prototype.broadcastRect = function() {
          var OO = this.contentRect_;
          return this.broadcastWidth = OO.width, this.broadcastHeight = OO.height, OO
        }, OO
      }(),
      fO = function(OO, KO) {
        var pO = function(OO) {
          var KO = OO.x,
            pO = OO.y,
            XO = OO.width,
            bK = OO.height,
            eO = "undefined" !== typeof DOMRectReadOnly ? DOMRectReadOnly : Object,
            lO = Object.create(eO.prototype);
          return DO(lO, {
            x: KO,
            y: pO,
            width: XO,
            height: bK,
            top: pO,
            right: KO + XO,
            bottom: bK + pO,
            left: KO
          }), lO
        }(KO);
        DO(this, {
          target: OO,
          contentRect: pO
        })
      },
      dO = function() {
        function OO(OO, KO, pO) {
          if (this.activeObservations_ = [], this.observations_ = new XO, "function" !== typeof OO) throw new TypeError("The callback provided as parameter 1 is not a function.");
          this.callback_ = OO, this.controller_ = KO, this.callbackCtx_ = pO
        }
        return OO.prototype.observe = function(OO) {
          if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
          if ("undefined" !== typeof Element && Element instanceof Object) {
            if (!(OO instanceof MO(OO).Element)) throw new TypeError('parameter 1 is not of type "Element".');
            var KO = this.observations_;
            KO.has(OO) || (KO.set(OO, new AO(OO)), this.controller_.addObserver(this), this.controller_.refresh())
          }
        }, OO.prototype.unobserve = function(OO) {
          if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
          if ("undefined" !== typeof Element && Element instanceof Object) {
            if (!(OO instanceof MO(OO).Element)) throw new TypeError('parameter 1 is not of type "Element".');
            var KO = this.observations_;
            KO.has(OO) && (KO.delete(OO), KO.size || this.controller_.removeObserver(this))
          }
        }, OO.prototype.disconnect = function() {
          this.clearActive(), this.observations_.clear(), this.controller_.removeObserver(this)
        }, OO.prototype.gatherActive = function() {
          var OO = this;
          this.clearActive(), this.observations_.forEach((function(KO) {
            KO.isActive() && OO.activeObservations_.push(KO)
          }))
        }, OO.prototype.broadcastActive = function() {
          if (this.hasActive()) {
            var OO = this.callbackCtx_,
              KO = this.activeObservations_.map((function(OO) {
                return new fO(OO.target, OO.broadcastRect())
              }));
            this.callback_.call(OO, KO, OO), this.clearActive()
          }
        }, OO.prototype.clearActive = function() {
          this.activeObservations_.splice(0)
        }, OO.prototype.hasActive = function() {
          return this.activeObservations_.length > 0
        }, OO
      }(),
      TO = "undefined" !== typeof WeakMap ? new WeakMap : new XO,
      NO = function OO(KO) {
        if (!(this instanceof OO)) throw new TypeError("Cannot call a class as a function.");
        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
        var pO = hO.getInstance(),
          XO = new dO(KO, pO, this);
        TO.set(this, XO)
      };
    ["observe", "unobserve", "disconnect"].forEach((function(OO) {
      NO.prototype[OO] = function() {
        var KO;
        return (KO = TO.get(this))[OO].apply(KO, arguments)
      }
    }));
    const IO = "undefined" !== typeof eO.ResizeObserver ? eO.ResizeObserver : NO
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);