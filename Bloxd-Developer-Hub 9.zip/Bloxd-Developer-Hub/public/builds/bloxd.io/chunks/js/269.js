export const id = 269;
export const ids = [269, 270];
export const modules = {
  39217: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      CharacterCustomisationUI: () => PO
    });
    var XO = pO(63),
      bK = pO(2332),
      eO = pO(1004),
      lO = pO(1556),
      vK = pO(918),
      CO = pO.n(vK),
      hO = pO(1098),
      DO = pO(512),
      MO = pO(1051),
      aK = pO(1803),
      oO = pO(1862),
      FO = pO(7899),
      VO = pO(1811),
      LO = pO(2401),
      QO = pO(1583),
      zK = pO(1271),
      AO = pO(1849),
      fO = pO(22),
      dO = pO(1329),
      TO = pO(256),
      NO = pO(39219),
      IO = pO(1388),
      yK = pO(2329),
      gK = pO(1749),
      uO = pO(2061),
      EO = pO(933);
    Math.PI, Math.PI, Math.PI, Math.PI, Math.PI, Math.PI, Math.PI, Math.PI, Math.PI, Math.PI, Math.PI, Math.PI, Math.PI;
    var jK = pO(1871),
      YO = pO(1195),
      wO = pO(976);

    function iK(OO) {
      var KO;
      let {
        pack: pO,
        ownedPacks: XO,
        children: bK
      } = OO;
      const {
        t: eO
      } = (0, MO.D)(), lO = IO.e[pO], vK = lO.purchasable, hO = XO.includes(pO), DO = vK && !hO, aK = yK.j[pO];
      return (0, wO.jsxs)("div", {
        className: CO()("CosmeticPackGroup", {
          CosmeticPackGroupLocked: DO
        }),
        children: [aK && (0, wO.jsx)(aK, {}), (0, wO.jsxs)("div", {
          className: "CosmeticPackGroupLabel",
          children: [(0, wO.jsx)("span", {
            className: "CosmeticPackGroupLabelName",
            children: null !== (KO = lO.displayName) && void 0 !== KO ? KO : pO
          }), DO && (0, wO.jsxs)(zK.B, {
            onClick: () => {
              (0, yK.g)(pO)
            },
            children: [(0, wO.jsx)(EO.d, {
              name: "store"
            }), " ", eO("general:viewInShop")]
          })]
        }), DO && "bee" === pO && (0, wO.jsx)(yK.b, {}), bK]
      })
    }

    function rK(OO) {
      let {
        equippedEmoteIds: KO,
        ownedPacks: pO,
        xsollaSupported: XO,
        onUpdateLoadout: bK,
        onEmoteSelected: eO,
        onEquipPreviewSkin: lO
      } = OO;
      const {
        t: vK
      } = (0, MO.D)(), DO = new Set(KO), oO = new Map, FO = Object.keys(aK.d.emote).sort(((OO, KO) => {
        var pO, XO, bK, eO;
        return (null !== (pO = null === (XO = (0, aK.j)("emote", OO)) || void 0 === XO ? void 0 : XO.clientIdx) && void 0 !== pO ? pO : 0) - (null !== (bK = null === (eO = (0, aK.j)("emote", KO)) || void 0 === eO ? void 0 : eO.clientIdx) && void 0 !== bK ? bK : 0)
      })).filter((OO => {
        const KO = (0, aK.o)("emote", OO),
          bK = (0, aK.j)("emote", OO).cosmeticPack,
          eO = pO.includes(bK);
        return !(KO.purchasable && !eO && !XO) && (KO.clientSelectable || eO)
      }));
      for (const CO of FO) {
        const OO = (0, aK.j)("emote", CO).cosmeticPack;
        oO.has(OO) || oO.set(OO, []), oO.get(OO).push(CO)
      }
      const LO = Array.from(oO.keys());
      return (0, wO.jsxs)("div", {
        className: "CharCustomisPartSelectorWrapper",
        children: [!1, (0, wO.jsxs)("div", {
          className: "EmoteLoadoutSummary",
          children: [(0, wO.jsx)("span", {
            className: "EmoteLoadoutSummaryText SmallTextBold",
            children: vK("emotes:equippedCount", {
              count: KO.length,
              max: hO.m
            })
          }), (0, wO.jsx)("span", {
            className: "EmoteLoadoutSummaryHint SmallTextLight",
            children: vK("emotes:loadoutHint")
          })]
        }), LO.map((OO => {
          const XO = oO.get(OO);
          return (0, wO.jsx)(iK, {
            pack: OO,
            ownedPacks: pO,
            children: (0, wO.jsx)("div", {
              className: "CosmeticPackGroupItems",
              children: XO.map((XO => {
                var lO;
                const MO = KO.indexOf(XO),
                  oO = -1 !== MO,
                  FO = KO.length >= hO.m,
                  LO = (0, aK.o)("emote", XO).purchasable && !pO.includes(OO),
                  QO = LO || !oO && FO,
                  zK = (0, VO.j)(XO);
                return (0, wO.jsxs)("div", {
                  className: CO()("CharCustomPartWrapper", "EmoteCustomPartWrapper", {
                    SelectedCharCustomPartWrapper: oO
                  }),
                  onClick: () => {
                    eO(XO)
                  },
                  children: [(0, wO.jsxs)("div", {
                    className: "CharCustomPart EmoteCustomPart",
                    children: [(0, wO.jsx)("div", {
                      className: "EmoteCustomPartIcon",
                      style: {
                        backgroundImage: `url(/textures/charSkins/previews/emote_${XO}_preview.png)`
                      },
                      "aria-hidden": !0
                    }), (0, wO.jsx)("span", {
                      className: "EmoteCustomPartLabel SmallTextBold",
                      children: null !== (lO = null === zK || void 0 === zK ? void 0 : zK.displayName) && void 0 !== lO ? lO : XO
                    })]
                  }), (0, wO.jsxs)("div", {
                    className: "EmoteCustomPartToggleContainer",
                    children: [oO && (0, wO.jsx)("span", {
                      className: "EmoteCustomPartSlotBadge",
                      children: MO + 1
                    }), LO && (0, wO.jsx)(EO.d, {
                      name: "lock",
                      className: "LockedCosmeticIcon"
                    }), (0, wO.jsx)(YO.g, {
                      tooltipInner: (0, wO.jsx)(wO.Fragment, {
                        children: vK(oO ? "general:remove" : "general:add")
                      }),
                      delayShow: 0,
                      delayHide: 0,
                      children: (0, wO.jsx)("div", {
                        className: CO()("EmoteCustomPartToggle", {
                          EmoteCustomPartToggleDisabled: QO,
                          EmoteCustomPartToggleEquipped: oO
                        }),
                        onClick: OO => {
                          OO.stopPropagation(), QO || function(OO) {
                            DO.has(OO) ? bK(KO.filter((KO => KO !== OO))) : KO.length >= hO.m || bK([...KO, OO])
                          }(XO)
                        },
                        children: (0, wO.jsx)(EO.d, {
                          name: oO ? "minus" : "plus",
                          "aria-hidden": !0
                        })
                      })
                    })]
                  })]
                }, XO)
              }))
            })
          }, OO)
        }))]
      })
    }
    const PO = (0, XO.memo)((function(OO) {
      let {
        selectedTab: KO
      } = OO;
      const pO = "characters" === KO ? "skin" : KO,
        {
          t: vK
        } = (0, MO.D)(),
        {
          userContext: VO,
          isUserContextUpdating: yK
        } = (0, eO.d)(),
        YO = (0, bK.b)(),
        {
          gameState: PO,
          initSdkSelectorFinished: mK
        } = (0, fO.l)(["gameState", "initSdkSelectorFinished"]),
        [sO, HO] = (0, XO.useState)({}),
        [RO, SO] = (0, XO.useState)({}),
        {
          previewEmote: JO,
          triggerEmote: cK
        } = (0, LO.d)(),
        BO = (0, XO.useRef)(hO.w.reduce(((OO, KO) => (OO[KO] = (0, FO.d)(KO), OO)), {})),
        ZO = (0, XO.useRef)(!1),
        GO = (0, XO.useRef)(null),
        qK = (0, XO.useRef)(null),
        xK = (0, XO.useRef)(null);

      function nO() {
        null !== qK.current && (clearTimeout(qK.current), qK.current = null);
        const OO = xK.current;
        if (null === OO) return;
        xK.current = null;
        const KO = {
          oV: "emote",
          VV: OO
        };
        null !== lO.gameBridge.latest("connectedGame").websocketUrl ? lO.gameBridge.send("updateMyCosmetic", KO) : dO.c.updateCosmetics(VO, [KO]).catch((OO => {
          console.error("Failed to update emote loadout", OO)
        }))
      }

      function WO(OO, KO, pO) {
        var XO, bK, eO;
        if (BO.current = {
            ...BO.current,
            [OO]: KO
          }, YO(), pO) {
          const pO = {
            oV: OO,
            VV: KO
          };
          null !== lO.gameBridge.latest("connectedGame").websocketUrl ? lO.gameBridge.send("updateMyCosmetic", pO) : dO.c.updateCosmetics(VO, [pO]).catch((OO => {
            console.error("Failed to update cosmetic", OO)
          })), VO.setPlayerCosmetics(OO, KO)
        }
        const vK = (0, aK.j)(OO, KO);
        if (null !== vK && void 0 !== vK && vK.colourGroup && null !== (XO = IO.e[vK.cosmeticPack].colourGroups) && void 0 !== XO && null !== (bK = XO[vK.colourGroup]) && void 0 !== bK && bK.showSwatchSelector) {
          const pO = (0, aK.h)(KO);
          pO && SO((KO => ({
            ...KO,
            [`${vK.cosmeticPack}_${OO}_${vK.colourGroup}`]: parseInt(pO[1])
          })))
        }
        null !== (eO = GO.current) && void 0 !== eO && eO.isReady() && GO.current.updateCosmetic(OO, KO)
      }

      function tK(OO) {
        return Object.entries(OO).every((OO => {
          let [KO, pO] = OO;
          return sO[KO] === pO
        }))
      }(0, QO.b)("cosmeticsUpdated", (OO => {
        let KO = !1;
        for (const {
            local: pO,
            oV: XO,
            VV: bK
          }
          of OO) {
          if (!pO) return;
          KO = !0, ZO.current || WO(XO, bK, !1), YO()
        }
        KO && (ZO.current = !0)
      })), (0, XO.useEffect)((() => {
        if (!yK) {
          for (const [OO, KO] of Object.entries(VO.getPlayerCosmetics())) WO(OO, KO, !1);
          YO()
        }
      }), [yK]), (0, XO.useEffect)((() => () => {
        nO()
      }), []);
      const kK = VO.getOwnedCosmeticPacks(),
        UO = (0, jK.siteSupportsPurchases)(),
        OK = Object.keys(aK.d[pO]).filter((OO => {
          const KO = (0, aK.o)(pO, OO),
            XO = (0, aK.j)(pO, OO).cosmeticPack,
            bK = kK.includes(XO);
          return !(KO.purchasable && !bK && !UO) && (KO.clientSelectable || bK)
        })).sort(((OO, KO) => {
          var XO, bK, eO, lO;
          return (null !== (XO = null === (bK = (0, aK.j)(pO, OO)) || void 0 === bK ? void 0 : bK.clientIdx) && void 0 !== XO ? XO : 0) - (null !== (eO = null === (lO = (0, aK.j)(pO, KO)) || void 0 === lO ? void 0 : lO.clientIdx) && void 0 !== eO ? eO : 0)
        })),
        KK = new Map;
      for (const XO of OK) {
        var pK;
        const OO = null === (pK = (0, aK.j)(pO, XO)) || void 0 === pK ? void 0 : pK.cosmeticPack;
        KK.has(OO) || KK.set(OO, []), KK.get(OO).push(XO)
      }
      const XK = new Map;
      for (const [XO, bK] of KK) {
        const OO = [],
          KO = new Map;
        for (const XO of bK) {
          var bp, eK;
          const bK = null !== (bp = null === (eK = (0, aK.j)(pO, XO)) || void 0 === eK ? void 0 : eK.colourGroup) && void 0 !== bp ? bp : null;
          KO.has(bK) || (KO.set(bK, []), OO.push(bK)), KO.get(bK).push(XO)
        }
        const eO = OO.map((OO => {
          var bK;
          const eO = KO.get(OO),
            lO = OO ? null === (bK = IO.e[XO].colourGroups) || void 0 === bK ? void 0 : bK[OO] : void 0;
          if ((null === lO || void 0 === lO ? void 0 : lO.showSwatchSelector) && lO) {
            var vK;
            const KO = null !== (vK = RO[`${XO}_${pO}_${OO}`]) && void 0 !== vK ? vK : (0, IO.i)(lO.colours);
            return {
              groupName: OO,
              cosmetics: eO.filter((OO => {
                const pO = (0, aK.h)(OO);
                return !pO || KO.toString() === pO[1].toString()
              }))
            }
          }
          return {
            groupName: OO,
            cosmetics: eO
          }
        }));
        XK.set(XO, eO)
      }
      const lK = Array.from(KK.keys()),
        vp = new Map;
      for (const [XO, bK] of Object.entries(oO.e)) {
        const OO = IO.e[bK.cosmeticPack],
          KO = kK.includes(bK.cosmeticPack);
        (OO.clientSelectable || KO) && ((!OO.purchasable || KO || UO) && (vp.has(bK.cosmeticPack) || vp.set(bK.cosmeticPack, []), vp.get(bK.cosmeticPack).push([XO, bK])))
      }
      const CK = Array.from(vp.keys());
      return (0, wO.jsxs)("div", {
        className: "CharCustomisationBody",
        children: [("cape" === pO || "nameColour" === pO) && !VO.playerHasRank("super") && (0, wO.jsxs)("div", {
          className: "CharCustomisationBodyHeader",
          children: [(0, wO.jsx)(EO.d, {
            name: "bolt"
          }), vK("homePage:unlockWithSuperRank"), UO && (0, wO.jsx)(zK.m, {
            onClick: () => {
              (0, AO.k)({
                mode: "self",
                source: "characterCustomisation",
                openItem: "superRank"
              })
            },
            children: vK("general:getItNow")
          })]
        }), (0, wO.jsxs)("div", {
          className: "CharCustomisationBodyInner",
          children: ["characters" === KO && (0, wO.jsxs)("div", {
            className: "CharCustomisPartSelectorWrapper",
            children: [!1, CK.map((OO => {
              const KO = vp.get(OO),
                pO = IO.e[OO].purchasable && !kK.includes(OO);
              return (0, wO.jsx)(iK, {
                pack: OO,
                ownedPacks: kK,
                children: (0, wO.jsx)("div", {
                  className: "CharacterPresetsGrid",
                  children: KO.map((OO => {
                    let [KO, {
                      cosmetics: XO
                    }] = OO;
                    const bK = tK(XO),
                      eO = !bK && Object.entries(XO).every((OO => {
                        let [KO, pO] = OO;
                        return BO.current[KO] === pO
                      }));
                    return (0, wO.jsxs)("div", {
                      "data-pad-focusable": !0,
                      className: CO()("CharacterPresetCard", {
                        CharacterPresetCardActive: eO,
                        CharacterPresetCardTryingOn: bK
                      }),
                      onClick: () => {
                        if (pO) ! function(OO) {
                          tK(OO) ? HO({}) : HO({
                            ...OO
                          })
                        }(XO);
                        else {
                          Object.keys(sO).length > 0 && HO({});
                          const OO = Object.entries(XO);
                          for (const [KO, pO] of OO) WO(KO, pO, !1), VO.setPlayerCosmetics(KO, pO);
                          if (null !== lO.gameBridge.latest("connectedGame").websocketUrl)
                            for (const [KO, pO] of OO) lO.gameBridge.send("updateMyCosmetic", {
                              oV: KO,
                              VV: pO
                            });
                          else dO.c.updateCosmetics(VO, OO.map((OO => {
                            let [KO, pO] = OO;
                            return {
                              oV: KO,
                              VV: pO
                            }
                          }))).catch((OO => {
                            console.error("Failed to update cosmetics", OO)
                          }))
                        }
                      },
                      children: [(0, wO.jsx)("div", {
                        className: "CharacterPresetCardPreview",
                        style: {
                          backgroundImage: `url(/textures/charSkins/previews/character_${KO}_preview.png)`
                        }
                      }), pO && (0, wO.jsx)(EO.d, {
                        name: "lock",
                        className: "LockedCosmeticIcon"
                      })]
                    }, KO)
                  }))
                })
              }, OO)
            }))]
          }), "emote" === KO && (0, wO.jsx)(rK, {
            equippedEmoteIds: (0, FO.h)(BO.current.emote),
            ownedPacks: kK,
            xsollaSupported: UO,
            onUpdateLoadout: OO => {
              const KO = (0, FO.l)(OO);
              var pO;
              BO.current = {
                ...BO.current,
                emote: KO
              }, VO.setPlayerCosmetics("emote", KO), YO(), pO = KO, xK.current = pO, null !== qK.current && clearTimeout(qK.current), qK.current = setTimeout(nO, 350)
            },
            onEmoteSelected: cK,
            onEquipPreviewSkin: () => {
              ! function(OO, KO) {
                for (const pO of hO.w) "cape" !== pO && "nameColour" !== pO && "emote" !== pO && OO(pO, "skin" === pO ? "skin_preview" : `${pO}_none`, !1);
                KO()
              }(WO, YO)
            }
          }), "characters" !== KO && "emote" !== KO && (0, wO.jsxs)("div", {
            className: "CharCustomisPartSelectorWrapper",
            children: [!1, lK.map((OO => {
              const KO = XK.get(OO),
                XO = IO.e[OO].purchasable && !kK.includes(OO);
              return (0, wO.jsx)(iK, {
                pack: OO,
                ownedPacks: kK,
                children: KO.map((KO => {
                  var bK;
                  let {
                    groupName: eO,
                    cosmetics: lO
                  } = KO;
                  const vK = eO ? null === (bK = IO.e[OO].colourGroups) || void 0 === bK ? void 0 : bK[eO] : void 0,
                    hO = `${OO}_${pO}_${eO}`,
                    MO = null === vK || void 0 === vK ? void 0 : vK.showSwatchSelector;
                  return (0, wO.jsxs)("div", {
                    className: "CosmeticPackGroupItems",
                    children: [MO && vK && (0, wO.jsx)("div", {
                      className: "CosmeticColorSwatchCell",
                      children: [...vK.colours.map(((OO, KO) => ({
                        color: OO,
                        index: KO
                      })))].sort(((OO, KO) => OO.color.order - KO.color.order)).map((KO => {
                        var XO;
                        let {
                          color: bK,
                          index: lO
                        } = KO;
                        return (0, wO.jsx)("div", {
                          className: CO()("CosmeticColorOption", {
                            CosmeticColorOptionSelected: (null !== (XO = RO[hO]) && void 0 !== XO ? XO : (0, IO.i)(vK.colours)) === lO
                          }),
                          style: {
                            backgroundColor: `rgb(${bK.rbg.join(",")})`
                          },
                          onClick: () => {
                            var KO;
                            SO((OO => ({
                              ...OO,
                              [hO]: lO
                            })));
                            const XO = sO[pO],
                              bK = XO ? (0, aK.j)(pO, XO) : null,
                              vK = (null === bK || void 0 === bK ? void 0 : bK.cosmeticPack) === OO,
                              CO = vK ? XO : BO.current[pO],
                              DO = vK ? bK : (0, aK.j)(pO, CO);
                            if ((null === DO || void 0 === DO ? void 0 : DO.cosmeticPack) !== OO) return;
                            if ((null !== (KO = null === DO || void 0 === DO ? void 0 : DO.colourGroup) && void 0 !== KO ? KO : null) !== eO) return;
                            const MO = (0, aK.h)(CO);
                            if (MO) {
                              const OO = `${pO}_${MO[0]}_${lO}`;
                              vK ? HO((KO => ({
                                ...KO,
                                [pO]: OO
                              }))) : WO(pO, OO, !0)
                            }
                          }
                        }, bK.rbg.join())
                      }))
                    }), lO.map((OO => {
                      const KO = OO === BO.current[pO],
                        bK = sO[pO] === OO;
                      let eO = !0;
                      return XO || KO || ("cape" !== pO || (0, TO.Cd)(VO.getPlayerRanks(), OO)) && ("nameColour" !== pO || VO.playerHasRank("super")) || (eO = !1), (0, wO.jsxs)("div", {
                        className: CO()("CharCustomPartWrapper", {
                          SelectedCharCustomPartWrapper: KO && !bK,
                          TryingOnCharCustomPartWrapper: bK,
                          DisabledCharCustomPartWrapper: !eO,
                          CharCustomPartWrapperProfileEffect: "profileEffect" === pO
                        }),
                        onClick: () => {
                          if (eO)
                            if (XO) HO((KO => {
                              if (KO[pO] === OO) {
                                const OO = {
                                  ...KO
                                };
                                return delete OO[pO], OO
                              }
                              return {
                                ...KO,
                                [pO]: OO
                              }
                            }));
                            else {
                              var KO;
                              if (sO[pO] && HO((OO => {
                                  const KO = {
                                    ...OO
                                  };
                                  return delete KO[pO], KO
                                })), OO === BO.current[pO]) return;
                              null !== (KO = GO.current) && void 0 !== KO && KO.isReady() && WO(pO, OO, !0)
                            }
                        },
                        children: ["profileEffect" === pO ? (0, wO.jsx)("div", {
                          className: "CharCustomPart CharCustomProfileEffect",
                          children: (0, wO.jsx)(uO.h, {
                            playerSocialPreview: (0, gK.b)(OO, {
                              name: VO.getPlayerName(),
                              cosmetics: VO.getPlayerCosmetics()
                            }),
                            showLocation: !1,
                            opensProfileCard: !1
                          })
                        }) : (0, wO.jsx)("div", {
                          className: CO()("CharCustomPart", {
                            PixelatedImage: "cape" === pO
                          }),
                          style: (0, aK.j)(pO, OO).previewTex ? {
                            backgroundImage: `url(/textures/charSkins/previews/${(0,aK.j)(pO,OO).previewTex}.png)`
                          } : {
                            backgroundColor: DO.s[OO],
                            borderRadius: "50%"
                          }
                        }), XO && (0, wO.jsx)(EO.d, {
                          name: "lock",
                          className: "LockedCosmeticIcon"
                        })]
                      }, OO)
                    }))]
                  }, null !== eO && void 0 !== eO ? eO : "ungrouped")
                }))
              }, OO)
            }))]
          }), (0, wO.jsx)(NO.CharacterPreview, {
            ref: GO,
            forcedCosmetics: sO,
            GV: JO.id,
            emotePlaySeq: JO.seq,
            onReady: () => {
              for (const OO of hO.w) WO(OO, BO.current[OO], !1)
            }
          })]
        })]
      })
    }))
  },
  39219: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      CharacterPreview: () => DO
    });
    var XO = pO(63),
      bK = pO(2209),
      eO = pO(1098),
      lO = pO(7899),
      vK = pO(35338),
      CO = pO(2883),
      hO = pO(976);
    const DO = (0, XO.memo)((0, XO.forwardRef)((function(OO, KO) {
      let {
        onReady: pO,
        onDrawn: DO,
        owner: MO = "other",
        forcedCosmetics: aK,
        GV: oO,
        emotePlaySeq: FO
      } = OO;
      const VO = (0, XO.useRef)(null),
        {
          width: LO,
          height: QO
        } = (0, bK.d)(VO),
        zK = (0, XO.useRef)(null),
        AO = (0, XO.useRef)({}),
        fO = (0, XO.useRef)({}),
        [dO, TO] = (0, XO.useState)(!1),
        NO = (0, XO.useRef)(pO);
      NO.current = pO;
      const IO = (0, XO.useRef)(DO);
      IO.current = DO;
      const yK = (0, XO.useRef)(null),
        gK = (0, XO.useRef)(!1),
        uO = (0, XO.useRef)(!1),
        EO = (0, XO.useCallback)((() => {
          const OO = zK.current;
          if (!OO || !IO.current || gK.current || !uO.current) return;
          const KO = {};
          yK.current = KO, queueMicrotask((() => {
            if (yK.current !== KO) return;
            const pO = Promise.all(eO.w.map((KO => OO.untilDrawn(KO)))).catch((OO => {
                console.error("Failed to draw the character preview", OO)
              })),
              XO = new Promise((OO => {
                setTimeout(OO, 1e4)
              }));
            Promise.race([pO, XO]).then((() => {
              var pO;
              zK.current !== OO || yK.current !== KO || gK.current || (gK.current = !0, null === (pO = IO.current) || void 0 === pO || pO.call(IO))
            }))
          }))
        }), []);
      return (0, XO.useImperativeHandle)(KO, (() => {
        const OO = (OO, KO) => {
          var pO;
          (AO.current[OO] = KO, null !== aK && void 0 !== aK && aK[OO]) || (null === (pO = zK.current) || void 0 === pO || pO.setCosmetic(OO, KO), EO())
        };
        return {
          updateCosmetic: OO,
          setAllCosmetics(KO) {
            for (const XO of eO.w) {
              var pO;
              OO(XO, null !== (pO = KO[XO]) && void 0 !== pO ? pO : (0, lO.d)(XO))
            }
          },
          isReady() {
            var OO, KO;
            return null !== (OO = null === (KO = zK.current) || void 0 === KO ? void 0 : KO.isReady()) && void 0 !== OO && OO
          },
          async ensureReadyForCapture(OO) {
            var KO;
            await (null === (KO = zK.current) || void 0 === KO ? void 0 : KO.untilDrawn(OO))
          },
          getDevTools() {
            var OO;
            return null !== (OO = zK.current) && void 0 !== OO && OO.isReady() ? zK.current.dev : null
          }
        }
      }), [aK, EO]), (0, XO.useEffect)((() => {
        const OO = CO.d.register(MO),
          KO = vK.e.openCharacter(VO.current);
        zK.current = KO;
        let pO = !0;
        return KO.ready.then((() => {
          pO && (TO(!0), NO.current())
        })).catch((OO => {
          console.error("Failed to set up the character preview", OO)
        })), () => {
          pO = !1, OO(), KO.close(), zK.current = null
        }
      }), []), (0, XO.useEffect)((() => {
        LO <= 0 || QO <= 0 || zK.current.resize(LO, QO)
      }), [LO, QO]), (0, XO.useEffect)((() => {
        if (!dO) return;
        const OO = fO.current;
        for (const KO of eO.w) {
          const pO = null === aK || void 0 === aK ? void 0 : aK[KO],
            XO = OO[KO];
          pO && pO !== XO ? zK.current.setCosmetic(KO, pO) : !pO && XO && AO.current[KO] && zK.current.setCosmetic(KO, AO.current[KO])
        }
        fO.current = {
          ...aK
        }, uO.current = !0, EO()
      }), [aK, dO, EO]), (0, XO.useEffect)((() => {
        dO && zK.current.playEmote(null !== oO && void 0 !== oO ? oO : null)
      }), [oO, FO, dO]), (0, hO.jsx)("div", {
        className: "CharCustomisationPreview",
        ref: VO
      })
    })))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);