export const id = 228;
export const ids = [228];
export const modules = {
  37682: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => OX
    });
    const XO = [0, 90, 180, 270],
      bK = "plotsblueprint";
    var eO = pO(63),
      lO = pO(35137),
      vK = pO(22),
      CO = pO(1441),
      hO = pO(1481),
      DO = pO(26);
    const MO = [
        ["well", "greenhouse", "farmhouse"],
        ["tent", "cottage", "windmill"],
        ["marketStall", "gazebo", "bakery"],
        ["bridge", "lookoutTower", "lighthouse"]
      ],
      aK = MO.flat(),
      oO = {
        well: {
          displayName: {
            translationKey: "plotsGame:blueprintWell"
          },
          tier: "small"
        },
        greenhouse: {
          displayName: {
            translationKey: "plotsGame:blueprintGreenhouse"
          },
          tier: "small"
        },
        farmhouse: {
          displayName: {
            translationKey: "plotsGame:blueprintFarmhouse"
          },
          tier: "medium"
        },
        tent: {
          displayName: {
            translationKey: "plotsGame:blueprintTent"
          },
          tier: "small"
        },
        cottage: {
          displayName: {
            translationKey: "plotsGame:blueprintCottage"
          },
          tier: "small"
        },
        windmill: {
          displayName: {
            translationKey: "plotsGame:blueprintWindmill"
          },
          tier: "medium"
        },
        marketStall: {
          displayName: {
            translationKey: "plotsGame:blueprintMarketStall"
          },
          tier: "small"
        },
        gazebo: {
          displayName: {
            translationKey: "plotsGame:blueprintGazebo"
          },
          tier: "small"
        },
        bakery: {
          displayName: {
            translationKey: "plotsGame:blueprintBakery"
          },
          tier: "medium"
        },
        bridge: {
          displayName: {
            translationKey: "plotsGame:blueprintBridge"
          },
          tier: "small"
        },
        lookoutTower: {
          displayName: {
            translationKey: "plotsGame:blueprintLookoutTower"
          },
          tier: "small"
        },
        lighthouse: {
          displayName: {
            translationKey: "plotsGame:blueprintLighthouse"
          },
          tier: "medium"
        }
      };

    function FO(OO) {
      return oO[OO]
    }
    const VO = new Map(MO.flatMap((OO => OO.slice(1).map(((KO, pO) => [KO, OO[pO]])))));

    function LO(OO) {
      var KO;
      return null !== (KO = VO.get(OO)) && void 0 !== KO ? KO : null
    }
    const QO = {
      well: "plotsGame:journalNoteWell",
      tent: "plotsGame:journalNoteTent",
      lookoutTower: "plotsGame:journalNoteLookoutTower",
      farmhouse: "plotsGame:journalNoteFarmhouse",
      windmill: "plotsGame:journalNoteWindmill"
    };

    function zK(OO, KO) {
      const pO = new Set(OO),
        XO = function(OO) {
          const KO = new Set(OO);
          return new Set(aK.filter((OO => {
            const pO = LO(OO);
            return null === pO || KO.has(pO)
          })))
        }(pO);
      return aK.map((OO => {
        const bK = OO === KO;
        return pO.has(OO) ? {
          id: OO,
          active: bK,
          state: "completed",
          unlockedBy: null
        } : XO.has(OO) ? {
          id: OO,
          active: bK,
          state: "open",
          unlockedBy: null
        } : {
          id: OO,
          active: bK,
          state: "locked",
          unlockedBy: LO(OO)
        }
      }))
    }
    const AO = "plotsJournalChanged";
    class fO {
      constructor(OO, KO) {
        this.api = OO, this.placement = KO, this.pages = null, this.openRequested = !1, this.reported = new Set, this.onOpened = () => {
          this.placement.stop(), this.CX("journal_opened")
        }, this.build = OO => {
          this.CX("placement_started"), this.placement.start(OO), (0, lO.g)()
        }, this.putAway = () => {
          this.api.sendCommand(`${bK} cancel`)
        }
      }
      getPages() {
        return this.pages
      }
      PX(OO) {
        let [, KO, pO] = OO;
        this.pages = zK(KO, pO), DO.i.pl(AO, this.pages, !0)
      }
      openFromServer() {
        this.openRequested = !0, this.KK()
      }
      KK() {
        this.openRequested && !vK.d.get("loadingOverlayVisible") && (this.openRequested = !1, null === this.pages || (0, CO.i)() || (0, hO.isTypingInInput)() || null !== this.placement.getView() || (0, lO.o)())
      }
      CX(OO) {
        this.reported.has(OO) || (this.reported.add(OO), this.api.sendCommand(`${bK} report ${OO}`))
      }
    }
    var dO = pO(918),
      TO = pO.n(dO),
      NO = pO(933),
      IO = pO(1271),
      yK = pO(3719),
      gK = pO(2680),
      uO = pO(1263),
      EO = pO(1667),
      jK = pO(1051),
      YO = pO(8365);
    const wO = [0, 90, 180, 270],
      iK = /^(meta\|rot\d)\|([lrud]+)$/,
      rK = "nesw",
      PO = /^meta\|([nesw]*)\|?(Stacked)?$/,
      mK = function(OO) {
        const KO = new WeakMap;
        return (pO, XO) => {
          let bK = KO.get(pO);
          return void 0 === bK && (bK = OO(pO, XO), KO.set(pO, bK)), bK
        }
      }((OO => new sO(OO)));
    class sO {
      constructor(OO) {
        this.blockMetadata = OO, this.blockIdMappings = new Map, this.maxBlockId = void 0;
        const KO = new Set(Object.keys(OO).map((KO => OO[KO].id)));
        KO.add(0), this.maxBlockId = Math.max(...KO)
      }
      static
      for (OO) {
        return mK(OO)
      }
      getBlockIdMapping(OO, KO) {
        const pO = this.getBlockIdMappingKey(OO, KO);
        let XO = this.blockIdMappings.get(pO);
        return void 0 === XO && wO.includes(OO) && (XO = this.createBlockIdMapping(this.blockMetadata, this.maxBlockId, OO, KO), this.blockIdMappings.set(pO, XO)), XO
      }
      turnBlockId(OO, KO, pO) {
        return this.mapBlockId(this.blockMetadata[OO], KO, this.getRotationMapping(KO, pO), pO)
      }
      getBlockIdMappingKey(OO, KO) {
        return `r${OO}|m${Number(KO)}`
      }
      createBlockIdMapping(OO, KO, pO, XO) {
        const bK = new Uint16Array(KO + 1),
          eO = this.getRotationMapping(pO, XO);
        for (const lO in OO) {
          const KO = OO[lO];
          bK[KO.id] = this.mapBlockId(KO, pO, eO, XO)
        }
        return bK
      }
      getRotationMapping(OO, KO) {
        const pO = Math.round(OO / 90),
          XO = new Uint8Array(4);
        for (let bK = 0; bK < 4; bK++) XO[bK] = (4 + bK - pO) % 4;
        if (KO) {
          let OO = XO[0];
          XO[0] = XO[1], XO[1] = OO, OO = XO[2], XO[2] = XO[3], XO[3] = OO
        }
        return XO
      }
      mapBlockId(OO, KO, pO, XO) {
        var bK;
        const {
          blockMetadata: eO
        } = this, lO = Math.round(KO / 90), {
          id: vK,
          meta: CO
        } = OO, {
          rot: hO,
          rootName: DO,
          metaStr: MO
        } = CO;
        let aK;
        const [, oO, FO] = null !== (bK = PO.exec(MO)) && void 0 !== bK ? bK : [];
        if (void 0 !== oO) {
          var VO, LO;
          aK = null !== (VO = null === (LO = eO[`${DO}|meta|${[rK.split("").filter(((OO,KO)=>oO.split("").some((OO=>{const pO=rK.indexOf(OO);return((XO?3-pO:pO)+lO)%4===KO})))).join(""),FO].filter(Boolean).join("|")}`]) || void 0 === LO ? void 0 : LO.id) && void 0 !== VO ? VO : vK
        } else if (null === hO) aK = vK;
        else {
          var QO, zK;
          const OO = pO[hO - 1] + 1;
          let KO = MO.replace(`rot${hO}`, `rot${OO}`);
          XO && CO.stairsCorner && (KO = KO.replace(/(Left|Right)$/, (OO => "Left" === OO ? "Right" : "Left"))), XO && "Chest" === DO && (KO = KO.replace(/\|(left|right)$/, ((OO, KO) => "left" === KO ? "|right" : "|left")));
          const bK = iK.exec(KO);
          if (XO && null !== bK) {
            const OO = "lrud".split("").filter((OO => bK[2].includes("l" === OO ? "r" : "r" === OO ? "l" : OO)));
            KO = `${bK[1]}|${OO.join("")}`
          }
          const lO = `${DO}|${KO}`;
          if (aK = null !== (QO = null === (zK = eO[lO]) || void 0 === zK ? void 0 : zK.id) && void 0 !== QO ? QO : null, null === aK) {
            const OO = eO[DO];
            aK = OO.rootMetaDesc === lO ? OO.id : vK
          }
        }
        return aK
      }
    }

    function HO(OO, KO, pO) {
      let {
        xRotationMappedOrigin: XO,
        shouldSwapXZ: bK
      } = pO;
      const eO = bK ? KO : OO;
      return null === XO ? eO : XO - eO
    }

    function RO(OO, KO, pO) {
      let {
        zRotationMappedOrigin: XO,
        shouldSwapXZ: bK
      } = pO;
      const eO = bK ? OO : KO;
      return null === XO ? eO : XO - eO
    }
    const SO = {
        well: {
          size: [7, 8, 5],
          palette: ["Daisy", "Stone Bricks", "Cracked Stone Bricks", "Stone Bricks Slab", "Maple Log", "Bricks Stairs|meta|rot4|bot", "Light Blue Glass", "Mossy Stone Bricks", "Maple Wood Planks", "Bricks Slab", "Bricks Stairs|meta|rot2|bot", "Poppy", "Dandelion"],
          layers: [".bbbbb. abgggh. .bgggb. .cgggbl .bbbbbm", ".bbbbb. .b...b. .b...b. .b...b. .bhbbb.", ".ddddd. .d...d. .e...e. .d...d. .ddddd.", "....... ....... .e...e. ....... .......", "....... ....... .eiiie. ....... .......", "....... .f...k. .fiiik. .f...k. .......", "....... ..f.k.. ..fik.. ..f.k.. .......", "....... ...j... ...j... ...j... ......."]
        },
        greenhouse: {
          size: [5, 6, 7],
          palette: ["Stone Bricks", "White Concrete", "Glass", "Dirt", "Poppy", "Dandelion", "Maple Leaves", "Red Tulip", "Daisy", "White Concrete Stairs|meta|rot4|bot", "Workbench", "Smooth Stone Slab", "White Concrete Slab", "Pink Tulip", "Bluebell", "Orange Tulip", "White Tulip", "White Concrete Stairs|meta|rot2|bot"],
          layers: ["aaaaa adkda adlda adlda adlda adlda aa.aa", "bcccb ce.nc cf.oc bg.gb ch.pc ci.qc bc.cb", "bcccb c...c c...c b...b c...c c...c bcccb", "bcccb c...c c...c b...b c...c c...c bcccb", ".jcr. .c.c. .c.c. .j.r. .c.c. .c.c. .jcr.", "..m.. ..m.. ..m.. ..m.. ..m.. ..m.. ..m.."]
        },
        farmhouse: {
          size: [13, 9, 9],
          palette: ["Pine Trapdoor|meta|rot4|open", "Pine Stairs|meta|rot4|bot", "White Concrete", "Red Planks", "Pumpkin", "Glass", "Chest", "Carved Pumpkin", "Lantern|meta|rot1|side", "Workbench", "Pine Slab", "Yellow Wool", "Pine Stairs|meta|rot2|bot", "Pine Trapdoor|meta|rot2|open", "Maple Fence|meta|es", "Maple Fence|meta|ne", "Maple Fence|meta|s", "Maple Fence|meta|esw", "Maple Fence|meta|ew", "Maple Fence|meta|new", "Maple Fence|meta|sw", "Maple Fence|meta|ns", "Maple Fence|meta|nsw", "Maple Fence|meta|nw"],
          layers: ["............. .cdddddc..... .dgj.lld..... .d...lld.orsu .d.....d.pe.v .d.....d...ew .d.....d..e.v .cd...dc.q.ew .eh......pstx", "............. .cdddddc..... ad....ldn.... .f.....f..... .d.....d..... .f.....f..... ad.....dn.... .cd...dc..... .............", "............. .cdddddc..... ad.....dn.... .f.....f..... .d.....d..... .f.....f..... ad.....dn.... .cd...dc..... ..i...i......", "............. .cdddddc..... .d.....d..... .d.....d..... .d.....d..... .d.....d..... .d.....d..... .cdcccdc..... .............", "b.......m.... bdddddddm.... b.......m.... b.......m.... b.......m.... b.......m.... b.......m.... bdddddddm.... b.......m....", ".b.....m..... .bdddddm..... .b.....m..... .b.....m..... .b.....m..... .b.....m..... .b.....m..... .bddfddm..... .b.....m.....", "..b...m...... ..bdddm...... ..b...m...... ..b...m...... ..b...m...... ..b...m...... ..b...m...... ..bdcdm...... ..b...m......", "...b.m....... ...bdm....... ...b.m....... ...b.m....... ...b.m....... ...b.m....... ...b.m....... ...bdm....... ...b.m.......", "....k........ ....k........ ....k........ ....k........ ....k........ ....k........ ....k........ ....k........ ....k........"]
        },
        tent: {
          size: [10, 4, 7],
          palette: ["Red Chalk Stairs|meta|rot4|bot", "White Chalk Stairs|meta|rot4|bot", "Red Wool", "White Wool", "White Carpet", "Lantern", "Red Chalk Slab", "White Chalk Slab", "Light Blue Carpet", "Red Chalk Stairs|meta|rot2|bot", "White Chalk Stairs|meta|rot2|bot", "Chest", "Messy Stone Slab", "Torch"],
          layers: ["acccccj... b.efi.k... a.e.i.j... b.e.i.k.m. a.....jmnm bd...dk.m. ......l...", ".acccj.... .b...k.... .a...j.... .b...k.... .a...j.... .bd.dk.... ..........", "..acj..... ..b.k..... ..a.j..... ..b.k..... ..a.j..... ..bdk..... ..........", "...g...... ...h...... ...g...... ...h...... ...g...... ...h...... .........."]
        },
        cottage: {
          size: [7, 8, 7],
          palette: ["Maple Trapdoor|meta|rot4|open", "Red Chalk Bricks Stairs|meta|rot4|bot", "Maple Log", "Maple Wood Planks", "Glass", "Workbench", "Poppy", "Red Carpet", "Lantern|meta|rot1|side", "Red Chalk Bricks Slab", "Chest", "Dandelion", "Red Chalk Bricks Stairs|meta|rot2|bot", "Bricks", "Maple Trapdoor|meta|rot2|open"],
          layers: ["....... .cdddc. .df.kd. .d.h.d. .d...d. .cd.dc. ..g.l..", "....... .cdedc. ad...do .e...e. ad...do .ce.ec. .......", "....... .cdddc. .d...d. .d...d. .d...d. .cdddc. ...i...", "b.....m bdddddm b.....m b.....m b.....m bdddddm b.....m", ".b...m. .bdddm. .b...m. .b...m. .b...m. .bdedm. .b...m.", "..b.m.. ..bdm.. ..b.n.. ..b.m.. ..b.m.. ..bdm.. ..b.m..", "...j... ...j... ...jn.. ...j... ...j... ...j... ...j...", "....... ....... ....n.. ....... ....... ....... ......."]
        },
        windmill: {
          size: [9, 13, 6],
          palette: ["Pine Log", "White Wool", "Poppy", "Stone Bricks", "Mossy Stone Bricks", "Stone Bricks Stairs|meta|rot3|bot|outerRight", "Stone Bricks Stairs|meta|rot4|bot", "Stone Bricks Stairs|meta|rot1|bot|outerLeft", "Red Chalk Bricks Stairs|meta|rot3|bot|outerRight", "Red Chalk Bricks Stairs|meta|rot4|bot", "Red Chalk Bricks Stairs|meta|rot1|bot|outerLeft", "Chest", "Lantern|meta|rot1|side", "Pine Wood Planks", "Stone Bricks Stairs|meta|rot3|bot", "Sandstone", "Stone Bricks Stairs", "Red Chalk Bricks Stairs|meta|rot3|bot", "Red Chalk Bricks", "Red Chalk Bricks Stairs", "Red Chalk Bricks Slab", "Workbench", "Glass", "Red Chalk Bricks Stairs|meta|rot3|bot|outerLeft", "Red Chalk Bricks Stairs|meta|rot2|bot", "Red Chalk Bricks Stairs|meta|rot1|bot|outerRight", "Stone Bricks Stairs|meta|rot3|bot|outerLeft", "Stone Bricks Stairs|meta|rot2|bot", "Stone Bricks Stairs|meta|rot1|bot|outerRight", "Dandelion", "Pine Trapdoor|meta|rot2|open"],
          layers: ["..ddddd.. ..dl.vd.. ..e...d.. ..d...d.. .cdd.dd~. .........", "..ddddd.. ..d...d.. ..d...d.. ..d...e.. ..dd.dd.. .........", "..ddddd.. ..d...d\x7f. ..d...w.. ..d...d\x7f. ..ddddd.. ...m.....", "..ddddd.. ..d...d.. ..d...d.. ..d...d.. ..ddddd.. .........", "..ddddd.. ..dnnnd.. ..dnnnd.. ..dnnnd.. ..ddddd.. ..bba....", "..fooo{.. ..gppp|.. ..gppp|.. ..gppp|.. ..hqqq}.. ..bba....", "......... ...ppp... ...ppp... ...ppp... ......... ..bbabbb.", "......... ...ppp... ...ppw... ...ppp... ......... ....abbb.", "......... ...ppp... ...ppp... ...ppp... ....a.... aaaaaaaaa", "......... ...ppp... ...ppp... ...ppp... ......... bbb.a....", "..irrrx.. ..jsssy.. ..jsssy.. ..jsssy.. ..ktttz.. bbb.abb..", "......... ...irx... ...jsy... ...ktz... ......... ....abb..", "......... ......... ....u.... ......... ......... ....abb.."]
        },
        marketStall: {
          size: [6, 5, 5],
          palette: ["Maple Log", "Pumpkin", "Red Chalk Slab|meta|rot1|top", "Red Chalk Slab", "Pine Wood Planks", "Chest", "Maple Wood Planks", "White Chalk Slab|meta|rot1|top", "White Chalk Slab", "Melon", "Bread Block", "Workbench", "Lantern", "Carved Pumpkin"],
          layers: ["aeeeea .f..l. ...... agggga b....n", "aeeeea ...... ...... abjkma ......", "aeeeea ...... ...... chchch dididi", "aeeeea chchch dididi ...... ......", "dididi ...... ...... ...... ......"]
        },
        gazebo: {
          size: [7, 8, 7],
          palette: ["Red Tulip", "Green Concrete Stairs|meta|rot3|bot|outerRight", "Green Concrete Stairs|meta|rot4|bot", "Green Concrete Stairs|meta|rot1|bot|outerLeft", "Maple Wood Planks", "White Concrete", "Maple Fence|meta|ns", "Green Concrete Stairs|meta|rot3|bot", "Green Concrete Stairs", "Maple Fence|meta|ew", "Maple Fence|meta|w", "Stone Bricks Stairs", "Lantern", "Green Concrete", "Maple Fence|meta|e", "Green Concrete Stairs|meta|rot3|bot|outerLeft", "Green Concrete Stairs|meta|rot2|bot", "Green Concrete Stairs|meta|rot1|bot|outerRight", "Pink Tulip"],
          layers: ["....... .eeeee. .eeeee. .eeeee. .eeeee. aeeeees ...l...", "....... .fjjjf. .g...g. .g.m.g. .g...g. .fk.of. .......", "....... .f...f. ....... ....... ....... .f...f. .......", "....... .f...f. ....... ....... ....... .f...f. .......", "bhhhhhp ceeeeeq ce...eq ce...eq ce...eq ceeeeeq diiiiir", "....... .bhhhp. .ceeeq. .ce.eq. .ceeeq. .diiir. .......", "....... ....... ..bhp.. ..cnq.. ..dir.. ....... .......", "....... ....... ....... ...m... ....... ....... ......."]
        },
        bakery: {
          size: [9, 8, 7],
          palette: ["Bricks", "Sandstone", "Red Chalk Stairs", "Cedar Stairs|meta|rot3|bot|outerRight", "Cedar Stairs|meta|rot4|bot", "Cedar Stairs|meta|rot1|bot|outerLeft", "Workbench", "Bread Block", "Poppy", "Glass", "White Chalk Stairs", "Cedar Stairs|meta|rot3|bot", "Cedar Wood Planks", "Cedar Stairs", "Chest", "Dandelion", "Lantern|meta|rot1|side", "Furnace", "Pink Tulip", "Daisy", "Cedar Stairs|meta|rot2|bot", "Cedar Stairs|meta|rot1|bot|outerRight", "Cedar Stairs|meta|rot3|bot|outerLeft", "Cedar Trapdoor|meta|rot2|open"],
          layers: ["aaaaaaaa. ago..rra. a......a. a......a. ahh...ha. aaa.aaaa. .ip..st..", "bbbbbbbb. b......bx b......j. b......j. b......bx bjj.bjjb. .........", "bbbbbbbb. b......bx b......j. b......j. b......bx bjjbbjjb. ...q.....", "bbbbbbbb. b......b. b......b. b......b. b......b. bbbbbbbb. ckckckck.", "dllllllw. emmmmmau. emmmmmmu. emmmmmmu. emmmmmmu. fnnnnnnv. .........", "......... .dlllla.. .emmmmu.. .emmmmu.. .fnnnnv.. ......... .........", "......... ......a.. ..llll... ..nnnn... ......... ......... .........", "......... ......a.. ......... ......... ......... ......... ........."]
        },
        bridge: {
          size: [3, 6, 11],
          palette: ["Stone Bricks", "Maple Stairs|meta|rot3|bot", "Maple Stairs", "Pine Fence", "Stone Bricks Stairs|meta|rot1|top", "Stone Bricks Stairs|meta|rot3|top", "Pine Log", "Maple Wood Planks", "Lantern", "Pine Fence|meta|s", "Pine Fence|meta|ns", "Pine Fence|meta|n"],
          layers: ["aaa ... ... ... ... ... ... ... ... ... aaa", "bbb aaa aaa ... ... ... ... ... aaa aaa ccc", "d.d bbb aaa ... ... ... ... ... aaa ccc d.d", "... d.d bbb eee ... ... ... fff ccc d.d ...", "... ... g.g hhh hhh hhh hhh hhh g.g ... ...", "... ... i.i j.j k.k k.k k.k l.l i.i ... ..."]
        },
        lookoutTower: {
          size: [5, 14, 5],
          palette: ["Pine Wood Planks", "Maple Log", "Pine Fence|meta|ns", "Red Concrete Stairs|meta|rot3|bot|outerRight", "Red Concrete Stairs|meta|rot4|bot", "Red Concrete Stairs|meta|rot1|bot|outerLeft", "Maple Ladder", "Pine Fence|meta|ew", "Red Concrete Stairs|meta|rot3|bot", "Red Concrete Stairs", "Lantern", "Pine Fence|meta|e", "Red Concrete Slab", "Red Concrete Stairs|meta|rot3|bot|outerLeft", "Red Concrete Stairs|meta|rot2|bot", "Red Concrete Stairs|meta|rot1|bot|outerRight"],
          layers: ["..... .b.b. ..... .b.b. .g...", "..... .b.b. ..... .b.b. .g...", "..... .b.b. ..... .b.b. .g...", "..... .bab. .a.a. .bab. .g...", "..... .b.b. ..... .b.b. .g...", "..... .b.b. ..... .b.b. .g...", "..... .b.b. ..... .b.b. .g...", "aaaaa aaaaa aaaaa aaaaa agaaa", "bhhhb c...c c.k.c c...c b.lhb", "b...b ..... ..... ..... b...b", "b...b ..... ..... ..... b...b", "diiin eaaao ea.ao eaaao fjjjp", "..... .din. .eao. .fjp. .....", "..... ..... ..m.. ..... ....."]
        },
        lighthouse: {
          size: [7, 16, 7],
          palette: ["Stone Bricks", "Pine Fence|meta|s", "Pine Fence|meta|ns", "Pine Fence|meta|n", "White Concrete", "Red Concrete", "Pine Fence|meta|e", "Red Concrete Stairs|meta|rot3|bot|outerRight", "Red Concrete Stairs|meta|rot4|bot", "Red Concrete Stairs|meta|rot1|bot|outerLeft", "Pine Fence|meta|ew", "Yellow Glass", "Red Concrete Stairs|meta|rot3|bot", "Red Concrete Stairs", "Stone Bricks Stairs", "Lantern|meta|rot1|side", "Glass", "Lantern", "Red Concrete Slab", "Red Concrete Stairs|meta|rot3|bot|outerLeft", "Red Concrete Stairs|meta|rot2|bot", "Red Concrete Stairs|meta|rot1|bot|outerRight", "Pine Fence|meta|w"],
          layers: ["....... ..eee.. .e...e. .e...e. .e...e. ..e.e.. ...o...", "....... ..eee.. .e...e. .e...e. .e...e. ..e.e.. .......", "....... ..fff.. .f...f. .f...f. .f...f. ..fff.. ...p...", "....... ..fff.. .f...f. .f...f. .f...f. ..fff.. .......", "....... ..eee.. .e...e. .e...e. .e...e. ..eee.. .......", "....... ..eee.. .e...e. .e...q. .e...e. ..eee.. .......", "....... ..fff.. .f...f. .f...f. .f...f. ..fff.. .......", "....... ..fff.. .f...f. .f...f. .f...f. ..fqf.. .......", "....... ..eee.. .e...e. .e...e. .e...e. ..eee.. .......", "....... ..eee.. .e...e. .e...e. .e...e. ..eee.. .......", ".aaaaa. aaaaaaa aaaaaaa aaaaaaa aaaaaaa aaaaaaa .aaaaa.", ".gkkkw. b.....b c.lll.c c.lrl.c c.lll.c d.....d .gkkkw.", "....... ....... ..lll.. ..l.l.. ..lll.. ....... .......", "....... .hmmmt. .ifffu. .ifffu. .ifffu. .jnnnv. .......", "....... ....... ..hmt.. ..ifu.. ..jnv.. ....... .......", "....... ....... ....... ...s... ....... ....... ......."]
        }
      },
      JO = new Map;

    function cK(OO, KO) {
      const pO = `${OO}|${KO}`;
      let XO = JO.get(pO);
      if (void 0 === XO) {
        const {
          size: bK,
          palette: eO,
          layers: lO
        } = SO[OO], vK = 90 === KO || 270 === KO, [CO, hO] = vK ? [bK[2], bK[0]] : [bK[0], bK[2]], DO = function(OO, KO, pO) {
          let XO = null,
            bK = null,
            eO = !1;
          switch (OO) {
            case 0:
              break;
            case 90:
              XO = KO - 1, eO = !0;
              break;
            case 180:
              XO = KO - 1, bK = pO - 1;
              break;
            case 270:
              bK = pO - 1, eO = !0;
              break;
            default:
              throw new Error(`Invalid rotation: ${OO}`)
          }
          return {
            xRotationMappedOrigin: XO,
            zRotationMappedOrigin: bK,
            shouldSwapXZ: eO
          }
        }(KO, CO, hO), MO = sO.for(YO.l), aK = eO.map((OO => (0, YO.h)(MO.turnBlockId((0, YO.p)(OO), KO, !1)))), oO = [];
        lO.forEach(((OO, KO) => {
          OO.split(" ").forEach(((OO, pO) => {
            for (let XO = 0; XO < OO.length; XO++)
              if ("." !== OO[XO]) {
                const bK = [HO(XO, pO, DO), KO, RO(XO, pO, DO)];
                oO.push({
                  offset: bK,
                  block: aK[OO.charCodeAt(XO) - "a".charCodeAt(0)]
                })
              }
          }))
        })), XO = {
          size: [CO, bK[1], hO],
          cells: oO
        }, JO.set(pO, XO)
      }
      return XO
    }
    const BO = {
      well: pO.p + "static/media/well.6059dda29952da474ade.webp",
      tent: pO.p + "static/media/tent.b33fdaeb9129e7931315.webp",
      marketStall: pO.p + "static/media/marketStall.6e04c605a5daeb43787d.webp",
      gazebo: pO.p + "static/media/gazebo.5db92096efe3e790b93c.webp",
      cottage: pO.p + "static/media/cottage.a2ba06bd20dc5625f673.webp",
      lookoutTower: pO.p + "static/media/lookoutTower.eeb0336a5e86d88661c4.webp",
      bridge: pO.p + "static/media/bridge.ee5a7ddef6d74a1c5c2d.webp",
      farmhouse: pO.p + "static/media/farmhouse.9e4425b8d81e6c8cf5d2.webp",
      bakery: pO.p + "static/media/bakery.678fc20dd5fba272965f.webp",
      greenhouse: pO.p + "static/media/greenhouse.b77eb0b4ade590f95053.webp",
      lighthouse: pO.p + "static/media/lighthouse.b8267661edfd4c5e7c77.webp",
      windmill: pO.p + "static/media/windmill.e2fd79cf51ec00d299c8.webp"
    };
    var ZO = pO(976);
    const GO = {
      small: "plotsGame:journalTierSmall",
      medium: "plotsGame:journalTierMedium",
      large: "plotsGame:journalTierLarge"
    };

    function qK(OO) {
      let {
        page: KO,
        building: pO,
        onBuild: XO,
        onPutAway: bK
      } = OO;
      const {
        t: eO
      } = (0, jK.D)(), {
        displayName: lO,
        tier: vK
      } = FO(KO.id), CO = cK(KO.id, 0).cells.length, hO = QO[KO.id], DO = "locked" === KO.state, MO = pO ? IO.d : IO.m;
      return (0, ZO.jsxs)("article", {
        className: TO()("PlotsJournalPage", {
          Locked: DO
        }),
        children: [(0, ZO.jsx)("h3", {
          className: "PlotsJournalPageName",
          children: eO(lO.translationKey)
        }), (0, ZO.jsxs)("div", {
          className: "PlotsJournalPageMeta",
          children: [eO(GO[vK]), " \xb7 ", eO("plotsGame:journalBlocks", {
            blocks: String(CO)
          })]
        }), (0, ZO.jsxs)("div", {
          className: "PlotsJournalSketch",
          children: [aK.map((OO => (0, ZO.jsx)("img", {
            className: TO()({
              Shown: OO === KO.id
            }),
            src: BO[OO],
            alt: "",
            draggable: !1
          }, OO))), "completed" === KO.state && (0, ZO.jsx)("span", {
            className: "PlotsJournalStamp",
            children: eO("plotsGame:journalBuilt")
          }), DO && (0, ZO.jsx)("span", {
            className: "PlotsJournalLock",
            children: (0, ZO.jsx)(NO.d, {
              name: "lock"
            })
          })]
        }), void 0 !== hO && "completed" !== KO.state && (0, ZO.jsx)("p", {
          className: "PlotsJournalNote",
          children: eO(hO)
        }), (0, ZO.jsxs)("div", {
          className: "PlotsJournalPageAction",
          children: ["locked" === KO.state && (0, ZO.jsx)("p", {
            className: "PlotsJournalHint",
            children: eO("plotsGame:journalLocked", {
              name: eO(FO(KO.unlockedBy).displayName.translationKey)
            })
          }), KO.active && (0, ZO.jsxs)(ZO.Fragment, {
            children: [(0, ZO.jsx)("p", {
              className: "PlotsJournalHint Building",
              children: eO("plotsGame:journalBuilding")
            }), (0, ZO.jsx)(IO.e, {
              onClick: bK,
              children: eO("plotsGame:journalPutAway")
            })]
          }), !DO && !KO.active && (0, ZO.jsx)(MO, {
            onClick: () => {
              XO(KO.id)
            },
            children: eO("plotsGame:placementBuild")
          })]
        })]
      })
    }

    function xK(OO) {
      let {
        className: KO,
        page: pO,
        hidden: XO,
        building: bK,
        journal: eO
      } = OO;
      return (0, ZO.jsxs)("div", {
        ref: OO => {
          null !== OO && (OO.inert = XO)
        },
        className: TO()("PlotsJournalSide", KO),
        children: [void 0 !== pO && (0, ZO.jsx)(qK, {
          page: pO,
          building: bK,
          onBuild: eO.build,
          onPutAway: eO.putAway
        }), void 0 === pO && (0, ZO.jsx)("div", {
          className: "PlotsJournalPage"
        })]
      })
    }
    var nO = pO(256),
      WO = pO(1531);

    function tK(OO) {
      return Math.cos((0, WO.n)(OO))
    }

    function kK(OO) {
      return (0, WO.A)(Math.acos(nO.e.clamp(OO, -1, 1)))
    }

    function UO(OO, KO, pO, XO, bK) {
      const eO = Math.abs(KO - OO),
        lO = (0, WO.A)(bK / (pO * Math.abs(Math.sin((0, WO.n)(OO))))),
        vK = 450 * Math.min(1, eO / XO),
        CO = lO > 0 ? 3 * eO / lO : 1 / 0;
      return Math.round(Math.max(120, Math.min(vK, CO)))
    }
    class OK {
      constructor() {
        this.samples = []
      }
      add(OO, KO) {
        for (this.samples.push({
            x: OO,
            at: KO
          }); KO - this.samples[0].at > 100;) this.samples.shift()
      }
      get() {
        const OO = this.samples[0],
          KO = this.samples[this.samples.length - 1];
        return KO.at > OO.at ? (KO.x - OO.x) / (KO.at - OO.at) : 0
      }
    }

    function KK(OO, KO) {
      return OO > KO && OO >= 600
    }

    function pK(OO) {
      return kK(new DOMMatrixReadOnly(getComputedStyle(OO).transform).m11)
    }

    function XK(OO, KO) {
      OO.style.transform = `rotateY(${-KO}deg)`, OO.classList.add("Turning")
    }

    function bp(OO) {
      let {
        journal: KO
      } = OO;
      const {
        t: pO
      } = (0, jK.D)(), XO = (0, uO.h)(AO, KO.getPages()), bK = (0, EO.e)(KK), [vK, CO] = (0, eO.useState)((() => function(OO) {
        const KO = OO.findIndex((OO => OO.active));
        return -1 !== KO ? KO : Math.max(0, OO.findIndex((OO => "open" === OO.state)))
      }(XO))), DO = (0, eO.useRef)(null), MO = (0, eO.useRef)(null), aK = (0, eO.useRef)({
        Forward: null,
        Back: null
      }), oO = bK ? 2 : 1, FO = bK ? 180 : 90, VO = vK - vK % oO, LO = VO > 0, QO = VO + oO < XO.length, zK = (0, eO.useCallback)((() => {
        const OO = MO.current;
        return null === OO ? VO : (MO.current = null, OO.animation.cancel(), (KO = aK.current[OO.direction]).style.transform = "", KO.classList.remove("Turning"), null === OO.next ? VO : (CO(OO.next), OO.next));
        var KO
      }), [VO]), fO = (0, eO.useCallback)(((OO, KO, pO, XO) => {
        const bK = aK.current[OO],
          eO = pK(bK),
          lO = KO === ("Forward" === OO) ? FO : 0;
        XK(bK, lO);
        const vK = bK.animate([{
          transform: `rotateY(${-eO}deg)`
        }, {
          transform: `rotateY(${-lO}deg)`
        }], {
          duration: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : UO(eO, lO, bK.offsetWidth, FO, lO > eO ? -pO : pO),
          easing: "cubic-bezier(0.25, 0.75, 0.5, 1)"
        });
        MO.current = {
          direction: OO,
          animation: vK,
          next: KO ? XO + ("Forward" === OO ? oO : -oO) : null
        }, vK.onfinish = () => {
          var OO;
          (null === (OO = MO.current) || void 0 === OO ? void 0 : OO.animation) === vK && zK()
        }
      }), [oO, FO, zK]), dO = (0, eO.useCallback)((OO => {
        if (null !== DO.current) return;
        const KO = zK();
        ("Forward" === OO ? KO + oO < XO.length : KO > 0) && fO(OO, !0, 0, KO)
      }), [zK, fO, oO, XO.length]);
      (0, eO.useEffect)((() => {
        KO.onOpened()
      }), [KO]), (0, eO.useEffect)((() => () => {
        var OO;
        null === (OO = MO.current) || void 0 === OO || OO.animation.cancel()
      }), []), (0, eO.useEffect)((() => {
        const OO = OO => {
          var KO;
          OO.pointerId !== (null === (KO = DO.current) || void 0 === KO ? void 0 : KO.pointerId) || DO.current.following || (DO.current = null)
        };
        return window.addEventListener("pointerup", OO), () => {
          window.removeEventListener("pointerup", OO)
        }
      }), []), (0, gK.b)((OO => ("ArrowLeft" === OO.code || "ArrowRight" === OO.code) && !(0, hO.isTypingInInput)()), (OO => {
        OO.stopPropagation(), dO("ArrowLeft" === OO.code ? "Back" : "Forward")
      }));
      const NO = (OO, KO, pO) => {
          const XO = function(OO, KO, pO, XO) {
            return (OO < 0 ? pO : XO) ? nO.e.clampAbs(OO, KO) : Math.sign(OO) * KO * (1 - 1 / (.55 * Math.abs(OO) / KO + 1))
          }(OO.base + pO, oO * OO.width, QO, LO);
          return "Forward" === KO ? Math.min(XO, 0) : Math.max(XO, 0)
        },
        YO = (OO, KO) => {
          const pO = DO.current;
          if (DO.current = null, null === pO.direction) return;
          pO.speed.add(OO, KO);
          const XO = pO.speed.get(),
            bK = NO(pO, pO.direction, OO - pO.x);
          fO(pO.direction, null !== function(OO, KO, pO, XO, bK) {
            if (Math.abs(KO) >= .3 ? Math.sign(KO) !== Math.sign(OO) : Math.abs(OO) < .5 * pO) return null;
            const eO = OO < 0 ? "Forward" : "Back";
            return ("Forward" === eO ? XO : bK) ? eO : null
          }(bK, XO, oO * pO.width, QO, LO), XO, VO)
        },
        wO = XO.some((OO => OO.active)),
        iK = (OO, pO, bK) => (0, ZO.jsx)(xK, {
          className: OO,
          page: pO >= 0 && pO < XO.length ? XO[pO] : void 0,
          hidden: bK,
          building: wO,
          journal: KO
        });
      return (0, ZO.jsx)(yK.d, {
        close: lO.j,
        togglePointerLock: !1,
        className: "PlotsJournalOverlay",
        children: (0, ZO.jsxs)("section", {
          className: TO()("PlotsJournal", {
            Spread: bK
          }),
          role: "dialog",
          "aria-modal": "true",
          "aria-label": pO("plotsGame:journalTitle"),
          children: [(0, ZO.jsx)(IO.i, {
            className: "PlotsJournalClose",
            onClick: lO.j
          }), (0, ZO.jsx)(eK, {
            direction: "Back",
            disabled: !LO,
            onTurn: dO
          }), (0, ZO.jsx)("div", {
            className: "PlotsJournalBookPages",
            onPointerDown: OO => {
              var KO;
              if (!OO.isPrimary || 0 !== OO.button || null !== MO.current && null !== OO.target.closest("button")) return;
              const pO = new OK;
              pO.add(OO.clientX, OO.timeStamp);
              const XO = aK.current.Forward.offsetWidth,
                bK = MO.current;
              MO.current = null;
              let eO = 0;
              if (null !== bK) {
                const KO = aK.current[bK.direction],
                  pO = pK(KO);
                bK.animation.cancel(), XK(KO, pO), eO = function(OO, KO, pO, XO) {
                  return (OO < 0 ? pO : XO) ? OO : Math.sign(OO) * KO * (1 / (1 - Math.min(Math.abs(OO) / KO, .99)) - 1) / .55
                }(function(OO, KO, pO, XO) {
                  return pO * (tK(KO) - tK("Forward" === OO ? 0 : XO))
                }(bK.direction, pO, XO, FO), oO * XO, QO, LO), OO.currentTarget.setPointerCapture(OO.pointerId)
              }
              DO.current = {
                pointerId: OO.pointerId,
                x: OO.clientX,
                y: OO.clientY,
                base: eO,
                width: XO,
                following: null !== bK,
                direction: null !== (KO = null === bK || void 0 === bK ? void 0 : bK.direction) && void 0 !== KO ? KO : null,
                speed: pO
              }
            },
            onPointerMove: OO => {
              const KO = DO.current;
              if (null === KO || OO.pointerId !== KO.pointerId) return;
              if (0 === OO.buttons) return void YO(OO.clientX, OO.timeStamp);
              const pO = OO.clientX - KO.x;
              !KO.following && function(OO, KO) {
                return Math.abs(OO) > 8 && Math.abs(OO) > Math.abs(KO)
              }(pO, OO.clientY - KO.y) && (KO.following = !0, KO.direction = pO < 0 ? "Forward" : "Back", OO.currentTarget.setPointerCapture(OO.pointerId)), null !== KO.direction && (KO.speed.add(OO.clientX, OO.timeStamp), XK(aK.current[KO.direction], function(OO, KO, pO, XO) {
                const bK = pO * tK("Forward" === OO ? 0 : XO) + KO;
                return nO.e.clamp(kK(bK / pO), 0, XO)
              }(KO.direction, NO(KO, KO.direction, pO), KO.width, FO)))
            },
            onPointerUp: OO => {
              var KO;
              OO.pointerId === (null === (KO = DO.current) || void 0 === KO ? void 0 : KO.pointerId) && YO(OO.clientX, OO.timeStamp)
            },
            onPointerCancel: OO => {
              const KO = DO.current;
              OO.pointerId === (null === KO || void 0 === KO ? void 0 : KO.pointerId) && (DO.current = null, null !== KO.direction && fO(KO.direction, !1, 0, VO))
            },
            children: (0, ZO.jsxs)("div", {
              className: "PlotsJournalSheet",
              children: [bK && iK("Left", VO - 2, !0), iK("Right", VO + 2 * oO - 1, !0), (0, ZO.jsxs)("div", {
                ref: OO => {
                  aK.current.Back = OO
                },
                className: "PlotsJournalLeaf Back",
                children: [iK("Recto", VO - 1, !0), bK && iK("Verso", VO, !1)]
              }), (0, ZO.jsxs)("div", {
                ref: OO => {
                  aK.current.Forward = OO
                },
                className: "PlotsJournalLeaf Forward",
                children: [iK("Recto", VO + oO - 1, !1), bK && iK("Verso", VO + oO, !0)]
              })]
            })
          }), (0, ZO.jsx)(eK, {
            direction: "Forward",
            disabled: !QO,
            onTurn: dO
          })]
        })
      })
    }

    function eK(OO) {
      let {
        direction: KO,
        disabled: pO,
        onTurn: XO
      } = OO;
      const {
        t: bK
      } = (0, jK.D)();
      return (0, ZO.jsx)("div", {
        className: TO()("PlotsJournalArrow", KO),
        children: (0, ZO.jsx)(IO.d, {
          disabled: pO,
          ariaLabel: bK("Forward" === KO ? "plotsGame:journalNextPage" : "plotsGame:journalPreviousPage"),
          onClick: () => {
            XO(KO)
          },
          children: (0, ZO.jsx)(NO.d, {
            name: "angle-up"
          })
        })
      })
    }
    var lK = pO(35130),
      vp = pO(1546),
      CK = pO(1588);
    const hK = "plotsStepChanged",
      DK = "plotsPlotChanged";
    class MK {
      constructor() {
        this.step = ["none"], this.plot = ["none"]
      }
      getStep() {
        return this.step
      }
      receiveStep(OO) {
        this.step = OO, DO.i.pl(hK, OO, !0)
      }
      getPlot() {
        return this.plot
      }
      receivePlot(OO) {
        this.plot = OO, DO.i.pl(DK, OO, !0)
      }
    }
    const ap = "KeyJ";

    function oK(OO) {
      let {
        hud: KO,
        journal: pO
      } = OO;
      const XO = (0, uO.h)(AO, pO.getPages()),
        bK = (0, uO.h)(hK, KO.getStep()),
        {
          isTouchScreen: eO
        } = (0, vK.l)(["isTouchScreen"]),
        {
          t: DO
        } = (0, jK.D)(),
        MO = null !== XO && "none" === bK[0];
      return (0, gK.b)((OO => null !== XO && OO.code === ap && !OO.repeat && !(0, hO.isTypingInInput)()), (OO => {
        (0, CO.v)(OO, MO, lO.o)
      })), MO ? (0, ZO.jsx)(lK.h, {
        placement: "topRight",
        children: (0, ZO.jsx)("div", {
          className: "PlotsJournalButtonContainer",
          children: (0, ZO.jsxs)("button", {
            type: "button",
            className: TO()("PlotsJournalButton SmallTextBold", {
              Touch: eO
            }),
            onClick: lO.o,
            children: [(0, ZO.jsx)("span", {
              className: "PlotsJournalButtonIcon",
              children: (0, ZO.jsx)(vp.b, {
                itemName: "Book",
                amount: 0
              })
            }), DO("plotsGame:journalButton"), !eO && (0, ZO.jsx)(CK.d, {
              className: "PlotsJournalButtonKey",
              keyCode: ap
            })]
          })
        })
      }) : null
    }
    var FK = pO(36809),
      VK = pO(36576),
      LK = pO(35409),
      QK = pO(8399),
      zp = pO(8416),
      AK = pO(36173);
    const fK = new Map([
        ["Bluebell", [.165, .749, .992]],
        ["Bread Block", [.776, .565, .161]],
        ["Bricks", [.584, .329, .239]],
        ["Bricks Slab", [.612, .345, .263]],
        ["Bricks Stairs", [.584, .329, .239]],
        ["Carved Pumpkin", [.929, .576, .173]],
        ["Cedar Stairs", [.318, .204, .098]],
        ["Cedar Trapdoor", [.239, .145, .071]],
        ["Cedar Wood Planks", [.318, .204, .098]],
        ["Chest", [.718, .49, .176]],
        ["Cracked Stone Bricks", [.522, .545, .573]],
        ["Daisy", [.969, .969, .969]],
        ["Dandelion", [1, .925, .31]],
        ["Dirt", [.522, .384, .302]],
        ["Furnace", [.502, .522, .545]],
        ["Glass", [.702, .902, .882]],
        ["Green Concrete", [.333, .416, .137]],
        ["Green Concrete Stairs", [.333, .416, .137]],
        ["Lantern", [.451, .451, .498]],
        ["Light Blue Carpet", [.231, .761, .902]],
        ["Light Blue Glass", [.263, .769, .925]],
        ["Maple Fence", [.682, .561, .353]],
        ["Maple Ladder", [.612, .471, .29]],
        ["Maple Leaves", [.173, .443, .09]],
        ["Maple Log", [.486, .388, .255]],
        ["Maple Stairs", [.682, .561, .353]],
        ["Maple Trapdoor", [.518, .38, .239]],
        ["Maple Wood Planks", [.682, .561, .353]],
        ["Melon", [.957, .918, .337]],
        ["Messy Stone Slab", [.475, .498, .529]],
        ["Mossy Stone Bricks", [.49, .514, .541]],
        ["Orange Tulip", [.969, .655, .2]],
        ["Pine Fence", [.475, .341, .263]],
        ["Pine Log", [.286, .192, .157]],
        ["Pine Slab", [.475, .341, .263]],
        ["Pine Stairs", [.475, .341, .263]],
        ["Pine Trapdoor", [.478, .357, .204]],
        ["Pine Wood Planks", [.475, .341, .263]],
        ["Pink Tulip", [1, .616, .753]],
        ["Poppy", [.929, .188, .173]],
        ["Pumpkin", [.929, .576, .173]],
        ["Red Carpet", [.69, .173, .145]],
        ["Red Chalk Bricks", [.761, .506, .463]],
        ["Red Chalk Bricks Slab", [.753, .502, .455]],
        ["Red Chalk Bricks Stairs", [.761, .506, .463]],
        ["Red Chalk Slab", [.761, .506, .463]],
        ["Red Chalk Stairs", [.761, .506, .463]],
        ["Red Concrete", [.58, .157, .141]],
        ["Red Concrete Slab", [.58, .157, .141]],
        ["Red Concrete Stairs", [.58, .157, .141]],
        ["Red Planks", [.608, .2, .184]],
        ["Red Tulip", [.949, .216, .298]],
        ["Red Wool", [.69, .173, .145]],
        ["Sandstone", [.988, .929, .686]],
        ["Smooth Stone Slab", [.522, .545, .573]],
        ["Stone Bricks", [.522, .545, .573]],
        ["Stone Bricks Slab", [.522, .545, .573]],
        ["Stone Bricks Stairs", [.522, .545, .573]],
        ["Torch", [.647, .439, .153]],
        ["White Carpet", [.98, .98, .98]],
        ["White Chalk Slab", [.906, .902, .867]],
        ["White Chalk Stairs", [.906, .902, .867]],
        ["White Concrete", [.89, .894, .894]],
        ["White Concrete Slab", [.89, .894, .894]],
        ["White Concrete Stairs", [.89, .894, .894]],
        ["White Tulip", [1, 1, 1]],
        ["White Wool", [.98, .98, .98]],
        ["Workbench", [.647, .439, .153]],
        ["Yellow Glass", [1, .82, .263]],
        ["Yellow Wool", [1, .827, .251]]
      ]),
      dK = [...LK.d.blockRemoveActionRoots, ...VK.b, ...QK.l, "Board", "Code Block", "Custom Lobby Block"],
      TK = /^(open|closed|(inner|outer)(Left|Right)|Stacked|books\d+|Roots|\w*GrassRoots|Growing|FreshlyGrown|empty|full)$/;
    let NK = null;

    function IK() {
      return NK ??= function() {
        const OO = yp(),
          KO = Math.max(...OO.map((OO => YO.l[OO].id))) + 1,
          pO = new Int32Array(KO),
          XO = new Int32Array(KO),
          bK = new Uint8Array(KO).fill(1),
          eO = new Uint8Array(KO),
          lO = new Uint8Array(KO),
          vK = new Array(KO).fill("Air"),
          CO = new Map,
          hO = OO => {
            let KO = CO.get(OO);
            return void 0 === KO && (KO = CO.size + 1, CO.set(OO, KO)), KO
          },
          DO = new Set(dK);
        for (const aK of OO) {
          var MO;
          const {
            id: OO,
            meta: KO,
            altActionable: CO,
            canBePlacedOver: oO
          } = YO.l[aK];
          pO[OO] = hO(gp(aK));
          const FO = KO.stairsCorner;
          if (null === FO) XO[OO] = pO[OO];
          else {
            const pO = FO.endsWith("Right");
            XO[OO] = hO(`${KO.rootName}|rot${pO?KO.rot%4+1:KO.rot}|${KO.halfblockPlacement}|${FO.replace("Right","Left")}`)
          }
          bK[OO] = oO ? 1 : 0, eO[OO] = CO || null !== KO.open || aK in AK.e || DO.has(KO.rootName) || void 0 !== (0, VK.f)(KO.rootName) ? 1 : 0;
          const {
            rootName: VO
          } = KO;
          lO[OO] = null !== KO.open || VK.b.includes(VO) || VO.includes("Bookshelf") || VO.includes("Mailbox") ? 1 : 0, vK[OO] = null !== (MO = (0, FK.f)(OO)) && void 0 !== MO ? MO : VO
        }
        return {
          kinds: pO,
          shapes: XO,
          empty: bK,
          inUse: eO,
          ownAltActionMessage: lO,
          placingItems: vK
        }
      }(), NK
    }

    function yp() {
      return Object.keys(YO.l).filter((OO => YO.l[OO].name === OO))
    }

    function gp(OO) {
      var KO;
      const pO = YO.l[OO],
        {
          rootName: XO,
          rot: bK
        } = pO.meta,
        [, ...eO] = (null !== (KO = pO.rootMetaDesc) && void 0 !== KO ? KO : OO).split("|"),
        lO = eO.filter((OO => !("meta" === OO || TK.test(OO) || (0, zp.s)(pO) && /^[nesw]+$/.test(OO) || QK.l.includes(XO) && /^[lrud]+$/.test(OO) || nO.G.includes(XO) && /^(left|right)$/.test(OO))));
      return [XO, ...lO].map((OO => "fenceGate" === pO.model && OO === `rot${bK}` ? "rot" + ((bK - 1) % 2 + 1) : OO)).join("|")
    }

    function uK(OO, KO) {
      const {
        kinds: pO,
        shapes: XO
      } = IK();
      return pO[OO] === pO[KO] || XO[OO] === XO[KO]
    }

    function EK(OO) {
      return 1 === IK().empty[OO]
    }

    function jp(OO) {
      return IK().placingItems[OO]
    }

    function YK(OO) {
      return fK.get(YO.l[OO].meta.rootName)
    }
    var wK = pO(8392),
      ip = pO(8411);
    const rp = [0, 0, 0, 1, 1, 1],
      PK = (0, wK.b)([
        [2, 0, 2, 6, 6, 6]
      ]),
      mp = (0, wK.b)([
        [3, 0, 3, 5, 5, 5]
      ]),
      sK = (0, wK.b)([
        [3, 3, 3, 5, 8, 5]
      ]),
      HK = [0, 1, 2, 3].map((OO => (0, wK.b)((0, wK.m)([
        [3, 2, 0, 5, 7, 3]
      ], OO))));

    function RK(OO) {
      const {
        Al: KO,
        model: pO,
        blockModel: XO,
        meta: bK
      } = YO.l[OO];
      return void 0 !== KO ? KO : "CentreCross" === pO ? PK : null !== XO && void 0 !== XO && XO.startsWith("torch") ? bK.halfblockPlacement === ip.e.side ? HK[bK.rot - 1] : bK.halfblockPlacement === ip.e.top ? sK : mp : rp
    }

    function SK(OO, KO) {
      return null === OO || null === KO ? OO === KO : OO[0] === KO[0] && OO[1] === KO[1] && OO[2] === KO[2]
    }

    function JK(OO) {
      return [OO[0] + .5, OO[1] + .5, OO[2] + .5]
    }
    var cp = pO(171);

    function BK(OO, KO) {
      const pO = cp.h.gM / 2;
      return OO[0] < KO[0] + pO && OO[0] + 1 > KO[0] - pO && OO[1] < KO[1] + cp.h.uD && OO[1] + 1 > KO[1] && OO[2] < KO[2] + pO && OO[2] + 1 > KO[2] - pO
    }

    function ZK(OO) {
      return OO + 1
    }

    function GK(OO, KO, pO, XO, bK) {
      const eO = Math.hypot(...KO.dir);
      if (!Number.isFinite(eO) || 0 === eO) return -1;
      const {
        from: lO,
        reach: vK,
        solid: CO
      } = KO, hO = [KO.dir[0] / eO, KO.dir[1] / eO, KO.dir[2] / eO], DO = null === CO ? vK : Math.min(vK, function(OO, KO, pO) {
        const XO = qp(OO, KO, pO);
        if (XO !== 1 / 0) return XO;
        return (pO[0] + .5 - OO[0]) * KO[0] + (pO[1] + .5 - OO[1]) * KO[1] + (pO[2] + .5 - OO[2]) * KO[2]
      }(lO, hO, CO) + .75);
      let MO = -1,
        aK = 1 / 0,
        oO = 1 / 0;
      for (let FO = 0; FO < OO.length; FO += 4) {
        const KO = [OO[FO], OO[FO + 1], OO[FO + 2]],
          eO = bK(FO) ? vK : DO;
        let CO = -1,
          VO = qp(lO, hO, KO);
        if (VO > eO) {
          const OO = [KO[0] + .5 - lO[0], KO[1] + .5 - lO[1], KO[2] + .5 - lO[2]];
          if (VO = OO[0] * hO[0] + OO[1] * hO[1] + OO[2] * hO[2], VO <= 0 || VO > eO) continue;
          if (CO = Math.hypot(OO[0] - VO * hO[0], OO[1] - VO * hO[1], OO[2] - VO * hO[2]), CO > .7 || !XO(FO)) continue
        }(CO < aK || CO === aK && VO < oO) && pO(FO) && (MO = FO, aK = CO, oO = VO)
      }
      return MO
    }

    function qp(OO, KO, pO) {
      let XO = 0,
        bK = 1 / 0;
      for (let eO = 0; eO < 3; eO++) {
        const lO = pO[eO] - OO[eO];
        if (0 === KO[eO]) {
          if (lO > 0 || lO + 1 < 0) return 1 / 0;
          continue
        }
        const vK = lO / KO[eO],
          CO = (lO + 1) / KO[eO];
        XO = Math.max(XO, Math.min(vK, CO)), bK = Math.min(bK, Math.max(vK, CO))
      }
      return XO <= bK ? XO : 1 / 0
    }
    var xp = pO(36431),
      nK = pO(36904);
    const WK = [1, 1, 1];
    class tp {
      constructor(OO) {
        this.api = OO, this.meshes = null, this.shown = null
      }
      show(OO) {
        if (!SK(OO, this.shown))
          if (this.shown = null === OO ? null : [OO[0], OO[1], OO[2]], null !== this.meshes)
            for (const KO of this.meshes) this.api.setGameMesh(KO, null === OO ? {
              visible: !1
            } : {
              anchor: OO,
              visible: !0
            });
          else if (null !== OO) {
          const KO = [xp.d, xp.d, xp.d, 0, 0, 0];
          this.meshes = [this.build([KO], xp.e, OO), this.build((0, xp.b)(), xp.i, OO)]
        }
      }
      dispose() {
        for (const KO of null !== (OO = this.meshes) && void 0 !== OO ? OO : []) {
          var OO;
          this.api.disposeGameMesh(KO)
        }
        this.meshes = null, this.shown = null
      }
      build(OO, KO, pO) {
        const XO = [],
          bK = [];
        for (const [eO, lO, vK, CO, hO, DO] of OO)(0, nK.f)(XO, bK, [CO + .5, hO + .5, DO + .5], [eO, lO, vK]);
        return this.api.createGameMesh({
          positions: XO,
          indices: bK
        }, {
          rgb: WK,
          alpha: KO,
          onTop: !0
        }, pO)
      }
    }
    class kp {
      constructor(OO) {
        this.api = OO, this.chunks = [], this.versions = [], this.lastCheckMs = -1 / 0
      }
      watch(OO) {
        const KO = cp.h.SX;
        this.chunks = [];
        for (let pO = 0; pO < OO.length; pO += 3) {
          const XO = Math.floor(OO[pO] / KO),
            bK = Math.floor(OO[pO + 1] / KO),
            eO = Math.floor(OO[pO + 2] / KO);
          this.watches(XO, bK, eO) || this.chunks.push(XO, bK, eO)
        }
        this.versions = [], this.lastCheckMs = -1 / 0, this.changed()
      }
      changed() {
        const OO = performance.now();
        if (OO - this.lastCheckMs < 100) return !1;
        this.lastCheckMs = OO;
        let KO = !1;
        for (let pO = 0; pO < this.chunks.length; pO += 3) {
          const OO = this.api.getChunkVersion(this.chunks[pO], this.chunks[pO + 1], this.chunks[pO + 2]);
          this.versions[pO / 3] !== OO && (this.versions[pO / 3] = OO, KO = !0)
        }
        return KO
      }
      watches(OO, KO, pO) {
        for (let XO = 0; XO < this.chunks.length; XO += 3)
          if (this.chunks[XO] === OO && this.chunks[XO + 1] === KO && this.chunks[XO + 2] === pO) return !0;
        return !1
      }
    }
    const UK = .35,
      Op = {
        size: .9,
        alpha: .35,
        crossed: !1
      },
      Kp = {
        size: 1.04,
        alpha: .45,
        crossed: !0
      },
      pp = [.95, .2, .15];
    class Xp {
      constructor() {
        this.groups = []
      }
      add(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : rp;
        for (const lO of this.groups)
          if (lp(lO, XO, bK)) return lO.cells.push(OO, KO, pO), void lO.boxes.push(eO);
        this.groups.push({
          rgb: XO,
          look: bK,
          cells: [OO, KO, pO],
          boxes: [eO]
        })
      }
      toArray() {
        return this.groups
      }
    }
    class bX {
      constructor(OO) {
        this.api = OO, this.shown = []
      }
      show(OO) {
        const KO = [];
        for (const pO of OO) {
          const OO = this.shown.findIndex((OO => {
            let {
              group: KO
            } = OO;
            return lp(KO, pO.rgb, pO.look) && vX(KO, pO)
          })); - 1 === OO ? KO.push(this.build(pO)) : (KO.push(this.shown[OO]), this.shown.splice(OO, 1))
        }
        this.dispose(), this.shown = KO
      }
      dispose() {
        for (const {
            meshes: OO
          }
          of this.shown)
          for (const KO of OO) this.api.disposeGameMesh(KO);
        this.shown = []
      }
      build(OO) {
        const {
          rgb: KO,
          look: pO,
          boxes: XO
        } = OO, bK = [KO[0] + (1 - KO[0]) * UK, KO[1] + (1 - KO[1]) * UK, KO[2] + (1 - KO[2]) * UK], eO = [this.buildMesh(OO.cells, KO, pO.alpha, ((OO, KO, bK, eO) => {
          ep(OO, KO, bK, XO[eO], pO.size, !1)
        })), this.buildMesh(OO.cells, bK, pO.alpha, ((OO, KO, bK, eO) => {
          ep(OO, KO, bK, XO[eO], pO.size, !0)
        }))];
        return pO.crossed && eO.push(this.buildMesh(OO.cells, KO, .9, ((OO, KO, XO) => {
          (0, nK.g)(OO, KO, XO, pO.size + .01, .12)
        }))), {
          group: OO,
          meshes: eO
        }
      }
      buildMesh(OO, KO, pO, XO) {
        const bK = [OO[0], OO[1], OO[2]],
          eO = [],
          lO = [];
        for (let vK = 0; vK < OO.length; vK += 3) XO(eO, lO, [OO[vK] - bK[0] + .5, OO[vK + 1] - bK[1] + .5, OO[vK + 2] - bK[2] + .5], vK / 3);
        return this.api.createGameMesh({
          positions: eO,
          indices: lO
        }, {
          rgb: [KO[0], KO[1], KO[2]],
          alpha: pO
        }, bK)
      }
    }

    function ep(OO, KO, pO, XO, bK, eO) {
      for (let lO = 0; lO < XO.length; lO += 6) {
        const vK = [0, 0, 0],
          CO = [0, 0, 0];
        for (let OO = 0; OO < 3; OO++) vK[OO] = pO[OO] + ((XO[lO + OO] + XO[lO + OO + 3]) / 2 - .5) * bK, CO[OO] = (XO[lO + OO + 3] - XO[lO + OO]) * bK;
        (0, nK.b)(OO, KO, vK, CO, eO)
      }
    }

    function lp(OO, KO, pO) {
      return OO.rgb[0] === KO[0] && OO.rgb[1] === KO[1] && OO.rgb[2] === KO[2] && OO.look === pO
    }

    function vX(OO, KO) {
      if (OO.cells.length !== KO.cells.length) return !1;
      for (let pO = 0; pO < OO.cells.length; pO++)
        if (OO.cells[pO] !== KO.cells[pO]) return !1;
      return OO.boxes.every(((OO, pO) => OO === KO.boxes[pO]))
    }
    class Cp {
      constructor(OO, KO, pO) {
        this.api = OO, this.localPlayerId = KO, this.pickNext = pO, this.turning = null, this.pending = null, this.tap = null, this.heading = [0, 1]
      }
      look(OO) {
        const [KO, , pO] = OO.cameraDirection, XO = Math.hypot(KO, pO);
        XO > .001 && (this.heading = [KO / XO, pO / XO])
      }
      tapped(OO, KO, pO) {
        const XO = ZK(this.api.getClientOption(this.localPlayerId, "blockReach")),
          {
            origin: bK,
            direction: eO
          } = this.api.getActionRay(),
          lO = [...bK],
          vK = [
            [lO, [lO[0] + eO[0] * XO, lO[1] + eO[1] * XO, lO[2] + eO[2] * XO]]
          ];
        null !== OO && vK.push([lO, JK(OO)]), this.tap = {
          lines: vK,
          next: KO,
          ms: pO
        }
      }
      filled(OO, KO) {
        this.tap = null, this.pending = {
          from: OO,
          ms: KO
        }, this.retry(KO)
      }
      arrived(OO, KO) {
        const {
          tap: pO
        } = this;
        if (null === pO || KO - pO.ms > 1500) return null;
        const XO = JK(OO);
        return SK(pO.next, OO) || pO.lines.some((OO => {
          let [KO, pO] = OO;
          return function(OO, KO, pO) {
            const XO = [pO[0] - KO[0], pO[1] - KO[1], pO[2] - KO[2]],
              bK = [OO[0] - KO[0], OO[1] - KO[1], OO[2] - KO[2]],
              eO = XO[0] ** 2 + XO[1] ** 2 + XO[2] ** 2,
              lO = 0 === eO ? 0 : Math.min(1, Math.max(0, (bK[0] * XO[0] + bK[1] * XO[1] + bK[2] * XO[2]) / eO));
            return Math.hypot(bK[0] - XO[0] * lO, bK[1] - XO[1] * lO, bK[2] - XO[2] * lO)
          }(XO, KO, pO) <= .9
        })) ? (this.tap = null, this.pending = {
          from: OO,
          ms: KO
        }, pO.ms) : null
      }
      retry(OO) {
        const {
          pending: KO
        } = this;
        if (null === KO) return;
        if (OO - KO.ms > 1500) return void(this.pending = null);
        const pO = this.pickNext(JK(KO.from), (OO => SK(OO, KO.from)));
        if (null === pO) return;
        this.pending = null;
        const {
          turning: XO
        } = this;
        if (null !== XO && OO < XO.endMs && SK(XO.to, pO)) return;
        const bK = this.api.getActionRay().origin,
          eO = [pO[0] + .5 - bK[0], pO[1] + .5 - bK[1], pO[2] + .5 - bK[2]],
          lO = Math.hypot(eO[0], eO[2]);
        if (lO < .3) {
          const OO = Math.max(lO, .001);
          eO[0] = this.heading[0] * OO, eO[2] = this.heading[1] * OO
        }
        this.api.turnCamera(eO, 250), this.turning = {
          to: pO,
          endMs: OO + 250
        }
      }
    }
    class hp {
      constructor(OO, KO, pO) {
        this.api = OO, this.localPlayerId = KO, this.juice = pO, this.ghostCells = [], this.palette = [], this.blockIds = [], this.occupiedCells = [], this.blueprint = "", this.layerY = 0, this.topLayerY = 0, this.layerCells = new Map, this.open = new Set, this.nextCells = [], this.lastFilled = null, this.lastSeenFilled = null, this.playerCells = [], this.aimed = null, this.pressMs = null, this.foreseen = new Map, this.turn = void 0, this.nextCell = null, this.chunkWatch = void 0, this.meshes = void 0, this.outline = void 0, this.chunkWatch = new kp(OO), this.meshes = new bX(OO), this.outline = new tp(OO), this.turn = new Cp(OO, KO, ((OO, KO) => this.pickNext(OO, KO)))
      }
      PX(OO) {
        const KO = "active" === OO[0] ? `${OO[1]}|${OO[3]}|${OO[4]}|${OO[5]}|${OO[6]}` : "";
        if ("active" !== OO[0]) "built" === OO[0] && "" !== this.blueprint && this.finishLayer(1 / 0), this.ghostCells = [], this.palette = [], this.occupiedCells = [];
        else {
          const [, , , , , , , pO, XO, bK, eO] = OO;
          KO !== this.blueprint ? (this.layerCells.clear(), this.topLayerY = pO) : pO === this.layerY ? this.burstUnlisted(XO) : pO > this.layerY && this.finishLayer(pO), this.layerY = pO, this.layerCells.has(pO) || this.layerCells.set(pO, XO.filter(Mp)), this.ghostCells = XO, this.palette = bK, this.occupiedCells = eO
        }
        KO !== this.blueprint && (this.blueprint = KO, this.open.clear(), this.foreseen.clear(), this.lastFilled = null, this.lastSeenFilled = null), this.blockIds = this.palette.map((OO => this.api.blockNameToBlockId(OO))), this.chunkWatch.watch([...this.ghostCells.filter(Mp), ...this.occupiedCells]), this.refresh()
      }
      finishLayer(OO) {
        this.burstUnlisted([]), OO > this.topLayerY && (this.juice.layerDone(this.layerCells.get(this.topLayerY)), this.topLayerY = OO)
      }
      KK() {
        if (this.chunkWatch.changed()) return void this.refresh();
        const OO = performance.now();
        let KO = !1;
        for (const [bK, eO] of this.foreseen) {
          var pO;
          if (OO - eO > 1e3) this.foreseen.delete(bK), KO = !0, (null === (pO = this.lastFilled) || void 0 === pO ? void 0 : pO.join()) === bK && (this.lastFilled = this.lastSeenFilled)
        }
        const XO = Dp(this.api.getPositionView(this.localPlayerId));
        (KO || XO.some(((OO, KO) => OO !== this.playerCells[KO]))) && this.showNext()
      }
      dispose() {
        this.meshes.dispose(), this.outline.dispose()
      }
      burstUnlisted(OO) {
        const KO = new Set;
        for (let bK = 0; bK < OO.length; bK += 4) KO.add(`${OO[bK]},${OO[bK+1]},${OO[bK+2]}`);
        const pO = [],
          {
            ghostCells: XO
          } = this;
        for (let bK = 0; bK < XO.length; bK += 4) {
          const OO = `${XO[bK]},${XO[bK+1]},${XO[bK+2]}`;
          !KO.has(OO) && this.open.delete(OO) && pO.push(this.filledCell(bK))
        }
        this.burst(pO)
      }
      refresh() {
        const {
          ghostCells: OO,
          palette: KO,
          occupiedCells: pO
        } = this, XO = new Xp, bK = new Set, eO = [], lO = [];
        for (let vK = 0; vK < OO.length; vK += 4) {
          const [pO, CO, hO, DO] = [OO[vK], OO[vK + 1], OO[vK + 2], OO[vK + 3]], MO = this.api.getBlockId(pO, CO, hO), aK = `${pO},${CO},${hO}`, oO = uK(this.blockIds[DO], MO);
          !oO && EK(MO) ? XO.add(pO, CO, hO, YK(KO[DO]), Op, RK(KO[DO])) : oO ? this.open.has(aK) && eO.push(this.filledCell(vK)) : XO.add(pO, CO, hO, pp, Kp), !oO && this.api.isBlockInLoadedChunk(pO, CO, hO) && (bK.add(aK), lO.push(pO, CO, hO, EK(MO) ? 0 : 1))
        }
        this.open = bK, this.nextCells = lO;
        for (let vK = 0; vK < pO.length; vK += 3) {
          const [OO, KO, bK] = [pO[vK], pO[vK + 1], pO[vK + 2]];
          EK(this.api.getBlockId(OO, KO, bK)) || XO.add(OO, KO, bK, pp, Kp)
        }
        this.meshes.show(XO.toArray()), this.burst(eO), this.showNext(), this.turn.retry(performance.now())
      }
      burst(OO) {
        const KO = performance.now(),
          pO = [];
        for (const [XO, bK, eO] of OO) {
          const OO = [XO, bK, eO];
          this.lastSeenFilled = OO, this.foreseen.delete(OO.join()) || pO.push(OO)
        }
        for (const XO of pO) {
          this.lastFilled = XO;
          const OO = this.turn.arrived(XO, KO);
          if (null !== OO)
            for (const [KO, pO] of this.foreseen) pO <= OO && this.foreseen.delete(KO)
        }
        this.juice.filled(OO)
      }
      showNext() {
        var OO;
        const KO = this.api.getPositionView(this.localPlayerId);
        this.playerCells.splice(0, 1 / 0, ...Dp(KO));
        const pO = this.lastFilled;
        this.nextCell = this.pickNext(null === pO ? [KO[0], KO[1] + 1, KO[2]] : JK(pO), (() => !1)), this.outline.show(null !== (OO = this.aimed) && void 0 !== OO ? OO : this.nextCell)
      }
      pickNext(OO, KO) {
        const pO = this.api.getPositionView(this.localPlayerId),
          {
            nextCells: XO
          } = this,
          bK = function(OO, KO, pO, XO, bK) {
            let eO = -1,
              lO = !1,
              vK = 1 / 0;
            for (let CO = 0; CO < OO.length; CO += KO) {
              const KO = XO(CO);
              if (lO && !KO || bK(CO)) continue;
              const hO = (OO[CO] + .5 - pO[0]) ** 2 + (OO[CO + 1] + .5 - pO[1]) ** 2 + (OO[CO + 2] + .5 - pO[2]) ** 2;
              (KO && !lO || hO < vK) && (eO = CO, lO = KO, vK = hO)
            }
            return eO
          }(XO, 4, OO, (OO => 1 === XO[OO + 3]), (OO => {
            const bK = [XO[OO], XO[OO + 1], XO[OO + 2]];
            return BK(bK, pO) || this.foreseen.has(bK.join()) || KO(bK)
          }));
        return -1 === bK ? null : [XO[bK], XO[bK + 1], XO[bK + 2]]
      }
      afterRender(OO) {
        var KO;
        this.turn.look(OO);
        const pO = this.api.getTargetedBlock();
        this.aimed = this.findAimed(null === pO ? null : pO.position), this.outline.show(null !== (KO = this.aimed) && void 0 !== KO ? KO : this.nextCell)
      }
      attemptAltAction(OO) {
        const KO = performance.now(),
          pO = this.findAimed(OO);
        if (null === pO && null !== this.nextCell && this.turn.tapped(OO, this.nextCell, KO), null !== pO || !(null === this.pressMs || KO - this.pressMs > 500)) return null !== pO && (this.foreseen.set(pO.join(), KO), this.lastFilled = pO, this.aimed = null, this.showNext(), this.turn.filled(pO, KO)), this.pressMs = KO, "preventPlacement";
        this.pressMs = null
      }
      findAimed(OO) {
        return function(OO, KO, pO, XO, bK, eO, lO) {
          const vK = OO.mhO(KO),
            CO = null === vK || null === OO.blockNameToBlockId(vK.name, !0) ? null : vK.name,
            hO = OO.getPositionView(KO),
            {
              origin: DO,
              direction: MO
            } = OO.getActionRay(),
            aK = GK(XO, {
              from: DO,
              dir: MO,
              reach: ZK(OO.getClientOption(KO, "blockReach")),
              solid: pO
            }, (KO => {
              const pO = [XO[KO], XO[KO + 1], XO[KO + 2]];
              return !uK(bK[XO[KO + 3]], OO.getBlockId(...pO)) && !lO.has(pO.join()) && OO.isBlockInLoadedChunk(...pO) && !BK(pO, hO)
            }), (OO => null === CO || CO === jp(bK[XO[OO + 3]])), (OO => null !== eO && XO[OO] === eO[0] && XO[OO + 1] === eO[1] && XO[OO + 2] === eO[2]));
          return -1 === aK ? null : [XO[aK], XO[aK + 1], XO[aK + 2]]
        }(this.api, this.localPlayerId, OO, this.ghostCells, this.blockIds, this.nextCell, this.foreseen)
      }
      endPress() {
        this.pressMs = null
      }
      filledCell(OO) {
        const {
          ghostCells: KO
        } = this, [pO, XO, bK] = YK(this.palette[KO[OO + 3]]);
        return [KO[OO], KO[OO + 1], KO[OO + 2], pO, XO, bK]
      }
    }

    function Dp(OO) {
      let [KO, pO, XO] = OO;
      const bK = cp.h.gM / 2;
      return [Math.floor(KO), Math.floor(pO), Math.floor(XO), Math.floor(KO - bK), Math.floor(KO + bK), Math.floor(pO + cp.h.uD), Math.floor(XO - bK), Math.floor(XO + bK)]
    }

    function Mp(OO, KO) {
      return KO % 4 !== 3
    }

    function aX(OO, KO, pO, XO, bK) {
      if (!OO.isBlockInLoadedChunk(KO, XO - 6, pO) || !OO.isBlockInLoadedChunk(KO, XO + 6 + bK, pO) || !OO.canModifyBlockAt(KO, XO, pO)) return NaN;
      let eO = XO - 1;
      if (0 !== OO.getBlockId(KO, eO, pO)) {
        for (; eO < XO + 6 && 0 !== OO.getBlockId(KO, eO + 1, pO);) eO++;
        return eO
      }
      for (; eO > XO - 6;)
        if (eO--, 0 !== OO.getBlockId(KO, eO, pO)) return eO;
      return NaN
    }

    function op(OO, KO, pO, XO, bK) {
      let eO = 0;
      for (let lO = XO + 1; lO <= XO + bK; lO++) 0 !== OO.getBlockId(KO, lO, pO) && eO++;
      return eO
    }

    function Fp(OO) {
      const KO = new Map;
      for (const lO of OO) {
        var pO;
        if (Number.isNaN(lO)) return null;
        KO.set(lO, (null !== (pO = KO.get(lO)) && void 0 !== pO ? pO : 0) + 1)
      }
      let XO = NaN,
        bK = 0;
      for (const [lO, vK] of KO)(vK > bK || vK === bK && lO < XO) && (XO = lO, bK = vK);
      let eO = 0;
      for (const lO of OO) eO += Math.abs(lO - XO);
      return eO
    }

    function Vp(OO, KO, pO, XO) {
      const {
        eye: bK,
        forward: eO,
        tanHalfFovX: lO,
        tanHalfFovY: vK
      } = OO, [CO, hO] = function(OO) {
        let [KO, pO, XO] = OO;
        const bK = Math.hypot(KO, XO),
          [eO, lO] = [XO / bK, -KO / bK];
        return [
          [eO, 0, lO],
          [pO * lO, XO * eO - KO * lO, -pO * eO]
        ]
      }(eO), [DO, MO] = [KO * lO, pO * vK], aK = eO[0] + DO * CO[0] + MO * hO[0], oO = eO[1] + MO * hO[1], FO = eO[2] + DO * CO[2] + MO * hO[2], VO = (XO - bK[1]) / oO;
      return VO > 0 && VO < 1 / 0 ? [bK[0] + VO * aK, bK[2] + VO * FO] : null
    }
    const Lp = "plotsBlueprintPlacementChanged",
      Qp = {
        size: .9,
        alpha: .2,
        crossed: !1
      };
    class zX {
      constructor(OO, KO) {
        this.api = OO, this.localPlayerId = KO, this.placing = null, this.view = null, this.camera = {
          eye: [0, 0, 0],
          forward: [0, 0, 1],
          tanHalfFovX: 1,
          tanHalfFovY: 1
        }, this.chunkWatch = void 0, this.meshes = void 0, this.start = OO => {
          var KO, pO, XO, eO;
          const lO = null !== (KO = null === (pO = this.placing) || void 0 === pO ? void 0 : pO.rotation) && void 0 !== KO ? KO : 0,
            {
              size: vK
            } = cK(OO, lO),
            CO = this.api.fV(this.localPlayerId),
            [hO, DO] = null !== (XO = null !== (eO = function(OO, KO, pO) {
              const [XO, bK, eO] = KO, [lO, vK, CO] = [Math.floor(pO[0]), Math.floor(pO[1]), Math.floor(pO[2])], [hO, DO] = [10 + Math.ceil(XO / 2), 10 + Math.ceil(eO / 2)], [MO, aK] = [lO - hO, CO - DO], [oO, FO] = [2 * hO + 1, 2 * DO + 1], VO = new Float64Array(oO * FO), LO = new Uint16Array(oO * FO);
              for (let fO = 0; fO < oO; fO++)
                for (let KO = 0; KO < FO; KO++) {
                  const pO = aX(OO, MO + fO, aK + KO, vK, bK);
                  VO[fO * FO + KO] = pO, Number.isNaN(pO) || (LO[fO * FO + KO] = op(OO, MO + fO, aK + KO, pO, bK))
                }
              const QO = [];
              let zK = null,
                AO = 1 / 0;
              for (let fO = 0; fO + XO <= oO; fO++)
                for (let OO = 0; OO + eO <= FO; OO++) {
                  const [KO, bK] = [MO + fO, aK + OO], vK = Math.hypot(KO + XO / 2 - pO[0], bK + eO / 2 - pO[2]);
                  if (vK > 10 || lO >= KO - 2 && lO < KO + XO + 2 && CO >= bK - 2 && CO < bK + eO + 2) continue;
                  QO.length = 0;
                  let hO = 0;
                  for (let pO = 0; pO < XO; pO++)
                    for (let KO = 0; KO < eO; KO++) QO.push(VO[(fO + pO) * FO + OO + KO]), hO += LO[(fO + pO) * FO + OO + KO];
                  const DO = Fp(QO);
                  if (null === DO) continue;
                  const oO = vK + 3 * (DO + hO);
                  oO < AO && (AO = oO, zK = [KO, bK])
                }
              return zK
            }(this.api, vK, CO)) && void 0 !== eO ? eO : this.cornerOnTarget(vK)) && void 0 !== XO ? XO : [Math.floor(CO[0]) + 2, Math.floor(CO[2])];
          this.placing = {
            id: OO,
            rotation: lO,
            corner: [hO, this.playerLevel(), DO],
            sent: null,
            refusals: 0,
            hover: null,
            drag: null
          }, this.update(), this.api.sendCommand(`${bK} preview`)
        }, this.rotate = () => {
          const {
            id: OO,
            rotation: KO,
            corner: pO
          } = this.placing, bK = XO[(XO.indexOf(KO) + 1) % XO.length], [eO, , lO] = cK(OO, KO).size, [vK, , CO] = cK(OO, bK).size;
          this.moveTo(pO[0] + Math.floor(eO / 2) - Math.floor(vK / 2), pO[2] + Math.floor(lO / 2) - Math.floor(CO / 2), bK)
        }, this.hoverAt = (OO, KO) => {
          this.placing.hover = [OO, KO], this.moveCentreTo(this.camera, OO, KO)
        }, this.endHover = () => {
          this.placing.hover = null
        }, this.beginDrag = (OO, KO) => {
          const pO = this.placing,
            {
              eye: XO,
              forward: bK,
              tanHalfFovX: eO,
              tanHalfFovY: lO
            } = this.camera,
            vK = {
              eye: [XO[0], XO[1], XO[2]],
              forward: [bK[0], bK[1], bK[2]],
              tanHalfFovX: eO,
              tanHalfFovY: lO
            },
            CO = pO.corner[1],
            hO = Vp(vK, OO, KO, CO);
          pO.hover = null, pO.drag = hO && {
            view: vK,
            ground: hO,
            corner: [pO.corner[0], pO.corner[2]],
            level: CO
          }
        }, this.dragTo = (OO, KO) => {
          const pO = this.placing.drag,
            XO = pO && Vp(pO.view, OO, KO, pO.level);
          null !== pO && null !== XO && this.moveTo(pO.corner[0] + Math.round(XO[0] - pO.ground[0]), pO.corner[1] + Math.round(XO[1] - pO.ground[1]))
        }, this.endDrag = () => {
          this.placing.drag = null
        }, this.tap = () => {
          const OO = this.view;
          OO.waiting || (OO.blocked ? this.pl({
            ...OO,
            refusals: ++this.placing.refusals
          }) : this.build())
        }, this.build = () => {
          const OO = this.placing,
            {
              id: KO,
              rotation: pO,
              corner: XO
            } = OO;
          this.api.sendCommand(`${bK} place ${KO} ${XO.join(" ")} ${pO}`), OO.sent = {
            atMs: performance.now(),
            corner: [...XO],
            rotation: pO,
            timedOut: !1
          }, this.update()
        }, this.stop = () => {
          null !== this.placing && (this.close(), this.api.sendCommand(`${bK} preview off`))
        }, this.chunkWatch = new kp(OO), this.meshes = new bX(OO)
      }
      getView() {
        return this.view
      }
      KK() {
        const OO = this.placing;
        null !== OO && (null !== OO.sent && !OO.sent.timedOut && performance.now() - OO.sent.atMs > 3e3 ? (OO.sent.timedOut = !0, this.update()) : (this.followPlayerLevel(OO) || this.chunkWatch.changed()) && this.update())
      }
      afterRender(OO) {
        const KO = this.placing;
        null !== KO && (! function(OO, KO) {
          for (let pO = 0; pO < 3; pO++) KO.eye[pO] = OO.cameraPosition[pO], KO.forward[pO] = OO.cameraDirection[pO];
          KO.tanHalfFovX = OO.tanHalfFovX, KO.tanHalfFovY = OO.tanHalfFovY
        }(OO, this.camera), null !== KO.hover && this.moveCentreTo(this.camera, KO.hover[0], KO.hover[1]))
      }
      PX(OO) {
        const KO = this.placing;
        if (null === KO || null === KO.sent || "active" !== OO[0]) return;
        const {
          sent: pO
        } = KO, [, XO, bK, eO, lO, vK, CO] = OO;
        bK && XO === KO.id && CO === pO.rotation && eO === pO.corner[0] && lO === pO.corner[1] && vK === pO.corner[2] && this.close()
      }
      endFromServer() {
        null !== this.placing && this.close()
      }
      dispose() {
        this.meshes.dispose()
      }
      cornerOnTarget(OO) {
        let [KO, , pO] = OO;
        const XO = this.api.getTargetedBlock();
        if (null === XO) return null;
        const [bK, , eO] = XO.position;
        return [bK - Math.floor(KO / 2), eO - Math.floor(pO / 2)]
      }
      playerLevel() {
        var OO;
        const [KO, pO, XO] = this.api.fV(this.localPlayerId);
        if (null !== (OO = this.api.getLocalPlayerMovement()) && void 0 !== OO && OO.onGround) return Math.ceil(pO - .01);
        const [bK, eO, lO] = [Math.floor(KO), Math.floor(pO), Math.floor(XO)];
        for (let vK = eO; vK >= eO - 2; vK--)
          if (this.api.isSolidToPlayerBlockId(this.api.getBlockId(bK, vK, lO))) return vK + 1;
        return eO
      }
      followPlayerLevel(OO) {
        if (Ap(OO)) return !1;
        const KO = this.playerLevel();
        return KO !== OO.corner[1] && (OO.corner[1] = KO, !0)
      }
      moveCentreTo(OO, KO, pO) {
        const XO = this.placing,
          bK = Vp(OO, KO, pO, XO.corner[1]);
        if (null !== bK) {
          const [OO, , KO] = cK(XO.id, XO.rotation).size;
          this.moveTo(Math.round(bK[0] - OO / 2), Math.round(bK[1] - KO / 2))
        }
      }
      moveTo(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.placing.rotation;
        const XO = this.placing;
        if (Ap(XO)) return;
        const [bK, eO, lO] = XO.corner;
        if (this.centreOnPlot(bK, lO) && !this.centreOnPlot(OO, KO, pO))
          if (this.centreOnPlot(OO, lO, pO)) KO = lO;
          else {
            if (!this.centreOnPlot(bK, KO, pO)) return;
            OO = bK
          } OO === bK && KO === lO && pO === XO.rotation || (XO.rotation = pO, XO.corner = [OO, eO, KO], this.update())
      }
      centreOnPlot(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.placing.rotation;
        const {
          id: XO,
          corner: bK
        } = this.placing, [eO, , lO] = cK(XO, pO).size;
        return this.api.canModifyBlockAt(OO + Math.floor(eO / 2), bK[1], KO + Math.floor(lO / 2))
      }
      close() {
        this.placing = null, this.meshes.dispose(), this.pl(null)
      }
      update() {
        const {
          id: OO,
          rotation: KO,
          corner: pO,
          refusals: XO
        } = this.placing, bK = new Xp, eO = [];
        let lO = !1,
          vK = 0;
        for (const {
            offset: DO,
            block: MO
          }
          of cK(OO, KO).cells) {
          const [OO, KO, XO] = [pO[0] + DO[0], pO[1] + DO[1], pO[2] + DO[2]];
          eO.push(OO, KO, XO);
          const CO = !this.api.canModifyBlockAt(OO, KO, XO),
            hO = this.api.getBlockId(OO, KO, XO),
            aK = !EK(hO) && !uK(this.api.blockNameToBlockId(MO), hO);
          lO ||= CO, vK += aK ? 1 : 0, CO || aK ? bK.add(OO, KO, XO, pp, Kp) : bK.add(OO, KO, XO, YK(MO), Qp, RK(MO))
        }
        this.chunkWatch.watch(eO), this.meshes.show(bK.toArray());
        const CO = this.view,
          hO = Ap(this.placing);
        (null === CO || void 0 === CO ? void 0 : CO.id) === OO && CO.blocked === lO && CO.toClear === vK && CO.waiting === hO && CO.refusals === XO || this.pl({
          id: OO,
          blocked: lO,
          toClear: vK,
          waiting: hO,
          refusals: XO
        })
      }
      pl(OO) {
        this.view = OO, DO.i.pl(Lp, OO, !0)
      }
    }

    function Ap(OO) {
      let {
        sent: KO
      } = OO;
      return null !== KO && !KO.timedOut
    }
    var fp = pO(3520),
      dp = pO(37499);

    function Tp(OO, KO, pO) {
      const XO = [255 * OO, 255 * KO, 255 * pO],
        [bK, eO, lO] = XO.map((OO => OO + .4 * (255 - OO)));
      return {
        texture: "square_particle",
        YO: 48,
        minLifeTime: .3 / dp.b,
        maxLifeTime: .55 / dp.b,
        minSize: .07,
        maxSize: .14,
        minEmitPower: 1,
        maxEmitPower: 1,
        emitRate: 0,
        gravity: [0, -14 * dp.b * dp.b, 0],
        colorGradients: [{
          timeFraction: 0,
          minColor: [...XO, 1],
          maxColor: [bK, eO, lO, 1]
        }, {
          timeFraction: 1,
          minColor: [...XO, 0],
          maxColor: [bK, eO, lO, 0]
        }],
        blendMode: fp.d.Standard
      }
    }
    const Np = {
      texture: "glint",
      mipmaps: !1,
      YO: 96,
      minLifeTime: .5 / dp.b,
      maxLifeTime: .9 / dp.b,
      minSize: .15,
      maxSize: .3,
      minEmitPower: 1,
      maxEmitPower: 1,
      emitRate: 0,
      gravity: [0, 2 * dp.b * dp.b, 0],
      colorGradients: [{
        timeFraction: 0,
        minColor: [255, 224, 97, 1],
        maxColor: [255, 166, 38, 1]
      }, {
        timeFraction: 1,
        minColor: [0, 0, 0, 1]
      }],
      blendMode: fp.d.OneOne
    };
    class Ip {
      constructor(OO, KO) {
        this.api = OO, this.localPlayerId = KO, this.chips = new Map, this.sparkles = null, this.points = new Float32Array(384)
      }
      filled(OO) {
        if (this.api.particlesEnabled())
          for (const [KO, pO, XO, bK, eO, lO] of OO.slice(0, 3)) {
            const OO = `${bK},${eO},${lO}`;
            let vK = this.chips.get(OO);
            void 0 === vK && (vK = this.api.createParticles(Tp(bK, eO, lO), {
              pos: [KO + .5, pO + .5, XO + .5]
            }), this.chips.set(OO, vK));
            for (let KO = 0; KO < 8; KO++) this.setPoint(KO, .9 * (Math.random() - .5), .9 * (Math.random() - .5), .9 * (Math.random() - .5), 1.5 + 1.5 * Math.random());
            vK.emitPoints([KO + .5, pO + .5, XO + .5], this.points, 8)
          }
      }
      layerDone(OO) {
        this.api.playSound(this.localPlayerId, "magicAccent2", .7, 1.1);
        const KO = OO.length / 3;
        if (0 === KO || !this.api.particlesEnabled()) return;
        const pO = Math.min(KO, 48),
          [XO, bK, eO] = [OO[0] + .5, OO[1] + 1, OO[2] + .5];
        let lO = 0;
        for (let vK = 0; vK < pO; vK++) {
          const CO = 3 * Math.floor(vK * KO / pO);
          for (let KO = 0; KO < 2; KO++) this.setPoint(lO++, OO[CO] + Math.random() - XO, OO[CO + 1] + 1 - bK, OO[CO + 2] + Math.random() - eO, .6 + .8 * Math.random())
        }
        this.sparkles ??= this.api.createParticles(Np, {
          pos: [XO, bK, eO]
        }), this.sparkles.emitPoints([XO, bK, eO], this.points, lO)
      }
      dispose() {
        var OO;
        for (const KO of this.chips.values()) KO.stop();
        this.chips.clear(), null === (OO = this.sparkles) || void 0 === OO || OO.stop(), this.sparkles = null
      }
      setPoint(OO, KO, pO, XO, bK) {
        const eO = 4 * OO;
        this.points[eO] = KO, this.points[eO + 1] = pO, this.points[eO + 2] = XO, this.points[eO + 3] = bK
      }
    }
    var yX = pO(1591);
    const gX = "SpecialAction1",
      upO = "KeyY",
      Ep = "KeyX";

    function jX(OO) {
      let {
        placement: KO
      } = OO;
      const pO = (0, uO.h)(Lp, KO.getView()),
        {
          t: XO
        } = (0, jK.D)(),
        {
          isTouchScreen: bK
        } = (0, vK.l)(["isTouchScreen"]),
        eO = null !== pO,
        lO = eO && !pO.blocked && !pO.waiting;
      if ((0, gK.b)((OO => eO && !OO.repeat && !(0, hO.isTypingInInput)() && !(0, CO.i)() && !bK), (OO => {
          const pO = function(OO, KO, pO) {
            if (OO === Ep) return KO.stop;
            if (OO === upO) return pO ? KO.build : wp;
            return yX.s[gX].includes(OO) ? KO.rotate : null
          }(OO.code, KO, lO);
          null !== pO && (OO.stopPropagation(), pO())
        })), !eO) return null;
      let DO = bK ? "plotsGame:placementHintTouch" : "plotsGame:placementHint";
      return pO.blocked ? DO = "plotsGame:placementOffPlot" : pO.toClear > 0 && (DO = "plotsGame:placementClear"), (0, ZO.jsx)(lK.h, {
        placement: "bottom",
        children: (0, ZO.jsxs)("div", {
          className: "PlotsPlacementCard",
          children: [(0, ZO.jsx)("div", {
            className: "PlotsPlacementCardTitle SmallTextBold",
            children: XO(FO(pO.id).displayName.translationKey)
          }), (0, ZO.jsx)("div", {
            className: TO()("PlotsPlacementCardHint SmallTextLight", {
              Nudge: pO.refusals > 0
            }),
            children: XO(DO)
          }, pO.refusals), (0, ZO.jsxs)("div", {
            className: "PlotsPlacementCardButtons",
            children: [(0, ZO.jsxs)(IO.d, {
              onClick: KO.rotate,
              children: [(0, ZO.jsx)(Yp, {
                noaAction: gX
              }), XO("plotsGame:placementRotate")]
            }), (0, ZO.jsxs)(IO.I, {
              onClick: KO.stop,
              children: [(0, ZO.jsx)(Yp, {
                keyCode: Ep
              }), XO("general:cancel")]
            }), (0, ZO.jsxs)(IO.m, {
              disabled: !lO,
              onClick: KO.build,
              children: [(0, ZO.jsx)(Yp, {
                keyCode: upO
              }), XO("plotsGame:placementBuild")]
            })]
          })]
        })
      })
    }

    function Yp(OO) {
      return (0, ZO.jsx)(CK.d, {
        className: "PlotsPlacementKey",
        ...OO
      })
    }

    function wp() {}
    var iX = pO(3730);
    class rX {
      constructor(OO) {
        this.placement = OO, this.press = null
      }
      down(OO) {
        if (null !== this.press) return !1;
        const {
          id: KO,
          mouse: pO,
          x: XO,
          y: bK,
          atMs: eO
        } = OO;
        return this.press = {
          id: KO,
          mouse: pO,
          x: XO,
          y: bK,
          atMs: eO,
          moved: !1
        }, pO || this.placement.beginDrag(OO.ndcX, OO.ndcY), !0
      }
      move(OO) {
        const KO = this.press;
        null !== KO && KO.id === OO.id && (KO.moved ||= Math.hypot(OO.x - KO.x, OO.y - KO.y) > 8), OO.mouse ? this.placement.hoverAt(OO.ndcX, OO.ndcY) : (null === KO || void 0 === KO ? void 0 : KO.id) === OO.id && this.placement.dragTo(OO.ndcX, OO.ndcY)
      }
      up(OO) {
        const KO = this.press;
        (null === KO || void 0 === KO ? void 0 : KO.id) === OO.id && (this.move(OO), this.end(), !KO.moved && (KO.mouse || OO.atMs - KO.atMs <= 250) && this.placement.tap())
      }
      cancel(OO) {
        var KO;
        (null === (KO = this.press) || void 0 === KO ? void 0 : KO.id) === OO && this.end()
      }
      DX(OO) {
        let {
          id: KO,
          mouse: pO
        } = OO;
        pO && this.placement.endHover(), this.cancel(KO)
      }
      end() {
        this.press.mouse || this.placement.endDrag(), this.press = null
      }
    }

    function Pp(OO) {
      let {
        placement: KO
      } = OO;
      return null === (0, uO.h)(Lp, KO.getView()) ? null : (0, ZO.jsx)(mX, {
        placement: KO
      })
    }

    function mX(OO) {
      let {
        placement: KO
      } = OO;
      (0, iX.b)(!0, !0, "PlotsPlacementLayer");
      const pO = (0, eO.useMemo)((() => new rX(KO)), [KO]);
      return (0, ZO.jsx)("div", {
        className: "PlotsPlacementLayer",
        onPointerDown: OO => {
          "mouse" === OO.pointerType && 0 !== OO.button || !pO.down(sp(OO)) || OO.currentTarget.setPointerCapture(OO.pointerId)
        },
        onPointerMove: OO => {
          pO.move(sp(OO))
        },
        onPointerUp: OO => {
          pO.up(sp(OO))
        },
        onPointerCancel: OO => {
          pO.cancel(OO.pointerId)
        },
        onLostPointerCapture: OO => {
          pO.cancel(OO.pointerId)
        },
        onPointerLeave: OO => {
          pO.DX(sp(OO))
        },
        "aria-hidden": !0
      })
    }

    function sp(OO) {
      const {
        left: KO,
        top: pO,
        width: XO,
        height: bK
      } = OO.currentTarget.getBoundingClientRect();
      return {
        id: OO.pointerId,
        mouse: "mouse" === OO.pointerType,
        x: OO.clientX,
        y: OO.clientY,
        ndcX: (OO.clientX - KO) / XO * 2 - 1,
        ndcY: 1 - (OO.clientY - pO) / bK * 2,
        atMs: OO.timeStamp
      }
    }
    var Hp = pO(1925),
      Rp = pO(35238),
      Sp = pO(1583),
      Jp = pO(1119);
    const cX = {
      own: "crown",
      shared: "user-group",
      other: "house"
    };

    function Bp(OO) {
      let {
        hud: KO
      } = OO;
      const pO = (0, uO.h)(DK, KO.getPlot()),
        [XO, bK] = (0, eO.useState)(null),
        lO = (0, Rp.l)(XO);
      if ("none" === pO[0]) return null;
      const [, vK, CO, hO, DO, MO] = pO;
      return (0, ZO.jsx)("div", {
        className: TO()("PlotsPlotBannerContainer", {
          Below: lO
        }),
        children: (0, ZO.jsx)(Zp, {
          plotX: vK,
          plotZ: CO,
          ownerName: hO,
          ownerId: DO,
          relation: MO,
          plaqueRef: bK
        }, `${vK},${CO}`)
      })
    }

    function Zp(OO) {
      var KO, pO;
      let {
        plotX: XO,
        plotZ: bK,
        ownerName: eO,
        ownerId: lO,
        relation: vK,
        plaqueRef: CO
      } = OO;
      const {
        t: hO
      } = (0, jK.D)(), DO = (0, Sp.i)("hiddenPlayerNames"), MO = (0, Sp.i)("players"), aK = null === lO ? null : null !== (KO = null === (pO = MO.byId[lO]) || void 0 === pO ? void 0 : pO.cosmetics) && void 0 !== KO ? KO : null, oO = hO("plotsGame:plotBannerCoords", {
        x: XO,
        z: bK
      }), FO = "own" === vK || null !== eO;
      return (0, ZO.jsxs)("div", {
        ref: CO,
        className: TO()("PlotsPlotBanner", {
          Own: "own" === vK,
          Shared: "shared" === vK
        }),
        role: "status",
        children: [(0, ZO.jsxs)("span", {
          className: TO()("PlotsPlotBannerSeal", {
            Face: null !== aK
          }),
          children: [null !== aK && (0, ZO.jsx)(Hp.c, {
            cosmetics: aK
          }), null === aK && (0, ZO.jsx)(NO.d, {
            name: cX[vK]
          })]
        }), (0, ZO.jsxs)("div", {
          className: "PlotsPlotBannerText",
          children: [(0, ZO.jsxs)("div", {
            className: "PlotsPlotBannerTitle SmallTextBold",
            children: ["own" === vK && hO("plotsGame:plotBannerYours"), "own" !== vK && null !== eO && hO("plotsGame:plotBannerOwner", {
              name: (0, Jp.f)(eO, DO)
            }), !FO && oO]
          }), FO && (0, ZO.jsxs)("div", {
            className: "PlotsPlotBannerCoords SmallTextLight",
            children: [oO, "shared" === vK && (0, ZO.jsx)("span", {
              className: "PlotsPlotBannerBadge",
              children: hO("plotsGame:plotBannerShared")
            })]
          })]
        })]
      })
    }

    function Gp(OO) {
      let {
        progress: KO,
        goal: pO
      } = OO;
      const XO = Math.min(KO, pO);
      return (0, ZO.jsxs)("div", {
        className: "PlotsProgress",
        children: [(0, ZO.jsx)("div", {
          className: "PlotsProgressBar",
          role: "progressbar",
          "aria-valuemin": 0,
          "aria-valuemax": pO,
          "aria-valuenow": XO,
          children: (0, ZO.jsx)("div", {
            className: "PlotsProgressBarFill",
            style: {
              transform: `scaleX(${XO/pO})`
            }
          })
        }), (0, ZO.jsxs)("span", {
          className: "PlotsProgressCount",
          children: [XO, "/", pO]
        })]
      })
    }

    function qX(OO) {
      return {
        translationKey: `plotsGame:${OO}`,
        actions: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : []
      }
    }
    const xX = {
      house: {
        icon: "house",
        titleKey: "plotsGame:starterLotHouseTitle",
        desktop: qX("starterLotHouseHint", ["alt-fire"]),
        touch: qX("starterLotHouseHint", ["alt-fire"]),
        plainKey: "plotsGame:starterLotHousePlain"
      },
      garden: {
        icon: "sparkle",
        titleKey: "plotsGame:starterLotGarden",
        desktop: qX("starterLotGardenHint", ["alt-fire"]),
        touch: qX("starterLotGardenHint", ["alt-fire"]),
        plainKey: "plotsGame:starterLotGardenPlain"
      },
      boulder: {
        icon: "hammer",
        titleKey: "plotsGame:starterLotBoulder",
        desktop: qX("starterLotBreakHint", ["primary-fire"]),
        touch: qX("starterLotBreakHintTouch"),
        plainKey: "plotsGame:starterLotBreakPlain"
      },
      fly: {
        icon: "angles-up",
        titleKey: "plotsGame:starterLotFly",
        desktop: qX("starterLotFlyHint", ["jump"]),
        touch: qX("starterLotFlyHintTouch"),
        plainKey: "plotsGame:starterLotFlyPlain"
      },
      backpack: {
        icon: "backpack",
        titleKey: "plotsGame:starterLotBackpack",
        desktop: qX("starterLotBackpackHint", ["OpenInventory"]),
        touch: qX("starterLotBackpackHintTouch"),
        plainKey: "plotsGame:starterLotBackpackPlain"
      },
      neighbour: {
        icon: "person",
        titleKey: "plotsGame:starterLotNeighbour",
        desktop: qX("starterLotNeighbourHint", ["forward", "left", "backward", "right"]),
        touch: qX("starterLotNeighbourHintTouch"),
        plainKey: "plotsGame:starterLotNeighbourPlain"
      }
    };

    function np(OO, KO, pO) {
      const {
        translationKey: XO,
        actions: bK
      } = pO ? KO.touch : KO.desktop;
      if (0 === bK.length) return OO(XO);
      const eO = [];
      for (const lO of bK) {
        const XO = (0, yX.o)(lO, pO),
          bK = yX.s[lO][0];
        if (null === XO && void 0 === bK) return OO(KO.plainKey);
        eO.push(null === XO ? (0, yX.j)(bK) : OO(XO.translationKey))
      }
      return OO(XO, {
        key: eO.join("")
      })
    }

    function Wp(OO) {
      let {
        hud: KO
      } = OO;
      const pO = (0, uO.h)(hK, KO.getStep()),
        {
          t: XO
        } = (0, jK.D)();
      return (0, ZO.jsxs)(lK.h, {
        placement: "bottom",
        children: ["step" === pO[0] && (0, ZO.jsx)(tX, {
          step: pO[1],
          progress: pO[2],
          goal: pO[3]
        }, pO[1]), "celebrate" === pO[0] && (0, ZO.jsx)(kX, {
          className: TO()("Celebrate", {
            Gold: "house" === pO[1]
          }),
          icon: "star",
          title: XO("house" === pO[1] ? "plotsGame:starterLotYourPlot" : "plotsGame:starterLotBriefDone")
        }, `celebrate-${pO[1]}`)]
      })
    }

    function tX(OO) {
      let {
        step: KO,
        progress: pO,
        goal: XO
      } = OO;
      const {
        isTouchScreen: bK
      } = (0, vK.l)(["isTouchScreen"]), {
        t: eO
      } = (0, jK.D)(), lO = xX[KO];
      return (0, ZO.jsxs)(kX, {
        icon: lO.icon,
        title: eO(lO.titleKey),
        children: [(0, ZO.jsx)("div", {
          className: "PlotsStepCardHint SmallTextLight",
          children: np(eO, lO, bK)
        }), XO > 1 && (0, ZO.jsx)(Gp, {
          progress: pO,
          goal: XO
        }), "backpack" === KO && bK && (0, ZO.jsx)(Up, {})]
      })
    }

    function kX(OO) {
      let {
        className: KO,
        icon: pO,
        title: XO,
        children: bK
      } = OO;
      return (0, ZO.jsxs)("div", {
        className: TO()("PlotsStepCard", KO),
        role: "status",
        children: [(0, ZO.jsx)("span", {
          className: "PlotsStepCardIcon",
          children: (0, ZO.jsx)(NO.d, {
            name: pO
          })
        }), (0, ZO.jsxs)("div", {
          className: "PlotsStepCardBody",
          children: [(0, ZO.jsx)("div", {
            className: "PlotsStepCardTitle SmallTextBold",
            children: XO
          }), bK]
        })]
      })
    }

    function Up() {
      return (0, eO.useEffect)((() => (vK.d.set({
        backpackPointerRequested: !0
      }), () => {
        vK.d.set({
          backpackPointerRequested: !1
        })
      })), []), null
    }
    const OX = function(OO, KO, pO, XO) {
      let {
        localPlayerId: bK
      } = XO;
      const vK = new MK;
      let CO = null,
        hO = null,
        DO = null,
        MO = null,
        aK = null;
      const oO = [];
      return {
        onCreate: OO => {
          CO = new Ip(OO, bK), hO = new hp(OO, bK, CO), DO = new hp(OO, bK, CO), MO = new zX(OO, bK), aK = new fO(OO, MO), oO.push((0, lO.q)((0, eO.createElement)(eO.Fragment, null, (0, eO.createElement)(Bp, {
            hud: vK
          }), (0, eO.createElement)(Wp, {
            hud: vK
          }), (0, eO.createElement)(oK, {
            hud: vK,
            journal: aK
          }), (0, eO.createElement)(Pp, {
            placement: MO
          }), (0, eO.createElement)(jX, {
            placement: MO
          })), {
            content: (0, eO.createElement)(bp, {
              journal: aK
            })
          }))
        },
        KK: () => {
          hO.KK(), DO.KK(), MO.KK(), aK.KK()
        },
        onPlayerAttemptAltAction: (OO, KO, pO, XO, bK, eO) => {
          var lO;
          if (null !== eO) return;
          const vK = void 0 === KO ? null : [KO, pO, XO];
          return null !== (lO = hO.attemptAltAction(vK)) && void 0 !== lO ? lO : DO.attemptAltAction(vK)
        },
        onPlayerClickUp: () => {
          hO.endPress(), DO.endPress()
        },
        onAfterRender: (OO, KO) => {
          MO.afterRender(KO), hO.afterRender(KO), DO.afterRender(KO)
        },
        onClose: () => {
          for (const OO of oO) OO();
          CO.dispose(), hO.dispose(), DO.dispose(), MO.dispose(), CO = null, hO = null, DO = null, MO = null, aK = null
        },
        onReceivedMessageFromServer: (OO, KO) => {
          if ("plotsStarterLot" === OO) vK.receiveStep(KO);
          else if ("plotsPlot" === OO) vK.receivePlot(KO);
          else if ("plotsStarterHouse" === OO) hO.PX(KO);
          else if ("plotsBlueprint" === OO) {
            const OO = KO;
            DO.PX(OO), MO.PX(OO)
          } else "plotsJournal" === OO ? aK.PX(KO) : "plotsJournalOpen" === OO ? aK.openFromServer() : "plotsPreviewEnd" === OO && MO.endFromServer()
        }
      }
    }
  },
  37499: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO,
      c: () => eO
    });
    const XO = 1 / .6,
      bK = {
        kind: "smokePuff"
      };
    class eO {
      constructor(OO, KO, pO) {
        this.style = OO, this.YO = KO, this.half = pO, this.particles = null, this.lastFrame = -1
      }
      emit(OO, KO, pO) {
        let eO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : this.style.count;
        return pO !== this.lastFrame && (this.lastFrame = pO, this.particles || (this.particles = OO.createParticles(function(OO, KO) {
          const [
            [pO, eO, lO],
            [vK, CO, hO]
          ] = OO.colours;
          return {
            texture: OO.soft ? bK : "square_particle",
            YO: KO,
            minLifeTime: OO.life[0] / XO,
            maxLifeTime: OO.life[1] / XO,
            minEmitPower: OO.power[0] * XO,
            maxEmitPower: OO.power[1] * XO,
            minSize: OO.size[0],
            maxSize: OO.size[1],
            emitRate: 0,
            gravity: [0, OO.lift * XO * XO, 0],
            dir1: [-OO.spread, 1, -OO.spread],
            dir2: [OO.spread, 1, OO.spread],
            colorGradients: [{
              timeFraction: 0,
              minColor: [pO, eO, lO, OO.alpha],
              maxColor: [vK, CO, hO, OO.alpha]
            }, {
              timeFraction: 1,
              minColor: [pO, eO, lO, 0],
              maxColor: [vK, CO, hO, 0]
            }],
            blendMode: OO.blendMode
          }
        }(this.style, this.YO), {
          pos: KO,
          half: this.half
        })), this.particles.moveTo(KO, this.half), this.particles.emit(eO), !0)
      }
      dispose() {
        var OO;
        null === (OO = this.particles) || void 0 === OO || OO.stop(), this.particles = null
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);