export const id = 10;
export const ids = [10];
export const modules = {
  37618: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => XO
    });
    const XO = function(OO, KO, pO) {
      let XO;
      return {
        onCreate: OO => {
          XO = OO
        },
        onPlayerAltAction: (OO, KO, pO, bK, eO, lO) => {
          lO && "Mesh" === XO.getEntityType(lO) && ("Permanent Upgrades" === XO.getEntityName(lO) ? XO.openShop(OO, !1, "Upgrades") : "Items" === XO.getEntityName(lO) ? XO.openShop(OO, !1, "Items") : "Prestige" === XO.getEntityName(lO) && XO.openShop(OO, !1, "Prestige"))
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);