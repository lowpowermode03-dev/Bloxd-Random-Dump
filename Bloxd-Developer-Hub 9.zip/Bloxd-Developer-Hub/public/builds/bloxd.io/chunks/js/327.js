export const id = 327;
export const ids = [327];
export const modules = {
  40403: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO
    });
    var XO = pO(37907);
    const bK = "clipPlaneVertex",
      eO = "#ifdef CLIPPLANE\nvertexOutputs.fClipDistance=dot(worldPos,uniforms.vClipPlane);\n#endif\n#ifdef CLIPPLANE2\nvertexOutputs.fClipDistance2=dot(worldPos,uniforms.vClipPlane2);\n#endif\n#ifdef CLIPPLANE3\nvertexOutputs.fClipDistance3=dot(worldPos,uniforms.vClipPlane3);\n#endif\n#ifdef CLIPPLANE4\nvertexOutputs.fClipDistance4=dot(worldPos,uniforms.vClipPlane4);\n#endif\n#ifdef CLIPPLANE5\nvertexOutputs.fClipDistance5=dot(worldPos,uniforms.vClipPlane5);\n#endif\n#ifdef CLIPPLANE6\nvertexOutputs.fClipDistance6=dot(worldPos,uniforms.vClipPlane6);\n#endif\n";
    XO.b.IncludesShadersStoreWGSL[bK] || (XO.b.IncludesShadersStoreWGSL[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40307: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO
    });
    var XO = pO(37907);
    const bK = "clipPlaneVertexDeclaration",
      eO = "#ifdef CLIPPLANE\nuniform vClipPlane: vec4<f32>;varying fClipDistance: f32;\n#endif\n#ifdef CLIPPLANE2\nuniform vClipPlane2: vec4<f32>;varying fClipDistance2: f32;\n#endif\n#ifdef CLIPPLANE3\nuniform vClipPlane3: vec4<f32>;varying fClipDistance3: f32;\n#endif\n#ifdef CLIPPLANE4\nuniform vClipPlane4: vec4<f32>;varying fClipDistance4: f32;\n#endif\n#ifdef CLIPPLANE5\nuniform vClipPlane5: vec4<f32>;varying fClipDistance5: f32;\n#endif\n#ifdef CLIPPLANE6\nuniform vClipPlane6: vec4<f32>;varying fClipDistance6: f32;\n#endif\n";
    XO.b.IncludesShadersStoreWGSL[bK] || (XO.b.IncludesShadersStoreWGSL[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40408: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(37907);
    const bK = "fogVertex",
      eO = "#ifdef FOG\n#ifdef SCENE_UBO\nvertexOutputs.vFogDistance=(scene.view*worldPos).xyz;\n#else\nvertexOutputs.vFogDistance=(uniforms.view*worldPos).xyz;\n#endif\n#endif\n";
    XO.b.IncludesShadersStoreWGSL[bK] || (XO.b.IncludesShadersStoreWGSL[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40313: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO
    });
    var XO = pO(37907);
    const bK = "fogVertexDeclaration",
      eO = "#ifdef FOG\nvarying vFogDistance: vec3f;\n#endif\n";
    XO.b.IncludesShadersStoreWGSL[bK] || (XO.b.IncludesShadersStoreWGSL[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40335: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(37907);
    const bK = "logDepthDeclaration",
      eO = "#ifdef LOGARITHMICDEPTH\nuniform logarithmicDepthConstant: f32;varying vFragmentDepth: f32;\n#endif\n";
    XO.b.IncludesShadersStoreWGSL[bK] || (XO.b.IncludesShadersStoreWGSL[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40431: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(37907);
    const bK = "logDepthVertex",
      eO = "#ifdef LOGARITHMICDEPTH\nvertexOutputs.vFragmentDepth=1.0+vertexOutputs.position.w;vertexOutputs.position.z=log2(max(0.000001,vertexOutputs.vFragmentDepth))*uniforms.logarithmicDepthConstant;\n#endif\n";
    XO.b.IncludesShadersStoreWGSL[bK] || (XO.b.IncludesShadersStoreWGSL[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  59129: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      skyVertexShaderWGSL: () => oO
    });
    var XO = pO(37907),
      bK = pO(40335),
      eO = pO(40307),
      lO = pO(40313),
      vK = pO(40403),
      CO = pO(40431),
      hO = pO(40408);
    const DO = "skyVertexShader",
      MO = "attribute position: vec3f;\n#ifdef VERTEXCOLOR\nattribute color: vec4f;\n#endif\nuniform world: mat4x4f;uniform view: mat4x4f;uniform viewProjection: mat4x4f;\n#ifdef POINTSIZE\nuniform pointSize: f32;\n#endif\nvarying vPositionW: vec3f;\n#ifdef VERTEXCOLOR\nvarying vColor: vec4f;\n#endif\n#include<logDepthDeclaration>\n#include<clipPlaneVertexDeclaration>\n#include<fogVertexDeclaration>\n#define CUSTOM_VERTEX_DEFINITIONS\n@vertex\nfn main(input : VertexInputs)->FragmentInputs {\n#define CUSTOM_VERTEX_MAIN_BEGIN\nvertexOutputs.position=uniforms.viewProjection*uniforms.world* vec4f(vertexInputs.position,1.0);var worldPos: vec4f=uniforms.world* vec4f(vertexInputs.position,1.0);vertexOutputs.vPositionW= worldPos.xyz;\n#include<clipPlaneVertex>\n#include<logDepthVertex>\n#include<fogVertex>\n#ifdef VERTEXCOLOR\nvertexOutputs.vColor=vertexInputs.color;\n#endif\n#define CUSTOM_VERTEX_MAIN_END\n}\n";
    XO.b.ShadersStoreWGSL[DO] || (XO.b.ShadersStoreWGSL[DO] = MO);
    const aK = [bK.c, eO.d, lO.d, vK.d, CO.e, hO.e];
    for (const FO of aK) XO.b.IncludesShadersStoreWGSL[FO.name] || (XO.b.IncludesShadersStoreWGSL[FO.name] = FO.shader);
    const oO = {
      name: DO,
      shader: MO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);