export const id = 270;
export const ids = [270];
export const modules = {
  39219: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      CharacterPreview: () => DO
    });
    var XO = pO(63),
      bK = pO(2209),
      eO = pO(1098),
      lO = pO(7899),
      vK = pO(35338),
      CO = pO(2883),
      hO = pO(976);
    const DO = (0, XO.memo)((0, XO.forwardRef)((function(OO, KO) {
      let {
        onReady: pO,
        onDrawn: DO,
        owner: MO = "other",
        forcedCosmetics: aK,
        GV: oO,
        emotePlaySeq: FO
      } = OO;
      const VO = (0, XO.useRef)(null),
        {
          width: LO,
          height: QO
        } = (0, bK.d)(VO),
        zK = (0, XO.useRef)(null),
        AO = (0, XO.useRef)({}),
        fO = (0, XO.useRef)({}),
        [dO, TO] = (0, XO.useState)(!1),
        NO = (0, XO.useRef)(pO);
      NO.current = pO;
      const IO = (0, XO.useRef)(DO);
      IO.current = DO;
      const yK = (0, XO.useRef)(null),
        gK = (0, XO.useRef)(!1),
        uO = (0, XO.useRef)(!1),
        EO = (0, XO.useCallback)((() => {
          const OO = zK.current;
          if (!OO || !IO.current || gK.current || !uO.current) return;
          const KO = {};
          yK.current = KO, queueMicrotask((() => {
            if (yK.current !== KO) return;
            const pO = Promise.all(eO.w.map((KO => OO.untilDrawn(KO)))).catch((OO => {
                console.error("Failed to draw the character preview", OO)
              })),
              XO = new Promise((OO => {
                setTimeout(OO, 1e4)
              }));
            Promise.race([pO, XO]).then((() => {
              var pO;
              zK.current !== OO || yK.current !== KO || gK.current || (gK.current = !0, null === (pO = IO.current) || void 0 === pO || pO.call(IO))
            }))
          }))
        }), []);
      return (0, XO.useImperativeHandle)(KO, (() => {
        const OO = (OO, KO) => {
          var pO;
          (AO.current[OO] = KO, null !== aK && void 0 !== aK && aK[OO]) || (null === (pO = zK.current) || void 0 === pO || pO.setCosmetic(OO, KO), EO())
        };
        return {
          updateCosmetic: OO,
          setAllCosmetics(KO) {
            for (const XO of eO.w) {
              var pO;
              OO(XO, null !== (pO = KO[XO]) && void 0 !== pO ? pO : (0, lO.d)(XO))
            }
          },
          isReady() {
            var OO, KO;
            return null !== (OO = null === (KO = zK.current) || void 0 === KO ? void 0 : KO.isReady()) && void 0 !== OO && OO
          },
          async ensureReadyForCapture(OO) {
            var KO;
            await (null === (KO = zK.current) || void 0 === KO ? void 0 : KO.untilDrawn(OO))
          },
          getDevTools() {
            var OO;
            return null !== (OO = zK.current) && void 0 !== OO && OO.isReady() ? zK.current.dev : null
          }
        }
      }), [aK, EO]), (0, XO.useEffect)((() => {
        const OO = CO.d.register(MO),
          KO = vK.e.openCharacter(VO.current);
        zK.current = KO;
        let pO = !0;
        return KO.ready.then((() => {
          pO && (TO(!0), NO.current())
        })).catch((OO => {
          console.error("Failed to set up the character preview", OO)
        })), () => {
          pO = !1, OO(), KO.close(), zK.current = null
        }
      }), []), (0, XO.useEffect)((() => {
        LO <= 0 || QO <= 0 || zK.current.resize(LO, QO)
      }), [LO, QO]), (0, XO.useEffect)((() => {
        if (!dO) return;
        const OO = fO.current;
        for (const KO of eO.w) {
          const pO = null === aK || void 0 === aK ? void 0 : aK[KO],
            XO = OO[KO];
          pO && pO !== XO ? zK.current.setCosmetic(KO, pO) : !pO && XO && AO.current[KO] && zK.current.setCosmetic(KO, AO.current[KO])
        }
        fO.current = {
          ...aK
        }, uO.current = !0, EO()
      }), [aK, dO, EO]), (0, XO.useEffect)((() => {
        dO && zK.current.playEmote(null !== oO && void 0 !== oO ? oO : null)
      }), [oO, FO, dO]), (0, hO.jsx)("div", {
        className: "CharCustomisationPreview",
        ref: VO
      })
    })))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);