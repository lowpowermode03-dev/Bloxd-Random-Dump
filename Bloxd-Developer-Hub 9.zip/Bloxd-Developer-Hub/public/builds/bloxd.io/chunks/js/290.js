export const id = 290;
export const ids = [290];
export const modules = {
  39801: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      _BasisTextureLoader: () => zK
    });
    var XO, bK = pO(38172),
      eO = pO(37061),
      lO = pO(38580),
      vK = pO(37889);

    function CO() {
      const OO = 0,
        KO = 1,
        pO = 2,
        XO = 3,
        bK = 6,
        eO = 8,
        lO = 9,
        vK = 10,
        CO = 14;
      let hO = null;

      function DO(OO, KO, pO, XO, bK) {
        const eO = OO.getImageTranscodedSizeInBytes(KO, pO, XO);
        let lO = new Uint8Array(eO);
        if (!OO.transcodeImage(lO, KO, pO, XO, 1, 0)) return null;
        if (bK) {
          lO = function(OO, KO, pO, XO) {
            const bK = new Uint16Array(4),
              eO = new Uint16Array(pO * XO),
              lO = pO / 4,
              vK = XO / 4;
            for (let CO = 0; CO < vK; CO++)
              for (let XO = 0; XO < lO; XO++) {
                const vK = KO + 8 * (CO * lO + XO);
                bK[0] = OO[vK] | OO[vK + 1] << 8, bK[1] = OO[vK + 2] | OO[vK + 3] << 8, bK[2] = (2 * (31 & bK[0]) + 1 * (31 & bK[1])) / 3 | (2 * (2016 & bK[0]) + 1 * (2016 & bK[1])) / 3 & 2016 | (2 * (63488 & bK[0]) + 1 * (63488 & bK[1])) / 3 & 63488, bK[3] = (2 * (31 & bK[1]) + 1 * (31 & bK[0])) / 3 | (2 * (2016 & bK[1]) + 1 * (2016 & bK[0])) / 3 & 2016 | (2 * (63488 & bK[1]) + 1 * (63488 & bK[0])) / 3 & 63488;
                for (let KO = 0; KO < 4; KO++) {
                  const lO = OO[vK + 4 + KO];
                  let hO = (4 * CO + KO) * pO + 4 * XO;
                  eO[hO++] = bK[3 & lO], eO[hO++] = bK[lO >> 2 & 3], eO[hO++] = bK[lO >> 4 & 3], eO[hO] = bK[lO >> 6 & 3]
                }
              }
            return eO
          }(lO, 0, OO.getImageWidth(KO, pO) + 3 & -4, OO.getImageHeight(KO, pO) + 3 & -4)
        }
        return lO
      }
      onmessage = MO => {
        if ("init" === MO.data.action) {
          if (MO.data.url) try {
            importScripts(MO.data.url)
          } catch (aK) {
            postMessage({
              action: "error",
              error: aK
            })
          }
          hO || (hO = BASIS({
            wasmBinary: MO.data.wasmBinary
          })), null !== hO && hO.then((OO => {
            BASIS = OO, OO.initializeBasis(), postMessage({
              action: "init"
            })
          }))
        } else if ("transcode" === MO.data.action) {
          const hO = MO.data.config,
            aK = MO.data.imageData,
            oO = new BASIS.BasisFile(aK),
            FO = function(OO) {
              const KO = OO.getHasAlpha(),
                pO = OO.getNumImages(),
                XO = [];
              for (let bK = 0; bK < pO; bK++) {
                const KO = {
                    levels: []
                  },
                  pO = OO.getNumLevels(bK);
                for (let XO = 0; XO < pO; XO++) {
                  const pO = {
                    width: OO.getImageWidth(bK, XO),
                    height: OO.getImageHeight(bK, XO)
                  };
                  KO.levels.push(pO)
                }
                XO.push(KO)
              }
              return {
                hasAlpha: KO,
                images: XO
              }
            }(oO);
          let VO = MO.data.ignoreSupportedFormats ? null : function(hO, DO) {
              let MO = null;
              hO.supportedCompressionFormats && (MO = hO.supportedCompressionFormats.astc ? vK : hO.supportedCompressionFormats.bc7 ? bK : hO.supportedCompressionFormats.s3tc ? DO.hasAlpha ? XO : pO : hO.supportedCompressionFormats.pvrtc ? DO.hasAlpha ? lO : eO : hO.supportedCompressionFormats.etc2 ? KO : hO.supportedCompressionFormats.etc1 ? OO : CO);
              return MO
            }(MO.data.config, FO),
            LO = !1;
          null === VO && (LO = !0, VO = FO.hasAlpha ? XO : pO);
          let QO = !0;
          oO.startTranscoding() || (QO = !1);
          const zK = [];
          for (let OO = 0; OO < FO.images.length && QO; OO++) {
            const KO = FO.images[OO];
            if (void 0 === hO.loadSingleImage || hO.loadSingleImage === OO) {
              let pO = KO.levels.length;
              !1 === hO.loadMipmapLevels && (pO = 1);
              for (let XO = 0; XO < pO; XO++) {
                const pO = KO.levels[XO],
                  bK = DO(oO, OO, XO, VO, LO);
                if (!bK) {
                  QO = !1;
                  break
                }
                pO.transcodedPixels = bK, zK.push(pO.transcodedPixels.buffer)
              }
            }
          }
          oO.close(), oO.delete(), LO && (VO = -1), QO ? postMessage({
            action: "transcode",
            success: QO,
            id: MO.data.id,
            fileInfo: FO,
            format: VO
          }, zK) : postMessage({
            action: "transcode",
            success: QO,
            id: MO.data.id
          })
        }
      }
    }! function(OO) {
      OO[OO.cTFETC1 = 0] = "cTFETC1", OO[OO.cTFETC2 = 1] = "cTFETC2", OO[OO.cTFBC1 = 2] = "cTFBC1", OO[OO.cTFBC3 = 3] = "cTFBC3", OO[OO.cTFBC4 = 4] = "cTFBC4", OO[OO.cTFBC5 = 5] = "cTFBC5", OO[OO.cTFBC7 = 6] = "cTFBC7", OO[OO.cTFPVRTC1_4_RGB = 8] = "cTFPVRTC1_4_RGB", OO[OO.cTFPVRTC1_4_RGBA = 9] = "cTFPVRTC1_4_RGBA", OO[OO.cTFASTC_4x4 = 10] = "cTFASTC_4x4", OO[OO.cTFATC_RGB = 11] = "cTFATC_RGB", OO[OO.cTFATC_RGBA_INTERPOLATED_ALPHA = 12] = "cTFATC_RGBA_INTERPOLATED_ALPHA", OO[OO.cTFRGBA32 = 13] = "cTFRGBA32", OO[OO.cTFRGB565 = 14] = "cTFRGB565", OO[OO.cTFBGR565 = 15] = "cTFBGR565", OO[OO.cTFRGBA4444 = 16] = "cTFRGBA4444", OO[OO.cTFFXT1_RGB = 17] = "cTFFXT1_RGB", OO[OO.cTFPVRTC2_4_RGB = 18] = "cTFPVRTC2_4_RGB", OO[OO.cTFPVRTC2_4_RGBA = 19] = "cTFPVRTC2_4_RGBA", OO[OO.cTFETC2_EAC_R11 = 20] = "cTFETC2_EAC_R11", OO[OO.cTFETC2_EAC_RG11 = 21] = "cTFETC2_EAC_RG11"
    }(XO || (XO = {}));
    const hO = {
      JSModuleURL: `${bK.k._DefaultCdnUrl}/basisTranscoder/1/basis_transcoder.js`,
      WasmModuleURL: `${bK.k._DefaultCdnUrl}/basisTranscoder/1/basis_transcoder.wasm`
    };
    let DO = null,
      MO = null,
      aK = 0;
    const oO = async () => (DO || (DO = new Promise(((OO, KO) => {
      MO ? OO(MO) : bK.k.LoadFileAsync(bK.k.GetBabylonScriptURL(hO.WasmModuleURL)).then((pO => {
        if ("function" !== typeof URL) return KO("Basis transcoder requires an environment with a URL constructor");
        const XO = URL.createObjectURL(new Blob([`(${CO})()`], {
          type: "application/javascript"
        }));
        MO = new Worker(XO), async function(OO, KO, pO) {
          return await new Promise(((XO, eO) => {
            const lO = KO => {
              "init" === KO.data.action ? (OO.removeEventListener("message", lO), XO(OO)) : "error" === KO.data.action && eO(KO.data.error || "error initializing worker")
            };
            OO.addEventListener("message", lO), OO.postMessage({
              action: "init",
              url: pO ? bK.k.GetBabylonScriptURL(pO) : void 0,
              wasmBinary: KO
            }, [KO])
          }))
        }(MO, pO, hO.JSModuleURL).then(OO, KO)
      })).catch(KO)
    }))), await DO), FO = async (OO, KO) => {
      const pO = OO instanceof ArrayBuffer ? new Uint8Array(OO) : OO;
      return await new Promise(((OO, XO) => {
        oO().then((() => {
          const bK = aK++,
            eO = KO => {
              "transcode" === KO.data.action && KO.data.id === bK && (MO.removeEventListener("message", eO), KO.data.success ? OO(KO.data) : XO("Transcode is not supported on this device"))
            };
          MO.addEventListener("message", eO);
          const lO = new Uint8Array(pO.byteLength);
          lO.set(new Uint8Array(pO.buffer, pO.byteOffset, pO.byteLength)), MO.postMessage({
            action: "transcode",
            id: bK,
            imageData: lO,
            config: KO,
            ignoreSupportedFormats: false
          }, [lO.buffer])
        }), (OO => {
          XO(OO)
        }))
      }))
    }, VO = (OO, KO) => {
      let pO = KO._gl?.TEXTURE_2D;
      OO.isCube && (pO = KO._gl?.TEXTURE_CUBE_MAP), KO._bindTextureDirectly(pO, OO, !0)
    }, LO = (OO, KO) => {
      const pO = OO.qb();
      for (let bK = 0; bK < KO.fileInfo.images.length; bK++) {
        const CO = KO.fileInfo.images[bK].levels[0];
        if (OO._invertVScale = OO.invertY, -1 === KO.format || KO.format === XO.cTFRGB565)
          if (OO.type = 10, OO.format = 4, !pO._features.basisNeedsPOT || Math.log2(CO.width) % 1 === 0 && Math.log2(CO.height) % 1 === 0) OO._invertVScale = !OO.invertY, OO.width = CO.width + 3 & -4, OO.height = CO.height + 3 & -4, OO.samplingMode = 2, VO(OO, pO), pO._uploadDataToTextureDirectly(OO, new Uint16Array(CO.transcodedPixels.buffer), bK, 0, 4, !0);
          else {
            const KO = new vK.e(pO, 2);
            OO._invertVScale = OO.invertY, KO.type = 10, KO.format = 4, KO.width = CO.width + 3 & -4, KO.height = CO.height + 3 & -4, VO(KO, pO), pO._uploadDataToTextureDirectly(KO, new Uint16Array(CO.transcodedPixels.buffer), bK, 0, 4, !0), pO._rescaleTexture(KO, OO, pO.scenes[0], pO._getInternalFormat(4), (() => {
              pO._releaseTexture(KO), VO(OO, pO)
            }))
          }
        else {
          OO.width = CO.width, OO.height = CO.height, OO.generateMipMaps = KO.fileInfo.images[bK].levels.length > 1;
          const XO = QO.GetInternalFormatFromBasisFormat(KO.format, pO);
          OO.format = XO, VO(OO, pO);
          const vK = KO.fileInfo.images[bK].levels;
          for (let KO = 0; KO < vK.length; KO++) {
            const eO = vK[KO];
            pO._uploadCompressedDataToTextureDirectly(OO, XO, eO.width, eO.height, eO.transcodedPixels, bK, KO)
          }!pO._features.basisNeedsPOT || Math.log2(OO.width) % 1 === 0 && Math.log2(OO.height) % 1 === 0 || (eO.b.Warn("Loaded .basis texture width and height are not a power of two. Texture wrapping will be set to Texture.CLAMP_ADDRESSMODE as other modes are not supported with non power of two dimensions in webGL 1."), OO._cachedWrapU = lO.e.CLAMP_ADDRESSMODE, OO._cachedWrapV = lO.e.CLAMP_ADDRESSMODE)
        }
      }
    }, QO = {
      JSModuleURL: hO.JSModuleURL,
      WasmModuleURL: hO.WasmModuleURL,
      GetInternalFormatFromBasisFormat: (OO, KO) => {
        let pO;
        switch (OO) {
          case XO.cTFETC1:
            pO = 36196;
            break;
          case XO.cTFBC1:
            pO = 33776;
            break;
          case XO.cTFBC4:
            pO = 33779;
            break;
          case XO.cTFASTC_4x4:
            pO = 37808;
            break;
          case XO.cTFETC2:
            pO = 37496;
            break;
          case XO.cTFBC7:
            pO = 36492
        }
        if (void 0 === pO) throw "The chosen Basis transcoder format is not currently supported";
        return pO
      },
      TranscodeAsync: FO,
      LoadTextureFromTranscodeResult: LO
    };
    class zK {
      constructor() {
        this.supportCascades = !1
      }
      loadCubeData(OO, KO, pO, XO, eO) {
        if (Array.isArray(OO)) return;
        const lO = KO.qb().getCaps(),
          vK = {
            supportedCompressionFormats: {
              etc1: !!lO.etc1,
              s3tc: !!lO.s3tc,
              pvrtc: !!lO.pvrtc,
              etc2: !!lO.etc2,
              astc: !!lO.astc,
              bc7: !!lO.bptc
            }
          };
        FO(OO, vK).then((OO => {
          const pO = OO.fileInfo.images[0].levels.length > 1 && KO.generateMipMaps;
          LO(KO, OO), KO.qb()._setCubeMapTextureParams(KO, pO), KO.isReady = !0, KO.onLoadedObservable.notifyObservers(KO), KO.onLoadedObservable.clear(), XO && XO()
        })).catch((OO => {
          bK.k.Warn("Failed to transcode Basis file, transcoding may not be supported on this device"), KO.isReady = !0, eO && eO(OO)
        }))
      }
      loadData(OO, KO, pO) {
        const XO = KO.qb().getCaps(),
          eO = {
            supportedCompressionFormats: {
              etc1: !!XO.etc1,
              s3tc: !!XO.s3tc,
              pvrtc: !!XO.pvrtc,
              etc2: !!XO.etc2,
              astc: !!XO.astc,
              bc7: !!XO.bptc
            }
          };
        FO(OO, eO).then((OO => {
          const XO = OO.fileInfo.images[0].levels[0],
            bK = OO.fileInfo.images[0].levels.length > 1 && KO.generateMipMaps;
          pO(XO.width, XO.height, bK, -1 !== OO.format, (() => {
            LO(KO, OO)
          }))
        })).catch((OO => {
          bK.k.Warn("Failed to transcode Basis file, transcoding may not be supported on this device"), bK.k.Warn(`Failed to transcode Basis file: ${OO}`), pO(0, 0, !1, !1, (() => {}), !0)
        }))
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);