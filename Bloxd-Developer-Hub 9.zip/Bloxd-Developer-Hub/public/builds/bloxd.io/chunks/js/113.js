export const id = 113;
export const ids = [113];
export const modules = {
  5671: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => mK
    });
    var XO = pO(63),
      bK = pO(1355),
      eO = pO(918),
      lO = pO.n(eO),
      vK = pO(243),
      CO = pO(5678),
      hO = pO(933),
      DO = pO(1344),
      MO = pO(3738),
      aK = pO(1271),
      oO = pO(2430),
      FO = pO(3746),
      VO = pO(1475),
      LO = pO(3732),
      QO = pO(1004),
      zK = pO(22),
      AO = pO(1329),
      fO = pO(1056),
      dO = pO(94),
      TO = pO(1051),
      NO = pO(1180),
      IO = pO(1077),
      yK = pO(5674),
      gK = pO(5680),
      uO = pO(976);

    function EO(OO) {
      let {
        pack: KO,
        view: pO,
        favourite: XO,
        notice: bK
      } = OO;
      const {
        width: eO,
        height: vK
      } = CO.t.thumb, {
        live: MO
      } = KO;
      return (0, uO.jsx)("div", {
        className: "ShaderPackCard",
        children: (0, uO.jsxs)("div", {
          className: "ShaderPackCardTile",
          children: [(0, uO.jsxs)(DO.LinkPreserveSearch, {
            to: (0, yK.Y)(KO.packId),
            className: "ShaderPackCardLink",
            children: [MO && (0, uO.jsx)("img", {
              className: "ShaderPackCardImage",
              src: (0, CO.u)(fO.clientSideServerUrls.s3Url, MO, pO, "thumb"),
              width: eO,
              height: vK,
              loading: "lazy",
              alt: "",
              draggable: !1
            }), MO && (0, uO.jsx)(gK.d, {
              item: MO
            }), !MO && (0, uO.jsx)("div", {
              className: "ShaderPackCardImage ShaderPackCardImagePending",
              children: (0, uO.jsx)(hO.d, {
                name: "hourglass"
              })
            }), (0, uO.jsxs)("div", {
              className: "ShaderPackCardText",
              children: [bK && (0, uO.jsx)("div", {
                className: lO()("ShaderPackCardNotice", {
                  Warning: "warning" === bK.tone
                }),
                children: bK.text
              }), (0, uO.jsx)("div", {
                className: "ShaderPackCardName SmallTextBold",
                children: KO.name
              })]
            })]
          }), MO && (0, uO.jsxs)("div", {
            className: "ShaderPackCardStats",
            children: [(0, uO.jsxs)("div", {
              className: "ShaderPackCardUses SmallTextBold",
              children: [(0, uO.jsx)(hO.d, {
                name: "download"
              }), (0, IO.L)(MO.downloads)]
            }), XO && (0, uO.jsx)(aK.w, {
              onClick: XO.onToggle,
              isLiked: !0 === XO.isFavourite,
              isLoading: null === XO.isFavourite
            })]
          })]
        })
      })
    }
    var jK = pO(5684);

    function YO(OO) {
      let {
        results: KO,
        loading: pO,
        failed: XO,
        onRetry: bK,
        view: eO,
        previewView: vK
      } = OO;
      const {
        t: CO
      } = (0, TO.D)(), hO = (0, jK.j)(), DO = Date.now(), MO = null === KO ? 0 : "owned" === KO.kind ? KO.packs.length : KO.page.results.length;
      return (0, uO.jsxs)("div", {
        className: lO()("ShaderPackBrowseResults", {
          Loading: pO && null !== KO
        }),
        children: [pO && null === KO && (0, uO.jsx)("div", {
          className: "ShaderPackBrowseMessage",
          children: (0, uO.jsx)(NO.e, {})
        }), XO && (0, uO.jsxs)("div", {
          className: "ShaderPackBrowseMessage",
          children: [CO("shaderPackListing:loadFailed"), (0, uO.jsx)(aK.d, {
            onClick: bK,
            children: CO("general:tryAgain")
          })]
        }), "listing" === (null === KO || void 0 === KO ? void 0 : KO.kind) && MO > 0 && (0, uO.jsx)("div", {
          className: "ShaderPackBrowseGrid",
          children: KO.page.results.map((OO => (0, uO.jsx)(EO, {
            pack: {
              packId: OO.packId,
              name: OO.name,
              live: OO
            },
            view: vK,
            favourite: {
              isFavourite: hO.isFavourite(OO.packId),
              onToggle: () => {
                hO.toggle(OO.packId)
              }
            }
          }, OO.packId)))
        }), "owned" === (null === KO || void 0 === KO ? void 0 : KO.kind) && MO > 0 && (0, uO.jsx)("div", {
          className: "ShaderPackBrowseGrid",
          children: KO.packs.map((OO => {
            var KO;
            return (0, uO.jsx)(EO, {
              pack: OO,
              view: vK,
              notice: OO.owner ? (0, yK.V)(OO.owner, !(null === (KO = OO.live) || void 0 === KO || !KO.renderId), DO, CO)[0] : void 0
            }, OO.packId)
          }))
        }), null !== KO && 0 === MO && (0, uO.jsx)("div", {
          className: "ShaderPackBrowseMessage",
          children: CO(wO(eO))
        })]
      })
    }

    function wO(OO) {
      return "mine" === OO.section ? "shaderPackListing:noOwnPacks" : (0, yK.v)(OO) ? "general:noResults" : "favourites" === OO.section ? "shaderPackListing:noFavourites" : "general:noResults"
    }
    var iK = pO(5698);
    const rK = 24,
      PO = {
        favourites: "general:favourites",
        mine: "shaderPackListing:mine"
      };

    function mK() {
      var OO, KO, pO, eO;
      const {
        t: NO
      } = (0, TO.D)(), IO = (0, DO.useNavigatePreserveSearch)(), gK = (0, bK.p)(), {
        userContext: EO,
        isUserContextUpdating: wO
      } = (0, QO.d)(), [mK, sO] = (0, jK.i)(), [HO, RO] = (0, jK.g)(), SO = (0, XO.useRef)(!1), [JO, cK] = (0, MO.n)(), BO = (0, yK.C)(JO), [ZO, GO] = (0, XO.useState)(null !== (OO = BO.searchQuery) && void 0 !== OO ? OO : ""), qK = (0, XO.useRef)(null), {
        searchQuery: xK
      } = BO;
      (0, XO.useEffect)((() => {
        GO(null !== xK && void 0 !== xK ? xK : ""), qK.current && (qK.current.value = null !== xK && void 0 !== xK ? xK : "")
      }), [xK]);
      const [nO, WO] = (0, XO.useState)(null), [tK, kK] = (0, XO.useState)(!1), [UO, OK] = (0, XO.useState)(!1), [KK, pK] = (0, XO.useState)(0), XK = (0, XO.useRef)(0), bp = JSON.stringify(BO), eK = (0, yK.k)();

      function lK() {
        null !== eK ? (IO(eK), zK.d.set({
          openEverythingMenuName: vK.o.SETTINGS,
          openSettingsCategory: "hX"
        })) : IO("/")
      }

      function vp(OO) {
        cK((KO => {
          (0, yK.db)(KO, {
            ...BO,
            pageNumber: 1,
            ...OO
          })
        }))
      }

      function CK() {
        const OO = ZO.trim() || null;
        vp({
          searchQuery: OO,
          ...null !== OO && !SO.current && (0, yK.n)(BO) && {
            withFeatures: [],
            withoutFeatures: []
          }
        })
      }(0, LO.e)(lK), (0, jK.c)(), (0, XO.useEffect)((() => {
        if (wO) return;
        const OO = ++XK.current,
          KO = JSON.parse(bp);
        kK(!0), OK(!1), async function(OO) {
          if ("mine" === OO.section) return {
            kind: "owned",
            packs: await AO.c.getOwnedShaderPacks(EO)
          };
          const KO = "favourites" === OO.section,
            pO = KO && (0, yK.n)(OO),
            XO = await AO.c.getShaderPacks(EO, {
              sort: KO ? yK.g : OO.sort,
              features: pO ? [] : OO.withFeatures,
              withoutFeatures: pO ? [] : OO.withoutFeatures,
              searchQuery: OO.searchQuery,
              pageNumber: OO.pageNumber,
              pageSize: rK,
              onlyFavourites: KO,
              banned: (0, yK.r)(EO) ? (0, yK.e)(OO.banned) : void 0
            });
          return {
            kind: "listing",
            page: XO
          }
        }(KO).then((KO => {
          XK.current === OO && WO(KO)
        })).catch((KO => {
          XK.current === OO && (console.error("Failed to get shader packs", KO), WO(null), OK(!0))
        })).finally((() => {
          XK.current === OO && kK(!1)
        }))
      }), [bp, EO, wO, KK]);
      const [hK, DK] = (0, XO.useState)(null), MK = null !== (pO = null === (eO = ("listing" === (null === nO || void 0 === nO ? void 0 : nO.kind) ? nO.page.results : (null !== (KO = null === nO || void 0 === nO ? void 0 : nO.packs) && void 0 !== KO ? KO : []).flatMap((OO => OO.live ? [OO.live] : [])))[0]) || void 0 === eO ? void 0 : eO.baselineVersion) && void 0 !== pO ? pO : null;
      (0, XO.useEffect)((() => {
        null !== MK && DK(MK)
      }), [MK]);
      const ap = "mine" === BO.section,
        oK = (0, yK.r)(EO),
        FK = OO => {
          "explore" !== BO.section && (OO.stopPropagation(), OO.preventDefault(), vp({
            section: "explore"
          }))
        };
      return (0, uO.jsxs)("div", {
        className: "ShaderPackBrowse AnimFadeIn",
        children: [(0, uO.jsx)(aK.c, {
          onClick: lK,
          children: NO(null === eK ? "homePage:backToGames" : "shaderPackListing:backToSettings")
        }), (0, uO.jsxs)("div", {
          className: "ShaderPackBrowseHeader",
          children: [(0, uO.jsxs)("div", {
            className: "ShaderPackBrowseHeaderRow",
            children: [(0, uO.jsx)("h1", {
              className: "VisuallyHidden",
              children: NO("shaderPackListing:title")
            }), (0, uO.jsxs)("div", {
              className: "ShaderPackBrowseTabs",
              children: [(0, uO.jsx)("div", {
                className: lO()("ShaderPackBrowseSort", {
                  Active: "explore" === BO.section
                }),
                onMouseDownCapture: FK,
                onTouchEndCapture: FK,
                children: (0, uO.jsx)(oO.b, {
                  options: CO.v.map((OO => ({
                    value: OO,
                    label: NO(yK.$[OO])
                  }))),
                  value: BO.sort,
                  onChange: OO => {
                    vp({
                      section: "explore",
                      sort: OO.value
                    })
                  }
                })
              }), Object.keys(PO).map((OO => (0, uO.jsx)(aK.S, {
                active: BO.section === OO,
                onClick: () => {
                  vp({
                    section: OO
                  })
                },
                children: NO(PO[OO])
              }, OO)))]
            }), !ap && (0, uO.jsx)("div", {
              className: "ShaderPackBrowseDivider"
            }), !ap && (0, uO.jsxs)("div", {
              className: "ShaderPackBrowseSearch",
              children: [(0, uO.jsx)("div", {
                className: "ShaderPackBrowseSearchIcon",
                children: (0, uO.jsx)(hO.d, {
                  name: "magnifying-glass"
                })
              }), (0, uO.jsx)(VO.e, {
                className: "ShaderPackBrowseSearchInput",
                placeholderText: NO("shaderPackListing:searchPlaceholder"),
                maxLength: CO.E,
                defaultValue: ZO,
                domRef: qK,
                onValueChange: GO,
                onEnter: CK
              }), (0, uO.jsx)(aK.d, {
                onClick: CK,
                children: NO("general:search")
              })]
            }), !ap && (0, uO.jsxs)(aK.S, {
              className: lO()("ShaderPackBrowseFilterToggle", {
                Open: HO
              }),
              pressed: HO,
              onClick: () => {
                RO(!HO)
              },
              children: [NO("shaderPackListing:filter"), " ", (0, uO.jsx)(hO.d, {
                name: HO ? "angle-up" : "angle-down"
              })]
            }), (0, uO.jsx)("div", {
              className: "ShaderPackBrowseSpace"
            }), dO.featureFlags.settings.canUseShaderPacks && (0, uO.jsxs)(aK.m, {
              onClick: () => {
                IO(yK._)
              },
              children: [(0, uO.jsx)(hO.d, {
                name: "upload"
              }), " ", NO("shaderPackListing:publish")]
            })]
          }), !ap && HO && (0, uO.jsxs)("div", {
            className: "ShaderPackBrowseFeatures",
            children: [yK.z.map((OO => {
              const KO = (0, yK.h)(BO, OO),
                pO = NO(yK.M[OO]);
              return (0, uO.jsx)(aK.S, {
                className: lO()("ShaderPackBrowseFeature", {
                  Without: "without" === KO
                }),
                active: "with" === KO,
                pressed: null !== KO,
                onClick: () => {
                  SO.current = !0, vp((0, yK.cb)(BO, OO))
                },
                children: (0, uO.jsxs)("span", {
                  className: "ShaderPackBrowseFeatureLabel",
                  children: [(0, uO.jsxs)("span", {
                    className: "ShaderPackBrowseFeatureReserve",
                    children: [(0, uO.jsx)(hO.d, {
                      name: "check"
                    }), " ", pO]
                  }), (0, uO.jsxs)("span", {
                    children: [null !== KO && (0, uO.jsx)(hO.d, {
                      name: "with" === KO ? "check" : "xmark"
                    }), " ", pO]
                  })]
                })
              }, OO)
            })), oK && (0, uO.jsx)(aK.S, {
              className: lO()("ShaderPackBrowseFeature", {
                Without: "without" === BO.banned
              }),
              active: "with" === BO.banned,
              pressed: null !== BO.banned,
              onClick: () => {
                const OO = "without" === BO.banned && !SO.current && (0, yK.n)(BO);
                vp({
                  banned: (0, yK.B)(BO.banned),
                  ...OO && {
                    withFeatures: [],
                    withoutFeatures: []
                  }
                })
              },
              children: (0, uO.jsxs)("span", {
                className: "ShaderPackBrowseFeatureLabel",
                children: [(0, uO.jsxs)("span", {
                  className: "ShaderPackBrowseFeatureReserve",
                  children: [(0, uO.jsx)(hO.d, {
                    name: "check"
                  }), " BANNED"]
                }), (0, uO.jsxs)("span", {
                  children: [null !== BO.banned && (0, uO.jsx)(hO.d, {
                    name: "with" === BO.banned ? "check" : "xmark"
                  }), " BANNED"]
                })]
              })
            })]
          })]
        }), (!ap || null !== hK) && (0, uO.jsx)("div", {
          className: "ShaderPackBrowseScenes",
          children: (0, uO.jsx)(iK.d, {
            selected: mK,
            onSelect: sO,
            imageUrl: OO => null === hK ? null : (0, CO.o)(fO.clientSideServerUrls.s3Url, hK, OO, "thumb")
          })
        }), (0, uO.jsx)(YO, {
          results: nO,
          loading: tK,
          failed: UO,
          onRetry: () => {
            pK((OO => OO + 1))
          },
          view: BO,
          previewView: mK
        }), "listing" === (null === nO || void 0 === nO ? void 0 : nO.kind) && (0, uO.jsx)(FO.e, {
          className: "ShaderPackBrowsePagination",
          page: nO.page.pageNumber,
          totalPages: nO.page.totalPages,
          onSetPage: OO => {
            cK((KO => {
              (0, MO.k)(KO, OO)
            }))
          },
          getPageHref: function(OO) {
            const KO = new URLSearchParams(JO);
            (0, MO.k)(KO, OO);
            const pO = KO.toString();
            return pO ? `${gK.pathname}?${pO}` : gK.pathname
          }
        })]
      })
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);