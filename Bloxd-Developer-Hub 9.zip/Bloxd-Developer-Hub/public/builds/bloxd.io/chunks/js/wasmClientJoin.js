export const id = 49;
export const ids = [49];
export const modules = {
  41328: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      joinRoom: () => vK,
      leaveHeldSeat: () => oO,
      resumeRoom: () => hO
    });
    var XO = pO(5632),
      bK = pO(3934),
      eO = pO(38917),
      lO = pO(39e3);
    async function vK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      try {
        return await CO(OO, KO, pO)
      } catch (bK) {
        var XO;
        const eO = await (null === (XO = KO.optionsAfterRefusal) || void 0 === XO ? void 0 : XO.call(KO, bK));
        if (!eO) throw bK;
        return CO(OO, {
          ...KO,
          joinOptions: eO
        }, {
          ...pO,
          early: void 0
        })
      }
    }
    async function CO(OO, KO, pO) {
      var bK;
      const {
        signal: eO
      } = pO, vK = () => (0, lO.k)(KO.endpoint, KO.roomName, KO.joinOptions, pO), {
        early: CO
      } = pO, hO = CO ? null !== (bK = await CO.take(eO)) && void 0 !== bK ? bK : await CO.reserveInstead(vK, eO) : await vK();
      return (0, XO.j)(eO), aK(OO, KO.endpoint, hO, pO, !1)
    }
    async function hO(OO, KO, pO, bK) {
      let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
      const vK = await (0, lO.g)(KO, pO, bK, eO);
      return (0, XO.j)(eO.signal), aK(OO, KO, vK, eO, !0)
    }

    function DO(OO, KO, pO) {
      const XO = (0, lO.n)(OO, KO);
      return pO.createSocket ? pO.createSocket(XO) : new WebSocket(XO)
    }

    function MO(OO, KO, pO) {
      var XO;
      let bK = !1;
      return (null !== (XO = OO.setTimer) && void 0 !== XO ? XO : (OO, KO) => {
        setTimeout(OO, KO)
      })((() => {
        bK || KO()
      }), pO), () => {
        bK = !0
      }
    }
    async function aK(OO, KO, pO, lO, vK) {
      const {
        signal: CO
      } = lO, hO = DO(KO, pO, lO);
      let aK = null,
        oO = null;
      const FO = [];
      let VO = !1,
        LO = !1;
      const QO = OO => {
        var KO;
        LO = !0, null === (KO = oO) || void 0 === KO || KO.reject(new eO.b("the room socket closed before the resume", "closed", OO.code))
      };
      vK && hO.addEventListener("close", QO);
      const zK = (OO, KO) => {
          var pO;
          if (OO === (vK ? bK.F.Resumed : bK.F.Activated)) VO = !0, null === (pO = oO) || void 0 === pO || pO.resolve();
          else if (!vK || OO !== bK.F.ResumeRefused && OO !== bK.F.Activated)
            if (OO === bK.F.Error) {
              var XO;
              null === (XO = oO) || void 0 === XO || XO.reject(new eO.b(`the room refused the join (code ${KO})`, "roomError", KO))
            } else {
              var lO;
              null === (lO = oO) || void 0 === lO || lO.reject(new eO.b("the room socket closed before the join", "closed", KO))
            }
          else {
            var CO;
            null === (CO = oO) || void 0 === CO || CO.reject(new eO.i("the core refused the resume: it held no game"))
          }
        },
        AO = OO.onConnection(((OO, KO, pO) => {
          null === aK ? FO.push([OO, KO, pO]) : OO === aK && zK(KO, pO)
        })),
        fO = OO.attachSocket(hO);
      if (null === fO) throw AO(), new eO.b("the core could not take the room socket", "attach");
      var dO;
      (aK = fO, vK) && (null === (dO = lO.onAttached) || void 0 === dO || dO.call(lO));
      let TO = !1;
      const NO = () => {
        if (TO) return;
        if (TO = !0, AO(), vK && (hO.removeEventListener("close", QO), !VO && !(null !== CO && void 0 !== CO && CO.aborted && (0, XO.c)(CO) instanceof eO.k))) return void(LO || OO.closeSocket(fO));
        VO && OO.leaveRoom(fO) || OO.sendRaw(fO, eO.g) ? MO(lO, (() => {
          OO.closeSocket(fO)
        }), eO.c) : OO.closeSocket(fO)
      };
      try {
        await new Promise(((KO, pO) => {
          const bK = () => {
            var KO;
            vK && (null === (KO = OO.flushNet) || void 0 === KO || KO.call(OO));
            pO((0, XO.c)(CO))
          };
          null === CO || void 0 === CO || CO.addEventListener("abort", bK, {
            once: !0
          }), oO = {
            resolve: () => {
              null === CO || void 0 === CO || CO.removeEventListener("abort", bK), KO()
            },
            reject: OO => {
              null === CO || void 0 === CO || CO.removeEventListener("abort", bK), pO(OO)
            }
          };
          for (const [OO, XO, eO] of FO.splice(0)) OO === aK && zK(XO, eO)
        }))
      } catch (IO) {
        throw NO(), IO
      }
      vK && hO.removeEventListener("close", QO);
      return {
        conn: fO,
        seat: pO,
        DX: NO,
        detach: () => {
          TO = !0, AO()
        }
      }
    }
    async function oO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
      try {
        const bK = DO(OO, await (0, lO.g)(OO, KO, pO, XO), XO);
        bK.binaryType = "arraybuffer", await new Promise((OO => {
          const KO = MO(XO, (() => {
            bK.close(), OO()
          }), eO.c);
          bK.addEventListener("open", (() => {
            bK.send(eO.g)
          })), bK.addEventListener("close", (() => {
            KO(), OO()
          }))
        }))
      } catch (bK) {
        console.warn("[bloxd-wasm-client] the held seat of a game left while it reconnected couldn't be released", bK)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);