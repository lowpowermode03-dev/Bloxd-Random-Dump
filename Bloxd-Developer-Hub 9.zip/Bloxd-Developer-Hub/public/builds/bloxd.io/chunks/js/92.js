export const id = 92;
export const ids = [92];
export const modules = {
  4059: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => MO,
      e: () => DO,
      g: () => aK
    });
    pO(4061);
    var XO = pO(1051),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(1195),
      vK = (pO(63), pO(3618)),
      CO = pO(933),
      hO = pO(976);

    function DO(OO) {
      let {
        children: KO,
        label: pO,
        className: bK,
        circleInfoText: vK,
        disabled: DO,
        onLabelClick: MO
      } = OO;
      const {
        t: aK
      } = (0, XO.D)(), oO = (0, hO.jsxs)("div", {
        className: eO()("Label", {
          ClickableLabel: void 0 !== MO
        }),
        onClick: MO,
        children: [aK(pO), vK && (0, hO.jsx)(CO.d, {
          name: "circle-info"
        })]
      });
      return (0, hO.jsxs)("div", {
        className: eO()("LabeledInput", {
          [bK]: bK,
          DisabledLabelInput: DO
        }),
        children: [vK && (0, hO.jsx)(lO.g, {
          tooltipInner: (0, hO.jsx)("div", {
            className: "LabeledInputTooltip",
            children: aK(vK)
          }),
          children: oO
        }), !vK && oO, KO]
      })
    }

    function MO(OO) {
      let {
        checked: KO,
        setChecked: pO
      } = OO;
      return (0, hO.jsx)("div", {
        className: "OtherInput ClickableOtherInput",
        "data-pad-focusable": !0,
        onClick: OO => {
          pO(!KO)
        },
        children: (0, hO.jsx)(vK.c, {
          checked: KO,
          onChange: OO => {
            pO(OO.target.checked)
          },
          disabled: !1
        })
      })
    }

    function aK(OO) {
      let {
        checked: KO,
        setChecked: pO,
        disabled: XO
      } = OO;
      return (0, hO.jsx)("div", {
        className: eO()("SwitchContainer", {
          SwitchContainerDisabled: XO
        }),
        onClick: () => {
          XO || pO(!KO)
        },
        children: (0, hO.jsx)(vK.c, {
          className: "SwitchCheckbox",
          checked: KO,
          onChange: OO => {
            pO(OO.target.checked)
          },
          disabled: !!XO
        })
      })
    }
  },
  4070: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(1051),
      lO = pO(976);
    const vK = ["dayNight", "fallDamage", "survivalGuns"],
      CO = [...vK, "tpRequests", "spawnProtection", "spawnReset", "smpMarketplace"];

    function hO(OO) {
      let {
        callbacks: KO,
        disabled: pO,
        advancedMode: XO,
        hideWrapper: hO
      } = OO;
      const {
        t: MO
      } = (0, eO.D)(), aK = (0, lO.jsx)("div", {
        className: bK()("PluginsGrid", {
          SectionBody: !hO
        }),
        children: (XO ? CO : vK).map((OO => (0, lO.jsx)(DO, {
          plugin: OO,
          callbacks: KO[OO],
          disabled: pO
        }, OO)))
      });
      return hO ? aK : (0, lO.jsxs)("div", {
        className: "BloxdForm",
        children: [(0, lO.jsx)("div", {
          className: "SectionTitle",
          children: MO("worldBuilder:pluginsSection")
        }), aK]
      })
    }

    function DO(OO) {
      let {
        plugin: KO,
        callbacks: {
          isEnabled: pO,
          WE: XO
        },
        disabled: vK
      } = OO;
      const {
        t: CO
      } = (0, eO.D)(), hO = pO();
      return (0, lO.jsxs)("div", {
        className: bK()("PluginCard", {
          PluginCardEnabled: hO,
          PluginCardDisabledForm: vK
        }),
        "data-pad-focusable": !0,
        "aria-disabled": vK || void 0,
        onClick: () => {
          vK || XO(!hO)
        },
        children: [(0, lO.jsx)("div", {
          className: "PluginCardIcon",
          children: (0, lO.jsx)("img", {
            src: `/textures/games/classic/customGames/${KO}.png`,
            alt: KO
          })
        }), (0, lO.jsxs)("div", {
          className: "PluginCardBody",
          children: [(0, lO.jsx)("div", {
            className: "PluginCardTitle",
            children: CO(MO[KO])
          }), (0, lO.jsx)("div", {
            className: "PluginCardDescription",
            children: CO(aK[KO])
          })]
        }), (0, lO.jsx)("span", {
          className: "PluginCardToggleLabel",
          children: CO(hO ? "general:on" : "general:off")
        })]
      })
    }
    const MO = {
        fallDamage: "classic:enableFallDamage",
        tpRequests: "classic:enableTpRequests",
        spawnProtection: "classic:enableSpawnProtection",
        spawnReset: "classic:enableSpawnReset",
        smpMarketplace: "classic:enableSmpMarketplace",
        survivalGuns: "classic:enableSurvivalGuns",
        dayNight: "classic:enableDayNight"
      },
      aK = {
        fallDamage: "classic:enableFallDamageDescription",
        tpRequests: "classic:enableTpRequestsDescription",
        spawnProtection: "classic:enableSpawnProtectionDescription",
        spawnReset: "classic:enableSpawnResetDescription",
        smpMarketplace: "classic:enableSmpMarketplaceDescription",
        survivalGuns: "classic:enableSurvivalGunsDescription",
        dayNight: "classic:enableDayNightDescription"
      }
  },
  4054: (OO, KO, pO) => {
    pO.d(KO, {
      f: () => bp,
      b: () => XK,
      e: () => pK,
      h: () => eK
    });
    var XO = pO(63),
      bK = pO(1187),
      eO = pO(1271),
      lO = pO(1475),
      vK = pO(1051),
      CO = pO(1180),
      hO = pO(1195),
      DO = pO(933),
      MO = pO(1077),
      aK = pO(918),
      oO = pO.n(aK),
      FO = pO(243),
      VO = pO(3812),
      LO = pO(1098),
      QO = pO(4059),
      zK = pO(2430),
      AO = pO(4070),
      fO = pO(976);

    function dO(OO) {
      let {
        icon: KO,
        title: pO,
        disabled: XO,
        children: bK
      } = OO;
      return (0, fO.jsxs)("div", {
        className: oO()("ManageCard", {
          ManageCardDisabled: XO
        }),
        children: [(0, fO.jsxs)("div", {
          className: "ManageCardHead",
          children: [(0, fO.jsx)("div", {
            className: "ManageCardIcon",
            children: (0, fO.jsx)(DO.d, {
              name: KO
            })
          }), (0, fO.jsx)("div", {
            children: (0, fO.jsx)("h2", {
              className: "ManageCardTitle",
              children: pO
            })
          })]
        }), (0, fO.jsxs)("div", {
          className: "ManageCardBody",
          children: [bK, XO && (0, fO.jsx)("div", {
            className: "ManageCardDisabledOverlay"
          })]
        })]
      })
    }

    function TO(OO) {
      let {
        label: KO,
        caption: pO,
        children: XO
      } = OO;
      return (0, fO.jsxs)("div", {
        className: "ManageStackedField",
        children: [(0, fO.jsx)("div", {
          className: "ManageStackedFieldLabel",
          children: KO
        }), XO, pO && (0, fO.jsx)("div", {
          className: "ManageStackedFieldCaption",
          children: pO
        })]
      })
    }

    function NO(OO) {
      let {
        label: KO,
        caption: pO,
        disabled: XO,
        children: bK
      } = OO;
      return (0, fO.jsxs)("div", {
        className: oO()("ManageField", {
          ManageFieldDisabled: XO
        }),
        children: [(0, fO.jsxs)("div", {
          className: "ManageFieldText",
          children: [(0, fO.jsx)("div", {
            className: "ManageFieldLabel",
            children: KO
          }), (0, fO.jsx)("div", {
            className: "ManageFieldCaption",
            children: pO
          })]
        }), (0, fO.jsx)("div", {
          className: "ManageFieldControl",
          children: bK
        })]
      })
    }

    function IO(OO) {
      var KO, pO;
      let {
        schematicData: XO,
        updateSchematicData: bK,
        publishFormEnabled: eO,
        formEnabled: lO
      } = OO;
      const {
        t: CO
      } = (0, vK.D)(), hO = !eO, DO = {
        tpRequests: {
          isEnabled: () => !XO.disableTpRequests,
          WE: OO => bK("disableTpRequests", !OO)
        },
        spawnProtection: {
          isEnabled: () => !XO.disableSpawnProtection,
          WE: OO => bK("disableSpawnProtection", !OO)
        },
        spawnReset: {
          isEnabled: () => !!XO.enableSpawnReset,
          WE: OO => bK("enableSpawnReset", OO)
        },
        smpMarketplace: {
          isEnabled: () => !!XO.enableSmpMarketplace,
          WE: OO => bK("enableSmpMarketplace", OO)
        },
        survivalGuns: {
          isEnabled: () => !!XO.enableSurvivalGuns,
          WE: OO => bK("enableSurvivalGuns", OO)
        },
        fallDamage: {
          isEnabled: () => !XO.disableFallDamage,
          WE: OO => bK("disableFallDamage", !OO)
        },
        dayNight: {
          isEnabled: () => !!XO.enableDayNight,
          WE: OO => bK("enableDayNight", OO)
        }
      };
      return (0, fO.jsxs)(fO.Fragment, {
        children: [!1 === XO.schematicContainsSpawnBlock && (0, fO.jsx)("div", {
          className: "ManageWarningBanner",
          children: CO("worldBuilder:mustContainSpawnBlock")
        }), (0, fO.jsxs)("div", {
          className: "ManageSettingsGrid",
          children: [(0, fO.jsxs)(dO, {
            icon: "globe",
            title: CO("worldBuilder:worldRulesSection"),
            disabled: !lO,
            children: [(0, fO.jsx)(NO, {
              label: CO("classic:defaultGamemode"),
              caption: CO("classic:defaultGamemodeDescription"),
              disabled: hO,
              children: (0, fO.jsx)(zK.b, {
                controlClassName: "ManageDropdown",
                options: VO.B.map((OO => ({
                  value: OO,
                  label: FO.r[OO]
                }))),
                value: XO.defaultGamemode,
                onChange: OO => bK("defaultGamemode", OO.value)
              })
            }), (0, fO.jsx)(NO, {
              label: CO("classic:voidDeathHeight"),
              caption: CO("classic:voidDeathHeightDescription"),
              disabled: hO,
              children: (0, fO.jsxs)("div", {
                className: "ManageNumberField",
                children: [(0, fO.jsx)("input", {
                  type: "number",
                  max: LO.F,
                  value: null !== (KO = XO.voidDeathHeight) && void 0 !== KO ? KO : "",
                  onChange: OO => {
                    const KO = parseInt(OO.target.value);
                    bK("voidDeathHeight", KO)
                  }
                }), (0, fO.jsx)("span", {
                  className: "ManageFieldUnit",
                  children: CO("worldBuilder:blocksUnit")
                })]
              })
            }), (0, fO.jsx)(NO, {
              label: CO("classic:worldBorder"),
              caption: CO("classic:worldBorderDescription"),
              disabled: hO,
              children: (0, fO.jsxs)("div", {
                className: "ManageNumberField",
                children: [(0, fO.jsx)("input", {
                  type: "number",
                  min: LO.K,
                  max: LO.G,
                  placeholder: CO("worldBuilder:noWorldBorderLimit"),
                  value: null !== (pO = XO.worldBorder) && void 0 !== pO ? pO : "",
                  onChange: OO => {
                    const KO = parseInt(OO.target.value);
                    bK("worldBorder", isNaN(KO) ? null : KO)
                  }
                }), (0, fO.jsx)("span", {
                  className: "ManageFieldUnit",
                  children: CO("worldBuilder:blocksUnit")
                })]
              })
            }), (0, fO.jsx)(NO, {
              label: CO("classic:disableMobs"),
              caption: CO("classic:disableMobsDescription"),
              disabled: hO,
              children: (0, fO.jsx)(QO.g, {
                checked: XO.disableMobs,
                setChecked: OO => bK("disableMobs", OO),
                disabled: hO
              })
            })]
          }), (0, fO.jsxs)(dO, {
            icon: "user-group",
            title: CO("worldBuilder:playerAndLobbySection"),
            disabled: !lO,
            children: [(0, fO.jsx)(NO, {
              label: CO("classic:disableKeepInventory"),
              caption: CO("classic:disableKeepInventoryDescription"),
              disabled: hO,
              children: (0, fO.jsx)(QO.g, {
                checked: XO.disableKeepInventory,
                setChecked: OO => bK("disableKeepInventory", OO),
                disabled: hO
              })
            }), (0, fO.jsx)(NO, {
              label: CO("classic:persistInventory"),
              caption: CO("classic:persistInventoryDescription"),
              disabled: hO,
              children: (0, fO.jsx)(zK.b, {
                controlClassName: "ManageDropdown",
                options: VO.g.map((OO => ({
                  value: OO,
                  label: FO.g[OO]
                }))),
                value: XO.persistInventory,
                onChange: OO => bK("persistInventory", OO.value)
              })
            }), (0, fO.jsx)(NO, {
              label: CO("classic:persistWorld"),
              caption: CO("classic:persistWorldDescription"),
              disabled: hO,
              children: (0, fO.jsx)(QO.g, {
                checked: XO.persistWorld,
                setChecked: OO => bK("persistWorld", OO),
                disabled: hO
              })
            }), (0, fO.jsx)(NO, {
              label: CO("classic:disableLobbySpawn"),
              caption: CO("classic:disableLobbySpawnDescription"),
              disabled: hO,
              children: (0, fO.jsx)(QO.g, {
                checked: XO.disableLobbySpawn,
                setChecked: OO => bK("disableLobbySpawn", OO),
                disabled: hO
              })
            }), (0, fO.jsx)(NO, {
              label: CO("classic:hideLobbyCode"),
              caption: CO("classic:hideLobbyCodeDescription"),
              disabled: hO,
              children: (0, fO.jsx)(QO.g, {
                checked: XO.hideLobbyCode,
                setChecked: OO => bK("hideLobbyCode", OO),
                disabled: hO
              })
            })]
          })]
        }), (0, fO.jsx)(dO, {
          icon: "layer-group",
          title: CO("worldBuilder:pluginsSection"),
          disabled: !lO,
          children: (0, fO.jsx)(AO.b, {
            callbacks: DO,
            disabled: hO,
            advancedMode: !0,
            hideWrapper: !0
          })
        })]
      })
    }
    var yK = pO(4078),
      gK = pO(3618),
      uO = pO(1329),
      EO = pO(2737),
      jK = pO(1004),
      YO = pO(4035),
      wO = pO(4080),
      iK = pO(1273);
    const rK = 50,
      PO = .3;
    async function mK(OO) {
      const KO = await
      function(OO) {
        return new Promise(((KO, pO) => {
          const XO = new FileReader;
          XO.onload = () => KO(XO.result), XO.onerror = pO, XO.readAsDataURL(OO)
        }))
      }(OO), pO = await
      function(OO) {
        return new Promise(((KO, pO) => {
          const XO = new Image;
          XO.onload = () => KO(XO), XO.onerror = () => pO(new Error("Failed to load image")), XO.src = OO
        }))
      }(KO);
      if (pO.naturalHeight > pO.naturalWidth) throw new sO;
      const XO = 1024 * rK,
        {
          dataUrl: bK,
          finalQuality: eO
        } = function(OO, KO) {
          const pO = document.createElement("canvas");
          pO.width = OO.naturalWidth, pO.height = OO.naturalHeight, pO.getContext("2d").drawImage(OO, 0, 0);
          let XO = .92,
            bK = pO.toDataURL("image/jpeg", XO);
          for (; .75 * bK.length > KO && XO > .05;) XO -= .05, bK = pO.toDataURL("image/jpeg", XO);
          return {
            dataUrl: bK,
            finalQuality: XO
          }
        }(pO, XO);
      if (Math.ceil(.75 * bK.length) > XO) throw new HO;
      return {
        base64Jpg: bK,
        heavilyCompressed: eO < PO
      }
    }
    class sO extends Error {}
    class HO extends Error {}
    var RO = function(OO) {
      return OO[OO.NOT_LOGGED_IN = 0] = "NOT_LOGGED_IN", OO[OO.THUMBNAIL_LIMIT_REACHED = 1] = "THUMBNAIL_LIMIT_REACHED", OO
    }(RO || {});

    function SO(OO) {
      var KO;
      let {
        schematicId: pO,
        hasReadUploadPolicy: bK,
        onPolicyValidationError: CO,
        onThumbnailReady: hO
      } = OO;
      const {
        t: aK
      } = (0, vK.D)(), [FO, VO] = (0, XO.useState)(null), [LO, QO] = (0, XO.useState)(""), [zK, AO] = (0, XO.useState)(""), [dO, TO] = (0, XO.useState)(!0), [NO, IO] = (0, XO.useState)(!1), yK = (0, XO.useRef)(!1), [gK, uO] = (0, XO.useState)(null), [EO, jK] = (0, XO.useState)(!1), [YO, iK] = (0, XO.useState)(!1), rK = (0, XO.useRef)(0), {
        getRootProps: PO,
        getInputProps: RO,
        isDragActive: SO
      } = (0, wO.d)({
        accept: {
          "image/*": [".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"]
        },
        multiple: !1,
        onDrop: async OO => {
          if (0 === OO.length) return;
          const KO = OO[0],
            pO = ++rK.current;
          uO(null), jK(!1), VO(null), QO(KO.name);
          try {
            const OO = await mK(KO);
            if (pO !== rK.current) return;
            VO(OO), jK(OO.heavilyCompressed)
          } catch (XO) {
            if (pO !== rK.current) return;
            uO(aK(XO instanceof sO ? "thumbnail:portraitImagesNotAllowed" : XO instanceof HO ? "thumbnail:couldNotCompressImage" : "thumbnail:failedToUploadImage"))
          }
        },
        useFsAccessApi: !1
      }), JO = LO.length <= 30 ? LO : `${LO.slice(0,27)}...`, cK = null !== (KO = null === FO || void 0 === FO ? void 0 : FO.base64Jpg) && void 0 !== KO ? KO : null, BO = zK.trim(), ZO = BO.length >= MO.o && BO.length <= MO.m, GO = YO && !FO && !gK, qK = YO && !ZO;
      return (0, fO.jsxs)("div", {
        className: "ThumbnailUploadContainer",
        children: [(0, fO.jsxs)("div", {
          ...PO({
            className: oO()("ThumbnailUploadDropzone", {
              ActiveDrag: SO,
              ValidationError: GO
            })
          }),
          children: [(0, fO.jsx)("input", {
            ...RO()
          }), !SO && cK ? (0, fO.jsxs)(fO.Fragment, {
            children: [(0, fO.jsxs)("div", {
              className: "ThumbnailAspectPreviews",
              children: [(0, fO.jsxs)("div", {
                className: "ThumbnailAspectPreview",
                children: [(0, fO.jsx)("div", {
                  className: "ThumbnailAspectLabel",
                  children: "1:1"
                }), (0, fO.jsx)("div", {
                  className: "ThumbnailAspectFrame Square",
                  children: (0, fO.jsx)("img", {
                    src: cK,
                    alt: "1:1 preview"
                  })
                })]
              }), (0, fO.jsxs)("div", {
                className: "ThumbnailAspectPreview",
                children: [(0, fO.jsx)("div", {
                  className: "ThumbnailAspectLabel",
                  children: "16:9"
                }), (0, fO.jsx)("div", {
                  className: "ThumbnailAspectFrame Wide",
                  children: (0, fO.jsx)("img", {
                    src: cK,
                    alt: "16:9 preview"
                  })
                })]
              })]
            }), (0, fO.jsxs)("div", {
              children: [(0, fO.jsx)("div", {
                className: "ThumbnailUploadInstructions Active",
                children: JO
              }), (0, fO.jsx)("div", {
                className: "ThumbnailUploadInstructions Preview",
                children: aK("thumbnail:preview")
              })]
            })]
          }) : (0, fO.jsxs)(fO.Fragment, {
            children: [(0, fO.jsx)("div", {
              className: "ThumbnailUploadIcon",
              children: (0, fO.jsx)(DO.d, {
                name: "image"
              })
            }), (0, fO.jsx)("div", {
              className: "ThumbnailUploadInstructions",
              children: aK("thumbnail:dragImageHere")
            })]
          })]
        }), GO && (0, fO.jsx)("div", {
          className: "ThumbnailUploadError",
          children: aK("thumbnail:imageRequired")
        }), (0, fO.jsx)(lO.e, {
          className: oO()("ThumbnailUploadNameInput", {
            ValidationError: qK
          }),
          placeholderText: aK("thumbnail:thumbnailName"),
          defaultValue: zK,
          onValueChange: OO => {
            AO(OO)
          },
          maxLength: MO.m
        }), qK && (0, fO.jsx)("div", {
          className: "ThumbnailUploadError",
          children: aK("thumbnail:nameRequired", {
            min: MO.o,
            max: MO.m
          })
        }), (0, fO.jsxs)("label", {
          className: "ThumbnailUploadCheckbox",
          children: [(0, fO.jsx)("input", {
            type: "checkbox",
            checked: dO,
            onChange: OO => {
              TO(OO.target.checked)
            }
          }), aK("thumbnail:setAsThumbnailOnceApproved")]
        }), EO && (0, fO.jsx)("div", {
          className: "ThumbnailUploadWarning",
          children: aK("thumbnail:heavyCompressionWarning")
        }), gK && (0, fO.jsx)("div", {
          className: "ThumbnailUploadError",
          children: gK
        }), (0, fO.jsx)(eO.m, {
          disabled: NO,
          className: "ThumbnailUploadButton",
          onClick: async () => {
            if (iK(!0), !yK.current && FO && ZO && bK) {
              yK.current = !0, IO(!0), uO(null);
              try {
                await hO(FO.base64Jpg, BO, dO ? pO : null)
              } catch (OO) {
                uO(OO.errorMessageForUser ? aK(OO.errorMessageForUser, OO.errorMessageTranslationParams) : aK("thumbnail:failedToUploadImage"))
              } finally {
                yK.current = !1, IO(!1)
              }
            } else bK || CO()
          },
          children: aK(NO ? "thumbnail:processing" : "thumbnail:uploadThumbnail")
        })]
      })
    }
    const JO = 2e3;

    function cK(OO) {
      let {
        schematicId: KO,
        ownedThumbnailCount: pO,
        onClose: bK,
        onThumbnailReady: eO
      } = OO;
      const {
        t: lO
      } = (0, vK.D)(), {
        userContext: CO
      } = (0, jK.d)(), [hO, aK] = (0, XO.useState)(!1), [FO, VO] = (0, XO.useState)(!1), [LO, QO] = (0, XO.useState)(!1), zK = (0, XO.useRef)();
      (0, XO.useEffect)((() => () => {
        clearTimeout(zK.current)
      }), []);
      const AO = function(OO, KO) {
        const pO = [];
        return OO.isLoggedIn() || pO.push(RO.NOT_LOGGED_IN), KO >= MO.Q && pO.push(RO.THUMBNAIL_LIMIT_REACHED), pO
      }(CO, pO);
      if (AO.length > 0) {
        const OO = {
          [RO.NOT_LOGGED_IN]: {
            key: "thumbnail:mustBeLoggedInToUpload"
          },
          [RO.THUMBNAIL_LIMIT_REACHED]: {
            key: "thumbnail:thumbnailLimitReachedPleaseDelete",
            params: {
              max: MO.Q
            }
          }
        };
        return (0, fO.jsxs)("div", {
          className: "ThumbnailUploaderInner",
          children: [(0, fO.jsx)("h1", {
            className: "SchematicPopupTitle",
            children: lO("thumbnail:cannotUploadThumbnail")
          }), AO.map(((KO, pO) => {
            const XO = OO[KO];
            return (0, fO.jsxs)("div", {
              className: "CannotUploadThumbnailItem",
              children: [(0, fO.jsx)(DO.d, {
                name: "triangle-exclamation"
              }), (0, fO.jsx)("span", {
                children: lO(XO.key, XO.params)
              })]
            }, pO)
          }))]
        })
      }
      return (0, fO.jsxs)("div", {
        className: oO()("ThumbnailUploaderInner", {
          ThumbnailUploaderSuccess: hO
        }),
        children: [hO && (0, fO.jsxs)("div", {
          className: "ThumbnailUploadSuccessOverlay",
          children: [(0, fO.jsxs)("div", {
            className: "ThumbnailUploadSuccessIcon FullyFancyText AnimFadeInScaleUp",
            children: [(0, fO.jsx)(DO.d, {
              name: "check"
            }), (0, fO.jsx)(iK.b, {})]
          }), (0, fO.jsx)("div", {
            className: "ThumbnailUploadSuccessText AnimFadeInScaleUp",
            children: lO("thumbnail:thumbnailUploaded")
          })]
        }), (0, fO.jsx)("h1", {
          className: "SchematicPopupTitle",
          children: lO("thumbnail:uploadThumbnail")
        }), (0, fO.jsxs)("div", {
          className: "ThumbnailUploaderBody",
          children: [(0, fO.jsxs)("div", {
            className: "ThumbnailUploaderLeft",
            children: [(0, fO.jsx)("h3", {
              className: "SchematicPopupSubtitle",
              children: lO("thumbnail:chooseImage", {
                maxSizeKb: rK
              })
            }), (0, fO.jsx)(SO, {
              schematicId: KO,
              hasReadUploadPolicy: FO,
              onPolicyValidationError: () => {
                QO(!0)
              },
              onThumbnailReady: async (OO, KO, pO) => {
                await eO(OO, KO, pO), aK(!0), zK.current = setTimeout(bK, JO)
              }
            })]
          }), (0, fO.jsxs)("div", {
            className: "ThumbnailUploadPolicy",
            children: [(0, fO.jsx)("h3", {
              className: "ThumbnailUploadPolicyTitle",
              children: lO("thumbnail:uploadPolicy")
            }), (0, fO.jsxs)("ul", {
              className: "ThumbnailUploadPolicyList",
              children: [(0, fO.jsxs)("li", {
                className: "ThumbnailUploadPolicyItem Allowed",
                children: [(0, fO.jsx)(DO.d, {
                  name: "check"
                }), (0, fO.jsx)("span", {
                  children: lO("thumbnail:policyFollowGuidelines")
                })]
              }), (0, fO.jsxs)("li", {
                className: "ThumbnailUploadPolicyItem Allowed",
                children: [(0, fO.jsx)(DO.d, {
                  name: "check"
                }), (0, fO.jsx)("span", {
                  children: lO("thumbnail:policyInGameAssets")
                })]
              }), (0, fO.jsxs)("li", {
                className: "ThumbnailUploadPolicyItem Allowed",
                children: [(0, fO.jsx)(DO.d, {
                  name: "check"
                }), (0, fO.jsx)("span", {
                  children: lO("thumbnail:policyLimitText")
                })]
              }), (0, fO.jsxs)("li", {
                className: "ThumbnailUploadPolicyItem NotAllowed",
                children: [(0, fO.jsx)(DO.d, {
                  name: "x"
                }), (0, fO.jsx)("span", {
                  children: lO("thumbnail:policyCopyrightContent")
                })]
              }), (0, fO.jsxs)("li", {
                className: "ThumbnailUploadPolicyItem NotAllowed",
                children: [(0, fO.jsx)(DO.d, {
                  name: "x"
                }), (0, fO.jsx)("span", {
                  children: lO("thumbnail:policyOutOfGameAssets")
                })]
              }), (0, fO.jsxs)("li", {
                className: "ThumbnailUploadPolicyItem NotAllowed",
                children: [(0, fO.jsx)(DO.d, {
                  name: "x"
                }), (0, fO.jsx)("span", {
                  children: lO("thumbnail:policyBloxdTags")
                })]
              }), (0, fO.jsxs)("li", {
                className: "ThumbnailUploadPolicyItem NotAllowed",
                children: [(0, fO.jsx)(DO.d, {
                  name: "x"
                }), (0, fO.jsx)("span", {
                  children: lO("thumbnail:policyMustReflectGame")
                })]
              })]
            }), (0, fO.jsxs)("label", {
              className: oO()("ThumbnailUploadCheckbox Policy", {
                ValidationError: LO && !FO
              }),
              children: [(0, fO.jsx)("input", {
                type: "checkbox",
                checked: FO,
                onChange: OO => {
                  VO(OO.target.checked)
                }
              }), lO("thumbnail:agreeToUploadPolicy")]
            }), LO && !FO && (0, fO.jsx)("div", {
              className: "ThumbnailPolicyError",
              children: lO("thumbnail:policyRequired")
            })]
          })]
        })]
      })
    }
    var BO = pO(1056);
    const ZO = {
      "custom-game-bad-thumbnail": {
        reason: "thumbnail:rejectionInappropriate",
        tips: ["thumbnail:rejectionInappropriateTip1", "thumbnail:rejectionInappropriateTip2", "thumbnail:rejectionInappropriateTip3"]
      },
      "thumbnail-copyright-content": {
        reason: "thumbnail:rejectionCopyright",
        tips: ["thumbnail:rejectionCopyrightTip1", "thumbnail:rejectionCopyrightTip2", "thumbnail:rejectionCopyrightTip3"]
      },
      "thumbnail-random-irrelevant-content": {
        reason: "thumbnail:rejectionIrrelevant",
        tips: ["thumbnail:rejectionIrrelevantTip1", "thumbnail:rejectionIrrelevantTip2", "thumbnail:rejectionIrrelevantTip3"]
      },
      "thumbnail-sexual-content": {
        reason: "thumbnail:rejectionSexual",
        tips: ["thumbnail:rejectionSexualTip1", "thumbnail:rejectionSexualTip2", "thumbnail:rejectionSexualTip3"]
      },
      "thumbnail-substances-content": {
        reason: "thumbnail:rejectionSubstances",
        tips: ["thumbnail:rejectionSubstancesTip1", "thumbnail:rejectionSubstancesTip2"]
      },
      "thumbnail-unauthorized-bloxd-branding": {
        reason: "thumbnail:rejectionUnauthorisedBranding",
        tips: ["thumbnail:rejectionUnauthorisedBrandingTip1", "thumbnail:rejectionUnauthorisedBrandingTip2", "thumbnail:rejectionUnauthorisedBrandingTip3", "thumbnail:rejectionUnauthorisedBrandingTip4"]
      },
      "thumbnail-violent-gore-content": {
        reason: "thumbnail:rejectionViolence",
        tips: ["thumbnail:rejectionViolenceTip1", "thumbnail:rejectionViolenceTip2", "thumbnail:rejectionViolenceTip3", "thumbnail:rejectionViolenceTip4"]
      }
    };

    function GO(OO) {
      var KO, pO;
      let {
        schematicData: lO,
        updateSchematicData: hO,
        publishFormEnabled: MO,
        onClose: aK
      } = OO;
      const {
        t: FO
      } = (0, vK.D)(), {
        userContext: VO,
        isUserContextUpdating: LO
      } = (0, jK.d)(), QO = (0, EO.b)(), [zK, AO] = (0, XO.useState)([]), [dO, TO] = (0, XO.useState)([]), [NO, IO] = (0, XO.useState)(!0), [yK, gK] = (0, XO.useState)(null !== (KO = lO.customThumbnailId) && void 0 !== KO ? KO : null), [wO, iK] = (0, XO.useState)(null), rK = (0, XO.useRef)(null !== (pO = lO.customThumbnailId) && void 0 !== pO ? pO : null), PO = (0, XO.useRef)(0), mK = (0, XO.useRef)(null), sO = (0, XO.useRef)(null), HO = (0, XO.useRef)(null), RO = (0, XO.useRef)(!1);

      function SO(OO, KO) {
        HO.current && (clearTimeout(HO.current), HO.current = null), iK(OO), null !== OO && KO && (HO.current = setTimeout((() => {
          iK(null), HO.current = null
        }), 5e3))
      }(0, XO.useEffect)((() => () => {
        clearTimeout(sO.current), clearTimeout(HO.current)
      }), []);
      const JO = (0, XO.useCallback)((() => {
        IO(!0), uO.c.getOwnedThumbnails(VO).then((OO => {
          const KO = [],
            pO = [];
          for (const XO of OO.thumbnails) XO.rejectionPolicyId ? KO.push(XO) : pO.push(XO);
          KO.sort(((OO, KO) => OO.lastUpdatedAt - KO.lastUpdatedAt)), pO.sort(((OO, KO) => {
            const pO = OO.approved ? 1 : 0,
              XO = (KO.approved ? 1 : 0) - pO;
            return 0 !== XO ? XO : KO.lastUpdatedAt - OO.lastUpdatedAt
          })), TO(KO), AO(pO)
        })).catch((OO => {
          console.error("Failed to fetch thumbnails:", OO)
        })).finally((() => {
          IO(!1)
        }))
      }), [VO]);
      async function ZO(OO, KO, pO) {
        return uO.c.uploadSchematicThumbnail(VO, OO, KO, pO).then((() => {
          SO({
            text: FO("thumbnail:uploadedAwaitingModeration"),
            type: "success"
          }, !0), JO()
        }))
      }

      function GO() {
        PO.current = Date.now(), sO.current = null;
        const OO = mK.current;
        mK.current = null, SO({
          text: FO("thumbnail:settingThumbnail"),
          type: "info"
        }, !1), uO.c.setSchematicThumbnail(VO, lO.schematicId, OO).then((() => {
          QO.current && (SO({
            text: FO("thumbnail:thumbnailUpdated"),
            type: "success"
          }, !0), rK.current = OO, hO("customThumbnailId", OO), hO("customThumbnailBlurhash", void 0), hO("customThumbnailVariants", void 0))
        })).catch((OO => {
          QO.current && (SO({
            text: OO.errorMessageForUser ? FO(OO.errorMessageForUser, OO.errorMessageTranslationParams) : FO("thumbnail:failedToSetThumbnail"),
            type: "error"
          }, !0), gK(rK.current))
        }))
      }

      function nO(OO) {
        gK(OO), mK.current = OO;
        const KO = Date.now() - PO.current;
        KO >= 1e3 ? GO() : (SO({
          text: FO("thumbnail:settingThumbnail"),
          type: "info"
        }, !1), sO.current || (sO.current = setTimeout((() => {
          GO()
        }), 1e3 - KO)))
      }
      return (0, XO.useEffect)((() => {
        !1 === LO && JO()
      }), [LO, JO]), dO.length > 0 ? (0, fO.jsx)(qK, {
        rejectedThumbnails: dO,
        userContext: VO,
        isMountedRef: QO,
        onAcknowledged: JO
      }) : (0, fO.jsxs)("div", {
        className: "BloxdForm ThumbnailSection",
        children: [(0, fO.jsxs)("div", {
          className: "SectionTitle",
          children: [FO("thumbnail:gameThumbnail"), wO && (0, fO.jsx)("span", {
            className: oO()("ThumbnailActionMsg", `ThumbnailActionMsg--${wO.type}`),
            children: wO.text
          })]
        }), (0, fO.jsx)("div", {
          className: "SectionBody",
          children: (0, fO.jsxs)("div", {
            className: "ThumbnailGrid",
            children: [(0, fO.jsxs)("div", {
              className: oO()("ThumbnailGridItem ThumbnailGridItemDefault", {
                ThumbnailGridItemSelected: null === yK
              }),
              onClick: () => nO(null),
              children: [(0, fO.jsx)(YO.b, {
                game: {
                  schematicId: lO.schematicId,
                  imageBlurhash: lO.imageBlurhash
                }
              }), (0, fO.jsx)("div", {
                className: "ThumbnailGridItemLabel ThumbnailDefaultLabel",
                children: FO("general:default")
              })]
            }), NO && (0, fO.jsx)(CO.e, {}), zK.map(((OO, KO) => (0, fO.jsxs)("div", {
              className: oO()("ThumbnailGridItem", {
                ThumbnailGridItemSelected: yK === OO.id,
                ThumbnailGridItemPending: !OO.approved
              }),
              onClick: () => {
                OO.approved && nO(OO.id)
              },
              children: [OO.approved && (0, fO.jsx)("img", {
                src: `${BO.clientSideServerUrls.s3Url}/customThumbnails/${OO.id}.jpg`,
                alt: "Thumbnail"
              }), OO.approved && (0, fO.jsx)("div", {
                className: "ThumbnailGridItemLabel",
                children: OO.name
              }), OO.id && (0, fO.jsx)(eO.I, {
                className: "ThumbnailDeleteButton",
                onClick: KO => async function(OO, KO, pO) {
                  OO.stopPropagation();
                  const XO = await bK.NotificationProvider.showCustomPopup({
                      body: OO => (0, fO.jsx)(xK, {
                        thumbnailId: KO,
                        thumbnailName: pO,
                        onClose: KO => {
                          KO && (RO.current = !0), OO()
                        }
                      }),
                      middleScreenPopupClassName: "ThumbnailDeleteConfirmPopup",
                      onClose: aK
                    }).getResult(),
                    eO = RO.current;
                  RO.current = !1, eO && !0 === XO && (QO.current && SO({
                    text: FO("thumbnail:deletingThumbnail"),
                    type: "info"
                  }, !1), uO.c.deleteSchematicThumbnail(VO, KO).then((() => {
                    QO.current && (SO({
                      text: FO("thumbnail:thumbnailDeleted"),
                      type: "success"
                    }, !0), rK.current === KO && nO(null), JO())
                  })).catch((OO => {
                    QO.current && SO({
                      text: OO.errorMessageForUser ? FO(OO.errorMessageForUser, OO.errorMessageTranslationParams) : FO("thumbnail:failedToDeleteThumbnail"),
                      type: "error"
                    }, !0)
                  })))
                }(KO, OO.id, OO.name),
                children: (0, fO.jsx)(DO.d, {
                  name: "trash-can"
                })
              }), !OO.approved && (0, fO.jsx)("div", {
                className: "ThumbnailUnapprovedIcon",
                children: (0, fO.jsx)(DO.d, {
                  name: "hourglass-clock"
                })
              }), !OO.approved && (0, fO.jsxs)("div", {
                className: "ThumbnailGridItemLabel ThumbnailPendingLabel",
                children: [OO.name, (0, fO.jsx)("br", {}), FO("thumbnail:pendingApproval")]
              })]
            }, KO))), (0, fO.jsxs)("div", {
              className: oO()("ThumbnailGridItem ThumbnailUploadTile", {
                ThumbnailUploadTileDisabled: !MO
              }),
              onClick: () => {
                MO && function(OO) {
                  let {
                    schematicId: KO,
                    ownedThumbnailCount: pO,
                    onThumbnailReady: XO,
                    onClose: eO
                  } = OO;
                  bK.NotificationProvider.showCustomPopup({
                    body: OO => (0, fO.jsx)(cK, {
                      schematicId: KO,
                      ownedThumbnailCount: pO,
                      onClose: OO,
                      onThumbnailReady: XO
                    }),
                    middleScreenPopupClassName: "SchematicThumbnailPopup",
                    onClose: eO,
                    unlockPointerKey: "schematicThumbnailUploaderPopup"
                  })
                }({
                  schematicId: lO.schematicId,
                  ownedThumbnailCount: zK.length,
                  onThumbnailReady: ZO,
                  onClose: aK
                })
              },
              children: [(0, fO.jsx)(DO.d, {
                name: "plus"
              }), (0, fO.jsx)("div", {
                className: "ThumbnailGridItemLabel",
                children: FO("thumbnail:uploadThumbnail")
              })]
            })]
          })
        })]
      })
    }

    function qK(OO) {
      let {
        rejectedThumbnails: KO,
        userContext: pO,
        isMountedRef: bK,
        onAcknowledged: lO
      } = OO;
      const {
        t: hO
      } = (0, vK.D)(), [MO, aK] = (0, XO.useState)(!1), [oO, FO] = (0, XO.useState)(!1), VO = function(OO) {
        const KO = new Map;
        for (const pO of OO) {
          const OO = pO.rejectionPolicyId,
            XO = KO.get(OO);
          XO ? XO.push(pO) : KO.set(OO, [pO])
        }
        return KO
      }(KO);
      return (0, fO.jsxs)("div", {
        className: "ThumbnailRejectionNotice",
        children: [(0, fO.jsxs)("div", {
          className: "ThumbnailRejectionNoticeTitle",
          children: [(0, fO.jsx)(DO.d, {
            name: "triangle-exclamation"
          }), " ", hO("thumbnail:thumbnailsRejected"), " ", (0, fO.jsx)(DO.d, {
            name: "triangle-exclamation"
          })]
        }), (0, fO.jsx)("div", {
          className: "ThumbnailRejectionNoticeSubtitle",
          children: hO("thumbnail:thumbnailsRejectedDescription")
        }), (0, fO.jsx)("div", {
          className: "ThumbnailRejectionNoticeList",
          children: [...VO.entries()].map((OO => {
            let [KO, pO] = OO;
            const XO = ZO[KO];
            return (0, fO.jsxs)("div", {
              className: "ThumbnailRejectionNoticeGroup",
              children: [(0, fO.jsx)("div", {
                className: "ThumbnailRejectionNoticeItems",
                children: pO.map((OO => (0, fO.jsxs)("div", {
                  className: "ThumbnailRejectionNoticeItem",
                  children: [(0, fO.jsx)("div", {
                    className: "ThumbnailRejectionNoticeItemIcon",
                    children: (0, fO.jsx)(DO.d, {
                      name: "image-slash"
                    })
                  }), (0, fO.jsx)("div", {
                    className: "ThumbnailRejectionNoticeItemDetails",
                    children: (0, fO.jsx)("div", {
                      className: "ThumbnailRejectionNoticeItemName",
                      children: OO.name
                    })
                  })]
                }, OO.id)))
              }), (0, fO.jsxs)("div", {
                className: "ThumbnailRejectionNoticeGroupReason",
                children: [hO("thumbnail:rejectionReason"), " ", XO ? hO(XO.reason) : KO]
              }), XO && (0, fO.jsx)("ul", {
                className: "ThumbnailRejectionNoticeGroupTips",
                children: XO.tips.map((OO => (0, fO.jsx)("li", {
                  children: hO(OO)
                }, OO)))
              })]
            }, KO)
          }))
        }), (0, fO.jsxs)("label", {
          className: "ThumbnailRejectionNoticeCheckbox",
          children: [(0, fO.jsx)(gK.c, {
            checked: MO,
            onChange: OO => aK(OO.target.checked),
            disabled: oO
          }), (0, fO.jsx)("span", {
            children: hO("thumbnail:haveReadRejectionReasons")
          })]
        }), (0, fO.jsx)(eO.m, {
          onClick: async function() {
            FO(!0);
            const OO = await Promise.allSettled(KO.map((OO => uO.c.deleteSchematicThumbnail(pO, OO.id))));
            if (!bK.current) return;
            const XO = OO.filter((OO => "rejected" === OO.status));
            XO.length > 0 && console.error("Some rejected thumbnails failed to delete:", XO), lO()
          },
          disabled: !MO || oO,
          className: "ThumbnailRejectionNoticeAcceptButton",
          children: oO ? (0, fO.jsx)(CO.e, {}) : hO("general:accept")
        })]
      })
    }

    function xK(OO) {
      let {
        thumbnailId: KO,
        thumbnailName: pO,
        onClose: XO
      } = OO;
      const {
        t: bK
      } = (0, vK.D)();
      return (0, fO.jsxs)("div", {
        className: "ThumbnailDeleteConfirm",
        children: [(0, fO.jsx)("div", {
          className: "ThumbnailDeleteConfirmTitle",
          children: bK("thumbnail:deleteThumbnail")
        }), (0, fO.jsxs)("div", {
          className: "ThumbnailDeleteConfirmImageContainer",
          children: [(0, fO.jsx)("img", {
            className: "ThumbnailDeleteConfirmImage",
            src: `${BO.clientSideServerUrls.s3Url}/customThumbnails/${KO}.jpg`,
            alt: "Thumbnail to delete"
          }), (0, fO.jsx)("div", {
            className: "ThumbnailGridItemLabel",
            children: pO
          })]
        }), (0, fO.jsx)("div", {
          className: "ThumbnailDeleteConfirmSubtitle",
          children: bK("thumbnail:deleteThumbnailConfirmation")
        }), (0, fO.jsxs)("div", {
          className: "ThumbnailDeleteConfirmButtons",
          children: [(0, fO.jsxs)(eO.I, {
            className: "ThumbnailDeleteConfirmButton",
            onClick: () => XO(!0),
            children: [(0, fO.jsx)(DO.d, {
              name: "trash-can"
            }), " ", bK("general:delete")]
          }), (0, fO.jsx)(eO.e, {
            className: "ThumbnailDeleteConfirmButton",
            onClick: () => XO(!1),
            children: bK("general:cancel")
          })]
        })]
      })
    }
    var nO = pO(2460),
      WO = pO(4111),
      tK = pO(4118),
      kK = pO(4158);

    function UO(OO) {
      let {
        schematicData: KO,
        setTexturePack: pO,
        initializeTexturePack: bK,
        publishFormEnabled: eO
      } = OO;
      const {
        t: lO
      } = (0, vK.D)(), [CO, hO] = (0, XO.useState)(null), [DO, MO] = (0, XO.useState)(null), [aK, FO] = (0, XO.useState)(!1), VO = (0, EO.b)(), LO = eO && !aK, QO = KO.customTexturePackKey;

      function zK(OO) {
        var KO;
        hO(OO.metaData.id), MO(null !== (KO = OO.metaData.fromFolderName) && void 0 !== KO ? KO : null), (OO.metaData.id !== nO.o.CUSTOM || OO.metaData.fromFolderName) && pO(OO)
      }
      return (0, XO.useEffect)((() => {
        QO && (FO(!0), (0, WO.c)(QO).then((OO => {
          var KO;
          VO.current && (OO ? (hO(OO.metaData.id), MO(null !== (KO = OO.metaData.fromFolderName) && void 0 !== KO ? KO : null), bK(OO)) : console.error(`No texture pack at ${QO}`))
        })).catch((OO => {
          console.error("Error fetching texture pack: ", OO)
        })).finally((() => {
          FO(!1)
        })))
      }), [QO, bK, VO]), (0, fO.jsxs)("div", {
        className: "BloxdForm TexturePackSection",
        children: [(0, fO.jsx)("div", {
          className: "SectionTitle",
          children: lO("customTexturePack:customTexturePack")
        }), (0, fO.jsxs)("div", {
          className: "TexturePackList",
          children: [(0, fO.jsx)("div", {
            className: oO()("TexturePack", {
              Selected: null === CO && !aK,
              Disabled: !LO
            }),
            onClick: () => {
              LO && (hO(null), pO(null), MO(null))
            },
            children: (0, fO.jsx)("div", {
              className: "TexturePackName",
              children: "No Override"
            })
          }), Object.values(nO.o).map((OO => (0, fO.jsx)(tK.f, {
            id: OO,
            isSelected: OO === CO,
            setSelected: zK,
            disabled: !LO
          }, OO)))]
        }), CO === nO.o.CUSTOM && (0, fO.jsx)(kK.c, {
          folderName: DO,
          onTexturePackUpdated: zK,
          disabled: !LO,
          maxFileSizeMb: 25,
          packOwner: "customGame"
        })]
      })
    }
    var OK = pO(4176);

    function KK(OO) {
      var KO;
      let {
        gameCategory: pO,
        setGameCategory: XO,
        disabled: bK
      } = OO;
      const lO = null !== (KO = (0, FO.gb)(pO)) && void 0 !== KO ? KO : "other";
      return (0, fO.jsxs)("div", {
        className: "GameCategoryPicker",
        children: [(0, fO.jsx)(QO.e, {
          label: "worldBuilder:gameCategoryGroup",
          className: "GameCategoryGroup",
          disabled: bK,
          children: (0, fO.jsx)(zK.b, {
            options: FO.U.map((OO => ({
              value: OO,
              label: FO.R[OO]
            }))),
            value: lO,
            onChange: OO => {
              OO.value !== lO && XO(FO.M[OO.value][0])
            }
          })
        }), (0, fO.jsx)(QO.e, {
          label: "worldBuilder:gameCategory",
          className: "GameCategory",
          disabled: bK,
          children: (0, fO.jsx)("div", {
            className: "GameCategoryOptions",
            children: FO.M[lO].map((OO => (0, fO.jsx)(eO.S, {
              active: OO === pO,
              onClick: () => {
                XO(OO)
              },
              children: (0, FO.cb)(OO)
            }, OO)))
          })
        })]
      })
    }

    function pK(OO) {
      let {
        editor: KO,
        onClose: pO
      } = OO;
      const {
        t: XO
      } = (0, vK.D)(), {
        schematicData: bK,
        updateSchematicData: eO,
        publishFormEnabled: CO,
        formEnabled: hO
      } = KO;
      return (0, fO.jsxs)(fO.Fragment, {
        children: [(0, fO.jsxs)(dO, {
          icon: "pen-to-square",
          title: XO("worldBuilder:basicsSection"),
          disabled: !hO,
          children: [(0, fO.jsx)(TO, {
            label: XO("general:name"),
            caption: XO("worldBuilder:schematicNameTagsHint"),
            children: (0, fO.jsx)(lO.e, {
              className: "SchematicPageName",
              defaultValue: bK.name,
              onValueChange: OO => eO("name", OO),
              placeholderText: XO("worldBuilder:schematicNamePlaceholder"),
              maxLength: MO.jb
            })
          }), (0, fO.jsx)(TO, {
            label: XO("general:description"),
            children: (0, fO.jsx)(lO.e, {
              className: "SchematicPageDescription",
              useTextarea: !0,
              defaultValue: bK.description,
              onValueChange: OO => eO("description", OO),
              placeholderText: XO("worldBuilder:schematicDescriptionPlaceholder"),
              maxLength: MO.ib
            })
          }), (0, fO.jsx)(KK, {
            gameCategory: bK.gameCategory,
            setGameCategory: OO => eO("gameCategory", OO),
            disabled: !CO
          }), !0 === bK.gamePublished && (0, fO.jsx)(GO, {
            schematicData: bK,
            updateSchematicData: eO,
            publishFormEnabled: CO,
            onClose: function() {
              null === pO || void 0 === pO || pO()
            }
          })]
        }), (0, fO.jsx)(IO, {
          schematicData: bK,
          updateSchematicData: eO,
          publishFormEnabled: CO,
          formEnabled: hO
        }), !0 === bK.gamePublished && (0, fO.jsx)(dO, {
          icon: "palette",
          title: XO("worldBuilder:texturePackSection"),
          disabled: !hO,
          children: (0, fO.jsx)(UO, {
            schematicData: bK,
            setTexturePack: KO.setTexturePack,
            initializeTexturePack: KO.initializeTexturePack,
            publishFormEnabled: CO
          })
        })]
      })
    }

    function XK(OO) {
      let {
        editor: KO
      } = OO;
      const {
        t: pO
      } = (0, vK.D)(), {
        schematicData: XO,
        formEnabled: bK,
        hasUnsavedChanges: lO
      } = KO, MO = bK && lO;
      return (0, fO.jsxs)("footer", {
        className: "SchematicPageFooter",
        children: [bK && lO && (0, fO.jsxs)("div", {
          className: "SchematicPageFooterStatus",
          children: [(0, fO.jsx)("span", {
            className: "SchematicPageFooterStatusDot"
          }), pO("worldBuilder:unsavedChanges")]
        }), (0, fO.jsx)(hO.g, {
          tooltipInner: (0, fO.jsx)("div", {
            className: "SaveButtonTooltip",
            children: pO(bK && !lO ? "worldBuilder:saveChangesNoneDescription" : "worldBuilder:saveChangesDescription")
          }),
          children: (0, fO.jsxs)(eO.d, {
            className: "SaveChangesButton",
            onClick: () => KO.saveSchematic(XO.gamePublished),
            disabled: !MO,
            children: [(0, fO.jsxs)("span", {
              className: bK ? "" : "SaveChangesButtonBodyHidden",
              children: [(0, fO.jsx)(DO.d, {
                name: "wrench"
              }), " ", pO("worldBuilder:saveChanges")]
            }), !bK && (0, fO.jsx)(CO.e, {})]
          })
        })]
      })
    }

    function bp(OO) {
      let {
        schematic: KO,
        onSchematicUpdate: pO,
        onClose: bK,
        inSourceWorld: lO
      } = OO;
      const {
        t: CO
      } = (0, vK.D)();

      function hO() {
        null === bK || void 0 === bK || bK()
      }
      const DO = (0, OK.e)(KO, {
        onNavigateAway: hO,
        inSourceWorld: lO
      });
      return (0, XO.useEffect)((() => {
        null === pO || void 0 === pO || pO(DO.schematicData)
      }), [DO.schematicData, pO]), (0, fO.jsxs)("div", {
        className: "SchematicPage SchematicPagePopupVariant",
        children: [(0, fO.jsxs)("div", {
          className: "SchematicPageBody",
          children: [(0, fO.jsx)(eO.c, {
            onClick: hO,
            children: CO("worldBuilder:back")
          }), (0, fO.jsx)(dO, {
            icon: "rocket-launch",
            title: CO("worldBuilder:actionsSection"),
            disabled: !DO.formEnabled,
            children: (0, fO.jsx)(yK.b, {
              editor: DO
            })
          }), (0, fO.jsx)(pK, {
            editor: DO,
            onClose: hO
          })]
        }), (0, fO.jsx)(XK, {
          editor: DO
        })]
      })
    }

    function eK(OO) {
      let {
        schematic: KO,
        onSchematicUpdate: pO,
        onClose: XO,
        inSourceWorld: eO
      } = OO;
      bK.NotificationProvider.showCustomPopup({
        body: OO => (0, fO.jsx)(bp, {
          schematic: KO,
          onSchematicUpdate: pO,
          onClose: OO,
          inSourceWorld: eO
        }),
        middleScreenPopupClassName: "SchematicPopup",
        onClose: XO,
        unlockPointerKey: "schematicPagePopup"
      })
    }
  },
  4078: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => MO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(1051),
      lO = pO(933),
      vK = pO(1271),
      CO = pO(1195),
      hO = pO(1180),
      DO = pO(976);

    function MO(OO) {
      let {
        editor: KO,
        className: pO
      } = OO;
      const {
        t: XO
      } = (0, eO.D)(), {
        schematicData: MO,
        formEnabled: aK,
        publishFormEnabled: oO
      } = KO, FO = !aK || !oO;
      return (0, DO.jsxs)("div", {
        className: bK()("PublishButtonContainer", pO),
        children: [KO.canEditSourceWorld && (0, DO.jsxs)(vK.d, {
          onClick: KO.editSourceWorld,
          disabled: FO,
          children: [(0, DO.jsx)(lO.d, {
            name: "edit"
          }), " ", XO("worldBuilder:editSourceWorld")]
        }), !MO.gamePublished && (0, DO.jsx)(CO.g, {
          tooltipInner: (0, DO.jsx)("div", {
            className: "PublishButtonTooltip",
            children: XO("worldBuilder:publishAsGameDescription")
          }),
          children: (0, DO.jsxs)(vK.m, {
            onClick: () => KO.saveSchematic(!0),
            disabled: FO,
            children: [(0, DO.jsx)(lO.d, {
              name: "rocket-launch"
            }), " ", XO("worldBuilder:publishAsGame"), " ", (0, DO.jsx)(lO.d, {
              name: "info-circle"
            })]
          })
        }), !0 === MO.gamePublished && (0, DO.jsxs)(DO.Fragment, {
          children: [(0, DO.jsx)(CO.g, {
            tooltipInner: (0, DO.jsx)("div", {
              className: "PublishButtonTooltip",
              children: XO("worldBuilder:unpublishAsGameDescription")
            }),
            children: (0, DO.jsxs)(vK.I, {
              onClick: KO.unpublishSchematic,
              disabled: FO,
              children: [(0, DO.jsx)(lO.d, {
                name: "rocket-launch"
              }), " ", XO("worldBuilder:unpublishAsGame"), " ", (0, DO.jsx)(lO.d, {
                name: "info-circle"
              })]
            })
          }), (0, DO.jsxs)(vK.d, {
            onClick: KO.playGame,
            disabled: FO,
            children: [(0, DO.jsx)(lO.d, {
              name: "joystick"
            }), " ", XO("general:playGame")]
          })]
        }), !aK && (0, DO.jsx)(hO.e, {
          loaderType: "Secondary"
        })]
      })
    }
  },
  4111: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(1056);
    async function bK(OO) {
      const KO = await fetch(`${XO.clientSideServerUrls.s3Url}/${OO}`, {
        headers: {
          Accept: "application/json"
        }
      });
      if (404 === KO.status || 403 === KO.status) return null;
      if (!KO.ok) throw new Error(`Failed to download the texture pack (${KO.status})`);
      return await KO.json()
    }
  },
  4176: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => LO
    });
    var XO = pO(63),
      bK = pO(1165),
      eO = pO(886),
      lO = pO(149),
      vK = pO(1382),
      CO = pO(22),
      hO = pO(1556),
      DO = pO(1329),
      MO = pO(3764),
      aK = pO(1187),
      oO = pO(1004),
      FO = pO(1344);

    function VO(OO, KO) {
      return {
        schematicId: OO.schematicId,
        name: OO.name,
        description: OO.description,
        gamePublished: KO,
        gameCategory: OO.gameCategory,
        defaultGamemode: OO.defaultGamemode,
        voidDeathHeight: OO.voidDeathHeight,
        disableKeepInventory: OO.disableKeepInventory,
        disableTpRequests: OO.disableTpRequests,
        disableLobbySpawn: OO.disableLobbySpawn,
        disableMobs: OO.disableMobs,
        disableSpawnProtection: OO.disableSpawnProtection,
        disableFallDamage: OO.disableFallDamage,
        worldBorder: OO.worldBorder,
        hideLobbyCode: OO.hideLobbyCode,
        enableSmpMarketplace: OO.enableSmpMarketplace,
        enableSurvivalGuns: OO.enableSurvivalGuns,
        enableSpawnReset: OO.enableSpawnReset,
        enableDayNight: OO.enableDayNight,
        persistWorld: OO.persistWorld,
        persistInventory: OO.persistInventory
      }
    }

    function LO(OO) {
      let {
        onNavigateAway: KO,
        inSourceWorld: pO = !1
      } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      const {
        userContext: LO
      } = (0, oO.d)(), QO = (0, FO.useNavigatePreserveSearch)(), [zK, AO] = (0, XO.useState)({
        ...OO
      }), [fO, dO] = (0, XO.useState)("Enter"), [TO, NO] = (0, XO.useState)(void 0), IO = (0, XO.useRef)(VO(OO, OO.gamePublished)), yK = (0, XO.useRef)(void 0), gK = "Enter" === fO, uO = LO.playerHasRank("developer") || LO.playerHasRank("admin") || "Enter" === fO && !1 !== zK.schematicContainsSpawnBlock, EO = void 0 !== TO && TO !== yK.current || JSON.stringify(VO(zK, zK.gamePublished)) !== JSON.stringify(IO.current);

      function jK(OO, KO) {
        AO((pO => ({
          ...pO,
          [OO]: KO
        })))
      }
      const YO = (0, XO.useCallback)((OO => {
        yK.current = OO, NO(OO)
      }), []);

      function wO(OO) {
        dO("Loading");
        const KO = VO(zK, OO),
          pO = TO !== yK.current ? TO : void 0;
        DO.c.updateSchematic(LO, KO, pO).then((pO => {
          let {
            customTexturePackKey: XO
          } = pO;
          dO("Success"), jK("customTexturePackKey", XO), IO.current = KO, yK.current = void 0, NO(void 0), setTimeout((() => {
            jK("gamePublished", OO), dO("Enter")
          }), 1e3)
        })).catch((OO => {
          var KO;
          (console.error("Failed to save schematic:", OO), dO("Error"), OO instanceof lO.b && OO.errorMessageForUser) && aK.NotificationProvider.showAlertPopup({
            title: "worldBuilder:changesNotSaved",
            subtitle: OO.errorMessageForUser,
            textOpts: {
              subtitle: null !== (KO = OO.errorMessageTranslationParams) && void 0 !== KO ? KO : void 0
            },
            confirmText: "general:ok"
          });
          setTimeout((() => {
            dO("Enter")
          }), 1e3)
        }))
      }
      return {
        schematicData: zK,
        updateSchematicData: jK,
        setTexturePack: NO,
        initializeTexturePack: YO,
        updateState: fO,
        formEnabled: gK,
        publishFormEnabled: uO,
        hasUnsavedChanges: EO,
        canEditSourceWorld: !pO,
        saveSchematic: wO,
        unpublishSchematic: function() {
          aK.NotificationProvider.showPromptPopup({
            icon: "rocket-launch",
            title: "worldBuilder:unpublishAsGameConfirmTitle",
            subtitle: "worldBuilder:unpublishAsGameConfirmSubtitle",
            confirmText: "worldBuilder:unpublishAsGame",
            cancelText: "general:cancel",
            unlockPointerKey: "unpublishGamePrompt"
          }).getResult().then((OO => {
            !0 === OO && wO(!1)
          }))
        },
        editSourceWorld: function() {
          dO("Loading"), MO.e.getSourceWorld(zK.schematicId).then((OO => {
            hO.gameBridge.send("leaveGame", {
              reloadPath: "/"
            }), (0, CO.j)("other"), QO((0, bK.b)("classic", OO)), null === KO || void 0 === KO || KO()
          })).catch((OO => {
            console.error("Failed to get source world:", OO), dO("Error"), setTimeout((() => {
              dO("Enter")
            }), 1e3)
          }))
        },
        playGame: function() {
          hO.gameBridge.send("leaveGame", {
            reloadPath: "/"
          }), QO((0, vK.u)((0, eO.s)(zK.schematicId), zK)), null === KO || void 0 === KO || KO()
        }
      }
    }
  },
  4061: () => {}
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);