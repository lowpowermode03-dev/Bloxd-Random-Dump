export const id = 334;
export const ids = [334];
export const modules = {
  59080: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      WorldCodeAiOutOfUsage: () => eO
    });
    var XO = pO(1271),
      bK = pO(976);

    function eO(OO) {
      let {
        onGetSuperRank: KO
      } = OO;
      return (0, bK.jsxs)("div", {
        className: "WorldCodeAiOutOfUsage",
        children: [(0, bK.jsx)("p", {
          className: "WorldCodeAiOutOfUsageText",
          children: "You don't have any Super Bot.xd usage left - use Bot.xd or get Super Rank for more usage!"
        }), (0, bK.jsx)(XO.m, {
          className: "WorldCodeAiOutOfUsageButton",
          onClick: KO,
          children: "Get Super Rank"
        })]
      })
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);