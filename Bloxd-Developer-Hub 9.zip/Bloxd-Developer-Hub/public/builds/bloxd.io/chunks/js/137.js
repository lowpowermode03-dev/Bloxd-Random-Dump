export const id = 137;
export const ids = [137];
export const modules = {
  7200: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      GameDistributionSdkAdaptor: () => eO
    });
    var XO = pO(1158),
      bK = pO(1044);
    class eO extends XO.c {
      constructor(OO) {
        super(), this.setOnEndCb = OO, this.name = "gamedistribution"
      }
      static async setup() {
        let OO;
        let KO;
        return window.GD_OPTIONS = {
          gameId: "b35b336d21654aa5a378480d13ed7225",
          onEvent: pO => {
            const XO = () => {
              KO && (window.adCompleteSoResume(), KO = !1), OO && (OO(), OO = null)
            };
            switch (pO.name) {
              case "SDK_GAME_START":
                console.log("Gamedis SDK_GAME_START"), KO = !1, OO ? (OO(), OO = null, window.adCompleteSoResume()) : console.error("onEndCb is not defined during SDK_GAME_START for gamedis sdk. Probably means error happened before.");
                break;
              case "SDK_GAME_PAUSE":
                console.log("Gamedis SDK_GAME_PAUSE"), window.adStartSoPause(null, {
                  preventMovement: !0
                }), KO = !0;
                break;
              case "SDK_ERROR":
                console.error("Gamedis SDK_ERROR fired"), XO();
                break;
              case "SDK_GDPR_TRACKING":
              case "SDK_GDPR_TARGETING":
              default:
                break;
              case "AD_ERROR":
                console.error("Gamedis AD_ERROR fired"), XO();
                break;
              case "AD_IS_ALREADY_RUNNING":
                console.error("Gamedis AD_IS_ALREADY_RUNNING fired"), XO();
                break;
              case "DISPLAYAD_ERROR":
                console.error("Gamedis DISPLAYAD_ERROR fired"), console.error(pO)
            }
          }
        }, await (0, bK.e)("https://html5.api.gamedistribution.com/main.min.js", {
          id: "gamedistribution-jssdk"
        }), new eO((KO => {
          OO = KO
        }))
      }
      playVideoAd(OO, KO) {
        this.setOnEndCb(OO), console.log("Requesting gamedis preroll"), window.gdsdk.showAd()
      }
      renderBanner(OO) {
        console.log("Getting new gamedis banners"), void 0 !== window.gdsdk.AdType.Display ? (console.log("requesting gamedis banner into", document.getElementById(OO.divId)), console.log("Params to window.gdsdk.showAd", window.gdsdk.AdType.Display, OO.divId), window.gdsdk.showAd(window.gdsdk.AdType.Display, {
          containerId: OO.divId
        }).then((() => console.info("showAd(window.gdsdk.AdType.Display) resolved."))).catch((OO => console.info(OO)))) : console.error("window.gdsdk.AdType.Display is undefined")
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);