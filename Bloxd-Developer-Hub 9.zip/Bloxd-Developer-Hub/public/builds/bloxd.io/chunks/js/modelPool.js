export const id = 38;
export const ids = [38];
export const modules = {
  39529: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(142),
      bK = pO(1063);

    function eO(OO) {
      return (0, XO.e)() ? `https://${bK.e.discordDomain}/${OO.href}` : OO.href
    }
    const lO = {
      scriptUrl: eO(new pO.U(pO(39538))),
      wasmBinaryUrl: eO(new pO.U(pO(39542)))
    }
  },
  33011: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK,
      f: () => eO,
      i: () => lO
    });
    const XO = 1179937895,
      bK = 1313821514;

    function eO(OO) {
      const KO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength);
      if (OO.byteLength < 20 || KO.getUint32(0, !0) !== XO || 2 !== KO.getUint32(4, !0)) return null;
      const pO = Math.min(KO.getUint32(8, !0), OO.byteLength),
        eO = KO.getUint32(12, !0);
      if (KO.getUint32(16, !0) !== bK || 20 + eO > pO) return null;
      let lO;
      try {
        lO = JSON.parse((new TextDecoder).decode(OO.subarray(20, 20 + eO)))
      } catch {
        return null
      }
      return "object" === typeof lO && null !== lO ? {
        json: lO,
        jsonEnd: 20 + eO,
        length: pO
      } : null
    }

    function lO(OO) {
      var KO;
      const pO = null === (KO = eO(OO)) || void 0 === KO ? void 0 : KO.json;
      if (void 0 === pO || !Array.isArray(pO.extensionsUsed) || !pO.extensionsUsed.includes("KHR_draco_mesh_compression")) return !1;
      const XO = pO.meshes;
      return Array.isArray(XO) && XO.some((OO => {
        const KO = null === OO || void 0 === OO ? void 0 : OO.primitives;
        return Array.isArray(KO) && KO.some((OO => {
          const KO = null === OO || void 0 === OO ? void 0 : OO.extensions;
          return null != (null === KO || void 0 === KO ? void 0 : KO.KHR_draco_mesh_compression)
        }))
      }))
    }
  },
  41387: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      pageModelPool: () => AO
    });
    var XO = pO(2951),
      bK = pO(34910),
      eO = pO(38841),
      lO = pO(39529),
      vK = pO(38871);
    Error;
    class CO extends Error {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        super(`Draco ${OO}: ${KO}`), this.stage = OO, this.url = pO, this.status = XO, this.name = "DracoLoadError"
      }
      get goneUrl() {
        return 404 === this.status || 410 === this.status ? this.url : null
      }
    }

    function hO(OO, KO) {
      let pO = null,
        bK = !1;
      return {
        get: () => {
          if (null === pO) {
            const eO = async function(OO, KO) {
              try {
                return (await (0, XO.y)(OO)).buffer
              } catch (pO) {
                throw new CO(KO, (0, vK.d)(pO), OO, pO instanceof XO.h ? pO.status : null)
              }
            }(OO, KO);
            pO = eO, eO.then((() => {
              bK = pO === eO
            }), (() => {
              pO = null
            }))
          }
          return pO
        },
        forget: () => {
          bK && (pO = null, bK = !1)
        }
      }
    }

    function DO(OO, KO) {
      const pO = hO(KO, "wasm"),
        XO = hO(OO, "script");
      return async function() {
        arguments.length > 0 && void 0 !== arguments[0] && arguments[0] && (pO.forget(), XO.forget());
        const [OO, KO] = await Promise.all([pO.get(), XO.get()]);
        return {
          script: KO,
          wasmBinary: OO
        }
      }
    }
    var MO = pO(33011),
      aK = pO(2407),
      oO = pO(39029),
      FO = pO(39072);
    class VO extends Error {
      constructor(OO) {
        super(`no model worker could install it: ${OO}`), this.name = "DracoInstallError"
      }
    }
    class LO {
      constructor(OO) {
        this.opts = OO, this.queue = [], this.slots = [], this.stopped = null, this.create = null, this.be = null, this.downloads = 0, this.installFailure = "", this.nextSeq = 0, this.jobLosses = 0;
        for (let KO = 0; KO < Math.max(1, OO.count); KO++) this.slots.push({
          worker: null,
          starting: !1,
          timer: null,
          job: null,
          seq: 0,
          be: "none",
          installSeq: 0,
          failedDownload: 0,
          losses: 0,
          startedAt: void 0,
          gaveUp: !1
        });
        this.downloadDecoder(), this.pump()
      }
      get pending() {
        return this.queue.length + this.slots.filter((OO => null !== OO.job)).length
      }
      build(OO, KO) {
        if (null !== this.stopped) return Promise.resolve((0, oO.o)(OO, this.stopped));
        const pO = (0, MO.i)(KO);
        return pO && this.downloadDecoder(), new Promise((XO => {
          this.queue.push({
            word: OO,
            glb: KO,
            draco: pO,
            attempts: 0,
            resolve: XO
          }), this.pump()
        }))
      }
      dispose() {
        this.fail(null)
      }
      files() {
        return "object" === typeof this.be ? this.be : null
      }
      pump() {
        const OO = this.files();
        for (const KO of this.slots) {
          if (null !== this.stopped) return;
          if (KO.gaveUp || KO.starting) continue;
          if (null === KO.worker) {
            this.start(KO);
            continue
          }
          if (null !== OO && "none" === KO.be && KO.failedDownload !== this.downloads && this.install(KO, KO.worker, OO), null !== KO.job) continue;
          const pO = this.queue.findIndex((OO => "installed" === KO.be || !OO.draco));
          pO >= 0 && this.run(KO, KO.worker, this.queue.splice(pO, 1)[0])
        }
        null === this.stopped && this.checkDecoder()
      }
      checkDecoder() {
        if (null === this.files()) return;
        this.slots.some((OO => !OO.gaveUp && ("none" !== OO.be || OO.failedDownload !== this.downloads))) || (this.be = "uninstallable", this.decoderFailed(new VO(this.installFailure)))
      }
      start(OO) {
        if (OO.losses >= 6) return OO.gaveUp = !0, void(this.slots.every((OO => OO.gaveUp)) && this.fail(new Error("every model worker went 6 times with no file built")));
        OO.starting = !0, this.create ??= this.opts.loadWorker(), Promise.all([this.create, this.opts.module]).then((KO => {
          let [pO, XO] = KO;
          null === this.stopped && this.launch(OO, pO, XO)
        }), (OO => {
          this.fail(OO)
        }))
      }
      launch(OO, KO, pO) {
        let XO;
        try {
          XO = KO()
        } catch (bK) {
          return void this.lose(OO, `a model worker could not be created (${String(bK)})`)
        }
        OO.worker = XO, this.startTimer(OO, 3e4, (KO => {
          this.lose(OO, `a model worker did not start: ${(0,FO.l)(KO)}`)
        })), XO.onmessage = KO => {
          let {
            data: pO
          } = KO;
          this.answered(OO, XO, pO)
        }, XO.onerror = KO => {
          this.lose(OO, OO.starting ? `a model worker failed to start: ${KO.message}` : `a model worker failed: ${KO.message}`)
        }, XO.postMessage({
          type: "start",
          module: pO
        })
      }
      startTimer(OO, KO, pO) {
        OO.timer = new FO.j(KO, (KO => {
          OO.timer = null, pO(KO)
        }), void 0, this.opts.visibility)
      }
      clearTimer(OO) {
        var KO;
        null === (KO = OO.timer) || void 0 === KO || KO.cancel(), OO.timer = null
      }
      answered(OO, KO, pO) {
        if ("lost" === pO.type) return void this.lose(OO, pO.reason);
        if (OO.starting) return "started" !== pO.type ? void this.lose(OO, `a model worker answered ${pO.type} before it started`) : (this.clearTimer(OO), OO.starting = !1, OO.startedAt = performance.now(), void this.pump());
        if ("dracoInstalled" === pO.type || "dracoFailed" === pO.type) {
          if (pO.seq !== OO.installSeq) return;
          return void("installing" === OO.be ? (this.clearTimer(OO), "dracoInstalled" === pO.type ? (OO.be = "installed", this.pump()) : this.installFailed(OO, pO.reason)) : "dracoInstalled" === pO.type && "none" === OO.be && OO.failedDownload === this.downloads && (OO.be = "installed", this.pump()))
        }
        const XO = OO.job;
        null !== XO && "started" !== pO.type && pO.seq === OO.seq && ("trapped" !== pO.type ? (OO.job = null, OO.losses = 0, this.jobLosses = 0, XO.resolve(new Uint8Array(pO.record)), this.pump()) : this.lose(OO, pO.trap, !0))
      }
      install(OO, KO, pO) {
        const XO = this.nextSeq++;
        OO.be = "installing", OO.installSeq = XO, this.startTimer(OO, 3e4, (KO => {
          this.installFailed(OO, `no install within ${Math.round(KO)} ms`)
        }));
        const bK = pO.script.slice(0),
          eO = pO.wasmBinary.slice(0);
        KO.postMessage({
          type: "installDraco",
          seq: XO,
          script: bK,
          wasmBinary: eO
        }, [bK, eO])
      }
      installFailed(OO, KO) {
        console.warn(`[modelPool] a model worker could not install the Draco decoder: ${KO}`), this.noInstall(OO, KO), this.pump()
      }
      noInstall(OO, KO) {
        OO.be = "none", OO.failedDownload = this.downloads, this.installFailure = KO
      }
      downloadDecoder() {
        if (null !== this.stopped || "downloading" === this.be || null !== this.files()) return;
        const OO = "uninstallable" === this.be;
        this.be = "downloading", this.opts.downloadFiles(OO).then((OO => {
          null === this.stopped && (this.be = OO, this.downloads++, this.pump())
        }), (OO => {
          this.be = null, this.decoderFailed(OO)
        }))
      }
      decoderFailed(OO) {
        if (null !== this.stopped) return;
        const KO = (0, vK.d)(OO);
        let pO = 0;
        for (const XO of this.queue.splice(0)) XO.draco ? (XO.resolve((0, oO.g)(XO.word, KO)), pO++) : this.queue.push(XO);
        pO > 0 && this.opts.onDecoderFailed(OO)
      }
      run(OO, KO, pO) {
        const XO = this.nextSeq++;
        OO.seq = XO, OO.job = pO, pO.attempts++;
        const bK = pO.glb.slice();
        KO.postMessage({
          type: "job",
          seq: XO,
          word: pO.word,
          glb: bK.buffer
        }, [bK.buffer])
      }
      lose(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        this.clearTimer(OO);
        const XO = OO.worker;
        null !== XO && (XO.onmessage = null, XO.onerror = null, XO.terminate());
        const bK = !pO && "installing" === OO.be;
        OO.worker = null, OO.starting = !1, OO.be = "none", bK && this.noInstall(OO, KO), void 0 !== OO.startedAt && performance.now() - OO.startedAt >= 6e4 && (OO.losses = 0), OO.startedAt = void 0;
        const eO = OO.job;
        if (OO.job = null, null !== eO || bK || OO.losses++, this.opts.onWorkerLost(KO), null !== eO && bK) eO.attempts--, this.queue.unshift(eO);
        else if (null !== eO && (eO.attempts < 2 ? this.queue.unshift(eO) : eO.resolve((0, oO.l)(eO.word, KO)), this.jobLosses++, this.jobLosses >= 32)) return void this.fail(new Error("model workers were lost on 32 jobs with no file built"));
        this.pump()
      }
      fail(OO) {
        if (null !== this.stopped) return;
        this.stopped = null === OO ? "the model workers stopped" : `the model workers could not start: ${(0,vK.d)(OO)}`;
        const KO = this.stopped,
          pO = OO => {
            OO.resolve((0, oO.o)(OO.word, KO))
          };
        for (const bK of this.slots) {
          var XO;
          this.clearTimer(bK), null === (XO = bK.worker) || void 0 === XO || XO.terminate(), bK.worker = null, null !== bK.job && pO(bK.job), bK.job = null
        }
        this.queue.splice(0).forEach(pO), null !== OO && this.opts.onUnavailable(OO)
      }
    }
    let QO = null;
    const zK = new Set;

    function AO(OO) {
      return zK.add(OO), QO ??= function() {
        let OO = (KO = navigator.hardwareConcurrency, vK = "deviceMemory" in navigator ? navigator.deviceMemory : void 0, KO > 2 && !(0, aK.m)(vK) ? 2 : 1);
        var KO, vK;
        const hO = new LO({
          module: (0, bK.d)(eO.d),
          downloadFiles: DO(lO.c.scriptUrl, lO.c.wasmBinaryUrl),
          loadWorker: async () => (await pO.e(39).then((() => pO(59395)))).createModelWorker,
          count: OO,
          onUnavailable: OO => {
            if (QO === hO) {
              QO = null;
              const KO = function(OO) {
                return OO instanceof XO.d ? [eO.d.url().href] : void 0
              }(OO);
              fO((pO => {
                pO.onUnavailable(OO, KO)
              }))
            }
          },
          onDecoderFailed: OO => {
            if (QO === hO) {
              const KO = OO instanceof CO ? OO.goneUrl : null,
                pO = null === KO ? void 0 : [KO];
              fO((KO => {
                KO.onDecoderFailed(OO, pO)
              }))
            }
          },
          onWorkerLost: OO => {
            QO === hO && fO((KO => {
              KO.onWorkerLost(OO)
            }))
          }
        });
        return hO
      }(), {
        pool: QO,
        unlisten: () => {
          zK.delete(OO)
        }
      }
    }

    function fO(OO) {
      for (const pO of [...zK]) try {
        OO(pO)
      } catch (KO) {
        console.error("[pageModelPool] a listener threw", KO)
      }
    }
  },
  39542: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/draco_decoder_gltf_v2_1.1207caa8c6e38dc2aa04.wasm"
  },
  39538: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/draco_wasm_wrapper_gltf_v2_1.8b33994b6159ad3fc976.js"
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);