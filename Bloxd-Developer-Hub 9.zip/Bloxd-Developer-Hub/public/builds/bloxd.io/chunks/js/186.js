export const id = 186;
export const ids = [186];
export const modules = {
  33001: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => wO,
      e: () => YO,
      i: () => jK
    });
    var XO = pO(33003);
    const bK = {
        fileBytes: 4194304,
        vertices: 65535,
        indices: 196608,
        accessorElements: 196608,
        primitives: 64,
        nodes: 128,
        meshes: 64,
        materials: 8,
        images: 8,
        imageSide: 1024
      },
      eO = {
        items: 1024,
        perFile: 1024,
        surfaces: 256,
        few: 64,
        bounds: 16,
        attributeMembers: 32
      },
      lO = 1048576,
      vK = "is not a binary glTF 2.0 file",
      CO = "loads data from outside the file",
      hO = new Set(["KHR_draco_mesh_compression", "KHR_materials_unlit", "KHR_texture_transform", "KHR_materials_specular", "KHR_materials_ior", "KHR_materials_anisotropy"]),
      DO = {
        POSITION: "VEC3",
        NORMAL: "VEC3",
        TEXCOORD_0: "VEC2",
        COLOR_0: "VEC4"
      },
      MO = {
        type: "VEC2",
        componentTypes: [5126, 5121, 5123]
      },
      aK = {
        TANGENT: {
          type: "VEC4",
          componentTypes: [5126]
        },
        TEXCOORD_1: MO,
        TEXCOORD_2: MO,
        TEXCOORD_3: MO,
        TEXCOORD_4: MO,
        TEXCOORD_5: MO
      },
      oO = new Set(XO.g.map((OO => {
        let [KO] = OO;
        return KO
      }))),
      FO = {
        1: "line",
        2: "line loop",
        3: "line strip",
        5: "triangle strip",
        6: "triangle fan"
      },
      VO = 5126;

    function LO(OO) {
      return OO.toLocaleString("en-US")
    }

    function QO(OO, KO, pO) {
      return OO > KO ? `has ${LO(OO)} ${pO} (the limit is ${LO(KO)})` : null
    }

    function zK(OO, KO) {
      return Number.isInteger(OO) && OO >= 0 && OO < (null !== KO && void 0 !== KO ? KO : 0)
    }

    function AO(OO) {
      return Number.isInteger(OO) && OO >= 0
    }

    function fO(OO, KO) {
      return void 0 !== OO && (!Array.isArray(OO) || OO.length > KO)
    }

    function dO(OO, KO) {
      return "object" === typeof OO && null !== OO && Object.keys(OO).length > KO
    }

    function TO(OO) {
      var KO;
      return `${OO.normalized?"normalized ":""}${null!==(KO=XO.c[OO.componentType])&&void 0!==KO?KO:OO.componentType} ${OO.type}`
    }

    function NO(OO) {
      const KO = KO => {
        var pO;
        return null !== (pO = OO[KO]) && void 0 !== pO ? pO : -1
      };
      return 255 === KO(0) && 216 === KO(1) ? "JPEG" : 82 === KO(0) && 73 === KO(1) && 87 === KO(8) && 69 === KO(9) ? "WebP" : 171 === KO(0) && 75 === KO(1) && 84 === KO(2) && 88 === KO(3) ? "KTX2" : "non-PNG"
    }

    function IO(OO) {
      return OO.length >= 24 && [137, 80, 78, 71, 13, 10, 26, 10].every(((KO, pO) => OO[pO] === KO)) && 73 === OO[12] && 72 === OO[13] && 68 === OO[14] && 82 === OO[15]
    }

    function yK(OO) {
      return /^[aeiou]/i.test(OO) ? `an ${OO}` : `a ${OO}`
    }

    function gK(OO) {
      const KO = OO.byteStride;
      return void 0 === KO || Number.isInteger(KO) && KO >= 4 && KO <= 252 && KO % 4 === 0
    }

    function uO(OO, KO, pO) {
      var XO, bK;
      const eO = null === (XO = OO.bufferViews) || void 0 === XO ? void 0 : XO[pO];
      if (!eO || !KO || 0 !== eO.buffer) return null;
      const lO = null !== (bK = eO.byteOffset) && void 0 !== bK ? bK : 0;
      return !AO(lO) || !AO(eO.byteLength) || lO + eO.byteLength > KO.byteLength ? null : KO.subarray(lO, lO + eO.byteLength)
    }

    function EO(OO, KO) {
      var pO, bK, eO;
      const lO = XO.n[KO.type],
        vK = XO.b[KO.componentType];
      if (!lO || !vK || !Number.isInteger(KO.count) || KO.count < 0) return !1;
      if (void 0 === KO.bufferView) return !0;
      const CO = null === (pO = OO.bufferViews) || void 0 === pO ? void 0 : pO[KO.bufferView],
        hO = null !== (bK = KO.byteOffset) && void 0 !== bK ? bK : 0;
      if (!CO || !AO(hO) || hO % vK !== 0) return !1;
      const DO = lO * vK,
        MO = null !== (eO = CO.byteStride) && void 0 !== eO ? eO : DO;
      if (MO < DO) return !1;
      return (0 === KO.count ? 0 : hO + MO * (KO.count - 1) + DO) <= CO.byteLength
    }

    function jK(OO) {
      return OO > bK.fileBytes ? `is ${(OO/lO).toFixed(1)} MiB (the limit is ${bK.fileBytes/lO} MiB)` : null
    }

    function YO(OO, KO) {
      try {
        return function(OO, KO) {
          var pO, lO, MO, LO, AO, jK, YO, wO, iK, rK, PO, mK, sO, HO, RO, SO, JO;
          const cK = Array.isArray(OO.extensionsUsed) && OO.extensionsUsed.includes("KHR_draco_mesh_compression");
          if (function(OO, KO) {
              var pO, XO;
              const {
                items: bK,
                perFile: lO,
                surfaces: vK,
                few: CO,
                bounds: hO,
                attributeMembers: DO
              } = eO;
              if (fO(OO.extensionsRequired, CO) || fO(OO.animations, 1 / 0) || fO(OO.skins, 1 / 0)) return !0;
              if (null !== (pO = OO.animations) && void 0 !== pO && pO.length || null !== (XO = OO.skins) && void 0 !== XO && XO.length) return !1;
              if ([
                  [OO.buffers, CO],
                  [OO.scenes, CO],
                  [OO.bufferViews, bK],
                  [OO.accessors, bK],
                  [OO.nodes, bK],
                  [OO.meshes, bK],
                  [OO.materials, vK],
                  [OO.textures, vK],
                  [OO.samplers, vK],
                  [OO.images, vK]
                ].some((OO => {
                  let [KO, pO] = OO;
                  return fO(KO, pO)
                }))) return !0;
              for (const eO of null !== (MO = OO.accessors) && void 0 !== MO ? MO : []) {
                var MO, aK, oO;
                if (Number.isInteger(eO.count) && (!Number.isSafeInteger(eO.count) || Object.is(eO.count, -0)) || fO(null !== (aK = eO.min) && void 0 !== aK ? aK : void 0, hO) || fO(null !== (oO = eO.max) && void 0 !== oO ? oO : void 0, hO)) return !0
              }
              for (const eO of null !== (FO = OO.scenes) && void 0 !== FO ? FO : []) {
                var FO;
                if (fO(eO.nodes, bK)) return !0
              }
              let VO = 0;
              for (const eO of null !== (LO = OO.nodes) && void 0 !== LO ? LO : []) {
                var LO, QO, zK;
                if (fO(eO.children, lO)) return !0;
                VO += null !== (QO = null === (zK = eO.children) || void 0 === zK ? void 0 : zK.length) && void 0 !== QO ? QO : 0
              }
              if (VO > lO) return !0;
              let AO = 0;
              for (const eO of null !== (TO = OO.meshes) && void 0 !== TO ? TO : []) {
                var TO;
                if (!Array.isArray(eO.primitives)) return !0;
                if (AO += eO.primitives.length, AO > lO) return !0;
                for (const OO of eO.primitives) {
                  var NO;
                  const pO = KO ? null === (NO = OO.extensions) || void 0 === NO ? void 0 : NO.KHR_draco_mesh_compression : void 0;
                  if (dO(OO.attributes, DO) || dO(null === pO || void 0 === pO ? void 0 : pO.attributes, DO)) return !0
                }
              }
              return !1
            }(OO, cK)) return vK;
          const BO = null === (pO = OO.asset) || void 0 === pO ? void 0 : pO.version;
          if ("string" !== typeof BO || !/^2\.\d+/.test(BO)) return `uses glTF version ${null!==BO&&void 0!==BO?BO:"(none)"}`;
          const ZO = null === (lO = OO.asset) || void 0 === lO ? void 0 : lO.minVersion;
          if (void 0 !== ZO && "2.0" !== ZO) return `uses glTF version ${ZO}`;
          for (const XO of null !== (GO = OO.extensionsRequired) && void 0 !== GO ? GO : []) {
            var GO;
            if (!hO.has(XO)) return `requires the glTF extension ${XO}`
          }
          if (null !== (MO = OO.animations) && void 0 !== MO && MO.length) return "has animations";
          if (null !== (LO = OO.skins) && void 0 !== LO && LO.length) return "uses skins";
          const qK = null !== (AO = OO.buffers) && void 0 !== AO ? AO : [];
          for (const [XO, bK] of qK.entries()) {
            if (void 0 !== bK.uri) return CO;
            if (XO > 0 || !KO) return vK
          }
          for (const [XO, bK] of(null !== (xK = OO.bufferViews) && void 0 !== xK ? xK : []).entries()) {
            var xK;
            if (!uO(OO, KO, XO) || !gK(bK)) return vK
          }
          const nO = null !== (jK = OO.accessors) && void 0 !== jK ? jK : [];
          for (const XO of nO) {
            if (void 0 !== XO.sparse) return "uses sparse accessors";
            const KO = Number.isInteger(XO.count) ? QO(XO.count, bK.accessorElements, "elements in an accessor") : null;
            if (KO) return KO;
            if (!EO(OO, XO)) return vK
          }
          const WO = null !== (YO = OO.scenes) && void 0 !== YO ? YO : [];
          if (1 !== WO.length) return `has ${WO.length} scenes`;
          const tK = (0, XO.v)(OO);
          if (void 0 !== tK && 0 !== tK) return vK;
          const kK = null !== (wO = OO.nodes) && void 0 !== wO ? wO : [],
            UO = null !== (iK = OO.meshes) && void 0 !== iK ? iK : [],
            OK = null !== (rK = OO.materials) && void 0 !== rK ? rK : [],
            KK = null !== (PO = OO.textures) && void 0 !== PO ? PO : [],
            pK = null !== (mK = OO.images) && void 0 !== mK ? mK : [],
            XK = null !== (sO = null !== (HO = null !== (RO = QO(kK.length, bK.nodes, "nodes")) && void 0 !== RO ? RO : QO(UO.length, bK.meshes, "meshes")) && void 0 !== HO ? HO : QO(OK.length, bK.materials, "materials")) && void 0 !== sO ? sO : QO(pK.length, bK.images, "images");
          if (XK) return XK;
          const bp = new Set;
          for (const XO of kK)
            for (const OO of null !== (eK = XO.children) && void 0 !== eK ? eK : []) {
              var eK;
              if (!zK(OO, kK.length) || bp.has(OO)) return vK;
              bp.add(OO)
            }
          const lK = new Set,
            vp = OO => {
              var KO;
              return !lK.has(OO) && (lK.add(OO), (null !== (KO = kK[OO].children) && void 0 !== KO ? KO : []).every(vp))
            };
          for (const XO of null !== (CK = WO[0].nodes) && void 0 !== CK ? CK : []) {
            var CK;
            if (!zK(XO, kK.length) || bp.has(XO) || !vp(XO)) return vK
          }
          for (const XO of kK) {
            if (void 0 !== XO.matrix) return "uses node matrices";
            if (void 0 !== XO.skin) return "uses skins";
            if (void 0 !== XO.weights) return "uses morph targets";
            if (void 0 !== XO.mesh && !zK(XO.mesh, UO.length)) return vK;
            const OO = [
              [XO.translation, 3],
              [XO.rotation, 4],
              [XO.scale, 3]
            ];
            for (const [KO, pO] of OO)
              if (void 0 !== KO && (!Array.isArray(KO) || KO.length !== pO || !KO.every((OO => Number.isFinite(OO))))) return vK
          }
          let hK = -1,
            DK = 0,
            MK = 0,
            ap = null;
          for (const bK of UO) {
            if (void 0 !== bK.weights) return "uses morph targets";
            if (0 === bK.primitives.length) return vK;
            for (const pO of bK.primitives) {
              var oK, FK;
              const bK = null !== (oK = pO.mode) && void 0 !== oK ? oK : 4;
              var VK;
              if (4 !== bK && 0 !== bK) return `uses ${null!==(VK=FO[bK])&&void 0!==VK?VK:`mode ${bK}`} primitives`;
              if (void 0 !== pO.targets) return "uses morph targets";
              if (void 0 !== pO.material && !zK(pO.material, OK.length)) return vK;
              const eO = cK ? null === (FK = pO.extensions) || void 0 === FK ? void 0 : FK.KHR_draco_mesh_compression : void 0;
              if (eO) {
                if (4 !== bK) return "uses Draco-compressed points";
                if (!uO(OO, KO, eO.bufferView) || "object" !== typeof eO.attributes) return vK
              }
              const lO = pO.attributes;
              if ("object" !== typeof lO || null === lO) return vK;
              if (void 0 === lO.POSITION) return "has a primitive with no positions";
              if (!zK(lO.POSITION, nO.length)) return vK;
              const CO = nO[lO.POSITION].count;
              for (const [OO, KO] of Object.entries(lO)) {
                if (!zK(KO, nO.length)) return vK;
                if (/^(JOINTS|WEIGHTS)_\d+$/.test(OO)) return "uses skins";
                const pO = nO[KO],
                  XO = DO[OO];
                if (XO && (pO.componentType !== VO || pO.normalized || pO.type !== XO)) return `stores ${OO} as ${TO(pO)}`;
                const bK = aK[OO];
                if (bK && (pO.type !== bK.type || !bK.componentTypes.includes(pO.componentType) || pO.componentType === VO === !!pO.normalized)) return `stores ${OO} as ${TO(pO)}`;
                if (oO.has(OO) && pO.count !== CO) return "has vertex attributes of different lengths"
              }
              if (eO) {
                if (void 0 === pO.indices) return vK;
                for (const KO in eO.attributes)
                  if (oO.has(KO) && void 0 === lO[KO]) return vK;
                if (void 0 === eO.attributes.POSITION) return vK;
                const OO = zK(pO.indices, nO.length) ? nO[pO.indices].count : -1;
                if (0 === OO) return vK;
                if (-1 === hK) hK = eO.bufferView, DK = CO, MK = OO;
                else {
                  ap ??= new Map([
                    [hK, [DK, MK]]
                  ]);
                  const KO = ap.get(eO.bufferView);
                  if (KO && (KO[0] !== CO || KO[1] !== OO)) return vK;
                  ap.set(eO.bufferView, null !== KO && void 0 !== KO ? KO : [CO, OO])
                }
              }
              let hO = CO;
              if (void 0 !== pO.indices) {
                if (!zK(pO.indices, nO.length)) return vK;
                const OO = nO[pO.indices];
                if ("SCALAR" !== OO.type) return vK;
                if (5121 === OO.componentType) return "uses 8-bit indices";
                var LK;
                if (5123 !== OO.componentType && 5125 !== OO.componentType) return `stores indices as ${null!==(LK=XO.c[OO.componentType])&&void 0!==LK?LK:OO.componentType}`;
                if (!eO && void 0 === OO.bufferView) return vK;
                hO = OO.count
              }
              if (4 === bK && hO % 3 !== 0) return vK
            }
          }
          let QK = 0,
            zp = 0,
            AK = 0;
          for (let XO = 0; XO < kK.length; XO++) {
            const OO = kK[XO].mesh;
            if (void 0 !== OO && lK.has(XO))
              for (const KO of UO[OO].primitives) AK++, QK += nO[KO.attributes.POSITION].count, void 0 !== KO.indices && (zp += nO[KO.indices].count)
          }
          const fK = null !== (SO = null !== (JO = QO(QK, bK.vertices, "vertices")) && void 0 !== JO ? JO : QO(zp, bK.indices, "indices")) && void 0 !== SO ? SO : QO(AK, bK.primitives, "primitives");
          if (fK) return fK;
          for (const XO of OK) {
            var dK, TK;
            if (void 0 !== XO.emissiveTexture) return "uses an emissive texture";
            const KO = null !== (dK = XO.alphaMode) && void 0 !== dK ? dK : "OPAQUE";
            if ("OPAQUE" !== KO && "MASK" !== KO && "BLEND" !== KO) return vK;
            const pO = null === (TK = XO.pbrMetallicRoughness) || void 0 === TK ? void 0 : TK.baseColorTexture;
            if (pO) {
              var NK, IK, yp, gp, uK;
              const KO = null !== (NK = OO.extensionsUsed) && void 0 !== NK && NK.includes("KHR_texture_transform") ? null === (IK = pO.extensions) || void 0 === IK ? void 0 : IK.KHR_texture_transform : void 0;
              if (0 !== (null !== (yp = pO.texCoord) && void 0 !== yp ? yp : 0) || 0 !== (null !== (gp = null === KO || void 0 === KO ? void 0 : KO.texCoord) && void 0 !== gp ? gp : 0)) return "uses a second UV set";
              const XO = KK[pO.index];
              if (!XO || !zK(XO.source, pK.length) || void 0 !== XO.sampler && !zK(XO.sampler, null === (uK = OO.samplers) || void 0 === uK ? void 0 : uK.length)) return vK
            }
          }
          for (const XO of pK) {
            if (void 0 !== XO.uri) return CO;
            if (void 0 === XO.bufferView) return vK;
            const pO = uO(OO, KO, XO.bufferView);
            if (!pO) return vK;
            if ("image/png" !== XO.mimeType) {
              var EK, jp, YK;
              return `has ${yK(null!==(EK=null!==(jp={"image/jpeg":"JPEG","image/webp":"WebP","image/ktx2":"KTX2"}[null!==(YK=XO.mimeType)&&void 0!==YK?YK:""])&&void 0!==jp?jp:XO.mimeType)&&void 0!==EK?EK:"untyped")} image`
            }
            if (!IO(pO)) return `has ${yK(NO(pO))} image`;
            const eO = new DataView(pO.buffer, pO.byteOffset, pO.byteLength),
              lO = eO.getUint32(16),
              hO = eO.getUint32(20);
            if (lO > bK.imageSide || hO > bK.imageSide) return `has a ${lO} \xd7 ${hO} image (the limit is ${bK.imageSide})`
          }
          return null
        }(OO, KO)
      } catch {
        return vK
      }
    }

    function wO(OO) {
      const KO = jK(OO.byteLength);
      if (KO) return KO;
      try {
        const {
          json: KO,
          bin: pO
        } = (0, XO.z)(OO);
        return YO(KO, pO)
      } catch (pO) {
        if (pO instanceof XO.l) return pO.reason;
        throw pO
      }
    }
  },
  33003: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => oO,
      c: () => aK,
      g: () => VO,
      i: () => eO,
      l: () => bK,
      n: () => FO,
      p: () => DO,
      t: () => MO,
      v: () => lO,
      z: () => hO
    });
    var XO = pO(33011);
    class bK extends Error {
      constructor(OO) {
        super(`GLB refused: it ${OO}`), this.reason = OO, this.name = "GlbRefused"
      }
    }
    class eO extends Error {
      constructor(OO) {
        super(OO), this.name = "GlbError"
      }
    }

    function lO(OO) {
      return Reflect.get(OO, "scene")
    }
    const vK = 5130562,
      CO = "is not a binary glTF 2.0 file";

    function hO(OO) {
      var KO;
      const pO = OO instanceof Uint8Array ? OO : new Uint8Array(OO),
        eO = (0, XO.f)(pO);
      if (null === eO) throw new bK(CO);
      const lO = eO.json,
        {
          jsonEnd: hO,
          length: DO
        } = eO,
        MO = new DataView(pO.buffer, pO.byteOffset, pO.byteLength);
      let aK = -1,
        oO = 0;
      for (let LO = hO; LO < DO;) {
        if (LO + 8 > DO) throw new bK(CO);
        const OO = MO.getUint32(LO, !0),
          KO = MO.getUint32(LO + 4, !0);
        if (LO + 8 + OO > DO || KO === XO.b || KO === vK && -1 !== aK) throw new bK(CO);
        KO === vK && (aK = LO + 8, oO = OO), LO += 8 + OO
      }
      let FO = null;
      const VO = null === (KO = lO.buffers) || void 0 === KO ? void 0 : KO[0];
      if (-1 !== aK && VO && void 0 === VO.uri) {
        if (!(VO.byteLength >= 0) || VO.byteLength > oO) throw new bK(CO);
        FO = new Uint8Array(pO.buffer, pO.byteOffset + aK, VO.byteLength)
      }
      return {
        json: lO,
        bin: FO,
        fileBytes: pO.byteLength
      }
    }

    function DO(OO) {
      const KO = OO.slice(OO.indexOf(",") + 1),
        pO = Uint8Array.fromBase64;
      if (pO) return pO(KO).buffer;
      const XO = atob(KO),
        bK = new Uint8Array(XO.length);
      for (let eO = 0; eO < XO.length; eO++) bK[eO] = XO.charCodeAt(eO);
      return bK.buffer
    }
    async function MO(OO) {
      if (OO.startsWith("data:")) return DO(OO);
      const KO = await fetch(OO);
      if (!KO.ok) throw new eO(`fetching ${OO} failed: ${KO.status} ${KO.statusText}`);
      return await KO.arrayBuffer()
    }
    const aK = {
        5120: "i8",
        5121: "u8",
        5122: "i16",
        5123: "u16",
        5125: "u32",
        5126: "f32"
      },
      oO = {
        5120: 1,
        5121: 1,
        5122: 2,
        5123: 2,
        5125: 4,
        5126: 4
      },
      FO = {
        SCALAR: 1,
        VEC2: 2,
        VEC3: 3,
        VEC4: 4,
        MAT2: 4,
        MAT3: 9,
        MAT4: 16
      },
      VO = [
        ["POSITION", "position"],
        ["NORMAL", "normal"],
        ["TANGENT", "tangent"],
        ["TEXCOORD_0", "uv"],
        ["TEXCOORD_1", "uv2"],
        ["TEXCOORD_2", "uv3"],
        ["TEXCOORD_3", "uv4"],
        ["TEXCOORD_4", "uv5"],
        ["TEXCOORD_5", "uv6"],
        ["COLOR_0", "color"]
      ]
  },
  33011: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK,
      f: () => eO,
      i: () => lO
    });
    const XO = 1179937895,
      bK = 1313821514;

    function eO(OO) {
      const KO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength);
      if (OO.byteLength < 20 || KO.getUint32(0, !0) !== XO || 2 !== KO.getUint32(4, !0)) return null;
      const pO = Math.min(KO.getUint32(8, !0), OO.byteLength),
        eO = KO.getUint32(12, !0);
      if (KO.getUint32(16, !0) !== bK || 20 + eO > pO) return null;
      let lO;
      try {
        lO = JSON.parse((new TextDecoder).decode(OO.subarray(20, 20 + eO)))
      } catch {
        return null
      }
      return "object" === typeof lO && null !== lO ? {
        json: lO,
        jsonEnd: 20 + eO,
        length: pO
      } : null
    }

    function lO(OO) {
      var KO;
      const pO = null === (KO = eO(OO)) || void 0 === KO ? void 0 : KO.json;
      if (void 0 === pO || !Array.isArray(pO.extensionsUsed) || !pO.extensionsUsed.includes("KHR_draco_mesh_compression")) return !1;
      const XO = pO.meshes;
      return Array.isArray(XO) && XO.some((OO => {
        const KO = null === OO || void 0 === OO ? void 0 : OO.primitives;
        return Array.isArray(KO) && KO.some((OO => {
          const KO = null === OO || void 0 === OO ? void 0 : OO.extensions;
          return null != (null === KO || void 0 === KO ? void 0 : KO.KHR_draco_mesh_compression)
        }))
      }))
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);