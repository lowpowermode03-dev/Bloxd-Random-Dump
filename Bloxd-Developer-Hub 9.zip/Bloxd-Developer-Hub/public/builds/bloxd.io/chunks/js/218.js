export const id = 218;
export const ids = [218];
export const modules = {
  39125: (OO, KO, pO) => {
    pO.d(KO, {
      noaDevTools: () => MO
    });
    var XO = pO(35875),
      bK = pO(35860),
      eO = pO(2231),
      lO = pO(1481);

    function vK(OO) {
      const {
        Lb: KO
      } = OO, pO = KO.engine, XO = {
        width: pO.getRenderWidth(),
        height: pO.getRenderHeight()
      };
      return {
        canvas: pO.getRenderingCanvas(),
        maxTextureSize: pO.getCaps().maxTextureSize,
        drawing: () => !OO.YL,
        resize: (OO, KO) => {
          pO.setSize(OO, KO)
        },
        restoreSize: () => {
          pO.setSize(XO.width, XO.height), KO.resize()
        },
        onFrameDrawn: KO => (OO.on("afterRender", KO), () => {
          OO.off("afterRender", KO)
        })
      }
    }
    var CO = pO(39106),
      hO = pO(8256);

    function DO(OO, KO) {
      let {
        width: hO,
        height: DO,
        colouring: MO
      } = KO;
      const aK = "normals" === MO,
        oO = "depth" === MO;
      return new Promise((KO => {
        try {
          const FO = (0, eO.d)();
          if (FO.Lb.Qb) return "screenshot" !== OO || null !== MO ? (console.warn("GLB downloads and coloured screenshots need WebGPU off in Graphics settings"), void KO()) : void(0, CO.e)(vK(FO), hO, DO).finally(KO);
          const VO = FO.Lb.engine,
            LO = FO.Lb.JKO(),
            QO = hO,
            zK = DO;
          Promise.all([Promise.all([pO.e(235), pO.e(236), pO.e(216)]).then((() => pO(59055))), Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(233), pO.e(237), pO.e(240), pO.e(291), pO.e(220)]).then((() => pO(59059))), Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(233), pO.e(243), pO.e(237), pO.e(245), pO.e(222)]).then((() => pO(59063))), pO.e(332).then((() => pO(59066))), Promise.all([pO.e(214), pO.e(210)]).then((() => pO(35624))), pO.e(234).then((() => pO(59068))), pO.e(209).then((() => pO(59074)))]).then((eO => {
            const {
              CreateScreenshotUsingRenderTarget: vK
            } = eO[1], {
              ShaderMaterial: CO
            } = eO[2], {
              ShaderLanguage: hO
            } = eO[3], {
              WX: DO
            } = eO[4], {
              registerDevtoolsShader: MO
            } = eO[6], FO = hO.GLSL, AO = new Map, fO = LO.meshes.filter((OO => OO.material));
            let dO = !1,
              TO = null;

            function NO() {
              var OO;
              dO && (dO = !1, (0, XO.i)(LO.meshes, !1)), null === (OO = TO) || void 0 === OO || OO(), TO = null, fO.forEach((OO => {
                const KO = AO.get(OO);
                KO && (OO.material = KO)
              }))
            }
            if (aK) {
              const OO = [],
                KO = [];
              fO.forEach((pO => {
                const XO = pO.name.toLowerCase(),
                  bK = pO.hpO().boundingBox.center,
                  eO = LO.activeCamera.position.subtract(bK).length();
                XO.includes("sky") || XO.includes("background") || XO.includes("environment") || eO > 1e3 ? KO.push(pO) : OO.push(pO)
              })), MO("devtoolsNormal", FO);
              const pO = new CO("normalMaterial", LO, "devtoolsNormal", {
                attributes: ["position", "normal"],
                uniforms: ["worldViewProjection", "world"],
                shaderLanguage: FO
              });
              MO("devtoolsWhite", FO);
              const XO = new CO("whiteMaterial", LO, "devtoolsWhite", {
                attributes: ["position"],
                uniforms: ["worldViewProjection"],
                shaderLanguage: FO
              });
              OO.forEach((OO => {
                AO.set(OO, OO.material), OO.material = pO
              })), KO.forEach((OO => {
                AO.set(OO, OO.material), OO.material = XO
              }))
            } else if (oO) {
              MO("devtoolsDepth", FO);
              const OO = LO.activeCamera.position;
              let KO = 0,
                pO = 1 / 0;
              fO.forEach((XO => {
                const bK = XO.name.toLowerCase();
                if (bK.includes("sky") || bK.includes("background") || bK.includes("environment")) return;
                const eO = XO.hpO().boundingBox.center,
                  lO = DO.TransformCoordinates(eO, XO.getWorldMatrix()),
                  vK = OO.subtract(lO).length();
                vK > 1e3 || (KO = Math.max(KO, vK), pO = Math.min(pO, vK))
              }));
              const XO = KO - pO;
              KO += .1 * XO, pO = Math.max(0, pO - .1 * XO), console.log(`Depth range: min=${pO.toFixed(2)}, max=${KO.toFixed(2)}, range=${XO.toFixed(2)}`), XO < 1 && (KO = pO + 10);
              const bK = new CO("depthMaterial", LO, "devtoolsDepth", {
                attributes: ["position"],
                uniforms: ["worldViewProjection", "world", "cameraPosition", "maxDepth", "minDepth"],
                shaderLanguage: FO
              });
              bK.setVector3("cameraPosition", OO), bK.setFloat("maxDepth", KO), bK.setFloat("minDepth", pO), fO.forEach((OO => {
                AO.set(OO, OO.material), OO.material = bK
              }))
            }
            if ((0, XO.i)(LO.meshes, !0), dO = !0, "glb" === OO && (TO = (0, bK.d)(LO.meshes)), "screenshot" === OO) {
              let OO = `bloxd-screenshot-${QO}x${zK}-${Date.now()}.png`;
              aK ? OO = `bloxd-screenshot-normals-${QO}x${zK}-${Date.now()}.png` : oO && (OO = `bloxd-screenshot-depth-${QO}x${zK}-${Date.now()}.png`), vK(VO, LO.activeCamera, {
                width: QO,
                height: zK
              }, (function(pO) {
                NO(), fetch(pO).then((function(OO) {
                  return OO.blob()
                })).then((function(pO) {
                  (0, lO.downloadBlob)(pO, OO), KO()
                })).catch((function(OO) {
                  console.error("Error processing screenshot:", OO), KO()
                }))
              }), "image/png", void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, (function() {
                console.error("Screenshot timed out"), NO(), KO()
              }))
            } else {
              let OO = "Ce";
              aK ? OO = "scene-normals" : oO && (OO = "scene-depth"), aK || oO ? setTimeout((() => {
                (async function() {
                  const {
                    StandardMaterial: OO
                  } = await Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(233), pO.e(243), pO.e(242), pO.e(221)]).then((() => pO(38355))), {
                    Color3: KO
                  } = await Promise.all([pO.e(215), pO.e(217)]).then((() => pO(35680))), XO = [], bK = [];
                  if (fO.forEach((OO => {
                      const KO = OO.name.toLowerCase(),
                        pO = OO.hpO().boundingBox.center,
                        eO = LO.activeCamera.position.subtract(pO).length();
                      KO.includes("sky") || KO.includes("background") || KO.includes("environment") || eO > 1e3 ? bK.push(OO) : XO.push(OO)
                    })), aK) XO.forEach(((pO, XO) => {
                    const bK = pO.getVerticesData("normal");
                    if (bK) {
                      const eO = [];
                      for (let OO = 0; OO < bK.length; OO += 3) {
                        const KO = Math.abs(bK[OO]),
                          pO = Math.abs(bK[OO + 1]),
                          XO = Math.abs(bK[OO + 2]);
                        eO.push(KO, pO, XO, 1)
                      }
                      pO.setVerticesData("color", eO);
                      const lO = new OO(`vertexColorMat_${XO}`, LO);
                      lO.disableLighting = !0, lO.emissiveColor = new KO(1, 1, 1), lO.specularColor = new KO(0, 0, 0), pO.material = lO
                    }
                  })), bK.forEach(((pO, XO) => {
                    const bK = pO.getVerticesData("position");
                    if (bK) {
                      const eO = [],
                        lO = bK.length / 3;
                      for (let OO = 0; OO < lO; OO++) eO.push(1, 1, 1, 1);
                      pO.setVerticesData("color", eO);
                      const vK = new OO(`whiteMat_${XO}`, LO);
                      vK.disableLighting = !0, vK.emissiveColor = new KO(1, 1, 1), vK.specularColor = new KO(0, 0, 0), pO.material = vK
                    }
                  }));
                  else if (oO) {
                    const pO = LO.activeCamera.position;
                    let bK = 0,
                      eO = 1 / 0;
                    XO.forEach((OO => {
                      const KO = OO.hpO().boundingBox.center,
                        XO = DO.TransformCoordinates(KO, OO.getWorldMatrix()),
                        lO = pO.subtract(XO).length();
                      bK = Math.max(bK, lO), eO = Math.min(eO, lO)
                    }));
                    const lO = bK - eO;
                    bK += .1 * lO, eO = Math.max(0, eO - .1 * lO), lO < 1 && (bK = eO + 10), fO.forEach(((XO, lO) => {
                      const vK = XO.name.toLowerCase(),
                        CO = XO.hpO().boundingBox.center,
                        hO = DO.TransformCoordinates(CO, XO.getWorldMatrix()),
                        MO = pO.subtract(hO).length();
                      if (!(vK.includes("sky") || vK.includes("background") || vK.includes("environment") || MO > 1e3)) {
                        const pO = 1 - Math.min(Math.max((MO - eO) / (bK - eO), 0), 1),
                          vK = new OO(`depthMat_${lO}`, LO);
                        vK.diffuseColor = new KO(pO, pO, pO), vK.specularColor = new KO(0, 0, 0), XO.material = vK
                      }
                    }))
                  }
                })().then((() => Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(233), pO.e(243), pO.e(237), pO.e(242), pO.e(240), pO.e(232), pO.e(245), pO.e(271), pO.e(291), pO.e(225), pO.e(244), pO.e(213)]).then((() => pO(59076))))).then((KO => KO.GLTF2Export.GLBAsync(LO, OO))).then((OO => {
                  NO(), OO.downloadFiles(), KO()
                })).catch((OO => {
                  console.error("Error exporting GLB:", OO), NO(), KO()
                }))
              }), 100) : Promise.all([pO.e(215), pO.e(214), pO.e(235), pO.e(236), pO.e(233), pO.e(243), pO.e(237), pO.e(242), pO.e(240), pO.e(232), pO.e(245), pO.e(271), pO.e(291), pO.e(225), pO.e(244), pO.e(213)]).then((() => pO(59076))).then((pO => {
                pO.GLTF2Export.GLBAsync(LO, OO).then((OO => {
                  NO(), OO.downloadFiles(), KO()
                })).catch((OO => {
                  console.error("Error exporting GLB:", OO), NO(), KO()
                }))
              })).catch((OO => {
                console.error("Error importing serializers:", OO), NO(), KO()
              }))
            }
          })).catch((OO => {
            console.error("Error downloading the scene:", OO), KO()
          }))
        } catch (FO) {
          console.error("Error taking screenshot:", FO), KO()
        }
      }))
    }
    const MO = new class {
      constructor() {
        this.tools = hO.ALL_DEV_TOOLS
      }
      downloadScene(OO, KO) {
        return DO(OO, KO)
      }
      async setAmbientLightIntensity(OO) {
        const {
          Color3: KO
        } = await Promise.all([pO.e(215), pO.e(217)]).then((() => pO(35680)));
        (0, eO.d)().Lb.JKO().ambientColor = KO.FromArray([OO, OO, OO])
      }
    }
  },
  39106: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => CO
    });
    var XO = pO(1492);
    const bK = 33177600,
      eO = 3e4;
    let lO = !1;

    function vK(OO, KO, pO) {
      if (!OO.drawing()) return Promise.reject(new Error("Screenshots need a game to be running"));
      if (lO) return Promise.reject(new Error("A screenshot is already being taken"));
      lO = !0;
      const XO = function(OO, KO, pO) {
        const XO = Math.max(1, OO),
          eO = Math.max(1, KO),
          lO = Math.min(1, pO / Math.max(XO, eO), Math.sqrt(bK / (XO * eO)));
        return {
          width: Math.max(1, Math.floor(XO * lO)),
          height: Math.max(1, Math.floor(eO * lO))
        }
      }(KO, pO, OO.maxTextureSize);
      return OO.resize(XO.width, XO.height), new Promise(((KO, pO) => {
        let XO, bK = 2,
          vK = null;
        const CO = () => {
          var KO;
          lO = !1, null === (KO = vK) || void 0 === KO || KO(), clearTimeout(XO), OO.restoreSize()
        };
        XO = setTimeout((() => {
          CO(), pO(new Error("No frame was drawn to capture"))
        }), eO), vK = OO.onFrameDrawn((() => {
          if (bK--, bK > 0) return;
          const {
            canvas: XO
          } = OO, eO = {
            width: XO.width,
            height: XO.height
          };
          try {
            XO.toBlob((OO => {
              OO ? KO({
                blob: OO,
                ...eO
              }) : pO(new Error("The canvas gave no image"))
            }), "image/png")
          } catch (lO) {
            pO(lO)
          } finally {
            CO()
          }
        }))
      }))
    }
    async function CO(OO, KO, pO) {
      try {
        const bK = await vK(OO, KO, pO);
        (0, XO.d)(bK.blob, `bloxd-screenshot-${bK.width}x${bK.height}-${Date.now()}.png`)
      } catch (bK) {
        console.error("Error taking screenshot:", bK)
      }
    }
  },
  35875: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => hO,
      i: () => vK,
      l: () => lO
    });
    var XO = pO(35866),
      bK = pO(35879);
    let eO = 0;

    function lO(OO, KO) {
      const pO = OO;
      pO._noaFaceGroups = null !== KO && void 0 !== KO ? KO : null, pO._noaFaceEpoch = -1, pO._noaFaceMask = -1, pO._noaFaceCount = -1, pO._noaFaceMaterial = null;
      const XO = OO.au;
      XO && 1 === XO.length && (XO[0].indexStart = 0, XO[0].indexCount = OO.getTotalIndices())
    }

    function vK(OO, KO) {
      if (KO) {
        eO++;
        for (const KO of OO) {
          const OO = KO._noaFaceGroups;
          OO && lO(KO, OO)
        }
      } else eO = Math.max(0, eO - 1)
    }

    function CO(OO, KO, pO) {
      let bK = -1,
        eO = 0;
      for (let lO = 0; lO < XO.e; lO++) {
        const pO = OO[lO],
          vK = OO[lO + 1];
        vK > pO && KO & 1 << XO.d[lO] && (bK < 0 && (bK = pO), eO = vK)
      }
      return bK < 0 ? (pO[0] = 0, pO[1] = 0, 0) : (pO[0] = bK, pO[1] = eO - bK, eO - bK)
    }
    class hO {
      constructor(OO, KO) {
        this.SX = OO, this.engine = KO, this.epoch = 0, this.eyeX = NaN, this.eyeY = NaN, this.eyeZ = NaN, this.focalPx = NaN, this.culling = !1, this.range = new Int32Array(2)
      }
      apply(OO, KO) {
        if (!KO) return;
        const pO = KO.getProjectionMatrix().m,
          lO = 0 === eO && 0 === pO[15],
          vK = KO.globalPosition,
          {
            engine: hO
          } = this,
          DO = lO ? (0, bK.c)(pO, hO.getRenderWidth(), hO.getRenderHeight()) : 0;
        vK.x === this.eyeX && vK.y === this.eyeY && vK.z === this.eyeZ && DO === this.focalPx && lO === this.culling || (this.epoch++, this.eyeX = vK.x, this.eyeY = vK.y, this.eyeZ = vK.z, this.focalPx = DO, this.culling = lO);
        const {
          epoch: MO,
          range: aK
        } = this, oO = this.SX / 2, FO = oO * Math.sqrt(3), VO = OO.data, LO = OO.length;
        let QO = 0;
        for (let eO = 0; eO < LO; eO++) {
          const OO = VO[eO],
            KO = OO._noaFaceGroups;
          if (KO && (OO._noaFaceEpoch !== MO || OO._noaFaceMaterial !== OO.material)) {
            OO._noaFaceEpoch = MO, OO._noaFaceMaterial = OO.material;
            const pO = OO.au,
              eO = pO && 1 === pO.length ? pO[0] : null;
            let hO = -1;
            if (lO && eO && (0, XO.k)(OO.material)) {
              const pO = OO.position,
                XO = vK.x - pO.x,
                eO = vK.y - pO.y,
                lO = vK.z - pO.z,
                CO = XO - oO,
                MO = eO - oO,
                aK = lO - oO,
                VO = Math.sqrt(CO * CO + MO * MO + aK * aK) + FO;
              hO = (0, bK.l)(KO, XO, eO, lO, (0, bK.d)(VO, DO))
            }
            if (eO && hO !== OO._noaFaceMask) {
              OO._noaFaceMask = hO;
              let pO = 0,
                bK = KO[XO.e]; - 1 !== hO && (bK = CO(KO, hO, aK), pO = aK[0]), OO._noaFaceCount = bK, eO.indexStart = 6 * pO, eO.indexCount = 6 * bK, eO.setBoundingInfo(OO.hpO())
            }
          }
          KO && 0 === OO._noaFaceCount || (VO[QO++] = OO)
        }
        OO.length = QO
      }
    }
  },
  35860: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO,
      g: () => vK
    });
    const XO = new WeakSet;
    let bK = 0;
    const eO = new Set;

    function lO(OO, KO) {
      OO._data = KO
    }

    function vK(OO) {
      var KO, pO;
      (null !== (KO = null === (pO = OO.getBuffer()) || void 0 === pO ? void 0 : pO.YO) && void 0 !== KO ? KO : 0) > 0 && (XO.add(OO), 0 === bK ? lO(OO, null) : eO.add(OO))
    }

    function CO(OO) {
      bK++;
      for (const pO of function(OO) {
          const KO = new Set;
          for (const bK of OO) {
            const OO = bK.geometry;
            for (const bK of Object.values(null !== (pO = null === OO || void 0 === OO ? void 0 : OO.getVertexBuffers()) && void 0 !== pO ? pO : {})) {
              var pO;
              const OO = bK.getWrapperBuffer();
              XO.has(OO) && KO.add(OO)
            }
          }
          return KO
        }(OO)) pO.getData() || hO(pO), eO.add(pO);
      let KO = !0;
      return () => {
        if (KO && (KO = !1, bK--, 0 === bK)) {
          for (const OO of eO) lO(OO, null);
          eO.clear()
        }
      }
    }

    function hO(OO) {
      const KO = OO.getBuffer();
      if (!KO || !(KO.YO > 0)) return;
      const pO = OO._engine,
        XO = new Uint8Array(KO.YO);
      pO.bindArrayBuffer(KO), pO._gl.getBufferSubData(pO._gl.ARRAY_BUFFER, 0, XO), pO._resetVertexBufferBinding(), lO(OO, XO)
    }
  },
  35866: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      e: () => eO,
      g: () => CO,
      h: () => XO,
      i: () => vK,
      j: () => bK,
      k: () => hO
    });
    const XO = 6,
      bK = [0, 2, 4, 1, 3, 5, 0, 2],
      eO = 6,
      lO = [1, 0, 3, 2, 5, 4];
    for (let DO = eO; DO < bK.length; DO++)
      if (bK[DO] !== bK[DO - eO]) throw new Error("FACE_LAYOUT must repeat a prefix of its base groups");
    const vK = bK.length + 1,
      CO = (() => {
        const OO = [];
        for (let KO = 0; KO < eO; KO++) OO[bK[KO]] = KO;
        return OO
      })();

    function hO(OO) {
      return !!OO && OO.backFaceCulling && (0 === OO.transparencyMode || 1 === OO.transparencyMode)
    }
  },
  35879: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK,
      d: () => CO,
      h: () => DO,
      l: () => hO,
      n: () => FO
    });
    var XO = pO(35866);
    const bK = 1 / 16,
      eO = 1 / 64,
      lO = 2048;
    XO.h;

    function vK(OO, KO, pO) {
      return Math.min(Math.abs(OO[0] * KO), Math.abs(OO[5] * pO)) / 2
    }

    function CO(OO, KO) {
      return bK + eO * OO * OO / KO
    }

    function hO(OO, KO, pO, bK, eO) {
      const lO = XO.i;
      return DO(OO[lO], OO[lO + 1], OO[lO + 2], OO[lO + 3], OO[lO + 4], OO[lO + 5], KO, pO, bK, eO)
    }

    function DO(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
      return (lO <= OO - hO ? 0 : 1) | (lO >= KO + hO ? 0 : 2) | (vK <= pO - hO ? 0 : 4) | (vK >= XO + hO ? 0 : 8) | (CO <= bK - hO ? 0 : 16) | (CO >= eO + hO ? 0 : 32)
    }
    const MO = (() => {
        const OO = [];
        for (let KO = 0; KO < XO.j.length; KO++) {
          let pO = 0;
          for (let bK = KO + 1; bK <= XO.j.length; bK++) {
            const eO = 1 << XO.j[bK - 1];
            if (pO & eO) break;
            pO |= eO, OO.push({
              start: KO,
              end: bK,
              qX: pO
            })
          }
        }
        return OO
      })(),
      aK = [];

    function oO(OO, KO) {
      const pO = XO.g[KO];
      return OO[pO + 1] - OO[pO]
    }

    function FO(OO, KO, pO) {
      let bK = 0;
      for (let lO = 0; lO < XO.h; lO++) oO(OO, lO) > 0 && (bK |= 1 << lO);
      if (0 === (KO &= bK)) return 0;
      if (KO === bK) return pO[0] = 0, pO[1] = OO[XO.e], 1;
      let eO = null,
        vK = 1 / 0;
      for (const hO of function(OO) {
          let KO = aK[OO];
          if (KO) return KO;
          const pO = new Map,
            XO = (OO, KO) => {
              const XO = 4 * OO + KO.length / 2;
              pO.has(XO) || pO.set(XO, {
                qX: OO,
                windows: KO
              })
            };
          for (const eO of MO)
            if ((eO.qX & OO) === OO && XO(eO.qX, [eO.start, eO.end]), 0 !== (eO.qX & OO))
              for (const KO of MO) KO.start < eO.end || 0 !== (eO.qX & KO.qX) || 0 === (KO.qX & OO) || ((eO.qX | KO.qX) & OO) !== OO || XO(eO.qX | KO.qX, [eO.start, eO.end, KO.start, KO.end]);
          const bK = [...pO.values()];
          return KO = bK.filter((OO => !bK.some((KO => KO !== OO && (KO.qX & OO.qX) === KO.qX && KO.windows.length <= OO.windows.length)))), aK[OO] = KO, KO
        }(KO)) {
        let pO = (hO.windows.length / 2 - 1) * lO;
        const CO = hO.qX & ~KO & bK;
        for (let KO = 0; KO < XO.h; KO++) CO & 1 << KO && (pO += oO(OO, KO));
        pO < vK && (eO = hO, vK = pO)
      }
      const CO = eO.windows;
      for (let XO = 0; XO < CO.length; XO += 2) {
        const KO = OO[CO[XO]];
        pO[XO] = KO, pO[XO + 1] = OO[CO[XO + 1]] - KO
      }
      return CO.length / 2
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);