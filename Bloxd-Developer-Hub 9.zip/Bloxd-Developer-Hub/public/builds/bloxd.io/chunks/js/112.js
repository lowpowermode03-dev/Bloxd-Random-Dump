export const id = 112;
export const ids = [112];
export const modules = {
  5669: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => aK
    });
    var XO = pO(1180),
      bK = pO(63),
      eO = pO(105),
      lO = pO(1355),
      vK = pO(1086),
      CO = pO(243),
      hO = pO(554);
    const DO = new URL(vK.j[CO.c.PRODUCTION]).origin;
    var MO = pO(976);

    function aK() {
      const OO = (0, lO.w)();
      return (0, bK.useEffect)((() => {
        const KO = eO.currentUrl.getSearchParam("code");
        eO.currentUrl.removeSearchParam("code"), null === KO && (console.error("No authorization code found in the URL"), window.close());
        const pO = {
          type: `oauth_authentication_${OO.providerName}`,
          code: KO
        };
        for (const OO of (bK = window.location.origin) === DO ? [bK, `https://${hO.e}`] : [bK]) {
          var XO;
          null === (XO = window.opener) || void 0 === XO || XO.postMessage(pO, OO)
        }
        var bK;
        setTimeout((() => {
          window.close()
        }), 1e3)
      })), (0, MO.jsx)("div", {
        className: "AuthCallback",
        children: (0, MO.jsx)(XO.e, {
          showFace: !0,
          loading: !0
        })
      })
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);