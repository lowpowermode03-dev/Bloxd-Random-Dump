export const id = 213;
export const ids = [213, 217];
export const modules = {
  39849: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(39784),
      bK = pO(38056);
    let eO = !1;

    function lO() {
      eO || (eO = !0, bK.d.prototype._sphericalPolynomialTargetSize = 0, bK.d.prototype.forceSphericalPolynomialsRecompute = function() {
        this._texture && (this._texture._sphericalPolynomial = null, this._texture._sphericalPolynomialPromise = null, this._texture._sphericalPolynomialComputed = !1)
      }, Object.defineProperty(bK.d.prototype, "sphericalPolynomial", {
        get: function() {
          if (this._texture) {
            if (this._texture._sphericalPolynomial || this._texture._sphericalPolynomialComputed) return this._texture._sphericalPolynomial;
            if (this._texture.isReady) return this._texture._sphericalPolynomialPromise || (this._texture._sphericalPolynomialPromise = XO.b.ConvertCubeMapTextureToSphericalPolynomial(this), null === this._texture._sphericalPolynomialPromise ? this._texture._sphericalPolynomialComputed = !0 : this._texture._sphericalPolynomialPromise.then((OO => {
              this._texture._sphericalPolynomial = OO, this._texture._sphericalPolynomialComputed = !0
            }))), null
          }
          return null
        },
        set: function(OO) {
          this._texture && (this._texture._sphericalPolynomial = OO)
        },
        enumerable: !0,
        configurable: !0
      }))
    }
  },
  35680: (OO, KO, pO) => {
    pO.d(KO, {
      Color3: () => XO.e,
      c: () => XO.g
    });
    var XO = pO(35688);
    (0, XO.h)()
  },
  36142: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(36146);
    class bK {
      static GetPlanes(OO) {
        const KO = [];
        for (let pO = 0; pO < 6; pO++) KO.push(new XO.d(0, 0, 0, 0));
        return bK.GetPlanesToRef(OO, KO), KO
      }
      static GetNearPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[2], KO.normal.y = pO[7] + pO[6], KO.normal.z = pO[11] + pO[10], KO.d = pO[15] + pO[14], KO.normalize()
      }
      static GetFarPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[2], KO.normal.y = pO[7] - pO[6], KO.normal.z = pO[11] - pO[10], KO.d = pO[15] - pO[14], KO.normalize()
      }
      static GetLeftPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[0], KO.normal.y = pO[7] + pO[4], KO.normal.z = pO[11] + pO[8], KO.d = pO[15] + pO[12], KO.normalize()
      }
      static GetRightPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[0], KO.normal.y = pO[7] - pO[4], KO.normal.z = pO[11] - pO[8], KO.d = pO[15] - pO[12], KO.normalize()
      }
      static GetTopPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[1], KO.normal.y = pO[7] - pO[5], KO.normal.z = pO[11] - pO[9], KO.d = pO[15] - pO[13], KO.normalize()
      }
      static GetBottomPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[1], KO.normal.y = pO[7] + pO[5], KO.normal.z = pO[11] + pO[9], KO.d = pO[15] + pO[13], KO.normalize()
      }
      static GetPlanesToRef(OO, KO) {
        bK.GetNearPlaneToRef(OO, KO[0]), bK.GetFarPlaneToRef(OO, KO[1]), bK.GetLeftPlaneToRef(OO, KO[2]), bK.GetRightPlaneToRef(OO, KO[3]), bK.GetTopPlaneToRef(OO, KO[4]), bK.GetBottomPlaneToRef(OO, KO[5])
      }
      static IsPointInFrustum(OO, KO) {
        for (let pO = 0; pO < 6; pO++)
          if (KO[pO].dotCoordinate(OO) < 0) return !1;
        return !0
      }
    }
  },
  36146: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK
    });
    var XO = pO(35632);
    class bK {
      constructor(OO, KO, pO, bK) {
        this.normal = new XO.o(OO, KO, pO), this.d = bK
      }
      WhO() {
        return [this.normal.x, this.normal.y, this.normal.z, this.d]
      }
      clone() {
        return new bK(this.normal.x, this.normal.y, this.normal.z, this.d)
      }
      getClassName() {
        return "Plane"
      }
      getHashCode() {
        let OO = this.normal.getHashCode();
        return OO = 397 * OO ^ this.d, OO
      }
      normalize() {
        const OO = Math.sqrt(this.normal.x * this.normal.x + this.normal.y * this.normal.y + this.normal.z * this.normal.z);
        let KO = 0;
        return 0 !== OO && (KO = 1 / OO), this.normal.x *= KO, this.normal.y *= KO, this.normal.z *= KO, this.d *= KO, this
      }
      transform(OO) {
        const KO = bK._TmpMatrix;
        OO.invertToRef(KO);
        const pO = KO.m,
          XO = this.normal.x,
          eO = this.normal.y,
          lO = this.normal.z,
          vK = this.d,
          CO = XO * pO[0] + eO * pO[1] + lO * pO[2] + vK * pO[3],
          hO = XO * pO[4] + eO * pO[5] + lO * pO[6] + vK * pO[7],
          DO = XO * pO[8] + eO * pO[9] + lO * pO[10] + vK * pO[11],
          MO = XO * pO[12] + eO * pO[13] + lO * pO[14] + vK * pO[15];
        return new bK(CO, hO, DO, MO)
      }
      dotCoordinate(OO) {
        return this.normal.x * OO.x + this.normal.y * OO.y + this.normal.z * OO.z + this.d
      }
      copyFromPoints(OO, KO, pO) {
        const XO = KO.x - OO.x,
          bK = KO.y - OO.y,
          eO = KO.z - OO.z,
          lO = pO.x - OO.x,
          vK = pO.y - OO.y,
          CO = pO.z - OO.z,
          hO = bK * CO - eO * vK,
          DO = eO * lO - XO * CO,
          MO = XO * vK - bK * lO,
          aK = Math.sqrt(hO * hO + DO * DO + MO * MO);
        let oO;
        return oO = 0 !== aK ? 1 / aK : 0, this.normal.x = hO * oO, this.normal.y = DO * oO, this.normal.z = MO * oO, this.d = -(this.normal.x * OO.x + this.normal.y * OO.y + this.normal.z * OO.z), this
      }
      isFrontFacingTo(OO, KO) {
        return XO.o.Dot(this.normal, OO) <= KO
      }
      signedDistanceTo(OO) {
        return XO.o.Dot(OO, this.normal) + this.d
      }
      static FromArray(OO) {
        return new bK(OO[0], OO[1], OO[2], OO[3])
      }
      static FromPoints(OO, KO, pO) {
        const XO = new bK(0, 0, 0, 0);
        return XO.copyFromPoints(OO, KO, pO), XO
      }
      static FromPositionAndNormal(OO, KO) {
        const pO = new bK(0, 0, 0, 0);
        return this.FromPositionAndNormalToRef(OO, KO, pO)
      }
      static FromPositionAndNormalToRef(OO, KO, pO) {
        return pO.normal.NhO(KO), pO.normal.normalize(), pO.d = -OO.dot(pO.normal), pO
      }
      static SignedDistanceToPlaneFromPositionAndNormal(OO, KO, pO) {
        const bK = -(KO.x * OO.x + KO.y * OO.y + KO.z * OO.z);
        return XO.o.Dot(pO, KO) + bK
      }
    }
    bK._TmpMatrix = XO.c.Identity()
  },
  35624: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      Matrix: () => XO.c,
      Quaternion: () => XO.g,
      RegisterMathVector: () => XO.i,
      TmpVectors: () => XO.j,
      Vector2: () => XO.m,
      WX: () => XO.o,
      Vector4: () => XO.s
    });
    var XO = pO(35632);
    (0, XO.i)()
  },
  36513: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    class XO {
      constructor(OO, KO, pO, XO) {
        this.x = OO, this.y = KO, this.width = pO, this.height = XO
      }
      toGlobal(OO, KO) {
        return new XO(this.x * OO, this.y * KO, this.width * OO, this.height * KO)
      }
      toGlobalToRef(OO, KO, pO) {
        return pO.x = this.x * OO, pO.y = this.y * KO, pO.width = this.width * OO, pO.height = this.height * KO, this
      }
      clone() {
        return new XO(this.x, this.y, this.width, this.height)
      }
    }
  },
  39784: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO
    });
    var XO = pO(35632),
      bK = pO(35664),
      eO = pO(38048),
      lO = pO(35639),
      vK = pO(35688);
    class CO {
      constructor(OO, KO, pO, XO) {
        this.name = OO, this.worldAxisForNormal = KO, this.worldAxisForFileX = pO, this.worldAxisForFileY = XO
      }
    }
    class hO {
      static _NearestPow2Floor(OO) {
        return OO <= 1 ? 1 : 1 << Math.floor(Math.log2(OO))
      }
      static ConvertCubeMapTextureToSphericalPolynomial(OO) {
        if (!OO.isCube) return null;
        OO.JKO()?.qb().flushFramebuffer();
        const KO = OO.getSize().width,
          pO = OO._sphericalPolynomialTargetSize,
          XO = pO > 0 ? this._NearestPow2Floor(pO) : 0,
          bK = !OO.noMipmap && !0 === OO._texture?.generateMipMaps,
          eO = XO > 0 && XO < KO && bK,
          lO = eO ? Math.max(0, Math.round(Math.log2(KO / XO))) : 0,
          vK = eO ? Math.max(1, Math.floor(KO / Math.pow(2, lO))) : KO,
          CO = OO.readPixels(0, lO, void 0, !1),
          hO = OO.readPixels(1, lO, void 0, !1);
        let DO, MO;
        OO.isRenderTarget ? (DO = OO.readPixels(3, lO, void 0, !1), MO = OO.readPixels(2, lO, void 0, !1)) : (DO = OO.readPixels(2, lO, void 0, !1), MO = OO.readPixels(3, lO, void 0, !1));
        const aK = OO.readPixels(4, lO, void 0, !1),
          oO = OO.readPixels(5, lO, void 0, !1),
          FO = OO.gammaSpace,
          VO = XO > 0 && XO < KO && !eO;
        return new Promise((OO => {
          Promise.all([hO, CO, DO, MO, aK, oO]).then((pO => {
            let [bK, eO, lO, CO, hO, DO] = pO, MO = vK;
            if (VO) {
              const OO = 4;
              bK = this._DownsampleFace(bK, KO, XO, OO), eO = this._DownsampleFace(eO, KO, XO, OO), lO = this._DownsampleFace(lO, KO, XO, OO), CO = this._DownsampleFace(CO, KO, XO, OO), hO = this._DownsampleFace(hO, KO, XO, OO), DO = this._DownsampleFace(DO, KO, XO, OO), MO = XO
            }
            const aK = {
              size: MO,
              right: eO,
              left: bK,
              up: lO,
              down: CO,
              front: hO,
              back: DO,
              format: 5,
              type: bK instanceof Float32Array ? 1 : 0,
              gammaSpace: FO
            };
            OO(this.ConvertCubeMapToSphericalPolynomial(aK))
          }))
        }))
      }
      static _AreaElement(OO, KO) {
        return Math.atan2(OO * KO, Math.sqrt(OO * OO + KO * KO + 1))
      }
      static _DownsampleFace(OO, KO, pO, XO) {
        const bK = OO instanceof Float32Array ? OO : Float32Array.from(OO),
          eO = pO * pO * XO,
          lO = new Float32Array(eO),
          vK = KO / pO,
          CO = 1 / (vK * vK);
        for (let DO = 0; DO < pO; DO++) {
          const OO = Math.floor(DO * vK),
            eO = Math.floor((DO + 1) * vK);
          for (let hO = 0; hO < pO; hO++) {
            const MO = Math.floor(hO * vK),
              aK = Math.floor((hO + 1) * vK),
              oO = (DO * pO + hO) * XO;
            for (let pO = 0; pO < XO; pO++) {
              let vK = 0;
              for (let lO = OO; lO < eO; lO++)
                for (let OO = MO; OO < aK; OO++) vK += bK[(lO * KO + OO) * XO + pO];
              lO[oO + pO] = vK * CO
            }
          }
        }
        if (OO instanceof Float32Array) return lO;
        const hO = new(0, OO.constructor)(eO);
        for (let DO = 0; DO < eO; DO++) hO[DO] = lO[DO] + .5 | 0;
        return hO
      }
      static ConvertCubeMapToSphericalPolynomial(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        const pO = KO > 0 ? this._NearestPow2Floor(KO) : 0;
        if (pO > 0 && OO.size > pO) {
          const KO = 5 === OO.format ? 4 : 3,
            XO = ["right", "left", "up", "down", "front", "back"],
            bK = {};
          for (const eO of XO) bK[eO] = this._DownsampleFace(OO[eO], OO.size, pO, KO);
          OO = {
            ...OO,
            ...bK,
            size: pO
          }
        }
        const XO = new eO.e;
        let CO = 0;
        const hO = 2 / OO.size,
          DO = hO,
          MO = .5 * hO,
          aK = MO - 1;
        for (let eO = 0; eO < 6; eO++) {
          const KO = this._FileFaces[eO],
            pO = OO[KO.name];
          let oO = aK;
          const FO = 5 === OO.format ? 4 : 3;
          for (let eO = 0; eO < OO.size; eO++) {
            let VO = aK;
            for (let DO = 0; DO < OO.size; DO++) {
              const aK = KO.worldAxisForFileX.scale(VO).add(KO.worldAxisForFileY.scale(oO)).add(KO.worldAxisForNormal);
              aK.normalize();
              const LO = this._AreaElement(VO - MO, oO - MO) - this._AreaElement(VO - MO, oO + MO) - this._AreaElement(VO + MO, oO - MO) + this._AreaElement(VO + MO, oO + MO);
              let QO = pO[eO * OO.size * FO + DO * FO + 0],
                zK = pO[eO * OO.size * FO + DO * FO + 1],
                AO = pO[eO * OO.size * FO + DO * FO + 2];
              isNaN(QO) && (QO = 0), isNaN(zK) && (zK = 0), isNaN(AO) && (AO = 0), 0 === OO.type && (QO /= 255, zK /= 255, AO /= 255), OO.gammaSpace && (QO = Math.pow((0, bK.Clamp)(QO), lO.e), zK = Math.pow((0, bK.Clamp)(zK), lO.e), AO = Math.pow((0, bK.Clamp)(AO), lO.e));
              const fO = this.MAX_HDRI_VALUE;
              if (this.PRESERVE_CLAMPED_COLORS) {
                const OO = Math.max(QO, zK, AO);
                if (OO > fO) {
                  const KO = fO / OO;
                  QO *= KO, zK *= KO, AO *= KO
                }
              } else QO = (0, bK.Clamp)(QO, 0, fO), zK = (0, bK.Clamp)(zK, 0, fO), AO = (0, bK.Clamp)(AO, 0, fO);
              const dO = new vK.e(QO, zK, AO);
              XO.addLight(aK, dO, LO), CO += LO, VO += hO
            }
            oO += DO
          }
        }
        const oO = 6 * (4 * Math.PI) / 6 / CO;
        return XO.scaleInPlace(oO), XO.convertIncidentRadianceToIrradiance(), XO.convertIrradianceToLambertianRadiance(), eO.f.FromHarmonics(XO)
      }
    }
    hO._FileFaces = [new CO("right", new XO.o(1, 0, 0), new XO.o(0, 0, -1), new XO.o(0, -1, 0)), new CO("left", new XO.o(-1, 0, 0), new XO.o(0, 0, 1), new XO.o(0, -1, 0)), new CO("up", new XO.o(0, 1, 0), new XO.o(1, 0, 0), new XO.o(0, 0, 1)), new CO("down", new XO.o(0, -1, 0), new XO.o(1, 0, 0), new XO.o(0, 0, -1)), new CO("front", new XO.o(0, 0, 1), new XO.o(1, 0, 0), new XO.o(0, -1, 0)), new CO("back", new XO.o(0, 0, -1), new XO.o(-1, 0, 0), new XO.o(0, -1, 0))], hO.MAX_HDRI_VALUE = 4096, hO.PRESERVE_CLAMPED_COLORS = !1
  },
  39575: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO.i,
      g: () => XO.s
    });
    var XO = pO(38104);
    (0, XO.v)()
  },
  36274: (OO, KO, pO) => {
    function XO() {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (OO => {
        const KO = 16 * Math.random() | 0;
        return ("x" === OO ? KO : 3 & KO | 8).toString(16)
      }))
    }
    pO.d(KO, {
      b: () => XO
    })
  },
  39825: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO
    });
    var XO = pO(39812),
      bK = pO(39827);
    class eO {
      static ExpandRGBDTexture(OO) {
        const KO = OO._texture;
        if (!KO || !OO.isRGBD) return;
        const bK = KO.qb(),
          eO = bK.getCaps(),
          lO = KO.isReady;
        let vK = !1;
        eO.textureHalfFloatRender && eO.textureHalfFloatLinearFiltering ? (vK = !0, KO.type = 2) : eO.textureFloatRender && eO.textureFloatLinearFiltering && (vK = !0, KO.type = 1), vK && (KO.isReady = !1, KO._isRGBD = !1, KO.invertY = !1);
        const CO = async () => {
          const eO = bK.isWebGPU,
            lO = eO ? 1 : 0;
          KO.isReady = !1, eO ? await pO.e(322).then((() => pO(59271))) : await pO.e(304).then((() => pO(59280)));
          const vK = new XO.d("rgbdDecode", "rgbdDecode", null, null, 1, null, 3, bK, !1, void 0, KO.type, void 0, null, !1, void 0, lO);
          vK.externalTextureSamplerBinding = !0;
          const CO = bK.createRenderTargetTexture(KO.width, {
            generateDepthBuffer: !1,
            generateMipMaps: !1,
            generateStencilBuffer: !1,
            samplingMode: KO.samplingMode,
            type: KO.type,
            format: 5
          });
          vK.onEffectCreatedObservable.addOnce((pO => {
            pO.executeWhenCompiled((() => {
              vK.onApply = OO => {
                OO._bindTexture("textureSampler", KO), OO.setFloat2("scale", 1, 1)
              }, OO.JKO()?.postProcessManager.directRender([vK], CO, !0), bK.restoreDefaultFramebuffer(), bK._releaseTexture(KO), vK && vK.dispose(), CO._swapAndDie(KO), KO.isReady = !0
            }))
          }))
        };
        vK && (lO ? CO() : OO.onLoadObservable.addOnce(CO))
      }
      static async EncodeTextureToRGBD(OO, KO) {
        let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        return KO.qb().isWebGPU ? await pO.e(323).then((() => pO(59303))) : await pO.e(305).then((() => pO(59295))), await (0, bK.e)("rgbdEncode", OO, KO, XO, 1, 5)
      }
    }
  },
  59055: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      AsyncLoop: () => XO.e,
      RegisterTools: () => XO.i,
      Tools: () => XO.k,
      className: () => XO.o
    });
    var XO = pO(38172);
    (0, XO.i)()
  },
  39862: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK
    });
    class XO {
      constructor(OO) {
        this._pendingActions = new Array, this._workerInfos = OO.map((OO => ({
          workerPromise: Promise.resolve(OO),
          idle: !0
        })))
      }
      dispose() {
        for (const OO of this._workerInfos) OO.workerPromise.then((OO => {
          OO.terminate()
        }));
        this._workerInfos.length = 0, this._pendingActions.length = 0
      }
      push(OO) {
        this._executeOnIdleWorker(OO) || this._pendingActions.push(OO)
      }
      _executeOnIdleWorker(OO) {
        for (const KO of this._workerInfos)
          if (KO.idle) return this._execute(KO, OO), !0;
        return !1
      }
      _execute(OO, KO) {
        OO.idle = !1, OO.workerPromise.then((pO => {
          KO(pO, (() => {
            const KO = this._pendingActions.shift();
            KO ? this._execute(OO, KO) : OO.idle = !0
          }))
        }))
      }
    }
    class bK extends XO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : bK.DefaultOptions;
        super([]), this._maxWorkers = OO, this._createWorkerAsync = KO, this._options = pO
      }
      push(OO) {
        if (!this._executeOnIdleWorker(OO))
          if (this._workerInfos.length < this._maxWorkers) {
            const KO = {
              workerPromise: this._createWorkerAsync(),
              idle: !1
            };
            this._workerInfos.push(KO), this._execute(KO, OO)
          } else this._pendingActions.push(OO)
      }
      _execute(OO, KO) {
        OO.timeoutId && (clearTimeout(OO.timeoutId), delete OO.timeoutId), super._execute(OO, ((pO, XO) => {
          KO(pO, (() => {
            XO(), OO.idle && (OO.timeoutId = setTimeout((() => {
              OO.workerPromise.then((OO => {
                OO.terminate()
              }));
              const KO = this._workerInfos.indexOf(OO); - 1 !== KO && this._workerInfos.splice(KO, 1)
            }), this._options.idleTimeElapsedBeforeRelease))
          }))
        }))
      }
    }
    bK.DefaultOptions = {
      idleTimeElapsedBeforeRelease: 1e3
    }
  },
  59076: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      AbstractThreeMfSerializer: () => Gv,
      BVHExporter: () => yv,
      ContentTypeFileName: () => ov,
      DefaultXmlSerializerFormatOptions: () => Jl,
      DefaultXmlSerializerNumberOptions: () => Sl,
      EXT_lights_area: () => Lb,
      EXT_mesh_gpu_instancing: () => HX,
      EXT_texture_avif: () => bv,
      EXT_texture_webp: () => Ol,
      GLTF2Export: () => PX,
      GLTFData: () => hO,
      GetXmlFieldMeta: () => Pl,
      GetXmlName: () => mv,
      IsQualifiedName: () => gv,
      KHR_draco_mesh_compression: () => tb,
      KHR_interactivity: () => hb,
      KHR_lights_punctual: () => eb,
      KHR_materials_anisotropy: () => fb,
      KHR_materials_clearcoat: () => ye,
      KHR_materials_coat: () => wb,
      KHR_materials_diffuse_roughness: () => ml,
      KHR_materials_diffuse_transmission: () => Hb,
      KHR_materials_dispersion: () => ce,
      KHR_materials_emissive_strength: () => qe,
      KHR_materials_fuzz: () => De,
      KHR_materials_ior: () => te,
      KHR_materials_iridescence: () => Ke,
      KHR_materials_openpbr: () => Se,
      KHR_materials_sheen: () => ee,
      KHR_materials_specular: () => Fe,
      KHR_materials_transmission: () => zl,
      KHR_materials_unlit: () => Ne,
      KHR_materials_volume: () => ue,
      KHR_materials_volume_scatter: () => we,
      KHR_texture_basisu: () => We,
      KHR_texture_transform: () => Ze,
      Known3mfRelationshipTypes: () => Fv,
      KnownI3mfContentType: () => Cv,
      Matrix3d: () => fv,
      MatrixFormatter: () => dv,
      ModelFileName: () => Mv,
      NumberFormatter: () => Zl,
      OBJExport: () => lO,
      Object3dDirName: () => Dv,
      OpenXmlContentTypesNamespace: () => lv,
      OpenXmlRelationshipsNamespace: () => vC,
      RegisterEXT_lights_area: () => ze,
      RegisterEXT_mesh_gpu_instancing: () => SX,
      RegisterEXT_texture_avif: () => ll,
      RegisterEXT_texture_webp: () => pl,
      RegisterKHR_draco_mesh_compression: () => UX,
      RegisterKHR_interactivity: () => Mb,
      RegisterKHR_lights_punctual: () => ve,
      RegisterKHR_materials_anisotropy: () => Tb,
      RegisterKHR_materials_clearcoat: () => ub,
      RegisterKHR_materials_coat: () => re,
      RegisterKHR_materials_diffuse_roughness: () => He,
      RegisterKHR_materials_diffuse_transmission: () => Sb,
      RegisterKHR_materials_dispersion: () => Zb,
      RegisterKHR_materials_emissive_strength: () => nb,
      RegisterKHR_materials_fuzz: () => al,
      RegisterKHR_materials_ior: () => Ub,
      RegisterKHR_materials_iridescence: () => Xe,
      RegisterKHR_materials_openpbr: () => cl,
      RegisterKHR_materials_sheen: () => vl,
      RegisterKHR_materials_specular: () => Le,
      RegisterKHR_materials_transmission: () => fe,
      RegisterKHR_materials_unlit: () => yl,
      RegisterKHR_materials_volume: () => jl,
      RegisterKHR_materials_volume_scatter: () => rl,
      RegisterKHR_texture_basisu: () => kl,
      RegisterKHR_texture_transform: () => ql,
      RelationshipDirName: () => hv,
      RelationshipFileName: () => aC,
      ResolveFormatOptions: () => Bl,
      ResolveNumberOptions: () => cv,
      STLExport: () => vv,
      ST_ObjectType: () => ev,
      ST_Unit: () => bC,
      StringXmlWriter: () => Ov,
      ThreeDimModelNamespace: () => pv,
      ThreeMf: () => qC,
      ThreeMfBase: () => mC,
      ThreeMfBaseMaterials: () => Pv,
      ThreeMfBuild: () => sv,
      ThreeMfComponent: () => rC,
      ThreeMfComponents: () => iC,
      ThreeMfComponentsBuilder: () => Sv,
      ThreeMfContentType: () => Lv,
      ThreeMfContentTypes: () => Vv,
      ThreeMfDocument: () => Av,
      ThreeMfDocumentBuilder: () => Zv,
      ThreeMfItem: () => Hv,
      ThreeMfMaterialBuilder: () => cC,
      ThreeMfMesh: () => uv,
      ThreeMfMeshBuilder: () => Jv,
      ThreeMfMeta: () => Nv,
      ThreeMfMetadataGroup: () => Iv,
      ThreeMfModel: () => Tv,
      ThreeMfModelBuilder: () => Bv,
      ThreeMfObject: () => gC,
      ThreeMfObjectBuilder: () => Rv,
      ThreeMfRelationship: () => zC,
      ThreeMfRelationships: () => Qv,
      ThreeMfResources: () => yC,
      ThreeMfSerializer: () => Wv,
      ThreeMfSerializerGlobalConfiguration: () => xC,
      ThreeMfTriangle: () => wv,
      ThreeMfTriangles: () => Yv,
      ThreeMfVertex: () => jC,
      ThreeMfVertices: () => Ev,
      ToQualifiedString: () => Rl,
      TokenType: () => kv,
      TriangleSetsNamespace: () => Xv,
      USDZExportAsync: () => Nl,
      Utf8XmlWriterToBytes: () => Kv,
      XmlAttr: () => iv,
      XmlBuilder: () => Ul,
      XmlElem: () => rv,
      XmlIgnore: () => wl,
      XmlName: () => Yl,
      XmlNameToParts: () => Hl,
      XmlSerializer: () => Wl,
      _ConvertToGLTFPBRMetallicRoughness: () => yX,
      _SolveMetallic: () => Ip,
      __IGLTFExporterExtension: () => vK
    });
    var XO = pO(35624),
      bK = pO(59055),
      eO = pO(38382);
    class lO {
      static OBJ(OO, KO, pO, lO) {
        const vK = [];
        let CO = 1,
          hO = 1;
        KO && (pO || (pO = "mat"), vK.push("mtllib " + pO + ".mtl"));
        for (let DO = 0; DO < OO.length; DO++) {
          const pO = OO[DO],
            MO = pO.name || `mesh${DO}}`;
          vK.push(`o ${MO}`);
          let aK = null;
          if (lO) {
            const OO = pO.computeWorldMatrix(!0);
            aK = new XO.Matrix, OO.invertToRef(aK), pO.bakeTransformIntoVertices(OO)
          }
          if (KO) {
            const OO = pO.material;
            OO && vK.push("usemtl " + OO.id)
          }
          const oO = pO.geometry;
          if (!oO) {
            bK.Tools.Warn("No geometry is present on the mesh");
            continue
          }
          const FO = oO.getVerticesData("position"),
            VO = oO.getVerticesData("normal"),
            LO = oO.getVerticesData("uv"),
            QO = oO.rFO();
          let zK = 0,
            AO = 0;
          if (!FO || !QO) {
            bK.Tools.Warn("There are no position vertices or indices on the mesh!");
            continue
          }
          const fO = OO[0].JKO().useRightHandedSystem ? 1 : -1;
          for (let OO = 0; OO < FO.length; OO += 3) vK.push("v " + FO[OO] * fO + " " + FO[OO + 1] + " " + FO[OO + 2]), zK++;
          if (null != VO)
            for (let OO = 0; OO < VO.length; OO += 3) vK.push("vn " + VO[OO] * fO + " " + VO[OO + 1] + " " + VO[OO + 2]);
          if (null != LO)
            for (let OO = 0; OO < LO.length; OO += 2) vK.push("vt " + LO[OO] + " " + LO[OO + 1]), AO++;
          const dO = ["", "", ""],
            TO = (pO.material || pO.JKO().defaultMaterial)._getEffectiveOrientation(pO),
            [NO, IO] = TO === eO.b.ClockWiseSideOrientation ? [2, 1] : [1, 2];
          for (let OO = 0; OO < QO.length; OO += 3) {
            const KO = [String(QO[OO] + CO), String(QO[OO + NO] + CO), String(QO[OO + IO] + CO)],
              pO = [String(QO[OO] + hO), String(QO[OO + NO] + hO), String(QO[OO + IO] + hO)],
              XO = KO,
              bK = null != LO ? pO : dO,
              eO = null != VO ? KO : dO;
            vK.push("f " + XO[0] + "/" + bK[0] + "/" + eO[0] + " " + XO[1] + "/" + bK[1] + "/" + eO[1] + " " + XO[2] + "/" + bK[2] + "/" + eO[2])
          }
          lO && aK && pO.bakeTransformIntoVertices(aK), CO += zK, hO += AO
        }
        return vK.join("\n")
      }
      static MTL(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "mat1";
        const pO = [],
          XO = OO.material;
        pO.push("newmtl " + KO), pO.push("  Ns " + XO.specularPower.toFixed(4)), pO.push("  Ni 1.5000"), pO.push("  d " + XO.alpha.toFixed(4)), pO.push("  Tr 0.0000"), pO.push("  Tf 1.0000 1.0000 1.0000"), pO.push("  illum 2"), pO.push("  Ka " + XO.ambientColor.r.toFixed(4) + " " + XO.ambientColor.g.toFixed(4) + " " + XO.ambientColor.b.toFixed(4)), pO.push("  Kd " + XO.diffuseColor.r.toFixed(4) + " " + XO.diffuseColor.g.toFixed(4) + " " + XO.diffuseColor.b.toFixed(4)), pO.push("  Ks " + XO.specularColor.r.toFixed(4) + " " + XO.specularColor.g.toFixed(4) + " " + XO.specularColor.b.toFixed(4)), pO.push("  Ke " + XO.emissiveColor.r.toFixed(4) + " " + XO.emissiveColor.g.toFixed(4) + " " + XO.emissiveColor.b.toFixed(4));
        XO.ambientTexture && pO.push("  map_Ka " + XO.ambientTexture.name), XO.diffuseTexture && pO.push("  map_Kd " + XO.diffuseTexture.name), XO.specularTexture && pO.push("  map_Ks " + XO.specularTexture.name), XO.bumpTexture && pO.push("  map_bump -imfchan z " + XO.bumpTexture.name), XO.opacityTexture && pO.push("  map_d " + XO.opacityTexture.name);
        return pO.join("\n")
      }
    }
    var vK = 0,
      CO = pO(39575);
    class hO {
      constructor() {
        this.files = {}
      }
      get glTFFiles() {
        return this.files
      }
      downloadFiles() {
        for (const OO in this.files) {
          const KO = this.files[OO],
            pO = new Blob([KO], {
              type: (0, CO.e)(OO)
            });
          bK.Tools.Download(pO, OO)
        }
      }
    }
    var DO = pO(39297),
      MO = pO(39251),
      aK = pO(39660),
      oO = pO(39254),
      FO = pO(37880),
      VO = pO(35653),
      LO = pO(35680),
      QO = pO(35664);
    const zK = QO.HighestCommonFactor,
      AO = {
        ...QO,
        TwoPi: 2 * Math.PI,
        Sign: Math.sign,
        Log2: Math.log2,
        HCF: zK
      };
    var fO = pO(39827),
      dO = pO(39279),
      TO = pO(39616),
      NO = pO(39620),
      IO = pO(39846);
    (0, IO.RegisterDumpTools)();
    var yK = pO(38063),
      gK = pO(38066),
      uO = pO(37061),
      EO = pO(38186),
      jK = pO(38580),
      YO = pO(39825);
    let wO = 0;
    const iK = (OO, KO, pO, XO) => {
        if (!OO[pO]) {
          const bK = OO.useDelayedTextureLoading;
          OO.useDelayedTextureLoading = !1;
          const eO = OO._blockEntityCollection;
          OO._blockEntityCollection = !1;
          const lO = jK.e.CreateFromBase64String(KO, XO + wO++, OO, !0, !1, jK.e.BILINEAR_SAMPLINGMODE);
          OO._blockEntityCollection = eO;
          const vK = OO.qb().getLoadedTexturesCache(),
            CO = vK.indexOf(lO.getInternalTexture()); - 1 !== CO && vK.splice(CO, 1), lO.isRGBD = !0, lO.wrapU = jK.e.CLAMP_ADDRESSMODE, lO.wrapV = jK.e.CLAMP_ADDRESSMODE, OO[pO] = lO, OO.useDelayedTextureLoading = bK, YO.c.ExpandRGBDTexture(lO);
          const hO = OO.qb().onContextRestoredObservable.add((() => {
            lO.isRGBD = !0;
            const KO = OO.onBeforeRenderObservable.add((() => {
              lO.isReady() && (OO.onBeforeRenderObservable.remove(KO), YO.c.ExpandRGBDTexture(lO))
            }))
          }));
          OO.cpO.add((() => {
            OO.qb().onContextRestoredObservable.remove(hO)
          }))
        }
        return OO[pO]
      },
      rK = OO => iK(OO, "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAgAElEQVR42u29yY5tWXIlZnbuiSaTbZFUkZRKrCKhElASQA0EoQABgn6hJvoXzfUP+gP9hWb6Bg00IgRoQJaKqUxmZmTEe8/v0uB2u7Fm2T7HIyIrnz88uPvt3f2a2WrMbOvf/u3PvvzP/sUf/N6//i8vf/lv/3v5H//d//Sb//Uq/5u8yf8hV/m/5Cp/L1f5hVzlG7nKJ7mKyJuIXN/hPwqXI/g++zq6rPI5u8z+WqfLre+zy7PrVv9L8brsMiGvk8XLmM/sdfHXal4e3ad6GXPdyu2ij8u/+uv/5cuf/OSLfdtEfvUr+dnf/d0X//t3H/7bf/hP//N/928h/0Yg/4VA/kogfyGQP5Wr/IFAvhbIlwK5CGQTPP+9z5uPeePJSW+yo2+s/GtN30Rnv1E+f5zxof9R/lSXv/nr//mrr3+i+5dfyX7ZZQP07Tffys//8R/l/9TtX7790T/7r/8G8pdy+/8XAvnnAvkzgfwzgfyxQP5AIL8vkJ8K5KsmMVzu1U7p5PA5AXxOAJ8TwPf7sX/51ZeXfcemqnp9w/W77/S7X/6T/vzf/7383RWCX3/z05/9i3/13/0PX//eX/2FyP8tIv+PiPy9iPy/IvIzEfm5iPxCRH4lIt/c/393//9BRD6KyKf7f488fP74/PH544dJAF9cLl98IZfLBZtuqterXr/7Dt9982v95S9+Lv+gF/3i7Spv/8lf/vnf/vGf/dF/JfKnIvLnIvLvReQ/NEngn0TklyLy6/v/34jIt00iGJOBlxAsdvv54/PH5493SQCXy9t2ueh2ueimKorrFbjq9eNH+fDtb+TXv/ol/vHyhX4Fxfbx7euPf/Lnf/PfiPyeiPyhiPxxkwB+fk8AvxzQgJcIrGTwFsiAEXH4/PH54/PHUgLY7whgu2C7bLqpQgHB2xvePn6SDx8+6G9+84384vKF/IPu8iVU9Y/+7C/+jWxffiHytYj8VER+X0T+oEEBvxqQwCMJeIngo5EI3goIwVMIPn98/vj8ESaAbbtu2ybbvl8u2ybbdtluSECA65u8ffqIDx8+6G++/VZ/efkV/sO261dQXP7wT/7kX8vl8qXIFyLylbySwe/dE0CLAr65B/9vGn0gQwRMMqgmhM/J4fPH548eAezbZd/lsm3YtssNAYiqiogAAkCvb5/k46cP8u2HD/rrb7+R/2/b9Wu9yJe//8d/9Ney6S5yEZFdRL68/38khG/uKOCnAwoYkcCoEXwkEgGDDq7CeQfyOTl8/vhd1QCum26ybZtu2yabbrKpQvXue1yvuF6v+vbpTT5+/CDffviAX1++1V9sO77WXb/66R/+4V/dgkbllQi+aBLBV/dE8LWRALwkYCWCNyMZXElkwLTMeMkga/P4/PH547ccAVwuctkvdxSw6bbdtYDbTfSZBN7e8PHTR/3u4wf55vKd/nL7DX6mu3791U9//5+/gkNFZGuSgZUQvnKowKgLWLTAQgRtEniTuEfwaELw0MJvf3LQzynud+53uG+X6y3gN9kul+2y6XVT1U27JCDAFVc8ksAn/e7jR/nN5YP+avtWfq6Xy9f7Vz/9w1dgRYngiyYhfNkkgzYBWHTg44AEMmqQUYQKOmDaiCIa8TmsfmzB+DnZDQjgcpGLbti2y3bZHjRAdRMVvb/dcYU8kcDbPQlsH/CrbddfbF98+RPZfvLFnAQeieCRDC5DMvju/vmD4JkEvjRQgKULeGggowdHkAHTYxihg89vu88I5UeGAPSOAFTlrgPopiqbKPSmCKreUoAAkCcSePukHz590m8vH+WbD9/JP335k6/+tA86KxFchv8jMvhiogE4JQm8XhfKqOAqx5qRPyeGzx8/cgSwbXcUoLJtim27C4Oi93+4v6VxQwKAvl2v+Hj9pB8+fZJvt4/yzfbF9lPdv/wJnsE2BogmyeCRED40tGFvksIXiSbgiYSRRpDNDZ6BDI6ghM+J4fPHeyKAO+zX7cb9t4tedMMNAQju5V+f1uAtBSiu1zsduMrHy5t8ePsk3376KN98sX/xE5FPAnm7/782o0DiUINXMkCXCB7/P94/e87AWUmARQWVvgMuKej9t1RLBp+Tw+ePgwngsutFFdu26WXbbl+rSvdfbnqAiuA23QcBgCugV1zl7e1NPm5v+LC96XfbJ/1W9y++fgXjA3bDYXV+MuhRwSPwL3JLMFYC+HS/LU8HYrGwIhwyNOF12SvgM4SgztdifP85MXz+KGsA2C6X7aJ6bXSAOwrY5OYIqGy3d5uq4P5GhABXuV6veLvRAf10fZMPb2/y3b7vX7+g+9v98/WOBq7GG7RNAlYy+Dgkhhb+Xxp0sE8IAC4SGAP/TbgVJK/PoJPBnAiwPKxsXfbbnRg+i3s/JAK4Q/4b9NfLtomBAqCickMBjy7BuywAUVyv8na94tMjCVzf9KNcLl/0SeA6oAEYb1i9g+FtSALb/bKL8/+t+wxXFMyswqiHoK4ToIgKqslgpg1qUC0QoYbvJZg/B/q5v4szHmPX7YEAsD0CX25OwEUVm9xag1+agKg+nxQArnKjAtDr9U0+Xd/k4/UqH7bL5YsewrcBBiMJZPRAp6TwQgWfjM9vgRbgUYGL8AvLWH2gqhesCokeUmCSwPsnhs8fP2YNYMO2XeSmAWxy2VQaXeDmDIhApf33rD4PTUCuV+DtCn27XuXT5ir8VmCJ2G5BpBM8/r/dEcJb8/0lEQMtJHA5TAlqNuLRhJChhEpSqFabH3di+G1AGj+W1/dyAR4IYJNNnuLf6+tWC9CHHiAtFhAIFLjK2/Uqn65X+SS67aK+3QeTDoy/IG2ogQ7fb/dAtz5vBgrYGqrwNtCHsVfgIvwK07OTQBURVNCBFpKCOjqCHn5L/67TgTN+fpySAC56nwSUi256kXsSuFGAVyLoUIDo8/Pz7fdoErr/v17lk162HbgHvFpIYDfoAJJfW4sGPjkU4VNAF8ZEcLmLhdc7kljdY1y1Dq9yLiI4IiRqcLujb138KIPn80ejATwRwIbtBvn1cqv+2J78/5EI5N4cJA8qIPcmwRsKAHDF9WYP6mV7VmrgLuTpxYTcMEW0LAmoQxFsuvAI8tv/a/C5fV2ZMMiKg++FCM7RDPRu8ebWY7VG6VJi+Bzk35MI2LsAckMAgwvQ0gC5DQjd3ABg2HQLAPpEAlZ1Bu7VV7MGHDFRAbo3VKsTbAY9sPWC/uvx86gBbDK3D1eEQS8pbAeSgSwmhepnJb6uBv/o/PzHLzxWA/X7TH77De5j6AGQi6o0CUGfCOD2X7cXAlCFQABtEsGLDtxuOyQB2UTQBKZe5GUPXgkUYCUAbZJRhBDeuq8xBf+bgwbehDm+BFQi2IJksOocvA8ysIMfxluVcRsY/eB3JzH8GFDAXQO48X/dcIf9jyDHptIigDsFkEe066tBSETQUYF7ElDdYEBytN4+rk9UcBPfrKaZqFHWcw3i4J8/X4ev2//bSXqAhwTay6OEIPLD2Ipt8OtAGzxkwLw9WVFRjTc/qC6H3+YK/b1oAA0KuOizHfieCLaHHiAb5NYTIC9EMEbZrVEQt1xwhVy1UfBh8PUOquMizwaap3tQXfY5B//tea/NZdfhsvbz+PURQTDSGWB87VX/7WSd4KxjUqrIgE0IUkoKGnhIvwvawpGf6eECXJ7tv4qbA7DJgwpsKthEmmYgfaAAffYF3HLxo0vwNjJ0SwRWMG4db4eh1gPNm18vQ+us/0eGmxDemu/fnM/X4evq/8342ksGHgLY5LyT/zg0wM8lcMjgGFXwqIOVFJBQw99eCvF9oZL9Mfl3QwAvIXDsBRC9R+fz8x0FPBLB0xJEpwUobrfAkARgIAF41h3wQgP6QAmX5E/7eI43IxGwwf/moIkRyWRJQIPgt9CA9b39nzt4bYUWjAlCjWDPgv8IEjgLJfzuaAsrv9VdVG4OwOXW/fdoA35qAdL0BDwvf6AAUVHd8LIEu94A3K+Q+2YxaB84MOH62P//qoo38fCRDERE2zf0JfmDa+MieElAjcDPKz+mRKCOtdgGtXaBjgNJ4H2owSpNeAW/rRH4CaHSpMwnBYYycjgSJwfie9CR6mPu20Uv8kABF206AvXlBMiIBPSlB9wjBW1fwEuSb94296VCqgMaGCt/G1BbExi3IG+r3a3J6P48Gv/J0YmEYoiGY7V/SxwFCwGoE/xa0AJ0CEiV9QPCJb1OJ5F1VTjEY2/MO9AEJvj1BJTQpqLfTlGwjABuzT962e4IoKnyrdh3+/6mzDVJ4PHOxj0JqGKoy20+wBMN6D1gLWi9NQHfVP5MEEPzjGYy8BMAOnTAJgEr8HUIejRo5xrA5xkR5AngmiSHs+zDDAmMgWzTg55GSJEmHE8IvWPAoYTfhWak/Wn/bQ0CGLSAjv83SUEfKp5q24LXuQICpzrjrgWoza8xVE00CQCORdhMJuTUT/rjuls0gO4Iby8BIEgK6gS7BsGuTtDrScH/fR68biUHNVGBnxjeNyHEvQe/ve3LZQqgG3rof6cEclsNflG9J4KtaQ8WHcVBHS1BtHE4QP9OBMS98mpbKTeDW7dJwRsnHpMBTFJpV4I+b0kY/NqInVFSyBLANbnMSgBM8F+Fqfxq/h657/Up+GaBnwV9hRqc9bZ/vA6vu+T9E8KPJWns94UfTeCj2QXwCHS9dNL8Xf3Ho/rfewSeFODGDV69AU0y6NFAE1DP3qK++rdB7/1HRxf86gT376zOr99T/h/ioBiXWQkgQgVeIrCC/WomhDmQK+hASI2ARQZKooHMLdCJwGEBBXC3+uERwg+VOHZ9ioAt9H80AI06wGgJ3nQA3BoCut6AhxYwgcPOFnxuFnrphk+NIKIGrWPQtgz3b0i7Y6D5rs1GKqTop0nQX52vmQC4BkjA+r4a7Kx9WLENGeegkhSETBCrNXIMdi/444Rw1n6E96ry7OPuj8UfLxtQ78NA2iSBbg7gIiIbdDLsb5agPhLC3RkYKv8NDbS2YGsatNRAG2oQwf9ZIOydgy1MAzBkAw8UwEEIDzSAqdPQ6za0PkeJAMH3Z0wXniUSZoHvBXU2mcjQgv56TedIKglCpIoQfgwCIjOytd8WgN0bfxoR8Fn9Gx0Aj5Zgq0lIZbsH/ibSJoFnS+C98g9ooHEELI3gliy25yONIiE6pb0NfBlyNEYyENoodkKwgl6I6s8kARgJ4ZoEfuYWHLEJa0LhSBXm7kImGeSfVdoJ1DO2G7WXsehAptupSOoyrCSF904k+6vt98X/ZcM98Hsd4JYIXhQAIg3/f9AAUYhsLQKAtkHVBnzjCKhOoYl2ym+iBtvzDzQ2DLXJ4PUmbJHAVnBQX4jkxfvHhNDqAdHXGQJgv0aSDGItgOseHIU+K9hXnIJzkoGlEKzNHagTdJ6VWEUH4iCKH4fd2AwDPaYBm4Wgng4gQ9V/CoGiuNmD04AQtNGMGzSAAQ2I2pzfogY9LRh7BrbOh4+D30sAencljFu2CUFrwY8UAWRfWwGvVOVfbx2uIILM0pwDv082dUTw8hYs8L+uIWiHGpWgClnAa1lMPJogovvvbePPs/q3Xr++kgCsfgB5oQF9WYKPJqEn6G+OE3i5AqouF59FQOmahQC8rlPLj38kg1c2f30vw+XaoIX24/pMGIgSBoZqoH3wo0sIIGlA9PWcCPrAtpPB8eBf6x1o6cHra+2+tpIFP4PgBfxZtZUJfo4qxELT948D9ucK8Mt9+ccjIQw6QJcEbrD/1g340ATuDgDkFfx6twSf1f9xvuBECYxq/7ythQQGm+5JDx6Brw4CkMGT3wgscCUoQ4sU2t6DR2ciBjTgtcpenQoZVX9NuL4Owc+dVaDursYVkVALX+shjSBKBuvCYDUZjE5BdNkxdHAUBexyHwB6NP7Iyw7sxUDViwge1t+mz8B/LAvVx/c3PeBBCToB8IUGOgqA3iV4yUg6UAOxaUFHDx6CYS8SorMOue0CCJGAf5YfRhoAI+A1CvwxqNkAY5yAIx2EQmkFfeWOXi+nEdSQQA0ZHMEItiagJArQxDXIrj8nCfQi4HZPAttrIahso9oPQ/2/JwV5JQU8zw+7I4D7/sBn4EO6rjw0FR+i3Z9fHtahzsFvJgM0X+tmVH5vaYiNDGAigewAz+gyNLThnjCURQFR1b9d3lZvnVqmj9mEPDKIUIC4KCCjBXywS4N+otp/Hk3QVthOkwEKlV9PQwXjT7s/zwF4Qf9toAAzFdjuaEB6S7D1//U5FIQu2MevO0rQQH8ZmoXE6B/IkgE60XCjVoq8gt2iCG0S8L5GdxkM1cGsfsCMArSCAnrr7dzAZxCEEpepvB8tqHJ/q+bmJGGts/AcAXFOMMeTwC7Pw0B6CtCtA2vWgonqBQJFSwH0JQK29OB2kvgj2HHXAoyeAIsCQO0kMNECAhFMqCBf8mElAkyBbX1tJQP2RJ/ha0gpAfS9l+/5n00CkrQpq0MZbOdAuxmMvHswog62jZj7BnYQe19b14kxNq2D/ehX/p68HEcF+x3yP7z/V/A/q/5DA3i5A/dzA5pdgbKp3v3/wQF4Bb70WkCTHGRAA6+KL0bFl6FJaFw0ImZwm6igSwbbwPn9RMBWf3sN2JgA/BVh/Rg0kQBgePf6HglAHLFQwqQQOwDjbdVxNZjR4iM6Qa3WxwvNxh0JFb3g/WzFQQS8b/ttKcDWoABtUMAd8j9hf0MB2uDXhzX4CHj03L9DBU3Qjz0C0l4mLSLQPicOOwZoVCB6P6dA7nDbGkVuxcNr8PU2JQO4wX5trEqmccZaHU4q8oCDFOpzAnOwqyMIMktNNNAHouDGxO37DgArQZzlmp/14W1QlqHTMaIIx7SCx0+5yza7AKJ3IXBrNAHVDcMZAU/BT/vgv/ULPOA+XiLggAREDF2g0ci6xNDRglegd7P7TWWH5oJfayliEg7bScQRBVgI4Ookg/F6rvpLWP29swREqA3CaG8/FpKqS8DTAV4TiBqIqtxfzaQRLys5I0XEFIFrPbZRQb+16Fgi2LvJv8EFUPW1gGfQv1T/F/d/HBnccP7rAwnIIyHI4ArgWeGbU4eHy6Tx/EeTZIb5bo/BsMBjmjBE08f/RB0PHYBd9eVRAGY7cHRwiBf8WeCPHY1bgBTa9xKTELzEkQX9CPtl0gJiqsAmCT7I8xbjivh3JGFI+D2nBcSJQJ8agDX+O9iBL7UfG4bzAkcaICrbtYHz1ycSmGmAjJfL3CMgT3tQpmrfB7gxSzC1DnvdhQMieG47u75+kTouKNkM8c/+vq/Q7ZYjO/hhVvRq8F/9gGfhP8aqE9EIdR6LTwJ1h0BItyDqB8iFwuNqASscRnYioxOg9ApvnYA35f8e9Ohbfe8J4rknoFkO0lmA2gmAG0YK0DkB4ieEjiLoMD8wBzom27ANZkzIoU8EMHk/uo1mzeVoEoRWKn8L/62EYAX/lsB7D/LXg74uAMr9oGivJ0CNJCGD6i9DhZdQF+gtOp4S+NODRzsDVbhdgv4BqTMNyIL9SCKwL9/FGPp5oQKxIf8A/UX6r231H7YIqLML0Ae2GtrADOvRQH5b/MPE9dt9BGLNG8jVTAQvIaK5TtvvvWQgDvyXIClUA78S9Nfg7VtIBlO7cbsEYkQDMot+ygQ7QwmOawTHnAM2XUSnJvPIYRYMmYPS+sv3J+cfP3d04JYIXsF/EwMbBKB9Q9AY+BiSwFj9mzrSXmcJhFPVHySTbgHJCPvRQ/z7G/SVUETsg0ZF+i3CRoCjhf7y1A9mOiDD7TwdwEoEXjLwAv+avLE2B7Jnb+OqDpBoAchoQJskxKnss0vu7Q2YhcDv4ySeLOg9GsCKiUIihP7yfW7zbTsBh0TQfN0iAWn9f72Z56/Ax9P7j5OAH/Qvv3/QxKfk0DgDuP+R3USg3bzBC7bO/QT9Eeh9QvDPG7glBQzJwK740lAFFgFk8P88CqDGAa223YckWYhr+c0BPdwetl2ocnsfzePAWcVnnAIp6gDVhDLyfV4nqFEDPxHsbWD3k4BDkN+pARqKMLYBPzYEvxp9xmCHQQdgWH/9EtH2TIFpu3AH/cdGydv1j0TQbRrq+D/mLcX3ZACZ15bF378CG0My6Kq/zoGOQwhASDFwFbxyNGBuSxbCEhQ/uEPe/6gAERWQObCVVfjPpQX+rexxYhYFxIkgpgX7Y/vPs+Pvxf9vwt8kAs7i32t3QCP+3SPaTwIytQXP38u0PESm+YER+o9B3vr8mETAUfDrEkPI80ck0FZ0dXh9U+HRbhey0cAc2H7A4y4egoD6y8JfkBiigLdFP8v2W00E8deT2IeAKujZ/QAVKpAtKI20gLWksHedfgPcb+0+NEHefd9vB9rayi8h7J91gBbaw20MsnWAF5xHkyDUCOoXp+yrOwwxcKj0aL6fFppaaKDv6OpHR5sgx5BAlK/+fYhuP1D196o8e7lFBaKqv5YIMnFQpd0FGVR35RJCnCDaABaXBtgbiSwtICMtalKC+1JQ6bx/PLcDPQL91QFodQNKpwOgF/9eqcBxBBqRcKAAVk+ArQOMx1RYGgB6naDhlK+uQQwJYx4meQbxtNnYQwMjt/d4f3M9ZE4UOld1LAh99fbfzOxiEkKFCkTJIUIMUeVnJ/9sDt8/e1NEJOi9oVHDGYhgnSLss9DX2IAqw1zALUncKcDr0FB5NP+0cBQNrEezDiyiADPkt9qGpwoPdL0AGPx/NOKeyf3b9WJNdfcFv6bKd2cLMJVfJ6Y3B6wB9WFUfWWEwKMfGiQL+3bz9XGQz2EHKhF41GCtZyDi/gUCsNhYoAr3UNJ58YidHKqnMb/6AB5J4N73/4L+t7mAkeeP3P+1LNSB/l0SkMEd8DcEuUlguEw6t2AU/PCE/q++Akw6QFf1u6SBrj1ZnnhG50AfkoGIdf7gJv1KcSfgzWWkQ9U33Z3tHXYASKJ9e/YhU90rvD+q9Ej69/wxYJVs506Eg/r3DkMDzEdDBRGgcZay49XihLA30P+l8N+hf1f57/0AoxbQbwYaan/rBMirE9Dk+sBzTkC8JNDEUlv5McB8PP19Y01Gayep+hC/2zvQ/2HGLAurowsNGlA1cnqGGzeH5weiYLZm7h3QQC4O2tXdhvMMk1ZS5ebpgI8eMrPvPGkwaxayk8Yc6PMOBPEdC1XZ+2UfbfOPtxLMQQAG9BcZFoF0gp/RKjxe7+oAw9T7ZPWhgedodgz0gf5KBtrtIZhQAZpAV1Bi36w6t98qVfH7hqGI318lLCjLCUFlxRHwqYEH9a2qb4XjWvDT7kBwfbZA5P0+PNuRuW1yf4yNQH3zzwv6b70QOJ0G9OT/dhoYRUGT15uQH/71MjQLtQlxfDuiCXrtM+SkA+icQdH6sU/xz7Ze7FlubV4TpoTQ2osdpaEjtqADmEU7OkBEFoLeC3IWFFeswJXKXzkboNL+wzcFHU8hTGKIboO7CLi1/P+5F+gydQhuvRbwEgxvtACmANikhLTbj0gCYk8KdlYgmj+4Ymaod7TwahwadICuX0Cm2fE5iNHPK0x/CDV66Kyg1MnqjNFBnhBoLQCgUULfaVe5nq/6EQWY67bXCszUb+7232fVPz51iGB12owK9peyP1T4raMFF/OEYJP792mgXYfZ04GHMAhBkCSmSj+dKqRPgVFGHbpLEGMiGFeQWfSgrY52VxaeDUPSNJI0P7NoisG729HHl78z6hxfs9rV3m4JjgM/lsui2qmThjCfDFSb+I9vwUqG5wwL55U7C+6ot8B+7N2o6r3q37T9trfpjgmTvv7PSQATLLeRAOZhIJHBQfDQQJPBdUwEbVW3+L08EcEE/9G4ANrCeWcnPKRHDupbNynMx5AA9IRYLmrc/YLSiD5EaEBS/s/TgnU9ILcH19n+CpHwegLejx7Mn/d25fdN+e9U/1vgb7bqf08MOtf8EXxaoh+GY8L6gDfhvs4i6HQ7seYI2sv1GchdMsBIG3xlvxcCRzdgCPTn+6q/TW00VE8Q9FaFv+R2VlOM1vm/hhjhDCdgNflVKME5B47I9xT8z0YgPAJ8myb/LqHy36j/Mwqw9AALxuO1JVjiuQAYLcFzIhiEPe05fk8tRjGw7yWQbsfuLAT2VqOId1osnr0F49VM8INACPHDoBz4B5mqqSnUgyh3ArjXxfQH5BbgUS8gP7aU+w0zHD9GGD0CGHf+P1p/DeivlhU4BbxR9a2kYFR58YaDZCUR2P0DMmgED2eg77puegy6PgDphEB0CwlG/i9d+/Hs34pBEQrBn0W51mqGnJAk3ACCHeiqkQ1XFQA5AlKH7Lk8yJKWY3/nym14h2C3JvxeMwD9ZVMz0BPMi1n1RbKl1cYhIVblF3G0ATsRiCMUvoK9//OgcwYMoe+ZKOLlC6/Xk50br9NFz9fanqA8UIYSpCwlBO4kHc4WLLBfBHVaKwKgLQjmP4Un61Vq+3s7Bsyi0WztmLjJwJwFeE0I2vD/1Q6MVwefxfUf32skCPbCnxQqf+QMPEUDHZ7vGeyj020JgkPXXwsldA7SYR1RE3h94NvNtugswcgxXEkIcBPCGZ1rmrgDC0A4K88nm2fn/eTnpQtWyZfybRoK8Dro4zYDIMGsf7saTBzvX0SMbkAD6o9CYbsfMK38cJKD9l2FJt9/VGs0h5Gib33pxMKWNsigFUh3G2un+/N1WUglI/EEx8fq27vUNnwsiOoKecL7kQS8VnWAGCFUgn6dBtQhv40CmIYggwK0uwDHRGAuBXVdfwzHUjZzATLMAoyJ4FmBhzaWBlrHld9CCWpPHRqofBqMReMGTJ78q9rDes1Tv7/0m0v0AFHXNR6P6g30SHivin7V1BOhh3iWPwvps/yE836L2XiwnUT8x2iHgfqhnwn667QHEE8oLQjEvtEW7GYBZDrDVkwNIO4G5GiBDf9fGoFM6n+vbEtzXwP6u9AduaWnGYSLAlVdl/AU+ikrSeEIKgwdaZ4AACAASURBVKj4/wtgHcHtdO2nWKcBkPfxcvnNQvsj2Me9f02r76T8q0IBn9OLKfz1HX8yVXQYGoAB/2UeBQ5/5kCL6+H/OGGoRnLSwdd3oH8r7KkGTbgIxEwVWvnF8KOpHnyzfF9Jod5Px+IF1h8owyitDw/XEgRb5bPqbt1uvn7qBIQ16vtS/u+DP3cR7CH0WWJgd5mTJKYgNzoGjQrfvu99NDBC+bnyW1x/qhTatv2OaMKgJWPvv5kwnMgxHYGFRtJW8VMl3uP+MgoqSZyWFKr7+KIDw1d6+IiOgZI4+d5iYL3imzbgyO+tph9t2oSBxOM3ugHtPoFZ1LM0hF4kXNEBssvVgPdjdXZWK7uKvyS3q1Xb1WQwtVDqSUggq+Vw3t56JA2cz7PXOwGNW1ecwxPhfe3QEUsDsFaAz8jg0nf+iZMAHNg/XSazDuC18Iq1HBRrOsAQ8NLB+16g614jmuSgs3bROxE55D+WDDQNA4ivdMJ9M1b309UqknaDU8ObV9/PwmMPATvTMAxpABLBzugUtV9bLdhNDQA+7B9tQJ06/7QNDHGSwtgZOCIA47InIoDdROQGtt0U1HI3GaoUnCnC/rzBMQJteN17+VaAzYNA7e+PFqHQUyXPUYB7iQYa5ZFjq1Zqpx8Uqu/XT7+6BWC1Xaj0GlBIwMoHu7UzcI/6/Acb8KIq+hzmGWmAYnADrIpvKP7TZeLaf0LAeQkGgebbq9FToI44p654F47tekKkI0L5PQNZPsDwPBpy/ni+wKMN76Vav4+2cFZFf8+JwAraMt0DFB7beA/u4Zz/a+RXx0M/ct4/jwaNAS8G17eSwmta0Fhx0VRxJkHMivso+onMXr+YwdWKbgioy1jp4x4AzIKg5lEA7wvHEYCRmdx11TAuT6lDLVl4KvXkAET9P4RT8H2u+lg9EPQIpw+/NpJ7RwE8HaDv/Mu4f3OdNkq/EfAiEiOANjEALvcWL9gfFV4NZbgbQc6qPky4Pm35QZxtH1f4j+P/jXuaYPcWwIEH/fmEPBoAO4m4LGxV3txOQqDU+dXgey+UwSzuqP++uImO/u/6ogCb7wTc1n61sL+vZi87rxnrNas+giTg6QLzaUCjIp6JfhwtGI7AjBBB9JjDY4ePYVR6ZPgN4owVv6Q2N5hhVHwNeYrM+w6dN6K1sMHZm/Ce7bHe3dzKr1xw1w4JrSQMZtgnoQHlr18fzunAszD4qurNUg/TDqzx/lfCaO6t4tACMUQ6P6htWjDPC1hCoZ8kpODzJ70MUR9AODcgwyqyPhmE+wfHYB/hvSqt6qeXUShhXH+d9SR8DzrDaZZdpSp/HxqLMQuATgDU/qDPRgOIeT8cvz/h/XC6BtE7ACLOWPE0KIS4UUjmZaJ2grBphiWgT41BUVWZfP3AnEIT6OrfoF122l2rMycBoU5i/OXoUZ4/aglsXwLzHNU++FVF3qikOj5HXm2PBitT1WuvJRAB+6O//W0/PY8vQH5IrAsMs/WuVmAdHBrQgrbOxJShXwRSsu08h8JMBpo0+aDTALwV4tbswgzHrftG/dJKIAQb5h9KCssWIMeto+GYqG12/HWGjx8kzqNJaa0noMWOr2KwW01AMwJoNvhMQda2/RKQP/3ecABM3g9uD6BY68Ntz9+nDOMb5iV+hIE+dP/Zs/wwJhJ9mgBnohBuStABUXjugF3hkXF9ZZJAjefKdHZCc389LoStKvIl7QIEb1d9RyciQgFDI9Cjyccc/23Aam7/PZJBhgDgin5CtQvbCzX8ip9YgIFtOAt+w0owp/hOiCWgEGbVHuYjRigPGR/YOnEoqPDoV5z5YqB3mRq2ox5ICmSSgAP1Ne+XV2NE+/vuFbCTRADxtS70VRBCjgBk2OyDUQiUgfl77b7DwaHm2rAZ7osRSOOUoHgKfNBSLI767+oDYrfwZvqChSpGfj3pFwZFsCJg2jeIQQBUiyI4WgD68ww4qO8khuWkkIuDrxWv2nv+UTBpJYiPd0KemTA8qqFiuUF1jWS3BoG6pADJq751JqBI0wvAVPyMQvjcX1zbELltKK+zBiXRFiRxG+b7q3M9xuLdzR8g0gCGNzSM5gNYfqGO9CBT8OHct6oB3KsSDBisUnwsFuISQaRHxDSv0vptt2oeLHMERfRn/FG/Cx01EpgIQG8LP+/i37PKw53xn6sYCM4/JwSRrCnIeB1ZkLsawDhaPKv/njU3wnZ/dBdGE8+YTHSG8+ofGgIjsC19YnwdM/KAnTSsqj6ig7uGgIPw3nYFzhhIIvriAxFP9CQd4HSlnzgxONIdrE7A8ZDPx9fjib8ifgegNIliRgdx95+E1T7+3nQVNNhEzDgGA3T2rEDLduwtPpuuouPcs8swwXFjdTaMKt+jA5gUAQPcf95KJQxYU0cYxEDvsBSmYuukp7AwnqniC9Afa5z8vboI68ImT0t26CvwBzSggkj447r9IojvCn7U92J/Hw0QSdwZKNNjxPCfSxRqnATkdwpOwh88oc4J8KTSm/wdbZjrc+4iFP8YO0/5JJDCfaijK5xVXevqfg6zGRrQf83chvX4aRfAE//6vv5+6490U4ADdO7QgM/5bcHP/n4OtCQhBEFeDWSvos8DPq8/IwzLzjpa8/U6MMSkBklDm8e0mn3QIY7XG1Om8wzN48y7HwhOK3P0/ZwUQHHv4psbdoVeb9VlAjChBCdtDDpOKTh9ZfcagOYq31RFjN4/gwBYzp8lAwYNwBELhZoxECeZxMlAzWGdCRV0fQWGHo8+8Kx+AAxnCIzowAxy9KvNepWfsfp4RR9kUrD88CPVTuXRybhqqTHcnxEGndsgub1Gdug8yz9fHt3Hpl57x/mfCOC29FOSQ7/noAZR5W3Ob24UMpuPYAYiQrQgk1gnFoUIKr4vKFpV15pHUJO3Y5rfH3UFHU4bGkU+NKJ9f2hJyOMxDBDpjAgwiYqvk5TqNl9EH2Arb6fA3yaA4cBtPWewhkEcIQJBlGzYp6zRmr1v+e3Fv27xpzvyI44NGDkCIi7CGNV9Dw0M8NtHC2vUwHINumCGNG8erxOwtQINsW88Tlwdoc+F85nI559ngEDpt2F/Uu3hiXYrkN/pBFS26hYDAkFgErMK67y9mGBA3L5ore5izf8b3n805MOq/t7XU4WHv1DUF/5gugCSOAIW/59uMwl6CHWAib8bvfxWl9/rBGEMTTwDfG+ezEYG4yk6FvRPuPwE+wvc39IRjENWM+/cm5b0W4Pf4WuKUnw/vD6eDbB1ETs5vl77Dhnm/51g6wPWwQAqxnivgQaeS3gy/u/1H4hpTPrIgHAN0mSgXUX13YP5PMIuQAfBr/f70cdeE+QoCX3i8nFMLcAjInBoAIYqt1LhC1WdtvmSab28AYffaeivCB+ohdYQgfUa/WS4ToMsNLHLc9nnvPZLwn1/EefPVf+U/xvnCVSEQEkEQEnEQJO7S7RvYDxNeNYKrG7DKMhtsQ8cMmhgPKKKj+F7CiHYFR5KIIPxOmg5IVAtu3ACQSPh7CzUQOgAej5CWEkIe3vgxz0ROGO//qYfz/dnLT+ZxDr4QW0eNCJBorCFOVC312Ec2TiY5Bk0cAaQmiA1VH1MOwDHQ0kHdEDDf+2UTWhS4Z8diQMicLx8MLBfverLcP/jQzF0P8EJj5+NGK9RCz755S6F/f1+X/gxeP+Wsedv+vF8/54aSPJYFjIQd624MDz/UDLQnr8HU3ztKHRf8Qeno1vyAQJBaLcMtTV3cvgP56COCqd/QP9xLgBkH4BxO13n4hNUDtACC6G1S3zqooZ6Ba4lp/zcAFb7iERKQwQcF39IFJjdXECGADw0IE4gg674pYAnk4HoHPx54tD5daO5vxrugSkMjgiiqc7TVKAT6AT8R4ckbHEQCYR/IZBxJgA+XZjsR7vaoRpIxWqeqfXuGC2CxwudicwePEB1kNkaZCuwyF0DuKv/4sz9mzP/Qxdg3BDkBTMC8Q+loD6UGBzx0Kz6eAX/KArOQTlPHFoI4vVtf4rNuLrca9edRn4xBP7k8w+9AgZCgBfEUZWfEs8iFNZ3UO7TqmkjCO/rWdgco/yIqHcQWaC2EGTzgz5y/iXQAvyx3riyxxV/JeBriaGB9OrTA5g9/eokM+37GszqfA/UZk9iW5UnCtBqBl3XoNN6Ag/+zy6A5evPAp+TIFDn15gQw9rjrOzFX0s2JBVAxa/nP1a6AsNWYGjPNGPLTQgBsNUFvOA3Ht9o/rGDN0tWOCcxJGp+f7++kkP7PxcGv1+GjkaLt/fawpwwerQxBJNW4b+PJsYEgiAYYdEAGIlDNaAbRkIgK3ut0jKByp+8yz23X6GttmBmjwDvChgiYLP5V/zhH6/110sGcKo5CkggCngxnIPoPja0j2B+1BRkiYJiviaLJqghDI63G2nAgAxMCuDdnoD0wIQm+urMB3VuAwbBrFGgGgnhAFqg9+ujKsLxB3qGCQNEEtPinIQlAj4WgIw7/iXc9V/x/yUWFs2KH504bAh4aYWf4TrTLGTy9YbftyLeVOWNfYNyt/ji29mQnqMAltU3ioTtbX343yv/1u0YPUBz6zB702tQucnX0gWaFh6DgPdmhXaapGotw0SFz1qDiTMdd8h45HfcqCPRUhA3+NmKz1l9teCPaMd4urGaewRitNBDdahR5c3AfQmDCFT9vmtQEwqAYXX4XI2n23Z9B/Yb1FL+LWox6wHGbZSo6FR1LzyG+3hriSZvWT6jfXhl2cmQZJDrAbuYAqAHo1GA/EOgD8eGcU7A8eDvH4fQBuAhBL/Zp/vamPTrRENDGLTV/7E1WEPLDlP/PwzU4YhusIMUgfIPAr6Dhv5R4y2r8ldFwiFoYHnmr8TAHbhRQSZOctH598ZYhqt6wP7q/ouqe77RJxvzFYaji/z4vna4v5cUMDXqDAJ5ytktqtBDckyjvJg04hl16LB0xFfyMfD77PZjErGQRRjYIfSvoAXntks0ok8MsUC4KARWnYPlJBeIgLeFrUgDOHYCag0/XNAbWgRwQuLAsaQwIhC1g7+jCNKuT38JfnYSyTi+QQEwwHeT4/dWHYxJPxfOj5oAnRQqgU3YgGZSOaDyK3n/qkDYBKptzR3oD6B4fyRKjp2AzSl80YR/3P+/1vBjX18Jbu+YsrMRgbqPP8zrDLTAaupphfeZtyPs9BPztpLSBZjowF3woYRwBwOWaqbev15b7X4RWsiqYiY6ZkFEIoUwUA2OrkeEQE8HYNyD/rl3m88jCGgO/nPW3xy8x4Q/HBcM1dYg5q8N+B/SBSYhtD0EY1PRGLDoKIBHF3yLz4H/gSYQJRETgqeB2d4vC8L2NVnQn4PoVJJAcP0inahAfdXVI8CFszjRagCTtRdV7Sr895NBpRKXIT64RMFw/iw5eChhEvmmyUIH+k+Qu3cLzOAN6ILlFvgWnx3YWFDz0f38ze9GlfP6UQ3ojEY0gtqRIEbA5/WgQFhsEuIeL75uTzvqHktAWfj/OD6sQXssROcGiRgFn0QVkld7OznMDT7CJKzhMIqxW9B+LCOQdH4uyxIcE49VTSeLj0wKjzcp2oDXQA8YoDEGBLMW0BJw+eAxXejPV/IXd59/tp5rVyYXDw5BlRetSpQAcvgfOwVM8ObzBq/AQ2wX4lwkQV3vNhYFfn2LFgaoDU1ogqsfqGkJYmrj9Tr22KQwBLzbLuzDeA9yzyJjVRfwegWq0H+FThDPA6ZhZwX2M2Kh4waovCzAWJTzD/qY00c+6PM8coz08VNqglzx54LfHuTJK7z2rwX35ABLg1DzsZ7Qv7l/f2yXDlbf4C/irg0MJ0aCuD0wP74MrxfdFlX7tq+vtRdCpvt599EG9Yz3V+P+Oj/n4zLruZHcJ7oMt/MNp9eD6HEeFb6/TMfbWo85Pb79HJo8t3371/PuIAZqMvjPC34nVV6ZB4hEuA7AzA5cfU0y2n6ux89D/35/n2/vWY5Bf0qwf3tPLISO1Tap9qzFB6eap/beqI94NCCbGwgqOItY3CGl446CaQ8i2Q9g0AvmgJOnBoAA0gu17tsKtKS7D4udgCYERy2QIceCX/P7mBW+g/7D9S6Mn50CS0eAoQPDcBjopIA5+EcxEjLweRjXq0UbLIjcBxsGx2IZvlf0ATjz/6qypAmY7bhrk4ahsIis6ccXKHdueAfUgk+RWPCLh42c6zEeKyJpRTdRAOqBbl/Wq/uT+q+Fx3FoTIuCzc6+hN8j4veGjuAnhSE5gKnco3A3XwYlq2sq+lmP4yEOpqEoG0M+mGDYuYT0pKCFHgLHKt3T7T9p8GcWH+n1UwGa8X6kQt2x4CeqPexegT6o/Z4Cr313PHdgrsS2ZReLfpKIf+IMFnmVmwxQ9AhithYT73+p2s+JIVfrjwiHnpAZrSsr9CMstQXP1+1+510N/q8E/YoekMN9OMFvi5LvkRDsy9rgFCOoPdpgaQIWBZjf5KCSQszZJ1ivTvLokpen6tsJAVND0NFqb6GUGg2Im4Dyx9Pn7/0dm4pADAslJzTv+dKNrAPQ0wyySm7bj1RQgbAXsRa4R+mBJzpaQmHLmy0BLoL+Nh2ZRca8uUc6P37k97n451fvTieAE8BdZ2ItqFEK6oOJIYPsiU4woo140Oh+H/UC++gatHYcOFT+2y3AYvD1rM/fpxdUcsAi70c0OxAEP45X/hymE9XeoC0zfYhbcqfbhs09HpwnKMDR6g0mmYyKth/UcLl9ITGQ8N1S6s+gA1HvQCc2pluPvN2Br8SyZyfyxPP/VhCi1L1HWX2CQCuAE8TIq/sBYdANZmTIwqq0sb0HIzhhugBeUpBZLFyA8y+EErsBUYDZHYN9QAAooQwOws+uQlhdESSSqk5Qsh8LSYI6LDS1AbmOvLlRBqQIeITvM36+TP63VfE5hFClCTr9zEyVFwS3STQBy66DMHB+PJWIrfgGnYBx2dTboPa2X49GaBVlePA7CFx4iaGi4ns0aLVjMGvtPTDtmO4XEE8E5Kb/8qYai+NHl60LgAICcUCoJPVeiYG6Pxw/X9VFNVbFn9FNPzXoIRDTyzcpREYB5Fm1EQQn3KRi9wKApR8Tz48SwxnV3qM0q7ZhpdKvr0zfY+gO4oQf+EGPFYW/Xf5hwWsUgxiBbShGoGIx+D2eH1h2EeR3UQMH4zMaUKr4033nzkSkfQADelFbLOQCalxdxvN8mInhPas9bxtGJw29Fx3Y8429MAS0fL33Oeo7qFZeiToCC3B/VSNYuU0fgDnkhxGgMFdxiYEY7MYel+OHPH30IMeVFK1C79l+QdXVpFqHlMAXEf3EYDyfkkGdNvJ8f3RAXU0jpgM7jMNA5yCrtfzOicKG/M9bgEkEjqqPPDEcDfqVwGZv6zcO9avDfOhf4OmLFd9OLBHHdxp51HvOBlnAoQksYjASA1xnIhPsapTCPjbsGB2YevpPpgM73EYeSYIftgPgte6CWesVBB9QEgfnWYMgoeC8ql69bWoRIqYHvSIv/u26bj/jdqZ9KSGk74JRo6QS9PuTiSHm6Z62kLUGH0UO4rwWrhtRETkR4iKRdI8giJ2D2nUCMjsA0TXiVDb98NAf/rCMlajA9wesWHZrAe1dlwRyVI2jx4KkyUHSx7YDe6YD4tOC6XW01puEdAJwaEJzf1uATHi6ZlSCpBQscsh6C1xRcWEG4bCFeKcAVhVlDu54JQIkTT21hptIT/Afk0kMcS9BKfjBJozcDXCrtgbWXxbMAw3INQIxtQJPAGwXmYaBbYh4SCsuKwLOAQ5awKskCMmRg8P3xwlBfbosQaDqyZqBkyQe1CLQACoTgN4qbyHsPwkTiF2pYaj6MAXBmUosQHnUEYCsBL3MW39SNKMJ5PfoBsT33DVJCEbFnBCMOkHfvj6Xq8uw+dgRIhGgAiUqf5QgKDFyhe8nnYrlqn9sG1GoAfirubygX4H+8IM1CmQrMFAJ5ExzKIp54nPoVU2Auh6eBShDlTV4u5c4HE/fVvjFrsII0Ik6QX+Iq68jB19ziLoKC27FYe0gC+j1RSS+BgB7AvAM3m8HLdy5fV60C8RMVuhD1ieQB32MCCq0QPJuvuw5IHF/geMKwOPdpmsxBwVEfGEOgeincJqNmuSFIPhPq/xM81CWIIi+gCFBqDX3QPYd2OcCRo6GZBoA3AM+00aesAOQ7/2Pe/vBCXoguD4OBD1WfPwClzcui12AuH+gC0gEwW72KfjBCQRBr05D0IQc7N8PzOCMehPWK384MPVDJQim7yDdoiRTItzzFV/ZOX9sYFetP0fsQzb6O7wOoFjxk89YoQXv+BmSN+yYHYO+BsDRAXHhuJXsEFbdIEGZQWUkNVNzGA9NZUVBIQL7jASR0AclE4Pb7JN3BO72mG92+o8UG3nybj+mASh0FsLKn9GPxDrEcS2Au35BzHO1BksriIJdpqWjKR1wlpR4fN977rZqI+XbYjYDgVDpcYQalOYKMiuQbB3G6Pu/HlMbi9a0EMkksXtjvvXTfgMKAEZRN/i/O7yD8Da2S2Bdh3ICWfp8yuMkYl5a4df4vVWt4UF0yyqEnaT6swYyWB8/j111Y1ERS9oB0SLMtBGDEBD1PEHwtdjUEAHnqmoHU4wCDAoAS+lHwtu9eQLUAgmxVvAuMB9cELMV3m8EUtcBYYI9nkNIEEJYrQeUHfnzzRyC39j8CgSkir/E0P2odnAmAqDnDIhqrtV9BDNS2POjv/0pwKr6z1h/PMz3uf9ykFYq9TtoAXSwpz0HljdvBCVAPY6t7osv6gFhMpkX13rcfXQMIpuTsfTibkfOPRAC2meLRipI4mDPwMD5x+v3+Ey+qEfACwoUEkKQSMZxYJDz9R68PyP43yvo2aYf881rNQbZgRU/jp80QnW/hdXqJxMvCFxXQSNHpE8QiF4XI+wFfQcw7VL2Md7RRajsKgh2D+6SLAKPF356+/7yXYBTUgFy/38StUjFHweD+iiHh8/LV/i/TSvGk4L5x7F6AsIKbgb4C0YjgdGRIToGUx7cgS3JKP8pRcgak95BJGQbjaJdBYQ1qHYnYHL8F45QgHx2gLMQ2cDxBD/4SeR0LSDi5XzPQNjM4ySE/HGG6g+ugltLNSARn281BPtNO72eJLjdX4ITSEgpQvJYFEUg24f1qAYQNQdxx6Q/RcB85j9f+03zf2QV33IDPHegNgPABTfqFR8cZK9TA7/ll0EQbUUHW8Gr1d+MSadia+LRHwhunv87yWoJ3h/pRDwJAbDNQQFd2P2mH4kP/wDT/ZeN3CK3+ZjvgVpw4r20AMafb58j4N1UMknuj6iCx883PU9g2VHVH5JX2eEcPghSgRBCKPzK0Q3fknwPN0Hk0CyC0zBkz//7duEetgFjVtypASDI4CsknYJgYDhqsBxxy29+eyxrAZX75EEf8f+CkOcijMDDHx4ASYGGu8WHgPwpHJc0qOG8FgFTuVk0cRZVePFwHEIUEu8xSHoL5qWg4I7/HgOKXe2dcnu2SSdCGIDTA+AcxY1zYL6Q6AAFu+/1GvjKPSeEoJV3NiM4Dz9C6oWkEav+NWjPWXNOIkKgNTi2I8LeBgaZHJxqrC4oNXoB9pzzMws/OW3ghSyQJgjbygOVEDhoj4nHLld8HPD6UUMFVLIgKrTL7cFoBRLQgEdXIseZ2/HhFPKbk4d5tYWwwR0nIFQSD2P5gQhs6meVfB+Bkyz2fOIvX/zxqsSODuAGIOLtPNnmIPCrv6Kqvgz3q4tCwNl9lWYfnsdHj2HTgQw5IBHwULmfSu1jEV3gDFSxTBmqSEVqiYK2IkWcRiAkwV/cyW9YhqHXDw9dkNQAcO6HFNJT7oChfrPUYc3KY17zAd+evAwF2w5SCKLV4EuCEKsKfjBVWHu9Q9Arh4CoBqEMWYBsNX7YgKP/69uC3M7/mOOz232QT+ox4iCyJGEFP4oBHd+GVvXBwX35nqp7qeIbV6L6tdZub3ueJ+gBIKgC6S5gOQFxDoGr+Bv2nzqbknd7ph/EmXzO0o+kZdc/wqvQkAOUffVMzKtYgx5Vob1/+HAfCdzHSiXHenX35/2JTr3KZ9Ruj2lYiMhLIFoNyMq9hFroeYMTE0bSLbhb4l3YlFPa6hMd2jk8dmrDgdQCnC4/+ANFlYTB6ATlx2GDGXP1rvL+SnWHw+cJes5/rRWt4H2pw9GklD4uSMpwasIQiaYR92gIyFX5S8dtRZt/nCAH48VXW3hRE/HKOsGquj8EM85Q9cfeAV4XwNGAlmIFIwPYrfLKuxV476RRetzcdeAsRSZhiHizCKEIOHn3EMOWy5X4uIJnXX6sFiBFLaBm/THOQAkVJK9j6TKwiSDTBWpwHkSPQJX7U959uAkoaTUuug6oQCBz1Zlxm0OJSIoIw04M+7zCGuYiznCfHww9AN6Ir+HXA7lfn2oBSJ2FOOh8SzINfmcAyITq8JX/sOMPx6A9LeYtVfwgCBZhdu25OB9/XmWWNPUEPD5dUuJ68wd1AqD2+w1PI9KxE9BW5t3z/igdYGWiL7L+wPv9jgVY8f0ZcbCKCuLAHN+c5wa69Zpr0J9t2KnpAGzyiAIPiFalJ8/xXrrA6Y+/8NoDnWCPNwFJzf5DpVkHte8hx76P+HU1+HEytEeSEIzAsu5r6wPJGu6oLz8VrKofXLce+ywIHhNa/Dmw8LrptWXZ4NKZm4pr/QQ7Qk8ehMrPtAF7PQCD309QgRgRZMKgAbFREAfBBXNalbHA9cEHMo4IgIUuPjjBWEUFEQpYTkhVO43eRiynJw9Jjj8TOUIlJExK+0wA4gWgQvcFBHAc7P4/u78/Ff4CC5ATB3P3oUwFClYgcALcxzp/B9Ez4DUV8RjBbsCBrMH4dLNwIDaCGhA6o3pXksdBvYBsktrXDgNJKAFy1Z+ZGIy5NXgXoBT8a3ZgVSPIUAMV6DjLxhsV8wX4n4ibbONObHNyCr8Z4FinNFjg8ziiF5zSV8A99u7Zdf5OisvVaAAAG3VJREFU/kIPAJLWX3hUIFD6o7MD4WkHIMXBk4IftSrPNBJVk0OoC7ice8HGS8XBKDoz/YFBLaQi392lGpCMJfhD9xVkx5Xbj73P9V4m1j0v73x9FjDDPlYvATkgFAVWcdNvJBamliOjAwRV0EpeRymAe717kMYRyy/j5FwFBX0fP7Dyx8gq8wn2ZXi8GfGYR+lFcGJSxa3Y84WgzBHetlU4cvKY44Ps4iP9fsgsPGEhQTAcHqwwGCj61SoPexKwasXFqtxq8qhD9SixoBBYcJEDNzmIoi3J7QkoJActVHocTVpPBCDhElAvMDK1PT/Sq3DwB/ygmyB9GNhYDH4so4Foy48kkPtZfZEv1PQTxYpyX0EI3Bu+/5krcN8fgwVdwWu2JNVNWAk+PcOOPMNdGFyAZ5Aj6gicgzNfwuHZg0HrLxBWfjSRl88fVCo/apX/IBrIvf65ZxtEoK9Bec4KZIPLe76osQns46NwW0pUPCPAyMc4A/KXOwZzFLGbAqD5xhhbgBcWfoJBAlarcCSQgdQJ+Movnih4gjZQTw51rz588y/ZgxVUEAQ8soCfX8OR26JwujCLGFAMsOjnwGrlPuQw9D/PPv8BYVR7pG/eeFtQpsLzR2KFI8SwKj9KlX++HeLOPuSBKrKeHBi7L4b+Kx184+ptAp4Trcscv69oARVYzWgaK01H1X0K3zNSmARKtxXYHvwJuT+8gLGGWgpHcWOmBeljFB2Ckg6wiAYOqfxEK3GMCAj6kIiTWdCBCXhkjUKMgJcLk271N9uLSbtvvK0S69OXAvoA5z94VsFubbmZvx4QAnXgBnJxENyQjy38wef81uPhxMpPJIQzr5ckuUTKe0wZyN57iFTWga8GvCwlh5UqvYgmaNV9XSxEVWs40kkosFwA70RgNOu8mLZfR6wDiwRa35y7j08NksqPQhcfkRBK/J8R75Iz+9C8gJpqzwiIeZII3QnYOkJWbVEI5jNuA+o2BwK82ifwnpSgHwaC+GNAdmW2VXfC+vPu6wR6lBj84C9WfvivZyUhZMJlJhjSukDlFJ3g4AvGJfC1iEpQJ/CaEd7G9wds7p71+odruKrHip/C7RdsxeVjzIxhoNkFGOW/+sk/YVAGtltfzZAIfzix8gcHhZCXpcGN2u69qWqD9OlRFAy7x2fQBhHUiETB+DocqvArYt98f+AEAXApsEmEcNLC0t2uPHCqPQIXwHYDfI4/9+8LMpchqr5HK39MJSrBXwnutNqjovjHFdq+fcHLp7YLR4mGgduW5hFpAXUoL4cTTuW5HJSkB5PC0S7A+8c+837DyoM1J9iv/po/o3BunlDqPjOSO/YbLFd+FGy9sxKFeT8b+nLNPrkAyD53FtT27yUS32yqUaEGTMBiASGcZ0FmK8nWxbvjC1q6WQC4VdWdAcBY8eFoAzIrC0b7Wt8wlPcIdE1FhUWeKU1Igv8Q/0dl4k/NnYSxdlDon8diUDeuQB4c8XVzcahRgyyZmNC+LAgeCfSVALde8/t1DCYawNoePGT83wlOpFUdOZKwxn89OsMEf0X8CxJCBN/dwKbFwkSMgx0ACJJDJD4iC1JEYh6XcEqVHpx4+J4I4UiAl26r5x64sttvSlAn3LBuQCz6edU8C+J5epBrC4YP52EFDgHrCw1B0eU9bOaTgh3wmYvQV3Oqqcf53XnVNXUBELX1xtSgFrirlII5d3HFulxBCNEfZx0h7K2f34XwdHpuYQcguN189Ow/nPXclaUcqMH5leCXjKOjbv3F0a7i2ZaRHmBe5zwnhA9S736ZC8AH8LHkg/T5znYgmES1dtuzGo92qwHIquiWX+4KgVLd8utv9Ml1BQNhEJW/FOgweiTguCUoQHkEwYhjfQIgm8eAzPKzHqAG5xGiiPyxeGRRaYetUpDVpHVC1T9bHGyaknb/TQTnuG7rDYwYCUT7/cMjtILzA+Go/FPw581F/mWeTkDuBsBCAK8ki+A29nMzPn4Rzjv6QV7xWW4fzQFUxb9jQQ1qc28kMi4mDl1NBr4usIsz5ltZqNm7AeJXfuTHd7nioLEyPBISU+8/tP1AC4Il/n+YGmjg2NiBRdl6yCw//zG5ph7bqaBuz8B4VMU/TqSsNPbwCeZA1cdxyG9SgKzRZPL+GXFOiH1/SFZ9wX8M3zUgvH8a4rMBjZj/h1W9MrwTiN6MlsCKiI4gycBzgV/xUaQGjGDHwHiYi0VIzeEAasCpNuL76AC7BIEl7i4AIxnAfoMxk35eJbZ68wWEUChs8IPz/EEE9BkUoNA4RCWSLJkY1h0Y/dG9bVCtUVPe7QRhtStXG4nOECDfUxc4Uw/Ik8JkA9o9+a83IrfHH11EdFUWc4phNgVFWkPsIHBnCvCCYBSgqEN9qtoXuwHhByYoJJA7BxIkkRwpDGgAHo+vQ3ZGOwCFJCJKUAx4MBpFZWvReeLgtBBkDDQu2OJxXa7SE/P4ZiUPHABjY1DsFIhPAaygWewiXK72hHjow/k8gCL6gKES8qcDZ7A+EhYlWCPGCX1wXIwzkQEKt8cP6iqkC0FEhFj/ZYtvXCtwuBLcDT5wXN+9H6ZEIkTwV/x/s78fXFX3siWHEKrC3tw7EFZ31Ll7ttknQyEMGgAqCaVe1bGk8r8nFWCQQR0h7CY0dsU/mIeIuA1AGCo02Q0YVXxub36sG1Qgfo0CBBUXxap+ECFEycQVyViBEBFPt14TK9rZHB9EwMG7DPXOv0OVHkdtx7OSCXfb3av4CFZGTwQBwT7/hKPHE4PzpJ4L4+FM9r1n8B+B+9R9I4Fu9brYUZgCunZWNxdQgIs8mASBQ4F8hJpEiaf4GPihk8FdAxin/kybjZjTj+mAQy6ihZ9whDvHAWB6BKrBXQr+5SBfqPaINwiz12UIwoTmbPACZY/fshBBBKNlW8ZCHwH/cVKSOZMm4Mxk4OwE9JeB+EFkn1IzcPQoiSB4vGgNeJSoik1A7m0TCmE/HrggB+/1M12C1Z18ACGoIeH1pH2IhAqFWgBq+kDFEWAvA3X8tpW0cnSD5WAOriOHhnYraF1eLTkS8P/QsHUBdtMPnOrMaANJE9AZiaKWII5Ue/8PTHn/UcCSTgIF2xN4zdmAQYIAKeBFl6FiO0aKfq5jcImHfPwTxcEdRmD3LcFoAva1Hdjm9UgGggI9YOoPkOBYLsT8HlG3nucMDGkOOJ8CkNOELdSO7D5qqAeJYBb2GpABgRi2gxLITgrOQ9C937HgB+0i7MeRx3gfPWCXLtgbLJAu/gCFBPzRX8eADJqCvA3FViC/BlOQC4LZyrBq8BdQAOUKoKjqR7v7EFfVFMojPgEoSlJesNIePyLHwW9NRgq7E6HvUN8A0yj0wyWDHRZ3J2A1jHdMyu3hCGwSDwdRir7h9VP7AKLgPoMCgKziOFLtrUm8aIFHlgxYfz8WBYUU55iAXauo+evJaIK/NTgRJM9sUcZRzcCnMdNKMJc7usnAyrpxHYkTRHK+n1HxS01LheAHqRWwKIDqLvQC0+PupHZgBawfVGsiniTVHwZHRqbUI/D4Cd+ftgyLAR1ehkIiqaKFw7MJEwUIuK5zsu4svoFYCFKgBJZACBuppOId2RDkPZas8H9kULcA9a0KTCQDGtpnzT+RMJiOGseHl4BQ1C29AWUXIIf/OIwwqoNEK3SCuA7FRiBrE9B4/PcrGJ1OQNj83F4Xbol/TgVHfMiIZLAdcaVkgh8sLrd+liNQH/FqsNTfj15m1J0X+ffZuq/gTY7QnvIfJz6UzBJLs83ItQpt3RfZz5iuGfNPajpngUm0R8DoA5jDlzsOTAwZjzsC3Jjxg7H914PjlcskGdghgx9HG4OOQH34uwQyzz61/0qiYNQjXxECuWYbGM/DrjtPH/Mw/K+gBLLSA+cEfPr4MroArzcDuybbr8Zc72i2UnzeHnTgzD4Ug78SzIvCoARVOQxaFFR3TzWnkkHUVFShEuqKxZnKz4p4YYcf8ZhYhuu8wFgSHcuuwCJagI4bgchJQK/qe9c/RT6nGcg6KGREJpb+MI0EY/b0jcsni3AJBeCQNsBOFVYoApcM2Aom4VFgIRdHpeIG8D3YaxBD+qCiQ+rBOSVnci8hzkAG1t/pgHA4uwDzmu8xFKkkkIqCfkIRs204r/hiDgutoAAcowBMZ9+KS0CcXVBOHCvJw2jMQSJyeoeExF2DuTuRcuWAo9sefyUQ6/oBaIjPtiRH1KvQKvygAHb171d+vc4GRMDPoxN/kL5pwlVh1mBQ1quQJAJ5j0TgOAis+h8d3mnC8xTKE34+8sDNjyVXE6nFMN+H39TQDmocHScENvN74LoGScGU4f7g6IG3n3C3qnG6JBS+Z5tHOOzRYQx+u7MZmAl0OSsRLAS/VIKfRAWU92+12aaVPksGDBWQuCMvgNy2M2Mt8EwqbjosZAec5xLEAmXmcFTHiOWARWglpNpjdEtBQRxJJU5VL5/7F1X86XntXgUK4q+KggsUoIIK8oA+kgy4+zLaACqQGTVOX6MBWdehL6BxHn+tlyBMDGAqufd7WOX5WTJwKYDfXJJP2GXDPk7Tj5Ed7BOG7DMFaBRAJgI/+H2Ngeb2SKb0zkoGlQBHkefDr7xMA5HZeJPtKIzyApI9gmnPgf1c3mulfhe0gFekDCdNFnrOwi4Gs6eTACNjB+Uegcgojog4V25P8bctRYY6RL8AJklE9ACFAGZdBEahd4d4CmghFhbzcwaXYH5qTlS6DY+KfNH5Avzjo2JJ0poDkSCMxLn73H/eB+ifvgvyIFCWAji7BWC8hd0qj0FziMdrS70BlVbgamIgcmotGZDNPwm0L9l5iHv7WRoAFx57ScFS2r2iwot8oKu8l+TOCOg2mZ2nFdjTgOFQENzKkJ8OjEnsE8f6AzyXwT6MNF3RDRnuj0Lwo6wTlBMDIyqaz6G+RiLJMg/KUrQV/rh9uH0tWduwoxmky0kSMQ+rnXxZsGadgnxfgk1pCnsIsGYltvfdzTOBIclIsN8MLAGcz5gBwj94AE8DuC9Molip/JGwB57nRyJiyD3pyk6q5ij+3TzRLohcqyqCEQBTepF15+WVmW8SEr5jMUUkx3oMIsrH3ndwAQganKzyMpOJNxMQooGBYwcByw7axIhgPRGEr6GSGJhkAELoQ1YRg+dPeD5IIRDIqq5PA2Jh0Rq0YcS8XBi0ghGRFpCtWTdum5+yLOsQf2EuYY8AfnbQZDgCjHxBSKwTGpt8QCIDVH3/4H5OwEvldhliINwAFLsEyyIfGKV+vm3eEehVqKTdNxtDiPoLHCRiuwTJxCECxMDqDjTvZ63KaPKvRgV2i/F3ohm88V8LN8hgJcXD5pVGIPPNn9EBqSQC0I4AMxBUcQNCkarkFgSn/oCs9GCVep4eUG5BRAOcQOCWlGSc3If0IFqRfURQGRrKewPKEJ9sLnIowKCcw+f48N6UHjqYtgInaCCkBbPSj8VEkCr2g8U43wY1xX/BNkwreQrzg+oaJghOCGTU8RBxuIp6VFOGoEXgEsBLIgV6gBgxoLSI5CgiYNT+GBHsU01GthrceiMUtv9KgAYktgVNeGrBbtiOQVi9x8WjiAW7UNUnm4Vet7WtsFgDCDYEwQ/EVL1PnQf/xCDLTowTh4c4HPRDoQaiwhKIAae4B7xgCBydI/CDPOrevK0FR4p6w3VfoXgQiB3T1N8Y1PCD0X19JqcHGfzB5WkQE4p/kdeXBcEVUXEIFqSij82lMyrWq/7c+LFHA7z5/dwOHHg8s/Y8C2CmhbmALtare+4UWLfb25BmXABKABTniC8gRAP2yvDAiUAsElnrxFzITQa/sAFecAOY7zPV/8jMQHSbWAiUPGkQNABhw85xrSCv+mMSzFR8+7mjw01A8f4F8S/td4jnDHYxpT8/OEyV3gz2+GTfdAeAszswfJNGlQhEIjB0Bls0BKn4Iw7WKu9f1gmSagmvqleEwJwnZwjO7npz1HdCJ1hS/mlBcRXyF3i/M7NxqJFoeH27z7nnJaBmpUZKHsTbGUc1ALEoIGsGYl9ixS50gjAT/VhB8IzvGTrBVfWEz1MzAkRFTtecW731VdjNQPukVdhdn0Y8d/a7WYH6i/TBPBzUFwAlHwtGHOQISrgb1AMUgDETTA3+THAdeRJhg59V/Ektofa9I8wxVICkC7QQSAd2O3cftzPzdMK6aA4iZI4ILfYRbb9RgqICt2AxVnYZ4kkBvHOBxT/zN9ybHx/f5Ql2fkGCX6ANm6F8WCfqAS+Eq5AGcHJd2IFHagTMHAAj+mWBnDXuc81CjhsAi5dL2K8QCYI1aJ/PJtSSxEFXASv7C2I3ZB9/a0j/7nDn/j1pHsz9Jr8fNpxPBUAUUYD4wz5GBlmyAiORjtAIGDFwzSUwqiNZ1d1tPiB7/Q9VeI9KeJU16/knkEeQJEALjY4rkp74fCZiMDSA/PgvT/aT2gYgp5E/P29AKBQAo6TRth5T4VesQFb0i4K7RA2MZpgyFXCEQHCOixuYMPgy2L7+45ezSSKt2oUkURlpXkEMOLSiXPuDQZjk63N5bmzOSxQdLHX7AhwUEA0BAeQPJIQzkAuFlOK/GtyLdiGDKEBdllQ7YouxV2Xdwza9So4Kp5Z0yAgUhTlJgFzSFrznIHYIwKcCu2/L3LsCg6UI1b1/CA+ApIV5/32HqOIjdQusE4azip5Wc1b0q/QGIAlaWEJbXP3r/L+AEipw/+BtkQVY9fIM2i/ZhgVEgJO6DZ1ksVtlYdoQAPhVO0oKmYBmnAYco4DRCRB3TwCziptaE0auER9/VzRqKNOEYINOQg2m1l9GpGNQAhh1v6UmxNQh2M4+LmlUzll0OTjYQOaGlZAEMCrdhmBphaMBwBADrSQQc3//He8KgFETT7p6BHnjj2X9EXsDjrgBS6ihoAmcSQVYmE4JgYWFpp1waAQRoqDzxDhU+HxSnZHz/9JEY6Y5MJA+cwoWrt99+U3Mc/9g/NQTFaigAEtwB1yBzwzucZSX7RZEILhR1d5GDCsBLVUdIQvsldZfEJt5i/MHx2hGJZFkVVyK242iFeh58oBUFqIQbkfp2DV2X0CkAYgv1sU+P+I/HmBu8nErugdRnUWhfp+A/ddlbEH3uQlBsNobUEMHasK1HOYn8BEEvCUaiuigXRIKj+sGOPA4KAWz9/s7WxcgB4+a6/fI2osEwv4yOENAiPf+wQhbc/5f0gGisWuQaRFmGoIqguARWsBQgTTocDLMT5OJUQnhqdCEig+/EShKSEgTVV0MBMnz04BcshPnLk/+OaV0/dwKzB4QUt1NB6uTDfGOP+cNm9mEsBAFiM7AQh9AKVEU75vy68jeOxrUC4mDEuYO0oLqoSdHaEF2eXYYSm0V+oEOwpLmYFOF3Z4CmAeBTIGueiIw2xoKPzDBJVBXQ5g5O8/twwA+QguIjJt3+g0NQEcDfUXgO5gsqlTBLkQLdl86K3CWneitQ8sg/5oWAUJP2C3V3RoEyji5n4b9lB4t9pz2CA+cAFn1Z9I/uzYsU/ELtEBOCHYQQqGcFejV+yeuRJX31zsKV5IGjway9z6PLDxKwNEPsBuOEiqw57jGgOtZ1Y++T50AuMFl7hPIbhskiOwsATtRoc7rS7dXrpcgrMCGJca6ELJo+Y0be0BW5ZKGcFz4y8W9BduwcDnK9iO5fagsKpp9ANnvDPxeP8THNyIVFo1AMas8Qk5v2Ytm0LCCYAXqn+wQsPTBh/5Bcnne14Os3uCQt28vsK1WUESJFviBgAW//3u9PLxusXchcCR2WsNzv/ImvgZzzkUByDUAIrjTvmSHAowpJBQE4SUlxMxnARlQbIqkArVAJ6pBBvELCCKlkyCDAP45BYfEPfcUpfMch3Vn4bheYK4E66BxAxHSVd5INgEPgU/NBCDfNQ8Ho1CoINAPQAW/QT8OCIZlNFCB84XhoDChFByHGjx35v9BLgyhmojqHYb5QYXnuAecvua0hZe6BV9f7v4ibvgvamrmAc1TmaEir0LQ9h97eYAYVoM/nWA60i8Q3Ifezha9BqaaL3zvqd6IAuwwLSCCuCLuJWch4h30giPtyiAphKEBcCu9BV5wwzkMxID8rhMwdwMhcSFgrBT3RUTQboAUg3+p+Qe1IGarOioVnazmefV3lHpwA0AcLWCahUiXwePHWJsP+GH1gnp/we5KfOhJAbsj0H/BIEb04TbrTPsAyb2LLu93KwfCvn5PLAwrOXAa72eEQRo1CNdw5IprsAZ3hApy9zlcITG2vpCihsRSYxNS+J4vdBZ6B52eqRcQ/QXmSjAWSfa/5GA5qEg4iJFtm624AqXLrSA2gx8p1Mdqcghv41S0lSp/xAYs9gakQc4Ie2RTUYwYgt748mV+FU1Xgp14eW3XYZ6cdqGTNHwHICTwEeTPl0jEZwIgP9gDEaogeg5IHWCF+1eoAhvEKPB/EAeTRsM/pSAP5wjWEUMM1/NJRhwJbpJSgK7S7zF3EOsI5jBQBK9DV80Z8Y0COzvmWzJXgDl40KEC6cqvqgi4OB5cpgLFYK/1CvDiItXqC6/S87wfAUfPtxqfGNzlYaOjlf1IsHPPvffHgDAoEeEST4ZLZUd/RSo91/BjXY5ggWgQ4In3fyj4mUqPrInHOCLKO3wUwRsfyXpt1nEIRLrqcWeTuk7bigsbid1zD4iDRQtnIdQsyIXnFCn1I9D7ADgxEhOvR5AJosoUbu1FkJyYCi9OhQERoIx+4AX/YqUXQhtYEwKN4Cy1HntLMmtaAQpqfrT/UCoLSxeswjA5UWPPi0mjajUWxMTdVusNvt/ChMdmILK5IRMFu90BMEzFYHdg2GAgeYVHMMJIBTA7EFTx/5fpgTFXz9w/en0ZjD8kCDoKPNGwlB01BmoWQbh+AxR689mBponGJOr9OwmMu3dtJ/ylW1Tik4ElUPmR9RqII+pVhD9ychABMQ51gOIZg+/G+5mGIzLB1JJC5WhzYjhJ7IWmLDpA8jzsAafUPkB2WnFBF4iSxkq1ty7f25rv/+EQLOxs2oUdTSA9HIR9swdBlCcFe9owPC3XWDDC0ISVzsEVbSCF/sWdA5Fu4HJqankp2SeQCYYrImNalfmhpVxYrGkUS4LeSUjg8dD7+D7w/ybIfy7vlB9/HJ978zr7/45Qgajzj+4EjIK/ULHPRAOlKr/aG0AFcqCyu0GcW45Igh6JMJmhA49/U+cEssHNJhtXDC1MOya3j/sAiAGcrEtqtgjBD6wEzSDc7D8o6C8rIqAZyPk+NQoNLAZ1hR64Yl1FBY648smUYKnSg1Xwk/0DyRyArByMUobyByhCcPnOaPyoegREFS4jNfYAw+IHCjdC1J2WDZBke/OyN85J24WiXwDYPoJyYuCD238ulvuzwt6KgHf0shWKsqCFFGjB/w8HU8eeTED9wAAAAABJRU5ErkJggg==", "environmentBRDFTexture", "EnvironmentBRDFTexture"),
      PO = OO => iK(OO, "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAF9UlEQVR4nGWVy64eVxGF16X27u7/HMcyuZGYAINwmTBigngBXoc34El4B0ZMGDJjFCExQUIKiRKZYBITHdvn/L1rF4P+c+yEUqmH9WmtrrWLkdB4C1/91h/9yn947D8+8CfdlBeGGAMtqwNd6K7VWAJrw9qwLtw2nDaernh6wKuHPD3S1Vs6vaPT97W9r/Wx1seKUWj7Uzz6vX79T//wF/Gbx/7rw/jsFB/39nlrX7q99LKrp5bJZXAtrqW1uJIncbNOXafBU+o0tZW28got0AJ3KACsE4OfYvmzfvDMb/+4//Td9snD9rfr9vHWnyz9361/1fpNLLde0mt5pTZ7a9pCm32SrqQTfZI3aqNXHAwvcAB4BPwnk/oMEcqX8eaz1t9cHjxs7133f5z6p2v/Ylme9eWmLbexjlhnrPBirz3WxWv30rw0L/Yi96PpDrcDcPMEfq+qvQCfsFF1blcv2js3vb2xLNd9O/XT1p8u/Vlfnvd+25bResXC6BFLj2WJpUdv7uEe0exGByPoOAC//BH+cgNqUjfkU4mOEetde+O2vf+y8br71Nva+9q/XpYXvZ97z9ardUXrra3RerQWrUU4myLk4AzYiADwJ+NRQ41i7MSNEBIcM5YR1+f21rnlXcPWtbVYW1/a7dL21mZvbK211lv01lpEtIi0MxTmFGzMAABAN6gF1CTPxI1gkXa5Z5xGPNrbfo6xB/bQubW9nXvkHtXDPfqIJd2bI+1mpZjmNK17QFuxDzhBJued8Fy0KLvcp7fpNzJuM3JE7daIWGKMqAylW0bLiHQ0e1ppTXEK8Qrwkzv8fUIua6oG553wQpRIme7lbfpBxm3GnoEMZ+wZlYGMlu6pNh1pT3nqALCEugCeAB2ohKqYk9hZd4JFS5ThDm/lB9N305nGtKfnNKZiqk23qZhySZOcYhHFewXfI54UMCBDOYlU3TMkSaYWaCtdwXu5yprOKUxrqk9FyUWXNKXiBfCNgucGboGAUBwUJzFYO3G+MCwFtdAn6K6UZZSyXCXBAUVdGCoS5IVxAcQNujAHKCiLLHJqDtWZh1GHV0Et8EYNqOABTUhglKJoyKBBgSwCBC6Ajz7Azz+GiJbwhFTkZCXnEM6EJcuHDmmlztCkBE2IkMGAAhQoSCBBvgYA0G6xN4DgLE5IU5iqZA1hJ8zDqCY2qktJHfEnZSpIk6bE++kEXwHUEBMCmBBBFzE5UzNZuyBRshlSSF0aEg6MaDHIgyFCPAqvA/YdIjTgQ3WBLNZkpWoQPnRIUljdGiIkHd9jumgeO0ESEI97cNTPJj6Z4ISOZh1JUSVLwiAs7pRp02aTypRUhwIzjvhfPCKF1wH/BTqwA5pQlnYyipgs6dDBQVncZatZaZUlsUxZYVq0jyfm8kNeBzz/Gu0ETrjABAURAoTJOVVJpDAoM3ZOc5olfmMK42CYMrRTAr6tIK6QiSA84VtIIEosslSTNYUkUxyS5aEDQ6tMmQ7YDMOmjziYx8E56oPEl8DdDgM2/BLeIJVw9CRSTClZg97ZrDl0BF6m49V0GTIZQL4CvNuxFj47w4ASmqUkAalYU+DBoIbK8hAG506aZTLonWFG0IMa1AAHXlegW9wFGuAJG97hhFkqiuCxUZyqSSWR5GCZHKxB7nSwDcZADHiACQ4eJ/Oot9+BvsaLQD2Hby9RUEEs1cUlcdKpmWKSQ2VyqAY56J0RiEEPOqHxXYv2W4yJuANWxBkBOKEGFcwyjlhMYdLJSjLJpA8FAxqMwXZRQA0wgdQ94Hcf4nqDFnQhBDcY5YJUIqSSpnxpRqone6ol+2Af7Il2MJJxnN/8lgIA8yWQUKItaBMRsGEdDIrQoYNTnGSyBqdZQSY16IEYaANOOKn/A+htXH+OdgLOiB1BBOEGCz5ejmO6JpGEeexVJTmohJNORqIlnVDyO4CvvsT2AGm0BVEHo0IMHeEooeQipzDFY5eSNcigLgwoGYlIKHF/ky9Z+xD/WrCfoQUuRCGAKBhlwIBRQvmSuykkMYHkqx7EAPK+/wdqEbWmfB0bfwAAAABJRU5ErkJggg==", "environmentFuzzBRDFTexture", "EnvironmentFuzzBRDFTexture"),
      mK = OO => iK(OO, "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAABGSklEQVR42u3cx4tb6brvcf0DmmpUoxrUoAY1KCgwFAZjME1jjGmMTWNs2tjY2MY2DjjinHPOOeec3dXOOeecU2VlaSksSc/9aq1X0pJKqmD3Dn3upvnCSe197v38nlfS2fscW1x+kbCMloAsFY/skEY5KbVySb7JXfkoT+WtvJGX8ol/67s8lDr+o065KW65Jl7+q/zyF3/nWTpJx+gQ/7H94pPd/Oe38yduEZds4E9dK/Wykj95GX/OYvkq8/kz58h7mcmfP41/hMnyTCbIIxkn9/nv5raMlOsyTK7IELkgg6RKBshp6ScnpI8ckd5yQHrJHvmd/3578I/QjX+E32SNdOEfobMskV9lAf+vmiOdZIZ0lKnSQSZKe/7kSv7kdjKchkoFf2q59Ke+UsafWCY9pZQ/rZQ/rUS6Umcp5k8q5k8p5k8p4k8p4k8o4u928Hc7+Dsd/F1mpWLn7zArVhWpHOlsRvYC/Yf++t8A/j8fQCxrADvTA/j6vwH8/zGAaOzX/w3g/+cBaJEuEkqMMQbg/t8A2jiA8n/+AHzB7qLFx8K2zBhAA5Q16QE8+98A/q8PwOXvLYHYePEllsO666cGcPR/A/jnDaDRN0C80Ynija8QV2K3GsBlywDe5h3AVYAvAv0X4IUH4P7fAP7bB9DgGyau0BRx6yvFGd8j9YlTUp24LF+g/gDKGwbwAqwnwD1o5QD2/VcPYMT/BmD9q94/Thq0GeKMrpbG2B6pi5+S78kBJAoNoDFrAFU/PICP/+UD6PL/xwDqAlOlNjBH6sMQ6XulJnZavsWvyGcG8D7BABJvsgZwxxiAK2sAZ9ID8P/gAF78QwbQ/v/eAGqDc6Tav1BqtA1SE90v1fpp+Rq7Ip/id+UdA3jNAJ4nPsnjRGYAN0C9whe8C+kB+BmAP2sAu/jPNx1AjRrAlzwDeNqKARz/3wD+7r+qtSXy1QdLcJN8Dx+Qb9Ez8kW/Ih9id+Vt/Jm8sgzgfqL5ARwxBuBjAN70ADbznSE5gDWMJzWARekBvGsygLFy738D+Hf+9T20Sj77VsuXwFb5oh2SL5Gz8lG/Ku8ZwJvYM3kZfyPP4h/lUeIbA6iV24lGuZ5IDcALjQ8aP4+zOYCD/Pt70wNwqQE0WAbwLWcAr/MM4FbOAP78Bw+g6L97AN/CG+Sjb6N89O+Qj9oR+Rg+J++jV+Wtfk9eMYAXsTfyhAE8jH+TuwzgVqLBGMDlhFvOJ7zyZyI5AB8D8EHjyxrAtjYN4EnWAEYYA7j8XzCAXwoMoOJvHsB/aARfwtvkvS/ZHnkfOCbvtCp5G74mb6L35KX+TJ4xgMexj/IgOYB4rdyMN8i1hFMuGQPwyDlGcJoRHE+YAzgA/l7jn1VwqwE0WgZQLUuNAXxmAB+MAcyQVxClBvCQAdxtxQD25x1A1x8ewB9tGEAljO3+7wzgU2SPvPPvlje+A/LGf0LeBP+S16Fr8jJyT55Hn8kT/Y080j/K/dhXuROvYQD1cjWeHIBL/lIDOEXH6TAdoD0JcwBbGcAmBrCeL4Br+AWQO4DZ/MQ0B/C8mQGczxnA4YIDaM0LUNmqAfz2LxmA/b9xAB8iB+VN4IC88h2Rl/5T8jJwXl5o1+V56L48jTyTx9HX8kD/IHf1r3IrViPXY/VyJd4oF+IuqYq75SzYJ0E/ZgzAI/tpD6/DDgaylZdiE9efHMBqYwDfGcBXBvBJ5uUMYJIxgAeWAVyzDODcv2gAA35oAEV5BpAZwT9sAO+iR+VV4Ii88B2X576z8tx/QZ4Fb8gT7b48Dj+Vh5HXcj/6Qe7oX+SmXi3XYnVyOdbAAJwMwCVnGMHJuEeOAn/IGICbAbiMAWzhC+NGvjOs49fD6kSNrFADWGgM4L0awEs1gMeWAdxUA7jUxgGs+Le8AP+nBvAmelJeBE/IM99peeqrkif+S/I4cFMeMYAHoadyP/xK7kTey63oF7muf5creq1c4hU4H2uUczGXnGYEJxjBETpE+4DfbQzAqQZQzwBqZVWiWlbwS2JJ4ossTHxUA3ijBvDMGMB4YwB3ZFTeAZz6FwzA+gL0+jcN4L/sl8BL/Yw8004Df04e+87LI98Veei/JQ+CD+Se9lTuhF7JrfB7uRH5JNei3+SyXiMX9Hqp0hvkbMwppxjBcTrCEA7SXtrF67Ad/C1c/wauf60awHJjAJ8ZwAeZm3gnsxJvZHrihUxNpAZwvxUDOKQGsJsBbP+bB/A7df/JAfzD/mcBz3WuXvtTHvmr5IHvotz3XZN7DOBu4IHcCT6VW9oruRF6J9fCn+RK5KtcjFbL+Wid/MkITuuNcpIRHKPDjGA/8HtoJ98RtvFrYTNfGDeAv5bnf2XiOwP4KosTn2SBMYC3DOCVMYApiacyKfFIxifuy5hEcgA3YLrKAC7KYPlLBjKA/nKSARzLM4DNagCr/4UD6PRvGsB/YARPda5eOy8PAhfknu+y3PVdlzu+O3LL/0BuBp7Kde2lXNPeyZXQR7kU/irnI9+lKlojZxnBKV6B44zgCB3iI2E/7aEd4G8Ff1O8Tjbw03FNvFpW8jNyGc//Yp7/BYn3lgE8ZwBPZKIxgHsM4LaMSlyXEYkrMjTBABJVDOCsMYC+lgH0VAPo/hMDqGhxAJ1bOYCyf+4AHuuX+Ky/yMVfAv6q3PLdlJsM4Ib/oVxnANeCL+WK9lYuaR/kQuiLVIW/yblItZyO1spJRnCMl+AwQzhAe2kXXxB38B1hC18WN4K/HvzV8e8M4KssjX+WRfGPMp/nfw7P/8zES5mWHsADGZe4ywBuGQMYbgzggjmAxBnpn2AAiaPSJ5EcwD4GsAuubWoA6/83gB/964F+Re6Grsjt4FW56b8uN3y35LrvrlzzPZQr/qdyOfBSLgbfyHntvVRpn+Rc6KucCX+Xk5EaOR6plSOM4FC0XvYzhD20U6+TbeBvidXKBn42rot9l1Vc/4r4FwbwiQF8kHnxtzI7/lpmxl8wgGcyOfE4awAjE9cYwGXLAE4zgBMM4AgDOCi9E3ulZ4IBJBhAYpN0S6QGsByyxX/bAEqyBtDxJwbwX/xL4J5+TW6Hr8nN4HW57r8B/G254rsnl32P5BIDuOB/IecDb6Qq+F7OaR/ljPZFToW+yXFGcJQRHGYEB3gN9tJufiHsoK18UdzET8YN4K+JfZOVsa+yPPZJlsQ+yML4OwbwhgG8khnx5zI1/lQmxx/JhPh9BnBHRiduqgFcYgDnGcCfWQP4Iz2AndkDSKySLgkGkGAAifnyS2K2GsCUv2UAxQUH8A//HwbdiV2Xm2HwtRtyNXAL/DtyyXdfLjCA876n8hcDqAq8lnOBd3Im+EFO8QqcYATHGMFhRnAwXC37GcIe2sl3g+18SdwC/kZ+Mq7Xv8lq/SsD+CzLYh9lcey9LIi9lbmx1zIr/lKmx58xgCcyKf6QAdyTsfHbMjp+Q0bGrxoDGMIABiXOqQEcVwM4wAD2qAFsVQNYl38ACQaQYAAJBpBgAIm2DKDrDwzg7/gp+G8ewc3YTbkevilXtZs897flov8u+PfBfyRVDOCc74Wc9b+S04G3cpJX4ETwoxzTPssR7ascYgT7+U6whyHs4svhDtoa/S6b+Lm4Afi1+hdZpX+WFfpHWap/kEWxdzI/9kbmxF7JzNgLmR57KlPijxnAAxkfv8sAbjEAvgDGr8iw+EUZEv9LBsX5CZjgJ6AxgMMMgF8AxgB2SA9jABuNAXRt7QASDCDBABIMIMEAEgwgwQAShQbQ+n9VUNP/WcA/4HvA9RhXH7nFl7xbciFwR84zgCrfA/mTAZzzPZEzvudy2v9STvrfyHFegaO8AkcYwSFGsJ+XYC/fCXbTDoawLfJNtvBTcSOtj36RNdFPshL85eAv0d/JQv2tzNNfyWzwZ8aeybTYE5kceyQTY/dlfOyOjInflFHxawzgMgO4wACqGMBZGRDnJ2D8mPSNH8oZwBY1gLUMYCUDWMYAFlkGML1tA0gwgAQDSDCARKEBFP7nA/6RA7jCAC5FbssFDfwg+P57wD8A/pGcZgAnGcAJ30s57n8tR/1v5XDgvRxiBPsZwV4+DvYwhJ38OthOW8JfZBNtiHyWtZFPsir6UVZEP8jS6DtZBP4C/bXM1V/KLP25zNCfylT9MQN4IBNid2Vc7LaMid2QUTGe/xif/3E+/+N/MoDTagD8AkgOIM4A4rulZ5wBxJMD2JBnAPPyDGAs+KPyDKBf4QEkGECCASQYQIIBJP5d/7OAf+MILvH/8Rcid+Sv0B35kwGcC9zn4h/IKQZwkgEc9z2TY3wMHPG9kkO8AgcZwX5GsJcR7GEEO/liuJ0hbAl9ks20IfxR1tHqyAdZGXkvyyPvZEn0rSyMvpZ50ZcyR+f69WcyHfwp+kOZpN+XCfodGcsQR/N9ZGTsCgO4KENjf8ngGJ//DKB//DgD4BdAnC+A8X0MgF8A8e3mAOIb5Lf4GukaTw5gqWUAsywDmNDGAXQrPIAEA0gwgAQDSDCABANIMIBEqZE9UaIqVhVZcqSzJf5LBnCep7cqeoefd3flrHaPz/r7PPcPuPpH4D+RowzgMK/AIV6BA3wX2M8I9vJ9YDcfBzv5TrCdIWzVPshm2hj6IOtpTei9rAy/kxW0NPJWFkVeywLw50ZfyOzoM5kRfSLT9EcyWX8gE/W7Ml6/LWP1GzKaXyQjYjz/sQsMoIoBnJWBsZPSP8bnf+wwA+ALYHwvA+ALYHwbA9icPYA4A4gvlF/jc+WXeGoAk/+GAfzSigGUtXEAagS5/bsHUMUAzkXv8tv+Lt/w78lJBnCcARxlAEd8j4F/KgcZwH5egX2MYA8j2M0IdjCC7bQ1+E4200btnayntbQq9FZW0rLwG1kSfiULIy9lXuSFzIk8k1ngT48+lqnRBzI5es+4/nH6TRmjX5dR+hUZoV+SYfp5GRLj+Y/x/BsD4PM/xvMf2y+9Y3z+x3YwgK0MgF8AcX4CxlczgBUMYEn2AOLTpGOcAcStAxje4gBK/5MDSGfL9K/86xwDOM0ATjGAEwzgePC+HAk8kMP+R+A/lgO8Avt5BfYygj2MYBcj2MEItvOdYEvgjWymjcE3sp7Wam9kNa2k5aFXsoQWhV/K/PBzmRt+JrMjT2RG5LFMizyUKdH7Mol/3PHRWzI2al7/SP2yDNe5fr1KhujnZJDOAHSe/9gRywB2mwOI8fzH+AIY4ydgfBUDWK4GsEANYGb2AOIMIM4A4gwgzgDihb4E9rAMoMvfMIDiHxxAzghy+7v+Os0ATgJxnAEcYwBHGMAhBnDQ/xD4R1z9Y+CfyG5GsJMR7GAE22gLvww2M4SNgVeyntYGX8lqWqm9kuXaS1lKi7UXsiD0XOaFnsmc8BOZGX4s08MPZWrkvkyO3JWJfPkcF+X6o9dkVJTrj15kAOcZwJ8yWD8jA/WT5gB0nn/9gPyh8/zHdjGA7WoAfAGMrZXfYiula4wBxBYbA/glPqd1A4gzgDgDiDOAOAOIM4A4A4gzgDgDiDOAeGoAnZoZQL7vAcXNvgI/PYC21NxfJ+N35Difw0cZwJHQPb7h35cDDGA/HwN7eQX2MIBdDGAHbWcEW2kLQ9jECDb4X8h6Wht4IatpZfCFLKelwefgP5eF2jOZrz2VOaHHMiv0SGaEHsi08H2Zwj/WJPAnRG7KuMh1GRO5ygAuMYALMizK9UfN6x+on5D++lHpqx9iAFy/vkd66Tulp87nf2yzGsAaYwBdYvwCiPEFMMZPwNgc6RSbwQCmMoBJDGA8AxhjGcCQtg0gzgDiDCDOAOK5A/iZL4L/xhEU6hgDOMIADnORB/kiuF+7L/sYwR5GsJtXYCevwA5GsI22MILNfCfYxAg20Hpa638uq2ll4LksDzyTpbQ4+EwWBp+A/0Tmao9ltvZIZoI/PQQ+/xiTwuCHwQ9fl7Hgj45clpGRCzI8wvVHuf7oGRkU5fqjxxkAz79+kOvfxwB2MwCef53Pf32TdNfXSzedz39jAEvVAPgFEJttDKBjjAHEGECMAcSSAxj59wwgzgDiDCBeYfZPHsARBnCIL2IHGcB+cPbyMbCHAeziy+AOXoHtvgdc/SPwH4H/WDbSBoawjtbQKlrpfyLLaWngiSymhYHHMj/4WOYGH4H/QGYyqun8uVO1uzI5dFsmhm7K+BD44WsyOnxFRoUvygjwh0W4/shZGRzh+qMnGMBR6Rfl+qP7jee/t87zr/P861sYAJ//Op//Op//Ol8AdT7/db4A6skB8AUwxi+AGD8BYxNpnDmA2EhpFxtGDCDGAGL9pTzGAGIMINaaAXTMGUBqBAwgXqZiAPF/0AAOxW/LAQawL3JH9jCA3SDtDN7jW/592ea/L1sZwRZGsMn3EPhHXP0jWUtrGMIqWknLaan/sSzmI2MhzQ88lLm8ILMZ0kyaEbwr07Q7MkW7JZO0mzJBuy7jQtdkTAj80CUZGT4vw8NVMjR8jgGclkERrj/C9Ue4/uhBcwBRnv/oDukZ3coAeP51nn+dz3+dz3+dz3+dz3+dL4A6XwB1BqAzAJ0B6AxAZwD6aKnUrQMY2HQAMQYQYwCx/AMoNgaQ7xXIMwCjYktFmbIG4PjPDmA/A9jH7/A9DGBX+I7sAGo7I9gWuMu3/Ht80bvP1d8H/z5X/wD8B7KaVjKIFbSMlvLvL6aFjGU+zeXvmc3fO4s/Y0bwjkwL3pYpwQz+eO2qjNWuyOgkfuiCjAhVybAQ+OEzMjh8UgaGjzOAI9Ivckj6RsCPcP2RXQyA649y/dGN0j3K8x9drQawjAEsYgDzGQBfAHW+AOp8AdT5AqjzBTA9gBHSTmcA+mCp0AeC38wAYgwgxgBi/BSMtXUApc0PIO5IZzOym/0nRrAnfkv26LdkV/S27OCzeXvojmxlBFuA2wTgBv9dvujdBf8eV3+fq78vK733ZQUt499eQotoIc3nv2Yu/7WzaZb/jswI3JZpgVsyJXBTJgevy8TgNRkfTOJfljHaRRmlga/9JcNDf8rQ0BkZEjolg0I8/eGj0j98WPqFuf7wPgawhwFw/ZFt8ntkMwPYwADWMgCe/yjPf5TP/yjPf5TnPzqb+AKo8/mvT1IDGEujmg5AZwA6A9AZgJ4aQPecAfxqDiDGAGIMIMYAYgwg1poBlLRtAAWzFe5nB7ArflN2MoAd/B7fFr4lW/iM3qzd5rf9HdkQuAP+Hb7o3eHq73L1Zsu9d2UpLaFF/PsLaL7vjsyl2b7b4N+SGTTNfxP8GzI5AH4giX9FxgUvyZhgEv+8jNSqZLj2pwzTzsoQ7bQMDnH9oWMyIMT1h7j+8H4GAH6Y6w9vZwBbGABf/iJcf4Rv/xGuP8LzH+H5j/L8R3n+ozz/0enEAKIMIDo+ZwBDCw9AZwA6A9AZgN6KAcQYQIwBxMpVDCBWavT3DqCFEfzMQHYwgO36TdnK7/EtDGBT6JZs4LN6A0/2Oq53DVe8yn8b+Ns8+be5+js8+Xdksfe2LKQFNM93C/xb4N+Smb6bMoOm+a/LFJrsvyYT/VdkQuCyjAuAH7ggo4PgB6tkRPCcgT80ia+dlEEaT792RPqD3y8Efmiv/BHazQC4/jCf/WGuP8z1h9dJtzDPf2QFA1jKAHj+Izz/EZ7/yExjAB2jU2iiOYAoXwCjDCA63DIAfgHo/ahP4QHoDEBnADoD0Ns4gFiJqlhVZCl3AI5/3QBaalv8hmzRb8jm6A3ZyO/yDXxDX89n9VpaHbwpq3i+V3LNy2kZwEtoMS303pT5NI/m0GzvDfCvy3Sa5rsmU2iy74qJ778k4/wXZWwSPwB+APzAORkePCNDg6dlSNDEH5jE18DXDkhfbZ/00bj+0E7pFeL6Q1x/aKP0CK1nAFx/mOsPc/3hJbRQOofnMQCe/wjPf4TP/wif/5EJDIDP/yif/9GR5gCifAGM8gsgah1A79YNQGcAOgPQGYDOAHQGoLd2AHlGoLIZ2bP7dw1gS/y6bNKvy4YoRa7LOn6br9FuyGpaGbwhK3jCl/tv8C3/BvA3ePJv8OTfAP+6zKU5NItmeq/JdJrmuwr+FfAvy0TfJZnguwj+BRnrPy+j/VUyyv+niR8AP3BKhgROyOAg+MEjMiB4iAFk8P/QdklvbYf00rh+jevXuP4Q1x/i+kMMIMSXvxDPf5jnP8zzH55FPP9hnv/IJHMAEZ7/CAOIjGAAw7IHEGUAUQYQZQDRnj8+AL1cxQD0UiO7/pMDyJvN7O8cwMb4NdmgX5P10WuyNnJN1vDbfBW/0VfybX0FX9yW8fm9hBbznC/kqhfQPJpLswGf5b0qM7xXwL8iU2mK95JMoonAj/ddkHG+8zLW95eM9iXxz8kI/1kZ7j8tw/wnTfzAMRkUAD8AfvCg9Avul75B8IMZ/J4a169x/RrXr62RbtpK+U1bzgC4/hDXH+L6Qzz/YZ7/8DTi+Q/z/Id5/iNjaJQxgHYRBhBhABF+Akb6Nx1AlAFEGUCUAUQZQJQBRFszgArLAMoyAzAqtlRklncAjtYPoFA/MoAN8auyLnZV1uhXZXXkqqwMX5UVoauynJ9qS/nGvoQWBa7yE+8qP/Gugn9F5tBsmgn4DO9lmQb4VJrivQj+BZlI473nZZz3L/CrwP9TRvnA952R4T6F7z8ug/3g+4/IwCR+4ID0C4Af2CN9ArsYAPjBbdIzCH4Q/CDXr/HNX1sFPp/9Gp/9Gtevcf2hucTzH+L5D3H9ockMgOsP8/yH+fwP8/yHef7DfP5HBmcGEOlLfP5HGECEAUR6GAMoif6WPYAoA4gygCgDiLZ1ACVNB2DkSGfT/6YBtKXUANbGr8ia2BVZpV+RlZErsiJ8RZaFrshSfqcvpkV8c18QuAL+ZX7iXQb/ksyimTQd9GmgTwV8Mk0CfQKN91aBXyVjvH/KaO85GeU9A/5p8E/KMN8JGeoD33fUxPcfkgF+8P3g+8H3gx/YIb0D26RXYIv0DGyS3wMbGMBa6R5cLd2CyetfxgC4fo3r17h+jevXZhLPf4jrD/H8h8YTz39otGUAQ4jnP8zzH2YAYQYQTg6gV2YAEQYQYQARBhApMIAoA4gygCgDiFaYNRlAaQsDyDMC3d60f+UIkq2OX5KVMdIvyfLoJVkaviRLQpdkkXZJFtJ8frbN49v7XJrNF7lZPO0zeNqn0zTQpwA+mSZy7RNAHw/6ONDH0GjgR3lPywjvKRnuBd97HPxj4B+RQb7DMtAHvu+A9Pftk74+he8H3w++H3y/wg+sk+4B8APgB3n6g1x/kG/+wQUMgOvXuH6N69f48qdx/RrPv8bzr/H8h3j+Q3z+h3j+Qzz/IQYQSg6A5z/M858cQJgBhHn+wwwg3M0ygM5SHGEAEQYQYQARBhApMIAoA4iWqcCP/k0DaJItu58dwMr4RVkRuyjL9IuyNHpRFkcuyqLQRVmgXZD5NDd4Qebw7X02zeSL3Ayaxuf6VD7Xp4A+CfSJNAH48aCP9Z4F/wz4p2Uk8COAH+49YeJ7j8pgL/jeQzLQe1AGePcb+P3A7+sD3we+D3wf+D7w/eD7wfevMfEDK2ipdA0sli4B8INcf5DrD3L9Qa5f4/o1rl/j+dd4/rXRxPVrXL/G86/x/Id4/kNcf4gBhBhAiOc/xC8A6wDCDCDchRhAOM8AIgwgwgAiDCDSzACiJapiS3/zAFpboQEsj1+QZbELskS/IIujF2Rh5IIsCJ+XeaHzMlc7L7P5zT6LZgb+kun+v/h9XwV+Fd/y/5RJNBH0JPw44MeCPoZGeU7JSM9JGeE5IcM9x2WY55gM8RwB/7DCP2Die/dKPy/43l3Sx7tD/vBuk97eLQxgEwPYIL/71ksP3xoGsEq6+cH38/T7efoDPP2B+TRHfg3wzT/A9QenEtcf5PqDPP9Bnn+N69e4fo3r14aYA9AYgMYANJ7/0B9qADz/IQYQ4gtgiAGEcgYQZgBhBhBmAOE8AzBiAJEyVakaQYEBpHOks/07RpCvpfHzsjh2Xhbp52VB9LzMj/wl88J/yZzQXzJbq5KZNCNYJdP57T6Vn3BT+CY/mS90k2iC7yz4Z8A/beCP5tpHAT8S+BHADwd+GPBDPIdlsOeQDPIclIGe/TLAs0/6e/ZIP89u6evZKX08Fnwv+F7wvQrfB76P6/cpfP8iAt/P0++fbeD/EuCbf4DrD0wirj/I9Qd5/oMMIMgAguYAKjSef43nX+tnDkBjABrPv8YAtB6WAfD8hxhAiAGEGEAoZwBhBhBmAGEGEC4wALJHSlTFZs0NIJ29af/KASyOV8nCWJUs0KtkXrRK5kaqZE64SmaF/gT/T5mhnZNpwXMyld/uUwJnZZL/DD/xzoB/mp95SfhTXP1J8E+Afxz84+Cb8EMN/EPgHwT/gMLfq/B3gb8D/O3yh2er9PaA7wHfo/C94HvB9ybxl9MS6eoD38fT75tn4P/q5+n38/T7uX4/1+/n+gPjCPwA+AGe/wDPf5DnP8j1B7n+INcfTA6A51/rrQbwuzkAjQFoXL/GALScAYQ6SVGIAYQYQChnAEYMIFymKjAAoyJLjjwjsLciW3Y/M4CF8T9lfuxPmaefkznRczI7ck5mhc/JjNA5ma6dlWk0JXhGJgdOyySayG/48f5T/L4/yU+8k+CfAP84X/aOAX+Uqz+i8A8p/AMyyL1fBrr3yQD3Hunv3i393Dulrxt8N/hu8N0WfM866eEB32Pid/OC7+Vz3wu+18Tv7OPp9/H0+7h+H9fvM/E7+nn6/Tz9fj77/Ul8rj/A9Qd4/gNcf2CAGgDXH2QAQQYQtA6A67cOQGMAGvga15/GVwMIMYAQAwhVmOUOgOzhElWxWZMBqBGobEb27FozgNZUaADz4udkbuyszNHPyqzoWZkZOSMzwmdkeui0TNVOyxSaHDwlEwOnZELgJPgnZZz/BPjHZYzPhB/Jl7sRfLkbzlM/DHQT/4AMBn4Q8AOBN/F3gb9D4W8Dfwv4m6WXe6P0dIPvBt9t4nf3gO8B3wO+hy99ngUMAHwv+F7wveB7k/g8/T6efh9Pv4/r93H9fq7fD76f6/dz/X6uPzDQGEB5gOsPMIDAH2oAPP9BBhDk+oMMIJgaQBL/18wANAagga+1V+UMIMQAQmWqUqMmAzAqyslhlh5AnhHkzWYW/cnmxk/L7NhpmaWflpnR0zI9clqmhU/J1NAp8E/KJJoYPCkTgidkfOA4+MD7j8lofseP4ufcSOBH8OVuOOjDeOqHAj+Ep34w8IPcexX+bvB3Sj8X+K7t0se1Vf5wge/aJL1cG8BfD/5aA7+HG3w3+G7w3SZ+V89CBsDnvofPfQ9Pv4en38vT7+Xp93L9Xp5+L9fv4/p9XL+P6/cNJ67fz/X7uX4/A/Bz/f4kPtcfAD/A9QcYQKCHZQDgB7n+IAMIMoBgMwPQGIBWoWIAWs4AQiWqYksFBkC2dPbsmhtAS7U0gNnxUzIzdkpm6KdkevSkTIuclCnhkzI5dEIm0UTtuIwPAh88JmMDx8A/KqP9R0x8fseP4Fv9MK8F3pMfvh/wfV3bwN8C/mbwN5r4LvBd4LtW00rp7loB/jLw+cx3g+8G3w2+ey4pfM90At8DvoenP4nvHUtcv5fr944w8X1cv4/r94Hv4/n39zMH4Of6/QzA35N+NwcQYAABrj/AAAI5AwgygCADCDKAYAq/wACMSo3sWolZ1giKcnKks4UKDCBvNrPITzYzflJmxIDXT8jU6AmZEjkuk8PHZSJNCB2T8doxGacdlbHBIzImALz/sIz0Aw/+cN9B8A/w+34/+PvA38uXvT3g7wZ/F/g71NVvM67exN9kwV8H/ppsfBf4riW0SLq6ePZdFnw3+G7w3eC7JzMAnn4PT7+Hp98DvmcUA+D6vVy/F3wv1+8dpAbA9fsYgK8PMQBfL2MApckB+MH3c/1+BuBXAwgwgAADCDCAAAMIWAYQrFQxgGCFWXMDMCpWFWWXOwAje/7yDaClWhrA9PhxmRY7LlN14PVjMil6TCZGjsqE8FEZHzoiYzXgtcMyOnhIRgUOgX9QRvgPgL9fhtFQ7z4Zwu/5wcAP4mfdQOAHAG/ibwN/a/rq/wC+N/C9uPqeXL2Jv0rhL8+DP4/Ad4Hvmkngu5L4Uwh89wQC383T7+Hp94Dv4fo9XL8HfA/X7wXfy/V7wfdy/d4kfm9zAD7wfVy/jwH4UgMA3w++H3w/+H4T3xhAgAEEGEAA/EA7I3MA5aoyVamRPZhvALkjcKSzpbMXHkE6W3bhH2xq/JhMiR0F/6hM0o/IxOgRGR85IuPCh2Vs6BD4h2Q0jQoelJGBA+Dvl+H+JP4+GerbA/4eGezdDf4ufubtUPjbwd8K/hbwN6ur36Dw10lPJ/hOrt650qi7M4m/FPjFOfhzmuK7wHeB7wLfNd7A7+AG3831u8F3D6OhBn47D9fvAd/D9XuS+H3MAXjB9/L8exmAt4eBX+oD38f1+xiAjwH4LAPwg+/voMoZQIABBMpVZWbWAaQrttSKARSquRE0V6EBTIkfkUkx4MGfoB+W8dFDMi5ySMaGwQ8dBP+AjNT2y4gg8IF9Msy/V4b6gQd/sA94r4I38LeDv5Vv+lsU/qb01fd2rpdewPd0rgF/lcJfAf4y6eYE3wm+c6F0dYLvBN8JvhN8Zwb/l1x8F/gunn4X+C7wXcNNfDfX7wbfzfW7+zOAfuYAPOB7uH4PA/AofC/X7+X6vQzAywC8DMCrBuBjAD4G4GMAPvB97c0B+BmAH3wjBuAvN0sNIFBqZA+UWMoZQDpHOluwFQPIyta0UBubFD8kE2OHwD8k42ls9KCMiRyQ0eH9Miq038TX9snw4F4ZFthj4vt3g79TBvl2yEBvEh94zzYD3sTfDP5G8JNXn4RfR2vAXw3+SoW/XOHz5DsXKfz5FvxZJr4TfCf4TvCd4Dsn5sEfaeK7ePpd4Lu4flcSf4AxgHI3+G6u380A3En8nuYAPAzAwwA84HvA9yh8L/he8L2dVJYB+CpV4PsqzFID8JepwDcqMUsNIF2RJUfTERjZm9aaAbQm6wAmxA/K+NhBGacfkLH6fhkT3S+jI+CH98nI0F7w98hwGhbcLUMDu8DfKYP9OxT+dhng3QY+8NSX3/R9+U3fB3gTf526+tW0SuGbV9+dq+/WyNU3gt+4QLo2gt84l8BvBL9xBmXjd0riO8F3gu8E3wm+cyQDMPErXUMVPtfvAt/F9bu4fhf4riR+b3MAbvDd4LvBd3P9bssAPAzAwwA8DMCj8I0YgJcBeCtVDMCrBuArV5WpwPdZBmBUbKnILDUAS7Z0drNgc9my+5ExjI/vl3Gx/Sa+vk9GR/fKqAjwYeBDwGvAa8AHd8qQwA4T379dBvq2gb9F+nuT+En4TdLHvUHhrwd/bfrqewL/u+XquzcuUfgLFf48hT87G78R/EbwG8FvBL9xPPGlr3EMAxht4jt5+p3gO8F3gu9M4g+04PdVAwDfBb6L63cxABcDcCUHAL4bfDf47s5GxW4G4FYD8IDv6aBiAB7wPe0yAzAqV5Wp1AB8Jari7FIDMHJkZUuVGkCz2ZqOoLnyDWBcfJ+Mie2V0Trw+h4ZGd0jIyK7ZXh4twwL7QIfeA34IPAB4P1bZYB/iwzwJfE3Sz/vJunr2Wjg/+FeD/468NfwZS9z9b9z9T0M+KUKf5HCn6/w5yj8mQp/msKfrPAnZOM3gt8IfiP4jeA3JvGHGPjtnOA7uX4n+E7wneA7uX5nHnwX1+9iAC4G4GIALvBdCt/dScUA3OC726vMATiMwPeUq8pUpeYAjEpUxZl8RTk5skoPwG8vnHUALdXSKMbE98jo2B4TX98tI6K7ZHhkpwwL75ChoR3gb5fB2jYZFNwqAwNbDPz+/s3S37cJ/I3gc/Ue4N3rjKvvDXwvftr1VPC/c/U9LFffTV29ic/VN4DfMEs6N4DfMJ3AbwC/AfwG8BvAbwC/gWe/AfwGK/5wE78R/EauvxH8RvAbuf5G8BtT+L3NATgZgJMBOMF38s3facW3DMDFAFzguzoaFbkYgEvhG4HvrlCVqywDILtRicoyAG9RTg6z1ADS2ZuWdxC2pgXa0Oj4bhkV2wX+Lhmh75Th0R0yLAJ+eLsMCW0Df6sM0rbIwCD4AeD9wPuA922Qvt714K+TPzzAu9cY8L34Td/Tlbn6Hs7k1S82rr6b5eq7NiTxZyv8GRb8KQp/Yn78BvAbwG8Av2Eogd8AfgP4DeA3JPG5fmMAfxD4jeA3gt8IfiPX32gOoCQ5ACcDcILvBN8JvvMXMzWANL5RpYoBuCpU5WbJARiVGtndJZmSA0hXlJMjMwKypbNn8jWXLZO/DaUGMDK+U0bEdshwHXgaGgU+Anx4qwwObTHxtc0yILhJ+gc2Sj//BgO/j2+d9PGuBX8N+Fy9e6XC5+pdyw34HnzD7+40r76b5eq7GlefxJ9pwZ+ajV8Pfj349eDXg18Pfj349SMYQC7+oAx+A/gN4Ddw/Q3gN4DfAH6DBb+R628EvxH8RvAbOxsVN6YGAL6zo1GRkwE426vAd7bLPwBXmarUyO6yDMBdbKkou+QALNnS2c28LWXLHkFL5Q5hRBz82Hbwt8lQGhIFPgJ8GPjQZvA3yQBto/QPbpB+AfD9wPuA966h1dLbs8rAT8L3BP531zKFvxj8RQp/PvjzFL559Sa+efW/1oNfD349T359Cn+cBX9UBr8e/Hrw68GvB7+ez/168OvBrwe/Hvx68Ot5+uutAwDfiAE0cP0NDKCBATQwgAaF3/iLigE0gt/YQQV+Y6UZA3AYge8sV5VlDcCeGkC6YktFZukROLKypbNnRtBcyQG0pkKDGB7fJsNiW8HfIkNocBT8CPBh4EPAaxtM/OB66RtYK338wPtWg78KfK6eerqXg78MfOBdSwz47vyu7+Y0r/63JDxf9LpannwDvz6Jn4SfbMEf3zJ+Hfh14Ncl8Qem8Sss+OVJ/Hrw68Gv5/rrwa8Hv57rrwe/Hvx6E98YQAMDaAC/AfyGjkZFDeA3tDczBtDOyNFYoSo3Sw7AqNTIblSSKd8A0jmysqVKDqCljBHYWq65YQyLb5GhsST+ZhlMg6KbZGBkowwIAx8CXlsP/joTPwC8H3jfSuntTeKvMPB/dy8Ffwn4XL0rib8AfPPqM/iz0k++iT/Vgm9evYFfB34d+HWjCfw68OvAr+Pbfl0Ofh34deDXgV8Hfh34deDXgV8Hfh34deDXgV8Hfp0VXw2gHvx68Ot/UTGAevDrO5gZA6hUtTNyNFSo1AAay1SlRnajkkzOYktFORUYgMvefOkh2JqvpXEMjW+WIbFN4G+SQfpGGRjdIAMi4IeBDwGvrZW+wTXgrwIfeOrlWyG9vFy9Z5nCXww+8K6FGXznXPCB5+ediW/Cd1ZP/q/qyU/j14034DvWjcnBH94Uvxb8WvBrwa8Fvxb8WvBrwa8FvzaDX2bFp5I6BlAHfh34dVx/HfhG4NeBX9fRqKguOYD2qkoV+PUVqnJzAA1llkqN7A0lmRqLcyrKLjkAS7Z09kzNjsFWOHcrGhLfKINjG8HfIANpQHS99I+sk35h4EPAa6ulTxD8QBIfeN9yWiY9vcB7uHp3Eh94F/Cu+eDPU/jANwLPb/sMvgn/q3ryDfy6JP64PPhcfS34teDXgl8Lfm0r8WvBrwW/FnwjBlDLAGrBrwW/FvzazkbFteDXgl/bySyFbwR+XaWqnZGjzjIAozJVqZHdqMTMGEFxTkXZNTrS2bKyZ3I2l83M9YMNjm+QQbEk/noZoK+T/tG14K8BH3htFa2UP4LgB8D3A+9bCv4S8IH3LGIAKfx5BLxzDqXwZ4BvXn02/kQyrz4bf5R0qOXqa5viV6bwa/jCVwN+Dfg14NeAXwN+TW8Cv6aniqe/Bvwa8GvArwG/BvyaLioGUAN+zS9mxgA6GhXVgl/bXlWpAr9WDcCoXFWmKjWyG5WYGUMotlTUtAZHOltW9kyNzWUzc7ay3AEMiq+XgbF14K+V/voa6RdZLX3DwIeAT+JrK6R3kKsPgO8H37dYfvcC71kI/gLw51vwgXfOAn9mDr4J/6u6+mz8McTV1xbArwG/Bvyaga3A79UCftcc/NQAOqnAr+mgAr+mUtXOyFFboSpXlVkqNbIblWRGUFdsqahp9Y50tqzsmRqay2bW2MpyBzEwvlYGxNaAv1r6RVdJ38hK6RMGPrQC/OXSW1smvYLAB5YwAPB94HsXMID50t1twndzcfUuhe8EvnE6mVffFN+E76SuvmNtHvyaYWn4yppB2fjV4Ff3JfCrwa/ubVRWDX41+NU8/dXgV4NfDX71b0Yl1eBXg1/d2ai4Gvxq8Ks7qbj+auCN2qsqzZL4RhWqclWZqtTIblRilhxBbXFORU2rc6SzZWXPVN9ctkwNrcw6iAHx1dI/tkr66SulbxT8CPDh5QxgGfhLpZcGfHAxA1gkv/u5eh9X7wXfA77bhP/NlYSfmQcf+IZJ4JtX3zy+Cd++ZmhT/Grwq1vA/w7+d/C/g/8d/O/dVOB/B/87+N87q8D//osK/O8djYq+d1BZ8KvbGTmqK1TllspUpUZ2o5LMCGqKcyrKCfjaTLas7NnVFcqWXX0rS42hfxz8GPgMoE8U/AhXHwY/lMH/PbAQfK7eB7x3HvhzTXy3wnfNAB945zTwgW/k6hX+L03wzSe/o4LvYLn6LPxq8KtN/HZW/O/gfwf/e2+jsu/N4H8D/xv437qowP8G/rdfVJ1UOfhGlSrwjSpU5aoyS6VG9u8lZtWpii0V5clhjkBlS2dvWm2hbE2ra2XJIfSLgx9bIX10rj4KfGQpA1givUJcvcbVB8EPgO8H3we+d4508wDvngX+TBPfZeJ3dqbwufoG4BsUfL159Xnxa3Lwq/Pgfwf/ewH8b+B/A/8b+N/A/9ZNVQj/1yb4xd+AN2qvqlS1M3J8q1CVWypTlRrZjUrMjCEU51SUJ4c5ApUtnT1/+YZRY8tfbSvrG18ufWLL5A8d+OgSBrBYeoUXSc8Q8NoCBjBfegSA989lAOB7wfeA755pwHd1cfVJeOcU8Ln6xjz49T+I/z0P/jfwvyXh8+HTV/C/gv+1qwr8r+B/Bd4I/K+dVB2Nir52UIH/tVLVzsjxtcJSuarMUqmR3agkM4JvxTkV5clhxhBsWdmbL2sYtsLVtKI+cfBj4OvgR8GPgB8GPwS+Bn4Q/MAcBjBbuvmA985kAFy9W+G7FL5T4Tcq/AYFX6/g+YnXUcF3sDz57S3wlQY8fc/B/wb+tzz4X8H/Cv7X7ioTvzSF/wX8L51V4H/5RQX+l45GRV86qNqrKlXtjBxfKlTllspUpUZ2oxJzAOmKcyrKyZGV7Zs1e8ulB2FrueZG8kcc+NhiBrBIekUXSs8I8OH5DGCe9NC4+iD4AfD9VnwTvosLeNdk8E34XxuT8OPz49e1Al/Bp/G/5cH/miwP/hfwv4D/JQnfEr4awGfgjdqrKlXtjByfKyyVq8oslRrZjUrMERgV51SUJ0dWtmRfU9lb3zdb68s3jj/i4MfA18GPgh8BP6zwNfCDs8AH3jeDAXD1HvDdOfhOhd+Yg1//I/hJ+Bz8r+Cn4RX+F/C/dFdZ8D8nA/9zZxX4n4H/lKyTqqNR0SfwP7VXVaraGTmMKlTlqjJLpUZ2o5KcinMqyu5zMkdWNmtf7G3IZva1jaVG0Tu+UHrFFkhPHfjoPAYwV3qEgddmE/gB8P3g+8D3gu8B353En0TAOycQ8I3jwAe+YQz4wNeb8B3rTPgOtcNaid83g/81g1+ewv9i4pel8D+D/xn8JPynZOB/6qwC36gA/sdk7VWVqnZGjo8VqnJLZZZKjexGJZaK81TUtE+OrGzp7K3rcypb0760oV5x8GPzGQD4UfAj4IcUfhD8wHQGME26+oD3TgGfq3crfJcFv7EAfp3CrzXh2xs/8fLgW66+Cf6XJHwO/meF/wn8T3nwPwJvBP7HTqqORia8Bf9DpaqdkeNDhaVyVZmlUiO7UUlOxTkV5cmR6SPoWdnbGIiffrDkWHrGwY+Br4MfBT4yiwHMlG4aVx8EPwC+H3wf+J48+E4LfoPCr28O34QviG/A5+L/bvYZ/CT8p2Q5+B+7qEz8kjS+GsCHjirgjdqrcvDfJ6tQlVsqs1RqZDcqyak4p6I8ObKypfqQzN7GbE372IZ6xufK77E50kMHPwp+GPwQ+Br4QfAD4PvB94LvmcgAgHeNJ+CdY8EHvnE0+MA3jGwVfuonXrP4Xyz4nxX+pxz8j0n4HPwPvxoVf/hFlYP/Pll7VaWldkZp/HfllsoslRrZjUpyKs6pqECOrGxZ2TO9b022lvvQTL/HwY/NZgDgR8EPgx8CXwM/OIUBTOb6uXov+B7w3QrfBb5T4Tem8EcQ8HXDaKiJX6vwa3Lx++XB750f/1MKv5vZxxz8D8ny4L/vpAL/fQ7+u2SVqnZGjncVlhT+2zJLpensRiWWivNUlCdHVrYm2Qv3Ll+2Hys1jh5x8GPg6+BHpzOAaQxgqnTVwA+C7wffB743D77Tgt+Qiw987eBm8NWXva8W/C8WfAM+B/9jBr/0Q1cFb8F/D/77X1QW/Hd87r/roLLgv03WzsjxtsJSuSXg36QqNbIbleRUnFNRgRxZ2bKy/0A2s7c/WI/4TOkemyHddPAj4IfBD4GvgR8A3w++D3wP+G6F77LgN1rw63PxB6XxK1vE75WD3yOD/9GC/yEH/31nAz4L/10nVUcV8G+TtVdl4xe9YQBvKlTllpriO16Db1Riqbhpr4oK5MjKlpW9cK8LZWu5N83UPT6DAYCvgx8BPwx+CHxtEgMA3w++F3wP8O4x4APvGsUARmbwGyz4dQq/NolvwjfF75Mf/3MO/kcL/gcL/vsuKgv+u19UCv9tR5UF/02ySlW7dAb861TlZq/Kcio1shuV5FSc3ctkRXlyZGVrkr2N2bJ79QN1j4MfA1+fygDADyv8IPgB4P3jGAD4HvDdFnwn8I3DwR9m4tfnwa9J4vc3/gkdA/975vO+IufLnoH/KQ/+Bwv++xz8d78apfHfdlJZ8N90UPAK/3WqdkaOVxWWyi0p+JfJSo3sRiU5FWf3IllRgRxZ2bKy/0C2H8s6mm5x8GPg6+BHwA+Dr02QzsHxDAB8H/heC77Lgt8IfMPQDH5dK/C/tYD/sRX473Lw31rw33RUWfBftzfRX6VqZ5SGf5ms3FKZJfBfmNmNSnIqzu55sqI8OZpky8r+A9l+vm5x8GPg65MZAPgh8DXwg+AHxjIA8L2jGYCJ38kFvtOKD3z94Ax+rcKvSeL3y4Pfuxn87k3x31vw31nw3/6q4BX+mxz81x1M+FftLfD0sp2RiW7Bf5GqzJIF/3mykpyKm/asqECOrGxNsv9Atp/vtzj4MfCjE6VLBPwQ+Br4QfD94PvA94DvVvgu8J3gN4LfkMIfZNQEv7pvC/i/N8VPX70FPw3f2YA3U/hvLPivkwH/qoOCV72sVJn4RS8YwIsKlQX/eVlOpUYG/rOSPBVn97SoQKA/yc6Wlf0Hs/18v8XB17n86AQGAH4IfA38IPh+8L3ge8B358FvAL/egl+bB//7D+C/z4P/Ngf/jQU/Cf8qmQX/ZSqF/6JdujT+82TllkB/lqo0nf2ZGsBTa4A/ya0of48dWdmaZG97j5LZfr6u8UkMAPwo+JFxDAB8DfwA+H7wveB7FL4LfCf4jUMYgMKvB77Ogl+Twu+Tg9+rbfjvCuC/seC/7qTgTfzilx0s8PSiUqXwn7dT6Kpn5ZYs+E9L09mfJCvJSYE/tlaUv0eOJtmaZM/fw+aytb0Heeoa5+nXwY+CHwE/NIYBgB8A3w++F3y3wneB7wS/EfyGHPxaC361Bf/bT+C/teC/seAb8Bb8lxb8F6kU/vN26Uz0VBb8p2VmT5KVpjPwH5fkSaE/slaUv4eOrGzJHlizt637qWx/T13iE9QAwA+DHwJfG8UAwPeNYADgu4cxgBz8BuDrga+z4NdY8L9b8L/+BP4bC/7rXxS8wn9pwX9hwX9eqVL4z9pZ4OlpudmTcoVu6XFpOvtjNYBH1izoD1MVmT3IzdEk2/3c7M13r1C27O7+YF3i4OtcfxT8MPgh8IPgB8D3ge8B3w2+C3wn+I0mfvsUfh34tRb86gx+hRX/S/Zv/Dbhv87Bf2nBf5HEVwN4bsF/VmnAmyXR6UmFQrfgP7YG/CMzu5FCf5gK7Ae5WcDv5+bI7h7gWQF5t43dSWX7e+oSB1/n+o0BgK+BHwTfD74PfI/Cd4HvBL8R/IYB6vot+DU5+N9y8D9n45dZ8d8p/LcK/00O/qs8+C8s+M8t+M8s+E+TpeAV/mNrCv5RWRrewH9YaoI/yA3w+7lZwO9Zuutoks3aHYcFs4Vu58tmdusn6xwHXwc/yvUbAwA/CL4ffC/4HhO/gwt8J/iNwBsD6M8AwK818c3rB/+7Bf+riV+ehd8tD34XKW0J/6XCf2HBf67wn7XPwD+tNOGfJFPwj1Mp+EflCl0FuNED4I0U+H1rFvR7qZLQBQI4N1uq26ksoLda2c1kth/vRk6d4+Dr4EfBD3P9xgDA9w9lAOC7W8Cv7aOu34L/LQ/+pzz47wvgv6ZXzeA/z4P/VPWkXboMfIVCt+A/VD0oM+CN7oNvZIG/V2Ji381XEjpfgN+2dAvsJllBW9ENawrv+k90TfVrfDQDAD8Kfhh8jetXA+igBtBeDaDSGAD49eDX5eBXg/89B//LT+K/VPgv8uA/U/hpeAv+Ywv+Iwv+w3ILuup+aToD/55Cv5vKAn7HmsK+rbplzZHpJth5y0Wl663omj2D15quttCvcfD1kQwA/PBwBgB+AHwf+F7w3eC7uH4n+I3gN4BfD35dH2MAFTU5+N/A/6rwP1vwP7YevyQf/nMTv/hZDv4TC/5jhf+oItNDBf+g3IKeSuHfA/5uqQWd7qSyoN9W3Spq2s1UjuxugJ3qeqpCsM10NZUF70obulwgcwDgR8APga/x9AfA9/H0exS+C3yniV+ZD7+6lxpAHvxP/wL8p+0t8JVp+KJHyVLwFRb48hz4MgPdcdcsjX8npzR4blZw1Y0iA9voeiabtWupCuGqrjRXHsRLbehiTr/ER6YH0DEEvgZ+AHwf+B4LfiP4DX0t1w9+TR78rz3Mf+Wugd89g/8h81Ov9F0L+C8U/vOOaXgD/2kO/uNKC7zCT8I/qMjA3y+3oKvuZvAdd0ot4KpbJdngN61Zwem6NQV/LVMa/WqqFoAvW7qUr2YwL7Sh86pf4uDrXH9kmGUAgxgA+J4BDAB8Zz9jAO2MAYBfB34t+DW9jAGUfwf/2++W6+9uefpbif8yH37HbPwn7S3wOfhp+AoLvMpAT2Wip7LfLrWgW/Bv5nSjOA84XUtlgb9qZruSpxaBVRctXbDWDGZz/ZWnKmMA4OvgR8APgR/k+v1cv5cBuLl+NYB2jbn4vbPxv6Wuv7vl6c/+Z/XMp/9n8Ntn8NPw9MCCnwVfboEvy4J3JOFvlWbQb1pLgdP1VLngqqsqcHOzXVZdStVaZEvnrbWAWtWK/sypkzEA8CNDGAD4QfD94HvBd4Pv4vqd4DeAXw9+XW/L9YP/PQf/cw7+hxz8t23Af9rBAq/wHxXAv1+RA2/Bv6O6bcI7blnwrfA3SnLQ6VqqXHBrgF9WXTKzWbuYqjXIlv6yVGVvPeq5FjprqVN8WHoAHYwBgO/n6feC7wbfBX4j+A1/WAYAfg346QGA/7W7un6F/zEXv0vr8J+1At+AV/j3LaXhyzPoBnyZgZ7KfrM0B52ul+RBVzUBp8uqS47sLlrAL1hrBXRVgf5M1QbYZGdyOp2nTnHwda4/An6I61cDqPRYrl8NoKI+P37m+rsZA8jCf9/F8rmf/YWvJI3fqQl+cSvwi9LwFRl4K74Bb8G/aZaGv24pC1x1pbgp+iVrJrjRhUwG+HlrhS66APS5fP0AbqpTOZ20ZA4A/Ahf/DTwg1y/D3yPun4n+I3J6we/rpcxgHJjAOB/72G5/m6W6++qBtCl6Ze+tuI/UvgPKxU83W9n4hvwFvw75TnwZVnwjhvgJ8uCT2VFV13Og35RdaEoC91+3iyN/pelghddAPus6oyl1uCebKYTOR1XdYwPSQ+gfXIAAfB94HvAd4HvBL+ht3n9xgDAr8mDb1x/U/yCn/vN4T9uI/4dVRZ8WRa843oSvjQHna6WZMNfVl0qLoBuwT9v6S8zW1VOzWGfzYN9Ok+tQc6Hm69jOXWMg69z/WHwtQF5B1BhDAD8OoWvrr/sW3fL9Vs+9z90UQNoBf7zVuLfV6XhKzLwufg3y7Lg0/i58FdKsuEvWcqHfj5VNrq9yswEV51L1VZs1UlrbUC24h7N6UiesgcAfgB8H/hu8F1cfyP4DeDX98xcfzXX/727GkDy+n+zXH8e/Dd5vvQ1we/QFP9BK/Bv061yC3xZFryBf63Ucu0p+JKca0/BFxdAp79UVY7sssBVZx0/iK06oTpubz3ykQIdtnQop45x8HXwwwMyA/BmBlCRGkDy+mvBr+lhuX7wv/xmDCD99BsDsPwrePN97reE/7AZ/DsVGfi8+GUZ/GtmTeFLsuEvpuCLm0FPZYIbncuURj+j+mHsnFoL3RxyqoOWDqg6pAfQnwGAH+jLAMB3c/1O8BvN6y+v+90cQPr6u6UHkPzf0W96/Zl/Tj/7S19T/OKW8IEvysW/pcqCL8uCd1wtbQp/qSTn2i2dL86Gr7L0Z1ETdPtZswy6pULgzWKrjqqO2NsOnQ852f4CdYgPZAADjAFUJgfg5/q94LvAd4Lf2DMzgOT1V4OfGoBx/V3VALpYrj/zr+BN47/M81v/ieVzPx/+vVbgp+HLMvAp/CbwqrzwxXmuXcGfS5VBtwNuP52LrmoNeF7snA7b2wZdCHmfpb2W9qgBtI9y/WHwNa7f3yd7AA3g1yevv4cxgLLq1PX/Zrn+LvmffuP6O2U//Xnx27eMf7vCAt8MPvCOK0n80jzwJU3RDfjiZtDpbFEWujUTPKd86C2BH1YdspaD3dJFF0LO125Vh/gAYwCVagDt/OB7wHeB7+T6G35Xz39yAMnr75YeQPL/KldmAJ0LX39z3/gftbd84au04LdrHf61six4A/9yDr4BX1IAvrh5+DNFTeFBt2eBq447mqK3CZwOqg7YC2Pnu+jmkJPtsrTTUodYcgDgh7n+YJ/sAfD8lxsDAL+2u3n9xgCS19/V+L/MVfDpV9ef/fRn8ItbgV+UDz/r6pviO5L4TeBLCsAXq8/23GtX8KeLmqCnykZXNXflrQKn/al+EDsf9I4Cbaf2sf7mAEJqAL7eDAB8F9ffCH59D3MAyeuvBv/7b5br75K+fuN/T/+d+b+2ZV5/HvxnzXzps+LfycG/mcIvz8a/WpYF77hU2hTeip8Fr2py7Sl4OlXUBN7eBF111NE69ILgqn2qtmDvbAF7u6Vtqq2qzADAD/5hDKDCbQ6gPDWA5PXXdDMHkLz+r10tA8jz9L9Ofe7n/LN7hb70tQX/Whvwz6vywhdnw5/OgT9ZlIVuP54pG52OOLLRm7vyguCqPfafu+xcaCv2ljy1j4Ef7WsZAPhurt8JfmOP7AEkr/+bwv+s8Ft7/blP/8NWPPst4St4Az8vfEkB+OIW4IvywtuboKsKoee78rzglnbb8193a7C3toC9WbXJUmYA4Ae5fusAGpLPP/i13SzPf3IAXTLX/yEH/3Whpz/P5376d34ufkUG/3oO/pV8+KUt46fhi5uHP1GUDX9M1QRddcjxc+i7VbtUhcCbe8Zbi71RtcFS+xj4Ua4/OYAAA/AmBwC+s0fOANT1pwfQ2RhA9vV3Utdv+RdzNvnWn/Ol767l6W8rPvCOC6V54EsKwNPp4mbg6XhRBv6o6ohZNrqqNeh7WkKnHal+4Lpbi51qvaXKrAGA7+X6XakBgF8Hfs1vlgF0ST//qf/TbCXvLNf/Kv/T3+LnfnP4V/9m/ILwRRn4I5aaoKvaim4Fz0JXWdHbct2twV5naa1qjU3+HwuefjlXE4+yAAAAAElFTkSuQmCC", "openPBREnvironmentBRDFTexture", "OpenPBREnvironmentBRDFTexture");
    var sO = pO(38170),
      HO = pO(35632),
      RO = pO(38216),
      SO = pO(38378),
      JO = pO(38456);
    class cK extends SO.e {
      constructor() {
        super(...arguments), this.BRDF_V_HEIGHT_CORRELATED = !1, this.MS_BRDF_ENERGY_CONSERVATION = !1, this.SPHERICAL_HARMONICS = !1, this.SPECULAR_GLOSSINESS_ENERGY_CONSERVATION = !1, this.MIX_IBL_RADIANCE_WITH_IRRADIANCE = !0, this.LEGACY_SPECULAR_ENERGY_CONSERVATION = !1, this.BASE_DIFFUSE_MODEL = 0, this.DIELECTRIC_SPECULAR_MODEL = 0, this.CONDUCTOR_SPECULAR_MODEL = 0
      }
    }
    let BO = (() => {
      var OO, KO, pO, XO, bK, eO, lO, vK, CO, hO;
      let DO, MO, aK, oO, FO, VO, LO, QO, zK, AO = JO.c,
        fO = [],
        dO = [],
        TO = [],
        NO = [],
        IO = [],
        uO = [],
        EO = [],
        jK = [],
        YO = [],
        wO = [],
        iK = [],
        rK = [],
        PO = [],
        mK = [],
        sO = [],
        HO = [],
        RO = [],
        SO = [];
      return OO = class extends AO {
        get useEnergyConservation() {
          return (0, yK.b)(this, KO, "f")
        }
        set useEnergyConservation(OO) {
          (0, yK.e)(this, KO, OO, "f")
        }
        get useSmithVisibilityHeightCorrelated() {
          return (0, yK.b)(this, pO, "f")
        }
        set useSmithVisibilityHeightCorrelated(OO) {
          (0, yK.e)(this, pO, OO, "f")
        }
        get useSphericalHarmonics() {
          return (0, yK.b)(this, XO, "f")
        }
        set useSphericalHarmonics(OO) {
          (0, yK.e)(this, XO, OO, "f")
        }
        get useSpecularGlossinessInputEnergyConservation() {
          return (0, yK.b)(this, bK, "f")
        }
        set useSpecularGlossinessInputEnergyConservation(OO) {
          (0, yK.e)(this, bK, OO, "f")
        }
        get mixIblRadianceWithIrradiance() {
          return (0, yK.b)(this, eO, "f")
        }
        set mixIblRadianceWithIrradiance(OO) {
          (0, yK.e)(this, eO, OO, "f")
        }
        get useLegacySpecularEnergyConservation() {
          return (0, yK.b)(this, lO, "f")
        }
        set useLegacySpecularEnergyConservation(OO) {
          (0, yK.e)(this, lO, OO, "f")
        }
        get baseDiffuseModel() {
          return (0, yK.b)(this, vK, "f")
        }
        set baseDiffuseModel(OO) {
          (0, yK.e)(this, vK, OO, "f")
        }
        get dielectricSpecularModel() {
          return (0, yK.b)(this, CO, "f")
        }
        set dielectricSpecularModel(OO) {
          (0, yK.e)(this, CO, OO, "f")
        }
        get conductorSpecularModel() {
          return (0, yK.b)(this, hO, "f")
        }
        set conductorSpecularModel(OO) {
          (0, yK.e)(this, hO, OO, "f")
        }
        _markAllSubMeshesAsMiscDirty() {
          this._internalMarkAllSubMeshesAsMiscDirty()
        }
        isCompatible() {
          return !0
        }
        constructor(DO) {
          let MO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          super(DO, "PBRBRDF", 90, new cK, MO), this._useEnergyConservation = OO.DEFAULT_USE_ENERGY_CONSERVATION, KO.set(this, (0, yK.i)(this, fO, OO.DEFAULT_USE_ENERGY_CONSERVATION)), this._useSmithVisibilityHeightCorrelated = ((0, yK.i)(this, dO), OO.DEFAULT_USE_SMITH_VISIBILITY_HEIGHT_CORRELATED), pO.set(this, (0, yK.i)(this, TO, OO.DEFAULT_USE_SMITH_VISIBILITY_HEIGHT_CORRELATED)), this._useSphericalHarmonics = ((0, yK.i)(this, NO), OO.DEFAULT_USE_SPHERICAL_HARMONICS), XO.set(this, (0, yK.i)(this, IO, OO.DEFAULT_USE_SPHERICAL_HARMONICS)), this._useSpecularGlossinessInputEnergyConservation = ((0, yK.i)(this, uO), OO.DEFAULT_USE_SPECULAR_GLOSSINESS_INPUT_ENERGY_CONSERVATION), bK.set(this, (0, yK.i)(this, EO, OO.DEFAULT_USE_SPECULAR_GLOSSINESS_INPUT_ENERGY_CONSERVATION)), this._mixIblRadianceWithIrradiance = ((0, yK.i)(this, jK), OO.DEFAULT_MIX_IBL_RADIANCE_WITH_IRRADIANCE), eO.set(this, (0, yK.i)(this, YO, OO.DEFAULT_MIX_IBL_RADIANCE_WITH_IRRADIANCE)), this._useLegacySpecularEnergyConservation = ((0, yK.i)(this, wO), OO.DEFAULT_USE_LEGACY_SPECULAR_ENERGY_CONSERVATION), lO.set(this, (0, yK.i)(this, iK, OO.DEFAULT_USE_LEGACY_SPECULAR_ENERGY_CONSERVATION)), this._baseDiffuseModel = ((0, yK.i)(this, rK), OO.DEFAULT_DIFFUSE_MODEL), vK.set(this, (0, yK.i)(this, PO, OO.DEFAULT_DIFFUSE_MODEL)), this._dielectricSpecularModel = ((0, yK.i)(this, mK), OO.DEFAULT_DIELECTRIC_SPECULAR_MODEL), CO.set(this, (0, yK.i)(this, sO, OO.DEFAULT_DIELECTRIC_SPECULAR_MODEL)), this._conductorSpecularModel = ((0, yK.i)(this, HO), OO.DEFAULT_CONDUCTOR_SPECULAR_MODEL), hO.set(this, (0, yK.i)(this, RO, OO.DEFAULT_CONDUCTOR_SPECULAR_MODEL)), this._internalMarkAllSubMeshesAsMiscDirty = (0, yK.i)(this, SO), this._internalMarkAllSubMeshesAsMiscDirty = DO._dirtyCallbacks[16], this._enable(!0)
        }
        prepareDefines(OO) {
          OO.BRDF_V_HEIGHT_CORRELATED = this._useSmithVisibilityHeightCorrelated, OO.MS_BRDF_ENERGY_CONSERVATION = this._useEnergyConservation && this._useSmithVisibilityHeightCorrelated, OO.SPHERICAL_HARMONICS = this._useSphericalHarmonics, OO.SPECULAR_GLOSSINESS_ENERGY_CONSERVATION = this._useSpecularGlossinessInputEnergyConservation, OO.MIX_IBL_RADIANCE_WITH_IRRADIANCE = this._mixIblRadianceWithIrradiance && !this._material._disableLighting, OO.LEGACY_SPECULAR_ENERGY_CONSERVATION = this._useLegacySpecularEnergyConservation, OO.BASE_DIFFUSE_MODEL = this._baseDiffuseModel, OO.DIELECTRIC_SPECULAR_MODEL = this._dielectricSpecularModel, OO.CONDUCTOR_SPECULAR_MODEL = this._conductorSpecularModel
        }
        getClassName() {
          return "PBRBRDFConfiguration"
        }
      }, KO = new WeakMap, pO = new WeakMap, XO = new WeakMap, bK = new WeakMap, eO = new WeakMap, lO = new WeakMap, vK = new WeakMap, CO = new WeakMap, hO = new WeakMap, (() => {
        const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(AO[Symbol.metadata] ?? null) : void 0;
        DO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], MO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], aK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], oO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], FO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], VO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], LO = [(0, gK.M)("baseDiffuseModel"), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], QO = [(0, gK.M)("dielectricSpecularModel"), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], zK = [(0, gK.M)("conductorSpecularModel"), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], (0, yK.f)(OO, null, DO, {
          kind: "accessor",
          name: "useEnergyConservation",
          static: !1,
          private: !1,
          access: {
            has: OO => "useEnergyConservation" in OO,
            get: OO => OO.useEnergyConservation,
            set: (OO, KO) => {
              OO.useEnergyConservation = KO
            }
          },
          metadata: KO
        }, fO, dO), (0, yK.f)(OO, null, MO, {
          kind: "accessor",
          name: "useSmithVisibilityHeightCorrelated",
          static: !1,
          private: !1,
          access: {
            has: OO => "useSmithVisibilityHeightCorrelated" in OO,
            get: OO => OO.useSmithVisibilityHeightCorrelated,
            set: (OO, KO) => {
              OO.useSmithVisibilityHeightCorrelated = KO
            }
          },
          metadata: KO
        }, TO, NO), (0, yK.f)(OO, null, aK, {
          kind: "accessor",
          name: "useSphericalHarmonics",
          static: !1,
          private: !1,
          access: {
            has: OO => "useSphericalHarmonics" in OO,
            get: OO => OO.useSphericalHarmonics,
            set: (OO, KO) => {
              OO.useSphericalHarmonics = KO
            }
          },
          metadata: KO
        }, IO, uO), (0, yK.f)(OO, null, oO, {
          kind: "accessor",
          name: "useSpecularGlossinessInputEnergyConservation",
          static: !1,
          private: !1,
          access: {
            has: OO => "useSpecularGlossinessInputEnergyConservation" in OO,
            get: OO => OO.useSpecularGlossinessInputEnergyConservation,
            set: (OO, KO) => {
              OO.useSpecularGlossinessInputEnergyConservation = KO
            }
          },
          metadata: KO
        }, EO, jK), (0, yK.f)(OO, null, FO, {
          kind: "accessor",
          name: "mixIblRadianceWithIrradiance",
          static: !1,
          private: !1,
          access: {
            has: OO => "mixIblRadianceWithIrradiance" in OO,
            get: OO => OO.mixIblRadianceWithIrradiance,
            set: (OO, KO) => {
              OO.mixIblRadianceWithIrradiance = KO
            }
          },
          metadata: KO
        }, YO, wO), (0, yK.f)(OO, null, VO, {
          kind: "accessor",
          name: "useLegacySpecularEnergyConservation",
          static: !1,
          private: !1,
          access: {
            has: OO => "useLegacySpecularEnergyConservation" in OO,
            get: OO => OO.useLegacySpecularEnergyConservation,
            set: (OO, KO) => {
              OO.useLegacySpecularEnergyConservation = KO
            }
          },
          metadata: KO
        }, iK, rK), (0, yK.f)(OO, null, LO, {
          kind: "accessor",
          name: "baseDiffuseModel",
          static: !1,
          private: !1,
          access: {
            has: OO => "baseDiffuseModel" in OO,
            get: OO => OO.baseDiffuseModel,
            set: (OO, KO) => {
              OO.baseDiffuseModel = KO
            }
          },
          metadata: KO
        }, PO, mK), (0, yK.f)(OO, null, QO, {
          kind: "accessor",
          name: "dielectricSpecularModel",
          static: !1,
          private: !1,
          access: {
            has: OO => "dielectricSpecularModel" in OO,
            get: OO => OO.dielectricSpecularModel,
            set: (OO, KO) => {
              OO.dielectricSpecularModel = KO
            }
          },
          metadata: KO
        }, sO, HO), (0, yK.f)(OO, null, zK, {
          kind: "accessor",
          name: "conductorSpecularModel",
          static: !1,
          private: !1,
          access: {
            has: OO => "conductorSpecularModel" in OO,
            get: OO => OO.conductorSpecularModel,
            set: (OO, KO) => {
              OO.conductorSpecularModel = KO
            }
          },
          metadata: KO
        }, RO, SO), KO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: KO
        })
      })(), OO.DEFAULT_USE_ENERGY_CONSERVATION = !0, OO.DEFAULT_USE_SMITH_VISIBILITY_HEIGHT_CORRELATED = !0, OO.DEFAULT_USE_SPHERICAL_HARMONICS = !0, OO.DEFAULT_USE_SPECULAR_GLOSSINESS_INPUT_ENERGY_CONSERVATION = !0, OO.DEFAULT_MIX_IBL_RADIANCE_WITH_IRRADIANCE = !0, OO.DEFAULT_USE_LEGACY_SPECULAR_ENERGY_CONSERVATION = !0, OO.DEFAULT_DIFFUSE_MODEL = 0, OO.DEFAULT_DIELECTRIC_SPECULAR_MODEL = 0, OO.DEFAULT_CONDUCTOR_SPECULAR_MODEL = 0, OO
    })();
    var ZO = pO(38363),
      GO = pO(35688),
      qK = pO(38371),
      xK = pO(38191),
      nO = pO(38447),
      WO = pO(38439),
      tK = pO(38449),
      kK = pO(38424);
    class UO extends SO.e {
      constructor() {
        super(...arguments), this.CLEARCOAT = !1, this.CLEARCOAT_DEFAULTIOR = !1, this.CLEARCOAT_TEXTURE = !1, this.CLEARCOAT_TEXTURE_ROUGHNESS = !1, this.CLEARCOAT_TEXTUREDIRECTUV = 0, this.CLEARCOAT_TEXTURE_ROUGHNESSDIRECTUV = 0, this.CLEARCOAT_BUMP = !1, this.CLEARCOAT_BUMPDIRECTUV = 0, this.CLEARCOAT_USE_ROUGHNESS_FROM_MAINTEXTURE = !1, this.CLEARCOAT_REMAP_F0 = !1, this.CLEARCOAT_TINT = !1, this.CLEARCOAT_TINT_TEXTURE = !1, this.CLEARCOAT_TINT_TEXTUREDIRECTUV = 0, this.CLEARCOAT_TINT_GAMMATEXTURE = !1
      }
    }
    let OK = (() => {
      var OO, KO, pO, XO, bK, eO, lO, vK, CO, hO;
      let DO, MO, aK, oO, FO, VO, LO, QO, zK, AO, fO, dO, TO, NO, IO = JO.c,
        uO = [],
        EO = [],
        jK = [],
        YO = [],
        wO = [],
        iK = [],
        rK = [],
        PO = [],
        mK = [],
        sO = [],
        HO = [],
        RO = [],
        SO = [],
        cK = [],
        BO = [],
        ZO = [],
        qK = [],
        xK = [],
        nO = [],
        tK = [],
        OK = [],
        KK = [],
        pK = [],
        XK = [],
        bp = [],
        eK = [],
        lK = [],
        vp = [];
      return OO = class extends IO {
        get isEnabled() {
          return (0, yK.b)(this, KO, "f")
        }
        set isEnabled(OO) {
          (0, yK.e)(this, KO, OO, "f")
        }
        get indexOfRefraction() {
          return (0, yK.b)(this, pO, "f")
        }
        set indexOfRefraction(OO) {
          (0, yK.e)(this, pO, OO, "f")
        }
        get texture() {
          return (0, yK.b)(this, XO, "f")
        }
        set texture(OO) {
          (0, yK.e)(this, XO, OO, "f")
        }
        get useRoughnessFromMainTexture() {
          return (0, yK.b)(this, bK, "f")
        }
        set useRoughnessFromMainTexture(OO) {
          (0, yK.e)(this, bK, OO, "f")
        }
        get textureRoughness() {
          return (0, yK.b)(this, eO, "f")
        }
        set textureRoughness(OO) {
          (0, yK.e)(this, eO, OO, "f")
        }
        get remapF0OnInterfaceChange() {
          return (0, yK.b)(this, lO, "f")
        }
        set remapF0OnInterfaceChange(OO) {
          (0, yK.e)(this, lO, OO, "f")
        }
        get bumpTexture() {
          return (0, yK.b)(this, vK, "f")
        }
        set bumpTexture(OO) {
          (0, yK.e)(this, vK, OO, "f")
        }
        get isTintEnabled() {
          return (0, yK.b)(this, CO, "f")
        }
        set isTintEnabled(OO) {
          (0, yK.e)(this, CO, OO, "f")
        }
        get tintTexture() {
          return (0, yK.b)(this, hO, "f")
        }
        set tintTexture(OO) {
          (0, yK.e)(this, hO, OO, "f")
        }
        _markAllSubMeshesAsTexturesDirty() {
          this._enable(this._isEnabled), this._internalMarkAllSubMeshesAsTexturesDirty()
        }
        isCompatible() {
          return !0
        }
        constructor(DO) {
          let MO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          super(DO, "PBRClearCoat", 100, new UO, MO), this._isEnabled = !1, KO.set(this, (0, yK.i)(this, uO, !1)), this.intensity = ((0, yK.i)(this, EO), (0, yK.i)(this, jK, 1)), this.roughness = ((0, yK.i)(this, YO), (0, yK.i)(this, wO, 0)), this._indexOfRefraction = ((0, yK.i)(this, iK), OO._DefaultIndexOfRefraction), pO.set(this, (0, yK.i)(this, rK, OO._DefaultIndexOfRefraction)), this._texture = ((0, yK.i)(this, PO), null), XO.set(this, (0, yK.i)(this, mK, null)), this._useRoughnessFromMainTexture = ((0, yK.i)(this, sO), !0), bK.set(this, (0, yK.i)(this, HO, !0)), this._textureRoughness = ((0, yK.i)(this, RO), null), eO.set(this, (0, yK.i)(this, SO, null)), this._remapF0OnInterfaceChange = ((0, yK.i)(this, cK), !0), lO.set(this, (0, yK.i)(this, BO, !0)), this._bumpTexture = ((0, yK.i)(this, ZO), null), vK.set(this, (0, yK.i)(this, qK, null)), this._isTintEnabled = ((0, yK.i)(this, xK), !1), CO.set(this, (0, yK.i)(this, nO, !1)), this.tintColor = ((0, yK.i)(this, tK), (0, yK.i)(this, OK, GO.e.White())), this.tintColorAtDistance = ((0, yK.i)(this, KK), (0, yK.i)(this, pK, 1)), this.tintThickness = ((0, yK.i)(this, XK), (0, yK.i)(this, bp, 1)), this._tintTexture = ((0, yK.i)(this, eK), null), hO.set(this, (0, yK.i)(this, lK, null)), this._internalMarkAllSubMeshesAsTexturesDirty = (0, yK.i)(this, vp), this._internalMarkAllSubMeshesAsTexturesDirty = DO._dirtyCallbacks[1]
        }
        isReadyForSubMesh(OO, KO, pO) {
          if (!this._isEnabled) return !0;
          const XO = this._material._disableBumpMap;
          if (OO._areTexturesDirty && KO.texturesEnabled) {
            if (this._texture && WO.e.ClearCoatTextureEnabled && !this._texture.isReadyOrNotBlocking()) return !1;
            if (this._textureRoughness && WO.e.ClearCoatTextureEnabled && !this._textureRoughness.isReadyOrNotBlocking()) return !1;
            if (pO.getCaps().standardDerivatives && this._bumpTexture && WO.e.ClearCoatBumpTextureEnabled && !XO && !this._bumpTexture.isReady()) return !1;
            if (this._isTintEnabled && this._tintTexture && WO.e.ClearCoatTintTextureEnabled && !this._tintTexture.isReadyOrNotBlocking()) return !1
          }
          return !0
        }
        prepareDefinesBeforeAttributes(KO, pO) {
          this._isEnabled ? (KO.CLEARCOAT = !0, KO.CLEARCOAT_USE_ROUGHNESS_FROM_MAINTEXTURE = this._useRoughnessFromMainTexture, KO.CLEARCOAT_REMAP_F0 = this._remapF0OnInterfaceChange, KO._areTexturesDirty && pO.texturesEnabled && (this._texture && WO.e.ClearCoatTextureEnabled ? (0, kK.bb)(this._texture, KO, "CLEARCOAT_TEXTURE") : KO.CLEARCOAT_TEXTURE = !1, this._textureRoughness && WO.e.ClearCoatTextureEnabled ? (0, kK.bb)(this._textureRoughness, KO, "CLEARCOAT_TEXTURE_ROUGHNESS") : KO.CLEARCOAT_TEXTURE_ROUGHNESS = !1, this._bumpTexture && WO.e.ClearCoatBumpTextureEnabled ? (0, kK.bb)(this._bumpTexture, KO, "CLEARCOAT_BUMP") : KO.CLEARCOAT_BUMP = !1, KO.CLEARCOAT_DEFAULTIOR = this._indexOfRefraction === OO._DefaultIndexOfRefraction, this._isTintEnabled ? (KO.CLEARCOAT_TINT = !0, this._tintTexture && WO.e.ClearCoatTintTextureEnabled ? ((0, kK.bb)(this._tintTexture, KO, "CLEARCOAT_TINT_TEXTURE"), KO.CLEARCOAT_TINT_GAMMATEXTURE = this._tintTexture.gammaSpace) : KO.CLEARCOAT_TINT_TEXTURE = !1) : (KO.CLEARCOAT_TINT = !1, KO.CLEARCOAT_TINT_TEXTURE = !1))) : (KO.CLEARCOAT = !1, KO.CLEARCOAT_TEXTURE = !1, KO.CLEARCOAT_TEXTURE_ROUGHNESS = !1, KO.CLEARCOAT_BUMP = !1, KO.CLEARCOAT_TINT = !1, KO.CLEARCOAT_TINT_TEXTURE = !1, KO.CLEARCOAT_USE_ROUGHNESS_FROM_MAINTEXTURE = !1, KO.CLEARCOAT_DEFAULTIOR = !1, KO.CLEARCOAT_TEXTUREDIRECTUV = 0, KO.CLEARCOAT_TEXTURE_ROUGHNESSDIRECTUV = 0, KO.CLEARCOAT_BUMPDIRECTUV = 0, KO.CLEARCOAT_REMAP_F0 = !1, KO.CLEARCOAT_TINT_TEXTUREDIRECTUV = 0, KO.CLEARCOAT_TINT_GAMMATEXTURE = !1)
        }
        bindForSubMesh(OO, KO, pO, XO) {
          if (!this._isEnabled) return;
          const bK = XO.materialDefines,
            eO = this._material.isFrozen,
            lO = this._material._disableBumpMap,
            vK = this._material._invertNormalMapX,
            CO = this._material._invertNormalMapY;
          if (!OO.useUbo || !eO || !OO.isSync) {
            (this._texture || this._textureRoughness) && WO.e.ClearCoatTextureEnabled && (OO.updateFloat4("vClearCoatInfos", this._texture?.coordinatesIndex ?? 0, this._texture?.level ?? 0, this._textureRoughness?.coordinatesIndex ?? 0, this._textureRoughness?.level ?? 0), this._texture && (0, kK.B)(this._texture, OO, "clearCoat"), this._textureRoughness && !bK.CLEARCOAT_USE_ROUGHNESS_FROM_MAINTEXTURE && (0, kK.B)(this._textureRoughness, OO, "clearCoatRoughness")), this._bumpTexture && pO.getCaps().standardDerivatives && WO.e.ClearCoatTextureEnabled && !lO && (OO.updateFloat2("vClearCoatBumpInfos", this._bumpTexture.coordinatesIndex, this._bumpTexture.level), (0, kK.B)(this._bumpTexture, OO, "clearCoatBump"), KO._mirroredCameraPosition ? OO.updateFloat2("vClearCoatTangentSpaceParams", vK ? 1 : -1, CO ? 1 : -1) : OO.updateFloat2("vClearCoatTangentSpaceParams", vK ? -1 : 1, CO ? -1 : 1)), this._tintTexture && WO.e.ClearCoatTintTextureEnabled && (OO.updateFloat2("vClearCoatTintInfos", this._tintTexture.coordinatesIndex, this._tintTexture.level), (0, kK.B)(this._tintTexture, OO, "clearCoatTint")), OO.updateFloat2("vClearCoatParams", this.intensity, this.roughness);
            const XO = 1 - this._indexOfRefraction,
              eO = 1 + this._indexOfRefraction,
              hO = Math.pow(-XO / eO, 2),
              DO = 1 / this._indexOfRefraction;
            OO.updateFloat4("vClearCoatRefractionParams", hO, DO, XO, eO), this._isTintEnabled && (OO.updateFloat4("vClearCoatTintParams", this.tintColor.r, this.tintColor.g, this.tintColor.b, Math.max(1e-5, this.tintThickness)), OO.updateFloat("clearCoatColorAtDistance", Math.max(1e-5, this.tintColorAtDistance)))
          }
          KO.texturesEnabled && (this._texture && WO.e.ClearCoatTextureEnabled && OO.setTexture("clearCoatSampler", this._texture), this._textureRoughness && !bK.CLEARCOAT_USE_ROUGHNESS_FROM_MAINTEXTURE && WO.e.ClearCoatTextureEnabled && OO.setTexture("clearCoatRoughnessSampler", this._textureRoughness), this._bumpTexture && pO.getCaps().standardDerivatives && WO.e.ClearCoatBumpTextureEnabled && !lO && OO.setTexture("clearCoatBumpSampler", this._bumpTexture), this._isTintEnabled && this._tintTexture && WO.e.ClearCoatTintTextureEnabled && OO.setTexture("clearCoatTintSampler", this._tintTexture))
        }
        hasTexture(OO) {
          return this._texture === OO || (this._textureRoughness === OO || (this._bumpTexture === OO || this._tintTexture === OO))
        }
        getActiveTextures(OO) {
          this._texture && OO.push(this._texture), this._textureRoughness && OO.push(this._textureRoughness), this._bumpTexture && OO.push(this._bumpTexture), this._tintTexture && OO.push(this._tintTexture)
        }
        getAnimatables(OO) {
          this._texture && this._texture.animations && this._texture.animations.length > 0 && OO.push(this._texture), this._textureRoughness && this._textureRoughness.animations && this._textureRoughness.animations.length > 0 && OO.push(this._textureRoughness), this._bumpTexture && this._bumpTexture.animations && this._bumpTexture.animations.length > 0 && OO.push(this._bumpTexture), this._tintTexture && this._tintTexture.animations && this._tintTexture.animations.length > 0 && OO.push(this._tintTexture)
        }
        dispose(OO) {
          OO && (this._texture?.dispose(), this._textureRoughness?.dispose(), this._bumpTexture?.dispose(), this._tintTexture?.dispose())
        }
        getClassName() {
          return "PBRClearCoatConfiguration"
        }
        addFallbacks(OO, KO, pO) {
          return OO.CLEARCOAT_BUMP && KO.addFallback(pO++, "CLEARCOAT_BUMP"), OO.CLEARCOAT_TINT && KO.addFallback(pO++, "CLEARCOAT_TINT"), OO.CLEARCOAT && KO.addFallback(pO++, "CLEARCOAT"), pO
        }
        getSamplers(OO) {
          OO.push("clearCoatSampler", "clearCoatRoughnessSampler", "clearCoatBumpSampler", "clearCoatTintSampler")
        }
        getUniforms() {
          return {
            ubo: [{
              name: "vClearCoatParams",
              size: 2,
              type: "vec2"
            }, {
              name: "vClearCoatRefractionParams",
              size: 4,
              type: "vec4"
            }, {
              name: "vClearCoatInfos",
              size: 4,
              type: "vec4"
            }, {
              name: "clearCoatMatrix",
              size: 16,
              type: "mat4"
            }, {
              name: "clearCoatRoughnessMatrix",
              size: 16,
              type: "mat4"
            }, {
              name: "vClearCoatBumpInfos",
              size: 2,
              type: "vec2"
            }, {
              name: "vClearCoatTangentSpaceParams",
              size: 2,
              type: "vec2"
            }, {
              name: "clearCoatBumpMatrix",
              size: 16,
              type: "mat4"
            }, {
              name: "vClearCoatTintParams",
              size: 4,
              type: "vec4"
            }, {
              name: "clearCoatColorAtDistance",
              size: 1,
              type: "float"
            }, {
              name: "vClearCoatTintInfos",
              size: 2,
              type: "vec2"
            }, {
              name: "clearCoatTintMatrix",
              size: 16,
              type: "mat4"
            }]
          }
        }
      }, KO = new WeakMap, pO = new WeakMap, XO = new WeakMap, bK = new WeakMap, eO = new WeakMap, lO = new WeakMap, vK = new WeakMap, CO = new WeakMap, hO = new WeakMap, (() => {
        const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(IO[Symbol.metadata] ?? null) : void 0;
        DO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], MO = [(0, gK.M)()], aK = [(0, gK.M)()], oO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], FO = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], VO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], LO = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], QO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], zK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], AO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], fO = [(0, gK.r)()], dO = [(0, gK.M)()], TO = [(0, gK.M)()], NO = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], (0, yK.f)(OO, null, DO, {
          kind: "accessor",
          name: "isEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isEnabled" in OO,
            get: OO => OO.isEnabled,
            set: (OO, KO) => {
              OO.isEnabled = KO
            }
          },
          metadata: KO
        }, uO, EO), (0, yK.f)(OO, null, oO, {
          kind: "accessor",
          name: "indexOfRefraction",
          static: !1,
          private: !1,
          access: {
            has: OO => "indexOfRefraction" in OO,
            get: OO => OO.indexOfRefraction,
            set: (OO, KO) => {
              OO.indexOfRefraction = KO
            }
          },
          metadata: KO
        }, rK, PO), (0, yK.f)(OO, null, FO, {
          kind: "accessor",
          name: "texture",
          static: !1,
          private: !1,
          access: {
            has: OO => "texture" in OO,
            get: OO => OO.texture,
            set: (OO, KO) => {
              OO.texture = KO
            }
          },
          metadata: KO
        }, mK, sO), (0, yK.f)(OO, null, VO, {
          kind: "accessor",
          name: "useRoughnessFromMainTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "useRoughnessFromMainTexture" in OO,
            get: OO => OO.useRoughnessFromMainTexture,
            set: (OO, KO) => {
              OO.useRoughnessFromMainTexture = KO
            }
          },
          metadata: KO
        }, HO, RO), (0, yK.f)(OO, null, LO, {
          kind: "accessor",
          name: "textureRoughness",
          static: !1,
          private: !1,
          access: {
            has: OO => "textureRoughness" in OO,
            get: OO => OO.textureRoughness,
            set: (OO, KO) => {
              OO.textureRoughness = KO
            }
          },
          metadata: KO
        }, SO, cK), (0, yK.f)(OO, null, QO, {
          kind: "accessor",
          name: "remapF0OnInterfaceChange",
          static: !1,
          private: !1,
          access: {
            has: OO => "remapF0OnInterfaceChange" in OO,
            get: OO => OO.remapF0OnInterfaceChange,
            set: (OO, KO) => {
              OO.remapF0OnInterfaceChange = KO
            }
          },
          metadata: KO
        }, BO, ZO), (0, yK.f)(OO, null, zK, {
          kind: "accessor",
          name: "bumpTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "bumpTexture" in OO,
            get: OO => OO.bumpTexture,
            set: (OO, KO) => {
              OO.bumpTexture = KO
            }
          },
          metadata: KO
        }, qK, xK), (0, yK.f)(OO, null, AO, {
          kind: "accessor",
          name: "isTintEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isTintEnabled" in OO,
            get: OO => OO.isTintEnabled,
            set: (OO, KO) => {
              OO.isTintEnabled = KO
            }
          },
          metadata: KO
        }, nO, tK), (0, yK.f)(OO, null, NO, {
          kind: "accessor",
          name: "tintTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "tintTexture" in OO,
            get: OO => OO.tintTexture,
            set: (OO, KO) => {
              OO.tintTexture = KO
            }
          },
          metadata: KO
        }, lK, vp), (0, yK.f)(null, null, MO, {
          kind: "field",
          name: "intensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "intensity" in OO,
            get: OO => OO.intensity,
            set: (OO, KO) => {
              OO.intensity = KO
            }
          },
          metadata: KO
        }, jK, YO), (0, yK.f)(null, null, aK, {
          kind: "field",
          name: "roughness",
          static: !1,
          private: !1,
          access: {
            has: OO => "roughness" in OO,
            get: OO => OO.roughness,
            set: (OO, KO) => {
              OO.roughness = KO
            }
          },
          metadata: KO
        }, wO, iK), (0, yK.f)(null, null, fO, {
          kind: "field",
          name: "tintColor",
          static: !1,
          private: !1,
          access: {
            has: OO => "tintColor" in OO,
            get: OO => OO.tintColor,
            set: (OO, KO) => {
              OO.tintColor = KO
            }
          },
          metadata: KO
        }, OK, KK), (0, yK.f)(null, null, dO, {
          kind: "field",
          name: "tintColorAtDistance",
          static: !1,
          private: !1,
          access: {
            has: OO => "tintColorAtDistance" in OO,
            get: OO => OO.tintColorAtDistance,
            set: (OO, KO) => {
              OO.tintColorAtDistance = KO
            }
          },
          metadata: KO
        }, pK, XK), (0, yK.f)(null, null, TO, {
          kind: "field",
          name: "tintThickness",
          static: !1,
          private: !1,
          access: {
            has: OO => "tintThickness" in OO,
            get: OO => OO.tintThickness,
            set: (OO, KO) => {
              OO.tintThickness = KO
            }
          },
          metadata: KO
        }, bp, eK), KO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: KO
        })
      })(), OO._DefaultIndexOfRefraction = 1.5, OO
    })();
    class KK extends SO.e {
      constructor() {
        super(...arguments), this.IRIDESCENCE = !1, this.IRIDESCENCE_TEXTURE = !1, this.IRIDESCENCE_TEXTUREDIRECTUV = 0, this.IRIDESCENCE_THICKNESS_TEXTURE = !1, this.IRIDESCENCE_THICKNESS_TEXTUREDIRECTUV = 0
      }
    }
    let pK = (() => {
      var OO, KO, pO, XO;
      let bK, eO, lO, vK, CO, hO, DO, MO = JO.c,
        aK = [],
        oO = [],
        FO = [],
        VO = [],
        LO = [],
        QO = [],
        zK = [],
        AO = [],
        fO = [],
        dO = [],
        TO = [],
        NO = [],
        IO = [],
        uO = [];
      return OO = class extends MO {
        get isEnabled() {
          return (0, yK.b)(this, KO, "f")
        }
        set isEnabled(OO) {
          (0, yK.e)(this, KO, OO, "f")
        }
        get texture() {
          return (0, yK.b)(this, pO, "f")
        }
        set texture(OO) {
          (0, yK.e)(this, pO, OO, "f")
        }
        get thicknessTexture() {
          return (0, yK.b)(this, XO, "f")
        }
        set thicknessTexture(OO) {
          (0, yK.e)(this, XO, OO, "f")
        }
        _markAllSubMeshesAsTexturesDirty() {
          this._enable(this._isEnabled), this._internalMarkAllSubMeshesAsTexturesDirty()
        }
        isCompatible() {
          return !0
        }
        constructor(bK) {
          let eO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          super(bK, "PBRIridescence", 110, new KK, eO), this._isEnabled = !1, KO.set(this, (0, yK.i)(this, aK, !1)), this.intensity = ((0, yK.i)(this, oO), (0, yK.i)(this, FO, 1)), this.minimumThickness = ((0, yK.i)(this, VO), (0, yK.i)(this, LO, OO._DefaultMinimumThickness)), this.maximumThickness = ((0, yK.i)(this, QO), (0, yK.i)(this, zK, OO._DefaultMaximumThickness)), this.indexOfRefraction = ((0, yK.i)(this, AO), (0, yK.i)(this, fO, OO._DefaultIndexOfRefraction)), this._texture = ((0, yK.i)(this, dO), null), pO.set(this, (0, yK.i)(this, TO, null)), this._thicknessTexture = ((0, yK.i)(this, NO), null), XO.set(this, (0, yK.i)(this, IO, null)), this._internalMarkAllSubMeshesAsTexturesDirty = (0, yK.i)(this, uO), this._internalMarkAllSubMeshesAsTexturesDirty = bK._dirtyCallbacks[1]
        }
        isReadyForSubMesh(OO, KO) {
          if (!this._isEnabled) return !0;
          if (OO._areTexturesDirty && KO.texturesEnabled) {
            if (this._texture && WO.e.IridescenceTextureEnabled && !this._texture.isReadyOrNotBlocking()) return !1;
            if (this._thicknessTexture && WO.e.IridescenceTextureEnabled && !this._thicknessTexture.isReadyOrNotBlocking()) return !1
          }
          return !0
        }
        prepareDefinesBeforeAttributes(OO, KO) {
          this._isEnabled ? (OO.IRIDESCENCE = !0, OO._areTexturesDirty && KO.texturesEnabled && (this._texture && WO.e.IridescenceTextureEnabled ? (0, kK.bb)(this._texture, OO, "IRIDESCENCE_TEXTURE") : OO.IRIDESCENCE_TEXTURE = !1, this._thicknessTexture && WO.e.IridescenceTextureEnabled ? (0, kK.bb)(this._thicknessTexture, OO, "IRIDESCENCE_THICKNESS_TEXTURE") : OO.IRIDESCENCE_THICKNESS_TEXTURE = !1)) : (OO.IRIDESCENCE = !1, OO.IRIDESCENCE_TEXTURE = !1, OO.IRIDESCENCE_THICKNESS_TEXTURE = !1, OO.IRIDESCENCE_TEXTUREDIRECTUV = 0, OO.IRIDESCENCE_THICKNESS_TEXTUREDIRECTUV = 0)
        }
        bindForSubMesh(OO, KO) {
          if (!this._isEnabled) return;
          const pO = this._material.isFrozen;
          OO.useUbo && pO && OO.isSync || ((this._texture || this._thicknessTexture) && WO.e.IridescenceTextureEnabled && (OO.updateFloat4("vIridescenceInfos", this._texture?.coordinatesIndex ?? 0, this._texture?.level ?? 0, this._thicknessTexture?.coordinatesIndex ?? 0, this._thicknessTexture?.level ?? 0), this._texture && (0, kK.B)(this._texture, OO, "iridescence"), this._thicknessTexture && (0, kK.B)(this._thicknessTexture, OO, "iridescenceThickness")), OO.updateFloat4("vIridescenceParams", this.intensity, this.indexOfRefraction, this.minimumThickness, this.maximumThickness)), KO.texturesEnabled && (this._texture && WO.e.IridescenceTextureEnabled && OO.setTexture("iridescenceSampler", this._texture), this._thicknessTexture && WO.e.IridescenceTextureEnabled && OO.setTexture("iridescenceThicknessSampler", this._thicknessTexture))
        }
        hasTexture(OO) {
          return this._texture === OO || this._thicknessTexture === OO
        }
        getActiveTextures(OO) {
          this._texture && OO.push(this._texture), this._thicknessTexture && OO.push(this._thicknessTexture)
        }
        getAnimatables(OO) {
          this._texture && this._texture.animations && this._texture.animations.length > 0 && OO.push(this._texture), this._thicknessTexture && this._thicknessTexture.animations && this._thicknessTexture.animations.length > 0 && OO.push(this._thicknessTexture)
        }
        dispose(OO) {
          OO && (this._texture?.dispose(), this._thicknessTexture?.dispose())
        }
        getClassName() {
          return "PBRIridescenceConfiguration"
        }
        addFallbacks(OO, KO, pO) {
          return OO.IRIDESCENCE && KO.addFallback(pO++, "IRIDESCENCE"), pO
        }
        getSamplers(OO) {
          OO.push("iridescenceSampler", "iridescenceThicknessSampler")
        }
        getUniforms() {
          return {
            ubo: [{
              name: "vIridescenceParams",
              size: 4,
              type: "vec4"
            }, {
              name: "vIridescenceInfos",
              size: 4,
              type: "vec4"
            }, {
              name: "iridescenceMatrix",
              size: 16,
              type: "mat4"
            }, {
              name: "iridescenceThicknessMatrix",
              size: 16,
              type: "mat4"
            }]
          }
        }
      }, KO = new WeakMap, pO = new WeakMap, XO = new WeakMap, (() => {
        const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(MO[Symbol.metadata] ?? null) : void 0;
        bK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], eO = [(0, gK.M)()], lO = [(0, gK.M)()], vK = [(0, gK.M)()], CO = [(0, gK.M)()], hO = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], DO = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], (0, yK.f)(OO, null, bK, {
          kind: "accessor",
          name: "isEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isEnabled" in OO,
            get: OO => OO.isEnabled,
            set: (OO, KO) => {
              OO.isEnabled = KO
            }
          },
          metadata: KO
        }, aK, oO), (0, yK.f)(OO, null, hO, {
          kind: "accessor",
          name: "texture",
          static: !1,
          private: !1,
          access: {
            has: OO => "texture" in OO,
            get: OO => OO.texture,
            set: (OO, KO) => {
              OO.texture = KO
            }
          },
          metadata: KO
        }, TO, NO), (0, yK.f)(OO, null, DO, {
          kind: "accessor",
          name: "thicknessTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "thicknessTexture" in OO,
            get: OO => OO.thicknessTexture,
            set: (OO, KO) => {
              OO.thicknessTexture = KO
            }
          },
          metadata: KO
        }, IO, uO), (0, yK.f)(null, null, eO, {
          kind: "field",
          name: "intensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "intensity" in OO,
            get: OO => OO.intensity,
            set: (OO, KO) => {
              OO.intensity = KO
            }
          },
          metadata: KO
        }, FO, VO), (0, yK.f)(null, null, lO, {
          kind: "field",
          name: "minimumThickness",
          static: !1,
          private: !1,
          access: {
            has: OO => "minimumThickness" in OO,
            get: OO => OO.minimumThickness,
            set: (OO, KO) => {
              OO.minimumThickness = KO
            }
          },
          metadata: KO
        }, LO, QO), (0, yK.f)(null, null, vK, {
          kind: "field",
          name: "maximumThickness",
          static: !1,
          private: !1,
          access: {
            has: OO => "maximumThickness" in OO,
            get: OO => OO.maximumThickness,
            set: (OO, KO) => {
              OO.maximumThickness = KO
            }
          },
          metadata: KO
        }, zK, AO), (0, yK.f)(null, null, CO, {
          kind: "field",
          name: "indexOfRefraction",
          static: !1,
          private: !1,
          access: {
            has: OO => "indexOfRefraction" in OO,
            get: OO => OO.indexOfRefraction,
            set: (OO, KO) => {
              OO.indexOfRefraction = KO
            }
          },
          metadata: KO
        }, fO, dO), KO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: KO
        })
      })(), OO._DefaultMinimumThickness = 100, OO._DefaultMaximumThickness = 400, OO._DefaultIndexOfRefraction = 1.3, OO
    })();
    class XK extends SO.e {
      constructor() {
        super(...arguments), this.ANISOTROPIC = !1, this.ANISOTROPIC_TEXTURE = !1, this.ANISOTROPIC_TEXTUREDIRECTUV = 0, this.ANISOTROPIC_LEGACY = !1, this.MAINUV1 = !1
      }
    }
    let bp = (() => {
      var OO, KO, pO, XO;
      let bK, eO, lO, vK, CO, hO = JO.c,
        DO = [],
        MO = [],
        aK = [],
        oO = [],
        FO = [],
        VO = [],
        LO = [],
        QO = [],
        zK = [],
        AO = [];
      return OO = class extends hO {
        get isEnabled() {
          return (0, yK.b)(this, KO, "f")
        }
        set isEnabled(OO) {
          (0, yK.e)(this, KO, OO, "f")
        }
        set angle(OO) {
          this.direction.x = Math.cos(OO), this.direction.y = Math.sin(OO)
        }
        get angle() {
          return Math.atan2(this.direction.y, this.direction.x)
        }
        get texture() {
          return (0, yK.b)(this, pO, "f")
        }
        set texture(OO) {
          (0, yK.e)(this, pO, OO, "f")
        }
        get legacy() {
          return (0, yK.b)(this, XO, "f")
        }
        set legacy(OO) {
          (0, yK.e)(this, XO, OO, "f")
        }
        _markAllSubMeshesAsTexturesDirty() {
          this._enable(this._isEnabled), this._internalMarkAllSubMeshesAsTexturesDirty()
        }
        _markAllSubMeshesAsMiscDirty() {
          this._enable(this._isEnabled), this._internalMarkAllSubMeshesAsMiscDirty()
        }
        isCompatible() {
          return !0
        }
        constructor(OO) {
          let bK = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          super(OO, "PBRAnisotropic", 110, new XK, bK), this._isEnabled = !1, KO.set(this, (0, yK.i)(this, DO, !1)), this.intensity = ((0, yK.i)(this, MO), (0, yK.i)(this, aK, 1)), this.direction = ((0, yK.i)(this, oO), (0, yK.i)(this, FO, new HO.m(1, 0))), this._texture = ((0, yK.i)(this, VO), null), pO.set(this, (0, yK.i)(this, LO, null)), this._legacy = ((0, yK.i)(this, QO), !1), XO.set(this, (0, yK.i)(this, zK, !1)), this._internalMarkAllSubMeshesAsTexturesDirty = (0, yK.i)(this, AO), this._internalMarkAllSubMeshesAsTexturesDirty = OO._dirtyCallbacks[1], this._internalMarkAllSubMeshesAsMiscDirty = OO._dirtyCallbacks[16]
        }
        isReadyForSubMesh(OO, KO) {
          return !this._isEnabled || !(OO._areTexturesDirty && KO.texturesEnabled && this._texture && WO.e.AnisotropicTextureEnabled && !this._texture.isReadyOrNotBlocking())
        }
        prepareDefinesBeforeAttributes(OO, KO, pO) {
          this._isEnabled ? (OO.ANISOTROPIC = this._isEnabled, this._isEnabled && !pO.isVerticesDataPresent(RO.j.TangentKind) && (OO._needUVs = !0, OO.MAINUV1 = !0), OO._areTexturesDirty && KO.texturesEnabled && (this._texture && WO.e.AnisotropicTextureEnabled ? (0, kK.bb)(this._texture, OO, "ANISOTROPIC_TEXTURE") : OO.ANISOTROPIC_TEXTURE = !1), OO._areMiscDirty && (OO.ANISOTROPIC_LEGACY = this._legacy)) : (OO.ANISOTROPIC = !1, OO.ANISOTROPIC_TEXTURE = !1, OO.ANISOTROPIC_TEXTUREDIRECTUV = 0, OO.ANISOTROPIC_LEGACY = !1)
        }
        bindForSubMesh(OO, KO) {
          if (!this._isEnabled) return;
          const pO = this._material.isFrozen;
          OO.useUbo && pO && OO.isSync || (this._texture && WO.e.AnisotropicTextureEnabled && (OO.updateFloat2("vAnisotropyInfos", this._texture.coordinatesIndex, this._texture.level), (0, kK.B)(this._texture, OO, "anisotropy")), OO.updateFloat3("vAnisotropy", this.direction.x, this.direction.y, this.intensity)), KO.texturesEnabled && this._texture && WO.e.AnisotropicTextureEnabled && OO.setTexture("anisotropySampler", this._texture)
        }
        hasTexture(OO) {
          return this._texture === OO
        }
        getActiveTextures(OO) {
          this._texture && OO.push(this._texture)
        }
        getAnimatables(OO) {
          this._texture && this._texture.animations && this._texture.animations.length > 0 && OO.push(this._texture)
        }
        dispose(OO) {
          OO && this._texture && this._texture.dispose()
        }
        getClassName() {
          return "PBRAnisotropicConfiguration"
        }
        addFallbacks(OO, KO, pO) {
          return OO.ANISOTROPIC && KO.addFallback(pO++, "ANISOTROPIC"), pO
        }
        getSamplers(OO) {
          OO.push("anisotropySampler")
        }
        getUniforms() {
          return {
            ubo: [{
              name: "vAnisotropy",
              size: 3,
              type: "vec3"
            }, {
              name: "vAnisotropyInfos",
              size: 2,
              type: "vec2"
            }, {
              name: "anisotropyMatrix",
              size: 16,
              type: "mat4"
            }]
          }
        }
        parse(OO, KO, pO) {
          super.parse(OO, KO, pO), void 0 === OO.legacy && (this.legacy = !0)
        }
      }, KO = new WeakMap, pO = new WeakMap, XO = new WeakMap, (() => {
        const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(hO[Symbol.metadata] ?? null) : void 0;
        bK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], eO = [(0, gK.M)()], lO = [(0, gK.J)()], vK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], CO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], (0, yK.f)(OO, null, bK, {
          kind: "accessor",
          name: "isEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isEnabled" in OO,
            get: OO => OO.isEnabled,
            set: (OO, KO) => {
              OO.isEnabled = KO
            }
          },
          metadata: KO
        }, DO, MO), (0, yK.f)(OO, null, vK, {
          kind: "accessor",
          name: "texture",
          static: !1,
          private: !1,
          access: {
            has: OO => "texture" in OO,
            get: OO => OO.texture,
            set: (OO, KO) => {
              OO.texture = KO
            }
          },
          metadata: KO
        }, LO, QO), (0, yK.f)(OO, null, CO, {
          kind: "accessor",
          name: "legacy",
          static: !1,
          private: !1,
          access: {
            has: OO => "legacy" in OO,
            get: OO => OO.legacy,
            set: (OO, KO) => {
              OO.legacy = KO
            }
          },
          metadata: KO
        }, zK, AO), (0, yK.f)(null, null, eO, {
          kind: "field",
          name: "intensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "intensity" in OO,
            get: OO => OO.intensity,
            set: (OO, KO) => {
              OO.intensity = KO
            }
          },
          metadata: KO
        }, aK, oO), (0, yK.f)(null, null, lO, {
          kind: "field",
          name: "direction",
          static: !1,
          private: !1,
          access: {
            has: OO => "direction" in OO,
            get: OO => OO.direction,
            set: (OO, KO) => {
              OO.direction = KO
            }
          },
          metadata: KO
        }, FO, VO), KO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: KO
        })
      })(), OO
    })();
    class eK extends SO.e {
      constructor() {
        super(...arguments), this.SHEEN = !1, this.SHEEN_TEXTURE = !1, this.SHEEN_GAMMATEXTURE = !1, this.SHEEN_TEXTURE_ROUGHNESS = !1, this.SHEEN_TEXTUREDIRECTUV = 0, this.SHEEN_TEXTURE_ROUGHNESSDIRECTUV = 0, this.SHEEN_LINKWITHALBEDO = !1, this.SHEEN_ROUGHNESS = !1, this.SHEEN_ALBEDOSCALING = !1, this.SHEEN_USE_ROUGHNESS_FROM_MAINTEXTURE = !1
      }
    }
    let lK = (() => {
      var OO, KO, pO, XO, bK, eO, lO, vK;
      let CO, hO, DO, MO, aK, oO, FO, VO, LO, QO = JO.c,
        zK = [],
        AO = [],
        fO = [],
        dO = [],
        TO = [],
        NO = [],
        IO = [],
        uO = [],
        EO = [],
        jK = [],
        YO = [],
        wO = [],
        iK = [],
        rK = [],
        PO = [],
        mK = [],
        sO = [],
        HO = [];
      return OO = class extends QO {
        get isEnabled() {
          return (0, yK.b)(this, KO, "f")
        }
        set isEnabled(OO) {
          (0, yK.e)(this, KO, OO, "f")
        }
        get linkSheenWithAlbedo() {
          return (0, yK.b)(this, pO, "f")
        }
        set linkSheenWithAlbedo(OO) {
          (0, yK.e)(this, pO, OO, "f")
        }
        get texture() {
          return (0, yK.b)(this, XO, "f")
        }
        set texture(OO) {
          (0, yK.e)(this, XO, OO, "f")
        }
        get useRoughnessFromMainTexture() {
          return (0, yK.b)(this, bK, "f")
        }
        set useRoughnessFromMainTexture(OO) {
          (0, yK.e)(this, bK, OO, "f")
        }
        get roughness() {
          return (0, yK.b)(this, eO, "f")
        }
        set roughness(OO) {
          (0, yK.e)(this, eO, OO, "f")
        }
        get textureRoughness() {
          return (0, yK.b)(this, lO, "f")
        }
        set textureRoughness(OO) {
          (0, yK.e)(this, lO, OO, "f")
        }
        get albedoScaling() {
          return (0, yK.b)(this, vK, "f")
        }
        set albedoScaling(OO) {
          (0, yK.e)(this, vK, OO, "f")
        }
        _markAllSubMeshesAsTexturesDirty() {
          this._enable(this._isEnabled), this._internalMarkAllSubMeshesAsTexturesDirty()
        }
        isCompatible() {
          return !0
        }
        constructor(OO) {
          let CO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          super(OO, "Sheen", 120, new eK, CO), this._isEnabled = !1, KO.set(this, (0, yK.i)(this, zK, !1)), this._linkSheenWithAlbedo = ((0, yK.i)(this, AO), !1), pO.set(this, (0, yK.i)(this, fO, !1)), this.intensity = ((0, yK.i)(this, dO), (0, yK.i)(this, TO, 1)), this.color = ((0, yK.i)(this, NO), (0, yK.i)(this, IO, GO.e.White())), this._texture = ((0, yK.i)(this, uO), null), XO.set(this, (0, yK.i)(this, EO, null)), this._useRoughnessFromMainTexture = ((0, yK.i)(this, jK), !0), bK.set(this, (0, yK.i)(this, YO, !0)), this._roughness = ((0, yK.i)(this, wO), null), eO.set(this, (0, yK.i)(this, iK, null)), this._textureRoughness = ((0, yK.i)(this, rK), null), lO.set(this, (0, yK.i)(this, PO, null)), this._albedoScaling = ((0, yK.i)(this, mK), !1), vK.set(this, (0, yK.i)(this, sO, !1)), this._internalMarkAllSubMeshesAsTexturesDirty = (0, yK.i)(this, HO), this._internalMarkAllSubMeshesAsTexturesDirty = OO._dirtyCallbacks[1]
        }
        isReadyForSubMesh(OO, KO) {
          if (!this._isEnabled) return !0;
          if (OO._areTexturesDirty && KO.texturesEnabled) {
            if (this._texture && WO.e.SheenTextureEnabled && !this._texture.isReadyOrNotBlocking()) return !1;
            if (this._textureRoughness && WO.e.SheenTextureEnabled && !this._textureRoughness.isReadyOrNotBlocking()) return !1
          }
          return !0
        }
        prepareDefinesBeforeAttributes(OO, KO) {
          this._isEnabled ? (OO.SHEEN = !0, OO.SHEEN_LINKWITHALBEDO = this._linkSheenWithAlbedo, OO.SHEEN_ROUGHNESS = null !== this._roughness, OO.SHEEN_ALBEDOSCALING = this._albedoScaling, OO.SHEEN_USE_ROUGHNESS_FROM_MAINTEXTURE = this._useRoughnessFromMainTexture, OO._areTexturesDirty && KO.texturesEnabled && (this._texture && WO.e.SheenTextureEnabled ? ((0, kK.bb)(this._texture, OO, "SHEEN_TEXTURE"), OO.SHEEN_GAMMATEXTURE = this._texture.gammaSpace) : OO.SHEEN_TEXTURE = !1, this._textureRoughness && WO.e.SheenTextureEnabled ? (0, kK.bb)(this._textureRoughness, OO, "SHEEN_TEXTURE_ROUGHNESS") : OO.SHEEN_TEXTURE_ROUGHNESS = !1)) : (OO.SHEEN = !1, OO.SHEEN_TEXTURE = !1, OO.SHEEN_TEXTURE_ROUGHNESS = !1, OO.SHEEN_LINKWITHALBEDO = !1, OO.SHEEN_ROUGHNESS = !1, OO.SHEEN_ALBEDOSCALING = !1, OO.SHEEN_USE_ROUGHNESS_FROM_MAINTEXTURE = !1, OO.SHEEN_GAMMATEXTURE = !1, OO.SHEEN_TEXTUREDIRECTUV = 0, OO.SHEEN_TEXTURE_ROUGHNESSDIRECTUV = 0)
        }
        bindForSubMesh(OO, KO, pO, XO) {
          if (!this._isEnabled) return;
          const bK = XO.materialDefines,
            eO = this._material.isFrozen;
          OO.useUbo && eO && OO.isSync || ((this._texture || this._textureRoughness) && WO.e.SheenTextureEnabled && (OO.updateFloat4("vSheenInfos", this._texture?.coordinatesIndex ?? 0, this._texture?.level ?? 0, this._textureRoughness?.coordinatesIndex ?? 0, this._textureRoughness?.level ?? 0), this._texture && (0, kK.B)(this._texture, OO, "sheen"), this._textureRoughness && !bK.SHEEN_USE_ROUGHNESS_FROM_MAINTEXTURE && (0, kK.B)(this._textureRoughness, OO, "sheenRoughness")), OO.updateFloat4("vSheenColor", this.color.r, this.color.g, this.color.b, this.intensity), null !== this._roughness && OO.updateFloat("vSheenRoughness", this._roughness)), KO.texturesEnabled && (this._texture && WO.e.SheenTextureEnabled && OO.setTexture("sheenSampler", this._texture), this._textureRoughness && !bK.SHEEN_USE_ROUGHNESS_FROM_MAINTEXTURE && WO.e.SheenTextureEnabled && OO.setTexture("sheenRoughnessSampler", this._textureRoughness))
        }
        hasTexture(OO) {
          return this._texture === OO || this._textureRoughness === OO
        }
        getActiveTextures(OO) {
          this._texture && OO.push(this._texture), this._textureRoughness && OO.push(this._textureRoughness)
        }
        getAnimatables(OO) {
          this._texture && this._texture.animations && this._texture.animations.length > 0 && OO.push(this._texture), this._textureRoughness && this._textureRoughness.animations && this._textureRoughness.animations.length > 0 && OO.push(this._textureRoughness)
        }
        dispose(OO) {
          OO && (this._texture?.dispose(), this._textureRoughness?.dispose())
        }
        getClassName() {
          return "PBRSheenConfiguration"
        }
        addFallbacks(OO, KO, pO) {
          return OO.SHEEN && KO.addFallback(pO++, "SHEEN"), pO
        }
        getSamplers(OO) {
          OO.push("sheenSampler", "sheenRoughnessSampler")
        }
        getUniforms() {
          return {
            ubo: [{
              name: "vSheenColor",
              size: 4,
              type: "vec4"
            }, {
              name: "vSheenRoughness",
              size: 1,
              type: "float"
            }, {
              name: "vSheenInfos",
              size: 4,
              type: "vec4"
            }, {
              name: "sheenMatrix",
              size: 16,
              type: "mat4"
            }, {
              name: "sheenRoughnessMatrix",
              size: 16,
              type: "mat4"
            }]
          }
        }
      }, KO = new WeakMap, pO = new WeakMap, XO = new WeakMap, bK = new WeakMap, eO = new WeakMap, lO = new WeakMap, vK = new WeakMap, (() => {
        const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(QO[Symbol.metadata] ?? null) : void 0;
        CO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], hO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], DO = [(0, gK.M)()], MO = [(0, gK.r)()], aK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], oO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], FO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], VO = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], LO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], (0, yK.f)(OO, null, CO, {
          kind: "accessor",
          name: "isEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isEnabled" in OO,
            get: OO => OO.isEnabled,
            set: (OO, KO) => {
              OO.isEnabled = KO
            }
          },
          metadata: KO
        }, zK, AO), (0, yK.f)(OO, null, hO, {
          kind: "accessor",
          name: "linkSheenWithAlbedo",
          static: !1,
          private: !1,
          access: {
            has: OO => "linkSheenWithAlbedo" in OO,
            get: OO => OO.linkSheenWithAlbedo,
            set: (OO, KO) => {
              OO.linkSheenWithAlbedo = KO
            }
          },
          metadata: KO
        }, fO, dO), (0, yK.f)(OO, null, aK, {
          kind: "accessor",
          name: "texture",
          static: !1,
          private: !1,
          access: {
            has: OO => "texture" in OO,
            get: OO => OO.texture,
            set: (OO, KO) => {
              OO.texture = KO
            }
          },
          metadata: KO
        }, EO, jK), (0, yK.f)(OO, null, oO, {
          kind: "accessor",
          name: "useRoughnessFromMainTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "useRoughnessFromMainTexture" in OO,
            get: OO => OO.useRoughnessFromMainTexture,
            set: (OO, KO) => {
              OO.useRoughnessFromMainTexture = KO
            }
          },
          metadata: KO
        }, YO, wO), (0, yK.f)(OO, null, FO, {
          kind: "accessor",
          name: "roughness",
          static: !1,
          private: !1,
          access: {
            has: OO => "roughness" in OO,
            get: OO => OO.roughness,
            set: (OO, KO) => {
              OO.roughness = KO
            }
          },
          metadata: KO
        }, iK, rK), (0, yK.f)(OO, null, VO, {
          kind: "accessor",
          name: "textureRoughness",
          static: !1,
          private: !1,
          access: {
            has: OO => "textureRoughness" in OO,
            get: OO => OO.textureRoughness,
            set: (OO, KO) => {
              OO.textureRoughness = KO
            }
          },
          metadata: KO
        }, PO, mK), (0, yK.f)(OO, null, LO, {
          kind: "accessor",
          name: "albedoScaling",
          static: !1,
          private: !1,
          access: {
            has: OO => "albedoScaling" in OO,
            get: OO => OO.albedoScaling,
            set: (OO, KO) => {
              OO.albedoScaling = KO
            }
          },
          metadata: KO
        }, sO, HO), (0, yK.f)(null, null, DO, {
          kind: "field",
          name: "intensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "intensity" in OO,
            get: OO => OO.intensity,
            set: (OO, KO) => {
              OO.intensity = KO
            }
          },
          metadata: KO
        }, TO, NO), (0, yK.f)(null, null, MO, {
          kind: "field",
          name: "color",
          static: !1,
          private: !1,
          access: {
            has: OO => "color" in OO,
            get: OO => OO.color,
            set: (OO, KO) => {
              OO.color = KO
            }
          },
          metadata: KO
        }, IO, uO), KO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: KO
        })
      })(), OO
    })();
    class vp extends SO.e {
      constructor() {
        super(...arguments), this.SUBSURFACE = !1, this.SS_REFRACTION = !1, this.SS_REFRACTION_USE_INTENSITY_FROM_THICKNESS = !1, this.SS_TRANSLUCENCY = !1, this.SS_TRANSLUCENCY_USE_INTENSITY_FROM_THICKNESS = !1, this.SS_SCATTERING = !1, this.SS_DISPERSION = !1, this.SS_THICKNESSANDMASK_TEXTURE = !1, this.SS_THICKNESSANDMASK_TEXTUREDIRECTUV = 0, this.SS_HAS_THICKNESS = !1, this.SS_REFRACTIONINTENSITY_TEXTURE = !1, this.SS_REFRACTIONINTENSITY_TEXTUREDIRECTUV = 0, this.SS_TRANSLUCENCYINTENSITY_TEXTURE = !1, this.SS_TRANSLUCENCYINTENSITY_TEXTUREDIRECTUV = 0, this.SS_TRANSLUCENCYCOLOR_TEXTURE = !1, this.SS_TRANSLUCENCYCOLOR_TEXTUREDIRECTUV = 0, this.SS_TRANSLUCENCYCOLOR_TEXTURE_GAMMA = !1, this.SS_REFRACTIONMAP_3D = !1, this.SS_REFRACTIONMAP_OPPOSITEZ = !1, this.SS_LODINREFRACTIONALPHA = !1, this.SS_GAMMAREFRACTION = !1, this.SS_RGBDREFRACTION = !1, this.SS_LINEARSPECULARREFRACTION = !1, this.SS_LINKREFRACTIONTOTRANSPARENCY = !1, this.SS_ALBEDOFORREFRACTIONTINT = !1, this.SS_ALBEDOFORTRANSLUCENCYTINT = !1, this.SS_USE_LOCAL_REFRACTIONMAP_CUBIC = !1, this.SS_USE_THICKNESS_AS_DEPTH = !1, this.SS_USE_GLTF_TEXTURES = !1, this.SS_APPLY_ALBEDO_AFTER_SUBSURFACE = !1, this.SS_TRANSLUCENCY_LEGACY = !1
      }
    }
    let CK = (() => {
      var OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO;
      let QO, zK, AO, fO, dO, TO, NO, IO, uO, EO, jK, YO, wO, iK, rK, PO, mK, sO, RO, SO, cK, BO, ZO, qK, xK, nO, tK, UO, OK, KK, pK = JO.c,
        XK = [],
        bp = [],
        eK = [],
        lK = [],
        CK = [],
        hK = [],
        DK = [],
        MK = [],
        ap = [],
        oK = [],
        FK = [],
        VK = [],
        LK = [],
        QK = [],
        zp = [],
        AK = [],
        fK = [],
        dK = [],
        TK = [],
        NK = [],
        IK = [],
        yp = [],
        gp = [],
        uK = [],
        EK = [],
        jp = [],
        YK = [],
        wK = [],
        ip = [],
        rp = [],
        PK = [],
        mp = [],
        sK = [],
        HK = [],
        RK = [],
        SK = [],
        JK = [],
        cp = [],
        BK = [],
        ZK = [],
        GK = [],
        qp = [],
        xp = [],
        nK = [],
        WK = [],
        tp = [],
        kp = [],
        UK = [],
        Op = [],
        Kp = [],
        pp = [],
        Xp = [],
        bX = [],
        ep = [],
        lp = [],
        vX = [],
        Cp = [],
        hp = [],
        Dp = [],
        Mp = [];
      return OO = class extends pK {
        get isRefractionEnabled() {
          return (0, yK.b)(this, KO, "f")
        }
        set isRefractionEnabled(OO) {
          (0, yK.e)(this, KO, OO, "f")
        }
        get isTranslucencyEnabled() {
          return (0, yK.b)(this, pO, "f")
        }
        set isTranslucencyEnabled(OO) {
          (0, yK.e)(this, pO, OO, "f")
        }
        get isDispersionEnabled() {
          return (0, yK.b)(this, XO, "f")
        }
        set isDispersionEnabled(OO) {
          (0, yK.e)(this, XO, OO, "f")
        }
        get isScatteringEnabled() {
          return (0, yK.b)(this, bK, "f")
        }
        set isScatteringEnabled(OO) {
          (0, yK.e)(this, bK, OO, "f")
        }
        get scatteringDiffusionProfile() {
          return this._scene.subSurfaceConfiguration ? this._scene.subSurfaceConfiguration.ssDiffusionProfileColors[this._scatteringDiffusionProfileIndex] : null
        }
        set scatteringDiffusionProfile(OO) {
          this._scene.enableSubSurfaceForPrePass() && OO && (this._scatteringDiffusionProfileIndex = this._scene.subSurfaceConfiguration.addDiffusionProfile(OO))
        }
        get useAlbedoToTintRefraction() {
          return (0, yK.b)(this, eO, "f")
        }
        set useAlbedoToTintRefraction(OO) {
          (0, yK.e)(this, eO, OO, "f")
        }
        get useAlbedoToTintTranslucency() {
          return (0, yK.b)(this, lO, "f")
        }
        set useAlbedoToTintTranslucency(OO) {
          (0, yK.e)(this, lO, OO, "f")
        }
        get thicknessTexture() {
          return (0, yK.b)(this, vK, "f")
        }
        set thicknessTexture(OO) {
          (0, yK.e)(this, vK, OO, "f")
        }
        get refractionTexture() {
          return (0, yK.b)(this, CO, "f")
        }
        set refractionTexture(OO) {
          (0, yK.e)(this, CO, OO, "f")
        }
        get indexOfRefraction() {
          return (0, yK.b)(this, hO, "f")
        }
        set indexOfRefraction(OO) {
          (0, yK.e)(this, hO, OO, "f")
        }
        get volumeIndexOfRefraction() {
          return this._volumeIndexOfRefraction >= 1 ? this._volumeIndexOfRefraction : this._indexOfRefraction
        }
        set volumeIndexOfRefraction(OO) {
          const KO = OO >= 1 ? OO : -1;
          this._volumeIndexOfRefraction !== KO && (this._volumeIndexOfRefraction = KO, this._markAllSubMeshesAsTexturesDirty())
        }
        get invertRefractionY() {
          return (0, yK.b)(this, DO, "f")
        }
        set invertRefractionY(OO) {
          (0, yK.e)(this, DO, OO, "f")
        }
        get linkRefractionWithTransparency() {
          return (0, yK.b)(this, MO, "f")
        }
        set linkRefractionWithTransparency(OO) {
          (0, yK.e)(this, MO, OO, "f")
        }
        get useMaskFromThicknessTexture() {
          return (0, yK.b)(this, aK, "f")
        }
        set useMaskFromThicknessTexture(OO) {
          (0, yK.e)(this, aK, OO, "f")
        }
        get refractionIntensityTexture() {
          return (0, yK.b)(this, oO, "f")
        }
        set refractionIntensityTexture(OO) {
          (0, yK.e)(this, oO, OO, "f")
        }
        get translucencyIntensityTexture() {
          return (0, yK.b)(this, FO, "f")
        }
        set translucencyIntensityTexture(OO) {
          (0, yK.e)(this, FO, OO, "f")
        }
        get translucencyColorTexture() {
          return (0, yK.b)(this, VO, "f")
        }
        set translucencyColorTexture(OO) {
          (0, yK.e)(this, VO, OO, "f")
        }
        get useGltfStyleTextures() {
          return (0, yK.b)(this, LO, "f")
        }
        set useGltfStyleTextures(OO) {
          (0, yK.e)(this, LO, OO, "f")
        }
        get legacyTransluceny() {
          return this.legacyTranslucency
        }
        set legacyTransluceny(OO) {
          this.legacyTranslucency = OO
        }
        _markAllSubMeshesAsTexturesDirty() {
          this._enable(this._isRefractionEnabled || this._isTranslucencyEnabled || this._isScatteringEnabled), this._internalMarkAllSubMeshesAsTexturesDirty()
        }
        _markScenePrePassDirty() {
          this._enable(this._isRefractionEnabled || this._isTranslucencyEnabled || this._isScatteringEnabled), this._internalMarkAllSubMeshesAsTexturesDirty(), this._internalMarkScenePrePassDirty()
        }
        isCompatible() {
          return !0
        }
        constructor(QO) {
          let zK = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          super(QO, "PBRSubSurface", 130, new vp, zK), this._isRefractionEnabled = !1, KO.set(this, (0, yK.i)(this, XK, !1)), this._isTranslucencyEnabled = ((0, yK.i)(this, bp), !1), pO.set(this, (0, yK.i)(this, eK, !1)), this._isDispersionEnabled = ((0, yK.i)(this, lK), !1), XO.set(this, (0, yK.i)(this, CK, !1)), this._isScatteringEnabled = ((0, yK.i)(this, hK), !1), bK.set(this, (0, yK.i)(this, DK, !1)), this._scatteringDiffusionProfileIndex = ((0, yK.i)(this, MK), (0, yK.i)(this, ap, 0)), this.refractionIntensity = ((0, yK.i)(this, oK), (0, yK.i)(this, FK, 1)), this.translucencyIntensity = ((0, yK.i)(this, VK), (0, yK.i)(this, LK, 1)), this._useAlbedoToTintRefraction = ((0, yK.i)(this, QK), !1), eO.set(this, (0, yK.i)(this, zp, !1)), this._useAlbedoToTintTranslucency = ((0, yK.i)(this, AK), !1), lO.set(this, (0, yK.i)(this, fK, !1)), this._thicknessTexture = ((0, yK.i)(this, dK), null), vK.set(this, (0, yK.i)(this, TK, null)), this._refractionTexture = ((0, yK.i)(this, NK), null), CO.set(this, (0, yK.i)(this, IK, null)), this._indexOfRefraction = ((0, yK.i)(this, yp), 1.5), hO.set(this, (0, yK.i)(this, gp, 1.5)), this._volumeIndexOfRefraction = ((0, yK.i)(this, uK), (0, yK.i)(this, EK, -1)), this._invertRefractionY = ((0, yK.i)(this, jp), !1), DO.set(this, (0, yK.i)(this, YK, !1)), this._linkRefractionWithTransparency = ((0, yK.i)(this, wK), !1), MO.set(this, (0, yK.i)(this, ip, !1)), this.minimumThickness = ((0, yK.i)(this, rp), (0, yK.i)(this, PK, 0)), this.maximumThickness = ((0, yK.i)(this, mp), (0, yK.i)(this, sK, 1)), this.useThicknessAsDepth = ((0, yK.i)(this, HK), (0, yK.i)(this, RK, !1)), this.tintColor = ((0, yK.i)(this, SK), (0, yK.i)(this, JK, GO.e.White())), this.tintColorAtDistance = ((0, yK.i)(this, cp), (0, yK.i)(this, BK, 1)), this.dispersion = ((0, yK.i)(this, ZK), (0, yK.i)(this, GK, 0)), this.diffusionDistance = ((0, yK.i)(this, qp), (0, yK.i)(this, xp, GO.e.White())), this._useMaskFromThicknessTexture = ((0, yK.i)(this, nK), !1), aK.set(this, (0, yK.i)(this, WK, !1)), this._refractionIntensityTexture = ((0, yK.i)(this, tp), null), oO.set(this, (0, yK.i)(this, kp, null)), this._translucencyIntensityTexture = ((0, yK.i)(this, UK), null), FO.set(this, (0, yK.i)(this, Op, null)), this.translucencyColor = ((0, yK.i)(this, Kp), (0, yK.i)(this, pp, null)), this._translucencyColorTexture = ((0, yK.i)(this, Xp), null), VO.set(this, (0, yK.i)(this, bX, null)), this._useGltfStyleTextures = ((0, yK.i)(this, ep), !0), LO.set(this, (0, yK.i)(this, lp, !0)), this.applyAlbedoAfterSubSurface = ((0, yK.i)(this, vX), (0, yK.i)(this, Cp, OO.DEFAULT_APPLY_ALBEDO_AFTERSUBSURFACE)), this.legacyTranslucency = ((0, yK.i)(this, hp), (0, yK.i)(this, Dp, OO.DEFAULT_LEGACY_TRANSLUCENCY)), this._scene = (0, yK.i)(this, Mp), this._scene = QO.JKO(), this.registerForExtraEvents = !0, this._internalMarkAllSubMeshesAsTexturesDirty = QO._dirtyCallbacks[1], this._internalMarkScenePrePassDirty = QO._dirtyCallbacks[32]
        }
        isReadyForSubMesh(OO, KO) {
          if (!this._isRefractionEnabled && !this._isTranslucencyEnabled && !this._isScatteringEnabled) return !0;
          if (OO._areTexturesDirty && KO.texturesEnabled) {
            if (this._thicknessTexture && WO.e.ThicknessTextureEnabled && !this._thicknessTexture.isReadyOrNotBlocking()) return !1;
            if (this._refractionIntensityTexture && WO.e.RefractionIntensityTextureEnabled && !this._refractionIntensityTexture.isReadyOrNotBlocking()) return !1;
            if (this._translucencyColorTexture && WO.e.TranslucencyColorTextureEnabled && !this._translucencyColorTexture.isReadyOrNotBlocking()) return !1;
            if (this._translucencyIntensityTexture && WO.e.TranslucencyIntensityTextureEnabled && !this._translucencyIntensityTexture.isReadyOrNotBlocking()) return !1;
            const OO = this._getRefractionTexture(KO);
            if (OO && WO.e.RefractionTextureEnabled && !OO.isReadyOrNotBlocking()) return !1
          }
          return !0
        }
        prepareDefinesBeforeAttributes(OO, KO) {
          if (!this._isRefractionEnabled && !this._isTranslucencyEnabled && !this._isScatteringEnabled) return OO.SUBSURFACE = !1, OO.SS_DISPERSION = !1, OO.SS_TRANSLUCENCY = !1, OO.SS_SCATTERING = !1, OO.SS_REFRACTION = !1, OO.SS_REFRACTION_USE_INTENSITY_FROM_THICKNESS = !1, OO.SS_TRANSLUCENCY_USE_INTENSITY_FROM_THICKNESS = !1, OO.SS_THICKNESSANDMASK_TEXTURE = !1, OO.SS_THICKNESSANDMASK_TEXTUREDIRECTUV = 0, OO.SS_HAS_THICKNESS = !1, OO.SS_REFRACTIONINTENSITY_TEXTURE = !1, OO.SS_REFRACTIONINTENSITY_TEXTUREDIRECTUV = 0, OO.SS_TRANSLUCENCYINTENSITY_TEXTURE = !1, OO.SS_TRANSLUCENCYINTENSITY_TEXTUREDIRECTUV = 0, OO.SS_REFRACTIONMAP_3D = !1, OO.SS_REFRACTIONMAP_OPPOSITEZ = !1, OO.SS_LODINREFRACTIONALPHA = !1, OO.SS_GAMMAREFRACTION = !1, OO.SS_RGBDREFRACTION = !1, OO.SS_LINEARSPECULARREFRACTION = !1, OO.SS_LINKREFRACTIONTOTRANSPARENCY = !1, OO.SS_ALBEDOFORREFRACTIONTINT = !1, OO.SS_ALBEDOFORTRANSLUCENCYTINT = !1, OO.SS_USE_LOCAL_REFRACTIONMAP_CUBIC = !1, OO.SS_USE_THICKNESS_AS_DEPTH = !1, OO.SS_USE_GLTF_TEXTURES = !1, OO.SS_TRANSLUCENCYCOLOR_TEXTURE = !1, OO.SS_TRANSLUCENCYCOLOR_TEXTUREDIRECTUV = 0, OO.SS_TRANSLUCENCYCOLOR_TEXTURE_GAMMA = !1, void(OO.SS_APPLY_ALBEDO_AFTER_SUBSURFACE = !1);
          if (OO._areTexturesDirty) {
            if (OO.SUBSURFACE = !0, OO.SS_DISPERSION = this._isDispersionEnabled, OO.SS_TRANSLUCENCY = this._isTranslucencyEnabled, OO.SS_TRANSLUCENCY_USE_INTENSITY_FROM_THICKNESS = !1, OO.SS_TRANSLUCENCY_LEGACY = this.legacyTranslucency, OO.SS_SCATTERING = this._isScatteringEnabled, OO.SS_THICKNESSANDMASK_TEXTURE = !1, OO.SS_REFRACTIONINTENSITY_TEXTURE = !1, OO.SS_TRANSLUCENCYINTENSITY_TEXTURE = !1, OO.SS_HAS_THICKNESS = !1, OO.SS_USE_GLTF_TEXTURES = !1, OO.SS_REFRACTION = !1, OO.SS_REFRACTION_USE_INTENSITY_FROM_THICKNESS = !1, OO.SS_REFRACTIONMAP_3D = !1, OO.SS_GAMMAREFRACTION = !1, OO.SS_RGBDREFRACTION = !1, OO.SS_LINEARSPECULARREFRACTION = !1, OO.SS_REFRACTIONMAP_OPPOSITEZ = !1, OO.SS_LODINREFRACTIONALPHA = !1, OO.SS_LINKREFRACTIONTOTRANSPARENCY = !1, OO.SS_ALBEDOFORREFRACTIONTINT = !1, OO.SS_ALBEDOFORTRANSLUCENCYTINT = !1, OO.SS_USE_LOCAL_REFRACTIONMAP_CUBIC = !1, OO.SS_USE_THICKNESS_AS_DEPTH = !1, OO.SS_TRANSLUCENCYCOLOR_TEXTURE = !1, OO.SS_APPLY_ALBEDO_AFTER_SUBSURFACE = this.applyAlbedoAfterSubSurface, OO._areTexturesDirty && KO.texturesEnabled && (this._thicknessTexture && WO.e.ThicknessTextureEnabled && (0, kK.bb)(this._thicknessTexture, OO, "SS_THICKNESSANDMASK_TEXTURE"), this._refractionIntensityTexture && WO.e.RefractionIntensityTextureEnabled && (0, kK.bb)(this._refractionIntensityTexture, OO, "SS_REFRACTIONINTENSITY_TEXTURE"), this._translucencyIntensityTexture && WO.e.TranslucencyIntensityTextureEnabled && (0, kK.bb)(this._translucencyIntensityTexture, OO, "SS_TRANSLUCENCYINTENSITY_TEXTURE"), this._translucencyColorTexture && WO.e.TranslucencyColorTextureEnabled && ((0, kK.bb)(this._translucencyColorTexture, OO, "SS_TRANSLUCENCYCOLOR_TEXTURE"), OO.SS_TRANSLUCENCYCOLOR_TEXTURE_GAMMA = this._translucencyColorTexture.gammaSpace)), OO.SS_HAS_THICKNESS = this.maximumThickness - this.minimumThickness !== 0, OO.SS_USE_GLTF_TEXTURES = this._useGltfStyleTextures, OO.SS_REFRACTION_USE_INTENSITY_FROM_THICKNESS = this._useMaskFromThicknessTexture && !this._refractionIntensityTexture, OO.SS_TRANSLUCENCY_USE_INTENSITY_FROM_THICKNESS = this._useMaskFromThicknessTexture && !this._translucencyIntensityTexture, this._isRefractionEnabled && KO.texturesEnabled) {
              const pO = this._getRefractionTexture(KO);
              pO && WO.e.RefractionTextureEnabled && (OO.SS_REFRACTION = !0, OO.SS_REFRACTIONMAP_3D = pO.isCube, OO.SS_GAMMAREFRACTION = pO.gammaSpace, OO.SS_RGBDREFRACTION = pO.isRGBD, OO.SS_LINEARSPECULARREFRACTION = pO.linearSpecularLOD, OO.SS_REFRACTIONMAP_OPPOSITEZ = this._scene.useRightHandedSystem && pO.isCube ? !pO.invertZ : pO.invertZ, OO.SS_LODINREFRACTIONALPHA = pO.lodLevelInAlpha, OO.SS_LINKREFRACTIONTOTRANSPARENCY = this._linkRefractionWithTransparency, OO.SS_ALBEDOFORREFRACTIONTINT = this._useAlbedoToTintRefraction, OO.SS_USE_LOCAL_REFRACTIONMAP_CUBIC = pO.isCube && pO.boundingBoxSize, OO.SS_USE_THICKNESS_AS_DEPTH = this.useThicknessAsDepth)
            }
            this._isTranslucencyEnabled && (OO.SS_ALBEDOFORTRANSLUCENCYTINT = this._useAlbedoToTintTranslucency)
          }
        }
        hardBindForSubMesh(OO, KO, pO, XO) {
          if (this._isRefractionEnabled || this._isTranslucencyEnabled || this._isScatteringEnabled)
            if (0 === this.maximumThickness && 0 === this.minimumThickness) OO.updateFloat2("vThicknessParam", 0, 0);
            else {
              XO.getRenderingMesh().getWorldMatrix().decompose(HO.j.WX[0]);
              const KO = Math.max(Math.abs(HO.j.WX[0].x), Math.abs(HO.j.WX[0].y), Math.abs(HO.j.WX[0].z));
              OO.updateFloat2("vThicknessParam", this.minimumThickness * KO, (this.maximumThickness - this.minimumThickness) * KO)
            }
        }
        bindForSubMesh(OO, KO, pO, XO) {
          if (!this._isRefractionEnabled && !this._isTranslucencyEnabled && !this._isScatteringEnabled) return;
          const bK = XO.materialDefines,
            eO = this._material.isFrozen,
            lO = this._material.realTimeFiltering,
            vK = bK.LODBASEDMICROSFURACE,
            CO = this._getRefractionTexture(KO);
          if (!OO.useUbo || !eO || !OO.isSync) {
            if (this._thicknessTexture && WO.e.ThicknessTextureEnabled && (OO.updateFloat2("vThicknessInfos", this._thicknessTexture.coordinatesIndex, this._thicknessTexture.level), (0, kK.B)(this._thicknessTexture, OO, "thickness")), this._refractionIntensityTexture && WO.e.RefractionIntensityTextureEnabled && bK.SS_REFRACTIONINTENSITY_TEXTURE && (OO.updateFloat2("vRefractionIntensityInfos", this._refractionIntensityTexture.coordinatesIndex, this._refractionIntensityTexture.level), (0, kK.B)(this._refractionIntensityTexture, OO, "refractionIntensity")), this._translucencyColorTexture && WO.e.TranslucencyColorTextureEnabled && bK.SS_TRANSLUCENCYCOLOR_TEXTURE && (OO.updateFloat2("vTranslucencyColorInfos", this._translucencyColorTexture.coordinatesIndex, this._translucencyColorTexture.level), (0, kK.B)(this._translucencyColorTexture, OO, "translucencyColor")), this._translucencyIntensityTexture && WO.e.TranslucencyIntensityTextureEnabled && bK.SS_TRANSLUCENCYINTENSITY_TEXTURE && (OO.updateFloat2("vTranslucencyIntensityInfos", this._translucencyIntensityTexture.coordinatesIndex, this._translucencyIntensityTexture.level), (0, kK.B)(this._translucencyIntensityTexture, OO, "translucencyIntensity")), CO && WO.e.RefractionTextureEnabled) {
              OO.AlO("refractionMatrix", CO.getRefractionTextureMatrix());
              let KO = 1;
              CO.isCube || CO.depth && (KO = CO.depth);
              const pO = CO.getSize().width,
                XO = this.volumeIndexOfRefraction;
              if (OO.updateFloat4("vRefractionInfos", CO.level, 1 / XO, KO, this._invertRefractionY ? -1 : 1), OO.updateFloat4("vRefractionMicrosurfaceInfos", pO, CO.lodGenerationScale, CO.lodGenerationOffset, 1 / this.indexOfRefraction), lO && OO.updateFloat2("vRefractionFilteringInfo", pO, Math.log2(pO)), CO.boundingBoxSize) {
                const KO = CO;
                OO.updateVector3("vRefractionPosition", KO.boundingBoxPosition), OO.updateVector3("vRefractionSize", KO.boundingBoxSize)
              }
            }
            this._isScatteringEnabled && OO.updateFloat("scatteringDiffusionProfile", this._scatteringDiffusionProfileIndex), OO.updateColor3("vDiffusionDistance", this.diffusionDistance), OO.updateFloat4("vTintColor", this.tintColor.r, this.tintColor.g, this.tintColor.b, Math.max(1e-5, this.tintColorAtDistance)), OO.updateColor4("vTranslucencyColor", this.translucencyColor ?? this.tintColor, 0), OO.updateFloat3("vSubSurfaceIntensity", this.refractionIntensity, this.translucencyIntensity, 0), OO.updateFloat("dispersion", this.dispersion)
          }
          KO.texturesEnabled && (this._thicknessTexture && WO.e.ThicknessTextureEnabled && OO.setTexture("thicknessSampler", this._thicknessTexture), this._refractionIntensityTexture && WO.e.RefractionIntensityTextureEnabled && bK.SS_REFRACTIONINTENSITY_TEXTURE && OO.setTexture("refractionIntensitySampler", this._refractionIntensityTexture), this._translucencyIntensityTexture && WO.e.TranslucencyIntensityTextureEnabled && bK.SS_TRANSLUCENCYINTENSITY_TEXTURE && OO.setTexture("translucencyIntensitySampler", this._translucencyIntensityTexture), this._translucencyColorTexture && WO.e.TranslucencyColorTextureEnabled && bK.SS_TRANSLUCENCYCOLOR_TEXTURE && OO.setTexture("translucencyColorSampler", this._translucencyColorTexture), CO && WO.e.RefractionTextureEnabled && (vK ? OO.setTexture("refractionSampler", CO) : (OO.setTexture("refractionSampler", CO._lodTextureMid || CO), OO.setTexture("refractionSamplerLow", CO._lodTextureLow || CO), OO.setTexture("refractionSamplerHigh", CO._lodTextureHigh || CO))))
        }
        _getRefractionTexture(OO) {
          return this._refractionTexture ? this._refractionTexture : this._isRefractionEnabled ? OO.environmentTexture : null
        }
        get disableAlphaBlending() {
          return this._isRefractionEnabled && this._linkRefractionWithTransparency
        }
        fillRenderTargetTextures(OO) {
          WO.e.RefractionTextureEnabled && this._refractionTexture && this._refractionTexture.isRenderTarget && OO.push(this._refractionTexture)
        }
        hasTexture(OO) {
          return this._thicknessTexture === OO || (this._refractionTexture === OO || (this._refractionIntensityTexture === OO || (this._translucencyIntensityTexture === OO || this._translucencyColorTexture === OO)))
        }
        hasRenderTargetTextures() {
          return !!(WO.e.RefractionTextureEnabled && this._refractionTexture && this._refractionTexture.isRenderTarget)
        }
        getActiveTextures(OO) {
          this._thicknessTexture && OO.push(this._thicknessTexture), this._refractionTexture && OO.push(this._refractionTexture), this._refractionIntensityTexture && OO.push(this._refractionIntensityTexture), this._translucencyColorTexture && OO.push(this._translucencyColorTexture), this._translucencyIntensityTexture && OO.push(this._translucencyIntensityTexture)
        }
        getAnimatables(OO) {
          this._thicknessTexture && this._thicknessTexture.animations && this._thicknessTexture.animations.length > 0 && OO.push(this._thicknessTexture), this._refractionTexture && this._refractionTexture.animations && this._refractionTexture.animations.length > 0 && OO.push(this._refractionTexture), this._refractionIntensityTexture && this._refractionIntensityTexture.animations && this._refractionIntensityTexture.animations.length > 0 && OO.push(this._refractionIntensityTexture), this._translucencyColorTexture && this._translucencyColorTexture.animations && this._translucencyColorTexture.animations.length > 0 && OO.push(this._translucencyColorTexture), this._translucencyIntensityTexture && this._translucencyIntensityTexture.animations && this._translucencyIntensityTexture.animations.length > 0 && OO.push(this._translucencyIntensityTexture)
        }
        dispose(OO) {
          OO && (this._thicknessTexture && this._thicknessTexture.dispose(), this._refractionTexture && this._refractionTexture.dispose(), this._refractionIntensityTexture && this._refractionIntensityTexture.dispose(), this._translucencyColorTexture && this._translucencyColorTexture.dispose(), this._translucencyIntensityTexture && this._translucencyIntensityTexture.dispose())
        }
        getClassName() {
          return "PBRSubSurfaceConfiguration"
        }
        addFallbacks(OO, KO, pO) {
          return OO.SS_SCATTERING && KO.addFallback(pO++, "SS_SCATTERING"), OO.SS_TRANSLUCENCY && KO.addFallback(pO++, "SS_TRANSLUCENCY"), pO
        }
        getSamplers(OO) {
          OO.push("thicknessSampler", "refractionIntensitySampler", "translucencyIntensitySampler", "refractionSampler", "refractionSamplerLow", "refractionSamplerHigh", "translucencyColorSampler")
        }
        getUniforms() {
          return {
            ubo: [{
              name: "vRefractionMicrosurfaceInfos",
              size: 4,
              type: "vec4"
            }, {
              name: "vRefractionFilteringInfo",
              size: 2,
              type: "vec2"
            }, {
              name: "vTranslucencyIntensityInfos",
              size: 2,
              type: "vec2"
            }, {
              name: "vRefractionInfos",
              size: 4,
              type: "vec4"
            }, {
              name: "refractionMatrix",
              size: 16,
              type: "mat4"
            }, {
              name: "vThicknessInfos",
              size: 2,
              type: "vec2"
            }, {
              name: "vRefractionIntensityInfos",
              size: 2,
              type: "vec2"
            }, {
              name: "thicknessMatrix",
              size: 16,
              type: "mat4"
            }, {
              name: "refractionIntensityMatrix",
              size: 16,
              type: "mat4"
            }, {
              name: "translucencyIntensityMatrix",
              size: 16,
              type: "mat4"
            }, {
              name: "vThicknessParam",
              size: 2,
              type: "vec2"
            }, {
              name: "vDiffusionDistance",
              size: 3,
              type: "vec3"
            }, {
              name: "vTintColor",
              size: 4,
              type: "vec4"
            }, {
              name: "vSubSurfaceIntensity",
              size: 3,
              type: "vec3"
            }, {
              name: "vRefractionPosition",
              size: 3,
              type: "vec3"
            }, {
              name: "vRefractionSize",
              size: 3,
              type: "vec3"
            }, {
              name: "scatteringDiffusionProfile",
              size: 1,
              type: "float"
            }, {
              name: "dispersion",
              size: 1,
              type: "float"
            }, {
              name: "vTranslucencyColor",
              size: 4,
              type: "vec4"
            }, {
              name: "vTranslucencyColorInfos",
              size: 2,
              type: "vec2"
            }, {
              name: "translucencyColorMatrix",
              size: 16,
              type: "mat4"
            }]
          }
        }
      }, KO = new WeakMap, pO = new WeakMap, XO = new WeakMap, bK = new WeakMap, eO = new WeakMap, lO = new WeakMap, vK = new WeakMap, CO = new WeakMap, hO = new WeakMap, DO = new WeakMap, MO = new WeakMap, aK = new WeakMap, oO = new WeakMap, FO = new WeakMap, VO = new WeakMap, LO = new WeakMap, (() => {
        const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(pK[Symbol.metadata] ?? null) : void 0;
        QO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], zK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], AO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], fO = [(0, gK.M)(), (0, gK.h)("_markScenePrePassDirty")], dO = [(0, gK.M)()], TO = [(0, gK.M)()], NO = [(0, gK.M)()], IO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], uO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], EO = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], jK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], YO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], wO = [(0, gK.M)()], iK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], rK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], PO = [(0, gK.M)()], mK = [(0, gK.M)()], sO = [(0, gK.M)()], RO = [(0, gK.r)()], SO = [(0, gK.M)()], cK = [(0, gK.M)()], BO = [(0, gK.r)()], ZO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], qK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], xK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], nO = [(0, gK.r)()], tK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], UO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], OK = [(0, gK.M)()], KK = [(0, gK.M)()], (0, yK.f)(OO, null, QO, {
          kind: "accessor",
          name: "isRefractionEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isRefractionEnabled" in OO,
            get: OO => OO.isRefractionEnabled,
            set: (OO, KO) => {
              OO.isRefractionEnabled = KO
            }
          },
          metadata: KO
        }, XK, bp), (0, yK.f)(OO, null, zK, {
          kind: "accessor",
          name: "isTranslucencyEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isTranslucencyEnabled" in OO,
            get: OO => OO.isTranslucencyEnabled,
            set: (OO, KO) => {
              OO.isTranslucencyEnabled = KO
            }
          },
          metadata: KO
        }, eK, lK), (0, yK.f)(OO, null, AO, {
          kind: "accessor",
          name: "isDispersionEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isDispersionEnabled" in OO,
            get: OO => OO.isDispersionEnabled,
            set: (OO, KO) => {
              OO.isDispersionEnabled = KO
            }
          },
          metadata: KO
        }, CK, hK), (0, yK.f)(OO, null, fO, {
          kind: "accessor",
          name: "isScatteringEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isScatteringEnabled" in OO,
            get: OO => OO.isScatteringEnabled,
            set: (OO, KO) => {
              OO.isScatteringEnabled = KO
            }
          },
          metadata: KO
        }, DK, MK), (0, yK.f)(OO, null, IO, {
          kind: "accessor",
          name: "useAlbedoToTintRefraction",
          static: !1,
          private: !1,
          access: {
            has: OO => "useAlbedoToTintRefraction" in OO,
            get: OO => OO.useAlbedoToTintRefraction,
            set: (OO, KO) => {
              OO.useAlbedoToTintRefraction = KO
            }
          },
          metadata: KO
        }, zp, AK), (0, yK.f)(OO, null, uO, {
          kind: "accessor",
          name: "useAlbedoToTintTranslucency",
          static: !1,
          private: !1,
          access: {
            has: OO => "useAlbedoToTintTranslucency" in OO,
            get: OO => OO.useAlbedoToTintTranslucency,
            set: (OO, KO) => {
              OO.useAlbedoToTintTranslucency = KO
            }
          },
          metadata: KO
        }, fK, dK), (0, yK.f)(OO, null, EO, {
          kind: "accessor",
          name: "thicknessTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "thicknessTexture" in OO,
            get: OO => OO.thicknessTexture,
            set: (OO, KO) => {
              OO.thicknessTexture = KO
            }
          },
          metadata: KO
        }, TK, NK), (0, yK.f)(OO, null, jK, {
          kind: "accessor",
          name: "refractionTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "refractionTexture" in OO,
            get: OO => OO.refractionTexture,
            set: (OO, KO) => {
              OO.refractionTexture = KO
            }
          },
          metadata: KO
        }, IK, yp), (0, yK.f)(OO, null, YO, {
          kind: "accessor",
          name: "indexOfRefraction",
          static: !1,
          private: !1,
          access: {
            has: OO => "indexOfRefraction" in OO,
            get: OO => OO.indexOfRefraction,
            set: (OO, KO) => {
              OO.indexOfRefraction = KO
            }
          },
          metadata: KO
        }, gp, uK), (0, yK.f)(OO, null, iK, {
          kind: "accessor",
          name: "invertRefractionY",
          static: !1,
          private: !1,
          access: {
            has: OO => "invertRefractionY" in OO,
            get: OO => OO.invertRefractionY,
            set: (OO, KO) => {
              OO.invertRefractionY = KO
            }
          },
          metadata: KO
        }, YK, wK), (0, yK.f)(OO, null, rK, {
          kind: "accessor",
          name: "linkRefractionWithTransparency",
          static: !1,
          private: !1,
          access: {
            has: OO => "linkRefractionWithTransparency" in OO,
            get: OO => OO.linkRefractionWithTransparency,
            set: (OO, KO) => {
              OO.linkRefractionWithTransparency = KO
            }
          },
          metadata: KO
        }, ip, rp), (0, yK.f)(OO, null, ZO, {
          kind: "accessor",
          name: "useMaskFromThicknessTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "useMaskFromThicknessTexture" in OO,
            get: OO => OO.useMaskFromThicknessTexture,
            set: (OO, KO) => {
              OO.useMaskFromThicknessTexture = KO
            }
          },
          metadata: KO
        }, WK, tp), (0, yK.f)(OO, null, qK, {
          kind: "accessor",
          name: "refractionIntensityTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "refractionIntensityTexture" in OO,
            get: OO => OO.refractionIntensityTexture,
            set: (OO, KO) => {
              OO.refractionIntensityTexture = KO
            }
          },
          metadata: KO
        }, kp, UK), (0, yK.f)(OO, null, xK, {
          kind: "accessor",
          name: "translucencyIntensityTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "translucencyIntensityTexture" in OO,
            get: OO => OO.translucencyIntensityTexture,
            set: (OO, KO) => {
              OO.translucencyIntensityTexture = KO
            }
          },
          metadata: KO
        }, Op, Kp), (0, yK.f)(OO, null, tK, {
          kind: "accessor",
          name: "translucencyColorTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "translucencyColorTexture" in OO,
            get: OO => OO.translucencyColorTexture,
            set: (OO, KO) => {
              OO.translucencyColorTexture = KO
            }
          },
          metadata: KO
        }, bX, ep), (0, yK.f)(OO, null, UO, {
          kind: "accessor",
          name: "useGltfStyleTextures",
          static: !1,
          private: !1,
          access: {
            has: OO => "useGltfStyleTextures" in OO,
            get: OO => OO.useGltfStyleTextures,
            set: (OO, KO) => {
              OO.useGltfStyleTextures = KO
            }
          },
          metadata: KO
        }, lp, vX), (0, yK.f)(null, null, dO, {
          kind: "field",
          name: "_scatteringDiffusionProfileIndex",
          static: !1,
          private: !1,
          access: {
            has: OO => "_scatteringDiffusionProfileIndex" in OO,
            get: OO => OO._scatteringDiffusionProfileIndex,
            set: (OO, KO) => {
              OO._scatteringDiffusionProfileIndex = KO
            }
          },
          metadata: KO
        }, ap, oK), (0, yK.f)(null, null, TO, {
          kind: "field",
          name: "refractionIntensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "refractionIntensity" in OO,
            get: OO => OO.refractionIntensity,
            set: (OO, KO) => {
              OO.refractionIntensity = KO
            }
          },
          metadata: KO
        }, FK, VK), (0, yK.f)(null, null, NO, {
          kind: "field",
          name: "translucencyIntensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "translucencyIntensity" in OO,
            get: OO => OO.translucencyIntensity,
            set: (OO, KO) => {
              OO.translucencyIntensity = KO
            }
          },
          metadata: KO
        }, LK, QK), (0, yK.f)(null, null, wO, {
          kind: "field",
          name: "_volumeIndexOfRefraction",
          static: !1,
          private: !1,
          access: {
            has: OO => "_volumeIndexOfRefraction" in OO,
            get: OO => OO._volumeIndexOfRefraction,
            set: (OO, KO) => {
              OO._volumeIndexOfRefraction = KO
            }
          },
          metadata: KO
        }, EK, jp), (0, yK.f)(null, null, PO, {
          kind: "field",
          name: "minimumThickness",
          static: !1,
          private: !1,
          access: {
            has: OO => "minimumThickness" in OO,
            get: OO => OO.minimumThickness,
            set: (OO, KO) => {
              OO.minimumThickness = KO
            }
          },
          metadata: KO
        }, PK, mp), (0, yK.f)(null, null, mK, {
          kind: "field",
          name: "maximumThickness",
          static: !1,
          private: !1,
          access: {
            has: OO => "maximumThickness" in OO,
            get: OO => OO.maximumThickness,
            set: (OO, KO) => {
              OO.maximumThickness = KO
            }
          },
          metadata: KO
        }, sK, HK), (0, yK.f)(null, null, sO, {
          kind: "field",
          name: "useThicknessAsDepth",
          static: !1,
          private: !1,
          access: {
            has: OO => "useThicknessAsDepth" in OO,
            get: OO => OO.useThicknessAsDepth,
            set: (OO, KO) => {
              OO.useThicknessAsDepth = KO
            }
          },
          metadata: KO
        }, RK, SK), (0, yK.f)(null, null, RO, {
          kind: "field",
          name: "tintColor",
          static: !1,
          private: !1,
          access: {
            has: OO => "tintColor" in OO,
            get: OO => OO.tintColor,
            set: (OO, KO) => {
              OO.tintColor = KO
            }
          },
          metadata: KO
        }, JK, cp), (0, yK.f)(null, null, SO, {
          kind: "field",
          name: "tintColorAtDistance",
          static: !1,
          private: !1,
          access: {
            has: OO => "tintColorAtDistance" in OO,
            get: OO => OO.tintColorAtDistance,
            set: (OO, KO) => {
              OO.tintColorAtDistance = KO
            }
          },
          metadata: KO
        }, BK, ZK), (0, yK.f)(null, null, cK, {
          kind: "field",
          name: "dispersion",
          static: !1,
          private: !1,
          access: {
            has: OO => "dispersion" in OO,
            get: OO => OO.dispersion,
            set: (OO, KO) => {
              OO.dispersion = KO
            }
          },
          metadata: KO
        }, GK, qp), (0, yK.f)(null, null, BO, {
          kind: "field",
          name: "diffusionDistance",
          static: !1,
          private: !1,
          access: {
            has: OO => "diffusionDistance" in OO,
            get: OO => OO.diffusionDistance,
            set: (OO, KO) => {
              OO.diffusionDistance = KO
            }
          },
          metadata: KO
        }, xp, nK), (0, yK.f)(null, null, nO, {
          kind: "field",
          name: "translucencyColor",
          static: !1,
          private: !1,
          access: {
            has: OO => "translucencyColor" in OO,
            get: OO => OO.translucencyColor,
            set: (OO, KO) => {
              OO.translucencyColor = KO
            }
          },
          metadata: KO
        }, pp, Xp), (0, yK.f)(null, null, OK, {
          kind: "field",
          name: "applyAlbedoAfterSubSurface",
          static: !1,
          private: !1,
          access: {
            has: OO => "applyAlbedoAfterSubSurface" in OO,
            get: OO => OO.applyAlbedoAfterSubSurface,
            set: (OO, KO) => {
              OO.applyAlbedoAfterSubSurface = KO
            }
          },
          metadata: KO
        }, Cp, hp), (0, yK.f)(null, null, KK, {
          kind: "field",
          name: "legacyTranslucency",
          static: !1,
          private: !1,
          access: {
            has: OO => "legacyTranslucency" in OO,
            get: OO => OO.legacyTranslucency,
            set: (OO, KO) => {
              OO.legacyTranslucency = KO
            }
          },
          metadata: KO
        }, Dp, Mp), KO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: KO
        })
      })(), OO.DEFAULT_APPLY_ALBEDO_AFTERSUBSURFACE = !1, OO.DEFAULT_LEGACY_TRANSLUCENCY = !1, OO
    })();
    var hK = pO(38452),
      DK = pO(38431),
      MK = pO(38460),
      ap = pO(38464),
      oK = pO(38471),
      FK = pO(38480),
      VK = pO(38488),
      LK = pO(38496),
      QK = pO(37938);
    const zp = {
      effect: null,
      subMesh: null
    };
    class AK extends((0, VK.c)((0, FK.c)(SO.e))) {}
    class fK extends((0, qK.f)(AK)) {
      constructor(OO) {
        super(OO), this.PBR = !0, this.NUM_SAMPLES = "0", this.REALTIME_FILTERING = !1, this.IBL_CDF_FILTERING = !1, this.ALBEDO = !1, this.GAMMAALBEDO = !1, this.ALBEDODIRECTUV = 0, this.VERTEXCOLOR = !1, this.BASE_WEIGHT = !1, this.BASE_WEIGHTDIRECTUV = 0, this.BASE_DIFFUSE_ROUGHNESS = !1, this.BASE_DIFFUSE_ROUGHNESSDIRECTUV = 0, this.BAKED_VERTEX_ANIMATION_TEXTURE = !1, this.AMBIENT = !1, this.AMBIENTDIRECTUV = 0, this.AMBIENTINGRAYSCALE = !1, this.OPACITY = !1, this.VERTEXALPHA = !1, this.OPACITYDIRECTUV = 0, this.OPACITYRGB = !1, this.ALPHATEST = !1, this.DEPTHPREPASS = !1, this.ALPHABLEND = !1, this.ALPHAFROMALBEDO = !1, this.ALPHATESTVALUE = "0.5", this.SPECULAROVERALPHA = !1, this.RADIANCEOVERALPHA = !1, this.ALPHAFRESNEL = !1, this.LINEARALPHAFRESNEL = !1, this.PREMULTIPLYALPHA = !1, this.EMISSIVE = !1, this.EMISSIVEDIRECTUV = 0, this.GAMMAEMISSIVE = !1, this.REFLECTIVITY = !1, this.REFLECTIVITY_GAMMA = !1, this.REFLECTIVITYDIRECTUV = 0, this.SPECULARTERM = !1, this.MICROSURFACEFROMREFLECTIVITYMAP = !1, this.MICROSURFACEAUTOMATIC = !1, this.LODBASEDMICROSFURACE = !1, this.MICROSURFACEMAP = !1, this.MICROSURFACEMAPDIRECTUV = 0, this.METALLICWORKFLOW = !1, this.ROUGHNESSSTOREINMETALMAPALPHA = !1, this.ROUGHNESSSTOREINMETALMAPGREEN = !1, this.METALLNESSSTOREINMETALMAPBLUE = !1, this.AOSTOREINMETALMAPRED = !1, this.METALLIC_REFLECTANCE = !1, this.METALLIC_REFLECTANCE_GAMMA = !1, this.METALLIC_REFLECTANCEDIRECTUV = 0, this.METALLIC_REFLECTANCE_USE_ALPHA_ONLY = !1, this.REFLECTANCE = !1, this.REFLECTANCE_GAMMA = !1, this.REFLECTANCEDIRECTUV = 0, this.ENVIRONMENTBRDF = !1, this.ENVIRONMENTBRDF_RGBD = !1, this.NORMAL = !1, this.TANGENT = !1, this.BUMP = !1, this.BUMPDIRECTUV = 0, this.OBJECTSPACE_NORMALMAP = !1, this.PARALLAX = !1, this.PARALLAX_RHS = !1, this.PARALLAXOCCLUSION = !1, this.NORMALXYSCALE = !0, this.LIGHTMAP = !1, this.LIGHTMAPDIRECTUV = 0, this.USELIGHTMAPASSHADOWMAP = !1, this.GAMMALIGHTMAP = !1, this.RGBDLIGHTMAP = !1, this.REFLECTION = !1, this.REFLECTIONMAP_3D = !1, this.REFLECTIONMAP_SPHERICAL = !1, this.REFLECTIONMAP_PLANAR = !1, this.REFLECTIONMAP_CUBIC = !1, this.USE_LOCAL_REFLECTIONMAP_CUBIC = !1, this.REFLECTIONMAP_PROJECTION = !1, this.REFLECTIONMAP_SKYBOX = !1, this.REFLECTIONMAP_EXPLICIT = !1, this.REFLECTIONMAP_EQUIRECTANGULAR = !1, this.REFLECTIONMAP_EQUIRECTANGULAR_FIXED = !1, this.REFLECTIONMAP_MIRROREDEQUIRECTANGULAR_FIXED = !1, this.INVERTCUBICMAP = !1, this.USESPHERICALFROMREFLECTIONMAP = !1, this.USEIRRADIANCEMAP = !1, this.USE_IRRADIANCE_DOMINANT_DIRECTION = !1, this.USESPHERICALINVERTEX = !1, this.REFLECTIONMAP_OPPOSITEZ = !1, this.LODINREFLECTIONALPHA = !1, this.GAMMAREFLECTION = !1, this.RGBDREFLECTION = !1, this.LINEARSPECULARREFLECTION = !1, this.RADIANCEOCCLUSION = !1, this.HORIZONOCCLUSION = !1, this.INSTANCES = !1, this.THIN_INSTANCES = !1, this.INSTANCESCOLOR = !1, this.NUM_BONE_INFLUENCERS = 0, this.BonesPerMesh = 0, this.BONETEXTURE = !1, this.BONES_VELOCITY_ENABLED = !1, this.NONUNIFORMSCALING = !1, this.MORPHTARGETS = !1, this.MORPHTARGETS_POSITION = !1, this.MORPHTARGETS_NORMAL = !1, this.MORPHTARGETS_TANGENT = !1, this.MORPHTARGETS_UV = !1, this.MORPHTARGETS_UV2 = !1, this.MORPHTARGETS_COLOR = !1, this.MORPHTARGETTEXTURE_HASPOSITIONS = !1, this.MORPHTARGETTEXTURE_HASNORMALS = !1, this.MORPHTARGETTEXTURE_HASTANGENTS = !1, this.MORPHTARGETTEXTURE_HASUVS = !1, this.MORPHTARGETTEXTURE_HASUV2S = !1, this.MORPHTARGETTEXTURE_HASCOLORS = !1, this.NUM_MORPH_INFLUENCERS = 0, this.MORPHTARGETS_TEXTURE = !1, this.MULTIVIEW = !1, this.ORDER_INDEPENDENT_TRANSPARENCY = !1, this.ORDER_INDEPENDENT_TRANSPARENCY_16BITS = !1, this.USEPHYSICALLIGHTFALLOFF = !1, this.USEGLTFLIGHTFALLOFF = !1, this.TWOSIDEDLIGHTING = !1, this.MIRRORED = !1, this.SHADOWFLOAT = !1, this.CLIPPLANE = !1, this.CLIPPLANE2 = !1, this.CLIPPLANE3 = !1, this.CLIPPLANE4 = !1, this.CLIPPLANE5 = !1, this.CLIPPLANE6 = !1, this.POINTSIZE = !1, this.FOG = !1, this.LOGARITHMICDEPTH = !1, this.CAMERA_ORTHOGRAPHIC = !1, this.CAMERA_PERSPECTIVE = !1, this.AREALIGHTSUPPORTED = !0, this.FORCENORMALFORWARD = !1, this.SPECULARAA = !1, this.UNLIT = !1, this.DECAL_AFTER_DETAIL = !1, this.TEXTURE_REPETITION_MODE = 0, this.DEBUGMODE = 0, this.USE_VERTEX_PULLING = !1, this.VERTEX_PULLING_USE_INDEX_BUFFER = !1, this.VERTEX_PULLING_INDEX_BUFFER_32BITS = !1, this.RIGHT_HANDED = !1, this.CLUSTLIGHT_SLICES = 0, this.CLUSTLIGHT_BATCH = 0, this.rebuild()
      }
      reset() {
        super.reset(), this.ALPHATESTVALUE = "0.5", this.PBR = !0, this.NORMALXYSCALE = !0
      }
    }
    class dK extends((0, LK.e)(nO.d)) {}
    let TK = (() => {
      var OO, KO;
      let XO, bK = dK,
        lO = [],
        vK = [];
      return OO = class extends bK {
        get realTimeFiltering() {
          return this._realTimeFiltering
        }
        set realTimeFiltering(OO) {
          this._realTimeFiltering = OO, this.jhO(1)
        }
        get realTimeFilteringQuality() {
          return this._realTimeFilteringQuality
        }
        set realTimeFilteringQuality(OO) {
          this._realTimeFilteringQuality = OO, this.jhO(1)
        }
        get canRenderToMRT() {
          return !0
        }
        get debugMode() {
          return (0, yK.b)(this, KO, "f")
        }
        set debugMode(OO) {
          (0, yK.e)(this, KO, OO, "f")
        }
        constructor(pO, XO) {
          super(pO, XO, void 0, arguments.length > 2 && void 0 !== arguments[2] && arguments[2] || OO.ForceGLSL), this._directIntensity = 1, this._emissiveIntensity = 1, this._environmentIntensity = 1, this._specularIntensity = 1, this._lightingInfos = new HO.s(this._directIntensity, this._emissiveIntensity, this._environmentIntensity, this._specularIntensity), this._disableBumpMap = !1, this._albedoTexture = null, this._baseWeightTexture = null, this._baseDiffuseRoughnessTexture = null, this._ambientTexture = null, this._ambientTextureStrength = 1, this._ambientTextureImpactOnAnalyticalLights = OO.DEFAULT_AO_ON_ANALYTICAL_LIGHTS, this._opacityTexture = null, this._reflectionTexture = null, this._emissiveTexture = null, this._reflectivityTexture = null, this._metallicTexture = null, this._metallic = null, this._roughness = null, this._metallicF0Factor = 1, this._metallicReflectanceColor = GO.e.White(), this._useOnlyMetallicFromMetallicReflectanceTexture = !1, this._metallicReflectanceTexture = null, this._reflectanceTexture = null, this._microSurfaceTexture = null, this._bumpTexture = null, this._lightmapTexture = null, this._ambientColor = new GO.e(0, 0, 0), this._albedoColor = new GO.e(1, 1, 1), this._baseWeight = 1, this._baseDiffuseRoughness = null, this._reflectivityColor = new GO.e(1, 1, 1), this._reflectionColor = new GO.e(1, 1, 1), this._emissiveColor = new GO.e(0, 0, 0), this._microSurface = .9, this._useLightmapAsShadowmap = !1, this._useHorizonOcclusion = !0, this._useRadianceOcclusion = !0, this._useAlphaFromAlbedoTexture = !1, this._useSpecularOverAlpha = !0, this._useMicroSurfaceFromReflectivityMapAlpha = !1, this._useRoughnessFromMetallicTextureAlpha = !0, this._useRoughnessFromMetallicTextureGreen = !1, this._useMetallnessFromMetallicTextureBlue = !1, this._useAmbientOcclusionFromMetallicTextureRed = !1, this._useAmbientInGrayScale = !1, this._useAutoMicroSurfaceFromReflectivityMap = !1, this._lightFalloff = OO.LIGHTFALLOFF_PHYSICAL, this._useRadianceOverAlpha = !0, this._useObjectSpaceNormalMap = !1, this._useParallax = !1, this._useParallaxOcclusion = !1, this._parallaxScaleBias = .05, this._disableLighting = !1, this._maxSimultaneousLights = 4, this._invertNormalMapX = !1, this._invertNormalMapY = !1, this._twoSidedLighting = !1, this._alphaCutOff = .4, this._useAlphaFresnel = !1, this._useLinearAlphaFresnel = !1, this._environmentBRDFTexture = null, this._forceIrradianceInFragment = !1, this._realTimeFiltering = !1, this._realTimeFilteringQuality = 8, this._forceNormalForward = !1, this._enableSpecularAntiAliasing = !1, this._renderTargets = new EO.e(16), this._globalAmbientColor = new GO.e(0, 0, 0), this._unlit = !1, this._applyDecalMapAfterDetailMap = !1, this._debugMode = 0, this._breakShaderLoadedCheck = !1, this._vertexPullingMetadata = null, KO.set(this, (0, yK.i)(this, lO, 0)), this.debugLimit = ((0, yK.i)(this, vK), -1), this.debugFactor = 1, this._cacheHasRenderTargetTextures = !1, this.brdf = new BO(this), this.clearCoat = new OK(this), this.iridescence = new pK(this), this.anisotropy = new bp(this), this.sheen = new lK(this), this.subSurface = new CK(this), this.detailMap = new hK.e(this), this._attachImageProcessingConfiguration(null), this.getRenderTargetTextures = () => (this._renderTargets.reset(), WO.e.ReflectionTextureEnabled && this._reflectionTexture && this._reflectionTexture.isRenderTarget && this._renderTargets.push(this._reflectionTexture), this._eventInfo.renderTargets = this._renderTargets, this._callbackPluginEventFillRenderTargetTextures(this._eventInfo), this._renderTargets), this._environmentBRDFTexture = rK(this.JKO()), this.prePassConfiguration = new ZO.c
        }
        get hasRenderTargetTextures() {
          return !!(WO.e.ReflectionTextureEnabled && this._reflectionTexture && this._reflectionTexture.isRenderTarget) || this._cacheHasRenderTargetTextures
        }
        get isPrePassCapable() {
          return !this.disableDepthWrite
        }
        getClassName() {
          return "PBRBaseMaterial"
        }
        get _disableAlphaBlending() {
          return this._transparencyMode === OO.PBRMATERIAL_OPAQUE || this._transparencyMode === OO.PBRMATERIAL_ALPHATEST || this.subSurface?.disableAlphaBlending
        }
        needAlphaBlending() {
          return this._hasTransparencyMode ? this._transparencyModeIsBlend : !this._disableAlphaBlending && (this.alpha < 1 || null != this._opacityTexture || this._shouldUseAlphaFromAlbedoTexture())
        }
        needAlphaTesting() {
          return this._hasTransparencyMode ? this._transparencyModeIsTest : !this.subSurface?.disableAlphaBlending && (this._hasAlphaChannel() && (null == this._transparencyMode || this._transparencyMode === OO.PBRMATERIAL_ALPHATEST))
        }
        _shouldUseAlphaFromAlbedoTexture() {
          return null != this._albedoTexture && this._albedoTexture.hasAlpha && this._useAlphaFromAlbedoTexture && this._transparencyMode !== OO.PBRMATERIAL_OPAQUE
        }
        _hasAlphaChannel() {
          return null != this._albedoTexture && this._albedoTexture.hasAlpha || null != this._opacityTexture
        }
        getAlphaTestTexture() {
          return this._albedoTexture
        }
        isReadyForSubMesh(OO, KO, pO) {
          this._uniformBufferLayoutBuilt || this.buildUniformLayout();
          const XO = KO._drawWrapper;
          if (XO.effect && this.isFrozen && XO._wasPreviouslyReady && XO._wasPreviouslyUsingInstances === pO) return !0;
          KO.materialDefines || (this._callbackPluginEventGeneric(4, this._eventInfo), KO.materialDefines = new fK(this._eventInfo.defineNames));
          const bK = KO.materialDefines;
          if (this._isReadyForSubMesh(KO)) return !0;
          const eO = this.JKO(),
            lO = eO.qb();
          if (bK._areTexturesDirty && (this._eventInfo.hasRenderTargetTextures = !1, this._callbackPluginEventHasRenderTargetTextures(this._eventInfo), this._cacheHasRenderTargetTextures = this._eventInfo.hasRenderTargetTextures, eO.texturesEnabled)) {
            if (this._albedoTexture && WO.e.DiffuseTextureEnabled && !this._albedoTexture.isReadyOrNotBlocking()) return !1;
            if (this._baseWeightTexture && WO.e.BaseWeightTextureEnabled && !this._baseWeightTexture.isReadyOrNotBlocking()) return !1;
            if (this._baseDiffuseRoughnessTexture && WO.e.BaseDiffuseRoughnessTextureEnabled && !this._baseDiffuseRoughnessTexture.isReadyOrNotBlocking()) return !1;
            if (this._ambientTexture && WO.e.AmbientTextureEnabled && !this._ambientTexture.isReadyOrNotBlocking()) return !1;
            if (this._opacityTexture && WO.e.OpacityTextureEnabled && !this._opacityTexture.isReadyOrNotBlocking()) return !1;
            const OO = this._getReflectionTexture();
            if (OO && WO.e.ReflectionTextureEnabled) {
              if (!OO.isReadyOrNotBlocking()) return !1;
              if (OO.irradianceTexture) {
                if (!OO.irradianceTexture.isReadyOrNotBlocking()) return !1
              } else if (!OO.sphericalPolynomial && OO.getInternalTexture()?._sphericalPolynomialPromise) return !1
            }
            if (this._lightmapTexture && WO.e.LightmapTextureEnabled && !this._lightmapTexture.isReadyOrNotBlocking()) return !1;
            if (this._emissiveTexture && WO.e.EmissiveTextureEnabled && !this._emissiveTexture.isReadyOrNotBlocking()) return !1;
            if (WO.e.SpecularTextureEnabled) {
              if (this._metallicTexture) {
                if (!this._metallicTexture.isReadyOrNotBlocking()) return !1
              } else if (this._reflectivityTexture && !this._reflectivityTexture.isReadyOrNotBlocking()) return !1;
              if (this._metallicReflectanceTexture && !this._metallicReflectanceTexture.isReadyOrNotBlocking()) return !1;
              if (this._reflectanceTexture && !this._reflectanceTexture.isReadyOrNotBlocking()) return !1;
              if (this._microSurfaceTexture && !this._microSurfaceTexture.isReadyOrNotBlocking()) return !1
            }
            if (lO.getCaps().standardDerivatives && this._bumpTexture && WO.e.BumpTextureEnabled && !this._disableBumpMap && !this._bumpTexture.isReady()) return !1;
            if (this._environmentBRDFTexture && WO.e.ReflectionTextureEnabled && !this._environmentBRDFTexture.isReady()) return !1
          }
          if (this._eventInfo.isReadyForSubMesh = !0, this._eventInfo.defines = bK, this._eventInfo.subMesh = KO, this._callbackPluginEventIsReadyForSubMesh(this._eventInfo), !this._eventInfo.isReadyForSubMesh) return !1;
          if (bK._areImageProcessingDirty && this._imageProcessingConfiguration && !this._imageProcessingConfiguration.isReady()) return !1;
          if (bK.AREALIGHTUSED || bK.CLUSTLIGHT_BATCH)
            for (let MO = 0; MO < OO.lightSources.length; MO++)
              if (!OO.lightSources[MO]._isReady()) return !1;
          if (lO.getCaps().standardDerivatives || OO.isVerticesDataPresent(RO.j.NormalKind) || (OO.createNormals(!0), uO.b.Warn("PBRMaterial: Normals have been created for the mesh: " + OO.name)), !(0, kK.c)(eO, OO, this._maxSimultaneousLights, this._disableLighting)) return !1;
          const vK = KO.effect,
            CO = bK._areLightsDisposed,
            hO = this._prepareEffect(OO, KO.getRenderingMesh(), bK, this.onCompiled, this.onError, pO, null);
          let DO = !1;
          if (hO)
            if (this._onEffectCreatedObservable && (zp.effect = hO, zp.subMesh = KO, this._onEffectCreatedObservable.notifyObservers(zp)), this.allowShaderHotSwapping && vK && !hO.isReady()) {
              if (bK.markAsUnprocessed(), DO = this.isFrozen, CO) return bK._areLightsDisposed = !0, !1
            } else eO.resetCachedMaterial(), KO.setEffect(hO, bK, this._materialContext);
          return !(!KO.effect || !KO.effect.isReady()) && (bK._renderId = eO.getRenderId(), XO._wasPreviouslyReady = !DO, XO._wasPreviouslyUsingInstances = !!pO, this._checkScenePerformancePriority(), !0)
        }
        isMetallicWorkflow() {
          return !(null == this._metallic && null == this._roughness && !this._metallicTexture)
        }
        _prepareEffect(KO, pO, XO) {
          let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
            eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
            lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
            vK = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null;
          if (this._prepareDefines(KO, pO, XO, lO, vK), !XO.isDirty) return null;
          XO.markAsProcessed();
          const CO = this.JKO().qb(),
            hO = new tK.c;
          let DO = 0;
          XO.USESPHERICALINVERTEX && hO.addFallback(DO++, "USESPHERICALINVERTEX"), XO.FOG && hO.addFallback(DO, "FOG"), XO.SPECULARAA && hO.addFallback(DO, "SPECULARAA"), XO.POINTSIZE && hO.addFallback(DO, "POINTSIZE"), XO.LOGARITHMICDEPTH && hO.addFallback(DO, "LOGARITHMICDEPTH"), XO.PARALLAX && hO.addFallback(DO, "PARALLAX"), XO.PARALLAX_RHS && hO.addFallback(DO, "PARALLAX_RHS"), XO.PARALLAXOCCLUSION && hO.addFallback(DO++, "PARALLAXOCCLUSION"), XO.ENVIRONMENTBRDF && hO.addFallback(DO++, "ENVIRONMENTBRDF"), XO.TANGENT && hO.addFallback(DO++, "TANGENT"), XO.BUMP && hO.addFallback(DO++, "BUMP"), DO = (0, kK.F)(XO, hO, this._maxSimultaneousLights, DO), XO.SPECULARTERM && hO.addFallback(DO++, "SPECULARTERM"), XO.USESPHERICALFROMREFLECTIONMAP && hO.addFallback(DO++, "USESPHERICALFROMREFLECTIONMAP"), XO.USEIRRADIANCEMAP && hO.addFallback(DO++, "USEIRRADIANCEMAP"), XO.LIGHTMAP && hO.addFallback(DO++, "LIGHTMAP"), XO.NORMAL && hO.addFallback(DO++, "NORMAL"), XO.AMBIENT && hO.addFallback(DO++, "AMBIENT"), XO.EMISSIVE && hO.addFallback(DO++, "EMISSIVE"), XO.VERTEXCOLOR && hO.addFallback(DO++, "VERTEXCOLOR"), XO.MORPHTARGETS && hO.addFallback(DO++, "MORPHTARGETS"), XO.MULTIVIEW && hO.addFallback(0, "MULTIVIEW");
          const MO = [RO.j.PositionKind];
          XO.NORMAL && MO.push(RO.j.NormalKind), XO.TANGENT && MO.push(RO.j.TangentKind);
          for (let OO = 1; OO <= 6; ++OO) XO["UV" + OO] && MO.push(`uv${1===OO?"":OO}`);
          XO.VERTEXCOLOR && MO.push(RO.j.ColorKind), (0, kK.H)(MO, KO, XO, hO), (0, kK.L)(MO, XO), (0, kK.N)(MO, KO, XO), (0, kK.G)(MO, KO, XO);
          let aK = "pbr";
          const oO = ["world", "view", "viewProjection", "vEyePosition", "vLightsType", "vAmbientColor", "vAlbedoColor", "baseWeight", "baseDiffuseRoughness", "vReflectivityColor", "vMetallicReflectanceFactors", "vEmissiveColor", "visibility", "vFogInfos", "vFogColor", "pointSize", "vAlbedoInfos", "vBaseWeightInfos", "vBaseDiffuseRoughnessInfos", "vAmbientInfos", "vOpacityInfos", "vEmissiveInfos", "vReflectivityInfos", "vMetallicReflectanceInfos", "vReflectanceInfos", "vMicroSurfaceSamplerInfos", "vBumpInfos", "vLightmapInfos", "mBones", "albedoMatrix", "baseWeightMatrix", "baseDiffuseRoughnessMatrix", "ambientMatrix", "opacityMatrix", "emissiveMatrix", "reflectivityMatrix", "normalMatrix", "microSurfaceSamplerMatrix", "bumpMatrix", "lightmapMatrix", "metallicReflectanceMatrix", "reflectanceMatrix", "vLightingIntensity", "logarithmicDepthConstant", "vTangentSpaceParams", "boneTextureInfo", "vDebugMode", "morphTargetTextureInfo", "morphTargetTextureIndices", "cameraInfo", "vTextureRepetitionHexTilingParams"],
            FO = ["albedoSampler", "baseWeightSampler", "baseDiffuseRoughnessSampler", "reflectivitySampler", "ambientSampler", "emissiveSampler", "bumpSampler", "lightmapSampler", "opacitySampler", "microSurfaceSampler", "environmentBrdfSampler", "boneSampler", "metallicReflectanceSampler", "reflectanceSampler", "morphTargets", "oitDepthSampler", "oitFrontColorSampler", "areaLightsLTC1Sampler", "areaLightsLTC2Sampler"];
          (0, kK.rb)(oO, FO, !0);
          const VO = ["Material", "Scene", "Mesh"],
            LO = {
              maxSimultaneousLights: this._maxSimultaneousLights,
              maxSimultaneousMorphTargets: XO.NUM_MORPH_INFLUENCERS
            };
          if (this._eventInfo.fallbacks = hO, this._eventInfo.fallbackRank = DO, this._eventInfo.defines = XO, this._eventInfo.uniforms = oO, this._eventInfo.attributes = MO, this._eventInfo.samplers = FO, this._eventInfo.uniformBuffersNames = VO, this._eventInfo.customCode = void 0, this._eventInfo.mesh = KO, this._eventInfo.indexParameters = LO, this._callbackPluginEventGeneric(128, this._eventInfo), oK.d.AddUniformsAndSamplers(oO, FO), ZO.c.AddUniforms(oO), ZO.c.AddSamplers(FO), (0, DK.c)(oO), this._useVertexPulling) {
            const OO = pO?.geometry;
            OO && (this._vertexPullingMetadata = (0, MK.e)(OO), this._vertexPullingMetadata && this._vertexPullingMetadata.forEach(((OO, KO) => {
              oO.push(`vp_${KO}_info`)
            })))
          } else this._vertexPullingMetadata = null;
          xK.d && (xK.d.PrepareUniforms(oO, XO), xK.d.PrepareSamplers(FO, XO)), (0, kK.ub)({
            uniformsNames: oO,
            uniformBuffersNames: VO,
            samplers: FO,
            defines: XO,
            maxSimultaneousLights: this._maxSimultaneousLights,
            shaderLanguage: this._shaderLanguage
          });
          const QO = {};
          this.customShaderNameResolve && (aK = this.customShaderNameResolve(aK, oO, VO, FO, XO, MO, QO));
          const zK = XO.toString(),
            AO = CO.createEffect(aK, {
              attributes: MO,
              uniformsNames: oO,
              uniformBuffersNames: VO,
              samplers: FO,
              defines: zK,
              fallbacks: hO,
              onCompiled: bK,
              onError: eO,
              indexParameters: LO,
              processFinalCode: QO.processFinalCode,
              processCodeAfterIncludes: this._eventInfo.customCode,
              multiTarget: XO.PREPASS,
              shaderLanguage: this._shaderLanguage,
              extraInitializationsAsync: OO._ShaderLoader.getLoadCallback(this._shaderLanguage)
            }, CO);
          return this._eventInfo.customCode = void 0, AO
        }
        _prepareDefines(KO, pO, XO) {
          let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
            eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
          const lO = pO.hasThinInstances,
            vK = this.JKO(),
            CO = vK.qb();
          (0, kK._)(vK, KO, XO, !0, this._maxSimultaneousLights, this._disableLighting), XO._needNormals = !0, (0, kK.hb)(vK, XO);
          const hO = this.needAlphaBlendingForMesh(KO) && this.JKO().useOrderIndependentTransparency;
          if ((0, kK.mb)(vK, XO, this.canRenderToMRT && !hO), (0, kK.ib)(vK, XO, hO), oK.d.PrepareDefines(CO.currentRenderPassId, KO, XO), XO.METALLICWORKFLOW = this.isMetallicWorkflow(), XO._areTexturesDirty) {
            XO._needUVs = !1;
            for (let OO = 1; OO <= 6; ++OO) XO["MAINUV" + OO] = !1;
            if (vK.texturesEnabled) {
              XO.ALBEDODIRECTUV = 0, XO.BASE_WEIGHTDIRECTUV = 0, XO.BASE_DIFFUSE_ROUGHNESSDIRECTUV = 0, XO.AMBIENTDIRECTUV = 0, XO.OPACITYDIRECTUV = 0, XO.EMISSIVEDIRECTUV = 0, XO.REFLECTIVITYDIRECTUV = 0, XO.MICROSURFACEMAPDIRECTUV = 0, XO.METALLIC_REFLECTANCEDIRECTUV = 0, XO.REFLECTANCEDIRECTUV = 0, XO.BUMPDIRECTUV = 0, XO.LIGHTMAPDIRECTUV = 0, CO.getCaps().textureLOD && (XO.LODBASEDMICROSFURACE = !0), this._albedoTexture && WO.e.DiffuseTextureEnabled ? ((0, kK.bb)(this._albedoTexture, XO, "ALBEDO"), XO.GAMMAALBEDO = this._albedoTexture.gammaSpace) : XO.ALBEDO = !1, this._baseWeightTexture && WO.e.BaseWeightTextureEnabled ? (0, kK.bb)(this._baseWeightTexture, XO, "BASE_WEIGHT") : XO.BASE_WEIGHT = !1, this._baseDiffuseRoughnessTexture && WO.e.BaseDiffuseRoughnessTextureEnabled ? (0, kK.bb)(this._baseDiffuseRoughnessTexture, XO, "BASE_DIFFUSE_ROUGHNESS") : XO.BASE_DIFFUSE_ROUGHNESS = !1, this._ambientTexture && WO.e.AmbientTextureEnabled ? ((0, kK.bb)(this._ambientTexture, XO, "AMBIENT"), XO.AMBIENTINGRAYSCALE = this._useAmbientInGrayScale) : XO.AMBIENT = !1, this._opacityTexture && WO.e.OpacityTextureEnabled ? ((0, kK.bb)(this._opacityTexture, XO, "OPACITY"), XO.OPACITYRGB = this._opacityTexture.getAlphaFromRGB) : XO.OPACITY = !1;
              const OO = this._getReflectionTexture(),
                KO = this._forceIrradianceInFragment || this.realTimeFiltering || this._twoSidedLighting || CO.getCaps().maxVaryingVectors <= 8 || null != this._baseDiffuseRoughnessTexture;
              (0, kK.Z)(vK, OO, XO, this.realTimeFiltering, this.realTimeFilteringQuality, !KO), this._lightmapTexture && WO.e.LightmapTextureEnabled ? ((0, kK.bb)(this._lightmapTexture, XO, "LIGHTMAP"), XO.USELIGHTMAPASSHADOWMAP = this._useLightmapAsShadowmap, XO.GAMMALIGHTMAP = this._lightmapTexture.gammaSpace, XO.RGBDLIGHTMAP = this._lightmapTexture.isRGBD) : XO.LIGHTMAP = !1, this._emissiveTexture && WO.e.EmissiveTextureEnabled ? ((0, kK.bb)(this._emissiveTexture, XO, "EMISSIVE"), XO.GAMMAEMISSIVE = this._emissiveTexture.gammaSpace) : XO.EMISSIVE = !1, WO.e.SpecularTextureEnabled ? (this._metallicTexture ? ((0, kK.bb)(this._metallicTexture, XO, "REFLECTIVITY"), XO.ROUGHNESSSTOREINMETALMAPALPHA = this._useRoughnessFromMetallicTextureAlpha, XO.ROUGHNESSSTOREINMETALMAPGREEN = !this._useRoughnessFromMetallicTextureAlpha && this._useRoughnessFromMetallicTextureGreen, XO.METALLNESSSTOREINMETALMAPBLUE = this._useMetallnessFromMetallicTextureBlue, XO.AOSTOREINMETALMAPRED = this._useAmbientOcclusionFromMetallicTextureRed, XO.REFLECTIVITY_GAMMA = !1) : this._reflectivityTexture ? ((0, kK.bb)(this._reflectivityTexture, XO, "REFLECTIVITY"), XO.MICROSURFACEFROMREFLECTIVITYMAP = this._useMicroSurfaceFromReflectivityMapAlpha, XO.MICROSURFACEAUTOMATIC = this._useAutoMicroSurfaceFromReflectivityMap, XO.REFLECTIVITY_GAMMA = this._reflectivityTexture.gammaSpace) : XO.REFLECTIVITY = !1, this._metallicReflectanceTexture || this._reflectanceTexture ? (XO.METALLIC_REFLECTANCE_USE_ALPHA_ONLY = this._useOnlyMetallicFromMetallicReflectanceTexture, this._metallicReflectanceTexture ? ((0, kK.bb)(this._metallicReflectanceTexture, XO, "METALLIC_REFLECTANCE"), XO.METALLIC_REFLECTANCE_GAMMA = this._metallicReflectanceTexture.gammaSpace) : XO.METALLIC_REFLECTANCE = !1, this._reflectanceTexture && (!this._metallicReflectanceTexture || this._metallicReflectanceTexture && this._useOnlyMetallicFromMetallicReflectanceTexture) ? ((0, kK.bb)(this._reflectanceTexture, XO, "REFLECTANCE"), XO.REFLECTANCE_GAMMA = this._reflectanceTexture.gammaSpace) : XO.REFLECTANCE = !1) : (XO.METALLIC_REFLECTANCE = !1, XO.REFLECTANCE = !1), this._microSurfaceTexture ? (0, kK.bb)(this._microSurfaceTexture, XO, "MICROSURFACEMAP") : XO.MICROSURFACEMAP = !1) : (XO.REFLECTIVITY = !1, XO.MICROSURFACEMAP = !1), CO.getCaps().standardDerivatives && this._bumpTexture && WO.e.BumpTextureEnabled && !this._disableBumpMap ? ((0, kK.bb)(this._bumpTexture, XO, "BUMP"), this._useParallax && this._albedoTexture && WO.e.DiffuseTextureEnabled ? (XO.PARALLAX = !0, XO.PARALLAX_RHS = vK.useRightHandedSystem, XO.PARALLAXOCCLUSION = !!this._useParallaxOcclusion) : XO.PARALLAX = !1, XO.OBJECTSPACE_NORMALMAP = this._useObjectSpaceNormalMap) : (XO.BUMP = !1, XO.PARALLAX = !1, XO.PARALLAX_RHS = !1, XO.PARALLAXOCCLUSION = !1, XO.OBJECTSPACE_NORMALMAP = !1), this._environmentBRDFTexture && WO.e.ReflectionTextureEnabled ? (XO.ENVIRONMENTBRDF = !0, XO.ENVIRONMENTBRDF_RGBD = this._environmentBRDFTexture.isRGBD) : (XO.ENVIRONMENTBRDF = !1, XO.ENVIRONMENTBRDF_RGBD = !1), this._shouldUseAlphaFromAlbedoTexture() ? XO.ALPHAFROMALBEDO = !0 : XO.ALPHAFROMALBEDO = !1
            }
            XO.SPECULAROVERALPHA = this._useSpecularOverAlpha, this._lightFalloff === OO.LIGHTFALLOFF_STANDARD ? (XO.USEPHYSICALLIGHTFALLOFF = !1, XO.USEGLTFLIGHTFALLOFF = !1) : this._lightFalloff === OO.LIGHTFALLOFF_GLTF ? (XO.USEPHYSICALLIGHTFALLOFF = !1, XO.USEGLTFLIGHTFALLOFF = !0) : (XO.USEPHYSICALLIGHTFALLOFF = !0, XO.USEGLTFLIGHTFALLOFF = !1), XO.RADIANCEOVERALPHA = this._useRadianceOverAlpha, !this.backFaceCulling && this._twoSidedLighting ? XO.TWOSIDEDLIGHTING = !0 : XO.TWOSIDEDLIGHTING = !1, XO.MIRRORED = !!vK._mirroredCameraPosition, XO.SPECULARAA = CO.getCaps().standardDerivatives && this._enableSpecularAntiAliasing
          }(XO._areTexturesDirty || XO._areMiscDirty) && (XO.ALPHATESTVALUE = `${this._alphaCutOff}${this._alphaCutOff%1===0?".":""}`, XO.PREMULTIPLYALPHA = 7 === this.alphaMode || 8 === this.alphaMode, XO.ALPHABLEND = this.needAlphaBlendingForMesh(KO), XO.ALPHAFRESNEL = this._useAlphaFresnel || this._useLinearAlphaFresnel, XO.LINEARALPHAFRESNEL = this._useLinearAlphaFresnel), XO._areTexturesDirty && (XO.TEXTURE_REPETITION_MODE = CO.version > 1 || CO.isWebGPU ? this.textureRepetitionMode : 0), XO._areImageProcessingDirty && this._imageProcessingConfiguration && this._imageProcessingConfiguration.prepareDefines(XO), XO.FORCENORMALFORWARD = this._forceNormalForward, XO.RADIANCEOCCLUSION = this._useRadianceOcclusion, XO.HORIZONOCCLUSION = this._useHorizonOcclusion, XO._areMiscDirty && ((0, kK.fb)(KO, vK, this._useLogarithmicDepth, this.pointsCloud, this.fogEnabled, this.needAlphaTestingForMesh(KO), XO, this._applyDecalMapAfterDetailMap, this._useVertexPulling, pO, this._isVertexOutputInvariant), XO.UNLIT = this._unlit || (this.pointsCloud || this.wireframe) && !KO.isVerticesDataPresent(RO.j.NormalKind), XO.DEBUGMODE = this._debugMode), (0, kK.V)(vK, CO, this, XO, !!bK, eO, lO), this._eventInfo.defines = XO, this._eventInfo.mesh = KO, this._callbackPluginEventPrepareDefinesBeforeAttributes(this._eventInfo), (0, kK.S)(KO, XO, !0, !0, !0, this._transparencyMode !== OO.PBRMATERIAL_OPAQUE), this._callbackPluginEventPrepareDefines(this._eventInfo)
        }
        forceCompilation(OO, KO, pO) {
          const XO = {
            clipPlane: !1,
            useInstances: !1,
            ...pO
          };
          this._uniformBufferLayoutBuilt || this.buildUniformLayout(), this._callbackPluginEventGeneric(4, this._eventInfo);
          (() => {
            if (this._breakShaderLoadedCheck) return;
            const pO = new fK(this._eventInfo.defineNames),
              bK = this._prepareEffect(OO, OO, pO, void 0, void 0, XO.useInstances, XO.clipPlane);
            this._onEffectCreatedObservable && (zp.effect = bK, zp.subMesh = null, this._onEffectCreatedObservable.notifyObservers(zp)), bK.isReady() ? KO && KO(this) : bK.onCompileObservable.add((() => {
              KO && KO(this)
            }))
          })()
        }
        buildUniformLayout() {
          const OO = this._uniformBuffer;
          OO.addUniform("vAlbedoInfos", 2), OO.addUniform("vBaseWeightInfos", 2), OO.addUniform("vBaseDiffuseRoughnessInfos", 2), OO.addUniform("vAmbientInfos", 4), OO.addUniform("vOpacityInfos", 2), OO.addUniform("vEmissiveInfos", 2), OO.addUniform("vLightmapInfos", 2), OO.addUniform("vReflectivityInfos", 3), OO.addUniform("vMicroSurfaceSamplerInfos", 2), OO.addUniform("vBumpInfos", 3), OO.addUniform("albedoMatrix", 16), OO.addUniform("baseWeightMatrix", 16), OO.addUniform("baseDiffuseRoughnessMatrix", 16), OO.addUniform("ambientMatrix", 16), OO.addUniform("opacityMatrix", 16), OO.addUniform("emissiveMatrix", 16), OO.addUniform("lightmapMatrix", 16), OO.addUniform("reflectivityMatrix", 16), OO.addUniform("microSurfaceSamplerMatrix", 16), OO.addUniform("bumpMatrix", 16), OO.addUniform("vTangentSpaceParams", 2), OO.addUniform("vAlbedoColor", 4), OO.addUniform("baseWeight", 1), OO.addUniform("baseDiffuseRoughness", 1), OO.addUniform("vLightingIntensity", 4), OO.addUniform("pointSize", 1), OO.addUniform("vReflectivityColor", 4), OO.addUniform("vEmissiveColor", 3), OO.addUniform("vAmbientColor", 3), OO.addUniform("vDebugMode", 2), OO.addUniform("vMetallicReflectanceFactors", 4), OO.addUniform("vMetallicReflectanceInfos", 2), OO.addUniform("metallicReflectanceMatrix", 16), OO.addUniform("vReflectanceInfos", 2), OO.addUniform("reflectanceMatrix", 16), OO.addUniform("cameraInfo", 4), OO.addUniform("vTextureRepetitionHexTilingParams", 4), (0, kK.nb)(OO, !0, !0, !0, !0, !0), super.buildUniformLayout()
        }
        bindForSubMesh(OO, KO, pO) {
          const XO = this.JKO(),
            bK = pO.materialDefines;
          if (!bK) return;
          const eO = pO.effect;
          if (!eO) return;
          this._activeEffect = eO, KO.getMeshUniformBuffer().bindToEffect(eO, "Mesh"), KO.transferToEffect(OO);
          const lO = XO.qb();
          this._uniformBuffer.bindToEffect(eO, "Material"), this.prePassConfiguration.bindForSubMesh(this._activeEffect, XO, KO, OO, this.isFrozen), oK.d.Bind(lO.currentRenderPassId, this._activeEffect, KO, OO, this);
          const vK = XO.activeCamera;
          vK ? this._uniformBuffer.updateFloat4("cameraInfo", vK.minZ, vK.maxZ, 0, 0) : this._uniformBuffer.updateFloat4("cameraInfo", 0, 0, 0, 0);
          const CO = this.textureRepetitionHexTilingParams;
          this._uniformBuffer.updateFloat4("vTextureRepetitionHexTilingParams", CO[0], CO[1], CO[2], CO[3]), this._eventInfo.subMesh = pO, this._callbackPluginEventHardBindForSubMesh(this._eventInfo), bK.OBJECTSPACE_NORMALMAP && (OO.toNormalMatrix(this._normalMatrix), this.bindOnlyNormalMatrix(this._normalMatrix));
          const hO = this._mustRebind(XO, eO, pO, KO.visibility),
            DO = lO._features.needToAlwaysBindUniformBuffers;
          (0, kK.g)(KO, this._activeEffect, this.prePassConfiguration), this._vertexPullingMetadata && (0, MK.c)(this._activeEffect, this._vertexPullingMetadata);
          let MO = null;
          const aK = this._uniformBuffer;
          if (hO) {
            if (this.bindViewProjection(eO), MO = this._getReflectionTexture(), !aK.useUbo || !this.isFrozen || !aK.isSync || pO._drawWrapper._forceRebindOnNextCall) {
              if (XO.texturesEnabled && (this._albedoTexture && WO.e.DiffuseTextureEnabled && (aK.updateFloat2("vAlbedoInfos", this._albedoTexture.coordinatesIndex, this._albedoTexture.level), (0, kK.B)(this._albedoTexture, aK, "albedo")), this._baseWeightTexture && WO.e.BaseWeightTextureEnabled && (aK.updateFloat2("vBaseWeightInfos", this._baseWeightTexture.coordinatesIndex, this._baseWeightTexture.level), (0, kK.B)(this._baseWeightTexture, aK, "baseWeight")), this._baseDiffuseRoughnessTexture && WO.e.BaseDiffuseRoughnessTextureEnabled && (aK.updateFloat2("vBaseDiffuseRoughnessInfos", this._baseDiffuseRoughnessTexture.coordinatesIndex, this._baseDiffuseRoughnessTexture.level), (0, kK.B)(this._baseDiffuseRoughnessTexture, aK, "baseDiffuseRoughness")), this._ambientTexture && WO.e.AmbientTextureEnabled && (aK.updateFloat4("vAmbientInfos", this._ambientTexture.coordinatesIndex, this._ambientTexture.level, this._ambientTextureStrength, this._ambientTextureImpactOnAnalyticalLights), (0, kK.B)(this._ambientTexture, aK, "ambient")), this._opacityTexture && WO.e.OpacityTextureEnabled && (aK.updateFloat2("vOpacityInfos", this._opacityTexture.coordinatesIndex, this._opacityTexture.level), (0, kK.B)(this._opacityTexture, aK, "opacity")), this._emissiveTexture && WO.e.EmissiveTextureEnabled && (aK.updateFloat2("vEmissiveInfos", this._emissiveTexture.coordinatesIndex, this._emissiveTexture.level), (0, kK.B)(this._emissiveTexture, aK, "emissive")), this._lightmapTexture && WO.e.LightmapTextureEnabled && (aK.updateFloat2("vLightmapInfos", this._lightmapTexture.coordinatesIndex, this._lightmapTexture.level), (0, kK.B)(this._lightmapTexture, aK, "lightmap")), WO.e.SpecularTextureEnabled && (this._metallicTexture ? (aK.updateFloat3("vReflectivityInfos", this._metallicTexture.coordinatesIndex, this._metallicTexture.level, this._ambientTextureStrength), (0, kK.B)(this._metallicTexture, aK, "reflectivity")) : this._reflectivityTexture && (aK.updateFloat3("vReflectivityInfos", this._reflectivityTexture.coordinatesIndex, this._reflectivityTexture.level, 1), (0, kK.B)(this._reflectivityTexture, aK, "reflectivity")), this._metallicReflectanceTexture && (aK.updateFloat2("vMetallicReflectanceInfos", this._metallicReflectanceTexture.coordinatesIndex, this._metallicReflectanceTexture.level), (0, kK.B)(this._metallicReflectanceTexture, aK, "metallicReflectance")), this._reflectanceTexture && bK.REFLECTANCE && (aK.updateFloat2("vReflectanceInfos", this._reflectanceTexture.coordinatesIndex, this._reflectanceTexture.level), (0, kK.B)(this._reflectanceTexture, aK, "reflectance")), this._microSurfaceTexture && (aK.updateFloat2("vMicroSurfaceSamplerInfos", this._microSurfaceTexture.coordinatesIndex, this._microSurfaceTexture.level), (0, kK.B)(this._microSurfaceTexture, aK, "microSurfaceSampler"))), this._bumpTexture && lO.getCaps().standardDerivatives && WO.e.BumpTextureEnabled && !this._disableBumpMap && (aK.updateFloat3("vBumpInfos", this._bumpTexture.coordinatesIndex, this._bumpTexture.level, this._parallaxScaleBias), (0, kK.B)(this._bumpTexture, aK, "bump"), XO._mirroredCameraPosition ? aK.updateFloat2("vTangentSpaceParams", this._invertNormalMapX ? 1 : -1, this._invertNormalMapY ? 1 : -1) : aK.updateFloat2("vTangentSpaceParams", this._invertNormalMapX ? -1 : 1, this._invertNormalMapY ? -1 : 1)), (0, kK.k)(XO, bK, aK, this._reflectionColor, MO, this.realTimeFiltering, !0, !0, !0, !0, !0)), this.pointsCloud && aK.updateFloat("pointSize", this.pointSize), bK.METALLICWORKFLOW) {
                GO.j.Color4[0].r = void 0 === this._metallic || null === this._metallic ? 1 : this._metallic, GO.j.Color4[0].g = void 0 === this._roughness || null === this._roughness ? 1 : this._roughness;
                const OO = this.subSurface?._indexOfRefraction ?? 1.5,
                  KO = 1;
                GO.j.Color4[0].b = OO;
                const pO = Math.pow((OO - KO) / (OO + KO), 2);
                GO.j.Color4[0].a = pO, aK.updateDirectColor4("vReflectivityColor", GO.j.Color4[0]), aK.updateColor4("vMetallicReflectanceFactors", this._metallicReflectanceColor, this._metallicF0Factor)
              } else aK.updateColor4("vReflectivityColor", this._reflectivityColor, this._microSurface);
              aK.updateColor3("vEmissiveColor", WO.e.EmissiveTextureEnabled ? this._emissiveColor : GO.e.BlackReadOnly), !bK.SS_REFRACTION && this.subSurface?._linkRefractionWithTransparency ? aK.updateColor4("vAlbedoColor", this._albedoColor, 1) : aK.updateColor4("vAlbedoColor", this._albedoColor, this.alpha), aK.updateFloat("baseWeight", this._baseWeight), aK.updateFloat("baseDiffuseRoughness", this._baseDiffuseRoughness || 0), this._lightingInfos.x = this._directIntensity, this._lightingInfos.y = this._emissiveIntensity, this._lightingInfos.z = this._environmentIntensity * XO.environmentIntensity, this._lightingInfos.w = this._specularIntensity, aK.updateVector4("vLightingIntensity", this._lightingInfos), XO.ambientColor.multiplyToRef(this._ambientColor, this._globalAmbientColor), aK.updateColor3("vAmbientColor", this._globalAmbientColor), aK.updateFloat2("vDebugMode", this.debugLimit, this.debugFactor)
            }
            XO.texturesEnabled && (this._albedoTexture && WO.e.DiffuseTextureEnabled && aK.setTexture("albedoSampler", this._albedoTexture), this._baseWeightTexture && WO.e.BaseWeightTextureEnabled && aK.setTexture("baseWeightSampler", this._baseWeightTexture), this._baseDiffuseRoughnessTexture && WO.e.BaseDiffuseRoughnessTextureEnabled && aK.setTexture("baseDiffuseRoughnessSampler", this._baseDiffuseRoughnessTexture), this._ambientTexture && WO.e.AmbientTextureEnabled && aK.setTexture("ambientSampler", this._ambientTexture), this._opacityTexture && WO.e.OpacityTextureEnabled && aK.setTexture("opacitySampler", this._opacityTexture), (0, kK.n)(XO, bK, aK, MO, this.realTimeFiltering), bK.ENVIRONMENTBRDF && aK.setTexture("environmentBrdfSampler", this._environmentBRDFTexture), this._emissiveTexture && WO.e.EmissiveTextureEnabled && aK.setTexture("emissiveSampler", this._emissiveTexture), this._lightmapTexture && WO.e.LightmapTextureEnabled && aK.setTexture("lightmapSampler", this._lightmapTexture), WO.e.SpecularTextureEnabled && (this._metallicTexture ? aK.setTexture("reflectivitySampler", this._metallicTexture) : this._reflectivityTexture && aK.setTexture("reflectivitySampler", this._reflectivityTexture), this._metallicReflectanceTexture && aK.setTexture("metallicReflectanceSampler", this._metallicReflectanceTexture), this._reflectanceTexture && bK.REFLECTANCE && aK.setTexture("reflectanceSampler", this._reflectanceTexture), this._microSurfaceTexture && aK.setTexture("microSurfaceSampler", this._microSurfaceTexture)), this._bumpTexture && lO.getCaps().standardDerivatives && WO.e.BumpTextureEnabled && !this._disableBumpMap && aK.setTexture("bumpSampler", this._bumpTexture)), this.JKO().useOrderIndependentTransparency && this.needAlphaBlendingForMesh(KO) && this.JKO().depthPeelingRenderer.bind(eO), this._eventInfo.subMesh = pO, this._callbackPluginEventBindForSubMesh(this._eventInfo), (0, DK.e)(this._activeEffect, this, XO), this.bindEyePosition(eO)
          } else DO && (this._needToBindSceneUbo = !0);
          !hO && this.isFrozen && !DO || !XO.lightsEnabled || this._disableLighting || (0, kK.r)(XO, KO, this._activeEffect, bK, this._maxSimultaneousLights), !hO && this.isFrozen || ((XO.fogEnabled && KO.applyFog && XO.fogMode !== sO.e.FOGMODE_NONE || MO || this.subSurface.refractionTexture || KO.receiveShadows || bK.PREPASS || bK.CLUSTLIGHT_BATCH) && this.bindView(eO), (0, kK.i)(XO, KO, this._activeEffect, !0), bK.NUM_MORPH_INFLUENCERS && (0, kK.w)(KO, this._activeEffect), bK.BAKED_VERTEX_ANIMATION_TEXTURE && KO.bakedVertexAnimationManager?.bind(eO, bK.INSTANCES), this._imageProcessingConfiguration.bind(this._activeEffect), (0, kK.s)(bK, this._activeEffect, XO)), this._afterBind(KO, this._activeEffect, pO), aK.update()
        }
        getAnimatables() {
          const OO = super.getAnimatables();
          return this._albedoTexture && this._albedoTexture.animations && this._albedoTexture.animations.length > 0 && OO.push(this._albedoTexture), this._baseWeightTexture && this._baseWeightTexture.animations && this._baseWeightTexture.animations.length > 0 && OO.push(this._baseWeightTexture), this._baseDiffuseRoughnessTexture && this._baseDiffuseRoughnessTexture.animations && this._baseDiffuseRoughnessTexture.animations.length > 0 && OO.push(this._baseDiffuseRoughnessTexture), this._ambientTexture && this._ambientTexture.animations && this._ambientTexture.animations.length > 0 && OO.push(this._ambientTexture), this._opacityTexture && this._opacityTexture.animations && this._opacityTexture.animations.length > 0 && OO.push(this._opacityTexture), this._reflectionTexture && this._reflectionTexture.animations && this._reflectionTexture.animations.length > 0 && OO.push(this._reflectionTexture), this._emissiveTexture && this._emissiveTexture.animations && this._emissiveTexture.animations.length > 0 && OO.push(this._emissiveTexture), this._metallicTexture && this._metallicTexture.animations && this._metallicTexture.animations.length > 0 ? OO.push(this._metallicTexture) : this._reflectivityTexture && this._reflectivityTexture.animations && this._reflectivityTexture.animations.length > 0 && OO.push(this._reflectivityTexture), this._bumpTexture && this._bumpTexture.animations && this._bumpTexture.animations.length > 0 && OO.push(this._bumpTexture), this._lightmapTexture && this._lightmapTexture.animations && this._lightmapTexture.animations.length > 0 && OO.push(this._lightmapTexture), this._metallicReflectanceTexture && this._metallicReflectanceTexture.animations && this._metallicReflectanceTexture.animations.length > 0 && OO.push(this._metallicReflectanceTexture), this._reflectanceTexture && this._reflectanceTexture.animations && this._reflectanceTexture.animations.length > 0 && OO.push(this._reflectanceTexture), this._microSurfaceTexture && this._microSurfaceTexture.animations && this._microSurfaceTexture.animations.length > 0 && OO.push(this._microSurfaceTexture), OO
        }
        _getReflectionTexture() {
          return this._reflectionTexture ? this._reflectionTexture : this.JKO().environmentTexture
        }
        getActiveTextures() {
          const OO = super.getActiveTextures();
          return this._albedoTexture && OO.push(this._albedoTexture), this._baseWeightTexture && OO.push(this._baseWeightTexture), this._baseDiffuseRoughnessTexture && OO.push(this._baseDiffuseRoughnessTexture), this._ambientTexture && OO.push(this._ambientTexture), this._opacityTexture && OO.push(this._opacityTexture), this._reflectionTexture && OO.push(this._reflectionTexture), this._emissiveTexture && OO.push(this._emissiveTexture), this._reflectivityTexture && OO.push(this._reflectivityTexture), this._metallicTexture && OO.push(this._metallicTexture), this._metallicReflectanceTexture && OO.push(this._metallicReflectanceTexture), this._reflectanceTexture && OO.push(this._reflectanceTexture), this._microSurfaceTexture && OO.push(this._microSurfaceTexture), this._bumpTexture && OO.push(this._bumpTexture), this._lightmapTexture && OO.push(this._lightmapTexture), OO
        }
        hasTexture(OO) {
          return !!super.hasTexture(OO) || (this._albedoTexture === OO || (this._baseWeightTexture === OO || (this._baseDiffuseRoughnessTexture === OO || (this._ambientTexture === OO || (this._opacityTexture === OO || (this._reflectionTexture === OO || (this._emissiveTexture === OO || (this._reflectivityTexture === OO || (this._metallicTexture === OO || (this._metallicReflectanceTexture === OO || (this._reflectanceTexture === OO || (this._microSurfaceTexture === OO || (this._bumpTexture === OO || this._lightmapTexture === OO)))))))))))))
        }
        setPrePassRenderer() {
          if (!this.subSurface?.isScatteringEnabled) return !1;
          const OO = this.JKO().enableSubSurfaceForPrePass();
          return OO && (OO.enabled = !0), !0
        }
        dispose(OO, KO) {
          this._breakShaderLoadedCheck = !0, KO && (this._environmentBRDFTexture && this.JKO().environmentBRDFTexture !== this._environmentBRDFTexture && this._environmentBRDFTexture.dispose(), this._albedoTexture?.dispose(), this._baseWeightTexture?.dispose(), this._baseDiffuseRoughnessTexture?.dispose(), this._ambientTexture?.dispose(), this._opacityTexture?.dispose(), this._reflectionTexture?.dispose(), this._emissiveTexture?.dispose(), this._metallicTexture?.dispose(), this._reflectivityTexture?.dispose(), this._bumpTexture?.dispose(), this._lightmapTexture?.dispose(), this._metallicReflectanceTexture?.dispose(), this._reflectanceTexture?.dispose(), this._microSurfaceTexture?.dispose()), this._renderTargets.dispose(), this._imageProcessingConfiguration && this._imageProcessingObserver && this._imageProcessingConfiguration.onUpdateParameters.remove(this._imageProcessingObserver), super.dispose(OO, KO)
        }
      }, KO = new WeakMap, (() => {
        const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(bK[Symbol.metadata] ?? null) : void 0;
        XO = [(0, gK.h)("_markAllSubMeshesAsMiscDirty")], (0, yK.f)(OO, null, XO, {
          kind: "accessor",
          name: "debugMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "debugMode" in OO,
            get: OO => OO.debugMode,
            set: (OO, KO) => {
              OO.debugMode = KO
            }
          },
          metadata: KO
        }, lO, vK), KO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: KO
        })
      })(), OO.PBRMATERIAL_OPAQUE = eO.b.MATERIAL_OPAQUE, OO.PBRMATERIAL_ALPHATEST = eO.b.MATERIAL_ALPHATEST, OO.PBRMATERIAL_ALPHABLEND = eO.b.MATERIAL_ALPHABLEND, OO.PBRMATERIAL_ALPHATESTANDBLEND = eO.b.MATERIAL_ALPHATESTANDBLEND, OO.DEFAULT_AO_ON_ANALYTICAL_LIGHTS = 0, OO.LIGHTFALLOFF_PHYSICAL = 0, OO.LIGHTFALLOFF_GLTF = 1, OO.LIGHTFALLOFF_STANDARD = 2, OO.ForceGLSL = !1, OO._ShaderLoader = new ap.e((() => [Promise.all([pO.e(297), pO.e(308)]).then((() => pO(59425))), Promise.all([pO.e(302), pO.e(298), pO.e(360), pO.e(311), pO.e(359)]).then((() => pO(59449)))]), (() => [Promise.all([pO.e(316), pO.e(318), pO.e(325)]).then((() => pO(59525))), Promise.all([pO.e(316), pO.e(319), pO.e(363), pO.e(329), pO.e(362)]).then((() => pO(59556)))])), OO
    })();
    Object.getOwnPropertyDescriptor(TK.prototype, "decalMap") || Object.defineProperty(TK.prototype, "decalMap", (0, QK.e)("PBRBaseMaterial", "decalMap")), (0, pO(39849).c)();
    var NK = pO(38077);
    var IK = pO(38172),
      yp = pO(39833),
      gp = pO(37889),
      uK = pO(37899),
      EK = pO(38004);
    let jp = !1;
    const YK = new GO.g,
      wK = new GO.g;
    class ip extends yp.e {
      get isSupported() {
        return this._engine?.getCaps().drawBuffersExtension ?? !1
      }
      get textures() {
        return this._textures
      }
      get count() {
        return this._count
      }
      get depthTexture() {
        return this._textures[this._textures.length - 1]
      }
      set wrapU(OO) {
        if (this._textures)
          for (let KO = 0; KO < this._textures.length; KO++) this._textures[KO].wrapU = OO
      }
      set wrapV(OO) {
        if (this._textures)
          for (let KO = 0; KO < this._textures.length; KO++) this._textures[KO].wrapV = OO
      }
      constructor(OO, KO, pO, XO, bK, eO) {
        const lO = !(!bK || !bK.generateMipMaps) && bK.generateMipMaps,
          vK = !(!bK || !bK.generateDepthTexture) && bK.generateDepthTexture,
          CO = bK && bK.depthTextureFormat ? bK.depthTextureFormat : 15,
          hO = !bK || void 0 === bK.doNotChangeAspectRatio || bK.doNotChangeAspectRatio,
          DO = !(!bK || !bK.drawOnlyOnFirstAttachmentByDefault) && bK.drawOnlyOnFirstAttachmentByDefault;
        if (super(OO, KO, XO, lO, hO, void 0, void 0, void 0, void 0, void 0, void 0, void 0, !0), jp || (jp = !0, uK.ThinEngine.prototype.restoreSingleAttachment = function() {
            const OO = this._gl;
            this.bindAttachments([OO.BACK])
          }, uK.ThinEngine.prototype.restoreSingleAttachmentForRenderTarget = function() {
            const OO = this._gl;
            this.bindAttachments([OO.COLOR_ATTACHMENT0])
          }, uK.ThinEngine.prototype.buildTextureLayout = function(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            const pO = this._gl,
              XO = [];
            if (KO) XO.push(pO.BACK);
            else
              for (let bK = 0; bK < OO.length; bK++) OO[bK] ? XO.push(pO["COLOR_ATTACHMENT" + bK]) : XO.push(pO.NONE);
            return XO
          }, uK.ThinEngine.prototype.bindAttachments = function(OO) {
            const KO = this._gl,
              pO = this._currentRenderTarget?.textures;
            if (this._integerMRTAttachmentsMask = 0, pO)
              for (let XO = 0; XO < OO.length; XO++) OO[XO] !== KO.NONE && pO[XO] && (0, EK.j)(pO[XO].format) && (this._integerMRTAttachmentsMask |= 1 << XO);
            KO.drawBuffers(OO)
          }, uK.ThinEngine.prototype.clearAttachments = function(OO, KO, pO, XO) {
            let bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
              eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0;
            const lO = this._currentRenderTarget?.textures;
            let vK = !1;
            if (pO && OO && lO)
              for (let CO = 0; CO < KO.length; CO++) {
                const OO = lO[CO];
                if (KO[CO] !== this._gl.NONE && OO && (0, EK.j)(OO.format)) {
                  if (this._webGLVersion < 2) throw new Error("ThinEngine.clearAttachments: integer MRT attachments require WebGL2");
                  vK = !0;
                  break
                }
              }
            if (!vK || !OO || !lO) return this.bindAttachments(KO), void this.clear(OO, pO, XO, bK, eO);
            this.bindAttachments(KO), this._applyColorWriteState();
            for (let CO = 0; CO < KO.length; CO++) {
              const pO = lO[CO];
              if (KO[CO] !== this._gl.NONE && pO) {
                let KO = OO;
                if ((0, EK.j)(pO.format)) {
                  const XO = (0, EK.k)(pO.type);
                  KO = XO ? YK : wK;
                  const bK = XO ? 255 : 1;
                  KO.r = Math.round(OO.r * bK), KO.g = Math.round(OO.g * bK), KO.b = Math.round(OO.b * bK), KO.a = Math.round(OO.a * bK)
                }
                this._clearColorAttachment(CO, KO, pO.format, pO.type)
              }
            }
            if (XO || bK) {
              const OO = this._integerMRTAttachmentsMask;
              this._integerMRTAttachmentsMask = 0;
              try {
                this.clear(null, !1, XO, bK, eO)
              } finally {
                this._integerMRTAttachmentsMask = OO
              }
            }
          }, uK.ThinEngine.prototype.unBindMultiColorAttachmentFramebuffer = function(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              pO = arguments.length > 2 ? arguments[2] : void 0;
            this._currentRenderTarget = null, this._integerMRTAttachmentsMask = 0, OO.disableAutomaticMSAAResolve || this.resolveMultiFramebuffer(OO), KO || this.generateMipMapsMultiFramebuffer(OO), pO && (OO._MSAAFramebuffer && this._bindUnboundFramebuffer(OO._framebuffer), pO()), this._bindUnboundFramebuffer(null)
          }, uK.ThinEngine.prototype.createMultipleRenderTarget = function(OO, KO) {
            let pO, XO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
              bK = !1,
              eO = !0,
              lO = !1,
              vK = !1,
              CO = 1,
              hO = 1,
              DO = [],
              MO = [],
              aK = [],
              oO = [],
              FO = [],
              VO = [],
              LO = [],
              QO = [],
              zK = [],
              AO = !1;
            const fO = this._createHardwareRenderTargetWrapper(!0, !1, OO);
            void 0 !== KO && (bK = void 0 !== KO.generateMipMaps && KO.generateMipMaps, eO = void 0 === KO.generateDepthBuffer || KO.generateDepthBuffer, lO = void 0 !== KO.generateStencilBuffer && KO.generateStencilBuffer, vK = void 0 !== KO.generateDepthTexture && KO.generateDepthTexture, CO = KO.PoO ?? 1, hO = KO.samples ?? hO, DO = KO.types || DO, MO = KO.samplingModes || MO, aK = KO.useSRGBBuffers || aK, oO = KO.formats || oO, FO = KO.targetTypes || FO, VO = KO.faceIndex || VO, LO = KO.layerIndex || LO, QO = KO.layerCounts || QO, zK = KO.labels || zK, AO = KO.dontCreateTextures ?? !1, this.ye > 1 && (13 === KO.depthTextureFormat || 17 === KO.depthTextureFormat || 16 === KO.depthTextureFormat || 14 === KO.depthTextureFormat || 18 === KO.depthTextureFormat) && (pO = KO.depthTextureFormat)), void 0 === pO && (pO = lO ? 13 : 14);
            const dO = this._gl,
              TO = this._currentFramebuffer,
              NO = dO.createFramebuffer();
            this._bindUnboundFramebuffer(NO);
            const IO = OO.width ?? OO,
              yK = OO.height ?? OO,
              gK = [],
              EO = [],
              jK = this.ye > 1 && (13 === pO || 17 === pO || 18 === pO);
            fO.label = KO?.label ?? "MultiRenderTargetWrapper", fO._framebuffer = NO, fO._generateDepthBuffer = vK || eO, fO._generateStencilBuffer = vK ? jK : lO, fO._depthStencilBuffer = this._setupFramebufferDepthAttachments(fO._generateStencilBuffer, fO._generateDepthBuffer, IO, yK, 1, pO), fO._attachments = EO;
            for (let YO = 0; YO < CO; YO++) {
              let OO = MO[YO] || 3,
                KO = DO[YO] || 0,
                pO = aK[YO] || !1;
              const XO = oO[YO] || 5,
                eO = FO[YO] || 3553,
                lO = QO[YO] ?? 1;
              (1 !== KO || this._caps.textureFloatLinearFiltering) && (2 !== KO || this._caps.textureHalfFloatLinearFiltering) || (OO = 1);
              const vK = this._getSamplingParameters(OO, bK);
              1 !== KO || this._caps.textureFloat || (KO = 0, uO.b.Warn("Float textures are not supported. Render target forced to TEXTURETYPE_UNSIGNED_BYTE type")), pO = pO && this._caps.supportSRGBBuffers && (this.ye > 1 || this.isWebGPU);
              const CO = this.ye > 1,
                hO = dO[CO ? "COLOR_ATTACHMENT" + YO : "COLOR_ATTACHMENT" + YO + "_WEBGL"];
              if (EO.push(hO), -1 === eO || AO) continue;
              const VO = new gp.e(this, 6);
              gK[YO] = VO, dO.activeTexture(dO["TEXTURE" + YO]), dO.bindTexture(eO, VO._hardwareTexture.underlyingResource), dO.texParameteri(eO, dO.TEXTURE_MAG_FILTER, vK.mag), dO.texParameteri(eO, dO.TEXTURE_MIN_FILTER, vK.min), dO.texParameteri(eO, dO.TEXTURE_WRAP_S, dO.CLAMP_TO_EDGE), dO.texParameteri(eO, dO.TEXTURE_WRAP_T, dO.CLAMP_TO_EDGE);
              const LO = this._getRGBABufferInternalSizedFormat(KO, XO, pO),
                TO = this._getInternalFormat(XO),
                NO = this._getWebGLTextureType(KO);
              if (!CO || 35866 !== eO && 32879 !== eO)
                if (34067 === eO) {
                  for (let OO = 0; OO < 6; OO++) dO.texImage2D(dO.TEXTURE_CUBE_MAP_POSITIVE_X + OO, 0, LO, IO, yK, 0, TO, NO, null);
                  VO.isCube = !0
                } else dO.texImage2D(dO.TEXTURE_2D, 0, LO, IO, yK, 0, TO, NO, null);
              else 35866 === eO ? VO.is2DArray = !0 : VO.is3D = !0, VO.baseDepth = VO.depth = lO, dO.texImage3D(eO, 0, LO, IO, yK, lO, 0, TO, NO, null);
              bK && dO.generateMipmap(eO), this._bindTextureDirectly(eO, null), VO.baseWidth = IO, VO.baseHeight = yK, VO.width = IO, VO.height = yK, VO.isReady = !0, VO.samples = 1, VO.generateMipMaps = bK, VO.samplingMode = OO, VO.type = KO, VO._useSRGBBuffer = pO, VO.format = XO, VO.label = zK[YO] ?? fO.label + "-Texture" + YO, this._internalTexturesCache.push(VO)
            }
            if (vK && this._caps.depthTextureExtension && !AO) {
              const OO = new gp.e(this, 14);
              let KO = 5,
                XO = dO.DEPTH_COMPONENT16,
                eO = dO.DEPTH_COMPONENT,
                lO = dO.UNSIGNED_SHORT,
                vK = dO.DEPTH_ATTACHMENT;
              this.ye < 2 ? XO = dO.DEPTH_COMPONENT : 14 === pO ? (KO = 1, lO = dO.FLOAT, XO = dO.DEPTH_COMPONENT32F) : 18 === pO ? (KO = 0, lO = dO.FLOAT_32_UNSIGNED_INT_24_8_REV, XO = dO.DEPTH32F_STENCIL8, eO = dO.DEPTH_STENCIL, vK = dO.DEPTH_STENCIL_ATTACHMENT) : 16 === pO ? (KO = 0, lO = dO.UNSIGNED_INT, XO = dO.DEPTH_COMPONENT24, vK = dO.DEPTH_ATTACHMENT) : 13 !== pO && 17 !== pO || (KO = 12, lO = dO.UNSIGNED_INT_24_8, XO = dO.DEPTH24_STENCIL8, eO = dO.DEPTH_STENCIL, vK = dO.DEPTH_STENCIL_ATTACHMENT), this._bindTextureDirectly(dO.TEXTURE_2D, OO, !0), dO.texParameteri(dO.TEXTURE_2D, dO.TEXTURE_MAG_FILTER, dO.NEAREST), dO.texParameteri(dO.TEXTURE_2D, dO.TEXTURE_MIN_FILTER, dO.NEAREST), dO.texParameteri(dO.TEXTURE_2D, dO.TEXTURE_WRAP_S, dO.CLAMP_TO_EDGE), dO.texParameteri(dO.TEXTURE_2D, dO.TEXTURE_WRAP_T, dO.CLAMP_TO_EDGE), dO.texImage2D(dO.TEXTURE_2D, 0, XO, IO, yK, 0, eO, lO, null), dO.framebufferTexture2D(dO.FRAMEBUFFER, vK, dO.TEXTURE_2D, OO._hardwareTexture.underlyingResource, 0), this._bindTextureDirectly(dO.TEXTURE_2D, null), fO._depthStencilTexture = OO, fO._depthStencilTextureWithStencil = jK, OO.baseWidth = IO, OO.baseHeight = yK, OO.width = IO, OO.height = yK, OO.isReady = !0, OO.samples = 1, OO.generateMipMaps = bK, OO.samplingMode = 1, OO.format = pO, OO.type = KO, OO.label = fO.label + "-DepthStencil", gK[CO] = OO, this._internalTexturesCache.push(OO)
            }
            if (fO.setTextures(gK), XO && dO.drawBuffers(EO), this._bindUnboundFramebuffer(TO), fO.setLayerAndFaceIndices(LO, VO), this.resetTextureCache(), AO) {
              if (hO > 1) {
                const OO = dO.createFramebuffer();
                if (!OO) throw new Error("Unable to create multi sampled framebuffer");
                fO._samples = hO, fO._MSAAFramebuffer = OO, CO > 0 && XO && (this._bindUnboundFramebuffer(OO), dO.drawBuffers(EO), this._bindUnboundFramebuffer(TO))
              }
            } else this.updateMultipleRenderTargetTextureSampleCount(fO, hO, XO);
            return fO
          }, uK.ThinEngine.prototype.updateMultipleRenderTargetTextureSampleCount = function(OO, KO) {
            let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
            if (this.ye < 2 || !OO) return 1;
            if (OO.samples === KO) return KO;
            const XO = this._gl;
            KO = Math.min(KO, this.getCaps().maxMSAASamples), OO._depthStencilBuffer && (XO.deleteRenderbuffer(OO._depthStencilBuffer), OO._depthStencilBuffer = null), OO._MSAAFramebuffer && (XO.deleteFramebuffer(OO._MSAAFramebuffer), OO._MSAAFramebuffer = null);
            const bK = OO._attachments.length;
            for (let lO = 0; lO < bK; lO++) {
              const KO = OO.textures[lO]._hardwareTexture;
              KO?.releaseMSAARenderBuffers()
            }
            if (KO > 1 && "function" === typeof XO.renderbufferStorageMultisample) {
              const eO = XO.createFramebuffer();
              if (!eO) throw new Error("Unable to create multi sampled framebuffer");
              OO._MSAAFramebuffer = eO, this._bindUnboundFramebuffer(eO);
              const lO = [];
              for (let pO = 0; pO < bK; pO++) {
                const bK = OO.textures[pO],
                  eO = bK._hardwareTexture,
                  vK = XO[this.ye > 1 ? "COLOR_ATTACHMENT" + pO : "COLOR_ATTACHMENT" + pO + "_WEBGL"],
                  CO = this._createRenderBuffer(bK.width, bK.height, KO, -1, this._getRGBABufferInternalSizedFormat(bK.type, bK.format, bK._useSRGBBuffer), vK);
                if (!CO) throw new Error("Unable to create multi sampled framebuffer");
                eO.addMSAARenderBuffer(CO), bK.samples = KO, lO.push(vK)
              }
              pO && XO.drawBuffers(lO)
            } else this._bindUnboundFramebuffer(OO._framebuffer);
            const eO = OO._depthStencilTexture ? OO._depthStencilTexture.format : void 0;
            return OO._depthStencilBuffer = this._setupFramebufferDepthAttachments(OO._generateStencilBuffer, OO._generateDepthBuffer, OO.width, OO.height, KO, eO), this._bindUnboundFramebuffer(null), OO._samples = KO, KO
          }, uK.ThinEngine.prototype.generateMipMapsMultiFramebuffer = function(OO) {
            const KO = OO,
              pO = this._gl;
            if (KO.isMulti)
              for (let XO = 0; XO < KO._attachments.length; XO++) {
                const OO = KO.textures[XO];
                !OO?.generateMipMaps || OO?.isCube || OO?.is3D || (this._bindTextureDirectly(pO.TEXTURE_2D, OO, !0), pO.generateMipmap(pO.TEXTURE_2D), this._bindTextureDirectly(pO.TEXTURE_2D, null))
              }
          }, uK.ThinEngine.prototype.resolveMultiFramebuffer = function(OO) {
            const KO = OO,
              pO = this._gl;
            if (!KO._MSAAFramebuffer || !KO.isMulti) return;
            let XO = KO.resolveMSAAColors ? pO.COLOR_BUFFER_BIT : 0;
            XO |= KO._generateDepthBuffer && KO.resolveMSAADepth ? pO.DEPTH_BUFFER_BIT : 0, XO |= KO._generateStencilBuffer && KO.resolveMSAAStencil ? pO.STENCIL_BUFFER_BIT : 0;
            const bK = KO._attachments,
              eO = bK.length;
            pO.bindFramebuffer(pO.READ_FRAMEBUFFER, KO._MSAAFramebuffer), pO.bindFramebuffer(pO.DRAW_FRAMEBUFFER, KO._framebuffer);
            for (let lO = 0; lO < eO; lO++) {
              const OO = KO.textures[lO];
              for (let KO = 0; KO < eO; KO++) bK[KO] = pO.NONE;
              bK[lO] = pO[this.ye > 1 ? "COLOR_ATTACHMENT" + lO : "COLOR_ATTACHMENT" + lO + "_WEBGL"], pO.readBuffer(bK[lO]), pO.drawBuffers(bK), pO.blitFramebuffer(0, 0, OO.width, OO.height, 0, 0, OO.width, OO.height, XO, pO.NEAREST)
            }
            for (let lO = 0; lO < eO; lO++) bK[lO] = pO[this.ye > 1 ? "COLOR_ATTACHMENT" + lO : "COLOR_ATTACHMENT" + lO + "_WEBGL"];
            pO.drawBuffers(bK), pO.bindFramebuffer(this._gl.FRAMEBUFFER, KO._MSAAFramebuffer)
          }), !this.isSupported) return void this.dispose();
        this._textureNames = eO;
        const MO = [],
          aK = [],
          oO = [],
          FO = [],
          VO = [],
          LO = [],
          QO = [],
          zK = [];
        this._initTypes(pO, MO, aK, oO, FO, VO, LO, QO, zK, bK);
        const AO = !bK || void 0 === bK.generateDepthBuffer || bK.generateDepthBuffer,
          fO = !(!bK || void 0 === bK.generateStencilBuffer) && bK.generateStencilBuffer,
          dO = bK && bK.samples ? bK.samples : 1;
        this._multiRenderTargetOptions = {
          samplingModes: aK,
          generateMipMaps: lO,
          generateDepthBuffer: AO,
          generateStencilBuffer: fO,
          generateDepthTexture: vK,
          depthTextureFormat: CO,
          types: MO,
          PoO: pO,
          useSRGBBuffers: oO,
          samples: dO,
          formats: FO,
          targetTypes: VO,
          faceIndex: LO,
          layerIndex: QO,
          layerCounts: zK,
          labels: eO,
          label: OO
        }, this._count = pO, this._drawOnlyOnFirstAttachmentByDefault = DO, pO > 0 && (this._createInternalTextures(), this._createTextures(eO))
      }
      _initTypes(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
        for (let DO = 0; DO < OO; DO++) hO && hO.types && void 0 !== hO.types[DO] ? KO.push(hO.types[DO]) : KO.push(hO && hO.defaultType ? hO.defaultType : 0), hO && hO.samplingModes && void 0 !== hO.samplingModes[DO] ? pO.push(hO.samplingModes[DO]) : pO.push(jK.e.BILINEAR_SAMPLINGMODE), hO && hO.useSRGBBuffers && void 0 !== hO.useSRGBBuffers[DO] ? XO.push(hO.useSRGBBuffers[DO]) : XO.push(!1), hO && hO.formats && void 0 !== hO.formats[DO] ? bK.push(hO.formats[DO]) : bK.push(5), hO && hO.targetTypes && void 0 !== hO.targetTypes[DO] ? eO.push(hO.targetTypes[DO]) : eO.push(3553), hO && hO.faceIndex && void 0 !== hO.faceIndex[DO] ? lO.push(hO.faceIndex[DO]) : lO.push(0), hO && hO.layerIndex && void 0 !== hO.layerIndex[DO] ? vK.push(hO.layerIndex[DO]) : vK.push(0), hO && hO.layerCounts && void 0 !== hO.layerCounts[DO] ? CO.push(hO.layerCounts[DO]) : CO.push(1)
      }
      _createInternaTextureIndexMapping() {
        const OO = {},
          KO = [];
        if (!this._renderTarget) return KO;
        const pO = this._renderTarget.textures;
        for (let XO = 0; XO < pO.length; XO++) {
          const bK = pO[XO];
          if (!bK) continue;
          const eO = OO[bK.uniqueId];
          void 0 !== eO ? KO[XO] = eO : OO[bK.uniqueId] = XO
        }
        return KO
      }
      _rebuild() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 ? arguments[2] : void 0;
        if (this._count < 1 || OO) return;
        const XO = this._createInternaTextureIndexMapping();
        this.releaseInternalTextures(), this._createInternalTextures(), KO && (this._releaseTextures(), this._createTextures(pO));
        const bK = this._renderTarget.textures;
        for (let eO = 0; eO < bK.length; eO++) {
          const OO = this._textures[eO];
          void 0 !== XO[eO] && this._renderTarget.setTexture(bK[XO[eO]], eO), OO._texture = bK[eO], OO._texture && (OO._noMipmap = !OO._texture.useMipMaps, OO._useSRGBBuffer = OO._texture._useSRGBBuffer)
        }
        1 !== this.samples && this._renderTarget.setSamples(this.samples, !this._drawOnlyOnFirstAttachmentByDefault, !0)
      }
      _createInternalTextures() {
        this._renderTarget = this._getEngine().createMultipleRenderTarget(this._size, this._multiRenderTargetOptions, !this._drawOnlyOnFirstAttachmentByDefault), this._texture = this._renderTarget.texture
      }
      _releaseTextures() {
        if (this._textures)
          for (let OO = 0; OO < this._textures.length; OO++) this._textures[OO]._texture = null, this._textures[OO].dispose()
      }
      _createTextures(OO) {
        const KO = this._renderTarget.textures;
        this._textures = [];
        for (let pO = 0; pO < KO.length; pO++) {
          const XO = new jK.e(null, this.JKO());
          OO?.[pO] && (XO.name = OO[pO]), XO._texture = KO[pO], XO._texture && (XO._noMipmap = !XO._texture.useMipMaps, XO._useSRGBBuffer = XO._texture._useSRGBBuffer), this._textures.push(XO)
        }
      }
      setInternalTexture(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        if (this.renderTarget && (0 === KO && (this._texture = OO), this.renderTarget.setTexture(OO, KO, pO), this.textures[KO] || (this.textures[KO] = new jK.e(null, this.JKO()), this.textures[KO].name = this._textureNames?.[KO] ?? this.textures[KO].name), this.textures[KO]._texture = OO, this.textures[KO]._noMipmap = !OO.useMipMaps, this.textures[KO]._useSRGBBuffer = OO._useSRGBBuffer, this._count = this.renderTarget.textures ? this.renderTarget.textures.length : 0, this._multiRenderTargetOptions.types && (this._multiRenderTargetOptions.types[KO] = OO.type), this._multiRenderTargetOptions.samplingModes && (this._multiRenderTargetOptions.samplingModes[KO] = OO.samplingMode), this._multiRenderTargetOptions.useSRGBBuffers && (this._multiRenderTargetOptions.useSRGBBuffers[KO] = OO._useSRGBBuffer), this._multiRenderTargetOptions.targetTypes && -1 !== this._multiRenderTargetOptions.targetTypes[KO])) {
          let pO;
          pO = OO.is2DArray ? 35866 : OO.isCube ? 34067 : OO.is3D ? 32879 : 3553, this._multiRenderTargetOptions.targetTypes[KO] = pO
        }
      }
      setLayerAndFaceIndex(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : -1;
        this.textures[OO] && this.renderTarget && (this._multiRenderTargetOptions.layerIndex && (this._multiRenderTargetOptions.layerIndex[OO] = KO), this._multiRenderTargetOptions.faceIndex && (this._multiRenderTargetOptions.faceIndex[OO] = pO), this.renderTarget.setLayerAndFaceIndex(OO, KO, pO))
      }
      setLayerAndFaceIndices(OO, KO) {
        this.renderTarget && (this._multiRenderTargetOptions.layerIndex = OO, this._multiRenderTargetOptions.faceIndex = KO, this.renderTarget.setLayerAndFaceIndices(OO, KO))
      }
      get samples() {
        return this._samples
      }
      set samples(OO) {
        this._renderTarget ? this._samples = this._renderTarget.setSamples(OO) : this._samples = OO
      }
      resize(OO) {
        this._processSizeParameter(OO), this._rebuild(!1, void 0, this._textureNames)
      }
      updateCount(OO, KO, pO) {
        this._multiRenderTargetOptions.PoO = OO, this._count = OO;
        const XO = [],
          bK = [],
          eO = [],
          lO = [],
          vK = [],
          CO = [],
          hO = [],
          DO = [];
        this._textureNames = pO, this._initTypes(OO, XO, bK, eO, lO, vK, CO, hO, DO, KO), this._multiRenderTargetOptions.types = XO, this._multiRenderTargetOptions.samplingModes = bK, this._multiRenderTargetOptions.useSRGBBuffers = eO, this._multiRenderTargetOptions.formats = lO, this._multiRenderTargetOptions.targetTypes = vK, this._multiRenderTargetOptions.faceIndex = CO, this._multiRenderTargetOptions.layerIndex = hO, this._multiRenderTargetOptions.layerCounts = DO, this._multiRenderTargetOptions.labels = pO, this._rebuild(!1, !0, pO)
      }
      _unbindFrameBuffer(OO, KO) {
        this._renderTarget && OO.unBindMultiColorAttachmentFramebuffer(this._renderTarget, this.isCube, (() => {
          this.onAfterRenderObservable.notifyObservers(KO)
        }))
      }
      dispose() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        this._releaseTextures(), OO ? this._texture = null : this.releaseInternalTextures(), super.dispose()
      }
      releaseInternalTextures() {
        const OO = this._renderTarget?.textures;
        if (OO) {
          for (let KO = OO.length - 1; KO >= 0; KO--) this._textures[KO]._texture = null;
          this._renderTarget?.dispose(), this._renderTarget = null
        }
      }
    }
    var rp = pO(38250);
    class PK {
      constructor(OO) {
        this.name = rp.d.NAME_GEOMETRYBUFFERRENDERER, this.Ce = OO
      }
      register() {
        this.Ce._gatherRenderTargetsStage.registerStep(rp.d.STEP_GATHERRENDERTARGETS_GEOMETRYBUFFERRENDERER, this, this._gatherRenderTargets)
      }
      rebuild() {}
      dispose() {}
      _gatherRenderTargets(OO) {
        this.Ce._geometryBufferRenderer && OO.push(this.Ce._geometryBufferRenderer.getGBuffer())
      }
    }
    let mp = !1;
    var sK;
    ! function(OO) {
      OO[OO.Small = 0] = "Small", OO[OO.Medium = 1] = "Medium", OO[OO.Large = 2] = "Large", OO[OO.ExtraLarge = 3] = "ExtraLarge"
    }(sK || (sK = {}));
    const HK = ["diffuseSampler", "bumpSampler", "reflectivitySampler", "albedoSampler", "morphTargets", "boneSampler", "transmissionWeightSampler", "subsurfaceWeightSampler", "iblShadowSampler"],
      RK = ["world", "mBones", "viewProjection", "diffuseMatrix", "alphaCutOff", "view", "previousWorld", "previousViewProjection", "mPreviousBones", "bumpMatrix", "reflectivityMatrix", "albedoMatrix", "reflectivityColor", "albedoColor", "reflectionMatrix", "vTransmissionWeight", "vSubsurfaceWeight", "vEyePosition", "vTransmissionScatterAnisotropy", "vSubsurfaceScatterAnisotropy", "shadowTextureSize", "metallic", "glossiness", "vTangentSpaceParams", "vBumpInfos", "morphTargetInfluences", "morphTargetCount", "morphTargetTextureInfo", "morphTargetTextureIndices", "boneTextureInfo", "objectId", "meshBlendTag"];
    class SK {
      get renderTransparentMeshes() {
        return this._renderTransparentMeshes
      }
      set renderTransparentMeshes(OO) {
        if (OO && this._enableMeshBlendTag && !this._scene.qb().getCaps().blendParametersPerTarget) throw new Error("GeometryBufferRenderer: transparent mesh-blending tags require per-target blend parameters");
        this._renderTransparentMeshes = OO
      }
      get normalsAreUnsigned() {
        return this._normalsAreUnsigned
      }
      _linkPrePassRenderer(OO) {
        if (this._enableObjectId || this._enableMeshBlendTag) throw new Error("GeometryBufferRenderer: object ID and mesh-blending tag textures are not supported when linked to the PrePassRenderer");
        this._linkedWithPrePass = !0, this._prePassRenderer = OO, this._multiRenderTarget && (this._multiRenderTarget.onClearObservable.clear(), this._multiRenderTarget.onClearObservable.add((() => {})))
      }
      _unlinkPrePassRenderer() {
        this._linkedWithPrePass = !1, this._createRenderTargets()
      }
      _resetLayout() {
        this._enableDepth = !0, this._enableNormal = !0, this._enablePosition = !1, this._enableReflectivity = !1, this._enableVelocity = !1, this._enableVelocityLinear = !1, this._enableScreenspaceDepth = !1, this._enableIrradiance = !1, this._enableObjectId = !1, this._enableMeshBlendTag = !1, this._attachmentsFromPrePass = []
      }
      _forceTextureType(OO, KO) {
        OO === SK.POSITION_TEXTURE_TYPE ? (this._positionIndex = KO, this._enablePosition = !0) : OO === SK.VELOCITY_TEXTURE_TYPE ? (this._velocityIndex = KO, this._enableVelocity = !0) : OO === SK.VELOCITY_LINEAR_TEXTURE_TYPE ? (this._velocityLinearIndex = KO, this._enableVelocityLinear = !0) : OO === SK.REFLECTIVITY_TEXTURE_TYPE ? (this._reflectivityIndex = KO, this._enableReflectivity = !0) : OO === SK.DEPTH_TEXTURE_TYPE ? (this._depthIndex = KO, this._enableDepth = !0) : OO === SK.NORMAL_TEXTURE_TYPE ? (this._normalIndex = KO, this._enableNormal = !0) : OO === SK.SCREENSPACE_DEPTH_TEXTURE_TYPE ? (this._screenspaceDepthIndex = KO, this._enableScreenspaceDepth = !0) : OO === SK.IRRADIANCE_TEXTURE_TYPE ? (this._irradianceIndex = KO, this._enableIrradiance = !0) : OO === SK.OBJECT_ID_TEXTURE_TYPE ? (this._objectIdIndex = KO, this._enableObjectId = !0) : OO === SK.MESH_BLEND_TAG_TEXTURE_TYPE && (this._meshBlendTagIndex = KO, this._enableMeshBlendTag = !0)
      }
      _setAttachments(OO) {
        this._attachmentsFromPrePass = OO
      }
      _linkInternalTexture(OO) {
        this._multiRenderTarget.setInternalTexture(OO, 0, !1)
      }
      get renderList() {
        return this._multiRenderTarget.renderList
      }
      set renderList(OO) {
        this._multiRenderTarget.renderList = OO
      }
      get isSupported() {
        return this._multiRenderTarget.isSupported
      }
      getTextureIndex(OO) {
        switch (OO) {
          case SK.POSITION_TEXTURE_TYPE:
            return this._positionIndex;
          case SK.VELOCITY_TEXTURE_TYPE:
            return this._velocityIndex;
          case SK.VELOCITY_LINEAR_TEXTURE_TYPE:
            return this._velocityLinearIndex;
          case SK.REFLECTIVITY_TEXTURE_TYPE:
            return this._reflectivityIndex;
          case SK.DEPTH_TEXTURE_TYPE:
            return this._depthIndex;
          case SK.NORMAL_TEXTURE_TYPE:
            return this._normalIndex;
          case SK.SCREENSPACE_DEPTH_TEXTURE_TYPE:
            return this._screenspaceDepthIndex;
          case SK.IRRADIANCE_TEXTURE_TYPE:
            return this._irradianceIndex;
          case SK.OBJECT_ID_TEXTURE_TYPE:
            return this._objectIdIndex;
          case SK.MESH_BLEND_TAG_TEXTURE_TYPE:
            return this._meshBlendTagIndex;
          default:
            return -1
        }
      }
      get enableDepth() {
        return this._enableDepth
      }
      set enableDepth(OO) {
        this._enableDepth = OO, this._linkedWithPrePass || (this.dispose(), this._createRenderTargets())
      }
      get enableNormal() {
        return this._enableNormal
      }
      set enableNormal(OO) {
        this._enableNormal = OO, this._linkedWithPrePass || (this.dispose(), this._createRenderTargets())
      }
      get enablePosition() {
        return this._enablePosition
      }
      set enablePosition(OO) {
        this._enablePosition = OO, this._linkedWithPrePass || (this.dispose(), this._createRenderTargets())
      }
      get enableVelocity() {
        return this._enableVelocity
      }
      set enableVelocity(OO) {
        this._enableVelocity = OO, OO || (this._previousTransformationMatrices = {}), this._linkedWithPrePass || (this.dispose(), this._createRenderTargets()), this._scene.needsPreviousWorldMatrices = OO
      }
      get enableVelocityLinear() {
        return this._enableVelocityLinear
      }
      set enableVelocityLinear(OO) {
        this._enableVelocityLinear = OO, this._linkedWithPrePass || (this.dispose(), this._createRenderTargets())
      }
      get enableReflectivity() {
        return this._enableReflectivity
      }
      set enableReflectivity(OO) {
        this._enableReflectivity = OO, this._linkedWithPrePass || (this.dispose(), this._createRenderTargets())
      }
      get enableScreenspaceDepth() {
        return this._enableScreenspaceDepth
      }
      set enableScreenspaceDepth(OO) {
        this._enableScreenspaceDepth = OO, this._linkedWithPrePass || (this.dispose(), this._createRenderTargets())
      }
      get enableIrradiance() {
        return this._enableIrradiance
      }
      set enableIrradiance(OO) {
        this._enableIrradiance = OO, this._linkedWithPrePass || (this.dispose(), this._createRenderTargets())
      }
      get enableObjectId() {
        return this._enableObjectId
      }
      set enableObjectId(OO) {
        if (OO && this._linkedWithPrePass) throw new Error("GeometryBufferRenderer: object ID textures are not supported when linked to the PrePassRenderer");
        if (OO && 1 !== this.samples) throw new Error("GeometryBufferRenderer: object ID textures currently require samples to be 1");
        if (OO && !this._enableObjectId && !this._linkedWithPrePass) {
          const OO = this._scene.qb(),
            KO = Math.min(OO.getCaps().maxDrawBuffers ?? 1, 8),
            pO = this._assignRenderTargetIndices()[0] + 1;
          if (OO.getCaps().drawBuffersExtension && pO > KO) throw new Error(`GeometryBufferRenderer: ${pO} color attachments were requested, but this engine supports at most ${KO}`)
        }
        this._enableObjectId = OO, OO || (this._objectIdIndex = -1), this._linkedWithPrePass || (this.dispose(), this._createRenderTargets())
      }
      get enableMeshBlendingTag() {
        return this._enableMeshBlendTag
      }
      set enableMeshBlendingTag(OO) {
        if (this._enableMeshBlendTag !== OO) {
          if (OO) {
            const OO = this._scene.qb();
            if (! function(OO) {
                return "NATIVE" !== OO.shaderPlatformName && (OO.isWebGPU || 2 === OO.ye)
              }(OO)) throw new Error("GeometryBufferRenderer: mesh-blending tag textures require WebGL2 or WebGPU");
            if (this.renderTransparentMeshes && !OO.isWebGPU && !OO.getCaps().blendParametersPerTarget) throw new Error("GeometryBufferRenderer: transparent mesh-blending tags require per-target blend parameters");
            if (this._linkedWithPrePass) throw new Error("GeometryBufferRenderer: mesh-blending tag textures are not supported when linked to the PrePassRenderer");
            if (1 !== this.samples) throw new Error("GeometryBufferRenderer: mesh-blending tag textures require samples to be 1");
            if (!this._enableMeshBlendTag) {
              const KO = Math.min(OO.getCaps().maxDrawBuffers ?? 1, 8),
                pO = this._assignRenderTargetIndices()[0] + 1;
              if (OO.getCaps().drawBuffersExtension && pO > KO) throw new Error(`GeometryBufferRenderer: ${pO} color attachments were requested, but this engine supports at most ${KO}`)
            }
          }
          this._enableMeshBlendTag = OO, OO || (this._meshBlendTagIndex = -1), this._linkedWithPrePass || (this.dispose(), this._createRenderTargets())
        }
      }
      get Ce() {
        return this._scene
      }
      get ratio() {
        return "object" === typeof this._ratioOrDimensions ? 1 : this._ratioOrDimensions
      }
      get shaderLanguage() {
        return this._shaderLanguage
      }
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 15,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        var bK;
        this._previousTransformationMatrices = {}, this._previousBonesTransformationMatrices = {}, this.excludedSkinnedMeshesFromVelocity = [], this._renderTransparentMeshes = !0, this.generateNormalsInWorldSpace = !1, this._normalsAreUnsigned = !1, this._resizeObserver = null, this._enableDepth = !0, this._enableNormal = !0, this._enablePosition = !1, this._enableVelocity = !1, this._enableVelocityLinear = !1, this._enableReflectivity = !1, this._enableScreenspaceDepth = !1, this._enableIrradiance = !1, this._enableObjectId = !1, this._enableMeshBlendTag = !1, this._clearColor = new GO.g(0, 0, 0, 0), this._clearDepthColor = new GO.g(0, 0, 0, 1), this._positionIndex = -1, this._velocityIndex = -1, this._velocityLinearIndex = -1, this._reflectivityIndex = -1, this._depthIndex = -1, this._normalIndex = -1, this._screenspaceDepthIndex = -1, this._irradianceIndex = -1, this._objectIdIndex = -1, this._meshBlendTagIndex = -1, this._linkedWithPrePass = !1, this.generateIrradianceWithScatterMask = !1, this.useSpecificClearForDepthTexture = !1, this._shaderLanguage = 0, this._shadersLoaded = !1, this._scene = OO, this._ratioOrDimensions = KO, this._useUbo = OO.qb().supportsUniformBuffers, this._depthFormat = pO, this._textureTypesAndFormats = XO || {}, this._initShaderSourceAsync(), bK = SK, mp || (mp = !0, Object.defineProperty(sO.e.prototype, "geometryBufferRenderer", {
          get: function() {
            return this._geometryBufferRenderer
          },
          set: function(OO) {
            OO && OO.isSupported && (this._geometryBufferRenderer = OO)
          },
          enumerable: !0,
          configurable: !0
        }), sO.e.prototype.enableGeometryBufferRenderer = function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
            KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 15,
            pO = arguments.length > 2 ? arguments[2] : void 0;
          return this._geometryBufferRenderer || (this._geometryBufferRenderer = new bK(this, OO, KO, pO), this._geometryBufferRenderer.isSupported || (this._geometryBufferRenderer = null)), this._geometryBufferRenderer
        }, sO.e.prototype.disableGeometryBufferRenderer = function() {
          this._geometryBufferRenderer && (this._geometryBufferRenderer.dispose(), this._geometryBufferRenderer = null)
        }, bK._SceneComponentInitialization = OO => {
          let KO = OO._getComponent(rp.d.NAME_GEOMETRYBUFFERRENDERER);
          KO || (KO = new PK(OO), OO.cDO(KO))
        }), SK._SceneComponentInitialization(this._scene), this._createRenderTargets()
      }
      async _initShaderSourceAsync() {
        this._scene.qb().isWebGPU && !SK.ForceGLSL ? (this._shaderLanguage = 1, await Promise.all([pO.e(317).then((() => pO(59719))), Promise.all([pO.e(316), pO.e(328)]).then((() => pO(59723)))])) : await Promise.all([pO.e(300).then((() => pO(59729))), pO.e(299).then((() => pO(59734)))]), this._shadersLoaded = !0
      }
      isReady(OO, KO) {
        if (!this._shadersLoaded) return !1;
        const pO = OO.UX();
        if (pO && pO.disableDepthWrite) return !1;
        if (function(OO) {
            return OO._isGaussianSplatting || "GaussianSplattingMesh" === (KO = OO.getClassName()) || "GaussianSplattingStream" === KO;
            var KO
          }(OO.getMesh())) return !1;
        const XO = [],
          bK = [RO.j.PositionKind],
          eO = OO.getMesh();
        eO.isVerticesDataPresent(RO.j.NormalKind) && (XO.push("#define HAS_NORMAL_ATTRIBUTE"), bK.push(RO.j.NormalKind));
        let lO = !1,
          vK = !1;
        if (pO) {
          let OO = !1;
          if (pO.needAlphaTestingForMesh(eO) && pO.getAlphaTestTexture() && (XO.push("#define ALPHATEST"), XO.push(`#define ALPHATEST_UV${pO.getAlphaTestTexture().coordinatesIndex+1}`), OO = !0), (pO.bumpTexture || pO.normalTexture || pO.geometryNormalTexture) && WO.e.BumpTextureEnabled) {
            const KO = pO.bumpTexture || pO.normalTexture || pO.geometryNormalTexture;
            XO.push("#define BUMP"), XO.push(`#define BUMP_UV${KO.coordinatesIndex+1}`), OO = !0
          }
          if (this._enableReflectivity) {
            let KO = !1;
            if ("PBRMetallicRoughnessMaterial" === pO.getClassName()) pO.metallicRoughnessTexture && (XO.push("#define ORMTEXTURE"), XO.push(`#define REFLECTIVITY_UV${pO.metallicRoughnessTexture.coordinatesIndex+1}`), XO.push("#define METALLICWORKFLOW"), OO = !0, KO = !0), null != pO.metallic && (XO.push("#define METALLIC"), XO.push("#define METALLICWORKFLOW"), KO = !0), null != pO.roughness && (XO.push("#define ROUGHNESS"), XO.push("#define METALLICWORKFLOW"), KO = !0), KO && (pO.baseTexture && (XO.push("#define ALBEDOTEXTURE"), XO.push(`#define ALBEDO_UV${pO.baseTexture.coordinatesIndex+1}`), pO.baseTexture.gammaSpace && XO.push("#define GAMMAALBEDO"), OO = !0), pO.baseColor && XO.push("#define ALBEDOCOLOR"));
            else if ("PBRSpecularGlossinessMaterial" === pO.getClassName()) pO.specularGlossinessTexture ? (XO.push("#define SPECULARGLOSSINESSTEXTURE"), XO.push(`#define REFLECTIVITY_UV${pO.specularGlossinessTexture.coordinatesIndex+1}`), OO = !0, pO.specularGlossinessTexture.gammaSpace && XO.push("#define GAMMAREFLECTIVITYTEXTURE")) : pO.specularColor && XO.push("#define REFLECTIVITYCOLOR"), null != pO.glossiness && XO.push("#define GLOSSINESS");
            else if ("PBRMaterial" === pO.getClassName()) pO.metallicTexture && (XO.push("#define ORMTEXTURE"), XO.push(`#define REFLECTIVITY_UV${pO.metallicTexture.coordinatesIndex+1}`), XO.push("#define METALLICWORKFLOW"), OO = !0, KO = !0), null != pO.metallic && (XO.push("#define METALLIC"), XO.push("#define METALLICWORKFLOW"), KO = !0), null != pO.roughness && (XO.push("#define ROUGHNESS"), XO.push("#define METALLICWORKFLOW"), KO = !0), KO ? (pO.albedoTexture && (XO.push("#define ALBEDOTEXTURE"), XO.push(`#define ALBEDO_UV${pO.albedoTexture.coordinatesIndex+1}`), pO.albedoTexture.gammaSpace && XO.push("#define GAMMAALBEDO"), OO = !0), pO.albedoColor && XO.push("#define ALBEDOCOLOR")) : (pO.reflectivityTexture ? (XO.push("#define SPECULARGLOSSINESSTEXTURE"), XO.push(`#define REFLECTIVITY_UV${pO.reflectivityTexture.coordinatesIndex+1}`), pO.reflectivityTexture.gammaSpace && XO.push("#define GAMMAREFLECTIVITYTEXTURE"), OO = !0) : pO.reflectivityColor && XO.push("#define REFLECTIVITYCOLOR"), null != pO.microSurface && XO.push("#define GLOSSINESS"));
            else if ("StandardMaterial" === pO.getClassName()) pO.specularTexture && (XO.push("#define REFLECTIVITYTEXTURE"), XO.push(`#define REFLECTIVITY_UV${pO.specularTexture.coordinatesIndex+1}`), pO.specularTexture.gammaSpace && XO.push("#define GAMMAREFLECTIVITYTEXTURE"), OO = !0), pO.specularColor && XO.push("#define REFLECTIVITYCOLOR");
            else if ("OpenPBRMaterial" === pO.getClassName()) {
              const KO = pO;
              XO.push("#define METALLIC"), XO.push("#define ROUGHNESS"), KO._useRoughnessFromMetallicTextureGreen && KO.baseMetalnessTexture ? (XO.push("#define ORMTEXTURE"), XO.push(`#define REFLECTIVITY_UV${KO.baseMetalnessTexture.coordinatesIndex+1}`), OO = !0) : KO.baseMetalnessTexture ? (XO.push("#define METALLIC_TEXTURE"), XO.push(`#define METALLIC_UV${KO.baseMetalnessTexture.coordinatesIndex+1}`), OO = !0) : KO.specularRoughnessTexture && (XO.push("#define ROUGHNESS_TEXTURE"), XO.push(`#define ROUGHNESS_UV${KO.specularRoughnessTexture.coordinatesIndex+1}`), OO = !0), KO.baseColorTexture && (XO.push("#define ALBEDOTEXTURE"), XO.push(`#define ALBEDO_UV${KO.baseColorTexture.coordinatesIndex+1}`), KO.baseColorTexture.gammaSpace && XO.push("#define GAMMAALBEDO"), OO = !0), KO.baseColor && XO.push("#define ALBEDOCOLOR")
            }
          }
          if (this._enableIrradiance && this.generateIrradianceWithScatterMask && (XO.push("#define IRRADIANCE_SCATTER_MASK"), "OpenPBRMaterial" === pO.getClassName())) {
            const KO = pO;
            KO.subsurfaceWeight > 0 && KO.subsurfaceWeightTexture && (XO.push("#define SUBSURFACE_WEIGHT"), XO.push(`#define SUBSURFACEWEIGHT_UV${KO.subsurfaceWeightTexture.coordinatesIndex+1}`), OO = !0), KO.transmissionWeight > 0 && KO.transmissionWeightTexture && (XO.push("#define TRANSMISSION_WEIGHT"), XO.push(`#define TRANSMISSIONWEIGHT_UV${KO.transmissionWeightTexture.coordinatesIndex+1}`), OO = !0)
          }
          OO && (XO.push("#define NEED_UV"), eO.isVerticesDataPresent(RO.j.UVKind) && (bK.push(RO.j.UVKind), XO.push("#define UV1"), lO = !0), eO.isVerticesDataPresent(RO.j.UV2Kind) && (bK.push(RO.j.UV2Kind), XO.push("#define UV2"), vK = !0))
        }
        if (this._enableDepth && (XO.push("#define DEPTH"), XO.push("#define DEPTH_INDEX " + this._depthIndex)), this._enableNormal && (XO.push("#define NORMAL"), XO.push("#define NORMAL_INDEX " + this._normalIndex)), this._enablePosition && (XO.push("#define POSITION"), XO.push("#define POSITION_INDEX " + this._positionIndex)), this._enableVelocity && (XO.push("#define VELOCITY"), XO.push("#define VELOCITY_INDEX " + this._velocityIndex), -1 === this.excludedSkinnedMeshesFromVelocity.indexOf(eO) && XO.push("#define BONES_VELOCITY_ENABLED")), this._enableVelocityLinear && (XO.push("#define VELOCITY_LINEAR"), XO.push("#define VELOCITY_LINEAR_INDEX " + this._velocityLinearIndex), -1 === this.excludedSkinnedMeshesFromVelocity.indexOf(eO) && XO.push("#define BONES_VELOCITY_ENABLED")), this._enableReflectivity && (XO.push("#define REFLECTIVITY"), XO.push("#define REFLECTIVITY_INDEX " + this._reflectivityIndex)), this._enableScreenspaceDepth && -1 !== this._screenspaceDepthIndex && (XO.push("#define SCREENSPACE_DEPTH_INDEX " + this._screenspaceDepthIndex), XO.push("#define SCREENSPACE_DEPTH")), this._enableIrradiance && -1 !== this._irradianceIndex) {
          XO.push("#define IRRADIANCE_INDEX " + this._irradianceIndex), XO.push("#define IRRADIANCE");
          const OO = this._scene;
          if (OO.environmentTexture) {
            const KO = {};
            let bK = !1,
              eO = 0;
            "OpenPBRMaterial" !== pO.getClassName() && "StandardMaterial" !== pO.getClassName() && "PBRMetallicRoughnessMaterial" !== pO.getClassName() && "PBRSpecularGlossinessMaterial" !== pO.getClassName() && "PBRMaterial" !== pO.getClassName() || (bK = !!pO.realtimeFiltering, eO = pO.realtimeFilteringQuality || 0), (0, kK.Z)(OO, OO.environmentTexture, KO, bK, eO, !0);
            for (const OO in KO) KO[OO] && XO.push("#define " + OO);
            KO.USEIRRADIANCEMAP || XO.push("#define SPHERICAL_HARMONICS");
            const lO = OO.postProcessRenderPipelineManager.supportedPipelines.find((OO => "IBLShadowsRenderPipeline" === OO.getClassName()));
            if (lO) {
              const OO = lO;
              OO._getAccumulatedTexture() && (XO.push("#define IBL_SHADOW_TEXTURE"), OO.coloredShadows && XO.push("#define COLORED_IBL_SHADOWS"))
            }
          }
        }
        this._enableObjectId && (XO.push("#define OBJECT_ID"), XO.push("#define OBJECT_ID_INDEX " + this._objectIdIndex)), this._enableMeshBlendTag && (XO.push("#define MESH_BLEND_TAG"), XO.push("#define MESH_BLEND_TAG_INDEX " + this._meshBlendTagIndex)), this.generateNormalsInWorldSpace && XO.push("#define NORMAL_WORLDSPACE"), this._normalsAreUnsigned && XO.push("#define ENCODE_NORMAL"), eO.useBones && eO.computeBonesUsingShaders && eO.skeleton ? (bK.push(RO.j.MatricesIndicesKind), bK.push(RO.j.MatricesWeightsKind), eO.numBoneInfluencers > 4 && (bK.push(RO.j.MatricesIndicesExtraKind), bK.push(RO.j.MatricesWeightsExtraKind)), XO.push("#define NUM_BONE_INFLUENCERS " + eO.numBoneInfluencers), XO.push("#define BONETEXTURE " + eO.skeleton.isUsingTextureForMatrices), XO.push("#define BonesPerMesh " + (eO.skeleton.bones.length + 1))) : (XO.push("#define NUM_BONE_INFLUENCERS 0"), XO.push("#define BONETEXTURE false"), XO.push("#define BonesPerMesh 0"));
        const CO = eO.morphTargetManager ? (0, kK.R)(eO.morphTargetManager, XO, bK, eO, !0, !0, !1, lO, vK, !1) : 0;
        KO && (XO.push("#define INSTANCES"), (0, kK.vb)(bK, this._enableVelocity || this._enableVelocityLinear), OO.getRenderingMesh().hasThinInstances && XO.push("#define THIN_INSTANCES")), this._linkedWithPrePass ? XO.push("#define SCENE_MRT_COUNT " + this._attachmentsFromPrePass.length) : XO.push("#define SCENE_MRT_COUNT " + this._multiRenderTarget.textures.length), (0, DK.l)(pO, this._scene, XO);
        const hO = this._scene.qb(),
          DO = OO._getDrawWrapper(void 0, !0),
          MO = DO.defines,
          aK = XO.join("\n");
        return MO !== aK && DO.setEffect(hO.createEffect("geometry", {
          attributes: bK,
          uniformsNames: RK,
          samplers: HK,
          defines: aK,
          onCompiled: null,
          fallbacks: null,
          onError: null,
          uniformBuffersNames: ["Scene"],
          indexParameters: {
            buffersCount: this._multiRenderTarget.textures.length - 1,
            maxSimultaneousMorphTargets: CO
          },
          shaderLanguage: this.shaderLanguage
        }, hO), aK), DO.effect.isReady()
      }
      getGBuffer() {
        return this._multiRenderTarget
      }
      get samples() {
        return this._multiRenderTarget.samples
      }
      set samples(OO) {
        if (this._enableObjectId && 1 !== OO) throw new Error("GeometryBufferRenderer: object ID textures currently require samples to be 1");
        if (this._enableMeshBlendTag && 1 !== OO) throw new Error("GeometryBufferRenderer: mesh-blending tag textures require samples to be 1");
        this._multiRenderTarget.samples = OO
      }
      dispose() {
        if (this._resizeObserver) {
          this._scene.qb().onResizeObservable.remove(this._resizeObserver), this._resizeObserver = null
        }
        this._multiRenderTarget?.renderTarget && this.Ce.qb()._currentRenderTarget === this._multiRenderTarget.renderTarget && this.Ce.qb().unBindFramebuffer(this._multiRenderTarget?.renderTarget), this.getGBuffer().dispose()
      }
      _assignRenderTargetIndices() {
        const OO = [],
          KO = [];
        let pO = 0;
        return this._enableDepth && (this._depthIndex = pO, pO++, OO.push("gBuffer_Depth"), KO.push(this._textureTypesAndFormats[SK.DEPTH_TEXTURE_TYPE])), this._enableNormal && (this._normalIndex = pO, pO++, OO.push("gBuffer_Normal"), KO.push(this._textureTypesAndFormats[SK.NORMAL_TEXTURE_TYPE])), this._enablePosition && (this._positionIndex = pO, pO++, OO.push("gBuffer_Position"), KO.push(this._textureTypesAndFormats[SK.POSITION_TEXTURE_TYPE])), this._enableVelocity && (this._velocityIndex = pO, pO++, OO.push("gBuffer_Velocity"), KO.push(this._textureTypesAndFormats[SK.VELOCITY_TEXTURE_TYPE])), this._enableVelocityLinear && (this._velocityLinearIndex = pO, pO++, OO.push("gBuffer_VelocityLinear"), KO.push(this._textureTypesAndFormats[SK.VELOCITY_LINEAR_TEXTURE_TYPE])), this._enableReflectivity && (this._reflectivityIndex = pO, pO++, OO.push("gBuffer_Reflectivity"), KO.push(this._textureTypesAndFormats[SK.REFLECTIVITY_TEXTURE_TYPE])), this._enableScreenspaceDepth && (this._screenspaceDepthIndex = pO, pO++, OO.push("gBuffer_ScreenspaceDepth"), KO.push(this._textureTypesAndFormats[SK.SCREENSPACE_DEPTH_TEXTURE_TYPE])), this._enableIrradiance && (this._irradianceIndex = pO, pO++, OO.push("gBuffer_Irradiance"), KO.push(this._textureTypesAndFormats[SK.IRRADIANCE_TEXTURE_TYPE])), this._enableObjectId && (this._objectIdIndex = pO, pO++, OO.push("gBuffer_ObjectId"), KO.push({
          textureType: 0,
          textureFormat: 5,
          samplingMode: 1
        })), this._enableMeshBlendTag && (this._meshBlendTagIndex = pO, pO++, OO.push("gBuffer_MeshBlendTag"), KO.push({
          textureType: 0,
          textureFormat: 8,
          samplingMode: 1
        })), [pO, OO, KO]
      }
      _createRenderTargets() {
        const OO = this._scene.qb(),
          [KO, pO, XO] = this._assignRenderTargetIndices(),
          bK = Math.min(OO.getCaps().maxDrawBuffers ?? 1, 8);
        if (OO.getCaps().drawBuffersExtension && KO > bK) throw new Error(`GeometryBufferRenderer: ${KO} color attachments were requested, but this engine supports at most ${bK}`);
        let lO = 0;
        OO._caps.textureFloat && OO._caps.textureFloatLinearFiltering ? lO = 1 : OO._caps.textureHalfFloat && OO._caps.textureHalfFloatLinearFiltering && (lO = 2);
        const vK = this._getRenderTargetDimensions(),
          CO = [],
          hO = [],
          DO = [];
        for (const eO of XO) eO ? (CO.push(eO.textureType), hO.push(eO.textureFormat), DO.push(eO.samplingMode ?? 2)) : (CO.push(lO), hO.push(5), DO.push(2));
        if (this._normalsAreUnsigned = 11 === CO[SK.NORMAL_TEXTURE_TYPE] || 13 === CO[SK.NORMAL_TEXTURE_TYPE], this._multiRenderTarget = new ip("gBuffer", vK, KO, this._scene, {
            generateMipMaps: !1,
            generateDepthTexture: !0,
            types: CO,
            formats: hO,
            samplingModes: DO,
            depthTextureFormat: this._depthFormat
          }, pO.concat("gBuffer_DepthBuffer")), !this.isSupported) return;
        this._multiRenderTarget.wrapU = jK.e.CLAMP_ADDRESSMODE, this._multiRenderTarget.wrapV = jK.e.CLAMP_ADDRESSMODE, this._multiRenderTarget.refreshRate = 1, this._multiRenderTarget.renderParticles = !1, this._multiRenderTarget.renderList = null;
        const MO = [!0],
          aK = [!1],
          oO = [!0];
        for (let eO = 1; eO < KO; ++eO) MO.push(!0), oO.push(!1), aK.push(!0);
        const FO = OO.buildTextureLayout(MO),
          VO = OO.buildTextureLayout(aK),
          LO = OO.buildTextureLayout(oO);
        this._multiRenderTarget.onClearObservable.add((OO => {
          const KO = this.useSpecificClearForDepthTexture ? VO : FO;
          OO.clearAttachments(this._clearColor, KO, !0, !0, !0), this.useSpecificClearForDepthTexture && OO.clearAttachments(this._clearDepthColor, LO, !0, !1, !1), OO.bindAttachments(FO)
        })), this._resizeObserver = OO.onResizeObservable.add((() => {
          this._multiRenderTarget && this._multiRenderTarget.resize(this._getRenderTargetDimensions())
        }));
        const QO = OO => {
          const KO = OO.getRenderingMesh(),
            pO = OO.getEffectiveMesh(),
            XO = this._scene,
            bK = XO.qb(),
            lO = OO.UX();
          if (!lO) return;
          if (pO._internalAbstractMeshDataInfo._isActiveIntermediate = !1, (this._enableVelocity || this._enableVelocityLinear) && !this._previousTransformationMatrices[pO.uniqueId] && (this._previousTransformationMatrices[pO.uniqueId] = {
              lK: HO.c.Identity(),
              viewProjection: XO.getTransformMatrix()
            }, KO.skeleton)) {
            const OO = KO.skeleton.getTransformMatrices(KO);
            this._previousBonesTransformationMatrices[KO.uniqueId] = this._copyBonesTransformationMatrices(OO, new Float32Array(OO.length))
          }
          const vK = KO._getInstancesRenderList(OO._id, !!OO.getReplacementMesh());
          if (vK.mustReturn) return;
          const CO = bK.getCaps().instancedArrays && (null !== vK.visibleInstances[OO._id] || KO.hasThinInstances),
            hO = pO.getWorldMatrix();
          if (this.isReady(OO, CO)) {
            const DO = OO._getDrawWrapper();
            if (!DO) return;
            const MO = DO.effect;
            let aK;
            bK.enableEffect(DO), CO || KO._bind(OO, MO, lO.fillMode), this._useUbo ? ((0, kK.A)(MO, this._scene.getSceneUniformBuffer()), this._scene.finalizeSceneUbo()) : (MO.setMatrix("viewProjection", XO.getTransformMatrix()), MO.setMatrix("view", XO.getViewMatrix()), this._scene.bindEyePosition(MO, "vEyePosition"));
            if (KO._instanceDataStorage.isFrozen || !lO.backFaceCulling && null === lO.sideOrientation) aK = KO._effectiveSideOrientation;
            else {
              const OO = pO._getWorldMatrixDeterminant();
              aK = lO._getEffectiveOrientation(KO), OO < 0 && (aK = aK === eO.b.ClockWiseSideOrientation ? eO.b.CounterClockWiseSideOrientation : eO.b.ClockWiseSideOrientation)
            }
            if (lO._preBind(DO, aK), lO.needAlphaTestingForMesh(pO)) {
              const OO = lO.getAlphaTestTexture();
              OO && (MO.setTexture("diffuseSampler", OO), MO.setMatrix("diffuseMatrix", OO.getTextureMatrix()), MO.setFloat("alphaCutOff", lO.alphaCutOff ?? .4))
            }
            if ((lO.bumpTexture || lO.normalTexture || lO.geometryNormalTexture) && XO.qb().getCaps().standardDerivatives && WO.e.BumpTextureEnabled) {
              const OO = lO.bumpTexture || lO.normalTexture || lO.geometryNormalTexture;
              MO.setFloat3("vBumpInfos", OO.coordinatesIndex, 1 / OO.level, lO.parallaxScaleBias), MO.setMatrix("bumpMatrix", OO.getTextureMatrix()), MO.setTexture("bumpSampler", OO), MO.setFloat2("vTangentSpaceParams", lO.invertNormalMapX ? -1 : 1, lO.invertNormalMapY ? -1 : 1)
            }
            if (this._enableReflectivity)
              if ("PBRMetallicRoughnessMaterial" === lO.getClassName()) null !== lO.metallicRoughnessTexture && (MO.setTexture("reflectivitySampler", lO.metallicRoughnessTexture), MO.setMatrix("reflectivityMatrix", lO.metallicRoughnessTexture.getTextureMatrix())), null !== lO.metallic && MO.setFloat("metallic", lO.metallic), null !== lO.roughness && MO.setFloat("glossiness", 1 - lO.roughness), null !== lO.baseTexture && (MO.setTexture("albedoSampler", lO.baseTexture), MO.setMatrix("albedoMatrix", lO.baseTexture.getTextureMatrix())), null !== lO.baseColor && MO.setColor3("albedoColor", lO.baseColor);
              else if ("PBRSpecularGlossinessMaterial" === lO.getClassName()) null !== lO.specularGlossinessTexture ? (MO.setTexture("reflectivitySampler", lO.specularGlossinessTexture), MO.setMatrix("reflectivityMatrix", lO.specularGlossinessTexture.getTextureMatrix())) : null !== lO.specularColor && MO.setColor3("reflectivityColor", lO.specularColor), null !== lO.glossiness && MO.setFloat("glossiness", lO.glossiness);
            else if ("PBRMaterial" === lO.getClassName()) null !== lO.metallicTexture && (MO.setTexture("reflectivitySampler", lO.metallicTexture), MO.setMatrix("reflectivityMatrix", lO.metallicTexture.getTextureMatrix())), null !== lO.metallic && MO.setFloat("metallic", lO.metallic), null !== lO.roughness && MO.setFloat("glossiness", 1 - lO.roughness), null !== lO.roughness || null !== lO.metallic || null !== lO.metallicTexture ? (null !== lO.albedoTexture && (MO.setTexture("albedoSampler", lO.albedoTexture), MO.setMatrix("albedoMatrix", lO.albedoTexture.getTextureMatrix())), null !== lO.albedoColor && MO.setColor3("albedoColor", lO.albedoColor)) : (null !== lO.reflectivityTexture ? (MO.setTexture("reflectivitySampler", lO.reflectivityTexture), MO.setMatrix("reflectivityMatrix", lO.reflectivityTexture.getTextureMatrix())) : null !== lO.reflectivityColor && MO.setColor3("reflectivityColor", lO.reflectivityColor), null !== lO.microSurface && MO.setFloat("glossiness", lO.microSurface));
            else if ("StandardMaterial" === lO.getClassName()) null !== lO.specularTexture && (MO.setTexture("reflectivitySampler", lO.specularTexture), MO.setMatrix("reflectivityMatrix", lO.specularTexture.getTextureMatrix())), null !== lO.specularColor && MO.setColor3("reflectivityColor", lO.specularColor);
            else if ("OpenPBRMaterial" === lO.getClassName()) {
              const OO = lO;
              OO._useRoughnessFromMetallicTextureGreen && OO.baseMetalnessTexture ? (MO.setTexture("reflectivitySampler", OO.baseMetalnessTexture), MO.setMatrix("reflectivityMatrix", OO.baseMetalnessTexture.getTextureMatrix())) : OO.baseMetalnessTexture ? (MO.setTexture("metallicSampler", OO.baseMetalnessTexture), MO.setMatrix("metallicMatrix", OO.baseMetalnessTexture.getTextureMatrix())) : OO.specularRoughnessTexture && (MO.setTexture("roughnessSampler", OO.specularRoughnessTexture), MO.setMatrix("roughnessMatrix", OO.specularRoughnessTexture.getTextureMatrix())), MO.setFloat("metallic", OO.baseMetalness), MO.setFloat("glossiness", 1 - OO.specularRoughness), null !== OO.baseColorTexture && (MO.setTexture("albedoSampler", OO.baseColorTexture), MO.setMatrix("albedoMatrix", OO.baseColorTexture.getTextureMatrix())), null !== OO.baseColor && MO.setColor3("albedoColor", OO.baseColor)
            }
            if (this._enableIrradiance && XO.environmentTexture) {
              const OO = XO.environmentTexture,
                KO = XO.postProcessRenderPipelineManager.supportedPipelines.find((OO => "IBLShadowsRenderPipeline" === OO.getClassName()));
              if (KO) {
                const OO = KO._getAccumulatedTexture();
                OO && (MO.setTexture("iblShadowSampler", OO), MO.setFloat2("shadowTextureSize", OO.getSize().width, OO.getSize().height))
              }
              if (MO.setMatrix("reflectionMatrix", OO.getReflectionTextureMatrix()), MO.setFloat2("vReflectionInfos", OO.level * XO.iblIntensity, 0), MO.setTexture("reflectionSampler", OO), OO.irradianceTexture && (MO.setTexture("irradianceSampler", OO.irradianceTexture), OO.irradianceTexture._dominantDirection && MO.setVector3("vReflectionDominantDirection", OO.irradianceTexture._dominantDirection)), OO.sphericalPolynomial) {
                const KO = OO.sphericalPolynomial;
                if (KO.preScaledHarmonics) {
                  const OO = KO.preScaledHarmonics;
                  MO.setVector3("vSphericalL00", OO.l00), MO.setVector3("vSphericalL1_1", OO.l1_1), MO.setVector3("vSphericalL10", OO.l10), MO.setVector3("vSphericalL11", OO.l11), MO.setVector3("vSphericalL2_2", OO.l2_2), MO.setVector3("vSphericalL2_1", OO.l2_1), MO.setVector3("vSphericalL20", OO.l20), MO.setVector3("vSphericalL21", OO.l21), MO.setVector3("vSphericalL22", OO.l22)
                } else MO.setFloat3("vSphericalX", KO.x.x, KO.x.y, KO.x.z), MO.setFloat3("vSphericalY", KO.y.x, KO.y.y, KO.y.z), MO.setFloat3("vSphericalZ", KO.z.x, KO.z.y, KO.z.z), MO.setFloat3("vSphericalXX_ZZ", KO.xx.x - KO.zz.x, KO.xx.y - KO.zz.y, KO.xx.z - KO.zz.z), MO.setFloat3("vSphericalYY_ZZ", KO.yy.x - KO.zz.x, KO.yy.y - KO.zz.y, KO.yy.z - KO.zz.z), MO.setFloat3("vSphericalZZ", KO.zz.x, KO.zz.y, KO.zz.z), MO.setFloat3("vSphericalXY", KO.xy.x, KO.xy.y, KO.xy.z), MO.setFloat3("vSphericalYZ", KO.yz.x, KO.yz.y, KO.yz.z), MO.setFloat3("vSphericalZX", KO.zx.x, KO.zx.y, KO.zx.z)
              }
              if (this.generateIrradianceWithScatterMask && "OpenPBRMaterial" === lO.getClassName()) {
                const OO = lO;
                MO.setFloat("vSubsurfaceWeight", OO.subsurfaceWeight), OO.subsurfaceWeightTexture && (MO.setTexture("subsurfaceWeightSampler", OO.subsurfaceWeightTexture), MO.setMatrix("subsurfaceWeightMatrix", OO.subsurfaceWeightTexture.getTextureMatrix())), MO.setFloat("vTransmissionWeight", OO.transmissionWeight), OO.transmissionWeightTexture && (MO.setTexture("transmissionWeightSampler", OO.transmissionWeightTexture), MO.setMatrix("transmissionWeightMatrix", OO.transmissionWeightTexture.getTextureMatrix())), MO.setFloat("vTransmissionScatterAnisotropy", OO.transmissionScatterAnisotropy), MO.setFloat("vSubsurfaceScatterAnisotropy", OO.subsurfaceScatterAnisotropy)
              }
            }
            if ((0, DK.e)(MO, lO, this._scene), KO.useBones && KO.computeBonesUsingShaders && KO.skeleton) {
              const OO = KO.skeleton;
              if (OO.isUsingTextureForMatrices && MO.getUniformIndex("boneTextureInfo") > -1) {
                const pO = OO.getTransformMatrixTexture(KO);
                MO.setTexture("boneSampler", pO), MO.setFloat2("boneTextureInfo", OO._textureWidth, OO._textureHeight)
              } else MO.setMatrices("mBones", KO.skeleton.getTransformMatrices(KO));
              (this._enableVelocity || this._enableVelocityLinear) && MO.setMatrices("mPreviousBones", this._previousBonesTransformationMatrices[KO.uniqueId])
            }
            if ((0, kK.w)(KO, MO), KO.morphTargetManager && KO.morphTargetManager.isUsingTextureForTargets && KO.morphTargetManager._bind(MO), (this._enableVelocity || this._enableVelocityLinear) && (MO.setMatrix("previousWorld", this._previousTransformationMatrices[pO.uniqueId].lK), MO.setMatrix("previousViewProjection", this._previousTransformationMatrices[pO.uniqueId].viewProjection)), this._enableObjectId) {
              let OO = KO.uniqueId;
              if (this.objectIdProvider) OO = (0, oK.h)(KO, this.objectIdProvider);
              else if (OO > 16777215) throw new Error(`Invalid geometry object ID ${OO} for mesh "${KO.name}". Object IDs must be integers between 0 and 0xFFFFFF.`);
              MO.setFloat("objectId", OO)
            }
            if (this._enableMeshBlendTag) {
              const OO = this.meshBlendTagProvider ? (0, oK.g)(KO, this.meshBlendTagProvider) : KO.meshBlendingTag;
              MO.setInt("meshBlendTag", OO)
            }
            CO && KO.hasThinInstances && MO.setMatrix("world", hO), KO._processRendering(pO, OO, MO, lO.fillMode, vK, CO, ((OO, KO) => {
              OO || MO.setMatrix("world", KO)
            }))
          }(this._enableVelocity || this._enableVelocityLinear) && (this._previousTransformationMatrices[pO.uniqueId].lK = hO.clone(), this._previousTransformationMatrices[pO.uniqueId].viewProjection = this._scene.getTransformMatrix().clone(), KO.skeleton && this._copyBonesTransformationMatrices(KO.skeleton.getTransformMatrices(KO), this._previousBonesTransformationMatrices[pO.uniqueId]))
        };
        this._multiRenderTarget.customIsReadyFunction = (KO, pO, XO) => {
          if ((XO || 0 === pO) && KO.au)
            for (let bK = 0; bK < KO.au.length; ++bK) {
              const pO = KO.au[bK],
                XO = pO.UX(),
                eO = pO.getRenderingMesh();
              if (!XO) continue;
              const lO = eO._getInstancesRenderList(pO._id, !!pO.getReplacementMesh()),
                vK = OO.getCaps().instancedArrays && (null !== lO.visibleInstances[pO._id] || eO.hasThinInstances);
              if (!this.isReady(pO, vK)) return !1
            }
          return !0
        }, this._multiRenderTarget.customRenderFunction = (KO, pO, XO, bK) => {
          let eO;
          if (this._linkedWithPrePass) {
            if (!this._prePassRenderer.enabled) return;
            this._scene.qb().bindAttachments(this._attachmentsFromPrePass)
          }
          if (bK.length) {
            for (OO.setColorWrite(!1), eO = 0; eO < bK.length; eO++) QO(bK.data[eO]);
            OO.setColorWrite(!0)
          }
          for (eO = 0; eO < KO.length; eO++) QO(KO.data[eO]);
          for (OO.setDepthWrite(!1), eO = 0; eO < pO.length; eO++) QO(pO.data[eO]);
          if (this.renderTransparentMeshes)
            for (eO = 0; eO < XO.length; eO++) QO(XO.data[eO]);
          OO.setDepthWrite(!0)
        }
      }
      _getRenderTargetDimensions() {
        if ("object" === typeof this._ratioOrDimensions) return {
          width: Math.max(1, Math.floor(this._ratioOrDimensions.width)),
          height: Math.max(1, Math.floor(this._ratioOrDimensions.height))
        };
        const OO = this._scene.qb();
        return {
          width: Math.max(1, Math.floor(OO.getRenderWidth() * this._ratioOrDimensions)),
          height: Math.max(1, Math.floor(OO.getRenderHeight() * this._ratioOrDimensions))
        }
      }
      _copyBonesTransformationMatrices(OO, KO) {
        for (let pO = 0; pO < OO.length; pO++) KO[pO] = OO[pO];
        return KO
      }
    }
    SK.ForceGLSL = !1, SK.DEPTH_TEXTURE_TYPE = 0, SK.NORMAL_TEXTURE_TYPE = 1, SK.POSITION_TEXTURE_TYPE = 2, SK.VELOCITY_TEXTURE_TYPE = 3, SK.REFLECTIVITY_TEXTURE_TYPE = 4, SK.SCREENSPACE_DEPTH_TEXTURE_TYPE = 5, SK.VELOCITY_LINEAR_TEXTURE_TYPE = 6, SK.IRRADIANCE_TEXTURE_TYPE = 7, SK.OBJECT_ID_TEXTURE_TYPE = 8, SK.MESH_BLEND_TAG_TEXTURE_TYPE = 9, SK._SceneComponentInitialization = OO => {
      throw (0, QK.j)("GeometryBufferRendererSceneComponent")
    };
    var JK = pO(35676);
    const cp = {
      effect: null,
      subMesh: null
    };

    function BK(OO) {
      if ("number" === typeof OO) return 1;
      if (OO instanceof HO.m) return 2;
      if (OO instanceof HO.o || OO instanceof GO.e) return 3;
      if (OO instanceof HO.s || OO instanceof GO.g) return 4;
      throw new Error("Unsupported OpenPBR property type.")
    }
    class ZK {
      populateVectorFromLinkedProperties(OO) {
        const KO = BK(OO);
        for (const pO in this.linkedProperties) {
          const OO = this.linkedProperties[pO],
            XO = OO.numComponents;
          if (KO < XO || OO.targetUniformComponentOffset > KO - XO) return void(1 == XO ? uO.b.Error(`Float property ${OO.name} has an offset that is too large.`) : uO.b.Error(`Vector${XO} property ${OO.name} won't fit in Vector${KO} or has an offset that is too large.`));
          "number" === typeof OO.value ? ZK._tmpArray[OO.targetUniformComponentOffset] = OO.value : OO.value.toArray(ZK._tmpArray, OO.targetUniformComponentOffset)
        }
        OO.BCO(ZK._tmpArray)
      }
      constructor(OO, KO) {
        this.linkedProperties = {}, this.firstLinkedKey = "", this.name = OO, this.numComponents = KO
      }
    }
    ZK._tmpArray = [0, 0, 0, 0];
    class GK {
      constructor(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
          eO = arguments.length > 5 ? arguments[5] : void 0;
        this.targetUniformComponentNum = 4, this.targetUniformComponentOffset = 0, this.name = OO, this.targetUniformName = pO, this.defaultValue = KO, this.value = KO, this.targetUniformComponentNum = XO, this.targetUniformComponentOffset = bK, this.requiredDefine = eO
      }
      get numComponents() {
        return "number" === typeof this.defaultValue ? 1 : BK(this.defaultValue)
      }
    }
    class qp {
      get samplerName() {
        return this.samplerPrefix + "Sampler"
      }
      get samplerInfoName() {
        return "v" + this.samplerPrefix.charAt(0).toUpperCase() + this.samplerPrefix.slice(1) + "Infos"
      }
      get samplerMatrixName() {
        return this.samplerPrefix + "Matrix"
      }
      constructor(OO, KO, pO) {
        this.value = null, this.samplerPrefix = "", this.textureDefine = "", this.name = OO, this.samplerPrefix = KO, this.textureDefine = pO
      }
    }
    class xp extends((0, VK.c)((0, FK.c)(SO.e))) {}
    class nK extends(function(OO) {
      return class extends OO {
        constructor() {
          super(...arguments), this.REFLECTION = !1, this.REFLECTIONMAP_3D = !1, this.REFLECTIONMAP_SPHERICAL = !1, this.REFLECTIONMAP_PLANAR = !1, this.REFLECTIONMAP_CUBIC = !1, this.USE_LOCAL_REFLECTIONMAP_CUBIC = !1, this.REFLECTIONMAP_PROJECTION = !1, this.REFLECTIONMAP_SKYBOX = !1, this.REFLECTIONMAP_EXPLICIT = !1, this.REFLECTIONMAP_EQUIRECTANGULAR = !1, this.REFLECTIONMAP_EQUIRECTANGULAR_FIXED = !1, this.REFLECTIONMAP_MIRROREDEQUIRECTANGULAR_FIXED = !1, this.INVERTCUBICMAP = !1, this.USESPHERICALFROMREFLECTIONMAP = !1, this.USEIRRADIANCEMAP = !1, this.USE_IRRADIANCE_DOMINANT_DIRECTION = !1, this.USESPHERICALINVERTEX = !1, this.REFLECTIONMAP_OPPOSITEZ = !1, this.LODINREFLECTIONALPHA = !1, this.GAMMAREFLECTION = !1, this.RGBDREFLECTION = !1
        }
      }
    }(xp)) {}
    class WK extends((0, qK.f)(nK)) {
      constructor(OO) {
        super(OO), this.NUM_SAMPLES = "0", this.REALTIME_FILTERING = !1, this.IBL_CDF_FILTERING = !1, this.LIGHTCOUNT = 0, this.VERTEXCOLOR = !1, this.BAKED_VERTEX_ANIMATION_TEXTURE = !1, this.VERTEXALPHA = !1, this.ALPHATEST = !1, this.DEPTHPREPASS = !1, this.ALPHABLEND = !1, this.ALPHA_FROM_BASE_COLOR_TEXTURE = !1, this.ALPHATESTVALUE = "0.5", this.PREMULTIPLYALPHA = !1, this.REFLECTIVITY_GAMMA = !1, this.REFLECTIVITYDIRECTUV = 0, this.SPECULARTERM = !1, this.LODBASEDMICROSFURACE = !0, this.SPECULAR_ROUGHNESS_FROM_METALNESS_TEXTURE_GREEN = !1, this.BASE_METALNESS_FROM_METALNESS_TEXTURE_BLUE = !1, this.AOSTOREINMETALMAPRED = !1, this.SPECULAR_WEIGHT_IN_ALPHA = !1, this.SPECULAR_WEIGHT_FROM_SPECULAR_COLOR_TEXTURE = !1, this.SPECULAR_ROUGHNESS_ANISOTROPY_FROM_TANGENT_TEXTURE = !1, this.COAT_ROUGHNESS_FROM_GREEN_CHANNEL = !1, this.COAT_ROUGHNESS_ANISOTROPY_FROM_TANGENT_TEXTURE = !1, this.USE_GLTF_STYLE_ANISOTROPY = !1, this.THIN_FILM_THICKNESS_FROM_THIN_FILM_TEXTURE = !1, this.FUZZ_ROUGHNESS_FROM_TEXTURE_ALPHA = !1, this.SUBSURFACE_WEIGHT_FROM_TEXTURE_ALPHA = !1, this.GEOMETRY_THICKNESS_FROM_GREEN_CHANNEL = !1, this.ENVIRONMENTBRDF = !1, this.ENVIRONMENTBRDF_RGBD = !1, this.FUZZENVIRONMENTBRDF = !1, this.NORMAL = !1, this.TANGENT = !1, this.OBJECTSPACE_NORMALMAP = !1, this.PARALLAX = !1, this.PARALLAX_RHS = !1, this.PARALLAXOCCLUSION = !1, this.NORMALXYSCALE = !0, this.ANISOTROPIC = !1, this.ANISOTROPIC_OPENPBR = !0, this.ANISOTROPIC_BASE = !1, this.ANISOTROPIC_COAT = !1, this.FUZZ_IBL_SAMPLES = 6, this.REFRACTION_HIGH_QUALITY_BLUR = !1, this.FUZZ = !1, this.THIN_FILM = !1, this.IRIDESCENCE = !1, this.DISPERSION = !1, this.SCATTERING = !1, this.USE_IRRADIANCE_TEXTURE_FOR_SCATTERING = !1, this.SSS_SAMPLE_COUNT = 16, this.USE_IRRADIANCE_TEXTURE_FOR_SCATTERING_GBUFFER = !1, this.TRANSMISSION_SLAB = !1, this.TRANSMISSION_SLAB_VOLUME = !1, this.SUBSURFACE_SLAB = !1, this.GEOMETRY_THIN_WALLED = !1, this.REFRACTED_BACKGROUND = !1, this.REFRACTED_LIGHTS = !1, this.REFRACTED_ENVIRONMENT = !1, this.REFRACTED_ENVIRONMENT_OPPOSITEZ = !1, this.REFRACTED_ENVIRONMENT_LOCAL_CUBE = !1, this.RADIANCEOCCLUSION = !1, this.HORIZONOCCLUSION = !1, this.INSTANCES = !1, this.THIN_INSTANCES = !1, this.INSTANCESCOLOR = !1, this.NUM_BONE_INFLUENCERS = 0, this.BonesPerMesh = 0, this.BONETEXTURE = !1, this.BONES_VELOCITY_ENABLED = !1, this.NONUNIFORMSCALING = !1, this.MORPHTARGETS = !1, this.MORPHTARGETS_POSITION = !1, this.MORPHTARGETS_NORMAL = !1, this.MORPHTARGETS_TANGENT = !1, this.MORPHTARGETS_UV = !1, this.MORPHTARGETS_UV2 = !1, this.MORPHTARGETS_COLOR = !1, this.MORPHTARGETTEXTURE_HASPOSITIONS = !1, this.MORPHTARGETTEXTURE_HASNORMALS = !1, this.MORPHTARGETTEXTURE_HASTANGENTS = !1, this.MORPHTARGETTEXTURE_HASUVS = !1, this.MORPHTARGETTEXTURE_HASUV2S = !1, this.MORPHTARGETTEXTURE_HASCOLORS = !1, this.NUM_MORPH_INFLUENCERS = 0, this.MORPHTARGETS_TEXTURE = !1, this.USEPHYSICALLIGHTFALLOFF = !1, this.USEGLTFLIGHTFALLOFF = !1, this.TWOSIDEDLIGHTING = !1, this.MIRRORED = !1, this.SHADOWFLOAT = !1, this.CLIPPLANE = !1, this.CLIPPLANE2 = !1, this.CLIPPLANE3 = !1, this.CLIPPLANE4 = !1, this.CLIPPLANE5 = !1, this.CLIPPLANE6 = !1, this.POINTSIZE = !1, this.FOG = !1, this.LOGARITHMICDEPTH = !1, this.CAMERA_ORTHOGRAPHIC = !1, this.CAMERA_PERSPECTIVE = !1, this.AREALIGHTSUPPORTED = !0, this.FORCENORMALFORWARD = !1, this.SPECULARAA = !1, this.UNLIT = !1, this.DECAL_AFTER_DETAIL = !1, this.TEXTURE_REPETITION_MODE = 0, this.DEBUGMODE = 0, this.USE_VERTEX_PULLING = !1, this.VERTEX_PULLING_USE_INDEX_BUFFER = !1, this.VERTEX_PULLING_INDEX_BUFFER_32BITS = !1, this.RIGHT_HANDED = !1, this.CLUSTLIGHT_SLICES = 0, this.CLUSTLIGHT_BATCH = 0, this.BRDF_V_HEIGHT_CORRELATED = !0, this.MS_BRDF_ENERGY_CONSERVATION = !0, this.SPHERICAL_HARMONICS = !0, this.SPECULAR_GLOSSINESS_ENERGY_CONSERVATION = !0, this.MIX_IBL_RADIANCE_WITH_IRRADIANCE = !0, this.LEGACY_SPECULAR_ENERGY_CONSERVATION = !1, this.BASE_DIFFUSE_MODEL = 0, this.DIELECTRIC_SPECULAR_MODEL = 1, this.CONDUCTOR_SPECULAR_MODEL = 1, this.rebuild()
      }
      reset() {
        super.reset(), this.ALPHATESTVALUE = "0.5", this.NORMALXYSCALE = !0
      }
    }
    class tp extends((0, LK.e)(nO.d)) {}
    let kp = (() => {
        var OO, KO, XO, bK, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO, QO, zK, AO, fO, dO, TO, NO, IO, YO, wO, iK, rK, sO, SO, JO, cK, BO, qK, nO, UO, OK, KK, pK, XK, bp, eK, lK, vp, CK, hK, FK, VK, LK, QK, zp, AK, fK, dK, TK, yp, gp, uK, EK, jp, YK, wK, ip, rp, PK, mp, sK, HK, RK, JK, BK, xp, nK, kp, UK, Op, Kp, pp, Xp, bX, ep, lp, vX, Cp, hp, Dp, Mp, aX, op, Fp, Vp, Lp, Qp, zX, Ap, fp, dp, Tp, Np, Ip, yX, gX, upO, Ep;
        let jX, Yp, wp, iX, rX, Pp, mX, sp, Hp, Rp, Sp, Jp, cX, Bp, Zp, Gp, qX, xX, np, Wp, tX, kX, Up, OX, KX, pX, XX, bb, eX, lX, vb, CX, hX, DX, MX, ab, oX, FX, VX, LX, QX, zb, AX, fX, dX, TX, NX, IX, yb, gb, uX, EX, jb, YX, wX, ib, rb, PX, mb, sX, HX, RX, SX, JX, cb, BX, ZX, GX, qb, xb, nX, WX, tb, kb, UX, Ob, Kb, pb, Xb, be, eb, lb, ve, Cb, hb, Db, Mb, ae, ob, Fb, Vb, Lb, Qb, ze, Ab, fb, db, Tb, Nb, Ib, ye, ge, ub, Eb, je, Yb = tp,
          wb = [],
          ie = [],
          re = [],
          Pb = [],
          me = [],
          sb = [],
          Hb = [],
          Rb = [],
          Sb = [],
          Jb = [],
          ce = [],
          Bb = [],
          Zb = [],
          Gb = [],
          qe = [],
          xe = [],
          nb = [],
          Wb = [],
          te = [],
          ke = [],
          Ub = [],
          Oe = [],
          Ke = [],
          pe = [],
          Xe = [],
          bl = [],
          ee = [],
          le = [],
          vl = [],
          Ce = [],
          he = [],
          De = [],
          Me = [],
          al = [],
          oe = [],
          Fe = [],
          Ve = [],
          Le = [],
          Qe = [],
          zl = [],
          Ae = [],
          fe = [],
          de = [],
          Te = [],
          Ne = [],
          Ie = [],
          yl = [],
          gl = [],
          ue = [],
          Ee = [],
          jl = [],
          Ye = [],
          we = [],
          il = [],
          rl = [],
          Pe = [],
          ml = [],
          se = [],
          He = [],
          Re = [],
          Se = [],
          Je = [],
          cl = [],
          Be = [],
          Ze = [],
          Ge = [],
          ql = [],
          xl = [],
          ne = [],
          We = [],
          tl = [],
          kl = [],
          Ue = [],
          Ol = [],
          Kl = [],
          pl = [],
          Xl = [],
          bv = [],
          el = [],
          ll = [],
          vv = [],
          Cl = [],
          hl = [],
          Dl = [],
          Ml = [],
          av = [],
          ol = [],
          Fl = [],
          Vl = [],
          Ll = [],
          Ql = [],
          zv = [],
          Al = [],
          fl = [],
          dl = [],
          Tl = [],
          Nl = [],
          Il = [],
          yv = [],
          gv = [],
          ul = [],
          El = [],
          jv = [],
          Yl = [],
          wl = [],
          iv = [],
          rv = [],
          Pl = [],
          mv = [],
          sl = [],
          Hl = [],
          Rl = [],
          Sl = [],
          Jl = [],
          cv = [],
          Bl = [],
          Zl = [],
          Gl = [],
          qv = [],
          xv = [],
          nl = [],
          Wl = [],
          tv = [],
          kv = [],
          Ul = [],
          Ov = [],
          Kv = [],
          pv = [],
          Xv = [],
          bC = [],
          ev = [],
          lv = [],
          vC = [],
          Cv = [],
          hv = [],
          Dv = [],
          Mv = [],
          aC = [],
          ov = [],
          Fv = [],
          Vv = [],
          Lv = [],
          Qv = [],
          zC = [],
          Av = [],
          fv = [],
          dv = [],
          Tv = [],
          Nv = [],
          Iv = [],
          yC = [],
          gC = [],
          uv = [],
          Ev = [],
          jC = [],
          Yv = [],
          wv = [],
          iC = [],
          rC = [],
          Pv = [],
          mC = [],
          sv = [],
          Hv = [],
          Rv = [],
          Sv = [],
          Jv = [],
          cC = [],
          Bv = [],
          Zv = [],
          Gv = [],
          qC = [],
          xC = [],
          nv = [],
          Wv = [],
          tC = [],
          kC = [],
          Uv = [],
          OC = [],
          KC = [],
          pC = [],
          XC = [],
          bh = [],
          eC = [],
          lC = [],
          vh = [],
          CC = [],
          hC = [],
          DC = [],
          MC = [],
          ah = [],
          oC = [],
          FC = [],
          VC = [],
          LC = [],
          QC = [],
          zh = [],
          AC = [],
          fC = [],
          dC = [],
          TC = [],
          NC = [],
          IC = [],
          yh = [],
          gh = [],
          uC = [];
        return OO = class extends Yb {
          get baseWeight() {
            return (0, yK.b)(this, KO, "f")
          }
          set baseWeight(OO) {
            (0, yK.e)(this, KO, OO, "f")
          }
          get baseWeightTexture() {
            return (0, yK.b)(this, XO, "f")
          }
          set baseWeightTexture(OO) {
            (0, yK.e)(this, XO, OO, "f")
          }
          get baseColor() {
            return (0, yK.b)(this, bK, "f")
          }
          set baseColor(OO) {
            (0, yK.e)(this, bK, OO, "f")
          }
          get baseColorTexture() {
            return (0, yK.b)(this, lO, "f")
          }
          set baseColorTexture(OO) {
            (0, yK.e)(this, lO, OO, "f")
          }
          get baseDiffuseRoughness() {
            return (0, yK.b)(this, vK, "f")
          }
          set baseDiffuseRoughness(OO) {
            (0, yK.e)(this, vK, OO, "f")
          }
          get baseDiffuseRoughnessTexture() {
            return (0, yK.b)(this, CO, "f")
          }
          set baseDiffuseRoughnessTexture(OO) {
            (0, yK.e)(this, CO, OO, "f")
          }
          get baseMetalness() {
            return (0, yK.b)(this, hO, "f")
          }
          set baseMetalness(OO) {
            (0, yK.e)(this, hO, OO, "f")
          }
          get baseMetalnessTexture() {
            return (0, yK.b)(this, DO, "f")
          }
          set baseMetalnessTexture(OO) {
            (0, yK.e)(this, DO, OO, "f")
          }
          get specularWeight() {
            return (0, yK.b)(this, MO, "f")
          }
          set specularWeight(OO) {
            (0, yK.e)(this, MO, OO, "f")
          }
          get specularWeightTexture() {
            return (0, yK.b)(this, aK, "f")
          }
          set specularWeightTexture(OO) {
            (0, yK.e)(this, aK, OO, "f")
          }
          get specularColor() {
            return (0, yK.b)(this, oO, "f")
          }
          set specularColor(OO) {
            (0, yK.e)(this, oO, OO, "f")
          }
          get specularColorTexture() {
            return (0, yK.b)(this, FO, "f")
          }
          set specularColorTexture(OO) {
            (0, yK.e)(this, FO, OO, "f")
          }
          get specularRoughness() {
            return (0, yK.b)(this, VO, "f")
          }
          set specularRoughness(OO) {
            (0, yK.e)(this, VO, OO, "f")
          }
          get specularRoughnessTexture() {
            return (0, yK.b)(this, LO, "f")
          }
          set specularRoughnessTexture(OO) {
            (0, yK.e)(this, LO, OO, "f")
          }
          get specularRoughnessAnisotropy() {
            return (0, yK.b)(this, QO, "f")
          }
          set specularRoughnessAnisotropy(OO) {
            (0, yK.e)(this, QO, OO, "f")
          }
          get specularRoughnessAnisotropyTexture() {
            return (0, yK.b)(this, zK, "f")
          }
          set specularRoughnessAnisotropyTexture(OO) {
            (0, yK.e)(this, zK, OO, "f")
          }
          get specularIor() {
            return (0, yK.b)(this, AO, "f")
          }
          set specularIor(OO) {
            (0, yK.e)(this, AO, OO, "f")
          }
          get transmissionWeight() {
            return (0, yK.b)(this, fO, "f")
          }
          set transmissionWeight(OO) {
            (0, yK.e)(this, fO, OO, "f")
          }
          get transmissionWeightTexture() {
            return (0, yK.b)(this, dO, "f")
          }
          set transmissionWeightTexture(OO) {
            (0, yK.e)(this, dO, OO, "f")
          }
          get transmissionColor() {
            return (0, yK.b)(this, TO, "f")
          }
          set transmissionColor(OO) {
            (0, yK.e)(this, TO, OO, "f")
          }
          get transmissionColorTexture() {
            return (0, yK.b)(this, NO, "f")
          }
          set transmissionColorTexture(OO) {
            (0, yK.e)(this, NO, OO, "f")
          }
          get transmissionDepth() {
            return (0, yK.b)(this, IO, "f")
          }
          set transmissionDepth(OO) {
            (0, yK.e)(this, IO, OO, "f")
          }
          get transmissionDepthTexture() {
            return (0, yK.b)(this, YO, "f")
          }
          set transmissionDepthTexture(OO) {
            (0, yK.e)(this, YO, OO, "f")
          }
          get transmissionScatter() {
            return (0, yK.b)(this, wO, "f")
          }
          set transmissionScatter(OO) {
            (0, yK.e)(this, wO, OO, "f")
          }
          get transmissionScatterTexture() {
            return (0, yK.b)(this, iK, "f")
          }
          set transmissionScatterTexture(OO) {
            (0, yK.e)(this, iK, OO, "f")
          }
          get transmissionScatterAnisotropy() {
            return (0, yK.b)(this, rK, "f")
          }
          set transmissionScatterAnisotropy(OO) {
            (0, yK.e)(this, rK, OO, "f")
          }
          get transmissionDispersionScale() {
            return (0, yK.b)(this, sO, "f")
          }
          set transmissionDispersionScale(OO) {
            (0, yK.e)(this, sO, OO, "f")
          }
          get transmissionDispersionScaleTexture() {
            return (0, yK.b)(this, SO, "f")
          }
          set transmissionDispersionScaleTexture(OO) {
            (0, yK.e)(this, SO, OO, "f")
          }
          get transmissionDispersionAbbeNumber() {
            return (0, yK.b)(this, JO, "f")
          }
          set transmissionDispersionAbbeNumber(OO) {
            (0, yK.e)(this, JO, OO, "f")
          }
          get subsurfaceWeight() {
            return (0, yK.b)(this, cK, "f")
          }
          set subsurfaceWeight(OO) {
            (0, yK.e)(this, cK, OO, "f")
          }
          get subsurfaceWeightTexture() {
            return (0, yK.b)(this, BO, "f")
          }
          set subsurfaceWeightTexture(OO) {
            (0, yK.e)(this, BO, OO, "f")
          }
          get subsurfaceColor() {
            return (0, yK.b)(this, qK, "f")
          }
          set subsurfaceColor(OO) {
            (0, yK.e)(this, qK, OO, "f")
          }
          get subsurfaceColorTexture() {
            return (0, yK.b)(this, nO, "f")
          }
          set subsurfaceColorTexture(OO) {
            (0, yK.e)(this, nO, OO, "f")
          }
          get subsurfaceRadius() {
            return (0, yK.b)(this, UO, "f")
          }
          set subsurfaceRadius(OO) {
            (0, yK.e)(this, UO, OO, "f")
          }
          get subsurfaceRadiusScale() {
            return (0, yK.b)(this, OK, "f")
          }
          set subsurfaceRadiusScale(OO) {
            (0, yK.e)(this, OK, OO, "f")
          }
          get subsurfaceRadiusScaleTexture() {
            return (0, yK.b)(this, KK, "f")
          }
          set subsurfaceRadiusScaleTexture(OO) {
            (0, yK.e)(this, KK, OO, "f")
          }
          get subsurfaceScatterAnisotropy() {
            return (0, yK.b)(this, pK, "f")
          }
          set subsurfaceScatterAnisotropy(OO) {
            (0, yK.e)(this, pK, OO, "f")
          }
          get coatWeight() {
            return (0, yK.b)(this, XK, "f")
          }
          set coatWeight(OO) {
            (0, yK.e)(this, XK, OO, "f")
          }
          get coatWeightTexture() {
            return (0, yK.b)(this, bp, "f")
          }
          set coatWeightTexture(OO) {
            (0, yK.e)(this, bp, OO, "f")
          }
          get coatColor() {
            return (0, yK.b)(this, eK, "f")
          }
          set coatColor(OO) {
            (0, yK.e)(this, eK, OO, "f")
          }
          get coatColorTexture() {
            return (0, yK.b)(this, lK, "f")
          }
          set coatColorTexture(OO) {
            (0, yK.e)(this, lK, OO, "f")
          }
          get coatRoughness() {
            return (0, yK.b)(this, vp, "f")
          }
          set coatRoughness(OO) {
            (0, yK.e)(this, vp, OO, "f")
          }
          get coatRoughnessTexture() {
            return (0, yK.b)(this, CK, "f")
          }
          set coatRoughnessTexture(OO) {
            (0, yK.e)(this, CK, OO, "f")
          }
          get coatRoughnessAnisotropy() {
            return (0, yK.b)(this, hK, "f")
          }
          set coatRoughnessAnisotropy(OO) {
            (0, yK.e)(this, hK, OO, "f")
          }
          get coatRoughnessAnisotropyTexture() {
            return (0, yK.b)(this, FK, "f")
          }
          set coatRoughnessAnisotropyTexture(OO) {
            (0, yK.e)(this, FK, OO, "f")
          }
          get coatIor() {
            return (0, yK.b)(this, VK, "f")
          }
          set coatIor(OO) {
            (0, yK.e)(this, VK, OO, "f")
          }
          get coatDarkening() {
            return (0, yK.b)(this, LK, "f")
          }
          set coatDarkening(OO) {
            (0, yK.e)(this, LK, OO, "f")
          }
          get coatDarkeningTexture() {
            return (0, yK.b)(this, QK, "f")
          }
          set coatDarkeningTexture(OO) {
            (0, yK.e)(this, QK, OO, "f")
          }
          get fuzzWeight() {
            return (0, yK.b)(this, zp, "f")
          }
          set fuzzWeight(OO) {
            (0, yK.e)(this, zp, OO, "f")
          }
          get fuzzWeightTexture() {
            return (0, yK.b)(this, AK, "f")
          }
          set fuzzWeightTexture(OO) {
            (0, yK.e)(this, AK, OO, "f")
          }
          get fuzzColor() {
            return (0, yK.b)(this, fK, "f")
          }
          set fuzzColor(OO) {
            (0, yK.e)(this, fK, OO, "f")
          }
          get fuzzColorTexture() {
            return (0, yK.b)(this, dK, "f")
          }
          set fuzzColorTexture(OO) {
            (0, yK.e)(this, dK, OO, "f")
          }
          get fuzzRoughness() {
            return (0, yK.b)(this, TK, "f")
          }
          set fuzzRoughness(OO) {
            (0, yK.e)(this, TK, OO, "f")
          }
          get fuzzRoughnessTexture() {
            return (0, yK.b)(this, yp, "f")
          }
          set fuzzRoughnessTexture(OO) {
            (0, yK.e)(this, yp, OO, "f")
          }
          get geometryThinWalled() {
            return (0, yK.b)(this, gp, "f")
          }
          set geometryThinWalled(OO) {
            (0, yK.e)(this, gp, OO, "f")
          }
          get geometryNormalTexture() {
            return (0, yK.b)(this, uK, "f")
          }
          set geometryNormalTexture(OO) {
            (0, yK.e)(this, uK, OO, "f")
          }
          get geometryTangent() {
            return (0, yK.b)(this, EK, "f")
          }
          set geometryTangent(OO) {
            (0, yK.e)(this, EK, OO, "f")
          }
          get geometryTangentAngle() {
            return Math.atan2(this.geometryTangent.y, this.geometryTangent.x)
          }
          set geometryTangentAngle(OO) {
            this.geometryTangent = new HO.m(Math.cos(OO), Math.sin(OO))
          }
          get geometryTangentTexture() {
            return (0, yK.b)(this, jp, "f")
          }
          set geometryTangentTexture(OO) {
            (0, yK.e)(this, jp, OO, "f")
          }
          get geometryCoatNormalTexture() {
            return (0, yK.b)(this, YK, "f")
          }
          set geometryCoatNormalTexture(OO) {
            (0, yK.e)(this, YK, OO, "f")
          }
          get geometryCoatTangent() {
            return (0, yK.b)(this, wK, "f")
          }
          set geometryCoatTangent(OO) {
            (0, yK.e)(this, wK, OO, "f")
          }
          get geometryCoatTangentAngle() {
            return Math.atan2(this.geometryCoatTangent.y, this.geometryCoatTangent.x)
          }
          set geometryCoatTangentAngle(OO) {
            this.geometryCoatTangent = new HO.m(Math.cos(OO), Math.sin(OO))
          }
          get geometryCoatTangentTexture() {
            return (0, yK.b)(this, ip, "f")
          }
          set geometryCoatTangentTexture(OO) {
            (0, yK.e)(this, ip, OO, "f")
          }
          get geometryOpacity() {
            return (0, yK.b)(this, rp, "f")
          }
          set geometryOpacity(OO) {
            (0, yK.e)(this, rp, OO, "f")
          }
          get geometryOpacityTexture() {
            return (0, yK.b)(this, PK, "f")
          }
          set geometryOpacityTexture(OO) {
            (0, yK.e)(this, PK, OO, "f")
          }
          get geometryThickness() {
            return (0, yK.b)(this, mp, "f")
          }
          set geometryThickness(OO) {
            (0, yK.e)(this, mp, OO, "f")
          }
          get geometryThicknessTexture() {
            return (0, yK.b)(this, sK, "f")
          }
          set geometryThicknessTexture(OO) {
            (0, yK.e)(this, sK, OO, "f")
          }
          get emissionLuminance() {
            return (0, yK.b)(this, HK, "f")
          }
          set emissionLuminance(OO) {
            (0, yK.e)(this, HK, OO, "f")
          }
          get emissionColor() {
            return (0, yK.b)(this, RK, "f")
          }
          set emissionColor(OO) {
            (0, yK.e)(this, RK, OO, "f")
          }
          get emissionColorTexture() {
            return (0, yK.b)(this, JK, "f")
          }
          set emissionColorTexture(OO) {
            (0, yK.e)(this, JK, OO, "f")
          }
          get thinFilmWeight() {
            return (0, yK.b)(this, BK, "f")
          }
          set thinFilmWeight(OO) {
            (0, yK.e)(this, BK, OO, "f")
          }
          get thinFilmWeightTexture() {
            return (0, yK.b)(this, xp, "f")
          }
          set thinFilmWeightTexture(OO) {
            (0, yK.e)(this, xp, OO, "f")
          }
          get thinFilmThickness() {
            return (0, yK.b)(this, nK, "f")
          }
          set thinFilmThickness(OO) {
            (0, yK.e)(this, nK, OO, "f")
          }
          get thinFilmThicknessMin() {
            return (0, yK.b)(this, kp, "f")
          }
          set thinFilmThicknessMin(OO) {
            (0, yK.e)(this, kp, OO, "f")
          }
          get thinFilmThicknessTexture() {
            return (0, yK.b)(this, UK, "f")
          }
          set thinFilmThicknessTexture(OO) {
            (0, yK.e)(this, UK, OO, "f")
          }
          get thinFilmIor() {
            return (0, yK.b)(this, Op, "f")
          }
          set thinFilmIor(OO) {
            (0, yK.e)(this, Op, OO, "f")
          }
          get ambientOcclusionTexture() {
            return (0, yK.b)(this, Kp, "f")
          }
          set ambientOcclusionTexture(OO) {
            (0, yK.e)(this, Kp, OO, "f")
          }
          get sssQuality() {
            return this._sssQuality
          }
          set sssQuality(OO) {
            this._sssQuality !== OO && (this._sssQuality = OO, this.jhO(1))
          }
          get sssIrradianceTexture() {
            return this._sssIrradianceTexture
          }
          set sssIrradianceTexture(OO) {
            this._sssIrradianceTexture !== OO && (this._sssIrradianceTexture = OO, this._markAllSubMeshesAsTexturesDirty())
          }
          get sssDepthTexture() {
            return this._sssDepthTexture
          }
          set sssDepthTexture(OO) {
            this._sssDepthTexture !== OO && (this._sssDepthTexture = OO, this._markAllSubMeshesAsTexturesDirty())
          }
          get directIntensity() {
            return (0, yK.b)(this, pp, "f")
          }
          set directIntensity(OO) {
            (0, yK.e)(this, pp, OO, "f")
          }
          get environmentIntensity() {
            return (0, yK.b)(this, Xp, "f")
          }
          set environmentIntensity(OO) {
            (0, yK.e)(this, Xp, OO, "f")
          }
          get useSpecularWeightFromTextureAlpha() {
            return (0, yK.b)(this, bX, "f")
          }
          set useSpecularWeightFromTextureAlpha(OO) {
            (0, yK.e)(this, bX, OO, "f")
          }
          get forceAlphaTest() {
            return (0, yK.b)(this, ep, "f")
          }
          set forceAlphaTest(OO) {
            (0, yK.e)(this, ep, OO, "f")
          }
          get alphaCutOff() {
            return (0, yK.b)(this, lp, "f")
          }
          set alphaCutOff(OO) {
            (0, yK.e)(this, lp, OO, "f")
          }
          get useAmbientOcclusionFromMetallicTextureRed() {
            return (0, yK.b)(this, vX, "f")
          }
          set useAmbientOcclusionFromMetallicTextureRed(OO) {
            (0, yK.e)(this, vX, OO, "f")
          }
          get useAmbientInGrayScale() {
            return (0, yK.b)(this, Cp, "f")
          }
          set useAmbientInGrayScale(OO) {
            (0, yK.e)(this, Cp, OO, "f")
          }
          get hasTransparency() {
            return this.subsurfaceWeight > 0 || this.transmissionWeight > 0
          }
          get hasScattering() {
            return this.transmissionWeight > 0 && this.transmissionDepth > 0 && !this.transmissionScatter.equals(GO.e.BlackReadOnly) || this.subsurfaceWeight > 0
          }
          get usePhysicalLightFalloff() {
            return this._lightFalloff === eO.b.LIGHTFALLOFF_PHYSICAL
          }
          set usePhysicalLightFalloff(OO) {
            OO !== this.usePhysicalLightFalloff && (this._markAllSubMeshesAsTexturesDirty(), this._lightFalloff = OO ? eO.b.LIGHTFALLOFF_PHYSICAL : eO.b.LIGHTFALLOFF_STANDARD)
          }
          get useGLTFLightFalloff() {
            return this._lightFalloff === eO.b.LIGHTFALLOFF_GLTF
          }
          set useGLTFLightFalloff(OO) {
            OO !== this.useGLTFLightFalloff && (this._markAllSubMeshesAsTexturesDirty(), this._lightFalloff = OO ? eO.b.LIGHTFALLOFF_GLTF : eO.b.LIGHTFALLOFF_STANDARD)
          }
          get useObjectSpaceNormalMap() {
            return (0, yK.b)(this, hp, "f")
          }
          set useObjectSpaceNormalMap(OO) {
            (0, yK.e)(this, hp, OO, "f")
          }
          get useParallax() {
            return (0, yK.b)(this, Dp, "f")
          }
          set useParallax(OO) {
            (0, yK.e)(this, Dp, OO, "f")
          }
          get useParallaxOcclusion() {
            return (0, yK.b)(this, Mp, "f")
          }
          set useParallaxOcclusion(OO) {
            (0, yK.e)(this, Mp, OO, "f")
          }
          get parallaxScaleBias() {
            return (0, yK.b)(this, aX, "f")
          }
          set parallaxScaleBias(OO) {
            (0, yK.e)(this, aX, OO, "f")
          }
          get disableLighting() {
            return (0, yK.b)(this, op, "f")
          }
          set disableLighting(OO) {
            (0, yK.e)(this, op, OO, "f")
          }
          get forceIrradianceInFragment() {
            return (0, yK.b)(this, Fp, "f")
          }
          set forceIrradianceInFragment(OO) {
            (0, yK.e)(this, Fp, OO, "f")
          }
          get maxSimultaneousLights() {
            return (0, yK.b)(this, Vp, "f")
          }
          set maxSimultaneousLights(OO) {
            (0, yK.e)(this, Vp, OO, "f")
          }
          get invertNormalMapX() {
            return (0, yK.b)(this, Lp, "f")
          }
          set invertNormalMapX(OO) {
            (0, yK.e)(this, Lp, OO, "f")
          }
          get invertNormalMapY() {
            return (0, yK.b)(this, Qp, "f")
          }
          set invertNormalMapY(OO) {
            (0, yK.e)(this, Qp, OO, "f")
          }
          get twoSidedLighting() {
            return (0, yK.b)(this, zX, "f")
          }
          set twoSidedLighting(OO) {
            (0, yK.e)(this, zX, OO, "f")
          }
          get useAlphaFresnel() {
            return (0, yK.b)(this, Ap, "f")
          }
          set useAlphaFresnel(OO) {
            (0, yK.e)(this, Ap, OO, "f")
          }
          get useLinearAlphaFresnel() {
            return (0, yK.b)(this, fp, "f")
          }
          set useLinearAlphaFresnel(OO) {
            (0, yK.e)(this, fp, OO, "f")
          }
          get environmentBRDFTexture() {
            return (0, yK.b)(this, dp, "f")
          }
          set environmentBRDFTexture(OO) {
            (0, yK.e)(this, dp, OO, "f")
          }
          get forceNormalForward() {
            return (0, yK.b)(this, Tp, "f")
          }
          set forceNormalForward(OO) {
            (0, yK.e)(this, Tp, OO, "f")
          }
          get enableSpecularAntiAliasing() {
            return (0, yK.b)(this, Np, "f")
          }
          set enableSpecularAntiAliasing(OO) {
            (0, yK.e)(this, Np, OO, "f")
          }
          get useHorizonOcclusion() {
            return (0, yK.b)(this, Ip, "f")
          }
          set useHorizonOcclusion(OO) {
            (0, yK.e)(this, Ip, OO, "f")
          }
          get useRadianceOcclusion() {
            return (0, yK.b)(this, yX, "f")
          }
          set useRadianceOcclusion(OO) {
            (0, yK.e)(this, yX, OO, "f")
          }
          get unlit() {
            return (0, yK.b)(this, gX, "f")
          }
          set unlit(OO) {
            (0, yK.e)(this, gX, OO, "f")
          }
          get applyDecalMapAfterDetailMap() {
            return (0, yK.b)(this, upO, "f")
          }
          set applyDecalMapAfterDetailMap(OO) {
            (0, yK.e)(this, upO, OO, "f")
          }
          get backgroundRefractionTexture() {
            return this._backgroundRefractionTexture
          }
          set backgroundRefractionTexture(OO) {
            this._backgroundRefractionTexture = OO, this._markAllSubMeshesAsTexturesDirty()
          }
          get refractionHighQualityBlur() {
            return this._refractionHighQualityBlur
          }
          set refractionHighQualityBlur(OO) {
            this._refractionHighQualityBlur !== OO && (this._refractionHighQualityBlur = OO, this.jhO(1))
          }
          get realTimeFiltering() {
            return this._realTimeFiltering
          }
          set realTimeFiltering(OO) {
            this._realTimeFiltering = OO, this.jhO(1)
          }
          get realTimeFilteringQuality() {
            return this._realTimeFilteringQuality
          }
          set realTimeFilteringQuality(OO) {
            this._realTimeFilteringQuality = OO, this.jhO(1)
          }
          get fuzzSampleNumber() {
            return this._fuzzSampleNumber
          }
          set fuzzSampleNumber(OO) {
            this._fuzzSampleNumber = OO, this.jhO(1)
          }
          get canRenderToMRT() {
            return !0
          }
          get debugMode() {
            return (0, yK.b)(this, Ep, "f")
          }
          set debugMode(OO) {
            (0, yK.e)(this, Ep, OO, "f")
          }
          constructor(pO, gK) {
            super(pO, gK, void 0, arguments.length > 2 && void 0 !== arguments[2] && arguments[2] || OO.ForceGLSL), KO.set(this, ((0, yK.i)(this, wb), (0, yK.i)(this, ie, void 0))), this._baseWeight = ((0, yK.i)(this, re), new GK("base_weight", 1, "vBaseWeight", 1)), XO.set(this, (0, yK.i)(this, Pb, void 0)), this._baseWeightTexture = ((0, yK.i)(this, me), new qp("base_weight", "baseWeight", "BASE_WEIGHT")), bK.set(this, (0, yK.i)(this, sb, void 0)), this._baseColor = ((0, yK.i)(this, Hb), new GK("base_color", GO.e.White(), "vBaseColor", 4)), lO.set(this, (0, yK.i)(this, Rb, void 0)), this._baseColorTexture = ((0, yK.i)(this, Sb), new qp("base_color", "baseColor", "BASE_COLOR")), vK.set(this, (0, yK.i)(this, Jb, void 0)), this._baseDiffuseRoughness = ((0, yK.i)(this, ce), new GK("base_diffuse_roughness", 0, "vBaseDiffuseRoughness", 1)), CO.set(this, (0, yK.i)(this, Bb, void 0)), this._baseDiffuseRoughnessTexture = ((0, yK.i)(this, Zb), new qp("base_diffuse_roughness", "baseDiffuseRoughness", "BASE_DIFFUSE_ROUGHNESS")), hO.set(this, (0, yK.i)(this, Gb, void 0)), this._baseMetalness = ((0, yK.i)(this, qe), new GK("base_metalness", 0, "vReflectanceInfo", 4, 0)), DO.set(this, (0, yK.i)(this, xe, void 0)), this._baseMetalnessTexture = ((0, yK.i)(this, nb), new qp("base_metalness", "baseMetalness", "BASE_METALNESS")), MO.set(this, (0, yK.i)(this, Wb, void 0)), this._specularWeight = ((0, yK.i)(this, te), new GK("specular_weight", 1, "vReflectanceInfo", 4, 3)), aK.set(this, (0, yK.i)(this, ke, void 0)), this._specularWeightTexture = ((0, yK.i)(this, Ub), new qp("specular_weight", "specularWeight", "SPECULAR_WEIGHT")), oO.set(this, (0, yK.i)(this, Oe, void 0)), this._specularColor = ((0, yK.i)(this, Ke), new GK("specular_color", GO.e.White(), "vSpecularColor", 4)), FO.set(this, (0, yK.i)(this, pe, void 0)), this._specularColorTexture = ((0, yK.i)(this, Xe), new qp("specular_color", "specularColor", "SPECULAR_COLOR")), VO.set(this, (0, yK.i)(this, bl, void 0)), this._specularRoughness = ((0, yK.i)(this, ee), new GK("specular_roughness", .3, "vReflectanceInfo", 4, 1)), LO.set(this, (0, yK.i)(this, le, void 0)), this._specularRoughnessTexture = ((0, yK.i)(this, vl), new qp("specular_roughness", "specularRoughness", "SPECULAR_ROUGHNESS")), QO.set(this, (0, yK.i)(this, Ce, void 0)), this._specularRoughnessAnisotropy = ((0, yK.i)(this, he), new GK("specular_roughness_anisotropy", 0, "vSpecularAnisotropy", 3, 2)), zK.set(this, (0, yK.i)(this, De, void 0)), this._specularRoughnessAnisotropyTexture = ((0, yK.i)(this, Me), new qp("specular_roughness_anisotropy", "specularRoughnessAnisotropy", "SPECULAR_ROUGHNESS_ANISOTROPY")), AO.set(this, (0, yK.i)(this, al, void 0)), this._specularIor = ((0, yK.i)(this, oe), new GK("specular_ior", 1.5, "vReflectanceInfo", 4, 2)), fO.set(this, (0, yK.i)(this, Fe, void 0)), this._transmissionWeight = ((0, yK.i)(this, Ve), new GK("transmission_weight", 0, "vTransmissionWeight", 1)), dO.set(this, (0, yK.i)(this, Le, void 0)), this._transmissionWeightTexture = ((0, yK.i)(this, Qe), new qp("transmission_weight", "transmissionWeight", "TRANSMISSION_WEIGHT")), TO.set(this, (0, yK.i)(this, zl, void 0)), this._transmissionColor = ((0, yK.i)(this, Ae), new GK("transmission_color", GO.e.White(), "vTransmissionColor", 3, 0)), NO.set(this, (0, yK.i)(this, fe, void 0)), this._transmissionColorTexture = ((0, yK.i)(this, de), new qp("transmission_color", "transmissionColor", "TRANSMISSION_COLOR")), IO.set(this, (0, yK.i)(this, Te, void 0)), this._transmissionDepth = ((0, yK.i)(this, Ne), new GK("transmission_depth", 0, "vTransmissionDepth", 1, 0)), YO.set(this, (0, yK.i)(this, Ie, void 0)), this._transmissionDepthTexture = ((0, yK.i)(this, yl), new qp("transmission_depth", "transmissionDepth", "TRANSMISSION_DEPTH")), wO.set(this, (0, yK.i)(this, gl, void 0)), this._transmissionScatter = ((0, yK.i)(this, ue), new GK("transmission_scatter", GO.e.Black(), "vTransmissionScatter", 3, 0)), iK.set(this, (0, yK.i)(this, Ee, void 0)), this._transmissionScatterTexture = ((0, yK.i)(this, jl), new qp("transmission_scatter", "transmissionScatter", "TRANSMISSION_SCATTER")), rK.set(this, (0, yK.i)(this, Ye, void 0)), this._transmissionScatterAnisotropy = ((0, yK.i)(this, we), new GK("transmission_scatter_anisotropy", 0, "vTransmissionScatterAnisotropy", 1, 0)), sO.set(this, (0, yK.i)(this, il, void 0)), this._transmissionDispersionScale = ((0, yK.i)(this, rl), new GK("transmission_dispersion_scale", 0, "vTransmissionDispersionScale", 1, 0)), SO.set(this, (0, yK.i)(this, Pe, void 0)), this._transmissionDispersionScaleTexture = ((0, yK.i)(this, ml), new qp("transmission_dispersion_scale", "transmissionDispersionScale", "TRANSMISSION_DISPERSION_SCALE")), JO.set(this, (0, yK.i)(this, se, void 0)), this._transmissionDispersionAbbeNumber = ((0, yK.i)(this, He), new GK("transmission_dispersion_abbe_number", 20, "vTransmissionDispersionAbbeNumber", 1, 0)), cK.set(this, (0, yK.i)(this, Re, void 0)), this._subsurfaceWeight = ((0, yK.i)(this, Se), new GK("subsurface_weight", 0, "vSubsurfaceWeight", 1, 0, "SUBSURFACE_SLAB")), BO.set(this, (0, yK.i)(this, Je, void 0)), this._subsurfaceWeightTexture = ((0, yK.i)(this, cl), new qp("subsurface_weight", "subsurfaceWeight", "SUBSURFACE_WEIGHT")), qK.set(this, (0, yK.i)(this, Be, void 0)), this._subsurfaceColor = ((0, yK.i)(this, Ze), new GK("subsurface_color", new GO.e(.8, .8, .8), "vSubsurfaceColor", 3, 0, "SUBSURFACE_SLAB")), nO.set(this, (0, yK.i)(this, Ge, void 0)), this._subsurfaceColorTexture = ((0, yK.i)(this, ql), new qp("subsurface_color", "subsurfaceColor", "SUBSURFACE_COLOR")), UO.set(this, (0, yK.i)(this, xl, void 0)), this._subsurfaceRadius = ((0, yK.i)(this, ne), new GK("subsurface_radius", .1, "vSubsurfaceRadius", 1, 0, "SUBSURFACE_SLAB")), OK.set(this, (0, yK.i)(this, We, void 0)), this._subsurfaceRadiusScale = ((0, yK.i)(this, tl), new GK("subsurface_radius_scale", new GO.e(1, .5, .25), "vSubsurfaceRadiusScale", 3, 0, "SUBSURFACE_SLAB")), KK.set(this, (0, yK.i)(this, kl, void 0)), this._subsurfaceRadiusScaleTexture = ((0, yK.i)(this, Ue), new qp("subsurface_radius_scale", "subsurfaceRadiusScale", "SUBSURFACE_RADIUS_SCALE")), pK.set(this, (0, yK.i)(this, Ol, void 0)), this._subsurfaceScatterAnisotropy = ((0, yK.i)(this, Kl), new GK("subsurface_scatter_anisotropy", 0, "vSubsurfaceScatterAnisotropy", 1, 0, "SUBSURFACE_SLAB")), XK.set(this, (0, yK.i)(this, pl, void 0)), this._coatWeight = ((0, yK.i)(this, Xl), new GK("coat_weight", 0, "vCoatWeight", 1, 0)), bp.set(this, (0, yK.i)(this, bv, void 0)), this._coatWeightTexture = ((0, yK.i)(this, el), new qp("coat_weight", "coatWeight", "COAT_WEIGHT")), eK.set(this, (0, yK.i)(this, ll, void 0)), this._coatColor = ((0, yK.i)(this, vv), new GK("coat_color", GO.e.White(), "vCoatColor", 3, 0)), lK.set(this, (0, yK.i)(this, Cl, void 0)), this._coatColorTexture = ((0, yK.i)(this, hl), new qp("coat_color", "coatColor", "COAT_COLOR")), vp.set(this, (0, yK.i)(this, Dl, void 0)), this._coatRoughness = ((0, yK.i)(this, Ml), new GK("coat_roughness", 0, "vCoatRoughness", 1, 0)), CK.set(this, (0, yK.i)(this, av, void 0)), this._coatRoughnessTexture = ((0, yK.i)(this, ol), new qp("coat_roughness", "coatRoughness", "COAT_ROUGHNESS")), hK.set(this, (0, yK.i)(this, Fl, void 0)), this._coatRoughnessAnisotropy = ((0, yK.i)(this, Vl), new GK("coat_roughness_anisotropy", 0, "vCoatRoughnessAnisotropy", 1)), FK.set(this, (0, yK.i)(this, Ll, void 0)), this._coatRoughnessAnisotropyTexture = ((0, yK.i)(this, Ql), new qp("coat_roughness_anisotropy", "coatRoughnessAnisotropy", "COAT_ROUGHNESS_ANISOTROPY")), VK.set(this, (0, yK.i)(this, zv, void 0)), this._coatIor = ((0, yK.i)(this, Al), new GK("coat_ior", 1.5, "vCoatIor", 1, 0)), LK.set(this, (0, yK.i)(this, fl, void 0)), this._coatDarkening = ((0, yK.i)(this, dl), new GK("coat_darkening", 1, "vCoatDarkening", 1, 0)), QK.set(this, (0, yK.i)(this, Tl, void 0)), this._coatDarkeningTexture = ((0, yK.i)(this, Nl), new qp("coat_darkening", "coatDarkening", "COAT_DARKENING")), this.useCoatRoughnessFromWeightTexture = !1, zp.set(this, (0, yK.i)(this, Il, void 0)), this._fuzzWeight = ((0, yK.i)(this, yv), new GK("fuzz_weight", 0, "vFuzzWeight", 1, 0)), AK.set(this, (0, yK.i)(this, gv, void 0)), this._fuzzWeightTexture = ((0, yK.i)(this, ul), new qp("fuzz_weight", "fuzzWeight", "FUZZ_WEIGHT")), fK.set(this, (0, yK.i)(this, El, void 0)), this._fuzzColor = ((0, yK.i)(this, jv), new GK("fuzz_color", GO.e.White(), "vFuzzColor", 3, 0)), dK.set(this, (0, yK.i)(this, Yl, void 0)), this._fuzzColorTexture = ((0, yK.i)(this, wl), new qp("fuzz_color", "fuzzColor", "FUZZ_COLOR")), TK.set(this, (0, yK.i)(this, iv, void 0)), this._fuzzRoughness = ((0, yK.i)(this, rv), new GK("fuzz_roughness", .5, "vFuzzRoughness", 1, 0)), yp.set(this, (0, yK.i)(this, Pl, void 0)), this._fuzzRoughnessTexture = ((0, yK.i)(this, mv), new qp("fuzz_roughness", "fuzzRoughness", "FUZZ_ROUGHNESS")), gp.set(this, (0, yK.i)(this, sl, void 0)), this._geometryThinWalled = ((0, yK.i)(this, Hl), new GK("geometry_thin_walled", 0, "vGeometryThinWalled", 1, 0)), uK.set(this, (0, yK.i)(this, Rl, void 0)), this._geometryNormalTexture = ((0, yK.i)(this, Sl), new qp("geometry_normal", "geometryNormal", "GEOMETRY_NORMAL")), EK.set(this, (0, yK.i)(this, Jl, void 0)), this._geometryTangent = ((0, yK.i)(this, cv), new GK("geometry_tangent", new HO.m(1, 0), "vSpecularAnisotropy", 3, 0)), jp.set(this, (0, yK.i)(this, Bl, void 0)), this._geometryTangentTexture = ((0, yK.i)(this, Zl), new qp("geometry_tangent", "geometryTangent", "GEOMETRY_TANGENT")), YK.set(this, (0, yK.i)(this, Gl, void 0)), this._geometryCoatNormalTexture = ((0, yK.i)(this, qv), new qp("geometry_coat_normal", "geometryCoatNormal", "GEOMETRY_COAT_NORMAL")), wK.set(this, (0, yK.i)(this, xv, void 0)), this._geometryCoatTangent = ((0, yK.i)(this, nl), new GK("geometry_coat_tangent", new HO.m(1, 0), "vGeometryCoatTangent", 2, 0)), ip.set(this, (0, yK.i)(this, Wl, void 0)), this._geometryCoatTangentTexture = ((0, yK.i)(this, tv), new qp("geometry_coat_tangent", "geometryCoatTangent", "GEOMETRY_COAT_TANGENT")), rp.set(this, (0, yK.i)(this, kv, void 0)), this._geometryOpacity = ((0, yK.i)(this, Ul), new GK("geometry_opacity", 1, "vBaseColor", 4, 3)), PK.set(this, (0, yK.i)(this, Ov, void 0)), this._geometryOpacityTexture = ((0, yK.i)(this, Kv), new qp("geometry_opacity", "geometryOpacity", "GEOMETRY_OPACITY")), mp.set(this, (0, yK.i)(this, pv, void 0)), this._geometryThickness = ((0, yK.i)(this, Xv), new GK("geometry_thickness", 0, "vGeometryThickness", 1, 0)), sK.set(this, (0, yK.i)(this, bC, void 0)), this._geometryThicknessTexture = ((0, yK.i)(this, ev), new qp("geometry_thickness", "geometryThickness", "GEOMETRY_THICKNESS")), HK.set(this, (0, yK.i)(this, lv, void 0)), this._emissionLuminance = ((0, yK.i)(this, vC), new GK("emission_luminance", 1, "vLightingIntensity", 4, 1)), RK.set(this, (0, yK.i)(this, Cv, void 0)), this._emissionColor = ((0, yK.i)(this, hv), new GK("emission_color", GO.e.Black(), "vEmissionColor", 3)), JK.set(this, (0, yK.i)(this, Dv, void 0)), this._emissionColorTexture = ((0, yK.i)(this, Mv), new qp("emission_color", "emissionColor", "EMISSION_COLOR")), BK.set(this, (0, yK.i)(this, aC, void 0)), this._thinFilmWeight = ((0, yK.i)(this, ov), new GK("thin_film_weight", 0, "vThinFilmWeight", 1, 0)), xp.set(this, (0, yK.i)(this, Fv, void 0)), this._thinFilmWeightTexture = ((0, yK.i)(this, Vv), new qp("thin_film_weight", "thinFilmWeight", "THIN_FILM_WEIGHT")), nK.set(this, (0, yK.i)(this, Lv, void 0)), this._thinFilmThickness = ((0, yK.i)(this, Qv), new GK("thin_film_thickness", .5, "vThinFilmThickness", 2, 0)), kp.set(this, (0, yK.i)(this, zC, void 0)), this._thinFilmThicknessMin = ((0, yK.i)(this, Av), new GK("thin_film_thickness_min", 0, "vThinFilmThickness", 2, 1)), UK.set(this, (0, yK.i)(this, fv, void 0)), this._thinFilmThicknessTexture = ((0, yK.i)(this, dv), new qp("thin_film_thickness", "thinFilmThickness", "THIN_FILM_THICKNESS")), Op.set(this, (0, yK.i)(this, Tv, void 0)), this._thinFilmIor = ((0, yK.i)(this, Nv), new GK("thin_film_ior", 1.4, "vThinFilmIor", 1, 0)), Kp.set(this, (0, yK.i)(this, Iv, void 0)), this._ambientOcclusionTexture = ((0, yK.i)(this, yC), new qp("ambient_occlusion", "ambientOcclusion", "AMBIENT_OCCLUSION")), this._sssQuality = OO.SSS_QUALITY_MEDIUM, this._sssIrradianceTexture = null, this._sssDepthTexture = null, this._uniformsList = {}, this._uniformsArray = [], this._samplersList = {}, this._samplerDefines = {}, pp.set(this, (0, yK.i)(this, gC, 1)), Xp.set(this, ((0, yK.i)(this, uv), (0, yK.i)(this, Ev, 1))), bX.set(this, ((0, yK.i)(this, jC), (0, yK.i)(this, Yv, !1))), ep.set(this, ((0, yK.i)(this, wv), (0, yK.i)(this, iC, !1))), lp.set(this, ((0, yK.i)(this, rC), (0, yK.i)(this, Pv, .4))), vX.set(this, ((0, yK.i)(this, mC), (0, yK.i)(this, sv, !1))), Cp.set(this, ((0, yK.i)(this, Hv), (0, yK.i)(this, Rv, !1))), hp.set(this, ((0, yK.i)(this, Sv), (0, yK.i)(this, Jv, !1))), Dp.set(this, ((0, yK.i)(this, cC), (0, yK.i)(this, Bv, !1))), Mp.set(this, ((0, yK.i)(this, Zv), (0, yK.i)(this, Gv, !1))), aX.set(this, ((0, yK.i)(this, qC), (0, yK.i)(this, xC, .05))), op.set(this, ((0, yK.i)(this, nv), (0, yK.i)(this, Wv, !1))), Fp.set(this, ((0, yK.i)(this, tC), (0, yK.i)(this, kC, !1))), Vp.set(this, ((0, yK.i)(this, Uv), (0, yK.i)(this, OC, 4))), Lp.set(this, ((0, yK.i)(this, KC), (0, yK.i)(this, pC, !1))), Qp.set(this, ((0, yK.i)(this, XC), (0, yK.i)(this, bh, !1))), zX.set(this, ((0, yK.i)(this, eC), (0, yK.i)(this, lC, !1))), Ap.set(this, ((0, yK.i)(this, vh), (0, yK.i)(this, CC, !1))), fp.set(this, ((0, yK.i)(this, hC), (0, yK.i)(this, DC, !1))), dp.set(this, ((0, yK.i)(this, MC), (0, yK.i)(this, ah, null))), Tp.set(this, ((0, yK.i)(this, oC), (0, yK.i)(this, FC, !1))), Np.set(this, ((0, yK.i)(this, VC), (0, yK.i)(this, LC, !1))), Ip.set(this, ((0, yK.i)(this, QC), (0, yK.i)(this, zh, !0))), yX.set(this, ((0, yK.i)(this, AC), (0, yK.i)(this, fC, !0))), gX.set(this, ((0, yK.i)(this, dC), (0, yK.i)(this, TC, !1))), upO.set(this, ((0, yK.i)(this, NC), (0, yK.i)(this, IC, !1))), this._lightingInfos = ((0, yK.i)(this, yh), new HO.s(this.directIntensity, 1, this.environmentIntensity, 1)), this._radianceTexture = null, this._useSpecularWeightFromAlpha = !1, this._useSpecularWeightFromSpecularColorTexture = !1, this._useSpecularRoughnessAnisotropyFromTangentTexture = !1, this._useCoatRoughnessAnisotropyFromTangentTexture = !1, this._useCoatRoughnessFromGreenChannel = !1, this._useGltfStyleAnisotropy = !1, this._useFuzzRoughnessFromTextureAlpha = !1, this._useSubsurfaceWeightFromTextureAlpha = !1, this._useHorizonOcclusion = !0, this._useRadianceOcclusion = !0, this._useAlphaFromBaseColorTexture = !1, this._useAmbientOcclusionFromMetallicTextureRed = !1, this._useRoughnessFromMetallicTextureGreen = !1, this._useMetallicFromMetallicTextureBlue = !1, this._useThinFilmThicknessFromTextureGreen = !1, this._useGeometryThicknessFromGreenChannel = !1, this._lightFalloff = eO.b.LIGHTFALLOFF_PHYSICAL, this._useObjectSpaceNormalMap = !1, this._useParallax = !1, this._useParallaxOcclusion = !1, this._parallaxScaleBias = .05, this._disableLighting = !1, this._maxSimultaneousLights = 4, this._invertNormalMapX = !1, this._invertNormalMapY = !1, this._twoSidedLighting = !1, this._alphaCutOff = .4, this._useAlphaFresnel = !1, this._useLinearAlphaFresnel = !1, this._environmentBRDFTexture = null, this._environmentFuzzBRDFTexture = null, this._backgroundRefractionTexture = null, this._refractionHighQualityBlur = !0, this._forceIrradianceInFragment = !1, this._realTimeFiltering = !1, this._realTimeFilteringQuality = 8, this._fuzzSampleNumber = 4, this._forceNormalForward = !1, this._enableSpecularAntiAliasing = !1, this._renderTargets = new EO.e(16), this._unlit = !1, this._applyDecalMapAfterDetailMap = !1, this._debugMode = 0, this._breakShaderLoadedCheck = !1, this._vertexPullingMetadata = null, Ep.set(this, (0, yK.i)(this, gh, 0)), this.debugLimit = ((0, yK.i)(this, uC), -1), this.debugFactor = 1, this._cacheHasRenderTargetTextures = !1, this._transparencyMode = eO.b.MATERIAL_OPAQUE, this.JKO() && !this.JKO()?.qb().isWebGPU && this.JKO().qb().ye < 2 && uO.b.Error("OpenPBRMaterial: WebGL 2.0 or above is required for this material."), OO._noiseTextures[this.JKO().uniqueId] || (OO._noiseTextures[this.JKO().uniqueId] = new jK.e(IK.k.GetAssetUrl("https://assets.babylonjs.com/core/blue_noise/blue_noise_rgb.png"), this.JKO(), !1, !0, 1), this.JKO().cpO.addOnce((() => {
              OO._noiseTextures[this.JKO().uniqueId]?.dispose(), delete OO._noiseTextures[this.JKO().uniqueId]
            }))), this._attachImageProcessingConfiguration(null), this.getRenderTargetTextures = () => (this._renderTargets.reset(), WO.e.ReflectionTextureEnabled && this._radianceTexture && this._radianceTexture.isRenderTarget && this._renderTargets.push(this._radianceTexture), WO.e.RefractionTextureEnabled && this._backgroundRefractionTexture && this._backgroundRefractionTexture.isRenderTarget && this._renderTargets.push(this._backgroundRefractionTexture), this._eventInfo.renderTargets = this._renderTargets, this._callbackPluginEventFillRenderTargetTextures(this._eventInfo), this._renderTargets), this._environmentBRDFTexture = mK(this.JKO()), this._environmentFuzzBRDFTexture = PO(this.JKO()), this.prePassConfiguration = new ZO.c, this._propertyList = {};
            for (const OO of Object.getOwnPropertyNames(this)) {
              const KO = this[OO];
              KO instanceof GK && (this._propertyList[OO] = KO)
            }
            Object.keys(this._propertyList).forEach((OO => {
              const KO = this._propertyList[OO];
              let pO = this._uniformsList[KO.targetUniformName];
              pO ? pO.numComponents !== KO.targetUniformComponentNum ? uO.b.Error(`Uniform ${KO.targetUniformName} already exists of size ${pO.numComponents}, but trying to set it to ${KO.targetUniformComponentNum}.`) : pO.requiredDefine !== KO.requiredDefine && (pO.requiredDefine = void 0) : (pO = new ZK(KO.targetUniformName, KO.targetUniformComponentNum), pO.requiredDefine = KO.requiredDefine, this._uniformsList[KO.targetUniformName] = pO), "" === pO.firstLinkedKey && (pO.firstLinkedKey = KO.name), pO.linkedProperties[KO.name] = KO
            })), this._uniformsArray = Object.values(this._uniformsList), this._samplersList = {};
            for (const OO of Object.getOwnPropertyNames(this)) {
              const KO = this[OO];
              KO instanceof qp && (this._samplersList[OO] = KO)
            }
            for (const OO in this._samplersList) {
              const KO = this._samplersList[OO].textureDefine;
              this._samplerDefines[KO] = {
                type: "boolean",
                default: !1
              }, this._samplerDefines[KO + "DIRECTUV"] = {
                type: "number",
                default: 0
              }, this._samplerDefines[KO + "_GAMMA"] = {
                type: "boolean",
                default: !1
              }
            }
            this._baseWeight, this._baseWeightTexture, this._baseColor, this._baseColorTexture, this._baseDiffuseRoughness, this._baseDiffuseRoughnessTexture, this._baseMetalness, this._baseMetalnessTexture, this._specularWeight, this._specularWeightTexture, this._specularColor, this._specularColorTexture, this._specularRoughness, this._specularIor, this._specularRoughnessTexture, this._specularRoughnessAnisotropy, this._specularRoughnessAnisotropyTexture, this._transmissionWeight, this._transmissionWeightTexture, this._transmissionColor, this._transmissionColorTexture, this._transmissionDepth, this._transmissionDepthTexture, this._transmissionScatter, this._transmissionScatterTexture, this._transmissionScatterAnisotropy, this._transmissionDispersionScale, this._transmissionDispersionScaleTexture, this._transmissionDispersionAbbeNumber, this._subsurfaceWeight, this._subsurfaceWeightTexture, this._subsurfaceColor, this._subsurfaceColorTexture, this._subsurfaceRadius, this._subsurfaceRadiusScale, this._subsurfaceRadiusScaleTexture, this._subsurfaceScatterAnisotropy, this._coatWeight, this._coatWeightTexture, this._coatColor, this._coatColorTexture, this._coatRoughness, this._coatRoughnessTexture, this._coatRoughnessAnisotropy, this._coatRoughnessAnisotropyTexture, this._coatIor, this._coatDarkening, this._coatDarkeningTexture, this._fuzzWeight, this._fuzzWeightTexture, this._fuzzColor, this._fuzzColorTexture, this._fuzzRoughness, this._fuzzRoughnessTexture, this._geometryThinWalled, this._geometryNormalTexture, this._geometryTangent, this._geometryTangentTexture, this._geometryCoatNormalTexture, this._geometryCoatTangent, this._geometryCoatTangentTexture, this._geometryOpacity, this._geometryOpacityTexture, this._geometryThickness, this._geometryThicknessTexture, this._thinFilmWeight, this._thinFilmWeightTexture, this._thinFilmThickness, this._thinFilmThicknessMin, this._thinFilmThicknessTexture, this._thinFilmIor, this._emissionLuminance, this._emissionColor, this._emissionColorTexture, this._ambientOcclusionTexture
          }
          get hasRenderTargetTextures() {
            return !!(WO.e.ReflectionTextureEnabled && this._radianceTexture && this._radianceTexture.isRenderTarget) || (!!(WO.e.RefractionTextureEnabled && this._backgroundRefractionTexture && this._backgroundRefractionTexture.isRenderTarget) || this._cacheHasRenderTargetTextures)
          }
          get isPrePassCapable() {
            return !this.disableDepthWrite
          }
          getClassName() {
            return "OpenPBRMaterial"
          }
          get transparencyMode() {
            return this._transparencyMode
          }
          set transparencyMode(OO) {
            this._transparencyMode !== OO && (this._transparencyMode = OO, this._markAllSubMeshesAsTexturesAndMiscDirty())
          }
          _shouldUseAlphaFromBaseColorTexture() {
            return this._hasAlphaChannel() && this._transparencyMode !== eO.b.MATERIAL_OPAQUE && !this.geometryOpacityTexture
          }
          _hasAlphaChannel() {
            return null != this.baseColorTexture && this.baseColorTexture.hasAlpha && this._useAlphaFromBaseColorTexture || null != this.geometryOpacityTexture
          }
          needAlphaBlending() {
            return this.geometryOpacity < 1 || null != this.geometryOpacityTexture
          }
          needAlphaBlendingForMesh(OO) {
            return this.geometryOpacity < 1 || null != this.geometryOpacityTexture || super.needAlphaBlendingForMesh(OO)
          }
          clone(KO) {
            let pO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
              XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
            const bK = NK.c.Clone((() => new OO(KO, this.JKO())), this, {
              cloneTexturesOnlyOnce: pO
            });
            return bK.id = KO, bK.name = KO, this.stencil.copyTo(bK.stencil), this._clonePlugins(bK, XO), bK
          }
          serialize() {
            const OO = super.serialize();
            return OO.customType = "BABYLON.OpenPBRMaterial", OO
          }
          static Parse(KO, pO, XO) {
            const bK = NK.c.Parse((() => new OO(KO.name, pO)), KO, pO, XO);
            return KO.stencil && bK.stencil.parse(KO.stencil, pO, XO), eO.b._ParsePlugins(KO, bK, pO, XO), bK
          }
          forceCompilation(OO, KO, pO) {
            const XO = {
              clipPlane: !1,
              useInstances: !1,
              ...pO
            };
            this._uniformBufferLayoutBuilt || this.buildUniformLayout(), this._callbackPluginEventGeneric(4, this._eventInfo);
            (() => {
              if (this._breakShaderLoadedCheck) return;
              const pO = new WK({
                  ...this._eventInfo.defineNames || {},
                  ...this._samplerDefines || {}
                }),
                bK = this._prepareEffect(OO, OO, pO, void 0, void 0, XO.useInstances, XO.clipPlane);
              this._onEffectCreatedObservable && (cp.effect = bK, cp.subMesh = null, this._onEffectCreatedObservable.notifyObservers(cp)), bK.isReady() ? KO && KO(this) : bK.onCompileObservable.add((() => {
                KO && KO(this)
              }))
            })()
          }
          isReadyForSubMesh(KO, pO, XO) {
            this._uniformBufferLayoutBuilt || this.buildUniformLayout();
            const bK = pO._drawWrapper;
            if (bK.effect && this.isFrozen && bK._wasPreviouslyReady && bK._wasPreviouslyUsingInstances === XO) return !0;
            pO.materialDefines || (this._callbackPluginEventGeneric(4, this._eventInfo), pO.materialDefines = new WK({
              ...this._eventInfo.defineNames || {},
              ...this._samplerDefines || {}
            }));
            const eO = pO.materialDefines;
            if (this._isReadyForSubMesh(pO)) return !0;
            const lO = this.JKO(),
              vK = lO.qb();
            if (eO._areTexturesDirty && (this._eventInfo.hasRenderTargetTextures = !1, this._callbackPluginEventHasRenderTargetTextures(this._eventInfo), this._cacheHasRenderTargetTextures = this._eventInfo.hasRenderTargetTextures, lO.texturesEnabled)) {
              for (const OO in this._samplersList) {
                const KO = this._samplersList[OO];
                if (KO.value && !KO.value.isReadyOrNotBlocking()) return !1
              }
              const KO = this._getRadianceTexture();
              if (KO && WO.e.ReflectionTextureEnabled) {
                if (!KO.isReadyOrNotBlocking()) return !1;
                if (KO.irradianceTexture) {
                  if (!KO.irradianceTexture.isReadyOrNotBlocking()) return !1
                } else if (!KO.sphericalPolynomial && KO.getInternalTexture()?._sphericalPolynomialPromise) return !1
              }
              if (this._environmentBRDFTexture && WO.e.ReflectionTextureEnabled && !this._environmentBRDFTexture.isReady()) return !1;
              if (this._environmentFuzzBRDFTexture && WO.e.ReflectionTextureEnabled && !this._environmentFuzzBRDFTexture.isReady()) return !1;
              if (this._backgroundRefractionTexture && WO.e.RefractionTextureEnabled && !this._backgroundRefractionTexture.isReadyOrNotBlocking()) return !1;
              if (OO._noiseTextures[lO.uniqueId] && !OO._noiseTextures[lO.uniqueId].isReady()) return !1;
              if (this._sssIrradianceTexture && this._sssDepthTexture) {
                if (!this._sssIrradianceTexture.isReady()) return !1;
                if (!this._sssDepthTexture.isReady()) return !1
              }
            }
            if (this._eventInfo.isReadyForSubMesh = !0, this._eventInfo.defines = eO, this._eventInfo.subMesh = pO, this._callbackPluginEventIsReadyForSubMesh(this._eventInfo), !this._eventInfo.isReadyForSubMesh) return !1;
            if (eO._areImageProcessingDirty && this._imageProcessingConfiguration && !this._imageProcessingConfiguration.isReady()) return !1;
            if (eO.AREALIGHTUSED)
              for (let OO = 0; OO < KO.lightSources.length; OO++)
                if (!KO.lightSources[OO]._isReady()) return !1;
            if (vK.getCaps().standardDerivatives || KO.isVerticesDataPresent(RO.j.NormalKind) || (KO.createNormals(!0), uO.b.Warn("OpenPBRMaterial: Normals have been created for the mesh: " + KO.name)), !(0, kK.c)(lO, KO, this._maxSimultaneousLights, this._disableLighting)) return !1;
            const CO = pO.effect,
              hO = eO._areLightsDisposed,
              DO = this._prepareEffect(KO, pO.getRenderingMesh(), eO, this.onCompiled, this.onError, XO, null);
            let MO = !1;
            if (DO)
              if (this._onEffectCreatedObservable && (cp.effect = DO, cp.subMesh = pO, this._onEffectCreatedObservable.notifyObservers(cp)), this.allowShaderHotSwapping && CO && !DO.isReady()) {
                if (eO.markAsUnprocessed(), MO = this.isFrozen, hO) return eO._areLightsDisposed = !0, !1
              } else lO.resetCachedMaterial(), pO.setEffect(DO, eO, this._materialContext);
            return !(!pO.effect || !pO.effect.isReady()) && (eO._renderId = lO.getRenderId(), bK._wasPreviouslyReady = !MO, bK._wasPreviouslyUsingInstances = !!XO, this._checkScenePerformancePriority(), !0)
          }
          buildUniformLayout() {
            const OO = this._uniformBuffer;
            OO.addUniform("vTangentSpaceParams", 2), OO.addUniform("vLightingIntensity", 4), OO.addUniform("pointSize", 1), OO.addUniform("vDebugMode", 2), OO.addUniform("renderTargetSize", 2), OO.addUniform("cameraInfo", 4), OO.addUniform("vTextureRepetitionHexTilingParams", 4), OO.addUniform("backgroundRefractionMatrix", 16), OO.addUniform("vBackgroundRefractionInfos", 3), (0, kK.nb)(OO, !0, !0, !0, !0, !0), Object.values(this._uniformsList).forEach((KO => {
              OO.addUniform(KO.name, KO.numComponents)
            })), Object.values(this._samplersList).forEach((KO => {
              OO.addUniform(KO.samplerInfoName, 2), OO.addUniform(KO.samplerMatrixName, 16)
            })), super.buildUniformLayout()
          }
          bindPropertiesForSubMesh(OO, KO, pO, XO) {
            if (0 === this.geometryThickness) OO.updateFloat("vGeometryThickness", 0);
            else {
              XO.getRenderingMesh().getWorldMatrix().decompose(HO.j.WX[0]);
              const KO = Math.max(Math.abs(HO.j.WX[0].x), Math.abs(HO.j.WX[0].y), Math.abs(HO.j.WX[0].z));
              OO.updateFloat("vGeometryThickness", this.geometryThickness * KO)
            }
          }
          bindForSubMesh(KO, pO, XO) {
            const bK = this.JKO(),
              eO = XO.materialDefines;
            if (!eO) return;
            const lO = XO.effect;
            if (!lO) return;
            this._activeEffect = lO, pO.getMeshUniformBuffer().bindToEffect(lO, "Mesh"), pO.transferToEffect(KO);
            const vK = bK.qb();
            this._uniformBuffer.bindToEffect(lO, "Material"), this.prePassConfiguration.bindForSubMesh(this._activeEffect, bK, pO, KO, this.isFrozen), oK.d.Bind(vK.currentRenderPassId, this._activeEffect, pO, KO, this);
            const CO = bK.activeCamera;
            CO ? this._uniformBuffer.updateFloat4("cameraInfo", CO.minZ, CO.maxZ, 0, 0) : this._uniformBuffer.updateFloat4("cameraInfo", 0, 0, 0, 0);
            const hO = this.textureRepetitionHexTilingParams;
            this._uniformBuffer.updateFloat4("vTextureRepetitionHexTilingParams", hO[0], hO[1], hO[2], hO[3]), this._eventInfo.subMesh = XO, this._callbackPluginEventHardBindForSubMesh(this._eventInfo), eO.OBJECTSPACE_NORMALMAP && (KO.toNormalMatrix(this._normalMatrix), this.bindOnlyNormalMatrix(this._normalMatrix));
            const DO = this._mustRebind(bK, lO, XO, pO.visibility),
              MO = vK._features.needToAlwaysBindUniformBuffers;
            (0, kK.g)(pO, this._activeEffect, this.prePassConfiguration), this._vertexPullingMetadata && (0, MK.c)(this._activeEffect, this._vertexPullingMetadata);
            const aK = this._uniformBuffer;
            if (DO) {
              this.bindViewProjection(lO);
              const KO = this._getRadianceTexture();
              if (!aK.useUbo || !this.isFrozen || !aK.isSync || XO._drawWrapper._forceRebindOnNextCall) {
                if (bK.texturesEnabled) {
                  for (const OO in this._samplersList) {
                    const KO = this._samplersList[OO];
                    KO.value && (aK.updateFloat2(KO.samplerInfoName, KO.value.coordinatesIndex, KO.value.level), (0, kK.B)(KO.value, aK, KO.samplerPrefix))
                  }(this.geometryNormalTexture || this.geometryCoatNormalTexture) && (bK._mirroredCameraPosition ? aK.updateFloat2("vTangentSpaceParams", this._invertNormalMapX ? 1 : -1, this._invertNormalMapY ? 1 : -1) : aK.updateFloat2("vTangentSpaceParams", this._invertNormalMapX ? -1 : 1, this._invertNormalMapY ? -1 : 1)), (0, kK.k)(bK, eO, aK, GO.e.White(), KO, this.realTimeFiltering, !0, !0, !0, !0, !0)
                }
                this.pointsCloud && aK.updateFloat("pointSize", this.pointSize);
                const OO = this._uniformsArray;
                for (let KO = 0, pO = OO.length; KO < pO; KO++) {
                  const pO = OO[KO];
                  (void 0 === pO.requiredDefine || eO[pO.requiredDefine]) && (4 === pO.numComponents ? (pO.populateVectorFromLinkedProperties(HO.j.Vector4[0]), aK.updateVector4(pO.name, HO.j.Vector4[0])) : 3 === pO.numComponents ? (pO.populateVectorFromLinkedProperties(HO.j.WX[0]), aK.updateVector3(pO.name, HO.j.WX[0])) : 2 === pO.numComponents ? (pO.populateVectorFromLinkedProperties(HO.j.Vector2[0]), aK.updateFloat2(pO.name, HO.j.Vector2[0].x, HO.j.Vector2[0].y)) : 1 === pO.numComponents && aK.updateFloat(pO.name, pO.linkedProperties[pO.firstLinkedKey].value))
                }
                this._lightingInfos.x = this.directIntensity, this._lightingInfos.y = this.emissionLuminance, this._lightingInfos.z = this.environmentIntensity * bK.environmentIntensity, this._lightingInfos.w = 1, aK.updateVector4("vLightingIntensity", this._lightingInfos), aK.updateFloat2("vDebugMode", this.debugLimit, this.debugFactor)
              }
              if (bK.texturesEnabled) {
                for (const OO in this._samplersList) {
                  const KO = this._samplersList[OO];
                  KO.value && aK.setTexture(KO.samplerName, KO.value)
                }
                if ((0, kK.n)(bK, eO, aK, KO, this.realTimeFiltering), eO.ENVIRONMENTBRDF && aK.setTexture("environmentBrdfSampler", this._environmentBRDFTexture), eO.FUZZENVIRONMENTBRDF && aK.setTexture("environmentFuzzBrdfSampler", this._environmentFuzzBRDFTexture), eO.REFRACTED_BACKGROUND && (aK.setTexture("backgroundRefractionSampler", this._backgroundRefractionTexture), aK.AlO("backgroundRefractionMatrix", this._backgroundRefractionTexture.getReflectionTextureMatrix()), HO.j.WX[1].set(Math.log2(this._backgroundRefractionTexture.getSize().width), 0, 0), aK.updateVector3("vBackgroundRefractionInfos", HO.j.WX[1])), (eO.ANISOTROPIC || eO.FUZZ || eO.REFRACTED_BACKGROUND || eO.USE_IRRADIANCE_TEXTURE_FOR_SCATTERING) && aK.setTexture("blueNoiseSampler", OO._noiseTextures[this.JKO().uniqueId]), eO.USE_IRRADIANCE_TEXTURE_FOR_SCATTERING && this.sssIrradianceTexture && this.sssDepthTexture) {
                  const OO = this.sssIrradianceTexture.getSize().width,
                    KO = this.sssIrradianceTexture.getSize().height;
                  aK.setTexture("sceneIrradianceSampler", this.sssIrradianceTexture), aK.setTexture("sceneDepthSampler", this.sssDepthTexture), aK.updateFloat2("renderTargetSize", OO, KO)
                }
              }
              this.JKO().useOrderIndependentTransparency && this.needAlphaBlendingForMesh(pO) && this.JKO().depthPeelingRenderer.bind(lO), this._eventInfo.subMesh = XO, this._callbackPluginEventBindForSubMesh(this._eventInfo), (0, DK.e)(this._activeEffect, this, bK), this.bindEyePosition(lO)
            } else MO && (this._needToBindSceneUbo = !0);
            this.bindPropertiesForSubMesh(this._uniformBuffer, bK, bK.qb(), XO), !DO && this.isFrozen && !MO || !bK.lightsEnabled || this._disableLighting || (0, kK.r)(bK, pO, this._activeEffect, eO, this._maxSimultaneousLights), !DO && this.isFrozen || (this.bindView(lO), (0, kK.i)(bK, pO, this._activeEffect, !0), eO.NUM_MORPH_INFLUENCERS && (0, kK.w)(pO, this._activeEffect), eO.BAKED_VERTEX_ANIMATION_TEXTURE && pO.bakedVertexAnimationManager?.bind(lO, eO.INSTANCES), this._imageProcessingConfiguration.bind(this._activeEffect), (0, kK.s)(eO, this._activeEffect, bK)), this._afterBind(pO, this._activeEffect, XO), aK.update()
          }
          getAnimatables() {
            const OO = super.getAnimatables();
            for (const KO in this._samplersList) {
              const pO = this._samplersList[KO];
              pO.value && pO.value.animations && pO.value.animations.length > 0 && OO.push(pO.value)
            }
            return this._radianceTexture && this._radianceTexture.animations && this._radianceTexture.animations.length > 0 && OO.push(this._radianceTexture), OO
          }
          getActiveTextures() {
            const OO = super.getActiveTextures();
            for (const KO in this._samplersList) {
              const pO = this._samplersList[KO];
              pO.value && OO.push(pO.value)
            }
            return this._radianceTexture && OO.push(this._radianceTexture), OO
          }
          hasTexture(OO) {
            if (super.hasTexture(OO)) return !0;
            for (const KO in this._samplersList) {
              if (this._samplersList[KO].value === OO) return !0
            }
            return this._radianceTexture === OO
          }
          setPrePassRenderer() {
            return !1
          }
          dispose(OO, KO) {
            if (this._breakShaderLoadedCheck = !0, KO) {
              this._environmentBRDFTexture && this.JKO().openPBREnvironmentBRDFTexture !== this._environmentBRDFTexture && this._environmentBRDFTexture.dispose(), this._environmentFuzzBRDFTexture && this.JKO().environmentFuzzBRDFTexture !== this._environmentFuzzBRDFTexture && this._environmentFuzzBRDFTexture.dispose(), this._backgroundRefractionTexture = null;
              for (const OO in this._samplersList) {
                const KO = this._samplersList[OO];
                KO.value?.dispose()
              }
              this._radianceTexture?.dispose()
            }
            this._renderTargets.dispose(), this._imageProcessingConfiguration && this._imageProcessingObserver && this._imageProcessingConfiguration.onUpdateParameters.remove(this._imageProcessingObserver), super.dispose(OO, KO)
          }
          _getRadianceTexture() {
            return this._radianceTexture ? this._radianceTexture : this.JKO().environmentTexture
          }
          _prepareEffect(KO, pO, XO) {
            let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
              eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
              lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
              vK = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null;
            if (this._prepareDefines(KO, pO, XO, lO, vK), !XO.isDirty) return null;
            XO.markAsProcessed();
            const CO = this.JKO().qb(),
              hO = new tK.c;
            let DO = 0;
            XO.USESPHERICALINVERTEX && hO.addFallback(DO++, "USESPHERICALINVERTEX"), XO.FOG && hO.addFallback(DO, "FOG"), XO.SPECULARAA && hO.addFallback(DO, "SPECULARAA"), XO.POINTSIZE && hO.addFallback(DO, "POINTSIZE"), XO.LOGARITHMICDEPTH && hO.addFallback(DO, "LOGARITHMICDEPTH"), XO.PARALLAX && hO.addFallback(DO, "PARALLAX"), XO.PARALLAX_RHS && hO.addFallback(DO, "PARALLAX_RHS"), XO.PARALLAXOCCLUSION && hO.addFallback(DO++, "PARALLAXOCCLUSION"), XO.ENVIRONMENTBRDF && hO.addFallback(DO++, "ENVIRONMENTBRDF"), XO.TANGENT && hO.addFallback(DO++, "TANGENT"), DO = (0, kK.F)(XO, hO, this._maxSimultaneousLights, DO), XO.SPECULARTERM && hO.addFallback(DO++, "SPECULARTERM"), XO.USESPHERICALFROMREFLECTIONMAP && hO.addFallback(DO++, "USESPHERICALFROMREFLECTIONMAP"), XO.USEIRRADIANCEMAP && hO.addFallback(DO++, "USEIRRADIANCEMAP"), XO.NORMAL && hO.addFallback(DO++, "NORMAL"), XO.VERTEXCOLOR && hO.addFallback(DO++, "VERTEXCOLOR"), XO.MORPHTARGETS && hO.addFallback(DO++, "MORPHTARGETS"), XO.MULTIVIEW && hO.addFallback(0, "MULTIVIEW");
            const MO = [RO.j.PositionKind];
            XO.NORMAL && MO.push(RO.j.NormalKind), XO.TANGENT && MO.push(RO.j.TangentKind);
            for (let OO = 1; OO <= 6; ++OO) XO["UV" + OO] && MO.push(`uv${1===OO?"":OO}`);
            XO.VERTEXCOLOR && MO.push(RO.j.ColorKind), (0, kK.H)(MO, KO, XO, hO), (0, kK.L)(MO, XO), (0, kK.N)(MO, KO, XO), (0, kK.G)(MO, KO, XO);
            let aK = "openpbr";
            const oO = ["world", "view", "viewProjection", "projection", "vEyePosition", "inverseProjection", "renderTargetSize", "vLightsType", "visibility", "vFogInfos", "vFogColor", "pointSize", "mBones", "normalMatrix", "vLightingIntensity", "logarithmicDepthConstant", "vTangentSpaceParams", "boneTextureInfo", "vDebugMode", "morphTargetTextureInfo", "morphTargetTextureIndices", "cameraInfo", "vTextureRepetitionHexTilingParams", "backgroundRefractionMatrix", "vBackgroundRefractionInfos"];
            for (const OO in this._uniformsList) oO.push(OO);
            const FO = ["environmentBrdfSampler", "boneSampler", "morphTargets", "oitDepthSampler", "oitFrontColorSampler", "areaLightsLTC1Sampler", "areaLightsLTC2Sampler"];
            XO.FUZZENVIRONMENTBRDF && FO.push("environmentFuzzBrdfSampler"), XO.REFRACTED_BACKGROUND && FO.push("backgroundRefractionSampler"), (XO.ANISOTROPIC || XO.FUZZ || XO.REFRACTED_BACKGROUND || XO.USE_IRRADIANCE_TEXTURE_FOR_SCATTERING) && FO.push("blueNoiseSampler"), XO.USE_IRRADIANCE_TEXTURE_FOR_SCATTERING && (FO.push("sceneIrradianceSampler"), FO.push("sceneDepthSampler"));
            for (const OO in this._samplersList) {
              const KO = this._samplersList[OO];
              FO.push(KO.samplerName), oO.push(KO.samplerInfoName), oO.push(KO.samplerMatrixName)
            }(0, kK.rb)(oO, FO, !0);
            const VO = ["Material", "Scene", "Mesh"],
              LO = {
                maxSimultaneousLights: this._maxSimultaneousLights,
                maxSimultaneousMorphTargets: XO.NUM_MORPH_INFLUENCERS
              };
            if (this._eventInfo.fallbacks = hO, this._eventInfo.fallbackRank = DO, this._eventInfo.defines = XO, this._eventInfo.uniforms = oO, this._eventInfo.attributes = MO, this._eventInfo.samplers = FO, this._eventInfo.uniformBuffersNames = VO, this._eventInfo.customCode = void 0, this._eventInfo.mesh = KO, this._eventInfo.indexParameters = LO, this._callbackPluginEventGeneric(128, this._eventInfo), oK.d.AddUniformsAndSamplers(oO, FO), ZO.c.AddUniforms(oO), ZO.c.AddSamplers(FO), (0, DK.c)(oO), this._useVertexPulling) {
              const OO = pO?.geometry;
              OO && (this._vertexPullingMetadata = (0, MK.e)(OO), this._vertexPullingMetadata && this._vertexPullingMetadata.forEach(((OO, KO) => {
                oO.push(`vp_${KO}_info`)
              })))
            } else this._vertexPullingMetadata = null;
            xK.d && (xK.d.PrepareUniforms(oO, XO), xK.d.PrepareSamplers(FO, XO)), (0, kK.ub)({
              uniformsNames: oO,
              uniformBuffersNames: VO,
              samplers: FO,
              defines: XO,
              maxSimultaneousLights: this._maxSimultaneousLights,
              shaderLanguage: this._shaderLanguage
            });
            const QO = {};
            this.customShaderNameResolve && (aK = this.customShaderNameResolve(aK, oO, VO, FO, XO, MO, QO));
            const zK = XO.toString(),
              AO = CO.createEffect(aK, {
                attributes: MO,
                uniformsNames: oO,
                uniformBuffersNames: VO,
                samplers: FO,
                defines: zK,
                fallbacks: hO,
                onCompiled: bK,
                onError: eO,
                indexParameters: LO,
                processFinalCode: QO.processFinalCode,
                processCodeAfterIncludes: this._eventInfo.customCode,
                multiTarget: XO.PREPASS,
                shaderLanguage: this._shaderLanguage,
                extraInitializationsAsync: OO._ShaderLoader.getLoadCallback(this._shaderLanguage)
              }, CO);
            return this._eventInfo.customCode = void 0, AO
          }
          _prepareDefines(KO, pO, XO) {
            let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
              lO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
            const vK = pO.hasThinInstances,
              CO = this.JKO(),
              hO = CO.qb();
            (0, kK._)(CO, KO, XO, !0, this._maxSimultaneousLights, this._disableLighting), XO._needNormals = !0, (0, kK.hb)(CO, XO);
            const DO = this.needAlphaBlendingForMesh(KO) && this.JKO().useOrderIndependentTransparency;
            if ((0, kK.mb)(CO, XO, this.canRenderToMRT && !DO), (0, kK.ib)(CO, XO, DO), oK.d.PrepareDefines(hO.currentRenderPassId, KO, XO), XO._areTexturesDirty) {
              XO._needUVs = !1;
              for (let OO = 1; OO <= 6; ++OO) XO["MAINUV" + OO] = !1;
              if (CO.texturesEnabled) {
                for (const pO in this._samplersList) {
                  const OO = this._samplersList[pO];
                  OO.value ? ((0, kK.bb)(OO.value, XO, OO.textureDefine), XO[OO.textureDefine + "_GAMMA"] = OO.value.gammaSpace) : XO[OO.textureDefine] = !1
                }
                const OO = this._getRadianceTexture(),
                  KO = this._forceIrradianceInFragment || this.realTimeFiltering || this._twoSidedLighting || hO.getCaps().maxVaryingVectors <= 8 || null != this._baseDiffuseRoughnessTexture;
                if ((0, kK.Z)(CO, OO, XO, this.realTimeFiltering, this.realTimeFilteringQuality, !KO), this._baseMetalnessTexture && (XO.AOSTOREINMETALMAPRED = this._useAmbientOcclusionFromMetallicTextureRed), XO.SPECULAR_WEIGHT_IN_ALPHA = this._useSpecularWeightFromAlpha, XO.SPECULAR_WEIGHT_FROM_SPECULAR_COLOR_TEXTURE = this._useSpecularWeightFromSpecularColorTexture, XO.SPECULAR_ROUGHNESS_ANISOTROPY_FROM_TANGENT_TEXTURE = this._useSpecularRoughnessAnisotropyFromTangentTexture, XO.COAT_ROUGHNESS_ANISOTROPY_FROM_TANGENT_TEXTURE = this._useCoatRoughnessAnisotropyFromTangentTexture, XO.COAT_ROUGHNESS_FROM_GREEN_CHANNEL = this._useCoatRoughnessFromGreenChannel, XO.SPECULAR_ROUGHNESS_FROM_METALNESS_TEXTURE_GREEN = this._useRoughnessFromMetallicTextureGreen, XO.FUZZ_ROUGHNESS_FROM_TEXTURE_ALPHA = this._useFuzzRoughnessFromTextureAlpha, XO.SUBSURFACE_WEIGHT_FROM_TEXTURE_ALPHA = this._useSubsurfaceWeightFromTextureAlpha, XO.BASE_METALNESS_FROM_METALNESS_TEXTURE_BLUE = this._useMetallicFromMetallicTextureBlue, XO.THIN_FILM_THICKNESS_FROM_THIN_FILM_TEXTURE = this._useThinFilmThicknessFromTextureGreen, XO.GEOMETRY_THICKNESS_FROM_GREEN_CHANNEL = this._useGeometryThicknessFromGreenChannel, this.geometryNormalTexture ? (this._useParallax && this.baseColorTexture && WO.e.DiffuseTextureEnabled ? (XO.PARALLAX = !0, XO.PARALLAX_RHS = CO.useRightHandedSystem, XO.PARALLAXOCCLUSION = !!this._useParallaxOcclusion) : XO.PARALLAX = !1, XO.OBJECTSPACE_NORMALMAP = this._useObjectSpaceNormalMap) : (XO.PARALLAX = !1, XO.PARALLAX_RHS = !1, XO.PARALLAXOCCLUSION = !1, XO.OBJECTSPACE_NORMALMAP = !1), this._environmentBRDFTexture && WO.e.ReflectionTextureEnabled ? (XO.ENVIRONMENTBRDF = !0, XO.ENVIRONMENTBRDF_RGBD = this._environmentBRDFTexture.isRGBD) : (XO.ENVIRONMENTBRDF = !1, XO.ENVIRONMENTBRDF_RGBD = !1), this._environmentFuzzBRDFTexture ? XO.FUZZENVIRONMENTBRDF = !0 : XO.FUZZENVIRONMENTBRDF = !1, this.hasTransparency) {
                  XO.REFRACTED_BACKGROUND = !!this._backgroundRefractionTexture && WO.e.RefractionTextureEnabled, XO.REFRACTION_HIGH_QUALITY_BLUR = this._refractionHighQualityBlur, XO.REFRACTED_LIGHTS = !0;
                  const OO = this._getRadianceTexture();
                  OO ? (XO.REFRACTED_ENVIRONMENT = WO.e.RefractionTextureEnabled, XO.REFRACTED_ENVIRONMENT_OPPOSITEZ = this.JKO().useRightHandedSystem ? !OO.invertZ : OO.invertZ, XO.REFRACTED_ENVIRONMENT_LOCAL_CUBE = OO.isCube && OO.boundingBoxSize) : XO.REFRACTED_ENVIRONMENT = !1
                } else XO.REFRACTED_BACKGROUND = !1, XO.REFRACTED_LIGHTS = !1, XO.REFRACTED_ENVIRONMENT = !1;
                this._shouldUseAlphaFromBaseColorTexture() ? XO.ALPHA_FROM_BASE_COLOR_TEXTURE = !0 : XO.ALPHA_FROM_BASE_COLOR_TEXTURE = !1
              }
              this._lightFalloff === eO.b.LIGHTFALLOFF_STANDARD ? (XO.USEPHYSICALLIGHTFALLOFF = !1, XO.USEGLTFLIGHTFALLOFF = !1) : this._lightFalloff === eO.b.LIGHTFALLOFF_GLTF ? (XO.USEPHYSICALLIGHTFALLOFF = !1, XO.USEGLTFLIGHTFALLOFF = !0) : (XO.USEPHYSICALLIGHTFALLOFF = !0, XO.USEGLTFLIGHTFALLOFF = !1), !this.backFaceCulling && this._twoSidedLighting ? XO.TWOSIDEDLIGHTING = !0 : XO.TWOSIDEDLIGHTING = !1, XO.MIRRORED = !!CO._mirroredCameraPosition, XO.SPECULARAA = hO.getCaps().standardDerivatives && this._enableSpecularAntiAliasing
            }(XO._areTexturesDirty || XO._areMiscDirty) && (XO.ALPHATESTVALUE = `${this._alphaCutOff}${this._alphaCutOff%1===0?".":""}`, XO.PREMULTIPLYALPHA = 7 === this.alphaMode || 8 === this.alphaMode, XO.ALPHABLEND = this.needAlphaBlendingForMesh(KO)), XO._areTexturesDirty && (XO.TEXTURE_REPETITION_MODE = hO.version > 1 || hO.isWebGPU ? this.textureRepetitionMode : 0), XO._areImageProcessingDirty && this._imageProcessingConfiguration && this._imageProcessingConfiguration.prepareDefines(XO), XO.FORCENORMALFORWARD = this._forceNormalForward, XO.RADIANCEOCCLUSION = this._useRadianceOcclusion, XO.HORIZONOCCLUSION = this._useHorizonOcclusion, (this.specularRoughnessAnisotropy > 0 || this.coatRoughnessAnisotropy > 0) && OO._noiseTextures[CO.uniqueId] && WO.e.ReflectionTextureEnabled ? (XO.ANISOTROPIC = !0, KO.isVerticesDataPresent(RO.j.TangentKind) || (XO._needUVs = !0, XO.MAINUV1 = !0), this._useGltfStyleAnisotropy && (XO.USE_GLTF_STYLE_ANISOTROPY = !0), XO.ANISOTROPIC_BASE = this.specularRoughnessAnisotropy > 0, XO.ANISOTROPIC_COAT = this.coatRoughnessAnisotropy > 0) : (XO.ANISOTROPIC = !1, XO.USE_GLTF_STYLE_ANISOTROPY = !1, XO.ANISOTROPIC_BASE = !1, XO.ANISOTROPIC_COAT = !1), XO.THIN_FILM = this.thinFilmWeight > 0, XO.IRIDESCENCE = this.thinFilmWeight > 0, XO.DISPERSION = this.transmissionDispersionScale > 0, XO.SCATTERING = this.hasScattering;
            if (XO.SSS_SAMPLE_COUNT = [8, 16, 32][this._sssQuality] ?? 16, XO.TRANSMISSION_SLAB = this.transmissionWeight > 0, XO.TRANSMISSION_SLAB_VOLUME = this.transmissionWeight > 0 && this.transmissionDepth > 0, XO.SUBSURFACE_SLAB = this.subsurfaceWeight > 0, !XO.PREPASS && (XO.SUBSURFACE_SLAB || XO.TRANSMISSION_SLAB_VOLUME)) {
              let OO = !1;
              if (!this.sssIrradianceTexture && CO.geometryBufferRenderer) {
                const KO = CO.geometryBufferRenderer.getTextureIndex(SK.IRRADIANCE_TEXTURE_TYPE);
                this.sssIrradianceTexture = CO.geometryBufferRenderer.getGBuffer().textures[KO], OO = !0
              }
              if (!this.sssDepthTexture && CO.geometryBufferRenderer) {
                const KO = CO.geometryBufferRenderer.getTextureIndex(SK.SCREENSPACE_DEPTH_TEXTURE_TYPE);
                this.sssDepthTexture = CO.geometryBufferRenderer.getGBuffer().textures[KO], OO = !0
              }
              this.sssIrradianceTexture && this.sssDepthTexture && (XO.USE_IRRADIANCE_TEXTURE_FOR_SCATTERING = !0, OO && (XO.USE_IRRADIANCE_TEXTURE_FOR_SCATTERING_GBUFFER = !0))
            }
            XO.FUZZ = this.fuzzWeight > 0 && WO.e.ReflectionTextureEnabled, XO.GEOMETRY_THIN_WALLED = 0 != this.geometryThinWalled, XO.FUZZ ? (KO.isVerticesDataPresent(RO.j.TangentKind) || (XO._needUVs = !0, XO.MAINUV1 = !0), this._environmentFuzzBRDFTexture = PO(this.JKO()), XO.FUZZ_IBL_SAMPLES = this.fuzzSampleNumber) : (this._environmentFuzzBRDFTexture = null, XO.FUZZENVIRONMENTBRDF = !1, XO.FUZZ_IBL_SAMPLES = 0), XO._areMiscDirty && ((0, kK.fb)(KO, CO, this._useLogarithmicDepth, this.pointsCloud, this.fogEnabled, this.needAlphaTestingForMesh(KO), XO, this._applyDecalMapAfterDetailMap, this._useVertexPulling, pO, this._isVertexOutputInvariant), XO.UNLIT = this._unlit || (this.pointsCloud || this.wireframe) && !KO.isVerticesDataPresent(RO.j.NormalKind), XO.DEBUGMODE = this._debugMode), (0, kK.V)(CO, hO, this, XO, !!bK, lO, vK), this._eventInfo.defines = XO, this._eventInfo.mesh = KO, this._callbackPluginEventPrepareDefinesBeforeAttributes(this._eventInfo), (0, kK.S)(KO, XO, !0, !0, !0, this._transparencyMode !== eO.b.MATERIAL_OPAQUE), this._callbackPluginEventPrepareDefines(this._eventInfo)
          }
        }, KO = new WeakMap, XO = new WeakMap, bK = new WeakMap, lO = new WeakMap, vK = new WeakMap, CO = new WeakMap, hO = new WeakMap, DO = new WeakMap, MO = new WeakMap, aK = new WeakMap, oO = new WeakMap, FO = new WeakMap, VO = new WeakMap, LO = new WeakMap, QO = new WeakMap, zK = new WeakMap, AO = new WeakMap, fO = new WeakMap, dO = new WeakMap, TO = new WeakMap, NO = new WeakMap, IO = new WeakMap, YO = new WeakMap, wO = new WeakMap, iK = new WeakMap, rK = new WeakMap, sO = new WeakMap, SO = new WeakMap, JO = new WeakMap, cK = new WeakMap, BO = new WeakMap, qK = new WeakMap, nO = new WeakMap, UO = new WeakMap, OK = new WeakMap, KK = new WeakMap, pK = new WeakMap, XK = new WeakMap, bp = new WeakMap, eK = new WeakMap, lK = new WeakMap, vp = new WeakMap, CK = new WeakMap, hK = new WeakMap, FK = new WeakMap, VK = new WeakMap, LK = new WeakMap, QK = new WeakMap, zp = new WeakMap, AK = new WeakMap, fK = new WeakMap, dK = new WeakMap, TK = new WeakMap, yp = new WeakMap, gp = new WeakMap, uK = new WeakMap, EK = new WeakMap, jp = new WeakMap, YK = new WeakMap, wK = new WeakMap, ip = new WeakMap, rp = new WeakMap, PK = new WeakMap, mp = new WeakMap, sK = new WeakMap, HK = new WeakMap, RK = new WeakMap, JK = new WeakMap, BK = new WeakMap, xp = new WeakMap, nK = new WeakMap, kp = new WeakMap, UK = new WeakMap, Op = new WeakMap, Kp = new WeakMap, pp = new WeakMap, Xp = new WeakMap, bX = new WeakMap, ep = new WeakMap, lp = new WeakMap, vX = new WeakMap, Cp = new WeakMap, hp = new WeakMap, Dp = new WeakMap, Mp = new WeakMap, aX = new WeakMap, op = new WeakMap, Fp = new WeakMap, Vp = new WeakMap, Lp = new WeakMap, Qp = new WeakMap, zX = new WeakMap, Ap = new WeakMap, fp = new WeakMap, dp = new WeakMap, Tp = new WeakMap, Np = new WeakMap, Ip = new WeakMap, yX = new WeakMap, gX = new WeakMap, upO = new WeakMap, Ep = new WeakMap, (() => {
          const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(Yb[Symbol.metadata] ?? null) : void 0;
          jX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Yp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], wp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], iX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], rX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Pp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], mX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], sp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Hp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Rp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Sp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Jp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], cX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Bp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Zp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Gp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], qX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], xX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], np = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Wp = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], tX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], kX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Up = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], OX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], KX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], pX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], XX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], bb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], eX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], lX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], vb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], CX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], hX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], DX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], MX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], ab = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], oX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], FX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], VX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], LX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], QX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], zb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], AX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], fX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], dX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], TX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], NX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], IX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], yb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], gb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], uX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], EX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], jb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], YX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], wX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], ib = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], rb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], PX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], mb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], sX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], HX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], RX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], SX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], JX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], cb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], BX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], ZX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], GX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], qb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], xb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], nX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], WX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], tb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], kb = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], UX = [(0, gK.e)("_markAllSubMeshesAsTexturesDirty")], Ob = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Kb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], pb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Xb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesAndMiscDirty")], be = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesAndMiscDirty")], eb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], lb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], ve = [(0, gK.M)()], Cb = [(0, gK.M)()], hb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Db = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Mb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], ae = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], ob = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsLightsDirty")], Fb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Vb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsLightsDirty")], Lb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Qb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], ze = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Ab = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], fb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], db = [(0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Tb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Nb = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Ib = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], ye = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], ge = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], ub = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], Eb = [(0, gK.h)("_markAllSubMeshesAsMiscDirty")], je = [(0, gK.M)()], (0, yK.f)(OO, null, jX, {
            kind: "accessor",
            name: "baseWeight",
            static: !1,
            private: !1,
            access: {
              has: OO => "baseWeight" in OO,
              get: OO => OO.baseWeight,
              set: (OO, KO) => {
                OO.baseWeight = KO
              }
            },
            metadata: KO
          }, ie, re), (0, yK.f)(OO, null, Yp, {
            kind: "accessor",
            name: "baseWeightTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "baseWeightTexture" in OO,
              get: OO => OO.baseWeightTexture,
              set: (OO, KO) => {
                OO.baseWeightTexture = KO
              }
            },
            metadata: KO
          }, Pb, me), (0, yK.f)(OO, null, wp, {
            kind: "accessor",
            name: "baseColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "baseColor" in OO,
              get: OO => OO.baseColor,
              set: (OO, KO) => {
                OO.baseColor = KO
              }
            },
            metadata: KO
          }, sb, Hb), (0, yK.f)(OO, null, iX, {
            kind: "accessor",
            name: "baseColorTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "baseColorTexture" in OO,
              get: OO => OO.baseColorTexture,
              set: (OO, KO) => {
                OO.baseColorTexture = KO
              }
            },
            metadata: KO
          }, Rb, Sb), (0, yK.f)(OO, null, rX, {
            kind: "accessor",
            name: "baseDiffuseRoughness",
            static: !1,
            private: !1,
            access: {
              has: OO => "baseDiffuseRoughness" in OO,
              get: OO => OO.baseDiffuseRoughness,
              set: (OO, KO) => {
                OO.baseDiffuseRoughness = KO
              }
            },
            metadata: KO
          }, Jb, ce), (0, yK.f)(OO, null, Pp, {
            kind: "accessor",
            name: "baseDiffuseRoughnessTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "baseDiffuseRoughnessTexture" in OO,
              get: OO => OO.baseDiffuseRoughnessTexture,
              set: (OO, KO) => {
                OO.baseDiffuseRoughnessTexture = KO
              }
            },
            metadata: KO
          }, Bb, Zb), (0, yK.f)(OO, null, mX, {
            kind: "accessor",
            name: "baseMetalness",
            static: !1,
            private: !1,
            access: {
              has: OO => "baseMetalness" in OO,
              get: OO => OO.baseMetalness,
              set: (OO, KO) => {
                OO.baseMetalness = KO
              }
            },
            metadata: KO
          }, Gb, qe), (0, yK.f)(OO, null, sp, {
            kind: "accessor",
            name: "baseMetalnessTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "baseMetalnessTexture" in OO,
              get: OO => OO.baseMetalnessTexture,
              set: (OO, KO) => {
                OO.baseMetalnessTexture = KO
              }
            },
            metadata: KO
          }, xe, nb), (0, yK.f)(OO, null, Hp, {
            kind: "accessor",
            name: "specularWeight",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularWeight" in OO,
              get: OO => OO.specularWeight,
              set: (OO, KO) => {
                OO.specularWeight = KO
              }
            },
            metadata: KO
          }, Wb, te), (0, yK.f)(OO, null, Rp, {
            kind: "accessor",
            name: "specularWeightTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularWeightTexture" in OO,
              get: OO => OO.specularWeightTexture,
              set: (OO, KO) => {
                OO.specularWeightTexture = KO
              }
            },
            metadata: KO
          }, ke, Ub), (0, yK.f)(OO, null, Sp, {
            kind: "accessor",
            name: "specularColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularColor" in OO,
              get: OO => OO.specularColor,
              set: (OO, KO) => {
                OO.specularColor = KO
              }
            },
            metadata: KO
          }, Oe, Ke), (0, yK.f)(OO, null, Jp, {
            kind: "accessor",
            name: "specularColorTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularColorTexture" in OO,
              get: OO => OO.specularColorTexture,
              set: (OO, KO) => {
                OO.specularColorTexture = KO
              }
            },
            metadata: KO
          }, pe, Xe), (0, yK.f)(OO, null, cX, {
            kind: "accessor",
            name: "specularRoughness",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularRoughness" in OO,
              get: OO => OO.specularRoughness,
              set: (OO, KO) => {
                OO.specularRoughness = KO
              }
            },
            metadata: KO
          }, bl, ee), (0, yK.f)(OO, null, Bp, {
            kind: "accessor",
            name: "specularRoughnessTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularRoughnessTexture" in OO,
              get: OO => OO.specularRoughnessTexture,
              set: (OO, KO) => {
                OO.specularRoughnessTexture = KO
              }
            },
            metadata: KO
          }, le, vl), (0, yK.f)(OO, null, Zp, {
            kind: "accessor",
            name: "specularRoughnessAnisotropy",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularRoughnessAnisotropy" in OO,
              get: OO => OO.specularRoughnessAnisotropy,
              set: (OO, KO) => {
                OO.specularRoughnessAnisotropy = KO
              }
            },
            metadata: KO
          }, Ce, he), (0, yK.f)(OO, null, Gp, {
            kind: "accessor",
            name: "specularRoughnessAnisotropyTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularRoughnessAnisotropyTexture" in OO,
              get: OO => OO.specularRoughnessAnisotropyTexture,
              set: (OO, KO) => {
                OO.specularRoughnessAnisotropyTexture = KO
              }
            },
            metadata: KO
          }, De, Me), (0, yK.f)(OO, null, qX, {
            kind: "accessor",
            name: "specularIor",
            static: !1,
            private: !1,
            access: {
              has: OO => "specularIor" in OO,
              get: OO => OO.specularIor,
              set: (OO, KO) => {
                OO.specularIor = KO
              }
            },
            metadata: KO
          }, al, oe), (0, yK.f)(OO, null, xX, {
            kind: "accessor",
            name: "transmissionWeight",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionWeight" in OO,
              get: OO => OO.transmissionWeight,
              set: (OO, KO) => {
                OO.transmissionWeight = KO
              }
            },
            metadata: KO
          }, Fe, Ve), (0, yK.f)(OO, null, np, {
            kind: "accessor",
            name: "transmissionWeightTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionWeightTexture" in OO,
              get: OO => OO.transmissionWeightTexture,
              set: (OO, KO) => {
                OO.transmissionWeightTexture = KO
              }
            },
            metadata: KO
          }, Le, Qe), (0, yK.f)(OO, null, Wp, {
            kind: "accessor",
            name: "transmissionColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionColor" in OO,
              get: OO => OO.transmissionColor,
              set: (OO, KO) => {
                OO.transmissionColor = KO
              }
            },
            metadata: KO
          }, zl, Ae), (0, yK.f)(OO, null, tX, {
            kind: "accessor",
            name: "transmissionColorTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionColorTexture" in OO,
              get: OO => OO.transmissionColorTexture,
              set: (OO, KO) => {
                OO.transmissionColorTexture = KO
              }
            },
            metadata: KO
          }, fe, de), (0, yK.f)(OO, null, kX, {
            kind: "accessor",
            name: "transmissionDepth",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionDepth" in OO,
              get: OO => OO.transmissionDepth,
              set: (OO, KO) => {
                OO.transmissionDepth = KO
              }
            },
            metadata: KO
          }, Te, Ne), (0, yK.f)(OO, null, Up, {
            kind: "accessor",
            name: "transmissionDepthTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionDepthTexture" in OO,
              get: OO => OO.transmissionDepthTexture,
              set: (OO, KO) => {
                OO.transmissionDepthTexture = KO
              }
            },
            metadata: KO
          }, Ie, yl), (0, yK.f)(OO, null, OX, {
            kind: "accessor",
            name: "transmissionScatter",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionScatter" in OO,
              get: OO => OO.transmissionScatter,
              set: (OO, KO) => {
                OO.transmissionScatter = KO
              }
            },
            metadata: KO
          }, gl, ue), (0, yK.f)(OO, null, KX, {
            kind: "accessor",
            name: "transmissionScatterTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionScatterTexture" in OO,
              get: OO => OO.transmissionScatterTexture,
              set: (OO, KO) => {
                OO.transmissionScatterTexture = KO
              }
            },
            metadata: KO
          }, Ee, jl), (0, yK.f)(OO, null, pX, {
            kind: "accessor",
            name: "transmissionScatterAnisotropy",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionScatterAnisotropy" in OO,
              get: OO => OO.transmissionScatterAnisotropy,
              set: (OO, KO) => {
                OO.transmissionScatterAnisotropy = KO
              }
            },
            metadata: KO
          }, Ye, we), (0, yK.f)(OO, null, XX, {
            kind: "accessor",
            name: "transmissionDispersionScale",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionDispersionScale" in OO,
              get: OO => OO.transmissionDispersionScale,
              set: (OO, KO) => {
                OO.transmissionDispersionScale = KO
              }
            },
            metadata: KO
          }, il, rl), (0, yK.f)(OO, null, bb, {
            kind: "accessor",
            name: "transmissionDispersionScaleTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionDispersionScaleTexture" in OO,
              get: OO => OO.transmissionDispersionScaleTexture,
              set: (OO, KO) => {
                OO.transmissionDispersionScaleTexture = KO
              }
            },
            metadata: KO
          }, Pe, ml), (0, yK.f)(OO, null, eX, {
            kind: "accessor",
            name: "transmissionDispersionAbbeNumber",
            static: !1,
            private: !1,
            access: {
              has: OO => "transmissionDispersionAbbeNumber" in OO,
              get: OO => OO.transmissionDispersionAbbeNumber,
              set: (OO, KO) => {
                OO.transmissionDispersionAbbeNumber = KO
              }
            },
            metadata: KO
          }, se, He), (0, yK.f)(OO, null, lX, {
            kind: "accessor",
            name: "subsurfaceWeight",
            static: !1,
            private: !1,
            access: {
              has: OO => "subsurfaceWeight" in OO,
              get: OO => OO.subsurfaceWeight,
              set: (OO, KO) => {
                OO.subsurfaceWeight = KO
              }
            },
            metadata: KO
          }, Re, Se), (0, yK.f)(OO, null, vb, {
            kind: "accessor",
            name: "subsurfaceWeightTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "subsurfaceWeightTexture" in OO,
              get: OO => OO.subsurfaceWeightTexture,
              set: (OO, KO) => {
                OO.subsurfaceWeightTexture = KO
              }
            },
            metadata: KO
          }, Je, cl), (0, yK.f)(OO, null, CX, {
            kind: "accessor",
            name: "subsurfaceColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "subsurfaceColor" in OO,
              get: OO => OO.subsurfaceColor,
              set: (OO, KO) => {
                OO.subsurfaceColor = KO
              }
            },
            metadata: KO
          }, Be, Ze), (0, yK.f)(OO, null, hX, {
            kind: "accessor",
            name: "subsurfaceColorTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "subsurfaceColorTexture" in OO,
              get: OO => OO.subsurfaceColorTexture,
              set: (OO, KO) => {
                OO.subsurfaceColorTexture = KO
              }
            },
            metadata: KO
          }, Ge, ql), (0, yK.f)(OO, null, DX, {
            kind: "accessor",
            name: "subsurfaceRadius",
            static: !1,
            private: !1,
            access: {
              has: OO => "subsurfaceRadius" in OO,
              get: OO => OO.subsurfaceRadius,
              set: (OO, KO) => {
                OO.subsurfaceRadius = KO
              }
            },
            metadata: KO
          }, xl, ne), (0, yK.f)(OO, null, MX, {
            kind: "accessor",
            name: "subsurfaceRadiusScale",
            static: !1,
            private: !1,
            access: {
              has: OO => "subsurfaceRadiusScale" in OO,
              get: OO => OO.subsurfaceRadiusScale,
              set: (OO, KO) => {
                OO.subsurfaceRadiusScale = KO
              }
            },
            metadata: KO
          }, We, tl), (0, yK.f)(OO, null, ab, {
            kind: "accessor",
            name: "subsurfaceRadiusScaleTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "subsurfaceRadiusScaleTexture" in OO,
              get: OO => OO.subsurfaceRadiusScaleTexture,
              set: (OO, KO) => {
                OO.subsurfaceRadiusScaleTexture = KO
              }
            },
            metadata: KO
          }, kl, Ue), (0, yK.f)(OO, null, oX, {
            kind: "accessor",
            name: "subsurfaceScatterAnisotropy",
            static: !1,
            private: !1,
            access: {
              has: OO => "subsurfaceScatterAnisotropy" in OO,
              get: OO => OO.subsurfaceScatterAnisotropy,
              set: (OO, KO) => {
                OO.subsurfaceScatterAnisotropy = KO
              }
            },
            metadata: KO
          }, Ol, Kl), (0, yK.f)(OO, null, FX, {
            kind: "accessor",
            name: "coatWeight",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatWeight" in OO,
              get: OO => OO.coatWeight,
              set: (OO, KO) => {
                OO.coatWeight = KO
              }
            },
            metadata: KO
          }, pl, Xl), (0, yK.f)(OO, null, VX, {
            kind: "accessor",
            name: "coatWeightTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatWeightTexture" in OO,
              get: OO => OO.coatWeightTexture,
              set: (OO, KO) => {
                OO.coatWeightTexture = KO
              }
            },
            metadata: KO
          }, bv, el), (0, yK.f)(OO, null, LX, {
            kind: "accessor",
            name: "coatColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatColor" in OO,
              get: OO => OO.coatColor,
              set: (OO, KO) => {
                OO.coatColor = KO
              }
            },
            metadata: KO
          }, ll, vv), (0, yK.f)(OO, null, QX, {
            kind: "accessor",
            name: "coatColorTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatColorTexture" in OO,
              get: OO => OO.coatColorTexture,
              set: (OO, KO) => {
                OO.coatColorTexture = KO
              }
            },
            metadata: KO
          }, Cl, hl), (0, yK.f)(OO, null, zb, {
            kind: "accessor",
            name: "coatRoughness",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatRoughness" in OO,
              get: OO => OO.coatRoughness,
              set: (OO, KO) => {
                OO.coatRoughness = KO
              }
            },
            metadata: KO
          }, Dl, Ml), (0, yK.f)(OO, null, AX, {
            kind: "accessor",
            name: "coatRoughnessTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatRoughnessTexture" in OO,
              get: OO => OO.coatRoughnessTexture,
              set: (OO, KO) => {
                OO.coatRoughnessTexture = KO
              }
            },
            metadata: KO
          }, av, ol), (0, yK.f)(OO, null, fX, {
            kind: "accessor",
            name: "coatRoughnessAnisotropy",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatRoughnessAnisotropy" in OO,
              get: OO => OO.coatRoughnessAnisotropy,
              set: (OO, KO) => {
                OO.coatRoughnessAnisotropy = KO
              }
            },
            metadata: KO
          }, Fl, Vl), (0, yK.f)(OO, null, dX, {
            kind: "accessor",
            name: "coatRoughnessAnisotropyTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatRoughnessAnisotropyTexture" in OO,
              get: OO => OO.coatRoughnessAnisotropyTexture,
              set: (OO, KO) => {
                OO.coatRoughnessAnisotropyTexture = KO
              }
            },
            metadata: KO
          }, Ll, Ql), (0, yK.f)(OO, null, TX, {
            kind: "accessor",
            name: "coatIor",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatIor" in OO,
              get: OO => OO.coatIor,
              set: (OO, KO) => {
                OO.coatIor = KO
              }
            },
            metadata: KO
          }, zv, Al), (0, yK.f)(OO, null, NX, {
            kind: "accessor",
            name: "coatDarkening",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatDarkening" in OO,
              get: OO => OO.coatDarkening,
              set: (OO, KO) => {
                OO.coatDarkening = KO
              }
            },
            metadata: KO
          }, fl, dl), (0, yK.f)(OO, null, IX, {
            kind: "accessor",
            name: "coatDarkeningTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "coatDarkeningTexture" in OO,
              get: OO => OO.coatDarkeningTexture,
              set: (OO, KO) => {
                OO.coatDarkeningTexture = KO
              }
            },
            metadata: KO
          }, Tl, Nl), (0, yK.f)(OO, null, yb, {
            kind: "accessor",
            name: "fuzzWeight",
            static: !1,
            private: !1,
            access: {
              has: OO => "fuzzWeight" in OO,
              get: OO => OO.fuzzWeight,
              set: (OO, KO) => {
                OO.fuzzWeight = KO
              }
            },
            metadata: KO
          }, Il, yv), (0, yK.f)(OO, null, gb, {
            kind: "accessor",
            name: "fuzzWeightTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "fuzzWeightTexture" in OO,
              get: OO => OO.fuzzWeightTexture,
              set: (OO, KO) => {
                OO.fuzzWeightTexture = KO
              }
            },
            metadata: KO
          }, gv, ul), (0, yK.f)(OO, null, uX, {
            kind: "accessor",
            name: "fuzzColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "fuzzColor" in OO,
              get: OO => OO.fuzzColor,
              set: (OO, KO) => {
                OO.fuzzColor = KO
              }
            },
            metadata: KO
          }, El, jv), (0, yK.f)(OO, null, EX, {
            kind: "accessor",
            name: "fuzzColorTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "fuzzColorTexture" in OO,
              get: OO => OO.fuzzColorTexture,
              set: (OO, KO) => {
                OO.fuzzColorTexture = KO
              }
            },
            metadata: KO
          }, Yl, wl), (0, yK.f)(OO, null, jb, {
            kind: "accessor",
            name: "fuzzRoughness",
            static: !1,
            private: !1,
            access: {
              has: OO => "fuzzRoughness" in OO,
              get: OO => OO.fuzzRoughness,
              set: (OO, KO) => {
                OO.fuzzRoughness = KO
              }
            },
            metadata: KO
          }, iv, rv), (0, yK.f)(OO, null, YX, {
            kind: "accessor",
            name: "fuzzRoughnessTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "fuzzRoughnessTexture" in OO,
              get: OO => OO.fuzzRoughnessTexture,
              set: (OO, KO) => {
                OO.fuzzRoughnessTexture = KO
              }
            },
            metadata: KO
          }, Pl, mv), (0, yK.f)(OO, null, wX, {
            kind: "accessor",
            name: "geometryThinWalled",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryThinWalled" in OO,
              get: OO => OO.geometryThinWalled,
              set: (OO, KO) => {
                OO.geometryThinWalled = KO
              }
            },
            metadata: KO
          }, sl, Hl), (0, yK.f)(OO, null, ib, {
            kind: "accessor",
            name: "geometryNormalTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryNormalTexture" in OO,
              get: OO => OO.geometryNormalTexture,
              set: (OO, KO) => {
                OO.geometryNormalTexture = KO
              }
            },
            metadata: KO
          }, Rl, Sl), (0, yK.f)(OO, null, rb, {
            kind: "accessor",
            name: "geometryTangent",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryTangent" in OO,
              get: OO => OO.geometryTangent,
              set: (OO, KO) => {
                OO.geometryTangent = KO
              }
            },
            metadata: KO
          }, Jl, cv), (0, yK.f)(OO, null, PX, {
            kind: "accessor",
            name: "geometryTangentTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryTangentTexture" in OO,
              get: OO => OO.geometryTangentTexture,
              set: (OO, KO) => {
                OO.geometryTangentTexture = KO
              }
            },
            metadata: KO
          }, Bl, Zl), (0, yK.f)(OO, null, mb, {
            kind: "accessor",
            name: "geometryCoatNormalTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryCoatNormalTexture" in OO,
              get: OO => OO.geometryCoatNormalTexture,
              set: (OO, KO) => {
                OO.geometryCoatNormalTexture = KO
              }
            },
            metadata: KO
          }, Gl, qv), (0, yK.f)(OO, null, sX, {
            kind: "accessor",
            name: "geometryCoatTangent",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryCoatTangent" in OO,
              get: OO => OO.geometryCoatTangent,
              set: (OO, KO) => {
                OO.geometryCoatTangent = KO
              }
            },
            metadata: KO
          }, xv, nl), (0, yK.f)(OO, null, HX, {
            kind: "accessor",
            name: "geometryCoatTangentTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryCoatTangentTexture" in OO,
              get: OO => OO.geometryCoatTangentTexture,
              set: (OO, KO) => {
                OO.geometryCoatTangentTexture = KO
              }
            },
            metadata: KO
          }, Wl, tv), (0, yK.f)(OO, null, RX, {
            kind: "accessor",
            name: "geometryOpacity",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryOpacity" in OO,
              get: OO => OO.geometryOpacity,
              set: (OO, KO) => {
                OO.geometryOpacity = KO
              }
            },
            metadata: KO
          }, kv, Ul), (0, yK.f)(OO, null, SX, {
            kind: "accessor",
            name: "geometryOpacityTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryOpacityTexture" in OO,
              get: OO => OO.geometryOpacityTexture,
              set: (OO, KO) => {
                OO.geometryOpacityTexture = KO
              }
            },
            metadata: KO
          }, Ov, Kv), (0, yK.f)(OO, null, JX, {
            kind: "accessor",
            name: "geometryThickness",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryThickness" in OO,
              get: OO => OO.geometryThickness,
              set: (OO, KO) => {
                OO.geometryThickness = KO
              }
            },
            metadata: KO
          }, pv, Xv), (0, yK.f)(OO, null, cb, {
            kind: "accessor",
            name: "geometryThicknessTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "geometryThicknessTexture" in OO,
              get: OO => OO.geometryThicknessTexture,
              set: (OO, KO) => {
                OO.geometryThicknessTexture = KO
              }
            },
            metadata: KO
          }, bC, ev), (0, yK.f)(OO, null, BX, {
            kind: "accessor",
            name: "emissionLuminance",
            static: !1,
            private: !1,
            access: {
              has: OO => "emissionLuminance" in OO,
              get: OO => OO.emissionLuminance,
              set: (OO, KO) => {
                OO.emissionLuminance = KO
              }
            },
            metadata: KO
          }, lv, vC), (0, yK.f)(OO, null, ZX, {
            kind: "accessor",
            name: "emissionColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "emissionColor" in OO,
              get: OO => OO.emissionColor,
              set: (OO, KO) => {
                OO.emissionColor = KO
              }
            },
            metadata: KO
          }, Cv, hv), (0, yK.f)(OO, null, GX, {
            kind: "accessor",
            name: "emissionColorTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "emissionColorTexture" in OO,
              get: OO => OO.emissionColorTexture,
              set: (OO, KO) => {
                OO.emissionColorTexture = KO
              }
            },
            metadata: KO
          }, Dv, Mv), (0, yK.f)(OO, null, qb, {
            kind: "accessor",
            name: "thinFilmWeight",
            static: !1,
            private: !1,
            access: {
              has: OO => "thinFilmWeight" in OO,
              get: OO => OO.thinFilmWeight,
              set: (OO, KO) => {
                OO.thinFilmWeight = KO
              }
            },
            metadata: KO
          }, aC, ov), (0, yK.f)(OO, null, xb, {
            kind: "accessor",
            name: "thinFilmWeightTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "thinFilmWeightTexture" in OO,
              get: OO => OO.thinFilmWeightTexture,
              set: (OO, KO) => {
                OO.thinFilmWeightTexture = KO
              }
            },
            metadata: KO
          }, Fv, Vv), (0, yK.f)(OO, null, nX, {
            kind: "accessor",
            name: "thinFilmThickness",
            static: !1,
            private: !1,
            access: {
              has: OO => "thinFilmThickness" in OO,
              get: OO => OO.thinFilmThickness,
              set: (OO, KO) => {
                OO.thinFilmThickness = KO
              }
            },
            metadata: KO
          }, Lv, Qv), (0, yK.f)(OO, null, WX, {
            kind: "accessor",
            name: "thinFilmThicknessMin",
            static: !1,
            private: !1,
            access: {
              has: OO => "thinFilmThicknessMin" in OO,
              get: OO => OO.thinFilmThicknessMin,
              set: (OO, KO) => {
                OO.thinFilmThicknessMin = KO
              }
            },
            metadata: KO
          }, zC, Av), (0, yK.f)(OO, null, tb, {
            kind: "accessor",
            name: "thinFilmThicknessTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "thinFilmThicknessTexture" in OO,
              get: OO => OO.thinFilmThicknessTexture,
              set: (OO, KO) => {
                OO.thinFilmThicknessTexture = KO
              }
            },
            metadata: KO
          }, fv, dv), (0, yK.f)(OO, null, kb, {
            kind: "accessor",
            name: "thinFilmIor",
            static: !1,
            private: !1,
            access: {
              has: OO => "thinFilmIor" in OO,
              get: OO => OO.thinFilmIor,
              set: (OO, KO) => {
                OO.thinFilmIor = KO
              }
            },
            metadata: KO
          }, Tv, Nv), (0, yK.f)(OO, null, UX, {
            kind: "accessor",
            name: "ambientOcclusionTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "ambientOcclusionTexture" in OO,
              get: OO => OO.ambientOcclusionTexture,
              set: (OO, KO) => {
                OO.ambientOcclusionTexture = KO
              }
            },
            metadata: KO
          }, Iv, yC), (0, yK.f)(OO, null, Ob, {
            kind: "accessor",
            name: "directIntensity",
            static: !1,
            private: !1,
            access: {
              has: OO => "directIntensity" in OO,
              get: OO => OO.directIntensity,
              set: (OO, KO) => {
                OO.directIntensity = KO
              }
            },
            metadata: KO
          }, gC, uv), (0, yK.f)(OO, null, Kb, {
            kind: "accessor",
            name: "environmentIntensity",
            static: !1,
            private: !1,
            access: {
              has: OO => "environmentIntensity" in OO,
              get: OO => OO.environmentIntensity,
              set: (OO, KO) => {
                OO.environmentIntensity = KO
              }
            },
            metadata: KO
          }, Ev, jC), (0, yK.f)(OO, null, pb, {
            kind: "accessor",
            name: "useSpecularWeightFromTextureAlpha",
            static: !1,
            private: !1,
            access: {
              has: OO => "useSpecularWeightFromTextureAlpha" in OO,
              get: OO => OO.useSpecularWeightFromTextureAlpha,
              set: (OO, KO) => {
                OO.useSpecularWeightFromTextureAlpha = KO
              }
            },
            metadata: KO
          }, Yv, wv), (0, yK.f)(OO, null, Xb, {
            kind: "accessor",
            name: "forceAlphaTest",
            static: !1,
            private: !1,
            access: {
              has: OO => "forceAlphaTest" in OO,
              get: OO => OO.forceAlphaTest,
              set: (OO, KO) => {
                OO.forceAlphaTest = KO
              }
            },
            metadata: KO
          }, iC, rC), (0, yK.f)(OO, null, be, {
            kind: "accessor",
            name: "alphaCutOff",
            static: !1,
            private: !1,
            access: {
              has: OO => "alphaCutOff" in OO,
              get: OO => OO.alphaCutOff,
              set: (OO, KO) => {
                OO.alphaCutOff = KO
              }
            },
            metadata: KO
          }, Pv, mC), (0, yK.f)(OO, null, eb, {
            kind: "accessor",
            name: "useAmbientOcclusionFromMetallicTextureRed",
            static: !1,
            private: !1,
            access: {
              has: OO => "useAmbientOcclusionFromMetallicTextureRed" in OO,
              get: OO => OO.useAmbientOcclusionFromMetallicTextureRed,
              set: (OO, KO) => {
                OO.useAmbientOcclusionFromMetallicTextureRed = KO
              }
            },
            metadata: KO
          }, sv, Hv), (0, yK.f)(OO, null, lb, {
            kind: "accessor",
            name: "useAmbientInGrayScale",
            static: !1,
            private: !1,
            access: {
              has: OO => "useAmbientInGrayScale" in OO,
              get: OO => OO.useAmbientInGrayScale,
              set: (OO, KO) => {
                OO.useAmbientInGrayScale = KO
              }
            },
            metadata: KO
          }, Rv, Sv), (0, yK.f)(OO, null, ve, {
            kind: "getter",
            name: "usePhysicalLightFalloff",
            static: !1,
            private: !1,
            access: {
              has: OO => "usePhysicalLightFalloff" in OO,
              get: OO => OO.usePhysicalLightFalloff
            },
            metadata: KO
          }, null, wb), (0, yK.f)(OO, null, Cb, {
            kind: "getter",
            name: "useGLTFLightFalloff",
            static: !1,
            private: !1,
            access: {
              has: OO => "useGLTFLightFalloff" in OO,
              get: OO => OO.useGLTFLightFalloff
            },
            metadata: KO
          }, null, wb), (0, yK.f)(OO, null, hb, {
            kind: "accessor",
            name: "useObjectSpaceNormalMap",
            static: !1,
            private: !1,
            access: {
              has: OO => "useObjectSpaceNormalMap" in OO,
              get: OO => OO.useObjectSpaceNormalMap,
              set: (OO, KO) => {
                OO.useObjectSpaceNormalMap = KO
              }
            },
            metadata: KO
          }, Jv, cC), (0, yK.f)(OO, null, Db, {
            kind: "accessor",
            name: "useParallax",
            static: !1,
            private: !1,
            access: {
              has: OO => "useParallax" in OO,
              get: OO => OO.useParallax,
              set: (OO, KO) => {
                OO.useParallax = KO
              }
            },
            metadata: KO
          }, Bv, Zv), (0, yK.f)(OO, null, Mb, {
            kind: "accessor",
            name: "useParallaxOcclusion",
            static: !1,
            private: !1,
            access: {
              has: OO => "useParallaxOcclusion" in OO,
              get: OO => OO.useParallaxOcclusion,
              set: (OO, KO) => {
                OO.useParallaxOcclusion = KO
              }
            },
            metadata: KO
          }, Gv, qC), (0, yK.f)(OO, null, ae, {
            kind: "accessor",
            name: "parallaxScaleBias",
            static: !1,
            private: !1,
            access: {
              has: OO => "parallaxScaleBias" in OO,
              get: OO => OO.parallaxScaleBias,
              set: (OO, KO) => {
                OO.parallaxScaleBias = KO
              }
            },
            metadata: KO
          }, xC, nv), (0, yK.f)(OO, null, ob, {
            kind: "accessor",
            name: "disableLighting",
            static: !1,
            private: !1,
            access: {
              has: OO => "disableLighting" in OO,
              get: OO => OO.disableLighting,
              set: (OO, KO) => {
                OO.disableLighting = KO
              }
            },
            metadata: KO
          }, Wv, tC), (0, yK.f)(OO, null, Fb, {
            kind: "accessor",
            name: "forceIrradianceInFragment",
            static: !1,
            private: !1,
            access: {
              has: OO => "forceIrradianceInFragment" in OO,
              get: OO => OO.forceIrradianceInFragment,
              set: (OO, KO) => {
                OO.forceIrradianceInFragment = KO
              }
            },
            metadata: KO
          }, kC, Uv), (0, yK.f)(OO, null, Vb, {
            kind: "accessor",
            name: "maxSimultaneousLights",
            static: !1,
            private: !1,
            access: {
              has: OO => "maxSimultaneousLights" in OO,
              get: OO => OO.maxSimultaneousLights,
              set: (OO, KO) => {
                OO.maxSimultaneousLights = KO
              }
            },
            metadata: KO
          }, OC, KC), (0, yK.f)(OO, null, Lb, {
            kind: "accessor",
            name: "invertNormalMapX",
            static: !1,
            private: !1,
            access: {
              has: OO => "invertNormalMapX" in OO,
              get: OO => OO.invertNormalMapX,
              set: (OO, KO) => {
                OO.invertNormalMapX = KO
              }
            },
            metadata: KO
          }, pC, XC), (0, yK.f)(OO, null, Qb, {
            kind: "accessor",
            name: "invertNormalMapY",
            static: !1,
            private: !1,
            access: {
              has: OO => "invertNormalMapY" in OO,
              get: OO => OO.invertNormalMapY,
              set: (OO, KO) => {
                OO.invertNormalMapY = KO
              }
            },
            metadata: KO
          }, bh, eC), (0, yK.f)(OO, null, ze, {
            kind: "accessor",
            name: "twoSidedLighting",
            static: !1,
            private: !1,
            access: {
              has: OO => "twoSidedLighting" in OO,
              get: OO => OO.twoSidedLighting,
              set: (OO, KO) => {
                OO.twoSidedLighting = KO
              }
            },
            metadata: KO
          }, lC, vh), (0, yK.f)(OO, null, Ab, {
            kind: "accessor",
            name: "useAlphaFresnel",
            static: !1,
            private: !1,
            access: {
              has: OO => "useAlphaFresnel" in OO,
              get: OO => OO.useAlphaFresnel,
              set: (OO, KO) => {
                OO.useAlphaFresnel = KO
              }
            },
            metadata: KO
          }, CC, hC), (0, yK.f)(OO, null, fb, {
            kind: "accessor",
            name: "useLinearAlphaFresnel",
            static: !1,
            private: !1,
            access: {
              has: OO => "useLinearAlphaFresnel" in OO,
              get: OO => OO.useLinearAlphaFresnel,
              set: (OO, KO) => {
                OO.useLinearAlphaFresnel = KO
              }
            },
            metadata: KO
          }, DC, MC), (0, yK.f)(OO, null, db, {
            kind: "accessor",
            name: "environmentBRDFTexture",
            static: !1,
            private: !1,
            access: {
              has: OO => "environmentBRDFTexture" in OO,
              get: OO => OO.environmentBRDFTexture,
              set: (OO, KO) => {
                OO.environmentBRDFTexture = KO
              }
            },
            metadata: KO
          }, ah, oC), (0, yK.f)(OO, null, Tb, {
            kind: "accessor",
            name: "forceNormalForward",
            static: !1,
            private: !1,
            access: {
              has: OO => "forceNormalForward" in OO,
              get: OO => OO.forceNormalForward,
              set: (OO, KO) => {
                OO.forceNormalForward = KO
              }
            },
            metadata: KO
          }, FC, VC), (0, yK.f)(OO, null, Nb, {
            kind: "accessor",
            name: "enableSpecularAntiAliasing",
            static: !1,
            private: !1,
            access: {
              has: OO => "enableSpecularAntiAliasing" in OO,
              get: OO => OO.enableSpecularAntiAliasing,
              set: (OO, KO) => {
                OO.enableSpecularAntiAliasing = KO
              }
            },
            metadata: KO
          }, LC, QC), (0, yK.f)(OO, null, Ib, {
            kind: "accessor",
            name: "useHorizonOcclusion",
            static: !1,
            private: !1,
            access: {
              has: OO => "useHorizonOcclusion" in OO,
              get: OO => OO.useHorizonOcclusion,
              set: (OO, KO) => {
                OO.useHorizonOcclusion = KO
              }
            },
            metadata: KO
          }, zh, AC), (0, yK.f)(OO, null, ye, {
            kind: "accessor",
            name: "useRadianceOcclusion",
            static: !1,
            private: !1,
            access: {
              has: OO => "useRadianceOcclusion" in OO,
              get: OO => OO.useRadianceOcclusion,
              set: (OO, KO) => {
                OO.useRadianceOcclusion = KO
              }
            },
            metadata: KO
          }, fC, dC), (0, yK.f)(OO, null, ge, {
            kind: "accessor",
            name: "unlit",
            static: !1,
            private: !1,
            access: {
              has: OO => "unlit" in OO,
              get: OO => OO.unlit,
              set: (OO, KO) => {
                OO.unlit = KO
              }
            },
            metadata: KO
          }, TC, NC), (0, yK.f)(OO, null, ub, {
            kind: "accessor",
            name: "applyDecalMapAfterDetailMap",
            static: !1,
            private: !1,
            access: {
              has: OO => "applyDecalMapAfterDetailMap" in OO,
              get: OO => OO.applyDecalMapAfterDetailMap,
              set: (OO, KO) => {
                OO.applyDecalMapAfterDetailMap = KO
              }
            },
            metadata: KO
          }, IC, yh), (0, yK.f)(OO, null, Eb, {
            kind: "accessor",
            name: "debugMode",
            static: !1,
            private: !1,
            access: {
              has: OO => "debugMode" in OO,
              get: OO => OO.debugMode,
              set: (OO, KO) => {
                OO.debugMode = KO
              }
            },
            metadata: KO
          }, gh, uC), (0, yK.f)(OO, null, je, {
            kind: "getter",
            name: "transparencyMode",
            static: !1,
            private: !1,
            access: {
              has: OO => "transparencyMode" in OO,
              get: OO => OO.transparencyMode
            },
            metadata: KO
          }, null, wb), KO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: KO
          })
        })(), OO.SSS_QUALITY_LOW = 0, OO.SSS_QUALITY_MEDIUM = 1, OO.SSS_QUALITY_HIGH = 2, OO._noiseTextures = {}, OO.ForceGLSL = !1, OO._ShaderLoader = new ap.e((() => [Promise.all([pO.e(297), pO.e(361)]).then((() => pO(59645))), Promise.all([pO.e(302), pO.e(298), pO.e(360), pO.e(365)]).then((() => pO(59653)))]), (() => [Promise.all([pO.e(316), pO.e(318), pO.e(364)]).then((() => pO(59686))), Promise.all([pO.e(316), pO.e(319), pO.e(363), pO.e(366)]).then((() => pO(59696)))])), OO
      })(),
      UK = !1;
    UK || (UK = !0, (0, xK.f)(), (0, JK.h)("BABYLON.OpenPBRMaterial", kp));
    var Op = pO(35660);
    class Kp {
      constructor(OO) {
        this.name = rp.d.NAME_PROCEDURALTEXTURE, this.Ce = OO
      }
      register() {
        this.Ce._beforeClearStage.registerStep(rp.d.STEP_BEFORECLEAR_PROCEDURALTEXTURE, this, this._beforeClear)
      }
      rebuild() {}
      dispose() {}
      _beforeClear() {
        if (this.Ce.proceduralTexturesEnabled) {
          IK.k.StartPerformanceCounter("Procedural textures", this.Ce.proceduralTextures.length > 0);
          for (let OO = 0; OO < this.Ce.proceduralTextures.length; OO++) {
            const KO = this.Ce.proceduralTextures[OO];
            KO._shouldRender() && KO.render()
          }
          IK.k.EndPerformanceCounter("Procedural textures", this.Ce.proceduralTextures.length > 0)
        }
      }
    }
    var pp = pO(38416);
    let Xp = (() => {
      var OO;
      let KO, XO, bK, lO, vK, CO = jK.e,
        hO = [],
        DO = [],
        MO = [],
        aK = [],
        oO = [],
        FO = [],
        LO = [],
        QO = [],
        zK = [];
      return OO = class extends CO {
        get shaderLanguage() {
          return this._shaderLanguage
        }
        constructor(OO, KO, pO, XO) {
          let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
            eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
            lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
            vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0;
          super(null, XO, !eO), this.isEnabled = ((0, yK.i)(this, hO), (0, yK.i)(this, DO, !0)), this.autoClear = ((0, yK.i)(this, MO), (0, yK.i)(this, aK, !0)), this.onGenerated = (0, yK.i)(this, oO), this.onGeneratedObservable = new Op.e, this.onBeforeGenerationObservable = new Op.e, this.nodeMaterialSource = null, this.defines = "", this._generateMipMaps = (0, yK.i)(this, FO, void 0), this._drawWrapper = (0, yK.i)(this, LO), this._textures = {}, this._size = (0, yK.i)(this, QO, void 0), this._textureType = (0, yK.i)(this, zK), this._currentRefreshId = -1, this._frameId = -1, this._refreshRate = 1, this._vertexBuffers = {}, this._uniforms = new Array, this._samplers = new Array, this._floats = {}, this._ints = {}, this._floatsArrays = {}, this._colors3 = {}, this._colors4 = {}, this._vectors2 = {}, this._vectors3 = {}, this._vectors4 = {}, this._matrices = {}, this._fallbackTextureUsed = !1, this._cachedDefines = null, this._contentUpdateId = -1, this._rtWrapper = null, null === bK || bK instanceof jK.e ? (this._options = {}, this._fallbackTexture = bK) : (this._options = bK, this._fallbackTexture = bK.fallbackTexture ?? null), this._shaderLanguage = this._options.shaderLanguage ?? 0;
          let CO = (XO = this.JKO() || VO.c.LastCreatedScene)._getComponent(rp.d.NAME_PROCEDURALTEXTURE);
          CO || (CO = new Kp(XO), XO.cDO(CO)), this._options.skipSceneRegistration || XO.proceduralTextures.push(this), this._fullEngine = XO.qb(), this.name = OO, this.isRenderTarget = !0, this._size = KO, this._textureType = vK, this._generateMipMaps = eO, this._drawWrapper = new pp.c(this._fullEngine), this.setFragment(pO);
          const AO = this._createRtWrapper(lO, KO, eO, vK);
          this._texture = AO.texture;
          const fO = [];
          fO.push(1, 1), fO.push(-1, 1), fO.push(-1, -1), fO.push(1, -1), this._vertexBuffers[RO.j.PositionKind] = new RO.j(this._fullEngine, fO, RO.j.PositionKind, !1, !1, 2), this._createIndexBuffer()
        }
        _createRtWrapper(OO, KO, pO, XO) {
          return OO ? (this._rtWrapper = this._fullEngine.createRenderTargetCubeTexture(KO, {
            generateMipMaps: pO,
            generateDepthBuffer: !1,
            generateStencilBuffer: !1,
            type: XO,
            ...this._options
          }), this.setFloat("face", 0)) : (this._rtWrapper = this._fullEngine.createRenderTargetTexture(KO, {
            generateMipMaps: pO,
            generateDepthBuffer: !1,
            generateStencilBuffer: !1,
            type: XO,
            ...this._options
          }), this._rtWrapper.is3D && (this.setFloat("layer", 0), this.setInt("layerNum", 0))), this._rtWrapper
        }
        getEffect() {
          return this._drawWrapper.effect
        }
        _setEffect(OO) {
          this._drawWrapper.effect = OO
        }
        getContent() {
          return this._contentData && this._frameId === this._contentUpdateId || (this._contentData ? this._contentData.then((OO => {
            this._contentData = this.readPixels(0, 0, OO), this._contentUpdateId = this._frameId
          })) : (this._contentData = this.readPixels(0, 0), this._contentUpdateId = this._frameId)), this._contentData
        }
        _createIndexBuffer() {
          const OO = this._fullEngine,
            KO = [];
          KO.push(0), KO.push(1), KO.push(2), KO.push(0), KO.push(2), KO.push(3), this._indexBuffer = OO.createIndexBuffer(KO)
        }
        _rebuild() {
          const OO = this._vertexBuffers[RO.j.PositionKind];
          OO && OO._rebuild(), this._createIndexBuffer(), this.refreshRate === yp.e.REFRESHRATE_RENDER_ONCE && (this.refreshRate = yp.e.REFRESHRATE_RENDER_ONCE)
        }
        reset() {
          this._drawWrapper.effect?.dispose(), this._drawWrapper.effect = null, this._cachedDefines = null
        }
        _getDefines() {
          return this.defines
        }
        executeWhenReady(OO) {
          if (this.isReady()) return void OO(this);
          const KO = this.getEffect();
          KO && KO.executeWhenCompiled((() => {
            OO(this)
          }))
        }
        isReady() {
          const OO = this._fullEngine;
          if (this.nodeMaterialSource) return this._drawWrapper.effect?.isReady() ?? !1;
          if (!this._fragment) return !1;
          if (this._fallbackTextureUsed) return !0;
          if (!this._texture) return !1;
          const KO = this._getDefines();
          if (this._drawWrapper.effect && KO === this._cachedDefines && this._drawWrapper.effect.isReady()) return !0;
          const XO = {
            vertex: "procedural",
            fragmentElement: this._fragment.fragmentElement,
            fragmentSource: this._fragment.fragmentSource,
            fragment: "string" === typeof this._fragment ? this._fragment : void 0
          };
          return this._cachedDefines !== KO && (this._cachedDefines = KO, this._drawWrapper.effect = OO.createEffect(XO, [RO.j.PositionKind], this._uniforms, this._samplers, KO, void 0, void 0, (() => {
            this._rtWrapper?.dispose(), this._rtWrapper = this._texture = null, this._fallbackTexture && (this._texture = this._fallbackTexture._texture, this._texture && this._texture.incrementReferences()), this._fallbackTextureUsed = !0
          }), void 0, this._shaderLanguage, (async () => {
            this._options.extraInitializationsAsync ? 1 === this.shaderLanguage ? await Promise.all([pO.e(369).then((() => pO(59753))), this._options.extraInitializationsAsync()]) : await Promise.all([pO.e(370).then((() => pO(59758))), this._options.extraInitializationsAsync()]) : 1 === this.shaderLanguage ? await pO.e(369).then((() => pO(59753))) : await pO.e(370).then((() => pO(59758)))
          }))), this._drawWrapper.effect.isReady()
        }
        resetRefreshCounter() {
          this._currentRefreshId = -1
        }
        setFragment(OO) {
          this._fragment = OO
        }
        get refreshRate() {
          return this._refreshRate
        }
        set refreshRate(OO) {
          this._refreshRate = OO, this.resetRefreshCounter()
        }
        _shouldRender() {
          return this.isEnabled && this.isReady() && this._texture ? !this._fallbackTextureUsed && (-1 === this._currentRefreshId || this.refreshRate === this._currentRefreshId ? (this._currentRefreshId = 1, this._frameId++, !0) : (this._currentRefreshId++, !1)) : (this._texture && (this._texture.isReady = !1), !1)
        }
        getRenderSize() {
          return this._size
        }
        resize(OO, KO) {
          if (this._fallbackTextureUsed || !this._rtWrapper || !this._texture) return;
          const pO = this._texture.isCube;
          this._rtWrapper.dispose();
          const XO = this._createRtWrapper(pO, OO, KO, this._textureType);
          this._texture = XO.texture, this._size = OO, this._generateMipMaps = KO
        }
        _checkUniform(OO) {
          -1 === this._uniforms.indexOf(OO) && this._uniforms.push(OO)
        }
        setTexture(OO, KO) {
          return -1 === this._samplers.indexOf(OO) && this._samplers.push(OO), this._textures[OO] = KO, this
        }
        setFloat(OO, KO) {
          return this._checkUniform(OO), this._floats[OO] = KO, this
        }
        setInt(OO, KO) {
          return this._checkUniform(OO), this._ints[OO] = KO, this
        }
        setFloats(OO, KO) {
          return this._checkUniform(OO), this._floatsArrays[OO] = KO, this
        }
        setColor3(OO, KO) {
          return this._checkUniform(OO), this._colors3[OO] = KO, this
        }
        setColor4(OO, KO) {
          return this._checkUniform(OO), this._colors4[OO] = KO, this
        }
        setVector2(OO, KO) {
          return this._checkUniform(OO), this._vectors2[OO] = KO, this
        }
        setVector3(OO, KO) {
          return this._checkUniform(OO), this._vectors3[OO] = KO, this
        }
        setVector4(OO, KO) {
          return this._checkUniform(OO), this._vectors4[OO] = KO, this
        }
        setMatrix(OO, KO) {
          return this._checkUniform(OO), this._matrices[OO] = KO, this
        }
        render(OO) {
          const KO = this.JKO();
          if (!KO) return;
          const pO = this._fullEngine;
          if (pO.enableEffect(this._drawWrapper), this.onBeforeGenerationObservable.notifyObservers(this), pO.setState(!1), !this.nodeMaterialSource) {
            for (const OO in this._textures) this._drawWrapper.effect.setTexture(OO, this._textures[OO]);
            for (const OO in this._ints) this._drawWrapper.effect.setInt(OO, this._ints[OO]);
            for (const OO in this._floats) this._drawWrapper.effect.setFloat(OO, this._floats[OO]);
            for (const OO in this._floatsArrays) this._drawWrapper.effect.setArray(OO, this._floatsArrays[OO]);
            for (const OO in this._colors3) this._drawWrapper.effect.setColor3(OO, this._colors3[OO]);
            for (const OO in this._colors4) {
              const KO = this._colors4[OO];
              this._drawWrapper.effect.setFloat4(OO, KO.r, KO.g, KO.b, KO.a)
            }
            for (const OO in this._vectors2) this._drawWrapper.effect.setVector2(OO, this._vectors2[OO]);
            for (const OO in this._vectors3) this._drawWrapper.effect.setVector3(OO, this._vectors3[OO]);
            for (const OO in this._vectors4) this._drawWrapper.effect.setVector4(OO, this._vectors4[OO]);
            for (const OO in this._matrices) this._drawWrapper.effect.setMatrix(OO, this._matrices[OO])
          }
          if (!this._texture || !this._rtWrapper) return;
          pO._enableGPUDebugMarkers && pO._debugPushGroup?.(`procedural texture generation for ${this.name}`);
          const XO = pO.currentViewport;
          if (this.isCube)
            for (let bK = 0; bK < 6; bK++) pO.bindFramebuffer(this._rtWrapper, bK, void 0, void 0, !0), pO.bindBuffers(this._vertexBuffers, this._indexBuffer, this._drawWrapper.effect), this._drawWrapper.effect.setFloat("face", bK), this.autoClear && pO.clear(KO.clearColor, !0, !1, !1), pO.drawElementsType(eO.b.TriangleFillMode, 0, 6), pO.unBindFramebuffer(this._rtWrapper, !0);
          else {
            let OO = 1;
            this._rtWrapper.is3D ? OO = this._rtWrapper.depth : this._rtWrapper.is2DArray && (OO = this._rtWrapper.layers);
            for (let XO = 0; XO < OO; XO++) {
              if (pO.bindFramebuffer(this._rtWrapper, 0, void 0, void 0, !0, 0, XO), pO.bindBuffers(this._vertexBuffers, this._indexBuffer, this._drawWrapper.effect), this._rtWrapper.is3D || this._rtWrapper.is2DArray) {
                this._drawWrapper.effect?.setFloat("layer", 1 !== OO ? XO / (OO - 1) : 0), this._drawWrapper.effect?.setInt("layerNum", XO);
                for (const OO in this._textures) this._drawWrapper.effect.setTexture(OO, this._textures[OO])
              }
              this.autoClear && pO.clear(KO.clearColor, !0, !1, !1), pO.drawElementsType(eO.b.TriangleFillMode, 0, 6), pO.unBindFramebuffer(this._rtWrapper, !this._generateMipMaps)
            }
          }
          XO && pO.setViewport(XO), this.isCube && pO.generateMipMapsForCubemap(this._texture, !0), pO._enableGPUDebugMarkers && pO._debugPopGroup?.(), this.onGenerated && this.onGenerated(), this.onGeneratedObservable.notifyObservers(this)
        }
        clone() {
          const KO = this.getSize(),
            pO = new OO(this.name, KO.width, this._fragment, this.JKO(), this._fallbackTexture, this._generateMipMaps);
          return pO.hasAlpha = this.hasAlpha, pO.level = this.level, pO.coordinatesMode = this.coordinatesMode, pO
        }
        dispose() {
          const OO = this.JKO();
          if (!OO) return;
          const KO = OO.proceduralTextures.indexOf(this);
          KO >= 0 && OO.proceduralTextures.splice(KO, 1);
          const pO = this._vertexBuffers[RO.j.PositionKind];
          pO && (pO.dispose(), this._vertexBuffers[RO.j.PositionKind] = null), this._indexBuffer && this._fullEngine._releaseBuffer(this._indexBuffer) && (this._indexBuffer = null), this.onGeneratedObservable.clear(), this.onBeforeGenerationObservable.clear(), super.dispose()
        }
      }, (() => {
        const pO = "function" === typeof Symbol && Symbol.metadata ? Object.create(CO[Symbol.metadata] ?? null) : void 0;
        KO = [(0, gK.M)()], XO = [(0, gK.M)()], bK = [(0, gK.M)()], lO = [(0, gK.M)()], vK = [(0, gK.M)()], (0, yK.f)(OO, null, vK, {
          kind: "getter",
          name: "refreshRate",
          static: !1,
          private: !1,
          access: {
            has: OO => "refreshRate" in OO,
            get: OO => OO.refreshRate
          },
          metadata: pO
        }, null, hO), (0, yK.f)(null, null, KO, {
          kind: "field",
          name: "isEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "isEnabled" in OO,
            get: OO => OO.isEnabled,
            set: (OO, KO) => {
              OO.isEnabled = KO
            }
          },
          metadata: pO
        }, DO, MO), (0, yK.f)(null, null, XO, {
          kind: "field",
          name: "autoClear",
          static: !1,
          private: !1,
          access: {
            has: OO => "autoClear" in OO,
            get: OO => OO.autoClear,
            set: (OO, KO) => {
              OO.autoClear = KO
            }
          },
          metadata: pO
        }, aK, oO), (0, yK.f)(null, null, bK, {
          kind: "field",
          name: "_generateMipMaps",
          static: !1,
          private: !1,
          access: {
            has: OO => "_generateMipMaps" in OO,
            get: OO => OO._generateMipMaps,
            set: (OO, KO) => {
              OO._generateMipMaps = KO
            }
          },
          metadata: pO
        }, FO, LO), (0, yK.f)(null, null, lO, {
          kind: "field",
          name: "_size",
          static: !1,
          private: !1,
          access: {
            has: OO => "_size" in OO,
            get: OO => OO._size,
            set: (OO, KO) => {
              OO._size = KO
            }
          },
          metadata: pO
        }, QO, zK), pO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: pO
        })
      })(), OO
    })();

    function bX(OO) {
      return "texture" in OO
    }

    function ep(OO) {
      return "value" in OO
    }
    async function lp(OO, KO, XO) {
      const bK = [KO.red, KO.green, KO.blue, KO.alpha],
        eO = [],
        lO = [];
      for (let pO = 0; pO < 4; pO++) {
        const OO = bK[pO];
        if (OO)
          if (bX(OO)) {
            if (OO.sourceChannel < 0 || OO.sourceChannel > 3) throw new Error("Source channel must be between 0 and 3 (R, G, B, A)");
            let KO = eO.indexOf(OO.texture); - 1 === KO && (KO = eO.length, eO.push(OO.texture)), lO[pO] = KO
          } else {
            if (!ep(OO)) throw new Error("Invalid channel input configuration");
            if (OO.value < 0 || OO.value > 1) throw new Error("Constant value must be between 0.0 and 1.0");
            lO[pO] = -1
          }
        else lO[pO] = -1
      }
      let vK = KO.outputSize;
      if (!vK && eO.length > 0) {
        let OO = 0;
        for (const KO of eO) {
          const pO = KO.getSize(),
            XO = Math.max(pO.width, pO.height);
          XO > OO && (OO = XO, vK = pO.width === pO.height ? OO : pO)
        }
      }
      vK = vK || 512;
      const CO = [],
        hO = new Set;
      for (let pO = 0; pO < 4; pO++) {
        const OO = bK[pO],
          KO = ["RED", "GREEN", "BLUE", "ALPHA"][pO];
        if (OO && bX(OO)) {
          CO.push(`${KO}_FROM_TEXTURE`);
          const OO = lO[pO];
          hO.add(OO)
        }
      }
      hO.forEach((OO => {
        CO.push(`USE_TEXTURE${OO}`)
      }));
      const DO = {
          type: 2,
          format: 5,
          samplingMode: 1,
          generateDepthBuffer: !1,
          generateMipMaps: !1,
          shaderLanguage: XO.qb().isWebGPU ? 1 : 0,
          extraInitializationsAsync: async () => {
            XO.qb().isWebGPU ? await Promise.all([pO.e(367).then((() => pO(59737)))]) : await Promise.all([pO.e(368).then((() => pO(59746)))])
          },
          skipSceneRegistration: !0
        },
        MO = new Xp(OO, vK, "textureMerger", XO, DO);
      MO.refreshRate = -1, MO.defines = CO.length > 0 ? "#define " + CO.join("\n#define ") + "\n" : "";
      for (let pO = 0; pO < eO.length; pO++) aK = eO[pO], (oO = MO).uOffset = aK.uOffset, oO.vOffset = aK.vOffset, oO.uScale = aK.uScale, oO.vScale = aK.vScale, oO.uAng = aK.uAng, oO.vAng = aK.vAng, oO.wAng = aK.wAng, oO.uRotationCenter = aK.uRotationCenter, oO.vRotationCenter = aK.vRotationCenter, MO.setTexture(`inputTexture${pO}`, eO[pO]);
      var aK, oO;
      for (let pO = 0; pO < 4; pO++) {
        const OO = bK[pO],
          KO = ["red", "green", "blue", "alpha"][pO];
        if (OO && bX(OO)) {
          const XO = lO[pO];
          MO.setInt(`${KO}TextureIndex`, XO), MO.setInt(`${KO}SourceChannel`, OO.sourceChannel)
        } else {
          let XO;
          XO = OO && ep(OO) ? OO.value : 3 === pO ? 1 : 0, MO.setFloat(`${KO}ConstantValue`, XO)
        }
      }
      return await new Promise(((OO, KO) => {
        MO.executeWhenReady((() => {
          try {
            MO.render(), OO(MO)
          } catch (pO) {
            KO(pO instanceof Error ? pO : new Error(String(pO)))
          }
        }))
      }))
    }

    function vX(OO, KO) {
      return {
        texture: OO,
        sourceChannel: KO
      }
    }

    function Cp(OO) {
      return {
        value: OO
      }
    }

    function hp(OO, KO, pO, XO) {
      return {
        red: OO,
        green: KO,
        blue: pO,
        alpha: XO
      }
    }
    var Dp = pO(37887),
      Mp = pO(37987),
      aX = pO(35644),
      op = pO(38041),
      Fp = pO(37978);
    class Vp {
      constructor() {
        this.renderWidth = 512, this.renderHeight = 256, this.textureSize = 512, this.deterministicLockstep = !1, this.lockstepMaxSteps = 4
      }
    }
    class Lp extends Dp.d {
      isDeterministicLockStep() {
        return this._options.deterministicLockstep
      }
      getLockstepMaxSteps() {
        return this._options.lockstepMaxSteps
      }
      getHardwareScalingLevel() {
        return 1
      }
      get supportsUniformBuffers() {
        return !!this._options?.enableMultiview || this.ye > 1 && !this.disableUniformBuffers
      }
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new Vp;
        super(null), void 0 === OO.deterministicLockstep && (OO.deterministicLockstep = !1), void 0 !== OO.timeStep && (this._timeStep = OO.timeStep), void 0 === OO.lockstepMaxSteps && (OO.lockstepMaxSteps = 4), this._options = OO, aX.b.SetMatrixPrecision(!!OO.useHighPrecisionMatrix), this._caps = {
          maxTexturesImageUnits: 16,
          maxVertexTextureImageUnits: 16,
          maxCombinedTexturesImageUnits: 32,
          maxTextureSize: 512,
          maxCubemapTextureSize: 512,
          maxDrawBuffers: 0,
          maxRenderTextureSize: 512,
          maxVertexAttribs: 16,
          maxVaryingVectors: 16,
          maxFragmentUniformVectors: 16,
          maxVertexUniformVectors: 16,
          shaderFloatPrecision: 10,
          standardDerivatives: !1,
          astc: null,
          pvrtc: null,
          etc1: null,
          etc2: null,
          bptc: null,
          maxAnisotropy: 0,
          uintIndices: !1,
          fragmentDepthSupported: !1,
          highPrecisionShaderSupported: !0,
          colorBufferFloat: !1,
          blendFloat: !1,
          supportFloatTexturesResolve: !1,
          rg11b10ufColorRenderable: !1,
          textureFloat: !1,
          textureFloatLinearFiltering: !1,
          textureFloatRender: !1,
          textureHalfFloat: !1,
          textureHalfFloatLinearFiltering: !1,
          textureHalfFloatRender: !1,
          textureLOD: !1,
          texelFetch: !1,
          drawBuffersExtension: !1,
          depthTextureExtension: !1,
          vertexArrayObject: !1,
          instancedArrays: !1,
          supportOcclusionQuery: !1,
          canUseTimestampForTimerQuery: !1,
          maxMSAASamples: 1,
          blendMinMax: !1,
          canUseGLInstanceID: !1,
          canUseGLVertexID: !1,
          supportComputeShaders: !1,
          supportSRGBBuffers: !1,
          supportTransformFeedbacks: !1,
          textureMaxLevel: !1,
          texture2DArrayMaxLayerCount: 128,
          disableMorphTargetTexture: !1,
          textureNorm16: !1,
          blendParametersPerTarget: !1,
          dualSourceBlending: !1,
          supportReadWriteStorageTextures: !1
        }, OO.enableMultiview && (this._caps.multiview = {
          framebufferTextureMultiviewOVR: () => {}
        }), this._features = {
          forceBitmapOverHTMLImageElement: !1,
          supportRenderAndCopyToLodForFloatTextures: !1,
          supportDepthStencilTexture: !1,
          supportShadowSamplers: !1,
          uniformBufferHardCheckMatrix: !1,
          allowTexturePrefiltering: !1,
          trackUbosInFrame: !1,
          checkUbosContentBeforeUpload: !1,
          supportCSM: !1,
          basisNeedsPOT: !1,
          support3DTextures: !1,
          needTypeSuffixInShaderConstants: !1,
          supportMSAA: !1,
          supportSSAO2: !1,
          supportIBLShadows: !1,
          supportExtendedTextureFormats: !1,
          supportSwitchCaseInShader: !1,
          supportSyncTextureRead: !1,
          needsInvertingBitmap: !1,
          useUBOBindingCache: !1,
          needShaderCodeInlining: !1,
          needToAlwaysBindUniformBuffers: !1,
          supportRenderPasses: !0,
          supportSpriteInstancing: !1,
          forceVertexBufferStrideAndOffsetMultiple4Bytes: !1,
          _checkNonFloatVertexBuffersDontRecreatePipelineContext: !1
        }, OO.renderingCanvas && (this._renderingCanvas = OO.renderingCanvas), uO.b.Log(`Babylon.js v${Dp.d.Version} - Null engine`);
        const KO = "undefined" !== typeof self ? self : "undefined" !== typeof global ? global : window;
        "undefined" === typeof URL && (KO.URL = {
          createObjectURL: function() {},
          revokeObjectURL: function() {}
        }), "undefined" === typeof Blob && (KO.Blob = function() {})
      }
      createVertexBuffer(OO) {
        const KO = new Mp.c;
        return KO.references = 1, KO
      }
      createIndexBuffer(OO) {
        const KO = new Mp.c;
        return KO.references = 1, KO
      }
      clear(OO, KO, pO) {}
      getRenderWidth() {
        return !(arguments.length > 0 && void 0 !== arguments[0] && arguments[0]) && this._currentRenderTarget ? this._currentRenderTarget.width : this._options.renderWidth
      }
      getRenderHeight() {
        return !(arguments.length > 0 && void 0 !== arguments[0] && arguments[0]) && this._currentRenderTarget ? this._currentRenderTarget.height : this._options.renderHeight
      }
      setViewport(OO, KO, pO) {
        this._cachedViewport = OO
      }
      createUniformBuffer(OO) {
        const KO = new Mp.c;
        return KO.references = 1, KO.YO = OO instanceof Array ? OO.length * Float32Array.BYTES_PER_ELEMENT : OO.byteLength, KO
      }
      createDynamicUniformBuffer(OO) {
        return this.createUniformBuffer(OO)
      }
      updateUniformBuffer(OO, KO, pO, XO) {}
      bindUniformBufferBase(OO, KO, pO) {}
      bindUniformBlock(OO, KO, pO) {}
      createShaderProgram(OO, KO, pO, XO, bK) {
        return {
          __SPECTOR_rebuildProgram: null
        }
      }
      getUniforms(OO, KO) {
        return []
      }
      getAttributes(OO, KO) {
        return []
      }
      bindSamplers(OO) {
        this._currentEffect = null
      }
      enableEffect(OO) {
        OO = null !== OO && (0, Fp.e)(OO) ? OO.effect : OO, this._currentEffect = OO, OO && (OO.onBind && OO.onBind(OO), OO._onBindObservable && OO._onBindObservable.notifyObservers(OO))
      }
      setStateCullFaceType(OO, KO) {}
      setState(OO) {}
      setIntArray(OO, KO) {
        return !0
      }
      setIntArray2(OO, KO) {
        return !0
      }
      setIntArray3(OO, KO) {
        return !0
      }
      setIntArray4(OO, KO) {
        return !0
      }
      setFloatArray(OO, KO) {
        return !0
      }
      setFloatArray2(OO, KO) {
        return !0
      }
      setFloatArray3(OO, KO) {
        return !0
      }
      setFloatArray4(OO, KO) {
        return !0
      }
      setArray(OO, KO) {
        return !0
      }
      setArray2(OO, KO) {
        return !0
      }
      setArray3(OO, KO) {
        return !0
      }
      setArray4(OO, KO) {
        return !0
      }
      setMatrices(OO, KO) {
        return !0
      }
      setMatrix3x3(OO, KO) {
        return !0
      }
      setMatrix2x2(OO, KO) {
        return !0
      }
      setFloat(OO, KO) {
        return !0
      }
      setFloat2(OO, KO, pO) {
        return !0
      }
      setFloat3(OO, KO, pO, XO) {
        return !0
      }
      setBool(OO, KO) {
        return !0
      }
      setFloat4(OO, KO, pO, XO, bK) {
        return !0
      }
      setAlphaMode(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        this._alphaMode[pO] !== OO && (this.alphaState.setAlphaBlend(0 !== OO, 0), KO || this.setDepthWrite(0 === OO), this._alphaMode[pO] = OO)
      }
      bindBuffers(OO, KO, pO) {}
      wipeCaches(OO) {
        this.preventCacheWipeBetweenFrames || (this.resetTextureCache(), this._currentEffect = null, OO && (this._currentProgram = null, this._stencilStateComposer.reset(), this.depthCullingState.reset(), this.alphaState.reset()), this._cachedVertexBuffers = null, this._cachedIndexBuffer = null, this._cachedEffectForVertexBuffers = null)
      }
      draw(OO, KO, pO, XO) {}
      drawElementsType(OO, KO, pO, XO) {}
      drawArraysType(OO, KO, pO, XO) {}
      _createTexture() {
        return {}
      }
      _releaseTexture(OO) {}
      createTexture(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 3,
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
          lO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
          vK = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : null;
        const CO = new gp.e(this, 1),
          hO = String(OO);
        return CO.url = hO, CO.generateMipMaps = !KO, CO.samplingMode = bK, CO.invertY = pO, CO.baseWidth = this._options.textureSize, CO.baseHeight = this._options.textureSize, CO.width = this._options.textureSize, CO.height = this._options.textureSize, vK && (CO.format = vK), lO && (CO._buffer = lO), CO.isReady = !0, eO && setTimeout((() => {
          eO(CO)
        })), this._internalTexturesCache.push(CO), CO
      }
      _createHardwareRenderTargetWrapper(OO, KO, pO) {
        const XO = new op.c(OO, KO, pO, this);
        return this._renderTargetWrapperCache.push(XO), XO
      }
      createRenderTargetTexture(OO, KO) {
        const pO = this._createHardwareRenderTargetWrapper(!1, !1, OO),
          XO = {};
        void 0 !== KO && "object" === typeof KO ? (XO.generateMipMaps = KO.generateMipMaps, XO.generateDepthBuffer = void 0 === KO.generateDepthBuffer || KO.generateDepthBuffer, XO.generateStencilBuffer = XO.generateDepthBuffer && KO.generateStencilBuffer, XO.type = void 0 === KO.type ? 0 : KO.type, XO.samplingMode = void 0 === KO.samplingMode ? 3 : KO.samplingMode) : (XO.generateMipMaps = KO, XO.generateDepthBuffer = !0, XO.generateStencilBuffer = !1, XO.type = 0, XO.samplingMode = 3);
        const bK = new gp.e(this, 5);
        pO.setTexture(bK);
        const eO = OO.width || OO,
          lO = OO.height || OO;
        return pO._generateDepthBuffer = XO.generateDepthBuffer, pO._generateStencilBuffer = !!XO.generateStencilBuffer, bK.baseWidth = eO, bK.baseHeight = lO, bK.width = eO, bK.height = lO, bK.isReady = !0, bK.samples = 1, bK.generateMipMaps = !!XO.generateMipMaps, bK.samplingMode = XO.samplingMode, bK.type = XO.type, this._internalTexturesCache.push(bK), pO
      }
      createMultiviewRenderTargetTexture(OO, KO) {
        if (!this.getCaps().multiview) throw new Error("Multiview is not supported");
        const pO = this._createHardwareRenderTargetWrapper(!1, !1, {
            width: OO,
            height: KO
          }),
          XO = new gp.e(this, 5, !0);
        return XO.baseWidth = OO, XO.baseHeight = KO, XO.width = OO, XO.height = KO, XO.isMultiview = !0, XO.isReady = !0, XO.format = 5, XO.samples = 1, pO.setTextures(XO), pO
      }
      bindMultiviewFramebuffer(OO) {
        this.bindFramebuffer(OO, void 0, void 0, void 0, !0)
      }
      createRenderTargetCubeTexture(OO, KO) {
        const pO = this._createHardwareRenderTargetWrapper(!1, !0, OO),
          XO = {
            generateMipMaps: !0,
            generateDepthBuffer: !0,
            generateStencilBuffer: !1,
            type: 0,
            samplingMode: 3,
            format: 5,
            ...KO
          };
        XO.generateStencilBuffer = XO.generateDepthBuffer && XO.generateStencilBuffer, (1 !== XO.type || this._caps.textureFloatLinearFiltering) && (2 !== XO.type || this._caps.textureHalfFloatLinearFiltering) || (XO.samplingMode = 1), pO._generateDepthBuffer = XO.generateDepthBuffer, pO._generateStencilBuffer = !!XO.generateStencilBuffer;
        const bK = new gp.e(this, 5);
        return bK.baseWidth = OO, bK.baseHeight = OO, bK.width = OO, bK.height = OO, bK.isReady = !0, bK.isCube = !0, bK.samples = 1, bK.generateMipMaps = !!XO.generateMipMaps, bK.samplingMode = XO.samplingMode, bK.type = XO.type, this._internalTexturesCache.push(bK), pO
      }
      updateTextureSamplingMode(OO, KO) {
        KO.samplingMode = OO
      }
      createRawTexture(OO, KO, pO, XO, bK, eO, lO) {
        let vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
          CO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0,
          hO = arguments.length > 10 && void 0 !== arguments[10] && arguments[10];
        const DO = new gp.e(this, 3);
        return DO.baseWidth = KO, DO.baseHeight = pO, DO.width = KO, DO.height = pO, DO.format = XO, DO.generateMipMaps = bK, DO.samplingMode = lO, DO.invertY = eO, DO._compression = vK, DO.type = CO, DO._useSRGBBuffer = hO, this._doNotHandleContextLost || (DO._bufferView = OO), DO
      }
      updateRawTexture(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
          lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
        OO && (OO._bufferView = KO, OO.format = pO, OO.invertY = XO, OO._compression = bK, OO.type = eO, OO._useSRGBBuffer = lO)
      }
      bindFramebuffer(OO, KO, pO, XO, bK) {
        this._currentRenderTarget && this.unBindFramebuffer(this._currentRenderTarget), this._currentRenderTarget = OO, this._currentFramebuffer = null, this._cachedViewport && !bK && this.setViewport(this._cachedViewport, pO, XO)
      }
      unBindFramebuffer(OO) {
        let KO = arguments.length > 2 ? arguments[2] : void 0;
        this._currentRenderTarget = null, KO && KO(), this._currentFramebuffer = null
      }
      createDynamicVertexBuffer(OO) {
        const KO = new Mp.c;
        return KO.references = 1, KO.YO = 1, KO
      }
      updateDynamicTexture(OO, KO, pO) {}
      areAllEffectsReady() {
        return !0
      }
      getError() {
        return 0
      }
      _getUnpackAlignement() {
        return 1
      }
      _unpackFlipY(OO) {}
      updateDynamicIndexBuffer(OO, KO) {}
      updateDynamicVertexBuffer(OO, KO, pO, XO) {}
      _bindTextureDirectly(OO, KO) {
        return this._boundTexturesCache[this._activeChannel] !== KO && (this._boundTexturesCache[this._activeChannel] = KO, !0)
      }
      _bindTexture(OO, KO) {
        OO < 0 || this._bindTextureDirectly(0, KO)
      }
      _deleteBuffer(OO) {}
      releaseEffects() {}
      displayLoadingUI() {}
      hideLoadingUI() {}
      set loadingUIText(OO) {}
      flushFramebuffer() {}
      _uploadCompressedDataToTextureDirectly(OO, KO, pO, XO, bK) {}
      _uploadDataToTextureDirectly(OO, KO) {}
      _uploadArrayBufferViewToTexture(OO, KO) {}
      _uploadImageToTexture(OO, KO) {}
    }
    pO(38099), pO(38149), pO(38092);
    async function Qp(OO) {
      const KO = OO.getInternalTexture();
      if (!KO || 1 !== KO.source) return null;
      if (KO.invertY) {
        const KO = OO.JKO()?.qb();
        if (!(KO instanceof Lp)) return null
      }
      const pO = KO._buffer;
      let XO, eO = OO.mimeType;
      try {
        pO ? ArrayBuffer.isView(pO) ? XO = pO.buffer.slice(pO.byteOffset, pO.byteOffset + pO.byteLength) : pO instanceof ArrayBuffer ? XO = pO : pO instanceof Blob ? (XO = await pO.arrayBuffer(), eO = pO.type || eO) : "string" === typeof pO ? (XO = await bK.Tools.LoadFileAsync(pO), eO = (0, CO.e)(pO) || eO) : "undefined" !== typeof HTMLImageElement && pO instanceof HTMLImageElement && (XO = await bK.Tools.LoadFileAsync(pO.src), eO = (0, CO.e)(pO.src) || eO) : (XO = await bK.Tools.LoadFileAsync(KO.url), eO = (0, CO.e)(KO.url) || eO)
      } catch {
        return null
      }
      if (XO && !eO && KO.url) {
        const OO = KO.url.match(/^data:([^;,]+)/);
        eO = OO ? OO[1] : (0, CO.e)(KO.url)
      }
      return XO && eO ? {
        data: XO,
        mimeType: eO
      } : null
    }
    const zX = 1e-6,
      Ap = new LO.Color3(.04, .04, .04),
      fp = 1024,
      dp = LO.Color3.White(),
      Tp = LO.Color3.BlackReadOnly;

    function Np(OO) {
      switch (OO) {
        case "image/jpeg":
        case "image/png":
        case "image/webp":
        case "image/avif":
        case "image/ktx2":
          return !0;
        default:
          return !1
      }
    }

    function Ip(OO, KO, pO) {
      if (KO < Ap.r) return 0;
      const XO = Ap.r,
        bK = OO * pO / (1 - Ap.r) + KO - 2 * Ap.r,
        eO = bK * bK - 4 * XO * (Ap.r - KO);
      return AO.Clamp((-bK + Math.sqrt(eO)) / (2 * XO), 0, 1)
    }

    function yX(OO) {
      const KO = OO.diffuseColor.toLinearSpace(OO.JKO().qb().useExactSrgbConversions).scale(.5),
        pO = OO.alpha,
        XO = function(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new HO.m(0, 1),
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new HO.m(0, .1),
            XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : new HO.m(0, .1),
            bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : new HO.m(1300, .1);
          return function(OO, KO, pO, XO, bK) {
            return (1 - OO) * (1 - OO) * (1 - OO) * KO + 3 * (1 - OO) * (1 - OO) * OO * pO + 3 * (1 - OO) * OO * OO * XO + OO * OO * OO * bK
          }(Math.pow(OO / bK.x, .333333), KO.y, pO.y, XO.y, bK.y)
        }(AO.Clamp(OO.specularPower, 0, fp));
      return {
        baseColorFactor: [KO.r, KO.g, KO.b, pO],
        metallicFactor: 0,
        roughnessFactor: XO
      }
    }

    function gX(OO, KO) {
      KO.needAlphaBlending() ? OO.alphaMode = "BLEND" : KO.needAlphaTesting() && (OO.alphaMode = "MASK", OO.alphaCutoff = KO.alphaCutOff)
    }

    function upO(OO, KO, pO) {
      const XO = new Uint8Array(OO * KO * 4);
      for (let bK = 0; bK < XO.length; bK += 4) XO[bK] = XO[bK + 1] = XO[bK + 2] = XO[bK + 3] = 255;
      return TO.e.CreateRGBATexture(XO, OO, KO, pO)
    }

    function Ep(OO) {
      if (OO instanceof Uint8Array) {
        const KO = OO.length,
          pO = new Float32Array(OO.length);
        for (let XO = 0; XO < KO; ++XO) pO[XO] = OO[XO] / 255;
        return pO
      }
      if (OO instanceof Float32Array) return OO;
      throw new Error("Unsupported pixel format!")
    }
    class jX {
      constructor(OO) {
        this._exporter = OO, this._textureMap = new Map, this._internalTextureToImage = {}
      }
      getTextureInfo(OO) {
        return OO ? this._textureMap.get(OO.uniqueId) ?? null : null
      }
      async exportStandardMaterialAsync(OO, KO) {
        const pO = yX(OO),
          XO = {
            name: OO.name
          };
        if (null == OO.backFaceCulling || OO.backFaceCulling || (OO.twoSidedLighting || bK.Tools.Warn(OO.name + ": Back-face culling disabled and two-sided lighting disabled is not supported in glTF."), XO.doubleSided = !0), KO) {
          const KO = [],
            bK = OO.diffuseTexture;
          bK && KO.push(this.exportTextureAsync(bK).then((OO => {
            OO && (pO.baseColorTexture = OO)
          })));
          const eO = OO.bumpTexture;
          eO && KO.push(this.exportTextureAsync(eO).then((OO => {
            OO && (XO.normalTexture = OO, 1 !== eO.level && (XO.normalTexture.scale = eO.level))
          })));
          const lO = OO.emissiveTexture;
          lO && (XO.emissiveFactor = [1, 1, 1], KO.push(this.exportTextureAsync(lO).then((OO => {
            OO && (XO.emissiveTexture = OO)
          }))));
          const vK = OO.ambientTexture;
          vK && KO.push(this.exportTextureAsync(vK).then((OO => {
            if (OO) {
              const KO = {
                index: OO.index
              };
              XO.occlusionTexture = KO
            }
          }))), KO.length > 0 && (this._exporter._materialNeedsUVsSet.add(OO), await Promise.all(KO))
        }(OO.alpha < 1 || OO.opacityTexture) && (OO.alphaMode === NO.b.ALPHA_COMBINE ? XO.alphaMode = "BLEND" : bK.Tools.Warn(OO.name + ": glTF 2.0 does not support alpha mode: " + OO.alphaMode.toString())), OO.emissiveColor && !OO.emissiveColor.equalsWithEpsilon(Tp, zX) && (XO.emissiveFactor = OO.emissiveColor.WhO()), XO.pbrMetallicRoughness = pO, gX(XO, OO), await this._finishMaterialAsync(XO, OO);
        const eO = this._exporter._materials;
        return eO.push(XO), eO.length - 1
      }
      async _finishMaterialAsync(OO, KO) {
        const pO = await this._exporter._extensionsPostExportMaterialAdditionalTexturesAsync("exportMaterial", OO, KO),
          XO = [];
        for (const bK of pO) XO.push(this.exportTextureAsync(bK));
        await Promise.all(XO), await this._exporter._extensionsPostExportMaterialAsync("exportMaterial", OO, KO)
      }
      _resizeTexturesToSameDimensions(OO, KO, pO) {
        const XO = OO ? OO.getSize() : {
            width: 0,
            height: 0
          },
          bK = KO ? KO.getSize() : {
            width: 0,
            height: 0
          };
        let eO, lO;
        return XO.width < bK.width ? (eO = OO && OO instanceof dO.c ? fO.i.CreateResizedCopy(OO, bK.width, bK.height, !0) : upO(bK.width, bK.height, pO), lO = KO) : XO.width > bK.width ? (lO = KO && KO instanceof dO.c ? fO.i.CreateResizedCopy(KO, XO.width, XO.height, !0) : upO(XO.width, XO.height, pO), eO = OO) : (eO = OO, lO = KO), {
          texture1: eO,
          texture2: lO
        }
      }
      async _convertSpecularGlossinessTexturesToMetallicRoughnessAsync(OO, KO, pO) {
        const XO = new Array;
        if (!OO && !KO) return await Promise.reject("diffuse and specular glossiness textures are not defined!");
        const bK = OO ? OO.JKO() : KO ? KO.JKO() : null;
        if (bK) {
          const eO = this._resizeTexturesToSameDimensions(OO, KO, bK),
            lO = eO.texture1?.getSize();
          let vK, CO;
          const hO = lO.width,
            DO = lO.height,
            MO = await eO.texture1.readPixels(),
            aK = await eO.texture2.readPixels();
          if (!MO) return await Promise.reject("Failed to retrieve pixels from diffuse texture!");
          if (vK = Ep(MO), !aK) return await Promise.reject("Failed to retrieve pixels from specular glossiness texture!");
          CO = Ep(aK);
          const oO = CO.byteLength,
            FO = new Uint8Array(oO),
            VO = new Uint8Array(oO),
            QO = 4,
            zK = new LO.Color3(0, 0, 0);
          let AO = 0,
            fO = 0;
          for (let OO = 0; OO < DO; ++OO)
            for (let KO = 0; KO < hO; ++KO) {
              const XO = (hO * OO + KO) * QO,
                lO = {
                  diffuseColor: new LO.Color3(vK[XO], vK[XO + 1], vK[XO + 2]).toLinearSpace(bK.qb().useExactSrgbConversions).multiply(pO.diffuseColor),
                  specularColor: new LO.Color3(CO[XO], CO[XO + 1], CO[XO + 2]).toLinearSpace(bK.qb().useExactSrgbConversions).multiply(pO.specularColor),
                  glossiness: CO[XO + 3] * pO.glossiness
                },
                DO = this._convertSpecularGlossinessToMetallicRoughness(lO);
              zK.r = Math.max(zK.r, DO.baseColor.r), zK.g = Math.max(zK.g, DO.baseColor.g), zK.b = Math.max(zK.b, DO.baseColor.b), AO = Math.max(AO, DO.metallic), fO = Math.max(fO, DO.roughness), VO[XO] = 255 * DO.baseColor.r, VO[XO + 1] = 255 * DO.baseColor.g, VO[XO + 2] = 255 * DO.baseColor.b, VO[XO + 3] = eO.texture1.hasAlpha ? 255 * vK[XO + 3] : 255, FO[XO] = 0, FO[XO + 1] = 255 * DO.roughness, FO[XO + 2] = 255 * DO.metallic, FO[XO + 3] = 255
            }
          const dO = {
            baseColor: zK,
            metallic: AO,
            roughness: fO
          };
          let TO = !1,
            NO = !1;
          for (let OO = 0; OO < DO; ++OO)
            for (let KO = 0; KO < hO; ++KO) {
              const pO = (hO * OO + KO) * QO;
              VO[pO] /= dO.baseColor.r > zX ? dO.baseColor.r : 1, VO[pO + 1] /= dO.baseColor.g > zX ? dO.baseColor.g : 1, VO[pO + 2] /= dO.baseColor.b > zX ? dO.baseColor.b : 1;
              const XO = LO.Color3.FromInts(VO[pO], VO[pO + 1], VO[pO + 2]).toGammaSpace(bK.qb().useExactSrgbConversions);
              VO[pO] = 255 * XO.r, VO[pO + 1] = 255 * XO.g, VO[pO + 2] = 255 * XO.b, XO.equalsWithEpsilon(dp, zX) || (NO = !0), FO[pO + 1] /= dO.roughness > zX ? dO.roughness : 1, FO[pO + 2] /= dO.metallic > zX ? dO.metallic : 1;
              LO.Color3.FromInts(255, FO[pO + 1], FO[pO + 2]).equalsWithEpsilon(dp, zX) || (TO = !0)
            }
          return TO && XO.push((0, IO.EncodeImageAsync)(FO, hO, DO).then((OO => {
            dO.metallicRoughnessTextureData = OO
          }))), NO && XO.push((0, IO.EncodeImageAsync)(VO, hO, DO).then((OO => {
            dO.baseColorTextureData = OO
          }))), await Promise.all(XO).then((() => dO))
        }
        return await Promise.reject("_ConvertSpecularGlossinessTexturesToMetallicRoughness: Scene from textures is missing!")
      }
      _convertSpecularGlossinessToMetallicRoughness(OO) {
        const KO = this._getPerceivedBrightness(OO.diffuseColor),
          pO = this._getPerceivedBrightness(OO.specularColor),
          XO = 1 - this._getMaxComponent(OO.specularColor),
          bK = Ip(KO, pO, XO),
          eO = OO.diffuseColor.scale(XO / (1 - Ap.r) / Math.max(1 - bK, zX)),
          lO = OO.specularColor.subtract(Ap.scale(1 - bK)).scale(1 / Math.max(bK, zX));
        let vK = LO.Color3.Lerp(eO, lO, bK * bK);
        vK = vK.clampToRef(0, 1, vK);
        return {
          baseColor: vK,
          metallic: bK,
          roughness: 1 - OO.glossiness
        }
      }
      _getPerceivedBrightness(OO) {
        return Math.sqrt(.299 * OO.r * OO.r + .587 * OO.g * OO.g + .114 * OO.b * OO.b)
      }
      _getMaxComponent(OO) {
        return Math.max(OO.r, Math.max(OO.g, OO.b))
      }
      async _convertMetalRoughFactorsToMetallicRoughnessAsync(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        const hO = [],
          DO = {
            baseColor: OO,
            metallic: KO,
            roughness: pO
          };
        if (CO)
          if (lO instanceof kp) {
            if (lO.geometryOpacityTexture) {
              const OO = XO && XO.getInternalTexture() ? XO.getInternalTexture().uniqueId : 0,
                KO = lO.geometryOpacityTexture && lO.geometryOpacityTexture.getInternalTexture() ? lO.geometryOpacityTexture.getInternalTexture().uniqueId : 0,
                pO = Number(`${OO}${KO}`),
                bK = this._textureMap.get(pO);
              bK ? vK.baseColorTexture = bK : hO.push(lp("baseColorOpacityTexture", hp(XO ? vX(XO, 0) : Cp(1), XO ? vX(XO, 1) : Cp(1), XO ? vX(XO, 2) : Cp(1), vX(lO.geometryOpacityTexture, 0)), lO.JKO()).then((async OO => {
                const KO = await this.exportTextureAsync(OO, pO);
                KO && (vK.baseColorTexture = KO)
              })))
            } else XO && hO.push(this.exportTextureAsync(XO).then((OO => {
              OO && (vK.baseColorTexture = OO)
            })));
            if (lO._useMetallicFromMetallicTextureBlue && bK) hO.push(this.exportTextureAsync(bK).then((OO => {
              OO && (vK.metallicRoughnessTexture = OO)
            })));
            else if (eO || bK) {
              const OO = bK && bK.getInternalTexture() ? bK.getInternalTexture().uniqueId : 0,
                KO = eO && eO.getInternalTexture() ? eO.getInternalTexture().uniqueId : 0,
                pO = Number(`${OO}${KO}`),
                XO = this._textureMap.get(pO);
              XO ? vK.metallicRoughnessTexture = XO : hO.push(lp("MetalRoughTexture", hp(lO.ambientOcclusionTexture ? vX(lO.ambientOcclusionTexture, 0) : Cp(1), eO ? vX(eO, 0) : Cp(1), bK ? vX(bK, 0) : Cp(1)), lO.JKO()).then((async OO => {
                const KO = await this.exportTextureAsync(OO, pO);
                KO && (vK.metallicRoughnessTexture = KO)
              })))
            }
          } else XO && hO.push(this.exportTextureAsync(XO).then((OO => {
            OO && (vK.baseColorTexture = OO)
          }))), bK && hO.push(this.exportTextureAsync(bK).then((OO => {
            OO && (vK.metallicRoughnessTexture = OO)
          })));
        return hO.length > 0 && (this._exporter._materialNeedsUVsSet.add(lO), await Promise.all(hO)), DO
      }
      _getTextureSampler(OO) {
        const KO = {};
        if (!OO || !(OO instanceof dO.c)) return KO;
        const pO = this._getGLTFTextureWrapMode(OO.wrapU);
        10497 !== pO && (KO.wrapS = pO);
        const XO = this._getGLTFTextureWrapMode(OO.wrapV);
        switch (10497 !== XO && (KO.wrapT = XO), OO.samplingMode) {
          case dO.c.LINEAR_LINEAR:
            KO.magFilter = 9729, KO.minFilter = 9729;
            break;
          case dO.c.LINEAR_NEAREST:
            KO.magFilter = 9729, KO.minFilter = 9728;
            break;
          case dO.c.NEAREST_LINEAR:
            KO.magFilter = 9728, KO.minFilter = 9729;
            break;
          case dO.c.NEAREST_LINEAR_MIPLINEAR:
            KO.magFilter = 9728, KO.minFilter = 9987;
            break;
          case dO.c.NEAREST_NEAREST:
            KO.magFilter = 9728, KO.minFilter = 9728;
            break;
          case dO.c.NEAREST_LINEAR_MIPNEAREST:
            KO.magFilter = 9728, KO.minFilter = 9985;
            break;
          case dO.c.LINEAR_NEAREST_MIPNEAREST:
            KO.magFilter = 9729, KO.minFilter = 9984;
            break;
          case dO.c.LINEAR_NEAREST_MIPLINEAR:
            KO.magFilter = 9729, KO.minFilter = 9986;
            break;
          case dO.c.NEAREST_NEAREST_MIPLINEAR:
            KO.magFilter = 9728, KO.minFilter = 9986;
            break;
          case dO.c.LINEAR_LINEAR_MIPLINEAR:
            KO.magFilter = 9729, KO.minFilter = 9987;
            break;
          case dO.c.LINEAR_LINEAR_MIPNEAREST:
            KO.magFilter = 9729, KO.minFilter = 9985;
            break;
          case dO.c.NEAREST_NEAREST_MIPNEAREST:
            KO.magFilter = 9728, KO.minFilter = 9984
        }
        return KO
      }
      _getGLTFTextureWrapMode(OO) {
        switch (OO) {
          case dO.c.WRAP_ADDRESSMODE:
            return 10497;
          case dO.c.CLAMP_ADDRESSMODE:
            return 33071;
          case dO.c.MIRROR_ADDRESSMODE:
            return 33648;
          default:
            return bK.Tools.Error(`Unsupported Texture Wrap Mode ${OO}!`), 10497
        }
      }
      async _convertSpecGlossFactorsToMetallicRoughnessAsync(OO, KO, pO) {
        const XO = {
            diffuseColor: OO._albedoColor,
            specularColor: OO._reflectivityColor,
            glossiness: OO._microSurface
          },
          bK = OO._albedoTexture,
          eO = OO._reflectivityTexture,
          lO = OO._useMicroSurfaceFromReflectivityMapAlpha;
        if (eO && !lO) return await Promise.reject("_ConvertPBRMaterial: Glossiness values not included in the reflectivity texture are currently not supported");
        if ((bK || eO) && pO) {
          this._exporter._materialNeedsUVsSet.add(OO);
          const pO = this._exportTextureSampler(bK || eO),
            lO = await this._convertSpecularGlossinessTexturesToMetallicRoughnessAsync(bK, eO, XO),
            vK = this._exporter._textures;
          if (lO.baseColorTextureData) {
            const OO = await this._exportImageAsync(`baseColor${vK.length}`, lO.baseColorTextureData);
            KO.baseColorTexture = this._exportTextureInfo(OO, pO, bK?.coordinatesIndex)
          }
          if (lO.metallicRoughnessTextureData) {
            const OO = await this._exportImageAsync(`metallicRoughness${vK.length}`, lO.metallicRoughnessTextureData);
            KO.metallicRoughnessTexture = this._exportTextureInfo(OO, pO, eO?.coordinatesIndex)
          }
          return lO
        }
        return this._convertSpecularGlossinessToMetallicRoughness(XO)
      }
      async exportPBRMaterialAsync(OO, KO) {
        const pO = {},
          XO = {
            name: OO.name
          },
          bK = OO.isMetallicWorkflow();
        if (bK) {
          const KO = OO._albedoColor,
            XO = OO.alpha;
          KO && (pO.baseColorFactor = [KO.r, KO.g, KO.b, XO])
        }
        const eO = bK ? await this._convertMetalRoughFactorsToMetallicRoughnessAsync(OO._albedoColor, OO._metallic, OO._roughness, OO._albedoTexture, OO._metallicTexture, OO._metallicTexture, OO, pO, KO) : await this._convertSpecGlossFactorsToMetallicRoughnessAsync(OO, pO, KO);
        await this._setMetallicRoughnessPbrMaterialAsync(eO, OO, XO, pO, KO), await this._finishMaterialAsync(XO, OO);
        const lO = this._exporter._materials;
        return lO.push(XO), lO.length - 1
      }
      async _setMetallicRoughnessPbrMaterialAsync(OO, KO, pO, XO, eO) {
        if (gX(pO, KO), OO.baseColor.equalsWithEpsilon(dp, zX) && AO.WithinEpsilon(KO.alpha, 1, zX) || (XO.baseColorFactor = [OO.baseColor.r, OO.baseColor.g, OO.baseColor.b, KO.alpha]), null != OO.metallic && 1 !== OO.metallic && (XO.metallicFactor = OO.metallic), null != OO.roughness && 1 !== OO.roughness && (XO.roughnessFactor = OO.roughness), null == KO.backFaceCulling || KO.backFaceCulling || (KO._twoSidedLighting || bK.Tools.Warn(KO.name + ": Back-face culling disabled and two-sided lighting disabled is not supported in glTF."), pO.doubleSided = !0), eO) {
          const OO = [],
            bK = KO instanceof TK ? KO._bumpTexture : KO.geometryNormalTexture;
          bK && OO.push(this.exportTextureAsync(bK).then((OO => {
            OO && (pO.normalTexture = OO, 1 !== bK.level && (pO.normalTexture.scale = bK.level))
          })));
          const eO = KO instanceof TK ? KO._ambientTexture : KO.ambientOcclusionTexture;
          eO && OO.push(new Promise((async OO => {
            if (KO instanceof kp && XO.metallicRoughnessTexture) {
              const KO = this._exportTextureSampler(eO),
                pO = this._exporter._textures[XO.metallicRoughnessTexture.index].source,
                bK = this._exportTextureInfo(pO, KO, eO.coordinatesIndex);
              return this._textureMap.set(eO.uniqueId, bK), this._exporter._extensionsPostExportTextures("exporter", bK, eO), OO(bK)
            }
            return OO(await this.exportTextureAsync(eO))
          })).then((async OO => {
            if (OO) {
              const XO = {
                index: OO.index,
                texCoord: OO.texCoord,
                extensions: OO.extensions
              };
              pO.occlusionTexture = XO, XO.strength = KO instanceof TK ? KO._ambientTextureStrength : KO.ambientOcclusionTexture.level
            }
          })));
          const lO = KO instanceof TK ? KO._emissiveTexture : KO.emissionColorTexture;
          lO && OO.push(this.exportTextureAsync(lO).then((OO => {
            OO && (pO.emissiveTexture = OO)
          }))), OO.length > 0 && (this._exporter._materialNeedsUVsSet.add(KO), await Promise.all(OO))
        }
        const lO = KO instanceof TK ? KO._emissiveColor : KO.emissionColor;
        lO.equalsWithEpsilon(Tp, zX) || (pO.emissiveFactor = lO.WhO()), pO.pbrMetallicRoughness = XO
      }
      async exportOpenPBRMaterialAsync(OO, KO) {
        const pO = {},
          XO = {
            name: OO.name
          },
          bK = OO.baseColor,
          eO = OO.geometryOpacity;
        bK && (pO.baseColorFactor = [bK.r, bK.g, bK.b, eO]);
        const lO = await this._convertMetalRoughFactorsToMetallicRoughnessAsync(OO.baseColor, OO.baseMetalness, OO.specularRoughness, OO.baseColorTexture, OO.baseMetalnessTexture, OO.specularRoughnessTexture, OO, pO, KO);
        await this._setMetallicRoughnessPbrMaterialAsync(lO, OO, XO, pO, KO), await this._finishMaterialAsync(XO, OO);
        const vK = this._exporter._materials;
        return vK.push(XO), vK.length - 1
      }
      async exportTextureAsync(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = this._textureMap.get(KO ?? OO.uniqueId);
        if (pO) return pO;
        const XO = this._exportTextureSampler(OO),
          bK = await this._exportTextureImageAsync(OO);
        return pO = this._exportTextureInfo(bK, XO, OO.coordinatesIndex), this._textureMap.set(KO ?? OO.uniqueId, pO), this._exporter._extensionsPostExportTextures("exporter", pO, OO), pO
      }
      async _exportTextureImageAsync(OO) {
        const KO = OO.mimeType ?? "none",
          pO = this._internalTextureToImage,
          XO = OO.getInternalTexture().uniqueId;
        pO[XO] = pO[XO] || {};
        let eO = pO[XO][KO];
        return void 0 === eO && (eO = (async () => {
          const pO = await Qp(OO);
          if (pO && Np(pO.mimeType) && ("none" === KO || pO.mimeType === KO)) return await this._exportImageAsync(OO.name, new Blob([pO.data], {
            type: pO.mimeType
          }));
          let XO = "image/png";
          "none" !== KO && (Np(KO) ? XO = KO : (XO = "image/png", bK.Tools.Warn(`Unsupported media type: ${KO}. Exporting texture as PNG.`)));
          const eO = OO.getSize(),
            lO = await (0, fO.h)(OO),
            vK = await (0, IO.EncodeImageAsync)(lO, eO.width, eO.height, XO);
          return await this._exportImageAsync(OO.name, vK)
        })(), pO[XO][KO] = eO), await eO
      }
      async _exportImageAsync(OO, KO) {
        const pO = this._exporter._images;
        let XO;
        if (this._exporter._shouldUseGlb) {
          XO = {
            name: OO,
            mimeType: KO.type,
            bufferView: void 0
          };
          const pO = await KO.arrayBuffer(),
            bK = this._exporter._bufferManager.createBufferView(new Uint8Array(pO));
          this._exporter._bufferManager.setBufferView(XO, bK)
        } else {
          const eO = OO.replace(/\.\/|\/|\.\\|\\/g, "_"),
            lO = function(OO) {
              switch (OO) {
                case "image/jpeg":
                  return ".jpg";
                case "image/png":
                  return ".png";
                case "image/webp":
                  return ".webp";
                case "image/avif":
                  return ".avif";
                case "image/ktx2":
                  return ".ktx2"
              }
            }(KO.type);
          let vK = eO + lO;
          pO.some((OO => OO.uri === vK)) && (vK = `${eO}_${bK.Tools.RandomId()}${lO}`), XO = {
            name: OO,
            uri: vK
          }, this._exporter._imageData[vK] = KO
        }
        return pO.push(XO), pO.length - 1
      }
      _exportTextureInfo(OO, KO, pO) {
        const XO = this._exporter._textures;
        let bK = XO.findIndex((pO => pO.sampler == KO && pO.source === OO)); - 1 === bK && (bK = XO.length, XO.push({
          source: OO,
          sampler: KO
        }));
        const eO = {
          index: bK
        };
        return pO && (eO.texCoord = pO), eO
      }
      _exportTextureSampler(OO) {
        const KO = this._getTextureSampler(OO),
          pO = this._exporter._samplers,
          XO = pO.findIndex((OO => OO.minFilter === KO.minFilter && OO.magFilter === KO.magFilter && OO.wrapS === KO.wrapS && OO.wrapT === KO.wrapT));
        return -1 !== XO ? XO : (pO.push(KO), pO.length - 1)
      }
    }
    var Yp = pO(38136),
      wp = pO(38287);
    (0, wp.d)();
    var iX = pO(35639);
    const rX = XO.Matrix.Compose(new XO.WX(-1, 1, 1), XO.Quaternion.Identity(), XO.WX.Zero());

    function Pp(OO, KO) {
      if (!(OO instanceof MO.c)) return !1;
      if (KO) {
        if (!OO.getWorldMatrix().equalsWithEpsilon(XO.Matrix.IdentityReadOnly, iX.c)) return !1
      } else {
        if (!OO.getWorldMatrix().multiplyToRef(rX, XO.TmpVectors.Matrix[0]).equalsWithEpsilon(XO.Matrix.IdentityReadOnly, iX.c)) return !1
      }
      return !(OO instanceof aK.c && OO.geometry)
    }
    const mX = XO.WX.ZeroReadOnly,
      sp = XO.Quaternion.Identity(),
      Hp = XO.WX.OneReadOnly,
      Rp = new XO.WX(-1, 1, 1);

    function Sp(OO, KO) {
      const {
        byteOffset: pO,
        byteStride: XO,
        type: bK,
        normalized: eO
      } = OO, lO = OO.getSize(), vK = KO.reduce(((OO, KO) => KO.getTotalVertices() > OO ? KO.getTotalVertices() : OO), -Number.MAX_VALUE);
      return {
        byteOffset: pO,
        byteStride: XO,
        componentCount: lO,
        type: bK,
        count: vK * lO,
        normalized: eO,
        totalVertices: vK,
        kind: OO.getKind()
      }
    }

    function Jp(OO) {
      switch (OO) {
        case "MAT2":
        case "VEC4":
          return 4;
        case "MAT3":
          return 9;
        case "MAT4":
          return 16;
        case "SCALAR":
          return 1;
        case "VEC2":
          return 2;
        case "VEC3":
          return 3
      }
    }

    function cX(OO) {
      switch (OO) {
        case DO.f.PositionKind:
        case DO.f.NormalKind:
        case DO.f.TangentKind:
        case DO.f.ColorKind:
        case DO.f.MatricesIndicesKind:
        case DO.f.MatricesIndicesExtraKind:
        case DO.f.MatricesWeightsKind:
        case DO.f.MatricesWeightsExtraKind:
        case DO.f.UVKind:
        case DO.f.UV2Kind:
        case DO.f.UV3Kind:
        case DO.f.UV4Kind:
        case DO.f.UV5Kind:
        case DO.f.UV6Kind:
          return !0
      }
      return !1
    }

    function Bp(OO) {
      const KO = Math.sqrt(OO.x * OO.x + OO.y * OO.y + OO.z * OO.z);
      KO > 0 && (OO.x /= KO, OO.y /= KO, OO.z /= KO)
    }

    function Zp(OO) {
      return OO.x *= -1, OO
    }

    function Gp(OO) {
      if (OO.x * OO.x + OO.y * OO.y > .5) {
        const KO = Math.abs(OO.x),
          pO = Math.abs(OO.y);
        if (KO > pO) {
          const pO = Math.sign(OO.x);
          OO.x = KO, OO.y *= -pO, OO.z *= -pO, OO.w *= pO
        } else {
          const KO = Math.sign(OO.y);
          OO.x *= -KO, OO.y = pO, OO.z *= KO, OO.w *= -KO
        }
      } else {
        const KO = Math.abs(OO.z),
          pO = Math.abs(OO.w);
        if (KO > pO) {
          const pO = Math.sign(OO.z);
          OO.x *= -pO, OO.y *= pO, OO.z = KO, OO.w *= -pO
        } else {
          const KO = Math.sign(OO.w);
          OO.x *= KO, OO.y *= -KO, OO.z *= -KO, OO.w = pO
        }
      }
      return OO
    }

    function qX(OO) {
      OO.rvO(-OO.z, OO.w, OO.x, -OO.y)
    }

    function xX(OO, KO) {
      const pO = XO.WX.FromArrayToRef(KO.translation || [0, 0, 0], 0, XO.TmpVectors.WX[0]),
        bK = XO.Quaternion.FromArrayToRef(KO.rotation || [0, 0, 0, 1], 0, XO.TmpVectors.Quaternion[0]),
        eO = XO.Matrix.ComposeToRef(Hp, bK, pO, XO.TmpVectors.Matrix[0]),
        lO = XO.WX.FromArrayToRef(OO.translation || [0, 0, 0], 0, XO.TmpVectors.WX[2]),
        vK = XO.Quaternion.FromArrayToRef(OO.rotation || [0, 0, 0, 1], 0, XO.TmpVectors.Quaternion[1]),
        CO = XO.Matrix.ComposeToRef(Hp, vK, lO, XO.TmpVectors.Matrix[1]);
      eO.multiplyToRef(CO, CO), CO.decompose(void 0, bK, pO), pO.equalsWithEpsilon(mX, iX.c) ? delete KO.translation : KO.translation = pO.WhO(), bK.equalsWithEpsilon(sp, iX.c) ? delete KO.rotation : KO.rotation = bK.WhO(), KO.scale && delete KO.scale
    }

    function np(OO, KO) {
      if (!(KO instanceof MO.c)) return !1;
      if (!(1 === KO.getChildren().length && 0 === OO.getChildren().length && OO.parent === KO)) return !1;
      const pO = OO.JKO(),
        XO = OO instanceof wp.f && !pO.useRightHandedSystem ? Rp : Hp;
      return !!KO.ol.equalsWithEpsilon(XO, iX.c) || (uO.b.Warn(`Cannot collapse node ${OO.name} into parent node ${KO.name} with modified scaling.`), !1)
    }

    function Wp(OO) {
      if (OO instanceof Array) {
        const KO = new Float32Array(OO);
        return new Uint8Array(KO.buffer, KO.byteOffset, KO.byteLength)
      }
      return ArrayBuffer.isView(OO) ? new Uint8Array(OO.buffer, OO.byteOffset, OO.byteLength) : new Uint8Array(OO)
    }

    function tX(OO, KO) {
      for (const [pO, XO] of Object.entries(OO)) {
        const bK = KO[pO];
        (Array.isArray(XO) && Array.isArray(bK) && kX(XO, bK) || XO === bK) && delete OO[pO]
      }
      return OO
    }

    function kX(OO, KO) {
      return OO.length === KO.length && OO.every(((OO, pO) => OO === KO[pO]))
    }
    const Up = new Map([
      [Int8Array, (OO, KO, pO) => OO.setInt8(KO, pO)],
      [Uint8Array, (OO, KO, pO) => OO.setUint8(KO, pO)],
      [Uint8ClampedArray, (OO, KO, pO) => OO.setUint8(KO, pO)],
      [Int16Array, (OO, KO, pO) => OO.setInt16(KO, pO, !0)],
      [Uint16Array, (OO, KO, pO) => OO.setUint16(KO, pO, !0)],
      [Int32Array, (OO, KO, pO) => OO.setInt32(KO, pO, !0)],
      [Uint32Array, (OO, KO, pO) => OO.setUint32(KO, pO, !0)],
      [Float32Array, (OO, KO, pO) => OO.setFloat32(KO, pO, !0)],
      [Float64Array, (OO, KO, pO) => OO.setFloat64(KO, pO, !0)]
    ]);
    class OX {
      writeTypedArray(OO) {
        this._checkGrowBuffer(OO.byteLength);
        const KO = Up.get(OO.constructor);
        for (let pO = 0; pO < OO.length; pO++) KO(this._dataView, this._byteOffset, OO[pO]), this._byteOffset += OO.BYTES_PER_ELEMENT
      }
      constructor(OO) {
        this._data = new Uint8Array(OO), this._dataView = new DataView(this._data.buffer), this._byteOffset = 0
      }
      get byteOffset() {
        return this._byteOffset
      }
      getOutputData() {
        return new Uint8Array(this._data.buffer, 0, this._byteOffset)
      }
      writeUInt8(OO) {
        this._checkGrowBuffer(1), this._dataView.setUint8(this._byteOffset, OO), this._byteOffset++
      }
      writeInt8(OO) {
        this._checkGrowBuffer(1), this._dataView.setInt8(this._byteOffset, OO), this._byteOffset++
      }
      writeInt16(OO) {
        this._checkGrowBuffer(2), this._dataView.setInt16(this._byteOffset, OO, !0), this._byteOffset += 2
      }
      writeUInt16(OO) {
        this._checkGrowBuffer(2), this._dataView.setUint16(this._byteOffset, OO, !0), this._byteOffset += 2
      }
      writeInt32(OO) {
        this._checkGrowBuffer(4), this._dataView.setInt32(this._byteOffset, OO, !0), this._byteOffset += 4
      }
      writeUInt32(OO) {
        this._checkGrowBuffer(4), this._dataView.setUint32(this._byteOffset, OO, !0), this._byteOffset += 4
      }
      writeFloat32(OO) {
        this._checkGrowBuffer(4), this._dataView.setFloat32(this._byteOffset, OO, !0), this._byteOffset += 4
      }
      writeFloat64(OO) {
        this._checkGrowBuffer(8), this._dataView.setFloat64(this._byteOffset, OO, !0), this._byteOffset += 8
      }
      _checkGrowBuffer(OO) {
        const KO = this.byteOffset + OO;
        if (KO > this._data.byteLength) {
          const OO = new Uint8Array(2 * KO);
          OO.set(this._data), this._data = OO, this._dataView = new DataView(this._data.buffer)
        }
      }
    }

    function KX(OO) {
      return OO % 4 === 0 ? 4 : OO % 2 === 0 ? 2 : 1
    }
    class pX {
      constructor() {
        this._bufferViewToData = new Map, this._bufferViewToProperties = new Map, this._accessorToBufferView = new Map
      }
      generateBinary(OO) {
        let KO = 0;
        this._bufferViewToData.forEach((OO => {
          KO += OO.byteLength
        }));
        const pO = new OX(KO),
          XO = Array.from(this._bufferViewToData.keys()).sort(((OO, KO) => KX(KO.byteLength) - KX(OO.byteLength)));
        for (const bK of XO) {
          bK.byteOffset = pO.byteOffset, OO.push(bK);
          const KO = OO.length - 1,
            XO = this.getPropertiesWithBufferView(bK);
          for (const OO of XO) OO.bufferView = KO;
          pO.writeTypedArray(this._bufferViewToData.get(bK)), this._bufferViewToData.delete(bK)
        }
        return pO.getOutputData()
      }
      createBufferView(OO, KO) {
        const pO = {
          buffer: 0,
          byteOffset: void 0,
          byteLength: OO.byteLength,
          byteStride: KO
        };
        return this._bufferViewToData.set(pO, OO), pO
      }
      createAccessor(OO, KO, pO, XO, bK, eO, lO) {
        this._verifyBufferView(OO);
        const vK = {
          bufferView: void 0,
          componentType: pO,
          count: XO,
          type: KO,
          min: eO?.min,
          max: eO?.max,
          normalized: lO,
          byteOffset: bK
        };
        return this.setBufferView(vK, OO), this._accessorToBufferView.set(vK, OO), vK
      }
      setBufferView(OO, KO) {
        this._verifyBufferView(KO);
        this.getPropertiesWithBufferView(KO).push(OO)
      }
      removeBufferView(OO) {
        const KO = this.getPropertiesWithBufferView(OO);
        for (const pO of KO) void 0 !== pO.bufferView && delete pO.bufferView;
        this._bufferViewToData.delete(OO), this._bufferViewToProperties.delete(OO), this._accessorToBufferView.forEach(((KO, pO) => {
          KO === OO && (void 0 !== pO.byteOffset && delete pO.byteOffset, this._accessorToBufferView.delete(pO))
        }))
      }
      getBufferView(OO) {
        const KO = this._accessorToBufferView.get(OO);
        return this._verifyBufferView(KO), KO
      }
      getPropertiesWithBufferView(OO) {
        return this._verifyBufferView(OO), this._bufferViewToProperties.set(OO, this._bufferViewToProperties.get(OO) ?? []), this._bufferViewToProperties.get(OO)
      }
      getData(OO) {
        return this._verifyBufferView(OO), this._bufferViewToData.get(OO)
      }
      _verifyBufferView(OO) {
        if (void 0 === OO || !this._bufferViewToData.has(OO)) throw new Error(`BufferView ${OO} not found in BufferManager.`)
      }
    }
    var XX = pO(38294);
    (0, XX.f)();
    var bb = pO(38552);
    (0, bb.f)();
    var eX = pO(38355),
      lX = pO(39242);
    (0, lX.g)();
    let vb = (() => {
      var OO;
      let KO, pO, XO = [],
        bK = [],
        eO = [],
        lO = [];
      return OO = class {
        get influence() {
          return this._influence
        }
        set influence(OO) {
          if (this._influence === OO) return;
          const KO = this._influence;
          this._influence = OO, this.onInfluenceChanged.hasObservers() && this.onInfluenceChanged.notifyObservers(0 === KO || 0 === OO)
        }
        get animationPropertiesOverride() {
          return !this._animationPropertiesOverride && this._scene ? this._scene.animationPropertiesOverride : this._animationPropertiesOverride
        }
        set animationPropertiesOverride(OO) {
          this._animationPropertiesOverride = OO
        }
        constructor(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
            vK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
          this.name = OO, this.animations = [], this._positions = null, this._normals = null, this._tangents = null, this._uvs = null, this._uv2s = null, this._colors = null, this._uniqueId = 0, this.onInfluenceChanged = new Op.e, this._onDataLayoutChanged = new Op.e, this.id = (0, yK.i)(this, XO, void 0), this.morphTargetManager = ((0, yK.i)(this, bK), (0, yK.i)(this, eO, null)), this._animationPropertiesOverride = ((0, yK.i)(this, lO), null), this.id = OO, this.morphTargetManager = vK, this._scene = pO || VO.c.LastCreatedScene, this.influence = KO, this._scene && (this._uniqueId = this._scene.getUniqueId())
        }
        get uniqueId() {
          return this._uniqueId
        }
        get hasPositions() {
          return !!this._positions
        }
        get hasNormals() {
          return !!this._normals
        }
        get hasTangents() {
          return !!this._tangents
        }
        get hasUVs() {
          return !!this._uvs
        }
        get hasUV2s() {
          return !!this._uv2s
        }
        get hasColors() {
          return !!this._colors
        }
        get vertexCount() {
          return this._positions ? this._positions.length / 3 : this._normals ? this._normals.length / 3 : this._tangents ? this._tangents.length / 3 : this._uvs ? this._uvs.length / 2 : this._uv2s ? this._uv2s.length / 2 : this._colors ? this._colors.length / 4 : 0
        }
        mFO(OO) {
          const KO = this.hasPositions;
          this._positions = OO, KO !== this.hasPositions && this._onDataLayoutChanged.notifyObservers(void 0)
        }
        getPositions() {
          return this._positions
        }
        setNormals(OO) {
          const KO = this.hasNormals;
          this._normals = OO, KO !== this.hasNormals && this._onDataLayoutChanged.notifyObservers(void 0)
        }
        getNormals() {
          return this._normals
        }
        setTangents(OO) {
          const KO = this.hasTangents;
          this._tangents = OO, KO !== this.hasTangents && this._onDataLayoutChanged.notifyObservers(void 0)
        }
        getTangents() {
          return this._tangents
        }
        setUVs(OO) {
          const KO = this.hasUVs;
          this._uvs = OO, KO !== this.hasUVs && this._onDataLayoutChanged.notifyObservers(void 0)
        }
        getUVs() {
          return this._uvs
        }
        setUV2s(OO) {
          const KO = this.hasUV2s;
          this._uv2s = OO, KO !== this.hasUV2s && this._onDataLayoutChanged.notifyObservers(void 0)
        }
        getUV2s() {
          return this._uv2s
        }
        setColors(OO) {
          const KO = this.hasColors;
          this._colors = OO, KO !== this.hasColors && this._onDataLayoutChanged.notifyObservers(void 0)
        }
        getColors() {
          return this._colors
        }
        clone() {
          const KO = NK.c.Clone((() => new OO(this.name, this.influence, this._scene, this.morphTargetManager)), this);
          return KO._positions = this._positions, KO._normals = this._normals, KO._tangents = this._tangents, KO._uvs = this._uvs, KO._uv2s = this._uv2s, KO._colors = this._colors, KO
        }
        serialize() {
          const OO = {};
          return OO.name = this.name, OO.influence = this.influence, null != this.id && (OO.id = this.id), OO.uniqueId = this.uniqueId, OO.positions = Array.prototype.slice.call(this.getPositions()), this.hasNormals && (OO.normals = Array.prototype.slice.call(this.getNormals())), this.hasTangents && (OO.tangents = Array.prototype.slice.call(this.getTangents())), this.hasUVs && (OO.uvs = Array.prototype.slice.call(this.getUVs())), this.hasUV2s && (OO.uv2s = Array.prototype.slice.call(this.getUV2s())), this.hasColors && (OO.colors = Array.prototype.slice.call(this.getColors())), NK.c.AppendSerializedAnimations(this, OO), OO
        }
        getClassName() {
          return "MorphTarget"
        }
        static Parse(KO, pO) {
          let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
          const bK = new OO(KO.name, KO.influence, pO, XO);
          if (bK.mFO(KO.positions), null != KO.id && (bK.id = KO.id), KO.normals && bK.setNormals(KO.normals), KO.tangents && bK.setTangents(KO.tangents), KO.uvs && bK.setUVs(KO.uvs), KO.uv2s && bK.setUV2s(KO.uv2s), KO.colors && bK.setColors(KO.colors), KO.animations) {
            for (let OO = 0; OO < KO.animations.length; OO++) {
              const pO = KO.animations[OO],
                XO = (0, JK.e)("BABYLON.Animation");
              XO && bK.animations.push(XO.Parse(pO))
            }
            KO.autoAnimate && pO && pO.beginAnimation(bK, KO.autoAnimateFrom, KO.autoAnimateTo, KO.autoAnimateLoop, KO.autoAnimateSpeed || 1)
          }
          return bK
        }
        static FromMesh(KO, pO, XO) {
          pO || (pO = KO.name);
          const bK = new OO(pO, XO, KO.JKO(), KO.morphTargetManager);
          return bK.mFO(KO.getVerticesData(RO.j.PositionKind)), KO.isVerticesDataPresent(RO.j.NormalKind) && bK.setNormals(KO.getVerticesData(RO.j.NormalKind)), KO.isVerticesDataPresent(RO.j.TangentKind) && bK.setTangents(KO.getVerticesData(RO.j.TangentKind)), KO.isVerticesDataPresent(RO.j.UVKind) && bK.setUVs(KO.getVerticesData(RO.j.UVKind)), KO.isVerticesDataPresent(RO.j.UV2Kind) && bK.setUV2s(KO.getVerticesData(RO.j.UV2Kind)), KO.isVerticesDataPresent(RO.j.ColorKind) && bK.setColors(KO.getVerticesData(RO.j.ColorKind)), bK
        }
      }, (() => {
        const vK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, gK.M)()], pO = [(0, gK.M)()], (0, yK.f)(null, null, KO, {
          kind: "field",
          name: "id",
          static: !1,
          private: !1,
          access: {
            has: OO => "id" in OO,
            get: OO => OO.id,
            set: (OO, KO) => {
              OO.id = KO
            }
          },
          metadata: vK
        }, XO, bK), (0, yK.f)(null, null, pO, {
          kind: "field",
          name: "morphTargetManager",
          static: !1,
          private: !1,
          access: {
            has: OO => "morphTargetManager" in OO,
            get: OO => OO.morphTargetManager,
            set: (OO, KO) => {
              OO.morphTargetManager = KO
            }
          },
          metadata: vK
        }, eO, lO), vK && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: vK
        })
      })(), OO
    })();
    var CX, hX = pO(39305),
      DX = pO(38347);
    ! function(OO) {
      OO[OO.INTANGENT = 0] = "INTANGENT", OO[OO.OUTTANGENT = 1] = "OUTTANGENT"
    }(CX || (CX = {}));
    class MX {
      static _IsTransformable(OO) {
        return OO && (OO instanceof MO.c || OO instanceof XX.c || OO instanceof DX.b)
      }
      static _CreateNodeAnimation(OO, KO, pO, XO, eO) {
        if (this._IsTransformable(OO)) {
          const lO = [],
            vK = [],
            CO = KO.getKeys(),
            hO = MX._CalculateMinMaxKeyFrames(CO),
            DO = MX._DeduceInterpolation(CO, pO, XO),
            MO = DO.interpolationType,
            aK = DO.shouldBakeAnimation;
          if (aK ? MX._CreateBakedAnimation(OO, KO, pO, hO.min, hO.max, KO.framePerSecond, eO, lO, vK, hO, XO) : "LINEAR" === MO || "STEP" === MO ? MX._CreateLinearOrStepAnimation(OO, KO, pO, lO, vK, XO) : "CUBICSPLINE" === MO ? MX._CreateCubicSplineAnimation(OO, KO, pO, lO, vK, XO) : MX._CreateBakedAnimation(OO, KO, pO, hO.min, hO.max, KO.framePerSecond, eO, lO, vK, hO, XO), lO.length && vK.length) {
            return {
              inputs: lO,
              outputs: vK,
              samplerInterpolation: MO,
              inputsMin: aK ? hO.min : bK.Tools.FloatRound(hO.min / KO.framePerSecond),
              inputsMax: aK ? hO.max : bK.Tools.FloatRound(hO.max / KO.framePerSecond)
            }
          }
        }
        return null
      }
      static _DeduceAnimationInfo(OO) {
        let KO = null,
          pO = "VEC3",
          XO = !1;
        const eO = OO.targetProperty.split(".");
        switch (eO[0]) {
          case "ol":
            KO = "scale";
            break;
          case "position":
            KO = "translation";
            break;
          case "rotation":
            pO = "VEC4", KO = "rotation";
            break;
          case "rotationQuaternion":
            pO = "VEC4", XO = !0, KO = "rotation";
            break;
          case "influence":
            pO = "SCALAR", KO = "weights";
            break;
          default:
            bK.Tools.Error(`Unsupported animatable property ${eO[0]}`)
        }
        return KO ? {
          animationChannelTargetPath: KO,
          dataAccessorType: pO,
          useQuaternion: XO
        } : (bK.Tools.Error("animation channel target path and data accessor type could be deduced"), null)
      }
      static _CreateNodeAnimationFromNodeAnimations(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
        let MO;
        if (MX._IsTransformable(OO) && OO.animations)
          for (const aK of OO.animations) {
            if (DO && !DO(aK)) continue;
            const bK = MX._DeduceAnimationInfo(aK);
            bK && (MO = {
              name: aK.name,
              samplers: [],
              channels: []
            }, MX._AddAnimation(`${aK.name}`, aK.hasRunningRuntimeAnimations ? KO : MO, OO, aK, bK.dataAccessorType, bK.animationChannelTargetPath, XO, eO, lO, vK, bK.useQuaternion, CO, hO), MO.samplers.length && MO.channels.length && pO.push(MO))
          }
      }
      static _CreateMorphTargetAnimationFromMorphTargetAnimations(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
        let MO;
        if (OO instanceof hX.c) {
          const bK = OO.morphTargetManager;
          if (bK)
            for (let aK = 0; aK < bK.numTargets; ++aK) {
              const oO = bK.getTarget(aK);
              for (const FO of oO.animations) {
                if (DO && !DO(FO)) continue;
                const oO = new lX.e(`${FO.name}`, "influence", FO.framePerSecond, FO.dataType, FO.i4, FO.enableBlending),
                  VO = [],
                  LO = FO.getKeys();
                for (let OO = 0; OO < LO.length; ++OO) {
                  const KO = LO[OO];
                  for (let OO = 0; OO < bK.numTargets; ++OO) OO == aK ? VO.push(KO) : VO.push({
                    frame: KO.frame,
                    value: 0
                  })
                }
                oO.setKeys(VO, !0);
                const QO = MX._DeduceAnimationInfo(oO);
                QO && (MO = {
                  name: oO.name,
                  samplers: [],
                  channels: []
                }, MX._AddAnimation(FO.name, FO.hasRunningRuntimeAnimations ? KO : MO, OO, oO, QO.dataAccessorType, QO.animationChannelTargetPath, XO, eO, lO, vK, QO.useQuaternion, CO, hO, bK.numTargets), MO.samplers.length && MO.channels.length && pO.push(MO))
              }
            }
        }
      }
      static _CreateNodeAndMorphAnimationFromAnimationGroups(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
        let DO;
        if (OO.animationGroups) {
          const MO = OO.animationGroups;
          for (const aK of MO) {
            const MO = new Map,
              oO = new Map,
              FO = new Set,
              VO = aK.to - aK.from;
            DO = {
              name: aK.name,
              channels: [],
              samplers: []
            };
            for (let KO = 0; KO < aK.targetedAnimations.length; ++KO) {
              const hO = aK.targetedAnimations[KO],
                VO = hO.target,
                LO = hO.animation;
              if (CO && !CO(LO)) continue;
              const QO = vK.has(VO);
              if (this._IsTransformable(VO) || 1 === VO.length && this._IsTransformable(VO[0])) {
                const OO = MX._DeduceAnimationInfo(hO.animation);
                if (OO) {
                  const KO = this._IsTransformable(VO) ? VO : this._IsTransformable(VO[0]) ? VO[0] : null;
                  KO && MX._AddAnimation(`${LO.name}`, DO, KO, LO, OO.dataAccessorType, OO.animationChannelTargetPath, pO, XO, bK, eO, OO.useQuaternion, lO, QO)
                }
              } else if (VO instanceof vb || 1 === VO.length && VO[0] instanceof vb) {
                if (MX._DeduceAnimationInfo(hO.animation)) {
                  const KO = VO instanceof vb ? VO : VO[0];
                  if (KO) {
                    const pO = OO.morphTargetManagers.find((OO => {
                      for (let pO = 0; pO < OO.numTargets; ++pO)
                        if (OO.getTarget(pO) === KO) return !0;
                      return !1
                    }));
                    if (pO) {
                      const XO = OO.meshes.find((OO => OO.morphTargetManager === pO));
                      XO && (MO.has(XO) || MO.set(XO, new Map), MO.get(XO)?.set(KO, LO), FO.add(XO), oO.set(XO, LO))
                    }
                  }
                }
              }
            }
            FO.forEach((OO => {
              const KO = OO.morphTargetManager;
              let vK = null;
              const CO = [],
                hO = oO.get(OO).getKeys(),
                FO = hO.length;
              for (let pO = 0; pO < FO; ++pO)
                for (let XO = 0; XO < KO.numTargets; ++XO) {
                  const bK = KO.getTarget(XO),
                    eO = MO.get(OO);
                  if (eO) {
                    const KO = eO.get(bK);
                    KO ? (vK || (vK = new lX.e(`${aK.name}_${OO.name}_MorphWeightAnimation`, "influence", KO.framePerSecond, lX.e.ANIMATIONTYPE_FLOAT, KO.i4, KO.enableBlending)), CO.push(KO.getKeys()[pO])) : CO.push({
                      frame: aK.from + VO / FO * pO,
                      value: bK.influence,
                      inTangent: hO[0].inTangent ? 0 : void 0,
                      outTangent: hO[0].outTangent ? 0 : void 0
                    })
                  }
                }
              vK.setKeys(CO, !0);
              const LO = MX._DeduceAnimationInfo(vK);
              LO && MX._AddAnimation(`${aK.name}_${OO.name}_MorphWeightAnimation`, DO, OO, vK, LO.dataAccessorType, LO.animationChannelTargetPath, pO, XO, bK, eO, LO.useQuaternion, lO, !1, KO?.numTargets)
            })), DO.channels.length && DO.samplers.length && (hO?.set(aK, KO.length), KO.push(DO))
          }
        }
      }
      static _AddAnimation(OO, KO, pO, bK, eO, lO, vK, CO, hO, DO, MO, aK, oO, FO) {
        const VO = MX._CreateNodeAnimation(pO, bK, lO, MO, aK);
        let LO, QO, zK, AO, fO, dO;
        if (VO) {
          if (FO) {
            let OO, KO = 0;
            const pO = [];
            for (; VO.inputs.length > 0;) OO = VO.inputs.shift(), KO % FO == 0 && pO.push(OO), KO++;
            VO.inputs = pO
          }
          const OO = vK.get(pO),
            bK = new Float32Array(VO.inputs);
          LO = CO.createBufferView(bK), QO = CO.createAccessor(LO, "SCALAR", 5126, VO.inputs.length, void 0, {
            min: [VO.inputsMin],
            max: [VO.inputsMax]
          }), DO.push(QO), zK = DO.length - 1;
          const hO = new XO.Quaternion,
            MO = new XO.WX,
            aK = new XO.WX,
            TO = pO instanceof XX.c,
            NO = Jp(eO),
            IO = new Float32Array(VO.outputs.length * NO);
          VO.outputs.forEach((function(OO, KO) {
            let pO = OO;
            switch (lO) {
              case "translation":
                oO && (XO.WX.FromArrayToRef(OO, 0, aK), Zp(aK), aK.toArray(pO));
                break;
              case "rotation":
                4 === OO.length ? XO.Quaternion.FromArrayToRef(OO, 0, hO) : (pO = new Array(4), XO.WX.FromArrayToRef(OO, 0, MO), XO.Quaternion.FromEulerVectorToRef(MO, hO)), oO && (Gp(hO), TO && qX(hO)), hO.toArray(pO)
            }
            IO.set(pO, KO * NO)
          })), LO = CO.createBufferView(IO), QO = CO.createAccessor(LO, eO, 5126, VO.outputs.length), DO.push(QO), AO = DO.length - 1, fO = {
            interpolation: VO.samplerInterpolation,
            input: zK,
            output: AO
          }, KO.samplers.push(fO), dO = {
            sampler: KO.samplers.length - 1,
            target: {
              node: OO,
              path: lO
            }
          }, KO.channels.push(dO)
        }
      }
      static _CreateBakedAnimation(OO, KO, pO, eO, lO, vK, CO, hO, DO, MO, aK) {
        let oO;
        const FO = XO.Quaternion.Identity();
        let VO, LO, QO, zK, AO, fO = null,
          dO = null;
        MO.min = bK.Tools.FloatRound(eO / vK);
        const TO = KO.getKeys();
        for (let XO = 0, NO = TO.length; XO < NO; ++XO) {
          if (LO = TO[XO], XO + 1 < NO)
            if (QO = TO[XO + 1], LO.value.equals && LO.value.equals(QO.value) || LO.value === QO.value) {
              if (0 !== XO) continue;
              AO = LO.frame
            } else AO = QO.frame;
          else {
            if (zK = TO[XO - 1], LO.value.equals && LO.value.equals(zK.value) || LO.value === zK.value) continue;
            AO = lO
          }
          if (AO)
            for (let XO = LO.frame; XO <= AO; XO += CO) {
              if (VO = bK.Tools.FloatRound(XO / vK), VO === fO) continue;
              fO = VO, dO = VO;
              const eO = {
                key: 0,
                repeatCount: 0,
                i4: KO.i4
              };
              oO = KO._interpolate(XO, eO), MX._SetInterpolatedValue(OO, oO, VO, KO, pO, FO, hO, DO, aK)
            }
        }
        dO && (MO.max = dO)
      }
      static _ConvertFactorToVector3OrQuaternion(OO, KO, pO, eO, lO) {
        const vK = MX._GetBasePositionRotationOrScale(KO, eO, lO),
          CO = pO.targetProperty.split("."),
          hO = CO ? CO[1] : "",
          DO = lO ? XO.Quaternion.FromArray(vK).normalize() : XO.WX.FromArray(vK);
        switch (hO) {
          case "x":
          case "y":
          case "z":
            DO[hO] = OO;
            break;
          case "w":
            DO.w = OO;
            break;
          default:
            bK.Tools.Error(`glTFAnimation: Unsupported component name "${hO}"!`)
        }
        return DO
      }
      static _SetInterpolatedValue(OO, KO, pO, bK, eO, lO, vK, CO, hO) {
        let DO;
        vK.push(pO), "weights" !== eO ? (bK.dataType === lX.e.ANIMATIONTYPE_FLOAT && (KO = this._ConvertFactorToVector3OrQuaternion(KO, OO, bK, eO, hO)), "rotation" === eO ? (hO ? lO = KO : (DO = KO, XO.Quaternion.RotationYawPitchRollToRef(DO.y, DO.x, DO.z, lO)), CO.push(lO.WhO())) : (DO = KO, CO.push(DO.WhO()))) : CO.push([KO])
      }
      static _CreateLinearOrStepAnimation(OO, KO, pO, XO, bK, eO) {
        for (const lO of KO.getKeys()) XO.push(lO.frame / KO.framePerSecond), MX._AddKeyframeValue(lO, KO, bK, pO, OO, eO)
      }
      static _CreateCubicSplineAnimation(OO, KO, pO, XO, bK, eO) {
        KO.getKeys().forEach((function(lO) {
          XO.push(lO.frame / KO.framePerSecond), MX._AddSplineTangent(CX.INTANGENT, bK, pO, "CUBICSPLINE", lO, eO), MX._AddKeyframeValue(lO, KO, bK, pO, OO, eO), MX._AddSplineTangent(CX.OUTTANGENT, bK, pO, "CUBICSPLINE", lO, eO)
        }))
      }
      static _GetBasePositionRotationOrScale(OO, KO, pO) {
        let bK;
        if ("rotation" === KO)
          if (pO) {
            bK = (OO.rotationQuaternion ?? XO.Quaternion.Identity()).WhO()
          } else {
            bK = (OO.rotation ?? XO.WX.Zero()).WhO()
          }
        else if ("translation" === KO) {
          bK = (OO.position ?? XO.WX.Zero()).WhO()
        } else {
          bK = (OO.ol ?? XO.WX.One()).WhO()
        }
        return bK
      }
      static _AddKeyframeValue(OO, KO, pO, eO, lO, vK) {
        let CO;
        const hO = KO.dataType;
        if (hO === lX.e.ANIMATIONTYPE_VECTOR3) {
          let KO = OO.value.WhO();
          if ("rotation" === eO) {
            const OO = XO.WX.FromArray(KO);
            KO = XO.Quaternion.RotationYawPitchRoll(OO.y, OO.x, OO.z).WhO()
          }
          pO.push(KO)
        } else if (hO === lX.e.ANIMATIONTYPE_FLOAT) {
          if ("weights" === eO) pO.push([OO.value]);
          else if (CO = this._ConvertFactorToVector3OrQuaternion(OO.value, lO, KO, eO, vK), CO) {
            if ("rotation" === eO) {
              const OO = vK ? CO : XO.Quaternion.RotationYawPitchRoll(CO.y, CO.x, CO.z).normalize();
              pO.push(OO.WhO())
            }
            pO.push(CO.WhO())
          }
        } else hO === lX.e.ANIMATIONTYPE_QUATERNION ? pO.push(OO.value.normalize().WhO()) : bK.Tools.Error("glTFAnimation: Unsupported key frame values for animation!")
      }
      static _DeduceInterpolation(OO, KO, pO) {
        let XO, bK, eO = !1;
        if ("rotation" === KO && !pO) return {
          interpolationType: "LINEAR",
          shouldBakeAnimation: !0
        };
        for (let lO = 0, vK = OO.length; lO < vK; ++lO)
          if (bK = OO[lO], bK.inTangent || bK.outTangent)
            if (XO) {
              if ("CUBICSPLINE" !== XO) {
                XO = "LINEAR", eO = !0;
                break
              }
            } else XO = "CUBICSPLINE";
        else if (XO) {
          if ("CUBICSPLINE" === XO || bK.interpolation && 1 === bK.interpolation && "STEP" !== XO) {
            XO = "LINEAR", eO = !0;
            break
          }
        } else XO = bK.interpolation && 1 === bK.interpolation ? "STEP" : "LINEAR";
        return XO || (XO = "LINEAR"), {
          interpolationType: XO,
          shouldBakeAnimation: eO
        }
      }
      static _AddSplineTangent(OO, KO, pO, bK, eO, lO) {
        let vK;
        const CO = OO === CX.INTANGENT ? eO.inTangent : eO.outTangent;
        if ("CUBICSPLINE" === bK) {
          if ("rotation" === pO)
            if (CO)
              if (lO) vK = CO.WhO();
              else {
                const OO = CO;
                vK = XO.Quaternion.RotationYawPitchRoll(OO.y, OO.x, OO.z).WhO()
              }
          else vK = [0, 0, 0, 0];
          else vK = "weights" === pO ? CO ? [CO] : [0] : CO ? CO.WhO() : [0, 0, 0];
          KO.push(vK)
        }
      }
      static _CalculateMinMaxKeyFrames(OO) {
        let KO = 1 / 0,
          pO = -1 / 0;
        return OO.forEach((function(OO) {
          KO = Math.min(KO, OO.frame), pO = Math.max(pO, OO.frame)
        })), {
          min: KO,
          max: pO
        }
      }
    }

    function ab(OO, KO, pO, eO, lO, vK) {
      const CO = {
          attributes: {},
          influence: OO.influence,
          name: OO.name
        },
        hO = KO.geometry;
      if (!hO) return bK.Tools.Warn("Attempted to export morph target data from a mesh without geometry. This should not happen."), CO;
      const MO = vK ? -1 : 1,
        aK = XO.WX.Zero();
      let oO, FO;
      if (OO.hasPositions) {
        const eO = OO.getPositions(),
          vK = hO.getVerticesData(DO.f.PositionKind);
        if (vK) {
          const OO = new Float32Array(vK.length),
            KO = [1 / 0, 1 / 0, 1 / 0],
            bK = [-1 / 0, -1 / 0, -1 / 0];
          FO = vK.length / 3, oO = 0;
          for (let pO = oO; pO < FO; ++pO) {
            const lO = XO.WX.FromArray(vK, 3 * pO);
            XO.WX.FromArray(eO, 3 * pO).subtractToRef(lO, aK), aK.x *= MO, KO[0] = Math.min(KO[0], aK.x), bK[0] = Math.max(bK[0], aK.x), KO[1] = Math.min(KO[1], aK.y), bK[1] = Math.max(bK[1], aK.y), KO[2] = Math.min(KO[2], aK.z), bK[2] = Math.max(bK[2], aK.z), OO[3 * pO] = aK.x, OO[3 * pO + 1] = aK.y, OO[3 * pO + 2] = aK.z
          }
          const hO = pO.createBufferView(OO, 12),
            DO = pO.createAccessor(hO, "VEC3", 5126, eO.length / 3, 0, {
              min: KO,
              max: bK
            });
          lO.push(DO), CO.attributes.POSITION = lO.length - 1
        } else bK.Tools.Warn(`Morph target positions for mesh ${KO.name} were not exported. Mesh does not have position vertex data`)
      }
      if (OO.hasNormals) {
        const eO = OO.getNormals(),
          vK = hO.getVerticesData(DO.f.NormalKind);
        if (vK) {
          const OO = new Float32Array(vK.length);
          FO = vK.length / 3, oO = 0;
          for (let pO = oO; pO < FO; ++pO) {
            const KO = XO.WX.FromArray(vK, 3 * pO).normalize();
            XO.WX.FromArray(eO, 3 * pO).normalize().subtractToRef(KO, aK), OO[3 * pO] = aK.x * MO, OO[3 * pO + 1] = aK.y, OO[3 * pO + 2] = aK.z
          }
          const KO = pO.createBufferView(OO, 12),
            bK = pO.createAccessor(KO, "VEC3", 5126, eO.length / 3, 0);
          lO.push(bK), CO.attributes.NORMAL = lO.length - 1
        } else bK.Tools.Warn(`Morph target normals for mesh ${KO.name} were not exported. Mesh does not have normals vertex data`)
      }
      if (OO.hasTangents) {
        const eO = OO.getTangents(),
          vK = hO.getVerticesData(DO.f.TangentKind);
        if (vK) {
          FO = vK.length / 4;
          const OO = new Float32Array(3 * FO);
          oO = 0;
          for (let pO = oO; pO < FO; ++pO) {
            const KO = XO.WX.FromArray(vK, 4 * pO);
            Bp(KO);
            const bK = XO.WX.FromArray(eO, 3 * pO);
            Bp(bK), bK.subtractToRef(KO, aK), OO[3 * pO] = aK.x * MO, OO[3 * pO + 1] = aK.y, OO[3 * pO + 2] = aK.z
          }
          const KO = pO.createBufferView(OO, 12),
            bK = pO.createAccessor(KO, "VEC3", 5126, FO, 0);
          lO.push(bK), CO.attributes.TANGENT = lO.length - 1
        } else bK.Tools.Warn(`Morph target tangents for mesh ${KO.name} were not exported. Mesh does not have tangents vertex data`)
      }
      if (OO.hasColors) {
        const eO = OO.getColors(),
          vK = hO.getVerticesData(DO.f.ColorKind),
          MO = hO.getVertexBuffer(DO.f.ColorKind);
        if (vK && MO) {
          const OO = MO.getSize();
          FO = vK.length / OO;
          const KO = new Float32Array(FO * OO);
          oO = 0;
          for (let pO = oO; pO < FO; ++pO)
            if (3 === OO) {
              const bK = XO.WX.FromArray(vK, pO * OO);
              XO.WX.FromArray(eO, pO * OO).subtractToRef(bK, aK), KO[3 * pO] = aK.x, KO[3 * pO + 1] = aK.y, KO[3 * pO + 2] = aK.z
            } else if (4 === OO) {
            const bK = new XO.Vector4,
              lO = XO.Vector4.FromArray(vK, pO * OO);
            XO.Vector4.FromArray(eO, pO * OO).subtractToRef(lO, bK), KO[4 * pO] = bK.x, KO[4 * pO + 1] = bK.y, KO[4 * pO + 2] = bK.z, KO[4 * pO + 3] = bK.w
          } else bK.Tools.Warn(`Unsupported number of components for color attribute: ${OO}`);
          const hO = pO.createBufferView(KO, 4 * OO),
            DO = pO.createAccessor(hO, 3 === OO ? "VEC3" : "VEC4", 5126, FO, 0);
          lO.push(DO), CO.attributes.COLOR_0 = lO.length - 1
        } else bK.Tools.Warn(`Morph target colors for mesh ${KO.name} were not exported. Mesh does not have colors vertex data`)
      }
      return CO
    }
    var oX = pO(39604);
    class FX {}
    FX.DEFAULT_COLOR = GO.e.White(), FX.DEFAULT_WIDTH_ATTENUATED = 1, FX.DEFAULT_WIDTH = .1;
    var VX = pO(39234);
    class LX {
      constructor(OO) {
        this._paths = [], this._tempPaths = [], this._holes = [], this._resolution = OO
      }
      moveTo(OO, KO) {
        this._currentPath = new VX.i(OO, KO), this._tempPaths.push(this._currentPath)
      }
      lineTo(OO, KO) {
        this._currentPath.addLineTo(OO, KO)
      }
      quadraticCurveTo(OO, KO, pO, XO) {
        this._currentPath.addQuadraticCurveTo(OO, KO, pO, XO, this._resolution)
      }
      bezierCurveTo(OO, KO, pO, XO, bK, eO) {
        this._currentPath.addBezierCurveTo(OO, KO, pO, XO, bK, eO, this._resolution)
      }
      extractHoles() {
        for (const OO of this._tempPaths) OO.area() > 0 ? this._holes.push(OO) : this._paths.push(OO);
        if (!this._paths.length && this._holes.length) {
          const OO = this._holes;
          this._holes = this._paths, this._paths = OO
        }
        this._tempPaths.length = 0
      }
      get paths() {
        return this._paths
      }
      get holes() {
        return this._holes
      }
    }

    function QX(OO, KO, pO, XO, bK, eO) {
      const lO = eO.glyphs[OO] || eO.glyphs["?"];
      if (!lO) return null;
      const vK = new LX(bK);
      if (lO.o) {
        const OO = lO.o.split(" ");
        for (let bK = 0, eO = OO.length; bK < eO;) {
          switch (OO[bK++]) {
            case "m": {
              const eO = parseInt(OO[bK++]) * KO + pO,
                lO = parseInt(OO[bK++]) * KO + XO;
              vK.moveTo(eO, lO);
              break
            }
            case "l": {
              const eO = parseInt(OO[bK++]) * KO + pO,
                lO = parseInt(OO[bK++]) * KO + XO;
              vK.lineTo(eO, lO);
              break
            }
            case "q": {
              const eO = parseInt(OO[bK++]) * KO + pO,
                lO = parseInt(OO[bK++]) * KO + XO,
                CO = parseInt(OO[bK++]) * KO + pO,
                hO = parseInt(OO[bK++]) * KO + XO;
              vK.quadraticCurveTo(CO, hO, eO, lO);
              break
            }
            case "b": {
              const eO = parseInt(OO[bK++]) * KO + pO,
                lO = parseInt(OO[bK++]) * KO + XO,
                CO = parseInt(OO[bK++]) * KO + pO,
                hO = parseInt(OO[bK++]) * KO + XO,
                DO = parseInt(OO[bK++]) * KO + pO,
                MO = parseInt(OO[bK++]) * KO + XO;
              vK.bezierCurveTo(CO, hO, DO, MO, eO, lO);
              break
            }
          }
        }
      }
      return vK.extractHoles(), {
        offsetX: lO.ha * KO,
        shapePath: vK
      }
    }

    function zb(OO, KO, pO, XO) {
      const bK = Array.from(OO),
        eO = KO / XO.resolution,
        lO = (XO.boundingBox.yMax - XO.boundingBox.yMin + XO.underlineThickness) * eO,
        vK = [];
      let CO = 0,
        hO = 0;
      for (let DO = 0; DO < bK.length; DO++) {
        const OO = bK[DO];
        if ("\n" === OO) CO = 0, hO -= lO;
        else {
          const KO = QX(OO, eO, CO, hO, pO, XO);
          KO && (CO += KO.offsetX, vK.push(KO.shapePath))
        }
      }
      return vK
    }
    class AX {
      static ConvertPoints(OO, KO) {
        if (OO.length && Array.isArray(OO) && "number" === typeof OO[0]) return [OO];
        if (OO.length && Array.isArray(OO[0]) && "number" === typeof OO[0][0]) return OO;
        if (OO.length && !Array.isArray(OO[0]) && OO[0] instanceof HO.o) {
          const KO = [];
          for (let pO = 0; pO < OO.length; pO++) {
            const XO = OO[pO];
            KO.push(XO.x, XO.y, XO.z)
          }
          return [KO]
        }
        if (OO.length > 0 && Array.isArray(OO[0]) && OO[0].length > 0 && OO[0][0] instanceof HO.o) {
          const KO = [],
            pO = OO;
          for (const OO of pO) KO.push(OO.flatMap((OO => [OO.x, OO.y, OO.z])));
          return KO
        }
        if (OO instanceof Float32Array) {
          if (KO?.floatArrayStride) {
            const pO = [],
              XO = 3 * KO.floatArrayStride;
            for (let KO = 0; KO < OO.length; KO += XO) {
              const bK = new Array(XO);
              for (let pO = 0; pO < XO; pO++) bK[pO] = OO[KO + pO];
              pO.push(bK)
            }
            return pO
          }
          return [Array.from(OO)]
        }
        if (OO.length && OO[0] instanceof Float32Array) {
          const KO = [];
          for (const pO of OO) KO.push(Array.from(pO));
          return KO
        }
        return []
      }
      static OmitZeroLengthPredicate(OO, KO, pO) {
        const XO = [];
        return KO.subtract(OO).lengthSquared() > 0 && XO.push([OO, KO]), pO.subtract(KO).lengthSquared() > 0 && XO.push([KO, pO]), OO.subtract(pO).lengthSquared() > 0 && XO.push([pO, OO]), 0 === XO.length ? null : XO
      }
      static OmitDuplicatesPredicate(OO, KO, pO, XO) {
        const bK = [];
        return AX._SearchInPoints(OO, KO, XO) || bK.push([OO, KO]), AX._SearchInPoints(KO, pO, XO) || bK.push([KO, pO]), AX._SearchInPoints(pO, OO, XO) || bK.push([pO, OO]), 0 === bK.length ? null : bK
      }
      static _SearchInPoints(OO, KO, pO) {
        for (const XO of pO)
          for (let pO = 0; pO < XO.length; pO++)
            if (XO[pO]?.equals(OO) && (XO[pO + 1]?.equals(KO) || XO[pO - 1]?.equals(KO))) return !0;
        return !1
      }
      static MeshesToLines(OO, KO) {
        const pO = [];
        for (let XO = 0; XO < OO.length; XO++) {
          const bK = OO[XO],
            eO = bK.getVerticesData(RO.j.PositionKind),
            lO = bK.rFO();
          if (eO && lO)
            for (let OO = 0, vK = 0; OO < lO.length; OO++) {
              const CO = 3 * lO[vK++],
                hO = 3 * lO[vK++],
                DO = 3 * lO[vK++],
                MO = new HO.o(eO[CO], eO[CO + 1], eO[CO + 2]),
                aK = new HO.o(eO[hO], eO[hO + 1], eO[hO + 2]),
                oO = new HO.o(eO[DO], eO[DO + 1], eO[DO + 2]);
              if (KO) {
                const vK = KO(MO, aK, oO, pO, OO, CO, bK, XO, eO, lO);
                if (vK)
                  for (const OO of vK) pO.push(OO)
              } else pO.push([MO, aK], [aK, oO], [oO, MO])
            }
        }
        return pO
      }
      static ToVector3Array(OO) {
        if (Array.isArray(OO[0])) {
          const KO = [],
            pO = OO;
          for (const OO of pO) {
            const pO = [];
            for (let KO = 0; KO < OO.length; KO += 3) pO.push(new HO.o(OO[KO], OO[KO + 1], OO[KO + 2]));
            KO.push(pO)
          }
          return KO
        }
        const KO = OO,
          pO = [];
        for (let XO = 0; XO < KO.length; XO += 3) pO.push(new HO.o(KO[XO], KO[XO + 1], KO[XO + 2]));
        return pO
      }
      static ToNumberArray(OO) {
        return OO.flatMap((OO => [OO.x, OO.y, OO.z]))
      }
      static GetPointsCountInfo(OO) {
        const KO = new Array(OO.length);
        let pO = 0;
        for (let XO = OO.length; XO--;) KO[XO] = OO[XO].length / 3, pO += KO[XO];
        return {
          total: pO,
          counts: KO
        }
      }
      static GetLineLength(OO) {
        if (0 === OO.length) return 0;
        let KO;
        KO = "number" === typeof OO[0] ? AX.ToVector3Array(OO) : OO;
        const pO = HO.j.WX[0];
        let XO = 0;
        for (let bK = 0; bK < KO.length - 1; bK++) {
          const OO = KO[bK];
          XO += KO[bK + 1].subtractToRef(OO, pO).length()
        }
        return XO
      }
      static GetLineLengthArray(OO, KO) {
        const pO = KO ? new Float32Array(KO, 0, OO.length / 3) : new Float32Array(OO.length / 3);
        let XO = 0;
        for (let bK = 0, eO = OO.length / 3 - 1; bK < eO; bK++) {
          let KO = OO[3 * bK + 0],
            eO = OO[3 * bK + 1],
            lO = OO[3 * bK + 2];
          KO -= OO[3 * bK + 3], eO -= OO[3 * bK + 4], lO -= OO[3 * bK + 5];
          XO += Math.sqrt(KO * KO + eO * eO + lO * lO), pO[bK + 1] = XO
        }
        return pO
      }
      static SegmentizeSegmentByCount(OO, KO, pO) {
        const XO = [],
          bK = KO.subtract(OO),
          eO = HO.j.WX[0];
        eO.plO(pO);
        const lO = HO.j.WX[1];
        bK.divideToRef(eO, lO);
        let vK = OO.clone();
        XO.push(vK);
        for (let CO = 0; CO < pO; CO++) vK = vK.clone(), XO.push(vK.addInPlace(lO));
        return XO
      }
      static SegmentizeLineBySegmentLength(OO, KO) {
        const pO = OO[0] instanceof HO.o ? AX.GetLineSegments(OO) : "number" === typeof OO[0] ? AX.GetLineSegments(AX.ToVector3Array(OO)) : OO,
          XO = [];
        for (const bK of pO)
          if (bK.length > KO) {
            const OO = AX.SegmentizeSegmentByCount(bK.point1, bK.point2, Math.ceil(bK.length / KO));
            for (const KO of OO) XO.push(KO)
          } else XO.push(bK.point1), XO.push(bK.point2);
        return XO
      }
      static SegmentizeLineBySegmentCount(OO, KO) {
        const pO = "number" === typeof OO[0] ? AX.ToVector3Array(OO) : OO,
          XO = AX.GetLineLength(pO) / KO;
        return AX.SegmentizeLineBySegmentLength(pO, XO)
      }
      static GetLineSegments(OO) {
        const KO = [];
        for (let pO = 0; pO < OO.length - 1; pO++) {
          const XO = OO[pO],
            bK = OO[pO + 1],
            eO = bK.subtract(XO).length();
          KO.push({
            point1: XO,
            point2: bK,
            length: eO
          })
        }
        return KO
      }
      static GetMinMaxSegmentLength(OO) {
        const KO = AX.GetLineSegments(OO).sort((OO => OO.length));
        return {
          min: KO[0].length,
          max: KO[KO.length - 1].length
        }
      }
      static GetPositionOnLineByVisibility(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        const bK = KO * pO;
        let eO = 0,
          lO = 0;
        const vK = OO.length;
        for (let hO = 0; hO < vK; hO++) {
          if (bK <= eO + OO[hO].length) {
            lO = hO;
            break
          }
          eO += OO[hO].length
        }
        const CO = (bK - eO) / OO[lO].length;
        return OO[lO].point2.subtractToRef(OO[lO].point1, HO.j.WX[0]), HO.j.WX[0].scaleToRef(CO, HO.j.WX[1]), XO || HO.j.WX[1].addInPlace(OO[lO].point1), HO.j.WX[1].clone()
      }
      static GetCircleLinePoints(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : OO,
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 2 * Math.PI / KO;
        const eO = [];
        for (let lO = 0; lO <= KO; lO++) eO.push(new HO.o(Math.cos(lO * bK) * OO, Math.sin(lO * bK) * XO, pO));
        return eO
      }
      static GetBezierLinePoints(OO, KO, pO, XO) {
        return VX.h.CreateQuadraticBezier(OO, KO, pO, XO).getPoints().flatMap((OO => [OO.x, OO.y, OO.z]))
      }
      static GetArrowCap(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
          lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0;
        return {
          points: [OO.clone(), OO.add(KO.multiplyByFloats(pO, pO, pO))],
          widths: [XO, bK, eO, lO]
        }
      }
      static GetPointsFromText(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
          eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5];
        const lO = [],
          vK = zb(OO, KO, pO, XO);
        for (const CO of vK) {
          for (const OO of CO.paths) {
            const KO = [],
              pO = OO.getPoints();
            for (const OO of pO) KO.push(OO.x, OO.y, bK);
            lO.push(KO)
          }
          if (eO)
            for (const OO of CO.holes) {
              const KO = [],
                pO = OO.getPoints();
              for (const OO of pO) KO.push(OO.x, OO.y, bK);
              lO.push(KO)
            }
        }
        return lO
      }
      static Color3toRGBAUint8(OO) {
        const KO = new Uint8Array(4 * OO.length);
        for (let pO = 0, XO = 0; pO < OO.length; pO++) KO[XO++] = 255 * OO[pO].r, KO[XO++] = 255 * OO[pO].g, KO[XO++] = 255 * OO[pO].b, KO[XO++] = 255;
        return KO
      }
      static CreateColorsTexture(OO, KO, pO, XO) {
        const bK = XO.qb().getCaps().maxTextureSize ?? 1,
          eO = KO.length > bK ? bK : KO.length,
          lO = Math.ceil(KO.length / bK);
        lO > 1 && (KO = [...KO, ...Array(eO * lO - KO.length).fill(KO[0])]);
        const vK = AX.Color3toRGBAUint8(KO),
          CO = new TO.e(vK, eO, lO, Dp.d.TEXTUREFORMAT_RGBA, XO, !1, !0, pO);
        return CO.name = OO, CO
      }
      static PrepareEmptyColorsTexture(OO) {
        if (!FX.EmptyColorsTexture) {
          const KO = new Uint8Array(4);
          FX.EmptyColorsTexture = new TO.e(KO, 1, 1, Dp.d.TEXTUREFORMAT_RGBA, OO, !1, !1, TO.e.NEAREST_NEAREST), FX.EmptyColorsTexture.name = "grlEmptyColorsTexture", FX.EmptyColorsTexture.cpO.addOnce((() => {
            FX.EmptyColorsTexture = null
          }))
        }
        return FX.EmptyColorsTexture
      }
      static DisposeEmptyColorsTexture() {
        FX.EmptyColorsTexture?.dispose(), FX.EmptyColorsTexture = null
      }
      static BooleanToNumber(OO) {
        return OO ? 1 : 0
      }
    }
    class fX extends SO.e {
      constructor() {
        super(...arguments), this.GREASED_LINE_HAS_COLOR = !1, this.GREASED_LINE_SIZE_ATTENUATION = !1, this.GREASED_LINE_COLOR_DISTRIBUTION_TYPE_LINE = !1, this.GREASED_LINE_RIGHT_HANDED_COORDINATE_SYSTEM = !1, this.GREASED_LINE_CAMERA_FACING = !0, this.GREASED_LINE_USE_OFFSETS = !1
      }
    }
    class dX extends JO.c {
      isCompatible(OO) {
        return !0
      }
      constructor(OO, KO, pO) {
        pO = pO || {
          color: FX.DEFAULT_COLOR
        };
        const XO = new fX;
        XO.GREASED_LINE_HAS_COLOR = !!pO.color && !pO.useColors, XO.GREASED_LINE_SIZE_ATTENUATION = pO.sizeAttenuation ?? !1, XO.GREASED_LINE_COLOR_DISTRIBUTION_TYPE_LINE = 1 === pO.colorDistributionType, XO.GREASED_LINE_RIGHT_HANDED_COORDINATE_SYSTEM = (KO ?? OO.JKO()).useRightHandedSystem, XO.GREASED_LINE_CAMERA_FACING = pO.cameraFacing ?? !0, super(OO, dX.GREASED_LINE_MATERIAL_NAME, 200, XO, !0, !0), this.colorsTexture = null, this._forceGLSL = !1, this._forceGLSL = pO?.forceGLSL || dX.ForceGLSL, this._scene = KO ?? OO.JKO(), this._engine = this._scene.qb(), this._cameraFacing = pO.cameraFacing ?? !0, this.visibility = pO.visibility ?? 1, this.useDash = pO.useDash ?? !1, this.dashRatio = pO.dashRatio ?? .5, this.dashOffset = pO.dashOffset ?? 0, this.width = pO.width ? pO.width : pO.sizeAttenuation ? FX.DEFAULT_WIDTH_ATTENUATED : FX.DEFAULT_WIDTH, this._sizeAttenuation = pO.sizeAttenuation ?? !1, this.colorMode = pO.colorMode ?? 0, this._color = pO.color ?? null, this.useColors = pO.useColors ?? !1, this._colorsDistributionType = pO.colorDistributionType ?? 0, this.colorsSampling = pO.colorsSampling ?? TO.e.NEAREST_NEAREST, this._colors = pO.colors ?? null, this.dashCount = pO.dashCount ?? 1, this.resolution = pO.resolution ?? new HO.m(this._engine.getRenderWidth(), this._engine.getRenderHeight()), pO.colorsTexture ? this.colorsTexture = pO.colorsTexture : this._colors ? this.colorsTexture = AX.CreateColorsTexture(`${OO.name}-colors-texture`, this._colors, this.colorsSampling, this._scene) : (this._color = this._color ?? FX.DEFAULT_COLOR, AX.PrepareEmptyColorsTexture(this._scene)), this._engine.cpO.add((() => {
          AX.DisposeEmptyColorsTexture()
        }))
      }
      getAttributes(OO) {
        OO.push("grl_offsets"), OO.push("grl_widths"), OO.push("grl_colorPointers"), OO.push("grl_counters"), this._cameraFacing ? (OO.push("grl_previousAndSide"), OO.push("grl_nextAndCounters")) : OO.push("grl_slopes")
      }
      getSamplers(OO) {
        OO.push("grl_colors")
      }
      getActiveTextures(OO) {
        this.colorsTexture && OO.push(this.colorsTexture)
      }
      getUniforms() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        const KO = [{
          name: "grl_singleColor",
          size: 3,
          type: "vec3"
        }, {
          name: "grl_textureSize",
          size: 2,
          type: "vec2"
        }, {
          name: "grl_dashOptions",
          size: 4,
          type: "vec4"
        }, {
          name: "grl_colorMode_visibility_colorsWidth_useColors",
          size: 4,
          type: "vec4"
        }];
        return this._cameraFacing && KO.push({
          name: "grl_projection",
          size: 16,
          type: "mat4"
        }, {
          name: "grl_aspect_resolution_lineWidth",
          size: 4,
          type: "vec4"
        }), 1 === OO && KO.push({
          name: "viewProjection",
          size: 16,
          type: "mat4"
        }), {
          ubo: KO,
          vertex: this._cameraFacing && this._isGLSL(OO) ? "\n                    uniform vec4 grl_aspect_resolution_lineWidth;\n                    uniform mat4 grl_projection;\n    " : "",
          fragment: this._isGLSL(OO) ? "\n                    uniform vec4 grl_dashOptions;\n                    uniform vec2 grl_textureSize;\n                    uniform vec4 grl_colorMode_visibility_colorsWidth_useColors;\n                    uniform vec3 grl_singleColor;\n    " : ""
        }
      }
      get isEnabled() {
        return !0
      }
      bindForSubMesh(OO) {
        if (this._cameraFacing) {
          OO.AlO("grl_projection", this._scene.getProjectionMatrix()), this._isGLSL(this._material.shaderLanguage) || OO.AlO("viewProjection", this._scene.getTransformMatrix());
          const KO = HO.j.Vector4[0];
          KO.x = this._aspect, KO.y = this._resolution.x, KO.z = this._resolution.y, KO.w = this.width, OO.updateVector4("grl_aspect_resolution_lineWidth", KO)
        }
        const KO = HO.j.Vector4[0];
        KO.x = AX.BooleanToNumber(this.useDash), KO.y = this._dashArray, KO.z = this.dashOffset, KO.w = this.dashRatio, OO.updateVector4("grl_dashOptions", KO);
        const pO = HO.j.Vector4[1];
        pO.x = this.colorMode, pO.y = this.visibility, pO.z = this.colorsTexture ? this.colorsTexture.getSize().width : 0, pO.w = AX.BooleanToNumber(this.useColors), OO.updateVector4("grl_colorMode_visibility_colorsWidth_useColors", pO), this._color && OO.updateColor3("grl_singleColor", this._color);
        const XO = this.colorsTexture ?? FX.EmptyColorsTexture;
        OO.setTexture("grl_colors", XO), OO.updateFloat2("grl_textureSize", XO?.getSize().width ?? 1, XO?.getSize().height ?? 1)
      }
      prepareDefines(OO, KO, pO) {
        OO.GREASED_LINE_HAS_COLOR = !!this.color && !this.useColors, OO.GREASED_LINE_SIZE_ATTENUATION = this._sizeAttenuation, OO.GREASED_LINE_COLOR_DISTRIBUTION_TYPE_LINE = 1 === this._colorsDistributionType, OO.GREASED_LINE_RIGHT_HANDED_COORDINATE_SYSTEM = KO.useRightHandedSystem, OO.GREASED_LINE_CAMERA_FACING = this._cameraFacing, OO.GREASED_LINE_USE_OFFSETS = !!pO.offsets
      }
      getClassName() {
        return dX.GREASED_LINE_MATERIAL_NAME
      }
      getCustomCode(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return this._isGLSL(KO) ? function(OO, KO) {
          if ("vertex" === OO) {
            const OO = {
              CUSTOM_VERTEX_DEFINITIONS: "\n                attribute float grl_widths;\n                #ifdef GREASED_LINE_USE_OFFSETS\n                    attribute vec3 grl_offsets;\n                #endif\n                attribute float grl_colorPointers;\n                varying float grlCounters;\n                varying float grlColorPointer;\n\n                #ifdef GREASED_LINE_CAMERA_FACING\n                    attribute vec4 grl_previousAndSide;\n                    attribute vec4 grl_nextAndCounters;\n\n                    vec2 grlFix( vec4 i, float aspect ) {\n                        vec2 res = i.xy / i.w;\n                        res.x *= aspect;\n                        return res;\n                    }\n                #else\n                    attribute vec3 grl_slopes;\n                    attribute float grl_counters;\n                #endif\n                ",
              CUSTOM_VERTEX_UPDATE_POSITION: "\n                #ifdef GREASED_LINE_USE_OFFSETS\n                    vec3 grlPositionOffset = grl_offsets;\n                #else\n                    vec3 grlPositionOffset = vec3(0.);\n                #endif\n\n                #ifdef GREASED_LINE_CAMERA_FACING\n                    positionUpdated += grlPositionOffset;\n                #else\n                    positionUpdated = (positionUpdated + grlPositionOffset) + (grl_slopes * grl_widths);\n                #endif\n                ",
              CUSTOM_VERTEX_MAIN_END: "\n                grlColorPointer = grl_colorPointers;\n\n                #ifdef GREASED_LINE_CAMERA_FACING\n\n                    float grlAspect = grl_aspect_resolution_lineWidth.x;\n                    float grlBaseWidth = grl_aspect_resolution_lineWidth.w;\n\n                    vec3 grlPrevious = grl_previousAndSide.xyz;\n                    float grlSide = grl_previousAndSide.w;\n\n                    vec3 grlNext = grl_nextAndCounters.xyz;\n                    grlCounters = grl_nextAndCounters.w;\n                    float grlWidth = grlBaseWidth * grl_widths;\n                    \n                    vec3 worldDir = normalize(grlNext - grlPrevious);\n                    vec3 nearPosition = positionUpdated + (worldDir * 0.01);\n                    mat4 grlMatrix = viewProjection * finalWorld;\n                    vec4 grlFinalPosition = grlMatrix * vec4(positionUpdated , 1.0);\n                    vec4 screenNearPos = grlMatrix * vec4(nearPosition, 1.0);\n                    vec2 grlLinePosition = grlFix(grlFinalPosition, grlAspect);\n                    vec2 grlLineNearPosition = grlFix(screenNearPos, grlAspect);\n                    vec2 grlDir = normalize(grlLineNearPosition - grlLinePosition);\n\n                    vec4 grlNormal = vec4(-grlDir.y, grlDir.x, 0., 1.);\n\n                    #ifdef GREASED_LINE_RIGHT_HANDED_COORDINATE_SYSTEM\n                        grlNormal.xy *= -.5 * grlWidth;\n                    #else\n                        grlNormal.xy *= .5 * grlWidth;\n                    #endif\n\n                    grlNormal *= grl_projection;\n\n                    #ifdef GREASED_LINE_SIZE_ATTENUATION\n                        grlNormal.xy *= grlFinalPosition.w;\n                        grlNormal.xy /= (vec4(grl_aspect_resolution_lineWidth.yz, 0., 1.) * grl_projection).xy;\n                    #endif\n\n                    grlFinalPosition.xy += grlNormal.xy * grlSide;\n                    gl_Position = grlFinalPosition;\n\n                    vPositionW = vec3(grlFinalPosition);\n                #else\n                    grlCounters = grl_counters;\n                #endif\n                "
            };
            return KO && (OO["!gl_Position\\=viewProjection\\*worldPos;"] = "//"), OO
          }
          return "fragment" === OO ? {
            CUSTOM_FRAGMENT_DEFINITIONS: "\n                    #ifdef PBR\n                         #define grlFinalColor finalColor\n                    #else\n                         #define grlFinalColor color\n                    #endif\n\n                    varying float grlCounters;\n                    varying float grlColorPointer;\n                    uniform sampler2D grl_colors;\n                ",
            CUSTOM_FRAGMENT_BEFORE_FRAGCOLOR: "\n                    float grlColorMode = grl_colorMode_visibility_colorsWidth_useColors.x;\n                    float grlVisibility = grl_colorMode_visibility_colorsWidth_useColors.y;\n                    float grlColorsWidth = grl_colorMode_visibility_colorsWidth_useColors.z;\n                    float grlUseColors = grl_colorMode_visibility_colorsWidth_useColors.w;\n\n                    float grlUseDash = grl_dashOptions.x;\n                    float grlDashArray = grl_dashOptions.y;\n                    float grlDashOffset = grl_dashOptions.z;\n                    float grlDashRatio = grl_dashOptions.w;\n\n                    grlFinalColor.a *= step(grlCounters, grlVisibility);\n                    if(grlFinalColor.a == 0.) discard;\n\n                    if(grlUseDash == 1.){\n                        grlFinalColor.a *= ceil(mod(grlCounters + grlDashOffset, grlDashArray) - (grlDashArray * grlDashRatio));\n                        if (grlFinalColor.a == 0.) discard;\n                    }\n\n                    #ifdef GREASED_LINE_HAS_COLOR\n                        if (grlColorMode == 0.) {\n                            grlFinalColor.rgb = grl_singleColor;\n                        } else if (grlColorMode == 1.) {\n                            grlFinalColor.rgb += grl_singleColor;\n                        } else if (grlColorMode == 2.) {\n                            grlFinalColor.rgb *= grl_singleColor;\n                        }\n                    #else\n                        if (grlUseColors == 1.) {\n                            #ifdef GREASED_LINE_COLOR_DISTRIBUTION_TYPE_LINE\n                                vec4 grlColor = texture2D(grl_colors, vec2(grlCounters, 0.), 0.);\n                            #else\n                                vec2 lookup = vec2(fract(grlColorPointer / grl_textureSize.x), 1.0 - floor(grlColorPointer / grl_textureSize.x) / max(grl_textureSize.y - 1.0, 1.0));\n                                vec4 grlColor = texture2D(grl_colors, lookup, 0.0);\n                            #endif\n                            if (grlColorMode == 0.) {\n                                grlFinalColor = grlColor;\n                            } else if (grlColorMode == 1.) {\n                                grlFinalColor += grlColor;\n                            } else if (grlColorMode == 2.) {\n                                grlFinalColor *= grlColor;\n                            }\n                        }\n                    #endif\n                "
          } : null
        }(OO, this._cameraFacing) : function(OO, KO) {
          if ("vertex" === OO) {
            const OO = {
              CUSTOM_VERTEX_DEFINITIONS: "\n                attribute grl_widths: f32;\n                attribute grl_colorPointers: f32;\n                varying grlCounters: f32;\n                varying grlColorPointer: f32;\n\n                #ifdef GREASED_LINE_USE_OFFSETS\n                    attribute grl_offsets: vec3f;   \n                #endif\n\n                #ifdef GREASED_LINE_CAMERA_FACING\n                    attribute grl_previousAndSide : vec4f;\n                    attribute grl_nextAndCounters : vec4f;\n\n                    fn grlFix(i: vec4f, aspect: f32) -> vec2f {\n                        var res = i.xy / i.w;\n                        res.x *= aspect;\n                        return res;\n                    }\n                #else\n                    attribute grl_slopes: f32;\n                    attribute grl_counters: f32;\n                #endif\n\n\n                ",
              CUSTOM_VERTEX_UPDATE_POSITION: "\n                #ifdef GREASED_LINE_USE_OFFSETS\n                    var grlPositionOffset: vec3f = input.grl_offsets;\n                #else\n                    var grlPositionOffset = vec3f(0.);\n                #endif\n\n                #ifdef GREASED_LINE_CAMERA_FACING\n                    positionUpdated += grlPositionOffset;\n                #else\n                    positionUpdated = (positionUpdated + grlPositionOffset) + (input.grl_slopes * input.grl_widths);\n                #endif\n                ",
              CUSTOM_VERTEX_MAIN_END: "\n                vertexOutputs.grlColorPointer = input.grl_colorPointers;\n\n                #ifdef GREASED_LINE_CAMERA_FACING\n\n                    let grlAspect: f32 = uniforms.grl_aspect_resolution_lineWidth.x;\n                    let grlBaseWidth: f32 = uniforms.grl_aspect_resolution_lineWidth.w;\n\n                    let grlPrevious: vec3f = input.grl_previousAndSide.xyz;\n                    let grlSide: f32 = input.grl_previousAndSide.w;\n\n                    let grlNext: vec3f = input.grl_nextAndCounters.xyz;\n                    vertexOutputs.grlCounters = input.grl_nextAndCounters.w;\n\n                    let grlWidth: f32 = grlBaseWidth * input.grl_widths;\n\n                    let worldDir: vec3f = normalize(grlNext - grlPrevious);\n                    let nearPosition: vec3f = positionUpdated + (worldDir * 0.01);\n                    let grlMatrix: mat4x4f = uniforms.viewProjection * finalWorld;\n                    let grlFinalPosition: vec4f = grlMatrix * vec4f(positionUpdated, 1.0); \n                    let screenNearPos: vec4f = grlMatrix * vec4(nearPosition, 1.0);\n                    let grlLinePosition: vec2f = grlFix(grlFinalPosition, grlAspect);\n                    let grlLineNearPosition: vec2f = grlFix(screenNearPos, grlAspect);\n                    let grlDir: vec2f = normalize(grlLineNearPosition - grlLinePosition);\n\n                    var grlNormal: vec4f = vec4f(-grlDir.y, grlDir.x, 0.0, 1.0);\n\n                    let grlHalfWidth: f32 = 0.5 * grlWidth;\n                    #if defined(GREASED_LINE_RIGHT_HANDED_COORDINATE_SYSTEM)\n                        grlNormal.x *= -grlHalfWidth;\n                        grlNormal.y *= -grlHalfWidth;\n                    #else\n                        grlNormal.x *= grlHalfWidth;\n                        grlNormal.y *= grlHalfWidth;\n                    #endif\n\n                    grlNormal *= uniforms.grl_projection;\n\n                    #if defined(GREASED_LINE_SIZE_ATTENUATION)\n                        grlNormal.x *= grlFinalPosition.w;\n                        grlNormal.y *= grlFinalPosition.w;\n\n                        let pr = vec4f(uniforms.grl_aspect_resolution_lineWidth.yz, 0.0, 1.0) * uniforms.grl_projection;\n                        grlNormal.x /= pr.x;\n                        grlNormal.y /= pr.y;\n                    #endif\n\n                    vertexOutputs.position = vec4f(grlFinalPosition.xy + grlNormal.xy * grlSide, grlFinalPosition.z, grlFinalPosition.w);\n                    vertexOutputs.vPositionW = vertexOutputs.position.xyz;\n                \n                #else\n                    vertexOutputs.grlCounters = input.grl_counters;\n                #endif\n                "
            };
            return KO && (OO["!vertexOutputs\\.position\\s=\\sscene\\.viewProjection\\s\\*\\sworldPos;"] = "//"), OO
          }
          return "fragment" === OO ? {
            CUSTOM_FRAGMENT_DEFINITIONS: "\n                    #ifdef PBR\n                         #define grlFinalColor finalColor\n                    #else\n                         #define grlFinalColor color\n                    #endif\n\n                    varying grlCounters: f32;\n                    varying grlColorPointer: 32;\n\n                    var grl_colors: texture_2d<f32>;\n                    var grl_colorsSampler: sampler;\n                ",
            CUSTOM_FRAGMENT_BEFORE_FRAGCOLOR: "\n                    let grlColorMode: f32 = uniforms.grl_colorMode_visibility_colorsWidth_useColors.x;\n                    let grlVisibility: f32 = uniforms.grl_colorMode_visibility_colorsWidth_useColors.y;\n                    let grlColorsWidth: f32 = uniforms.grl_colorMode_visibility_colorsWidth_useColors.z;\n                    let grlUseColors: f32 = uniforms.grl_colorMode_visibility_colorsWidth_useColors.w;\n\n                    let grlUseDash: f32 = uniforms.grl_dashOptions.x;\n                    let grlDashArray: f32 = uniforms.grl_dashOptions.y;\n                    let grlDashOffset: f32 = uniforms.grl_dashOptions.z;\n                    let grlDashRatio: f32 = uniforms.grl_dashOptions.w;\n\n                    grlFinalColor.a *= step(fragmentInputs.grlCounters, grlVisibility);\n                    if (grlFinalColor.a == 0.0) {\n                        discard;\n                    }\n\n                    if (grlUseDash == 1.0) {\n                        let dashPosition = (fragmentInputs.grlCounters + grlDashOffset) % grlDashArray;\n                        grlFinalColor.a *= ceil(dashPosition - (grlDashArray * grlDashRatio));\n\n                        if (grlFinalColor.a == 0.0) {\n                            discard;\n                        }\n                    }\n\n                    #ifdef GREASED_LINE_HAS_COLOR\n                        if (grlColorMode == 0.) {\n                            grlFinalColor = vec4f(uniforms.grl_singleColor, grlFinalColor.a);\n                        } else if (grlColorMode == 1.) {\n                            grlFinalColor += vec4f(uniforms.grl_singleColor, grlFinalColor.a);\n                        } else if (grlColorMode == 2.) {\n                            grlFinalColor *= vec4f(uniforms.grl_singleColor, grlFinalColor.a);\n                        }\n                    #else\n                        if (grlUseColors == 1.) {\n                            #ifdef GREASED_LINE_COLOR_DISTRIBUTION_TYPE_LINE\n                                let grlColor: vec4f = textureSample(grl_colors, grl_colorsSampler, vec2f(fragmentInputs.grlCounters, 0.));\n                            #else\n                                let lookup: vec2f = vec2(fract(fragmentInputs.grlColorPointer / uniforms.grl_textureSize.x), 1.0 - floor(fragmentInputs.grlColorPointer / uniforms.grl_textureSize.x) / max(uniforms.grl_textureSize.y - 1.0, 1.0));\n                                let grlColor: vec4f = textureSample(grl_colors, grl_colorsSampler, lookup);\n                            #endif\n                            if (grlColorMode == 0.) {\n                                grlFinalColor = grlColor;\n                            } else if (grlColorMode == 1.) {\n                                grlFinalColor += grlColor;\n                            } else if (grlColorMode == 2.) {\n                                grlFinalColor *= grlColor;\n                            }\n                        }\n                    #endif\n\n\n                "
          } : null
        }(OO, this._cameraFacing)
      }
      dispose() {
        this.colorsTexture?.dispose(), super.dispose()
      }
      get colors() {
        return this._colors
      }
      set colors(OO) {
        this.setColors(OO)
      }
      setColors(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = this._colors?.length ?? 0;
        if (this._colors = OO, null !== OO && 0 !== OO.length) {
          if (!KO || pO)
            if (this.colorsTexture && XO === OO.length && !pO) {
              const KO = AX.Color3toRGBAUint8(OO);
              this.colorsTexture.update(KO)
            } else this.colorsTexture?.dispose(), this.colorsTexture = AX.CreateColorsTexture(`${this._material.name}-colors-texture`, OO, this.colorsSampling, this._scene)
        } else this.colorsTexture?.dispose()
      }
      updateLazy() {
        this._colors && this.setColors(this._colors, !1, !0)
      }
      get dashCount() {
        return this._dashCount
      }
      set dashCount(OO) {
        this._dashCount = OO, this._dashArray = 1 / OO
      }
      get sizeAttenuation() {
        return this._sizeAttenuation
      }
      set sizeAttenuation(OO) {
        this._sizeAttenuation = OO, this.markAllDefinesAsDirty()
      }
      get color() {
        return this._color
      }
      set color(OO) {
        this.setColor(OO)
      }
      setColor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        null === this._color && null !== OO || null !== this._color && null === OO ? (this._color = OO, KO || this.markAllDefinesAsDirty()) : this._color = OO
      }
      get colorsDistributionType() {
        return this._colorsDistributionType
      }
      set colorsDistributionType(OO) {
        this._colorsDistributionType = OO, this.markAllDefinesAsDirty()
      }
      get resolution() {
        return this._resolution
      }
      set resolution(OO) {
        this._aspect = OO.x / OO.y, this._resolution = OO
      }
      serialize() {
        const OO = super.serialize(),
          KO = {
            colorDistributionType: this._colorsDistributionType,
            colorsSampling: this.colorsSampling,
            colorMode: this.colorMode,
            dashCount: this._dashCount,
            dashOffset: this.dashOffset,
            dashRatio: this.dashRatio,
            resolution: this._resolution,
            sizeAttenuation: this._sizeAttenuation,
            useColors: this.useColors,
            useDash: this.useDash,
            visibility: this.visibility,
            width: this.width
          };
        return this._colors && (KO.colors = this._colors), this._color && (KO.color = this._color), OO.greasedLineMaterialOptions = KO, OO
      }
      parse(OO, KO, pO) {
        super.parse(OO, KO, pO);
        const XO = OO.greasedLineMaterialOptions;
        this.colorsTexture?.dispose(), XO.color && this.setColor(XO.color, !0), XO.colorDistributionType && (this.colorsDistributionType = XO.colorDistributionType), XO.colors && (this.colors = XO.colors), XO.colorsSampling && (this.colorsSampling = XO.colorsSampling), XO.colorMode && (this.colorMode = XO.colorMode), XO.useColors && (this.useColors = XO.useColors), XO.visibility && (this.visibility = XO.visibility), XO.useDash && (this.useDash = XO.useDash), XO.dashCount && (this.dashCount = XO.dashCount), XO.dashRatio && (this.dashRatio = XO.dashRatio), XO.dashOffset && (this.dashOffset = XO.dashOffset), XO.width && (this.width = XO.width), XO.sizeAttenuation && (this.sizeAttenuation = XO.sizeAttenuation), XO.resolution && (this.resolution = XO.resolution), this.colors ? this.colorsTexture = AX.CreateColorsTexture(`${this._material.name}-colors-texture`, this.colors, this.colorsSampling, KO) : AX.PrepareEmptyColorsTexture(KO), this.markAllDefinesAsDirty()
      }
      copyTo(OO) {
        const KO = OO;
        KO.colorsTexture?.dispose(), this._colors && (KO.colorsTexture = AX.CreateColorsTexture(`${KO._material.name}-colors-texture`, this._colors, KO.colorsSampling, this._scene)), KO.setColor(this.color, !0), KO.colorsDistributionType = this.colorsDistributionType, KO.colorsSampling = this.colorsSampling, KO.colorMode = this.colorMode, KO.useColors = this.useColors, KO.visibility = this.visibility, KO.useDash = this.useDash, KO.dashCount = this.dashCount, KO.dashRatio = this.dashRatio, KO.dashOffset = this.dashOffset, KO.width = this.width, KO.sizeAttenuation = this.sizeAttenuation, KO.resolution = this.resolution, KO.markAllDefinesAsDirty()
      }
      _isGLSL(OO) {
        return 0 === OO || this._forceGLSL
      }
    }
    dX.GREASED_LINE_MATERIAL_NAME = "GreasedLinePluginMaterial", dX.ForceGLSL = !1;
    var TX = pO(38502),
      NX = pO(38511),
      IX = pO(37055),
      yb = pO(38572),
      gb = pO(37896);
    class uX extends yb.m {
      constructor(OO, KO, XO) {
        const bK = KO.qb(),
          eO = bK.isWebGPU && !(XO.forceGLSL || uX.ForceGLSL),
          lO = ["COLOR_DISTRIBUTION_TYPE_LINE 1.", "COLOR_DISTRIBUTION_TYPE_SEGMENT 0.", "COLOR_MODE_SET 0.", "COLOR_MODE_ADD 1.", "COLOR_MODE_MULTIPLY 2."];
        KO.useRightHandedSystem && lO.push("GREASED_LINE_RIGHT_HANDED_COORDINATE_SYSTEM");
        const vK = ["position", "grl_widths", "grl_offsets", "grl_colorPointers"];
        XO.cameraFacing ? (lO.push("GREASED_LINE_CAMERA_FACING"), vK.push("grl_previousAndSide", "grl_nextAndCounters")) : (vK.push("grl_slopes"), vK.push("grl_counters"));
        const CO = ["grlColorsWidth", "grlUseColors", "grlWidth", "grlColor", "grl_colorModeAndColorDistributionType", "grlResolution", "grlAspect", "grlAizeAttenuation", "grlDashArray", "grlDashOffset", "grlDashRatio", "grlUseDash", "grlVisibility", "grlColors"];
        if (eO || CO.push("world", "viewProjection", "view", "projection"), super(OO, KO, {
            vertex: "greasedLine",
            fragment: "greasedLine"
          }, {
            uniformBuffers: eO ? ["Scene", "Mesh"] : void 0,
            attributes: vK,
            uniforms: CO,
            samplers: eO ? [] : ["grlColors"],
            defines: lO,
            extraInitializationsAsync: async () => {
              eO ? await Promise.all([pO.e(314).then((() => pO(59762))), pO.e(371).then((() => pO(59768)))]) : await Promise.all([pO.e(307).then((() => pO(59772))), pO.e(372).then((() => pO(59779)))])
            },
            shaderLanguage: eO ? 1 : 0
          }), this._color = GO.e.White(), this._colorsDistributionType = 0, this._colorsTexture = null, XO = XO || {
            color: FX.DEFAULT_COLOR
          }, this.visibility = XO.visibility ?? 1, this.useDash = XO.useDash ?? !1, this.dashRatio = XO.dashRatio ?? .5, this.dashOffset = XO.dashOffset ?? 0, this.dashCount = XO.dashCount ?? 1, this.width = XO.width ? XO.width : XO.sizeAttenuation && XO.cameraFacing ? FX.DEFAULT_WIDTH_ATTENUATED : FX.DEFAULT_WIDTH, this.sizeAttenuation = XO.sizeAttenuation ?? !1, this.color = XO.color ?? GO.e.White(), this.useColors = XO.useColors ?? !1, this.colorsDistributionType = XO.colorDistributionType ?? 0, this.colorsSampling = XO.colorsSampling ?? TO.e.NEAREST_NEAREST, this.colorMode = XO.colorMode ?? 0, this._colors = XO.colors ?? null, this._cameraFacing = XO.cameraFacing ?? !0, this.resolution = XO.resolution ?? new HO.m(bK.getRenderWidth(), bK.getRenderHeight()), XO.colorsTexture ? this.colorsTexture = XO.colorsTexture : this._colors ? this.colorsTexture = AX.CreateColorsTexture(`${this.name}-colors-texture`, this._colors, this.colorsSampling, KO) : (this._color = this._color ?? FX.DEFAULT_COLOR, this.colorsTexture = AX.PrepareEmptyColorsTexture(KO)), eO) {
          const OO = new gb.e;
          OO.setParameters(), OO.samplingMode = this.colorsSampling, this.setTextureSampler("grlColorsSampler", OO)
        }
        bK.cpO.add((() => {
          AX.DisposeEmptyColorsTexture()
        }))
      }
      dispose() {
        this._colorsTexture && this._colorsTexture !== FX.EmptyColorsTexture && this._colorsTexture.dispose(), super.dispose()
      }
      _setColorModeAndColorDistributionType() {
        this.setVector2("grl_colorModeAndColorDistributionType", new HO.m(this._colorMode, this._colorsDistributionType))
      }
      updateLazy() {
        this._colors && this.setColors(this._colors, !1, !0)
      }
      get colors() {
        return this._colors
      }
      set colors(OO) {
        this.setColors(OO)
      }
      setColors(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = this._colors?.length ?? 0;
        if (this._colors = OO, null !== OO && 0 !== OO.length) {
          if (!KO || pO)
            if (this._colorsTexture && XO === OO.length && !pO) {
              const KO = AX.Color3toRGBAUint8(OO);
              this._colorsTexture.update(KO)
            } else this._colorsTexture && this._colorsTexture !== FX.EmptyColorsTexture && this._colorsTexture.dispose(), this.colorsTexture = AX.CreateColorsTexture(`${this.name}-colors-texture`, OO, this.colorsSampling, this.JKO())
        } else {
          this._colorsTexture && this._colorsTexture !== FX.EmptyColorsTexture && this._colorsTexture.dispose();
          const OO = this.JKO();
          OO && (this.colorsTexture = AX.PrepareEmptyColorsTexture(OO))
        }
      }
      get colorsTexture() {
        return this._colorsTexture ?? null
      }
      set colorsTexture(OO) {
        this._colorsTexture = OO, this.setFloat("grlColorsWidth", this._colorsTexture.getSize().width), this.setTexture("grlColors", this._colorsTexture)
      }
      get width() {
        return this._width
      }
      set width(OO) {
        this._width = OO, this.setFloat("grlWidth", OO)
      }
      get useColors() {
        return this._useColors
      }
      set useColors(OO) {
        this._useColors = OO, this.setFloat("grlUseColors", AX.BooleanToNumber(OO))
      }
      get colorsSampling() {
        return this._colorsSampling
      }
      set colorsSampling(OO) {
        this._colorsSampling = OO
      }
      get visibility() {
        return this._visibility
      }
      set visibility(OO) {
        this._visibility = OO, this.setFloat("grlVisibility", OO)
      }
      get useDash() {
        return this._useDash
      }
      set useDash(OO) {
        this._useDash = OO, this.setFloat("grlUseDash", AX.BooleanToNumber(OO))
      }
      get dashOffset() {
        return this._dashOffset
      }
      set dashOffset(OO) {
        this._dashOffset = OO, this.setFloat("grlDashOffset", OO)
      }
      get dashRatio() {
        return this._dashRatio
      }
      set dashRatio(OO) {
        this._dashRatio = OO, this.setFloat("grlDashRatio", OO)
      }
      get dashCount() {
        return this._dashCount
      }
      set dashCount(OO) {
        this._dashCount = OO, this._dashArray = 1 / OO, this.setFloat("grlDashArray", this._dashArray)
      }
      get sizeAttenuation() {
        return this._sizeAttenuation
      }
      set sizeAttenuation(OO) {
        this._sizeAttenuation = OO, this.setFloat("grlSizeAttenuation", AX.BooleanToNumber(OO))
      }
      get color() {
        return this._color
      }
      set color(OO) {
        this.setColor(OO)
      }
      setColor(OO) {
        OO = OO ?? FX.DEFAULT_COLOR, this._color = OO, this.setColor3("grlColor", OO)
      }
      get colorsDistributionType() {
        return this._colorsDistributionType
      }
      set colorsDistributionType(OO) {
        this._colorsDistributionType = OO, this._setColorModeAndColorDistributionType()
      }
      get colorMode() {
        return this._colorMode
      }
      set colorMode(OO) {
        this._colorMode = OO, this._setColorModeAndColorDistributionType()
      }
      get resolution() {
        return this._resolution
      }
      set resolution(OO) {
        this._resolution = OO, this.setVector2("grlResolution", OO), this.setFloat("grlAspect", OO.x / OO.y)
      }
      serialize() {
        const OO = super.serialize(),
          KO = {
            colorDistributionType: this._colorsDistributionType,
            colorsSampling: this._colorsSampling,
            colorMode: this._colorMode,
            color: this._color,
            dashCount: this._dashCount,
            dashOffset: this._dashOffset,
            dashRatio: this._dashRatio,
            resolution: this._resolution,
            sizeAttenuation: this._sizeAttenuation,
            useColors: this._useColors,
            useDash: this._useDash,
            visibility: this._visibility,
            width: this._width,
            cameraFacing: this._cameraFacing
          };
        return this._colors && (KO.colors = this._colors), OO.greasedLineMaterialOptions = KO, OO
      }
      parse(OO, KO, pO) {
        const XO = OO.greasedLineMaterialOptions;
        this._colorsTexture?.dispose(), XO.color && (this.color = XO.color), XO.colorDistributionType && (this.colorsDistributionType = XO.colorDistributionType), XO.colorsSampling && (this.colorsSampling = XO.colorsSampling), XO.colorMode && (this.colorMode = XO.colorMode), XO.useColors && (this.useColors = XO.useColors), XO.visibility && (this.visibility = XO.visibility), XO.useDash && (this.useDash = XO.useDash), XO.dashCount && (this.dashCount = XO.dashCount), XO.dashRatio && (this.dashRatio = XO.dashRatio), XO.dashOffset && (this.dashOffset = XO.dashOffset), XO.width && (this.width = XO.width), XO.sizeAttenuation && (this.sizeAttenuation = XO.sizeAttenuation), XO.resolution && (this.resolution = XO.resolution), XO.colors ? this.colorsTexture = AX.CreateColorsTexture(`${this.name}-colors-texture`, XO.colors, this.colorsSampling, this.JKO()) : this.colorsTexture = AX.PrepareEmptyColorsTexture(KO), this._cameraFacing = XO.cameraFacing ?? !0, this.setDefine("GREASED_LINE_CAMERA_FACING", this._cameraFacing)
      }
    }
    var EX, jb, YX;
    uX.ForceGLSL = !1,
      function(OO) {
        OO[OO.POINTS_MODE_POINTS = 0] = "POINTS_MODE_POINTS", OO[OO.POINTS_MODE_PATHS = 1] = "POINTS_MODE_PATHS"
      }(EX || (EX = {})),
      function(OO) {
        OO[OO.FACES_MODE_SINGLE_SIDED = 0] = "FACES_MODE_SINGLE_SIDED", OO[OO.FACES_MODE_SINGLE_SIDED_NO_BACKFACE_CULLING = 1] = "FACES_MODE_SINGLE_SIDED_NO_BACKFACE_CULLING", OO[OO.FACES_MODE_DOUBLE_SIDED = 2] = "FACES_MODE_DOUBLE_SIDED"
      }(jb || (jb = {})),
      function(OO) {
        OO[OO.AUTO_DIRECTIONS_FROM_FIRST_SEGMENT = 0] = "AUTO_DIRECTIONS_FROM_FIRST_SEGMENT", OO[OO.AUTO_DIRECTIONS_FROM_ALL_SEGMENTS = 1] = "AUTO_DIRECTIONS_FROM_ALL_SEGMENTS", OO[OO.AUTO_DIRECTIONS_ENHANCED = 2] = "AUTO_DIRECTIONS_ENHANCED", OO[OO.AUTO_DIRECTIONS_FACE_TO = 3] = "AUTO_DIRECTIONS_FACE_TO", OO[OO.AUTO_DIRECTIONS_NONE = 99] = "AUTO_DIRECTIONS_NONE"
      }(YX || (YX = {}));
    class wX extends TX.c {
      constructor(OO, KO, pO) {
        super(OO, KO, null, null, !1, !1), this.name = OO, this._options = pO, this._lazy = !1, this._updatable = !1, this._engine = KO.qb(), this._lazy = pO.lazy ?? !1, this._updatable = pO.updatable ?? !1, this._vertexPositions = [], this._indices = [], this._uvs = [], this._points = [], this._colorPointers = pO.colorPointers ?? [], this._widths = pO.widths ?? new Array(pO.points.length).fill(1)
      }
      getClassName() {
        return "GreasedLineMesh"
      }
      _updateWidthsWithValue(OO) {
        let KO = 0;
        for (const XO of this._points) KO += XO.length;
        const pO = KO / 3 * 2 - this._widths.length;
        for (let XO = 0; XO < pO; XO++) this._widths.push(OO)
      }
      updateLazy() {
        this._setPoints(this._points), this._options.colorPointers || this._updateColorPointers(), this._createVertexBuffers(this._options.ribbonOptions?.smoothShading), !this.kb && this.refreshBoundingInfo(), this.greasedLineMaterial?.updateLazy()
      }
      addPoints(OO, KO) {
        for (const pO of OO) this._points.push(pO);
        this._lazy || this.setPoints(this._points, KO)
      }
      dispose(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        super.dispose(OO, KO)
      }
      isLazy() {
        return this._lazy
      }
      get uvs() {
        return this._uvs
      }
      set uvs(OO) {
        this._uvs = OO instanceof Float32Array ? OO : new Float32Array(OO), this._createVertexBuffers()
      }
      get offsets() {
        return this._offsets
      }
      set offsets(OO) {
        this.material instanceof uX && this.material.setDefine("GREASED_LINE_USE_OFFSETS", OO?.length > 0), this._offsets = OO, this._offsetsBuffer ? this._offsetsBuffer.update(OO) : this._createOffsetsBuffer(OO)
      }
      get widths() {
        return this._widths
      }
      set widths(OO) {
        this._widths = OO, this._lazy || this._widthsBuffer && this._widthsBuffer.update(OO)
      }
      get colorPointers() {
        return this._colorPointers
      }
      set colorPointers(OO) {
        this._colorPointers = OO, this._lazy || this._colorPointersBuffer && this._colorPointersBuffer.update(OO)
      }
      get greasedLineMaterial() {
        if (this.material && this.material instanceof uX) return this.material;
        const OO = this.material?.pluginManager?.getPlugin(dX.GREASED_LINE_MATERIAL_NAME);
        return OO || void 0
      }
      get points() {
        const OO = [];
        return IX.d.DeepCopy(this._points, OO), OO
      }
      setPoints(OO, KO) {
        this._points = AX.ConvertPoints(OO, KO?.pointsOptions ?? this._options.pointsOptions), this._updateWidths(), KO?.colorPointers || this._updateColorPointers(), this._setPoints(this._points, KO)
      }
      _initGreasedLine() {
        this._vertexPositions = [], this._indices = [], this._uvs = []
      }
      _createLineOptions() {
        return {
          points: this._points,
          colorPointers: this._colorPointers,
          lazy: this._lazy,
          updatable: this._updatable,
          uvs: this._uvs,
          widths: this._widths,
          ribbonOptions: this._options.ribbonOptions
        }
      }
      serialize(OO) {
        super.serialize(OO), OO.type = this.getClassName(), OO.lineOptions = this._createLineOptions()
      }
      _createVertexBuffers() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = new NX.e;
        return KO.positions = this._vertexPositions, KO.indices = this._indices, KO.uvs = this._uvs, OO && (KO.normals = [], NX.e.ComputeNormals(this._vertexPositions, this._indices, KO.normals)), KO.applyToMesh(this, this._options.updatable), KO
      }
      _createOffsetsBuffer(OO) {
        const KO = this._scene.qb(),
          pO = new RO.b(KO, OO, this._updatable, 3);
        this.setVerticesBuffer(pO.createVertexBuffer("grl_offsets", 0, 3)), this._offsetsBuffer = pO
      }
    }
    class ib {
      constructor(OO, KO) {
        this._indicesAccessorMap = new Map, this._vertexBufferViewMap = new Map, this._vertexAccessorMap = new Map, this._remappedBufferView = new Map, this._meshMorphTargetMap = new Map, this._vertexMapColorAlpha = new Map, this._exportedNodes = new Set, this._meshMap = new Map, this.convertedToRightHandedBuffers = new Map, this.convertToRightHanded = OO, this.wasAddedByNoopNode = KO
      }
      getIndicesAccessor(OO, KO, pO, XO, bK) {
        return this._indicesAccessorMap.get(OO)?.get(KO)?.get(pO)?.get(XO)?.get(bK)
      }
      setIndicesAccessor(OO, KO, pO, XO, bK, eO) {
        let lO = this._indicesAccessorMap.get(OO);
        lO || (lO = new Map, this._indicesAccessorMap.set(OO, lO));
        let vK = lO.get(KO);
        vK || (vK = new Map, lO.set(KO, vK));
        let CO = vK.get(pO);
        CO || (CO = new Map, vK.set(pO, CO));
        let hO = CO.get(XO);
        hO || (hO = new Map, CO.set(XO, hO)), hO.set(bK, eO)
      }
      pushExportedNode(OO) {
        this._exportedNodes.has(OO) || this._exportedNodes.add(OO)
      }
      getNodesSet() {
        return this._exportedNodes
      }
      getVertexBufferView(OO) {
        return this._vertexBufferViewMap.get(OO)
      }
      setVertexBufferView(OO, KO) {
        this._vertexBufferViewMap.set(OO, KO)
      }
      setRemappedBufferView(OO, KO, pO) {
        this._remappedBufferView.set(OO, new Map), this._remappedBufferView.get(OO).set(KO, pO)
      }
      getRemappedBufferView(OO, KO) {
        return this._remappedBufferView.get(OO)?.get(KO)
      }
      getVertexAccessor(OO, KO, pO) {
        return this._vertexAccessorMap.get(OO)?.get(KO)?.get(pO)
      }
      setVertexAccessor(OO, KO, pO, XO) {
        let bK = this._vertexAccessorMap.get(OO);
        bK || (bK = new Map, this._vertexAccessorMap.set(OO, bK));
        let eO = bK.get(KO);
        eO || (eO = new Map, bK.set(KO, eO)), eO.set(pO, XO)
      }
      hasVertexColorAlpha(OO) {
        return this._vertexMapColorAlpha.get(OO) || !1
      }
      setHasVertexColorAlpha(OO, KO) {
        return this._vertexMapColorAlpha.set(OO, KO)
      }
      getMesh(OO) {
        return this._meshMap.get(OO)
      }
      setMesh(OO, KO) {
        this._meshMap.set(OO, KO)
      }
      bindMorphDataToMesh(OO, KO) {
        const pO = this._meshMorphTargetMap.get(OO) || [];
        this._meshMorphTargetMap.set(OO, pO), -1 === pO.indexOf(KO) && pO.push(KO)
      }
      getMorphTargetsFromMesh(OO) {
        return this._meshMorphTargetMap.get(OO)
      }
    }
    class rb {
      _ApplyExtension(OO, KO, pO, XO) {
        if (pO >= KO.length) return Promise.resolve(OO);
        const bK = XO(KO[pO], OO);
        return bK ? bK.then((async OO => OO ? await this._ApplyExtension(OO, KO, pO + 1, XO) : null)) : this._ApplyExtension(OO, KO, pO + 1, XO)
      }
      _ApplyExtensions(OO, KO) {
        const pO = [];
        for (const XO of rb._ExtensionNames) pO.push(this._extensions[XO]);
        return this._ApplyExtension(OO, pO, 0, KO)
      }
      _extensionsPostExportNodeAsync(OO, KO, pO, XO, bK) {
        return this._ApplyExtensions(KO, ((KO, eO) => KO.postExportNodeAsync && KO.postExportNodeAsync(OO, eO, pO, XO, bK, this._bufferManager)))
      }
      _extensionsPostExportMaterialAsync(OO, KO, pO) {
        return this._ApplyExtensions(KO, ((KO, XO) => KO.postExportMaterialAsync && KO.postExportMaterialAsync(OO, XO, pO)))
      }
      async _extensionsPostExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        return await Promise.all(rb._ExtensionNames.map((async bK => {
          const eO = this._extensions[bK];
          if (eO.postExportMaterialAdditionalTexturesAsync) {
            const bK = await eO.postExportMaterialAdditionalTexturesAsync(OO, KO, pO);
            XO.push(...bK)
          }
        }))), XO
      }
      _extensionsPostExportTextures(OO, KO, pO) {
        for (const XO of rb._ExtensionNames) {
          const bK = this._extensions[XO];
          bK.postExportTexture && bK.postExportTexture(OO, KO, pO)
        }
      }
      _extensionsPostExportMeshPrimitive(OO) {
        for (const KO of rb._ExtensionNames) {
          const pO = this._extensions[KO];
          pO.postExportMeshPrimitive && pO.postExportMeshPrimitive(OO, this._bufferManager, this._accessors)
        }
      }
      async _extensionsPreGenerateBinaryAsync() {
        for (const OO of rb._ExtensionNames) {
          const KO = this._extensions[OO];
          KO.preGenerateBinaryAsync && await KO.preGenerateBinaryAsync(this._bufferManager)
        }
      }
      _forEachExtensions(OO) {
        for (const KO of rb._ExtensionNames) {
          const pO = this._extensions[KO];
          pO.enabled && OO(pO)
        }
      }
      _extensionsOnExporting() {
        this._forEachExtensions((OO => {
          var KO, pO, XO;
          OO.wasUsed && ((KO = this._glTF).extensionsUsed || (KO.extensionsUsed = []), -1 === this._glTF.extensionsUsed.indexOf(OO.name) && this._glTF.extensionsUsed.push(OO.name), OO.required && ((pO = this._glTF).extensionsRequired || (pO.extensionsRequired = []), -1 === this._glTF.extensionsRequired.indexOf(OO.name) && this._glTF.extensionsRequired.push(OO.name)), (XO = this._glTF).extensions || (XO.extensions = {}), OO.onExporting && OO.onExporting())
        }))
      }
      _loadExtensions() {
        for (const OO of rb._ExtensionNames) {
          const KO = rb._ExtensionFactories[OO](this);
          this._extensions[OO] = KO
        }
      }
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : VO.c.LastCreatedScene,
          KO = arguments.length > 1 ? arguments[1] : void 0;
        if (this._glTF = {
            asset: {
              generator: `Babylon.js v${FO.d.Version}`,
              version: "2.0"
            }
          }, this._animations = [], this._accessors = [], this._bufferViews = [], this._cameras = [], this._images = [], this._materials = [], this._meshes = [], this._nodes = [], this._samplers = [], this._scenes = [], this._skins = [], this._textures = [], this._imageData = {}, this._shouldUseGlb = !1, this._materialExporter = new jX(this), this._extensions = {}, this._bufferManager = new pX, this._shouldExportNodeMap = new Map, this._nodeMap = new Map, this._animationGroupMap = new Map, this._materialMap = new Map, this._camerasMap = new Map, this._nodesCameraMap = new Map, this._skinMap = new Map, this._nodesSkinMap = new Map, this._materialNeedsUVsSet = new Set, !OO) throw new Error("No scene available to export");
        this._babylonScene = OO, this._options = {
          shouldExportNode: () => !0,
          shouldExportAnimation: () => !0,
          metadataSelector: OO => OO?.UhO?.extras,
          animationSampleRate: 1 / 60,
          exportWithoutWaitingForScene: !1,
          exportUnusedUVs: !1,
          removeNoopRootNodes: !0,
          includeCoordinateSystemConversionNodes: !1,
          meshCompressionMethod: "None",
          khrInteractivity: void 0,
          ...KO
        }, this._loadExtensions()
      }
      dispose() {
        for (const OO in this._extensions) {
          this._extensions[OO].dispose()
        }
      }
      get options() {
        return this._options
      }
      static RegisterExtension(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 100;
        rb.UnregisterExtension(OO) && bK.Tools.Warn(`Extension with the name ${OO} already exists`), rb._ExtensionFactories[OO] = KO;
        const XO = pO ?? 0;
        rb._ExtensionOrders[OO] = XO;
        let eO = rb._ExtensionNames.length;
        for (let bK = 0; bK < rb._ExtensionNames.length; bK++) {
          const OO = rb._ExtensionNames[bK];
          if (XO < rb._ExtensionOrders[OO]) {
            eO = bK;
            break
          }
        }
        rb._ExtensionNames.splice(eO, 0, OO)
      }
      static UnregisterExtension(OO) {
        if (!rb._ExtensionFactories[OO]) return !1;
        delete rb._ExtensionFactories[OO], delete rb._ExtensionOrders[OO];
        const KO = rb._ExtensionNames.indexOf(OO);
        return -1 !== KO && rb._ExtensionNames.splice(KO, 1), !0
      }
      _generateJSON(OO, KO, pO) {
        const XO = {
          byteLength: OO
        };
        return XO.byteLength && (this._glTF.buffers = [XO]), this._nodes && this._nodes.length && (this._glTF.nodes = this._nodes), this._meshes && this._meshes.length && (this._glTF.meshes = this._meshes), this._scenes && this._scenes.length && (this._glTF.scenes = this._scenes, this._glTF.Ce = 0), this._cameras && this._cameras.length && (this._glTF.cameras = this._cameras), this._bufferViews && this._bufferViews.length && (this._glTF.bufferViews = this._bufferViews), this._accessors && this._accessors.length && (this._glTF.accessors = this._accessors), this._animations && this._animations.length && (this._glTF.animations = this._animations), this._materials && this._materials.length && (this._glTF.materials = this._materials), this._textures && this._textures.length && (this._glTF.textures = this._textures), this._samplers && this._samplers.length && (this._glTF.samplers = this._samplers), this._skins && this._skins.length && (this._glTF.skins = this._skins), this._images && this._images.length && (this._glTF.images = this._images), this._shouldUseGlb || (XO.uri = KO + ".bin"), pO ? JSON.stringify(this._glTF, null, 2) : JSON.stringify(this._glTF)
      }
      async generateGLTFAsync(OO) {
        const KO = await this._generateBinaryAsync();
        this._extensionsOnExporting();
        const pO = this._generateJSON(KO.byteLength, OO, !0),
          XO = new Blob([KO], {
            type: "application/octet-stream"
          }),
          bK = OO + ".gltf",
          eO = OO + ".bin",
          lO = new hO;
        if (lO.files[bK] = pO, lO.files[eO] = XO, this._imageData)
          for (const vK in this._imageData) lO.files[vK] = this._imageData[vK];
        return lO
      }
      async _generateBinaryAsync() {
        return await this._exportSceneAsync(), await this._extensionsPreGenerateBinaryAsync(), this._bufferManager.generateBinary(this._bufferViews)
      }
      _getPadding(OO) {
        const KO = OO % 4;
        return 0 === KO ? KO : 4 - KO
      }
      async generateGLBAsync(OO) {
        this._shouldUseGlb = !0;
        const KO = await this._generateBinaryAsync();
        this._extensionsOnExporting();
        const pO = this._generateJSON(KO.byteLength),
          XO = OO + ".glb";
        let bK, eO = pO.length;
        if ("undefined" !== typeof TextEncoder) {
          bK = (new TextEncoder).encode(pO), eO = bK.length
        }
        const lO = this._getPadding(eO),
          vK = this._getPadding(KO.byteLength),
          CO = 28 + eO + lO + KO.byteLength + vK,
          DO = new OX(CO);
        if (DO.writeUInt32(1179937895), DO.writeUInt32(2), DO.writeUInt32(CO), DO.writeUInt32(eO + lO), DO.writeUInt32(1313821514), bK) DO.writeTypedArray(bK);
        else {
          const OO = "_".charCodeAt(0);
          for (let KO = 0; KO < eO; ++KO) {
            const XO = pO.charCodeAt(KO);
            XO != pO.codePointAt(KO) ? DO.writeUInt8(OO) : DO.writeUInt8(XO)
          }
        }
        for (let hO = 0; hO < lO; ++hO) DO.writeUInt8(32);
        DO.writeUInt32(KO.byteLength + vK), DO.writeUInt32(5130562), DO.writeTypedArray(KO);
        for (let hO = 0; hO < vK; ++hO) DO.writeUInt8(0);
        const MO = new hO;
        return MO.files[XO] = new Blob([DO.getOutputData()], {
          type: "application/octet-stream"
        }), MO
      }
      _setNodeTransformation(OO, KO, pO) {
        if (KO.getPivotPoint().equalsWithEpsilon(mX, iX.c) || bK.Tools.Warn("Pivot points are not supported in the glTF serializer"), !KO.position.equalsWithEpsilon(mX, iX.c)) {
          const bK = XO.TmpVectors.WX[0].NhO(KO.position);
          pO && Zp(bK), OO.translation = bK.WhO()
        }
        KO.ol.equalsWithEpsilon(Hp, iX.c) || (OO.scale = KO.ol.WhO());
        const eO = KO.rotationQuaternion?.clone() || XO.Quaternion.FromEulerAngles(KO.rotation.x, KO.rotation.y, KO.rotation.z);
        eO.equalsWithEpsilon(sp, iX.c) || (pO && Gp(eO), OO.rotation = eO.normalize().WhO())
      }
      _setCameraTransformation(OO, KO, pO) {
        const bK = XO.TmpVectors.WX[0],
          eO = XO.TmpVectors.Quaternion[0],
          lO = KO.getWorldMatrix();
        if (KO.parent) {
          const OO = KO.parent.getWorldMatrix().invertToRef(XO.TmpVectors.Matrix[0]);
          lO.multiplyToRef(OO, XO.TmpVectors.Matrix[1]).decompose(void 0, eO, bK)
        } else lO.decompose(void 0, eO, bK);
        bK.equalsWithEpsilon(mX, iX.c) || (pO && Zp(bK), OO.translation = bK.WhO()), pO && Gp(eO), this._babylonScene.useRightHandedSystem || qX(eO), eO.equalsWithEpsilon(sp, iX.c) || (OO.rotation = eO.WhO())
      }
      _listAvailableCameras() {
        for (const OO of this._babylonScene.cameras) {
          const KO = {
            type: OO.mode === XX.c.PERSPECTIVE_CAMERA ? "perspective" : "orthographic"
          };
          if (OO.name && (KO.name = OO.name), "perspective" === KO.type) KO.perspective = {
            aspectRatio: OO.qb().getAspectRatio(OO),
            yfov: OO.fovMode === XX.c.FOVMODE_VERTICAL_FIXED ? OO.fov : OO.fov * OO.qb().getAspectRatio(OO),
            znear: OO.minZ,
            zfar: OO.maxZ
          };
          else if ("orthographic" === KO.type) {
            const pO = OO.orthoLeft && OO.orthoRight ? .5 * (OO.orthoRight - OO.orthoLeft) : .5 * OO.qb().getRenderWidth(),
              XO = OO.orthoBottom && OO.orthoTop ? .5 * (OO.orthoTop - OO.orthoBottom) : .5 * OO.qb().getRenderHeight();
            KO.orthographic = {
              xmag: pO,
              ymag: XO,
              znear: OO.minZ,
              zfar: OO.maxZ
            }
          }
          this._camerasMap.set(OO, KO)
        }
      }
      _exportAndAssignCameras() {
        const OO = Array.from(this._camerasMap.values());
        for (const KO of OO) {
          const OO = this._nodesCameraMap.get(KO);
          if (void 0 !== OO) {
            this._cameras.push(KO);
            for (const KO of OO) KO.camera = this._cameras.length - 1
          }
        }
      }
      _listAvailableSkeletons() {
        for (const OO of this._babylonScene.skeletons) {
          if (OO.bones.length <= 0) continue;
          const KO = {
            joints: []
          };
          this._skinMap.set(OO, KO)
        }
      }
      _exportAndAssignSkeletons(OO) {
        for (const pO of this._babylonScene.skeletons) {
          if (pO.bones.length <= 0) continue;
          const eO = this._skinMap.get(pO);
          if (void 0 == eO) continue;
          const lO = {};
          let vK = -1;
          for (let OO = 0; OO < pO.bones.length; ++OO) {
            const KO = pO.bones[OO],
              XO = KO.getIndex() ?? OO; - 1 !== XO && (lO[XO] = KO, XO > vK && (vK = XO))
          }
          const CO = [];
          for (let pO = 0; pO <= vK; ++pO) {
            const vK = lO[pO],
              hO = vK.getTransformNode(),
              DO = hO ? this._nodeMap.get(hO) : void 0;
            if (void 0 === DO) {
              bK.Tools.Warn("Exporting a bone without a linked transform node is currently unsupported.");
              continue
            }
            eO.joints.push(DO);
            const MO = vK.getAbsoluteInverseBindMatrix().clone();
            OO.has(hO) && (KO = MO, rX.invertToRef(XO.TmpVectors.Matrix[0]).multiplyToRef(KO, KO).multiplyToRef(rX, KO)), CO.push(MO)
          }
          const hO = this._nodesSkinMap.get(eO);
          if (eO.joints.length > 0 && void 0 !== hO) {
            const OO = new Float32Array(16 * CO.length);
            CO.forEach(((KO, pO) => {
              OO.set(KO.m, 16 * pO)
            }));
            const KO = this._bufferManager.createBufferView(OO);
            this._accessors.push(this._bufferManager.createAccessor(KO, "MAT4", 5126, CO.length)), eO.inverseBindMatrices = this._accessors.length - 1, this._skins.push(eO);
            const pO = this._skins.length - 1;
            for (const XO of hO) XO.skin = pO
          }
        }
        var KO
      }
      async _exportSceneAsync() {
        const OO = {
          nodes: []
        };
        if (this._babylonScene.metadata) {
          const KO = this._options.metadataSelector(this._babylonScene.metadata);
          KO && (OO.extras = KO)
        }
        const KO = new Array,
          pO = new Array,
          XO = new Array,
          bK = this._options.removeNoopRootNodes && !this._options.khrInteractivity;
        let eO;
        if (bK && !this._options.includeCoordinateSystemConversionNodes)
          for (const hO of this._babylonScene.animationGroups)
            for (const OO of hO.targetedAnimations) {
              const KO = OO.target;
              KO instanceof MO.c && !KO.parent && (eO ?? (eO = new Set)).add(KO)
            }
        for (const hO of this._babylonScene.rootNodes) {
          const OO = hO.animations,
            lO = !!OO && OO.length > 0 || eO?.has(hO);
          bK && !this._options.includeCoordinateSystemConversionNodes && Pp(hO, this._babylonScene.useRightHandedSystem) && !lO ? XO.push(...hO.getChildren()) : this._babylonScene.useRightHandedSystem ? KO.push(hO) : pO.push(hO)
        }
        this._listAvailableCameras(), this._listAvailableSkeletons();
        const lO = new ib(!0, !1);
        OO.nodes.push(...await this._exportNodesAsync(pO, lO));
        const vK = new ib(!1, !1);
        OO.nodes.push(...await this._exportNodesAsync(KO, vK));
        const CO = new ib(!1, !0);
        OO.nodes.push(...await this._exportNodesAsync(XO, CO)), OO.nodes.length && this._scenes.push(OO), this._exportAndAssignCameras(), this._exportAndAssignSkeletons(lO.getNodesSet()), this._babylonScene.animationGroups.length && MX._CreateNodeAndMorphAnimationFromAnimationGroups(this._babylonScene, this._animations, this._nodeMap, this._bufferManager, this._bufferViews, this._accessors, this._animationSampleRate, lO.getNodesSet(), this._options.shouldExportAnimation, this._animationGroupMap)
      }
      _getNodeIndex(OO) {
        return this._nodeMap.get(OO)
      }
      _getAnimationIndex(OO) {
        return this._animationGroupMap.get(OO)
      }
      _getCameraIndex(OO) {
        const KO = this._camerasMap.get(OO);
        if (!KO) return;
        const pO = this._cameras.indexOf(KO);
        return pO >= 0 ? pO : void 0
      }
      _getMaterialIndex(OO) {
        return this._materialMap.get(OO)
      }
      _getRootIndex(OO, KO) {
        switch (OO) {
          case "nodes":
            return this._getNodeIndex(KO);
          case "animations":
            return this._getAnimationIndex(KO);
          case "cameras":
            return this._getCameraIndex(KO);
          case "materials":
            return this._getMaterialIndex(KO);
          case "meshes": {
            const OO = this._getNodeIndex(KO);
            return void 0 === OO ? void 0 : this._nodes[OO]?.mesh
          }
          case "textures":
            return this._materialExporter.getTextureInfo(KO)?.index;
          case "images": {
            const OO = this._materialExporter.getTextureInfo(KO)?.index;
            if (void 0 === OO) return;
            const pO = this._textures[OO];
            for (const KO of ["KHR_texture_basisu", "EXT_texture_webp", "EXT_texture_avif"]) {
              const OO = pO?.extensions?.[KO]?.source;
              if ("number" === typeof OO) return OO
            }
            return pO?.source
          }
          case "samplers": {
            const OO = this._materialExporter.getTextureInfo(KO)?.index;
            return void 0 === OO ? void 0 : this._textures[OO]?.sampler
          }
          case "skins": {
            const OO = this._skinMap.get(KO),
              pO = OO ? this._skins.indexOf(OO) : -1;
            return pO >= 0 ? pO : void 0
          }
          case "scenes":
            return KO === this._babylonScene && this._scenes.length > 0 ? 0 : void 0
        }
      }
      _setNodeExtension(OO, KO, pO) {
        const XO = this._nodes[OO];
        if (!XO) throw new Error(`Cannot write ${KO}: glTF node ${OO} does not exist.`);
        XO.extensions || (XO.extensions = {}), XO.extensions[KO] = pO
      }
      _shouldExportNode(OO) {
        let KO = this._shouldExportNodeMap.get(OO);
        return void 0 === KO && (KO = this._options.shouldExportNode(OO), this._shouldExportNodeMap.set(OO, KO)), KO
      }
      async _exportNodesAsync(OO, KO) {
        const pO = new Array;
        this._exportBuffers(OO, KO);
        for (const XO of OO) await this._exportNodeAsync(XO, pO, KO);
        return pO
      }
      _collectBuffers(OO, KO, pO, XO, bK) {
        if (this._shouldExportNode(OO) && OO instanceof aK.c && OO.geometry) {
          const eO = OO.geometry.getVertexBuffers();
          if (eO)
            for (const XO in eO) {
              if (!cX(XO)) continue;
              const lO = eO[XO];
              bK.setHasVertexColorAlpha(lO, OO.hasVertexAlpha);
              const vK = lO._buffer,
                CO = KO.get(vK) || [];
              KO.set(vK, CO), -1 === CO.indexOf(lO) && CO.push(lO);
              const hO = pO.get(lO) || [];
              pO.set(lO, hO), -1 === hO.indexOf(OO) && hO.push(OO)
            }
          const lO = OO.morphTargetManager;
          if (lO)
            for (let KO = 0; KO < lO.numTargets; KO++) {
              const pO = lO.getTarget(KO),
                bK = XO.get(pO) || [];
              XO.set(pO, bK), -1 === bK.indexOf(OO) && bK.push(OO)
            }
        }
        for (const eO of OO.getChildren()) this._collectBuffers(eO, KO, pO, XO, bK)
      }
      _exportBuffers(OO, KO) {
        const pO = new Map,
          XO = new Map,
          bK = new Map;
        for (const vK of OO) this._collectBuffers(vK, pO, XO, bK, KO);
        const eO = Array.from(pO.keys());
        for (const vK of eO) {
          const OO = vK.getData();
          if (!OO) throw new Error("Buffer data is not available");
          const bK = pO.get(vK);
          if (!bK) continue;
          const eO = bK[0].byteStride;
          if (bK.some((OO => OO.byteStride !== eO))) throw new Error("Vertex buffers pointing to the same buffer must have the same byte stride");
          const lO = Wp(OO).slice();
          for (const KO of bK) {
            const OO = XO.get(KO),
              {
                byteOffset: pO,
                byteStride: bK,
                componentCount: eO,
                type: vK,
                count: CO,
                normalized: hO,
                kind: MO
              } = Sp(KO, OO);
            switch (MO) {
              case DO.f.NormalKind:
              case DO.f.TangentKind:
                (0, Yp.h)(lO, pO, bK, eO, vK, CO, hO, (OO => {
                  const KO = Math.sqrt(OO[0] * OO[0] + OO[1] * OO[1] + OO[2] * OO[2]);
                  if (KO > 0) {
                    const pO = 1 / KO;
                    OO[0] *= pO, OO[1] *= pO, OO[2] *= pO
                  }
                }));
                break;
              case DO.f.ColorKind: {
                const KO = OO.filter((OO => OO.material instanceof eX.StandardMaterial || null == OO.material)).length;
                if (0 == KO) break;
                if (KO != OO.length) {
                  uO.b.Warn("Not converting vertex color space, as buffer is shared by StandardMaterials and other material types. Results may look incorrect.");
                  break
                }
                vK == DO.f.UNSIGNED_BYTE && uO.b.Warn("Converting uint8 vertex colors to linear space. Results may look incorrect.");
                const XO = new LO.Color3,
                  MO = new LO.c,
                  aK = this._babylonScene.qb().useExactSrgbConversions;
                (0, Yp.h)(lO, pO, bK, eO, vK, CO, hO, (OO => {
                  3 === OO.length ? (XO.BCO(OO, 0), XO.toLinearSpaceToRef(XO, aK), XO.toArray(OO, 0)) : (MO.BCO(OO, 0), MO.toLinearSpaceToRef(MO, aK), MO.toArray(OO, 0))
                }))
              }
            }
          }
          if (KO.convertToRightHanded) {
            for (const OO of bK) {
              const KO = XO.get(OO),
                {
                  byteOffset: pO,
                  byteStride: bK,
                  componentCount: eO,
                  type: vK,
                  count: CO,
                  normalized: hO,
                  kind: MO
                } = Sp(OO, KO);
              switch (MO) {
                case DO.f.PositionKind:
                case DO.f.NormalKind:
                case DO.f.TangentKind:
                  (0, Yp.h)(lO, pO, bK, eO, vK, CO, hO, (OO => {
                    OO[0] = -OO[0]
                  }))
              }
            }
            KO.convertedToRightHandedBuffers.set(vK, lO)
          }
          const CO = this._bufferManager.createBufferView(lO, eO);
          KO.setVertexBufferView(vK, CO);
          const hO = new Map;
          for (const KO of bK) {
            const OO = XO.get(KO),
              {
                kind: pO,
                totalVertices: bK
              } = Sp(KO, OO);
            switch (pO) {
              case DO.f.MatricesIndicesKind:
              case DO.f.MatricesIndicesExtraKind:
                if (KO.type == DO.f.FLOAT) {
                  const OO = KO.getFloatData(bK);
                  null !== OO && hO.set(KO, OO)
                }
            }
          }
          0 !== hO.size && uO.b.Warn("Joint indices conversion needed: some joint indices are stored as floats in Babylon but GLTF requires UNSIGNED BYTES. We will perform the conversion but this might lead to unused data in the buffer.");
          const MO = Array.from(hO.keys());
          for (const pO of MO) {
            const OO = hO.get(pO);
            if (!OO) continue;
            const XO = OO.some((OO => OO >= 256)),
              bK = new(XO ? Uint16Array : Uint8Array)(OO.length);
            for (let KO = 0; KO < OO.length; KO++) bK[KO] = OO[KO];
            const eO = this._bufferManager.createBufferView(bK, 4 * (XO ? 2 : 1));
            KO.setRemappedBufferView(vK, pO, eO)
          }
        }
        const lO = Array.from(bK.keys());
        for (const vK of lO) {
          const OO = bK.get(vK);
          if (!OO) continue;
          const pO = ab(vK, OO[0], this._bufferManager, this._bufferViews, this._accessors, KO.convertToRightHanded);
          for (const XO of OO) KO.bindMorphDataToMesh(XO, pO)
        }
      }
      async _exportNodeAsync(OO, KO, pO) {
        let XO = this._nodeMap.get(OO);
        if (void 0 !== XO) return void(KO.includes(XO) || KO.push(XO));
        const bK = await this._createNodeAsync(OO, pO);
        if (bK) {
          XO = this._nodes.length, this._nodes.push(bK), this._nodeMap.set(OO, XO), pO.pushExportedNode(OO), KO.push(XO);
          const eO = {
              name: "runtime animations",
              channels: [],
              samplers: []
            },
            lO = [];
          this._babylonScene.animationGroups.length || (MX._CreateMorphTargetAnimationFromMorphTargetAnimations(OO, eO, lO, this._nodeMap, this._nodes, this._bufferManager, this._bufferViews, this._accessors, this._animationSampleRate, pO.convertToRightHanded, this._options.shouldExportAnimation), OO.animations.length && MX._CreateNodeAnimationFromNodeAnimations(OO, eO, lO, this._nodeMap, this._nodes, this._bufferManager, this._bufferViews, this._accessors, this._animationSampleRate, pO.convertToRightHanded, this._options.shouldExportAnimation)), eO.channels.length && eO.samplers.length && this._animations.push(eO), lO.forEach((OO => {
            OO.channels.length && OO.samplers.length && this._animations.push(OO)
          }))
        }
        const eO = bK ? [] : KO;
        for (const lO of OO.getChildren()) await this._exportNodeAsync(lO, eO, pO);
        bK && eO.length && (bK.children = eO)
      }
      async _createNodeAsync(OO, KO) {
        if (!this._shouldExportNode(OO)) return null;
        const pO = {};
        if (OO.name && (pO.name = OO.name), OO.metadata) {
          const KO = this._options.metadataSelector(OO.metadata);
          KO && (pO.extras = KO)
        }
        if (OO instanceof MO.c && (this._setNodeTransformation(pO, OO, KO.convertToRightHanded), OO instanceof aK.c)) {
          const XO = OO instanceof oO.b ? OO.SDO : OO;
          if (XO.au && XO.au.length > 0 && (pO.mesh = await this._exportMeshAsync(XO, KO)), OO.skeleton) {
            const KO = this._skinMap.get(OO.skeleton);
            void 0 !== KO && (void 0 === this._nodesSkinMap.get(KO) && this._nodesSkinMap.set(KO, []), this._nodesSkinMap.get(KO)?.push(pO))
          }
        }
        if (OO instanceof wp.f) {
          const XO = this._camerasMap.get(OO);
          if (XO) {
            void 0 === this._nodesCameraMap.get(XO) && this._nodesCameraMap.set(XO, []), this._setCameraTransformation(pO, OO, KO.convertToRightHanded);
            const bK = OO.parent;
            if (null !== bK && np(OO, bK)) {
              const OO = this._nodeMap.get(bK);
              if (void 0 !== OO) {
                const KO = this._nodes[OO];
                return xX(pO, KO), this._nodesCameraMap.get(XO)?.push(KO), null
              }
            }
            this._nodesCameraMap.get(XO)?.push(pO)
          }
        }
        return await this._extensionsPostExportNodeAsync("exportNodeAsync", pO, OO, this._nodeMap, KO.convertToRightHanded) ? pO : (uO.b.Warn(`Not exporting node ${OO.name}`), null)
      }
      _exportIndices(OO, KO, pO, XO, bK, lO, vK, CO, hO) {
        let DO = null;
        hO.mode = function(OO) {
          switch (OO) {
            case eO.b.TriangleFillMode:
              return 4;
            case eO.b.TriangleStripDrawMode:
              return 5;
            case eO.b.TriangleFanDrawMode:
              return 6;
            case eO.b.PointListDrawMode:
            case eO.b.PointFillMode:
              return 0;
            case eO.b.LineLoopDrawMode:
              return 2;
            case eO.b.LineListDrawMode:
              return 1;
            case eO.b.LineStripDrawMode:
              return 3
          }
          throw new Error(`Unknown fill mode: ${OO}`)
        }(lO);
        const MO = vK !== eO.b.CounterClockWiseSideOrientation && function(OO) {
          switch (OO) {
            case eO.b.TriangleFillMode:
            case eO.b.TriangleStripDrawMode:
            case eO.b.TriangleFanDrawMode:
              return !0
          }
          return !1
        }(lO);
        if (MO) {
          if (lO === eO.b.TriangleStripDrawMode || lO === eO.b.TriangleFanDrawMode) throw new Error("Triangle strip/fan fill mode is not implemented");
          const vK = KO ? new Uint32Array(XO) : new Uint16Array(XO);
          if (OO)
            for (let KO = 0; KO + 2 < XO; KO += 3) vK[KO] = OO[pO + KO] + bK, vK[KO + 1] = OO[pO + KO + 2] + bK, vK[KO + 2] = OO[pO + KO + 1] + bK;
          else
            for (let OO = 0; OO + 2 < XO; OO += 3) vK[OO] = OO, vK[OO + 1] = OO + 2, vK[OO + 2] = OO + 1;
          DO = vK
        } else if (OO && 0 !== bK) {
          const eO = KO ? new Uint32Array(XO) : new Uint16Array(XO);
          for (let KO = 0; KO < XO; KO++) eO[KO] = OO[pO + KO] + bK;
          DO = eO
        } else OO && (DO = function(OO, KO, pO, XO) {
          let bK = OO;
          return 0 === KO && pO === OO.length || (bK = Array.isArray(OO) ? OO.slice(KO, KO + pO) : OO.subarray(KO, KO + pO)), bK instanceof Int32Array ? new Uint32Array(bK.buffer, bK.byteOffset, bK.length) : Array.isArray(bK) ? XO ? new Uint32Array(bK) : new Uint16Array(bK) : bK
        }(OO, pO, XO, KO));
        if (DO) {
          let eO = CO.getIndicesAccessor(OO, pO, XO, bK, MO);
          if (void 0 === eO) {
            const lO = this._bufferManager.createBufferView(DO),
              vK = KO ? 5125 : 5123;
            this._accessors.push(this._bufferManager.createAccessor(lO, "SCALAR", vK, XO, 0)), eO = this._accessors.length - 1, CO.setIndicesAccessor(OO, pO, XO, bK, MO, eO)
          }
          hO.indices = eO
        }
      }
      _exportVertexBuffer(OO, KO, pO, XO, bK, eO) {
        const lO = OO.getKind();
        if (!cX(lO)) return;
        if (lO.startsWith("uv") && !this._options.exportUnusedUVs && (!KO || !this._materialNeedsUVsSet.has(KO))) return;
        let vK = bK.getVertexAccessor(OO, pO, XO);
        if (void 0 === vK) {
          const KO = bK.convertedToRightHandedBuffers.get(OO._buffer) || OO._buffer.getData(),
            eO = lO === DO.f.PositionKind ? function(OO, KO, pO, XO) {
              const {
                byteOffset: bK,
                byteStride: eO,
                type: lO,
                normalized: vK
              } = KO, CO = KO.getSize(), hO = new Array(CO).fill(1 / 0), DO = new Array(CO).fill(-1 / 0);
              return (0, Yp.h)(OO, bK + pO * eO, eO, CO, lO, XO * CO, vK, (OO => {
                for (let KO = 0; KO < CO; KO++) hO[KO] = Math.min(hO[KO], OO[KO]), DO[KO] = Math.max(DO[KO], OO[KO])
              })), {
                min: hO,
                max: DO
              }
            }(KO, OO, pO, XO) : void 0,
            CO = (lO === DO.f.MatricesIndicesKind || lO === DO.f.MatricesIndicesExtraKind) && OO.type === DO.f.FLOAT,
            hO = CO ? DO.f.UNSIGNED_BYTE : OO.type,
            MO = CO ? void 0 : OO.normalized,
            aK = CO ? bK.getRemappedBufferView(OO._buffer, OO) : bK.getVertexBufferView(OO._buffer),
            oO = OO.byteOffset + pO * OO.byteStride;
          this._accessors.push(this._bufferManager.createAccessor(aK, function(OO, KO) {
            if (OO == DO.f.ColorKind) return KO ? "VEC4" : "VEC3";
            switch (OO) {
              case DO.f.PositionKind:
              case DO.f.NormalKind:
                return "VEC3";
              case DO.f.TangentKind:
              case DO.f.MatricesIndicesKind:
              case DO.f.MatricesIndicesExtraKind:
              case DO.f.MatricesWeightsKind:
              case DO.f.MatricesWeightsExtraKind:
                return "VEC4";
              case DO.f.UVKind:
              case DO.f.UV2Kind:
              case DO.f.UV3Kind:
              case DO.f.UV4Kind:
              case DO.f.UV5Kind:
              case DO.f.UV6Kind:
                return "VEC2"
            }
            throw new Error(`Unknown kind ${OO}`)
          }(lO, bK.hasVertexColorAlpha(OO)), hO, XO, oO, eO, MO)), vK = this._accessors.length - 1, bK.setVertexAccessor(OO, pO, XO, vK)
        }
        eO.attributes[function(OO) {
          switch (OO) {
            case DO.f.PositionKind:
              return "POSITION";
            case DO.f.NormalKind:
              return "NORMAL";
            case DO.f.TangentKind:
              return "TANGENT";
            case DO.f.ColorKind:
              return "COLOR_0";
            case DO.f.UVKind:
              return "TEXCOORD_0";
            case DO.f.UV2Kind:
              return "TEXCOORD_1";
            case DO.f.UV3Kind:
              return "TEXCOORD_2";
            case DO.f.UV4Kind:
              return "TEXCOORD_3";
            case DO.f.UV5Kind:
              return "TEXCOORD_4";
            case DO.f.UV6Kind:
              return "TEXCOORD_5";
            case DO.f.MatricesIndicesKind:
              return "JOINTS_0";
            case DO.f.MatricesIndicesExtraKind:
              return "JOINTS_1";
            case DO.f.MatricesWeightsKind:
              return "WEIGHTS_0";
            case DO.f.MatricesWeightsExtraKind:
              return "WEIGHTS_1"
          }
          throw new Error(`Unknown kind: ${OO}`)
        }(lO)] = vK
      }
      async _exportMaterialAsync(OO, KO, pO, XO) {
        let bK = this._materialMap.get(OO);
        if (void 0 === bK) {
          const XO = KO && Object.keys(KO).some((OO => OO.startsWith("uv")));
          if ((OO = OO instanceof bb.d ? OO.jvO[pO.materialIndex] : OO) instanceof TK) bK = await this._materialExporter.exportPBRMaterialAsync(OO, XO);
          else if (OO instanceof eX.StandardMaterial) bK = await this._materialExporter.exportStandardMaterialAsync(OO, XO);
          else {
            if (!(OO instanceof kp)) return void uO.b.Warn(`Unsupported material '${OO.name}' with type ${OO.getClassName()}`);
            bK = await this._materialExporter.exportOpenPBRMaterialAsync(OO, XO)
          }
          this._materialMap.set(OO, bK)
        }
        XO.material = bK
      }
      async _exportMeshAsync(OO, KO) {
        let pO = KO.getMesh(OO);
        if (void 0 !== pO) return pO;
        const XO = {
          primitives: []
        };
        pO = this._meshes.length, this._meshes.push(XO), KO.setMesh(OO, pO);
        const bK = OO.isUnIndexed ? null : OO.rFO(),
          lO = OO.geometry?.getVertexBuffers(),
          vK = KO.getMorphTargetsFromMesh(OO),
          CO = OO instanceof oX.e,
          hO = OO instanceof wX,
          DO = OO.au;
        if (lO && DO && DO.length > 0)
          for (const MO of DO) {
            const pO = {
                attributes: {}
              },
              DO = MO.UX() || this._babylonScene.defaultMaterial;
            if (hO) {
              const KO = {
                  name: DO.name
                },
                XO = OO,
                bK = LO.Color3.White(),
                eO = XO.material?.alpha ?? 1,
                lO = XO.greasedLineMaterial?.color ?? bK;
              (!lO.equalsWithEpsilon(bK, iX.c) || eO < 1) && (KO.pbrMetallicRoughness = {
                baseColorFactor: [...lO.WhO(), eO]
              }), this._materials.push(KO), pO.material = this._materials.length - 1
            } else if (CO) {
              const KO = {
                  name: DO.name
                },
                XO = OO;
              (!XO.color.equalsWithEpsilon(LO.Color3.White(), iX.c) || XO.alpha < 1) && (KO.pbrMetallicRoughness = {
                baseColorFactor: [...XO.color.WhO(), XO.alpha]
              }), this._materials.push(KO), pO.material = this._materials.length - 1
            } else await this._exportMaterialAsync(DO, lO, MO, pO);
            const aK = CO || hO ? eO.b.LineListDrawMode : OO.overrideRenderingFillMode ?? DO.fillMode;
            let oO = DO._getEffectiveOrientation(OO);
            KO.wasAddedByNoopNode && !OO.JKO().useRightHandedSystem && (oO = oO === eO.b.ClockWiseSideOrientation ? eO.b.CounterClockWiseSideOrientation : eO.b.ClockWiseSideOrientation), this._exportIndices(bK, bK ? (0, Yp.b)(bK, MO.indexCount, MO.indexStart, MO.verticesStart) : MO.verticesCount > 65535, bK ? MO.indexStart : MO.verticesStart, bK ? MO.indexCount : MO.verticesCount, -MO.verticesStart, aK, oO, KO, pO);
            for (const OO of Object.values(lO)) this._exportVertexBuffer(OO, DO, MO.verticesStart, MO.verticesCount, KO, pO);
            if (vK) {
              pO.targets = [];
              for (const OO of vK) pO.targets.push(OO.attributes)
            }
            XO.primitives.push(pO), this._extensionsPostExportMeshPrimitive(pO)
          }
        if (vK) {
          XO.weights = [], XO.extras || (XO.extras = {}), XO.extras.targetNames = [];
          for (const OO of vK) XO.weights.push(OO.influence), XO.extras.targetNames.push(OO.name)
        }
        return pO
      }
    }
    rb._ExtensionNames = new Array, rb._ExtensionFactories = {}, rb._ExtensionOrders = {};
    class PX {
      static async GLTFAsync(OO, KO, pO) {
        pO && pO.exportWithoutWaitingForScene || await OO.whenReadyAsync();
        const XO = new rb(OO, pO),
          bK = await XO.generateGLTFAsync(KO.replace(/\.[^/.]+$/, ""));
        return XO.dispose(), bK
      }
      static async GLBAsync(OO, KO, pO) {
        pO && pO.exportWithoutWaitingForScene || await OO.whenReadyAsync();
        const XO = new rb(OO, pO),
          bK = await XO.generateGLBAsync(KO.replace(/\.[^/.]+$/, ""));
        return XO.dispose(), bK
      }
    }
    const mb = "EXT_mesh_gpu_instancing";

    function sX(OO, KO) {
      const pO = new Float32Array(3 * KO);
      for (let XO = 0; XO < KO; XO++) pO[3 * XO + 0] = OO[4 * XO + 0], pO[3 * XO + 1] = OO[4 * XO + 1], pO[3 * XO + 2] = OO[4 * XO + 2];
      return pO
    }
    class HX {
      constructor(OO) {
        this.name = mb, this.enabled = !0, this.required = !1, this._instanceColorWarned = !1, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportNodeAsync(OO, KO, pO, XO, bK, eO) {
        return await new Promise((OO => {
          if (KO && pO instanceof TX.c && pO.hasThinInstances && this._exporter) {
            this._wasUsed = !0;
            const OO = HO.o.Zero(),
              XO = HO.g.Identity(),
              lO = HO.o.One(),
              vK = pO.thinInstanceGetWorldMatrices(),
              CO = HO.j.WX[2],
              hO = HO.j.Quaternion[1],
              DO = HO.j.WX[3];
            let MO = !1,
              aK = !1,
              oO = !1;
            const FO = new Float32Array(3 * pO.hlO),
              VO = new Float32Array(4 * pO.hlO),
              LO = new Float32Array(3 * pO.hlO);
            let QO = 0;
            for (const KO of vK) KO.decompose(DO, hO, CO), bK && (Zp(CO), Gp(hO)), FO.set(CO.WhO(), 3 * QO), VO.set(hO.normalize().WhO(), 4 * QO), LO.set(DO.WhO(), 3 * QO), MO = MO || !CO.equalsWithEpsilon(OO), aK = aK || !hO.equalsWithEpsilon(XO), oO = oO || !DO.equalsWithEpsilon(lO), QO++;
            const zK = {
              attributes: {}
            };
            MO && (zK.attributes.TRANSLATION = this._buildAccessor(FO, "VEC3", pO.hlO, eO)), aK && (zK.attributes.ROTATION = this._buildAccessor(VO, "VEC4", pO.hlO, eO)), oO && (zK.attributes.SCALE = this._buildAccessor(LO, "VEC3", pO.hlO, eO));
            let AO = pO._userThinInstanceBuffersStorage?.data?.instanceColor;
            if (AO) {
              const OO = pO.hlO,
                KO = "VEC3";
              pO.hasVertexAlpha && AO.length === 4 * OO ? (this._instanceColorWarned || (uO.b.Warn("EXT_mesh_gpu_instancing: Exporting instance colors as RGB, alpha channel of instance color is not exported"), this._instanceColorWarned = !0), AO = sX(AO, OO)) : AO.length === 4 * OO && (AO = sX(AO, OO)), AO.length === 3 * OO && (zK.attributes._COLOR_0 = this._buildAccessor(AO, KO, OO, eO))
            }
            KO.extensions = KO.extensions || {}, KO.extensions[mb] = zK
          }
          OO(KO)
        }))
      }
      _buildAccessor(OO, KO, pO, XO) {
        const bK = XO.createBufferView(OO),
          eO = XO.createAccessor(bK, KO, 5126, pO);
        return this._exporter._accessors.push(eO), this._exporter._accessors.length - 1
      }
    }
    let RX = !1;

    function SX() {
      RX || (RX = !0, rb.RegisterExtension(mb, (OO => new HX(OO))))
    }
    pO(38587);
    SX();
    var JX = pO(39862);

    function cb(OO, KO, pO, XO) {
      const bK = OO;
      let eO = null,
        lO = null,
        vK = null,
        CO = null;
      const hO = {},
        DO = KO.find((OO => "POSITION" === OO.dracoName));
      if (!DO) throw new Error("Draco: Missing position attribute for encoding.");
      if (!pO) {
        const OO = DO.data.length / DO.size;
        pO = new(OO > 65535 ? Uint32Array : Uint16Array)(OO);
        for (let KO = 0; KO < OO; KO++) pO[KO] = KO
      }
      try {
        eO = new bK.Encoder, lO = new bK.MeshBuilder, vK = new bK.Mesh, lO.AddFacesToMesh(vK, pO.length / 3, pO);
        const OO = new Map([
          [Float32Array, (OO, KO, pO, XO, bK, eO) => OO.AddFloatAttribute(KO, pO, XO, bK, eO)],
          [Uint32Array, (OO, KO, pO, XO, bK, eO) => OO.AddUInt32Attribute(KO, pO, XO, bK, eO)],
          [Uint16Array, (OO, KO, pO, XO, bK, eO) => OO.AddUInt16Attribute(KO, pO, XO, bK, eO)],
          [Uint8Array, (OO, KO, pO, XO, bK, eO) => OO.AddUInt8Attribute(KO, pO, XO, bK, eO)],
          [Int32Array, (OO, KO, pO, XO, bK, eO) => OO.AddInt32Attribute(KO, pO, XO, bK, eO)],
          [Int16Array, (OO, KO, pO, XO, bK, eO) => OO.AddInt16Attribute(KO, pO, XO, bK, eO)],
          [Int8Array, (OO, KO, pO, XO, bK, eO) => OO.AddInt8Attribute(KO, pO, XO, bK, eO)]
        ]);
        for (const pO of KO) {
          pO.data instanceof Uint8ClampedArray && (pO.data = new Uint8Array(pO.data));
          const KO = OO.get(pO.data.constructor),
            CO = pO.data.length / pO.size;
          hO[pO.kind] = KO(lO, vK, bK[pO.dracoName], CO, pO.size, pO.data), XO.quantizationBits && XO.quantizationBits[pO.dracoName] && eO.SetAttributeQuantization(bK[pO.dracoName], XO.quantizationBits[pO.dracoName])
        }
        XO.method && eO.SetEncodingMethod(bK[XO.method]), void 0 !== XO.encodeSpeed && void 0 !== XO.decodeSpeed && eO.SetSpeedOptions(XO.encodeSpeed, XO.decodeSpeed), CO = new bK.DracoInt8Array;
        const DO = eO.EncodeMeshToDracoBuffer(vK, CO);
        if (DO <= 0) throw new Error("Draco: Failed to encode.");
        const MO = new Int8Array(DO);
        for (let KO = 0; KO < DO; KO++) MO[KO] = CO.GetValue(KO);
        return {
          data: MO,
          attributeIds: hO
        }
      } finally {
        vK && bK.destroy(vK), lO && bK.destroy(lO), eO && bK.destroy(eO), CO && bK.destroy(CO)
      }
    }

    function BX() {
      let OO;
      onmessage = KO => {
        const pO = KO.data;
        switch (pO.id) {
          case "init": {
            pO.url && importScripts(pO.url);
            const KO = pO.wasmBinary ? {
              wasmBinary: pO.wasmBinary
            } : {};
            OO = DracoEncoderModule(KO), postMessage({
              id: "initDone"
            });
            break
          }
          case "encodeMesh":
            if (!OO) throw new Error("Draco: Encoder module is not available.");
            OO.then((OO => {
              const KO = cb(OO, pO.attributes, pO.indices, pO.options);
              postMessage({
                id: "encodeMeshSuccess",
                encodedMeshData: KO
              }, KO ? [KO.data.buffer] : void 0)
            })).catch((OO => {
              postMessage({
                id: "encodeMeshError",
                errorMessage: OO.message
              })
            }))
        }
      }
    }
    class ZX {
      constructor(OO) {
        if (OO.workerPool) return void(this._workerPoolPromise = Promise.resolve(OO.workerPool));
        const KO = OO.wasmBinary,
          pO = OO.numWorkers ?? ("object" === typeof navigator && navigator.hardwareConcurrency ? Math.min(Math.floor(.5 * navigator.hardwareConcurrency), 4) : 1),
          XO = pO && "function" === typeof Worker && "function" === typeof URL,
          bK = XO || !OO.jsModule,
          eO = OO.wasmUrl && OO.wasmBinaryUrl && "object" === typeof WebAssembly ? {
            url: bK ? IK.k.GetBabylonScriptURL(OO.wasmUrl, !0) : "",
            wasmBinaryPromise: KO ? Promise.resolve(KO) : IK.k.LoadFileAsync(IK.k.GetBabylonScriptURL(OO.wasmBinaryUrl, !0))
          } : {
            url: bK ? IK.k.GetBabylonScriptURL(OO.fallbackUrl) : "",
            wasmBinaryPromise: Promise.resolve(void 0)
          };
        XO ? this._workerPoolPromise = eO.wasmBinaryPromise.then((OO => {
          const KO = this._getWorkerContent(),
            XO = URL.createObjectURL(new Blob([KO], {
              type: "application/javascript"
            }));
          return new JX.b(pO, (() => async function(OO, KO, pO) {
            return await new Promise(((XO, bK) => {
              const eO = KO => {
                  OO.removeEventListener("error", eO), OO.removeEventListener("message", lO), bK(KO)
                },
                lO = KO => {
                  "initDone" === KO.data.id && (OO.removeEventListener("error", eO), OO.removeEventListener("message", lO), XO(OO))
                };
              if (OO.addEventListener("error", eO), OO.addEventListener("message", lO), KO) {
                const XO = KO.slice(0);
                OO.postMessage({
                  id: "init",
                  url: pO,
                  wasmBinary: XO
                }, [XO])
              } else OO.postMessage({
                id: "init",
                url: pO
              })
            }))
          }(new Worker(XO), OO, eO.url)))
        })) : this._modulePromise = eO.wasmBinaryPromise.then((async KO => {
          if (!this._isModuleAvailable() && !OO.jsModule) {
            if (!eO.url) throw new Error("Draco codec module is not available");
            await IK.k.LoadBabylonScriptAsync(eO.url)
          }
          return await this._createModuleAsync(KO, OO.jsModule)
        }))
      }
      async whenReadyAsync() {
        this._workerPoolPromise ? await this._workerPoolPromise : this._modulePromise && await this._modulePromise
      }
      dispose() {
        this._workerPoolPromise && this._workerPoolPromise.then((OO => {
          OO.dispose()
        })), delete this._workerPoolPromise, delete this._modulePromise
      }
    }

    function GX() {
      const OO = OO => !!OO && "object" === typeof OO;
      for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
      return pO.reduce(((KO, pO) => {
        const XO = Object.keys(pO);
        for (const bK of XO) {
          const XO = KO[bK],
            eO = pO[bK];
          Array.isArray(XO) && Array.isArray(eO) ? KO[bK] = XO.concat(eO) : OO(XO) && OO(eO) ? KO[bK] = GX(XO, eO) : KO[bK] = eO
        }
        return KO
      }), {})
    }

    function qb(OO) {
      return OO === RO.j.PositionKind ? "POSITION" : OO === RO.j.NormalKind ? "NORMAL" : OO === RO.j.ColorKind ? "COLOR" : OO.startsWith(RO.j.UVKind) ? "TEX_COORD" : "GENERIC"
    }
    const xb = {
      decodeSpeed: 5,
      encodeSpeed: 5,
      method: "MESH_EDGEBREAKER_ENCODING",
      quantizationBits: {
        POSITION: 14,
        NORMAL: 10,
        COLOR: 8,
        TEX_COORD: 12,
        GENERIC: 12
      }
    };
    class nX extends ZX {
      static get DefaultAvailable() {
        return !!((OO = nX.DefaultConfiguration).wasmUrl && (OO.wasmBinary || OO.wasmBinaryUrl) && "object" === typeof WebAssembly || OO.fallbackUrl);
        var OO
      }
      static get Default() {
        return nX._Default ?? (nX._Default = new nX), nX._Default
      }
      static ResetDefault(OO) {
        nX._Default && (OO || nX._Default.dispose(), nX._Default = null)
      }
      _isModuleAvailable() {
        return "undefined" !== typeof DracoEncoderModule
      }
      async _createModuleAsync(OO, KO) {
        return {
          module: await (KO || DracoEncoderModule)({
            wasmBinary: OO
          })
        }
      }
      _getWorkerContent() {
        return `${cb}(${BX})()`
      }
      constructor() {
        super(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : nX.DefaultConfiguration)
      }
      async _encodeAsync(OO, KO, pO) {
        const XO = pO ? GX(xb, pO) : xb;
        if (this._workerPoolPromise) {
          const pO = await this._workerPoolPromise;
          return await new Promise(((bK, eO) => {
            pO.push(((pO, lO) => {
              const vK = OO => {
                  pO.removeEventListener("error", vK), pO.removeEventListener("message", CO), eO(OO), lO()
                },
                CO = OO => {
                  "encodeMeshSuccess" === OO.data.id ? (pO.removeEventListener("error", vK), pO.removeEventListener("message", CO), bK(OO.data.encodedMeshData), lO()) : "encodeMeshError" === OO.data.id && (pO.removeEventListener("error", vK), pO.removeEventListener("message", CO), eO(new Error(OO.data.errorMessage)), lO())
                };
              pO.addEventListener("error", vK), pO.addEventListener("message", CO);
              const hO = [];
              for (const KO of OO) hO.push(KO.data.buffer);
              KO && hO.push(KO.buffer), pO.postMessage({
                id: "encodeMesh",
                attributes: OO,
                indices: KO,
                options: XO
              }, hO)
            }))
          }))
        }
        if (this._modulePromise) {
          return cb((await this._modulePromise).module, OO, KO, XO)
        }
        throw new Error("Draco: Encoder module is not available")
      }
      async encodeMeshAsync(OO, KO) {
        if (0 == OO.getTotalVertices()) throw new Error("Draco: Cannot encode geometry with no vertices.");
        OO instanceof TX.c && OO.morphTargetManager && "MESH_EDGEBREAKER_ENCODING" === KO?.method && (uO.b.Warn("Draco: Cannot use EDGEBREAKER encoding method with morph targets. Falling back to SEQUENTIAL method."), KO.method = "MESH_SEQUENTIAL_ENCODING");
        const pO = function(OO) {
            let KO = OO.rFO(void 0, !0);
            return !KO || KO instanceof Uint32Array || KO instanceof Uint16Array || (KO = ((0, Yp.b)(KO, KO.length) ? Uint32Array : Uint16Array).from(KO)), KO
          }(OO),
          XO = function(OO, KO) {
            const pO = [];
            for (const XO of OO.getVerticesDataKinds()) {
              if (KO?.includes(XO)) {
                if (XO === RO.j.PositionKind) throw new Error("Draco: Cannot exclude position attribute from encoding.");
                continue
              }
              const bK = OO.getVertexBuffer(XO),
                eO = bK.getSize(),
                lO = (0, Yp.u)(bK.getData(), eO, bK.type, bK.byteOffset, bK.byteStride, OO.getTotalVertices(), !0);
              pO.push({
                kind: XO,
                dracoName: qb(XO),
                size: eO,
                data: lO
              })
            }
            return pO
          }(OO, KO?.excludedAttributes);
        return await this._encodeAsync(XO, pO, KO)
      }
    }
    nX.DefaultConfiguration = {
      wasmUrl: `${IK.k._DefaultCdnUrl}/draco_encoder_wasm_wrapper.js`,
      wasmBinaryUrl: `${IK.k._DefaultCdnUrl}/draco_encoder.wasm`,
      fallbackUrl: `${IK.k._DefaultCdnUrl}/draco_encoder.js`
    }, nX._Default = null;
    const WX = "KHR_draco_mesh_compression";
    class tb {
      get wasUsed() {
        return this._wasUsed
      }
      constructor(OO) {
        this.name = WX, this.required = !0, this._bufferViewsUsed = new Set, this._accessorsUsed = new Set, this._encodePromises = [], this._wasUsed = !1, this.enabled = "Draco" === OO.options.meshCompressionMethod && nX.DefaultAvailable
      }
      dispose() {}
      postExportMeshPrimitive(OO, KO, pO) {
        if (!this.enabled) return;
        if (4 !== OO.mode && 5 !== OO.mode) return void uO.b.Warn("Cannot compress primitive with mode " + OO.mode + ".");
        const XO = [],
          bK = [];
        let eO = null;
        if (void 0 !== OO.indices) {
          const lO = pO[OO.indices],
            vK = KO.getBufferView(lO);
          eO = KO.getData(vK).slice(), XO.push(vK), bK.push(lO)
        }
        const lO = [];
        for (const [DO, MO] of Object.entries(OO.attributes)) {
          const OO = pO[MO],
            eO = KO.getBufferView(OO),
            CO = Jp(OO.type),
            hO = (0, Yp.u)(KO.getData(eO), CO, OO.componentType, OO.byteOffset || 0, eO.byteStride || (0, Yp.r)(OO.componentType) * CO, OO.count, !0);
          lO.push({
            kind: DO,
            dracoName: (vK = DO, "POSITION" === vK ? "POSITION" : "NORMAL" === vK ? "NORMAL" : vK.startsWith("COLOR") ? "COLOR" : vK.startsWith("TEXCOORD") ? "TEX_COORD" : "GENERIC"),
            size: Jp(OO.type),
            data: hO
          }), XO.push(eO), bK.push(OO)
        }
        var vK;
        const CO = {
            method: OO.targets ? "MESH_SEQUENTIAL_ENCODING" : "MESH_EDGEBREAKER_ENCODING"
          },
          hO = nX.Default._encodeAsync(lO, eO, CO).then((pO => {
            const eO = {
                bufferView: -1,
                attributes: pO.attributeIds
              },
              lO = KO.createBufferView(pO.data);
            KO.setBufferView(eO, lO);
            for (const OO of XO) this._bufferViewsUsed.add(OO);
            for (const OO of bK) this._accessorsUsed.add(OO);
            OO.extensions || (OO.extensions = {}), OO.extensions[WX] = eO
          })).catch((OO => {
            uO.b.Error("KHR_draco_mesh_compression: Failed to export Draco-encoded primitive. Resulting glTF may be invalid. " + OO.message)
          }));
        this._encodePromises.push(hO), this._wasUsed = !0
      }
      async preGenerateBinaryAsync(OO) {
        this.enabled && (await Promise.all(this._encodePromises), this._bufferViewsUsed.forEach((KO => {
          OO.getPropertiesWithBufferView(KO).every((OO => this._accessorsUsed.has(OO))) && OO.removeBufferView(KO)
        })), this._bufferViewsUsed.clear(), this._accessorsUsed.clear())
      }
    }
    let kb = !1;

    function UX() {
      kb || (kb = !0, rb.RegisterExtension(WX, (OO => new tb(OO))))
    }
    UX();
    var Ob = pO(39601);
    const Kb = "KHR_lights_punctual",
      pb = {
        name: "",
        color: [1, 1, 1],
        intensity: 1,
        range: Number.MAX_VALUE
      },
      Xb = {
        innerConeAngle: 0,
        outerConeAngle: Math.PI / 4
      },
      be = HO.o.Backward();
    class eb {
      constructor(OO) {
        this.name = Kb, this.enabled = !0, this.required = !1, this._exporter = OO
      }
      dispose() {
        this._lights = null
      }
      get wasUsed() {
        return !!this._lights
      }
      onExporting() {
        this._exporter._glTF.extensions[Kb] = this._lights
      }
      async postExportNodeAsync(OO, KO, pO, XO, bK) {
        return await new Promise((eO => {
          if (!(pO instanceof DX.b)) return void eO(KO);
          const lO = pO.getTypeID() == DX.b.LIGHTTYPEID_POINTLIGHT ? "point" : pO.getTypeID() == DX.b.LIGHTTYPEID_DIRECTIONALLIGHT ? "directional" : pO.getTypeID() == DX.b.LIGHTTYPEID_SPOTLIGHT ? "spot" : null;
          if (!lO || !(pO instanceof Ob.e)) return uO.b.Warn(`${OO}: Light ${pO.name} is not supported in ${Kb}`), void eO(KO);
          if (pO.falloffType !== DX.b.FALLOFF_GLTF && uO.b.Warn(`${OO}: Light falloff for ${pO.name} does not match the ${Kb} specification!`), !pO.position.soO(0, 0, 0)) {
            const OO = HO.j.WX[0].NhO(pO.position);
            bK && Zp(OO), KO.translation = OO.WhO()
          }
          if ("point" !== lO) {
            const OO = pO.direction.normalizeToRef(HO.j.WX[0]);
            bK && Zp(OO);
            const XO = HO.g.FromUnitVectorsToRef(be, OO, HO.j.Quaternion[0]);
            HO.g.IsIdentity(XO) || (KO.rotation = XO.WhO())
          }
          const vK = {
            type: lO,
            name: pO.name,
            color: pO.diffuse.WhO(),
            intensity: pO.intensity,
            range: pO.range
          };
          if (tX(vK, pb), "spot" === lO) {
            const OO = pO;
            vK.spot = {
              innerConeAngle: OO.innerAngle / 2,
              outerConeAngle: OO.angle / 2
            }, tX(vK.spot, Xb)
          }
          this._lights || (this._lights = {
            lights: []
          }), this._lights.lights.push(vK);
          const CO = {
              light: this._lights.lights.length - 1
            },
            hO = pO.parent;
          if (hO && np(pO, hO)) {
            const OO = XO.get(hO);
            if (OO) {
              const pO = this._exporter._nodes[OO];
              return xX(KO, pO), pO.extensions || (pO.extensions = {}), pO.extensions[Kb] = CO, void eO(null)
            }
          }
          KO.extensions || (KO.extensions = {}), KO.extensions[Kb] = CO, eO(KO)
        }))
      }
    }
    let lb = !1;

    function ve() {
      lb || (lb = !0, rb.RegisterExtension(Kb, (OO => new eb(OO))))
    }
    ve();
    const Cb = "KHR_interactivity";
    class hb {
      constructor(OO) {
        this._exporter = OO, this.name = Cb, this.enabled = !!OO.options.khrInteractivity, this.required = OO.options.khrInteractivity?.required ?? !1
      }
      dispose() {
        this._exporter = null
      }
      get wasUsed() {
        return this.enabled
      }
      onExporting() {
        var OO, KO, pO;
        const XO = this._exporter.options.khrInteractivity;
        if (!XO) return;
        const bK = XO.build({
          getNodeCount: () => this._exporter._nodes.length,
          getNodeIndex: OO => this._exporter._getNodeIndex(OO),
          getAnimationIndex: OO => this._exporter._getAnimationIndex(OO),
          getCameraIndex: OO => this._exporter._getCameraIndex(OO),
          getMaterialIndex: OO => this._exporter._getMaterialIndex(OO),
          getRootIndex: (OO, KO) => this._exporter._getRootIndex(OO, KO),
          setNodeExtension: (OO, KO, pO) => this._exporter._setNodeExtension(OO, KO, pO)
        });
        this._exporter._glTF.extensions[Cb] = bK;
        for (const eO of XO.additionalExtensionsUsed)(OO = this._exporter._glTF).extensionsUsed || (OO.extensionsUsed = []), -1 === this._exporter._glTF.extensionsUsed.indexOf(eO) && this._exporter._glTF.extensionsUsed.push(eO);
        for (const eO of XO.additionalExtensionsRequired)(KO = this._exporter._glTF).extensionsUsed || (KO.extensionsUsed = []), -1 === this._exporter._glTF.extensionsUsed.indexOf(eO) && this._exporter._glTF.extensionsUsed.push(eO), (pO = this._exporter._glTF).extensionsRequired || (pO.extensionsRequired = []), -1 === this._exporter._glTF.extensionsRequired.indexOf(eO) && this._exporter._glTF.extensionsRequired.push(eO)
      }
    }
    let Db = !1;

    function Mb() {
      Db || (Db = !0, rb.RegisterExtension(Cb, (OO => new hb(OO)), 200))
    }
    Mb();
    const ae = "EXT_lights_area",
      ob = {
        name: "",
        color: [1, 1, 1],
        intensity: 1,
        size: 1
      },
      Fb = {
        aspect: 1
      },
      Vb = HO.o.Backward();
    class Lb {
      constructor(OO) {
        this.name = ae, this.enabled = !0, this.required = !1, this._exporter = OO
      }
      dispose() {
        this._lights = null
      }
      get wasUsed() {
        return !!this._lights
      }
      onExporting() {
        this._exporter._glTF.extensions[ae] = this._lights
      }
      async postExportNodeAsync(OO, KO, pO, XO, bK) {
        return await new Promise((eO => {
          if (!(pO instanceof DX.b)) return void eO(KO);
          const lO = pO.getTypeID() == DX.b.LIGHTTYPEID_RECT_AREALIGHT ? "rect" : null;
          if (!lO) return uO.b.Warn(`${OO}: Light ${pO.name} is not supported in ${ae}`), void eO(KO);
          const vK = pO;
          if (vK.falloffType !== DX.b.FALLOFF_GLTF && uO.b.Warn(`${OO}: Light falloff for ${pO.name} does not match the ${ae} specification!`), !vK.position.soO(0, 0, 0)) {
            const OO = HO.j.WX[0].NhO(vK.position);
            bK && Zp(OO), KO.translation = OO.WhO()
          }
          const CO = HO.o.Forward();
          bK && Zp(CO);
          const hO = HO.g.FromUnitVectorsToRef(Vb, CO, HO.j.Quaternion[0]);
          HO.g.IsIdentity(hO) || (KO.rotation = hO.WhO());
          const DO = {
            type: lO,
            name: vK.name,
            color: vK.diffuse.WhO(),
            intensity: vK.intensity,
            size: vK.height,
            rect: {
              aspect: vK.width / vK.height
            }
          };
          tX(DO, ob), DO.rect && tX(DO.rect, Fb), this._lights || (this._lights = {
            lights: []
          }), this._lights.lights.push(DO);
          const MO = {
              light: this._lights.lights.length - 1
            },
            aK = pO.parent;
          if (aK && np(vK, aK)) {
            const OO = XO.get(aK);
            if (OO) {
              const pO = this._exporter._nodes[OO];
              return xX(KO, pO), pO.extensions || (pO.extensions = {}), pO.extensions[ae] = MO, void eO(null)
            }
          }
          KO.extensions || (KO.extensions = {}), KO.extensions[ae] = MO, eO(KO)
        }))
      }
    }
    let Qb = !1;

    function ze() {
      Qb || (Qb = !0, rb.RegisterExtension(ae, (OO => new Lb(OO))))
    }
    ze();
    const Ab = "KHR_materials_anisotropy";
    class fb {
      constructor(OO) {
        this.name = Ab, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._anisoTexturesMap = {}, this._exporter = OO
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        if (pO instanceof TK) {
          if (pO.anisotropy.isEnabled && !pO.anisotropy.legacy) return pO.anisotropy.texture && XO.push(pO.anisotropy.texture), XO
        } else if (pO instanceof kp && pO.specularRoughnessAnisotropy > 0) {
          const OO = function(OO) {
            const KO = OO.specularRoughnessAnisotropyTexture,
              pO = OO.geometryTangentTexture;
            return `${KO&&KO.getInternalTexture()?KO.getInternalTexture().uniqueId:"NoStrength"}_${pO&&pO.getInternalTexture()?pO.getInternalTexture().uniqueId:"NoTangent"}`
          }(pO);
          if (this._anisoTexturesMap[OO]) XO.push(this._anisoTexturesMap[OO]);
          else {
            const KO = await async function(OO) {
              const KO = OO.JKO(),
                pO = OO.specularRoughnessAnisotropyTexture,
                XO = OO.geometryTangentTexture;
              return pO || XO ? await lp("AnisotropyTexture", hp(XO ? vX(XO, 0) : Cp(1), XO ? vX(XO, 1) : Cp(0), pO ? vX(pO, 0) : Cp(1)), KO) : null
            }(pO);
            KO && (XO.push(KO), this._anisoTexturesMap[OO] = KO)
          }
          return XO
        }
        return []
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          var XO;
          if (pO instanceof TK) {
            if (!pO.anisotropy.isEnabled || pO.anisotropy.legacy) return void OO(KO);
            this._wasUsed = !0, KO.extensions = KO.extensions || {};
            const XO = this._exporter._materialExporter.getTextureInfo(pO.anisotropy.texture),
              bK = {
                anisotropyStrength: pO.anisotropy.intensity,
                anisotropyRotation: pO.anisotropy.angle,
                anisotropyTexture: XO ?? void 0
              };
            null !== bK.anisotropyTexture && this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[Ab] = bK
          } else if (pO instanceof kp && pO.specularRoughnessAnisotropy > 0) {
            this._wasUsed = !0, KO.extensions = KO.extensions || {};
            let bK = pO.specularRoughnessTexture;
            pO._useRoughnessFromMetallicTextureGreen && (bK = pO.baseMetalnessTexture);
            const eO = this._anisoTexturesMap[pO.id];
            if (!bK && !eO) {
              let XO = pO.specularRoughness,
                bK = pO.specularRoughnessAnisotropy;
              if (!pO._useGltfStyleAnisotropy) {
                const OO = function(OO, KO) {
                  const pO = OO * OO,
                    XO = pO * Math.sqrt(2 / (1 + (1 - KO) * (1 - KO))),
                    bK = (1 - KO) * XO;
                  return {
                    newBaseRoughness: Math.sqrt(bK),
                    newAnisotropyStrength: Math.min(Math.sqrt((XO - pO) / Math.max(1 - pO, 1e-4)), 1)
                  }
                }(pO.specularRoughness, pO.specularRoughnessAnisotropy);
                XO = OO.newBaseRoughness, bK = OO.newAnisotropyStrength
              }
              KO.pbrMetallicRoughness && (KO.pbrMetallicRoughness.roughnessFactor = XO);
              const eO = {
                anisotropyStrength: bK,
                anisotropyRotation: pO.geometryTangentAngle + .5 * Math.PI,
                anisotropyTexture: void 0
              };
              return KO.extensions[Ab] = eO, OO(KO)
            }
            const lO = eO ? this._exporter._materialExporter.getTextureInfo(eO) : null,
              vK = {
                anisotropyStrength: pO.specularRoughnessAnisotropy,
                anisotropyRotation: pO.geometryTangentAngle,
                anisotropyTexture: lO || void 0,
                extensions: {}
              };
            pO._useGltfStyleAnisotropy || (KO.extensions.KHR_materials_openpbr = {}, (XO = this._exporter._glTF).extensionsUsed || (XO.extensionsUsed = []), -1 === this._exporter._glTF.extensionsUsed.indexOf("KHR_materials_openpbr") && this._exporter._glTF.extensionsUsed.push("KHR_materials_openpbr")), this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[Ab] = vK
          }
          OO(KO)
        }))
      }
    }
    let db = !1;

    function Tb() {
      db || (db = !0, rb.RegisterExtension(Ab, (OO => new fb(OO))))
    }
    Tb();
    const Nb = "KHR_materials_clearcoat";

    function Ib(OO, KO) {
      const pO = new jK.e(KO.name, KO.JKO());
      return pO._texture = OO, pO.coordinatesIndex = KO.coordinatesIndex, KO instanceof jK.e && (pO.uOffset = KO.uOffset, pO.vOffset = KO.vOffset, pO.uScale = KO.uScale, pO.vScale = KO.vScale, pO.wAng = KO.wAng), pO.wrapU = KO.wrapU, pO.wrapV = KO.wrapV, pO
    }
    class ye {
      constructor(OO) {
        this.name = Nb, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._mergedTexturesMap = {}, this._cachedInternalTexturesMap = {}, this._exporter = OO
      }
      dispose() {
        for (const OO of Object.keys(this._mergedTexturesMap)) {
          this._mergedTexturesMap[OO].dispose()
        }
        this._mergedTexturesMap = {};
        for (const OO of Object.keys(this._cachedInternalTexturesMap)) {
          this._cachedInternalTexturesMap[OO].dispose()
        }
        this._cachedInternalTexturesMap = {}
      }
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        if (pO instanceof TK) {
          if (pO.clearCoat.isEnabled) return pO.clearCoat.texture && XO.push(pO.clearCoat.texture), !pO.clearCoat.useRoughnessFromMainTexture && pO.clearCoat.textureRoughness && XO.push(pO.clearCoat.textureRoughness), pO.clearCoat.bumpTexture && XO.push(pO.clearCoat.bumpTexture), XO
        } else if (pO instanceof kp && pO.coatWeight > 0) {
          let OO = !1;
          if (pO.coatWeightTexture ? pO.coatRoughnessTexture ? pO._useCoatRoughnessFromGreenChannel && pO.coatWeightTexture.getInternalTexture() === pO.coatRoughnessTexture.getInternalTexture() ? (XO.push(pO.coatWeightTexture), XO.push(pO.coatRoughnessTexture)) : OO = !0 : XO.push(pO.coatWeightTexture) : pO.coatRoughnessTexture && (pO._useCoatRoughnessFromGreenChannel ? XO.push(pO.coatRoughnessTexture) : OO = !0), OO) {
            const OO = function(OO) {
              const KO = OO.coatWeightTexture,
                pO = KO && KO.getInternalTexture() ? KO.getInternalTexture().uniqueId : "NoCoat",
                XO = OO.coatRoughnessTexture;
              return `${pO}_${XO&&XO.getInternalTexture()?XO.getInternalTexture().uniqueId:"NoRoughness"}`
            }(pO);
            if (!this._cachedInternalTexturesMap[OO]) {
              const KO = await async function(OO) {
                const KO = OO.JKO(),
                  pO = OO.coatWeightTexture,
                  XO = OO.coatRoughnessTexture;
                return pO || XO ? (await lp("CoatTexture", hp(pO ? vX(pO, 0) : Cp(1), XO ? vX(XO, OO._useCoatRoughnessFromGreenChannel ? 1 : 0) : Cp(1)), KO)).getInternalTexture() : null
              }(pO);
              KO && (this._cachedInternalTexturesMap[OO] = KO)
            }
            this._cachedInternalTexturesMap[OO] && (pO.coatWeightTexture && (this._mergedTexturesMap[pO.coatWeightTexture.uniqueId] = Ib(this._cachedInternalTexturesMap[OO], pO.coatWeightTexture), XO.push(this._mergedTexturesMap[pO.coatWeightTexture.uniqueId])), pO.coatRoughnessTexture && (this._mergedTexturesMap[pO.coatRoughnessTexture.uniqueId] = Ib(this._cachedInternalTexturesMap[OO], pO.coatRoughnessTexture), XO.push(this._mergedTexturesMap[pO.coatRoughnessTexture.uniqueId])))
          }
          return pO.geometryCoatNormalTexture && XO.push(pO.geometryCoatNormalTexture), XO
        }
        return []
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          if (pO instanceof TK) {
            if (!pO.clearCoat.isEnabled) return void OO(KO);
            this._wasUsed = !0, KO.extensions = KO.extensions || {};
            const XO = this._exporter._materialExporter.getTextureInfo(pO.clearCoat.texture);
            let bK;
            bK = pO.clearCoat.useRoughnessFromMainTexture ? this._exporter._materialExporter.getTextureInfo(pO.clearCoat.texture) : this._exporter._materialExporter.getTextureInfo(pO.clearCoat.textureRoughness), pO.clearCoat.isTintEnabled && IK.k.Warn(`Clear Color tint is not supported for glTF export. Ignoring for: ${pO.name}`), pO.clearCoat.remapF0OnInterfaceChange && IK.k.Warn(`Clear Color F0 remapping is not supported for glTF export. Ignoring for: ${pO.name}`);
            const eO = this._exporter._materialExporter.getTextureInfo(pO.clearCoat.bumpTexture),
              lO = {
                clearcoatFactor: pO.clearCoat.intensity,
                clearcoatTexture: XO ?? void 0,
                clearcoatRoughnessFactor: pO.clearCoat.roughness,
                clearcoatRoughnessTexture: bK ?? void 0,
                clearcoatNormalTexture: eO ?? void 0
              };
            null === lO.clearcoatTexture && null === lO.clearcoatRoughnessTexture && null === lO.clearcoatRoughnessTexture || this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[Nb] = lO
          } else if (pO instanceof kp) {
            if (0 == pO.coatWeight) return void OO(KO);
            let XO, bK, eO, lO;
            this._wasUsed = !0, KO.extensions = KO.extensions || {}, pO.coatWeightTexture && (XO = this._mergedTexturesMap[pO.coatWeightTexture.uniqueId], bK = this._exporter._materialExporter.getTextureInfo(XO)), pO.coatRoughnessTexture && (eO = this._mergedTexturesMap[pO.coatRoughnessTexture.uniqueId], lO = this._exporter._materialExporter.getTextureInfo(eO)), pO.coatColorTexture && IK.k.Warn(`Clear Color tint is not supported for glTF export. Ignoring for: ${pO.name}`);
            const vK = this._exporter._materialExporter.getTextureInfo(pO.geometryCoatNormalTexture),
              CO = {
                clearcoatFactor: pO.coatWeight,
                clearcoatTexture: bK ?? void 0,
                clearcoatRoughnessFactor: pO.coatRoughness,
                clearcoatRoughnessTexture: lO ?? void 0,
                clearcoatNormalTexture: vK ?? void 0
              };
            null === CO.clearcoatTexture && null === CO.clearcoatRoughnessTexture && null === CO.clearcoatRoughnessTexture || this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[Nb] = CO
          }
          OO(KO)
        }))
      }
    }
    let ge = !1;

    function ub() {
      ge || (ge = !0, rb.RegisterExtension(Nb, (OO => new ye(OO))))
    }
    ub();
    const Eb = "KHR_materials_coat";

    function je(OO) {
      const KO = OO.coatRoughnessAnisotropyTexture,
        pO = OO.geometryCoatTangentTexture;
      return `${KO&&KO.getInternalTexture()?KO.getInternalTexture().uniqueId:"NoStrength"}_${pO&&pO.getInternalTexture()?pO.getInternalTexture().uniqueId:"NoTangent"}`
    }

    function Yb(OO, KO) {
      const pO = new jK.e(KO.name, KO.JKO());
      return pO._texture = OO, pO.coordinatesIndex = KO.coordinatesIndex, KO instanceof jK.e && (pO.uOffset = KO.uOffset, pO.vOffset = KO.vOffset, pO.uScale = KO.uScale, pO.vScale = KO.vScale, pO.wAng = KO.wAng), pO.wrapU = KO.wrapU, pO.wrapV = KO.wrapV, pO
    }
    class wb {
      constructor(OO) {
        this.name = Eb, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._mergedTexturesMap = {}, this._cachedInternalTexturesMap = {}, this._exporter = OO
      }
      dispose() {
        for (const OO of Object.keys(this._mergedTexturesMap)) {
          this._mergedTexturesMap[OO].dispose()
        }
        this._mergedTexturesMap = {};
        for (const OO of Object.keys(this._cachedInternalTexturesMap)) {
          this._cachedInternalTexturesMap[OO].dispose()
        }
        this._cachedInternalTexturesMap = {}
      }
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        if (pO instanceof TK) {
          if (pO.clearCoat.isEnabled) return pO.clearCoat.texture && XO.push(pO.clearCoat.texture), !pO.clearCoat.useRoughnessFromMainTexture && pO.clearCoat.textureRoughness && XO.push(pO.clearCoat.textureRoughness), pO.clearCoat.bumpTexture && XO.push(pO.clearCoat.bumpTexture), pO.clearCoat.tintTexture && XO.push(pO.clearCoat.tintTexture), XO
        } else if (pO instanceof kp && pO.coatWeight > 0) {
          let OO = !1;
          if (pO.coatWeightTexture ? pO.coatRoughnessTexture ? pO._useCoatRoughnessFromGreenChannel && pO.coatWeightTexture.getInternalTexture() === pO.coatRoughnessTexture.getInternalTexture() ? (XO.push(pO.coatWeightTexture), XO.push(pO.coatRoughnessTexture)) : OO = !0 : XO.push(pO.coatWeightTexture) : pO.coatRoughnessTexture && (pO._useCoatRoughnessFromGreenChannel ? XO.push(pO.coatRoughnessTexture) : OO = !0), OO) {
            const OO = function(OO) {
              const KO = OO.coatWeightTexture,
                pO = KO && KO.getInternalTexture() ? KO.getInternalTexture().uniqueId : "NoCoat",
                XO = OO.coatRoughnessTexture;
              return `${pO}_${XO&&XO.getInternalTexture()?XO.getInternalTexture().uniqueId:"NoRoughness"}`
            }(pO);
            if (!this._cachedInternalTexturesMap[OO]) {
              const KO = await async function(OO) {
                const KO = OO.JKO(),
                  pO = OO.coatWeightTexture,
                  XO = OO.coatRoughnessTexture;
                return pO || XO ? (await lp("CoatTexture", hp(pO ? vX(pO, 0) : Cp(1), XO ? vX(XO, OO._useCoatRoughnessFromGreenChannel ? 1 : 0) : Cp(1)), KO)).getInternalTexture() : null
              }(pO);
              KO && (this._cachedInternalTexturesMap[OO] = KO)
            }
            this._cachedInternalTexturesMap[OO] && (pO.coatWeightTexture && (this._mergedTexturesMap[pO.coatWeightTexture.uniqueId] = Yb(this._cachedInternalTexturesMap[OO], pO.coatWeightTexture), XO.push(this._mergedTexturesMap[pO.coatWeightTexture.uniqueId])), pO.coatRoughnessTexture && (this._mergedTexturesMap[pO.coatRoughnessTexture.uniqueId] = Yb(this._cachedInternalTexturesMap[OO], pO.coatRoughnessTexture), XO.push(this._mergedTexturesMap[pO.coatRoughnessTexture.uniqueId])))
          }
          if (pO.geometryCoatNormalTexture && XO.push(pO.geometryCoatNormalTexture), pO.coatColorTexture && XO.push(pO.coatColorTexture), pO.coatRoughnessAnisotropy > 0) {
            const OO = je(pO);
            if (this._mergedTexturesMap[OO]) XO.push(this._mergedTexturesMap[OO]);
            else {
              const KO = await async function(OO) {
                const KO = OO.JKO(),
                  pO = OO.coatRoughnessAnisotropyTexture,
                  XO = OO.geometryCoatTangentTexture;
                return pO || XO ? await lp("AnisotropyTexture", hp(XO ? vX(XO, 0) : Cp(1), XO ? vX(XO, 1) : Cp(0), pO ? vX(pO, 0) : Cp(1)), KO) : null
              }(pO);
              KO && (XO.push(KO), this._mergedTexturesMap[OO] = KO)
            }
            return XO
          }
          return XO
        }
        return []
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          var XO;
          if (pO instanceof TK) {
            if (!pO.clearCoat.isEnabled) return void OO(KO);
            this._wasUsed = !0, KO.extensions = KO.extensions || {};
            const XO = this._exporter._materialExporter.getTextureInfo(pO.clearCoat.texture);
            let bK, eO;
            bK = pO.clearCoat.useRoughnessFromMainTexture ? this._exporter._materialExporter.getTextureInfo(pO.clearCoat.texture) : this._exporter._materialExporter.getTextureInfo(pO.clearCoat.textureRoughness), pO.clearCoat.isTintEnabled && (eO = this._exporter._materialExporter.getTextureInfo(pO.clearCoat.tintTexture));
            const lO = this._exporter._materialExporter.getTextureInfo(pO.clearCoat.bumpTexture),
              vK = pO.clearCoat.indexOfRefraction,
              CO = {
                coatFactor: pO.clearCoat.intensity,
                coatTexture: XO ?? void 0,
                coatRoughnessFactor: pO.clearCoat.roughness,
                coatRoughnessTexture: bK ?? void 0,
                coatNormalTexture: lO ?? void 0,
                coatColorFactor: pO.clearCoat.tintColor.WhO(),
                coatColorTexture: eO ?? void 0,
                coatIor: 1.5 !== vK ? vK : void 0
              };
            null === CO.coatTexture && null === CO.coatRoughnessTexture && null === CO.coatRoughnessTexture && null === CO.coatColorTexture || this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[Eb] = CO
          } else if (pO instanceof kp) {
            if (0 == pO.coatWeight) return void OO(KO);
            let bK, eO, lO, vK;
            this._wasUsed = !0, KO.extensions = KO.extensions || {}, pO.coatWeightTexture && (bK = this._mergedTexturesMap[pO.coatWeightTexture.uniqueId] ? this._mergedTexturesMap[pO.coatWeightTexture.uniqueId] : pO.coatWeightTexture, eO = this._exporter._materialExporter.getTextureInfo(bK)), pO.coatRoughnessTexture && (lO = this._mergedTexturesMap[pO.coatRoughnessTexture.uniqueId] ? this._mergedTexturesMap[pO.coatRoughnessTexture.uniqueId] : pO.coatRoughnessTexture, vK = this._exporter._materialExporter.getTextureInfo(lO));
            const CO = this._exporter._materialExporter.getTextureInfo(pO.geometryCoatNormalTexture),
              hO = this._exporter._materialExporter.getTextureInfo(pO.coatColorTexture),
              DO = pO.coatIor,
              MO = pO.coatDarkening,
              aK = pO.coatRoughnessTexture,
              oO = je(pO),
              FO = this._mergedTexturesMap[oO];
            let VO, LO = 0,
              QO = 0;
            if (pO.coatRoughnessAnisotropy > 0) {
              if (aK || FO) {
                const OO = FO ? this._exporter._materialExporter.getTextureInfo(FO) : null;
                LO = pO.coatRoughnessAnisotropy, QO = pO.geometryCoatTangentAngle, VO = OO || void 0
              } else {
                let OO = pO.coatRoughness,
                  XO = pO.coatRoughnessAnisotropy;
                if (!pO._useGltfStyleAnisotropy) {
                  const KO = function(OO, KO) {
                    const pO = OO * OO,
                      XO = pO * Math.sqrt(2 / (1 + (1 - KO) * (1 - KO))),
                      bK = (1 - KO) * XO;
                    return {
                      newBaseRoughness: Math.sqrt(bK),
                      newAnisotropyStrength: Math.min(Math.sqrt((XO - pO) / Math.max(1 - pO, 1e-4)), 1)
                    }
                  }(pO.coatRoughness, pO.coatRoughnessAnisotropy);
                  OO = KO.newBaseRoughness, XO = KO.newAnisotropyStrength
                }
                KO.pbrMetallicRoughness && (KO.pbrMetallicRoughness.roughnessFactor = OO), LO = XO, QO = pO.geometryCoatTangentAngle + .5 * Math.PI, VO = void 0
              }
              pO._useGltfStyleAnisotropy || (KO.extensions.KHR_materials_openpbr = {}, (XO = this._exporter._glTF).extensionsUsed || (XO.extensionsUsed = []), -1 === this._exporter._glTF.extensionsUsed.indexOf("KHR_materials_openpbr") && this._exporter._glTF.extensionsUsed.push("KHR_materials_openpbr"))
            }
            const zK = {
              coatFactor: pO.coatWeight,
              coatTexture: eO ?? void 0,
              coatRoughnessFactor: pO.coatRoughness,
              coatRoughnessTexture: vK ?? void 0,
              coatNormalTexture: CO ?? void 0,
              coatColorFactor: pO.coatColor.WhO(),
              coatColorTexture: hO ?? void 0,
              coatIor: 1.5 !== DO ? DO : void 0,
              coatDarkeningFactor: 1 !== MO ? MO : void 0,
              coatAnisotropyRotation: QO,
              coatAnisotropyStrength: LO,
              coatAnisotropyTexture: VO
            };
            null === zK.coatTexture && null === zK.coatRoughnessTexture && null === zK.coatRoughnessTexture && null === zK.coatAnisotropyTexture && null === zK.coatColorTexture || this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[Eb] = zK
          }
          OO(KO)
        }))
      }
    }
    let ie = !1;

    function re() {
      ie || (ie = !0, rb.RegisterExtension(Eb, (OO => new wb(OO))))
    }
    re();
    let Pb = (() => {
      var OO, KO, pO, XO, bK, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO, QO, zK, AO, fO, dO, TO, NO, IO, uO, EO, jK, YO, wO, iK, PO, mK, sO, HO, RO, SO, JO, cK, BO, ZO, qK, xK, nO, WO, tK, kK, UO, OK, KK, pK, XK, bp, eK, lK, vp, CK, hK, DK, MK, ap, oK, FK, VK, LK, QK, zp, AK;
      let fK, dK, IK, yp, gp, uK, EK, jp, YK, wK, ip, rp, PK, mp, sK, HK, RK, SK, JK, cp, BK, ZK, GK, qp, xp, nK, WK, tp, kp, UK, Op, Kp, pp, Xp, bX, ep, lp, vX, Cp, hp, Dp, Mp, aX, op, Fp, Vp, Lp, Qp, zX, Ap, fp, dp, Tp, Np, Ip, yX, gX, upO, Ep, jX, Yp, wp, iX, rX, Pp, mX, sp, Hp, Rp = TK,
        Sp = [],
        Jp = [],
        cX = [],
        Bp = [],
        Zp = [],
        Gp = [],
        qX = [],
        xX = [],
        np = [],
        Wp = [],
        tX = [],
        kX = [],
        Up = [],
        OX = [],
        KX = [],
        pX = [],
        XX = [],
        bb = [],
        eX = [],
        lX = [],
        vb = [],
        CX = [],
        hX = [],
        DX = [],
        MX = [],
        ab = [],
        oX = [],
        FX = [],
        VX = [],
        LX = [],
        QX = [],
        zb = [],
        AX = [],
        fX = [],
        dX = [],
        TX = [],
        NX = [],
        IX = [],
        yb = [],
        gb = [],
        uX = [],
        EX = [],
        jb = [],
        YX = [],
        wX = [],
        ib = [],
        rb = [],
        PX = [],
        mb = [],
        sX = [],
        HX = [],
        RX = [],
        SX = [],
        JX = [],
        cb = [],
        BX = [],
        ZX = [],
        GX = [],
        qb = [],
        xb = [],
        nX = [],
        WX = [],
        tb = [],
        kb = [],
        UX = [],
        Ob = [],
        Kb = [],
        pb = [],
        Xb = [],
        be = [],
        eb = [],
        lb = [],
        ve = [],
        Cb = [],
        hb = [],
        Db = [],
        Mb = [],
        ae = [],
        ob = [],
        Fb = [],
        Vb = [],
        Lb = [],
        Qb = [],
        ze = [],
        Ab = [],
        fb = [],
        db = [],
        Tb = [],
        Nb = [],
        Ib = [],
        ye = [],
        ge = [],
        ub = [],
        Eb = [],
        je = [],
        Yb = [],
        wb = [],
        ie = [],
        re = [],
        Pb = [],
        me = [],
        sb = [],
        Hb = [],
        Rb = [],
        Sb = [],
        Jb = [],
        ce = [],
        Bb = [],
        Zb = [],
        Gb = [],
        qe = [],
        xe = [],
        nb = [],
        Wb = [],
        te = [],
        ke = [],
        Ub = [],
        Oe = [],
        Ke = [],
        pe = [],
        Xe = [],
        bl = [],
        ee = [],
        le = [],
        vl = [],
        Ce = [],
        he = [],
        De = [],
        Me = [],
        al = [],
        oe = [],
        Fe = [],
        Ve = [];
      return OO = class extends Rp {
        get directIntensity() {
          return (0, yK.b)(this, KO, "f")
        }
        set directIntensity(OO) {
          (0, yK.e)(this, KO, OO, "f")
        }
        get emissiveIntensity() {
          return (0, yK.b)(this, pO, "f")
        }
        set emissiveIntensity(OO) {
          (0, yK.e)(this, pO, OO, "f")
        }
        get environmentIntensity() {
          return (0, yK.b)(this, XO, "f")
        }
        set environmentIntensity(OO) {
          (0, yK.e)(this, XO, OO, "f")
        }
        get specularIntensity() {
          return (0, yK.b)(this, bK, "f")
        }
        set specularIntensity(OO) {
          (0, yK.e)(this, bK, OO, "f")
        }
        get disableBumpMap() {
          return (0, yK.b)(this, lO, "f")
        }
        set disableBumpMap(OO) {
          (0, yK.e)(this, lO, OO, "f")
        }
        get albedoTexture() {
          return (0, yK.b)(this, vK, "f")
        }
        set albedoTexture(OO) {
          (0, yK.e)(this, vK, OO, "f")
        }
        get baseWeightTexture() {
          return (0, yK.b)(this, CO, "f")
        }
        set baseWeightTexture(OO) {
          (0, yK.e)(this, CO, OO, "f")
        }
        get baseDiffuseRoughnessTexture() {
          return (0, yK.b)(this, hO, "f")
        }
        set baseDiffuseRoughnessTexture(OO) {
          (0, yK.e)(this, hO, OO, "f")
        }
        get ambientTexture() {
          return (0, yK.b)(this, DO, "f")
        }
        set ambientTexture(OO) {
          (0, yK.e)(this, DO, OO, "f")
        }
        get ambientTextureStrength() {
          return (0, yK.b)(this, MO, "f")
        }
        set ambientTextureStrength(OO) {
          (0, yK.e)(this, MO, OO, "f")
        }
        get ambientTextureImpactOnAnalyticalLights() {
          return (0, yK.b)(this, aK, "f")
        }
        set ambientTextureImpactOnAnalyticalLights(OO) {
          (0, yK.e)(this, aK, OO, "f")
        }
        get opacityTexture() {
          return (0, yK.b)(this, oO, "f")
        }
        set opacityTexture(OO) {
          (0, yK.e)(this, oO, OO, "f")
        }
        get reflectionTexture() {
          return (0, yK.b)(this, FO, "f")
        }
        set reflectionTexture(OO) {
          (0, yK.e)(this, FO, OO, "f")
        }
        get emissiveTexture() {
          return (0, yK.b)(this, VO, "f")
        }
        set emissiveTexture(OO) {
          (0, yK.e)(this, VO, OO, "f")
        }
        get reflectivityTexture() {
          return (0, yK.b)(this, LO, "f")
        }
        set reflectivityTexture(OO) {
          (0, yK.e)(this, LO, OO, "f")
        }
        get metallicTexture() {
          return (0, yK.b)(this, QO, "f")
        }
        set metallicTexture(OO) {
          (0, yK.e)(this, QO, OO, "f")
        }
        get metallic() {
          return (0, yK.b)(this, zK, "f")
        }
        set metallic(OO) {
          (0, yK.e)(this, zK, OO, "f")
        }
        get roughness() {
          return (0, yK.b)(this, AO, "f")
        }
        set roughness(OO) {
          (0, yK.e)(this, AO, OO, "f")
        }
        get metallicF0Factor() {
          return (0, yK.b)(this, fO, "f")
        }
        set metallicF0Factor(OO) {
          (0, yK.e)(this, fO, OO, "f")
        }
        get metallicReflectanceColor() {
          return (0, yK.b)(this, dO, "f")
        }
        set metallicReflectanceColor(OO) {
          (0, yK.e)(this, dO, OO, "f")
        }
        get useOnlyMetallicFromMetallicReflectanceTexture() {
          return (0, yK.b)(this, TO, "f")
        }
        set useOnlyMetallicFromMetallicReflectanceTexture(OO) {
          (0, yK.e)(this, TO, OO, "f")
        }
        get metallicReflectanceTexture() {
          return (0, yK.b)(this, NO, "f")
        }
        set metallicReflectanceTexture(OO) {
          (0, yK.e)(this, NO, OO, "f")
        }
        get reflectanceTexture() {
          return (0, yK.b)(this, IO, "f")
        }
        set reflectanceTexture(OO) {
          (0, yK.e)(this, IO, OO, "f")
        }
        get microSurfaceTexture() {
          return (0, yK.b)(this, uO, "f")
        }
        set microSurfaceTexture(OO) {
          (0, yK.e)(this, uO, OO, "f")
        }
        get bumpTexture() {
          return (0, yK.b)(this, EO, "f")
        }
        set bumpTexture(OO) {
          (0, yK.e)(this, EO, OO, "f")
        }
        get lightmapTexture() {
          return (0, yK.b)(this, jK, "f")
        }
        set lightmapTexture(OO) {
          (0, yK.e)(this, jK, OO, "f")
        }
        get refractionTexture() {
          return this.subSurface.refractionTexture
        }
        set refractionTexture(OO) {
          this.subSurface.refractionTexture = OO, OO ? this.subSurface.isRefractionEnabled = !0 : this.subSurface.linkRefractionWithTransparency || (this.subSurface.isRefractionEnabled = !1)
        }
        get ambientColor() {
          return (0, yK.b)(this, YO, "f")
        }
        set ambientColor(OO) {
          (0, yK.e)(this, YO, OO, "f")
        }
        get albedoColor() {
          return (0, yK.b)(this, wO, "f")
        }
        set albedoColor(OO) {
          (0, yK.e)(this, wO, OO, "f")
        }
        get baseWeight() {
          return (0, yK.b)(this, iK, "f")
        }
        set baseWeight(OO) {
          (0, yK.e)(this, iK, OO, "f")
        }
        get baseDiffuseRoughness() {
          return (0, yK.b)(this, PO, "f")
        }
        set baseDiffuseRoughness(OO) {
          (0, yK.e)(this, PO, OO, "f")
        }
        get reflectivityColor() {
          return (0, yK.b)(this, mK, "f")
        }
        set reflectivityColor(OO) {
          (0, yK.e)(this, mK, OO, "f")
        }
        get reflectionColor() {
          return (0, yK.b)(this, sO, "f")
        }
        set reflectionColor(OO) {
          (0, yK.e)(this, sO, OO, "f")
        }
        get emissiveColor() {
          return (0, yK.b)(this, HO, "f")
        }
        set emissiveColor(OO) {
          (0, yK.e)(this, HO, OO, "f")
        }
        get microSurface() {
          return (0, yK.b)(this, RO, "f")
        }
        set microSurface(OO) {
          (0, yK.e)(this, RO, OO, "f")
        }
        get indexOfRefraction() {
          return this.subSurface.indexOfRefraction
        }
        set indexOfRefraction(OO) {
          this.subSurface.indexOfRefraction = OO
        }
        get invertRefractionY() {
          return this.subSurface.invertRefractionY
        }
        set invertRefractionY(OO) {
          this.subSurface.invertRefractionY = OO
        }
        get linkRefractionWithTransparency() {
          return this.subSurface.linkRefractionWithTransparency
        }
        set linkRefractionWithTransparency(OO) {
          this.subSurface.linkRefractionWithTransparency = OO, OO && (this.subSurface.isRefractionEnabled = !0)
        }
        get useLightmapAsShadowmap() {
          return (0, yK.b)(this, SO, "f")
        }
        set useLightmapAsShadowmap(OO) {
          (0, yK.e)(this, SO, OO, "f")
        }
        get useAlphaFromAlbedoTexture() {
          return (0, yK.b)(this, JO, "f")
        }
        set useAlphaFromAlbedoTexture(OO) {
          (0, yK.e)(this, JO, OO, "f")
        }
        get forceAlphaTest() {
          return (0, yK.b)(this, cK, "f")
        }
        set forceAlphaTest(OO) {
          (0, yK.e)(this, cK, OO, "f")
        }
        get alphaCutOff() {
          return (0, yK.b)(this, BO, "f")
        }
        set alphaCutOff(OO) {
          (0, yK.e)(this, BO, OO, "f")
        }
        get useSpecularOverAlpha() {
          return (0, yK.b)(this, ZO, "f")
        }
        set useSpecularOverAlpha(OO) {
          (0, yK.e)(this, ZO, OO, "f")
        }
        get useMicroSurfaceFromReflectivityMapAlpha() {
          return (0, yK.b)(this, qK, "f")
        }
        set useMicroSurfaceFromReflectivityMapAlpha(OO) {
          (0, yK.e)(this, qK, OO, "f")
        }
        get useRoughnessFromMetallicTextureAlpha() {
          return (0, yK.b)(this, xK, "f")
        }
        set useRoughnessFromMetallicTextureAlpha(OO) {
          (0, yK.e)(this, xK, OO, "f")
        }
        get useRoughnessFromMetallicTextureGreen() {
          return (0, yK.b)(this, nO, "f")
        }
        set useRoughnessFromMetallicTextureGreen(OO) {
          (0, yK.e)(this, nO, OO, "f")
        }
        get useMetallnessFromMetallicTextureBlue() {
          return (0, yK.b)(this, WO, "f")
        }
        set useMetallnessFromMetallicTextureBlue(OO) {
          (0, yK.e)(this, WO, OO, "f")
        }
        get useAmbientOcclusionFromMetallicTextureRed() {
          return (0, yK.b)(this, tK, "f")
        }
        set useAmbientOcclusionFromMetallicTextureRed(OO) {
          (0, yK.e)(this, tK, OO, "f")
        }
        get useAmbientInGrayScale() {
          return (0, yK.b)(this, kK, "f")
        }
        set useAmbientInGrayScale(OO) {
          (0, yK.e)(this, kK, OO, "f")
        }
        get useAutoMicroSurfaceFromReflectivityMap() {
          return (0, yK.b)(this, UO, "f")
        }
        set useAutoMicroSurfaceFromReflectivityMap(OO) {
          (0, yK.e)(this, UO, OO, "f")
        }
        get usePhysicalLightFalloff() {
          return this._lightFalloff === TK.LIGHTFALLOFF_PHYSICAL
        }
        set usePhysicalLightFalloff(OO) {
          OO !== this.usePhysicalLightFalloff && (this._markAllSubMeshesAsTexturesDirty(), this._lightFalloff = OO ? TK.LIGHTFALLOFF_PHYSICAL : TK.LIGHTFALLOFF_STANDARD)
        }
        get useGLTFLightFalloff() {
          return this._lightFalloff === TK.LIGHTFALLOFF_GLTF
        }
        set useGLTFLightFalloff(OO) {
          OO !== this.useGLTFLightFalloff && (this._markAllSubMeshesAsTexturesDirty(), this._lightFalloff = OO ? TK.LIGHTFALLOFF_GLTF : TK.LIGHTFALLOFF_STANDARD)
        }
        get useRadianceOverAlpha() {
          return (0, yK.b)(this, OK, "f")
        }
        set useRadianceOverAlpha(OO) {
          (0, yK.e)(this, OK, OO, "f")
        }
        get useObjectSpaceNormalMap() {
          return (0, yK.b)(this, KK, "f")
        }
        set useObjectSpaceNormalMap(OO) {
          (0, yK.e)(this, KK, OO, "f")
        }
        get useParallax() {
          return (0, yK.b)(this, pK, "f")
        }
        set useParallax(OO) {
          (0, yK.e)(this, pK, OO, "f")
        }
        get useParallaxOcclusion() {
          return (0, yK.b)(this, XK, "f")
        }
        set useParallaxOcclusion(OO) {
          (0, yK.e)(this, XK, OO, "f")
        }
        get parallaxScaleBias() {
          return (0, yK.b)(this, bp, "f")
        }
        set parallaxScaleBias(OO) {
          (0, yK.e)(this, bp, OO, "f")
        }
        get disableLighting() {
          return (0, yK.b)(this, eK, "f")
        }
        set disableLighting(OO) {
          (0, yK.e)(this, eK, OO, "f")
        }
        get forceIrradianceInFragment() {
          return (0, yK.b)(this, lK, "f")
        }
        set forceIrradianceInFragment(OO) {
          (0, yK.e)(this, lK, OO, "f")
        }
        get maxSimultaneousLights() {
          return (0, yK.b)(this, vp, "f")
        }
        set maxSimultaneousLights(OO) {
          (0, yK.e)(this, vp, OO, "f")
        }
        get invertNormalMapX() {
          return (0, yK.b)(this, CK, "f")
        }
        set invertNormalMapX(OO) {
          (0, yK.e)(this, CK, OO, "f")
        }
        get invertNormalMapY() {
          return (0, yK.b)(this, hK, "f")
        }
        set invertNormalMapY(OO) {
          (0, yK.e)(this, hK, OO, "f")
        }
        get twoSidedLighting() {
          return (0, yK.b)(this, DK, "f")
        }
        set twoSidedLighting(OO) {
          (0, yK.e)(this, DK, OO, "f")
        }
        get useAlphaFresnel() {
          return (0, yK.b)(this, MK, "f")
        }
        set useAlphaFresnel(OO) {
          (0, yK.e)(this, MK, OO, "f")
        }
        get useLinearAlphaFresnel() {
          return (0, yK.b)(this, ap, "f")
        }
        set useLinearAlphaFresnel(OO) {
          (0, yK.e)(this, ap, OO, "f")
        }
        get environmentBRDFTexture() {
          return (0, yK.b)(this, oK, "f")
        }
        set environmentBRDFTexture(OO) {
          (0, yK.e)(this, oK, OO, "f")
        }
        get forceNormalForward() {
          return (0, yK.b)(this, FK, "f")
        }
        set forceNormalForward(OO) {
          (0, yK.e)(this, FK, OO, "f")
        }
        get enableSpecularAntiAliasing() {
          return (0, yK.b)(this, VK, "f")
        }
        set enableSpecularAntiAliasing(OO) {
          (0, yK.e)(this, VK, OO, "f")
        }
        get useHorizonOcclusion() {
          return (0, yK.b)(this, LK, "f")
        }
        set useHorizonOcclusion(OO) {
          (0, yK.e)(this, LK, OO, "f")
        }
        get useRadianceOcclusion() {
          return (0, yK.b)(this, QK, "f")
        }
        set useRadianceOcclusion(OO) {
          (0, yK.e)(this, QK, OO, "f")
        }
        get unlit() {
          return (0, yK.b)(this, zp, "f")
        }
        set unlit(OO) {
          (0, yK.e)(this, zp, OO, "f")
        }
        get applyDecalMapAfterDetailMap() {
          return (0, yK.b)(this, AK, "f")
        }
        set applyDecalMapAfterDetailMap(OO) {
          (0, yK.e)(this, AK, OO, "f")
        }
        constructor(eO, gK) {
          super(eO, gK, arguments.length > 2 && void 0 !== arguments[2] && arguments[2]), KO.set(this, ((0, yK.i)(this, Sp), (0, yK.i)(this, Jp, 1))), pO.set(this, ((0, yK.i)(this, cX), (0, yK.i)(this, Bp, 1))), XO.set(this, ((0, yK.i)(this, Zp), (0, yK.i)(this, Gp, 1))), bK.set(this, ((0, yK.i)(this, qX), (0, yK.i)(this, xX, 1))), lO.set(this, ((0, yK.i)(this, np), (0, yK.i)(this, Wp, !1))), vK.set(this, ((0, yK.i)(this, tX), (0, yK.i)(this, kX, void 0))), CO.set(this, ((0, yK.i)(this, Up), (0, yK.i)(this, OX, void 0))), hO.set(this, ((0, yK.i)(this, KX), (0, yK.i)(this, pX, void 0))), DO.set(this, ((0, yK.i)(this, XX), (0, yK.i)(this, bb, void 0))), MO.set(this, ((0, yK.i)(this, eX), (0, yK.i)(this, lX, 1))), aK.set(this, ((0, yK.i)(this, vb), (0, yK.i)(this, CX, OO.DEFAULT_AO_ON_ANALYTICAL_LIGHTS))), oO.set(this, ((0, yK.i)(this, hX), (0, yK.i)(this, DX, void 0))), FO.set(this, ((0, yK.i)(this, MX), (0, yK.i)(this, ab, void 0))), VO.set(this, ((0, yK.i)(this, oX), (0, yK.i)(this, FX, void 0))), LO.set(this, ((0, yK.i)(this, VX), (0, yK.i)(this, LX, void 0))), QO.set(this, ((0, yK.i)(this, QX), (0, yK.i)(this, zb, void 0))), zK.set(this, ((0, yK.i)(this, AX), (0, yK.i)(this, fX, void 0))), AO.set(this, ((0, yK.i)(this, dX), (0, yK.i)(this, TX, void 0))), fO.set(this, ((0, yK.i)(this, NX), (0, yK.i)(this, IX, 1))), dO.set(this, ((0, yK.i)(this, yb), (0, yK.i)(this, gb, GO.e.White()))), TO.set(this, ((0, yK.i)(this, uX), (0, yK.i)(this, EX, !1))), NO.set(this, ((0, yK.i)(this, jb), (0, yK.i)(this, YX, void 0))), IO.set(this, ((0, yK.i)(this, wX), (0, yK.i)(this, ib, void 0))), uO.set(this, ((0, yK.i)(this, rb), (0, yK.i)(this, PX, void 0))), EO.set(this, ((0, yK.i)(this, mb), (0, yK.i)(this, sX, void 0))), jK.set(this, ((0, yK.i)(this, HX), (0, yK.i)(this, RX, void 0))), YO.set(this, ((0, yK.i)(this, SX), (0, yK.i)(this, JX, new GO.e(0, 0, 0)))), wO.set(this, ((0, yK.i)(this, cb), (0, yK.i)(this, BX, new GO.e(1, 1, 1)))), iK.set(this, ((0, yK.i)(this, ZX), (0, yK.i)(this, GX, 1))), PO.set(this, ((0, yK.i)(this, qb), (0, yK.i)(this, xb, void 0))), mK.set(this, ((0, yK.i)(this, nX), (0, yK.i)(this, WX, new GO.e(1, 1, 1)))), sO.set(this, ((0, yK.i)(this, tb), (0, yK.i)(this, kb, new GO.e(1, 1, 1)))), HO.set(this, ((0, yK.i)(this, UX), (0, yK.i)(this, Ob, new GO.e(0, 0, 0)))), RO.set(this, ((0, yK.i)(this, Kb), (0, yK.i)(this, pb, 1))), SO.set(this, ((0, yK.i)(this, Xb), (0, yK.i)(this, be, !1))), JO.set(this, ((0, yK.i)(this, eb), (0, yK.i)(this, lb, !1))), cK.set(this, ((0, yK.i)(this, ve), (0, yK.i)(this, Cb, !1))), BO.set(this, ((0, yK.i)(this, hb), (0, yK.i)(this, Db, .4))), ZO.set(this, ((0, yK.i)(this, Mb), (0, yK.i)(this, ae, !0))), qK.set(this, ((0, yK.i)(this, ob), (0, yK.i)(this, Fb, !1))), xK.set(this, ((0, yK.i)(this, Vb), (0, yK.i)(this, Lb, !0))), nO.set(this, ((0, yK.i)(this, Qb), (0, yK.i)(this, ze, !1))), WO.set(this, ((0, yK.i)(this, Ab), (0, yK.i)(this, fb, !1))), tK.set(this, ((0, yK.i)(this, db), (0, yK.i)(this, Tb, !1))), kK.set(this, ((0, yK.i)(this, Nb), (0, yK.i)(this, Ib, !1))), UO.set(this, ((0, yK.i)(this, ye), (0, yK.i)(this, ge, !1))), OK.set(this, ((0, yK.i)(this, ub), (0, yK.i)(this, Eb, !0))), KK.set(this, ((0, yK.i)(this, je), (0, yK.i)(this, Yb, !1))), pK.set(this, ((0, yK.i)(this, wb), (0, yK.i)(this, ie, !1))), XK.set(this, ((0, yK.i)(this, re), (0, yK.i)(this, Pb, !1))), bp.set(this, ((0, yK.i)(this, me), (0, yK.i)(this, sb, .05))), eK.set(this, ((0, yK.i)(this, Hb), (0, yK.i)(this, Rb, !1))), lK.set(this, ((0, yK.i)(this, Sb), (0, yK.i)(this, Jb, !1))), vp.set(this, ((0, yK.i)(this, ce), (0, yK.i)(this, Bb, 4))), CK.set(this, ((0, yK.i)(this, Zb), (0, yK.i)(this, Gb, !1))), hK.set(this, ((0, yK.i)(this, qe), (0, yK.i)(this, xe, !1))), DK.set(this, ((0, yK.i)(this, nb), (0, yK.i)(this, Wb, !1))), MK.set(this, ((0, yK.i)(this, te), (0, yK.i)(this, ke, !1))), ap.set(this, ((0, yK.i)(this, Ub), (0, yK.i)(this, Oe, !1))), oK.set(this, ((0, yK.i)(this, Ke), (0, yK.i)(this, pe, null))), FK.set(this, ((0, yK.i)(this, Xe), (0, yK.i)(this, bl, !1))), VK.set(this, ((0, yK.i)(this, ee), (0, yK.i)(this, le, !1))), LK.set(this, ((0, yK.i)(this, vl), (0, yK.i)(this, Ce, !0))), QK.set(this, ((0, yK.i)(this, he), (0, yK.i)(this, De, !0))), zp.set(this, ((0, yK.i)(this, Me), (0, yK.i)(this, al, !1))), AK.set(this, ((0, yK.i)(this, oe), (0, yK.i)(this, Fe, !1))), (0, yK.i)(this, Ve), this._environmentBRDFTexture = rK(this.JKO())
        }
        getClassName() {
          return "PBRMaterial"
        }
        clone(KO) {
          let pO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
            XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
          const bK = NK.c.Clone((() => new OO(KO, this.JKO())), this, {
            cloneTexturesOnlyOnce: pO
          });
          return bK.id = KO, bK.name = KO, this.stencil.copyTo(bK.stencil), this._clonePlugins(bK, XO), bK
        }
        serialize() {
          const OO = super.serialize();
          return OO.customType = "BABYLON.PBRMaterial", OO
        }
        static Parse(KO, pO, XO) {
          const bK = NK.c.Parse((() => new OO(KO.name, pO)), KO, pO, XO);
          return KO.stencil && bK.stencil.parse(KO.stencil, pO, XO), eO.b._ParsePlugins(KO, bK, pO, XO), KO.clearCoat && bK.clearCoat.parse(KO.clearCoat, pO, XO), KO.anisotropy && bK.anisotropy.parse(KO.anisotropy, pO, XO), KO.brdf && bK.brdf.parse(KO.brdf, pO, XO), KO.sheen && bK.sheen.parse(KO.sheen, pO, XO), KO.subSurface && bK.subSurface.parse(KO.subSurface, pO, XO), KO.iridescence && bK.iridescence.parse(KO.iridescence, pO, XO), bK
        }
      }, KO = new WeakMap, pO = new WeakMap, XO = new WeakMap, bK = new WeakMap, lO = new WeakMap, vK = new WeakMap, CO = new WeakMap, hO = new WeakMap, DO = new WeakMap, MO = new WeakMap, aK = new WeakMap, oO = new WeakMap, FO = new WeakMap, VO = new WeakMap, LO = new WeakMap, QO = new WeakMap, zK = new WeakMap, AO = new WeakMap, fO = new WeakMap, dO = new WeakMap, TO = new WeakMap, NO = new WeakMap, IO = new WeakMap, uO = new WeakMap, EO = new WeakMap, jK = new WeakMap, YO = new WeakMap, wO = new WeakMap, iK = new WeakMap, PO = new WeakMap, mK = new WeakMap, sO = new WeakMap, HO = new WeakMap, RO = new WeakMap, SO = new WeakMap, JO = new WeakMap, cK = new WeakMap, BO = new WeakMap, ZO = new WeakMap, qK = new WeakMap, xK = new WeakMap, nO = new WeakMap, WO = new WeakMap, tK = new WeakMap, kK = new WeakMap, UO = new WeakMap, OK = new WeakMap, KK = new WeakMap, pK = new WeakMap, XK = new WeakMap, bp = new WeakMap, eK = new WeakMap, lK = new WeakMap, vp = new WeakMap, CK = new WeakMap, hK = new WeakMap, DK = new WeakMap, MK = new WeakMap, ap = new WeakMap, oK = new WeakMap, FK = new WeakMap, VK = new WeakMap, LK = new WeakMap, QK = new WeakMap, zp = new WeakMap, AK = new WeakMap, (() => {
        const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(Rp[Symbol.metadata] ?? null) : void 0;
        fK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], dK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], IK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], yp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], gp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], uK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], EK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], jp = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], YK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], wK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], ip = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], rp = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesAndMiscDirty")], PK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], mp = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], sK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], HK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], RK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], SK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], JK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], cp = [(0, gK.r)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], BK = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], ZK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], GK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], qp = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], xp = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], nK = [(0, gK.I)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty", null)], WK = [(0, gK.r)("ambient"), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], tp = [(0, gK.r)("albedo"), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], kp = [(0, gK.M)("baseWeight"), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], UK = [(0, gK.M)("baseDiffuseRoughness"), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Op = [(0, gK.r)("reflectivity"), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Kp = [(0, gK.r)("reflection"), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], pp = [(0, gK.r)("emissive"), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Xp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], bX = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], ep = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesAndMiscDirty")], lp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesAndMiscDirty")], vX = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesAndMiscDirty")], Cp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], hp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Dp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Mp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], aX = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], op = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Fp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Vp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Lp = [(0, gK.M)()], Qp = [(0, gK.M)()], zX = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Ap = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], fp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], dp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Tp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Np = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsLightsDirty")], Ip = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], yX = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsLightsDirty")], gX = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], upO = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Ep = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], jX = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Yp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], wp = [(0, gK.h)("_markAllSubMeshesAsTexturesDirty")], iX = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], rX = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], Pp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], mX = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsTexturesDirty")], sp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], Hp = [(0, gK.M)(), (0, gK.h)("_markAllSubMeshesAsMiscDirty")], (0, yK.f)(OO, null, fK, {
          kind: "accessor",
          name: "directIntensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "directIntensity" in OO,
            get: OO => OO.directIntensity,
            set: (OO, KO) => {
              OO.directIntensity = KO
            }
          },
          metadata: KO
        }, Jp, cX), (0, yK.f)(OO, null, dK, {
          kind: "accessor",
          name: "emissiveIntensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "emissiveIntensity" in OO,
            get: OO => OO.emissiveIntensity,
            set: (OO, KO) => {
              OO.emissiveIntensity = KO
            }
          },
          metadata: KO
        }, Bp, Zp), (0, yK.f)(OO, null, IK, {
          kind: "accessor",
          name: "environmentIntensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "environmentIntensity" in OO,
            get: OO => OO.environmentIntensity,
            set: (OO, KO) => {
              OO.environmentIntensity = KO
            }
          },
          metadata: KO
        }, Gp, qX), (0, yK.f)(OO, null, yp, {
          kind: "accessor",
          name: "specularIntensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "specularIntensity" in OO,
            get: OO => OO.specularIntensity,
            set: (OO, KO) => {
              OO.specularIntensity = KO
            }
          },
          metadata: KO
        }, xX, np), (0, yK.f)(OO, null, gp, {
          kind: "accessor",
          name: "disableBumpMap",
          static: !1,
          private: !1,
          access: {
            has: OO => "disableBumpMap" in OO,
            get: OO => OO.disableBumpMap,
            set: (OO, KO) => {
              OO.disableBumpMap = KO
            }
          },
          metadata: KO
        }, Wp, tX), (0, yK.f)(OO, null, uK, {
          kind: "accessor",
          name: "albedoTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "albedoTexture" in OO,
            get: OO => OO.albedoTexture,
            set: (OO, KO) => {
              OO.albedoTexture = KO
            }
          },
          metadata: KO
        }, kX, Up), (0, yK.f)(OO, null, EK, {
          kind: "accessor",
          name: "baseWeightTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "baseWeightTexture" in OO,
            get: OO => OO.baseWeightTexture,
            set: (OO, KO) => {
              OO.baseWeightTexture = KO
            }
          },
          metadata: KO
        }, OX, KX), (0, yK.f)(OO, null, jp, {
          kind: "accessor",
          name: "baseDiffuseRoughnessTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "baseDiffuseRoughnessTexture" in OO,
            get: OO => OO.baseDiffuseRoughnessTexture,
            set: (OO, KO) => {
              OO.baseDiffuseRoughnessTexture = KO
            }
          },
          metadata: KO
        }, pX, XX), (0, yK.f)(OO, null, YK, {
          kind: "accessor",
          name: "ambientTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "ambientTexture" in OO,
            get: OO => OO.ambientTexture,
            set: (OO, KO) => {
              OO.ambientTexture = KO
            }
          },
          metadata: KO
        }, bb, eX), (0, yK.f)(OO, null, wK, {
          kind: "accessor",
          name: "ambientTextureStrength",
          static: !1,
          private: !1,
          access: {
            has: OO => "ambientTextureStrength" in OO,
            get: OO => OO.ambientTextureStrength,
            set: (OO, KO) => {
              OO.ambientTextureStrength = KO
            }
          },
          metadata: KO
        }, lX, vb), (0, yK.f)(OO, null, ip, {
          kind: "accessor",
          name: "ambientTextureImpactOnAnalyticalLights",
          static: !1,
          private: !1,
          access: {
            has: OO => "ambientTextureImpactOnAnalyticalLights" in OO,
            get: OO => OO.ambientTextureImpactOnAnalyticalLights,
            set: (OO, KO) => {
              OO.ambientTextureImpactOnAnalyticalLights = KO
            }
          },
          metadata: KO
        }, CX, hX), (0, yK.f)(OO, null, rp, {
          kind: "accessor",
          name: "opacityTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "opacityTexture" in OO,
            get: OO => OO.opacityTexture,
            set: (OO, KO) => {
              OO.opacityTexture = KO
            }
          },
          metadata: KO
        }, DX, MX), (0, yK.f)(OO, null, PK, {
          kind: "accessor",
          name: "reflectionTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "reflectionTexture" in OO,
            get: OO => OO.reflectionTexture,
            set: (OO, KO) => {
              OO.reflectionTexture = KO
            }
          },
          metadata: KO
        }, ab, oX), (0, yK.f)(OO, null, mp, {
          kind: "accessor",
          name: "emissiveTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "emissiveTexture" in OO,
            get: OO => OO.emissiveTexture,
            set: (OO, KO) => {
              OO.emissiveTexture = KO
            }
          },
          metadata: KO
        }, FX, VX), (0, yK.f)(OO, null, sK, {
          kind: "accessor",
          name: "reflectivityTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "reflectivityTexture" in OO,
            get: OO => OO.reflectivityTexture,
            set: (OO, KO) => {
              OO.reflectivityTexture = KO
            }
          },
          metadata: KO
        }, LX, QX), (0, yK.f)(OO, null, HK, {
          kind: "accessor",
          name: "metallicTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "metallicTexture" in OO,
            get: OO => OO.metallicTexture,
            set: (OO, KO) => {
              OO.metallicTexture = KO
            }
          },
          metadata: KO
        }, zb, AX), (0, yK.f)(OO, null, RK, {
          kind: "accessor",
          name: "metallic",
          static: !1,
          private: !1,
          access: {
            has: OO => "metallic" in OO,
            get: OO => OO.metallic,
            set: (OO, KO) => {
              OO.metallic = KO
            }
          },
          metadata: KO
        }, fX, dX), (0, yK.f)(OO, null, SK, {
          kind: "accessor",
          name: "roughness",
          static: !1,
          private: !1,
          access: {
            has: OO => "roughness" in OO,
            get: OO => OO.roughness,
            set: (OO, KO) => {
              OO.roughness = KO
            }
          },
          metadata: KO
        }, TX, NX), (0, yK.f)(OO, null, JK, {
          kind: "accessor",
          name: "metallicF0Factor",
          static: !1,
          private: !1,
          access: {
            has: OO => "metallicF0Factor" in OO,
            get: OO => OO.metallicF0Factor,
            set: (OO, KO) => {
              OO.metallicF0Factor = KO
            }
          },
          metadata: KO
        }, IX, yb), (0, yK.f)(OO, null, cp, {
          kind: "accessor",
          name: "metallicReflectanceColor",
          static: !1,
          private: !1,
          access: {
            has: OO => "metallicReflectanceColor" in OO,
            get: OO => OO.metallicReflectanceColor,
            set: (OO, KO) => {
              OO.metallicReflectanceColor = KO
            }
          },
          metadata: KO
        }, gb, uX), (0, yK.f)(OO, null, BK, {
          kind: "accessor",
          name: "useOnlyMetallicFromMetallicReflectanceTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "useOnlyMetallicFromMetallicReflectanceTexture" in OO,
            get: OO => OO.useOnlyMetallicFromMetallicReflectanceTexture,
            set: (OO, KO) => {
              OO.useOnlyMetallicFromMetallicReflectanceTexture = KO
            }
          },
          metadata: KO
        }, EX, jb), (0, yK.f)(OO, null, ZK, {
          kind: "accessor",
          name: "metallicReflectanceTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "metallicReflectanceTexture" in OO,
            get: OO => OO.metallicReflectanceTexture,
            set: (OO, KO) => {
              OO.metallicReflectanceTexture = KO
            }
          },
          metadata: KO
        }, YX, wX), (0, yK.f)(OO, null, GK, {
          kind: "accessor",
          name: "reflectanceTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "reflectanceTexture" in OO,
            get: OO => OO.reflectanceTexture,
            set: (OO, KO) => {
              OO.reflectanceTexture = KO
            }
          },
          metadata: KO
        }, ib, rb), (0, yK.f)(OO, null, qp, {
          kind: "accessor",
          name: "microSurfaceTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "microSurfaceTexture" in OO,
            get: OO => OO.microSurfaceTexture,
            set: (OO, KO) => {
              OO.microSurfaceTexture = KO
            }
          },
          metadata: KO
        }, PX, mb), (0, yK.f)(OO, null, xp, {
          kind: "accessor",
          name: "bumpTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "bumpTexture" in OO,
            get: OO => OO.bumpTexture,
            set: (OO, KO) => {
              OO.bumpTexture = KO
            }
          },
          metadata: KO
        }, sX, HX), (0, yK.f)(OO, null, nK, {
          kind: "accessor",
          name: "lightmapTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "lightmapTexture" in OO,
            get: OO => OO.lightmapTexture,
            set: (OO, KO) => {
              OO.lightmapTexture = KO
            }
          },
          metadata: KO
        }, RX, SX), (0, yK.f)(OO, null, WK, {
          kind: "accessor",
          name: "ambientColor",
          static: !1,
          private: !1,
          access: {
            has: OO => "ambientColor" in OO,
            get: OO => OO.ambientColor,
            set: (OO, KO) => {
              OO.ambientColor = KO
            }
          },
          metadata: KO
        }, JX, cb), (0, yK.f)(OO, null, tp, {
          kind: "accessor",
          name: "albedoColor",
          static: !1,
          private: !1,
          access: {
            has: OO => "albedoColor" in OO,
            get: OO => OO.albedoColor,
            set: (OO, KO) => {
              OO.albedoColor = KO
            }
          },
          metadata: KO
        }, BX, ZX), (0, yK.f)(OO, null, kp, {
          kind: "accessor",
          name: "baseWeight",
          static: !1,
          private: !1,
          access: {
            has: OO => "baseWeight" in OO,
            get: OO => OO.baseWeight,
            set: (OO, KO) => {
              OO.baseWeight = KO
            }
          },
          metadata: KO
        }, GX, qb), (0, yK.f)(OO, null, UK, {
          kind: "accessor",
          name: "baseDiffuseRoughness",
          static: !1,
          private: !1,
          access: {
            has: OO => "baseDiffuseRoughness" in OO,
            get: OO => OO.baseDiffuseRoughness,
            set: (OO, KO) => {
              OO.baseDiffuseRoughness = KO
            }
          },
          metadata: KO
        }, xb, nX), (0, yK.f)(OO, null, Op, {
          kind: "accessor",
          name: "reflectivityColor",
          static: !1,
          private: !1,
          access: {
            has: OO => "reflectivityColor" in OO,
            get: OO => OO.reflectivityColor,
            set: (OO, KO) => {
              OO.reflectivityColor = KO
            }
          },
          metadata: KO
        }, WX, tb), (0, yK.f)(OO, null, Kp, {
          kind: "accessor",
          name: "reflectionColor",
          static: !1,
          private: !1,
          access: {
            has: OO => "reflectionColor" in OO,
            get: OO => OO.reflectionColor,
            set: (OO, KO) => {
              OO.reflectionColor = KO
            }
          },
          metadata: KO
        }, kb, UX), (0, yK.f)(OO, null, pp, {
          kind: "accessor",
          name: "emissiveColor",
          static: !1,
          private: !1,
          access: {
            has: OO => "emissiveColor" in OO,
            get: OO => OO.emissiveColor,
            set: (OO, KO) => {
              OO.emissiveColor = KO
            }
          },
          metadata: KO
        }, Ob, Kb), (0, yK.f)(OO, null, Xp, {
          kind: "accessor",
          name: "microSurface",
          static: !1,
          private: !1,
          access: {
            has: OO => "microSurface" in OO,
            get: OO => OO.microSurface,
            set: (OO, KO) => {
              OO.microSurface = KO
            }
          },
          metadata: KO
        }, pb, Xb), (0, yK.f)(OO, null, bX, {
          kind: "accessor",
          name: "useLightmapAsShadowmap",
          static: !1,
          private: !1,
          access: {
            has: OO => "useLightmapAsShadowmap" in OO,
            get: OO => OO.useLightmapAsShadowmap,
            set: (OO, KO) => {
              OO.useLightmapAsShadowmap = KO
            }
          },
          metadata: KO
        }, be, eb), (0, yK.f)(OO, null, ep, {
          kind: "accessor",
          name: "useAlphaFromAlbedoTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "useAlphaFromAlbedoTexture" in OO,
            get: OO => OO.useAlphaFromAlbedoTexture,
            set: (OO, KO) => {
              OO.useAlphaFromAlbedoTexture = KO
            }
          },
          metadata: KO
        }, lb, ve), (0, yK.f)(OO, null, lp, {
          kind: "accessor",
          name: "forceAlphaTest",
          static: !1,
          private: !1,
          access: {
            has: OO => "forceAlphaTest" in OO,
            get: OO => OO.forceAlphaTest,
            set: (OO, KO) => {
              OO.forceAlphaTest = KO
            }
          },
          metadata: KO
        }, Cb, hb), (0, yK.f)(OO, null, vX, {
          kind: "accessor",
          name: "alphaCutOff",
          static: !1,
          private: !1,
          access: {
            has: OO => "alphaCutOff" in OO,
            get: OO => OO.alphaCutOff,
            set: (OO, KO) => {
              OO.alphaCutOff = KO
            }
          },
          metadata: KO
        }, Db, Mb), (0, yK.f)(OO, null, Cp, {
          kind: "accessor",
          name: "useSpecularOverAlpha",
          static: !1,
          private: !1,
          access: {
            has: OO => "useSpecularOverAlpha" in OO,
            get: OO => OO.useSpecularOverAlpha,
            set: (OO, KO) => {
              OO.useSpecularOverAlpha = KO
            }
          },
          metadata: KO
        }, ae, ob), (0, yK.f)(OO, null, hp, {
          kind: "accessor",
          name: "useMicroSurfaceFromReflectivityMapAlpha",
          static: !1,
          private: !1,
          access: {
            has: OO => "useMicroSurfaceFromReflectivityMapAlpha" in OO,
            get: OO => OO.useMicroSurfaceFromReflectivityMapAlpha,
            set: (OO, KO) => {
              OO.useMicroSurfaceFromReflectivityMapAlpha = KO
            }
          },
          metadata: KO
        }, Fb, Vb), (0, yK.f)(OO, null, Dp, {
          kind: "accessor",
          name: "useRoughnessFromMetallicTextureAlpha",
          static: !1,
          private: !1,
          access: {
            has: OO => "useRoughnessFromMetallicTextureAlpha" in OO,
            get: OO => OO.useRoughnessFromMetallicTextureAlpha,
            set: (OO, KO) => {
              OO.useRoughnessFromMetallicTextureAlpha = KO
            }
          },
          metadata: KO
        }, Lb, Qb), (0, yK.f)(OO, null, Mp, {
          kind: "accessor",
          name: "useRoughnessFromMetallicTextureGreen",
          static: !1,
          private: !1,
          access: {
            has: OO => "useRoughnessFromMetallicTextureGreen" in OO,
            get: OO => OO.useRoughnessFromMetallicTextureGreen,
            set: (OO, KO) => {
              OO.useRoughnessFromMetallicTextureGreen = KO
            }
          },
          metadata: KO
        }, ze, Ab), (0, yK.f)(OO, null, aX, {
          kind: "accessor",
          name: "useMetallnessFromMetallicTextureBlue",
          static: !1,
          private: !1,
          access: {
            has: OO => "useMetallnessFromMetallicTextureBlue" in OO,
            get: OO => OO.useMetallnessFromMetallicTextureBlue,
            set: (OO, KO) => {
              OO.useMetallnessFromMetallicTextureBlue = KO
            }
          },
          metadata: KO
        }, fb, db), (0, yK.f)(OO, null, op, {
          kind: "accessor",
          name: "useAmbientOcclusionFromMetallicTextureRed",
          static: !1,
          private: !1,
          access: {
            has: OO => "useAmbientOcclusionFromMetallicTextureRed" in OO,
            get: OO => OO.useAmbientOcclusionFromMetallicTextureRed,
            set: (OO, KO) => {
              OO.useAmbientOcclusionFromMetallicTextureRed = KO
            }
          },
          metadata: KO
        }, Tb, Nb), (0, yK.f)(OO, null, Fp, {
          kind: "accessor",
          name: "useAmbientInGrayScale",
          static: !1,
          private: !1,
          access: {
            has: OO => "useAmbientInGrayScale" in OO,
            get: OO => OO.useAmbientInGrayScale,
            set: (OO, KO) => {
              OO.useAmbientInGrayScale = KO
            }
          },
          metadata: KO
        }, Ib, ye), (0, yK.f)(OO, null, Vp, {
          kind: "accessor",
          name: "useAutoMicroSurfaceFromReflectivityMap",
          static: !1,
          private: !1,
          access: {
            has: OO => "useAutoMicroSurfaceFromReflectivityMap" in OO,
            get: OO => OO.useAutoMicroSurfaceFromReflectivityMap,
            set: (OO, KO) => {
              OO.useAutoMicroSurfaceFromReflectivityMap = KO
            }
          },
          metadata: KO
        }, ge, ub), (0, yK.f)(OO, null, Lp, {
          kind: "getter",
          name: "usePhysicalLightFalloff",
          static: !1,
          private: !1,
          access: {
            has: OO => "usePhysicalLightFalloff" in OO,
            get: OO => OO.usePhysicalLightFalloff
          },
          metadata: KO
        }, null, Sp), (0, yK.f)(OO, null, Qp, {
          kind: "getter",
          name: "useGLTFLightFalloff",
          static: !1,
          private: !1,
          access: {
            has: OO => "useGLTFLightFalloff" in OO,
            get: OO => OO.useGLTFLightFalloff
          },
          metadata: KO
        }, null, Sp), (0, yK.f)(OO, null, zX, {
          kind: "accessor",
          name: "useRadianceOverAlpha",
          static: !1,
          private: !1,
          access: {
            has: OO => "useRadianceOverAlpha" in OO,
            get: OO => OO.useRadianceOverAlpha,
            set: (OO, KO) => {
              OO.useRadianceOverAlpha = KO
            }
          },
          metadata: KO
        }, Eb, je), (0, yK.f)(OO, null, Ap, {
          kind: "accessor",
          name: "useObjectSpaceNormalMap",
          static: !1,
          private: !1,
          access: {
            has: OO => "useObjectSpaceNormalMap" in OO,
            get: OO => OO.useObjectSpaceNormalMap,
            set: (OO, KO) => {
              OO.useObjectSpaceNormalMap = KO
            }
          },
          metadata: KO
        }, Yb, wb), (0, yK.f)(OO, null, fp, {
          kind: "accessor",
          name: "useParallax",
          static: !1,
          private: !1,
          access: {
            has: OO => "useParallax" in OO,
            get: OO => OO.useParallax,
            set: (OO, KO) => {
              OO.useParallax = KO
            }
          },
          metadata: KO
        }, ie, re), (0, yK.f)(OO, null, dp, {
          kind: "accessor",
          name: "useParallaxOcclusion",
          static: !1,
          private: !1,
          access: {
            has: OO => "useParallaxOcclusion" in OO,
            get: OO => OO.useParallaxOcclusion,
            set: (OO, KO) => {
              OO.useParallaxOcclusion = KO
            }
          },
          metadata: KO
        }, Pb, me), (0, yK.f)(OO, null, Tp, {
          kind: "accessor",
          name: "parallaxScaleBias",
          static: !1,
          private: !1,
          access: {
            has: OO => "parallaxScaleBias" in OO,
            get: OO => OO.parallaxScaleBias,
            set: (OO, KO) => {
              OO.parallaxScaleBias = KO
            }
          },
          metadata: KO
        }, sb, Hb), (0, yK.f)(OO, null, Np, {
          kind: "accessor",
          name: "disableLighting",
          static: !1,
          private: !1,
          access: {
            has: OO => "disableLighting" in OO,
            get: OO => OO.disableLighting,
            set: (OO, KO) => {
              OO.disableLighting = KO
            }
          },
          metadata: KO
        }, Rb, Sb), (0, yK.f)(OO, null, Ip, {
          kind: "accessor",
          name: "forceIrradianceInFragment",
          static: !1,
          private: !1,
          access: {
            has: OO => "forceIrradianceInFragment" in OO,
            get: OO => OO.forceIrradianceInFragment,
            set: (OO, KO) => {
              OO.forceIrradianceInFragment = KO
            }
          },
          metadata: KO
        }, Jb, ce), (0, yK.f)(OO, null, yX, {
          kind: "accessor",
          name: "maxSimultaneousLights",
          static: !1,
          private: !1,
          access: {
            has: OO => "maxSimultaneousLights" in OO,
            get: OO => OO.maxSimultaneousLights,
            set: (OO, KO) => {
              OO.maxSimultaneousLights = KO
            }
          },
          metadata: KO
        }, Bb, Zb), (0, yK.f)(OO, null, gX, {
          kind: "accessor",
          name: "invertNormalMapX",
          static: !1,
          private: !1,
          access: {
            has: OO => "invertNormalMapX" in OO,
            get: OO => OO.invertNormalMapX,
            set: (OO, KO) => {
              OO.invertNormalMapX = KO
            }
          },
          metadata: KO
        }, Gb, qe), (0, yK.f)(OO, null, upO, {
          kind: "accessor",
          name: "invertNormalMapY",
          static: !1,
          private: !1,
          access: {
            has: OO => "invertNormalMapY" in OO,
            get: OO => OO.invertNormalMapY,
            set: (OO, KO) => {
              OO.invertNormalMapY = KO
            }
          },
          metadata: KO
        }, xe, nb), (0, yK.f)(OO, null, Ep, {
          kind: "accessor",
          name: "twoSidedLighting",
          static: !1,
          private: !1,
          access: {
            has: OO => "twoSidedLighting" in OO,
            get: OO => OO.twoSidedLighting,
            set: (OO, KO) => {
              OO.twoSidedLighting = KO
            }
          },
          metadata: KO
        }, Wb, te), (0, yK.f)(OO, null, jX, {
          kind: "accessor",
          name: "useAlphaFresnel",
          static: !1,
          private: !1,
          access: {
            has: OO => "useAlphaFresnel" in OO,
            get: OO => OO.useAlphaFresnel,
            set: (OO, KO) => {
              OO.useAlphaFresnel = KO
            }
          },
          metadata: KO
        }, ke, Ub), (0, yK.f)(OO, null, Yp, {
          kind: "accessor",
          name: "useLinearAlphaFresnel",
          static: !1,
          private: !1,
          access: {
            has: OO => "useLinearAlphaFresnel" in OO,
            get: OO => OO.useLinearAlphaFresnel,
            set: (OO, KO) => {
              OO.useLinearAlphaFresnel = KO
            }
          },
          metadata: KO
        }, Oe, Ke), (0, yK.f)(OO, null, wp, {
          kind: "accessor",
          name: "environmentBRDFTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "environmentBRDFTexture" in OO,
            get: OO => OO.environmentBRDFTexture,
            set: (OO, KO) => {
              OO.environmentBRDFTexture = KO
            }
          },
          metadata: KO
        }, pe, Xe), (0, yK.f)(OO, null, iX, {
          kind: "accessor",
          name: "forceNormalForward",
          static: !1,
          private: !1,
          access: {
            has: OO => "forceNormalForward" in OO,
            get: OO => OO.forceNormalForward,
            set: (OO, KO) => {
              OO.forceNormalForward = KO
            }
          },
          metadata: KO
        }, bl, ee), (0, yK.f)(OO, null, rX, {
          kind: "accessor",
          name: "enableSpecularAntiAliasing",
          static: !1,
          private: !1,
          access: {
            has: OO => "enableSpecularAntiAliasing" in OO,
            get: OO => OO.enableSpecularAntiAliasing,
            set: (OO, KO) => {
              OO.enableSpecularAntiAliasing = KO
            }
          },
          metadata: KO
        }, le, vl), (0, yK.f)(OO, null, Pp, {
          kind: "accessor",
          name: "useHorizonOcclusion",
          static: !1,
          private: !1,
          access: {
            has: OO => "useHorizonOcclusion" in OO,
            get: OO => OO.useHorizonOcclusion,
            set: (OO, KO) => {
              OO.useHorizonOcclusion = KO
            }
          },
          metadata: KO
        }, Ce, he), (0, yK.f)(OO, null, mX, {
          kind: "accessor",
          name: "useRadianceOcclusion",
          static: !1,
          private: !1,
          access: {
            has: OO => "useRadianceOcclusion" in OO,
            get: OO => OO.useRadianceOcclusion,
            set: (OO, KO) => {
              OO.useRadianceOcclusion = KO
            }
          },
          metadata: KO
        }, De, Me), (0, yK.f)(OO, null, sp, {
          kind: "accessor",
          name: "unlit",
          static: !1,
          private: !1,
          access: {
            has: OO => "unlit" in OO,
            get: OO => OO.unlit,
            set: (OO, KO) => {
              OO.unlit = KO
            }
          },
          metadata: KO
        }, al, oe), (0, yK.f)(OO, null, Hp, {
          kind: "accessor",
          name: "applyDecalMapAfterDetailMap",
          static: !1,
          private: !1,
          access: {
            has: OO => "applyDecalMapAfterDetailMap" in OO,
            get: OO => OO.applyDecalMapAfterDetailMap,
            set: (OO, KO) => {
              OO.applyDecalMapAfterDetailMap = KO
            }
          },
          metadata: KO
        }, Fe, Ve), KO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: KO
        })
      })(), OO.PBRMATERIAL_OPAQUE = TK.PBRMATERIAL_OPAQUE, OO.PBRMATERIAL_ALPHATEST = TK.PBRMATERIAL_ALPHATEST, OO.PBRMATERIAL_ALPHABLEND = TK.PBRMATERIAL_ALPHABLEND, OO.PBRMATERIAL_ALPHATESTANDBLEND = TK.PBRMATERIAL_ALPHATESTANDBLEND, OO.DEFAULT_AO_ON_ANALYTICAL_LIGHTS = TK.DEFAULT_AO_ON_ANALYTICAL_LIGHTS, OO
    })();
    const me = "KHR_materials_diffuse_transmission";

    function sb(OO, KO) {
      const pO = KO.subSurface;
      let XO = null;
      return pO.translucencyIntensityTexture ? XO = pO.translucencyIntensityTexture : pO.thicknessTexture && pO.useMaskFromThicknessTexture && (XO = pO.thicknessTexture), XO && !pO.useGltfStyleTextures ? (uO.b.Warn(`${OO}: Translucency intensity texture is not supported when useGltfStyleTextures = false. Ignoring for: ${KO.name}`, 1), null) : XO
    }
    class Hb {
      constructor(OO) {
        this.name = me, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        if (pO instanceof Pb && this._isExtensionEnabled(pO)) {
          const KO = sb(OO, pO);
          return KO && XO.push(KO), pO.subSurface.translucencyColorTexture && XO.push(pO.subSurface.translucencyColorTexture), XO
        }
        return XO
      }
      _isExtensionEnabled(OO) {
        if (OO.unlit) return !1;
        const KO = OO.subSurface;
        return !!KO.isTranslucencyEnabled && (!OO.unlit && !KO.useAlbedoToTintTranslucency && KO.useGltfStyleTextures && 1 === KO.volumeIndexOfRefraction && 0 === KO.minimumThickness && 0 === KO.maximumThickness)
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((XO => {
          if (pO instanceof Pb && this._isExtensionEnabled(pO)) {
            this._wasUsed = !0;
            const XO = pO.subSurface,
              bK = sb(OO, pO),
              eO = 0 == XO.translucencyIntensity ? void 0 : XO.translucencyIntensity,
              lO = this._exporter._materialExporter.getTextureInfo(bK) ?? void 0,
              vK = !XO.translucencyColor || XO.translucencyColor.equalsFloats(1, 1, 1) ? void 0 : XO.translucencyColor.WhO(),
              CO = this._exporter._materialExporter.getTextureInfo(XO.translucencyColorTexture) ?? void 0,
              hO = {
                diffuseTransmissionFactor: eO,
                diffuseTransmissionTexture: lO,
                diffuseTransmissionColorFactor: vK,
                diffuseTransmissionColorTexture: CO
              };
            (lO || CO) && this._exporter._materialNeedsUVsSet.add(pO), KO.extensions = KO.extensions || {}, KO.extensions[me] = hO
          }
          XO(KO)
        }))
      }
    }
    let Rb = !1;

    function Sb() {
      Rb || (Rb = !0, rb.RegisterExtension(me, (OO => new Hb(OO))))
    }
    Sb();
    const Jb = "KHR_materials_dispersion";
    class ce {
      constructor() {
        this.name = Jb, this.enabled = !0, this.required = !1, this._wasUsed = !1
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      _isExtensionEnabled(OO) {
        if (OO.unlit) return !1;
        const KO = OO.subSurface;
        return !(!KO.isRefractionEnabled && !KO.isDispersionEnabled)
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          if (pO instanceof Pb && this._isExtensionEnabled(pO)) {
            this._wasUsed = !0;
            const OO = {
              dispersion: pO.subSurface.dispersion
            };
            KO.extensions = KO.extensions || {}, KO.extensions[Jb] = OO
          }
          OO(KO)
        }))
      }
    }
    let Bb = !1;

    function Zb() {
      Bb || (Bb = !0, rb.RegisterExtension(Jb, (() => new ce)))
    }
    Zb();
    const Gb = "KHR_materials_emissive_strength";
    class qe {
      constructor() {
        this.name = Gb, this.enabled = !0, this.required = !1, this._wasUsed = !1
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAsync(OO, KO, pO) {
        return await new Promise((OO => {
          if (!(pO instanceof Pb)) return OO(KO);
          const XO = pO.emissiveColor.scale(pO.emissiveIntensity),
            bK = Math.max(...XO.WhO());
          if (bK > 1) {
            KO.emissiveFactor = XO.scale(1 / bK).WhO(), this._wasUsed = !0;
            const OO = {
              emissiveStrength: bK
            };
            KO.extensions || (KO.extensions = {}), KO.extensions[Gb] = OO
          } else KO.emissiveFactor = XO.WhO();
          return OO(KO)
        }))
      }
    }
    let xe = !1;

    function nb() {
      xe || (xe = !0, rb.RegisterExtension(Gb, (() => new qe)))
    }
    nb();
    const Wb = "KHR_materials_ior";
    class te {
      constructor() {
        this.name = Wb, this.enabled = !0, this.required = !1, this._wasUsed = !1
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      _isExtensionEnabled(OO) {
        return !OO.unlit && (OO instanceof kp ? 1.5 != OO.specularIor : OO instanceof Pb && (void 0 != OO.indexOfRefraction && 1.5 != OO.indexOfRefraction))
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          if (pO instanceof Pb && this._isExtensionEnabled(pO)) {
            this._wasUsed = !0;
            const OO = {
              ior: pO.indexOfRefraction
            };
            KO.extensions = KO.extensions || {}, KO.extensions[Wb] = OO
          } else if (pO instanceof kp && this._isExtensionEnabled(pO)) {
            this._wasUsed = !0;
            const OO = {
              ior: pO.specularIor
            };
            KO.extensions = KO.extensions || {}, KO.extensions[Wb] = OO
          }
          OO(KO)
        }))
      }
    }
    let ke = !1;

    function Ub() {
      ke || (ke = !0, rb.RegisterExtension(Wb, (() => new te)))
    }
    Ub();
    const Oe = "KHR_materials_iridescence";
    class Ke {
      constructor(OO) {
        this.name = Oe, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        if (pO instanceof TK) {
          if (pO.iridescence.isEnabled) return pO.iridescence.texture && XO.push(pO.iridescence.texture), pO.iridescence.thicknessTexture && pO.iridescence.thicknessTexture !== pO.iridescence.texture && XO.push(pO.iridescence.thicknessTexture), XO
        } else if (pO instanceof kp && pO.thinFilmWeight > 0) return pO.thinFilmWeightTexture && XO.push(pO.thinFilmWeightTexture), pO.thinFilmThicknessTexture && pO.thinFilmThicknessTexture !== pO.thinFilmWeightTexture && XO.push(pO.thinFilmThicknessTexture), XO;
        return []
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          if (pO instanceof TK) {
            if (!pO.iridescence.isEnabled) return void OO(KO);
            this._wasUsed = !0, KO.extensions = KO.extensions || {};
            const XO = this._exporter._materialExporter.getTextureInfo(pO.iridescence.texture),
              bK = this._exporter._materialExporter.getTextureInfo(pO.iridescence.thicknessTexture),
              eO = {
                iridescenceFactor: pO.iridescence.intensity,
                iridescenceIor: pO.iridescence.indexOfRefraction,
                iridescenceThicknessMinimum: pO.iridescence.minimumThickness,
                iridescenceThicknessMaximum: pO.iridescence.maximumThickness,
                iridescenceTexture: XO ?? void 0,
                iridescenceThicknessTexture: bK ?? void 0
              };
            null === eO.iridescenceTexture && null === eO.iridescenceThicknessTexture || this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[Oe] = eO
          } else if (pO instanceof kp) {
            if (pO.thinFilmWeight <= 0) return void OO(KO);
            this._wasUsed = !0, KO.extensions = KO.extensions || {};
            const XO = this._exporter._materialExporter.getTextureInfo(pO.thinFilmWeightTexture),
              bK = this._exporter._materialExporter.getTextureInfo(pO.thinFilmThicknessTexture),
              eO = {
                iridescenceFactor: pO.thinFilmWeight,
                iridescenceIor: pO.thinFilmIor,
                iridescenceThicknessMinimum: 1e3 * pO.thinFilmThicknessMin,
                iridescenceThicknessMaximum: 1e3 * pO.thinFilmThickness,
                iridescenceTexture: XO ?? void 0,
                iridescenceThicknessTexture: bK ?? void 0
              };
            null === eO.iridescenceTexture && null === eO.iridescenceThicknessTexture || this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[Oe] = eO
          }
          OO(KO)
        }))
      }
    }
    let pe = !1;

    function Xe() {
      pe || (pe = !0, rb.RegisterExtension(Oe, (OO => new Ke(OO))))
    }
    Xe();
    const bl = "KHR_materials_sheen";
    class ee {
      constructor(OO) {
        this.name = bl, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        return pO instanceof Pb && pO.sheen.isEnabled && pO.sheen.texture ? [pO.sheen.texture] : []
      }
      async postExportMaterialAsync(OO, KO, pO) {
        return await new Promise((OO => {
          if (pO instanceof Pb) {
            if (!pO.sheen.isEnabled) return void OO(KO);
            this._wasUsed = !0, null == KO.extensions && (KO.extensions = {});
            const XO = {
              sheenColorFactor: pO.sheen.color.WhO(),
              sheenRoughnessFactor: pO.sheen.roughness ?? 0
            };
            null === XO.sheenColorTexture && null === XO.sheenRoughnessTexture || this._exporter._materialNeedsUVsSet.add(pO), pO.sheen.texture && (XO.sheenColorTexture = this._exporter._materialExporter.getTextureInfo(pO.sheen.texture) ?? void 0), pO.sheen.textureRoughness && !pO.sheen.useRoughnessFromMainTexture ? XO.sheenRoughnessTexture = this._exporter._materialExporter.getTextureInfo(pO.sheen.textureRoughness) ?? void 0 : pO.sheen.texture && pO.sheen.useRoughnessFromMainTexture && (XO.sheenRoughnessTexture = this._exporter._materialExporter.getTextureInfo(pO.sheen.texture) ?? void 0), KO.extensions[bl] = XO
          }
          OO(KO)
        }))
      }
    }
    let le = !1;

    function vl() {
      le || (le = !0, rb.RegisterExtension(bl, (OO => new ee(OO))))
    }
    vl();
    const Ce = "KHR_materials_fuzz";

    function he(OO, KO) {
      const pO = new jK.e(KO.name, KO.JKO());
      return pO._texture = OO, pO.coordinatesIndex = KO.coordinatesIndex, KO instanceof jK.e && (pO.uOffset = KO.uOffset, pO.vOffset = KO.vOffset, pO.uScale = KO.uScale, pO.vScale = KO.vScale, pO.wAng = KO.wAng), pO.wrapU = KO.wrapU, pO.wrapV = KO.wrapV, pO
    }
    class De {
      constructor(OO) {
        this.name = Ce, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._mergedTexturesMap = {}, this._cachedInternalTexturesMap = {}, this._exporter = OO
      }
      dispose() {
        for (const OO of Object.keys(this._mergedTexturesMap)) {
          this._mergedTexturesMap[OO].dispose()
        }
        this._mergedTexturesMap = {};
        for (const OO of Object.keys(this._cachedInternalTexturesMap)) {
          this._cachedInternalTexturesMap[OO].dispose()
        }
        this._cachedInternalTexturesMap = {}
      }
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        if (pO instanceof kp) {
          const OO = [];
          if (pO.fuzzWeight > 0) {
            pO.fuzzWeightTexture && OO.push(pO.fuzzWeightTexture);
            let KO = !1;
            if (pO.fuzzRoughnessTexture && (pO._useFuzzRoughnessFromTextureAlpha ? OO.push(pO.fuzzRoughnessTexture) : KO = !0), pO.fuzzColorTexture && !KO && OO.push(pO.fuzzColorTexture), KO) {
              const KO = function(OO) {
                const KO = OO.fuzzColorTexture,
                  pO = KO && KO.getInternalTexture() ? KO.getInternalTexture().uniqueId : "NoFuzzColor",
                  XO = OO.fuzzRoughnessTexture;
                return `FuzzColor_${pO}_FuzzRoughness_${XO&&XO.getInternalTexture()?XO.getInternalTexture().uniqueId:"NoFuzzRoughness"}`
              }(pO);
              if (!this._cachedInternalTexturesMap[KO]) {
                const OO = await async function(OO) {
                  const KO = OO.JKO(),
                    pO = OO.fuzzColorTexture,
                    XO = OO.fuzzRoughnessTexture;
                  return pO || XO ? (await lp("FuzzTexture", hp(pO ? vX(pO, 0) : Cp(1), pO ? vX(pO, 1) : Cp(1), pO ? vX(pO, 2) : Cp(1), XO ? vX(XO, OO._useFuzzRoughnessFromTextureAlpha ? 3 : 0) : Cp(1)), KO)).getInternalTexture() : null
                }(pO);
                OO && (this._cachedInternalTexturesMap[KO] = OO)
              }
              this._cachedInternalTexturesMap[KO] && (pO.fuzzColorTexture && (this._mergedTexturesMap[pO.fuzzColorTexture.uniqueId] = he(this._cachedInternalTexturesMap[KO], pO.fuzzColorTexture), OO.push(this._mergedTexturesMap[pO.fuzzColorTexture.uniqueId])), pO.fuzzRoughnessTexture && (this._mergedTexturesMap[pO.fuzzRoughnessTexture.uniqueId] = he(this._cachedInternalTexturesMap[KO], pO.fuzzRoughnessTexture), OO.push(this._mergedTexturesMap[pO.fuzzRoughnessTexture.uniqueId])))
            }
          }
          return OO
        }
        return []
      }
      async postExportMaterialAsync(OO, KO, pO) {
        return await new Promise((OO => {
          if (pO instanceof kp) {
            if (0 == pO.fuzzWeight) return void OO(KO);
            this._wasUsed = !0, null == KO.extensions && (KO.extensions = {});
            const XO = {
              fuzzFactor: pO.fuzzWeight,
              fuzzColorFactor: pO.fuzzColor.WhO(),
              fuzzRoughnessFactor: pO.fuzzRoughness
            };
            let bK, eO;
            pO.fuzzWeightTexture && (XO.fuzzTexture = this._exporter._materialExporter.getTextureInfo(pO.fuzzWeightTexture) ?? void 0), pO.fuzzColorTexture && (bK = this._mergedTexturesMap[pO.fuzzColorTexture.uniqueId] ? this._mergedTexturesMap[pO.fuzzColorTexture.uniqueId] : pO.fuzzColorTexture, XO.fuzzColorTexture = this._exporter._materialExporter.getTextureInfo(bK) ?? void 0), pO.fuzzRoughnessTexture && (eO = this._mergedTexturesMap[pO.fuzzRoughnessTexture.uniqueId] ? this._mergedTexturesMap[pO.fuzzRoughnessTexture.uniqueId] : pO.fuzzRoughnessTexture, XO.fuzzRoughnessTexture = this._exporter._materialExporter.getTextureInfo(eO) ?? void 0), null === XO.fuzzColorTexture && null === XO.fuzzRoughnessTexture || this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[Ce] = XO
          }
          OO(KO)
        }))
      }
    }
    let Me = !1;

    function al() {
      Me || (Me = !0, rb.RegisterExtension(Ce, (OO => new De(OO))))
    }
    al();
    const oe = "KHR_materials_specular";
    class Fe {
      constructor(OO) {
        this.name = oe, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        return pO instanceof Pb && this._isExtensionEnabled(pO) ? (pO.metallicReflectanceTexture && XO.push(pO.metallicReflectanceTexture), pO.reflectanceTexture && XO.push(pO.reflectanceTexture), XO) : XO
      }
      _isExtensionEnabled(OO) {
        return !OO.unlit && (void 0 != OO.metallicF0Factor && 1 != OO.metallicF0Factor || void 0 != OO.metallicReflectanceColor && !OO.metallicReflectanceColor.equalsFloats(1, 1, 1) || this._hasTexturesExtension(OO))
      }
      _hasTexturesExtension(OO) {
        return null != OO.metallicReflectanceTexture || null != OO.reflectanceTexture
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          var XO;
          if (pO instanceof Pb && this._isExtensionEnabled(pO)) {
            this._wasUsed = !0, KO.extensions = KO.extensions || {};
            const OO = this._exporter._materialExporter.getTextureInfo(pO.metallicReflectanceTexture) ?? void 0,
              XO = this._exporter._materialExporter.getTextureInfo(pO.reflectanceTexture) ?? void 0,
              bK = {
                specularFactor: 1 == pO.metallicF0Factor ? void 0 : pO.metallicF0Factor,
                specularTexture: OO,
                specularColorFactor: pO.metallicReflectanceColor.equalsFloats(1, 1, 1) ? void 0 : pO.metallicReflectanceColor.WhO(),
                specularColorTexture: XO
              };
            this._hasTexturesExtension(pO) && this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[oe] = bK
          } else if (pO instanceof kp) {
            KO.extensions = KO.extensions || {};
            const bK = this._exporter._materialExporter.getTextureInfo(pO.specularWeightTexture) ?? void 0,
              eO = this._exporter._materialExporter.getTextureInfo(pO.specularColorTexture) ?? void 0,
              lO = 1 == pO.specularWeight ? void 0 : pO.specularWeight,
              vK = pO.specularColor.equalsFloats(1, 1, 1) ? void 0 : pO.specularColor.WhO();
            if (!eO && !bK && void 0 === lO && void 0 === vK) return OO(KO);
            this._wasUsed = !0;
            const CO = {
                specularEdgeColorEnabled: !0
              },
              hO = {
                specularFactor: lO,
                specularTexture: bK,
                specularColorFactor: vK,
                specularColorTexture: eO,
                extensions: {}
              };
            hO.extensions.EXT_materials_specular_edge_color = CO, (XO = this._exporter._glTF).extensionsUsed || (XO.extensionsUsed = []), -1 === this._exporter._glTF.extensionsUsed.indexOf("EXT_materials_specular_edge_color") && this._exporter._glTF.extensionsUsed.push("EXT_materials_specular_edge_color"), (bK || eO) && this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[oe] = hO
          }
          OO(KO)
        }))
      }
    }
    let Ve = !1;

    function Le() {
      Ve || (Ve = !0, rb.RegisterExtension(oe, (OO => new Fe(OO))))
    }
    Le();
    const Qe = "KHR_materials_transmission";
    class zl {
      constructor(OO) {
        this.name = Qe, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        if (pO instanceof Pb) {
          if (this._isExtensionEnabled(pO)) return pO.subSurface.refractionIntensityTexture && pO.subSurface.useGltfStyleTextures && XO.push(pO.subSurface.refractionIntensityTexture), XO
        } else pO instanceof kp && (pO.transmissionWeight > 0 && pO.transmissionWeightTexture && (XO.push(pO.transmissionWeightTexture), pO.transmissionColorTexture && XO.push(pO.transmissionColorTexture)), pO.subsurfaceWeight > 0 && pO.subsurfaceWeightTexture && XO.push(pO.subsurfaceWeightTexture));
        return XO
      }
      _isExtensionEnabled(OO) {
        if (OO instanceof kp && !OO.unlit) return OO.transmissionWeight > 0 || OO.subsurfaceWeight > 0;
        if (OO instanceof Pb && !OO.unlit) {
          const KO = OO.subSurface;
          return KO.isRefractionEnabled && void 0 != KO.refractionIntensity && 0 != KO.refractionIntensity || null != KO.refractionIntensityTexture && KO.useGltfStyleTextures
        }
        return !1
      }
      async postExportMaterialAsync(OO, KO, pO) {
        if (!this._isExtensionEnabled(pO)) return KO;
        if (pO instanceof Pb) {
          this._wasUsed = !0;
          const XO = pO.subSurface,
            bK = {
              transmissionFactor: 0 === XO.refractionIntensity ? void 0 : XO.refractionIntensity
            };
          if (XO.refractionIntensityTexture)
            if (XO.useGltfStyleTextures) {
              this._exporter._materialNeedsUVsSet.add(pO);
              const OO = this._exporter._materialExporter.getTextureInfo(XO.refractionIntensityTexture);
              OO && (bK.transmissionTexture = OO)
            } else uO.b.Warn(`${OO}: Exporting a subsurface refraction intensity texture without \`useGltfStyleTextures\` is not supported`);
          KO.extensions || (KO.extensions = {}), KO.extensions[Qe] = bK
        } else if (pO instanceof kp) {
          this._wasUsed = !0;
          const OO = {
            transmissionFactor: (1 - pO.transmissionWeight) * pO.subsurfaceWeight + pO.transmissionWeight
          };
          if (pO.transmissionWeightTexture) {
            this._exporter._materialNeedsUVsSet.add(pO);
            const KO = this._exporter._materialExporter.getTextureInfo(pO.transmissionWeightTexture);
            KO && (OO.transmissionTexture = KO)
          } else if (pO.subsurfaceWeightTexture) {
            this._exporter._materialNeedsUVsSet.add(pO);
            const KO = this._exporter._materialExporter.getTextureInfo(pO.subsurfaceWeightTexture);
            KO && (OO.transmissionTexture = KO)
          }
          if (0 == pO.transmissionDepth && (!pO.transmissionColor.equals(GO.e.White()) || pO.transmissionColorTexture) && KO.pbrMetallicRoughness && (KO.pbrMetallicRoughness.baseColorFactor || (KO.pbrMetallicRoughness.baseColorFactor = [1, 1, 1, 1]), KO.pbrMetallicRoughness.baseColorFactor[0] *= pO.transmissionColor.r, KO.pbrMetallicRoughness.baseColorFactor[1] *= pO.transmissionColor.g, KO.pbrMetallicRoughness.baseColorFactor[2] *= pO.transmissionColor.b, pO.transmissionColorTexture && !KO.pbrMetallicRoughness.baseColorTexture)) {
            const OO = this._exporter._materialExporter.getTextureInfo(pO.transmissionColorTexture);
            OO && (KO.pbrMetallicRoughness.baseColorTexture = OO, this._exporter._materialNeedsUVsSet.add(pO))
          }
          KO.extensions || (KO.extensions = {}), KO.extensions[Qe] = OO
        }
        return KO
      }
    }
    let Ae = !1;

    function fe() {
      Ae || (Ae = !0, rb.RegisterExtension(Qe, (OO => new zl(OO))))
    }
    fe();
    var de = pO(38360);
    const Te = "KHR_materials_unlit";
    class Ne {
      constructor() {
        this.name = Te, this.enabled = !0, this.required = !1, this._wasUsed = !1
      }
      get wasUsed() {
        return this._wasUsed
      }
      dispose() {}
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          let XO = !1;
          pO instanceof Pb ? XO = pO.unlit : pO instanceof de.d && (XO = pO.disableLighting), XO && (this._wasUsed = !0, null == KO.extensions && (KO.extensions = {}), KO.extensions[Te] = {}), OO(KO)
        }))
      }
    }
    let Ie = !1;

    function yl() {
      Ie || (Ie = !0, rb.RegisterExtension(Te, (() => new Ne)))
    }
    yl();
    const gl = "KHR_materials_volume";
    class ue {
      constructor(OO) {
        this.name = gl, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        if (pO instanceof Pb) {
          if (this._isExtensionEnabled(pO)) return pO.subSurface.thicknessTexture && XO.push(pO.subSurface.thicknessTexture), XO
        } else pO instanceof kp && (pO.transmissionWeight > 0 || pO.subsurfaceWeight > 0) && pO.geometryThicknessTexture && XO.push(pO.geometryThicknessTexture);
        return XO
      }
      _isExtensionEnabled(OO) {
        if (OO.unlit) return !1;
        const KO = OO.subSurface;
        return !(!KO.isRefractionEnabled && !KO.isTranslucencyEnabled) && (void 0 != KO.maximumThickness && 0 != KO.maximumThickness || void 0 != KO.tintColorAtDistance && KO.tintColorAtDistance != Number.POSITIVE_INFINITY || void 0 != KO.tintColor && KO.tintColor != GO.e.White() || this._hasTexturesExtension(OO))
      }
      _hasTexturesExtension(OO) {
        return null != OO.subSurface.thicknessTexture
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          if (pO instanceof Pb && this._isExtensionEnabled(pO)) {
            this._wasUsed = !0;
            const OO = pO.subSurface,
              XO = {
                thicknessFactor: 0 == OO.maximumThickness ? void 0 : OO.maximumThickness,
                thicknessTexture: this._exporter._materialExporter.getTextureInfo(OO.thicknessTexture) ?? void 0,
                attenuationDistance: OO.tintColorAtDistance == Number.POSITIVE_INFINITY ? void 0 : OO.tintColorAtDistance,
                attenuationColor: OO.tintColor.equalsFloats(1, 1, 1) ? void 0 : OO.tintColor.WhO()
              };
            this._hasTexturesExtension(pO) && this._exporter._materialNeedsUVsSet.add(pO), KO.extensions = KO.extensions || {}, KO.extensions[gl] = XO
          } else if (pO instanceof kp) {
            const OO = pO.transmissionWeight > 0 && !pO.geometryThinWalled,
              XO = pO.subsurfaceWeight > 0 && !pO.geometryThinWalled;
            if (OO || XO) {
              this._wasUsed = !0;
              const bK = pO.geometryThickness,
                eO = this._exporter._materialExporter.getTextureInfo(pO.geometryThicknessTexture) ?? void 0;
              let lO;
              eO && this._exporter._materialNeedsUVsSet.add(pO);
              const vK = GO.e.White().WhO();
              if (OO && pO.transmissionDepth > 0) {
                const OO = 1 / pO.transmissionDepth;
                let KO = new HO.o(-Math.log(pO.transmissionColor.r) * OO, -Math.log(pO.transmissionColor.g) * OO, -Math.log(pO.transmissionColor.b) * OO);
                const XO = new HO.o(pO.transmissionScatter.r * OO, pO.transmissionScatter.g * OO, pO.transmissionScatter.b * OO),
                  bK = KO.subtract(XO),
                  eO = Math.min(bK.x, bK.y, bK.z);
                eO < 0 && (bK.x = bK.x - eO, bK.y = bK.y - eO, bK.z = bK.z - eO), KO = bK.add(XO);
                lO = 1 / Math.max(KO.x, KO.y, KO.z), vK[0] = Math.exp(-KO.x * lO), vK[1] = Math.exp(-KO.y * lO), vK[2] = Math.exp(-KO.z * lO)
              } else lO = Number.MAX_VALUE, vK[0] = 1, vK[1] = 1, vK[2] = 1;
              let CO = 1;
              const hO = GO.e.White().WhO();
              if (XO) {
                const OO = pO.subsurfaceRadius,
                  KO = pO.subsurfaceRadiusScale,
                  XO = new HO.o(KO.r, KO.g, KO.b).multiplyByFloats(OO, OO, OO),
                  bK = new HO.o(1 / Math.max(XO.x, 1e-6), 1 / Math.max(XO.y, 1e-6), 1 / Math.max(XO.z, 1e-6));
                CO = 1 / Math.max(bK.x, bK.y, bK.z), hO[0] = Math.exp(-bK.x * CO), hO[1] = Math.exp(-bK.y * CO), hO[2] = Math.exp(-bK.z * CO)
              }
              const DO = (1 - pO.transmissionWeight) * pO.subsurfaceWeight,
                MO = DO + pO.transmissionWeight,
                aK = 1 / Math.max(MO, 1e-6),
                oO = pO.transmissionWeight * aK,
                FO = DO * aK,
                VO = vK.map(((OO, KO) => OO * oO + hO[KO] * FO)),
                LO = {
                  thicknessFactor: bK,
                  thicknessTexture: eO,
                  attenuationDistance: lO * oO + CO * FO,
                  attenuationColor: VO
                };
              KO.extensions = KO.extensions || {}, KO.extensions[gl] = LO
            }
          }
          OO(KO)
        }))
      }
    }
    let Ee = !1;

    function jl() {
      Ee || (Ee = !0, rb.RegisterExtension(gl, (OO => new ue(OO))))
    }
    jl();
    const Ye = "KHR_materials_volume_scatter";
    class we {
      constructor(OO) {
        this.name = Ye, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        return pO instanceof kp && (pO.transmissionWeight > 0 && pO.transmissionScatterTexture && XO.push(pO.transmissionScatterTexture), pO.subsurfaceWeight > 0 && pO.subsurfaceColorTexture && XO.push(pO.subsurfaceColorTexture)), XO
      }
      _isExtensionEnabled(OO) {
        if (OO.unlit) return !1;
        const KO = OO.transmissionWeight > 0 && !OO.geometryThinWalled && OO.transmissionDepth > 0 && !OO.transmissionScatter.equals(GO.e.Black()),
          pO = OO.subsurfaceWeight > 0 && !OO.geometryThinWalled;
        return !(!KO && !pO)
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          if (pO instanceof kp && this._isExtensionEnabled(pO)) {
            this._wasUsed = !0;
            let OO = HO.o.Zero(),
              XO = 0;
            if (pO.transmissionWeight > 0) {
              OO = function(OO) {
                const KO = new HO.o(Math.sqrt(1 - OO.x), Math.sqrt(1 - OO.y), Math.sqrt(1 - OO.z)),
                  pO = new HO.o(1, 1, 1),
                  XO = pO.subtract(KO),
                  bK = pO.subtract(new HO.o(.139, .139, .139).multiplyInPlace(KO)),
                  eO = pO.add(new HO.o(1.17, 1.17, 1.17).multiplyInPlace(KO));
                return XO.multiplyInPlace(bK).divideInPlace(eO)
              }(new HO.o(pO.transmissionScatter.r, pO.transmissionScatter.g, pO.transmissionScatter.b)), XO = pO.transmissionScatterAnisotropy
            }
            const bK = HO.o.Zero();
            let eO = 0;
            pO.subsurfaceWeight > 0 && (bK.set(pO.subsurfaceColor.r, pO.subsurfaceColor.g, pO.subsurfaceColor.b), eO = pO.subsurfaceScatterAnisotropy);
            const lO = (1 - pO.transmissionWeight) * pO.subsurfaceWeight,
              vK = lO + pO.transmissionWeight,
              CO = 1 / Math.max(vK, 1e-6),
              hO = pO.transmissionWeight * CO,
              DO = lO * CO,
              MO = {
                multiscatterColorFactor: OO.multiplyByFloats(hO, hO, hO).addInPlace(bK.multiplyByFloats(DO, DO, DO)).WhO(),
                scatterAnisotropy: XO * hO + eO * DO
              };
            if (pO.subsurfaceWeight > 0 && pO.subsurfaceColorTexture) {
              this._exporter._materialNeedsUVsSet.add(pO);
              const OO = this._exporter._materialExporter.getTextureInfo(pO.subsurfaceColorTexture);
              OO && (MO.multiscatterColorTexture = OO)
            } else if (pO.transmissionWeight > 0 && pO.transmissionScatterTexture) {
              this._exporter._materialNeedsUVsSet.add(pO);
              const OO = this._exporter._materialExporter.getTextureInfo(pO.transmissionScatterTexture);
              OO && (MO.multiscatterColorTexture = OO)
            }
            KO.extensions = KO.extensions || {}, KO.extensions[Ye] = MO
          }
          OO(KO)
        }))
      }
    }
    let il = !1;

    function rl() {
      il || (il = !0, rb.RegisterExtension(Ye, (OO => new we(OO)), 101))
    }
    rl();
    const Pe = "KHR_materials_diffuse_roughness";
    class ml {
      constructor(OO) {
        this.name = Pe, this.enabled = !0, this.required = !1, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      async postExportMaterialAdditionalTexturesAsync(OO, KO, pO) {
        const XO = [];
        if (pO instanceof TK) {
          if (pO._baseDiffuseRoughness) return pO._baseDiffuseRoughnessTexture && XO.push(pO._baseDiffuseRoughnessTexture), XO
        } else if (pO instanceof kp && pO.baseDiffuseRoughness) return pO.baseDiffuseRoughnessTexture && XO.push(pO.baseDiffuseRoughnessTexture), XO;
        return []
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          let XO = null,
            bK = null;
          if (pO instanceof TK ? (XO = pO._baseDiffuseRoughness, bK = pO._baseDiffuseRoughnessTexture) : pO instanceof kp && (XO = pO.baseDiffuseRoughness, bK = pO.baseDiffuseRoughnessTexture), !XO) return void OO(KO);
          this._wasUsed = !0, KO.extensions = KO.extensions || {};
          const eO = {
            diffuseRoughnessFactor: XO,
            diffuseRoughnessTexture: this._exporter._materialExporter.getTextureInfo(bK) ?? void 0
          };
          null !== eO.diffuseRoughnessTexture && this._exporter._materialNeedsUVsSet.add(pO), KO.extensions[Pe] = eO, OO(KO)
        }))
      }
    }
    let se = !1;

    function He() {
      se || (se = !0, rb.RegisterExtension(Pe, (OO => new ml(OO))))
    }
    He();
    const Re = "KHR_materials_openpbr";
    class Se {
      constructor() {
        this.name = Re, this.enabled = !0, this.required = !1, this._wasUsed = !1
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      postExportMaterialAsync(OO, KO, pO) {
        return new Promise((OO => {
          pO instanceof kp && (this._wasUsed = !0, KO.extensions = KO.extensions || {}, KO.extensions[Re] = {}), OO(KO)
        }))
      }
    }
    let Je = !1;

    function cl() {
      Je || (Je = !0, rb.RegisterExtension(Re, (() => new Se)))
    }
    cl();
    const Be = "KHR_texture_transform";
    class Ze {
      constructor() {
        this.name = Be, this.enabled = !0, this.required = !1, this._wasUsed = !1
      }
      dispose() {}
      get wasUsed() {
        return this._wasUsed
      }
      postExportTexture(OO, KO, pO) {
        if (pO.JKO() || IK.k.Warn(`${OO}: "scene" is not defined for Babylon texture ${pO.name}!`), (0 !== pO.uAng || 0 !== pO.vAng) && (IK.k.Warn(`${OO}: Texture ${pO.name} with rotation in the u or v axis is not supported in glTF.`), 0 !== pO.uRotationCenter || 0 !== pO.vRotationCenter)) return;
        const XO = {};
        let bK = !1;
        if (0 === pO.uOffset && 0 === pO.vOffset || (XO.offset = [pO.uOffset, pO.vOffset], bK = !0), 1 === pO.uScale && 1 === pO.vScale || (XO.scale = [pO.uScale, pO.vScale], bK = !0), 0 !== pO.wAng) {
          if (0 !== pO.uRotationCenter || 0 !== pO.vRotationCenter) {
            if (pO.homogeneousRotationInUVTransform && pO.uScale !== pO.vScale) return void IK.k.Warn(`${OO}: Texture ${pO.name} with homogenousRotationInUVTransform, non-uniform scaling, and non-zero rotation cannot be exported with ${Be}.`);
            IK.k.Warn(`${OO}: Texture ${pO.name} with non-origin rotation center will be exported using an adjusted offset with ${Be}.`), XO.offset = function(OO) {
              const {
                uOffset: KO,
                vOffset: pO,
                uRotationCenter: XO,
                vRotationCenter: bK,
                uScale: eO,
                vScale: lO,
                wAng: vK
              } = OO, CO = Math.cos(vK), hO = Math.sin(vK), DO = XO * eO, MO = bK * lO;
              return [KO + (DO * (1 - CO) + MO * hO), pO + (MO * (1 - CO) - DO * hO)]
            }(pO)
          }
          XO.rotation = -pO.wAng, bK = !0
        }
        0 !== pO.coordinatesIndex && (XO.texCoord = pO.coordinatesIndex, bK = !0), bK && (this._wasUsed = !0, KO.extensions || (KO.extensions = {}), KO.extensions[Be] = XO)
      }
    }
    let Ge = !1;

    function ql() {
      Ge || (Ge = !0, rb.RegisterExtension(Be, (() => new Ze)))
    }
    ql();
    var xl = pO(38104);
    const ne = "KHR_texture_basisu";
    class We {
      get wasUsed() {
        return this._wasUsed
      }
      constructor(OO) {
        this.name = ne, this.enabled = !0, this.required = !0, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      postExportTexture(OO, KO) {
        const pO = this._exporter._textures[KO.index],
          XO = pO.source;
        if (void 0 === XO) return;
        const bK = this._exporter._images[XO];
        "image/ktx2" === (bK.mimeType || (0, xl.i)(bK.uri)) && (pO.source = void 0, pO.extensions || (pO.extensions = {}), pO.extensions[ne] = {
          source: XO
        }, this._wasUsed = !0)
      }
    }
    let tl = !1;

    function kl() {
      tl || (tl = !0, rb.RegisterExtension(ne, (OO => new We(OO))))
    }
    kl();
    const Ue = "EXT_texture_webp";
    class Ol {
      get wasUsed() {
        return this._wasUsed
      }
      constructor(OO) {
        this.name = Ue, this.enabled = !0, this.required = !0, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      postExportTexture(OO, KO) {
        const pO = this._exporter._textures[KO.index],
          XO = pO.source;
        if (void 0 === XO) return;
        const bK = this._exporter._images[XO];
        "image/webp" === (bK.mimeType || (0, xl.i)(bK.uri)) && (pO.source = void 0, pO.extensions || (pO.extensions = {}), pO.extensions[Ue] = {
          source: XO
        }, this._wasUsed = !0)
      }
    }
    let Kl = !1;

    function pl() {
      Kl || (Kl = !0, rb.RegisterExtension(Ue, (OO => new Ol(OO))))
    }
    pl();
    const Xl = "EXT_texture_avif";
    class bv {
      get wasUsed() {
        return this._wasUsed
      }
      constructor(OO) {
        this.name = Xl, this.enabled = !0, this.required = !0, this._wasUsed = !1, this._exporter = OO
      }
      dispose() {}
      postExportTexture(OO, KO) {
        const pO = this._exporter._textures[KO.index],
          XO = pO.source;
        if (void 0 === XO) return;
        const bK = this._exporter._images[XO];
        "image/avif" === (bK.mimeType || (0, xl.i)(bK.uri)) && (pO.source = void 0, pO.extensions || (pO.extensions = {}), pO.extensions[Xl] = {
          source: XO
        }, this._wasUsed = !0)
      }
    }
    let el = !1;

    function ll() {
      el || (el = !0, rb.RegisterExtension(Xl, (OO => new bv(OO))))
    }
    ll();
    class vv {
      static CreateSTL(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "stlmesh",
          bK = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          eO = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
          lO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
          vK = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
          CO = arguments.length > 7 && void 0 !== arguments[7] && arguments[7];
        const hO = function(OO, KO, pO) {
            const bK = [3 * OO[pO], 3 * OO[pO + 1], 3 * OO[pO + 2]],
              eO = [new XO.WX(KO[bK[0]], KO[bK[0] + 2], KO[bK[0] + 1]), new XO.WX(KO[bK[1]], KO[bK[1] + 2], KO[bK[1] + 1]), new XO.WX(KO[bK[2]], KO[bK[2] + 2], KO[bK[2] + 1])],
              lO = eO[0].subtract(eO[1]),
              vK = eO[2].subtract(eO[1]);
            return {
              v: eO,
              n: XO.WX.Cross(vK, lO).normalize()
            }
          },
          MO = function(OO, KO, pO, XO) {
            return KO = aK(OO, KO, pO.x, XO), KO = aK(OO, KO, pO.y, XO), aK(OO, KO, pO.z, XO)
          },
          aK = function(OO, KO, pO, XO) {
            return OO.setFloat32(KO, pO, XO), KO + 4
          },
          FO = function(OO) {
            if (vK) {
              let KO = OO;
              OO instanceof oO.b && (KO = OO.SDO);
              const pO = KO.getVerticesData(DO.f.PositionKind, !0, !0);
              if (!pO) return [];
              const bK = XO.WX.Zero();
              let eO;
              for (eO = 0; eO < pO.length; eO += 3) XO.WX.TransformCoordinatesFromFloatsToRef(pO[eO], pO[eO + 1], pO[eO + 2], OO.computeWorldMatrix(!0), bK).toArray(pO, eO);
              return pO
            }
            return OO.getVerticesData(DO.f.PositionKind) || []
          };
        vK && (lO = !0);
        let VO = "",
          LO = 0,
          QO = 0;
        if (bK) {
          for (let pO = 0; pO < OO.length; pO++) {
            const KO = OO[pO].rFO();
            LO += KO ? KO.length / 3 : 0
          }
          const KO = new ArrayBuffer(84 + 50 * LO);
          VO = new DataView(KO), QO += 80, VO.setUint32(QO, LO, eO), QO += 4
        } else CO || (VO = "solid stlmesh\r\n");
        for (let XO = 0; XO < OO.length; XO++) {
          const KO = OO[XO];
          !bK && CO && (VO += "solid " + KO.name + "\r\n"), !lO && KO instanceof hX.c && KO.bakeCurrentTransformIntoVertices();
          const pO = FO(KO),
            vK = KO.rFO() || [];
          for (let OO = 0; OO < vK.length; OO += 3) {
            const KO = hO(vK, pO, OO);
            bK ? (QO = MO(VO, QO, KO.n, eO), QO = MO(VO, QO, KO.v[0], eO), QO = MO(VO, QO, KO.v[1], eO), QO = MO(VO, QO, KO.v[2], eO), QO += 2) : (VO += "\tfacet normal " + KO.n.x + " " + KO.n.y + " " + KO.n.z + "\r\n", VO += "\t\touter loop\r\n", VO += "\t\t\tvertex " + KO.v[0].x + " " + KO.v[0].y + " " + KO.v[0].z + "\r\n", VO += "\t\t\tvertex " + KO.v[1].x + " " + KO.v[1].y + " " + KO.v[1].z + "\r\n", VO += "\t\t\tvertex " + KO.v[2].x + " " + KO.v[2].y + " " + KO.v[2].z + "\r\n", VO += "\t\tendloop\r\n", VO += "\tendfacet\r\n")
          }!bK && CO && (VO += "endsolid " + name + "\r\n")
        }
        if (bK || CO || (VO += "endsolid stlmesh"), KO) {
          const OO = document.createElement("a"),
            KO = new Blob([VO], {
              type: "application/octet-stream"
            });
          OO.href = window.URL.createObjectURL(KO), OO.download = pO + ".stl", OO.click()
        }
        return VO
      }
    }

    function Cl(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 3,
        XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      const bK = [];
      for (let eO = 0; eO < OO.length / pO; eO++) {
        const lO = OO[eO * pO] * (XO ? -1 : 1),
          vK = OO[eO * pO + 1],
          CO = OO[eO * pO + 2];
        bK.push(`(${lO.toPrecision(KO.precision)}, ${vK.toPrecision(KO.precision)}, ${CO.toPrecision(KO.precision)})`)
      }
      return bK.join(", ")
    }

    function hl(OO, KO) {
      const pO = [];
      for (let XO = 0; XO < OO.length / 2; XO++) {
        const bK = OO[2 * XO],
          eO = OO[2 * XO + 1];
        pO.push(`(${bK.toPrecision(KO.precision)}, ${(1-eO).toPrecision(KO.precision)})`)
      }
      return pO.join(", ")
    }

    function Dl(OO, KO, pO, XO) {
      const bK = OO.getVerticesData(DO.f.PositionKind),
        eO = OO.getVerticesData(DO.f.NormalKind);
      if (bK && eO) return `\n\tdef Mesh "Geometry"\n\t{\n        uniform token orientation = "${pO}"\n\t\tint[] faceVertexCounts = [${function(OO){const KO=OO.rFO()?.length?OO.getTotalIndices():OO.getTotalVertices();return Array(KO/3).fill(3).join(", ")}(OO)}]\n\t\tint[] faceVertexIndices = [${function(OO){const KO=OO.rFO(),pO=KO?.length??OO.getTotalVertices(),XO=[];if(null!==KO)for(let bK=0;bK<pO;bK++)XO.push(KO[bK]);else for(let bK=0;bK<pO;bK++)XO.push(bK);return XO.join(", ")}(OO)}]\n\t\tnormal3f[] normals = [${Cl(eO,KO,void 0,XO)}] (\n\t\t\tinterpolation = "vertex"\n\t\t)\n\t\tpoint3f[] points = [${Cl(bK,KO,void 0,XO)}]\n        ${function(OO,KO){let pO="";for(let bK=0;bK<4;bK++){const XO=bK>0?bK:"",eO=OO.getVerticesData(DO.f.UVKind+(XO?XO+1:""));eO&&(pO+=`\n\t\ttexCoord2f[] primvars:st${XO} = [${hl(eO,KO)}] (\n\t\t\tinterpolation = "vertex"\n\t\t)`)}const XO=OO.getVerticesData(DO.f.ColorKind);return XO&&(pO+=`\
      n\ tcolor3f[] primvars: displayColor = [$ {
        Cl(XO, KO, XO.length / OO.getTotalVertices())
      }](\n\ t\ tinterpolation = "vertex"\
        n\ t\ t)`),pO}(OO,KO)}\n\t\tuniform token subdivisionScheme = "none"\n\t}\n`
    }

    function Ml(OO, KO, pO, XO) {
      return `\n        def "Geometry"\n        {\n        ${Dl(OO,KO,pO,XO)}\n        }\n        `
    }

    function av(OO) {
      let KO = '#usda 1.0\n    (\n        customLayerData = {\n            string creator = "Babylon.js USDZExportAsync"\n        }\n        defaultPrim = "Root"\n        metersPerUnit = 1\n        upAxis = "Y"\n    )';
      return KO += OO, fflate.strToU8(KO)
    }

    function ol(OO) {
      const KO = OO.m;
      return `( ${Fl(KO,0)}, ${Fl(KO,4)}, ${Fl(KO,8)}, ${Fl(KO,12)} )`
    }

    function Fl(OO, KO) {
      return `(${OO[KO+0]}, ${OO[KO+1]}, ${OO[KO+2]}, ${OO[KO+3]})`
    }

    function Vl(OO, KO) {
      const pO = "Object_" + OO.uniqueId,
        XO = ol(KO);
      return `def Xform "${pO}" (\n\tprepend references = @./geometries/Geometry_${OO.geometry.uniqueId}.usda@</Geometry>\n\tprepend apiSchemas = ["MaterialBindingAPI"]\n)\n{\n\tmatrix4d xformOp:transform = ${XO}\n\tuniform token[] xformOpOrder = ["xformOp:transform"]\t\n\n    rel material:binding = </Root/Materials/Material_${OO.material.uniqueId}>\n}\n\n`
    }

    function Ll(OO) {
      switch (OO) {
        case NO.b.TEXTURE_CLAMP_ADDRESSMODE:
          return "clamp";
        case NO.b.TEXTURE_MIRROR_ADDRESSMODE:
          return "mirror";
        case NO.b.TEXTURE_WRAP_ADDRESSMODE:
        default:
          return "repeat"
      }
    }

    function Ql(OO) {
      return `(${OO.x}, ${OO.y})`
    }

    function zv(OO) {
      return `(${OO.r}, ${OO.g}, ${OO.b})`
    }

    function Al(OO) {
      return "image/jpeg" === OO || "image/png" === OO
    }

    function fl(OO, KO, pO, bK, eO, lO) {
      const vK = OO.getInternalTexture().uniqueId + "_" + OO.invertY,
        hO = OO.mimeType || (0, CO.e)(OO.getInternalTexture()?.url ?? ""),
        DO = Al(hO) ? hO : "image/png",
        MO = "image/jpeg" === DO ? "jpg" : "png";
      eO[vK] = {
        texture: OO,
        mimeType: DO,
        ext: MO
      };
      const aK = OO.coordinatesIndex > 0 ? "st" + OO.coordinatesIndex : "st",
        oO = new XO.Vector2(OO.uScale, OO.vScale),
        FO = new XO.Vector2(OO.uOffset, OO.vOffset),
        VO = OO.wAng,
        LO = Math.sin(VO),
        QO = Math.cos(VO);
      return FO.y = 1 - FO.y - oO.y, FO.x += LO * oO.x, FO.y += (1 - QO) * oO.y, `\n    def Shader "PrimvarReader_${pO}"\n    {\n        uniform token info:id = "UsdPrimvarReader_float2"\n        float2 inputs:fallback = (0.0, 0.0)\n        token inputs:varname = "${aK}"\n        float2 outputs:result\n    }\n\n    def Shader "Transform2d_${pO}"\n    {\n        uniform token info:id = "UsdTransform2d"\n        token inputs:in.connect = </Root/Materials/Material_${KO.uniqueId}/PrimvarReader_${pO}.outputs:result>\n        float inputs:rotation = ${(VO*(180/Math.PI)).toFixed(lO.precision)}\n        float2 inputs:scale = ${Ql(oO)}\n        float2 inputs:translation = ${Ql(FO)}\n        float2 outputs:result\n    }\n\n    def Shader "Texture_${OO.uniqueId}_${pO}"\n    {\n        uniform token info:id = "UsdUVTexture"\n        asset inputs:file = @textures/Texture_${vK}.${MO}@\n        float2 inputs:st.connect = </Root/Materials/Material_${KO.uniqueId}/Transform2d_${pO}.outputs:result>\n        ${bK?"float4 inputs:scale = "+function(OO){return`(${OO.r}, ${OO.g}, ${OO.b}, 1.0)`}(bK):""}\n        token inputs:sourceColorSpace = "${OO.gammaSpace?"sRGB":"raw"}"\n        token inputs:wrapS = "${Ll(OO.wrapU)}"\n        token inputs:wrapT = "${Ll(OO.wrapV)}"\n        float outputs:r\n        float outputs:g\n        float outputs:b\n        float3 outputs:rgb\n        ${KO.needAlphaBlending()||KO.needAlphaTesting()?"float outputs:a":""}\n    }`
    }

    function dl(OO, KO, pO) {
      const XO = "\t\t\t",
        bK = [],
        eO = [],
        {
          diffuseMap: lO,
          diffuse: vK,
          alphaCutOff: CO,
          emissiveMap: hO,
          emissive: DO,
          normalMap: MO,
          roughnessMap: aK,
          roughnessChannel: oO,
          roughness: FO,
          metalnessMap: VO,
          metalnessChannel: QO,
          metalness: zK,
          aoMap: AO,
          aoMapChannel: fO,
          aoMapIntensity: dO,
          alphaMap: TO,
          ior: NO,
          clearCoatEnabled: IO,
          clearCoat: yK,
          clearCoatMap: gK,
          clearCoatRoughness: uO,
          clearCoatRoughnessMap: EO
        } = function(OO) {
          const KO = {
            diffuseMap: null,
            diffuse: null,
            alphaCutOff: 0,
            emissiveMap: null,
            emissive: null,
            normalMap: null,
            roughnessMap: null,
            roughnessChannel: "a",
            roughness: 0,
            metalnessMap: null,
            metalnessChannel: "r",
            metalness: 0,
            aoMap: null,
            aoMapChannel: "rgb",
            aoMapIntensity: 0,
            alphaMap: null,
            ior: 1,
            clearCoatEnabled: !1,
            clearCoat: 0,
            clearCoatMap: null,
            clearCoatRoughness: 0,
            clearCoatRoughnessMap: null
          };
          return OO instanceof eX.StandardMaterial ? {
            ...KO,
            diffuseMap: OO.diffuseTexture,
            diffuse: OO.diffuseColor,
            alphaCutOff: OO.alphaCutOff,
            emissiveMap: OO.emissiveTexture,
            emissive: OO.emissiveColor,
            roughness: 1,
            alphaMap: OO.opacityTexture
          } : OO instanceof TK ? {
            ...KO,
            diffuseMap: OO._albedoTexture,
            diffuse: OO._albedoColor,
            alphaCutOff: OO._alphaCutOff,
            emissiveMap: OO._emissiveTexture,
            emissive: OO._emissiveColor,
            normalMap: OO._bumpTexture,
            roughnessMap: OO._metallicTexture,
            roughnessChannel: OO._useRoughnessFromMetallicTextureAlpha ? "a" : "g",
            roughness: OO._roughness ?? 1,
            metalnessMap: OO._metallicTexture,
            metalnessChannel: OO._useMetallnessFromMetallicTextureBlue ? "b" : "r",
            metalness: OO._metallic ?? 0,
            aoMap: OO._ambientTexture,
            aoMapChannel: OO._useAmbientInGrayScale ? "r" : "rgb",
            aoMapIntensity: OO._ambientTextureStrength,
            alphaMap: OO._opacityTexture,
            ior: OO.subSurface.indexOfRefraction,
            clearCoatEnabled: OO.clearCoat.isEnabled,
            clearCoat: OO.clearCoat.intensity,
            clearCoatMap: OO.clearCoat.texture,
            clearCoatRoughness: OO.clearCoat.roughness,
            clearCoatRoughnessMap: OO.clearCoat.useRoughnessFromMainTexture ? OO.clearCoat.texture : OO.clearCoat.textureRoughness
          } : KO
        }(OO);
      return null !== lO ? (bK.push(`${XO}color3f inputs:diffuseColor.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${lO.uniqueId}_diffuse.outputs:rgb>`), OO.needAlphaBlending() ? bK.push(`${XO}float inputs:opacity.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${lO.uniqueId}_diffuse.outputs:a>`) : OO.needAlphaTesting() && (bK.push(`${XO}float inputs:opacity.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${lO.uniqueId}_diffuse.outputs:a>`), bK.push(`${XO}float inputs:opacityThreshold = ${CO}`)), eO.push(fl(lO, OO, "diffuse", vK, KO, pO))) : bK.push(`${XO}color3f inputs:diffuseColor = ${zv(vK||LO.Color3.White())}`), null !== hO ? (bK.push(`${XO}color3f inputs:emissiveColor.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${hO.uniqueId}_emissive.outputs:rgb>`), eO.push(fl(hO, OO, "emissive", DO, KO, pO))) : DO && DO.toLuminance() > 0 && bK.push(`${XO}color3f inputs:emissiveColor = ${zv(DO)}`), null !== MO && (bK.push(`${XO}normal3f inputs:normal.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${MO.uniqueId}_normal.outputs:rgb>`), eO.push(fl(MO, OO, "normal", null, KO, pO))), null !== AO && (bK.push(`${XO}float inputs:occlusion.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${AO.uniqueId}_occlusion.outputs:${fO}>`), eO.push(fl(AO, OO, "occlusion", new LO.Color3(dO, dO, dO), KO, pO))), null !== aK ? (bK.push(`${XO}float inputs:roughness.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${aK.uniqueId}_roughness.outputs:${oO}>`), eO.push(fl(aK, OO, "roughness", new LO.Color3(FO, FO, FO), KO, pO))) : bK.push(`${XO}float inputs:roughness = ${FO}`), null !== VO ? (bK.push(`${XO}float inputs:metallic.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${VO.uniqueId}_metallic.outputs:${QO}>`), eO.push(fl(VO, OO, "metallic", new LO.Color3(zK, zK, zK), KO, pO))) : bK.push(`${XO}float inputs:metallic = ${zK}`), null !== TO ? (bK.push(`${XO}float inputs:opacity.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${TO.uniqueId}_opacity.outputs:r>`), bK.push(`${XO}float inputs:opacityThreshold = 0.0001`), eO.push(fl(TO, OO, "opacity", null, KO, pO))) : bK.push(`${XO}float inputs:opacity = ${OO.alpha}`), IO && (null !== gK ? (bK.push(`${XO}float inputs:clearcoat.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${gK.uniqueId}_clearcoat.outputs:r>`), eO.push(fl(gK, OO, "clearcoat", new LO.Color3(yK, yK, yK), KO, pO))) : bK.push(`${XO}float inputs:clearcoat = ${yK}`), null !== EO ? (bK.push(`${XO}float inputs:clearcoatRoughness.connect = </Root/Materials/Material_${OO.uniqueId}/Texture_${EO.uniqueId}_clearcoatRoughness.outputs:g>`), eO.push(fl(EO, OO, "clearcoatRoughness", new LO.Color3(uO, uO, uO), KO, pO))) : bK.push(`${XO}float inputs:clearcoatRoughness = ${uO}`)), bK.push(`${XO}float inputs:ior = ${NO}`), `\n\tdef Material "Material_${OO.uniqueId}"\n\t{\n\t\tdef Shader "PreviewSurface"\n\t\t{\n\t\t\tuniform token info:id = "UsdPreviewSurface"\n${bK.join("\n")}\n\t\t\tint inputs:useSpecularWorkflow = 0\n\t\t\ttoken outputs:surface\n\t\t}\n\n\t\ttoken outputs:surface.connect = </Root/Materials/Material_${OO.uniqueId}/PreviewSurface.outputs:surface>\n\n${eO.join("\n")}\n\n\t}\n`
    }

    function Tl(OO) {
      OO.computeWorldMatrix(!0);
      const KO = OO.getWorldMatrix().clone(),
        pO = OO.JKO().useRightHandedSystem;
      let XO = OO.material?._getEffectiveOrientation(OO) ?? OO.sideOrientation,
        lO = !pO,
        vK = OO.parent;
      for (; vK;) {
        if (Pp(vK, pO) && null === vK.parent) {
          pO || (KO.multiplyToRef(vK.getWorldMatrix().invert(), KO), XO = XO === eO.b.ClockWiseSideOrientation ? eO.b.CounterClockWiseSideOrientation : eO.b.ClockWiseSideOrientation), lO = !1;
          break
        }
        vK = vK.parent
      }
      return KO.determinant() < 0 && bK.Tools.Warn(`Mesh ${OO.name} has a negative scale, which may look incorrect in destinations like QuickLook.`), {
        matrix: KO,
        windingOrder: XO === eO.b.ClockWiseSideOrientation ? "leftHanded" : "rightHanded",
        convertToRightHanded: lO
      }
    }
    async function Nl(OO, KO, pO) {
      const eO = {
        fflateUrl: "https://unpkg.com/fflate@0.8.2",
        includeAnchoringProperties: !0,
        anchoringType: "plane",
        planeAnchoringAlignment: "horizontal",
        modelFileName: "model.usda",
        precision: 5,
        exportCamera: !1,
        cameraSensorWidth: 35,
        ...KO
      };
      "undefined" === typeof fflate && await bK.Tools.LoadScriptAsync(eO.fflateUrl);
      const lO = {};
      lO[eO.modelFileName] = null;
      let vK = '#usda 1.0\n    (\n        customLayerData = {\n            string creator = "Babylon.js USDZExportAsync"\n        }\n        defaultPrim = "Root"\n        metersPerUnit = 1\n        upAxis = "Y"\n    )';
      vK += function(OO) {
        return `def Xform "Root"\n    {\n        def Scope "Scenes" (\n            kind = "sceneLibrary"\n        )\n        {\n            def Xform "Scene" (\n                customData = {\n                    bool preliminary_collidesWithEnvironment = 0\n                    string sceneName = "Scene"\n                }\n                sceneName = "Scene"\n            )\n            {${!0===OO.includeAnchoringProperties?`\n\t\ttoken preliminary:anchoring:type = "${OO.anchoringType}"\n\t\ttoken preliminary:planeAnchoring:alignment = "${OO.planeAnchoringAlignment}"`:""}\n            `
      }(eO);
      const CO = {};
      for (const XO of OO.meshes) {
        if (0 === XO.getTotalVertices()) continue;
        const OO = XO,
          KO = OO.geometry,
          hO = OO.material;
        if (!hO || !KO || pO && !pO(OO)) continue;
        if (-1 !== ["StandardMaterial", "PBRMaterial", "PBRMetallicRoughnessMaterial"].indexOf(hO.getClassName())) {
          const pO = "geometries/Geometry_" + KO.uniqueId + ".usda",
            {
              matrix: XO,
              windingOrder: bK,
              convertToRightHanded: DO
            } = Tl(OO);
          if (!(pO in lO)) {
            const OO = Ml(KO, eO, bK, DO);
            lO[pO] = av(OO)
          }
          hO.uniqueId in CO || (CO[hO.uniqueId] = hO), vK += Vl(OO, XO)
        } else bK.Tools.Warn("USDZExportAsync does not support this material type: " + hO.getClassName())
      }
      OO.activeCamera && eO.exportCamera && (vK += function(OO, KO) {
        const pO = "Camera_" + OO.uniqueId,
          bK = ol(XO.Matrix.RotationY(Math.PI).multiply(OO.getWorldMatrix()));
        if (OO.mode === NO.b.ORTHOGRAPHIC_CAMERA) return `def Camera "${pO}"\n\t\t{\n\t\t\tmatrix4d xformOp:transform = ${bK}\n\t\t\tuniform token[] xformOpOrder = ["xformOp:transform"]\n\n\t\t\tfloat2 clippingRange = (${OO.minZ.toPrecision(KO.precision)}, ${OO.maxZ.toPrecision(KO.precision)})\n\t\t\tfloat horizontalAperture = ${(10*(Math.abs(OO.orthoLeft||1)+Math.abs(OO.orthoRight||1))).toPrecision(KO.precision)}\n\t\t\tfloat verticalAperture = ${(10*(Math.abs(OO.orthoTop||1)+Math.abs(OO.orthoBottom||1))).toPrecision(KO.precision)}\n\t\t\ttoken projection = "orthographic"\n\t\t}\n\t\n\t`;
        {
          const XO = OO.qb().getAspectRatio(OO),
            eO = KO.cameraSensorWidth || 35;
          return `def Camera "${pO}"\n\t\t{\n\t\t\tmatrix4d xformOp:transform = ${bK}\n\t\t\tuniform token[] xformOpOrder = ["xformOp:transform"]\n\n\t\t\tfloat2 clippingRange = (${OO.minZ.toPrecision(KO.precision)}, ${OO.maxZ.toPrecision(KO.precision)})\n\t\t\tfloat focalLength = ${(eO/(2*Math.tan(.5*OO.fov))).toPrecision(KO.precision)}\n            token projection = "perspective"\n\t\t\tfloat horizontalAperture = ${(eO*XO).toPrecision(KO.precision)}\n\t\t\tfloat verticalAperture = ${(eO/XO).toPrecision(KO.precision)}            \n\t\t}\n\t\n\t`
        }
      }(OO.activeCamera, eO)), vK += "\n            }\n        }";
      const hO = {};
      vK += function(OO, KO, pO) {
        const XO = [];
        for (const bK in OO) {
          const eO = OO[bK];
          XO.push(dl(eO, KO, pO))
        }
        return `\n    def "Materials"\n{\n${XO.join("")}\n}\n\n`
      }(CO, hO, eO), vK += "\n    }", lO[eO.modelFileName] = fflate.strToU8(vK);
      for (const XO in hO) {
        const {
          texture: OO,
          ext: KO,
          mimeType: pO
        } = hO[XO], bK = await Qp(OO);
        if (bK && Al(bK.mimeType) && bK.mimeType === pO) lO[`textures/Texture_${XO}.${KO}`] = new Uint8Array(bK.data);
        else {
          const bK = OO.getSize(),
            eO = await (0, fO.h)(OO),
            vK = await IO.DumpTools.DumpDataAsync(bK.width, bK.height, eO, pO, void 0, !1, !0);
          lO[`textures/Texture_${XO}.${KO}`] = new Uint8Array(vK).slice()
        }
      }
      let DO = 0;
      for (const XO in lO) {
        const OO = lO[XO];
        if (!OO) continue;
        DO += 34 + XO.length;
        const KO = 63 & DO;
        if (4 !== KO) {
          const pO = new Uint8Array(64 - KO);
          lO[XO] = [OO, {
            extra: {
              12345: pO
            }
          }]
        }
        DO = OO.length
      }
      return fflate.zipSync(lO, {
        level: 0
      })
    }
    var Il = pO(39248);
    class yv {
      static Export(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
          pO = arguments.length > 2 ? arguments[2] : void 0;
        if (!OO || 0 === OO.bones.length) throw new Error("Invalid or empty skeleton provided");
        let XO = KO;
        KO && 0 !== KO.length || (XO = OO.animations.map((OO => OO.name)));
        let bK = null;
        for (const hO of XO) {
          const KO = OO.getAnimationRange(hO);
          KO && (bK = bK ? new Il.b("animation-range", Math.min(bK.from, KO.from), Math.max(bK.to, KO.to)) : KO)
        }
        if (!bK && (OO.animations.length > 0 && (bK = OO.getAnimationRange(OO.animations[0].name)), !bK)) throw new Error("No animation range found in skeleton");
        const eO = pO || 1 / (OO.animations[0]?.framePerSecond || 30),
          lO = this._BuildBoneHierarchy(OO, XO);
        let vK = 0;
        for (const hO of lO) hO.positionKeys.length > 0 && (vK = Math.max(vK, hO.positionKeys.length)), hO.rotationKeys.length > 0 && (vK = Math.max(vK, hO.rotationKeys.length));
        0 === vK && (vK = Math.floor((bK.to - bK.from) / eO) + 1);
        let CO = "";
        return CO += "HIERARCHY\n", CO += this._ExportHierarchy(lO, 0), CO += "MOTION\n", CO += `Frames: ${vK}\n`, CO += `Frame Time: ${eO.toFixed(6)}\n`, CO += this._ExportMotionData(lO, vK, 0, XO), CO
      }
      static _BuildBoneHierarchy(OO, KO) {
        const pO = new Map,
          XO = [];
        for (const bK of OO.bones) {
          const OO = {
            bone: bK,
            children: [],
            hasPositionChannels: !1,
            hasRotationChannels: !1,
            positionKeys: [],
            rotationKeys: []
          };
          pO.set(bK, OO)
        }
        for (const bK of OO.bones) {
          const OO = pO.get(bK);
          if (bK.animations.length > 0)
            for (const pO of bK.animations) KO.includes(pO.name) && ("position" === pO.targetProperty ? (OO.hasPositionChannels = !0, OO.positionKeys.push(...pO.getKeys())) : "rotationQuaternion" === pO.targetProperty && (OO.hasRotationChannels = !0, OO.rotationKeys.push(...pO.getKeys())));
          if (bK.getParent()) {
            const KO = pO.get(bK.getParent());
            KO && KO.children.push(OO)
          } else XO.push(OO)
        }
        return XO
      }
      static _ExportHierarchy(OO, KO) {
        let pO = "";
        const XO = "    ".repeat(KO);
        for (const bK of OO) {
          const OO = bK.bone;
          if (this._IsEndSite(bK)) {
            pO += `${XO}End Site\n`, pO += `${XO}{\n`;
            const KO = this._GetBoneOffset(OO);
            pO += `${XO}    OFFSET ${KO.x.toFixed(6)} ${KO.y.toFixed(6)} ${KO.z.toFixed(6)}\n`, pO += `${XO}}\n`
          } else {
            pO += `${0===KO?"ROOT":`${XO}JOINT`} ${OO.name}\n`, pO += `${XO}{\n`;
            const eO = this._GetBoneOffset(OO);
            pO += `${XO}    OFFSET ${eO.x.toFixed(6)} ${eO.y.toFixed(6)} ${eO.z.toFixed(6)}\n`;
            const lO = [];
            bK.hasPositionChannels && lO.push("Xposition", "Yposition", "Zposition"), bK.hasRotationChannels && lO.push("Zrotation", "Xrotation", "Yrotation"), lO.length > 0 && (pO += `${XO}    CHANNELS ${lO.length} ${lO.join(" ")}\n`), bK.children.length > 0 && (pO += this._ExportHierarchy(bK.children, KO + 1)), pO += `${XO}}\n`
          }
        }
        return pO
      }
      static _IsEndSite(OO) {
        return 0 === OO.children.length
      }
      static _GetBoneOffset(OO) {
        try {
          if (!OO.getParent()) return OO.getRestMatrix().getTranslation();
          return OO.getLocalMatrix().getTranslation()
        } catch (KO) {
          return XO.WX.Zero()
        }
      }
      static _ExportMotionData(OO, KO, pO, XO) {
        let bK = "";
        for (let eO = 0; eO < KO; eO++) {
          const KO = [];
          this._CollectFrameValues(OO, eO + pO, KO, XO), bK += KO.map((OO => OO.toFixed(6))).join(" ") + "\n"
        }
        return bK
      }
      static _CollectFrameValues(OO, KO, pO, XO) {
        for (const bK of OO)
          if (!this._IsEndSite(bK)) {
            if (bK.hasPositionChannels) {
              const OO = this._GetPositionAtFrameIndex(bK.positionKeys, KO);
              pO.push(OO.x, OO.y, OO.z)
            }
            if (bK.hasRotationChannels) {
              const OO = this._GetRotationAtFrameIndex(bK.rotationKeys, KO),
                XO = this._QuaternionToEuler(OO);
              pO.push(XO.z, XO.x, XO.y)
            }
            bK.children.length > 0 && this._CollectFrameValues(bK.children, KO, pO, XO)
          }
      }
      static _GetPositionAtFrameIndex(OO, KO) {
        if (0 === OO.length) return XO.WX.Zero();
        return OO[Math.max(0, Math.min(KO, OO.length - 1))].value.clone()
      }
      static _GetRotationAtFrameIndex(OO, KO) {
        if (0 === OO.length) return XO.Quaternion.Identity();
        return OO[Math.max(0, Math.min(KO, OO.length - 1))].value.clone()
      }
      static _QuaternionToEuler(OO) {
        const KO = new XO.Matrix;
        OO.toRotationMatrix(KO);
        const pO = KO.m;
        let eO, lO, vK;
        const CO = Math.sqrt(pO[0] * pO[0] + pO[1] * pO[1]);
        return CO > iX.c ? (eO = Math.atan2(pO[6], pO[10]), lO = Math.atan2(-pO[2], CO), vK = Math.atan2(pO[1], pO[0])) : (eO = Math.atan2(-pO[9], pO[5]), lO = Math.atan2(-pO[2], CO), vK = 0), new XO.WX(bK.Tools.ToDegrees(eO), bK.Tools.ToDegrees(lO), bK.Tools.ToDegrees(vK))
      }
    }

    function gv(OO) {
      return "string" === typeof OO?.name
    }
    const ul = Symbol("__xml:meta$__"),
      El = Symbol("__xml:name$__");

    function jv(OO, KO) {
      Object.prototype.hasOwnProperty.call(OO.metadata, ul) || (OO.metadata[ul] = []), OO.metadata[ul].push(KO)
    }

    function Yl(OO) {
      return (KO, pO) => {
        KO[El] = OO
      }
    }

    function wl() {
      return (OO, KO) => jv(KO, {
        kind: "none",
        prop: String(KO.name),
        ignore: !0
      })
    }

    function iv(OO) {
      return (KO, pO) => jv(pO, {
        kind: "attr",
        prop: String(pO.name),
        ...OO
      })
    }

    function rv(OO) {
      return (KO, pO) => jv(pO, {
        kind: "elem",
        prop: String(pO.name),
        ...OO
      })
    }

    function Pl(OO) {
      const KO = "function" === typeof OO ? OO : OO?.constructor,
        pO = KO?.[Symbol.metadata];
      if (!pO) return [];
      const XO = [];
      let bK = pO;
      for (; bK;) Object.prototype.hasOwnProperty.call(bK, ul) && XO.push(...bK[ul]), bK = Object.getPrototypeOf(bK);
      return XO
    }

    function mv(OO) {
      const KO = OO?.constructor?.[El];
      return KO || void 0
    }

    function sl(OO) {
      return /^[A-Za-z_][A-Za-z0-9._-]*$/.test(OO)
    }

    function Hl(OO) {
      if (gv(OO)) return OO;
      const KO = (OO ?? "").trim();
      if (!KO) return {
        name: ""
      };
      const pO = KO.indexOf(":");
      if (-1 === pO) return {
        name: KO
      };
      if (-1 !== KO.indexOf(":", pO + 1)) return {
        name: KO
      };
      const XO = KO.slice(0, pO),
        bK = KO.slice(pO + 1);
      return sl(XO) && sl(bK) ? {
        ns: XO,
        name: bK
      } : {
        name: KO
      }
    }

    function Rl(OO, KO) {
      return KO ? `${KO}:${OO}` : OO
    }
    const Sl = Object.freeze({
        eps: 1e-6,
        maxDecimalsCap: 15,
        trimTrailingZeros: !0,
        allowScientific: !1,
        snapNearZero: !0
      }),
      Jl = Object.freeze({
        number: Sl
      });

    function cv(OO) {
      const KO = OO?.eps ?? Sl.eps;
      return {
        eps: KO,
        maxDecimalsCap: OO?.maxDecimalsCap ?? Sl.maxDecimalsCap,
        trimTrailingZeros: OO?.trimTrailingZeros ?? Sl.trimTrailingZeros,
        fixedDecimals: OO?.fixedDecimals,
        allowScientific: OO?.allowScientific ?? Sl.allowScientific,
        snapNearZero: OO?.snapNearZero ?? Sl.snapNearZero,
        zeroThreshold: OO?.zeroThreshold ?? KO,
        perAttributeEps: OO?.perAttributeEps
      }
    }

    function Bl(OO) {
      return {
        number: cv(OO?.number)
      }
    }
    class Zl {
      constructor(OO) {
        if (this.o = OO, this._o = OO.number, !Number.isFinite(this._o.eps) || this._o.eps <= 0) throw new Error("opts.eps must be a finite, positive number")
      }
      toString(OO) {
        if (!Number.isFinite(OO)) throw new Error(`Cannot format non-finite number: ${OO}`);
        const KO = this._o,
          pO = this._clampInt(KO.maxDecimalsCap ?? 15, 0, 20),
          XO = KO.trimTrailingZeros ?? !0,
          bK = KO.snapNearZero ?? !0,
          eO = KO.zeroThreshold ?? KO.eps,
          lO = 1 / KO.eps;
        let vK, CO = Math.round(OO * lO) / lO;
        if (Object.is(CO, -0) && (CO = 0), bK && Math.abs(CO) <= eO && (CO = 0), vK = void 0 !== KO.fixedDecimals ? this._clampInt(KO.fixedDecimals, 0, pO) : this._clampInt(Math.ceil(-Math.log10(KO.eps)), 0, pO), KO.allowScientific, 0 === vK) return String(Math.trunc(CO));
        let hO = CO.toFixed(vK);
        if (XO && void 0 === KO.fixedDecimals && (hO = hO.replace(/(\.\d*?[1-9])0+$/, "$1").replace(/\.0+$/, "").replace(/\.$/, "")), /[eE]/.test(hO)) throw new Error(`Scientific notation not allowed in XML output: ${hO}`);
        return hO
      }
      _clampInt(OO, KO, pO) {
        return Number.isFinite(OO) ? (OO = Math.trunc(OO), Math.max(KO, Math.min(pO, OO))) : KO
      }
    }

    function Gl(OO) {
      return OO instanceof Date
    }

    function qv(OO) {
      return "string" === typeof OO
    }

    function xv(OO) {
      return "string" === typeof OO || "number" === typeof OO || "boolean" === typeof OO || "bigint" === typeof OO || Gl(OO)
    }

    function nl(OO) {
      return "number" === typeof OO || "boolean" === typeof OO || "bigint" === typeof OO || Gl(OO)
    }
    class Wl {
      constructor(OO, KO) {
        this._ns = new Map, this._prefixCount = 0, this._builder = OO, this._format = Bl(KO), this._nFmt = new Zl(this._format)
      }
      withNamespace() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        for (const XO of KO) this._assignNamespace(XO);
        return this
      }
      serialize(OO, KO) {
        if (!(KO = KO ?? mv(OO))) throw new Error("can not find name for given object");
        const pO = Hl(KO);
        pO.ns && this._assignNamespace(pO.ns, "xmlns"), this._gatherNamespaces(OO, new WeakSet);
        const XO = this._builder.ele(null, pO.name);
        for (const [bK, eO] of Array.from(this._ns.entries())) XO.att("xmlns", eO, bK);
        this._writeObjectContent(XO, OO, (new WeakSet).add(OO)), this._builder.end()
      }
      _writeObject(OO, KO, pO) {
        if (pO.has(KO)) return;
        if (pO.add(KO), Array.isArray(KO)) {
          for (const XO of KO) nl(XO) || (qv(XO) ? this._builder.text(XO) : this._writeObject(OO, XO, pO));
          return
        }
        const XO = mv(KO);
        if (!XO) return;
        const bK = Hl(XO),
          eO = this._getPrefix(bK),
          lO = Rl(bK.name, eO);
        OO.ele(null, lO), this._writeObjectContent(OO, KO, pO), this._builder.end()
      }
      _getPrefix(OO) {
        if (OO.ns) {
          const KO = this._ns.get(OO.ns.toLowerCase());
          if ("xmlns" !== KO) return KO
        }
      }
      _writeObjectContent(OO, KO, pO) {
        const XO = Pl(KO) ?? [],
          bK = new Map;
        for (const lO of XO) {
          const OO = bK.get(lO.prop) ?? [];
          OO.push(lO), bK.set(lO.prop, OO)
        }
        const eO = Object.keys(KO).sort(((OO, KO) => {
          const pO = (bK.get(OO) ?? []).some((OO => "attr" === OO.kind));
          return pO === (bK.get(KO) ?? []).some((OO => "attr" === OO.kind)) ? 0 : pO ? -1 : 1
        }));
        for (const lO of eO) {
          const XO = KO[lO];
          if (null === XO || void 0 === XO) continue;
          const eO = bK.get(lO);
          if (eO) {
            if (eO.some((OO => !0 === OO.ignore || "none" === OO.kind))) continue;
            for (const KO of eO) {
              const pO = KO.name ?? KO.prop.toLowerCase();
              if (pO) switch (KO.kind) {
                case "attr": {
                  let bK = null;
                  if ("number" === typeof XO && this._nFmt && (bK = this._nFmt.toString(XO)), KO.formatter) {
                    bK = new KO.formatter(this._format).toString(XO)
                  }
                  if (bK = bK ?? XO.toString(), bK) {
                    const KO = Hl(pO),
                      XO = this._getPrefix(KO),
                      eO = Rl(KO.name, XO);
                    OO.att(null, eO, bK)
                  }
                  break
                }
              }
            }
          } else nl(XO) || (qv(XO) ? this._builder.text(XO) : this._writeObject(OO, XO, pO))
        }
      }
      _gatherNamespaces(OO, KO) {
        if (KO.has(OO)) return;
        if (KO.add(OO), Array.isArray(OO)) {
          for (const pO of OO) xv(pO) || this._gatherNamespaces(pO, KO);
          return
        }
        const pO = mv(OO);
        pO && this._assignNamespace(pO);
        const XO = Pl(OO) ?? [],
          bK = new Map;
        for (const lO of XO) {
          const OO = bK.get(lO.prop) ?? [];
          OO.push(lO), bK.set(lO.prop, OO)
        }
        const eO = [];
        for (const lO of Object.keys(OO)) {
          const KO = OO[lO];
          if (null === KO || void 0 === KO) continue;
          const pO = bK.get(lO);
          if (pO) {
            if (pO.some((OO => !0 === OO.ignore || "none" === OO.kind))) continue;
            for (const OO of pO) OO.name && this._assignNamespace(OO.name)
          }
          eO.push(KO)
        }
        for (const lO of eO) xv(lO) || this._gatherNamespaces(lO, KO)
      }
      _assignNamespace(OO, KO) {
        const pO = Hl(OO);
        if (pO?.ns) {
          const OO = pO.ns.toLowerCase();
          this._ns.get(OO) || this._ns.set(OO, KO ?? this._buildNsPrefix(OO))
        } else if ("xmlns" === KO) {
          const OO = pO.name.toLowerCase();
          this._ns.get(OO) || this._ns.set(OO, KO ?? this._buildNsPrefix(OO))
        }
      }
      _buildNsPrefix(OO) {
        let KO, pO = !1;
        do {
          KO = "ns" + this._prefixCount++;
          for (const OO of Array.from(this._ns.values()))
            if (OO === KO) {
              pO = !0;
              break
            }
        } while (pO);
        return KO
      }
    }
    class tv {}
    var kv;
    tv.OpenTag = "<", tv.CloseTag = ">", tv.Slash = "/", tv.Question = "?", tv.Quote = '"', tv.Equal = "=", tv.Space = " ", tv.Semicolon = ":", tv.Dec = "<?xml", tv.Xml = "xml", tv.Xmlns = "xmlns", tv.Xsi = "xsi", tv.VersionKeyword = "version", tv.EncodingKeyword = "encoding", tv.StandaloneKeyword = "standalone",
      function(OO) {
        OO[OO.Declaration = 0] = "Declaration", OO[OO.Tag = 1] = "Tag", OO[OO.Attribute = 2] = "Attribute", OO[OO.Text = 3] = "Text"
      }(kv || (kv = {}));
    class Ul {
      constructor(OO) {
        this._ctxStack = [], this._d = 0, this._w = OO
      }
      dec(OO, KO, pO) {
        return this._w.write(tv.Dec), this._writeAttStr(tv.VersionKeyword, OO), KO && this._writeAttStr(tv.EncodingKeyword, KO), void 0 !== pO && this._writeAttStr(tv.StandaloneKeyword, pO ? "yes" : "no"), this._w.write(tv.Question, tv.CloseTag), this
      }
      att(OO, KO, pO) {
        const XO = this._peekContext();
        if (!XO) throw new Error("att() without open element");
        if (XO.closed) throw new Error(`att() after start tag closed for <${XO.name}>`);
        if (this._isXmlnsDecl(OO, KO)) {
          if (KO === tv.Xmlns) XO.defaultNs = pO, this._registerNamespace(XO, "", pO), this._writeAttStr(tv.Xmlns, pO);
          else if (OO) this._registerNamespace(XO, KO, pO), this._writeAttStr(`${OO}:${KO}`, pO);
          else {
            const OO = KO.slice(6);
            this._registerNamespace(XO, OO, pO), this._writeAttStr(KO, pO)
          }
          return XO.lastToken = kv.Attribute, this
        }
        let bK = KO;
        if (OO) {
          bK = `${this._ensurePrefixDeclared(XO,OO)}:${KO}`
        }
        return XO.lastToken = kv.Attribute, this._writeAttStr(bK, pO), this
      }
      ele(OO, KO) {
        const pO = this._peekContext();
        pO && this._closeOpenTagIfNeeded(pO);
        let XO = KO;
        if (OO) {
          XO = `${this._lookupPrefix(OO)??OO}:${KO}`
        }
        return this._pushContext(XO, ++this._d), this._w.write(tv.OpenTag, XO), this
      }
      text(OO) {
        const KO = this._peekContext();
        if (!KO) throw new Error("text() without open element");
        return this._closeOpenTagIfNeeded(KO), KO.lastToken = kv.Text, this._w.write(this._escText(OO)), this
      }
      end() {
        const OO = this._popContext();
        return OO && (this._d--, OO.closed ? this._w.write(tv.OpenTag, tv.Slash, OO.name, tv.CloseTag) : this._w.write(tv.Slash, tv.CloseTag)), this
      }
      _pushContext(OO, KO) {
        const pO = new Ul.Context(OO, KO);
        return this._ctxStack.push(pO), pO
      }
      _popContext() {
        return this._ctxStack.pop()
      }
      _peekContext() {
        return this._ctxStack[this._ctxStack.length - 1]
      }
      get _contextDepth() {
        return this._ctxStack.length
      }
      _writeAttStr(OO, KO) {
        this._w.write(tv.Space, OO, tv.Equal, tv.Quote, this._escAttr(KO), tv.Quote)
      }
      _lookupPrefix(OO) {
        let KO = this._ctxStack.length - 1;
        if (KO >= 0)
          do {
            const pO = this._ctxStack[KO--],
              XO = pO.ns2prefix?.get(OO);
            if (XO) return XO
          } while (KO >= 0)
      }
      _escText(OO) {
        return OO.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      }
      _escAttr(OO) {
        return this._escText(OO).replace(/"/g, "&quot;").replace(/'/g, "&apos;")
      }
      _isXmlnsDecl(OO, KO) {
        if (OO) return OO === tv.Xmlns;
        const pO = KO.length,
          XO = tv.Xmlns.length;
        return pO >= XO && (KO.startsWith(tv.Xmlns) && (KO.length == XO || KO[XO] == tv.Semicolon))
      }
      _registerNamespace(OO, KO, pO) {
        if (KO === tv.Xml || KO === tv.Xmlns) throw new Error(`reserved prefix '${KO}'`);
        const XO = OO.prefix2ns.get(KO);
        if (XO && XO !== pO) throw new Error(`prefix '${KO}' already bound to a different namespace`);
        OO.ns2prefix.get(pO) || OO.ns2prefix.set(pO, KO), OO.prefix2ns.set(KO, pO)
      }
      _allocPrefix(OO) {
        let KO = 1;
        for (;;) {
          const pO = "ns" + KO++;
          if (!OO.prefix2ns.has(pO)) return pO
        }
      }
      _ensurePrefixDeclared(OO, KO) {
        const pO = this._lookupPrefix(KO);
        if (pO) return pO;
        if (OO.closed) throw new Error(`can not declare namespace after start tag closed for <${OO.name}>`);
        const XO = this._allocPrefix(OO);
        return this._writeAttStr(`${tv.Xmlns}:${XO}`, KO), this._registerNamespace(OO, XO, KO), XO
      }
      _closeOpenTagIfNeeded(OO) {
        OO.closed || (this._w.write(tv.CloseTag), OO.closed = !0)
      }
    }
    Ul.Context = class {
      constructor(OO, KO) {
        this.name = "", this.closed = !1, this.lastToken = null, this.ns2prefix = new Map, this.prefix2ns = new Map, this.defaultNs = null, this.name = OO, this.depth = KO
      }
    };
    class Ov {
      constructor() {
        this.count = 0, this._chunks = []
      }
      write() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        if (0 === KO.length) return this;
        const XO = KO.join("");
        return this._chunks.push(XO), this.count += XO.length, this
      }
      toString() {
        return this._chunks.join("")
      }
      clear() {
        this._chunks = [], this.count = 0
      }
    }
    class Kv {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        this._sink = OO, this._opts = KO, this.count = 0, this._encoder = new TextEncoder, this._pending = "", this._pendingChars = 0
      }
      write() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        if (0 === KO.length) return this;
        const XO = KO.join("");
        if (0 === XO.length) return this;
        this._pending += XO, this._pendingChars += XO.length;
        const bK = this._opts.flushChars ?? 65536;
        return this._pendingChars >= bK && this.flush(), this
      }
      flush() {
        if (0 === this._pendingChars) return this;
        const OO = this._encoder.encode(this._pending);
        return this._sink.push(OO), this.count += OO.length, this._pending = "", this._pendingChars = 0, this
      }
      finish() {
        this.flush(), this._sink.push(new Uint8Array(0), !0)
      }
      clear() {
        this._pending = "", this._pendingChars = 0, this.count = 0
      }
    }
    const pv = "http://schemas.microsoft.com/3dmanufacturing/core/2015/02",
      Xv = "http://schemas.microsoft.com/3dmanufacturing/trianglesets/2021/07";
    var bC, ev;
    ! function(OO) {
      OO.micron = "micron", OO.millimeter = "millimeter", OO.centimeter = "centimeter", OO.inch = "inch", OO.foot = "foot", OO.meter = "meter"
    }(bC || (bC = {})),
    function(OO) {
      OO.model = "model", OO.solidsupport = "solidsupport", OO.support = "support", OO.surface = "surface", OO.other = "other"
    }(ev || (ev = {}));
    const lv = "http://schemas.openxmlformats.org/package/2006/content-types",
      vC = "http://schemas.openxmlformats.org/package/2006/relationships";
    var Cv;
    ! function(OO) {
      OO.Relationships = "application/vnd.openxmlformats-package.relationships+xml", OO.Model = "application/vnd.ms-package.3dmanufacturing-3dmodel+xml", OO.Materials = "application/vnd.ms-package.3dmanufacturing-material+xml", OO.Colors = "application/vnd.ms-package.3dmanufacturing-colors+xml", OO.Texture = "application/vnd.ms-package.3dmanufacturing-texture+xml", OO.Texture2D = "application/vnd.ms-package.3dmanufacturing-texture2d+xml", OO.Production = "application/vnd.ms-package.3dmanufacturing-production+xml", OO.Slice = "application/vnd.ms-package.3dmanufacturing-slice+xml", OO.BeamLattice = "application/vnd.ms-package.3dmanufacturing-beamlattice+xml", OO.SecureContent = "application/vnd.ms-package.3dmanufacturing-securecontent+xml", OO.Png = "image/png", OO.Jpeg = "image/jpeg", OO.Tiff = "image/tiff", OO.Xml = "application/xml"
    }(Cv || (Cv = {}));
    const hv = "_rels/",
      Dv = "3D/",
      Mv = "3dmodel.model",
      aC = ".rels",
      ov = "[Content_Types].xml";
    class Fv {
      static IsKnown(OO) {
        return Fv.Known.has(OO)
      }
      static IsThreeDimModel(OO) {
        return OO === Fv.ThreeDimModel
      }
    }
    Fv.ThreeDimModel = "http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel", Fv.Thumbnail = "http://schemas.openxmlformats.org/package/2006/relationships/metadata/thumbnail", Fv.PrintTicket = "http://schemas.microsoft.com/3dmanufacturing/2013/01/printticket", Fv.MustPreserve = "http://schemas.openxmlformats.org/package/2006/relationships/mustpreserve", Fv.Known = new Set([Fv.ThreeDimModel, Fv.Thumbnail, Fv.PrintTicket, Fv.MustPreserve]);
    let Vv = (() => {
        let OO, KO, pO = [Yl({
            ns: lv,
            name: "Types"
          })],
          XO = [];
        KO = class {
          constructor() {
            this.items = []
          }
        };
        return (0, yK.l)(KO, "ThreeMfContentTypes"), (() => {
          const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          (0, yK.f)(null, OO = {
            value: KO
          }, pO, {
            kind: "class",
            name: KO.name,
            metadata: bK
          }, null, XO), KO = OO.value, bK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: bK
          }), (0, yK.i)(KO, XO)
        })(), KO
      })(),
      Lv = (() => {
        let OO, KO, pO, XO, bK = [Yl({
            ns: lv,
            name: "Default"
          })],
          eO = [],
          lO = [],
          vK = [],
          CO = [],
          hO = [];
        KO = class {
          constructor(OO, KO) {
            this.ext = (0, yK.i)(this, lO, void 0), this.ct = ((0, yK.i)(this, vK), (0, yK.i)(this, CO, void 0)), (0, yK.i)(this, hO), this.ext = OO, this.ct = KO
          }
        };
        return (0, yK.l)(KO, "ThreeMfContentType"), (() => {
          const DO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: {
              ns: lv,
              name: "Extension"
            }
          })], XO = [iv({
            name: {
              ns: lv,
              name: "ContentType"
            }
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "ext",
            static: !1,
            private: !1,
            access: {
              has: OO => "ext" in OO,
              get: OO => OO.ext,
              set: (OO, KO) => {
                OO.ext = KO
              }
            },
            metadata: DO
          }, lO, vK), (0, yK.f)(null, null, XO, {
            kind: "field",
            name: "ct",
            static: !1,
            private: !1,
            access: {
              has: OO => "ct" in OO,
              get: OO => OO.ct,
              set: (OO, KO) => {
                OO.ct = KO
              }
            },
            metadata: DO
          }, CO, hO), (0, yK.f)(null, OO = {
            value: KO
          }, bK, {
            kind: "class",
            name: KO.name,
            metadata: DO
          }, null, eO), KO = OO.value, DO && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: DO
          }), (0, yK.i)(KO, eO)
        })(), KO
      })(),
      Qv = (() => {
        let OO, KO, pO = [Yl({
            ns: vC,
            name: "Relationships"
          })],
          XO = [];
        KO = class {
          constructor() {
            this.items = []
          }
        };
        return (0, yK.l)(KO, "ThreeMfRelationships"), (() => {
          const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          (0, yK.f)(null, OO = {
            value: KO
          }, pO, {
            kind: "class",
            name: KO.name,
            metadata: bK
          }, null, XO), KO = OO.value, bK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: bK
          }), (0, yK.i)(KO, XO)
        })(), KO
      })(),
      zC = (() => {
        let OO, KO, pO, XO, bK, eO = [Yl({
            ns: vC,
            name: "Relationship"
          })],
          lO = [],
          vK = [],
          CO = [],
          hO = [],
          DO = [],
          MO = [],
          aK = [];
        KO = class {
          constructor(OO, KO, pO) {
            this.id = (0, yK.i)(this, vK, void 0), this.type = ((0, yK.i)(this, CO), (0, yK.i)(this, hO, void 0)), this.target = ((0, yK.i)(this, DO), (0, yK.i)(this, MO, void 0)), (0, yK.i)(this, aK), this.id = OO, this.type = KO, this.target = pO
          }
        };
        return (0, yK.l)(KO, "ThreeMfRelationship"), (() => {
          const oO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: "Id"
          })], XO = [iv({
            name: "Type"
          })], bK = [iv({
            name: "Target"
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "id",
            static: !1,
            private: !1,
            access: {
              has: OO => "id" in OO,
              get: OO => OO.id,
              set: (OO, KO) => {
                OO.id = KO
              }
            },
            metadata: oO
          }, vK, CO), (0, yK.f)(null, null, XO, {
            kind: "field",
            name: "type",
            static: !1,
            private: !1,
            access: {
              has: OO => "type" in OO,
              get: OO => OO.type,
              set: (OO, KO) => {
                OO.type = KO
              }
            },
            metadata: oO
          }, hO, DO), (0, yK.f)(null, null, bK, {
            kind: "field",
            name: "target",
            static: !1,
            private: !1,
            access: {
              has: OO => "target" in OO,
              get: OO => OO.target,
              set: (OO, KO) => {
                OO.target = KO
              }
            },
            metadata: oO
          }, MO, aK), (0, yK.f)(null, OO = {
            value: KO
          }, eO, {
            kind: "class",
            name: KO.name,
            metadata: oO
          }, null, lO), KO = OO.value, oO && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: oO
          }), (0, yK.i)(KO, lO)
        })(), KO
      })();
    class Av {
      constructor(OO, KO, pO) {
        this.contentTypes = OO, this.relationships = KO, this.model = pO
      }
    }
    class fv {
      static Zero() {
        return new fv([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
      }
      constructor(OO) {
        this.values = OO
      }
      toString() {
        return this.values.join(" ")
      }
    }
    class dv {
      constructor(OO) {
        this.o = OO, this._f = new Zl(OO)
      }
      toString(OO) {
        return OO.values.map((OO => this._f.toString(OO))).join(" ")
      }
    }
    let Tv = (() => {
        let OO, KO, pO, XO, bK, eO = [Yl({
            ns: pv,
            name: "model"
          })],
          lO = [],
          vK = [],
          CO = [],
          hO = [],
          DO = [],
          MO = [],
          aK = [];
        KO = class {
          constructor() {
            this.unit = (0, yK.i)(this, vK, bC.millimeter), this.requiredextensions = ((0, yK.i)(this, CO), (0, yK.i)(this, hO, void 0)), this.recommendedextensions = ((0, yK.i)(this, DO), (0, yK.i)(this, MO, void 0)), this.metadata = (0, yK.i)(this, aK)
          }
        };
        return (0, yK.l)(KO, "ThreeMfModel"), (() => {
          const oO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: "unit"
          })], XO = [iv({
            name: "requiredextensions"
          })], bK = [iv({
            name: "recommendedextensions"
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "unit",
            static: !1,
            private: !1,
            access: {
              has: OO => "unit" in OO,
              get: OO => OO.unit,
              set: (OO, KO) => {
                OO.unit = KO
              }
            },
            metadata: oO
          }, vK, CO), (0, yK.f)(null, null, XO, {
            kind: "field",
            name: "requiredextensions",
            static: !1,
            private: !1,
            access: {
              has: OO => "requiredextensions" in OO,
              get: OO => OO.requiredextensions,
              set: (OO, KO) => {
                OO.requiredextensions = KO
              }
            },
            metadata: oO
          }, hO, DO), (0, yK.f)(null, null, bK, {
            kind: "field",
            name: "recommendedextensions",
            static: !1,
            private: !1,
            access: {
              has: OO => "recommendedextensions" in OO,
              get: OO => OO.recommendedextensions,
              set: (OO, KO) => {
                OO.recommendedextensions = KO
              }
            },
            metadata: oO
          }, MO, aK), (0, yK.f)(null, OO = {
            value: KO
          }, eO, {
            kind: "class",
            name: KO.name,
            metadata: oO
          }, null, lO), KO = OO.value, oO && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: oO
          })
        })(), KO.KnownMeta = ["Title", "Designer", "Description", "Copyright", "LicenseTerms", "Rating", "CreationDate", "ModificationDate", "Application"], (0, yK.i)(KO, lO), KO
      })(),
      Nv = (() => {
        let OO, KO, pO, XO, bK, eO = [Yl({
            ns: pv,
            name: "meta"
          })],
          lO = [],
          vK = [],
          CO = [],
          hO = [],
          DO = [],
          MO = [],
          aK = [];
        KO = class {
          constructor(OO, KO, pO, XO) {
            this.name = (0, yK.i)(this, vK, void 0), this.preserve = ((0, yK.i)(this, CO), (0, yK.i)(this, hO, void 0)), this.type = ((0, yK.i)(this, DO), (0, yK.i)(this, MO, void 0)), this.value = (0, yK.i)(this, aK), this.name = OO, this.value = KO, this.preserve = pO, this.type = XO
          }
        };
        return (0, yK.l)(KO, "ThreeMfMeta"), (() => {
          const oO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: "name"
          })], XO = [iv({
            name: "preserve"
          })], bK = [iv({
            name: "type"
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "name",
            static: !1,
            private: !1,
            access: {
              has: OO => "name" in OO,
              get: OO => OO.name,
              set: (OO, KO) => {
                OO.name = KO
              }
            },
            metadata: oO
          }, vK, CO), (0, yK.f)(null, null, XO, {
            kind: "field",
            name: "preserve",
            static: !1,
            private: !1,
            access: {
              has: OO => "preserve" in OO,
              get: OO => OO.preserve,
              set: (OO, KO) => {
                OO.preserve = KO
              }
            },
            metadata: oO
          }, hO, DO), (0, yK.f)(null, null, bK, {
            kind: "field",
            name: "type",
            static: !1,
            private: !1,
            access: {
              has: OO => "type" in OO,
              get: OO => OO.type,
              set: (OO, KO) => {
                OO.type = KO
              }
            },
            metadata: oO
          }, MO, aK), (0, yK.f)(null, OO = {
            value: KO
          }, eO, {
            kind: "class",
            name: KO.name,
            metadata: oO
          }, null, lO), KO = OO.value, oO && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: oO
          }), (0, yK.i)(KO, lO)
        })(), KO
      })(),
      Iv = (() => {
        let OO, KO, pO = [Yl({
            ns: pv,
            name: "metadatagroup"
          })],
          XO = [];
        KO = class {
          constructor() {
            this.metadata = []
          }
        };
        return (0, yK.l)(KO, "ThreeMfMetadataGroup"), (() => {
          const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          (0, yK.f)(null, OO = {
            value: KO
          }, pO, {
            kind: "class",
            name: KO.name,
            metadata: bK
          }, null, XO), KO = OO.value, bK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: bK
          }), (0, yK.i)(KO, XO)
        })(), KO
      })(),
      yC = (() => {
        let OO, KO, pO = [Yl({
            ns: pv,
            name: "resources"
          })],
          XO = [];
        KO = class {
          constructor() {
            this.object = []
          }
        };
        return (0, yK.l)(KO, "ThreeMfResources"), (() => {
          const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          (0, yK.f)(null, OO = {
            value: KO
          }, pO, {
            kind: "class",
            name: KO.name,
            metadata: bK
          }, null, XO), KO = OO.value, bK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: bK
          }), (0, yK.i)(KO, XO)
        })(), KO
      })(),
      gC = (() => {
        let OO, KO, pO, XO, bK, eO, lO, vK, CO, hO = [Yl({
            ns: pv,
            name: "object"
          })],
          DO = [],
          MO = [],
          aK = [],
          oO = [],
          FO = [],
          VO = [],
          LO = [],
          QO = [],
          zK = [],
          AO = [],
          fO = [],
          dO = [],
          TO = [],
          NO = [],
          IO = [];
        KO = class {
          constructor(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ev.model;
            this.id = (0, yK.i)(this, MO, void 0), this.type = ((0, yK.i)(this, aK), (0, yK.i)(this, oO, void 0)), this.thumbnail = ((0, yK.i)(this, FO), (0, yK.i)(this, VO, void 0)), this.partnumber = ((0, yK.i)(this, LO), (0, yK.i)(this, QO, void 0)), this.name = ((0, yK.i)(this, zK), (0, yK.i)(this, AO, void 0)), this.pid = ((0, yK.i)(this, fO), (0, yK.i)(this, dO, void 0)), this.pindex = ((0, yK.i)(this, TO), (0, yK.i)(this, NO, void 0)), this.metadatagroup = (0, yK.i)(this, IO), this.id = OO, this.type = KO
          }
        };
        return (0, yK.l)(KO, "ThreeMfObject"), (() => {
          const gK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: "id"
          })], XO = [iv({
            name: "type"
          })], bK = [iv({
            name: "thumbnail"
          })], eO = [iv({
            name: "partnumber"
          })], lO = [iv({
            name: "name"
          })], vK = [iv({
            name: "pid"
          })], CO = [iv({
            name: "pindex"
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "id",
            static: !1,
            private: !1,
            access: {
              has: OO => "id" in OO,
              get: OO => OO.id,
              set: (OO, KO) => {
                OO.id = KO
              }
            },
            metadata: gK
          }, MO, aK), (0, yK.f)(null, null, XO, {
            kind: "field",
            name: "type",
            static: !1,
            private: !1,
            access: {
              has: OO => "type" in OO,
              get: OO => OO.type,
              set: (OO, KO) => {
                OO.type = KO
              }
            },
            metadata: gK
          }, oO, FO), (0, yK.f)(null, null, bK, {
            kind: "field",
            name: "thumbnail",
            static: !1,
            private: !1,
            access: {
              has: OO => "thumbnail" in OO,
              get: OO => OO.thumbnail,
              set: (OO, KO) => {
                OO.thumbnail = KO
              }
            },
            metadata: gK
          }, VO, LO), (0, yK.f)(null, null, eO, {
            kind: "field",
            name: "partnumber",
            static: !1,
            private: !1,
            access: {
              has: OO => "partnumber" in OO,
              get: OO => OO.partnumber,
              set: (OO, KO) => {
                OO.partnumber = KO
              }
            },
            metadata: gK
          }, QO, zK), (0, yK.f)(null, null, lO, {
            kind: "field",
            name: "name",
            static: !1,
            private: !1,
            access: {
              has: OO => "name" in OO,
              get: OO => OO.name,
              set: (OO, KO) => {
                OO.name = KO
              }
            },
            metadata: gK
          }, AO, fO), (0, yK.f)(null, null, vK, {
            kind: "field",
            name: "pid",
            static: !1,
            private: !1,
            access: {
              has: OO => "pid" in OO,
              get: OO => OO.pid,
              set: (OO, KO) => {
                OO.pid = KO
              }
            },
            metadata: gK
          }, dO, TO), (0, yK.f)(null, null, CO, {
            kind: "field",
            name: "pindex",
            static: !1,
            private: !1,
            access: {
              has: OO => "pindex" in OO,
              get: OO => OO.pindex,
              set: (OO, KO) => {
                OO.pindex = KO
              }
            },
            metadata: gK
          }, NO, IO), (0, yK.f)(null, OO = {
            value: KO
          }, hO, {
            kind: "class",
            name: KO.name,
            metadata: gK
          }, null, DO), KO = OO.value, gK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: gK
          }), (0, yK.i)(KO, DO)
        })(), KO
      })(),
      uv = (() => {
        let OO, KO, pO = [Yl({
            ns: pv,
            name: "mesh"
          })],
          XO = [];
        KO = class {
          constructor(OO, KO) {
            this.vertices = OO ?? new Ev, this.triangles = KO ?? new Yv
          }
        };
        return (0, yK.l)(KO, "ThreeMfMesh"), (() => {
          const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          (0, yK.f)(null, OO = {
            value: KO
          }, pO, {
            kind: "class",
            name: KO.name,
            metadata: bK
          }, null, XO), KO = OO.value, bK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: bK
          }), (0, yK.i)(KO, XO)
        })(), KO
      })(),
      Ev = (() => {
        let OO, KO, pO = [Yl({
            ns: pv,
            name: "vertices"
          })],
          XO = [];
        KO = class {
          constructor() {
            this.vertex = []
          }
        };
        return (0, yK.l)(KO, "ThreeMfVertices"), (() => {
          const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          (0, yK.f)(null, OO = {
            value: KO
          }, pO, {
            kind: "class",
            name: KO.name,
            metadata: bK
          }, null, XO), KO = OO.value, bK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: bK
          }), (0, yK.i)(KO, XO)
        })(), KO
      })(),
      jC = (() => {
        let OO, KO, pO, XO, bK, eO = [Yl({
            ns: pv,
            name: "vertex"
          })],
          lO = [],
          vK = [],
          CO = [],
          hO = [],
          DO = [],
          MO = [],
          aK = [];
        KO = class {
          constructor() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
              KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
              pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
            this.x = (0, yK.i)(this, vK, void 0), this.y = ((0, yK.i)(this, CO), (0, yK.i)(this, hO, void 0)), this.z = ((0, yK.i)(this, DO), (0, yK.i)(this, MO, void 0)), (0, yK.i)(this, aK), this.x = OO, this.y = KO, this.z = pO
          }
        };
        return (0, yK.l)(KO, "ThreeMfVertex"), (() => {
          const oO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: "x"
          })], XO = [iv({
            name: "y"
          })], bK = [iv({
            name: "z"
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "x",
            static: !1,
            private: !1,
            access: {
              has: OO => "x" in OO,
              get: OO => OO.x,
              set: (OO, KO) => {
                OO.x = KO
              }
            },
            metadata: oO
          }, vK, CO), (0, yK.f)(null, null, XO, {
            kind: "field",
            name: "y",
            static: !1,
            private: !1,
            access: {
              has: OO => "y" in OO,
              get: OO => OO.y,
              set: (OO, KO) => {
                OO.y = KO
              }
            },
            metadata: oO
          }, hO, DO), (0, yK.f)(null, null, bK, {
            kind: "field",
            name: "z",
            static: !1,
            private: !1,
            access: {
              has: OO => "z" in OO,
              get: OO => OO.z,
              set: (OO, KO) => {
                OO.z = KO
              }
            },
            metadata: oO
          }, MO, aK), (0, yK.f)(null, OO = {
            value: KO
          }, eO, {
            kind: "class",
            name: KO.name,
            metadata: oO
          }, null, lO), KO = OO.value, oO && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: oO
          }), (0, yK.i)(KO, lO)
        })(), KO
      })(),
      Yv = (() => {
        let OO, KO, pO = [Yl({
            ns: pv,
            name: "triangles"
          })],
          XO = [];
        KO = class {
          constructor() {
            this.triangle = []
          }
        };
        return (0, yK.l)(KO, "ThreeMfTriangles"), (() => {
          const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          (0, yK.f)(null, OO = {
            value: KO
          }, pO, {
            kind: "class",
            name: KO.name,
            metadata: bK
          }, null, XO), KO = OO.value, bK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: bK
          }), (0, yK.i)(KO, XO)
        })(), KO
      })(),
      wv = (() => {
        let OO, KO, pO, XO, bK, eO, lO, vK, CO, hO = [Yl({
            ns: pv,
            name: "triangle"
          })],
          DO = [],
          MO = [],
          aK = [],
          oO = [],
          FO = [],
          VO = [],
          LO = [],
          QO = [],
          zK = [],
          AO = [],
          fO = [],
          dO = [],
          TO = [],
          NO = [],
          IO = [];
        KO = class {
          constructor(OO, KO, pO) {
            this.v1 = (0, yK.i)(this, MO, void 0), this.v2 = ((0, yK.i)(this, aK), (0, yK.i)(this, oO, void 0)), this.v3 = ((0, yK.i)(this, FO), (0, yK.i)(this, VO, void 0)), this.p1 = ((0, yK.i)(this, LO), (0, yK.i)(this, QO, void 0)), this.p2 = ((0, yK.i)(this, zK), (0, yK.i)(this, AO, void 0)), this.p3 = ((0, yK.i)(this, fO), (0, yK.i)(this, dO, void 0)), this.pid = ((0, yK.i)(this, TO), (0, yK.i)(this, NO, void 0)), (0, yK.i)(this, IO), this.v1 = OO, this.v2 = KO, this.v3 = pO
          }
        };
        return (0, yK.l)(KO, "ThreeMfTriangle"), (() => {
          const gK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: "v1"
          })], XO = [iv({
            name: "v2"
          })], bK = [iv({
            name: "v3"
          })], eO = [iv({
            name: "p1"
          })], lO = [iv({
            name: "p2"
          })], vK = [iv({
            name: "p3"
          })], CO = [iv({
            name: "pid"
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "v1",
            static: !1,
            private: !1,
            access: {
              has: OO => "v1" in OO,
              get: OO => OO.v1,
              set: (OO, KO) => {
                OO.v1 = KO
              }
            },
            metadata: gK
          }, MO, aK), (0, yK.f)(null, null, XO, {
            kind: "field",
            name: "v2",
            static: !1,
            private: !1,
            access: {
              has: OO => "v2" in OO,
              get: OO => OO.v2,
              set: (OO, KO) => {
                OO.v2 = KO
              }
            },
            metadata: gK
          }, oO, FO), (0, yK.f)(null, null, bK, {
            kind: "field",
            name: "v3",
            static: !1,
            private: !1,
            access: {
              has: OO => "v3" in OO,
              get: OO => OO.v3,
              set: (OO, KO) => {
                OO.v3 = KO
              }
            },
            metadata: gK
          }, VO, LO), (0, yK.f)(null, null, eO, {
            kind: "field",
            name: "p1",
            static: !1,
            private: !1,
            access: {
              has: OO => "p1" in OO,
              get: OO => OO.p1,
              set: (OO, KO) => {
                OO.p1 = KO
              }
            },
            metadata: gK
          }, QO, zK), (0, yK.f)(null, null, lO, {
            kind: "field",
            name: "p2",
            static: !1,
            private: !1,
            access: {
              has: OO => "p2" in OO,
              get: OO => OO.p2,
              set: (OO, KO) => {
                OO.p2 = KO
              }
            },
            metadata: gK
          }, AO, fO), (0, yK.f)(null, null, vK, {
            kind: "field",
            name: "p3",
            static: !1,
            private: !1,
            access: {
              has: OO => "p3" in OO,
              get: OO => OO.p3,
              set: (OO, KO) => {
                OO.p3 = KO
              }
            },
            metadata: gK
          }, dO, TO), (0, yK.f)(null, null, CO, {
            kind: "field",
            name: "pid",
            static: !1,
            private: !1,
            access: {
              has: OO => "pid" in OO,
              get: OO => OO.pid,
              set: (OO, KO) => {
                OO.pid = KO
              }
            },
            metadata: gK
          }, NO, IO), (0, yK.f)(null, OO = {
            value: KO
          }, hO, {
            kind: "class",
            name: KO.name,
            metadata: gK
          }, null, DO), KO = OO.value, gK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: gK
          }), (0, yK.i)(KO, DO)
        })(), KO
      })(),
      iC = (() => {
        let OO, KO, pO = [Yl({
            ns: pv,
            name: "components"
          })],
          XO = [];
        KO = class {
          constructor() {
            this.component = []
          }
        };
        return (0, yK.l)(KO, "ThreeMfComponents"), (() => {
          const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          (0, yK.f)(null, OO = {
            value: KO
          }, pO, {
            kind: "class",
            name: KO.name,
            metadata: bK
          }, null, XO), KO = OO.value, bK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: bK
          }), (0, yK.i)(KO, XO)
        })(), KO
      })(),
      rC = (() => {
        let OO, KO, pO, XO, bK = [Yl({
            ns: pv,
            name: "component"
          })],
          eO = [],
          lO = [],
          vK = [],
          CO = [],
          hO = [];
        KO = class {
          constructor(OO, KO) {
            this.objectid = (0, yK.i)(this, lO, void 0), this.transform = ((0, yK.i)(this, vK), (0, yK.i)(this, CO, void 0)), (0, yK.i)(this, hO), this.objectid = OO, this.transform = KO
          }
        };
        return (0, yK.l)(KO, "ThreeMfComponent"), (() => {
          const DO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: "objectid"
          })], XO = [iv({
            name: "transform",
            formatter: dv
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "objectid",
            static: !1,
            private: !1,
            access: {
              has: OO => "objectid" in OO,
              get: OO => OO.objectid,
              set: (OO, KO) => {
                OO.objectid = KO
              }
            },
            metadata: DO
          }, lO, vK), (0, yK.f)(null, null, XO, {
            kind: "field",
            name: "transform",
            static: !1,
            private: !1,
            access: {
              has: OO => "transform" in OO,
              get: OO => OO.transform,
              set: (OO, KO) => {
                OO.transform = KO
              }
            },
            metadata: DO
          }, CO, hO), (0, yK.f)(null, OO = {
            value: KO
          }, bK, {
            kind: "class",
            name: KO.name,
            metadata: DO
          }, null, eO), KO = OO.value, DO && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: DO
          }), (0, yK.i)(KO, eO)
        })(), KO
      })(),
      Pv = (() => {
        let OO, KO, pO, XO = [Yl({
            ns: pv,
            name: "basematerials"
          })],
          bK = [],
          eO = [],
          lO = [];
        KO = class {
          constructor(OO) {
            this.id = (0, yK.i)(this, eO, void 0), this.base = ((0, yK.i)(this, lO), []), this.id = OO
          }
        };
        return (0, yK.l)(KO, "ThreeMfBaseMaterials"), (() => {
          const vK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: "id"
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "id",
            static: !1,
            private: !1,
            access: {
              has: OO => "id" in OO,
              get: OO => OO.id,
              set: (OO, KO) => {
                OO.id = KO
              }
            },
            metadata: vK
          }, eO, lO), (0, yK.f)(null, OO = {
            value: KO
          }, XO, {
            kind: "class",
            name: KO.name,
            metadata: vK
          }, null, bK), KO = OO.value, vK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: vK
          }), (0, yK.i)(KO, bK)
        })(), KO
      })(),
      mC = (() => {
        let OO, KO, pO, XO, bK = [Yl({
            ns: pv,
            name: "base"
          })],
          eO = [],
          lO = [],
          vK = [],
          CO = [],
          hO = [];
        KO = class {
          constructor(OO, KO) {
            this.name = (0, yK.i)(this, lO, void 0), this.displaycolor = ((0, yK.i)(this, vK), (0, yK.i)(this, CO, void 0)), (0, yK.i)(this, hO), this.name = OO, this.displaycolor = KO
          }
        };
        return (0, yK.l)(KO, "ThreeMfBase"), (() => {
          const DO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: "name"
          })], XO = [iv({
            name: "displaycolor"
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "name",
            static: !1,
            private: !1,
            access: {
              has: OO => "name" in OO,
              get: OO => OO.name,
              set: (OO, KO) => {
                OO.name = KO
              }
            },
            metadata: DO
          }, lO, vK), (0, yK.f)(null, null, XO, {
            kind: "field",
            name: "displaycolor",
            static: !1,
            private: !1,
            access: {
              has: OO => "displaycolor" in OO,
              get: OO => OO.displaycolor,
              set: (OO, KO) => {
                OO.displaycolor = KO
              }
            },
            metadata: DO
          }, CO, hO), (0, yK.f)(null, OO = {
            value: KO
          }, bK, {
            kind: "class",
            name: KO.name,
            metadata: DO
          }, null, eO), KO = OO.value, DO && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: DO
          }), (0, yK.i)(KO, eO)
        })(), KO
      })(),
      sv = (() => {
        let OO, KO, pO = [Yl({
            ns: pv,
            name: "build"
          })],
          XO = [];
        KO = class {
          constructor() {
            this.item = []
          }
        };
        return (0, yK.l)(KO, "ThreeMfBuild"), (() => {
          const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          (0, yK.f)(null, OO = {
            value: KO
          }, pO, {
            kind: "class",
            name: KO.name,
            metadata: bK
          }, null, XO), KO = OO.value, bK && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: bK
          }), (0, yK.i)(KO, XO)
        })(), KO
      })(),
      Hv = (() => {
        let OO, KO, pO, XO, bK, eO = [Yl({
            ns: pv,
            name: "item"
          })],
          lO = [],
          vK = [],
          CO = [],
          hO = [],
          DO = [],
          MO = [],
          aK = [];
        KO = class {
          constructor(OO, KO, pO) {
            this.objectid = (0, yK.i)(this, vK, void 0), this.transform = ((0, yK.i)(this, CO), (0, yK.i)(this, hO, void 0)), this.partnumber = ((0, yK.i)(this, DO), (0, yK.i)(this, MO, void 0)), this.metadatagroup = (0, yK.i)(this, aK), this.objectid = OO, this.transform = KO, this.partnumber = pO
          }
        };
        return (0, yK.l)(KO, "ThreeMfItem"), (() => {
          const oO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          pO = [iv({
            name: "objectid"
          })], XO = [iv({
            name: "transform",
            formatter: dv
          })], bK = [iv({
            name: "partnumber"
          })], (0, yK.f)(null, null, pO, {
            kind: "field",
            name: "objectid",
            static: !1,
            private: !1,
            access: {
              has: OO => "objectid" in OO,
              get: OO => OO.objectid,
              set: (OO, KO) => {
                OO.objectid = KO
              }
            },
            metadata: oO
          }, vK, CO), (0, yK.f)(null, null, XO, {
            kind: "field",
            name: "transform",
            static: !1,
            private: !1,
            access: {
              has: OO => "transform" in OO,
              get: OO => OO.transform,
              set: (OO, KO) => {
                OO.transform = KO
              }
            },
            metadata: oO
          }, hO, DO), (0, yK.f)(null, null, bK, {
            kind: "field",
            name: "partnumber",
            static: !1,
            private: !1,
            access: {
              has: OO => "partnumber" in OO,
              get: OO => OO.partnumber,
              set: (OO, KO) => {
                OO.partnumber = KO
              }
            },
            metadata: oO
          }, MO, aK), (0, yK.f)(null, OO = {
            value: KO
          }, eO, {
            kind: "class",
            name: KO.name,
            metadata: oO
          }, null, lO), KO = OO.value, oO && Object.defineProperty(KO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: oO
          }), (0, yK.i)(KO, lO)
        })(), KO
      })();
    class Rv {
      constructor(OO, KO) {
        this._object = new gC(OO, KO)
      }
      withName(OO) {
        return this._object.name = OO, this
      }
      withThumbnail(OO) {
        return this._object.thumbnail = OO, this
      }
      withProperty(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return this._object.pid = OO, this._object.id = KO, this
      }
      build() {
        return this._object
      }
      reset(OO, KO) {
        this._object = new gC(OO, KO)
      }
    }
    class Sv extends Rv {
      constructor(OO) {
        super(OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ev.model), this._object.content = new iC
      }
      withComponent(OO, KO) {
        return this._object.content.component.push(new rC(OO, KO)), this
      }
    }
    class Jv extends Rv {
      constructor(OO) {
        super(OO, ev.model)
      }
      withPostProcessHandlers(OO, KO) {
        return this._vh = OO, this._th = KO, this
      }
      withData(OO) {
        return this._object.content = this._buildMesh(OO), this
      }
      withMaterial(OO, KO) {
        return this._object.pid = OO, this._object.pindex = KO, this
      }
      _buildMesh(OO) {
        const KO = this._buildVertices(OO.positions),
          pO = this._buildTriangle(OO.indices);
        return new uv(KO, pO)
      }
      _buildVertices(OO) {
        const KO = new Ev;
        if (OO)
          for (let pO = 0; pO < OO.length;) {
            const XO = OO[pO++],
              bK = OO[pO++],
              eO = OO[pO++];
            let lO = new jC(XO, bK, eO);
            this._vh && (lO = this._vh(lO)), KO.vertex.push(lO)
          }
        return KO
      }
      _buildTriangle(OO) {
        const KO = new Yv;
        if (OO)
          for (let pO = 0; pO < OO.length;) {
            const XO = OO[pO++],
              bK = OO[pO++],
              eO = OO[pO++];
            let lO = new wv(XO, bK, eO);
            this._th && (lO = this._th(lO)), KO.triangle.push(lO)
          }
        return KO
      }
    }
    class cC {
      constructor(OO) {
        this._m = new Pv(OO)
      }
      withColor(OO, KO) {
        this._m.base = this._m.base ?? [];
        let pO = this._m.base.find((KO => KO.name.toLowerCase() === OO.toLowerCase()));
        return pO ? (pO.displaycolor = this._rgbaToHex(KO), this) : (pO = new mC(OO, this._rgbaToHex(KO)), this._m.base.push(pO), this)
      }
      build() {
        return this._m
      }
      _rgbaToHex(OO) {
        const KO = OO => Math.round(Math.min(255, Math.max(0, 255 * Math.pow(OO, 1 / 2.2)))),
          pO = KO(OO.r).toString(16).padStart(2, "0").toUpperCase(),
          XO = KO(OO.g).toString(16).padStart(2, "0").toUpperCase(),
          bK = KO(OO.b).toString(16).padStart(2, "0").toUpperCase();
        if ("number" === typeof OO.a) {
          return `#${pO}${XO}${bK}${Math.round(Math.min(255,Math.max(0,255*OO.a))).toString(16).padStart(2,"0").toUpperCase()}`
        }
        return `#${pO}${XO}${bK}`
      }
    }
    class Bv {
      constructor() {
        this._model = new Tv, this._objects = new Map
      }
      withMetaData(OO, KO, pO, XO) {
        return this._model.metadata || (this._model.metadata = new Array), this._model.metadata.push(new Nv(OO, KO, pO, XO)), this
      }
      withMaterial(OO) {
        return OO instanceof cC && (OO = OO.build()), OO && (this._model.resources = this._model.resources ?? new yC, this._model.resources.basematerials = this._model.resources.basematerials ?? [], this._model.resources.basematerials.push(OO)), this
      }
      withMesh(OO) {
        return OO instanceof Jv && (OO = OO.build()), this._model.resources = this._model.resources ?? new yC, this._model.resources.object.push(OO), this
      }
      withComponents(OO) {
        return OO instanceof Sv && (OO = OO.build()), this._model.resources = this._model.resources ?? new yC, this._model.resources.object.push(OO), this
      }
      withBuild(OO, KO, pO) {
        return this._model.build = this._model.build ?? new sv, this._model.build.item?.push(new Hv(OO, KO, pO)), this
      }
      withUnit(OO) {
        return this._model.unit = OO, this
      }
      reset() {
        return this._model = new Tv, this._objects = new Map, this
      }
      build() {
        if (!this._model.resources?.object?.length) throw new Error("Invalid state: resources MUST be defined ");
        if (!this._model.build?.item?.length) throw new Error("Invalid state: Build MUST be defined ");
        return this._model
      }
    }
    Bv.KnownMetaSet = new Set(Tv.KnownMeta.map((OO => OO.toLowerCase())));
    class Zv {
      withContentType(OO) {
        this._cts || (this._cts = new Vv);
        const KO = this._cts.items;
        return KO.some((KO => KO.ext === OO.ext && KO.ct === OO.ct)) || KO.push(OO), this
      }
      withRelationship(OO) {
        this._rs || (this._rs = new Qv);
        const KO = this._rs.items;
        return KO.some((KO => KO.id === OO.id)) || KO.push(OO), this.withContentType(new Lv("rels", Cv.Relationships)), this
      }
      withModel(OO) {
        return OO instanceof Bv && (OO = OO.build()), this._m = OO, this.withContentType(new Lv("model", Cv.Model)), this
      }
      build() {
        if (!this._m) throw new Error("Invalid state: you Must provide at least a model.");
        const OO = `${Dv}${Mv}`;
        if (!this._rs) {
          const KO = `/${OO}`;
          this.withRelationship(new zC("rel0", Fv.ThreeDimModel, KO))
        }
        return new Av(this._cts, this._rs, this._m)
      }
    }
    class Gv {
      constructor(OO) {
        this._o = OO
      }
      get options() {
        return this._o
      }
      async serializeAsync(OO) {
        const KO = await this.ensureZipLibReadyAsync();
        if (!KO) return;
        const pO = KO.Zip,
          XO = KO.ZipDeflate;
        if (!pO || !XO) throw new Error("fflate Zip / ZipDeflate not available");
        const bK = function(OO, KO, pO) {
          const bK = new XO(KO, {
            level: 6
          });
          OO.add(bK);
          const eO = function(OO) {
              return {
                push: (KO, pO) => OO.push(KO, pO)
              }
            }(bK),
            lO = new Kv(eO),
            vK = new Ul(lO).dec("1.0", "UTF-8");
          new Wl(vK).serialize(pO), lO.finish()
        };
        for (var eO = arguments.length, lO = new Array(eO > 1 ? eO - 1 : 0), vK = 1; vK < eO; vK++) lO[vK - 1] = arguments[vK];
        const CO = this.toDocument(...lO);
        if (!CO) return;
        const hO = new pO(OO);
        bK(hO, ov, CO.contentTypes), bK(hO, `${hv}${aC}`, CO.relationships), bK(hO, `${Dv}${Mv}`, CO.model), hO.end()
      }
      toDocument() {
        const OO = (new Bv).withUnit(this._o?.unit ?? bC.millimeter);
        if (this.options.metadata)
          for (const bK in this.options.metadata) OO.withMetaData(bK, this.options.metadata[bK]);
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        return (new Zv).withModel(this.toModel(OO, ...pO)).build()
      }
    }
    class qC {
      static async SerializeToMemoryAsync(OO) {
        const KO = new Array;
        let pO = 0;
        for (var XO = arguments.length, bK = new Array(XO > 1 ? XO - 1 : 0), eO = 1; eO < XO; eO++) bK[eO - 1] = arguments[eO];
        if (await OO.serializeAsync((function(OO, XO, bK) {
            KO.push(XO), pO += XO.length
          }), ...bK), !pO) return;
        const lO = new Uint8Array(pO);
        let vK = 0;
        for (const CO of KO) lO.set(CO, vK), vK += CO.length;
        return lO
      }
    }
    class xC {}
    xC.FFLATEUrl = "https://unpkg.com/fflate@0.8.2";
    class nv {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Number.MIN_SAFE_INTEGER,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
        this._from = OO, this._to = KO, this._step = pO, this._i = OO
      }
      next() {
        if (this._i < this._to) throw new Error("ST_ResourceID out of bound");
        const OO = this._i;
        return this._i += this._step, OO
      }
      reset() {
        return this._i = this._from, this
      }
    }
    class Wv extends Gv {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        super({
          ...Wv.DefaultOptions,
          ...OO
        })
      }
      toModel(OO) {
        for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
        pO = pO.filter((OO => OO instanceof hX.c || OO instanceof oO.b));
        const bK = new nv,
          eO = OO,
          lO = new Map,
          vK = this.options.exportInstances ? [] : null;
        for (let CO = 0; CO < pO.length; CO++) {
          const OO = pO[CO];
          if (OO instanceof oO.b) {
            vK?.push(OO);
            continue
          }
          const KO = OO.name || `mesh${CO}`,
            XO = OO.getWorldMatrix(),
            hO = this._handleBabylonTo3mfMatrixTransformToRef(XO, fv.Zero()),
            DO = OO.au;
          if (void 0 === DO) continue;
          const MO = 1 == DO.length;
          for (let pO = 0; pO < DO.length; pO++) {
            const XO = DO[pO],
              vK = this._extractSubMesh(OO, XO);
            if (vK) {
              const OO = MO ? `${KO}` : `${KO}_${pO}`,
                CO = new Jv(bK.next()).withData(vK).withName(OO).build();
              eO.withMesh(CO), eO.withBuild(CO.id, hO), lO.set(XO, CO)
            }
          }
        }
        if (vK && vK.length) {
          const OO = this._groupBy(vK, (OO => OO.SDO));
          for (const [KO, pO] of Array.from(OO.entries()))
            if (pO && pO.length)
              for (let OO = 0; OO < pO.length; OO++) {
                const XO = pO[OO].getWorldMatrix(),
                  bK = KO.au;
                for (let OO = 0; OO < bK.length; OO++) {
                  const KO = bK[OO],
                    pO = lO.get(KO);
                  pO && eO.withBuild(pO.id, this._handleBabylonTo3mfMatrixTransformToRef(XO, fv.Zero()))
                }
              }
        }
        return eO.build()
      }
      async ensureZipLibReadyAsync() {
        return this._fflateReadyPromise || (this._fflateReadyPromise = (async () => {
          const OO = globalThis;
          return OO.fflate || await bK.Tools.LoadScriptAsync(xC.FFLATEUrl), OO.fflate
        })()), await this._fflateReadyPromise
      }
      _extractSubMesh(OO, KO) {
        const pO = OO.rFO();
        if (!pO) return;
        const XO = OO.getVerticesData(Wv._PositionKind);
        if (!XO) return;
        if (0 == KO.indexStart && KO.indexCount == pO.length) return {
          positions: XO,
          indices: pO
        };
        const bK = KO.indexStart,
          eO = new Map,
          lO = [],
          vK = new Uint32Array(KO.indexCount);
        for (let CO = 0; CO < KO.indexCount; CO++) {
          const OO = pO[bK + CO];
          let KO = eO.get(OO);
          if (void 0 === KO) {
            KO = eO.size, eO.set(OO, KO);
            const pO = 3 * OO;
            lO.push(XO[pO], XO[pO + 1], XO[pO + 2])
          }
          vK[CO] = KO
        }
        return {
          positions: new Float32Array(lO),
          indices: vK
        }
      }
      _groupBy(OO, KO) {
        const pO = new Map;
        for (const XO of OO) {
          const OO = KO(XO),
            bK = pO.get(OO);
          bK ? bK.push(XO) : pO.set(OO, [XO])
        }
        return pO
      }
      _handleBabylonTo3mfMatrixTransformToRef(OO, KO) {
        const pO = OO.multiplyToRef(Wv._R_BJS_TO_3MF, HO.c.Zero()).m;
        return KO.values = [pO[0], pO[1], pO[2], pO[4], pO[5], pO[6], pO[8], pO[9], pO[10], pO[12], pO[13], pO[14]], KO
      }
    }
    Wv.DefaultOptions = {
      unit: bC.meter,
      exportInstances: !1
    }, Wv._PositionKind = "position", Wv._R_BJS_TO_3MF = HO.c.RotationX(Math.PI / 2).multiply(HO.c.Scaling(1, -1, 1))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);