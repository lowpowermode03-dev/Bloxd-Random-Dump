/*! For license information please see vjxd5n.102.bfbfba84.chunk.js.LICENSE.txt */
export const id = 102;
export const ids = [102];
export const modules = {
  5583: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      Graph: () => SO,
      debug: () => jX,
      default: () => wp,
      graphlib: () => eO,
      layout: () => op,
      util: () => Yp,
      version: () => eK
    });
    var XO = Object.defineProperty,
      bK = (OO, KO, pO) => ((OO, KO, pO) => KO in OO ? XO(OO, KO, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: pO
      }) : OO[KO] = pO)(OO, "symbol" != typeof KO ? KO + "" : KO, pO),
      eO = {};
    ((OO, KO) => {
      for (var pO in KO) XO(OO, pO, {
        get: KO[pO],
        enumerable: !0
      })
    })(eO, {
      Graph: () => SO,
      alg: () => QO
    });
    var lO = Object.defineProperty,
      vK = (OO, KO) => {
        for (var pO in KO) lO(OO, pO, {
          get: KO[pO],
          enumerable: !0
        })
      },
      CO = class {
        constructor(OO) {
          this._isDirected = !0, this._isMultigraph = !1, this._isCompound = !1, this._nodes = {}, this._in = {}, this._preds = {}, this._out = {}, this._sucs = {}, this._edgeObjs = {}, this._edgeLabels = {}, this._nodeCount = 0, this._edgeCount = 0, this._defaultNodeLabelFn = () => {}, this._defaultEdgeLabelFn = () => {}, OO && (this._isDirected = !("directed" in OO) || OO.directed, this._isMultigraph = "multigraph" in OO && OO.multigraph, this._isCompound = "compound" in OO && OO.compound), this._isCompound && (this._parent = {}, this._children = {}, this._children["\0"] = {})
        }
        isDirected() {
          return this._isDirected
        }
        isMultigraph() {
          return this._isMultigraph
        }
        isCompound() {
          return this._isCompound
        }
        setGraph(OO) {
          return this._label = OO, this
        }
        graph() {
          return this._label
        }
        setDefaultNodeLabel(OO) {
          return this._defaultNodeLabelFn = "function" != typeof OO ? () => OO : OO, this
        }
        nodeCount() {
          return this._nodeCount
        }
        nodes() {
          return Object.keys(this._nodes)
        }
        sources() {
          return this.nodes().filter((OO => 0 === Object.keys(this._in[OO]).length))
        }
        sinks() {
          return this.nodes().filter((OO => 0 === Object.keys(this._out[OO]).length))
        }
        setNodes(OO, KO) {
          return OO.forEach((OO => {
            void 0 !== KO ? this.setNode(OO, KO) : this.setNode(OO)
          })), this
        }
        setNode(OO, KO) {
          return OO in this._nodes ? (arguments.length > 1 && (this._nodes[OO] = KO), this) : (this._nodes[OO] = arguments.length > 1 ? KO : this._defaultNodeLabelFn(OO), this._isCompound && (this._parent[OO] = "\0", this._children[OO] = {}, this._children["\0"][OO] = !0), this._in[OO] = {}, this._preds[OO] = {}, this._out[OO] = {}, this._sucs[OO] = {}, ++this._nodeCount, this)
        }
        node(OO) {
          return this._nodes[OO]
        }
        hasNode(OO) {
          return OO in this._nodes
        }
        removeNode(OO) {
          if (OO in this._nodes) {
            let KO = OO => this.removeEdge(this._edgeObjs[OO]);
            delete this._nodes[OO], this._isCompound && (this._removeFromParentsChildList(OO), delete this._parent[OO], this.children(OO).forEach((OO => {
              this.setParent(OO)
            })), delete this._children[OO]), Object.keys(this._in[OO]).forEach(KO), delete this._in[OO], delete this._preds[OO], Object.keys(this._out[OO]).forEach(KO), delete this._out[OO], delete this._sucs[OO], --this._nodeCount
          }
          return this
        }
        setParent(OO, KO) {
          if (!this._isCompound) throw new Error("Cannot set parent in a non-compound graph");
          if (void 0 === KO) KO = "\0";
          else {
            for (let pO = KO += ""; void 0 !== pO; pO = this.parent(pO))
              if (pO === OO) throw new Error("Setting " + KO + " as parent of " + OO + " would create a cycle");
            this.setNode(KO)
          }
          return this.setNode(OO), this._removeFromParentsChildList(OO), this._parent[OO] = KO, this._children[KO][OO] = !0, this
        }
        parent(OO) {
          if (this._isCompound) {
            let KO = this._parent[OO];
            if ("\0" !== KO) return KO
          }
        }
        children() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "\0";
          if (this._isCompound) {
            let KO = this._children[OO];
            if (KO) return Object.keys(KO)
          } else {
            if ("\0" === OO) return this.nodes();
            if (this.hasNode(OO)) return []
          }
          return []
        }
        predecessors(OO) {
          let KO = this._preds[OO];
          if (KO) return Object.keys(KO)
        }
        successors(OO) {
          let KO = this._sucs[OO];
          if (KO) return Object.keys(KO)
        }
        neighbors(OO) {
          let KO = this.predecessors(OO);
          if (KO) {
            let pO = new Set(KO),
              XO = this.successors(OO);
            if (XO)
              for (let OO of XO) pO.add(OO);
            return Array.from(pO.values())
          }
        }
        isLeaf(OO) {
          var KO;
          let pO;
          return pO = this.isDirected() ? this.successors(OO) : this.neighbors(OO), 0 === (null != (KO = null == pO ? void 0 : pO.length) ? KO : 0)
        }
        filterNodes(OO) {
          let KO = new this.constructor({
            directed: this._isDirected,
            multigraph: this._isMultigraph,
            compound: this._isCompound
          });
          KO.setGraph(this.graph()), Object.entries(this._nodes).forEach((pO => {
            let [XO, bK] = pO;
            OO(XO) && KO.setNode(XO, bK)
          })), Object.values(this._edgeObjs).forEach((OO => {
            KO.hasNode(OO.v) && KO.hasNode(OO.w) && KO.setEdge(OO, this.edge(OO))
          }));
          let pO = {},
            XO = OO => {
              let bK = this.parent(OO);
              return !bK || KO.hasNode(bK) ? (pO[OO] = bK, bK) : bK in pO ? pO[bK] : XO(bK)
            };
          return this._isCompound && KO.nodes().forEach((OO => KO.setParent(OO, XO(OO)))), KO
        }
        setDefaultEdgeLabel(OO) {
          return this._defaultEdgeLabelFn = "function" != typeof OO ? () => OO : OO, this
        }
        edgeCount() {
          return this._edgeCount
        }
        edges() {
          return Object.values(this._edgeObjs)
        }
        setPath(OO, KO) {
          return OO.reduce(((OO, pO) => (void 0 !== KO ? this.setEdge(OO, pO, KO) : this.setEdge(OO, pO), pO))), this
        }
        setEdge(OO, KO, pO, XO) {
          let bK, eO, lO, vK, CO = !1;
          "object" == typeof OO && null !== OO && "v" in OO ? (bK = OO.v, eO = OO.w, lO = OO.name, 2 === arguments.length && (vK = KO, CO = !0)) : (bK = OO, eO = KO, lO = XO, arguments.length > 2 && (vK = pO, CO = !0)), bK = "" + bK, eO = "" + eO, void 0 !== lO && (lO = "" + lO);
          let DO = MO(this._isDirected, bK, eO, lO);
          if (DO in this._edgeLabels) return CO && (this._edgeLabels[DO] = vK), this;
          if (void 0 !== lO && !this._isMultigraph) throw new Error("Cannot set a named edge when isMultigraph = false");
          this.setNode(bK), this.setNode(eO), this._edgeLabels[DO] = CO ? vK : this._defaultEdgeLabelFn(bK, eO, lO);
          let aK = function(OO, KO, pO, XO) {
            let bK = "" + KO,
              eO = "" + pO;
            if (!OO && bK > eO) {
              let OO = bK;
              bK = eO, eO = OO
            }
            let lO = {
              v: bK,
              w: eO
            };
            return XO && (lO.name = XO), lO
          }(this._isDirected, bK, eO, lO);
          return bK = aK.v, eO = aK.w, Object.freeze(aK), this._edgeObjs[DO] = aK, hO(this._preds[eO], bK), hO(this._sucs[bK], eO), this._in[eO][DO] = aK, this._out[bK][DO] = aK, this._edgeCount++, this
        }
        edge(OO, KO, pO) {
          let XO = 1 === arguments.length ? aK(this._isDirected, OO) : MO(this._isDirected, OO, KO, pO);
          return this._edgeLabels[XO]
        }
        edgeAsObj(OO, KO, pO) {
          let XO = 1 === arguments.length ? this.edge(OO) : this.edge(OO, KO, pO);
          return "object" != typeof XO || null === XO ? {
            label: XO
          } : XO
        }
        hasEdge(OO, KO, pO) {
          return (1 === arguments.length ? aK(this._isDirected, OO) : MO(this._isDirected, OO, KO, pO)) in this._edgeLabels
        }
        removeEdge(OO, KO, pO) {
          let XO = 1 === arguments.length ? aK(this._isDirected, OO) : MO(this._isDirected, OO, KO, pO),
            bK = this._edgeObjs[XO];
          if (bK) {
            let OO = bK.v,
              KO = bK.w;
            delete this._edgeLabels[XO], delete this._edgeObjs[XO], DO(this._preds[KO], OO), DO(this._sucs[OO], KO), delete this._in[KO][XO], delete this._out[OO][XO], this._edgeCount--
          }
          return this
        }
        inEdges(OO, KO) {
          return this.isDirected() ? this.filterEdges(this._in[OO], OO, KO) : this.nodeEdges(OO, KO)
        }
        outEdges(OO, KO) {
          return this.isDirected() ? this.filterEdges(this._out[OO], OO, KO) : this.nodeEdges(OO, KO)
        }
        nodeEdges(OO, KO) {
          if (OO in this._nodes) return this.filterEdges({
            ...this._in[OO],
            ...this._out[OO]
          }, OO, KO)
        }
        _removeFromParentsChildList(OO) {
          delete this._children[this._parent[OO]][OO]
        }
        filterEdges(OO, KO, pO) {
          if (!OO) return;
          let XO = Object.values(OO);
          return pO ? XO.filter((OO => OO.v === KO && OO.w === pO || OO.v === pO && OO.w === KO)) : XO
        }
      };

    function hO(OO, KO) {
      OO[KO] ? OO[KO]++ : OO[KO] = 1
    }

    function DO(OO, KO) {
      void 0 !== OO[KO] && !--OO[KO] && delete OO[KO]
    }

    function MO(OO, KO, pO, XO) {
      let bK = "" + KO,
        eO = "" + pO;
      if (!OO && bK > eO) {
        let OO = bK;
        bK = eO, eO = OO
      }
      return bK + "\x01" + eO + "\x01" + (void 0 === XO ? "\0" : XO)
    }

    function aK(OO, KO) {
      return MO(OO, KO.v, KO.w, KO.name)
    }

    function oO(OO) {
      let KO = {
          options: {
            directed: OO.isDirected(),
            multigraph: OO.isMultigraph(),
            compound: OO.isCompound()
          },
          nodes: FO(OO),
          edges: VO(OO)
        },
        pO = OO.graph();
      return void 0 !== pO && (KO.value = structuredClone(pO)), KO
    }

    function FO(OO) {
      return OO.nodes().map((KO => {
        let pO = OO.node(KO),
          XO = OO.parent(KO),
          bK = {
            v: KO
          };
        return void 0 !== pO && (bK.value = pO), void 0 !== XO && (bK.parent = XO), bK
      }))
    }

    function VO(OO) {
      return OO.edges().map((KO => {
        let pO = OO.edge(KO),
          XO = {
            v: KO.v,
            w: KO.w
          };
        return void 0 !== KO.name && (XO.name = KO.name), void 0 !== pO && (XO.value = pO), XO
      }))
    }

    function LO(OO) {
      let KO = new CO(OO.options);
      return void 0 !== OO.value && KO.setGraph(OO.value), OO.nodes.forEach((OO => {
        KO.setNode(OO.v, OO.value), OO.parent && KO.setParent(OO.v, OO.parent)
      })), OO.edges.forEach((OO => {
        KO.setEdge({
          v: OO.v,
          w: OO.w,
          name: OO.name
        }, OO.value)
      })), KO
    }
    vK({}, {
      read: () => LO,
      write: () => oO
    });
    var QO = {};
    vK(QO, {
      CycleException: () => jK,
      bellmanFord: () => AO,
      components: () => fO,
      dijkstra: () => NO,
      dijkstraAll: () => IO,
      findCycles: () => gK,
      floydWarshall: () => EO,
      isAcyclic: () => wO,
      postorder: () => mK,
      preorder: () => sO,
      prim: () => HO,
      shortestPaths: () => RO,
      tarjan: () => yK,
      topsort: () => YO
    });
    var zK = () => 1;

    function AO(OO, KO, pO, XO) {
      return function(OO, KO, pO, XO) {
        let bK, eO = {},
          lO = 0,
          vK = OO.nodes(),
          CO = function(OO) {
            let KO = eO[OO.v],
              XO = eO[OO.w];
            if (!KO || !XO) return;
            let lO = pO(OO);
            KO.distance + lO < XO.distance && (eO[OO.w] = {
              distance: KO.distance + lO,
              predecessor: OO.v
            }, bK = !0)
          },
          hO = function() {
            vK.forEach((function(OO) {
              XO(OO).forEach((function(KO) {
                let pO = KO.v === OO ? KO.v : KO.w,
                  XO = pO === KO.v ? KO.w : KO.v;
                CO({
                  v: pO,
                  w: XO
                })
              }))
            }))
          };
        vK.forEach((function(OO) {
          let pO = OO === KO ? 0 : Number.POSITIVE_INFINITY;
          eO[OO] = {
            distance: pO,
            predecessor: ""
          }
        }));
        let DO = vK.length;
        for (let MO = 1; MO < DO && (bK = !1, lO++, hO(), bK); MO++);
        if (lO === DO - 1 && (bK = !1, hO(), bK)) throw new Error("The graph contains a negative weight cycle");
        return eO
      }(OO, String(KO), pO || zK, XO || function(KO) {
        var pO;
        return null != (pO = OO.outEdges(KO)) ? pO : []
      })
    }

    function fO(OO) {
      let KO, pO = {},
        XO = [];

      function bK(XO) {
        var eO, lO;
        XO in pO || (pO[XO] = !0, KO.push(XO), null == (eO = OO.successors(XO)) || eO.forEach(bK), null == (lO = OO.predecessors(XO)) || lO.forEach(bK))
      }
      return OO.nodes().forEach((function(OO) {
        KO = [], bK(OO), KO.length && XO.push(KO)
      })), XO
    }
    var dO = class {
        constructor() {
          this._arr = [], this._keyIndices = {}
        }
        size() {
          return this._arr.length
        }
        keys() {
          return this._arr.map((OO => OO.key))
        }
        has(OO) {
          return OO in this._keyIndices
        }
        priority(OO) {
          let KO = this._keyIndices[OO];
          if (void 0 !== KO) return this._arr[KO].priority
        }
        min() {
          if (0 === this.size()) throw new Error("Queue underflow");
          return this._arr[0].key
        }
        add(OO, KO) {
          let pO = this._keyIndices,
            XO = String(OO);
          if (!(XO in pO)) {
            let OO = this._arr,
              bK = OO.length;
            return pO[XO] = bK, OO.push({
              key: XO,
              priority: KO
            }), this._decrease(bK), !0
          }
          return !1
        }
        removeMin() {
          if (0 === this.size()) throw new Error("Queue underflow");
          this._swap(0, this._arr.length - 1);
          let OO = this._arr.pop();
          return delete this._keyIndices[OO.key], this._heapify(0), OO.key
        }
        decrease(OO, KO) {
          let pO = this._keyIndices[OO];
          if (void 0 === pO) throw new Error(`Key not found: ${OO}`);
          let XO = this._arr[pO].priority;
          if (KO > XO) throw new Error(`New priority is greater than current priority. Key: ${OO} Old: ${XO} New: ${KO}`);
          this._arr[pO].priority = KO, this._decrease(pO)
        }
        _heapify(OO) {
          let KO = this._arr,
            pO = 2 * OO,
            XO = pO + 1,
            bK = OO;
          pO < KO.length && (bK = KO[pO].priority < KO[bK].priority ? pO : bK, XO < KO.length && (bK = KO[XO].priority < KO[bK].priority ? XO : bK), bK !== OO && (this._swap(OO, bK), this._heapify(bK)))
        }
        _decrease(OO) {
          let KO, pO = this._arr,
            XO = pO[OO].priority;
          for (; 0 !== OO && (KO = OO >> 1, !(pO[KO].priority < XO));) this._swap(OO, KO), OO = KO
        }
        _swap(OO, KO) {
          let pO = this._arr,
            XO = this._keyIndices,
            bK = pO[OO],
            eO = pO[KO];
          pO[OO] = eO, pO[KO] = bK, XO[eO.key] = OO, XO[bK.key] = KO
        }
      },
      TO = () => 1;

    function NO(OO, KO, pO, XO) {
      return function(OO, KO, pO, XO) {
        let bK, eO, lO = {},
          vK = new dO,
          CO = function(OO) {
            let KO = OO.v !== bK ? OO.v : OO.w,
              XO = lO[KO];
            if (!XO) return;
            let CO = pO(OO),
              hO = eO.distance + CO;
            if (CO < 0) throw new Error("dijkstra does not allow negative edge weights. Bad edge: " + OO + " Weight: " + CO);
            hO < XO.distance && (XO.distance = hO, XO.predecessor = bK, vK.decrease(KO, hO))
          };
        for (OO.nodes().forEach((function(OO) {
            let pO = OO === KO ? 0 : Number.POSITIVE_INFINITY;
            lO[OO] = {
              distance: pO,
              predecessor: ""
            }, vK.add(OO, pO)
          })); vK.size() > 0;) {
          bK = vK.removeMin();
          let OO = lO[bK];
          if (!OO || OO.distance === Number.POSITIVE_INFINITY) break;
          eO = OO, XO(bK).forEach(CO)
        }
        return lO
      }(OO, String(KO), pO || TO, XO || function(KO) {
        var pO;
        return null != (pO = OO.outEdges(KO)) ? pO : []
      })
    }

    function IO(OO, KO, pO) {
      return OO.nodes().reduce((function(XO, bK) {
        return XO[bK] = NO(OO, bK, KO, pO), XO
      }), {})
    }

    function yK(OO) {
      let KO = 0,
        pO = [],
        XO = {},
        bK = [];

      function eO(lO) {
        var vK;
        let CO = XO[lO] = {
          onStack: !0,
          lowlink: KO,
          index: KO++
        };
        if (pO.push(lO), null == (vK = OO.successors(lO)) || vK.forEach((function(OO) {
            if (OO in XO) {
              let KO = XO[OO];
              null != KO && KO.onStack && (CO.lowlink = Math.min(CO.lowlink, KO.index))
            } else {
              eO(OO);
              let KO = XO[OO];
              KO && (CO.lowlink = Math.min(CO.lowlink, KO.lowlink))
            }
          })), CO.lowlink === CO.index) {
          let OO, KO = [];
          do {
            OO = pO.pop();
            let bK = XO[OO];
            bK && (bK.onStack = !1), KO.push(OO)
          } while (lO !== OO);
          bK.push(KO)
        }
      }
      return OO.nodes().forEach((function(OO) {
        OO in XO || eO(OO)
      })), bK
    }

    function gK(OO) {
      return yK(OO).filter((function(KO) {
        var pO;
        let XO = KO[0];
        return !!XO && (KO.length > 1 || 1 === KO.length && (null != (pO = OO.outEdges(XO, XO)) ? pO : []).length > 0)
      }))
    }
    var uO = () => 1;

    function EO(OO, KO, pO) {
      return function(OO, KO, pO) {
        let XO = {},
          bK = OO.nodes();
        return bK.forEach((function(OO) {
          let eO = {};
          XO[OO] = eO, eO[OO] = {
            distance: 0,
            predecessor: ""
          }, bK.forEach((function(KO) {
            OO !== KO && (eO[KO] = {
              distance: Number.POSITIVE_INFINITY,
              predecessor: ""
            })
          })), pO(OO).forEach((function(pO) {
            let XO = pO.v === OO ? pO.w : pO.v,
              bK = KO(pO);
            eO[XO] = {
              distance: bK,
              predecessor: OO
            }
          }))
        })), bK.forEach((function(OO) {
          let KO = XO[OO];
          KO && bK.forEach((function(pO) {
            let eO = XO[pO];
            eO && bK.forEach((function(pO) {
              let XO = eO[OO],
                bK = KO[pO],
                lO = eO[pO];
              if (XO && bK && lO) {
                let OO = XO.distance + bK.distance;
                OO < lO.distance && (lO.distance = OO, lO.predecessor = bK.predecessor)
              }
            }))
          }))
        })), XO
      }(OO, KO || uO, pO || function(KO) {
        var pO;
        return null != (pO = OO.outEdges(KO)) ? pO : []
      })
    }
    var jK = class extends Error {
      constructor(OO) {
        super(OO), this.name = "CycleException"
      }
    };

    function YO(OO) {
      let KO = {},
        pO = {},
        XO = [];
      if (OO.sinks().forEach((function bK(eO) {
          var lO;
          if (eO in pO) throw new jK;
          eO in KO || (pO[eO] = !0, KO[eO] = !0, null == (lO = OO.predecessors(eO)) || lO.forEach(bK), delete pO[eO], XO.push(eO))
        })), Object.keys(KO).length !== OO.nodeCount()) throw new jK;
      return XO
    }

    function wO(OO) {
      try {
        YO(OO)
      } catch (KO) {
        if (KO instanceof jK) return !1;
        throw KO
      }
      return !0
    }

    function iK(OO, KO, pO, XO, bK) {
      Array.isArray(KO) || (KO = [KO]);
      let eO = KO => {
          var pO;
          return null != (pO = OO.isDirected() ? OO.successors(KO) : OO.neighbors(KO)) ? pO : []
        },
        lO = {};
      return KO.forEach((function(KO) {
        if (!OO.hasNode(KO)) throw new Error("Graph does not have node: " + KO);
        bK = rK(OO, KO, "post" === pO, lO, eO, XO, bK)
      })), bK
    }

    function rK(OO, KO, pO, XO, bK, eO, lO) {
      return KO in XO || (XO[KO] = !0, pO || (lO = eO(lO, KO)), bK(KO).forEach((function(KO) {
        lO = rK(OO, KO, pO, XO, bK, eO, lO)
      })), pO && (lO = eO(lO, KO))), lO
    }

    function PO(OO, KO, pO) {
      return iK(OO, KO, pO, (function(OO, KO) {
        return OO.push(KO), OO
      }), [])
    }

    function mK(OO, KO) {
      return PO(OO, KO, "post")
    }

    function sO(OO, KO) {
      return PO(OO, KO, "pre")
    }

    function HO(OO, KO) {
      var pO;
      let XO, bK = new CO,
        eO = {},
        lO = new dO;

      function vK(OO) {
        let pO = OO.v === XO ? OO.w : OO.v,
          bK = lO.priority(pO);
        if (void 0 !== bK) {
          let vK = KO(OO);
          vK < bK && (eO[pO] = XO, lO.decrease(pO, vK))
        }
      }
      if (0 === OO.nodeCount()) return bK;
      OO.nodes().forEach((function(OO) {
        lO.add(OO, Number.POSITIVE_INFINITY), bK.setNode(OO)
      }));
      let hO = OO.nodes()[0];
      void 0 !== hO && lO.decrease(hO, 0);
      let DO = !1;
      for (; lO.size() > 0;) {
        if (XO = lO.removeMin(), XO in eO) bK.setEdge(XO, eO[XO]);
        else {
          if (DO) throw new Error("Input graph is not connected: " + OO);
          DO = !0
        }
        null == (pO = OO.nodeEdges(XO)) || pO.forEach(vK)
      }
      return bK
    }

    function RO(OO, KO, pO, XO) {
      return function(OO, KO, pO, XO) {
        if (void 0 === pO) return NO(OO, KO, pO, XO);
        let bK = !1,
          eO = OO.nodes();
        for (let lO = 0; lO < eO.length; lO++) {
          let vK = eO[lO];
          if (void 0 === vK) continue;
          let CO = XO(vK);
          for (let OO = 0; OO < CO.length; OO++) {
            let KO = CO[OO];
            if (!KO) continue;
            let XO = KO.v === vK ? KO.v : KO.w;
            pO({
              v: XO,
              w: XO === KO.v ? KO.w : KO.v
            }) < 0 && (bK = !0)
          }
          if (bK) return AO(OO, KO, pO, XO)
        }
        return NO(OO, KO, pO, XO)
      }(OO, KO, pO, null != XO ? XO : KO => {
        var pO;
        return null != (pO = OO.outEdges(KO)) ? pO : []
      })
    }
    var SO = CO;

    function JO(OO, KO, pO, XO) {
      let bK = XO;
      for (; OO.hasNode(bK);) bK = UO(XO);
      return pO.dummy = KO, OO.setNode(bK, pO), bK
    }

    function cK(OO) {
      let KO = new SO({
        multigraph: OO.isMultigraph()
      }).setGraph(OO.graph());
      return OO.nodes().forEach((pO => {
        OO.children(pO).length || KO.setNode(pO, OO.node(pO))
      })), OO.edges().forEach((pO => {
        KO.setEdge(pO, OO.edge(pO))
      })), KO
    }

    function BO(OO, KO) {
      let pO, XO, bK = OO.x,
        eO = OO.y,
        lO = KO.x - bK,
        vK = KO.y - eO,
        CO = OO.width / 2,
        hO = OO.height / 2;
      if (!lO && !vK) throw new Error("Not possible to find intersection inside of the rectangle");
      return Math.abs(vK) * CO > Math.abs(lO) * hO ? (vK < 0 && (hO = -hO), pO = hO * lO / vK, XO = hO) : (lO < 0 && (CO = -CO), pO = CO, XO = CO * vK / lO), {
        x: bK + pO,
        y: eO + XO
      }
    }

    function ZO(OO) {
      let KO = OK(nO(OO) + 1).map((() => []));
      return OO.nodes().forEach((pO => {
        let XO = OO.node(pO),
          bK = XO.rank;
        void 0 !== bK && (KO[bK] || (KO[bK] = []), KO[bK][XO.order] = pO)
      })), KO
    }

    function GO(OO, KO, pO, XO) {
      let bK = {
        width: 0,
        height: 0
      };
      return arguments.length >= 4 && (bK.rank = pO, bK.order = XO), JO(OO, "border", bK, KO)
    }
    var qK = 65535;

    function xK(OO, KO) {
      if (KO.length > qK) {
        let pO = function(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : qK,
            pO = [];
          for (let XO = 0; XO < OO.length; XO += KO) {
            let bK = OO.slice(XO, XO + KO);
            pO.push(bK)
          }
          return pO
        }(KO);
        return OO(...pO.map((KO => OO(...KO))))
      }
      return OO(...KO)
    }

    function nO(OO) {
      let KO = OO.nodes().map((KO => {
        let pO = OO.node(KO).rank;
        return void 0 === pO ? Number.MIN_VALUE : pO
      }));
      return xK(Math.max, KO)
    }

    function WO(OO, KO) {
      let pO = Date.now();
      try {
        return KO()
      } finally {
        console.log(OO + " time: " + (Date.now() - pO) + "ms")
      }
    }

    function tK(OO, KO) {
      return KO()
    }
    var kK = 0;

    function UO(OO) {
      return OO + "" + ++kK
    }

    function OK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
      null == KO && (KO = OO, OO = 0);
      let XO = OO => OO < KO;
      pO < 0 && (XO = OO => KO < OO);
      let bK = [];
      for (let eO = OO; XO(eO); eO += pO) bK.push(eO);
      return bK
    }

    function KK(OO, KO) {
      let pO = {};
      for (let XO of KO) void 0 !== OO[XO] && (pO[XO] = OO[XO]);
      return pO
    }

    function pK(OO, KO) {
      let pO;
      return pO = "string" == typeof KO ? OO => OO[KO] : KO, Object.entries(OO).reduce(((OO, KO) => {
        let [XO, bK] = KO;
        return OO[XO] = pO(bK, XO), OO
      }), {})
    }
    var XK = "\0";

    function bp(OO, KO, pO) {
      var XO, bK, eO, lO, vK, CO;
      if (!(OO && KO && pO && "edge" === KO.dummy && "edge" === pO.dummy && KO.edgeObj && pO.edgeObj && OO[KO.edgeObj.v] && OO[pO.edgeObj.v] && OO[KO.edgeObj.w] && OO[pO.edgeObj.w])) return 0;
      let hO = !0;
      KO.edgeObj.w === pO.edgeObj.w && (hO = !1);
      let DO = hO ? null != (bK = null == (XO = OO[KO.edgeObj.v]) ? void 0 : XO.rank) ? bK : NaN : null != (lO = null == (eO = OO[KO.edgeObj.w]) ? void 0 : eO.rank) ? lO : NaN,
        MO = Object.entries(OO).find((OO => {
          var pO, XO;
          return (null == (pO = OO[1].edgeObj) ? void 0 : pO.v) === KO.edgeObj.v && (null == (XO = OO[1].edgeObj) ? void 0 : XO.w) === KO.edgeObj.w && OO[1].rank === DO
        })),
        aK = Object.entries(OO).find((OO => {
          var KO, XO;
          return (null == (KO = OO[1].edgeObj) ? void 0 : KO.v) === pO.edgeObj.v && (null == (XO = OO[1].edgeObj) ? void 0 : XO.w) === pO.edgeObj.w && OO[1].rank === DO
        }));
      if (!MO || !aK) return 0;
      let oO = null != (vK = MO[1].order) ? vK : NaN,
        FO = null != (CO = aK[1].order) ? CO : NaN;
      return isNaN(oO - FO) ? 0 : oO - FO
    }
    var eK = "3.1.1";

    function lK(OO) {
      OO._prev._next = OO._next, OO._next._prev = OO._prev, delete OO._next, delete OO._prev
    }

    function vp(OO, KO) {
      if ("_next" !== OO && "_prev" !== OO) return KO
    }
    var CK = class {
        constructor() {
          bK(this, "_sentinel");
          let OO = {};
          OO._next = OO._prev = OO, this._sentinel = OO
        }
        dequeue() {
          let OO = this._sentinel,
            KO = OO._prev;
          if (KO !== OO) return lK(KO), KO
        }
        enqueue(OO) {
          let KO = this._sentinel;
          OO._prev && OO._next && lK(OO), OO._next = KO._next, KO._next._prev = OO, KO._next = OO, OO._prev = KO
        }
        toString() {
          let OO = [],
            KO = this._sentinel,
            pO = KO._prev;
          for (; pO !== KO;) OO.push(JSON.stringify(pO, vp)), pO = pO._prev;
          return "[" + OO.join(", ") + "]"
        }
      },
      hK = () => 1;

    function DK(OO, KO) {
      if (OO.nodeCount() <= 1) return [];
      let pO = function(OO, KO) {
        let pO = new SO,
          XO = 0,
          bK = 0;
        OO.nodes().forEach((OO => {
          pO.setNode(OO, {
            v: OO,
            in: 0,
            out: 0
          })
        })), OO.edges().forEach((OO => {
          let eO = pO.edge(OO.v, OO.w) || 0,
            lO = KO(OO),
            vK = eO + lO;
          pO.setEdge(OO.v, OO.w, vK);
          let CO = pO.node(OO.v),
            hO = pO.node(OO.w);
          bK = Math.max(bK, CO.out += lO), XO = Math.max(XO, hO.in += lO)
        }));
        let eO = function(OO) {
            let KO = [];
            for (let pO = 0; pO < OO; pO++) KO.push(pO);
            return KO
          }(bK + XO + 3).map((() => new CK)),
          lO = XO + 1;
        return pO.nodes().forEach((OO => {
          ap(eO, lO, pO.node(OO))
        })), {
          graph: pO,
          buckets: eO,
          zeroIdx: lO
        }
      }(OO, KO || hK);
      return function(OO, KO, pO) {
        var XO;
        let bK, eO = [],
          lO = KO[KO.length - 1],
          vK = KO[0];
        for (; OO.nodeCount();) {
          for (; bK = vK.dequeue();) MK(OO, KO, pO, bK);
          for (; bK = lO.dequeue();) MK(OO, KO, pO, bK);
          if (OO.nodeCount())
            for (let lO = KO.length - 2; lO > 0; --lO)
              if (bK = null == (XO = KO[lO]) ? void 0 : XO.dequeue(), bK) {
                eO = eO.concat(MK(OO, KO, pO, bK, !0) || []);
                break
              }
        }
        return eO
      }(pO.graph, pO.buckets, pO.zeroIdx).flatMap((KO => OO.outEdges(KO.v, KO.w) || []))
    }

    function MK(OO, KO, pO, XO, bK) {
      let eO = [],
        lO = bK ? eO : void 0;
      return (OO.inEdges(XO.v) || []).forEach((XO => {
        let lO = OO.edge(XO),
          vK = OO.node(XO.v);
        bK && eO.push({
          v: XO.v,
          w: XO.w
        }), vK.out -= lO, ap(KO, pO, vK)
      })), (OO.outEdges(XO.v) || []).forEach((XO => {
        let bK = OO.edge(XO),
          eO = XO.w,
          lO = OO.node(eO);
        lO.in -= bK, ap(KO, pO, lO)
      })), OO.removeNode(XO.v), lO
    }

    function ap(OO, KO, pO) {
      var XO, bK, eO;
      pO.out ? pO.in ? null == (eO = OO[pO.out - pO.in + KO]) || eO.enqueue(pO) : null == (bK = OO[OO.length - 1]) || bK.enqueue(pO) : null == (XO = OO[0]) || XO.enqueue(pO)
    }

    function oK(OO, KO) {
      var pO;
      ("greedy" === OO.graph().acyclicer ? DK(OO, (pO = OO, OO => pO.edge(OO).weight)) : function(OO, KO) {
        let pO = [],
          XO = {},
          bK = {};

        function eO(KO) {
          Object.hasOwn(bK, KO) || (bK[KO] = !0, XO[KO] = !0, OO.outEdges(KO).forEach((OO => {
            Object.hasOwn(XO, OO.w) ? pO.push(OO) : eO(OO.w)
          })), delete XO[KO])
        }

        function lO(eO) {
          var vK;
          Object.hasOwn(bK, eO) || (bK[eO] = !0, XO[eO] = !0, null == (vK = OO.outEdges(eO)) || vK.forEach((bK => {
            var vK, CO;
            Object.hasOwn(XO, bK.w) || (null == (vK = KO.node(eO)) ? void 0 : vK.rank) > (null == (CO = KO.node(bK.w)) ? void 0 : CO.rank) && function(OO, KO, pO) {
              let XO = new Set;

              function bK(KO) {
                var eO;
                if (OO.sources().includes(KO)) return !0;
                XO.add(KO);
                for (let lO of null != (eO = OO.inEdges(KO)) ? eO : [])
                  if ((lO.v !== pO.v || lO.w !== pO.w) && !XO.has(lO.v) && bK(lO.v)) return !0;
                return !1
              }
              return bK(KO)
            }(OO, bK.w, bK) ? pO.push(bK) : lO(bK.w)
          })), delete XO[eO])
        }
        let vK = eO;
        return KO && "function" == typeof KO.node && (vK = lO), OO.sources().forEach(vK), OO.nodes().forEach(vK), pO
      }(OO, null != KO ? KO : null)).forEach((KO => {
        let pO = OO.edge(KO);
        OO.removeEdge(KO), pO.forwardName = KO.name, pO.reversed = !0, OO.setEdge(KO.w, KO.v, pO, UO("rev"))
      }))
    }

    function FK(OO) {
      OO.graph().dummyChains = [], OO.edges().forEach((KO => function(OO, KO) {
        let pO, XO, bK, eO = KO.v,
          lO = OO.node(eO).rank,
          vK = KO.w,
          CO = OO.node(vK).rank,
          hO = KO.name,
          DO = OO.edge(KO),
          MO = DO.labelRank;
        if (CO === lO + 1) return;
        for (OO.removeEdge(KO), bK = 0, ++lO; lO < CO; ++bK, ++lO) DO.points = [], XO = {
          width: 0,
          height: 0,
          edgeLabel: DO,
          edgeObj: KO,
          rank: lO
        }, pO = JO(OO, "edge", XO, "_d"), lO === MO && (XO.width = DO.width, XO.height = DO.height, XO.dummy = "edge-label", XO.labelpos = DO.labelpos), OO.setEdge(eO, pO, {
          weight: DO.weight
        }, hO), 0 === bK && OO.graph().dummyChains.push(pO), eO = pO;
        OO.setEdge(eO, vK, {
          weight: DO.weight
        }, hO)
      }(OO, KO)))
    }

    function VK(OO) {
      let KO = {};
      OO.sources().forEach((function pO(XO) {
        let bK = OO.node(XO);
        if (Object.hasOwn(KO, XO)) return bK.rank;
        KO[XO] = !0;
        let eO = OO.outEdges(XO),
          lO = eO ? eO.map((KO => null == KO ? Number.POSITIVE_INFINITY : pO(KO.w) - OO.edge(KO).minlen)) : [],
          vK = xK(Math.min, lO);
        return vK === Number.POSITIVE_INFINITY && (vK = 0), bK.rank = vK
      }))
    }

    function LK(OO, KO) {
      return OO.node(KO.w).rank - OO.node(KO.v).rank - OO.edge(KO).minlen
    }
    var QK = function(OO) {
      let KO = new SO({
          directed: !1
        }),
        pO = OO.nodes();
      if (0 === pO.length) throw new Error("Graph must have at least one node");
      let XO, bK, eO = pO[0],
        lO = OO.nodeCount();
      for (KO.setNode(eO, {}); zp(KO, OO) < lO && (XO = AK(KO, OO), XO);) bK = KO.hasNode(XO.v) ? LK(OO, XO) : -LK(OO, XO), fK(KO, OO, bK);
      return KO
    };

    function zp(OO, KO) {
      return OO.nodes().forEach((function pO(XO) {
        let bK = KO.nodeEdges(XO);
        bK && bK.forEach((bK => {
          let eO = bK.v,
            lO = XO === eO ? bK.w : eO;
          !OO.hasNode(lO) && !LK(KO, bK) && (OO.setNode(lO, {}), OO.setEdge(XO, lO, {}), pO(lO))
        }))
      })), OO.nodeCount()
    }

    function AK(OO, KO) {
      return KO.edges().reduce(((pO, XO) => {
        let bK = Number.POSITIVE_INFINITY;
        return OO.hasNode(XO.v) !== OO.hasNode(XO.w) && (bK = LK(KO, XO)), bK < pO[0] ? [bK, XO] : pO
      }), [Number.POSITIVE_INFINITY, null])[1]
    }

    function fK(OO, KO, pO) {
      OO.nodes().forEach((OO => KO.node(OO).rank += pO))
    }
    var {
      preorder: dK,
      postorder: TK
    } = QO, NK = IK;

    function IK(OO) {
      OO = function(OO) {
        let KO = (new SO).setGraph(OO.graph());
        return OO.nodes().forEach((pO => KO.setNode(pO, OO.node(pO)))), OO.edges().forEach((pO => {
          let XO = KO.edge(pO.v, pO.w) || {
              weight: 0,
              minlen: 1
            },
            bK = OO.edge(pO);
          KO.setEdge(pO.v, pO.w, {
            weight: XO.weight + bK.weight,
            minlen: Math.max(XO.minlen, bK.minlen)
          })
        })), KO
      }(OO), VK(OO);
      let KO, pO, XO = QK(OO);
      for (uK(XO), yp(XO, OO); KO = jp(XO);) pO = YK(XO, OO, KO), wK(XO, OO, KO, pO)
    }

    function yp(OO, KO) {
      let pO = TK(OO, OO.nodes());
      pO = pO.slice(0, pO.length - 1), pO.forEach((pO => function(OO, KO, pO) {
        let XO = OO.node(pO).parent,
          bK = OO.edge(pO, XO);
        bK.cutvalue = gp(OO, KO, pO)
      }(OO, KO, pO)))
    }

    function gp(OO, KO, pO) {
      let XO = OO.node(pO).parent,
        bK = !0,
        eO = KO.edge(pO, XO),
        lO = 0;
      eO || (bK = !1, eO = KO.edge(XO, pO)), lO = eO.weight;
      let vK = KO.nodeEdges(pO);
      return vK && vK.forEach((eO => {
        let vK = eO.v === pO,
          CO = vK ? eO.w : eO.v;
        if (CO !== XO) {
          let XO = vK === bK,
            hO = KO.edge(eO).weight;
          if (lO += XO ? hO : -hO, function(OO, KO, pO) {
              return OO.hasEdge(KO, pO)
            }(OO, pO, CO)) {
            let KO = OO.edge(pO, CO).cutvalue;
            lO += XO ? -KO : KO
          }
        }
      })), lO
    }

    function uK(OO, KO) {
      arguments.length < 2 && (KO = OO.nodes()[0]), EK(OO, {}, 1, KO)
    }

    function EK(OO, KO, pO, XO, bK) {
      let eO = pO,
        lO = OO.node(XO);
      KO[XO] = !0;
      let vK = OO.neighbors(XO);
      return vK && vK.forEach((bK => {
        Object.hasOwn(KO, bK) || (pO = EK(OO, KO, pO, bK, XO))
      })), lO.low = eO, lO.lim = pO++, bK ? lO.parent = bK : delete lO.parent, pO
    }

    function jp(OO) {
      return OO.edges().find((KO => OO.edge(KO).cutvalue < 0))
    }

    function YK(OO, KO, pO) {
      let XO = pO.v,
        bK = pO.w;
      KO.hasEdge(XO, bK) || (XO = pO.w, bK = pO.v);
      let eO = OO.node(XO),
        lO = OO.node(bK),
        vK = eO,
        CO = !1;
      return eO.lim > lO.lim && (vK = lO, CO = !0), KO.edges().filter((KO => CO === ip(OO, OO.node(KO.v), vK) && CO !== ip(OO, OO.node(KO.w), vK))).reduce(((OO, pO) => LK(KO, pO) < LK(KO, OO) ? pO : OO))
    }

    function wK(OO, KO, pO, XO) {
      let bK = pO.v,
        eO = pO.w;
      OO.removeEdge(bK, eO), OO.setEdge(XO.v, XO.w, {}), uK(OO), yp(OO, KO),
        function(OO, KO) {
          let pO = OO.nodes().find((KO => !OO.node(KO).parent));
          if (!pO) return;
          let XO = dK(OO, [pO]);
          XO = XO.slice(1), XO.forEach((pO => {
            let XO = OO.node(pO).parent,
              bK = KO.edge(pO, XO),
              eO = !1;
            bK || (bK = KO.edge(XO, pO), eO = !0), KO.node(pO).rank = KO.node(XO).rank + (eO ? bK.minlen : -bK.minlen)
          }))
        }(OO, KO)
    }

    function ip(OO, KO, pO) {
      return pO.low <= KO.lim && KO.lim <= pO.lim
    }
    IK.initLowLimValues = uK, IK.initCutValues = yp, IK.calcCutValue = gp, IK.leaveEdge = jp, IK.enterEdge = YK, IK.exchangeEdges = wK;
    var rp = function(OO) {
      let KO = OO.graph().ranker;
      if ("function" == typeof KO) return KO(OO);
      switch (KO) {
        case "network-simplex":
        default:
          mp(OO);
          break;
        case "tight-tree":
          ! function(OO) {
            VK(OO), QK(OO)
          }(OO);
          break;
        case "longest-path":
          PK(OO);
        case "none":
      }
    };
    var PK = VK;

    function mp(OO) {
      NK(OO)
    }
    var sK = function(OO) {
      let KO = function(OO) {
          let KO = {},
            pO = 0;

          function XO(bK) {
            let eO = pO;
            OO.children(bK).forEach(XO), KO[bK] = {
              low: eO,
              lim: pO++
            }
          }
          return OO.children(XK).forEach(XO), KO
        }(OO),
        pO = OO.graph();
      if (!Array.isArray(pO.dummyChains)) return;
      pO.dummyChains.forEach((pO => {
        let XO = OO.node(pO),
          bK = XO.edgeObj,
          eO = function(OO, KO, pO, XO) {
            let bK, eO = [],
              lO = [],
              vK = Math.min(KO[pO].low, KO[XO].low),
              CO = Math.max(KO[pO].lim, KO[XO].lim);
            bK = pO;
            do {
              bK = OO.parent(bK), eO.push(bK)
            } while (bK && (KO[bK].low > vK || CO > KO[bK].lim));
            let hO = bK,
              DO = XO;
            for (;
              (DO = OO.parent(DO)) !== hO;) lO.push(DO);
            return {
              path: eO.concat(lO.reverse()),
              lca: hO
            }
          }(OO, KO, bK.v, bK.w),
          lO = eO.path,
          vK = eO.lca,
          CO = 0,
          hO = lO[CO],
          DO = !0;
        for (; pO !== bK.w;) {
          if (XO = OO.node(pO), DO) {
            for (;
              (hO = lO[CO]) !== vK && OO.node(hO).maxRank < XO.rank;) CO++;
            hO === vK && (DO = !1)
          }
          if (!DO) {
            for (; CO < lO.length - 1 && OO.node(lO[CO + 1]).minRank <= XO.rank;) CO++;
            hO = lO[CO]
          }
          void 0 !== hO && OO.setParent(pO, hO), pO = OO.successors(pO)[0]
        }
      }))
    };

    function HK(OO) {
      let KO = JO(OO, "root", {}, "_root"),
        pO = function(OO) {
          let KO = {};

          function pO(XO, bK) {
            let eO = OO.children(XO);
            eO && eO.length && eO.forEach((OO => pO(OO, bK + 1))), KO[XO] = bK
          }
          return OO.children(XK).forEach((OO => pO(OO, 1))), KO
        }(OO),
        XO = Object.values(pO),
        bK = xK(Math.max, XO) - 1,
        eO = 2 * bK + 1;
      OO.graph().nestingRoot = KO, OO.edges().forEach((KO => OO.edge(KO).minlen *= eO));
      let lO = function(OO) {
        return OO.edges().reduce(((KO, pO) => KO + OO.edge(pO).weight), 0)
      }(OO) + 1;
      OO.children(XK).forEach((XO => {
        RK(OO, KO, eO, lO, bK, pO, XO)
      })), OO.graph().nodeRankFactor = eO
    }

    function RK(OO, KO, pO, XO, bK, eO, lO) {
      var vK;
      let CO = OO.children(lO);
      if (!CO.length) return void(lO !== KO && OO.setEdge(KO, lO, {
        weight: 0,
        minlen: pO
      }));
      let hO = GO(OO, "_bt"),
        DO = GO(OO, "_bb"),
        MO = OO.node(lO);
      OO.setParent(hO, lO), MO.borderTop = hO, OO.setParent(DO, lO), MO.borderBottom = DO, CO.forEach((vK => {
        var CO;
        RK(OO, KO, pO, XO, bK, eO, vK);
        let MO = OO.node(vK),
          aK = MO.borderTop ? MO.borderTop : vK,
          oO = MO.borderBottom ? MO.borderBottom : vK,
          FO = MO.borderTop ? XO : 2 * XO,
          VO = aK !== oO ? 1 : bK - (null != (CO = eO[lO]) ? CO : 0) + 1;
        OO.setEdge(hO, aK, {
          weight: FO,
          minlen: VO,
          nestingEdge: !0
        }), OO.setEdge(oO, DO, {
          weight: FO,
          minlen: VO,
          nestingEdge: !0
        })
      })), OO.parent(lO) || OO.setEdge(KO, hO, {
        weight: 0,
        minlen: bK + (null != (vK = eO[lO]) ? vK : 0)
      })
    }
    var SK = function(OO) {
      OO.children(XK).forEach((function KO(pO) {
        let XO = OO.children(pO),
          bK = OO.node(pO);
        if (XO.length && XO.forEach(KO), bK && Object.hasOwn(bK, "minRank")) {
          bK.borderLeft = [], bK.borderRight = [];
          for (let KO = bK.minRank, XO = bK.maxRank + 1; KO < XO; ++KO) JK(OO, "borderLeft", "_bl", pO, bK, KO), JK(OO, "borderRight", "_br", pO, bK, KO)
        }
      }))
    };

    function JK(OO, KO, pO, XO, bK, eO) {
      let lO = {
          width: 0,
          height: 0,
          rank: eO,
          borderType: KO
        },
        vK = bK[KO][eO - 1],
        CO = JO(OO, "border", lO, pO);
      bK[KO][eO] = CO, OO.setParent(CO, XO), vK && OO.setEdge(vK, CO, {
        weight: 1
      })
    }

    function cp(OO) {
      var KO;
      let pO = null == (KO = OO.graph().rankdir) ? void 0 : KO.toLowerCase();
      ("bt" === pO || "rl" === pO) && function(OO) {
        OO.nodes().forEach((KO => GK(OO.node(KO)))), OO.edges().forEach((KO => {
          var pO;
          let XO = OO.edge(KO);
          null == (pO = XO.points) || pO.forEach(GK), Object.hasOwn(XO, "y") && GK(XO)
        }))
      }(OO), ("lr" === pO || "rl" === pO) && (function(OO) {
        OO.nodes().forEach((KO => qp(OO.node(KO)))), OO.edges().forEach((KO => {
          var pO;
          let XO = OO.edge(KO);
          null == (pO = XO.points) || pO.forEach(qp), Object.hasOwn(XO, "x") && qp(XO)
        }))
      }(OO), BK(OO))
    }

    function BK(OO) {
      OO.nodes().forEach((KO => ZK(OO.node(KO)))), OO.edges().forEach((KO => ZK(OO.edge(KO))))
    }

    function ZK(OO) {
      let KO = OO.width;
      OO.width = OO.height, OO.height = KO
    }

    function GK(OO) {
      OO.y = -OO.y
    }

    function qp(OO) {
      let KO = OO.x;
      OO.x = OO.y, OO.y = KO
    }

    function xp(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
        pO = {},
        XO = OO.nodes().filter((KO => !OO.children(KO).length)),
        bK = XO.map((KO => OO.node(KO).rank)),
        eO = OK(xK(Math.max, bK) + 1).map((() => []));
      return XO.sort(((KO, pO) => OO.node(KO).rank - OO.node(pO).rank)).forEach((function XO(bK) {
        if (pO[bK]) return;
        pO[bK] = !0;
        let lO = OO.node(bK);
        eO[lO.rank].push(bK);
        let vK = OO.successors(bK);
        vK && [...vK].sort(((pO, XO) => function(pO, XO) {
          let bK = OO.node(pO),
            eO = OO.node(XO);
          return bp(KO, bK, eO)
        }(pO, XO))).forEach(XO)
      })), eO
    }

    function nK(OO, KO) {
      let pO = 0;
      for (let XO = 1; XO < KO.length; ++XO) pO += WK(OO, KO[XO - 1], KO[XO]);
      return pO
    }

    function WK(OO, KO, pO) {
      let XO = function(OO, KO) {
          return OO.reduce(((OO, pO, XO) => (OO[pO] = KO[XO], OO)), {})
        }(pO, pO.map(((OO, KO) => KO))),
        bK = KO.flatMap((KO => {
          let pO = OO.outEdges(KO);
          return pO ? pO.map((KO => ({
            pos: XO[KO.w],
            weight: OO.edge(KO).weight
          }))).sort(((OO, KO) => OO.pos - KO.pos)) : []
        })),
        eO = 1;
      for (; eO < pO.length;) eO <<= 1;
      let lO = 2 * eO - 1;
      eO -= 1;
      let vK = new Array(lO).fill(0),
        CO = 0;
      return bK.forEach((OO => {
        let KO = OO.pos + eO;
        vK[KO] += OO.weight;
        let pO = 0;
        for (; KO > 0;) KO % 2 && (pO += vK[KO + 1]), KO = KO - 1 >> 1, vK[KO] += OO.weight;
        CO += OO.weight * pO
      })), CO
    }

    function tp(OO, KO) {
      let pO = {};
      return OO.forEach(((OO, KO) => {
          let XO = {
            indegree: 0,
            in: [],
            out: [],
            vs: [OO.v],
            i: KO
          };
          void 0 !== OO.barycenter && (XO.barycenter = OO.barycenter, XO.weight = OO.weight), pO[OO.v] = XO
        })), KO.edges().forEach((OO => {
          let KO = pO[OO.v],
            XO = pO[OO.w];
          void 0 !== KO && void 0 !== XO && (XO.indegree++, KO.out.push(XO))
        })),
        function(OO) {
          let KO = [];

          function pO(OO) {
            return KO => {
              KO.merged || (void 0 === KO.barycenter || void 0 === OO.barycenter || KO.barycenter >= OO.barycenter) && function(OO, KO) {
                let pO = 0,
                  XO = 0;
                OO.weight && (pO += OO.barycenter * OO.weight, XO += OO.weight), KO.weight && (pO += KO.barycenter * KO.weight, XO += KO.weight), OO.vs = KO.vs.concat(OO.vs), OO.barycenter = pO / XO, OO.weight = XO, OO.i = Math.min(KO.i, OO.i), KO.merged = !0
              }(OO, KO)
            }
          }

          function XO(KO) {
            return pO => {
              pO.in.push(KO), 0 === --pO.indegree && OO.push(pO)
            }
          }
          for (; OO.length;) {
            let bK = OO.pop();
            KO.push(bK), bK.in.reverse().forEach(pO(bK)), bK.out.forEach(XO(bK))
          }
          return KO.filter((OO => !OO.merged)).map((OO => KK(OO, ["vs", "i", "barycenter", "weight"])))
        }(Object.values(pO).filter((OO => !OO.indegree)))
    }

    function kp(OO, KO, pO, XO, bK) {
      let eO = {},
        lO = null,
        vK = null,
        CO = bK;
      "boolean" == typeof KO ? (CO = KO, eO = {}) : KO && (eO = KO, lO = null != pO ? pO : null, vK = null != XO ? XO : null);
      let hO = function(OO, KO) {
          let pO = {
            lhs: [],
            rhs: []
          };
          return OO.forEach((OO => {
            KO(OO) ? pO.lhs.push(OO) : pO.rhs.push(OO)
          })), pO
        }(OO, (OO => Object.hasOwn(OO, "barycenter"))),
        DO = hO.lhs,
        MO = hO.rhs.sort(((OO, KO) => KO.i - OO.i)),
        aK = [],
        oO = 0,
        FO = 0,
        VO = 0;
      DO.sort(function(OO, KO, pO) {
        return (XO, bK) => {
          if (XO.barycenter < bK.barycenter) return -1;
          if (XO.barycenter > bK.barycenter) return 1;
          if (OO && ("string" == typeof XO.vs[0] || "string" == typeof bK.vs[0])) {
            let pO = OO.node(XO.vs[0]),
              eO = OO.node(bK.vs[0]),
              lO = bp(KO, pO, eO);
            if (0 !== lO) return lO
          }
          return pO ? bK.i - XO.i : XO.i - bK.i
        }
      }(vK, lO, !!CO));
      for (let [QO, zK] of Object.entries(eO)) {
        let OO = DO.findIndex((OO => OO.vs[0] === QO));
        DO.splice(OO + 1, 0, zK)
      }
      VO = UK(aK, MO, VO), DO.forEach((OO => {
        VO += OO.vs.length, aK.push(OO.vs), oO += OO.barycenter * OO.weight, FO += OO.weight, VO = UK(aK, MO, VO)
      }));
      let LO = {
        vs: aK.flat(1)
      };
      return FO && (LO.barycenter = oO / FO, LO.weight = FO), LO
    }

    function UK(OO, KO, pO) {
      let XO;
      for (; KO.length && (XO = KO[KO.length - 1]).i <= pO;) KO.pop(), OO.push(XO.vs), pO++;
      return pO
    }

    function Op(OO, KO, pO, XO, bK) {
      var eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO;
      let LO = null,
        QO = bK;
      "boolean" == typeof XO ? (QO = XO, LO = null) : void 0 !== XO && (LO = XO);
      let zK = OO.children(KO),
        AO = OO.node(KO),
        fO = AO ? AO.borderLeft : void 0,
        dO = AO ? AO.borderRight : void 0,
        TO = {};
      fO && (zK = zK.filter((OO => OO !== fO && OO !== dO)));
      let NO = function(OO) {
        return (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : []).map((KO => {
          let pO = OO.inEdges(KO);
          if (!pO || !pO.length) return {
            v: KO
          };
          {
            let XO = pO.reduce(((KO, pO) => {
              let XO = OO.edge(pO),
                bK = OO.node(pO.v);
              return {
                sum: KO.sum + XO.weight * bK.order,
                weight: KO.weight + XO.weight
              }
            }), {
              sum: 0,
              weight: 0
            });
            return {
              v: KO,
              barycenter: XO.sum / XO.weight,
              weight: XO.weight
            }
          }
        }))
      }(OO, zK);
      NO.forEach((KO => {
        if (OO.children(KO.v).length) {
          let {
            result: XO
          } = Op(OO, KO.v, pO, LO, QO);
          TO[KO.v] = XO, Object.hasOwn(XO, "barycenter") && function(OO, KO) {
            void 0 !== OO.barycenter ? (OO.barycenter = (OO.barycenter * OO.weight + KO.barycenter * KO.weight) / (OO.weight + KO.weight), OO.weight += KO.weight) : (OO.barycenter = KO.barycenter, OO.weight = KO.weight)
          }(KO, XO)
        }
      }));
      let IO = tp(NO, pO);
      ! function(OO, KO) {
        OO.forEach((OO => {
          OO.vs = OO.vs.flatMap((OO => KO[OO] ? KO[OO].vs : OO))
        }))
      }(IO, TO);
      let yK = {},
        gK = !1;
      for (let EO = 0; EO < IO.length; EO++)
        for (let KO = EO + 1; KO < IO.length; KO++)
          if (IO[EO] && IO[KO] && null != (eO = IO[EO]) && eO.barycenter && null != (lO = IO[KO]) && lO.barycenter && (null == (vK = IO[EO]) ? void 0 : vK.barycenter) === IO[KO].barycenter) {
            let pO = null != (hO = null == (CO = IO[EO]) ? void 0 : CO.vs[0]) ? hO : "",
              XO = null != (MO = null == (DO = IO[KO]) ? void 0 : DO.vs[0]) ? MO : "",
              bK = OO.node(pO),
              eO = OO.node(XO);
            if ("edge" === bK.dummy && "edge" === eO.dummy && (null == (aK = bK.edgeObj) ? void 0 : aK.v) === (null == (oO = eO.edgeObj) ? void 0 : oO.v) && (null == (FO = bK.edgeObj) ? void 0 : FO.w) === (null == (VO = eO.edgeObj) ? void 0 : VO.w)) {
              if (bK.edgeLabel.reversed) {
                yK[XO] = IO[EO], IO.splice(EO, 1), EO--;
                break
              }
              yK[pO] = IO[KO], IO.splice(KO, 1), KO--
            } else gK = !0
          } let uO = kp(IO, yK, LO, OO, QO);
      if (fO && dO) {
        uO.vs = [fO, uO.vs, dO].flat(1);
        let KO = OO.predecessors(fO);
        if (KO && KO.length) {
          let pO = OO.node(KO[0]),
            XO = OO.predecessors(dO),
            bK = OO.node(XO[0]);
          Object.hasOwn(uO, "barycenter") || (uO.barycenter = 0, uO.weight = 0), uO.barycenter = (uO.barycenter * uO.weight + pO.order + bK.order) / (uO.weight + 2), uO.weight += 2
        }
      }
      return Object.defineProperty(uO, "result", {
        value: uO,
        enumerable: !1,
        configurable: !0,
        writable: !0
      }), Object.defineProperty(uO, "usedBias", {
        value: gK,
        enumerable: !1,
        configurable: !0,
        writable: !0
      }), uO
    }

    function Kp(OO, KO, pO, XO) {
      XO || (XO = OO.nodes());
      let bK = function(OO) {
          let KO;
          for (; OO.hasNode(KO = UO("_root")););
          return KO
        }(OO),
        eO = new SO({
          compound: !0
        }).setGraph({
          root: bK
        }).setDefaultNodeLabel((KO => OO.node(KO)));
      return XO.forEach((XO => {
        let lO = OO.node(XO),
          vK = OO.parent(XO);
        if (lO.rank === KO || lO.minRank <= KO && KO <= lO.maxRank) {
          eO.setNode(XO), eO.setParent(XO, vK || bK);
          let CO = OO[pO](XO);
          CO && CO.forEach((KO => {
            let pO = KO.v === XO ? KO.w : KO.v,
              bK = eO.edge(pO, XO),
              lO = void 0 !== bK ? bK.weight : 0;
            eO.setEdge(pO, XO, {
              weight: OO.edge(KO).weight + lO
            })
          })), Object.hasOwn(lO, "minRank") && eO.setNode(XO, {
            borderLeft: lO.borderLeft[KO],
            borderRight: lO.borderRight[KO]
          })
        }
      })), eO
    }

    function pp(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
      if ("function" == typeof KO.customOrder) return void KO.customOrder(OO, pp);
      let XO = nO(OO),
        bK = Xp(OO, OK(1, XO + 1), "inEdges"),
        eO = Xp(OO, OK(XO - 1, -1, -1), "outEdges"),
        lO = xp(OO, pO);
      if (ep(OO, lO), KO.disableOptimalOrderHeuristic) return;
      let vK, CO = Number.POSITIVE_INFINITY,
        hO = KO.constraints || [];
      for (let DO = 0, MO = 0; MO < 4; ++DO, ++MO) {
        bX(DO % 2 ? bK : eO, DO % 4 >= 2, hO, pO), lO = ZO(OO);
        let KO = nK(OO, lO);
        KO < CO ? (MO = 0, vK = Object.assign({}, lO), CO = KO) : KO === CO && (vK = structuredClone(lO))
      }
      ep(OO, vK)
    }

    function Xp(OO, KO, pO) {
      let XO = new Map,
        bK = (OO, KO) => {
          XO.has(OO) || XO.set(OO, []), XO.get(OO).push(KO)
        };
      for (let eO of OO.nodes()) {
        let KO = OO.node(eO);
        if ("number" == typeof KO.rank && bK(KO.rank, eO), "number" == typeof KO.minRank && "number" == typeof KO.maxRank)
          for (let OO = KO.minRank; OO <= KO.maxRank; OO++) OO !== KO.rank && bK(OO, eO)
      }
      return KO.map((function(KO) {
        return Kp(OO, KO, pO, XO.get(KO) || [])
      }))
    }

    function bX(OO, KO, pO, XO) {
      let bK = !0,
        eO = new SO;
      OO.forEach((function(OO) {
        pO.forEach((OO => eO.setEdge(OO.left, OO.right)));
        let lO = OO.graph().root,
          {
            result: vK,
            usedBias: CO
          } = Op(OO, lO, eO, XO, bK);
        KO && CO && (bK = !bK), vK.vs.forEach(((KO, pO) => OO.node(KO).order = pO)),
          function(OO, KO, pO) {
            let XO, bK = {};
            pO.forEach((pO => {
              let eO, lO, vK = OO.parent(pO);
              for (; vK;) {
                if (eO = OO.parent(vK), eO ? (lO = bK[eO], bK[eO] = vK) : (lO = XO, XO = vK), lO && lO !== vK) return void KO.setEdge(lO, vK);
                vK = eO
              }
            }))
          }(OO, eO, vK.vs)
      }))
    }

    function ep(OO, KO) {
      Object.values(KO).forEach((KO => KO.forEach(((KO, pO) => OO.node(KO).order = pO))))
    }

    function lp(OO, KO, pO) {
      if (KO > pO) {
        let OO = KO;
        KO = pO, pO = OO
      }
      let XO = OO[KO];
      XO || (OO[KO] = XO = {}), XO[pO] = !0
    }

    function vX(OO, KO, pO) {
      if (KO > pO) {
        let OO = KO;
        KO = pO, pO = OO
      }
      let XO = OO[KO];
      return void 0 !== XO && Object.hasOwn(XO, pO)
    }

    function Cp(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
        eO = {},
        lO = function(OO, KO, pO, XO) {
          let bK = new SO,
            eO = OO.graph(),
            lO = function(OO, KO, pO) {
              return (XO, bK, eO) => {
                let lO, vK = XO.node(bK),
                  CO = XO.node(eO),
                  hO = 0;
                if (hO += vK.width / 2, Object.hasOwn(vK, "labelpos")) switch (vK.labelpos.toLowerCase()) {
                  case "l":
                    lO = -vK.width / 2;
                    break;
                  case "r":
                    lO = vK.width / 2
                }
                if (lO && (hO += pO ? lO : -lO), lO = void 0, hO += (vK.dummy ? KO : OO) / 2, hO += (CO.dummy ? KO : OO) / 2, hO += CO.width / 2, Object.hasOwn(CO, "labelpos")) switch (CO.labelpos.toLowerCase()) {
                  case "l":
                    lO = CO.width / 2;
                    break;
                  case "r":
                    lO = -CO.width / 2
                }
                return lO && (hO += pO ? lO : -lO), hO
              }
            }(eO.nodesep, eO.edgesep, XO);
          return KO.forEach((KO => {
            let XO;
            KO.forEach((KO => {
              let eO = pO[KO];
              if (void 0 !== eO) {
                if (bK.setNode(eO), void 0 !== XO) {
                  let vK = pO[XO];
                  if (void 0 !== vK) {
                    let pO = bK.edge(vK, eO);
                    bK.setEdge(vK, eO, Math.max(lO(OO, KO, XO), pO || 0))
                  }
                }
                XO = KO
              }
            }))
          })), bK
        }(OO, KO, pO, bK),
        vK = bK ? "borderLeft" : "borderRight";

      function CO(OO, KO) {
        let pO = lO.nodes().slice(),
          XO = {},
          bK = pO.pop();
        for (; bK;) {
          if (XO[bK]) OO(bK);
          else {
            XO[bK] = !0, pO.push(bK);
            for (let OO of KO(bK)) pO.push(OO)
          }
          bK = pO.pop()
        }
      }
      return CO((function(OO) {
        let KO = lO.inEdges(OO);
        eO[OO] = KO ? KO.reduce(((OO, KO) => {
          var pO;
          let XO = null != (pO = eO[KO.v]) ? pO : 0,
            bK = lO.edge(KO);
          return Math.max(OO, XO + (void 0 !== bK ? bK : 0))
        }), 0) : 0
      }), (function(OO) {
        return lO.predecessors(OO) || []
      })), CO((function(KO) {
        let pO = lO.outEdges(KO),
          XO = Number.POSITIVE_INFINITY;
        pO && (XO = pO.reduce(((OO, KO) => {
          let pO = eO[KO.w],
            XO = lO.edge(KO);
          return Math.min(OO, (void 0 !== pO ? pO : 0) - (void 0 !== XO ? XO : 0))
        }), Number.POSITIVE_INFINITY));
        let bK = OO.node(KO);
        XO !== Number.POSITIVE_INFINITY && bK.borderType !== vK && (eO[KO] = Math.max(void 0 !== eO[KO] ? eO[KO] : 0, XO))
      }), (function(OO) {
        return lO.successors(OO) || []
      })), Object.keys(XO).forEach((OO => {
        var KO;
        let XO = pO[OO];
        void 0 !== XO && (eO[OO] = null != (KO = eO[XO]) ? KO : 0)
      })), eO
    }

    function hp(OO, KO) {
      let pO, XO = ZO(OO),
        bK = Object.assign(function(OO, KO) {
          let pO = {};
          return KO.length && KO.reduce((function(KO, XO) {
            let bK = 0,
              eO = 0,
              lO = KO.length,
              vK = XO[XO.length - 1];
            return XO.forEach(((KO, CO) => {
              let hO = function(OO, KO) {
                  if (OO.node(KO).dummy) {
                    let pO = OO.predecessors(KO);
                    if (pO) return pO.find((KO => OO.node(KO).dummy))
                  }
                }(OO, KO),
                DO = hO ? OO.node(hO).order : lO;
              (hO || KO === vK) && (XO.slice(eO, CO + 1).forEach((KO => {
                let XO = OO.predecessors(KO);
                XO && XO.forEach((XO => {
                  let eO = OO.node(XO),
                    lO = eO.order;
                  (lO < bK || DO < lO) && (!eO.dummy || !OO.node(KO).dummy) && lp(pO, XO, KO)
                }))
              })), eO = CO + 1, bK = DO)
            })), XO
          })), pO
        }(OO, XO), function(OO, KO) {
          let pO = {};

          function XO(KO, XO, bK, eO, lO) {
            OK(XO, bK).forEach((XO => {
              let bK = KO[XO];
              if (void 0 !== bK && OO.node(bK).dummy) {
                let KO = OO.predecessors(bK);
                KO && KO.forEach((KO => {
                  if (void 0 === KO) return;
                  let XO = OO.node(KO);
                  XO.dummy && (XO.order < eO || XO.order > lO) && lp(pO, KO, bK)
                }))
              }
            }))
          }
          return KO.length && KO.reduce((function(KO, pO) {
            let bK = -1,
              eO = -1,
              lO = 0;
            return pO.forEach(((vK, CO) => {
              if ("border" === OO.node(vK).dummy) {
                let KO = OO.predecessors(vK);
                if (KO && KO.length) {
                  let vK = KO[0];
                  if (void 0 === vK) return;
                  eO = OO.node(vK).order, XO(pO, lO, CO, bK, eO), lO = CO, bK = eO
                }
              }
              XO(pO, lO, pO.length, eO, KO.length)
            })), pO
          })), pO
        }(OO, XO)),
        eO = {};
      ["u", "d"].forEach((lO => {
        pO = "u" === lO ? XO : Object.values(XO).reverse(), ["l", "r"].forEach((XO => {
          "r" === XO && (pO = pO.map((OO => Object.values(OO).reverse())));
          let vK = function(OO, KO, pO, XO, bK) {
              let eO = {},
                lO = {},
                vK = {};
              return KO.forEach((OO => {
                OO.forEach(((OO, KO) => {
                  eO[OO] = OO, lO[OO] = OO, vK[OO] = KO
                }))
              })), KO.forEach((KO => {
                let CO = -1,
                  hO = -1,
                  DO = !1,
                  MO = KO,
                  aK = KO.findIndex((KO => (null == bK ? void 0 : bK.includes(KO)) || Dp(KO, OO, bK)));
                aK > 0 && (MO = [KO[aK], ...KO.slice(0, aK), ...KO.slice(aK + 1)], DO = !0), MO.forEach((KO => {
                  var MO;
                  let aK = XO(KO);
                  if (aK && aK.length) {
                    null != bK && bK.includes(KO) && (aK = aK.filter((KO => Dp(KO, OO, bK))));
                    let XO = aK.sort(((OO, KO) => {
                        let pO = vK[OO],
                          XO = vK[KO];
                        return (void 0 !== pO ? pO : 0) - (void 0 !== XO ? XO : 0)
                      })),
                      oO = (XO.length - 1) / 2;
                    for (let OO = Math.floor(oO), bK = Math.ceil(oO); OO <= bK; ++OO) {
                      let bK = XO[OO];
                      if (void 0 === bK) continue;
                      let aK = vK[bK];
                      if (void 0 !== aK && lO[KO] === KO && CO < aK && vK[bK] !== hO && !vX(pO, KO, bK)) {
                        let OO = eO[bK];
                        void 0 !== OO && (lO[bK] = KO, lO[KO] = eO[KO] = OO, CO = aK, DO && (CO = -1, hO = null != (MO = vK[bK]) ? MO : -1, DO = !1))
                      }
                    }
                  }
                }))
              })), {
                root: eO,
                align: lO
              }
            }(OO, pO, bK, (KO => ("u" === lO ? OO.predecessors(KO) : OO.successors(KO)) || []), KO),
            CO = Cp(OO, pO, vK.root, vK.align, "r" === XO);
          "r" === XO && (CO = pK(CO, (OO => -OO))), eO[lO + XO] = CO
        }))
      }));
      let lO = function(OO, KO) {
        return Object.values(KO).reduce(((KO, pO) => {
          let XO = Number.NEGATIVE_INFINITY,
            bK = Number.POSITIVE_INFINITY;
          Object.entries(pO).forEach((KO => {
            let [pO, eO] = KO, lO = function(OO, KO) {
              return OO.node(KO).width
            }(OO, pO) / 2;
            XO = Math.max(eO + lO, XO), bK = Math.min(eO - lO, bK)
          }));
          let eO = XO - bK;
          return eO < KO[0] && (KO = [eO, pO]), KO
        }), [Number.POSITIVE_INFINITY, null])[1]
      }(OO, eO);
      return function(OO, KO) {
          let pO = Object.values(KO),
            XO = xK(Math.min, pO),
            bK = xK(Math.max, pO);
          ["u", "d"].forEach((pO => {
            ["l", "r"].forEach((eO => {
              let lO = pO + eO,
                vK = OO[lO];
              if (!vK || vK === KO) return;
              let CO = Object.values(vK),
                hO = XO - xK(Math.min, CO);
              "l" !== eO && (hO = bK - xK(Math.max, CO)), hO && (OO[lO] = pK(vK, (OO => OO + hO)))
            }))
          }))
        }(eO, lO),
        function(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0,
            pO = OO.ul;
          return pO ? pK(pO, ((pO, XO) => {
            var bK, eO;
            if (KO) {
              let pO = KO.toLowerCase(),
                bK = OO[pO];
              if (bK && void 0 !== bK[XO]) return bK[XO]
            }
            let lO = Object.values(OO).map((OO => {
              let KO = OO[XO];
              return void 0 !== KO ? KO : 0
            })).sort(((OO, KO) => OO - KO));
            return ((null != (bK = lO[1]) ? bK : 0) + (null != (eO = lO[2]) ? eO : 0)) / 2
          })) : {}
        }(eO, OO.graph().align)
    }

    function Dp(OO, KO, pO) {
      var XO;
      if (!pO) return !1;
      let bK = null == (XO = KO.node(OO)) ? void 0 : XO.edgeObj;
      if (!bK || KO.node(OO).edgeLabel.reversed) return !1;
      let eO = pO.indexOf(null == bK ? void 0 : bK.v),
        lO = pO.indexOf(null == bK ? void 0 : bK.w);
      return -1 !== eO && -1 !== lO && eO === (lO + 1) % pO.length || eO === (lO - 1) % pO.length
    }

    function Mp(OO, KO) {
      (function(OO) {
        let KO = ZO(OO),
          pO = OO.graph(),
          XO = pO.ranksep,
          bK = pO.rankalign,
          eO = 0;
        KO.forEach((KO => {
          let pO = KO.reduce(((KO, pO) => {
            var XO;
            let bK = null != (XO = OO.node(pO).height) ? XO : 0;
            return KO > bK ? KO : bK
          }), 0);
          KO.forEach((KO => {
            let XO = OO.node(KO);
            XO.y = "top" === bK ? eO + XO.height / 2 : "bottom" === bK ? eO + pO - XO.height / 2 : eO + pO / 2
          })), eO += pO + XO
        }))
      })(OO = cK(OO)), Object.entries(hp(OO, KO)).forEach((KO => {
        let [pO, XO] = KO;
        return OO.node(pO).x = XO
      }))
    }
    var aX = new WeakMap;

    function op(OO) {
      return Vp(OO, tK, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}), OO
    }

    function Fp(OO, KO, pO) {
      let XO = KO;
      for (; void 0 !== XO;) {
        let KO = OO.parent(XO);
        if (KO === pO) return XO;
        XO = KO
      }
    }

    function Vp(OO, KO, pO) {
      var XO;
      let bK = OO.nodes().filter((KO => OO.children(KO).length)),
        eO = {};
      bK.forEach((XO => {
        let bK = OO.node(XO);
        if (bK && bK.rankdir) {
          let lO = new SO({
            multigraph: !0,
            compound: !0
          });
          lO.setGraph({
            rankdir: bK.rankdir
          });
          let vK = OO.children(XO);
          vK.forEach((KO => {
            let pO = {
              ...OO.node(KO)
            };
            lO.setNode(KO, pO);
            let bK = OO.parent(KO);
            bK && bK !== XO && vK.includes(bK) && lO.setParent(KO, bK)
          }));
          let CO = new Set;
          OO.edges().forEach((KO => {
            let pO = Fp(OO, KO.v, XO),
              bK = Fp(OO, KO.w, XO);
            if (pO && bK && pO !== bK) {
              let XO = `${pO}\0${bK}`;
              CO.has(XO) || (CO.add(XO), lO.setEdge(pO, bK, {
                ...OO.edge(KO)
              }))
            }
          })), Vp(lO, KO, pO);
          let hO = gX(lO);
          Lp(hO, KO, pO, null), Qp(lO, hO);
          let DO = 1 / 0,
            MO = 1 / 0,
            aK = -1 / 0,
            oO = -1 / 0;
          lO.nodes().forEach((OO => {
            if (OO === XO) return;
            let KO = lO.node(OO);
            KO && "number" == typeof KO.x && "number" == typeof KO.y && "number" == typeof KO.width && "number" == typeof KO.height && (DO = Math.min(DO, KO.x - KO.width / 2), aK = Math.max(aK, KO.x + KO.width / 2), MO = Math.min(MO, KO.y - KO.height / 2), oO = Math.max(oO, KO.y + KO.height / 2))
          })), (!isFinite(DO) || !isFinite(MO) || !isFinite(aK) || !isFinite(oO)) && (DO = MO = 0, aK = oO = 0);
          let FO = aK - DO,
            VO = oO - MO;
          eO[XO] = {
            minX: DO,
            pp: MO,
            maxX: aK,
            ep: oO,
            width: FO,
            height: VO,
            offsetX: DO,
            offsetY: MO
          }, bK._dagreClusterSubgraph = lO
        }
      }));
      let lO = [],
        vK = new Map;
      bK.forEach((KO => {
        let pO = OO.node(KO);
        pO && pO.rankdir && eO[KO] && vK.set(KO, (OO.children(KO) || []).filter((OO => OO !== KO)))
      }));
      let CO = new Set([...vK.values()].flat()),
        hO = new Map;
      vK.forEach(((KO, pO) => {
        CO.has(pO) || hO.set(pO, (KO => {
          let pO = [],
            XO = (OO.children(KO) || []).filter((OO => OO !== KO));
          for (; XO.length > 0;) {
            let KO = XO.shift();
            pO.push(KO), (OO.children(KO) || []).filter((OO => OO !== KO)).forEach((OO => XO.push(OO)))
          }
          return pO
        })(pO))
      }));
      let DO = new Set([...hO.values()].flat()),
        MO = OO => {
          for (let [KO, pO] of hO)
            if (pO.includes(OO)) return KO;
          return OO
        },
        aK = [];
      OO.edges().forEach((KO => {
        (DO.has(KO.v) || DO.has(KO.w)) && aK.push({
          edge: KO,
          label: OO.edge(KO)
        })
      }));
      let oO = new Map;
      DO.forEach((KO => {
        let pO = OO.parent(KO);
        oO.set(KO, "string" == typeof pO ? pO : void 0)
      })), hO.forEach(((KO, pO) => {
        let XO = OO.node(pO),
          bK = [];
        KO.forEach((KO => {
          let pO = OO.node(KO);
          pO && (bK.push({
            id: KO,
            node: pO,
            parent: oO.get(KO)
          }), OO.removeNode(KO))
        }));
        let vK = aK.filter((OO => {
            let {
              edge: pO
            } = OO;
            return KO.includes(pO.v) || KO.includes(pO.w)
          })),
          CO = eO[pO];
        XO && (lO.push({
          clusterId: pO,
          subgraph: XO._dagreClusterSubgraph,
          bounds: CO,
          children: KO,
          removedNodes: bK,
          removedEdges: vK
        }), XO.width = CO.width, XO.height = CO.height)
      }));
      let FO = new Set;
      aK.forEach((KO => {
        let {
          edge: pO,
          label: XO
        } = KO, bK = MO(pO.v), eO = MO(pO.w);
        if (bK !== eO && OO.hasNode(bK) && OO.hasNode(eO)) {
          let KO = `${bK}\0${eO}`;
          FO.has(KO) || (FO.add(KO), OO.setEdge(bK, eO, {
            ...XO,
            width: 0,
            height: 0
          }))
        }
      }));
      let VO = gX(OO),
        LO = Lp(VO, KO, pO, null != (XO = aX.get(OO)) ? XO : null);
      aX.set(OO, LO), Qp(OO, VO), FO.forEach((KO => {
        let pO = KO.indexOf("\0"),
          XO = KO.slice(0, pO),
          bK = KO.slice(pO + 1);
        OO.hasEdge(XO, bK) && OO.removeEdge(XO, bK)
      })), lO.forEach((KO => {
        let {
          clusterId: pO,
          subgraph: XO,
          bounds: bK,
          removedNodes: eO,
          removedEdges: lO
        } = KO;
        var vK, CO;
        let hO = OO.node(pO),
          DO = null != (vK = null == hO ? void 0 : hO.x) ? vK : 0,
          MO = null != (CO = null == hO ? void 0 : hO.y) ? CO : 0,
          aK = (bK.minX + bK.maxX) / 2,
          oO = (bK.pp + bK.ep) / 2;
        eO.forEach((KO => {
          let {
            id: pO,
            node: XO,
            parent: bK
          } = KO;
          OO.setNode(pO, XO), void 0 !== bK && OO.setParent(pO, bK)
        })), lO.forEach((KO => {
          let {
            edge: pO,
            label: XO
          } = KO;
          OO.setEdge(pO, XO)
        })), XO.nodes().forEach((KO => {
          if (KO === pO) return;
          let bK = XO.node(KO),
            eO = OO.node(KO);
          eO && bK && "number" == typeof bK.x && "number" == typeof bK.y && (eO.x = DO + (bK.x - aK), eO.y = MO + (bK.y - oO))
        })), delete hO._dagreClusterSubgraph
      })), bK.forEach((KO => {
        var pO, XO;
        let bK = OO.node(KO),
          lO = eO[KO];
        if (bK && bK.rankdir && bK._dagreClusterSubgraph && lO) {
          let eO = bK._dagreClusterSubgraph,
            vK = null != (pO = bK.x) ? pO : 0,
            CO = null != (XO = bK.y) ? XO : 0,
            hO = (lO.minX + lO.maxX) / 2,
            DO = (lO.pp + lO.ep) / 2;
          eO.nodes().forEach((pO => {
            if (pO === KO) return;
            let XO = eO.node(pO),
              bK = OO.node(pO);
            if (bK && XO && "number" == typeof XO.x && "number" == typeof XO.y) {
              let OO = XO.x - hO,
                KO = XO.y - DO;
              bK.x = vK + OO, bK.y = CO + KO
            }
          })), delete bK._dagreClusterSubgraph
        }
      }))
    }

    function Lp(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
      var bK, eO;
      let lO = !1 !== (null == pO ? void 0 : pO.useDynamic),
        vK = lO && null != (bK = null == XO ? void 0 : XO.graph) ? bK : null,
        CO = lO && null != (eO = null == XO ? void 0 : XO.rawNodes) ? eO : null;
      KO("    makeSpaceForEdgeLabels", (() => function(OO) {
        let KO = OO.graph();
        KO.ranksep /= 2, OO.edges().forEach((pO => {
          var XO;
          let bK = OO.edge(pO);
          bK.minlen *= 2, "c" !== (null != (XO = bK.labelpos) ? XO : "r").toLowerCase() && ("TB" === KO.rankdir || "BT" === KO.rankdir ? bK.width += bK.labeloffset : bK.height += bK.labeloffset)
        }))
      }(OO))), KO("    removeSelfEdges", (() => function(OO) {
        OO.edges().forEach((KO => {
          if (KO.v === KO.w) {
            let pO = OO.node(KO.v);
            pO.selfEdges || (pO.selfEdges = []), pO.selfEdges.push({
              e: KO,
              label: OO.edge(KO)
            }), OO.removeEdge(KO)
          }
        }))
      }(OO))), KO("    acyclic", (() => oK(OO, vK))), KO("    nestingGraph.run", (() => HK(OO))), KO("    rank", (() => rp(cK(OO)))), KO("    injectEdgeLabelProxies", (() => function(OO) {
        OO.edges().forEach((KO => {
          let pO = OO.edge(KO);
          if (pO.width && pO.height) {
            let pO = OO.node(KO.v),
              XO = {
                rank: (OO.node(KO.w).rank - pO.rank) / 2 + pO.rank,
                e: KO
              };
            JO(OO, "edge-proxy", XO, "_ep")
          }
        }))
      }(OO))), KO("    removeEmptyRanks", (() => function(OO) {
        let KO = OO.nodes().map((KO => OO.node(KO).rank)).filter((OO => void 0 !== OO)),
          pO = xK(Math.min, KO),
          XO = [];
        OO.nodes().forEach((KO => {
          let bK = OO.node(KO).rank - pO;
          XO[bK] || (XO[bK] = []), XO[bK].push(KO)
        }));
        let bK = 0,
          eO = OO.graph().nodeRankFactor;
        Array.from(XO).forEach(((KO, pO) => {
          void 0 === KO && pO % eO !== 0 ? --bK : void 0 !== KO && bK && KO.forEach((KO => OO.node(KO).rank += bK))
        }))
      }(OO))), KO("    nestingGraph.cleanup", (() => function(OO) {
        let KO = OO.graph();
        OO.removeNode(KO.nestingRoot), delete KO.nestingRoot, OO.edges().forEach((KO => {
          OO.edge(KO).nestingEdge && OO.removeEdge(KO)
        }))
      }(OO))), KO("    normalizeRanks", (() => function(OO) {
        let KO = OO.nodes().map((KO => {
            let pO = OO.node(KO).rank;
            return void 0 === pO ? Number.MAX_VALUE : pO
          })),
          pO = xK(Math.min, KO);
        OO.nodes().forEach((KO => {
          let XO = OO.node(KO);
          Object.hasOwn(XO, "rank") && (XO.rank -= pO)
        }))
      }(OO))), KO("    assignRankMinMax", (() => function(OO) {
        let KO = 0;
        OO.nodes().forEach((pO => {
          let XO = OO.node(pO);
          XO.borderTop && (XO.minRank = OO.node(XO.borderTop).rank, XO.maxRank = OO.node(XO.borderBottom).rank, KO = Math.max(KO, XO.maxRank))
        })), OO.graph().maxRank = KO
      }(OO))), KO("    removeEdgeLabelProxies", (() => function(OO) {
        OO.nodes().forEach((KO => {
          let pO = OO.node(KO);
          if ("edge-proxy" === pO.dummy) {
            let XO = pO;
            OO.edge(XO.e).labelRank = pO.rank, OO.removeNode(KO)
          }
        }))
      }(OO))), KO("    normalize.run", (() => FK(OO))), KO("    parentDummyChains", (() => sK(OO))), KO("    addBorderSegments", (() => SK(OO))), KO("    order", (() => pp(OO, pO, CO))), KO("    insertSelfEdges", (() => function(OO) {
        ZO(OO).forEach((KO => {
          let pO = 0;
          KO.forEach(((KO, XO) => {
            let bK = OO.node(KO);
            "number" != typeof bK.rank && (bK.rank = 0), bK.order = XO + pO, (bK.selfEdges || []).forEach((KO => {
              JO(OO, "selfedge", {
                width: KO.label.width,
                height: KO.label.height,
                rank: bK.rank,
                order: XO + ++pO,
                e: KO.e,
                edgeLabel: KO.label
              }, "_se"), (!Array.isArray(KO.label.points) || 7 !== KO.label.points.length) && (KO.label.points = [{
                x: 0,
                y: -10
              }, {
                x: 0,
                y: -10
              }, {
                x: 0,
                y: 0
              }, {
                x: 0,
                y: 10
              }, {
                x: 0,
                y: 10
              }, {
                x: 0,
                y: 0
              }, {
                x: 0,
                y: 0
              }])
            })), delete bK.selfEdges
          }))
        }))
      }(OO))), KO("    adjustCoordinateSystem", (() => function(OO) {
        var KO;
        let pO = null == (KO = OO.graph().rankdir) ? void 0 : KO.toLowerCase();
        ("lr" === pO || "rl" === pO) && BK(OO)
      }(OO))), KO("    position", (() => Mp(OO, pO.corePath))), KO("    positionSelfEdges", (() => function(OO) {
        OO.nodes().forEach((KO => {
          let pO = OO.node(KO),
            XO = OO => "number" == typeof OO && isFinite(OO);
          if ("selfedge" === pO.dummy) {
            let bK = pO,
              eO = OO.node(bK.e.v),
              lO = XO(null == eO ? void 0 : eO.x) ? eO.x : 0,
              vK = XO(null == eO ? void 0 : eO.y) ? eO.y : 0,
              CO = XO(null == eO ? void 0 : eO.width) ? eO.width : 0,
              hO = XO(null == eO ? void 0 : eO.height) ? eO.height : 0,
              DO = XO(pO.x) ? pO.x : lO,
              MO = XO(pO.y) ? pO.y : vK,
              aK = CO / 2,
              oO = hO / 2;
            bK.edgeLabel.points = [{
              x: DO + aK,
              y: MO - oO
            }, {
              x: DO + aK,
              y: MO - oO
            }, {
              x: DO,
              y: MO
            }, {
              x: DO - aK,
              y: MO + oO
            }, {
              x: DO - aK,
              y: MO + oO
            }, {
              x: DO,
              y: MO
            }, {
              x: DO,
              y: MO
            }], bK.edgeLabel.x = DO, bK.edgeLabel.y = MO, OO.setEdge(bK.e, bK.edgeLabel), OO.removeNode(KO)
          } else pO && Array.isArray(pO.selfEdges) && pO.selfEdges.forEach((OO => {
            if (!Array.isArray(OO.label.points) || 7 !== OO.label.points.length) {
              let KO = XO(pO.x) ? pO.x : 0,
                bK = XO(pO.y) ? pO.y : 0,
                eO = (XO(pO.width) ? pO.width : 0) / 2,
                lO = (XO(pO.height) ? pO.height : 0) / 2;
              OO.label.points = [{
                x: KO + eO,
                y: bK - lO
              }, {
                x: KO + eO,
                y: bK - lO
              }, {
                x: KO,
                y: bK
              }, {
                x: KO - eO,
                y: bK + lO
              }, {
                x: KO - eO,
                y: bK + lO
              }, {
                x: KO,
                y: bK
              }, {
                x: KO,
                y: bK
              }]
            }
          }))
        }))
      }(OO)));
      let hO = JSON.parse(JSON.stringify(OO._nodes));
      return KO("    removeBorderNodes", (() => function(OO) {
        OO.nodes().forEach((KO => {
          if (OO.children(KO).length) {
            let pO = OO.node(KO),
              XO = OO.node(pO.borderTop),
              bK = OO.node(pO.borderBottom),
              eO = OO.node(pO.borderLeft[pO.borderLeft.length - 1]),
              lO = OO.node(pO.borderRight[pO.borderRight.length - 1]);
            pO.width = Math.abs(lO.x - eO.x), pO.height = Math.abs(bK.y - XO.y), pO.x = eO.x + pO.width / 2, pO.y = XO.y + pO.height / 2
          }
        })), OO.nodes().forEach((KO => {
          "border" === OO.node(KO).dummy && OO.removeNode(KO)
        }))
      }(OO))), KO("    normalize.undo", (() => function(OO) {
        OO.graph().dummyChains.forEach((KO => {
          let pO, XO = OO.node(KO),
            bK = XO.edgeLabel;
          for (OO.setEdge(XO.edgeObj, bK); XO.dummy;) pO = OO.successors(KO)[0], OO.removeNode(KO), bK.points.push({
            x: XO.x,
            y: XO.y
          }), "edge-label" === XO.dummy && (bK.x = XO.x, bK.y = XO.y, bK.width = XO.width, bK.height = XO.height), KO = pO, XO = OO.node(KO)
        }))
      }(OO))), KO("    fixupEdgeLabelCoords", (() => function(OO) {
        OO.edges().forEach((KO => {
          let pO = OO.edge(KO);
          if (Object.hasOwn(pO, "x")) switch (("l" === pO.labelpos || "r" === pO.labelpos) && (pO.width -= pO.labeloffset), pO.labelpos) {
            case "l":
              pO.x -= pO.width / 2 + pO.labeloffset;
              break;
            case "r":
              pO.x += pO.width / 2 + pO.labeloffset
          }
        }))
      }(OO))), KO("    undoCoordinateSystem", (() => cp(OO))), KO("    translateGraph", (() => function(OO) {
        let KO = Number.POSITIVE_INFINITY,
          pO = 0,
          XO = Number.POSITIVE_INFINITY,
          bK = 0,
          eO = OO.graph(),
          lO = eO.marginx || 0,
          vK = eO.marginy || 0;

        function CO(OO) {
          let eO = OO.x,
            lO = OO.y,
            vK = OO.width,
            CO = OO.height;
          KO = Math.min(KO, eO - vK / 2), pO = Math.max(pO, eO + vK / 2), XO = Math.min(XO, lO - CO / 2), bK = Math.max(bK, lO + CO / 2)
        }
        OO.nodes().forEach((KO => CO(OO.node(KO)))), OO.edges().forEach((KO => {
          let pO = OO.edge(KO);
          Object.hasOwn(pO, "x") && CO(pO)
        })), KO -= lO, XO -= vK, OO.nodes().forEach((pO => {
          let bK = OO.node(pO);
          bK.x -= KO, bK.y -= XO
        })), OO.edges().forEach((pO => {
          let bK = OO.edge(pO);
          bK.points.forEach((OO => {
            OO.x -= KO, OO.y -= XO
          })), Object.hasOwn(bK, "x") && (bK.x -= KO), Object.hasOwn(bK, "y") && (bK.y -= XO)
        })), eO.width = pO - KO + lO, eO.height = bK - XO + vK
      }(OO))), KO("    assignNodeIntersects", (() => function(OO) {
        OO.edges().forEach((KO => {
          if (KO.v === KO.w) return;
          let pO, XO, bK = OO.edge(KO),
            eO = OO.node(KO.v),
            lO = OO.node(KO.w);
          bK.points ? (pO = bK.points[0], XO = bK.points[bK.points.length - 1]) : (bK.points = [], pO = lO, XO = eO), bK.points.unshift(BO(eO, pO)), bK.points.push(BO(lO, XO))
        }))
      }(OO))), KO("    reversePoints", (() => function(OO) {
        OO.edges().forEach((KO => {
          let pO = OO.edge(KO);
          pO.reversed && pO.points.reverse()
        }))
      }(OO))), KO("    acyclic.undo", (() => function(OO) {
        OO.edges().forEach((KO => {
          let pO = OO.edge(KO);
          if (pO.reversed) {
            OO.removeEdge(KO);
            let XO = pO.forwardName;
            delete pO.reversed, delete pO.forwardName, OO.setEdge(KO.w, KO.v, pO, XO)
          }
        }))
      }(OO))), {
        graph: OO,
        rawNodes: hO
      }
    }

    function Qp(OO, KO) {
      OO.nodes().forEach((pO => {
        let XO = OO.node(pO),
          bK = KO.node(pO);
        XO && (XO.x = bK.x, XO.y = bK.y, XO.order = bK.order, XO.rank = bK.rank, KO.children(pO).length && (XO.width = bK.width, XO.height = bK.height))
      })), OO.edges().forEach((pO => {
        let XO = OO.edge(pO),
          bK = KO.edge(pO);
        XO.points = bK.points, Object.hasOwn(bK, "x") && (XO.x = bK.x, XO.y = bK.y)
      })), OO.graph().width = KO.graph().width, OO.graph().height = KO.graph().height
    }
    var zX = ["nodesep", "edgesep", "ranksep", "marginx", "marginy"],
      Ap = {
        ranksep: 50,
        edgesep: 20,
        nodesep: 50,
        rankdir: "TB",
        rankalign: "center"
      },
      fp = ["acyclicer", "ranker", "rankdir", "align", "rankalign"],
      dp = ["width", "height", "rank"],
      Tp = {
        width: 0,
        height: 0
      },
      Np = ["minlen", "weight", "width", "height", "labeloffset"],
      Ip = {
        minlen: 1,
        weight: 1,
        width: 0,
        height: 0,
        labeloffset: 10,
        labelpos: "r"
      },
      yX = ["labelpos"];

    function gX(OO) {
      let KO = new SO({
          multigraph: !0,
          compound: !0
        }),
        pO = Ep(OO.graph());
      return KO.setGraph(Object.assign({}, Ap, upO(pO, zX), KK(pO, fp))), OO.nodes().forEach((pO => {
        let XO = upO(Ep(OO.node(pO)), dp);
        Object.keys(Tp).forEach((OO => {
          void 0 === XO[OO] && (XO[OO] = Tp[OO])
        })), KO.setNode(pO, XO);
        let bK = OO.parent(pO);
        void 0 !== bK && KO.setParent(pO, bK)
      })), OO.edges().forEach((pO => {
        let XO = Ep(OO.edge(pO));
        KO.setEdge(pO, Object.assign({}, Ip, upO(XO, Np), KK(XO, yX)))
      })), KO
    }

    function upO(OO, KO) {
      return pK(KK(OO, KO), Number)
    }

    function Ep(OO) {
      let KO = {};
      return OO && Object.entries(OO).forEach((OO => {
        let [pO, XO] = OO;
        "string" == typeof pO && (pO = pO.toLowerCase()), KO[pO] = XO
      })), KO
    }

    function jX(OO) {
      let KO = ZO(OO),
        pO = new SO({
          compound: !0,
          multigraph: !0
        }).setGraph({});
      return OO.nodes().forEach((KO => {
        pO.setNode(KO, {
          label: KO
        }), pO.setParent(KO, "layer" + OO.node(KO).rank)
      })), OO.edges().forEach((OO => pO.setEdge(OO.v, OO.w, {}, OO.name))), KO.forEach(((OO, KO) => {
        let XO = "layer" + KO;
        pO.setNode(XO, {
          rank: "same"
        }), OO.reduce(((OO, KO) => (pO.setEdge(OO, KO, {
          style: "invis"
        }), KO)))
      })), pO
    }
    var Yp = {
        time: WO,
        notime: tK
      },
      wp = {
        graphlib: eO,
        version: eK,
        layout: op,
        debug: jX,
        util: {
          time: WO,
          notime: tK
        }
      }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);