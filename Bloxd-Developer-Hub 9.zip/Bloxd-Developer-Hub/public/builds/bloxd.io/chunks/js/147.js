export const id = 147;
export const ids = [147];
export const modules = {
  39228: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      openMobLineupPreview: () => SO,
      openMobPreview: () => RO,
      openPetPreview: () => JO
    });
    var XO = pO(37880),
      bK = pO(38162),
      eO = pO(39231),
      lO = pO(35680),
      vK = pO(35624),
      CO = pO(38338),
      hO = pO(39251),
      DO = pO(36873),
      MO = pO(35990),
      aK = pO(35959),
      oO = pO(35980),
      FO = pO(36770),
      VO = pO(36764),
      LO = pO(36516),
      QO = pO(36553),
      zK = pO(36532),
      AO = pO(36155),
      fO = pO(2231),
      dO = pO(35952);
    pO(39254), pO(38587), pO(39261);
    const TO = 22,
      NO = 13,
      IO = Math.PI - Math.PI / 16,
      yK = 6,
      gK = Math.PI / 4;
    let uO = null;
    const EO = {},
      jK = new Map;

    function YO() {
      if (null !== uO) return uO;
      const OO = document.createElement("canvas");
      OO.classList.add("MobPreviewCanvas");
      const KO = new XO.d(OO, !0, {
        preserveDrawingBuffer: !0
      });
      KO.BhO = (0, fO.d)().Lb.engine.BhO;
      const pO = new bK.d(KO);
      pO.clearColor = new lO.c(0, 0, 0, 0), pO.ambientColor = new lO.Color3(1, 1, 1);
      const hO = new eO.c("xv", Math.PI / 2, Math.PI / 2, TO, vK.WX.Zero(), pO),
        DO = new CO.b("light", new vK.WX(-.1, 1, -.3), pO);
      return DO.diffuse = new lO.Color3(1, 1, 1), DO.specular = new lO.Color3(1, 1, 1), DO.groundColor = new lO.Color3(.5, .5, .5), uO = {
        engine: KO,
        Ce: pO,
        canvas: OO,
        camera: hO
      }, uO
    }

    function wO(OO) {
      return EO[OO] ??= (0, LO.u)(OO, YO().Ce, !0).catch((KO => {
        throw delete EO[OO], KO
      })), EO[OO]
    }

    function iK(OO) {
      let KO = jK.get(OO);
      return KO || (KO = AO.G[OO].loadModel(YO().Ce, !1).then((OO => (OO.WE(!1), OO)), (KO => {
        throw jK.delete(OO), KO
      })), jK.set(OO, KO)), KO
    }

    function rK(OO) {
      var KO, pO, XO;
      let {
        mobType: bK,
        variation: eO,
        animation: lO
      } = OO, CO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, TO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
      const yK = null !== (KO = null === CO || void 0 === CO ? void 0 : CO.size) && void 0 !== KO ? KO : 1,
        gK = null !== (pO = null === CO || void 0 === CO ? void 0 : CO.cosmetics) && void 0 !== pO ? pO : [],
        uO = null !== (XO = null === CO || void 0 === CO ? void 0 : CO.XE) && void 0 !== XO ? XO : null;
      let EO = !1,
        jK = null,
        rK = null;
      const {
        engine: PO,
        Ce: mK
      } = YO(), sO = mK.onBeforeRenderObservable.add((() => {
        var OO;
        null === (OO = rK) || void 0 === OO || OO.render(PO.getDeltaTime())
      })), HO = null === uO ? null : iK(uO).catch((OO => (console.error(`Mob preview: could not load ${uO}`, OO), null)));
      return Promise.all([wO(bK), HO]).then((OO => {
        var KO, pO, XO;
        let [CO, wO] = OO;
        if (EO) return;
        const iK = (0, fO.d)().Lb.ZKO,
          {
            hitBoxDimensions: PO
          } = (0, DO.c)(bK),
          mK = NO / Math.max(PO.height, PO.width);
        if (jK = (0, LO.g)(bK, mK * yK, !0, !0), iK.setPosition(jK, TO, -PO.height * mK / 2, 0), iK.setRotationEulerY(jK, IO), CO.meshApi instanceof zK.c && gK.length > 0)
          for (const [bK, eO] of gK) CO.meshApi.updatePlayerCosmetic(null, jK, bK, eO, !0);
        else CO.meshApi.updateVariation(jK, bK, null !== eO && void 0 !== eO ? eO : "default");
        null !== uO && null !== wO && function(OO, KO, pO, XO) {
          var bK;
          const eO = AO.G[OO],
            lO = (0, FO.m)();
          (0, FO.h)(eO, null === (bK = (0, QO.d)(pO).meshMetadata.heldItemPositionParams) || void 0 === bK ? void 0 : bK.itemOffset, lO);
          const CO = dO.e * lO.ol.y,
            DO = lO.usesQuaternion ? lO.quaternion : vK.Quaternion.FromEulerVector(lO.rotation),
            MO = new hO.c(`${KO.name}Hand`, YO().Ce);
          MO.position.NhO((0, VO.e)(lO.position, DO, CO, eO.heldModelOffsetY())), MO.rotationQuaternion = DO, MO.ol.set(lO.ol.x, CO, lO.ol.z), KO.clone(`${KO.name}Held`, MO).WE(!0);
          const aK = (0, fO.d)().Lb.ZKO;
          aK.attachTransformNode(MO, XO, aK.getNamedNode(XO, "ArmRightMesh"))
        }(uO, wO, bK, jK), iK.set(jK, "aOpacity", 1);
        const sO = null !== (KO = (0, QO.d)(bK).meshMetadata.lifeformTypeForModelOverride) && void 0 !== KO ? KO : bK;
        rK = new oO.AnimatorState, rK.thinInstMgr = iK, rK.GKO = jK, rK.dhO = iK.ZhO(jK, 0), rK.modelLifeformType = sO, rK.nodeNameAliases = null !== (pO = null === (XO = (0, MO.b)(sO)) || void 0 === XO ? void 0 : XO.nodeNameAliases) && void 0 !== pO ? pO : null, rK.startAnimation(lO, aK.f.Movement)
      })).catch((OO => {
        console.error(`Mob preview: could not load ${bK}`, OO)
      })), () => {
        EO = !0, mK.onBeforeRenderObservable.remove(sO), null !== jK && (0, fO.d)().Lb.ZKO.delete(jK)
      }
    }

    function PO(OO, KO) {
      return rK({
        mobType: "NPC",
        variation: null,
        animation: OO.animation
      }, OO, KO)
    }

    function mK(OO) {
      let {
        mobType: KO,
        variation: pO,
        metaInfo: XO,
        tamed: bK
      } = OO, eO = !1, lO = null, vK = 0;
      const CO = (0, fO.d)(),
        hO = CO.Lb.ZKO,
        DO = OO => {
          vK += gK * (OO / 1e3) % (2 * Math.PI), hO.setRotationEulerY(lO, vK)
        };
      return wO(KO).then((OO => {
        if (eO) return;
        lO = (0, LO.g)(KO, yK, !0, !0), hO.setPosition(lO, 0, -yK, 0), OO.meshApi.updateVariation(lO, KO, pO);
        const vK = {
          wool: "Sheared" !== XO,
          saddle: "Saddled" === XO,
          antlers: "Antlers" === XO,
          collar: bK
        };
        for (const [KO, pO] of Object.entries(vK)) hO.hasGroup(lO, KO) && OO.meshApi.setMeshGroupVisibility(lO, KO, pO);
        hO.set(lO, "aOpacity", 1), CO.on("renderTickBegin", DO)
      })).catch((OO => {
        console.error(`Pet preview: could not load ${KO}`, OO)
      })), () => {
        eO = !0, CO.off("renderTickBegin", DO), null !== lO && hO.delete(lO)
      }
    }
    class sO {
      constructor(OO, KO) {
        this.place = KO, this.remove = null;
        const {
          engine: pO,
          Ce: XO,
          canvas: bK
        } = YO();
        OO.appendChild(bK), pO.resize(), pO.runRenderLoop((() => {
          XO.render()
        }))
      }
      show(OO) {
        var KO;
        null === (KO = this.remove) || void 0 === KO || KO.call(this), this.remove = this.place(OO)
      }
      resize(OO, KO) {
        const {
          engine: pO,
          canvas: XO
        } = YO();
        XO.width = OO, XO.height = KO, pO.resize()
      }
      close() {
        var OO;
        YO().engine.stopRenderLoop(), null === (OO = this.remove) || void 0 === OO || OO.call(this), this.remove = null
      }
    }
    class HO {
      constructor(OO) {
        this.preview = void 0, this.view = {
          figures: [],
          shown: []
        }, this.aspect = 1, this.placed = [], this.preview = new sO(OO, (() => () => {}))
      }
      show(OO) {
        OO.figures !== this.view.figures && this.preload(OO.figures), this.view = OO, this.place()
      }
      resize(OO, KO) {
        this.preview.resize(OO, KO), this.aspect = OO / KO, this.place()
      }
      close() {
        this.preview.close();
        for (const OO of this.placed) null === OO || void 0 === OO || OO.remove();
        this.placed = []
      }
      preload(OO) {
        const KO = () => {};
        wO("NPC").catch(KO);
        for (const {
            XE: pO
          }
          of OO) null !== pO && iK(pO).catch(KO)
      }
      place() {
        const {
          figures: OO,
          shown: KO
        } = this.view, pO = OO.map(((pO, XO) => {
          var bK;
          const eO = null !== (bK = this.placed[XO]) && void 0 !== bK ? bK : null;
          if (!KO[XO]) return null === eO || void 0 === eO || eO.remove(), null;
          const lO = (vK = (XO + .5) / OO.length, CO = this.aspect, (.5 - vK) * (2 * TO * Math.tan(YO().camera.fov / 2)) * CO);
          var vK, CO;
          return null !== eO && eO.figure === pO && eO.x === lO ? eO : (null === eO || void 0 === eO || eO.remove(), {
            figure: pO,
            x: lO,
            remove: PO(pO, lO)
          })
        }));
        for (const XO of this.placed.slice(OO.length)) null === XO || void 0 === XO || XO.remove();
        this.placed = pO
      }
    }

    function RO(OO) {
      return new sO(OO, rK)
    }

    function SO(OO) {
      return new HO(OO)
    }

    function JO(OO) {
      return new sO(OO, mK)
    }
  },
  37168: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => aK
    });
    var XO = pO(35545),
      bK = pO(35559),
      eO = pO(35774),
      lO = pO(35568),
      vK = pO(35552);

    function CO(OO) {
      return `\n\t\t\t\t${(0,vK.D)(OO,"mat2","rotate",[{name:"ang",type:"float"}],`\
      n\ t\ t\ t\ t\ t$ {
        (0, vK.I)(OO, "float", "s", "sin(ang)")
      }\
      n\ t\ t\ t\ t\ t$ {
        (0, vK.I)(OO, "float", "c", "cos(ang)")
      }\
      n\ t\ t\ t\ t\ treturn $ {
        (0, vK.q)(OO, "mat2", "c", "s", "-s", "c")
      };\
      n\ t\ t\ t\ t`)}\n\t\t\t`
    }

    function hO(OO, KO) {
      let pO = (0, vK.Cb)(OO, "skele" + (KO - 1));
      for (let bK = KO - 2; bK >= 0; bK--) pO = (0, vK.tb)(OO, `boneIdx == ${bK}`, (0, vK.Cb)(OO, `skele${bK}`), pO);
      const XO = "bone.yz + rotate(bone.x) * pivot - pivot";
      return `\n\t\t\t\t${(0,vK.I)(OO,"int","boneIdx",(0,vK.zb)(OO,"BLOXD_CAPE_MAX_Y - positionUpdated.y"))}\n\t\t\t\t${(0,vK.I)(OO,"vec3","bone",pO)}\n\t\t\t\t${(0,vK.I)(OO,"vec2","pivot",(0,vK.q)(OO,"vec2","0.0",`${(0,vK.Lb)(OO,"position")}.z`))}\n\t\t\t\t${(0,vK.cb)(OO)?`positionUpdated = vec3f(positionUpdated.x, positionUpdated.yz + (${XO}));`:`positionUpdated.yz += ${XO};`}\n\t\t`
    }

    function DO(OO) {
      return `\n\t\t\t\t#ifdef NORMAL\n\t\t\t\tnormalUpdated = ${(0,vK.q)(OO,"vec3","normalUpdated.x","rotate(bone.x) * normalUpdated.yz")};\n\t\t\t\t#endif\n\t\t`
    }
    const MO = {
        x: 0,
        y: 0,
        z: 0,
        BCO(OO, KO) {
          return this.x = OO[KO], this.y = OO[KO + 1], this.z = OO[KO + 2], this
        }
      },
      aK = {
        name: "Cape",
        className: "CapeMaterialPlugin",
        priority: 200,
        defines: (OO, KO) => ({
          ...(0, XO.e)("CAPE"),
          BLOXD_CAPE_BONES: `${OO}`,
          BLOXD_CAPE_MAX_Y: (0, bK.kb)(KO)
        }),
        getUniforms(OO) {
          return (0, eO.e)(function(OO) {
            const KO = [];
            for (let pO = 0; pO < OO; pO++) KO.push({
              name: `skele${pO}`,
              type: "highp vec3"
            });
            return KO
          }(this.skeleLen), "vertex", OO)
        },
        bind(OO) {
          for (let KO = 0; KO < this.skeleLen; KO++) OO.updateVector3(`skele${KO}`, MO.BCO(this.skele, 3 * KO))
        },
        uniformsVersion() {
          return this.bonesVersion
        },
        getCustomCode(OO, KO) {
          return "vertex" !== OO ? null : {
            CUSTOM_VERTEX_DEFINITIONS: CO(KO),
            CUSTOM_VERTEX_UPDATE_POSITION: hO(KO, this.skeleLen),
            CUSTOM_VERTEX_UPDATE_NORMAL: DO(KO)
          }
        }
      };
    (0, lO.k)(aK)
  },
  37070: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      h: () => MO
    });
    var XO = pO(35545),
      bK = pO(35774),
      eO = pO(35552),
      lO = pO(35568);
    const vK = "bloxdTextLodBias",
      CO = [{
        name: vK,
        type: "float"
      }],
      hO = "bloxdTextSample",
      DO = {
        planes: -.5,
        boards: -.5
      },
      MO = {
        name: "TextSampler",
        className: "TextSamplerMaterialPlugin",
        priority: 60,
        defines: () => (0, XO.e)("TEXT_SAMPLER"),
        getUniforms: OO => (0, bK.e)(CO, "fragment", OO),
        bind(OO) {
          OO.updateFloat(vK, this.lodBias)
        },
        uniformsVersion: () => 0,
        getCustomCode(OO, KO) {
          if ("fragment" !== OO) return null;
          const pO = (0, eO.R)(KO, `vec4 ${hO}(sampler2D s, vec2 uv, float bias)`, `fn ${hO}(t: texture_2d<f32>, ts: sampler, uv: vec2f, bias: f32) -> vec4f`),
            XO = (0, eO.R)(KO, "texture2D(s, uv, bias)", "textureSampleBias(t, ts, uv, bias)"),
            bK = `${(0,eO._)(KO,"vDiffuseUV")} + uvOffset`,
            lO = (0, eO.R)(KO, `${hO}(diffuseSampler, ${bK}, ${(0,eO.Cb)(KO,vK)})`, `${hO}(diffuseSampler, diffuseSamplerSampler, ${bK}, ${(0,eO.Cb)(KO,vK)})`);
          return {
            CUSTOM_FRAGMENT_DEFINITIONS: `\n\t\t\t\t${pO} {\n\t\t\t\t\t${(0,eO.I)(KO,"vec4","texel",XO)}\n\t\t\t\t\t// 8-bit premultiplied rounding can put the quotient just over 1; only alpha 0 hits the floor,\n\t\t\t\t\t// where the colour is 0 anyway.\n\t\t\t\t\treturn ${(0,eO.q)(KO,"vec4",`clamp(texel.rgb / max(texel.a, 1.0 / 255.0), ${(0,eO.q)(KO,"vec3","0.0")}, ${(0,eO.q)(KO,"vec3","1.0")})`,"texel.a")};\n\t\t\t\t}\n\t\t\t`,
            [(0, eO.M)(KO)]: `baseColor = ${lO};`
          }
        }
      };
    (0, lO.k)(MO)
  },
  7899: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      h: () => vK,
      l: () => CO
    });
    var XO = pO(1803),
      bK = pO(1098),
      eO = pO(1811);
    const lO = ",";

    function vK(OO) {
      if (!OO) return [];
      const KO = new Set,
        pO = [];
      for (const XO of OO.split(lO)) {
        const OO = XO.trim();
        if ((0, eO.n)(OO) && !KO.has(OO) && (KO.add(OO), pO.push(OO), pO.length >= bK.m)) break
      }
      return pO
    }

    function CO(OO) {
      const KO = new Set,
        pO = [];
      for (const XO of OO)
        if ((0, eO.n)(XO) && !KO.has(XO) && (KO.add(XO), pO.push(XO), pO.length >= bK.m)) break;
      return pO.join(lO)
    }

    function hO() {
      return CO(eO.g)
    }

    function DO(OO) {
      var KO;
      return "emote" === OO ? hO() : null !== (KO = MO[OO][0]) && void 0 !== KO ? KO : aK[OO]
    }
    const MO = bK.w.reduce(((OO, KO) => {
        const pO = [];
        for (const eO in XO.d[KO]) {
          var bK;
          "default" === (null === (bK = (0, XO.j)(KO, eO)) || void 0 === bK ? void 0 : bK.cosmeticPack) && pO.push(eO)
        }
        return OO[KO] = pO, OO
      }), {}),
      aK = bK.w.reduce(((OO, KO) => (OO[KO] = Object.keys(XO.d[KO])[0], OO)), {})
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);