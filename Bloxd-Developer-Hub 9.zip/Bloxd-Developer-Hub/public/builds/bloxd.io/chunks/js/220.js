export const id = 220;
export const ids = [220, 221];
export const modules = {
  38343: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      h: () => aK
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35632),
      lO = pO(35688),
      vK = pO(38347),
      CO = pO(38301),
      hO = pO(35676);
    let DO = (() => {
        var OO;
        let KO, pO, CO = vK.b,
          hO = [],
          DO = [],
          MO = [],
          aK = [];
        return OO = class extends CO {
          constructor(OO, KO, pO, bK) {
            super(OO, pO, bK), this.groundColor = (0, XO.i)(this, hO, new lO.e(0, 0, 0)), this.direction = ((0, XO.i)(this, DO), (0, XO.i)(this, MO, void 0)), (0, XO.i)(this, aK), this.direction = KO || eO.o.Up()
          }
          _buildUniformLayout() {
            this._uniformBuffer.addUniform("vLightData", 4), this._uniformBuffer.addUniform("vLightDiffuse", 4), this._uniformBuffer.addUniform("vLightSpecular", 4), this._uniformBuffer.addUniform("vLightGround", 3), this._uniformBuffer.addUniform("shadowsInfo", 3), this._uniformBuffer.addUniform("depthValues", 2), this._uniformBuffer.create()
          }
          getClassName() {
            return "HemisphericLight"
          }
          setDirectionToTarget(OO) {
            return this.direction = eO.o.Normalize(OO.subtract(eO.o.Zero())), this.direction
          }
          getShadowGenerator() {
            return null
          }
          transferToEffect(OO, KO) {
            const pO = eO.o.Normalize(this.direction);
            return this._uniformBuffer.updateFloat4("vLightData", pO.x, pO.y, pO.z, 0, KO), this._uniformBuffer.updateColor3("vLightGround", this.groundColor.scale(this.intensity), KO), this
          }
          transferToNodeMaterialEffect(OO, KO) {
            const pO = eO.o.Normalize(this.direction);
            return OO.setFloat3(KO, pO.x, pO.y, pO.z), this
          }
          computeWorldMatrix() {
            return this._worldMatrix || (this._worldMatrix = eO.c.Identity()), this._worldMatrix
          }
          getTypeID() {
            return vK.b.LIGHTTYPEID_HEMISPHERICLIGHT
          }
          prepareLightSpecificDefines(OO, KO) {
            OO["HEMILIGHT" + KO] = !0
          }
        }, (() => {
          const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(CO[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.r)()], pO = [(0, bK.L)()], (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "groundColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "groundColor" in OO,
              get: OO => OO.groundColor,
              set: (OO, KO) => {
                OO.groundColor = KO
              }
            },
            metadata: eO
          }, hO, DO), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "direction",
            static: !1,
            private: !1,
            access: {
              has: OO => "direction" in OO,
              get: OO => OO.direction,
              set: (OO, KO) => {
                OO.direction = KO
              }
            },
            metadata: eO
          }, MO, aK), eO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: eO
          })
        })(), OO
      })(),
      MO = !1;

    function aK() {
      MO || (MO = !0, CO.c.AddNodeConstructor("Light_Type_3", ((OO, KO) => () => new DO(OO, eO.o.Zero(), KO))), (0, hO.h)("BABYLON.HemisphericLight", DO))
    }
  },
  36142: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(36146);
    class bK {
      static GetPlanes(OO) {
        const KO = [];
        for (let pO = 0; pO < 6; pO++) KO.push(new XO.d(0, 0, 0, 0));
        return bK.GetPlanesToRef(OO, KO), KO
      }
      static GetNearPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[2], KO.normal.y = pO[7] + pO[6], KO.normal.z = pO[11] + pO[10], KO.d = pO[15] + pO[14], KO.normalize()
      }
      static GetFarPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[2], KO.normal.y = pO[7] - pO[6], KO.normal.z = pO[11] - pO[10], KO.d = pO[15] - pO[14], KO.normalize()
      }
      static GetLeftPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[0], KO.normal.y = pO[7] + pO[4], KO.normal.z = pO[11] + pO[8], KO.d = pO[15] + pO[12], KO.normalize()
      }
      static GetRightPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[0], KO.normal.y = pO[7] - pO[4], KO.normal.z = pO[11] - pO[8], KO.d = pO[15] - pO[12], KO.normalize()
      }
      static GetTopPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[1], KO.normal.y = pO[7] - pO[5], KO.normal.z = pO[11] - pO[9], KO.d = pO[15] - pO[13], KO.normalize()
      }
      static GetBottomPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[1], KO.normal.y = pO[7] + pO[5], KO.normal.z = pO[11] + pO[9], KO.d = pO[15] + pO[13], KO.normalize()
      }
      static GetPlanesToRef(OO, KO) {
        bK.GetNearPlaneToRef(OO, KO[0]), bK.GetFarPlaneToRef(OO, KO[1]), bK.GetLeftPlaneToRef(OO, KO[2]), bK.GetRightPlaneToRef(OO, KO[3]), bK.GetTopPlaneToRef(OO, KO[4]), bK.GetBottomPlaneToRef(OO, KO[5])
      }
      static IsPointInFrustum(OO, KO) {
        for (let pO = 0; pO < 6; pO++)
          if (KO[pO].dotCoordinate(OO) < 0) return !1;
        return !0
      }
    }
  },
  36146: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK
    });
    var XO = pO(35632);
    class bK {
      constructor(OO, KO, pO, bK) {
        this.normal = new XO.o(OO, KO, pO), this.d = bK
      }
      WhO() {
        return [this.normal.x, this.normal.y, this.normal.z, this.d]
      }
      clone() {
        return new bK(this.normal.x, this.normal.y, this.normal.z, this.d)
      }
      getClassName() {
        return "Plane"
      }
      getHashCode() {
        let OO = this.normal.getHashCode();
        return OO = 397 * OO ^ this.d, OO
      }
      normalize() {
        const OO = Math.sqrt(this.normal.x * this.normal.x + this.normal.y * this.normal.y + this.normal.z * this.normal.z);
        let KO = 0;
        return 0 !== OO && (KO = 1 / OO), this.normal.x *= KO, this.normal.y *= KO, this.normal.z *= KO, this.d *= KO, this
      }
      transform(OO) {
        const KO = bK._TmpMatrix;
        OO.invertToRef(KO);
        const pO = KO.m,
          XO = this.normal.x,
          eO = this.normal.y,
          lO = this.normal.z,
          vK = this.d,
          CO = XO * pO[0] + eO * pO[1] + lO * pO[2] + vK * pO[3],
          hO = XO * pO[4] + eO * pO[5] + lO * pO[6] + vK * pO[7],
          DO = XO * pO[8] + eO * pO[9] + lO * pO[10] + vK * pO[11],
          MO = XO * pO[12] + eO * pO[13] + lO * pO[14] + vK * pO[15];
        return new bK(CO, hO, DO, MO)
      }
      dotCoordinate(OO) {
        return this.normal.x * OO.x + this.normal.y * OO.y + this.normal.z * OO.z + this.d
      }
      copyFromPoints(OO, KO, pO) {
        const XO = KO.x - OO.x,
          bK = KO.y - OO.y,
          eO = KO.z - OO.z,
          lO = pO.x - OO.x,
          vK = pO.y - OO.y,
          CO = pO.z - OO.z,
          hO = bK * CO - eO * vK,
          DO = eO * lO - XO * CO,
          MO = XO * vK - bK * lO,
          aK = Math.sqrt(hO * hO + DO * DO + MO * MO);
        let oO;
        return oO = 0 !== aK ? 1 / aK : 0, this.normal.x = hO * oO, this.normal.y = DO * oO, this.normal.z = MO * oO, this.d = -(this.normal.x * OO.x + this.normal.y * OO.y + this.normal.z * OO.z), this
      }
      isFrontFacingTo(OO, KO) {
        return XO.o.Dot(this.normal, OO) <= KO
      }
      signedDistanceTo(OO) {
        return XO.o.Dot(OO, this.normal) + this.d
      }
      static FromArray(OO) {
        return new bK(OO[0], OO[1], OO[2], OO[3])
      }
      static FromPoints(OO, KO, pO) {
        const XO = new bK(0, 0, 0, 0);
        return XO.copyFromPoints(OO, KO, pO), XO
      }
      static FromPositionAndNormal(OO, KO) {
        const pO = new bK(0, 0, 0, 0);
        return this.FromPositionAndNormalToRef(OO, KO, pO)
      }
      static FromPositionAndNormalToRef(OO, KO, pO) {
        return pO.normal.NhO(KO), pO.normal.normalize(), pO.d = -OO.dot(pO.normal), pO
      }
      static SignedDistanceToPlaneFromPositionAndNormal(OO, KO, pO) {
        const bK = -(KO.x * OO.x + KO.y * OO.y + KO.z * OO.z);
        return XO.o.Dot(pO, KO) + bK
      }
    }
    bK._TmpMatrix = XO.c.Identity()
  },
  36513: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    class XO {
      constructor(OO, KO, pO, XO) {
        this.x = OO, this.y = KO, this.width = pO, this.height = XO
      }
      toGlobal(OO, KO) {
        return new XO(this.x * OO, this.y * KO, this.width * OO, this.height * KO)
      }
      toGlobalToRef(OO, KO, pO) {
        return pO.x = this.x * OO, pO.y = this.y * KO, pO.width = this.width * OO, pO.height = this.height * KO, this
      }
      clone() {
        return new XO(this.x, this.y, this.width, this.height)
      }
    }
  },
  37055: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(37061);
    const bK = (OO, KO, pO) => OO ? OO.getClassName && "Mesh" === OO.getClassName() ? null : !OO.getClassName || "SubMesh" !== OO.getClassName() && "PhysicsBody" !== OO.getClassName() ? OO.clone ? OO.clone() : Array.isArray(OO) ? OO.slice() : pO && "object" === typeof OO ? {
      ...OO
    } : null : OO.clone(KO) : null;
    class eO {
      static DeepCopy(OO, KO, pO, eO) {
        let lO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        const vK = function(OO) {
          const KO = [];
          do {
            const pO = Object.getOwnPropertyNames(OO);
            for (const OO of pO) - 1 === KO.indexOf(OO) && KO.push(OO)
          } while (OO = Object.getPrototypeOf(OO));
          return KO
        }(OO);
        for (const hO of vK) {
          if ("_" === hO[0] && (!eO || -1 === eO.indexOf(hO))) continue;
          if (hO.endsWith("Observable")) continue;
          if (pO && -1 !== pO.indexOf(hO)) continue;
          const vK = OO[hO],
            DO = typeof vK;
          if ("function" !== DO) try {
            if ("object" === DO)
              if (vK instanceof Uint8Array) KO[hO] = Uint8Array.from(vK);
              else if (vK instanceof Array) {
              if (KO[hO] = [], vK.length > 0)
                if ("object" == typeof vK[0])
                  for (let OO = 0; OO < vK.length; OO++) {
                    const pO = bK(vK[OO], KO, lO); - 1 === KO[hO].indexOf(pO) && KO[hO].push(pO)
                  } else KO[hO] = vK.slice(0)
            } else KO[hO] = bK(vK, KO, lO);
            else KO[hO] = vK
          } catch (CO) {
            XO.b.Warn(CO.message)
          }
        }
      }
    }
  },
  36274: (OO, KO, pO) => {
    function XO() {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (OO => {
        const KO = 16 * Math.random() | 0;
        return ("x" === OO ? KO : 3 & KO | 8).toString(16)
      }))
    }
    pO.d(KO, {
      b: () => XO
    })
  },
  37061: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      static _CheckLimit(OO, KO) {
        let pO = XO._LogLimitOutputs[OO];
        return pO ? pO.current++ : (pO = {
          limit: KO,
          current: 1
        }, XO._LogLimitOutputs[OO] = pO), pO.current <= pO.limit
      }
      static _GenerateLimitMessage(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        const pO = XO._LogLimitOutputs[OO];
        if (!pO || !XO.MessageLimitReached) return;
        const bK = this._Levels[KO];
        pO.current === pO.limit && XO[bK.name](XO.MessageLimitReached.replace(/%LIMIT%/g, "" + pO.limit).replace(/%TYPE%/g, bK.name ?? ""))
      }
      static _AddLogEntry(OO) {
        XO._LogCache = OO + XO._LogCache, XO.OnNewCacheEntry && XO.OnNewCacheEntry(OO)
      }
      static _FormatMessage(OO) {
        const KO = OO => OO < 10 ? "0" + OO : "" + OO,
          pO = new Date;
        return "[" + KO(pO.getHours()) + ":" + KO(pO.getMinutes()) + ":" + KO(pO.getSeconds()) + "]: " + OO
      }
      static _LogDisabled(OO, KO) {}
      static _LogEnabled() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const bK = Array.isArray(KO) ? KO[0] : KO;
        if (void 0 !== pO && !XO._CheckLimit(bK, pO)) return;
        const eO = XO._FormatMessage(bK),
          lO = this._Levels[OO],
          vK = Array.isArray(KO) ? KO.slice(1) : [];
        lO.logFunc && lO.logFunc("BJS - " + eO, ...vK);
        const CO = `<div style='color:${lO.color}'>${eO}</div><br>`;
        XO._AddLogEntry(CO), XO._GenerateLimitMessage(bK, OO)
      }
      static get LogCache() {
        return XO._LogCache
      }
      static ClearLogCache() {
        XO._LogCache = "", XO._LogLimitOutputs = {}, XO.errorsCount = 0
      }
      static set LogLevels(OO) {
        XO.Log = XO._LogDisabled, XO.Warn = XO._LogDisabled, XO.Error = XO._LogDisabled;
        const KO = [XO.MessageLogLevel, XO.WarningLogLevel, XO.ErrorLogLevel];
        for (const pO of KO)
          if ((OO & pO) === pO) {
            const OO = this._Levels[pO];
            XO[OO.name] = XO._LogEnabled.bind(XO, pO)
          }
      }
    }
    XO.NoneLogLevel = 0, XO.MessageLogLevel = 1, XO.WarningLogLevel = 2, XO.ErrorLogLevel = 4, XO.AllLogLevel = 7, XO.MessageLimitReached = "Too many %TYPE%s (%LIMIT%), no more %TYPE%s will be reported for this message.", XO._LogCache = "", XO._LogLimitOutputs = {}, XO._Levels = [{}, {
      color: "white",
      logFunc: console.log,
      name: "Log"
    }, {
      color: "orange",
      logFunc: console.warn,
      name: "Warn"
    }, {}, {
      color: "red",
      logFunc: console.error,
      name: "Error"
    }], XO.errorsCount = 0, XO.Log = XO._LogEnabled.bind(XO, XO.MessageLogLevel), XO.Warn = XO._LogEnabled.bind(XO, XO.WarningLogLevel), XO.Error = XO._LogEnabled.bind(XO, XO.ErrorLogLevel)
  },
  59059: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      CreateScreenshot: () => mK,
      CreateScreenshotAsync: () => sO,
      CreateScreenshotForFrameGraphAsync: () => JO,
      CreateScreenshotUsingRenderTarget: () => RO,
      CreateScreenshotUsingRenderTargetAsync: () => SO,
      CreateScreenshotWithResizeAsync: () => HO,
      RegisterScreenshotTools: () => GO,
      ScreenshotTools: () => BO
    });
    var XO = pO(38580),
      bK = pO(39833),
      eO = pO(39812),
      lO = pO(38077),
      vK = pO(39819),
      CO = pO(35653),
      hO = pO(35632);
    class DO extends vK.e {
      static _GetDefines(OO) {
        if (!OO) return null;
        return OO.extractDriverInfo().toLowerCase().indexOf("mali") > -1 ? "#define MALI 1\n" : null
      }
      _gatherImports(OO, KO) {
        OO ? (this._webGPUReady = !0, KO.push(Promise.all([pO.e(355).then((() => pO(59398))), pO.e(356).then((() => pO(59402)))]))) : KO.push(Promise.all([pO.e(357).then((() => pO(59411))), pO.e(358).then((() => pO(59417)))]))
      }
      constructor(OO) {
        const KO = {
          ...arguments.length > 2 ? arguments[2] : void 0,
          name: OO,
          engine: (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null) || CO.c.LastCreatedEngine,
          useShaderStore: !0,
          useAsPostProcess: !0,
          vertexShader: DO.VertexUrl,
          fragmentShader: DO.FragmentUrl,
          uniforms: DO.Uniforms
        };
        super({
          ...KO,
          defines: DO._GetDefines(KO.engine)
        }), this.texelSize = new hO.m(0, 0)
      }
      bind() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        super.bind(OO), this._drawWrapper.effect.setFloat2("texelSize", this.texelSize.x, this.texelSize.y)
      }
    }
    DO.VertexUrl = "fxaa", DO.FragmentUrl = "fxaa", DO.Uniforms = ["texelSize"];
    class MO extends eO.d {
      getClassName() {
        return "FxaaPostProcess"
      }
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          bK = arguments.length > 3 ? arguments[3] : void 0,
          eO = arguments.length > 4 ? arguments[4] : void 0,
          lO = arguments.length > 5 ? arguments[5] : void 0,
          vK = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0;
        const CO = {
          uniforms: DO.Uniforms,
          size: "number" === typeof KO ? KO : void 0,
          camera: pO,
          samplingMode: bK || XO.e.BILINEAR_SAMPLINGMODE,
          engine: eO,
          reusable: lO,
          textureType: vK,
          ...KO
        };
        super(OO, DO.FragmentUrl, {
          effectWrapper: "number" !== typeof KO && KO.effectWrapper ? void 0 : new DO(OO, eO, CO),
          ...CO
        }), this.onApplyObservable.add((OO => {
          this._effectWrapper.texelSize = this.texelSize
        }))
      }
      static _Parse(OO, KO, pO, XO) {
        return lO.c.Parse((() => new MO(OO.name, OO.options, KO, OO.renderTargetSamplingMode, pO.qb(), OO.reusable)), OO, pO, XO)
      }
    }
    var aK = pO(37061),
      oO = pO(38172),
      FO = pO(39846),
      VO = pO(39827),
      LO = pO(37955);
    const QO = 0;
    class zK {
      constructor(OO, KO, pO) {
        this.name = OO, this._parentTask = KO, this._context = pO, this.disabled = !1
      }
      setInitializeFunc(OO) {
        this._initFunc = OO
      }
      setExecuteFunc(OO) {
        this._executeFunc = OO
      }
      _execute() {
        this.disabled || this._executeFunc(this._context)
      }
      _initialize() {
        this._initFunc?.(this._context)
      }
      _isValid() {
        return void 0 !== this._executeFunc ? null : "Execute function is not set (call setExecuteFunc to set it)"
      }
      _dispose() {}
    }
    class AO extends zK {
      static IsObjectListPass(OO) {
        return void 0 !== OO.setObjectList
      }
      get objectList() {
        return this._objectList
      }
      setObjectList(OO) {
        this._objectList = OO
      }
      constructor(OO, KO, pO, XO) {
        super(OO, KO, pO), this._engine = XO
      }
      _isValid() {
        const OO = super._isValid();
        return OO || (void 0 !== this._objectList ? null : "Object list is not set (call setObjectList to set it)")
      }
    }
    class fO extends zK {
      static IsRenderPass(OO) {
        return void 0 !== OO.setRenderTarget
      }
      get renderTarget() {
        return this._renderTarget
      }
      get renderTargetDepth() {
        return this._renderTargetDepth
      }
      get frameGraphRenderTarget() {
        return this._frameGraphRenderTarget
      }
      constructor(OO, KO, pO, XO) {
        super(OO, KO, pO), this._dependencies = new Set, this.depthReadOnly = !1, this.stencilReadOnly = !1, this._engine = XO
      }
      setRenderTarget(OO) {
        this._renderTarget = OO
      }
      setRenderTargetDepth(OO) {
        this._renderTargetDepth = OO
      }
      addDependencies(OO) {
        if (void 0 !== OO)
          if (Array.isArray(OO))
            for (const KO of OO) this._dependencies.add(KO);
          else this._dependencies.add(OO)
      }
      collectDependencies(OO) {
        const KO = this._dependencies.keys();
        for (let pO = KO.next(); !0 !== pO.done; pO = KO.next()) OO.add(pO.value);
        if (void 0 !== this._renderTarget)
          if (Array.isArray(this._renderTarget))
            for (const pO of this._renderTarget) void 0 !== pO && OO.add(pO);
          else OO.add(this._renderTarget);
        void 0 !== this._renderTargetDepth && OO.add(this._renderTargetDepth)
      }
      setOutputLayerAndFaceIndices(OO) {
        const KO = this.frameGraphRenderTarget.renderTargetWrapper;
        if (KO)
          for (const pO of OO) KO.setLayerAndFaceIndex(pO.targetIndex, pO.layerIndex, pO.faceIndex)
      }
      _initialize() {
        this._frameGraphRenderTarget = this._context.createRenderTarget(this.name, this._renderTarget, this._renderTargetDepth, this.depthReadOnly, this.stencilReadOnly), super._initialize()
      }
      _execute() {
        this._context.bindRenderTarget(this._frameGraphRenderTarget), super._execute(), this._context.restoreDefaultFramebuffer()
      }
      _isValid() {
        const OO = super._isValid();
        return OO || (void 0 !== this._renderTarget || void 0 !== this.renderTargetDepth ? null : "Render target and render target depth cannot both be undefined.")
      }
      _dispose() {
        this._frameGraphRenderTarget?.dispose()
      }
    }
    var dO = pO(35660);
    class TO {
      get name() {
        return this._name
      }
      set name(OO) {
        this._name = OO
      }
      get disabled() {
        return this._disabled
      }
      set disabled(OO) {
        this._disabled = OO
      }
      get passes() {
        return this._passes
      }
      get passesDisabled() {
        return this._passesDisabled
      }
      getClassName() {
        return "FrameGraphTask"
      }
      initAsync() {
        return Promise.resolve()
      }
      isReady() {
        return !0
      }
      dispose() {
        this._reset(), this.onTexturesAllocatedObservable.clear(), this.onBeforeTaskExecute.clear(), this.onAfterTaskExecute.clear()
      }
      constructor(OO, KO) {
        this._passes = [], this._passesDisabled = [], this._disabled = !1, this.onTexturesAllocatedObservable = new dO.e, this.onBeforeTaskExecute = new dO.e, this.onAfterTaskExecute = new dO.e, this.name = OO, this._frameGraph = KO, this._reset()
      }
      _reset() {
        for (const OO of this._passes) OO._dispose();
        for (const OO of this._passesDisabled) OO._dispose();
        this._passes.length = 0, this._passesDisabled.length = 0
      }
      _addPass(OO, KO) {
        KO ? this._passesDisabled.push(OO) : this._passes.push(OO)
      }
      _checkTask() {
        let OO, KO = null,
          pO = null;
        for (const vK of this._passes) {
          const XO = vK._isValid();
          if (XO) throw new Error(`Pass "${vK.name}" is not valid. ${XO}`);
          if (fO.IsRenderPass(vK)) {
            const OO = Array.isArray(vK.renderTarget) ? vK.renderTarget : [vK.renderTarget];
            KO = [];
            for (const pO of OO) void 0 !== pO && KO.push(this._frameGraph.textureManager.getTextureFromHandle(pO));
            pO = void 0 !== vK.renderTargetDepth ? this._frameGraph.textureManager.getTextureFromHandle(vK.renderTargetDepth) : null
          } else AO.IsObjectListPass(vK) && (OO = vK.objectList)
        }
        let XO, bK = null,
          eO = [],
          lO = null;
        for (const vK of this._passesDisabled) {
          const OO = vK._isValid();
          if (OO) throw new Error(`Pass "${vK.name}" is not valid. ${OO}`);
          if (fO.IsRenderPass(vK)) {
            const OO = Array.isArray(vK.renderTarget) ? vK.renderTarget : [vK.renderTarget];
            bK = [];
            for (const KO of OO) void 0 !== KO && bK.push(this._frameGraph.textureManager.getTextureFromHandle(KO));
            eO = OO, lO = void 0 !== vK.renderTargetDepth ? this._frameGraph.textureManager.getTextureFromHandle(vK.renderTargetDepth) : null
          } else AO.IsObjectListPass(vK) && (XO = vK.objectList)
        }
        if (this._passesDisabled.length > 0) {
          if (!this._checkSameRenderTarget(KO, bK)) {
            let OO = !0;
            for (const KO of eO)
              if (void 0 !== KO && !this._frameGraph.textureManager.isHistoryTexture(KO)) {
                OO = !1;
                break
              } if (!OO) throw new Error(`The output texture of the task "${this.name}" is different when it is enabled or disabled.`)
          }
          if (pO !== lO && null !== lO) throw new Error(`The output depth texture of the task "${this.name}" is different when it is enabled or disabled.`);
          if (OO !== XO && null !== XO) throw new Error(`The output object list of the task "${this.name}" is different when it is enabled or disabled.`)
        }
      }
      _execute() {
        const OO = this._disabled && this._passesDisabled.length > 0 ? this._passesDisabled : this._passes;
        this.onBeforeTaskExecute.notifyObservers(this), this._frameGraph.engine._debugPushGroup?.(`${this.getClassName()} (${this.name})`);
        try {
          for (const KO of OO) KO._execute()
        } finally {
          this._frameGraph.engine._debugPopGroup?.()
        }
        this.onAfterTaskExecute.notifyObservers(this)
      }
      _initializePasses() {
        this._frameGraph.engine._debugPushGroup?.(`${this.getClassName()} (${this.name})`);
        try {
          for (const OO of this._passes) OO._initialize();
          for (const OO of this._passesDisabled) OO._initialize()
        } finally {
          this._frameGraph.engine._debugPopGroup?.()
        }
      }
      _checkSameRenderTarget(OO, KO) {
        if (null === OO || null === KO) return OO === KO;
        if (OO.length !== KO.length) return !1;
        for (let pO = 0; pO < OO.length; pO++)
          if (OO[pO] !== KO[pO]) return !1;
        return !0
      }
    }
    class NO extends TO {
      get alphaMode() {
        return this.postProcess.alphaMode
      }
      set alphaMode(OO) {
        this.postProcess.alphaMode = OO
      }
      get drawWrapper() {
        return this._postProcessDrawWrapper
      }
      constructor(OO, KO, pO) {
        super(OO, KO), this.sourceSamplingMode = 2, this.depthReadOnly = !1, this.stencilReadOnly = !1, this.disableColorWrite = !1, this.drawBackFace = !1, this.depthTest = !0, this.postProcess = pO, this._postProcessDrawWrapper = this.postProcess.drawWrapper, this.outputTexture = this._frameGraph.textureManager.createDanglingHandle(), this.outputDepthAttachmentTexture = this._frameGraph.textureManager.createDanglingHandle()
      }
      isReady() {
        return this.postProcess.isReady()
      }
      getClassName() {
        return "FrameGraphPostProcessTask"
      }
      record() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        if (void 0 === this.sourceTexture && void 0 === this.targetTexture) throw new Error(`FrameGraphPostProcessTask "${this.name}": sourceTexture or targetTexture is required`);
        const XO = void 0 !== this.sourceTexture ? this._frameGraph.textureManager.getTextureCreationOptions(this.sourceTexture) : void 0;
        if (XO && (XO.options.samples = 1), this._frameGraph.textureManager.resolveDanglingHandle(this.outputTexture, this.targetTexture, this.name, XO), void 0 !== this.depthAttachmentTexture && this._frameGraph.textureManager.resolveDanglingHandle(this.outputDepthAttachmentTexture, this.depthAttachmentTexture), XO) {
          const OO = this._frameGraph.textureManager.getTextureAbsoluteDimensions(XO);
          this._sourceWidth = OO.width, this._sourceHeight = OO.height
        }
        const bK = this._frameGraph.textureManager.getTextureDescription(this.outputTexture);
        this._outputWidth = bK.size.width, this._outputHeight = bK.size.height;
        const eO = this._frameGraph.addRenderPass(this.name);
        if (eO.depthReadOnly = this.depthReadOnly, eO.stencilReadOnly = this.stencilReadOnly, eO.addDependencies(this.sourceTexture), eO.setRenderTarget(this.outputTexture), eO.setRenderTargetDepth(this.depthAttachmentTexture), eO.setExecuteFunc((OO => {
            OO.pushDebugGroup(`Apply post-process (${this.name})`), void 0 !== this.sourceTexture && OO.setTextureSamplingMode(this.sourceTexture, this.sourceSamplingMode), KO?.(OO), this.viewport && OO.setViewport(this.viewport), OO.applyFullScreenEffect(this._postProcessDrawWrapper, (() => {
              void 0 !== this.sourceTexture && OO.bindTextureHandle(this._postProcessDrawWrapper.effect, "textureSampler", this.sourceTexture), pO?.(OO), this.postProcess.bind()
            }), this.stencilState, this.disableColorWrite, this.drawBackFace, this.depthTest, void 0 !== this.viewport), OO.restoreDefaultFramebuffer(), OO.popDebugGroup()
          })), !OO) {
          const OO = this._frameGraph.addRenderPass(this.name + "_disabled", !0);
          OO.depthReadOnly = this.depthReadOnly, OO.stencilReadOnly = this.stencilReadOnly, OO.addDependencies(this.sourceTexture), OO.setRenderTarget(this.outputTexture), OO.setRenderTargetDepth(this.depthAttachmentTexture), OO.setExecuteFunc((OO => {
            void 0 !== this.sourceTexture && 0 === this.alphaMode && (this.viewport && OO.setViewport(this.viewport), OO.copyTexture(this.sourceTexture, void 0, void 0 !== this.viewport))
          }))
        }
        return eO
      }
      dispose() {
        this.postProcess.dispose(), super.dispose()
      }
    }
    class IO extends NO {
      constructor(OO, KO, pO) {
        super(OO, KO, pO || new DO(OO, KO.engine))
      }
      getClassName() {
        return "FrameGraphFXAATask"
      }
      record() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const XO = super.record(OO, KO, pO);
        return this.postProcess.texelSize.x = 1 / this._sourceWidth, this.postProcess.texelSize.y = 1 / this._sourceHeight, XO
      }
    }
    var yK = pO(39841);
    class gK extends NO {
      constructor(OO, KO, pO) {
        super(OO, KO, pO || new yK.f(OO, KO.engine))
      }
      getClassName() {
        return "FrameGraphPassTask"
      }
    }
    var uO = pO(38170),
      EO = pO(38254),
      jK = pO(38209),
      YO = pO(38343),
      wO = pO(35688);
    class iK {
      getRenderCamera(OO) {
        if (this._renderCamera) return this._renderCamera;
        {
          let KO;
          return KO = this.originalScene.activeCameras && this.originalScene.activeCameras.length > 1 ? this.originalScene.activeCameras[this.originalScene.activeCameras.length - 1] : this.originalScene.activeCamera, OO && KO && KO.isRigCamera ? KO.rigParent : KO
        }
      }
      setRenderCamera(OO) {
        this._renderCamera = OO
      }
      _getSharedGizmoLight() {
        return this._sharedGizmoLight || (this._sharedGizmoLight = new YO.d("shared gizmo light", new hO.o(0, 1, 0), this.utilityLayerScene), this._sharedGizmoLight.intensity = 2, this._sharedGizmoLight.groundColor = wO.e.Gray()), this._sharedGizmoLight
      }
      static get DefaultUtilityLayer() {
        return null == iK._DefaultUtilityLayer ? iK._CreateDefaultUtilityLayerFromScene(CO.c.LastCreatedScene) : iK._DefaultUtilityLayer
      }
      static _CreateDefaultUtilityLayerFromScene(OO) {
        return iK._DefaultUtilityLayer = new iK(OO), iK._DefaultUtilityLayer.originalScene.cpO.addOnce((() => {
          iK._DefaultUtilityLayer = null
        })), iK._DefaultUtilityLayer
      }
      static get DefaultKeepDepthUtilityLayer() {
        return null == iK._DefaultKeepDepthUtilityLayer ? iK._CreateDefaultKeepUtilityLayerFromScene(CO.c.LastCreatedScene) : iK._DefaultKeepDepthUtilityLayer
      }
      static _CreateDefaultKeepUtilityLayerFromScene(OO) {
        return iK._DefaultKeepDepthUtilityLayer = new iK(OO), iK._DefaultKeepDepthUtilityLayer.utilityLayerScene.autoClearDepthAndStencil = !1, iK._DefaultKeepDepthUtilityLayer.originalScene.cpO.addOnce((() => {
          iK._DefaultKeepDepthUtilityLayer = null
        })), iK._DefaultKeepDepthUtilityLayer
      }
      constructor(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        this.originalScene = OO, this.handleEvents = KO, this._pointerCaptures = {}, this._lastPointerEvents = {}, this._sharedGizmoLight = null, this._renderCamera = null, this.pickUtilitySceneFirst = !0, this.shouldRender = !0, this.onlyCheckPointerDownEvents = !0, this.processAllEvents = !1, this.pickingEnabled = !0, this.onPointerOutObservable = new dO.e, this.utilityLayerScene = new uO.e(OO.qb(), {
          virtual: !0,
          useFloatingOrigin: OO.floatingOriginMode
        }), this.utilityLayerScene.useRightHandedSystem = OO.useRightHandedSystem, this.utilityLayerScene._allowPostProcessClearColor = !1, this.utilityLayerScene.postProcessesEnabled = !1, this.utilityLayerScene.detachControl(), KO && (this._originalPointerObserver = OO.onPrePointerObservable.add((KO => {
          if (!this.utilityLayerScene.activeCamera) return;
          if (!this.pickingEnabled) return;
          if (!this.processAllEvents && KO.type !== EO.c.POINTERMOVE && KO.type !== EO.c.POINTERUP && KO.type !== EO.c.POINTERDOWN && KO.type !== EO.c.POINTERDOUBLETAP) return;
          this.utilityLayerScene.pointerX = OO.pointerX, this.utilityLayerScene.pointerY = OO.pointerY;
          const pO = KO.event;
          if (OO.isPointerCaptured(pO.pointerId)) return void(this._pointerCaptures[pO.pointerId] = !1);
          const XO = pO => {
              let XO;
              if (KO.nearInteractionPickingInfo) XO = KO.nearInteractionPickingInfo.pickedMesh.JKO() == pO ? KO.nearInteractionPickingInfo : new jK.c;
              else if (pO !== this.utilityLayerScene && KO.originalPickingInfo) XO = KO.originalPickingInfo;
              else {
                let bK = null;
                this._renderCamera && (bK = pO._activeCamera, pO._activeCamera = this._renderCamera, KO.ray = null), XO = KO.ray ? pO.pickWithRay(KO.ray) : pO.Kp(OO.pointerX, OO.pointerY), bK && (pO._activeCamera = bK)
              }
              return XO
            },
            bK = XO(this.utilityLayerScene);
          if (!KO.ray && bK && (KO.ray = bK.ray), KO.originalPickingInfo?.aimTransform && bK && (bK.aimTransform = KO.originalPickingInfo.aimTransform, bK.gripTransform = KO.originalPickingInfo.gripTransform), this.utilityLayerScene.onPrePointerObservable.notifyObservers(KO), this.onlyCheckPointerDownEvents && KO.type != EO.c.POINTERDOWN) return KO.skipOnPointerObservable || this.utilityLayerScene.onPointerObservable.notifyObservers(new EO.e(KO.type, KO.event, bK), KO.type), void(KO.type === EO.c.POINTERUP && this._pointerCaptures[pO.pointerId] && (this._pointerCaptures[pO.pointerId] = !1));
          if (this.utilityLayerScene.autoClearDepthAndStencil || this.pickUtilitySceneFirst) bK && bK.hit && (KO.skipOnPointerObservable || this.utilityLayerScene.onPointerObservable.notifyObservers(new EO.e(KO.type, KO.event, bK), KO.type), KO.skipOnPointerObservable = !0);
          else {
            const pO = XO(OO),
              eO = KO.event;
            pO && bK && (0 === bK.distance && pO.pickedMesh ? this.mainSceneTrackerPredicate && this.mainSceneTrackerPredicate(pO.pickedMesh) ? (this._notifyObservers(KO, pO, eO), KO.skipOnPointerObservable = !0) : KO.type === EO.c.POINTERDOWN ? (this._pointerCaptures[eO.pointerId] = !0, this._notifyObservers(KO, pO, eO)) : KO.type !== EO.c.POINTERMOVE && KO.type !== EO.c.POINTERUP || (this._lastPointerEvents[eO.pointerId] && (this.onPointerOutObservable.notifyObservers(eO.pointerId), delete this._lastPointerEvents[eO.pointerId]), this._notifyObservers(KO, pO, eO)) : !this._pointerCaptures[eO.pointerId] && (bK.distance < pO.distance || 0 === pO.distance) ? (this._notifyObservers(KO, bK, eO), KO.skipOnPointerObservable || (KO.skipOnPointerObservable = bK.distance > 0)) : !this._pointerCaptures[eO.pointerId] && bK.distance >= pO.distance && (this.mainSceneTrackerPredicate && this.mainSceneTrackerPredicate(pO.pickedMesh) ? (this._notifyObservers(KO, pO, eO), KO.skipOnPointerObservable = !0) : (KO.type !== EO.c.POINTERMOVE && KO.type !== EO.c.POINTERUP || this._lastPointerEvents[eO.pointerId] && (this.onPointerOutObservable.notifyObservers(eO.pointerId), delete this._lastPointerEvents[eO.pointerId]), this._notifyObservers(KO, bK, eO))), KO.type === EO.c.POINTERUP && this._pointerCaptures[eO.pointerId] && (this._pointerCaptures[eO.pointerId] = !1))
          }
        })), this._originalPointerObserver && OO.onPrePointerObservable.makeObserverTopPriority(this._originalPointerObserver)), this.utilityLayerScene.autoClear = !1, pO || (this._afterRenderObserver = this.originalScene.onAfterRenderCameraObservable.add((OO => {
          this.shouldRender && OO == this.getRenderCamera() && this.render()
        }))), this._sceneDisposeObserver = this.originalScene.cpO.add((() => {
          this.dispose()
        })), this._updateCamera()
      }
      _notifyObservers(OO, KO, pO) {
        OO.skipOnPointerObservable || (this.utilityLayerScene.onPointerObservable.notifyObservers(new EO.e(OO.type, OO.event, KO), OO.type), this._lastPointerEvents[pO.pointerId] = !0)
      }
      render() {
        if (this._updateCamera(), this.utilityLayerScene.activeCamera) {
          const OO = this.utilityLayerScene.activeCamera.JKO(),
            KO = this.utilityLayerScene.activeCamera;
          KO._scene = this.utilityLayerScene, KO.leftCamera && (KO.leftCamera._scene = this.utilityLayerScene), KO.rightCamera && (KO.rightCamera._scene = this.utilityLayerScene), this.utilityLayerScene.render(!1), KO._scene = OO, KO.leftCamera && (KO.leftCamera._scene = OO), KO.rightCamera && (KO.rightCamera._scene = OO)
        }
      }
      dispose() {
        this.onPointerOutObservable.clear(), this._afterRenderObserver && this.originalScene.onAfterRenderCameraObservable.remove(this._afterRenderObserver), this._sceneDisposeObserver && this.originalScene.cpO.remove(this._sceneDisposeObserver), this._originalPointerObserver && this.originalScene.onPrePointerObservable.remove(this._originalPointerObserver), this.utilityLayerScene.dispose()
      }
      _updateCamera() {
        this.utilityLayerScene.cameraToUseForPointers = this.getRenderCamera(), this.utilityLayerScene.activeCamera = this.getRenderCamera()
      }
    }
    iK._DefaultUtilityLayer = null, iK._DefaultKeepDepthUtilityLayer = null;
    const rK = {
      FindMainCamera: function(OO) {
        return OO.findMainCamera()
      },
      FindMainObjectRenderer: function(OO) {
        return OO.findMainObjectRenderer()
      },
      CreateUtilityLayerRenderer: function(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        const pO = OO.Ce,
          XO = new iK(pO, KO, !0);
        XO.utilityLayerScene.activeCamera = pO.activeCamera;
        let bK = rK.FindMainCamera(pO.frameGraph);
        !bK && pO.cameras.length > 0 && (bK = pO.cameras[0]), bK && (XO.setRenderCamera(bK), XO.utilityLayerScene.activeCamera = bK);
        const eO = pO.onAfterRenderObservable.add((() => {
          XO.render()
        }));
        return XO.utilityLayerScene.cpO.addOnce((() => {
          pO.onAfterRenderObservable.remove(eO)
        })), XO
      }
    };
    let PO = null;

    function mK(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "image/png",
        eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
        lO = arguments.length > 6 ? arguments[6] : void 0,
        vK = arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
        CO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8];
      const {
        height: hO,
        width: DO
      } = cK(OO, KO, pO);
      if (!hO || !DO) return void aK.b.Error("Invalid 'size' parameter !");
      const MO = KO.JKO();
      let FO = MO.activeCamera !== KO;
      if (MO.frameGraph) {
        const OO = rK.FindMainObjectRenderer(MO.frameGraph);
        OO && (FO = OO.camera !== KO)
      }
      FO ? RO(OO, KO, pO, (OO => {
        if (eO) {
          const KO = new Blob([OO]);
          oO.k.DownloadBlob(KO), XO && XO("")
        } else XO && XO(OO)
      }), bK, 1, OO.getCreationOptions().antialias, void 0, void 0, void 0, void 0, lO) : OO.onEndFrameObservable.addOnce((() => {
        PO || (PO = document.createElement("canvas")), PO.width = DO, PO.height = hO;
        const KO = PO.getContext("2d"),
          pO = OO.getRenderingCanvas();
        if (!KO || !pO) return void aK.b.Error("Failed to create screenshot. Rendering context or rendering canvas is not available.");
        const FO = pO.width,
          VO = pO.height,
          LO = PO.width,
          QO = PO.height,
          zK = LO / FO,
          AO = QO / VO,
          fO = vK ? Math.max(zK, AO) : Math.min(zK, AO),
          dO = FO * fO,
          TO = VO * fO,
          NO = (LO - dO) / 2,
          IO = (QO - TO) / 2;
        KO.save(), KO.fillStyle = CO ? MO.clearColor.toHexString() : "rgba(0, 0, 0, 0)", KO.fillRect(0, 0, DO, hO), KO.restore(), KO.drawImage(pO, 0, 0, FO, VO, NO, IO, dO, TO), eO ? (oO.k.EncodeScreenshotCanvasData(PO, void 0, bK, void 0, lO), XO && XO("")) : oO.k.EncodeScreenshotCanvasData(PO, XO, bK, void 0, lO)
      }))
    }
    async function sO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "image/png",
        bK = arguments.length > 4 ? arguments[4] : void 0,
        eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
        lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
        vK = arguments.length > 7 && void 0 !== arguments[7] && arguments[7];
      return await new Promise(((CO, hO) => {
        mK(OO, KO, pO, (OO => {
          "undefined" !== typeof OO ? CO(OO) : hO(new Error("Data is undefined"))
        }), XO, vK, bK, eO, lO)
      }))
    }
    async function HO(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "image/png",
        eO = arguments.length > 5 ? arguments[5] : void 0,
        lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
      return await new Promise((vK => {
        mK(OO, KO, {
          width: pO,
          height: XO
        }, (() => {
          vK()
        }), bK, !0, eO, lO)
      }))
    }

    function RO(OO, KO, eO, lO) {
      let vK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "image/png",
        CO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1,
        hO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
        DO = arguments.length > 7 ? arguments[7] : void 0,
        oO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8],
        QO = arguments.length > 9 && void 0 !== arguments[9] && arguments[9],
        zK = !(arguments.length > 10 && void 0 !== arguments[10]) || arguments[10],
        AO = arguments.length > 11 ? arguments[11] : void 0,
        fO = arguments.length > 12 ? arguments[12] : void 0,
        dO = arguments.length > 13 ? arguments[13] : void 0,
        TO = arguments.length > 14 && void 0 !== arguments[14] ? arguments[14] : 3e4,
        NO = arguments.length > 15 ? arguments[15] : void 0;
      const IO = KO.JKO();
      if (IO.frameGraph) return void JO(IO.frameGraph, KO, eO, vK, CO, hO, DO, AO, dO, !lO).then((OO => {
        lO && lO(OO)
      }));
      const {
        height: yK,
        width: gK,
        finalWidth: uO,
        finalHeight: EO
      } = cK(OO, KO, eO), jK = {
        width: gK,
        height: yK
      };
      if (!yK || !gK) return void aK.b.Error("Invalid 'size' parameter !");
      OO.skipFrameRender = !0;
      const YO = OO.getRenderWidth,
        wO = OO.getRenderHeight;
      OO.getRenderWidth = function() {
        return !(arguments.length > 0 && void 0 !== arguments[0] && arguments[0]) && OO._currentRenderTarget ? OO._currentRenderTarget.width : gK
      }, OO.getRenderHeight = function() {
        return !(arguments.length > 0 && void 0 !== arguments[0] && arguments[0]) && OO._currentRenderTarget ? OO._currentRenderTarget.height : yK
      }, OO.onResizeObservable.hasObservers() && OO.onResizeObservable.notifyObservers(OO);
      const iK = new bK.e("screenShot", jK, IO, !1, !1, 0, !1, XO.e.BILINEAR_SAMPLINGMODE, void 0, QO, void 0, void 0, void 0, CO);
      iK.renderList = IO.meshes.slice(), iK.samples = CO, iK.renderSprites = oO, iK.activeCamera = KO, iK.forceLayerMaskCheck = zK, fO?.(iK);
      const rK = dO || FO.DumpData,
        PO = () => {
          IO.incrementRenderId(), IO.resetCachedMaterial(), (0, LO.e)((() => iK.isReadyForRendering() && KO.isReady(!0)), (() => {
            OO.onEndFrameObservable.addOnce((() => {
              uO === gK && EO === yK ? iK.readPixels(void 0, void 0, void 0, !1).then((OO => {
                rK(gK, yK, OO, lO, vK, DO, !0, void 0, AO), iK.dispose()
              })) : (OO.isWebGPU ? pO.e(351).then((() => pO(59329))) : pO.e(352).then((() => pO(59336)))).then((async () => await (0, VO.e)("pass", iK.getInternalTexture(), IO, void 0, void 0, void 0, uO, EO).then((KO => {
                OO._readTexturePixels(KO, uO, EO, -1, 0, null, !0, !1, 0, 0).then((OO => {
                  rK(uO, EO, OO, lO, vK, DO, !0, void 0, AO), KO.dispose()
                }))
              }))))
            })), IO.incrementRenderId(), IO.resetCachedMaterial();
            const XO = IO.activeCamera,
              bK = IO.activeCameras,
              eO = KO.outputRenderTarget,
              CO = IO.spritesEnabled;
            IO.activeCamera = KO, IO.activeCameras = null, KO.outputRenderTarget = iK, IO.spritesEnabled = oO;
            const hO = IO.meshes;
            IO.meshes = iK.renderList || IO.meshes;
            try {
              IO.render()
            } finally {
              IO.activeCamera = XO, IO.activeCameras = bK, KO.outputRenderTarget = eO, IO.spritesEnabled = CO, IO.meshes = hO, OO.getRenderWidth = YO, OO.getRenderHeight = wO, OO.onResizeObservable.hasObservers() && OO.onResizeObservable.notifyObservers(OO), KO.getProjectionMatrix(!0), OO.skipFrameRender = !1
            }
          }), (() => {
            OO.skipFrameRender = !1, OO.getRenderWidth = YO, OO.getRenderHeight = wO, NO?.()
          }), void 0, TO)
        };
      if (hO) {
        const OO = new MO("antialiasing", 1, IO.activeCamera);
        iK.addPostProcess(OO), OO.autoClear = !0, OO.onEffectCreatedObservable.addOnce((OO => {
          OO.isReady() ? PO() : OO.onCompiled = () => {
            PO()
          }
        }))
      } else PO()
    }
    async function SO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "image/png",
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
        eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
        lO = arguments.length > 6 ? arguments[6] : void 0,
        vK = arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
        CO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8],
        hO = !(arguments.length > 9 && void 0 !== arguments[9]) || arguments[9],
        DO = arguments.length > 10 ? arguments[10] : void 0,
        MO = arguments.length > 11 ? arguments[11] : void 0,
        aK = arguments.length > 12 ? arguments[12] : void 0;
      return await new Promise(((oO, FO) => {
        RO(OO, KO, pO, (OO => {
          "undefined" !== typeof OO ? oO(OO) : FO(new Error("Data is undefined"))
        }), XO, bK, eO, lO, vK, CO, hO, DO, MO, aK)
      }))
    }
    async function JO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "image/png",
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
        eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
        lO = arguments.length > 6 ? arguments[6] : void 0,
        vK = arguments.length > 7 ? arguments[7] : void 0,
        CO = arguments.length > 8 ? arguments[8] : void 0,
        hO = arguments.length > 9 && void 0 !== arguments[9] && arguments[9],
        DO = arguments.length > 10 ? arguments[10] : void 0;
      const MO = OO.engine,
        aK = OO.textureManager,
        {
          height: oO,
          width: VO,
          finalWidth: LO,
          finalHeight: zK
        } = cK(MO, KO, pO),
        AO = {
          width: VO,
          height: oO
        },
        fO = CO || FO.DumpData,
        dO = OO.tasks,
        TO = dO.length,
        NO = OO.pausedExecution,
        yK = MO.getCaps().parallelShaderCompile;
      aK.setBackBufferTextures(0, 0, {
        size: AO,
        options: {
          createMipMaps: !1,
          samples: bK,
          types: [0],
          formats: [5],
          useSRGBBuffers: [!1],
          creationFlags: [0],
          labels: ["screenshot color"]
        },
        sizeIsPercentage: !1
      }, {
        size: AO,
        options: {
          createMipMaps: !1,
          samples: bK,
          types: [0],
          formats: [MO.isStencilEnable ? 13 : 14],
          useSRGBBuffers: [!1],
          creationFlags: [0],
          labels: ["screenshot depth"]
        },
        sizeIsPercentage: !1
      });
      let uO = QO;
      if (eO) {
        const KO = new IO("fxaa", OO);
        KO.sourceTexture = uO, uO = KO.outputTexture, OO.addTask(KO)
      }
      if (LO !== VO || zK !== oO) {
        const KO = new gK("pass", OO);
        KO.sourceTexture = uO, KO.targetTexture = OO.textureManager.createRenderTargetTexture("pass_output", {
          size: {
            width: LO,
            height: zK
          },
          options: {
            createMipMaps: !1,
            types: [0],
            formats: [5],
            samples: 1,
            labels: ["screenshot_final_texture"],
            useSRGBBuffers: [!1]
          },
          sizeIsPercentage: !1
        }), uO = KO.outputTexture, OO.addTask(KO)
      }
      const EO = rK.FindMainObjectRenderer(OO);
      let jK = null;
      EO && (jK = EO.camera, EO.camera = KO), MO.getCaps().parallelShaderCompile = void 0, await OO.buildAsync();
      const YO = DO ?? (aK.hasHistoryTextures ? 32 : 1);
      for (let FO = 0; FO < YO; ++FO) OO.execute();
      OO.pausedExecution = !0, MO.getCaps().parallelShaderCompile = yK;
      for (let FO = TO; FO < dO.length; ++FO) OO.tasks[FO].dispose();
      OO.tasks.length = TO, EO && jK && (EO.camera = jK);
      const wO = OO.textureManager.getTextureFromHandle(uO);
      return wO.incrementReferences(), aK.resetBackBufferTextures(), await OO.buildAsync(), OO.pausedExecution = NO, new Promise((OO => {
        MO._readTexturePixels(wO, LO, zK, -1, 0, null, !0, !1, 0, 0).then((async KO => {
          wO.dispose(), fO(LO, zK, KO, hO ? void 0 : KO => OO(KO), XO, lO, !0, void 0, vK), hO && OO(null)
        }))
      }))
    }

    function cK(OO, KO, pO) {
      let XO = 0,
        bK = 0,
        eO = 0,
        lO = 0;
      if ("object" === typeof pO) {
        const vK = pO.precision ? Math.abs(pO.precision) : 1;
        pO.width && pO.height ? (XO = pO.height * vK, bK = pO.width * vK) : pO.width && !pO.height ? (bK = pO.width * vK, XO = Math.round(bK / OO.getAspectRatio(KO))) : pO.height && !pO.width ? (XO = pO.height * vK, bK = Math.round(XO * OO.getAspectRatio(KO))) : (bK = Math.round(OO.getRenderWidth() * vK), XO = Math.round(bK / OO.getAspectRatio(KO))), pO.finalWidth && pO.finalHeight ? (lO = pO.finalHeight, eO = pO.finalWidth) : pO.finalWidth && !pO.finalHeight ? (eO = pO.finalWidth, lO = Math.round(eO / OO.getAspectRatio(KO))) : pO.finalHeight && !pO.finalWidth ? (lO = pO.finalHeight, eO = Math.round(lO * OO.getAspectRatio(KO))) : (eO = bK, lO = XO)
      } else isNaN(pO) || (XO = pO, bK = pO, eO = pO, lO = pO);
      return bK && (bK = Math.floor(bK)), XO && (XO = Math.floor(XO)), eO && (eO = Math.floor(eO)), lO && (lO = Math.floor(lO)), {
        height: 0 | XO,
        width: 0 | bK,
        finalWidth: 0 | eO,
        finalHeight: 0 | lO
      }
    }
    const BO = {
      CreateScreenshot: mK,
      CreateScreenshotAsync: sO,
      CreateScreenshotWithResizeAsync: HO,
      CreateScreenshotUsingRenderTarget: RO,
      CreateScreenshotUsingRenderTargetAsync: SO,
      CreateScreenshotForFrameGraphAsync: JO
    };
    let ZO = !1;

    function GO() {
      if (ZO) return;
      ZO = !0;
      oO.k.CreateScreenshot = mK, oO.k.CreateScreenshotAsync = sO, oO.k.CreateScreenshotUsingRenderTarget = RO, oO.k.CreateScreenshotUsingRenderTargetAsync = SO
    }
    GO()
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);