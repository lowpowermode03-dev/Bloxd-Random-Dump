export const id = 145;
export const ids = [145];
export const modules = {
  7942: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => gK,
      h: () => yK
    });
    var XO = pO(1051),
      bK = pO(63),
      eO = pO(1591),
      lO = pO(1608),
      vK = pO(918),
      CO = pO.n(vK),
      hO = pO(1271),
      DO = pO(22),
      MO = pO(94),
      aK = pO(107),
      oO = pO(4120),
      FO = pO(1991),
      VO = pO(129),
      LO = pO(1610),
      QO = pO(1618),
      zK = pO(7947),
      AO = pO(243),
      fO = pO(976);
    const dO = {
      floating: "settingsMenu:joystickFloating",
      fixed_shown: "settingsMenu:joystickFixed",
      fixed_hidden: "settingsMenu:joystickHidden"
    };
    var TO = pO(7952);
    const NO = [function() {
      const {
        t: OO
      } = (0, XO.D)(), {
        joystickMode: KO,
        touchSpeedCurve: pO,
        autorun: bK,
        jumpLock: eO
      } = (0, DO.l)(["clientEscMenuOptions"]).clientEscMenuOptions;
      return (0, fO.jsxs)(fO.Fragment, {
        children: [(0, fO.jsx)(oO.e, {
          label: OO("settingsMenu:joystick"),
          options: AO.Ab.map((KO => ({
            value: KO,
            label: OO(dO[KO])
          }))),
          value: KO,
          onChange: OO => {
            DO.d.setClientEscMenuOptions({
              joystickMode: OO
            })
          },
          circleInfoText: OO("settingsMenu:joystickInfo")
        }), (0, fO.jsx)(oO.b, {
          label: OO("settingsMenu:preciseWalking"),
          checked: pO,
          onClick: OO => {
            DO.d.setClientEscMenuOptions({
              touchSpeedCurve: OO
            })
          },
          circleInfoText: OO("settingsMenu:preciseWalkingInfo")
        }), (0, fO.jsx)(oO.b, {
          label: OO("settingsMenu:autoRun"),
          checked: bK,
          onClick: OO => {
            DO.d.setClientEscMenuOptions({
              autorun: OO
            })
          },
          circleInfoText: OO("settingsMenu:autoRunInfo")
        }), (0, fO.jsx)(oO.b, {
          label: OO("settingsMenu:jumpLock"),
          checked: eO,
          onClick: OO => {
            DO.d.setClientEscMenuOptions({
              jumpLock: OO
            })
          },
          circleInfoText: OO("settingsMenu:jumpLockInfo")
        })]
      })
    }, function() {
      const {
        t: OO
      } = (0, XO.D)(), {
        clientEscMenuOptions: KO
      } = (0, DO.l)(["clientEscMenuOptions"]);
      return (0, fO.jsx)(oO.b, {
        label: OO("touchSettings:actionButtons"),
        checked: KO.touchActionButtons,
        onClick: OO => {
          DO.d.setClientEscMenuOptions({
            touchActionButtons: OO
          })
        },
        circleInfoText: OO("touchSettings:actionButtonsInfo")
      })
    }, function() {
      const {
        t: OO
      } = (0, XO.D)(), {
        clientEscMenuOptions: KO
      } = (0, DO.l)(["clientEscMenuOptions"]);
      return (0, TO.e)() ? (0, fO.jsx)(oO.b, {
        label: OO("settingsMenu:vibration"),
        checked: KO.vibration,
        onClick: OO => {
          DO.d.setClientEscMenuOptions({
            vibration: OO
          })
        },
        circleInfoText: OO("settingsMenu:vibrationInfo")
      }) : null
    }];

    function IO() {
      return (0, fO.jsx)(fO.Fragment, {
        children: NO.map(((OO, KO) => (0, fO.jsx)(OO, {}, KO)))
      })
    }

    function yK() {
      const {
        t: OO
      } = (0, XO.D)(), {
        isTouchScreen: KO,
        clientEscMenuOptions: pO,
        gameState: lO
      } = (0, DO.l)(["isTouchScreen", "clientEscMenuOptions", "gameState"]), vK = (0, FO.i)("ezBridging"), CO = (0, FO.i)("ezTowering"), LO = "inGame" !== lO || !0 === vK, QO = (0, VO.d)() && ("inGame" !== lO || !0 === CO), [, AO] = (0, bK.useReducer)((OO => OO + 1), 0), dO = (0, zK.c)();
      return (0, fO.jsxs)("div", {
        className: "SettingsMenuRightInner",
        children: [dO && (0, fO.jsxs)("div", {
          className: "SettingBox ControlsControllerNote",
          children: [(0, fO.jsx)("div", {
            children: OO("controller:settingsControlsNote")
          }), (0, fO.jsx)(hO.S, {
            onClick: () => {
              DO.d.set({
                openSettingsCategory: "controller"
              })
            },
            children: OO("controller:settingsOpenController")
          })]
        }), (0, MO.isTouchscreen)() && !(0, MO.isMobile)() ? (0, fO.jsx)(fO.Fragment, {
          children: (0, fO.jsx)(oO.b, {
            label: OO("settingsMenu:useTouchControls"),
            checked: KO,
            onClick: OO => {
              DO.d.set({
                isTouchScreen: OO
              })
            }
          })
        }) : null, KO && (0, fO.jsx)(IO, {}), LO && (0, fO.jsx)(oO.b, {
          label: OO("settingsMenu:ezBridging"),
          checked: pO.ezBridging,
          onClick: OO => {
            DO.d.setClientEscMenuOptions({
              ezBridging: OO
            })
          },
          circleInfoText: OO("settingsMenu:ezBridgingInfo")
        }), QO && (0, fO.jsx)(oO.b, {
          label: OO("settingsMenu:ezTowering"),
          checked: pO.ezTowering,
          onClick: OO => {
            DO.d.setClientEscMenuOptions({
              ezTowering: OO
            })
          },
          circleInfoText: OO("settingsMenu:ezToweringInfo")
        }), (0, fO.jsx)(oO.b, {
          label: OO("settingsMenu:crouchToggle"),
          checked: pO.crouchIsToggle,
          onClick: OO => {
            DO.d.setClientEscMenuOptions({
              crouchIsToggle: OO
            })
          },
          circleInfoText: OO("settingsMenu:crouchToggleInfo")
        }), (0, fO.jsx)(oO.b, {
          label: OO("settingsMenu:hideUiToggle"),
          checked: pO.hideUiIsToggle,
          onClick: OO => {
            DO.d.setClientEscMenuOptions({
              hideUiIsToggle: OO
            })
          },
          circleInfoText: OO("settingsMenu:hideUiToggleInfo")
        }), "mouseOnly" !== (0, aK.c)() && (0, fO.jsx)(oO.h, {
          name: OO("settingsMenu:touchscreenSensitivity"),
          min: 1,
          max: 900,
          step: 1,
          initValue: pO.touchscreenSensitivity,
          onChange: OO => {
            DO.d.setClientEscMenuOptions({
              touchscreenSensitivity: OO
            })
          }
        }), !(0, MO.isMobile)() && (0, fO.jsx)(oO.h, {
          name: OO("settingsMenu:mouseSensitivity"),
          min: 1,
          max: 200,
          step: 1,
          initValue: pO.mouseSensitivity,
          onChange: OO => {
            DO.d.setClientEscMenuOptions({
              mouseSensitivity: OO
            })
          }
        }), !(0, MO.isMobile)() && (0, fO.jsxs)("div", {
          className: "ControlsContainer",
          children: [(0, fO.jsx)("div", {
            className: "SliderText",
            children: OO("settingsMenu:keyBindings")
          }), eO.c.map((KO => (0, fO.jsx)(gK, {
            title: OO(KO.name.translationKey, KO.name.params),
            defaultOpen: eO.g.has(KO.id),
            children: KO.actions.map((OO => (0, fO.jsx)(uO, {
              noaAction: OO,
              forceUpdate: AO,
              clashesWith: KO.clashesWith,
              showPadGlyph: dO
            }, OO)))
          }, KO.name.translationKey))), (0, fO.jsx)(hO.I, {
            className: "ResetBindingsButton",
            onClick: () => {
              (0, eO.A)(), AO()
            },
            children: OO("controls:resetBindings")
          })]
        })]
      })
    }

    function gK(OO) {
      let {
        title: KO,
        defaultOpen: pO,
        children: XO
      } = OO;
      const [eO, lO] = (0, bK.useState)(pO);
      return (0, fO.jsxs)("div", {
        className: CO()("ControlsSection", {
          Collapsed: !eO
        }),
        children: [(0, fO.jsxs)("div", {
          className: "ControlsSectionHeader",
          "data-pad-focusable": !0,
          onClick: () => {
            lO(!eO)
          },
          children: [(0, fO.jsx)("div", {
            className: "ControlsSectionTitle",
            children: KO
          }), (0, fO.jsx)("div", {
            className: "ControlsSectionChevron",
            children: "\u25be"
          })]
        }), eO && (0, fO.jsx)("div", {
          className: "ControlsSectionRows",
          children: XO
        })]
      })
    }

    function uO(OO) {
      let {
        noaAction: KO,
        forceUpdate: pO,
        clashesWith: vK,
        showPadGlyph: DO
      } = OO;
      const {
        t: MO
      } = (0, XO.D)(), aK = (0, QO.d)(KO), [oO, FO] = (0, bK.useState)(!1), [VO, zK] = (0, bK.useState)("controls:clickToEnterNewBinding"), [AO, dO] = (0, bK.useState)(null), [TO, NO] = (0, bK.useState)(null), IO = (0, bK.useRef)(null);
      (0, bK.useEffect)((() => {
        oO && IO.current && IO.current.focus()
      }), [oO]);
      const yK = eO.s[KO].filter((OO => lO.f[OO]));
      let gK = null;
      const uO = [],
        EO = vK.flatMap((OO => {
          var KO, pO;
          return null !== (KO = null === (pO = eO.c.find((KO => KO.id === OO))) || void 0 === pO ? void 0 : pO.actions) && void 0 !== KO ? KO : []
        }));
      for (const XO of EO) {
        if (XO === KO) continue;
        const OO = eO.s[XO];
        for (const KO of OO) yK.includes(KO) && uO.push(MO(eO.u[XO].translationKey, eO.u[XO].params))
      }
      uO.length > 0 && (gK = MO("controls:sharedBindingsWarning") + " ", gK += uO.join(", "));
      const jK = () => {
          FO(!1), dO(null), zK("controls:clickToEnterNewBinding"), NO(null)
        },
        YO = () => "BindingInput_" + KO;
      return (0, fO.jsxs)("div", {
        className: CO()("ControlRow", {
          WarningBorder: null !== gK
        }),
        children: [(0, fO.jsxs)("div", {
          className: "ControlRowInner",
          children: [(0, fO.jsxs)("div", {
            className: "ControlName",
            children: [MO(eO.u[KO].translationKey, eO.u[KO].params), DO && aK && (0, fO.jsx)(LO.b, {
              glyph: aK,
              className: "ControlPadGlyph"
            })]
          }), (0, fO.jsxs)("div", {
            className: "ControlBindingsContainer",
            children: [(0, fO.jsxs)("div", {
              className: "ControlBindingsList",
              children: [yK.map((OO => (0, fO.jsxs)("div", {
                className: "ControlBinding",
                children: [(0, fO.jsx)("div", {
                  children: (0, eO.j)(OO)
                }), (0, fO.jsx)("div", {
                  className: "ControlBindingRemoveIcon",
                  "data-pad-focusable": !0,
                  onClick: () => {
                    const XO = (0, eO.v)(KO, OO);
                    XO.isError() ? NO(XO.asError().message) : NO(null), pO()
                  },
                  children: "\xd7"
                })]
              }, OO))), !oO && (0, fO.jsx)("div", {
                className: "ControlBinding ControlBindingAdd",
                onClick: () => {
                  FO(!0), NO(null)
                },
                children: (0, fO.jsx)("div", {
                  className: "ControlBindingAddIcon",
                  children: "+"
                })
              })]
            }), oO && (0, fO.jsxs)("div", {
              className: "ControlBindingAddInput",
              children: [(0, fO.jsxs)("div", {
                className: "InputContainer",
                children: [(0, fO.jsx)("div", {
                  className: "InputOverlay",
                  children: AO ? (0, eO.j)(AO) : (0, fO.jsx)("div", {
                    className: "InputOverlayPlaceholder",
                    children: MO(VO)
                  })
                }), (0, fO.jsx)("input", {
                  ref: IO,
                  id: YO(),
                  "data-pad-no-osk": !0,
                  defaultValue: "",
                  onKeyDown: OO => {
                    if ("Escape" === OO.code) return jK(), OO.preventDefault(), void OO.stopPropagation();
                    const KO = OO.code;
                    lO.b.includes(KO) ? (NO(null), dO(KO)) : (NO("controls:keyIsReserved"), dO(null)), OO.preventDefault(), OO.stopPropagation()
                  },
                  onMouseDown: OO => {
                    const KO = "Mouse" + (OO.button + 1);
                    document.activeElement && document.activeElement.id === YO() ? lO.b.includes(KO) ? (NO(null), dO(KO)) : (NO("controls:keyIsReserved"), dO(null)) : zK("controls:enterNewBinding"), OO.stopPropagation()
                  },
                  onBlur: () => {
                    zK("controls:clickToEnterNewBinding")
                  }
                })]
              }), (0, fO.jsx)(hO.d, {
                onPointerDown: OO => {
                  OO.preventDefault()
                },
                onClick: () => {
                  (0, eO.b)(KO, AO), pO(), jK()
                },
                className: "ControlBindingAddButton",
                disabled: null === AO,
                children: MO("general:add")
              }), (0, fO.jsx)("div", {
                className: "ControlBindingAddCancel",
                onClick: () => {
                  jK()
                },
                children: "\xd7"
              })]
            }), TO && (0, fO.jsx)("div", {
              className: "ControlBindingError",
              children: MO(TO)
            })]
          })]
        }), gK && (0, fO.jsx)("div", {
          className: "ControlRowWarning",
          children: gK
        })]
      })
    }
  },
  7922: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK
    });
    var XO = pO(22),
      bK = pO(2704),
      eO = pO(1187),
      lO = pO(1225);
    const vK = async () => {
      if ((0, lO.h)()) {
        if (!0 !== await eO.NotificationProvider.showPromptPopup({
            title: "controller:menusLeaveGameTitle",
            confirmText: "controller:menusLeaveGameLeave",
            cancelText: "controller:menusLeaveGameStay",
            destructive: !0
          }).getResult() || "inGame" !== XO.d.get("gameState")) return
      }(0, bK.b)()
    }
  },
  7927: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO,
      c: () => eO,
      e: () => lO,
      f: () => bK,
      j: () => vK
    });
    var XO = pO(1575);
    const bK = "controllerPadShopOpen",
      eO = OO => XO.j.includes(OO),
      lO = OO => Object.values(OO).some((OO => !1 !== OO.canBuy && !OO.isRewardedAd)),
      vK = (OO, KO, pO) => {
        var XO, bK, lO, vK;
        const CO = OO.filter((OO => !eO(OO))),
          hO = null !== KO && OO.includes(KO) ? KO : null;
        return null !== hO && !eO(hO) && pO(hO) ? hO : null !== (XO = null !== (bK = null !== (lO = null !== (vK = CO.find(pO)) && void 0 !== vK ? vK : CO[0]) && void 0 !== lO ? lO : hO) && void 0 !== bK ? bK : OO[0]) && void 0 !== XO ? XO : null
      },
      CO = OO => OO.userInput || OO.isRewardedAd || "boolean" === typeof OO.isSelected ? null : JSON.stringify([OO.image, OO.cost, OO.currency, OO.amount, OO.customTitle, OO.buyButtonText, OO.description, OO.canBuy])
  },
  7947: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO,
      c: () => DO
    });
    var XO = pO(63),
      bK = pO(1263),
      eO = pO(1621),
      lO = pO(1232),
      vK = pO(1244),
      CO = pO(976);
    const hO = () => {
        const OO = (0, lO.q)();
        if ((0, XO.useEffect)((() => {
            (0, lO.m)()
          }), []), !OO) return null;
        const {
          ControllerCategory: KO
        } = OO;
        return (0, CO.jsx)(vK.d, {
          children: (0, CO.jsx)(KO, {})
        })
      },
      DO = () => {
        var OO;
        const KO = (0, lO.q)(),
          [, pO] = (0, XO.useReducer)((OO => OO + 1), 0);
        return (0, bK.f)(eO.b, pO), null !== (OO = null === KO || void 0 === KO ? void 0 : KO.hasActivePad()) && void 0 !== OO && OO
      }
  },
  7952: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      f: () => CO
    });
    var XO = pO(22),
      bK = pO(1163),
      eO = pO(94);
    const lO = {
      blockMined: {
        pattern: [18],
        priority: 1,
        minGapMs: 120
      },
      hitLanded: {
        pattern: [20],
        priority: 2,
        minGapMs: 80
      },
      damageTaken: {
        pattern: [45],
        priority: 3,
        minGapMs: 250
      },
      fishBite: {
        pattern: null,
        priority: 3,
        minGapMs: 0
      },
      death: {
        pattern: [60, 70, 120],
        priority: 4,
        minGapMs: 0
      },
      lockReady: {
        pattern: [8],
        priority: 2,
        minGapMs: 0
      },
      lockLocked: {
        pattern: [15, 50, 15],
        priority: 2,
        minGapMs: 0
      },
      autorunLedgeStop: {
        pattern: [40],
        priority: 3,
        minGapMs: 0
      }
    };

    function vK() {
      return (0, eO.isMobile)() && "function" === typeof navigator.vibrate
    }
    const CO = new class {
      constructor(OO) {
        this.deps = OO, this.lastAt = new Map, this.lastAnyAt = -1 / 0, this.playingUntil = -1 / 0, this.playingPriority = 0
      }
      play(OO, KO) {
        var pO;
        if (!this.deps.enabled()) return;
        const XO = lO[OO],
          bK = null !== KO && void 0 !== KO ? KO : XO.pattern;
        if (null === bK) return void console.warn("No vibration pattern for", OO);
        const eO = this.deps.now();
        eO - this.lastAnyAt < 40 && XO.priority < this.playingPriority || eO - (null !== (pO = this.lastAt.get(OO)) && void 0 !== pO ? pO : -1 / 0) < XO.minGapMs || eO < this.playingUntil && XO.priority < this.playingPriority || (this.lastAt.set(OO, eO), this.lastAnyAt = eO, this.playingUntil = eO + bK.reduce(((OO, KO) => OO + KO), 0), this.playingPriority = XO.priority, this.deps.vibrate(bK))
      }
    }({
      vibrate: OO => {
        navigator.vibrate([...OO])
      },
      now: () => performance.now(),
      enabled: () => vK() && XO.d.get("isTouchScreen") && XO.d.get("clientEscMenuOptions").vibration && !(0, bK.f)()
    })
  },
  7833: (OO, KO, pO) => {
    function XO(OO, KO) {
      return !OO.hidden && (KO || !OO.isRewardedAd)
    }

    function bK(OO) {
      return "object" === typeof OO ? OO.option : OO
    }

    function eO(OO, KO) {
      var pO;
      if ("dropdown" === (null === (pO = OO.userInput) || void 0 === pO ? void 0 : pO.type) && "object" === typeof OO.userInput.dropdownOptions[0]) {
        for (const pO of OO.userInput.dropdownOptions)
          if (bK(pO) === KO) return "object" === typeof pO ? pO.cost : OO.cost;
        console.error("Didn't find matching option for dropdown item. Item:", OO, "input:", KO)
      }
      return OO.cost
    }

    function lO(OO, KO, pO) {
      var XO;
      const bK = null !== (XO = pO.excludedPlayers) && void 0 !== XO ? XO : [KO];
      return OO.filter((OO => !bK.includes(OO)))
    }
    pO.d(KO, {
      e: () => eO,
      f: () => bK,
      g: () => lO,
      i: () => XO
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);