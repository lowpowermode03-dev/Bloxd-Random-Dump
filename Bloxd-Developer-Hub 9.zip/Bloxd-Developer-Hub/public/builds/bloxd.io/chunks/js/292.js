export const id = 292;
export const ids = [292];
export const modules = {
  39851: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      _HDRTextureLoader: () => DO
    });
    var XO = pO(35632);
    class bK {
      static ConvertPanoramaToCubemap(OO, KO, pO, XO) {
        let bK, eO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
          lO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5];
        if (!OO) throw "ConvertPanoramaToCubemap: input cannot be null";
        if (OO.length != KO * pO * 3) {
          if (OO.length != KO * pO * 4) throw "ConvertPanoramaToCubemap: input size is wrong";
          bK = 4
        } else bK = 3;
        return {
          front: this.CreateCubemapTexture(XO, this.FACE_FRONT, OO, KO, pO, eO, lO, bK),
          back: this.CreateCubemapTexture(XO, this.FACE_BACK, OO, KO, pO, eO, lO, bK),
          left: this.CreateCubemapTexture(XO, this.FACE_LEFT, OO, KO, pO, eO, lO, bK),
          right: this.CreateCubemapTexture(XO, this.FACE_RIGHT, OO, KO, pO, eO, lO, bK),
          up: this.CreateCubemapTexture(XO, this.FACE_UP, OO, KO, pO, eO, lO, bK),
          down: this.CreateCubemapTexture(XO, this.FACE_DOWN, OO, KO, pO, eO, lO, bK),
          size: XO,
          type: 1,
          format: 4,
          gammaSpace: !1
        }
      }
      static CreateCubemapTexture(OO, KO, pO, XO, bK, eO, lO, vK) {
        const CO = new ArrayBuffer(OO * OO * 4 * 3),
          hO = new Float32Array(CO),
          DO = eO ? Math.max(1, Math.round(XO / 4 / OO)) : 1,
          MO = 1 / DO,
          aK = MO * MO,
          oO = KO[1].subtract(KO[0]).scale(MO / OO),
          FO = KO[3].subtract(KO[2]).scale(MO / OO),
          VO = 1 / OO;
        let LO = 0;
        for (let QO = 0; QO < OO; QO++)
          for (let eO = 0; eO < DO; eO++) {
            let eO = KO[0],
              CO = KO[2];
            for (let KO = 0; KO < OO; KO++)
              for (let MO = 0; MO < DO; MO++) {
                const DO = CO.subtract(eO).scale(LO).add(eO);
                DO.normalize();
                const MO = this.CalcProjectionSpherical(DO, pO, XO, bK, vK, lO);
                hO[QO * OO * 3 + 3 * KO + 0] += MO.r * aK, hO[QO * OO * 3 + 3 * KO + 1] += MO.g * aK, hO[QO * OO * 3 + 3 * KO + 2] += MO.b * aK, eO = eO.add(oO), CO = CO.add(FO)
              }
            LO += VO * MO
          }
        return hO
      }
      static CalcProjectionSpherical(OO, KO, pO, XO, bK, eO) {
        let lO = Math.atan2(OO.z, OO.x);
        const vK = Math.acos(OO.y);
        for (; lO < -Math.PI;) lO += 2 * Math.PI;
        for (; lO > Math.PI;) lO -= 2 * Math.PI;
        let CO = lO / Math.PI;
        const hO = vK / Math.PI;
        CO = .5 * CO + .5;
        let DO = Math.round(CO * pO);
        DO < 0 ? DO = 0 : DO >= pO && (DO = pO - 1);
        let MO = Math.round(hO * XO);
        MO < 0 ? MO = 0 : MO >= XO && (MO = XO - 1);
        const aK = eO ? XO - MO - 1 : MO;
        return {
          r: KO[aK * pO * bK + DO * bK + 0],
          g: KO[aK * pO * bK + DO * bK + 1],
          b: KO[aK * pO * bK + DO * bK + 2]
        }
      }
    }

    function eO(OO, KO, pO, XO, bK, eO) {
      bK > 0 ? (bK = function(OO, KO) {
        return KO > 1023 ? OO * Math.pow(2, 1023) * Math.pow(2, KO - 1023) : KO < -1074 ? OO * Math.pow(2, -1074) * Math.pow(2, KO + 1074) : OO * Math.pow(2, KO)
      }(1, bK - 136), OO[eO + 0] = KO * bK, OO[eO + 1] = pO * bK, OO[eO + 2] = XO * bK) : (OO[eO + 0] = 0, OO[eO + 1] = 0, OO[eO + 2] = 0)
    }

    function lO(OO, KO) {
      let pO, XO = "";
      for (let bK = KO; bK < OO.length - KO && (pO = String.fromCharCode(OO[bK]), "\n" != pO); bK++) XO += pO;
      return XO
    }

    function vK(OO) {
      let KO = lO(OO, 0);
      if ("#" != KO[0] || "?" != KO[1]) throw "Bad HDR Format.";
      let pO = !1,
        XO = !1,
        bK = 0;
      do {
        bK += KO.length + 1, KO = lO(OO, bK), "FORMAT=32-bit_rle_rgbe" == KO ? XO = !0 : 0 == KO.length && (pO = !0)
      } while (!pO);
      if (!XO) throw "HDR Bad header format, unsupported FORMAT";
      bK += KO.length + 1, KO = lO(OO, bK);
      const eO = /^-Y (.*) \+X (.*)$/g.exec(KO);
      if (!eO || eO.length < 3) throw "HDR Bad header format, no size";
      const vK = parseInt(eO[2]),
        CO = parseInt(eO[1]);
      if (vK < 8 || vK > 32767) throw "HDR Bad header format, unsupported size";
      return bK += KO.length + 1, {
        height: CO,
        width: vK,
        dataPosition: bK
      }
    }

    function CO(OO, KO) {
      return function(OO, KO) {
        let pO = KO.height;
        const XO = KO.width;
        let bK, lO, vK, CO, DO, MO, aK, oO, FO = KO.dataPosition;
        const VO = new ArrayBuffer(4 * XO),
          LO = new Uint8Array(VO),
          QO = new ArrayBuffer(KO.width * KO.height * 4 * 3),
          zK = new Float32Array(QO);
        for (; pO > 0;) {
          if (bK = OO[FO++], lO = OO[FO++], vK = OO[FO++], CO = OO[FO++], 2 != bK || 2 != lO || 128 & vK || KO.width < 8 || KO.width > 32767) return hO(OO, KO);
          if ((vK << 8 | CO) != XO) throw "HDR Bad header format, wrong scan line width";
          for (MO = 0, oO = 0; oO < 4; oO++)
            for (aK = (oO + 1) * XO; MO < aK;)
              if (bK = OO[FO++], lO = OO[FO++], bK > 128) {
                if (DO = bK - 128, 0 == DO || DO > aK - MO) throw "HDR Bad Format, bad scanline data (run)";
                for (; DO-- > 0;) LO[MO++] = lO
              } else {
                if (DO = bK, 0 == DO || DO > aK - MO) throw "HDR Bad Format, bad scanline data (non-run)";
                if (LO[MO++] = lO, --DO > 0)
                  for (let KO = 0; KO < DO; KO++) LO[MO++] = OO[FO++]
              } for (oO = 0; oO < XO; oO++) bK = LO[oO], lO = LO[oO + XO], vK = LO[oO + 2 * XO], CO = LO[oO + 3 * XO], eO(zK, bK, lO, vK, CO, (KO.height - pO) * XO * 3 + 3 * oO);
          pO--
        }
        return zK
      }(OO, KO)
    }

    function hO(OO, KO) {
      let pO = KO.height;
      const XO = KO.width;
      let bK, lO, vK, CO, hO, DO = KO.dataPosition;
      const MO = new ArrayBuffer(KO.width * KO.height * 4 * 3),
        aK = new Float32Array(MO);
      for (; pO > 0;) {
        for (hO = 0; hO < KO.width; hO++) bK = OO[DO++], lO = OO[DO++], vK = OO[DO++], CO = OO[DO++], eO(aK, bK, lO, vK, CO, (KO.height - pO) * XO * 3 + 3 * hO);
        pO--
      }
      return aK
    }
    bK.FACE_LEFT = [new XO.o(-1, -1, -1), new XO.o(1, -1, -1), new XO.o(-1, 1, -1), new XO.o(1, 1, -1)], bK.FACE_RIGHT = [new XO.o(1, -1, 1), new XO.o(-1, -1, 1), new XO.o(1, 1, 1), new XO.o(-1, 1, 1)], bK.FACE_FRONT = [new XO.o(1, -1, -1), new XO.o(1, -1, 1), new XO.o(1, 1, -1), new XO.o(1, 1, 1)], bK.FACE_BACK = [new XO.o(-1, -1, 1), new XO.o(-1, -1, -1), new XO.o(-1, 1, 1), new XO.o(-1, 1, -1)], bK.FACE_DOWN = [new XO.o(1, 1, -1), new XO.o(1, 1, 1), new XO.o(-1, 1, -1), new XO.o(-1, 1, 1)], bK.FACE_UP = [new XO.o(-1, -1, -1), new XO.o(-1, -1, 1), new XO.o(1, -1, -1), new XO.o(1, -1, 1)];
    class DO {
      constructor() {
        this.supportCascades = !1
      }
      loadCubeData() {
        throw ".hdr not supported in Cube."
      }
      loadData(OO, KO, pO) {
        const XO = new Uint8Array(OO.buffer, OO.byteOffset, OO.byteLength),
          bK = vK(XO),
          eO = CO(XO, bK),
          lO = bK.width * bK.height,
          hO = new Float32Array(4 * lO);
        for (let vK = 0; vK < lO; vK += 1) hO[4 * vK] = eO[3 * vK], hO[4 * vK + 1] = eO[3 * vK + 1], hO[4 * vK + 2] = eO[3 * vK + 2], hO[4 * vK + 3] = 1;
        pO(bK.width, bK.height, KO.generateMipMaps, !1, (() => {
          const OO = KO.qb();
          KO.type = 1, KO.format = 5, KO._gammaSpace = !1, OO._uploadDataToTextureDirectly(KO, hO)
        }))
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);