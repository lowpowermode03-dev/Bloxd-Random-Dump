export const id = 146;
export const ids = [146];
export const modules = {
  37173: (OO, KO, pO) => {
    var XO = {
      "./cape_cow_cream.png": 26896,
      "./cape_cow_normal.png": 26901,
      "./cape_creator_level1.png": 26910,
      "./cape_creator_level2.png": 26917,
      "./cape_creator_level3.png": 26926,
      "./cape_none.png": 26929,
      "./cape_pig.png": 26934,
      "./cape_sheep.png": 26936,
      "./cape_super.png": 26943,
      "./cape_super_inverted.png": 26950,
      "./cape_youtuber.png": 26955
    };

    function bK(OO) {
      var KO = eO(OO);
      return pO(KO)
    }

    function eO(OO) {
      if (!pO.o(XO, OO)) {
        var KO = new Error("Cannot find module '" + OO + "'");
        throw KO.code = "MODULE_NOT_FOUND", KO
      }
      return XO[OO]
    }
    bK.keys = function() {
      return Object.keys(XO)
    }, bK.resolve = eO, OO.exports = bK, bK.id = 37173
  },
  39319: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      openCharacterPreview: () => ZO
    });
    var XO = pO(36516),
      bK = pO(2231),
      eO = pO(1803),
      lO = pO(512),
      vK = pO(35966),
      CO = pO(1811),
      hO = pO(35959),
      DO = pO(37880),
      MO = pO(38162),
      aK = pO(39231),
      oO = pO(35624),
      FO = pO(38338),
      VO = pO(35680),
      LO = pO(38355),
      QO = pO(39279),
      zK = pO(35594),
      AO = pO(35980),
      fO = pO(35990);
    pO(39254), pO(38587), pO(39261);
    let dO, TO, NO, IO, yK, gK, uO, EO, jK;
    const YO = document.createElement("canvas");
    async function wO() {
      await new Promise((OO => {
        setTimeout((() => {
          OO()
        }), 100)
      }))
    }
    YO.classList.add("CharCustomisationPreviewCanvas");
    const iK = {},
      rK = {},
      PO = {},
      mK = {};

    function sO(OO) {
      OO.unfreezeWorldMatrix();
      for (const KO of OO.getChildren()) sO(KO)
    }

    function HO(OO, KO) {
      const pO = (0, zK.f)(OO, KO);
      return pO in iK || (iK[pO] = (async () => {
        try {
          const pO = await (0, zK.g)(OO, NO),
            XO = new Map;
          for (const OO of pO.getNodes()) XO.set(OO.name, OO);
          const bK = (0, zK.c)(null !== KO && void 0 !== KO ? KO : OO, NO);
          (0, zK.i)(pO, bK, {
            onProcessedMesh: OO => {
              (0, zK.j)(OO), NO.GhO(OO, !1), OO.isVisible = !1
            }
          });
          for (const OO of pO.rootNodes) sO(OO);
          return XO
        } catch (XO) {
          throw delete iK[pO], console.error(`Failed to load preview attachment ${pO}:`, XO), XO
        }
      })()), iK[pO]
    }

    function RO(OO, KO) {
      OO.isVisible = KO;
      for (const pO of OO.getChildMeshes()) pO.isVisible = KO
    }

    function SO(OO, KO) {
      if (!IO) return;
      const vK = (0, bK.d)();
      if (vK.QKO(!1), XO.b.Player.meshApi.updatePlayerCosmetic(vK.CpO, uO, OO, KO, !0), "cape" === OO)
        if (KO === lO.f) yK.WE(!1);
        else {
          yK.WE(!0);
          yK.material.diffuseTexture = new QO.c(pO(37173)(`./cape_${KO}.png`), yK.JKO(), {
            invertY: !1,
            samplingMode: QO.c.NEAREST_NEAREST_MIPLINEAR
          })
        } mK[OO] = async function(OO, KO) {
        var pO;
        PO[OO] = KO;
        const XO = rK[OO];
        if (XO)
          for (const {
              mesh: eO,
              destNode: lO
            }
            of XO) {
            RO(eO, !1);
            const OO = gK.getNamedNode(uO, lO);
            gK.detachTransformNodeIfFound(eO, uO, OO)
          }
        rK[OO] = [];
        const bK = (0, eO.j)(OO, KO);
        if (null !== bK && void 0 !== bK && null !== (pO = bK.attachments) && void 0 !== pO && pO.length)
          for (const eO of bK.attachments) {
            let pO;
            try {
              pO = await HO(eO.modelGlb, eO.texture)
            } catch {
              continue
            }
            if (PO[OO] !== KO) return;
            const XO = pO.get(eO.modelNode);
            if (!XO) {
              console.error(`Preview attachment node ${eO.modelNode} not found in ${eO.modelGlb}`);
              continue
            }
            RO(XO, !0), (0, zK.n)(XO, eO.overlayColour);
            const bK = gK.getNamedNode(uO, eO.destNode);
            gK.attachTransformNode(XO, uO, bK), rK[OO].push({
              mesh: XO,
              destNode: eO.destNode
            })
          }
      }(OO, KO)
    }

    function JO(OO, KO) {
      YO.width = OO, YO.height = KO, dO.resize()
    }
    let cK = 0;
    class BO {
      constructor(OO) {
        this.ready = jK, this.dev = {
          setCamera(OO) {
            let {
              yaw: KO,
              pitch: pO,
              radius: XO
            } = OO;
            TO.alpha = KO, TO.beta = pO, XO && (TO.radius = XO)
          },
          canvas: () => YO,
          isolateHead(OO) {
            const KO = gK.getNodeNames(uO);
            for (let pO = 0; pO < KO.length; pO++) "HeadMesh" !== KO[pO] && "__root__" !== KO[pO] && "TorsoNode" !== KO[pO] && gK.setNodeEnabled(uO, pO, !1);
            if (OO) {
              const OO = gK.getNamedNode(uO, "HeadMesh");
              gK.setNodeDisableColorWrite(uO, OO, !0, (OO => {
                const KO = new LO.StandardMaterial(`${OO.name}_depthOnly`, OO.JKO());
                return KO.disableColorWrite = !0, KO
              }))
            }
            gK.setPosition(uO, 0, -12, 0)
          }
        }, this.closed = !1;
        const KO = OO.getBoundingClientRect();
        JO(KO.width, KO.height), cK++, dO.stopRenderLoop(), dO.runRenderLoop((() => {
          var OO;
          null === (OO = EO) || void 0 === OO || OO.render(dO.getDeltaTime()), NO.render()
        }))
      }
      isReady() {
        return !!IO
      }
      setCosmetic(OO, KO) {
        SO(OO, KO)
      }
      playEmote(OO) {
        if (!EO) return;
        if (!OO) return void EO.stopAnimation(hO.f.Emote);
        const KO = (0, vK.g)((0, CO.j)(OO).animation);
        EO.startAnimation(KO, hO.f.Emote, 0, CO.d)
      }
      async untilDrawn(OO) {
        if (await wO(), "cape" === OO && yK) {
          const OO = yK.material,
            KO = null === OO || void 0 === OO ? void 0 : OO.diffuseTexture;
          KO && !KO.isReady() && (await new Promise((OO => {
            KO.onLoadObservable.addOnce((() => {
              OO()
            }))
          })), await wO())
        }
        mK[OO] && (await mK[OO], await wO()), await NO.whenReadyAsync(), await new Promise((OO => {
          NO.onAfterRenderObservable.addOnce((() => {
            OO()
          }))
        }))
      }
      resize(OO, KO) {
        JO(OO, KO)
      }
      close() {
        this.closed || (this.closed = !0, cK--, 0 === cK && dO.stopRenderLoop())
      }
    }

    function ZO(OO) {
      return OO.appendChild(YO), dO || function() {
        dO = new DO.d(YO, !0, {
          preserveDrawingBuffer: !0
        });
        const OO = (0, bK.d)();
        dO.BhO = OO.Lb.engine.BhO, NO = new MO.d(dO), NO.clearColor = new VO.c(0, 0, 0, 0), NO.ambientColor = new VO.Color3(1, 1, 1), TO = new aK.c("xv", .61 * Math.PI, Math.PI / 2.05, 30, oO.WX.Zero(), NO), TO.attachControl(YO, !0), TO.panningSensibility = 0, jK = (0, XO.u)("Player", NO, !0).then((KO => {
          IO = KO.meshApi, yK = KO.capeMesh, gK = OO.Lb.ZKO;
          const pO = 8.33;
          uO = (0, XO.g)("Player", pO, !0, !0), gK.setPosition(uO, 0, -8.33, 0);
          const bK = gK.getNamedNode(uO, "BodyMesh");
          gK.attachTransformNode(yK, uO, bK), gK.set(uO, "aOpacity", 1), gK.DpO(uO, "aOpacity", 1), EO = new AO.AnimatorState, EO.ap = OO, EO.thinInstMgr = gK, EO.GKO = uO, EO.dhO = gK.ZhO(uO, 0), EO.modelLifeformType = "Player", EO.nodeNameAliases = (0, fO.b)("Player").nodeNameAliases;
          const eO = yK.hpO().boundingBox;
          yK.position.y = ((24 - eO.maximum.y + eO.minimum.y) / 2 - 1 / 32) / pO, yK.position.z = -1 / pO, yK.rotationQuaternion = null;
          const lO = Math.PI / 18,
            vK = eO.maximum.y / pO;
          yK.rotation.x = lO;
          const CO = Math.cos(lO),
            hO = Math.sin(lO);
          yK.position.y += vK * (1 - CO) + 0 * hO, yK.position.z -= vK * hO + 0 * (1 - CO);
          const DO = new LO.StandardMaterial("capeMaterial", yK.JKO());
          yK.material = DO;
          const MO = new VO.Color3(1, 1, 1);
          DO.diffuseColor = new VO.Color3, DO.specularColor = new VO.Color3, DO.emissiveColor = new VO.Color3, DO.ambientColor = new VO.Color3, MO.scaleToRef(.43, DO.diffuseColor), MO.scaleToRef(1.75, DO.ambientColor), DO.freeze();
          const aK = new FO.b("light", new oO.WX(-.1, 1, -.3), NO);
          aK.diffuse = new VO.Color3(1, 1, 1), aK.specular = new VO.Color3(1, 1, 1), aK.groundColor = new VO.Color3(.5, .5, .5)
        }))
      }(), new BO(OO)
    }
  },
  37168: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => aK
    });
    var XO = pO(35545),
      bK = pO(35559),
      eO = pO(35774),
      lO = pO(35568),
      vK = pO(35552);

    function CO(OO) {
      return `\n\t\t\t\t${(0,vK.D)(OO,"mat2","rotate",[{name:"ang",type:"float"}],`\
      n\ t\ t\ t\ t\ t$ {
        (0, vK.I)(OO, "float", "s", "sin(ang)")
      }\
      n\ t\ t\ t\ t\ t$ {
        (0, vK.I)(OO, "float", "c", "cos(ang)")
      }\
      n\ t\ t\ t\ t\ treturn $ {
        (0, vK.q)(OO, "mat2", "c", "s", "-s", "c")
      };\
      n\ t\ t\ t\ t`)}\n\t\t\t`
    }

    function hO(OO, KO) {
      let pO = (0, vK.Cb)(OO, "skele" + (KO - 1));
      for (let bK = KO - 2; bK >= 0; bK--) pO = (0, vK.tb)(OO, `boneIdx == ${bK}`, (0, vK.Cb)(OO, `skele${bK}`), pO);
      const XO = "bone.yz + rotate(bone.x) * pivot - pivot";
      return `\n\t\t\t\t${(0,vK.I)(OO,"int","boneIdx",(0,vK.zb)(OO,"BLOXD_CAPE_MAX_Y - positionUpdated.y"))}\n\t\t\t\t${(0,vK.I)(OO,"vec3","bone",pO)}\n\t\t\t\t${(0,vK.I)(OO,"vec2","pivot",(0,vK.q)(OO,"vec2","0.0",`${(0,vK.Lb)(OO,"position")}.z`))}\n\t\t\t\t${(0,vK.cb)(OO)?`positionUpdated = vec3f(positionUpdated.x, positionUpdated.yz + (${XO}));`:`positionUpdated.yz += ${XO};`}\n\t\t`
    }

    function DO(OO) {
      return `\n\t\t\t\t#ifdef NORMAL\n\t\t\t\tnormalUpdated = ${(0,vK.q)(OO,"vec3","normalUpdated.x","rotate(bone.x) * normalUpdated.yz")};\n\t\t\t\t#endif\n\t\t`
    }
    const MO = {
        x: 0,
        y: 0,
        z: 0,
        BCO(OO, KO) {
          return this.x = OO[KO], this.y = OO[KO + 1], this.z = OO[KO + 2], this
        }
      },
      aK = {
        name: "Cape",
        className: "CapeMaterialPlugin",
        priority: 200,
        defines: (OO, KO) => ({
          ...(0, XO.e)("CAPE"),
          BLOXD_CAPE_BONES: `${OO}`,
          BLOXD_CAPE_MAX_Y: (0, bK.kb)(KO)
        }),
        getUniforms(OO) {
          return (0, eO.e)(function(OO) {
            const KO = [];
            for (let pO = 0; pO < OO; pO++) KO.push({
              name: `skele${pO}`,
              type: "highp vec3"
            });
            return KO
          }(this.skeleLen), "vertex", OO)
        },
        bind(OO) {
          for (let KO = 0; KO < this.skeleLen; KO++) OO.updateVector3(`skele${KO}`, MO.BCO(this.skele, 3 * KO))
        },
        uniformsVersion() {
          return this.bonesVersion
        },
        getCustomCode(OO, KO) {
          return "vertex" !== OO ? null : {
            CUSTOM_VERTEX_DEFINITIONS: CO(KO),
            CUSTOM_VERTEX_UPDATE_POSITION: hO(KO, this.skeleLen),
            CUSTOM_VERTEX_UPDATE_NORMAL: DO(KO)
          }
        }
      };
    (0, lO.k)(aK)
  },
  37070: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      h: () => MO
    });
    var XO = pO(35545),
      bK = pO(35774),
      eO = pO(35552),
      lO = pO(35568);
    const vK = "bloxdTextLodBias",
      CO = [{
        name: vK,
        type: "float"
      }],
      hO = "bloxdTextSample",
      DO = {
        planes: -.5,
        boards: -.5
      },
      MO = {
        name: "TextSampler",
        className: "TextSamplerMaterialPlugin",
        priority: 60,
        defines: () => (0, XO.e)("TEXT_SAMPLER"),
        getUniforms: OO => (0, bK.e)(CO, "fragment", OO),
        bind(OO) {
          OO.updateFloat(vK, this.lodBias)
        },
        uniformsVersion: () => 0,
        getCustomCode(OO, KO) {
          if ("fragment" !== OO) return null;
          const pO = (0, eO.R)(KO, `vec4 ${hO}(sampler2D s, vec2 uv, float bias)`, `fn ${hO}(t: texture_2d<f32>, ts: sampler, uv: vec2f, bias: f32) -> vec4f`),
            XO = (0, eO.R)(KO, "texture2D(s, uv, bias)", "textureSampleBias(t, ts, uv, bias)"),
            bK = `${(0,eO._)(KO,"vDiffuseUV")} + uvOffset`,
            lO = (0, eO.R)(KO, `${hO}(diffuseSampler, ${bK}, ${(0,eO.Cb)(KO,vK)})`, `${hO}(diffuseSampler, diffuseSamplerSampler, ${bK}, ${(0,eO.Cb)(KO,vK)})`);
          return {
            CUSTOM_FRAGMENT_DEFINITIONS: `\n\t\t\t\t${pO} {\n\t\t\t\t\t${(0,eO.I)(KO,"vec4","texel",XO)}\n\t\t\t\t\t// 8-bit premultiplied rounding can put the quotient just over 1; only alpha 0 hits the floor,\n\t\t\t\t\t// where the colour is 0 anyway.\n\t\t\t\t\treturn ${(0,eO.q)(KO,"vec4",`clamp(texel.rgb / max(texel.a, 1.0 / 255.0), ${(0,eO.q)(KO,"vec3","0.0")}, ${(0,eO.q)(KO,"vec3","1.0")})`,"texel.a")};\n\t\t\t\t}\n\t\t\t`,
            [(0, eO.M)(KO)]: `baseColor = ${lO};`
          }
        }
      };
    (0, lO.k)(MO)
  },
  7899: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      h: () => vK,
      l: () => CO
    });
    var XO = pO(1803),
      bK = pO(1098),
      eO = pO(1811);
    const lO = ",";

    function vK(OO) {
      if (!OO) return [];
      const KO = new Set,
        pO = [];
      for (const XO of OO.split(lO)) {
        const OO = XO.trim();
        if ((0, eO.n)(OO) && !KO.has(OO) && (KO.add(OO), pO.push(OO), pO.length >= bK.m)) break
      }
      return pO
    }

    function CO(OO) {
      const KO = new Set,
        pO = [];
      for (const XO of OO)
        if ((0, eO.n)(XO) && !KO.has(XO) && (KO.add(XO), pO.push(XO), pO.length >= bK.m)) break;
      return pO.join(lO)
    }

    function hO() {
      return CO(eO.g)
    }

    function DO(OO) {
      var KO;
      return "emote" === OO ? hO() : null !== (KO = MO[OO][0]) && void 0 !== KO ? KO : aK[OO]
    }
    const MO = bK.w.reduce(((OO, KO) => {
        const pO = [];
        for (const eO in XO.d[KO]) {
          var bK;
          "default" === (null === (bK = (0, XO.j)(KO, eO)) || void 0 === bK ? void 0 : bK.cosmeticPack) && pO.push(eO)
        }
        return OO[KO] = pO, OO
      }), {}),
      aK = bK.w.reduce(((OO, KO) => (OO[KO] = Object.keys(XO.d[KO])[0], OO)), {})
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);