export const id = 132;
export const ids = [132];
export const modules = {
  7172: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      BloxdDiscordSDK: () => VO,
      DiscordLoginCancelledError: () => FO,
      discordPopupTimeoutMs: () => oO
    });
    var XO = pO(149),
      bK = pO(1086),
      eO = pO(1008),
      lO = pO(1015),
      vK = pO.n(lO),
      CO = pO(1056),
      hO = pO(36),
      DO = pO(533),
      MO = pO(1187),
      aK = pO(1063);
    const oO = 6e5;
    class FO extends Error {
      constructor() {
        super(...arguments), this.name = eO.discordLoginCancelledErrorName
      }
    }
    class VO {
      constructor() {
        this.popupWindowPromise = null, this.popupWindowPromiseResolve = null, this.popupWindowPromiseReject = null, this.popupWindow = null, this.popupWindowCheckInterval = null, this.popupWindowTimeout = null, this.bloxdDiscordRefreshTokenKey = "4PSIDTCPM", this.discordRedirectUrl = bK.j[aK.e.clientEnvironment];
        const OO = new URL(this.discordRedirectUrl).origin;
        window.addEventListener("message", (KO => {
          var pO;
          if (KO.origin !== OO || "oauth_authentication_discord" !== (null === (pO = KO.data) || void 0 === pO ? void 0 : pO.type)) return;
          if ("string" !== typeof KO.data.code || !KO.data.code) return void this.failPopup(new FO("Discord authentication was cancelled on Discord"));
          const XO = this.popupWindowPromiseResolve;
          this.resetPopupState(), null === XO || void 0 === XO || XO(KO.data.code)
        }))
      }
      resetPopupState() {
        null !== this.popupWindowCheckInterval && window.clearInterval(this.popupWindowCheckInterval), null !== this.popupWindowTimeout && window.clearTimeout(this.popupWindowTimeout), this.popupWindowCheckInterval = null, this.popupWindowTimeout = null, this.popupWindowPromiseResolve = null, this.popupWindowPromiseReject = null, this.popupWindowPromise = null, this.popupWindow = null
      }
      failPopup(OO) {
        var KO;
        const pO = this.popupWindowPromiseReject;
        null === (KO = this.popupWindow) || void 0 === KO || KO.close(), this.resetPopupState(), null === pO || void 0 === pO || pO(OO)
      }
      openDiscordOAuthWindow() {
        const OO = aK.e.discordClientID;
        return window.open(`https://discord.com/oauth2/authorize?response_type=code&client_id=${OO}&scope=identify%20guilds&redirect_uri=${this.discordRedirectUrl}&integration_type=0`, "oauth_authentication", `popup,width=480,height=720,top=${window.screen.height/2-360},left=${window.screen.width/2-240}`)
      }
      async showDiscordAuthPrompt() {
        return new Promise(((OO, KO) => {
          MO.NotificationProvider.showPromptPopup({
            title: "Discord Login Required",
            confirmText: "Continue",
            confirmTooltip: "Open Discord login window",
            cancelText: "Cancel",
            cancelTooltip: "Cancel Discord login"
          }).getResult().then((pO => {
            pO ? OO() : KO(new FO("Discord login was cancelled"))
          })).catch(KO)
        }))
      }
      signInWithPopup() {
        if (null !== this.popupWindowPromise) return this.popupWindowPromise;
        const OO = new Promise(((OO, KO) => {
          this.popupWindowPromiseResolve = OO, this.popupWindowPromiseReject = KO
        }));
        return this.popupWindowPromise = OO, hO.b.removeItem(this.bloxdDiscordRefreshTokenKey), this.popupWindowTimeout = window.setTimeout((() => {
          this.failPopup(new Error("Discord authentication timed out"))
        }), oO), this.openPopup(OO).catch((KO => {
          this.popupWindowPromise === OO && this.failPopup(KO instanceof Error ? KO : new Error(String(KO)))
        })), OO
      }
      async openPopup(OO) {
        let KO = this.openDiscordOAuthWindow();
        if (!KO) {
          if (await this.showDiscordAuthPrompt(), this.popupWindowPromise !== OO) return;
          KO = this.openDiscordOAuthWindow()
        }
        if (console.log("Discord OAuth window opened:", KO), !KO) throw new Error("Failed to open Discord authentication popup - popup may have been blocked");
        this.popupWindow = KO;
        const pO = window.setInterval((() => {
          KO.closed && this.popupWindowPromise === OO && (window.clearInterval(pO), this.popupWindowCheckInterval = null, window.setTimeout((() => {
            this.popupWindowPromise === OO && this.failPopup(new FO("Discord authentication was cancelled - popup window was closed"))
          }), 1e3))
        }), 200);
        this.popupWindowCheckInterval = pO
      }
      async exchangeAuthorizationCodeForAccessToken(OO, KO) {
        const {
          accessToken: pO,
          refreshToken: XO
        } = await vK()((async () => await (0, eO.postJsonWithMetricsCookiesAndJsonResponse)(`${CO.clientSideServerUrls.indexUrl}/index/discord/log-event`, {
          authorizationCode: OO,
          bloxdClientEnvironment: aK.e.clientEnvironment,
          instanceId: null
        }, {
          retries: 0
        }, KO.getMetricsCookies())), {
          retries: 3
        });
        return console.log("Discord access token received:", XO, this.bloxdDiscordRefreshTokenKey), hO.b.setItem(this.bloxdDiscordRefreshTokenKey, XO), pO
      }
      hasCurrentUser() {
        const OO = hO.b.getItem(this.bloxdDiscordRefreshTokenKey);
        return !(0, DO.I)(OO)
      }
      async getCurrentUser(OO) {
        const KO = hO.b.getItem(this.bloxdDiscordRefreshTokenKey);
        if (!KO) return null;
        let pO;
        try {
          const XO = await vK()((async () => {
            try {
              return await (0, eO.postJsonWithMetricsCookiesAndJsonResponse)(`${CO.clientSideServerUrls.indexUrl}/index/discord/collect-event`, {
                refreshToken: KO
              }, {
                retries: 0
              }, OO.getMetricsCookies())
            } catch (pO) {
              if (LO(pO)) throw new(vK().AbortError)(pO);
              throw pO
            }
          }), {
            retries: 3
          });
          pO = XO.accessToken, hO.b.setItem(this.bloxdDiscordRefreshTokenKey, XO.refreshToken)
        } catch (XO) {
          return LO(XO) ? (hO.b.removeItem(this.bloxdDiscordRefreshTokenKey), null) : (console.error("Failed to refresh Discord access token:", XO), null)
        }
        return {
          accessToken: pO
        }
      }
      signOut() {
        this.failPopup(new FO("Signed out of Discord during login")), hO.b.removeItem(this.bloxdDiscordRefreshTokenKey)
      }
    }

    function LO(OO) {
      return OO instanceof XO.b && 435 === OO.httpCode
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);