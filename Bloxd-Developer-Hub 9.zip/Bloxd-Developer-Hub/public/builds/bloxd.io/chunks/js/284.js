export const id = 284;
export const ids = [284];
export const modules = {
  39640: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(38186),
      bK = pO(39643);
    class eO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2;
        this.maxDepth = pO, this.vMO = [], this._maxBlockCapacity = KO || 64, this._selectionContent = new XO.d(1024), this._creationFunc = OO
      }
      update(OO, KO, pO) {
        bK.c._CreateBlocks(OO, KO, pO, this._maxBlockCapacity, 0, this.maxDepth, this, this._creationFunc)
      }
      GhO(OO) {
        for (let KO = 0; KO < this.blocks.length; KO++) {
          this.blocks[KO].addEntry(OO)
        }
      }
      nKO(OO) {
        for (let KO = 0; KO < this.blocks.length; KO++) {
          this.blocks[KO].removeEntry(OO)
        }
      }
      select(OO, KO) {
        this._selectionContent.reset();
        for (let pO = 0; pO < this.blocks.length; pO++) {
          this.blocks[pO].select(OO, this._selectionContent, KO)
        }
        return KO ? this._selectionContent.concat(this.vMO) : this._selectionContent.concatWithNoDuplicate(this.vMO), this._selectionContent
      }
      intersects(OO, KO, pO) {
        this._selectionContent.reset();
        for (let XO = 0; XO < this.blocks.length; XO++) {
          this.blocks[XO].intersects(OO, KO, this._selectionContent, pO)
        }
        return pO ? this._selectionContent.concat(this.vMO) : this._selectionContent.concatWithNoDuplicate(this.vMO), this._selectionContent
      }
      intersectsRay(OO) {
        this._selectionContent.reset();
        for (let KO = 0; KO < this.blocks.length; KO++) {
          this.blocks[KO].intersectsRay(OO, this._selectionContent)
        }
        return this._selectionContent.concatWithNoDuplicate(this.vMO), this._selectionContent
      }
    }
    eO.CreationFuncForMeshes = (OO, KO) => {
      const pO = OO.hpO();
      !OO.isBlocked && pO.boundingBox.intersectsMinMax(KO.kDO, KO.tDO) && KO.entries.push(OO)
    }, eO.CreationFuncForSubMeshes = (OO, KO) => {
      OO.hpO().boundingBox.intersectsMinMax(KO.kDO, KO.tDO) && KO.entries.push(OO)
    }
  },
  39643: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO
    });
    var XO = pO(35632),
      bK = pO(38404);
    class eO {
      constructor(OO, KO, pO, XO, bK, eO) {
        this.entries = [], this.CDO = new Array, this._capacity = pO, this._depth = XO, this._maxDepth = bK, this._creationFunc = eO, this._minPoint = OO, this._maxPoint = KO, this.CDO.push(OO.clone()), this.CDO.push(KO.clone()), this.CDO.push(OO.clone()), this.CDO[2].x = KO.x, this.CDO.push(OO.clone()), this.CDO[3].y = KO.y, this.CDO.push(OO.clone()), this.CDO[4].z = KO.z, this.CDO.push(KO.clone()), this.CDO[5].z = OO.z, this.CDO.push(KO.clone()), this.CDO[6].x = OO.x, this.CDO.push(KO.clone()), this.CDO[7].y = OO.y
      }
      get YO() {
        return this._capacity
      }
      get kDO() {
        return this._minPoint
      }
      get tDO() {
        return this._maxPoint
      }
      addEntry(OO) {
        if (this.blocks)
          for (let KO = 0; KO < this.blocks.length; KO++) {
            this.blocks[KO].addEntry(OO)
          } else this._creationFunc(OO, this), this.entries.length > this.YO && this._depth < this._maxDepth && this.createInnerBlocks()
      }
      removeEntry(OO) {
        if (this.blocks) {
          for (let KO = 0; KO < this.blocks.length; KO++) {
            this.blocks[KO].removeEntry(OO)
          }
          return
        }
        const KO = this.entries.indexOf(OO);
        KO > -1 && this.entries.splice(KO, 1)
      }
      addEntries(OO) {
        for (let KO = 0; KO < OO.length; KO++) {
          const pO = OO[KO];
          this.addEntry(pO)
        }
      }
      select(OO, KO, pO) {
        if (bK.c.IsInFrustum(this.CDO, OO)) {
          if (this.blocks) {
            for (let XO = 0; XO < this.blocks.length; XO++) {
              this.blocks[XO].select(OO, KO, pO)
            }
            return
          }
          pO ? KO.concat(this.entries) : KO.concatWithNoDuplicate(this.entries)
        }
      }
      intersects(OO, KO, pO, XO) {
        if (bK.c.IntersectsSphere(this._minPoint, this._maxPoint, OO, KO)) {
          if (this.blocks) {
            for (let bK = 0; bK < this.blocks.length; bK++) {
              this.blocks[bK].intersects(OO, KO, pO, XO)
            }
            return
          }
          XO ? pO.concat(this.entries) : pO.concatWithNoDuplicate(this.entries)
        }
      }
      intersectsRay(OO, KO) {
        if (OO.intersectsBoxMinMax(this._minPoint, this._maxPoint)) {
          if (this.blocks) {
            for (let pO = 0; pO < this.blocks.length; pO++) {
              this.blocks[pO].intersectsRay(OO, KO)
            }
            return
          }
          KO.concatWithNoDuplicate(this.entries)
        }
      }
      createInnerBlocks() {
        eO._CreateBlocks(this._minPoint, this._maxPoint, this.entries, this._capacity, this._depth, this._maxDepth, this, this._creationFunc), this.entries.splice(0)
      }
      static _CreateBlocks(OO, KO, pO, bK, lO, vK, CO, hO) {
        CO.blocks = new Array;
        const DO = new XO.o((KO.x - OO.x) / 2, (KO.y - OO.y) / 2, (KO.z - OO.z) / 2);
        for (let XO = 0; XO < 2; XO++)
          for (let KO = 0; KO < 2; KO++)
            for (let MO = 0; MO < 2; MO++) {
              const aK = OO.add(DO.multiplyByFloats(XO, KO, MO)),
                oO = OO.add(DO.multiplyByFloats(XO + 1, KO + 1, MO + 1)),
                FO = new eO(aK, oO, bK, lO + 1, vK, hO);
              FO.addEntries(pO), CO.blocks.push(FO)
            }
      }
    }
  },
  39651: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => DO
    });
    var XO = pO(38170),
      bK = pO(35632),
      eO = pO(38537),
      lO = pO(39588),
      vK = pO(38250),
      CO = pO(35653),
      hO = pO(39640);
    class DO {
      constructor(OO) {
        this.name = vK.d.NAME_OCTREE, this.checksIsEnabled = !0, this._tempRay = new lO.y(bK.o.Zero(), new bK.o(1, 1, 1)), (OO = OO || CO.c.LastCreatedScene) && (this.Ce = OO, this.Ce.getActiveMeshCandidates = () => this.getActiveMeshCandidates(), this.Ce.getActiveSubMeshCandidates = OO => this.getActiveSubMeshCandidates(OO), this.Ce.getCollidingSubMeshCandidates = (OO, KO) => this.getCollidingSubMeshCandidates(OO, KO), this.Ce.getIntersectingSubMeshCandidates = (OO, KO) => this.getIntersectingSubMeshCandidates(OO, KO))
      }
      register() {
        this.Ce.onMeshRemovedObservable.add((OO => {
          const KO = this.Ce.selectionOctree;
          if (void 0 !== KO && null !== KO) {
            const pO = KO.vMO.indexOf(OO); - 1 !== pO && KO.vMO.splice(pO, 1)
          }
        })), this.Ce.onMeshImportedObservable.add((OO => {
          const KO = this.Ce.selectionOctree;
          void 0 !== KO && null !== KO && KO.GhO(OO)
        }))
      }
      getActiveMeshCandidates() {
        return this.Ce.VDO?.select(this.Ce.frustumPlanes) || this.Ce._getDefaultMeshCandidates()
      }
      getActiveSubMeshCandidates(OO) {
        if (OO._submeshesOctree && OO.useOctreeForRenderingSelection) {
          return OO._submeshesOctree.select(this.Ce.frustumPlanes)
        }
        return this.Ce._getDefaultSubMeshCandidates(OO)
      }
      getIntersectingSubMeshCandidates(OO, KO) {
        if (OO._submeshesOctree && OO.useOctreeForPicking) {
          lO.y.TransformToRef(KO, OO.getWorldMatrix(), this._tempRay);
          return OO._submeshesOctree.intersectsRay(this._tempRay)
        }
        return this.Ce._getDefaultSubMeshCandidates(OO)
      }
      getCollidingSubMeshCandidates(OO, KO) {
        if (OO._submeshesOctree && OO.useOctreeForCollisions) {
          const pO = KO._velocityWorldLength + Math.max(KO._radius.x, KO._radius.y, KO._radius.z);
          return OO._submeshesOctree.intersects(KO._basePointWorld, pO)
        }
        return this.Ce._getDefaultSubMeshCandidates(OO)
      }
      rebuild() {}
      dispose() {}
    }
    let MO = !1;
    MO || (MO = !0, XO.e.prototype.createOrUpdateSelectionOctree = function() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 64,
        KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2,
        pO = this._getComponent(vK.d.NAME_OCTREE);
      pO || (pO = new DO(this), this.cDO(pO)), this.VDO || (this.VDO = new hO.e(hO.e.CreationFuncForMeshes, OO, KO));
      const XO = this.getWorldExtends();
      return this.VDO.update(XO.min, XO.max, this.meshes), this.VDO
    }, Object.defineProperty(XO.e.prototype, "selectionOctree", {
      get: function() {
        return this.VDO
      },
      enumerable: !0,
      configurable: !0
    }), eO.d.prototype.createOrUpdateSubmeshesOctree = function() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 64,
        KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
      const pO = this.JKO();
      let XO = pO._getComponent(vK.d.NAME_OCTREE);
      XO || (XO = new DO(pO), pO.cDO(XO)), this._submeshesOctree || (this._submeshesOctree = new hO.e(hO.e.CreationFuncForSubMeshes, OO, KO)), this.computeWorldMatrix(!0);
      const bK = this.hpO().boundingBox;
      return this._submeshesOctree.update(bK.minimumWorld, bK.maximumWorld, this.au), this._submeshesOctree
    })
  },
  39588: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => jK,
      d: () => VO,
      e: () => FO,
      i: () => oO,
      k: () => uO,
      n: () => gK,
      q: () => NO,
      u: () => yK,
      x: () => IO,
      y: () => MO
    });
    var XO = pO(35639),
      bK = pO(35632),
      eO = pO(35641),
      lO = pO(38391),
      vK = pO(38209),
      CO = pO(35653),
      hO = pO(38269);
    const DO = {
      internalPickerForMesh: void 0
    };
    class MO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Number.MAX_VALUE,
          bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : XO.c;
        this.origin = OO, this.direction = KO, this.length = pO, this.epsilon = bK
      }
      clone() {
        return new MO(this.origin.clone(), this.direction.clone(), this.length)
      }
      intersectsBoxMinMax(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        const XO = MO._TmpVector3[0].rvO(OO.x - pO, OO.y - pO, OO.z - pO),
          bK = MO._TmpVector3[1].rvO(KO.x + pO, KO.y + pO, KO.z + pO);
        let eO, lO, vK, CO, hO = 0,
          DO = Number.MAX_VALUE;
        if (Math.abs(this.direction.x) < 1e-7) {
          if (this.origin.x < XO.x || this.origin.x > bK.x) return !1
        } else if (eO = 1 / this.direction.x, lO = (XO.x - this.origin.x) * eO, vK = (bK.x - this.origin.x) * eO, vK === -1 / 0 && (vK = 1 / 0), lO > vK && (CO = lO, lO = vK, vK = CO), hO = Math.max(lO, hO), DO = Math.min(vK, DO), hO > DO) return !1;
        if (Math.abs(this.direction.y) < 1e-7) {
          if (this.origin.y < XO.y || this.origin.y > bK.y) return !1
        } else if (eO = 1 / this.direction.y, lO = (XO.y - this.origin.y) * eO, vK = (bK.y - this.origin.y) * eO, vK === -1 / 0 && (vK = 1 / 0), lO > vK && (CO = lO, lO = vK, vK = CO), hO = Math.max(lO, hO), DO = Math.min(vK, DO), hO > DO) return !1;
        if (Math.abs(this.direction.z) < 1e-7) {
          if (this.origin.z < XO.z || this.origin.z > bK.z) return !1
        } else if (eO = 1 / this.direction.z, lO = (XO.z - this.origin.z) * eO, vK = (bK.z - this.origin.z) * eO, vK === -1 / 0 && (vK = 1 / 0), lO > vK && (CO = lO, lO = vK, vK = CO), hO = Math.max(lO, hO), DO = Math.min(vK, DO), hO > DO) return !1;
        return !0
      }
      intersectsBox(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return this.intersectsBoxMinMax(OO.minimum, OO.maximum, KO)
      }
      intersectsSphere(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        const pO = OO.center.x - this.origin.x,
          XO = OO.center.y - this.origin.y,
          bK = OO.center.z - this.origin.z,
          eO = pO * pO + XO * XO + bK * bK,
          lO = OO.radius + KO,
          vK = lO * lO;
        if (eO <= vK) return !0;
        const CO = pO * this.direction.x + XO * this.direction.y + bK * this.direction.z;
        if (CO < 0) return !1;
        return eO - CO * CO <= vK
      }
      intersectsTriangle(OO, KO, pO) {
        const XO = MO._TmpVector3[0],
          eO = MO._TmpVector3[1],
          vK = MO._TmpVector3[2],
          CO = MO._TmpVector3[3],
          hO = MO._TmpVector3[4];
        KO.subtractToRef(OO, XO), pO.subtractToRef(OO, eO), bK.o.CrossToRef(this.direction, eO, vK);
        const DO = bK.o.Dot(XO, vK);
        if (0 === DO) return null;
        const aK = 1 / DO;
        this.origin.subtractToRef(OO, CO);
        const oO = bK.o.Dot(CO, vK) * aK;
        if (oO < -this.epsilon || oO > 1 + this.epsilon) return null;
        bK.o.CrossToRef(CO, XO, hO);
        const FO = bK.o.Dot(this.direction, hO) * aK;
        if (FO < -this.epsilon || oO + FO > 1 + this.epsilon) return null;
        const VO = bK.o.Dot(eO, hO) * aK;
        return VO > this.length || VO < 0 ? null : new lO.d(1 - oO - FO, oO, VO)
      }
      intersectsPlane(OO) {
        let KO;
        const pO = bK.o.Dot(OO.normal, this.direction);
        if (Math.abs(pO) < 9.99999997475243e-7) return null;
        {
          const XO = bK.o.Dot(OO.normal, this.origin);
          return KO = (-OO.d - XO) / pO, KO < 0 ? KO < -9.99999997475243e-7 ? null : 0 : KO
        }
      }
      intersectsAxis(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        switch (OO) {
          case "y": {
            const OO = (this.origin.y - KO) / this.direction.y;
            return OO > 0 ? null : new bK.o(this.origin.x + this.direction.x * -OO, KO, this.origin.z + this.direction.z * -OO)
          }
          case "x": {
            const OO = (this.origin.x - KO) / this.direction.x;
            return OO > 0 ? null : new bK.o(KO, this.origin.y + this.direction.y * -OO, this.origin.z + this.direction.z * -OO)
          }
          case "z": {
            const OO = (this.origin.z - KO) / this.direction.z;
            return OO > 0 ? null : new bK.o(this.origin.x + this.direction.x * -OO, this.origin.y + this.direction.y * -OO, KO)
          }
          default:
            return null
        }
      }
      iMO(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          eO = arguments.length > 4 ? arguments[4] : void 0,
          lO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
        const vK = bK.j.Matrix[0];
        return OO.getWorldMatrix().invertToRef(vK), this._tmpRay ? MO.TransformToRef(this, vK, this._tmpRay) : this._tmpRay = MO.Transform(this, vK), OO.intersects(this._tmpRay, KO, pO, XO, eO, lO)
      }
      intersectsMeshes(OO, KO, pO) {
        pO ? pO.length = 0 : pO = [];
        for (let XO = 0; XO < OO.length; XO++) {
          const bK = this.iMO(OO[XO], KO);
          bK.hit && pO.push(bK)
        }
        return pO.sort(this._comparePickingInfo), pO
      }
      _comparePickingInfo(OO, KO) {
        return OO.distance < KO.distance ? -1 : OO.distance > KO.distance ? 1 : 0
      }
      intersectionSegment(OO, KO, pO) {
        const XO = this.origin,
          eO = bK.j.WX[0],
          lO = bK.j.WX[1],
          vK = bK.j.WX[2],
          CO = bK.j.WX[3];
        KO.subtractToRef(OO, eO), this.direction.scaleToRef(MO._Rayl, vK), XO.addToRef(vK, lO), OO.subtractToRef(XO, CO);
        const hO = bK.o.Dot(eO, eO),
          DO = bK.o.Dot(eO, vK),
          aK = bK.o.Dot(vK, vK),
          oO = bK.o.Dot(eO, CO),
          FO = bK.o.Dot(vK, CO),
          VO = hO * aK - DO * DO;
        let LO, QO, zK = VO,
          AO = VO;
        VO < MO._Smallnum ? (LO = 0, zK = 1, QO = FO, AO = aK) : (LO = DO * FO - aK * oO, QO = hO * FO - DO * oO, LO < 0 ? (LO = 0, QO = FO, AO = aK) : LO > zK && (LO = zK, QO = FO + DO, AO = aK)), QO < 0 ? (QO = 0, -oO < 0 ? LO = 0 : -oO > hO ? LO = zK : (LO = -oO, zK = hO)) : QO > AO && (QO = AO, -oO + DO < 0 ? LO = 0 : -oO + DO > hO ? LO = zK : (LO = -oO + DO, zK = hO));
        const fO = Math.abs(LO) < MO._Smallnum ? 0 : LO / zK,
          dO = Math.abs(QO) < MO._Smallnum ? 0 : QO / AO,
          TO = bK.j.WX[4];
        vK.scaleToRef(dO, TO);
        const NO = bK.j.WX[5];
        eO.scaleToRef(fO, NO), NO.addInPlace(CO);
        const IO = bK.j.WX[6];
        NO.subtractToRef(TO, IO);
        return dO > 0 && dO <= this.length && IO.lengthSquared() < pO * pO ? NO.length() : -1
      }
      update(OO, KO, pO, XO, eO, lO, vK) {
        if (arguments.length > 7 && void 0 !== arguments[7] && arguments[7]) {
          MO._RayDistant || (MO._RayDistant = MO.Zero()), MO._RayDistant.unprojectRayToRef(OO, KO, pO, XO, bK.c.IdentityReadOnly, lO, vK);
          const CO = bK.j.Matrix[0];
          eO.invertToRef(CO), MO.TransformToRef(MO._RayDistant, CO, this)
        } else this.unprojectRayToRef(OO, KO, pO, XO, eO, lO, vK);
        return this
      }
      static Zero() {
        return new MO(bK.o.Zero(), bK.o.Zero())
      }
      static CreateNew(OO, KO, pO, XO, bK, eO, lO) {
        return MO.Zero().update(OO, KO, pO, XO, bK, eO, lO)
      }
      static CreateNewFromTo(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : bK.c.IdentityReadOnly;
        const XO = new MO(new bK.o(0, 0, 0), new bK.o(0, 0, 0));
        return MO.CreateFromToToRef(OO, KO, XO, pO)
      }
      static CreateFromToToRef(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : bK.c.IdentityReadOnly;
        pO.origin.NhO(OO);
        const eO = KO.subtractToRef(OO, pO.direction),
          lO = Math.sqrt(eO.x * eO.x + eO.y * eO.y + eO.z * eO.z);
        return pO.length = lO, pO.direction.normalize(), MO.TransformToRef(pO, XO, pO)
      }
      static Transform(OO, KO) {
        const pO = new MO(new bK.o(0, 0, 0), new bK.o(0, 0, 0));
        return MO.TransformToRef(OO, KO, pO), pO
      }
      static TransformToRef(OO, KO, pO) {
        bK.o.TransformCoordinatesToRef(OO.origin, KO, pO.origin), bK.o.TransformNormalToRef(OO.direction, KO, pO.direction), pO.length = OO.length, pO.epsilon = OO.epsilon;
        const XO = pO.direction,
          eO = XO.length();
        if (0 !== eO && 1 !== eO) {
          const OO = 1 / eO;
          XO.x *= OO, XO.y *= OO, XO.z *= OO, pO.length *= eO
        }
        return pO
      }
      unprojectRayToRef(OO, KO, pO, XO, eO, lO, vK) {
        const hO = bK.j.Matrix[0];
        eO.multiplyToRef(lO, hO), hO.multiplyToRef(vK, hO), hO.invert();
        const DO = CO.c.LastCreatedEngine,
          MO = bK.j.WX[0];
        MO.x = OO / pO * 2 - 1, MO.y = -(KO / XO * 2 - 1), MO.z = DO?.BhO ? 1 : DO?.isNDCHalfZRange ? 0 : -1;
        const aK = bK.j.WX[1].rvO(MO.x, MO.y, 1 - 1e-8),
          oO = bK.j.WX[2],
          FO = bK.j.WX[3];
        bK.o.TransformCoordinatesToRef(MO, hO, oO), bK.o.TransformCoordinatesToRef(aK, hO, FO), this.origin.NhO(oO), FO.subtractToRef(oO, this.direction), this.direction.normalize()
      }
    }

    function aK(OO, KO, pO, XO, bK) {
      let eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
      const lO = MO.Zero();
      return oO(OO, KO, pO, XO, lO, bK, eO), lO
    }

    function oO(OO, KO, pO, XO, eO, lO) {
      let vK = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
        CO = arguments.length > 7 && void 0 !== arguments[7] && arguments[7];
      const hO = OO.qb();
      if (!lO && !(lO = OO.activeCamera) && !(lO = OO.cameraToUseForPointers)) return OO;
      const DO = lO.viewport,
        MO = hO.getRenderHeight(),
        {
          x: aK,
          y: oO,
          width: FO,
          height: VO
        } = DO.toGlobal(hO.getRenderWidth(), MO),
        LO = 1 / hO.getHardwareScalingLevel();
      return KO = KO * LO - aK, pO = pO * LO - (MO - oO - VO), eO.update(KO, pO, FO, VO, XO || bK.c.IdentityReadOnly, vK ? bK.c.IdentityReadOnly : lO.getViewMatrix(), lO.getProjectionMatrix(), CO), OO
    }

    function FO(OO, KO, pO, XO) {
      const bK = MO.Zero();
      return VO(OO, KO, pO, bK, XO), bK
    }

    function VO(OO, KO, pO, XO, eO) {
      if (!vK.c) return OO;
      const lO = OO.qb();
      if (!eO && !(eO = OO.activeCamera) && !(eO = OO.cameraToUseForPointers)) throw new Error("Active camera not set");
      const CO = eO.viewport,
        hO = lO.getRenderHeight(),
        {
          x: DO,
          y: MO,
          width: aK,
          height: oO
        } = CO.toGlobal(lO.getRenderWidth(), hO),
        FO = bK.c.Identity(),
        VO = 1 / lO.getHardwareScalingLevel();
      return KO = KO * VO - DO, pO = pO * VO - (hO - MO - oO), XO.update(KO, pO, aK, oO, FO, FO, eO.getProjectionMatrix()), OO
    }

    function LO(OO, KO, pO, XO, bK, eO, lO, vK) {
      return QO(OO, pO, XO, KO(XO, pO.enableDistantPicking), bK, eO, lO, vK)
    }

    function QO(OO, KO, pO, XO, bK, eO, lO, vK) {
      const CO = KO.intersects(XO, bK, lO, eO, pO, vK);
      return CO && CO.hit ? !bK && null != OO && CO.distance >= OO.distance ? null : CO : null
    }

    function zK(OO, KO) {
      return "InstancedLinesMesh" === OO || "LinesMesh" === OO ? KO.intersectionThreshold : 0
    }

    function AO(OO) {
      const KO = OO.getClassName();
      if ("GreasedLineMesh" === KO) return {
        rawBoundingInfo: null,
        intersectionThreshold: 0
      };
      const pO = OO.rawBoundingInfo;
      return {
        rawBoundingInfo: pO,
        intersectionThreshold: pO ? zK(KO, OO) : 0
      }
    }

    function fO(OO, KO, pO, XO, bK) {
      const eO = OO(pO, KO.enableDistantPicking);
      return eO.intersectsSphere(XO.QDO, bK) && eO.intersectsBox(XO.boundingBox, bK) ? eO : null
    }

    function dO(OO, KO, pO, XO, eO, lO) {
      let CO = null;
      const hO = !!(OO.activeCameras && OO.activeCameras.length > 1 && OO.cameraToUseForPointers !== OO.activeCamera),
        MO = OO.cameraToUseForPointers || OO.activeCamera,
        aK = DO.internalPickerForMesh || LO,
        oO = aK === LO;
      for (let vK = 0; vK < OO.meshes.length; vK++) {
        const DO = OO.meshes[vK];
        if (pO) {
          if (!pO(DO, -1)) continue
        } else if (!DO.isEnabled() || !DO.isVisible || !DO.De) continue;
        const FO = hO && DO.isWorldMatrixCameraDependent(),
          VO = DO.computeWorldMatrix(FO, MO);
        if (DO.hasThinInstances && DO.fCO) {
          const OO = aK(CO, KO, DO, VO, !0, !0, lO);
          if (OO) {
            if (eO) return OO;
            const {
              rawBoundingInfo: vK,
              intersectionThreshold: hO
            } = AO(DO), MO = DO._thinInstanceDataStorage.matrixData;
            if (MO) {
              const OO = bK.j.Matrix[0],
                FO = bK.j.Matrix[1],
                LO = Math.min(DO.hlO, MO.length >> 4);
              for (let zK = 0; zK < LO; zK++) {
                if (pO && !pO(DO, zK)) continue;
                bK.c.FromArrayToRef(MO, zK << 4, OO), OO.multiplyToRef(VO, FO);
                const LO = oO && vK ? fO(KO, DO, FO, vK, hO) : null;
                if (oO && vK && !LO) continue;
                const AO = oO && LO ? QO(CO, DO, FO, LO, XO, eO, lO, !0) : aK(CO, KO, DO, FO, XO, eO, lO, !0);
                if (AO && (CO = AO, CO.thinInstanceIndex = zK, XO)) return CO
              }
            }
          }
        } else {
          const OO = aK(CO, KO, DO, VO, XO, eO, lO);
          if (OO && (CO = OO, XO)) return CO
        }
      }
      return CO || new vK.c
    }

    function TO(OO, KO, pO, XO) {
      if (!vK.c) return null;
      const eO = [],
        lO = !!(OO.activeCameras && OO.activeCameras.length > 1 && OO.cameraToUseForPointers !== OO.activeCamera),
        CO = OO.cameraToUseForPointers || OO.activeCamera,
        hO = DO.internalPickerForMesh || LO,
        MO = hO === LO;
      for (let vK = 0; vK < OO.meshes.length; vK++) {
        const DO = OO.meshes[vK];
        if (pO) {
          if (!pO(DO, -1)) continue
        } else if (!DO.isEnabled() || !DO.isVisible || !DO.De) continue;
        const aK = lO && DO.isWorldMatrixCameraDependent(),
          oO = DO.computeWorldMatrix(aK, CO);
        if (DO.hasThinInstances && DO.fCO) {
          if (hO(null, KO, DO, oO, !0, !0, XO)) {
            const {
              rawBoundingInfo: OO,
              intersectionThreshold: lO
            } = AO(DO), vK = DO._thinInstanceDataStorage.matrixData;
            if (vK) {
              const CO = bK.j.Matrix[0],
                aK = bK.j.Matrix[1],
                FO = Math.min(DO.hlO, vK.length >> 4);
              for (let VO = 0; VO < FO; VO++) {
                if (pO && !pO(DO, VO)) continue;
                bK.c.FromArrayToRef(vK, VO << 4, CO), CO.multiplyToRef(oO, aK);
                const FO = MO && OO ? fO(KO, DO, aK, OO, lO) : null;
                if (MO && OO && !FO) continue;
                const LO = MO && FO ? QO(null, DO, aK, FO, !1, !1, XO, !0) : hO(null, KO, DO, aK, !1, !1, XO, !0);
                LO && (LO.thinInstanceIndex = VO, eO.push(LO))
              }
            }
          }
        } else {
          const OO = hO(null, KO, DO, oO, !1, !1, XO);
          OO && eO.push(OO)
        }
      }
      return eO
    }

    function NO(OO, KO, pO, XO, eO, lO) {
      if (!vK.c) return null;
      const CO = dO(OO, (XO => (OO._tempPickingRay || (OO._tempPickingRay = MO.Zero()), oO(OO, KO, pO, XO, OO._tempPickingRay, lO || null), OO._tempPickingRay)), XO, eO, !0);
      return CO && (CO.ray = aK(OO, KO, pO, bK.c.Identity(), lO || null)), CO
    }

    function IO(OO, KO, pO, XO, eO, lO, vK) {
      const CO = dO(OO, ((XO, bK) => (OO._tempPickingRay || (OO._tempPickingRay = MO.Zero()), oO(OO, KO, pO, XO, OO._tempPickingRay, lO || null, !1, bK), OO._tempPickingRay)), XO, eO, !1, vK);
      return CO && (CO.ray = aK(OO, KO, pO, bK.c.Identity(), lO || null)), CO
    }

    function yK(OO, KO, pO, XO, eO) {
      const lO = dO(OO, (pO => (OO._pickWithRayInverseMatrix || (OO._pickWithRayInverseMatrix = bK.c.Identity()), pO.invertToRef(OO._pickWithRayInverseMatrix), OO._cachedRayForTransform || (OO._cachedRayForTransform = MO.Zero()), MO.TransformToRef(KO, OO._pickWithRayInverseMatrix, OO._cachedRayForTransform), OO._cachedRayForTransform)), pO, XO, !1, eO);
      return lO && (lO.ray = KO), lO
    }

    function gK(OO, KO, pO, XO, bK, eO) {
      return TO(OO, (XO => aK(OO, KO, pO, XO, bK || null)), XO, eO)
    }

    function uO(OO, KO, pO, XO) {
      return TO(OO, (pO => (OO._pickWithRayInverseMatrix || (OO._pickWithRayInverseMatrix = bK.c.Identity()), pO.invertToRef(OO._pickWithRayInverseMatrix), OO._cachedRayForTransform || (OO._cachedRayForTransform = MO.Zero()), MO.TransformToRef(KO, OO._pickWithRayInverseMatrix, OO._cachedRayForTransform), OO._cachedRayForTransform)), pO, XO)
    }

    function EO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 100,
        XO = arguments.length > 3 ? arguments[3] : void 0,
        eO = arguments.length > 4 ? arguments[4] : void 0;
      XO || (XO = OO.getWorldMatrix()), KO.length = pO, eO ? KO.origin.NhO(eO) : KO.origin.NhO(OO.position);
      const lO = bK.j.WX[2];
      lO.set(0, 0, OO._scene.useRightHandedSystem ? -1 : 1);
      const vK = bK.j.WX[3];
      return bK.o.TransformNormalToRef(lO, XO, vK), bK.o.NormalizeToRef(vK, KO.direction), KO
    }

    function jK(OO, KO) {
      KO && (KO.prototype.getForwardRay = function() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 100,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        return EO(this, new MO(bK.o.Zero(), bK.o.Zero(), OO), OO, KO, pO)
      }, KO.prototype.getForwardRayToRef = function(OO) {
        return EO(this, OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 100, arguments.length > 2 ? arguments[2] : void 0, arguments.length > 3 ? arguments[3] : void 0)
      }), OO && (hO.b._IsPickingAvailable = !0, OO.prototype.createPickingRay = function(OO, KO, pO, XO) {
        return aK(this, OO, KO, pO, XO, arguments.length > 4 && void 0 !== arguments[4] && arguments[4])
      })
    }
    MO._TmpVector3 = (0, eO.d)(6, bK.o.Zero), MO._RayDistant = MO.Zero(), MO._Smallnum = 1e-8, MO._Rayl = 1e9
  },
  39580: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO.y
    });
    var XO = pO(38170),
      bK = pO(38294),
      eO = pO(39588);
    let lO = !1;
    lO || (lO = !0, (0, eO.b)(XO.e, bK.c), XO.e.prototype.createPickingRayToRef = function(OO, KO, pO, XO, bK) {
      let lO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
        vK = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
      return (0, eO.i)(this, OO, KO, pO, XO, bK, lO, vK)
    }, XO.e.prototype.createPickingRayInCameraSpace = function(OO, KO, pO) {
      return (0, eO.e)(this, OO, KO, pO)
    }, XO.e.prototype.createPickingRayInCameraSpaceToRef = function(OO, KO, pO, XO) {
      return (0, eO.d)(this, OO, KO, pO, XO)
    }, XO.e.prototype.pickWithBoundingInfo = function(OO, KO, pO, XO, bK) {
      return (0, eO.q)(this, OO, KO, pO, XO, bK)
    }, XO.e.prototype.Kp = function(OO, KO, pO, XO, bK, lO) {
      let vK = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
      return (0, eO.x)(this, OO, KO, pO, XO, bK, lO, vK)
    }, XO.e.prototype.pickWithRay = function(OO, KO, pO, XO) {
      return (0, eO.u)(this, OO, KO, pO, XO)
    }, XO.e.prototype.multiPick = function(OO, KO, pO, XO, bK) {
      return (0, eO.n)(this, OO, KO, pO, XO, bK)
    }, XO.e.prototype.multiPickWithRay = function(OO, KO, pO) {
      return (0, eO.k)(this, OO, KO, pO)
    })
  },
  39592: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35632),
      lO = pO(38347),
      vK = pO(39601),
      CO = pO(38301),
      hO = pO(35676);
    let DO = (() => {
        var OO;
        let KO, pO, CO, hO, DO, MO, aK, oO, FO = vK.e,
          VO = [],
          LO = [],
          QO = [],
          zK = [],
          AO = [],
          fO = [],
          dO = [],
          TO = [],
          NO = [],
          IO = [],
          yK = [],
          gK = [],
          uO = [];
        return OO = class extends FO {
          get shadowFrustumSize() {
            return this._shadowFrustumSize
          }
          set shadowFrustumSize(OO) {
            this._shadowFrustumSize = OO, this.forceProjectionMatrixCompute()
          }
          get shadowOrthoScale() {
            return this._shadowOrthoScale
          }
          set shadowOrthoScale(OO) {
            this._shadowOrthoScale = OO, this.forceProjectionMatrixCompute()
          }
          get orthoLeft() {
            return this._orthoLeft
          }
          set orthoLeft(OO) {
            this._orthoLeft = OO
          }
          get orthoRight() {
            return this._orthoRight
          }
          set orthoRight(OO) {
            this._orthoRight = OO
          }
          get orthoTop() {
            return this._orthoTop
          }
          set orthoTop(OO) {
            this._orthoTop = OO
          }
          get orthoBottom() {
            return this._orthoBottom
          }
          set orthoBottom(OO) {
            this._orthoBottom = OO
          }
          constructor(OO, KO, pO, bK) {
            super(OO, pO, bK), this._shadowFrustumSize = ((0, XO.i)(this, VO), 0), this._shadowOrthoScale = .1, this.autoUpdateExtends = (0, XO.i)(this, LO, !0), this.autoCalcShadowZBounds = ((0, XO.i)(this, QO), (0, XO.i)(this, zK, !1)), this._orthoLeft = ((0, XO.i)(this, AO), (0, XO.i)(this, fO, Number.MAX_VALUE)), this._orthoRight = ((0, XO.i)(this, dO), (0, XO.i)(this, TO, Number.MIN_VALUE)), this._orthoTop = ((0, XO.i)(this, NO), (0, XO.i)(this, IO, Number.MIN_VALUE)), this._orthoBottom = ((0, XO.i)(this, yK), (0, XO.i)(this, gK, Number.MAX_VALUE)), (0, XO.i)(this, uO), this.position = KO.scale(-1), this.direction = KO
          }
          getClassName() {
            return "DirectionalLight"
          }
          getTypeID() {
            return lO.b.LIGHTTYPEID_DIRECTIONALLIGHT
          }
          _setDefaultShadowProjectionMatrix(OO, KO, pO) {
            this.shadowFrustumSize > 0 ? this._setDefaultFixedFrustumShadowProjectionMatrix(OO) : this._setDefaultAutoExtendShadowProjectionMatrix(OO, KO, pO)
          }
          _setDefaultFixedFrustumShadowProjectionMatrix(OO) {
            const KO = this.JKO().activeCamera;
            eO.c.OrthoLHToRef(this.shadowFrustumSize, this.shadowFrustumSize, void 0 !== this.shadowMinZ ? this.shadowMinZ : KO ? KO.minZ : 0, void 0 !== this.shadowMaxZ ? this.shadowMaxZ : KO ? KO.maxZ : 1e4, OO, this.JKO().qb().isNDCHalfZRange)
          }
          _setDefaultAutoExtendShadowProjectionMatrix(OO, KO, pO) {
            const XO = this.JKO().activeCamera;
            if (this.autoUpdateExtends || this._orthoLeft === Number.MAX_VALUE) {
              const OO = eO.o.Zero();
              this._orthoLeft = Number.MAX_VALUE, this._orthoRight = -Number.MAX_VALUE, this._orthoTop = -Number.MAX_VALUE, this._orthoBottom = Number.MAX_VALUE;
              let XO = Number.MAX_VALUE,
                bK = -Number.MAX_VALUE;
              for (let lO = 0; lO < pO.length; lO++) {
                const vK = pO[lO];
                if (!vK) continue;
                const CO = vK.hpO().boundingBox;
                for (let pO = 0; pO < CO.vectorsWorld.length; pO++) eO.o.TransformCoordinatesToRef(CO.vectorsWorld[pO], KO, OO), OO.x < this._orthoLeft && (this._orthoLeft = OO.x), OO.y < this._orthoBottom && (this._orthoBottom = OO.y), OO.x > this._orthoRight && (this._orthoRight = OO.x), OO.y > this._orthoTop && (this._orthoTop = OO.y), this.autoCalcShadowZBounds && (OO.z < XO && (XO = OO.z), OO.z > bK && (bK = OO.z))
              }
              this.autoCalcShadowZBounds && (this._shadowMinZ = XO, this._shadowMaxZ = bK)
            }
            const bK = this._orthoRight - this._orthoLeft,
              lO = this._orthoTop - this._orthoBottom,
              vK = void 0 !== this.shadowMinZ ? this.shadowMinZ : XO?.minZ || 0,
              CO = void 0 !== this.shadowMaxZ ? this.shadowMaxZ : XO?.maxZ || 1e4,
              hO = this.JKO().qb().BhO;
            eO.c.OrthoOffCenterLHToRef(this._orthoLeft - bK * this.shadowOrthoScale, this._orthoRight + bK * this.shadowOrthoScale, this._orthoBottom - lO * this.shadowOrthoScale, this._orthoTop + lO * this.shadowOrthoScale, hO ? CO : vK, hO ? vK : CO, OO, this.JKO().qb().isNDCHalfZRange)
          }
          _buildUniformLayout() {
            this._uniformBuffer.addUniform("vLightData", 4), this._uniformBuffer.addUniform("vLightDiffuse", 4), this._uniformBuffer.addUniform("vLightSpecular", 4), this._uniformBuffer.addUniform("shadowsInfo", 3), this._uniformBuffer.addUniform("depthValues", 2), this._uniformBuffer.create()
          }
          transferToEffect(OO, KO) {
            return this.computeTransformedInformation() ? (this._uniformBuffer.updateFloat4("vLightData", this.transformedDirection.x, this.transformedDirection.y, this.transformedDirection.z, 1, KO), this) : (this._uniformBuffer.updateFloat4("vLightData", this.direction.x, this.direction.y, this.direction.z, 1, KO), this)
          }
          transferToNodeMaterialEffect(OO, KO) {
            return this.computeTransformedInformation() ? (OO.setFloat3(KO, this.transformedDirection.x, this.transformedDirection.y, this.transformedDirection.z), this) : (OO.setFloat3(KO, this.direction.x, this.direction.y, this.direction.z), this)
          }
          getDepthMinZ(OO) {
            const KO = this._scene.qb();
            return !KO.BhO && KO.isNDCHalfZRange ? 0 : 1
          }
          getDepthMaxZ(OO) {
            const KO = this._scene.qb();
            return KO.BhO && KO.isNDCHalfZRange ? 0 : 1
          }
          prepareLightSpecificDefines(OO, KO) {
            OO["DIRLIGHT" + KO] = !0
          }
        }, (() => {
          const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(FO[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.M)()], pO = [(0, bK.M)()], CO = [(0, bK.M)()], hO = [(0, bK.M)()], DO = [(0, bK.M)("orthoLeft")], MO = [(0, bK.M)("orthoRight")], aK = [(0, bK.M)("orthoTop")], oO = [(0, bK.M)("orthoBottom")], (0, XO.f)(OO, null, KO, {
            kind: "getter",
            name: "shadowFrustumSize",
            static: !1,
            private: !1,
            access: {
              has: OO => "shadowFrustumSize" in OO,
              get: OO => OO.shadowFrustumSize
            },
            metadata: eO
          }, null, VO), (0, XO.f)(OO, null, pO, {
            kind: "getter",
            name: "shadowOrthoScale",
            static: !1,
            private: !1,
            access: {
              has: OO => "shadowOrthoScale" in OO,
              get: OO => OO.shadowOrthoScale
            },
            metadata: eO
          }, null, VO), (0, XO.f)(null, null, CO, {
            kind: "field",
            name: "autoUpdateExtends",
            static: !1,
            private: !1,
            access: {
              has: OO => "autoUpdateExtends" in OO,
              get: OO => OO.autoUpdateExtends,
              set: (OO, KO) => {
                OO.autoUpdateExtends = KO
              }
            },
            metadata: eO
          }, LO, QO), (0, XO.f)(null, null, hO, {
            kind: "field",
            name: "autoCalcShadowZBounds",
            static: !1,
            private: !1,
            access: {
              has: OO => "autoCalcShadowZBounds" in OO,
              get: OO => OO.autoCalcShadowZBounds,
              set: (OO, KO) => {
                OO.autoCalcShadowZBounds = KO
              }
            },
            metadata: eO
          }, zK, AO), (0, XO.f)(null, null, DO, {
            kind: "field",
            name: "_orthoLeft",
            static: !1,
            private: !1,
            access: {
              has: OO => "_orthoLeft" in OO,
              get: OO => OO._orthoLeft,
              set: (OO, KO) => {
                OO._orthoLeft = KO
              }
            },
            metadata: eO
          }, fO, dO), (0, XO.f)(null, null, MO, {
            kind: "field",
            name: "_orthoRight",
            static: !1,
            private: !1,
            access: {
              has: OO => "_orthoRight" in OO,
              get: OO => OO._orthoRight,
              set: (OO, KO) => {
                OO._orthoRight = KO
              }
            },
            metadata: eO
          }, TO, NO), (0, XO.f)(null, null, aK, {
            kind: "field",
            name: "_orthoTop",
            static: !1,
            private: !1,
            access: {
              has: OO => "_orthoTop" in OO,
              get: OO => OO._orthoTop,
              set: (OO, KO) => {
                OO._orthoTop = KO
              }
            },
            metadata: eO
          }, IO, yK), (0, XO.f)(null, null, oO, {
            kind: "field",
            name: "_orthoBottom",
            static: !1,
            private: !1,
            access: {
              has: OO => "_orthoBottom" in OO,
              get: OO => OO._orthoBottom,
              set: (OO, KO) => {
                OO._orthoBottom = KO
              }
            },
            metadata: eO
          }, gK, uO), eO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: eO
          })
        })(), OO
      })(),
      MO = !1;
    MO || (MO = !0, CO.c.AddNodeConstructor("Light_Type_1", ((OO, KO) => () => new DO(OO, eO.o.Zero(), KO))), (0, hO.h)("BABYLON.DirectionalLight", DO))
  },
  39611: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => GK
    });
    var XO = pO(37085),
      bK = pO(35660),
      eO = pO(35632),
      lO = pO(38216),
      vK = pO(39616),
      CO = pO(35653),
      hO = pO(38371),
      DO = pO(35688),
      MO = pO(37088),
      aK = pO(37055),
      oO = pO(35664);
    class FO {
      constructor() {
        this.direction1 = new eO.o(0, 1, 0), this.direction2 = new eO.o(0, 1, 0)
      }
      startDirectionFunction(OO, KO, pO, XO) {
        const bK = (0, oO.RandomRange)(this.direction1.x, this.direction2.x),
          lO = (0, oO.RandomRange)(this.direction1.y, this.direction2.y),
          vK = (0, oO.RandomRange)(this.direction1.z, this.direction2.z);
        XO ? KO.rvO(bK, lO, vK) : eO.o.TransformNormalFromFloatsToRef(bK, lO, vK, OO, KO)
      }
      startPositionFunction(OO, KO, pO, XO) {
        XO ? KO.rvO(0, 0, 0) : eO.o.TransformCoordinatesFromFloatsToRef(0, 0, 0, OO, KO)
      }
      clone() {
        const OO = new FO;
        return aK.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {
        OO.setVector3("direction1", this.direction1), OO.setVector3("direction2", this.direction2)
      }
      buildUniformLayout(OO) {
        OO.addUniform("direction1", 3), OO.addUniform("direction2", 3)
      }
      getEffectDefines() {
        return "#define POINTEMITTER"
      }
      getClassName() {
        return "PointParticleEmitter"
      }
      serialize() {
        const OO = {};
        return OO.type = this.getClassName(), OO.direction1 = this.direction1.WhO(), OO.direction2 = this.direction2.WhO(), OO
      }
      parse(OO) {
        eO.o.FromArrayToRef(OO.direction1, 0, this.direction1), eO.o.FromArrayToRef(OO.direction2, 0, this.direction2)
      }
    }
    class VO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        this.radius = OO, this.radiusRange = KO, this.directionRandomizer = pO
      }
      startDirectionFunction(OO, KO, pO, XO) {
        const bK = pO.position.subtract(OO.getTranslation()).normalize(),
          lO = (0, oO.RandomRange)(0, this.directionRandomizer),
          vK = (0, oO.RandomRange)(0, this.directionRandomizer),
          CO = (0, oO.RandomRange)(0, this.directionRandomizer);
        bK.x += lO, bK.y += vK, bK.z += CO, bK.normalize(), XO ? KO.NhO(bK) : eO.o.TransformNormalFromFloatsToRef(bK.x, bK.y, bK.z, OO, KO)
      }
      startPositionFunction(OO, KO, pO, XO) {
        const bK = this.radius - (0, oO.RandomRange)(0, this.radius * this.radiusRange),
          lO = (0, oO.RandomRange)(0, 1),
          vK = (0, oO.RandomRange)(0, 2 * Math.PI),
          CO = Math.acos(2 * lO - 1),
          hO = bK * Math.cos(vK) * Math.sin(CO),
          DO = bK * Math.cos(CO),
          MO = bK * Math.sin(vK) * Math.sin(CO);
        XO ? KO.rvO(hO, Math.abs(DO), MO) : eO.o.TransformCoordinatesFromFloatsToRef(hO, Math.abs(DO), MO, OO, KO)
      }
      clone() {
        const OO = new VO(this.radius, this.directionRandomizer);
        return aK.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {
        OO.setFloat("radius", this.radius), OO.setFloat("radiusRange", this.radiusRange), OO.setFloat("directionRandomizer", this.directionRandomizer)
      }
      buildUniformLayout(OO) {
        OO.addUniform("radius", 1), OO.addUniform("radiusRange", 1), OO.addUniform("directionRandomizer", 1)
      }
      getEffectDefines() {
        return "#define HEMISPHERICEMITTER"
      }
      getClassName() {
        return "HemisphericParticleEmitter"
      }
      serialize() {
        const OO = {};
        return OO.type = this.getClassName(), OO.radius = this.radius, OO.radiusRange = this.radiusRange, OO.directionRandomizer = this.directionRandomizer, OO
      }
      parse(OO) {
        this.radius = OO.radius, this.radiusRange = OO.radiusRange, this.directionRandomizer = OO.directionRandomizer
      }
    }
    class LO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        this.radius = OO, this.radiusRange = KO, this.directionRandomizer = pO
      }
      startDirectionFunction(OO, KO, pO, XO) {
        const bK = pO.position.subtract(OO.getTranslation()).normalize(),
          lO = (0, oO.RandomRange)(0, this.directionRandomizer),
          vK = (0, oO.RandomRange)(0, this.directionRandomizer),
          CO = (0, oO.RandomRange)(0, this.directionRandomizer);
        bK.x += lO, bK.y += vK, bK.z += CO, bK.normalize(), XO ? KO.NhO(bK) : eO.o.TransformNormalFromFloatsToRef(bK.x, bK.y, bK.z, OO, KO)
      }
      startPositionFunction(OO, KO, pO, XO) {
        const bK = this.radius - (0, oO.RandomRange)(0, this.radius * this.radiusRange),
          lO = (0, oO.RandomRange)(0, 1),
          vK = (0, oO.RandomRange)(0, 2 * Math.PI),
          CO = Math.acos(2 * lO - 1),
          hO = bK * Math.cos(vK) * Math.sin(CO),
          DO = bK * Math.cos(CO),
          MO = bK * Math.sin(vK) * Math.sin(CO);
        XO ? KO.rvO(hO, DO, MO) : eO.o.TransformCoordinatesFromFloatsToRef(hO, DO, MO, OO, KO)
      }
      clone() {
        const OO = new LO(this.radius, this.directionRandomizer);
        return aK.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {
        OO.setFloat("radius", this.radius), OO.setFloat("radiusRange", this.radiusRange), OO.setFloat("directionRandomizer", this.directionRandomizer)
      }
      buildUniformLayout(OO) {
        OO.addUniform("radius", 1), OO.addUniform("radiusRange", 1), OO.addUniform("directionRandomizer", 1)
      }
      getEffectDefines() {
        return "#define SPHEREEMITTER"
      }
      getClassName() {
        return "SphereParticleEmitter"
      }
      serialize() {
        const OO = {};
        return OO.type = this.getClassName(), OO.radius = this.radius, OO.radiusRange = this.radiusRange, OO.directionRandomizer = this.directionRandomizer, OO
      }
      parse(OO) {
        this.radius = OO.radius, this.radiusRange = OO.radiusRange, this.directionRandomizer = OO.directionRandomizer
      }
    }
    class QO extends LO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new eO.o(0, 1, 0),
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new eO.o(0, 1, 0);
        super(OO), this.direction1 = KO, this.direction2 = pO
      }
      startDirectionFunction(OO, KO, pO, XO) {
        const bK = (0, oO.RandomRange)(this.direction1.x, this.direction2.x),
          lO = (0, oO.RandomRange)(this.direction1.y, this.direction2.y),
          vK = (0, oO.RandomRange)(this.direction1.z, this.direction2.z);
        XO ? KO.rvO(bK, lO, vK) : eO.o.TransformNormalFromFloatsToRef(bK, lO, vK, OO, KO)
      }
      clone() {
        const OO = new QO(this.radius, this.direction1, this.direction2);
        return aK.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {
        OO.setFloat("radius", this.radius), OO.setFloat("radiusRange", this.radiusRange), OO.setVector3("direction1", this.direction1), OO.setVector3("direction2", this.direction2)
      }
      buildUniformLayout(OO) {
        OO.addUniform("radius", 1), OO.addUniform("radiusRange", 1), OO.addUniform("direction1", 3), OO.addUniform("direction2", 3)
      }
      getEffectDefines() {
        return "#define SPHEREEMITTER\n#define DIRECTEDSPHEREEMITTER"
      }
      getClassName() {
        return "SphereDirectedParticleEmitter"
      }
      serialize() {
        const OO = super.serialize();
        return OO.direction1 = this.direction1.WhO(), OO.direction2 = this.direction2.WhO(), OO
      }
      parse(OO) {
        super.parse(OO), eO.o.FromArrayToRef(OO.direction1, 0, this.direction1), eO.o.FromArrayToRef(OO.direction2, 0, this.direction2)
      }
    }
    var zK = pO(37049);
    class AO {
      get radius() {
        return this._radius
      }
      set radius(OO) {
        this._radius = OO, this._buildHeight()
      }
      get angle() {
        return this._angle
      }
      set angle(OO) {
        this._angle = OO, this._buildHeight()
      }
      _buildHeight() {
        0 !== this._angle ? this._height = this._radius / Math.tan(this._angle / 2) : this._height = 1
      }
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Math.PI,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        this.directionRandomizer = pO, this.radiusRange = 1, this.heightRange = 1, this.emitFromSpawnPointOnly = !1, this.angle = KO, this.radius = OO
      }
      startDirectionFunction(OO, KO, pO, XO) {
        const bK = pO.position.subtract(OO.getTranslation()).normalize(),
          lO = (0, oO.RandomRange)(0, this.directionRandomizer),
          vK = (0, oO.RandomRange)(0, this.directionRandomizer),
          CO = (0, oO.RandomRange)(0, this.directionRandomizer);
        bK.x += lO, bK.y += vK, bK.z += CO, bK.normalize(), XO ? KO.NhO(bK) : eO.o.TransformNormalFromFloatsToRef(bK.x, bK.y, bK.z, OO, KO)
      }
      startPositionFunction(OO, KO, pO, XO) {
        const bK = (0, oO.RandomRange)(0, 2 * Math.PI);
        let lO;
        this.emitFromSpawnPointOnly ? lO = 1e-4 : (lO = (0, oO.RandomRange)(0, this.heightRange), lO = 1 - lO * lO);
        let vK = this._radius - (0, oO.RandomRange)(0, this._radius * this.radiusRange);
        vK *= lO;
        const CO = vK * Math.sin(bK),
          hO = vK * Math.cos(bK),
          DO = lO * this._height;
        if (XO) return KO.x = CO, KO.y = DO, void(KO.z = hO);
        eO.o.TransformCoordinatesFromFloatsToRef(CO, DO, hO, OO, KO)
      }
      clone() {
        const OO = new AO(this._radius, this._angle, this.directionRandomizer);
        return aK.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {
        OO.setFloat2("radius", this._radius, this.radiusRange), OO.setFloat("coneAngle", this._angle), OO.setFloat2("height", this._height, this.heightRange), OO.setFloat("directionRandomizer", this.directionRandomizer)
      }
      buildUniformLayout(OO) {
        OO.addUniform("radius", 2), OO.addUniform("coneAngle", 1), OO.addUniform("height", 2), OO.addUniform("directionRandomizer", 1)
      }
      getEffectDefines() {
        let OO = "#define CONEEMITTER";
        return this.emitFromSpawnPointOnly && (OO += "\n#define CONEEMITTERSPAWNPOINT"), OO
      }
      getClassName() {
        return "ConeParticleEmitter"
      }
      serialize() {
        const OO = {};
        return OO.type = this.getClassName(), OO.radius = this._radius, OO.angle = this._angle, OO.directionRandomizer = this.directionRandomizer, OO.radiusRange = this.radiusRange, OO.heightRange = this.heightRange, OO.emitFromSpawnPointOnly = this.emitFromSpawnPointOnly, OO
      }
      parse(OO) {
        this.radius = OO.radius, this.angle = OO.angle, this.directionRandomizer = OO.directionRandomizer, this.radiusRange = void 0 !== OO.radiusRange ? OO.radiusRange : 1, this.heightRange = void 0 !== OO.heightRange ? OO.heightRange : 1, this.emitFromSpawnPointOnly = void 0 !== OO.emitFromSpawnPointOnly && OO.emitFromSpawnPointOnly
      }
    }
    class fO extends AO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Math.PI,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new eO.o(0, 1, 0),
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : new eO.o(0, 1, 0);
        super(OO, KO), this.direction1 = pO, this.direction2 = XO
      }
      startDirectionFunction(OO, KO, pO, XO) {
        const bK = (0, oO.RandomRange)(this.direction1.x, this.direction2.x),
          lO = (0, oO.RandomRange)(this.direction1.y, this.direction2.y),
          vK = (0, oO.RandomRange)(this.direction1.z, this.direction2.z);
        XO ? KO.rvO(bK, lO, vK) : eO.o.TransformNormalFromFloatsToRef(bK, lO, vK, OO, KO)
      }
      clone() {
        const OO = new fO(this.radius, this.angle, this.direction1, this.direction2);
        return aK.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {
        super.applyToShader(OO), OO.setVector3("direction1", this.direction1), OO.setVector3("direction2", this.direction2)
      }
      buildUniformLayout(OO) {
        super.buildUniformLayout(OO), OO.addUniform("direction1", 3), OO.addUniform("direction2", 3)
      }
      getEffectDefines() {
        return "#define CONEEMITTER\n#define DIRECTEDCONEEMITTER"
      }
      getClassName() {
        return "ConeDirectedParticleEmitter"
      }
      serialize() {
        const OO = super.serialize();
        return OO.direction1 = this.direction1.WhO(), OO.direction2 = this.direction2.WhO(), OO
      }
      parse(OO) {
        super.parse(OO), eO.o.FromArrayToRef(OO.direction1, 0, this.direction1), eO.o.FromArrayToRef(OO.direction2, 0, this.direction2)
      }
    }
    class dO {
      get mesh() {
        return this._mesh
      }
      set mesh(OO) {
        this._mesh !== OO && (this._mesh = OO, OO ? (this._indices = OO.rFO(), this._positions = OO.getVerticesData(lO.j.PositionKind), this._normals = OO.getVerticesData(lO.j.NormalKind)) : (this._indices = null, this._positions = null, this._normals = null))
      }
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        this._indices = null, this._positions = null, this._normals = null, this._storedNormal = eO.o.Zero(), this._mesh = null, this.direction1 = new eO.o(0, 1, 0), this.direction2 = new eO.o(0, 1, 0), this.useMeshNormalsForDirection = !0, this.mesh = OO
      }
      startDirectionFunction(OO, KO, pO, XO) {
        if (this.useMeshNormalsForDirection && this._normals) return void eO.o.TransformNormalToRef(this._storedNormal, OO, KO);
        const bK = (0, oO.RandomRange)(this.direction1.x, this.direction2.x),
          lO = (0, oO.RandomRange)(this.direction1.y, this.direction2.y),
          vK = (0, oO.RandomRange)(this.direction1.z, this.direction2.z);
        XO ? KO.rvO(bK, lO, vK) : eO.o.TransformNormalFromFloatsToRef(bK, lO, vK, OO, KO)
      }
      startPositionFunction(OO, KO, pO, XO) {
        if (!this._indices || !this._positions) return;
        const bK = 3 * (Math.random() * (this._indices.length / 3) | 0),
          lO = Math.random(),
          vK = Math.random() * (1 - lO),
          CO = 1 - lO - vK,
          hO = this._indices[bK],
          DO = this._indices[bK + 1],
          MO = this._indices[bK + 2],
          aK = eO.j.WX[0],
          oO = eO.j.WX[1],
          FO = eO.j.WX[2],
          VO = eO.j.WX[3];
        eO.o.FromArrayToRef(this._positions, 3 * hO, aK), eO.o.FromArrayToRef(this._positions, 3 * DO, oO), eO.o.FromArrayToRef(this._positions, 3 * MO, FO), VO.x = lO * aK.x + vK * oO.x + CO * FO.x, VO.y = lO * aK.y + vK * oO.y + CO * FO.y, VO.z = lO * aK.z + vK * oO.z + CO * FO.z, XO ? KO.rvO(VO.x, VO.y, VO.z) : eO.o.TransformCoordinatesFromFloatsToRef(VO.x, VO.y, VO.z, OO, KO), this.useMeshNormalsForDirection && this._normals && (eO.o.FromArrayToRef(this._normals, 3 * hO, aK), eO.o.FromArrayToRef(this._normals, 3 * DO, oO), eO.o.FromArrayToRef(this._normals, 3 * MO, FO), this._storedNormal.x = lO * aK.x + vK * oO.x + CO * FO.x, this._storedNormal.y = lO * aK.y + vK * oO.y + CO * FO.y, this._storedNormal.z = lO * aK.z + vK * oO.z + CO * FO.z)
      }
      clone() {
        const OO = new dO(this.mesh);
        return aK.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {
        OO.setVector3("direction1", this.direction1), OO.setVector3("direction2", this.direction2)
      }
      buildUniformLayout(OO) {
        OO.addUniform("direction1", 3), OO.addUniform("direction2", 3)
      }
      getEffectDefines() {
        return ""
      }
      getClassName() {
        return "MeshParticleEmitter"
      }
      serialize() {
        const OO = {};
        return OO.type = this.getClassName(), OO.direction1 = this.direction1.WhO(), OO.direction2 = this.direction2.WhO(), OO.meshId = this.mesh?.id, OO.useMeshNormalsForDirection = this.useMeshNormalsForDirection, OO
      }
      parse(OO, KO) {
        eO.o.FromArrayToRef(OO.direction1, 0, this.direction1), eO.o.FromArrayToRef(OO.direction2, 0, this.direction2), OO.meshId && KO && (this.mesh = KO.getLastMeshById(OO.meshId)), this.useMeshNormalsForDirection = OO.useMeshNormalsForDirection
      }
    }
    class TO {
      get targetStopDuration() {
        return this._targetStopDuration
      }
      set targetStopDuration(OO) {
        this._targetStopDuration !== OO && (this._targetStopDuration = OO)
      }
      get isNodeGenerated() {
        return !1
      }
      get noiseTexture() {
        return this._noiseTexture
      }
      set noiseTexture(OO) {
        this._noiseTexture !== OO && (this._noiseTexture = OO, this._reset())
      }
      get attractors() {
        return this._attractors.slice(0)
      }
      addAttractor(OO) {
        this._attractors.push(OO)
      }
      removeAttractor(OO) {
        const KO = this._attractors.indexOf(OO); - 1 !== KO && this._attractors.splice(KO, 1)
      }
      get _isAnimationSheetEnabled() {
        return this._animationSheetEnabled
      }
      set _isAnimationSheetEnabled(OO) {
        this._animationSheetEnabled !== OO && (this._animationSheetEnabled = OO)
      }
      get isAnimationSheetEnabled() {
        return this._isAnimationSheetEnabled
      }
      set isAnimationSheetEnabled(OO) {
        this._isAnimationSheetEnabled != OO && (this._isAnimationSheetEnabled = OO, this._reset())
      }
      get useLogarithmicDepth() {
        return this._useLogarithmicDepth
      }
      set useLogarithmicDepth(OO) {
        this._useLogarithmicDepth = OO && this.JKO().qb().getCaps().fragmentDepthSupported
      }
      JKO() {
        return this._scene
      }
      _hasTargetStopDurationDependantGradient() {
        return this._startSizeGradients && this._startSizeGradients.length > 0 || this._emitRateGradients && this._emitRateGradients.length > 0 || this._lifeTimeGradients && this._lifeTimeGradients.length > 0
      }
      _setEngineBasedOnBlendMode(OO) {
        switch (OO) {
          case TO.BLENDMODE_MULTIPLYADD:
            return;
          case TO.BLENDMODE_ADD:
            OO = 1;
            break;
          case TO.BLENDMODE_ONEONE:
            OO = 6;
            break;
          case TO.BLENDMODE_STANDARD:
            OO = 2;
            break;
          case TO.BLENDMODE_MULTIPLY:
            OO = 4;
            break;
          case TO.BLENDMODE_SUBTRACT:
            OO = 3
        }
        this._engine.setAlphaMode(OO)
      }
      getDragGradients() {
        return this._dragGradients
      }
      getLimitVelocityGradients() {
        return this._limitVelocityGradients
      }
      getColorGradients() {
        return this._colorGradients
      }
      getSizeGradients() {
        return this._sizeGradients
      }
      getColorRemapGradients() {
        return this._colorRemapGradients
      }
      getAlphaRemapGradients() {
        return this._alphaRemapGradients
      }
      getLifeTimeGradients() {
        return this._lifeTimeGradients
      }
      getAngularSpeedGradients() {
        return this._angularSpeedGradients
      }
      getVelocityGradients() {
        return this._velocityGradients
      }
      getStartSizeGradients() {
        return this._startSizeGradients
      }
      getEmitRateGradients() {
        return this._emitRateGradients
      }
      addEmitRateGradient(OO, KO, pO) {
        return this._emitRateGradients || (this._emitRateGradients = []), this._addFactorGradient(this._emitRateGradients, OO, KO, pO), this
      }
      removeEmitRateGradient(OO) {
        return this._removeFactorGradient(this._emitRateGradients, OO), this
      }
      get direction1() {
        return this.particleEmitterType.direction1 ? this.particleEmitterType.direction1 : eO.o.Zero()
      }
      set direction1(OO) {
        this.particleEmitterType.direction1 && (this.particleEmitterType.direction1 = OO)
      }
      get direction2() {
        return this.particleEmitterType.direction2 ? this.particleEmitterType.direction2 : eO.o.Zero()
      }
      set direction2(OO) {
        this.particleEmitterType.direction2 && (this.particleEmitterType.direction2 = OO)
      }
      get minEmitBox() {
        return this.particleEmitterType.minEmitBox ? this.particleEmitterType.minEmitBox : eO.o.Zero()
      }
      set minEmitBox(OO) {
        this.particleEmitterType.minEmitBox && (this.particleEmitterType.minEmitBox = OO)
      }
      get maxEmitBox() {
        return this.particleEmitterType.maxEmitBox ? this.particleEmitterType.maxEmitBox : eO.o.Zero()
      }
      set maxEmitBox(OO) {
        this.particleEmitterType.maxEmitBox && (this.particleEmitterType.maxEmitBox = OO)
      }
      get billboardMode() {
        return this._billboardMode
      }
      set billboardMode(OO) {
        this._billboardMode !== OO && (this._billboardMode = OO, this._reset())
      }
      get isBillboardBased() {
        return this._isBillboardBased
      }
      set isBillboardBased(OO) {
        this._isBillboardBased !== OO && (this._isBillboardBased = OO, this._reset())
      }
      get imageProcessingConfiguration() {
        return this._imageProcessingConfiguration
      }
      set imageProcessingConfiguration(OO) {
        this._attachImageProcessingConfiguration(OO)
      }
      _attachImageProcessingConfiguration(OO) {
        OO !== this._imageProcessingConfiguration && (!OO && this._scene ? this._imageProcessingConfiguration = this._scene.imageProcessingConfiguration : this._imageProcessingConfiguration = OO)
      }
      _reset() {}
      _addFactorGradient(OO, KO, pO, bK) {
        const eO = new XO.j(KO, pO, bK);
        OO.push(eO), OO.sort(((OO, KO) => OO.gradient < KO.gradient ? -1 : OO.gradient > KO.gradient ? 1 : 0))
      }
      _removeFactorGradient(OO, KO) {
        if (!OO) return;
        let pO = 0;
        for (const XO of OO) {
          if (XO.gradient === KO) {
            OO.splice(pO, 1);
            break
          }
          pO++
        }
      }
      _removeGradientAndTexture(OO, KO, pO) {
        if (!KO) return this;
        let XO = 0;
        for (const bK of KO) {
          if (bK.gradient === OO) {
            KO.splice(XO, 1);
            break
          }
          XO++
        }
        return pO && pO.dispose(), this
      }
      constructor(OO) {
        this.animations = [], this.renderingGroupId = 0, this.emitter = eO.o.Zero(), this.emitRate = 10, this.manualEmitCount = -1, this.updateSpeed = .01, this._targetStopDuration = 0, this.disposeOnStop = !1, this.minEmitPower = 1, this.maxEmitPower = 1, this.minLifeTime = 1, this.maxLifeTime = 1, this.minSize = 1, this.maxSize = 1, this.minScaleX = 1, this.maxScaleX = 1, this.minScaleY = 1, this.maxScaleY = 1, this.minInitialRotation = 0, this.maxInitialRotation = 0, this.minAngularSpeed = 0, this.maxAngularSpeed = 0, this.layerMask = 268435455, this.customShader = null, this.preventAutoStart = !1, this.applyFog = !1, this._wasDispatched = !1, this._rootUrl = "", this.noiseStrength = new eO.o(10, 10, 10), this._attractors = [], this.onAnimationEnd = null, this.blendMode = TO.BLENDMODE_ONEONE, this.forceDepthWrite = !1, this.preWarmCycles = 0, this.preWarmStepOffset = 1, this.spriteCellChangeSpeed = 1, this.startSpriteCellID = 0, this.endSpriteCellID = 0, this.spriteCellWidth = 0, this.spriteCellHeight = 0, this.spriteCellLoop = !0, this.spriteRandomStartCell = !1, this.translationPivot = new eO.m(0, 0), this._animationSheetEnabled = !1, this.beginAnimationOnStart = !1, this.beginAnimationFrom = 0, this.beginAnimationTo = 60, this.beginAnimationLoop = !1, this.worldOffset = new eO.o(0, 0, 0), this._useLogarithmicDepth = !1, this.gravity = eO.o.Zero(), this._colorGradients = null, this._sizeGradients = null, this._lifeTimeGradients = null, this._angularSpeedGradients = null, this._velocityGradients = null, this._limitVelocityGradients = null, this._dragGradients = null, this._emitRateGradients = null, this._startSizeGradients = null, this._rampGradients = null, this._colorRemapGradients = null, this._alphaRemapGradients = null, this.startDelay = 0, this.limitVelocityDamping = .4, this.color1 = new DO.g(1, 1, 1, 1), this.color2 = new DO.g(1, 1, 1, 1), this.colorDead = new DO.g(0, 0, 0, 1), this.textureMask = new DO.g(1, 1, 1, 1), this._isSubEmitter = !1, this._billboardMode = 7, this._isBillboardBased = !0, this._imageProcessingConfigurationDefines = new hO.b, this.id = OO, this.name = OO
      }
      createPointEmitter(OO, KO) {
        const pO = function(OO, KO) {
          const pO = new FO;
          return pO.direction1 = OO, pO.direction2 = KO, pO
        }(OO, KO);
        return this.particleEmitterType = pO, pO
      }
      createHemisphericEmitter() {
        const OO = function() {
          return new VO(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1)
        }(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1);
        return this.particleEmitterType = OO, OO
      }
      createSphereEmitter() {
        const OO = function() {
          return new LO(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1)
        }(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1);
        return this.particleEmitterType = OO, OO
      }
      createDirectedSphereEmitter() {
        const OO = function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
            KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new eO.o(0, 1, 0),
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new eO.o(0, 1, 0);
          return new QO(OO, KO, pO)
        }(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new eO.o(0, 1, 0), arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new eO.o(0, 1, 0));
        return this.particleEmitterType = OO, OO
      }
      createCylinderEmitter() {
        const OO = function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
            KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
            XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
          return new zK.e(OO, KO, pO, XO)
        }(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0);
        return this.particleEmitterType = OO, OO
      }
      createDirectedCylinderEmitter() {
        const OO = function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
            KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
            XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : new eO.o(0, 1, 0),
            bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : new eO.o(0, 1, 0);
          return new zK.d(OO, KO, pO, XO, bK)
        }(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : new eO.o(0, 1, 0), arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : new eO.o(0, 1, 0));
        return this.particleEmitterType = OO, OO
      }
      createConeEmitter() {
        const OO = function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
            KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Math.PI / 4;
          return new AO(OO, KO)
        }(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Math.PI / 4);
        return this.particleEmitterType = OO, OO
      }
      createDirectedConeEmitter() {
        const OO = function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
            KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Math.PI / 4,
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new eO.o(0, 1, 0),
            XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : new eO.o(0, 1, 0);
          return new fO(OO, KO, pO, XO)
        }(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Math.PI / 4, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new eO.o(0, 1, 0), arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : new eO.o(0, 1, 0));
        return this.particleEmitterType = OO, OO
      }
      createBoxEmitter(OO, KO, pO, XO) {
        const bK = new MO.b;
        return this.particleEmitterType = bK, this.direction1 = OO, this.direction2 = KO, this.minEmitBox = pO, this.maxEmitBox = XO, bK
      }
      createMeshEmitter() {
        const OO = function() {
          return new dO(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null)
        }(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null);
        return this.particleEmitterType = OO, OO
      }
    }
    TO.BLENDMODE_ONEONE = 0, TO.BLENDMODE_STANDARD = 1, TO.BLENDMODE_ADD = 2, TO.BLENDMODE_MULTIPLY = 3, TO.BLENDMODE_MULTIPLYADD = 4, TO.BLENDMODE_SUBTRACT = -1;
    class NO {
      constructor() {
        this.attachedSubEmitters = null, this.currentColor1 = new DO.g(0, 0, 0, 0), this.currentColor2 = new DO.g(0, 0, 0, 0), this.currentSize1 = 0, this.currentSize2 = 0, this.currentAngularSpeed1 = 0, this.currentAngularSpeed2 = 0, this.currentVelocity1 = 0, this.currentVelocity2 = 0, this.scaledDirection = eO.o.Zero(), this.currentLimitVelocity1 = 0, this.currentLimitVelocity2 = 0, this.currentDrag1 = 0, this.currentDrag2 = 0
      }
      reset() {
        this.currentColorGradient = null, this.currentSizeGradient = null, this.currentAngularSpeedGradient = null, this.currentVelocityGradient = null, this.currentLimitVelocityGradient = null, this.currentDragGradient = null, this.randomCellOffset = void 0, this.randomNoiseCoordinates1 = null, this.randomNoiseCoordinates2 = null
      }
    }
    class IO {
      constructor(OO) {
        this.particleSystem = OO, this.position = eO.o.Zero(), this.direction = eO.o.Zero(), this.color = new DO.g(0, 0, 0, 0), this.colorStep = new DO.g(0, 0, 0, 0), this.initialColor = new DO.g(0, 0, 0, 0), this.colorDead = new DO.g(0, 0, 0, 0), this.lifeTime = 1, this.age = 0, this.size = 0, this.scale = new eO.m(1, 1), this.angle = 0, this.angularSpeed = 0, this.cellIndex = 0, this.metadata = null, this._properties = new NO, this.id = IO._Count++, this.particleSystem.isAnimationSheetEnabled && this._updateCellInfoFromSystem()
      }
      _updateCellInfoFromSystem() {
        this.cellIndex = this.particleSystem.startSpriteCellID
      }
      updateCellIndex() {
        let OO = this.age,
          KO = this.particleSystem.spriteCellChangeSpeed;
        this.particleSystem.spriteRandomStartCell && (void 0 === this._properties.randomCellOffset && (this._properties.randomCellOffset = Math.random() * this.lifeTime), 0 === KO ? (KO = 1, OO = this._properties.randomCellOffset) : OO += this._properties.randomCellOffset);
        const pO = this._properties.initialEndSpriteCellId - this._properties.initialStartSpriteCellId + 1;
        let XO;
        XO = this._properties.initialSpriteCellLoop ? (0, oO.Clamp)(OO * KO % this.lifeTime / this.lifeTime) : (0, oO.Clamp)(OO * KO / this.lifeTime), this.cellIndex = this._properties.initialStartSpriteCellId + XO * pO | 0
      }
      _inheritParticleInfoToSubEmitter(OO) {
        if (OO.particleSystem.emitter.position) {
          const KO = OO.particleSystem.emitter;
          if (KO.position.NhO(this.position), OO.inheritDirection) {
            const OO = eO.j.WX[0];
            this.direction.normalizeToRef(OO), KO.setDirection(OO, 0, Math.PI / 2)
          }
        } else {
          OO.particleSystem.emitter.NhO(this.position)
        }
        this.direction.scaleToRef(OO.inheritedVelocityAmount / 2, eO.j.WX[0]), OO.particleSystem._inheritedVelocityOffset.NhO(eO.j.WX[0])
      }
      _inheritParticleInfoToSubEmitters() {
        if (this._properties.attachedSubEmitters && this._properties.attachedSubEmitters.length > 0)
          for (const OO of this._properties.attachedSubEmitters) this._inheritParticleInfoToSubEmitter(OO)
      }
      _reset() {
        this._properties.onReset && this._properties.onReset(), this.age = 0, this.id = IO._Count++, this._properties.reset(), this.metadata = null, this.cellIndex = this.particleSystem.startSpriteCellID
      }
      copyTo(OO) {
        OO.position.NhO(this.position), this._properties.initialDirection ? OO._properties.initialDirection ? OO._properties.initialDirection.NhO(this._properties.initialDirection) : OO._properties.initialDirection = this._properties.initialDirection.clone() : OO._properties.initialDirection = null, OO.direction.NhO(this.direction), this._properties.localPosition && (OO._properties.localPosition ? OO._properties.localPosition.NhO(this._properties.localPosition) : OO._properties.localPosition = this._properties.localPosition.clone()), OO.color.NhO(this.color), OO.colorStep.NhO(this.colorStep), OO.initialColor.NhO(this.initialColor), OO.colorDead.NhO(this.colorDead), OO.lifeTime = this.lifeTime, OO.age = this.age, OO._properties.randomCellOffset = this._properties.randomCellOffset, OO.size = this.size, OO.scale.NhO(this.scale), OO.angle = this.angle, OO.angularSpeed = this.angularSpeed, OO.particleSystem = this.particleSystem, OO.cellIndex = this.cellIndex, OO.id = this.id, OO._properties.attachedSubEmitters = this._properties.attachedSubEmitters, this._properties.currentColorGradient && (OO._properties.currentColorGradient = this._properties.currentColorGradient, OO._properties.currentColor1.NhO(this._properties.currentColor1), OO._properties.currentColor2.NhO(this._properties.currentColor2)), this._properties.currentSizeGradient && (OO._properties.currentSizeGradient = this._properties.currentSizeGradient, OO._properties.currentSize1 = this._properties.currentSize1, OO._properties.currentSize2 = this._properties.currentSize2), this._properties.currentAngularSpeedGradient && (OO._properties.currentAngularSpeedGradient = this._properties.currentAngularSpeedGradient, OO._properties.currentAngularSpeed1 = this._properties.currentAngularSpeed1, OO._properties.currentAngularSpeed2 = this._properties.currentAngularSpeed2), this._properties.currentVelocityGradient && (OO._properties.currentVelocityGradient = this._properties.currentVelocityGradient, OO._properties.currentVelocity1 = this._properties.currentVelocity1, OO._properties.currentVelocity2 = this._properties.currentVelocity2), this._properties.currentLimitVelocityGradient && (OO._properties.currentLimitVelocityGradient = this._properties.currentLimitVelocityGradient, OO._properties.currentLimitVelocity1 = this._properties.currentLimitVelocity1, OO._properties.currentLimitVelocity2 = this._properties.currentLimitVelocity2), this._properties.currentDragGradient && (OO._properties.currentDragGradient = this._properties.currentDragGradient, OO._properties.currentDrag1 = this._properties.currentDrag1, OO._properties.currentDrag2 = this._properties.currentDrag2), this.particleSystem.isAnimationSheetEnabled && (OO._properties.initialStartSpriteCellId = this._properties.initialStartSpriteCellId, OO._properties.initialEndSpriteCellId = this._properties.initialEndSpriteCellId, OO._properties.initialSpriteCellLoop = this._properties.initialSpriteCellLoop), this.particleSystem.useRampGradients && (OO.remapData && this.remapData ? OO.remapData.NhO(this.remapData) : OO.remapData = new eO.s(0, 0, 0, 0)), this._properties.randomNoiseCoordinates1 && this._properties.randomNoiseCoordinates2 && (OO._properties.randomNoiseCoordinates1 && OO._properties.randomNoiseCoordinates2 ? (OO._properties.randomNoiseCoordinates1.NhO(this._properties.randomNoiseCoordinates1), OO._properties.randomNoiseCoordinates2.NhO(this._properties.randomNoiseCoordinates2)) : (OO._properties.randomNoiseCoordinates1 = this._properties.randomNoiseCoordinates1.clone(), OO._properties.randomNoiseCoordinates2 = this._properties.randomNoiseCoordinates2.clone())), OO.metadata = this.metadata
      }
    }
    IO._Count = 0;
    var yK = pO(39242);
    class gK {
      get currentFrame() {
        return this._currentFrame
      }
      get _evaluatedFrom() {
        return this._playbackFrom
      }
      get _evaluatedTo() {
        return this._playbackTo
      }
      get _evaluatedProgress() {
        return this._playbackProgress
      }
      get _evaluatedSyncRoot() {
        return this._playbackSyncRoot
      }
      get _evaluatedJump() {
        return this._playbackJumped
      }
      get weight() {
        return this._weight
      }
      get currentValue() {
        return this._currentValue
      }
      get targetPath() {
        return this._targetPath
      }
      get target() {
        return this._currentActiveTarget
      }
      get isAdditive() {
        return this._host && this._host.isAdditive
      }
      constructor(OO, KO, pO, XO) {
        if (this._events = new Array, this._currentFrame = 0, this._originalValue = new Array, this._originalBlendValue = null, this._offsetsCache = {}, this._highLimitsCache = {}, this._stopped = !1, this._blendingFactor = 0, this._currentValue = null, this._currentActiveTarget = null, this._directTarget = null, this._targetPath = "", this._weight = 1, this._absoluteFrameOffset = 0, this._previousElapsedTime = 0, this._yoyoDirection = 1, this._previousAbsoluteFrame = 0, this._playbackFrom = 0, this._playbackTo = 0, this._playbackFrames = 0, this._playbackProgress = 0, this._playbackSyncRoot = null, this._playbackJumped = !1, this._playbackSyncMasterPlayed = 0, this._playbackSyncMasterFrame = 0, this._targetIsArray = !1, this._coreRuntimeAnimation = null, this._animation = KO, this.GbO = OO, this._scene = pO, this._host = XO, this._activeTargets = [], KO._runtimeAnimations.push(this), this._animationState = {
            key: 0,
            repeatCount: 0,
            i4: this._getCorrectLoopMode()
          }, this._animation.dataType === yK.e.ANIMATIONTYPE_MATRIX && (this._animationState.workValue = eO.c.Zero()), this._keys = this._animation.getKeys(), this._minFrame = this._keys[0].frame, this._maxFrame = this._keys[this._keys.length - 1].frame, 0 !== this._minFrame) {
          const OO = {
            frame: 0,
            value: this._keys[0].value
          };
          this._keys.splice(0, 0, OO)
        }
        if (this.GbO instanceof Array) {
          let OO = 0;
          for (const KO of this.GbO) this._preparePath(KO, OO), this._getOriginalValues(OO), OO++;
          this._targetIsArray = !0
        } else this._preparePath(this.GbO), this._getOriginalValues(), this._targetIsArray = !1, this._directTarget = this._activeTargets[0];
        const bK = KO.getEvents();
        if (bK && bK.length > 0)
          for (const eO of bK) this._events.push(eO._clone());
        this._enableBlending = OO && OO.animationPropertiesOverride ? OO.animationPropertiesOverride.enableBlending : this._animation.enableBlending
      }
      _preparePath(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        const pO = this._animation.targetPropertyPath;
        if (pO.length > 1) {
          let XO = OO;
          for (let OO = 0; OO < pO.length - 1; OO++) {
            const KO = pO[OO];
            if (XO = XO[KO], void 0 === XO) throw new Error(`Invalid property (${KO}) in property path (${pO.join(".")})`)
          }
          this._targetPath = pO[pO.length - 1], this._activeTargets[KO] = XO
        } else this._targetPath = pO[0], this._activeTargets[KO] = OO;
        if (void 0 === this._activeTargets[KO][this._targetPath]) throw new Error(`Invalid property (${this._targetPath}) in property path (${pO.join(".")})`)
      }
      get animation() {
        return this._animation
      }
      reset() {
        if (arguments.length > 0 && void 0 !== arguments[0] && arguments[0])
          if (this.GbO instanceof Array) {
            let OO = 0;
            for (const KO of this.GbO) void 0 !== this._originalValue[OO] && this._setValue(KO, this._activeTargets[OO], this._originalValue[OO], -1, OO), OO++
          } else void 0 !== this._originalValue[0] && this._setValue(this.GbO, this._directTarget, this._originalValue[0], -1, 0);
        this._offsetsCache = {}, this._highLimitsCache = {}, this._currentFrame = 0, this._blendingFactor = 0;
        for (let OO = 0; OO < this._events.length; OO++) this._events[OO].isDone = !1
      }
      isStopped() {
        return this._stopped
      }
      dispose() {
        const OO = this._animation.runtimeAnimations.indexOf(this);
        OO > -1 && this._animation.runtimeAnimations.splice(OO, 1)
      }
      setValue(OO, KO) {
        if (this._targetIsArray)
          for (let pO = 0; pO < this.GbO.length; pO++) {
            const XO = this.GbO[pO];
            this._setValue(XO, this._activeTargets[pO], OO, KO, pO)
          } else this._setValue(this.GbO, this._directTarget, OO, KO, 0)
      }
      _getOriginalValues() {
        let OO, KO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        const pO = this._activeTargets[KO];
        if (yK.e.InheritOriginalValueFromActiveAnimations) {
          const OO = this._scene._activeAnimatables;
          for (let XO = 0; XO < OO.length; XO++) {
            const bK = OO[XO]._runtimeAnimations;
            for (let OO = 0; OO < bK.length; OO++) {
              const XO = bK[OO];
              if (XO !== this && XO._targetPath === this._targetPath)
                for (let OO = 0; OO < XO._activeTargets.length; OO++)
                  if (XO._activeTargets[OO] === pO && void 0 !== XO._originalValue[OO]) return void(XO._originalValue[OO] && XO._originalValue[OO].clone ? this._originalValue[KO] = XO._originalValue[OO].clone() : this._originalValue[KO] = XO._originalValue[OO])
            }
          }
        }
        OO = pO.getLocalMatrix && "_matrix" === this._targetPath ? pO.getLocalMatrix() : pO[this._targetPath], OO && OO.clone ? this._originalValue[KO] = OO.clone() : this._originalValue[KO] = OO
      }
      _registerTargetForLateAnimationBinding(OO, KO) {
        const pO = OO.target;
        this._scene._registeredForLateAnimationBindings.pushNoDuplicate(pO), pO._lateAnimationHolders || (pO._lateAnimationHolders = {}), pO._lateAnimationHolders[OO.targetPath] || (pO._lateAnimationHolders[OO.targetPath] = {
          totalWeight: 0,
          totalAdditiveWeight: 0,
          animations: [],
          additiveAnimations: [],
          originalValue: KO
        }), OO.isAdditive ? (pO._lateAnimationHolders[OO.targetPath].additiveAnimations.push(OO), pO._lateAnimationHolders[OO.targetPath].totalAdditiveWeight += OO.weight) : (pO._lateAnimationHolders[OO.targetPath].animations.push(OO), pO._lateAnimationHolders[OO.targetPath].totalWeight += OO.weight)
      }
      _setValue(OO, KO, pO, XO, bK) {
        const lO = this._scene._animationWrites,
          vK = this._scene._animationWriteCount++;
        let CO = lO[vK];
        if (CO || (CO = lO[vK] = {
            runtimeAnimation: this,
            target: OO,
            weight: XO,
            additive: !1,
            blendingFactor: 1,
            El: !1
          }), CO.runtimeAnimation = this, CO.target = OO, CO.weight = XO, CO.additive = this.isAdditive, CO.El = !1, this._currentActiveTarget = KO, this._weight = XO, this._enableBlending && this._blendingFactor <= 1) {
          if (!this._originalBlendValue) {
            const OO = KO[this._targetPath];
            OO.clone ? this._originalBlendValue = OO.clone() : this._originalBlendValue = OO
          }
          this._originalBlendValue.m ? yK.e.AllowMatrixDecomposeForInterpolation ? this._currentValue ? eO.c.DecomposeLerpToRef(this._originalBlendValue, pO, this._blendingFactor, this._currentValue) : this._currentValue = eO.c.DecomposeLerp(this._originalBlendValue, pO, this._blendingFactor) : this._currentValue ? eO.c.LerpToRef(this._originalBlendValue, pO, this._blendingFactor, this._currentValue) : this._currentValue = eO.c.Lerp(this._originalBlendValue, pO, this._blendingFactor) : this._currentValue = yK.e._UniversalLerp(this._originalBlendValue, pO, this._blendingFactor);
          const XO = OO && OO.animationPropertiesOverride ? OO.animationPropertiesOverride.blendingSpeed : this._animation.blendingSpeed;
          CO.blendingFactor = this._blendingFactor, this._blendingFactor += XO
        } else CO.blendingFactor = 1, this._currentValue ? this._currentValue.NhO ? this._currentValue.NhO(pO) : this._currentValue = pO : this._currentValue = pO?.clone ? pO.clone() : pO; - 1 !== XO ? this._registerTargetForLateAnimationBinding(this, this._originalValue[bK]) : this._animationState.i4 === yK.e.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT ? this._currentValue.addToRef ? this._currentValue.addToRef(this._originalValue[bK], KO[this._targetPath]) : KO[this._targetPath] = this._originalValue[bK] + this._currentValue : KO[this._targetPath] = this._currentValue, OO.jhO && OO.jhO(this._animation.targetProperty)
      }
      _getCorrectLoopMode() {
        if (this.GbO && this.GbO.animationPropertiesOverride) {
          return "MorphTarget" === this.GbO.getClassName?.() && null == this.GbO._animationPropertiesOverride ? this._animation.i4 : this.GbO.animationPropertiesOverride.i4
        }
        return this._animation.i4
      }
      goToFrame(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1;
        const pO = this._animation.getKeys();
        OO < pO[0].frame ? OO = pO[0].frame : OO > pO[pO.length - 1].frame && (OO = pO[pO.length - 1].frame);
        const XO = this._events;
        if (XO.length)
          for (let eO = 0; eO < XO.length; eO++) XO[eO].onlyOnce || (XO[eO].isDone = XO[eO].frame < OO);
        this._currentFrame = OO;
        const bK = this._animation._interpolate(OO, this._animationState);
        this.setValue(bK, KO)
      }
      _prepareForSpeedRatioChange(OO) {
        const KO = this._previousElapsedTime * (this._animation.framePerSecond * OO) / 1e3;
        this._absoluteFrameOffset = this._previousAbsoluteFrame - KO
      }
      animate(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : -1;
        const lO = this._animation,
          vK = lO.targetPropertyPath;
        if (!vK || vK.length < 1) return this._stopped = !0, !1;
        let CO, hO = !0;
        const DO = this._events;
        let MO;
        if (this._coreRuntimeAnimation) MO = pO - KO, CO = this._coreRuntimeAnimation.currentFrame, this._currentFrame = CO, this._animationState.repeatCount = this._coreRuntimeAnimation._animationState.repeatCount, this._animationState.highLimitValue = this._coreRuntimeAnimation._animationState.highLimitValue, this._animationState.offsetValue = this._coreRuntimeAnimation._animationState.offsetValue, this._playbackFrom = this._coreRuntimeAnimation._playbackFrom, this._playbackTo = this._coreRuntimeAnimation._playbackTo, this._playbackFrames = this._coreRuntimeAnimation._playbackFrames, this._playbackProgress = this._coreRuntimeAnimation._playbackProgress, this._playbackJumped = this._coreRuntimeAnimation._playbackJumped, this._playbackSyncRoot = this._coreRuntimeAnimation._playbackSyncRoot;
        else {
          let eO;
          (KO < this._minFrame || KO > this._maxFrame) && (KO = this._minFrame), (pO < this._minFrame || pO > this._maxFrame) && (pO = this._maxFrame), MO = pO - KO;
          let vK = OO * (lO.framePerSecond * bK) / 1e3 + this._absoluteFrameOffset,
            aK = 0,
            oO = !1;
          const FO = XO && this._animationState.i4 === yK.e.ANIMATIONLOOPMODE_YOYO;
          if (FO) {
            const OO = (vK - KO) / MO,
              pO = Math.sin(OO * Math.PI);
            vK = Math.abs(pO) * MO + KO;
            const XO = pO >= 0 ? 1 : -1;
            this._yoyoDirection !== XO && (oO = !0), this._yoyoDirection = XO
          }
          if (this._previousElapsedTime = OO, this._previousAbsoluteFrame = vK, !XO && pO >= KO && (vK >= MO && bK > 0 || vK <= 0 && bK < 0)) hO = !1, aK = lO.evaluate(pO);
          else if (!XO && KO >= pO && (vK <= MO && bK < 0 || vK >= 0 && bK > 0)) hO = !1, aK = lO.evaluate(KO);
          else if (this._animationState.i4 !== yK.e.ANIMATIONLOOPMODE_CYCLE) {
            const OO = pO.toString() + KO.toString();
            if (!this._offsetsCache[OO]) {
              this._animationState.repeatCount = 0, this._animationState.i4 = yK.e.ANIMATIONLOOPMODE_CYCLE;
              const XO = lO._interpolate(KO, this._animationState),
                bK = lO._interpolate(pO, this._animationState);
              switch (this._animationState.i4 = this._getCorrectLoopMode(), lO.dataType) {
                case yK.e.ANIMATIONTYPE_FLOAT:
                  this._offsetsCache[OO] = bK - XO;
                  break;
                case yK.e.ANIMATIONTYPE_QUATERNION:
                case yK.e.ANIMATIONTYPE_VECTOR3:
                case yK.e.ANIMATIONTYPE_VECTOR2:
                case yK.e.ANIMATIONTYPE_SIZE:
                case yK.e.ANIMATIONTYPE_COLOR3:
                case yK.e.ANIMATIONTYPE_COLOR4:
                  this._offsetsCache[OO] = bK.subtract(XO)
              }
              this._highLimitsCache[OO] = bK
            }
            aK = this._highLimitsCache[OO], eO = this._offsetsCache[OO]
          }
          if (void 0 === eO) switch (lO.dataType) {
            case yK.e.ANIMATIONTYPE_FLOAT:
              eO = 0;
              break;
            case yK.e.ANIMATIONTYPE_QUATERNION:
              eO = yK.o;
              break;
            case yK.e.ANIMATIONTYPE_VECTOR3:
              eO = yK.w;
              break;
            case yK.e.ANIMATIONTYPE_VECTOR2:
              eO = yK.t;
              break;
            case yK.e.ANIMATIONTYPE_SIZE:
              eO = yK.q;
              break;
            case yK.e.ANIMATIONTYPE_COLOR3:
              eO = yK.j;
              break;
            case yK.e.ANIMATIONTYPE_COLOR4:
              eO = yK.l
          }
          const VO = this._host ? this._host.syncRoot : null;
          let LO, QO = this._playbackFrames,
            zK = !1;
          if (VO) {
            const OO = VO.toFrame - VO.fromFrame,
              pO = VO.masterFrame,
              XO = (pO - VO.fromFrame) / OO;
            CO = KO + MO * XO;
            const bK = VO.getAnimations()[0];
            if (bK && 0 !== OO) {
              const OO = MO * XO,
                KO = bK._playbackTo - bK._playbackFrom;
              if (0 !== KO && bK._playbackFrom <= VO.fromFrame && bK._playbackTo >= VO.toFrame) {
                QO = MO * Math.round((bK._playbackFrames - (bK._currentFrame - bK._playbackFrom)) / KO) + OO
              } else zK = (pO - this._playbackSyncMasterFrame) * (bK._playbackFrames - this._playbackSyncMasterPlayed) < 0, QO = OO;
              zK = zK || bK._playbackJumped, this._playbackSyncMasterPlayed = bK._playbackFrames, this._playbackSyncMasterFrame = pO
            }
          } else CO = vK > 0 && KO > pO || vK < 0 && KO < pO ? hO && 0 !== MO ? pO + vK % MO : KO : hO && 0 !== MO ? KO + vK % MO : pO;
          if (!FO && (bK > 0 && this.currentFrame > CO || bK < 0 && this.currentFrame < CO) || FO && oO) {
            this._onLoop();
            for (let OO = 0; OO < DO.length; OO++) DO[OO].onlyOnce || (DO[OO].isDone = !1);
            this._animationState.key = bK > 0 ? 0 : lO.getKeys().length - 1
          }
          if (this._currentFrame = CO, this._animationState.repeatCount = 0 === MO ? 0 : vK / MO | 0, this._animationState.highLimitValue = aK, this._animationState.offsetValue = eO, this._playbackFrom = KO, this._playbackTo = pO, this._playbackJumped = zK, this._playbackSyncRoot = VO, VO) LO = QO;
          else if (hO) LO = FO ? CO === KO && vK === pO ? MO : CO - KO : vK;
          else {
            const OO = 0 !== MO ? Math.floor(this._playbackFrames / MO) : 0;
            LO = (CO === pO ? OO + 1 : OO) * MO
          }
          this._playbackFrames = LO, this._playbackProgress = this._animationState.i4 === yK.e.ANIMATIONLOOPMODE_CONSTANT && this._animationState.repeatCount > 0 ? MO : LO
        }
        const aK = lO._interpolate(CO, this._animationState);
        if (this.setValue(aK, eO), DO.length)
          for (let oO = 0; oO < DO.length; oO++)
            if (MO >= 0 && CO >= DO[oO].frame && DO[oO].frame >= KO || MO < 0 && CO <= DO[oO].frame && DO[oO].frame <= KO) {
              const OO = DO[oO];
              OO.isDone || (OO.onlyOnce && (DO.splice(oO, 1), oO--), OO.isDone = !0, OO.action(CO))
            } return hO || (this._stopped = !0), hO
      }
    }
    var uO = pO(37966);
    class EO {
      get syncRoot() {
        return this._syncRoot
      }
      get masterFrame() {
        return 0 === this._runtimeAnimations.length ? 0 : this._runtimeAnimations[0].currentFrame
      }
      get weight() {
        return this._weight
      }
      set weight(OO) {
        this._weight = -1 !== OO ? Math.min(Math.max(OO, 0), 1) : -1
      }
      get speedRatio() {
        return this._speedRatio
      }
      set speedRatio(OO) {
        for (let KO = 0; KO < this._runtimeAnimations.length; KO++) {
          this._runtimeAnimations[KO]._prepareForSpeedRatioChange(OO)
        }
        this._speedRatio = OO, null !== this._goToFrame && this.goToFrame(this._goToFrame)
      }
      get elapsedTime() {
        return null === this._localDelayOffset ? 0 : this._scene._animationTime - this._localDelayOffset
      }
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 100,
          eO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
          lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1,
          vK = arguments.length > 6 ? arguments[6] : void 0,
          CO = arguments.length > 7 ? arguments[7] : void 0,
          hO = arguments.length > 8 ? arguments[8] : void 0,
          DO = arguments.length > 9 && void 0 !== arguments[9] && arguments[9],
          MO = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : 0;
        this.target = KO, this.fromFrame = pO, this.toFrame = XO, this.loopAnimation = eO, this.onAnimationEnd = vK, this.onAnimationLoop = hO, this.isAdditive = DO, this.playOrder = MO, this._localDelayOffset = null, this._pausedDelay = null, this._manualJumpDelay = null, this._runtimeAnimations = new Array, this.YL = !1, this._speedRatio = 1, this._weight = -1, this._previousWeight = -1, this._syncRoot = null, this._frameToSyncFromJump = null, this._goToFrame = null, this.disposeOnEnd = !0, this.animationStarted = !1, this.onAnimationEndObservable = new bK.e, this.onAnimationLoopObservable = new bK.e, this._scene = OO, CO && this.appendAnimations(KO, CO), this._speedRatio = lO, OO._activeAnimatables.push(this)
      }
      syncWith(OO) {
        if (this._syncRoot = OO, OO) {
          const OO = this._scene._activeAnimatables.indexOf(this);
          OO > -1 && (this._scene._activeAnimatables.splice(OO, 1), this._scene._activeAnimatables.push(this))
        }
        return this
      }
      getAnimations() {
        return this._runtimeAnimations
      }
      appendAnimations(OO, KO) {
        for (let pO = 0; pO < KO.length; pO++) {
          const XO = KO[pO],
            bK = new gK(OO, XO, this._scene, this);
          bK._onLoop = () => {
            this.onAnimationLoopObservable.notifyObservers(this), this.onAnimationLoop && this.onAnimationLoop()
          }, this._runtimeAnimations.push(bK)
        }
      }
      getAnimationByTargetProperty(OO) {
        const KO = this._runtimeAnimations;
        for (let pO = 0; pO < KO.length; pO++)
          if (KO[pO].animation.targetProperty === OO) return KO[pO].animation;
        return null
      }
      getRuntimeAnimationByTargetProperty(OO) {
        const KO = this._runtimeAnimations;
        for (let pO = 0; pO < KO.length; pO++)
          if (KO[pO].animation.targetProperty === OO) return KO[pO];
        return null
      }
      reset() {
        const OO = this._runtimeAnimations;
        for (let KO = 0; KO < OO.length; KO++) OO[KO].reset(!0);
        this._localDelayOffset = null, this._pausedDelay = null
      }
      enableBlending(OO) {
        const KO = this._runtimeAnimations;
        for (let pO = 0; pO < KO.length; pO++) KO[pO].animation.enableBlending = !0, KO[pO].animation.blendingSpeed = OO
      }
      disableBlending() {
        const OO = this._runtimeAnimations;
        for (let KO = 0; KO < OO.length; KO++) OO[KO].animation.enableBlending = !1
      }
      goToFrame(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = this._runtimeAnimations;
        if (pO[0]) {
          const KO = pO[0].animation.framePerSecond;
          this._frameToSyncFromJump = this._frameToSyncFromJump ?? pO[0].currentFrame;
          const XO = 0 === this.speedRatio ? 0 : (OO - this._frameToSyncFromJump) / KO * 1e3 / this.speedRatio;
          this._manualJumpDelay = -XO
        }
        for (let XO = 0; XO < pO.length; XO++) pO[XO].goToFrame(OO, KO ? this._weight : -1);
        this._goToFrame = OO
      }
      get paused() {
        return this.YL
      }
      pause() {
        this.YL || (this.YL = !0)
      }
      restart() {
        this.YL = !1
      }
      _raiseOnAnimationEnd() {
        this.onAnimationEnd && this.onAnimationEnd(), this.onAnimationEndObservable.notifyObservers(this)
      }
      stop(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        if (OO || KO) {
          const bK = this._scene._activeAnimatables.indexOf(this);
          if (bK > -1) {
            const eO = this._runtimeAnimations;
            for (let pO = eO.length - 1; pO >= 0; pO--) {
              const XO = eO[pO];
              OO && XO.animation.name != OO || (KO && !KO(XO.target) || (XO.dispose(), eO.splice(pO, 1)))
            }
            0 == eO.length && (pO || this._scene._activeAnimatables.splice(bK, 1), XO || this._raiseOnAnimationEnd())
          }
        } else {
          const OO = this._scene._activeAnimatables.indexOf(this);
          if (OO > -1) {
            pO || this._scene._activeAnimatables.splice(OO, 1);
            const KO = this._runtimeAnimations;
            for (let OO = 0; OO < KO.length; OO++) KO[OO].dispose();
            this._runtimeAnimations.length = 0, XO || this._raiseOnAnimationEnd()
          }
        }
      }
      async waitAsync() {
        return await new Promise((OO => {
          this.onAnimationEndObservable.add((() => {
            OO(this)
          }), void 0, void 0, this, !0)
        }))
      }
      _animate(OO) {
        if (this.YL) return this.animationStarted = !1, null === this._pausedDelay && (this._pausedDelay = OO), !0;
        if (null === this._localDelayOffset ? (this._localDelayOffset = OO, this._pausedDelay = null) : null !== this._pausedDelay && (this._localDelayOffset += OO - this._pausedDelay, this._pausedDelay = null), null !== this._manualJumpDelay && (this._localDelayOffset += this.speedRatio < 0 ? -this._manualJumpDelay : this._manualJumpDelay, this._manualJumpDelay = null, this._frameToSyncFromJump = null), this._goToFrame = null, !EO.ProcessPausedAnimatables && 0 === this._weight && 0 === this._previousWeight) return !0;
        this._previousWeight = this._weight;
        let KO = !1;
        const pO = this._runtimeAnimations;
        let XO;
        for (XO = 0; XO < pO.length; XO++) {
          const bK = pO[XO].animate(OO - this._localDelayOffset, this.fromFrame, this.toFrame, this.loopAnimation, this._speedRatio, this._weight);
          KO = KO || bK
        }
        if (this.animationStarted = KO, !KO) {
          if (this.disposeOnEnd)
            for (XO = this._scene._activeAnimatables.indexOf(this), this._scene._activeAnimatables.splice(XO, 1), XO = 0; XO < pO.length; XO++) pO[XO].dispose();
          this._raiseOnAnimationEnd(), this.disposeOnEnd && (this.onAnimationEnd = null, this.onAnimationLoop = null, this.onAnimationLoopObservable.clear(), this.onAnimationEndObservable.clear())
        }
        return KO
      }
    }

    function jK(OO) {
      if (0 === OO.totalWeight && 0 === OO.totalAdditiveWeight) return OO.originalValue;
      let KO = 1;
      const pO = eO.j.WX[0],
        XO = eO.j.WX[1],
        bK = eO.j.Quaternion[0];
      let lO = 0;
      const vK = OO.animations[0],
        CO = OO.originalValue;
      let hO, DO = !1;
      if (OO.totalWeight < 1) hO = 1 - OO.totalWeight, CO.decompose(XO, bK, pO);
      else {
        if (lO = 1, KO = OO.totalWeight, hO = vK.weight / KO, 1 == hO) {
          if (!OO.totalAdditiveWeight) return vK.currentValue;
          DO = !0
        }
        vK.currentValue.decompose(XO, bK, pO)
      }
      if (!DO) {
        XO.scaleInPlace(hO), pO.scaleInPlace(hO), bK.scaleInPlace(hO);
        for (let vK = lO; vK < OO.animations.length; vK++) {
          const lO = OO.animations[vK];
          if (0 === lO.weight) continue;
          hO = lO.weight / KO;
          const CO = eO.j.WX[2],
            DO = eO.j.WX[3],
            MO = eO.j.Quaternion[1];
          lO.currentValue.decompose(DO, MO, CO), DO.scaleAndAddToRef(hO, XO), MO.scaleAndAddToRef(eO.g.Dot(bK, MO) > 0 ? hO : -hO, bK), CO.scaleAndAddToRef(hO, pO)
        }
        bK.normalize()
      }
      for (let aK = 0; aK < OO.additiveAnimations.length; aK++) {
        const KO = OO.additiveAnimations[aK];
        if (0 === KO.weight) continue;
        const lO = eO.j.WX[2],
          vK = eO.j.WX[3],
          CO = eO.j.Quaternion[1];
        KO.currentValue.decompose(vK, CO, lO), vK.multiplyToRef(XO, vK), eO.o.LerpToRef(XO, vK, KO.weight, XO), bK.multiplyToRef(CO, CO), eO.g.SlerpToRef(bK, CO, KO.weight, bK), lO.scaleAndAddToRef(KO.weight, pO)
      }
      const MO = vK ? vK._animationState.workValue : eO.j.Matrix[0].clone();
      return eO.c.ComposeToRef(XO, bK, pO, MO), MO
    }

    function YO(OO, KO) {
      if (0 === OO.totalWeight && 0 === OO.totalAdditiveWeight) return KO;
      const pO = OO.animations[0],
        XO = OO.originalValue;
      let bK = KO;
      if (0 === OO.totalWeight && OO.totalAdditiveWeight > 0) bK.NhO(XO);
      else if (1 === OO.animations.length) {
        if (eO.g.SlerpToRef(XO, pO.currentValue, Math.min(1, OO.totalWeight), bK), 0 === OO.totalAdditiveWeight) return bK
      } else if (OO.animations.length > 1) {
        let pO, lO, vK = 1;
        if (OO.totalWeight < 1) {
          const KO = 1 - OO.totalWeight;
          pO = [], lO = [], pO.push(XO), lO.push(KO)
        } else {
          if (2 === OO.animations.length && (eO.g.SlerpToRef(OO.animations[0].currentValue, OO.animations[1].currentValue, OO.animations[1].weight / OO.totalWeight, KO), 0 === OO.totalAdditiveWeight)) return KO;
          pO = [], lO = [], vK = OO.totalWeight
        }
        for (let KO = 0; KO < OO.animations.length; KO++) {
          const XO = OO.animations[KO];
          pO.push(XO.currentValue), lO.push(XO.weight / vK)
        }
        let CO = 0;
        for (let OO = 0; OO < pO.length;) OO ? (CO += lO[OO], eO.g.SlerpToRef(bK, pO[OO], lO[OO] / CO, bK), OO++) : (eO.g.SlerpToRef(pO[OO], pO[OO + 1], lO[OO + 1] / (lO[OO] + lO[OO + 1]), KO), bK = KO, CO = lO[OO] + lO[OO + 1], OO += 2)
      }
      for (let lO = 0; lO < OO.additiveAnimations.length; lO++) {
        const KO = OO.additiveAnimations[lO];
        0 !== KO.weight && (bK.multiplyToRef(KO.currentValue, eO.j.Quaternion[0]), eO.g.SlerpToRef(bK, eO.j.Quaternion[0], KO.weight, bK))
      }
      return bK
    }

    function wO(OO, KO) {
      KO && (KO.prototype.copyAnimationRange = function(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
        0 === this.animations.length && (this.animations.push(new yK.e(this.name, "_matrix", OO.animations[0].framePerSecond, yK.e.ANIMATIONTYPE_MATRIX, 0)), this.animations[0].setKeys([]));
        const eO = OO.animations[0].getRange(KO);
        if (!eO) return !1;
        const lO = eO.from,
          vK = eO.to,
          CO = OO.animations[0].getKeys(),
          hO = OO.length,
          DO = OO.getParent(),
          MO = this.getParent(),
          aK = XO && DO && hO && this.length && hO !== this.length,
          oO = aK && MO && DO ? MO.length / DO.length : 1,
          FO = XO && !MO && bK && (1 !== bK.x || 1 !== bK.y || 1 !== bK.z),
          VO = this.animations[0].getKeys();
        let LO, QO, zK;
        for (let AO = 0, fO = CO.length; AO < fO; AO++) LO = CO[AO], LO.frame >= lO && LO.frame <= vK && (XO ? (zK = LO.value.clone(), aK ? (QO = zK.getTranslation(), zK.setTranslation(QO.scaleInPlace(oO))) : FO && bK ? (QO = zK.getTranslation(), zK.setTranslation(QO.multiplyInPlace(bK))) : zK = LO.value) : zK = LO.value, VO.push({
          frame: LO.frame + pO,
          value: zK
        }));
        return this.animations[0].createRange(KO, lO + pO, vK + pO), !0
      }), OO && (OO.prototype._animate = function(OO) {
        const KO = this._animationWrites,
          pO = this._animationWriteCount;
        let XO = 0;
        for (let eO = this._animationStepWriteCount; eO < pO; eO++) {
          const OO = KO[eO];
          OO.El && -1 === OO.weight || (OO.El = !0, KO[eO] = KO[XO], KO[XO] = OO, XO++)
        }
        for (let eO = XO; eO < pO; eO++) {
          const OO = KO[eO];
          OO.runtimeAnimation = null, OO.target = null
        }
        if (this._animationWriteCount = XO, this._animationStepWriteCount = 0, this._animationStepEvaluated = !1, !this.animationsEnabled) return;
        const bK = uO.d.Now;
        if (!this._animationTimeLast) {
          if (this._pendingData.length > 0) return;
          this._animationTimeLast = bK
        }
        this.deltaTime = void 0 !== OO ? OO : this.useConstantAnimationDeltaTime ? 16 : (bK - this._animationTimeLast) * this.animationTimeScale, this._animationTimeLast = bK;
        const lO = this._activeAnimatables;
        if (0 === lO.length) return;
        this._animationTime += this.deltaTime;
        const vK = this._animationTime;
        this._animationStepEvaluated = !0;
        for (let eO = 0; eO < lO.length; eO++) {
          const OO = lO[eO];
          !OO._animate(vK) && OO.disposeOnEnd && eO--
        }! function(OO) {
          if (OO._registeredForLateAnimationBindings.length) {
            for (let KO = 0; KO < OO._registeredForLateAnimationBindings.length; KO++) {
              const pO = OO._registeredForLateAnimationBindings.data[KO];
              for (const OO in pO._lateAnimationHolders) {
                const KO = pO._lateAnimationHolders[OO],
                  XO = KO.animations[0],
                  bK = KO.originalValue;
                if (void 0 === bK || null === bK) continue;
                const lO = yK.e.AllowMatrixDecomposeForInterpolation && bK.m;
                let vK = pO[OO];
                if (lO) vK = jK(KO);
                else if (void 0 !== bK.w) vK = YO(KO, vK || eO.g.Identity());
                else {
                  let OO = 0,
                    pO = 1;
                  const eO = XO && XO._animationState.i4 === yK.e.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT;
                  if (KO.totalWeight < 1) vK = eO ? bK.clone ? bK.clone() : bK : XO && bK.scale ? bK.scale(1 - KO.totalWeight) : XO ? bK * (1 - KO.totalWeight) : bK.clone ? bK.clone() : bK;
                  else if (XO) {
                    pO = KO.totalWeight;
                    const lO = XO.weight / pO;
                    vK = 1 !== lO ? XO.currentValue.scale ? XO.currentValue.scale(lO) : XO.currentValue * lO : (KO.animations.length > 1 || KO.additiveAnimations.length > 0) && XO.currentValue.clone ? XO.currentValue.clone() : XO.currentValue, eO && (vK.addToRef ? vK.addToRef(bK, vK) : vK += bK), OO = 1
                  }
                  for (let XO = OO; XO < KO.animations.length; XO++) {
                    const OO = KO.animations[XO],
                      bK = OO.weight / pO;
                    bK && (OO.currentValue.scaleAndAddToRef ? OO.currentValue.scaleAndAddToRef(bK, vK) : vK += OO.currentValue * bK)
                  }
                  for (let XO = 0; XO < KO.additiveAnimations.length; XO++) {
                    const OO = KO.additiveAnimations[XO],
                      pO = OO.weight;
                    pO && (OO.currentValue.scaleAndAddToRef ? OO.currentValue.scaleAndAddToRef(pO, vK) : vK += OO.currentValue * pO)
                  }
                }
                pO[OO] = vK
              }
              pO._lateAnimationHolders = {}
            }
            OO._registeredForLateAnimationBindings.reset()
          }
        }(this), this._animationStepWriteCount = this._animationWriteCount
      }, OO.prototype.sortActiveAnimatables = function() {
        this._activeAnimatables.sort(((OO, KO) => OO.playOrder - KO.playOrder))
      }, OO.prototype.beginWeightedAnimation = function(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
          bK = arguments.length > 4 ? arguments[4] : void 0,
          eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1,
          lO = arguments.length > 6 ? arguments[6] : void 0,
          vK = arguments.length > 7 ? arguments[7] : void 0,
          CO = arguments.length > 8 ? arguments[8] : void 0,
          hO = arguments.length > 9 ? arguments[9] : void 0,
          DO = arguments.length > 10 && void 0 !== arguments[10] && arguments[10];
        const MO = this.beginAnimation(OO, KO, pO, bK, eO, lO, vK, !1, CO, hO, DO);
        return MO.weight = XO, MO
      }, OO.prototype.beginAnimation = function(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
          eO = arguments.length > 5 ? arguments[5] : void 0,
          lO = arguments.length > 6 ? arguments[6] : void 0,
          vK = !(arguments.length > 7 && void 0 !== arguments[7]) || arguments[7],
          CO = arguments.length > 8 ? arguments[8] : void 0,
          hO = arguments.length > 9 ? arguments[9] : void 0,
          DO = arguments.length > 10 && void 0 !== arguments[10] && arguments[10];
        if (bK < 0) {
          const OO = KO;
          KO = pO, pO = OO, bK = -bK
        }
        KO > pO && (bK = -bK), vK && this.stopAnimation(OO, void 0, CO), lO || (lO = new EO(this, OO, KO, pO, XO, bK, eO, void 0, hO, DO));
        const MO = !CO || CO(OO);
        if (OO.animations && MO && lO.appendAnimations(OO, OO.animations), OO.getAnimatables) {
          const DO = OO.getAnimatables();
          for (let OO = 0; OO < DO.length; OO++) this.beginAnimation(DO[OO], KO, pO, XO, bK, eO, lO, vK, CO, hO)
        }
        return lO.reset(), lO
      }, OO.prototype.beginHierarchyAnimation = function(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1,
          lO = arguments.length > 6 ? arguments[6] : void 0,
          vK = arguments.length > 7 ? arguments[7] : void 0,
          CO = !(arguments.length > 8 && void 0 !== arguments[8]) || arguments[8],
          hO = arguments.length > 9 ? arguments[9] : void 0,
          DO = arguments.length > 11 && void 0 !== arguments[11] && arguments[11];
        const MO = OO.getDescendants(KO),
          aK = [];
        aK.push(this.beginAnimation(OO, pO, XO, bK, eO, lO, vK, CO, hO, void 0, DO));
        for (const oO of MO) aK.push(this.beginAnimation(oO, pO, XO, bK, eO, lO, vK, CO, hO, void 0, DO));
        return aK
      }, OO.prototype.beginDirectAnimation = function(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1;
        if (eO < 0) {
          const OO = pO;
          pO = XO, XO = OO, eO = -eO
        }
        pO > XO && (eO = -eO);
        return new EO(this, OO, pO, XO, bK, eO, arguments.length > 6 ? arguments[6] : void 0, KO, arguments.length > 7 ? arguments[7] : void 0, arguments.length > 8 && void 0 !== arguments[8] && arguments[8])
      }, OO.prototype.beginDirectHierarchyAnimation = function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        let hO = arguments.length > 9 && void 0 !== arguments[9] && arguments[9];
        const DO = OO.getDescendants(KO),
          MO = [];
        MO.push(this.beginDirectAnimation(OO, pO, XO, bK, eO, lO, vK, CO, hO));
        for (const aK of DO) MO.push(this.beginDirectAnimation(aK, pO, XO, bK, eO, lO, vK, CO, hO));
        return MO
      }, OO.prototype.getAnimatableByTarget = function(OO) {
        for (let KO = 0; KO < this._activeAnimatables.length; KO++)
          if (this._activeAnimatables[KO].target === OO) return this._activeAnimatables[KO];
        return null
      }, OO.prototype.getAllAnimatablesByTarget = function(OO) {
        const KO = [];
        for (let pO = 0; pO < this._activeAnimatables.length; pO++) this._activeAnimatables[pO].target === OO && KO.push(this._activeAnimatables[pO]);
        return KO
      }, OO.prototype.stopAnimation = function(OO, KO, pO) {
        const XO = this.getAllAnimatablesByTarget(OO);
        for (const bK of XO) bK.stop(KO, pO)
      }, OO.prototype.stopAllAnimations = function() {
        if (this._activeAnimatables) {
          for (let OO = 0; OO < this._activeAnimatables.length; OO++) this._activeAnimatables[OO].stop(void 0, void 0, !0);
          this._activeAnimatables.length = 0
        }
        for (const OO of this.animationGroups) OO.stop()
      })
    }
    EO.ProcessPausedAnimatables = !1;
    var iK, rK = pO(35641),
      PO = pO(38301),
      mK = pO(37938);
    class sO extends PO.c {
      get _matrix() {
        return this._compose(), this._localMatrix
      }
      set _matrix(OO) {
        (OO.updateFlag !== this._localMatrix.updateFlag || this._needToCompose) && (this._needToCompose = !1, this._localMatrix.NhO(OO), this._markAsDirtyAndDecompose())
      }
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
          bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
          lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
          vK = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null;
        super(OO, KO.JKO(), !1), this.name = OO, this.children = [], this.animations = [], this._index = null, this._scalingDeterminant = 1, this._needToDecompose = !0, this._needToCompose = !1, this._linkedTransformNode = null, this._waitingTransformNodeId = null, this._waitingTransformNodeUniqueId = null, this._skeleton = KO, this._localMatrix = XO?.clone() ?? eO.c.Identity(), this._restMatrix = bK ?? this._localMatrix.clone(), this._bindMatrix = lO ?? this._localMatrix.clone(), this._index = vK, this._absoluteMatrix = new eO.c, this._absoluteBindMatrix = new eO.c, this._absoluteInverseBindMatrix = new eO.c, this._finalMatrix = new eO.c, KO.bones.push(this), this.setParent(pO, !1), this._updateAbsoluteBindMatrices()
      }
      getClassName() {
        return "Bone"
      }
      getSkeleton() {
        return this._skeleton
      }
      get parent() {
        return this._parentNode
      }
      getParent() {
        return this.parent
      }
      getChildren() {
        return this.children
      }
      getIndex() {
        return null === this._index ? this.getSkeleton().bones.indexOf(this) : this._index
      }
      set parent(OO) {
        this.setParent(OO)
      }
      setParent(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (this.parent !== OO) {
          if (this.parent) {
            const OO = this.parent.children.indexOf(this); - 1 !== OO && this.parent.children.splice(OO, 1)
          }
          this._parentNode = OO, this.parent && this.parent.children.push(this), KO && this._updateAbsoluteBindMatrices(), this.jhO()
        }
      }
      getLocalMatrix() {
        return this._compose(), this._localMatrix
      }
      getBindMatrix() {
        return this._bindMatrix
      }
      getBaseMatrix() {
        return this.getBindMatrix()
      }
      getRestMatrix() {
        return this._restMatrix
      }
      getRestPose() {
        return this.getRestMatrix()
      }
      setRestMatrix(OO) {
        this._restMatrix.NhO(OO)
      }
      setRestPose(OO) {
        this.setRestMatrix(OO)
      }
      getBindPose() {
        return this.getBindMatrix()
      }
      setBindMatrix(OO) {
        this.AlO(OO)
      }
      setBindPose(OO) {
        this.setBindMatrix(OO)
      }
      getFinalMatrix() {
        return this._finalMatrix
      }
      getWorldMatrix() {
        return this.getFinalMatrix()
      }
      returnToRest() {
        if (this._linkedTransformNode) {
          const OO = eO.j.WX[0],
            KO = eO.j.Quaternion[0],
            pO = eO.j.WX[1];
          this.getRestMatrix().decompose(OO, KO, pO), this._linkedTransformNode.position.NhO(pO), this._linkedTransformNode.rotationQuaternion = this._linkedTransformNode.rotationQuaternion ?? eO.g.Identity(), this._linkedTransformNode.rotationQuaternion.NhO(KO), this._linkedTransformNode.ol.NhO(OO)
        } else this._matrix = this._restMatrix
      }
      getAbsoluteInverseBindMatrix() {
        return this._absoluteInverseBindMatrix
      }
      getInvertedAbsoluteTransform() {
        return this.getAbsoluteInverseBindMatrix()
      }
      getAbsoluteMatrix() {
        return this._skeleton.computeAbsoluteMatrices(), this._absoluteMatrix
      }
      getAbsoluteTransform() {
        return this.getAbsoluteMatrix()
      }
      linkTransformNode(OO) {
        this._linkedTransformNode && this._skeleton._numBonesWithLinkedTransformNode--, this._linkedTransformNode = OO, this._linkedTransformNode && this._skeleton._numBonesWithLinkedTransformNode++
      }
      getTransformNode() {
        return this._linkedTransformNode
      }
      get position() {
        return this._decompose(), this.ZvO
      }
      set position(OO) {
        this._decompose(), this.ZvO.NhO(OO), this._markAsDirtyAndCompose()
      }
      get rotation() {
        return this.getRotation()
      }
      set rotation(OO) {
        this.setRotation(OO)
      }
      get rotationQuaternion() {
        return this._decompose(), this._localRotation
      }
      set rotationQuaternion(OO) {
        this.setRotationQuaternion(OO)
      }
      get ol() {
        return this.getScale()
      }
      set ol(OO) {
        this.setScale(OO)
      }
      get animationPropertiesOverride() {
        return this._skeleton.animationPropertiesOverride
      }
      _decompose() {
        this._needToDecompose && (this._needToDecompose = !1, this._localScaling || (this._localScaling = eO.o.Zero(), this._localRotation = eO.g.Zero(), this.ZvO = eO.o.Zero()), this._localMatrix.decompose(this._localScaling, this._localRotation, this.ZvO))
      }
      _compose() {
        this._needToCompose && (this._localScaling ? (this._needToCompose = !1, eO.c.ComposeToRef(this._localScaling, this._localRotation, this.ZvO, this._localMatrix)) : this._needToCompose = !1)
      }
      AlO(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        this._bindMatrix.NhO(OO), KO && this._updateAbsoluteBindMatrices(), pO ? this._matrix = OO : this.jhO()
      }
      _updateAbsoluteBindMatrices(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (OO || (OO = this._bindMatrix), this.parent ? OO.multiplyToRef(this.parent._absoluteBindMatrix, this._absoluteBindMatrix) : this._absoluteBindMatrix.NhO(OO), this._absoluteBindMatrix.invertToRef(this._absoluteInverseBindMatrix), KO)
          for (let pO = 0; pO < this.children.length; pO++) this.children[pO]._updateAbsoluteBindMatrices();
        this._scalingDeterminant = this._absoluteBindMatrix.determinant() < 0 ? -1 : 1
      }
      jhO() {
        return this._currentRenderId++, this._childUpdateId++, this._skeleton._markAsDirty(), this
      }
      _markAsDirtyAndCompose() {
        this.jhO(), this._needToCompose = !0
      }
      _markAsDirtyAndDecompose() {
        this.jhO(), this._needToDecompose = !0
      }
      _updatePosition(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        const bK = this.getLocalMatrix();
        if (0 == KO) XO ? (bK.addAtIndex(12, OO.x), bK.addAtIndex(13, OO.y), bK.addAtIndex(14, OO.z)) : bK.setTranslationFromFloats(OO.x, OO.y, OO.z);
        else {
          const KO = sO._TmpMats[0],
            lO = sO._TmpVecs[0];
          this.parent ? (KO.NhO(this.parent.getAbsoluteMatrix()), pO && KO.multiplyToRef(pO.getWorldMatrix(), KO)) : eO.c.IdentityToRef(KO), XO && KO.setTranslationFromFloats(0, 0, 0), KO.invert(), eO.o.TransformCoordinatesToRef(OO, KO, lO), XO ? (bK.addAtIndex(12, lO.x), bK.addAtIndex(13, lO.y), bK.addAtIndex(14, lO.z)) : bK.setTranslationFromFloats(lO.x, lO.y, lO.z)
        }
        this._markAsDirtyAndDecompose()
      }
      translate(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        this._updatePosition(OO, KO, pO, !0)
      }
      setPosition(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        this._updatePosition(OO, KO, pO, !1)
      }
      setAbsolutePosition(OO, KO) {
        this.setPosition(OO, 1, KO)
      }
      scale(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        const bK = this.getLocalMatrix(),
          lO = sO._TmpMats[0];
        eO.c.ScalingToRef(OO, KO, pO, lO), lO.multiplyToRef(bK, bK), lO.invert();
        for (const eO of this.children) {
          const XO = eO.getLocalMatrix();
          XO.multiplyToRef(lO, XO), XO.multiplyAtIndex(12, OO), XO.multiplyAtIndex(13, KO), XO.multiplyAtIndex(14, pO), eO._markAsDirtyAndDecompose()
        }
        if (this._markAsDirtyAndDecompose(), XO)
          for (const eO of this.children) eO.scale(OO, KO, pO, XO)
      }
      setScale(OO) {
        this._decompose(), this._localScaling.NhO(OO), this._markAsDirtyAndCompose()
      }
      getScale() {
        return this._decompose(), this._localScaling
      }
      getScaleToRef(OO) {
        this._decompose(), OO.NhO(this._localScaling)
      }
      setYawPitchRoll(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
          bK = arguments.length > 4 ? arguments[4] : void 0;
        if (0 === XO) {
          const lO = sO._TmpQuat;
          return eO.g.RotationYawPitchRollToRef(OO, KO, pO, lO), void this.setRotationQuaternion(lO, XO, bK)
        }
        const lO = sO._TmpMats[0];
        if (!this._getAbsoluteInverseMatrixUnscaledToRef(lO, bK)) return;
        const vK = sO._TmpMats[1];
        eO.c.RotationYawPitchRollToRef(OO, KO, pO, vK), lO.multiplyToRef(vK, vK), this._rotateWithMatrix(vK, XO, bK)
      }
      rotate(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        const bK = sO._TmpMats[0];
        bK.setTranslationFromFloats(0, 0, 0), eO.c.RotationAxisToRef(OO, KO, bK), this._rotateWithMatrix(bK, pO, XO)
      }
      setAxisAngle(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        if (0 === pO) {
          const bK = sO._TmpQuat;
          return eO.g.RotationAxisToRef(OO, KO, bK), void this.setRotationQuaternion(bK, pO, XO)
        }
        const bK = sO._TmpMats[0];
        if (!this._getAbsoluteInverseMatrixUnscaledToRef(bK, XO)) return;
        const lO = sO._TmpMats[1];
        eO.c.RotationAxisToRef(OO, KO, lO), bK.multiplyToRef(lO, lO), this._rotateWithMatrix(lO, pO, XO)
      }
      setRotation(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        this.setYawPitchRoll(OO.y, OO.x, OO.z, KO, pO)
      }
      setRotationQuaternion(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        if (0 === KO) return this._decompose(), this._localRotation.NhO(OO), void this._markAsDirtyAndCompose();
        const XO = sO._TmpMats[0];
        if (!this._getAbsoluteInverseMatrixUnscaledToRef(XO, pO)) return;
        const bK = sO._TmpMats[1];
        eO.c.FromQuaternionToRef(OO, bK), XO.multiplyToRef(bK, bK), this._rotateWithMatrix(bK, KO, pO)
      }
      setRotationMatrix(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        if (0 === KO) {
          const XO = sO._TmpQuat;
          return eO.g.FromRotationMatrixToRef(OO, XO), void this.setRotationQuaternion(XO, KO, pO)
        }
        const XO = sO._TmpMats[0];
        if (!this._getAbsoluteInverseMatrixUnscaledToRef(XO, pO)) return;
        const bK = sO._TmpMats[1];
        bK.NhO(OO), XO.multiplyToRef(OO, bK), this._rotateWithMatrix(bK, KO, pO)
      }
      _rotateWithMatrix(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const XO = this.getLocalMatrix(),
          bK = XO.m[12],
          eO = XO.m[13],
          lO = XO.m[14],
          vK = this.getParent(),
          CO = sO._TmpMats[3],
          hO = sO._TmpMats[4];
        vK && 1 == KO ? (pO ? (CO.NhO(pO.getWorldMatrix()), vK.getAbsoluteMatrix().multiplyToRef(CO, CO)) : CO.NhO(vK.getAbsoluteMatrix()), hO.NhO(CO), hO.invert(), XO.multiplyToRef(CO, XO), XO.multiplyToRef(OO, XO), XO.multiplyToRef(hO, XO)) : 1 == KO && pO ? (CO.NhO(pO.getWorldMatrix()), hO.NhO(CO), hO.invert(), XO.multiplyToRef(CO, XO), XO.multiplyToRef(OO, XO), XO.multiplyToRef(hO, XO)) : XO.multiplyToRef(OO, XO), XO.setTranslationFromFloats(bK, eO, lO), this._markAsDirtyAndDecompose()
      }
      _getAbsoluteInverseMatrixUnscaledToRef(OO, KO) {
        const pO = sO._TmpMats[2];
        return OO.NhO(this.getAbsoluteMatrix()), KO ? (OO.multiplyToRef(KO.getWorldMatrix(), OO), eO.c.ScalingToRef(KO.ol.x, KO.ol.y, KO.ol.z, pO)) : eO.c.IdentityToRef(pO), OO.invert(), !isNaN(OO.m[0]) && (pO.multiplyAtIndex(0, this._scalingDeterminant), OO.multiplyToRef(pO, OO), !0)
      }
      fV() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        const pO = eO.o.Zero();
        return this.getPositionToRef(OO, KO, pO), pO
      }
      getPositionToRef() {
        let OO = arguments.length > 1 ? arguments[1] : void 0,
          KO = arguments.length > 2 ? arguments[2] : void 0;
        if (0 == (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0)) {
          const OO = this.getLocalMatrix();
          KO.x = OO.m[12], KO.y = OO.m[13], KO.z = OO.m[14]
        } else {
          const pO = sO._TmpMats[0].NhO(this.getAbsoluteMatrix());
          OO && pO.multiplyToRef(OO.getWorldMatrix(), pO), KO.x = pO.m[12], KO.y = pO.m[13], KO.z = pO.m[14]
        }
      }
      getAbsolutePosition() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        const KO = eO.o.Zero();
        return this.getPositionToRef(1, OO, KO), KO
      }
      getAbsolutePositionToRef(OO, KO) {
        this.getPositionToRef(1, OO, KO)
      }
      computeAbsoluteMatrices() {
        if (this._compose(), this.parent) this._localMatrix.multiplyToRef(this.parent._absoluteMatrix, this._absoluteMatrix);
        else {
          this._absoluteMatrix.NhO(this._localMatrix);
          const OO = this._skeleton.getPoseMatrix();
          OO && this._absoluteMatrix.multiplyToRef(OO, this._absoluteMatrix)
        }
        const OO = this.children,
          KO = OO.length;
        for (let pO = 0; pO < KO; pO++) OO[pO].computeAbsoluteMatrices()
      }
      computeAbsoluteTransforms() {
        this.computeAbsoluteMatrices()
      }
      YbO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        const pO = eO.o.Zero();
        return this.getDirectionToRef(OO, KO, pO), pO
      }
      getDirectionToRef(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const XO = sO._TmpMats[0].NhO(this.getAbsoluteMatrix());
        KO && XO.multiplyToRef(KO.getWorldMatrix(), XO), eO.o.TransformNormalToRef(OO, XO, pO), pO.normalize()
      }
      getRotation() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        const pO = eO.o.Zero();
        return this.getRotationToRef(OO, KO, pO), pO
      }
      getRotationToRef() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const XO = sO._TmpQuat;
        this.getRotationQuaternionToRef(OO, KO, XO), XO.toEulerAnglesToRef(pO)
      }
      getRotationQuaternion() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        const pO = eO.g.Identity();
        return this.getRotationQuaternionToRef(OO, KO, pO), pO
      }
      getRotationQuaternionToRef() {
        let OO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          KO = arguments.length > 2 ? arguments[2] : void 0;
        if (0 == (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0)) this._decompose(), KO.NhO(this._localRotation);
        else {
          const pO = sO._TmpMats[0],
            XO = this.getAbsoluteMatrix();
          OO ? XO.multiplyToRef(OO.getWorldMatrix(), pO) : pO.NhO(XO), pO.multiplyAtIndex(0, this._scalingDeterminant), pO.multiplyAtIndex(1, this._scalingDeterminant), pO.multiplyAtIndex(2, this._scalingDeterminant), pO.decompose(void 0, KO, void 0)
        }
      }
      getRotationMatrix() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 ? arguments[1] : void 0;
        const pO = eO.c.Identity();
        return this.getRotationMatrixToRef(OO, KO, pO), pO
      }
      getRotationMatrixToRef() {
        let OO = arguments.length > 1 ? arguments[1] : void 0,
          KO = arguments.length > 2 ? arguments[2] : void 0;
        if (0 == (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0)) this.getLocalMatrix().getRotationMatrixToRef(KO);
        else {
          const pO = sO._TmpMats[0],
            XO = this.getAbsoluteMatrix();
          OO ? XO.multiplyToRef(OO.getWorldMatrix(), pO) : pO.NhO(XO), pO.multiplyAtIndex(0, this._scalingDeterminant), pO.multiplyAtIndex(1, this._scalingDeterminant), pO.multiplyAtIndex(2, this._scalingDeterminant), pO.getRotationMatrixToRef(KO)
        }
      }
      getAbsolutePositionFromLocal(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        const pO = eO.o.Zero();
        return this.getAbsolutePositionFromLocalToRef(OO, KO, pO), pO
      }
      getAbsolutePositionFromLocalToRef(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const XO = sO._TmpMats[0].NhO(this.getAbsoluteMatrix());
        KO && XO.multiplyToRef(KO.getWorldMatrix(), XO), eO.o.TransformCoordinatesToRef(OO, XO, pO)
      }
      getLocalPositionFromAbsolute(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        const pO = eO.o.Zero();
        return this.getLocalPositionFromAbsoluteToRef(OO, KO, pO), pO
      }
      getLocalPositionFromAbsoluteToRef(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const XO = sO._TmpMats[0].NhO(this.getAbsoluteMatrix());
        KO && XO.multiplyToRef(KO.getWorldMatrix(), XO), XO.invert(), eO.o.TransformCoordinatesToRef(OO, XO, pO)
      }
      setCurrentPoseAsRest() {
        this.setRestMatrix(this.getLocalMatrix())
      }
      dispose() {
        this._linkedTransformNode = null;
        const OO = this._skeleton.bones.indexOf(this);
        if (-1 !== OO && this._skeleton.bones.splice(OO, 1), this._parentNode && this._parentNode.children) {
          const OO = this._parentNode.children,
            KO = OO.indexOf(this); - 1 !== KO && OO.splice(KO, 1)
        }
        super.dispose()
      }
    }
    sO._TmpVecs = (0, rK.d)(2, eO.o.Zero), sO._TmpQuat = eO.g.Identity(), sO._TmpMats = (0, rK.d)(5, eO.c.Identity), (iK = sO.prototype).copyAnimationRange ?? (iK.copyAnimationRange = (0, mK.h)("Bone", "copyAnimationRange"));
    var HO = pO(38170);
    let RO = !1;
    var SO = pO(38024),
      JO = pO(38416),
      cK = pO(38431),
      BO = pO(38424),
      ZO = pO(38202);

    function GO(OO, KO) {
      const pO = (0, oO.RandomRange)(0, 1);
      DO.g.LerpToRef(KO.color1, KO.color2, pO, OO.color)
    }

    function qK(OO, KO) {
      KO.colorDead.subtractToRef(OO.color, KO._colorDiff), KO._colorDiff.scaleToRef(1 / OO.lifeTime, OO.colorStep)
    }

    function xK(OO, KO) {
      OO._properties.currentColorGradient = KO._colorGradients[0], OO._properties.currentColorGradient.getColorToRef(OO.color), OO._properties.currentColor1.NhO(OO.color), KO._colorGradients.length > 1 ? KO._colorGradients[1].getColorToRef(OO._properties.currentColor2) : OO._properties.currentColor2.NhO(OO.color)
    }

    function nO(OO, KO) {
      const pO = KO._colorGradients;
      XO.k.GetCurrentGradient(KO._ratio, pO, ((KO, pO, XO) => {
        KO !== OO._properties.currentColorGradient && (OO._properties.currentColor1.NhO(OO._properties.currentColor2), pO.getColorToRef(OO._properties.currentColor2), OO._properties.currentColorGradient = KO), DO.g.LerpToRef(OO._properties.currentColor1, OO._properties.currentColor2, XO, OO.color), OO.color.a < 0 && (OO.color.a = 0)
      }))
    }

    function WO(OO, KO) {
      OO.colorStep.scaleToRef(KO._scaledUpdateSpeed, KO._scaledColorStep), OO.color.addInPlace(KO._scaledColorStep), OO.color.a < 0 && (OO.color.a = 0)
    }

    function tK(OO, KO) {
      XO.k.GetCurrentGradient(KO._ratio, KO._angularSpeedGradients, ((KO, pO, XO) => {
        KO !== OO._properties.currentAngularSpeedGradient && (OO._properties.currentAngularSpeed1 = OO._properties.currentAngularSpeed2, OO._properties.currentAngularSpeed2 = pO.getFactor(), OO._properties.currentAngularSpeedGradient = KO), OO.angularSpeed = (0, oO.Lerp)(OO._properties.currentAngularSpeed1, OO._properties.currentAngularSpeed2, XO)
      }))
    }

    function kK(OO, KO) {
      OO.angle += OO.angularSpeed * KO._scaledUpdateSpeed
    }

    function UO(OO, KO) {
      KO.particleEmitterType.startDirectionFunction(KO._emitterWorldMatrix, OO.direction, OO, KO.isLocal, KO._emitterInverseWorldMatrix)
    }

    function OK(OO, KO) {
      KO.startDirectionFunction(KO._emitterWorldMatrix, OO.direction, OO, KO.isLocal)
    }

    function KK(OO, KO) {
      OO._properties.currentVelocityGradient = KO._velocityGradients[0], OO._properties.currentVelocity1 = OO._properties.currentVelocityGradient.getFactor(), KO._velocityGradients.length > 1 ? OO._properties.currentVelocity2 = KO._velocityGradients[1].getFactor() : OO._properties.currentVelocity2 = OO._properties.currentVelocity1
    }

    function pK(OO, KO) {
      OO._properties.currentLimitVelocityGradient = KO._limitVelocityGradients[0], OO._properties.currentLimitVelocity1 = OO._properties.currentLimitVelocityGradient.getFactor(), KO._limitVelocityGradients.length > 1 ? OO._properties.currentLimitVelocity2 = KO._limitVelocityGradients[1].getFactor() : OO._properties.currentLimitVelocity2 = OO._properties.currentLimitVelocity1
    }

    function XK(OO, KO) {
      XO.k.GetCurrentGradient(KO._ratio, KO._velocityGradients, ((KO, pO, XO) => {
        KO !== OO._properties.currentVelocityGradient && (OO._properties.currentVelocity1 = OO._properties.currentVelocity2, OO._properties.currentVelocity2 = pO.getFactor(), OO._properties.currentVelocityGradient = KO), OO._properties.directionScale *= (0, oO.Lerp)(OO._properties.currentVelocity1, OO._properties.currentVelocity2, XO)
      }))
    }

    function bp(OO, KO) {
      XO.k.GetCurrentGradient(KO._ratio, KO._limitVelocityGradients, ((pO, XO, bK) => {
        pO !== OO._properties.currentLimitVelocityGradient && (OO._properties.currentLimitVelocity1 = OO._properties.currentLimitVelocity2, OO._properties.currentLimitVelocity2 = XO.getFactor(), OO._properties.currentLimitVelocityGradient = pO);
        const eO = (0, oO.Lerp)(OO._properties.currentLimitVelocity1, OO._properties.currentLimitVelocity2, bK);
        OO.direction.length() > eO && OO.direction.scaleInPlace(KO.limitVelocityDamping)
      }))
    }

    function eK(OO) {
      OO.direction.scaleToRef(OO._properties.directionScale, OO._properties.scaledDirection)
    }

    function lK(OO, KO) {
      KO.particleEmitterType.startPositionFunction(KO._emitterWorldMatrix, OO.position, OO, KO.isLocal)
    }

    function vp(OO, KO) {
      KO.startPositionFunction(KO._emitterWorldMatrix, OO.position, OO, KO.isLocal)
    }

    function CK(OO, KO) {
      OO._properties.localPosition ? OO._properties.localPosition.NhO(OO.position) : OO._properties.localPosition = OO.position.clone(), eO.o.TransformCoordinatesToRef(OO._properties.localPosition, KO._emitterWorldMatrix, OO.position)
    }

    function hK(OO, KO) {
      KO.isLocal && OO._properties.localPosition ? (OO._properties.localPosition.addInPlace(OO._properties.scaledDirection), eO.o.TransformCoordinatesToRef(OO._properties.localPosition, KO._emitterWorldMatrix, OO.position)) : OO.position.addInPlace(OO._properties.scaledDirection)
    }

    function DK(OO, KO) {
      OO._properties.currentDragGradient = KO._dragGradients[0], OO._properties.currentDrag1 = OO._properties.currentDragGradient.getFactor(), KO._dragGradients.length > 1 ? OO._properties.currentDrag2 = KO._dragGradients[1].getFactor() : OO._properties.currentDrag2 = OO._properties.currentDrag1
    }

    function MK(OO, KO) {
      XO.k.GetCurrentGradient(KO._ratio, KO._dragGradients, ((KO, pO, XO) => {
        KO !== OO._properties.currentDragGradient && (OO._properties.currentDrag1 = OO._properties.currentDrag2, OO._properties.currentDrag2 = pO.getFactor(), OO._properties.currentDragGradient = KO);
        const bK = (0, oO.Lerp)(OO._properties.currentDrag1, OO._properties.currentDrag2, XO);
        OO._properties.scaledDirection.scaleInPlace(1 - bK)
      }))
    }

    function ap(OO, KO) {
      OO._properties.randomNoiseCoordinates1 && OO._properties.randomNoiseCoordinates2 ? (OO._properties.randomNoiseCoordinates1.rvO(Math.random(), Math.random(), Math.random()), OO._properties.randomNoiseCoordinates2.rvO(Math.random(), Math.random(), Math.random())) : (OO._properties.randomNoiseCoordinates1 = new eO.o(Math.random(), Math.random(), Math.random()), OO._properties.randomNoiseCoordinates2 = new eO.o(Math.random(), Math.random(), Math.random()))
    }

    function oK(OO, KO) {
      const pO = KO._noiseTextureData,
        XO = KO._noiseTextureSize;
      if (pO && XO && OO._properties.randomNoiseCoordinates1 && OO._properties.randomNoiseCoordinates2) {
        const bK = KO._fetchR(OO._properties.randomNoiseCoordinates1.x, OO._properties.randomNoiseCoordinates1.y, XO.width, XO.height, pO),
          lO = KO._fetchR(OO._properties.randomNoiseCoordinates1.z, OO._properties.randomNoiseCoordinates2.x, XO.width, XO.height, pO),
          vK = KO._fetchR(OO._properties.randomNoiseCoordinates2.y, OO._properties.randomNoiseCoordinates2.z, XO.width, XO.height, pO),
          CO = eO.j.WX[0],
          hO = eO.j.WX[1];
        CO.rvO((2 * bK - 1) * KO.noiseStrength.x, (2 * lO - 1) * KO.noiseStrength.y, (2 * vK - 1) * KO.noiseStrength.z), CO.scaleToRef(KO._tempScaledUpdateSpeed, hO), OO.direction.addInPlace(hO)
      }
    }

    function FK(OO, KO) {
      KO.gravity.scaleToRef(KO._tempScaledUpdateSpeed, KO._scaledGravity), OO.direction.addInPlace(KO._scaledGravity)
    }

    function VK(OO, KO) {
      OO.size = (0, oO.RandomRange)(KO.minSize, KO.maxSize), OO.scale.rvO((0, oO.RandomRange)(KO.minScaleX, KO.maxScaleX), (0, oO.RandomRange)(KO.minScaleY, KO.maxScaleY))
    }

    function LK(OO, KO) {
      OO._properties.currentSizeGradient = KO._sizeGradients[0], OO._properties.currentSize1 = OO._properties.currentSizeGradient.getFactor(), OO.size = OO._properties.currentSize1, KO._sizeGradients.length > 1 ? OO._properties.currentSize2 = KO._sizeGradients[1].getFactor() : OO._properties.currentSize2 = OO._properties.currentSize1, OO.scale.rvO((0, oO.RandomRange)(KO.minScaleX, KO.maxScaleX), (0, oO.RandomRange)(KO.minScaleY, KO.maxScaleY))
    }

    function QK(OO, KO) {
      const pO = KO._actualFrame / KO.targetStopDuration;
      XO.k.GetCurrentGradient(pO, KO._startSizeGradients, ((pO, XO, bK) => {
        pO !== KO._currentStartSizeGradient && (KO._currentStartSize1 = KO._currentStartSize2, KO._currentStartSize2 = XO.getFactor(), KO._currentStartSizeGradient = pO);
        const eO = (0, oO.Lerp)(KO._currentStartSize1, KO._currentStartSize2, bK);
        OO.scale.scaleInPlace(eO)
      }))
    }

    function zp(OO, KO) {
      XO.k.GetCurrentGradient(KO._ratio, KO._sizeGradients, ((KO, pO, XO) => {
        KO !== OO._properties.currentSizeGradient && (OO._properties.currentSize1 = OO._properties.currentSize2, OO._properties.currentSize2 = pO.getFactor(), OO._properties.currentSizeGradient = KO), OO.size = (0, oO.Lerp)(OO._properties.currentSize1, OO._properties.currentSize2, XO)
      }))
    }

    function AK(OO, KO) {
      OO.remapData = new eO.s(0, 1, 0, 1)
    }

    function fK(OO, KO) {
      KO._colorRemapGradients && KO._colorRemapGradients.length > 0 && XO.k.GetCurrentGradient(KO._ratio, KO._colorRemapGradients, ((KO, pO, XO) => {
        const bK = (0, oO.Lerp)(KO.factor1, pO.factor1, XO),
          eO = (0, oO.Lerp)(KO.factor2, pO.factor2, XO);
        OO.remapData.x = bK, OO.remapData.y = eO - bK
      })), KO._alphaRemapGradients && KO._alphaRemapGradients.length > 0 && XO.k.GetCurrentGradient(KO._ratio, KO._alphaRemapGradients, ((KO, pO, XO) => {
        const bK = (0, oO.Lerp)(KO.factor1, pO.factor1, XO),
          eO = (0, oO.Lerp)(KO.factor2, pO.factor2, XO);
        OO.remapData.z = bK, OO.remapData.w = eO - bK
      }))
    }

    function dK(OO, KO) {
      const pO = (0, oO.Clamp)(KO._actualFrame / KO.targetStopDuration);
      XO.k.GetCurrentGradient(pO, KO._lifeTimeGradients, ((KO, XO) => {
        const bK = KO,
          eO = XO,
          lO = bK.getFactor(),
          vK = eO.getFactor(),
          CO = (pO - bK.gradient) / (eO.gradient - bK.gradient);
        OO.lifeTime = (0, oO.Lerp)(lO, vK, CO)
      })), KO._emitPower = (0, oO.RandomRange)(KO.minEmitPower, KO.maxEmitPower)
    }

    function TK(OO, KO) {
      OO.lifeTime = (0, oO.RandomRange)(KO.minLifeTime, KO.maxLifeTime), KO._emitPower = (0, oO.RandomRange)(KO.minEmitPower, KO.maxEmitPower)
    }

    function NK(OO, KO) {
      0 === KO._emitPower ? (OO._properties.initialDirection ? OO._properties.initialDirection.NhO(OO.direction) : OO._properties.initialDirection = OO.direction.clone(), OO.direction.set(0, 0, 0)) : (OO._properties.initialDirection = null, OO.direction.scaleInPlace(KO._emitPower)), OO.direction.addInPlace(KO._inheritedVelocityOffset)
    }

    function IK(OO, KO) {
      OO.angularSpeed = (0, oO.RandomRange)(KO.minAngularSpeed, KO.maxAngularSpeed), OO.angle = (0, oO.RandomRange)(KO.minInitialRotation, KO.maxInitialRotation)
    }

    function yp(OO, KO) {
      OO._properties.currentAngularSpeedGradient = KO._angularSpeedGradients[0], OO.angularSpeed = OO._properties.currentAngularSpeedGradient.getFactor(), OO._properties.currentAngularSpeed1 = OO.angularSpeed, KO._angularSpeedGradients.length > 1 ? OO._properties.currentAngularSpeed2 = KO._angularSpeedGradients[1].getFactor() : OO._properties.currentAngularSpeed2 = OO._properties.currentAngularSpeed1, OO.angle = (0, oO.RandomRange)(KO.minInitialRotation, KO.maxInitialRotation)
    }

    function gp(OO, KO) {
      OO._properties.initialStartSpriteCellId = KO.startSpriteCellID, OO._properties.initialEndSpriteCellId = KO.endSpriteCellID, OO._properties.initialSpriteCellLoop = KO.spriteCellLoop
    }

    function uK(OO, KO) {
      OO.previousItem = KO.previousItem, OO.nextItem = KO, KO.previousItem && (KO.previousItem.nextItem = OO), KO.previousItem = OO
    }

    function EK(OO, KO) {
      OO.previousItem = KO, OO.nextItem = KO.nextItem, KO.nextItem && (KO.nextItem.previousItem = OO), KO.nextItem = OO
    }

    function jp(OO) {
      OO.previousItem && (OO.previousItem.nextItem = OO.nextItem), OO.nextItem && (OO.nextItem.previousItem = OO.previousItem)
    }
    var YK = pO(38471);
    class wK extends TO {
      get startDirectionFunction() {
        return this._startDirectionFunction
      }
      set startDirectionFunction(OO) {
        this._startDirectionFunction !== OO && (this._startDirectionFunction = OO, this._directionCreation.process = OO ? OK : UO)
      }
      get startPositionFunction() {
        return this._startPositionFunction
      }
      set startPositionFunction(OO) {
        this._startPositionFunction !== OO && (this._startPositionFunction = OO, this._positionCreation.process = OO ? vp : lK)
      }
      set onDispose(OO) {
        this._onDisposeObserver && this.cpO.remove(this._onDisposeObserver), this._onDisposeObserver = this.cpO.add(OO)
      }
      get FhO() {
        return this._isDisposed
      }
      get useRampGradients() {
        return this._useRampGradients
      }
      set useRampGradients(OO) {
        this._useRampGradients !== OO && (this._useRampGradients = OO, this._resetEffect(), OO ? (this._rampCreation = {
          process: AK,
          previousItem: null,
          nextItem: null
        }, EK(this._rampCreation, this._colorDeadCreation), this._gravityProcessing && (this._remapGradientProcessing = {
          process: fK,
          previousItem: null,
          nextItem: null
        }, EK(this._remapGradientProcessing, this._gravityProcessing))) : (jp(this._rampCreation), jp(this._remapGradientProcessing)))
      }
      get isLocal() {
        return this._isLocal
      }
      set isLocal(OO) {
        this._isLocal !== OO && (this._isLocal = OO, OO ? (this._isLocalCreation = {
          process: CK,
          previousItem: null,
          nextItem: null
        }, EK(this._isLocalCreation, this._positionCreation)) : jp(this._isLocalCreation))
      }
      get particles() {
        return this._particles
      }
      get shaderLanguage() {
        return this._shaderLanguage
      }
      get _isAnimationSheetEnabled() {
        return this._animationSheetEnabled
      }
      set _isAnimationSheetEnabled(OO) {
        this._animationSheetEnabled !== OO && (this._animationSheetEnabled = OO, OO ? (this._sheetCreation = {
          process: gp,
          previousItem: null,
          nextItem: null
        }, EK(this._sheetCreation, this._colorDeadCreation)) : jp(this._sheetCreation), this._reset())
      }
      getActiveCount() {
        return this._particles.length
      }
      getClassName() {
        return "ParticleSystem"
      }
      isStopping() {
        return this._stopped && this.isAlive()
      }
      getCustomEffect() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return this._customWrappers[OO]?.effect ?? this._customWrappers[0].effect
      }
      _getCustomDrawWrapper() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return this._customWrappers[OO] ?? this._customWrappers[0]
      }
      setCustomEffect(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        this._customWrappers[KO] = new JO.c(this._engine), this._customWrappers[KO].effect = OO, this._customWrappers[KO].drawContext && (this._customWrappers[KO].drawContext.useInstancing = this._useInstancing)
      }
      get onBeforeDrawParticlesObservable() {
        return this._onBeforeDrawParticlesObservable || (this._onBeforeDrawParticlesObservable = new bK.e), this._onBeforeDrawParticlesObservable
      }
      get vertexShaderName() {
        return "particles"
      }
      get vertexBuffers() {
        return this._vertexBuffers
      }
      get indexBuffer() {
        return this._indexBuffer
      }
      get noiseTexture() {
        return this._noiseTexture
      }
      set noiseTexture(OO) {
        if (this.noiseTexture !== OO) {
          if (this._noiseTexture = OO, !OO) return jp(this._noiseCreation), void jp(this._noiseProcessing);
          this._noiseCreation = {
            process: ap,
            previousItem: null,
            nextItem: null
          }, EK(this._noiseCreation, this._colorDeadCreation), this._noiseProcessing = {
            process: oK,
            previousItem: null,
            nextItem: null
          }, EK(this._noiseProcessing, this._positionProcessing)
        }
      }
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
          lO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
          vK = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : .01,
          hO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
        RO || (RO = !0, wO(HO.e, sO)), (0, SO.c)(), super(OO), this._emitterInverseWorldMatrix = eO.c.Identity(), this._startDirectionFunction = null, this._startPositionFunction = null, this._inheritedVelocityOffset = new eO.o, this.cpO = new bK.e, this.onStoppedObservable = new bK.e, this.onStartedObservable = new bK.e, this._noiseTextureSize = null, this._noiseTextureData = null, this._particles = new Array, this._stockParticles = new Array, this._newPartsExcess = 0, this._vertexBuffers = {}, this._renderPassObserver = null, this._scaledColorStep = new DO.g(0, 0, 0, 0), this._colorDiff = new DO.g(0, 0, 0, 0), this._scaledGravity = eO.o.Zero(), this._currentRenderId = -1, this._useInstancing = !1, this._useFixedCapacityForSnapshot = !1, this._fixedCapacityHighWaterMark = 0, this._isDisposed = !1, this._started = !1, this._stopped = !1, this._actualFrame = 0, this._currentEmitRate1 = 0, this._currentEmitRate2 = 0, this._currentStartSize1 = 0, this._currentStartSize2 = 0, this.updateInAnimate = !0, this._rawTextureWidth = 256, this._useRampGradients = !1, this._updateQueueStart = null, this._startSizeCreation = null, this._createQueueStart = null, this._isLocal = !1, this.isGPU = !1, this._shaderLanguage = 0, this._onBeforeDrawParticlesObservable = null, this._emitFromParticle = OO => {}, this.recycleParticle = OO => {
          const KO = this._particles.pop();
          KO !== OO && KO.copyTo(OO), KO.metadata = null, this._stockParticles.push(KO)
        }, this._createParticle = () => {
          let OO;
          return 0 !== this._stockParticles.length ? (OO = this._stockParticles.pop(), OO._reset()) : OO = new IO(this), this._prepareParticle(OO), OO
        }, this.paused = !1, this._shadersLoaded = !1, this._capacity = KO, this._epsilon = vK, pO && "Scene" !== pO.getClassName() ? (this._engine = pO, this.defaultProjectionMatrix = eO.c.PerspectiveFovLH(.8, 1, .1, 100, this._engine.isNDCHalfZRange)) : (this._scene = pO || CO.c.LastCreatedScene, this._engine = this._scene.qb(), this.uniqueId = this._scene.getUniqueId(), this.layerMask = this._scene.defaultRenderableLayerMask, this._scene.ku.push(this)), this._engine.getCaps().vertexArrayObject && (this._vertexArrayObject = null), this._initShaderSourceAsync(), this._lifeTimeCreation = {
          process: TK,
          previousItem: null,
          nextItem: null
        }, this._positionCreation = {
          process: lK,
          previousItem: null,
          nextItem: null
        }, EK(this._positionCreation, this._lifeTimeCreation), this._directionCreation = {
          process: UO,
          previousItem: null,
          nextItem: null
        }, EK(this._directionCreation, this._positionCreation), this._emitPowerCreation = {
          process: NK,
          previousItem: null,
          nextItem: null
        }, EK(this._emitPowerCreation, this._directionCreation), this._sizeCreation = {
          process: VK,
          previousItem: null,
          nextItem: null
        }, EK(this._sizeCreation, this._emitPowerCreation), this._angleCreation = {
          process: IK,
          previousItem: null,
          nextItem: null
        }, EK(this._angleCreation, this._sizeCreation), this._colorCreation = {
          process: GO,
          previousItem: null,
          nextItem: null
        }, EK(this._colorCreation, this._angleCreation), this._colorDeadCreation = {
          process: qK,
          previousItem: null,
          nextItem: null
        }, EK(this._colorDeadCreation, this._colorCreation), this._createQueueStart = this._lifeTimeCreation, hO || (this._colorProcessing = {
          process: WO,
          previousItem: null,
          nextItem: null
        }, this._angularSpeedProcessing = {
          process: kK,
          previousItem: null,
          nextItem: null
        }, EK(this._angularSpeedProcessing, this._colorProcessing), this._directionProcessing = {
          process: eK,
          previousItem: null,
          nextItem: null
        }, EK(this._directionProcessing, this._angularSpeedProcessing), this._positionProcessing = {
          process: hK,
          previousItem: null,
          nextItem: null
        }, EK(this._positionProcessing, this._directionProcessing), this._gravityProcessing = {
          process: FK,
          previousItem: null,
          nextItem: null
        }, EK(this._gravityProcessing, this._positionProcessing), this._updateQueueStart = this._colorProcessing), this._isAnimationSheetEnabled = lO, this._attachImageProcessingConfiguration(null), this._customWrappers = {
          0: new JO.c(this._engine)
        }, this._customWrappers[0].effect = XO, this._drawWrappers = [], this._useInstancing = this._engine.getCaps().instancedArrays, this._createIndexBuffer(), this._createVertexBuffers(), this.particleEmitterType = new MO.b, this.updateFunction = OO => {
          this.noiseTexture && (this._noiseTextureSize = this.noiseTexture.getSize(), this.noiseTexture.getContent()?.then((OO => {
            this._noiseTextureData = OO
          })));
          const KO = OO === this._particles;
          for (let pO = 0; pO < OO.length; pO++) {
            const XO = OO[pO];
            this._tempScaledUpdateSpeed = this._scaledUpdateSpeed;
            const bK = XO.age;
            if (XO.age += this._tempScaledUpdateSpeed, XO.age > XO.lifeTime) {
              const OO = XO.age - bK,
                KO = XO.lifeTime - bK;
              this._tempScaledUpdateSpeed = KO * this._tempScaledUpdateSpeed / OO, XO.age = XO.lifeTime
            }
            this._ratio = XO.age / XO.lifeTime, XO._properties.directionScale = this._tempScaledUpdateSpeed;
            let eO = this._updateQueueStart;
            for (; eO;) eO.process(XO, this), eO = eO.nextItem;
            if (this._isAnimationSheetEnabled && !hO && XO.updateCellIndex(), XO._inheritParticleInfoToSubEmitters(), XO.age >= XO.lifeTime) {
              if (this._emitFromParticle(XO), XO._properties.attachedSubEmitters) {
                for (const OO of XO._properties.attachedSubEmitters) OO.particleSystem.disposeOnStop = !0, OO.particleSystem.stop();
                XO._properties.attachedSubEmitters = null
              }
              this.recycleParticle(XO), KO && pO--
            } else;
          }
        }
      }
      serialize(OO) {
        throw new Error("Method not implemented.")
      }
      clone(OO, KO) {
        throw new Error("Method not implemented.")
      }
      _syncLifeTimeCreation() {
        this.targetStopDuration && this._lifeTimeGradients && this._lifeTimeGradients.length > 0 ? this._lifeTimeCreation.process = dK : this._lifeTimeCreation.process = TK
      }
      _syncStartSizeCreation() {
        this._startSizeGradients && this._startSizeGradients[0] && this.targetStopDuration ? this._startSizeCreation || (this._startSizeCreation = {
          process: QK,
          previousItem: null,
          nextItem: null
        }, EK(this._startSizeCreation, this._sizeCreation)) : this._startSizeCreation && (jp(this._startSizeCreation), this._startSizeCreation = null)
      }
      get targetStopDuration() {
        return this._targetStopDuration
      }
      set targetStopDuration(OO) {
        this.targetStopDuration !== OO && (this._targetStopDuration = OO, this._syncLifeTimeCreation(), this._syncStartSizeCreation())
      }
      addLifeTimeGradient(OO, KO, pO) {
        return this._lifeTimeGradients || (this._lifeTimeGradients = []), this._addFactorGradient(this._lifeTimeGradients, OO, KO, pO), this._syncLifeTimeCreation(), this
      }
      removeLifeTimeGradient(OO) {
        return this._removeFactorGradient(this._lifeTimeGradients, OO), this._syncLifeTimeCreation(), this
      }
      addSizeGradient(OO, KO, pO) {
        return this._sizeGradients || (this._sizeGradients = []), 0 === this._sizeGradients.length && (this._sizeCreation.process = LK, this._sizeGradientProcessing = {
          process: zp,
          previousItem: null,
          nextItem: null
        }, uK(this._sizeGradientProcessing, this._gravityProcessing)), this._addFactorGradient(this._sizeGradients, OO, KO, pO), this
      }
      removeSizeGradient(OO) {
        return this._removeFactorGradient(this._sizeGradients, OO), 0 === this._sizeGradients?.length && (jp(this._sizeGradientProcessing), this._sizeCreation.process = VK), this
      }
      addColorRemapGradient(OO, KO, pO) {
        return this._colorRemapGradients || (this._colorRemapGradients = []), this._addFactorGradient(this._colorRemapGradients, OO, KO, pO), this
      }
      removeColorRemapGradient(OO) {
        return this._removeFactorGradient(this._colorRemapGradients, OO), this
      }
      addAlphaRemapGradient(OO, KO, pO) {
        return this._alphaRemapGradients || (this._alphaRemapGradients = []), this._addFactorGradient(this._alphaRemapGradients, OO, KO, pO), this
      }
      removeAlphaRemapGradient(OO) {
        return this._removeFactorGradient(this._alphaRemapGradients, OO), this
      }
      addAngularSpeedGradient(OO, KO, pO) {
        return this._angularSpeedGradients || (this._angularSpeedGradients = []), 0 === this._angularSpeedGradients.length && (this._angleCreation.process = yp, this._angularSpeedGradientProcessing = {
          process: tK,
          previousItem: null,
          nextItem: null
        }, uK(this._angularSpeedGradientProcessing, this._angularSpeedProcessing)), this._addFactorGradient(this._angularSpeedGradients, OO, KO, pO), this
      }
      removeAngularSpeedGradient(OO) {
        return this._removeFactorGradient(this._angularSpeedGradients, OO), 0 === this._angularSpeedGradients?.length && (this._angleCreation.process = IK, jp(this._angularSpeedGradientProcessing)), this
      }
      addVelocityGradient(OO, KO, pO) {
        return this._velocityGradients || (this._velocityGradients = []), 0 === this._velocityGradients.length && (this._velocityCreation = {
          process: KK,
          previousItem: null,
          nextItem: null
        }, EK(this._velocityCreation, this._angleCreation), this._velocityGradientProcessing = {
          process: XK,
          previousItem: null,
          nextItem: null
        }, uK(this._velocityGradientProcessing, this._directionProcessing)), this._addFactorGradient(this._velocityGradients, OO, KO, pO), this
      }
      removeVelocityGradient(OO) {
        return this._removeFactorGradient(this._velocityGradients, OO), 0 === this._velocityGradients?.length && (jp(this._velocityCreation), jp(this._velocityGradientProcessing)), this
      }
      addLimitVelocityGradient(OO, KO, pO) {
        return this._limitVelocityGradients || (this._limitVelocityGradients = []), 0 === this._limitVelocityGradients.length && (this._limitVelocityCreation = {
          process: pK,
          previousItem: null,
          nextItem: null
        }, EK(this._limitVelocityCreation, this._angleCreation), this._limitVelocityGradientProcessing = {
          process: bp,
          previousItem: null,
          nextItem: null
        }, EK(this._limitVelocityGradientProcessing, this._directionProcessing)), this._addFactorGradient(this._limitVelocityGradients, OO, KO, pO), this
      }
      removeLimitVelocityGradient(OO) {
        return this._removeFactorGradient(this._limitVelocityGradients, OO), 0 === this._limitVelocityGradients?.length && (jp(this._limitVelocityCreation), jp(this._limitVelocityGradientProcessing)), this
      }
      addDragGradient(OO, KO, pO) {
        return this._dragGradients || (this._dragGradients = []), 0 === this._dragGradients.length && (this._dragCreation = {
          process: DK,
          previousItem: null,
          nextItem: null
        }, uK(this._dragCreation, this._colorDeadCreation), this._dragGradientProcessing = {
          process: MK,
          previousItem: null,
          nextItem: null
        }, uK(this._dragGradientProcessing, this._positionProcessing)), this._addFactorGradient(this._dragGradients, OO, KO, pO), this
      }
      removeDragGradient(OO) {
        return this._removeFactorGradient(this._dragGradients, OO), 0 === this._dragGradients?.length && (jp(this._dragCreation), jp(this._dragGradientProcessing)), this
      }
      addStartSizeGradient(OO, KO, pO) {
        return this._startSizeGradients || (this._startSizeGradients = []), this._addFactorGradient(this._startSizeGradients, OO, KO, pO), this._syncStartSizeCreation(), this
      }
      removeStartSizeGradient(OO) {
        return this._removeFactorGradient(this._startSizeGradients, OO), this._syncStartSizeCreation(), this
      }
      _createRampGradientTexture() {
        if (!this._rampGradients || !this._rampGradients.length || this._rampGradientsTexture || !this._scene) return;
        const OO = new Uint8Array(4 * this._rawTextureWidth),
          KO = DO.j.Color3[0];
        for (let pO = 0; pO < this._rawTextureWidth; pO++) {
          const bK = pO / this._rawTextureWidth;
          XO.k.GetCurrentGradient(bK, this._rampGradients, ((XO, bK, eO) => {
            DO.e.LerpToRef(XO.color, bK.color, eO, KO), OO[4 * pO] = 255 * KO.r, OO[4 * pO + 1] = 255 * KO.g, OO[4 * pO + 2] = 255 * KO.b, OO[4 * pO + 3] = 255
          }))
        }
        this._rampGradientsTexture = vK.e.CreateRGBATexture(OO, this._rawTextureWidth, 1, this._scene, !1, !1, 1)
      }
      getRampGradients() {
        return this._rampGradients
      }
      forceRefreshGradients() {
        this._syncRampGradientTexture()
      }
      _syncRampGradientTexture() {
        this._rampGradients && (this._rampGradients.sort(((OO, KO) => OO.gradient < KO.gradient ? -1 : OO.gradient > KO.gradient ? 1 : 0)), this._rampGradientsTexture && (this._rampGradientsTexture.dispose(), this._rampGradientsTexture = null), this._createRampGradientTexture())
      }
      addRampGradient(OO, KO) {
        this._rampGradients || (this._rampGradients = []);
        const pO = new XO.h(OO, KO);
        return this._rampGradients.push(pO), this._syncRampGradientTexture(), this
      }
      removeRampGradient(OO) {
        return this._removeGradientAndTexture(OO, this._rampGradients, this._rampGradientsTexture), this._rampGradientsTexture = null, this._rampGradients && this._rampGradients.length > 0 && this._createRampGradientTexture(), this
      }
      addColorGradient(OO, KO, pO) {
        this._colorGradients || (this._colorGradients = []), 0 === this._colorGradients.length && (this._colorCreation.process = xK, this._colorProcessing.process = nO);
        const bK = new XO.d(OO, KO, pO);
        return this._colorGradients.push(bK), this._colorGradients.sort(((OO, KO) => OO.gradient < KO.gradient ? -1 : OO.gradient > KO.gradient ? 1 : 0)), this
      }
      removeColorGradient(OO) {
        if (!this._colorGradients) return this;
        let KO = 0;
        for (const pO of this._colorGradients) {
          if (pO.gradient === OO) {
            this._colorGradients.splice(KO, 1);
            break
          }
          KO++
        }
        return 0 === this._colorGradients.length && (this._colorCreation.process = GO, this._colorProcessing.process = WO), this
      }
      resetDrawCache() {
        if (this._drawWrappers) {
          for (const OO of this._drawWrappers)
            if (OO)
              for (const KO of OO) KO?.dispose();
          this._drawWrappers = []
        }
      }
      _fetchR(OO, KO, pO, XO, bK) {
        return bK[4 * (((OO = .5 * Math.abs(OO) + .5) * pO % pO | 0) + ((KO = .5 * Math.abs(KO) + .5) * XO % XO | 0) * pO)] / 255
      }
      _reset() {
        this._resetEffect()
      }
      _resetEffect() {
        this._vertexBuffer && (this._vertexBuffer.dispose(), this._vertexBuffer = null), this._spriteBuffer && (this._spriteBuffer.dispose(), this._spriteBuffer = null), this._vertexArrayObject && (this._engine.releaseVertexArrayObject(this._vertexArrayObject), this._vertexArrayObject = null), this._createVertexBuffers()
      }
      _createVertexBuffers() {
        this._vertexBufferSize = this._useInstancing ? 10 : 12, this._isAnimationSheetEnabled && (this._vertexBufferSize += 1), this._isBillboardBased && 8 !== this.billboardMode && 9 !== this.billboardMode || (this._vertexBufferSize += 3), this._useRampGradients && (this._vertexBufferSize += 4);
        const OO = this._engine,
          KO = this._vertexBufferSize * (this._useInstancing ? 1 : 4);
        this._vertexData = new Float32Array(this._capacity * KO), this._vertexBuffer = new lO.b(OO, this._vertexData, !0, KO);
        let pO = 0;
        const XO = this._vertexBuffer.createVertexBuffer(lO.j.PositionKind, pO, 3, this._vertexBufferSize, this._useInstancing);
        this._vertexBuffers[lO.j.PositionKind] = XO, pO += 3;
        const bK = this._vertexBuffer.createVertexBuffer(lO.j.ColorKind, pO, 4, this._vertexBufferSize, this._useInstancing);
        this._vertexBuffers[lO.j.ColorKind] = bK, pO += 4;
        const eO = this._vertexBuffer.createVertexBuffer("angle", pO, 1, this._vertexBufferSize, this._useInstancing);
        this._vertexBuffers.angle = eO, pO += 1;
        const vK = this._vertexBuffer.createVertexBuffer("size", pO, 2, this._vertexBufferSize, this._useInstancing);
        if (this._vertexBuffers.size = vK, pO += 2, this._isAnimationSheetEnabled) {
          const OO = this._vertexBuffer.createVertexBuffer("cellIndex", pO, 1, this._vertexBufferSize, this._useInstancing);
          this._vertexBuffers.cellIndex = OO, pO += 1
        }
        if (!this._isBillboardBased || 8 === this.billboardMode || 9 === this.billboardMode) {
          const OO = this._vertexBuffer.createVertexBuffer("direction", pO, 3, this._vertexBufferSize, this._useInstancing);
          this._vertexBuffers.direction = OO, pO += 3
        }
        if (this._useRampGradients) {
          const OO = this._vertexBuffer.createVertexBuffer("remapData", pO, 4, this._vertexBufferSize, this._useInstancing);
          this._vertexBuffers.remapData = OO, pO += 4
        }
        let CO;
        if (this._useInstancing) {
          const KO = new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]);
          this._spriteBuffer = new lO.b(OO, KO, !1, 2), CO = this._spriteBuffer.createVertexBuffer("offset", 0, 2)
        } else CO = this._vertexBuffer.createVertexBuffer("offset", pO, 2, this._vertexBufferSize, this._useInstancing);
        this._vertexBuffers.offset = CO, this.resetDrawCache()
      }
      _createIndexBuffer() {
        if (this._useInstancing) return void(this._linesIndexBufferUseInstancing = this._engine.createIndexBuffer(new Uint32Array([0, 1, 1, 3, 3, 2, 2, 0, 0, 3])));
        const OO = [],
          KO = [];
        let pO = 0;
        for (let XO = 0; XO < this._capacity; XO++) OO.push(pO), OO.push(pO + 1), OO.push(pO + 2), OO.push(pO), OO.push(pO + 2), OO.push(pO + 3), KO.push(pO, pO + 1, pO + 1, pO + 2, pO + 2, pO + 3, pO + 3, pO, pO, pO + 3), pO += 4;
        this._indexBuffer = this._engine.createIndexBuffer(OO), this._linesIndexBuffer = this._engine.createIndexBuffer(KO)
      }
      getCapacity() {
        return this._capacity
      }
      isAlive() {
        return this._alive
      }
      isStarted() {
        return this._started
      }
      _preStart() {}
      start() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.startDelay;
        if (!this.targetStopDuration && this._hasTargetStopDurationDependantGradient()) throw "Particle system started with a targetStopDuration dependant gradient (eg. startSizeGradients) but no targetStopDuration set";
        if (OO) return this.startDelay = OO, void setTimeout((() => {
          this.start(0)
        }), OO);
        if (this._started = !0, this._stopped = !1, this._actualFrame = 0, this._preStart(), this._emitRateGradients && (this._emitRateGradients.length > 0 && (this._currentEmitRateGradient = this._emitRateGradients[0], this._currentEmitRate1 = this._currentEmitRateGradient.getFactor(), this._currentEmitRate2 = this._currentEmitRate1), this._emitRateGradients.length > 1 && (this._currentEmitRate2 = this._emitRateGradients[1].getFactor())), this._startSizeGradients && (this._startSizeGradients.length > 0 && (this._currentStartSizeGradient = this._startSizeGradients[0], this._currentStartSize1 = this._currentStartSizeGradient.getFactor(), this._currentStartSize2 = this._currentStartSize1), this._startSizeGradients.length > 1 && (this._currentStartSize2 = this._startSizeGradients[1].getFactor())), this.preWarmCycles) {
          -1 !== this.emitter?.getClassName().indexOf("Mesh") && this.emitter.computeWorldMatrix(!0), this._scene?.updateTransformMatrix();
          const OO = this.noiseTexture;
          if (OO && OO.onGeneratedObservable) OO.onGeneratedObservable.addOnce((() => {
            setTimeout((() => {
              for (let KO = 0; KO < this.preWarmCycles; KO++) this.animate(!0), OO.render()
            }))
          }));
          else
            for (let KO = 0; KO < this.preWarmCycles; KO++) this.animate(!0)
        }
        this.beginAnimationOnStart && this.animations && this.animations.length > 0 && this._scene && this._scene.beginAnimation(this, this.beginAnimationFrom, this.beginAnimationTo, this.beginAnimationLoop), this.onStartedObservable.notifyObservers(this)
      }
      stop() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        this._stopped || (this.onStoppedObservable.notifyObservers(this), this._stopped = !0, this._postStop(OO))
      }
      _postStop(OO) {}
      reset() {
        this._stockParticles.length = 0, this._particles.length = 0
      }
      _appendParticleVertex(OO, KO, pO, XO) {
        let bK = OO * this._vertexBufferSize;
        const lO = eO.j.WX[0].NhO(this._scene?.floatingOriginOffset || eO.o.ZeroReadOnly);
        if (this._vertexData[bK++] = KO.position.x + this.worldOffset.x - lO.x, this._vertexData[bK++] = KO.position.y + this.worldOffset.y - lO.y, this._vertexData[bK++] = KO.position.z + this.worldOffset.z - lO.z, this._vertexData[bK++] = KO.color.r, this._vertexData[bK++] = KO.color.g, this._vertexData[bK++] = KO.color.b, this._vertexData[bK++] = KO.color.a, this._vertexData[bK++] = KO.angle, this._vertexData[bK++] = KO.scale.x * KO.size, this._vertexData[bK++] = KO.scale.y * KO.size, this._isAnimationSheetEnabled && (this._vertexData[bK++] = KO.cellIndex), this._isBillboardBased) 8 !== this.billboardMode && 9 !== this.billboardMode || (this._vertexData[bK++] = KO.direction.x, this._vertexData[bK++] = KO.direction.y, this._vertexData[bK++] = KO.direction.z);
        else if (KO._properties.initialDirection) {
          let OO = KO._properties.initialDirection;
          this.isLocal && (eO.o.TransformNormalToRef(OO, this._emitterWorldMatrix, eO.j.WX[0]), OO = eO.j.WX[0]), 0 === OO.x && 0 === OO.z && (OO.x = .001), this._vertexData[bK++] = OO.x, this._vertexData[bK++] = OO.y, this._vertexData[bK++] = OO.z
        } else {
          let OO = KO.direction;
          this.isLocal && (eO.o.TransformNormalToRef(OO, this._emitterWorldMatrix, eO.j.WX[0]), OO = eO.j.WX[0]), 0 === OO.x && 0 === OO.z && (OO.x = .001), this._vertexData[bK++] = OO.x, this._vertexData[bK++] = OO.y, this._vertexData[bK++] = OO.z
        }
        this._useRampGradients && KO.remapData && (this._vertexData[bK++] = KO.remapData.x, this._vertexData[bK++] = KO.remapData.y, this._vertexData[bK++] = KO.remapData.z, this._vertexData[bK++] = KO.remapData.w), this._useInstancing || (this._isAnimationSheetEnabled && (0 === pO ? pO = this._epsilon : 1 === pO && (pO = 1 - this._epsilon), 0 === XO ? XO = this._epsilon : 1 === XO && (XO = 1 - this._epsilon)), this._vertexData[bK++] = pO, this._vertexData[bK] = XO)
      }
      _prepareParticle(OO) {}
      _createNewOnes(OO) {
        let KO;
        for (let pO = 0; pO < OO && this._particles.length !== this._capacity; pO++) {
          KO = this._createParticle(), this._particles.push(KO);
          let OO = this._createQueueStart;
          for (; OO;) OO.process(KO, this), OO = OO.nextItem;
          KO._inheritParticleInfoToSubEmitters()
        }
      }
      _update(OO) {
        if (this._alive = this._particles.length > 0, this.emitter.position) {
          const OO = this.emitter;
          this._emitterWorldMatrix = OO.getWorldMatrix()
        } else {
          const OO = this.emitter;
          this._emitterWorldMatrix = eO.c.Translation(OO.x, OO.y, OO.z)
        }
        this._emitterWorldMatrix.invertToRef(this._emitterInverseWorldMatrix), this.updateFunction(this._particles), this._createNewOnes(OO)
      }
      static _GetAttributeNamesOrOptions() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = [lO.j.PositionKind, lO.j.ColorKind, "angle", "offset", "size"];
        return OO && XO.push("cellIndex"), KO || XO.push("direction"), pO && XO.push("remapData"), XO
      }
      static _GetEffectCreationOptions() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = ["invView", "view", "projection", "textureMask", "translationPivot", "eyePosition"];
        return (0, cK.c)(XO), OO && XO.push("particlesInfos"), KO && XO.push("logarithmicDepthConstant"), pO && (XO.push("vFogInfos"), XO.push("vFogColor")), XO
      }
      fillDefines(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        if (this._scene && ((0, cK.l)(this, this._scene, OO), this.applyFog && this._scene.fogEnabled && 0 !== this._scene.fogMode && OO.push("#define FOG")), this._isAnimationSheetEnabled && OO.push("#define ANIMATESHEET"), this.useLogarithmicDepth && OO.push("#define LOGARITHMICDEPTH"), KO === TO.BLENDMODE_MULTIPLY && OO.push("#define BLENDMULTIPLYMODE"), this.isLocal && OO.push("#define LOCAL"), this._useRampGradients && OO.push("#define RAMPGRADIENT"), this._isBillboardBased) switch (OO.push("#define BILLBOARD"), this.billboardMode) {
          case 2:
            OO.push("#define BILLBOARDY");
            break;
          case 8:
          case 9:
            OO.push("#define BILLBOARDSTRETCHED"), 9 === this.billboardMode && OO.push("#define BILLBOARDSTRETCHED_LOCAL");
            break;
          case 7:
            OO.push("#define BILLBOARDMODE_ALL")
        }
        pO && this._imageProcessingConfiguration && (this._imageProcessingConfiguration.prepareDefines(this._imageProcessingConfigurationDefines), OO.push(this._imageProcessingConfigurationDefines.toString()))
      }
      fillUniformsAttributesAndSamplerNames(OO, KO, pO) {
        KO.push(...wK._GetAttributeNamesOrOptions(this._isAnimationSheetEnabled, this._isBillboardBased && 8 !== this.billboardMode && 9 !== this.billboardMode, this._useRampGradients)), OO.push(...wK._GetEffectCreationOptions(this._isAnimationSheetEnabled, this.useLogarithmicDepth, this.applyFog)), pO.push("diffuseSampler", "rampSampler"), this._imageProcessingConfiguration && ((0, ZO.g)(OO, this._imageProcessingConfigurationDefines), (0, ZO.d)(pO, this._imageProcessingConfigurationDefines))
      }
      _getWrapper(OO) {
        var KO;
        const pO = this._getCustomDrawWrapper(OO);
        if (pO?.effect) return pO;
        const XO = [];
        this.fillDefines(XO, OO);
        const eO = this._engine._features.supportRenderPasses ? this._engine.currentRenderPassId : 0,
          lO = YK.d._PrepareStringDefines(eO, XO),
          vK = lO ? YK.d.GetConfiguration(eO) : void 0;
        let CO = this._drawWrappers[eO];
        CO || (CO = this._drawWrappers[eO] = [], 0 === eO || this._renderPassObserver || (this._renderPassObserver = ((KO = this._engine)._onReleaseRenderPassObservable ?? (KO._onReleaseRenderPassObservable = new bK.e)).add((OO => {
          const KO = this._drawWrappers[OO];
          if (KO) {
            for (const OO of KO) OO?.dispose();
            delete this._drawWrappers[OO]
          }
        }))));
        let hO = CO[OO];
        hO || (hO = new JO.c(this._engine), hO.drawContext && (hO.drawContext.useInstancing = this._useInstancing), CO[OO] = hO);
        const DO = XO.join("\n");
        if (hO.defines !== DO) {
          const OO = [],
            KO = [],
            pO = [];
          this.fillUniformsAttributesAndSamplerNames(KO, OO, pO), lO && (KO.push("cameraInfo", "objectId", "meshBlendTag", "geometryZeroAlphaDiscard"), this.isLocal && void 0 !== vK?.defines.PREPASS_LOCAL_POSITION_INDEX && KO.push("inverseEmitterWM", "geometryWorldOffset")), hO.setEffect(this._engine.createEffect("particles", {
            attributes: OO,
            uniformsNames: KO,
            samplers: pO,
            defines: DO,
            shaderLanguage: this._shaderLanguage,
            multiTarget: lO,
            indexParameters: lO ? {
              buffersCount: vK?._mrtCount ?? 0
            } : void 0
          }, this._engine), DO)
        }
        return hO
      }
      _bindGeometryRendering(OO) {
        const KO = this._engine._features.supportRenderPasses ? this._engine.currentRenderPassId : 0,
          pO = YK.d.GetConfiguration(KO);
        if (!pO?._defines) return;
        OO.setFloat("objectId", 0), OO.setInt("meshBlendTag", 0);
        const XO = this._scene?.activeCamera;
        if (OO.setFloat2("cameraInfo", XO?.minZ ?? 0, XO?.maxZ ?? 1), this.isLocal && void 0 !== pO.defines.PREPASS_LOCAL_POSITION_INDEX) {
          OO.setMatrix("inverseEmitterWM", this._emitterInverseWorldMatrix);
          const KO = this.worldOffset.subtractToRef(this._scene?.floatingOriginOffset || eO.o.ZeroReadOnly, eO.j.WX[0]);
          OO.setVector3("geometryWorldOffset", KO)
        }
      }
      animate() {
        let OO, KO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        if (this._started && !this.paused) {
          if (!KO && this._scene) {
            if (!this.isReady()) return;
            if (this._currentRenderId === this._scene.getFrameId()) return;
            this._currentRenderId = this._scene.getFrameId()
          }
          if (this._scaledUpdateSpeed = this.updateSpeed * (KO ? this.preWarmStepOffset : this._scene?.getAnimationRatio() || 1), this.manualEmitCount > -1) OO = this.manualEmitCount, this._newPartsExcess = 0, this.manualEmitCount = 0;
          else {
            const KO = this._calculateEmitRate();
            OO = KO * this._scaledUpdateSpeed | 0, this._newPartsExcess += KO * this._scaledUpdateSpeed - OO
          }
          if (this._newPartsExcess > 1 && (OO += this._newPartsExcess | 0, this._newPartsExcess -= this._newPartsExcess | 0), this._alive = !1, this._stopped ? OO = 0 : (this._actualFrame += this._scaledUpdateSpeed, this.targetStopDuration && this._actualFrame >= this.targetStopDuration && this.stop()), this._update(OO), this._stopped && (this._alive || (this._started = !1, this.onAnimationEnd && this.onAnimationEnd(), this.disposeOnStop && this._scene && this._scene._toBeDisposed.push(this))), !KO) {
            let OO = 0;
            for (let KO = 0; KO < this._particles.length; KO++) {
              const pO = this._particles[KO];
              this._appendParticleVertices(OO, pO), OO += this._useInstancing ? 1 : 4
            }
            if (this._vertexBuffer)
              if (this._useFixedCapacityForSnapshot) {
                const OO = this._vertexBufferSize * (this._useInstancing ? 1 : 4),
                  KO = this._particles.length;
                KO < this._fixedCapacityHighWaterMark && this._vertexData.fill(0, KO * OO, this._fixedCapacityHighWaterMark * OO), this._fixedCapacityHighWaterMark = KO, this._vertexBuffer.updateDirectly(this._vertexData, 0, this._capacity)
              } else this._vertexBuffer.updateDirectly(this._vertexData, 0, this._particles.length)
          }
          0 === this.manualEmitCount && this.disposeOnStop && this.stop()
        }
      }
      _initFixedCapacitySnapshotData() {
        return !this._useFixedCapacityForSnapshot && (this._useFixedCapacityForSnapshot = !0, this._vertexData.fill(0), this._fixedCapacityHighWaterMark = 0, this._vertexBuffer?.updateDirectly(this._vertexData, 0, this._capacity), !0)
      }
      _clearFixedCapacitySnapshotData() {
        if (!this._useFixedCapacityForSnapshot || !this._vertexBuffer || 0 === this._fixedCapacityHighWaterMark) return;
        const OO = this._vertexBufferSize * (this._useInstancing ? 1 : 4);
        this._vertexData.fill(0, 0, this._fixedCapacityHighWaterMark * OO), this._fixedCapacityHighWaterMark = 0, this._vertexBuffer.updateDirectly(this._vertexData, 0, this._capacity)
      }
      _calculateEmitRate() {
        let OO = this.emitRate;
        if (this._emitRateGradients && this._emitRateGradients.length > 0 && this.targetStopDuration) {
          const KO = this._actualFrame / this.targetStopDuration;
          XO.k.GetCurrentGradient(KO, this._emitRateGradients, ((KO, pO, XO) => {
            KO !== this._currentEmitRateGradient && (this._currentEmitRate1 = this._currentEmitRate2, this._currentEmitRate2 = pO.getFactor(), this._currentEmitRateGradient = KO), OO = (0, oO.Lerp)(this._currentEmitRate1, this._currentEmitRate2, XO)
          }))
        }
        return OO
      }
      _appendParticleVertices(OO, KO) {
        this._appendParticleVertex(OO++, KO, 0, 0), this._useInstancing || (this._appendParticleVertex(OO++, KO, 1, 0), this._appendParticleVertex(OO++, KO, 1, 1), this._appendParticleVertex(OO, KO, 0, 1))
      }
      rebuild() {
        this._engine.getCaps().vertexArrayObject && (this._vertexArrayObject = null), this._createIndexBuffer(), this._spriteBuffer?._rebuild(), this._createVertexBuffers(), this.resetDrawCache()
      }
      async _initShaderSourceAsync() {
        this._engine.isWebGPU && !wK.ForceGLSL ? (this._shaderLanguage = 1, await Promise.all([pO.e(326).then((() => pO(59093))), pO.e(320).then((() => pO(59095)))])) : await Promise.all([pO.e(309).then((() => pO(59102))), Promise.all([pO.e(302), pO.e(336)]).then((() => pO(59111)))]), this._shadersLoaded = !0
      }
      isReady() {
        if (!this._shadersLoaded) return !1;
        if (!this.emitter || this._imageProcessingConfiguration && !this._imageProcessingConfiguration.isReady() || !this.particleTexture || !this.particleTexture.isReady()) return !1;
        if (this.blendMode !== TO.BLENDMODE_MULTIPLYADD) {
          if (!this._getWrapper(this.blendMode).effect.isReady()) return !1
        } else {
          if (!this._getWrapper(TO.BLENDMODE_MULTIPLY).effect.isReady()) return !1;
          if (!this._getWrapper(TO.BLENDMODE_ADD).effect.isReady()) return !1
        }
        return !0
      }
      _render(OO) {
        const KO = this._getWrapper(OO),
          pO = KO.effect,
          XO = this._engine;
        XO.enableEffect(KO);
        const bK = this.defaultViewMatrix ?? this._scene.getViewMatrix();
        pO.setTexture("diffuseSampler", this.particleTexture), pO.setMatrix("view", bK);
        const lO = this.defaultProjectionMatrix ?? this._scene.getProjectionMatrix();
        if (pO.setMatrix("projection", lO), this._isAnimationSheetEnabled && this.particleTexture) {
          const OO = this.particleTexture.getBaseSize();
          pO.setFloat3("particlesInfos", this.spriteCellWidth / OO.width, this.spriteCellHeight / OO.height, this.spriteCellWidth / OO.width)
        }
        if (pO.setVector2("translationPivot", this.translationPivot), pO.setFloat4("textureMask", this.textureMask.r, this.textureMask.g, this.textureMask.b, this.textureMask.a), this._isBillboardBased && this._scene) {
          const OO = this._scene.activeCamera;
          pO.setVector3("eyePosition", OO.globalPosition)
        }
        this._rampGradientsTexture && (this._rampGradients && this._rampGradients.length || (this._rampGradientsTexture.dispose(), this._rampGradientsTexture = null), pO.setTexture("rampSampler", this._rampGradientsTexture));
        const vK = pO.defines;
        this._scene && ((0, cK.e)(pO, this, this._scene), this.applyFog && (0, BO.i)(this._scene, void 0, pO)), vK.indexOf("#define BILLBOARDMODE_ALL") >= 0 && (bK.invertToRef(eO.j.Matrix[0]), pO.setMatrix("invView", eO.j.Matrix[0])), pO._multiTarget && this._bindGeometryRendering(pO), void 0 !== this._vertexArrayObject ? this._scene?.forceWireframe ? XO.bindBuffers(this._vertexBuffers, this._linesIndexBufferUseInstancing, pO) : (this._vertexArrayObject || (this._vertexArrayObject = this._engine.recordVertexArrayObject(this._vertexBuffers, this._indexBuffer, pO)), this._engine.bindVertexArrayObject(this._vertexArrayObject, this._indexBuffer)) : this._indexBuffer ? XO.bindBuffers(this._vertexBuffers, this._scene?.forceWireframe ? this._linesIndexBuffer : this._indexBuffer, pO) : XO.bindBuffers(this._vertexBuffers, this._scene?.forceWireframe ? this._linesIndexBufferUseInstancing : null, pO), this.useLogarithmicDepth && this._scene && (0, BO.s)(vK, pO, this._scene), this._imageProcessingConfiguration && !this._imageProcessingConfiguration.applyByPostProcess && this._imageProcessingConfiguration.bind(pO), this._setEngineBasedOnBlendMode(OO), pO._multiTarget && YK.d._BindZeroAlphaDiscard(XO, pO);
        let CO = !1;
        try {
          YK.d._BindAttachmentsForEffect(XO, pO) && (this._onBeforeDrawParticlesObservable && this._onBeforeDrawParticlesObservable.notifyObservers(pO), this._useInstancing ? this._scene?.forceWireframe ? XO.drawElementsType(6, 0, 10, this._useFixedCapacityForSnapshot ? this._capacity : this._particles.length) : XO.drawArraysType(7, 0, 4, this._useFixedCapacityForSnapshot ? this._capacity : this._particles.length) : this._scene?.forceWireframe ? XO.drawElementsType(1, 0, 10 * (this._useFixedCapacityForSnapshot ? this._capacity : this._particles.length)) : XO.drawElementsType(0, 0, 6 * (this._useFixedCapacityForSnapshot ? this._capacity : this._particles.length)), CO = !0)
        } finally {
          YK.d._RestoreAttachments(XO)
        }
        return CO ? this._particles.length : 0
      }
      render() {
        if (!this.isReady() || !this._particles.length && !this._useFixedCapacityForSnapshot) return 0;
        const OO = this._engine;
        let KO;
        return OO.setState && (OO.setState(!1), this.forceDepthWrite && OO.setDepthWrite(!0)), KO = this.blendMode === TO.BLENDMODE_MULTIPLYADD ? this._render(TO.BLENDMODE_MULTIPLY) + this._render(TO.BLENDMODE_ADD) : this._render(this.blendMode), this._engine.unbindInstanceAttributes(), this._engine.setAlphaMode(0), KO
      }
      _onDispose() {}
      dispose() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (this._engine._onReleaseRenderPassObservable?.remove(this._renderPassObserver), this._renderPassObserver = null, this.resetDrawCache(), this._vertexBuffer && (this._vertexBuffer.dispose(), this._vertexBuffer = null), this._spriteBuffer && (this._spriteBuffer.dispose(), this._spriteBuffer = null), this._indexBuffer && (this._engine._releaseBuffer(this._indexBuffer), this._indexBuffer = null), this._linesIndexBuffer && (this._engine._releaseBuffer(this._linesIndexBuffer), this._linesIndexBuffer = null), this._linesIndexBufferUseInstancing && (this._engine._releaseBuffer(this._linesIndexBufferUseInstancing), this._linesIndexBufferUseInstancing = null), this._vertexArrayObject && (this._engine.releaseVertexArrayObject(this._vertexArrayObject), this._vertexArrayObject = null), OO && this.particleTexture && (this.particleTexture.dispose(), this.particleTexture = null), OO && this.noiseTexture && (this.noiseTexture.dispose(), this.noiseTexture = null), this._rampGradientsTexture && (this._rampGradientsTexture.dispose(), this._rampGradientsTexture = null), this._onDispose(KO, pO), this._onBeforeDrawParticlesObservable && this._onBeforeDrawParticlesObservable.clear(), this._scene) {
          const OO = this._scene.ku.indexOf(this);
          OO > -1 && this._scene.ku.splice(OO, 1), this._scene._activeParticleSystems.dispose()
        }
        this.cpO.notifyObservers(this), this.cpO.clear(), this.onStoppedObservable.clear(), this.onStartedObservable.clear(), this.reset(), this._isDisposed = !0
      }
    }
    wK.ForceGLSL = !1;
    var ip, rp = pO(35676);
    ! function(OO) {
      OO[OO.ATTACHED = 0] = "ATTACHED", OO[OO.END = 1] = "END"
    }(ip || (ip = {}));
    class PK {
      constructor(OO) {
        if (this.particleSystem = OO, this.type = 1, this.inheritDirection = !1, this.inheritedVelocityAmount = 0, !OO.emitter || !OO.emitter.dispose) {
          const KO = (0, rp.e)("BABYLON.AbstractMesh");
          OO.emitter = new KO("SubemitterSystemEmitter", OO.JKO()), OO._disposeEmitterOnDispose = !0
        }
      }
      clone() {
        let OO = this.particleSystem.emitter;
        if (OO) {
          if (OO instanceof eO.o) OO = OO.clone();
          else if (-1 !== OO.getClassName().indexOf("Mesh")) {
            OO = new((0, rp.e)("BABYLON.Mesh"))("", OO.JKO()), OO.isVisible = !1
          }
        } else OO = new eO.o;
        const KO = new PK(this.particleSystem.clone(this.particleSystem.name, OO));
        return KO.particleSystem.name += "Clone", KO.type = this.type, KO.inheritDirection = this.inheritDirection, KO.inheritedVelocityAmount = this.inheritedVelocityAmount, KO.particleSystem._disposeEmitterOnDispose = !0, KO.particleSystem.disposeOnStop = !0, KO
      }
      serialize() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = {};
        return KO.type = this.type, KO.inheritDirection = this.inheritDirection, KO.inheritedVelocityAmount = this.inheritedVelocityAmount, KO.particleSystem = this.particleSystem.serialize(OO), KO
      }
      static _ParseParticleSystem(OO, KO, pO) {
        throw (0, mK.j)("ParseParticle")
      }
      static Parse(OO, KO, pO) {
        const XO = OO.particleSystem,
          bK = new PK(PK._ParseParticleSystem(XO, KO, pO, !0));
        return bK.type = OO.type, bK.inheritDirection = OO.inheritDirection, bK.inheritedVelocityAmount = OO.inheritedVelocityAmount, bK.particleSystem._isSubEmitter = !0, bK
      }
      dispose() {
        this.particleSystem.dispose()
      }
    }
    var mp = pO(37962),
      sK = pO(38077);
    const HK = () => {};
    class RK {
      constructor() {
        this.particlePositionGenerator = HK, this.particleDestinationGenerator = HK, this.particleDirectionGenerator = HK
      }
      startDirectionFunction(OO, KO, pO, XO) {
        const bK = eO.j.WX[0];
        if (this.particleDirectionGenerator && this.particleDirectionGenerator !== HK) this.particleDirectionGenerator(-1, pO, bK);
        else if (this.particleDestinationGenerator && this.particleDestinationGenerator !== HK) {
          this.particleDestinationGenerator(-1, pO, bK);
          const OO = eO.j.WX[1];
          bK.subtractToRef(pO.position, OO), OO.scaleToRef(1 / pO.lifeTime, bK)
        } else bK.set(0, 0, 0);
        XO ? KO.NhO(bK) : eO.o.TransformNormalToRef(bK, OO, KO)
      }
      startPositionFunction(OO, KO, pO, XO) {
        const bK = eO.j.WX[0];
        this.particlePositionGenerator && this.particlePositionGenerator !== HK ? this.particlePositionGenerator(-1, pO, bK) : bK.set(0, 0, 0), XO ? KO.NhO(bK) : eO.o.TransformCoordinatesToRef(bK, OO, KO)
      }
      clone() {
        const OO = new RK;
        return aK.d.DeepCopy(this, OO), OO
      }
      applyToShader(OO) {}
      buildUniformLayout(OO) {}
      getEffectDefines() {
        return "#define CUSTOMEMITTER"
      }
      getClassName() {
        return "CustomParticleEmitter"
      }
      serialize() {
        const OO = {};
        return OO.type = this.getClassName(), OO.particlePositionGenerator = this.particlePositionGenerator, OO.particleDestinationGenerator = this.particleDestinationGenerator, OO
      }
      parse(OO) {
        OO.particlePositionGenerator && (this.particlePositionGenerator = OO.particlePositionGenerator), OO.particleDestinationGenerator && (this.particleDestinationGenerator = OO.particleDestinationGenerator)
      }
    }
    const SK = eO.o.Zero(),
      JK = eO.o.Zero(),
      cp = eO.o.Zero();
    class BK {
      constructor() {
        this.strength = 0, this.position = eO.o.Zero()
      }
      _processParticle(OO, KO) {
        this.position.subtractToRef(OO.position, SK);
        const pO = SK.lengthSquared() + 1;
        SK.normalize().scaleToRef(this.strength / pO, JK), JK.scaleToRef(KO._tempScaledUpdateSpeed, cp), OO.direction.addInPlace(cp)
      }
      serialize() {
        return {
          position: this.position.WhO(),
          strength: this.strength
        }
      }
    }
    const ZK = ["level", "hasAlpha", "getAlphaFromRGB", "gammaSpace", "coordinatesIndex", "coordinatesMode", "wrapU", "wrapV", "wrapR", "anisotropicFilteringLevel", "uOffset", "vOffset", "uScale", "vScale", "uAng", "vAng", "wAng", "uRotationCenter", "vRotationCenter", "wRotationCenter"];
    class GK extends wK {
      constructor() {
        super(...arguments), this._disposeEmitterOnDispose = !1, this.doNotSerialize = !1, this.canStart = () => !0, this._flowMap = null, this._flowMapUpdate = null, this._source = null, this._blockReference = 0, this.flowMapStrength = 1, this._attractorUpdate = null, this.metadata = null, this._emitFromParticle = OO => {
          if (!this._subEmitters || 0 === this._subEmitters.length) return;
          const KO = Math.floor(Math.random() * this._subEmitters.length);
          for (const pO of this._subEmitters[KO])
            if (1 === pO.type) {
              const KO = pO.clone();
              OO._inheritParticleInfoToSubEmitter(KO), KO.particleSystem._rootParticleSystem = this, this.activeSubSystems.push(KO.particleSystem), KO.particleSystem.start()
            }
        }
      }
      get source() {
        return this._source
      }
      get isNodeGenerated() {
        return null !== this._source
      }
      get flowMap() {
        return this._flowMap
      }
      set flowMap(OO) {
        this._flowMap !== OO && (this._flowMap = OO, this._flowMapUpdate && (jp(this._flowMapUpdate), this._flowMapUpdate = null), OO && (this._flowMapUpdate = {
          process: OO => {
            const KO = this.JKO()?.getTransformMatrix();
            this._flowMap._processParticle(OO, this.flowMapStrength * this._tempScaledUpdateSpeed, KO)
          },
          previousItem: null,
          nextItem: null
        }, EK(this._flowMapUpdate, this._directionProcessing)))
      }
      addAttractor(OO) {
        super.addAttractor(OO), 1 === this._attractors.length && (this._attractorUpdate = {
          process: OO => {
            for (const KO of this._attractors) KO._processParticle(OO, this)
          },
          previousItem: null,
          nextItem: null
        }, EK(this._attractorUpdate, this._directionProcessing))
      }
      removeAttractor(OO) {
        super.removeAttractor(OO), 0 === this._attractors.length && this._attractorUpdate && jp(this._attractorUpdate)
      }
      start() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.startDelay;
        this.canStart() && super.start(OO)
      }
      _prepareSubEmitterInternalArray() {
        if (this._subEmitters = new Array, this.subEmitters)
          for (const OO of this.subEmitters) OO instanceof GK ? this._subEmitters.push([new PK(OO)]) : OO instanceof PK ? this._subEmitters.push([OO]) : OO instanceof Array && this._subEmitters.push(OO)
      }
      _stopSubEmitters() {
        if (this.activeSubSystems) {
          for (const OO of this.activeSubSystems) OO.stop(!0);
          this.activeSubSystems = []
        }
      }
      _removeFromRoot() {
        if (!this._rootParticleSystem) return;
        const OO = this._rootParticleSystem.activeSubSystems.indexOf(this); - 1 !== OO && this._rootParticleSystem.activeSubSystems.splice(OO, 1), this._rootParticleSystem = null
      }
      _preStart() {
        this._prepareSubEmitterInternalArray(), this._subEmitters && 0 != this._subEmitters.length && (this.activeSubSystems = [])
      }
      _postStop(OO) {
        OO && this._stopSubEmitters()
      }
      _prepareParticle(OO) {
        if (this._subEmitters && this._subEmitters.length > 0) {
          const KO = this._subEmitters[Math.floor(Math.random() * this._subEmitters.length)];
          OO._properties.attachedSubEmitters = [];
          for (const pO of KO)
            if (0 === pO.type) {
              const KO = pO.clone();
              OO._properties.attachedSubEmitters.push(KO), KO.particleSystem.start()
            }
        }
      }
      _onDispose() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (this._removeFromRoot(), this.subEmitters && !this._subEmitters && this._prepareSubEmitterInternalArray(), OO && this.particles)
          for (const pO of this.particles)
            if (pO._properties.attachedSubEmitters)
              for (let OO = pO._properties.attachedSubEmitters.length - 1; OO >= 0; OO -= 1) pO._properties.attachedSubEmitters[OO].dispose();
        if (KO && this.activeSubSystems)
          for (let pO = this.activeSubSystems.length - 1; pO >= 0; pO -= 1) this.activeSubSystems[pO].dispose();
        if (this._subEmitters && this._subEmitters.length) {
          for (let OO = 0; OO < this._subEmitters.length; OO++)
            for (const KO of this._subEmitters[OO]) KO.dispose();
          this._subEmitters = [], this.subEmitters = []
        }
        this._disposeEmitterOnDispose && this.emitter && this.emitter.dispose && this.emitter.dispose(!0)
      }
      static _Parse(OO, KO, pO, XO) {
        let bK;
        bK = pO instanceof mp.e ? null : pO;
        const lO = (0, rp.e)("BABYLON.Texture");
        if (lO && bK)
          if (OO.texture) KO.particleTexture = lO.Parse(OO.texture, bK, XO);
          else if (OO.textureName) {
          const pO = OO.textureSettings;
          if (KO.particleTexture = new lO(XO + OO.textureName, bK, !1, void 0 === OO.invertY || OO.invertY, pO ? pO.samplingMode : void 0), KO.particleTexture.name = OO.textureName, pO) {
            const OO = KO.particleTexture;
            for (const KO of ZK) void 0 !== pO[KO] && (OO[KO] = pO[KO])
          }
        }
        if (OO.emitterId || 0 === OO.emitterId || void 0 !== OO.emitter ? (OO.emitterId || 0 === OO.emitterId) && bK ? (KO.emitter = bK.getLastMeshById(OO.emitterId), KO.emitter || (KO.emitter = eO.o.Zero())) : KO.emitter = eO.o.FromArray(OO.emitter) : KO.emitter = eO.o.Zero(), KO.isLocal = !!OO.isLocal, void 0 !== OO.renderingGroupId && (KO.renderingGroupId = OO.renderingGroupId), void 0 !== OO.isBillboardBased && (KO.isBillboardBased = OO.isBillboardBased), void 0 !== OO.billboardMode && (KO.billboardMode = OO.billboardMode), void 0 !== OO.useLogarithmicDepth && (KO.useLogarithmicDepth = OO.useLogarithmicDepth), OO.animations) {
          for (let pO = 0; pO < OO.animations.length; pO++) {
            const XO = OO.animations[pO],
              bK = (0, rp.e)("BABYLON.Animation");
            bK && KO.animations.push(bK.Parse(XO))
          }
          KO.beginAnimationOnStart = OO.beginAnimationOnStart, KO.beginAnimationFrom = OO.beginAnimationFrom, KO.beginAnimationTo = OO.beginAnimationTo, KO.beginAnimationLoop = OO.beginAnimationLoop
        }
        if (OO.autoAnimate && bK && bK.beginAnimation(KO, OO.autoAnimateFrom, OO.autoAnimateTo, OO.autoAnimateLoop, OO.autoAnimateSpeed || 1), KO.startDelay = 0 | OO.startDelay, KO.minAngularSpeed = OO.minAngularSpeed, KO.maxAngularSpeed = OO.maxAngularSpeed, KO.minSize = OO.minSize, KO.maxSize = OO.maxSize, OO.minScaleX && (KO.minScaleX = OO.minScaleX, KO.maxScaleX = OO.maxScaleX, KO.minScaleY = OO.minScaleY, KO.maxScaleY = OO.maxScaleY), void 0 !== OO.preWarmCycles && (KO.preWarmCycles = OO.preWarmCycles, KO.preWarmStepOffset = OO.preWarmStepOffset), void 0 !== OO.minInitialRotation && (KO.minInitialRotation = OO.minInitialRotation, KO.maxInitialRotation = OO.maxInitialRotation), KO.minLifeTime = OO.minLifeTime, KO.maxLifeTime = OO.maxLifeTime, KO.minEmitPower = OO.minEmitPower, KO.maxEmitPower = OO.maxEmitPower, KO.emitRate = OO.emitRate, KO.gravity = eO.o.FromArray(OO.gravity), OO.noiseStrength && (KO.noiseStrength = eO.o.FromArray(OO.noiseStrength)), KO.color1 = DO.g.FromArray(OO.color1), KO.color2 = DO.g.FromArray(OO.color2), KO.colorDead = DO.g.FromArray(OO.colorDead), KO.updateSpeed = OO.updateSpeed, KO.targetStopDuration = OO.targetStopDuration, KO.blendMode = OO.blendMode, OO.colorGradients)
          for (const eO of OO.colorGradients) KO.addColorGradient(eO.gradient, DO.g.FromArray(eO.color1), eO.color2 ? DO.g.FromArray(eO.color2) : void 0);
        if (OO.rampGradients) {
          for (const pO of OO.rampGradients) KO.addRampGradient(pO.gradient, DO.e.FromArray(pO.color));
          KO.useRampGradients = OO.useRampGradients
        }
        if (OO.colorRemapGradients)
          for (const eO of OO.colorRemapGradients) KO.addColorRemapGradient(eO.gradient, void 0 !== eO.factor1 ? eO.factor1 : eO.factor, eO.factor2);
        if (OO.alphaRemapGradients)
          for (const eO of OO.alphaRemapGradients) KO.addAlphaRemapGradient(eO.gradient, void 0 !== eO.factor1 ? eO.factor1 : eO.factor, eO.factor2);
        if (OO.sizeGradients)
          for (const eO of OO.sizeGradients) KO.addSizeGradient(eO.gradient, void 0 !== eO.factor1 ? eO.factor1 : eO.factor, eO.factor2);
        if (OO.angularSpeedGradients)
          for (const eO of OO.angularSpeedGradients) KO.addAngularSpeedGradient(eO.gradient, void 0 !== eO.factor1 ? eO.factor1 : eO.factor, eO.factor2);
        if (OO.velocityGradients)
          for (const eO of OO.velocityGradients) KO.addVelocityGradient(eO.gradient, void 0 !== eO.factor1 ? eO.factor1 : eO.factor, eO.factor2);
        if (OO.dragGradients)
          for (const eO of OO.dragGradients) KO.addDragGradient(eO.gradient, void 0 !== eO.factor1 ? eO.factor1 : eO.factor, eO.factor2);
        if (OO.emitRateGradients)
          for (const eO of OO.emitRateGradients) KO.addEmitRateGradient(eO.gradient, void 0 !== eO.factor1 ? eO.factor1 : eO.factor, eO.factor2);
        if (OO.startSizeGradients)
          for (const eO of OO.startSizeGradients) KO.addStartSizeGradient(eO.gradient, void 0 !== eO.factor1 ? eO.factor1 : eO.factor, eO.factor2);
        if (OO.lifeTimeGradients)
          for (const eO of OO.lifeTimeGradients) KO.addLifeTimeGradient(eO.gradient, void 0 !== eO.factor1 ? eO.factor1 : eO.factor, eO.factor2);
        if (OO.limitVelocityGradients) {
          for (const pO of OO.limitVelocityGradients) KO.addLimitVelocityGradient(pO.gradient, void 0 !== pO.factor1 ? pO.factor1 : pO.factor, pO.factor2);
          KO.limitVelocityDamping = OO.limitVelocityDamping
        }
        if (OO.noiseTexture && bK) {
          const pO = (0, rp.e)("BABYLON.ProceduralTexture");
          KO.noiseTexture = pO.Parse(OO.noiseTexture, bK, XO)
        }
        let vK;
        if (OO.particleEmitterType) {
          switch (OO.particleEmitterType.type) {
            case "SphereParticleEmitter":
              vK = new LO;
              break;
            case "SphereDirectedParticleEmitter":
              vK = new QO;
              break;
            case "ConeEmitter":
            case "ConeParticleEmitter":
              vK = new AO;
              break;
            case "ConeDirectedParticleEmitter":
              vK = new fO;
              break;
            case "CylinderParticleEmitter":
              vK = new zK.e;
              break;
            case "CylinderDirectedParticleEmitter":
              vK = new zK.d;
              break;
            case "HemisphericParticleEmitter":
              vK = new VO;
              break;
            case "PointParticleEmitter":
              vK = new FO;
              break;
            case "MeshParticleEmitter":
              vK = new dO;
              break;
            case "CustomParticleEmitter":
              vK = new RK;
              break;
            default:
              vK = new MO.b
          }
          vK.parse(OO.particleEmitterType, bK)
        } else vK = new MO.b, vK.parse(OO, bK);
        KO.particleEmitterType = vK, KO.startSpriteCellID = OO.startSpriteCellID, KO.endSpriteCellID = OO.endSpriteCellID, KO.spriteCellLoop = OO.spriteCellLoop ?? !0, KO.spriteCellWidth = OO.spriteCellWidth, KO.spriteCellHeight = OO.spriteCellHeight, KO.spriteCellChangeSpeed = OO.spriteCellChangeSpeed, KO.spriteRandomStartCell = OO.spriteRandomStartCell, KO.disposeOnStop = OO.disposeOnStop ?? !1, KO.manualEmitCount = OO.manualEmitCount ?? -1
      }
      static Parse(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
          bK = arguments.length > 4 ? arguments[4] : void 0;
        const lO = OO.name;
        let vK, CO, hO = null,
          MO = null;
        if (KO instanceof mp.e ? vK = KO : (CO = KO, vK = CO.qb()), OO.customShader && (0, mK.b)(vK.createEffectForParticles)) {
          MO = OO.customShader;
          const KO = MO.shaderOptions.defines.length > 0 ? MO.shaderOptions.defines.join("\n") : "";
          hO = vK.createEffectForParticles(MO.shaderPath.fragmentElement, MO.shaderOptions.uniforms, MO.shaderOptions.samplers, KO)
        }
        const aK = new GK(lO, bK || OO.YO, KO, hO, OO.isAnimationSheetEnabled);
        if (aK.customShader = MO, aK._rootUrl = pO, OO.id && (aK.id = OO.id), OO.subEmitters) {
          aK.subEmitters = [];
          for (const XO of OO.subEmitters) {
            const OO = [];
            for (const bK of XO) OO.push(PK.Parse(bK, KO, pO));
            aK.subEmitters.push(OO)
          }
        }
        if (OO.attractors)
          for (const DO of OO.attractors) {
            const OO = new BK;
            OO.position = eO.o.FromArray(DO.position), OO.strength = DO.strength, aK.addAttractor(OO)
          }
        return GK._Parse(OO, aK, KO, pO), OO.textureMask && (aK.textureMask = DO.g.FromArray(OO.textureMask)), OO.worldOffset && (aK.worldOffset = eO.o.FromArray(OO.worldOffset)), OO.preventAutoStart && (aK.preventAutoStart = OO.preventAutoStart), OO.metadata && (aK.metadata = OO.metadata), XO || aK.preventAutoStart || aK.start(), aK
      }
      serialize() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = {};
        if (GK._Serialize(KO, this, OO), KO.textureMask = this.textureMask.WhO(), KO.customShader = this.customShader, KO.preventAutoStart = this.preventAutoStart, KO.worldOffset = this.worldOffset.WhO(), this.metadata && (KO.metadata = this.metadata), this.subEmitters) {
          KO.subEmitters = [], this._subEmitters || this._prepareSubEmitterInternalArray();
          for (const pO of this._subEmitters) {
            const XO = [];
            for (const KO of pO) KO.particleSystem.doNotSerialize || XO.push(KO.serialize(OO));
            KO.subEmitters.push(XO)
          }
        }
        if (this._attractors && this._attractors.length) {
          KO.attractors = [];
          for (const OO of this._attractors) KO.attractors.push(OO.serialize())
        }
        return KO
      }
      static _Serialize(OO, KO, pO) {
        if (OO.name = KO.name, OO.id = KO.id, OO.YO = KO.getCapacity(), OO.disposeOnStop = KO.disposeOnStop, OO.manualEmitCount = KO.manualEmitCount, KO.emitter.position) {
          const pO = KO.emitter;
          OO.emitterId = pO.id
        } else {
          const pO = KO.emitter;
          OO.emitter = pO.WhO()
        }
        if (KO.particleEmitterType && (OO.particleEmitterType = KO.particleEmitterType.serialize()), KO.particleTexture)
          if (pO) OO.texture = KO.particleTexture.serialize();
          else {
            const pO = KO.particleTexture;
            OO.textureName = KO.particleTexture.name, OO.invertY = !!pO._invertY;
            const XO = {};
            for (const OO of ZK) XO[OO] = pO[OO];
            XO.samplingMode = pO.samplingMode, OO.textureSettings = XO
          } OO.isLocal = KO.isLocal, sK.c.AppendSerializedAnimations(KO, OO), OO.beginAnimationOnStart = KO.beginAnimationOnStart, OO.beginAnimationFrom = KO.beginAnimationFrom, OO.beginAnimationTo = KO.beginAnimationTo, OO.beginAnimationLoop = KO.beginAnimationLoop, OO.startDelay = KO.startDelay, OO.renderingGroupId = KO.renderingGroupId, OO.isBillboardBased = KO.isBillboardBased, OO.billboardMode = KO.billboardMode, OO.minAngularSpeed = KO.minAngularSpeed, OO.maxAngularSpeed = KO.maxAngularSpeed, OO.minSize = KO.minSize, OO.maxSize = KO.maxSize, OO.minScaleX = KO.minScaleX, OO.maxScaleX = KO.maxScaleX, OO.minScaleY = KO.minScaleY, OO.maxScaleY = KO.maxScaleY, OO.minEmitPower = KO.minEmitPower, OO.maxEmitPower = KO.maxEmitPower, OO.minLifeTime = KO.minLifeTime, OO.maxLifeTime = KO.maxLifeTime, OO.emitRate = KO.emitRate, OO.gravity = KO.gravity.WhO(), OO.noiseStrength = KO.noiseStrength.WhO(), OO.color1 = KO.color1.WhO(), OO.color2 = KO.color2.WhO(), OO.colorDead = KO.colorDead.WhO(), OO.updateSpeed = KO.updateSpeed, OO.targetStopDuration = KO.targetStopDuration, OO.blendMode = KO.blendMode, OO.preWarmCycles = KO.preWarmCycles, OO.preWarmStepOffset = KO.preWarmStepOffset, OO.minInitialRotation = KO.minInitialRotation, OO.maxInitialRotation = KO.maxInitialRotation, OO.startSpriteCellID = KO.startSpriteCellID, OO.spriteCellLoop = KO.spriteCellLoop, OO.endSpriteCellID = KO.endSpriteCellID, OO.spriteCellChangeSpeed = KO.spriteCellChangeSpeed, OO.spriteCellWidth = KO.spriteCellWidth, OO.spriteCellHeight = KO.spriteCellHeight, OO.spriteRandomStartCell = KO.spriteRandomStartCell, OO.isAnimationSheetEnabled = KO.isAnimationSheetEnabled, OO.useLogarithmicDepth = KO.useLogarithmicDepth;
        const XO = KO.getColorGradients();
        if (XO) {
          OO.colorGradients = [];
          for (const KO of XO) {
            const pO = {
              gradient: KO.gradient,
              color1: KO.color1.WhO()
            };
            KO.color2 ? pO.color2 = KO.color2.WhO() : pO.color2 = KO.color1.WhO(), OO.colorGradients.push(pO)
          }
        }
        const bK = KO.getRampGradients();
        if (bK) {
          OO.rampGradients = [];
          for (const KO of bK) {
            const pO = {
              gradient: KO.gradient,
              color: KO.color.WhO()
            };
            OO.rampGradients.push(pO)
          }
          OO.useRampGradients = KO.useRampGradients
        }
        const eO = KO.getColorRemapGradients();
        if (eO) {
          OO.colorRemapGradients = [];
          for (const KO of eO) {
            const pO = {
              gradient: KO.gradient,
              factor1: KO.factor1
            };
            void 0 !== KO.factor2 ? pO.factor2 = KO.factor2 : pO.factor2 = KO.factor1, OO.colorRemapGradients.push(pO)
          }
        }
        const lO = KO.getAlphaRemapGradients();
        if (lO) {
          OO.alphaRemapGradients = [];
          for (const KO of lO) {
            const pO = {
              gradient: KO.gradient,
              factor1: KO.factor1
            };
            void 0 !== KO.factor2 ? pO.factor2 = KO.factor2 : pO.factor2 = KO.factor1, OO.alphaRemapGradients.push(pO)
          }
        }
        const vK = KO.getSizeGradients();
        if (vK) {
          OO.sizeGradients = [];
          for (const KO of vK) {
            const pO = {
              gradient: KO.gradient,
              factor1: KO.factor1
            };
            void 0 !== KO.factor2 ? pO.factor2 = KO.factor2 : pO.factor2 = KO.factor1, OO.sizeGradients.push(pO)
          }
        }
        const CO = KO.getAngularSpeedGradients();
        if (CO) {
          OO.angularSpeedGradients = [];
          for (const KO of CO) {
            const pO = {
              gradient: KO.gradient,
              factor1: KO.factor1
            };
            void 0 !== KO.factor2 ? pO.factor2 = KO.factor2 : pO.factor2 = KO.factor1, OO.angularSpeedGradients.push(pO)
          }
        }
        const hO = KO.getVelocityGradients();
        if (hO) {
          OO.velocityGradients = [];
          for (const KO of hO) {
            const pO = {
              gradient: KO.gradient,
              factor1: KO.factor1
            };
            void 0 !== KO.factor2 ? pO.factor2 = KO.factor2 : pO.factor2 = KO.factor1, OO.velocityGradients.push(pO)
          }
        }
        const DO = KO.getDragGradients();
        if (DO) {
          OO.dragGradients = [];
          for (const KO of DO) {
            const pO = {
              gradient: KO.gradient,
              factor1: KO.factor1
            };
            void 0 !== KO.factor2 ? pO.factor2 = KO.factor2 : pO.factor2 = KO.factor1, OO.dragGradients.push(pO)
          }
        }
        const MO = KO.getEmitRateGradients();
        if (MO) {
          OO.emitRateGradients = [];
          for (const KO of MO) {
            const pO = {
              gradient: KO.gradient,
              factor1: KO.factor1
            };
            void 0 !== KO.factor2 ? pO.factor2 = KO.factor2 : pO.factor2 = KO.factor1, OO.emitRateGradients.push(pO)
          }
        }
        const aK = KO.getStartSizeGradients();
        if (aK) {
          OO.startSizeGradients = [];
          for (const KO of aK) {
            const pO = {
              gradient: KO.gradient,
              factor1: KO.factor1
            };
            void 0 !== KO.factor2 ? pO.factor2 = KO.factor2 : pO.factor2 = KO.factor1, OO.startSizeGradients.push(pO)
          }
        }
        const oO = KO.getLifeTimeGradients();
        if (oO) {
          OO.lifeTimeGradients = [];
          for (const KO of oO) {
            const pO = {
              gradient: KO.gradient,
              factor1: KO.factor1
            };
            void 0 !== KO.factor2 ? pO.factor2 = KO.factor2 : pO.factor2 = KO.factor1, OO.lifeTimeGradients.push(pO)
          }
        }
        const FO = KO.getLimitVelocityGradients();
        if (FO) {
          OO.limitVelocityGradients = [];
          for (const KO of FO) {
            const pO = {
              gradient: KO.gradient,
              factor1: KO.factor1
            };
            void 0 !== KO.factor2 ? pO.factor2 = KO.factor2 : pO.factor2 = KO.factor1, OO.limitVelocityGradients.push(pO)
          }
          OO.limitVelocityDamping = KO.limitVelocityDamping
        }
        KO.noiseTexture && (OO.noiseTexture = KO.noiseTexture.serialize())
      }
      clone(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = {
          ...this._customWrappers
        };
        let bK = null;
        const eO = this._engine;
        if ((0, mK.b)(eO.createEffectForParticles) && null != this.customShader) {
          bK = this.customShader;
          const OO = bK.shaderOptions.defines.length > 0 ? bK.shaderOptions.defines.join("\n") : "",
            KO = eO.createEffectForParticles(bK.shaderPath.fragmentElement, bK.shaderOptions.uniforms, bK.shaderOptions.samplers, OO);
          XO[0] ? XO[0].effect = KO : this.setCustomEffect(KO, 0)
        }
        const lO = this.serialize(pO),
          vK = !1 === pO && this.particleTexture ? this.particleTexture.clone() : null;
        vK && (lO.textureName = void 0);
        const CO = GK.Parse(lO, this._scene || this._engine, this._rootUrl);
        return CO.name = OO, CO.customShader = bK, CO._customWrappers = XO, vK && (CO.particleTexture = vK), void 0 === KO && (KO = this.emitter), this.noiseTexture && (CO.noiseTexture = this.noiseTexture.clone()), CO.emitter = KO, this.preventAutoStart || CO.start(), CO
      }
    }
    GK.BILLBOARDMODE_Y = 2, GK.BILLBOARDMODE_ALL = 7, GK.BILLBOARDMODE_STRETCHED = 8, GK.BILLBOARDMODE_STRETCHED_LOCAL = 9;
    let qp = !1;
    qp || (qp = !0, PK._ParseParticleSystem = GK.Parse)
  },
  39663: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      SkyMaterial: () => AO,
      _MaxColorValueForRenderTarget: () => zK
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(38077),
      lO = pO(35624),
      vK = pO(38378),
      CO = pO(38447),
      hO = pO(39620),
      DO = pO(39297),
      MO = pO(38162),
      aK = pO(35676),
      oO = pO(38464),
      FO = pO(38449),
      VO = pO(38431),
      LO = pO(38424);
    class QO extends vK.e {
      constructor() {
        super(), this.CLIPPLANE = !1, this.CLIPPLANE2 = !1, this.CLIPPLANE3 = !1, this.CLIPPLANE4 = !1, this.CLIPPLANE5 = !1, this.CLIPPLANE6 = !1, this.POINTSIZE = !1, this.FOG = !1, this.VERTEXCOLOR = !1, this.VERTEXALPHA = !1, this.IMAGEPROCESSINGPOSTPROCESS = !1, this.SKIPFINALCOLORCLAMP = !1, this.DITHER = !1, this.LOGARITHMICDEPTH = !1, this.SKY_RAW_HDR_OUTPUT = !1, this.rebuild()
      }
    }

    function zK(OO) {
      switch (OO) {
        case hO.b.TEXTURETYPE_HALF_FLOAT:
          return 65504;
        case hO.b.TEXTURETYPE_FLOAT:
          return 3e38;
        default:
          return 1
      }
    }
    let AO = (() => {
      var OO;
      let KO, vK, hO, aK, AO, fO, dO, TO, NO, IO, yK, gK, uO, EO, jK, YO = CO.d,
        wO = [],
        iK = [],
        rK = [],
        PO = [],
        mK = [],
        sO = [],
        HO = [],
        RO = [],
        SO = [],
        JO = [],
        cK = [],
        BO = [],
        ZO = [],
        GO = [],
        qK = [],
        xK = [],
        nO = [],
        WO = [],
        tK = [],
        kK = [],
        UO = [],
        OK = [],
        KK = [],
        pK = [],
        XK = [],
        bp = [],
        eK = [],
        lK = [],
        vp = [],
        CK = [];
      return OO = class extends YO {
        constructor(OO, KO) {
          super(OO, KO, void 0, arguments.length > 2 && void 0 !== arguments[2] && arguments[2]), this.luminance = (0, XO.i)(this, wO, 1), this.turbidity = ((0, XO.i)(this, iK), (0, XO.i)(this, rK, 10)), this.rayleigh = ((0, XO.i)(this, PO), (0, XO.i)(this, mK, 2)), this.mieCoefficient = ((0, XO.i)(this, sO), (0, XO.i)(this, HO, .005)), this.mieDirectionalG = ((0, XO.i)(this, RO), (0, XO.i)(this, SO, .8)), this.distance = ((0, XO.i)(this, JO), (0, XO.i)(this, cK, 500)), this.inclination = ((0, XO.i)(this, BO), (0, XO.i)(this, ZO, .49)), this.azimuth = ((0, XO.i)(this, GO), (0, XO.i)(this, qK, .25)), this.sunPosition = ((0, XO.i)(this, xK), (0, XO.i)(this, nO, new lO.WX(0, 100, 0))), this.useSunPosition = ((0, XO.i)(this, WO), (0, XO.i)(this, tK, !1)), this.cameraOffset = ((0, XO.i)(this, kK), (0, XO.i)(this, UO, lO.WX.Zero())), this.up = ((0, XO.i)(this, OK), (0, XO.i)(this, KK, lO.WX.Up())), this.dithering = ((0, XO.i)(this, pK), (0, XO.i)(this, XK, !1)), this.rawHdrOutput = ((0, XO.i)(this, bp), (0, XO.i)(this, eK, !1)), this.cloudiness = ((0, XO.i)(this, lK), (0, XO.i)(this, vp, 0)), this._cameraPosition = ((0, XO.i)(this, CK), lO.WX.Zero()), this._skyOrientation = new lO.Quaternion
        }
        needAlphaBlending() {
          return this.alpha < 1
        }
        needAlphaTesting() {
          return !1
        }
        getAlphaTestTexture() {
          return null
        }
        isReadyForSubMesh(KO, pO) {
          const XO = pO._drawWrapper;
          if (this.isFrozen && XO.effect && XO._wasPreviouslyReady) return !0;
          pO.materialDefines || (pO.materialDefines = new QO);
          const bK = pO.materialDefines,
            eO = this.JKO();
          if (this._isReadyForSubMesh(pO)) return !0;
          if ((0, LO.fb)(KO, eO, this._useLogarithmicDepth, this.pointsCloud, this.fogEnabled, !1, bK, void 0, void 0, void 0, this._isVertexOutputInvariant), (0, LO.S)(KO, bK, !0, !1), bK.IMAGEPROCESSINGPOSTPROCESS !== eO.imageProcessingConfiguration.applyByPostProcess && bK.markAsMiscDirty(), bK.DITHER !== this.dithering && bK.markAsMiscDirty(), bK.SKY_RAW_HDR_OUTPUT !== this.rawHdrOutput && bK.markAsMiscDirty(), bK.isDirty) {
            bK.markAsProcessed(), eO.resetCachedMaterial();
            const KO = new FO.c;
            bK.FOG && KO.addFallback(1, "FOG"), bK.IMAGEPROCESSINGPOSTPROCESS = eO.imageProcessingConfiguration.applyByPostProcess, bK.DITHER = this.dithering, bK.SKY_RAW_HDR_OUTPUT = this.rawHdrOutput;
            const XO = [DO.f.PositionKind];
            bK.VERTEXCOLOR && XO.push(DO.f.ColorKind);
            const lO = "sky",
              vK = ["world", "viewProjection", "view", "vFogInfos", "vFogColor", "logarithmicDepthConstant", "pointSize", "luminance", "turbidity", "rayleigh", "mieCoefficient", "mieDirectionalG", "sunPosition", "cameraPosition", "cameraOffset", "up", "cloudiness", "maxColorValue"];
            (0, VO.c)(vK);
            const CO = bK.toString();
            pO.setEffect(eO.qb().createEffect(lO, {
              attributes: XO,
              uniformsNames: vK,
              uniformBuffersNames: [],
              samplers: [],
              defines: CO,
              fallbacks: KO,
              onCompiled: this.onCompiled,
              onError: this.onError,
              shaderLanguage: this._shaderLanguage,
              extraInitializationsAsync: OO._ShaderLoader.getLoadCallback(this._shaderLanguage)
            }, eO.qb()), bK, this._materialContext)
          }
          return !(!pO.effect || !pO.effect.isReady()) && (bK._renderId = eO.getRenderId(), XO._wasPreviouslyReady = !0, !0)
        }
        bindForSubMesh(OO, KO, pO) {
          const XO = this.JKO(),
            bK = pO.materialDefines;
          if (!bK) return;
          const eO = pO.effect;
          if (!eO) return;
          this._activeEffect = eO, this.bindOnlyWorldMatrix(OO), this._activeEffect.setMatrix("viewProjection", XO.getTransformMatrix()), this._mustRebind(XO, eO, pO) && ((0, VO.e)(eO, this, XO), this.pointsCloud && this._activeEffect.setFloat("pointSize", this.pointSize), this._useLogarithmicDepth && (0, LO.s)(bK, eO, XO)), XO.fogEnabled && KO.applyFog && XO.fogMode !== MO.d.FOGMODE_NONE && this._activeEffect.setMatrix("view", XO.getViewMatrix()), (0, LO.i)(XO, KO, this._activeEffect, this.rawHdrOutput);
          const vK = XO.activeCamera;
          if (vK) {
            const OO = vK.getWorldMatrix();
            this._cameraPosition.x = OO.m[12], this._cameraPosition.y = OO.m[13], this._cameraPosition.z = OO.m[14], this._activeEffect.setVector3("cameraPosition", lO.TmpVectors.WX[0].NhO(this._cameraPosition).oDO(XO.floatingOriginOffset))
          }
          if (this._activeEffect.setVector3("cameraOffset", this.cameraOffset), this._activeEffect.setVector3("up", this.up), (this.rawHdrOutput || this.luminance > 0) && this._activeEffect.setFloat("luminance", this.luminance), this._activeEffect.setFloat("turbidity", this.turbidity), this._activeEffect.setFloat("rayleigh", this.rayleigh), this._activeEffect.setFloat("mieCoefficient", this.mieCoefficient), this._activeEffect.setFloat("mieDirectionalG", this.mieDirectionalG), this._activeEffect.setFloat("cloudiness", this.cloudiness), this.rawHdrOutput) {
            const OO = XO.qb()._currentRenderTarget;
            this._activeEffect.setFloat("maxColorValue", zK(OO?.texture?.type))
          }
          if (!this.useSunPosition) {
            const OO = Math.PI * (this.inclination - .5),
              KO = 2 * Math.PI * (this.azimuth - .5);
            this.sunPosition.x = this.distance * Math.cos(KO) * Math.cos(OO), this.sunPosition.y = this.distance * Math.sin(-OO), this.sunPosition.z = this.distance * Math.sin(KO) * Math.cos(OO), lO.Quaternion.FromUnitVectorsToRef(lO.WX.UpReadOnly, this.up, this._skyOrientation), this.sunPosition.rotateByQuaternionToRef(this._skyOrientation, this.sunPosition)
          }
          this._activeEffect.setVector3("sunPosition", this.sunPosition), this._afterBind(KO, this._activeEffect, pO)
        }
        getAnimatables() {
          return []
        }
        dispose(OO) {
          super.dispose(OO)
        }
        clone(KO) {
          return eO.c.Clone((() => new OO(KO, this.JKO())), this)
        }
        serialize() {
          const OO = super.serialize();
          return OO.customType = "BABYLON.SkyMaterial", OO
        }
        getClassName() {
          return "SkyMaterial"
        }
        static Parse(KO, pO, XO) {
          return eO.c.Parse((() => new OO(KO.name, pO)), KO, pO, XO)
        }
      }, (() => {
        const pO = "function" === typeof Symbol && Symbol.metadata ? Object.create(YO[Symbol.metadata] ?? null) : void 0;
        KO = [(0, bK.M)()], vK = [(0, bK.M)()], hO = [(0, bK.M)()], aK = [(0, bK.M)()], AO = [(0, bK.M)()], fO = [(0, bK.M)()], dO = [(0, bK.M)()], TO = [(0, bK.M)()], NO = [(0, bK.L)()], IO = [(0, bK.M)()], yK = [(0, bK.L)()], gK = [(0, bK.L)()], uO = [(0, bK.M)()], EO = [(0, bK.M)()], jK = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "luminance",
          static: !1,
          private: !1,
          access: {
            has: OO => "luminance" in OO,
            get: OO => OO.luminance,
            set: (OO, KO) => {
              OO.luminance = KO
            }
          },
          metadata: pO
        }, wO, iK), (0, XO.f)(null, null, vK, {
          kind: "field",
          name: "turbidity",
          static: !1,
          private: !1,
          access: {
            has: OO => "turbidity" in OO,
            get: OO => OO.turbidity,
            set: (OO, KO) => {
              OO.turbidity = KO
            }
          },
          metadata: pO
        }, rK, PO), (0, XO.f)(null, null, hO, {
          kind: "field",
          name: "rayleigh",
          static: !1,
          private: !1,
          access: {
            has: OO => "rayleigh" in OO,
            get: OO => OO.rayleigh,
            set: (OO, KO) => {
              OO.rayleigh = KO
            }
          },
          metadata: pO
        }, mK, sO), (0, XO.f)(null, null, aK, {
          kind: "field",
          name: "mieCoefficient",
          static: !1,
          private: !1,
          access: {
            has: OO => "mieCoefficient" in OO,
            get: OO => OO.mieCoefficient,
            set: (OO, KO) => {
              OO.mieCoefficient = KO
            }
          },
          metadata: pO
        }, HO, RO), (0, XO.f)(null, null, AO, {
          kind: "field",
          name: "mieDirectionalG",
          static: !1,
          private: !1,
          access: {
            has: OO => "mieDirectionalG" in OO,
            get: OO => OO.mieDirectionalG,
            set: (OO, KO) => {
              OO.mieDirectionalG = KO
            }
          },
          metadata: pO
        }, SO, JO), (0, XO.f)(null, null, fO, {
          kind: "field",
          name: "distance",
          static: !1,
          private: !1,
          access: {
            has: OO => "distance" in OO,
            get: OO => OO.distance,
            set: (OO, KO) => {
              OO.distance = KO
            }
          },
          metadata: pO
        }, cK, BO), (0, XO.f)(null, null, dO, {
          kind: "field",
          name: "inclination",
          static: !1,
          private: !1,
          access: {
            has: OO => "inclination" in OO,
            get: OO => OO.inclination,
            set: (OO, KO) => {
              OO.inclination = KO
            }
          },
          metadata: pO
        }, ZO, GO), (0, XO.f)(null, null, TO, {
          kind: "field",
          name: "azimuth",
          static: !1,
          private: !1,
          access: {
            has: OO => "azimuth" in OO,
            get: OO => OO.azimuth,
            set: (OO, KO) => {
              OO.azimuth = KO
            }
          },
          metadata: pO
        }, qK, xK), (0, XO.f)(null, null, NO, {
          kind: "field",
          name: "sunPosition",
          static: !1,
          private: !1,
          access: {
            has: OO => "sunPosition" in OO,
            get: OO => OO.sunPosition,
            set: (OO, KO) => {
              OO.sunPosition = KO
            }
          },
          metadata: pO
        }, nO, WO), (0, XO.f)(null, null, IO, {
          kind: "field",
          name: "useSunPosition",
          static: !1,
          private: !1,
          access: {
            has: OO => "useSunPosition" in OO,
            get: OO => OO.useSunPosition,
            set: (OO, KO) => {
              OO.useSunPosition = KO
            }
          },
          metadata: pO
        }, tK, kK), (0, XO.f)(null, null, yK, {
          kind: "field",
          name: "cameraOffset",
          static: !1,
          private: !1,
          access: {
            has: OO => "cameraOffset" in OO,
            get: OO => OO.cameraOffset,
            set: (OO, KO) => {
              OO.cameraOffset = KO
            }
          },
          metadata: pO
        }, UO, OK), (0, XO.f)(null, null, gK, {
          kind: "field",
          name: "up",
          static: !1,
          private: !1,
          access: {
            has: OO => "up" in OO,
            get: OO => OO.up,
            set: (OO, KO) => {
              OO.up = KO
            }
          },
          metadata: pO
        }, KK, pK), (0, XO.f)(null, null, uO, {
          kind: "field",
          name: "dithering",
          static: !1,
          private: !1,
          access: {
            has: OO => "dithering" in OO,
            get: OO => OO.dithering,
            set: (OO, KO) => {
              OO.dithering = KO
            }
          },
          metadata: pO
        }, XK, bp), (0, XO.f)(null, null, EO, {
          kind: "field",
          name: "rawHdrOutput",
          static: !1,
          private: !1,
          access: {
            has: OO => "rawHdrOutput" in OO,
            get: OO => OO.rawHdrOutput,
            set: (OO, KO) => {
              OO.rawHdrOutput = KO
            }
          },
          metadata: pO
        }, eK, lK), (0, XO.f)(null, null, jK, {
          kind: "field",
          name: "cloudiness",
          static: !1,
          private: !1,
          access: {
            has: OO => "cloudiness" in OO,
            get: OO => OO.cloudiness,
            set: (OO, KO) => {
              OO.cloudiness = KO
            }
          },
          metadata: pO
        }, vp, CK), pO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: pO
        })
      })(), OO._ShaderLoader = new oO.e((() => [pO.e(310).then((() => pO(59116))), pO.e(303).then((() => pO(59120)))]), (() => [pO.e(327).then((() => pO(59129))), pO.e(321).then((() => pO(59136)))])), OO
    })();
    (0, aK.h)("BABYLON.SkyMaterial", AO)
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);