export const id = 4;
export const ids = [4];
export const modules = {
  34986: (OO, KO, pO) => {
    var XO = {
      "./Artisan Bench.json": [39138, 253],
      "./Aspen Item Pedestal.json": [39147, 254],
      "./Cedar Item Pedestal.json": [39149, 255],
      "./Cherry Item Pedestal.json": [39157, 256],
      "./Furnace.json": [39164, 257],
      "./Jungle Item Pedestal.json": [39171, 258],
      "./Mango Item Pedestal.json": [39173, 259],
      "./Palm Item Pedestal.json": [39176, 260],
      "./Pear Item Pedestal.json": [39180, 261],
      "./Pine Item Pedestal.json": [39185, 262],
      "./Plum Item Pedestal.json": [39187, 263],
      "./Potion Table.json": [39195, 264],
      "./Salvaging Table.json": [39197, 265],
      "./Showcase.json": [39201, 266],
      "./Spectral Item Pedestal.json": [39206, 267],
      "./Workbench.json": [39209, 268]
    };

    function bK(OO) {
      if (!pO.o(XO, OO)) return Promise.resolve().then((() => {
        var KO = new Error("Cannot find module '" + OO + "'");
        throw KO.code = "MODULE_NOT_FOUND", KO
      }));
      var KO = XO[OO],
        bK = KO[0];
      return pO.e(KO[1]).then((() => pO(bK)))
    }
    bK.keys = () => Object.keys(XO), bK.id = 34986, OO.exports = bK
  },
  34983: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      getBlockModelIconUrl: () => aK,
      hasBlockModelIcon: () => hO
    });
    var XO = pO(34974),
      bK = pO(34968);
    const eO = pO(34986),
      lO = new Map(eO.keys().filter((OO => OO.startsWith("./"))).map((OO => [OO.slice(2, -5), OO]))),
      vK = new Map,
      CO = new Map;

    function hO(OO) {
      return lO.has(OO)
    }

    function DO(OO) {
      return eO(lO.get(OO))
    }
    async function MO(OO, KO, pO) {
      const {
        data: XO,
        texture: eO
      } = await
      function(OO) {
        let KO = vK.get(OO);
        return KO || (KO = DO(OO).then((async OO => {
          const KO = new Image;
          KO.src = OO.texture, await KO.decode();
          const pO = document.createElement("canvas");
          pO.width = KO.width, pO.height = KO.height;
          const XO = pO.getContext("2d");
          return XO.drawImage(KO, 0, 0), {
            data: OO,
            texture: {
              width: KO.width,
              height: KO.height,
              pixels: XO.getImageData(0, 0, KO.width, KO.height).data
            }
          }
        })), KO.catch((() => {
          vK.delete(OO)
        })), vK.set(OO, KO)), KO
      }(OO), lO = document.createElement("canvas");
      return lO.width = KO, lO.height = KO, lO.getContext("2d").putImageData(new ImageData((0, bK.f)(XO, eO, KO, pO), KO, KO), 0, 0), lO.toDataURL()
    }

    function aK(OO, KO, pO) {
      const bK = `${KO}|${pO}|${OO}`;
      let eO = CO.get(bK);
      return eO || (eO = (0, XO.e)(OO, (() => DO(OO)), KO, pO).then((XO => null !== XO && void 0 !== XO ? XO : MO(OO, KO, pO))), eO.catch((() => {
        CO.delete(bK)
      })), CO.set(bK, eO)), eO
    }
  },
  34974: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => yK,
      e: () => gK,
      h: () => zK
    });
    var XO = pO(129),
      bK = pO(94);
    const eO = new(pO(34981).c)(new URL(pO.p + pO.u(3), pO.b), {
      name: "blockIconWorker",
      type: "module"
    });
    var lO = pO(2373);
    const vK = 1e4,
      CO = 3e4;
    let hO = null,
      DO = null,
      MO = null,
      aK = !1,
      oO = 0;
    const FO = new Map;
    let VO = null;
    const LO = new Map,
      QO = new Map;

    function zK(OO) {
      return new Promise(((KO, pO) => {
        const XO = new Image;
        XO.crossOrigin = "anonymous", XO.onload = () => {
          KO(XO)
        }, XO.onerror = () => {
          pO(new Error(`A block icon's texture did not load: ${OO.slice(0,100)}`))
        }, XO.src = OO
      }))
    }

    function AO(OO) {
      var KO, pO;
      aK || console.warn(`[blockIconWorker] block icons draw on the page, as the worker ${OO}`), aK = !0, null === (KO = hO) || void 0 === KO || KO.terminate(), hO = null, DO = null, LO.clear(), QO.clear();
      for (const XO of FO.values()) XO(null);
      FO.clear(), null === (pO = VO) || void 0 === pO || pO()
    }

    function fO() {
      return MO ??= async function() {
        if ("undefined" === typeof Worker || "undefined" === typeof OffscreenCanvas || "undefined" === typeof createImageBitmap) return;
        if ("page" === XO.b.ios_icon_worker_v1 && (0, bK.isWebKit)()) return;
        try {
          hO = await async function() {
            return await eO.ready(), eO.start()
          }()
        } catch (vK) {
          return void AO(`did not start (${String(vK)})`)
        }
        let OO = () => {};
        const KO = new Promise((KO => {
          OO = KO
        }));
        hO.onmessage = KO => {
          let {
            data: pO
          } = KO;
          if ("started" === pO.type) DO = hO, OO();
          else if ("failed" === pO.type) AO(`failed a draw (${pO.message})`);
          else {
            var XO, bK;
            null === (XO = FO.get(pO.id)) || void 0 === XO || XO(pO.url), FO.delete(pO.id), null === (bK = VO) || void 0 === bK || bK()
          }
        }, hO.onerror = KO => {
          KO.preventDefault(), AO(`stopped (${KO.message||"its script did not load or run"})`), OO()
        };
        const pO = `did not start in ${CO/1e3} s`;
        await (0, lO.d)(KO, CO, pO).catch((() => {
          AO(pO)
        }))
      }(), MO
    }

    function dO() {
      if (null !== VO || 0 === FO.size) return;
      const OO = new Promise((OO => {
          VO = OO
        })),
        KO = `did not answer in ${vK/1e3} s`;
      (0, lO.d)(OO, vK, KO).then((() => {
        VO = null, dO()
      }), (() => {
        VO = null, AO(KO)
      }))
    }

    function TO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
      OO.postMessage(KO, pO)
    }

    function NO(OO, KO, pO, XO) {
      let bK = KO.get(pO);
      return void 0 === bK && (bK = XO().then((async KO => {
        let {
          image: pO,
          request: XO
        } = KO;
        try {
          const KO = await createImageBitmap(pO);
          TO(OO, XO(KO), [KO])
        } catch (bK) {
          AO(`could not take an image (${String(bK)})`)
        }
      })), bK.catch((() => {
        KO.get(pO) === bK && KO.delete(pO)
      })), KO.set(pO, bK)), bK
    }
    async function IO(OO, KO) {
      fO();
      const pO = DO;
      if (null === pO) return null;
      if (await OO(pO), DO !== pO) return null;
      const XO = ++oO;
      return new Promise((OO => {
        FO.set(XO, OO), TO(pO, KO(XO)), dO()
      }))
    }

    function yK(OO, KO, pO) {
      return IO((KO => Promise.all([OO.top, OO.left, OO.right].map((OO => function(OO, KO) {
        return NO(OO, LO, KO, (async () => ({
          image: await zK(KO),
          request: OO => ({
            type: "texture",
            url: KO,
            bitmap: OO
          })
        })))
      }(KO, OO))))), (XO => ({
        type: "draw",
        id: XO,
        ...OO,
        size: KO,
        outlineWidth: pO
      })))
    }

    function gK(OO, KO, pO, XO) {
      return IO((pO => function(OO, KO, pO) {
        return NO(OO, QO, KO, (async () => {
          const {
            texture: OO,
            ...XO
          } = await pO();
          return {
            image: await zK(OO),
            request: OO => ({
              type: "model",
              name: KO,
              bitmap: OO,
              geometry: XO
            })
          }
        }))
      }(pO, OO, KO)), (KO => ({
        type: "drawModel",
        id: KO,
        name: OO,
        size: pO,
        outlineWidth: XO
      })))
    }
  },
  34968: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      d: () => vK,
      f: () => lO
    });
    const XO = 1 / 32,
      bK = [15, 15, 15],
      eO = {
        top: 1,
        left: .85,
        right: .7
      };

    function lO(OO, KO, pO, bK) {
      const {
        vertices: eO,
        uvs: lO,
        indices: CO,
        shades: hO
      } = OO, DO = pO * XO, MO = pO - 2 * DO, aK = new Float32Array(eO.length);
      for (let XO = 0; XO < eO.length; XO += 3) aK[XO] = DO + eO[XO] * MO, aK[XO + 1] = DO + eO[XO + 1] * MO, aK[XO + 2] = eO[XO + 2];
      const oO = new Float32Array(pO * pO).fill(-1 / 0),
        FO = new Uint8ClampedArray(pO * pO * 4),
        VO = 255 * OO.alphaCutoff;
      for (let XO = 0; XO < CO.length; XO += 3) {
        const [OO, bK, eO] = [CO[XO], CO[XO + 1], CO[XO + 2]], [vK, DO, MO] = [3 * OO, 3 * bK, 3 * eO], [LO, QO, zK, AO, fO, dO] = [aK[vK], aK[vK + 1], aK[DO], aK[DO + 1], aK[MO], aK[MO + 1]], TO = (zK - LO) * (dO - QO) - (fO - LO) * (AO - QO);
        if (Math.abs(TO) < 1e-9) continue;
        const NO = hO[XO / 3],
          [IO, yK, gK, uO, EO, jK] = [lO[2 * OO], lO[2 * OO + 1], lO[2 * bK], lO[2 * bK + 1], lO[2 * eO], lO[2 * eO + 1]],
          YO = Math.max(0, Math.floor(Math.min(LO, zK, fO))),
          wO = Math.min(pO - 1, Math.ceil(Math.max(LO, zK, fO))),
          iK = Math.max(0, Math.floor(Math.min(QO, AO, dO))),
          rK = Math.min(pO - 1, Math.ceil(Math.max(QO, AO, dO)));
        for (let XO = iK; XO <= rK; XO++)
          for (let OO = YO; OO <= wO; OO++) {
            const [bK, eO] = [OO + .5, XO + .5], lO = ((bK - LO) * (dO - QO) - (fO - LO) * (eO - QO)) / TO, CO = ((zK - LO) * (eO - QO) - (bK - LO) * (AO - QO)) / TO, hO = 1 - lO - CO;
            if (hO < 0 || lO < 0 || CO < 0) continue;
            const YO = hO * aK[vK + 2] + lO * aK[DO + 2] + CO * aK[MO + 2],
              wO = XO * pO + OO;
            if (YO <= oO[wO]) continue;
            const iK = Math.max(0, Math.min(KO.width - 1, Math.floor((hO * IO + lO * gK + CO * EO) * KO.width))),
              rK = 4 * (Math.max(0, Math.min(KO.height - 1, Math.floor((hO * yK + lO * uO + CO * jK) * KO.height))) * KO.width + iK);
            KO.pixels[rK + 3] < VO || (oO[wO] = YO, FO[4 * wO] = KO.pixels[rK] * NO, FO[4 * wO + 1] = KO.pixels[rK + 1] * NO, FO[4 * wO + 2] = KO.pixels[rK + 2] * NO, FO[4 * wO + 3] = 255)
          }
      }
      return vK(FO, pO, bK), FO
    }

    function vK(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : KO => 0 !== OO[4 * KO + 3];
      const eO = (OO, pO) => OO < 0 || pO < 0 || OO >= KO || pO >= KO || !XO(pO * KO + OO),
        lO = [];
      for (let bK = 0; bK < KO; bK++)
        for (let OO = 0; OO < KO; OO++)
          if (!eO(OO, bK)) OO: for (let XO = -pO; XO <= pO; XO++) {
            const vK = pO - Math.abs(XO);
            for (let pO = -vK; pO <= vK; pO++)
              if (eO(OO + pO, bK + XO)) {
                lO.push(bK * KO + OO);
                break OO
              }
          }
      for (const vK of lO) OO.set(bK, 4 * vK), OO[4 * vK + 3] = 255
    }
  },
  34981: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    const XO = {
      wait: function(OO) {
        return new Promise((KO => {
          setTimeout(KO, OO)
        }))
      },
      stallMs: 2e4
    };
    class bK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : XO;
        this.url = OO, this.options = KO, this.timing = pO, this.fetched = null, this.scriptUrl = void 0, this.scriptUrl = OO
      }
      ready() {
        return this.fetched ??= this.fetchWithRetries(), this.fetched
      }
      start() {
        return new Worker(this.scriptUrl, this.options)
      }
      async fetchWithRetries() {
        for (let OO = 0;; OO++) {
          const KO = new URL(this.url);
          if (OO > 0 && KO.searchParams.set("cache-bust", `${Date.now()}-${OO}`), await this.fetchWhole(KO)) return void(this.scriptUrl = KO);
          if (OO >= 3) return;
          await this.timing.wait(500 * 2 ** OO)
        }
      }
      async fetchWhole(OO) {
        const KO = new AbortController;
        let pO;
        const XO = () => {
          clearTimeout(pO), pO = setTimeout((() => {
            KO.abort()
          }), this.timing.stallMs)
        };
        XO();
        try {
          var bK;
          const pO = await fetch(OO, {
            signal: KO.signal
          });
          if (!pO.ok) return !1;
          const eO = null === (bK = pO.body) || void 0 === bK ? void 0 : bK.getReader();
          if (!eO) return !1;
          for (;;) {
            const {
              done: OO
            } = await eO.read();
            if (OO) return !0;
            XO()
          }
        } catch {
          return !1
        } finally {
          clearTimeout(pO)
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);