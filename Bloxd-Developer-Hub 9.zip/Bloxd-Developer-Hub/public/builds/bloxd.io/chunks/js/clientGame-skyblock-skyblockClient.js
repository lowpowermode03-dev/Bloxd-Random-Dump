export const id = 24;
export const ids = [24];
export const modules = {
  35130: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      h: () => FO,
      i: () => aK,
      k: () => MO
    });
    var XO = pO(8311),
      bK = pO(35137),
      eO = pO(35139),
      lO = pO(7854),
      vK = pO(1263),
      CO = pO(63),
      hO = pO(77),
      DO = pO(976);

    function MO() {
      var OO;
      return (0, vK.h)(bK.d, (0, bK.l)()), (0, DO.jsx)(DO.Fragment, {
        children: null === (OO = (0, bK.l)()) || void 0 === OO ? void 0 : OO.content
      })
    }

    function aK(OO) {
      var KO;
      let {
        show: pO
      } = OO;
      (0, vK.h)(bK.d, (0, bK.l)());
      const hO = null === (KO = (0, bK.l)()) || void 0 === KO ? void 0 : KO.menu;
      return (0, CO.useEffect)((() => {
        var OO;
        pO || (null === hO || void 0 === hO || null === (OO = hO.onClose) || void 0 === OO || OO.call(hO), (0, eO.q)())
      }), [pO, hO]), (0, CO.useEffect)((() => pO ? (0, lO.f)(eO.y, eO.f) : void 0), [pO]), (0, DO.jsx)(XO.e, {
        showing: pO,
        globallyUniqueKey: "clientGameMenu",
        children: null === hO || void 0 === hO ? void 0 : hO.content
      })
    }

    function oO(OO) {
      let {
        placement: KO = "bottom"
      } = OO;
      return (0, DO.jsx)("div", {
        id: `clientGameHud-${KO}`,
        style: {
          display: "contents"
        }
      })
    }

    function FO(OO) {
      let {
        children: KO,
        placement: pO = "bottom"
      } = OO;
      const [XO, bK] = (0, CO.useState)(null);
      return (0, CO.useEffect)((() => {
        bK(document.getElementById(`clientGameHud-${pO}`))
      }), [pO]), XO ? (0, hO.createPortal)(KO, XO) : null
    }
  },
  3967: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => LO,
      f: () => QO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(63),
      lO = pO(1051),
      vK = pO(3969),
      CO = pO(1533),
      hO = pO(1991),
      DO = pO(3972),
      MO = pO(976);
    const aK = new WeakMap;
    let oO = 0;

    function FO(OO) {
      let KO = aK.get(OO);
      return void 0 === KO && (KO = oO++, aK.set(OO, KO)), KO
    }

    function VO(OO) {
      let {
        piece: KO
      } = OO;
      return "space" === KO.kind ? (0, MO.jsx)(MO.Fragment, {
        children: KO.text
      }) : (0, MO.jsx)("span", {
        className: "DialogueWord",
        style: {
          "--word-delay": `${KO.delayMs}ms`
        },
        children: (0, MO.jsx)(vK.b, {
          text: "icon" === KO.kind ? `[[${KO.icon}]]` : KO.text
        })
      })
    }

    function LO(OO) {
      let {
        display: KO
      } = OO;
      const {
        selectedLanguage: pO
      } = (0, lO.D)(), XO = (0, eO.useMemo)((() => (0, DO.e)((0, DO.g)(KO).plan.pieces)), [KO, pO.code]);
      return (0, MO.jsxs)("div", {
        className: bK()("Dialogue", {
          DialogueAnimateIn: !1 !== KO.animateIn
        }),
        children: [KO.speakerName && (0, MO.jsx)(CO.d, {
          text: KO.speakerName,
          className: "DialogueSpeaker"
        }), (0, MO.jsx)("p", {
          className: "DialogueLine",
          children: XO.map(((OO, KO) => 1 === OO.length && "space" === OO[0].kind ? OO[0].text : (0, MO.jsx)("span", {
            className: "DialogueGlue",
            children: OO.map(((OO, KO) => (0, MO.jsx)(VO, {
              piece: OO
            }, KO)))
          }, KO)))
        })]
      })
    }
    const QO = (0, eO.memo)((function() {
      const OO = (0, hO.i)("dialogue");
      return (0, MO.jsx)("div", {
        className: "DialogueAnchor",
        "data-camera-keeper": "",
        role: "status",
        "aria-live": "polite",
        "aria-atomic": "true",
        children: OO && (0, MO.jsx)(LO, {
          display: OO
        }, FO(OO))
      })
    }))
  },
  3969: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK
    });
    var XO = pO(63),
      bK = pO(243),
      eO = pO(1546),
      lO = pO(976);

    function vK(OO) {
      let {
        text: KO
      } = OO;
      const pO = [];
      let vK = "";
      return (0, bK.cc)(KO).forEach(((OO, KO) => {
        if ("string" === typeof OO || !(0, eO.d)(OO.icon)) return void(vK += "string" === typeof OO ? OO : OO.icon);
        const bK = Math.max(0, vK.trimEnd().search(/\S{1,12}$/));
        pO.push((0, lO.jsxs)(XO.Fragment, {
          children: [vK.slice(0, bK), (0, lO.jsxs)("span", {
            className: "InlineIconTextGlue",
            children: [vK.slice(bK), (0, lO.jsx)("span", {
              className: "InlineIconTextIcon",
              role: "img",
              "aria-label": OO.icon,
              children: (0, lO.jsx)(eO.b, {
                itemName: OO.icon,
                amount: 0
              })
            })]
          })]
        }, KO)), vK = ""
      })), pO.push(vK), (0, lO.jsx)(lO.Fragment, {
        children: pO
      })
    }
  },
  35072: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => MO,
      i: () => oO,
      k: () => aK,
      l: () => VO,
      m: () => FO,
      p: () => DO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(35075),
      vK = pO(26),
      CO = pO(1969),
      hO = pO(976);

    function DO(OO, KO) {
      const pO = (0, XO.useRef)(null);
      return (0, XO.useLayoutEffect)((() => (lO.d.set(OO, pO.current, KO), () => {
        lO.d.set(OO, null)
      })), [OO, KO]), pO
    }
    const MO = "touchKeysChanged",
      aK = {
        Crouch: "C",
        Jump: "J",
        Use: "U",
        Primary: "P",
        Attack: "A",
        Game: "G",
        Context: "X"
      },
      oO = (0, XO.forwardRef)((function(OO, KO) {
        let {
          slot: pO,
          canvasZone: bK = !1,
          lit: lO = !1,
          label: CO,
          className: DO,
          children: aK,
          ...oO
        } = OO;
        return (0, XO.useEffect)((() => (vK.i.pl(MO), () => {
          vK.i.pl(MO)
        })), []), (0, hO.jsx)("div", {
          ref: KO,
          className: eO()("TouchKeyHit", `TouchSlot${pO}`, DO, {
            CanvasZone: bK
          }),
          ...oO,
          children: (0, hO.jsxs)("div", {
            className: eO()("TouchKey", {
              Lit: lO,
              Labelled: void 0 !== CO
            }),
            children: [aK, void 0 !== CO && (0, hO.jsx)("span", {
              className: "TouchKeyLabel",
              children: CO
            })]
          })
        })
      }));

    function FO(OO, KO) {
      (0, XO.useEffect)((() => () => {
        KO.current && (KO.current = !1, (0, CO.u)(OO, !1, {
          isTrusted: !0,
          timeStamp: performance.now()
        }))
      }), [])
    }

    function VO(OO, KO) {
      const pO = KO ? [aK.Context] : [aK.Primary, aK.Context];
      return OO.filter((OO => null !== OO)).slice(0, pO.length).map(((OO, KO) => {
        const bK = pO[KO];
        return (0, hO.jsx)(XO.Fragment, {
          children: OO.render(bK)
        }, `${OO.id}:${bK}`)
      }))
    }
  },
  8311: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(3725),
      bK = pO(3730);

    function eO(OO) {
      let {
        children: KO,
        showing: pO,
        globallyUniqueKey: eO,
        alwaysMountChildren: lO = !1,
        doGameplayStartStopOnShow: vK = !0,
        keepsMovement: CO = !1
      } = OO;
      return (0, bK.b)(!0, pO, eO, CO), (0, XO.e)(vK, pO), pO || lO ? KO : null
    }
  },
  35232: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      f: () => CO
    });
    var XO = pO(63),
      bK = pO(22),
      eO = pO(1263),
      lO = pO(35072);

    function vK(OO, KO, pO) {
      let XO = null;
      for (const eO of document.querySelectorAll(".TouchComponentsButtons .TouchKeyHit")) {
        const lO = eO.getBoundingClientRect();
        var bK;
        if (lO.height > 0 && lO.top > pO && lO.left < KO && lO.right > OO) XO = Math.min(null !== (bK = XO) && void 0 !== bK ? bK : lO.top, lO.top)
      }
      return XO
    }

    function CO(OO, KO) {
      const {
        isTouchScreen: pO
      } = (0, bK.l)(["isTouchScreen"]), CO = (0, XO.useRef)(null);
      (0, eO.f)(lO.e, (() => {
        var OO;
        null === (OO = CO.current) || void 0 === OO || OO.call(CO)
      })), (0, XO.useEffect)((() => {
        const XO = null === OO || void 0 === OO ? void 0 : OO.closest(KO),
          bK = document.querySelector(".BottomRightElements");
        if (!pO || !OO || !XO || !bK) return;
        const eO = () => {
          ! function(OO, KO) {
            const pO = OO.getBoundingClientRect(),
              XO = vK(pO.left, pO.right, -1 / 0),
              bK = KO.getBoundingClientRect().bottom + parseFloat(getComputedStyle(KO).bottom),
              eO = null === XO ? "0px" : `${Math.ceil(bK-XO+4)}px`;
            KO.style.getPropertyValue("--touch-keys-reach") !== eO && KO.style.setProperty("--touch-keys-reach", eO)
          }(OO, XO)
        };
        CO.current = eO;
        const lO = new ResizeObserver(eO);
        return lO.observe(OO), lO.observe(bK), window.addEventListener("resize", eO), () => {
          CO.current = null, lO.disconnect(), window.removeEventListener("resize", eO), XO.style.setProperty("--touch-keys-reach", "0px")
        }
      }), [pO, OO, KO])
    }
  },
  3972: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => rK,
      g: () => iK
    });
    var XO = pO(3977),
      bK = pO(243);
    const eO = 120,
      lO = 260,
      vK = 1.15,
      CO = 1.2,
      hO = 2,
      DO = 1.08,
      MO = .8,
      aK = .95,
      oO = 8,
      FO = "[\"')\\]\u300d\u300f\uff09]*",
      VO = new RegExp(`[.!?\u2026\u3002\uff01\uff1f]${FO}$`),
      LO = new RegExp(`[?\uff1f]${FO}$`),
      QO = new RegExp(`[!\uff01]${FO}$`),
      zK = /[,;:\u3001\uff0c\uff1b\uff1a]$/,
      AO = "\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uac00-\\ud7af\\uf900-\\ufaff",
      fO = new RegExp(`[${AO}]`),
      dO = new RegExp(`[${AO}]|[^${AO}]+`, "g"),
      TO = /[aeiouy\u0430\u0435\u0438\u043e\u0443\u044b\u044d\u044e\u044f\u03b1\u03b5\u03b7\u03b9\u03bf\u03c5\u03c9]+/g;

    function NO(OO) {
      let KO = 2166136261;
      for (let pO = 0; pO < OO.length; pO++) KO ^= OO.charCodeAt(pO), KO = Math.imul(KO, 16777619);
      return (KO >>> 0) / 4294967295 * 2 - 1
    }

    function IO(OO) {
      var KO;
      if (fO.test(OO)) return 1;
      const pO = OO.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase(),
        XO = pO.replace(/[^0-9]/g, "");
      if (XO.length > 0 && !/\p{L}/u.test(pO)) return Math.min(XO.length, 4);
      const bK = null !== (KO = pO.match(TO)) && void 0 !== KO ? KO : [];
      if (0 === bK.length) {
        var eO, lO;
        const OO = null !== (eO = null === (lO = pO.match(/\p{L}/gu)) || void 0 === lO ? void 0 : lO.length) && void 0 !== eO ? eO : 0;
        return 0 === OO ? 0 : Math.min(Math.max(1, Math.round(OO / 2.5)), oO)
      }
      const vK = pO.replace(/[^\p{L}]/gu, ""),
        CO = bK.length > 1 && "e" === bK.at(-1) && vK.endsWith("e") && !vK.endsWith("le") && !/[\u00e9\u00e8\u00ea]$/i.test(OO.replace(/[^\p{L}]/gu, ""));
      return Math.min(bK.length - (CO ? 1 : 0), oO)
    }

    function yK(OO) {
      return OO.toLowerCase().replace(/[^\p{L}\p{N}]/gu, "")
    }

    function gK(OO) {
      const KO = OO.replace(/[^\p{L}]/gu, "");
      return KO.length >= 2 && KO === KO.toUpperCase() && KO !== KO.toLowerCase()
    }

    function uO(OO, KO) {
      var pO;
      const oO = KO && (0, XO.l)(KO),
        FO = null !== (pO = null === oO || void 0 === oO ? void 0 : oO.syllableMs) && void 0 !== pO ? pO : XO.d,
        AO = function(OO) {
          const KO = [];
          for (const XO of (0, bK.cc)(OO))
            if ("string" === typeof XO)
              for (const OO of XO.split(/(\s+)/)) {
                if ("" === OO) continue;
                if (/^\s+$/.test(OO)) {
                  KO.push({
                    kind: "space",
                    text: OO
                  });
                  continue
                }
                if (!fO.test(OO)) {
                  KO.push({
                    kind: "word",
                    text: OO,
                    delayMs: 0
                  });
                  continue
                }
                let XO = !0;
                for (const bK of null !== (pO = OO.match(dO)) && void 0 !== pO ? pO : []) {
                  var pO;
                  const OO = KO.at(-1);
                  XO || "word" !== (null === OO || void 0 === OO ? void 0 : OO.kind) || fO.test(bK) || /[\p{L}\p{N}]/u.test(bK) ? (XO || KO.push({
                    kind: "space",
                    text: "\u200b"
                  }), KO.push({
                    kind: "word",
                    text: bK,
                    delayMs: 0
                  }), XO = !1) : OO.text += bK
                }
              } else KO.push({
                kind: "icon",
                text: XO.icon,
                delayMs: 0
              });
          return KO
        }(OO),
        TO = [];
      let uO = [];
      for (const XO of AO) "space" !== XO.kind && (uO.push(XO), VO.test(XO.text) && (TO.push(uO), uO = []));
      TO.push(uO);
      const EO = [];
      let jK = 0;
      for (const XO of TO) {
        var YO, wO;
        const OO = null !== (YO = null === (wO = XO.at(-1)) || void 0 === wO ? void 0 : wO.text) && void 0 !== YO ? YO : "",
          KO = LO.test(OO),
          pO = QO.test(OO),
          bK = XO.map((OO => "word" === OO.kind ? IO(OO.text) : 1)),
          AO = bK.findLastIndex((OO => OO > 0));
        for (const [LO, QO] of XO.entries()) {
          const OO = "word" === QO.kind,
            XO = bK[LO];
          QO.delayMs = jK;
          for (let bK = 0; oO && bK < XO; bK++) {
            const {
              intonation: eO
            } = oO;
            let lO = AO > 0 ? -eO.declineSemitones * (LO / AO) : 0;
            lO += NO(`${yK(QO.text)}|${bK}`) * eO.variationSemitones;
            const VO = Math.min(1, eO.variationSemitones);
            let zK = oO.glideSemitones,
              fO = 1;
            pO && (lO += eO.exclaimLiftSemitones, fO *= vK), KO && LO === AO && (lO += eO.questionRiseSemitones * (XO > 1 ? .5 + .5 * bK / (XO - 1) : 1), bK === XO - 1 && (zK = Math.abs(zK) + eO.questionRiseSemitones / 2)), OO && gK(QO.text) && (lO += hO * VO, fO *= CO), XO > 1 && 0 === bK && (lO += MO * VO, fO *= DO), EO.push({
              atMs: jK + bK * FO,
              semitones: lO,
              glideSemitones: zK,
              durationMs: bK < XO - 1 ? Math.min(oO.durationMs, FO * aK) : oO.durationMs,
              level: fO
            })
          }
          jK += XO * FO + (VO.test(QO.text) ? lO : zK.test(QO.text) ? eO : 0)
        }
      }
      return {
        pieces: AO.map((OO => "space" === OO.kind ? OO : "icon" === OO.kind ? {
          kind: "icon",
          icon: OO.text,
          delayMs: OO.delayMs
        } : {
          kind: "word",
          text: OO.text,
          delayMs: OO.delayMs
        })),
        blips: EO
      }
    }
    var EO = pO(1051),
      jK = pO(1109),
      YO = pO(1558);

    function wO(OO) {
      if ("string" === typeof OO) return OO;
      const KO = jK.f.get().getCurrentLanguageCode();
      return (0, EO.s)(KO, OO.translationKey, (0, EO.q)(OO.params, YO.c.shown))
    }

    function iK(OO) {
      const KO = void 0 === OO.voice ? null : (0, XO.m)(OO.voice),
        pO = KO && (0, XO.l)(KO);
      return {
        plan: uO(wO(OO.line), pO),
        synth: pO
      }
    }

    function rK(OO) {
      const KO = [];
      let pO = [];
      for (const [bK, eO] of OO.entries()) {
        var XO;
        "space" === eO.kind && (" " !== eO.text || "icon" !== (null === (XO = OO[bK + 1]) || void 0 === XO ? void 0 : XO.kind)) ? (pO.length > 0 && KO.push(pO), KO.push([eO]), pO = []) : pO.push(eO)
      }
      return pO.length > 0 && KO.push(pO), KO
    }
  },
  7854: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      f: () => bK
    });
    let XO = null;
    const bK = function(OO) {
        const KO = {
          cycle: OO,
          canCycle: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => !0
        };
        return XO = KO, () => {
          XO === KO && (XO = null)
        }
      },
      eO = () => {
        var OO;
        return null !== (OO = XO) && void 0 !== OO && OO.canCycle() ? XO.cycle : null
      }
  },
  35139: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => zK,
      c: () => eO,
      f: () => VO,
      i: () => LO,
      m: () => vK,
      n: () => aK,
      q: () => QO,
      s: () => MO,
      u: () => AO,
      y: () => FO
    });
    var XO = pO(22),
      bK = pO(26);
    const eO = "clientGameInventoryButtonsChanged",
      lO = new Map;

    function vK() {
      return [...lO.values()].sort(((OO, KO) => {
        var pO, XO;
        return (null !== (pO = OO.order) && void 0 !== pO ? pO : 0) - (null !== (XO = KO.order) && void 0 !== XO ? XO : 0)
      }))
    }
    let CO = null;

    function hO(OO) {
      CO = OO
    }
    let DO = !1;

    function MO(OO) {
      DO = !0;
      try {
        OO.onClick()
      } finally {
        DO = !1
      }
      OO.panel && "clientGame" === XO.d.get("openInGameMenuName") && hO(OO.id)
    }

    function aK() {
      return DO
    }

    function oO() {
      return vK().filter((OO => OO.panel && !OO.disabled))
    }

    function FO(OO) {
      const KO = oO(),
        pO = KO.findIndex((OO => OO.id === CO));
      return !(pO < 0 || KO.length < 2) && (MO(KO[(pO + OO + KO.length) % KO.length]), !0)
    }

    function VO() {
      return null !== CO && oO().length > 1
    }

    function LO() {
      hO(null)
    }

    function QO() {
      "inventory" !== XO.d.get("openInGameMenuName") && hO(null)
    }

    function zK() {
      const OO = CO;
      return hO(null), OO
    }

    function AO(OO) {
      return lO.set(OO.id, OO), bK.i.pl(eO, vK(), !0), () => {
        lO.get(OO.id) === OO && (lO.delete(OO.id), bK.i.pl(eO, vK()))
      }
    }
  },
  35137: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      g: () => LO,
      j: () => QO,
      k: () => aK,
      l: () => hO,
      o: () => VO,
      p: () => oO,
      q: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(1136),
      lO = pO(35139);
    const vK = "clientGameUiChanged";
    let CO = null;

    function hO() {
      return CO
    }

    function DO(OO, KO) {
      const pO = {
        content: OO,
        menu: KO
      };
      return CO = pO, bK.i.pl(vK, CO, !0), () => {
        CO === pO && (CO = null, FO = !1, LO(), bK.i.pl(vK, null))
      }
    }
    let MO = null;

    function aK() {
      return MO
    }

    function oO(OO) {
      return MO = OO, () => {
        MO === OO && (MO = null)
      }
    }
    let FO = !1;

    function VO() {
      const OO = XO.d.get("openInGameMenuName");
      "clientGame" !== OO && (FO = "inventory" === OO), (0, lO.n)() || (0, lO.i)(), (0, eO.k)("InGameMenu"), XO.d.set({
        openInGameMenuName: "clientGame",
        openEverythingMenuName: null
      })
    }

    function LO() {
      zK(!1)
    }

    function QO() {
      zK(FO)
    }

    function zK(OO) {
      "clientGame" === XO.d.get("openInGameMenuName") && XO.d.set({
        openInGameMenuName: OO ? "inventory" : null
      }), OO || (0, lO.i)(), FO = !1
    }
  },
  36902: (OO, KO, pO) => {
    function XO(OO, KO, pO) {
      const XO = new Set,
        bK = new ResizeObserver(pO),
        eO = () => {
          const KO = new Set(document.querySelectorAll(OO));
          let eO = !1;
          for (const OO of XO) KO.has(OO) || (bK.unobserve(OO), XO.delete(OO), eO = !0);
          for (const OO of KO) XO.has(OO) || (bK.observe(OO), lO.observe(OO, {
            attributes: !0,
            attributeFilter: ["class", "style"]
          }), XO.add(OO));
          eO && pO()
        },
        lO = new MutationObserver((KO => {
          KO.some((OO => "attributes" === OO.type)) && pO(), KO.some((KO => function(OO, KO, pO) {
            if ("childList" !== OO.type) return !1;
            for (const XO of OO.addedNodes)
              if (XO instanceof Element && (XO.matches(KO) || XO.querySelector(KO))) return !0;
            for (const XO of OO.removedNodes)
              if (XO instanceof Element)
                for (const OO of pO)
                  if (XO.contains(OO)) return !0;
            return !1
          }(KO, OO, XO))) && eO()
        }));
      lO.observe(document.body, {
        childList: !0,
        subtree: !0
      });
      for (const vK of KO) bK.observe(vK);
      return window.addEventListener("resize", pO), eO(), pO(), () => {
        bK.disconnect(), lO.disconnect(), window.removeEventListener("resize", pO)
      }
    }
    pO.d(KO, {
      d: () => XO
    })
  },
  7952: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      f: () => CO
    });
    var XO = pO(22),
      bK = pO(1163),
      eO = pO(94);
    const lO = {
      blockMined: {
        pattern: [18],
        priority: 1,
        minGapMs: 120
      },
      hitLanded: {
        pattern: [20],
        priority: 2,
        minGapMs: 80
      },
      damageTaken: {
        pattern: [45],
        priority: 3,
        minGapMs: 250
      },
      fishBite: {
        pattern: null,
        priority: 3,
        minGapMs: 0
      },
      death: {
        pattern: [60, 70, 120],
        priority: 4,
        minGapMs: 0
      },
      lockReady: {
        pattern: [8],
        priority: 2,
        minGapMs: 0
      },
      lockLocked: {
        pattern: [15, 50, 15],
        priority: 2,
        minGapMs: 0
      },
      autorunLedgeStop: {
        pattern: [40],
        priority: 3,
        minGapMs: 0
      }
    };

    function vK() {
      return (0, eO.isMobile)() && "function" === typeof navigator.vibrate
    }
    const CO = new class {
      constructor(OO) {
        this.deps = OO, this.lastAt = new Map, this.lastAnyAt = -1 / 0, this.playingUntil = -1 / 0, this.playingPriority = 0
      }
      play(OO, KO) {
        var pO;
        if (!this.deps.enabled()) return;
        const XO = lO[OO],
          bK = null !== KO && void 0 !== KO ? KO : XO.pattern;
        if (null === bK) return void console.warn("No vibration pattern for", OO);
        const eO = this.deps.now();
        eO - this.lastAnyAt < 40 && XO.priority < this.playingPriority || eO - (null !== (pO = this.lastAt.get(OO)) && void 0 !== pO ? pO : -1 / 0) < XO.minGapMs || eO < this.playingUntil && XO.priority < this.playingPriority || (this.lastAt.set(OO, eO), this.lastAnyAt = eO, this.playingUntil = eO + bK.reduce(((OO, KO) => OO + KO), 0), this.playingPriority = XO.priority, this.deps.vibrate(bK))
      }
    }({
      vibrate: OO => {
        navigator.vibrate([...OO])
      },
      now: () => performance.now(),
      enabled: () => vK() && XO.d.get("isTouchScreen") && XO.d.get("clientEscMenuOptions").vibration && !(0, bK.f)()
    })
  },
  35966: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK,
      g: () => lO
    });
    var XO = pO(35959),
      bK = pO(256),
      eO = pO(1531);

    function lO(OO) {
      if ("w6" in OO) return TO.createAnimationScript(OO);
      return new hO(OO).createAnimationScript()
    }

    function vK(OO, KO, pO, bK) {
      const eO = OO.w6 <= 0 ? 1 : KO + pO * Math.max(0, bK) / OO.w6;
      return OO.i4 === XO.j.LoopOnLastFrame ? eO % 1 : OO.i4 === XO.j.NoLoop && eO >= 1 ? null : Math.min(1, eO)
    }
    class CO {
      createAnimationScript(OO) {
        const {
          w6: KO,
          loop: pO,
          r4: XO
        } = OO;
        return {
          w6: Math.round(KO),
          i4: this.createLoopMode(null !== pO && void 0 !== pO && pO),
          r4: this.createNodeSkeletonAnimationScript(null !== XO && void 0 !== XO ? XO : null)
        }
      }
      createLoopMode(OO) {
        switch (OO) {
          case !1:
            return XO.j.NoLoop;
          case !0:
            return XO.j.LoopOnLastFrame;
          case "hold-on-last-frame":
            return XO.j.HoldOnLastFrame
        }
        throw new Error(`Invalid loop mode schema: ${OO}`)
      }
      createNodeSkeletonAnimationScript(OO) {
        if (null === OO) return null;
        const KO = {};
        for (const pO in OO) {
          const XO = OO[pO];
          KO[pO] = this.createNodeAnimationScript(XO)
        }
        return KO
      }
      createNodeAnimationScript(OO) {
        const {
          timeline: KO
        } = OO, pO = KO.filter((OO => Number.isFinite(OO.timeFraction)));
        return pO.sort(((OO, KO) => OO.timeFraction - KO.timeFraction)), {
          rotation: this.createTimelineFromKeyframes(pO, "rotation", aK),
          position: this.createTimelineFromKeyframes(pO, "position", FO)
        }
      }
      createTimelineFromKeyframes(OO, KO, pO) {
        const XO = [];
        for (const CO of OO) {
          const OO = CO[KO];
          if (OO) {
            const KO = this.createAnimationFrameWithoutPrecomputes(CO.timeFraction, OO);
            DO(KO) && XO.push(KO)
          }
        }
        const bK = [];
        for (let CO = 0; CO < XO.length; CO++) {
          var eO, lO, vK;
          const OO = XO[CO],
            KO = null !== (eO = XO[CO - 1]) && void 0 !== eO ? eO : OO,
            hO = null !== (lO = XO[CO + 1]) && void 0 !== lO ? lO : OO,
            DO = null !== (vK = XO[CO + 2]) && void 0 !== vK ? vK : hO;
          bK.push({
            ...OO,
            ...pO(KO.post, KO.timeFraction, OO.post, OO.timeFraction, hO.pre, hO.timeFraction, DO.pre, DO.timeFraction)
          })
        }
        return bK
      }
      createAnimationFrameWithoutPrecomputes(OO, KO) {
        let pO, XO, bK = null;
        var eO;
        if ("object" === typeof KO && "point" in KO) bK = null !== (eO = KO.U6) && void 0 !== eO ? eO : null, pO = KO.point, XO = KO.point;
        else if ("object" === typeof KO && "pre" in KO) {
          var lO;
          bK = null !== (lO = KO.U6) && void 0 !== lO ? lO : null, pO = KO.pre, XO = KO.post
        } else pO = KO, XO = KO;
        return {
          timeFraction: OO,
          U6: this.createLerpMode(bK),
          pre: pO,
          post: XO
        }
      }
      createLerpMode(OO) {
        return null === OO ? XO.i.Linear : CO.LERP_MODE_SCHEMA_MAPPING[OO]
      }
    }
    CO.LERP_MODE_SCHEMA_MAPPING = {
      linear: XO.i.Linear,
      "catmull-rom-spline": XO.i.CatmullRomSpline
    };
    class hO {
      constructor(OO) {
        this.animationSchema = OO
      }
      createAnimationScript() {
        const {
          animation_length: OO,
          loop: KO,
          bones: pO
        } = this.animationSchema;
        return {
          w6: Math.round(1e3 * OO),
          i4: this.createLoopMode(null !== KO && void 0 !== KO && KO),
          r4: this.createNodeSkeletonAnimationScript(null !== pO && void 0 !== pO ? pO : null)
        }
      }
      createLoopMode(OO) {
        switch (OO) {
          case !1:
            return XO.j.NoLoop;
          case !0:
            return XO.j.LoopOnLastFrame;
          case "hold_on_last_frame":
            return XO.j.HoldOnLastFrame
        }
        throw new Error(`Invalid Blockbench loop mode schema: ${OO}`)
      }
      createNodeSkeletonAnimationScript(OO) {
        if (null === OO) return null;
        const KO = {};
        for (const pO in OO) {
          const XO = OO[pO];
          KO[pO] = this.createNodeAnimationScript(XO)
        }
        return KO
      }
      createNodeAnimationScript(OO) {
        const {
          rotation: KO,
          position: pO
        } = OO;
        return {
          rotation: this.createAnimationTimeline(null !== KO && void 0 !== KO ? KO : null, LO, aK, !0),
          position: this.createAnimationTimeline(null !== pO && void 0 !== pO ? pO : null, zK, FO, !1)
        }
      }
      createAnimationTimeline(OO, KO, pO, XO) {
        if (null === OO) return [];
        if (Array.isArray(OO)) {
          OO = {
            "0.0": OO
          }
        }
        const bK = Object.entries(OO).map((OO => {
          let [pO, XO] = OO;
          const bK = Number(pO) / this.animationSchema.animation_length;
          return this.createAnimationFrameWithoutPrecomputes(bK, XO, KO)
        })).filter(DO);
        bK.sort(((OO, KO) => OO.timeFraction - KO.timeFraction)), XO && function(OO) {
          for (let KO = 1; KO < OO.length; KO++) {
            const pO = OO[KO - 1].post,
              XO = OO[KO],
              bK = AO(XO.pre),
              eO = AO(XO.post),
              lO = dO(pO, XO.pre);
            dO(pO, bK) < lO && (OO[KO] = {
              ...XO,
              pre: bK,
              post: eO
            })
          }
        }(bK);
        const eO = [];
        for (let hO = 0; hO < bK.length; hO++) {
          var lO, vK, CO;
          const OO = bK[hO],
            KO = null !== (lO = bK[hO - 1]) && void 0 !== lO ? lO : OO,
            XO = null !== (vK = bK[hO + 1]) && void 0 !== vK ? vK : OO,
            DO = null !== (CO = bK[hO + 2]) && void 0 !== CO ? CO : XO;
          eO.push({
            ...OO,
            ...pO(KO.post, KO.timeFraction, OO.post, OO.timeFraction, XO.pre, XO.timeFraction, DO.pre, DO.timeFraction)
          })
        }
        return eO
      }
      createAnimationFrameWithoutPrecomputes(OO, KO, pO) {
        let XO, bK, eO = null;
        if ("object" === typeof KO && "post" in KO) {
          var lO;
          eO = null !== (lO = KO.lerp_mode) && void 0 !== lO ? lO : null, bK = VO(KO.post, pO), XO = KO.pre ? VO(KO.pre, pO) : bK
        } else {
          const OO = VO(KO, pO);
          bK = OO, XO = OO
        }
        return {
          timeFraction: OO,
          U6: this.createLerpMode(eO),
          pre: XO,
          post: bK
        }
      }
      createLerpMode(OO) {
        return null === OO ? XO.i.Linear : hO.LERP_MODE_SCHEMA_MAPPING[OO]
      }
    }

    function DO(OO) {
      return Number.isFinite(OO.timeFraction) && MO(OO.pre) && MO(OO.post)
    }

    function MO(OO) {
      return Number.isFinite(OO[0]) && Number.isFinite(OO[1]) && Number.isFinite(OO[2])
    }

    function aK(OO, KO, pO, XO, bK, eO, lO, vK) {
      const CO = eO - KO,
        hO = eO - XO,
        DO = vK - XO,
        MO = [null, null, null];
      for (let aK = 0; aK < MO.length; aK++) MO[aK] = oO(OO[aK], pO[aK], bK[aK], lO[aK], CO, DO);
      return {
        O4: hO,
        K4: MO
      }
    }

    function oO(OO, KO, pO, XO, eO, lO) {
      return {
        B4: bK.e.computeShortestRotation(OO, pO) / eO,
        Z4: bK.e.computeShortestRotation(KO, XO) / lO,
        delta: bK.e.computeShortestRotation(KO, pO)
      }
    }

    function FO(OO, KO, pO, XO, bK, eO, lO, vK) {
      const CO = eO - KO,
        hO = eO - XO,
        DO = vK - XO,
        MO = [null, null, null];
      for (let aK = 0; aK < MO.length; aK++) MO[aK] = {
        B4: (bK[aK] - OO[aK]) / CO,
        Z4: (lO[aK] - pO[aK]) / DO,
        delta: bK[aK] - pO[aK]
      };
      return {
        O4: hO,
        K4: MO
      }
    }

    function VO(OO, KO) {
      return null === KO ? OO : KO(OO)
    }

    function LO(OO) {
      const [KO, pO, XO] = OO, lO = -(0, eO.n)(KO), vK = -(0, eO.n)(pO), CO = (0, eO.n)(XO), hO = bK.e.quaternionFromEulerZYX(lO, vK, CO);
      return bK.e.eulerYXZFromQuaternion(hO)
    }
    hO.LERP_MODE_SCHEMA_MAPPING = {
      linear: XO.i.Linear,
      catmullrom: XO.i.CatmullRomSpline
    };
    const QO = 1 / 16;

    function zK(OO) {
      return [-OO[0] * QO, OO[1] * QO, OO[2] * QO]
    }

    function AO(OO) {
      const [KO, pO, XO] = OO;
      return [KO >= 0 ? Math.PI - KO : -Math.PI - KO, fO(pO + Math.PI), fO(XO + Math.PI)]
    }

    function fO(OO) {
      return bK.e.mod(OO + Math.PI, 2 * Math.PI) - Math.PI
    }

    function dO(OO, KO) {
      return Math.abs(bK.e.computeShortestRotation(OO[0], KO[0])) + Math.abs(bK.e.computeShortestRotation(OO[1], KO[1])) + Math.abs(bK.e.computeShortestRotation(OO[2], KO[2]))
    }
    const TO = new CO
  },
  35959: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      f: () => eO,
      i: () => XO,
      j: () => bK
    });
    let XO = function(OO) {
        return OO[OO.Linear = 0] = "Linear", OO[OO.CatmullRomSpline = 1] = "CatmullRomSpline", OO
      }({}),
      bK = function(OO) {
        return OO[OO.NoLoop = 0] = "NoLoop", OO[OO.LoopOnLastFrame = 1] = "LoopOnLastFrame", OO[OO.HoldOnLastFrame = 2] = "HoldOnLastFrame", OO
      }({}),
      eO = function(OO) {
        return OO[OO.Movement = 0] = "Movement", OO[OO.Action = 1] = "Action", OO[OO.Emote = 2] = "Emote", OO[OO.Custom = 3] = "Custom", OO
      }({}),
      lO = function(OO) {
        return OO[OO.Start = 0] = "Start", OO[OO.Stop = 1] = "Stop", OO
      }({})
  },
  3977: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      g: () => XO,
      k: () => eO,
      l: () => CO,
      m: () => lO
    });
    const XO = ["sine", "triangle", "square", "sawtooth"],
      bK = 55,
      eO = {
        soft: {
          waveform: "sine",
          pitchHz: 300,
          glideSemitones: -.5,
          durationMs: 80,
          attackMs: 6,
          releaseMs: 18,
          lowpassHz: null,
          volume: .6,
          intonation: {
            variationSemitones: 1.2,
            declineSemitones: 1.5,
            questionRiseSemitones: 3.5,
            exclaimLiftSemitones: 1.5
          },
          syllableMs: 60
        },
        regular: {
          waveform: "triangle",
          pitchHz: 195,
          glideSemitones: -.6,
          durationMs: 70,
          attackMs: 2,
          releaseMs: 12,
          lowpassHz: null,
          volume: 1,
          intonation: {
            variationSemitones: 1.5,
            declineSemitones: 2,
            questionRiseSemitones: 4,
            exclaimLiftSemitones: 2
          },
          syllableMs: 52
        },
        dark: {
          waveform: "sawtooth",
          pitchHz: 80,
          glideSemitones: -.6,
          durationMs: 85,
          attackMs: 6,
          releaseMs: 16,
          lowpassHz: 420,
          volume: 1.05,
          intonation: {
            variationSemitones: 1,
            declineSemitones: 3.5,
            questionRiseSemitones: 2.5,
            exclaimLiftSemitones: 1
          },
          syllableMs: 64
        },
        "high-pitched": {
          waveform: "triangle",
          pitchHz: 300,
          glideSemitones: -.8,
          durationMs: 55,
          attackMs: 2,
          releaseMs: 10,
          lowpassHz: null,
          volume: .8,
          intonation: {
            variationSemitones: 2.2,
            declineSemitones: 2,
            questionRiseSemitones: 5,
            exclaimLiftSemitones: 3
          },
          syllableMs: 44
        },
        gruff: {
          waveform: "sawtooth",
          pitchHz: 105,
          glideSemitones: -.8,
          durationMs: 75,
          attackMs: 4,
          releaseMs: 14,
          lowpassHz: 900,
          volume: .85,
          intonation: {
            variationSemitones: 1.2,
            declineSemitones: 3,
            questionRiseSemitones: 3,
            exclaimLiftSemitones: 2
          },
          syllableMs: 58
        },
        lively: {
          waveform: "square",
          pitchHz: 230,
          glideSemitones: .6,
          durationMs: 55,
          attackMs: 2,
          releaseMs: 10,
          lowpassHz: 2400,
          volume: .5,
          intonation: {
            variationSemitones: 2.6,
            declineSemitones: 1.5,
            questionRiseSemitones: 5,
            exclaimLiftSemitones: 3.5
          },
          syllableMs: 44
        },
        posh: {
          waveform: "triangle",
          pitchHz: 175,
          glideSemitones: 1.2,
          durationMs: 90,
          attackMs: 6,
          releaseMs: 20,
          lowpassHz: 2e3,
          volume: 1,
          intonation: {
            variationSemitones: 2,
            declineSemitones: 4,
            questionRiseSemitones: 5,
            exclaimLiftSemitones: 2.5
          },
          syllableMs: 60
        },
        mechanical: {
          waveform: "square",
          pitchHz: 140,
          glideSemitones: 0,
          durationMs: 60,
          attackMs: 0,
          releaseMs: 4,
          lowpassHz: 1400,
          volume: .55,
          intonation: {
            variationSemitones: 0,
            declineSemitones: 0,
            questionRiseSemitones: 0,
            exclaimLiftSemitones: 0
          },
          syllableMs: 62
        }
      };

    function lO(OO) {
      return "string" !== typeof OO ? OO : Object.hasOwn(eO, OO) ? eO[OO] : null
    }

    function vK(OO, KO, pO) {
      return Math.min(pO, Math.max(KO, OO))
    }

    function CO(OO) {
      const KO = vK(OO.durationMs, 10, 500),
        pO = vK(OO.attackMs, 0, KO),
        {
          intonation: bK
        } = OO;
      return {
        waveform: XO.includes(OO.waveform) ? OO.waveform : "sine",
        pitchHz: vK(OO.pitchHz, 20, 4e3),
        glideSemitones: vK(OO.glideSemitones, -24, 24),
        durationMs: KO,
        attackMs: pO,
        releaseMs: vK(OO.releaseMs, 0, KO - pO),
        lowpassHz: null === OO.lowpassHz ? null : vK(OO.lowpassHz, 20, 2e4),
        volume: vK(OO.volume, 0, 2),
        intonation: {
          variationSemitones: vK(bK.variationSemitones, 0, 6),
          declineSemitones: vK(bK.declineSemitones, 0, 12),
          questionRiseSemitones: vK(bK.questionRiseSemitones, 0, 12),
          exclaimLiftSemitones: vK(bK.exclaimLiftSemitones, 0, 12)
        },
        syllableMs: vK(OO.syllableMs, 25, 200)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);