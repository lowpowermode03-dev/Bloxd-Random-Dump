export const id = 27;
export const ids = [27];
export const modules = {
  7319: (OO, KO, pO) => {
    var XO = {
      "./nintendo/A.svg": 7325,
      "./nintendo/B.svg": 7330,
      "./nintendo/Down.svg": 7337,
      "./nintendo/Home.svg": 7345,
      "./nintendo/LB.svg": 7347,
      "./nintendo/LS.svg": 7354,
      "./nintendo/LT.svg": 7362,
      "./nintendo/Left.svg": 7369,
      "./nintendo/LeftStick.svg": 7373,
      "./nintendo/Menu.svg": 7379,
      "./nintendo/RB.svg": 7388,
      "./nintendo/RS.svg": 7392,
      "./nintendo/RT.svg": 7396,
      "./nintendo/Right.svg": 7400,
      "./nintendo/RightStick.svg": 7405,
      "./nintendo/Up.svg": 7412,
      "./nintendo/View.svg": 7416,
      "./nintendo/X.svg": 7419,
      "./nintendo/Y.svg": 7422,
      "./playstation/A.svg": 7431,
      "./playstation/B.svg": 7438,
      "./playstation/Down.svg": 7445,
      "./playstation/Home.svg": 7448,
      "./playstation/LB.svg": 7455,
      "./playstation/LS.svg": 7461,
      "./playstation/LT.svg": 7464,
      "./playstation/Left.svg": 7471,
      "./playstation/LeftStick.svg": 7480,
      "./playstation/Menu.svg": 7487,
      "./playstation/RB.svg": 7490,
      "./playstation/RS.svg": 7492,
      "./playstation/RT.svg": 7498,
      "./playstation/Right.svg": 7507,
      "./playstation/RightStick.svg": 7509,
      "./playstation/Up.svg": 7516,
      "./playstation/View.svg": 7519,
      "./playstation/X.svg": 7521,
      "./playstation/Y.svg": 7530,
      "./steamdeck/A.svg": 7534,
      "./steamdeck/B.svg": 7537,
      "./steamdeck/Down.svg": 7545,
      "./steamdeck/Home.svg": 7549,
      "./steamdeck/LB.svg": 7553,
      "./steamdeck/LS.svg": 7560,
      "./steamdeck/LT.svg": 7565,
      "./steamdeck/Left.svg": 7567,
      "./steamdeck/LeftStick.svg": 7571,
      "./steamdeck/Menu.svg": 7579,
      "./steamdeck/RB.svg": 7581,
      "./steamdeck/RS.svg": 7585,
      "./steamdeck/RT.svg": 7587,
      "./steamdeck/Right.svg": 7596,
      "./steamdeck/RightStick.svg": 7599,
      "./steamdeck/Up.svg": 7603,
      "./steamdeck/View.svg": 7608,
      "./steamdeck/X.svg": 7616,
      "./steamdeck/Y.svg": 7622,
      "./xbox/A.svg": 7628,
      "./xbox/B.svg": 7637,
      "./xbox/Down.svg": 7639,
      "./xbox/Home.svg": 7648,
      "./xbox/LB.svg": 7654,
      "./xbox/LS.svg": 7662,
      "./xbox/LT.svg": 7669,
      "./xbox/Left.svg": 7677,
      "./xbox/LeftStick.svg": 7686,
      "./xbox/Menu.svg": 7689,
      "./xbox/RB.svg": 7697,
      "./xbox/RS.svg": 7704,
      "./xbox/RT.svg": 7708,
      "./xbox/Right.svg": 7715,
      "./xbox/RightStick.svg": 7723,
      "./xbox/Up.svg": 7730,
      "./xbox/View.svg": 7735,
      "./xbox/X.svg": 7738,
      "./xbox/Y.svg": 7744
    };

    function bK(OO) {
      var KO = eO(OO);
      return pO(KO)
    }

    function eO(OO) {
      if (!pO.o(XO, OO)) {
        var KO = new Error("Cannot find module '" + OO + "'");
        throw KO.code = "MODULE_NOT_FOUND", KO
      }
      return XO[OO]
    }
    bK.keys = function() {
      return Object.keys(XO)
    }, bK.resolve = eO, OO.exports = bK, bK.id = 7319
  },
  7872: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => YO,
      g: () => gK,
      h: () => uO
    });
    var XO = pO(63),
      bK = pO(3730),
      eO = pO(1004),
      lO = pO(1263),
      vK = pO(26),
      CO = pO(2692),
      hO = pO(1811),
      DO = pO(1098),
      MO = pO(7899),
      aK = pO(1556),
      oO = pO(1583),
      FO = pO(1051),
      VO = pO(22),
      LO = pO(1441),
      QO = pO(918),
      zK = pO.n(QO),
      AO = pO(7875),
      fO = pO(7880),
      dO = pO(7886),
      TO = pO(7847),
      NO = pO(7893),
      IO = (pO(7896), pO(976));
    let yK = null;

    function gK() {
      return null !== yK
    }

    function uO() {
      return "pad" === yK
    }

    function EO() {
      return "inGame" === VO.d.get("gameState") && !(0, LO.i)()
    }

    function jK(OO) {
      return (0, fO.v)(OO, DO.m, fO.g, fO.k, fO.n)
    }
    const YO = (0, XO.memo)((function() {
      const {
        t: OO
      } = (0, FO.D)(), {
        userContext: KO
      } = (0, eO.d)(), [pO, VO] = (0, XO.useState)(null), [QO, gK] = (0, XO.useState)(null), uO = (0, XO.useRef)(null), YO = (0, XO.useCallback)((OO => {
        uO.current = OO, gK(OO)
      }), []), wO = (0, XO.useRef)(0), iK = (0, XO.useRef)(null), rK = (0, XO.useRef)({
        x: 0,
        y: 0
      }), [PO, mK] = (0, XO.useState)(0), sO = (0, XO.useMemo)((() => function(OO) {
        const KO = [];
        for (let XO = 0; XO < DO.m; XO++) {
          var pO;
          KO.push(null !== (pO = OO[XO]) && void 0 !== pO ? pO : null)
        }
        return KO
      }((0, MO.h)(KO.getPlayerCosmetics().emote))), [KO, PO]);
      (0, oO.b)("cosmeticsUpdated", (OO => {
        OO.some((OO => OO.local && "emote" === OO.oV)) && mK((OO => OO + 1))
      }));
      const HO = (0, XO.useRef)(!1),
        RO = (0, XO.useCallback)((function(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          "pad" === OO && (0, dO.e)(), HO.current = KO, rK.current = {
            x: 0,
            y: 0
          }, YO(null), VO(OO)
        }), [YO]),
        SO = (0, XO.useCallback)((() => {
          VO(null), YO(null), rK.current = {
            x: 0,
            y: 0
          }
        }), [YO]),
        JO = (0, XO.useCallback)((OO => {
          if (Date.now() < wO.current) return;
          const KO = (0, hO.j)(OO),
            pO = !!KO.holdUntilMove,
            XO = pO ? 600 : Math.ceil(1e3 * KO.animation.animation_length / hO.d) + 200;
          wO.current = Date.now() + XO, iK.current = OO, aK.gameBridge.send("playEmote", OO), aK.gameBridge.send("applyTemporaryThirdPerson", pO ? {} : {
            durationMs: XO
          })
        }), []);
      (0, lO.f)("requestToggleEmoteWheel", (() => {
        null === pO ? EO() && RO("click") : SO()
      })), (0, lO.f)("requestEmoteWheelHoldOpen", (() => {
        null === pO && EO() && RO((0, AO.b)() ? "hold" : "click")
      })), (0, lO.f)("requestEmoteWheelPadOpen", (OO => {
        null !== pO || !EO() || (0, TO.b)() || (0, NO.o)() || RO("pad", OO)
      })), (0, lO.f)("requestEmoteRepeatLast", (() => {
        if (null !== pO || !EO() || (0, TO.b)() || (0, NO.o)()) return;
        const OO = iK.current;
        null !== OO && sO.includes(OO) ? JO(OO) : RO("pad", !0)
      }));
      const cK = () => {
        const OO = uO.current,
          KO = null !== OO ? sO[OO] : null;
        null !== KO && "pad" === pO && Date.now() < wO.current || (SO(), null !== KO && JO(KO))
      };
      (0, lO.f)("emoteWheelPadAim", (OO => {
        if ("pad" !== pO) return;
        const KO = (0, fO.H)(OO, DO.m, uO.current);
        YO(null !== KO && null !== sO[KO] ? KO : null)
      })), (0, lO.f)("requestEmoteWheelPadCommit", (OO => {
        "pad" !== pO || OO && HO.current || cK()
      })), (0, lO.f)("appManagerUpdated|activeInputDevice", (OO => {
        null !== pO && "pad" === pO !== ("gamepad" === OO) && SO()
      })), (0, XO.useLayoutEffect)((() => (yK = pO, (0, CO.r)("emoteWheel", "pad" === pO), vK.i.pl(CO.i), () => {
        yK = null, (0, CO.r)("emoteWheel", !1), vK.i.pl(CO.i)
      })), [pO]), (0, lO.f)("requestEmoteWheelHoldRelease", (() => {
        "hold" === pO && cK()
      })), (0, lO.f)("requestEmoteWheelClose", (() => {
        null !== pO && SO()
      })), (0, lO.f)("appManagerUpdated|gameState", (OO => {
        "inGame" !== OO && SO()
      }));
      const BO = () => {
        (0, LO.i)() && SO()
      };
      if ((0, lO.f)("appManagerUpdated|openEverythingMenuName", BO), (0, lO.f)("appManagerUpdated|openInGameMenuName", BO), (0, lO.f)("pointerLockUpdate", (OO => {
          OO || "hold" !== pO || SO()
        })), (0, XO.useEffect)((() => {
          if (null === pO) return;
          const OO = OO => {
            "Escape" === OO.key && (OO.stopImmediatePropagation(), OO.preventDefault(), SO())
          };
          return document.addEventListener("keydown", OO, !0), () => {
            document.removeEventListener("keydown", OO, !0)
          }
        }), [pO, SO]), (0, bK.b)(!0, "click" === pO, "EmoteWheelOverlay"), (0, XO.useEffect)((() => {
          if ("hold" === pO) return aK.gameBridge.send("holdEmoteWheel", !0), () => {
            aK.gameBridge.send("holdEmoteWheel", !1)
          }
        }), [pO]), (0, XO.useEffect)((() => {
          if ("hold" !== pO) return;
          const OO = parseFloat(window.getComputedStyle(document.documentElement).fontSize),
            KO = fO.u * OO,
            XO = fO.t * OO,
            bK = OO => {
              let pO = rK.current.x + OO.movementX,
                bK = rK.current.y + OO.movementY;
              const eO = Math.hypot(pO, bK);
              if (eO > KO) {
                const OO = KO / eO;
                pO *= OO, bK *= OO
              }
              rK.current = {
                x: pO,
                y: bK
              }, YO(function(OO, KO, pO, XO) {
                if (Math.hypot(OO, KO) < pO) return null;
                const bK = (0, fO.w)(OO, KO, DO.m);
                return null === XO[bK] ? null : bK
              }(pO, bK, XO, sO))
            };
          return document.addEventListener("mousemove", bK), () => {
            document.removeEventListener("mousemove", bK)
          }
        }), [pO, sO, YO]), null === pO) return null;
      const ZO = "hold" === pO || "pad" === pO,
        GO = null !== QO ? sO[QO] : null,
        qK = null !== GO ? (0, hO.j)(GO).displayName : OO("emotes:pickEmote");
      return (0, IO.jsx)("div", {
        className: zK()("EmoteWheelOverlay", {
          EmoteWheelOverlayPad: "pad" === pO
        }),
        onMouseDown: OO => {
          OO.target === OO.currentTarget && SO()
        },
        children: (0, IO.jsxs)("div", {
          className: "EmoteWheel",
          style: {
            width: 2 * fO.u + "rem",
            height: 2 * fO.u + "rem"
          },
          children: [(0, IO.jsxs)("svg", {
            className: "EmoteWheelSvg",
            viewBox: `0 0 ${fO.r} ${fO.r}`,
            children: [sO.map(((KO, pO) => {
              const XO = null !== KO,
                bK = ZO && pO === QO;
              return (0, IO.jsx)("path", {
                d: jK(pO),
                className: zK()("EmoteWheelWedge", {
                  EmoteWheelWedgeHighlighted: bK,
                  EmoteWheelWedgeDisabled: !XO
                }),
                onClick: OO => {
                  OO.stopPropagation(), null !== KO && (OO => {
                    SO(), JO(OO)
                  })(KO)
                },
                "aria-label": null !== KO ? (0, hO.j)(KO).displayName : OO("emotes:emptySlot")
              }, pO)
            })), (0, IO.jsx)("circle", {
              className: "EmoteWheelOuterRing",
              cx: fO.g,
              cy: fO.g,
              r: fO.n
            }), (0, IO.jsx)("circle", {
              className: "EmoteWheelInnerRing",
              cx: fO.g,
              cy: fO.g,
              r: fO.k
            }), ZO && null !== QO && (0, IO.jsx)("path", {
              className: "EmoteWheelWedgeOutline",
              d: jK(QO)
            })]
          }), sO.map(((OO, KO) => {
            const pO = null !== OO,
              XO = ZO && KO === QO,
              bK = (0, fO.z)(KO, DO.m),
              eO = fO.d * Math.cos(bK),
              lO = fO.d * Math.sin(bK);
            return (0, IO.jsx)("div", {
              className: zK()("EmoteWheelSlotIcon", {
                EmoteWheelSlotIconHighlighted: XO,
                EmoteWheelSlotIconDisabled: !pO
              }),
              style: {
                left: `calc(50% + ${eO}rem)`,
                top: `calc(50% + ${lO}rem)`,
                backgroundImage: pO ? `url(/textures/charSkins/previews/emote_${OO}_preview.png)` : void 0
              },
              "aria-hidden": !0
            }, KO)
          })), (0, IO.jsx)("div", {
            className: "EmoteWheelHint SmallTextBold",
            children: qK
          })]
        })
      })
    }))
  },
  4120: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => FO,
      e: () => zK,
      h: () => VO,
      j: () => QO
    });
    var XO = pO(63),
      bK = pO(4123),
      eO = pO(3618),
      lO = pO(1195),
      vK = pO(4148),
      CO = pO(918),
      hO = pO.n(CO),
      DO = pO(1187),
      MO = pO(1481),
      aK = pO(4151),
      oO = pO(976);

    function FO(OO) {
      let {
        label: KO,
        onClick: pO,
        checked: XO,
        circleInfoText: bK,
        className: vK,
        disabled: CO
      } = OO;
      return (0, oO.jsx)("div", {
        "aria-disabled": CO || void 0,
        "data-pad-focusable": !0,
        className: hO()("SettingBox CheckboxContainer", {
          [vK]: vK,
          SettingBoxDisabled: CO
        }),
        onClick: () => {
          CO || pO(!XO)
        },
        children: (0, oO.jsxs)("div", {
          className: "CheckboxInputAndText",
          children: [(0, oO.jsx)("label", {
            className: "CheckboxClickableLabel",
            children: (0, oO.jsx)(eO.c, {
              className: "SettingsCheckbox",
              checked: XO,
              disabled: CO,
              onChange: () => {}
            })
          }), (0, oO.jsxs)("div", {
            className: "CheckboxText",
            children: [KO, bK && (0, oO.jsx)("span", {
              onClick: OO => OO.stopPropagation(),
              children: (0, oO.jsx)(lO.c, {
                className: "SettingsTextInputCircleInfo",
                hoverInfo: bK
              })
            })]
          })]
        })
      })
    }

    function VO(OO) {
      let {
        name: KO,
        onChange: pO,
        min: bK,
        max: eO,
        step: vK,
        initValue: CO,
        circleInfoText: DO,
        format: MO,
        className: aK,
        padStep: FO,
        disabled: VO = !1,
        selectableMax: QO,
        cappedNote: zK
      } = OO;
      const [AO, fO] = (0, XO.useState)(CO);
      (0, XO.useEffect)((() => {
        fO(CO)
      }), [CO]);
      const dO = void 0 !== QO && QO < eO,
        TO = dO ? {
          "--slider-selectable": (QO - bK) / (eO - bK)
        } : void 0;
      return (0, oO.jsxs)("div", {
        className: hO()("SettingBox SettingsSliderDiv", {
          [aK]: aK,
          SettingBoxDisabled: VO,
          SliderCapped: dO
        }),
        style: TO,
        children: [(0, oO.jsxs)("div", {
          className: "SliderText",
          children: [`${KO}: ${MO?MO(AO):AO}`, DO && (0, oO.jsx)(lO.c, {
            className: "SettingsTextInputCircleInfo",
            hoverInfo: DO
          })]
        }), (0, oO.jsx)("div", {
          className: "SliderDiv",
          children: (0, oO.jsx)(LO, {
            value: AO,
            min: bK,
            max: eO,
            step: vK,
            onChange: OO => {
              if (dO && OO >= QO && AO === QO) return;
              const KO = dO ? Math.min(OO, QO) : OO;
              fO(KO), pO(KO)
            },
            format: MO,
            padStep: FO,
            disabled: VO
          })
        }), dO && zK && (0, oO.jsx)("div", {
          className: "SliderNote",
          children: zK
        })]
      })
    }

    function LO(OO) {
      var KO;
      let {
        value: pO,
        min: eO,
        max: lO,
        step: vK,
        onChange: CO,
        orientation: hO,
        reverse: DO,
        setIsChanging: MO,
        tooltip: FO,
        labels: VO,
        handleLabel: LO,
        format: QO,
        onChangeStart: zK,
        onChangeComplete: AO,
        padStep: fO,
        disabled: dO = !1
      } = OO;
      const TO = (0, XO.useRef)(null),
        NO = (0, XO.useRef)(null);
      (0, XO.useLayoutEffect)((() => {
        var OO, KO, pO;
        const XO = null !== (OO = null === (KO = TO.current) || void 0 === KO ? void 0 : KO.querySelector(".rangeslider")) && void 0 !== OO ? OO : null;
        null === XO || void 0 === XO || XO.setAttribute("data-pad-slider", ""), null === XO || void 0 === XO || XO.setAttribute("data-pad-focusable", ""), null === XO || void 0 === XO || null === (pO = XO.querySelector(".rangeslider__handle")) || void 0 === pO || pO.setAttribute("data-pad-slider-handle", ""), NO.current = XO
      }), []), (0, XO.useLayoutEffect)((() => {
        var OO, KO;
        dO ? null === (OO = NO.current) || void 0 === OO || OO.setAttribute("aria-disabled", "true") : null === (KO = NO.current) || void 0 === KO || KO.removeAttribute("aria-disabled")
      }), [dO]);
      const IO = (null !== (KO = String(vK).split(".")[1]) && void 0 !== KO ? KO : "").length,
        yK = OO => {
          const KO = Number((Math.round((OO - eO) / vK) * vK + eO).toFixed(IO));
          return Math.min(lO, Math.max(eO, KO))
        },
        gK = (0, XO.useRef)(!1);
      return (0, aK.h)(NO, {
        adjust: OO => {
          if (dO) return;
          const KO = null !== fO && void 0 !== fO ? fO : Math.max(vK, Math.round((lO - eO) / 20 / vK) * vK),
            XO = yK(pO + OO * KO * (DO ? -1 : 1));
          XO !== pO && (null === zK || void 0 === zK || zK(), CO(XO), null === AO || void 0 === AO || AO())
        },
        setFraction: OO => {
          if (dO) return;
          const KO = yK(eO + (DO ? 1 - OO : OO) * (lO - eO));
          KO !== pO && (gK.current || (gK.current = !0, null === zK || void 0 === zK || zK()), CO(KO))
        },
        endDrag: () => {
          gK.current && (gK.current = !1, null === AO || void 0 === AO || AO())
        }
      }), (0, oO.jsx)("div", {
        ref: TO,
        style: {
          display: "contents"
        },
        children: (0, oO.jsx)(bK.c, {
          value: pO,
          min: eO,
          max: lO,
          step: vK,
          onChange: CO,
          orientation: hO,
          reverse: DO,
          tooltip: FO,
          labels: VO,
          handleLabel: LO,
          format: QO,
          onChangeStart: () => {
            null === zK || void 0 === zK || zK(), null === MO || void 0 === MO || MO(!0)
          },
          onChangeComplete: () => {
            null === MO || void 0 === MO || MO(!1), null === AO || void 0 === AO || AO()
          }
        })
      })
    }
    async function QO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
      const KO = DO.NotificationProvider.showPromptPopup({
        title: "settingsMenu:reloadPagePopupTitle",
        subtitle: "settingsMenu:reloadPagePopupSubtitle",
        confirmText: "settingsMenu:reloadPagePopupConfirm",
        confirmTooltip: "",
        cancelText: "general:cancel",
        cancelTooltip: "",
        unlockPointerKey: OO
      });
      !0 === await KO.getResult() && (0, MO.reloadBloxd)()
    }

    function zK(OO) {
      let {
        label: KO,
        options: pO,
        value: XO,
        onChange: bK,
        circleInfoText: eO
      } = OO;
      return (0, oO.jsxs)("div", {
        className: "SettingBox SegmentedSettingRow",
        children: [(0, oO.jsxs)("div", {
          className: "SliderText",
          children: [KO, eO && (0, oO.jsx)(lO.c, {
            className: "SettingsTextInputCircleInfo",
            hoverInfo: eO
          })]
        }), (0, oO.jsx)(vK.c, {
          ariaLabel: KO,
          options: pO,
          value: XO,
          onChange: bK
        })]
      })
    }
  },
  4148: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(976);

    function lO(OO) {
      let {
        options: KO,
        value: pO,
        onChange: XO,
        ariaLabel: lO
      } = OO;
      return (0, eO.jsx)("div", {
        className: "SegmentedToggle",
        role: "group",
        "aria-label": lO,
        children: KO.map((OO => {
          const KO = OO.value === pO;
          return (0, eO.jsx)("button", {
            type: "button",
            "aria-pressed": KO,
            className: bK()("SegmentedToggleOption SmallTextLight", {
              SegmentedToggleOptionSelected: KO
            }),
            onClick: () => {
              KO || XO(OO.value)
            },
            children: OO.label
          }, OO.value)
        }))
      })
    }
  },
  7857: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => aK,
      h: () => VO,
      l: () => LO,
      p: () => FO,
      t: () => oO
    });
    var XO = pO(63),
      bK = pO(7865),
      eO = pO(26),
      lO = pO(1556),
      vK = pO(596),
      CO = pO(36),
      hO = pO(1119),
      DO = pO(1569);
    const MO = 50;
    const aK = new class {
      constructor() {
        this.state = {
          messages: [],
          reportedPlayers: [],
          channel: null
        }, this.listeners = new Set, this.stopListening = [], this.nextClientChatMsgId = 0, this.subscribe = OO => {
          if (0 === this.listeners.size) {
            var KO, pO;
            this.state = {
              ...this.state,
              channel: null !== (KO = null === (pO = DO.c.get("chatChannels")) || void 0 === pO ? void 0 : pO[0]) && void 0 !== KO ? KO : null
            };
            const OO = eO.i.subscribe("reportPlayer", (OO => {
              let {
                playerEId: KO
              } = OO;
              this.setState({
                ...this.state,
                reportedPlayers: [...this.state.reportedPlayers, KO]
              })
            }));
            this.stopListening = [lO.gameBridge.subscribe("chatReceived", (OO => {
              let {
                serverChatMsgId: KO,
                content: pO,
                author: XO
              } = OO;
              this.addMessage(KO, pO, XO)
            })), () => {
              eO.i.unsubscribe(OO)
            }, DO.c.subscribe("chatChannels", (OO => {
              var KO;
              this.setState({
                ...this.state,
                channel: null !== (KO = null === OO || void 0 === OO ? void 0 : OO[0]) && void 0 !== KO ? KO : null
              })
            }))]
          }
          return this.listeners.add(OO), () => {
            if (this.listeners.delete(OO), 0 === this.listeners.size) {
              for (const OO of this.stopListening) OO();
              this.stopListening = [], this.state = {
                messages: [],
                reportedPlayers: [],
                channel: null
              }
            }
          }
        }, this.getState = () => this.state
      }
      addMessage(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        const XO = {
          serverChatMsgId: OO,
          content: KO,
          clientChatMsgId: this.nextClientChatMsgId++,
          author: pO
        };
        this.setState({
          ...this.state,
          messages: [XO, ...this.state.messages].slice(0, bK.f)
        })
      }
      selectNextChannel() {
        const OO = DO.c.get("chatChannels");
        if (OO) {
          const KO = OO.findIndex((OO => {
            var KO;
            return OO.channelName === (null === (KO = this.state.channel) || void 0 === KO ? void 0 : KO.channelName)
          }));
          this.setState({
            ...this.state,
            channel: OO[(KO + 1) % OO.length]
          })
        }
      }
      setState(OO) {
        this.state = OO;
        for (const KO of this.listeners) KO()
      }
    };

    function oO() {
      const [OO, KO] = (0, XO.useState)(aK.getState);
      return (0, XO.useEffect)((() => {
        const OO = aK.subscribe((() => {
          KO(aK.getState())
        }));
        return KO(aK.getState()), OO
      }), []), OO
    }

    function FO(OO) {
      var KO, pO;
      if (vK.k && "/" !== OO[0]) aK.addMessage(null, [{
        str: "Cannot send chat messages in bloxdk12. Use /help for a list of commands."
      }]);
      else {
        if (OO.startsWith("/report")) {
          var XO;
          const KO = null !== (XO = OO.replace("/report", "").trim().split(" ")[0]) && void 0 !== XO ? XO : "";
          if ("" === KO) return void aK.addMessage(null, [{
            str: "You must type a player's name when reporting them.\nExample:\n/report Bob"
          }]);
          const pO = lO.gameBridge.latest("players"),
            bK = lO.gameBridge.latest("hiddenPlayerNames"),
            vK = OO => {
              var XO, eO;
              const lO = null !== (XO = null === (eO = pO.byId[OO]) || void 0 === eO ? void 0 : eO.name) && void 0 !== XO ? XO : null;
              return null !== lO && (lO === KO || (0, hO.e)(lO, bK) === KO)
            };
          if (null !== pO.localId && vK(pO.localId)) return void aK.addMessage(null, [{
            str: "You cannot report yourself."
          }]);
          for (const OO of pO.ids)
            if (vK(OO)) return eO.i.pl("OpenReportMenu", {
              playerEId: OO,
              playerName: pO.byId[OO].name,
              Tl: null,
              serverChatMsgId: null
            }), void console.log("Opening report menu...");
          aK.addMessage(null, [{
            str: "Player not found in lobby."
          }])
        }
        lO.gameBridge.send("sendChatMessage", {
            Tl: OO,
            channelName: null !== (KO = null === (pO = aK.getState().channel) || void 0 === pO ? void 0 : pO.channelName) && void 0 !== KO ? KO : null
          }),
          function(OO) {
            var KO;
            const pO = null !== (KO = CO.e.getItem("recentlySentChatMsgs")) && void 0 !== KO ? KO : [];
            pO.push(OO), pO.length > MO && pO.shift();
            CO.e.setItem("recentlySentChatMsgs", pO)
          }(OO)
      }
    }

    function VO() {
      var OO;
      return null !== (OO = CO.e.getItem("recentlySentChatMsgs")) && void 0 !== OO ? OO : []
    }

    function LO(OO) {
      var KO;
      let pO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      const XO = null !== (KO = CO.e.getItem("recentlySentChatMsgs")) && void 0 !== KO ? KO : [],
        bK = XO.length + 1,
        eO = pO ? (OO % bK + bK) % bK : Math.min(XO.length, Math.max(0, OO));
      return {
        stepsBack: eO,
        text: 0 === eO ? "" : XO[XO.length - eO]
      }
    }
  },
  7800: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      f: () => eO
    });
    var XO = pO(1608);
    const bK = /^(?:Key[A-Z]|Digit[0-9]|Arrow(?:Up|Down|Left|Right)|Space)$/,
      eO = OO => "string" === typeof OO.icon && "" !== OO.icon && "string" === typeof OO.keycode && bK.test(OO.keycode),
      lO = OO => "Space" === OO ? "_" : XO.f[OO]
  },
  7875: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK
    });
    var XO = pO(22);

    function bK() {
      return !XO.d.get("isTouchScreen") && null !== document.pointerLockElement
    }
  },
  7880: (OO, KO, pO) => {
    pO.d(KO, {
      D: () => aK,
      H: () => oO,
      d: () => eO,
      g: () => vK,
      k: () => hO,
      n: () => CO,
      r: () => lO,
      t: () => bK,
      u: () => XO,
      v: () => FO,
      w: () => MO,
      z: () => DO
    });
    const XO = 14,
      bK = 6,
      eO = (XO + bK) / 2,
      lO = 200,
      vK = lO / 2,
      CO = lO / 2 - 1,
      hO = bK / XO * (lO / 2),
      DO = (OO, KO) => -Math.PI / 2 + 2 * OO * Math.PI / KO,
      MO = (OO, KO, pO) => {
        const XO = 2 * Math.PI / pO;
        return (Math.round((Math.atan2(KO, OO) + Math.PI / 2) / XO) % pO + pO) % pO
      },
      aK = .5,
      oO = (OO, KO, pO) => Math.hypot(OO.x, OO.y) < aK ? pO : MO(OO.x, OO.y, KO),
      FO = (OO, KO, pO, XO, bK) => {
        const eO = Math.PI / KO,
          lO = DO(OO, KO),
          vK = lO - eO,
          CO = lO + eO,
          hO = (OO, KO) => `${pO+OO*Math.cos(KO)} ${pO+OO*Math.sin(KO)}`;
        return [`M ${hO(XO,vK)}`, `L ${hO(bK,vK)}`, `A ${bK} ${bK} 0 0 1 ${hO(bK,CO)}`, `L ${hO(XO,CO)}`, `A ${XO} ${XO} 0 0 0 ${hO(XO,vK)}`, "Z"].join(" ")
      }
  },
  7917: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(63),
      bK = pO(7824),
      eO = pO(1991);

    function lO() {
      const OO = (0, eO.i)("shopInfo"),
        [, KO] = (0, XO.useReducer)((OO => OO + 1), 0);
      return (0, eO.f)("shopInfo", KO), !(0, bK.e)(OO)
    }
  },
  7272: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      d: () => eO,
      e: () => aK,
      i: () => MO,
      k: () => hO,
      l: () => vK,
      p: () => XO,
      r: () => oO,
      s: () => FO
    });
    const XO = ["menuConfirm", "menuBack", "menuTabPrevious", "menuTabNext", "menuPageUp", "menuPageDown", "menuSecondary", "menuToggleCursor"],
      bK = [{
        group: "gameplay",
        actions: ["jump", "sneak", "sneakToggle", "sprint", "attack", "use", "hotbarPrevious", "hotbarNext", "inventory", "actionButton", "perspective", "XM", "drop", "emoteWheel", "chat", "pause", "leaderboard"]
      }, {
        group: "menu",
        actions: XO
      }, {
        group: "inventory",
        actions: ["inventoryPrimary", "inventorySecondary", "inventoryQuickMove", "inventoryClose", "inventoryPanelPrevious", "inventoryPanelNext", "inventoryDrop", "inventoryHotbarSwap"]
      }, {
        group: "keyboard",
        actions: ["keyboardType", "keyboardBackspace", "keyboardSpace", "keyboardCaretLeft", "keyboardCaretRight", "keyboardShift", "keyboardSymbols", "keyboardSubmit", "keyboardClose", "keyboardChannel"]
      }],
      eO = {
        jump: "A",
        sneak: "B",
        sneakToggle: "RS",
        sprint: "LS",
        attack: "RT",
        use: "LT",
        hotbarPrevious: "LB",
        hotbarNext: "RB",
        inventory: "Y",
        actionButton: "X",
        perspective: "Up",
        XM: "Up",
        drop: "Down",
        emoteWheel: "Left",
        chat: "Right",
        pause: "Menu",
        leaderboard: "View",
        menuConfirm: "A",
        menuBack: "B",
        menuTabPrevious: "LB",
        menuTabNext: "RB",
        menuPageUp: "LT",
        menuPageDown: "RT",
        menuSecondary: "X",
        menuToggleCursor: "LS",
        inventoryPrimary: "A",
        inventorySecondary: "X",
        inventoryQuickMove: "RS",
        inventoryClose: "B",
        inventoryPanelPrevious: "LB",
        inventoryPanelNext: "RB",
        inventoryDrop: "View",
        inventoryHotbarSwap: "LS",
        keyboardType: "A",
        keyboardBackspace: "X",
        keyboardSpace: "Y",
        keyboardCaretLeft: "LB",
        keyboardCaretRight: "RB",
        keyboardShift: "LT",
        keyboardSymbols: "RT",
        keyboardSubmit: "Menu",
        keyboardClose: "B",
        keyboardChannel: "View"
      },
      lO = ["XM", "perspective"],
      vK = OO => lO.includes(OO) ? lO : [OO],
      CO = Object.fromEntries(bK.flatMap((OO => {
        let {
          group: KO,
          actions: pO
        } = OO;
        return pO.map((OO => [OO, KO]))
      }))),
      hO = OO => CO[OO],
      DO = {
        pause: ["menu"],
        leaderboard: ["menu"],
        inventory: ["menu"],
        menuPageUp: ["inventory"],
        menuPageDown: ["inventory"]
      },
      MO = OO => {
        var KO;
        return [hO(OO), ...null !== (KO = DO[OO]) && void 0 !== KO ? KO : []]
      },
      aK = new Set(["menu", "inventory", "keyboard"]),
      oO = {
        jump: "jump",
        crouch: "sneak",
        sprint: "sprint",
        "primary-fire": "attack",
        "alt-fire": "use",
        SpecialAction1: "actionButton",
        SpecialAction2: "actionButton",
        ReloadGun: "actionButton",
        DropItem: "drop",
        SwapCameraZoom: "perspective",
        "mid-fire": "XM",
        OpenInventory: "inventory",
        OpenSettings: "pause",
        OpenLobbyLeaderboard: "leaderboard",
        OpenShop: "leaderboard",
        OpenEmoteWheel: "emoteWheel"
      },
      FO = new Set(["forward", "backward", "left", "right"])
  },
  7263: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => gK,
      D: () => DO,
      H: () => yK,
      K: () => jK,
      d: () => zK,
      g: () => dO,
      j: () => aK,
      m: () => oO,
      n: () => wO,
      o: () => EO,
      s: () => uO,
      u: () => fO,
      w: () => YO,
      y: () => IO,
      z: () => AO
    });
    var XO = pO(7272),
      bK = pO(7275),
      eO = pO(7255),
      lO = pO(7289);
    const vK = OO => "XM" === OO ? "perspective" : OO,
      CO = (OO, KO) => {
        var pO;
        const bK = vK(KO);
        return null !== (pO = OO[bK]) && void 0 !== pO ? pO : XO.d[bK]
      },
      hO = new Map([
        ["menuConfirm", "menuBack"],
        ["inventoryPrimary", "inventoryClose"],
        ["keyboardType", "keyboardClose"]
      ].flatMap((OO => {
        let [KO, pO] = OO;
        return [
          [KO, pO],
          [pO, KO]
        ]
      }))),
      DO = (OO, KO) => null !== OO && void 0 !== OO ? OO : "nintendo" === KO,
      MO = OO => DO((0, bK.i)().swapConfirmBack, (0, bK.l)()) && hO.get(OO) || OO,
      aK = OO => CO((0, bK.i)().MX, MO(OO)),
      oO = OO => XO.d[MO(OO)],
      FO = Object.keys(XO.d),
      VO = OO => "gameplay" === (0, XO.k)(OO) ? ["gameplay"] : (0, XO.i)(OO),
      LO = (OO, KO) => {
        const pO = VO(KO);
        return VO(OO).some((OO => pO.includes(OO)))
      },
      QO = (OO, KO, pO) => {
        const bK = CO(OO, KO),
          lO = new Set((0, XO.l)(KO)),
          hO = [...lO];
        for (let XO = hO.pop(); XO; XO = hO.pop())
          for (const KO of FO) {
            const eO = CO(OO, KO);
            lO.has(KO) || eO !== pO && eO !== bK || !LO(XO, KO) || (lO.add(KO), hO.push(KO))
          }
        const DO = {
          ...OO
        };
        for (const MO of lO) {
          const KO = CO(OO, MO) === bK ? pO : bK,
            lO = (0, XO.i)(MO).some((OO => XO.e.has(OO)));
          if ((0, eO.H)(KO) && lO) return null;
          DO[vK(MO)] = KO
        }
        for (const eO of Object.keys(DO)) DO[eO] === XO.d[eO] && delete DO[eO];
        return DO
      },
      zK = (OO, KO) => null !== QO((0, bK.i)().MX, MO(OO), KO),
      AO = (OO, KO) => {
        if (aK(OO) === KO) return !0;
        const pO = QO((0, bK.i)().MX, MO(OO), KO);
        return !!pO && ((0, bK.n)({
          MX: pO
        }), !0)
      },
      fO = (OO, KO) => {
        const pO = (0, XO.l)(KO);
        return FO.filter((KO => vK(KO) === KO && !pO.includes(KO) && CO(OO, MO(KO)) !== aK(KO)))
      },
      dO = ["southpaw", "triggersSwapped"],
      TO = {
        southpaw: {
          sprint: "RS",
          sneakToggle: "LS"
        },
        triggersSwapped: {
          attack: "LT",
          use: "RT"
        }
      },
      NO = OO => Object.keys(TO[OO]),
      IO = (OO, KO) => "southpaw" === OO ? KO.swapSticks : NO(OO).every((pO => CO(KO.MX, pO) === TO[OO][pO])),
      yK = (OO, KO) => {
        const pO = (0, bK.i)();
        let eO = pO.MX;
        for (const bK of NO(OO)) {
          const pO = KO ? TO[OO][bK] : XO.d[bK];
          if (eO = QO(eO, bK, pO), !eO) return !1
        }
        return (0, bK.n)({
          swapSticks: "southpaw" === OO ? KO : pO.swapSticks,
          MX: eO
        }), !0
      },
      gK = () => {
        (0, bK.n)({
          swapSticks: !1,
          MX: {}
        })
      },
      uO = () => (0, bK.i)().swapSticks ? "RightStick" : "LeftStick",
      EO = () => (0, bK.i)().swapSticks ? "LeftStick" : "RightStick",
      jK = OO => (0, bK.i)().swapSticks && (0, eO.H)(OO),
      YO = OO => jK(OO) ? uO() : EO(),
      wO = OO => {
        if (XO.s.has(OO)) return uO();
        const KO = XO.r[OO];
        return KO && ("leaderboard" !== KO || (0, lO.c)(OO, (0, lO.b)())) ? aK(KO) : null
      }
  },
  7247: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      ControllerCategory: () => KC,
      ControllerGlyph: () => oX,
      ControllerRoot: () => Kv,
      PadLobbyShortcuts: () => Qv,
      PadSneakChip: () => Cv,
      PadTooltip: () => Dv,
      attachPressToContinue: () => yC,
      getBoundButton: () => DO.j,
      getControllerSettings: () => aK.i,
      getGlyphForNoaAction: () => DO.n,
      getInventoryCursorState: () => XC,
      getMenuShortcutButton: () => Hb,
      getPadGlyphIconName: () => ev,
      getPadGlyphIconUrl: () => lv,
      getPadRepeatTiming: () => VO.c,
      hasActivePad: () => pC,
      isPadSteppingSlots: () => bh
    });
    const XO = JSON.parse('{"controller":{"inventoryTake":"Take","inventoryTakeHalf":"Take half","inventoryPlace":"Place","inventoryPlaceOne":"Place one","inventoryQuickMove":"Quick move","inventoryToHotbar":"To hotbar","inventoryPutBack":"Put back","inventoryHotbarSwap":"Swap with hotbar","inventorySwapHere":"Swap here","inventoryCancel":"Cancel","inventoryClose":"Close","inventoryDrop":"Drop (hold: stack)","inventorySelect":"Select","inventoryCraft":"Craft (hold to repeat)","inventoryCraftAll":"Craft all","inventoryChooseRecipe":"Choose","inventoryBackToRecipes":"Back to recipes","inventoryType":"Type","inventoryPanels":"Switch panel","inventoryCategory":"Category","inventoryPage":"Page","disconnected":"Controller disconnected","gameplayReload":"Reload","gameplayActionWheelHint":"(hold for more)","gameplaySneaking":"Sneaking","gameplayLoadFailedTitle":"Controller unavailable","gameplayLoadFailedSubtitle":"Reload the page to play with your controller.","gameplayDropStack":"Keep holding to drop the stack","gameplayAttackLatched":"Attacking","gameplayPickBlock":"Pick block","padButtonView":"View","padButtonMenu":"Menu","padButtonHome":"Home","padButtonCreate":"Create","padButtonOptions":"Options","padButtonDpadUp":"D-pad \u2191","padButtonDpadDown":"D-pad \u2193","padButtonDpadLeft":"D-pad \u2190","padButtonDpadRight":"D-pad \u2192","padButtonLeftStick":"L Stick","padButtonRightStick":"R Stick","settingsLook":"Look","settingsLookSensitivityX":"Look sensitivity (horizontal)","settingsLookSensitivityY":"Look sensitivity (vertical)","settingsAimLookSensitivity":"Look sensitivity while aiming (use held)","settingsInvertLookX":"Invert horizontal look","settingsInvertLookY":"Invert vertical look","settingsLookCurve":"Look curve","settingsLookCurveHint":"Steep gives finer aim near the centre, Linear turns at an even rate, and Boost turns faster when you hold the stick all the way.","settingsCurveExponential":"Steep","settingsCurveLinear":"Linear","settingsCurveBoost":"Boost","settingsLookDeadzone":"Look deadzone","settingsGyro":"Gyro aiming","settingsGyroToggle":"Aim by moving the controller","settingsGyroToggleInfo":"Turn and tilt the controller to aim, on top of the right stick.","settingsGyroTogglePhone":"Aim by moving your phone or tablet","settingsGyroToggleInfoPhone":"Turn and tilt your phone or tablet to aim, on top of the right stick.","settingsGyroUnsupported":"Gyro aiming needs Chrome or Edge.","settingsGyroBlocked":"Gyro aiming isn\'t available on this site.","settingsGyroPhoneNeedsController":"Connect a controller to aim by moving your phone or tablet.","settingsGyroSteamHint":"If Steam already turns your gyro into mouse movement, leave this off.","settingsGyroConnect":"Connect motion controller","settingsGyroConnectHint":"Works with DualSense, DualShock 4 and Switch controllers.","settingsGyroConnectNeedsClick":"Click Connect with your mouse: the browser asks before sharing a controller.","settingsGyroOpenFailed":"Another app is using the controller. Close apps such as Steam or DS4Windows, then try again.","settingsGyroConnected":"Aiming with {{name}}.","settingsGyroAllowMotion":"Allow motion sensor","settingsGyroAllowNeedsTap":"Tap Allow motion sensor on your screen to turn it on.","settingsGyroPhoneOn":"Aiming with this device\'s motion sensor.","settingsGyroPhoneWaiting":"Waiting for this device\'s motion sensor\u2026","settingsGyroPhoneNoSensor":"No motion sensor found on this device.","settingsGyroPhoneDenied":"Motion access is blocked. Allow it in your browser settings.","settingsGyroSensitivity":"Gyro sensitivity","settingsGyroActivation":"Gyro turns on","settingsGyroAlways":"Always","settingsGyroWhileAiming":"While aiming","settingsGyroWhileButton":"While holding a button","settingsGyroAimingHint":"Hold {{button}} to aim with motion.","settingsGyroButton":"Gyro button","settingsGyroButtonHint":"While gyro aiming is on, this button only turns the gyro on in game, so pick one you rarely use.","settingsMovement":"Movement","settingsMoveDeadzone":"Move deadzone","settingsAutoSprint":"Sprint at full tilt","settingsAutoSprintInfo":"Push the movement stick all the way to sprint.","settingsSneak":"Sneak","settingsSneakHold":"Hold","settingsSneakToggle":"Toggle","settingsButtons":"Buttons","settingsPromptFamily":"Button prompts","settingsPromptAuto":"Match my controller","settingsPromptXbox":"Xbox","settingsPromptPlayStation":"PlayStation","settingsPromptNintendo":"Nintendo","settingsPromptSteamDeck":"Steam Deck","settingsPromptGeneric":"Generic","settingsHideButtonHints":"Hide button hints","settingsVibration":"Vibration","settingsCursorSpeed":"Virtual cursor speed","settingsCursorMagnetism":"Cursor snaps onto buttons","settingsMenuBackToCategories":"Back returns to the category list first","settingsAccessibility":"Accessibility","settingsSwapConfirmBack":"Swap confirm and back","settingsSwapToast":"Select and Back have swapped buttons.","settingsLayoutRefusedToast":"This layout doesn\'t fit your current buttons. Reset them to use it.","settingsSwapConfirmBackInfo":"Select with the right face button and go back with the bottom one, in menus, the inventory and the on-screen keyboard. On by default for Nintendo controllers.","settingsButtonRepeat":"Button repeat","settingsButtonRepeatHint":"How a held button repeats in menus, sliders, the on-screen keyboard and crafting. Off acts once per press, and holding drop in game drops just one item.","settingsButtonRepeatDefault":"Default","settingsButtonRepeatSlow":"Slow (0.8 s, then 4 a second)","settingsButtonRepeatOff":"Off (once per press)","settingsTapHoldTime":"Tap/hold time","settingsTapHoldTimeHint":"How long to hold the chat, emote or action button to open its wheel, or the view button to change view where a tap picks a block. Dropping a whole stack takes 0.8, 1 or 1.3 s.","settingsTapHoldShort":"Short (0.25 s)","settingsTapHoldMedium":"Medium (0.5 s)","settingsTapHoldLong":"Long (0.8 s)","settingsEmoteButton":"Emote button","settingsEmoteButtonTapHoldHint":"Tap to repeat your last emote, or hold to open the emote wheel.","settingsEmoteButtonWheelHint":"Any press opens the emote wheel, with no hold to time. Pick with the stick, then select.","settingsEmoteButtonTapHold":"Tap repeats, hold opens wheel","settingsEmoteButtonWheel":"Opens the wheel","settingsAttackMode":"Attack / mine","settingsAttackHoldHint":"Hold attack to keep attacking or mining.","settingsAttackToggleHint":"Press attack once to keep attacking or mining, and again to stop.","settingsAttackHold":"Hold","settingsAttackToggle":"Toggle","settingsLargePointer":"Large pointer and focus","settingsLargePointerInfo":"A bigger menu cursor, thicker selection brackets and bigger button hints.","settingsRemap":"Remap buttons","settingsRemapHint":"Select an action, then press a button. If that button is taken, the two swap.","settingsLayoutSouthpaw":"Southpaw (move with the right stick)","settingsLayoutTriggersSwapped":"Triggers swapped (attack with the left trigger)","settingsCapturePrompt":"Press a button","settingsCaptureCancelHint":"Press {{button}} to cancel","settingsCaptureCancelOrBindHint":"Tap {{button}} to cancel, or hold it to choose it","settingsReset":"Reset","settingsSwapNotice":"{{action}} moved to {{button}}","settingsResetAll":"Reset all buttons and sticks","settingsGroupGameplay":"Movement & gameplay","settingsGroupMenus":"Menus","settingsGroupInventory":"Inventory","settingsGroupKeyboard":"On-screen keyboard","settingsActionMove":"Move","settingsActionLook":"Look around","settingsActionJump":"Jump","settingsActionSneak":"Sneak","settingsActionSneakToggle":"Toggle sneak","settingsActionSprint":"Sprint","settingsActionAttack":"Attack / mine","settingsActionUse":"Use / place","settingsActionHotbarPrevious":"Previous hotbar slot","settingsActionHotbarNext":"Next hotbar slot","settingsActionInventory":"Inventory","settingsActionActionButton":"Game action","settingsActionPerspective":"Change view","settingsActionPickBlock":"Pick block (creative)","settingsActionDrop":"Drop item","settingsActionEmoteWheel":"Emotes","settingsActionChat":"Chat","settingsActionPause":"Pause menu","settingsActionLeaderboard":"Shop / leaderboard","settingsActionMenuConfirm":"Select","settingsActionMenuBack":"Back","settingsActionMenuTabPrevious":"Previous tab","settingsActionMenuTabNext":"Next tab","settingsActionMenuPageUp":"Page up","settingsActionMenuPageDown":"Page down","settingsActionMenuSecondary":"Secondary action","settingsActionMenuToggleCursor":"Switch to virtual cursor","settingsActionInventoryPrimary":"Pick up / place","settingsActionInventorySecondary":"Pick up half / place one","settingsActionInventoryQuickMove":"Quick move","settingsActionInventoryHotbarSwap":"Swap with hotbar slot","settingsActionInventoryClose":"Close","settingsActionInventoryPanelPrevious":"Previous panel","settingsActionInventoryPanelNext":"Next panel","settingsActionInventoryDrop":"Drop item","settingsActionKeyboardType":"Type key","settingsActionKeyboardBackspace":"Backspace","settingsActionKeyboardSpace":"Space","settingsActionKeyboardCaretLeft":"Move cursor left","settingsActionKeyboardCaretRight":"Move cursor right","settingsActionKeyboardShift":"Shift","settingsActionKeyboardSymbols":"Accents and symbols","settingsActionKeyboardSubmit":"Send","settingsActionKeyboardClose":"Close keyboard","settingsActionKeyboardChannel":"Chat channel","settingsAlternatives":"Try alternatives","settingsAlternativesHint":"Try each way of playing and keep the one that feels best.","settingsMenuNavigation":"Menu navigation","settingsMenuNavigationHint":"Steer a cursor with the stick and jump between buttons with the D-pad, or use just one.","settingsNavHybrid":"Cursor and D-pad","settingsMenuNavFocus":"Jump between buttons","settingsVirtualCursor":"Virtual cursor","settingsInventoryNavigation":"Inventory","settingsInventoryNavigationHint":"Steer a cursor with the stick and step slot by slot with the D-pad, or use just one.","settingsInventoryNavSlot":"Slot by slot","settingsQuickChat":"Hold chat button","settingsQuickChatHint":"Hold the chat button to pick a quick phrase. Tapping it still opens chat.","settingsQuickChatWheel":"Quick chat wheel","settingsQuickChatOff":"Off","settingsLeaderboardButton":"Shop / leaderboard button","settingsLeaderboardButtonHint":"Open the shop in one press in games that have one. The lobby leaderboard is still in the pause menu.","settingsLeaderboardButtonShop":"Shop, in games with one","settingsLeaderboardButtonLeaderboard":"Always the leaderboard","settingsTester":"Gamepad tester","settingsTesterNoPad":"Connect a gamepad and press any button to test it.","settingsTesterFamily":"Detected: {{family}}","settingsTesterHint":"Start a test to try every button and stick without moving through the menu.","settingsTesterStart":"Start test","settingsTesterStop":"Stop test","settingsTesterTesting":"Press anything to see it light up. To stop, hold {{button}} or press it three times.","settingsControlsNote":"Playing with a gamepad? Change its buttons and feel in Gamepad settings.","settingsOpenController":"Gamepad settings","keyboardSpace":"Space","keyboardSend":"Send","keyboardDone":"Done","keyboardTargetChat":"Chat","keyboardTargetSign":"Sign","keyboardTargetNameTag":"Name tag","keyboardTargetBook":"Book page","keyboardTargetBookTitle":"Book title","keyboardTargetText":"Text","keyboardPhraseGg":"gg","keyboardPhraseHi":"hi","keyboardPhraseThanks":"thanks","keyboardPhraseGl":"gl","keyboardPhraseBrb":"brb","keyboardPhraseYes":"yes","keyboardPhraseNo":"no","keyboardPhraseHelp":"help!","quickChatPick":"Pick a phrase","actionWheelPick":"Pick an action","wheelReleaseToPick":"Release to pick","wheelClose":"Close","wheelChoose":"Choose","menusSelect":"Select","menusBack":"Back","menusClose":"Close","menusQuickChat":"Quick chat (hold)","menusSkipTutorial":"Skip tutorial","menusTabs":"Tabs","menusRows":"Rows","menusCursorMode":"Cursor","menusFocusMode":"Focus","menusClick":"Click","menusRightClick":"Right-click","menusScroll":"Scroll","menusFriends":"Friends","menusSearch":"Search","menusSettings":"Settings","menusLeaveGameTitle":"Leave the game?","menusLeaveGameLeave":"Leave","menusLeaveGameStay":"Stay","menusNotifications":"Notifications","menusLobby":"Lobby","menusShop":"Shop","menusTasks":"Tasks & leaderboards","menusInvite":"Invite friends","menusAdjust":"Adjust","menusFavourite":"Favourite","screensPressToContinue":"Press {{button}} to continue","screensPressToEnterGame":"Press {{button}} to enter game","screensEnterGame":"Enter game","screensBackToGames":"Back to games","tutorialMine":"Mine","tutorialPlace":"Place / Use","tutorialInventory":"Inventory","tutorialPause":"Pause","menusUseMouse":"Use a mouse or touch here"}}');
    var bK = pO(1051),
      eO = pO(1232),
      lO = pO(7252),
      vK = pO(77),
      CO = pO(22),
      hO = pO(26),
      DO = pO(7263),
      MO = pO(7291),
      aK = pO(7275),
      oO = pO(7299),
      FO = pO(7255),
      VO = pO(7748),
      LO = pO(7750),
      QO = pO(1473);
    const zK = (OO, KO, pO) => Math.max(KO, Math.min(pO, OO)),
      AO = OO => Math.min(OO.width, OO.height) / 720,
      fO = OO => Math.max(.15, OO);
    class dO {
      constructor() {
        this.locked = !1
      }
      lock() {
        this.locked = !0
      }
      update(OO, KO) {
        const pO = Math.hypot(OO.x, OO.y) >= (OO => Math.max(.3, OO))(KO);
        return this.locked ? (this.locked = pO, !1) : pO
      }
    }
    const TO = (OO, KO) => {
        const pO = zK(KO.dtMs, 0, 100),
          XO = pO / 1e3,
          bK = AO(KO.viewport) * (KO.cursorSpeedPercent / 100),
          eO = (0, FO.g)(KO.stick, fO(KO.moveDeadzone)),
          lO = Math.hypot(eO.x, eO.y),
          vK = ((OO, KO, pO) => {
            if (KO < .3) return 0;
            const XO = pO / 350;
            return KO >= .85 ? Math.min(1, OO + XO) : Math.max(0, OO - XO)
          })(OO.speedRamp, lO, pO);
        let CO = OO.x,
          hO = OO.y;
        if (lO > 0) {
          const OO = .45 + .55 * vK,
            pO = KO.context.overInteractive ? .45 : 1,
            DO = 1400 * (OO => {
              const KO = zK(OO, 0, 1);
              return .3 * KO + .7 * KO * KO
            })(lO) * bK * OO * pO;
          CO += eO.x / lO * DO * XO, hO += eO.y / lO * DO * XO
        }
        const DO = Math.hypot(KO.dpad.x, KO.dpad.y);
        if (DO > 0) {
          const OO = 500 * bK;
          CO += KO.dpad.x / DO * OO * XO, hO += KO.dpad.y / DO * OO * XO
        }
        const MO = KO.context.magnetTarget;
        if (MO && lO < .3 && 0 === DO) {
          const OO = ((OO, KO, pO, XO, bK) => {
            const eO = KO.x - OO.x,
              lO = KO.y - OO.y,
              vK = Math.hypot(eO, lO);
            if (0 === vK) return {
              x: 0,
              y: 0
            };
            const CO = Math.min(vK, bK * (1 - XO / .3));
            let hO = eO / vK * CO,
              DO = lO / vK * CO;
            if (XO > 0) {
              const OO = pO.x / XO,
                KO = pO.y / XO,
                bK = hO * OO + DO * KO;
              bK < 0 && (hO -= bK * OO, DO -= bK * KO)
            }
            return {
              x: hO,
              y: DO
            }
          })({
            x: CO,
            y: hO
          }, MO, eO, lO, 120 * AO(KO.viewport) * XO);
          CO += OO.x, hO += OO.y
        }
        return {
          x: zK(CO, 0, Math.max(0, KO.viewport.width - 1)),
          y: zK(hO, 0, Math.max(0, KO.viewport.height - 1)),
          speedRamp: vK
        }
      },
      NO = OO => {
        const KO = (0, FO.g)(OO, .2);
        return 0 !== KO.x || 0 !== KO.y
      },
      IO = (OO, KO) => {
        const pO = (0, FO.g)(OO, .2),
          XO = Math.hypot(pO.x, pO.y);
        if (0 === XO) return {
          x: 0,
          y: 0
        };
        const bK = XO * XO * 1600,
          eO = zK(KO, 0, 100) / 1e3;
        return {
          x: pO.x / XO * bK * eO,
          y: pO.y / XO * bK * eO
        }
      },
      yK = (OO, KO) => "y" === KO ? OO.scrollHeight > OO.clientHeight + 1 : OO.scrollWidth > OO.clientWidth + 1,
      gK = (OO, KO) => {
        const pO = getComputedStyle(OO),
          XO = "y" === KO ? pO.overflowY : pO.overflowX;
        return ("auto" === XO || "scroll" === XO) && yK(OO, KO)
      },
      uO = (OO, KO, pO) => {
        for (let eO = OO instanceof HTMLElement ? OO : null !== (XO = null === OO || void 0 === OO ? void 0 : OO.parentElement) && void 0 !== XO ? XO : null; eO; eO = eO.parentElement) {
          var XO;
          if (gK(eO, KO)) return eO;
          if (eO === pO) return null
        }
        if (pO) return null;
        const bK = document.scrollingElement;
        return bK instanceof HTMLElement && yK(bK, KO) ? bK : null
      },
      EO = new WeakMap,
      jK = (OO, KO) => {
        const pO = performance.now(),
          XO = EO.get(OO);
        if (XO && XO.axis === KO && pO - XO.atMs < 500 && (!XO.container || XO.container.isConnected)) return XO.container;
        const bK = YO(OO, KO);
        return EO.set(OO, {
          axis: KO,
          atMs: pO,
          container: bK
        }), bK
      },
      YO = (OO, KO) => {
        let pO = gK(OO, KO) ? OO : null,
          XO = pO ? pO.clientWidth * pO.clientHeight : 0;
        for (const bK of OO.querySelectorAll("*")) {
          const OO = bK.clientWidth * bK.clientHeight;
          OO > XO && gK(bK, KO) && (pO = bK, XO = OO)
        }
        return pO
      },
      wO = (OO, KO, pO) => "y" === KO ? pO < 0 ? OO.scrollTop > 0 : OO.scrollTop + OO.clientHeight < OO.scrollHeight - 1 : pO < 0 ? OO.scrollLeft > 0 : OO.scrollLeft + OO.clientWidth < OO.scrollWidth - 1,
      iK = (OO, KO, pO) => {
        "y" === KO ? OO.scrollBy({
          top: pO,
          behavior: "instant"
        }) : OO.scrollBy({
          left: pO,
          behavior: "instant"
        })
      },
      rK = OO => {
        if (!OO || OO === document.scrollingElement) return new DOMRect(0, 0, window.innerWidth, window.innerHeight);
        const KO = OO.getBoundingClientRect(),
          pO = Math.max(0, KO.left),
          XO = Math.max(0, KO.top);
        return new DOMRect(pO, XO, Math.min(window.innerWidth, KO.right) - pO, Math.min(window.innerHeight, KO.bottom) - XO)
      },
      PO = (OO, KO) => OO.left < KO.right && KO.left < OO.right && OO.top < KO.bottom && KO.top < OO.bottom;
    var mK = pO(63),
      sO = pO(918),
      HO = pO.n(sO),
      RO = pO(976);
    let SO = 0,
      JO = !1;
    class cK {
      constructor() {
        this.element = null, this.shownKey = "", this.gap = null
      }
      setElement(OO) {
        this.element = OO, this.shownKey = "", this.gap = null
      }
      show(OO) {
        const KO = this.element;
        if (!KO) return;
        const pO = OO ? this.keepOnScreen(KO, OO) : null,
          XO = pO ? `${pO.left},${pO.top},${pO.width},${pO.height}` : "";
        if (XO === this.shownKey) return;
        const bK = "" === this.shownKey;
        this.shownKey = XO, KO.classList.toggle("Visible", null !== pO), pO && (KO.classList.toggle("Snap", bK), KO.style.width = `${pO.width}px`, KO.style.height = `${pO.height}px`, KO.style.transform = `translate(${pO.left}px, ${pO.top}px)`, bK && (KO.offsetWidth, KO.classList.remove("Snap")))
      }
      hide() {
        this.show(null)
      }
      keepOnScreen(OO, KO) {
        var pO;
        const XO = `${window.innerWidth}x${window.innerHeight}@${(()=>{if("undefined"===typeof ResizeObserver)return getComputedStyle(document.documentElement).fontSize;if(!JO){JO=!0;const OO=document.createElement("div");OO.setAttribute("aria-hidden","true"),OO.style.cssText="position: fixed; top: 0; left: 0; width: 1rem; height: 0; visibility: hidden; pointer-events: none",document.body.appendChild(OO),new ResizeObserver((()=>{SO++})).observe(OO)}return String(SO)})()}`;
        (null === (pO = this.gap) || void 0 === pO ? void 0 : pO.key) !== XO && (this.gap = {
          px: parseFloat(getComputedStyle(OO).paddingLeft) || 0,
          key: XO
        });
        const bK = this.gap.px + 2,
          eO = Math.max(KO.left, bK),
          lO = Math.max(KO.top, bK),
          vK = Math.min(KO.left + KO.width, window.innerWidth - bK),
          CO = Math.min(KO.top + KO.height, window.innerHeight - bK);
        return vK <= eO || CO <= lO ? KO : {
          left: eO,
          top: lO,
          width: vK - eO,
          height: CO - lO
        }
      }
    }
    const BO = OO => {
      let {
        placer: KO,
        className: pO
      } = OO;
      const XO = (0, mK.useCallback)((OO => {
        KO.setElement(OO)
      }), [KO]);
      return (0, RO.jsx)("div", {
        ref: XO,
        className: HO()("PadReticle", pO),
        "aria-hidden": !0
      })
    };
    var ZO = pO(7757),
      GO = pO(1483);
    const qK = OO => OO >= 56320 && OO <= 57343,
      xK = OO => OO >= 55296 && OO <= 56319,
      nO = (OO, KO) => KO >= 2 && qK(OO.charCodeAt(KO - 1)) && xK(OO.charCodeAt(KO - 2)) ? KO - 2 : Math.max(0, KO - 1),
      WO = (OO, KO) => {
        let pO;
        var XO, bK;
        return pO = OO.start !== OO.end ? KO < 0 ? OO.start : OO.end : KO < 0 ? nO(OO.value, OO.start) : (XO = OO.value, (bK = OO.start) + 1 < XO.length && xK(XO.charCodeAt(bK)) && qK(XO.charCodeAt(bK + 1)) ? bK + 2 : Math.min(XO.length, bK + 1)), {
          value: OO.value,
          start: pO,
          end: pO
        }
      },
      tK = ["text", "search", "url", "email", "tel", "password", "number"],
      kK = OO => !(!(0, GO.d)(OO) || OO.isContentEditable || OO.hasAttribute("data-pad-no-osk")) && (OO instanceof HTMLTextAreaElement || OO instanceof HTMLInputElement && tK.includes(OO.type)),
      UO = OO => null !== OO.selectionStart,
      OK = OO => {
        var KO, pO;
        const {
          value: XO
        } = OO;
        return {
          value: XO,
          start: null !== (KO = OO.selectionStart) && void 0 !== KO ? KO : XO.length,
          end: null !== (pO = OO.selectionEnd) && void 0 !== pO ? pO : XO.length
        }
      },
      KK = (OO, KO, pO) => {
        if (OO.readOnly) return;
        const XO = OO instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        Object.getOwnPropertyDescriptor(XO, "value").set.call(OO, KO.value), UO(OO) && OO.setSelectionRange(KO.start, KO.end), (0, QO.f)(OO, new InputEvent("input", {
          bubbles: !0,
          inputType: pO
        }))
      };
    let pK = !1;
    const XK = (OO, KO) => !!document.execCommand(OO, !1, KO) || (pK || (pK = !0, console.warn(`execCommand("${OO}") failed; the on-screen keyboard is setting the value directly`)), !1),
      bp = (OO, KO) => {
        XK("insertText", KO) || KK(OO, function(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : -1;
          const XO = OO.value.slice(0, OO.start),
            bK = OO.value.slice(OO.end);
          let eO = pO < 0 ? KO.length : Math.max(0, pO - XO.length - bK.length);
          eO > 0 && eO < KO.length && xK(KO.charCodeAt(eO - 1)) && eO--;
          const lO = KO.slice(0, eO),
            vK = XO.length + lO.length;
          return {
            value: XO + lO + bK,
            start: vK,
            end: vK
          }
        }(OK(OO), KO, OO.maxLength), "insertText")
      },
      eK = OO => {
        XK("delete") || KK(OO, (OO => {
          const KO = OO.start === OO.end ? nO(OO.value, OO.start) : OO.start;
          return {
            value: OO.value.slice(0, KO) + OO.value.slice(OO.end),
            start: KO,
            end: KO
          }
        })(OK(OO)), "deleteContentBackward")
      },
      lK = (OO, KO) => {
        if (!UO(OO)) return;
        const pO = WO(OK(OO), KO);
        OO.setSelectionRange(pO.start, pO.end)
      },
      vp = ["button", "a[href]", "input:not([type=hidden])", "textarea", "select", "[role=button]", "[role=tab]", "[role=switch]", "[role=checkbox]", "[role=option]", "[role=menuitem]", "[data-pad-focusable]", "[data-pad-tab]", ".Dropdown-control", ".Dropdown-option"].join(","),
      CK = (OO, KO) => {
        if ("function" === typeof OO.checkVisibility) return !OO.checkVisibility({
          visibilityProperty: !0,
          checkVisibilityCSS: !0,
          opacityProperty: KO,
          checkOpacity: KO
        });
        const {
          visibility: pO
        } = getComputedStyle(OO);
        if ("hidden" === pO || "collapse" === pO) return !0;
        if (!KO) return !1;
        for (let XO = OO; XO; XO = XO.parentElement)
          if ("0" === getComputedStyle(XO).opacity) return !0;
        return !1
      },
      hK = OO => {
        if (!OO.isConnected || CK(OO, !0)) return !1;
        const KO = OO.getBoundingClientRect();
        return KO.width > 0 && KO.height > 0
      },
      DK = OO => !!OO.matches(":disabled, [aria-disabled='true']") || "button" === OO.getAttribute("role") && "-1" === OO.getAttribute("tabindex"),
      MK = OO => {
        var KO;
        if (OO.closest("[data-pad-ignore]")) return !0;
        return !!(null === (KO = OO.parentElement) || void 0 === KO ? void 0 : KO.closest("[data-pad-focusable]"))
      },
      ap = OO => {
        const KO = OO.querySelectorAll(vp);
        return OO.matches(vp) ? [OO, ...KO] : KO
      },
      oK = OO => {
        const KO = [];
        for (const pO of ap(OO)) !MK(pO) && hK(pO) && KO.push(pO);
        return KO
      },
      FK = new WeakMap,
      VK = OO => {
        const KO = FK.get(OO);
        if (KO && LK(KO, OO)) return !0;
        for (const pO of ap(OO))
          if (!MK(pO) && hK(pO)) return FK.set(OO, pO), !0;
        return FK.delete(OO), !1
      },
      LK = (OO, KO) => KO.contains(OO) && OO.matches(vp) && !MK(OO) && hK(OO),
      QK = (OO, KO) => LK(OO, KO) && !DK(OO),
      zp = OO => {
        const KO = KO => {
          let pO = 0;
          for (let XO = KO.parentElement; XO && XO !== OO; XO = XO.parentElement) pO++;
          return pO
        };
        return [...OO.querySelectorAll("[data-pad-initial-area]")].filter(hK).sort(((OO, pO) => KO(pO) - KO(OO)))
      },
      AK = OO => kK(OO),
      fK = OO => {
        const KO = OO.getBoundingClientRect();
        return {
          x: KO.left + KO.width / 2,
          y: KO.top + KO.height / 2
        }
      },
      dK = (OO, KO, pO) => ({
        bubbles: !0,
        cancelable: !0,
        composed: !0,
        view: window,
        clientX: OO.x,
        clientY: OO.y,
        screenX: OO.x,
        screenY: OO.y,
        button: KO,
        buttons: pO,
        pointerId: 1,
        pointerType: "mouse",
        isPrimary: !0
      }),
      TK = (OO, KO) => {
        (0, QO.f)(OO, KO)
      },
      NK = function(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        const XO = 0 === pO ? 1 : 2;
        TK(OO, new PointerEvent("pointerdown", dK(KO, pO, XO))), TK(OO, new MouseEvent("mousedown", dK(KO, pO, XO)))
      },
      IK = function(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        TK(OO, new PointerEvent("pointerup", dK(KO, pO, 0))), TK(OO, new MouseEvent("mouseup", dK(KO, pO, 0)))
      },
      yp = function(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        NK(OO, KO, pO), IK(OO, KO, pO), TK(OO, 0 === pO ? new MouseEvent("click", dK(KO, 0, 0)) : new MouseEvent("contextmenu", dK(KO, 2, 0)))
      },
      gp = function(OO, KO, pO) {
        let {
          leaveBelow: XO = null,
          enterBelow: bK = null
        } = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
        if (OO !== KO) {
          if (null !== OO && void 0 !== OO && OO.isConnected) {
            const bK = {
              ...dK(pO, 0, 0),
              relatedTarget: KO
            };
            TK(OO, new PointerEvent("pointerout", bK)), TK(OO, new MouseEvent("mouseout", bK));
            const eO = OO => !!KO && OO.contains(KO) || !!XO && OO.contains(XO);
            for (let KO = OO; KO && !eO(KO); KO = KO.parentElement) TK(KO, new PointerEvent("pointerleave", {
              ...bK,
              bubbles: !1
            })), TK(KO, new MouseEvent("mouseleave", {
              ...bK,
              bubbles: !1
            }))
          }
          if (KO) {
            const XO = {
              ...dK(pO, 0, 0),
              relatedTarget: OO
            };
            TK(KO, new PointerEvent("pointerover", XO)), TK(KO, new MouseEvent("mouseover", XO));
            const eO = [],
              lO = KO => !(null === OO || void 0 === OO || !OO.isConnected) && KO.contains(OO) || !!bK && KO.contains(bK);
            for (let OO = KO; OO && !lO(OO); OO = OO.parentElement) eO.push(OO);
            for (const OO of eO.reverse()) TK(OO, new PointerEvent("pointerenter", {
              ...XO,
              bubbles: !1
            })), TK(OO, new MouseEvent("mouseenter", {
              ...XO,
              bubbles: !1
            }));
            TK(KO, new PointerEvent("pointermove", dK(pO, 0, 0))), TK(KO, new MouseEvent("mousemove", dK(pO, 0, 0)))
          }
        } else KO && (TK(KO, new PointerEvent("pointermove", dK(pO, 0, 0))), TK(KO, new MouseEvent("mousemove", dK(pO, 0, 0))))
      },
      uK = OO => {
        hO.i.pl(ZO.h, OO)
      },
      EK = OO => {
        if (AK(OO)) return void uK(OO);
        const KO = OO.hasAttribute("data-pad-focusable") ? OO.querySelector("a[href]") : null,
          pO = null !== KO && void 0 !== KO ? KO : OO;
        yp(pO, fK(pO))
      },
      jp = ".Dropdown-root.is-open",
      YK = OO => {
        const KO = OO.querySelector(".Dropdown-control");
        return EK(KO), KO
      },
      wK = OO => {
        var KO;
        const pO = null !== (KO = OO.closest(jp)) && void 0 !== KO ? KO : OO.querySelector(jp);
        return pO ? YK(pO) : null
      },
      ip = OO => {
        for (const KO of document.querySelectorAll(jp)) KO.contains(OO) || YK(KO)
      },
      rp = OO => null !== OO.closest("input[type=color], input[type=file], [data-pad-mouse-only]"),
      PK = OO => {
        const KO = OO ? document.elementFromPoint(OO.x, OO.y) : null;
        return !(null === KO || void 0 === KO || !KO.closest("[data-pad-repeat]"))
      },
      mp = OO => {
        var KO;
        return null !== (KO = [...OO.querySelectorAll("[data-pad-back]")].find(hK)) && void 0 !== KO ? KO : null
      },
      sK = OO => {
        const KO = mp(OO);
        return !!KO && (EK(KO), !0)
      },
      HK = OO => {
        var KO, pO, XO, bK;
        return null !== (KO = null !== (pO = null !== (XO = OO.getAttribute("data-pad-key")) && void 0 !== XO ? XO : OO.getAttribute("href")) && void 0 !== pO ? pO : null === (bK = OO.querySelector("a[href]")) || void 0 === bK ? void 0 : bK.getAttribute("href")) && void 0 !== KO ? KO : null
      },
      RK = {
        x: 0,
        y: 0,
        visible: !1,
        pressed: !1
      };
    const SK = new class {
        constructor() {
          this.state = RK, this.listeners = new Set
        }
        get() {
          return this.state
        }
        set(OO) {
          if (KO = this.state, pO = OO, (KO.visible || pO.visible) && (KO.visible !== pO.visible || KO.x !== pO.x || KO.y !== pO.y || KO.pressed !== pO.pressed)) {
            var KO, pO;
            this.state = OO;
            for (const KO of this.listeners) KO(OO)
          }
        }
        hide() {
          this.set(RK)
        }
        subscribe(OO) {
          return this.listeners.add(OO), () => {
            this.listeners.delete(OO)
          }
        }
      },
      JK = (OO, KO) => {
        let {
          kind: pO,
          holding: XO,
          hasPress: bK,
          hasBack: eO,
          slotHasItem: lO
        } = KO;
        switch (OO) {
          case "primary":
            return "slot" === pO ? "slotPrimary" : "recipe" === pO || "button" === pO ? bK ? "pressPrimary" : "click" : "textField" === pO ? "openKeyboard" : null;
          case "secondary":
            return "slot" === pO ? "slotSecondary" : "button" !== pO && "recipe" !== pO || !bK ? null : "pressSecondary";
          case "quickMove":
            return "slot" === pO && lO ? "slotQuickMove" : null;
          case "hotbarSwap":
            return "slot" === pO && lO && !XO ? "hotbarPick" : null;
          case "openButton":
            return "close";
          case "back":
            return XO ? "cancel" : eO ? "pressBack" : "close"
        }
      },
      cp = OO => {
        const KO = [];
        if (OO.hotbarPicking) return KO.push({
          actions: ["inventoryPrimary", "inventoryHotbarSwap"],
          labelKey: "inventorySwapHere"
        }), KO.push({
          actions: ["inventoryClose"],
          labelKey: "inventoryCancel"
        }), KO;
        if (OO.holding) "slot" === OO.kind ? (KO.push({
          actions: ["inventoryPrimary"],
          labelKey: "inventoryPlace"
        }), KO.push({
          actions: ["inventorySecondary"],
          labelKey: "inventoryPlaceOne"
        })) : "textField" === OO.kind && KO.push({
          actions: ["inventoryPrimary"],
          labelKey: "inventoryType"
        }), KO.push({
          actions: ["inventoryClose"],
          labelKey: "inventoryPutBack"
        }), KO.push({
          actions: ["inventoryDrop"],
          labelKey: "inventoryDrop"
        }), OO.openButtonCloses && KO.push({
          actions: ["inventory"],
          labelKey: "inventoryClose"
        });
        else {
          var pO;
          "slot" === OO.kind && OO.slotHasItem ? (KO.push({
            actions: ["inventoryPrimary"],
            labelKey: "inventoryTake"
          }), KO.push({
            actions: ["inventorySecondary"],
            labelKey: "inventoryTakeHalf"
          }), KO.push({
            actions: ["inventoryQuickMove"],
            labelKey: OO.quickMoveToHotbar ? "inventoryToHotbar" : "inventoryQuickMove"
          }), KO.push({
            actions: ["inventoryHotbarSwap"],
            labelKey: "inventoryHotbarSwap"
          }), KO.push({
            actions: ["inventoryDrop"],
            labelKey: "inventoryDrop"
          })) : "button" !== OO.kind && "recipe" !== OO.kind || !OO.pressHints ? "button" === OO.kind || "recipe" === OO.kind ? KO.push({
            actions: ["inventoryPrimary"],
            labelKey: "inventorySelect"
          }) : "textField" === OO.kind && KO.push({
            actions: ["inventoryPrimary"],
            labelKey: "inventoryType"
          }) : (OO.pressHints.primary && KO.push({
            actions: ["inventoryPrimary"],
            labelKey: OO.pressHints.primary
          }), OO.pressHints.secondary && KO.push({
            actions: ["inventorySecondary"],
            labelKey: OO.pressHints.secondary
          }));
          const XO = null === (pO = OO.pressHints) || void 0 === pO ? void 0 : pO.back;
          XO && KO.push({
            actions: ["inventoryClose"],
            labelKey: XO
          });
          const bK = [];
          OO.openButtonCloses && bK.push("inventory"), XO || bK.push("inventoryClose"), bK.length > 0 && KO.push({
            actions: bK,
            labelKey: "inventoryClose"
          })
        }
        return KO.push({
          actions: ["inventoryPanelPrevious", "inventoryPanelNext"],
          labelKey: "inventoryPanels"
        }), OO.hasCategories ? KO.push({
          actions: ["menuPageUp", "menuPageDown"],
          labelKey: "inventoryCategory"
        }) : OO.hasList && KO.push({
          actions: ["menuPageUp", "menuPageDown"],
          labelKey: "inventoryPage"
        }), KO
      };
    var BK = pO(7762);
    const ZK = OO => ({
        x: OO.left + OO.width / 2,
        y: OO.top + OO.height / 2
      }),
      GK = (OO, KO, pO) => OO < 0 ? pO >= 0 ? 0 : KO - 1 : ((OO + pO) % KO + KO) % KO,
      qp = OO => "Left" === OO || "Right" === OO,
      xp = (OO, KO, pO) => {
        const XO = qp(pO),
          bK = XO ? OO.top : OO.left,
          eO = XO ? OO.height : OO.width,
          lO = XO ? KO.top : KO.left,
          vK = XO ? KO.height : KO.width,
          CO = Math.max(0, Math.max(lO - (bK + eO), bK - (lO + vK)));
        return eO > 1.5 * vK ? {
          gap: CO,
          offset: Math.max(0, lO - bK) + .1 * Math.max(0, bK - lO)
        } : {
          gap: CO,
          offset: Math.abs(lO + vK / 2 - (bK + eO / 2))
        }
      },
      nK = (OO, KO, pO) => {
        const XO = ((OO, KO, pO) => {
          const XO = ZK(OO),
            bK = ZK(KO),
            eO = qp(pO) ? Math.min(OO.width, KO.width) / 4 : Math.min(OO.height, KO.height) / 4;
          switch (pO) {
            case "Right":
              return bK.x - XO.x >= eO ? Math.max(0, KO.left - (OO.left + OO.width)) : null;
            case "Left":
              return XO.x - bK.x >= eO ? Math.max(0, OO.left - (KO.left + KO.width)) : null;
            case "Down":
              return bK.y - XO.y >= eO ? Math.max(0, KO.top - (OO.top + OO.height)) : null;
            case "Up":
              return XO.y - bK.y >= eO ? Math.max(0, OO.top - (KO.top + KO.height)) : null
          }
        })(OO, KO, pO);
        if (null === XO) return null;
        const bK = xp(OO, KO, pO);
        return XO + 3 * bK.gap + .5 * bK.offset
      },
      WK = (OO, KO) => KO.visible || null !== KO.scrollGroup && KO.scrollGroup === OO.scrollGroup,
      tp = (OO, KO, pO, XO) => {
        let bK = null,
          eO = 1 / 0;
        for (const lO of KO) {
          if (lO.key === OO.key || !WK(OO, lO) || !XO(lO)) continue;
          const KO = nK(OO.rect, lO.rect, pO);
          null !== KO && KO < eO && (bK = lO, eO = KO)
        }
        return bK
      },
      kp = (OO, KO, pO) => {
        const XO = tp(OO, KO, pO, (() => !0));
        if (!XO || qp(pO) || null === OO.scrollGroup || XO.scrollGroup === OO.scrollGroup) return XO;
        const bK = tp(OO, KO, pO, (KO => 0 === xp(OO.rect, KO.rect, pO).gap));
        return null !== bK && void 0 !== bK ? bK : XO
      },
      UK = (OO, KO, pO) => {
        let XO = null,
          bK = 1 / 0;
        for (const eO of KO) {
          if (!eO.visible || pO && !pO(eO)) continue;
          const KO = ZK(eO.rect),
            lO = Math.hypot(KO.x - OO.x, KO.y - OO.y);
          lO < bK && (XO = eO, bK = lO)
        }
        return XO
      },
      Op = (OO, KO) => {
        let pO = null;
        for (const XO of KO) {
          const {
            left: KO,
            top: bK,
            width: eO,
            height: lO
          } = XO.rect;
          !XO.visible || OO.x < KO || OO.x >= KO + eO || OO.y < bK || OO.y >= bK + lO || (!pO || eO * lO < pO.rect.width * pO.rect.height) && (pO = XO)
        }
        return pO
      },
      Kp = OO => {
        let KO = null;
        for (const pO of OO) {
          if (!pO.visible) continue;
          if (!KO) {
            KO = pO;
            continue
          }
          const OO = Math.min(KO.rect.height, pO.rect.height) / 2,
            XO = pO.rect.top - KO.rect.top;
          (XO < -OO || Math.abs(XO) <= OO && pO.rect.left < KO.rect.left) && (KO = pO)
        }
        return KO
      },
      pp = (OO, KO, pO, XO, bK) => {
        const eO = bK % KO,
          lO = Math.floor(bK / KO);
        return {
          left: OO.left + eO * pO,
          top: OO.top + lO * XO,
          width: OO.width,
          height: OO.height
        }
      },
      Xp = ".EntireInventoryWrapper .Inventory, .HotBarGameItemsContainer",
      bX = ".LazyLoadedItemWrapper",
      ep = ["[data-inven-idx]", "[data-recipe-key]", "[role=button]", "button", "input:not([type=hidden])", "textarea", ".CreativeCategoryTab", ".CreativeCategoryDropdownButton", ".CreativeCategoryDropdownOption", "[data-craft-ingredient]"].join(","),
      lp = [
        ["hotbar", ".HotBarGameItemsContainer"],
        ["gameButtons", ".ClientGameInventoryButtons"],
        ["categories", ".CreativeCategoryRail"],
        ["recipe", ".CraftableInfo"],
        ["armour", ".ArmourItemSlots"],
        ["main", ".InvenBodyRight"],
        ["left", ".InvenLeftSide"]
      ],
      vX = ["gameButtons", "categories", "left", "recipe", "armour", "main", "hotbar"],
      Cp = new WeakMap;
    let hp = 0;
    const Dp = OO => {
        let KO = Cp.get(OO);
        return KO || (KO = "el:" + hp++, Cp.set(OO, KO)), KO
      },
      Mp = OO => ({
        left: OO.left,
        top: OO.top,
        width: OO.width,
        height: OO.height
      }),
      aX = (OO, KO) => OO.width > 0 && OO.height > 0 && OO.left + OO.width > 0 && OO.top + OO.height > 0 && OO.left < KO.width && OO.top < KO.height,
      op = OO => OO.hasAttribute("data-inven-idx") ? "slot" : OO.hasAttribute("data-recipe-key") ? "recipe" : OO.hasAttribute("data-craft-ingredient") || DK(OO) ? "info" : AK(OO) ? "textField" : "button",
      Fp = (OO, KO) => "slot" === KO ? Number(OO.getAttribute("data-inven-idx")) : null,
      Vp = OO => OO.matches(bX) ? OO.querySelector(ep) : OO,
      Lp = OO => {
        var KO, pO;
        return {
          element: OO,
          recipe: null !== (KO = OO && (null === (pO = Vp(OO)) || void 0 === pO ? void 0 : pO.getAttribute("data-recipe-key"))) && void 0 !== KO ? KO : null
        }
      },
      Qp = OO => {
        const KO = Vp(OO);
        if (!KO) return {
          kind: "pending",
          idx: null
        };
        const pO = op(KO);
        return {
          kind: pO,
          idx: Fp(KO, pO)
        }
      },
      zX = OO => {
        const KO = [];
        for (const [pO, XO] of lp) {
          OO.matches(XO) && KO.push([pO, OO]);
          for (const bK of OO.querySelectorAll(XO)) KO.push([pO, bK])
        }
        return KO
      },
      Ap = (OO, KO) => {
        for (const [pO, XO] of OO)
          if (XO.contains(KO)) return pO;
        return "other"
      },
      fp = (OO, KO, pO, XO, bK, eO, lO) => {
        var vK;
        const CO = OO.children,
          hO = Mp(CO[0].getBoundingClientRect()),
          DO = [{
            element: CO[0],
            rect: hO
          }];
        if (eO.push(DO[0]), 0 === hO.width || 0 === hO.height) return;
        let MO = 1;
        for (; MO < CO.length && Math.abs(CO[MO].getBoundingClientRect().top - hO.top) < 1;) MO++;
        const aK = OO => {
            const KO = {
              element: CO[OO],
              rect: Mp(CO[OO].getBoundingClientRect())
            };
            return eO.push(KO), DO.push(KO), KO.rect
          },
          oO = MO > 1 ? aK(1).left - hO.left : hO.width,
          FO = CO.length > MO ? aK(MO).top - hO.top : hO.height,
          VO = uO(OO, "y", KO),
          LO = VO === document.scrollingElement ? null : VO;
        LO && eO.push({
          element: LO,
          rect: Mp(LO.getBoundingClientRect())
        });
        const QO = LO ? rK(LO) : null,
          zK = LO ? Dp(LO) : null;
        let AO = null;
        var fO;
        LO && QO && (AO = null !== (fO = lO.get(LO)) && void 0 !== fO ? fO : null, AO || (AO = {
          top: LO.scrollTop,
          left: LO.scrollLeft,
          box: QO,
          viewport: XO,
          targets: [],
          probes: [],
          holdsOthers: !1
        }, lO.set(LO, AO)), AO.probes.push(...DO));
        const dO = bK.length;
        for (let TO = 0; TO < CO.length; TO++) {
          const OO = CO[TO],
            KO = pp(hO, MO, oO, FO, TO),
            eO = KO.top + KO.height / 2,
            lO = OO.firstElementChild ? OO.querySelector(ep) : null,
            vK = lO ? op(lO) : "pending";
          bK.push({
            key: Dp(OO),
            rect: KO,
            panel: pO,
            scrollGroup: zK,
            visible: aX(KO, XO) && (!QO || eO >= QO.top && eO <= QO.bottom),
            element: OO,
            kind: vK,
            idx: lO ? Fp(lO, vK) : null,
            scrollContainer: LO
          })
        }
        null === (vK = AO) || void 0 === vK || vK.targets.push(...bK.slice(dO))
      };
    class dp {
      constructor() {
        this.latched = null, this.presses = 0
      }
      press(OO, KO, pO, XO) {
        this.latched = {
          source: OO,
          focusKey: KO,
          sinceMs: pO,
          hold: {
            id: ++this.presses,
            holdMs: XO
          }
        }
      }
      update(OO, KO, pO) {
        const XO = this.latched;
        return XO ? OO && KO === XO.focusKey ? pO - XO.sinceMs < XO.hold.holdMs ? null : (this.latched = null, XO.source) : (this.latched = null, null) : null
      }
      getHold() {
        var OO, KO;
        return null !== (OO = null === (KO = this.latched) || void 0 === KO ? void 0 : KO.hold) && void 0 !== OO ? OO : null
      }
      reset() {
        this.latched = null
      }
    }
    var Tp = pO(7768);
    const Np = {
        kind: "none"
      },
      Ip = OO => ({
        x: OO.clientX,
        y: OO.clientY
      }),
      yX = () => 2 * (parseFloat(getComputedStyle(document.documentElement).fontSize) || 16);
    class gX {
      constructor() {
        this.hovered = Np, this.signature = "", this.holding = !1, this.lastPoint = {
          clientX: 0,
          clientY: 0
        }
      }
      sync(OO, KO, pO, XO, bK) {
        const eO = null !== KO ? {
            kind: "slot",
            idx: KO
          } : pO ? {
            kind: "element",
            element: pO
          } : Np,
          lO = `${bK}|${Math.round(XO.clientX)},${Math.round(XO.clientY)}`,
          vK = (CO = this.hovered, hO = eO, "slot" === CO.kind && "slot" === hO.kind ? CO.idx === hO.idx : "element" === CO.kind && "element" === hO.kind ? CO.element === hO.element : CO.kind === hO.kind);
        var CO, hO;
        if (vK && lO === this.signature) return;
        const DO = !vK || bK !== this.holding || "" === this.signature;
        this.signature = lO, this.holding = bK, this.lastPoint = XO;
        const MO = this.hovered;
        if (this.hovered = eO, "slot" === eO.kind) return this.leaveElement(MO, null, XO), void(DO ? OO.hover(eO.idx, XO) : OO.moveTo(XO));
        if (vK) return void("element" === eO.kind ? gp(eO.element, eO.element, Ip(XO)) : OO.hover(null, XO));
        OO.hover(null, XO);
        const aK = "element" === eO.kind ? eO.element : null;
        "element" === MO.kind ? gp(MO.element, aK, Ip(XO)) : aK && gp(null, aK, Ip(XO))
      }
      invalidate() {
        this.signature = ""
      }
      clear(OO) {
        const KO = this.hovered;
        this.hovered = Np, this.signature = "", "none" !== KO.kind && (this.leaveElement(KO, null, this.lastPoint), OO && "slot" === KO.kind && OO.hover(null, this.lastPoint))
      }
      leaveElement(OO, KO, pO) {
        "element" === OO.kind && gp(OO.element, KO, Ip(pO))
      }
    }
    class upO {
      constructor() {
        this.lastTiltedMs = -1 / 0
      }
      update(OO, KO) {
        NO(OO) && (this.lastTiltedMs = KO)
      }
      allowsClick(OO) {
        return OO - this.lastTiltedMs > 150
      }
    }
    class Ep {
      constructor() {
        this.remainder = 0, this.container = null
      }
      isScrolling(OO) {
        return 0 !== (0, FO.g)(OO, .2).y
      }
      step(OO, KO, pO) {
        OO !== this.container && (this.container = OO, this.remainder = 0);
        const XO = IO(KO, pO).y;
        if (0 === XO) return this.remainder = 0, !1;
        const bK = this.remainder + XO,
          eO = Math.trunc(bK);
        if (this.remainder = bK - eO, 0 === eO) return !1;
        const lO = OO.scrollTop;
        return OO.scrollTop = lO + eO, OO.scrollTop !== lO
      }
      reset() {
        this.remainder = 0, this.container = null
      }
    }
    var jX = pO(7775);
    const Yp = "[data-pad-inventory-default]",
      wp = ".HotBarGameItemsContainer .InvenItem.Selected",
      iX = {
        Up: {
          x: 0,
          y: -1
        },
        Down: {
          x: 0,
          y: 1
        },
        Left: {
          x: -1,
          y: 0
        },
        Right: {
          x: 1,
          y: 0
        }
      },
      rX = [
        ["primary", "inventoryPrimary"],
        ["secondary", "inventorySecondary"],
        ["quickMove", "inventoryQuickMove"],
        ["hotbarSwap", "inventoryHotbarSwap"],
        ["back", "inventoryClose"],
        ["openButton", "inventory"]
      ],
      Pp = ["inventoryPrimary", "inventorySecondary", "inventoryQuickMove", "inventoryHotbarSwap", "inventoryClose", "inventoryDrop"],
      mX = ["inventoryPanelPrevious", "inventoryPanelNext", "menuPageUp", "menuPageDown"],
      sp = [...Pp, ...mX],
      Hp = () => {
        return OO = (0, DO.j)("inventory"), !sp.map(DO.j).includes(OO) && !(0, FO.H)(OO);
        var OO
      },
      Rp = new Set(["slotPrimary", "slotSecondary", "slotQuickMove", "pressPrimary", "pressSecondary", "openKeyboard"]),
      Sp = (OO, KO) => {
        const pO = !(null === KO || void 0 === KO || !KO.isHolding());
        return function(OO, KO) {
          const pO = OO.find((OO => OO.visible && KO(OO)));
          if (pO) return pO;
          for (var XO = arguments.length, bK = new Array(XO > 2 ? XO - 2 : 0), eO = 2; eO < XO; eO++) bK[eO - 2] = arguments[eO];
          for (const lO of bK) {
            const KO = Kp(OO.filter(lO));
            if (KO) return KO
          }
          return Kp(OO)
        }(OO, (OO => {
          const {
            element: KO
          } = OO;
          return KO.matches(Yp) || null !== KO.querySelector(Yp) || KO.matches(wp)
        }), (OO => "slot" === OO.kind ? pO || null !== OO.idx && !(null === KO || void 0 === KO || !KO.hasItemAt(OO.idx)) : "recipe" === OO.kind || "pending" === OO.kind), (OO => "slot" === OO.kind || "button" === OO.kind))
      };
    class Jp {
      constructor() {
        this.set = null, this.observer = new MutationObserver((OO => {
          OO.some((OO => {
            return !((KO = OO.target) instanceof Element && null !== KO.closest(bX));
            var KO
          })) && (this.set = null)
        })), this.invalidate = () => {
          this.set = null
        }, this.onScroll = OO => {
          this.scrolled(OO.target)
        }
      }
      get() {
        if (!this.set) {
          this.set = (() => {
            const OO = [],
              KO = [];
            let pO = !1;
            const XO = {
                width: window.innerWidth,
                height: window.innerHeight
              },
              bK = new Map;
            for (const vK of document.querySelectorAll(Xp)) {
              const lO = zX(vK);
              pO ||= null !== vK.querySelector(".CreativeCategoryTab");
              for (const pO of vK.querySelectorAll(`${bX}:first-child`)) {
                const eO = pO.parentElement;
                fp(eO, vK, Ap(lO, eO), XO, OO, KO, bK)
              }
              for (const pO of vK.querySelectorAll(ep)) {
                var eO;
                if (pO.closest(bX) || pO.closest("[data-pad-ignore]")) continue;
                const bK = null === (eO = pO.parentElement) || void 0 === eO ? void 0 : eO.closest(ep);
                if (bK && vK.contains(bK)) continue;
                const CO = op(pO),
                  hO = Fp(pO, CO);
                if (-1 === hO) continue;
                const DO = Mp(pO.getBoundingClientRect());
                KO.push({
                  element: pO,
                  rect: DO
                }), aX(DO, XO) && OO.push({
                  key: Dp(pO),
                  rect: DO,
                  panel: Ap(lO, pO),
                  scrollGroup: null,
                  visible: !0,
                  element: pO,
                  kind: CO,
                  idx: hO,
                  scrollContainer: null
                })
              }
            }
            for (const [vK, CO] of bK) CO.holdsOthers = KO.some((OO => OO.element !== vK && vK.contains(OO.element) && !OO.element.closest(bX)));
            const lO = new Map;
            for (const vK of OO) lO.set(vK.element, vK);
            return {
              targets: OO,
              byElement: lO,
              hasCategories: pO,
              probes: KO,
              scrollers: bK
            }
          })(), this.observer.disconnect();
          for (const OO of document.querySelectorAll(Xp)) this.observer.observe(OO, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeFilter: ["class", "disabled", "aria-disabled", "tabindex", "data-inven-idx"]
          })
        }
        return this.set
      }
      scrolled(OO) {
        !this.set || OO instanceof Element && ((OO, KO) => {
          const pO = OO.scrollers.get(KO);
          if (!pO || pO.holdsOthers || KO.scrollLeft !== pO.left) return !1;
          const XO = KO.scrollTop - pO.top;
          if (0 === XO) return !0;
          pO.top = KO.scrollTop;
          for (const bK of pO.probes) bK.rect.top -= XO;
          for (const bK of pO.targets) {
            bK.rect.top -= XO;
            const OO = bK.rect.top + bK.rect.height / 2;
            bK.visible = aX(bK.rect, pO.viewport) && OO >= pO.box.top && OO <= pO.box.bottom
          }
          return !0
        })(this.set, OO) || (this.set = null)
      }
      revalidate() {
        this.set && this.set.probes.some((OO => {
          return KO = OO.rect, pO = OO.element.getBoundingClientRect(), !(KO.left === pO.left && KO.top === pO.top && KO.width === pO.width && KO.height === pO.height);
          var KO, pO
        })) && (this.set = null)
      }
      disconnect() {
        this.observer.disconnect(), this.set = null
      }
    }
    const cX = new class {
        constructor() {
          this.focused = null, this.focusTarget = null, this.lastRect = null, this.panelMemory = new Map, this.reopenSlotIdx = null, this.dpadTimers = new Map(FO.z.map((OO => [OO, (0, VO.b)(FO.D)]))), this.stickRepeat = new FO.b((0, VO.b)(FO.ib)), this.pageUpTimer = (0, VO.b)(FO.bb), this.pageDownTimer = (0, VO.b)(FO.bb), this.stickGate = new dO, this.pointer = null, this.activePress = null, this.dropLatch = new dp, this.scroller = new Ep, this.scrollStickClick = new upO, this.hover = new gX, this.lastRealPointer = null, this.placeAfterCategory = null, this.hotbarPick = null, this.ring = new cK, this.targets = new Jp, this.hasCategories = !1, this.wasShowing = !1, this.state = Tp.c, this.isActive = () => (0, BK.f)(), this.isShowing = () => "inventory" === MO.c.getActiveConsumerName() && (0, oO.o)(), this.getState = () => this.state, this.isSteppingSlots = () => this.isShowing() && null === this.pointer, this.onDeactivate = () => {
            this.endInteraction((0, BK.e)()), (0, BK.f)() || this.forgetSurface()
          }, this.forgetSurface = () => {
            var OO;
            this.reopenSlotIdx = null !== (OO = this.focused ? Qp(this.focused).idx : null) && void 0 !== OO ? OO : this.reopenSlotIdx, this.focused = null, this.focusTarget = null, this.lastRect = null, this.placeAfterCategory = null, (0, BK.o)(), this.panelMemory.clear(), this.targets.disconnect()
          }, this.onFrame = OO => {
            (0, vK.unstable_batchedUpdates)((() => {
              this.frame(OO)
            }))
          }, this.shouldBlockRealPointer = OO => OO.isTrusted && !(0, QO.s)(OO) && this.isShowing(), this.noteRealPointer = OO => {
            OO instanceof MouseEvent && OO.isTrusted && !(0, QO.s)(OO) && (this.lastRealPointer ??= {
              x: 0,
              y: 0
            }, this.lastRealPointer.x = OO.clientX, this.lastRealPointer.y = OO.clientY)
          }, this.wakePressActs = OO => {
            var KO;
            return OO === (0, DO.j)("inventoryClose") ? !(null !== (KO = (0, BK.e)()) && void 0 !== KO && KO.isHolding()) : !(OO !== (0, DO.j)("inventory") || !Hp()) || ((0, FO.H)(OO) ? this.isNavButton(OO) : mX.some((KO => (0, DO.j)(KO) === OO)))
          }
        }
        frame(OO) {
          var KO, pO, XO, bK, eO, lO;
          const vK = (0, BK.e)();
          if (!(0, oO.o)()) return void(this.wasShowing && (this.endInteraction(vK), this.rehoverRealPointer()));
          this.wasShowing = !0, this.applyFocusRequest(), OO.wokeDevice && this.focusWakePointer(!(null === vK || void 0 === vK || !vK.isHolding())), this.applyCategoryPlace(), this.ensureFocus(), "cursor" !== (0, aK.i)().inventoryNavigation || this.pointer || this.engagePointer();
          const CO = performance.now();
          this.handleNavigation(OO, CO), this.handlePanels(OO), this.handlePaging(OO, CO), this.handleScroll(OO), this.handleButtons(OO, CO, vK), this.applyFocusRequest(), this.pointer && this.hoverAtPointer();
          const hO = this.ensureFocus(),
            MO = this.focusContext(vK);
          this.ring.show(hO);
          const FO = "slot" === MO.kind ? MO.idx : null,
            VO = null !== (KO = null === (pO = MO.actionElement) || void 0 === pO ? void 0 : pO.querySelector(".DoCraftItem")) && void 0 !== KO ? KO : MO.actionElement;
          this.pointer ? (this.hover.sync(vK, FO, VO, ((OO, KO) => {
            const pO = KO ? yX() : 0;
            return {
              clientX: OO.x - pO,
              clientY: OO.y - pO
            }
          })(this.pointer, MO.holding), MO.holding), SK.set({
            x: this.pointer.x,
            y: this.pointer.y,
            visible: !0,
            pressed: OO.isHeld((0, DO.j)("inventoryPrimary"))
          })) : hO && this.focused && this.hover.sync(vK, FO, VO, ((OO, KO) => {
            if (!KO) return {
              clientX: OO.left + OO.width - 10,
              clientY: OO.top + OO.height / 2 - 10
            };
            const pO = yX();
            return {
              clientX: OO.left + OO.width / 2 - pO,
              clientY: OO.top + OO.height / 2 - pO
            }
          })(hO, MO.holding), MO.holding), this.publishState({
            showing: !0,
            kind: MO.kind,
            holding: MO.holding,
            slotHasItem: MO.slotHasItem,
            pressHints: null !== (XO = null === (bK = MO.press) || void 0 === bK ? void 0 : bK.hints) && void 0 !== XO ? XO : null,
            hasCategories: this.hasCategories,
            hasList: !(null === (eO = this.focusTarget) || void 0 === eO || !eO.scrollGroup),
            openButtonCloses: Hp(),
            steppingSlots: null === this.pointer,
            quickMoveToHotbar: "slot" === MO.kind && !(null === (lO = MO.actionElement) || void 0 === lO || !lO.closest(".CreativeItemSlots")),
            dropStackHold: this.dropLatch.getHold(),
            hotbarPicking: null !== this.hotbarPick
          })
        }
        focusWakePointer(OO) {
          var KO;
          const pO = (0, oO.e)();
          if (!pO) return;
          this.targets.revalidate();
          const XO = this.getTargets().targets;
          this.setFocus(null !== (KO = Op(pO, XO)) && void 0 !== KO ? KO : OO ? UK(pO, XO, (OO => {
            let {
              rect: KO
            } = OO;
            const XO = Math.max(KO.left - pO.x, 0, pO.x - (KO.left + KO.width)),
              bK = Math.max(KO.top - pO.y, 0, pO.y - (KO.top + KO.height));
            return Math.hypot(XO, bK) <= Math.min(KO.width, KO.height) / 2
          })) : null, !1), "cursor" === (0, aK.i)().inventoryNavigation && (this.pointer = {
            x: pO.x,
            y: pO.y,
            speedRamp: 0
          })
        }
        rehoverRealPointer() {
          const OO = this.lastRealPointer;
          if (!OO || "keyboardMouse" !== CO.d.get("activeInputDevice")) return;
          const KO = document.elementFromPoint(OO.x, OO.y);
          KO && gp(null, KO, OO)
        }
        endInteraction(OO) {
          this.wasShowing = !1, this.hotbarPick = null, this.releasePress(), this.dropLatch.reset(), this.scroller.reset();
          for (const KO of this.dpadTimers.values()) KO.reset();
          this.stickRepeat.reset(), this.pageUpTimer.reset(), this.pageDownTimer.reset(), this.hover.clear(OO), this.ring.hide(), this.releasePointer(), this.publishState(Tp.c)
        }
        getTargets() {
          const OO = this.targets.get();
          return this.hasCategories = OO.hasCategories, OO
        }
        currentTarget() {
          var OO;
          return this.focused && null !== (OO = this.getTargets().byElement.get(this.focused)) && void 0 !== OO ? OO : null
        }
        readFocusRect() {
          const OO = this.focused;
          if (null === OO || void 0 === OO || !OO.isConnected || !OO.closest(Xp)) return null;
          const KO = OO.getBoundingClientRect();
          return KO.width > 0 && KO.height > 0 ? {
            left: KO.left,
            top: KO.top,
            width: KO.width,
            height: KO.height
          } : null
        }
        ensureFocus() {
          const OO = this.readFocusRect();
          if (OO || this.pointer) return OO;
          const {
            targets: KO,
            byElement: pO
          } = this.getTargets();
          let XO = null,
            bK = !1;
          if (this.lastRect) XO = UK(ZK(this.lastRect), KO);
          else {
            var eO, lO;
            const OO = ((OO, KO) => {
                const pO = document.querySelector(".EntireInventoryWrapper [data-pad-inventory-start]");
                return pO ? Sp(OO.filter((OO => pO.contains(OO.element))), KO) : null
              })(KO, (0, BK.e)()),
              vK = KO.find((OO => null !== OO.idx && OO.idx === this.reopenSlotIdx)),
              CO = document.querySelector(wp);
            bK = null !== OO || void 0 !== vK, XO = null !== (eO = null !== (lO = null !== OO && void 0 !== OO ? OO : vK) && void 0 !== lO ? lO : CO && pO.get(CO)) && void 0 !== eO ? eO : Kp(KO)
          }
          return this.setFocus(XO, bK), this.lastRect
        }
        setFocus(OO) {
          let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          OO && (this.focused = OO.element, this.focusTarget = OO, this.panelMemory.set(OO.panel, OO.element), KO && OO.scrollContainer && ((OO, KO) => {
            const pO = OO.getBoundingClientRect(),
              XO = KO.getBoundingClientRect(),
              bK = KO.scrollTop;
            return pO.top < XO.top ? KO.scrollTop -= XO.top - pO.top : pO.bottom > XO.bottom && (KO.scrollTop += pO.bottom - XO.bottom), KO.scrollTop !== bK
          })(OO.element, OO.scrollContainer) && this.targets.invalidate(), this.lastRect = this.readFocusRect(), this.followFocusJump())
        }
        followFocusJump() {
          if (this.pointer)
            if ("cursor" === (0, aK.i)().inventoryNavigation) {
              if (this.lastRect) {
                const OO = ZK(this.lastRect);
                this.pointer = {
                  x: OO.x,
                  y: OO.y,
                  speedRamp: 0
                }
              }
            } else this.releasePointer()
        }
        engagePointer() {
          const OO = this.lastRect ? ZK(this.lastRect) : {
            x: window.innerWidth / 2,
            y: window.innerHeight / 2
          };
          this.pointer = {
            x: OO.x,
            y: OO.y,
            speedRamp: 0
          }
        }
        releasePointer() {
          this.pointer = null, SK.hide()
        }
        hoverAtPointer() {
          var OO;
          const KO = Op(this.pointer, this.getTargets().targets);
          (null === KO || void 0 === KO ? void 0 : KO.element) !== this.focused && (this.focused = null !== (OO = null === KO || void 0 === KO ? void 0 : KO.element) && void 0 !== OO ? OO : null, this.focusTarget = KO, KO && (this.panelMemory.set(KO.panel, KO.element), this.lastRect = this.readFocusRect()))
        }
        moveCursor(OO, KO) {
          const pO = this.focusTarget,
            XO = pO && (0, aK.i)().cursorMagnetism ? ZK(pO.rect) : null;
          this.pointer = TO(this.pointer, {
            stick: OO.leftStick,
            moveDeadzone: (0, aK.i)().moveDeadzone,
            dpad: KO,
            dtMs: OO.dtMs,
            cursorSpeedPercent: (0, aK.i)().cursorSpeed,
            viewport: {
              width: window.innerWidth,
              height: window.innerHeight
            },
            context: {
              overInteractive: !1,
              magnetTarget: XO
            }
          })
        }
        move(OO) {
          this.targets.revalidate();
          const KO = this.currentTarget();
          KO && this.setFocus(kp(KO, this.getTargets().targets, OO))
        }
        step(OO) {
          const KO = this.pointer;
          if (KO && (this.releasePointer(), !this.focused)) return this.targets.revalidate(), void this.setFocus(((OO, KO, pO) => {
            var XO;
            const bK = {
              key: "",
              rect: {
                left: OO.x,
                top: OO.y,
                width: 0,
                height: 0
              },
              panel: "",
              scrollGroup: null,
              visible: !0
            };
            return null !== (XO = kp(bK, KO, pO)) && void 0 !== XO ? XO : UK(OO, KO)
          })(KO, this.getTargets().targets, OO));
          this.move(OO)
        }
        isNavButton(OO) {
          return !Pp.some((KO => (0, DO.j)(KO) === OO)) && !(OO === (0, DO.j)("inventory") && Hp())
        }
        handleNavigation(OO, KO) {
          const pO = (0, aK.i)().inventoryNavigation,
            XO = {
              x: 0,
              y: 0
            };
          let bK = null;
          for (const CO of FO.z) {
            const eO = this.isNavButton(CO) && OO.isHeld(CO);
            eO && (XO.x += iX[CO].x, XO.y += iX[CO].y), this.dpadTimers.get(CO).update(eO, KO) && "cursor" !== pO && (bK ??= CO)
          }
          const eO = this.stickGate.update(OO.leftStick, (0, aK.i)().moveDeadzone);
          if (bK && (this.step(bK), this.stickGate.lock()), "slot" !== pO) {
            const KO = ((OO, KO, pO, XO) => "hybrid" !== OO ? "cursor" === OO : !XO && (KO || pO))(pO, null !== this.pointer, eO, null !== bK);
            return KO && !this.pointer && this.engagePointer(), void(this.pointer && this.moveCursor(OO, "cursor" === pO ? XO : {
              x: 0,
              y: 0
            }))
          }
          const lO = (0, FO.g)(OO.leftStick, (0, aK.i)().moveDeadzone),
            vK = this.stickRepeat.update(eO ? (0, FO.mb)(lO) : null, KO);
          vK && this.move(vK)
        }
        applyCategoryPlace() {
          const OO = this.placeAfterCategory;
          if (!OO) return;
          this.placeAfterCategory = null, this.targets.invalidate();
          const KO = UK(ZK(OO.rect), this.getTargets().targets, (KO => KO.scrollGroup === OO.scrollGroup));
          this.setFocus(KO, !1)
        }
        applyFocusRequest() {
          const OO = (0, BK.o)();
          OO && (this.targets.invalidate(), this.setFocus((0, BK.d)(this.getTargets().targets, OO)))
        }
        handlePanels(OO) {
          var KO, pO, XO;
          const bK = OO.wasPressed((0, DO.j)("inventoryPanelPrevious")),
            eO = OO.wasPressed((0, DO.j)("inventoryPanelNext"));
          if (!bK && !eO) return;
          const {
            targets: lO
          } = this.getTargets(), vK = (CO = ((OO, KO) => {
            const pO = [];
            for (const bK of OO) bK.visible && !pO.includes(bK.panel) && pO.push(bK.panel);
            const XO = OO => {
              const XO = KO.indexOf(OO);
              return -1 === XO ? KO.length + pO.indexOf(OO) : XO
            };
            return pO.sort(((OO, KO) => XO(OO) - XO(KO)))
          })(lO, vX), hO = null !== (KO = null === (pO = this.focusTarget) || void 0 === pO ? void 0 : pO.panel) && void 0 !== KO ? KO : null, MO = eO ? 1 : -1, 0 === CO.length ? null : CO[GK(null === hO ? -1 : CO.indexOf(hO), CO.length, MO)]);
          var CO, hO, MO;
          if (null === vK) return;
          const aK = this.panelMemory.get(vK),
            oO = lO.filter((OO => OO.panel === vK)),
            FO = null !== (XO = oO.find((OO => OO.element === aK && OO.visible))) && void 0 !== XO ? XO : Sp(oO, (0, BK.e)());
          this.setFocus(FO)
        }
        handlePaging(OO, KO) {
          var pO, XO;
          const bK = (0, DO.j)("menuPageUp"),
            eO = (0, DO.j)("menuPageDown"),
            lO = this.pageUpTimer.update(OO.isHeld(bK), KO),
            vK = this.pageDownTimer.update(OO.isHeld(eO), KO);
          if (!lO && !vK) return;
          const CO = vK ? 1 : -1;
          if (!OO.wasPressed(vK ? eO : bK) && this.hasCategories) return;
          if ((OO => {
              const KO = Array.from(document.querySelectorAll(".EntireInventoryWrapper .CreativeCategoryTab"));
              if (0 === KO.length) return !1;
              const pO = KO.findIndex((OO => OO.classList.contains("Selected"))),
                XO = KO[GK(pO, KO.length, OO)];
              return yp(XO, fK(XO)), !0
            })(CO)) {
            var hO, MO;
            this.targets.invalidate();
            const OO = null !== (hO = null === (MO = this.focusTarget) || void 0 === MO ? void 0 : MO.scrollGroup) && void 0 !== hO ? hO : null,
              KO = this.readFocusRect();
            return void(this.placeAfterCategory = null !== OO && KO && !this.pointer ? {
              rect: KO,
              scrollGroup: OO
            } : null)
          }
          const {
            targets: aK
          } = this.getTargets();
          let oO = this.currentTarget();
          var FO;
          null !== (pO = oO) && void 0 !== pO && pO.scrollContainer || (oO = null !== (FO = aK.find((OO => null !== OO.scrollContainer && OO.visible))) && void 0 !== FO ? FO : null);
          if (null === (XO = oO) || void 0 === XO || !XO.scrollContainer) return;
          const VO = ((OO, KO, pO, XO) => {
            if (null === OO.scrollGroup) return null;
            const bK = ZK(OO.rect),
              eO = bK.x,
              lO = bK.y + ("Down" === pO ? XO : -XO);
            let vK = null,
              CO = 1 / 0;
            for (const hO of KO) {
              if (hO.scrollGroup !== OO.scrollGroup || hO.key === OO.key) continue;
              const KO = ZK(hO.rect);
              if ("Down" === pO ? KO.y <= bK.y : KO.y >= bK.y) continue;
              const XO = Math.hypot(KO.x - eO, KO.y - lO);
              XO < CO && (vK = hO, CO = XO)
            }
            return vK
          })(oO, aK, CO > 0 ? "Down" : "Up", oO.scrollContainer.clientHeight);
          this.setFocus(null !== VO && void 0 !== VO ? VO : oO)
        }
        handleScroll(OO) {
          var KO, pO, XO, bK;
          if (!this.scroller.isScrolling(OO.rightStick)) return void this.scroller.reset();
          const eO = null !== (KO = null === (pO = this.focusTarget) || void 0 === pO ? void 0 : pO.scrollContainer) && void 0 !== KO ? KO : null === (XO = this.getTargets().targets.find((OO => null !== OO.scrollContainer))) || void 0 === XO ? void 0 : XO.scrollContainer;
          if (!eO || !this.scroller.step(eO, OO.rightStick, OO.dtMs)) return;
          this.targets.scrolled(eO);
          const lO = this.pointer || (null === (bK = this.focusTarget) || void 0 === bK ? void 0 : bK.scrollContainer) !== eO ? null : this.readFocusRect();
          if (!lO) return;
          const vK = rK(eO),
            CO = ZK(lO);
          if (CO.y < vK.top || CO.y > vK.bottom) {
            const OO = this.focusTarget.scrollGroup,
              KO = UK(CO, this.getTargets().targets, (KO => KO.scrollGroup === OO));
            this.setFocus(KO, !1)
          }
        }
        focusContext(OO) {
          const {
            kind: KO,
            idx: pO
          } = this.focused ? Qp(this.focused) : {
            kind: null,
            idx: null
          }, XO = this.focused ? Vp(this.focused) : null, bK = XO ? (0, jX.d)(XO) : null;
          return {
            kind: KO,
            idx: pO,
            actionElement: XO,
            press: bK,
            hasPress: null !== bK,
            hasBack: !(null === bK || void 0 === bK || !bK.back),
            holding: OO.isHolding(),
            slotHasItem: null !== pO && OO.hasItemAt(pO)
          }
        }
        handleButtons(OO, KO, pO) {
          var XO, bK;
          if (!this.activePress || OO.isHeld(this.activePress.button) && (XO = this.activePress.target, bK = this.focused, null !== XO.recipe ? Lp(bK).recipe === XO.recipe : bK === XO.element) || this.releasePress(), this.scrollStickClick.update(OO.rightStick, KO), !this.handleHotbarPick(OO, pO)) {
            for (const [XO, bK] of rX) {
              const eO = (0, DO.j)(bK);
              if (!OO.wasPressed(eO) || "openButton" === XO && !Hp()) continue;
              if ("RS" === eO && !this.scrollStickClick.allowsClick(KO)) continue;
              const lO = this.focusContext(pO),
                vK = JK(XO, lO);
              vK && this.runIntent(vK, lO, eO, pO)
            }
            this.handleDrop(OO, KO, pO)
          }
        }
        handleHotbarPick(OO, KO) {
          const pO = this.hotbarPick;
          if (!pO) return !1;
          const XO = OO.wasPressed((0, DO.j)("inventoryPrimary")) || OO.wasPressed((0, DO.j)("inventoryHotbarSwap"));
          if (!XO && !OO.wasPressed((0, DO.j)("inventoryClose")) && !KO.isHolding()) return !(OO.wasPressed((0, DO.j)("inventory")) && Hp());
          const bK = this.focusTarget;
          XO && "hotbar" === (null === bK || void 0 === bK ? void 0 : bK.panel) && null !== bK.idx && bK.idx !== pO.idx && (KO.swapWithHotbar(bK.idx, pO.idx), this.afterAction()), this.hotbarPick = null;
          const eO = pO.element.isConnected ? this.getTargets().byElement.get(pO.element) : void 0;
          return eO && this.setFocus(eO), !0
        }
        startHotbarPick(OO) {
          var KO;
          const {
            targets: pO,
            byElement: XO
          } = this.getTargets(), bK = document.querySelector(wp), eO = null !== (KO = bK && XO.get(bK)) && void 0 !== KO ? KO : pO.find((OO => "hotbar" === OO.panel));
          eO && this.focused && (this.hotbarPick = {
            idx: OO,
            element: this.focused
          }, this.setFocus(eO))
        }
        focusKey() {
          return this.focused ? Dp(this.focused) : null
        }
        handleDrop(OO, KO, pO) {
          const XO = (0, DO.j)("inventoryDrop");
          if (OO.wasPressed(XO)) {
            const OO = (bK = this.focusContext(pO)).holding ? {
              kind: "JK"
            } : "slot" === bK.kind && bK.slotHasItem && null !== bK.idx ? {
              kind: "slot",
              idx: bK.idx
            } : null;
            return void(OO && (this.dropFrom(OO, !1, pO), this.dropLatch.press(OO, this.focusKey(), KO, LO.d[(0, aK.i)().tapHoldTime].dropStackMs), this.afterAction()))
          }
          var bK;
          const eO = this.dropLatch.update(OO.isHeld(XO), this.focusKey(), KO);
          eO && ((OO, KO, pO) => "JK" === OO.kind ? KO : !KO && pO(OO.idx))(eO, pO.isHolding(), pO.hasItemAt) && (this.dropFrom(eO, !0, pO), this.afterAction())
        }
        dropFrom(OO, KO, pO) {
          "JK" === OO.kind ? pO.dropHeld(KO, this.slotPoint()) : pO.dropSlot(OO.idx, KO)
        }
        slotPoint() {
          return this.pointer ? {
            clientX: this.pointer.x,
            clientY: this.pointer.y
          } : this.lastRect ? (OO => {
            const KO = ZK(OO);
            return {
              clientX: KO.x,
              clientY: KO.y
            }
          })(this.lastRect) : {
            clientX: 0,
            clientY: 0
          }
        }
        runIntent(OO, KO, pO, XO) {
          const bK = KO.idx,
            eO = KO.actionElement;
          switch (eO && Rp.has(OO) && (0, QO.u)(eO), OO) {
            case "slotPrimary":
              XO.primary(bK, this.slotPoint());
              break;
            case "slotSecondary":
              XO.secondary(bK, this.slotPoint());
              break;
            case "slotQuickMove":
              XO.quickMove(bK, this.slotPoint());
              break;
            case "hotbarPick":
              this.startHotbarPick(bK);
              break;
            case "pressPrimary":
            case "pressSecondary":
              this.startPress(KO.press, "pressPrimary" === OO ? "primary" : "secondary", pO);
              break;
            case "click":
              yp(eO, fK(eO));
              break;
            case "openKeyboard":
              AK(eO) && uK(eO);
              break;
            case "pressBack":
              KO.press.back();
              break;
            case "cancel":
              XO.cancel();
              break;
            case "close":
              return this.releasePress(), void XO.close()
          }
          this.afterAction()
        }
        startPress(OO, KO, pO) {
          this.releasePress(), OO.press(KO) && (this.activePress = {
            handlers: OO,
            button: pO,
            target: Lp(this.focused)
          })
        }
        releasePress() {
          var OO, KO, pO;
          null === (OO = this.activePress) || void 0 === OO || null === (KO = (pO = OO.handlers).release) || void 0 === KO || KO.call(pO), this.activePress = null
        }
        afterAction() {
          this.targets.invalidate(), this.hover.invalidate()
        }
        publishState(OO) {
          ((OO, KO) => {
            var pO, XO, bK, eO, lO, vK;
            return OO.showing === KO.showing && OO.kind === KO.kind && OO.holding === KO.holding && OO.slotHasItem === KO.slotHasItem && (null === (pO = OO.pressHints) || void 0 === pO ? void 0 : pO.primary) === (null === (XO = KO.pressHints) || void 0 === XO ? void 0 : XO.primary) && (null === (bK = OO.pressHints) || void 0 === bK ? void 0 : bK.secondary) === (null === (eO = KO.pressHints) || void 0 === eO ? void 0 : eO.secondary) && (null === (lO = OO.pressHints) || void 0 === lO ? void 0 : lO.back) === (null === (vK = KO.pressHints) || void 0 === vK ? void 0 : vK.back) && OO.hasCategories === KO.hasCategories && OO.hasList === KO.hasList && OO.openButtonCloses === KO.openButtonCloses && OO.steppingSlots === KO.steppingSlots && OO.hotbarPicking === KO.hotbarPicking && OO.quickMoveToHotbar === KO.quickMoveToHotbar && OO.dropStackHold === KO.dropStackHold
          })(OO, this.state) || (this.state = OO, hO.i.pl(Tp.e, OO))
        }
      },
      Bp = ["pointermove", "pointerover", "pointerout", "mouseover", "mouseout"];
    var Zp = pO(7307);
    var Gp = pO(7781);
    const qX = {
        duration: 80,
        strongMagnitude: .2,
        weakMagnitude: .2,
        needsPadInUse: !1
      },
      xX = {
        damage: {
          duration: 120,
          strongMagnitude: .45,
          weakMagnitude: .3,
          minIntervalMs: 250,
          needsPadInUse: !0
        },
        blockBreak: {
          duration: 40,
          strongMagnitude: 0,
          weakMagnitude: .25,
          minIntervalMs: 120,
          needsPadInUse: !0
        },
        hit: {
          duration: 50,
          strongMagnitude: .15,
          weakMagnitude: .35,
          minIntervalMs: 120,
          needsPadInUse: !0
        },
        connect: {
          ...qX,
          minIntervalMs: 1e3
        },
        preview: {
          ...qX,
          minIntervalMs: 0
        }
      };
    const np = new class {
        constructor(OO) {
          this.deps = OO, this.lastPlayedMs = {}, this.loggedFailure = !1, this.logFailure = OO => {
            this.loggedFailure || (this.loggedFailure = !0, console.warn("Controller vibration failed; further failures are not logged.", OO))
          }
        }
        play(OO, KO) {
          const pO = xX[OO];
          if (!this.deps.isVibrationOn() || pO.needsPadInUse && !this.deps.isPadInUse()) return !1;
          const XO = this.lastPlayedMs[OO];
          if (void 0 !== XO && KO - XO < pO.minIntervalMs) return !1;
          const bK = this.deps.getActuator();
          if (!bK) return !1;
          this.lastPlayedMs[OO] = KO;
          const {
            duration: eO,
            strongMagnitude: lO,
            weakMagnitude: vK
          } = pO;
          try {
            bK.playEffect("dual-rumble", {
              duration: eO,
              strongMagnitude: lO,
              weakMagnitude: vK
            }).catch(this.logFailure)
          } catch (CO) {
            this.logFailure(CO)
          }
          return !0
        }
      }({
        getActuator: () => (OO => {
          const KO = null === OO || void 0 === OO ? void 0 : OO.vibrationActuator;
          return "function" === typeof(null === KO || void 0 === KO ? void 0 : KO.playEffect) ? KO : null
        })(lO.g.getActiveGamepad()),
        isVibrationOn: () => (0, aK.i)().vibration,
        isPadInUse: oO.o
      }),
      Wp = OO => {
        np.play(OO, performance.now())
      };
    var tX = pO(7310),
      kX = pO(2302),
      Up = pO(107),
      OX = pO(36),
      KX = pO(959);
    class pX {
      constructor(OO) {
        this.deps = OO
      }
      check() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        const KO = this.deps.isPadActive() ? this.deps.getPadFamily() : null;
        if (!KO) return "skipped";
        const pO = OO ? this.deps.getVisitId() : this.deps.peekVisitId();
        return null === pO || this.deps.readReportedVisitId() === pO ? "skipped" : this.deps.canReport() ? (this.deps.writeReportedVisitId(pO), this.deps.CX(KO, this.deps.getInputType()), "reported") : "notReady"
      }
    }
    const XX = "controllerUsageReportedVisit";
    var bb = pO(1187),
      eX = pO(1481),
      lX = pO(554),
      vb = pO(1263),
      CX = pO(1109);
    const hX = OO => ({
        translationKey: `controller:${OO}`
      }),
      DX = {
        A: "A",
        B: "B",
        X: "X",
        Y: "Y",
        LB: "LB",
        RB: "RB",
        LT: "LT",
        RT: "RT",
        View: hX("padButtonView"),
        Menu: hX("padButtonMenu"),
        LS: "L3",
        RS: "R3",
        Up: hX("padButtonDpadUp"),
        Down: hX("padButtonDpadDown"),
        Left: hX("padButtonDpadLeft"),
        Right: hX("padButtonDpadRight"),
        Home: hX("padButtonHome"),
        LeftStick: hX("padButtonLeftStick"),
        RightStick: hX("padButtonRightStick")
      },
      MX = {
        xbox: {
          LS: "LS",
          RS: "RS"
        },
        generic: {},
        steamdeck: {
          LB: "L1",
          RB: "R1",
          LT: "L2",
          RT: "R2"
        },
        playstation: {
          A: "\u2715",
          B: "\u25cb",
          X: "\u25a1",
          Y: "\u25b3",
          LB: "L1",
          RB: "R1",
          LT: "L2",
          RT: "R2",
          View: hX("padButtonCreate"),
          Menu: hX("padButtonOptions")
        },
        nintendo: {
          A: "B",
          B: "A",
          X: "Y",
          Y: "X",
          LB: "L",
          RB: "R",
          LT: "ZL",
          RT: "ZR",
          View: "\u2212",
          Menu: "+"
        }
      },
      ab = (OO, KO) => {
        var pO;
        const XO = null !== (pO = MX[OO][KO]) && void 0 !== pO ? pO : DX[KO];
        return "string" === typeof XO ? XO : (0, bK.z)(CX.f.get().getCurrentLanguageCode(), XO.translationKey)
      },
      oX = OO => {
        let {
          glyph: KO,
          family: pO,
          className: XO
        } = OO;
        const bK = (0, oO.E)(),
          eO = null !== pO && void 0 !== pO ? pO : bK,
          lO = (0, tX.d)(eO, KO);
        return (0, RO.jsx)("span", {
          className: HO()("ControllerGlyph", XO),
          role: "img",
          "aria-label": ab(eO, KO),
          style: {
            "--pad-glyph-mask": `url(${lO})`,
            "--pad-glyph-aspect": (0, tX.c)(eO, KO)
          }
        })
      };
    var FX = pO(1533);
    const VX = OO => {
      let {
        action: KO
      } = OO;
      const {
        t: pO
      } = (0, bK.D)();
      switch (KO.kind) {
        case "reload":
          return (0, RO.jsx)("span", {
            children: pO("controller:gameplayReload")
          });
        case "specialAction":
          return null;
        case "customButton":
          return (0, RO.jsx)(FX.d, {
            text: KO.description ? [{
              icon: KO.icon
            }, ` ${KO.description}`] : [{
              icon: KO.icon
            }]
          });
        case "touchButton":
          return (0, RO.jsx)(FX.d, {
            text: KO.label
          })
      }
    };
    var LX = pO(7789);
    const QX = OO => {
      let {
        hold: KO
      } = OO;
      return (0, RO.jsx)("div", {
        className: "DropStackFillTrack",
        style: {
          "--pad-drop-stack-hold": `${KO.holdMs}ms`
        },
        children: (0, RO.jsx)("div", {
          className: "DropStackFillBar"
        })
      }, KO.id)
    };
    var zb = pO(7811),
      AX = pO(7817),
      fX = pO(7819),
      dX = pO(7806);
    const TX = () => {
        const {
          gameState: OO
        } = (0, CO.l)(["gameState"]), KO = (0, oO.C)(), [XO, bK] = (0, mK.useState)(!1), [eO, lO] = (0, mK.useState)(!1);
        return (0, mK.useEffect)((() => {
          "inGame" === OO && bK(!0)
        }), [OO]), (0, mK.useEffect)((() => {
          if (!XO) return;
          let OO = null,
            KO = !1;
          return (lX.s ? Promise.all([pO.e(62), pO.e(75), pO.e(229), pO.e(204), pO.e(201), pO.e(104)]).then((() => pO(38637))).then((OO => OO.startWasmPadGameplay)) : Promise.all([pO.e(62), pO.e(215), pO.e(214), pO.e(65), pO.e(63), pO.e(64), pO.e(83), pO.e(206), pO.e(174), pO.e(211), pO.e(127), pO.e(183), pO.e(75), pO.e(207), pO.e(219), pO.e(205), pO.e(200), pO.e(105), pO.e(103), pO.e(74), pO.e(107), pO.e(223), pO.e(204), pO.e(82)]).then((() => pO(38764))).then((OO => OO.startPadGameplay))).then((pO => {
            KO || (OO = pO())
          })).catch((OO => {
            console.error("Pad gameplay failed to load", OO), KO || lO(!0)
          })), () => {
            var pO;
            KO = !0, null === (pO = OO) || void 0 === pO || pO()
          }
        }), [XO]), (0, mK.useEffect)((() => {
          eO && KO && (lO(!1), bb.NotificationProvider.showPromptPopup({
            title: "controller:gameplayLoadFailedTitle",
            subtitle: "controller:gameplayLoadFailedSubtitle",
            confirmText: "settingsMenu:reloadPagePopupConfirm",
            confirmTooltip: "",
            cancelText: "general:cancel",
            cancelTooltip: ""
          }).getResult().then((OO => {
            !0 === OO && (0, eX.reloadBloxd)()
          })))
        }), [eO, KO]), (0, RO.jsxs)(RO.Fragment, {
          children: [(0, RO.jsx)(NX, {}), (0, RO.jsx)(IX, {}), (0, RO.jsx)(yb, {})]
        })
      },
      NX = () => {
        const {
          t: OO
        } = (0, bK.D)(), KO = (0, oO.C)(), {
          gameState: pO,
          isUiHidden: XO
        } = (0, CO.l)(["gameState", "isUiHidden"]), {
          hideButtonHints: eO
        } = (0, aK.p)(), lO = (0, LX.i)(), vK = (0, LX.j)(), [hO, MO] = (0, mK.useState)(fX.c);
        return (0, vb.f)(dX.q, MO), !KO || eO || XO || "inGame" !== pO || !lO && !hO ? null : (0, RO.jsxs)("div", {
          className: "PadActionHint SmallTextBold",
          children: [lO && (0, RO.jsxs)("span", {
            className: "PadActionHintEntry",
            children: [(0, RO.jsx)(oX, {
              glyph: (0, DO.j)("actionButton")
            }), (0, RO.jsx)(VX, {
              action: lO
            }), vK && (0, RO.jsx)("span", {
              className: "PadActionHintMore",
              children: OO("controller:gameplayActionWheelHint")
            })]
          }), hO && (0, RO.jsxs)("span", {
            className: "PadActionHintEntry",
            children: [(0, RO.jsx)(oX, {
              glyph: (0, DO.j)("XM")
            }), (0, RO.jsx)("span", {
              children: OO("controller:gameplayPickBlock")
            })]
          })]
        })
      },
      IX = () => {
        const {
          t: OO
        } = (0, bK.D)(), KO = (0, oO.C)(), {
          gameState: pO,
          isUiHidden: XO
        } = (0, CO.l)(["gameState", "isUiHidden"]), [eO, lO] = (0, mK.useState)(zb.b);
        return (0, vb.f)(dX.p, lO), KO && !XO && "inGame" === pO && eO ? (0, RO.jsxs)("div", {
          className: "PadDropStackFill SmallTextBold",
          children: [(0, RO.jsx)("span", {
            children: OO("controller:gameplayDropStack")
          }), (0, RO.jsx)(QX, {
            hold: eO
          })]
        }) : null
      },
      yb = () => {
        const {
          t: OO
        } = (0, bK.D)(), KO = (0, oO.C)(), {
          gameState: pO,
          isUiHidden: XO
        } = (0, CO.l)(["gameState", "isUiHidden"]), {
          hideButtonHints: eO
        } = (0, aK.p)(), [lO, vK] = (0, mK.useState)(AX.d);
        return (0, vb.f)(dX.m, vK), KO && !XO && "inGame" === pO && lO ? (0, RO.jsxs)("div", {
          className: "PadAttackLatchedHint SmallTextBold",
          children: [!eO && (0, RO.jsx)(oX, {
            glyph: (0, DO.j)("attack")
          }), (0, RO.jsx)("span", {
            children: OO("controller:gameplayAttackLatched")
          })]
        }) : null
      };
    var gb = pO(7824),
      uX = pO(1569),
      EX = pO(1991),
      jb = pO(7289);
    const YX = OO => OO && !(0, gb.e)(uX.c.get("shopInfo")),
      wX = () => {
        const OO = "inGame" === (0, CO.l)(["gameState"]).gameState;
        return (0, EX.f)("shopInfo", (() => {
          (0, jb.d)(YX(OO))
        })), (0, mK.useEffect)((() => {
          (0, jb.d)(YX(OO))
        }), [OO]), null
      },
      ib = () => {
        const {
          t: OO
        } = (0, bK.D)(), {
          hideButtonHints: KO
        } = (0, aK.p)();
        (0, oO.E)();
        const pO = (0, Tp.k)();
        return (0, mK.useEffect)((() => (() => {
          const OO = MO.c.register({
              name: "inventory",
              isActive: cX.isActive,
              onFrame: cX.onFrame,
              onDeactivate: cX.onDeactivate,
              wakePressActs: cX.wakePressActs
            }),
            KO = OO => {
              cX.noteRealPointer(OO), cX.shouldBlockRealPointer(OO) && OO.stopPropagation()
            };
          for (const lO of Bp) window.addEventListener(lO, KO, !0);
          const pO = (0, BK.g)((() => {
              "inventory" !== MO.c.getActiveConsumerName() && cX.forgetSurface()
            })),
            XO = OO => {
              const KO = OO.target;
              (0, oO.o)() && kK(KO) && KO.closest(Xp) && (0, BK.f)() && (0, BK.m)(KO)
            };
          document.addEventListener("focusout", XO, !0);
          const {
            invalidate: bK,
            onScroll: eO
          } = cX.targets;
          return document.addEventListener("scroll", eO, !0), window.addEventListener("resize", bK), () => {
            OO(), pO();
            for (const OO of Bp) window.removeEventListener(OO, KO, !0);
            document.removeEventListener("scroll", eO, !0), document.removeEventListener("focusout", XO, !0), window.removeEventListener("resize", bK), cX.targets.disconnect()
          }
        })()), []), (0, RO.jsxs)(RO.Fragment, {
          children: [(0, RO.jsx)(BO, {
            placer: cX.ring,
            className: "InventorySlotCursorRing"
          }), pO.showing && !KO && (0, RO.jsx)("div", {
            className: "InventorySlotCursorHints SmallTextBold",
            children: cp(pO).map((KO => {
              let {
                actions: XO,
                labelKey: bK
              } = KO;
              return (0, RO.jsxs)("div", {
                className: "InventorySlotCursorHint",
                children: [XO.map((OO => (0, RO.jsx)(oX, {
                  glyph: (0, DO.j)(OO)
                }, OO))), (0, RO.jsx)("span", {
                  children: OO(`controller:${bK}`)
                }), "inventoryDrop" === bK && pO.dropStackHold && (0, RO.jsx)(QX, {
                  hold: pO.dropStackHold
                })]
              }, bK)
            }))
          })]
        })
      },
      rb = [{
        command: "close",
        action: "keyboardClose",
        repeats: !1
      }, {
        command: "submit",
        action: "keyboardSubmit",
        repeats: !1
      }, {
        command: "backspace",
        action: "keyboardBackspace",
        repeats: !0
      }, {
        command: "space",
        action: "keyboardSpace",
        repeats: !1
      }, {
        command: "caretLeft",
        action: "keyboardCaretLeft",
        repeats: !0
      }, {
        command: "caretRight",
        action: "keyboardCaretRight",
        repeats: !0
      }, {
        command: "shift",
        action: "keyboardShift",
        repeats: !1
      }, {
        command: "page",
        action: "keyboardSymbols",
        repeats: !1
      }, {
        command: "channel",
        action: "keyboardChannel",
        repeats: !1
      }],
      PX = OO => Array.from(OO).map((OO => ({
        type: "char",
        char: OO,
        width: 1
      }))),
      mb = function(OO) {
        return {
          type: "command",
          command: OO,
          width: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1
        }
      },
      sX = [mb("page", 2), mb("otherPage"), mb("caretLeft"), mb("space", 3), mb("caretRight"), mb("close", 1.5), mb("submit", 1.5)],
      HX = [mb("page", 2), mb("otherPage"), mb("caretLeft"), mb("space", 2), mb("caretRight"), mb("newline"), mb("close", 1.5), mb("submit", 1.5)],
      RX = [
        [...PX("1234567890"), mb("backspace")], PX("qwertyuiop/"), PX("asdfghjkl'?"), [mb("shift", 2), ...PX("zxcvbnm,.")]
      ],
      SX = [
        [...PX("1234567890"), mb("backspace")], PX("!@#$%^&*()/"), PX('-_=+[]{};:"'), PX("~`|\\<>'\u20ac\xa3,.")
      ],
      JX = {
        letters: RX,
        accents: [
          [...PX("1234567890"), mb("backspace")], PX("\xe1\xe9\xed\xf3\xfa\xe0\xe8\xec\xf2\xf9\xf1"), PX("\xe2\xea\xee\xf4\xfb\xe4\xeb\xef\xf6\xfc\xe7"), [mb("shift", 2), ...PX("\xe3\xf5\xdf\u0153\u011f\u015f\u0131\xbf\xa1")]
        ],
        symbols: SX
      },
      cb = new Set(["de", "es", "fr", "it", "nl", "pt", "pt-BR", "tr", "vi"]),
      BX = (OO, KO) => "letters" === OO ? KO ? {
        page: "accents",
        otherPage: "symbols"
      } : {
        page: "symbols",
        otherPage: "accents"
      } : {
        page: "letters",
        otherPage: "accents" === OO ? "symbols" : "accents"
      },
      ZX = function(OO, KO) {
        const pO = ((OO, KO) => [...JX[OO], KO ? HX : sX])(OO, arguments.length > 2 && void 0 !== arguments[2] && arguments[2]);
        if (0 === KO) return pO;
        const XO = Math.min(2, GX(pO[0]) / KO);
        return [Array.from({
          length: KO
        }, ((OO, KO) => ({
          type: "phrase",
          phraseIndex: KO,
          width: XO
        }))), ...pO]
      },
      GX = OO => OO.reduce(((OO, KO) => OO + KO.width), 0),
      qb = OO => Math.max(...OO.map(GX)),
      xb = (OO, KO) => {
        const pO = OO[KO.row];
        let XO = (qb(OO) - GX(pO)) / 2;
        for (let bK = 0; bK < KO.col; bK++) XO += pO[bK].width;
        return XO + pO[KO.col].width / 2
      },
      nX = (OO, KO, pO) => {
        let XO = 0,
          bK = 1 / 0;
        for (let eO = 0; eO < OO[KO].length; eO++) {
          const lO = Math.abs(xb(OO, {
            row: KO,
            col: eO
          }) - pO);
          lO < bK - 1e-9 && (XO = eO, bK = lO)
        }
        return XO
      },
      WX = (OO, KO) => {
        const pO = Math.max(0, Math.min(OO.length - 1, KO.row));
        return {
          row: pO,
          col: Math.max(0, Math.min(OO[pO].length - 1, KO.col))
        }
      },
      tb = (OO, KO, pO) => "once" === OO && KO - pO <= 400 ? "caps" : "off" === OO ? "once" : "off",
      kb = (OO, KO) => "once" === OO && (OO => OO.toLowerCase() !== OO.toUpperCase())(KO) ? "off" : OO,
      UX = (OO, KO, pO) => {
        if ("symbols" === KO || "off" === pO) return OO;
        const XO = OO.toUpperCase();
        return 1 === XO.length ? XO : OO
      };
    var Ob = pO(1479),
      Kb = pO(7746),
      pb = pO(7838),
      Xb = pO(243),
      be = pO(1441),
      eb = pO(7272);
    const lb = "[data-pad-secondary]",
      ve = OO => OO instanceof HTMLElement && hK(OO) && !DK(OO),
      Cb = OO => {
        const KO = OO.querySelector(lb);
        if (KO && ve(KO)) return KO;
        for (const bK of null !== (pO = null === (XO = OO.parentElement) || void 0 === XO ? void 0 : XO.children) && void 0 !== pO ? pO : []) {
          var pO, XO;
          if (bK !== OO && bK.matches(lb) && ve(bK)) return bK
        }
        return null
      },
      hb = (OO, KO, pO, XO) => Math.max(0, Math.max(OO, pO) - Math.min(KO, XO)),
      Db = (OO, KO, pO, XO) => Math.max(0, Math.min(KO, XO) - Math.max(OO, pO)),
      Mb = (OO, KO, pO) => {
        const XO = (OO.left + OO.right) / 2,
          bK = (OO.top + OO.bottom) / 2,
          eO = (KO.left + KO.right) / 2,
          lO = (KO.top + KO.bottom) / 2;
        if ("Left" === pO || "Right" === pO) {
          const vK = "Right" === pO ? 1 : -1;
          return {
            forwardGap: "Right" === pO ? KO.left - OO.right : OO.left - KO.right,
            centreForward: (eO - XO) * vK,
            sidewaysGap: hb(OO.top, OO.bottom, KO.top, KO.bottom),
            sidewaysOverlap: Db(OO.top, OO.bottom, KO.top, KO.bottom),
            centreSideways: Math.abs(lO - bK),
            startSideways: Math.abs(KO.top - OO.top),
            fromSidewaysSize: OO.bottom - OO.top,
            toSidewaysSize: KO.bottom - KO.top,
            toLength: KO.right - KO.left
          }
        }
        const vK = "Down" === pO ? 1 : -1;
        return {
          forwardGap: "Down" === pO ? KO.top - OO.bottom : OO.top - KO.bottom,
          centreForward: (lO - bK) * vK,
          sidewaysGap: hb(OO.left, OO.right, KO.left, KO.right),
          sidewaysOverlap: Db(OO.left, OO.right, KO.left, KO.right),
          centreSideways: Math.abs(eO - XO),
          startSideways: Math.abs(KO.left - OO.left),
          fromSidewaysSize: OO.right - OO.left,
          toSidewaysSize: KO.right - KO.left,
          toLength: KO.bottom - KO.top
        }
      },
      ae = OO => OO.centreForward > .5 && OO.forwardGap >= -OO.toLength / 2,
      ob = OO => {
        const KO = OO.sidewaysOverlap > 0 ? 0 : 2 * OO.fromSidewaysSize,
          pO = OO.fromSidewaysSize > 1.5 * OO.toSidewaysSize ? OO.startSideways : OO.centreSideways;
        return Math.max(0, OO.forwardGap) + 3 * OO.sidewaysGap + KO + .1 * pO
      },
      Fb = (OO, KO) => Db(OO.top, OO.bottom, KO.top, KO.bottom) > 0 || KO.bottom - KO.top > KO.right - KO.left,
      Vb = (OO, KO, pO, XO, bK, eO) => {
        const lO = bK ? Qb(OO, KO, pO, bK) : new Set,
          vK = Ab(OO, KO, pO, lO);
        return vK < 0 && lO.size > 0 && eO ? Lb(OO, KO, pO, eO) : XO && vK >= 0 ? ze(OO, KO, pO, XO, vK, lO) : vK
      },
      Lb = (OO, KO, pO, XO) => {
        const bK = new Set,
          eO = Ab(OO, KO, "Up", bK) >= 0,
          lO = Ab(OO, KO, "Down", bK) >= 0,
          vK = new Set;
        return KO.forEach(((KO, pO) => {
          const bK = KO.top + KO.bottom < OO.top + OO.bottom;
          XO[pO] && !(bK ? eO : lO) || vK.add(pO)
        })), Ab(OO, KO, pO, vK)
      },
      Qb = (OO, KO, pO, XO) => {
        const bK = new Set;
        return "Left" !== pO && "Right" !== pO || KO.forEach(((KO, pO) => {
          XO[pO] && Db(OO.top, OO.bottom, KO.top, KO.bottom) <= 0 && bK.add(pO)
        })), bK
      },
      ze = (OO, KO, pO, XO, bK, eO) => {
        const lO = Mb(OO, KO[bK], pO).forwardGap;
        let vK = bK,
          CO = XO[bK],
          hO = 1 / 0;
        return KO.forEach(((KO, DO) => {
          const MO = XO[DO];
          if (eO.has(DO) || MO < CO || MO === CO && vK === bK) return;
          const aK = Mb(OO, KO, pO);
          if (!ae(aK) || aK.forwardGap < 0 || aK.forwardGap >= lO) return;
          const oO = ob(aK);
          (MO > CO || oO < hO) && (vK = DO, CO = MO, hO = oO)
        })), vK
      },
      Ab = (OO, KO, pO, XO) => {
        let bK = -1,
          eO = 1 / 0;
        if (KO.forEach(((KO, lO) => {
            const vK = ((OO, KO, pO) => {
              const XO = Mb(OO, KO, pO);
              if (!ae(XO)) return null;
              const bK = Math.max(0, XO.forwardGap);
              return XO.sidewaysOverlap <= 0 && XO.sidewaysGap > 2 * (bK + 1) ? null : ob(XO)
            })(OO, KO, pO);
            null !== vK && vK < eO && !XO.has(lO) && (eO = vK, bK = lO)
          })), bK < 0) return -1;
        const lO = KO[bK],
          vK = Mb(OO, lO, pO).forwardGap;
        let CO = vK,
          hO = bK;
        return KO.forEach(((KO, eO) => {
          if (eO === bK || XO.has(eO) || !((OO, KO, pO) => {
              const XO = "Left" === pO || "Right" === pO,
                bK = XO ? Db(OO.top, OO.bottom, KO.top, KO.bottom) : Db(OO.left, OO.right, KO.left, KO.right),
                eO = XO ? Math.min(OO.bottom - OO.top, KO.bottom - KO.top) : Math.min(OO.right - OO.left, KO.right - KO.left);
              return bK > 0 && bK >= eO / 2
            })(KO, lO, pO)) return;
          const DO = Mb(OO, KO, pO);
          ae(DO) && DO.forwardGap + DO.toLength <= vK + 1 && DO.forwardGap < CO && (CO = DO.forwardGap, hO = eO)
        })), hO
      },
      fb = (OO, KO) => {
        let pO = -1,
          XO = 1 / 0;
        return KO.forEach(((KO, bK) => {
          const eO = Math.max(KO.left - OO.x, 0, OO.x - KO.right),
            lO = Math.max(KO.top - OO.y, 0, OO.y - KO.bottom),
            vK = Math.hypot(eO, lO);
          vK < XO && (XO = vK, pO = bK)
        })), pO
      },
      db = (OO, KO) => {
        const pO = Math.min(OO.bottom - OO.top, KO.bottom - KO.top) / 2;
        return Math.abs(OO.top - KO.top) > pO ? OO.top - KO.top : OO.left - KO.left
      },
      Tb = OO => {
        let KO = -1;
        for (let pO = 0; pO < OO.length; pO++)(KO < 0 || db(OO[pO], OO[KO]) < 0) && (KO = pO);
        return KO
      };
    var Nb = pO(7842),
      Ib = pO(7847);
    const ye = OO => {
        if ("death" !== OO || "inGame" !== CO.d.get("gameState") || "off" === (0, aK.i)().quickChat || null === (0, Ob.d)()) return !1;
        const KO = (0, DO.j)("chat");
        return KO !== (0, DO.j)("menuConfirm") && KO !== (0, DO.j)("menuBack")
      },
      ge = new Nb.b;
    var ub = pO(3562),
      Eb = pO(7854);
    const je = OO => {
        let KO = null;
        for (const pO of OO.querySelectorAll("[data-pad-tabs]")) hK(pO) && (!KO || Number(pO.dataset.padTabs) < Number(KO.dataset.padTabs)) && (KO = pO);
        return KO
      },
      Yb = (OO, KO, pO, XO) => {
        OO.focusWhenFound((() => {
          const bK = OO.pickInitial(KO);
          if (bK && !pO.has(bK) && (null === XO || void 0 === XO || !XO.contains(bK))) return bK;
          const eO = ((OO, KO) => {
              const pO = KO => OO.getEnabledCandidates(KO).filter((OO => !OO.closest("[data-pad-tabs]")));
              for (const XO of zp(KO)) {
                const OO = pO(XO);
                if (OO.length > 0) return OO
              }
              return pO(KO)
            })(OO, KO).filter((OO => !pO.has(OO))),
            lO = Tb(eO.map((OO => OO.getBoundingClientRect())));
          return lO >= 0 ? eO[lO] : null
        }), 3e3)
      },
      wb = (OO, KO, pO, XO) => {
        var bK;
        const eO = ((OO, KO) => {
          if (0 === OO.length) return null;
          const pO = OO.findIndex((OO => "true" === OO.dataset.padSelected));
          return pO < 0 ? KO > 0 ? OO[0] : OO[OO.length - 1] : OO[(pO + KO + OO.length) % OO.length]
        })([...pO.querySelectorAll("[data-pad-tab]")].filter((OO => hK(OO) && !DK(OO))), XO);
        if (!eO) return;
        const lO = null !== (bK = null === OO || void 0 === OO ? void 0 : OO.getFocused()) && void 0 !== bK ? bK : null,
          vK = !(null === lO || void 0 === lO || !lO.isConnected) && pO.contains(lO),
          CO = OO && !vK ? new Set(OO.getEnabledCandidates(KO)) : null;
        EK(eO), OO && (CO ? Yb(OO, KO, CO, pO) : OO.setFocus(eO, {
          byUser: !0
        }))
      },
      ie = OO => {
        var KO;
        const pO = rK(null !== (KO = uO(OO, "x")) && void 0 !== KO ? KO : OO),
          XO = oK(OO).filter((OO => !DK(OO))),
          bK = XO.filter((OO => PO(OO.getBoundingClientRect(), pO)));
        return (bK.length > 0 ? bK : XO).sort(((OO, KO) => db(OO.getBoundingClientRect(), KO.getBoundingClientRect())))
      },
      re = (OO, KO, pO) => {
        const XO = [...KO.querySelectorAll("[data-pad-row]")].filter(hK),
          bK = OO.getFocused(),
          eO = bK ? XO.findIndex((OO => OO.contains(bK))) : -1;
        let lO = 0,
          vK = pO > 0 ? 0 : XO.length - 1;
        if (eO >= 0 && bK) lO = Math.max(0, ie(XO[eO]).indexOf(bK)), vK = eO + pO;
        else if (bK) {
          const OO = bK.getBoundingClientRect(),
            KO = XO.map((KO => {
              const XO = KO.getBoundingClientRect();
              return pO > 0 ? XO.top >= OO.top : XO.bottom <= OO.bottom
            }));
          vK = pO > 0 ? KO.indexOf(!0) : KO.lastIndexOf(!0)
        }
        for (let CO = vK; CO >= 0 && CO < XO.length; CO += pO) {
          const KO = ie(XO[CO]);
          if (KO.length > 0) return void OO.setFocus(KO[Math.min(lO, KO.length - 1)], {
            byUser: !0
          })
        }
      },
      Pb = (OO, KO, pO) => {
        var XO, bK;
        const eO = null !== (XO = null === OO || void 0 === OO ? void 0 : OO.getFocused()) && void 0 !== XO ? XO : null,
          lO = null !== eO && void 0 !== eO && eO.closest("[data-pad-row]") ? "x" : "y",
          vK = null !== (bK = eO ? uO(eO, lO, KO) : null) && void 0 !== bK ? bK : jK(KO, lO);
        if (!vK) return;
        const CO = eO ? fK(eO) : null;
        if (iK(vK, lO, pO * ("y" === lO ? vK.clientHeight : vK.clientWidth) * .85), !OO || !CO) return;
        const hO = rK(vK),
          DO = OO.getEnabledCandidates(KO).filter((OO => vK.contains(OO) && PO(OO.getBoundingClientRect(), hO))),
          MO = fb(CO, DO.map((OO => OO.getBoundingClientRect())));
        MO >= 0 && OO.setFocus(DO[MO], {
          scroll: !1,
          byUser: !0
        })
      };
    let me = null;
    const sb = (OO, KO) => {
        var pO, XO;
        const bK = KO.querySelector("[data-pad-friends-column]"),
          eO = OO.getFocused();
        if (!bK || !eO || !bK.contains(eO)) return !1;
        const lO = OO.getEnabledCandidates(KO).filter((OO => !bK.contains(OO))),
          vK = fb(fK(eO), lO.map((OO => OO.getBoundingClientRect()))),
          CO = null === (pO = me) || void 0 === pO ? void 0 : pO.deref();
        return OO.setFocus(null !== CO && void 0 !== CO && CO.isConnected ? CO : null !== (XO = lO[vK]) && void 0 !== XO ? XO : null, {
          byUser: !0
        }), !0
      },
      Hb = OO => {
        const KO = (0, DO.j)(OO);
        return (0, FO.H)(KO) || eb.p.some((OO => (0, DO.j)(OO) === KO)) ? null : KO
      },
      Rb = (OO, KO) => {
        const pO = Hb(KO);
        return null !== pO && OO.wasPressed(pO)
      },
      Sb = function(OO, KO, pO) {
        let XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        const bK = (OO => {
            var KO, pO;
            return null !== (KO = null === (pO = je(OO)) || void 0 === pO ? void 0 : pO.querySelector("[data-pad-tab][data-pad-selected='true']")) && void 0 !== KO ? KO : null
          })(KO),
          eO = OO && bK ? new Set(OO.getEnabledCandidates(KO)) : null;
        (0, pb.c)(), pO === Xb.o.SETTINGS && (0, be.h)(CO.d.get("openEverythingMenuName")) ? CO.d.set({
          openEverythingMenuName: pO
        }) : (0, be.p)(new Event("padMenuShortcut"), pO, XO), OO && eO && bK && Yb(OO, KO, eO, bK.closest("[data-pad-tabs]"))
      },
      Jb = OO => null !== OO.closest(".Dropdown-root") || null !== OO.querySelector(".Dropdown-root.is-open"),
      ce = OO => null !== (0, Eb.b)() && "popup" !== OO.layer.kind && !je(OO.root) && !Jb(OO.root),
      Bb = (0, VO.b)(FO.bb),
      Zb = (0, VO.b)(FO.bb),
      Gb = (OO, KO, pO) => {
        if (((OO, KO) => {
            const pO = (0, DO.j)("chat");
            return ye(KO) && OO.isHeld(pO) ? "hold" === ge.update(OO.wasPressed(pO), OO.isHeld(pO), performance.now(), LO.d[(0, aK.i)().tapHoldTime].wheelMs) && (MO.c.consumeButton(pO), hO.i.pl(Ib.o), !0) : (ge.release(), !1)
          })(KO, pO.layer.kind)) return !0;
        const XO = pO.root;
        for (const [lO, vK] of [
            ["menuTabPrevious", -1],
            ["menuTabNext", 1]
          ])
          if (KO.wasPressed((0, DO.j)(lO))) {
            const KO = Jb(XO) ? null : je(XO);
            if (KO) wb(OO, XO, KO, vK);
            else if (ce(pO)) {
              var bK;
              const KO = OO ? new Set(OO.getEnabledCandidates(XO)) : null;
              null !== (bK = (0, Eb.b)()) && void 0 !== bK && bK(vK) && OO && KO && Yb(OO, XO, KO, null)
            } else OO && re(OO, XO, vK);
            return !0
          } for (const [lO, vK, CO] of [
            ["menuPageUp", -1, Bb],
            ["menuPageDown", 1, Zb]
          ]) {
          const pO = (0, DO.j)(lO);
          if (KO.wasPressed(pO) && CO.reset(), CO.update(KO.isHeld(pO), performance.now())) return Pb(OO, XO, vK), !0
        }
        const eO = "popup" === pO.layer.kind;
        return Rb(KO, "pause") ? (eO || (0, be.l)() && "menu" !== pO.layer.kind || Sb(OO, XO, (0, be.l)() ? Xb.o.SETTINGS : (0, ub.d)()), !0) : !!Rb(KO, "leaderboard") && ("home" === pO.layer.kind ? (OO => {
          const KO = [...OO.querySelectorAll("[data-pad-notifications]")].find(hK);
          KO && EK(KO)
        })(XO) : eO || Sb(OO, XO, Xb.o.LOBBY_LEADERBOARD, "inGame" === CO.d.get("gameState")), !0)
      },
      qe = (OO, KO, pO) => {
        if (Gb(OO, KO, pO)) return !0;
        const XO = "home" === pO.layer.kind;
        if (KO.wasPressed((0, DO.j)("menuSecondary"))) {
          const KO = OO.getFocused(),
            bK = KO ? Cb(KO) : null;
          if (bK) return EK(bK), !0;
          if (XO) {
            const KO = pO.root.querySelector("[data-pad-search] input");
            return KO && QK(KO, pO.root) ? (OO.setFocus(KO, {
              byUser: !0
            }), EK(KO)) : CO.d.set({
              searchOpen: !0
            }), !0
          }
        }
        return !(!XO || !Rb(KO, "inventory")) && (((OO, KO) => {
          var pO, XO;
          const bK = KO.querySelector("[data-pad-friends-column]");
          if (!bK || !hK(bK)) return void(0, be.p)(new Event("padMenuShortcut"), Xb.o.SOCIAL);
          if (sb(OO, KO)) return;
          const eO = null !== (pO = null === (XO = bK.querySelector("[data-pad-friends-start]")) || void 0 === XO ? void 0 : XO.getBoundingClientRect().top) && void 0 !== pO ? pO : -1 / 0,
            lO = OO.getEnabledCandidates(bK),
            vK = lO.filter((OO => OO.getBoundingClientRect().top >= eO)),
            CO = vK.length > 0 ? vK : lO,
            hO = Tb(CO.map((OO => OO.getBoundingClientRect())));
          OO.setFocus(hO >= 0 ? CO[hO] : null, {
            byUser: !0
          })
        })(OO, pO.root), !0)
      },
      xe = OO => {
        var KO, pO, XO;
        const bK = HK(OO);
        if (null !== bK) return bK;
        const eO = (null !== (KO = null !== (pO = null !== (XO = OO.getAttribute("aria-label")) && void 0 !== XO ? XO : OO.getAttribute("title")) && void 0 !== pO ? pO : OO.textContent) && void 0 !== KO ? KO : "").replace(/\s+/g, " ").trim();
        return eO ? `${OO.tagName}:${eO.slice(0,100)}` : null
      };
    class nb {
      constructor() {
        this.remembered = new Map, this.history = []
      }
      enter(OO) {
        const KO = this.history.indexOf(OO);
        if (KO >= 0) {
          for (const OO of this.history.splice(KO + 1)) this.remembered.delete(OO);
          return !0
        }
        return this.remembered.delete(OO), this.history.push(OO), this.history.length > 32 && this.forget(this.history[0]), !1
      }
      forget(OO) {
        this.remembered.delete(OO);
        const KO = this.history.indexOf(OO);
        KO >= 0 && this.history.splice(KO, 1)
      }
      remember(OO, KO, pO, XO) {
        const bK = xe(KO),
          eO = HK(KO),
          lO = null !== eO && ((OO, KO) => {
            let pO = 0;
            for (const XO of OO.querySelectorAll("[data-pad-key], [href]"))
              if ((XO.getAttribute("data-pad-key") === KO || XO.getAttribute("href") === KO) && (pO++, pO > 1)) return !0;
            return !1
          })(pO, eO) ? Math.max(0, this.twins(XO(), eO).indexOf(KO)) : 0;
        this.remembered.set(OO, {
          element: new WeakRef(KO),
          identity: bK,
          ordinal: lO
        })
      }
      has(OO) {
        return this.remembered.has(OO)
      }
      recall(OO, KO) {
        var pO, XO;
        const bK = this.remembered.get(OO);
        if (!bK) return null;
        const eO = bK.element.deref();
        if (eO && KO.includes(eO)) return eO;
        if (null === bK.identity) return null;
        const lO = this.twins(KO, bK.identity);
        return null !== (pO = null !== (XO = lO[bK.ordinal]) && void 0 !== XO ? XO : lO[0]) && void 0 !== pO ? pO : null
      }
      twins(OO, KO) {
        return OO.filter((OO => xe(OO) === KO))
      }
    }
    var Wb = pO(1134);
    const te = OO => {
        const KO = [];
        let pO = OO;
        for (; pO && pO !== document.body;) {
          const OO = getComputedStyle(pO).zIndex;
          "auto" !== OO && KO.push(Number(OO) || 0), pO = pO.parentElement
        }
        return KO.reverse()
      },
      ke = (OO, KO) => {
        const pO = ((OO, KO) => {
          const pO = Math.max(OO.length, KO.length);
          for (let eO = 0; eO < pO; eO++) {
            var XO, bK;
            const pO = (null !== (XO = OO[eO]) && void 0 !== XO ? XO : 0) - (null !== (bK = KO[eO]) && void 0 !== bK ? bK : 0);
            if (0 !== pO) return pO
          }
          return 0
        })(te(OO), te(KO));
        if (0 !== pO) return pO > 0;
        if (OO.contains(KO)) return !1;
        if (KO.contains(OO)) return !0;
        const XO = OO.compareDocumentPosition(KO);
        return !!(XO & Node.DOCUMENT_POSITION_PRECEDING) || !(XO & Node.DOCUMENT_POSITION_FOLLOWING) && null
      },
      Ub = (OO, KO) => {
        var pO;
        return null !== (pO = ke(OO.root, KO.root)) && void 0 !== pO ? pO : OO.order > KO.order
      },
      Oe = (OO, KO) => KO.some((KO => !KO.contains(OO) && !OO.contains(KO) && !0 === ke(KO, OO)));
    let Ke = null,
      pe = null,
      Xe = -1;
    const bl = () => {
        var OO;
        const KO = null === (OO = document.timeline) || void 0 === OO ? void 0 : OO.currentTime,
          pO = "number" === typeof KO ? KO : null;
        if (null !== pO && pO === pe && Xe === (0, Wb.d)()) return Ke;
        let XO = null;
        const bK = [],
          eO = [...document.querySelectorAll("[data-pad-covers]")].filter(hK);
        for (const lO of (0, Wb.g)()) {
          const OO = lO.getRoot(),
            KO = !!OO && hK(OO) && !Oe(OO, eO);
          if (lO.shown && !KO && bK.push(lO), lO.shown = KO, !OO || !KO) continue;
          const pO = {
            layer: lO,
            root: OO,
            order: lO.order
          };
          XO && !Ub(pO, XO) || (XO = pO)
        }
        Ke = XO, pe = pO, Xe = (0, Wb.d)();
        for (const lO of bK)(0, Wb.h)(lO);
        return Ke
      },
      ee = () => {
        const OO = bl();
        return !(null === OO || void 0 === OO || !OO.layer.close) && (OO.layer.close(), pe = null, !0)
      },
      le = () => {
        var OO, KO;
        return null !== (OO = null === (KO = bl()) || void 0 === KO ? void 0 : KO.root) && void 0 !== OO ? OO : null
      },
      vl = OO => OO ? {
        ...OO,
        root: le()
      } : null;
    let Ce = null,
      he = null,
      De = (0, aK.i)().menuNavigation,
      Me = null;
    const al = new dO;
    let oe = null;
    hO.i.subscribe(aK.f, (() => {
      const OO = (0, aK.i)().menuNavigation;
      OO !== De && (De = OO, Ce = null, he = null)
    }));
    const Fe = () => {
        var OO;
        return null !== (OO = Ce) && void 0 !== OO ? OO : (0, aK.i)().menuNavigation
      },
      Ve = OO => {
        if (Ae()) {
          if (Me = vl(OO), "hybrid" === Fe()) return al.lock(), void(he = he ? null : le());
          Ce = "focus" === Fe() ? "cursor" : "focus"
        }
      },
      Le = () => {
        const OO = Me;
        return Me = null, OO
      };
    let Qe = {
      root: null,
      firstSeenMs: -1 / 0,
      atMs: -1 / 0,
      has: !1
    };
    const zl = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : performance.now();
        const pO = Qe.root === OO,
          XO = pO ? Qe.firstSeenMs : KO,
          bK = Qe.has || KO - XO > 1e3;
        return (!pO || !bK || KO - Qe.atMs > 250) && (Qe = {
          root: OO,
          firstSeenMs: XO,
          atMs: KO,
          has: VK(OO)
        }), Qe.has
      },
      Ae = () => {
        const OO = le();
        return null !== OO && zl(OO)
      },
      fe = () => {
        const OO = bl();
        return he && (null === OO || void 0 === OO ? void 0 : OO.root) !== he && (he = null), (OO => {
          let {
            mode: KO,
            hasLayer: pO,
            hasCandidates: XO,
            hybridCursorEngaged: bK
          } = OO;
          return pO ? "cursor" !== KO && XO() ? "hybrid" === KO && bK ? "cursor" : "focus" : "cursor" : null
        })({
          mode: Fe(),
          hasLayer: null !== OO,
          hasCandidates: () => null !== OO && zl(OO.root),
          hybridCursorEngaged: null !== he
        })
      },
      de = () => "hybrid" === Fe() && Ae(),
      Te = "pad-focused";
    var Ne = pO(4151);
    const Ie = "[data-pad-destructive]",
      yl = `${Ie}, [data-pad-back]`,
      gl = OO => ({
        rect: OO.getBoundingClientRect(),
        destructive: OO.matches(Ie),
        closes: null !== OO.closest("[data-pad-close-button]"),
        unavailable: OO.matches("[data-pad-unavailable]")
      }),
      ue = OO => {
        let {
          destructive: KO,
          closes: pO,
          unavailable: XO
        } = OO;
        return KO ? pO ? 2 : 3 : XO ? 1 : 0
      },
      Ee = OO => {
        let KO = -1;
        for (let pO = 0; pO < OO.length; pO++) {
          if (KO < 0) {
            KO = pO;
            continue
          }
          const XO = OO[pO],
            bK = OO[KO];
          ue(XO) === ue(bK) ? db(XO.rect, bK.rect) < 0 && (KO = pO) : ue(XO) < ue(bK) && (KO = pO)
        }
        return KO
      },
      jl = "[data-pad-tabs]",
      Ye = "[data-pad-tab]",
      we = (OO, KO) => {
        const pO = OO.querySelector(`${Ye}[data-pad-selected='true']`);
        return pO && KO.includes(pO) ? pO : null
      },
      il = (OO, KO) => {
        let pO = KO;
        for (let XO = KO.parentElement; XO && !XO.contains(OO); XO = XO.parentElement) pO = XO;
        return pO
      };
    class rl {
      constructor() {
        this.contentReturn = null
      }
      redirect(OO, KO, pO, XO) {
        var bK, eO;
        const lO = OO.closest(jl),
          vK = KO.closest(jl);
        var CO;
        if (vK && vK !== lO) return lO || (this.contentReturn = new WeakRef(OO)), null !== (CO = we(vK, pO)) && void 0 !== CO ? CO : KO;
        if (!lO || vK) return KO;
        const hO = il(OO, KO),
          DO = null === (bK = this.contentReturn) || void 0 === bK ? void 0 : bK.deref();
        return DO && hO.contains(DO) && pO.includes(DO) ? DO : null !== (eO = this.pickRegionStart(hO, uO(KO, "y", XO), pO)) && void 0 !== eO ? eO : KO
      }
      findTabContent(OO, KO, pO) {
        const XO = OO.closest(jl);
        if (!XO || !OO.matches(Ye) || XO.contains(KO)) return null;
        const bK = KO.closest(jl);
        if (bK && Number(bK.dataset.padTabs) <= Number(XO.dataset.padTabs)) return null;
        const eO = il(OO, KO);
        return pO.some((OO => eO.contains(OO) && !OO.closest(yl))) || !KO.closest(yl) ? eO : null
      }
      pickContentStart(OO, KO, pO) {
        return this.contentReturn = null, this.pickRegionStart(OO, uO(OO, "y", pO), KO)
      }
      pickReplacedContentStart(OO, KO, pO, XO) {
        if (!KO.contains(OO)) return null;
        const bK = il(KO, OO),
          eO = pO.filter((OO => KO.contains(OO) && !bK.contains(OO) && !OO.closest(yl)));
        return 0 === eO.length ? null : (this.contentReturn = null, this.pickRegionStart(KO, uO(eO[0], "y", XO), eO))
      }
      backToStrip(OO, KO, pO) {
        if (OO.closest(jl)) return null;
        const XO = je(pO);
        for (const bK of pO.querySelectorAll(jl)) {
          if (Number(bK.dataset.padTabs) <= 1 || bK === XO) continue;
          const eO = we(bK, KO),
            lO = eO ? il(OO, bK).parentElement : null;
          if (eO && lO && lO !== pO && pO.contains(lO)) return this.contentReturn = new WeakRef(OO), eO
        }
        return null
      }
      pickRegionStart(OO, KO, pO) {
        const XO = rK(KO),
          bK = OO => {
            const KO = pO.filter((KO => OO.contains(KO) && !KO.closest(jl) && PO(KO.getBoundingClientRect(), XO))),
              bK = Ee(KO.map(gl));
            return bK >= 0 ? KO[bK] : null
          };
        for (const eO of zp(OO)) {
          const OO = bK(eO);
          if (OO) return OO
        }
        for (const eO of OO.querySelectorAll(jl)) {
          const OO = we(eO, pO);
          if (OO) return OO
        }
        return bK(OO)
      }
    }
    const Pe = 1e3,
      ml = "[data-pad-default-focus], .Dropdown-option.is-selected",
      se = ".Dropdown-root.is-open > .Dropdown-menu",
      He = "[data-pad-no-step-in]",
      Re = "[data-pad-tabs]",
      Se = "[data-pad-press-area]",
      Je = OO => {
        let KO = OO;
        for (let pO = 0; KO && pO <= 4; pO++, KO = KO.parentElement) {
          const pO = KO.querySelector(".CircleInfo");
          if (pO) return KO === OO || KO.querySelectorAll(vp).length <= 1 ? pO : null;
          if (KO !== OO && KO.querySelectorAll(vp).length > 1) return null
        }
        return null
      },
      cl = (OO, KO, pO) => {
        gp(OO, KO, pO);
        const XO = null !== OO && void 0 !== OO && OO.isConnected ? Je(OO) : null,
          bK = Je(KO);
        XO !== bK && gp(XO, bK, bK ? fK(bK) : pO, {
          leaveBelow: OO,
          enterBelow: KO
        })
      },
      Be = OO => OO.getBoundingClientRect(),
      Ze = (OO, KO, pO) => {
        const XO = new Set(pO);
        for (let bK = OO; bK; bK = bK === KO ? null : bK.parentElement)
          if (XO.has(bK)) return bK;
        return null
      },
      Ge = (OO, KO) => !OO.root || OO.root === KO || KO.matches(se) && OO.root.contains(KO);
    const ql = new class {
        constructor() {
          this.focused = null, this.layerKey = null, this.layerRoot = null, this.memory = new nb, this.tabStripNav = new rl, this.movedInLayer = !1, this.scrolledInLayer = !1, this.restoredFromMemory = !1, this.restoreOnFocusLoss = !1, this.confirmPressedOn = null, this.confirmRepeatKey = null, this.confirmRepeated = !1, this.confirmRepeat = (0, VO.b)(FO.s), this.dpadRepeats = new Map(FO.z.map((OO => [OO, (0, VO.b)(FO.D)]))), this.stickRepeat = new FO.b((0, VO.b)(FO.ib)), this.lastRefocusCheckMs = -1 / 0, this.enteredLayerAtMs = 0, this.lastFocusedCentre = null, this.lastActivatedKey = null, this.lastActivated = null, this.lastActivatedAtMs = -1 / 0, this.pendingFocus = null, this.tabOpenWait = null, this.retryMove = null, this.scrollRemainder = {
            x: 0,
            y: 0
          }, this.wasActive = !1, this.layerKind = null, this.pressGuardUntilMs = -1 / 0, this.pressGuardExtends = !1, this.listeners = new Set, this.dropdownLayers = new WeakMap, this.dropdownLayerCounter = 0
        }
        install() {
          const OO = MO.c.register({
              name: "focus",
              isActive: () => (0, oO.o)() && "focus" === fe(),
              onFrame: OO => {
                this.onFrame(OO)
              },
              onDeactivate: () => {
                this.deactivate()
              },
              wakePressActs: OO => (0, MO.f)(OO) || OO === (0, DO.j)("menuConfirm") && PK((0, oO.e)())
            }),
            KO = (0, Wb.j)((OO => {
              const KO = (0, Wb.n)(OO);
              null === OO.memoryKey && this.memory.forget(KO), KO === this.layerKey && (this.layerKey = null)
            }));
          let pO = -1 / 0;
          const XO = lO.g.onFrame((OO => {
              (0, oO.o)() || OO.timestampMs - pO < 100 || (pO = OO.timestampMs, bl())
            })),
            bK = OO => {
              OO.isTrusted && OO.target instanceof Element && lO.g.getActivePad() && this.noteChosenStop(OO.target)
            };
          return document.addEventListener("click", bK, !0), () => {
            OO(), KO(), XO(), document.removeEventListener("click", bK, !0), this.deactivate()
          }
        }
        noteChosenStop(OO) {
          var KO, pO;
          const XO = bl();
          if (!XO || !XO.root.contains(OO)) return;
          const bK = null !== (KO = null === (pO = OO.closest(".Dropdown-root")) || void 0 === pO ? void 0 : pO.querySelector(".Dropdown-control")) && void 0 !== KO ? KO : OO,
            eO = Ze(bK, XO.root, this.getEnabledCandidates(XO.root));
          if (!eO) return;
          const lO = (0, Wb.n)(XO.layer);
          lO === this.layerKey && XO.root === this.layerRoot || this.beginLayer(XO, lO), this.wasActive ? this.setFocus(eO, {
            scroll: !1,
            byUser: !0
          }) : (this.pendingFocus = null, this.movedInLayer = !0, this.restoredFromMemory = !1, this.restoreOnFocusLoss = !1, this.focused = eO, this.lastFocusedCentre = fK(eO), this.rememberFocus(eO), this.notify())
        }
        getFocused() {
          return this.focused
        }
        isActive() {
          return this.wasActive
        }
        onChange(OO) {
          return this.listeners.add(OO), () => {
            this.listeners.delete(OO)
          }
        }
        notify() {
          for (const OO of this.listeners) OO()
        }
        deactivate() {
          var OO;
          if (this.wasActive) {
            this.wasActive = !1, this.layerKind = null, this.confirmPressedOn = null, this.retryMove = null, this.pendingFocus = null;
            for (const OO of this.dpadRepeats.values()) OO.reset();
            this.stickRepeat.reset(), null !== (OO = this.focused) && void 0 !== OO && OO.isConnected && cl(this.focused, null, fK(this.focused)), this.notify()
          }
        }
        setFocus(OO) {
          var KO;
          let {
            scroll: pO = !0,
            byUser: XO = !1
          } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          if (XO && (this.pendingFocus = null, this.movedInLayer = !0, this.restoredFromMemory = !1, this.restoreOnFocusLoss = !1), OO === this.focused) return;
          const bK = null !== (KO = this.focused) && void 0 !== KO && KO.isConnected ? this.focused : null;
          if (this.focused = OO, OO) {
            pO && (OO.classList.add(Te), OO.scrollIntoView({
              block: "nearest",
              inline: "nearest",
              behavior: "instant"
            })), XO && ((OO, KO) => {
              const pO = KO.closest("[data-pad-friends-column]");
              pO && OO && !pO.contains(OO) && (me = new WeakRef(OO))
            })(bK, OO);
            const KO = fK(OO);
            this.lastFocusedCentre = KO, this.movedInLayer && this.rememberFocus(OO), cl(bK, OO, KO), "false" === OO.getAttribute("aria-pressed") && OO.closest("[data-pad-select-on-focus]") && EK(OO)
          } else bK && cl(bK, null, fK(bK));
          this.notify()
        }
        rememberFocus(OO) {
          const KO = this.layerRoot;
          this.layerKey && KO && this.memory.remember(this.layerKey, OO, KO, (() => this.getEnabledCandidates(KO)))
        }
        noteCursorActivation(OO) {
          const KO = bl();
          if (!KO || !KO.root.contains(OO)) return;
          const pO = this.getEnabledCandidates(KO.root),
            XO = new Set(pO);
          let bK = OO;
          for (; bK && !XO.has(bK);) bK = bK === KO.root ? null : bK.parentElement;
          if (!(bK instanceof HTMLElement)) return;
          const eO = (0, Wb.n)(KO.layer);
          this.memory.enter(eO), this.memory.remember(eO, bK, KO.root, (() => pO))
        }
        notePageEnteredByCursor(OO) {
          return this.memory.enter(OO)
        }
        recallStop(OO, KO) {
          return this.findRemembered(OO, KO)
        }
        focusWhenFound(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500,
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
          this.pendingFocus = {
            find: OO,
            untilMs: performance.now() + KO,
            holdWhile: pO
          }
        }
        getEnabledCandidates(OO) {
          return oK(OO).filter((OO => !DK(OO)))
        }
        onFrame(OO) {
          var KO;
          const pO = bl();
          if (!pO) return;
          const XO = null !== (KO = this.findOpenDropdown(pO)) && void 0 !== KO ? KO : pO,
            bK = performance.now(),
            eO = (0, Wb.n)(XO.layer);
          if (eO !== this.layerKey || XO.root !== this.layerRoot) {
            const KO = this.focused;
            if (null !== this.layerKey && XO.root === this.layerRoot && KO && QK(KO, XO.root)) this.continueLayer(eO, KO), this.wasActive || this.resume(XO.root, bK);
            else {
              const KO = !this.wasActive && !OO.wokeDevice,
                lO = "death" === this.layerKind || KO,
                vK = this.enterLayer(XO, eO);
              "popup" !== XO.layer.kind || XO !== pO || vK ? "menu" === XO.layer.kind && lO && "inGame" === CO.d.get("gameState") && !(0, pb.f)(3e3) && (this.pressGuardExtends = !0, this.pressGuardUntilMs = bK + Pe) : (this.pressGuardExtends = KO, this.pressGuardUntilMs = bK + (KO ? Pe : lO ? 500 : 250))
            }
          } else this.wasActive || this.resume(XO.root, bK);
          if (this.layerKind = XO.layer.kind, this.wasActive || (this.wasActive = !0, this.notify()), OO.wokeDevice && this.focusPointedStop(XO.root), this.validateFocus(XO, bK), bK < this.pressGuardUntilMs && this.pressGuardExtends && (OO.wasPressed((0, DO.j)("menuConfirm")) || OO.wasPressed((0, DO.j)("menuBack"))) && (this.pressGuardUntilMs = bK + Pe), bK >= this.pressGuardUntilMs && this.handleButtons(OO, XO)) return;
          const lO = "hybrid" === Fe();
          if (lO && (OO => {
              const KO = le();
              return KO !== oe && (oe = KO, al.lock()), al.update(OO, (0, aK.i)().moveDeadzone)
            })(OO.leftStick)) return vK = this.getHandoff(), Me = vl(vK), he = le(), void MO.c.handOffHeldInput();
          var vK;
          this.handleDirections(OO, XO, bK, !lO), this.handleScroll(OO, XO)
        }
        findOpenDropdown(OO) {
          const KO = OO.root.querySelector(se);
          if (!KO || !hK(KO)) return null;
          let pO = this.dropdownLayers.get(KO);
          return pO || (this.dropdownLayerCounter++, pO = {
            id: `dropdown-${this.dropdownLayerCounter}`,
            kind: OO.layer.kind,
            getRoot: () => KO,
            close: () => {
              wK(KO)
            },
            memoryKey: null
          }, this.dropdownLayers.set(KO, pO)), {
            layer: pO,
            root: KO,
            order: OO.order
          }
        }
        focusPointedStop(OO) {
          const KO = (0, oO.e)(),
            pO = KO ? document.elementFromPoint(KO.x, KO.y) : null;
          if (!pO || !OO.contains(pO)) return;
          const XO = Ze(pO, OO, this.getEnabledCandidates(OO));
          XO && this.setFocus(XO, {
            scroll: !1,
            byUser: !0
          })
        }
        enterLayer(OO, KO) {
          const pO = this.beginLayer(OO, KO),
            XO = Le();
          return XO && Ge(XO, OO.root) ? (this.takeOver(OO.root, XO, this.enteredLayerAtMs), pO) : (this.restoreLayerFocus(OO.root, pO), pO)
        }
        beginLayer(OO, KO) {
          return this.layerKey = KO, this.layerRoot = OO.root, this.lastActivatedKey = null, this.movedInLayer = !1, this.scrolledInLayer = !1, this.restoreOnFocusLoss = !1, this.retryMove = null, this.pendingFocus = null, this.confirmPressedOn = null, this.lastRefocusCheckMs = -1 / 0, this.pressGuardUntilMs = -1 / 0, this.pressGuardExtends = !1, this.enteredLayerAtMs = performance.now(), this.lastFocusedCentre = null, this.memory.enter(KO)
        }
        restoreLayerFocus(OO, KO) {
          const pO = KO && this.layerKey ? this.findRemembered(OO, this.layerKey) : null;
          this.restoredFromMemory = null !== pO, this.setFocus(null !== pO && void 0 !== pO ? pO : this.pickInitial(OO, {
            waitForContent: !0
          }))
        }
        continueLayer(OO, KO) {
          this.layerKey = OO;
          const pO = this.memory.enter(OO);
          this.restoreOnFocusLoss = pO, this.movedInLayer && !pO && this.rememberFocus(KO)
        }
        resume(OO, KO) {
          var pO;
          const XO = Le();
          XO && Ge(XO, OO) ? this.takeOver(OO, XO, KO) : null !== (pO = this.focused) && void 0 !== pO && pO.isConnected && cl(null, this.focused, fK(this.focused))
        }
        pickPreferred(OO) {
          var KO;
          return null !== (KO = this.layerKey ? this.findRemembered(OO, this.layerKey) : null) && void 0 !== KO ? KO : this.pickInitial(OO, {
            waitForContent: !0
          })
        }
        findRemembered(OO, KO) {
          return this.memory.has(KO) ? this.memory.recall(KO, this.getEnabledCandidates(OO)) : null
        }
        getHandoff() {
          var OO, KO, pO;
          const XO = null !== (OO = this.focused) && void 0 !== OO && OO.isConnected ? this.focused : null,
            bK = null !== (KO = this.layerRoot) && void 0 !== KO && KO.isConnected ? this.layerRoot : null;
          return {
            point: XO ? fK(XO) : null !== (pO = this.lastFocusedCentre) && void 0 !== pO ? pO : this.getLayerStartPoint(bK),
            element: XO,
            direction: null
          }
        }
        getLayerStartPoint(OO) {
          if (!OO) return {
            x: window.innerWidth / 2,
            y: window.innerHeight / 2
          };
          const KO = this.pickInitial(OO, {
            includeDisabled: !0
          });
          return fK(null !== KO && void 0 !== KO ? KO : OO)
        }
        takeOver(OO, KO, pO) {
          const {
            element: XO,
            direction: bK,
            point: eO
          } = KO, lO = XO instanceof HTMLElement && QK(XO, OO) ? XO : null;
          if (!bK) {
            const KO = this.focused;
            return lO ? this.setFocus(lO, {
              scroll: !1,
              byUser: !0
            }) : this.focusNearest(OO, eO), void(this.focused && this.focused === KO && this.focused.isConnected && cl(null, this.focused, fK(this.focused)))
          }
          if (this.dpadRepeats.get(bK).update(!0, pO), lO) return this.setFocus(lO, {
            scroll: !1,
            byUser: !0
          }), void this.move(OO, bK, pO, !0);
          const vK = this.getEnabledCandidates(OO),
            CO = vK.map(Be),
            hO = Vb(new DOMRect(eO.x, eO.y, 0, 0), CO, bK),
            DO = hO >= 0 ? hO : fb(eO, CO);
          this.setFocus(DO >= 0 ? vK[DO] : this.pickInitial(OO), {
            byUser: !0
          })
        }
        focusNearest(OO, KO) {
          const pO = this.getEnabledCandidates(OO),
            XO = fb(KO, pO.map(Be));
          this.setFocus(XO >= 0 ? pO[XO] : this.pickInitial(OO), {
            byUser: !0
          })
        }
        pickDefault(OO) {
          let {
            includeDisabled: KO = !1,
            exclude: pO = null
          } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          const XO = [...OO.querySelectorAll(ml)].filter((XO => (null === pO || void 0 === pO || !pO.has(XO)) && (KO ? LK(XO, OO) : QK(XO, OO)))),
            bK = Ee(XO.map(gl));
          return bK >= 0 ? XO[bK] : null
        }
        pickNewAreaStart(OO, KO) {
          const pO = [...OO.querySelectorAll(Se)].filter(hK);
          for (const XO of [...zp(OO), ...pO]) {
            if (KO.has(XO)) continue;
            const OO = this.getEnabledCandidates(XO),
              pO = Ee(OO.map(gl));
            if (pO >= 0) return OO[pO]
          }
          return null
        }
        pickInitial(OO) {
          let {
            includeDisabled: KO = !1,
            waitForContent: pO = !1,
            enteredAtMs: XO = this.enteredLayerAtMs
          } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          const bK = this.pickDefault(OO, {
            includeDisabled: KO
          });
          if (bK) return bK;
          const eO = OO => KO ? oK(OO) : this.getEnabledCandidates(OO);
          let lO = [];
          for (const aK of zp(OO))
            if (lO = eO(aK), lO.length > 0) break;
          if (0 === lO.length) {
            if (pO && performance.now() - XO < 1e4 && (OO => {
                for (const KO of OO.querySelectorAll("[data-pad-initial-area]"))
                  if (!CK(KO, !1)) return !0;
                return !1
              })(OO)) return null;
            lO = eO(OO)
          }
          const vK = lO.map(Be),
            CO = rK(null),
            hO = lO.filter(((OO, KO) => PO(vK[KO], CO))),
            DO = hO.length > 0 ? hO : lO,
            MO = Ee(DO.map(gl));
          return MO >= 0 ? DO[MO] : null
        }
        validateFocus(OO, KO) {
          if (this.pendingFocus) {
            var pO, XO;
            const bK = this.pendingFocus.find();
            if (bK && QK(bK, OO.root)) return this.pendingFocus = null, void this.setFocus(bK, {
              byUser: !0
            });
            KO > this.pendingFocus.untilMs && (null === (pO = (XO = this.pendingFocus).holdWhile) || void 0 === pO || !pO.call(XO)) && (this.pendingFocus = null)
          }
          const bK = this.focused,
            eO = !!bK && QK(bK, OO.root);
          if (!(!eO && bK && bK === this.lastActivated && KO - this.lastActivatedAtMs < 5e3 && OO.root.contains(bK) && hK(bK) && DK(bK))) {
            if (!eO && this.restoreOnFocusLoss && this.layerKey) return this.restoreOnFocusLoss = !1, this.movedInLayer = !1, this.scrolledInLayer = !1, this.enteredLayerAtMs = KO, void this.restoreLayerFocus(OO.root, !0);
            if ((!eO || !this.movedInLayer && !this.scrolledInLayer) && !(KO - this.lastRefocusCheckMs < (eO ? 200 : 50)))
              if (this.lastRefocusCheckMs = KO, eO) {
                const pO = KO - this.enteredLayerAtMs < 15e3 ? this.pickPreferred(OO.root) : null,
                  XO = null !== pO && void 0 !== pO ? pO : this.restoredFromMemory ? null : this.pickDefault(OO.root);
                XO && XO !== bK && this.setFocus(XO)
              } else {
                if (this.lastFocusedCentre && this.movedInLayer) {
                  const KO = this.pendingFocus;
                  return this.focusNearest(OO.root, this.lastFocusedCentre), void(this.pendingFocus = KO)
                }
                this.setFocus(this.pickPreferred(OO.root))
              }
          }
        }
        handleButtons(OO, KO) {
          if (OO.wasPressed((0, DO.j)("menuToggleCursor"))) return Ve(this.getHandoff()), !0;
          if (OO.wasPressed((0, DO.j)("menuBack"))) {
            const OO = wK(KO.root);
            return OO ? this.setFocus(OO, {
              byUser: !0
            }) : sb(this, KO.root) || (sK(KO.root) ? this.returnToOpener(KO.root) : this.backToStrip(KO.root) || ee()), !0
          }
          const pO = (0, DO.j)("menuConfirm");
          var XO, bK;
          OO.wasPressed(pO) && (this.confirmPressedOn = this.focused, this.confirmRepeatKey = null !== (XO = null === (bK = this.focused) || void 0 === bK ? void 0 : bK.getAttribute("data-pad-repeat")) && void 0 !== XO ? XO : null, this.confirmRepeated = OO.wokeDevice, this.confirmRepeat.reset(), this.confirmRepeat.update(!0, performance.now()));
          if (OO.wasReleased(pO)) {
            const OO = this.confirmPressedOn;
            if (this.confirmPressedOn = null, OO && !this.confirmRepeated && OO === this.focused && OO.isConnected && !DK(OO)) {
              const pO = OO.matches("[data-pad-tab]") ? OO.closest(Re) : null;
              pO ? this.enterTab(OO, pO, KO.root, performance.now()) : this.activate(OO)
            }
            return !0
          }
          return this.repeatConfirm(OO, pO), qe(this, OO, KO)
        }
        repeatConfirm(OO, KO) {
          const pO = this.confirmPressedOn;
          pO && null !== this.confirmRepeatKey && OO.isHeld(KO) && (pO === this.focused && pO.isConnected && !DK(pO) && pO.getAttribute("data-pad-repeat") === this.confirmRepeatKey ? pO.hasAttribute("data-pad-repeat-wait") || this.confirmRepeat.update(!0, performance.now()) && (this.confirmRepeated = !0, this.activate(pO)) : this.confirmRepeatKey = null)
        }
        backToStrip(OO) {
          const KO = this.focused;
          if (!(0, aK.i)().menuBackToCategories) return !1;
          const pO = null !== KO && void 0 !== KO && KO.isConnected ? this.tabStripNav.backToStrip(KO, this.getEnabledCandidates(OO), OO) : null;
          return pO && this.setFocus(pO, {
            byUser: !0
          }), null !== pO
        }
        returnToOpener(OO) {
          const KO = this.lastActivatedKey;
          KO && (this.lastActivatedKey = null, this.focusWhenFound((() => {
            var pO;
            return null !== (pO = this.getEnabledCandidates(OO).find((OO => HK(OO) === KO))) && void 0 !== pO ? pO : null
          })))
        }
        activate(OO) {
          var KO;
          if ((0, Ne.d)(OO) || rp(OO)) return;
          this.lastActivatedKey = null !== (KO = HK(OO)) && void 0 !== KO ? KO : this.lastActivatedKey, this.lastActivated = OO, this.lastActivatedAtMs = performance.now(), this.rememberFocus(OO);
          const pO = this.layerRoot;
          if (pO) {
            const KO = new Set(pO.querySelectorAll(ml)),
              XO = new Set(pO.querySelectorAll(`[data-pad-initial-area], ${Se}`)),
              bK = this.lastActivatedAtMs;
            this.focusWhenFound((() => {
              var bK;
              return QK(OO, pO) ? null : null !== (bK = this.pickDefault(pO, {
                exclude: KO
              })) && void 0 !== bK ? bK : this.pickNewAreaStart(pO, XO)
            }), 5e3, (() => OO.isConnected && DK(OO) && performance.now() - bK < 6e4))
          }
          EK(OO), ip(OO)
        }
        handleDirections(OO, KO, pO, XO) {
          const bK = ye(KO.layer.kind) ? (0, DO.j)("chat") : null;
          for (const vK of FO.z) {
            this.dpadRepeats.get(vK).update(OO.isHeld(vK), pO) && (vK !== bK || OO.wasPressed(vK)) && this.move(KO.root, vK, pO, !0)
          }
          const eO = XO ? (0, FO.g)(OO.leftStick, (0, aK.i)().moveDeadzone) : {
              x: 0,
              y: 0
            },
            lO = this.stickRepeat.update((0, FO.mb)(eO), pO);
          if (lO && this.move(KO.root, lO, pO, !0), this.retryMove && pO >= this.retryMove.atMs) {
            const {
              direction: OO
            } = this.retryMove;
            this.retryMove = null, this.move(KO.root, OO, pO, !1)
          }
        }
        move(OO, KO, pO, XO) {
          var bK;
          let eO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
          if (this.pendingFocus && this.pendingFocus === (null === (bK = this.tabOpenWait) || void 0 === bK ? void 0 : bK.wait) && KO === this.tabOpenWait.direction) return;
          this.pendingFocus = null;
          const lO = this.focused;
          if (!lO || !lO.isConnected) {
            const KO = this.pickInitial(OO);
            return void(KO && this.setFocus(KO, {
              byUser: !0
            }))
          }
          const vK = "Left" === KO || "Right" === KO,
            CO = vK ? (0, Ne.d)(lO) : null;
          if (CO) return void CO.adjust("Left" === KO ? -1 : 1);
          const hO = OO => null !== OO.closest("[data-pad-friends-column]"),
            DO = hO(lO),
            MO = Be(lO),
            aK = vK || lO.closest(Re) ? null : (OO => {
              const KO = new Map;
              return pO => {
                const XO = pO.closest(Re);
                if (!XO) return !1;
                let bK = KO.get(XO);
                if (void 0 === bK) {
                  const pO = Be(XO);
                  bK = Fb(OO, pO) && (pO.right <= OO.left || pO.left >= OO.right), KO.set(XO, bK)
                }
                return bK
              }
            })(MO),
            oO = null !== lO.closest(He),
            FO = this.getEnabledCandidates(OO).filter((OO => OO !== lO && (vK || hO(OO) === DO) && !(null !== aK && void 0 !== aK && aK(OO)) && (oO || !OO.closest(He)))),
            VO = FO.map(Be),
            LO = uO(lO, "y", OO),
            QO = rK(LO);
          if (!eO && !PO(MO, QO)) {
            const OO = FO.filter(((OO, KO) => PO(VO[KO], QO)));
            if (OO.length > 0) {
              const KO = {
                x: QO.left + QO.width / 2,
                y: QO.top + QO.height / 2
              };
              return void this.setFocus(OO[fb(KO, OO.map(Be))], {
                byUser: !0
              })
            }
          }
          const zK = vK ? ((OO, KO, pO) => {
              const XO = Be(OO),
                bK = OO.closest(Re),
                eO = bK ? Be(bK) : null;
              return KO.map(((KO, lO) => {
                const vK = pO[lO];
                if (vK.bottom > XO.top && vK.top < XO.bottom) return !0;
                const CO = KO.closest(Re);
                if (bK && eO) return CO !== bK && (null !== CO || vK.bottom <= eO.top || vK.top >= eO.bottom);
                if (CO) return !Fb(XO, Be(CO));
                let hO = OO;
                for (let pO = OO.parentElement; pO && !pO.contains(KO); pO = pO.parentElement) hO = pO;
                const DO = Be(hO);
                return vK.right > DO.left && vK.left < DO.right
              }))
            })(lO, FO, VO) : void 0,
            AO = vK && !lO.closest(Re) ? (OO => OO.map((OO => !OO.closest(yl))))(FO) : void 0,
            fO = ((OO, KO) => {
              const pO = [];
              for (let bK = OO; bK; bK = bK.parentElement) pO.push(bK);
              const XO = new Map;
              return pO.forEach(((OO, KO) => {
                XO.set(OO, pO.length - 1 - KO)
              })), KO.map((OO => {
                for (let KO = OO; KO; KO = KO.parentElement) {
                  const OO = XO.get(KO);
                  if (void 0 !== OO) return OO
                }
                return -1
              }))
            })(lO, FO),
            dO = vK ? "x" : "y",
            TO = uO(lO, dO, OO);
          let NO = Vb(MO, VO, KO, fO, zK, AO);
          if (NO >= 0 && TO && !TO.contains(FO[NO])) {
            const OO = FO.flatMap(((OO, KO) => TO.contains(OO) ? [KO] : [])),
              pO = KO => KO && OO.map((OO => KO[OO])),
              XO = Vb(MO, OO.map((OO => VO[OO])), KO, OO.map((OO => fO[OO])), pO(zK), pO(AO));
            NO = XO >= 0 ? OO[XO] : NO
          }
          if (NO >= 0) return void this.moveTo(lO, FO[NO], FO, OO, KO, eO);
          if (!XO) return;
          const IO = "Right" === KO || "Down" === KO ? 1 : -1;
          if (TO && wO(TO, dO, IO)) {
            const OO = "y" === dO ? TO.clientHeight : TO.clientWidth;
            iK(TO, dO, IO * OO * .5), this.retryMove = {
              direction: KO,
              atMs: pO + 80
            }
          }
        }
        moveTo(OO, KO, pO, XO, bK, eO) {
          const lO = this.tabStripNav.findTabContent(OO, KO, pO);
          lO && "true" !== OO.dataset.padSelected ? this.openTab(OO, lO, XO, bK) : eO && !lO || this.setFocus(this.tabStripNav.redirect(OO, KO, pO, XO), {
            byUser: !0
          })
        }
        openTab(OO, KO, pO, XO) {
          const bK = KO.parentElement;
          EK(OO), this.focusWhenFound((() => "true" !== OO.dataset.padSelected ? null : KO.isConnected ? this.tabStripNav.pickContentStart(KO, this.getEnabledCandidates(pO), pO) : bK ? this.tabStripNav.pickReplacedContentStart(OO, bK, this.getEnabledCandidates(pO), pO) : null), 3e3), this.tabOpenWait = {
            wait: this.pendingFocus,
            direction: XO
          }
        }
        enterTab(OO, KO, pO, XO) {
          this.move(pO, (OO => {
            const KO = [...OO.querySelectorAll(Ye)].filter((KO => KO.closest(jl) === OO));
            if (KO.length >= 2) {
              const OO = KO[0].getBoundingClientRect(),
                pO = KO[1].getBoundingClientRect();
              return Math.abs(pO.top - OO.top) > Math.abs(pO.left - OO.left) ? "Right" : "Down"
            }
            const pO = OO.getBoundingClientRect();
            return pO.height > pO.width ? "Right" : "Down"
          })(KO), XO, !1, !0), this.focused !== OO || this.pendingFocus || this.activate(OO)
        }
        handleScroll(OO, KO) {
          const pO = (0, FO.g)(OO.rightStick, .2);
          if (0 === pO.x && 0 === pO.y) return void(this.scrollRemainder = {
            x: 0,
            y: 0
          });
          const XO = OO.dtMs / 1e3;
          for (const eO of ["x", "y"]) {
            var bK;
            const OO = pO[eO];
            if (0 === OO) continue;
            const lO = null !== (bK = uO(this.focused, eO, KO.root)) && void 0 !== bK ? bK : jK(KO.root, eO);
            if (!lO) continue;
            const vK = Math.sign(OO) * OO * OO * 1500 * XO + this.scrollRemainder[eO],
              CO = Math.trunc(vK);
            this.scrollRemainder[eO] = vK - CO, 0 !== CO && (iK(lO, eO, CO), this.scrolledInLayer = !0)
          }
        }
      },
      xl = ["controller:keyboardPhraseGg", "controller:keyboardPhraseHi", "controller:keyboardPhraseThanks", "controller:keyboardPhraseGl", "controller:keyboardPhraseBrb", "controller:keyboardPhraseYes", "controller:keyboardPhraseNo", "controller:keyboardPhraseHelp"];
    const ne = new class {
        constructor() {
          this.lastSendMs = -1 / 0
        }
        claim(OO) {
          return !(OO - this.lastSendMs < 2e3) && (this.lastSendMs = OO, !0)
        }
      },
      We = {
        visible: !1,
        target: null,
        kind: null,
        page: "letters",
        accentsFirst: !1,
        shift: "off",
        focus: {
          row: 0,
          col: 0
        },
        preferredX: 0,
        placement: "bottom",
        maxHeightPx: 0
      },
      tl = ["jG", "nameTag"],
      kl = OO => {
        const KO = OO.target instanceof HTMLTextAreaElement && !tl.includes(OO.kind);
        return ZX(OO.page, "chat" === OO.kind ? xl.length : 0, KO)
      },
      Ue = OO => {
        const KO = OO.getBoundingClientRect(),
          pO = window.innerHeight,
          XO = KO.top + KO.height / 2 < pO / 2 ? "bottom" : "top",
          bK = "bottom" === XO ? pO - KO.bottom - 6 : KO.top - 6;
        return {
          placement: XO,
          maxHeightPx: Math.min(.46 * pO, Math.max(.3 * pO, bK))
        }
      },
      Ol = OO => {
        (0, Ob.j)(OO) ? (0, Ob.d)().close(): (ql.noteChosenStop(OO), OO.blur())
      };
    class Kl {
      constructor(OO) {
        this.host = OO, this.lastShiftPressMs = -1 / 0, this.phraseTexts = [], this.phrasesFill = !1
      }
      setPhraseRow(OO, KO) {
        this.phraseTexts = OO, this.phrasesFill = KO
      }
      pressKey(OO) {
        const KO = this.host.getState(),
          pO = kl(KO),
          XO = pO[OO.row][OO.col];
        this.host.setState({
          ...KO,
          focus: OO,
          preferredX: xb(pO, OO)
        }), "char" === XO.type ? this.typeChar(XO.char) : "command" === XO.type ? this.runCommand(XO.command) : this.sendPhrase(XO.phraseIndex)
      }
      runCommand(OO) {
        const KO = this.host.getState();
        switch (OO) {
          case "backspace":
            eK(KO.target);
            break;
          case "space":
            bp(KO.target, " ");
            break;
          case "newline":
            bp(KO.target, "\n");
            break;
          case "caretLeft":
            lK(KO.target, -1);
            break;
          case "caretRight":
            lK(KO.target, 1);
            break;
          case "shift": {
            const OO = performance.now();
            this.host.setState({
              ...KO,
              shift: tb(KO.shift, OO, this.lastShiftPressMs)
            }), this.lastShiftPressMs = OO;
            break
          }
          case "page":
          case "otherPage": {
            const pO = BX(KO.page, KO.accentsFirst)[OO];
            this.host.setState({
              ...KO,
              page: pO,
              focus: WX(kl({
                ...KO,
                page: pO
              }), KO.focus)
            });
            break
          }
          case "submit":
            this.submit();
            break;
          case "close":
            this.close();
            break;
          case "channel":
            (0, Ob.j)(KO.target) && (0, Ob.d)().selectNextChannel()
        }
      }
      submit() {
        var OO, KO;
        const {
          target: pO
        } = this.host.getState();
        this.host.hide(), (0, Ob.j)(pO) ? (0, Ob.d)().submit() : (ql.noteChosenStop(pO), null === (OO = (KO = (0, Ob.g)(pO)).submit) || void 0 === OO || OO.call(KO), document.activeElement === pO && pO.blur())
      }
      close() {
        const {
          target: OO
        } = this.host.getState();
        this.host.hide(), Ol(OO)
      }
      typeChar(OO) {
        const {
          target: KO,
          page: pO,
          shift: XO
        } = this.host.getState();
        bp(KO, UX(OO, pO, XO)), this.host.setState({
          ...this.host.getState(),
          shift: kb(XO, OO)
        })
      }
      sendPhrase(OO) {
        if (this.phrasesFill) {
          const {
            target: KO
          } = this.host.getState(), pO = this.phraseTexts[OO];
          pO && (KO.setSelectionRange(0, KO.value.length), bp(KO, pO))
        } else ne.claim(performance.now()) && (this.host.hide(), (0, Ob.d)().sendLine(this.phraseTexts[OO]))
      }
    }
    const pl = {
        initialDelayMs: 380,
        intervalMs: 85
      },
      Xl = {
        initialDelayMs: 400,
        intervalMs: 55
      };
    class bv {
      constructor(OO, KO) {
        this.host = OO, this.editor = KO, this.lastDirection = null, this.navRepeat = new FO.b((0, VO.b)(pl)), this.commandRepeats = new Map(rb.filter((OO => {
          let {
            repeats: KO
          } = OO;
          return KO
        })).map((OO => {
          let {
            command: KO
          } = OO;
          return [KO, (0, VO.b)(Xl)]
        })))
      }
      reset() {
        this.navRepeat.reset();
        for (const OO of this.commandRepeats.values()) OO.reset()
      }
      onVisibleFrame(OO) {
        const KO = performance.now();
        for (const {
            command: bK,
            action: eO
          }
          of rb) {
          const pO = (0, DO.j)(eO),
            XO = this.commandRepeats.get(bK);
          if ((XO ? XO.update(OO.isHeld(pO), KO) : OO.wasPressed(pO)) && (this.editor.runCommand(bK), !this.host.getState().visible)) return
        }
        if (OO.wasPressed((0, DO.j)("keyboardType")) && (this.editor.pressKey(this.host.getState().focus), !this.host.getState().visible)) return;
        const pO = this.readNavDirection(OO);
        this.lastDirection = pO;
        const XO = this.navRepeat.update(pO, KO);
        XO && this.navigate(XO)
      }
      onHiddenFrame(OO, KO) {
        var pO;
        if (OO.wasPressed((0, DO.j)("keyboardClose"))) return void Ol(KO);
        const XO = (0, DO.j)("keyboardType");
        if (OO.wasPressed(XO)) return MO.c.consumeButton(XO), void this.host.open(KO);
        const bK = this.readNavDirection(OO),
          eO = null !== bK && bK !== this.lastDirection;
        if (this.lastDirection = bK, !eO || (0, Ob.j)(KO)) return;
        const lO = (null === (pO = bl()) || void 0 === pO ? void 0 : pO.root.contains(KO)) || null !== KO.closest(".EntireInventoryWrapper");
        Ol(KO), lO && MO.c.handOffHeldInput()
      }
      navigate(OO) {
        const KO = this.host.getState();
        if ("Up" === OO && 0 === KO.focus.row && "chat" === KO.kind) return (0, Ob.d)().stepHistory(), void this.host.setState({
          ...KO
        });
        const pO = ((OO, KO, pO, XO) => {
          if ("Left" === pO || "Right" === pO) {
            const XO = OO[KO.row].length,
              bK = (KO.col + ("Right" === pO ? 1 : -1) + XO) % XO,
              eO = {
                row: KO.row,
                col: bK
              };
            return {
              pos: eO,
              preferredX: xb(OO, eO)
            }
          }
          const bK = (KO.row + ("Down" === pO ? 1 : -1) + OO.length) % OO.length;
          return {
            pos: {
              row: bK,
              col: nX(OO, bK, XO)
            },
            preferredX: XO
          }
        })(kl(KO), KO.focus, OO, KO.preferredX);
        this.host.setState({
          ...KO,
          focus: pO.pos,
          preferredX: pO.preferredX
        })
      }
      readNavDirection(OO) {
        for (const KO of FO.z)
          if (OO.isHeld(KO)) return KO;
        return (0, FO.mb)((0, FO.g)(OO.leftStick, (0, aK.i)().moveDeadzone))
      }
    }
    const el = ["Up", "Down", "Left", "Right"],
      ll = new Set(["CapsLock", "Control", "Fn", "FnLock", "Hyper", "NumLock", "ScrollLock", "Shift", "Super"]);
    const vv = new class {
      constructor() {
        this.state = We, this.listeners = new Set, this.ownedField = null, this.pendingChatInput = null, this.pendingChatTimeout = 0, this.savedInputMode = null, this.editor = new Kl(this), this.padInput = new bv(this, this.editor)
      }
      getState() {
        return this.state
      }
      setState(OO) {
        const KO = OO.visible !== this.state.visible;
        this.state = OO;
        for (const pO of this.listeners) pO();
        KO && hO.i.pl(ZO.e, OO.visible)
      }
      subscribe(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      install() {
        const OO = MO.c.register({
            name: "keyboard",
            isActive: () => this.state.visible || kK(document.activeElement),
            onFrame: OO => {
              this.onFrame(OO)
            },
            onDeactivate: () => {
              this.padInput.reset()
            },
            wakePressActs: OO => el.includes(OO) || !this.state.visible && OO === (0, DO.j)("keyboardType")
          }),
          KO = OO => {
            const KO = OO.target;
            kK(KO) && (KO === this.pendingChatInput || (0, oO.o)() ? this.open(KO) : this.state.visible && KO !== this.state.target && (this.ownedField = null, this.hide()))
          },
          pO = () => {
            setTimeout((() => {
              this.releaseLostField()
            }), 0)
          },
          XO = OO => {
            OO.isTrusted && this.state.visible && (OO => !OO.repeat && !ll.has(OO.key) && !(0, Kb.e)(OO.key) && !/^(Audio|Media|Browser|Launch|Gamepad)/.test(OO.key))(OO) && this.hide()
          },
          bK = () => {
            this.state.visible && this.setState({
              ...this.state,
              ...Ue(this.state.target)
            })
          };
        document.addEventListener("focusin", KO, !0), document.addEventListener("focusout", pO, !0), window.addEventListener("keydown", XO, !0), window.addEventListener("resize", bK);
        const eO = hO.i.subscribe(dX.d, (() => {
            this.openChat()
          })),
          lO = hO.i.subscribe(ZO.h, (OO => {
            this.openForField(OO)
          }));
        return () => {
          OO(), document.removeEventListener("focusin", KO, !0), document.removeEventListener("focusout", pO, !0), window.removeEventListener("keydown", XO, !0), window.removeEventListener("resize", bK), hO.i.unsubscribe(eO), hO.i.unsubscribe(lO), this.clearPendingChat(), this.hide(), this.ownedField = null
        }
      }
      openChat() {
        const OO = (0, Ob.d)();
        OO ? document.activeElement !== OO.input ? (this.clearPendingChat(), this.pendingChatInput = OO.input, this.pendingChatTimeout = window.setTimeout((() => {
          this.pendingChatInput = null
        }), 250), OO.open()) : this.open(OO.input) : console.warn("controllerOpenChat with no chat mounted")
      }
      openForField(OO) {
        kK(OO) ? (document.activeElement !== OO && OO.focus(), document.activeElement === OO && this.open(OO)) : console.warn("controllerOpenKeyboard needs an editable input or textarea", OO)
      }
      open(OO) {
        var KO;
        if (this.clearPendingChat(), this.ownedField = OO, this.state.visible && this.state.target === OO) return;
        this.restoreInputMode(), (OO => {
          UO(OO) && 0 === OO.selectionStart && 0 === OO.selectionEnd && OO.setSelectionRange(OO.value.length, OO.value.length)
        })(OO), this.savedInputMode = OO.getAttribute("inputmode"), OO.setAttribute("inputmode", "none");
        const pO = {
          ...We,
          visible: !0,
          target: OO,
          kind: (0, Ob.j)(OO) ? "chat" : null !== (KO = (0, Ob.g)(OO).kind) && void 0 !== KO ? KO : null,
          accentsFirst: (XO = CX.f.get().getCurrentLanguageCode(), cb.has(XO)),
          ...Ue(OO)
        };
        var XO;
        const bK = kl(pO),
          eO = ((OO, KO) => {
            for (let pO = 0; pO < OO.length; pO++) {
              const XO = OO[pO].findIndex((OO => "char" === OO.type && OO.char === KO));
              if (-1 !== XO) return {
                row: pO,
                col: XO
              }
            }
            return null
          })(bK, "q");
        this.padInput.reset(), this.setState({
          ...pO,
          focus: eO,
          preferredX: xb(bK, eO)
        })
      }
      hide() {
        this.state.visible && (this.restoreInputMode(), this.padInput.reset(), this.setState(We))
      }
      onFrame(OO) {
        if (this.releaseLostField()) return;
        const KO = document.activeElement;
        this.state.visible ? this.padInput.onVisibleFrame(OO) : kK(KO) && this.padInput.onHiddenFrame(OO, KO)
      }
      releaseLostField() {
        const OO = this.ownedField;
        return !(null === OO || OO.isConnected && document.activeElement === OO) && (this.ownedField = null, this.hide(), !0)
      }
      clearPendingChat() {
        window.clearTimeout(this.pendingChatTimeout), this.pendingChatInput = null
      }
      restoreInputMode() {
        const {
          target: OO
        } = this.state;
        OO && (null === this.savedInputMode ? OO.removeAttribute("inputmode") : OO.setAttribute("inputmode", this.savedInputMode), this.savedInputMode = null)
      }
    };
    var Cl = pO(7857);
    const hl = new Map(rb.map((OO => {
        let {
          command: KO,
          action: pO
        } = OO;
        return [KO, pO]
      }))),
      Dl = {
        letters: "ABC",
        accents: "\xe0\xe9",
        symbols: "&123"
      },
      Ml = {
        chat: "controller:keyboardTargetChat",
        sign: "controller:keyboardTargetSign",
        nameTag: "controller:keyboardTargetNameTag",
        book: "controller:keyboardTargetBook",
        jG: "controller:keyboardTargetBookTitle"
      },
      av = OO => {
        const KO = (() => {
          const [, OO] = (0, mK.useReducer)((OO => OO + 1), 0);
          return OO
        })();
        (0, mK.useEffect)((() => {
          if (!OO) return;
          const pO = ["input", "select", "selectionchange", "keyup", "pointerup"];
          for (const bK of pO) OO.addEventListener(bK, KO);
          document.addEventListener("selectionchange", KO);
          const XO = new MutationObserver(KO);
          return XO.observe(OO, {
            attributeFilter: ["placeholder"]
          }), () => {
            XO.disconnect();
            for (const XO of pO) OO.removeEventListener(XO, KO);
            document.removeEventListener("selectionchange", KO)
          }
        }), [OO, KO])
      },
      ol = OO => {
        OO.preventDefault()
      },
      Fl = OO => {
        "mouse" !== OO.pointerType && OO.preventDefault()
      },
      Vl = () => {
        var OO;
        const {
          t: KO
        } = (0, bK.D)(), pO = (() => {
          const [OO, KO] = (0, mK.useState)(vv.getState());
          return (0, mK.useEffect)((() => vv.subscribe((() => {
            KO(vv.getState())
          }))), []), OO
        })(), XO = (0, oO.C)(), eO = (0, mK.useRef)(null);
        (0, aK.p)(), (0, oO.E)(), (0, mK.useEffect)((() => {
          const OO = vv.install(),
            KO = null;
          return () => {
            OO(), null === KO || void 0 === KO || KO()
          }
        }), []);
        const lO = (0, mK.useMemo)((() => xl.map((OO => KO(OO)))), [KO]),
          vK = pO.visible && "chat" === pO.kind ? pO.target : null;
        av(vK);
        const CO = null !== (OO = null === vK || void 0 === vK ? void 0 : vK.value) && void 0 !== OO ? OO : "",
          hO = ((OO, KO, pO) => {
            if (!OO.startsWith("/")) return [];
            const XO = [];
            for (let bK = KO.length - 1; bK >= 0 && XO.length < pO; bK--) {
              const pO = KO[bK].trim();
              pO.startsWith(OO) && pO !== OO && !XO.includes(pO) && XO.push(pO)
            }
            return XO
          })(CO, CO.startsWith("/") ? (0, Cl.h)() : [], xl.length),
          MO = CO.startsWith("/"),
          FO = MO ? xl.map(((OO, KO) => {
            var pO;
            return null !== (pO = hO[KO]) && void 0 !== pO ? pO : ""
          })) : lO;
        if ((0, mK.useEffect)((() => {
            vv.editor.setPhraseRow(FO, MO)
          })), (0, mK.useEffect)((() => {
            const OO = eO.current;
            if (OO) return OO.addEventListener("touchstart", ol, {
              passive: !1
            }), () => {
              OO.removeEventListener("touchstart", ol)
            }
          }), [pO.visible]), !pO.visible) return null;
        const VO = kl(pO),
          LO = qb(VO),
          QO = OO => "char" === OO.type ? UX(OO.char, pO.page, pO.shift) : "phrase" === OO.type ? FO[OO.phraseIndex] : (OO => {
            switch (OO) {
              case "backspace":
                return "\u232b";
              case "shift":
                return "caps" === pO.shift ? "\u21ea" : "\u21e7";
              case "page":
              case "otherPage":
                return Dl[BX(pO.page, pO.accentsFirst)[OO]];
              case "space":
                return KO("controller:keyboardSpace");
              case "caretLeft":
                return "\u2190";
              case "caretRight":
                return "\u2192";
              case "newline":
                return "\u21b5";
              case "submit":
                return KO("chat" === pO.kind ? "controller:keyboardSend" : "controller:keyboardDone");
              case "close":
                return "\u2715";
              case "channel":
                return "\u21c4"
            }
          })(OO.command),
          zK = OO => {
            vv.editor.pressKey(OO)
          };
        return (0, RO.jsxs)("div", {
          ref: eO,
          className: HO()(Ob.m, "top" === pO.placement ? "PadKeyboardTop" : "PadKeyboardBottom", {
            PadKeyboardMultiline: pO.target instanceof HTMLTextAreaElement
          }),
          style: {
            "--pad-keyboard-rows": VO.length,
            "--pad-keyboard-height": `${pO.maxHeightPx}px`
          },
          onPointerDown: Fl,
          onMouseDown: ol,
          children: [(0, RO.jsx)(Ll, {
            target: pO.target,
            label: pO.kind ? KO(Ml[pO.kind]) : pO.target.placeholder || KO("controller:keyboardTargetText")
          }), (0, RO.jsx)("div", {
            className: "PadKeyboardRows",
            children: VO.map(((OO, KO) => (0, RO.jsx)("div", {
              className: HO()("PadKeyboardRow", {
                PadKeyboardPhraseRow: "phrase" === OO[0].type
              }),
              children: OO.map(((OO, bK) => {
                const eO = XO && pO.focus.row === KO && pO.focus.col === bK,
                  lO = "command" === OO.type ? hl.get(OO.command) : void 0;
                return (0, RO.jsx)("div", {
                  className: "PadKeyboardKeySlot",
                  style: {
                    width: OO.width / LO * 100 + "%"
                  },
                  children: (0, RO.jsxs)("div", {
                    className: HO()("PadKeyboardKey", {
                      PadKeyboardKeyFocused: eO,
                      PadKeyboardKeyCommand: "command" === OO.type,
                      PadKeyboardKeyPhrase: "phrase" === OO.type,
                      PadKeyboardKeyActive: "command" === OO.type && "shift" === OO.command && "off" !== pO.shift,
                      PadKeyboardKeySubmit: "command" === OO.type && "submit" === OO.command
                    }),
                    role: "button",
                    onClick: () => {
                      zK({
                        row: KO,
                        col: bK
                      })
                    },
                    onTouchEnd: OO => {
                      var pO, XO;
                      OO.preventDefault(), pO = OO.changedTouches[0], XO = OO.currentTarget.getBoundingClientRect(), pO && pO.clientX >= XO.left && pO.clientX <= XO.right && pO.clientY >= XO.top && pO.clientY <= XO.bottom && zK({
                        row: KO,
                        col: bK
                      })
                    },
                    children: [(0, RO.jsx)("span", {
                      className: "PadKeyboardKeyLabel",
                      children: QO(OO)
                    }), XO && lO && (0, RO.jsx)(oX, {
                      className: "PadKeyboardKeyGlyph",
                      glyph: (0, DO.j)(lO)
                    })]
                  })
                }, bK)
              }))
            }, KO)))
          })]
        })
      },
      Ll = OO => {
        let {
          target: KO,
          label: pO
        } = OO;
        av(KO);
        const XO = (0, mK.useRef)(null),
          bK = (0, mK.useRef)(null),
          eO = KO instanceof HTMLTextAreaElement;
        (0, mK.useLayoutEffect)((() => {
          const OO = XO.current,
            KO = bK.current;
          eO ? OO.scrollTop = KO.offsetTop - OO.clientHeight / 2 : OO.scrollLeft = KO.offsetLeft - OO.clientWidth / 2
        }));
        const {
          value: lO,
          start: vK,
          end: CO
        } = OK(KO), hO = "password" === KO.type ? "\u2022".repeat(lO.length) : lO;
        return (0, RO.jsxs)("div", {
          className: "PadKeyboardPreview",
          children: [(0, RO.jsx)("div", {
            className: "PadKeyboardPreviewLabel SmallTextBold",
            children: pO
          }), (0, RO.jsxs)("div", {
            ref: XO,
            className: HO()("PadKeyboardPreviewText", {
              PadKeyboardPreviewMultiline: eO
            }),
            children: [(0, RO.jsx)("span", {
              children: hO.slice(0, vK)
            }), (0, RO.jsx)("span", {
              ref: bK,
              className: "PadKeyboardCaret"
            }), vK !== CO && (0, RO.jsx)("span", {
              className: "PadKeyboardPreviewSelection",
              children: hO.slice(vK, CO)
            }), (0, RO.jsx)("span", {
              children: hO.slice(CO)
            }), 0 === hO.length && KO.placeholder && KO.placeholder !== pO && (0, RO.jsx)("span", {
              className: "PadKeyboardPreviewPlaceholder",
              children: KO.placeholder
            })]
          })]
        })
      };
    var Ql = pO(1225),
      zv = pO(2692);
    const Al = function() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        return KO.map(DO.j)
      },
      fl = (OO, KO) => {
        const pO = Hb(OO);
        return pO ? [{
          glyphs: [pO],
          labelKey: KO
        }] : []
      },
      dl = [".BottomMiddleElements", ".BottomLeftElements > *", ".BottomRightElements > *", ".MiddleTextBottom .MiddleText"],
      Tl = "--pad-hint-bar-clearance",
      Nl = "[data-pad-hint-bar-avoid]",
      Il = OO => {
        const KO = [];
        for (const pO of OO) hK(pO) && KO.push(pO.getBoundingClientRect());
        return KO
      },
      yv = OO => {
        if (!OO) return null;
        const KO = bl(),
          pO = KO ? Il(((OO, KO) => {
            const pO = OO.closest(Nl);
            return pO ? [pO] : ("popup" === KO ? document : OO).querySelectorAll(Nl)
          })(KO.root, KO.layer.kind)) : [],
          XO = !KO || KO.root.hasAttribute("data-pad-shows-hud");
        if (((0, zv.f)(null === KO || void 0 === KO ? void 0 : KO.layer.kind, (0, zv.h)()) || XO) && pO.push(...Il(document.querySelectorAll(dl.join(",")))), 0 === pO.length) return null;
        const {
          width: bK,
          height: eO
        } = OO.getBoundingClientRect(), lO = window.innerHeight - 8, vK = (0, zv.l)(lO, {
          width: bK,
          height: eO
        }, window.innerWidth / 2, pO, 8);
        return vK === lO ? null : Math.round(window.innerHeight - vK)
      },
      gv = OO => {
        const KO = document.documentElement.style,
          pO = OO ? `${Math.round(window.innerHeight-OO.getBoundingClientRect().top)}px` : "";
        KO.getPropertyValue(Tl) !== pO && (pO ? KO.setProperty(Tl, pO) : KO.removeProperty(Tl))
      },
      ul = () => {
        const {
          t: OO
        } = (0, bK.D)(), {
          hideButtonHints: KO
        } = (0, aK.p)(), pO = (0, oO.C)(), [XO, eO] = (0, mK.useState)(!1), [lO, hO] = (0, mK.useState)([]), [VO, LO] = (0, mK.useState)(null), QO = (0, mK.useRef)(null), zK = (0, mK.useRef)(null);
        (0, vb.f)(ZO.e, (OO => {
          eO(OO)
        })), (0, vb.f)(zv.i, (() => {
          var OO;
          null === (OO = zK.current) || void 0 === OO || OO.call(zK)
        }));
        const AO = pO && !KO && !XO;
        return (0, mK.useEffect)((() => {
          if (!AO) return;
          let OO = null;
          const KO = () => {
            const KO = (() => {
                var OO;
                const KO = MO.c.getActiveConsumerName(),
                  pO = (0, zv.e)();
                if (pO) {
                  const OO = (0, DO.j)(pO),
                    KO = "emoteWheel" === pO && "wheel" === (0, aK.i)().emoteButton || !(0, FO.J)(MO.c.getLastFrame().values, OO) ? {
                      glyphs: Al("menuConfirm"),
                      labelKey: "controller:menusSelect"
                    } : {
                      glyphs: [OO],
                      labelKey: "controller:wheelReleaseToPick"
                    };
                  return [{
                    glyphs: [(0, DO.w)(OO)],
                    labelKey: "controller:wheelChoose"
                  }, KO, {
                    glyphs: Al("menuBack"),
                    labelKey: "controller:wheelClose"
                  }]
                }
                const XO = bl();
                if (!XO || "focus" !== KO && "cursor" !== KO) return (0, zv.b)(DO.j);
                const bK = [],
                  eO = {
                    glyphs: Al("menuBack"),
                    labelKey: "controller:menusBack"
                  },
                  lO = mp(XO.root),
                  vK = lO ? !DK(lO) : Boolean(XO.layer.close),
                  hO = !lO && XO.layer.closeLabelKey ? XO.layer.closeLabelKey : eO.labelKey,
                  oO = vK ? [{
                    ...eO,
                    labelKey: hO
                  }] : [],
                  VO = ye(XO.layer.kind) ? [{
                    glyphs: Al("chat"),
                    labelKey: "controller:menusQuickChat"
                  }] : [];
                if ("cursor" === KO) return bK.push({
                  glyphs: Al("menuConfirm"),
                  labelKey: "controller:menusClick"
                }), bK.push({
                  glyphs: Al("menuSecondary"),
                  labelKey: "controller:menusRightClick"
                }), bK.push(...oO), bK.push(...VO), bK.push({
                  glyphs: ["RightStick"],
                  labelKey: "controller:menusScroll"
                }), Ae() && bK.push({
                  glyphs: Al("menuToggleCursor"),
                  labelKey: "controller:menusFocusMode"
                }), bK;
                const LO = ql.getFocused();
                LO && (0, Ne.d)(LO) ? bK.push({
                  glyphs: ["Left", "Right"],
                  labelKey: "controller:menusAdjust"
                }) : LO && rp(LO) ? bK.push({
                  glyphs: [],
                  labelKey: "controller:menusUseMouse"
                }) : bK.push({
                  glyphs: Al("menuConfirm"),
                  labelKey: "controller:menusSelect"
                });
                const QO = LO ? null === (OO = Cb(LO)) || void 0 === OO ? void 0 : OO.dataset.padSecondary : void 0;
                QO && bK.push({
                  glyphs: Al("menuSecondary"),
                  labelKey: QO
                }), bK.push(...null !== LO && void 0 !== LO && LO.closest("[data-pad-friends-column]") ? [eO] : oO), bK.push(...VO);
                const zK = "home" === XO.layer.kind;
                Jb(XO.root) || !je(XO.root) && !ce(XO) ? zK && bK.push({
                  glyphs: Al("menuTabPrevious", "menuTabNext"),
                  labelKey: "controller:menusRows"
                }) : bK.push({
                  glyphs: Al("menuTabPrevious", "menuTabNext"),
                  labelKey: "controller:menusTabs"
                }), zK && (bK.push(...fl("inventory", "controller:menusFriends")), QO || bK.push({
                  glyphs: Al("menuSecondary"),
                  labelKey: "controller:menusSearch"
                }), bK.push(...fl("pause", "controller:menusSettings")), bK.push(...fl("leaderboard", "controller:menusNotifications")));
                const AO = CO.d.get("openEverythingMenuName");
                return "inGame" === CO.d.get("gameState") && "popup" !== XO.layer.kind && null !== AO && ((0, be.h)(AO) ? bK.push(...fl("leaderboard", "controller:menusClose")) : AO !== Xb.o.LOBBY_LEADERBOARD && bK.push(...fl("leaderboard", "controller:menusLobby"))), bK.push({
                  glyphs: Al("menuToggleCursor"),
                  labelKey: "controller:menusCursorMode"
                }), bK
              })(),
              pO = yv(QO.current),
              XO = ((OO, KO) => `${OO.map((OO=>`${OO.glyphs.join("+")}:${OO.labelKey}`)).join("|")}@${KO}`)(KO, pO);
            XO !== OO && (OO = XO, (0, vK.unstable_batchedUpdates)((() => {
              hO(KO), LO(pO)
            }))), gv(QO.current)
          };
          KO(), zK.current = KO;
          const pO = requestAnimationFrame(KO),
            XO = setInterval(KO, 150);
          return () => {
            zK.current = null, cancelAnimationFrame(pO), clearInterval(XO), gv(null)
          }
        }), [AO]), (0, mK.useLayoutEffect)((() => {
          if (!AO) return;
          if (0 === lO.length) return void gv(null);
          const OO = yv(QO.current);
          OO === VO ? gv(QO.current) : LO(OO)
        }), [AO, lO, VO]), AO && 0 !== lO.length ? (0, RO.jsx)("div", {
          ref: QO,
          className: "PadButtonHintBar SmallTextBold",
          style: null === VO ? void 0 : {
            bottom: VO
          },
          "aria-hidden": !0,
          children: lO.map((KO => (0, RO.jsxs)("div", {
            className: "PadButtonHint",
            children: [KO.glyphs.map((OO => (0, RO.jsx)(oX, {
              glyph: OO,
              className: "PadButtonHintGlyph"
            }, OO))), (0, RO.jsx)("span", {
              children: OO(KO.labelKey)
            })]
          }, KO.labelKey)))
        }) : null
      },
      El = [vp, "label", "[data-pad-slider]"].join(","),
      jv = "data-pad-cursor-probe",
      Yl = OO => {
        var KO;
        const pO = (OO => {
          const KO = [];
          for (let XO = OO; XO && XO !== document.body && XO !== document.documentElement && (KO.push(XO), !(KO.length > 8)); XO = XO.parentElement);
          const pO = document.documentElement.classList.contains(oO.w) ? KO[KO.length - 1] : void 0;
          null === pO || void 0 === pO || pO.setAttribute(jv, "");
          try {
            return KO.map((OO => ({
              element: OO,
              cursor: getComputedStyle(OO).cursor
            })))
          } finally {
            null === pO || void 0 === pO || pO.removeAttribute(jv)
          }
        })(OO);
        if ("pointer" !== (null === (KO = pO[0]) || void 0 === KO ? void 0 : KO.cursor)) return null;
        let XO = 0;
        for (; XO + 1 < pO.length && "pointer" === pO[XO + 1].cursor;) XO++;
        return pO[XO].element
      },
      wl = (OO, KO, pO, XO) => {
        const bK = XO.root.contains(OO) ? XO.root : null;
        for (let eO = OO; eO && eO !== document.body && eO !== document.documentElement; eO = eO.parentElement) {
          if (eO instanceof HTMLElement && gK(eO, KO) && wO(eO, KO, pO)) return eO;
          if (eO === bK) break
        }
        return "home" === XO.layer.kind || "gamePage" === XO.layer.kind ? ((OO, KO) => {
          const pO = document.scrollingElement;
          return pO instanceof HTMLElement && ![document.documentElement, document.body].some((KO => {
            const pO = getComputedStyle(KO),
              XO = "y" === OO ? pO.overflowY : pO.overflowX;
            return "hidden" === XO || "clip" === XO
          })) && wO(pO, OO, KO) ? pO : null
        })(KO, pO) : null
      };
    const iv = new class {
        constructor() {
          this.state = {
            x: 0,
            y: 0,
            speedRamp: 0
          }, this.hasPosition = !1, this.active = !1, this.hidden = !1, this.hit = null, this.interactive = null, this.magnet = null, this.lastHitTestMs = -1 / 0, this.press = null, this.draggedSlider = null, this.repeatStop = null, this.repeatKey = null, this.repeated = !1, this.confirmRepeat = (0, VO.b)(FO.s), this.secondaryArmed = !1, this.scrollRemainder = {
            x: 0,
            y: 0
          }, this.layerRoot = null, this.layerOrder = 0, this.layerPoints = new WeakMap, this.page = null, this.pendingPageStart = null
        }
        install() {
          const OO = MO.c.register({
              name: "cursor",
              isActive: () => "cursor" === fe(),
              onFrame: OO => {
                this.onFrame(OO)
              },
              onDeactivate: () => {
                this.deactivate()
              },
              wakePressActs: OO => (0, MO.f)(OO) || OO === (0, DO.j)("menuConfirm") && PK((0, oO.e)())
            }),
            KO = (0, Wb.j)((OO => {
              const KO = OO.getRoot();
              KO && this.layerPoints.delete(KO), KO === this.layerRoot && (this.layerRoot = null)
            })),
            pO = hO.i.subscribe("appManagerUpdated|activeInputDevice", (OO => {
              "gamepad" !== OO && this.active && !this.hidden && this.hide()
            }));
          return () => {
            OO(), KO(), hO.i.unsubscribe(pO), this.deactivate()
          }
        }
        getHighlighted() {
          return this.isVisible() ? this.interactive : null
        }
        isVisible() {
          return this.active && !this.hidden && (0, oO.o)()
        }
        getPoint() {
          return {
            x: this.state.x,
            y: this.state.y
          }
        }
        hide() {
          this.hidden = !0, this.cancelPress(), this.secondaryArmed = !1, this.clearHover(), this.pl()
        }
        activate(OO) {
          this.active = !0, this.hidden = !1;
          const KO = Le();
          !KO || KO.root && KO.root !== OO.root ? this.jumpTo(this.hasPosition ? this.getPoint() : {
            x: window.innerWidth / 2,
            y: window.innerHeight / 2
          }) : (this.setLayer(OO), this.jumpTo(KO.point))
        }
        jumpTo(OO) {
          this.state = {
            x: OO.x,
            y: OO.y,
            speedRamp: 0
          }, this.hasPosition = !0, this.lastHitTestMs = -1 / 0
        }
        deactivate() {
          this.active && (this.active = !1, this.page = null, this.pendingPageStart = null, this.cancelPress(), this.clearHover(), this.draggedSlider = null, this.secondaryArmed = !1, this.scrollRemainder = {
            x: 0,
            y: 0
          }, this.pl())
        }
        onFrame(OO) {
          const KO = bl();
          if (!KO) return;
          if (this.active || this.activate(KO), this.followPage(KO)) return;
          this.followLayer(KO);
          const pO = OO.wokeDevice ? (0, oO.e)() : null;
          if (pO && this.jumpTo(pO), !(0, oO.o)()) return void this.hide();
          const XO = (0, DO.j)("menuToggleCursor");
          if (OO.wasPressed(XO)) return MO.c.consumeButton(XO), void Ve(this.getHandoff(null));
          if (this.handBackToFocus(OO)) return;
          const bK = (0, DO.j)("menuConfirm"),
            eO = (0, DO.j)("menuSecondary");
          if (OO.wasPressed((0, DO.j)("menuBack"))) return wK(KO.root) || sK(KO.root) || ee(), void this.pl();
          if (Gb(null, OO, KO)) return OO.wasReleased(bK) && this.press && (this.updateHit(!1), this.updateConfirm(OO, bK)), void this.pl();
          if (document.pointerLockElement) return void this.hide();
          const lO = de() ? {
              x: 0,
              y: 0
            } : (OO => {
              const KO = (OO, KO) => (OO ? 1 : 0) - (KO ? 1 : 0);
              return {
                x: KO(OO.isHeld("Right"), OO.isHeld("Left")),
                y: KO(OO.isHeld("Down"), OO.isHeld("Up"))
              }
            })(OO),
            vK = (0, aK.i)().moveDeadzone,
            CO = ((OO, KO) => {
              const pO = (0, FO.g)(OO, fO(KO));
              return Math.hypot(pO.x, pO.y)
            })(OO.leftStick, vK) > 0 || 0 !== lO.x || 0 !== lO.y;
          if (this.hidden) {
            const KO = OO.wasPressed(bK),
              pO = OO.wasPressed(eO);
            if (!CO && !NO(OO.rightStick) && !KO && !pO && !OO.wokeDevice) return void this.pl();
            if (this.hidden = !1, this.updateHit(!1), KO || pO) return KO && (this.press = {
              kind: "ignored"
            }, OO.wokeDevice && this.beginRepeat()), this.secondaryArmed = !1, void this.pl()
          }
          this.movePendingPageStart(CO);
          const hO = this.getPoint();
          this.state = TO(this.state, {
            stick: OO.leftStick,
            moveDeadzone: vK,
            dpad: lO,
            dtMs: OO.dtMs,
            cursorSpeedPercent: (0, aK.i)().cursorSpeed,
            viewport: {
              width: window.innerWidth,
              height: window.innerHeight
            },
            context: this.getAssistContext()
          });
          const VO = this.state.x !== hO.x || this.state.y !== hO.y,
            LO = [bK, eO].some((KO => OO.wasPressed(KO) || OO.wasReleased(KO)));
          (VO || LO || performance.now() - this.lastHitTestMs >= 100) && this.updateHit(VO), this.updateConfirm(OO, bK), this.updateSecondary(OO, eO), this.updateScroll(OO, KO), this.pl()
        }
        followPage(OO) {
          const KO = "home" === OO.layer.kind || "gamePage" === OO.layer.kind,
            pO = this.page;
          if (this.page = KO ? {
              key: (0, Wb.n)(OO.layer),
              root: OO.root
            } : null, !this.page || !pO || pO.root !== OO.root || pO.key === this.page.key) return !1;
          if (this.cancelPress(), this.secondaryArmed = !1, this.setLayer(OO), "hybrid" === Fe()) return Me = null, he = null, al.lock(), !0;
          const {
            key: XO
          } = this.page;
          return this.pendingPageStart = {
            root: OO.root,
            key: XO,
            returning: ql.notePageEnteredByCursor(XO),
            enteredAtMs: performance.now()
          }, !1
        }
        movePendingPageStart(OO) {
          const KO = this.pendingPageStart;
          if (!KO) return;
          if (OO || KO.root !== this.layerRoot) return void(this.pendingPageStart = null);
          const pO = KO.returning ? ql.recallStop(KO.root, KO.key) : null;
          if (!pO && KO.returning && performance.now() - KO.enteredAtMs < 1e3) return;
          const XO = null !== pO && void 0 !== pO ? pO : ql.pickInitial(KO.root, {
            includeDisabled: !0,
            waitForContent: !0,
            enteredAtMs: KO.enteredAtMs
          });
          XO && (this.pendingPageStart = null, this.jumpTo(fK(XO)))
        }
        setLayer(OO) {
          this.layerRoot = OO.root, this.layerOrder = OO.order
        }
        followLayer(OO) {
          var KO;
          if (OO.root === this.layerRoot) return;
          null !== (KO = this.layerRoot) && void 0 !== KO && KO.isConnected && this.layerPoints.set(this.layerRoot, this.getPoint()), this.cancelPress(), this.draggedSlider = null, this.secondaryArmed = !1;
          const pO = this.layerPoints.get(OO.root),
            XO = pO && OO.order <= this.layerOrder ? pO : ql.getLayerStartPoint(OO.root);
          this.setLayer(OO), this.jumpTo(XO)
        }
        getHandoff(OO) {
          var KO;
          return {
            point: this.getPoint(),
            element: null !== (KO = this.interactive) && void 0 !== KO ? KO : this.findDraggedSliderNearby(),
            direction: OO
          }
        }
        findDraggedSliderNearby() {
          const OO = this.draggedSlider;
          if (null === OO || void 0 === OO || !OO.isConnected) return null;
          const KO = OO.getBoundingClientRect(),
            {
              y: pO
            } = this.getPoint();
          return pO >= KO.top - 40 && pO <= KO.bottom + 40 ? OO : null
        }
        handBackToFocus(OO) {
          if (!de()) return !1;
          const KO = FO.z.find((KO => OO.wasPressed(KO)));
          return !!KO && (pO = this.getHandoff(KO), Me = vl(pO), he = null, al.lock(), MO.c.handOffHeldInput(), !0);
          var pO
        }
        getAssistContext() {
          const OO = this.interactive;
          if (null === OO || void 0 === OO || !OO.isConnected) return {
            overInteractive: !1,
            magnetTarget: null
          };
          const KO = OO.getBoundingClientRect();
          if (KO.width > .4 * window.innerWidth || KO.height > .4 * window.innerHeight) return {
            overInteractive: !1,
            magnetTarget: null
          };
          const pO = (0, aK.i)().cursorMagnetism && !(0, GO.d)(OO) && !OO.closest("[data-pad-slider]"),
            XO = this.magnet && this.magnet !== OO && this.magnet.isConnected ? this.magnet.getBoundingClientRect() : KO;
          return {
            overInteractive: !0,
            magnetTarget: pO ? {
              x: XO.left + XO.width / 2,
              y: XO.top + XO.height / 2
            } : null
          }
        }
        updateHit(OO) {
          this.lastHitTestMs = performance.now();
          const KO = this.getPoint(),
            pO = document.elementFromPoint(KO.x, KO.y),
            XO = pO && !(0, QO.o)(pO) && (OO => {
              var KO;
              const pO = bl();
              return !(pO && !pO.root.contains(OO) && !OO.closest(".tooltip-container")) || !(null !== (KO = document.getElementById("root")) && void 0 !== KO && KO.contains(OO))
            })(pO) ? pO : null;
          if (XO !== this.hit) return gp(this.hit, XO, KO), this.hit = XO, void this.setInteractive(XO ? (OO => {
            const KO = OO.closest(El);
            if (KO) {
              var pO, XO;
              const OO = null !== (pO = null === (XO = KO.parentElement) || void 0 === XO ? void 0 : XO.closest("[data-pad-focusable]")) && void 0 !== pO ? pO : KO;
              return DK(OO) ? {
                element: null,
                magnet: null
              } : {
                element: OO,
                magnet: KO
              }
            }
            const bK = Yl(OO);
            return {
              element: bK,
              magnet: bK
            }
          })(XO) : {
            element: null,
            magnet: null
          });
          OO && XO && gp(XO, XO, KO)
        }
        setInteractive(OO) {
          let {
            element: KO,
            magnet: pO
          } = OO;
          this.interactive = KO, this.magnet = pO
        }
        clearHover() {
          this.hit && gp(this.hit, null, this.getPoint()), this.hit = null, this.setInteractive({
            element: null,
            magnet: null
          })
        }
        beginPress() {
          const OO = this.hit;
          if (!OO || rp(OO)) return {
            kind: "ignored"
          };
          const KO = (0, Ne.d)(OO),
            pO = OO.closest("[data-pad-slider]");
          return KO && pO ? {
            kind: "slider",
            slider: pO,
            adjuster: KO
          } : (NK(OO, this.getPoint()), {
            kind: "pointer",
            target: OO
          })
        }
        applySliderFraction(OO) {
          var KO;
          const pO = OO.slider.getBoundingClientRect(),
            XO = pO.height > pO.width,
            bK = null === (KO = OO.slider.querySelector("[data-pad-slider-handle]")) || void 0 === KO ? void 0 : KO.getBoundingClientRect(),
            eO = bK ? XO ? bK.height : bK.width : 0,
            lO = (XO ? pO.height : pO.width) - eO;
          if (lO <= 0) return;
          const vK = XO ? pO.bottom - eO / 2 - this.state.y : this.state.x - pO.left - eO / 2;
          OO.adjuster.setFraction(Math.max(0, Math.min(1, vK / lO)))
        }
        updateConfirm(OO, KO) {
          OO.wasPressed(KO) && (this.press = OO.wokeDevice ? {
            kind: "ignored"
          } : this.beginPress(), this.draggedSlider = "slider" === this.press.kind ? this.press.slider : null, this.beginRepeat());
          const pO = this.press;
          if (!pO) return;
          if (OO.isHeld(KO)) return "slider" === pO.kind && this.applySliderFraction(pO), void this.updateRepeat();
          this.press = null;
          const XO = this.repeated;
          if (this.endRepeat(), !OO.wasReleased(KO)) return void this.endPressWithoutClick(pO);
          const bK = this.getPoint(),
            eO = this.hit;
          if ("slider" === pO.kind && pO.adjuster.endDrag(), "pointer" === pO.kind) {
            const OO = null !== eO && void 0 !== eO ? eO : pO.target.isConnected ? pO.target : null;
            OO && IK(OO, bK);
            const KO = eO && pO.target.isConnected && !XO ? ((OO, KO) => {
              for (let pO = OO; pO; pO = pO.parentElement)
                if (pO.contains(KO)) return pO;
              return null
            })(pO.target, eO) : null;
            KO && (ql.noteCursorActivation(KO), (0, QO.f)(KO, new MouseEvent("click", dK(bK, 0, 0))), ip(KO), AK(KO) && uK(KO))
          }
        }
        beginRepeat() {
          var OO, KO, pO;
          const XO = null !== (OO = null === (KO = this.hit) || void 0 === KO ? void 0 : KO.closest("[data-pad-repeat]")) && void 0 !== OO ? OO : null;
          this.repeatStop = XO, this.repeatKey = null !== (pO = null === XO || void 0 === XO ? void 0 : XO.getAttribute("data-pad-repeat")) && void 0 !== pO ? pO : null, this.repeated = !1, this.confirmRepeat.reset(), this.confirmRepeat.update(!0, performance.now())
        }
        updateRepeat() {
          const OO = this.repeatStop;
          if (!OO) return;
          const KO = this.hit;
          OO.isConnected && !DK(OO) && OO.getAttribute("data-pad-repeat") === this.repeatKey && KO && OO.contains(KO) ? OO.hasAttribute("data-pad-repeat-wait") || this.confirmRepeat.update(!0, performance.now()) && (this.repeated = !0, ql.noteCursorActivation(OO), (0, QO.f)(OO, new MouseEvent("click", dK(this.getPoint(), 0, 0)))) : this.repeatStop = null
        }
        endRepeat() {
          this.repeatStop = null, this.repeated = !1
        }
        endPressWithoutClick(OO) {
          "slider" === OO.kind && OO.adjuster.endDrag(), "pointer" === OO.kind && OO.target.isConnected && IK(OO.target, this.getPoint())
        }
        cancelPress() {
          this.endRepeat(), this.press && (this.endPressWithoutClick(this.press), this.press = null)
        }
        updateSecondary(OO, KO) {
          OO.wasPressed(KO) && (this.secondaryArmed = null !== this.hit), this.secondaryArmed && !OO.isHeld(KO) && (this.secondaryArmed = !1, OO.wasReleased(KO) && this.hit && yp(this.hit, this.getPoint(), 2))
        }
        updateScroll(OO, KO) {
          const pO = IO(OO.rightStick, OO.dtMs);
          if (0 === pO.x && 0 === pO.y) return void(this.scrollRemainder = {
            x: 0,
            y: 0
          });
          this.scrollRemainder = {
            x: this.scrollRemainder.x + pO.x,
            y: this.scrollRemainder.y + pO.y
          };
          const XO = Math.trunc(this.scrollRemainder.x),
            bK = Math.trunc(this.scrollRemainder.y);
          this.scrollRemainder = {
            x: this.scrollRemainder.x - XO,
            y: this.scrollRemainder.y - bK
          };
          const eO = this.hit;
          if (!eO) return;
          let lO = !1;
          if (0 !== bK) {
            const OO = wl(eO, "y", bK > 0 ? 1 : -1, KO);
            OO && (OO.scrollBy({
              top: bK,
              behavior: "instant"
            }), lO = !0)
          }
          if (0 !== XO) {
            const OO = wl(eO, "x", XO > 0 ? 1 : -1, KO);
            OO && (OO.scrollBy({
              left: XO,
              behavior: "instant"
            }), lO = !0)
          }
          lO && (this.lastHitTestMs = -1 / 0)
        }
        pl() {
          SK.set({
            x: this.state.x,
            y: this.state.y,
            visible: this.isVisible(),
            pressed: null !== this.press && "ignored" !== this.press.kind
          })
        }
      },
      rv = () => {
        const OO = (0, mK.useMemo)((() => new cK), []),
          KO = (0, oO.C)();
        return (0, mK.useEffect)((() => {
          if (!KO) return;
          let pO = 0,
            XO = {
              of: null,
              atMs: 0,
              list: []
            };
          const bK = document.getElementsByClassName(Te),
            eO = OO => {
              for (const KO of [...bK]) KO !== OO && KO.classList.remove(Te)
            },
            lO = () => {
              var KO;
              pO = requestAnimationFrame(lO);
              const bK = (() => {
                const OO = ql.getFocused();
                if (ql.isActive() && null !== OO && void 0 !== OO && OO.isConnected) return OO;
                const KO = iv.getHighlighted();
                return null !== KO && void 0 !== KO && KO.isConnected ? KO : null
              })();
              eO(bK), bK && !bK.classList.contains(Te) && bK.classList.add(Te);
              const vK = null !== (KO = null === bK || void 0 === bK ? void 0 : bK.closest("[data-pad-reticle-box]")) && void 0 !== KO ? KO : bK;
              OO.show(vK ? ((OO, KO) => {
                let pO = OO.left,
                  XO = OO.top,
                  bK = OO.right,
                  eO = OO.bottom;
                for (const lO of KO) {
                  if (!lO) continue;
                  const OO = rK(lO);
                  pO = Math.max(pO, OO.left), XO = Math.max(XO, OO.top), bK = Math.min(bK, OO.right), eO = Math.min(eO, OO.bottom)
                }
                return bK <= pO || eO <= XO ? null : {
                  left: pO,
                  top: XO,
                  width: bK - pO,
                  height: eO - XO
                }
              })(vK.getBoundingClientRect(), (OO => {
                const KO = performance.now();
                return (XO.of !== OO || KO - XO.atMs > 500) && (XO = {
                  of: OO,
                  atMs: KO,
                  list: [uO(OO, "y"), uO(OO, "x")]
                }), XO.list
              })(vK)) : null)
            };
          return pO = requestAnimationFrame(lO), () => {
            cancelAnimationFrame(pO), eO(null), OO.hide()
          }
        }), [KO, OO]), (0, RO.jsx)(BO, {
          placer: OO,
          className: "PadFocusRing"
        })
      },
      Pl = (OO, KO) => {
        OO.style.transform = `translate3d(${KO.x}px, ${KO.y}px, 0)`, OO.classList.toggle("Visible", KO.visible), OO.classList.toggle("Pressed", KO.pressed)
      },
      mv = () => {
        const OO = (0, mK.useRef)(null);
        return (0, mK.useEffect)((() => {
          const KO = SK.subscribe((KO => {
            OO.current && Pl(OO.current, KO)
          }));
          return OO.current && Pl(OO.current, SK.get()), KO
        }), []), (0, RO.jsx)("div", {
          ref: OO,
          className: "PadCursorView",
          "aria-hidden": "true",
          children: (0, RO.jsx)("div", {
            className: "PadCursorGlyph",
            children: "+"
          })
        })
      },
      sl = "#ncmp__modal.ncmp__active",
      Hl = [{
        id: "nitro-consent-banner",
        find: () => document.querySelector(sl) ? null : document.querySelector("#ncmp__tool > .ncmp__banner.ncmp__active"),
        startSelectors: ["[data-ncmp-cmd='reject']", "[data-ncmp-cmd='showModal']"]
      }, {
        id: "nitro-consent-modal",
        find: () => document.querySelector(sl),
        startSelectors: ["[data-ncmp-cmd='reject']"]
      }, {
        id: "google-consent",
        find: () => document.querySelector(".fc-consent-root"),
        startSelectors: [".fc-cta-do-not-consent", ".fc-cta-manage-options"]
      }],
      Rl = "PadOverThirdParty",
      Sl = new Set(Hl.map((OO => OO.id))),
      Jl = () => {
        const OO = Hl.map((OO => {
            let {
              id: KO,
              find: pO,
              startSelectors: XO
            } = OO;
            return (0, Wb.m)({
              id: KO,
              kind: "popup",
              getRoot: () => {
                const OO = pO(),
                  KO = OO ? ((OO, KO) => {
                    var pO;
                    for (const XO of KO) {
                      const KO = OO.querySelector(XO);
                      if (KO) return KO
                    }
                    return null !== (pO = [...OO.querySelectorAll("button")].find((OO => !OO.matches(".fc-cta-consent, [data-ncmp-cmd='save']")))) && void 0 !== pO ? pO : null
                  })(OO, XO) : null;
                if (OO && KO && !KO.hasAttribute("data-pad-default-focus")) {
                  for (const KO of OO.querySelectorAll("[data-pad-default-focus]")) KO.removeAttribute("data-pad-default-focus");
                  for (const KO of OO.querySelectorAll("[data-pad-hint-bar-avoid]")) KO.removeAttribute("data-pad-hint-bar-avoid");
                  KO.setAttribute("data-pad-default-focus", ""), ((OO, KO) => {
                    let pO = OO;
                    for (let XO = OO.parentElement; XO && KO.contains(XO) && !(XO.getBoundingClientRect().height >= window.innerHeight / 2); XO = XO.parentElement) pO = XO;
                    return pO
                  })(KO, OO).setAttribute("data-pad-hint-bar-avoid", "")
                }
                return OO
              },
              close: null,
              memoryKey: null
            })
          })),
          KO = document.documentElement,
          pO = lO.g.onFrame((() => {
            const OO = (0, oO.o)() ? bl() : null,
              pO = !!OO && (XO = OO.layer, Sl.has(XO.id));
            var XO;
            KO.classList.contains(Rl) !== pO && KO.classList.toggle(Rl, pO)
          }));
        return () => {
          for (const KO of OO) KO();
          pO(), KO.classList.remove(Rl)
        }
      },
      cv = "PadLargePointer",
      Bl = () => {
        (0, mK.useEffect)((() => {
          const OO = (0, QO.l)(document.body),
            KO = ql.install(),
            pO = iv.install(),
            XO = Jl();
          return () => {
            OO(), KO(), pO(), XO()
          }
        }), []);
        const {
          largePointer: OO
        } = (0, aK.p)(), KO = (0, Ql.p)() && OO;
        return (0, mK.useEffect)((() => {
          if (KO) return document.documentElement.classList.add(cv), () => {
            document.documentElement.classList.remove(cv)
          }
        }), [KO]), (0, vK.createPortal)((0, RO.jsxs)(RO.Fragment, {
          children: [(0, RO.jsx)(ul, {}), (0, RO.jsx)(rv, {}), (0, RO.jsx)(mv, {})]
        }), document.body)
      };
    var Zl = pO(7872),
      Gl = pO(7893),
      qv = pO(7880);
    pO(7896);
    const xv = (OO, KO) => {
        const [pO, XO] = (0, mK.useState)(!1), [bK, eO] = (0, mK.useState)(null), lO = (0, mK.useRef)(null), vK = (0, mK.useCallback)((OO => {
          lO.current = OO, eO(OO)
        }), []), CO = (0, mK.useCallback)((() => {
          XO(!1), vK(null)
        }), [vK]), DO = (0, mK.useCallback)((() => {
          XO(!0)
        }), []), MO = (0, mK.useCallback)(((OO, KO) => {
          vK((0, qv.H)(OO, KO, lO.current))
        }), [vK]);
        (0, mK.useLayoutEffect)((() => (KO(pO), (0, zv.r)(OO, pO), hO.i.pl(zv.i), () => {
          KO(!1), (0, zv.r)(OO, !1), hO.i.pl(zv.i)
        })), [pO, OO, KO]), (0, vb.f)("appManagerUpdated|activeInputDevice", (OO => {
          "gamepad" !== OO && CO()
        })), (0, vb.f)("appManagerUpdated|gameState", (OO => {
          "inGame" !== OO && CO()
        }));
        const aK = () => {
          (0, be.i)() && CO()
        };
        return (0, vb.f)("appManagerUpdated|openEverythingMenuName", aK), (0, vb.f)("appManagerUpdated|openInGameMenuName", aK), {
          open: pO,
          picked: bK,
          pickedRef: lO,
          show: DO,
          aim: MO,
          close: CO
        }
      },
      nl = OO => {
        let {
          className: KO,
          slotCount: pO,
          picked: XO,
          slotLabel: bK,
          renderSlot: eO,
          centre: lO
        } = OO;
        const vK = Array.from({
          length: pO
        }, ((OO, KO) => KO));
        return (0, RO.jsx)("div", {
          className: HO()("EmoteWheelOverlay PadRadialWheel", KO),
          children: (0, RO.jsxs)("div", {
            className: "EmoteWheel",
            style: {
              width: 2 * qv.u + "rem",
              height: 2 * qv.u + "rem"
            },
            children: [(0, RO.jsxs)("svg", {
              className: "EmoteWheelSvg",
              viewBox: `0 0 ${qv.r} ${qv.r}`,
              children: [vK.map((OO => (0, RO.jsx)("path", {
                d: (0, qv.v)(OO, pO, qv.g, qv.k, qv.n),
                className: HO()("EmoteWheelWedge", {
                  EmoteWheelWedgeHighlighted: OO === XO
                }),
                "aria-label": bK(OO)
              }, OO))), (0, RO.jsx)("circle", {
                className: "EmoteWheelOuterRing",
                cx: qv.g,
                cy: qv.g,
                r: qv.n
              }), (0, RO.jsx)("circle", {
                className: "EmoteWheelInnerRing",
                cx: qv.g,
                cy: qv.g,
                r: qv.k
              }), null !== XO && (0, RO.jsx)("path", {
                className: "EmoteWheelWedgeOutline",
                d: (0, qv.v)(XO, pO, qv.g, qv.k, qv.n)
              })]
            }), vK.map((OO => {
              const KO = (0, qv.z)(OO, pO);
              return (0, RO.jsx)("div", {
                className: HO()("PadRadialWheelSlot SmallTextBold", {
                  PadRadialWheelSlotPicked: OO === XO
                }),
                style: {
                  left: `calc(50% + ${qv.d*Math.cos(KO)}rem)`,
                  top: `calc(50% + ${qv.d*Math.sin(KO)}rem)`
                },
                "aria-hidden": !0,
                children: eO(OO)
              }, OO)
            })), (0, RO.jsx)("div", {
              className: "EmoteWheelHint SmallTextBold",
              children: lO
            })]
          })
        })
      },
      Wl = xl.length,
      tv = () => {
        const {
          t: OO
        } = (0, bK.D)(), KO = xv("chat", Ib.p), pO = (0, mK.useMemo)((() => xl.map((KO => OO(KO)))), [OO]);
        return (0, vb.f)(Ib.o, (() => {
          KO.open || (0, Zl.g)() || (0, Gl.o)() || "inGame" !== CO.d.get("gameState") || (0, be.i)() || !(0, Ob.d)() || KO.show()
        })), (0, vb.f)(Ib.e, (OO => {
          KO.open && KO.aim(OO, Wl)
        })), (0, vb.f)(Ib.m, (() => {
          var OO;
          if (!KO.open) return;
          const XO = KO.pickedRef.current;
          null !== XO ? ne.claim(performance.now()) && (KO.close(), null === (OO = (0, Ob.d)()) || void 0 === OO || OO.sendLine(pO[XO])) : KO.close()
        })), (0, vb.f)(Ib.i, KO.close), KO.open ? (0, RO.jsx)(nl, {
          className: "QuickChatWheel",
          slotCount: Wl,
          picked: KO.picked,
          slotLabel: OO => pO[OO],
          renderSlot: OO => pO[OO],
          centre: null !== KO.picked ? pO[KO.picked] : OO("controller:quickChatPick")
        }) : null
      },
      kv = () => {
        const {
          t: OO
        } = (0, bK.D)(), KO = xv("actionButton", Gl.p), [pO, XO] = (0, mK.useState)([]);
        if ((0, vb.f)(Gl.k, (OO => {
            KO.open || (0, Zl.g)() || (0, Ib.b)() || "inGame" !== CO.d.get("gameState") || (0, be.i)() || (XO(OO), KO.show())
          })), (0, vb.f)(Gl.d, (OO => {
            KO.open && KO.aim(OO, pO.length)
          })), (0, vb.f)(Gl.j, (() => {
            if (!KO.open) return;
            const OO = KO.pickedRef.current;
            KO.close(), null !== OO && hO.i.pl(Gl.l, pO[OO])
          })), (0, vb.f)(Gl.h, KO.close), !KO.open) return null;
        const eO = null !== KO.picked ? pO[KO.picked] : null;
        return (0, RO.jsx)(nl, {
          className: "ActionWheel",
          slotCount: pO.length,
          picked: KO.picked,
          slotLabel: KO => {
            const XO = pO[KO];
            return "reload" === XO.kind ? OO("controller:gameplayReload") : "customButton" === XO.kind ? XO.description || XO.icon : "touchButton" === XO.kind && "string" === typeof XO.label ? XO.label : ""
          },
          renderSlot: OO => (0, RO.jsx)(VX, {
            action: pO[OO]
          }),
          centre: eO ? (0, RO.jsx)(VX, {
            action: eO
          }) : OO("controller:actionWheelPick")
        })
      };
    var Ul = pO(94);
    const Ov = () => ((0, mK.useEffect)((() => {
        var OO, KO;
        const pO = (0, QO.l)(document.getElementById("root")),
          XO = (0, oO.h)(),
          bK = (() => {
            const OO = [hO.i.subscribe(Gp.d, (() => {
                Wp("blockBreak")
              })), hO.i.subscribe("damagedByOtherPlayer", (() => {
                Wp("damage")
              })), hO.i.subscribe("yourAttackHit", (OO => {
                let {
                  hitSelf: KO
                } = OO;
                KO || Wp("hit")
              }))],
              KO = lO.g.onActivePadChanged((OO => {
                OO && Wp("connect")
              }));
            return () => {
              for (const KO of OO) hO.i.unsubscribe(KO);
              KO()
            }
          })(),
          eO = (() => {
            const OO = new pX({
              getVisitId: KX.b,
              peekVisitId: KX.peekVisitSessionId,
              readReportedVisitId: () => {
                const OO = OX.h.getItem(XX);
                return "string" === typeof OO ? OO : null
              },
              writeReportedVisitId: OO => {
                OX.h.setItem(XX, OO)
              },
              isPadActive: oO.o,
              getPadFamily: () => {
                var OO, KO;
                return null !== (OO = null === (KO = lO.g.getActivePad()) || void 0 === KO ? void 0 : KO.family) && void 0 !== OO ? OO : null
              },
              canReport: kX.j,
              getInputType: Up.c,
              CX: kX.o
            });
            let KO = 0,
              pO = null;
            const XO = bK => {
                null === pO && ("notReady" !== OO.check(bK) || null !== pO || KO >= 20 || (KO++, pO = setTimeout((() => {
                  pO = null, XO(!1)
                }), 3e3)))
              },
              bK = hO.i.subscribe("appManagerUpdated|activeInputDevice", (() => {
                XO(!0)
              })),
              eO = (0, KX.f)((() => {
                KO = 0, XO(!0)
              }));
            return () => {
              hO.i.unsubscribe(bK), eO(), null !== pO && clearTimeout(pO)
            }
          })(),
          vK = lO.g.onFrame(((OO, KO) => {
            const pO = (0, oO.s)(OO);
            MO.c.dispatch(OO, KO, pO)
          }));
        let DO = null !== (OO = null === (KO = lO.g.getActivePad()) || void 0 === KO ? void 0 : KO.family) && void 0 !== OO ? OO : null;
        const FO = lO.g.onActivePadChanged((OO => {
            var KO, pO;
            (MO.c.reset(), (0, oO.z)(), hO.i.pl(lO.c, OO), (null !== (KO = null === OO || void 0 === OO ? void 0 : OO.family) && void 0 !== KO ? KO : null) !== DO) && (DO = null !== (pO = null === OO || void 0 === OO ? void 0 : OO.family) && void 0 !== pO ? pO : null, hO.i.pl(aK.c, (0, aK.i)()));
            !OO && (0, oO.o)() && (0, oO.B)(CO.d.get("isTouchScreen") ? "touch" : "keyboardMouse")
          })),
          VO = () => {
            "visible" !== document.visibilityState && MO.c.clear()
          },
          LO = () => {
            MO.c.clear()
          };
        document.addEventListener("visibilitychange", VO), window.addEventListener("blur", LO), lO.g.start(), (0, tX.h)();
        const zK = null;
        return () => {
          pO(), XO(), bK(), eO(), vK(), FO(), document.removeEventListener("visibilitychange", VO), window.removeEventListener("blur", LO), lO.g.stop(), null === zK || void 0 === zK || zK()
        }
      }), []), (0, RO.jsxs)("div", {
        className: "ControllerRoot",
        children: [(0, RO.jsx)(TX, {}), (0, RO.jsx)(wX, {}), (0, RO.jsx)(ib, {}), (0, RO.jsx)(Vl, {}), (0, RO.jsx)(Bl, {}), (0, RO.jsx)(tv, {}), (0, RO.jsx)(kv, {})]
      })),
      Kv = () => Ul.featureFlags.useControllerSupport ? (0, RO.jsx)(Ov, {}) : null;
    var pv = pO(7281),
      Xv = pO(7907);
    const bC = new Set(tX.g),
      ev = OO => `${Xv.l}${(0,aK.l)()}/${OO}`,
      lv = OO => {
        if (!(0, Xv.k)(OO)) return null;
        const [KO, pO] = OO.slice(Xv.l.length).split("/");
        return (0, pv.g)(KO) && bC.has(pO) ? (0, tX.d)(KO, pO) : null
      };
    var vC = pO(7913);
    const Cv = () => {
        const {
          t: OO
        } = (0, bK.D)(), KO = (0, oO.C)(), {
          gameState: pO,
          isUiHidden: XO
        } = (0, CO.l)(["gameState", "isUiHidden"]), {
          hideButtonHints: eO,
          sneakMode: lO
        } = (0, aK.p)(), [vK, hO] = (0, mK.useState)(vC.e);
        return (0, vb.f)(dX.s, hO), KO && !XO && "inGame" === pO && vK ? (0, RO.jsxs)("div", {
          className: "PadSneakChip SmallTextBold",
          children: [!eO && (0, RO.jsx)(oX, {
            glyph: (0, DO.j)("toggle" === lO ? "sneak" : "sneakToggle")
          }), (0, RO.jsx)("span", {
            children: OO("controller:gameplaySneaking")
          })]
        }) : null
      },
      hv = 12,
      Dv = OO => {
        let {
          trigger: KO,
          className: pO,
          children: XO
        } = OO;
        const bK = (0, mK.useRef)(null);
        return (0, mK.useEffect)((() => {
          let OO = 0;
          const pO = uO(KO, "y"),
            XO = () => {
              OO = requestAnimationFrame(XO);
              const eO = bK.current;
              if (!eO || null === KO || void 0 === KO || !KO.isConnected) return;
              const {
                left: lO,
                top: vK
              } = function(OO, KO, pO) {
                let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
                  bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
                const eO = OO.left + OO.width / 2,
                  lO = Math.max(hv, pO.width - hv - KO.width),
                  vK = Math.min(Math.max(eO - KO.width / 2, hv), lO),
                  CO = pO.height - XO;
                let hO = 0,
                  DO = CO;
                if (bK) {
                  const OO = Math.max(0, bK.top),
                    XO = Math.min(CO, bK.bottom);
                  XO - OO >= Math.max(pO.height / 2, KO.height + 24) && (hO = OO, DO = XO)
                }
                const MO = OO.top + OO.height / 2 < (hO + DO) / 2 ? DO - hv - KO.height : hO + hv;
                return {
                  left: vK,
                  top: Math.max(hv, MO)
                }
              }(KO.getBoundingClientRect(), {
                width: eO.offsetWidth,
                height: eO.offsetHeight
              }, {
                width: window.innerWidth,
                height: window.innerHeight
              }, parseFloat(document.documentElement.style.getPropertyValue(Tl)) || 0, null !== pO && void 0 !== pO && pO.isConnected ? pO.getBoundingClientRect() : null);
              eO.style.transform = `translate3d(${Math.round(lO)}px, ${Math.round(vK)}px, 0)`, eO.style.visibility = "visible"
            };
          return XO(), () => {
            cancelAnimationFrame(OO)
          }
        }), [KO]), (0, RO.jsx)("div", {
          ref: bK,
          className: pO,
          style: {
            position: "fixed",
            left: 0,
            top: 0,
            visibility: "hidden"
          },
          children: XO
        })
      };
    var Mv = pO(933),
      aC = pO(7917),
      ov = pO(1271),
      Fv = pO(7922),
      Vv = pO(7927);
    const Lv = {
        shop: {
          icon: "cart-shopping",
          labelKey: "controller:menusShop"
        },
        tasks: {
          icon: "bars",
          labelKey: "controller:menusTasks"
        },
        invite: {
          icon: "user-plus",
          labelKey: "controller:menusInvite"
        },
        DX: {
          icon: "arrow-left",
          labelKey: "settingsMenu:exitGame"
        }
      },
      Qv = () => {
        const {
          t: OO
        } = (0, bK.D)(), KO = (0, oO.C)(), pO = (0, aC.c)(), XO = (0, EX.i)("_tasks"), eO = (0, EX.i)("_availableLeaderboards");
        if (!KO) return null;
        const lO = (OO => {
          let {
            hasShop: KO,
            hasTasksOrLeaderboards: pO,
            canInvite: XO
          } = OO;
          const bK = [];
          return KO && bK.push("shop"), pO && bK.push("tasks"), XO && bK.push("invite"), bK.push("DX"), bK
        })({
          hasShop: pO,
          hasTasksOrLeaderboards: !(!XO && !eO),
          canInvite: !!Ul.featureFlags.canUseInviteLinks
        });
        return (0, RO.jsx)("div", {
          className: "PadLobbyShortcuts",
          children: lO.map((KO => {
            const {
              icon: pO,
              labelKey: XO
            } = Lv[KO], bK = "DX" === KO ? ov.I : ov.d;
            return (0, RO.jsx)(bK, {
              className: "PadLobbyShortcut",
              onClick: () => {
                (OO => {
                  switch (OO) {
                    case "shop":
                      return hO.i.pl(Vv.f), void CO.d.set({
                        openEverythingMenuName: Xb.o.SHOP
                      });
                    case "tasks":
                      return void hO.i.pl("toggleMenu", "retentionFeatures");
                    case "invite":
                      return void hO.i.pl("toggleMenu", "inviteLink");
                    case "DX":
                      (0, Fv.b)()
                  }
                })(KO)
              },
              children: (0, RO.jsxs)("div", {
                className: "PadLobbyShortcutInner",
                children: [(0, RO.jsx)(Mv.d, {
                  name: pO
                }), (0, RO.jsx)("span", {
                  children: OO(XO)
                })]
              })
            }, KO)
          }))
        })
      };
    var zC = pO(1591);
    const Av = FO.x,
      fv = ["forward", "backward", "left", "right", "sprint"],
      dv = OO => OO.ctrlKey || OO.altKey || "Alt" === OO.key || "ArrowUp" === OO.key || "ArrowDown" === OO.key || "Tab" === OO.code || "/" === OO.key || "Slash" === OO.code;
    class Tv {
      constructor() {
        this.armed = !1, this.swallowedKeys = new Set, this.previousHeld = new Array(FO.Y).fill(!1), this.leftStickWasPressed = !1, this.rightStickWasPressed = !1, this.consumeNextFrame = !1, this.consumeAfterContinue = !1
      }
      setArmed(OO) {
        this.armed = OO
      }
      blocksGameplay() {
        return this.armed || this.consumeNextFrame
      }
      onKeyDown(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        return !this.armed || KO ? !OO.repeat && this.swallowedKeys.delete(OO.code) ? {
          swallow: !1,
          continues: !1
        } : {
          swallow: this.swallowedKeys.has(OO.code),
          continues: !1
        } : "Escape" === OO.key || OO.repeat && !this.swallowedKeys.has(OO.code) ? {
          swallow: !1,
          continues: !1
        } : pO ? {
          swallow: !1,
          continues: !0
        } : (this.swallowedKeys.add(OO.code), {
          swallow: !0,
          continues: (0, oO.k)(OO)
        })
      }
      onKeyUp(OO) {
        return this.swallowedKeys.delete(OO.code)
      }
      forgetKeys() {
        this.swallowedKeys.clear()
      }
      onPadFrame(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
          XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        const bK = (0, FO.p)(OO.values, this.previousHeld),
          eO = null === pO ? -1 : (0, FO.k)(pO),
          lO = eO >= 0 && bK[eO] && !this.previousHeld[eO],
          vK = bK.some(((OO, KO) => OO && !this.previousHeld[KO] && KO !== eO)),
          CO = Math.hypot(OO.leftStick.x, OO.leftStick.y) >= Av,
          hO = Math.hypot(OO.rightStick.x, OO.rightStick.y) >= Av,
          DO = CO && !this.leftStickWasPressed || hO && !this.rightStickWasPressed;
        this.previousHeld = bK, this.leftStickWasPressed = CO, this.rightStickWasPressed = hO;
        let MO = !1;
        this.consumeNextFrame && (this.consumeNextFrame = !1, MO = !0);
        const aK = !KO && lO && !XO,
          oO = !aK && this.armed && !KO && (vK || DO);
        return (aK || oO) && (this.consumeNextFrame = !0, this.consumeAfterContinue = oO, MO = !0), {
          continues: oO,
          back: aK,
          consumeHeld: MO
        }
      }
      consumeLeavesMoveStick() {
        return this.consumeAfterContinue
      }
    }
    const Nv = new Set([...zC.h, ...zC.x]),
      Iv = OO => ((OO, KO, pO) => {
        const XO = Object.keys(KO).filter((XO => !pO.has(XO) && KO[XO].includes(OO)));
        return XO.length > 0 && XO.every((OO => fv.includes(OO)))
      })(OO, zC.s, Nv),
      yC = (OO, KO, pO) => {
        const XO = new Tv,
          bK = OO => {
            if (!OO.isTrusted) return;
            const {
              swallow: pO,
              continues: bK
            } = XO.onKeyDown(OO, !(0, oO.H)(OO) || (0, Zp.j)() || (0, be.i)(), Iv(OO.code));
            pO && (OO.stopImmediatePropagation(), dv(OO) && OO.preventDefault()), bK && ((0, oO.B)("keyboardMouse"), KO())
          },
          eO = OO => {
            OO.isTrusted && XO.onKeyUp(OO) && (OO.stopImmediatePropagation(), dv(OO) && OO.preventDefault())
          },
          vK = () => {
            XO.forgetKeys()
          };
        window.addEventListener("keydown", bK, !0), window.addEventListener("keyup", eO, !0), window.addEventListener("blur", vK);
        const CO = lO.g.onFrame((OO => {
            const bK = MO.c.getActiveConsumerName(),
              eO = pO(),
              lO = eO ? (0, DO.j)("menuBack") : null,
              vK = null !== bK && "gameplay" !== bK,
              {
                continues: CO,
                back: hO,
                consumeHeld: FO
              } = XO.onPadFrame(OO, vK, lO, (0, oO.r)(OO));
            if (FO) {
              const OO = (0, aK.i)().swapSticks ? "right" : "left";
              MO.c.consumeAllHeld(XO.consumeLeavesMoveStick() ? OO : null)
            }
            hO ? null === eO || void 0 === eO || eO() : CO && KO()
          })),
          hO = (0, Zp.k)(`pressToContinue:${OO}`, (() => XO.blocksGameplay()));
        return {
          setArmed: OO => {
            XO.setArmed(OO)
          },
          dispose: () => {
            window.removeEventListener("keydown", bK, !0), window.removeEventListener("keyup", eO, !0), window.removeEventListener("blur", vK), CO(), hO()
          }
        }
      };
    var gC = pO(4120),
      uv = pO(2696),
      Ev = pO(2430),
      jC = pO(7284);
    const Yv = OO => {
        let {
          text: KO
        } = OO;
        return (0, RO.jsx)("div", {
          className: "ControllerSettingsHeading",
          children: KO
        })
      },
      wv = OO => {
        let {
          label: KO,
          hint: pO,
          options: XO,
          value: eO,
          onChange: lO
        } = OO;
        const {
          t: vK
        } = (0, bK.D)();
        return (0, RO.jsx)("div", {
          className: "SettingBox ControllerChoiceSetting",
          children: (0, RO.jsxs)("div", {
            className: "ControllerChoiceRow",
            children: [(0, RO.jsxs)("div", {
              className: "ControllerChoiceText",
              children: [(0, RO.jsx)("div", {
                className: "SliderText",
                children: KO
              }), pO && (0, RO.jsx)("div", {
                className: "ControllerSettingsHint",
                children: pO
              })]
            }), (0, RO.jsx)(Ev.b, {
              options: XO.map((OO => ({
                label: "label" in OO ? OO.label : vK(OO.labelKey),
                value: OO.value
              }))),
              value: eO,
              onChange: OO => {
                lO(OO.value)
              }
            })]
          })
        })
      },
      iC = OO => {
        let {
          settingKey: KO,
          label: pO,
          range: XO,
          format: bK
        } = OO;
        const eO = (0, aK.p)();
        return (0, RO.jsx)(gC.h, {
          name: pO,
          min: XO.min,
          max: XO.max,
          step: XO.step,
          padStep: XO.step,
          initValue: eO[KO],
          format: bK,
          onChange: OO => {
            (0, aK.n)({
              [KO]: (0, jC.t)(OO, XO)
            })
          }
        })
      };
    var rC = pO(7935),
      Pv = pO(7937);
    const mC = OO => OO instanceof DOMException && ("SecurityError" === OO.name || "NotAllowedError" === OO.name),
      sv = OO => {
        const [KO] = [...OO.controllers].sort(((OO, KO) => Pv.o[OO] - Pv.o[KO]));
        return Pv.k[KO]
      },
      Hv = OO => {
        (0, rC.e)().allowPhoneMotion().catch((KO => {
          OO && mC(KO) ? OO() : console.warn("Could not enable the motion sensor", KO)
        }))
      },
      Rv = {
        waiting: "controller:settingsGyroPhoneWaiting",
        noSensor: "controller:settingsGyroPhoneNoSensor",
        on: "controller:settingsGyroPhoneOn",
        denied: "controller:settingsGyroPhoneDenied"
      },
      Sv = OO => {
        let {
          status: KO
        } = OO;
        const {
          t: pO
        } = (0, bK.D)(), [XO, eO] = (0, mK.useState)(null), lO = `${KO.controllers.join(",")}|${KO.phoneMotion}`;
        (0, mK.useEffect)((() => {
          eO(null)
        }), [lO]);
        const vK = () => {
          (0, rC.e)().connectController().then((OO => {
            eO(OO > 0 ? "openFailed" : null)
          })).catch((OO => {
            mC(OO) ? eO("needsClick") : console.warn("Could not connect motion controller", OO)
          }))
        };
        if (KO.hidSupported) {
          let OO = pO("controller:settingsGyroConnectHint");
          return "needsClick" === XO ? OO = pO("controller:settingsGyroConnectNeedsClick") : "openFailed" === XO ? OO = pO("controller:settingsGyroOpenFailed") : KO.controllers.length > 0 && (OO = pO("controller:settingsGyroConnected", {
            name: sv(KO)
          })), (0, RO.jsx)("div", {
            className: "SettingBox ControllerChoiceSetting",
            children: (0, RO.jsxs)("div", {
              className: "ControllerChoiceRow",
              children: [(0, RO.jsx)("div", {
                className: "ControllerSettingsHint",
                children: OO
              }), (0, RO.jsx)(ov.d, {
                onClick: vK,
                children: pO("controller:settingsGyroConnect")
              })]
            })
          })
        }
        if ("needsPermission" === KO.phoneMotion) return (0, RO.jsx)("div", {
          className: "SettingBox ControllerChoiceSetting",
          children: (0, RO.jsxs)("div", {
            className: "ControllerChoiceRow",
            children: ["needsTap" === XO && (0, RO.jsx)("div", {
              className: "ControllerSettingsHint",
              children: pO("controller:settingsGyroAllowNeedsTap")
            }), (0, RO.jsx)(ov.d, {
              onClick: () => {
                Hv((() => {
                  eO("needsTap")
                }))
              },
              children: pO("controller:settingsGyroAllowMotion")
            })]
          })
        });
        const CO = Rv[KO.phoneMotion];
        return CO ? (0, RO.jsx)("div", {
          className: "ControllerSettingsHint",
          children: pO(CO)
        }) : null
      },
      Jv = () => {
        const {
          t: OO
        } = (0, bK.D)(), KO = (0, aK.p)(), pO = (0, rC.f)(), XO = (0, oO.E)(), eO = !pO.hidSupported && pO.phoneSupported && !pO.padConnected, lO = (pO.hidSupported || pO.phoneSupported) && !eO, vK = (0, DO.j)("pause");
        return (0, RO.jsxs)(RO.Fragment, {
          children: [(0, RO.jsx)(Yv, {
            text: OO("controller:settingsGyro")
          }), eO && (0, RO.jsx)("div", {
            className: "ControllerSettingsHint",
            children: OO("controller:settingsGyroPhoneNeedsController")
          }), !lO && !eO && (0, RO.jsx)("div", {
            className: "ControllerSettingsHint",
            children: OO(pO.hidBlocked || pO.phoneBlocked ? "controller:settingsGyroBlocked" : "controller:settingsGyroUnsupported")
          }), lO && (0, RO.jsx)(gC.b, {
            label: OO(pO.hidSupported ? "controller:settingsGyroToggle" : "controller:settingsGyroTogglePhone"),
            checked: KO.gyroAiming,
            onClick: OO => {
              var KO, pO;
              (0, aK.n)({
                gyroAiming: OO
              });
              const XO = null === (KO = null === (pO = navigator.userActivation) || void 0 === pO ? void 0 : pO.isActive) || void 0 === KO || KO;
              if (!OO || !XO) return;
              const bK = (0, rC.e)(),
                eO = bK.getStatus();
              eO.hidSupported ? bK.connectControllerIfNoneGranted().catch((OO => {
                console.warn("Motion controller picker unavailable", OO)
              })) : "needsPermission" === eO.phoneMotion && Hv()
            },
            circleInfoText: OO(pO.hidSupported ? "controller:settingsGyroToggleInfo" : "controller:settingsGyroToggleInfoPhone")
          }), lO && pO.hidSupported && (0, RO.jsx)("div", {
            className: "ControllerSettingsHint",
            children: OO("controller:settingsGyroSteamHint")
          }), lO && KO.gyroAiming && (0, RO.jsxs)(RO.Fragment, {
            children: [(0, RO.jsx)(Sv, {
              status: pO
            }), (0, RO.jsx)(iC, {
              settingKey: "gyroSensitivity",
              label: OO("controller:settingsGyroSensitivity"),
              range: jC.K,
              format: jC.G
            }), (0, RO.jsx)(wv, {
              label: OO("controller:settingsGyroActivation"),
              hint: "aiming" === KO.gyroActivation && (0, RO.jsx)(uv.b, {
                text: OO("controller:settingsGyroAimingHint", {
                  button: uv.c
                }),
                glyph: (0, DO.j)("use")
              }),
              options: jC.J,
              value: KO.gyroActivation,
              onChange: OO => {
                (0, aK.n)({
                  gyroActivation: OO
                })
              }
            }), "button" === KO.gyroActivation && (0, RO.jsx)(wv, {
              label: OO("controller:settingsGyroButton"),
              hint: OO("controller:settingsGyroButtonHint"),
              options: jC.o.filter((OO => OO !== vK || OO === KO.gyroButton)).map((OO => ({
                label: ab(XO, OO),
                value: OO
              }))),
              value: KO.gyroButton,
              onChange: OO => {
                (0, aK.n)({
                  gyroButton: OO
                })
              }
            })]
          })]
        })
      };
    var cC = pO(1693);
    const Bv = () => {
      const {
        t: OO
      } = (0, bK.D)(), KO = (0, aK.p)(), pO = (0, oO.E)();
      return (0, RO.jsxs)(RO.Fragment, {
        children: [(0, RO.jsx)(Yv, {
          text: OO("controller:settingsAccessibility")
        }), (0, RO.jsx)(gC.b, {
          label: OO("controller:settingsSwapConfirmBack"),
          checked: (0, DO.D)(KO.swapConfirmBack, pO),
          onClick: OO => {
            (0, aK.n)({
              swapConfirmBack: OO === (0, DO.D)(null, pO) ? null : OO
            }), cC.b.showMessage({
              translationKey: "controller:settingsSwapToast"
            })
          },
          circleInfoText: OO("controller:settingsSwapConfirmBackInfo")
        }), (0, RO.jsx)(wv, {
          label: OO("controller:settingsButtonRepeat"),
          hint: OO("controller:settingsButtonRepeatHint"),
          options: jC.m,
          value: KO.buttonRepeat,
          onChange: OO => {
            (0, aK.n)({
              buttonRepeat: OO
            })
          }
        }), (0, RO.jsx)(wv, {
          label: OO("controller:settingsTapHoldTime"),
          hint: OO("controller:settingsTapHoldTimeHint"),
          options: jC.ob,
          value: KO.tapHoldTime,
          onChange: OO => {
            (0, aK.n)({
              tapHoldTime: OO
            })
          }
        }), (0, RO.jsx)(wv, {
          label: OO("controller:settingsEmoteButton"),
          hint: OO("wheel" === KO.emoteButton ? "controller:settingsEmoteButtonWheelHint" : "controller:settingsEmoteButtonTapHoldHint"),
          options: jC.A,
          value: KO.emoteButton,
          onChange: OO => {
            (0, aK.n)({
              emoteButton: OO
            })
          }
        }), (0, RO.jsx)(wv, {
          label: OO("controller:settingsAttackMode"),
          hint: OO("toggle" === KO.attackMode ? "controller:settingsAttackToggleHint" : "controller:settingsAttackHoldHint"),
          options: jC.j,
          value: KO.attackMode,
          onChange: OO => {
            (0, aK.n)({
              attackMode: OO
            })
          }
        }), (0, RO.jsx)(gC.b, {
          label: OO("controller:settingsLargePointer"),
          checked: KO.largePointer,
          onClick: OO => {
            (0, aK.n)({
              largePointer: OO
            })
          },
          circleInfoText: OO("controller:settingsLargePointerInfo")
        })]
      })
    };
    var Zv = pO(7942);
    const Gv = new class {
        constructor(OO) {
          this.router = OO, this.current = null
        }
        claim(OO, KO) {
          const pO = this.current;
          pO && (this.current = null, pO.release(), pO.onTakenOver());
          const XO = this.router.register({
              ...OO,
              name: "capture"
            }),
            bK = {
              release: XO,
              onTakenOver: KO
            };
          return this.current = bK, () => {
            this.current === bK && (this.current = null), XO()
          }
        }
      }(MO.c),
      qC = OO => {
        (0, mK.useEffect)((() => {
          if (!OO) return;
          const KO = OO();
          let pO = !1;
          const XO = () => {
              pO || (pO = !0, KO.onEnd())
            },
            bK = Gv.claim({
              isActive: () => !pO,
              onFrame: OO => {
                KO.onFrame(OO, XO)
              }
            }, XO),
            eO = void 0 === KO.timeoutMs ? void 0 : window.setTimeout(XO, KO.timeoutMs),
            lO = OO => {
              "Escape" === OO.key && (OO.preventDefault(), OO.stopPropagation(), XO())
            };
          return window.addEventListener("keydown", lO, !0), () => {
            pO = !0, bK(), window.clearTimeout(eO), window.removeEventListener("keydown", lO, !0)
          }
        }), [OO])
      },
      xC = OO => {
        let {
          row: KO,
          capturing: pO,
          onCapture: XO,
          holdFillRef: eO,
          onRebind: lO,
          swapped: vK
        } = OO;
        const {
          t: CO
        } = (0, bK.D)();
        if ("fixed" === KO.kind) return (0, RO.jsx)("div", {
          className: "ControlRow PadControlRow PadControlRowFixed",
          children: (0, RO.jsxs)("div", {
            className: "ControlRowInner",
            children: [(0, RO.jsx)("div", {
              className: "ControlName",
              children: CO(KO.labelKey)
            }), (0, RO.jsx)("div", {
              className: "ControlBindingsContainer",
              children: (0, RO.jsx)("div", {
                className: "ControlBindingsList",
                children: (0, RO.jsx)("div", {
                  className: "ControlBinding PadBinding",
                  children: (0, RO.jsx)(oX, {
                    glyph: "move" === KO.stick ? (0, DO.s)() : (0, DO.o)()
                  })
                })
              })
            })]
          })
        });
        const {
          action: hO
        } = KO, MO = (0, DO.j)(hO), aK = (0, DO.m)(hO), oO = MO !== aK && (0, DO.d)(hO, aK);
        return (0, RO.jsxs)("div", {
          className: HO()("ControlRow PadControlRow", {
            Capturing: pO
          }),
          children: [(0, RO.jsxs)("div", {
            className: "ControlRowInner",
            children: [(0, RO.jsx)("div", {
              className: "ControlName",
              children: CO(jC.e[hO])
            }), (0, RO.jsxs)("div", {
              className: "ControlBindingsContainer",
              children: [!pO && (0, RO.jsxs)("div", {
                className: "ControlBindingsList",
                children: [(0, RO.jsx)("div", {
                  className: "ControlBinding PadBinding",
                  "data-pad-focusable": !0,
                  onClick: () => {
                    XO(hO)
                  },
                  children: (0, RO.jsx)(oX, {
                    glyph: MO
                  })
                }), oO && (0, RO.jsx)("div", {
                  className: "ControlBinding PadBindingReset",
                  title: CO("controller:settingsReset"),
                  "data-pad-focusable": !0,
                  onClick: () => {
                    lO(hO, aK)
                  },
                  children: (0, RO.jsx)(Mv.d, {
                    name: "arrows-rotate"
                  })
                })]
              }), pO && (0, RO.jsxs)("div", {
                className: "ControlBindingAddInput",
                children: [(0, RO.jsxs)("div", {
                  className: "PadCaptureBox",
                  children: [(0, RO.jsx)("span", {
                    children: CO("controller:settingsCapturePrompt")
                  }), (0, RO.jsx)("div", {
                    ref: eO,
                    className: "PadCaptureHoldFill"
                  })]
                }), (0, RO.jsx)("div", {
                  className: "ControlBindingAddCancel",
                  "data-pad-focusable": !0,
                  onClick: () => {
                    XO(null)
                  },
                  children: "\xd7"
                })]
              }), pO && (0, RO.jsx)("div", {
                className: "PadCaptureHint",
                children: (0, RO.jsx)(uv.b, {
                  text: CO((0, DO.d)(hO, (0, DO.j)("menuBack")) ? "controller:settingsCaptureCancelOrBindHint" : "controller:settingsCaptureCancelHint", {
                    button: uv.c
                  }),
                  glyph: (0, DO.j)("menuBack")
                })
              })]
            })]
          }), vK.map((OO => (0, RO.jsx)("div", {
            className: "ControlRowWarning PadSwapNotice",
            children: (0, RO.jsx)(uv.b, {
              text: CO("controller:settingsSwapNotice", {
                action: CO(jC.e[OO]),
                button: uv.c
              }),
              glyph: (0, DO.j)(OO)
            })
          }, OO))), pO && (0, RO.jsx)("div", {
            className: "PadCaptureTimer",
            style: {
              animationDuration: `${jC.r}ms`
            }
          })]
        })
      },
      nv = [],
      Wv = OO => {
        let {
          layoutSetting: KO
        } = OO;
        const {
          t: pO
        } = (0, bK.D)(), XO = (0, aK.p)();
        (0, oO.E)();
        const eO = (0, mK.useRef)(null),
          [lO, vK] = (0, mK.useState)(null),
          CO = (0, mK.useCallback)(((OO, KO) => {
            const pO = (0, aK.i)().MX;
            (0, DO.z)(OO, KO);
            const XO = (0, DO.u)(pO, OO);
            vK(XO.length > 0 ? {
              action: OO,
              swapped: XO
            } : null)
          }), []),
          [hO, VO] = ((OO, KO) => {
            const [pO, XO] = (0, mK.useState)(null), bK = (0, mK.useMemo)((() => pO ? () => {
              const bK = (0, DO.j)("menuBack"),
                eO = new jC.b(bK, (0, DO.j)("menuConfirm"), (OO => (0, DO.d)(pO, OO)));
              return {
                onFrame: (XO, lO) => {
                  var vK;
                  const CO = XO.frame.timestampMs,
                    hO = eO.update({
                      ...XO,
                      isDown: OO => (0, FO.J)(XO.frame.values, OO)
                    }, CO);
                  null === (vK = OO.current) || void 0 === vK || vK.style.setProperty("width", 100 * eO.getBindHoldProgress(CO) + "%"), hO && ("bind" === hO.kind ? (MO.c.consumeButton(hO.button), KO(pO, hO.button)) : MO.c.consumeButton(bK), lO())
                },
                onEnd: () => {
                  XO(null)
                },
                timeoutMs: jC.r
              }
            } : null), [pO, OO, KO]);
            return qC(bK), [pO, XO]
          })(eO, CO),
          LO = OO => {
            OO && vK(null), VO(OO)
          };
        (0, mK.useEffect)((() => {
          if (!lO) return;
          const OO = window.setTimeout((() => {
            vK(null)
          }), jC.nb);
          return () => {
            window.clearTimeout(OO)
          }
        }), [lO]);
        const QO = !XO.swapSticks && 0 === Object.keys(XO.MX).length;
        return (0, RO.jsxs)("div", {
          className: "ControlsContainer PadControlsContainer",
          children: [(0, RO.jsx)("div", {
            className: "SliderText",
            children: pO("controller:settingsRemap")
          }), (0, RO.jsx)("div", {
            className: "ControllerSettingsHint",
            children: pO("controller:settingsRemapHint")
          }), (0, RO.jsx)(ov.I, {
            className: "ResetBindingsButton PadResetAllButton",
            disabled: QO,
            onClick: () => {
              LO(null), vK(null), (0, DO.B)()
            },
            children: pO("controller:settingsResetAll")
          }), KO, jC.cb.map(((OO, KO) => (0, RO.jsx)(Zv.e, {
            title: pO(OO.titleKey),
            defaultOpen: 0 === KO,
            children: OO.rows.map((OO => (0, RO.jsx)(xC, {
              row: OO,
              capturing: "action" === OO.kind && OO.action === hO,
              onCapture: LO,
              holdFillRef: eO,
              onRebind: CO,
              swapped: "action" === OO.kind && (null === lO || void 0 === lO ? void 0 : lO.action) === OO.action ? lO.swapped : nv
            }, "action" === OO.kind ? OO.action : OO.labelKey)))
          }, OO.titleKey)))]
        })
      },
      tC = OO => {
        let {
          deadzone: KO,
          dotRef: pO,
          labelKey: XO
        } = OO;
        const {
          t: eO
        } = (0, bK.D)();
        return (0, RO.jsxs)("div", {
          className: "ControllerTesterStick",
          children: [(0, RO.jsxs)("div", {
            className: "ControllerTesterStickCircle",
            children: [(0, RO.jsx)("div", {
              className: "ControllerTesterDeadzone",
              style: {
                width: 100 * KO + "%",
                height: 100 * KO + "%"
              }
            }), (0, RO.jsx)("div", {
              ref: pO,
              className: "ControllerTesterDot"
            })]
          }), (0, RO.jsx)("div", {
            className: "ControllerTesterStickLabel",
            children: eO(XO)
          })]
        })
      },
      kC = (OO, KO, pO, XO) => {
        var bK;
        OO && (OO.style.left = 50 + 50 * Math.max(-1, Math.min(1, KO.x)) + "%", OO.style.top = 50 + 50 * Math.max(-1, Math.min(1, KO.y)) + "%", null === (bK = OO.parentElement) || void 0 === bK || bK.classList.toggle("Active", XO || Math.hypot(KO.x, KO.y) > pO))
      },
      Uv = OO => {
        const KO = {
            deadzone: OO.moveDeadzone,
            labelKey: "controller:settingsActionMove"
          },
          pO = {
            deadzone: OO.lookDeadzone,
            labelKey: "controller:settingsActionLook"
          };
        return OO.swapSticks ? {
          left: pO,
          right: KO
        } : {
          left: KO,
          right: pO
        }
      },
      OC = () => {
        const {
          t: OO
        } = (0, bK.D)(), KO = (() => {
          const [OO, KO] = (0, mK.useState)((() => lO.g.getActivePad()));
          return (0, vb.f)(lO.c, (() => {
            KO(lO.g.getActivePad())
          })), OO
        })(), pO = Uv((0, aK.p)()), XO = (0, mK.useRef)(null), eO = (0, mK.useRef)(null), vK = (0, mK.useRef)([]), CO = (0, mK.useRef)(null), hO = (0, mK.useRef)(null), [oO, VO] = (OO => {
          const [KO, pO] = (0, mK.useState)(!1), XO = (0, mK.useMemo)((() => KO ? () => {
            const KO = (0, DO.j)("menuBack"),
              XO = new jC.c;
            return {
              onFrame: (pO, bK) => {
                var eO;
                const lO = XO.update({
                  pressed: pO.wasPressed(KO),
                  JK: pO.isHeld(KO)
                }, pO.frame.timestampMs);
                null === (eO = OO.current) || void 0 === eO || eO.style.setProperty("width", 100 * lO + "%"), lO >= 1 && (MO.c.consumeButton(KO), bK())
              },
              onEnd: () => {
                pO(!1)
              }
            }
          } : null), [KO, OO]);
          return qC(XO), [KO, pO]
        })(eO);
        (0, mK.useEffect)((() => {
          const OO = OO => {
            for (const pO of FO.$) {
              const KO = (0, FO.k)(pO),
                XO = vK.current[KO];
              if (!XO) continue;
              const bK = OO.values[KO];
              XO.classList.toggle("Pressed", bK >= FO.x), (0, FO.N)(KO) && XO.style.setProperty("--trigger-fill", `${Math.round(100*bK)}%`)
            }
            const KO = Uv((0, aK.i)());
            kC(CO.current, OO.leftStick, KO.left.deadzone, OO.values[(0, FO.k)("LS")] >= FO.x), kC(hO.current, OO.rightStick, KO.right.deadzone, OO.values[(0, FO.k)("RS")] >= FO.x)
          };
          return KO || OO((0, FO.w)()), lO.g.onFrame(OO)
        }), [KO]), (0, mK.useEffect)((() => {
          KO || VO(!1)
        }), [KO, VO]), (0, mK.useEffect)((() => {
          var OO;
          oO && (null === (OO = XO.current) || void 0 === OO || OO.scrollIntoView({
            block: "nearest"
          }))
        }), [oO]);
        const LO = jC._.find((OO => OO.value === (null === KO || void 0 === KO ? void 0 : KO.family)));
        return (0, RO.jsxs)("div", {
          ref: XO,
          className: HO()("SettingBox ControllerTester", {
            Testing: oO
          }),
          children: [(0, RO.jsxs)("div", {
            className: "ControllerTesterHeader",
            children: [(0, RO.jsxs)("div", {
              className: "ControllerTesterInfo",
              children: [KO && (0, RO.jsx)("div", {
                children: OO("controller:settingsTesterFamily", {
                  family: LO ? OO(LO.labelKey) : KO.family
                })
              }), KO && (0, RO.jsx)("div", {
                className: "ControllerTesterPadId",
                children: KO.id
              }), !KO && (0, RO.jsx)("div", {
                children: OO("controller:settingsTesterNoPad")
              })]
            }), (KO || oO) && (0, RO.jsx)(ov.d, {
              className: "ControllerTesterToggle",
              onClick: () => {
                VO(!oO)
              },
              children: OO(oO ? "controller:settingsTesterStop" : "controller:settingsTesterStart")
            })]
          }), KO && !oO && (0, RO.jsx)("div", {
            className: "ControllerSettingsHint",
            children: OO("controller:settingsTesterHint")
          }), oO && (0, RO.jsxs)("div", {
            className: "ControllerTesterBanner",
            children: [(0, RO.jsx)(uv.b, {
              text: OO("controller:settingsTesterTesting", {
                button: uv.c
              }),
              glyph: (0, DO.j)("menuBack")
            }), (0, RO.jsx)("div", {
              ref: eO,
              className: "ControllerTesterExitFill"
            })]
          }), (0, RO.jsxs)("div", {
            className: "ControllerTesterBody",
            children: [(0, RO.jsx)(tC, {
              deadzone: pO.left.deadzone,
              dotRef: CO,
              labelKey: pO.left.labelKey
            }), (0, RO.jsx)("div", {
              className: "ControllerTesterButtons",
              children: FO.$.map((OO => {
                const pO = (0, FO.k)(OO);
                return (0, RO.jsx)("div", {
                  ref: OO => {
                    vK.current[pO] = OO
                  },
                  className: (0, FO.N)(pO) ? "ControllerTesterButton ControllerTesterTrigger" : "ControllerTesterButton",
                  children: (0, RO.jsx)(oX, {
                    glyph: OO,
                    family: null === KO || void 0 === KO ? void 0 : KO.family
                  })
                }, OO)
              }))
            }), (0, RO.jsx)(tC, {
              deadzone: pO.right.deadzone,
              dotRef: hO,
              labelKey: pO.right.labelKey
            })]
          })]
        })
      },
      KC = (0, mK.memo)((function() {
        const {
          t: OO
        } = (0, bK.D)(), KO = (0, aK.p)(), [pO, XO] = (0, mK.useState)(!1);
        return (0, mK.useEffect)((() => {
          if (!pO) return;
          const OO = window.setTimeout((() => {
            XO(!1)
          }), jC.nb);
          return () => {
            window.clearTimeout(OO)
          }
        }), [pO]), (0, RO.jsxs)("div", {
          className: "SettingsMenuRightInner ControllerCategory",
          children: [(0, RO.jsx)(Yv, {
            text: OO("controller:settingsLook")
          }), (0, RO.jsx)(iC, {
            settingKey: "lookSensitivityX",
            label: OO("controller:settingsLookSensitivityX"),
            range: jC.fb,
            format: jC.I
          }), (0, RO.jsx)(iC, {
            settingKey: "lookSensitivityY",
            label: OO("controller:settingsLookSensitivityY"),
            range: jC.fb,
            format: jC.I
          }), (0, RO.jsx)(iC, {
            settingKey: "aimLookSensitivity",
            label: OO("controller:settingsAimLookSensitivity"),
            range: jC.f,
            format: jC.I
          }), (0, RO.jsx)(wv, {
            label: OO("controller:settingsLookCurve"),
            hint: OO("controller:settingsLookCurveHint"),
            options: jC.T,
            value: KO.lookCurve,
            onChange: OO => {
              (0, aK.n)({
                lookCurve: OO
              })
            }
          }), (0, RO.jsx)(gC.b, {
            label: OO("controller:settingsInvertLookX"),
            checked: KO.invertLookX,
            onClick: OO => {
              (0, aK.n)({
                invertLookX: OO
              })
            }
          }), (0, RO.jsx)(gC.b, {
            label: OO("controller:settingsInvertLookY"),
            checked: KO.invertLookY,
            onClick: OO => {
              (0, aK.n)({
                invertLookY: OO
              })
            }
          }), (0, RO.jsx)(iC, {
            settingKey: "lookDeadzone",
            label: OO("controller:settingsLookDeadzone"),
            range: jC.z,
            format: jC.C
          }), (0, RO.jsx)(Jv, {}), (0, RO.jsx)(Yv, {
            text: OO("controller:settingsMovement")
          }), (0, RO.jsx)(iC, {
            settingKey: "moveDeadzone",
            label: OO("controller:settingsMoveDeadzone"),
            range: jC.z,
            format: jC.C
          }), (0, RO.jsx)(gC.b, {
            label: OO("controller:settingsAutoSprint"),
            checked: KO.autoSprint,
            onClick: OO => {
              (0, aK.n)({
                autoSprint: OO
              })
            },
            circleInfoText: OO("controller:settingsAutoSprintInfo")
          }), (0, RO.jsx)(wv, {
            label: OO("controller:settingsSneak"),
            options: jC.jb,
            value: KO.sneakMode,
            onChange: OO => {
              (0, aK.n)({
                sneakMode: OO
              })
            }
          }), (0, RO.jsx)(Yv, {
            text: OO("controller:settingsButtons")
          }), (0, RO.jsx)(wv, {
            label: OO("controller:settingsPromptFamily"),
            options: jC._,
            value: KO.promptFamily,
            onChange: OO => {
              (0, aK.n)({
                promptFamily: OO
              })
            }
          }), (0, RO.jsx)(gC.b, {
            label: OO("controller:settingsHideButtonHints"),
            checked: KO.hideButtonHints,
            onClick: OO => {
              (0, aK.n)({
                hideButtonHints: OO
              })
            }
          }), (0, RO.jsx)(gC.b, {
            label: OO("controller:settingsVibration"),
            checked: KO.vibration,
            onClick: OO => {
              (0, aK.n)({
                vibration: OO
              }), OO && Wp("preview")
            }
          }), (0, RO.jsx)(iC, {
            settingKey: "cursorSpeed",
            label: OO("controller:settingsCursorSpeed"),
            range: jC.w,
            format: jC.I
          }), (0, RO.jsx)(gC.b, {
            label: OO("controller:settingsCursorMagnetism"),
            checked: KO.cursorMagnetism,
            onClick: OO => {
              (0, aK.n)({
                cursorMagnetism: OO
              })
            }
          }), (0, RO.jsx)(gC.b, {
            label: OO("controller:settingsMenuBackToCategories"),
            checked: KO.menuBackToCategories,
            onClick: OO => {
              (0, aK.n)({
                menuBackToCategories: OO
              })
            }
          }), (0, RO.jsx)(Wv, {
            layoutSetting: (0, RO.jsxs)(RO.Fragment, {
              children: [DO.g.map((pO => (0, RO.jsx)(gC.b, {
                label: OO(jC.O[pO]),
                checked: (0, DO.y)(pO, KO),
                onClick: OO => {
                  XO(!(0, DO.H)(pO, OO))
                }
              }, pO))), pO && (0, RO.jsx)("div", {
                className: "PadLayoutRefusedNotice",
                role: "status",
                children: OO("controller:settingsLayoutRefusedToast")
              })]
            })
          }), (0, RO.jsx)(Bv, {}), (0, RO.jsx)(Yv, {
            text: OO("controller:settingsAlternatives")
          }), (0, RO.jsx)("div", {
            className: "ControllerSettingsHint",
            children: OO("controller:settingsAlternativesHint")
          }), (0, RO.jsx)(wv, {
            label: OO("controller:settingsMenuNavigation"),
            hint: OO("controller:settingsMenuNavigationHint"),
            options: jC.X,
            value: KO.menuNavigation,
            onChange: OO => {
              (0, aK.n)({
                menuNavigation: OO
              })
            }
          }), (0, RO.jsx)(wv, {
            label: OO("controller:settingsInventoryNavigation"),
            hint: OO("controller:settingsInventoryNavigationHint"),
            options: jC.M,
            value: KO.inventoryNavigation,
            onChange: OO => {
              (0, aK.n)({
                inventoryNavigation: OO
              })
            }
          }), (0, RO.jsx)(wv, {
            label: OO("controller:settingsQuickChat"),
            hint: OO("controller:settingsQuickChatHint"),
            options: jC.bb,
            value: KO.quickChat,
            onChange: OO => {
              (0, aK.n)({
                quickChat: OO
              })
            }
          }), (0, RO.jsx)(wv, {
            label: OO("controller:settingsLeaderboardButton"),
            hint: OO("controller:settingsLeaderboardButtonHint"),
            options: jC.R,
            value: KO.leaderboardButton,
            onChange: OO => {
              (0, aK.n)({
                leaderboardButton: OO
              })
            }
          }), (0, RO.jsx)(Yv, {
            text: OO("controller:settingsTester")
          }), (0, RO.jsx)(OC, {})]
        })
      }));
    (0, bK.e)(XO);
    for (const eC of (0, eO.o)()) eC.connected ? lO.g.handleConnectionEvent(eC) : lO.g.handleDisconnectionEvent(eC);
    const pC = () => null !== lO.g.getActivePad(),
      XC = () => cX.getState(),
      bh = () => cX.isSteppingSlots()
  },
  7260: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      i: () => CO
    });
    const XO = {
        "054c": "playstation",
        "057e": "nintendo"
      },
      bK = "28de",
      eO = new Set(["1205"]),
      lO = OO => {
        const KO = /vendor:\s*([0-9a-f]{4})\s*product:\s*([0-9a-f]{4})/i.exec(OO);
        if (KO) return {
          vendor: KO[1].toLowerCase(),
          product: KO[2].toLowerCase()
        };
        const pO = /^([0-9a-f]{1,4})-([0-9a-f]{1,4})-/i.exec(OO);
        return pO ? {
          vendor: pO[1].toLowerCase().padStart(4, "0"),
          product: pO[2].toLowerCase().padStart(4, "0")
        } : null
      },
      vK = (OO, KO) => {
        const pO = lO(OO);
        if ((null === pO || void 0 === pO ? void 0 : pO.vendor) === bK) return eO.has(pO.product) ? "steamdeck" : "xbox";
        if (pO && XO[pO.vendor]) return XO[pO.vendor];
        const vK = `${OO} ${null!==KO&&void 0!==KO?KO:""}`.toLowerCase();
        return /dualsense|dualshock|playstation|sony/.test(vK) ? "playstation" : /nintendo|switch|joy-con|pro controller/.test(vK) ? "nintendo" : /steam deck/.test(vK) ? "steamdeck" : "xbox"
      },
      CO = OO => {
        var KO;
        return (null === (KO = lO(OO)) || void 0 === KO ? void 0 : KO.vendor) === bK
      }
  },
  7291: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => hO,
      f: () => vK
    });
    var XO = pO(7255);
    const bK = ["capture", "keyboard", "wheel", "inventory", "cursor", "focus", "gameplay"],
      eO = new Set(["capture", "gameplay"]),
      lO = ["Up", "Down", "Left", "Right"],
      vK = OO => lO.includes(OO),
      CO = .25;
    const hO = new class {
      constructor() {
        this.consumers = new Map, this.activeName = null, this.JK = new Array(XO.Y).fill(!1), this.previousHeld = new Array(XO.Y).fill(!1), this.consumedButtons = new Array(XO.Y).fill(!1), this.suppressedReleases = new Array(XO.Y).fill(!1), this.wakeOwned = new Array(XO.Y).fill(!1), this.leftStickConsumed = !1, this.rightStickConsumed = !1, this.handOffPending = !1, this.idleResume = null, this.peek = null, this.lastFrame = (0, XO.w)()
      }
      register(OO) {
        return this.consumers.has(OO.name) && console.warn(`Controller consumer "${OO.name}" registered twice; the newer one replaces it.`), this.consumers.set(OO.name, OO), () => {
          var KO;
          this.consumers.get(OO.name) === OO && (this.activeName === OO.name ? (this.deactivateCurrent(), this.activeName = null, this.consumeAllHeld()) : (null === (KO = this.peek) || void 0 === KO ? void 0 : KO.over) === OO.name && (this.peek = null), this.consumers.delete(OO.name))
        }
      }
      getActiveConsumerName() {
        return this.activeName
      }
      isButtonHeld(OO) {
        return this.JK[(0, XO.k)(OO)]
      }
      getLastFrame() {
        return this.lastFrame
      }
      clear() {
        this.deactivateCurrent(), this.activeName = null, this.consumeAllHeld()
      }
      reset() {
        this.deactivateCurrent(), this.activeName = null, this.JK = new Array(XO.Y).fill(!1), this.previousHeld = new Array(XO.Y).fill(!1), this.consumedButtons.fill(!1), this.suppressedReleases.fill(!1), this.wakeOwned.fill(!1), this.leftStickConsumed = !1, this.rightStickConsumed = !1, this.handOffPending = !1, this.idleResume = null, this.lastFrame = (0, XO.w)()
      }
      dispatch(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        this.lastFrame = OO, this.previousHeld = this.JK, this.JK = (0, XO.p)(OO.values, this.previousHeld);
        for (let eO = 0; eO < XO.Y; eO++) this.suppressedReleases[eO] = !this.JK[eO] && this.consumedButtons[eO], this.JK[eO] || (this.consumedButtons[eO] = !1), this.wakeOwned[eO] && (this.JK[eO] ? (this.consumedButtons[eO] = !0, this.wakeOwned[eO] = !1) : OO.values[eO] < XO.V && (this.wakeOwned[eO] = !1));
        Math.hypot(OO.leftStick.x, OO.leftStick.y) < CO && (this.leftStickConsumed = !1), Math.hypot(OO.rightStick.x, OO.rightStick.y) < CO && (this.rightStickConsumed = !1);
        const bK = this.pickActive();
        if ((null === bK || void 0 === bK ? void 0 : bK.name) !== this.activeName) {
          var lO, vK, hO, DO, MO, aK;
          const OO = this.activeName,
            KO = {
              left: !this.leftStickConsumed,
              right: !this.rightStickConsumed
            },
            pO = null !== (lO = null === bK || void 0 === bK || null === (vK = bK.peek) || void 0 === vK ? void 0 : vK.call(bK)) && void 0 !== lO ? lO : null,
            eO = null === OO && !!pO && !(null === (hO = this.consumers.get(pO.over)) || void 0 === hO || !hO.onPeekFrame),
            CO = pO && (pO.over === OO || eO) ? pO : null,
            oO = null !== this.peek && this.peek.over === (null === bK || void 0 === bK ? void 0 : bK.name) ? this.peek : null;
          this.deactivateCurrent(null !== CO, null !== oO), this.activeName = null !== (DO = null === bK || void 0 === bK ? void 0 : bK.name) && void 0 !== DO ? DO : null, null === OO || this.handOffPending || this.consumeAllHeld();
          const FO = null === (MO = null !== CO && void 0 !== CO ? CO : oO) || void 0 === MO ? void 0 : MO.stick;
          "left" === FO && KO.left ? this.leftStickConsumed = !1 : "right" === FO && KO.right && (this.rightStickConsumed = !1), this.peek = CO, bK || null === OO ? bK && (null === (aK = this.idleResume) || void 0 === aK ? void 0 : aK.name) === bK.name && (this.idleResume.left && (this.leftStickConsumed = !1), this.idleResume.right && (this.rightStickConsumed = !1)) : this.idleResume = {
            name: OO,
            left: KO.left && this.leftStickConsumed,
            right: KO.right && this.rightStickConsumed
          }, bK && (this.idleResume = null);
          for (let bK = 0; bK < XO.Y; bK++) this.previousHeld[bK] && !this.JK[bK] && (this.suppressedReleases[bK] = !0)
        }
        var oO, FO;
        (this.handOffPending = !1, bK) && (pO && !eO.has(bK.name) && this.consumeWakePress(bK), bK.onFrame(this.buildInput(OO, KO, pO)), this.peek && (null === (oO = this.consumers.get(this.peek.over)) || void 0 === oO || null === (FO = oO.onPeekFrame) || void 0 === FO || FO.call(oO, this.buildInput(OO, KO, !1, this.peek.stick))))
      }
      consumeWakePress(OO) {
        for (let bK = 0; bK < XO.Y; bK++) {
          var KO, pO;
          const eO = XO.$[bK];
          (null !== (KO = null === (pO = OO.wakePressActs) || void 0 === pO ? void 0 : pO.call(OO, eO)) && void 0 !== KO ? KO : lO.includes(eO)) || (this.JK[bK] ? this.consumedButtons[bK] = !0 : this.lastFrame.values[bK] >= XO.T && (this.wakeOwned[bK] = !0))
        }
      }
      pickActive() {
        for (const OO of bK) {
          const KO = this.consumers.get(OO);
          if (KO && KO.isActive()) return KO
        }
        return null
      }
      deactivateCurrent() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        var pO, XO, bK, eO;
        this.activeName && (null === (pO = this.consumers.get(this.activeName)) || void 0 === pO || null === (XO = pO.onDeactivate) || void 0 === XO || XO.call(pO, OO));
        this.peek && !KO && (null === (bK = this.consumers.get(this.peek.over)) || void 0 === bK || null === (eO = bK.onDeactivate) || void 0 === eO || eO.call(bK, !1));
        this.peek = null
      }
      consumeAllHeld() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        this.idleResume = null;
        for (let bK = 0; bK < XO.Y; bK++) this.JK[bK] && (this.consumedButtons[bK] = !0);
        const {
          leftStick: KO,
          rightStick: pO
        } = this.lastFrame;
        this.leftStickConsumed = "left" !== OO && (this.leftStickConsumed || Math.hypot(KO.x, KO.y) >= CO), this.rightStickConsumed = "right" !== OO && (this.rightStickConsumed || Math.hypot(pO.x, pO.y) >= CO)
      }
      handOffHeldInput() {
        this.handOffPending = !0
      }
      consumeButton(OO) {
        const KO = (0, XO.k)(OO);
        this.JK[KO] && (this.consumedButtons[KO] = !0)
      }
      buildInput(OO, KO, pO, bK) {
        const eO = this.JK,
          lO = this.previousHeld,
          vK = bK ? new Array(XO.Y).fill(!0) : [...this.consumedButtons],
          CO = bK ? vK : [...this.suppressedReleases],
          hO = !this.leftStickConsumed && (!bK || "left" === bK),
          DO = !this.rightStickConsumed && (!bK || "right" === bK);
        return {
          frame: OO,
          dtMs: KO,
          isHeld: OO => {
            const KO = (0, XO.k)(OO);
            return eO[KO] && !vK[KO]
          },
          wasPressed: OO => {
            const KO = (0, XO.k)(OO);
            return eO[KO] && !lO[KO] && !vK[KO]
          },
          wasReleased: OO => {
            const KO = (0, XO.k)(OO);
            return !eO[KO] && lO[KO] && !CO[KO]
          },
          value: KO => {
            const pO = (0, XO.k)(KO);
            return vK[pO] ? 0 : OO.values[pO]
          },
          leftStick: hO ? OO.leftStick : {
            x: 0,
            y: 0
          },
          rightStick: DO ? OO.rightStick : {
            x: 0,
            y: 0
          },
          wokeDevice: pO
        }
      }
    }
  },
  7275: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => MO.f,
      f: () => MO.i,
      i: () => uO,
      l: () => EO,
      n: () => jK,
      p: () => YO
    });
    var XO = pO(63),
      bK = pO(26),
      eO = pO(1263),
      lO = pO(36),
      vK = pO(7281),
      CO = pO(7255),
      hO = pO(7272),
      DO = pO(7252),
      MO = pO(1621),
      aK = pO(7284);
    const oO = {
        lookSensitivityX: 100,
        lookSensitivityY: 100,
        aimLookSensitivity: 100,
        invertLookX: !1,
        invertLookY: !1,
        lookCurve: "exponential",
        lookDeadzone: .12,
        moveDeadzone: .15,
        swapSticks: !1,
        autoSprint: !0,
        sneakMode: "toggle",
        tapHoldTime: "short",
        attackMode: "hold",
        promptFamily: "auto",
        hideButtonHints: !1,
        vibration: !0,
        cursorSpeed: 100,
        cursorMagnetism: !1,
        buttonRepeat: "default",
        largePointer: !1,
        menuBackToCategories: !0,
        swapConfirmBack: null,
        menuNavigation: "hybrid",
        inventoryNavigation: "hybrid",
        quickChat: "wheel",
        leaderboardButton: "shop",
        gyroAiming: !1,
        gyroSensitivity: 2,
        gyroActivation: "always",
        gyroButton: "RB",
        emoteButton: "tapHold",
        MX: {}
      },
      FO = "controllerSettings",
      VO = ["MX", "promptFamily", "hideButtonHints", "swapSticks", "swapConfirmBack", "leaderboardButton"],
      LO = ["auto", ...vK.d],
      QO = (OO, KO) => "string" === typeof KO && OO.includes(KO),
      zK = OO => KO => "number" === typeof KO && Number.isFinite(KO) ? (0, aK.t)(KO, OO) : void 0,
      AO = OO => "boolean" === typeof OO ? OO : void 0,
      fO = OO => KO => QO(OO, KO) ? KO : void 0,
      dO = {
        lookSensitivityX: zK(aK.fb),
        lookSensitivityY: zK(aK.fb),
        aimLookSensitivity: zK(aK.f),
        invertLookX: AO,
        invertLookY: AO,
        lookCurve: fO(CO.R),
        lookDeadzone: zK(aK.z),
        moveDeadzone: zK(aK.z),
        swapSticks: AO,
        autoSprint: AO,
        sneakMode: fO(["toggle", "hold"]),
        tapHoldTime: fO(["short", "medium", "long"]),
        attackMode: fO(["hold", "toggle"]),
        promptFamily: fO(LO),
        hideButtonHints: AO,
        vibration: AO,
        cursorSpeed: zK(aK.w),
        cursorMagnetism: AO,
        buttonRepeat: fO(CO.m),
        largePointer: AO,
        menuBackToCategories: AO,
        swapConfirmBack: AO,
        menuNavigation: fO(["hybrid", "focus", "cursor"]),
        inventoryNavigation: fO(["hybrid", "slot", "cursor"]),
        quickChat: fO(["wheel", "off"]),
        leaderboardButton: fO(["shop", "leaderboard"]),
        gyroAiming: AO,
        gyroSensitivity: zK(aK.K),
        gyroActivation: fO(["always", "aiming", "button"]),
        gyroButton: fO(CO.$),
        emoteButton: fO(["tapHold", "wheel"])
      },
      TO = [{
        param: "padMenuNav",
        key: "menuNavigation"
      }, {
        param: "padInventoryNav",
        key: "inventoryNavigation"
      }, {
        param: "padQuickChat",
        key: "quickChat"
      }, {
        param: "padSneak",
        key: "sneakMode"
      }, {
        param: "padGyro",
        key: "gyroActivation"
      }, {
        param: "padLeaderboardButton",
        key: "leaderboardButton"
      }],
      NO = OO => {
        const KO = {};
        if ("object" !== typeof OO || null === OO) return KO;
        for (const [pO, XO] of Object.entries(OO)) Object.prototype.hasOwnProperty.call(hO.d, pO) && QO(CO.$, XO) && (KO[pO] = XO);
        return KO
      },
      IO = OO => {
        const KO = {};
        for (const pO of Object.keys(oO))("MX" === pO ? Object.keys(OO.MX).length > 0 : OO[pO] !== oO[pO]) && (KO[pO] = OO[pO]);
        0 !== Object.keys(KO).length ? lO.e.setItem(FO, KO) : lO.e.removeItem(FO)
      };
    let yK = (() => {
        const OO = lO.e.getItem(FO),
          KO = (OO => {
            const KO = "object" === typeof OO && null !== OO ? OO : {},
              pO = {
                ...oO,
                MX: NO(KO.MX)
              };
            for (const bK of Object.keys(dO)) {
              const OO = dO[bK](KO[bK]);
              void 0 !== OO && (pO[bK] = OO)
            }
            const XO = Object.keys(KO).filter((OO => !!Object.prototype.hasOwnProperty.call(oO, OO) && ("MX" === OO ? "object" !== typeof KO.MX || null === KO.MX || Object.keys(KO.MX).length !== Object.keys(pO.MX).length : pO[OO] !== KO[OO])));
            return XO.length > 0 && console.warn(`Stored controller settings had invalid values, replaced with defaults: ${XO.join(", ")}`), pO
          })(OO);
        return null !== OO && void 0 !== OO && IO(KO), KO
      })(),
      gK = {
        ...yK,
        ...(() => {
          if ("undefined" === typeof window) return {};
          const OO = {},
            KO = new URLSearchParams(window.location.search);
          for (const {
              param: pO,
              key: XO
            }
            of TO) {
            const bK = dO[XO](KO.get(pO));
            void 0 !== bK && (OO[XO] = bK)
          }
          return OO
        })()
      };
    const uO = () => gK,
      EO = () => {
        var OO, KO;
        const pO = uO().promptFamily;
        return "auto" !== pO ? pO : null !== (OO = null === (KO = DO.g.getActivePad()) || void 0 === KO ? void 0 : KO.family) && void 0 !== OO ? OO : "xbox"
      },
      jK = OO => {
        const KO = gK;
        yK = {
          ...yK,
          ...OO
        }, IO(yK), gK = {
          ...gK,
          ...OO
        }, (OO => {
          bK.i.pl(MO.i, gK), VO.some((KO => OO[KO] !== gK[KO])) && bK.i.pl(MO.f, gK)
        })(KO)
      },
      YO = () => {
        const [OO, KO] = (0, XO.useState)(gK);
        return (0, eO.f)(MO.i, KO), OO
      }
  },
  7746: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    const XO = new Set(["Alt", "AltGraph", "Meta", "OS", "AudioVolumeUp", "AudioVolumeDown", "AudioVolumeMute", "MediaPlayPause", "MediaPlay", "MediaPause", "MediaStop", "MediaTrackNext", "MediaTrackPrevious", "BrowserBack", "BrowserForward", "BrowserHome", "GoBack", "LaunchApplication1", "LaunchApplication2", "LaunchMail", "PrintScreen", "Unidentified"]),
      bK = OO => XO.has(OO)
  },
  7252: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => oO.b,
      g: () => QO
    });
    var XO = pO(7255),
      bK = pO(7260);
    const eO = .1,
      lO = .3;
    class vK {
      constructor() {
        this.deadzone = 0, this.anchor = null, this.steadyMs = 0, this.lastMs = null, this.returning = !0, this.anchorLearned = !1
      }
      observe(OO, KO) {
        const pO = null === this.lastMs ? 0 : Math.min(Math.max(0, KO - this.lastMs), 100);
        this.lastMs = KO;
        const XO = Math.hypot(OO.x, OO.y);
        if (XO >= lO) return this.anchor = null, void(this.returning = !0);
        XO >= eO || (this.returning = !1);
        const bK = this.anchor;
        if (!bK || Math.hypot(OO.x - bK.x, OO.y - bK.y) > .03) return this.anchorLearned && (this.returning = !1), this.anchor = {
          x: OO.x,
          y: OO.y
        }, this.steadyMs = 0, void(this.anchorLearned = !1);
        if (this.steadyMs += pO, this.steadyMs < 1e3) return;
        const vK = Math.max(XO, Math.hypot(bK.x, bK.y));
        vK < eO ? this.deadzone = 0 : this.returning && (this.deadzone = vK + .05, this.anchorLearned = !0)
      }
      getDeadzone() {
        return this.deadzone
      }
      apply(OO) {
        return Math.hypot(OO.x, OO.y) < this.deadzone ? {
          x: 0,
          y: 0
        } : OO
      }
    }
    const CO = (OO, KO) => {
        var pO, XO;
        return null !== (pO = OO && (null === (XO = Object.getOwnPropertyDescriptor(OO, KO)) || void 0 === XO ? void 0 : XO.get)) && void 0 !== pO ? pO : null
      },
      hO = OO => {
        const KO = OO.vendorName;
        return "string" === typeof KO ? KO : void 0
      },
      DO = ((OO, KO) => {
        const pO = CO(OO, "index"),
          XO = CO(OO, "id"),
          bK = CO(OO, "connected"),
          eO = CO(OO, "mapping"),
          lO = CO(OO, "buttons"),
          vK = CO(OO, "axes"),
          DO = CO(KO, "pressed"),
          MO = CO(KO, "value");
        return pO && XO && bK && eO && lO && vK && DO && MO ? OO => {
          const KO = lO.call(OO),
            CO = vK.call(OO),
            aK = {
              index: Number(pO.call(OO)),
              id: String(XO.call(OO)),
              connected: !0 === bK.call(OO),
              mapping: String(eO.call(OO)),
              buttons: [],
              axes: [],
              vendorName: hO(OO)
            };
          for (let pO = 0; pO < KO.length; pO++) aK.buttons.push({
            pressed: !0 === DO.call(KO[pO]),
            value: Number(MO.call(KO[pO]))
          });
          for (let pO = 0; pO < CO.length; pO++) aK.axes.push(Number(CO[pO]));
          return aK
        } : null
      })("undefined" === typeof Gamepad ? null : Gamepad.prototype, "undefined" === typeof GamepadButton ? null : GamepadButton.prototype),
      MO = "undefined" === typeof Navigator ? null : Navigator.prototype.getGamepads;
    var aK = pO(1236),
      oO = pO(1621);
    const FO = lO,
      VO = OO => {
        const KO = new Array(XO.Y).fill(0);
        for (let pO = 0; pO < XO.Y && pO < OO.buttons.length; pO++) {
          const bK = OO.buttons[pO];
          KO[pO] = bK.pressed && !(0, XO.N)(pO) ? Math.max(bK.value, XO.x) : bK.value
        }
        return KO
      },
      LO = (OO, KO) => {
        var pO, XO;
        return {
          x: null !== (pO = OO.axes[KO]) && void 0 !== pO ? pO : 0,
          y: null !== (XO = OO.axes[KO + 1]) && void 0 !== XO ? XO : 0
        }
      };
    const QO = new class {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : DO;
        this.readGamepads = OO, this.requireTrustedPads = KO, this.nativeReader = pO, this.running = !1, this.listening = !1, this.rafId = 0, this.lastTimestampMs = 0, this.activeInfo = null, this.slots = [], this.trustedIndices = new Set, this.warnedNonStandardIds = new Set, this.loggedReadError = !1, this.frameListeners = new Set, this.connectionListeners = new Set, this.anyPadConnected = !1, this.connectedListeners = new Set, this.handleConnectionEvent = OO => {
          OO.isTrusted && this.trustedIndices.add(OO.gamepad.index), this.wake()
        }, this.handleDisconnectionEvent = OO => {
          this.trustedIndices.delete(OO.gamepad.index)
        }, this.KK = OO => {
          if (this.rafId = 0, !this.running) return;
          const KO = 0 === this.lastTimestampMs ? 16 : Math.min(100, OO - this.lastTimestampMs);
          this.lastTimestampMs = OO;
          try {
            this.poll(OO, KO)
          } finally {
            this.anyPadConnected && (this.rafId = requestAnimationFrame(this.KK))
          }
        }
      }
      start() {
        this.running || "undefined" === typeof navigator || "function" !== typeof navigator.getGamepads || (this.running = !0, this.listenForConnections(), this.wake())
      }
      stop() {
        this.running = !1, cancelAnimationFrame(this.rafId), this.rafId = 0, this.listening = !1, window.removeEventListener("gamepadconnected", this.handleConnectionEvent), window.removeEventListener("gamepaddisconnected", this.handleDisconnectionEvent)
      }
      listenForConnections() {
        this.listening || "undefined" === typeof window || (this.listening = !0, window.addEventListener("gamepadconnected", this.handleConnectionEvent), window.addEventListener("gamepaddisconnected", this.handleDisconnectionEvent))
      }
      onFrame(OO) {
        return this.frameListeners.add(OO), () => {
          this.frameListeners.delete(OO)
        }
      }
      onActivePadChanged(OO) {
        return this.connectionListeners.add(OO), () => {
          this.connectionListeners.delete(OO)
        }
      }
      getActivePad() {
        return this.activeInfo
      }
      hasConnectedPad() {
        return this.anyPadConnected
      }
      onConnectedPadsChanged(OO) {
        return this.connectedListeners.add(OO), () => {
          this.connectedListeners.delete(OO)
        }
      }
      getActiveGamepad() {
        if (!this.activeInfo) return null;
        const OO = this.readPads()[this.activeInfo.index],
          KO = OO ? this.readPad(OO) : null;
        return KO && KO.id === this.activeInfo.id ? OO : null
      }
      poll(OO, KO) {
        var pO, bK;
        const eO = this.readPads();
        let lO = null,
          CO = !1;
        const hO = [],
          DO = Math.max(eO.length, this.slots.length);
        for (let AO = 0; AO < DO; AO++) {
          var MO;
          const KO = AO < eO.length ? eO[AO] : null,
            pO = KO ? this.readPad(KO) : null;
          if (!pO || !pO.connected || !this.isUsable(pO)) {
            this.slots[AO] = null;
            continue
          }
          let bK = this.slots[AO];
          bK && bK.id === pO.id || (bK = {
            id: pO.id,
            JK: [],
            leftSettled: !1,
            rightSettled: !1,
            leftRest: new vK,
            rightRest: new vK
          }, this.slots[AO] = bK);
          const DO = LO(pO, 0),
            aK = LO(pO, 2);
          !bK.leftSettled && Math.hypot(DO.x, DO.y) < FO && (bK.leftSettled = !0), !bK.rightSettled && Math.hypot(aK.x, aK.y) < FO && (bK.rightSettled = !0), bK.leftRest.observe(DO, OO), bK.rightRest.observe(aK, OO);
          const oO = VO(pO),
            QO = (0, XO.p)(oO, bK.JK),
            zK = bK.JK,
            fO = QO.map(((OO, KO) => OO && !zK[KO]));
          bK.JK = QO;
          const dO = {
            pad: pO,
            slot: bK,
            values: oO
          };
          AO === (null === (MO = this.activeInfo) || void 0 === MO ? void 0 : MO.index) && pO.id === this.activeInfo.id ? (lO = dO, CO = fO.includes(!0)) : fO.includes(!0) && hO.push({
            polled: dO,
            rose: fO
          })
        }
        const aK = this.slots.some((OO => null !== OO));
        if (aK !== this.anyPadConnected) {
          this.anyPadConnected = aK;
          for (const OO of this.connectedListeners) OO()
        }
        const oO = null !== (pO = null === (bK = lO) || void 0 === bK ? void 0 : bK.slot.JK) && void 0 !== pO ? pO : [],
          QO = CO ? void 0 : hO.find((OO => {
            let {
              rose: KO
            } = OO;
            return KO.some(((OO, KO) => OO && !oO[KO]))
          }));
        if (QO ? (lO = QO.polled, this.setActive(QO.polled.pad)) : this.activeInfo && !lO && this.setActive(null), !lO || !this.activeInfo) return;
        const zK = ((OO, KO) => {
          let {
            pad: pO,
            slot: bK,
            values: eO
          } = OO;
          const lO = (0, XO.w)(KO);
          return lO.values = eO, bK.leftSettled && (lO.leftStick = bK.leftRest.apply(LO(pO, 0))), bK.rightSettled && (lO.rightStick = bK.rightRest.apply(LO(pO, 2))), lO
        })(lO, OO);
        for (const XO of this.frameListeners) XO(zK, KO, this.activeInfo)
      }
      readPad(OO) {
        if (this.nativeReader) try {
          return this.nativeReader(OO)
        } catch {
          if (this.requireTrustedPads) return null
        }
        return this.requireTrustedPads ? null : (OO => {
          const KO = OO;
          return {
            index: KO.index,
            id: KO.id,
            connected: KO.connected,
            mapping: KO.mapping,
            buttons: Array.from(KO.buttons, (OO => ({
              pressed: OO.pressed,
              value: OO.value
            }))),
            axes: Array.from(KO.axes),
            vendorName: hO(OO)
          }
        })(OO)
      }
      isUsable(OO) {
        return !(0, aK.f)(OO.id) && ("standard" !== OO.mapping ? (this.warnedNonStandardIds.has(OO.id) || (this.warnedNonStandardIds.add(OO.id), console.warn(`Controller "${OO.id}" has no standard button mapping, so it is ignored.`)), !1) : !this.requireTrustedPads || this.trustedIndices.has(OO.index))
      }
      setActive(OO) {
        this.activeInfo = OO ? {
          index: OO.index,
          id: OO.id,
          family: (0, bK.e)(OO.id, OO.vendorName)
        } : null;
        for (const KO of this.connectionListeners) KO(this.activeInfo)
      }
      readPads() {
        try {
          return this.readGamepads()
        } catch (OO) {
          return this.loggedReadError || (this.loggedReadError = !0, console.warn("Reading gamepads failed; controller input is unavailable.", OO)), []
        }
      }
      wake() {
        this.running && 0 === this.rafId && (this.lastTimestampMs = 0, this.rafId = requestAnimationFrame(this.KK))
      }
    }((() => MO ? MO.call(navigator) : []), !0);
    QO.listenForConnections()
  },
  7793: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      h: () => lO,
      l: () => vK,
      o: () => bK
    });
    var XO = pO(7800);
    const bK = OO => {
        const KO = [];
        OO.holdingGun && KO.push({
          kind: "reload"
        }), OO.touchscreenActionButton && KO.push({
          kind: "touchButton",
          label: OO.touchscreenActionButton
        });
        for (const eO of null !== (pO = null === (bK = OO.customButtons) || void 0 === bK ? void 0 : bK.filter(XO.f)) && void 0 !== pO ? pO : []) {
          var pO, bK;
          KO.push({
            kind: "customButton",
            id: eO.id,
            icon: eO.icon,
            description: eO.description
          })
        }
        return KO
      },
      eO = OO => OO.length >= 2,
      lO = OO => "specialAction" !== OO.kind,
      vK = (OO, KO) => {
        if (null === OO || null === KO) return OO === KO;
        if (OO.kind !== KO.kind) return !1;
        switch (OO.kind) {
          case "reload":
            return !0;
          case "specialAction":
            return OO.action === KO.action;
          case "customButton":
            return OO.id === KO.id && OO.icon === KO.icon;
          case "touchButton":
            return OO.label === KO.label
        }
      }
  },
  7750: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    const XO = {
      short: {
        wheelMs: 250,
        dropStackMs: 800
      },
      medium: {
        wheelMs: 500,
        dropStackMs: 1e3
      },
      long: {
        wheelMs: 800,
        dropStackMs: 1300
      }
    }
  },
  7789: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      e: () => oO,
      i: () => MO,
      j: () => FO
    });
    var XO = pO(63),
      bK = pO(26),
      eO = pO(1263),
      lO = pO(7793),
      vK = pO(7806);
    let CO = null;
    const hO = () => CO,
      DO = OO => {
        (0, lO.l)(CO, OO) || (CO = OO, bK.i.pl(vK.f, CO))
      },
      MO = () => {
        const [OO, KO] = (0, XO.useState)(hO);
        return (0, eO.f)(vK.f, KO), OO
      };
    let aK = !1;
    const oO = OO => {
        OO !== aK && (aK = OO, bK.i.pl(vK.j, OO))
      },
      FO = () => {
        const [OO, KO] = (0, XO.useState)(aK);
        return (0, eO.f)(vK.j, KO), OO
      }
  },
  7817: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      h: () => vK
    });
    var XO = pO(26),
      bK = pO(7806);
    let eO = !1;
    const lO = () => eO,
      vK = OO => {
        OO !== eO && (eO = OO, XO.i.pl(bK.m, eO))
      }
  },
  7811: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK,
      f: () => CO
    });
    var XO = pO(26),
      bK = pO(7806);
    let eO = null,
      lO = 0;
    const vK = () => eO,
      CO = OO => {
        null === OO && null === eO || (eO = null === OO ? null : {
          id: ++lO,
          holdMs: OO
        }, XO.i.pl(bK.p, eO))
      }
  },
  7806: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      f: () => XO,
      j: () => bK,
      m: () => vK,
      p: () => CO,
      q: () => hO,
      s: () => lO
    });
    const XO = "controllerActionHintChanged",
      bK = "controllerActionWheelHintChanged",
      eO = "controllerOpenChat",
      lO = "controllerSneakToggledChanged",
      vK = "controllerAttackLatchedChanged",
      CO = "controllerDropStackHoldChanged",
      hO = "controllerPickBlockHintChanged"
  },
  7819: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      d: () => vK
    });
    var XO = pO(26),
      bK = pO(7806);
    let eO = !1;
    const lO = () => eO,
      vK = OO => {
        OO !== eO && (eO = OO, XO.i.pl(bK.q, eO))
      }
  },
  7913: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      i: () => vK
    });
    var XO = pO(26),
      bK = pO(7806);
    let eO = !1;
    const lO = () => eO,
      vK = OO => {
        OO !== eO && (eO = OO, XO.i.pl(bK.s, eO))
      }
  },
  7842: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      constructor() {
        this.downAtMs = null
      }
      update(OO, KO, pO, XO) {
        if (OO) return this.downAtMs = pO, null;
        if (null === this.downAtMs) return null;
        const bK = pO - this.downAtMs >= XO;
        return KO ? bK ? (this.downAtMs = null, "hold") : null : (this.downAtMs = null, bK ? "hold" : "tap")
      }
      release() {
        this.downAtMs = null
      }
    }
  },
  7310: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => MO,
      d: () => aK,
      g: () => vK,
      h: () => AO,
      k: () => zK
    });
    var XO = pO(36),
      bK = pO(7281),
      eO = pO(7255);
    const lO = (() => {
        try {
          return pO(7319)
        } catch {
          return null
        }
      })(),
      vK = [...eO.$, "LeftStick", "RightStick"],
      CO = new Map,
      hO = {
        xbox: "xbox",
        playstation: "playstation",
        nintendo: "nintendo",
        steamdeck: "steamdeck",
        generic: "xbox"
      },
      DO = (new Set(Object.values(hO)), {
        xbox: {
          LB: 1.5,
          RB: 1.5
        },
        steamdeck: {
          Home: 2,
          Menu: 2,
          View: 2
        }
      }),
      MO = (OO, KO) => {
        var pO, XO;
        return null !== (pO = null === (XO = DO[hO[OO]]) || void 0 === XO ? void 0 : XO[KO]) && void 0 !== pO ? pO : 1
      },
      aK = (OO, KO) => {
        const pO = `./${hO[OO]}/${KO}.svg`;
        let XO = CO.get(pO);
        return void 0 === XO && (XO = lO ? lO(pO) : "", CO.set(pO, XO)), XO
      },
      oO = new Set,
      FO = [],
      VO = OO => {
        if (!oO.has(OO)) {
          oO.add(OO);
          for (const KO of vK) {
            const pO = aK(OO, KO);
            if (pO) {
              const OO = new Image;
              OO.crossOrigin = "anonymous", OO.src = pO, FO.push(OO)
            }
          }
        }
      },
      LO = "controllerGlyphFamily";
    let QO = null;
    const zK = OO => {
        OO !== QO && (QO = OO, XO.e.setItem(LO, OO), VO(OO))
      },
      AO = () => {
        const OO = XO.e.getItem(LO);
        (0, bK.g)(OO) && OO !== QO && (QO = OO, VO(OO))
      }
  },
  7935: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => HO,
      f: () => RO
    });
    var XO = pO(63),
      bK = pO(26),
      eO = pO(1263),
      lO = pO(7263),
      vK = pO(7252),
      CO = pO(7291),
      hO = pO(7275);
    const DO = {
        x: 0,
        y: 0,
        z: 0
      },
      MO = Math.PI / 180,
      aK = OO => Math.hypot(OO.x, OO.y, OO.z),
      oO = (OO, KO) => ({
        x: OO.x * KO,
        y: OO.y * KO,
        z: OO.z * KO
      }),
      FO = (OO, KO) => ({
        x: OO.x + KO.x,
        y: OO.y + KO.y,
        z: OO.z + KO.z
      }),
      VO = (OO, KO) => ({
        x: OO.x - KO.x,
        y: OO.y - KO.y,
        z: OO.z - KO.z
      }),
      LO = OO => {
        const KO = aK(OO);
        return 0 === KO ? DO : oO(OO, 1 / KO)
      },
      QO = OO => ({
        min: {
          ...OO
        },
        max: {
          ...OO
        }
      }),
      zK = (OO, KO) => ({
        min: {
          x: Math.min(OO.min.x, KO.x),
          y: Math.min(OO.min.y, KO.y),
          z: Math.min(OO.min.z, KO.z)
        },
        max: {
          x: Math.max(OO.max.x, KO.x),
          y: Math.max(OO.max.y, KO.y),
          z: Math.max(OO.max.z, KO.z)
        }
      }),
      AO = (OO, KO) => OO.max.x - OO.min.x <= KO && OO.max.y - OO.min.y <= KO && OO.max.z - OO.min.z <= KO;
    class fO {
      constructor() {
        this.bias = DO, this.calibrated = !1, this.gyroRange = null, this.accelRange = null, this.sum = DO, this.windowSec = 0
      }
      update(OO) {
        const KO = this.gyroRange ? zK(this.gyroRange, OO.gyro) : QO(OO.gyro),
          pO = OO.accel ? this.accelRange ? zK(this.accelRange, OO.accel) : QO(OO.accel) : null;
        if (!AO(KO, 1) || pO && !AO(pO, .01)) return void this.restartWindow(OO);
        if (this.gyroRange = KO, this.accelRange = pO, this.sum = FO(this.sum, oO(OO.gyro, OO.dtSec)), this.windowSec += OO.dtSec, this.windowSec < 1) return;
        const XO = oO(this.sum, 1 / this.windowSec);
        if (aK(XO) > 5) return;
        const bK = VO(XO, this.bias);
        let eO = 0;
        !this.calibrated || this.windowSec >= 3 ? eO = 1 : aK(bK) <= 1 && (eO = Math.min(1, OO.dtSec / 1)), this.bias = FO(this.bias, oO(bK, eO)), this.calibrated = this.calibrated || eO > 0
      }
      correct(OO) {
        return VO(OO, this.bias)
      }
      getBias() {
        return this.bias
      }
      isCalibrated() {
        return this.calibrated
      }
      reset() {
        this.bias = DO, this.calibrated = !1, this.gyroRange = null, this.accelRange = null, this.sum = DO, this.windowSec = 0
      }
      restartWindow(OO) {
        this.gyroRange = QO(OO.gyro), this.accelRange = OO.accel ? QO(OO.accel) : null, this.sum = DO, this.windowSec = 0
      }
    }
    class dO {
      constructor() {
        this.down = null
      }
      update(OO, KO, pO) {
        const XO = LO(oO(KO, -1));
        if (!this.down) return this.down = XO, XO;
        const bK = oO(OO, MO * pO),
          eO = this.down,
          lO = {
            x: eO.x - (bK.y * eO.z - bK.z * eO.y),
            y: eO.y - (bK.z * eO.x - bK.x * eO.z),
            z: eO.z - (bK.x * eO.y - bK.y * eO.x)
          },
          vK = 0 === aK(XO) ? 0 : Math.min(1, pO / .25);
        var CO, hO;
        return this.down = LO((hO = vK, FO(CO = lO, oO(VO(XO, CO), hO)))), this.down
      }
      reset() {
        this.down = null
      }
    }
    class TO {
      constructor() {
        this.entries = [], this.windowSec = 0
      }
      apply(OO, KO, pO) {
        const XO = Math.hypot(OO, KO),
          bK = Math.max(0, Math.min(1, (XO - 2) / 2)),
          eO = {
            yaw: OO * (1 - bK),
            pitch: KO * (1 - bK),
            dtSec: pO
          };
        for (this.entries.push(eO), this.windowSec += pO; this.entries.length > 1 && this.windowSec - this.entries[0].dtSec >= .125;) this.windowSec -= this.entries[0].dtSec, this.entries.shift();
        let lO = 0,
          vK = 0;
        for (const hO of this.entries) lO += hO.yaw * hO.dtSec, vK += hO.pitch * hO.dtSec;
        const CO = this.windowSec > 0 ? {
          yaw: lO / this.windowSec,
          pitch: vK / this.windowSec
        } : {
          yaw: eO.yaw,
          pitch: eO.pitch
        };
        return {
          yaw: OO * bK + CO.yaw,
          pitch: KO * bK + CO.pitch
        }
      }
      reset() {
        this.entries = [], this.windowSec = 0
      }
    }
    class NO {
      constructor() {
        this.calibrator = new fO, this.gravity = new dO, this.smoother = new TO
      }
      process(OO, KO, pO) {
        const XO = Math.max(0, Math.min(.05, KO));
        this.calibrator.update({
          ...OO,
          dtSec: XO
        });
        const bK = this.calibrator.correct(OO.gyro);
        let eO = bK.y;
        "player" === pO && OO.accel && (eO = ((OO, KO) => {
          const pO = OO.y * KO.y + OO.z * KO.z;
          return -Math.sign(pO) * Math.min(1.41 * Math.abs(pO), Math.hypot(OO.y, OO.z))
        })(bK, this.gravity.update(bK, OO.accel, XO)));
        const lO = this.smoother.apply(eO, bK.x, XO),
          vK = ((OO, KO) => {
            const pO = Math.hypot(OO, KO);
            if (pO >= 1) return {
              yaw: OO,
              pitch: KO
            };
            const XO = pO / 1;
            return {
              yaw: OO * XO,
              pitch: KO * XO
            }
          })(lO.yaw, lO.pitch);
        return {
          yawDeg: vK.yaw * XO,
          pitchDeg: vK.pitch * XO
        }
      }
      getCalibration() {
        return {
          calibrated: this.calibrator.isCalibrated(),
          bias: this.calibrator.getBias()
        }
      }
      reset() {
        this.calibrator.reset(), this.gravity.reset(), this.smoother.reset()
      }
    }
    const IO = (OO, KO) => {
      var pO, XO, bK;
      const eO = KO * MO,
        lO = null !== (pO = OO.beta) && void 0 !== pO ? pO : 0,
        vK = null !== (XO = OO.gamma) && void 0 !== XO ? XO : 0;
      return {
        x: lO * Math.cos(eO) - vK * Math.sin(eO),
        y: lO * Math.sin(eO) + vK * Math.cos(eO),
        z: null !== (bK = OO.alpha) && void 0 !== bK ? bK : 0
      }
    };
    var yK = pO(7937);
    class gK {
      constructor(OO, KO, pO) {
        this.hid = OO, this.sink = KO, this.onControllersChanged = pO, this.controllers = new Map, this.running = !1, this.openedCount = 0, this.opening = new Set, this.disconnectedWhileOpening = new Set, this.switchPacketCounter = 0, this.onConnect = OO => {
          this.openController(OO.device).catch((OO => {
            console.warn("Could not open motion controller", OO)
          }))
        }, this.onDisconnect = OO => {
          this.opening.has(OO.device) && this.disconnectedWhileOpening.add(OO.device);
          const KO = this.controllers.get(OO.device);
          KO && (this.forget(KO), this.onControllersChanged())
        }
      }
      async start() {
        if (this.running) return;
        this.running = !0, this.hid.addEventListener("connect", this.onConnect), this.hid.addEventListener("disconnect", this.onDisconnect);
        const OO = await this.hid.getDevices();
        for (const KO of OO) await this.openController(KO).catch((OO => {
          console.warn("Could not open motion controller", OO)
        }))
      }
      stop() {
        this.running = !1, this.hid.removeEventListener("connect", this.onConnect), this.hid.removeEventListener("disconnect", this.onDisconnect);
        for (const OO of [...this.controllers.values()]) this.forget(OO);
        this.onControllersChanged()
      }
      async request() {
        const OO = await this.hid.requestDevice({
          filters: yK.h
        });
        let KO = 0;
        for (const pO of OO) await this.openController(pO).catch((OO => {
          console.warn("Could not open motion controller", OO), KO++
        }));
        return KO
      }
      async hasGrantedController() {
        return (await this.hid.getDevices()).some((OO => null !== (0, yK.c)(OO.vendorId, OO.productId)))
      }
      getConnectedKinds() {
        return [...this.controllers.values()].map((OO => OO.kind))
      }
      forget(OO) {
        OO.device.removeEventListener("inputreport", OO.onReport), this.controllers.get(OO.device) === OO && this.controllers.delete(OO.device)
      }
      async openController(OO) {
        const KO = (0, yK.c)(OO.vendorId, OO.productId);
        if (!KO || !this.running || this.controllers.has(OO) || this.opening.has(OO)) return;
        this.opening.add(OO);
        let pO = !1;
        try {
          OO.opened || await OO.open()
        } finally {
          this.opening.delete(OO), pO = this.disconnectedWhileOpening.delete(OO)
        }
        if (pO) return void OO.close().catch((OO => {
          console.debug("Could not close an unplugged motion controller", OO)
        }));
        if (!this.running) return;
        const XO = {
          device: OO,
          kind: KO,
          lastClock: null,
          lastEventMs: null,
          lastReadingMs: -1 / 0,
          openedOrder: this.openedCount++,
          onReport: OO => {
            this.onReport(XO, OO)
          }
        };
        this.controllers.set(OO, XO), OO.addEventListener("inputreport", XO.onReport), this.onControllersChanged();
        try {
          await this.enableMotion(XO)
        } catch (bK) {
          console.warn(`Could not turn on motion for ${KO}`, bK), this.controllers.get(OO) === XO && (this.forget(XO), this.onControllersChanged())
        }
      }
      async enableMotion(OO) {
        let {
          device: KO,
          kind: pO
        } = OO;
        if ((0, yK.f)(pO))
          for (const XO of yK.x[pO]) await KO.receiveFeatureReport(XO).catch((OO => {
            console.debug(`Motion controller feature report ${XO} unavailable`, OO)
          }));
        else
          for (let XO = 0; XO < 2; XO++)
            for (const {
                subcommand: OO,
                args: pO
              }
              of yK.y) await KO.sendReport(yK.B, (0, yK.b)(this.switchPacketCounter++, OO, pO)), await new Promise((OO => {
              setTimeout(OO, 60)
            }))
      }
      onReport(OO, KO) {
        const pO = (0, yK.r)(OO.kind, KO.reportId, KO.data, OO.device.productId);
        if (!pO) return;
        const XO = null === OO.lastEventMs ? 0 : (KO.timeStamp - OO.lastEventMs) / 1e3;
        OO.lastEventMs = KO.timeStamp;
        let bK = pO.dtSec;
        if (null !== bK && XO > 0 && (bK = Math.max(.001, Math.min(.017, XO / pO.readings.length))), null === bK && null !== pO.sensorClock && (0, yK.f)(OO.kind)) {
          const KO = (0, yK.v)(OO.kind, OO.lastClock, pO.sensorClock);
          OO.lastClock = pO.sensorClock, bK = 0 === KO ? null : KO
        }
        if (OO.lastReadingMs = KO.timeStamp, this.isPreferred(OO, KO.timeStamp))
          for (const lO of pO.readings) {
            var eO;
            this.sink(lO, null !== (eO = bK) && void 0 !== eO ? eO : XO, `hid${OO.openedOrder}`)
          }
      }
      isPreferred(OO, KO) {
        const pO = OO => 1e6 * yK.o[OO.kind] + OO.openedOrder;
        for (const XO of this.controllers.values())
          if (XO !== OO && KO - XO.lastReadingMs < 500 && pO(XO) < pO(OO)) return !1;
        return !0
      }
    }
    var uO = pO(94);
    const EO = () => DeviceMotionEvent,
      jK = () => "undefined" !== typeof window && "undefined" !== typeof DeviceMotionEvent && window.isSecureContext && (0, uO.isMobile)(),
      YO = () => {
        var OO;
        const KO = null === (OO = window.screen.orientation) || void 0 === OO ? void 0 : OO.angle;
        return "number" === typeof KO ? KO : "number" === typeof window.orientation ? window.orientation : 0
      };
    class wO {
      constructor(OO, KO) {
        this.sink = OO, this.onStateChanged = KO, this.state = "off", this.lastEventMs = null, this.noSensorTimer = null, this.wanted = !1, this.permissionRequest = null, this.granted = !1, this.onGesture = () => {
          this.requestPermission().catch((OO => {
            console.warn("Could not enable the motion sensor", OO)
          }))
        }, this.onMotion = OO => {
          const KO = OO.rotationRate;
          if (!KO || null === KO.alpha && null === KO.beta && null === KO.gamma) return;
          const pO = null === this.lastEventMs ? 0 : (OO.timeStamp - this.lastEventMs) / 1e3;
          this.lastEventMs = OO.timeStamp, this.clearNoSensorTimer(), this.setState("on"), this.sink({
            gyro: IO(KO, YO()),
            accel: null
          }, pO, "phone")
        }
      }
      getState() {
        return this.state
      }
      start() {
        if (this.wanted = !0, "off" === this.state) return "function" !== typeof EO().requestPermission || this.granted ? void this.listen() : (this.setState("needsPermission"), void this.armGestureRequest())
      }
      requestPermission() {
        return this.permissionRequest || (this.permissionRequest = this.askPermission().finally((() => {
          this.permissionRequest = null
        }))), this.permissionRequest
      }
      async askPermission() {
        const OO = EO().requestPermission;
        if (!this.wanted) return;
        if ("function" !== typeof OO) return void this.listen();
        let KO;
        this.disarmGestureRequest();
        try {
          KO = await OO.call(DeviceMotionEvent)
        } catch (pO) {
          throw this.wanted && "needsPermission" === this.state && this.armGestureRequest(), pO
        }
        this.wanted && ("granted" === KO ? (this.granted = !0, this.listen()) : this.setState("denied"))
      }
      stop() {
        this.wanted = !1, this.disarmGestureRequest(), window.removeEventListener("devicemotion", this.onMotion), this.clearNoSensorTimer(), this.lastEventMs = null, this.setState("off")
      }
      armGestureRequest() {
        window.addEventListener("touchend", this.onGesture), window.addEventListener("click", this.onGesture)
      }
      disarmGestureRequest() {
        window.removeEventListener("touchend", this.onGesture), window.removeEventListener("click", this.onGesture)
      }
      listen() {
        this.disarmGestureRequest(), window.removeEventListener("devicemotion", this.onMotion), window.addEventListener("devicemotion", this.onMotion), this.setState("waiting"), this.clearNoSensorTimer(), this.noSensorTimer = setTimeout((() => {
          this.noSensorTimer = null, "waiting" === this.state && this.setState("noSensor")
        }), 3e3)
      }
      clearNoSensorTimer() {
        null !== this.noSensorTimer && (clearTimeout(this.noSensorTimer), this.noSensorTimer = null)
      }
      setState(OO) {
        this.state !== OO && (this.state = OO, this.onStateChanged())
      }
    }
    const iK = "controllerGyroStatusChanged",
      rK = {
        wKO: 0,
        ipO: 0
      },
      PO = OO => {
        var KO, pO;
        return "undefined" === typeof document || (null === (KO = null === (pO = document.featurePolicy) || void 0 === pO ? void 0 : pO.allowsFeature(OO)) || void 0 === KO || KO)
      };
    class mK {
      constructor() {
        this.processor = new NO, this.hid = void 0, this.hidBlocked = void 0, this.phone = void 0, this.phoneBlocked = void 0, this.source = null, this.pendingYawDeg = 0, this.pendingPitchDeg = 0, this.lastDrainMs = -1 / 0, this.lastHidReadingMs = -1 / 0, this.running = !1, this.phoneRunning = !1, this.syncWithSettings = OO => {
          const KO = OO.gyroAiming && vK.g.hasConnectedPad();
          var pO, XO;
          KO !== this.phoneRunning && (this.phoneRunning = KO, KO ? null === (pO = this.phone) || void 0 === pO || pO.start() : null === (XO = this.phone) || void 0 === XO || XO.stop());
          if (OO.gyroAiming !== this.running) {
            var bK, eO;
            if (this.running = OO.gyroAiming, this.running) null === (bK = this.hid) || void 0 === bK || bK.start().catch((OO => {
              console.warn("Could not open motion controllers", OO)
            }));
            else null === (eO = this.hid) || void 0 === eO || eO.stop(), this.processor.reset(), this.source = null, this.discardPending();
            this.publishStatus()
          }
        }, this.publishStatus = () => {
          bK.i.pl(iK, this.getStatus())
        };
        const OO = (() => {
            var OO;
            return "undefined" !== typeof navigator && window.isSecureContext && null !== (OO = navigator.hid) && void 0 !== OO ? OO : null
          })(),
          KO = PO("hid");
        this.hidBlocked = null !== OO && !KO, this.hid = OO && KO ? new gK(OO, ((OO, KO, pO) => {
          this.lastHidReadingMs = performance.now(), this.feed(OO, KO, "player", pO)
        }), this.publishStatus) : null;
        const pO = PO("accelerometer") && PO("gyroscope");
        this.phoneBlocked = jK() && !pO, this.phone = jK() && pO ? new wO(((OO, KO, pO) => {
          performance.now() - this.lastHidReadingMs >= 500 && this.feed(OO, KO, "local", pO)
        }), this.publishStatus) : null, bK.i.subscribe(hO.f, this.syncWithSettings), vK.g.onConnectedPadsChanged((() => {
          this.syncWithSettings((0, hO.i)()), this.publishStatus()
        })), this.syncWithSettings((0, hO.i)())
      }
      isSupported() {
        return null !== this.hid || null !== this.phone
      }
      getStatus() {
        var OO, KO, pO, XO;
        return {
          hidSupported: null !== this.hid,
          hidBlocked: this.hidBlocked,
          phoneSupported: null !== this.phone,
          phoneBlocked: this.phoneBlocked,
          controllers: null !== (OO = null === (KO = this.hid) || void 0 === KO ? void 0 : KO.getConnectedKinds()) && void 0 !== OO ? OO : [],
          phoneMotion: null !== (pO = null === (XO = this.phone) || void 0 === XO ? void 0 : XO.getState()) && void 0 !== pO ? pO : "off",
          padConnected: vK.g.hasConnectedPad()
        }
      }
      async connectController() {
        return this.hid ? this.hid.request() : 0
      }
      async connectControllerIfNoneGranted() {
        this.hid && !await this.hid.hasGrantedController() && await this.hid.request()
      }
      async allowPhoneMotion() {
        var OO;
        await (null === (OO = this.phone) || void 0 === OO ? void 0 : OO.requestPermission())
      }
      drainLookDelta() {
        const OO = performance.now();
        OO - this.lastDrainMs > 500 && this.discardPending(), this.lastDrainMs = OO;
        const KO = {
          yawDeg: this.pendingYawDeg,
          pitchDeg: this.pendingPitchDeg
        };
        this.pendingYawDeg = 0, this.pendingPitchDeg = 0;
        const pO = (0, hO.i)();
        return pO.gyroAiming && (OO => {
          let {
            activation: KO,
            isHeld: pO,
            useButton: XO,
            gyroButton: bK
          } = OO;
          return "always" === KO || pO("aiming" === KO ? XO : bK)
        })({
          activation: pO.gyroActivation,
          isHeld: OO => CO.c.isButtonHeld(OO),
          useButton: (0, lO.j)("use"),
          gyroButton: pO.gyroButton
        }) ? ((OO, KO) => ({
          wKO: -OO.yawDeg * KO * MO,
          ipO: -OO.pitchDeg * KO * MO
        }))(KO, pO.gyroSensitivity) : rK
      }
      discardPending() {
        this.pendingYawDeg = 0, this.pendingPitchDeg = 0
      }
      injectMotion(OO, KO) {
        this.feed(OO, KO, "local", "injected")
      }
      getCalibration() {
        return this.processor.getCalibration()
      }
      feed(OO, KO, pO, XO) {
        this.source !== XO && (this.processor.reset(), this.source = XO);
        const bK = this.processor.process(OO, KO, pO);
        this.pendingYawDeg += bK.yawDeg, this.pendingPitchDeg += bK.pitchDeg
      }
    }
    let sO = null;
    const HO = () => (sO || (sO = new mK), sO),
      RO = () => {
        const [OO, KO] = (0, XO.useState)((() => HO().getStatus()));
        return (0, eO.f)(iK, KO), (0, XO.useEffect)((() => {
          KO(HO().getStatus())
        }), []), OO
      }
  },
  7937: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => AO,
      b: () => dO,
      c: () => CO,
      f: () => XO,
      h: () => vK,
      k: () => hO,
      o: () => DO,
      r: () => zK,
      v: () => LO,
      x: () => NO,
      y: () => TO
    });
    const XO = OO => "dualShock4" === OO || "dualSense" === OO,
      bK = 1356,
      eO = 1406,
      lO = [{
        vendorId: bK,
        productId: 1476,
        kind: "dualShock4"
      }, {
        vendorId: bK,
        productId: 2508,
        kind: "dualShock4"
      }, {
        vendorId: bK,
        productId: 2976,
        kind: "dualShock4"
      }, {
        vendorId: bK,
        productId: 3302,
        kind: "dualSense"
      }, {
        vendorId: bK,
        productId: 3570,
        kind: "dualSense"
      }, {
        vendorId: eO,
        productId: 8201,
        kind: "switchPro"
      }, {
        vendorId: eO,
        productId: 8198,
        kind: "joyConLeft"
      }, {
        vendorId: eO,
        productId: 8199,
        kind: "joyConRight"
      }],
      vK = lO.map((OO => {
        let {
          vendorId: KO,
          productId: pO
        } = OO;
        return {
          vendorId: KO,
          productId: pO
        }
      })),
      CO = (OO, KO) => {
        var pO, XO;
        return null !== (pO = null === (XO = lO.find((pO => pO.vendorId === OO && pO.productId === KO))) || void 0 === XO ? void 0 : XO.kind) && void 0 !== pO ? pO : null
      },
      hO = {
        dualShock4: "DualShock 4",
        dualSense: "DualSense",
        switchPro: "Switch Pro Controller",
        joyConLeft: "Joy-Con (L)",
        joyConRight: "Joy-Con (R)"
      },
      DO = {
        dualSense: 0,
        dualShock4: 0,
        switchPro: 0,
        joyConRight: 1,
        joyConLeft: 2
      },
      MO = 2e3 / 32767,
      aK = 1 / 8192,
      oO = 936 / 13371,
      FO = (OO, KO, pO) => ({
        x: OO.getInt16(KO, !0) * pO,
        y: OO.getInt16(KO + 2, !0) * pO,
        z: OO.getInt16(KO + 4, !0) * pO
      }),
      VO = OO => 0 === OO.x && 0 === OO.y && 0 === OO.z,
      LO = (OO, KO, pO) => null === KO ? null : "dualShock4" === OO ? 16 * (pO - KO & 65535) / 3 / 1e6 : (pO - KO >>> 0) / 3 / 1e6,
      QO = (OO, KO) => "joyConRight" === KO ? {
        x: OO.y,
        y: -OO.z,
        z: -OO.x
      } : {
        x: -OO.y,
        y: OO.z,
        z: -OO.x
      },
      zK = (OO, KO, pO, bK) => XO(OO) ? ((OO, KO, pO, XO) => {
        const bK = ((OO, KO, pO) => "dualShock4" === OO ? 1 === KO && pO >= 63 ? 0 : 17 === KO && pO >= 65 ? 2 : null : 1 === KO && pO >= 62 ? 0 : 49 === KO && pO >= 63 ? 1 : null)(OO, KO, pO.byteLength);
        if (null === bK) return null;
        if (2976 === XO && 1 === KO && 0 !== (4 & pO.getUint8(30))) return null;
        const eO = bK + ("dualShock4" === OO ? 12 : 15),
          lO = FO(pO, eO, MO),
          vK = FO(pO, eO + 6, aK);
        return VO(lO) && VO(vK) ? null : {
          readings: [{
            gyro: lO,
            accel: vK
          }],
          dtSec: null,
          sensorClock: "dualShock4" === OO ? pO.getUint16(bK + 9, !0) : pO.getUint32(bK + 27, !0)
        }
      })(OO, KO, pO, bK) : ((OO, KO, pO) => {
        if (48 !== KO && 49 !== KO || pO.byteLength < 48) return null;
        const XO = [];
        for (let bK = 0; bK < 3; bK++) {
          const KO = FO(pO, 12 + 12 * bK, 244e-6),
            eO = FO(pO, 18 + 12 * bK, oO);
          if (VO(eO) && VO(KO)) return null;
          XO.push({
            gyro: QO(eO, OO),
            accel: QO(KO, OO)
          })
        }
        return {
          readings: XO,
          dtSec: .005,
          sensorClock: null
        }
      })(OO, KO, pO),
      AO = 1,
      fO = [0, 1, 64, 64, 0, 1, 64, 64],
      dO = (OO, KO, pO) => new Uint8Array([15 & OO, ...fO, KO, ...pO]),
      TO = [{
        subcommand: 64,
        args: [1]
      }, {
        subcommand: 3,
        args: [48]
      }],
      NO = {
        dualShock4: [2, 5],
        dualSense: [5]
      }
  },
  7299: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => EO,
      h: () => mK,
      k: () => QO,
      o: () => oO.h,
      r: () => wO,
      s: () => YO,
      w: () => zK,
      z: () => iK,
      B: () => oO.m,
      C: () => oO.p,
      E: () => sO,
      H: () => oO.t,
      K: () => IO
    });
    var XO = pO(63),
      bK = pO(22),
      eO = pO(26),
      lO = pO(1263),
      vK = pO(1136),
      CO = pO(7275),
      hO = pO(7307),
      DO = pO(7260),
      MO = pO(7252),
      aK = pO(7310),
      oO = pO(1225),
      FO = pO(7255),
      VO = pO(7746);
    class LO {
      constructor() {
        this.travelled = 0, this.lastMoveMs = -1 / 0
      }
      add(OO, KO, pO) {
        return pO - this.lastMoveMs > 250 && (this.travelled = 0), this.lastMoveMs = pO, this.travelled += Math.hypot(OO, KO), this.travelled >= 12
      }
      reset() {
        this.travelled = 0, this.lastMoveMs = -1 / 0
      }
    }
    const QO = OO => !OO.repeat && !(0, VO.e)(OO.key),
      zK = "PadHidesCursor";
    let AO = !1;
    const fO = OO => {
        OO !== AO && (AO = OO, document.documentElement.classList.toggle(zK, OO))
      },
      dO = new class {
        constructor() {
          this.buttonsDown = [], this.stickAnchors = [null, null], this.lastActivityMs = -1 / 0, this.onlyMovedOn = !1
        }
        observe(OO) {
          let KO = !1,
            pO = !1;
          OO.values.forEach(((OO, XO) => {
            const bK = OO >= (this.buttonsDown[XO] ? FO.V : FO.T);
            bK && !this.buttonsDown[XO] && (KO = !0, pO = !0), this.buttonsDown[XO] = bK
          }));
          return [OO.leftStick, OO.rightStick].forEach(((OO, XO) => {
            const bK = this.stickAnchors[XO];
            Math.hypot(OO.x, OO.y) < (bK ? FO.V : .3) ? this.stickAnchors[XO] = null : (!bK || Math.hypot(OO.x - bK.x, OO.y - bK.y) >= .3) && (this.stickAnchors[XO] = {
              x: OO.x,
              y: OO.y
            }, KO = !0, pO ||= !bK)
          })), KO && (this.lastActivityMs = OO.timestampMs), this.onlyMovedOn = KO && !pO, KO
        }
        wasOnlyMoveOn() {
          return this.onlyMovedOn
        }
        isHolding(OO) {
          return !(OO - this.lastActivityMs >= 1e3) && (this.buttonsDown.some((OO => OO)) || this.stickAnchors.some((OO => null !== OO)))
        }
        isStickOffRest() {
          return this.stickAnchors.some((OO => null !== OO))
        }
        reset() {
          this.buttonsDown = [], this.stickAnchors = [null, null], this.lastActivityMs = -1 / 0, this.onlyMovedOn = !1
        }
      };
    let TO = null,
      NO = !1;
    const IO = () => NO;
    let yK = null,
      gK = !1,
      uO = null;
    const EO = () => uO;
    let jK = !1;
    const YO = OO => {
        if (!dO.observe(OO)) return !1;
        if (jK && dO.wasOnlyMoveOn() && !(0, oO.h)()) return !1;
        jK = !1, NO = !1;
        const KO = !(0, oO.h)();
        return KO && (TO = OO, uO = !AO && gK && yK ? {
          ...yK
        } : null), gK = !1, (0, oO.m)("gamepad"), fO(!0), (0, aK.k)((0, CO.l)()), KO
      },
      wO = OO => !(0, oO.h)() || OO === TO,
      iK = () => {
        dO.reset()
      },
      rK = () => {
        const OO = bK.d.get("activeInputDevice"),
          KO = "gamepad" === OO ? MO.g.getActivePad() : null;
        return {
          device: OO,
          inGame: (0, vK.l)(),
          padMovesMouse: null !== KO && (0, DO.i)(KO.id)
        }
      },
      PO = OO => {
        document.pointerLockElement ? yK = null : (yK ??= {
          x: 0,
          y: 0
        }, yK.x = OO.clientX, yK.y = OO.clientY)
      },
      mK = () => {
        const OO = new LO,
          KO = KO => {
            OO.reset(), jK = !1, (0, oO.m)(KO)
          },
          pO = OO => {
            if (OO.isTrusted) {
              if (OO instanceof KeyboardEvent) {
                if ((0, oO.l)(OO), !QO(OO)) return;
                NO = !0
              }
              if (OO instanceof PointerEvent && "touch" === OO.pointerType) return yK = null, void KO("touch");
              OO instanceof PointerEvent && (PO(OO), gK = !0), ("pointerdown" !== OO.type || (OO => {
                let {
                  device: KO,
                  inGame: pO,
                  padMovesMouse: XO
                } = OO;
                return !("gamepad" === KO && XO && pO)
              })(rK())) && KO("keyboardMouse")
            }
          },
          XO = OO => {
            OO.isTrusted && (yK = null, KO("touch"))
          },
          lO = OO => {
            OO.isTrusted && "touch" !== OO.pointerType && !OO.relatedTarget && (yK = null)
          },
          vK = pO => {
            if (!pO.isTrusted || "touch" === pO.pointerType) return;
            PO(pO);
            const XO = pO.movementX || 0,
              eO = pO.movementY || 0;
            if (0 === XO && 0 === eO) return;
            if (gK = !0, fO(!1), "keyboardMouse" === bK.d.get("activeInputDevice")) return;
            const lO = dO.isHolding(pO.timeStamp),
              vK = rK(),
              CO = (OO => {
                let {
                  device: KO,
                  inGame: pO,
                  padMovesMouse: XO,
                  padHolding: bK
                } = OO;
                return ("gamepad" !== KO || !XO) && "keyboardMouse" !== KO && (pO || !bK)
              })({
                ...vK,
                inGame: vK.inGame && (0, hO.g)(),
                padHolding: lO
              });
            CO && OO.add(XO, eO, pO.timeStamp) && (KO("keyboardMouse"), jK = dO.isStickOffRest())
          },
          CO = OO => {
            fO("gamepad" === OO)
          },
          DO = {
            capture: !0,
            passive: !0
          };
        window.addEventListener("keydown", pO, DO), window.addEventListener("pointerdown", pO, DO), window.addEventListener("wheel", pO, DO), window.addEventListener("touchstart", XO, DO), window.addEventListener("pointermove", vK, DO), window.addEventListener("pointerout", lO, DO);
        const MO = eO.i.subscribe("appManagerUpdated|activeInputDevice", CO);
        return CO(bK.d.get("activeInputDevice")), () => {
          window.removeEventListener("keydown", pO, DO), window.removeEventListener("pointerdown", pO, DO), window.removeEventListener("wheel", pO, DO), window.removeEventListener("touchstart", XO, DO), window.removeEventListener("pointermove", vK, DO), window.removeEventListener("pointerout", lO, DO), yK = null, eO.i.unsubscribe(MO), fO(!1)
        }
      },
      sO = () => {
        const [OO, KO] = (0, XO.useState)(CO.l);
        return (0, lO.f)(CO.c, (() => {
          KO((0, CO.l)())
        })), (0, lO.f)(MO.c, (() => {
          KO((0, CO.l)())
        })), OO
      }
  },
  7281: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      g: () => bK
    });
    const XO = ["xbox", "playstation", "nintendo", "steamdeck", "generic"],
      bK = OO => XO.includes(OO)
  },
  7768: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      e: () => eO,
      g: () => CO,
      k: () => vK
    });
    var XO = pO(1263),
      bK = pO(1232);
    const eO = "controllerInventoryCursorChanged",
      lO = {
        showing: !1,
        kind: null,
        holding: !1,
        slotHasItem: !1,
        pressHints: null,
        hasCategories: !1,
        hasList: !1,
        openButtonCloses: !1,
        steppingSlots: !1,
        quickMoveToHotbar: !1,
        dropStackHold: null,
        hotbarPicking: !1
      },
      vK = () => {
        var OO, KO;
        return (0, XO.h)(eO, null !== (OO = null === (KO = (0, bK.g)()) || void 0 === KO ? void 0 : KO.getInventoryCursorState()) && void 0 !== OO ? OO : lO)
      },
      CO = () => {
        var OO, KO;
        return null !== (OO = null === (KO = (0, bK.g)()) || void 0 === KO ? void 0 : KO.isPadSteppingSlots()) && void 0 !== OO && OO
      }
  },
  7762: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => aK,
      e: () => vK,
      f: () => CO,
      g: () => lO,
      i: () => eO,
      m: () => DO,
      o: () => MO
    });
    let XO = null;
    const bK = new Set,
      eO = OO => (XO = OO, () => {
        if (XO === OO) {
          XO = null;
          for (const OO of bK) OO()
        }
      }),
      lO = OO => (bK.add(OO), () => {
        bK.delete(OO)
      }),
      vK = () => XO,
      CO = () => null !== XO;
    let hO = null;
    const DO = OO => {
        hO = OO
      },
      MO = () => {
        const OO = hO;
        return hO = null, OO
      },
      aK = (OO, KO) => {
        var pO, XO;
        return null !== (pO = null !== (XO = OO.find((OO => OO.element === KO))) && void 0 !== XO ? XO : OO.find((OO => OO.element.contains(KO)))) && void 0 !== pO ? pO : null
      }
  },
  7775: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      g: () => lO
    });
    var XO = pO(63);
    const bK = new WeakMap,
      eO = OO => {
        var KO, pO;
        return null !== (KO = null === (pO = bK.get(OO)) || void 0 === pO ? void 0 : pO.current) && void 0 !== KO ? KO : null
      },
      lO = (OO, KO) => {
        const pO = (0, XO.useRef)(KO);
        pO.current = KO;
        const eO = (0, XO.useRef)(null);
        (0, XO.useEffect)((() => {
          const KO = OO.current,
            XO = eO.current;
          KO !== XO && (XO && bK.get(XO) === pO && bK.delete(XO), eO.current = KO, KO && bK.set(KO, pO))
        })), (0, XO.useEffect)((() => () => {
          const OO = eO.current;
          OO && bK.get(OO) === pO && bK.delete(OO), eO.current = null
        }), [])
      }
  },
  7907: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      f: () => hO,
      g: () => MO,
      k: () => DO,
      l: () => CO,
      m: () => oO
    });
    var XO = pO(26),
      bK = pO(1621),
      eO = pO(1232),
      lO = pO(1225);
    const vK = OO => {
        var KO, pO;
        return (0, lO.h)() && null !== (KO = null === (pO = (0, eO.g)()) || void 0 === pO ? void 0 : pO.getGlyphForNoaAction(OO)) && void 0 !== KO ? KO : null
      },
      CO = "controllerGlyph:",
      hO = OO => {
        var KO, pO;
        return null !== (KO = null === (pO = (0, eO.g)()) || void 0 === pO ? void 0 : pO.getPadGlyphIconName(OO)) && void 0 !== KO ? KO : `${CO}xbox/${OO}`
      },
      DO = OO => OO.startsWith(CO),
      MO = OO => {
        var KO, pO;
        return DO(OO) && null !== (KO = null === (pO = (0, eO.g)()) || void 0 === pO ? void 0 : pO.getPadGlyphIconUrl(OO)) && void 0 !== KO ? KO : null
      },
      aK = ["customBindingsChanged", "appManagerUpdated|isTouchScreen", lO.d, bK.f, bK.b],
      oO = OO => {
        const KO = aK.map((KO => XO.i.subscribe(KO, OO)));
        return () => {
          for (const OO of KO) XO.i.unsubscribe(OO)
        }
      }
  },
  7757: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => XO
    });
    const XO = "controllerOpenKeyboard",
      bK = "controllerKeyboardVisible"
  },
  7307: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => hO,
      g: () => DO,
      j: () => CO,
      k: () => vK
    });
    var XO = pO(22),
      bK = pO(1441),
      eO = pO(1483);
    const lO = new Map,
      vK = (OO, KO) => (lO.has(OO) && console.warn(`Gameplay blocker "${OO}" registered twice; the newer one replaces it.`), lO.set(OO, KO), () => {
        lO.get(OO) === KO && lO.delete(OO)
      }),
      CO = () => (0, eO.d)(document.activeElement),
      hO = function() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        for (const [KO, pO] of lO)
          if (!OO.includes(KO) && pO()) return KO;
        return null
      },
      DO = function() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return "inGame" === XO.d.get("gameState") && (!(0, bK.i)() && (!CO() && null === hO(OO)))
      }
  },
  7255: (OO, KO, pO) => {
    pO.d(KO, {
      $: () => XO,
      D: () => jK,
      H: () => fO,
      J: () => QO,
      N: () => LO,
      R: () => hO,
      T: () => aK,
      V: () => oO,
      Y: () => bK,
      b: () => wO,
      bb: () => TO,
      d: () => EO,
      eb: () => uO,
      f: () => DO,
      g: () => CO,
      ib: () => YO,
      k: () => vK,
      m: () => IO,
      mb: () => dO,
      p: () => zK,
      s: () => NO,
      w: () => eO,
      x: () => MO,
      z: () => AO
    });
    const XO = ["A", "B", "X", "Y", "LB", "RB", "LT", "RT", "View", "Menu", "LS", "RS", "Up", "Down", "Left", "Right", "Home"],
      bK = XO.length,
      eO = function() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return {
          values: new Array(bK).fill(0),
          leftStick: {
            x: 0,
            y: 0
          },
          rightStick: {
            x: 0,
            y: 0
          },
          timestampMs: OO
        }
      },
      lO = Object.fromEntries(XO.map(((OO, KO) => [OO, KO]))),
      vK = OO => lO[OO],
      CO = function(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : .95;
        const XO = Math.hypot(OO.x, OO.y);
        if (XO <= KO) return {
          x: 0,
          y: 0
        };
        const bK = Math.min(1, (XO - KO) / Math.max(1e-4, pO - KO));
        return {
          x: OO.x / XO * bK,
          y: OO.y / XO * bK
        }
      },
      hO = ["exponential", "linear", "boost"],
      DO = (OO, KO) => {
        const pO = Math.hypot(OO.x, OO.y);
        if (0 === pO) return {
          x: 0,
          y: 0
        };
        const XO = ((OO, KO) => {
          const pO = Math.max(0, Math.min(1, OO));
          return "linear" === KO ? pO : pO * pO
        })(pO, KO);
        return {
          x: OO.x / pO * XO,
          y: OO.y / pO * XO
        }
      },
      MO = .5,
      aK = .3,
      oO = .2,
      FO = vK("LT"),
      VO = vK("RT"),
      LO = OO => OO === FO || OO === VO,
      QO = (OO, KO) => {
        const pO = vK(KO);
        return LO(pO) ? OO[pO] > .35 : OO[pO] >= MO
      },
      zK = (OO, KO) => OO.map(((OO, pO) => LO(pO) ? KO[pO] ? OO > .35 : OO >= .55 : OO >= MO)),
      AO = ["Up", "Down", "Left", "Right"],
      fO = OO => AO.includes(OO),
      dO = function(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : .5;
        return Math.hypot(OO.x, OO.y) < KO ? null : Math.abs(OO.x) > Math.abs(OO.y) ? OO.x > 0 ? "Right" : "Left" : OO.y > 0 ? "Down" : "Up"
      },
      TO = {
        initialDelayMs: 350,
        intervalMs: 120
      },
      NO = {
        initialDelayMs: 350,
        intervalMs: 150
      },
      IO = ["default", "slow", "off"],
      yK = 800,
      gK = 250,
      uO = (OO, KO) => "off" === KO ? null : "slow" === KO ? {
        initialDelayMs: Math.max(OO.initialDelayMs, yK),
        intervalMs: Math.max(OO.intervalMs, gK)
      } : OO;
    class EO {
      constructor(OO) {
        this.readTiming = OO, this.JK = !1, this.timing = null, this.nextFireMs = 0
      }
      update(OO, KO) {
        return OO ? this.JK ? !!(this.timing && KO >= this.nextFireMs) && (this.nextFireMs = KO + this.timing.intervalMs, !0) : (this.JK = !0, this.timing = this.readTiming(), this.nextFireMs = KO + (null !== (pO = null === (XO = this.timing) || void 0 === XO ? void 0 : XO.initialDelayMs) && void 0 !== pO ? pO : 0), !0) : (this.JK = !1, !1);
        var pO, XO
      }
      reset() {
        this.JK = !1
      }
    }
    const jK = {
        initialDelayMs: 350,
        intervalMs: 80
      },
      YO = {
        initialDelayMs: 400,
        intervalMs: 90
      };
    class wO {
      constructor(OO) {
        this.timer = OO, this.direction = null
      }
      update(OO, KO) {
        return OO !== this.direction && (this.timer.reset(), this.direction = OO), this.timer.update(null !== OO, KO) ? OO : null
      }
      reset() {
        this.timer.reset(), this.direction = null
      }
    }
  },
  7838: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      f: () => eO
    });
    let XO = -1 / 0;
    const bK = () => {
        XO = performance.now()
      },
      eO = OO => performance.now() - XO < OO
  },
  7748: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO,
      c: () => eO
    });
    var XO = pO(7275),
      bK = pO(7255);
    const eO = OO => (0, bK.eb)(OO, (0, XO.i)().buttonRepeat),
      lO = OO => new bK.d((() => eO(OO)))
  },
  7289: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO,
      c: () => eO,
      d: () => vK
    });
    var XO = pO(26),
      bK = pO(7275);
    const eO = (OO, KO) => "OpenShop" === OO ? "shop" === KO : "OpenLobbyLeaderboard" !== OO || "leaderboard" === KO;
    let lO = !1;
    const vK = OO => {
        OO !== lO && (lO = OO, XO.i.pl(bK.c, (0, bK.i)()))
      },
      CO = () => ((OO, KO) => "shop" === OO && KO ? "shop" : "leaderboard")((0, bK.i)().leaderboardButton, lO)
  },
  7284: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => dO,
      C: () => aK,
      G: () => oO,
      I: () => MO,
      J: () => fO,
      K: () => hO,
      M: () => QO,
      O: () => gK,
      R: () => AO,
      T: () => VO,
      X: () => LO,
      _: () => FO,
      b: () => rK,
      bb: () => zK,
      c: () => mK,
      cb: () => YO,
      e: () => uO,
      f: () => lO,
      fb: () => eO,
      j: () => yK,
      jb: () => TO,
      m: () => NO,
      nb: () => PO,
      o: () => wO,
      ob: () => IO,
      r: () => iK,
      t: () => DO,
      w: () => CO,
      z: () => vK
    });
    var XO = pO(7272),
      bK = pO(7255);
    const eO = {
        min: 25,
        max: 500,
        step: 5
      },
      lO = {
        min: 25,
        max: 100,
        step: 5
      },
      vK = {
        min: 0,
        max: .4,
        step: .01
      },
      CO = {
        min: 25,
        max: 300,
        step: 5
      },
      hO = {
        min: .5,
        max: 6,
        step: .1
      },
      DO = (OO, KO) => {
        if (!Number.isFinite(OO)) return KO.min;
        const pO = KO.min + Math.round((OO - KO.min) / KO.step) * KO.step,
          XO = Math.min(KO.max, Math.max(KO.min, pO));
        return Math.round(1e3 * XO) / 1e3
      },
      MO = OO => `${Math.round(OO)}%`,
      aK = OO => MO(100 * OO),
      oO = OO => `${OO.toFixed(1)}\xd7`,
      FO = [{
        value: "auto",
        labelKey: "controller:settingsPromptAuto"
      }, {
        value: "xbox",
        labelKey: "controller:settingsPromptXbox"
      }, {
        value: "playstation",
        labelKey: "controller:settingsPromptPlayStation"
      }, {
        value: "nintendo",
        labelKey: "controller:settingsPromptNintendo"
      }, {
        value: "steamdeck",
        labelKey: "controller:settingsPromptSteamDeck"
      }, {
        value: "generic",
        labelKey: "controller:settingsPromptGeneric"
      }],
      VO = [{
        value: "exponential",
        labelKey: "controller:settingsCurveExponential"
      }, {
        value: "linear",
        labelKey: "controller:settingsCurveLinear"
      }, {
        value: "boost",
        labelKey: "controller:settingsCurveBoost"
      }],
      LO = [{
        value: "hybrid",
        labelKey: "controller:settingsNavHybrid"
      }, {
        value: "focus",
        labelKey: "controller:settingsMenuNavFocus"
      }, {
        value: "cursor",
        labelKey: "controller:settingsVirtualCursor"
      }],
      QO = [{
        value: "hybrid",
        labelKey: "controller:settingsNavHybrid"
      }, {
        value: "slot",
        labelKey: "controller:settingsInventoryNavSlot"
      }, {
        value: "cursor",
        labelKey: "controller:settingsVirtualCursor"
      }],
      zK = [{
        value: "wheel",
        labelKey: "controller:settingsQuickChatWheel"
      }, {
        value: "off",
        labelKey: "controller:settingsQuickChatOff"
      }],
      AO = [{
        value: "shop",
        labelKey: "controller:settingsLeaderboardButtonShop"
      }, {
        value: "leaderboard",
        labelKey: "controller:settingsLeaderboardButtonLeaderboard"
      }],
      fO = [{
        value: "always",
        labelKey: "controller:settingsGyroAlways"
      }, {
        value: "aiming",
        labelKey: "controller:settingsGyroWhileAiming"
      }, {
        value: "button",
        labelKey: "controller:settingsGyroWhileButton"
      }],
      dO = [{
        value: "tapHold",
        labelKey: "controller:settingsEmoteButtonTapHold"
      }, {
        value: "wheel",
        labelKey: "controller:settingsEmoteButtonWheel"
      }],
      TO = [{
        value: "toggle",
        labelKey: "controller:settingsSneakToggle"
      }, {
        value: "hold",
        labelKey: "controller:settingsSneakHold"
      }],
      NO = [{
        value: "default",
        labelKey: "controller:settingsButtonRepeatDefault"
      }, {
        value: "slow",
        labelKey: "controller:settingsButtonRepeatSlow"
      }, {
        value: "off",
        labelKey: "controller:settingsButtonRepeatOff"
      }],
      IO = [{
        value: "short",
        labelKey: "controller:settingsTapHoldShort"
      }, {
        value: "medium",
        labelKey: "controller:settingsTapHoldMedium"
      }, {
        value: "long",
        labelKey: "controller:settingsTapHoldLong"
      }],
      yK = [{
        value: "hold",
        labelKey: "controller:settingsAttackHold"
      }, {
        value: "toggle",
        labelKey: "controller:settingsAttackToggle"
      }],
      gK = {
        southpaw: "controller:settingsLayoutSouthpaw",
        triggersSwapped: "controller:settingsLayoutTriggersSwapped"
      },
      uO = {
        jump: "controller:settingsActionJump",
        sneak: "controller:settingsActionSneak",
        sneakToggle: "controller:settingsActionSneakToggle",
        sprint: "controller:settingsActionSprint",
        attack: "controller:settingsActionAttack",
        use: "controller:settingsActionUse",
        hotbarPrevious: "controller:settingsActionHotbarPrevious",
        hotbarNext: "controller:settingsActionHotbarNext",
        inventory: "controller:settingsActionInventory",
        actionButton: "controller:settingsActionActionButton",
        perspective: "controller:settingsActionPerspective",
        XM: "controller:settingsActionPickBlock",
        drop: "controller:settingsActionDrop",
        emoteWheel: "controller:settingsActionEmoteWheel",
        chat: "controller:settingsActionChat",
        pause: "controller:settingsActionPause",
        leaderboard: "controller:settingsActionLeaderboard",
        menuConfirm: "controller:settingsActionMenuConfirm",
        menuBack: "controller:settingsActionMenuBack",
        menuTabPrevious: "controller:settingsActionMenuTabPrevious",
        menuTabNext: "controller:settingsActionMenuTabNext",
        menuPageUp: "controller:settingsActionMenuPageUp",
        menuPageDown: "controller:settingsActionMenuPageDown",
        menuSecondary: "controller:settingsActionMenuSecondary",
        menuToggleCursor: "controller:settingsActionMenuToggleCursor",
        inventoryPrimary: "controller:settingsActionInventoryPrimary",
        inventorySecondary: "controller:settingsActionInventorySecondary",
        inventoryQuickMove: "controller:settingsActionInventoryQuickMove",
        inventoryClose: "controller:settingsActionInventoryClose",
        inventoryPanelPrevious: "controller:settingsActionInventoryPanelPrevious",
        inventoryPanelNext: "controller:settingsActionInventoryPanelNext",
        inventoryDrop: "controller:settingsActionInventoryDrop",
        inventoryHotbarSwap: "controller:settingsActionInventoryHotbarSwap",
        keyboardType: "controller:settingsActionKeyboardType",
        keyboardBackspace: "controller:settingsActionKeyboardBackspace",
        keyboardSpace: "controller:settingsActionKeyboardSpace",
        keyboardCaretLeft: "controller:settingsActionKeyboardCaretLeft",
        keyboardCaretRight: "controller:settingsActionKeyboardCaretRight",
        keyboardShift: "controller:settingsActionKeyboardShift",
        keyboardSymbols: "controller:settingsActionKeyboardSymbols",
        keyboardSubmit: "controller:settingsActionKeyboardSubmit",
        keyboardClose: "controller:settingsActionKeyboardClose",
        keyboardChannel: "controller:settingsActionKeyboardChannel"
      },
      EO = {
        gameplay: "controller:settingsGroupGameplay",
        menu: "controller:settingsGroupMenus",
        inventory: "controller:settingsGroupInventory",
        keyboard: "controller:settingsGroupKeyboard"
      },
      jK = [{
        kind: "fixed",
        stick: "move",
        labelKey: "controller:settingsActionMove"
      }, {
        kind: "fixed",
        stick: "look",
        labelKey: "controller:settingsActionLook"
      }],
      YO = XO.c.map((OO => {
        let {
          group: KO,
          actions: pO
        } = OO;
        const XO = pO.map((OO => ({
          kind: "action",
          action: OO
        })));
        return {
          titleKey: EO[KO],
          rows: "gameplay" === KO ? [...jK, ...XO] : XO
        }
      })),
      wO = bK.$.filter((OO => "Home" !== OO)),
      iK = 1e4;
    class rK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => !0;
        this.cancelButton = OO, this.openButton = KO, this.accepts = pO, this.startMs = null, this.ignoredUntilMs = new Map, this.cancelDownAtMs = null
      }
      update(OO, KO) {
        var pO;
        this.updateIgnored(OO, KO);
        const XO = KO - (null !== (pO = this.startMs) && void 0 !== pO ? pO : KO) >= 250;
        for (const bK of wO)
          if (bK !== this.cancelButton && XO && !this.ignoredUntilMs.has(bK) && OO.wasPressed(bK) && this.accepts(bK)) return {
            kind: "bind",
            button: bK
          };
        if (this.ignoredUntilMs.has(this.cancelButton)) return null;
        if (OO.wasPressed(this.cancelButton)) {
          if (!this.accepts(this.cancelButton)) return {
            kind: "cancel"
          };
          this.cancelDownAtMs = KO
        }
        return null === this.cancelDownAtMs ? null : OO.isHeld(this.cancelButton) && KO - this.cancelDownAtMs >= 700 ? (this.cancelDownAtMs = null, {
          kind: "bind",
          button: this.cancelButton
        }) : OO.wasReleased(this.cancelButton) ? (this.cancelDownAtMs = null, {
          kind: "cancel"
        }) : null
      }
      getBindHoldProgress(OO) {
        return null === this.cancelDownAtMs ? 0 : Math.min(1, (OO - this.cancelDownAtMs) / 700)
      }
      updateIgnored(OO, KO) {
        if (null === this.startMs) {
          this.startMs = KO;
          for (const KO of wO) OO.isDown(KO) && this.ignoredUntilMs.set(KO, 1 / 0);
          this.openButton && !this.ignoredUntilMs.has(this.openButton) && this.ignoredUntilMs.set(this.openButton, KO + 250)
        }
        for (const [pO, XO] of this.ignoredUntilMs) {
          const bK = OO.isDown(pO);
          XO === 1 / 0 ? bK || pO !== this.openButton ? bK || this.ignoredUntilMs.delete(pO) : this.ignoredUntilMs.set(pO, KO + 250) : KO >= XO ? this.ignoredUntilMs.delete(pO) : bK && this.ignoredUntilMs.set(pO, 1 / 0)
        }
      }
    }
    const PO = 6e3;
    class mK {
      constructor() {
        this.downAtMs = null, this.pressesAtMs = []
      }
      update(OO, KO) {
        let {
          pressed: pO,
          JK: XO
        } = OO;
        if (pO) {
          const OO = this.pressesAtMs.at(-1);
          if (this.pressesAtMs = void 0 !== OO && KO - OO < 1500 ? [...this.pressesAtMs, KO] : [KO], this.pressesAtMs.length >= 3) return 1
        }
        return XO ? (this.downAtMs ??= KO, Math.min(1, (KO - this.downAtMs) / 1500)) : (this.downAtMs = null, 0)
      }
    }
  },
  7854: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      f: () => bK
    });
    let XO = null;
    const bK = function(OO) {
        const KO = {
          cycle: OO,
          canCycle: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => !0
        };
        return XO = KO, () => {
          XO === KO && (XO = null)
        }
      },
      eO = () => {
        var OO;
        return null !== (OO = XO) && void 0 !== OO && OO.canCycle() ? XO.cycle : null
      }
  },
  4151: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      h: () => lO
    });
    var XO = pO(63);
    const bK = new WeakMap,
      eO = OO => {
        var KO;
        const pO = OO.closest("[data-pad-slider]");
        return pO && null !== (KO = bK.get(pO)) && void 0 !== KO ? KO : null
      },
      lO = (OO, KO) => {
        const pO = (0, XO.useRef)(KO);
        pO.current = KO, (0, XO.useEffect)((() => {
          if (OO.current) return ((OO, KO) => (bK.set(OO, KO), () => {
            bK.get(OO) === KO && bK.delete(OO)
          }))(OO.current, {
            adjust: OO => {
              pO.current.adjust(OO)
            },
            setFraction: OO => {
              pO.current.setFraction(OO)
            },
            endDrag: () => {
              pO.current.endDrag()
            }
          })
        }), [OO])
      }
  },
  7893: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      h: () => lO,
      j: () => eO,
      k: () => XO,
      l: () => vK,
      o: () => hO,
      p: () => DO
    });
    const XO = "controllerActionWheelOpen",
      bK = "controllerActionWheelAim",
      eO = "controllerActionWheelCommit",
      lO = "controllerActionWheelClose",
      vK = "controllerActionWheelPick";
    let CO = !1;
    const hO = () => CO,
      DO = OO => {
        CO = OO
      }
  },
  7886: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      e: () => bK
    });
    let XO = 0;
    const bK = () => {
        XO++
      },
      eO = () => XO
  },
  7847: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO,
      e: () => bK,
      i: () => lO,
      m: () => eO,
      o: () => XO,
      p: () => hO
    });
    const XO = "controllerQuickChatWheelOpen",
      bK = "controllerQuickChatWheelAim",
      eO = "controllerQuickChatWheelCommit",
      lO = "controllerQuickChatWheelClose";
    let vK = !1;
    const CO = () => vK,
      hO = OO => {
        vK = OO
      }
  },
  7781: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      d: () => bK
    });
    var XO = pO(26);
    const bK = "localBlockBroken";

    function eO() {
      return {
        onPlayerChangeBlock(OO, KO, pO, eO, lO, vK) {
          "Air" === vK && XO.i.pl(bK)
        }
      }
    }
  },
  7824: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(7833),
      bK = pO(533),
      eO = pO(142);

    function lO(OO) {
      var KO, pO;
      if ((0, bK.I)(OO)) return !0;
      const lO = null !== (KO = null === (pO = eO.p[eO.t]) || void 0 === pO ? void 0 : pO.adConfig.showRewardedAds) && void 0 !== KO && KO;
      for (const bK in OO) {
        const KO = OO[bK];
        if (null !== KO && void 0 !== KO && KO.items)
          for (const OO in KO.items)
            if ((0, XO.i)(KO.items[OO], lO)) return !1
      }
      return !0
    }
  },
  7865: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      f: () => XO
    });
    const XO = 100;

    function bK(OO) {
      let {
        translationKeys: KO = !1
      } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      return OO.map((OO => {
        var pO;
        return null !== (pO = function(OO, KO) {
          if ("string" === typeof OO) return OO;
          const pO = "str" in OO ? OO.str : OO;
          if ("string" === typeof pO) return pO;
          if ("entityName" in pO) return pO.entityName;
          if (KO && "translationKey" in pO) return `{${pO.translationKey}${void 0===pO.params?"":` ${JSON.stringify(pO.params)}`}}`;
          return null
        }(OO, KO)) && void 0 !== pO ? pO : " "
      })).join("")
    }
  },
  7899: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      h: () => vK,
      l: () => CO
    });
    var XO = pO(1803),
      bK = pO(1098),
      eO = pO(1811);
    const lO = ",";

    function vK(OO) {
      if (!OO) return [];
      const KO = new Set,
        pO = [];
      for (const XO of OO.split(lO)) {
        const OO = XO.trim();
        if ((0, eO.n)(OO) && !KO.has(OO) && (KO.add(OO), pO.push(OO), pO.length >= bK.m)) break
      }
      return pO
    }

    function CO(OO) {
      const KO = new Set,
        pO = [];
      for (const XO of OO)
        if ((0, eO.n)(XO) && !KO.has(XO) && (KO.add(XO), pO.push(XO), pO.length >= bK.m)) break;
      return pO.join(lO)
    }

    function hO() {
      return CO(eO.g)
    }

    function DO(OO) {
      var KO;
      return "emote" === OO ? hO() : null !== (KO = MO[OO][0]) && void 0 !== KO ? KO : aK[OO]
    }
    const MO = bK.w.reduce(((OO, KO) => {
        const pO = [];
        for (const eO in XO.d[KO]) {
          var bK;
          "default" === (null === (bK = (0, XO.j)(KO, eO)) || void 0 === bK ? void 0 : bK.cosmeticPack) && pO.push(eO)
        }
        return OO[KO] = pO, OO
      }), {}),
      aK = bK.w.reduce(((OO, KO) => (OO[KO] = Object.keys(XO.d[KO])[0], OO)), {})
  },
  7896: () => {},
  7325: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/A.926fb88933484dfbde14.svg"
  },
  7330: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/B.9f5ec099f78f84e44427.svg"
  },
  7337: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Down.b1852f687e6dd088dc83.svg"
  },
  7345: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Home.4f2ce08049843c0d68cc.svg"
  },
  7347: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LB.3a20b15927b55d5d8b60.svg"
  },
  7354: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LS.30b6b373c0d6b7ee1753.svg"
  },
  7362: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LT.9fdc5e69011b9d41f50a.svg"
  },
  7369: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Left.c380211d278e5ad37395.svg"
  },
  7373: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LeftStick.572ef7fe851cd5c7c48d.svg"
  },
  7379: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Menu.c903a662eb685211e52e.svg"
  },
  7388: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RB.bba470ddb76ceec5d168.svg"
  },
  7392: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RS.faed29b08b9895ac7291.svg"
  },
  7396: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RT.e5a9fbcc3c79550111ca.svg"
  },
  7400: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Right.01eea634de7e4fea174f.svg"
  },
  7405: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RightStick.8c455f35f82d8f40b0dc.svg"
  },
  7412: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Up.0c878a914746e22612b1.svg"
  },
  7416: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/View.0c9378b5d720a636d50d.svg"
  },
  7419: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/X.c9377519af94e6dce1d7.svg"
  },
  7422: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Y.62d8c17731dd2e172426.svg"
  },
  7431: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/A.958a6de9474f8d0c9caf.svg"
  },
  7438: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/B.d05958bfa88a1162b47a.svg"
  },
  7445: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Down.db68fb3980768eb54671.svg"
  },
  7448: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Home.4f2ce08049843c0d68cc.svg"
  },
  7455: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LB.37a3c5128c958ec2a0c2.svg"
  },
  7461: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LS.15b0cc5bf3f2fe7bbd8b.svg"
  },
  7464: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LT.5412ae5222c69f8c833f.svg"
  },
  7471: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Left.4457b2895ce94a5df32e.svg"
  },
  7480: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LeftStick.572ef7fe851cd5c7c48d.svg"
  },
  7487: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Menu.1e8427f8133c9d456c53.svg"
  },
  7490: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RB.c96c4aa2590209e930c7.svg"
  },
  7492: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RS.8d70d147cf1ab136e845.svg"
  },
  7498: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RT.1e4691bb5a7c049693df.svg"
  },
  7507: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Right.a1e101413040c540b879.svg"
  },
  7509: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RightStick.8c455f35f82d8f40b0dc.svg"
  },
  7516: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Up.7544a65ad4f611a55775.svg"
  },
  7519: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/View.003cae39de89cae0b9d8.svg"
  },
  7521: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/X.d88b6e62dd8fb4bda32a.svg"
  },
  7530: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Y.428d3e70775877892f82.svg"
  },
  7534: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/A.9f5ec099f78f84e44427.svg"
  },
  7537: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/B.926fb88933484dfbde14.svg"
  },
  7545: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Down.b1852f687e6dd088dc83.svg"
  },
  7549: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Home.ea8b009cfa9562aa644e.svg"
  },
  7553: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LB.f283d355d22fc107d6d6.svg"
  },
  7560: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LS.30b6b373c0d6b7ee1753.svg"
  },
  7565: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LT.13e66c122e7ee04bb876.svg"
  },
  7567: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Left.c380211d278e5ad37395.svg"
  },
  7571: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LeftStick.572ef7fe851cd5c7c48d.svg"
  },
  7579: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Menu.90fc4e918900eb5062a0.svg"
  },
  7581: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RB.918a7f16dc054d96b6f3.svg"
  },
  7585: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RS.faed29b08b9895ac7291.svg"
  },
  7587: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RT.a0523211130959598bed.svg"
  },
  7596: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Right.01eea634de7e4fea174f.svg"
  },
  7599: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RightStick.8c455f35f82d8f40b0dc.svg"
  },
  7603: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Up.0c878a914746e22612b1.svg"
  },
  7608: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/View.0bc952e292c28c3baac2.svg"
  },
  7616: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/X.62d8c17731dd2e172426.svg"
  },
  7622: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Y.c9377519af94e6dce1d7.svg"
  },
  7628: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/A.9f5ec099f78f84e44427.svg"
  },
  7637: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/B.926fb88933484dfbde14.svg"
  },
  7639: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Down.b1852f687e6dd088dc83.svg"
  },
  7648: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Home.8898f76b20962fe52ab7.svg"
  },
  7654: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LB.689ba3703ae248f2e4cc.svg"
  },
  7662: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LS.30b6b373c0d6b7ee1753.svg"
  },
  7669: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LT.9c2d10d335ab5c590525.svg"
  },
  7677: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Left.c380211d278e5ad37395.svg"
  },
  7686: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/LeftStick.572ef7fe851cd5c7c48d.svg"
  },
  7689: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Menu.9e485791ea97009871ca.svg"
  },
  7697: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RB.7ee5ce48dd551f993f80.svg"
  },
  7704: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RS.faed29b08b9895ac7291.svg"
  },
  7708: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RT.903ecadc55a9e9e00f07.svg"
  },
  7715: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Right.01eea634de7e4fea174f.svg"
  },
  7723: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/RightStick.8c455f35f82d8f40b0dc.svg"
  },
  7730: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Up.0c878a914746e22612b1.svg"
  },
  7735: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/View.3c5eeb34f0413bde4a65.svg"
  },
  7738: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/X.62d8c17731dd2e172426.svg"
  },
  7744: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/Y.c9377519af94e6dce1d7.svg"
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);