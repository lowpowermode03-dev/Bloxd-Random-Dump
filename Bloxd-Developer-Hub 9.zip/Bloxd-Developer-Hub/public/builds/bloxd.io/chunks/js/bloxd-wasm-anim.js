export const id = 5;
export const ids = [5];
export const modules = {
  41303: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_anim_bg.41a8946c13fce30cced7.wasm"
  },
  41299: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      BloxdAnimWasmError: () => PO,
      compileAnimationPackInWasm: () => RO
    });
    var XO = {};

    function bK(OO, KO, pO, XO, bK, eO) {
      const lO = zK(OO, uO.WOjv),
        vK = EO,
        CO = zK(KO, uO.WOjv),
        hO = EO,
        DO = zK(pO, uO.WOjv),
        MO = EO,
        aK = zK(XO, uO.WOjv),
        FO = EO,
        VO = zK(bK, uO.WOjv),
        LO = EO;
      var AO = QO(eO) ? 0 : function(OO, KO) {
          const pO = KO(1 * OO.length, 1) >>> 0;
          return oO().set(OO, pO / 1), EO = OO.length, pO
        }(eO, uO.WOjv),
        dO = EO;
      const TO = uO.Bnhl(lO, vK, CO, hO, DO, MO, aK, FO, VO, LO, AO, dO);
      if (TO[3]) throw fO(TO[2]);
      var NO, IO, yK = (NO = TO[0], IO = TO[1], NO >>>= 0, oO().subarray(NO / 1, NO / 1 + IO)).slice();
      return uO.jK8F(TO[0], 1 * TO[1], 1), yK
    }

    function eO(OO, KO) {
      const pO = AO(OO, uO.WOjv, uO.DZFH),
        XO = EO,
        bK = uO.k0VC(pO, XO, KO);
      if (bK[1]) throw fO(bK[0])
    }

    function lO() {
      uO.onVK()
    }

    function vK() {
      return {
        __proto__: null,
        ORFc: {
          __proto__: null,
          OhFO: function(OO, KO) {
            return CO(Error(MO(OO, KO)))
          },
          fUJU: function(OO, KO) {
            const pO = FO(KO),
              XO = "string" === typeof pO ? pO : void 0;
            var bK = QO(XO) ? 0 : AO(XO, uO.WOjv, uO.DZFH),
              eO = EO;
            DO().setInt32(OO + 4, eO, !0), DO().setInt32(OO + 0, bK, !0)
          },
          lcJm: function(OO, KO) {
            throw new Error(MO(OO, KO))
          },
          hxjf: function(OO, KO) {
            console.error(MO(OO, KO))
          },
          oaoM: function(OO) {
            fO(OO)
          }
        }
      }
    }

    function CO(OO) {
      LO === VO.length && VO.push(VO.length + 1);
      const KO = LO;
      return LO = VO[KO], VO[KO] = OO, KO
    }
    pO.r(XO), pO.d(XO, {
      iFO: () => bK,
      aK: () => eO,
      default: () => wO,
      initSync: () => YO,
      oO: () => lO
    });
    let hO = null;

    function DO() {
      return (null === hO || !0 === hO.buffer.detached || void 0 === hO.buffer.detached && hO.buffer !== uO.memory.buffer) && (hO = new DataView(uO.memory.buffer)), hO
    }

    function MO(OO, KO) {
      return function(OO, KO) {
        NO += KO, NO >= TO && (dO = new TextDecoder("utf-8", {
          ignoreBOM: !0,
          fatal: !0
        }), dO.decode(), NO = KO);
        return dO.decode(oO().subarray(OO, OO + KO))
      }(OO >>> 0, KO)
    }
    let aK = null;

    function oO() {
      return null !== aK && 0 !== aK.byteLength || (aK = new Uint8Array(uO.memory.buffer)), aK
    }

    function FO(OO) {
      return VO[OO]
    }
    let VO = new Array(1024).fill(void 0);
    VO.push(void 0, null, !0, !1);
    let LO = VO.length;

    function QO(OO) {
      return void 0 === OO || null === OO
    }

    function zK(OO, KO) {
      const pO = KO(4 * OO.length, 4) >>> 0,
        XO = DO();
      for (let bK = 0; bK < OO.length; bK++) XO.setUint32(pO + 4 * bK, CO(OO[bK]), !0);
      return EO = OO.length, pO
    }

    function AO(OO, KO, pO) {
      if (void 0 === pO) {
        const pO = IO.encode(OO),
          XO = KO(pO.length, 1) >>> 0;
        return oO().subarray(XO, XO + pO.length).set(pO), EO = pO.length, XO
      }
      let XO = OO.length,
        bK = KO(XO, 1) >>> 0;
      const eO = oO();
      let lO = 0;
      for (; lO < XO; lO++) {
        const KO = OO.charCodeAt(lO);
        if (KO > 127) break;
        eO[bK + lO] = KO
      }
      if (lO !== XO) {
        0 !== lO && (OO = OO.slice(lO)), bK = pO(bK, XO, XO = lO + 3 * OO.length, 1) >>> 0;
        const KO = oO().subarray(bK + lO, bK + XO);
        lO += IO.encodeInto(OO, KO).written, bK = pO(bK, XO, lO, 1) >>> 0
      }
      return EO = lO, bK
    }

    function fO(OO) {
      const KO = FO(OO);
      return function(OO) {
        OO < 1028 || (VO[OO] = LO, LO = OO)
      }(OO), KO
    }
    let dO = new TextDecoder("utf-8", {
      ignoreBOM: !0,
      fatal: !0
    });
    dO.decode();
    const TO = 2146435072;
    let NO = 0;
    const IO = new TextEncoder;
    "encodeInto" in IO || (IO.encodeInto = function(OO, KO) {
      const pO = IO.encode(OO);
      return KO.set(pO), {
        read: OO.length,
        written: pO.length
      }
    });
    let yK, gK, uO, EO = 0;

    function jK(OO, KO) {
      return gK = OO, uO = OO.exports, yK = KO, hO = null, aK = null, uO.pwUZ(), uO
    }

    function YO(OO) {
      if (void 0 !== uO) return uO;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module: OO
      } = OO) : console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));
      const KO = vK();
      OO instanceof WebAssembly.Module || (OO = new WebAssembly.Module(OO));
      return jK(new WebAssembly.Instance(OO, KO), OO)
    }
    async function wO(OO) {
      if (void 0 !== uO) return uO;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module_or_path: OO
      } = OO) : console.warn("using deprecated parameters for the initialization function; pass a single object instead"));
      const KO = vK();
      ("string" === typeof OO || "function" === typeof Request && OO instanceof Request || "function" === typeof URL && OO instanceof URL) && (OO = fetch(OO));
      const {
        instance: pO,
        module: XO
      } = await async function(OO, KO) {
        if ("function" === typeof Response && OO instanceof Response) {
          if (!OO.ok) throw new Error(`failed to fetch Wasm: ${OO.status} ${OO.statusText} fetching '${OO.url}'`);
          if ("function" === typeof WebAssembly.instantiateStreaming) try {
            return await WebAssembly.instantiateStreaming(OO, KO)
          } catch (pO) {
            if (! function(OO) {
                switch (OO) {
                  case "basic":
                  case "cors":
                  case "default":
                    return !0
                }
                return !1
              }(OO.type) || "application/wasm" === OO.headers.get("Content-Type")) throw pO;
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", pO)
          }
          const XO = await OO.arrayBuffer();
          return await WebAssembly.instantiate(XO, KO)
        } {
          const pO = await WebAssembly.instantiate(OO, KO);
          return pO instanceof WebAssembly.Instance ? {
            instance: pO,
            module: OO
          } : pO
        }
      }(await OO, KO);
      return jK(pO, XO)
    }
    var iK = pO(2951),
      rK = pO(5747);
    class PO extends Error {
      stage;
      constructor(OO, KO) {
        super((0, iK.v)(OO, KO), {
          cause: KO
        }), this.name = "BloxdAnimWasmError", this.stage = OO
      }
    }
    let mK = null,
      sO = null;

    function HO() {
      if (sO) throw sO
    }
    async function RO(OO, KO, bK) {
      HO();
      const eO = await (mK ??= (async () => {
        let OO;
        try {
          OO = await (0, iK.x)(new pO.U(pO(41303)), (0, rK.e)("bloxd_wasm_anim"))
        } catch (KO) {
          throw new PO((0, iK.z)(KO), KO)
        }
        try {
          await wO({
            module_or_path: OO
          })
        } catch (KO) {
          throw new PO("instantiate", KO)
        }
        return XO
      })(), mK.catch((() => {
        mK = null
      })), mK);
      HO();
      try {
        return eO.iFO(Object.entries(OO).flat(), [...KO.mobTypes], [...KO.vehicleTypes], [...KO.mobAiStates], [...KO.playerPoses], "builtIns" in bK ? bK.builtIns : void 0)
      } catch (lO) {
        const OO = new PO("call", lO);
        throw lO instanceof WebAssembly.RuntimeError && (sO = OO), OO
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);