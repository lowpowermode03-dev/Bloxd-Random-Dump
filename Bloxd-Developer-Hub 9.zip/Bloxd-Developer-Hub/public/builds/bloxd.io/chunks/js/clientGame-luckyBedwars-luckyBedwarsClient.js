export const id = 18;
export const ids = [18];
export const modules = {
  35130: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      h: () => FO,
      i: () => aK,
      k: () => MO
    });
    var XO = pO(8311),
      bK = pO(35137),
      eO = pO(35139),
      lO = pO(7854),
      vK = pO(1263),
      CO = pO(63),
      hO = pO(77),
      DO = pO(976);

    function MO() {
      var OO;
      return (0, vK.h)(bK.d, (0, bK.l)()), (0, DO.jsx)(DO.Fragment, {
        children: null === (OO = (0, bK.l)()) || void 0 === OO ? void 0 : OO.content
      })
    }

    function aK(OO) {
      var KO;
      let {
        show: pO
      } = OO;
      (0, vK.h)(bK.d, (0, bK.l)());
      const hO = null === (KO = (0, bK.l)()) || void 0 === KO ? void 0 : KO.menu;
      return (0, CO.useEffect)((() => {
        var OO;
        pO || (null === hO || void 0 === hO || null === (OO = hO.onClose) || void 0 === OO || OO.call(hO), (0, eO.q)())
      }), [pO, hO]), (0, CO.useEffect)((() => pO ? (0, lO.f)(eO.y, eO.f) : void 0), [pO]), (0, DO.jsx)(XO.e, {
        showing: pO,
        globallyUniqueKey: "clientGameMenu",
        children: null === hO || void 0 === hO ? void 0 : hO.content
      })
    }

    function oO(OO) {
      let {
        placement: KO = "bottom"
      } = OO;
      return (0, DO.jsx)("div", {
        id: `clientGameHud-${KO}`,
        style: {
          display: "contents"
        }
      })
    }

    function FO(OO) {
      let {
        children: KO,
        placement: pO = "bottom"
      } = OO;
      const [XO, bK] = (0, CO.useState)(null);
      return (0, CO.useEffect)((() => {
        bK(document.getElementById(`clientGameHud-${pO}`))
      }), [pO]), XO ? (0, hO.createPortal)(KO, XO) : null
    }
  },
  8311: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(3725),
      bK = pO(3730);

    function eO(OO) {
      let {
        children: KO,
        showing: pO,
        globallyUniqueKey: eO,
        alwaysMountChildren: lO = !1,
        doGameplayStartStopOnShow: vK = !0,
        keepsMovement: CO = !1
      } = OO;
      return (0, bK.b)(!0, pO, eO, CO), (0, XO.e)(vK, pO), pO || lO ? KO : null
    }
  },
  7854: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      f: () => bK
    });
    let XO = null;
    const bK = function(OO) {
        const KO = {
          cycle: OO,
          canCycle: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => !0
        };
        return XO = KO, () => {
          XO === KO && (XO = null)
        }
      },
      eO = () => {
        var OO;
        return null !== (OO = XO) && void 0 !== OO && OO.canCycle() ? XO.cycle : null
      }
  },
  35139: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => zK,
      c: () => eO,
      f: () => VO,
      i: () => LO,
      m: () => vK,
      n: () => aK,
      q: () => QO,
      s: () => MO,
      u: () => AO,
      y: () => FO
    });
    var XO = pO(22),
      bK = pO(26);
    const eO = "clientGameInventoryButtonsChanged",
      lO = new Map;

    function vK() {
      return [...lO.values()].sort(((OO, KO) => {
        var pO, XO;
        return (null !== (pO = OO.order) && void 0 !== pO ? pO : 0) - (null !== (XO = KO.order) && void 0 !== XO ? XO : 0)
      }))
    }
    let CO = null;

    function hO(OO) {
      CO = OO
    }
    let DO = !1;

    function MO(OO) {
      DO = !0;
      try {
        OO.onClick()
      } finally {
        DO = !1
      }
      OO.panel && "clientGame" === XO.d.get("openInGameMenuName") && hO(OO.id)
    }

    function aK() {
      return DO
    }

    function oO() {
      return vK().filter((OO => OO.panel && !OO.disabled))
    }

    function FO(OO) {
      const KO = oO(),
        pO = KO.findIndex((OO => OO.id === CO));
      return !(pO < 0 || KO.length < 2) && (MO(KO[(pO + OO + KO.length) % KO.length]), !0)
    }

    function VO() {
      return null !== CO && oO().length > 1
    }

    function LO() {
      hO(null)
    }

    function QO() {
      "inventory" !== XO.d.get("openInGameMenuName") && hO(null)
    }

    function zK() {
      const OO = CO;
      return hO(null), OO
    }

    function AO(OO) {
      return lO.set(OO.id, OO), bK.i.pl(eO, vK(), !0), () => {
        lO.get(OO.id) === OO && (lO.delete(OO.id), bK.i.pl(eO, vK()))
      }
    }
  },
  35137: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      g: () => LO,
      j: () => QO,
      k: () => aK,
      l: () => hO,
      o: () => VO,
      p: () => oO,
      q: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(1136),
      lO = pO(35139);
    const vK = "clientGameUiChanged";
    let CO = null;

    function hO() {
      return CO
    }

    function DO(OO, KO) {
      const pO = {
        content: OO,
        menu: KO
      };
      return CO = pO, bK.i.pl(vK, CO, !0), () => {
        CO === pO && (CO = null, FO = !1, LO(), bK.i.pl(vK, null))
      }
    }
    let MO = null;

    function aK() {
      return MO
    }

    function oO(OO) {
      return MO = OO, () => {
        MO === OO && (MO = null)
      }
    }
    let FO = !1;

    function VO() {
      const OO = XO.d.get("openInGameMenuName");
      "clientGame" !== OO && (FO = "inventory" === OO), (0, lO.n)() || (0, lO.i)(), (0, eO.k)("InGameMenu"), XO.d.set({
        openInGameMenuName: "clientGame",
        openEverythingMenuName: null
      })
    }

    function LO() {
      zK(!1)
    }

    function QO() {
      zK(FO)
    }

    function zK(OO) {
      "clientGame" === XO.d.get("openInGameMenuName") && XO.d.set({
        openInGameMenuName: OO ? "inventory" : null
      }), OO || (0, lO.i)(), FO = !1
    }
  },
  37661: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => UO
    });
    const XO = {
      trader: {
        name: "Lucky Trader",
        shopTab: "Basic Blocks"
      },
      wizard: {
        name: "Lucky Upgrades",
        shopTab: "Team Upgrades"
      }
    };
    var bK = pO(63),
      eO = pO(36414),
      lO = pO(256);
    const vK = ["Basic", "Rare", "Super"];

    function CO(OO, KO) {
      return `${"Basic"===KO?"":`${KO} `}${"Simple"===OO?"":`${OO} `}Lucky Block`
    }
    const hO = new Map(["Simple", "Building", "Weapon", "Armour", "Tools", "Food", "Potion"].flatMap((OO => vK.map((KO => [CO(OO, KO), {
      category: OO,
      rarity: KO
    }])))));
    hO.keys();

    function DO(OO) {
      return hO.get(OO)
    }
    const MO = "Obsidian",
      aK = ["Cobweb"],
      oO = [...["Red", "Blue", "Green", "Yellow"].map((OO => `${(0,lO.V)(OO)} Wool`)), "Maple Wood Planks", "Cracked Stone Bricks", "Baked Clay", MO, ...aK];

    function FO(OO) {
      return oO.includes(OO)
    }
    var VO = pO(533);

    function LO(OO, KO) {
      const pO = DO(OO);
      if (pO) {
        const OO = DO(KO);
        if (!OO) return;
        const XO = vK.length - 1 - vK.indexOf(OO.rarity);
        return (OO.category === pO.category ? 0 : 1) * vK.length + XO
      }
      if (!FO(OO)) return;
      if (KO === OO) return 0;
      const XO = OO => FO(OO) && !aK.includes(OO) && OO !== MO;
      return XO(OO) && XO(KO) ? 1 : void 0
    }
    const QO = [...Array.from({
      length: VO.r - VO.p
    }, ((OO, KO) => VO.p + KO)), ...Array.from({
      length: VO.p
    }, ((OO, KO) => KO))];
    class zK {
      constructor(OO) {
        this.inventory = OO, this.pending = new Map
      }
      onPlace(OO) {
        var KO;
        const pO = this.inventory.selectedSlot(),
          XO = this.inventory.itemAt(pO);
        (null === XO || void 0 === XO ? void 0 : XO.name) === OO && (null !== (KO = XO.amount) && void 0 !== KO ? KO : 1) <= 1 && AO(OO) && this.pending.set(pO, OO)
      }
      onDrop(OO, KO) {
        KO < VO.p && null === this.inventory.itemAt(KO) && AO(OO) && this.refill(KO, OO)
      }
      KK() {
        const OO = [...this.pending];
        this.pending.clear();
        for (const [KO, pO] of OO) null === this.inventory.itemAt(KO) && this.refill(KO, pO)
      }
      refill(OO, KO) {
        const pO = function(OO, KO, pO, XO) {
          let bK, eO = 1 / 0;
          for (const lO of QO) {
            if (lO === KO) continue;
            const vK = XO(lO);
            if (!vK || lO < VO.p && KO !== pO) continue;
            const CO = LO(OO, vK.name);
            void 0 !== CO && CO < eO && (bK = lO, eO = CO)
          }
          return bK
        }(KO, OO, this.inventory.selectedSlot(), this.inventory.itemAt);
        void 0 !== pO && this.inventory.swap(OO, pO)
      }
    }

    function AO(OO) {
      return !!DO(OO) || FO(OO)
    }
    var fO = pO(35137),
      dO = pO(77),
      TO = pO(918),
      NO = pO.n(TO);
    const IO = "Lucky Clover",
      yK = {
        Basic: [35, 45],
        Rare: [100, 130],
        Super: [250, 330]
      };

    function gK(OO) {
      return yK[OO][0]
    }

    function uO(OO) {
      return vK.filter((KO => OO >= gK(KO)))
    }
    var EO = pO(243),
      jK = pO(1991),
      YO = pO(22),
      wO = pO(2045),
      iK = pO(1546),
      rK = pO(35130),
      PO = pO(933);
    var mK = pO(976);
    const sO = {
      Basic: lO.J.whiteUiText,
      Rare: lO.J.goldUiText,
      Super: lO.J.cyanUiText
    };
    let HO = 1;

    function RO() {
      const OO = (0, jK.i)("currencyAmounts"),
        KO = null === OO || void 0 === OO ? void 0 : OO.Clovers;
      return !KO || KO.hidden ? null : (0, mK.jsx)(rK.h, {
        children: (0, mK.jsx)(SO, {
          amount: KO.amount
        })
      })
    }

    function SO(OO) {
      var KO, pO, XO;
      let {
        amount: eO
      } = OO;
      const {
        openEverythingMenuName: CO
      } = (0, YO.l)(["openEverythingMenuName"]), hO = (0, wO.b)(), [DO, MO] = (0, bK.useState)(eO), [aK, oO] = (0, bK.useState)(null), [FO, VO] = (0, bK.useState)(0), [LO, QO] = (0, bK.useState)([]), zK = (0, bK.useRef)(eO), AO = (0, bK.useRef)(!1), fO = (0, bK.useRef)(null), TO = CO === EO.o.SHOP;
      (0, bK.useEffect)((() => {
        const OO = zK.current;
        if (zK.current = eO, eO <= OO || TO) return void MO(eO);
        const KO = hO || LO.length > 0 || window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : (pO = eO - OO, XO = !AO.current, pO <= 0 || !XO && pO < 40 ? 0 : Math.min(4, Math.ceil(pO / 30)));
        var pO, XO;
        if (AO.current = !0, uO(eO).length > uO(OO).length && VO(HO++), KO > 0) {
          const OO = [];
          for (let pO = 0; pO < KO; pO++) OO.push({
            id: HO++,
            x: window.innerWidth / 2 + 60 * (Math.random() - .5),
            y: .58 * window.innerHeight + 30 * (Math.random() - .5),
            delayMs: 70 * pO
          });
          QO((KO => [...KO, ...OO]))
        }
        const bK = KO > 0 ? 600 : 0;
        oO({
          id: HO++,
          delayMs: bK
        });
        const vK = performance.now() + bK;
        let CO = 0;
        const DO = KO => {
          const pO = lO.e.clamp((KO - vK) / 600, 0, 1);
          MO(Math.round(OO + (eO - OO) * pO)), pO < 1 && (CO = requestAnimationFrame(DO))
        };
        return CO = requestAnimationFrame(DO), () => {
          cancelAnimationFrame(CO)
        }
      }), [eO, TO]);
      const yK = function(OO) {
          var KO;
          const pO = null !== (KO = vK.find((KO => OO < gK(KO)))) && void 0 !== KO ? KO : "Super";
          return {
            rarity: pO,
            progress: lO.e.clamp(OO / gK(pO), 0, 1)
          }
        }(DO),
        jK = uO(DO).at(-1);
      return (0, mK.jsxs)(mK.Fragment, {
        children: [(0, mK.jsx)("div", {
          className: "LuckyCloverWalletAnchor",
          children: (0, mK.jsxs)("div", {
            className: NO()("LuckyCloverWallet", {
              Capped: jK && "Basic" !== jK
            }),
            style: jK && {
              "--luckyTierColour": sO[jK]
            },
            children: [(0, mK.jsx)("div", {
              className: "LuckyCloverWalletFill",
              style: {
                transform: `scaleX(${yK.progress})`
              }
            }), FO > 0 && (0, mK.jsx)("div", {
              className: "LuckyCloverWalletReached",
              style: {
                animationDelay: `${null!==(KO=null===aK||void 0===aK?void 0:aK.delayMs)&&void 0!==KO?KO:0}ms`
              }
            }, FO), (0, mK.jsx)("div", {
              ref: fO,
              className: NO()("LuckyCloverWalletIcon", aK && "Bounce"),
              style: {
                animationDelay: `${null!==(XO=null===aK||void 0===aK?void 0:aK.delayMs)&&void 0!==XO?XO:0}ms`
              },
              children: (0, mK.jsx)(iK.b, {
                itemName: IO,
                amount: 0
              })
            }, null !== (pO = null === aK || void 0 === aK ? void 0 : aK.id) && void 0 !== pO ? pO : 0), (0, mK.jsx)("span", {
              className: "LuckyCloverWalletAmount SmallTextBold",
              children: DO
            }), jK && (0, mK.jsx)(PO.d, {
              className: "LuckyCloverWalletShop",
              name: "cart-shopping"
            })]
          })
        }), (0, dO.createPortal)(LO.map((OO => (0, mK.jsx)(JO, {
          flyer: OO,
          target: fO,
          onDone: () => {
            QO((KO => KO.filter((KO => KO.id !== OO.id))))
          }
        }, OO.id))), document.body)]
      })
    }

    function JO(OO) {
      let {
        flyer: KO,
        target: pO,
        onDone: XO
      } = OO;
      const eO = (0, bK.useRef)(null);
      return (0, bK.useEffect)((() => {
        var OO;
        const bK = null === (OO = pO.current) || void 0 === OO ? void 0 : OO.getBoundingClientRect();
        if (!eO.current || !bK) return void XO();
        const {
          x: lO,
          y: vK
        } = KO, CO = lO + 140 * (Math.random() - .5), hO = vK - 30 - 40 * Math.random(), DO = eO.current.animate([{
          transform: `translate(${lO}px, ${vK}px) scale(0.3)`,
          opacity: 0
        }, {
          transform: `translate(${CO}px, ${hO}px) scale(1.3)`,
          opacity: 1,
          offset: .3
        }, {
          transform: `translate(${bK.left}px, ${bK.top}px) scale(0.8)`,
          opacity: .9
        }], {
          duration: 750,
          easing: "ease-in",
          delay: KO.delayMs,
          fill: "backwards"
        });
        return DO.onfinish = XO, () => {
          DO.cancel()
        }
      }), []), (0, mK.jsx)("div", {
        ref: eO,
        className: "LuckyCloverFlying",
        children: (0, mK.jsx)(iK.b, {
          itemName: IO,
          amount: 0
        })
      })
    }
    var cK = pO(26);
    const BO = "luckyGearUpgradeView",
      ZO = {
        Wood: "#c8964f",
        Stone: "#b4b4b4",
        Iron: "#f2f2f2",
        Gold: "#ffd83d",
        Diamond: "#5cf2ea"
      };

    function GO(OO) {
      var KO;
      return null !== (KO = ZO[OO.split(" ")[0]]) && void 0 !== KO ? KO : "#e07bff"
    }
    class qK {
      constructor(OO, KO) {
        this.selectedSlot = OO, this.itemAt = KO, this.rings = [], this.unseen = new Map, this.view = {
          rings: [],
          unseenSlots: []
        }, this.nextId = 0
      }
      getView() {
        return this.view
      }
      PX(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : performance.now();
        for (const [pO, XO, bK] of OO) this.rings.push({
          id: this.nextId++,
          slot: pO,
          colour: GO(bK),
          until: KO + 1200
        }), pO !== this.selectedSlot() && this.unseen.set(pO, {
          from: XO,
          to: bK
        });
        this.pl()
      }
      KK() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : performance.now();
        if (!this.rings.length && !this.unseen.size) return;
        const KO = this.rings.filter((KO => KO.until > OO));
        let pO = KO.length !== this.rings.length;
        this.rings = KO;
        for (const [XO, {
            from: bK,
            to: eO
          }] of this.unseen) {
          const OO = this.itemAt(XO);
          (XO === this.selectedSlot() || OO !== eO && OO !== bK) && (this.unseen.delete(XO), pO = !0)
        }
        pO && this.pl()
      }
      pl() {
        this.view = {
          rings: [...this.rings],
          unseenSlots: [...this.unseen.keys()]
        }, cK.i.pl(BO, this.view)
      }
    }
    var xK = pO(1263);

    function nO(OO) {
      return document.querySelector(`.HotBar [data-inven-idx="${OO}"]`)
    }

    function WO(OO) {
      let {
        ring: KO
      } = OO;
      const [pO, XO] = (0, bK.useState)(null);
      return (0, bK.useLayoutEffect)((() => {
        var OO, pO;
        XO(null !== (OO = null === (pO = nO(KO.slot)) || void 0 === pO ? void 0 : pO.getBoundingClientRect()) && void 0 !== OO ? OO : null)
      }), [KO]), pO ? (0, mK.jsx)("div", {
        className: "LuckyGearRing",
        style: {
          left: pO.left,
          top: pO.top,
          width: pO.width,
          height: pO.height,
          "--ringColour": KO.colour,
          "--ringMs": "1200ms"
        }
      }) : null
    }

    function tK(OO) {
      let {
        slot: KO
      } = OO;
      const [pO, XO] = (0, bK.useState)(null);
      return (0, bK.useLayoutEffect)((() => {
        const OO = () => {
          XO(nO(KO))
        };
        OO();
        const pO = new MutationObserver(OO),
          bK = document.querySelector(".BottomMiddleElements");
        return bK && pO.observe(bK, {
          childList: !0,
          subtree: !0
        }), () => {
          pO.disconnect()
        }
      }), [KO]), pO ? (0, dO.createPortal)((0, mK.jsx)("div", {
        className: "LuckyGearUnseen"
      }), pO) : null
    }

    function kK(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, xK.h)(BO, KO.getView());
      return (0, mK.jsxs)(mK.Fragment, {
        children: [pO.rings.map((OO => (0, mK.jsx)(WO, {
          ring: OO
        }, OO.id))), pO.unseenSlots.map((OO => (0, mK.jsx)(tK, {
          slot: OO
        }, OO)))]
      })
    }
    const UO = function(OO, KO, pO, lO) {
      let vK, {
          localPlayerId: CO
        } = lO,
        hO = null;
      const DO = new zK({
          itemAt: OO => vK.getItemSlot(CO, OO),
          selectedSlot: () => vK.getSelectedInventorySlotI(CO),
          swap: (OO, KO) => {
            vK.swapInventorySlots(OO, KO)
          }
        }),
        MO = new qK((() => vK.getSelectedInventorySlotI(CO)), (OO => {
          var KO;
          return null === (KO = vK.getItemSlot(CO, OO)) || void 0 === KO ? void 0 : KO.name
        }));
      return {
        plugins: {
          placeAgainstBeds: (0, eO.b)()
        },
        onCreate: OO => {
          vK = OO, hO = (0, fO.q)((0, bK.createElement)(bK.Fragment, null, (0, bK.createElement)(RO), (0, bK.createElement)(kK, {
            controller: MO
          })))
        },
        onClose: () => {
          var OO;
          null === (OO = hO) || void 0 === OO || OO()
        },
        KK: () => {
          DO.KK(), MO.KK()
        },
        onReceivedMessageFromServer: (OO, KO) => {
          "luckyGearUpgrade" === OO && MO.PX(KO)
        },
        onPlayerChangeBlock: (OO, KO, pO, XO, bK, eO) => {
          "Air" !== eO && DO.onPlace(eO)
        },
        onPlayerDropItem: (OO, KO, pO, XO) => {
          DO.onDrop(KO, XO)
        },
        onPlayerAltAction: (OO, KO, pO, bK, eO, lO) => {
          if (!lO || "Mesh" !== vK.getEntityType(lO)) return;
          const CO = vK.getEntityName(lO),
            hO = Object.values(XO).find((OO => OO.name === CO));
          hO && vK.openShop(OO, !1, hO.shopTab)
        }
      }
    }
  },
  36414: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK
    });
    var XO = pO(256),
      bK = pO(35411),
      eO = pO(3673);
    const lO = ["Leaf Bed", "_Leaf Bed Head", ...XO.Bc.flatMap((OO => [`${OO} Bed`, `_${OO} Bed Head`, `${OO} Strongbed`, `_${OO} Strongbed Head`]))];

    function vK() {
      let OO;
      return {
        onCreate(KO) {
          OO = KO
        },
        altVetoBlocks: lO,
        onPlayerAttemptAltAction(KO, pO, XO, lO, vK, CO) {
          var hO;
          if ((0, bK.c)(OO.getMetaInfo(vK).rootName) && !OO.isEntityInteractable(CO) && (0, eO.f)(null === (hO = OO.mhO(KO)) || void 0 === hO ? void 0 : hO.typeObj.type)) return "preventAction"
        }
      }
    }
  },
  35411: (OO, KO, pO) => {
    function XO(OO) {
      return OO.includes("Leaf Bed")
    }

    function bK(OO) {
      return / Bed(?: Head)?(?:\||$)/.test(OO) && !XO(OO)
    }

    function eO(OO) {
      return OO.includes(" Strongbed")
    }

    function lO(OO) {
      return XO(OO) || bK(OO) || eO(OO)
    }
    pO.d(KO, {
      c: () => lO,
      g: () => XO,
      k: () => eO,
      l: () => bK
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);