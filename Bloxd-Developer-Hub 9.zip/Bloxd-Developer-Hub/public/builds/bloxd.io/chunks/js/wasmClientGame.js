export const id = 48;
export const ids = [48];
export const modules = {
  40636: (OO, KO, pO) => {
    var XO = {
      "./bedwars/bedwarsClient": [37611, 9],
      "./bridgeBattle/bridgeBattleClient": [37618, 10],
      "./buildAFactory2/buildAFactory2Client": [36883, 65, 63, 207, 224, 11],
      "./classic/classicClient": [37622, 12],
      "./clutch/clutchClient": [37630, 13],
      "./cooking/cookingClient": [37638, 14],
      "./defusal/defusalClient": [37647, 15],
      "./frontline/frontlineClient": [37651, 65, 63, 16],
      "./goalRush/goalRushClient": [37656, 17],
      "./luckyBedwars/luckyBedwarsClient": [37661, 18],
      "./ninetyNineNights/ninetyNineNightsClient": [37670, 19],
      "./oneBlock/oneBlockClient": [37673, 20],
      "./plots/plotsClient": [37682, 205, 228, 21],
      "./pvpCiv/pvpCivClient": [37749, 22],
      "./skyIslands/skyIslandsClient": [37758, 23],
      "./skyblock/skyblockClient": [36913, 65, 207, 179, 24],
      "./tsunami/tsunamiClient": [37761, 25]
    };

    function bK(OO) {
      if (!pO.o(XO, OO)) return Promise.resolve().then((() => {
        var KO = new Error("Cannot find module '" + OO + "'");
        throw KO.code = "MODULE_NOT_FOUND", KO
      }));
      var KO = XO[OO],
        bK = KO[0];
      return Promise.all(KO.slice(1).map(pO.e)).then((() => pO(bK)))
    }
    bK.keys = () => Object.keys(XO), bK.id = 40636, OO.exports = bK
  },
  35020: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => eO
    });
    let XO = !1;

    function bK() {
      return XO
    }

    function eO(OO) {
      return XO !== OO && (XO = OO, !0)
    }
  },
  37373: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      i: () => bK
    });
    var XO = pO(26);

    function bK(OO) {
      return "refetchCode" === OO || "devDownloadJson" === OO || OO.startsWith("Plugin")
    }

    function eO(OO, KO) {
      "refetchCode" !== OO ? "Plugin|MobAiPlugin|ShowPetUi" !== OO ? Promise.all([pO.e(94), pO.e(95), pO.e(90), pO.e(92), pO.e(195)]).then((() => pO(39755))).then((pO => {
        let {
          runClientGameMessage: XO
        } = pO;
        XO(OO, KO)
      })).catch((KO => {
        console.error(`Game message ${OO} failed`, KO)
      })) : XO.i.pl("showPetUi", KO) : XO.i.pl("refetchCode")
    }
  },
  40618: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      g: () => bK
    });
    const XO = ["recording", "freecam", "keyframe"];

    function bK() {
      const OO = crypto.getRandomValues(new Uint32Array(2));
      return BigInt(OO[1]) << 32n | BigInt(OO[0])
    }
  },
  8290: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      g: () => CO
    });
    var XO = pO(22);
    const bK = 24,
      eO = "farNametags",
      lO = 1e5;

    function vK() {
      var OO;
      return null === (OO = XO.d.get("showDistantNametags")) || void 0 === OO || OO
    }

    function CO() {
      var OO;
      return null !== (OO = function() {
        const OO = new URLSearchParams(window.location.search).get(eO),
          KO = null === OO || "" === OO ? NaN : Number(OO);
        return Number.isFinite(KO) && KO >= 0 ? Math.min(KO, lO) : null
      }()) && void 0 !== OO ? OO : vK() ? 0 : bK
    }
  },
  40610: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      blockIdOf: () => uC.d,
      clearWasmCameraScreen: () => kb,
      creativeItemIds: () => pX.creativeItemIds,
      decodeMapSettings: () => YC,
      drainTextRerasters: () => wv.e,
      enchantmentPerksOf: () => pX.enchantmentPerksOf,
      endGameHost: () => JC,
      followCursorAim: () => jh,
      followMenuPrefs: () => nb,
      loadAudio: () => mh,
      loadClientGame: () => PC,
      loadTextIcons: () => wv.i,
      rasterText: () => Yv.c,
      readBoardToEdit: () => gh,
      setTextHost: () => wv.l,
      setTextLocalPlayer: () => wv.n,
      showInCreativeInvenOf: () => pX.showInCreativeInvenOf,
      startGameHost: () => SC,
      startShellAnalytics: () => NC,
      startSkyFeed: () => Uv,
      textChanged: () => wv.s,
      warmText: () => Yv.e,
      wasmCameraScreen: () => tb
    });
    pO(35033);
    var XO = pO(22),
      bK = pO(35308),
      eO = pO(37505),
      lO = pO(26),
      vK = pO(35069),
      CO = pO(35301),
      hO = pO(1136),
      DO = pO(518),
      MO = pO(36620),
      aK = pO(3934),
      oO = pO(38732),
      FO = pO(38667);
    const VO = FO.zb / 4,
      LO = FO.n.PlaySound,
      QO = FO.n.SoundReset,
      zK = aK.V.ReplayFailed,
      AO = aK.V.RecorderEvent;
    class fO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        this.core = OO, this.memory = KO, this.audio = pO, this.serverIds = new Int32Array(256).fill(FO.Vc), this.kinds = new Uint16Array(256), this.idStr = new Array(256).fill(null), this.indexById = new Map, this.queries = void 0, this.buffer = null, this.viewPtr = -1, this.view = new DataView(new ArrayBuffer(FO.t.BYTES)), this.renderPtr = 0, this.YO = 0, this.renderCapacity = 0, this.render = new Float32Array(0), this.visPtr = 0, this.vis = new Uint8Array(0), this.renderBuffer = null, this.eventsBuffer = null, this.eventsPtr = 0, this.eventsLen = 0, this.events = new DataView(new ArrayBuffer(0)), this.audioView = null, this.scratchPtr = -1, this.corruption = null, this.replay = null, this.queries = new FO.W(OO, (() => {
          this.scratchPtr = -1, this.ensureViews()
        }))
      }
      scratch() {
        return this.scratchPtr < 0 && (this.scratchPtr = this.core.OMO(), this.ensureViews()), this.scratchPtr
      }
      eventBytes(OO, KO) {
        const pO = this.eventView();
        return new Uint8Array(pO.buffer, pO.byteOffset + OO, KO)
      }
      get apiView() {
        return this.ensureViews(), this.view
      }
      ensureViews() {
        this.memory().buffer !== this.buffer && this.reView()
      }
      get localId() {
        return FO.t.localId(this.apiView, 0)
      }
      localDeaths() {
        return FO.t.localDeaths(this.apiView, 0)
      }
      rereadDirectory() {
        const OO = this.apiView,
          KO = FO.t.entRenderPtr(OO, 0),
          pO = FO.t.entVisPtr(OO, 0),
          XO = FO.t.entCapacity(OO, 0);
        if (KO !== this.renderPtr || pO !== this.visPtr || XO !== this.YO || this.renderBuffer !== this.buffer) {
          this.renderPtr = KO, this.visPtr = pO, this.YO = XO, this.renderBuffer = this.buffer;
          const OO = this.memoryView(Float32Array, KO, XO * VO, "the render array"),
            bK = this.memoryView(Uint8Array, pO, XO, "the visibility array");
          this.renderCapacity = OO && bK ? XO : 0, this.render = OO && bK ? OO : new Float32Array(0), this.vis = OO && bK ? bK : new Uint8Array(0)
        }
      }
      memoryView(OO, KO, pO, XO) {
        try {
          return (0, oO.r)(OO, this.memory().buffer, KO, pO, XO)
        } catch (bK) {
          return this.keepCorruption(bK), null
        }
      }
      memoryData(OO, KO, pO, XO) {
        try {
          return (0, oO.h)(this.memory().buffer, OO, KO, pO, XO)
        } catch (bK) {
          return this.keepCorruption(bK), null
        }
      }
      reportCorruption(OO) {
        this.keepCorruption(new oO.e(OO))
      }
      keepCorruption(OO) {
        if (!(OO instanceof oO.e)) throw OO;
        this.corruption ??= OO
      }
      throwCorruption() {
        if (this.corruption) throw this.corruption
      }
      walk(OO, KO, pO) {
        this.rereadDirectory(), this.throwCorruption();
        const {
          ptr: XO,
          len: bK
        } = OO;
        this.eventsPtr = XO, this.eventsLen = bK, this.eventsBuffer = null;
        const eO = this.eventView();
        for (let hO = 0; hO < bK;) {
          const OO = eO.getUint32(hO, !0),
            pO = 65535 & OO,
            XO = OO >>> 16,
            bK = hO + aK.R;
          if (pO === FO.n.EntitySpawned) {
            var lO;
            if (XO !== FO.Gb.BYTES) throw yK(pO, hO, XO);
            const OO = FO.Gb.serverId(eO, bK);
            this.spawned(OO, FO.Gb.index(eO, bK), FO.Gb.kind(eO, bK)), null === (lO = KO.entityAdded) || void 0 === lO || lO.call(KO, OO)
          } else if ((pO === FO.n.ChunkSlot || pO === FO.n.EntityInfoChanged) && !(0, FO.ke)(pO, eO, bK, XO, KO)) throw yK(pO, hO, XO);
          hO = bK + (0, aK.ne)(XO)
        }
        try {
          var vK;
          null === (vK = KO.afterPrescan) || void 0 === vK || vK.call(KO), this.throwCorruption(), !pO() && this.dispatch(OO, KO, pO) && (this.throwCorruption(), this.applyListener(), KO.afterWalk(OO.kind)), this.throwCorruption()
        } catch (CO) {
          throw CO instanceof oO.e && (this.corruption ??= CO), CO
        } finally {
          pO() || null !== this.corruption || this.applyDespawns(bK, KO)
        }
      }
      applyDespawns(OO, KO) {
        const pO = this.eventView();
        for (let bK = 0; bK < OO;) {
          const OO = pO.getUint32(bK, !0),
            eO = bK + aK.R;
          if ((65535 & OO) === FO.n.EntityDespawned && OO >>> 16 === FO.Gb.BYTES) {
            const OO = FO.Gb.serverId(pO, eO);
            var XO;
            if (this.despawned(OO, FO.Gb.index(pO, eO))) null === (XO = KO.entityRemoved) || void 0 === XO || XO.call(KO, OO)
          }
          bK = eO + (0, aK.ne)(OO >>> 16)
        }
        this.rereadDirectory()
      }
      dispatch(OO, KO, pO) {
        const {
          len: XO,
          net: bK,
          netOffsets: eO
        } = OO;
        let lO = this.eventView(),
          vK = 0;
        for (let TO = 0; TO < XO;) {
          const OO = lO.getUint32(TO, !0),
            XO = 65535 & OO,
            NO = OO >>> 16,
            gK = TO + aK.R;
          let uO = !1;
          if (vK < bK.length && eO[vK] === TO) KO.netEvent(bK[vK]), vK++, uO = !0;
          else if (XO === aK.V.LocalPlayerBound) {
            var CO;
            if (NO !== aK.Fb) throw yK(XO, TO, NO);
            null === (CO = KO.localPlayerBound) || void 0 === CO || CO.call(KO, lO.getInt32(gK, !0)), uO = !0
          } else if (XO === aK.V.LocalHurt) {
            var hO;
            if (NO !== aK.Eb) throw yK(XO, TO, NO);
            null === (hO = KO.localHurt) || void 0 === hO || hO.call(KO, lO.getInt32(gK, !0), lO.getFloat32(gK + 4, !0), lO.getUint32(gK + 8, !0)), uO = !0
          } else if (XO === aK.V.AttackHit) {
            var DO;
            if (NO !== aK.d) throw yK(XO, TO, NO);
            const OO = lO.getFloat32(gK, !0),
              pO = lO.getFloat32(gK + 4, !0),
              bK = lO.getFloat32(gK + 8, !0),
              eO = lO.getUint32(gK + 12, !0);
            null === (DO = KO.attackHit) || void 0 === DO || DO.call(KO, OO, pO, bK, 0 !== (eO & aK.o.Crit), 0 !== (eO & aK.o.HitSelf))
          } else if (XO === aK.V.PhysicsType) {
            var MO;
            if (NO !== aK.Zb) throw yK(XO, TO, NO);
            null === (MO = KO.physicsType) || void 0 === MO || MO.call(KO, lO.getUint32(gK, !0), lO.getInt32(gK + 4, !0)), uO = !0
          } else if (XO === aK.V.VehicleEffect) {
            var oO;
            const OO = IO(lO, gK, NO);
            if (null === OO) throw yK(XO, TO, NO);
            null === (oO = KO.vehicleEffect) || void 0 === oO || oO.call(KO, OO.op, OO.name, OO.icon, OO.level, OO.durationMs), uO = !0
          } else if (XO === aK.V.ZoomChanged) {
            var VO;
            if (NO !== aK.Vd) throw yK(XO, TO, NO);
            null === (VO = KO.zoomChanged) || void 0 === VO || VO.call(KO, lO.getFloat32(gK, !0), lO.getUint8(gK + 4)), uO = !0
          } else if (XO === aK.V.ZoomDisabled) {
            var fO;
            if (0 !== NO) throw yK(XO, TO, NO);
            null === (fO = KO.zoomDisabled) || void 0 === fO || fO.call(KO), uO = !0
          } else if (XO === aK.V.GameCamera) {
            var dO;
            null === (dO = KO.gameCamera) || void 0 === dO || dO.call(KO, new Uint8Array(lO.buffer, lO.byteOffset + gK, NO).slice()), uO = !0
          } else if (XO === FO.n.ChunkSlot || XO === FO.n.EntityInfoChanged);
          else if (XO >= LO && XO <= QO) {
            if (this.audio && !this.audio.onAudioEvent(XO, lO, gK, NO)) throw yK(XO, TO, NO)
          } else if (XO >= zK && XO <= AO) {
            if (this.replay) {
              if (!this.replay.onReplayEvent(XO, lO, gK, NO)) throw yK(XO, TO, NO);
              uO = !0
            }
          } else if (XO >= FO.hd && XO <= FO.id && XO !== aK.V.EnvLighting) {
            if (!(0, FO.ke)(XO, lO, gK, NO, KO)) throw yK(XO, TO, NO);
            uO = !0
          }
          if (uO) {
            if (pO()) return !1;
            lO = this.eventView()
          }
          TO = gK + (0, aK.ne)(NO)
        }
        return !pO()
      }
      applyListener() {
        var OO;
        if (!this.audio) return;
        const KO = FO.t.audioViewPtr(this.apiView, 0),
          pO = this.memory().buffer;
        let XO = this.audioView;
        (null === (OO = XO) || void 0 === OO ? void 0 : OO.buffer) === pO && XO.byteOffset === KO || (XO = (0, oO.h)(pO, KO, FO.v.BYTES, 8, "the audio view"), this.audioView = XO), XO && this.audio.applyListener(XO)
      }
      indexOf(OO) {
        return this.indexById.get("number" === typeof OO ? OO : +OO)
      }
      isLocal(OO) {
        return OO !== FO.Vc && OO === FO.t.localId(this.apiView, 0)
      }
      fV(OO) {
        const KO = [0, 0, 0];
        return this.readPosition("number" === typeof OO ? OO : +OO, KO) ? KO : null
      }
      readPosition(OO, KO) {
        const pO = this.apiView;
        if (void 0 !== this.indexById.get(OO) && this.isLocal(OO)) {
          for (let OO = 0; OO < 3; OO++) KO[OO] = FO.t.localPos(pO, 0, OO);
          return !0
        }
        return this.readDrawnPosition(OO, KO)
      }
      readDrawnPosition(OO, KO) {
        const pO = this.apiView,
          XO = this.indexById.get(OO);
        if (void 0 === XO || XO >= this.renderCapacity) return KO[0] = KO[1] = KO[2] = NaN, !1;
        const bK = XO * VO;
        for (let eO = 0; eO < 3; eO++) KO[eO] = this.render[bK + eO] + FO.t.origin(pO, 0, eO);
        return !0
      }
      checkValid(OO) {
        return void 0 !== this.indexOf(OO)
      }
      isAlive(OO) {
        const KO = this.indexOf(OO);
        if (void 0 === KO) return null;
        if (this.ensureViews(), KO >= this.renderCapacity) return null;
        const pO = this.vis[KO];
        return 0 === pO ? null : 0 !== (pO & FO.he.Alive)
      }
      getEntityType(OO) {
        const KO = this.indexOf(OO);
        return void 0 === KO ? this.isLocal("number" === typeof OO ? OO : +OO) ? "Player" : null : TO(this.kinds[KO])
      }
      spawned(OO, KO, pO) {
        if (KO >= 1048576) throw new oO.e(`entity ${OO} spawned at index ${KO}`);
        this.ensureIndex(KO), this.serverIds[KO] === OO && null !== this.idStr[KO] || (this.idStr[KO] = String(OO)), this.serverIds[KO] = OO, this.kinds[KO] = pO, this.indexById.set(OO, KO)
      }
      despawned(OO, KO) {
        let pO = !1;
        return this.indexById.get(OO) === KO && (this.indexById.delete(OO), pO = !0), KO < this.serverIds.length && this.serverIds[KO] === OO && (this.serverIds[KO] = FO.Vc, this.kinds[KO] = 0, this.idStr[KO] = null), pO
      }
      ensureIndex(OO) {
        const KO = this.serverIds.length;
        if (OO < KO) return;
        let pO = 2 * KO;
        for (; pO <= OO;) pO *= 2;
        const XO = new Int32Array(pO).fill(FO.Vc);
        XO.set(this.serverIds), this.serverIds = XO;
        const bK = new Uint16Array(pO);
        bK.set(this.kinds), this.kinds = bK;
        for (let eO = KO; eO < pO; eO++) this.idStr.push(null)
      }
      eventView() {
        const OO = this.memory().buffer;
        return OO !== this.eventsBuffer && (this.eventsBuffer = OO, this.events = new DataView(OO, this.eventsPtr, this.eventsLen)), this.events
      }
      reView() {
        const OO = this.memory().buffer;
        this.buffer = OO, this.viewPtr < 0 && (this.viewPtr = this.core.KMO()), this.view = new DataView(OO, this.viewPtr, FO.t.BYTES), this.rereadDirectory()
      }
    }

    function dO(OO) {
      return OO >>> FO.e === FO.r.Item
    }

    function TO(OO) {
      var KO, pO;
      const XO = OO & FO.h;
      switch (OO >>> FO.e) {
        case FO.r.Lifeform:
          return null !== (KO = DO.h[XO]) && void 0 !== KO ? KO : null;
        case FO.r.Throwable:
          return null !== (pO = MO.j[XO]) && void 0 !== pO ? pO : null;
        case FO.r.Mesh:
          return "Mesh";
        case FO.r.Audio:
          return "AudioEntity";
        case FO.r.Item:
          return "Item";
        default:
          return null
      }
    }
    const NO = new TextDecoder;

    function IO(OO, KO, pO) {
      if (pO < aK.sd.HEAD_BYTES) return null;
      const XO = OO.getUint32(KO, !0),
        bK = OO.getUint32(KO + 20, !0),
        eO = OO.getUint32(KO + 24, !0),
        lO = aK.sd.HEAD_BYTES + (0, aK.ne)(bK);
      if (XO !== aK.sd.UPDATE && XO !== aK.sd.REMOVE || bK > pO || lO + eO > pO) return null;
      const vK = (pO, XO) => NO.decode(new Uint8Array(OO.buffer, OO.byteOffset + KO + pO, XO)),
        CO = OO.getFloat64(KO + 12, !0);
      return {
        op: XO,
        level: OO.getFloat64(KO + 4, !0),
        durationMs: Number.isNaN(CO) ? null : CO,
        name: vK(aK.sd.HEAD_BYTES, bK),
        icon: vK(lO, eO)
      }
    }

    function yK(OO, KO, pO) {
      return new oO.e(`event ${OO} at ${KO} of ${pO} bytes`)
    }
    var gK = pO(256),
      uO = pO(1077),
      EO = pO(37373),
      jK = pO(1567),
      YO = pO(38783),
      wO = pO(1531),
      iK = pO(37531),
      rK = pO(37560),
      PO = pO(37547),
      mK = pO(38717),
      sO = pO(1969),
      HO = pO(37522),
      RO = pO(37556);
    const SO = Math.max(FO.pb.BYTES, FO.hb.BYTES, FO.jb.BYTES);

    function JO(OO) {
      if (!(0, RO.g)(OO)) return null;
      const KO = Number(OO);
      return (0 | KO) === KO ? KO : null
    }
    class cK {
      constructor(OO) {
        this.api = OO, this.bodyHeading = 0, this.viewHeading = 0, this.defaultPose = (0, HO.m)(), this.defaultPoseRead = !1, this.defaultFov = 0, this.baseFov = 0, this.aspect = 1, this.Om = null, this.entityLive = !1, this.entityFeet = [0, 0, 0], this.entityAim = [0, 0, 0], this.entityHeading = 0, this.localId = FO.Vc, this.localName = String(FO.Vc), this.scratch = null
      }
      readView() {
        this.defaultPoseRead = !1, this.Om = null;
        const OO = this.api.queries.directorView() >= FO.pb.BYTES ? this.scratchView() : null;
        null !== OO && (this.defaultFov = (0, wO.A)(FO.pb.fov(OO, 0)), this.baseFov = (0, wO.A)(FO.pb.baseFov(OO, 0)), this.aspect = FO.pb.aspect(OO, 0), this.bodyHeading = FO.pb.bodyHeading(OO, 0))
      }
      getViewHeading() {
        return this.viewHeading
      }
      setViewHeading(OO) {
        this.viewHeading = OO
      }
      get localPlayerId() {
        const OO = FO.t.localId(this.api.apiView, 0);
        return OO !== this.localId && (this.localId = OO, this.localName = String(OO)), this.localName
      }
      getEntityPosition(OO) {
        return this.readEntity(OO) ? this.entityFeet : null
      }
      getEntityAimPoint(OO) {
        return this.readEntity(OO) ? this.entityAim : null
      }
      getEntityHeading(OO) {
        const KO = JO(OO);
        if (null === KO) return null;
        const pO = FO.t.localId(this.api.apiView, 0);
        return KO === pO && pO !== FO.Vc ? this.viewHeading : this.readEntity(OO) ? this.entityHeading : null
      }
      raycastTerrain(OO, KO, pO) {
        const XO = this.api.queries.cameraSweep(OO[0], OO[1], OO[2], KO[0], KO[1], KO[2], pO);
        return XO < pO - 1e-6 ? XO : null
      }
      getDefaultPose() {
        if (this.defaultPoseRead) return this.defaultPose;
        this.defaultPoseRead = !0;
        const OO = this.defaultPose;
        OO.fov = this.defaultFov;
        const KO = this.api.queries.directorDefaultPose() >= FO.hb.BYTES ? this.scratchView() : null;
        if (null === KO) return OO;
        for (let pO = 0; pO < 3; pO++) OO.position[pO] = FO.hb.eye(KO, 0, pO);
        return OO.heading = FO.hb.heading(KO, 0), OO.pitch = FO.hb.pitch(KO, 0), OO
      }
      getDefaultFov() {
        return this.defaultFov
      }
      getBaseFov() {
        return this.baseFov
      }
      getAspectRatio() {
        return this.aspect
      }
      readEntity(OO) {
        const KO = JO(OO);
        if (null === KO) return !1;
        if (KO === this.Om) return this.entityLive;
        this.Om = KO;
        const pO = this.api.queries.directorEntity(KO) >= FO.jb.BYTES ? this.scratchView() : null;
        if (this.entityLive = null !== pO, null === pO) return !1;
        for (let XO = 0; XO < 3; XO++) this.entityFeet[XO] = FO.jb.feet(pO, 0, XO), this.entityAim[XO] = this.entityFeet[XO];
        return this.entityAim[1] += FO.jb.eyeHeight(pO, 0), this.entityHeading = FO.jb.heading(pO, 0), !0
      }
      scratchView() {
        const OO = this.api.scratch(),
          KO = this.api.memory().buffer,
          pO = this.scratch;
        return null !== pO && pO.buffer === KO && pO.byteOffset === OO ? pO : (this.scratch = this.api.memoryData(OO, SO, 8, "the director's record"), this.scratch)
      }
    }
    const BO = {
        mode: "default"
      },
      ZO = {
        show: () => {},
        clear: () => {}
      };

    function GO() {
      return "undefined" !== typeof document && "hidden" === document.visibilityState
    }
    class qK {
      constructor(OO) {
        this.options = OO, this.lK = void 0, this.director = void 0, this.latest = BO, this.pending = void 0, this.shownSettings = null, this.facing = "movement", this.mouseTurns = "view", this.look = {
          wKO: 0,
          ipO: 0
        }, this.pointedAt = {
          heading: 0,
          pitch: 0
        }, this.engaged = !1, this.calledThisFrame = !1, this.holding = !1, this.lastCallMs = 0, this.answeredPose = !1, this.gp = new Int32Array(3 * FO.Ld), this.centresLen = 0, this.centresUnsent = !1, this.next = new Int32Array(3 * FO.Ld), this.lK = new cK(OO.api), this.director = new PO.c(this.lK)
      }
      settingsChanged(OO) {
        let KO = BO;
        if (OO.length > 0) try {
          KO = (0, mK.c)(OO)
        } catch {}
        this.latest = KO, this.pending = KO
      }
      call(OO, KO, pO, XO, bK, eO) {
        var lO, vK;
        let CO;
        this.holding = !1;
        try {
          CO = this.answer(OO, KO, pO, XO, bK, eO)
        } catch (aK) {
          var hO, DO;
          throw this.answeredPose = !1, null === (hO = (DO = this.options).showFacing) || void 0 === hO || hO.call(DO, null), aK
        }
        const MO = this.answeredPose && 0 === (XO & FO.mb.Held);
        return this.answeredPose = CO !== FO.gb.None, this.holding = this.answeredPose && !MO, null === (lO = (vK = this.options).showFacing) || void 0 === lO || lO.call(vK, this.holding ? this.facing : null), CO
      }
      holdsView() {
        return this.holding
      }
      answer(OO, KO, pO, XO, bK, eO) {
        this.calledThisFrame = !0, this.engaged = !0, this.lastCallMs = this.now();
        const {
          lK: lO
        } = this;
        lO.readView();
        if (0 !== (XO & FO.mb.Held) || lO.setViewHeading((0, iK.t)(lO.bodyHeading)), void 0 !== this.pending) {
          const OO = this.pending;
          this.pending = void 0, this.director.setSettings(OO), this.syncShownSettings()
        }
        this.readLook((0, sO.f)(KO), (0, sO.f)(pO), XO, (0, sO.f)(bK), (0, sO.f)(eO));
        const vK = this.director.update(OO / 1e3, this.look);
        if (this.syncShownSettings(), this.writeCentres(this.director.getLoadingPositions()), this.hidden() || this.screen().show(this.director.getScreenFade(), this.director.getSettings()), !vK) return FO.gb.None;
        const [CO, hO, DO] = vK.position;
        if (0 === this.options.api.queries.directorPose(CO, hO, DO, (0, iK.t)(vK.heading), (0, iK.g)(vK.pitch), (0, wO.n)(vK.fov))) return FO.gb.None;
        if ("default" === this.director.getSettings().mode) return FO.gb.Pose;
        switch (this.facing) {
          case "camera":
            return FO.gb.FaceCamera;
          case "cursor":
            return FO.gb.FaceCursor;
          default:
            return FO.gb.FaceMovement
        }
      }
      afterFrame(OO) {
        OO ? (this.calledThisFrame || (this.holding = !1, this.engaged && this.idle()), this.calledThisFrame = !1) : this.centresLen > 0 && this.hidden() && this.now() - this.lastCallMs > 1e3 && this.setCentres(0), this.centresUnsent && this.sendCentres()
      }
      reset() {
        this.latest = BO, this.idle()
      }
      restart() {
        const OO = this.holding;
        this.idle(), this.holding = OO
      }
      idle() {
        var OO, KO;
        this.engaged && this.screen().clear(), this.engaged = !1, this.holding = !1, this.director = new PO.c(this.lK), this.pending = this.latest, this.shownSettings = null, this.facing = "movement", this.mouseTurns = "view", this.answeredPose = !1, null === (OO = (KO = this.options).showFacing) || void 0 === OO || OO.call(KO, null), this.setCentres(0)
      }
      syncShownSettings() {
        const OO = this.director.getSettings();
        if (OO === this.shownSettings) return;
        this.shownSettings = OO;
        const KO = (0, rK.f)(OO);
        this.facing = KO.facing, this.mouseTurns = KO.mouseTurns
      }
      readLook(OO, KO, pO, XO, bK) {
        const eO = this.look,
          lO = 0 !== (pO & FO.mb.LookPointed);
        if (null === this.mouseTurns && !lO) return eO.wKO = 0, eO.ipO = 0, void(eO.pointedAt = void 0);
        let vK;
        lO && (this.pointedAt.heading = XO, this.pointedAt.pitch = bK, vK = this.pointedAt);
        const {
          lK: CO
        } = this;
        CO.setViewHeading((0, rK.d)(CO.getViewHeading(), OO, KO, vK, "look" === this.mouseTurns, eO))
      }
      writeCentres(OO) {
        const KO = this.next,
          pO = Math.min(OO.length, FO.Ld);
        for (let XO = 0; XO < pO; XO++)
          for (let pO = 0; pO < 3; pO++) KO[3 * XO + pO] = Math.floor(OO[XO][pO] / FO.z);
        this.setCentres(pO)
      }
      setCentres(OO) {
        const {
          gp: KO,
          next: pO
        } = this;
        let XO = OO === this.centresLen;
        for (let bK = 0; XO && bK < 3 * OO; bK++) XO = KO[bK] === pO[bK];
        XO || (KO.fill(0), KO.set(pO.subarray(0, 3 * OO)), this.centresLen = OO, this.centresUnsent = !0, this.sendCentres())
      }
      sendCentres() {
        const OO = this.options.cmd();
        null !== OO && (0, FO.xf)(OO, 0, this.gp, this.centresLen) && (this.centresUnsent = !1)
      }
      screen() {
        var OO, KO, pO;
        return null !== (OO = null === (KO = (pO = this.options).screen) || void 0 === KO ? void 0 : KO.call(pO)) && void 0 !== OO ? OO : ZO
      }
      hidden() {
        var OO;
        return (null !== (OO = this.options.isPageHidden) && void 0 !== OO ? OO : GO)()
      }
      now() {
        var OO, KO, pO;
        return null !== (OO = null === (KO = (pO = this.options).now) || void 0 === KO ? void 0 : KO.call(pO)) && void 0 !== OO ? OO : performance.now()
      }
    }
    const xK = FO.z * FO.z * FO.z,
      nO = Math.log2(FO.z),
      WO = FO.z - 1,
      tK = FO.O.BYTES / 4,
      kK = new Uint16Array(xK);

    function UO(OO, KO, pO) {
      return OO * FO.z * FO.z + KO * FO.z + pO
    }
    class OK {
      constructor(OO) {
        this.chunk = OO
      }
      get data() {
        return this.chunk.gameVoxels()
      }
      index(OO, KO, pO) {
        return UO(OO, KO, pO)
      }
    }
    class KK {
      constructor() {
        this.ids = new Map, this.cleared = new Set, this.layers = 0, this.patched = null, this.from = null
      }
    }
    class pK {
      constructor(OO, KO, pO, XO) {
        this.table = OO, this.slot = KO, this.generation = pO, this.epoch = XO, this.PK = new OK(this), this.writes = null, this.writeCount = 0, this.shownVersion = 0, this.shownCore = -1, this.shownWrites = -1, this.data = kK, this.dataPtr = 0, this.dataBuffer = null, this.dataStamp = -1, this.version = 0, this.layers = null, this.layersVersion = -1, this.layersPtr = -1, this.staleLayers = 0
      }
      get ae() {
        return this.voxelData(), this.version === this.shownCore && this.writeCount === this.shownWrites || (this.shownCore = this.version, this.shownWrites = this.writeCount, this.shownVersion = this.table.nextVersion()), this.shownVersion
      }
      get mX() {
        const OO = this.gameVoxels(),
          KO = this.layers ??= new Uint16Array(FO.z);
        this.layersVersion === this.version && this.layersPtr === this.dataPtr || (this.layersVersion = this.version, this.layersPtr = this.dataPtr, this.staleLayers = -1);
        for (let pO = 0; 0 !== this.staleLayers; pO++) {
          const XO = 1 << pO;
          0 !== (this.staleLayers & XO) && (this.staleLayers &= ~XO, KO[pO] = XK(OO, pO))
        }
        return KO
      }
      voxelData() {
        return this.dataStamp === this.table.stamp && 0 !== this.data.length ? this.data : this.reread()
      }
      gameVoxels() {
        const OO = this.voxelData(),
          KO = this.writes;
        if (null === KO || 0 === KO.ids.size) return OO;
        if (KO.from !== OO) {
          const pO = KO.patched ??= new Uint16Array(xK);
          pO.set(OO);
          for (const [OO, XO] of KO.ids) pO[OO] = XO;
          KO.from = OO
        }
        return KO.patched
      }
      written(OO) {
        var KO;
        return null === (KO = this.writes) || void 0 === KO ? void 0 : KO.ids.get(OO)
      }
      hasWrites() {
        return null !== this.writes && 0 !== this.writes.ids.size
      }
      write(OO, KO, pO) {
        const XO = this.writes ??= new KK;
        XO.ids.set(OO, KO), pO && XO.cleared.add(OO), null !== XO.from && (XO.patched[OO] = KO);
        const bK = 1 << (OO >> nO & WO);
        XO.layers |= bK, this.staleLayers |= bK, this.writeCount++
      }
      clearWrites() {
        const OO = this.writes;
        null !== OO && (this.staleLayers |= OO.layers, OO.ids.clear(), OO.cleared.clear(), OO.layers = 0, OO.from = null)
      }
      dataCleared(OO) {
        var KO;
        return !0 === (null === (KO = this.writes) || void 0 === KO ? void 0 : KO.cleared.has(OO))
      }
      reread() {
        this.dataStamp = this.table.stamp;
        const OO = this.table.slotWords(),
          KO = this.slot * tK;
        if (this.epoch !== this.table.epoch || KO + tK > OO.length || 0 === OO[KO + 3] || OO[KO + 2] !== this.generation) return this.data = kK, this.dataPtr = 0, kK;
        this.version = OO[KO + 1];
        const pO = OO[KO + 0],
          XO = OO.buffer;
        return pO === this.dataPtr && XO === this.dataBuffer || (this.dataPtr = pO, this.dataBuffer = XO, this.data = this.table.voxelsAt(XO, pO)), this.data
      }
    }

    function XK(OO, KO) {
      const pO = OO[KO * FO.z];
      for (let XO = 0; XO < FO.z; XO++) {
        const bK = UO(XO, KO, 0);
        for (let KO = 0; KO < FO.z; KO++)
          if (OO[bK + KO] !== pO) return 65535
      }
      return pO
    }
    const bp = new Uint32Array(0),
      eK = 1 << 20,
      lK = 1 << 21;

    function vp(OO, KO, pO) {
      const XO = OO + eK,
        bK = KO + 1024,
        eO = pO + eK;
      return XO < 0 || XO >= lK || eO < 0 || eO >= lK || bK < 0 || bK >= 2048 ? -1 : 2048 * (XO * lK + eO) + bK
    }

    function CK(OO, KO, pO) {
      return UO(OO & WO, KO & WO, pO & WO)
    }
    class hK {
      constructor(OO, KO) {
        this.memory = OO, this.apiView = KO, this.chunks = new Map, this.written = [], this.lastKey = -1, this.lastChunk = void 0, this.slotsPtr = 0, this.slotsLen = 0, this.slotsBuffer = null, this.slots = bp, this.walkPtr = 0, this.walkLen = 0, this.walkBuffer = null, this.walk = bp, this.epoch = 0, this.stamp = 0, this.versions = 0, this.corruption = null
      }
      apply(OO, KO, pO, XO, bK, eO) {
        if (this.lastKey = -1, this.lastChunk = void 0, this.stamp++, eO === FO.Q.ResetAll) return this.chunks.clear(), void this.epoch++;
        if (eO !== FO.Q.Stored && eO !== FO.Q.Unloaded) throw new oO.e(`ChunkSlot flags ${eO}`);
        const lO = vp(OO, KO, pO);
        if (lO < 0) return;
        if (eO === FO.Q.Unloaded) return void this.chunks.delete(lO);
        const vK = this.chunks.get(lO);
        (null === vK || void 0 === vK ? void 0 : vK.slot) === XO && vK.generation === bK || this.chunks.set(lO, new pK(this, XO, bK, this.epoch))
      }
      touch() {
        this.stamp++, this.clearOverlay(), this.viewWalkThrough()
      }
      refresh() {
        if (this.stamp++, this.corruption) throw this.corruption;
        const OO = this.apiView(),
          KO = FO.t.chunkSlotsPtr(OO, 0),
          pO = FO.t.chunkSlotsLen(OO, 0);
        KO === this.slotsPtr && pO === this.slotsLen || (this.slotsPtr = KO, this.slotsLen = pO, this.slotsBuffer = null, this.slotWords()), this.viewWalkThrough(), this.clearOverlay()
      }
      viewWalkThrough() {
        const OO = this.apiView(),
          KO = FO.t.walkThroughPtr(OO, 0),
          pO = FO.t.walkThroughLen(OO, 0);
        KO === this.walkPtr && pO === this.walkLen || (this.walkPtr = KO, this.walkLen = pO, this.walkBuffer = null, this.walkWords())
      }
      clearOverlay() {
        for (const OO of this.written) OO.clearWrites();
        this.written.length = 0
      }
      nextVersion() {
        return ++this.versions
      }
      slotWords() {
        const OO = this.memory().buffer;
        var KO;
        OO !== this.slotsBuffer && (this.slotsBuffer = OO, this.slots = null !== (KO = (0, oO.r)(Uint32Array, OO, this.slotsPtr, this.slotsLen * tK, "the chunk directory")) && void 0 !== KO ? KO : bp);
        return this.slots
      }
      voxelsAt(OO, KO) {
        try {
          var pO;
          return null !== (pO = (0, oO.r)(Uint16Array, OO, KO, xK, "a chunk's voxels")) && void 0 !== pO ? pO : kK
        } catch (XO) {
          if (!(XO instanceof oO.e)) throw XO;
          return this.corruption ??= XO, kK
        }
      }
      chunk(OO, KO, pO) {
        var XO;
        return null !== (XO = this.chunks.get(vp(OO, KO, pO))) && void 0 !== XO ? XO : null
      }
      isLoaded(OO, KO, pO) {
        return void 0 !== this.chunkAt(Math.floor(OO), Math.floor(KO), Math.floor(pO))
      }
      yl(OO, KO, pO) {
        var XO;
        const bK = Math.floor(OO),
          eO = Math.floor(KO),
          lO = Math.floor(pO),
          vK = this.chunkAt(bK, eO, lO);
        if (!vK) return 0;
        const CO = CK(bK, eO, lO);
        return null !== (XO = vK.written(CO)) && void 0 !== XO ? XO : vK.voxelData()[CO]
      }
      setOverlay(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        const eO = this.chunkAt(OO, KO, pO);
        return !!eO && (eO.hasWrites() || this.written.push(eO), eO.write(CK(OO, KO, pO), XO, bK), !0)
      }
      version(OO, KO, pO) {
        var XO, bK;
        return null !== (XO = null === (bK = this.chunks.get(vp(OO, KO, pO))) || void 0 === bK ? void 0 : bK.ae) && void 0 !== XO ? XO : null
      }
      scan(OO, KO, pO, XO, bK, eO, lO, vK) {
        const CO = FO.z;
        let hO = 0;
        for (let DO = Math.floor(KO / CO); DO * CO < bK; DO++) {
          const MO = DO * CO,
            aK = Math.min(bK - MO, CO);
          for (let bK = Math.floor(OO / CO); bK * CO < XO; bK++) {
            const oO = bK * CO,
              FO = Math.min(XO - oO, CO);
            for (let XO = Math.floor(pO / CO); XO * CO < eO; XO++) {
              const VO = this.chunks.get(vp(bK, DO, XO));
              if (!VO) continue;
              const LO = XO * CO,
                QO = Math.max(pO - LO, 0),
                zK = Math.min(eO - LO, CO),
                AO = VO.mX,
                fO = VO.gameVoxels();
              for (let pO = Math.max(KO - MO, 0); pO < aK; pO++) {
                const KO = AO[pO];
                if (65535 === KO || 0 !== lO[KO]) {
                  hO++;
                  for (let KO = Math.max(OO - oO, 0); KO < FO; KO++) {
                    const OO = UO(KO, pO, 0);
                    for (let XO = QO; XO < zK; XO++) {
                      const bK = fO[OO + XO];
                      0 !== lO[bK] && vK.push(oO + KO, MO + pO, LO + XO, bK)
                    }
                  }
                }
              }
            }
          }
        }
        return hO
      }
      dataCleared(OO, KO, pO) {
        var XO;
        const bK = Math.floor(OO),
          eO = Math.floor(KO),
          lO = Math.floor(pO);
        return !0 === (null === (XO = this.chunkAt(bK, eO, lO)) || void 0 === XO ? void 0 : XO.dataCleared(CK(bK, eO, lO)))
      }
      isWalkThrough(OO) {
        if (!Number.isInteger(OO) || OO < 0 || OO > 65535) return !1;
        const KO = this.walkWords(),
          pO = OO >>> 5;
        return pO < KO.length && 1 === (KO[pO] >>> (31 & OO) & 1)
      }
      walkWords() {
        const OO = this.memory().buffer;
        var KO;
        OO !== this.walkBuffer && (this.walkBuffer = OO, this.walk = null !== (KO = (0, oO.r)(Uint32Array, OO, this.walkPtr, this.walkLen, "the walk-through bits")) && void 0 !== KO ? KO : bp);
        return this.walk
      }
      chunkAt(OO, KO, pO) {
        if ((0 | OO) !== OO || (0 | KO) !== KO || (0 | pO) !== pO) return;
        const XO = vp(OO >> nO, KO >> nO, pO >> nO);
        return XO !== this.lastKey && (this.lastKey = XO, this.lastChunk = this.chunks.get(XO)), this.lastChunk
      }
    }
    var DK = pO(36895),
      MK = pO(36173),
      ap = pO(35287),
      oK = pO(35151),
      FK = pO(35162),
      VK = pO(37476),
      LK = pO(171);
    const QK = ["ambient", "crowd", "customGame_horror", "dig", "fishing", "gameStart", "gunMisc", "gunPistol", "gunRifle", "gunSemiAutomatic", "gunShotgun", "gunSubmachineGun", "mob", "note", "random", "rpg", "step", "survivalFactory"],
      zp = [
        ["ZombieGrunt1", 12],
        ["ZombieGrunt2", 12],
        ["ZombieGrunt3", 12],
        ["ZombieHurt1", 12],
        ["ZombieHurt2", 12],
        ["ZombieHurt3", 12],
        ["ZombieHurt4", 12],
        ["bass", 13],
        ["bassattack", 13],
        ["bd", 13],
        ["bearRoar1", 12],
        ["bearRoar2", 12],
        ["bearRoar3", 12],
        ["bearRoar4", 12],
        ["bearRoar5", 12],
        ["beep", 14],
        ["bigDrumSwish1", 13],
        ["bigDrumSwish2", 13],
        ["bigDrumSwish3", 13],
        ["bow", 14],
        ["bucketEmpty1", 14],
        ["bucketEmpty2", 14],
        ["bucketEmpty3", 14],
        ["bucketFill1", 14],
        ["bucketFill2", 14],
        ["bucketFill3", 14],
        ["bullet_shell_bounce_general_07", 6],
        ["bullet_shell_bounce_general_08", 6],
        ["burp", 14],
        ["cannonFire1", 14],
        ["cannonFire2", 14],
        ["cannonFire3", 14],
        ["cashRegister", 14],
        ["catHiss1", 12],
        ["catHiss2", 12],
        ["catHiss3", 12],
        ["catHiss4", 12],
        ["catHurt1", 12],
        ["catHurt2", 12],
        ["catHurt3", 12],
        ["catMeow1", 12],
        ["catMeow2", 12],
        ["catMeow3", 12],
        ["catMeow4", 12],
        ["catMeow5", 12],
        ["caughtFish", 4],
        ["chestClose", 14],
        ["chestOpen", 14],
        ["cloth1", 3],
        ["cloth2", 3],
        ["cloth3", 3],
        ["cloth4", 3],
        ["cowHurt1", 12],
        ["cowMoo1", 12],
        ["cowMoo2", 12],
        ["cowMoo3", 12],
        ["croneAttack1", 12],
        ["croneHurt1", 12],
        ["croneIdle1", 12],
        ["crowdAmbience", 1],
        ["crowdCheer", 1],
        ["cryptWhoosh", 2],
        ["deerGrunt1", 12],
        ["deerHurt1", 12],
        ["dogBark1", 12],
        ["dogBark2", 12],
        ["dogBark3", 12],
        ["dogGrowl1", 12],
        ["dogGrowl2", 12],
        ["dogGrowl3", 12],
        ["dogHurt1", 12],
        ["dogHurt2", 12],
        ["doorClose", 14],
        ["doorClose2", 14],
        ["doorKnock", 2],
        ["doorOpen-bloxd1", 14],
        ["doorOpen-bloxd2", 14],
        ["drink", 14],
        ["drumSwish1", 13],
        ["drumSwish2", 13],
        ["eat1", 14],
        ["equip_leather1", 14],
        ["exp_collect", 14],
        ["exp_levelup", 14],
        ["fallsmall", 14],
        ["fennecYip1", 12],
        ["fennecYip2", 12],
        ["fennecYip3", 12],
        ["fireBurn", 14],
        ["firecracker1", 14],
        ["firecracker2", 14],
        ["firecracker3", 14],
        ["firecracker4", 14],
        ["futureStrangePulse", 2],
        ["game_start_countdown_01", 5],
        ["game_start_countdown_02", 5],
        ["game_start_countdown_03", 5],
        ["game_start_countdown_final", 5],
        ["glass1", 3],
        ["glass2", 3],
        ["glass3", 3],
        ["golemGrunt1", 12],
        ["golemGrunt2", 12],
        ["gorillaIdle1", 12],
        ["gorillaIdle2", 12],
        ["gorillaIdle3", 12],
        ["gorillaIdle4", 12],
        ["gorillaRoar1", 12],
        ["grass1", 3],
        ["grass2", 3],
        ["grass3", 3],
        ["grass4", 3],
        ["gravel1", 3],
        ["gravel2", 3],
        ["gravel3", 3],
        ["gravel4", 3],
        ["harp_pling", 13],
        ["hat", 13],
        ["hauntedHorrorImpact", 2],
        ["headshot_04", 6],
        ["headshot_06", 6],
        ["headshot_08", 6],
        ["headshot_11", 6],
        ["hit1", 16],
        ["hit2", 16],
        ["hit3", 16],
        ["hoeTill1", 14],
        ["hoeTill2", 14],
        ["hoeTill3", 14],
        ["hoeTill4", 14],
        ["horrorAccent1", 2],
        ["horrorFright", 2],
        ["horrorMaleDrone", 2],
        ["horseHurt1", 12],
        ["horseHurt2", 12],
        ["horseIdle1", 12],
        ["horseIdle2", 12],
        ["horseIdle3", 12],
        ["intensiveRainLoop", 2],
        ["knightGrunt1", 12],
        ["knightGrunt2", 12],
        ["knightGrunt3", 12],
        ["laugh1", 14],
        ["laugh2", 14],
        ["laugh3", 14],
        ["lavaFlow", 0],
        ["levelup", 13],
        ["lowDrum1", 13],
        ["lowDrum2", 13],
        ["lowDrum3", 13],
        ["magicAccent1", 14],
        ["magicAccent2", 14],
        ["magicAccent3", 14],
        ["magicAccent4", 14],
        ["metalDoorKnock", 2],
        ["ominousBellHit", 2],
        ["pickUp", 3],
        ["pigHurt1", 12],
        ["pigHurt2", 12],
        ["pigHurt3", 12],
        ["pigOink1", 12],
        ["pigOink2", 12],
        ["pigOink3", 12],
        ["pigOink4", 12],
        ["pigOink5", 12],
        ["pistol_cock_01", 7],
        ["pistol_cock_02", 7],
        ["pistol_cock_03", 7],
        ["pistol_cock_06", 7],
        ["pistol_magazine_load_01", 7],
        ["pistol_magazine_load_02", 7],
        ["pistol_magazine_load_03", 7],
        ["pistol_magazine_unload_01", 7],
        ["pistol_magazine_unload_02", 7],
        ["pistol_magazine_unload_03", 7],
        ["pistol_shot_01", 7],
        ["pistol_shot_02", 7],
        ["pistol_shot_03", 7],
        ["pistol_shot_04", 7],
        ["pistol_shot_05", 7],
        ["pulseFromTheDark", 2],
        ["reaverAttack1", 12],
        ["reaverAttack2", 12],
        ["reaverAttack3", 12],
        ["reaverGrunt1", 12],
        ["reaverGrunt2", 12],
        ["reaverGrunt3", 12],
        ["reel", 4],
        ["refereeWhistle", 1],
        ["rifle_cock_01", 8],
        ["rifle_cock_02", 8],
        ["rifle_magazine_load_01", 8],
        ["rifle_magazine_load_02", 8],
        ["rifle_magazine_load_03", 8],
        ["rifle_magazine_unload_01", 8],
        ["rifle_magazine_unload_02", 8],
        ["rifle_magazine_unload_04", 8],
        ["rifle_shot_01", 8],
        ["rifle_shot_02", 8],
        ["rifle_shot_03", 8],
        ["rifle_shot_04", 8],
        ["rocketEngineLoop", 17],
        ["rpgBeltCloth1", 15],
        ["rpgBeltCloth2", 15],
        ["rpgBeltHandle1", 15],
        ["rpgBeltHandle2", 15],
        ["rpgBookClose", 15],
        ["rpgBookFlip1", 15],
        ["rpgBookFlip2", 15],
        ["rpgBookFlip3", 15],
        ["rpgBookOpen", 15],
        ["rpgBookPlace1", 15],
        ["rpgBookPlace2", 15],
        ["rpgBookPlace3", 15],
        ["rpgChop", 15],
        ["rpgCloth1", 15],
        ["rpgCloth2", 15],
        ["rpgCloth3", 15],
        ["rpgCloth4", 15],
        ["rpgCreak1", 15],
        ["rpgCreak2", 15],
        ["rpgCreak3", 15],
        ["rpgDoorClose1", 15],
        ["rpgDoorClose2", 15],
        ["rpgDoorClose3", 15],
        ["rpgDoorClose4", 15],
        ["rpgDoorOpen1", 15],
        ["rpgDoorOpen2", 15],
        ["rpgDrawKnife1", 15],
        ["rpgDrawKnife2", 15],
        ["rpgDrawKnife3", 15],
        ["rpgDropLeather", 15],
        ["rpgFootstep00", 15],
        ["rpgFootstep01", 15],
        ["rpgFootstep02", 15],
        ["rpgFootstep03", 15],
        ["rpgFootstep04", 15],
        ["rpgFootstep05", 15],
        ["rpgFootstep06", 15],
        ["rpgFootstep07", 15],
        ["rpgFootstep08", 15],
        ["rpgFootstep09", 15],
        ["rpgHandleCoins1", 15],
        ["rpgHandleCoins2", 15],
        ["rpgHandleSmallLeather1", 15],
        ["rpgHandleSmallLeather2", 15],
        ["rpgKnifeSlice1", 15],
        ["rpgKnifeSlice2", 15],
        ["rpgMetalClick", 15],
        ["rpgMetalLatch", 15],
        ["rpgMetalPot1", 15],
        ["rpgMetalPot2", 15],
        ["rpgMetalPot3", 15],
        ["sand1", 3],
        ["sand2", 3],
        ["sand3", 3],
        ["sand4", 3],
        ["semiAuto_cock_01", 9],
        ["semiAuto_cock_02", 9],
        ["semiAuto_cock_03", 9],
        ["semiAuto_cock_04", 9],
        ["semiAuto_cock_05", 9],
        ["semiAuto_first_shot_01", 9],
        ["semiAuto_magazine_load_01", 9],
        ["semiAuto_magazine_load_02", 9],
        ["semiAuto_magazine_load_03", 9],
        ["semiAuto_magazine_load_04", 9],
        ["semiAuto_magazine_load_05", 9],
        ["semiAuto_magazine_unload_01", 9],
        ["semiAuto_magazine_unload_02", 9],
        ["semiAuto_magazine_unload_03", 9],
        ["semiAuto_magazine_unload_04", 9],
        ["semiAuto_shot_01", 9],
        ["semiAuto_shot_02", 9],
        ["semiAuto_shot_03", 9],
        ["semiAuto_shot_04", 9],
        ["semiAuto_shot_05", 9],
        ["semiAuto_shot_06", 9],
        ["semiAuto_shot_07", 9],
        ["semiAuto_shot_08", 9],
        ["semiAuto_tail_only_shot_01", 9],
        ["sheepBaa1", 12],
        ["sheepBaa2", 12],
        ["sheepBaa3", 12],
        ["sheepBaa4", 12],
        ["sheepHurt1", 12],
        ["shotgun_cock_01", 10],
        ["shotgun_cock_02", 10],
        ["shotgun_cock_03", 10],
        ["shotgun_cock_04", 10],
        ["shotgun_cock_05", 10],
        ["shotgun_load_bullet_01", 10],
        ["shotgun_load_bullet_02", 10],
        ["shotgun_load_bullet_03", 10],
        ["shotgun_load_bullet_04", 10],
        ["shotgun_load_bullet_05", 10],
        ["shotgun_load_bullet_06", 10],
        ["shotgun_load_bullet_07", 10],
        ["shotgun_load_bullet_08", 10],
        ["shotgun_shot_01", 10],
        ["shotgun_shot_02", 10],
        ["shotgun_shot_03", 10],
        ["shotgun_shot_04", 10],
        ["skeletonRattle1", 12],
        ["skeletonRattle2", 12],
        ["skeletonRattle3", 12],
        ["skeletonRattle4", 12],
        ["snare", 13],
        ["snow1", 3],
        ["snow2", 3],
        ["snow3", 3],
        ["snow4", 3],
        ["sonarBeep", 13],
        ["splash1", 14],
        ["stagGrunt1", 12],
        ["stagHurt1", 12],
        ["stalkerAttack1", 12],
        ["stalkerIdle1", 12],
        ["step_cloth1", 16],
        ["step_cloth2", 16],
        ["step_cloth3", 16],
        ["step_cloth4", 16],
        ["step_grass1", 16],
        ["step_grass2", 16],
        ["step_grass3", 16],
        ["step_grass4", 16],
        ["step_grass5", 16],
        ["step_gravel1", 16],
        ["step_gravel2", 16],
        ["step_gravel3", 16],
        ["step_gravel4", 16],
        ["step_sand2", 16],
        ["step_sand3", 16],
        ["step_sand4", 16],
        ["step_sand5", 16],
        ["step_snow1", 16],
        ["step_snow2", 16],
        ["step_snow3", 16],
        ["step_snow4", 16],
        ["step_stone1", 16],
        ["step_stone2", 16],
        ["step_stone3", 16],
        ["step_stone4", 16],
        ["step_stone5", 16],
        ["step_stone6", 16],
        ["step_wood1", 16],
        ["step_wood2", 16],
        ["step_wood3", 16],
        ["step_wood4", 16],
        ["step_wood5", 16],
        ["step_wood6", 16],
        ["stone1", 3],
        ["stone2", 3],
        ["stone3", 3],
        ["stone4", 3],
        ["submachine_cock_01", 11],
        ["submachine_cock_02", 11],
        ["submachine_cock_03", 11],
        ["submachine_cock_04", 11],
        ["submachine_first_shot_01", 11],
        ["submachine_magazine_load_01", 11],
        ["submachine_magazine_load_02", 11],
        ["submachine_magazine_load_03", 11],
        ["submachine_magazine_load_04", 11],
        ["submachine_magazine_unload_01", 11],
        ["submachine_magazine_unload_02", 11],
        ["submachine_magazine_unload_03", 11],
        ["submachine_shot_01", 11],
        ["submachine_shot_02", 11],
        ["submachine_shot_03", 11],
        ["submachine_shot_04", 11],
        ["submachine_shot_05", 11],
        ["submachine_shot_06", 11],
        ["submachine_shot_07", 11],
        ["submachine_shot_08", 11],
        ["submachine_shot_09", 11],
        ["submachine_tail_only_shot_01", 11],
        ["successfulBowHit", 14],
        ["suspenseRiser", 2],
        ["sweep6", 16],
        ["thunderRain", 2],
        ["trapdoorOpen", 14],
        ["trumpetFlare", 13],
        ["trumpetNote1", 13],
        ["trumpetNote2", 13],
        ["trumpetNote3", 13],
        ["warperGrunt1", 12],
        ["warperGrunt2", 12],
        ["warperGrunt3", 12],
        ["warperGrunt4", 12],
        ["warperGrunt5", 12],
        ["warperPhase1", 12],
        ["warperPhase2", 12],
        ["wood1", 3],
        ["wood2", 3],
        ["wood3", 3],
        ["wood4", 3],
        ["wraithGrunt1", 12],
        ["wraithGrunt2", 12],
        ["wraithHurt", 12],
        ["zapAccent1", 2],
        ["zapAccent2", 2]
      ],
      AK = zp.map((OO => {
        let [KO] = OO;
        return KO
      })),
      fK = Uint8Array.from(zp, (OO => {
        let [, KO] = OO;
        return KO
      })),
      dK = {
        semi_automatic: 9,
        submachine: 11,
        rifle: 8,
        pistol: 7,
        shotgun: 10
      },
      TK = 6;
    var NK = pO(35279),
      IK = pO(8336);
    const yp = 2 ** QK.length - 1;
    class gp {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : IK.b;
        this.sheet = OO, this.onError = KO, this.idle = pO, this.queue = [], this.asked = 0, this.cancelIdle = null, this.gen = 0, this.onIdle = OO => {
          this.cancelIdle = null;
          try {
            if (OO.timeRemaining() >= 1) {
              let OO = this.queue.shift();
              for (; void 0 !== OO && !this.load(OO);) OO = this.queue.shift()
            }
          } catch (KO) {
            this.onError(KO)
          } finally {
            this.schedule()
          }
        }
      }
      preload(OO) {
        const KO = OO & yp & ~this.asked;
        if (0 !== KO) {
          this.asked |= KO;
          for (let OO = 0; OO < QK.length; OO++) KO & 1 << OO && this.queue.push(OO);
          this.schedule()
        }
      }
      cancel() {
        var OO;
        this.queue.length = 0, this.asked = 0, this.gen++, null === (OO = this.cancelIdle) || void 0 === OO || OO.call(this), this.cancelIdle = null
      }
      schedule() {
        null === this.cancelIdle && this.queue.length > 0 && (this.cancelIdle = this.idle(this.onIdle))
      }
      load(OO) {
        const KO = this.sheet(OO, !1),
          pO = this.sheet(OO, !0),
          [XO, bK] = "unloaded" === KO.state() && "unloaded" !== pO.state() ? [pO, KO] : [KO, pO],
          eO = this.gen,
          lO = () => {
            try {
              eO === this.gen && "unloaded" === bK.state() && bK.load()
            } catch (OO) {
              this.onError(OO)
            }
          },
          vK = XO.state();
        return "unloaded" === vK ? (XO.once("load", lO), XO.load(), !0) : "unloaded" === bK.state() && ("loading" === vK ? (XO.once("load", lO), !1) : (bK.load(), !0))
      }
    }
    var uK = pO(38968);
    const EK = {
        coneInnerAngle: 360,
        coneOuterAngle: 360,
        coneOuterGain: 0,
        distanceModel: "inverse",
        maxDistance: 1e3,
        panningModel: "HRTF",
        rolloffFactor: 1
      },
      jp = LK.h.uD * LK.h.playerEyeToHeightRatio,
      YK = [0, 0, -1, 0, 1, 0],
      wK = QK.indexOf("note");

    function ip(OO) {
      return OO >= 0 ? Math.min(1, OO) : 0
    }

    function rp(OO) {
      var KO;
      let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Math.random;
      const XO = function(OO) {
        let KO = 0,
          pO = AK.length;
        for (; KO < pO;) {
          const XO = KO + pO >>> 1;
          AK[XO] < OO ? KO = XO + 1 : pO = XO
        }
        return KO
      }(OO);
      if ("" === OO || null === (KO = AK[XO]) || void 0 === KO || !KO.startsWith(OO)) return -1;
      if (AK[XO] === OO) return XO;
      let bK = XO + 1;
      for (; bK < AK.length && AK[bK].startsWith(OO);) bK++;
      return XO + Math.floor(pO() * (bK - XO))
    }
    class PK {
      constructor(OO, KO, pO, XO, bK) {
        this.group = OO, this.loudness = KO, this.startMs = pO, this.howl = XO, this.host = bK, this.id = 0, this.direct = !1
      }
      getDurationMs() {
        const OO = this.host.alive(this.id);
        return OO ? 1e3 * this.howl.duration(this.id) / OO.rate : 0
      }
      isAlive() {
        return void 0 !== this.host.alive(this.id)
      }
      canStop() {
        return this.isAlive() && (this.direct || this.host.started(this.id)) && this.howl.playing(this.id) && !this.howl._playLock
      }
      stop() {
        this.host.drop(this.id)
      }
    }
    class mp {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => performance.now(),
          XO = arguments.length > 3 ? arguments[3] : void 0;
        this.createHowl = OO, this.listener = KO, this.now = pO, this.errors = 0, this.sheets = new Map, this.live = new Map, this.core = new Map, this.level = 1, this.master = 1, this.pose = new Float64Array(9), this.nextPose = new Float64Array(9), this.posed = !1, this.loader = void 0, this.voices = new NK.b, this.failed = new Set, this.started = new Set, this.voiceHost = {
          alive: OO => this.aliveVoice(OO),
          started: OO => this.started.has(OO),
          drop: OO => {
            var KO;
            null === (KO = this.live.get(OO)) || void 0 === KO || KO.howl.stop(OO), this.forget(OO)
          }
        }, this.handlers = {
          playSound: (OO, KO, pO, XO, bK, eO, lO, vK, CO) => {
            if (XO >= AK.length) return;
            const hO = 0 !== (bK & FO.Yd.Loop);
            bK & FO.Yd.TwoD ? this.start(XO, !1, lO, eO, vK, hO) : this.startSpatial(XO, lO, eO, vK, hO, OO, KO, pO, CO, this.earDistSq(OO, KO, pO))
          },
          soundPos: (OO, KO, pO, XO) => {
            const bK = this.core.get(XO);
            var eO;
            void 0 !== bK && (null === (eO = this.live.get(bK)) || void 0 === eO || eO.howl.pos(pO, KO, OO, bK))
          },
          soundSet: (OO, KO, pO, XO) => {
            const bK = this.core.get(OO),
              eO = void 0 === bK ? void 0 : this.live.get(bK);
            void 0 !== bK && eO && (this.setRel(bK, KO), eO.rate = pO, eO.howl.rate(pO, bK), eO.spatial && eO.howl.pannerAttr({
              refDistance: XO
            }, bK))
          },
          soundFade: (OO, KO, pO, XO) => {
            const bK = this.core.get(OO);
            void 0 !== bK && this.fade(bK, KO, pO, 0 !== (XO & FO.Xd.StopAfter))
          },
          soundStop: OO => {
            const KO = this.core.get(OO);
            var pO;
            void 0 !== KO && (null === (pO = this.live.get(KO)) || void 0 === pO || pO.howl.stop(KO), this.forget(KO))
          },
          soundReset: () => {
            this.stopCore()
          }
        }, this.loader = new gp(((OO, KO) => this.sheet(OO, KO)), (OO => {
          this.errors++, console.error("Audio preload failed", OO)
        }), XO)
      }
      prepare() {
        for (let OO = 0; OO < QK.length; OO++) this.sheet(OO, !1), this.sheet(OO, !0)
      }
      preload(OO) {
        this.loader.preload(OO)
      }
      cancelPreload() {
        this.loader.cancel()
      }
      onAudioEvent(OO, KO, pO, XO) {
        if (OO < FO.n.PlaySound || OO > FO.n.SoundReset) return !1;
        try {
          return (0, FO.ke)(OO, KO, pO, XO, this.handlers)
        } catch (bK) {
          return this.errors++, console.error("Audio event failed", bK), !0
        }
      }
      applyListener(OO) {
        const KO = this.nextPose;
        for (let XO = 0; XO < 3; XO++) KO[2 - XO] = FO.v.listener(OO, 0, XO), KO[5 - XO] = FO.v.forward(OO, 0, XO), KO[8 - XO] = FO.v.up(OO, 0, XO);
        0 === KO[3] && 0 === KO[4] && 0 === KO[5] && KO.set(this.posed ? this.pose.subarray(3) : YK, 3);
        for (let XO = 0; XO < 9; XO++)
          if (!Number.isFinite(KO[XO])) return;
        const pO = this.pose;
        if (this.posed) {
          let OO = !0;
          for (let XO = 0; XO < 9 && OO; XO++) OO = KO[XO] === pO[XO];
          if (OO) return
        }
        this.listener.apply(KO) && (pO.set(KO), this.posed = !0)
      }
      playGame(OO, KO, pO, XO, bK, eO, lO) {
        const vK = rp(OO);
        if (vK < 0) return uK.e;
        if (!pO) {
          const {
            howl: OO,
            id: pO
          } = this.start(vK, !1, KO, 0, 1, lO);
          return this.gameSound(OO, pO, !1)
        }
        const CO = pO[0],
          hO = pO[1] + jp,
          DO = pO[2];
        if (!Number.isFinite(CO) || !Number.isFinite(hO) || !Number.isFinite(DO)) return uK.e;
        let MO;
        if (XO) {
          const OO = CO - XO[0],
            KO = hO - XO[1],
            pO = DO - XO[2];
          if (MO = OO * OO + KO * KO + pO * pO, MO > bK * bK) return uK.e
        } else MO = this.earDistSq(CO, hO, DO);
        const aK = this.startSpatial(vK, KO, 0, 1, lO, CO, hO, DO, eO, MO);
        return aK ? this.gameSound(aK.howl, aK.id, !0) : uK.e
      }
      setMaster(OO, KO) {
        this.level = ip(OO);
        const pO = KO ? this.level : 0;
        if (pO !== this.master) {
          this.master = pO;
          for (const [OO, KO] of this.live) KO.fadeMs = 0, KO.gain = KO.rel * this.master, KO.howl.volume(KO.gain, OO)
        }
      }
      stopCore() {
        for (const KO of [...this.core.values()]) {
          var OO;
          null === (OO = this.live.get(KO)) || void 0 === OO || OO.howl.stop(KO)
        }
        this.core.clear()
      }
      stopAll() {
        this.cancelPreload();
        for (const [OO, KO] of [...this.live]) KO.howl.stop(OO), this.forget(OO);
        this.core.clear()
      }
      gameSound(OO, KO, pO) {
        const XO = {
          stop: () => (this.live.has(KO) && OO.stop(KO), XO),
          fade: (OO, pO, bK) => {
            var eO, lO;
            const vK = this.level > 0 ? pO / this.level : pO > 0 && null !== (eO = null === (lO = this.live.get(KO)) || void 0 === lO ? void 0 : lO.rel) && void 0 !== eO ? eO : 0;
            return this.fade(KO, vK, bK, !1), XO
          },
          rate: pO => {
            const bK = this.live.get(KO);
            return bK && (bK.rate = function(OO) {
              return OO > 0 && OO < 1 / 0 ? OO : 1
            }(pO), OO.rate(bK.rate, KO)), XO
          },
          getVolume: () => {
            var OO, pO;
            return (null !== (OO = null === (pO = this.live.get(KO)) || void 0 === pO ? void 0 : pO.rel) && void 0 !== OO ? OO : 0) * this.level
          },
          getRelativeVolume: () => {
            var OO, pO;
            return null !== (OO = null === (pO = this.live.get(KO)) || void 0 === pO ? void 0 : pO.rel) && void 0 !== OO ? OO : 0
          },
          setRelativeVolume: OO => (this.setRel(KO, OO), XO),
          setPannerAttr: bK => {
            if (pO && this.live.has(KO)) {
              const pO = {
                ...EK,
                refDistance: ap.h
              };
              for (const [OO, KO] of Object.entries(bK)) "number" !== typeof KO && "string" !== typeof KO || (pO[OO] = KO);
              OO.pannerAttr({
                coneOuterAngle: pO.coneOuterAngle
              }, KO), OO.pannerAttr(pO, KO)
            }
            return XO
          },
          setPosition: bK => (pO && this.live.has(KO) && Number.isFinite(bK[0] + bK[1] + bK[2]) && OO.pos(bK[2], bK[1], bK[0], KO), XO)
        };
        return XO
      }
      startSpatial(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
        const DO = this.sheet(fK[OO], !0);
        let MO = null;
        if (!bK) {
          if (this.failed.has(DO)) return null;
          const pO = fK[OO] === wK ? null : (0, NK.g)(AK[OO]),
            XO = (0, NK.e)(ip(KO), Math.sqrt(hO), CO);
          if (MO = new PK(pO, XO, this.now(), DO, this.voiceHost), !this.voices.admit(MO)) return null
        }
        const aK = this.start(OO, !0, KO, pO, XO, bK);
        return MO && (MO.id = aK.id, MO.direct = "loaded" === DO.state() && !DO._playLock), DO.pannerAttr({
          coneOuterAngle: 360
        }, aK.id), DO.pannerAttr({
          ...EK,
          refDistance: CO
        }, aK.id), DO.pos(vK, lO, eO, aK.id), aK
      }
      aliveVoice(OO) {
        const KO = this.live.get(OO);
        if (!KO) return;
        const pO = KO.howl._soundById(OO);
        if (pO && !pO._ended) return KO;
        this.forget(OO)
      }
      earDistSq(OO, KO, pO) {
        if (!this.posed) return 0;
        const XO = OO - this.pose[2],
          bK = KO - this.pose[1],
          eO = pO - this.pose[0];
        return XO * XO + bK * bK + eO * eO
      }
      start(OO, KO, pO, XO, bK, eO) {
        const lO = ip(pO),
          vK = this.sheet(fK[OO], KO);
        "unloaded" === vK.state() && vK.load();
        const CO = vK.play(AK[OO]),
          hO = lO * this.master;
        return vK.volume(hO, CO), this.live.set(CO, {
          howl: vK,
          rel: lO,
          gain: hO,
          fadeFrom: hO,
          fadeAt: 0,
          fadeMs: 0,
          rate: bK,
          handle: XO,
          spatial: KO,
          stopTimer: void 0
        }), 0 !== XO && this.core.set(XO, CO), 1 !== bK && vK.rate(bK, CO), eO && vK.loop(!0, CO), {
          howl: vK,
          id: CO
        }
      }
      sheet(OO, KO) {
        const pO = 2 * OO + (KO ? 1 : 0);
        let XO = this.sheets.get(pO);
        if (!XO) {
          const bK = this.createHowl(QK[OO], KO);
          bK.on("end", (OO => {
            bK.loop(OO) || this.forget(OO)
          })), bK.on("stop", (OO => {
            this.forget(OO)
          })), bK.on("play", (OO => {
            this.live.has(OO) && this.started.add(OO)
          })), bK.on("loaderror", (OO => {
            if ("loaded" !== bK.state()) {
              this.failed.add(bK);
              for (const [OO, KO] of this.live) KO.howl === bK && this.forget(OO)
            } else "number" === typeof OO && this.forget(OO)
          })), this.sheets.set(pO, bK), XO = bK
        }
        return XO
      }
      setRel(OO, KO) {
        const pO = this.live.get(OO);
        pO && (sK(pO), pO.fadeMs = 0, pO.rel = ip(KO), pO.gain = pO.rel * this.master, pO.howl.volume(pO.gain, OO))
      }
      fade(OO, KO, pO, XO) {
        const bK = this.live.get(OO);
        if (!bK) return;
        sK(bK);
        const {
          howl: eO
        } = bK, lO = this.gainNow(bK);
        bK.rel = ip(KO), bK.gain = bK.rel * this.master;
        const vK = pO > 0 ? Math.min(pO, 65535) : 0,
          CO = 0 === vK || lO === bK.gain;
        bK.fadeMs = CO ? 0 : vK, CO ? eO.volume(bK.gain, OO) : (bK.fadeFrom = lO, bK.fadeAt = this.now(), eO.fade(lO, bK.gain, vK, OO)), XO && (CO ? eO.stop(OO) : bK.stopTimer = setTimeout((() => {
          bK.stopTimer = void 0, eO.stop(OO)
        }), vK))
      }
      gainNow(OO) {
        if (OO.fadeMs > 0) {
          const KO = (this.now() - OO.fadeAt) / OO.fadeMs;
          if (KO < 1) return OO.fadeFrom + (OO.gain - OO.fadeFrom) * Math.max(0, KO);
          OO.fadeMs = 0
        }
        return OO.gain
      }
      forget(OO) {
        this.started.delete(OO);
        const KO = this.live.get(OO);
        KO && (sK(KO), this.live.delete(OO), 0 !== KO.handle && this.core.get(KO.handle) === OO && this.core.delete(KO.handle))
      }
    }

    function sK(OO) {
      void 0 !== OO.stopTimer && (clearTimeout(OO.stopTimer), OO.stopTimer = void 0)
    }
    var HK = pO(38698),
      RK = pO(37478);
    class SK {
      constructor(OO, KO, pO, XO) {
        this.key = OO, this.model = KO, this.host = XO, this.YO = void 0, this.records = void 0, this.origin = [0, 0, 0], this.count = 0, this.vaO = Number.NaN, this.sentOrigin = [Number.NaN, Number.NaN, Number.NaN], this.dirtyList = [], this.isDirty = void 0, this.tail = void 0, this.tailView = void 0, this.tailCut = new Uint8Array(0), this.made = !1, this.YX = !1, this.YO = Math.max(1, Math.ceil(pO)), this.records = new Float32Array(this.YO * DK.d), this.isDirty = new Uint8Array(this.YO), this.tail = new Uint8Array(this.YO * FO.qc.Bytes), this.tailView = new DataView(this.tail.buffer), this.make(XO.cmd())
      }
      setOrigin(OO, KO, pO) {
        this.origin[0] = OO, this.origin[1] = KO, this.origin[2] = pO
      }
      markDirty(OO) {
        !this.YX && OO >= 0 && OO < this.YO && OO < FO.qc.Max && this.Kb(OO, OO + 1)
      }
      commit(OO) {
        if (this.YX) return;
        (OO = Math.min(Math.max(Math.floor(OO), 0), this.YO, FO.qc.Max)) > this.count && this.Kb(this.count, OO), this.count = OO;
        const {
          origin: KO,
          sentOrigin: pO,
          dirtyList: XO
        } = this, bK = this.vaO !== OO, eO = pO[0] !== KO[0] || pO[1] !== KO[1] || pO[2] !== KO[2];
        if (0 === XO.length && !bK && !eO) return;
        const lO = this.host.cmd();
        if (!lO || !this.make(lO)) return;
        const vK = XO.length,
          {
            records: CO,
            tailView: hO
          } = this;
        for (let DO = 0; DO < vK; DO++) {
          const OO = XO[DO],
            KO = OO * DK.d,
            pO = DO * FO.qc.Bytes,
            bK = 0 !== CO[KO + DK.h] ? FO.qc.Hidden : 0;
          hO.setUint32(pO, (OO | bK) >>> 0, !0), hO.setFloat32(pO + 4, CO[KO], !0), hO.setFloat32(pO + 8, CO[KO + 1], !0), hO.setFloat32(pO + 12, CO[KO + 2], !0)
        }
        if ((0, FO.He)(lO, 0, this.key, OO, KO, vK, this.tailOf(vK))) {
          for (let OO = 0; OO < vK; OO++) this.isDirty[XO[OO]] = 0;
          XO.length = 0, this.vaO = OO, pO[0] = KO[0], pO[1] = KO[1], pO[2] = KO[2]
        }
      }
      grow(OO) {
        (OO = Math.ceil(OO)) <= this.YO || this.YX || (this.records = (0, RK.c)(this.records, new Float32Array(OO * DK.d)), this.isDirty = (0, RK.c)(this.isDirty, new Uint8Array(OO)), this.tail = new Uint8Array(OO * FO.qc.Bytes), this.tailView = new DataView(this.tail.buffer), this.YO = OO)
      }
      dispose() {
        this.YX || (this.YX = !0, this.host.YX(this, this.made ? this.key : null))
      }
      make(OO) {
        if (!this.made && OO) {
          const {
            item: KO,
            scale: pO,
            yaw: XO
          } = this.model;
          this.made = (0, FO.Je)(OO, 0, this.key, KO, pO, XO)
        }
        return this.made
      }
      tailOf(OO) {
        const KO = OO * FO.qc.Bytes;
        return this.tailCut.buffer === this.tail.buffer && this.tailCut.length === KO || (this.tailCut = this.tail.subarray(0, KO)), this.tailCut
      }
      Kb(OO, KO) {
        const {
          dirtyList: pO,
          isDirty: XO
        } = this;
        for (let bK = OO; bK < KO; bK++) 0 === XO[bK] && (XO[bK] = 1, pO.push(bK))
      }
    }
    var JK = pO(524);
    class cp {
      constructor(OO) {
        this.keys = 0, this.live = new Set, this.owing = new Set, this.host = void 0, this.host = {
          cmd: OO,
          owes: OO => {
            this.owing.add(OO)
          },
          settled: (OO, KO) => {
            this.owing.delete(OO), KO && this.live.delete(OO)
          }
        }
      }
      create(OO, KO) {
        if (pO = OO, !JK.k.includes(pO)) return null;
        var pO;
        const XO = new BK(++this.keys, DO.h.indexOf(OO), KO, this.host);
        return this.live.add(XO), XO
      }
      disposeAll() {
        for (const OO of [...this.live]) OO.dispose()
      }
      flush() {
        if (0 === this.owing.size) return;
        const OO = this.host.cmd();
        for (const KO of this.owing)
          if (!KO.sync(OO)) return
      }
    }
    class BK {
      constructor(OO, KO, pO, XO) {
        this.key = OO, this.lifeform = KO, this.scale = pO, this.host = XO, this.feet = [0, 0, 0], this.yaw = 0, this.visible = !1, this.owed = 1, this.YX = !1, this.sync()
      }
      setPose(OO, KO) {
        this.YX || (this.feet[0] = OO[0], this.feet[1] = OO[1], this.feet[2] = OO[2], this.yaw = KO, this.owed |= 2, this.sync())
      }
      setVisible(OO) {
        this.YX || OO === this.visible || (this.visible = OO, this.owed |= 4, this.sync())
      }
      dispose() {
        this.YX || (this.YX = !0, this.owed = 1 & this.owed ? 0 : 8, this.sync())
      }
      sync() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.host.cmd();
        return this.write(OO) ? (this.host.settled(this, this.YX), !0) : (this.host.owes(this), !1)
      }
      write(OO) {
        if (!OO) return this.owed = 0, !0;
        if (1 & this.owed) {
          if (!(0, FO.Se)(OO, 0, this.key, this.lifeform, this.scale)) return !1;
          this.owed &= -2
        }
        const KO = (2 & this.owed ? FO.Pc.Pose : 0) | (4 & this.owed ? FO.Pc.Visible : 0);
        if (0 !== KO) {
          if (!(0, FO.Pe)(OO, 0, this.key, KO, this.visible ? 1 : 0, this.feet, this.yaw)) return !1;
          this.owed &= -7
        }
        if (8 & this.owed) {
          if (!(0, FO.Me)(OO, 0, this.key)) return !1;
          this.owed = 0
        }
        return !0
      }
    }
    var ZK = pO(39114);

    function GK(OO, KO, pO, XO) {
      return (0, ZK.c)(), (0, FO.Bf)(OO, KO, pO, XO)
    }
    var qp = pO(37483),
      xp = pO(38680);
    const nK = [0, 0, 0],
      WK = [0, 0, 0],
      tp = [0, 0, 0],
      kp = [0, 0, 0],
      UK = {
        origin: [0, 0, 0],
        direction: [0, 0, 1]
      },
      Op = [0, 0, 0],
      Kp = [0, 0],
      pp = [1, 1, 1],
      Xp = 1 / 3;
    const bX = MK.i;

    function ep(OO) {
      const KO = MK.e[OO],
        pO = KO && MK.i[KO.mainMultiblock];
      return pO && {
        main: pO,
        x: KO.compX,
        y: KO.compY,
        z: KO.compZ
      }
    }

    function lp(OO) {
      if (null === OO || void 0 === OO) return FO.Vc;
      const KO = +OO;
      return Number.isInteger(KO) && KO >= -2147483648 && KO <= 2147483647 && String(KO) === String(OO) ? KO : FO.Vc
    }

    function vX(OO, KO, pO) {
      return (0, FO.Ef)(OO, 0, KO, null !== pO && void 0 !== pO ? pO : Number.NaN)
    }
    class Cp {
      constructor(OO) {
        this.deps = OO, this.api = void 0, this.live = void 0, this.chunks = void 0, this.items = void 0, this.tables = void 0, this.meshKeys = 0, this.liveMeshes = new Set, this.poolKeys = 0, this.livePools = new Set, this.cameraTurn = new qp.b((() => this.tables.getClientOption("forcedCameraDirectionTransitionMs")), (OO => {
          var KO, pO;
          null === (KO = (pO = this.deps).setLocalOptions) || void 0 === KO || KO.call(pO, OO)
        })), this.mobModels = new cp((() => this.deps.cmd())), this.owedFrees = [], this.pendingStyle = void 0, this.pendingFar = void 0, this.farSet = !1, this.routeMesh = 0, this.routeOffset = 0, this.routeLook = "", this.routeSlide = {
          uvOffset: [0, 0]
        }, this.poolHost = {
          cmd: () => this.deps.cmd(),
          YX: (OO, KO) => {
            this.livePools.delete(OO), null !== KO && (this.owedFrees.push(KO), this.flushOwed())
          }
        }, this.api = OO.api, this.live = OO.live, this.chunks = OO.chunks, this.items = OO.items, this.tables = OO.tables
      }
      isLocal(OO) {
        return null !== OO && void 0 !== OO && +OO === this.api.localId
      }
      assertLocal(OO, KO) {
        if (!this.isLocal(OO)) throw new Error(`Attempted to ${KO} for a player that is not the local player`)
      }
      fV(OO) {
        const KO = this.api.fV(OO);
        if (!KO) throw new Error(`Entity ${OO} has no replicated position`);
        return KO
      }
      checkValid(OO) {
        return !!this.deps.isSessionLive() && (null === OO || void 0 === OO || this.api.checkValid(OO))
      }
      isAlive(OO) {
        return !1 !== this.api.isAlive(OO)
      }
      getItemStat(OO, KO, pO) {
        return this.isLocal(OO) || null !== OO && "Player" === this.api.getEntityType(OO) ? this.tables.getItemStat(KO, pO) : this.tables.getDefaultItemStat(KO, pO)
      }
      getClientOption(OO, KO) {
        return this.assertLocal(OO, "get a client option"), this.tables.getClientOption(KO)
      }
      openShop(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 ? arguments[2] : void 0;
        this.assertLocal(OO, "open shop"), lO.i.pl("showShopFromServer", {
          toggle: KO,
          DW: pO
        }, !0)
      }
      sendMessage(OO, KO, pO) {
        this.assertLocal(OO, "send a message");
        const XO = "string" === typeof KO ? [{
          str: KO,
          style: pO
        }] : KO;
        lO.i.pl("chat", {
          content: XO
        }, !0)
      }
      getEntityType(OO) {
        return this.api.getEntityType(OO)
      }
      getEntityName(OO) {
        const KO = lp(OO);
        return KO === FO.Vc ? void 0 : (0, HK.f)(this.api, KO)
      }
      hasEffect(OO, KO) {
        const pO = lp(OO);
        return pO !== FO.Vc && (0, HK.d)(this.api, pO, KO)
      }
      getMetaInfo(OO) {
        return this.tables.getMetaInfo(OO)
      }
      getPlayerDbId(OO) {
        return this.assertLocal(OO, "get a DB ID"), this.deps.playerDbId()
      }
      getBlockData(OO, KO, pO) {
        if (!this.chunks.dataCleared(OO, KO, pO)) return (0, HK.b)(this.api, OO, KO, pO)
      }
      EKO(OO, KO, pO, XO) {
        this.setBlockId(OO, KO, pO, this.tables.getItemId(XO))
      }
      setOtherEntitySetting(OO, KO, pO, XO) {
        if (!this.isLocal(OO)) throw new Error("Attempted to set an other-entity setting for a player that is not the local player");
        if (!Object.hasOwn(FO.ed, pO)) throw new Error(`Unknown other-entity setting ${pO}`);
        const bK = FO.ed[pO],
          eO = lp(KO);
        if (eO === FO.Vc || !this.deps.beforeWrite()) return;
        const lO = (0, mK.e)(XO);
        if (lO.length > 16384) throw new Error(`The other-entity setting ${pO}'s value is over 16384 bytes`);
        const vK = this.api.memoryView(Uint8Array, this.api.scratch(), lO.length, "set_other_entity_setting's value");
        vK && (vK.set(lO), this.api.queries.setOtherEntitySetting(eO, bK, lO.length))
      }
      getPositionView(OO) {
        return this.live.position(+OO)
      }
      readDrawnPosition(OO, KO) {
        return this.api.readDrawnPosition(lp(OO), KO)
      }
      getDrawnHeading(OO) {
        const KO = lp(OO),
          pO = (KO === FO.Vc ? 0 : this.api.queries.directorEntity(KO)) >= FO.jb.BYTES ? this.api.memoryData(this.api.scratch(), FO.jb.BYTES, 8, "getDrawnHeading's DirectorEntity") : null;
        if (!pO) return null;
        if (1 === FO.jb.headingIsDrawn(pO, 0)) return FO.jb.heading(pO, 0);
        const XO = this.api.apiView;
        return this.isLocal(OO) && 0 === (FO.t.playerFlags(XO, 0) & FO.Ad.FreeCam) ? FO.t.heading(XO, 0) : null
      }
      getLocalPlayerMovement() {
        const OO = FO.t.playerFlags(this.api.apiView, 0);
        return 0 === (OO & FO.Ad.Replay) && this.api.readDrawnPosition(this.api.localId, tp) ? {
          onGround: 0 !== (OO & FO.Ad.OnGround),
          jumpHeld: 0 !== (OO & FO.Ad.JumpHeld)
        } : null
      }
      mhO(OO) {
        return this.isLocal(OO) ? this.items.JK() : null
      }
      getInventoryItems() {
        return this.items.playerItems()
      }
      getHeldGunInaccuracy() {
        var OO, KO;
        return "Gun" === (null === (OO = this.aliveHeld()) || void 0 === OO || null === (KO = OO.typeObj) || void 0 === KO ? void 0 : KO.type) ? this.items.inaccuracy : null
      }
      aliveHeld() {
        return !1 === this.api.isAlive(this.api.localId) ? null : this.items.JK()
      }
      isCrosshairShown() {
        var OO, KO;
        const pO = XO.d.get("crosshairShownOverride");
        if (null !== pO) return pO;
        const bK = null === (OO = this.aliveHeld()) || void 0 === OO ? void 0 : OO.typeObj,
          eO = "Gun" === (null === bK || void 0 === bK ? void 0 : bK.type),
          lO = eO || !0 === (null === bK || void 0 === bK ? void 0 : bK.showsAimingUi),
          vK = 0 === (FO.t.playerFlags(this.api.apiView, 0) & FO.Ad.ZoomFirstPerson),
          CO = null !== (KO = this.tables.getClientOption("gunshotOrigin")) && void 0 !== KO ? KO : null;
        return (0, oK.g)({
          gun: eO,
          aimable: lO
        }, vK, (0, FK.d)(), CO)
      }
      setCrosshairShown(OO) {
        XO.d.set({
          crosshairShownOverride: OO
        })
      }
      getInventoryFreeSlotCount(OO) {
        return this.isLocal(OO) ? this.items.freeSlots() : null
      }
      getSelectedInventorySlotI(OO) {
        return this.isLocal(OO) ? this.items.selectedSlot : null
      }
      getItemSlot(OO, KO) {
        return this.isLocal(OO) ? this.items.slot(KO) : null
      }
      swapInventorySlots(OO, KO) {
        return this.items.swap(OO, KO)
      }
      isPlayerCrouching(OO) {
        if (this.isLocal(OO)) return 0 !== (FO.t.playerFlags(this.api.apiView, 0) & FO.Ad.Crouching);
        const KO = lp(OO);
        return KO !== FO.Vc && 1 === this.api.queries.entityCrouching(KO)
      }
      getMiningBlock() {
        return this.live.breakingPosition()
      }
      isMining() {
        return 0 !== (FO.t.playerFlags(this.api.apiView, 0) & FO.Ad.AttemptingBreak)
      }
      getTargetedBlock() {
        return this.live.zCO()
      }
      getActionRay() {
        const OO = this.api.apiView;
        for (let KO = 0; KO < 3; KO++) UK.origin[KO] = FO.t.YvO(OO, 0, KO), UK.direction[KO] = FO.t.actionDir(OO, 0, KO);
        return UK
      }
      canModifyBlockAt(OO, KO, pO) {
        return 1 === this.api.queries.canModify(OO, KO, pO)
      }
      isSolidToPlayerBlockId(OO) {
        return this.tables.isSolidBlockId(OO) && !this.chunks.isWalkThrough(OO)
      }
      blockNameToBlockId(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return this.tables.blockNameToBlockId(OO, KO)
      }
      blockIdToBlockName(OO) {
        return this.tables.nameOfId(OO)
      }
      XCO(OO, KO, pO, XO, bK) {
        return 1 === this.api.queries.terrainBlocked(XO, OO, KO, pO, lp(null !== bK && void 0 !== bK ? bK : null))
      }
      getChunkVersion(OO, KO, pO) {
        return this.chunks.version(OO, KO, pO)
      }
      scanBlocks(OO, KO, pO, XO, bK, eO, lO, vK) {
        return this.chunks.scan(OO, KO, pO, XO, bK, eO, lO, vK)
      }
      isBlockInLoadedChunk(OO, KO, pO) {
        return this.chunks.isLoaded(OO, KO, pO)
      }
      getBlockId(OO, KO, pO) {
        return this.chunks.yl(OO, KO, pO)
      }
      playSound(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
        if (!this.isLocal(OO)) return null;
        const lO = this.playSoundFrom(KO, pO, bK, eO);
        return 1 === XO ? lO : lO.rate(XO)
      }
      playSoundFrom(OO, KO, pO, XO) {
        var bK, eO;
        const lO = this.deps.playSound;
        if (!lO) return uK.e;
        const vK = null === pO || void 0 === pO ? void 0 : pO.I9,
          CO = null !== (bK = null === pO || void 0 === pO ? void 0 : pO.maxHearDist) && void 0 !== bK ? bK : ap.g,
          hO = null !== (eO = null === pO || void 0 === pO ? void 0 : pO.refDistance) && void 0 !== eO ? eO : ap.h;
        let DO = null;
        if (Array.isArray(vK)) nK[0] = vK[0], nK[1] = vK[1], nK[2] = vK[2], DO = nK;
        else if (void 0 !== vK && null !== vK) {
          const OO = lp(vK);
          if (!this.api.isLocal(OO)) {
            if (!this.api.readPosition(OO, nK)) return uK.e;
            DO = nK
          }
        }
        return lO(OO, KO, DO, DO && this.ear(), CO, hO, XO)
      }
      ear() {
        if (this.api.readPosition(this.api.localId, WK)) WK[1] += jp;
        else {
          const OO = this.api.apiView;
          if (0 === FO.t.viewProj(OO, 0, 3) && 0 === FO.t.viewProj(OO, 0, 7) && 0 === FO.t.viewProj(OO, 0, 11)) return null;
          for (let KO = 0; KO < 3; KO++) WK[KO] = FO.t.eye(OO, 0, KO)
        }
        return Number.isFinite(WK[0] + WK[1] + WK[2]) ? WK : null
      }
      setBlockId(OO, KO, pO, XO) {
        if (!Number.isInteger(XO) || XO < 0 || XO > 65535) throw new Error(`Invalid block id ${XO}`);
        if (!this.deps.beforeWrite() || !this.chunks.isLoaded(OO, KO, pO)) return;
        const bK = Math.floor(OO),
          eO = Math.floor(KO),
          lO = Math.floor(pO),
          vK = this.predictedCells(bK, eO, lO, XO);
        if (1 === this.api.queries.EKO(bK, eO, lO, XO)) {
          for (let OO = 0; OO < vK.length; OO += 5) this.chunks.setOverlay(vK[OO], vK[OO + 1], vK[OO + 2], vK[OO + 3], 1 === vK[OO + 4]);
          this.live.refreshTarget()
        }
      }
      particlesEnabled() {
        return this.deps.particles.enabled()
      }
      createParticles(OO, KO) {
        return this.deps.particles.create(OO, KO)
      }
      playParticleEffect(OO) {
        this.deps.particles.playEffect(OO)
      }
      burstParticlePreset(OO, KO, pO) {
        this.deps.particles.burstPreset(OO, KO, pO)
      }
      createGameMesh(OO, KO, pO) {
        const XO = ++this.meshKeys,
          bK = this.deps.cmd();
        if (!bK) return XO;
        const {
          look: eO,
          colour: lO
        } = function(OO) {
          switch (OO.kind) {
            case void 0:
            case "flatEmissive":
              return OO.onTop ? {
                look: FO.Vb.FlatOnTop,
                colour: [...OO.rgb, OO.alpha]
              } : OO.opaque ? {
                look: FO.Vb.FlatOpaque,
                colour: [...OO.rgb, 1]
              } : {
                look: FO.Vb.Flat,
                colour: [...OO.rgb, OO.alpha]
              };
            case "chevronPath":
              return {
                look: FO.Vb.Chevrons, colour: [...(0, VK.d)(OO.colour), OO.alpha]
              };
            case "furnaceFire":
              return {
                look: FO.Vb.FurnaceFire, colour: [1, 1, 1, 1]
              }
          }
        }(KO), vK = Math.floor(OO.positions.length / 3), CO = function(OO, KO) {
          const pO = Math.floor(OO.positions.length / 3),
            XO = OO.indices.length,
            bK = pO * (KO ? 5 : 3),
            eO = new Uint8Array(4 * (bK + XO)),
            lO = new DataView(eO.buffer);
          for (let hO = 0; hO < 3 * pO; hO++) lO.setFloat32(4 * hO, OO.positions[hO], !0);
          if (KO) {
            var vK;
            const KO = null !== (vK = OO.uvs) && void 0 !== vK ? vK : [];
            for (let OO = 0; OO < 2 * pO; OO++) {
              var CO;
              lO.setFloat32(4 * (3 * pO + OO), null !== (CO = KO[OO]) && void 0 !== CO ? CO : 0, !0)
            }
          }
          for (let hO = 0; hO < XO; hO++) lO.setUint32(4 * (bK + hO), OO.indices[hO], !0);
          return eO
        }(OO, (0, DK.i)(KO));
        return (0, FO.De)(bK, 0, XO, eO, lO, pO, vK, OO.indices.length, CO) && this.liveMeshes.add(XO), XO
      }
      setGameMesh(OO, KO) {
        var pO;
        const XO = this.deps.cmd();
        if (!XO) return;
        let bK = 0;
        KO.anchor && (bK |= FO.Xb.Anchor, Op[0] = KO.anchor[0], Op[1] = KO.anchor[1], Op[2] = KO.anchor[2]), void 0 !== KO.visible && (bK |= FO.Xb.Visible), KO.uvOffset && (bK |= FO.Xb.UvOffset, Kp[0] = KO.uvOffset[0], Kp[1] = KO.uvOffset[1]);
        const eO = null !== (pO = KO.visibility) && void 0 !== pO ? pO : 1;
        void 0 !== KO.visibility && (bK |= FO.Xb.Visibility), KO.scale && (bK |= FO.Xb.Scale, pp[0] = KO.scale[0], pp[1] = KO.scale[1], pp[2] = KO.scale[2]), 0 !== bK && (0, FO.Fe)(XO, 0, OO, bK, KO.visible ? 1 : 0, Op, Kp, eO, pp)
      }
      disposeGameMesh(OO) {
        const KO = this.deps.cmd();
        KO && !(0, FO.Ee)(KO, 0, OO) || this.liveMeshes.delete(OO)
      }
      hasPackModel(OO) {
        var KO, pO, XO;
        return null !== (KO = null === (pO = (XO = this.deps).hasPackModel) || void 0 === pO ? void 0 : pO.call(XO, OO)) && void 0 !== KO && KO
      }
      disposeGameOutput() {
        const OO = OO => {
          try {
            OO()
          } catch (KO) {
            console.error("Error freeing client game output", KO)
          }
        };
        for (const KO of [...this.liveMeshes]) OO((() => {
          this.disposeGameMesh(KO)
        }));
        for (const KO of [...this.livePools]) OO((() => {
          KO.dispose()
        }));
        OO((() => {
          this.mobModels.disposeAll()
        })), OO((() => {
          this.setGroundArrowStyle(null)
        })), OO((() => {
          this.setRouteChevrons(null), this.routeOffset = 0, this.routeLook = ""
        })), OO((() => {
          this.setCrosshairShown(null)
        })), OO((() => {
          this.cameraTurn.dispose()
        })), OO((() => {
          this.farSet && (this.farSet = !1, this.setCameraFar(null))
        }))
      }
      createInstancePool(OO, KO) {
        const pO = this.tables.idOf(OO.item);
        if (void 0 === pO) return null;
        const XO = new SK(++this.poolKeys, {
          item: pO,
          scale: OO.scale,
          yaw: OO.yaw
        }, KO, this.poolHost);
        return this.livePools.add(XO), XO
      }
      createMobModel(OO, KO) {
        return this.mobModels.create(OO, KO)
      }
      setRouteChevrons(OO) {
        if (0 !== this.routeMesh && (this.disposeGameMesh(this.routeMesh), this.routeMesh = 0), !OO || 0 === OO.cells.length) return;
        const KO = `${OO.colour} ${OO.alpha}`;
        KO !== this.routeLook && (this.routeLook = KO, this.routeOffset = 0), this.routeMesh = this.createGameMesh(function(OO) {
          const [KO, pO, XO] = OO[0].pos, bK = [], eO = [], lO = [];
          return OO.forEach(((OO, vK) => {
            let {
              pos: CO,
              way: [hO, DO]
            } = OO;
            const MO = CO[0] - KO + .5,
              aK = CO[1] - pO + .04,
              oO = CO[2] - XO + .5,
              [FO, VO] = [.35 * -DO, .35 * hO],
              [LO, QO] = [vK * Xp, (vK + 1) * Xp],
              zK = bK.length / 3;
            bK.push(MO - .5 * hO + FO, aK, oO - .5 * DO + VO), bK.push(MO - .5 * hO - FO, aK, oO - .5 * DO - VO), bK.push(MO + .5 * hO + FO, aK, oO + .5 * DO + VO), bK.push(MO + .5 * hO - FO, aK, oO + .5 * DO - VO), eO.push(0, LO, 1, LO, 0, QO, 1, QO), lO.push(zK, zK + 1, zK + 2, zK + 1, zK + 3, zK + 2)
          })), {
            positions: bK,
            uvs: eO,
            indices: lO
          }
        }(OO.cells), {
          kind: "chevronPath",
          colour: OO.colour,
          alpha: OO.alpha
        }, OO.cells[0].pos), this.setRouteSlide()
      }
      slideRoute(OO) {
        0 !== this.routeMesh && (this.routeOffset = (this.routeOffset + Math.min(OO, 250) / 1e3 * 1.2 * Xp) % 1, this.setRouteSlide())
      }
      setRouteSlide() {
        this.routeSlide.uvOffset[1] = -this.routeOffset, this.setGameMesh(this.routeMesh, this.routeSlide)
      }
      setGroundArrowStyle(OO) {
        this.pendingStyle = OO, this.flushOwed()
      }
      flushOwed() {
        this.mobModels.flush();
        const OO = this.owedFrees;
        if (0 === OO.length && void 0 === this.pendingStyle && void 0 === this.pendingFar) return;
        const KO = this.deps.cmd();
        if (!KO) return OO.length = 0, void(this.pendingFar = void 0);
        let pO = 0;
        for (; pO < OO.length && (0, FO.Ie)(KO, 0, OO[pO]);) pO++;
        OO.splice(0, pO);
        const XO = this.pendingStyle;
        if (void 0 !== XO) {
          (XO ? (0, FO.Gf)(KO, 0, XO.width, XO.alpha, 1, XO.endAtSolidFace ? 1 : 0) : (0, FO.Gf)(KO, 0, 0, 0, 0, 0)) && (this.pendingStyle = void 0)
        }
        const bK = this.pendingFar;
        void 0 !== bK && (0, FO.Df)(KO, 0, null !== bK && void 0 !== bK ? bK : 0, null === bK ? 1 : 0) && (this.pendingFar = void 0)
      }
      setNametagOffset(OO, KO) {
        const pO = this.deps.cmd(),
          XO = lp(OO);
        pO && XO !== FO.Vc && (0, FO.Qf)(pO, 0, XO, KO)
      }
      setFacingTolerance(OO, KO) {
        const pO = this.deps.cmd(),
          XO = lp(OO);
        pO && XO !== FO.Vc && vX(pO, XO, KO)
      }
      forEachEntity(OO) {
        const {
          api: KO
        } = this;
        for (let pO = 0; pO < KO.idStr.length; pO++) {
          const XO = KO.idStr[pO];
          null === XO || dO(KO.kinds[pO]) || OO(XO)
        }
      }
      getEntityInfo(OO) {
        return this.deps.entityInfo.get(OO)
      }
      isEntityInteractable(OO) {
        const KO = lp(OO);
        return KO !== FO.Vc && 1 === this.api.queries.entityInteractable(KO)
      }
      isLocalPlayer(OO) {
        return this.isLocal(OO)
      }
      getLineOwner(OO) {
        var KO;
        const pO = null === (KO = this.deps.entityInfo.get(OO)) || void 0 === KO ? void 0 : KO.meshOpts;
        if (!pO) return null;
        try {
          const {
            lineToEId: OO
          } = JSON.parse(pO);
          return null !== OO && void 0 !== OO ? OO : null
        } catch {
          return null
        }
      }
      getCameraPosition() {
        const OO = this.api.apiView;
        return kp[0] = FO.t.eye(OO, 0, 0), kp[1] = FO.t.eye(OO, 0, 1), kp[2] = FO.t.eye(OO, 0, 2), kp
      }
      getCameraFar() {
        return FO.t.cameraFar(this.api.apiView, 0)
      }
      setCameraFar(OO) {
        null !== OO && (this.farSet = !0), this.pendingFar = OO, this.flushOwed()
      }
      turnCamera(OO, KO) {
        this.cameraTurn.turn(OO, KO)
      }
      clearPickupDelay(OO) {
        const KO = this.deps.cmd(),
          pO = lp(OO);
        KO && pO !== FO.Vc && (0, FO.oe)(KO, 0, pO)
      }
      sendChat(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        const pO = this.deps.sendCmd();
        pO && GK(pO, 0, xp.b.Chat, (0, mK.e)((0, xp.g)({
          Tl: OO,
          QG: KO
        })))
      }
      sendCommand(OO) {
        OO.length <= 119 && this.sendChat(`/${OO}`)
      }
      predictedCells(OO, KO, pO, XO) {
        const bK = this.chunks,
          eO = [],
          lO = (OO, KO, pO, XO, bK) => {
            eO.push(OO, KO, pO, XO, this.tables.blockRootId(bK) === this.tables.blockRootId(XO) ? 0 : 1)
          },
          vK = bK.yl(OO, KO, pO),
          CO = ep(vK);
        if (CO) {
          const [XO, eO, hO] = [OO - CO.x, KO - CO.y, pO - CO.z], DO = bX[bK.yl(XO, eO, hO)], MO = null === DO || void 0 === DO ? void 0 : DO.positions.some((OO => OO.id === vK && OO.x === CO.x && OO.y === CO.y && OO.z === CO.z));
          for (const OO of (MO && DO ? DO : CO.main).positions) bK.yl(XO + OO.x, eO + OO.y, hO + OO.z) === OO.id && lO(XO + OO.x, eO + OO.y, hO + OO.z, 0, OO.id)
        }
        const hO = ep(XO);
        if (hO)
          for (const MO of hO.main.positions) {
            const [XO, eO, vK] = [OO + MO.x - hO.x, KO + MO.y - hO.y, pO + MO.z - hO.z];
            lO(XO, eO, vK, MO.id, bK.yl(XO, eO, vK))
          } else lO(OO, KO, pO, XO, vK);
        const DO = this.tables;
        if ((0 !== DO.attachedTopOf(vK) || 0 !== DO.attachedTopOf(XO)) && bK.isLoaded(OO, KO + 1, pO)) {
          let CO = bK.yl(OO, KO + 1, pO);
          for (let XO = 0; XO < eO.length; XO += 5) eO[XO] === OO && eO[XO + 1] === KO + 1 && eO[XO + 2] === pO && (CO = eO[XO + 3]);
          const hO = this.attachedTopWrite(vK, XO, CO);
          void 0 !== hO && lO(OO, KO + 1, pO, hO, CO)
        }
        return eO
      }
      attachedTopWrite(OO, KO, pO) {
        const XO = this.tables,
          bK = XO.attachedTopOf(OO),
          eO = XO.attachedTopOf(KO),
          lO = 0 !== bK && 0 !== pO && XO.blockRootId(pO) === XO.blockRootId(bK);
        return 0 !== bK && 0 !== eO && XO.blockRootId(OO) === XO.blockRootId(KO) ? lO && pO !== eO ? eO : void 0 : 0 === eO || !lO && 0 !== pO ? lO ? 0 : void 0 : eO
      }
    }
    const hp = FO.mc + FO.nc * FO.tc.BYTES,
      Dp = 2147483647,
      Mp = new TextDecoder,
      aX = new TextEncoder,
      op = Object.freeze({
        kR: 0,
        uq: null,
        amountAddedToSlot: 0
      }),
      Fp = new Proxy({}, {
        get: () => () => FO.dd
      });

    function Vp(OO) {
      return Number.isInteger(OO) && OO >= 0 && OO <= 65535
    }

    function Lp(OO) {
      return Number.isInteger(OO) && OO >= 0 && OO <= 4294967295
    }
    class Qp {
      constructor(OO) {
        this.deps = OO, this.hiO = [0, 0, 0], this.inaccuracy = 0, this.version = 0, this.notified = 0, this.iconChanged = !1, this.facades = new Array(FO.nc), this.ids = new Uint16Array(FO.nc), this.amounts = new Uint16Array(FO.nc), this.attrRead = new Float64Array(FO.nc).fill(-1), this.stale = new Uint16Array(FO.nc), this.staleVersion = new Uint32Array(FO.nc), this.instances = new Uint32Array(FO.nc), this.viewPtr = 0, this.viewVersion = -1, this.len = 0, this.selected = 0, this.slotIconId = 0, this.stopped = !1, this.listeners = new Set
      }
      get length() {
        return this.len
      }
      get selectedSlot() {
        return this.selected
      }
      get slotIcon() {
        return this.slotIconId
      }
      get changes() {
        return this.version
      }
      slot(OO) {
        var KO;
        return Number.isInteger(OO) && OO >= 0 && OO < this.len && 0 !== this.ids[OO] && null !== (KO = this.facades[OO]) && void 0 !== KO ? KO : null
      }
      JK() {
        return this.slot(this.selected)
      }
      playerItems() {
        const OO = [];
        for (let KO = 0; KO < Math.min(FO.kd, this.len); KO++) OO.push(this.slot(KO));
        return OO
      }
      freeSlots() {
        let OO = 0;
        for (let KO = 0; KO < Math.min(FO.kd - FO.i, this.len); KO++) 0 === this.ids[KO] && OO++;
        return OO
      }
      amountOf(OO) {
        let KO = 0;
        for (let XO = 0; XO < Math.min(FO.kd, this.len); XO++) {
          const bK = this.slot(XO);
          var pO;
          if ((null === bK || void 0 === bK ? void 0 : bK.name) === OO) KO += null !== (pO = bK.amount) && void 0 !== pO ? pO : 1
        }
        return KO
      }
      instance(OO) {
        var KO;
        return null !== (KO = this.instances[OO]) && void 0 !== KO ? KO : 0
      }
      watch(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      touch() {
        this.version++
      }
      flush(OO) {
        if (this.version !== this.notified || this.iconChanged) {
          this.notified = this.version, this.iconChanged = !1;
          for (const pO of [...this.listeners]) try {
            pO()
          } catch (KO) {
            OO(KO)
          }
        }
      }
      chestOpened(OO, KO, pO) {
        this.hiO[0] = OO, this.hiO[1] = KO, this.hiO[2] = pO, this.version++
      }
      refresh() {
        const OO = this.deps.api.apiView,
          KO = FO.t.inventoryViewPtr(OO, 0),
          pO = FO.t.inventoryVersion(OO, 0),
          XO = FO.t.selectedSlot(OO, 0);
        XO !== this.selected && (this.selected = XO, this.version++);
        const bK = FO.t.slotIcon(OO, 0);
        if (bK !== this.slotIconId && (this.slotIconId = bK, this.iconChanged = !0), KO === this.viewPtr && pO === this.viewVersion) return;
        this.viewPtr = KO, this.viewVersion = pO;
        const eO = this.deps.api.memoryData(KO, hp, 4, "the inventory view"),
          lO = eO ? Math.min(eO.getUint32(0, !0), FO.nc) : 0;
        lO !== this.len && (this.len = lO, this.version++);
        let vK = 0;
        for (let CO = 0; CO < FO.nc; CO++) {
          const OO = FO.mc + CO * FO.tc.BYTES,
            KO = null !== eO && CO < lO ? FO.tc.item(eO, OO) : 0;
          if (0 === KO || null === eO) {
            0 !== this.ids[CO] && (this.ids[CO] = 0, this.attrRead[CO] = -1, this.instances[CO]++, this.version++);
            continue
          }
          const pO = FO.tc.amount(eO, OO),
            XO = FO.tc.attrVersion(eO, OO);
          KO === this.ids[CO] && pO === this.amounts[CO] || this.fill(CO, KO, pO), XO !== this.attrRead[CO] && (this.stale[vK] = CO, this.staleVersion[vK] = XO, vK++)
        }
        vK > 0 && this.fetchAttributes(vK)
      }
      fill(OO, KO, pO) {
        const {
          tables: XO
        } = this.deps, bK = KO !== this.ids[OO];
        let eO = this.facades[OO];
        eO || (eO = {
          name: "",
          amount: null,
          attributes: {
            customAttributes: {}
          },
          typeObj: null
        }, this.facades[OO] = eO), bK && (eO.name = XO.nameOfId(KO), eO.typeObj = XO.itemType(KO), eO.attributes = {
          customAttributes: {}
        }, this.attrRead[OO] = -1, this.instances[OO]++), eO.amount = 0 === pO ? null : pO, this.ids[OO] = KO, this.amounts[OO] = pO, this.version++
      }
      fetchAttributes(OO) {
        const {
          api: KO,
          onError: pO
        } = this.deps, XO = KO.memoryView(Uint16Array, KO.scratch(), OO, "item_attributes_batch's slots");
        if (!XO) return void this.markRead(OO);
        XO.set(this.stale.subarray(0, OO));
        const bK = KO.queries.itemAttributesBatch(OO),
          eO = 4294967295 === bK ? null : KO.memoryData(KO.scratch(), bK, 4, "item_attributes_batch's answer");
        if (!eO) return void this.markRead(OO);
        const lO = new Uint8Array(eO.buffer, eO.byteOffset, bK);
        for (let CO = 0; CO + 8 <= bK;) {
          const OO = eO.getUint16(CO, !0),
            KO = eO.getUint32(CO + 4, !0),
            XO = lO.subarray(CO + 8, CO + 8 + KO);
          CO += 8 + (0, aK.ne)(KO);
          const bK = this.facades[OO];
          if (bK && 0 !== this.ids[OO] && 0 !== KO) {
            try {
              bK.attributes = JSON.parse(Mp.decode(XO))
            } catch (vK) {
              pO(vK)
            }
            this.version++
          }
        }
        this.markRead(OO)
      }
      markRead(OO) {
        for (let KO = 0; KO < OO; KO++) this.attrRead[this.stale[KO]] = this.staleVersion[KO]
      }
      swap(OO, KO) {
        return Vp(OO) && Vp(KO) && this.settle(this.queries().invSwap(OO, KO))
      }
      move(OO, KO, pO) {
        return Vp(OO) && Vp(KO) && Lp(pO) && this.settle(this.queries().invMove(OO, KO, pO))
      }
      quickMove(OO, KO, pO, XO) {
        var bK, eO;
        if (!Vp(OO) || !Vp(KO) || !Vp(pO) || null !== XO && !Lp(XO)) return null;
        const lO = this.queries().invQuickMove(OO, KO, pO, null === XO ? -1 : Math.min(XO, Dp)),
          vK = lO === FO.dd ? FO.Db : null !== (bK = null === (eO = this.extras()) || void 0 === eO ? void 0 : eO[1]) && void 0 !== bK ? bK : FO.Db;
        return this.settle(lO), vK === FO.Db ? null : vK
      }
      remove(OO, KO, pO) {
        return Vp(OO) && Lp(KO) && this.settle(this.queries().invRemove(OO, KO, pO ? 1 : 0))
      }
      selectSlot(OO) {
        return Vp(OO) && this.settle(this.queries().selectSlot(OO))
      }
      closeChest() {
        return this.settle(this.queries().closeChest())
      }
      enchant(OO, KO, pO) {
        if (!Vp(OO) || !Number.isInteger(KO)) return !1;
        const [XO, bK, eO] = pO;
        return this.settle(this.queries().invEnchant(OO, KO, Math.floor(XO), Math.floor(bK), Math.floor(eO)))
      }
      craft(OO, KO, pO) {
        let XO;
        try {
          XO = this.deps.tables.getItemId(OO)
        } catch {
          return op
        }
        if (!Vp(KO) || null !== pO && (Number.isNaN(pO) || pO < 0)) return op;
        const bK = null === pO || pO > Dp ? -1 : Math.floor(pO),
          eO = this.queries().craft(XO, KO, bK);
        let lO = op;
        const vK = eO === FO.dd ? null : this.extras();
        if (vK) {
          const [OO, KO, pO] = vK;
          lO = {
            kR: OO,
            uq: KO === FO.Db ? null : KO,
            amountAddedToSlot: pO
          }
        }
        return this.settle(eO), lO
      }
      salvage(OO, KO, pO) {
        let XO;
        try {
          XO = this.deps.tables.getItemId(KO)
        } catch {
          return !1
        }
        return Vp(OO) && Number.isInteger(pO) && this.settle(this.queries().salvage(OO, XO, Math.max(Math.min(pO, Dp), -Dp)))
      }
      craftingView(OO, KO, pO) {
        var XO;
        if (this.stopped) return null;
        const {
          api: bK,
          onError: eO
        } = this.deps, lO = OO ? aX.encode(OO) : null;
        if (null !== lO) {
          if (lO.length > 1024) return eO(new Error(`The crafting station ${OO}'s name is over 1024 bytes`)), null;
          const KO = bK.memoryView(Uint8Array, bK.scratch(), lO.length, "crafting_view's station");
          if (!KO) return null;
          KO.set(lO)
        }
        const vK = Vp(KO) && Vp(pO),
          CO = bK.queries.craftingView(null !== (XO = null === lO || void 0 === lO ? void 0 : lO.length) && void 0 !== XO ? XO : 0, vK ? KO : 0, vK ? pO : 0);
        return CO < FO.cb.BYTES ? (bK.reportCorruption(`crafting_view's answer of ${CO} bytes`), null) : bK.memoryData(bK.scratch(), CO, 1, "crafting_view's answer")
      }
      queries() {
        var OO, KO;
        return !1 === (null === (OO = (KO = this.deps).beforeOp) || void 0 === OO ? void 0 : OO.call(KO)) ? (this.stopped = !0, Fp) : this.deps.api.queries
      }
      extras() {
        const {
          api: OO
        } = this.deps;
        return OO.memoryView(Uint32Array, OO.scratch(), 3, "a sync query's extra words")
      }
      settle(OO) {
        if (OO === FO.cd)(0, ZK.c)();
        else if (OO !== FO.dd) {
          const KO = this.deps.cmd();
          KO && function(OO, KO, pO) {
            return (0, ZK.c)(), (0, FO._f)(OO, KO, pO)
          }(KO, 0, OO) || this.deps.onError(new Error(`Sync op ${OO}'s marker didn't fit the command ring: its send goes after the next frame's commands`))
        }
        return this.stopped || this.refresh(), OO !== FO.dd
      }
    }
    const zX = 1 / .6,
      Ap = [0, 1, 0],
      fp = [0, 0, 0],
      dp = new Uint8Array(0),
      Tp = 1.2 * LK.h.gM,
      Np = new TextEncoder,
      Ip = [0, 0, 0],
      yX = [0, 0, 0],
      gX = new Map;

    function upO(OO) {
      let KO = gX.get(OO);
      return KO || (gX.size >= 64 && gX.clear(), KO = Np.encode(`{"emitRate":${OO}}`), gX.set(OO, KO)), KO
    }

    function Ep(OO) {
      return Number.isFinite(OO) && OO > 0 ? OO : 0
    }

    function jX(OO, KO) {
      for (let pO = 0; pO < 3; pO++) {
        const XO = Math.abs(KO[pO]);
        Ip[pO] = OO[pO] - XO, yX[pO] = 2 * XO
      }
      return Number.isFinite(Ip[0] + Ip[1] + Ip[2] + yX[0] + yX[1] + yX[2])
    }

    function Yp(OO, KO) {
      return "pos1" === OO || "pos2" === OO ? void 0 : KO
    }

    function wp(OO, KO, pO) {
      return OO.length > FO.zd.MaxOpts ? (pO(new Error(`${KO}'s particle opts are over ${FO.zd.MaxOpts} bytes of JSON`)), null) : OO
    }
    const iX = {
      moveTo() {},
      setEmitRate() {},
      emit() {},
      emitPoints() {},
      setDirections() {},
      stop() {},
      dispose() {}
    };
    class rX {
      constructor(OO) {
        this.deps = OO, this.session = 0, this.nextKey = 1, this.live = 0, this.started = !1
      }
      enabled() {
        return null !== this.sink()
      }
      sink() {
        return this.deps.isSessionLive() ? this.deps.cmd() : null
      }
      create(OO, KO) {
        var pO;
        const XO = this.sink(),
          bK = null !== (pO = KO.half) && void 0 !== pO ? pO : fp;
        if (!XO || this.live >= FO.zd.MaxLiveKeys || this.nextKey > FO.zd.MaxKey || !jX(KO.pos, bK)) return iX;
        const eO = this.nextKey,
          lO = wp(function(OO) {
            var KO, pO, XO;
            const bK = JSON.stringify({
              texture: "string" === typeof OO.texture ? OO.texture : "smokePuff",
              YO: OO.YO,
              minLifeTime: OO.minLifeTime,
              maxLifeTime: OO.maxLifeTime,
              minSize: OO.minSize,
              maxSize: OO.maxSize,
              minEmitPower: OO.minEmitPower,
              maxEmitPower: OO.maxEmitPower,
              emitRate: Ep(OO.emitRate),
              gravity: null !== (KO = OO.gravity) && void 0 !== KO ? KO : fp,
              dir1: null !== (pO = OO.dir1) && void 0 !== pO ? pO : Ap,
              dir2: null !== (XO = OO.dir2) && void 0 !== XO ? XO : Ap,
              colorGradients: OO.colorGradients,
              blendMode: OO.blendMode
            });
            return Np.encode(bK)
          }(OO), "createParticles", this.deps.onError);
        return lO && (0, FO.af)(XO, 0, eO, 0, FO.zd.PresetNone, 0, Ip, yX, lO) ? (this.nextKey++, this.live++, this.started = !0, new Pp(this, this.session, eO, OO, bK)) : iX
      }
      playEffect(OO) {
        const KO = this.sink(),
          {
            pos1: pO,
            pos2: XO
          } = OO;
        if (!KO || !pO || !XO) return;
        for (let eO = 0; eO < 3; eO++) Ip[eO] = Math.min(pO[eO], XO[eO]), yX[eO] = Math.abs(XO[eO] - pO[eO]);
        if (!Number.isFinite(Ip[0] + Ip[1] + Ip[2] + yX[0] + yX[1] + yX[2])) return;
        const bK = wp(Np.encode(JSON.stringify(OO, Yp)), "playParticleEffect", this.deps.onError);
        bK && (0, FO.We)(KO, 0, 0, FO.zd.PresetNone, FO.zd.HasBox, 0, Ip, yX, bK)
      }
      burstPreset(OO, KO, pO) {
        const XO = this.sink(),
          bK = Math.min(Math.floor(pO), FO.zd.MaxBurst);
        if (!XO || !Object.hasOwn(FO._b, OO) || !(bK > 0)) return;
        const eO = Tp;
        for (let lO = 0; lO < 3; lO++) Ip[lO] = KO[lO] - eO / 2, yX[lO] = eO;
        Number.isFinite(Ip[0] + Ip[1] + Ip[2]) && (0, FO.We)(XO, 0, 0, FO._b[OO], FO.zd.HasBox, bK, Ip, yX, dp)
      }
      sessionEnded() {
        this.session++;
        const OO = this.started ? this.deps.cmd() : null;
        return this.started = !1, this.nextKey = 1, this.live = 0, !OO || (0, FO.bf)(OO, 0)
      }
      sinkFor(OO) {
        return OO === this.session ? this.deps.cmd() : null
      }
      stop(OO, KO) {
        const pO = this.sinkFor(OO);
        pO && (0, FO.cf)(pO, 0, KO) && this.live--
      }
    }
    class Pp {
      constructor(OO, KO, pO, XO, bK) {
        this.owner = OO, this.session = KO, this.key = pO, this.half = void 0, this.rate = void 0, this.stopDelayMs = void 0, this.emitted = void 0, this.stopped = !1, this.freed = !1, this.half = [Math.abs(bK[0]), Math.abs(bK[1]), Math.abs(bK[2])], this.rate = Ep(XO.emitRate), this.emitted = this.rate > 0;
        const eO = XO.maxLifeTime * zX * 1e3 + 250;
        this.stopDelayMs = eO >= 0 ? Math.min(eO, 2147483647) : 250
      }
      sink() {
        return this.stopped ? null : this.owner.sinkFor(this.session)
      }
      moveTo(OO, KO) {
        const pO = this.sink();
        if (pO) {
          if (KO)
            for (let OO = 0; OO < 3; OO++) this.half[OO] = Math.abs(KO[OO]);
          jX(OO, this.half) && (0, FO.gf)(pO, 0, this.key, FO.zd.HasBox, Ip, yX, dp)
        }
      }
      setEmitRate(OO) {
        const KO = this.sink(),
          pO = Ep(OO);
        KO && pO !== this.rate && (0, FO.gf)(KO, 0, this.key, 0, fp, fp, upO(pO)) && (this.rate = pO, this.emitted ||= pO > 0)
      }
      emit(OO) {
        const KO = this.sink(),
          pO = Math.min(Math.floor(OO), FO.zd.MaxBurst);
        KO && pO > 0 && (0, FO.We)(KO, 0, this.key, FO.zd.PresetNone, 0, pO, fp, fp, dp) && (this.emitted = !0)
      }
      emitPoints(OO, KO, pO) {
        const XO = this.sink(),
          bK = Math.min(Math.floor(pO), FO.zd.MaxPoints, Math.floor(KO.length / 4));
        if (!XO || !(bK > 0) || !Number.isFinite(OO[0] + OO[1] + OO[2])) return;
        const eO = new Uint8Array(KO.buffer, KO.byteOffset, bK * FO.zd.PointBytes);
        (0, FO._e)(XO, 0, this.key, bK, OO, eO) && (this.emitted = !0)
      }
      setDirections(OO, KO) {
        const pO = this.sink();
        if (!pO || !Number.isFinite(OO[0] + OO[1] + OO[2] + KO[0] + KO[1] + KO[2])) return;
        const XO = Np.encode(JSON.stringify({
          dir1: [OO[0], OO[1], OO[2]],
          dir2: [KO[0], KO[1], KO[2]]
        }));
        (0, FO.gf)(pO, 0, this.key, 0, fp, fp, XO)
      }
      stop() {
        const OO = this.sink();
        this.stopped = !0, OO && (this.emitted ? (this.rate > 0 && (0, FO.gf)(OO, 0, this.key, 0, fp, fp, upO(0)), setTimeout((() => {
          this.free()
        }), this.stopDelayMs)) : this.free())
      }
      dispose() {
        this.stopped = !0, this.free()
      }
      free() {
        this.freed || (this.freed = !0, this.owner.stop(this.session, this.key))
      }
    }
    const mX = JK.o,
      sp = new TextDecoder;

    function Hp(OO, KO) {
      const {
        serverIds: pO,
        kinds: XO
      } = OO;
      let bK = 0;
      for (let eO = 0; eO < pO.length; eO++) {
        const OO = pO[eO];
        if (OO !== FO.Vc && !dO(XO[eO])) {
          if (bK === KO.length) {
            const OO = new Int32Array(Math.max(64, 2 * bK));
            OO.set(KO), KO = OO
          }
          KO[bK++] = OO
        }
      }
      return {
        ids: KO,
        count: bK
      }
    }

    function Rp(OO, KO) {
      return OO.length >= KO ? OO : new Int32Array(Math.max(KO, 2 * OO.length))
    }

    function Sp(OO, KO, pO, XO) {
      for (let bK = 0; bK < pO; bK += 4096) {
        const eO = Math.min(4096, pO - bK),
          lO = OO.memoryView(Int32Array, OO.scratch(), eO, "entity_info_batch's ids");
        if (!lO) return !1;
        lO.set(KO.subarray(bK, bK + eO));
        const vK = OO.queries.entityInfoBatch(eO),
          CO = 4294967295 === vK ? null : OO.memoryData(OO.scratch(), vK, 4, "entity_info_batch's records");
        if (!CO) return !1;
        for (let OO = 0; OO + FO.Nb.BYTES <= vK;) {
          const KO = FO.Nb.len(CO, OO);
          XO(FO.Nb.serverId(CO, OO), Jp(CO, OO, KO)), OO += FO.Nb.BYTES + (0, aK.ne)(KO)
        }
      }
      return !0
    }

    function Jp(OO, KO, pO) {
      var XO, bK, eO;
      const lO = FO.Nb.kind(OO, KO),
        vK = 0 === lO ? null : TO(lO);
      if (null === vK) return null;
      const CO = FO.Nb.variation(OO, KO),
        hO = FO.Nb.pose(OO, KO),
        DO = FO.Nb.meta(OO, KO),
        MO = FO.Nb.mesh(OO, KO),
        aK = 0 !== (FO.Nb.flags(OO, KO) & FO.Jb.HasOpts),
        oO = mX[vK];
      return Object.freeze({
        type: vK,
        variation: CO === FO._c ? void 0 : null !== (XO = null !== (bK = null === oO || void 0 === oO ? void 0 : oO[CO]) && void 0 !== bK ? bK : null === oO || void 0 === oO ? void 0 : oO[0]) && void 0 !== XO ? XO : "default",
        pose: hO === FO.ic ? void 0 : null !== (eO = FO.vb[hO]) && void 0 !== eO ? eO : FO.vb[0],
        metaInfo: DO === FO.ic ? void 0 : FO.Lc[DO],
        meshKind: MO === FO.ic ? void 0 : FO.Jc[MO],
        meshOpts: aK ? sp.decode(new Uint8Array(OO.buffer, OO.byteOffset + KO + FO.Nb.BYTES, pO)) : void 0
      })
    }
    const cX = 1,
      Bp = 2;
    class Zp {
      constructor(OO) {
        this.deps = OO, this.wanted = 0, this.JK = !1, this.refused = !1
      }
      get on() {
        return this.JK
      }
      want(OO, KO) {
        this.wanted = KO ? this.wanted | OO : this.wanted & ~OO;
        const pO = 0 !== this.wanted;
        if (pO === this.JK) return;
        const XO = this.deps.cmd();
        null !== XO ? (0, FO.cg)(XO, 0, pO ? 1 : 0) ? (this.JK = pO, this.refused = !1) : this.refused || (this.refused = !0, this.deps.onError(new Error("WatchEntityInfo didn't fit the command ring"))) : this.JK = !1
      }
    }
    class Gp {
      constructor(OO) {
        this.deps = OO, this.entries = new Map, this.complete = !1, this.refill = !1, this.midFrame = !1, this.pending = new Int32Array(64), this.pendingCount = 0, this.ids = new Int32Array(64)
      }
      get(OO) {
        var KO;
        return this.complete || this.fill(), null !== (KO = this.entries.get("string" === typeof OO ? OO : String(OO))) && void 0 !== KO ? KO : null
      }
      inCoreCall() {
        this.midFrame = !0
      }
      stale(OO) {
        if (this.complete) {
          if (this.pendingCount === this.pending.length) {
            const OO = new Int32Array(2 * this.pending.length);
            OO.set(this.pending), this.pending = OO
          }
          this.pending[this.pendingCount++] = OO
        }
      }
      removed(OO) {
        this.entries.size > 0 && this.entries.delete(String(OO))
      }
      refresh() {
        const OO = this.pendingCount;
        if (this.pendingCount = 0, this.midFrame = !1, !this.deps.watch.on || this.refill) return this.complete = !1, void(this.refill = !1);
        if (OO > 0 && this.complete) {
          const {
            api: KO
          } = this.deps;
          let pO = 0;
          const XO = this.ids = Rp(this.ids, OO);
          for (let bK = 0; bK < OO; bK++) {
            const OO = this.pending[bK],
              eO = KO.indexById.get(OO);
            void 0 === eO || dO(KO.kinds[eO]) ? this.entries.delete(String(OO)) : XO[pO++] = OO
          }
          pO > 0 && !this.batch(XO, pO) && (this.complete = !1)
        }
      }
      sessionEnded() {
        this.entries.clear(), this.complete = !1, this.refill = !1, this.midFrame = !1, this.pendingCount = 0, this.deps.watch.want(cX, !1)
      }
      fill() {
        const {
          api: OO
        } = this.deps;
        if (this.complete = !0, this.pendingCount = 0, this.entries.clear(), this.deps.isSessionLive()) {
          const {
            watch: OO
          } = this.deps, KO = OO.on;
          OO.want(cX, !0), !KO && OO.on && (this.refill = this.midFrame)
        }
        const {
          ids: KO,
          count: pO
        } = Hp(OO, this.ids);
        this.ids = KO, pO > 0 && !this.batch(KO, pO) && (this.refill = !0)
      }
      batch(OO, KO) {
        return Sp(this.deps.api, OO, KO, ((OO, KO) => {
          null === KO ? this.entries.delete(String(OO)) : this.entries.set(String(OO), KO)
        }))
      }
    }
    var qX = pO(3943);

    function xX(OO) {
      if ("message" !== OO.type || OO.Tl !== qX.Hb.NewClientOptions || OO.payloadKind !== aK.cc.Msgpack) return null;
      const KO = (0, mK.c)(OO.payload);
      if (null === KO || "object" !== typeof KO || Array.isArray(KO)) throw new Error("NewClientOptions whose body isn't an object of options");
      return KO
    }
    var np = pO(1098),
      Wp = pO(35157);

    function tX(OO, KO, pO, XO, bK, eO, vK) {
      var CO, hO, DO;
      switch (OO) {
        case FO.ae.ToggleMenu: {
          const OO = FO.F[KO];
          lO.i.pl("toggleMenu", void 0 === OO ? "inventory" : `inventory|${OO}`);
          break
        }
        case FO.ae.EditBoard:
          lO.i.pl("EditBoard", {
            pos: 0 === KO ? null : pO
          });
          break;
        case FO.ae.EditCodeBlock:
        case FO.ae.ViewCodeBlock:
          lO.i.pl("EditCodeBlock", {
            pos: pO,
            canChangePos: OO === FO.ae.EditCodeBlock
          });
          break;
        case FO.ae.EditCustomLobbyBlock:
          lO.i.pl("EditCustomLobbyBlock", {
            pos: pO
          });
          break;
        case FO.ae.OpenIronChest:
          lO.i.pl("OpenIronChest", {
            pos: pO
          });
          break;
        case FO.ae.EditNameTag:
          lO.i.pl("EditNameTag", null !== (CO = null === (hO = bK.JK()) || void 0 === hO || null === (DO = hO.attributes.customAttributes) || void 0 === DO ? void 0 : DO.text) && void 0 !== CO ? CO : "");
          break;
        case FO.ae.EditBook: {
          var MO, aK, VO;
          const OO = null === (MO = bK.JK()) || void 0 === MO ? void 0 : MO.attributes;
          lO.i.pl("EditBook", {
            pages: (0, np.O)(null === OO || void 0 === OO || null === (aK = OO.customAttributes) || void 0 === aK ? void 0 : aK.pages),
            title: null !== (VO = null === OO || void 0 === OO ? void 0 : OO.customDisplayName) && void 0 !== VO ? VO : "Title",
            isPublished: !(null === OO || void 0 === OO || !OO.customDescription)
          });
          break
        }
        case FO.ae.CantChangeBlock:
          ! function(OO, KO) {
            const pO = KO.getClientOption("cantChangeError"),
              XO = KO.getClientOption(OO ? "cantBuildError" : "cantBreakError"),
              bK = OO ? pO : XO;
            (KO.getClientOption("canChange") || bK || "You cannot modify this block" !== pO) && lO.i.pl("showBottomMessage", {
              message: XO || pO,
              type: "Error"
            })
          }(1 === KO, eO);
          break;
        case FO.ae.MiddleBarStart:
          lO.i.pl("middleScreenBarInitiate", {
            duration: XO,
            vOO: 1 === pO[0],
            horizBarRemOffset: KO
          });
          break;
        case FO.ae.MiddleBarStop:
          lO.i.pl("middleScreenBarRemove");
          break;
        case FO.ae.Hitmarker:
          lO.i.pl("localGunHitmarker", {
            qOO: 1 === KO
          });
          break;
        case FO.ae.ShotsLeft:
          lO.i.pl("localPlayerNewShotsLeft", XO);
          break;
        case FO.ae.AimingOverlay:
          lO.i.pl("aimingOverlay", 3 === (3 & KO) ? "sniper" : "none");
          break;
        case FO.ae.BottomMessage:
          lO.i.pl("showBottomMessage", JSON.parse(vK()));
          break;
        case FO.ae.Crosshair:
          bK.inaccuracy = (0, sO.f)(XO), (0, Wp.d)().crosshairAccuracy(bK.inaccuracy);
          break;
        case FO.ae.ChargeStage:
          break;
        case FO.ae.EmoteWheelClose:
          lO.i.pl("requestEmoteWheelClose");
          break;
        case FO.ae.BlockMined:
          lO.i.pl("localBlockMined");
          break;
        default:
          throw new oO.e(`UiEvent of no kind: what ${OO}`)
      }
    }
    var kX = pO(36373),
      Up = pO(8321),
      OX = pO(1579),
      KX = pO(35295),
      pX = pO(35217),
      XX = pO(3923);
    const bb = 10,
      eX = {
        player: [],
        chestOrCreative: [],
        chest: null,
        creative: !1,
        selectedSlot: 0,
        freeSlots: 0
      },
      lX = {
        items: [],
        ammo: 0,
        selectedSlot: 0
      },
      vb = {
        gun: !1,
        aimable: !1,
        chargeName: null
      };

    function CX(OO, KO) {
      let pO, XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
        bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
      const eO = () => (pO = (0, OX.p)(pO, KO()), pO);
      return {
        current: eO,
        watch(KO) {
          const pO = () => {
              KO(eO())
            },
            lO = [OO.watch(pO)];
          return null !== XO && lO.push((0, OX.s)((OO => {
            OO.some(XO) && pO()
          }))), null !== bK && lO.push(bK(pO)), () => {
            for (const OO of lO) OO()
          }
        }
      }
    }

    function hX(OO) {
      return OO && {
        name: OO.name,
        amount: OO.amount,
        attributes: OO.attributes
      }
    }
    const DX = new WeakMap;

    function MX(OO) {
      let KO = DX.get(OO);
      return void 0 === KO && (KO = (0, pX.creativeItemIds)().map((KO => ({
        name: OO.nameOfId(KO),
        amount: OO.isStackableId(KO) ? 1 : null,
        attributes: (0, kX.c)("Gun" === (0, pX.itemTypeOf)(KO) ? {
          type: "Gun",
          clipSize: (0, pX.clipSizeOf)(KO)
        } : void 0)
      }))), DX.set(OO, KO)), KO
    }

    function ab(OO, KO, pO, XO) {
      const bK = KO => (OO.flush(XO), KO),
        eO = pO => {
          var XO, bK, eO, lO, vK, CO, hO;
          const DO = OO.slot(pO);
          if (!DO) return null;
          const {
            rootName: MO,
            metaStr: aK
          } = KO.getMetaInfo(DO.name);
          return {
            name: DO.name,
            amount: DO.amount,
            attributes: DO.attributes,
            instance: OO.instance(pO),
            displayName: null !== (XO = DO.attributes.customDisplayName) && void 0 !== XO ? XO : KO.getDisplayName(MO),
            requiresAmmo: "RequiresAmmo" === aK,
            clipSize: null !== (bK = null !== (eO = null === (lO = DO.attributes.customAttributes) || void 0 === lO || null === (vK = lO.gunStats) || void 0 === vK ? void 0 : vK.clipSize) && void 0 !== eO ? eO : null === (CO = KO.getGunStats(MO)) || void 0 === CO ? void 0 : CO.clipSize) && void 0 !== bK ? bK : null === (hO = DO.typeObj) || void 0 === hO ? void 0 : hO.clipSize
          }
        },
        vK = function(OO, KO) {
          let pO = null,
            XO = {
              focus: null,
              recipes: [],
              detail: null
            },
            bK = -1;
          const eO = new Set;
          return {
            read() {
              var eO, lO;
              if (null === pO) return null !== XO.focus && (XO = {
                ...XO,
                focus: null
              }), XO;
              if (XO.focus === pO && bK === OO.changes) return XO;
              if (bK = OO.changes, 0 === OO.length) return XO = {
                focus: pO,
                recipes: [],
                detail: null
              }, XO;
              let vK = 0;
              if (null !== pO.recipe) try {
                vK = KO.getItemId(pO.recipe.name)
              } catch {}
              const CO = OO.craftingView(pO.station, vK, null !== (eO = null === (lO = pO.recipe) || void 0 === lO ? void 0 : lO.WH) && void 0 !== eO ? eO : 0);
              return XO = null === CO ? {
                focus: pO,
                recipes: [],
                detail: null
              } : function(OO, KO, pO) {
                let XO = FO.cb.BYTES;
                const bK = [];
                for (let DO = FO.cb.recipes(OO, 0); DO > 0; DO--) {
                  const pO = FO.Z.flags(OO, XO),
                    eO = {
                      name: KO.nameOfId(FO.Z.item(OO, XO)),
                      WH: FO.Z.recipe(OO, XO),
                      requires: [],
                      produces: FO.Z.produces(OO, XO),
                      haveIngredients: 0 !== (pO & FO.Y.HaveIngredients),
                      listed: 0 !== (pO & FO.Y.Listed)
                    };
                  let lO = FO.Z.requires(OO, XO);
                  for (XO += FO.Z.BYTES; lO > 0; lO--) {
                    const pO = FO._.items(OO, XO);
                    eO.requires.push({
                      items: VX(OO, XO + FO._.BYTES, pO, KO),
                      amt: FO._.amount(OO, XO)
                    }), XO += FO._.BYTES + 2 * pO
                  }
                  bK.push(eO)
                }
                const eO = FO.cb.flags(OO, 0);
                if (null === pO.recipe || 0 === (eO & FO.bb.Detail)) return {
                  focus: pO,
                  recipes: bK,
                  detail: null
                };
                const lO = {},
                  vK = {};
                for (let DO = FO.cb.ingredients(OO, 0); DO > 0; DO--) {
                  const pO = FO.X.item(OO, XO),
                    bK = FO.X.from(OO, XO),
                    eO = FO.X.amount(OO, XO);
                  XO += FO.X.BYTES;
                  const CO = bK === FO.D ? null : VX(OO, XO, bK, KO);
                  if (null !== CO && (XO += 2 * bK), 0 === pO) continue;
                  const hO = KO.nameOfId(pO);
                  lO[hO] = eO, null !== CO && (vK[hO] = CO)
                }
                const {
                  name: CO,
                  WH: hO
                } = pO.recipe;
                return {
                  focus: pO,
                  recipes: bK,
                  detail: {
                    name: CO,
                    WH: hO,
                    craftAllTimes: FO.cb.craftAllTimes(OO, 0),
                    roomForOne: 0 !== (eO & FO.bb.RoomForOne),
                    resultStackable: Boolean(KO.getItemStat(CO, "stackable")),
                    amounts: lO,
                    ingredientsCraftedFrom: vK
                  }
                }
              }(CO, KO, pO), XO
            },
            setFocus(OO) {
              pO = OO;
              for (const KO of [...eO]) KO()
            },
            watchFocus: OO => (eO.add(OO), () => {
              eO.delete(OO)
            })
          }
        }(OO, KO);
      return {
        states: {
          inventory: CX(OO, (() => {
            const pO = OO.length;
            if (0 === pO) return eX;
            const XO = [];
            for (let KO = 0; KO < FO.kd; KO++) XO.push(hX(OO.slot(KO)));
            const bK = OO.slotIcon,
              eO = XO[OO.selectedSlot];
            0 !== bK && eO && (XO[OO.selectedSlot] = {
              ...eO,
              icon: KO.nameOfId(bK)
            });
            const lO = !0 === KO.getClientOption("creative");
            let vK = [],
              CO = null;
            if (pO > FO.kd) {
              for (let KO = FO.kd; KO < pO; KO++) vK.push(hX(OO.slot(KO)));
              CO = {
                type: null,
                pos: [...OO.hiO],
                numSlots: pO - FO.kd,
                ironChest: null
              }
            } else lO && (vK = MX(KO));
            return {
              player: XO,
              chestOrCreative: vK,
              chest: CO,
              creative: lO,
              selectedSlot: OO.selectedSlot,
              freeSlots: OO.freeSlots()
            }
          }), (0, OX.n)("creative")),
          hotbar: CX(OO, (() => {
            if (0 === OO.length) return lX;
            const KO = [];
            for (let OO = 0; OO < bb; OO++) KO.push(eO(OO));
            return {
              items: KO,
              ammo: OO.amountOf("Ammo"),
              selectedSlot: OO.selectedSlot
            }
          }), (0, OX.j)("DisplayName", "GunStats")),
          crafting: CX(OO, vK.read, null, vK.watchFocus),
          heldItemAim: CX(OO, (() => {
            var KO;
            if (!pO()) return vb;
            const XO = null === (KO = OO.JK()) || void 0 === KO ? void 0 : KO.typeObj,
              bK = "Gun" === (null === XO || void 0 === XO ? void 0 : XO.type);
            return {
              gun: bK,
              aimable: bK || !0 === (null === XO || void 0 === XO ? void 0 : XO.showsAimingUi),
              chargeName: "Chargeable" === (null === XO || void 0 === XO ? void 0 : XO.type) ? XO.name : null
            }
          }), null, (OO => function(OO, KO) {
            let pO = OO();
            return (0, XX.v)((() => {
              const XO = OO();
              XO !== pO && (pO = XO, KO(XO))
            }))
          }(pO, OO)))
        },
        events: {
          hotbarSlotRequested: (0, OX.c)("setSelectedInventorySlotI"),
          hotbarScrolled: (0, OX.c)("ScrollInventorySlot"),
          numberKeyPressed: (0, OX.c)("numkeyPressed"),
          inventoryDropRequested: (0, OX.c)("DropInvenItem"),
          chestToggled: (0, OX.c)("chestToggleFromServer"),
          chestRefreshed: (0, OX.c)("chestRefreshedFromServer", FX),
          inventorySynced: (0, OX.c)("syncedInvenFromServer", FX),
          enchantingTableOpened: (0, OX.c)("enchantingTable", (OO => {
            let {
              position: pO,
              yl: XO
            } = OO;
            return {
              position: [...pO],
              blockName: KO.getMetaInfo(XO).rootName
            }
          }))
        },
        commands: {
          selectHotbarSlot(KO) {
            OO.selectSlot(KO), OO.flush(XO)
          },
          removeInventoryItem(KO) {
            let {
              slot: pO,
              amount: XO,
              drop: eO
            } = KO;
            return bK(OO.remove(pO, XO, eO))
          },
          swapInventorySlots(KO) {
            let {
              a: pO,
              b: XO
            } = KO;
            return bK(OO.swap(pO, XO))
          },
          moveInventoryItem(KO) {
            let {
              from: pO,
              to: XO,
              amount: eO
            } = KO;
            return bK(OO.move(pO, XO, eO))
          },
          quickMoveInventoryItem(KO) {
            let {
              slot: pO,
              start: XO,
              end: eO,
              amount: lO
            } = KO;
            return bK(OO.quickMove(pO, XO, eO, lO))
          },
          closeChest() {
            OO.closeChest(), OO.flush(XO), lO.i.pl("chestClosedByPlayer")
          },
          focusCrafting(OO) {
            vK.setFocus(OO)
          },
          craftRecipe(KO) {
            let {
              name: pO,
              WH: XO,
              times: eO
            } = KO;
            return bK(OO.craft(pO, XO, eO))
          },
          salvageItem(KO) {
            let {
              slot: pO,
              name: XO,
              amount: eO
            } = KO;
            return bK(OO.salvage(pO, XO, eO))
          },
          enchantItem(KO) {
            let {
              slot: pO,
              level: XO,
              tablePos: bK
            } = KO;
            OO.enchant(pO, XO, bK)
          }
        },
        queries: {
          enchantingOffer(pO) {
            let {
              slot: XO,
              blockName: bK
            } = pO;
            return function(OO, KO, pO, XO) {
              const bK = OO.slot(pO);
              if (!bK || !KO.getClientOption("canCraft") || !(0, Up.u)(XO) || (0, Up.r)(bK.attributes)) return oX;
              const eO = (0, pX.enchantmentPerksOf)(KO.getItemId(bK.name));
              if (0 === eO.length) return oX;
              const lO = [];
              for (let vK = 0; vK < KX.c; vK++) {
                const {
                  commonProb: OO,
                  uncommonProb: KO,
                  rareProb: pO,
                  epicProb: bK,
                  legendaryProb: eO,
                  level: CO
                } = (0, Up.i)(XO, vK);
                lO.push({
                  level: CO,
                  odds: [OO, KO, pO, bK, eO].map((OO => 100 * OO))
                })
              }
              return {
                perks: [...eO],
                options: lO
              }
            }(OO, KO, XO, bK)
          }
        }
      }
    }
    const oX = Object.freeze({
      perks: [],
      options: []
    });

    function FX() {
      return null
    }

    function VX(OO, KO, pO, XO) {
      const bK = [];
      for (let eO = 0; eO < pO; eO++) {
        const pO = OO.getUint16(KO + 2 * eO, !0);
        0 !== pO && bK.push(XO.nameOfId(pO))
      }
      return bK
    }
    class LX {
      constructor(OO) {
        this.api = OO, this.positions = new Map, this.targeted = {
          blO: 0,
          position: [0, 0, 0],
          normal: [0, 0, 0],
          Se: [0, 0, 0]
        }, this.hasTarget = !1, this.breaking = [0, 0, 0], this.isBreaking = !1
      }
      position(OO) {
        let KO = this.positions.get(OO);
        return KO || (this.api.checkValid(OO) || this.api.isLocal(OO) ? (KO = [NaN, NaN, NaN], this.api.readPosition(OO, KO), this.positions.set(OO, KO), KO) : null)
      }
      zCO() {
        return this.hasTarget ? this.targeted : null
      }
      breakingPosition() {
        return this.isBreaking ? this.breaking : null
      }
      refresh() {
        for (const [KO, pO] of this.positions) this.api.readPosition(KO, pO) || this.api.checkValid(KO) || this.api.isLocal(KO) || this.positions.delete(KO);
        const OO = this.api.apiView;
        if (this.refreshTarget(), this.isBreaking = 0 !== (FO.t.playerFlags(OO, 0) & FO.Ad.Breaking) && FO.t.breakingProgress(OO, 0) >= 0, this.isBreaking)
          for (let KO = 0; KO < 3; KO++) this.breaking[KO] = FO.t.breakingPos(OO, 0, KO)
      }
      refreshTarget() {
        const OO = this.api.apiView,
          KO = FO.t.targetBlockId(OO, 0);
        if (this.hasTarget = KO !== FO.Xc, this.hasTarget) {
          const pO = this.targeted;
          pO.blO = KO;
          for (let KO = 0; KO < 3; KO++) pO.position[KO] = FO.t.targetBlock(OO, 0, KO), pO.normal[KO] = FO.t.targetNormal(OO, 0, KO), pO.Se[KO] = FO.t.targetAdjacent(OO, 0, KO)
        }
      }
      despawned(OO) {
        const KO = this.positions.get(OO);
        KO && !this.api.isLocal(OO) && (KO.fill(NaN), this.positions.delete(OO))
      }
    }
    var QX = pO(38721),
      zb = pO(38700),
      AX = pO(35290);
    const fX = 1,
      dX = 2;
    class TX {
      constructor() {
        this.game = new AX.d, this.client = new AX.d, this.JK = 0
      }
      setGame(OO) {
        if (null === OO || "object" !== typeof OO) return !1;
        const {
          key: KO,
          value: pO
        } = OO;
        return "string" === typeof KO && (this.game.setBooleanType(KO, Boolean(pO)), !0)
      }
      setClient(OO, KO) {
        this.client.setBooleanType(OO, KO)
      }
      clearGame() {
        this.game = new AX.d
      }
      perms() {
        return (this.game._getTotalBooleanVal() ? fX : 0) | (this.client._getTotalBooleanVal() ? dX : 0)
      }
      write(OO) {
        const KO = this.perms();
        return KO === this.JK || !(!OO || !(0, FO.ye)(OO, 0, FO.Rb.Keep, KO)) && (this.JK = KO, !0)
      }
    }
    class NX {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => 35;
        this.api = OO, this.screenBandPct = void 0, this.clipX = 0, this.clipY = 0, this.clipW = 0, this.eye = [0, 0, 0], this.forward = [0, 0, 1], this.along = [0, 0, 0], this.screenBandPct = {
          x: vK.e,
          get y() {
            return KO()
          }
        }
      }
      get hasView() {
        const OO = this.api.apiView,
          KO = FO.t.viewProj;
        return 0 !== KO(OO, 0, 3) || 0 !== KO(OO, 0, 7) || 0 !== KO(OO, 0, 11) || 0 !== KO(OO, 0, 15)
      }
      get cameraPosition() {
        const OO = this.api.apiView,
          {
            eye: KO
          } = this;
        for (let pO = 0; pO < 3; pO++) KO[pO] = FO.t.eye(OO, 0, pO);
        return KO
      }
      get cameraDirection() {
        const OO = this.api.apiView,
          KO = FO.t.viewProj,
          pO = KO(OO, 0, 3),
          XO = KO(OO, 0, 7),
          bK = KO(OO, 0, 11),
          eO = Math.hypot(pO, XO, bK),
          {
            forward: lO
          } = this;
        return eO > 0 && (lO[0] = pO / eO, lO[1] = XO / eO, lO[2] = bK / eO), lO
      }
      get cameraHeading() {
        return FO.t.heading(this.api.apiView, 0)
      }
      get cameraPitch() {
        return FO.t.pitch(this.api.apiView, 0)
      }
      get tanHalfFovX() {
        return FO.t.tanHalfFovX(this.api.apiView, 0)
      }
      get tanHalfFovY() {
        return FO.t.tanHalfFovY(this.api.apiView, 0)
      }
      projectWorldPosToScreenPos(OO) {
        this.clip(OO);
        const {
          clipX: KO,
          clipY: pO,
          clipW: XO
        } = this;
        if (XO > 0) {
          const OO = KO / XO * 50,
            bK = -pO / XO * 50;
          return Math.abs(OO) <= this.screenBandPct.x && Math.abs(bK) <= this.screenBandPct.y ? {
            x: 50 + OO,
            y: 50 + bK
          } : this.clampToBand(OO, bK)
        }
        const bK = this.cameraPosition,
          eO = Math.hypot(OO[0] - bK[0], OO[1] - bK[1], OO[2] - bK[2]),
          lO = this.api.apiView,
          vK = FO.t.viewProj,
          CO = eO > 0 ? KO / eO : 0,
          hO = eO > 0 ? -pO / eO : 0,
          DO = Math.hypot(vK(lO, 0, 1), vK(lO, 0, 5), vK(lO, 0, 9)),
          MO = CO / Math.hypot(vK(lO, 0, 0), vK(lO, 0, 4), vK(lO, 0, 8)),
          aK = hO / DO,
          oO = !(Math.abs(MO) >= .001 || Math.abs(aK) >= .001);
        return this.clampToBand(CO, oO ? -(DO || 1) : hO)
      }
      projectDirectionToScreenPos(OO) {
        if (!this.hasView) return;
        const KO = this.cameraPosition,
          pO = this.along;
        for (let XO = 0; XO < 3; XO++) pO[XO] = KO[XO] + 10 * OO[XO];
        return this.projectWorldPosToScreenPos(pO)
      }
      projectWorldPosToViewport(OO) {
        this.clip(OO);
        const {
          clipX: KO,
          clipY: pO,
          clipW: XO
        } = this;
        return XO > 0 ? {
          x: 50 + KO / XO * 50,
          y: 50 - pO / XO * 50
        } : null
      }
      clip(OO) {
        const KO = this.api.apiView,
          pO = OO[0] - FO.t.origin(KO, 0, 0),
          XO = OO[1] - FO.t.origin(KO, 0, 1),
          bK = OO[2] - FO.t.origin(KO, 0, 2),
          eO = FO.t.viewProj;
        this.clipX = eO(KO, 0, 0) * pO + eO(KO, 0, 4) * XO + eO(KO, 0, 8) * bK + eO(KO, 0, 12), this.clipY = eO(KO, 0, 1) * pO + eO(KO, 0, 5) * XO + eO(KO, 0, 9) * bK + eO(KO, 0, 13), this.clipW = eO(KO, 0, 3) * pO + eO(KO, 0, 7) * XO + eO(KO, 0, 11) * bK + eO(KO, 0, 15)
      }
      clampToBand(OO, KO) {
        return (0, vK.f)(OO, KO, this.screenBandPct.x, this.screenBandPct.y)
      }
    }
    var IX = pO(3955);
    const yb = new TextEncoder,
      gb = new Uint8Array(FO.N * FO.J);
    class uX {
      constructor() {
        this.buttons = [], this.JK = !0
      }
      set(OO) {
        this.buttons = OO, this.JK = !1
      }
      attached() {
        this.JK = 0 === this.buttons.length
      }
      write(OO) {
        if (this.JK) return;
        const KO = new Uint8Array(FO.N),
          pO = new Uint8Array(FO.N);
        let XO = 0,
          bK = 0;
        for (const {
            id: eO,
            keycode: lO
          }
          of this.buttons) {
          if (XO === FO.N) break;
          const {
            read: OO,
            written: vK
          } = yb.encodeInto(eO, gb.subarray(bK, bK + FO.J));
          if (OO < eO.length) continue;
          const CO = IX.i[lO];
          KO[XO] = "number" === typeof CO ? CO : 0, pO[XO] = vK, XO++, bK += vK
        }
        this.JK = (0, FO.ne)(OO, 0, XO, KO, pO, gb.subarray(0, bK))
      }
    }

    function EX(OO, KO, pO) {
      const XO = yb.encode(KO);
      return XO.length <= FO.J && function(OO, KO, pO, XO) {
        return (0, ZK.c)(), (0, FO.jf)(OO, KO, pO, XO)
      }(OO, 0, pO ? 1 : 0, XO)
    }
    const jb = new TextDecoder,
      YX = new TextEncoder,
      wX = new Uint8Array(0),
      ib = {
        off: FO.Dd.Off,
        key: FO.Dd.Key,
        touch: FO.Dd.Touch
      };
    class rb {
      constructor(OO) {
        var KO;
        this.options = OO, this.renderFrame = void 0, this.live = void 0, this.chunks = void 0, this.items = void 0, this.entityInfo = void 0, this.entityInfoWatch = void 0, this.particles = void 0, this.clientApi = void 0, this.scriptedCamera = void 0, this.owners = [], this.tickers = [], this.renderers = [], this.receivers = [], this.failures = [], this.vetoSet = !1, this.hooksSet = !1, this.writtenPublicLobby = !1, this.promptWatch = "off", this.promptWatchSent = "off", this.customButtons = new uX, this.generation = 0, this.sessionLive = !1, this.boundId = 0, this.session = null, this.activeConn = 0, this.closedThrough = 0, this.openSocket = 0, this.socketLeftSinceAttach = !1, this.ticks = 0, this.zoomUnshown = !1, this.zoomHeld = !1, this.overflowGen = 0, this.resyncOwed = !1, this.zoom = 0, this.pendingZoom = null, this.cmd = null, this.freeCam = new TX, this.stopped = () => !1, this.onError = void 0, this.api = void 0, this.tables = void 0, this.itemSources = null, this.fault = void 0, this.CX = OO => {
          if ((0, oO.i)(OO)) throw OO;
          this.onError(OO)
        }, this.api = OO.api, this.tables = OO.tables, this.onError = null !== (KO = OO.onError) && void 0 !== KO ? KO : OO => {
          console.error("Error in client game callback", OO)
        }, this.renderFrame = new NX(this.api, OO.screenBandY), this.live = new LX(this.api), this.chunks = new hK(this.api.memory, (() => this.api.apiView)), this.items = new Qp({
          api: this.api,
          tables: OO.tables,
          cmd: () => this.cmd,
          onError: this.onError,
          beforeOp: OO.beforeOp
        });
        const pO = () => this.stopped() ? null : this.cmd,
          XO = () => this.sessionLive;
        this.entityInfoWatch = new Zp({
          cmd: pO,
          onError: this.onError
        }), this.entityInfo = new Gp({
          api: this.api,
          watch: this.entityInfoWatch,
          isSessionLive: XO
        }), this.particles = new rX({
          cmd: pO,
          isSessionLive: XO,
          onError: this.onError
        }), this.clientApi = new Cp({
          api: this.api,
          live: this.live,
          chunks: this.chunks,
          items: this.items,
          entityInfo: this.entityInfo,
          particles: this.particles,
          tables: OO.tables,
          cmd: pO,
          sendCmd: () => this.sendCmd(),
          isSessionLive: XO,
          beforeWrite: () => {
            var KO;
            if (this.stopped()) return !1;
            const pO = this.generation;
            return !1 !== (null === (KO = OO.beforeWrite) || void 0 === KO ? void 0 : KO.call(OO)) && pO === this.generation
          },
          playerDbId: () => {
            const OO = this.session;
            if (null === OO) throw new Error("No game session has started, so the local player has no DB id");
            return OO.playerDbId
          },
          playSound: OO.playSound,
          setLocalOptions: OO.setLocalOptions,
          hasPackModel: OO.hasPackModel
        }), this.scriptedCamera = new qK({
          api: this.api,
          cmd: () => this.stopped() ? null : this.cmd,
          screen: OO.cameraScreen,
          showFacing: OO.showCameraFacing
        })
      }
      get itemBridgeSources() {
        return this.itemSources ??= ab(this.items, this.tables, (() => this.localPlayerAlive()), this.CX), this.itemSources
      }
      get isSessionLive() {
        return this.sessionLive
      }
      get isCoreRunning() {
        return this.sessionLive && !this.stopped()
      }
      localPlayerAlive() {
        return !this.sessionLive || this.stopped() || !1 !== this.api.isAlive(this.boundId)
      }
      localDeaths() {
        return this.isCoreRunning ? this.api.localDeaths() : null
      }
      clickCodeBlock(OO) {
        const KO = this.sessionLive ? this.sendCmd() : null;
        return null !== KO && (pO = KO, XO = 0, bK = OO[0], eO = OO[1], lO = OO[2], (0, ZK.c)(), (0, FO.se)(pO, XO, bK, eO, lO));
        var pO, XO, bK, eO, lO
      }
      cameraZoom() {
        return this.zoom
      }
      setCameraZoom(OO) {
        const KO = this.liveCmd();
        return null === KO ? (this.pendingZoom = OO, !1) : (this.pendingZoom = null, (0, FO.Xf)(KO, 0, OO, 1))
      }
      QKO(OO) {
        const KO = this.stopped() ? null : this.cmd;
        return null !== KO && (0, FO.Tf)(KO, 0, OO ? 1 : 0)
      }
      respawn() {
        const OO = this.sessionLive ? this.sendCmd() : null;
        return null !== OO && (KO = OO, pO = 0, (0, ZK.c)(), (0, FO.wf)(KO, pO));
        var KO, pO
      }
      bindCustomButtonKeys(OO) {
        this.customButtons.set(OO)
      }
      pressCustomButton(OO, KO) {
        const pO = this.sessionLive ? this.sendCmd() : null;
        return null !== pO && EX(pO, OO, KO)
      }
      padMove(OO, KO, pO, XO, bK, eO) {
        const lO = this.liveCmd();
        return null !== lO && (0, FO.Ue)(lO, 0, OO, KO, pO, XO, bK, eO)
      }
      thirdPersonFor(OO) {
        const KO = this.liveCmd();
        return null !== KO && (0, FO.bg)(KO, 0, null !== OO && void 0 !== OO ? OO : 1 / 0)
      }
      send(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = 0 !== this.openSocket || this.sessionLive ? this.sendCmd() : null;
        return null !== XO && GK(XO, pO ? aK.gd : 0, OO, (0, mK.e)(KO))
      }
      socketAttached(OO) {
        this.openSocket = OO, this.socketLeftSinceAttach = !1
      }
      socketDetached(OO) {
        this.openSocket === OO && (this.openSocket = 0)
      }
      socketLeft() {
        this.openSocket = 0, this.socketLeftSinceAttach = !0
      }
      sendCmd() {
        return this.socketLeftSinceAttach || this.stopped() ? null : this.cmd
      }
      liveCmd() {
        return this.isCoreRunning ? this.cmd : null
      }
      attach(OO) {
        const KO = () => OO.isStopped;
        this.stopped = KO, this.cmd = OO.rings.cmd, this.promptWatchSent = "off", this.writePromptWatch(), this.customButtons.attached(), this.writeCustomButtons();
        const pO = this.api.apiView;
        this.overflowGen = FO.t.eventOverflowGen(pO, 0), this.resyncOwed = 0 !== FO.t.eventOverflowMask(pO, 0), OO.setGameHost(this), OO.setEventWalker((OO => {
          this.api.walk(OO, this, KO)
        }))
      }
      watchPromptPick(OO) {
        this.promptWatch = OO, this.writePromptWatch()
      }
      get promptEntity() {
        return "off" === this.promptWatch || this.stopped() ? null : PX(FO.t.promptEntity(this.api.apiView, 0))
      }
      get interactLabel() {
        return "touch" !== this.promptWatch || this.stopped() ? FO.rc.None : FO.t.interactLabel(this.api.apiView, 0)
      }
      get interactIcon() {
        return "touch" !== this.promptWatch || this.stopped() ? 0 : FO.t.interactIcon(this.api.apiView, 0)
      }
      closeGame() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        (0 === OO || OO >= this.openSocket) && (this.openSocket = 0), this.closedThrough = Math.max(this.closedThrough, OO, this.activeConn), this.activeConn = 0, this.endSession(), this.endGameGrants(), this.dropGameCamera()
      }
      gameCamera(OO) {
        0 !== this.activeConn && this.scriptedCamera.settingsChanged(OO)
      }
      netEvent(OO) {
        "connection" === OO.type ? OO.phase === aK.F.Activated && OO.conn !== this.activeConn && OO.conn > this.closedThrough ? (this.endSession(), this.activeConn = OO.conn, this.endGameGrants(), this.dropGameCamera()) : OO.phase !== aK.F.Left && OO.phase !== aK.F.Closed || OO.conn !== this.activeConn ? OO.phase === aK.F.Resumed && 0 !== this.activeConn && OO.conn > this.closedThrough && (this.activeConn = OO.conn) : this.closeGame() : OO.conn === this.activeConn && 0 !== OO.conn && (OO.Tl === zb.t ? this.gunHit(OO.payload) : OO.Tl === qX.Hb.EditItemCraftingRecipes || OO.Tl === zb.U ? this.items.touch() : (this.serverOptions(OO), this.gameMessage(OO)));
        const KO = this.options.onNetEvent;
        KO && this.guard((() => {
          KO(OO)
        }))
      }
      serverOptions(OO) {
        const KO = this.options.serverOptions,
          pO = KO ? this.decoded(xX, OO) : null;
        KO && pO && this.guard((() => {
          KO.applyNewClientOptions(pO)
        }))
      }
      gameMessage(OO) {
        let KO = null;
        try {
          KO = function(OO) {
            if ("message" !== OO.type || OO.Tl !== qX.Hb.GameCodeMessage || OO.payloadKind !== aK.cc.Msgpack) return null;
            const KO = (0, mK.c)(OO.payload);
            if (null === KO || "object" !== typeof KO || "string" !== typeof KO.messageType) throw new Error("GameCodeMessage without a messageType");
            return KO
          }(OO)
        } catch (pO) {
          this.sessionLive && this.onError(pO)
        }
        if (KO) {
          const {
            messageType: OO,
            data: pO
          } = KO;
          if ((0, EO.i)(OO)) return void this.guard((() => {
            (0, EO.e)(OO, pO)
          }));
          "freeCamPerms" === OO && this.freeCam.setGame(pO) && this.writeFreeCam(), this.sessionLive && this.round(this.receivers, (KO => {
            KO.onReceivedMessageFromServer(OO, pO)
          }))
        }
      }
      decoded(OO, KO) {
        try {
          return OO(KO)
        } catch (pO) {
          return this.onError(pO), null
        }
      }
      setClientFreeCameraGrant(OO, KO) {
        this.freeCam.setClient(OO, KO), this.writeFreeCam()
      }
      localPlayerBound(OO) {
        var KO, pO;
        if (0 === this.activeConn || this.sessionLive && OO === this.boundId) return;
        const XO = this.sessionLive;
        let bK, eO, lO, vK;
        this.endSession(), XO && this.restartGameCamera();
        try {
          var CO;
          this.session = null;
          const OO = this.options.sessionInfo(this.activeConn);
          if (this.session = OO, !OO) return;
          bK = OO.gameNameWithVariation, eO = null !== (CO = (0, gK.Lb)(bK)) && void 0 !== CO ? CO : void 0, lO = (0, uO.u)(OO.lobbyName), vK = (0, uO.J)(OO.lobbyName)
        } catch (zK) {
          return void this.onError(zK)
        }
        const hO = {
          localPlayerId: String(OO)
        };
        let DO = {},
          MO = {};
        try {
          var aK, oO;
          DO = null !== (aK = null === (oO = this.options.gameFactory((0, gK.Qb)(bK))) || void 0 === oO ? void 0 : oO(vK, lO, eO, hO)) && void 0 !== aK ? aK : {}
        } catch (zK) {
          this.CX(zK)
        }
        try {
          var FO, VO;
          MO = {
            ...null === (FO = (VO = this.options).defaultPlugins) || void 0 === FO ? void 0 : FO.call(VO, vK, lO, eO, hO),
            ...DO.plugins
          }
        } catch (zK) {
          this.CX(zK)
        }
        const LO = [DO, ...Object.values(MO)];
        this.owners = LO, this.tickers = LO.filter((OO => void 0 !== OO.KK)), this.renderers = LO.filter((OO => void 0 !== OO.onAfterRender)), this.receivers = LO.filter((OO => void 0 !== OO.onReceivedMessageFromServer)), this.writeAltVeto(LO), this.writeHooks(LO), this.writePublicLobby(vK), this.writeLocalDbId(null !== (KO = null === (pO = this.session) || void 0 === pO ? void 0 : pO.playerDbId) && void 0 !== KO ? KO : null), this.boundId = OO, this.sessionLive = !0, this.generation++, null !== this.pendingZoom && this.setCameraZoom(this.pendingZoom), this.round(LO, (OO => {
          var KO;
          null === (KO = OO.onCreate) || void 0 === KO || KO.call(OO, this.clientApi)
        }));
        const QO = this.generation;
        setTimeout((() => {
          QO === this.generation && !0 === this.tables.getClientOption("creative") && MX(this.tables)
        }), 0)
      }
      chunkSlot(OO, KO, pO, XO, bK, eO) {
        this.chunks.apply(OO, KO, pO, XO, bK, eO)
      }
      entityAdded(OO) {
        var KO;
        this.entityInfo.stale(OO), null === (KO = this.options.replayEntities) || void 0 === KO || KO.entityAdded(OO)
      }
      entityInfoChanged(OO) {
        var KO;
        this.entityInfo.stale(OO), null === (KO = this.options.replayEntities) || void 0 === KO || KO.entityInfoChanged(OO)
      }
      afterPrescan() {
        this.items.refresh(), this.entityInfo.refresh(), this.api.rereadDirectory(), this.chunks.refresh(), this.live.refresh()
      }
      tickEnd() {
        if (this.ticks++, this.tickers.length > 0) {
          const OO = performance.now();
          this.round(this.tickers, mb), (0, XX.e)(performance.now() - OO)
        }
      }
      afterWalk(OO) {
        this.ackEventOverflow(), this.clientApi.flushOwed();
        const KO = this.options.replayEntities;
        KO && this.guard((() => {
          this.entityInfoWatch.want(Bp, KO.wantsWatch), KO.flush(this.entityInfoWatch.on)
        }));
        const pO = (0, XX.j)(OO, FO.t.frameMs(this.api.apiView, 0));
        if (null !== pO) {
          const OO = this.renderFrame;
          this.guard((() => {
            (0, Wp.d)().turnDamageIndicators(OO.cameraHeading)
          })), this.guard((() => {
            this.clientApi.slideRoute(pO)
          })), this.round(this.renderers, (KO => {
            KO.onAfterRender(pO, OO)
          }))
        }
        this.writeFreeCam();
        try {
          this.scriptedCamera.afterFrame(null !== pO)
        } catch (bK) {
          this.CX(bK)
        }
        this.showZoom(), this.items.flush(this.CX), this.writePromptWatch(), this.writeCustomButtons();
        const XO = this.ticks;
        this.ticks = 0, (0, XX.g)(XO, OO, pO, this.CX)
      }
      entityRemoved(OO) {
        this.live.despawned(OO), this.entityInfo.removed(OO)
      }
      ackEventOverflow() {
        const OO = this.api.apiView,
          KO = FO.t.eventOverflowGen(OO, 0),
          pO = KO - this.overflowGen >>> 0;
        if (0 === pO && !this.resyncOwed) return;
        this.overflowGen = KO;
        const XO = FO.t.eventOverflowMask(OO, 0),
          bK = this.cmd;
        0 === XO || null === bK || this.stopped() ? this.resyncOwed = !1 : this.resyncOwed = !(0, FO.ue)(bK, 0, XO);
        const eO = this.options.onEventOverflow;
        0 !== pO && eO && this.guard((() => {
          eO(XO, pO)
        }))
      }
      gameCall(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        if (OO === FO.fc.Director) try {
          return this.scriptedCamera.call(KO, pO, XO, bK, eO, lO)
        } catch (hO) {
          return this.CX(hO), FO.gb.None
        }
        if (!this.sessionLive || void 0 !== this.fault) return OO === FO.fc.AltVeto ? FO.l.Allow : 0;
        try {
          return this.callGames(OO, KO, pO, XO, bK, eO, lO, vK)
        } catch (hO) {
          throw (0, oO.i)(hO) && (this.fault = hO), hO
        }
      }
      takeFault() {
        const OO = this.fault;
        return this.fault = void 0, OO
      }
      callGames(OO, KO, pO, XO, bK, eO, lO, vK) {
        this.api.rereadDirectory(), this.chunks.touch(), this.items.refresh(), this.live.refresh(), this.entityInfo.inCoreCall();
        const {
          tables: CO
        } = this.options, hO = String(this.boundId);
        switch (OO) {
          case FO.fc.AltVeto:
          case FO.fc.AltAction: {
            const vK = 0 !== lO,
              [DO, MO, aK] = vK ? [KO, pO, XO] : [void 0, void 0, void 0],
              oO = vK ? CO.nameOfId(bK) : "Air",
              VO = PX(eO);
            if (OO === FO.fc.AltAction) return this.first((OO => {
              var KO;
              return null === (KO = OO.onPlayerAltAction) || void 0 === KO ? void 0 : KO.call(OO, hO, DO, MO, aK, oO, VO)
            })), 0;
            const LO = this.first((OO => {
              var KO;
              return null === (KO = OO.onPlayerAttemptAltAction) || void 0 === KO ? void 0 : KO.call(OO, hO, DO, MO, aK, oO, VO)
            }));
            return "preventAction" === LO ? FO.l.Prevent : "preventPlacement" === LO ? FO.l.PreventPlacement : FO.l.Allow
          }
          case FO.fc.Click: {
            const OO = vK,
              DO = 0 !== (OO & FO.U.Alt),
              MO = 0 !== (OO & FO.U.HasPos),
              aK = MO ? CO.nameOfId(bK) : "Air",
              [oO, VO, LO] = MO ? [KO, pO, XO] : [null, null, null],
              QO = PX(eO),
              zK = 0 !== (OO & FO.U.Up),
              AO = PX(lO);
            if (0 === (OO & FO.U.AttackOnly) && this.first((OO => {
                var KO, pO;
                return zK ? null === (KO = OO.onPlayerClickUp) || void 0 === KO ? void 0 : KO.call(OO, hO, DO, oO, VO, LO, aK, QO) : null === (pO = OO.onPlayerClick) || void 0 === pO ? void 0 : pO.call(OO, hO, DO, oO, VO, LO, aK, QO)
              })), !zK && !DO && null !== AO) {
              const OO = this.clientApi.getPositionView(AO),
                KO = OO ? [OO[0], OO[1], OO[2]] : [0, 0, 0];
              this.first((OO => {
                var pO;
                return null === (pO = OO.onPlayerAttackEntity) || void 0 === pO ? void 0 : pO.call(OO, hO, AO, KO)
              }))
            }
            return 0
          }
          case FO.fc.ChangeBlock: {
            const OO = CO.nameOfId(bK),
              lO = CO.nameOfId(eO);
            return this.first((bK => {
              var eO;
              return null === (eO = bK.onPlayerChangeBlock) || void 0 === eO ? void 0 : eO.call(bK, hO, KO, pO, XO, OO, lO)
            })), 0
          }
          case FO.fc.DropItem: {
            const OO = CO.nameOfId(KO);
            return this.first((KO => {
              var bK;
              return null === (bK = KO.onPlayerDropItem) || void 0 === bK ? void 0 : bK.call(KO, hO, OO, pO, XO)
            })), 0
          }
          default:
            return this.onError(new Error(`Unknown game call kind ${OO}`)), 0
        }
      }
      changeBlockFail(OO, KO, pO, XO, bK, eO, lO) {
        const vK = bK === FO.Qc ? null : jb.decode(this.api.eventBytes(eO, Math.min(bK, lO)));
        this.failures.push({
          cKO: [OO, KO, pO],
          BOO: XO,
          ZOO: vK
        })
      }
      changeBlockFailEnd() {
        const OO = this.failures;
        this.failures = [], this.sessionLive && this.round(this.owners, (KO => {
          var pO;
          null === (pO = KO.onChangeBlockFail) || void 0 === pO || pO.call(KO, OO)
        })), this.pl("EditBoard", {
          pos: null
        }), this.pl("EditCodeBlock", {
          pos: null,
          canChangePos: null
        })
      }
      inventoryEvent(OO, KO, pO, XO, bK, eO) {
        OO === FO.wc.ChestOpened ? this.items.chestOpened(pO, XO, bK) : OO !== FO.wc.Synced && OO !== FO.wc.ChestClosed && OO !== FO.wc.ChestRefreshed || this.items.touch(), this.guard((() => {
          ! function(OO, KO, pO, XO) {
            switch (OO) {
              case FO.wc.Synced:
                lO.i.pl("syncedInvenFromServer");
                break;
              case FO.wc.ChestOpened:
              case FO.wc.ChestClosed:
                lO.i.pl("chestToggleFromServer", OO === FO.wc.ChestOpened, !0);
                break;
              case FO.wc.ChestRefreshed:
                lO.i.pl("chestRefreshedFromServer");
                break;
              case FO.wc.EnchantingTable:
                lO.i.pl("enchantingTable", {
                  yl: XO,
                  position: pO
                });
                break;
              case FO.wc.HotbarRequest:
                lO.i.pl("setSelectedInventorySlotI", KO, !0);
                break;
              case FO.wc.Scrolled:
                lO.i.pl("ScrollInventorySlot", KO);
                break;
              case FO.wc.NumberKey:
                lO.i.pl("numkeyPressed", KO + 1);
                break;
              case FO.wc.DropRequested:
                lO.i.pl("DropInvenItem", 0 !== KO);
                break;
              default:
                throw new oO.e(`InventoryEvent of no kind: what ${OO}`)
            }
          }(OO, KO, [pO, XO, bK], eO)
        }))
      }
      heldItemChanged() {
        this.items.touch()
      }
      shotDamage(OO, KO, pO, XO) {
        this.pl("shotPlayer", {
          playerId: String(OO),
          damage: KO,
          wasCrit: 0 !== XO,
          distance: pO
        })
      }
      localHurt(OO, KO) {
        this.pl("closeShopOnDamaged", null), this.guard((() => {
          lO.i.pl("damagedByOtherPlayer", {
            A7: null,
            direction: Number.isNaN(KO) ? null : KO,
            POO: OO
          })
        }))
      }
      attackHit(OO, KO, pO, XO, bK) {
        this.guard((() => {
          lO.i.pl("yourAttackHit", {
            qOO: XO,
            screenPos: this.renderFrame.projectDirectionToScreenPos([OO, KO, pO]),
            hitSelf: bK
          })
        }))
      }
      physicsType(OO) {
        this.pl("PlayerPhysicsTypeUpdate", OO)
      }
      vehicleEffect(OO, KO, pO, XO, bK) {
        this.guard((() => {
          OO === aK.sd.UPDATE ? (0, YO.k)(KO, {
            icon: pO,
            level: XO,
            displayName: null,
            durationMs: bK
          }) : jK.b.remove(KO)
        }))
      }
      zoomChanged(OO) {
        this.zoom = OO, this.zoomUnshown = !0
      }
      zoomDisabled() {
        this.pl("showBottomMessage", {
          message: "Zoom is disabled",
          timeoutLength: 2e3,
          type: "Error"
        })
      }
      showZoom() {
        const OO = this.scriptedCamera.holdsView();
        !this.zoomUnshown || OO && this.zoomHeld || (this.zoomUnshown = !1, this.pl("cameraZoomSet", this.zoom)), this.zoomHeld = OO
      }
      gunHit(OO) {
        this.guard((() => {
          const {
            A7: KO,
            N7: pO
          } = (0, QX.d)(zb.t, OO);
          lO.i.pl("damagedByOtherPlayer", {
            A7: KO,
            direction: pO
          })
        }))
      }
      uiEvent(OO, KO, pO, XO, bK, eO, lO, vK) {
        this.guard((() => {
          tX(OO, KO, [pO, XO, bK], eO, this.items, this.options.tables, (() => jb.decode(this.api.eventBytes(lO, vK))))
        }))
      }
      writeAltVeto(OO) {
        const KO = this.cmd;
        if (!KO) return;
        let pO;
        try {
          pO = function(OO, KO) {
            const pO = new Set;
            let XO = !1;
            for (const bK of OO)
              if (bK.onPlayerAttemptAltAction) {
                if (XO = !0, !bK.altVetoBlocks) return {
                  mode: FO.ee.All,
                  roots: []
                };
                for (const OO of bK.altVetoBlocks) pO.add(KO.getMetaInfo(OO).rootId)
              } return XO ? pO.size > FO.Gc ? {
              mode: FO.ee.All,
              roots: []
            } : {
              mode: FO.ee.Filter,
              roots: [...pO]
            } : {
              mode: FO.ee.Off,
              roots: []
            }
          }(OO, this.options.tables)
        } catch (bK) {
          this.onError(bK), pO = {
            mode: FO.ee.All,
            roots: []
          }
        }
        if (pO.mode === FO.ee.Off && !this.vetoSet) return;
        const XO = new Uint8Array(new Uint32Array(pO.roots).buffer);
        (0, FO.Cf)(KO, 0, pO.mode, pO.roots.length, XO) ? this.vetoSet = pO.mode !== FO.ee.Off: this.onError(new Error("SetAltVeto didn't fit the command ring"))
      }
      endGameGrants() {
        this.freeCam.clearGame(), this.writeFreeCam()
      }
      writeFreeCam() {
        this.stopped() || this.freeCam.write(this.cmd)
      }
      writeHooks(OO) {
        const KO = this.cmd;
        if (!KO) return;
        const pO = function(OO) {
          let KO = 0;
          for (const pO of OO) pO.onPlayerAltAction && (KO |= 1 << FO.fc.AltAction), (pO.onPlayerClick || pO.onPlayerClickUp || pO.onPlayerAttackEntity) && (KO |= 1 << FO.fc.Click), pO.onPlayerChangeBlock && (KO |= 1 << FO.fc.ChangeBlock), pO.onPlayerDropItem && (KO |= 1 << FO.fc.DropItem);
          return KO
        }(OO);
        (0 !== pO || this.hooksSet) && ((0, FO.Kf)(KO, 0, pO) ? this.hooksSet = 0 !== pO : this.onError(new Error("SetHooks didn't fit the command ring")))
      }
      writeCustomButtons() {
        const OO = this.cmd;
        OO && !this.stopped() && this.customButtons.write(OO)
      }
      writePromptWatch() {
        const OO = this.cmd,
          KO = this.promptWatch;
        KO !== this.promptWatchSent && OO && !this.stopped() && (0, FO.gg)(OO, 0, ib[KO]) && (this.promptWatchSent = KO)
      }
      writePublicLobby(OO) {
        const KO = this.cmd;
        KO && OO !== this.writtenPublicLobby && ((0, FO.Vf)(KO, 0, OO ? 1 : 0) ? this.writtenPublicLobby = OO : this.onError(new Error("SetPublicLobby didn't fit the command ring")))
      }
      writeLocalDbId(OO) {
        const KO = this.cmd;
        KO && ((0, FO.Mf)(KO, 0, null === OO ? 0 : 1, null === OO ? wX : YX.encode(OO)) || this.onError(new Error("SetLocalDbId didn't fit the command ring")))
      }
      first(OO) {
        const KO = this.generation;
        for (const XO of this.owners) {
          if (KO !== this.generation) break;
          try {
            const KO = OO(XO);
            if (void 0 !== KO) return KO
          } catch (pO) {
            this.CX(pO)
          }
        }
      }
      pl(OO, KO) {
        this.guard((() => {
          lO.i.pl(OO, KO)
        }))
      }
      dropGameCamera() {
        try {
          this.scriptedCamera.reset()
        } catch (OO) {
          this.CX(OO)
        }
      }
      restartGameCamera() {
        try {
          this.scriptedCamera.restart()
        } catch (OO) {
          this.CX(OO)
        }
      }
      endSession() {
        if (!this.sessionLive) return;
        this.sessionLive = !1;
        const OO = this.owners;
        let KO;
        if (this.owners = this.tickers = this.renderers = this.receivers = [], this.generation++, !this.stopped()) try {
          this.writeAltVeto([]), this.writeHooks([]), this.writePublicLobby(!1), this.writeLocalDbId(null)
        } catch (XO) {
          KO = XO
        }
        try {
          this.entityInfo.sessionEnded()
        } catch (XO) {
          KO ??= XO
        }
        this.round(OO, sX, !0);
        try {
          this.particles.sessionEnded() || this.onError(new Error("ParticleStopAll didn't fit the command ring"))
        } catch (XO) {
          KO ??= XO
        }
        try {
          this.clientApi.disposeGameOutput()
        } catch (XO) {
          KO ??= XO
        }
        const pO = this.options.onSessionEnd;
        if (pO) try {
          pO()
        } catch (XO) {
          this.onError(XO)
        }
        void 0 !== KO && this.CX(KO)
      }
      round(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = this.generation;
        for (const eO of OO) {
          if (XO !== this.generation) break;
          try {
            KO(eO)
          } catch (bK) {
            pO ? this.onError(bK) : this.CX(bK)
          }
        }
      }
      guard(OO) {
        try {
          OO()
        } catch (KO) {
          this.CX(KO)
        }
      }
    }

    function PX(OO) {
      return OO === FO.Tc ? null : String(OO)
    }

    function mb(OO) {
      OO.KK(aK.ld)
    }

    function sX(OO) {
      var KO;
      null === (KO = OO.onClose) || void 0 === KO || KO.call(OO)
    }

    function HX(OO, KO) {
      OO.watch((() => {
        const pO = function(OO) {
          let KO = 0;
          const pO = Math.min(bb, OO.length);
          for (let bK = 0; bK < pO; bK++) {
            var XO;
            const pO = null === (XO = OO.slot(bK)) || void 0 === XO ? void 0 : XO.typeObj,
              eO = pO ? (0, pX.gunTypeOf)(pO.id) : void 0;
            void 0 !== eO && (KO |= 1 << dK[eO])
          }
          return KO
        }(OO);
        0 !== pO && (KO.preload(pO), KO.preload(1 << TK))
      }))
    }
    var RX = pO(3988),
      SX = pO(35264);

    function JX(OO) {
      const KO = new RX.Howl({
          ...(0, SX.f)(OO),
          pool: 15,
          preload: !1
        }),
        pO = KO.load.bind(KO);
      return KO.load = () => (KO._preload = !0, pO()), KO
    }

    function cb(OO, KO, pO) {
      const XO = OO.listener;
      if (XO.positionX) BX(XO.positionX, KO, pO, 0), BX(XO.positionY, KO, pO, 1), BX(XO.positionZ, KO, pO, 2), BX(XO.forwardX, KO, pO, 3), BX(XO.forwardY, KO, pO, 4), BX(XO.forwardZ, KO, pO, 5), BX(XO.upX, KO, pO, 6), BX(XO.upY, KO, pO, 7), BX(XO.upZ, KO, pO, 8);
      else {
        let OO = !1;
        for (let XO = 0; XO < 9; XO++) OO ||= KO[XO] !== pO[XO];
        OO && (XO.setPosition(KO[0], KO[1], KO[2]), XO.setOrientation(KO[3], KO[4], KO[5], KO[6], KO[7], KO[8]), pO.set(KO))
      }
    }

    function BX(OO, KO, pO, XO) {
      KO[XO] !== pO[XO] && (OO.value = KO[XO], pO[XO] = KO[XO])
    }
    class ZX {
      constructor() {
        this.pose = new Float64Array(9), this.written = new Float64Array(9).fill(Number.NaN), this.watchedCtx = void 0
      }
      apply(OO) {
        this.pose.set(OO);
        const KO = RX.b.ctx;
        return !!KO && (KO !== this.watchedCtx && (this.watchedCtx = KO, this.written.fill(Number.NaN), KO.addEventListener("statechange", (() => {
          "running" === KO.state && cb(KO, this.pose, this.written)
        }))), "running" === KO.state && cb(KO, OO, this.written), !0)
      }
    }
    var GX = pO(35105),
      qb = pO(37562);
    let xb = null,
      nX = null;

    function WX() {
      return null === xb && (xb = document.createElement("div"), xb.style.cssText = "position:fixed;top:0;right:0;bottom:0;left:0;pointer-events:none", document.body.append(xb)), xb
    }

    function tb() {
      return nX ??= new qb.c(new GX.b(WX)), nX
    }

    function kb() {
      var OO;
      null === (OO = nX) || void 0 === OO || OO.clear(), UX(null)
    }

    function UX(OO) {
      XO.d.get("scriptedCameraFacing") !== OO && XO.d.set({
        scriptedCameraFacing: OO
      })
    }
    var Ob = pO(8461),
      Kb = pO(8411),
      pb = pO(37577),
      Xb = pO(38819),
      be = pO(2560);
    const eb = Object.entries(FO.bc).reduce(((OO, KO) => {
      let [pO, XO] = KO;
      return OO[XO] = pO, OO
    }), []);

    function lb(OO, KO) {
      var pO;
      return 0 !== ((null !== (pO = OO.itemFlags[KO]) && void 0 !== pO ? pO : 0) & FO.yc.Stackable)
    }
    const ve = /^(0|[1-9][0-9]*)$/,
      Cb = {
        displayName: (OO, KO) => (0, pX.displayNameOf)(KO),
        description: (OO, KO) => (0, pX.descriptionOf)(KO),
        type: (OO, KO) => (0, pX.itemTypeOf)(KO),
        clipSize: (OO, KO) => (0, pX.clipSizeOf)(KO),
        armourReduction: (OO, KO) => (0, pX.armourReductionOf)(KO),
        scopeType: (OO, KO) => (0, pX.scopeTypeOf)(KO),
        stackable: lb,
        harvestType: (OO, KO) => eb[OO.blockHarvestTypes[KO]],
        harvestLevel: (OO, KO) => {
          const pO = OO.blockHarvestLevels[KO];
          return pO === FO.Bc ? void 0 : pO
        },
        harvests: (OO, KO) => {
          var pO;
          const XO = null !== (pO = OO.itemHarvests[KO]) && void 0 !== pO ? pO : 0;
          return 0 !== XO ? eb[XO] : void 0 === (0, pX.harvestsNullLevelOf)(KO) ? void 0 : null
        },
        level: (OO, KO) => {
          var pO, XO;
          const bK = null !== (pO = OO.itemLevels[KO]) && void 0 !== pO ? pO : FO.Bc;
          return bK !== FO.Bc ? bK : null !== (XO = (0, pX.harvestsNullLevelOf)(KO)) && void 0 !== XO ? XO : void 0
        }
      };

    function hb(OO, KO, pO) {
      return Mb(new Uint8Array(Math.floor(OO.length / KO)), OO, KO, pO)
    }

    function Db(OO, KO, pO) {
      return Mb(new Uint16Array(Math.floor(OO.length / KO)), OO, KO, pO)
    }

    function Mb(OO, KO, pO, XO) {
      const bK = new DataView(KO.buffer, KO.byteOffset, KO.byteLength);
      for (let eO = 0; eO < OO.length; eO++) OO[eO] = XO(bK, eO * pO);
      return OO
    }
    class ae {
      constructor(OO, KO) {
        this.options = KO, this.metas = [], this.types = new Map, this.props = void 0, this.rootIdOf = OO => {
          const KO = this.idOf(OO);
          if (void 0 === KO) throw new Error(`No item is named ${OO}, an item's root`);
          return KO
        };
        const pO = KO => {
            const pO = KO();
            return new Uint8Array(OO.memory().buffer, OO.scratch(), pO).slice()
          },
          XO = (new TextDecoder).decode(pO((() => OO.queries.itemNames()))).split("\n"),
          bK = pO((() => OO.queries.blockProps())),
          eO = pO((() => OO.queries.itemProps()));
        this.props = {
          blockFlags: hb(bK, FO.x.BYTES, FO.x.flags),
          blockHarvestTypes: hb(bK, FO.x.BYTES, FO.x.harvestType),
          blockHarvestLevels: hb(bK, FO.x.BYTES, FO.x.harvestLevel),
          blockAttachedTops: Db(bK, FO.x.BYTES, FO.x.attachedTop),
          itemFlags: hb(eO, FO.zc.BYTES, FO.zc.flags),
          itemHarvests: hb(eO, FO.zc.BYTES, FO.zc.harvests),
          itemLevels: hb(eO, FO.zc.BYTES, FO.zc.level)
        }, (0, be.i)(Object.freeze(XO)), (0, Xb.f)()
      }
      idOf(OO) {
        if ("number" === typeof OO) return void 0 === (0, be.e)(OO) ? void 0 : OO;
        const KO = (0, be.c)(OO);
        return void 0 === KO && ve.test(OO) ? void 0 === (0, be.e)(+OO) ? void 0 : +OO : KO
      }
      getMetaInfo(OO) {
        if (!OO || OO === Ob.c) return Ob.e;
        const KO = this.idOf(OO);
        if (void 0 === KO) throw new Error(`Item ${OO} not found in registry`);
        return this.metaOf(KO)
      }
      blockRootId(OO) {
        return 0 !== OO && void 0 !== (0, be.e)(OO) ? this.metaOf(OO).rootId : OO
      }
      metaOf(OO) {
        return this.metas[OO] ??= (0, Kb.k)((0, be.e)(OO), OO, this.rootIdOf, (0, pX.rootMetaDescOf)(OO))
      }
      getItemId(OO) {
        if (!OO || OO === Ob.c) return 0;
        const KO = this.idOf(OO);
        if (void 0 === KO) throw new Error(`Invalid block name. You sent ${OO}. The only valid item names are 'Air' and those contained within the blockMetadata/itemMetadata files`);
        return KO
      }
      getItemName(OO) {
        if (!OO || OO === Ob.c) return Ob.c;
        const KO = this.idOf(OO);
        if (void 0 === KO) throw new Error(`Item ${OO} not found in registry`);
        return (0, be.e)(KO)
      }
      blockNameToBlockId(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (OO === Ob.c) return 0;
        let pO = this.idOf(OO);
        if (void 0 === pO || !this.isBlockId(pO)) {
          const KO = OO.indexOf("|"),
            XO = KO > 0 ? (0, be.c)(OO.slice(0, KO)) : void 0;
          pO = void 0 !== XO && this.isBlockId(XO) && (0, pX.rootMetaDescOf)(XO) === OO ? XO : void 0
        }
        if (void 0 !== pO) return pO;
        if (!KO) throw new Error(`Invalid block name. You sent ${OO}. The only valid block names are 'Air' and those contained within the blockMetadata.ts file`);
        return null
      }
      isBlockId(OO) {
        return OO > 0 && OO < this.props.blockFlags.length
      }
      nameOfId(OO) {
        return 0 !== OO && (0, be.e)(OO) || Ob.c
      }
      itemType(OO) {
        const KO = OO ? this.idOf(OO) : void 0;
        if (!KO) return null;
        let pO = this.types.get(KO);
        return void 0 === pO && (pO = Object.freeze({
          id: KO,
          name: (0, be.e)(KO),
          meta: this.getMetaInfo(KO),
          stackable: lb(this.props, KO),
          type: (0, pX.itemTypeNameOf)(KO),
          clipSize: (0, pX.clipSizeOf)(KO),
          scopeType: (0, pX.scopeTypeOf)(KO),
          showsAimingUi: (0, pX.showsAimingUi)(KO)
        }), this.types.set(KO, pO)), pO
      }
      getItemStat(OO, KO) {
        if (pb.c.has(KO)) {
          const pO = "minChargeStateToUse" === KO ? this.getMetaInfo(OO).rootName : this.getItemName(OO),
            XO = this.options.get((0, pb.d)(pO, KO));
          if (null !== XO && void 0 !== XO) return XO
        }
        return this.defaultStat(OO, KO, this.statOf(KO))
      }
      getDisplayName(OO) {
        return this.getItemStat(OO, "displayName")
      }
      getDefaultItemStat(OO, KO) {
        return this.defaultStat(OO, KO, this.statOf(KO))
      }
      statOf(OO) {
        const KO = Cb[OO];
        return void 0 === KO && function(OO, KO) {
          throw new Error(`ClientApi.${OO} is not available yet in the wasm client (${KO})`)
        }(`getItemStat("${OO}")`, `a table of the stat: the wasm client answers ${Object.keys(Cb).join(", ")}`), KO
      }
      defaultStat(OO, KO, pO) {
        const XO = this.idOf(OO),
          bK = void 0 === XO ? void 0 : pO(this.props, XO);
        return null !== bK && void 0 !== bK || "displayName" !== KO ? bK : this.getItemName(OO)
      }
      getClientOption(OO) {
        return this.options.get(OO)
      }
      getGunStats(OO) {
        return this.getClientOption(`${OO}GunStats`)
      }
      watchClientOption(OO, KO) {
        return this.options.subscribe(OO, KO)
      }
      isSolidBlockId(OO) {
        var KO;
        return 0 !== ((null !== (KO = this.props.blockFlags[OO]) && void 0 !== KO ? KO : 0) & FO.w.Solid)
      }
      isStackableId(OO) {
        return lb(this.props, OO)
      }
      isFluidBlockId(OO) {
        var KO;
        return 0 !== ((null !== (KO = this.props.blockFlags[OO]) && void 0 !== KO ? KO : 0) & FO.w.Fluid)
      }
      canPlaceOverBlockId(OO) {
        var KO;
        return 0 !== ((null !== (KO = this.props.blockFlags[OO]) && void 0 !== KO ? KO : 0) & FO.w.PlaceOver)
      }
      attachedTopOf(OO) {
        var KO;
        return null !== (KO = this.props.blockAttachedTops[OO]) && void 0 !== KO ? KO : 0
      }
      isDroplessBlockId(OO) {
        return (0, pX.dropsNothing)(OO)
      }
    }

    function ob(OO, KO) {
      const pO = new Map;
      return (XO, bK) => {
        const eO = KO.idOf(XO),
          lO = void 0 === eO ? null : (XO => {
            let bK = pO.get(XO);
            if (void 0 === bK) {
              const eO = OO.queries.salvageRecipe(XO),
                lO = new DataView(OO.memory().buffer, OO.scratch(), eO),
                vK = [];
              for (let OO = 0; OO + FO.Rd.BYTES <= eO; OO += FO.Rd.BYTES) vK.push(Object.freeze({
                item: KO.nameOfId(FO.Rd.item(lO, OO)),
                amt: FO.Rd.amount(lO, OO)
              }));
              bK = 0 === vK.length ? null : Object.freeze(vK), pO.set(XO, bK)
            }
            return bK
          })(eO);
        if (null === lO || void 0 === bK) return lO;
        const vK = bK <= 0 ? 1 : bK;
        return lO.map((OO => {
          let {
            item: KO,
            amt: pO
          } = OO;
          return {
            item: KO,
            amt: pO * vK
          }
        }))
      }
    }
    var Fb = pO(38976),
      Vb = pO(35427),
      Lb = pO(35414),
      Qb = pO(35454),
      ze = pO(35020),
      Ab = pO(38769),
      fb = pO(40618);
    const db = -1,
      Tb = new Uint8Array(0),
      Nb = new TextEncoder;

    function Ib(OO) {
      if (null === OO) return null;
      const KO = Nb.encode(OO);
      return KO.byteLength < aK.Ec ? KO : KO.subarray(0, aK.Ec - 1)
    }
    class ye {
      constructor(OO) {
        this.deps = OO, this.lastView = null, this.lastKeyframes = [], this.keyframesVersion = db, this.keyframesSettled = !1, this.reloadFrom = db
      }
      reloadKeyframes() {
        var OO, KO;
        this.keyframesVersion = db, this.reloadFrom = null !== (OO = null === (KO = this.view()) || void 0 === KO ? void 0 : KO.version) && void 0 !== OO ? OO : db
      }
      setPlayback(OO) {
        const KO = 1 === this.deps.core.FMO(OO);
        return KO && (this.lastView = null, this.lastKeyframes = [], this.keyframesVersion = db, this.reloadFrom = db), KO
      }
      async open(OO) {
        const KO = await this.deps.replay.open(OO);
        return "opening" === KO && (this.reloadKeyframes(), this.deps.recorder.prefetch()), KO
      }
      play() {
        this.deps.replay.play()
      }
      pause() {
        this.deps.replay.pause()
      }
      seek(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        this.deps.replay.seek(Math.max(0, Math.floor(OO)), KO)
      }
      setSpeed(OO) {
        this.deps.replay.setSpeed(OO)
      }
      setCameraMode(OO) {
        this.deps.replay.setCameraMode(fb.d.indexOf(OO))
      }
      view() {
        var OO;
        const KO = FO.t.replayViewPtr(this.deps.apiView(), 0);
        if (0 === KO) return this.lastView = null, null;
        const pO = new DataView(this.deps.buffer(), KO, FO.Jd.BYTES),
          XO = FO.Jd.version(pO, 0),
          bK = this.lastView;
        if (null !== bK && bK.version === XO) return bK;
        const eO = FO.Jd.markIn(pO, 0),
          lO = {
            version: XO,
            state: FO.Jd.state(pO, 0),
            cameraMode: null !== (OO = fb.d[FO.Jd.cameraMode(pO, 0)]) && void 0 !== OO ? OO : "recording",
            KK: FO.Jd.KK(pO, 0),
            totalTicks: FO.Jd.totalTicks(pO, 0),
            speed: FO.Jd.speed(pO, 0),
            mark: eO === FO.Hd ? null : {
              inTick: eO,
              outTick: FO.Jd.markOut(pO, 0)
            },
            editVersion: FO.Jd.editVersion(pO, 0)
          };
        return this.lastView = lO, lO
      }
      keyframes() {
        const OO = this.view();
        if (null === OO) return [];
        OO.version !== this.reloadFrom && (this.reloadFrom = db);
        const KO = this.reloadFrom === db && OO.state !== aK.cd.Cropping && OO.state !== aK.cd.None,
          pO = KO ? OO.editVersion : OO.version;
        if (pO === this.keyframesVersion && KO === this.keyframesSettled) return this.lastKeyframes;
        const {
          core: XO
        } = this.deps, bK = XO.VMO(), eO = XO.qv(), lO = [];
        if (0 !== eO && bK > 0) {
          const OO = new DataView(this.deps.buffer(), eO, bK * aK.kc);
          for (let KO = 0; KO < bK; KO++) {
            const pO = KO * aK.kc,
              XO = KO => OO.getFloat64(pO + KO, !0);
            lO.push({
              KK: OO.getUint32(pO + aK.Ac, !0),
              position: [XO(aK.wc), XO(aK.wc + 8), XO(aK.wc + 16)],
              direction: [XO(aK.oc), XO(aK.oc + 8), XO(aK.oc + 16)],
              easing: [XO(aK.sc), XO(aK.sc + 8), XO(aK.sc + 16), XO(aK.sc + 24)]
            })
          }
        }
        return this.keyframesVersion = pO, this.keyframesSettled = KO, this.lastKeyframes = lO, lO
      }
      addKeyframe() {
        const OO = this.deps.apiView(),
          KO = [FO.t.eye(OO, 0, 0), FO.t.eye(OO, 0, 1), FO.t.eye(OO, 0, 2)];
        return this.deps.replay.addKeyframe(KO, function(OO, KO) {
          const pO = Math.cos(KO);
          return [pO * Math.sin(OO), -Math.sin(KO), pO * Math.cos(OO)]
        }(FO.t.heading(OO, 0), FO.t.pitch(OO, 0)))
      }
      setKeyframe(OO) {
        return this.deps.replay.setKeyframe(OO.KK, Float64Array.from([...OO.position, ...OO.direction, ...OO.easing]))
      }
      moveKeyframe(OO, KO) {
        return this.deps.replay.moveKeyframe(OO, KO)
      }
      deleteKeyframes(OO, KO) {
        return this.deps.replay.deleteKeyframes(OO, KO)
      }
      setMark(OO) {
        var KO, pO;
        return this.deps.replay.setMark(null !== (KO = null === OO || void 0 === OO ? void 0 : OO.inTick) && void 0 !== KO ? KO : -1, null !== (pO = null === OO || void 0 === OO ? void 0 : OO.outTick) && void 0 !== pO ? pO : -1)
      }
      crop(OO, KO) {
        const pO = this.deps.replay.crop(OO, KO);
        return pO && this.reloadKeyframes(), pO
      }
      save(OO) {
        return this.deps.replay.askSave(), this.deps.recorder.saveEdited(OO)
      }
      recorderControl(OO) {
        this.deps.recorder.control(OO)
      }
      recorderPrefs(OO, KO) {
        this.deps.recorder.prefs(OO, KO)
      }
      recorderOption(OO, KO) {
        const pO = this.deps.cmd();
        return null !== pO && (0, FO.pf)(pO, 0, OO, null === KO ? Tb : Nb.encode(KO))
      }
      recordFlyingText(OO, KO, pO, XO) {
        const bK = this.deps.cmd(),
          eO = Math.max(0, Math.min(4294967295, Math.round(XO)));
        return null !== bK && (0, FO.lf)(bK, 0, KO, pO, eO, Nb.encode(OO))
      }
      recordPlayerKilled(OO, KO, pO, XO) {
        const bK = this.deps.cmd();
        return null !== bK && (0, FO.tf)(bK, 0, OO, KO, Math.max(0, pO), Nb.encode(XO))
      }
      recordKillfeed(OO, KO, pO) {
        var XO, bK;
        const eO = this.deps.cmd(),
          lO = function(OO) {
            const KO = OO.reduce(((OO, KO) => {
                var pO;
                return OO + qX.Y + (null !== (pO = null === KO || void 0 === KO ? void 0 : KO.byteLength) && void 0 !== pO ? pO : 0)
              }), 0),
              pO = new Uint8Array(KO),
              XO = new DataView(pO.buffer);
            let bK = 0;
            for (const lO of OO) {
              var eO;
              XO.setUint16(bK, null !== (eO = null === lO || void 0 === lO ? void 0 : lO.byteLength) && void 0 !== eO ? eO : aK.Ec, !0), bK += qX.Y, null !== lO && (pO.set(lO, bK), bK += lO.byteLength)
            }
            return pO
          }([Ib(OO.name), Ib(OO.colour), Ib(KO.name), Ib(KO.colour), Ib(pO)]);
        return null !== eO && (0, FO.nf)(eO, 0, null !== (XO = OO.id) && void 0 !== XO ? XO : FO.Vc, null !== (bK = KO.id) && void 0 !== bK ? bK : FO.Vc, lO)
      }
      recorderSession(OO, KO) {
        this.deps.recorder.session({
          session: KO,
          lobbyType: OO.lobbyType,
          game: OO.gameNameWithVariation,
          lobby: OO.lobbyName
        })
      }
      recorderClose() {
        this.deps.core.LMO()
      }
      filePartDone(OO, KO) {
        this.deps.recorder.filePartDone(OO, KO)
      }
      fileDone(OO) {
        this.deps.recorder.fileDone(OO)
      }
    }
    const ge = -2147483648;
    class ub {
      constructor(OO) {
        var KO;
        this.deps = OO, this.state = {
          recording: !1,
          clipping: !1,
          hasClipBuffer: !1,
          seconds: 0
        }, this.recordingSince = null, this.clipTickPending = !1, this.now = void 0, this.now = null !== (KO = OO.now) && void 0 !== KO ? KO : () => performance.now()
      }
      get current() {
        return this.state
      }
      get live() {
        var OO, KO, pO;
        return null === (OO = null === (KO = (pO = this.deps).live) || void 0 === KO ? void 0 : KO.call(pO)) || void 0 === OO || OO
      }
      activated(OO) {
        var KO, pO;
        this.live && (this.viewerShown(!0 === (null === (KO = (pO = this.deps).viewerOpen) || void 0 === KO ? void 0 : KO.call(pO))), this.deps.client.recorderSession(OO, (0, fb.g)()))
      }
      closed() {
        this.deps.client.recorderClose()
      }
      toggleRecording() {
        var OO, KO;
        this.live && (this.state.recording || !0 !== (null === (OO = (KO = this.deps).viewerOpen) || void 0 === OO ? void 0 : OO.call(KO))) ? this.deps.client.recorderControl(aK.Lc.ToggleRecording) : this.deps.notify(Qb.b.closeViewerFirst)
      }
      saveClip() {
        this.live ? this.deps.client.recorderControl(aK.Lc.SaveClip) : this.deps.notify(Qb.b.clippingNotOn)
      }
      viewerShown(OO) {
        this.live && this.deps.client.recorderControl(OO ? aK.Lc.ViewerOpened : aK.Lc.ViewerClosed)
      }
      setPrefs(OO, KO) {
        this.live && this.deps.client.recorderPrefs(OO, KO)
      }
      setOption(OO, KO) {
        this.live && this.deps.client.recorderOption(OO, KO)
      }
      recordFlyingText(OO, KO, pO, XO) {
        this.live && this.deps.client.recordFlyingText(OO, KO, pO, XO)
      }
      recordPlayerKilled(OO, KO, pO, XO) {
        this.live && this.deps.client.recordPlayerKilled(OO, KO, pO, XO)
      }
      recordKillfeed(OO, KO, pO) {
        this.live && this.deps.client.recordKillfeed(OO, KO, pO)
      }
      KK() {
        let OO = this.state;
        if (this.clipTickPending && (this.clipTickPending = !1, OO = {
            ...OO,
            hasClipBuffer: !0
          }), null !== this.recordingSince) {
          const KO = Math.floor((this.now() - this.recordingSince) / 1e3);
          KO !== OO.seconds && (OO = {
            ...OO,
            seconds: KO
          })
        }
        this.set(OO)
      }
      onEvent(OO) {
        var KO, pO;
        const {
          notify: XO
        } = this.deps, bK = Qb.b;
        switch (OO.what) {
          case aK.Kc.RecordingStarted:
            this.recordingSince = this.now(), this.set({
              ...this.state,
              recording: !0,
              seconds: 0
            }), XO(bK.recordingStarted);
            break;
          case aK.Kc.RecordingStopped:
            this.stopRecording(), XO(bK.recordingStopped), this.saveState(aK.Wc.Recording, "saving");
            break;
          case aK.Kc.RecordingDiscarded:
            this.stopRecording(), XO(bK.recordingDiscarded);
            break;
          case aK.Kc.RecordingTurnedOff:
            this.stopRecording(), XO(bK.recordingTurnedOff);
            break;
          case aK.Kc.LimitReached:
            XO(bK.limitReached);
            break;
          case aK.Kc.ClipSaved:
            this.saveState(aK.Wc.Clip, "saving");
            break;
          case aK.Kc.ClipEmpty:
            XO(bK.clipEmpty);
            break;
          case aK.Kc.ClippingNotOn:
            XO(bK.clippingNotOn);
            break;
          case aK.Kc.Disallowed:
            XO(bK.disallowed);
            break;
          case aK.Kc.ClippingOn:
            this.clipTickPending = !0, this.set({
              ...this.state,
              clipping: !0,
              hasClipBuffer: !1
            });
            break;
          case aK.Kc.ClippingOff:
            this.clipTickPending = !1, this.set({
              ...this.state,
              clipping: !1,
              hasClipBuffer: !1
            });
            break;
          case aK.Kc.ClipSettingsChanged:
            this.clipTickPending = this.state.clipping, this.set({
              ...this.state,
              hasClipBuffer: !1
            });
            break;
          case aK.Kc.SaveBusy:
            null === (KO = (pO = this.deps).onSaveState) || void 0 === KO || KO.call(pO, OO.kind, "busy"), XO(bK.saveBusy);
            break;
          case aK.Kc.CloseViewerFirst:
            XO(bK.closeViewerFirst)
        }
      }
      fileReady(OO, KO) {
        this.deps.download(KO), this.saveState(OO, "done"), this.deps.notify(OO === aK.Wc.Clip ? Qb.b.clipSaved : Qb.b.recordingSaved)
      }
      failed(OO) {
        this.saveState(OO, "failed"), this.deps.notify(OO === aK.Wc.Clip ? Qb.b.clipFailed : Qb.b.recordingFailed)
      }
      stopRecording() {
        this.recordingSince = null, this.set({
          ...this.state,
          recording: !1,
          seconds: 0
        })
      }
      saveState(OO, KO) {
        var pO, XO;
        null === (pO = (XO = this.deps).onSaveState) || void 0 === pO || pO.call(XO, OO, KO)
      }
      set(OO) {
        OO !== this.state && (this.state = OO, this.deps.onState(OO))
      }
    }
    const Eb = new TextDecoder;

    function je(OO, KO, pO, XO) {
      const bK = [];
      for (let eO = 0; eO < XO; eO++) {
        if (KO + qX.Y > pO) return null;
        const XO = OO.getUint16(KO, !0);
        if (KO += qX.Y, XO !== aK.Ec) {
          if (KO + XO > pO) return null;
          bK.push(Eb.decode(new Uint8Array(OO.buffer, OO.byteOffset + KO, XO))), KO += XO
        } else bK.push(null)
      }
      return KO === pO ? bK : null
    }

    function Yb(OO, KO) {
      let pO = new DataView(new ArrayBuffer(0)),
        XO = !0;
      const bK = {
        replayFailed: (KO, pO) => {
          OO.replayFailed({
            reason: KO,
            code: pO
          })
        },
        replayOption: (KO, bK, eO, lO) => {
          const vK = function(OO, KO, pO, XO) {
            switch (KO) {
              case aK.Xc.Cleared:
                return 0 === XO ? null : void 0;
              case aK.Xc.Text:
                return Eb.decode(new Uint8Array(OO.buffer, OO.byteOffset + pO, XO));
              case aK.Xc.Int:
                return XO === Int32Array.BYTES_PER_ELEMENT ? OO.getInt32(pO, !0) : void 0;
              case aK.Xc.Double:
                return XO === Float64Array.BYTES_PER_ELEMENT ? OO.getFloat64(pO, !0) : void 0;
              default:
                return
            }
          }(pO, bK, eO, lO);
          void 0 !== vK ? OO.replayOption({
            key: KO,
            value: vK
          }) : XO = !1
        },
        replayUiEvent: (KO, bK, eO, lO, vK, CO) => {
          const hO = function(OO, KO, pO, XO, bK, eO, lO) {
            const vK = eO + lO;
            switch (KO) {
              case aK.$c.FlyingText: {
                const lO = je(OO, eO, vK, 1);
                return null !== lO && null !== lO[0] ? {
                  what: KO,
                  SOO: pO,
                  ROO: XO,
                  angle: bK,
                  contentJson: lO[0]
                } : null
              }
              case aK.$c.PlayerKilled: {
                const XO = je(OO, eO, vK, 3);
                return XO ? {
                  what: KO,
                  killstreak: pO,
                  dead: XO[0],
                  killer: XO[1],
                  withItem: XO[2]
                } : null
              }
              case aK.$c.Killfeed: {
                const pO = je(OO, eO, vK, 7);
                return pO ? {
                  what: KO,
                  killerId: pO[0],
                  killerName: pO[1],
                  killerColour: pO[2],
                  victimId: pO[3],
                  victimName: pO[4],
                  victimColour: pO[5],
                  withItem: pO[6]
                } : null
              }
              default:
                return null
            }
          }(pO, KO, bK, eO, lO, vK, CO);
          null !== hO ? OO.replayUiEvent(hO) : XO = !1
        },
        replayFilePart: (pO, bK, eO, lO) => {
          const vK = KO();
          eO + lO > vK.byteLength ? XO = !1 : OO.filePart(pO, bK, new Uint8Array(vK, eO, lO).slice())
        },
        replayFileReady: (KO, pO, XO, bK) => {
          OO.fileReady({
            save: KO,
            kind: pO,
            parts: XO,
            bytes: bK
          })
        },
        recorderEvent: (KO, pO, XO) => {
          OO.recorderEvent({
            what: KO,
            kind: pO,
            save: XO
          })
        },
        replayOpened: (KO, XO, bK) => {
          OO.replayOpened(Eb.decode(new Uint8Array(pO.buffer, pO.byteOffset + XO, bK)))
        }
      };
      return (OO, KO, eO, lO) => !(OO < aK.V.ReplayFailed || OO > aK.V.RecorderEvent) && (pO = KO, XO = !0, (0, FO.ke)(OO, KO, eO, lO, bK) && XO)
    }

    function wb(OO) {
      let KO = null;
      const pO = Yb(OO, (() => {
        if (null === KO) throw new Error("a recorder event read outside recorderEventReader's call");
        return KO.buffer
      }));
      return (OO, XO) => {
        KO = XO;
        try {
          ! function(OO, KO) {
            const pO = OO.slice(),
              XO = new DataView(pO.buffer);
            for (let bK = 0; bK < pO.byteLength;) {
              if (bK + aK.R > pO.byteLength) throw new Error(`the recorder module's events end mid-head at ${bK}`);
              const OO = XO.getUint32(bK, !0),
                eO = 65535 & OO,
                lO = OO >>> 16,
                vK = bK + aK.R;
              if (vK + lO > pO.byteLength || !KO(eO, XO, vK, lO)) throw new Error(`the recorder module wrote a malformed event ${eO} (${lO} bytes) at ${bK}`);
              bK = vK + (0, aK.ne)(lO)
            }
          }(OO, pO)
        } finally {
          KO = null
        }
      }
    }
    class ie {
      constructor(OO, KO) {
        this.acks = OO, this.handlers = KO, this.parts = new Map
      }
      onPart(OO, KO, pO) {
        let XO = this.parts.get(OO);
        XO || (XO = [], this.parts.set(OO, XO)), XO[KO] = pO, this.acks.filePartDone(OO, KO)
      }
      onReady(OO) {
        var KO;
        const pO = null !== (KO = this.parts.get(OO.save)) && void 0 !== KO ? KO : [];
        this.parts.delete(OO.save);
        const XO = function(OO, KO, pO) {
          if (OO.length !== KO) return null;
          let XO = 0;
          for (let lO = 0; lO < KO; lO++) {
            if (void 0 === OO[lO]) return null;
            XO += OO[lO].byteLength
          }
          if (XO !== pO) return null;
          if (1 === KO) return OO[0];
          const bK = new Uint8Array(pO);
          let eO = 0;
          for (const lO of OO) bK.set(lO, eO), eO += lO.byteLength;
          return bK
        }(pO, OO.parts, OO.bytes);
        this.acks.fileDone(OO.save), null === XO ? this.handlers.fileIncomplete(OO.save, OO.kind) : this.handlers.fileReady(OO.save, OO.kind, XO)
      }
      onDiscarded(OO) {
        this.parts.delete(OO)
      }
    }

    function re() {
      return pO.e(52).then((() => pO(40653)))
    }
    class Pb {
      constructor(OO) {
        this.deps = OO, this.sink = void 0, this.recorder = void 0, this.recorderEvents = void 0, this.parts = void 0, this.viewerChunk = null, this.viewer = null;
        const {
          client: KO
        } = OO;
        this.recorder = new ub({
          client: KO,
          live: () => {
            var OO;
            return !0 !== (null === (OO = this.viewer) || void 0 === OO ? void 0 : OO.inPlayback)
          },
          viewerOpen: OO.viewerOpen,
          notify: OO.notify,
          download: KO => {
            var pO;
            null === (pO = OO.download) || void 0 === pO || pO.call(OO, KO)
          },
          onState: OO.onRecorderState,
          onSaveState: OO.onSaveState
        }), this.parts = new ie(KO, {
          fileReady: (OO, KO, pO) => {
            var XO;
            KO === aK.Wc.Edited ? null === (XO = this.viewer) || void 0 === XO || XO.saveDone(pO) : this.recorder.fileReady(KO, pO)
          },
          fileIncomplete: (OO, KO) => {
            this.saveFailed(KO)
          }
        });
        const pO = {
          replayFailed: OO => {
            var KO;
            null === (KO = this.viewer) || void 0 === KO || KO.onFailed(OO)
          },
          replayOption: KO => {
            var pO;
            null === (pO = OO.onReplayOption) || void 0 === pO || pO.call(OO, KO)
          },
          replayUiEvent: KO => {
            var pO;
            null === (pO = OO.onReplayUiEvent) || void 0 === pO || pO.call(OO, KO)
          },
          filePart: (OO, KO, pO) => {
            this.parts.onPart(OO, KO, pO)
          },
          fileReady: OO => {
            this.parts.onReady(OO)
          },
          replayOpened: KO => {
            var pO;
            null === (pO = OO.onReplayOpened) || void 0 === pO || pO.call(OO, KO)
          },
          recorderEvent: OO => {
            var KO;
            switch (OO.what) {
              case aK.Kc.FileDiscarded:
                this.parts.onDiscarded(OO.save);
                break;
              case aK.Kc.SaveFailed:
                this.saveFailed(OO.kind);
                break;
              case aK.Kc.SaveBusy:
                if (null !== (KO = this.viewer) && void 0 !== KO && KO.savePending) {
                  this.viewer.saveFailed(!0);
                  break
                }
                this.recorder.onEvent(OO);
                break;
              default:
                this.recorder.onEvent(OO)
            }
          }
        };
        this.sink = function(OO, KO) {
          return {
            onReplayEvent: Yb(OO, KO)
          }
        }(pO, OO.buffer), this.recorderEvents = wb(pO)
      }
      get currentViewer() {
        return this.viewer
      }
      loadViewer() {
        var OO;
        return this.viewer ? Promise.resolve(this.viewer) : (this.viewerChunk ??= (null !== (OO = this.deps.loadViewer) && void 0 !== OO ? OO : re)().catch((OO => {
          throw this.viewerChunk = null, OO
        })), this.viewerChunk.then((OO => (this.viewer ??= new OO.ReplayViewer({
          client: this.deps.client,
          setHoldDraws: this.deps.setHoldDraws,
          meshPending: this.deps.meshPending,
          notify: this.deps.notify,
          onChange: () => {
            var OO, KO;
            null === (OO = (KO = this.deps).onViewerChange) || void 0 === OO || OO.call(KO)
          }
        }), this.viewer))))
      }
      activated(OO) {
        this.recorder.activated(OO)
      }
      afterFrame(OO) {
        try {
          OO > 0 && this.recorder.KK()
        } finally {
          var KO;
          null === (KO = this.viewer) || void 0 === KO || KO.afterFrame()
        }
      }
      end() {
        var OO;
        null === (OO = this.viewer) || void 0 === OO || OO.end()
      }
      saveFailed(OO) {
        var KO;
        OO === aK.Wc.Edited ? null === (KO = this.viewer) || void 0 === KO || KO.saveFailed(!1) : this.recorder.failed(OO)
      }
    }
    var me = pO(38709),
      sb = pO(38723),
      Hb = pO(3952),
      Rb = pO(39064);
    class Sb {
      constructor(OO) {
        this.deps = OO, this.analogue = [0, 0], this.keys = 0, this.unsent = !1
      }
      drag(OO, KO) {
        if (!this.deps.live() || 0 === OO && 0 === KO) return;
        const pO = (0, sO.o)(0, performance.now()),
          XO = this.deps.dragScale();
        (0, Rb.j)((() => {
          (0, sO.s)(aK.zb.MouseDown, 0, 0, 0, pO), (0, sO.s)(aK.zb.MouseMove, 0, OO * XO, KO * XO, 0), (0, sO.s)(aK.zb.MouseUp, 0, 0, 0, pO)
        }))
      }
      move(OO) {
        var KO, pO;
        this.analogue[0] = null !== (KO = null === OO || void 0 === OO ? void 0 : OO.x) && void 0 !== KO ? KO : 0, this.analogue[1] = null !== (pO = null === OO || void 0 === OO ? void 0 : OO.y) && void 0 !== pO ? pO : 0, this.send()
      }
      holdVertical(OO, KO) {
        const pO = "freeCamUp" === OO ? FO.Tb.Up : FO.Tb.Down;
        this.keys = KO ? this.keys | pO : this.keys & ~pO, this.send()
      }
      flush() {
        this.unsent && this.send()
      }
      send() {
        const OO = this.deps.live() ? this.deps.cmd() : null;
        this.unsent = null !== OO && !(0, FO.Ce)(OO, 0, this.analogue, this.keys)
      }
    }
    var Jb = pO(35122),
      ce = pO(588),
      Bb = pO(129),
      Zb = pO(94),
      Gb = pO(8290);

    function qe() {
      const OO = XO.d.get("clientEscMenuOptions"),
        KO = (0, ce.l)(OO);
      return {
        mouse: (0, Zb.isMobile)() ? KO : OO.mouseSensitivity,
        touch: KO,
        fovPercent: OO.cameraFOV
      }
    }

    function xe() {
      const OO = XO.d.get("clientEscMenuOptions"),
        KO = XO.d.get("isTouchScreen") ? (0, ce.l)(OO) : OO.mouseSensitivity,
        pO = qe().mouse;
      return pO > 0 ? KO / pO : 1
    }

    function nb(OO) {
      const KO = () => {
        OO.setSoundPrefs(XO.d.get("soundVolume"), XO.d.get("soundOnFromAd"))
      };
      let pO = null;
      const bK = () => {
        const {
          showFog: KO,
          enableLighting: bK,
          fogChunkDistance: eO,
          chunkFadeIn: lO
        } = XO.d.get("clientEscMenuOptions"), vK = {
          showFog: KO,
          lighting: bK,
          fogChunks: eO,
          chunkFade: lO
        };
        pO && (0, aK._d)(pO) === (0, aK._d)(vK) && pO.fogChunks === eO || (pO = vK, OO.setEnvPrefs(pO))
      };
      let eO = null;
      const vK = () => {
        const KO = function() {
          const OO = XO.d.get("clientEscMenuOptions");
          return {
            nametagsHidden: XO.d.get("areNametagsHidden"),
            crouchToggle: OO.crouchIsToggle,
            bhopDisabled: OO.disableBunnyHopping,
            disableBobbing: OO.disableBobbing,
            ezTowering: OO.ezTowering && (0, Bb.d)(),
            ezBridging: OO.ezBridging,
            showChunkBorders: OO.showChunkBorders,
            edgeGuard: (0, Jb.f)(OO),
            nametagCutDistance: (0, Gb.g)()
          }
        }();
        (0, gK.Sd)(eO, KO) || (eO = KO, OO.setUiPrefs(KO))
      };
      let CO = null;
      const hO = () => {
        const KO = qe();
        (0, gK.Sd)(CO, KO) || (CO = KO, OO.setLookPrefs(KO))
      };
      KO(), bK(), vK(), hO();
      const DO = [(0, lO.j)("appManagerUpdated|soundVolume", KO), (0, lO.j)("appManagerUpdated|soundOnFromAd", KO), (0, lO.j)("appManagerUpdated|clientEscMenuOptions", (() => {
        bK(), vK(), hO()
      })), (0, lO.j)("appManagerUpdated|areNametagsHidden", vK), (0, lO.j)("appManagerUpdated|showDistantNametags", vK)];
      return () => {
        for (const OO of DO) OO()
      }
    }
    var Wb = pO(38987),
      te = pO(38995);
    var ke = (0, te.b)("lend"),
      Ub = (0, te.b)("starting"),
      Oe = (0, te.b)("generation"),
      Ke = (0, te.b)("end");
    class pe {
      constructor(OO) {
        this.deps = OO, Object.defineProperty(this, Ke, {
          value: Xe
        }), Object.defineProperty(this, ke, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, Ub, {
          writable: !0,
          value: !1
        }), Object.defineProperty(this, Oe, {
          writable: !0,
          value: 0
        })
      }
      get active() {
        return null !== (0, Wb.c)(this, ke)[ke] || (0, Wb.c)(this, Ub)[Ub]
      }
      async start(OO) {
        if (this.active) return "busy";
        const KO = (0, Wb.c)(this, Oe)[Oe];
        (0, Wb.c)(this, Ub)[Ub] = !0;
        try {
          if (!await this.deps.ensureLoaded()) return "refused"
        } finally {
          (0, Wb.c)(this, Ub)[Ub] = !1
        }
        if (KO !== (0, Wb.c)(this, Oe)[Oe]) return "refused";
        const pO = this.deps.beginSave();
        if (!pO) return "refused";
        const XO = Number(BigInt.asUintN(32, OO)),
          bK = Number(BigInt.asUintN(32, OO >> 32n));
        let eO = "refused";
        return this.deps.recorderCall(((OO, KO) => {
          const lO = pO.editState,
            vK = OO.stage(lO.length);
          0 !== vK ? (new Uint8Array(KO.buffer, vK, lO.length).set(lO), OO.QMO(pO.headLen, XO, bK) && (eO = "sealing")) : eO = "tooLarge"
        }), !0), "sealing" !== eO ? (pO.end(), eO) : ((0, Wb.c)(this, ke)[ke] = pO, "sealing")
      }
      beforeRecorderStep() {
        const OO = (0, Wb.c)(this, ke)[ke];
        if (!OO) return null;
        let KO = -1,
          pO = 0;
        if (!this.deps.recorderCall((OO => {
            KO = OO.zaO(), KO > 0 && (pO = OO.AMO())
          }))) return (0, Wb.c)(this, Ke)[Ke](OO, "stopped");
        if (KO < 0) return (0, Wb.c)(this, Ke)[Ke](OO, "read");
        if (0 === KO) return null;
        const XO = OO.head(pO, KO);
        let bK = !1;
        if (XO && this.deps.recorderCall(((OO, pO) => {
            const eO = OO.stage(KO);
            0 !== eO && (new Uint8Array(pO.buffer, eO, KO).set(XO), bK = !0)
          }), !0), bK) return null;
        const eO = OO.givenUp();
        this.deps.recorderCall((OO => {
          OO.fMO()
        }));
        const lO = (0, Wb.c)(this, Ke)[Ke](OO, eO ? "givenUp" : "stopped");
        return eO && this.deps.givenUp("Reopen the replay you were editing to make your edits again, as they weren't saved when another replay opened."), lO
      }
      stop() {
        (0, Wb.c)(this, Oe)[Oe]++;
        const OO = (0, Wb.c)(this, ke)[ke];
        OO && (this.deps.recorderCall((OO => {
          OO.fMO()
        })), (0, Wb.c)(this, Ke)[Ke](OO, "stopped"))
      }
    }

    function Xe(OO, KO) {
      return (0, Wb.c)(this, ke)[ke] = null, OO.end(), KO
    }

    function bl(OO, KO) {
      const pO = new Uint8Array(4),
        XO = new DataView(pO.buffer);
      return XO.setUint8(0, OO ? 1 : 0), XO.setUint16(2, Math.max(0, Math.min(65535, Math.round(KO))), !0), pO
    }

    function ee(OO, KO) {
      return OO > function(OO) {
        return 16777216 + 314572.8 * Math.max(0, OO)
      }(KO) + 33554432
    }
    let le = null;

    function vl(OO) {
      return le ??= async function(OO) {
        const KO = OO.loadInFlight();
        KO && await KO.catch((() => {}));
        if (OO.trapped()) return "trapped";
        if (OO.busy() || !ee(OO.memoryBytes(), OO.clipSeconds())) return "Sp";
        OO.unload();
        let pO = !1;
        try {
          pO = await OO.load()
        } catch {
          pO = !1
        }
        if (!pO) return OO.trapped() ? "trapped" : OO.YX() ? "YX" : "failed";
        return "recycled"
      }(OO).finally((() => {
        le = null
      })), le
    }
    const Ce = "Replay recording couldn't load, so try again.",
      he = new Set([aK.Lc.ToggleRecording, aK.Lc.SaveClip]);
    var De = (0, te.b)("MX"),
      Me = (0, te.b)("module"),
      al = (0, te.b)("memory"),
      oe = (0, te.b)("trapped"),
      Fe = (0, te.b)("YX"),
      Ve = (0, te.b)("recycleDue"),
      Le = (0, te.b)("loading"),
      Qe = (0, te.b)("generation"),
      zl = (0, te.b)("viewDrawn"),
      Ae = (0, te.b)("clip"),
      fe = (0, te.b)("session"),
      de = (0, te.b)("control"),
      Te = (0, te.b)("deferred"),
      Ne = (0, te.b)("coreU8"),
      Ie = (0, te.b)("coreU32"),
      yl = (0, te.b)("moduleU8"),
      gl = (0, te.b)("edited"),
      ue = (0, te.b)("sendSession"),
      Ee = (0, te.b)("checkNotInEvents"),
      jl = (0, te.b)("clipping"),
      Ye = (0, te.b)("busy"),
      we = (0, te.b)("use"),
      il = (0, te.b)("ensureLoaded"),
      rl = (0, te.b)("loadOnce"),
      Pe = (0, te.b)("recycleAfterStep"),
      ml = (0, te.b)("settleRecycle"),
      se = (0, te.b)("load"),
      He = (0, te.b)("attach"),
      Re = (0, te.b)("resendHeld"),
      Se = (0, te.b)("recycle"),
      Je = (0, te.b)("send"),
      cl = (0, te.b)("unload"),
      Be = (0, te.b)("dropModule"),
      Ze = (0, te.b)("coreBytes"),
      Ge = (0, te.b)("coreWords"),
      ql = (0, te.b)("moduleBytes"),
      xl = (0, te.b)("loadFailed"),
      ne = (0, te.b)("call"),
      We = (0, te.b)("guard"),
      tl = (0, te.b)("trapOn");
    class kl {
      constructor(OO) {
        this.deps = OO, Object.defineProperty(this, tl, {
          value: dl
        }), Object.defineProperty(this, We, {
          value: fl
        }), Object.defineProperty(this, ne, {
          value: Al
        }), Object.defineProperty(this, xl, {
          value: zv
        }), Object.defineProperty(this, ql, {
          value: Ql
        }), Object.defineProperty(this, Ge, {
          value: Ll
        }), Object.defineProperty(this, Ze, {
          value: Vl
        }), Object.defineProperty(this, Be, {
          value: Fl
        }), Object.defineProperty(this, cl, {
          value: ol
        }), Object.defineProperty(this, Je, {
          value: av
        }), Object.defineProperty(this, Se, {
          value: Ml
        }), Object.defineProperty(this, Re, {
          value: Dl
        }), Object.defineProperty(this, He, {
          value: hl
        }), Object.defineProperty(this, se, {
          value: Cl
        }), Object.defineProperty(this, ml, {
          value: vv
        }), Object.defineProperty(this, Pe, {
          value: ll
        }), Object.defineProperty(this, rl, {
          value: el
        }), Object.defineProperty(this, il, {
          value: bv
        }), Object.defineProperty(this, we, {
          value: Xl
        }), Object.defineProperty(this, Ye, {
          value: pl
        }), Object.defineProperty(this, jl, {
          value: Kl
        }), Object.defineProperty(this, Ee, {
          value: Ol
        }), Object.defineProperty(this, ue, {
          value: Ue
        }), Object.defineProperty(this, De, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, Me, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, al, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, oe, {
          writable: !0,
          value: !1
        }), Object.defineProperty(this, Fe, {
          writable: !0,
          value: !1
        }), Object.defineProperty(this, Ve, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, Le, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, Qe, {
          writable: !0,
          value: 0
        }), Object.defineProperty(this, zl, {
          writable: !0,
          value: !1
        }), Object.defineProperty(this, Ae, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, fe, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, de, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, Te, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, Ne, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, Ie, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, yl, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, gl, {
          writable: !0,
          value: void 0
        }), (0, Wb.c)(this, gl)[gl] = new pe({
          ensureLoaded: () => (0, Wb.c)(this, il)[il](),
          recorderCall: (OO, KO) => {
            KO && (0, Wb.c)(this, Ee)[Ee]("an edited save's stage");
            const pO = (0, Wb.c)(this, ne)[ne](((KO, pO) => (OO(KO, pO), !0)));
            return null !== pO && void 0 !== pO && pO
          },
          beginSave: OO.beginSave,
          givenUp: OO.givenUp
        })
      }
      get active() {
        return null !== (0, Wb.c)(this, Me)[Me]
      }
      get trapped() {
        return (0, Wb.c)(this, oe)[oe]
      }
      get loading() {
        return null !== (0, Wb.c)(this, Le)[Le]
      }
      prefetch() {
        (0, Wb.c)(this, Fe)[Fe] || (0, Wb.c)(this, oe)[oe] || (0, Wb.c)(this, Me)[Me] || (0, Wb.c)(this, Le)[Le] || this.deps.prefetch()
      }
      viewDrawn() {
        (0, Wb.c)(this, zl)[zl] = !0, (0, Wb.c)(this, jl)[jl]() && (0, Wb.c)(this, we)[we]()
      }
      prefs(OO, KO) {
        (0, Wb.c)(this, Ae)[Ae] = {
          on: OO,
          seconds: KO
        }, (0, Wb.c)(this, Je)[Je](aK.Jc.Prefs, bl(OO, KO)), OO && (0, Wb.c)(this, zl)[zl] && (0, Wb.c)(this, we)[we]()
      }
      control(OO) {
        const KO = function(OO) {
          return new Uint8Array([OO, 0, 0, 0])
        }(OO);
        if (he.has(OO)) return (0, Wb.c)(this, Me)[Me] ? void(0, Wb.c)(this, Je)[Je](aK.Jc.Control, KO) : ((0, Wb.c)(this, de)[de] = KO, void(0, Wb.c)(this, we)[we]());
        (0, Wb.c)(this, Fe)[Fe] || this.deps.coreCommand(aK.Jc.Control, KO)
      }
      session(OO) {
        (0, Wb.c)(this, fe)[fe] = OO, (0, Wb.c)(this, ue)[ue](OO)
      }
      filePartDone(OO, KO) {
        (0, Wb.c)(this, Je)[Je](aK.Jc.FilePartDone, function(OO, KO) {
          const pO = new Uint8Array(8),
            XO = new DataView(pO.buffer);
          return XO.setUint32(0, OO, !0), XO.setUint32(4, KO, !0), pO
        }(OO, KO))
      }
      fileDone(OO) {
        return (0, Wb.c)(this, Je)[Je](aK.Jc.FileDone, function(OO) {
          const KO = new Uint8Array(4);
          return new DataView(KO.buffer).setUint32(0, OO, !0), KO
        }(OO)), (0, Wb.c)(this, Pe)[Pe]()
      }
      saveEdited(OO) {
        return (0, Wb.c)(this, Ee)[Ee]("saveEdited"), (0, Wb.c)(this, gl)[gl].start(OO)
      }
      afterFrame() {
        if (!(0, Wb.c)(this, Me)[Me]) return;
        "read" === (0, Wb.c)(this, gl)[gl].beforeRecorderStep() && (0, Wb.c)(this, Pe)[Pe]();
        const OO = (0, Wb.c)(this, Ve)[Ve];
        (0, Wb.c)(this, Ve)[Ve] = null;
        const KO = (0, Wb.c)(this, Me)[Me],
          pO = (0, Wb.c)(this, al)[al];
        if (!KO || !pO) return void(null === OO || void 0 === OO || OO.resolve((0, Wb.c)(this, oe)[oe] ? "trapped" : "Sp"));
        const {
          core: XO
        } = this.deps, bK = XO.NMO(2);
        let eO, lO, vK, CO, hO = 0,
          DO = 0;
        if (0 !== bK) {
          var MO, aK;
          const OO = (0, Wb.c)(this, Ge)[Ge]();
          hO = null !== (MO = OO[bK >>> 2]) && void 0 !== MO ? MO : 0, DO = null !== (aK = OO[1 + (bK >>> 2)]) && void 0 !== aK ? aK : 0
        }
        try {
          if (DO > 0) {
            const OO = KO.feed(DO);
            0 !== OO && (0, Wb.c)(this, ql)[ql](pO).set((0, Wb.c)(this, Ze)[Ze]().subarray(hO, hO + DO), OO)
          }
          eO = KO.step(), lO = KO.yaO(), vK = KO.gaO(), CO = KO.uMO()
        } catch (oO) {
          if (!(0, Wb.c)(this, tl)[tl](oO)) throw null === OO || void 0 === OO || OO.resolve("Sp"), oO;
          return void(null === OO || void 0 === OO || OO.resolve("trapped"))
        }
        if (eO > 0) {
          const OO = XO.EMO(2, eO);
          0 !== OO && (0, Wb.c)(this, Ze)[Ze]().set((0, Wb.c)(this, ql)[ql](pO).subarray(lO, lO + eO), OO)
        }
        if (vK > 0) {
          (0, Wb.c)(this, Te)[Te] = [];
          try {
            this.deps.events(new Uint8Array(pO.buffer, CO, vK), pO)
          } catch (oO) {
            throw null === OO || void 0 === OO || OO.resolve("Sp"), oO
          } finally {
            const OO = (0, Wb.c)(this, Te)[Te];
            (0, Wb.c)(this, Te)[Te] = null;
            for (const [KO, pO] of OO)(0, Wb.c)(this, Je)[Je](KO, pO)
          }
        }
        if (!(0, Wb.c)(this, jl)[jl]() && !(0, Wb.c)(this, Ye)[Ye]()) return (0, Wb.c)(this, cl)[cl](), void(null === OO || void 0 === OO || OO.resolve("Sp"));
        null === OO || void 0 === OO || OO.resolve((0, Wb.c)(this, Se)[Se]())
      }
      dispose() {
        (0, Wb.c)(this, Fe)[Fe] = !0, (0, Wb.c)(this, cl)[cl]()
      }
    }

    function Ue(OO) {
      (0, Wb.c)(this, Je)[Je](aK.Jc.Session, function(OO) {
        const KO = new TextEncoder,
          pO = KO.encode(OO.game).subarray(0, 65535),
          XO = KO.encode(OO.lobby).subarray(0, 65535),
          bK = new Uint8Array(22 + pO.length + 2 + XO.length),
          eO = new DataView(bK.buffer);
        eO.setFloat64(0, OO.unixMs, !0), eO.setBigUint64(8, BigInt.asUintN(64, OO.session), !0), eO.setUint8(16, OO.lobbyType);
        let lO = 20;
        for (const vK of [pO, XO]) eO.setUint16(lO, vK.length, !0), bK.set(vK, lO + 2), lO += 2 + vK.length;
        return bK
      }({
        ...OO,
        unixMs: this.deps.unixNow()
      }))
    }

    function Ol(OO) {
      false
    }

    function Kl() {
      var OO, KO;
      return null !== (OO = null === (KO = (0, Wb.c)(this, Ae)[Ae]) || void 0 === KO ? void 0 : KO.on) && void 0 !== OO && OO
    }

    function pl() {
      const OO = (0, Wb.c)(this, Me)[Me];
      let KO = !0;
      if (OO) try {
        KO = OO.busy()
      } catch (pO) {
        if (!(0, Wb.c)(this, tl)[tl](pO)) throw pO
      }
      return KO || (0, Wb.c)(this, gl)[gl].active
    }
    async function Xl() {
      !(0, Wb.c)(this, Fe)[Fe] && this.deps.allowed() ? await (0, Wb.c)(this, il)[il]() : (0, Wb.c)(this, de)[de] = null
    }

    function bv() {
      return (0, Wb.c)(this, oe)[oe] || (0, Wb.c)(this, Fe)[Fe] ? Promise.resolve(!1) : (0, Wb.c)(this, Me)[Me] ? Promise.resolve(!0) : ((0, Wb.c)(this, Le)[Le] ??= (0, Wb.c)(this, rl)[rl](), (0, Wb.c)(this, Le)[Le])
    }
    async function el() {
      let OO = !1;
      try {
        return OO = await (0, Wb.c)(this, se)[se](), OO
      } finally {
        OO || ((0, Wb.c)(this, de)[de] = null), (0, Wb.c)(this, Le)[Le] = null
      }
    }

    function ll() {
      if (!(0, Wb.c)(this, Me)[Me]) return Promise.resolve((0, Wb.c)(this, oe)[oe] ? "trapped" : "Sp");
      if (!(0, Wb.c)(this, Ve)[Ve]) {
        let OO = () => {};
        const KO = new Promise((KO => {
          OO = KO
        }));
        (0, Wb.c)(this, Ve)[Ve] = {
          promise: KO,
          resolve: OO
        }
      }
      return (0, Wb.c)(this, Ve)[Ve].promise
    }

    function vv(OO) {
      const KO = (0, Wb.c)(this, Ve)[Ve];
      (0, Wb.c)(this, Ve)[Ve] = null, null === KO || void 0 === KO || KO.resolve(OO)
    }
    async function Cl() {
      let OO = (0, Wb.c)(this, De)[De];
      if (!OO) {
        const KO = (0, Wb.c)(this, Qe)[Qe];
        try {
          OO = await this.deps.load()
        } catch (pO) {
          return KO === (0, Wb.c)(this, Qe)[Qe] && await (0, Wb.c)(this, xl)[xl](pO), !1
        }
        if (KO !== (0, Wb.c)(this, Qe)[Qe]) return this.deps.unload(), !1;
        const XO = OO,
          bK = (0, Wb.c)(this, We)[We]((() => XO.jaO()));
        if (void 0 === bK) return !1;
        const eO = this.deps.core.YMO();
        if (bK !== eO) return await (0, Wb.c)(this, xl)[xl](new Error(`recorder port version ${bK}, the core's ${eO}`)), !1;
        (0, Wb.c)(this, De)[De] = OO
      }
      const KO = OO;
      try {
        if (!(0, Wb.c)(this, We)[We]((() => ((0, Wb.c)(this, Me)[Me] = new KO.wMO, (0, Wb.c)(this, al)[al] = KO.dMO(), !0)))) return !1;
        (0, Wb.c)(this, Re)[Re]();
        const OO = (0, Wb.c)(this, de)[de];
        return (0, Wb.c)(this, de)[de] = null, OO && (0, Wb.c)(this, Je)[Je](aK.Jc.Control, OO), (0, Wb.c)(this, He)[He]()
      } catch (pO) {
        return (0, Wb.c)(this, cl)[cl](), await (0, Wb.c)(this, xl)[xl](pO), !1
      }
    }

    function hl() {
      return this.deps.core.iaO(0), 1 === this.deps.core.iaO(1) || ((0, Wb.c)(this, cl)[cl](), this.deps.failed(Ce), !1)
    }

    function Dl() {
      (0, Wb.c)(this, Ae)[Ae] && (0, Wb.c)(this, Je)[Je](aK.Jc.Prefs, bl((0, Wb.c)(this, Ae)[Ae].on, (0, Wb.c)(this, Ae)[Ae].seconds)), (0, Wb.c)(this, fe)[fe] && (0, Wb.c)(this, ue)[ue]((0, Wb.c)(this, fe)[fe])
    }

    function Ml() {
      return vl({
        memoryBytes: this.deps.memoryBytes,
        clipSeconds: () => {
          var OO, KO;
          return null !== (OO = null === (KO = (0, Wb.c)(this, Ae)[Ae]) || void 0 === KO ? void 0 : KO.seconds) && void 0 !== OO ? OO : 0
        },
        trapped: () => (0, Wb.c)(this, oe)[oe],
        busy: () => (0, Wb.c)(this, Ye)[Ye](),
        loadInFlight: () => (0, Wb.c)(this, Le)[Le],
        YX: () => (0, Wb.c)(this, Fe)[Fe],
        unload: () => {
          (0, Wb.c)(this, cl)[cl]()
        },
        load: () => (0, Wb.c)(this, il)[il]()
      })
    }

    function av(OO, KO) {
      (0, Wb.c)(this, Te)[Te] ? (0, Wb.c)(this, Te)[Te].push([OO, KO]): (0, Wb.c)(this, ne)[ne](((pO, XO) => {
        const bK = pO.TMO(KO.length);
        0 !== bK && (new Uint8Array(XO.buffer, bK, KO.length).set(KO), pO.command(OO, KO.length))
      }))
    }

    function ol() {
      (0, Wb.c)(this, Qe)[Qe]++, (0, Wb.c)(this, ml)[ml]("Sp"), (0, Wb.c)(this, gl)[gl].stop(), this.deps.core.iaO(0), (0, Wb.c)(this, Be)[Be](), (0, Wb.c)(this, oe)[oe] || ((0, Wb.c)(this, De)[De] = null, this.deps.unload())
    }

    function Fl() {
      (0, Wb.c)(this, ne)[ne]((OO => {
        OO.free()
      })), (0, Wb.c)(this, Me)[Me] = null, (0, Wb.c)(this, al)[al] = null, (0, Wb.c)(this, yl)[yl] = null
    }

    function Vl() {
      var OO;
      const KO = this.deps.coreBuffer();
      return (null === (OO = (0, Wb.c)(this, Ne)[Ne]) || void 0 === OO ? void 0 : OO.buffer) !== KO && ((0, Wb.c)(this, Ne)[Ne] = new Uint8Array(KO)), (0, Wb.c)(this, Ne)[Ne]
    }

    function Ll() {
      var OO;
      const KO = this.deps.coreBuffer();
      return (null === (OO = (0, Wb.c)(this, Ie)[Ie]) || void 0 === OO ? void 0 : OO.buffer) !== KO && ((0, Wb.c)(this, Ie)[Ie] = new Uint32Array(KO, 0, KO.byteLength >>> 2)), (0, Wb.c)(this, Ie)[Ie]
    }

    function Ql(OO) {
      var KO;
      const pO = OO.buffer;
      return (null === (KO = (0, Wb.c)(this, yl)[yl]) || void 0 === KO ? void 0 : KO.buffer) !== pO && ((0, Wb.c)(this, yl)[yl] = new Uint8Array(pO)), (0, Wb.c)(this, yl)[yl]
    }
    async function zv(OO) {
      await this.deps.staleOr(OO, (() => {
        this.deps.failed(Ce)
      }))
    }

    function Al(OO) {
      const KO = (0, Wb.c)(this, Me)[Me],
        pO = (0, Wb.c)(this, al)[al];
      if (KO && pO) return (0, Wb.c)(this, We)[We]((() => OO(KO, pO)))
    }

    function fl(OO) {
      if (!(0, Wb.c)(this, oe)[oe]) try {
        return OO()
      } catch (KO) {
        if (!(0, Wb.c)(this, tl)[tl](KO)) throw KO;
        return
      }
    }

    function dl(OO) {
      return OO instanceof WebAssembly.RuntimeError && ((0, Wb.c)(this, oe)[oe] = !0, (0, Wb.c)(this, Me)[Me] = null, (0, Wb.c)(this, al)[al] = null, (0, Wb.c)(this, yl)[yl] = null, (0, Wb.c)(this, De)[De] = null, (0, Wb.c)(this, de)[de] = null, (0, Wb.c)(this, ml)[ml]("trapped"), this.deps.core.iaO(0), (0, Wb.c)(this, gl)[gl].stop(), this.deps.crash(this.deps.markTrapped(OO)), this.deps.failed("Replay recording stopped working, so reload the page to record replays again."), !0)
    }
    var Tl = pO(37025);
    const Nl = new Map([
      ["skyblock", () => pO.e(44).then((() => pO(37022)))]
    ]);

    function Il(OO) {
      const KO = Nl.get(OO);
      return KO ? KO().then((() => {
        const KO = (0, Tl.d)(OO);
        if (!KO) throw new Error(`${OO}'s replay hook module registered no hook`);
        return KO
      })) : null
    }
    class yv {
      constructor(OO) {
        this.deps = OO, this.game = null, this.hook = null, this.generation = 0, this.all = !1, this.pending = new Map, this.ids = new Int32Array(64)
      }
      get wantsWatch() {
        return null !== this.hook
      }
      opened(OO) {
        if (this.pending.clear(), OO === this.game && null !== this.hook) return void(this.all = !0);
        const KO = ++this.generation;
        this.game = OO, this.hook = null, this.all = !1;
        const pO = this.deps.loadHook(OO);
        null === pO || void 0 === pO || pO.then((OO => {
          KO === this.generation && (this.hook = OO, this.all = !0)
        }), (OO => {
          KO === this.generation && this.deps.onError(OO)
        }))
      }
      ended() {
        this.generation++, this.game = null, this.hook = null, this.all = !1, this.pending.clear()
      }
      entityAdded(OO) {
        null === this.hook || this.all || this.pending.set(OO, !0)
      }
      entityInfoChanged(OO) {
        null === this.hook || this.all || this.pending.has(OO) || this.pending.set(OO, !1)
      }
      flush(OO) {
        const {
          hook: KO
        } = this;
        if (null === KO || !OO || !this.all && 0 === this.pending.size) return;
        const pO = this.deps.cmd();
        if (null === pO) return;
        const {
          api: XO
        } = this.deps;
        if (this.all) {
          this.all = !1, this.pending.clear();
          const {
            ids: OO,
            count: KO
          } = Hp(XO, this.ids);
          this.ids = OO;
          for (let pO = 0; pO < KO; pO++) this.pending.set(OO[pO], !0)
        }
        const bK = this.ids = Rp(this.ids, this.pending.size);
        let eO = 0;
        for (const hO of this.pending.keys()) bK[eO++] = hO;
        const lO = [],
          vK = Sp(XO, bK, eO, ((OO, KO) => {
            null !== KO && lO.push({
              serverId: OO,
              info: KO,
              spawned: !0 === this.pending.get(OO)
            })
          }));
        if (vK) {
          this.pending.clear();
          for (const {
              serverId: OO,
              info: XO,
              spawned: bK
            }
            of lO) try {
            KO(XO, {
              setFacingTolerance: KO => {
                null === KO && bK || vX(pO, OO, KO) || this.pending.set(OO, bK)
              }
            })
          } catch (CO) {
            this.deps.onError(CO)
          }
        }
      }
    }
    var gv = (0, te.b)("MX"),
      ul = (0, te.b)("module"),
      El = (0, te.b)("memory"),
      jv = (0, te.b)("trapped"),
      Yl = (0, te.b)("generation"),
      wl = (0, te.b)("loading"),
      iv = (0, te.b)("lend"),
      rv = (0, te.b)("givenUp"),
      Pl = (0, te.b)("afterSave"),
      mv = (0, te.b)("opens"),
      sl = (0, te.b)("saveAskedAt"),
      Hl = (0, te.b)("unload"),
      Rl = (0, te.b)("dropModule"),
      Sl = (0, te.b)("loadFailed"),
      Jl = (0, te.b)("saveReadsBody"),
      cv = (0, te.b)("command"),
      Bl = (0, te.b)("call"),
      Zl = (0, te.b)("guard"),
      Gl = (0, te.b)("trapOn");
    class qv {
      constructor(OO) {
        this.deps = OO, Object.defineProperty(this, Gl, {
          value: Kv
        }), Object.defineProperty(this, Zl, {
          value: Ov
        }), Object.defineProperty(this, Bl, {
          value: Ul
        }), Object.defineProperty(this, cv, {
          value: kv
        }), Object.defineProperty(this, Jl, {
          get: tv,
          set: void 0
        }), Object.defineProperty(this, Sl, {
          value: Wl
        }), Object.defineProperty(this, Rl, {
          value: nl
        }), Object.defineProperty(this, Hl, {
          value: xv
        }), Object.defineProperty(this, gv, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, ul, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, El, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, jv, {
          writable: !0,
          value: !1
        }), Object.defineProperty(this, Yl, {
          writable: !0,
          value: 0
        }), Object.defineProperty(this, wl, {
          writable: !0,
          value: 0
        }), Object.defineProperty(this, iv, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, rv, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, Pl, {
          writable: !0,
          value: null
        }), Object.defineProperty(this, mv, {
          writable: !0,
          value: 0
        }), Object.defineProperty(this, sl, {
          writable: !0,
          value: null
        })
      }
      get active() {
        return null !== (0, Wb.c)(this, ul)[ul] && null === (0, Wb.c)(this, Pl)[Pl]
      }
      async open(OO) {
        if ((0, Wb.c)(this, jv)[jv]) return aK.Sc.ModuleTrap;
        let KO = (0, Wb.c)(this, gv)[gv];
        if (!KO) {
          const OO = (0, Wb.c)(this, Yl)[Yl];
          (0, Wb.c)(this, wl)[wl]++;
          try {
            KO = await this.deps.load()
          } catch (XO) {
            return (0, Wb.c)(this, wl)[wl]--, OO !== (0, Wb.c)(this, Yl)[Yl] ? "stopped" : (0, Wb.c)(this, Sl)[Sl](XO)
          }
          if ((0, Wb.c)(this, wl)[wl]--, OO !== (0, Wb.c)(this, Yl)[Yl]) return (0, Wb.c)(this, gv)[gv] || 0 !== (0, Wb.c)(this, wl)[wl] || (0, Wb.c)(this, jv)[jv] || this.deps.unload(), "stopped";
          if ((0, Wb.c)(this, jv)[jv]) return aK.Sc.ModuleTrap;
          const pO = KO.jaO(),
            bK = this.deps.core.YMO();
          if (pO !== bK) return (0, Wb.c)(this, Sl)[Sl](new Error(`replay port version ${pO}, the core's ${bK}`));
          (0, Wb.c)(this, gv)[gv] = KO
        }
        if (!(0, Wb.c)(this, ul)[ul]) {
          const OO = KO;
          if (!(0, Wb.c)(this, Zl)[Zl]((() => {
              (0, Wb.c)(this, ul)[ul] = new OO.raO, (0, Wb.c)(this, El)[El] = OO.PMO()
            }))) return aK.Sc.ModuleTrap
        }
        let pO = !1;
        return (0, Wb.c)(this, Bl)[Bl](((KO, XO) => {
          null !== (0, Wb.c)(this, Pl)[Pl] && KO.step(0, 0);
          const bK = KO.stage(OO.length);
          0 !== bK && (new Uint8Array(XO.buffer, bK, OO.length).set(OO), KO.open(), (0, Wb.c)(this, rv)[rv] = (0, Wb.c)(this, iv)[iv], (0, Wb.c)(this, Pl)[Pl] = null, (0, Wb.c)(this, mv)[mv]++, pO = !0)
        })) ? pO ? "opening" : aK.Sc.TooLarge : aK.Sc.ModuleTrap
      }
      beforeFrame(OO) {
        const KO = (0, Wb.c)(this, ul)[ul],
          pO = (0, Wb.c)(this, El)[El];
        if (!KO || !pO || null !== (0, Wb.c)(this, Pl)[Pl]) return;
        const {
          core: XO
        } = this.deps, bK = XO.maO(OO);
        if (bK < 0) return;
        const eO = Math.floor(bK);
        let lO, vK;
        try {
          lO = KO.step(eO, bK - eO), vK = KO.yaO()
        } catch (hO) {
          return void(0, Wb.c)(this, Gl)[Gl](hO)
        }
        const CO = XO.EMO(1, lO);
        if (0 === CO) {
          const OO = (0, Wb.c)(this, Bl)[Bl]((OO => {
            OO.close()
          }));
          if (!OO) return;
          return (0, Wb.c)(this, Jl)[Jl] ? (0, Wb.c)(this, Pl)[Pl] = "drop" : (0, Wb.c)(this, Rl)[Rl](), void XO.sMO(aK.Sc.Port)
        }
        new Uint8Array(this.deps.coreBuffer(), CO, lO).set(new Uint8Array(pO.buffer, vK, lO))
      }
      play() {
        (0, Wb.c)(this, cv)[cv]((OO => {
          OO.play()
        }))
      }
      pause() {
        (0, Wb.c)(this, cv)[cv]((OO => {
          OO.pause()
        }))
      }
      seek(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        (0, Wb.c)(this, cv)[cv]((pO => {
          pO.seek(OO, KO)
        }))
      }
      setMark(OO, KO) {
        return (0, Wb.c)(this, cv)[cv]((pO => {
          pO.HMO(OO, KO)
        }))
      }
      addKeyframe(OO, KO) {
        return (0, Wb.c)(this, cv)[cv]((pO => {
          pO.RMO(OO[0], OO[1], OO[2], KO[0], KO[1], KO[2])
        }))
      }
      setKeyframe(OO, KO) {
        return (0, Wb.c)(this, cv)[cv]((pO => {
          pO.SMO(OO, KO)
        }))
      }
      moveKeyframe(OO, KO) {
        return (0, Wb.c)(this, cv)[cv]((pO => {
          pO.JMO(OO, KO)
        }))
      }
      deleteKeyframes(OO, KO) {
        return (0, Wb.c)(this, cv)[cv]((pO => {
          pO.caO(OO, KO)
        }))
      }
      crop(OO, KO) {
        return null === (0, Wb.c)(this, iv)[iv] && (0, Wb.c)(this, cv)[cv]((pO => {
          pO.crop(OO, KO)
        }))
      }
      beginSave() {
        const OO = (0, Wb.c)(this, sl)[sl];
        if ((0, Wb.c)(this, sl)[sl] = null, null !== OO && OO !== (0, Wb.c)(this, mv)[mv]) return null;
        let KO = 0,
          pO = null;
        if ((0, Wb.c)(this, Bl)[Bl](((OO, XO) => {
            KO = OO.save(), 0 !== KO && (pO = new Uint8Array(XO.buffer, OO.BMO(), OO.ZMO()).slice())
          })), 0 === KO || !pO) return null;
        const XO = {
          headLen: KO,
          editState: pO,
          givenUp: () => (0, Wb.c)(this, rv)[rv] === XO,
          head: (OO, KO) => {
            if ((0, Wb.c)(this, iv)[iv] !== XO || !(0, Wb.c)(this, Jl)[Jl]) return null;
            let pO = null;
            return (0, Wb.c)(this, Bl)[Bl](((XO, bK) => {
              const eO = XO.GMO();
              0 !== eO && OO >= 0 && KO >= 0 && OO + KO <= eO && (pO = new Uint8Array(bK.buffer, XO.qaO() + OO, KO))
            })), pO
          },
          end: () => {
            if ((0, Wb.c)(this, iv)[iv] !== XO) return;
            (0, Wb.c)(this, iv)[iv] = null, (0, Wb.c)(this, rv)[rv] = null, (0, Wb.c)(this, Bl)[Bl]((OO => {
              OO.xaO()
            }));
            const OO = (0, Wb.c)(this, Pl)[Pl];
            (0, Wb.c)(this, Pl)[Pl] = null, "unload" === OO ? (0, Wb.c)(this, Hl)[Hl]() : "drop" === OO && (0, Wb.c)(this, Rl)[Rl]()
          }
        };
        return (0, Wb.c)(this, iv)[iv] = XO, XO
      }
      askSave() {
        (0, Wb.c)(this, sl)[sl] = (0, Wb.c)(this, mv)[mv]
      }
      setSpeed(OO) {
        (0, Wb.c)(this, cv)[cv]((KO => {
          KO.nMO(OO)
        }))
      }
      setCameraMode(OO) {
        (0, Wb.c)(this, cv)[cv]((KO => {
          KO.WMO(OO)
        }))
      }
      close() {
        (0, Wb.c)(this, cv)[cv]((OO => {
          OO.close()
        }))
      }
      stop() {
        (0, Wb.c)(this, Yl)[Yl]++, (0, Wb.c)(this, Jl)[Jl] && ((0, Wb.c)(this, Bl)[Bl]((OO => {
          OO.close()
        })), (0, Wb.c)(this, ul)[ul]) ? (0, Wb.c)(this, Pl)[Pl] = "unload" : (0, Wb.c)(this, Hl)[Hl]()
      }
    }

    function xv() {
      (0, Wb.c)(this, Rl)[Rl](), (0, Wb.c)(this, jv)[jv] || ((0, Wb.c)(this, gv)[gv] = null, this.deps.unload())
    }

    function nl() {
      (0, Wb.c)(this, Bl)[Bl]((OO => {
        OO.free()
      })), (0, Wb.c)(this, ul)[ul] = null, (0, Wb.c)(this, El)[El] = null
    }
    async function Wl(OO) {
      return await this.deps.staleOr(OO, (() => {})) ? "reloading" : aK.Sc.ModuleLoad
    }

    function tv() {
      return null !== (0, Wb.c)(this, iv)[iv] && (0, Wb.c)(this, rv)[rv] !== (0, Wb.c)(this, iv)[iv]
    }

    function kv(OO) {
      return null === (0, Wb.c)(this, Pl)[Pl] && (0, Wb.c)(this, Bl)[Bl](OO)
    }

    function Ul(OO) {
      const KO = (0, Wb.c)(this, ul)[ul],
        pO = (0, Wb.c)(this, El)[El];
      return !(!KO || !pO) && (0, Wb.c)(this, Zl)[Zl]((() => {
        OO(KO, pO)
      }))
    }

    function Ov(OO) {
      if ((0, Wb.c)(this, jv)[jv]) return !1;
      try {
        return OO(), !0
      } catch (KO) {
        return (0, Wb.c)(this, Gl)[Gl](KO), !1
      }
    }

    function Kv(OO) {
      if (!(OO instanceof WebAssembly.RuntimeError)) throw OO;
      (0, Wb.c)(this, jv)[jv] = !0, (0, Wb.c)(this, ul)[ul] = null, (0, Wb.c)(this, El)[El] = null, (0, Wb.c)(this, gv)[gv] = null, this.deps.crash(this.deps.markTrapped(OO)), this.deps.core.sMO(aK.Sc.ModuleTrap)
    }
    var pv = pO(5630),
      Xv = pO(38803);
    const bC = "[bloxd-wasm-client]";
    const ev = String(ge);

    function lv(OO) {
      return null === OO || OO === ev ? void 0 : OO
    }

    function vC(OO) {
      var KO, pO, XO, bK, eO, vK, CO;
      switch (OO.what) {
        case aK.$c.FlyingText: {
          let KO;
          try {
            KO = JSON.parse(OO.contentJson)
          } catch (hO) {
            return void console.warn(`${bC} a replay's flying text isn't JSON`, hO)
          }
          lO.i.pl("forceFlyingMiddleMessage", {
            content: KO,
            ROO: OO.ROO,
            angle: OO.angle,
            SOO: OO.SOO
          });
          break
        }
        case aK.$c.PlayerKilled:
          (0, Xv.g)({
            kind: "killed",
            body: {
              deadEId: null !== (KO = lv(OO.dead)) && void 0 !== KO ? KO : "",
              killerEId: lv(OO.killer),
              withItem: null !== (pO = OO.withItem) && void 0 !== pO ? pO : "",
              killstreak: OO.killstreak
            }
          });
          break;
        case aK.$c.Killfeed:
          (0, Xv.g)({
            kind: "custom",
            body: {
              killer: {
                eId: lv(OO.killerId),
                name: null !== (XO = OO.killerName) && void 0 !== XO ? XO : void 0,
                colour: null !== (bK = OO.killerColour) && void 0 !== bK ? bK : void 0
              },
              victim: {
                eId: lv(OO.victimId),
                name: null !== (eO = OO.victimName) && void 0 !== eO ? eO : void 0,
                colour: null !== (vK = OO.victimColour) && void 0 !== vK ? vK : void 0
              },
              withItem: null !== (CO = OO.withItem) && void 0 !== CO ? CO : ""
            }
          })
      }
    }
    const Cv = "[bloxd-wasm-client]";

    function hv(OO) {
      if (void 0 === OO || null === OO || "" === OO) return null;
      const KO = Number(OO);
      return Number.isInteger(KO) && KO > ge && KO <= 2147483647 ? KO : null
    }

    function Dv(OO) {
      return {
        id: hv(OO.eId),
        name: "string" === typeof OO.name ? OO.name : null,
        colour: "string" === typeof OO.colour ? OO.colour : null
      }
    }

    function Mv(OO) {
      const KO = (0, sb.n)(qX.Hb.PlayerKilled, (KO => {
          var pO, XO;
          const bK = (0, me.g)(KO);
          if (!(0, me.b)(bK)) return;
          const {
            deadEId: eO,
            killerEId: lO,
            withItem: vK,
            killstreak: CO
          } = bK;
          OO.recordPlayerKilled(null !== (pO = hv(eO)) && void 0 !== pO ? pO : ge, null !== (XO = hv(lO)) && void 0 !== XO ? XO : ge, "number" === typeof CO ? CO : 0, "string" === typeof vK ? vK : "")
        })),
        pO = (0, sb.n)(qX.Hb.CustomKillfeed, (KO => {
          const pO = (0, me.g)(KO);
          if (!(0, me.b)(pO) || !(0, me.b)(pO.killer) || !(0, me.b)(pO.victim)) return;
          const {
            killer: XO,
            victim: bK,
            withItem: eO
          } = pO;
          OO.recordKillfeed(Dv(XO), Dv(bK), "string" === typeof eO ? eO : null)
        }));
      return () => {
        KO(), pO()
      }
    }

    function aC(OO) {
      var KO;
      return void 0 === OO || null === OO ? null : null !== (KO = JSON.stringify(OO)) && void 0 !== KO ? KO : null
    }

    function ov(OO) {
      let KO = null;
      const pO = () => {
        const {
          enableClipping: pO,
          clipDurationSeconds: bK
        } = XO.d.get("clientEscMenuOptions"), eO = `${pO}:${bK}`;
        eO !== KO && (KO = eO, OO.recorder.setPrefs(pO, bK))
      };
      return pO(), (0, lO.j)("appManagerUpdated|clientEscMenuOptions", pO)
    }
    const Fv = "replayModule",
      Vv = "recorderModule";

    function Lv(OO, KO, pO) {
      return function() {
        return OO.isStopped ? pO : KO(...arguments)
      }
    }
    const Qv = {
      open: () => Promise.reject(new Error(Qb.b.coreStopped.text)),
      replayKey: () => null,
      encode: () => Promise.resolve(null),
      fileHandle: () => null,
      markSaved: () => {}
    };

    function zC() {
      return pO.e(56).then((() => pO(59359)))
    }

    function Av(OO) {
      (0, Qb.f)({
        text: OO,
        type: "Error"
      })
    }
    class fv {
      constructor(OO) {
        this.deps = OO, this.runtime = void 0, this.entityHooks = void 0, this.recordedOptions = void 0, this.stops = void 0, this.activeConn = 0, this.stopped = !1, this.bench = null, this.replay = void 0, this.recorder = void 0, this.freecam = void 0, this.drawn = !1;
        const {
          running: KO,
          api: XO,
          core: bK
        } = OO, eO = () => OO.memory().buffer, lO = () => KO.isStopped ? null : KO.rings.cmd, vK = Lv(KO, ((OO, KO) => bK.EMO(OO, KO)), 0), CO = () => bK.YMO();
        let hO = null;
        this.replay = new qv({
          core: {
            maO: Lv(KO, (OO => bK.maO(OO)), -1),
            EMO: vK,
            YMO: CO,
            sMO: Lv(KO, (OO => {
              bK.sMO(OO)
            }), void 0)
          },
          coreBuffer: eO,
          load: async () => (hO = await pO.e(57).then((() => pO(59372))), hO.loadReplayModule()),
          unload: () => {
            var OO;
            null === (OO = hO) || void 0 === OO || OO.unloadReplayModule()
          },
          markTrapped: OO => hO ? hO.markReplayTrapped(OO) : new Error(String(OO)),
          staleOr: (KO, pO) => OO.staleOr(Fv, KO, pO),
          crash: KO => {
            OO.reportFault(Fv, KO)
          }
        });
        let DO = null;
        this.recorder = new kl({
          core: {
            iaO: Lv(KO, (OO => bK.iaO(OO)), 0),
            NMO: Lv(KO, (OO => bK.NMO(OO)), 0),
            EMO: vK,
            YMO: CO
          },
          coreCommand: (OO, KO) => {
            var pO, XO;
            return null !== (pO = null === (XO = lO()) || void 0 === XO ? void 0 : XO.writeCmd(OO, 0, KO)) && void 0 !== pO && pO
          },
          coreBuffer: eO,
          load: async () => (DO = await zC(), DO.loadRecorderModule()),
          prefetch: () => {
            zC().then((OO => OO.prefetchRecorderModule())).catch((OO => {
              console.warn(`${Cv} the recorder module didn't prefetch, so a save loads it:`, OO)
            }))
          },
          unload: () => {
            var OO;
            null === (OO = DO) || void 0 === OO || OO.unloadRecorderModule()
          },
          markTrapped: OO => DO ? DO.markRecorderTrapped(OO) : new Error(String(OO)),
          memoryBytes: () => {
            var OO, KO;
            return null !== (OO = null === (KO = DO) || void 0 === KO ? void 0 : KO.recorderMemoryBytes()) && void 0 !== OO ? OO : 0
          },
          staleOr: (KO, pO) => OO.staleOr(Vv, KO, pO),
          crash: KO => {
            OO.reportFault(Vv, KO)
          },
          allowed: () => !0 === OO.options.get("canRecordReplays"),
          failed: Av,
          events: (OO, KO) => {
            this.runtime.recorderEvents(OO, KO)
          },
          beginSave: () => this.replay.beginSave(),
          givenUp: Av,
          unixNow: () => Date.now()
        });
        const MO = new ye({
          core: {
            FMO: Lv(KO, (OO => bK.FMO(OO)), 0),
            LMO: Lv(KO, (() => {
              bK.LMO()
            }), void 0),
            qv: Lv(KO, (() => bK.qv()), 0),
            VMO: Lv(KO, (() => bK.VMO()), 0)
          },
          buffer: eO,
          apiView: () => XO.apiView,
          cmd: lO,
          replay: this.replay,
          recorder: this.recorder
        });
        this.entityHooks = new yv({
          api: XO,
          cmd: lO,
          loadHook: Il,
          onError: OO => {
            console.warn(`${Cv} the recorded game's replay hooks:`, OO)
          }
        });
        const aK = new Pb({
          client: MO,
          buffer: eO,
          setHoldDraws: OO => {
            KO.setHoldDraws(OO)
          },
          notify: Qb.f,
          onRecorderState: () => {
            var OO;
            null === (OO = (0, Ab.e)()) || void 0 === OO || OO.recorderChanged()
          },
          onViewerChange: () => {
            var OO;
            null === (OO = (0, Ab.e)()) || void 0 === OO || OO.viewerChanged()
          },
          onReplayOption: KO => {
            ! function(OO, KO) {
              var pO, XO;
              const bK = qX.W[KO.key];
              if (void 0 === bK) return;
              let eO = null !== (pO = KO.value) && void 0 !== pO ? pO : JSON.parse(JSON.stringify(null !== (XO = pv.c[bK]) && void 0 !== XO ? XO : null));
              if (null !== KO.value && KO.key < qX.nb.Environment && "string" === typeof eO) try {
                eO = JSON.parse(eO)
              } catch (lO) {
                return void console.warn(`${bC} a replay's ${bK} isn't JSON`, lO)
              }
              OO.applyNewClientOptions({
                [bK]: eO
              })
            }(OO.options, KO)
          },
          onReplayUiEvent: vC,
          onReplayOpened: KO => {
            this.entityHooks.opened((0, gK.Qb)(KO)), OO.replayShaderPack(KO)
          },
          meshPending: () => {
            var OO, pO;
            return null !== (OO = null === (pO = KO.lastHeader) || void 0 === pO ? void 0 : pO.renderPending) && void 0 !== OO ? OO : 0
          },
          viewerOpen: ze.c,
          download: OO => {
            (0, Vb.j)(OO)
          }
        });
        this.runtime = aK, XO.replay = aK.sink, (0, Ab.q)(aK);
        const oO = new Sb({
          live: () => {
            var OO;
            return !KO.isStopped && !0 === (null === (OO = aK.currentViewer) || void 0 === OO ? void 0 : OO.inPlayback)
          },
          cmd: lO,
          dragScale: xe
        });
        this.freecam = oO, (0, Ab.o)(oO), this.recordedOptions = function(OO, KO) {
          const pO = qX.W,
            XO = pO.map(((pO, XO) => KO.subscribe(pO, (KO => {
              OO.setOption(XO, aC(KO))
            }))));
          return {
            sendAll() {
              pO.forEach(((pO, XO) => {
                OO.setOption(XO, aC(KO.get(pO)))
              }))
            },
            stop() {
              for (const OO of XO) OO()
            }
          }
        }(aK.recorder, OO.options), this.stops = [(0, XX.k)((OO => {
          oO.flush();
          try {
            this.replay.beforeFrame(OO)
          } catch (KO) {
            this.deps.reportFault("replayFrame", KO)
          }
        })), (0, XX.x)(((OO, KO) => {
          try {
            this.recorder.afterFrame(), KO && !this.drawn && (this.drawn = !0, this.recorder.viewDrawn())
          } catch (pO) {
            this.deps.reportFault("recorderFrame", pO)
          }
          try {
            aK.afterFrame(OO)
          } catch (pO) {
            this.deps.reportFault("replayRuntime", pO)
          }
        })), ov(aK), () => {
          this.recordedOptions.stop()
        }, Mv(aK.recorder), (0, Hb.h)((OO => {
          let {
            action: KO,
            down: pO
          } = OO;
          var XO;
          pO && (null === (XO = (0, Ab.e)()) || void 0 === XO || XO.keyDown(KO))
        }))];
        const FO = () => {
          const OO = aK.currentViewer;
          return !0 === (null === OO || void 0 === OO ? void 0 : OO.isOpen) ? OO : null
        };
        (0, Lb.e)({
          open: (OO, KO) => this.open(OO, KO),
          replayKey: () => {
            var OO, KO;
            return null !== (OO = null === (KO = FO()) || void 0 === KO ? void 0 : KO.id) && void 0 !== OO ? OO : null
          },
          saveRefusal: () => {
            var OO, KO;
            return null !== (OO = null === (KO = FO()) || void 0 === KO ? void 0 : KO.saveRefusal) && void 0 !== OO ? OO : null
          },
          encode: () => {
            var OO, KO;
            return null !== (OO = null === (KO = FO()) || void 0 === KO ? void 0 : KO.save()) && void 0 !== OO ? OO : Promise.resolve(null)
          },
          fileHandle: () => {
            var OO, KO;
            return null !== (OO = null === (KO = aK.currentViewer) || void 0 === KO ? void 0 : KO.fileHandle) && void 0 !== OO ? OO : null
          },
          markSaved: (OO, KO) => {
            var pO;
            null === (pO = aK.currentViewer) || void 0 === pO || pO.markSaved(OO, KO)
          }
        })
      }
      netEvent(OO) {
        if ("connection" === OO.type)
          if (OO.phase === aK.F.Activated) {
            this.activeConn = OO.conn;
            const KO = this.deps.sessionInfo(OO.conn);
            null !== KO && (this.runtime.activated({
              lobbyType: (0, uO.u)(KO.lobbyName),
              gameNameWithVariation: KO.gameNameWithVariation,
              lobbyName: KO.lobbyName
            }), this.recordedOptions.sendAll())
          } else OO.phase !== aK.F.Left && OO.phase !== aK.F.Closed || OO.conn !== this.activeConn || (this.activeConn = 0, this.runtime.recorder.closed())
      }
      stop() {
        if (!this.stopped) {
          this.stopped = !0;
          for (const OO of this.stops) OO();
          this.runtime.end(), this.entityHooks.ended(), this.replay.stop(), this.recorder.dispose(), (0, Ab.h)() === this.runtime && (0, Ab.q)(null), (0, Ab.f)() === this.freecam && (0, Ab.o)(null), (0, Lb.e)(Qv), null !== this.bench && window.wasmReplayBench === this.bench && (window.wasmReplayBench = void 0)
        }
      }
      async open(OO, KO) {
        const {
          running: pO
        } = this.deps;
        if (pO.isStopped) throw new Error(Qb.b.coreStopped.text);
        if (OO.byteLength > 67108864) throw new Error(Qb.b.cantOpen.text);
        let XO;
        try {
          XO = await async function(OO) {
            const KO = await OO.loadViewer();
            return KO.inPlayback || (0, XX.F)().leaveGame(null), KO
          }(this.runtime)
        } catch (bK) {
          throw console.warn(`${Cv} the replay viewer didn't load`, bK), new Error(Qb.b.viewerLoadFailed.text)
        }
        if (pO.isStopped) throw new Error(Qb.b.coreStopped.text);
        await XO.open(OO, KO)
      }
    }
    var dv = pO(1569),
      Tv = pO(38961);

    function Nv(OO) {
      (0, Tv.A)(function(OO) {
        return {
          aux: OO.reset ? aK.Wb.ResetFirst : 0,
          payload: yC(OO.changes)
        }
      }(OO)) && (OO.reset && dv.c.reset(), dv.c.apply(OO.changes))
    }
    const Iv = new TextEncoder;

    function yC(OO) {
      const KO = new gC;
      return Ev(KO, OO), KO.bytes()
    }
    class gC {
      constructor() {
        this.buf = new Uint8Array(256), this.view = new DataView(this.buf.buffer), this.len = 0
      }
      room(OO) {
        if (this.len + OO <= this.buf.length) return;
        const KO = new Uint8Array(Math.max(2 * this.buf.length, this.len + OO));
        KO.set(this.buf.subarray(0, this.len)), this.buf = KO, this.view = new DataView(KO.buffer)
      }
      u8(OO) {
        this.room(1), this.buf[this.len++] = OO
      }
      tagged(OO, KO, pO) {
        this.room(1 + KO), this.buf[this.len++] = OO, 1 === KO ? this.view.setUint8(this.len, pO) : 2 === KO ? this.view.setUint16(this.len, pO) : this.view.setUint32(this.len, pO), this.len += KO
      }
      signed(OO, KO, pO) {
        this.room(1 + KO), this.buf[this.len++] = OO, 1 === KO ? this.view.setInt8(this.len, pO) : 2 === KO ? this.view.setInt16(this.len, pO) : this.view.setInt32(this.len, pO), this.len += KO
      }
      f64(OO) {
        this.room(9), this.buf[this.len++] = 203, this.view.setFloat64(this.len, OO), this.len += 8
      }
      raw(OO) {
        this.room(OO.length), this.buf.set(OO, this.len), this.len += OO.length
      }
      bytes() {
        return this.buf.slice(0, this.len)
      }
    }

    function uv(OO, KO, pO, XO, bK, eO, lO) {
      KO < XO ? OO.u8(pO | KO) : null !== bK && KO < 256 ? OO.tagged(bK, 1, KO) : KO < 65536 ? OO.tagged(eO, 2, KO) : OO.tagged(lO, 4, KO)
    }

    function Ev(OO, KO) {
      switch (typeof KO) {
        case "undefined":
          return void OO.raw(jC);
        case "boolean":
          return void OO.u8(KO ? 195 : 194);
        case "number":
          return void
          function(OO, KO) {
            KO >>> 0 === KO ? KO < 128 ? OO.u8(KO) : KO < 256 ? OO.tagged(204, 1, KO) : KO < 65536 ? OO.tagged(205, 2, KO) : OO.tagged(206, 4, KO) : (KO | 0) === KO ? KO >= -32 ? OO.u8(255 & KO) : KO >= -128 ? OO.signed(208, 1, KO) : KO >= -32768 ? OO.signed(209, 2, KO) : OO.signed(210, 4, KO) : OO.f64(KO)
          }(OO, KO);
        case "string": {
          const pO = Iv.encode(KO);
          return uv(OO, pO.length, 160, 32, 217, 218, 219), void OO.raw(pO)
        }
        case "object":
          break;
        default:
          return void OO.u8(192)
      }
      if (null === KO) OO.u8(192);
      else if (Array.isArray(KO)) {
        uv(OO, KO.length, 144, 16, null, 220, 221);
        for (const pO of KO) Ev(OO, pO)
      } else if (KO instanceof Uint8Array) uv(OO, KO.length, 0, 0, 196, 197, 198), OO.raw(KO);
      else {
        const pO = Object.keys(KO);
        uv(OO, pO.length, 128, 0, null, 222, 223);
        for (const XO of pO) Ev(OO, XO), Ev(OO, KO[XO])
      }
    }
    const jC = new Uint8Array([212, 0, 0]);
    var Yv = pO(40627),
      wv = pO(40634),
      iC = pO(39083),
      rC = pO(39108),
      Pv = pO(2951);
    const mC = [1e3, 3e3, 9e3];
    class sv {
      constructor(OO) {
        this.host = OO, this.sets = new Map, this.table = [], this.generation = 0, this.YX = !1
      }
      onEvent(OO) {
        const KO = function(OO) {
          if (OO.byteLength !== aK.jd) return null;
          const KO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength);
          return {
            want: KO.getUint16(0, !0),
            release: KO.getUint16(2, !0)
          }
        }(OO);
        KO && !this.YX && (KO.release !== aK.kd && this.release(KO.release), KO.want !== aK.kd && this.want(KO.want))
      }
      reset(OO) {
        if (!this.YX) {
          for (const [OO, KO] of this.sets) "ready" === KO.state && this.releaseAll(KO.distinct), this.sets.delete(OO);
          this.table = OO, this.generation++
        }
      }
      dispose() {
        if (this.YX) return;
        this.YX = !0, this.generation++, this.table = [];
        const OO = [...this.sets.values()];
        this.sets.clear();
        let KO = null;
        for (const XO of OO)
          for (const OO of "ready" === XO.state ? XO.distinct : []) try {
            this.host.taO(OO)
          } catch (pO) {
            KO ??= {
              error: pO
            }
          }
        if (KO) throw KO.error
      }
      isReady(OO) {
        var KO;
        return "ready" === (null === (KO = this.sets.get(OO)) || void 0 === KO ? void 0 : KO.state)
      }
      want(OO) {
        const KO = this.sets.get(OO);
        if ("loading" === (null === KO || void 0 === KO ? void 0 : KO.state)) return KO.wanted = !0, void this.capAnswer(OO, KO);
        if ("ready" === (null === KO || void 0 === KO ? void 0 : KO.state)) return void this.host.sendReady(Rv(OO, KO.images, KO.size));
        const pO = this.table[OO];
        if (!pO || 1 !== pO.urls.length && pO.urls.length !== qX.Cb.CubeFaces) return this.host.sendReady(Sv(OO)), void this.host.onLoadFailed(OO, "", new Error(`no image set ${OO}`));
        const XO = {
          state: "loading",
          wanted: !0
        };
        this.sets.set(OO, XO), this.load(OO, pO, XO, this.generation, 0), this.capAnswer(OO, XO)
      }
      capAnswer(OO, KO) {
        this.host.wait(4e3, (() => {
          this.sets.get(OO) === KO && KO.wanted && this.host.sendReady(Sv(OO))
        }))
      }
      load(OO, KO, pO, XO, bK) {
        const eO = [...new Set(KO.urls)];
        Promise.allSettled(eO.map((OO => this.host.loadImage(OO, KO.orientation)))).then((lO => {
          const vK = lO.flatMap((OO => "fulfilled" === OO.status ? [OO.value] : [])),
            CO = XO === this.generation && this.sets.get(OO) === pO,
            hO = lO.findIndex((OO => "rejected" === OO.status));
          if (!CO || !pO.wanted) return this.YX ? void this.releaseAfterDispose(vK.map(Hv)) : (this.releaseAll(vK.map(Hv)), void(CO && this.sets.delete(OO)));
          hO < 0 ? this.loaded(OO, KO, eO, vK) : (this.releaseAll(vK.map(Hv)), this.host.sendReady(Sv(OO)), bK < mC.length ? this.host.wait(mC[bK], (() => {
            XO === this.generation && this.sets.get(OO) === pO && (pO.wanted ? this.load(OO, KO, pO, XO, bK + 1) : this.sets.delete(OO))
          })) : (this.sets.delete(OO), this.host.onLoadFailed(OO, eO[hO], lO[hO].reason)))
        }))
      }
      loaded(OO, KO, pO, XO) {
        const [bK] = XO, eO = [bK.width, bK.height], lO = XO.every((OO => OO.width === eO[0] && OO.height === eO[1])), vK = KO.urls.length === qX.Cb.CubeFaces;
        if (!lO || eO[0] <= 0 || eO[1] <= 0 || eO[0] > 65535 || eO[1] > 65535 || vK && eO[0] !== eO[1]) {
          this.releaseAll(XO.map(Hv)), this.sets.delete(OO), this.host.sendReady(Sv(OO));
          const pO = XO.map((OO => `${OO.width}x${OO.height}`));
          return void this.host.onLoadFailed(OO, KO.urls[0], new Error(`set ${OO}'s images can't make its texture: ${pO.join(", ")}`))
        }
        const CO = KO.urls.map((OO => XO[pO.indexOf(OO)].id)),
          hO = XO.map(Hv);
        this.sets.set(OO, {
          state: "ready",
          images: CO,
          distinct: hO,
          size: eO
        }), this.host.sendReady(Rv(OO, CO, eO))
      }
      release(OO) {
        const KO = this.sets.get(OO);
        "loading" === (null === KO || void 0 === KO ? void 0 : KO.state) ? KO.wanted = !1: "ready" === (null === KO || void 0 === KO ? void 0 : KO.state) && (this.releaseAll(KO.distinct), this.sets.delete(OO))
      }
      releaseAll(OO) {
        for (const KO of OO) this.host.taO(KO)
      }
      releaseAfterDispose(OO) {
        for (const KO of OO) try {
          this.host.taO(KO)
        } catch {}
      }
    }

    function Hv(OO) {
      return OO.id
    }

    function Rv(OO, KO, pO) {
      const XO = new Uint8Array(qX.Cb.SkyImagesReadyBytes),
        bK = new DataView(XO.buffer);
      return bK.setUint16(0, OO, !0), bK.setUint16(2, KO.length, !0), bK.setUint16(4, pO[0], !0), bK.setUint16(6, pO[1], !0), KO.slice(0, qX.Cb.CubeFaces).forEach(((OO, KO) => {
        bK.setUint32(8 + 4 * KO, OO, !0)
      })), XO
    }

    function Sv(OO) {
      const KO = new Uint8Array(qX.Cb.SkyImagesReadyBytes),
        pO = new DataView(KO.buffer);
      return pO.setUint16(0, OO, !0), pO.setUint16(2, qX.Cb.Failed, !0), KO
    }
    let Jv = Promise.resolve();
    async function cC(OO, KO) {
      let pO;
      try {
        pO = await (0, Pv.y)(OO)
      } catch (eO) {
        throw new iC.d("fetch", OO, {
          cause: eO
        })
      }
      const XO = Jv.then((() => async function(OO, KO) {
        const pO = new Blob([OO.slice()]);
        let XO = await createImageBitmap(pO, {
          premultiplyAlpha: "none",
          colorSpaceConversion: "none",
          imageOrientation: KO
        });
        const bK = 1024 / Math.max(XO.width, XO.height);
        if (bK < 1) {
          const OO = XO;
          try {
            XO = await createImageBitmap(OO, {
              resizeWidth: Math.max(1, Math.round(OO.width * bK)),
              resizeHeight: Math.max(1, Math.round(OO.height * bK)),
              resizeQuality: "high",
              premultiplyAlpha: "none",
              colorSpaceConversion: "none"
            })
          } finally {
            OO.close()
          }
        }
        return XO
      }(pO, KO)));
      let bK;
      Jv = XO.catch((() => {}));
      try {
        bK = await XO
      } catch (eO) {
        throw new iC.d("decode", OO, {
          cause: eO
        })
      }
      return {
        id: (0, iC.p)(bK),
        width: bK.width,
        height: bK.height
      }
    }
    var Bv = pO(2460),
      Zv = pO(32993);
    const Gv = Bv.g.length;

    function qC(OO) {
      const KO = [],
        pO = [];
      Bv.g.forEach(((XO, bK) => {
        var eO;
        const lO = null !== (eO = xC(OO[XO])) && void 0 !== eO ? eO : Zv.k[XO];
        "custom" === lO.type ? (pO.push({
          id: bK,
          kind: qX.Cb.KindCustom,
          set: KO.length,
          earth: null
        }), KO.push({
          urls: [lO.px, lO.py, lO.pz, lO.nx, lO.ny, lO.nz],
          orientation: "none"
        })) : pO.push({
          id: bK,
          kind: qX.Cb.KindEarth,
          set: 0,
          earth: lO
        })
      }));
      const XO = xC(OO.earth);
      "earth" === (null === XO || void 0 === XO ? void 0 : XO.type) && pO.push({
        id: Gv,
        kind: qX.Cb.KindEarth,
        set: 0,
        earth: XO
      });
      const bK = KO.length;
      KO.push({
        urls: Zv.d.map((OO => Zv.g + OO)),
        orientation: "none"
      }), KO.push({
        urls: [Zv.j],
        orientation: "flipY"
      }), KO.push({
        urls: [Zv.b],
        orientation: "flipY"
      });
      const eO = new Uint8Array(qX.Cb.SkyTableHeaderBytes + pO.length * qX.Cb.SkyTableEntryBytes),
        lO = new DataView(eO.buffer);
      return lO.setUint16(0, bK, !0), lO.setUint16(2, bK + 1, !0), lO.setUint16(4, bK + 2, !0), lO.setUint16(6, pO.length, !0), pO.forEach(((OO, KO) => {
        const pO = qX.Cb.SkyTableHeaderBytes + KO * qX.Cb.SkyTableEntryBytes;
        lO.setUint16(pO, OO.id, !0), lO.setUint8(pO + 2, OO.kind);
        const XO = pO + 4;
        OO.earth ? function(OO, KO, pO) {
          const XO = OO;
          let bK = 0,
            eO = 0;
          for (const [lO, vK] of nv) {
            const OO = XO[lO];
            "number" === typeof OO && Number.isFinite(OO) && (KO.setFloat32(pO + 4 * vK, OO, !0), bK |= 1 << vK)
          }
          for (const [lO, vK, CO] of Wv) {
            const OO = XO[lO];
            Array.isArray(OO) && 3 === OO.length && OO.every((OO => "number" === typeof OO && Number.isFinite(OO))) && (OO.forEach(((OO, XO) => {
              KO.setFloat32(pO + CO + 4 * XO, OO, !0)
            })), bK |= vK)
          }
          tC.forEach(((OO, eO) => {
            let [lO, vK] = OO;
            const CO = XO[lO];
            "number" === typeof CO && Number.isFinite(CO) && (KO.setFloat32(pO + qX.l.CameraOffsetAt + 4 * eO, CO, !0), bK |= vK)
          }));
          for (const [lO, vK] of kC) {
            const OO = XO[lO];
            null !== OO && void 0 !== OO && (bK |= vK, OO && (eO |= vK >>> 14))
          }
          KO.setUint32(pO + qX.l.PresentAt, bK, !0), KO.setUint8(pO + qX.l.FlagsAt, eO)
        }(OO.earth, lO, XO) : lO.setUint16(XO, OO.set, !0)
      })), {
        payload: eO,
        sets: KO
      }
    }

    function xC(OO) {
      if ("object" !== typeof OO || null === OO) return null;
      const KO = OO;
      if ("earth" === KO.type) return OO;
      return "custom" === KO.type && ["px", "py", "pz", "nx", "ny", "nz"].every((OO => {
        const pO = KO[OO];
        return "string" === typeof pO && pO.length > 0
      })) ? OO : null
    }
    const nv = [
        ["inclination", qX.l.Inclination],
        ["turbidity", qX.l.Turbidity],
        ["luminance", qX.l.Luminance],
        ["rayleigh", qX.l.Rayleigh],
        ["mieCoefficient", qX.l.MieCoefficient],
        ["mieDirectionalG", qX.l.MieDirectionalG],
        ["distance", qX.l.Distance],
        ["azimuth", qX.l.Azimuth]
      ],
      Wv = [
        ["sunPosition", qX.l.SunPosition, qX.l.SunPositionAt],
        ["up", qX.l.Up, qX.l.UpAt],
        ["vertexTint", qX.l.VertexTint, qX.l.VertexTintAt]
      ],
      tC = [
        ["xCameraOffset", qX.l.CameraOffsetX],
        ["yCameraOffset", qX.l.CameraOffsetY],
        ["zCameraOffset", qX.l.CameraOffsetZ]
      ],
      kC = [
        ["useSunPosition", qX.l.UseSunPosition],
        ["dithering", qX.l.Dithering],
        ["infiniteDistance", qX.l.InfiniteDistance]
      ];

    function Uv(OO, KO, pO) {
      const XO = new KC({
        writeCmd: OO,
        warn: KO,
        followPack: OC(pO, KO)
      });
      return XO.start(), XO
    }

    function OC(OO, KO) {
      return pO => {
        let XO = () => {};
        const bK = OO((OO => {
          XO(), XO = () => {}, null !== OO ? XO = OO.subscribe((OO => {
            pO(function(OO, KO, pO) {
              if ("object" !== typeof OO || null === OO) return null;
              const XO = OO.skyBoxes;
              if ("object" !== typeof XO || null === XO) return null;
              if ("player" === KO) return XO;
              return Object.fromEntries(Object.entries(XO).filter((OO => {
                let [KO, XO] = OO;
                return !! function(OO) {
                  if ("object" !== typeof OO || null === OO) return !1;
                  return "earth" === OO.type || Object.entries(OO).every((OO => {
                    let [KO, pO] = OO;
                    return "type" === KO || ("" === (XO = pO) || null !== function(OO) {
                      var KO, pO, XO;
                      return "string" !== typeof OO ? null : null !== (KO = null === (pO = pC.exec(OO)) || void 0 === pO || null === (XO = pO.groups) || void 0 === XO ? void 0 : XO.base64) && void 0 !== KO ? KO : null
                    }(XO));
                    var XO
                  }))
                }(XO) || (pO(`Ignoring texture pack skybox ${KO}, whose faces are not all data URLs`, null), !1)
              })))
            }(OO.pack, null === OO.gameSource ? "player" : "customGame", KO))
          })) : pO(null)
        }));
        return () => {
          bK(), XO()
        }
      }
    }
    class KC {
      constructor(OO) {
        var KO, pO, XO;
        this.host = OO, this.loader = void 0, this.wait = void 0, this.queue = [], this.written = null, this.stopFollowing = () => {}, this.YX = !1, this.wait = null !== (KO = OO.wait) && void 0 !== KO ? KO : (OO, KO) => {
          setTimeout(KO, OO)
        }, this.loader = new sv({
          loadImage: null !== (pO = OO.loadImage) && void 0 !== pO ? pO : cC,
          taO: null !== (XO = OO.taO) && void 0 !== XO ? XO : iC.r,
          sendReady: OO => {
            this.queue.push({
              kind: qX.Cb.SkyImagesReady,
              payload: OO
            })
          },
          onLoadFailed: (KO, pO, XO) => {
            OO.warn(`sky image set ${KO} (${pO}) didn't load: the last sky stays`, XO)
          },
          wait: this.wait
        })
      }
      start() {
        this.wait(rC.d, (() => {
          null === this.written && this.write({})
        })), this.stopFollowing = this.host.followPack((OO => {
          this.write(null !== OO && void 0 !== OO ? OO : {})
        }))
      }
      onEvent(OO) {
        this.loader.onEvent(OO)
      }
      drain() {
        if (0 === this.queue.length) return;
        let OO = 0;
        for (; OO < this.queue.length && this.host.writeCmd(this.queue[OO].kind, 0, this.queue[OO].payload);) OO++;
        OO > 0 && this.queue.splice(0, OO)
      }
      dispose() {
        this.YX = !0, this.stopFollowing(), this.queue = [], this.loader.dispose()
      }
      write(OO) {
        if (this.YX) return;
        const KO = qC(OO);
        var pO, XO;
        this.written && (pO = this.written, XO = KO, pO.payload.length === XO.payload.length && pO.payload.every(((OO, KO) => OO === XO.payload[KO])) && pO.sets.length === XO.sets.length && pO.sets.every(((OO, KO) => {
          const pO = XO.sets[KO];
          return OO.orientation === pO.orientation && OO.urls.length === pO.urls.length && OO.urls.every(((OO, KO) => OO === pO.urls[KO]))
        }))) || (this.written = KO, this.loader.reset(KO.sets), this.queue = this.queue.filter((OO => OO.kind !== qX.Cb.SkyImagesReady)), this.queue.push({
          kind: qX.Cb.SkyTable,
          payload: KO.payload
        }))
      }
    }
    const pC = /^data:[\w.+/-]*;base64,(?<base64>[A-Za-z0-9+/]*={0,2})$/;
    var XC = pO(2278),
      bh = pO(2325),
      eC = pO(138),
      lC = pO(168),
      vh = pO(2284),
      CC = pO(2293),
      hC = pO(219),
      DC = pO(226),
      MC = pO(2306),
      ah = pO(107),
      oC = pO(233),
      FC = pO(38886);
    class VC {
      constructor() {
        this.id = null, this.sentMs = null, this.roundTripMs = null, this.stopReplies = void 0, this.stopReplies = (0, sb.n)(zb.M, (OO => {
          this.onReply((0, me.d)(zb.M, OO), performance.now())
        }))
      }
      onFrame(OO, KO) {
        null === this.id ? this.id = OO : OO !== this.id && (this.id = OO, this.sentMs = document.hidden ? null : KO)
      }
      onVisibilityChange() {
        this.sentMs = null
      }
      onReply(OO, KO) {
        OO === this.id && null !== this.sentMs && (this.roundTripMs = Math.round(KO - this.sentMs), this.sentMs = null)
      }
      take() {
        const OO = this.roundTripMs;
        return this.roundTripMs = null, OO
      }
      stop() {
        this.stopReplies()
      }
    }
    class LC {
      constructor() {
        this.sampled = 0, this.timed = 0, this.frameUs = 0, this.primed = !1, this.windowTimed = 0, this.windowUs = 0
      }
      onFrame(OO, KO, pO, XO) {
        const bK = OO - this.sampled >>> 0,
          eO = KO - this.timed >>> 0,
          lO = pO - this.frameUs >>> 0,
          vK = this.primed;
        return this.sampled = OO, this.timed = KO, this.frameUs = pO, this.primed = !0, !(!vK || bK > 64 || eO > 64) && (XO && lO <= 1e6 * eO && (this.windowTimed += eO, this.windowUs += lO), XO && bK > 0)
      }
      reset() {}
      snapshotAndReset() {
        const OO = this.windowTimed > 0 ? this.windowUs / this.windowTimed / 1e3 : null;
        return this.windowTimed = 0, this.windowUs = 0, {
          passMs: OO,
          submitToDoneMs: null
        }
      }
    }
    const QC = {
      pacedShare: null,
      switchesPerHour: null,
      lagP50Ms: null,
      lagP90Ms: null,
      joinLagP90Ms: null
    };
    class zh {
      constructor() {
        this.samples = new Float64Array(4096), this.count = 0
      }
      add(OO, KO) {
        const pO = Math.min(4096, this.count + KO);
        this.samples.fill(OO, this.count, pO), this.count = pO
      }
      clear() {
        this.count = 0
      }
      take(OO) {
        const KO = this.count;
        if (this.count = 0, KO < 30) return null;
        const pO = this.samples.subarray(0, KO).sort();
        return OO.map((OO => pO[Math.min(KO - 1, Math.floor(OO * KO))]))
      }
    }
    class AC {
      constructor() {
        this.word = 0, this.lagUs = 0, this.primed = !1, this.lastDrawnMs = -1, this.tieredMs = 0, this.pacedMs = 0, this.switches = 0, this.lags = new zh, this.inJoin = !1, this.rose = !1, this.joinLags = new zh, this.joinLagP90Ms = null
      }
      onFrame(OO, KO, pO, XO, bK) {
        const eO = OO.headerWord(qX.w.Pacing),
          lO = OO.headerWord(qX.w.PacingLagUs),
          vK = (eO >>> qX.E.LagsShift) - (this.word >>> qX.E.LagsShift) & qX.E.CountMask,
          CO = (eO >>> qX.E.SwitchesShift) - (this.word >>> qX.E.SwitchesShift) & qX.E.CountMask,
          hO = vK > 0 ? (lO - this.lagUs >>> 0) / vK / 1e3 : 0,
          DO = this.primed && vK <= 64 && CO <= 2 && hO <= 6e4;
        if (this.rose = 0 !== (eO & ~this.word & qX.E.Joining), this.word = eO, this.lagUs = lO, this.primed = !0, 0 !== (eO & qX.E.Tiered)) {
          if (0 !== (eO & qX.E.Joining)) this.rose && (this.inJoin = !0, this.joinLags.clear()), this.inJoin && DO && XO && vK > 0 && this.joinLags.add(hO, vK);
          else if (this.inJoin) {
            var MO, aK;
            this.inJoin = !1, this.joinLagP90Ms = null !== (MO = null === (aK = this.joinLags.take([.9])) || void 0 === aK ? void 0 : aK[0]) && void 0 !== MO ? MO : null
          }
          if (bK) {
            if (DO && (this.switches += CO, vK > 0 && this.lags.add(hO, vK)), pO) {
              if (this.lastDrawnMs >= 0 && KO - this.lastDrawnMs <= 250) {
                const OO = KO - this.lastDrawnMs;
                this.tieredMs += OO, (eO & qX.E.AheadMask) > 0 && (this.pacedMs += OO)
              }
              this.lastDrawnMs = KO
            }
          } else this.lastDrawnMs = -1
        } else this.lastDrawnMs = -1
      }
      onJoin() {
        this.takeWindow(), this.rose || (this.inJoin = !1, this.joinLags.clear()), this.lastDrawnMs = -1
      }
      snapshotAndReset(OO) {
        const KO = this.takeWindow(),
          pO = this.joinLagP90Ms;
        return this.joinLagP90Ms = null, OO ? {
          ...KO,
          joinLagP90Ms: pO
        } : {
          ...QC,
          joinLagP90Ms: pO
        }
      }
      unsent(OO) {
        this.joinLagP90Ms ??= OO.joinLagP90Ms
      }
      takeWindow() {
        var OO, KO;
        const pO = this.tieredMs >= 2e3,
          XO = this.lags.take([.5, .9]),
          bK = {
            pacedShare: pO ? this.pacedMs / this.tieredMs : null,
            switchesPerHour: pO ? 36e5 * this.switches / this.tieredMs : null,
            lagP50Ms: null !== (OO = null === XO || void 0 === XO ? void 0 : XO[0]) && void 0 !== OO ? OO : null,
            lagP90Ms: null !== (KO = null === XO || void 0 === XO ? void 0 : XO[1]) && void 0 !== KO ? KO : null
          };
        return this.tieredMs = 0, this.pacedMs = 0, this.switches = 0, bK
      }
    }
    var fC = pO(8298),
      dC = pO(39059);
    const TC = {
      none: !0,
      not_requested: !1,
      webgl_holdback: !1,
      off_after_loss: !1,
      old_intel_driver: !1,
      intel_gen9: !1,
      gpu_class_webgl: !1,
      no_webgpu_api: !1,
      no_adapter: !0,
      software_adapter: !0,
      adapter_error: !0,
      load_failed: !0,
      start_no_adapter: !0,
      device_failed: !0,
      start_failed: !0,
      _unloaded: null
    };

    function NC(OO) {
      return new IC(OO)
    }
    class IC {
      constructor(OO) {
        this.shell = OO, this.tracker = new CC.e, this.gpu = new LC, this.pacing = new AC, this.timers = [], this.inGameAtLastFlush = !1, this.hasFlushedSinceConnect = !1, this.sendsDropped = 0, this.pendingLightFailures = 0, this.unsentPage = null, this.game = null, this.fpsSpanStartMs = -1, this.fpsFrames = 0, this.fpsOverTime = null, this.firstSpanFps = null, this.initialFps = null, this.ping = new VC, this.pacedCpuMs = 0, this.onVisibility = () => {
          this.tracker.onVisibilityChange(), this.ping.onVisibilityChange(), !document.hidden && this.fpsSpanStartMs >= 0 && (this.fpsFrames = 0, this.fpsSpanStartMs = performance.now())
        }, (0, fC.b)(OO.backend, OO.canvas, OO.adapterVendor), this.tracker.start((() => !OO.inGame()), this.gpu, "wasm"), document.addEventListener("visibilitychange", this.onVisibility), this.timers.push(setInterval((() => {
          this.flush(), this.fpsOverTime = null, this.initialFps = null
        }), 1e4), setInterval((() => {
          this.followGame() && (this.hasFlushedSinceConnect || (this.flush(), this.hasFlushedSinceConnect = !0))
        }), 250))
      }
      animationFrame(OO) {
        this.tracker.onAnimationFrame(OO)
      }
      frameRan(OO, KO, pO, XO) {
        this.ping.onFrame(OO.headerWord(qX.w.PingSent), pO);
        const bK = this.tracker;
        this.pacing.onFrame(OO, KO, "drawn" === XO, !document.hidden, bK.isSampling());
        const eO = OO.headerWord(qX.w.TickUs) / 1e3 + (0, XX.J)();
        bK.xV(eO);
        const lO = Math.max(0, pO - KO - eO);
        if ("drawn" !== XO) return void("paced" === XO && (this.pacedCpuMs += lO));
        this.followGame(), bK.onFrameStart(KO);
        this.gpu.onFrame(OO.headerWord(qX.w.GpuSampled), OO.headerWord(qX.w.GpuTimed), OO.headerWord(qX.w.GpuFrameUs), bK.isSampling()) && bK.onGpuSampleStarted(), bK.onFrameCpu(lO + this.pacedCpuMs), this.pacedCpuMs = 0, this.countFpsFrame(KO)
      }
      stop() {
        for (const OO of this.timers) clearInterval(OO);
        this.timers.length = 0, document.removeEventListener("visibilitychange", this.onVisibility), this.ping.stop()
      }
      followGame() {
        const OO = this.shell.joinedGame();
        return OO !== this.game && (this.game = OO, this.tracker.snapshotAndReset(), this.pacing.onJoin(), this.hasFlushedSinceConnect = !1, this.inGameAtLastFlush = !1, this.fpsSpanStartMs = -1, this.fpsFrames = 0, this.pacedCpuMs = 0, this.firstSpanFps = null, this.fpsOverTime = null, this.initialFps = null), null !== OO
      }
      countFpsFrame(OO) {
        if (this.fpsSpanStartMs < 0) {
          if (!this.shell.inGame()) return;
          this.fpsSpanStartMs = OO
        }
        this.fpsFrames++;
        const KO = OO - this.fpsSpanStartMs;
        if (!(KO < 15e3)) {
          if (!document.hidden) {
            const OO = 1e3 * this.fpsFrames / KO;
            this.firstSpanFps ??= OO, this.initialFps = this.firstSpanFps, this.fpsOverTime = OO
          }
          this.fpsFrames = 0, this.fpsSpanStartMs = OO
        }
      }
      flush() {
        const OO = this.followGame(),
          {
            cpuFrameMs: KO,
            refreshHz: pO,
            cpuBottleneck: bK,
            frameIntervalCv: eO,
            ...lO
          } = this.tracker.snapshotAndReset(),
          vK = this.shell.inGame(),
          CO = vK && this.inGameAtLastFlush,
          hO = CO ? lO : vh.h,
          DO = this.pacing.snapshotAndReset(CO);
        if (this.inGameAtLastFlush = vK, this.pendingLightFailures += this.shell.takeFailedMeshJobs(), !OO) return void this.pacing.unsent(DO);
        const MO = performance.now(),
          oO = (0, MC.t)((0, MC.q)(MO), this.unsentPage),
          VO = function(OO, KO, pO, bK, eO, lO, vK, CO) {
            var hO, DO, MO;
            const aK = {},
              {
                canvas: oO
              } = OO;
            for (const FO of (0, bh.e)()) {
              const VO = FO.name;
              let LO;
              if ((0, eC.i)(VO)) LO = (0, MC.d)(VO);
              else if ((0, MC.l)(VO)) LO = CO[VO];
              else switch (VO) {
                case "fps":
                  LO = bK;
                  break;
                case "rA":
                  LO = eO;
                  break;
                case "sA":
                  LO = (0, dC.d)().n;
                  break;
                case "HA":
                  LO = Math.max(oO.width, oO.height);
                  break;
                case "JA":
                  LO = Math.min(oO.width, oO.height);
                  break;
                case "aT":
                  LO = navigator.hardwareConcurrency || null;
                  break;
                case "zD":
                  LO = (0, Zb.getWebGpuSupported)();
                  break;
                case "bD":
                  LO = null === OO.fallbackReason ? null : TC[OO.fallbackReason];
                  break;
                case "jT":
                  LO = KO.cpuFrameMs;
                  break;
                case "pT":
                  LO = KO.refreshHz;
                  break;
                case "XT":
                  LO = KO.cpuBottleneck;
                  break;
                case "eT":
                  LO = KO.frameIntervalCv;
                  break;
                case "mD":
                  LO = KO.frameMs;
                  break;
                case "lT":
                  LO = KO.tickMs;
                  break;
                case "vN":
                  LO = KO.mainBusyShare;
                  break;
                case "aN":
                  LO = KO.mainProbeDelayMs;
                  break;
                case "zN":
                  LO = KO.longAnimationFramesPerMin;
                  break;
                case "yN":
                  LO = KO.longAnimationFrameTimeShare;
                  break;
                case "wT":
                  LO = KO.longAnimationFrameScriptShare;
                  break;
                case "mN":
                  LO = KO.gpuPassMs;
                  break;
                case "qN":
                  LO = KO.gpuSubmitToDoneMs;
                  break;
                case "kN":
                  LO = pO.pacedShare;
                  break;
                case "pN":
                  LO = pO.switchesPerHour;
                  break;
                case "XN":
                  LO = pO.lagP50Ms;
                  break;
                case "bI":
                  LO = pO.lagP90Ms;
                  break;
                case "vI":
                  LO = pO.joinLagP90Ms;
                  break;
                case "eb":
                  LO = (0, XC.g)(lO);
                  break;
                case "hA":
                  LO = vK;
                  break;
                case "hN":
                case "Gb":
                case "oN":
                case "yI":
                case "mI":
                case "ZN":
                case "MI":
                case "xI":
                case "ND":
                case "pI":
                case "vy":
                case "jy":
                case "HI":
                case "JI":
                case "ZI":
                  LO = null;
                  break;
                case "lD":
                  LO = (0, Zb.getPlatformType)();
                  break;
                case "Fy":
                  LO = (0, Zb.getGpuVendor)();
                  break;
                case "eD":
                  LO = FC.c[OO.backend];
                  break;
                case "bM":
                  LO = (0, ah.c)();
                  break;
                case "fD":
                  LO = (0, Zb.getOperatingSystem)();
                  break;
                case "Qy":
                  LO = (0, Zb.getTrafficSource)();
                  break;
                case "dD":
                  LO = null !== (hO = XO.d.get("gameEntrySource")) && void 0 !== hO ? hO : lC.e;
                  break;
                case "sL":
                  LO = KO.frameLimiter;
                  break;
                case "eC":
                  LO = (0, hC.f)();
                  break;
                case "jD":
                  LO = null !== (DO = (0, DC.d)()) && void 0 !== DO ? DO : lC.e;
                  break;
                case "ZD":
                  LO = (0, hC.c)(oO.width, oO.height);
                  break;
                case "Ay":
                  LO = (0, bh.i)(-(new Date).getTimezoneOffset());
                  break;
                case "lC":
                  LO = null !== (MO = OO.fallbackReason) && void 0 !== MO ? MO : lC.e;
                  break;
                case "hV":
                  LO = "ready";
                  break;
                case "Uy":
                  LO = (0, Zb.getSoftwareRenderer)();
                  break;
                case "Py":
                  LO = OO.shaderPackRuns() ? "true" : "false";
                  break;
                case "pD":
                  LO = oC.q;
                  break;
                case "Iy":
                case "Sy":
                case "Gy":
                case "Wy":
                case "HX":
                  LO = lC.e;
                  break;
                default:
                  throw new Error(`Unhandled field name: ${VO}`)
              }
              if (void 0 === LO) throw new Error(`Metric ${VO} has no value`);
              aK[VO] = LO
            }
            return aK
          }(this.shell, {
            cpuFrameMs: KO,
            refreshHz: pO,
            cpuBottleneck: bK,
            frameIntervalCv: eO,
            ...hO
          }, DO, this.fpsOverTime, this.initialFps, this.pendingLightFailures, this.ping.take(), oO);
        if (! function(OO, KO, pO) {
            return (0, ZK.c)(), OO(FO.m.Send, KO, pO)
          }(this.shell.writeCmd, aK.gd, function(OO) {
            const KO = (0, mK.e)((0, xp.d)(OO)),
              pO = new Uint8Array(FO.Td.BYTES + KO.length);
            return new DataView(pO.buffer).setUint16(0, xp.b.AnalyticsUpdate, !0), pO.set(KO, FO.Td.BYTES), pO
          }(VO))) return this.unsentPage = oO, this.pacing.unsent(DO), void(0 === this.sendsDropped++ && console.warn("[wasm-client] an analytics update found the cmd ring full: dropped"));
        this.unsentPage = null, this.pendingLightFailures -= Math.min(this.pendingLightFailures, XC.d), (0, MC.m)(this.fpsOverTime, this.initialFps, VO, MO)
      }
    }
    var yh = pO(37817);

    function gh(OO, KO, pO) {
      const XO = new Map;
      return (0, yh.c)(((OO, pO, XO) => KO.yl(OO, pO, XO)), ((KO, pO, bK) => {
        const eO = `${KO},${pO},${bK}`;
        return XO.has(eO) || XO.set(eO, (0, HK.b)(OO, KO, pO, bK)), XO.get(eO)
      }), pO)
    }
    var uC = pO(37825),
      EC = pO(38798);

    function jh(OO) {
      const KO = null !== OO && 0 !== (FO.t.playerFlags(OO.api.apiView, 0) & FO.Ad.CursorAim);
      KO !== (0, EC.l)() && (0, EC.D)(KO, null !== OO)
    }

    function YC(OO) {
      return (0, QX.d)(zb.F, OO)
    }
    const wC = new eO.f((OO => pO(40636)(`./${OO}/${OO}Client`)));
    let ih = null,
      rh = null;
    async function PC(OO) {
      ih ??= pO.e(26).then((() => pO(37495))).then((OO => {
        rh = OO.createDefaultClientPlugins
      }), (OO => {
        throw ih = null, OO
      })), await Promise.all([wC.load(OO), ih])
    }

    function mh(OO) {
      OO.load(new mp(JX, new ZX))
    }
    let sC = !1;
    const HC = new WeakMap;

    function RC(OO) {
      try {
        OO()
      } catch (KO) {
        console.error("[bloxd-wasm-client] a session-end step failed", KO)
      }
    }

    function SC(OO, KO) {
      ! function() {
        var OO, KO;
        RX.b.volume();
        const pO = RX.b;
        null === (OO = pO._autoResume) || void 0 === OO || OO.call(pO), null === (KO = pO._autoSuspend) || void 0 === KO || KO.call(pO)
      }(), KO.audio.prepare();
      const pO = new fO(KO.core, KO.memory, KO.audio);
      let eO;
      try {
        eO = new ae(pO, KO.options)
      } catch (aK) {
        return OO.crash(Fb.A, aK), null
      }(0, CO.e)(ob(pO, eO));
      const DO = new fv({
        running: OO,
        api: pO,
        core: KO.core,
        memory: KO.memory,
        staleOr: KO.staleOr,
        reportFault: KO.reportReplayFault,
        options: KO.options,
        sessionInfo: KO.sessionInfo,
        replayShaderPack: KO.replayShaderPack
      });
      (0, XX.y)();
      const MO = new rb({
        api: pO,
        tables: eO,
        sessionInfo: KO.sessionInfo,
        gameFactory: OO => wC.loadedFactory(OO),
        defaultPlugins: (OO, KO, pO, XO) => {
          if (null === rh) throw new Error("The default plugins started before they loaded");
          return rh(OO, KO, pO, XO)
        },
        serverOptions: KO.options,
        onNetEvent: OO => {
          DO.netEvent(OO), KO.onNetEvent(OO)
        },
        setLocalOptions: OO => {
          Nv({
            changes: OO,
            reset: !1
          })
        },
        playSound: (OO, pO, XO, bK, eO, lO, vK) => KO.audio.playGame(OO, pO, XO, bK, eO, lO, vK),
        onSessionEnd: () => {
          RC(bK.k), RC(kb), RC((() => {
            XO.d.set({
              openInGameMenuName: null
            })
          })), RC((() => {
            KO.audio.cancelPreload()
          }))
        },
        beforeWrite: KO.beforeWrite,
        beforeOp: KO.beforeOp,
        cameraScreen: tb,
        showCameraFacing: UX,
        onEventOverflow: KO.onEventOverflow,
        screenBandY: vK.j,
        replayEntities: DO.entityHooks,
        hasPackModel: KO.hasPackModel
      });
      return MO.attach(OO), HC.set(MO, DO), HX(MO.items, KO.audio),
        function(OO) {
          OO.setClientFreeCameraGrant("isDev", !1);
          const KO = KO => {
            OO.setClientFreeCameraGrant("hasDeveloperRank", KO.playerHasRank("developer"))
          };
          (0, lO.j)("userContextUpdated", KO)
        }(MO), sC || (sC = !0, (0, lO.j)("appManagerUpdated|openInGameMenuName", (OO => {
          !OO && (0, hO.i)().includes("InGameMenu") && (0, hO.j)("InGameMenu")
        }))), MO
    }

    function JC(OO) {
      try {
        OO.closeGame()
      } finally {
        var KO;
        null === (KO = HC.get(OO)) || void 0 === KO || KO.stop(), HC.delete(OO)
      }
    }
  },
  8461: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => eO
    });
    var XO = pO(8411);
    const bK = "Air",
      eO = Object.freeze(new XO.f(bK, 0, "", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);