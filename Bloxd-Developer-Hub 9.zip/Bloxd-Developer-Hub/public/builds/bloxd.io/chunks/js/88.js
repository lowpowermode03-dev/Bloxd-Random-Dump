export const id = 88;
export const ids = [88];
export const modules = {
  4035: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => aK
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(933),
      lO = pO(1180),
      vK = pO(2748),
      CO = pO(142),
      hO = pO(2780),
      DO = pO(2769),
      MO = pO(976);

    function aK(OO) {
      let {
        game: KO
      } = OO;
      const pO = (0, CO.o)() ? "large" : "small",
        XO = (0, hO.f)(KO, pO),
        aK = (0, vK.c)(XO),
        oO = void 0 !== aK.blurhash;
      return (0, MO.jsxs)("div", {
        className: "SchematicImageContainer",
        children: [aK.isLoading && !oO && (0, MO.jsx)(lO.e, {
          loaderType: "Secondary"
        }), !aK.failed && (null !== aK.src || oO) && (0, MO.jsx)("div", {
          className: bK()("SchematicImage", DO.m, {
            SchematicImageFadeIn: aK.fadeIn && !oO
          }),
          style: (0, DO.i)(aK),
          children: (0, MO.jsx)(DO.e, {
            image: aK
          })
        }), aK.failed && (0, MO.jsx)("div", {
          className: "SchematicImageError",
          children: (0, MO.jsx)(eO.d, {
            name: "face-dizzy"
          })
        })]
      })
    }
  },
  4027: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => yK
    });
    pO(4031);
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(243),
      vK = pO(892),
      CO = pO(1077),
      hO = pO(1051),
      DO = pO(1004),
      MO = pO(1329),
      aK = pO(4035),
      oO = pO(1271),
      FO = pO(4041),
      VO = pO(1180),
      LO = pO(1344),
      QO = pO(3815),
      zK = pO(933),
      AO = pO(881),
      fO = pO(2020),
      dO = pO(4048),
      TO = pO(1374),
      NO = pO(976);

    function IO() {
      const {
        t: OO
      } = (0, hO.D)(), KO = (0, LO.useNavigatePreserveSearch)(), pO = (0, fO.m)(), bK = (0, XO.useMemo)((() => [...AO.d].sort(((KO, XO) => {
        var bK, eO;
        const lO = (null !== (bK = (0, fO.b)(XO, pO)) && void 0 !== bK ? bK : 0) - (null !== (eO = (0, fO.b)(KO, pO)) && void 0 !== eO ? eO : 0);
        return 0 !== lO ? lO : (0, TO.m)(KO, OO).localeCompare((0, TO.m)(XO, OO))
      }))), [pO, OO]);
      return (0, NO.jsxs)(NO.Fragment, {
        children: [(0, NO.jsx)("div", {
          className: "StudioPageHeader",
          children: (0, NO.jsx)("h1", {
            className: "StudioPageTitle",
            children: OO("studio:firstPartyGames")
          })
        }), (0, NO.jsx)(FO.c, {
          className: "StudioTable AnimFadeIn",
          columns: [{
            key: "game",
            header: OO("general:game")
          }, {
            key: "ccu",
            header: OO("studio:metricCcu")
          }],
          rows: bK,
          getRowKey: OO => OO,
          renderRow: XO => {
            var bK;
            return (0, NO.jsxs)("tr", {
              onClick: () => {
                KO((0, TO.q)((0, vK.c)(XO, !0)))
              },
              children: [(0, NO.jsx)("td", {
                children: (0, NO.jsx)(dO.h, {
                  thumbnail: (0, NO.jsx)(dO.e, {
                    game: XO
                  }),
                  name: (0, TO.m)(XO, OO)
                })
              }), (0, NO.jsx)("td", {
                children: (0, CO.L)(null !== (bK = (0, fO.b)(XO, pO)) && void 0 !== bK ? bK : 0)
              })]
            })
          }
        })]
      })
    }

    function yK() {
      const {
        t: OO
      } = (0, hO.D)(), KO = (0, LO.useNavigatePreserveSearch)(), {
        userContext: pO,
        isUserContextUpdating: bK
      } = (0, DO.d)(), {
        isCreating: AO,
        create: fO
      } = (0, QO.e)(), [yK, gK] = (0, XO.useState)(null), [uO, EO] = (0, XO.useState)(null), [jK, YO] = (0, XO.useState)(!1);
      (0, XO.useEffect)((() => {
        bK || (YO(!1), MO.c.getPublishedGamePreviews(pO, {
          searchQuery: null,
          pageNumber: 1,
          pageSize: 50,
          onlyFavouriteGames: !1,
          onlyOwnedGames: !0,
          onlyApprovedGames: !1,
          schematicIdsToExclude: [],
          gameCategories: [],
          upAndComing: !1
        }).then((OO => {
          gK({
            ...OO,
            results: (0, lO.Y)(OO.results)
          })
        })).catch((OO => {
          console.error("Failed to get owned published games", OO), YO(!0)
        })), MO.c.getOwnedUnpublishedGames(pO).then((OO => {
          EO(OO)
        })).catch((OO => {
          console.error("Failed to get owned unpublished games", OO), YO(!0)
        })))
      }), [bK, pO]);
      const wO = null !== yK && null !== uO ? [...yK.results, ...uO] : [],
        iK = !jK && (null === yK || null === uO),
        rK = !iK && !jK && 0 === wO.length,
        PO = !bK && pO.playerHasRank("developer");
      return (0, NO.jsxs)("div", {
        className: "StudioPage StudioGameList",
        children: [(0, NO.jsxs)("div", {
          className: "StudioPageHeader",
          children: [(0, NO.jsx)("h1", {
            className: "StudioPageTitle",
            children: OO("studio:myGames")
          }), (0, NO.jsxs)(oO.m, {
            onClick: fO,
            loading: AO,
            children: [(0, NO.jsx)(zK.d, {
              name: "plus"
            }), " ", OO("homePage:createCustomGame")]
          })]
        }), iK && (0, NO.jsx)("div", {
          className: "StudioPageLoader AnimFadeIn",
          children: (0, NO.jsx)(VO.e, {})
        }), jK && (0, NO.jsx)("div", {
          className: "StudioPageMessage AnimFadeIn",
          children: OO("studio:failedToLoadGames")
        }), rK && (0, NO.jsx)("div", {
          className: "StudioPageMessage AnimFadeIn",
          children: OO("studio:noGamesYet")
        }), !iK && !jK && !rK && (0, NO.jsx)(FO.c, {
          className: "StudioTable AnimFadeIn",
          columns: [{
            key: "game",
            header: OO("general:game")
          }, {
            key: "status",
            header: OO("general:status")
          }, {
            key: "ccu",
            header: OO("studio:metricCcu")
          }, {
            key: "favourites",
            header: OO("general:favourites")
          }],
          rows: wO,
          getRowKey: OO => OO.schematicId,
          renderRow: pO => (0, NO.jsxs)("tr", {
            onClick: () => {
              var OO;
              OO = pO.schematicId, KO((0, TO.q)((0, vK.b)(OO)))
            },
            children: [(0, NO.jsx)("td", {
              children: (0, NO.jsx)(dO.h, {
                thumbnail: (0, NO.jsx)(aK.b, {
                  game: pO
                }),
                name: pO.name
              })
            }), (0, NO.jsx)("td", {
              children: (0, NO.jsx)("span", {
                className: eO()("StudioGameListStatusChip", {
                  StudioGameListStatusChipPublished: pO.gamePublished
                }),
                children: pO.gamePublished ? OO("general:published") : OO("general:draft")
              })
            }), (0, NO.jsx)("td", {
              children: (0, CO.L)(pO.ccu)
            }), (0, NO.jsx)("td", {
              children: (0, CO.L)(pO.favourites)
            })]
          })
        }), PO && (0, NO.jsx)(IO, {})]
      })
    }
  },
  4048: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      h: () => eO
    });
    var XO = pO(1374),
      bK = pO(976);

    function eO(OO) {
      let {
        thumbnail: KO,
        name: pO
      } = OO;
      return (0, bK.jsxs)("div", {
        className: "StudioTableGameCell",
        children: [(0, bK.jsx)("div", {
          className: "StudioTableThumbnail",
          children: KO
        }), (0, bK.jsx)("span", {
          className: "StudioTableGameName",
          children: pO
        })]
      })
    }

    function lO(OO) {
      let {
        game: KO
      } = OO;
      return (0, bK.jsx)("img", {
        className: "StudioTableThumbnailImage",
        src: (0, XO.i)(KO),
        alt: ""
      })
    }
  },
  4041: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(976);

    function vK(OO) {
      let {
        columns: KO,
        rows: pO,
        getRowKey: bK,
        renderRow: vK,
        className: CO
      } = OO;
      return (0, lO.jsxs)("table", {
        className: eO()("Table", CO),
        children: [(0, lO.jsx)("thead", {
          children: (0, lO.jsx)("tr", {
            children: KO.map((OO => (0, lO.jsx)("th", {
              children: OO.header
            }, OO.key)))
          })
        }), (0, lO.jsx)("tbody", {
          children: pO.map((OO => (0, lO.jsx)(XO.Fragment, {
            children: vK(OO)
          }, bK(OO))))
        })]
      })
    }
  },
  4031: () => {}
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);