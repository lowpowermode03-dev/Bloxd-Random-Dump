export const id = 243;
export const ids = [243];
export const modules = {
  38391: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    class XO {
      constructor(OO, KO, pO) {
        this.bu = OO, this.bv = KO, this.distance = pO, this.faceId = 0, this.subMeshId = 0, this._internalSubMeshId = 0
      }
    }
  },
  38404: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(35641),
      bK = pO(35632),
      eO = pO(35639);
    class lO {
      constructor(OO, KO, pO) {
        this.vectors = (0, XO.d)(8, bK.o.Zero), this.center = bK.o.Zero(), this.centerWorld = bK.o.Zero(), this.extendSize = bK.o.Zero(), this.extendSizeWorld = bK.o.Zero(), this.directions = (0, XO.d)(3, bK.o.Zero), this.vectorsWorld = (0, XO.d)(8, bK.o.Zero), this.minimumWorld = bK.o.Zero(), this.maximumWorld = bK.o.Zero(), this.minimum = bK.o.Zero(), this.maximum = bK.o.Zero(), this._drawWrapperFront = null, this._drawWrapperBack = null, this.reConstruct(OO, KO, pO)
      }
      reConstruct(OO, KO, pO) {
        const XO = OO.x,
          eO = OO.y,
          lO = OO.z,
          vK = KO.x,
          CO = KO.y,
          hO = KO.z,
          DO = this.vectors;
        this.minimum.rvO(XO, eO, lO), this.maximum.rvO(vK, CO, hO), DO[0].rvO(XO, eO, lO), DO[1].rvO(vK, CO, hO), DO[2].rvO(vK, eO, lO), DO[3].rvO(XO, CO, lO), DO[4].rvO(XO, eO, hO), DO[5].rvO(vK, CO, lO), DO[6].rvO(XO, CO, hO), DO[7].rvO(vK, eO, hO), KO.addToRef(OO, this.center).scaleInPlace(.5), KO.subtractToRef(OO, this.extendSize).scaleInPlace(.5), this._worldMatrix = pO || bK.c.IdentityReadOnly, this._update(this._worldMatrix)
      }
      scale(OO) {
        const KO = lO._TmpVector3,
          pO = this.maximum.subtractToRef(this.minimum, KO[0]),
          XO = pO.length();
        pO.normalizeFromLength(XO);
        const bK = XO * OO,
          eO = pO.scaleInPlace(.5 * bK),
          vK = this.center.subtractToRef(eO, KO[1]),
          CO = this.center.addToRef(eO, KO[2]);
        return this.reConstruct(vK, CO, this._worldMatrix), this
      }
      getWorldMatrix() {
        return this._worldMatrix
      }
      _update(OO) {
        const KO = this.minimumWorld,
          pO = this.maximumWorld,
          XO = this.directions,
          eO = this.vectorsWorld,
          lO = this.vectors;
        if (OO.isIdentity()) {
          KO.NhO(this.minimum), pO.NhO(this.maximum);
          for (let OO = 0; OO < 8; ++OO) eO[OO].NhO(lO[OO]);
          this.extendSizeWorld.NhO(this.extendSize), this.centerWorld.NhO(this.center)
        } else {
          KO.plO(Number.MAX_VALUE), pO.plO(-Number.MAX_VALUE);
          for (let XO = 0; XO < 8; ++XO) {
            const vK = eO[XO];
            bK.o.TransformCoordinatesToRef(lO[XO], OO, vK), KO.minimizeInPlace(vK), pO.maximizeInPlace(vK)
          }
          pO.subtractToRef(KO, this.extendSizeWorld).scaleInPlace(.5), pO.addToRef(KO, this.centerWorld).scaleInPlace(.5)
        }
        bK.o.FromArrayToRef(OO.m, 0, XO[0]), bK.o.FromArrayToRef(OO.m, 4, XO[1]), bK.o.FromArrayToRef(OO.m, 8, XO[2]), this._worldMatrix = OO
      }
      isInFrustum(OO) {
        return lO.IsInFrustum(this.vectorsWorld, OO)
      }
      isCompletelyInFrustum(OO) {
        return lO.IsCompletelyInFrustum(this.vectorsWorld, OO)
      }
      intersectsPoint(OO) {
        const KO = this.minimumWorld,
          pO = this.maximumWorld,
          XO = KO.x,
          bK = KO.y,
          lO = KO.z,
          vK = pO.x,
          CO = pO.y,
          hO = pO.z,
          DO = OO.x,
          MO = OO.y,
          aK = OO.z,
          oO = -eO.c;
        return !(vK - DO < oO || oO > DO - XO) && (!(CO - MO < oO || oO > MO - bK) && !(hO - aK < oO || oO > aK - lO))
      }
      intersectsSphere(OO) {
        return lO.IntersectsSphere(this.minimumWorld, this.maximumWorld, OO.centerWorld, OO.radiusWorld)
      }
      intersectsMinMax(OO, KO) {
        const pO = this.minimumWorld,
          XO = this.maximumWorld,
          bK = pO.x,
          eO = pO.y,
          lO = pO.z,
          vK = XO.x,
          CO = XO.y,
          hO = XO.z,
          DO = OO.x,
          MO = OO.y,
          aK = OO.z,
          oO = KO.x,
          FO = KO.y,
          VO = KO.z;
        return !(vK < DO || bK > oO) && (!(CO < MO || eO > FO) && !(hO < aK || lO > VO))
      }
      dispose() {
        this._drawWrapperFront?.dispose(), this._drawWrapperBack?.dispose()
      }
      static Intersects(OO, KO) {
        return OO.intersectsMinMax(KO.minimumWorld, KO.maximumWorld)
      }
      static IntersectsSphere(OO, KO, pO, XO) {
        const eO = lO._TmpVector3[0];
        bK.o.ClampToRef(pO, OO, KO, eO);
        return bK.o.DistanceSquared(pO, eO) <= XO * XO
      }
      static IsCompletelyInFrustum(OO, KO) {
        for (let pO = 0; pO < 6; ++pO) {
          const XO = KO[pO];
          for (let KO = 0; KO < 8; ++KO)
            if (XO.dotCoordinate(OO[KO]) < 0) return !1
        }
        return !0
      }
      static IsInFrustum(OO, KO) {
        for (let pO = 0; pO < 6; ++pO) {
          let XO = !0;
          const bK = KO[pO];
          for (let KO = 0; KO < 8; ++KO)
            if (bK.dotCoordinate(OO[KO]) >= 0) {
              XO = !1;
              break
            } if (XO) return !1
        }
        return !0
      }
    }
    lO._TmpVector3 = (0, XO.d)(3, bK.o.Zero)
  },
  38400: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => MO
    });
    var XO = pO(35641),
      bK = pO(35632),
      eO = pO(38404);
    class lO {
      constructor(OO, KO, pO) {
        this.center = bK.o.Zero(), this.centerWorld = bK.o.Zero(), this.minimum = bK.o.Zero(), this.maximum = bK.o.Zero(), this.reConstruct(OO, KO, pO)
      }
      reConstruct(OO, KO, pO) {
        this.minimum.NhO(OO), this.maximum.NhO(KO);
        const XO = bK.o.Distance(OO, KO);
        KO.addToRef(OO, this.center).scaleInPlace(.5), this.radius = .5 * XO, this._update(pO || bK.c.IdentityReadOnly)
      }
      scale(OO) {
        const KO = lO._TmpVector3,
          pO = this.maximum.subtractToRef(this.minimum, KO[0]),
          XO = pO.length();
        pO.normalizeFromLength(XO);
        const bK = XO * OO,
          eO = pO.scaleInPlace(.5 * bK),
          vK = this.center.subtractToRef(eO, KO[1]),
          CO = this.center.addToRef(eO, KO[2]);
        return this.reConstruct(vK, CO, this._worldMatrix), this
      }
      getWorldMatrix() {
        return this._worldMatrix
      }
      _update(OO) {
        if (OO.isIdentity()) this.centerWorld.NhO(this.center), this.radiusWorld = this.radius;
        else {
          bK.o.TransformCoordinatesToRef(this.center, OO, this.centerWorld);
          const KO = lO._TmpVector3[0];
          bK.o.TransformNormalFromFloatsToRef(1, 1, 1, OO, KO), this.radiusWorld = Math.max(Math.abs(KO.x), Math.abs(KO.y), Math.abs(KO.z)) * this.radius
        }
      }
      isInFrustum(OO) {
        const KO = this.centerWorld,
          pO = this.radiusWorld;
        for (let XO = 0; XO < 6; XO++)
          if (OO[XO].dotCoordinate(KO) <= -pO) return !1;
        return !0
      }
      isCenterInFrustum(OO) {
        const KO = this.centerWorld;
        for (let pO = 0; pO < 6; pO++)
          if (OO[pO].dotCoordinate(KO) < 0) return !1;
        return !0
      }
      intersectsPoint(OO) {
        const KO = bK.o.DistanceSquared(this.centerWorld, OO);
        return !(this.radiusWorld * this.radiusWorld < KO)
      }
      static Intersects(OO, KO) {
        const pO = bK.o.DistanceSquared(OO.centerWorld, KO.centerWorld),
          XO = OO.radiusWorld + KO.radiusWorld;
        return !(XO * XO < pO)
      }
      static CreateFromCenterAndRadius(OO, KO, pO) {
        this._TmpVector3[0].NhO(OO), this._TmpVector3[1].rvO(0, 0, KO), this._TmpVector3[2].NhO(OO), this._TmpVector3[0].addInPlace(this._TmpVector3[1]), this._TmpVector3[2].oDO(this._TmpVector3[1]);
        const XO = new lO(this._TmpVector3[0], this._TmpVector3[2]);
        return XO._worldMatrix = pO || bK.c.Identity(), XO
      }
    }
    lO._TmpVector3 = (0, XO.d)(3, bK.o.Zero);
    const vK = {
        min: 0,
        max: 0
      },
      CO = {
        min: 0,
        max: 0
      },
      hO = (OO, KO, pO) => {
        const XO = bK.o.Dot(KO.centerWorld, OO),
          eO = Math.abs(bK.o.Dot(KO.directions[0], OO)) * KO.extendSize.x + Math.abs(bK.o.Dot(KO.directions[1], OO)) * KO.extendSize.y + Math.abs(bK.o.Dot(KO.directions[2], OO)) * KO.extendSize.z;
        pO.min = XO - eO, pO.max = XO + eO
      },
      DO = (OO, KO, pO) => (hO(OO, KO, vK), hO(OO, pO, CO), !(vK.min > CO.max || CO.min > vK.max));
    class MO {
      constructor(OO, KO, pO) {
        this._isLocked = !1, this.boundingBox = new eO.c(OO, KO, pO), this.QDO = new lO(OO, KO, pO)
      }
      reConstruct(OO, KO, pO) {
        this.boundingBox.reConstruct(OO, KO, pO), this.QDO.reConstruct(OO, KO, pO)
      }
      get minimum() {
        return this.boundingBox.minimum
      }
      get maximum() {
        return this.boundingBox.maximum
      }
      get isLocked() {
        return this._isLocked
      }
      set isLocked(OO) {
        this._isLocked = OO
      }
      update(OO) {
        this._isLocked || (this.boundingBox._update(OO), this.QDO._update(OO))
      }
      centerOn(OO, KO) {
        const pO = MO._TmpVector3[0].NhO(OO).oDO(KO),
          XO = MO._TmpVector3[1].NhO(OO).addInPlace(KO);
        return this.boundingBox.reConstruct(pO, XO, this.boundingBox.getWorldMatrix()), this.QDO.reConstruct(pO, XO, this.boundingBox.getWorldMatrix()), this
      }
      encapsulate(OO) {
        const KO = bK.o.Minimize(this.minimum, OO),
          pO = bK.o.Maximize(this.maximum, OO);
        return this.reConstruct(KO, pO, this.boundingBox.getWorldMatrix()), this
      }
      encapsulateBoundingInfo(OO) {
        const KO = bK.j.Matrix[0];
        this.boundingBox.getWorldMatrix().invertToRef(KO);
        const pO = bK.j.WX[0];
        return bK.o.TransformCoordinatesToRef(OO.boundingBox.minimumWorld, KO, pO), this.encapsulate(pO), bK.o.TransformCoordinatesToRef(OO.boundingBox.maximumWorld, KO, pO), this.encapsulate(pO), this
      }
      scale(OO) {
        return this.boundingBox.scale(OO), this.QDO.scale(OO), this
      }
      isInFrustum(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        if ((2 === KO || 3 === KO) && this.QDO.isCenterInFrustum(OO)) return !0;
        if (!this.QDO.isInFrustum(OO)) return !1;
        return !(1 !== KO && 3 !== KO) || this.boundingBox.isInFrustum(OO)
      }
      get diagonalLength() {
        const OO = this.boundingBox;
        return OO.maximumWorld.subtractToRef(OO.minimumWorld, MO._TmpVector3[0]).length()
      }
      isCompletelyInFrustum(OO) {
        return this.boundingBox.isCompletelyInFrustum(OO)
      }
      _checkCollision(OO) {
        return OO._canDoCollision(this.QDO.centerWorld, this.QDO.radiusWorld, this.boundingBox.minimumWorld, this.boundingBox.maximumWorld)
      }
      intersectsPoint(OO) {
        return !!this.QDO.centerWorld && (!!this.QDO.intersectsPoint(OO) && !!this.boundingBox.intersectsPoint(OO))
      }
      intersects(OO, KO) {
        if (!lO.Intersects(this.QDO, OO.QDO)) return !1;
        if (!eO.c.Intersects(this.boundingBox, OO.boundingBox)) return !1;
        if (!KO) return !0;
        const pO = this.boundingBox,
          XO = OO.boundingBox;
        return !!DO(pO.directions[0], pO, XO) && (!!DO(pO.directions[1], pO, XO) && (!!DO(pO.directions[2], pO, XO) && (!!DO(XO.directions[0], pO, XO) && (!!DO(XO.directions[1], pO, XO) && (!!DO(XO.directions[2], pO, XO) && (!!DO(bK.o.Cross(pO.directions[0], XO.directions[0]), pO, XO) && (!!DO(bK.o.Cross(pO.directions[0], XO.directions[1]), pO, XO) && (!!DO(bK.o.Cross(pO.directions[0], XO.directions[2]), pO, XO) && (!!DO(bK.o.Cross(pO.directions[1], XO.directions[0]), pO, XO) && (!!DO(bK.o.Cross(pO.directions[1], XO.directions[1]), pO, XO) && (!!DO(bK.o.Cross(pO.directions[1], XO.directions[2]), pO, XO) && (!!DO(bK.o.Cross(pO.directions[2], XO.directions[0]), pO, XO) && (!!DO(bK.o.Cross(pO.directions[2], XO.directions[1]), pO, XO) && !!DO(bK.o.Cross(pO.directions[2], XO.directions[2]), pO, XO))))))))))))))
      }
    }
    MO._TmpVector3 = (0, XO.d)(2, bK.o.Zero)
  },
  38431: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      e: () => CO,
      i: () => vK,
      l: () => lO
    });
    var XO = pO(38231),
      bK = pO(35632);

    function eO(OO) {
      -1 === OO.indexOf("vClipPlane") && OO.push("vClipPlane"), -1 === OO.indexOf("vClipPlane2") && OO.push("vClipPlane2"), -1 === OO.indexOf("vClipPlane3") && OO.push("vClipPlane3"), -1 === OO.indexOf("vClipPlane4") && OO.push("vClipPlane4"), -1 === OO.indexOf("vClipPlane5") && OO.push("vClipPlane5"), -1 === OO.indexOf("vClipPlane6") && OO.push("vClipPlane6")
    }

    function lO(OO, KO, pO) {
      const XO = !!(OO.clipPlane ?? KO.clipPlane),
        bK = !!(OO.clipPlane2 ?? KO.clipPlane2),
        eO = !!(OO.clipPlane3 ?? KO.clipPlane3),
        lO = !!(OO.clipPlane4 ?? KO.clipPlane4),
        vK = !!(OO.clipPlane5 ?? KO.clipPlane5),
        CO = !!(OO.clipPlane6 ?? KO.clipPlane6);
      XO && pO.push("#define CLIPPLANE"), bK && pO.push("#define CLIPPLANE2"), eO && pO.push("#define CLIPPLANE3"), lO && pO.push("#define CLIPPLANE4"), vK && pO.push("#define CLIPPLANE5"), CO && pO.push("#define CLIPPLANE6")
    }

    function vK(OO, KO, pO) {
      let XO = !1;
      const bK = !!(OO.clipPlane ?? KO.clipPlane),
        eO = !!(OO.clipPlane2 ?? KO.clipPlane2),
        lO = !!(OO.clipPlane3 ?? KO.clipPlane3),
        vK = !!(OO.clipPlane4 ?? KO.clipPlane4),
        CO = !!(OO.clipPlane5 ?? KO.clipPlane5),
        hO = !!(OO.clipPlane6 ?? KO.clipPlane6);
      return pO.CLIPPLANE !== bK && (pO.CLIPPLANE = bK, XO = !0), pO.CLIPPLANE2 !== eO && (pO.CLIPPLANE2 = eO, XO = !0), pO.CLIPPLANE3 !== lO && (pO.CLIPPLANE3 = lO, XO = !0), pO.CLIPPLANE4 !== vK && (pO.CLIPPLANE4 = vK, XO = !0), pO.CLIPPLANE5 !== CO && (pO.CLIPPLANE5 = CO, XO = !0), pO.CLIPPLANE6 !== hO && (pO.CLIPPLANE6 = hO, XO = !0), XO
    }

    function CO(OO, KO, pO) {
      let XO = KO.clipPlane ?? pO.clipPlane;
      hO(OO, "vClipPlane", XO), XO = KO.clipPlane2 ?? pO.clipPlane2, hO(OO, "vClipPlane2", XO), XO = KO.clipPlane3 ?? pO.clipPlane3, hO(OO, "vClipPlane3", XO), XO = KO.clipPlane4 ?? pO.clipPlane4, hO(OO, "vClipPlane4", XO), XO = KO.clipPlane5 ?? pO.clipPlane5, hO(OO, "vClipPlane5", XO), XO = KO.clipPlane6 ?? pO.clipPlane6, hO(OO, "vClipPlane6", XO)
    }

    function hO(OO, KO, pO) {
      if (pO) {
        const eO = XO.c.JKO()?.floatingOriginOffset || bK.o.ZeroReadOnly;
        OO.setFloat4(KO, pO.normal.x, pO.normal.y, pO.normal.z, pO.d + bK.o.Dot(pO.normal, eO))
      }
    }
  },
  38449: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO
    });
    class XO {
      constructor() {
        this._defines = {}, this._currentRank = 32, this._maxRank = -1, this._mesh = null
      }
      unBindMesh() {
        this._mesh = null
      }
      addFallback(OO, KO) {
        this._defines[OO] || (OO < this._currentRank && (this._currentRank = OO), OO > this._maxRank && (this._maxRank = OO), this._defines[OO] = new Array), this._defines[OO].push(KO)
      }
      addCPUSkinningFallback(OO, KO) {
        this._mesh = KO, OO < this._currentRank && (this._currentRank = OO), OO > this._maxRank && (this._maxRank = OO)
      }
      get hasMoreFallbacks() {
        return this._currentRank <= this._maxRank
      }
      reduce(OO, KO) {
        if (this._mesh && this._mesh.computeBonesUsingShaders && this._mesh.numBoneInfluencers > 0) {
          this._mesh.computeBonesUsingShaders = !1, OO = OO.replace("#define NUM_BONE_INFLUENCERS " + this._mesh.numBoneInfluencers, "#define NUM_BONE_INFLUENCERS 0"), KO._bonesComputationForcedToCPU = !0;
          const pO = this._mesh.JKO();
          for (let OO = 0; OO < pO.meshes.length; OO++) {
            const XO = pO.meshes[OO];
            if (XO.material) {
              if (XO.computeBonesUsingShaders && 0 !== XO.numBoneInfluencers)
                if (XO.material.getEffect() === KO) XO.computeBonesUsingShaders = !1;
                else if (XO.au)
                for (const OO of XO.au) {
                  if (OO.effect === KO) {
                    XO.computeBonesUsingShaders = !1;
                    break
                  }
                }
            } else !this._mesh.material && XO.computeBonesUsingShaders && XO.numBoneInfluencers > 0 && (XO.computeBonesUsingShaders = !1)
          }
        } else {
          const KO = this._defines[this._currentRank];
          if (KO)
            for (let pO = 0; pO < KO.length; pO++) OO = OO.replace("#define " + KO[pO], "");
          this._currentRank++
        }
        return OO
      }
    }
  },
  38382: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => zK
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(38172),
      lO = pO(35660),
      vK = pO(35653),
      CO = pO(38388),
      hO = pO(38206),
      DO = pO(37061),
      MO = pO(36146),
      aK = pO(38416),
      oO = pO(38077);
    let FO = (() => {
      var OO;
      let KO, pO, eO, lO, vK, CO, hO, DO, MO, aK, FO, VO, LO = [];
      return OO = class {
        constructor() {
          this._func = (0, XO.i)(this, LO), this.reset()
        }
        reset() {
          this.enabled = !1, this.mask = 255, this.funcRef = 1, this.funcMask = 255, this.func = 519, this.opStencilFail = 7680, this.opDepthFail = 7680, this.opStencilDepthPass = 7681, this.backFunc = 519, this.backOpStencilFail = 7680, this.backOpDepthFail = 7680, this.backOpStencilDepthPass = 7681
        }
        get func() {
          return this._func
        }
        set func(OO) {
          this._func = OO
        }
        get backFunc() {
          return this._backFunc
        }
        set backFunc(OO) {
          this._backFunc = OO
        }
        get funcRef() {
          return this._funcRef
        }
        set funcRef(OO) {
          this._funcRef = OO
        }
        get funcMask() {
          return this._funcMask
        }
        set funcMask(OO) {
          this._funcMask = OO
        }
        get opStencilFail() {
          return this._opStencilFail
        }
        set opStencilFail(OO) {
          this._opStencilFail = OO
        }
        get opDepthFail() {
          return this._opDepthFail
        }
        set opDepthFail(OO) {
          this._opDepthFail = OO
        }
        get opStencilDepthPass() {
          return this._opStencilDepthPass
        }
        set opStencilDepthPass(OO) {
          this._opStencilDepthPass = OO
        }
        get backOpStencilFail() {
          return this._backOpStencilFail
        }
        set backOpStencilFail(OO) {
          this._backOpStencilFail = OO
        }
        get backOpDepthFail() {
          return this._backOpDepthFail
        }
        set backOpDepthFail(OO) {
          this._backOpDepthFail = OO
        }
        get backOpStencilDepthPass() {
          return this._backOpStencilDepthPass
        }
        set backOpStencilDepthPass(OO) {
          this._backOpStencilDepthPass = OO
        }
        get mask() {
          return this._mask
        }
        set mask(OO) {
          this._mask = OO
        }
        get enabled() {
          return this._enabled
        }
        set enabled(OO) {
          this._enabled = OO
        }
        getClassName() {
          return "MaterialStencilState"
        }
        copyTo(OO) {
          oO.c.Clone((() => OO), this)
        }
        serialize() {
          return oO.c.Serialize(this)
        }
        parse(OO, KO, pO) {
          oO.c.Parse((() => this), OO, KO, pO)
        }
      }, (() => {
        const oO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], eO = [(0, bK.M)()], lO = [(0, bK.M)()], vK = [(0, bK.M)()], CO = [(0, bK.M)()], hO = [(0, bK.M)()], DO = [(0, bK.M)()], MO = [(0, bK.M)()], aK = [(0, bK.M)()], FO = [(0, bK.M)()], VO = [(0, bK.M)()], (0, XO.f)(OO, null, KO, {
          kind: "getter",
          name: "func",
          static: !1,
          private: !1,
          access: {
            has: OO => "func" in OO,
            get: OO => OO.func
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, pO, {
          kind: "getter",
          name: "backFunc",
          static: !1,
          private: !1,
          access: {
            has: OO => "backFunc" in OO,
            get: OO => OO.backFunc
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, eO, {
          kind: "getter",
          name: "funcRef",
          static: !1,
          private: !1,
          access: {
            has: OO => "funcRef" in OO,
            get: OO => OO.funcRef
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, lO, {
          kind: "getter",
          name: "funcMask",
          static: !1,
          private: !1,
          access: {
            has: OO => "funcMask" in OO,
            get: OO => OO.funcMask
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, vK, {
          kind: "getter",
          name: "opStencilFail",
          static: !1,
          private: !1,
          access: {
            has: OO => "opStencilFail" in OO,
            get: OO => OO.opStencilFail
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, CO, {
          kind: "getter",
          name: "opDepthFail",
          static: !1,
          private: !1,
          access: {
            has: OO => "opDepthFail" in OO,
            get: OO => OO.opDepthFail
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, hO, {
          kind: "getter",
          name: "opStencilDepthPass",
          static: !1,
          private: !1,
          access: {
            has: OO => "opStencilDepthPass" in OO,
            get: OO => OO.opStencilDepthPass
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, DO, {
          kind: "getter",
          name: "backOpStencilFail",
          static: !1,
          private: !1,
          access: {
            has: OO => "backOpStencilFail" in OO,
            get: OO => OO.backOpStencilFail
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, MO, {
          kind: "getter",
          name: "backOpDepthFail",
          static: !1,
          private: !1,
          access: {
            has: OO => "backOpDepthFail" in OO,
            get: OO => OO.backOpDepthFail
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, aK, {
          kind: "getter",
          name: "backOpStencilDepthPass",
          static: !1,
          private: !1,
          access: {
            has: OO => "backOpStencilDepthPass" in OO,
            get: OO => OO.backOpStencilDepthPass
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, FO, {
          kind: "getter",
          name: "mask",
          static: !1,
          private: !1,
          access: {
            has: OO => "mask" in OO,
            get: OO => OO.mask
          },
          metadata: oO
        }, null, LO), (0, XO.f)(OO, null, VO, {
          kind: "getter",
          name: "enabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "enabled" in OO,
            get: OO => OO.enabled
          },
          metadata: oO
        }, null, LO), oO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: oO
        })
      })(), OO
    })();
    var VO = pO(38424),
      LO = pO(37978),
      QO = pO(37938);
    let zK = (() => {
      var OO;
      let KO, pO, QO, zK, AO, fO, dO, TO, NO, IO, yK, gK, uO, EO, jK, YO, wO, iK, rK, PO, mK, sO, HO, RO, SO, JO, cK, BO, ZO, GO = [],
        qK = [],
        xK = [],
        nO = [],
        WO = [],
        tK = [],
        kK = [],
        UO = [],
        OK = [],
        KK = [],
        pK = [],
        XK = [],
        bp = [],
        eK = [],
        lK = [],
        vp = [],
        CK = [],
        hK = [],
        DK = [],
        MK = [],
        ap = [],
        oK = [],
        FK = [],
        VK = [],
        LK = [],
        QK = [],
        zp = [],
        AK = [],
        fK = [],
        dK = [],
        TK = [],
        NK = [],
        IK = [],
        yp = [],
        gp = [],
        uK = [],
        EK = [],
        jp = [],
        YK = [],
        wK = [],
        ip = [],
        rp = [],
        PK = [],
        mp = [],
        sK = [],
        HK = [],
        RK = [],
        SK = [],
        JK = [],
        cp = [],
        BK = [];
      return OO = class {
        get useVertexPulling() {
          return this._useVertexPulling
        }
        set useVertexPulling(KO) {
          this._useVertexPulling !== KO && (this._useVertexPulling = KO, this.jhO(OO.MiscDirtyFlag))
        }
        get _supportGlowLayer() {
          return !1
        }
        set _glowModeEnabled(OO) {}
        get shaderLanguage() {
          return this._shaderLanguage
        }
        get canRenderToMRT() {
          return !1
        }
        set alpha(KO) {
          if (this._alpha === KO) return;
          const pO = this._alpha;
          this._alpha = KO, 1 !== pO && 1 !== KO || this.jhO(OO.MiscDirtyFlag + OO.PrePassDirtyFlag)
        }
        get alpha() {
          return this._alpha
        }
        set backFaceCulling(KO) {
          this._backFaceCulling !== KO && (this._backFaceCulling = KO, this.jhO(OO.TextureDirtyFlag))
        }
        get backFaceCulling() {
          return this._backFaceCulling
        }
        set textureRepetitionMode(KO) {
          const pO = Math.max(0, Math.min(0 | KO, 4));
          this._textureRepetitionMode !== pO && (this._textureRepetitionMode = pO, this.jhO(OO.TextureDirtyFlag))
        }
        get textureRepetitionMode() {
          return this._textureRepetitionMode
        }
        set cullBackFaces(KO) {
          this._cullBackFaces !== KO && (this._cullBackFaces = KO, this.jhO(OO.TextureDirtyFlag))
        }
        get cullBackFaces() {
          return this._cullBackFaces
        }
        get blockDirtyMechanism() {
          return this._blockDirtyMechanism
        }
        set blockDirtyMechanism(OO) {
          this._blockDirtyMechanism !== OO && (this._blockDirtyMechanism = OO, OO || this.markDirty())
        }
        atomicMaterialsUpdate(OO) {
          this.blockDirtyMechanism = !0;
          try {
            OO(this)
          } finally {
            this.blockDirtyMechanism = !1
          }
        }
        get hasRenderTargetTextures() {
          return this._eventInfo.hasRenderTargetTextures = !1, this._callbackPluginEventHasRenderTargetTextures(this._eventInfo), this._eventInfo.hasRenderTargetTextures
        }
        set onDispose(OO) {
          this._onDisposeObserver && this.cpO.remove(this._onDisposeObserver), this._onDisposeObserver = this.cpO.add(OO)
        }
        get onBindObservable() {
          return this._onBindObservable || (this._onBindObservable = new lO.e), this._onBindObservable
        }
        set onBind(OO) {
          this._onBindObserver && this.onBindObservable.remove(this._onBindObserver), this._onBindObserver = this.onBindObservable.add(OO)
        }
        get onUnBindObservable() {
          return this._onUnBindObservable || (this._onUnBindObservable = new lO.e), this._onUnBindObservable
        }
        get onEffectCreatedObservable() {
          return this._onEffectCreatedObservable || (this._onEffectCreatedObservable = new lO.e), this._onEffectCreatedObservable
        }
        set alphaMode(OO) {
          this._alphaMode[0] = OO
        }
        get alphaMode() {
          return this._alphaMode[0]
        }
        get alphaModes() {
          return this._alphaMode
        }
        setAlphaMode(KO) {
          let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
          this._alphaMode[pO] !== KO && (this._alphaMode[pO] = KO, this.jhO(OO.TextureDirtyFlag))
        }
        set needDepthPrePass(OO) {
          this._needDepthPrePass !== OO && (this._needDepthPrePass = OO, this._needDepthPrePass && (this.checkReadyOnEveryCall = !0))
        }
        get needDepthPrePass() {
          return this._needDepthPrePass
        }
        get isPrePassCapable() {
          return !1
        }
        set fogEnabled(KO) {
          this._fogEnabled !== KO && (this._fogEnabled = KO, this.jhO(OO.MiscDirtyFlag))
        }
        get fogEnabled() {
          return this._fogEnabled
        }
        get wireframe() {
          switch (this._fillMode) {
            case OO.WireFrameFillMode:
            case OO.LineListDrawMode:
            case OO.LineLoopDrawMode:
            case OO.LineStripDrawMode:
              return !0
          }
          return this._scene.forceWireframe
        }
        set wireframe(KO) {
          this.fillMode = KO ? OO.WireFrameFillMode : OO.TriangleFillMode
        }
        get pointsCloud() {
          switch (this._fillMode) {
            case OO.PointFillMode:
            case OO.PointListDrawMode:
              return !0
          }
          return this._scene.forcePointsCloud
        }
        set pointsCloud(KO) {
          this.fillMode = KO ? OO.PointFillMode : OO.TriangleFillMode
        }
        get fillMode() {
          return this._fillMode
        }
        set fillMode(KO) {
          this._fillMode !== KO && (this._fillMode = KO, this.jhO(OO.MiscDirtyFlag))
        }
        get useLogarithmicDepth() {
          return this._useLogarithmicDepth
        }
        set useLogarithmicDepth(OO) {
          const KO = this.JKO().qb().getCaps().fragmentDepthSupported;
          OO && !KO && DO.b.Warn("Logarithmic depth has been requested for a material on a device that doesn't support it."), this._useLogarithmicDepth = OO && KO, this._markAllSubMeshesAsMiscDirty()
        }
        get isVertexOutputInvariant() {
          return this._isVertexOutputInvariant
        }
        set isVertexOutputInvariant(OO) {
          this._isVertexOutputInvariant !== OO && (this._isVertexOutputInvariant = OO, this._markAllSubMeshesAsMiscDirty())
        }
        _getDrawWrapper() {
          return this._drawWrapper
        }
        _setDrawWrapper(OO) {
          this._drawWrapper = OO
        }
        constructor(KO, pO, bK) {
          let CO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
          this.customShaderNameResolve = (0, XO.i)(this, GO), this.shadowDepthWrapper = null, this.allowShaderHotSwapping = !0, this._shaderLanguage = 0, this._forceGLSL = !1, this._useVertexPulling = !1, this.id = (0, XO.i)(this, qK, void 0), this.uniqueId = ((0, XO.i)(this, xK), (0, XO.i)(this, nO, void 0)), this._loadedUniqueId = (0, XO.i)(this, WO), this.name = (0, XO.i)(this, tK, void 0), this.metadata = ((0, XO.i)(this, kK), (0, XO.i)(this, UO, null)), this._internalMetadata = (0, XO.i)(this, OK), this.reservedDataStore = null, this.checkReadyOnEveryCall = (0, XO.i)(this, KK, !1), this.checkReadyOnlyOnce = ((0, XO.i)(this, pK), (0, XO.i)(this, XK, !1)), this.state = ((0, XO.i)(this, bp), (0, XO.i)(this, eK, "")), this._alpha = ((0, XO.i)(this, lK), (0, XO.i)(this, vp, 1)), this.inspectableCustomProperties = (0, XO.i)(this, CK), this._backFaceCulling = (0, XO.i)(this, hK, !0), this._textureRepetitionMode = ((0, XO.i)(this, DK), (0, XO.i)(this, MK, 0)), this.textureRepetitionHexTilingParams = ((0, XO.i)(this, ap), (0, XO.i)(this, oK, [1, .6, 7, .5])), this._cullBackFaces = ((0, XO.i)(this, FK), (0, XO.i)(this, VK, !0)), this._blockDirtyMechanism = ((0, XO.i)(this, LK), !1), this.sideOrientation = (0, XO.i)(this, QK, null), this.onCompiled = ((0, XO.i)(this, zp), null), this.onError = null, this.getRenderTargetTextures = null, this.doNotSerialize = !1, this._storeEffectOnSubMeshes = !1, this.animations = null, this.cpO = new lO.e, this._onDisposeObserver = null, this._onUnBindObservable = null, this._onBindObserver = null, this._alphaMode = (0, XO.i)(this, AK, [2]), this._needDepthPrePass = ((0, XO.i)(this, fK), (0, XO.i)(this, dK, !1)), this.disableDepthWrite = ((0, XO.i)(this, TK), (0, XO.i)(this, NK, !1)), this.disableColorWrite = ((0, XO.i)(this, IK), (0, XO.i)(this, yp, !1)), this.forceDepthWrite = ((0, XO.i)(this, gp), (0, XO.i)(this, uK, !1)), this.depthFunction = ((0, XO.i)(this, EK), (0, XO.i)(this, jp, 0)), this.separateCullingPass = ((0, XO.i)(this, YK), (0, XO.i)(this, wK, !1)), this._fogEnabled = ((0, XO.i)(this, ip), (0, XO.i)(this, rp, !0)), this.pointSize = ((0, XO.i)(this, PK), (0, XO.i)(this, mp, 1)), this.zOffset = ((0, XO.i)(this, sK), (0, XO.i)(this, HK, 0)), this.zOffsetUnits = ((0, XO.i)(this, RK), (0, XO.i)(this, SK, 0)), this.clipPlane = (0, XO.i)(this, JK), this.stencil = new FO, this._isVertexOutputInvariant = (0, XO.i)(this, cp, OO.ForceVertexOutputInvariant), this._materialContext = (0, XO.i)(this, BK), this._useUBO = !1, this._fillMode = OO.TriangleFillMode, this._cachedDepthWriteState = !1, this._cachedColorWriteState = !1, this._cachedDepthFunctionState = 0, this._indexInSceneMaterialArray = -1, this.meshMap = null, this._parentContainer = null, this._uniformBufferLayoutBuilt = !1, this._eventInfo = {}, this._callbackPluginEventGeneric = () => {}, this._callbackPluginEventIsReadyForSubMesh = () => {}, this._callbackPluginEventPrepareDefines = () => {}, this._callbackPluginEventPrepareDefinesBeforeAttributes = () => {}, this._callbackPluginEventHardBindForSubMesh = () => {}, this._callbackPluginEventBindForSubMesh = () => {}, this._callbackPluginEventHasRenderTargetTextures = () => {}, this._callbackPluginEventFillRenderTargetTextures = () => {}, this._transparencyMode = null, this.name = KO;
          const DO = pO || vK.c.LastCreatedScene;
          DO && (this._scene = DO, this._dirtyCallbacks = {}, this._forceGLSL = CO, this._dirtyCallbacks[1] = this._markAllSubMeshesAsTexturesDirty.bind(this), this._dirtyCallbacks[2] = this._markAllSubMeshesAsLightsDirty.bind(this), this._dirtyCallbacks[4] = this._markAllSubMeshesAsFresnelDirty.bind(this), this._dirtyCallbacks[8] = this._markAllSubMeshesAsAttributesDirty.bind(this), this._dirtyCallbacks[16] = this._markAllSubMeshesAsMiscDirty.bind(this), this._dirtyCallbacks[32] = this._markAllSubMeshesAsPrePassDirty.bind(this), this._dirtyCallbacks[127] = this._markAllSubMeshesAsAllDirty.bind(this), this.id = KO || eO.k.RandomId(), this.uniqueId = this._scene.getUniqueId(), this._materialContext = this._scene.qb().createMaterialContext(), this._drawWrapper = new aK.c(this._scene.qb(), !1), this._drawWrapper.materialContext = this._materialContext, this._uniformBuffer = new hO.d(this._scene.qb(), void 0, void 0, KO), this._useUBO = this.JKO().qb().supportsUniformBuffers, this._createUniformBuffer(), bK || this._scene.addMaterial(this), this._scene.useMaterialMeshMap && (this.meshMap = {}), OO.OnEventObservable.notifyObservers(this, 1))
        }
        _createUniformBuffer() {
          const OO = this.JKO().qb();
          this._uniformBuffer?.dispose(), OO.isWebGPU && !this._forceGLSL ? (this._uniformBuffer = new hO.d(OO, void 0, void 0, this.name, !0), this._shaderLanguage = 1) : this._uniformBuffer = new hO.d(this._scene.qb(), void 0, void 0, this.name), this._uniformBufferLayoutBuilt = !1
        }
        toString(OO) {
          return "Name: " + this.name
        }
        getClassName() {
          return "Material"
        }
        get _isMaterial() {
          return !0
        }
        get isFrozen() {
          return this.checkReadyOnlyOnce
        }
        freeze() {
          this.markDirty(), this.checkReadyOnlyOnce = !0
        }
        unfreeze() {
          this.markDirty(), this.checkReadyOnlyOnce = !1
        }
        isReady(OO, KO) {
          return !0
        }
        isReadyForSubMesh(OO, KO, pO) {
          const XO = KO.materialDefines;
          return !!XO && (this._eventInfo.isReadyForSubMesh = !0, this._eventInfo.defines = XO, this._callbackPluginEventIsReadyForSubMesh(this._eventInfo), this._eventInfo.isReadyForSubMesh)
        }
        getEffect() {
          return this._drawWrapper.effect
        }
        JKO() {
          return this._scene
        }
        _getEffectiveOrientation(OO) {
          return null !== this.sideOrientation ? this.sideOrientation : OO.sideOrientation
        }
        get transparencyMode() {
          return this._transparencyMode
        }
        set transparencyMode(OO) {
          this._transparencyMode = OO
        }
        get _hasTransparencyMode() {
          return null != this._transparencyMode
        }
        get _transparencyModeIsBlend() {
          return this._transparencyMode === OO.MATERIAL_ALPHABLEND || this._transparencyMode === OO.MATERIAL_ALPHATESTANDBLEND
        }
        get _transparencyModeIsTest() {
          return this._transparencyMode === OO.MATERIAL_ALPHATEST || this._transparencyMode === OO.MATERIAL_ALPHATESTANDBLEND
        }
        get _disableAlphaBlending() {
          return this._transparencyMode === OO.MATERIAL_OPAQUE || this._transparencyMode === OO.MATERIAL_ALPHATEST
        }
        needAlphaBlending() {
          return this._hasTransparencyMode ? this._transparencyModeIsBlend : !this._disableAlphaBlending && this.alpha < 1
        }
        needAlphaBlendingForMesh(OO) {
          return this._hasTransparencyMode ? this._transparencyModeIsBlend : OO.visibility < 1 || !this._disableAlphaBlending && (OO.hasVertexAlpha || this.needAlphaBlending())
        }
        needAlphaTesting() {
          return !!this._hasTransparencyMode && this._transparencyModeIsTest
        }
        needAlphaTestingForMesh(OO) {
          return this._hasTransparencyMode ? this._transparencyModeIsTest : !this.needAlphaBlendingForMesh(OO) && this.needAlphaTesting()
        }
        getAlphaTestTexture() {
          return null
        }
        markDirty() {
          let KO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          const pO = this.JKO().meshes;
          for (const OO of pO)
            if (OO.au)
              for (const pO of OO.au)
                if (pO.UX() === this)
                  for (const OO of pO._drawWrappers) OO && this._materialContext === OO.materialContext && (OO._wasPreviouslyReady = !1, OO._wasPreviouslyUsingInstances = null, OO._forceRebindOnNextCall = KO);
          KO && this.jhO(OO.AllDirtyFlag)
        }
        _preBind(KO) {
          let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          const XO = this._scene.qb(),
            bK = (null == pO ? this.sideOrientation : pO) === OO.ClockWiseSideOrientation,
            eO = KO || this._getDrawWrapper();
          return (0, LO.e)(eO) && eO.materialContext && (eO.materialContext.useVertexPulling = this.useVertexPulling), XO.enableEffect(eO), XO.setState(this.backFaceCulling, this.zOffset, !1, bK, this._scene._mirroredCameraPosition ? !this.cullBackFaces : this.cullBackFaces, this.stencil, this.zOffsetUnits), bK
        }
        bind(OO, KO) {}
        buildUniformLayout() {
          const OO = this._uniformBuffer;
          this._eventInfo.ubo = OO, this._callbackPluginEventGeneric(8, this._eventInfo), OO.create(), this._uniformBufferLayoutBuilt = !0
        }
        bindForSubMesh(OO, KO, pO) {
          const XO = pO._drawWrapper;
          this._eventInfo.subMesh = pO, this._callbackPluginEventBindForSubMesh(this._eventInfo), XO._forceRebindOnNextCall = !1
        }
        bindOnlyWorldMatrix(OO) {}
        bindView(OO) {
          this._useUBO ? this._needToBindSceneUbo = !0 : OO.setMatrix("view", this.JKO().getViewMatrix())
        }
        bindViewProjection(OO) {
          this._useUBO ? this._needToBindSceneUbo = !0 : (OO.setMatrix("viewProjection", this.JKO().getTransformMatrix()), OO.setMatrix("projection", this.JKO().getProjectionMatrix()), OO.setMatrix("inverseProjection", this.JKO().getInverseProjectionMatrix()))
        }
        bindEyePosition(OO, KO) {
          this._useUBO ? this._needToBindSceneUbo = !0 : this._scene.bindEyePosition(OO, KO)
        }
        _afterBind(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          if (this._scene._cachedMaterial = this, this._needToBindSceneUbo && KO && (this._needToBindSceneUbo = !1, (0, VO.A)(KO, this.JKO().getSceneUniformBuffer()), this._scene.finalizeSceneUbo()), this._scene._cachedVisibility = OO ? OO.visibility : 1, this._onBindObservable && OO && this._onBindObservable.notifyObservers(OO), this.disableDepthWrite) {
            const OO = this._scene.qb();
            this._cachedDepthWriteState = OO.getDepthWrite(), OO.setDepthWrite(!1)
          }
          if (this.disableColorWrite) {
            const OO = this._scene.qb();
            this._cachedColorWriteState = OO.getColorWrite(), OO.setColorWrite(!1)
          }
          if (0 !== this.depthFunction) {
            const OO = this._scene.qb();
            this._cachedDepthFunctionState = OO.getDepthFunction() || 0, OO.setDepthFunction(this.depthFunction)
          }
        }
        unbind() {
          if (this._scene.getSceneUniformBuffer().unbindEffect(), this._onUnBindObservable && this._onUnBindObservable.notifyObservers(this), 0 !== this.depthFunction) {
            this._scene.qb().setDepthFunction(this._cachedDepthFunctionState)
          }
          if (this.disableDepthWrite) {
            this._scene.qb().setDepthWrite(this._cachedDepthWriteState)
          }
          if (this.disableColorWrite) {
            this._scene.qb().setColorWrite(this._cachedColorWriteState)
          }
        }
        getAnimatables() {
          return this._eventInfo.animatables = [], this._callbackPluginEventGeneric(256, this._eventInfo), this._eventInfo.animatables
        }
        getActiveTextures() {
          return this._eventInfo.activeTextures = [], this._callbackPluginEventGeneric(512, this._eventInfo), this._eventInfo.activeTextures
        }
        hasTexture(OO) {
          return this._eventInfo.hasTexture = !1, this._eventInfo.texture = OO, this._callbackPluginEventGeneric(1024, this._eventInfo), this._eventInfo.hasTexture
        }
        clone(OO) {
          return null
        }
        _clonePlugins(KO, pO) {
          const XO = {};
          if (this._serializePlugins(XO), OO._ParsePlugins(XO, KO, this._scene, pO), this.pluginManager)
            for (const OO of this.pluginManager._plugins) {
              const pO = KO.pluginManager.getPlugin(OO.name);
              pO && OO.copyTo(pO)
            }
        }
        getBindedMeshes() {
          if (this.meshMap) {
            const OO = [];
            for (const KO in this.meshMap) {
              const pO = this.meshMap[KO];
              pO && OO.push(pO)
            }
            return OO
          }
          return this._scene.meshes.filter((OO => OO.material === this))
        }
        forceCompilation(OO, KO, pO, XO) {
          const bK = {
              clipPlane: !1,
              useInstances: !1,
              ...pO
            },
            eO = this.JKO(),
            lO = this.allowShaderHotSwapping;
          this.allowShaderHotSwapping = !1;
          const vK = () => {
            if (!this._scene || !this._scene.qb()) return;
            const pO = eO.clipPlane;
            if (bK.clipPlane && (eO.clipPlane = new MO.d(0, 0, 0, 1)), this._storeEffectOnSubMeshes) {
              let pO = !0,
                eO = null;
              if (OO.au) {
                const KO = new CO.b(0, 0, 0, 0, 0, OO, void 0, !1, !1);
                KO.materialDefines && (KO.materialDefines._renderId = -1), this.isReadyForSubMesh(OO, KO, bK.useInstances) || (KO.effect && KO.effect.getCompilationError() && KO.effect.allFallbacksProcessed() ? eO = KO.effect.getCompilationError() : (pO = !1, setTimeout(vK, 16)))
              }
              pO && (this.allowShaderHotSwapping = lO, eO && XO && XO(eO), KO && KO(this))
            } else this.isReady() ? (this.allowShaderHotSwapping = lO, KO && KO(this)) : setTimeout(vK, 16);
            bK.clipPlane && (eO.clipPlane = pO)
          };
          vK()
        }
        async forceCompilationAsync(OO, KO) {
          return await new Promise(((pO, XO) => {
            this.forceCompilation(OO, (() => {
              pO()
            }), KO, (OO => {
              XO(OO)
            }))
          }))
        }
        jhO(KO) {
          this.JKO().blockMaterialDirtyMechanism || this._blockDirtyMechanism || (OO._DirtyCallbackArray.length = 0, KO & OO.ImageProcessingDirtyFlag && OO._DirtyCallbackArray.push(OO._ImageProcessingDirtyCallBack), KO & OO.TextureDirtyFlag && OO._DirtyCallbackArray.push(OO._TextureDirtyCallBack), KO & OO.LightDirtyFlag && OO._DirtyCallbackArray.push(OO._LightsDirtyCallBack), KO & OO.FresnelDirtyFlag && OO._DirtyCallbackArray.push(OO._FresnelDirtyCallBack), KO & OO.AttributesDirtyFlag && OO._DirtyCallbackArray.push(OO._AttributeDirtyCallBack), KO & OO.MiscDirtyFlag && OO._DirtyCallbackArray.push(OO._MiscDirtyCallBack), KO & OO.PrePassDirtyFlag && OO._DirtyCallbackArray.push(OO._PrePassDirtyCallBack), OO._DirtyCallbackArray.length && this._markAllSubMeshesAsDirty(OO._RunDirtyCallBacks), this.JKO().resetCachedMaterial())
        }
        resetDrawCache() {
          const OO = this.JKO().meshes;
          for (const KO of OO)
            if (KO.au)
              for (const OO of KO.au) OO.UX() === this && OO.resetDrawCache()
        }
        _markAllSubMeshesAsDirty(OO) {
          const KO = this.JKO();
          if (KO.blockMaterialDirtyMechanism || this._blockDirtyMechanism) return;
          const pO = KO.meshes;
          for (const XO of pO)
            if (XO.au)
              for (const pO of XO.au) {
                if ((pO.UX() || (KO._hasDefaultMaterial ? KO.defaultMaterial : null)) === this)
                  for (const KO of pO._drawWrappers) KO && KO.defines && KO.defines.markAllAsDirty && this._materialContext === KO.materialContext && OO(KO.defines)
              }
        }
        _markScenePrePassDirty() {
          if (this.JKO().blockMaterialDirtyMechanism || this._blockDirtyMechanism) return;
          const OO = this.JKO().enablePrePassRenderer();
          OO && OO.jhO()
        }
        _markAllSubMeshesAsAllDirty() {
          this._markAllSubMeshesAsDirty(OO._AllDirtyCallBack)
        }
        _markAllSubMeshesAsImageProcessingDirty() {
          this._markAllSubMeshesAsDirty(OO._ImageProcessingDirtyCallBack)
        }
        _markAllSubMeshesAsTexturesDirty() {
          this._markAllSubMeshesAsDirty(OO._TextureDirtyCallBack)
        }
        _markAllSubMeshesAsFresnelDirty() {
          this._markAllSubMeshesAsDirty(OO._FresnelDirtyCallBack)
        }
        _markAllSubMeshesAsFresnelAndMiscDirty() {
          this._markAllSubMeshesAsDirty(OO._FresnelAndMiscDirtyCallBack)
        }
        _markAllSubMeshesAsLightsDirty() {
          this._markAllSubMeshesAsDirty(OO._LightsDirtyCallBack)
        }
        _markAllSubMeshesAsAttributesDirty() {
          this._markAllSubMeshesAsDirty(OO._AttributeDirtyCallBack)
        }
        _markAllSubMeshesAsMiscDirty() {
          this._markAllSubMeshesAsDirty(OO._MiscDirtyCallBack)
        }
        _markAllSubMeshesAsPrePassDirty() {
          this._markAllSubMeshesAsDirty(OO._PrePassDirtyCallBack)
        }
        _markAllSubMeshesAsTexturesAndMiscDirty() {
          this._markAllSubMeshesAsDirty(OO._TextureAndMiscDirtyCallBack)
        }
        _checkScenePerformancePriority() {
          if (0 !== this._scene.performancePriority) {
            this.checkReadyOnlyOnce = !0;
            const OO = this._scene.onScenePerformancePriorityChangedObservable.addOnce((() => {
              this.checkReadyOnlyOnce = !1
            }));
            this.cpO.add((() => {
              this._scene.onScenePerformancePriorityChangedObservable.remove(OO)
            }))
          }
        }
        setPrePassRenderer(OO) {
          return !1
        }
        dispose(OO, KO, pO) {
          const XO = this.JKO();
          if (XO.stopAnimation(this), XO.freeProcessedMaterials(), XO.removeMaterial(this), this._eventInfo.forceDisposeTextures = KO, this._callbackPluginEventGeneric(2, this._eventInfo), this._parentContainer) {
            const OO = this._parentContainer.materials.indexOf(this);
            OO > -1 && this._parentContainer.materials.splice(OO, 1), this._parentContainer = null
          }
          if (!0 !== pO)
            if (this.meshMap)
              for (const bK in this.meshMap) {
                const OO = this.meshMap[bK];
                this._disposeMeshResources(OO)
              } else {
                const OO = XO.meshes;
                for (const KO of OO) this._disposeMeshResources(KO)
              }
          this._uniformBuffer.dispose(), this._drawWrapper.effect && (this._storeEffectOnSubMeshes || this._drawWrapper.effect.dispose(), this._drawWrapper.effect = null), this.metadata = null, this.cpO.notifyObservers(this), this.cpO.clear(), this._onBindObservable && this._onBindObservable.clear(), this._onUnBindObservable && this._onUnBindObservable.clear(), this._onEffectCreatedObservable && this._onEffectCreatedObservable.clear(), this._eventInfo && (this._eventInfo = {})
        }
        _disposeMeshResources(OO) {
          if (!OO) return;
          const KO = OO.geometry,
            pO = OO._internalAbstractMeshDataInfo._materialForRenderPass;
          if (this._storeEffectOnSubMeshes) {
            if (OO.au && pO)
              for (const XO of OO.au) {
                const OO = XO._drawWrappers;
                for (let bK = 0; bK < OO.length; bK++) {
                  const eO = OO[bK]?.effect;
                  if (!eO) continue;
                  pO[bK] === this && (KO?._releaseVertexArrayObject(eO), XO._removeDrawWrapper(bK, !0, !0))
                }
              }
          } else KO?._releaseVertexArrayObject(this._drawWrapper.effect);
          OO.material !== this || OO.SDO || (OO.material = null)
        }
        serialize() {
          const OO = oO.c.Serialize(this);
          return OO.stencil = this.stencil.serialize(), OO.uniqueId = this.uniqueId, this._serializePlugins(OO), OO
        }
        _serializePlugins(OO) {
          if (OO.plugins = {}, this.pluginManager)
            for (const KO of this.pluginManager._plugins) KO.doNotSerialize || (OO.plugins[KO.getClassName()] = KO.serialize())
        }
        static ParseAlphaMode(OO, KO) {
          void 0 !== OO._alphaMode ? KO._alphaMode = Array.isArray(OO._alphaMode) ? [...OO._alphaMode] : [OO._alphaMode] : void 0 !== OO.alphaMode ? KO._alphaMode = Array.isArray(OO.alphaMode) ? [...OO.alphaMode] : [OO.alphaMode] : KO._alphaMode = [2]
        }
        static Parse(KO, pO, XO) {
          if (KO.customType) {
            if ("BABYLON.PBRMaterial" === KO.customType && KO.overloadedAlbedo && (KO.customType = "BABYLON.LegacyPBRMaterial", !BABYLON.LegacyPBRMaterial)) return DO.b.Error("Your scene is trying to load a legacy version of the PBRMaterial, please, include it from the materials library."), null
          } else KO.customType = "BABYLON.StandardMaterial";
          const bK = eO.k.Instantiate(KO.customType).Parse(KO, pO, XO);
          return bK._loadedUniqueId = KO.uniqueId, OO.ParseAlphaMode(KO, bK), bK
        }
        static _ParsePlugins(OO, KO, pO, XO) {
          if (OO.plugins)
            for (const bK in OO.plugins) {
              const lO = OO.plugins[bK];
              let vK = KO.pluginManager?.getPlugin(lO.name);
              if (!vK) {
                const OO = eO.k.Instantiate("BABYLON." + bK);
                OO && (vK = new OO(KO))
              }
              vK?.parse(lO, pO, XO)
            }
        }
      }, (() => {
        const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], QO = [(0, bK.M)()], zK = [(0, bK.M)()], AO = [(0, bK.M)()], fO = [(0, bK.M)()], dO = [(0, bK.M)()], TO = [(0, bK.M)("alpha")], NO = [(0, bK.M)("backFaceCulling")], IO = [(0, bK.M)("textureRepetitionMode")], yK = [(0, bK.M)("textureRepetitionHexTilingParams")], gK = [(0, bK.M)("cullBackFaces")], uO = [(0, bK.M)()], EO = [(0, bK.M)()], jK = [(0, bK.M)()], YO = [(0, bK.M)()], wO = [(0, bK.M)()], iK = [(0, bK.M)()], rK = [(0, bK.M)()], PO = [(0, bK.M)()], mK = [(0, bK.M)("fogEnabled")], sO = [(0, bK.M)()], HO = [(0, bK.M)()], RO = [(0, bK.M)()], SO = [(0, bK.M)()], JO = [(0, bK.M)()], cK = [(0, bK.M)()], BO = [(0, bK.M)()], ZO = [(0, bK.M)()], (0, XO.f)(OO, null, SO, {
          kind: "getter",
          name: "pointsCloud",
          static: !1,
          private: !1,
          access: {
            has: OO => "pointsCloud" in OO,
            get: OO => OO.pointsCloud
          },
          metadata: eO
        }, null, GO), (0, XO.f)(OO, null, JO, {
          kind: "getter",
          name: "fillMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "fillMode" in OO,
            get: OO => OO.fillMode
          },
          metadata: eO
        }, null, GO), (0, XO.f)(OO, null, cK, {
          kind: "getter",
          name: "useLogarithmicDepth",
          static: !1,
          private: !1,
          access: {
            has: OO => "useLogarithmicDepth" in OO,
            get: OO => OO.useLogarithmicDepth
          },
          metadata: eO
        }, null, GO), (0, XO.f)(OO, null, ZO, {
          kind: "getter",
          name: "transparencyMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "transparencyMode" in OO,
            get: OO => OO.transparencyMode
          },
          metadata: eO
        }, null, GO), (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "id",
          static: !1,
          private: !1,
          access: {
            has: OO => "id" in OO,
            get: OO => OO.id,
            set: (OO, KO) => {
              OO.id = KO
            }
          },
          metadata: eO
        }, qK, xK), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "uniqueId",
          static: !1,
          private: !1,
          access: {
            has: OO => "uniqueId" in OO,
            get: OO => OO.uniqueId,
            set: (OO, KO) => {
              OO.uniqueId = KO
            }
          },
          metadata: eO
        }, nO, WO), (0, XO.f)(null, null, QO, {
          kind: "field",
          name: "name",
          static: !1,
          private: !1,
          access: {
            has: OO => "name" in OO,
            get: OO => OO.name,
            set: (OO, KO) => {
              OO.name = KO
            }
          },
          metadata: eO
        }, tK, kK), (0, XO.f)(null, null, zK, {
          kind: "field",
          name: "metadata",
          static: !1,
          private: !1,
          access: {
            has: OO => "metadata" in OO,
            get: OO => OO.metadata,
            set: (OO, KO) => {
              OO.metadata = KO
            }
          },
          metadata: eO
        }, UO, OK), (0, XO.f)(null, null, AO, {
          kind: "field",
          name: "checkReadyOnEveryCall",
          static: !1,
          private: !1,
          access: {
            has: OO => "checkReadyOnEveryCall" in OO,
            get: OO => OO.checkReadyOnEveryCall,
            set: (OO, KO) => {
              OO.checkReadyOnEveryCall = KO
            }
          },
          metadata: eO
        }, KK, pK), (0, XO.f)(null, null, fO, {
          kind: "field",
          name: "checkReadyOnlyOnce",
          static: !1,
          private: !1,
          access: {
            has: OO => "checkReadyOnlyOnce" in OO,
            get: OO => OO.checkReadyOnlyOnce,
            set: (OO, KO) => {
              OO.checkReadyOnlyOnce = KO
            }
          },
          metadata: eO
        }, XK, bp), (0, XO.f)(null, null, dO, {
          kind: "field",
          name: "state",
          static: !1,
          private: !1,
          access: {
            has: OO => "state" in OO,
            get: OO => OO.state,
            set: (OO, KO) => {
              OO.state = KO
            }
          },
          metadata: eO
        }, eK, lK), (0, XO.f)(null, null, TO, {
          kind: "field",
          name: "_alpha",
          static: !1,
          private: !1,
          access: {
            has: OO => "_alpha" in OO,
            get: OO => OO._alpha,
            set: (OO, KO) => {
              OO._alpha = KO
            }
          },
          metadata: eO
        }, vp, CK), (0, XO.f)(null, null, NO, {
          kind: "field",
          name: "_backFaceCulling",
          static: !1,
          private: !1,
          access: {
            has: OO => "_backFaceCulling" in OO,
            get: OO => OO._backFaceCulling,
            set: (OO, KO) => {
              OO._backFaceCulling = KO
            }
          },
          metadata: eO
        }, hK, DK), (0, XO.f)(null, null, IO, {
          kind: "field",
          name: "_textureRepetitionMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "_textureRepetitionMode" in OO,
            get: OO => OO._textureRepetitionMode,
            set: (OO, KO) => {
              OO._textureRepetitionMode = KO
            }
          },
          metadata: eO
        }, MK, ap), (0, XO.f)(null, null, yK, {
          kind: "field",
          name: "textureRepetitionHexTilingParams",
          static: !1,
          private: !1,
          access: {
            has: OO => "textureRepetitionHexTilingParams" in OO,
            get: OO => OO.textureRepetitionHexTilingParams,
            set: (OO, KO) => {
              OO.textureRepetitionHexTilingParams = KO
            }
          },
          metadata: eO
        }, oK, FK), (0, XO.f)(null, null, gK, {
          kind: "field",
          name: "_cullBackFaces",
          static: !1,
          private: !1,
          access: {
            has: OO => "_cullBackFaces" in OO,
            get: OO => OO._cullBackFaces,
            set: (OO, KO) => {
              OO._cullBackFaces = KO
            }
          },
          metadata: eO
        }, VK, LK), (0, XO.f)(null, null, uO, {
          kind: "field",
          name: "sideOrientation",
          static: !1,
          private: !1,
          access: {
            has: OO => "sideOrientation" in OO,
            get: OO => OO.sideOrientation,
            set: (OO, KO) => {
              OO.sideOrientation = KO
            }
          },
          metadata: eO
        }, QK, zp), (0, XO.f)(null, null, EO, {
          kind: "field",
          name: "_alphaMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "_alphaMode" in OO,
            get: OO => OO._alphaMode,
            set: (OO, KO) => {
              OO._alphaMode = KO
            }
          },
          metadata: eO
        }, AK, fK), (0, XO.f)(null, null, jK, {
          kind: "field",
          name: "_needDepthPrePass",
          static: !1,
          private: !1,
          access: {
            has: OO => "_needDepthPrePass" in OO,
            get: OO => OO._needDepthPrePass,
            set: (OO, KO) => {
              OO._needDepthPrePass = KO
            }
          },
          metadata: eO
        }, dK, TK), (0, XO.f)(null, null, YO, {
          kind: "field",
          name: "disableDepthWrite",
          static: !1,
          private: !1,
          access: {
            has: OO => "disableDepthWrite" in OO,
            get: OO => OO.disableDepthWrite,
            set: (OO, KO) => {
              OO.disableDepthWrite = KO
            }
          },
          metadata: eO
        }, NK, IK), (0, XO.f)(null, null, wO, {
          kind: "field",
          name: "disableColorWrite",
          static: !1,
          private: !1,
          access: {
            has: OO => "disableColorWrite" in OO,
            get: OO => OO.disableColorWrite,
            set: (OO, KO) => {
              OO.disableColorWrite = KO
            }
          },
          metadata: eO
        }, yp, gp), (0, XO.f)(null, null, iK, {
          kind: "field",
          name: "forceDepthWrite",
          static: !1,
          private: !1,
          access: {
            has: OO => "forceDepthWrite" in OO,
            get: OO => OO.forceDepthWrite,
            set: (OO, KO) => {
              OO.forceDepthWrite = KO
            }
          },
          metadata: eO
        }, uK, EK), (0, XO.f)(null, null, rK, {
          kind: "field",
          name: "depthFunction",
          static: !1,
          private: !1,
          access: {
            has: OO => "depthFunction" in OO,
            get: OO => OO.depthFunction,
            set: (OO, KO) => {
              OO.depthFunction = KO
            }
          },
          metadata: eO
        }, jp, YK), (0, XO.f)(null, null, PO, {
          kind: "field",
          name: "separateCullingPass",
          static: !1,
          private: !1,
          access: {
            has: OO => "separateCullingPass" in OO,
            get: OO => OO.separateCullingPass,
            set: (OO, KO) => {
              OO.separateCullingPass = KO
            }
          },
          metadata: eO
        }, wK, ip), (0, XO.f)(null, null, mK, {
          kind: "field",
          name: "_fogEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "_fogEnabled" in OO,
            get: OO => OO._fogEnabled,
            set: (OO, KO) => {
              OO._fogEnabled = KO
            }
          },
          metadata: eO
        }, rp, PK), (0, XO.f)(null, null, sO, {
          kind: "field",
          name: "pointSize",
          static: !1,
          private: !1,
          access: {
            has: OO => "pointSize" in OO,
            get: OO => OO.pointSize,
            set: (OO, KO) => {
              OO.pointSize = KO
            }
          },
          metadata: eO
        }, mp, sK), (0, XO.f)(null, null, HO, {
          kind: "field",
          name: "zOffset",
          static: !1,
          private: !1,
          access: {
            has: OO => "zOffset" in OO,
            get: OO => OO.zOffset,
            set: (OO, KO) => {
              OO.zOffset = KO
            }
          },
          metadata: eO
        }, HK, RK), (0, XO.f)(null, null, RO, {
          kind: "field",
          name: "zOffsetUnits",
          static: !1,
          private: !1,
          access: {
            has: OO => "zOffsetUnits" in OO,
            get: OO => OO.zOffsetUnits,
            set: (OO, KO) => {
              OO.zOffsetUnits = KO
            }
          },
          metadata: eO
        }, SK, JK), (0, XO.f)(null, null, BO, {
          kind: "field",
          name: "_isVertexOutputInvariant",
          static: !1,
          private: !1,
          access: {
            has: OO => "_isVertexOutputInvariant" in OO,
            get: OO => OO._isVertexOutputInvariant,
            set: (OO, KO) => {
              OO._isVertexOutputInvariant = KO
            }
          },
          metadata: eO
        }, cp, BK), eO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: eO
        })
      })(), OO.TriangleFillMode = 0, OO.WireFrameFillMode = 1, OO.PointFillMode = 2, OO.PointListDrawMode = 3, OO.LineListDrawMode = 4, OO.LineLoopDrawMode = 5, OO.LineStripDrawMode = 6, OO.TriangleStripDrawMode = 7, OO.TriangleFanDrawMode = 8, OO.ClockWiseSideOrientation = 0, OO.CounterClockWiseSideOrientation = 1, OO.ImageProcessingDirtyFlag = 64, OO.TextureDirtyFlag = 1, OO.LightDirtyFlag = 2, OO.FresnelDirtyFlag = 4, OO.AttributesDirtyFlag = 8, OO.MiscDirtyFlag = 16, OO.PrePassDirtyFlag = 32, OO.AllDirtyFlag = 127, OO.MATERIAL_OPAQUE = 0, OO.MATERIAL_ALPHATEST = 1, OO.MATERIAL_ALPHABLEND = 2, OO.MATERIAL_ALPHATESTANDBLEND = 3, OO.MATERIAL_NORMALBLENDMETHOD_WHITEOUT = 0, OO.MATERIAL_NORMALBLENDMETHOD_RNM = 1, OO.LIGHTFALLOFF_PHYSICAL = 0, OO.LIGHTFALLOFF_GLTF = 1, OO.LIGHTFALLOFF_STANDARD = 2, OO.OnEventObservable = new lO.e, OO.ForceVertexOutputInvariant = !1, OO._AllDirtyCallBack = OO => OO.markAllAsDirty(), OO._ImageProcessingDirtyCallBack = OO => OO.markAsImageProcessingDirty(), OO._TextureDirtyCallBack = OO => OO.markAsTexturesDirty(), OO._FresnelDirtyCallBack = OO => OO.markAsFresnelDirty(), OO._MiscDirtyCallBack = OO => OO.markAsMiscDirty(), OO._PrePassDirtyCallBack = OO => OO.markAsPrePassDirty(), OO._LightsDirtyCallBack = OO => OO.markAsLightDirty(), OO._AttributeDirtyCallBack = OO => OO.markAsAttributesDirty(), OO._FresnelAndMiscDirtyCallBack = KO => {
        OO._FresnelDirtyCallBack(KO), OO._MiscDirtyCallBack(KO)
      }, OO._TextureAndMiscDirtyCallBack = KO => {
        OO._TextureDirtyCallBack(KO), OO._MiscDirtyCallBack(KO)
      }, OO._DirtyCallbackArray = [], OO._RunDirtyCallBacks = KO => {
        for (const pO of OO._DirtyCallbackArray) pO(KO)
      }, OO
    })();
    Object.getOwnPropertyDescriptor(zK.prototype, "pluginManager") || Object.defineProperty(zK.prototype, "pluginManager", (0, QO.e)("Material", "pluginManager"))
  },
  38439: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(37962);
    class bK {
      static get DiffuseTextureEnabled() {
        return this._DiffuseTextureEnabled
      }
      static set DiffuseTextureEnabled(OO) {
        this._DiffuseTextureEnabled !== OO && (this._DiffuseTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get BaseWeightTextureEnabled() {
        return this._BaseWeightTextureEnabled
      }
      static set BaseWeightTextureEnabled(OO) {
        this._BaseWeightTextureEnabled !== OO && (this._BaseWeightTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get BaseDiffuseRoughnessTextureEnabled() {
        return this._BaseDiffuseRoughnessTextureEnabled
      }
      static set BaseDiffuseRoughnessTextureEnabled(OO) {
        this._BaseDiffuseRoughnessTextureEnabled !== OO && (this._BaseDiffuseRoughnessTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get DetailTextureEnabled() {
        return this._DetailTextureEnabled
      }
      static set DetailTextureEnabled(OO) {
        this._DetailTextureEnabled !== OO && (this._DetailTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get DecalMapEnabled() {
        return this._DecalMapEnabled
      }
      static set DecalMapEnabled(OO) {
        this._DecalMapEnabled !== OO && (this._DecalMapEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get AmbientTextureEnabled() {
        return this._AmbientTextureEnabled
      }
      static set AmbientTextureEnabled(OO) {
        this._AmbientTextureEnabled !== OO && (this._AmbientTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get OpacityTextureEnabled() {
        return this._OpacityTextureEnabled
      }
      static set OpacityTextureEnabled(OO) {
        this._OpacityTextureEnabled !== OO && (this._OpacityTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get ReflectionTextureEnabled() {
        return this._ReflectionTextureEnabled
      }
      static set ReflectionTextureEnabled(OO) {
        this._ReflectionTextureEnabled !== OO && (this._ReflectionTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get EmissiveTextureEnabled() {
        return this._EmissiveTextureEnabled
      }
      static set EmissiveTextureEnabled(OO) {
        this._EmissiveTextureEnabled !== OO && (this._EmissiveTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get SpecularTextureEnabled() {
        return this._SpecularTextureEnabled
      }
      static set SpecularTextureEnabled(OO) {
        this._SpecularTextureEnabled !== OO && (this._SpecularTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get BumpTextureEnabled() {
        return this._BumpTextureEnabled
      }
      static set BumpTextureEnabled(OO) {
        this._BumpTextureEnabled !== OO && (this._BumpTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get LightmapTextureEnabled() {
        return this._LightmapTextureEnabled
      }
      static set LightmapTextureEnabled(OO) {
        this._LightmapTextureEnabled !== OO && (this._LightmapTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get RefractionTextureEnabled() {
        return this._RefractionTextureEnabled
      }
      static set RefractionTextureEnabled(OO) {
        this._RefractionTextureEnabled !== OO && (this._RefractionTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get ColorGradingTextureEnabled() {
        return this._ColorGradingTextureEnabled
      }
      static set ColorGradingTextureEnabled(OO) {
        this._ColorGradingTextureEnabled !== OO && (this._ColorGradingTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get FresnelEnabled() {
        return this._FresnelEnabled
      }
      static set FresnelEnabled(OO) {
        this._FresnelEnabled !== OO && (this._FresnelEnabled = OO, XO.e.MarkAllMaterialsAsDirty(4))
      }
      static get ClearCoatTextureEnabled() {
        return this._ClearCoatTextureEnabled
      }
      static set ClearCoatTextureEnabled(OO) {
        this._ClearCoatTextureEnabled !== OO && (this._ClearCoatTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get ClearCoatBumpTextureEnabled() {
        return this._ClearCoatBumpTextureEnabled
      }
      static set ClearCoatBumpTextureEnabled(OO) {
        this._ClearCoatBumpTextureEnabled !== OO && (this._ClearCoatBumpTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get ClearCoatTintTextureEnabled() {
        return this._ClearCoatTintTextureEnabled
      }
      static set ClearCoatTintTextureEnabled(OO) {
        this._ClearCoatTintTextureEnabled !== OO && (this._ClearCoatTintTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get SheenTextureEnabled() {
        return this._SheenTextureEnabled
      }
      static set SheenTextureEnabled(OO) {
        this._SheenTextureEnabled !== OO && (this._SheenTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get AnisotropicTextureEnabled() {
        return this._AnisotropicTextureEnabled
      }
      static set AnisotropicTextureEnabled(OO) {
        this._AnisotropicTextureEnabled !== OO && (this._AnisotropicTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get ThicknessTextureEnabled() {
        return this._ThicknessTextureEnabled
      }
      static set ThicknessTextureEnabled(OO) {
        this._ThicknessTextureEnabled !== OO && (this._ThicknessTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get RefractionIntensityTextureEnabled() {
        return this._ThicknessTextureEnabled
      }
      static set RefractionIntensityTextureEnabled(OO) {
        this._RefractionIntensityTextureEnabled !== OO && (this._RefractionIntensityTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get TranslucencyIntensityTextureEnabled() {
        return this._TranslucencyIntensityTextureEnabled
      }
      static set TranslucencyIntensityTextureEnabled(OO) {
        this._TranslucencyIntensityTextureEnabled !== OO && (this._TranslucencyIntensityTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get TranslucencyColorTextureEnabled() {
        return this._TranslucencyColorTextureEnabled
      }
      static set TranslucencyColorTextureEnabled(OO) {
        this._TranslucencyColorTextureEnabled !== OO && (this._TranslucencyColorTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
      static get IridescenceTextureEnabled() {
        return this._IridescenceTextureEnabled
      }
      static set IridescenceTextureEnabled(OO) {
        this._IridescenceTextureEnabled !== OO && (this._IridescenceTextureEnabled = OO, XO.e.MarkAllMaterialsAsDirty(1))
      }
    }
    bK._DiffuseTextureEnabled = !0, bK._BaseWeightTextureEnabled = !0, bK._BaseDiffuseRoughnessTextureEnabled = !0, bK._DetailTextureEnabled = !0, bK._DecalMapEnabled = !0, bK._AmbientTextureEnabled = !0, bK._OpacityTextureEnabled = !0, bK._ReflectionTextureEnabled = !0, bK._EmissiveTextureEnabled = !0, bK._SpecularTextureEnabled = !0, bK._BumpTextureEnabled = !0, bK._LightmapTextureEnabled = !0, bK._RefractionTextureEnabled = !0, bK._ColorGradingTextureEnabled = !0, bK._FresnelEnabled = !0, bK._ClearCoatTextureEnabled = !0, bK._ClearCoatBumpTextureEnabled = !0, bK._ClearCoatTintTextureEnabled = !0, bK._SheenTextureEnabled = !0, bK._AnisotropicTextureEnabled = !0, bK._ThicknessTextureEnabled = !0, bK._RefractionIntensityTextureEnabled = !0, bK._TranslucencyIntensityTextureEnabled = !0, bK._TranslucencyColorTextureEnabled = !0, bK._IridescenceTextureEnabled = !0
  },
  38424: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => LO,
      B: () => fO,
      F: () => jK,
      G: () => dO,
      H: () => uO,
      L: () => EO,
      N: () => oO,
      R: () => aK,
      S: () => JO,
      V: () => mK,
      Z: () => rK,
      _: () => iK,
      bb: () => AO,
      c: () => wO,
      fb: () => YO,
      g: () => TO,
      hb: () => cK,
      i: () => MO,
      ib: () => BO,
      k: () => QO,
      mb: () => ZO,
      n: () => zK,
      nb: () => nO,
      r: () => gK,
      rb: () => qK,
      s: () => CO,
      ub: () => xK,
      vb: () => FO,
      w: () => VO
    });
    var XO = pO(37061),
      bK = pO(35653),
      eO = pO(38275),
      lO = pO(38431),
      vK = pO(38439);

    function CO(OO, KO, pO) {
      if (!OO || OO.LOGARITHMICDEPTH || OO.indexOf && OO.indexOf("LOGARITHMICDEPTH") >= 0) {
        const OO = pO.activeCamera;
        1 === OO.mode && XO.b.Error("Logarithmic depth is not compatible with orthographic cameras!", 20), KO.setFloat("logarithmicDepthConstant", 2 / (Math.log(OO.maxZ + 1) / Math.LN2))
      }
    }
    const hO = {
        r: 0,
        g: 0,
        b: 0
      },
      DO = {
        NUM_MORPH_INFLUENCERS: 0,
        NORMAL: !1,
        TANGENT: !1,
        UV: !1,
        UV2: !1,
        COLOR: !1
      };

    function MO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      pO && OO.fogEnabled && (!KO || KO.applyFog) && 0 !== OO.fogMode && (pO.setFloat4("vFogInfos", OO.fogMode, OO.fogStart, OO.fogEnd, OO.fogDensity), XO ? (OO.fogColor.toLinearSpaceToRef(hO, OO.qb().useExactSrgbConversions), pO.setColor3("vFogColor", hO)) : pO.setColor3("vFogColor", OO.fogColor))
    }

    function aK(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
      const MO = OO.numMaxInfluencers || OO.numInfluencers;
      return MO <= 0 ? 0 : (KO.push("#define MORPHTARGETS"), OO.hasPositions && KO.push("#define MORPHTARGETTEXTURE_HASPOSITIONS"), OO.hasNormals && KO.push("#define MORPHTARGETTEXTURE_HASNORMALS"), OO.hasTangents && KO.push("#define MORPHTARGETTEXTURE_HASTANGENTS"), OO.hasUVs && KO.push("#define MORPHTARGETTEXTURE_HASUVS"), OO.hasUV2s && KO.push("#define MORPHTARGETTEXTURE_HASUV2S"), OO.hasColors && KO.push("#define MORPHTARGETTEXTURE_HASCOLORS"), OO.supportsPositions && bK && KO.push("#define MORPHTARGETS_POSITION"), OO.supportsNormals && eO && KO.push("#define MORPHTARGETS_NORMAL"), OO.supportsTangents && lO && KO.push("#define MORPHTARGETS_TANGENT"), OO.supportsUVs && vK && KO.push("#define MORPHTARGETS_UV"), OO.supportsUV2s && CO && KO.push("#define MORPHTARGETS_UV2"), OO.supportsColors && hO && KO.push("#define MORPHTARGETS_COLOR"), KO.push("#define NUM_MORPH_INFLUENCERS " + MO), OO.isUsingTextureForTargets && KO.push("#define MORPHTARGETS_TEXTURE"), DO.NUM_MORPH_INFLUENCERS = MO, DO.NORMAL = eO, DO.TANGENT = lO, DO.UV = vK, DO.UV2 = CO, DO.COLOR = hO, oO(pO, XO, DO, bK), MO)
    }

    function oO(OO, KO, pO) {
      let eO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
      const lO = pO.NUM_MORPH_INFLUENCERS;
      if (lO > 0 && bK.c.LastCreatedEngine) {
        const vK = bK.c.LastCreatedEngine.getCaps().maxVertexAttribs,
          CO = KO.morphTargetManager;
        if (CO?.isUsingTextureForTargets) return;
        const hO = CO && CO.supportsPositions && eO,
          DO = CO && CO.supportsNormals && pO.NORMAL,
          MO = CO && CO.supportsTangents && pO.TANGENT,
          aK = CO && CO.supportsUVs && pO.UV1,
          oO = CO && CO.supportsUV2s && pO.UV2,
          FO = CO && CO.supportsColors && pO.VERTEXCOLOR;
        for (let pO = 0; pO < lO; pO++) hO && OO.push("position" + pO), DO && OO.push("normal" + pO), MO && OO.push("tangent" + pO), aK && OO.push("uv_" + pO), oO && OO.push("uv2_" + pO), FO && OO.push("color" + pO), OO.length > vK && XO.b.Error("Cannot add more vertex attributes for mesh " + KO.name)
      }
    }

    function FO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      OO.push("world0"), OO.push("world1"), OO.push("world2"), OO.push("world3"), KO && (OO.push("previousWorld0"), OO.push("previousWorld1"), OO.push("previousWorld2"), OO.push("previousWorld3"))
    }

    function VO(OO, KO) {
      const pO = OO.morphTargetManager;
      OO && pO && KO.setFloatArray("morphTargetInfluences", pO.influences)
    }

    function LO(OO, KO) {
      KO.bindToEffect(OO, "Scene")
    }

    function QO(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
        eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
        lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
        CO = arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
        hO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8],
        DO = arguments.length > 9 && void 0 !== arguments[9] && arguments[9],
        MO = arguments.length > 10 && void 0 !== arguments[10] && arguments[10],
        aK = arguments.length > 11 && void 0 !== arguments[11] ? arguments[11] : 0;
      if (OO.texturesEnabled && bK && vK.e.ReflectionTextureEnabled) {
        if (pO.AlO("reflectionMatrix", bK.getReflectionTextureMatrix()), pO.updateFloat2("vReflectionInfos", bK.level * OO.iblIntensity, aK), CO && bK.boundingBoxSize) {
          const OO = bK;
          pO.updateVector3("vReflectionPosition", OO.boundingBoxPosition), pO.updateVector3("vReflectionSize", OO.boundingBoxSize)
        }
        if (eO) {
          const OO = bK.getSize().width;
          pO.updateFloat2("vReflectionFilteringInfo", OO, Math.log2(OO))
        }
        if (DO && !KO.USEIRRADIANCEMAP) {
          const OO = bK.sphericalPolynomial;
          if (KO.USESPHERICALFROMREFLECTIONMAP && OO)
            if (KO.SPHERICAL_HARMONICS) {
              const KO = OO.preScaledHarmonics;
              pO.updateVector3("vSphericalL00", KO.l00), pO.updateVector3("vSphericalL1_1", KO.l1_1), pO.updateVector3("vSphericalL10", KO.l10), pO.updateVector3("vSphericalL11", KO.l11), pO.updateVector3("vSphericalL2_2", KO.l2_2), pO.updateVector3("vSphericalL2_1", KO.l2_1), pO.updateVector3("vSphericalL20", KO.l20), pO.updateVector3("vSphericalL21", KO.l21), pO.updateVector3("vSphericalL22", KO.l22)
            } else pO.updateFloat3("vSphericalX", OO.x.x, OO.x.y, OO.x.z), pO.updateFloat3("vSphericalY", OO.y.x, OO.y.y, OO.y.z), pO.updateFloat3("vSphericalZ", OO.z.x, OO.z.y, OO.z.z), pO.updateFloat3("vSphericalXX_ZZ", OO.xx.x - OO.zz.x, OO.xx.y - OO.zz.y, OO.xx.z - OO.zz.z), pO.updateFloat3("vSphericalYY_ZZ", OO.yy.x - OO.zz.x, OO.yy.y - OO.zz.y, OO.yy.z - OO.zz.z), pO.updateFloat3("vSphericalZZ", OO.zz.x, OO.zz.y, OO.zz.z), pO.updateFloat3("vSphericalXY", OO.xy.x, OO.xy.y, OO.xy.z), pO.updateFloat3("vSphericalYZ", OO.yz.x, OO.yz.y, OO.yz.z), pO.updateFloat3("vSphericalZX", OO.zx.x, OO.zx.y, OO.zx.z)
        } else hO && KO.USEIRRADIANCEMAP && KO.USE_IRRADIANCE_DOMINANT_DIRECTION && bK.irradianceTexture && pO.updateVector3("vReflectionDominantDirection", bK.irradianceTexture._dominantDirection);
        lO && pO.updateFloat3("vReflectionMicrosurfaceInfos", bK.getSize().width, bK.lodGenerationScale, bK.lodGenerationOffset)
      }
      MO && pO.updateColor3("vReflectionColor", XO)
    }

    function zK(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
        bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
      if (XO && vK.e.ReflectionTextureEnabled) {
        KO.LODBASEDMICROSFURACE ? pO.setTexture("reflectionSampler", XO) : (pO.setTexture("reflectionSampler", XO._lodTextureMid || XO), pO.setTexture("reflectionSamplerLow", XO._lodTextureLow || XO), pO.setTexture("reflectionSamplerHigh", XO._lodTextureHigh || XO)), KO.USEIRRADIANCEMAP && pO.setTexture("irradianceSampler", XO.irradianceTexture);
        const eO = OO.iblCdfGenerator;
        bK && eO && pO.setTexture("icdfSampler", eO.getIcdfTexture())
      }
    }

    function AO(OO, KO, pO) {
      KO._needUVs = !0, KO[pO] = !0, OO.optimizeUVAllocation && OO.getTextureMatrix().isIdentityAs3x2() ? (KO[pO + "DIRECTUV"] = OO.coordinatesIndex + 1, KO["MAINUV" + (OO.coordinatesIndex + 1)] = !0) : KO[pO + "DIRECTUV"] = 0
    }

    function fO(OO, KO, pO) {
      const XO = OO.getTextureMatrix();
      KO.AlO(pO + "Matrix", XO)
    }

    function dO(OO, KO, pO) {
      pO.BAKED_VERTEX_ANIMATION_TEXTURE && pO.INSTANCES && OO.push("bakedVertexAnimationSettingsInstanced")
    }

    function TO(OO, KO, pO) {
      var XO;
      if (KO && OO && (OO.computeBonesUsingShaders && KO._bonesComputationForcedToCPU && (OO.computeBonesUsingShaders = !1), OO.useBones && OO.computeBonesUsingShaders && OO.skeleton)) {
        const bK = OO.skeleton;
        if (bK.isUsingTextureForMatrices && KO.getUniformIndex("boneTextureInfo") > -1) {
          const pO = bK.getTransformMatrixTexture(OO);
          KO.setTexture("boneSampler", pO), KO.setFloat2("boneTextureInfo", bK._textureWidth, bK._textureHeight)
        } else {
          const eO = bK.getTransformMatrices(OO);
          eO && (KO.setMatrices("mBones", eO), pO && OO.JKO().prePassRenderer && OO.JKO().prePassRenderer.getIndex(2) && (pO.previousBones[OO.uniqueId] || (pO.previousBones[OO.uniqueId] = eO.slice()), KO.setMatrices("mPreviousBones", pO.previousBones[OO.uniqueId]), XO = eO, pO.previousBones[OO.uniqueId].set(XO)))
        }
      }
    }

    function NO(OO, KO, pO, XO, bK) {
      let eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5];
      OO._bindLight(KO, pO, XO, bK, eO)
    }
    const IO = 4,
      yK = new WeakMap;

    function gK(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 4;
      const eO = Math.min(KO.lightSources.length, bK);
      for (let lO = 0; lO < eO; lO++) {
        NO(KO.lightSources[lO], lO, OO, pO, "boolean" === typeof XO ? XO : XO.SPECULARTERM, KO.receiveShadows)
      }
    }

    function uO(OO, KO, pO, XO) {
      pO.NUM_BONE_INFLUENCERS > 0 && (XO.addCPUSkinningFallback(0, KO), OO.push("matricesIndices"), OO.push("matricesWeights"), pO.NUM_BONE_INFLUENCERS > 4 && (OO.push("matricesIndicesExtra"), OO.push("matricesWeightsExtra")))
    }

    function EO(OO, KO) {
      (KO.INSTANCES || KO.THIN_INSTANCES) && FO(OO, !!KO.PREPASS_VELOCITY), KO.INSTANCESCOLOR && OO.push("instanceColor")
    }

    function jK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 4,
        XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
        bK = 0;
      for (let eO = 0; eO < pO && OO["LIGHT" + eO]; eO++) eO > 0 && (bK = XO + eO, KO.addFallback(bK, "LIGHT" + eO)), OO.SHADOWS || (OO["SHADOW" + eO] && KO.addFallback(XO, "SHADOW" + eO), OO["SHADOWPCF" + eO] && KO.addFallback(XO, "SHADOWPCF" + eO), OO["SHADOWPCSS" + eO] && KO.addFallback(XO, "SHADOWPCSS" + eO), OO["SHADOWPOISSON" + eO] && KO.addFallback(XO, "SHADOWPOISSON" + eO), OO["SHADOWESM" + eO] && KO.addFallback(XO, "SHADOWESM" + eO), OO["SHADOWCLOSEESM" + eO] && KO.addFallback(XO, "SHADOWCLOSEESM" + eO));
      return bK
    }

    function YO(OO, KO, pO, XO, bK, eO, lO) {
      let vK = arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
        CO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8],
        hO = arguments.length > 9 ? arguments[9] : void 0,
        DO = arguments.length > 10 ? arguments[10] : void 0;
      if (lO._areMiscDirty) {
        lO.LOGARITHMICDEPTH = pO, lO.POINTSIZE = XO, lO.FOG = bK && function(OO, KO) {
          return KO.fogEnabled && OO.applyFog && 0 !== KO.fogMode
        }(OO, KO), lO.NONUNIFORMSCALING = OO.nonUniformScaling, lO.ALPHATEST = eO, lO.DECAL_AFTER_DETAIL = vK, lO.USE_VERTEX_PULLING = CO, lO.RIGHT_HANDED = KO.useRightHandedSystem;
        const MO = CO ? hO?.geometry?.getIndexBuffer() : null,
          aK = !!hO && hO.isUnIndexed;
        lO.VERTEX_PULLING_USE_INDEX_BUFFER = !!MO && !aK, lO.VERTEX_PULLING_INDEX_BUFFER_32BITS = !(!MO || aK) && MO.is32Bits, lO.VERTEXOUTPUT_INVARIANT = !!DO
      }
    }

    function wO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      if (!OO.lightsEnabled || XO) return !0;
      const bK = KO.lightSources,
        eO = Math.min(bK.length, pO);
      for (let lO = 0; lO < eO; lO++)
        if (!bK[lO].areLightTexturesReady()) return !1;
      return !0
    }

    function iK(OO, KO, pO, bK) {
      let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 4,
        lO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
      if (!pO._areLightsDirty) return pO._needNormals;
      const vK = eO;
      eO = function(OO, KO) {
        const pO = OO.qb().getCaps().maxUniformBuffersPerShaderStage;
        if (null == pO) return KO;
        const XO = Math.max(pO - IO, 1);
        return Math.min(KO, XO)
      }(OO, eO);
      let CO = 0;
      const hO = {
        needNormals: pO._needNormals,
        needRebuild: !1,
        lightmapMode: !1,
        shadowEnabled: !1,
        specularEnabled: !1
      };
      if (OO.lightsEnabled && !lO) {
        KO.lightSources.length > eO && eO < vK && function(OO, KO, pO, bK) {
          let eO = yK.get(OO);
          eO || (eO = new Set, yK.set(OO, eO)), eO.has(bK) || (eO.add(bK), XO.b.Warn(`maxSimultaneousLights is ${KO} but this engine supports at most ${pO} simultaneous lights. Each light declares its own uniform buffer in the vertex shader, so the ${bK} lights affecting this mesh plus the scene, mesh, material and leftover buffers would need ${bK+IO} uniform buffers, over the device limit of ${OO.getCaps().maxUniformBuffersPerShaderStage} per shader stage. The light count has been clamped to ${pO}, so the extra lights will not contribute to the render. Set maxSimultaneousLights to ${pO} or less to silence this warning.`))
        }(OO.qb(), vK, eO, Math.min(KO.lightSources.length, vK));
        for (const XO of KO.lightSources)
          if (PO(OO, KO, XO, CO, pO, bK, hO), CO++, CO === eO) break
      }
      pO.SPECULARTERM = hO.specularEnabled, pO.SHADOWS = hO.shadowEnabled;
      const DO = Math.max(eO, pO.MAXLIGHTCOUNT || 0);
      for (let XO = CO; XO < DO; XO++) void 0 !== pO["LIGHT" + XO] && (pO["LIGHT" + XO] = !1, pO["HEMILIGHT" + XO] = !1, pO["POINTLIGHT" + XO] = !1, pO["DIRLIGHT" + XO] = !1, pO["SPOTLIGHT" + XO] = !1, pO["AREALIGHT" + XO] = !1, pO["CLUSTLIGHT" + XO] = !1, pO["SHADOW" + XO] = !1, pO["SHADOWCSM" + XO] = !1, pO["SHADOWCSMDEBUG" + XO] = !1, pO["SHADOWCSMNUM_CASCADES" + XO] = !1, pO["SHADOWCSMUSESHADOWMAXZ" + XO] = !1, pO["SHADOWCSMNOBLEND" + XO] = !1, pO["SHADOWCSM_RIGHTHANDED" + XO] = !1, pO["SHADOWPCF" + XO] = !1, pO["SHADOWPCSS" + XO] = !1, pO["SHADOWPOISSON" + XO] = !1, pO["SHADOWESM" + XO] = !1, pO["SHADOWCLOSEESM" + XO] = !1, pO["SHADOWCUBE" + XO] = !1, pO["SHADOWLOWQUALITY" + XO] = !1, pO["SHADOWMEDIUMQUALITY" + XO] = !1);
      pO.LIGHTCOUNT = CO, pO.MAXLIGHTCOUNT = eO;
      const MO = OO.qb().getCaps();
      return void 0 === pO.SHADOWFLOAT && (hO.needRebuild = !0), pO.SHADOWFLOAT = hO.shadowEnabled && (MO.textureFloatRender && MO.textureFloatLinearFiltering || MO.textureHalfFloatRender && MO.textureHalfFloatLinearFiltering), pO.LIGHTMAPEXCLUDED = hO.lightmapMode, hO.needRebuild && pO.rebuild(), hO.needNormals
    }

    function rK(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 8,
        eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
      if (KO && vK.e.ReflectionTextureEnabled) {
        if (!KO.isReadyOrNotBlocking()) return !1;
        pO._needNormals = !0, pO.REFLECTION = !0, pO.GAMMAREFLECTION = KO.gammaSpace, pO.RGBDREFLECTION = KO.isRGBD, pO.LODINREFLECTIONALPHA = KO.lodLevelInAlpha, pO.LINEARSPECULARREFLECTION = KO.linearSpecularLOD, pO.USEIRRADIANCEMAP = !1, pO.LODBASEDMICROSFURACE = OO.qb().getCaps().textureLOD;
        const lO = OO.qb();
        switch (XO && bK > 0 ? (pO.NUM_SAMPLES = "" + bK, lO._features.needTypeSuffixInShaderConstants && (pO.NUM_SAMPLES = pO.NUM_SAMPLES + "u"), pO.REALTIME_FILTERING = !0, OO.iblCdfGenerator && (pO.IBL_CDF_FILTERING = !0)) : pO.REALTIME_FILTERING = !1, pO.INVERTCUBICMAP = 6 === KO.coordinatesMode, pO.REFLECTIONMAP_3D = KO.isCube, pO.REFLECTIONMAP_OPPOSITEZ = pO.REFLECTIONMAP_3D && OO.useRightHandedSystem ? !KO.invertZ : KO.invertZ, pO.REFLECTIONMAP_CUBIC = !1, pO.REFLECTIONMAP_EXPLICIT = !1, pO.REFLECTIONMAP_PLANAR = !1, pO.REFLECTIONMAP_PROJECTION = !1, pO.REFLECTIONMAP_SKYBOX = !1, pO.REFLECTIONMAP_SPHERICAL = !1, pO.REFLECTIONMAP_EQUIRECTANGULAR = !1, pO.REFLECTIONMAP_EQUIRECTANGULAR_FIXED = !1, pO.REFLECTIONMAP_MIRROREDEQUIRECTANGULAR_FIXED = !1, KO.coordinatesMode) {
          case 0:
            pO.REFLECTIONMAP_EXPLICIT = !0;
            break;
          case 2:
            pO.REFLECTIONMAP_PLANAR = !0;
            break;
          case 4:
            pO.REFLECTIONMAP_PROJECTION = !0;
            break;
          case 5:
            pO.REFLECTIONMAP_SKYBOX = !0;
            break;
          case 1:
            pO.REFLECTIONMAP_SPHERICAL = !0;
            break;
          case 7:
            pO.REFLECTIONMAP_EQUIRECTANGULAR = !0;
            break;
          case 8:
            pO.REFLECTIONMAP_EQUIRECTANGULAR_FIXED = !0;
            break;
          case 9:
            pO.REFLECTIONMAP_MIRROREDEQUIRECTANGULAR_FIXED = !0;
            break;
          default:
            pO.REFLECTIONMAP_CUBIC = !0, pO.USE_LOCAL_REFLECTIONMAP_CUBIC = !!KO.boundingBoxSize
        }
        5 !== KO.coordinatesMode && (KO.irradianceTexture ? (pO.USEIRRADIANCEMAP = !0, pO.USESPHERICALFROMREFLECTIONMAP = !1, pO.USESPHERICALINVERTEX = !1, KO.irradianceTexture._dominantDirection ? pO.USE_IRRADIANCE_DOMINANT_DIRECTION = !0 : pO.USE_IRRADIANCE_DOMINANT_DIRECTION = !1) : KO.isCube && (pO.USESPHERICALFROMREFLECTIONMAP = !0, pO.USEIRRADIANCEMAP = !1, pO.USE_IRRADIANCE_DOMINANT_DIRECTION = !1, pO.USESPHERICALINVERTEX = eO))
      } else pO.REFLECTION = !1, pO.REFLECTIONMAP_3D = !1, pO.REFLECTIONMAP_SPHERICAL = !1, pO.REFLECTIONMAP_PLANAR = !1, pO.REFLECTIONMAP_CUBIC = !1, pO.USE_LOCAL_REFLECTIONMAP_CUBIC = !1, pO.REFLECTIONMAP_PROJECTION = !1, pO.REFLECTIONMAP_SKYBOX = !1, pO.REFLECTIONMAP_EXPLICIT = !1, pO.REFLECTIONMAP_EQUIRECTANGULAR = !1, pO.REFLECTIONMAP_EQUIRECTANGULAR_FIXED = !1, pO.REFLECTIONMAP_MIRROREDEQUIRECTANGULAR_FIXED = !1, pO.INVERTCUBICMAP = !1, pO.USESPHERICALFROMREFLECTIONMAP = !1, pO.USEIRRADIANCEMAP = !1, pO.USE_IRRADIANCE_DOMINANT_DIRECTION = !1, pO.USESPHERICALINVERTEX = !1, pO.REFLECTIONMAP_OPPOSITEZ = !1, pO.LODINREFLECTIONALPHA = !1, pO.GAMMAREFLECTION = !1, pO.RGBDREFLECTION = !1, pO.LINEARSPECULARREFLECTION = !1;
      return !0
    }

    function PO(OO, KO, pO, XO, bK, lO, vK) {
      switch (vK.needNormals = !0, void 0 === bK["LIGHT" + XO] && (vK.needRebuild = !0), bK["LIGHT" + XO] = !0, bK["SPOTLIGHT" + XO] = !1, bK["HEMILIGHT" + XO] = !1, bK["POINTLIGHT" + XO] = !1, bK["DIRLIGHT" + XO] = !1, bK["AREALIGHT" + XO] = !1, bK["CLUSTLIGHT" + XO] = !1, pO.prepareLightSpecificDefines(bK, XO), bK["LIGHT_FALLOFF_PHYSICAL" + XO] = !1, bK["LIGHT_FALLOFF_GLTF" + XO] = !1, bK["LIGHT_FALLOFF_STANDARD" + XO] = !1, pO.falloffType) {
        case eO.e.FALLOFF_GLTF:
          bK["LIGHT_FALLOFF_GLTF" + XO] = !0;
          break;
        case eO.e.FALLOFF_PHYSICAL:
          bK["LIGHT_FALLOFF_PHYSICAL" + XO] = !0;
          break;
        case eO.e.FALLOFF_STANDARD:
          bK["LIGHT_FALLOFF_STANDARD" + XO] = !0
      }
      if (lO && !pO.specular.equalsFloats(0, 0, 0) && (vK.specularEnabled = !0), bK["SHADOW" + XO] = !1, bK["SHADOWCSM" + XO] = !1, bK["SHADOWCSMDEBUG" + XO] = !1, bK["SHADOWCSMNUM_CASCADES" + XO] = !1, bK["SHADOWCSMUSESHADOWMAXZ" + XO] = !1, bK["SHADOWCSMNOBLEND" + XO] = !1, bK["SHADOWCSM_RIGHTHANDED" + XO] = !1, bK["SHADOWPCF" + XO] = !1, bK["SHADOWPCSS" + XO] = !1, bK["SHADOWPOISSON" + XO] = !1, bK["SHADOWESM" + XO] = !1, bK["SHADOWCLOSEESM" + XO] = !1, bK["SHADOWCUBE" + XO] = !1, bK["SHADOWLOWQUALITY" + XO] = !1, bK["SHADOWMEDIUMQUALITY" + XO] = !1, KO && KO.receiveShadows && OO.shadowsEnabled && pO.shadowEnabled) {
        const KO = pO.getShadowGenerator(OO.activeCamera) ?? pO.getShadowGenerator();
        if (KO) {
          const OO = KO.getShadowMap();
          OO && OO.renderList && OO.renderList.length > 0 && (vK.shadowEnabled = !0, KO.prepareDefines(bK, XO))
        }
      }
      pO.lightmapMode != eO.e.LIGHTMAP_DEFAULT ? (vK.lightmapMode = !0, bK["LIGHTMAPEXCLUDED" + XO] = !0, bK["LIGHTMAPNOSPECULAR" + XO] = pO.lightmapMode == eO.e.LIGHTMAP_SHADOWSONLY) : (bK["LIGHTMAPEXCLUDED" + XO] = !1, bK["LIGHTMAPNOSPECULAR" + XO] = !1)
    }

    function mK(OO, KO, pO, XO, bK) {
      let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
        vK = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
        CO = function(OO, KO) {
          let pO = !1;
          if (OO.activeCamera) {
            const XO = KO.CAMERA_ORTHOGRAPHIC ? 1 : 0,
              bK = KO.CAMERA_PERSPECTIVE ? 1 : 0,
              eO = 1 === OO.activeCamera.mode ? 1 : 0,
              lO = 0 === OO.activeCamera.mode ? 1 : 0;
            (XO ^ eO || bK ^ lO) && (KO.CAMERA_ORTHOGRAPHIC = 1 === eO, KO.CAMERA_PERSPECTIVE = 1 === lO, pO = !0)
          }
          return pO
        }(OO, XO);
      !1 !== eO && (CO = (0, lO.i)(pO, OO, XO)), XO.DEPTHPREPASS !== !KO.getColorWrite() && (XO.DEPTHPREPASS = !XO.DEPTHPREPASS, CO = !0), XO.INSTANCES !== bK && (XO.INSTANCES = bK, CO = !0), XO.THIN_INSTANCES !== vK && (XO.THIN_INSTANCES = vK, CO = !0), CO && XO.markAsUnprocessed()
    }
    const sO = 40,
      HO = 64,
      RO = new WeakMap,
      SO = new WeakSet;

    function JO(OO, KO, pO, bK) {
      let eO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
        lO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
        vK = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6];
      if (!KO._areAttributesDirty && KO._needNormals === KO._normals && KO._needUVs === KO._uvs) return !1;
      KO._normals = KO._needNormals, KO._uvs = KO._needUVs, KO.NORMAL = KO._needNormals && OO.isVerticesDataPresent("normal"), KO._needNormals && OO.isVerticesDataPresent("tangent") && (KO.TANGENT = !0);
      for (let XO = 1; XO <= 6; ++XO) KO["UV" + XO] = !!KO._needUVs && OO.isVerticesDataPresent(`uv${1===XO?"":XO}`);
      if (pO) {
        const pO = OO.useVertexColors && OO.isVerticesDataPresent("color");
        KO.VERTEXCOLOR = pO, KO.VERTEXALPHA = OO.hasVertexAlpha && pO && lO
      }
      return OO.isVerticesDataPresent("instanceColor") && (OO.RDO || OO.hasThinInstances) && (KO.INSTANCESCOLOR = !0), bK && function(OO, KO) {
        if (OO.useBones && OO.computeBonesUsingShaders && OO.skeleton) {
          KO.NUM_BONE_INFLUENCERS = OO.numBoneInfluencers;
          const pO = void 0 !== KO.BONETEXTURE;
          if (OO.skeleton.isUsingTextureForMatrices && pO) KO.BONETEXTURE = !0;
          else {
            KO.BonesPerMesh = OO.skeleton.bones.length + 1, KO.BONETEXTURE = !pO && void 0;
            const bK = OO.JKO(),
              eO = bK.prePassRenderer;
            if (eO && eO.enabled) {
              const pO = -1 === eO.excludedSkinnedMesh.indexOf(OO);
              KO.BONES_VELOCITY_ENABLED = pO
            }
            const lO = !0 === KO.MULTIVIEW,
              vK = 2 * KO.BonesPerMesh + (lO ? 1 : 0);
            if (RO.get(OO.skeleton) !== vK) {
              RO.set(OO.skeleton, vK);
              const pO = bK.qb().getCaps().maxVertexUniformVectors;
              if (pO && !SO.has(OO.skeleton)) {
                const bK = 4 * KO.BonesPerMesh,
                  eO = lO ? HO : sO,
                  vK = Math.max(pO - eO, 0);
                (bK > vK || lO && 3 * bK > pO) && (SO.add(OO.skeleton), XO.b.Warn(`Skeleton "${OO.skeleton.name}": ${OO.skeleton.bones.length} bones stored as vertex uniforms use ${bK} of ~${vK} usable uniform vectors${lO?" (multiview)":""} on a device reporting ${pO}. This can exceed the GPU vertex-uniform limit and make the mesh silently fail to render. Set skeleton.useTextureToStoreBoneMatrices = true to store bone matrices in a texture.`))
              }
            }
          }
        } else KO.NUM_BONE_INFLUENCERS = 0, KO.BonesPerMesh = 0, void 0 !== KO.BONETEXTURE && (KO.BONETEXTURE = !1)
      }(OO, KO), eO && function(OO, KO) {
        const pO = OO.morphTargetManager;
        pO ? (KO.MORPHTARGETS_UV = pO.supportsUVs && KO.UV1, KO.MORPHTARGETS_UV2 = pO.supportsUV2s && KO.UV2, KO.MORPHTARGETS_TANGENT = pO.supportsTangents && KO.TANGENT, KO.MORPHTARGETS_NORMAL = pO.supportsNormals && KO.NORMAL, KO.MORPHTARGETS_POSITION = pO.supportsPositions, KO.MORPHTARGETS_COLOR = pO.supportsColors, KO.MORPHTARGETTEXTURE_HASUVS = pO.hasUVs, KO.MORPHTARGETTEXTURE_HASUV2S = pO.hasUV2s, KO.MORPHTARGETTEXTURE_HASTANGENTS = pO.hasTangents, KO.MORPHTARGETTEXTURE_HASNORMALS = pO.hasNormals, KO.MORPHTARGETTEXTURE_HASPOSITIONS = pO.hasPositions, KO.MORPHTARGETTEXTURE_HASCOLORS = pO.hasColors, KO.NUM_MORPH_INFLUENCERS = pO.numMaxInfluencers || pO.numInfluencers, KO.MORPHTARGETS = KO.NUM_MORPH_INFLUENCERS > 0, KO.MORPHTARGETS_TEXTURE = pO.isUsingTextureForTargets) : (KO.MORPHTARGETS_UV = !1, KO.MORPHTARGETS_UV2 = !1, KO.MORPHTARGETS_TANGENT = !1, KO.MORPHTARGETS_NORMAL = !1, KO.MORPHTARGETS_POSITION = !1, KO.MORPHTARGETS_COLOR = !1, KO.MORPHTARGETTEXTURE_HASUVS = !1, KO.MORPHTARGETTEXTURE_HASUV2S = !1, KO.MORPHTARGETTEXTURE_HASTANGENTS = !1, KO.MORPHTARGETTEXTURE_HASNORMALS = !1, KO.MORPHTARGETTEXTURE_HASPOSITIONS = !1, KO.MORPHTARGETTEXTURE_HAS_COLORS = !1, KO.MORPHTARGETS = !1, KO.NUM_MORPH_INFLUENCERS = 0)
      }(OO, KO), vK && function(OO, KO) {
        const pO = OO.bakedVertexAnimationManager;
        KO.BAKED_VERTEX_ANIMATION_TEXTURE = !(!pO || !pO.isEnabled)
      }(OO, KO), !0
    }

    function cK(OO, KO) {
      if (OO.activeCamera) {
        const pO = KO.MULTIVIEW;
        KO.MULTIVIEW = null !== OO.activeCamera.outputRenderTarget && OO.activeCamera.outputRenderTarget.getViewCount() > 1, KO.MULTIVIEW != pO && KO.markAsUnprocessed()
      }
    }

    function BO(OO, KO, pO) {
      const XO = KO.ORDER_INDEPENDENT_TRANSPARENCY,
        bK = KO.ORDER_INDEPENDENT_TRANSPARENCY_16BITS;
      KO.ORDER_INDEPENDENT_TRANSPARENCY = OO.useOrderIndependentTransparency && pO, KO.ORDER_INDEPENDENT_TRANSPARENCY_16BITS = !OO.qb().getCaps().textureFloatLinearFiltering, XO === KO.ORDER_INDEPENDENT_TRANSPARENCY && bK === KO.ORDER_INDEPENDENT_TRANSPARENCY_16BITS || KO.markAsUnprocessed()
    }

    function ZO(OO, KO, pO) {
      const XO = KO.PREPASS;
      if (!KO._arePrePassDirty) return;
      const bK = [{
        type: 1,
        define: "PREPASS_POSITION",
        index: "PREPASS_POSITION_INDEX"
      }, {
        type: 9,
        define: "PREPASS_LOCAL_POSITION",
        index: "PREPASS_LOCAL_POSITION_INDEX"
      }, {
        type: 2,
        define: "PREPASS_VELOCITY",
        index: "PREPASS_VELOCITY_INDEX"
      }, {
        type: 11,
        define: "PREPASS_VELOCITY_LINEAR",
        index: "PREPASS_VELOCITY_LINEAR_INDEX"
      }, {
        type: 3,
        define: "PREPASS_REFLECTIVITY",
        index: "PREPASS_REFLECTIVITY_INDEX"
      }, {
        type: 0,
        define: "PREPASS_IRRADIANCE_LEGACY",
        index: "PREPASS_IRRADIANCE_LEGACY_INDEX"
      }, {
        type: 7,
        define: "PREPASS_ALBEDO_SQRT",
        index: "PREPASS_ALBEDO_SQRT_INDEX"
      }, {
        type: 5,
        define: "PREPASS_DEPTH",
        index: "PREPASS_DEPTH_INDEX"
      }, {
        type: 10,
        define: "PREPASS_SCREENSPACE_DEPTH",
        index: "PREPASS_SCREENSPACE_DEPTH_INDEX"
      }, {
        type: 6,
        define: "PREPASS_NORMAL",
        index: "PREPASS_NORMAL_INDEX"
      }, {
        type: 8,
        define: "PREPASS_WORLD_NORMAL",
        index: "PREPASS_WORLD_NORMAL_INDEX"
      }, {
        type: 14,
        define: "PREPASS_IRRADIANCE",
        index: "PREPASS_IRRADIANCE_INDEX"
      }];
      if (OO.prePassRenderer && OO.prePassRenderer.enabled && pO) {
        KO.PREPASS = !0, KO.SCENE_MRT_COUNT = OO.prePassRenderer.mrtCount, KO.PREPASS_NORMAL_WORLDSPACE = OO.prePassRenderer.generateNormalsInWorldSpace, KO.PREPASS_COLOR = !0, KO.PREPASS_COLOR_INDEX = 0;
        for (let pO = 0; pO < bK.length; pO++) {
          const XO = OO.prePassRenderer.getIndex(bK[pO].type); - 1 !== XO ? (KO[bK[pO].define] = !0, KO[bK[pO].index] = XO) : KO[bK[pO].define] = !1
        }
      } else {
        KO.PREPASS = !1;
        for (let OO = 0; OO < bK.length; OO++) KO[bK[OO].define] = !1
      }
      KO.PREPASS != XO && (KO.markAsUnprocessed(), KO.markAsImageProcessingDirty())
    }

    function GO(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null,
        eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
        lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6],
        vK = arguments.length > 7 && void 0 !== arguments[7] && arguments[7],
        CO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8],
        hO = arguments.length > 9 && void 0 !== arguments[9] && arguments[9];
      bK && bK.push("Light" + OO), eO || (KO.push("vLightData" + OO, "vLightDiffuse" + OO, "vLightSpecular" + OO, "vLightDirection" + OO, "vLightWidth" + OO, "vLightHeight" + OO, "vLightFalloff" + OO, "vLightGround" + OO, "vSliceData" + OO, "vSliceRanges" + OO, "lightMatrix" + OO, "shadowsInfo" + OO, "depthValues" + OO), pO.push("shadowTexture" + OO), pO.push("depthTexture" + OO), KO.push("viewFrustumZ" + OO, "cascadeBlendFactor" + OO, "lightSizeUVCorrection" + OO, "depthCorrection" + OO, "penumbraDarkness" + OO, "frustumLengths" + OO), XO && (pO.push("projectionLightTexture" + OO), KO.push("textureProjectionMatrix" + OO)), lO && pO.push("iesLightTexture" + OO), CO && pO.push("rectAreaLightEmissionTexture" + OO), vK && (pO.push("lightDataTexture" + OO), hO || pO.push("tileMaskTexture" + OO)))
    }

    function qK(OO, KO, pO) {
      const XO = ["vReflectionMicrosurfaceInfos", "vReflectionDominantDirection", "reflectionMatrix", "vReflectionInfos", "vReflectionPosition", "vReflectionSize", "vReflectionColor", "vReflectionFilteringInfo"];
      pO && XO.push("vSphericalX", "vSphericalY", "vSphericalZ", "vSphericalXX_ZZ", "vSphericalYY_ZZ", "vSphericalZZ", "vSphericalXY", "vSphericalYZ", "vSphericalZX", "vSphericalL00", "vSphericalL1_1", "vSphericalL10", "vSphericalL11", "vSphericalL2_2", "vSphericalL2_1", "vSphericalL20", "vSphericalL21", "vSphericalL22"), OO.push(...XO);
      KO.push("reflectionSampler", "reflectionSamplerLow", "reflectionSamplerHigh", "irradianceSampler", "icdfSampler")
    }

    function xK(OO, KO, pO) {
      let XO, bK, eO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 4,
        lO = null;
      if (OO.uniformsNames) {
        const vK = OO;
        XO = vK.uniformsNames, bK = vK.uniformBuffersNames, KO = vK.samplers, pO = vK.defines, eO = vK.maxSimultaneousLights || 0, lO = vK.shaderLanguage ?? null
      } else XO = OO, KO || (KO = []);
      for (let vK = 0; vK < eO && pO["LIGHT" + vK]; vK++) GO(vK, XO, KO, pO["PROJECTEDLIGHTTEXTURE" + vK], bK, !1, pO["IESLIGHTTEXTURE" + vK], pO["CLUSTLIGHT" + vK], pO["RECTAREALIGHTEMISSIONTEXTURE" + vK], 1 === lO);
      pO.NUM_MORPH_INFLUENCERS && (XO.push("morphTargetInfluences"), XO.push("morphTargetCount")), pO.BAKED_VERTEX_ANIMATION_TEXTURE && (XO.push("bakedVertexAnimationSettings"), XO.push("bakedVertexAnimationTextureSizeInverted"), XO.push("bakedVertexAnimationTime"), KO.push("bakedVertexAnimationTexture"))
    }

    function nO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
        pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
        XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
        bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
        eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
      OO.addUniform("vReflectionInfos", 2), OO.addUniform("reflectionMatrix", 16), KO && OO.addUniform("vReflectionMicrosurfaceInfos", 3), pO && (OO.addUniform("vReflectionPosition", 3), OO.addUniform("vReflectionSize", 3)), XO && (OO.addUniform("vReflectionFilteringInfo", 2), OO.addUniform("vReflectionDominantDirection", 3)), eO && OO.addUniform("vReflectionColor", 3), bK && (OO.addUniform("vSphericalL00", 3), OO.addUniform("vSphericalL1_1", 3), OO.addUniform("vSphericalL10", 3), OO.addUniform("vSphericalL11", 3), OO.addUniform("vSphericalL2_2", 3), OO.addUniform("vSphericalL2_1", 3), OO.addUniform("vSphericalL20", 3), OO.addUniform("vSphericalL21", 3), OO.addUniform("vSphericalL22", 3), OO.addUniform("vSphericalX", 3), OO.addUniform("vSphericalY", 3), OO.addUniform("vSphericalZ", 3), OO.addUniform("vSphericalXX_ZZ", 3), OO.addUniform("vSphericalYY_ZZ", 3), OO.addUniform("vSphericalZZ", 3), OO.addUniform("vSphericalXY", 3), OO.addUniform("vSphericalYZ", 3), OO.addUniform("vSphericalZX", 3))
    }
  },
  38447: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(35632),
      bK = pO(38382);
    class eO extends bK.b {
      constructor(OO, KO) {
        let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        super(OO, KO, void 0, arguments.length > 3 && void 0 !== arguments[3] && arguments[3]), this._normalMatrix = new XO.c, this._storeEffectOnSubMeshes = pO
      }
      getEffect() {
        return this._storeEffectOnSubMeshes ? this._activeEffect : super.getEffect()
      }
      isReady(OO, KO) {
        return !!OO && (!this._storeEffectOnSubMeshes || (!OO.au || 0 === OO.au.length || this.isReadyForSubMesh(OO, OO.au[0], KO)))
      }
      _isReadyForSubMesh(OO) {
        const KO = OO.materialDefines;
        return !(this.checkReadyOnEveryCall || !OO.effect || !KO || KO._renderId !== this.JKO().getRenderId())
      }
      bindOnlyWorldMatrix(OO) {
        this._activeEffect.setMatrix("world", OO)
      }
      bindOnlyNormalMatrix(OO) {
        this._activeEffect.setMatrix("normalMatrix", OO)
      }
      bind(OO, KO) {
        KO && this.bindForSubMesh(OO, KO, KO.au[0])
      }
      _afterBind(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        super._afterBind(OO, KO, pO), this.JKO()._cachedEffect = KO, pO ? pO._drawWrapper._forceRebindOnNextCall = !1 : this._drawWrapper._forceRebindOnNextCall = !1
      }
      _mustRebind(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1;
        return pO._drawWrapper._forceRebindOnNextCall || OO.isCachedMaterialInvalid(this, KO, XO)
      }
      dispose(OO, KO, pO) {
        this._activeEffect = void 0, super.dispose(OO, KO, pO)
      }
    }
  },
  38460: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      e: () => bK
    });
    const XO = new WeakMap;

    function bK(OO) {
      const KO = OO.getVertexBuffers();
      if (!KO) return null;
      let pO = XO.get(OO);
      if (pO) {
        let OO = !1;
        for (const XO in KO)
          if (!pO.has(XO)) {
            OO = !0;
            break
          } if (!OO) return pO
      } else pO = new Map, XO.set(OO, pO);
      for (const XO in KO) {
        const OO = KO[XO];
        if (OO) {
          const KO = OO.byteOffset,
            bK = OO.byteStride,
            eO = OO.type,
            lO = OO.normalized;
          pO.set(XO, {
            offset: KO,
            stride: bK,
            type: eO,
            normalized: lO
          })
        }
      }
      return pO
    }

    function eO(OO, KO) {
      KO.forEach(((KO, pO) => {
        const XO = `vp_${pO}_info`;
        OO.setFloat4(XO, KO.offset, KO.stride, KO.type, KO.normalized ? 1 : 0)
      }))
    }
  },
  38413: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK,
      c: () => CO
    });
    var XO = pO(38063),
      bK = pO(35632),
      eO = pO(38066);
    let lO = (() => {
      var OO;
      let KO, pO, bK = [];
      return OO = class {
        static extractMinAndMaxIndexed(OO, KO, pO, XO, bK, eO) {
          for (let lO = pO; lO < pO + XO; lO++) {
            const pO = 3 * KO[lO],
              XO = OO[pO],
              vK = OO[pO + 1],
              CO = OO[pO + 2];
            bK.minimizeInPlaceFromFloats(XO, vK, CO), eO.maximizeInPlaceFromFloats(XO, vK, CO)
          }
        }
        static extractMinAndMax(OO, KO, pO, XO, bK, eO) {
          for (let lO = KO, vK = KO * XO; lO < KO + pO; lO++, vK += XO) {
            const KO = OO[vK],
              pO = OO[vK + 1],
              XO = OO[vK + 2];
            bK.minimizeInPlaceFromFloats(KO, pO, XO), eO.maximizeInPlaceFromFloats(KO, pO, XO)
          }
        }
      }, (() => {
        const lO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [eO.l.filter((function() {
          return !Array.isArray(arguments.length <= 0 ? void 0 : arguments[0]) && !Array.isArray(arguments.length <= 1 ? void 0 : arguments[1])
        }))], pO = [eO.l.filter((function() {
          return !Array.isArray(arguments.length <= 0 ? void 0 : arguments[0])
        }))], (0, XO.f)(OO, null, KO, {
          kind: "method",
          name: "extractMinAndMaxIndexed",
          static: !0,
          private: !1,
          access: {
            has: OO => "extractMinAndMaxIndexed" in OO,
            get: OO => OO.extractMinAndMaxIndexed
          },
          metadata: lO
        }, null, bK), (0, XO.f)(OO, null, pO, {
          kind: "method",
          name: "extractMinAndMax",
          static: !0,
          private: !1,
          access: {
            has: OO => "extractMinAndMax" in OO,
            get: OO => OO.extractMinAndMax
          },
          metadata: lO
        }, null, bK), lO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: lO
        }), (0, XO.i)(OO, bK)
      })(), OO
    })();

    function vK(OO, KO, pO, XO) {
      let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null;
      const vK = new bK.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE),
        CO = new bK.o(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE);
      return lO.extractMinAndMaxIndexed(OO, KO, pO, XO, vK, CO), eO && (vK.x -= vK.x * eO.x + eO.y, vK.y -= vK.y * eO.x + eO.y, vK.z -= vK.z * eO.x + eO.y, CO.x += CO.x * eO.x + eO.y, CO.y += CO.y * eO.x + eO.y, CO.z += CO.z * eO.x + eO.y), {
        minimum: vK,
        maximum: CO
      }
    }

    function CO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
        eO = arguments.length > 4 ? arguments[4] : void 0;
      const vK = new bK.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE),
        CO = new bK.o(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE);
      return eO || (eO = 3), lO.extractMinAndMax(OO, KO, pO, eO, vK, CO), XO && (vK.x -= vK.x * XO.x + XO.y, vK.y -= vK.y * XO.x + XO.y, vK.z -= vK.z * XO.x + XO.y, CO.x += CO.x * XO.x + XO.y, CO.y += CO.y * XO.x + XO.y, CO.z += CO.z * XO.x + XO.y), {
        minimum: vK,
        maximum: CO
      }
    }
  },
  38388: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => DO
    });
    var XO, bK = pO(38216),
      eO = pO(38391),
      lO = pO(38400),
      vK = pO(38413),
      CO = pO(38416),
      hO = pO(37938);
    class DO {
      get materialDefines() {
        const OO = this._mainDrawWrapperOverride ? this._mainDrawWrapperOverride.defines : this._getDrawWrapper()?.defines;
        return "string" === typeof OO ? null : OO
      }
      set materialDefines(OO) {
        (this._mainDrawWrapperOverride ?? this._getDrawWrapper(void 0, !0)).defines = OO
      }
      _getDrawWrapper(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        OO = OO ?? this._engine.currentRenderPassId;
        let pO = this._drawWrappers[OO];
        return !pO && KO && (this._drawWrappers[OO] = pO = new CO.c(this._mesh.JKO().qb())), pO
      }
      _removeDrawWrapper(OO) {
        let KO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        (!(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1]) && this._drawWrappers[OO]?.dispose(KO), this._drawWrappers[OO] = void 0
      }
      get effect() {
        return this._mainDrawWrapperOverride ? this._mainDrawWrapperOverride.effect : this._getDrawWrapper()?.effect ?? null
      }
      get _drawWrapper() {
        return this._mainDrawWrapperOverride ?? this._getDrawWrapper(void 0, !0)
      }
      get _drawWrapperOverride() {
        return this._mainDrawWrapperOverride
      }
      _setMainDrawWrapperOverride(OO) {
        this._mainDrawWrapperOverride = OO
      }
      setEffect(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        const bK = this._drawWrapper;
        bK.setEffect(OO, KO, XO), void 0 !== pO && (bK.materialContext = pO), OO || (bK.defines = null, bK.materialContext = void 0)
      }
      resetDrawCache(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (this._drawWrappers) {
          if (void 0 !== OO) return void this._removeDrawWrapper(OO, !0, KO);
          for (const OO of this._drawWrappers) OO?.dispose(KO)
        }
        this._drawWrappers = []
      }
      static AddToMesh(OO, KO, pO, XO, bK, eO, lO) {
        return new DO(OO, KO, pO, XO, bK, eO, lO, !(arguments.length > 7 && void 0 !== arguments[7]) || arguments[7])
      }
      constructor(OO, KO, pO, XO, bK, eO, lO) {
        let vK = !(arguments.length > 7 && void 0 !== arguments[7]) || arguments[7],
          CO = !(arguments.length > 8 && void 0 !== arguments[8]) || arguments[8];
        this.materialIndex = OO, this.verticesStart = KO, this.verticesCount = pO, this.indexStart = XO, this.indexCount = bK, this._mainDrawWrapperOverride = null, this._linesIndexCount = 0, this._linesIndexBuffer = null, this._lastColliderWorldVertices = null, this._lastColliderTransformMatrix = null, this._wasDispatched = !1, this._renderId = 0, this._alphaIndex = 0, this._distanceToCamera = 0, this._currentMaterial = null, this._mesh = eO, this._renderingMesh = lO || eO, CO && eO.au.push(this), this._engine = this._mesh.JKO().qb(), this.resetDrawCache(), this._trianglePlanes = [], this._id = eO.au.length - 1, vK && (this.refreshBoundingInfo(), eO.computeWorldMatrix(!0))
      }
      get IsGlobal() {
        return 0 === this.verticesStart && this.verticesCount === this._mesh.getTotalVertices() && 0 === this.indexStart && this.indexCount === this._mesh.getTotalIndices()
      }
      hpO() {
        return this.IsGlobal || this._mesh.hasThinInstances ? this._mesh.hpO() : this._boundingInfo
      }
      setBoundingInfo(OO) {
        return this._boundingInfo = OO, this
      }
      getMesh() {
        return this._mesh
      }
      getRenderingMesh() {
        return this._renderingMesh
      }
      getReplacementMesh() {
        return this._mesh._internalAbstractMeshDataInfo._actAsRegularMesh ? this._mesh : null
      }
      getEffectiveMesh() {
        const OO = this._mesh._internalAbstractMeshDataInfo._actAsRegularMesh ? this._mesh : null;
        return OO || this._renderingMesh
      }
      UX() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        const KO = this._renderingMesh.getMaterialForRenderPass(this._engine.currentRenderPassId) ?? this._renderingMesh.material;
        if (!KO) return OO && this._mesh.JKO()._hasDefaultMaterial ? this._mesh.JKO().defaultMaterial : null;
        if (this._isMultiMaterial(KO)) {
          const OO = KO.getSubMaterial(this.materialIndex);
          return this._currentMaterial !== OO && (this._currentMaterial = OO, this.resetDrawCache()), OO
        }
        return KO
      }
      _isMultiMaterial(OO) {
        return void 0 !== OO.getSubMaterial
      }
      refreshBoundingInfo() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        if (this._lastColliderWorldVertices = null, this.IsGlobal || !this._renderingMesh || !this._renderingMesh.geometry) return this;
        if (OO || (OO = this._renderingMesh.getVerticesData(bK.j.PositionKind)), !OO) return this._boundingInfo = this._mesh.hpO(), this;
        const KO = this._renderingMesh.rFO();
        let pO;
        if (0 === this.indexStart && this.indexCount === KO.length) {
          const OO = this._renderingMesh.hpO();
          pO = {
            minimum: OO.minimum.clone(),
            maximum: OO.maximum.clone()
          }
        } else pO = (0, vK.b)(OO, KO, this.indexStart, this.indexCount, this._renderingMesh.geometry.boundingBias);
        return this._boundingInfo ? this._boundingInfo.reConstruct(pO.minimum, pO.maximum) : this._boundingInfo = new lO.d(pO.minimum, pO.maximum), this
      }
      _checkCollision(OO) {
        return this.hpO()._checkCollision(OO)
      }
      updateBoundingInfo(OO) {
        let KO = this.hpO();
        return KO || (this.refreshBoundingInfo(), KO = this.hpO()), KO && KO.update(OO), this
      }
      isInFrustum(OO) {
        const KO = this.hpO();
        return !!KO && KO.isInFrustum(OO, this._mesh.cullingStrategy)
      }
      isCompletelyInFrustum(OO) {
        const KO = this.hpO();
        return !!KO && KO.isCompletelyInFrustum(OO)
      }
      render(OO) {
        return this._renderingMesh.render(this, OO, this._mesh._internalAbstractMeshDataInfo._actAsRegularMesh ? this._mesh : void 0), this
      }
      _getLinesIndexBuffer(OO, KO) {
        if (!this._linesIndexBuffer) {
          const pO = 6 * Math.floor(this.indexCount / 3),
            XO = this.verticesStart + this.verticesCount > 65535 ? new Uint32Array(pO) : new Uint16Array(pO);
          let bK = 0;
          if (0 === OO.length)
            for (let OO = this.indexStart; OO < this.indexStart + this.indexCount; OO += 3) XO[bK++] = OO, XO[bK++] = OO + 1, XO[bK++] = OO + 1, XO[bK++] = OO + 2, XO[bK++] = OO + 2, XO[bK++] = OO;
          else
            for (let KO = this.indexStart; KO < this.indexStart + this.indexCount; KO += 3) XO[bK++] = OO[KO], XO[bK++] = OO[KO + 1], XO[bK++] = OO[KO + 1], XO[bK++] = OO[KO + 2], XO[bK++] = OO[KO + 2], XO[bK++] = OO[KO];
          this._linesIndexBuffer = KO.createIndexBuffer(XO), this._linesIndexCount = XO.length
        }
        return this._linesIndexBuffer
      }
      canIntersects(OO) {
        const KO = this.hpO();
        return !!KO && OO.intersectsBox(KO.boundingBox)
      }
      intersects(OO, KO, pO, XO, bK) {
        const eO = this.UX();
        if (!eO) return null;
        let lO = 3,
          vK = !1;
        switch (eO.fillMode) {
          case 3:
          case 5:
          case 6:
          case 8:
            return null;
          case 7:
            lO = 1, vK = !0
        }
        return 4 === eO.fillMode ? pO.length ? this._intersectLines(OO, KO, pO, this._mesh.intersectionThreshold, XO) : this._intersectUnIndexedLines(OO, KO, pO, this._mesh.intersectionThreshold, XO) : !pO.length && this._mesh._unIndexed ? this._intersectUnIndexedTriangles(OO, KO, pO, XO, bK) : this._intersectTriangles(OO, KO, pO, lO, vK, XO, bK)
      }
      _intersectLines(OO, KO, pO, XO, bK) {
        let lO = null;
        for (let vK = this.indexStart; vK < this.indexStart + this.indexCount; vK += 2) {
          const CO = KO[pO[vK]],
            hO = KO[pO[vK + 1]],
            DO = OO.intersectionSegment(CO, hO, XO);
          if (!(DO < 0) && ((bK || !lO || DO < lO.distance) && (lO = new eO.d(null, null, DO), lO.faceId = vK / 2, bK))) break
        }
        return lO
      }
      _intersectUnIndexedLines(OO, KO, pO, XO, bK) {
        let lO = null;
        for (let vK = this.verticesStart; vK < this.verticesStart + this.verticesCount; vK += 2) {
          const pO = KO[vK],
            CO = KO[vK + 1],
            hO = OO.intersectionSegment(pO, CO, XO);
          if (!(hO < 0) && ((bK || !lO || hO < lO.distance) && (lO = new eO.d(null, null, hO), lO.faceId = vK / 2, bK))) break
        }
        return lO
      }
      _intersectTriangles(OO, KO, pO, XO, bK, eO, lO) {
        let vK = null,
          CO = -1;
        for (let hO = this.indexStart; hO < this.indexStart + this.indexCount - (3 - XO); hO += XO) {
          CO++;
          const XO = pO[hO],
            DO = pO[hO + 1],
            MO = pO[hO + 2];
          if (bK && 4294967295 === MO) {
            hO += 2;
            continue
          }
          const aK = KO[XO],
            oO = KO[DO],
            FO = KO[MO];
          if (!aK || !oO || !FO) continue;
          if (lO && !lO(aK, oO, FO, OO, XO, DO, MO)) continue;
          const VO = OO.intersectsTriangle(aK, oO, FO);
          if (VO) {
            if (VO.distance < 0) continue;
            if ((eO || !vK || VO.distance < vK.distance) && (vK = VO, vK.faceId = CO, eO)) break
          }
        }
        return vK
      }
      _intersectUnIndexedTriangles(OO, KO, pO, XO, bK) {
        let eO = null;
        for (let lO = this.verticesStart; lO < this.verticesStart + this.verticesCount; lO += 3) {
          const pO = KO[lO],
            vK = KO[lO + 1],
            CO = KO[lO + 2];
          if (bK && !bK(pO, vK, CO, OO, -1, -1, -1)) continue;
          const hO = OO.intersectsTriangle(pO, vK, CO);
          if (hO) {
            if (hO.distance < 0) continue;
            if ((XO || !eO || hO.distance < eO.distance) && (eO = hO, eO.faceId = lO / 3, XO)) break
          }
        }
        return eO
      }
      _rebuild() {
        this._linesIndexBuffer && (this._linesIndexBuffer = null)
      }
      clone(OO, KO) {
        const pO = new DO(this.materialIndex, this.verticesStart, this.verticesCount, this.indexStart, this.indexCount, OO, KO, !1);
        if (!this.IsGlobal) {
          const OO = this.hpO();
          if (!OO) return pO;
          pO._boundingInfo = new lO.d(OO.minimum, OO.maximum)
        }
        return pO
      }
      dispose() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        this._linesIndexBuffer && (this._mesh.JKO().qb()._releaseBuffer(this._linesIndexBuffer), this._linesIndexBuffer = null);
        const KO = this._mesh.au.indexOf(this);
        this._mesh.au.splice(KO, 1), this.resetDrawCache(void 0, OO)
      }
      getClassName() {
        return "SubMesh"
      }
      static CreateFromIndices(OO, KO, pO, XO, bK) {
        let eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
          lO = Number.MAX_VALUE,
          vK = -Number.MAX_VALUE;
        const CO = (bK || XO).rFO();
        for (let hO = KO; hO < KO + pO; hO++) {
          const OO = CO[hO];
          OO < lO && (lO = OO), OO > vK && (vK = OO)
        }
        return new DO(OO, lO, vK - lO + 1, KO, pO, XO, bK, eO)
      }
    }(XO = DO.prototype).projectToRef ?? (XO.projectToRef = (0, hO.h)("SubMesh", "projectToRef"))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);