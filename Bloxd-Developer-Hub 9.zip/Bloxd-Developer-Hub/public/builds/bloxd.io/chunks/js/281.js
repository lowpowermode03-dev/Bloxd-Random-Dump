export const id = 281;
export const ids = [281];
export const modules = {
  39501: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => TO
    });
    var XO = pO(63),
      bK = pO(3893),
      eO = pO(1475),
      lO = pO(918),
      vK = pO.n(lO),
      CO = pO(1271),
      hO = pO(1051),
      DO = pO(3868),
      MO = pO(3874),
      aK = pO(3880),
      oO = pO(976);

    function FO(OO) {
      return OO.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    }
    DO.b.registerLanguage("javascript", MO.c), DO.b.registerLanguage("typescript", aK.d);

    function VO(OO, KO) {
      const pO = FO(OO).replace(/"/g, "&quot;");
      return `<button type="button" class="DocsCopyButton ${KO}" title="${pO}" aria-label="${pO}"><svg class="DocsCopyIcon" viewBox="0 0 16 16" aria-hidden="true"><rect x="5.5" y="5.5" width="8.5" height="8.5" rx="1.5"/><path d="M10.5 3.5V3A1.5 1.5 0 0 0 9 1.5H3A1.5 1.5 0 0 0 1.5 3v6A1.5 1.5 0 0 0 3 10.5h.5"/></svg><svg class="DocsCopiedIcon" viewBox="0 0 16 16" aria-hidden="true"><path d="M2.5 8.5l3.5 3.5 7.5-7.5"/></svg></button>`
    }

    function LO(OO, KO) {
      const pO = [],
        XO = OO.toLowerCase(),
        bK = KO.toLowerCase();
      let eO = 0;
      for (; eO < OO.length;) {
        const lO = XO.indexOf(bK, eO);
        if (-1 === lO) {
          pO.push(OO.slice(eO));
          break
        }
        lO > eO && pO.push(OO.slice(eO, lO)), pO.push((0, oO.jsx)("mark", {
          className: "DocsHighlight",
          children: OO.slice(lO, lO + KO.length)
        }, lO)), eO = lO + KO.length
      }
      return pO
    }
    var QO = pO(933),
      zK = pO(1195),
      AO = pO(35367),
      fO = pO(35375);
    const dO = {
        clientOptions: {
          tabStep: "docsClientOptionsTab",
          tabText: "codeEditor:tutorialClientOptionsTab",
          pageStep: "docsClientOptions",
          pageText: "codeEditor:tutorialClientOptions"
        },
        apiReference: {
          tabStep: "docsApiReferenceTab",
          tabText: "codeEditor:tutorialApiReferenceTab",
          pageStep: "docsApiReference",
          pageText: "codeEditor:tutorialApiReference"
        },
        callbacks: {
          tabStep: "docsCallbacksTab",
          tabText: "codeEditor:tutorialCallbacksTab",
          pageStep: "docsCallbacks",
          pageText: "codeEditor:tutorialCallbacks"
        }
      },
      TO = (0, XO.memo)((function(OO) {
        var KO, pO, lO, MO, aK, TO, NO;
        let {
          popOutDocs: IO,
          hideDocs: yK,
          tutorialEnabled: gK
        } = OO;
        const [uO, EO] = (0, XO.useState)(bK.c[0].id), jK = (0, XO.useRef)(null), YO = (0, XO.useRef)(null), [wO, iK] = (0, XO.useState)(""), [rK, PO] = (0, XO.useState)(0), [mK, sO] = (0, XO.useState)(null), [HO, RO] = (0, XO.useState)(!1), [SO, JO] = (0, XO.useState)(160), cK = (0, XO.useRef)(!1), BO = (0, XO.useRef)(null), ZO = (0, AO.j)("docsOverview"), [GO, qK] = (0, XO.useState)(0), xK = Object.values(dO).some((OO => (null === OO || void 0 === OO ? void 0 : OO.tabStep) === ZO));
        (0, XO.useEffect)((() => {
          xK && wO.length > 0 && (iK(""), qK((OO => OO + 1)))
        }), [xK, wO]);
        const nO = wO.length > 0,
          WO = (0, XO.useMemo)((() => function(OO) {
            if (!OO) return [];
            const KO = OO.toLowerCase(),
              pO = [];
            for (const XO of bK.c) {
              const OO = XO.content.toLowerCase();
              let bK = 0,
                eO = -1,
                lO = 0,
                vK = OO.indexOf(KO, lO);
              for (; - 1 !== vK;) - 1 === eO && (eO = vK), bK++, lO = vK + KO.length, vK = OO.indexOf(KO, lO);
              if (0 === bK) continue;
              const CO = Math.max(0, eO - 40),
                hO = Math.min(XO.content.length, eO + KO.length + 40),
                DO = (CO > 0 ? "..." : "") + XO.content.slice(CO, hO).replace(/\n/g, " ") + (hO < XO.content.length ? "..." : "");
              pO.push({
                doc: XO,
                matchCount: bK,
                snippet: DO
              })
            }
            return pO.sort(((OO, KO) => KO.matchCount - OO.matchCount)), pO
          }(wO)), [wO]),
          tK = nO ? null !== (KO = null !== (pO = null === (lO = WO.find((OO => OO.doc.id === uO))) || void 0 === lO ? void 0 : lO.doc) && void 0 !== pO ? pO : null === (MO = WO[0]) || void 0 === MO ? void 0 : MO.doc) && void 0 !== KO ? KO : null : null !== (aK = bK.c.find((OO => OO.id === uO))) && void 0 !== aK ? aK : bK.c[0],
          {
            t: kK
          } = (0, hO.D)(),
          UO = kK("codeEditor:copySnippet"),
          OK = (0, XO.useMemo)((() => tK ? function(OO, KO, pO, XO) {
            let bK = KO;
            bK = bK.replace(/\r\n/g, "\n");
            const eO = [];
            bK = bK.replace(/```(\w*)\n([\s\S]*?)```/g, ((OO, KO, XO) => {
              const bK = eO.length;
              let lO = FO(XO);
              try {
                lO = DO.b.highlight(XO.trimEnd(), {
                  language: KO
                }).value
              } catch (vK) {
                console.warn("Could not highlight documentation code block", vK)
              }
              return eO.push(`<div class="DocsCodeBlockRow"><pre class="DocsCodeBlock" data-lang="${KO}"><code>${lO}</code></pre>${VO(pO,"DocsCopyBlock")}</div>`), `\0PLACEHOLDER_${bK}\0`
            })), bK = bK.replace(/(`{1,2})([^\n]+?)\1(?!`)/g, ((KO, XO, bK) => {
              const lO = eO.length,
                vK = 2 === XO.length ? bK.replace(/^ (.*) $/, "$1") : bK;
              let CO = FO(vK);
              try {
                "apiReference" !== OO && "callbacks" !== OO || (CO = DO.b.highlight(vK.trimEnd().replaceAll("\\|", "|"), {
                  language: "typescript"
                }).value)
              } catch (hO) {
                console.warn("Could not highlight documentation snippet", hO)
              }
              return eO.push(`<span class="DocsInlineCodeRow"><code class="DocsInlineCode">${CO}</code>${VO(pO,"DocsCopyInline")}</span>`), `\0PLACEHOLDER_${lO}\0`
            })), bK = FO(bK), bK = bK.replace(/^#### (.+)$/gm, '<h4 class="DocsH4">$1</h4>'), bK = bK.replace(/^### (.+)$/gm, '<h3 class="DocsH3">$1</h3>'), bK = bK.replace(/^## (.+)$/gm, '<h2 class="DocsH2">$1</h2>'), bK = bK.replace(/^# (.+)$/gm, '<h1 class="DocsH1">$1</h1>'), bK = bK.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>"), bK = bK.replace(/\[([^\]]+)\]\(([^)]+)\)/g, ((OO, KO, pO) => pO.startsWith("#") ? `<a class="DocsAnchor" data-id="${pO}">${KO}</a>` : `<a href="${pO}" target="_blank" rel="noopener noreferrer">${KO}</a>`)), bK = bK.replace(/^(\|.+\|)\n(\|[\s:\-|]+\|)\n((?:\|.+\|\s*\r?\n?)*)/gm, ((OO, KO, pO, XO) => `<table class="DocsTable"><thead><tr>${KO.split("|").slice(1,-1).map((OO=>`<th>${OO.trim()}</th>`)).join("")}</tr></thead><tbody>${XO.trim().split("\n").map((OO=>`<tr>${OO.split("|").slice(1,-1).map((OO=>`<td>${OO.trim()}</td>`)).join("")}</tr>`)).join("")}</tbody></table>`)), bK = bK.replace(/(?:^[ \t]*([*-])[ \t]+.+(?:\n|$))+/gm, ((OO, KO) => function(OO, KO) {
              const pO = "*" === KO,
                XO = [];
              for (const vK of OO.split("\n")) {
                const OO = vK.match(/^([ \t]*)(?:[*-])[ \t]+(.+)$/);
                OO && XO.push({
                  indent: OO[1].replace(/\t/g, "  ").length,
                  content: OO[2]
                })
              }
              let bK = "";
              const eO = [],
                lO = pO ? "ol" : "ul";
              for (const {
                  indent: vK,
                  content: CO
                }
                of XO) {
                for (; eO.length > 0 && vK < eO[eO.length - 1];) bK += `</${lO}></li>`, eO.pop();
                (0 === eO.length || vK > eO[eO.length - 1]) && (eO.length > 0 && (bK = bK.replace(/<\/li>$/, "")), bK += `<${lO} class="DocsList">`, eO.push(vK)), bK += `<li class="DocsListItem">${CO}</li>`
              }
              for (; eO.length > 0;) bK += `</${lO}>`, eO.pop(), eO.length > 0 && (bK += "</li>");
              return bK
            }(OO, KO))), bK = bK.replace(/\n{2,}/g, "\n<br/>\n");
            for (let lO = 0; lO < eO.length; lO++) bK = bK.replace(`\0PLACEHOLDER_${lO}\0`, eO[lO]);
            if (XO) {
              const OO = FO(XO).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
                KO = new RegExp(OO, "gi");
              bK = bK.replace(/([^<>]+)(?=<|$)/g, (OO => OO.replace(KO, (OO => `<mark class="DocsHighlight">${OO}</mark>`))))
            }
            return bK
          }(tK.id, tK.content, UO, nO ? wO : void 0) : ""), [tK, UO, nO, wO]);
        (0, XO.useEffect)((() => {
          const OO = YO.current;
          if (!OO) return;
          const KO = OO => {
            var KO, pO, XO, bK, eO;
            const lO = null === (KO = (pO = OO.target).closest) || void 0 === KO ? void 0 : KO.call(pO, ".DocsCopyButton");
            if (!lO) return;
            OO.preventDefault(), OO.stopPropagation();
            const vK = null !== (XO = null === (bK = lO.parentElement) || void 0 === bK || null === (eO = bK.querySelector("code")) || void 0 === eO ? void 0 : eO.textContent) && void 0 !== XO ? XO : "";
            navigator.clipboard.writeText(vK.trimEnd()).then((() => {
              lO.classList.add("Copied"), setTimeout((() => {
                lO.classList.remove("Copied")
              }), 1500)
            })).catch((OO => {
              console.warn("Could not copy documentation code", OO)
            }))
          };
          return OO.addEventListener("click", KO, !0), () => {
            OO.removeEventListener("click", KO, !0)
          }
        }), []);
        const [KK, pK] = (0, XO.useState)(0);
        (0, XO.useEffect)((() => {
          if (!nO || !YO.current) return void pK(0);
          const OO = YO.current.querySelectorAll(".DocsHighlight").length;
          pK(OO)
        }), [nO, OK]), (0, XO.useEffect)((() => {
          if (null === mK || !YO.current) return;
          sO(null);
          const OO = YO.current.querySelectorAll(".DocsHighlight");
          if (0 === OO.length) return;
          const KO = Math.min(mK, OO.length - 1);
          PO(KO), OO.forEach((OO => {
            OO.classList.remove("DocsHighlightActive")
          })), OO[KO].classList.add("DocsHighlightActive"), OO[KO].scrollIntoView({
            block: "center",
            behavior: "smooth"
          })
        }), [mK, OK]);
        const XK = (0, XO.useCallback)((OO => {
            if (!YO.current) return;
            const KO = YO.current.querySelectorAll(".DocsHighlight");
            if (0 === KO.length) return;
            const pO = (rK + OO + KO.length) % KO.length;
            PO(pO), sO(pO)
          }), [rK]),
          bp = (0, XO.useCallback)((OO => {
            var KO;
            const pO = null === (KO = dO[OO]) || void 0 === KO ? void 0 : KO.tabStep;
            pO && pO === ZO && (0, fO.e)(pO), OO !== uO ? (RO(!0), EO(OO), PO(0), YO.current && (YO.current.scrollTop = 0), nO && sO(0)) : RO(!HO)
          }), [nO, uO, HO, ZO]),
          eK = (0, XO.useCallback)((OO => {
            var KO;
            const pO = Array.from((null === (KO = YO.current) || void 0 === KO ? void 0 : KO.querySelectorAll(".DocsH2, .DocsH3")) || []).find((KO => {
              var pO;
              return null === (pO = KO.textContent) || void 0 === pO ? void 0 : pO.includes(OO)
            }));
            pO && pO.scrollIntoView({
              block: "start",
              behavior: "smooth"
            })
          }), [YO]),
          lK = (0, XO.useCallback)((OO => {
            var KO, pO;
            const XO = null !== (KO = null === (pO = jK.current) || void 0 === pO ? void 0 : pO.clientWidth) && void 0 !== KO ? KO : window.innerWidth,
              bK = Math.max(120, XO - 200);
            return Math.min(Math.max(OO, 120), bK)
          }), []),
          vp = (0, XO.useCallback)((() => {
            var OO;
            cK.current && (cK.current = !1, null === (OO = jK.current) || void 0 === OO || OO.classList.remove("DocsSidebarResizing"))
          }), []),
          CK = (0, XO.useCallback)((OO => {
            var KO;
            OO.preventDefault(), cK.current = !0, null === (KO = jK.current) || void 0 === KO || KO.classList.add("DocsSidebarResizing")
          }), []);
        (0, XO.useEffect)((() => {
          const OO = jK.current,
            KO = OO => {
              if (!cK.current || !jK.current) return;
              const KO = jK.current.getBoundingClientRect().left;
              JO(lK(OO.clientX - KO))
            };
          return window.addEventListener("mousemove", KO), window.addEventListener("mouseup", vp), () => {
            window.removeEventListener("mousemove", KO), window.removeEventListener("mouseup", vp), null === OO || void 0 === OO || OO.classList.remove("DocsSidebarResizing")
          }
        }), [lK, vp]);
        const hK = (0, XO.useCallback)((OO => {
          if (OO) {
            const [KO, pO] = OO.slice(1).split("-");
            pO && (BO.current = {
              docId: KO,
              subsection: pO
            }), KO && bp(KO)
          }
        }), [bp]);
        (0, XO.useEffect)((() => {
          const OO = BO.current;
          OO && uO === OO.docId && (setTimeout((() => {
            eK(OO.subsection)
          }), 0), BO.current = null)
        })), (0, XO.useEffect)((() => {
          if (!YO.current) return;
          YO.current.querySelectorAll("a.DocsAnchor").forEach((OO => {
            OO.addEventListener("click", (KO => {
              KO.preventDefault(), hK(OO.dataset.id)
            }))
          }))
        }), [uO, hK]);
        const DK = Object.values(dO).find((OO => (null === OO || void 0 === OO ? void 0 : OO.pageStep) === ZO));
        return (0, oO.jsx)(AO.f, {
          tutorial: "docsOverview",
          step: null !== (TO = null === DK || void 0 === DK ? void 0 : DK.pageStep) && void 0 !== TO ? TO : "docsPanel",
          text: kK(null !== (NO = null === DK || void 0 === DK ? void 0 : DK.pageText) && void 0 !== NO ? NO : "codeEditor:tutorialDocsPanel"),
          enabled: gK,
          placement: "left",
          onPrevious: DK ? void 0 : yK,
          children: (0, oO.jsxs)("div", {
            className: "DocsPanel",
            ref: jK,
            children: [(0, oO.jsxs)("div", {
              className: "DocsSidebar",
              style: {
                width: SO,
                minWidth: SO,
                maxWidth: SO
              },
              children: [(0, oO.jsx)(eO.e, {
                className: "DocsSearch",
                placeholderText: "\ud83d\udd0e Search docs...",
                onValueChange: OO => {
                  iK(OO), PO(0), sO(0)
                }
              }, GO), (0, oO.jsx)("div", {
                className: "DocsNavList",
                children: nO ? WO.map((OO => (0, oO.jsxs)("div", {
                  className: vK()("DocsNavItem", "SearchResult", {
                    Active: OO.doc.id === (null === tK || void 0 === tK ? void 0 : tK.id)
                  }),
                  "data-pad-focusable": !0,
                  onClick: () => {
                    bp(OO.doc.id)
                  },
                  children: [(0, oO.jsxs)("div", {
                    className: "SearchResultTitle",
                    children: [OO.doc.title, (0, oO.jsx)("span", {
                      className: "SearchResultCount",
                      children: OO.matchCount
                    })]
                  }), (0, oO.jsx)("div", {
                    className: "SearchResultSnippet",
                    children: LO(OO.snippet, wO)
                  })]
                }, OO.doc.id))) : bK.c.map((OO => {
                  const KO = (0, oO.jsxs)("div", {
                      className: vK()("DocsNavItem", {
                        Active: OO.id === (null === tK || void 0 === tK ? void 0 : tK.id)
                      }),
                      "data-pad-focusable": !0,
                      onClick: () => {
                        bp(OO.id)
                      },
                      children: [(0, oO.jsx)("span", {
                        className: "DocsNavItemTitle",
                        children: OO.title
                      }), OO.subsections && OO.id === (null === tK || void 0 === tK ? void 0 : tK.id) && HO && (0, oO.jsx)("span", {
                        className: "DocsNavItemSubsectionArrow",
                        children: (0, oO.jsx)(QO.d, {
                          name: "angle-down"
                        })
                      }), OO.subsections && (OO.id !== (null === tK || void 0 === tK ? void 0 : tK.id) || !HO) && (0, oO.jsx)("span", {
                        className: "DocsNavItemSubsectionArrow",
                        children: (0, oO.jsx)(QO.d, {
                          name: "angle-up"
                        })
                      })]
                    }),
                    pO = dO[OO.id];
                  return (0, oO.jsxs)(XO.Fragment, {
                    children: [pO && (0, oO.jsx)(AO.f, {
                      tutorial: "docsOverview",
                      step: pO.tabStep,
                      text: kK(pO.tabText),
                      enabled: gK,
                      placement: "left",
                      waitForClick: !0,
                      children: KO
                    }), !pO && KO, HO && OO.subsections && OO.id === (null === tK || void 0 === tK ? void 0 : tK.id) && OO.subsections.map((OO => (0, oO.jsx)("div", {
                      className: "DocsNavItem DocsSubsection",
                      "data-pad-focusable": !0,
                      onClick: () => {
                        eK(OO)
                      },
                      children: OO
                    }, OO)))]
                  }, OO.id)
                }))
              }), (0, oO.jsx)("div", {
                className: "DocsSidebarButtonContainer",
                children: (0, oO.jsx)(zK.g, {
                  tooltipInner: kK("codeEditor:popOutDocsTooltip"),
                  placement: "top",
                  children: (0, oO.jsx)(CO.d, {
                    className: "DocsSidebarButton",
                    onClick: IO,
                    children: kK("codeEditor:popOutDocs")
                  })
                })
              })]
            }), (0, oO.jsx)("div", {
              className: "DocsSidebarResizeHandle",
              onMouseDown: CK
            }), (0, oO.jsxs)("div", {
              className: "DocsContentWrapper",
              children: [nO && KK > 0 && (0, oO.jsxs)("div", {
                className: "DocsMatchNav",
                children: [(0, oO.jsxs)("span", {
                  className: "DocsMatchNavLabel",
                  children: [rK + 1, " / ", KK]
                }), (0, oO.jsx)("button", {
                  className: "DocsMatchNavButton",
                  onClick: () => {
                    XK(-1)
                  },
                  children: "\u25b2"
                }), (0, oO.jsx)("button", {
                  className: "DocsMatchNavButton",
                  onClick: () => {
                    XK(1)
                  },
                  children: "\u25bc"
                })]
              }), (0, oO.jsx)("div", {
                className: "DocsContent",
                ref: YO,
                dangerouslySetInnerHTML: {
                  __html: OK
                }
              })]
            })]
          })
        })
      }))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);