export const id = 205;
export const ids = [205];
export const modules = {
  36431: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO,
      d: () => XO,
      e: () => vK,
      h: () => bK,
      i: () => lO,
      m: () => eO
    });
    const XO = 1.001,
      bK = .501,
      eO = .025,
      lO = .75,
      vK = .08,
      CO = 4;

    function hO() {
      const OO = bK,
        KO = eO,
        pO = OO - KO / 2,
        XO = (2 * OO - 2 * KO) / (2 * CO - 1),
        lO = [];
      for (const bK of [-pO, pO])
        for (const eO of [-pO, pO])
          for (let pO = 0; pO < CO; pO++) {
            const vK = -OO + KO + XO * (2 * pO + .5);
            lO.push([XO, KO, KO, vK, bK, eO]), lO.push([KO, XO, KO, bK, vK, eO]), lO.push([KO, KO, XO, bK, eO, vK])
          }
      for (const bK of [-pO, pO])
        for (const OO of [-pO, pO])
          for (const XO of [-pO, pO]) lO.push([KO, KO, KO, bK, OO, XO]);
      return lO
    }
  },
  36818: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => dO,
      D: () => fO,
      G: () => aK,
      J: () => VO,
      L: () => QO,
      N: () => bK,
      e: () => DO,
      f: () => CO,
      h: () => AO,
      i: () => hO,
      l: () => vK,
      n: () => lO,
      p: () => eO,
      q: () => NO,
      u: () => oO,
      w: () => TO,
      z: () => IO
    });
    var XO = pO(8458);

    function bK(OO) {
      return Math.floor(OO).toLocaleString("en-US")
    }
    const eO = 2e3,
      lO = .005,
      vK = .001,
      CO = 2,
      hO = "Fluid Tank",
      DO = "Coolant Mixer",
      MO = 144;

    function aK(OO) {
      const KO = OO.split("|")[0];
      return (0, XO.n)(KO) ? KO === XO.e ? "cryo" : "water" : null
    }
    const oO = [
        [1, 0, 0],
        [-1, 0, 0],
        [0, 1, 0],
        [0, -1, 0],
        [0, 0, 1],
        [0, 0, -1]
      ],
      FO = 63;

    function VO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      const pO = KO ? function(OO, KO, pO) {
        const XO = oO.findIndex((XO => {
          let [bK, eO, lO] = XO;
          return bK === OO && eO === KO && lO === pO
        }));
        return XO < 0 ? 0 : 1 << XO
      }(KO[0], KO[1], KO[2]) : 0;
      return "maker" === OO ? {
        kind: OO,
        faces: pO
      } : "user" === OO ? {
        kind: OO,
        faces: FO & ~pO
      } : {
        kind: OO,
        faces: FO
      }
    }

    function LO(OO) {
      return "pipe" === OO || "tank" === OO || "maker" === OO
    }

    function QO(OO, KO, pO) {
      return 0 !== (OO.faces & 1 << pO) && 0 !== (KO.faces & 1 << (1 ^ pO)) && (LO(OO.kind) || LO(KO.kind))
    }
    const zK = (OO, KO, pO, XO) => ({
        input: OO,
        inputAmount: XO,
        output: KO,
        outputAmount: pO
      }),
      AO = {
        Condenser: {
          kind: "Condenser",
          opMs: 2e3,
          inputSlot: null,
          fuelSlot: null,
          outputSlots: [],
          recipes: [],
          powerPerOp: 60,
          fluidMade: 12,
          couplable: !0,
          couplerSlot: 0
        },
        Centrifuge: {
          kind: "Centrifuge",
          opMs: 12e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3],
          recipes: [zK("Uranium Grit", "Uranium Pellet", 1, 12), zK("Spent Pellet", "Plutonium Pellet", 1, 4)],
          powerPerOp: 600,
          waterPerOp: 24
        },
        Synthesizer: {
          kind: "Synthesizer",
          opMs: 6e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3],
          recipes: [],
          powerPerOp: 120,
          waterPerOp: 12,
          synth: !0
        },
        "Coolant Mixer": {
          kind: "Coolant Mixer",
          opMs: 12e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [],
          recipes: [zK("Biomass", "", 0, 1)],
          powerPerOp: 720,
          waterPerOp: 144,
          cryoMade: MO,
          couplable: !0,
          couplerSlot: 1
        }
      };

    function fO(OO, KO) {
      return 1e3 * (null !== KO && void 0 !== KO ? KO : 0) / OO.opMs
    }

    function dO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
      const pO = fO(AO["Coolant Mixer"], MO) * KO;
      return OO <= 0 ? 0 : Math.ceil(OO / pO - 1e-9)
    }
    const TO = "baf2Water",
      NO = "baf2waterclose",
      IO = "baf2wateropen"
  },
  36809: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => iK,
      f: () => rK
    });
    var XO = pO(8365),
      bK = pO(8399);
    const eO = [
      [1, 0, 0],
      [-1, 0, 0],
      [0, 0, 1],
      [0, 0, -1],
      [0, 1, 0],
      [0, -1, 0]
    ];
    var lO = pO(8416),
      vK = pO(36617),
      CO = pO(8411);
    const hO = {
      1: [0, -1],
      2: [-1, 0],
      3: [0, 1],
      4: [1, 0]
    };

    function DO(OO) {
      let [KO, pO] = OO;
      return [-pO, KO]
    }

    function MO(OO, KO) {
      return OO[0] === KO[0] && OO[1] === KO[1]
    }

    function aK(OO, KO) {
      return OO[0] * KO[0] + OO[1] * KO[1] === 0
    }
    const oO = [
      [1, 0, 0],
      [-1, 0, 0],
      [0, 0, 1],
      [0, 0, -1]
    ];
    var FO = pO(8449);

    function VO(OO, KO, pO, XO, bK) {
      return KO < FO.u || KO >= FO.u + FO.y || Math.floor(OO / FO.F) === Math.floor(XO / FO.F) && Math.floor(pO / FO.F) === Math.floor(bK / FO.F)
    }
    const LO = "Splitter",
      QO = "Sorting Gate",
      zK = new Set(FO.P),
      AO = new Set([...FO.P, "Belt Loader", "Fast Loader", QO]),
      fO = new Set(FO.C),
      dO = [
        [1, 0, 0],
        [-1, 0, 0],
        [0, 0, 1],
        [0, 0, -1],
        [0, 1, 0],
        [0, -1, 0]
      ];

    function TO(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = XO.l[OO]) || void 0 === pO ? void 0 : pO.meta.rootName) && void 0 !== KO ? KO : ""
    }

    function NO(OO) {
      return TO(OO) === FO.j && (0, FO.Z)(XO.l[OO].name)
    }
    var IO = pO(8408),
      yK = pO(8428);
    const gK = [
      [1, 0, 0],
      [-1, 0, 0],
      [0, 0, 1],
      [0, 0, -1]
    ];

    function uO(OO) {
      var KO, pO;
      const bK = null === (KO = XO.l[OO]) || void 0 === KO ? void 0 : KO.meta;
      return (null === bK || void 0 === bK ? void 0 : bK.rootName) !== yK.p ? null : {
        rot: null !== (pO = bK.rot) && void 0 !== pO ? pO : 1,
        half: (0, yK.i)(bK.rootName, bK.metaStr)
      }
    }

    function EO(OO, KO, pO, XO) {
      return uO(OO(KO, pO, XO))
    }

    function jK(OO, KO, pO, XO, bK) {
      let {
        rot: eO,
        half: lO
      } = bK;
      const [vK, CO] = (0, yK.m)(eO, lO), hO = EO(OO, KO + vK, pO, XO + CO);
      return null !== hO && hO.rot === eO && hO.half === yK.r[lO]
    }
    var YO = pO(36813);
    const wO = [new class {
      constructor() {
        this.reshapeOffsets = oO
      }
      handles(OO) {
        var KO;
        return "Stairs" === (null === (KO = XO.l[OO]) || void 0 === KO ? void 0 : KO.model)
      }
      affects(OO) {
        return this.handles(OO)
      }
      shape(OO, KO, pO, bK, eO) {
        const lO = this.stairsOf(eO),
          vK = this.cornerAt(OO, KO, pO, bK, lO),
          hO = lO.half === CO.e.top ? "top" : "bot";
        return (0, XO.p)(`${XO.l[eO].meta.rootName}|meta|rot${lO.rot}|${hO}${null===vK?"":`|${vK}`}`)
      }
      stairsOf(OO) {
        const {
          rot: KO,
          halfblockPlacement: pO
        } = XO.l[OO].meta;
        return {
          rot: KO,
          half: pO
        }
      }
      stairsAt(OO, KO, pO, XO) {
        const bK = OO(KO, pO, XO);
        return this.handles(bK) ? this.stairsOf(bK) : null
      }
      cornerAt(OO, KO, pO, XO, bK) {
        let {
          rot: eO,
          half: lO
        } = bK;
        const vK = hO[eO],
          CO = bK => {
            let [vK, CO] = bK;
            const hO = this.stairsAt(OO, KO + vK, pO, XO + CO);
            return null !== hO && hO.rot === eO && hO.half === lO
          },
          oO = this.stairsAt(OO, KO + vK[0], pO, XO + vK[1]);
        if (null !== oO && oO.half === lO) {
          const OO = hO[oO.rot];
          if (aK(vK, OO) && !CO([-OO[0], -OO[1]])) return MO(OO, DO(vK)) ? "outerLeft" : "outerRight"
        }
        const FO = this.stairsAt(OO, KO - vK[0], pO, XO - vK[1]);
        if (null !== FO && FO.half === lO) {
          const OO = hO[FO.rot];
          if (aK(vK, OO) && !CO(OO)) return MO(OO, DO(vK)) ? "innerLeft" : "innerRight"
        }
        return null
      }
    }, new class {
      constructor() {
        this.reshapeOffsets = eO, this.rootIds = new Set(bK.l.map((OO => (0, XO.p)(OO))))
      }
      handles(OO) {
        var KO;
        const pO = null === (KO = XO.l[OO]) || void 0 === KO ? void 0 : KO.meta;
        return void 0 !== pO && this.rootIds.has(pO.rootId)
      }
      affects(OO) {
        return this.handles(OO)
      }
      placedBy(OO) {
        return XO.l[OO].meta.rootName === bK.s ? null : bK.s
      }
      shape(OO, KO, pO, eO, lO) {
        const {
          rootId: vK,
          rootName: CO,
          rot: hO
        } = XO.l[lO].meta;
        let DO = 0;
        return bK.z[hO].forEach(((bK, lO) => {
          var CO;
          let [MO, aK, oO] = bK;
          const FO = null === (CO = XO.l[OO(KO + MO, pO + aK, eO + oO)]) || void 0 === CO ? void 0 : CO.meta;
          (null === FO || void 0 === FO ? void 0 : FO.rootId) === vK && FO.rot === hO && (DO |= 1 << lO)
        })), (0, XO.p)((0, bK.h)(CO, hO, DO))
      }
    }, ...lO.d.map((OO => new vK.c(OO))), new class {
      constructor() {
        this.reshapeOffsets = dO
      }
      handles(OO) {
        const KO = TO(OO);
        return zK.has(KO) || KO === FO.j
      }
      affects(OO) {
        const KO = TO(OO);
        return AO.has(KO) || fO.has(KO) || KO === LO || KO === FO.j || void 0 !== FO.e[KO]
      }
      shape(OO, KO, pO, bK, eO, lO) {
        const {
          rootName: vK,
          rot: CO
        } = XO.l[eO].meta;
        return vK === FO.j ? lO ? eO : function(OO, KO, pO, bK, eO) {
          const [lO, vK] = FO.h[eO - 1];
          for (let CO = 1; CO <= FO.L; CO++) {
            const [hO, DO] = [KO - lO * CO, bK - vK * CO], MO = OO(hO, pO, DO);
            if (TO(MO) === FO.j && XO.l[MO].meta.rot === eO && VO(KO, pO, bK, hO, DO)) return (0, XO.p)((0, FO.ib)(eO, !NO(MO)))
          }
          return (0, XO.p)((0, FO.ib)(eO, !1))
        }(OO, KO, pO, bK, CO) : (0, XO.p)((0, FO.T)(vK, CO, function(OO, KO, pO, bK, eO) {
          const [lO, vK] = FO.h[eO - 1], CO = (eO, CO) => function(OO, KO, pO, bK, eO) {
            var lO;
            const vK = null === (lO = XO.l[OO]) || void 0 === lO ? void 0 : lO.meta;
            if (!vK) return !1;
            const CO = vK.rootName,
              hO = AO.has(CO) || NO(OO);
            if (!hO && !fO.has(CO) && CO !== LO) return !1;
            const [DO, MO] = FO.h[vK.rot - 1];
            return hO ? DO === -KO && MO === -pO : fO.has(CO) ? DO === KO && MO === pO : (0, FO.fb)(XO.l[OO].name, DO, MO).some((OO => {
              let [XO, bK] = OO;
              return XO === -KO && bK === -pO
            })) && !(bK === KO && eO === pO)
          }(OO(KO + eO, pO, bK + CO), eO, CO, lO, vK), hO = OO(KO - lO, pO, bK - vK), DO = TO(hO) === LO && XO.l[hO].meta.rot === eO, MO = 1 === FO.e[TO(OO(KO, pO - 1, bK))] || -1 === FO.e[TO(OO(KO, pO + 1, bK))];
          if (MO || DO || function(OO, KO, pO) {
              if (TO(OO) !== QO) return !1;
              const [bK, eO] = FO.h[XO.l[OO].meta.rot - 1], [lO, vK] = (0, FO.U)(XO.l[OO].name, bK, eO);
              return KO === lO && pO === vK
            }(hO, lO, vK) || CO(-lO, -vK)) return null;
          const aK = CO(-vK, lO),
            oO = CO(vK, -lO);
          if (aK === oO) return null;
          return aK ? "turnLeft" : "turnRight"
        }(OO, KO, pO, bK, CO)))
      }
    }, new class {
      constructor() {
        this.reshapeOffsets = gK, this.rootId = (0, XO.p)(yK.p)
      }
      handles(OO) {
        var KO;
        return (null === (KO = XO.l[OO]) || void 0 === KO ? void 0 : KO.meta.rootId) === this.rootId
      }
      affects(OO) {
        return this.handles(OO)
      }
      shape(OO, KO, pO, bK, eO, lO) {
        const vK = uO(eO);
        return (0, XO.p)((CO = vK.rot, null !== (hO = lO ? this.reshapedHalf(OO, KO, pO, bK, vK) : this.placedHalf(OO, KO, pO, bK, vK.rot)) ? (0, yK.e)(yK.p, CO, hO) : 1 === CO ? yK.p : `${yK.p}|meta|rot${CO}`));
        var CO, hO
      }
      placedHalf(OO, KO, pO, XO, bK) {
        const [eO, lO] = IO.e[bK];
        for (const [vK, CO] of [
            ["right", 1],
            ["left", -1]
          ]) {
          const hO = KO + CO * eO,
            DO = XO + CO * lO,
            MO = EO(OO, hO, pO, DO);
          if (null !== MO && MO.rot === bK && (null === MO.half || !jK(OO, hO, pO, DO, MO))) return vK
        }
        return null
      }
      reshapedHalf(OO, KO, pO, XO, bK) {
        if (null !== bK.half && jK(OO, KO, pO, XO, bK)) return bK.half;
        for (const eO of ["right", "left"]) {
          const [lO, vK] = (0, yK.m)(bK.rot, eO), CO = EO(OO, KO + lO, pO, XO + vK);
          if (null !== CO && CO.rot === bK.rot && CO.half === yK.r[eO]) return eO
        }
        return null
      }
    }, new YO.d];

    function iK(OO, KO, pO, XO, bK) {
      let eO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
      for (const lO of wO)
        if (lO.handles(bK)) return lO.shape(OO, KO, pO, XO, bK, eO);
      return bK
    }

    function rK(OO) {
      for (const XO of wO) {
        var KO, pO;
        if (XO.handles(OO)) return null !== (KO = null === (pO = XO.placedBy) || void 0 === pO ? void 0 : pO.call(XO, OO)) && void 0 !== KO ? KO : null
      }
      return null
    }
  },
  36813: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => yK,
      f: () => fO,
      h: () => AO
    });
    var XO = pO(8365),
      bK = pO(8386),
      eO = pO(8458),
      lO = pO(36818),
      vK = pO(8449);
    const CO = (0, lO.J)("pipe"),
      hO = (0, lO.J)("tank"),
      DO = (0, lO.J)("port"),
      MO = "Reactor Port";

    function aK(OO, KO, pO) {
      const XO = new Set([eO.g, eO.e, MO, ...KO, ...pO, ...OO ? [lO.i] : []]);
      return {
        makers: new Set(KO),
        roots: XO
      }
    }
    const oO = {
        water: aK(!0, ["Condenser"], ["Centrifuge", "Synthesizer", lO.e]),
        cryo: aK(!1, [lO.e], [])
      },
      FO = new Set([...oO.water.roots, ...oO.cryo.roots]),
      VO = {
        nx: [-1, 0, 0],
        ny: [0, -1, 0],
        nz: [0, 0, -1],
        px: [1, 0, 0],
        py: [0, 1, 0],
        pz: [0, 0, 1]
      },
      LO = bK.f.map((OO => VO[OO])),
      QO = LO.map((OO => {
        let [KO, pO, XO] = OO;
        return lO.u.findIndex((OO => {
          let [bK, eO, lO] = OO;
          return bK === KO && eO === pO && lO === XO
        }))
      }));

    function zK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "water";
      const pO = XO.l[OO],
        bK = null === pO || void 0 === pO ? void 0 : pO.meta.rootName,
        aK = oO[KO];
      if (!bK || !aK.roots.has(bK)) return null;
      if ((0, eO.n)(bK)) return (0, lO.G)(pO.name) === KO ? CO : null;
      if (bK === lO.i) return hO;
      if (bK === MO) return pO.name.endsWith("|Water") ? DO : null;
      const [FO, VO] = vK.h[(pO.meta.rot || 1) - 1];
      return (0, lO.J)(aK.makers.has(bK) ? "maker" : "user", [-FO, 0, -VO])
    }

    function AO(OO, KO, pO, bK) {
      let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "water";
      const {
        makers: vK
      } = oO[eO];
      return LO.some(((hO, DO) => {
        var MO, aK;
        let [oO, FO, VO] = hO;
        const LO = OO(KO + oO, pO + FO, bK + VO),
          AO = zK(LO, eO);
        return null !== AO && vK.has(null !== (MO = null === (aK = XO.l[LO]) || void 0 === aK ? void 0 : aK.meta.rootName) && void 0 !== MO ? MO : "") && !(0, lO.L)(CO, AO, QO[DO])
      }))
    }

    function fO(OO) {
      const KO = XO.l[OO];
      return KO ? (0, lO.G)(KO.name) : null
    }
    let dO = null;

    function TO(OO) {
      if (!dO) {
        dO = new Map;
        for (const OO of ["water", "cryo"])
          for (let KO = 0; KO < 64; KO++)
            for (const pO of [!1, !0]) dO.set((0, eO.r)(OO, KO, pO), {
              Lp: OO,
              mask: KO,
              full: pO
            })
      }
      return dO.get(OO)
    }
    const NO = new Map(Array.from({
      length: eO.j + 1
    }, ((OO, KO) => [(0, eO.v)(KO), KO])));

    function IO(OO, KO, pO, bK, eO, lO) {
      return LO.some(((vK, CO) => {
        var hO, DO, MO;
        let [aK, oO, FO] = vK;
        if (0 === (lO >> CO & 1)) return !1;
        const VO = null !== (hO = null === (DO = XO.l[OO(KO + aK, pO + oO, bK + FO)]) || void 0 === DO ? void 0 : DO.name) && void 0 !== hO ? hO : "",
          LO = TO(VO);
        return LO ? LO.Lp === eO && LO.full : (null !== (MO = function(OO) {
          var KO;
          return null !== (KO = NO.get(OO)) && void 0 !== KO ? KO : null
        }(VO)) && void 0 !== MO ? MO : 0) > 0
      }))
    }
    class yK {
      constructor() {
        this.reshapeOffsets = LO
      }
      handles(OO) {
        return null !== fO(OO)
      }
      affects(OO) {
        var KO, pO;
        return FO.has(null !== (KO = null === (pO = XO.l[OO]) || void 0 === pO ? void 0 : pO.meta.rootName) && void 0 !== KO ? KO : "")
      }
      placedBy(OO) {
        var KO;
        return (null === (KO = XO.l[OO]) || void 0 === KO ? void 0 : KO.meta.rootName) === eO.e ? eO.g : null
      }
      shape(OO, KO, pO, bK, vK, hO) {
        var DO, MO, aK;
        const oO = null !== (DO = null === (MO = XO.l[vK]) || void 0 === MO ? void 0 : MO.name) && void 0 !== DO ? DO : "",
          FO = hO || oO !== eO.g ? null !== (aK = (0, lO.G)(oO)) && void 0 !== aK ? aK : "water" : function(OO, KO, pO, XO) {
            return LO.some(((bK, eO) => {
              let [vK, hO, DO] = bK;
              const MO = zK(OO(KO + vK, pO + hO, XO + DO), "cryo");
              return null !== MO && "port" !== MO.kind && (0, lO.L)(CO, MO, QO[eO])
            })) ? "cryo" : "water"
          }(OO, KO, pO, bK),
          VO = function(OO, KO, pO, XO) {
            let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "water",
              eO = 0;
            return LO.forEach(((vK, hO) => {
              let [DO, MO, aK] = vK;
              const oO = zK(OO(KO + DO, pO + MO, XO + aK), bK);
              oO && (0, lO.L)(CO, oO, QO[hO]) && (eO |= 1 << hO)
            })), eO
          }(OO, KO, pO, bK, FO),
          AO = hO ? function(OO) {
            var KO;
            return !0 === (null === (KO = TO(OO)) || void 0 === KO ? void 0 : KO.full)
          }(oO) : IO(OO, KO, pO, bK, FO, VO);
        return (0, XO.p)((0, eO.r)(FO, VO, AO))
      }
    }
  },
  36576: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO,
      f: () => eO
    });
    const XO = ["Chest", "Loot Chest", "Moonstone Chest"],
      bK = [{
        name: "Workbench",
        exactMatch: !0
      }, {
        name: "Furnace",
        exactMatch: !0
      }, {
        name: "Artisan Bench",
        exactMatch: !0
      }, {
        name: "Potion Table",
        exactMatch: !0
      }, {
        name: "Salvaging Table",
        exactMatch: !0
      }, {
        name: "Enchanting Table",
        exactMatch: !1
      }];

    function eO(OO) {
      return bK.find((KO => KO.exactMatch ? OO === KO.name : OO.includes(KO.name)))
    }
  },
  35411: (OO, KO, pO) => {
    function XO(OO) {
      return OO.includes("Leaf Bed")
    }

    function bK(OO) {
      return / Bed(?: Head)?(?:\||$)/.test(OO) && !XO(OO)
    }

    function eO(OO) {
      return OO.includes(" Strongbed")
    }

    function lO(OO) {
      return XO(OO) || bK(OO) || eO(OO)
    }
    pO.d(KO, {
      c: () => lO,
      g: () => XO,
      k: () => eO,
      l: () => bK
    })
  },
  35409: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => hO
    });
    var XO = pO(35411),
      bK = pO(8365);
    const eO = [],
      lO = [],
      vK = [],
      CO = [];
    for (const DO of Object.keys(bK.r))(0, XO.g)(DO) ? eO.push(DO) : (0, XO.l)(DO) && lO.push(DO), (0, XO.k)(DO) && vK.push(DO), (DO.includes(" Bed Head") || DO.includes(" Strongbed Head")) && CO.push(DO);
    const hO = {
      leafBeds: eO,
      woolBeds: lO,
      strongBeds: vK,
      beds: [...eO, ...lO, ...vK],
      bedHeads: CO,
      blockRemoveActionRoots: ["Chest", "Loot Chest", "Iron Chest", "Mailbox", "Bookshelf", "Empty Bookshelf"]
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);