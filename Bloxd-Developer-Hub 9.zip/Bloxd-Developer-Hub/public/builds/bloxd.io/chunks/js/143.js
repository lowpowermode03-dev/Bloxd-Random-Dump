export const id = 143;
export const ids = [143];
export const modules = {
  7238: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      NitroSdkAdaptor: () => lO
    });
    var XO = pO(1158),
      bK = pO(1044);
    const eO = "NitroOutstreamVideo";
    class lO extends XO.c {
      constructor() {
        super(), this.name = "nitro", this.bannerAutoRefresh = "alwaysOn", this.videoInFlight = !1
      }
      static async setup() {
        return window.nitroAds = window.nitroAds || {
          createAd: function() {
            for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
            return new Promise((OO => {
              window.nitroAds.queue.push(["createAd", KO, OO])
            }))
          },
          addUserToken: function() {
            for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
            window.nitroAds.queue.push(["addUserToken", KO])
          },
          queue: []
        }, document.addEventListener("nitroAds.rendered", (OO => {
          var KO, pO, XO;
          const bK = document.getElementById(null !== (KO = null === (pO = OO.detail) || void 0 === pO || null === (XO = pO.adInfo) || void 0 === XO ? void 0 : XO.adUnitCode) && void 0 !== KO ? KO : "");
          null !== bK && void 0 !== bK && bK.classList.contains("NitroBanner") && bK.classList.toggle("NitroBannerUnfilled", "blank" === OO.detail.type)
        })), await (0, bK.e)("https://s.nitropay.com/ads-2842.js", {
          "data-cfasync": "false"
        }), new lO
      }
      playVideoAd(OO, KO) {
        this.showVideoAd(OO, OO)
      }
      playRewarded(OO, KO) {
        this.showVideoAd(OO, KO)
      }
      showVideoAd(OO, KO) {
        if (this.videoInFlight) return console.log("AD: Nitro video already playing"), void KO();
        const pO = document.getElementById("GenericVideoWrapper"),
          XO = document.getElementById("GenericVideoInner");
        if (null === pO || null === XO) return void KO();
        this.videoInFlight = !0;
        let bK = !1;
        const lO = document.createElement("div");
        lO.id = eO, lO.className = "NitroVideoPlacement";
        const vK = eO => {
          if (!bK) {
            bK = !0, clearTimeout(QO), clearInterval(LO), document.removeEventListener("nitroAds.adResult", DO), document.removeEventListener("nitroAds.rendered", MO), document.removeEventListener("nitroAds.complete", aK);
            try {
              oO.remove(), lO.querySelectorAll("video").forEach((OO => {
                OO.pause()
              })), lO.remove(), XO.classList.remove("NitroVideo"), pO.style.display = "none"
            } catch (vK) {
              console.error("AD: Error tearing down Nitro video", vK)
            } finally {
              this.videoInFlight = !1, window.adCompleteSoResume(), eO ? OO() : KO()
            }
          }
        };
        let CO = !1;
        const hO = (OO, KO) => {
            if (!CO) {
              if (!OO) return console.log(`AD: Nitro video not filled: ${KO}`), void vK(!1);
              CO = !0, clearTimeout(QO), QO = setTimeout((() => {
                console.log("AD: Nitro video never completed"), vK(!1)
              }), 12e4)
            }
          },
          DO = OO => {
            var KO;
            (null === (KO = OO.detail) || void 0 === KO ? void 0 : KO.id) === eO && hO("filled" === OO.detail.status, OO.detail.status)
          },
          MO = OO => {
            var KO, pO;
            (null === (KO = OO.detail) || void 0 === KO || null === (pO = KO.adInfo) || void 0 === pO ? void 0 : pO.adUnitCode) === eO && hO("blank" !== OO.detail.type, OO.detail.type)
          },
          aK = OO => {
            var KO;
            (null === (KO = OO.detail) || void 0 === KO ? void 0 : KO.adUnitCode) === eO && vK(!0)
          },
          oO = document.createElement("button");
        oO.className = "NitroVideoSkip", oO.disabled = !0, oO.addEventListener("click", (() => {
          console.log("AD: Nitro video skipped"), vK(!0)
        }));
        let FO = Math.ceil(15);
        const VO = () => {
          if (FO <= 0) return clearInterval(LO), oO.textContent = "Skip Ad", void(oO.disabled = !1);
          oO.textContent = `Skip ad in ${FO}s`, FO--
        };
        VO();
        const LO = setInterval(VO, 1e3);
        let QO = setTimeout((() => {
          console.log("AD: Nitro video got no result"), vK(!1)
        }), 1e4);
        document.addEventListener("nitroAds.adResult", DO), document.addEventListener("nitroAds.rendered", MO), document.addEventListener("nitroAds.complete", aK), XO.appendChild(lO), XO.classList.add("NitroVideo"), pO.appendChild(oO), pO.style.display = "flex", window.adStartSoPause(null, {
          preventMovement: !0
        }), Promise.resolve(window.nitroAds.createAd(eO, {
          format: "display",
          outstream: "only",
          resultTimeout: 8e3
        })).catch((OO => {
          console.error("AD: Nitro failed to create video", OO), vK(!1)
        })), console.log("AD: Requested Nitro video")
      }
      renderBanner(OO) {
        const {
          divId: KO,
          width: pO,
          height: XO
        } = OO, bK = `${KO}-nitro`;
        let eO = document.getElementById(bK);
        null === eO && (eO = document.createElement("div"), eO.id = bK, eO.className = "NitroBanner", eO.style.setProperty("--nitro-slot-width", `${pO}px`), eO.style.setProperty("--nitro-slot-height", `${XO}px`), document.getElementById(KO).appendChild(eO));
        const lO = [
          [String(pO), String(XO)]
        ];
        Promise.resolve(window.nitroAds.createAd(bK, {
          sizes: lO
        })).catch((OO => {
          console.error(`AD: Nitro failed to create banner ${bK}:`, OO)
        })), console.log(`AD: Requested Nitro banner ${bK}`)
      }
      displayConsentUI() {
        var OO, KO;
        null === (OO = (KO = window).__cmp) || void 0 === OO || OO.call(KO, "showModal")
      }
      addPrivacyLinks(OO) {
        var KO, pO, XO, bK;
        const eO = document.createElement("span");
        eO.dataset.ccpaLink = "1";
        const lO = document.createElement("div");
        lO.id = "ncmp-consent-link", OO.replaceChildren(eO, lO), null === (KO = (pO = window).__uspapi) || void 0 === KO || KO.call(pO, "addLink", 1), null === (XO = (bK = window).__cmp) || void 0 === XO || XO.call(bK, "addConsentLink")
      }
      newPageSession() {
        var OO, KO;
        null === (OO = (KO = window.nitroAds).navigate) || void 0 === OO || OO.call(KO)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);