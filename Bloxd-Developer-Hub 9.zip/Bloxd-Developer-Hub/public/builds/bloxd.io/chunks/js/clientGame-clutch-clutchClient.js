export const id = 13;
export const ids = [13];
export const modules = {
  37630: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => XO
    });
    const XO = function(OO, KO, pO) {
      let XO;
      return {
        onCreate: OO => {
          XO = OO
        },
        onPlayerAltAction: (OO, KO, pO, bK, eO, lO) => {
          lO && "Mesh" === XO.getEntityType(lO) && "Quartermaster" === XO.getEntityName(lO) && XO.openShop(OO, !1, "Armoury")
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);