export const id = 20;
export const ids = [20];
export const modules = {
  37673: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => eO
    });
    const XO = {
      Maverick: "Portal Config",
      "Bling Bling": "Bank",
      Fred: "Farmer",
      Spencer: "Painter's Guild",
      Lorenzo: "Monster Hunter's Guild",
      Gill: "Farmer's Guild",
      Wren: "Travelling Trader"
    };
    const bK = 6400;
    const eO = function(OO, KO, pO, eO) {
      let lO, {
          localPlayerId: vK
        } = eO,
        CO = [];
      return {
        onCreate: OO => {
          lO = OO
        },
        onReceivedMessageFromServer: (OO, KO) => {
          "oneBlockNextBlocks" === OO && (CO = KO.blocks.map((OO => lO.blockNameToBlockId(OO))))
        },
        KK: () => {
          if (0 === CO.length) return;
          const OO = lO.getPositionView(vK),
            KO = function(OO, KO) {
              const pO = Math.ceil((OO - 3200) / bK);
              if (pO !== Math.ceil((KO - 3200) / bK) || pO <= 0) return null;
              const XO = pO * bK + 6;
              return [XO, 10, XO]
            }(OO[0], OO[2]);
          if (!KO) return;
          const [pO, XO, eO] = KO;
          if (lO.isBlockInLoadedChunk(pO, XO, eO) && 0 === lO.getBlockId(pO, XO, eO)) {
            const OO = CO.shift();
            lO.setBlockId(pO, XO, eO, OO)
          }
        },
        onPlayerAltAction: (OO, KO, pO, bK, eO, vK) => {
          ! function(OO, KO, pO, bK) {
            if (!pO || "Mesh" !== OO.getEntityType(pO)) return !1;
            const eO = XO[OO.getEntityName(pO)];
            !!eO && OO.openShop(KO, bK, eO)
          }(lO, OO, vK, !1)
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);