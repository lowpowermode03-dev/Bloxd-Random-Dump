export const id = 184;
export const ids = [184];
export const modules = {
  37483: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      constructor(OO, KO) {
        this.read = OO, this.apply = KO, this.release = null
      }
      turn(OO, KO) {
        const pO = null === this.release ? this.read() : this.release.transitionMs;
        this.stop(!1), this.apply({
          forcedCameraDirectionTransitionMs: KO,
          forcedCameraDirection: [OO[0], OO[1], OO[2]]
        }), this.release = {
          timer: setTimeout((() => {
            this.stop(!0)
          }), KO + 100),
          transitionMs: pO
        }
      }
      dispose() {
        this.stop(!0)
      }
      stop(OO) {
        null !== this.release && (clearTimeout(this.release.timer), OO && this.apply({
          forcedCameraDirection: null,
          forcedCameraDirectionTransitionMs: this.release.transitionMs
        }), this.release = null)
      }
    }
  },
  37025: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      h: () => bK
    });
    const XO = new Map;

    function bK(OO, KO) {
      XO.set(OO, KO)
    }

    function eO(OO) {
      return OO ? XO.get(OO) : void 0
    }
  },
  37817: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(36612);

    function bK(OO, KO, pO) {
      var bK, eO, lO, vK, CO, hO, DO;
      const MO = (0, XO.d)(OO, KO, pO[0], pO[1], pO[2]),
        aK = MO ? null !== (bK = MO.textCell) && void 0 !== bK ? bK : MO.rect.anchor : pO,
        oO = KO(aK[0], aK[1], aK[2]);
      return {
        pos: [pO[0], pO[1], pO[2]],
        noticeboardSpan: MO && {
          width: MO.rect.width,
          height: MO.rect.height
        },
        text: null !== (eO = null === oO || void 0 === oO || null === (lO = oO.persisted) || void 0 === lO || null === (vK = lO.shared) || void 0 === vK ? void 0 : vK.text) && void 0 !== eO ? eO : "",
        textSize: null !== (CO = null === oO || void 0 === oO || null === (hO = oO.persisted) || void 0 === hO || null === (DO = hO.shared) || void 0 === DO ? void 0 : DO.textSize) && void 0 !== CO ? CO : null
      }
    }
  },
  36895: (OO, KO, pO) => {
    function XO(OO) {
      switch (OO.kind) {
        case void 0:
        case "flatEmissive":
          return !1;
        case "chevronPath":
        case "furnaceFire":
          return !0
      }
    }
    pO.d(KO, {
      d: () => bK,
      h: () => eO,
      i: () => XO
    });
    const bK = 4,
      eO = 3
  },
  37505: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK,
      f: () => eO
    });
    var XO = pO(256);
    const bK = new Set(["bedwars", "bridgeBattle", "buildAFactory2", "classic", "clutch", "cooking", "defusal", "frontline", "goalRush", "luckyBedwars", "ninetyNineNights", "oneBlock", "plots", "pvpCiv", "skyIslands", "skyblock", "tsunami"]);
    class eO {
      constructor(OO) {
        this.importGame = OO, this.loads = new Map, this.loaded = new Map
      }
      load(OO) {
        const KO = (0, XO.Qb)(OO);
        if (!bK.has(KO)) return Promise.resolve(void 0);
        let pO = this.loads.get(KO);
        return pO || (pO = this.importGame(KO).then((OO => {
          const pO = OO.default;
          if ("function" !== typeof pO) throw new Error(`${KO}'s client code has no default-exported factory`);
          return this.loaded.set(KO, pO), pO
        })).catch((OO => {
          throw this.loads.delete(KO), OO
        })), this.loads.set(KO, pO)), pO
      }
      loadedFactory(OO) {
        const KO = (0, XO.Qb)(OO);
        if (!bK.has(KO)) return;
        const pO = this.loaded.get(KO);
        if (!pO) throw new Error(`${KO}'s client code started before it loaded`);
        return pO
      }
    }
  },
  37825: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO
    });
    var XO = pO(8461),
      bK = pO(35217),
      eO = pO(2560);

    function lO(OO) {
      if (OO === XO.c) return 0;
      const KO = (0, eO.c)(OO);
      if (void 0 !== KO && KO <= bK.MAX_BLOCK_ID) return KO;
      const pO = (0, eO.c)(OO.split("|")[0]);
      if (void 0 !== pO && pO <= bK.MAX_BLOCK_ID && (0, bK.rootMetaDescOf)(pO) === OO) return pO;
      throw new Error(`Invalid block name. You sent ${OO}. The only valid block names are 'Air' and those contained within the blockMetadata.ts file`)
    }
  },
  37562: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(22);
    class bK {
      constructor(OO) {
        this.screen = OO, this.hidesHud = !1
      }
      show(OO, KO) {
        this.screen.setFade(OO.colour, OO.alpha), this.screen.setLetterbox(!0 === KO.letterbox, OO.alpha < 1), this.setHudHidden(!0 === KO.hideHud)
      }
      clear() {
        this.screen.clear(), this.setHudHidden(!1)
      }
      setHudHidden(OO) {
        this.hidesHud !== OO && (this.hidesHud = OO, XO.d.set({
          isUiHiddenByCamera: OO
        }))
      }
    }
  },
  37531: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      f: () => aK,
      g: () => MO,
      i: () => lO,
      j: () => FO,
      m: () => CO,
      q: () => VO,
      t: () => hO,
      w: () => vK,
      x: () => DO
    });
    const XO = Math.PI / 2 - .001,
      bK = 2 * Math.PI,
      eO = 1e-9;

    function lO(OO, KO) {
      KO.heading = OO.heading, KO.pitch = OO.pitch
    }

    function vK(OO, KO) {
      const pO = KO - OO;
      return pO - bK * Math.floor((pO + Math.PI) / bK)
    }

    function CO(OO, KO, pO) {
      return OO + vK(OO, KO) * pO
    }

    function hO(OO) {
      if (!Number.isFinite(OO)) return OO;
      const KO = OO - bK * Math.floor(OO / bK);
      return KO < bK ? KO : 0
    }

    function DO(OO, KO) {
      return OO + vK(OO, KO)
    }

    function MO(OO) {
      return Math.max(-XO, Math.min(XO, OO))
    }

    function aK(OO, KO, pO) {
      const XO = Math.cos(KO);
      return pO[0] = XO * Math.sin(OO), pO[1] = -Math.sin(KO), pO[2] = XO * Math.cos(OO), pO
    }

    function oO(OO, KO, pO, XO) {
      const bK = Math.sqrt(OO * OO + pO * pO);
      return bK < eO && Math.abs(KO) < eO || (bK >= eO && (XO.heading = Math.atan2(OO, pO)), XO.pitch = MO(Math.atan2(-KO, bK) + 0)), XO
    }

    function FO(OO, KO) {
      return oO(OO[0], OO[1], OO[2], KO)
    }

    function VO(OO, KO, pO) {
      return oO(KO[0] - OO[0], KO[1] - OO[1], KO[2] - OO[2], pO)
    }
  },
  37560: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      f: () => bK
    });
    var XO = pO(37531);

    function bK(OO) {
      var KO;
      const pO = "default" === OO.mode ? "movement" : null !== (KO = OO.playerFacing) && void 0 !== KO ? KO : "movement";
      return "cursor" === pO ? {
        facing: pO,
        mouseTurns: null
      } : {
        facing: pO,
        mouseTurns: "default" !== OO.mode && void 0 !== OO.playerLook ? "look" : "view"
      }
    }

    function eO(OO, KO, pO, bK, eO, lO) {
      return lO.wKO = 0, lO.ipO = 0, lO.pointedAt = void 0, void 0 !== bK ? eO ? (lO.pointedAt = bK, OO) : (0, XO.t)(bK.heading) : eO ? (lO.wKO = KO, lO.ipO = pO, OO) : (0, XO.t)(OO + KO)
    }
  },
  37547: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => cK
    });
    var XO = pO(37553),
      bK = pO(37531),
      eO = pO(35460);

    function lO(OO, KO, pO, XO) {
      if (!(XO > 0)) return KO;
      const bK = KO > OO ? Math.min(KO, OO + pO / XO) : Math.max(KO, OO - pO / XO);
      return Math.abs(KO - bK) < 1e-9 ? KO : bK
    }
    class vK {
      constructor() {
        this.phase = null, this.outMs = 0, this.holdMs = 0, this.inMs = 0, this.heldMs = 0, this.sinceTurnMs = 1 / 0, this.clearMs = 1 / 0, this.waiting = null, this.screen = {
          colour: XO.d,
          alpha: 0
        }
      }
      getScreen() {
        return this.screen
      }
      fadeOut(OO) {
        !this.isGoingOut() && this.sinceTurnMs < XO.i.minFadeTurnMs ? this.waiting = {
          turn: "out",
          transition: OO
        } : (this.waiting = null, this.startOut(OO))
      }
      fadeIn(OO) {
        this.isGoingOut() ? this.sinceTurnMs < XO.i.minFadeTurnMs ? this.waiting = {
          turn: "in",
          minMs: OO
        } : (this.waiting = null, this.startIn(OO)) : this.waiting = null
      }
      advance(OO) {
        const KO = this.waiting;
        if (null === KO) return this.step(OO);
        const pO = XO.i.minFadeTurnMs - this.sinceTurnMs;
        if (pO > OO) return this.step(OO);
        const bK = this.step(pO);
        return this.waiting = null, "out" === KO.turn ? this.startOut(KO.transition) : this.startIn(KO.minMs), this.step(OO - pO) || bK
      }
      isGoingOut() {
        return "out" === this.phase || "hold" === this.phase
      }
      startOut(OO) {
        ("in" === this.phase || null === this.phase && this.clearMs < XO.i.minFadeTurnMs) && (this.sinceTurnMs = 0), this.phase = "out", 0 === this.screen.alpha && (this.screen.colour = OO.colour), this.outMs = OO.outMs, this.holdMs = OO.holdMs, this.inMs = OO.inMs
      }
      startIn(OO) {
        this.isGoingOut() && (this.sinceTurnMs = 0), this.phase = "in", this.inMs = Math.max(OO, this.inMs)
      }
      step(OO) {
        const KO = this.screen;
        this.sinceTurnMs += OO, null === this.phase && (this.clearMs += OO);
        let pO = !1,
          bK = OO;
        if ("out" === this.phase) {
          const XO = (1 - KO.alpha) * this.outMs;
          if (KO.alpha = lO(KO.alpha, 1, OO, this.outMs), KO.alpha < 1) return !1;
          this.phase = "hold", this.heldMs = 0, bK = Math.max(0, OO - XO), pO = !0
        }
        let eO = OO;
        if ("hold" === this.phase) {
          this.heldMs += bK;
          const OO = Math.min(this.heldMs - this.holdMs, this.sinceTurnMs - XO.i.minFadeTurnMs);
          if (OO < 0 || pO) return pO;
          this.phase = "in", this.sinceTurnMs = OO, eO = OO
        }
        return "in" === this.phase && (KO.alpha = lO(KO.alpha, 0, eO, this.inMs), KO.alpha <= 0 && (this.phase = null, this.clearMs = 0)), pO
      }
    }
    var CO = pO(37522),
      hO = pO(37556),
      DO = pO(1531),
      MO = pO(35107);

    function aK(OO, KO) {
      for (let pO = 0; pO < KO.length; pO++) KO[pO] = OO[pO]
    }

    function oO(OO, KO) {
      var pO;
      return null !== (pO = OO.fov) && void 0 !== pO ? pO : KO.getDefaultFov()
    }

    function FO(OO, KO, pO, XO, bK) {
      const eO = 2 / XO,
        lO = Math.exp(-eO * bK);
      for (let vK = 0; vK < OO.length; vK++) {
        const XO = OO[vK] - pO[vK],
          CO = (KO[vK] + eO * XO) * bK;
        OO[vK] = pO[vK] + (XO + CO) * lO, KO[vK] = (KO[vK] - eO * CO) * lO
      }
    }
    class VO {
      constructor(OO, KO, pO, XO) {
        var eO, lO, vK, CO, hO;
        this.settings = OO, this.lK = KO, this.targets = pO, this.base = void 0, this.closestDistance = void 0, this.furthestDistance = void 0, this.goal = void 0, this.framedTargets = !1, this.smoothed = [0, 0, 0, 0, 0, 0], this.ul = [0, 0, 0, 0, 0, 0], this.started = !1, this.angles = {
          heading: 0,
          pitch: 0
        }, this.points = [], this.forward = [0, 0, 0], this.base = {
          heading: (0, bK.t)((0, DO.n)(null !== (eO = OO.viewHeading) && void 0 !== eO ? eO : 0)),
          pitch: (0, bK.g)((0, DO.n)(null !== (lO = OO.viewElevation) && void 0 !== lO ? lO : 45))
        }, this.closestDistance = null !== (vK = OO.closestDistance) && void 0 !== vK ? vK : Math.min(6, null !== (CO = OO.furthestDistance) && void 0 !== CO ? CO : 1 / 0), this.furthestDistance = null !== (hO = OO.furthestDistance) && void 0 !== hO ? hO : Math.max(64, this.closestDistance);
        const MO = (0, bK.f)(this.base.heading, this.base.pitch, this.forward),
          aK = XO.position,
          oO = this.closestDistance;
        this.goal = [aK[0] + MO[0] * oO, aK[1] + MO[1] * oO, aK[2] + MO[2] * oO, oO, this.base.heading, this.base.pitch]
      }
      update(OO, KO, pO) {
        var XO, eO;
        this.placeGoal(null !== (XO = this.settings.fov) && void 0 !== XO ? XO : this.lK.getBaseFov()), this.goal[4] = (0, bK.x)(this.smoothed[4], this.base.heading), this.goal[5] = this.base.pitch;
        const lO = null !== (eO = this.settings.smoothMs) && void 0 !== eO ? eO : 400;
        !this.started || lO < 1 ? (aK(this.goal, this.smoothed), this.ul.fill(0), this.started = !0) : FO(this.smoothed, this.ul, this.goal, lO, OO), this.angles.heading = this.smoothed[4], this.angles.pitch = (0, bK.g)(this.smoothed[5]), KO.apply(this.angles, pO);
        const vK = (0, bK.f)(pO.heading, pO.pitch, this.forward);
        for (let bK = 0; bK < 3; bK++) pO.position[bK] = this.smoothed[bK] - vK[bK] * this.smoothed[3];
        pO.fov = oO(this.settings, this.lK)
      }
      continueFrom(OO) {
        OO instanceof VO && (aK(OO.goal, this.goal), aK(OO.smoothed, this.smoothed), aK(OO.ul, this.ul), this.framedTargets = OO.framedTargets, this.started = OO.started)
      }
      reset() {
        this.ul.fill(0), this.started = !1
      }
      placeGoal(OO) {
        var KO;
        let pO = 0;
        for (const DO of this.settings.targets) {
          const OO = this.targets.currentAimPoint(DO);
          OO && (0, CO.i)(OO, this.pointAt(pO++))
        }
        if (pO > 0) this.framedTargets = !0;
        else if (!this.framedTargets) {
          const OO = this.targets.aimPoint(this.lK.localPlayerId);
          OO && (0, CO.i)(OO, this.pointAt(pO++))
        }
        const XO = this.goal;
        if (0 === pO) return void(XO[3] = this.withinDistances(XO[3]));
        for (let CO = 0; CO < 3; CO++) {
          let OO = 1 / 0,
            KO = -1 / 0;
          for (let XO = 0; XO < pO; XO++) OO = Math.min(OO, this.points[XO][CO]), KO = Math.max(KO, this.points[XO][CO]);
          XO[CO] = (OO + KO) / 2
        }
        let bK = 0;
        for (let CO = 0; CO < pO; CO++) {
          const OO = this.points[CO];
          bK = Math.max(bK, Math.hypot(OO[0] - XO[0], OO[1] - XO[1], OO[2] - XO[2]))
        }
        const eO = Math.tan((0, DO.n)(OO) / 2),
          lO = Math.atan(eO * (!0 === this.settings.letterbox ? MO.f : 1)),
          vK = Math.atan(eO * this.lK.getAspectRatio()),
          hO = (bK + (null !== (KO = this.settings.padding) && void 0 !== KO ? KO : 2)) / Math.sin(Math.min(lO, vK));
        XO[3] = this.withinDistances(hO)
      }
      withinDistances(OO) {
        return Math.min(this.furthestDistance, Math.max(this.closestDistance, OO))
      }
      pointAt(OO) {
        return OO === this.points.length && this.points.push([0, 0, 0]), this.points[OO]
      }
    }
    class LO {
      constructor(OO) {
        this.limits = OO, this.yawOffset = 0, this.pitchOffset = 0, this.idleMs = 0, this.pointedAt = null
      }
      continueFrom(OO) {
        this.limits && (this.yawOffset = OO.yawOffset, this.pitchOffset = OO.pitchOffset, this.idleMs = OO.idleMs)
      }
      update(OO, KO) {
        const pO = this.limits;
        if (!pO) return;
        const XO = Number.isFinite(KO.wKO) ? KO.wKO : 0,
          bK = Number.isFinite(KO.ipO) ? KO.ipO : 0;
        if (KO.pointedAt) this.idleMs = 0, this.pointedAt = {
          heading: KO.pointedAt.heading,
          pitch: KO.pointedAt.pitch
        };
        else if (0 !== XO || 0 !== bK) this.idleMs = 0, this.yawOffset += XO, this.pitchOffset += bK;
        else {
          const KO = Math.max(0, this.idleMs + OO - 200) - Math.max(0, this.idleMs - 200);
          if (this.idleMs += OO, void 0 !== pO.returnMs && KO > 0) {
            const OO = pO.returnMs > 0 ? Math.exp(-3 * KO / pO.returnMs) : 0;
            this.yawOffset *= OO, this.pitchOffset *= OO
          }
        }
        this.clampOffsets(pO)
      }
      clampOffsets(OO) {
        if (OO.maxYaw >= 180) this.yawOffset = (0, bK.w)(0, this.yawOffset);
        else {
          const KO = (0, DO.n)(OO.maxYaw);
          this.yawOffset = Math.max(-KO, Math.min(KO, this.yawOffset))
        }
        const KO = (0, DO.n)(OO.maxPitch);
        this.pitchOffset = Math.max(-KO, Math.min(KO, this.pitchOffset))
      }
      apply(OO, KO) {
        this.pointedAt && this.limits && (this.yawOffset = (0, bK.w)(OO.heading, this.pointedAt.heading), this.pitchOffset = this.pointedAt.pitch - OO.pitch, this.pointedAt = null, this.clampOffsets(this.limits));
        const pO = (0, bK.g)(OO.pitch + this.pitchOffset);
        this.pitchOffset = pO - OO.pitch, KO.heading = (0, bK.t)(OO.heading + this.yawOffset), KO.pitch = pO
      }
      unapply(OO, KO) {
        KO.heading = (0, bK.t)(OO.heading - this.yawOffset), KO.pitch = (0, bK.g)(OO.pitch - this.pitchOffset)
      }
    }
    const QO = 1e-6;

    function zK(OO) {
      return Math.sqrt(OO[0] * OO[0] + OO[1] * OO[1] + OO[2] * OO[2])
    }

    function AO(OO, KO, pO, XO, bK) {
      const eO = bK * bK,
        lO = eO * bK;
      return (2 * lO - 3 * eO + 1) * OO + (lO - 2 * eO + bK) * KO + (-2 * lO + 3 * eO) * pO + (lO - eO) * XO
    }

    function fO(OO, KO, pO, XO, bK) {
      const eO = bK * bK;
      return (6 * eO - 6 * bK) * OO + (3 * eO - 4 * bK + 1) * KO + (-6 * eO + 6 * bK) * pO + (3 * eO - 2 * bK) * XO
    }

    function dO(OO, KO) {
      const pO = KO[0] - OO[0],
        XO = KO[1] - OO[1],
        bK = KO[2] - OO[2];
      return Math.sqrt(pO * pO + XO * XO + bK * bK)
    }

    function TO(OO, KO, pO, XO, bK, eO) {
      for (let lO = 0; lO < 3; lO++) eO[lO] = bK ? OO[lO] * XO : pO[lO] - KO[lO];
      return bK && function(OO, KO) {
        const pO = zK(OO);
        if (pO > KO) {
          const XO = KO / pO;
          OO[0] *= XO, OO[1] *= XO, OO[2] *= XO
        }
      }(eO, 3 * dO(KO, pO)), eO
    }

    function NO(OO, KO, pO, XO) {
      for (let bK = 0; bK < 3; bK++) XO[bK] = 6 * (KO[bK] - OO[bK]) - 2 * pO[bK];
      if (zK(XO) < QO)
        for (let bK = 0; bK < 3; bK++) XO[bK] = KO[bK] - OO[bK];
      return XO
    }

    function IO(OO, KO) {
      return [2 * KO[0] - OO[0], 2 * KO[1] - OO[1], 2 * KO[2] - OO[2]]
    }

    function yK(OO, KO, pO, XO, bK, eO, lO) {
      if (!eO && !lO) return 0;
      const vK = eO ? OO : 2 * KO - pO,
        CO = lO ? pO : 2 * KO - OO,
        hO = eO ? XO : bK,
        DO = lO ? bK : XO,
        MO = (KO - vK) / hO,
        aK = (CO - KO) / DO;
      if (MO * aK <= 0) return 0;
      const oO = (CO - vK) / (hO + DO),
        FO = 3 * Math.min(Math.abs(MO), Math.abs(aK));
      return Math.max(-FO, Math.min(FO, oO))
    }

    function gK(OO, KO, pO, XO, bK, eO, lO) {
      const {
        u: vK,
        segmentMs: CO
      } = OO;
      if (!OO.curved) return pO + (XO - pO) * vK;
      return AO(pO, yK(KO, pO, XO, OO.beforeMs, CO, eO, !0) * CO, XO, yK(pO, XO, bK, CO, OO.afterMs, !0, lO) * CO, vK)
    }

    function uO(OO) {
      return Math.abs(OO.pitch) >= bK.d
    }
    class EO {
      constructor(OO, KO, pO, XO, bK) {
        this.nodes = OO, this.prevNodes = pO, this.nextNodes = XO, this.tangents = void 0, this.derivative = [0, 0, 0], this.beforeAngles = {
          heading: 0,
          pitch: 0
        }, this.fromAngles = {
          heading: 0,
          pitch: 0
        }, this.toAngles = {
          heading: 0,
          pitch: 0
        }, this.afterAngles = {
          heading: 0,
          pitch: 0
        }, this.borrowedAngles = {
          heading: 0,
          pitch: 0
        }, this.tangents = OO.map(((OO, pO) => this.nodeTangent(KO, bK, pO)))
      }
      sample(OO, KO, pO) {
        const {
          index: XO,
          toIndex: eO,
          segmentMs: lO,
          curved: vK
        } = OO, CO = this.fromAngles, hO = this.toAngles, DO = this.nodeAngles(XO, pO.position, KO, CO), MO = this.nodeAngles(eO, pO.position, KO, hO);
        if (lO > 0 && "aim" !== DO && "aim" !== MO && this.liveTangent(OO, CO)) return pO.heading = (0, bK.t)(CO.heading), void(pO.pitch = CO.pitch);
        if ("none" === DO && "none" === MO) return;
        !vK && lO > 0 && ("tangent" === DO && this.liveTangent(OO, CO), "tangent" === MO && this.liveTangent(OO, hO)), "none" === DO ? (0, bK.i)(hO, CO) : "none" === MO && (0, bK.i)(CO, hO);
        const aK = vK && OO.beforeIndex >= 0 && "none" !== this.nodeAngles(OO.beforeIndex, pO.position, KO, this.beforeAngles),
          oO = vK && OO.afterIndex >= 0 && "none" !== this.nodeAngles(OO.afterIndex, pO.position, KO, this.afterAngles),
          FO = (0, bK.x)(CO.heading, hO.heading),
          VO = gK(OO, aK ? (0, bK.x)(CO.heading, this.beforeAngles.heading) : 0, CO.heading, FO, oO ? (0, bK.x)(FO, this.afterAngles.heading) : 0, aK, oO);
        pO.heading = (0, bK.t)(VO), pO.pitch = (0, bK.g)(gK(OO, this.beforeAngles.pitch, CO.pitch, hO.pitch, this.afterAngles.pitch, aK, oO))
      }
      nodeAngles(OO, KO, pO, XO) {
        const bK = this.rawNodeAngles(OO, KO, pO, XO);
        return "none" !== bK && uO(XO) && !this.borrowHeading(this.prevNodes[OO], KO, pO, XO) && this.borrowHeading(this.nextNodes[OO], KO, pO, XO), bK
      }
      borrowHeading(OO, KO, pO, XO) {
        const bK = this.borrowedAngles;
        return !(OO < 0 || "none" === this.rawNodeAngles(OO, KO, pO, bK) || uO(bK)) && (XO.heading = bK.heading, !0)
      }
      rawNodeAngles(OO, KO, pO, XO) {
        const eO = this.nodes[OO].keyframe;
        if (eO.lookDirection) return (0, bK.j)(eO.lookDirection, XO), "aim";
        if (void 0 !== eO.lookAt) {
          const OO = pO(eO.lookAt);
          if (OO) return (0, bK.q)(KO, OO, XO), "aim"
        }
        const lO = this.tangents[OO];
        return lO ? ((0, bK.i)(lO, XO), "tangent") : "none"
      }
      liveTangent(OO, KO) {
        const pO = this.nodes[OO.index].position,
          XO = this.nodes[OO.toIndex].position,
          eO = this.derivative;
        for (let bK = 0; bK < 3; bK++) eO[bK] = fO(pO[bK], OO.fromTangent[bK], XO[bK], OO.toTangent[bK], OO.u);
        return zK(eO) > 1e-9 ? ((0, bK.j)(eO, KO), !0) : !(dO(pO, XO) < QO) && ((0, bK.j)(NO(pO, XO, OO.u < .5 ? OO.toTangent : OO.fromTangent, eO), KO), !0)
      }
      nodeTangent(OO, KO, pO) {
        var XO;
        const eO = OO[pO];
        if (zK(eO) > 1e-9) return (0, bK.j)(eO, {
          heading: 0,
          pitch: 0
        });
        const lO = null !== (XO = this.restDirectionTo(pO, pO + 1, OO, KO)) && void 0 !== XO ? XO : this.restDirectionTo(pO, pO - 1, OO, KO);
        return lO ? (0, bK.j)(lO, {
          heading: 0,
          pitch: 0
        }) : null
      }
      restDirectionTo(OO, KO, pO, XO) {
        const bK = this.nodes[OO],
          eO = this.nodes[KO];
        if (!eO || dO(bK.position, eO.position) < QO) return null;
        const [lO, vK] = KO > OO ? [bK, eO] : [eO, bK], CO = TO(pO[KO], lO.position, vK.position, vK.timeMs - lO.timeMs, XO, [0, 0, 0]);
        return NO(lO.position, vK.position, CO, [0, 0, 0])
      }
    }

    function jK(OO, KO) {
      const pO = OO.lookDirection || KO.lookDirection ? function(OO, KO) {
        if (!OO || !KO) return OO === KO;
        const pO = zK(OO),
          XO = zK(KO);
        return Math.hypot(OO[0] / pO - KO[0] / XO, OO[1] / pO - KO[1] / XO, OO[2] / pO - KO[2] / XO) < QO
      }(OO.lookDirection, KO.lookDirection) : (XO = OO.lookAt, bK = KO.lookAt, "object" !== typeof XO || "object" !== typeof bK ? XO === bK : dO(XO, bK) < QO);
      var XO, bK;
      return dO(OO.position, KO.position) < QO && OO.fov === KO.fov && pO
    }
    class YO {
      constructor(OO, KO, pO) {
        if (this.smooth = KO, this.nodes = void 0, this.velocities = void 0, this.prevNodes = void 0, this.nextNodes = void 0, this.prevGaps = void 0, this.nextGaps = void 0, this.loopMs = void 0, this.aim = void 0, this.segment = {
            index: 0,
            toIndex: 0,
            u: 0,
            segmentMs: 0,
            curved: !1,
            beforeIndex: -1,
            afterIndex: -1,
            beforeMs: 0,
            afterMs: 0,
            fromTangent: [0, 0, 0],
            toTangent: [0, 0, 0]
          }, 0 === OO.length) throw new Error("A camera path needs at least one keyframe");
        for (let eO = 1; eO < OO.length; eO++)
          if (!(OO[eO].timeMs > OO[eO - 1].timeMs)) throw new Error("Camera path keyframe times must strictly increase");
        this.nodes = OO.map((OO => {
          var KO;
          return {
            timeMs: OO.timeMs,
            position: [...OO.position],
            keyframe: OO,
            easing: (0, eO.r)(null !== (KO = OO.easing) && void 0 !== KO ? KO : "linear")
          }
        }));
        const XO = this.nodes[0],
          bK = this.nodes[this.nodes.length - 1],
          lO = pO && this.nodes.length > 1;
        lO && !jK(XO.keyframe, bK.keyframe) && this.nodes.push({
          ...XO,
          timeMs: bK.timeMs + (bK.timeMs - XO.timeMs) / (this.nodes.length - 1)
        }), this.loopMs = lO ? this.nodes[this.nodes.length - 1].timeMs - XO.timeMs : 0, this.prevNodes = this.nodes.map(((OO, KO) => this.neighbour(KO, -1))), this.nextNodes = this.nodes.map(((OO, KO) => this.neighbour(KO, 1))), this.prevGaps = this.prevNodes.map(((OO, KO) => OO >= 0 ? this.gapMs(KO, -1) : 0)), this.nextGaps = this.nextNodes.map(((OO, KO) => OO >= 0 ? this.gapMs(KO, 1) : 0)), this.velocities = this.nodes.map(((OO, KO) => {
          const pO = this.prevNodes[KO],
            XO = this.nextNodes[KO];
          return function(OO, KO, pO, XO, bK, eO) {
            if (eO[0] = 0, eO[1] = 0, eO[2] = 0, !OO && !pO) return eO;
            const lO = null !== OO && void 0 !== OO ? OO : IO(null !== pO && void 0 !== pO ? pO : KO, KO),
              vK = null !== pO && void 0 !== pO ? pO : IO(null !== OO && void 0 !== OO ? OO : KO, KO),
              CO = OO ? XO : bK,
              hO = pO ? bK : XO,
              DO = dO(lO, KO),
              MO = dO(KO, vK);
            if (DO < QO || MO < QO) return eO;
            const aK = Math.sqrt(DO),
              oO = Math.sqrt(MO),
              FO = (aK + oO) / (CO + hO);
            for (let VO = 0; VO < 3; VO++) {
              const OO = (KO[VO] - lO[VO]) / aK - (vK[VO] - lO[VO]) / (aK + oO) + (vK[VO] - KO[VO]) / oO;
              eO[VO] = OO * FO
            }
            return eO
          }(pO >= 0 ? this.nodes[pO].position : null, OO.position, XO >= 0 ? this.nodes[XO].position : null, this.prevGaps[KO], this.nextGaps[KO], [0, 0, 0])
        })), this.aim = new EO(this.nodes, this.velocities, this.prevNodes, this.nextNodes, KO)
      }
      sample(OO, KO, pO, XO) {
        const bK = this.findSegment(this.pathTime(OO));
        this.samplePosition(bK, XO.position), this.aim.sample(bK, KO, XO);
        const {
          beforeIndex: eO,
          afterIndex: lO
        } = bK;
        XO.fov = gK(bK, eO >= 0 ? this.fovAt(eO, pO) : 0, this.fovAt(bK.index, pO), this.fovAt(bK.toIndex, pO), lO >= 0 ? this.fovAt(lO, pO) : 0, eO >= 0, lO >= 0)
      }
      pathTime(OO) {
        const KO = this.nodes[0].timeMs;
        if (this.loopMs <= 0 || OO <= KO) return OO;
        const pO = OO - KO;
        return KO + pO - this.loopMs * Math.floor(pO / this.loopMs)
      }
      findSegment(OO) {
        const KO = this.nodes,
          pO = this.segment;
        let XO = pO.index;
        for (OO < KO[XO].timeMs && (XO = 0); XO < KO.length - 2 && KO[XO + 1].timeMs <= OO;) XO++;
        const bK = Math.min(XO + 1, KO.length - 1),
          lO = KO[bK].timeMs - KO[XO].timeMs;
        return pO.index = XO, pO.toIndex = bK, pO.segmentMs = lO, pO.u = lO > 0 ? (0, eO.o)((OO - KO[XO].timeMs) / lO, KO[XO].easing) : 1, pO.curved = this.smooth && lO > 0, pO.beforeIndex = this.prevNodes[XO], pO.afterIndex = this.nextNodes[bK], pO.beforeMs = this.prevGaps[XO], pO.afterMs = this.nextGaps[bK], pO
      }
      samplePosition(OO, KO) {
        const {
          fromTangent: pO,
          toTangent: XO,
          curved: bK
        } = OO, eO = this.nodes[OO.index].position, lO = this.nodes[OO.toIndex].position;
        TO(this.velocities[OO.index], eO, lO, OO.segmentMs, bK, pO), TO(this.velocities[OO.toIndex], eO, lO, OO.segmentMs, bK, XO);
        const vK = OO.u;
        for (let CO = 0; CO < 3; CO++) KO[CO] = bK ? AO(eO[CO], pO[CO], lO[CO], XO[CO], vK) : eO[CO] + (lO[CO] - eO[CO]) * vK
      }
      fovAt(OO, KO) {
        var pO;
        return null !== (pO = this.nodes[OO].keyframe.fov) && void 0 !== pO ? pO : KO
      }
      neighbour(OO, KO) {
        const pO = this.nodes.length - 1,
          XO = OO + KO;
        return XO >= 0 && XO <= pO ? XO : this.loopMs <= 0 || pO < 2 ? -1 : XO < 0 ? pO - 1 : 1
      }
      gapMs(OO, KO) {
        const pO = this.nodes.length - 1;
        if (1 === KO) {
          const KO = OO === pO ? 0 : OO;
          return this.nodes[KO + 1].timeMs - this.nodes[KO].timeMs
        }
        const XO = 0 === OO ? pO : OO;
        return this.nodes[XO].timeMs - this.nodes[XO - 1].timeMs
      }
    }
    class wO {
      constructor(OO) {
        this.lK = OO, this.lastFeet = new Map, this.lastAimPoints = new Map, this.lastHeadings = new Map, this.readFeet = void 0, this.readAimPoint = void 0, this.readFeet = KO => OO.getEntityPosition(KO), this.readAimPoint = KO => OO.getEntityAimPoint(KO)
      }
      aimPoint(OO) {
        return "string" !== typeof OO ? (0, CO.p)(OO, 3) ? OO : null : this.resolve(OO, this.readAimPoint, this.lastAimPoints)
      }
      currentAimPoint(OO) {
        const KO = "string" === typeof OO ? this.lK.getEntityAimPoint(OO) : OO;
        return KO && (0, CO.p)(KO, 3) ? KO : null
      }
      feetPosition(OO) {
        return this.resolve(OO, this.readFeet, this.lastFeet)
      }
      heading(OO) {
        const KO = this.lK.getEntityHeading(OO);
        if (null !== KO && Number.isFinite(KO)) return this.lastHeadings.set(OO, KO), KO;
        const pO = this.lastHeadings.get(OO);
        return void 0 !== pO ? pO : OO === this.lK.localPlayerId ? 0 : this.heading(this.lK.localPlayerId)
      }
      resolve(OO, KO, pO) {
        const XO = KO(OO);
        let bK = pO.get(OO);
        return XO && (0, CO.p)(XO, 3) ? (bK || (bK = [0, 0, 0], pO.set(OO, bK)), bK[0] = XO[0], bK[1] = XO[1], bK[2] = XO[2], bK) : bK || (OO === this.lK.localPlayerId ? null : this.resolve(this.lK.localPlayerId, KO, pO))
      }
    }

    function iK(OO) {
      return {
        heading: OO.heading,
        pitch: OO.pitch
      }
    }

    function rK(OO, KO) {
      Number.isFinite(OO.heading) && Number.isFinite(OO.pitch) || (0, bK.i)(KO, OO)
    }

    function PO(OO, KO, pO, XO, eO) {
      if (KO) return void(0, bK.j)(KO, eO);
      const lO = XO.aimPoint(pO);
      lO && (0, bK.q)(OO, lO, eO)
    }
    class mK {
      constructor(OO, KO, pO, XO) {
        this.settings = OO, this.lK = KO, this.targets = pO, this.base = void 0, this.base = iK(XO)
      }
      update(OO, KO, pO) {
        var XO;
        const bK = this.settings;
        (0, CO.i)(bK.position, pO.position), PO(bK.position, bK.lookDirection, null !== (XO = bK.lookAt) && void 0 !== XO ? XO : this.lK.localPlayerId, this.targets, this.base), KO.apply(this.base, pO), pO.fov = oO(bK, this.lK)
      }
      continueFrom(OO) {
        OO instanceof mK && (0, bK.i)(OO.base, this.base)
      }
      reset(OO) {
        rK(this.base, OO)
      }
    }
    class sO {
      constructor(OO, KO, pO, XO) {
        this.settings = OO, this.lK = KO, this.targets = pO, this.base = void 0, this.goal = void 0, this.lastFeet = [0, 0, 0], this.foundFeet = !1, this.smoothed = [0, 0, 0], this.ul = [0, 0, 0], this.started = !1, this.distance = -1, this.toCamera = [0, 0, 0], this.aimOrigin = [0, 0, 0], this.base = iK(XO), this.goal = [...XO.position]
      }
      update(OO, KO, pO) {
        var XO, bK, eO;
        const lO = this.settings,
          vK = null !== (XO = lO.target) && void 0 !== XO ? XO : this.lK.localPlayerId,
          hO = this.targets.feetPosition(vK);
        let DO = !1;
        hO && (DO = this.foundFeet && dO(this.lastFeet, hO) > 32 + .1 * OO, (0, CO.i)(hO, this.lastFeet), this.foundFeet = !0, this.placeGoal(hO, vK));
        const MO = null !== (bK = lO.smoothMs) && void 0 !== bK ? bK : 0;
        !this.started || MO < 1 || DO ? ((0, CO.i)(this.goal, this.smoothed), this.ul.fill(0), this.started = !0) : FO(this.smoothed, this.ul, this.goal, MO, OO), DO && (this.distance = -1), (0, CO.i)(this.smoothed, pO.position);
        const aK = !0 === lO.avoidTerrain ? this.pullIn(vK, OO, pO) : 1;
        let VO = this.goal;
        if ("target" === lO.offsetSpace) VO = pO.position;
        else if (aK < 1) {
          VO = this.aimOrigin;
          for (let OO = 0; OO < 3; OO++) VO[OO] = pO.position[OO] + (this.goal[OO] - this.smoothed[OO]) * aK
        }
        PO(VO, lO.lookDirection, null !== (eO = lO.lookAt) && void 0 !== eO ? eO : vK, this.targets, this.base), KO.apply(this.base, pO), pO.fov = oO(lO, this.lK)
      }
      continueFrom(OO) {
        OO instanceof sO && (0, XO.q)(OO.settings.target, this.settings.target) && ((0, bK.i)(OO.base, this.base), (0, CO.i)(OO.goal, this.goal), (0, CO.i)(OO.lastFeet, this.lastFeet), this.foundFeet = OO.foundFeet, (0, CO.i)(OO.smoothed, this.smoothed), (0, CO.i)(OO.ul, this.ul), this.started = OO.started, !0 === OO.settings.avoidTerrain && (this.distance = OO.distance))
      }
      reset(OO) {
        rK(this.base, OO), this.ul.fill(0), this.started = !1, this.distance = -1
      }
      pullIn(OO, KO, pO) {
        const XO = this.targets.aimPoint(OO);
        if (!XO) return 1;
        const bK = pO.position,
          eO = dO(XO, bK);
        if (!(eO > 0)) return 1;
        const lO = this.toCamera;
        for (let CO = 0; CO < 3; CO++) lO[CO] = (bK[CO] - XO[CO]) / eO;
        const vK = function(OO, KO, pO) {
          return OO < 0 || KO < OO ? KO : KO + (OO - KO) * Math.exp(-pO / 150)
        }(this.distance, function(OO, KO, pO, XO) {
          const bK = OO.raycastTerrain(KO, pO, XO);
          return null !== bK && Number.isFinite(bK) ? Math.min(XO, Math.max(0, bK - .2)) : XO
        }(this.lK, XO, lO, eO), KO);
        if (eO - vK < .001) return this.distance = -1, 1;
        this.distance = vK;
        for (let CO = 0; CO < 3; CO++) bK[CO] = XO[CO] + lO[CO] * vK;
        return vK / eO
      }
      placeGoal(OO, KO) {
        const pO = this.settings.offset;
        let XO = pO[0],
          bK = pO[2];
        if ("target" === this.settings.offsetSpace) {
          const OO = this.targets.heading(KO),
            eO = Math.cos(OO),
            lO = Math.sin(OO);
          XO = pO[0] * eO + pO[2] * lO, bK = -pO[0] * lO + pO[2] * eO
        }
        this.goal[0] = OO[0] + XO, this.goal[1] = OO[1] + pO[1], this.goal[2] = OO[2] + bK
      }
    }
    class HO {
      constructor(OO, KO, pO, XO) {
        var bK, eO;
        this.settings = OO, this.lK = KO, this.sampler = void 0, this.base = void 0, this.resolveTarget = void 0, this.elapsedMs = 0, this.sampler = OO.keyframes.length > 0 ? new YO(OO.keyframes, null === (bK = OO.smooth) || void 0 === bK || bK, null !== (eO = OO.loop) && void 0 !== eO && eO) : null, this.base = (0, CO.h)(XO, (0, CO.m)()), this.resolveTarget = OO => pO.aimPoint(OO)
      }
      update(OO, KO, pO) {
        this.elapsedMs += OO;
        const XO = oO(this.settings, this.lK);
        this.sampler ? this.sampler.sample(this.elapsedMs, this.resolveTarget, XO, this.base) : this.base.fov = XO, (0, CO.i)(this.base.position, pO.position), pO.fov = this.base.fov, KO.apply(this.base, pO)
      }
      continueFrom(OO) {
        OO instanceof HO && (0, XO.q)(OO.settings.keyframes, this.settings.keyframes) && (this.elapsedMs = OO.elapsedMs, (0, CO.h)(OO.base, this.base))
      }
      reset(OO) {
        rK(this.base, OO), Number.isFinite(this.elapsedMs) || (this.elapsedMs = 0)
      }
    }

    function RO(OO, KO) {
      return (0, XO.t)(OO, KO)
    }
    class SO {
      constructor(OO, KO, pO) {
        var XO;
        this.settings = OO, this.lK = KO, this.pose = void 0, this.lastGoodPose = void 0, this.look = void 0, this.targets = void 0, this.mode = void 0, this.warnedNonFinite = !1;
        const bK = null !== pO && pO.settings.mode === OO.mode,
          eO = bK ? pO.pose : KO.getDefaultPose();
        this.pose = (0, CO.h)(eO, (0, CO.m)()), this.lastGoodPose = (0, CO.h)(bK ? pO.lastGoodPose : eO, (0, CO.m)()), this.look = new LO(OO.playerLook), this.targets = null !== (XO = null === pO || void 0 === pO ? void 0 : pO.targets) && void 0 !== XO ? XO : new wO(KO);
        const lO = (0, CO.h)(eO, (0, CO.m)());
        bK && pO.look.unapply(lO, lO), this.mode = function(OO, KO, pO, XO) {
          switch (OO.mode) {
            case "fixed":
              return new mK(OO, KO, pO, XO);
            case "follow":
              return new sO(OO, KO, pO, XO);
            case "path":
              return new HO(OO, KO, pO, XO);
            case "frame":
              return new VO(OO, KO, pO, XO)
          }
        }(OO, KO, this.targets, lO), bK && (this.look.continueFrom(pO.look), this.mode.continueFrom(pO.mode))
      }
      update(OO, KO) {
        return this.look.update(OO, KO), this.mode.update(OO, this.look, this.pose), (0, CO.n)(this.pose) ? (0, CO.h)(this.pose, this.lastGoodPose) : (this.warnedNonFinite || (console.warn("Scripted camera produced a non-finite pose; holding the last good one"), this.warnedNonFinite = !0), (0, CO.h)(this.lastGoodPose, this.pose), this.mode.reset((0, CO.n)(this.lastGoodPose) ? this.lastGoodPose : this.lK.getDefaultPose())), this.pose
      }
    }

    function JO(OO) {
      return [0, 0, OO[2], OO[3]]
    }
    class cK {
      constructor(OO) {
        this.lK = OO, this.settings = {
          mode: "default"
        }, this.pending = null, this.fade = new vK, this.shot = null, this.blend = null, this.mixed = (0, CO.m)(), this.output = (0, CO.m)(), this.hasOutput = !1, this.loadingPositions = [], this.loadingSlots = Array.from({
          length: 3
        }, (() => [0, 0, 0]))
      }
      setSettings(OO) {
        const KO = (0, hO.e)(OO);
        if ((0, XO.q)(KO, this.pending ? this.pending.settings : this.settings)) return;
        const pO = RO(this.settings, KO);
        if (void 0 !== KO.transition && !pO) return this.pending = {
          settings: KO,
          shot: "default" === KO.mode ? null : new SO(KO, this.lK, null)
        }, void this.fade.fadeOut(KO.transition);
        const bK = null !== this.pending;
        this.pending = null, !bK && pO || this.fade.fadeIn(XO.i.minTransitionFadeMs), this.show(KO, !1)
      }
      show(OO, KO) {
        var pO, bK;
        if ((0, XO.q)(OO, this.settings)) return;
        const lO = !KO && RO(this.settings, OO);
        this.settings = OO;
        const vK = null !== this.blend && this.blend.elapsedMs > 0,
          hO = (0, CO.h)(this.hasOutput ? this.output : this.lK.getDefaultPose(), (0, CO.m)());
        if (this.shot = "default" === OO.mode ? null : new SO(OO, this.lK, KO ? null : this.shot), lO) return;
        const DO = KO || !this.shot && !this.hasOutput ? 0 : null !== (pO = OO.blendInMs) && void 0 !== pO ? pO : 0;
        if (DO <= 0) return void(this.blend = null);
        const MO = (0, eO.r)(null !== (bK = OO.blendEasing) && void 0 !== bK ? bK : "easeInOut");
        this.blend = {
          from: hO,
          fromScripted: this.hasOutput,
          headingDelta: NaN,
          elapsedMs: 0,
          durationMs: DO,
          easing: vK ? JO(MO) : MO
        }
      }
      getSettings() {
        return this.settings
      }
      getScreenFade() {
        return this.fade.getScreen()
      }
      getLoadingPositions() {
        return this.loadingPositions
      }
      isActive() {
        return null !== this.shot || null !== this.blend
      }
      update(OO, KO) {
        const pO = Number.isFinite(OO) && OO > 0 ? OO : 0;
        if (this.fade.advance(pO) && null !== this.pending) {
          const {
            settings: OO
          } = this.pending;
          this.pending = null, this.show(OO, !0)
        }
        this.loadingPositions.length = 0;
        const XO = this.pending;
        if (null !== XO && void 0 !== XO && XO.shot) {
          const OO = "path" === XO.settings.mode ? 0 : pO;
          this.noteLoadingPosition(XO.shot.update(OO, CO.e).position)
        }
        if (!this.isActive()) return this.hasOutput = !1, null;
        const lO = this.shot ? this.shot.update(pO, KO) : this.lK.getDefaultPose();
        this.shot && this.noteLoadingPosition(lO.position);
        const vK = this.blend;
        if (!vK) return this.writeOutput(lO);
        vK.elapsedMs += pO;
        const hO = Math.min(1, vK.elapsedMs / vK.durationMs);
        if (vK.headingDelta = Number.isFinite(vK.headingDelta) ? (0, bK.x)(vK.headingDelta, lO.heading - vK.from.heading) : (0, bK.w)(vK.from.heading, lO.heading), (0, CO.r)(vK.from, lO, vK.headingDelta, (0, eO.o)(hO, vK.easing), this.mixed), hO >= 1) {
          if (this.blend = null, !this.shot) return this.hasOutput = !1, null
        } else vK.fromScripted && this.noteLoadingPosition(vK.from.position);
        return this.writeOutput(this.mixed)
      }
      noteLoadingPosition(OO) {
        if (OO.every(Number.isFinite)) {
          const KO = this.loadingPositions;
          KO.push((0, CO.i)(OO, this.loadingSlots[KO.length]))
        }
      }
      writeOutput(OO) {
        const KO = this.output;
        (0, CO.n)(OO) ? (0, CO.h)(OO, KO) : this.hasOutput || (0, CO.h)(this.lK.getDefaultPose(), KO), KO.pitch = (0, bK.g)(KO.pitch);
        const pO = this.lK.getDefaultFov(),
          eO = Number.isFinite(pO) && pO > 0 && pO < 180,
          lO = eO ? Math.min(XO.i.minFov, pO) : XO.i.minFov,
          vK = eO ? Math.max(XO.i.maxFov, pO) : XO.i.maxFov;
        return KO.fov = Number.isFinite(KO.fov) ? Math.min(vK, Math.max(lO, KO.fov)) : vK, this.hasOutput = !0, KO
      }
    }
  },
  37522: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => vK,
      i: () => lO,
      m: () => eO,
      n: () => hO,
      p: () => CO,
      r: () => DO
    });
    var XO = pO(37531);
    const bK = {
      wKO: 0,
      ipO: 0
    };

    function eO() {
      return {
        position: [0, 0, 0],
        heading: 0,
        pitch: 0,
        fov: 0
      }
    }

    function lO(OO, KO) {
      return KO[0] = OO[0], KO[1] = OO[1], KO[2] = OO[2], KO
    }

    function vK(OO, KO) {
      return lO(OO.position, KO.position), KO.heading = OO.heading, KO.pitch = OO.pitch, KO.fov = OO.fov, KO
    }

    function CO(OO, KO) {
      return Array.isArray(OO) && OO.length === KO && OO.every(Number.isFinite)
    }

    function hO(OO) {
      return CO(OO.position, 3) && Number.isFinite(OO.heading) && Number.isFinite(OO.pitch) && Number.isFinite(OO.fov)
    }

    function DO(OO, KO, pO, bK, eO) {
      for (let XO = 0; XO < 3; XO++) eO.position[XO] = OO.position[XO] + (KO.position[XO] - OO.position[XO]) * bK;
      return eO.heading = (0, XO.t)(OO.heading + pO * bK), eO.pitch = OO.pitch + (KO.pitch - OO.pitch) * bK, eO.fov = OO.fov + (KO.fov - OO.fov) * bK, eO
    }
  },
  37556: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => NO,
      g: () => aK
    });
    var XO = pO(37553),
      bK = pO(37522);
    const eO = XO.g,
      lO = XO.k;

    function vK(OO, KO, pO, XO) {
      return Number.isFinite(OO) ? Math.min(pO, Math.max(KO, OO)) : XO
    }

    function CO(OO, KO, pO) {
      return void 0 !== OO && Number.isFinite(OO) ? Math.min(pO, Math.max(KO, OO)) : void 0
    }

    function hO(OO) {
      const KO = XO.i.maxCoordinate;
      return [Math.min(KO, Math.max(-KO, OO[0])), Math.min(KO, Math.max(-KO, OO[1])), Math.min(KO, Math.max(-KO, OO[2]))]
    }

    function DO(OO) {
      return "string" === typeof OO ? OO : (0, bK.p)(OO, 3) ? hO(OO) : void 0
    }
    const MO = new RegExp(XO.o);

    function aK(OO) {
      return "string" === typeof OO && MO.test(OO)
    }

    function oO(OO) {
      const KO = [];
      if (!Array.isArray(OO)) return KO;
      for (const pO of OO.slice(0, XO.i.maxFrameTargets)) {
        const OO = DO(pO);
        void 0 === OO || "string" === typeof OO && !aK(OO) || KO.push(OO)
      }
      return KO
    }

    function FO(OO) {
      if (!(0, bK.p)(OO, 3)) return;
      const KO = Math.max(Math.abs(OO[0]), Math.abs(OO[1]), Math.abs(OO[2])),
        pO = Math.hypot(OO[0] / KO, OO[1] / KO, OO[2] / KO);
      return 0 === KO || KO * pO < XO.i.minDirectionLength ? void 0 : [OO[0] / KO / pO, OO[1] / KO / pO, OO[2] / KO / pO]
    }

    function VO(OO) {
      if (void 0 !== OO) return "string" === typeof OO ? eO.includes(OO) ? OO : void 0 : (0, bK.p)(OO, 4) ? [vK(OO[0], 0, 1, 0), vK(OO[1], XO.i.minEasingY, XO.i.maxEasingY, 0), vK(OO[2], 0, 1, 1), vK(OO[3], XO.i.minEasingY, XO.i.maxEasingY, 1)] : "linear"
    }

    function LO(OO) {
      if (OO) return {
        maxYaw: vK(OO.maxYaw, 0, XO.i.maxPlayerLook, 0),
        maxPitch: vK(OO.maxPitch, 0, XO.i.maxPlayerLook, 0),
        returnMs: CO(OO.returnMs, 0, XO.i.maxReturnMs)
      }
    }
    const QO = new RegExp(XO.b);

    function zK(OO) {
      var KO;
      if ("object" !== typeof OO || null === OO) return;
      const pO = XO.i.maxTransitionMs,
        bK = XO.i.minTransitionFadeMs;
      return {
        colour: "string" === typeof OO.colour && QO.test(OO.colour) ? OO.colour : XO.d,
        outMs: vK(OO.outMs, bK, pO, bK),
        holdMs: vK(null !== (KO = OO.holdMs) && void 0 !== KO ? KO : 0, 0, pO, 0),
        inMs: vK(OO.inMs, bK, pO, bK)
      }
    }

    function AO(OO) {
      return !0 === OO || void 0
    }

    function fO(OO) {
      if ("object" !== typeof OO || null === OO) return !1;
      const KO = OO.lookAt;
      return Number.isFinite(OO.timeMs) && (0, bK.p)(OO.position, 3) && (void 0 === KO || "string" === typeof KO || (0, bK.p)(KO, 3))
    }

    function dO(OO) {
      return {
        ...OO,
        timeMs: vK(OO.timeMs, 0, XO.i.maxPathMs, 0),
        position: hO(OO.position),
        lookAt: DO(OO.lookAt),
        lookDirection: FO(OO.lookDirection),
        fov: CO(OO.fov, XO.i.minFov, XO.i.maxFov),
        easing: VO(OO.easing)
      }
    }

    function TO(OO) {
      const KO = [];
      if (!Array.isArray(OO)) return KO;
      for (const pO of OO.slice(0, XO.i.maxKeyframes)) {
        if (!fO(pO)) continue;
        const OO = dO(pO);
        (0 === KO.length || OO.timeMs > KO[KO.length - 1].timeMs) && KO.push(OO)
      }
      return KO
    }

    function NO(OO) {
      if ("object" !== typeof OO || null === OO) return {
        mode: "default"
      };
      const KO = {
          blendInMs: CO(OO.blendInMs, 0, XO.i.maxBlendInMs),
          blendEasing: VO(OO.blendEasing),
          transition: zK(OO.transition),
          letterbox: AO(OO.letterbox),
          hideHud: AO(OO.hideHud)
        },
        pO = {
          mode: "default",
          ...KO
        };
      if ("default" === OO.mode || "fixed" === OO.mode && !(0, bK.p)(OO.position, 3)) return pO;
      const eO = {
        ...KO,
        fov: CO(OO.fov, XO.i.minFov, XO.i.maxFov),
        playerFacing: (MO = OO.playerFacing, lO.includes(MO) ? MO : void 0),
        playerLook: LO(OO.playerLook)
      };
      var MO, aK;
      switch (OO.mode) {
        case "fixed":
          return {
            ...OO, ...eO, position: hO(OO.position), lookAt: DO(OO.lookAt), lookDirection: FO(OO.lookDirection)
          };
        case "follow":
          return {
            ...OO, ...eO, target: "string" === typeof OO.target ? OO.target : void 0, lookAt: DO(OO.lookAt), offset: (aK = OO.offset, Array.isArray(aK) ? [vK(aK[0], -XO.i.maxOffset, XO.i.maxOffset, 0), vK(aK[1], -XO.i.maxOffset, XO.i.maxOffset, 0), vK(aK[2], -XO.i.maxOffset, XO.i.maxOffset, 0)] : [0, 0, 0]), lookDirection: FO(OO.lookDirection), smoothMs: CO(OO.smoothMs, 0, XO.i.maxSmoothMs)
          };
        case "path":
          return {
            ...OO, ...eO, keyframes: TO(OO.keyframes)
          };
        case "frame":
          return {
            ...OO, ...eO, targets: oO(OO.targets), viewHeading: CO(OO.viewHeading, -XO.i.maxFrameHeading, XO.i.maxFrameHeading), viewElevation: CO(OO.viewElevation, 0, XO.i.maxFrameElevation), padding: CO(OO.padding, 0, XO.i.maxFrameDistance), closestDistance: CO(OO.closestDistance, 0, XO.i.maxFrameDistance), furthestDistance: CO(OO.furthestDistance, 0, XO.i.maxFrameDistance), smoothMs: CO(OO.smoothMs, 0, XO.i.maxSmoothMs)
          };
        default:
          return pO
      }
    }
  },
  37478: (OO, KO, pO) => {
    function XO(OO, KO) {
      return KO.set(OO), KO
    }
    pO.d(KO, {
      c: () => XO
    })
  },
  37476: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO
    });
    var XO = pO(35167),
      bK = pO.n(XO);
    const eO = [1, 1, 1];

    function lO(OO) {
      if (!OO) return [...eO];
      try {
        const [KO, pO, XO] = bK()(OO).rgb().array();
        return [KO / 255, pO / 255, XO / 255]
      } catch (KO) {
        return console.warn(`Invalid groundArrowPath colour "${OO}":`, KO), [...eO]
      }
    }
  },
  32993: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      d: () => vK,
      g: () => lO,
      j: () => bK,
      k: () => XO
    });
    const XO = {
        default: {
          type: "earth",
          vertexTint: [137, 207, 240]
        },
        gloomy: {
          type: "custom",
          nx: "/textures/skyBoxes/gloomy/_nx.jpg",
          ny: "/textures/skyBoxes/gloomy/_ny.jpg",
          nz: "/textures/skyBoxes/gloomy/_nz.jpg",
          px: "/textures/skyBoxes/gloomy/_px.jpg",
          py: "/textures/skyBoxes/gloomy/_py.jpg",
          pz: "/textures/skyBoxes/gloomy/_pz.jpg"
        },
        interstellar: {
          type: "custom",
          nx: "/textures/skyBoxes/interstellar/_nx.jpg",
          ny: "/textures/skyBoxes/interstellar/_ny.jpg",
          nz: "/textures/skyBoxes/interstellar/_nz.jpg",
          px: "/textures/skyBoxes/interstellar/_px.jpg",
          py: "/textures/skyBoxes/interstellar/_py.jpg",
          pz: "/textures/skyBoxes/interstellar/_pz.jpg"
        },
        space_blue: {
          type: "custom",
          nx: "/textures/skyBoxes/space_blue/_nx.jpg",
          ny: "/textures/skyBoxes/space_blue/_ny.jpg",
          nz: "/textures/skyBoxes/space_blue/_nz.jpg",
          px: "/textures/skyBoxes/space_blue/_px.jpg",
          py: "/textures/skyBoxes/space_blue/_py.jpg",
          pz: "/textures/skyBoxes/space_blue/_pz.jpg"
        },
        space_lightblue: {
          type: "custom",
          nx: "/textures/skyBoxes/space_lightblue/_nx.jpg",
          ny: "/textures/skyBoxes/space_lightblue/_ny.jpg",
          nz: "/textures/skyBoxes/space_lightblue/_nz.jpg",
          px: "/textures/skyBoxes/space_lightblue/_px.jpg",
          py: "/textures/skyBoxes/space_lightblue/_py.jpg",
          pz: "/textures/skyBoxes/space_lightblue/_pz.jpg"
        },
        space_red: {
          type: "custom",
          nx: "/textures/skyBoxes/space_red/_nx.jpg",
          ny: "/textures/skyBoxes/space_red/_ny.jpg",
          nz: "/textures/skyBoxes/space_red/_nz.jpg",
          px: "/textures/skyBoxes/space_red/_px.jpg",
          py: "/textures/skyBoxes/space_red/_py.jpg",
          pz: "/textures/skyBoxes/space_red/_pz.jpg"
        },
        underwater: {
          type: "custom",
          nx: "/textures/skyBoxes/underwater/water.jpg",
          ny: "/textures/skyBoxes/underwater/water.jpg",
          nz: "/textures/skyBoxes/underwater/water.jpg",
          px: "/textures/skyBoxes/underwater/water.jpg",
          py: "/textures/skyBoxes/underwater/water.jpg",
          pz: "/textures/skyBoxes/underwater/water.jpg"
        },
        starry: {
          type: "custom",
          nx: "/textures/skyBoxes/starry/_nx.jpg",
          ny: "/textures/skyBoxes/starry/_ny.jpg",
          nz: "/textures/skyBoxes/starry/_nz.jpg",
          px: "/textures/skyBoxes/starry/_px.jpg",
          py: "/textures/skyBoxes/starry/_py.jpg",
          pz: "/textures/skyBoxes/starry/_pz.jpg"
        },
        space_red_2: {
          type: "custom",
          nx: "/textures/skyBoxes/space_red_2/_nx.jpg",
          ny: "/textures/skyBoxes/space_red_2/_ny.jpg",
          nz: "/textures/skyBoxes/space_red_2/_nz.jpg",
          px: "/textures/skyBoxes/space_red_2/_px.jpg",
          py: "/textures/skyBoxes/space_red_2/_py.jpg",
          pz: "/textures/skyBoxes/space_red_2/_pz.jpg"
        },
        space_white: {
          type: "custom",
          nx: "/textures/skyBoxes/space_white/_nx.jpg",
          ny: "/textures/skyBoxes/space_white/_ny.jpg",
          nz: "/textures/skyBoxes/space_white/_nz.jpg",
          px: "/textures/skyBoxes/space_white/_px.jpg",
          py: "/textures/skyBoxes/space_white/_py.jpg",
          pz: "/textures/skyBoxes/space_white/_pz.jpg"
        }
      },
      bK = "/textures/dayNight/sun.png",
      eO = "/textures/dayNight/moon.png",
      lO = "/textures/dayNight/stars",
      vK = ["_px.png", "_py.png", "_pz.png", "_nx.png", "_ny.png", "_nz.png"]
  },
  37553: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => DO,
      d: () => MO,
      g: () => XO,
      i: () => CO,
      k: () => bK,
      o: () => hO,
      q: () => vK,
      t: () => lO
    });
    const XO = ["linear", "easeIn", "easeOut", "easeInOut"],
      bK = ["movement", "camera", "cursor"],
      eO = ["targets", "playerFacing", "blendInMs", "blendEasing", "transition", "letterbox", "hideHud"];

    function lO(OO, KO) {
      return vK(OO, KO, eO)
    }

    function vK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
      if (OO === KO || Number.isNaN(OO) && Number.isNaN(KO)) return !0;
      if ("object" !== typeof OO || "object" !== typeof KO || null === OO || null === KO || Array.isArray(OO) !== Array.isArray(KO)) return !1;
      const XO = OO,
        bK = KO;
      for (const eO of new Set([...Object.keys(XO), ...Object.keys(bK)]))
        if (!pO.includes(eO) && !vK(XO[eO], bK[eO])) return !1;
      return !0
    }
    const CO = {
        maxBlendInMs: 1e4,
        minFov: 10,
        maxFov: 120,
        maxOffset: 128,
        maxSmoothMs: 5e3,
        maxReturnMs: 1e4,
        maxTransitionMs: 5e3,
        minTransitionFadeMs: 200,
        minFadeTurnMs: 333,
        maxPlayerLook: 180,
        maxKeyframes: 64,
        maxPathMs: 6e5,
        maxFrameTargets: 64,
        maxFrameDistance: 128,
        maxFrameHeading: 360,
        maxFrameElevation: 90,
        maxCoordinate: 1e6,
        minDirectionLength: 1e-6,
        minEasingY: -1,
        maxEasingY: 2
      },
      hO = "^-[1-9][0-9]*$",
      DO = "^#[0-9a-fA-F]{6}$",
      MO = "#000000"
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);