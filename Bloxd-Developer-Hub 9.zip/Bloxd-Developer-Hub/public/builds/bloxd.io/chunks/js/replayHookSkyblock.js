export const id = 44;
export const ids = [44];
export const modules = {
  37022: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      SkyblockEntityFacing: () => vK,
      needsSkyblockEntityFacing: () => lO
    });
    var XO = pO(36928),
      bK = pO(3520),
      eO = pO(37025);

    function lO(OO, KO) {
      if (OO.metaInfo === XO.n || "Iron Guardian" === OO.type || "Gold Guardian" === OO.type) return !0;
      if ("Pig" === OO.type) return "sitting" === OO.pose;
      if ("Person" !== OO.meshKind || void 0 === OO.meshOpts) return !1;
      let pO = null === KO || void 0 === KO ? void 0 : KO.get(OO.meshOpts);
      if (void 0 === pO) {
        var eO, lO;
        const XO = (0, bK.f)(OO);
        pO = !1, "pig_napoleon" === (null === XO || void 0 === XO || null === (eO = XO.opts.textures) || void 0 === eO ? void 0 : eO.head) ? pO = !0 : "npc_pig_head" === (null === XO || void 0 === XO || null === (lO = XO.opts.textures) || void 0 === lO ? void 0 : lO.head) && (pO = "sitting" === XO.opts.pose || "sitting"), KO && (KO.size >= 256 && KO.clear(), KO.set(OO.meshOpts, pO))
      }
      return "sitting" === pO ? "sitting" === OO.pose : pO
    }(0, eO.h)("skyblock", ((OO, KO) => {
      KO.setFacingTolerance(lO(OO) ? 0 : null)
    }));
    class vK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        this.api = OO, this.alsoVisit = KO, this.facing = new Set, this.nextFacing = new Set, this.meshFacingCache = new Map, this.visit = OO => {
          var KO;
          const pO = this.api.getEntityInfo(OO);
          pO && (lO(pO, this.meshFacingCache) && (this.api.setFacingTolerance(OO, 0), this.nextFacing.add(OO)), null === (KO = this.alsoVisit) || void 0 === KO || KO.call(this, OO, pO))
        }
      }
      KK() {
        const {
          api: OO
        } = this, KO = this.nextFacing;
        OO.forEachEntity(this.visit);
        for (const pO of this.facing) KO.has(pO) || OO.setFacingTolerance(pO, null);
        this.facing.clear(), this.nextFacing = this.facing, this.facing = KO
      }
      dispose() {
        for (const OO of this.facing) this.api.setFacingTolerance(OO, null);
        this.facing.clear(), this.meshFacingCache.clear()
      }
    }
  },
  36928: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      g: () => vK,
      k: () => XO,
      l: () => eO,
      n: () => bK,
      o: () => CO
    });
    const XO = "skyblockDungeons",
      bK = "skyblockHeldBoss",
      eO = "dungeonEnter ",
      lO = Object.freeze({
        easy: "skyblockGame:difficultyEasy",
        medium: "skyblockGame:difficultyMedium",
        hard: "skyblockGame:difficultyHard",
        insane: "skyblockGame:difficultyInsane"
      }),
      vK = Object.freeze({
        easy: "#77b326",
        medium: "#eac03d",
        hard: "#df7622",
        insane: "#e74d4d"
      });

    function CO(OO) {
      let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      const pO = Math.max(0, Math.floor(OO)),
        XO = Math.floor(pO % 1e3 / 100),
        bK = Math.floor(pO / 1e3),
        eO = bK % 60,
        lO = Math.floor(bK / 60),
        vK = lO % 60,
        CO = Math.floor(lO / 60),
        hO = OO => OO < 10 ? `0${OO}` : String(OO),
        DO = KO ? `.${XO}` : "";
      return CO > 0 ? `${CO}:${hO(vK)}:${hO(eO)}${DO}` : `${vK}:${hO(eO)}${DO}`
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);