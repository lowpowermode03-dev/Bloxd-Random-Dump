/*! For license information please see vjxd5n.248.8fb02618.chunk.js.LICENSE.txt */
export const id = 248;
export const ids = [248];
export const modules = {
  38632: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      getAnalytics: () => qp,
      getGoogleAnalyticsClientId: () => tp,
      initializeAnalytics: () => xp,
      isSupported: () => nK,
      logEvent: () => pp,
      setAnalyticsCollectionEnabled: () => Op,
      setConsent: () => Xp,
      setCurrentScreen: () => WK,
      setDefaultEventParameters: () => Kp,
      setUserId: () => kp,
      setUserProperties: () => UK,
      settings: () => ZK
    });
    var XO = pO(38610),
      bK = pO(38624),
      eO = pO(38622),
      lO = pO(38613);
    let vK, CO;
    const hO = new WeakMap,
      DO = new WeakMap,
      MO = new WeakMap,
      aK = new WeakMap,
      oO = new WeakMap;
    let FO = {
      get(OO, KO, pO) {
        if (OO instanceof IDBTransaction) {
          if ("done" === KO) return DO.get(OO);
          if ("objectStoreNames" === KO) return OO.objectStoreNames || MO.get(OO);
          if ("store" === KO) return pO.objectStoreNames[1] ? void 0 : pO.objectStore(pO.objectStoreNames[0])
        }
        return QO(OO[KO])
      },
      set: (OO, KO, pO) => (OO[KO] = pO, !0),
      has: (OO, KO) => OO instanceof IDBTransaction && ("done" === KO || "store" === KO) || KO in OO
    };

    function VO(OO) {
      return OO !== IDBDatabase.prototype.transaction || "objectStoreNames" in IDBTransaction.prototype ? (CO || (CO = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])).includes(OO) ? function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        return OO.apply(zK(this), pO), QO(hO.get(this))
      } : function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        return QO(OO.apply(zK(this), pO))
      } : function(KO) {
        for (var pO = arguments.length, XO = new Array(pO > 1 ? pO - 1 : 0), bK = 1; bK < pO; bK++) XO[bK - 1] = arguments[bK];
        const eO = OO.call(zK(this), KO, ...XO);
        return MO.set(eO, KO.sort ? KO.sort() : [KO]), QO(eO)
      }
    }

    function LO(OO) {
      return "function" === typeof OO ? VO(OO) : (OO instanceof IDBTransaction && function(OO) {
        if (DO.has(OO)) return;
        const KO = new Promise(((KO, pO) => {
          const XO = () => {
              OO.removeEventListener("complete", bK), OO.removeEventListener("error", eO), OO.removeEventListener("abort", eO)
            },
            bK = () => {
              KO(), XO()
            },
            eO = () => {
              pO(OO.error || new DOMException("AbortError", "AbortError")), XO()
            };
          OO.addEventListener("complete", bK), OO.addEventListener("error", eO), OO.addEventListener("abort", eO)
        }));
        DO.set(OO, KO)
      }(OO), KO = OO, (vK || (vK = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])).some((OO => KO instanceof OO)) ? new Proxy(OO, FO) : OO);
      var KO
    }

    function QO(OO) {
      if (OO instanceof IDBRequest) return function(OO) {
        const KO = new Promise(((KO, pO) => {
          const XO = () => {
              OO.removeEventListener("success", bK), OO.removeEventListener("error", eO)
            },
            bK = () => {
              KO(QO(OO.result)), XO()
            },
            eO = () => {
              pO(OO.error), XO()
            };
          OO.addEventListener("success", bK), OO.addEventListener("error", eO)
        }));
        return KO.then((KO => {
          KO instanceof IDBCursor && hO.set(KO, OO)
        })).catch((() => {})), oO.set(KO, OO), KO
      }(OO);
      if (aK.has(OO)) return aK.get(OO);
      const KO = LO(OO);
      return KO !== OO && (aK.set(OO, KO), oO.set(KO, OO)), KO
    }
    const zK = OO => oO.get(OO);
    const AO = ["get", "getKey", "getAll", "getAllKeys", "count"],
      fO = ["put", "add", "delete", "clear"],
      dO = new Map;

    function TO(OO, KO) {
      if (!(OO instanceof IDBDatabase) || KO in OO || "string" !== typeof KO) return;
      if (dO.get(KO)) return dO.get(KO);
      const pO = KO.replace(/FromIndex$/, ""),
        XO = KO !== pO,
        bK = fO.includes(pO);
      if (!(pO in (XO ? IDBIndex : IDBObjectStore).prototype) || !bK && !AO.includes(pO)) return;
      const eO = async function(OO) {
        const KO = this.transaction(OO, bK ? "readwrite" : "readonly");
        let eO = KO.store;
        for (var lO = arguments.length, vK = new Array(lO > 1 ? lO - 1 : 0), CO = 1; CO < lO; CO++) vK[CO - 1] = arguments[CO];
        return XO && (eO = eO.index(vK.shift())), (await Promise.all([eO[pO](...vK), bK && KO.done]))[0]
      };
      return dO.set(KO, eO), eO
    }
    FO = (OO => ({
      ...OO,
      get: (KO, pO, XO) => TO(KO, pO) || OO.get(KO, pO, XO),
      has: (KO, pO) => !!TO(KO, pO) || OO.has(KO, pO)
    }))(FO);
    const NO = "@firebase/installations",
      IO = "0.6.4",
      yK = 1e4,
      gK = `w:${IO}`,
      uO = "FIS_v2",
      EO = 36e5,
      jK = {
        "missing-app-config-values": 'Missing App configuration value: "{$valueName}"',
        "not-registered": "Firebase Installation is not registered.",
        "installation-not-found": "Firebase Installation not found.",
        "request-failed": '{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',
        "app-offline": "Could not process request. Application offline.",
        "delete-pending-registration": "Can't delete installation while there is a pending registration request."
      },
      YO = new eO.h("installations", "Installations", jK);

    function wO(OO) {
      return OO instanceof eO.k && OO.code.includes("request-failed")
    }

    function iK(OO) {
      let {
        projectId: KO
      } = OO;
      return `https://firebaseinstallations.googleapis.com/v1/projects/${KO}/installations`
    }

    function rK(OO) {
      return {
        token: OO.token,
        requestStatus: 2,
        expiresIn: (KO = OO.expiresIn, Number(KO.replace("s", "000"))),
        creationTime: Date.now()
      };
      var KO
    }
    async function PO(OO, KO) {
      const pO = (await KO.json()).error;
      return YO.create("request-failed", {
        requestName: OO,
        serverCode: pO.code,
        serverMessage: pO.message,
        serverStatus: pO.status
      })
    }

    function mK(OO) {
      let {
        apiKey: KO
      } = OO;
      return new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        "x-goog-api-key": KO
      })
    }

    function sO(OO, KO) {
      let {
        refreshToken: pO
      } = KO;
      const XO = mK(OO);
      return XO.append("Authorization", function(OO) {
        return `${uO} ${OO}`
      }(pO)), XO
    }
    async function HO(OO) {
      const KO = await OO();
      return KO.status >= 500 && KO.status < 600 ? OO() : KO
    }

    function RO(OO) {
      return new Promise((KO => {
        setTimeout(KO, OO)
      }))
    }
    const SO = /^[cdef][\w-]{21}$/;

    function JO() {
      try {
        const OO = new Uint8Array(17);
        (self.crypto || self.msCrypto).getRandomValues(OO), OO[0] = 112 + OO[0] % 16;
        const KO = function(OO) {
          const KO = (pO = OO, btoa(String.fromCharCode(...pO)).replace(/\+/g, "-").replace(/\//g, "_"));
          var pO;
          return KO.substr(0, 22)
        }(OO);
        return SO.test(KO) ? KO : ""
      } catch (OO) {
        return ""
      }
    }

    function cK(OO) {
      return `${OO.appName}!${OO.appId}`
    }
    const BO = new Map;

    function ZO(OO, KO) {
      const pO = cK(OO);
      GO(pO, KO),
        function(OO, KO) {
          const pO = xK();
          pO && pO.postMessage({
            key: OO,
            fid: KO
          });
          nO()
        }(pO, KO)
    }

    function GO(OO, KO) {
      const pO = BO.get(OO);
      if (pO)
        for (const XO of pO) XO(KO)
    }
    let qK = null;

    function xK() {
      return !qK && "BroadcastChannel" in self && (qK = new BroadcastChannel("[Firebase] FID Change"), qK.onmessage = OO => {
        GO(OO.data.key, OO.data.fid)
      }), qK
    }

    function nO() {
      0 === BO.size && qK && (qK.close(), qK = null)
    }
    const WO = "firebase-installations-store";
    let tK = null;

    function kK() {
      return tK || (tK = function(OO, KO) {
        let {
          blocked: pO,
          upgrade: XO,
          blocking: bK,
          terminated: eO
        } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        const lO = indexedDB.open(OO, KO),
          vK = QO(lO);
        return XO && lO.addEventListener("upgradeneeded", (OO => {
          XO(QO(lO.result), OO.oldVersion, OO.newVersion, QO(lO.transaction))
        })), pO && lO.addEventListener("blocked", (() => pO())), vK.then((OO => {
          eO && OO.addEventListener("close", (() => eO())), bK && OO.addEventListener("versionchange", (() => bK()))
        })).catch((() => {})), vK
      }("firebase-installations-database", 1, {
        upgrade: (OO, KO) => {
          if (0 === KO) OO.createObjectStore(WO)
        }
      })), tK
    }
    async function UO(OO, KO) {
      const pO = cK(OO),
        XO = (await kK()).transaction(WO, "readwrite"),
        bK = XO.objectStore(WO),
        eO = await bK.get(pO);
      return await bK.put(KO, pO), await XO.done, eO && eO.fid === KO.fid || ZO(OO, KO.fid), KO
    }
    async function OK(OO) {
      const KO = cK(OO),
        pO = (await kK()).transaction(WO, "readwrite");
      await pO.objectStore(WO).delete(KO), await pO.done
    }
    async function KK(OO, KO) {
      const pO = cK(OO),
        XO = (await kK()).transaction(WO, "readwrite"),
        bK = XO.objectStore(WO),
        eO = await bK.get(pO),
        lO = KO(eO);
      return void 0 === lO ? await bK.delete(pO) : await bK.put(lO, pO), await XO.done, !lO || eO && eO.fid === lO.fid || ZO(OO, lO.fid), lO
    }
    async function pK(OO) {
      let KO;
      const pO = await KK(OO.appConfig, (pO => {
        const XO = function(OO) {
            const KO = OO || {
              fid: JO(),
              registrationStatus: 0
            };
            return eK(KO)
          }(pO),
          bK = function(OO, KO) {
            if (0 === KO.registrationStatus) {
              if (!navigator.onLine) {
                return {
                  installationEntry: KO,
                  registrationPromise: Promise.reject(YO.create("app-offline"))
                }
              }
              const pO = {
                  fid: KO.fid,
                  registrationStatus: 1,
                  registrationTime: Date.now()
                },
                XO = async function(OO, KO) {
                  try {
                    const pO = await async function(OO, KO) {
                      let {
                        appConfig: pO,
                        heartbeatServiceProvider: XO
                      } = OO, {
                        fid: bK
                      } = KO;
                      const eO = iK(pO),
                        lO = mK(pO),
                        vK = XO.getImmediate({
                          optional: !0
                        });
                      if (vK) {
                        const OO = await vK.getHeartbeatsHeader();
                        OO && lO.append("x-firebase-client", OO)
                      }
                      const CO = {
                          fid: bK,
                          authVersion: uO,
                          appId: pO.appId,
                          sdkVersion: gK
                        },
                        hO = {
                          method: "POST",
                          headers: lO,
                          body: JSON.stringify(CO)
                        },
                        DO = await HO((() => fetch(eO, hO)));
                      if (DO.ok) {
                        const OO = await DO.json();
                        return {
                          fid: OO.fid || bK,
                          registrationStatus: 2,
                          refreshToken: OO.refreshToken,
                          authToken: rK(OO.authToken)
                        }
                      }
                      throw await PO("Create Installation", DO)
                    }(OO, KO);
                    return UO(OO.appConfig, pO)
                  } catch (pO) {
                    throw wO(pO) && 409 === pO.customData.serverCode ? await OK(OO.appConfig) : await UO(OO.appConfig, {
                      fid: KO.fid,
                      registrationStatus: 0
                    }), pO
                  }
                }(OO, pO);
              return {
                installationEntry: pO,
                registrationPromise: XO
              }
            }
            return 1 === KO.registrationStatus ? {
              installationEntry: KO,
              registrationPromise: XK(OO)
            } : {
              installationEntry: KO
            }
          }(OO, XO);
        return KO = bK.registrationPromise, bK.installationEntry
      }));
      return "" === pO.fid ? {
        installationEntry: await KO
      } : {
        installationEntry: pO,
        registrationPromise: KO
      }
    }
    async function XK(OO) {
      let KO = await bp(OO.appConfig);
      for (; 1 === KO.registrationStatus;) await RO(100), KO = await bp(OO.appConfig);
      if (0 === KO.registrationStatus) {
        const {
          installationEntry: KO,
          registrationPromise: pO
        } = await pK(OO);
        return pO || KO
      }
      return KO
    }

    function bp(OO) {
      return KK(OO, (OO => {
        if (!OO) throw YO.create("installation-not-found");
        return eK(OO)
      }))
    }

    function eK(OO) {
      return 1 === (KO = OO).registrationStatus && KO.registrationTime + yK < Date.now() ? {
        fid: OO.fid,
        registrationStatus: 0
      } : OO;
      var KO
    }
    async function lK(OO, KO) {
      let {
        appConfig: pO,
        heartbeatServiceProvider: XO
      } = OO;
      const bK = function(OO, KO) {
          let {
            fid: pO
          } = KO;
          return `${iK(OO)}/${pO}/authTokens:generate`
        }(pO, KO),
        eO = sO(pO, KO),
        lO = XO.getImmediate({
          optional: !0
        });
      if (lO) {
        const OO = await lO.getHeartbeatsHeader();
        OO && eO.append("x-firebase-client", OO)
      }
      const vK = {
          installation: {
            sdkVersion: gK,
            appId: pO.appId
          }
        },
        CO = {
          method: "POST",
          headers: eO,
          body: JSON.stringify(vK)
        },
        hO = await HO((() => fetch(bK, CO)));
      if (hO.ok) {
        return rK(await hO.json())
      }
      throw await PO("Generate Auth Token", hO)
    }
    async function vp(OO) {
      let KO, pO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      const XO = await KK(OO.appConfig, (XO => {
        if (!hK(XO)) throw YO.create("not-registered");
        const bK = XO.authToken;
        if (!pO && function(OO) {
            return 2 === OO.requestStatus && ! function(OO) {
              const KO = Date.now();
              return KO < OO.creationTime || OO.creationTime + OO.expiresIn < KO + EO
            }(OO)
          }(bK)) return XO;
        if (1 === bK.requestStatus) return KO = async function(OO, KO) {
          let pO = await CK(OO.appConfig);
          for (; 1 === pO.authToken.requestStatus;) await RO(100), pO = await CK(OO.appConfig);
          const XO = pO.authToken;
          return 0 === XO.requestStatus ? vp(OO, KO) : XO
        }(OO, pO), XO;
        {
          if (!navigator.onLine) throw YO.create("app-offline");
          const pO = function(OO) {
            const KO = {
              requestStatus: 1,
              requestTime: Date.now()
            };
            return Object.assign(Object.assign({}, OO), {
              authToken: KO
            })
          }(XO);
          return KO = async function(OO, KO) {
            try {
              const pO = await lK(OO, KO),
                XO = Object.assign(Object.assign({}, KO), {
                  authToken: pO
                });
              return await UO(OO.appConfig, XO), pO
            } catch (pO) {
              if (!wO(pO) || 401 !== pO.customData.serverCode && 404 !== pO.customData.serverCode) {
                const pO = Object.assign(Object.assign({}, KO), {
                  authToken: {
                    requestStatus: 0
                  }
                });
                await UO(OO.appConfig, pO)
              } else await OK(OO.appConfig);
              throw pO
            }
          }(OO, pO), pO
        }
      }));
      return KO ? await KO : XO.authToken
    }

    function CK(OO) {
      return KK(OO, (OO => {
        if (!hK(OO)) throw YO.create("not-registered");
        const KO = OO.authToken;
        return 1 === (pO = KO).requestStatus && pO.requestTime + yK < Date.now() ? Object.assign(Object.assign({}, OO), {
          authToken: {
            requestStatus: 0
          }
        }) : OO;
        var pO
      }))
    }

    function hK(OO) {
      return void 0 !== OO && 2 === OO.registrationStatus
    }
    async function DK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      const pO = OO;
      await async function(OO) {
        const {
          registrationPromise: KO
        } = await pK(OO);
        KO && await KO
      }(pO);
      return (await vp(pO, KO)).token
    }

    function MK(OO) {
      return YO.create("missing-app-config-values", {
        valueName: OO
      })
    }
    const ap = "installations",
      oK = OO => {
        const KO = OO.getProvider("app").getImmediate(),
          pO = function(OO) {
            if (!OO || !OO.options) throw MK("App Configuration");
            if (!OO.name) throw MK("App Name");
            const KO = ["projectId", "apiKey", "appId"];
            for (const pO of KO)
              if (!OO.options[pO]) throw MK(pO);
            return {
              appName: OO.name,
              projectId: OO.options.projectId,
              apiKey: OO.options.apiKey,
              appId: OO.options.appId
            }
          }(KO);
        return {
          app: KO,
          appConfig: pO,
          heartbeatServiceProvider: (0, XO.w)(KO, "heartbeat"),
          _delete: () => Promise.resolve()
        }
      },
      FK = OO => {
        const KO = OO.getProvider("app").getImmediate(),
          pO = (0, XO.w)(KO, ap).getImmediate();
        return {
          getId: () => async function(OO) {
            const KO = OO,
              {
                installationEntry: pO,
                registrationPromise: XO
              } = await pK(KO);
            return XO ? XO.catch(console.error) : vp(KO).catch(console.error), pO.fid
          }(pO),
          getToken: OO => DK(pO, OO)
        }
      };
    (0, XO.y)(new lO.d(ap, oK, "PUBLIC")), (0, XO.y)(new lO.d("installations-internal", FK, "PRIVATE")), (0, XO.P)(NO, IO), (0, XO.P)(NO, IO, "esm2017");
    const VK = "analytics",
      LK = "https://www.googletagmanager.com/gtag/js",
      QK = new bK.e("@firebase/analytics"),
      zp = {
        "already-exists": "A Firebase Analytics instance with the appId {$id}  already exists. Only one Firebase Analytics instance can be created for each appId.",
        "already-initialized": "initializeAnalytics() cannot be called again with different options than those it was initially called with. It can be called again with the same options to return the existing instance, or getAnalytics() can be used to get a reference to the already-intialized instance.",
        "already-initialized-settings": "Firebase Analytics has already been initialized.settings() must be called before initializing any Analytics instanceor it will have no effect.",
        "interop-component-reg-failed": "Firebase Analytics Interop Component failed to instantiate: {$reason}",
        "invalid-analytics-context": "Firebase Analytics is not supported in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}",
        "indexeddb-unavailable": "IndexedDB unavailable or restricted in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}",
        "fetch-throttle": "The config fetch request timed out while in an exponential backoff state. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.",
        "config-fetch-failed": "Dynamic config fetch failed: [{$httpStatus}] {$responseMessage}",
        "no-api-key": 'The "apiKey" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid API key.',
        "no-app-id": 'The "appId" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid app ID.',
        "no-client-id": 'The "client_id" field is empty.',
        "invalid-gtag-resource": "Trusted Types detected an invalid gtag resource: {$gtagURL}."
      },
      AK = new eO.h("analytics", "Analytics", zp);

    function fK(OO) {
      if (!OO.startsWith(LK)) {
        const KO = AK.create("invalid-gtag-resource", {
          gtagURL: OO
        });
        return QK.warn(KO.message), ""
      }
      return OO
    }

    function dK(OO) {
      return Promise.all(OO.map((OO => OO.catch((OO => OO)))))
    }

    function TK(OO, KO) {
      const pO = function(OO, KO) {
          let pO;
          return window.trustedTypes && (pO = window.trustedTypes.createPolicy(OO, KO)), pO
        }("firebase-js-sdk-policy", {
          createScriptURL: fK
        }),
        XO = document.createElement("script"),
        bK = `${LK}?l=${OO}&id=${KO}`;
      XO.src = pO ? null === pO || void 0 === pO ? void 0 : pO.createScriptURL(bK) : bK, XO.async = !0, document.head.appendChild(XO)
    }

    function NK(OO, KO, pO, XO) {
      return async function(bK) {
        try {
          for (var eO = arguments.length, lO = new Array(eO > 1 ? eO - 1 : 0), vK = 1; vK < eO; vK++) lO[vK - 1] = arguments[vK];
          if ("event" === bK) {
            const [XO, bK] = lO;
            await async function(OO, KO, pO, XO, bK) {
              try {
                let eO = [];
                if (bK && bK.send_to) {
                  let OO = bK.send_to;
                  Array.isArray(OO) || (OO = [OO]);
                  const XO = await dK(pO);
                  for (const pO of OO) {
                    const OO = XO.find((OO => OO.measurementId === pO)),
                      bK = OO && KO[OO.appId];
                    if (!bK) {
                      eO = [];
                      break
                    }
                    eO.push(bK)
                  }
                }
                0 === eO.length && (eO = Object.values(KO)), await Promise.all(eO), OO("event", XO, bK || {})
              } catch (eO) {
                QK.error(eO)
              }
            }(OO, KO, pO, XO, bK)
          } else if ("config" === bK) {
            const [bK, eO] = lO;
            await async function(OO, KO, pO, XO, bK, eO) {
              const lO = XO[bK];
              try {
                if (lO) await KO[lO];
                else {
                  const OO = (await dK(pO)).find((OO => OO.measurementId === bK));
                  OO && await KO[OO.appId]
                }
              } catch (vK) {
                QK.error(vK)
              }
              OO("config", bK, eO)
            }(OO, KO, pO, XO, bK, eO)
          } else if ("consent" === bK) {
            const [KO] = lO;
            OO("consent", "update", KO)
          } else if ("get" === bK) {
            const [KO, pO, XO] = lO;
            OO("get", KO, pO, XO)
          } else if ("set" === bK) {
            const [KO] = lO;
            OO("set", KO)
          } else OO(bK, ...lO)
        } catch (CO) {
          QK.error(CO)
        }
      }
    }
    const IK = new class {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e3;
        this.throttleMetadata = OO, this.intervalMillis = KO
      }
      getThrottleMetadata(OO) {
        return this.throttleMetadata[OO]
      }
      setThrottleMetadata(OO, KO) {
        this.throttleMetadata[OO] = KO
      }
      deleteThrottleMetadata(OO) {
        delete this.throttleMetadata[OO]
      }
    };

    function yp(OO) {
      return new Headers({
        Accept: "application/json",
        "x-goog-api-key": OO
      })
    }
    async function gp(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : IK,
        pO = arguments.length > 2 ? arguments[2] : void 0;
      const {
        appId: XO,
        apiKey: bK,
        measurementId: eO
      } = OO.options;
      if (!XO) throw AK.create("no-app-id");
      if (!bK) {
        if (eO) return {
          measurementId: eO,
          appId: XO
        };
        throw AK.create("no-api-key")
      }
      const lO = KO.getThrottleMetadata(XO) || {
          backoffCount: 0,
          throttleEndTimeMillis: Date.now()
        },
        vK = new EK;
      return setTimeout((async () => {
        vK.abort()
      }), void 0 !== pO ? pO : 6e4), uK({
        appId: XO,
        apiKey: bK,
        measurementId: eO
      }, lO, vK, KO)
    }
    async function uK(OO, KO, pO) {
      let {
        throttleEndTimeMillis: XO,
        backoffCount: bK
      } = KO, lO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : IK;
      var vK;
      const {
        appId: CO,
        measurementId: hO
      } = OO;
      try {
        await
        function(OO, KO) {
          return new Promise(((pO, XO) => {
            const bK = Math.max(KO - Date.now(), 0),
              eO = setTimeout(pO, bK);
            OO.addEventListener((() => {
              clearTimeout(eO), XO(AK.create("fetch-throttle", {
                throttleEndTimeMillis: KO
              }))
            }))
          }))
        }(pO, XO)
      } catch (DO) {
        if (hO) return QK.warn(`Timed out fetching this Firebase app's measurement ID from the server. Falling back to the measurement ID ${hO} provided in the "measurementId" field in the local Firebase config. [${null===DO||void 0===DO?void 0:DO.message}]`), {
          appId: CO,
          measurementId: hO
        };
        throw DO
      }
      try {
        const KO = await async function(OO) {
          var KO;
          const {
            appId: pO,
            apiKey: XO
          } = OO, bK = {
            method: "GET",
            headers: yp(XO)
          }, eO = "https://firebase.googleapis.com/v1alpha/projects/-/apps/{app-id}/webConfig".replace("{app-id}", pO), lO = await fetch(eO, bK);
          if (200 !== lO.status && 304 !== lO.status) {
            let OO = "";
            try {
              const pO = await lO.json();
              (null === (KO = pO.error) || void 0 === KO ? void 0 : KO.message) && (OO = pO.error.message)
            } catch (vK) {}
            throw AK.create("config-fetch-failed", {
              httpStatus: lO.status,
              responseMessage: OO
            })
          }
          return lO.json()
        }(OO);
        return lO.deleteThrottleMetadata(CO), KO
      } catch (DO) {
        const KO = DO;
        if (! function(OO) {
            if (!(OO instanceof eO.k) || !OO.customData) return !1;
            const KO = Number(OO.customData.httpStatus);
            return 429 === KO || 500 === KO || 503 === KO || 504 === KO
          }(KO)) {
          if (lO.deleteThrottleMetadata(CO), hO) return QK.warn(`Failed to fetch this Firebase app's measurement ID from the server. Falling back to the measurement ID ${hO} provided in the "measurementId" field in the local Firebase config. [${null===KO||void 0===KO?void 0:KO.message}]`), {
            appId: CO,
            measurementId: hO
          };
          throw DO
        }
        const XO = 503 === Number(null === (vK = null === KO || void 0 === KO ? void 0 : KO.customData) || void 0 === vK ? void 0 : vK.httpStatus) ? (0, eO.w)(bK, lO.intervalMillis, 30) : (0, eO.w)(bK, lO.intervalMillis),
          MO = {
            throttleEndTimeMillis: Date.now() + XO,
            backoffCount: bK + 1
          };
        return lO.setThrottleMetadata(CO, MO), QK.debug(`Calling attemptFetch again in ${XO} millis`), uK(OO, MO, pO, lO)
      }
    }
    class EK {
      constructor() {
        this.listeners = []
      }
      addEventListener(OO) {
        this.listeners.push(OO)
      }
      abort() {
        this.listeners.forEach((OO => OO()))
      }
    }
    let jp, YK;

    function wK(OO) {
      YK = OO
    }

    function ip(OO) {
      jp = OO
    }
    async function rp(OO, KO, pO, XO, bK, lO, vK) {
      var CO;
      const hO = gp(OO);
      hO.then((KO => {
        pO[KO.measurementId] = KO.appId, OO.options.measurementId && KO.measurementId !== OO.options.measurementId && QK.warn(`The measurement ID in the local Firebase config (${OO.options.measurementId}) does not match the measurement ID fetched from the server (${KO.measurementId}). To ensure analytics events are always sent to the correct Analytics property, update the measurement ID field in the local config or remove it from the local config.`)
      })).catch((OO => QK.error(OO))), KO.push(hO);
      const DO = async function() {
        if (!(0, eO.X)()) return QK.warn(AK.create("indexeddb-unavailable", {
          errorInfo: "IndexedDB is not available in this environment."
        }).message), !1;
        try {
          await (0, eO.hb)()
        } catch (OO) {
          return QK.warn(AK.create("indexeddb-unavailable", {
            errorInfo: null === OO || void 0 === OO ? void 0 : OO.toString()
          }).message), !1
        }
        return !0
      }().then((OO => OO ? XO.getId() : void 0)), [MO, aK] = await Promise.all([hO, DO]);
      (function(OO) {
        const KO = window.document.getElementsByTagName("script");
        for (const pO of Object.values(KO))
          if (pO.src && pO.src.includes(LK) && pO.src.includes(OO)) return pO;
        return null
      })(lO) || TK(lO, MO.measurementId), YK && (bK("consent", "default", YK), wK(void 0)), bK("js", new Date);
      const oO = null !== (CO = null === vK || void 0 === vK ? void 0 : vK.config) && void 0 !== CO ? CO : {};
      return oO.origin = "firebase", oO.update = !0, null != aK && (oO.firebase_id = aK), bK("config", MO.measurementId, oO), jp && (bK("set", jp), ip(void 0)), MO.measurementId
    }
    class PK {
      constructor(OO) {
        this.app = OO
      }
      _delete() {
        return delete mp[this.app.options.appId], Promise.resolve()
      }
    }
    let mp = {},
      sK = [];
    const HK = {};
    let RK, SK, JK = "dataLayer",
      cp = "gtag",
      BK = !1;

    function ZK(OO) {
      if (BK) throw AK.create("already-initialized");
      OO.dataLayerName && (JK = OO.dataLayerName), OO.gtagName && (cp = OO.gtagName)
    }

    function GK(OO, KO, pO) {
      ! function() {
        const OO = [];
        if ((0, eO.Q)() && OO.push("This is a browser extension environment."), (0, eO.m)() || OO.push("Cookies are not available."), OO.length > 0) {
          const KO = OO.map(((OO, KO) => `(${KO+1}) ${OO}`)).join(" "),
            pO = AK.create("invalid-analytics-context", {
              errorInfo: KO
            });
          QK.warn(pO.message)
        }
      }();
      const XO = OO.options.appId;
      if (!XO) throw AK.create("no-app-id");
      if (!OO.options.apiKey) {
        if (!OO.options.measurementId) throw AK.create("no-api-key");
        QK.warn(`The "apiKey" field is empty in the local Firebase config. This is needed to fetch the latest measurement ID for this Firebase app. Falling back to the measurement ID ${OO.options.measurementId} provided in the "measurementId" field in the local Firebase config.`)
      }
      if (null != mp[XO]) throw AK.create("already-exists", {
        id: XO
      });
      if (!BK) {
        ! function(OO) {
          let KO = [];
          Array.isArray(window[OO]) ? KO = window[OO] : window[OO] = KO
        }(JK);
        const {
          wrappedGtag: OO,
          gtagCore: KO
        } = function(OO, KO, pO, XO, bK) {
          let eO = function() {
            for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
            window[XO].push(arguments)
          };
          return window[bK] && "function" === typeof window[bK] && (eO = window[bK]), window[bK] = NK(eO, OO, KO, pO), {
            gtagCore: eO,
            wrappedGtag: window[bK]
          }
        }(mp, sK, HK, JK, cp);
        SK = OO, RK = KO, BK = !0
      }
      mp[XO] = rp(OO, sK, HK, KO, RK, JK, pO);
      return new PK(OO)
    }

    function qp() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : (0, XO.J)();
      OO = (0, eO.N)(OO);
      const KO = (0, XO.w)(OO, VK);
      return KO.isInitialized() ? KO.getImmediate() : xp(OO)
    }

    function xp(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      const pO = (0, XO.w)(OO, VK);
      if (pO.isInitialized()) {
        const OO = pO.getImmediate();
        if ((0, eO.B)(KO, pO.getOptions())) return OO;
        throw AK.create("already-initialized")
      }
      return pO.initialize({
        options: KO
      })
    }
    async function nK() {
      if ((0, eO.Q)()) return !1;
      if (!(0, eO.m)()) return !1;
      if (!(0, eO.X)()) return !1;
      try {
        return await (0, eO.hb)()
      } catch (OO) {
        return !1
      }
    }

    function WK(OO, KO, pO) {
      OO = (0, eO.N)(OO), async function(OO, KO, pO, XO) {
        if (XO && XO.global) return OO("set", {
          screen_name: pO
        }), Promise.resolve();
        OO("config", await KO, {
          update: !0,
          screen_name: pO
        })
      }(SK, mp[OO.app.options.appId], KO, pO).catch((OO => QK.error(OO)))
    }
    async function tp(OO) {
      return OO = (0, eO.N)(OO), async function(OO, KO) {
        const pO = await KO;
        return new Promise(((KO, XO) => {
          OO("get", pO, "client_id", (OO => {
            OO || XO(AK.create("no-client-id")), KO(OO)
          }))
        }))
      }(SK, mp[OO.app.options.appId])
    }

    function kp(OO, KO, pO) {
      OO = (0, eO.N)(OO), async function(OO, KO, pO, XO) {
        if (XO && XO.global) return OO("set", {
          user_id: pO
        }), Promise.resolve();
        OO("config", await KO, {
          update: !0,
          user_id: pO
        })
      }(SK, mp[OO.app.options.appId], KO, pO).catch((OO => QK.error(OO)))
    }

    function UK(OO, KO, pO) {
      OO = (0, eO.N)(OO), async function(OO, KO, pO, XO) {
        if (XO && XO.global) {
          const KO = {};
          for (const OO of Object.keys(pO)) KO[`user_properties.${OO}`] = pO[OO];
          return OO("set", KO), Promise.resolve()
        }
        OO("config", await KO, {
          update: !0,
          user_properties: pO
        })
      }(SK, mp[OO.app.options.appId], KO, pO).catch((OO => QK.error(OO)))
    }

    function Op(OO, KO) {
      OO = (0, eO.N)(OO), async function(OO, KO) {
        const pO = await OO;
        window[`ga-disable-${pO}`] = !KO
      }(mp[OO.app.options.appId], KO).catch((OO => QK.error(OO)))
    }

    function Kp(OO) {
      SK ? SK("set", OO) : ip(OO)
    }

    function pp(OO, KO, pO, XO) {
      OO = (0, eO.N)(OO), async function(OO, KO, pO, XO, bK) {
        if (bK && bK.global) OO("event", pO, XO);
        else {
          const bK = await KO;
          OO("event", pO, Object.assign(Object.assign({}, XO), {
            send_to: bK
          }))
        }
      }(SK, mp[OO.app.options.appId], KO, pO, XO).catch((OO => QK.error(OO)))
    }

    function Xp(OO) {
      SK ? SK("consent", "update", OO) : wK(OO)
    }
    const bX = "@firebase/analytics",
      ep = "0.10.0";
    (0, XO.y)(new lO.d(VK, ((OO, KO) => {
      let {
        options: pO
      } = KO;
      return GK(OO.getProvider("app").getImmediate(), OO.getProvider("installations-internal").getImmediate(), pO)
    }), "PUBLIC")), (0, XO.y)(new lO.d("analytics-internal", (function(OO) {
      try {
        const KO = OO.getProvider(VK).getImmediate();
        return {
          logEvent: (OO, pO, XO) => pp(KO, OO, pO, XO)
        }
      } catch (KO) {
        throw AK.create("interop-component-reg-failed", {
          reason: KO
        })
      }
    }), "PRIVATE")), (0, XO.P)(bX, ep), (0, XO.P)(bX, ep, "esm2017")
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);