export const id = 237;
export const ids = [237];
export const modules = {
  38530: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    let XO = !1
  },
  38056: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => FO
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35660),
      lO = pO(35632),
      vK = pO(35653),
      CO = pO(36274),
      hO = pO(38073);
    class DO {
      get wrapU() {
        return this._wrapU
      }
      set wrapU(OO) {
        this._wrapU = OO
      }
      get wrapV() {
        return this._wrapV
      }
      set wrapV(OO) {
        this._wrapV = OO
      }
      get coordinatesMode() {
        return 0
      }
      get isCube() {
        return !!this._texture && this._texture.isCube
      }
      set isCube(OO) {
        this._texture && (this._texture.isCube = OO)
      }
      get is3D() {
        return !!this._texture && this._texture.is3D
      }
      set is3D(OO) {
        this._texture && (this._texture.is3D = OO)
      }
      get is2DArray() {
        return !!this._texture && this._texture.is2DArray
      }
      set is2DArray(OO) {
        this._texture && (this._texture.is2DArray = OO)
      }
      getClassName() {
        return "ThinTexture"
      }
      static _IsRenderTargetWrapper(OO) {
        return void 0 !== OO?.shareDepth
      }
      constructor(OO) {
        this._wrapU = 1, this._wrapV = 1, this.wrapR = 1, this.anisotropicFilteringLevel = 4, this.delayLoadState = 0, this._texture = null, this._engine = null, this._cachedSize = hO.c.Zero(), this._cachedBaseSize = hO.c.Zero(), this._initialSamplingMode = 2, this._texture = DO._IsRenderTargetWrapper(OO) ? OO.texture : OO, this._texture && (this._engine = this._texture.qb(), this.wrapU = this._texture._cachedWrapU ?? this.wrapU, this.wrapV = this._texture._cachedWrapV ?? this.wrapV, this.wrapR = this._texture._cachedWrapR ?? this.wrapR)
      }
      isReady() {
        return 4 === this.delayLoadState ? (this.delayLoad(), !1) : !!this._texture && this._texture.isReady
      }
      delayLoad() {}
      getInternalTexture() {
        return this._texture
      }
      getSize() {
        if (this._texture) {
          if (this._texture.width) return this._cachedSize.width = this._texture.width, this._cachedSize.height = this._texture.height, this._cachedSize;
          if (this._texture._size) return this._cachedSize.width = this._texture._size, this._cachedSize.height = this._texture._size, this._cachedSize
        }
        return this._cachedSize
      }
      getBaseSize() {
        return this.isReady() && this._texture ? this._texture._size ? (this._cachedBaseSize.width = this._texture._size, this._cachedBaseSize.height = this._texture._size, this._cachedBaseSize) : (this._cachedBaseSize.width = this._texture.baseWidth, this._cachedBaseSize.height = this._texture.baseHeight, this._cachedBaseSize) : (this._cachedBaseSize.width = 0, this._cachedBaseSize.height = 0, this._cachedBaseSize)
      }
      get samplingMode() {
        return this._texture ? this._texture.samplingMode : this._initialSamplingMode
      }
      updateSamplingMode(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        this._texture && this._engine && this._engine.updateTextureSamplingMode(OO, this._texture, this._texture.generateMipMaps && KO)
      }
      releaseInternalTexture() {
        this._texture && (this._texture.dispose(), this._texture = null)
      }
      dispose() {
        this._texture && (this.releaseInternalTexture(), this._engine = null)
      }
    }
    var MO, aK = pO(38077),
      oO = pO(37938);
    let FO = (() => {
      var OO;
      let KO, pO, hO, MO, oO, FO, VO, LO, QO, zK, AO, fO, dO, TO, NO, IO, yK, gK, uO, EO, jK, YO, wO, iK, rK, PO = DO,
        mK = [],
        sO = [],
        HO = [],
        RO = [],
        SO = [],
        JO = [],
        cK = [],
        BO = [],
        ZO = [],
        GO = [],
        qK = [],
        xK = [],
        nO = [],
        WO = [],
        tK = [],
        kK = [],
        UO = [],
        OK = [],
        KK = [],
        pK = [],
        XK = [],
        bp = [],
        eK = [],
        lK = [],
        vp = [],
        CK = [],
        hK = [],
        DK = [],
        MK = [],
        ap = [],
        oK = [];
      return OO = class extends PO {
        set hasAlpha(OO) {
          this._hasAlpha = OO
        }
        get hasAlpha() {
          return this._hasAlpha
        }
        set getAlphaFromRGB(OO) {
          this._getAlphaFromRGB !== OO && (this._getAlphaFromRGB = OO, this._scene && this._scene.markAllMaterialsAsDirty(1, (OO => OO.hasTexture(this))))
        }
        get getAlphaFromRGB() {
          return this._getAlphaFromRGB
        }
        set coordinatesIndex(OO) {
          this._coordinatesIndex !== OO && (this._coordinatesIndex = OO, this._scene && this._scene.markAllMaterialsAsDirty(1, (OO => OO.hasTexture(this))))
        }
        get coordinatesIndex() {
          return this._coordinatesIndex
        }
        set coordinatesMode(OO) {
          this._coordinatesMode !== OO && (this._coordinatesMode = OO, this._scene && this._scene.markAllMaterialsAsDirty(1, (OO => OO.hasTexture(this))))
        }
        get coordinatesMode() {
          return this._coordinatesMode
        }
        get wrapU() {
          return this._wrapU
        }
        set wrapU(OO) {
          this._wrapU = OO
        }
        get wrapV() {
          return this._wrapV
        }
        set wrapV(OO) {
          this._wrapV = OO
        }
        get isCube() {
          return this._texture ? this._texture.isCube : this._isCube
        }
        set isCube(OO) {
          this._texture ? this._texture.isCube = OO : this._isCube = OO
        }
        get is3D() {
          return !!this._texture && this._texture.is3D
        }
        set is3D(OO) {
          this._texture && (this._texture.is3D = OO)
        }
        get is2DArray() {
          return !!this._texture && this._texture.is2DArray
        }
        set is2DArray(OO) {
          this._texture && (this._texture.is2DArray = OO)
        }
        get gammaSpace() {
          return this._texture ? (null === this._texture._gammaSpace && (this._texture._gammaSpace = this._gammaSpace), this._texture._gammaSpace && !this._texture._useSRGBBuffer) : this._gammaSpace
        }
        set gammaSpace(OO) {
          if (this._texture) {
            if (this._texture._gammaSpace === OO) return;
            this._texture._gammaSpace = OO
          } else {
            if (this._gammaSpace === OO) return;
            this._gammaSpace = OO
          }
          this.JKO()?.markAllMaterialsAsDirty(1, (OO => OO.hasTexture(this)))
        }
        get isRGBD() {
          return null != this._texture && this._texture._isRGBD
        }
        set isRGBD(OO) {
          OO !== this.isRGBD && (this._texture && (this._texture._isRGBD = OO), this.JKO()?.markAllMaterialsAsDirty(1, (OO => OO.hasTexture(this))))
        }
        get noMipmap() {
          return !1
        }
        get lodGenerationOffset() {
          return this._texture ? this._texture._lodGenerationOffset : 0
        }
        set lodGenerationOffset(OO) {
          this._texture && (this._texture._lodGenerationOffset = OO)
        }
        get lodGenerationScale() {
          return this._texture ? this._texture._lodGenerationScale : 0
        }
        set lodGenerationScale(OO) {
          this._texture && (this._texture._lodGenerationScale = OO)
        }
        get linearSpecularLOD() {
          return !!this._texture && this._texture._linearSpecularLOD
        }
        set linearSpecularLOD(OO) {
          this._texture && (this._texture._linearSpecularLOD = OO)
        }
        get irradianceTexture() {
          return this._texture ? this._texture._irradianceTexture : null
        }
        set irradianceTexture(OO) {
          this._texture && (this._texture._irradianceTexture = OO)
        }
        get uid() {
          return this._uid || (this._uid = (0, CO.b)()), this._uid
        }
        toString() {
          return this.name
        }
        getClassName() {
          return "BaseTexture"
        }
        set onDispose(OO) {
          this._onDisposeObserver && this.cpO.remove(this._onDisposeObserver), this._onDisposeObserver = this.cpO.add(OO)
        }
        get isBlocking() {
          return !0
        }
        get loadingError() {
          return this._loadingError
        }
        get errorObject() {
          return this._errorObject
        }
        constructor(KO) {
          let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          super(null), this.uniqueId = ((0, XO.i)(this, mK), (0, XO.i)(this, sO, void 0)), this.name = ((0, XO.i)(this, HO), (0, XO.i)(this, RO, void 0)), this.displayName = ((0, XO.i)(this, SO), (0, XO.i)(this, JO, void 0)), this.metadata = ((0, XO.i)(this, cK), (0, XO.i)(this, BO, null)), this._internalMetadata = (0, XO.i)(this, ZO), this.reservedDataStore = null, this._hasAlpha = (0, XO.i)(this, GO, !1), this._getAlphaFromRGB = ((0, XO.i)(this, qK), (0, XO.i)(this, xK, !1)), this.level = ((0, XO.i)(this, nO), (0, XO.i)(this, WO, 1)), this._coordinatesIndex = ((0, XO.i)(this, tK), (0, XO.i)(this, kK, 0)), this.optimizeUVAllocation = ((0, XO.i)(this, UO), (0, XO.i)(this, OK, !0)), this._coordinatesMode = ((0, XO.i)(this, KK), (0, XO.i)(this, pK, 0)), this.wrapR = ((0, XO.i)(this, XK), (0, XO.i)(this, bp, 1)), this.anisotropicFilteringLevel = ((0, XO.i)(this, eK), (0, XO.i)(this, lK, OO.DEFAULT_ANISOTROPIC_FILTERING_LEVEL)), this._isCube = ((0, XO.i)(this, vp), !1), this._gammaSpace = !0, this.invertZ = (0, XO.i)(this, CK, !1), this.lodLevelInAlpha = ((0, XO.i)(this, hK), (0, XO.i)(this, DK, !1)), this._dominantDirection = ((0, XO.i)(this, MK), null), this.isRenderTarget = (0, XO.i)(this, ap, !1), this._prefiltered = ((0, XO.i)(this, oK), !1), this._forceSerialize = !1, this.animations = [], this.cpO = new eO.e, this._onDisposeObserver = null, this._scene = null, this._uid = null, this._parentContainer = null, this._loadingError = !1, KO ? OO._IsScene(KO) ? this._scene = KO : this._engine = KO : this._scene = vK.c.LastCreatedScene, this._scene && (this.uniqueId = this._scene.getUniqueId(), this._scene.addTexture(this), this._engine = this._scene.qb()), this._texture = pO, this._uid = null
        }
        JKO() {
          return this._scene
        }
        _getEngine() {
          return this._engine
        }
        getTextureMatrix() {
          return lO.c.IdentityReadOnly
        }
        getReflectionTextureMatrix() {
          return lO.c.IdentityReadOnly
        }
        getRefractionTextureMatrix() {
          return this.getReflectionTextureMatrix()
        }
        isReadyOrNotBlocking() {
          return !this.isBlocking || this.isReady() || this.loadingError
        }
        scale(OO) {}
        get canRescale() {
          return !1
        }
        _getFromCache(OO, KO, pO, XO, bK, eO) {
          const lO = this._getEngine();
          if (!lO) return null;
          const vK = lO._getUseSRGBBuffer(!!bK, KO),
            CO = lO.getLoadedTexturesCache();
          for (let hO = 0; hO < CO.length; hO++) {
            const lO = CO[hO];
            if ((void 0 === bK || vK === lO._useSRGBBuffer) && (void 0 === XO || XO === lO.invertY) && lO.url === OO && lO.generateMipMaps === !KO && (!pO || pO === lO.samplingMode) && (void 0 === eO || eO === lO.isCube)) return lO.incrementReferences(), lO
          }
          return null
        }
        _rebuild() {}
        clone() {
          return null
        }
        get textureType() {
          return this._texture && void 0 !== this._texture.type ? this._texture.type : 0
        }
        get textureFormat() {
          return this._texture && void 0 !== this._texture.format ? this._texture.format : 5
        }
        _markAllSubMeshesAsTexturesDirty() {
          const OO = this.JKO();
          OO && OO.markAllMaterialsAsDirty(1)
        }
        readPixels() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
            KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
            XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
            bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
            eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
            lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0,
            vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : Number.MAX_VALUE,
            CO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : Number.MAX_VALUE;
          if (!this._texture) return null;
          const hO = this._getEngine();
          if (!hO) return null;
          const DO = this.getSize();
          let MO = DO.width,
            aK = DO.height;
          0 !== KO && (MO /= Math.pow(2, KO), aK /= Math.pow(2, KO), MO = Math.round(MO), aK = Math.round(aK)), vK = Math.min(MO, vK), CO = Math.min(aK, CO);
          try {
            return this._texture.isCube || this._texture.is2DArray ? hO._readTexturePixels(this._texture, vK, CO, OO, KO, pO, XO, bK, eO, lO) : hO._readTexturePixels(this._texture, vK, CO, -1, KO, pO, XO, bK, eO, lO)
          } catch (oO) {
            return null
          }
        }
        _readPixelsSync() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
            KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
            pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
            XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
            bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
          if (!this._texture) return null;
          const eO = this.getSize();
          let lO = eO.width,
            vK = eO.height;
          const CO = this._getEngine();
          if (!CO) return null;
          0 != KO && (lO /= Math.pow(2, KO), vK /= Math.pow(2, KO), lO = Math.round(lO), vK = Math.round(vK));
          try {
            return this._texture.isCube ? CO._readTexturePixelsSync(this._texture, lO, vK, OO, KO, pO, XO, bK) : CO._readTexturePixelsSync(this._texture, lO, vK, -1, KO, pO, XO, bK)
          } catch (hO) {
            return null
          }
        }
        get _lodTextureHigh() {
          return this._texture ? this._texture._lodTextureHigh : null
        }
        get _lodTextureMid() {
          return this._texture ? this._texture._lodTextureMid : null
        }
        get _lodTextureLow() {
          return this._texture ? this._texture._lodTextureLow : null
        }
        dispose() {
          if (this._scene) {
            this._scene.stopAnimation && this._scene.stopAnimation(this), this._scene.removePendingData(this);
            const OO = this._scene.textures.indexOf(this);
            if (OO >= 0 && this._scene.textures.splice(OO, 1), this._scene.onTextureRemovedObservable.notifyObservers(this), this._scene = null, this._parentContainer) {
              const OO = this._parentContainer.textures.indexOf(this);
              OO > -1 && this._parentContainer.textures.splice(OO, 1), this._parentContainer = null
            }
          }
          this.cpO.notifyObservers(this), this.cpO.clear(), this.metadata = null, super.dispose()
        }
        serialize() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          if (!this.name && !OO) return null;
          const KO = aK.c.Serialize(this);
          return aK.c.AppendSerializedAnimations(this, KO), KO
        }
        static WhenAllReady(OO, KO) {
          let pO = OO.length;
          if (0 !== pO)
            for (let XO = 0; XO < OO.length; XO++) {
              const bK = OO[XO];
              if (bK.isReady()) 0 === --pO && KO();
              else {
                const OO = bK.onLoadObservable;
                OO ? OO.addOnce((() => {
                  0 === --pO && KO()
                })) : 0 === --pO && KO()
              }
            } else KO()
        }
        static _IsScene(OO) {
          return "Scene" === OO.getClassName()
        }
      }, (() => {
        const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(PO[Symbol.metadata] ?? null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], hO = [(0, bK.M)()], MO = [(0, bK.M)()], oO = [(0, bK.M)("hasAlpha")], FO = [(0, bK.M)("getAlphaFromRGB")], VO = [(0, bK.M)()], LO = [(0, bK.M)("coordinatesIndex")], QO = [(0, bK.M)()], zK = [(0, bK.M)("coordinatesMode")], AO = [(0, bK.M)()], fO = [(0, bK.M)()], dO = [(0, bK.M)()], TO = [(0, bK.M)()], NO = [(0, bK.M)()], IO = [(0, bK.M)()], yK = [(0, bK.M)()], gK = [(0, bK.M)()], uO = [(0, bK.M)()], EO = [(0, bK.M)()], jK = [(0, bK.M)()], YO = [(0, bK.M)()], wO = [(0, bK.M)()], iK = [(0, bK.I)()], rK = [(0, bK.M)()], (0, XO.f)(OO, null, AO, {
          kind: "getter",
          name: "wrapU",
          static: !1,
          private: !1,
          access: {
            has: OO => "wrapU" in OO,
            get: OO => OO.wrapU
          },
          metadata: eO
        }, null, mK), (0, XO.f)(OO, null, fO, {
          kind: "getter",
          name: "wrapV",
          static: !1,
          private: !1,
          access: {
            has: OO => "wrapV" in OO,
            get: OO => OO.wrapV
          },
          metadata: eO
        }, null, mK), (0, XO.f)(OO, null, NO, {
          kind: "getter",
          name: "isCube",
          static: !1,
          private: !1,
          access: {
            has: OO => "isCube" in OO,
            get: OO => OO.isCube
          },
          metadata: eO
        }, null, mK), (0, XO.f)(OO, null, IO, {
          kind: "getter",
          name: "is3D",
          static: !1,
          private: !1,
          access: {
            has: OO => "is3D" in OO,
            get: OO => OO.is3D
          },
          metadata: eO
        }, null, mK), (0, XO.f)(OO, null, yK, {
          kind: "getter",
          name: "is2DArray",
          static: !1,
          private: !1,
          access: {
            has: OO => "is2DArray" in OO,
            get: OO => OO.is2DArray
          },
          metadata: eO
        }, null, mK), (0, XO.f)(OO, null, gK, {
          kind: "getter",
          name: "gammaSpace",
          static: !1,
          private: !1,
          access: {
            has: OO => "gammaSpace" in OO,
            get: OO => OO.gammaSpace
          },
          metadata: eO
        }, null, mK), (0, XO.f)(OO, null, jK, {
          kind: "getter",
          name: "lodGenerationOffset",
          static: !1,
          private: !1,
          access: {
            has: OO => "lodGenerationOffset" in OO,
            get: OO => OO.lodGenerationOffset
          },
          metadata: eO
        }, null, mK), (0, XO.f)(OO, null, YO, {
          kind: "getter",
          name: "lodGenerationScale",
          static: !1,
          private: !1,
          access: {
            has: OO => "lodGenerationScale" in OO,
            get: OO => OO.lodGenerationScale
          },
          metadata: eO
        }, null, mK), (0, XO.f)(OO, null, wO, {
          kind: "getter",
          name: "linearSpecularLOD",
          static: !1,
          private: !1,
          access: {
            has: OO => "linearSpecularLOD" in OO,
            get: OO => OO.linearSpecularLOD
          },
          metadata: eO
        }, null, mK), (0, XO.f)(OO, null, iK, {
          kind: "getter",
          name: "irradianceTexture",
          static: !1,
          private: !1,
          access: {
            has: OO => "irradianceTexture" in OO,
            get: OO => OO.irradianceTexture
          },
          metadata: eO
        }, null, mK), (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "uniqueId",
          static: !1,
          private: !1,
          access: {
            has: OO => "uniqueId" in OO,
            get: OO => OO.uniqueId,
            set: (OO, KO) => {
              OO.uniqueId = KO
            }
          },
          metadata: eO
        }, sO, HO), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "name",
          static: !1,
          private: !1,
          access: {
            has: OO => "name" in OO,
            get: OO => OO.name,
            set: (OO, KO) => {
              OO.name = KO
            }
          },
          metadata: eO
        }, RO, SO), (0, XO.f)(null, null, hO, {
          kind: "field",
          name: "displayName",
          static: !1,
          private: !1,
          access: {
            has: OO => "displayName" in OO,
            get: OO => OO.displayName,
            set: (OO, KO) => {
              OO.displayName = KO
            }
          },
          metadata: eO
        }, JO, cK), (0, XO.f)(null, null, MO, {
          kind: "field",
          name: "metadata",
          static: !1,
          private: !1,
          access: {
            has: OO => "metadata" in OO,
            get: OO => OO.metadata,
            set: (OO, KO) => {
              OO.metadata = KO
            }
          },
          metadata: eO
        }, BO, ZO), (0, XO.f)(null, null, oO, {
          kind: "field",
          name: "_hasAlpha",
          static: !1,
          private: !1,
          access: {
            has: OO => "_hasAlpha" in OO,
            get: OO => OO._hasAlpha,
            set: (OO, KO) => {
              OO._hasAlpha = KO
            }
          },
          metadata: eO
        }, GO, qK), (0, XO.f)(null, null, FO, {
          kind: "field",
          name: "_getAlphaFromRGB",
          static: !1,
          private: !1,
          access: {
            has: OO => "_getAlphaFromRGB" in OO,
            get: OO => OO._getAlphaFromRGB,
            set: (OO, KO) => {
              OO._getAlphaFromRGB = KO
            }
          },
          metadata: eO
        }, xK, nO), (0, XO.f)(null, null, VO, {
          kind: "field",
          name: "level",
          static: !1,
          private: !1,
          access: {
            has: OO => "level" in OO,
            get: OO => OO.level,
            set: (OO, KO) => {
              OO.level = KO
            }
          },
          metadata: eO
        }, WO, tK), (0, XO.f)(null, null, LO, {
          kind: "field",
          name: "_coordinatesIndex",
          static: !1,
          private: !1,
          access: {
            has: OO => "_coordinatesIndex" in OO,
            get: OO => OO._coordinatesIndex,
            set: (OO, KO) => {
              OO._coordinatesIndex = KO
            }
          },
          metadata: eO
        }, kK, UO), (0, XO.f)(null, null, QO, {
          kind: "field",
          name: "optimizeUVAllocation",
          static: !1,
          private: !1,
          access: {
            has: OO => "optimizeUVAllocation" in OO,
            get: OO => OO.optimizeUVAllocation,
            set: (OO, KO) => {
              OO.optimizeUVAllocation = KO
            }
          },
          metadata: eO
        }, OK, KK), (0, XO.f)(null, null, zK, {
          kind: "field",
          name: "_coordinatesMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "_coordinatesMode" in OO,
            get: OO => OO._coordinatesMode,
            set: (OO, KO) => {
              OO._coordinatesMode = KO
            }
          },
          metadata: eO
        }, pK, XK), (0, XO.f)(null, null, dO, {
          kind: "field",
          name: "wrapR",
          static: !1,
          private: !1,
          access: {
            has: OO => "wrapR" in OO,
            get: OO => OO.wrapR,
            set: (OO, KO) => {
              OO.wrapR = KO
            }
          },
          metadata: eO
        }, bp, eK), (0, XO.f)(null, null, TO, {
          kind: "field",
          name: "anisotropicFilteringLevel",
          static: !1,
          private: !1,
          access: {
            has: OO => "anisotropicFilteringLevel" in OO,
            get: OO => OO.anisotropicFilteringLevel,
            set: (OO, KO) => {
              OO.anisotropicFilteringLevel = KO
            }
          },
          metadata: eO
        }, lK, vp), (0, XO.f)(null, null, uO, {
          kind: "field",
          name: "invertZ",
          static: !1,
          private: !1,
          access: {
            has: OO => "invertZ" in OO,
            get: OO => OO.invertZ,
            set: (OO, KO) => {
              OO.invertZ = KO
            }
          },
          metadata: eO
        }, CK, hK), (0, XO.f)(null, null, EO, {
          kind: "field",
          name: "lodLevelInAlpha",
          static: !1,
          private: !1,
          access: {
            has: OO => "lodLevelInAlpha" in OO,
            get: OO => OO.lodLevelInAlpha,
            set: (OO, KO) => {
              OO.lodLevelInAlpha = KO
            }
          },
          metadata: eO
        }, DK, MK), (0, XO.f)(null, null, rK, {
          kind: "field",
          name: "isRenderTarget",
          static: !1,
          private: !1,
          access: {
            has: OO => "isRenderTarget" in OO,
            get: OO => OO.isRenderTarget,
            set: (OO, KO) => {
              OO.isRenderTarget = KO
            }
          },
          metadata: eO
        }, ap, oK), eO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: eO
        })
      })(), OO.DEFAULT_ANISOTROPIC_FILTERING_LEVEL = 4, OO
    })();
    (MO = FO.prototype).forceSphericalPolynomialsRecompute ?? (MO.forceSphericalPolynomialsRecompute = (0, oO.h)("BaseTexture", "forceSphericalPolynomialsRecompute")), Object.getOwnPropertyDescriptor(FO.prototype, "sphericalPolynomial") || Object.defineProperty(FO.prototype, "sphericalPolynomial", (0, oO.e)("BaseTexture", "sphericalPolynomial"))
  },
  38580: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => dO,
      e: () => AO
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35660),
      lO = pO(35632),
      vK = pO(38056),
      CO = pO(35676),
      hO = pO(37938),
      DO = pO(37955),
      MO = pO(38180),
      aK = pO(36146),
      oO = pO(38129);

    function FO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      const XO = KO.width,
        bK = KO.height;
      if (OO instanceof Float32Array) {
        let KO = OO.byteLength / OO.BYTES_PER_ELEMENT;
        const pO = new Uint8Array(KO);
        for (; --KO >= 0;) {
          let XO = OO[KO];
          XO < 0 ? XO = 0 : XO > 1 && (XO = 1), pO[KO] = 255 * XO
        }
        OO = pO
      }
      const eO = document.createElement("canvas");
      eO.width = XO, eO.height = bK;
      const lO = eO.getContext("2d");
      if (!lO) return null;
      const vK = lO.createImageData(XO, bK);
      if (vK.data.set(OO), lO.putImageData(vK, 0, 0), pO) {
        const OO = document.createElement("canvas");
        OO.width = XO, OO.height = bK;
        const KO = OO.getContext("2d");
        return KO ? (KO.translate(0, bK), KO.scale(1, -1), KO.drawImage(eO, 0, 0), OO.toDataURL("image/png")) : null
      }
      return eO.toDataURL("image/png")
    }

    function VO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
      const XO = OO.getInternalTexture();
      if (!XO) return null;
      const bK = OO._readPixelsSync(KO, pO);
      return bK ? FO(bK, OO.getSize(), XO.invertY) : null
    }
    async function LO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
      const XO = OO.getInternalTexture();
      if (!XO) return null;
      const bK = await OO.readPixels(KO, pO);
      return bK ? FO(bK, OO.getSize(), XO.invertY) : null
    }
    var QO = pO(38530),
      zK = pO(38077);
    let AO = (() => {
        var OO;
        let KO, pO, FO, AO, fO, dO, TO, NO, IO, yK, gK, uO, EO, jK = vK.d,
          YO = [],
          wO = [],
          iK = [],
          rK = [],
          PO = [],
          mK = [],
          sO = [],
          HO = [],
          RO = [],
          SO = [],
          JO = [],
          cK = [],
          BO = [],
          ZO = [],
          GO = [],
          qK = [],
          xK = [],
          nO = [],
          WO = [],
          tK = [],
          kK = [],
          UO = [],
          OK = [],
          KK = [],
          pK = [];
        return OO = class extends jK {
          static _CreateVideoTexture(KO, pO, XO) {
            arguments.length > 5 && void 0 !== arguments[5] || OO.TRILINEAR_SAMPLINGMODE;
            throw (0, hO.j)("VideoTexture")
          }
          get noMipmap() {
            return this._noMipmap
          }
          get mimeType() {
            return this._mimeType
          }
          set isBlocking(OO) {
            this._isBlocking = OO
          }
          get isBlocking() {
            return this._isBlocking
          }
          get invertY() {
            return this._invertY
          }
          constructor(KO, pO, bK, lO) {
            let vK, CO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : OO.TRILINEAR_SAMPLINGMODE,
              hO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
              MO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null,
              aK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
              oO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8],
              FO = arguments.length > 9 ? arguments[9] : void 0,
              VO = arguments.length > 10 ? arguments[10] : void 0,
              LO = arguments.length > 11 ? arguments[11] : void 0,
              zK = arguments.length > 12 ? arguments[12] : void 0,
              AO = arguments.length > 13 ? arguments[13] : void 0;
            super(pO), this.url = ((0, XO.i)(this, YO), (0, XO.i)(this, wO, null)), this.uOffset = ((0, XO.i)(this, iK), (0, XO.i)(this, rK, 0)), this.vOffset = ((0, XO.i)(this, PO), (0, XO.i)(this, mK, 0)), this.uScale = ((0, XO.i)(this, sO), (0, XO.i)(this, HO, 1)), this.vScale = ((0, XO.i)(this, RO), (0, XO.i)(this, SO, 1)), this.uAng = ((0, XO.i)(this, JO), (0, XO.i)(this, cK, 0)), this.vAng = ((0, XO.i)(this, BO), (0, XO.i)(this, ZO, 0)), this.wAng = ((0, XO.i)(this, GO), (0, XO.i)(this, qK, 0)), this.uRotationCenter = ((0, XO.i)(this, xK), (0, XO.i)(this, nO, .5)), this.vRotationCenter = ((0, XO.i)(this, WO), (0, XO.i)(this, tK, .5)), this.wRotationCenter = ((0, XO.i)(this, kK), (0, XO.i)(this, UO, .5)), this.homogeneousRotationInUVTransform = ((0, XO.i)(this, OK), (0, XO.i)(this, KK, !1)), this.inspectableCustomProperties = ((0, XO.i)(this, pK), null), this._noMipmap = !1, this._invertY = !1, this._rowGenerationMatrix = null, this._cachedTextureMatrix = null, this._projectionModeMatrix = null, this._t0 = null, this._t1 = null, this._t2 = null, this._cachedUOffset = -1, this._cachedVOffset = -1, this._cachedUScale = 0, this._cachedVScale = 0, this._cachedUAng = -1, this._cachedVAng = -1, this._cachedWAng = -1, this._cachedReflectionProjectionMatrixId = -1, this._cachedURotationCenter = -1, this._cachedVRotationCenter = -1, this._cachedWRotationCenter = -1, this._cachedHomogeneousRotationInUVTransform = !1, this._cachedIdentity3x2 = !0, this._cachedReflectionTextureMatrix = null, this._cachedReflectionUOffset = -1, this._cachedReflectionVOffset = -1, this._cachedReflectionUScale = 0, this._cachedReflectionVScale = 0, this._cachedReflectionCoordinatesMode = -1, this._buffer = null, this._deleteBuffer = !1, this._format = null, this._delayedOnLoad = null, this._delayedOnError = null, this.onLoadObservable = new eO.e, this._isBlocking = !0, this.name = KO || "", this.url = KO;
            let fO = !1,
              dO = null,
              TO = !0;
            "object" === typeof bK && null !== bK ? (vK = bK.noMipmap ?? !1, lO = bK.invertY ?? !QO.b, CO = bK.samplingMode ?? OO.TRILINEAR_SAMPLINGMODE, hO = bK.onLoad ?? null, MO = bK.onError ?? null, aK = bK.buffer ?? null, oO = bK.deleteBuffer ?? !1, FO = bK.format, VO = bK.mimeType, LO = bK.loaderOptions, zK = bK.creationFlags, fO = bK.useSRGBBuffer ?? !1, dO = bK.internalTexture ?? null, TO = bK.gammaSpace ?? TO, AO = bK.forcedExtension ?? AO) : vK = !!bK, this._gammaSpace = TO, this._noMipmap = vK, this._invertY = void 0 === lO ? !QO.b : lO, this._initialSamplingMode = CO, this._buffer = aK, this._deleteBuffer = oO, this._mimeType = VO, this._loaderOptions = LO, this._creationFlags = zK, this._useSRGBBuffer = fO, this._forcedExtension = AO, void 0 !== FO && (this._format = FO);
            const NO = this.JKO(),
              IO = this._getEngine();
            if (!IO) return;
            IO.onBeforeTextureInitObservable.notifyObservers(this);
            const yK = () => {
                this._texture && (this._texture._invertVScale && (this.vScale *= -1, this.vOffset += 1), null !== this._texture._cachedWrapU && (this.wrapU = this._texture._cachedWrapU, this._texture._cachedWrapU = null), null !== this._texture._cachedWrapV && (this.wrapV = this._texture._cachedWrapV, this._texture._cachedWrapV = null), null !== this._texture._cachedWrapR && (this.wrapR = this._texture._cachedWrapR, this._texture._cachedWrapR = null)), this.onLoadObservable.hasObservers() && this.onLoadObservable.notifyObservers(this), hO && hO(), !this.isBlocking && NO && NO.resetCachedMaterial()
              },
              gK = (KO, pO) => {
                this._loadingError = !0, this._errorObject = {
                  message: KO,
                  exception: pO
                }, MO && MO(KO, pO), OO.OnTextureLoadErrorObservable.notifyObservers(this)
              };
            if (!this.url && !dO) return this._delayedOnLoad = yK, void(this._delayedOnError = gK);
            if (this._texture = dO ?? this._getFromCache(this.url, vK, CO, this._invertY, fO, this.isCube), this._texture)
              if (this._texture.isReady) DO.c.SetImmediate((() => yK()));
              else {
                const OO = this._texture.onLoadedObservable.add(yK);
                this._texture.onErrorObservable.add((KO => {
                  gK(KO.message, KO.exception), this._texture?.onLoadedObservable.remove(OO)
                }))
              }
            else if (NO && NO.useDelayedTextureLoading) this.delayLoadState = 4, this._delayedOnLoad = yK, this._delayedOnError = gK;
            else {
              try {
                this._texture = IO.createTexture(this.url, vK, this._invertY, NO, CO, yK, gK, this._buffer, void 0, this._format, this._forcedExtension, VO, LO, zK, fO)
              } catch (uO) {
                throw gK("error loading", uO), uO
              }
              oO && (this._buffer = null)
            }
          }
          updateURL(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
              pO = arguments.length > 2 ? arguments[2] : void 0,
              XO = arguments.length > 3 ? arguments[3] : void 0;
            this.url && (this.releaseInternalTexture(), this.JKO().markAllMaterialsAsDirty(1, (OO => OO.hasTexture(this)))), this.name && !this.name.startsWith("data:") || (this.name = OO), this.url = OO, this._buffer = KO, this._forcedExtension = XO, this.delayLoadState = 4;
            const bK = this._delayedOnLoad;
            this._delayedOnLoad = () => {
              bK ? bK() : this.onLoadObservable.hasObservers() && this.onLoadObservable.notifyObservers(this), pO && pO()
            }, this.delayLoad()
          }
          delayLoad() {
            if (4 !== this.delayLoadState) return;
            const OO = this.JKO();
            if (!OO) return;
            let KO = this.url;
            !KO && (this.name.indexOf("://") > 0 || this.name.startsWith("data:")) && (KO = this.name), this.delayLoadState = 1, this._texture = this._getFromCache(KO, this._noMipmap, this.samplingMode, this._invertY, this._useSRGBBuffer, this.isCube), this._texture ? this._delayedOnLoad && (this._texture.isReady ? DO.c.SetImmediate(this._delayedOnLoad) : this._texture.onLoadedObservable.add(this._delayedOnLoad)) : (this._texture = OO.qb().createTexture(KO, this._noMipmap, this._invertY, OO, this.samplingMode, this._delayedOnLoad, this._delayedOnError, this._buffer, null, this._format, this._forcedExtension, this._mimeType, this._loaderOptions, this._creationFlags, this._useSRGBBuffer), this._deleteBuffer && (this._buffer = null)), this._delayedOnLoad = null, this._delayedOnError = null
          }
          _prepareRowForTextureGeneration(OO, KO, pO, XO) {
            OO *= this._cachedUScale, KO *= this._cachedVScale, OO -= this.uRotationCenter * this._cachedUScale, KO -= this.vRotationCenter * this._cachedVScale, pO -= this.wRotationCenter, lO.o.TransformCoordinatesFromFloatsToRef(OO, KO, pO, this._rowGenerationMatrix, XO), XO.x += this.uRotationCenter * this._cachedUScale + this._cachedUOffset, XO.y += this.vRotationCenter * this._cachedVScale + this._cachedVOffset, XO.z += this.wRotationCenter
          }
          getTextureMatrix() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
            if (this.uOffset === this._cachedUOffset && this.vOffset === this._cachedVOffset && this.uScale * OO === this._cachedUScale && this.vScale === this._cachedVScale && this.uAng === this._cachedUAng && this.vAng === this._cachedVAng && this.wAng === this._cachedWAng && this.uRotationCenter === this._cachedURotationCenter && this.vRotationCenter === this._cachedVRotationCenter && this.wRotationCenter === this._cachedWRotationCenter && this.homogeneousRotationInUVTransform === this._cachedHomogeneousRotationInUVTransform) return this._cachedTextureMatrix;
            this._cachedUOffset = this.uOffset, this._cachedVOffset = this.vOffset, this._cachedUScale = this.uScale * OO, this._cachedVScale = this.vScale, this._cachedUAng = this.uAng, this._cachedVAng = this.vAng, this._cachedWAng = this.wAng, this._cachedURotationCenter = this.uRotationCenter, this._cachedVRotationCenter = this.vRotationCenter, this._cachedWRotationCenter = this.wRotationCenter, this._cachedHomogeneousRotationInUVTransform = this.homogeneousRotationInUVTransform, this._cachedTextureMatrix && this._rowGenerationMatrix || (this._cachedTextureMatrix = lO.c.Zero(), this._rowGenerationMatrix = new lO.c, this._t0 = lO.o.Zero(), this._t1 = lO.o.Zero(), this._t2 = lO.o.Zero()), lO.c.RotationYawPitchRollToRef(this.vAng, this.uAng, this.wAng, this._rowGenerationMatrix), this.homogeneousRotationInUVTransform ? (lO.c.TranslationToRef(-this._cachedURotationCenter, -this._cachedVRotationCenter, -this._cachedWRotationCenter, lO.j.Matrix[0]), lO.c.TranslationToRef(this._cachedURotationCenter, this._cachedVRotationCenter, this._cachedWRotationCenter, lO.j.Matrix[1]), lO.c.ScalingToRef(this._cachedUScale, this._cachedVScale, 0, lO.j.Matrix[2]), lO.c.TranslationToRef(this._cachedUOffset, this._cachedVOffset, 0, lO.j.Matrix[3]), lO.j.Matrix[0].multiplyToRef(this._rowGenerationMatrix, this._cachedTextureMatrix), this._cachedTextureMatrix.multiplyToRef(lO.j.Matrix[1], this._cachedTextureMatrix), this._cachedTextureMatrix.multiplyToRef(lO.j.Matrix[2], this._cachedTextureMatrix), this._cachedTextureMatrix.multiplyToRef(lO.j.Matrix[3], this._cachedTextureMatrix), this._cachedTextureMatrix.setRowFromFloats(2, this._cachedTextureMatrix.m[12], this._cachedTextureMatrix.m[13], this._cachedTextureMatrix.m[14], 1)) : (this._prepareRowForTextureGeneration(0, 0, 0, this._t0), this._prepareRowForTextureGeneration(1, 0, 0, this._t1), this._prepareRowForTextureGeneration(0, 1, 0, this._t2), this._t1.oDO(this._t0), this._t2.oDO(this._t0), lO.c.FromValuesToRef(this._t1.x, this._t1.y, this._t1.z, 0, this._t2.x, this._t2.y, this._t2.z, 0, this._t0.x, this._t0.y, this._t0.z, 0, 0, 0, 0, 1, this._cachedTextureMatrix));
            const KO = this.JKO();
            if (!KO) return this._cachedTextureMatrix;
            const pO = this._cachedIdentity3x2;
            return this._cachedIdentity3x2 = this._cachedTextureMatrix.isIdentityAs3x2(), this.optimizeUVAllocation && pO !== this._cachedIdentity3x2 && KO.markAllMaterialsAsDirty(1, (OO => OO.hasTexture(this))), this._cachedTextureMatrix
          }
          getReflectionTextureMatrix() {
            const KO = this.JKO();
            if (!KO) return this._cachedReflectionTextureMatrix;
            if (this.uOffset === this._cachedReflectionUOffset && this.vOffset === this._cachedReflectionVOffset && this.uScale === this._cachedReflectionUScale && this.vScale === this._cachedReflectionVScale && this.coordinatesMode === this._cachedReflectionCoordinatesMode) {
              if (this.coordinatesMode !== OO.PROJECTION_MODE) return this._cachedReflectionTextureMatrix;
              if (this._cachedReflectionProjectionMatrixId === KO.getProjectionMatrix().updateFlag) return this._cachedReflectionTextureMatrix
            }
            this._cachedReflectionTextureMatrix || (this._cachedReflectionTextureMatrix = lO.c.Zero()), this._projectionModeMatrix || (this._projectionModeMatrix = lO.c.Zero());
            const pO = this._cachedReflectionCoordinatesMode !== this.coordinatesMode;
            switch (this._cachedReflectionUOffset = this.uOffset, this._cachedReflectionVOffset = this.vOffset, this._cachedReflectionUScale = this.uScale, this._cachedReflectionVScale = this.vScale, this._cachedReflectionCoordinatesMode = this.coordinatesMode, this.coordinatesMode) {
              case OO.PLANAR_MODE:
                lO.c.IdentityToRef(this._cachedReflectionTextureMatrix), this._cachedReflectionTextureMatrix[0] = this.uScale, this._cachedReflectionTextureMatrix[5] = this.vScale, this._cachedReflectionTextureMatrix[12] = this.uOffset, this._cachedReflectionTextureMatrix[13] = this.vOffset;
                break;
              case OO.PROJECTION_MODE: {
                lO.c.FromValuesToRef(.5, 0, 0, 0, 0, -.5, 0, 0, 0, 0, 0, 0, .5, .5, 1, 1, this._projectionModeMatrix);
                const OO = KO.getProjectionMatrix();
                this._cachedReflectionProjectionMatrixId = OO.updateFlag, OO.multiplyToRef(this._projectionModeMatrix, this._cachedReflectionTextureMatrix);
                break
              }
              default:
                lO.c.IdentityToRef(this._cachedReflectionTextureMatrix)
            }
            return pO && KO.markAllMaterialsAsDirty(1, (OO => OO.hasTexture(this))), this._cachedReflectionTextureMatrix
          }
          clone() {
            const KO = {
              noMipmap: this._noMipmap,
              invertY: this._invertY,
              samplingMode: this.samplingMode,
              onLoad: void 0,
              onError: void 0,
              buffer: this._texture ? this._texture._buffer : void 0,
              deleteBuffer: this._deleteBuffer,
              format: this.textureFormat,
              mimeType: this.mimeType,
              loaderOptions: this._loaderOptions,
              creationFlags: this._creationFlags,
              useSRGBBuffer: this._useSRGBBuffer
            };
            return zK.c.Clone((() => new OO(this._texture ? this._texture.url : null, this.JKO(), KO)), this)
          }
          serialize() {
            const KO = this.name;
            OO.SerializeBuffers || this.name.startsWith("data:") && (this.name = ""), this.name.startsWith("data:") && this.url === this.name && (this.url = "");
            const pO = super.serialize(OO._SerializeInternalTextureUniqueId);
            if (!pO) return null;
            if (OO.SerializeBuffers || OO.ForceSerializeBuffers)
              if ("string" === typeof this._buffer && this._buffer.startsWith("data:")) pO.base64String = this._buffer, pO.name = pO.name.replace("data:", "");
              else if (this.url && this.url.startsWith("data:") && this._buffer instanceof Uint8Array) {
              const OO = this.mimeType || "image/png";
              pO.base64String = `data:${OO};base64,${(0,oO.k)(this._buffer)}`
            } else(OO.ForceSerializeBuffers || this.url && this.url.startsWith("blob:") || this._forceSerialize) && (pO.base64String = !this._engine || this._engine._features.supportSyncTextureRead ? VO(this) : LO(this));
            return pO.invertY = this._invertY, pO.samplingMode = this.samplingMode, pO._creationFlags = this._creationFlags, pO._useSRGBBuffer = this._useSRGBBuffer, OO._SerializeInternalTextureUniqueId && (pO.internalTextureUniqueId = this._texture?.uniqueId), pO.internalTextureLabel = this._texture?.label, pO.noMipmap = this._noMipmap, this.name = KO, pO
          }
          getClassName() {
            return "Texture"
          }
          dispose() {
            super.dispose(), this.onLoadObservable.clear(), this._delayedOnLoad = null, this._delayedOnError = null, this._buffer = null
          }
          static Parse(KO, pO, XO) {
            if (KO.customType) {
              const OO = MO.b.Instantiate(KO.customType).Parse(KO, pO, XO);
              return KO.samplingMode && OO.updateSamplingMode && OO._samplingMode && OO._samplingMode !== KO.samplingMode && OO.updateSamplingMode(KO.samplingMode), OO
            }
            if (KO.isCube && !KO.isRenderTarget) return OO._CubeTextureParser(KO, pO, XO);
            const bK = void 0 !== KO.internalTextureUniqueId;
            if (!KO.name && !KO.isRenderTarget && !bK) return null;
            let eO;
            if (bK) {
              const OO = pO.qb().getLoadedTexturesCache();
              for (const pO of OO)
                if (pO.uniqueId === KO.internalTextureUniqueId) {
                  eO = pO;
                  break
                }
            }
            const lO = OO => {
              if (OO && OO._texture && (OO._texture._cachedWrapU = null, OO._texture._cachedWrapV = null, OO._texture._cachedWrapR = null), KO.samplingMode) {
                const pO = KO.samplingMode;
                OO && OO.samplingMode !== pO && OO.updateSamplingMode(pO)
              }
              if (OO && KO.animations)
                for (let pO = 0; pO < KO.animations.length; pO++) {
                  const XO = KO.animations[pO],
                    bK = (0, CO.e)("BABYLON.Animation");
                  bK && OO.animations.push(bK.Parse(XO))
                }
              OO && OO._texture && (bK && !eO && OO._texture._setUniqueId(KO.internalTextureUniqueId), OO._texture.label = KO.internalTextureLabel)
            };
            return zK.c.Parse((() => {
              let bK = !0;
              if (KO.noMipmap && (bK = !1), KO.mirrorPlane) {
                const XO = OO._CreateMirror(KO.name, KO.renderTargetSize, pO, bK);
                return XO._waitingRenderList = KO.renderList, XO.mirrorPlane = aK.d.FromArray(KO.mirrorPlane), lO(XO), XO
              }
              if (KO.isRenderTarget && !KO.base64String) {
                let XO = null;
                if (KO.isCube) {
                  if (pO.reflectionProbes)
                    for (let OO = 0; OO < pO.reflectionProbes.length; OO++) {
                      const XO = pO.reflectionProbes[OO];
                      if (XO.name === KO.name) return XO.cubeTexture
                    }
                } else XO = OO._CreateRenderTargetTexture(KO.name, KO.renderTargetSize, pO, bK, KO._creationFlags ?? 0), XO._waitingRenderList = KO.renderList;
                return lO(XO), XO
              }
              if (KO.isVideo) {
                const eO = OO._CreateVideoTexture(XO + (KO.url || KO.name), XO + (KO.src || KO.url), pO, bK, KO.invertY, KO.samplingMode, KO.settings || {});
                return lO(eO), eO
              } {
                let vK;
                if ("string" === typeof KO.base64String && KO.base64String && !eO) {
                  const XO = {
                      buffer: KO.base64String,
                      noMipmap: !bK,
                      invertY: KO.invertY,
                      samplingMode: KO.samplingMode,
                      useSRGBBuffer: KO._useSRGBBuffer ?? !1,
                      creationFlags: KO._creationFlags ?? 0,
                      onLoad: () => {
                        lO(vK)
                      }
                    },
                    eO = KO.base64String,
                    CO = eO.startsWith("data:") ? eO.substring(5) : eO;
                  vK = OO.CreateFromBase64String("", CO, pO, XO), vK.name = KO.name
                } else {
                  let CO;
                  CO = KO.name && (KO.name.indexOf("://") > 0 || KO.name.startsWith("data:")) ? KO.name : XO + KO.name, KO.url && (KO.url.startsWith("data:") || OO.UseSerializedUrlIfAny) && (CO = KO.url);
                  const hO = {
                    noMipmap: !bK,
                    invertY: KO.invertY,
                    samplingMode: KO.samplingMode,
                    useSRGBBuffer: KO._useSRGBBuffer ?? !1,
                    creationFlags: KO._creationFlags ?? 0,
                    onLoad: () => {
                      lO(vK)
                    },
                    internalTexture: eO
                  };
                  vK = new OO(CO, pO, hO)
                }
                return vK
              }
            }), KO, pO)
          }
          static CreateFromBase64String(KO, pO, XO, bK, eO) {
            let lO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : OO.TRILINEAR_SAMPLINGMODE;
            return new OO("data:" + pO, XO, bK, eO, lO, arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null, arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null, KO, !1, arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 5, void 0, void 0, arguments.length > 9 ? arguments[9] : void 0, arguments.length > 10 ? arguments[10] : void 0)
          }
          static LoadFromDataString(KO, pO, XO) {
            let bK = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
              eO = arguments.length > 4 ? arguments[4] : void 0,
              lO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
              vK = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : OO.TRILINEAR_SAMPLINGMODE,
              CO = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
              hO = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : null,
              DO = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 5,
              MO = arguments.length > 10 ? arguments[10] : void 0,
              aK = arguments.length > 11 ? arguments[11] : void 0;
            return "data:" !== KO.substring(0, 5) && (KO = "data:" + KO), new OO(KO, XO, eO, lO, vK, CO, hO, pO, bK, DO, void 0, void 0, MO, aK)
          }
        }, (() => {
          const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(jK[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.M)()], pO = [(0, bK.M)()], FO = [(0, bK.M)()], AO = [(0, bK.M)()], fO = [(0, bK.M)()], dO = [(0, bK.M)()], TO = [(0, bK.M)()], NO = [(0, bK.M)()], IO = [(0, bK.M)()], yK = [(0, bK.M)()], gK = [(0, bK.M)()], uO = [(0, bK.M)()], EO = [(0, bK.M)()], (0, XO.f)(OO, null, EO, {
            kind: "getter",
            name: "isBlocking",
            static: !1,
            private: !1,
            access: {
              has: OO => "isBlocking" in OO,
              get: OO => OO.isBlocking
            },
            metadata: eO
          }, null, YO), (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "url",
            static: !1,
            private: !1,
            access: {
              has: OO => "url" in OO,
              get: OO => OO.url,
              set: (OO, KO) => {
                OO.url = KO
              }
            },
            metadata: eO
          }, wO, iK), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "uOffset",
            static: !1,
            private: !1,
            access: {
              has: OO => "uOffset" in OO,
              get: OO => OO.uOffset,
              set: (OO, KO) => {
                OO.uOffset = KO
              }
            },
            metadata: eO
          }, rK, PO), (0, XO.f)(null, null, FO, {
            kind: "field",
            name: "vOffset",
            static: !1,
            private: !1,
            access: {
              has: OO => "vOffset" in OO,
              get: OO => OO.vOffset,
              set: (OO, KO) => {
                OO.vOffset = KO
              }
            },
            metadata: eO
          }, mK, sO), (0, XO.f)(null, null, AO, {
            kind: "field",
            name: "uScale",
            static: !1,
            private: !1,
            access: {
              has: OO => "uScale" in OO,
              get: OO => OO.uScale,
              set: (OO, KO) => {
                OO.uScale = KO
              }
            },
            metadata: eO
          }, HO, RO), (0, XO.f)(null, null, fO, {
            kind: "field",
            name: "vScale",
            static: !1,
            private: !1,
            access: {
              has: OO => "vScale" in OO,
              get: OO => OO.vScale,
              set: (OO, KO) => {
                OO.vScale = KO
              }
            },
            metadata: eO
          }, SO, JO), (0, XO.f)(null, null, dO, {
            kind: "field",
            name: "uAng",
            static: !1,
            private: !1,
            access: {
              has: OO => "uAng" in OO,
              get: OO => OO.uAng,
              set: (OO, KO) => {
                OO.uAng = KO
              }
            },
            metadata: eO
          }, cK, BO), (0, XO.f)(null, null, TO, {
            kind: "field",
            name: "vAng",
            static: !1,
            private: !1,
            access: {
              has: OO => "vAng" in OO,
              get: OO => OO.vAng,
              set: (OO, KO) => {
                OO.vAng = KO
              }
            },
            metadata: eO
          }, ZO, GO), (0, XO.f)(null, null, NO, {
            kind: "field",
            name: "wAng",
            static: !1,
            private: !1,
            access: {
              has: OO => "wAng" in OO,
              get: OO => OO.wAng,
              set: (OO, KO) => {
                OO.wAng = KO
              }
            },
            metadata: eO
          }, qK, xK), (0, XO.f)(null, null, IO, {
            kind: "field",
            name: "uRotationCenter",
            static: !1,
            private: !1,
            access: {
              has: OO => "uRotationCenter" in OO,
              get: OO => OO.uRotationCenter,
              set: (OO, KO) => {
                OO.uRotationCenter = KO
              }
            },
            metadata: eO
          }, nO, WO), (0, XO.f)(null, null, yK, {
            kind: "field",
            name: "vRotationCenter",
            static: !1,
            private: !1,
            access: {
              has: OO => "vRotationCenter" in OO,
              get: OO => OO.vRotationCenter,
              set: (OO, KO) => {
                OO.vRotationCenter = KO
              }
            },
            metadata: eO
          }, tK, kK), (0, XO.f)(null, null, gK, {
            kind: "field",
            name: "wRotationCenter",
            static: !1,
            private: !1,
            access: {
              has: OO => "wRotationCenter" in OO,
              get: OO => OO.wRotationCenter,
              set: (OO, KO) => {
                OO.wRotationCenter = KO
              }
            },
            metadata: eO
          }, UO, OK), (0, XO.f)(null, null, uO, {
            kind: "field",
            name: "homogeneousRotationInUVTransform",
            static: !1,
            private: !1,
            access: {
              has: OO => "homogeneousRotationInUVTransform" in OO,
              get: OO => OO.homogeneousRotationInUVTransform,
              set: (OO, KO) => {
                OO.homogeneousRotationInUVTransform = KO
              }
            },
            metadata: eO
          }, KK, pK), eO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: eO
          })
        })(), OO.SerializeBuffers = !0, OO.ForceSerializeBuffers = !1, OO.OnTextureLoadErrorObservable = new eO.e, OO._SerializeInternalTextureUniqueId = !1, OO._CubeTextureParser = (OO, KO, pO) => {
          throw (0, hO.j)("CubeTexture")
        }, OO._CreateMirror = (OO, KO, pO, XO) => {
          throw (0, hO.j)("MirrorTexture")
        }, OO._CreateRenderTargetTexture = (OO, KO, pO, XO, bK) => {
          throw (0, hO.j)("RenderTargetTexture")
        }, OO.NEAREST_SAMPLINGMODE = 1, OO.NEAREST_NEAREST_MIPLINEAR = 8, OO.BILINEAR_SAMPLINGMODE = 2, OO.LINEAR_LINEAR_MIPNEAREST = 11, OO.TRILINEAR_SAMPLINGMODE = 3, OO.LINEAR_LINEAR_MIPLINEAR = 3, OO.NEAREST_NEAREST_MIPNEAREST = 4, OO.NEAREST_LINEAR_MIPNEAREST = 5, OO.NEAREST_LINEAR_MIPLINEAR = 6, OO.NEAREST_LINEAR = 7, OO.NEAREST_NEAREST = 1, OO.LINEAR_NEAREST_MIPNEAREST = 9, OO.LINEAR_NEAREST_MIPLINEAR = 10, OO.LINEAR_LINEAR = 2, OO.LINEAR_NEAREST = 12, OO.EXPLICIT_MODE = 0, OO.SPHERICAL_MODE = 1, OO.PLANAR_MODE = 2, OO.CUBIC_MODE = 3, OO.PROJECTION_MODE = 4, OO.SKYBOX_MODE = 5, OO.INVCUBIC_MODE = 6, OO.EQUIRECTANGULAR_MODE = 7, OO.FIXED_EQUIRECTANGULAR_MODE = 8, OO.FIXED_EQUIRECTANGULAR_MIRRORED_MODE = 9, OO.CLAMP_ADDRESSMODE = 0, OO.WRAP_ADDRESSMODE = 1, OO.MIRROR_ADDRESSMODE = 2, OO.UseSerializedUrlIfAny = !1, OO
      })(),
      fO = !1;

    function dO() {
      fO || (fO = !0, (0, CO.h)("BABYLON.Texture", AO), zK.c._TextureParser = AO.Parse)
    }
  },
  38073: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO
    });
    class XO {
      constructor(OO, KO) {
        this.width = OO, this.height = KO
      }
      toString() {
        return `{W: ${this.width}, H: ${this.height}}`
      }
      getClassName() {
        return "Size"
      }
      getHashCode() {
        let OO = 0 | this.width;
        return OO = 397 * OO ^ this.height, OO
      }
      NhO(OO) {
        this.width = OO.width, this.height = OO.height
      }
      rvO(OO, KO) {
        return this.width = OO, this.height = KO, this
      }
      set(OO, KO) {
        return this.rvO(OO, KO)
      }
      multiplyByFloats(OO, KO) {
        return new XO(this.width * OO, this.height * KO)
      }
      clone() {
        return new XO(this.width, this.height)
      }
      equals(OO) {
        return !!OO && (this.width === OO.width && this.height === OO.height)
      }
      get surface() {
        return this.width * this.height
      }
      static Zero() {
        return new XO(0, 0)
      }
      add(OO) {
        return new XO(this.width + OO.width, this.height + OO.height)
      }
      subtract(OO) {
        return new XO(this.width - OO.width, this.height - OO.height)
      }
      scale(OO) {
        return new XO(this.width * OO, this.height * OO)
      }
      static Lerp(OO, KO, pO) {
        const bK = OO.width + (KO.width - OO.width) * pO,
          eO = OO.height + (KO.height - OO.height) * pO;
        return new XO(bK, eO)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);