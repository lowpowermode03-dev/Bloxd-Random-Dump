export const id = 22;
export const ids = [22];
export const modules = {
  37749: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => XO
    });
    const XO = function(OO, KO, pO) {
      let XO;
      return {
        onCreate: OO => {
          XO = OO
        },
        onPlayerAltAction: (OO, KO, pO, bK, eO, lO) => {
          null !== lO && "Mesh" === XO.getEntityType(lO) && "Weaponmaster" === XO.getEntityName(lO) && XO.openShop(OO, !1, "PvpCivWeapon")
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);