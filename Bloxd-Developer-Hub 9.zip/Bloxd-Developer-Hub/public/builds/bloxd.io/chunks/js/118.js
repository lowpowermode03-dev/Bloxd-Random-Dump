export const id = 118;
export const ids = [118, 120, 123];
export const modules = {
  5711: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(5715),
      bK = pO(976);
    const eO = {
      strict: "shaderPack:variantStrict",
      nonStrict: "shaderPack:variantNonStrict",
      terrain: "shaderPack:variantTerrain",
      liquid: "shaderPack:variantLiquid",
      model: "shaderPack:variantModel"
    };

    function lO(OO) {
      let {
        diagnostics: KO,
        more: pO = 0,
        t: lO
      } = OO;
      return (0, bK.jsxs)("ul", {
        className: "ShaderPackDiagnostics",
        children: [KO.map(((OO, KO) => {
          const pO = (0, XO.e)(OO),
            vK = function(OO, KO) {
              const pO = (0, XO.c)(null !== OO && void 0 !== OO ? OO : []);
              if (0 === pO.length) return null;
              return pO.map((OO => OO.map((OO => KO(eO[OO]))).join(", "))).join("; ")
            }(OO.variants, lO);
          return (0, bK.jsxs)("li", {
            children: [pO && (0, bK.jsx)("span", {
              className: "ShaderPackDiagnosticLocation",
              children: pO
            }), OO.message, vK && (0, bK.jsx)("span", {
              className: "ShaderPackDiagnosticVariants",
              children: lO("shaderPack:onlyIn", {
                variants: vK
              })
            })]
          }, KO)
        })), pO > 0 && (0, bK.jsx)("li", {
          children: lO("shaderPack:moreErrors", {
            count: String(pO)
          })
        })]
      })
    }
  },
  5730: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => cK,
      h: () => BO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(4080),
      vK = pO(1180),
      CO = pO(933),
      hO = pO(1271),
      DO = pO(1051),
      MO = pO(94),
      aK = pO(5709),
      oO = pO(5721);
    class FO extends Error {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        super(OO, arguments.length > 2 ? arguments[2] : void 0), this.translationKey = OO, this.params = KO
      }
    }
    const VO = 1024,
      LO = 101010256,
      QO = 33639248,
      zK = 67324752,
      AO = 22,
      fO = 46,
      dO = 30,
      TO = 65535,
      NO = 65535,
      IO = 4294967295,
      yK = 0,
      gK = 8,
      uO = new TextDecoder;

    function EO(OO) {
      const KO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength),
        pO = function(OO) {
          const KO = OO.byteLength - AO;
          for (let pO = KO; pO >= Math.max(0, KO - TO); pO--)
            if (OO.getUint32(pO, !0) === LO && pO + AO + OO.getUint16(pO + 20, !0) <= OO.byteLength) return pO;
          throw new FO("shaderPack:loadNotZip")
        }(KO),
        XO = KO.getUint16(pO + 8, !0),
        bK = KO.getUint16(pO + 10, !0),
        eO = KO.getUint32(pO + 12, !0),
        lO = KO.getUint32(pO + 16, !0);
      if (bK === NO || eO === IO || lO === IO) throw iK();
      if (0 !== KO.getUint16(pO + 4, !0) || 0 !== KO.getUint16(pO + 6, !0) || XO !== bK) throw new FO("shaderPack:loadSplitZip");
      if (bK > VO) throw new FO("shaderPack:loadTooManyZipEntries", {
        count: String(VO)
      });
      const vK = lO + eO;
      if (vK > pO) throw wO();
      const CO = [];
      let hO = lO;
      for (let DO = 0; DO < bK; DO++) {
        if (hO + fO > vK || KO.getUint32(hO, !0) !== QO) throw wO();
        const pO = KO.getUint16(hO + 8, !0),
          XO = KO.getUint16(hO + 10, !0),
          bK = KO.getUint32(hO + 20, !0),
          eO = KO.getUint32(hO + 24, !0),
          DO = KO.getUint16(hO + 28, !0),
          MO = KO.getUint16(hO + 30, !0),
          aK = KO.getUint16(hO + 32, !0),
          oO = KO.getUint32(hO + 42, !0),
          FO = hO + fO;
        if (hO = FO + DO + MO + aK, hO > vK) throw wO();
        if (bK === IO || eO === IO || oO === IO) throw iK();
        const VO = uO.decode(OO.subarray(FO, FO + DO)).replace(/\\/g, "/");
        VO.endsWith("/") || CO.push({
          path: VO,
          method: XO,
          encrypted: 0 !== (1 & pO),
          compressedSize: bK,
          dataOffset: YO(KO, oO, bK, lO)
        })
      }
      return CO
    }
    async function jK(OO, KO, pO) {
      if (KO.encrypted) throw new FO("shaderPack:loadEncrypted", {
        path: KO.path
      });
      if (KO.method === yK) return KO.compressedSize > pO ? null : OO.subarray(KO.dataOffset, KO.dataOffset + KO.compressedSize);
      if (KO.method === gK) return async function(OO, KO, pO) {
        const XO = new Blob([OO]).stream().pipeThrough(new DecompressionStream("deflate-raw")).getReader(),
          bK = [];
        let eO = 0;
        try {
          for (;;) {
            const {
              done: OO,
              value: pO
            } = await XO.read();
            if (OO) break;
            if (eO += pO.byteLength, eO > KO) return await XO.cancel(), null;
            bK.push(pO)
          }
        } catch (CO) {
          throw new FO("shaderPack:loadDecompressFailed", {
            path: pO
          }, {
            cause: CO
          })
        }
        const lO = new Uint8Array(eO);
        let vK = 0;
        for (const hO of bK) lO.set(hO, vK), vK += hO.byteLength;
        return lO
      }(OO.slice(KO.dataOffset, KO.dataOffset + KO.compressedSize), pO, KO.path);
      throw new FO("shaderPack:loadUnsupportedCompression", {
        path: KO.path,
        method: String(KO.method)
      })
    }

    function YO(OO, KO, pO, XO) {
      if (KO + dO > XO || OO.getUint32(KO, !0) !== zK) throw wO();
      const bK = KO + dO + OO.getUint16(KO + 26, !0) + OO.getUint16(KO + 28, !0);
      if (bK + pO > XO) throw wO();
      return bK
    }

    function wO() {
      return new FO("shaderPack:loadZipDamaged")
    }

    function iK() {
      return new FO("shaderPack:loadZip64")
    }
    const rK = 33554432,
      PO = 65536;
    async function mK(OO) {
      if (1 === OO.length && OO[0].name.toLowerCase().endsWith(".zip")) {
        const KO = OO[0];
        if (KO.size > rK) throw new FO("shaderPack:loadZipTooBig", {
          megabytes: String(rK / 1048576)
        });
        return async function(OO) {
          return sO(EO(OO).map((KO => ({
            path: KO.path,
            read: pO => jK(OO, KO, pO)
          }))))
        }(new Uint8Array(await KO.arrayBuffer()))
      }
      return sO(OO.map((OO => ({
        path: HO(OO),
        read: KO => async function(OO, KO) {
          return OO.size > KO ? null : new Uint8Array(await OO.arrayBuffer())
        }(OO, KO)
      }))))
    }
    async function sO(OO) {
      const KO = function(OO) {
          const KO = OO.length > 0 ? OO[0].path.indexOf("/") : -1;
          if (-1 === KO) return OO;
          const pO = OO[0].path.slice(0, KO + 1);
          if (!OO.every((OO => OO.path.startsWith(pO)))) return OO;
          return OO.map((OO => ({
            ...OO,
            path: OO.path.slice(pO.length)
          })))
        }(OO.filter((OO => ! function(OO) {
          const KO = OO.split("/"),
            pO = KO[KO.length - 1];
          return KO.includes("__MACOSX") || pO.startsWith("._") || ".DS_Store" === pO
        }(OO.path)))),
        pO = KO.filter((OO => "pack.json" === OO.path.toLowerCase()));
      if (0 === pO.length) throw new FO("shaderPack:loadNoManifest");
      if (pO.length > 1) throw new FO("shaderPack:loadDuplicateManifest");
      const XO = pO[0],
        bK = await XO.read(PO);
      if (null === bK) throw new FO("shaderPack:loadManifestTooBig", {
        kilobytes: String(PO / 1024)
      });
      const eO = function(OO) {
          let KO;
          try {
            KO = JSON.parse(OO)
          } catch (vK) {
            throw new FO("shaderPack:loadManifestNotJson", {
              error: vK.message
            }, {
              cause: vK
            })
          }
          if ("object" !== typeof KO || null === KO || Array.isArray(KO)) throw new FO("shaderPack:loadManifestNotObject");
          const {
            apiVersion: pO,
            name: XO,
            author: bK,
            description: eO,
            keepCircleShadows: lO
          } = KO;
          if (void 0 === pO) throw new FO("shaderPack:loadNoApiVersion", {
            version: String(oO.b)
          });
          if (!(0, oO.h)(pO)) throw new FO("shaderPack:loadWrongApiVersion", {
            packVersion: JSON.stringify(pO),
            version: String(oO.b)
          });
          if ("string" !== typeof XO || "" === XO.trim()) throw new FO("shaderPack:loadNoName");
          if (void 0 !== bK && null !== bK && "string" !== typeof bK) throw new FO("shaderPack:loadAuthorNotString");
          if (void 0 !== eO && null !== eO && "string" !== typeof eO) throw new FO("shaderPack:loadDescriptionNotString");
          if (void 0 !== lO && "boolean" !== typeof lO) throw new FO("shaderPack:loadKeepCircleShadowsNotBoolean");
          return {
            apiVersion: pO,
            name: XO,
            author: "string" === typeof bK ? bK : null,
            description: "string" === typeof eO && "" !== eO.trim() ? eO : null,
            keepCircleShadows: !0 === lO
          }
        }(RO(bK, XO.path)),
        lO = KO.filter((OO => OO.path.toLowerCase().endsWith(".wgsl"))).sort(((OO, KO) => (0, aK.m)(OO.path, KO.path)));
      if (0 === lO.length) throw new FO("shaderPack:loadNoWgsl");
      if (lO.length > aK.c) throw new FO("shaderPack:loadTooManyWgsl", {
        count: String(aK.c)
      });
      const vK = lO.find(((OO, KO) => KO > 0 && OO.path === lO[KO - 1].path));
      if (vK) throw new FO("shaderPack:loadDuplicatePath", {
        path: vK.path
      });
      const CO = [];
      let hO = aK.f;
      for (const DO of lO) {
        const OO = await DO.read(hO);
        if (null === OO) throw new FO("shaderPack:loadSourceTooBig", {
          kilobytes: String(aK.f / 1024)
        });
        hO -= OO.byteLength, CO.push({
          path: DO.path,
          source: RO(OO, DO.path)
        })
      }
      return {
        manifest: eO,
        files: CO
      }
    }

    function HO(OO) {
      return (OO.webkitRelativePath || OO.path || OO.name).replace(/^\.?\//, "")
    }

    function RO(OO, KO) {
      try {
        return new TextDecoder("utf-8", {
          fatal: !0
        }).decode(OO)
      } catch (pO) {
        throw new FO("shaderPack:loadNotUtf8", {
          path: KO
        }, {
          cause: pO
        })
      }
    }
    var SO = pO(5715),
      JO = pO(976);

    function cK(OO) {
      let {
        busy: KO,
        disabled: pO,
        onFiles: bK
      } = OO;
      const {
        t: aK
      } = (0, DO.D)(), oO = (0, XO.useRef)(null), FO = !(0, MO.isMobile)(), {
        getRootProps: VO,
        getInputProps: LO,
        isDragActive: QO,
        open: zK
      } = (0, lO.d)({
        onDrop: bK,
        noClick: !0,
        noKeyboard: !0,
        useFsAccessApi: !1,
        disabled: pO
      });
      return (0, JO.jsxs)("div", {
        ...VO({
          className: eO()("ShaderPackDropZone", {
            ActiveDrag: QO,
            Disabled: pO
          })
        }),
        children: [(0, JO.jsx)("input", {
          ...LO({
            webkitdirectory: "true"
          })
        }), (0, JO.jsx)("input", {
          ref: oO,
          type: "file",
          accept: ".zip,application/zip",
          hidden: !0,
          onChange: function(OO) {
            const KO = Array.from(OO.target.files);
            OO.target.value = "", bK(KO)
          }
        }), KO && (0, JO.jsx)(vK.e, {}), !KO && (0, JO.jsxs)(JO.Fragment, {
          children: [(0, JO.jsx)("div", {
            className: "ShaderPackDropZoneIcon",
            children: (0, JO.jsx)(CO.d, {
              name: "up-from-bracket"
            })
          }), (0, JO.jsx)("div", {
            className: "ShaderPackDropZoneInstructions",
            children: aK(FO ? "shaderPack:dropHere" : "shaderPack:chooseZipInstructions")
          }), (0, JO.jsxs)("div", {
            className: "ShaderPackDropZoneButtons",
            "data-pad-mouse-only": !0,
            children: [FO && (0, JO.jsx)(hO.d, {
              disabled: pO,
              onClick: zK,
              children: aK("shaderPack:chooseFolder")
            }), (0, JO.jsx)(hO.d, {
              disabled: pO,
              onClick: () => {
                oO.current.click()
              },
              children: aK("shaderPack:chooseZip")
            })]
          })]
        })]
      })
    }

    function BO(OO) {
      const {
        t: KO
      } = (0, DO.D)(), [pO, bK] = (0, XO.useState)(!1), [eO, lO] = (0, XO.useState)(null), vK = (0, XO.useRef)(!1);
      return {
        loading: pO,
        error: eO,
        setError: lO,
        onFiles: async function(pO) {
          if (!vK.current) {
            vK.current = !0, bK(!0), lO(null);
            try {
              await OO(await mK(pO))
            } catch (XO) {
              XO instanceof FO ? lO((0, SO.i)(KO, XO.translationKey, XO.params)) : (console.error("Failed to load the shader pack", XO), lO(KO("shaderPack:unexpectedError")))
            } finally {
              vK.current = !1, bK(!1)
            }
          }
        }
      }
    }
  },
  5715: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK,
      e: () => lO,
      i: () => eO
    });
    var XO = pO(5721);
    const bK = [OO => OO.strict ? "strict" : "nonStrict", OO => OO.program];

    function eO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      const XO = {};
      for (const bK in pO) XO[bK] = `\0${bK}\0`;
      return OO(KO, XO).replace(/\0(\w+)\0/g, ((OO, KO) => pO[KO]))
    }

    function lO(OO) {
      return null === OO.file ? null : OO.line > 0 ? `${OO.file}:${OO.line}` : OO.file
    }

    function vK(OO) {
      const KO = new Map(OO.map((OO => [CO(OO).join("."), OO])));
      if (0 === KO.size) return [];
      const pO = DO([...KO.values()]);
      return 0 === pO[0].length ? [] : pO
    }

    function CO(OO) {
      return bK.map((KO => KO(OO)))
    }
    const hO = bK.map((OO => new Set(XO.d.map(OO)).size));

    function DO(OO) {
      const KO = bK.map((KO => new Set(OO.map(KO)))),
        pO = KO.reduce(((OO, KO) => OO * KO.size), 1),
        XO = KO.every(((OO, KO) => 1 === OO.size || OO.size === hO[KO]));
      if (pO === OO.length && XO) return [bK.filter(((OO, pO) => 1 === KO[pO].size)).map((KO => KO(OO[0])))];
      let eO = null;
      for (let lO = 0; lO < bK.length; lO++) {
        if (1 === KO[lO].size) continue;
        const pO = MO(OO, bK[lO]).flatMap(DO);
        (null === eO || pO.length < eO.length) && (eO = pO)
      }
      return eO
    }

    function MO(OO, KO) {
      const pO = new Map;
      for (const bK of OO) {
        var XO;
        const OO = KO(bK);
        pO.set(OO, [...null !== (XO = pO.get(OO)) && void 0 !== XO ? XO : [], bK])
      }
      return [...pO.values()]
    }
  },
  5721: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO.h,
      d: () => bK,
      h: () => XO.q
    });
    var XO = pO(5709);
    const bK = [!1, !0].flatMap((OO => ["terrain", "liquid", "model"].map((KO => ({
      strict: OO,
      program: KO
    })))))
  },
  5791: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      forgetShaderPackActiveHint: () => EO,
      isOtherApiVersion: () => IO,
      isShaderPackActive: () => fO,
      isShaderPackChangePending: () => NO,
      markShaderPackChangePending: () => TO,
      pageShaderPackValidationVersion: () => yK,
      reconcileStoredShaderPackHint: () => uO,
      removeShaderPack: () => AO,
      replaceShaderPack: () => LO,
      saveShaderPack: () => VO,
      shaderPackNeedsCheck: () => gK,
      storedPackOutcome: () => dO,
      storedShaderPackFiles: () => aK,
      toStoredShaderPack: () => MO
    });
    var XO = pO(5709),
      bK = pO(5721),
      eO = pO(36),
      lO = pO(2668),
      vK = pO(5800),
      CO = pO(5763);
    const hO = "shaderPackChangePending";
    let DO = null;

    function MO(OO, KO, pO) {
      return {
        manifest: OO.manifest,
        files: (0, XO.v)(OO.files),
        validation: KO,
        ...pO && {
          listing: pO
        }
      }
    }

    function aK(OO) {
      return Object.keys(OO.files).map((KO => ({
        path: KO,
        source: OO.files[KO]
      })))
    }
    let oO = Promise.resolve();

    function FO(OO) {
      const KO = oO.then(OO);
      return oO = KO.catch((() => {})), KO
    }

    function VO(OO, KO) {
      return FO((() => QO(OO, KO)))
    }

    function LO(OO, KO, pO) {
      return FO((async () => JSON.stringify(await (0, vK.h)()) === JSON.stringify(OO) && (null === KO ? (await zK(), !0) : QO(KO, pO))))
    }
    async function QO(OO, KO) {
      const pO = await eO.d.setItem(vK.e, OO);
      return pO && jK(OO, KO), pO
    }
    async function zK() {
      await eO.d.removeItem(vK.e), eO.e.removeItem(lO.b)
    }

    function AO() {
      return FO(zK)
    }

    function fO(OO, KO) {
      return "active" === dO(OO, KO).kind
    }

    function dO(OO, KO) {
      var pO;
      return null === OO ? {
        kind: "none",
        reason: "nothingStored"
      } : IO(OO) ? {
        kind: "none",
        reason: "otherApiVersion"
      } : !1 !== (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.ok) || OO.validation.fromRecheck ? null === KO ? {
        kind: "none",
        reason: "noCompiler"
      } : gK(OO, KO) ? {
        kind: "blocked",
        messageKey: "shaderPack:failedUnchecked"
      } : OO.validation.ok ? {
        kind: "active"
      } : {
        kind: "blocked",
        messageKey: "shaderPack:failedValidation"
      } : {
        kind: "none",
        reason: "failedWhenLoaded"
      }
    }

    function TO() {
      eO.h.setItem(hO, performance.timeOrigin)
    }

    function NO() {
      return eO.h.getItem(hO) === performance.timeOrigin
    }

    function IO(OO) {
      return !(0, bK.h)(OO.manifest.apiVersion)
    }

    function yK(OO) {
      return DO ??= OO.sKO((0, CO.shaderPackTextures)()), DO
    }

    function gK(OO, KO) {
      var pO;
      return (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.headerVersion) !== yK(KO)
    }

    function uO(OO) {
      return FO((async () => {
        jK(await (0, vK.h)(!0), OO)
      }))
    }

    function EO() {
      return FO((async () => {
        eO.e.removeItem(lO.b)
      }))
    }

    function jK(OO, KO) {
      fO(OO, KO) ? eO.e.setItem(lO.b, !0) : eO.e.removeItem(lO.b)
    }
  },
  5763: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      loadShaderPackTextures: () => lO,
      shaderPackTextures: () => vK
    });
    var XO = pO(5709);
    let bK = null,
      eO = null;

    function lO() {
      return eO ??= Promise.all([pO.e(62), pO.e(182)]).then((() => pO(38591))).then((OO => {
        let {
          FORMER_BLOCK_IMAGE_NAMES: KO,
          textureNameToIndex: pO,
          textureAnimationData: eO
        } = OO;
        return bK ??= (0, XO.k)(pO, eO, KO), bK
      })), eO
    }

    function vK() {
      if (null === bK) throw new Error("Shader pack textures read before loadShaderPackTextures");
      return bK
    }
  },
  5786: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => CO,
      f: () => vK
    });
    var XO = pO(5791),
      bK = pO(5763),
      eO = pO(115);
    const lO = 100;
    async function vK(OO, KO) {
      var pO;
      let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null !== (pO = navigator.gpu) && void 0 !== pO ? pO : null;
      const lO = OO.GlO(KO, (0, bK.shaderPackTextures)());
      if (lO.errors.length > 0) return hO(OO, lO.errors, lO.offInStrict);
      const vK = await async function(OO) {
        if (!OO) return null;
        try {
          const KO = await (0, eO.m)(OO);
          return KO ? await KO.requestDevice() : null
        } catch (KO) {
          return console.error("Couldn't get a WebGPU device to validate the shader pack.", KO), null
        }
      }(XO);
      if (!vK) return null;
      let CO = !1;
      vK.lost.then((() => {
        CO = !0
      }));
      try {
        const KO = await Promise.all(lO.validationModules.map((KO => async function(OO, KO, pO) {
          KO.pushErrorScope("validation");
          const XO = KO.createShaderModule({
              code: pO.code
            }),
            bK = KO.popErrorScope(),
            {
              messages: eO
            } = await XO.getCompilationInfo(),
            lO = eO.filter((OO => "error" === OO.type)).map((KO => OO.mapValidationMessage(pO, KO))),
            vK = await bK;
          vK && 0 === lO.length && lO.push({
            file: null,
            line: 0,
            message: vK.message,
            variants: [pO.key]
          });
          return lO
        }(OO, vK, KO))));
        return CO ? null : hO(OO, OO.JhO(KO.flat()), lO.offInStrict)
      } catch (DO) {
        return console.error("Couldn't validate the shader pack on WebGPU.", DO), null
      } finally {
        vK.destroy()
      }
    }
    async function CO(OO, KO) {
      var pO;
      if (!(0, XO.shaderPackNeedsCheck)(OO, KO) || (0, XO.isOtherApiVersion)(OO)) return OO;
      const bK = await vK(KO, (0, XO.storedShaderPackFiles)(OO));
      if (!bK) return OO;
      const eO = !1 === (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.ok) && !OO.validation.fromRecheck,
        lO = {
          ...OO,
          validation: eO ? bK : {
            ...bK,
            fromRecheck: !0
          }
        };
      return await (0, XO.replaceShaderPack)(OO, lO, KO) || console.warn("Didn't save the shader pack's validation result: the stored pack changed or couldn't be written"), lO
    }

    function hO(OO, KO, pO) {
      return {
        headerVersion: (0, XO.pageShaderPackValidationVersion)(OO),
        ok: 0 === KO.length,
        errors: KO.slice(0, lO),
        moreErrors: Math.max(0, KO.length - lO),
        offInStrict: pO
      }
    }
  },
  5709: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      f: () => eO,
      h: () => XO,
      k: () => FO,
      m: () => DO,
      q: () => bK,
      t: () => CO,
      v: () => hO,
      w: () => MO
    });
    const XO = 5;

    function bK(OO) {
      return OO === XO
    }
    const eO = 262144,
      lO = 256,
      vK = 256;

    function CO(OO) {
      if ("object" !== typeof OO || null === OO || Array.isArray(OO)) return "The pack has no files.";
      const KO = [];
      for (const [pO, XO] of Object.entries(OO)) {
        if ("string" !== typeof XO) return `${pO} isn't text.`;
        KO.push({
          path: pO,
          source: XO
        })
      }
      return KO.sort(((OO, KO) => DO(OO.path, KO.path))),
        function(OO) {
          if (0 === OO.length) return "The pack has no .wgsl files.";
          if (OO.length > lO) return `The pack has more than ${lO} .wgsl files.`;
          const KO = new Set;
          for (const {
              path: pO
            }
            of OO) {
            const OO = aK(pO);
            if (null !== OO) return OO;
            if (KO.has(pO)) return `The pack has two files at ${pO}.`;
            KO.add(pO)
          }
          return MO(OO) > eO ? `The pack's .wgsl files are over ${eO/1024} KB in total.` : null
        }(KO) ?? KO
    }

    function hO(OO) {
      const KO = {};
      for (const pO of OO) KO[pO.path] = pO.source;
      return KO
    }

    function DO(OO, KO) {
      return OO < KO ? -1 : OO > KO ? 1 : 0
    }

    function MO(OO) {
      const KO = new TextEncoder;
      let pO = 0;
      for (const {
          source: XO
        }
        of OO) pO += KO.encode(XO).byteLength;
      return pO
    }

    function aK(OO) {
      if (!OO.toLowerCase().endsWith(".wgsl")) return `${OO} isn't a .wgsl file.`;
      if (OO.length > vK) return `A file path is over ${vK} characters.`;
      if (OO.includes("\\") || /[\u0000-\u001f]/.test(OO)) return `${OO} isn't a valid file path.`;
      return OO.split("/").some((OO => "" === OO || "." === OO || ".." === OO)) ? `${OO} isn't a valid file path.` : null
    }
    const oO = /^(.*)\[rot\[([1-4])$/;

    function FO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new Map;
      const XO = new Map;
      KO.forEach(((OO, KO) => {
        let {
          numAnimStates: pO,
          animStartIdx: bK
        } = OO;
        for (let eO = 1; eO < pO; eO++) XO.set(bK + eO - 1, KO)
      }));
      const bK = Object.entries(OO),
        eO = new Map;
      for (const [VO, LO] of bK) {
        const OO = oO.exec(VO);
        "1" === OO?.[2] && eO.set(OO[1], LO + 1)
      }
      const lO = OO => {
          const KO = oO.exec(OO);
          return KO && eO.has(KO[1]) ? {
            root: KO[1],
            rotation: Number(KO[2]) - 1
          } : null
        },
        vK = new Set(bK.map((OO => {
          let [KO] = OO;
          return lO(KO)?.root ?? KO
        }))),
        CO = (OO, pO) => {
          const XO = OO.replace(/_?0$/, "");
          return (KO[pO]?.numAnimStates ?? 0) > 1 && !vK.has(XO) ? XO : OO
        },
        hO = new Map;
      for (const [oO, VO] of bK) hO.set(VO, CO(lO(oO)?.root ?? oO, VO));
      const DO = bK.reduce(((OO, KO) => {
          let [, pO] = KO;
          return Math.max(OO, pO + 1)
        }), 0),
        MO = Array.from({
          length: DO
        }, ((OO, KO) => ({
          id: KO + 1,
          rotation: 0
        }))),
        aK = new Map,
        FO = new Map;
      for (const [oO, VO] of bK) {
        const OO = lO(oO),
          KO = XO.get(VO);
        if (void 0 !== KO) {
          const pO = hO.get(KO);
          FO.set(oO, {
            name: oO,
            texture: pO,
            kind: "frame"
          }), OO && !FO.has(OO.root) && FO.set(OO.root, {
            name: OO.root,
            texture: pO,
            kind: "frame"
          });
          continue
        }
        const pO = hO.get(VO),
          bK = OO?.root ?? oO;
        if (pO !== bK && FO.set(bK, {
            name: bK,
            texture: pO,
            kind: "frame"
          }), OO) {
          const KO = eO.get(OO.root);
          MO[VO] = {
            id: KO,
            rotation: OO.rotation
          }, aK.set(pO, KO), FO.set(oO, {
            name: oO,
            texture: pO,
            kind: "rotation"
          })
        } else aK.set(pO, VO + 1)
      }
      for (const oO of aK.keys()) FO.delete(oO);
      for (const [oO, VO] of pO) {
        const OO = aK.get(VO);
        void 0 === OO || aK.has(oO) || (aK.set(oO, OO), FO.delete(oO))
      }
      return {
        named: [...aK].sort(((OO, KO) => {
          let [pO] = OO, [XO] = KO;
          return pO < XO ? -1 : pO > XO ? 1 : 0
        })).map((OO => {
          let [KO, pO] = OO;
          return {
            name: KO,
            id: pO
          }
        })),
        aliases: [...FO.values()],
        layers: MO
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);