export const id = 178;
export const ids = [178];
export const modules = {
  8263: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    const XO = new Set(["chunkBorders"])
  },
  8301: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK
    });
    var XO = pO(171),
      bK = pO(1531),
      eO = pO(36);
    const lO = 2;

    function vK() {
      let OO = CO("chunkHorizAddDist", XO.h.defaultChunkHorizAddDistance),
        KO = CO("chunkVertAddDist", XO.h.defaultChunkVertAddDistance);
      return OO = (0, bK.g)(OO, lO, XO.h.maxChunkHorizAddDistance), KO = (0, bK.g)(KO, lO, XO.h.maxChunkVertAddDistance), [OO, KO]
    }

    function CO(OO, KO) {
      const pO = eO.e.getItem(OO),
        XO = "number" === typeof pO || "string" === typeof pO ? Number(pO) : Number.NaN;
      return Number.isFinite(XO) ? XO : KO
    }
  },
  8284: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK,
      g: () => lO
    });
    var XO = pO(36);
    const bK = new Map,
      eO = OO => `${OO}Chosen`;

    function lO(OO) {
      bK.set(OO, !0), XO.e.setItem(eO(OO), !0)
    }

    function vK(OO) {
      let KO = bK.get(OO);
      return void 0 === KO && (KO = !0 === XO.e.getItem(eO(OO)), bK.set(OO, KO)), KO
    }
  },
  8296: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => cK,
      d: () => AK,
      h: () => zp,
      k: () => dK,
      n: () => eK,
      r: () => vp,
      s: () => hK,
      u: () => fK,
      v: () => CK
    });
    var XO = pO(22),
      bK = pO(215),
      eO = pO(94),
      lO = pO(1441),
      vK = pO(8284),
      CO = pO(2265),
      hO = pO(2271),
      DO = pO(36);
    const {
      windows: MO,
      target: aK,
      stepDown: oO,
      stepUp: FO,
      noGain: VO
    } = hO.c, LO = 1e3 / 60 * 1.08, QO = 1e3 / 55, zK = 1e3 / 45, AO = 1e3 / 30 * .92, fO = 1e3 / 30 * 1.08;
    class dO {
      constructor() {
        this.lastMs = -1, this.runBand = -1, this.runLength = 0, this.votes60 = 0, this.votesMid = 0, this.sumMidMs = 0, this.votes30 = 0
      }
      frame(OO) {
        const KO = OO - this.lastMs;
        this.lastMs = OO;
        const pO = function(OO) {
          if (OO <= 0 || OO > 100) return -1;
          if (OO <= LO) return 0;
          if (OO >= QO && OO <= zK) return 1;
          return OO >= AO && OO <= fO ? 2 : -1
        }(KO);
        pO !== this.runBand && (this.runBand = pO, this.runLength = 0), pO < 0 || ++this.runLength < 3 || (0 === pO ? this.votes60++ : 1 === pO ? (this.votesMid++, this.sumMidMs += KO) : this.votes30++)
      }
      hz() {
        return this.votes60 >= 60 ? 60 : this.votesMid >= 60 ? 1e3 * this.votesMid / this.sumMidMs : this.votes30 >= 60 ? 30 : 60
      }
    }
    const TO = MO.windowMs,
      NO = MO.settleMs,
      IO = MO.graceMs,
      yK = MO.minIntervals,
      gK = 1e3 * yK / TO,
      uO = VO.backoffMs,
      EO = VO.maxMs;
    class jK {
      constructor(OO, KO) {
        let {
          lowest: pO,
          startStep: XO = 0,
          noGain: bK = null,
          upWait: eO = null
        } = KO;
        this.hooks = OO, this.step = void 0, this.lowest = void 0, this.phase = {
          kind: "watch"
        }, this.noGain = void 0, this.downUntilMs = void 0, this.downBackoffMs = void 0, this.upFailures = void 0, this.upUntilMs = void 0, this.climbing = void 0, this.climbed = null, this.cleanRun = 0, this.dropRun = 0, this.dropRunMasked = !1, this.dropRunFpsSum = 0, this.refresh = new dO, this.wasMeasuring = !1, this.lastFrameMs = -1, this.resizedMs = Number.NEGATIVE_INFINITY, this.quietUntilMs = 0, this.graceUntilMs = 0, this.windowStartMs = -1, this.lastDrawnMs = 0, this.windowIntervals = 0, this.windowHeld = 0, this.windowMaxIntervalMs = 0, this.windowMasked = !1, this.slowStartMs = -1, this.slowIntervals = 0, this.log = [], this.lastTargetFps = aK.maxFps, this.lowest = pO, this.step = Math.min(XO, pO), this.noGain = bK, this.climbing = this.step > 0;
        const lO = pO + 1;
        this.downUntilMs = new Array(lO).fill(0), this.downBackoffMs = new Array(lO).fill(0), this.upFailures = new Array(lO).fill(0), this.upUntilMs = new Array(lO).fill(0), null !== eO && eO.step >= 0 && eO.step < lO && (this.upUntilMs[eO.step] = eO.untilMs)
      }
      currentStep() {
        return this.step
      }
      frame(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        if (this.refresh.frame(OO), !pO) return void this.DX(OO);
        const bK = OO - this.lastFrameMs,
          eO = this.resizeStall(OO);
        if (bK > 2e3 && !eO && this.DX(this.lastFrameMs), !this.wasMeasuring) return this.wasMeasuring = !0, this.lastFrameMs = OO, this.quietUntilMs = Math.max(this.quietUntilMs, OO + IO), this.graceUntilMs = OO + IO, this.windowStartMs = -1, void(this.slowStartMs = -1);
        bK > 500 && (this.hitch(OO), eO && (this.slowStartMs = -1)), this.lastFrameMs = OO, OO >= this.quietUntilMs && this.countWindow(OO, KO, XO) || KO && OO >= this.graceUntilMs && this.countSlow(OO)
      }
      countWindow(OO, KO, pO) {
        if (this.windowStartMs < 0) return !!KO && (this.windowStartMs = OO, this.lastDrawnMs = OO, this.windowIntervals = 0, this.windowHeld = 0, this.windowMaxIntervalMs = 0, this.windowMasked = pO, !1);
        if (this.windowMasked ||= pO, !KO) return this.windowHeld++, !1;
        this.windowIntervals++, this.windowMaxIntervalMs = Math.max(this.windowMaxIntervalMs, OO - this.lastDrawnMs), this.lastDrawnMs = OO;
        const XO = OO - this.windowStartMs;
        if (XO < TO) return !1;
        const bK = this.windowIntervals,
          eO = 1e3 * bK / XO,
          lO = this.windowHeld,
          vK = this.windowMaxIntervalMs,
          CO = this.windowMasked;
        if (this.windowStartMs = -1, bK < yK) return !1;
        this.slowStartMs = -1;
        const hO = this.targetFps(),
          DO = eO >= hO * aK.cleanShare && vK <= aK.cleanMaxIntervalMs && (0 === lO || eO >= hO);
        return this.decide(eO, DO, eO < hO * aK.dropShare, CO, OO), !0
      }
      targetFps() {
        return this.lastTargetFps = Math.min(aK.maxFps, this.refresh.hz()), this.lastTargetFps
      }
      countSlow(OO) {
        if (this.slowStartMs < 0) return this.slowStartMs = OO, void(this.slowIntervals = 0);
        this.slowIntervals++;
        const KO = OO - this.slowStartMs;
        if (KO < 1e4) return;
        const pO = 1e3 * this.slowIntervals / KO;
        this.slowStartMs = -1, this.countSlow(OO), pO < gK && (this.windowStartMs = -1, this.decide(pO, !1, !0, !1, OO))
      }
      resizeStall(OO) {
        return this.lastFrameMs - this.resizedMs <= NO && OO - this.lastFrameMs <= 15e3
      }
      resized(OO) {
        this.resizedMs = OO, this.hitch(OO)
      }
      hidden() {
        this.DX(this.lastFrameMs)
      }
      DX(OO) {
        this.wasMeasuring && (this.wasMeasuring = !1, this.left(OO))
      }
      hitch(OO) {
        this.windowStartMs = -1, this.quietUntilMs = Math.max(this.quietUntilMs, OO + NO)
      }
      left(OO) {
        this.windowStartMs = -1, this.slowStartMs = -1, this.cleanRun = 0, this.resetDropRun();
        const KO = this.phase;
        "watch" !== KO.kind && (this.phase = {
          kind: "watch"
        }, "down" === KO.kind && (this.downUntilMs[KO.from] = Math.max(this.downUntilMs[KO.from], OO + uO)), this.setStep(KO.from, 0, OO, "left"), "up" === KO.kind && (this.climbed = KO.fromClimbed))
      }
      decide(OO, KO, pO, XO, bK) {
        const eO = this.phase;
        switch (eO.kind) {
          case "watch":
            return void this.watch(OO, KO, pO, XO, bK);
          case "down":
            if (eO.judged++, eO.fpsSum += OO, eO.dropped ||= pO, eO.judged < oO.judgeWindows) return;
            return void(!eO.dropped || eO.fpsSum / eO.judged >= eO.fromFps * oO.keepGain ? this.keepDown(eO.from, eO.fpsSum / eO.judged, bK) : this.noGainFrom(eO.from, eO.fromFps, bK));
          case "up":
            return KO ? void(++eO.judged >= FO.trialWindows && (this.watchAt(this.step), this.climbed = {
              from: eO.from,
              heldWindows: 0,
              below: eO.fromClimbed
            }, this.record(bK, OO, "up_kept"))) : (XO ? (this.watchAt(eO.from), this.setStep(eO.from, OO, bK, "spoiled")) : this.failUp(this.step, eO.from, OO, bK), void(this.climbed = eO.fromClimbed))
        }
      }
      watch(OO, KO, pO, XO, bK) {
        const eO = this.climbed;
        if (null !== eO && !pO && !XO && ++eO.heldWindows >= FO.heldWindows && (this.climbed = null, this.record(bK, OO, "JK"), this.hooks.JK(this.step)), pO ? (this.dropRun++, this.dropRunFpsSum += OO, this.dropRunMasked ||= XO) : this.resetDropRun(), XO && KO || (this.cleanRun = KO ? this.cleanRun + 1 : 0), this.dropRun >= (this.dropRunMasked ? oO.maskedWindows : oO.dropWindows)) {
          const KO = this.dropRunFpsSum / this.dropRun;
          this.resetDropRun();
          const pO = this.climbed;
          return void(null !== pO ? (this.failUp(this.step, pO.from, OO, bK), this.climbed = pO.below) : this.step < this.lowest && this.downAllowed(bK) && (this.climbing = !1, this.phase = {
            kind: "down",
            from: this.step,
            fromFps: KO,
            judged: 0,
            fpsSum: 0,
            dropped: !1
          }, this.setStep(this.step + 1, OO, bK, "down")))
        }
        const lO = this.step - 1;
        lO >= 0 && this.cleanRun >= (this.climbing ? FO.climbWindows : FO.cleanWindows) && this.upAllowed(lO, bK) && (this.phase = {
          kind: "up",
          from: this.step,
          judged: 0,
          fromClimbed: this.climbed
        }, this.setStep(lO, OO, bK, "up"))
      }
      downAllowed(OO) {
        return !(0 === this.step && null !== this.noGain && OO < this.noGain.untilMs) && OO >= this.downUntilMs[this.step]
      }
      upAllowed(OO, KO) {
        return this.upFailures[OO] <= FO.failWaitsMs.length && KO >= this.upUntilMs[OO]
      }
      keepDown(OO, KO, pO) {
        this.watchAt(this.step), this.downBackoffMs[OO] = 0, this.record(pO, KO, "down_kept"), 0 === OO && null !== this.noGain && (this.noGain = null, this.hooks.noGain(null)), this.hooks.Sp(this.step)
      }
      noGainFrom(OO, KO, pO) {
        var XO, bK;
        const eO = 0 === OO ? null !== (XO = null === (bK = this.noGain) || void 0 === bK ? void 0 : bK.backoffMs) && void 0 !== XO ? XO : 0 : this.downBackoffMs[OO],
          lO = 0 === eO ? uO : Math.min(2 * eO, EO);
        this.downBackoffMs[OO] = lO, this.downUntilMs[OO] = pO + lO, 0 === OO && (this.noGain = {
          untilMs: pO + lO,
          backoffMs: lO
        }, this.hooks.noGain(this.noGain)), this.watchAt(OO), this.setStep(OO, KO, pO, "no_gain")
      }
      failUp(OO, KO, pO, XO) {
        this.climbing = !1;
        const bK = ++this.upFailures[OO];
        this.upUntilMs[OO] = bK <= FO.failWaitsMs.length ? XO + FO.failWaitsMs[bK - 1] : Number.POSITIVE_INFINITY, this.watchAt(KO), this.setStep(KO, pO, XO, "up_failed"), this.hooks.upFailed(OO)
      }
      watchAt(OO) {
        this.phase = {
          kind: "watch"
        }, this.climbed = OO === this.step ? this.climbed : null, this.cleanRun = 0, this.resetDropRun()
      }
      resetDropRun() {
        this.dropRun = 0, this.dropRunFpsSum = 0, this.dropRunMasked = !1
      }
      setStep(OO, KO, pO, XO) {
        const bK = OO !== this.step;
        bK && (this.climbed = null), this.step = OO, this.record(pO, KO, XO), bK && (this.slowStartMs = -1, this.resized(pO), this.hooks.changed(OO))
      }
      record(OO, KO, pO) {
        64 === this.log.length && this.log.shift(), this.log.push({
          atMs: OO,
          step: this.step,
          fps: Math.round(10 * KO) / 10,
          targetFps: Math.round(10 * this.lastTargetFps) / 10,
          why: pO
        })
      }
    }
    var YO = pO(8298),
      wO = pO(2407);
    const iK = "autoGraphics",
      rK = 6048e5,
      PO = "startScale";

    function mK() {
      return (0, CO.J)(XO.d.get("clientEscMenuOptions").pixelScale) * (0, CO.k)()
    }

    function sO() {
      return (0, CO.q)(mK())
    }

    function HO() {
      const OO = DO.e.getItem(iK);
      return "object" !== typeof OO || null === OO || "string" !== typeof OO.gpu ? null : OO
    }

    function RO(OO) {
      return {
        untilEpochMs: Date.now() + (OO.untilMs - performance.now()),
        backoffMs: OO.backoffMs
      }
    }

    function SO(OO) {
      return OO ? {
        untilMs: performance.now() + (OO.untilEpochMs - Date.now()),
        backoffMs: OO.backoffMs
      } : null
    }
    let JO = null;

    function cK() {
      if (null === JO) {
        const OO = new URLSearchParams(window.location.search).get("msaa");
        JO = XO.d.get("clientEscMenuOptions").antiAliasing && ("0" === OO || "1" !== OO && (!(0, vK.c)("antiAliasing") && (0, wO.b)() || function() {
          var OO;
          return BO(null === (OO = HO()) || void 0 === OO ? void 0 : OO.msaaOffAt) && !(0, wO.h)() && ZO() && qK()
        }()))
      }
      return JO
    }

    function BO(OO) {
      const KO = "number" === typeof OO ? Date.now() - OO : -1;
      return KO >= 0 && KO < rK
    }

    function ZO() {
      return XO.d.get("clientEscMenuOptions").antiAliasing && (0, bK.j)() && !(0, vK.c)("antiAliasing")
    }
    let GO = null;

    function qK() {
      return GO ??= (0, eO.getDeviceDefaultPixelScale)(), xK(GO)
    }

    function xK(OO) {
      const KO = XO.d.get("clientEscMenuOptions");
      return KO.pixelSmoothing && !(0, vK.c)("pixelScale") && KO.pixelScale === OO
    }
    let nO = null,
      WO = 0;

    function tK() {
      if (null === nO || WO !== mK()) {
        var OO;
        WO = mK();
        const KO = Number(null !== (OO = new URLSearchParams(window.location.search).get(PO)) && void 0 !== OO ? OO : ""),
          pO = sO();
        if (KO > 0 && KO <= 1) nO = (0, CO.B)(pO, pO[0] / KO);
        else {
          const OO = HO(),
            KO = (0, CO.B)(pO, (0, CO.E)(mK())),
            XO = !(0, wO.h)() && BO(null === OO || void 0 === OO ? void 0 : OO.heldAt) && (null === OO || void 0 === OO ? void 0 : OO.heldTarget) === mK() ? null === OO || void 0 === OO ? void 0 : OO.heldN : void 0;
          nO = "number" === typeof XO ? Math.min(KO, (0, CO.B)(pO, XO)) : KO
        }
      }
      return nO
    }

    function kK(OO, KO) {
      var pO;
      const XO = KO.indexOf(null !== (pO = OO.failedUpN) && void 0 !== pO ? pO : -1);
      return XO >= 0 && BO(OO.failedUpAt) ? {
        step: XO,
        untilMs: performance.now() + hO.c.stepUp.failWaitsMs[0]
      } : null
    }
    let UO = null,
      OK = !1,
      KK = "";
    const pK = new Set;

    function XK() {
      for (const OO of pK) OO()
    }

    function bp() {
      return OK ? null : (oK(), null === UO ? (null !== GO || null !== (0, eO.peekGpuVendor)() ? qK() : xK(1)) ? tK() : null : qK() ? UO.currentStep() : null)
    }

    function eK() {
      const OO = bp();
      if (null === OO) return null;
      const KO = sO(),
        pO = KO[Math.min(OO, KO.length - 1)];
      return pO === lK() ? null : pO
    }

    function lK() {
      return (0, CO.y)(XO.d.get("clientEscMenuOptions").pixelScale, (0, CO.k)())
    }

    function vp() {
      return null !== UO && null !== eK()
    }

    function CK(OO) {
      return pK.add(OO), () => {
        pK.delete(OO)
      }
    }

    function hK(OO, KO, pO) {
      var XO;
      if (null !== UO || OK || (0, wO.h)()) return;
      DK = cK();
      const bK = (0, YO.b)(OO, KO, pO);
      null !== bK && (0, wO.k)(bK.vendor), KK = `${OO}:${(null===bK||void 0===bK?void 0:bK.renderer)||(null===bK||void 0===bK?void 0:bK.vendor)||""}`, (null === (XO = HO()) || void 0 === XO ? void 0 : XO.gpu) !== KK && (DO.e.setItem(iK, {
        gpu: KK
      }), nO = null), ap(), document.addEventListener("visibilitychange", (() => {
        if (document.hidden) try {
          var OO;
          null === (OO = UO) || void 0 === OO || OO.hidden()
        } catch (KO) {
          fK(), console.error("The quality steps stopped", KO)
        }
      }))
    }
    let DK = !1,
      MK = 0;

    function ap() {
      var OO;
      const KO = null !== (OO = HO()) && void 0 !== OO ? OO : {
          gpu: KK
        },
        pO = sO();
      MK = mK(), UO = new jK({
          changed: XK,
          Sp: OO => {
            FK(sO()[OO] > lK() && ZO() ? {
              msaaOffAt: Date.now(),
              heldN: void 0
            } : {
              heldN: void 0
            })
          },
          JK: OO => {
            var KO;
            const pO = sO()[OO],
              XO = {
                heldN: pO,
                heldAt: Date.now(),
                heldTarget: mK()
              };
            (null === (KO = HO()) || void 0 === KO ? void 0 : KO.failedUpN) === pO && (XO.failedUpN = void 0), FK(pO > lK() || DK ? XO : {
              ...XO,
              msaaOffAt: void 0
            })
          },
          upFailed: OO => {
            FK({
              failedUpN: sO()[OO],
              failedUpAt: Date.now()
            })
          },
          noGain: OO => {
            FK({
              noGain: null === OO ? void 0 : RO(OO)
            })
          }
        }, {
          lowest: pO.length - 1,
          startStep: tK(),
          noGain: SO(KO.noGain),
          upWait: kK(KO, pO)
        }),
        function(OO) {
          const KO = {
            get step() {
              return OO.currentStep()
            },
            get n() {
              var OO;
              return null !== (OO = eK()) && void 0 !== OO ? OO : lK()
            },
            get scale() {
              var OO;
              return sO()[0] / (null !== (OO = eK()) && void 0 !== OO ? OO : lK())
            },
            get msaaOff() {
              return cK()
            },
            log: OO.log
          };
          Object.defineProperty(window, "__qualitySteps", {
            value: KO,
            configurable: !0
          })
        }(UO), XK()
    }

    function oK() {
      null !== UO && mK() !== MK && (nO = null, ap())
    }

    function FK(OO) {
      DO.e.setItem(iK, {
        ...HO(),
        ...OO,
        gpu: KK
      })
    }
    let VK = 0,
      LK = 0,
      QK = !1;

    function zp() {
      VK++
    }

    function AK(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
      oK(), null !== UO && (OO - LK >= 1e3 && (QK = VK > hO.c.sceneChange.meshesPerSecond, VK = 0, LK = OO), UO.frame(OO, KO, pO && !document.hidden && qK(), QK || XO > 0 || (0, lO.i)()))
    }

    function fK() {
      if (!OK) {
        OK = !0, null !== UO && (UO = null, FK({
          msaaOffAt: void 0,
          noGain: void 0
        }));
        try {
          XK()
        } catch (OO) {
          console.error("The quality steps' resize to the player's n failed", OO)
        }
      }
    }

    function dK() {
      var OO;
      null === (OO = UO) || void 0 === OO || OO.resized(performance.now())
    }
  },
  8298: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO
    });
    var XO = pO(94),
      bK = pO(127);

    function eO(OO, KO, pO) {
      if ("webgpu" === OO) return pO ? ((0, XO.seedGpuVendor)(pO), {
        vendor: pO,
        renderer: ""
      }) : null;
      try {
        const pO = "webgl" === OO ? KO.getContext("webgl2") : KO.getContext("webgl"),
          eO = null === pO || void 0 === pO ? void 0 : pO.getExtension("WEBGL_debug_renderer_info");
        if (pO && eO) {
          const OO = String(pO.getParameter(eO.UNMASKED_VENDOR_WEBGL)),
            KO = String(pO.getParameter(eO.UNMASKED_RENDERER_WEBGL));
          return (0, XO.seedGpuVendor)(OO), (0, bK.t)(OO, KO), {
            vendor: OO,
            renderer: KO
          }
        }
        pO && (0, bK.t)(String(pO.getParameter(pO.VENDOR)), String(pO.getParameter(pO.RENDERER)))
      } catch {}
      return null
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);