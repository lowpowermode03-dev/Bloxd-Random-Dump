export const id = 128;
export const ids = [128];
export const modules = {
  39759: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      compilePagePack: () => hO,
      prefetchCompiler: () => vK,
      reconcileHint: () => CO
    });
    var XO = pO(5739),
      bK = pO(5791),
      eO = pO(5763),
      lO = pO(5786);

    function vK() {
      (0, XO.loadPageShaderPackCompiler)()
    }
    async function CO() {
      const OO = await (0, XO.loadPageShaderPackCompiler)();
      await (OO ? (0, bK.reconcileStoredShaderPackHint)(OO) : (0, bK.forgetShaderPackActiveHint)())
    }
    async function hO(OO) {
      const KO = await (0, XO.loadPageShaderPackCompiler)();
      if (!KO) return {
        status: "none"
      };
      const pO = await (0, lO.e)(OO, KO),
        vK = (0, bK.storedPackOutcome)(pO, KO);
      if ("none" === vK.kind) return {
        status: "none"
      };
      const CO = KO.GlO((0, bK.storedShaderPackFiles)(pO), (0, eO.shaderPackTextures)());
      if ("blocked" === vK.kind) return {
        status: "blocked",
        messageKey: vK.messageKey,
        variants: 0 === CO.errors.length ? CO.variants : null
      };
      if (CO.errors.length > 0) return console.error("Shader pack failed to compile after passing validation", CO.errors), {
        status: "none"
      };
      const {
        name: hO,
        keepCircleShadows: DO
      } = pO.manifest;
      return {
        status: "active",
        pack: {
          name: hO,
          variants: CO.variants,
          keepCircleShadows: !0 === DO
        }
      }
    }
  },
  5791: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      forgetShaderPackActiveHint: () => EO,
      isOtherApiVersion: () => IO,
      isShaderPackActive: () => fO,
      isShaderPackChangePending: () => NO,
      markShaderPackChangePending: () => TO,
      pageShaderPackValidationVersion: () => yK,
      reconcileStoredShaderPackHint: () => uO,
      removeShaderPack: () => AO,
      replaceShaderPack: () => LO,
      saveShaderPack: () => VO,
      shaderPackNeedsCheck: () => gK,
      storedPackOutcome: () => dO,
      storedShaderPackFiles: () => aK,
      toStoredShaderPack: () => MO
    });
    var XO = pO(5709),
      bK = pO(5721),
      eO = pO(36),
      lO = pO(2668),
      vK = pO(5800),
      CO = pO(5763);
    const hO = "shaderPackChangePending";
    let DO = null;

    function MO(OO, KO, pO) {
      return {
        manifest: OO.manifest,
        files: (0, XO.v)(OO.files),
        validation: KO,
        ...pO && {
          listing: pO
        }
      }
    }

    function aK(OO) {
      return Object.keys(OO.files).map((KO => ({
        path: KO,
        source: OO.files[KO]
      })))
    }
    let oO = Promise.resolve();

    function FO(OO) {
      const KO = oO.then(OO);
      return oO = KO.catch((() => {})), KO
    }

    function VO(OO, KO) {
      return FO((() => QO(OO, KO)))
    }

    function LO(OO, KO, pO) {
      return FO((async () => JSON.stringify(await (0, vK.h)()) === JSON.stringify(OO) && (null === KO ? (await zK(), !0) : QO(KO, pO))))
    }
    async function QO(OO, KO) {
      const pO = await eO.d.setItem(vK.e, OO);
      return pO && jK(OO, KO), pO
    }
    async function zK() {
      await eO.d.removeItem(vK.e), eO.e.removeItem(lO.b)
    }

    function AO() {
      return FO(zK)
    }

    function fO(OO, KO) {
      return "active" === dO(OO, KO).kind
    }

    function dO(OO, KO) {
      var pO;
      return null === OO ? {
        kind: "none",
        reason: "nothingStored"
      } : IO(OO) ? {
        kind: "none",
        reason: "otherApiVersion"
      } : !1 !== (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.ok) || OO.validation.fromRecheck ? null === KO ? {
        kind: "none",
        reason: "noCompiler"
      } : gK(OO, KO) ? {
        kind: "blocked",
        messageKey: "shaderPack:failedUnchecked"
      } : OO.validation.ok ? {
        kind: "active"
      } : {
        kind: "blocked",
        messageKey: "shaderPack:failedValidation"
      } : {
        kind: "none",
        reason: "failedWhenLoaded"
      }
    }

    function TO() {
      eO.h.setItem(hO, performance.timeOrigin)
    }

    function NO() {
      return eO.h.getItem(hO) === performance.timeOrigin
    }

    function IO(OO) {
      return !(0, bK.h)(OO.manifest.apiVersion)
    }

    function yK(OO) {
      return DO ??= OO.sKO((0, CO.shaderPackTextures)()), DO
    }

    function gK(OO, KO) {
      var pO;
      return (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.headerVersion) !== yK(KO)
    }

    function uO(OO) {
      return FO((async () => {
        jK(await (0, vK.h)(!0), OO)
      }))
    }

    function EO() {
      return FO((async () => {
        eO.e.removeItem(lO.b)
      }))
    }

    function jK(OO, KO) {
      fO(OO, KO) ? eO.e.setItem(lO.b, !0) : eO.e.removeItem(lO.b)
    }
  },
  5786: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => CO,
      f: () => vK
    });
    var XO = pO(5791),
      bK = pO(5763),
      eO = pO(115);
    const lO = 100;
    async function vK(OO, KO) {
      var pO;
      let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null !== (pO = navigator.gpu) && void 0 !== pO ? pO : null;
      const lO = OO.GlO(KO, (0, bK.shaderPackTextures)());
      if (lO.errors.length > 0) return hO(OO, lO.errors, lO.offInStrict);
      const vK = await async function(OO) {
        if (!OO) return null;
        try {
          const KO = await (0, eO.m)(OO);
          return KO ? await KO.requestDevice() : null
        } catch (KO) {
          return console.error("Couldn't get a WebGPU device to validate the shader pack.", KO), null
        }
      }(XO);
      if (!vK) return null;
      let CO = !1;
      vK.lost.then((() => {
        CO = !0
      }));
      try {
        const KO = await Promise.all(lO.validationModules.map((KO => async function(OO, KO, pO) {
          KO.pushErrorScope("validation");
          const XO = KO.createShaderModule({
              code: pO.code
            }),
            bK = KO.popErrorScope(),
            {
              messages: eO
            } = await XO.getCompilationInfo(),
            lO = eO.filter((OO => "error" === OO.type)).map((KO => OO.mapValidationMessage(pO, KO))),
            vK = await bK;
          vK && 0 === lO.length && lO.push({
            file: null,
            line: 0,
            message: vK.message,
            variants: [pO.key]
          });
          return lO
        }(OO, vK, KO))));
        return CO ? null : hO(OO, OO.JhO(KO.flat()), lO.offInStrict)
      } catch (DO) {
        return console.error("Couldn't validate the shader pack on WebGPU.", DO), null
      } finally {
        vK.destroy()
      }
    }
    async function CO(OO, KO) {
      var pO;
      if (!(0, XO.shaderPackNeedsCheck)(OO, KO) || (0, XO.isOtherApiVersion)(OO)) return OO;
      const bK = await vK(KO, (0, XO.storedShaderPackFiles)(OO));
      if (!bK) return OO;
      const eO = !1 === (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.ok) && !OO.validation.fromRecheck,
        lO = {
          ...OO,
          validation: eO ? bK : {
            ...bK,
            fromRecheck: !0
          }
        };
      return await (0, XO.replaceShaderPack)(OO, lO, KO) || console.warn("Didn't save the shader pack's validation result: the stored pack changed or couldn't be written"), lO
    }

    function hO(OO, KO, pO) {
      return {
        headerVersion: (0, XO.pageShaderPackValidationVersion)(OO),
        ok: 0 === KO.length,
        errors: KO.slice(0, lO),
        moreErrors: Math.max(0, KO.length - lO),
        offInStrict: pO
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);