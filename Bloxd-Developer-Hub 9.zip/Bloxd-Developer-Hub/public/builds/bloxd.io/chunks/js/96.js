export const id = 96;
export const ids = [96, 117];
export const modules = {
  5703: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      ShaderPackPublishForm: () => AO
    });
    var XO = pO(63),
      bK = pO(5678),
      eO = pO(173),
      lO = pO(5709),
      vK = pO(933),
      CO = pO(1271),
      hO = pO(1475),
      DO = pO(1004),
      MO = pO(5711),
      aK = pO(5730),
      oO = pO(1329),
      FO = pO(1051),
      VO = pO(5739),
      LO = pO(5786),
      QO = pO(5674),
      zK = pO(976);

    function AO(OO) {
      var KO, pO, MO;
      let {
        existing: AO,
        onPublished: dO
      } = OO;
      const {
        t: NO
      } = (0, FO.D)(), {
        userContext: IO,
        isUserContextUpdating: yK
      } = (0, DO.d)(), [gK, uO] = (0, XO.useState)(null), [EO, jK] = (0, XO.useState)(0), [YO, wO] = (0, XO.useState)(null !== (KO = null === AO || void 0 === AO ? void 0 : AO.name) && void 0 !== KO ? KO : ""), iK = (0, XO.useRef)(YO), rK = (0, XO.useRef)(""), PO = OO => {
        iK.current = OO, wO(OO)
      }, [mK, sO] = (0, XO.useState)(null !== (pO = null === AO || void 0 === AO ? void 0 : AO.description) && void 0 !== pO ? pO : ""), HO = (0, XO.useRef)(mK), RO = (0, XO.useRef)(""), SO = OO => {
        HO.current = OO, sO(OO)
      }, [JO, cK] = (0, XO.useState)(!1), {
        loading: BO,
        error: ZO,
        setError: GO,
        onFiles: qK
      } = (0, aK.h)((async OO => {
        const KO = await (0, VO.loadPageShaderPackCompiler)();
        if (!KO) return void GO(NO("shaderPack:compilerUnavailable"));
        const pO = await (0, LO.f)(KO, OO.files);
        if (uO({
            pack: OO,
            validation: pO,
            sourceBytes: (0, lO.w)(OO.files)
          }), !AO) {
          var XO;
          if ("" !== iK.current.trim() && iK.current !== rK.current || (rK.current = (0, bK.H)(OO.manifest.name.trim(), bK.w), PO(rK.current)), "" === HO.current.trim() || HO.current === RO.current) RO.current = (0, bK.H)((null !== (XO = OO.manifest.description) && void 0 !== XO ? XO : "").trim(), bK.s), SO(RO.current);
          jK((OO => OO + 1))
        }
      })), xK = !yK && !IO.isLoggedIn() && !eO.e.offlineMode, nO = YO.trim(), WO = nO.length < bK.x, tK = null !== gK && !1 !== (null === (MO = gK.validation) || void 0 === MO ? void 0 : MO.ok) && !BO && !WO && !xK && !yK;
      return (0, zK.jsxs)("div", {
        className: "ShaderPackPublishForm",
        children: [(0, zK.jsx)("p", {
          className: "ShaderPackPublishIntro",
          children: AO ? NO("shaderPackListing:uploadIntro", {
            minutes: String(bK.B / 6e4)
          }) : NO("shaderPackListing:publishIntro")
        }), (0, zK.jsx)(TO, {}), xK && (0, zK.jsx)("div", {
          className: "ShaderPackPublishNote Warning",
          children: NO("shaderPackListing:publishNeedsLogin")
        }), (0, zK.jsx)(aK.e, {
          busy: BO,
          disabled: BO || JO,
          onFiles: OO => {
            uO(null), qK(OO)
          }
        }), gK && (0, zK.jsxs)("div", {
          className: "ShaderPackPublishSummary",
          children: [(0, zK.jsx)("div", {
            className: "ShaderPackPublishPackName",
            children: gK.pack.manifest.name
          }), (0, zK.jsxs)("div", {
            className: "ShaderPackPublishPackSize",
            children: [NO("shaderPackListing:sizeValue", {
              kilobytes: String((0, QO.O)(gK.sourceBytes))
            }), " \xb7", " ", NO("shaderPackListing:filesValue", {
              files: String(gK.pack.files.length)
            })]
          }), (0, zK.jsx)(fO, {
            picked: gK
          })]
        }), !AO && (0, zK.jsxs)(zK.Fragment, {
          children: [(0, zK.jsxs)("label", {
            className: "ShaderPackPublishField",
            children: [(0, zK.jsx)("span", {
              children: NO("general:name")
            }), (0, zK.jsx)(hO.e, {
              className: "ShaderPackPublishInput",
              defaultValue: YO,
              maxLength: bK.w,
              onValueChange: PO
            }, EO), gK && WO && (0, zK.jsx)("span", {
              className: "ShaderPackPublishHint",
              children: NO("shaderPackListing:nameTooShort", {
                min: String(bK.x)
              })
            })]
          }), (0, zK.jsxs)("label", {
            className: "ShaderPackPublishField",
            children: [(0, zK.jsx)("span", {
              children: NO("general:description")
            }), (0, zK.jsx)(hO.e, {
              className: "ShaderPackPublishInput ShaderPackPublishDescription",
              defaultValue: mK,
              maxLength: bK.s,
              onValueChange: SO,
              useTextarea: !0
            }, EO)]
          })]
        }), ZO && (0, zK.jsx)("div", {
          className: "ShaderPackPublishNote Error",
          children: ZO
        }), (0, zK.jsxs)(CO.m, {
          className: "ShaderPackPublishButton",
          disabled: !tK,
          loading: JO,
          onClick: () => {
            !async function() {
              var OO;
              if (!gK) return;
              const {
                name: KO,
                description: pO
              } = null !== AO && void 0 !== AO ? AO : {
                name: nO,
                description: mK.trim()
              }, XO = {
                packId: null !== (OO = null === AO || void 0 === AO ? void 0 : AO.packId) && void 0 !== OO ? OO : null,
                name: KO,
                description: pO,
                apiVersion: gK.pack.manifest.apiVersion,
                files: (0, lO.v)(gK.pack.files),
                keepCircleShadows: !0 === gK.pack.manifest.keepCircleShadows
              };
              if ((new TextEncoder).encode(JSON.stringify(XO)).byteLength > 1024 * bK.G) GO(NO("shaderPackListing:publishTooBig", {
                kilobytes: String(bK.G)
              }));
              else {
                cK(!0), GO(null);
                try {
                  dO(await oO.c.publishShaderPack(IO, XO))
                } catch (eO) {
                  console.error("Failed to publish the shader pack", eO), GO((0, QO.w)(eO, NO, "shaderPackListing:publishFailed"))
                } finally {
                  cK(!1)
                }
              }
            }()
          },
          children: [(0, zK.jsx)(vK.d, {
            name: "upload"
          }), " ", NO(AO ? "shaderPackListing:uploadButton" : "shaderPackListing:publishButton")]
        })]
      })
    }

    function fO(OO) {
      let {
        picked: KO
      } = OO;
      const {
        t: pO
      } = (0, FO.D)(), {
        validation: XO
      } = KO;
      return null === XO ? (0, zK.jsx)("div", {
        className: "ShaderPackPublishNote",
        children: pO("shaderPackListing:publishUnchecked")
      }) : XO.ok ? (0, zK.jsxs)(zK.Fragment, {
        children: [(0, zK.jsxs)("div", {
          className: "ShaderPackPublishNote Ready",
          children: [(0, zK.jsx)(vK.d, {
            name: "circle-check"
          }), " ", pO("shaderPackListing:publishReady")]
        }), XO.offInStrict.length > 0 && (0, zK.jsxs)(zK.Fragment, {
          children: [(0, zK.jsxs)("div", {
            className: "ShaderPackPublishNote Warning",
            children: [(0, zK.jsx)(vK.d, {
              name: "triangle-exclamation"
            }), " ", pO("shaderPack:offInStrict")]
          }), (0, zK.jsx)(MO.c, {
            diagnostics: XO.offInStrict,
            t: pO
          })]
        })]
      }) : (0, zK.jsxs)(zK.Fragment, {
        children: [(0, zK.jsxs)("div", {
          className: "ShaderPackPublishNote Error",
          children: [(0, zK.jsx)(vK.d, {
            name: "triangle-exclamation"
          }), " ", pO("shaderPackListing:publishHasErrors")]
        }), (0, zK.jsx)(MO.c, {
          diagnostics: XO.errors,
          more: XO.moreErrors,
          t: pO
        })]
      })
    }
    const dO = "\0";

    function TO() {
      const {
        t: OO
      } = (0, FO.D)(), [KO, pO] = OO("shaderPackListing:bloxdhubHelp", {
        site: dO
      }).split(dO);
      return (0, zK.jsxs)("p", {
        className: "ShaderPackPublishIntro",
        children: [KO, (0, zK.jsx)("a", {
          className: "ShaderPackPublishLink",
          href: bK.i,
          target: "_blank",
          rel: "noopener noreferrer",
          children: bK.d
        }), pO]
      })
    }
  },
  5700: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => DO
    });
    var XO = pO(1344),
      bK = pO(1271),
      eO = pO(1051),
      lO = pO(5703),
      vK = pO(5684),
      CO = pO(5674),
      hO = pO(976);

    function DO() {
      const {
        t: OO
      } = (0, eO.D)(), KO = (0, XO.useNavigatePreserveSearch)();
      return (0, vK.c)(), (0, hO.jsxs)("div", {
        className: "ShaderPackPublishPage AnimFadeIn",
        children: [(0, hO.jsx)("div", {
          className: "ShaderPackPublishBack",
          children: (0, hO.jsx)(bK.c, {
            onClick: () => {
              KO(CO.S)
            },
            children: OO("shaderPackListing:backToPacks")
          })
        }), (0, hO.jsx)("h1", {
          className: "ShaderPackPublishTitle",
          children: OO("shaderPackListing:publishTitle")
        }), (0, hO.jsx)(lO.ShaderPackPublishForm, {
          existing: null,
          onPublished: OO => {
            KO((0, CO.Y)(OO.packId), {
              replace: !0
            })
          }
        })]
      })
    }
  },
  5684: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => aK,
      g: () => oO,
      i: () => MO,
      j: () => FO
    });
    var XO = pO(63),
      bK = pO(5678),
      eO = pO(1329),
      lO = pO(5674),
      vK = pO(5691),
      CO = pO(1004);
    const hO = "shaderPackListingView",
      DO = "shaderPackListingFilterOpen";

    function MO() {
      var OO;
      const [KO, pO] = (0, vK.d)(hO, bK.y[0]);
      return [null !== (OO = bK.y.find((OO => OO === KO))) && void 0 !== OO ? OO : bK.y[0], pO]
    }

    function aK() {
      (0, XO.useEffect)((() => () => {
        window.location.pathname.startsWith(lO.S) || (0, lO.i)()
      }), [])
    }

    function oO() {
      return (0, vK.d)(DO, !1)
    }

    function FO() {
      const {
        userContext: OO,
        isUserContextUpdating: KO
      } = (0, CO.d)(), [pO, bK] = (0, XO.useState)(null), lO = (0, XO.useRef)(new Set);

      function vK(OO, KO) {
        bK((pO => {
          const XO = new Set(pO);
          return KO ? XO.add(OO) : XO.delete(OO), XO
        }))
      }
      return (0, XO.useEffect)((() => {
        if (KO) return;
        let pO = !1;
        return eO.c.getFavouriteShaderPacks(OO).then((OO => {
          pO || bK(new Set(OO))
        })).catch((OO => {
          console.error("Failed to get favourite shader packs", OO), pO || bK(new Set)
        })), () => {
          pO = !0
        }
      }), [OO, KO]), {
        isFavourite: OO => null === pO ? null : pO.has(OO),
        toggle: function(KO) {
          if (null === pO || lO.current.has(KO)) return;
          lO.current.add(KO);
          const XO = !pO.has(KO);
          vK(KO, XO), (XO ? eO.c.favouriteShaderPack(OO, KO) : eO.c.unfavouriteShaderPack(OO, KO)).catch((OO => {
            console.error("Failed to change a favourite shader pack", OO), vK(KO, !XO)
          })).finally((() => {
            lO.current.delete(KO)
          }))
        }
      }
    }
  },
  5674: (OO, KO, pO) => {
    pO.d(KO, {
      $: () => rK,
      B: () => QO,
      C: () => uO,
      G: () => DO,
      I: () => jK,
      M: () => VO,
      O: () => HO,
      Q: () => mK,
      S: () => lO,
      V: () => sO,
      Y: () => CO,
      _: () => vK,
      bb: () => PO,
      cb: () => AO,
      db: () => EO,
      e: () => zK,
      g: () => yK,
      h: () => LO,
      i: () => aK,
      k: () => MO,
      n: () => YO,
      r: () => oO,
      v: () => wO,
      w: () => RO,
      z: () => FO
    });
    var XO = pO(5678),
      bK = pO(149),
      eO = pO(3738);
    const lO = "/shader-packs",
      vK = `${lO}/publish`;

    function CO(OO) {
      return `${lO}/${encodeURIComponent(OO)}`
    }
    let hO = null;

    function DO(OO) {
      hO = OO
    }

    function MO() {
      return hO
    }

    function aK() {
      hO = null
    }

    function oO(OO) {
      return OO.playerHasRank("developer") || OO.playerHasRank("admin")
    }
    const FO = ["terrain", "water", "models", "sunShadows", "strict"],
      VO = {
        terrain: "shaderPackListing:filterTerrain",
        water: "shaderPackListing:filterWater",
        models: "shaderPackListing:filterModels",
        sunShadows: "shaderPackListing:filterShadows",
        strict: "shaderPackListing:filterAllGames"
      };

    function LO(OO, KO) {
      return OO.withFeatures.includes(KO) ? "with" : OO.withoutFeatures.includes(KO) ? "without" : null
    }

    function QO(OO) {
      return null === OO ? "with" : "with" === OO ? "without" : null
    }

    function zK(OO) {
      return "with" === OO ? "only" : null === OO ? "include" : void 0
    }

    function AO(OO, KO) {
      const pO = LO(OO, KO),
        XO = OO => OO.filter((OO => OO !== KO));
      return {
        withFeatures: null === pO ? [...OO.withFeatures, KO] : XO(OO.withFeatures),
        withoutFeatures: "with" === pO ? [...OO.withoutFeatures, KO] : XO(OO.withoutFeatures)
      }
    }
    const fO = "section",
      dO = "sort",
      TO = "filters",
      NO = "q",
      IO = "banned",
      yK = "popular",
      gK = "strict";

    function uO(OO) {
      var KO, pO, bK;
      const lO = OO.get(fO),
        vK = (null !== (KO = OO.get(TO)) && void 0 !== KO ? KO : gK).split(","),
        CO = OO.get(IO);
      return {
        section: "favourites" === lO || "mine" === lO ? lO : "explore",
        sort: null !== (pO = XO.v.find((KO => KO === OO.get(dO)))) && void 0 !== pO ? pO : yK,
        withFeatures: FO.filter((OO => vK.includes(OO) && !vK.includes(`-${OO}`))),
        withoutFeatures: FO.filter((OO => vK.includes(`-${OO}`))),
        searchQuery: (null === (bK = OO.get(NO)) || void 0 === bK ? void 0 : bK.slice(0, XO.E)) || null,
        pageNumber: (0, eO.f)(OO.get(eO.d)),
        banned: "only" === CO ? "with" : "include" === CO ? null : "without"
      }
    }

    function EO(OO, KO) {
      var pO;
      const XO = iK(KO);
      (0, eO.g)(OO, fO, "explore" === KO.section ? null : KO.section), (0, eO.g)(OO, dO, KO.sort === yK ? null : KO.sort), (0, eO.g)(OO, TO, XO === gK ? null : XO), (0, eO.g)(OO, NO, KO.searchQuery), (0, eO.g)(OO, IO, null !== (pO = zK(KO.banned)) && void 0 !== pO ? pO : null), (0, eO.k)(OO, KO.pageNumber)
    }

    function jK(OO) {
      const KO = new URLSearchParams;
      return EO(KO, {
        section: "explore",
        sort: yK,
        withFeatures: "strict" === OO ? [OO] : [OO, "strict"],
        withoutFeatures: [],
        searchQuery: null,
        pageNumber: 1,
        banned: "without"
      }), `${lO}?${KO.toString()}`
    }

    function YO(OO) {
      return iK(OO) === gK
    }

    function wO(OO) {
      return null !== OO.searchQuery || "with" === OO.banned || iK(OO) !== gK
    }

    function iK(OO) {
      return FO.flatMap((KO => {
        const pO = LO(OO, KO);
        return "with" === pO ? [KO] : "without" === pO ? [`-${KO}`] : []
      })).join(",")
    }
    const rK = {
        popular: "shaderPackListing:sortPopular",
        updated: "shaderPackListing:sortUpdated",
        newest: "shaderPackListing:sortNewest"
      },
      PO = {
        forest: "shaderPackListing:viewForest",
        desert: "shaderPackListing:viewDesert",
        water: "shaderPackListing:viewWater",
        night: "shaderPackListing:viewNight",
        cave: "shaderPackListing:viewCave"
      };

    function mK(OO) {
      return Math.round(100 * Math.max(0, 1 - 1 / OO))
    }

    function sO(OO, KO, pO, bK) {
      const eO = [];
      OO.isBanned && eO.push({
        tone: "warning",
        text: bK("shaderPackListing:ownerBanned"),
        detail: null
      });
      const {
        pending: lO
      } = OO;
      if (null === OO.brokenError || lO && !lO.error || eO.push({
          tone: "warning",
          text: bK("shaderPackListing:ownerBroken"),
          detail: OO.brokenError
        }), null !== lO && void 0 !== lO && lO.error) eO.push({
        tone: "warning",
        text: bK(KO ? "shaderPackListing:ownerUpdateFailed" : "shaderPackListing:ownerFirstFailed"),
        detail: (0, XO.m)(lO.error) ? null : lO.error
      });
      else if (lO) {
        const OO = null === lO.renderNotBefore ? 0 : lO.renderNotBefore - pO,
          XO = String(Math.ceil(OO / 6e4)),
          vK = bK(KO ? OO > 0 ? "shaderPackListing:ownerUpdateWaiting" : "shaderPackListing:ownerUpdateSoon" : OO > 0 ? "shaderPackListing:ownerFirstWaiting" : "shaderPackListing:ownerFirstSoon", {
            minutes: XO
          });
        eO.push({
          tone: "info",
          text: vK,
          detail: null
        })
      }
      return OO.listed || eO.push({
        tone: "info",
        text: bK("shaderPackListing:ownerUnlisted"),
        detail: null
      }), eO
    }

    function HO(OO) {
      return Math.max(1, Math.round(OO / 1024))
    }

    function RO(OO, KO, pO) {
      return OO instanceof bK.b && OO.errorMessageForUser ? OO.errorMessageForUser : KO(pO)
    }
  },
  5691: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(63),
      bK = pO(36);

    function eO(OO, KO) {
      var pO;
      const [eO, lO] = (0, XO.useState)(null !== (pO = bK.e.getItem(OO)) && void 0 !== pO ? pO : KO);
      return [eO, KO => {
        bK.e.setItem(OO, KO), lO(KO)
      }]
    }
  },
  5800: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => eO
    });
    var XO = pO(36);
    const bK = "shaderPack";
    async function eO() {
      var OO;
      let KO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
      return null !== (OO = await XO.d.getItem(bK, KO)) && void 0 !== OO ? OO : null
    }
  },
  5678: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => aK,
      E: () => DO,
      F: () => AO,
      G: () => MO,
      H: () => hO,
      d: () => oO,
      g: () => VO,
      i: () => FO,
      m: () => zK,
      o: () => dO,
      s: () => CO,
      t: () => bK,
      u: () => fO,
      v: () => eO,
      w: () => vK,
      x: () => lO,
      y: () => XO
    });
    const XO = ["forest", "desert", "water", "night", "cave"];
    const bK = {
        full: {
          width: 3840,
          height: 2160
        },
        large: {
          width: 1920,
          height: 1080
        },
        thumb: {
          width: 640,
          height: 360
        }
      },
      eO = ["popular", "updated", "newest"],
      lO = 3,
      vK = 32,
      CO = 300;

    function hO(OO, KO) {
      return OO.slice(0, KO).replace(/[\uD800-\uDBFF]$/, "")
    }
    const DO = 64,
      MO = 512,
      aK = 18e5;
    const oO = "Bloxdhub",
      FO = "https://bloxdhub.com/shaders";

    function VO(OO) {
      return `https://bloxdhub.com/workshop/${encodeURIComponent(OO)}`
    }
    const LO = "Screenshot generation failed.",
      QO = "Its screenshots couldn't be generated:";

    function zK(OO) {
      var KO;
      return OO === LO || null !== (KO = null === OO || void 0 === OO ? void 0 : OO.startsWith(QO)) && void 0 !== KO && KO
    }

    function AO(OO, KO) {
      return `shaderPacks/${OO}/${KO}.json`
    }

    function fO(OO, KO, pO, XO) {
      return null === KO.renderId ? dO(OO, KO.baselineVersion, pO, XO) : `${OO}/${function(OO,KO,pO,XO){return`shaderPacks/${OO}/${KO}/${pO}-${XO}.webp`}(KO.packId,KO.renderId,pO,XO)}`
    }

    function dO(OO, KO, pO, XO) {
      return `${OO}/${function(OO,KO,pO){return`shaderPacks/baseline/${OO}/${KO}-${pO}.webp`}(KO,pO,XO)}`
    }
  },
  4095: (OO, KO, pO) => {
    var XO = pO(4100);

    function bK() {}

    function eO() {}
    eO.resetWarningCache = bK, OO.exports = function() {
      function OO(OO, KO, pO, bK, eO, lO) {
        if (lO !== XO) {
          var vK = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
          throw vK.name = "Invariant Violation", vK
        }
      }

      function KO() {
        return OO
      }
      OO.isRequired = OO;
      var pO = {
        array: OO,
        bigint: OO,
        bool: OO,
        func: OO,
        number: OO,
        object: OO,
        string: OO,
        symbol: OO,
        any: OO,
        arrayOf: KO,
        element: OO,
        elementType: OO,
        instanceOf: KO,
        node: OO,
        objectOf: KO,
        oneOf: KO,
        oneOfType: KO,
        shape: KO,
        exact: KO,
        checkPropTypes: eO,
        resetWarningCache: bK
      };
      return pO.PropTypes = pO, pO
    }
  },
  4087: (OO, KO, pO) => {
    OO.exports = pO(4095)()
  },
  4100: OO => {
    OO.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);