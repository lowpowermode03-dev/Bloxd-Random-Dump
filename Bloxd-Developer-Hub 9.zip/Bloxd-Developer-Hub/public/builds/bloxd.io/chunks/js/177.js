export const id = 177;
export const ids = [177];
export const modules = {
  8256: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      ALL_DEV_TOOLS: () => lO,
      coreDevTools: () => hO,
      devTools: () => CO
    });
    var XO = pO(554),
      bK = pO(1146),
      eO = pO(8263);
    const lO = new Set(["sceneDownload", "ambientLight", "weaponRaycasts", "chunkBorders"]);
    async function vK() {
      const {
        noaDevTools: OO
      } = await pO.e(218).then((() => pO(39125)));
      return OO
    }
    const CO = new class {
        constructor() {
          this.loadHost = vK, this.tools = lO
        }
        setHost(OO) {
          this.tools = null === OO ? lO : OO.tools, this.loadHost = null === OO ? vK : async () => OO
        }
        supports(OO) {
          return this.tools.has(OO)
        }
        async downloadScene(OO, KO) {
          const pO = await this.loadHost();
          await pO.downloadScene(OO, KO)
        }
        async setAmbientLightIntensity(OO) {
          const KO = await this.loadHost();
          await KO.setAmbientLightIntensity(OO)
        }
      },
      hO = {
        tools: eO.b,
        downloadScene: async () => {
          throw new Error("This client can't download the scene")
        },
        setAmbientLightIntensity: async () => {
          throw new Error("This client can't set the ambient light")
        }
      };
    XO.s && CO.setHost(hO), (0, bK.m)((() => {
      CO.setHost(hO)
    }))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);