export const id = 2;
export const ids = [2];
export const modules = {
  34960: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      drawBlockIcon: () => fO,
      drawBlockIconUrl: () => dO,
      getDrawnBlockIcon: () => AO
    });
    var XO = pO(34968);
    const bK = Math.SQRT1_2,
      eO = Math.sqrt(3) / 2,
      lO = .5,
      vK = {
        boxes: [
          [0, 0, 0, 1, 1, 1]
        ],
        cropFaces: !1
      },
      CO = {
        boxes: [
          [0, 0, 0, 1, .5, 1]
        ],
        cropFaces: !1
      },
      hO = {
        boxes: [
          [0, 0, 0, 1, .5, 1],
          [0, .5, 0, .5, 1, 1]
        ],
        cropFaces: !0
      };
    const DO = 1e-6;

    function MO(OO, KO, pO, XO) {
      let {
        origin: bK,
        across: eO,
        down: lO,
        texture: vK,
        rect: [CO, hO, MO, aK],
        shade: oO
      } = XO;
      const FO = eO.x * lO.y - eO.y * lO.x;
      if (Math.abs(FO) < 1e-9) return;
      const VO = [bK.x, bK.x + eO.x, bK.x + lO.x, bK.x + eO.x + lO.x],
        LO = [bK.y, bK.y + eO.y, bK.y + lO.y, bK.y + eO.y + lO.y],
        QO = Math.max(0, Math.floor(Math.min(...VO))),
        zK = Math.min(pO - 1, Math.ceil(Math.max(...VO))),
        AO = Math.max(0, Math.floor(Math.min(...LO))),
        fO = Math.min(pO - 1, Math.ceil(Math.max(...LO)));
      for (let dO = AO; dO <= fO; dO++)
        for (let XO = QO; XO <= zK; XO++) {
          const VO = XO + .5 - bK.x,
            LO = dO + .5 - bK.y,
            QO = (VO * lO.y - LO * lO.x) / FO,
            zK = (eO.x * LO - eO.y * VO) / FO;
          if (QO < -DO || QO > 1 + DO || zK < -DO || zK > 1 + DO) continue;
          const AO = dO * pO + XO;
          KO[AO] = 1;
          const fO = CO + Math.min(Math.max(QO, 0), 1) * (MO - CO),
            TO = hO + Math.min(Math.max(zK, 0), 1) * (aK - hO),
            NO = Math.min(vK.width - 1, Math.floor(fO * vK.width)),
            IO = 4 * (Math.min(vK.height - 1, Math.floor(TO * vK.height)) * vK.width + NO),
            yK = vK.pixels[IO + 3] / 255;
          if (0 === yK) continue;
          const gK = 4 * AO,
            uO = OO[gK + 3] / 255 * (1 - yK),
            EO = yK + uO;
          for (let KO = 0; KO < 3; KO++) OO[gK + KO] = (vK.pixels[IO + KO] * oO * yK + OO[gK + KO] * uO) / EO;
          OO[gK + 3] = 255 * EO
        }
    }
    var aK = pO(34974);
    const oO = new Map,
      FO = new Map,
      VO = new Map,
      LO = new Map;

    function QO(OO, KO, pO) {
      return `${KO}|${pO}|${OO}`
    }

    function zK(OO, KO, pO) {
      let XO = OO.get(KO);
      return void 0 === XO && (XO = pO().catch((pO => {
        throw OO.delete(KO), pO
      })), OO.set(KO, XO)), XO
    }

    function AO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
      return FO.get(QO(OO, KO, pO))
    }

    function fO(OO, KO, pO, XO) {
      const bK = QO(OO, KO, pO);
      return zK(oO, bK, (async () => {
        const eO = await NO(XO(OO), KO, TO(pO));
        return FO.set(bK, eO), eO
      }))
    }

    function dO(OO, KO, pO, XO) {
      return zK(VO, QO(OO, KO, pO), (async () => {
        var bK;
        const eO = XO(OO),
          lO = TO(pO);
        return null !== (bK = await (0, aK.d)(eO, KO, lO)) && void 0 !== bK ? bK : (await NO(eO, KO, lO)).toDataURL()
      }))
    }

    function TO(OO) {
      return Math.max(1, Math.round(OO))
    }
    async function NO(OO, KO, pO) {
      let {
        top: DO,
        left: aK,
        right: oO,
        itemType: FO
      } = OO;
      const [VO, LO, QO] = await Promise.all([IO(DO), IO(aK), IO(oO)]), zK = function(OO, KO, pO, vK) {
        const CO = .6 * pO,
          hO = CO * bK,
          DO = CO * bK * lO,
          aK = CO * eO,
          oO = Math.max(...KO.boxes.map((OO => OO[4]))),
          FO = hO / 2 + (pO - hO) / 2,
          VO = DO + (pO - DO - DO - oO * aK) / 2,
          LO = (OO, KO, pO) => ({
            x: FO + (OO - pO) * hO,
            y: VO - DO + (OO + pO) * DO + (oO - KO) * aK
          }),
          QO = (OO, pO, XO, bK, eO, lO) => ({
            origin: OO,
            across: {
              x: pO.x - OO.x,
              y: pO.y - OO.y
            },
            down: {
              x: XO.x - OO.x,
              y: XO.y - OO.y
            },
            texture: bK,
            rect: KO.cropFaces ? eO : [0, 0, 1, 1],
            shade: lO
          }),
          zK = new Uint8ClampedArray(pO * pO * 4),
          AO = new Uint8Array(pO * pO),
          fO = XO.b;
        for (const [XO, bK, eO, lO, dO, TO] of KO.boxes) {
          const KO = QO(LO(lO, dO, TO), LO(lO, dO, eO), LO(lO, bK, TO), OO.right, [1 - TO, 1 - dO, 1 - eO, 1 - bK], fO.right),
            vK = QO(LO(XO, dO, TO), LO(lO, dO, TO), LO(XO, bK, TO), OO.left, [XO, 1 - dO, lO, 1 - bK], fO.left),
            CO = QO(LO(XO, dO, eO), LO(lO, dO, eO), LO(XO, dO, TO), OO.top, [XO, eO, lO, TO], fO.top);
          for (const OO of [KO, vK, CO]) MO(zK, AO, pO, OO)
        }
        return (0, XO.d)(zK, pO, vK, (OO => 1 === AO[OO])), zK
      }({
        top: VO,
        left: LO,
        right: QO
      }, function(OO) {
        return "SlabBlock" === OO ? CO : "StairsBlock" === OO ? hO : vK
      }(FO), KO, pO), AO = document.createElement("canvas");
      AO.width = KO, AO.height = KO;
      const fO = AO.getContext("2d");
      if (!fO) throw new Error("Failed to get 2D context");
      return fO.putImageData(new ImageData(zK, KO, KO), 0, 0), AO
    }

    function IO(OO) {
      return zK(LO, OO, (async () => {
        const KO = await (0, aK.h)(OO),
          pO = document.createElement("canvas");
        pO.width = KO.width, pO.height = KO.height;
        const XO = pO.getContext("2d");
        if (!XO) throw new Error("Failed to get 2D context");
        return XO.drawImage(KO, 0, 0), {
          width: KO.width,
          height: KO.height,
          pixels: XO.getImageData(0, 0, KO.width, KO.height).data
        }
      }))
    }
  },
  34974: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => yK,
      e: () => gK,
      h: () => zK
    });
    var XO = pO(129),
      bK = pO(94);
    const eO = new(pO(34981).c)(new URL(pO.p + pO.u(3), pO.b), {
      name: "blockIconWorker",
      type: "module"
    });
    var lO = pO(2373);
    const vK = 1e4,
      CO = 3e4;
    let hO = null,
      DO = null,
      MO = null,
      aK = !1,
      oO = 0;
    const FO = new Map;
    let VO = null;
    const LO = new Map,
      QO = new Map;

    function zK(OO) {
      return new Promise(((KO, pO) => {
        const XO = new Image;
        XO.crossOrigin = "anonymous", XO.onload = () => {
          KO(XO)
        }, XO.onerror = () => {
          pO(new Error(`A block icon's texture did not load: ${OO.slice(0,100)}`))
        }, XO.src = OO
      }))
    }

    function AO(OO) {
      var KO, pO;
      aK || console.warn(`[blockIconWorker] block icons draw on the page, as the worker ${OO}`), aK = !0, null === (KO = hO) || void 0 === KO || KO.terminate(), hO = null, DO = null, LO.clear(), QO.clear();
      for (const XO of FO.values()) XO(null);
      FO.clear(), null === (pO = VO) || void 0 === pO || pO()
    }

    function fO() {
      return MO ??= async function() {
        if ("undefined" === typeof Worker || "undefined" === typeof OffscreenCanvas || "undefined" === typeof createImageBitmap) return;
        if ("page" === XO.b.ios_icon_worker_v1 && (0, bK.isWebKit)()) return;
        try {
          hO = await async function() {
            return await eO.ready(), eO.start()
          }()
        } catch (vK) {
          return void AO(`did not start (${String(vK)})`)
        }
        let OO = () => {};
        const KO = new Promise((KO => {
          OO = KO
        }));
        hO.onmessage = KO => {
          let {
            data: pO
          } = KO;
          if ("started" === pO.type) DO = hO, OO();
          else if ("failed" === pO.type) AO(`failed a draw (${pO.message})`);
          else {
            var XO, bK;
            null === (XO = FO.get(pO.id)) || void 0 === XO || XO(pO.url), FO.delete(pO.id), null === (bK = VO) || void 0 === bK || bK()
          }
        }, hO.onerror = KO => {
          KO.preventDefault(), AO(`stopped (${KO.message||"its script did not load or run"})`), OO()
        };
        const pO = `did not start in ${CO/1e3} s`;
        await (0, lO.d)(KO, CO, pO).catch((() => {
          AO(pO)
        }))
      }(), MO
    }

    function dO() {
      if (null !== VO || 0 === FO.size) return;
      const OO = new Promise((OO => {
          VO = OO
        })),
        KO = `did not answer in ${vK/1e3} s`;
      (0, lO.d)(OO, vK, KO).then((() => {
        VO = null, dO()
      }), (() => {
        VO = null, AO(KO)
      }))
    }

    function TO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
      OO.postMessage(KO, pO)
    }

    function NO(OO, KO, pO, XO) {
      let bK = KO.get(pO);
      return void 0 === bK && (bK = XO().then((async KO => {
        let {
          image: pO,
          request: XO
        } = KO;
        try {
          const KO = await createImageBitmap(pO);
          TO(OO, XO(KO), [KO])
        } catch (bK) {
          AO(`could not take an image (${String(bK)})`)
        }
      })), bK.catch((() => {
        KO.get(pO) === bK && KO.delete(pO)
      })), KO.set(pO, bK)), bK
    }
    async function IO(OO, KO) {
      fO();
      const pO = DO;
      if (null === pO) return null;
      if (await OO(pO), DO !== pO) return null;
      const XO = ++oO;
      return new Promise((OO => {
        FO.set(XO, OO), TO(pO, KO(XO)), dO()
      }))
    }

    function yK(OO, KO, pO) {
      return IO((KO => Promise.all([OO.top, OO.left, OO.right].map((OO => function(OO, KO) {
        return NO(OO, LO, KO, (async () => ({
          image: await zK(KO),
          request: OO => ({
            type: "texture",
            url: KO,
            bitmap: OO
          })
        })))
      }(KO, OO))))), (XO => ({
        type: "draw",
        id: XO,
        ...OO,
        size: KO,
        outlineWidth: pO
      })))
    }

    function gK(OO, KO, pO, XO) {
      return IO((pO => function(OO, KO, pO) {
        return NO(OO, QO, KO, (async () => {
          const {
            texture: OO,
            ...XO
          } = await pO();
          return {
            image: await zK(OO),
            request: OO => ({
              type: "model",
              name: KO,
              bitmap: OO,
              geometry: XO
            })
          }
        }))
      }(pO, OO, KO)), (KO => ({
        type: "drawModel",
        id: KO,
        name: OO,
        size: pO,
        outlineWidth: XO
      })))
    }
  },
  34968: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      d: () => vK,
      f: () => lO
    });
    const XO = 1 / 32,
      bK = [15, 15, 15],
      eO = {
        top: 1,
        left: .85,
        right: .7
      };

    function lO(OO, KO, pO, bK) {
      const {
        vertices: eO,
        uvs: lO,
        indices: CO,
        shades: hO
      } = OO, DO = pO * XO, MO = pO - 2 * DO, aK = new Float32Array(eO.length);
      for (let XO = 0; XO < eO.length; XO += 3) aK[XO] = DO + eO[XO] * MO, aK[XO + 1] = DO + eO[XO + 1] * MO, aK[XO + 2] = eO[XO + 2];
      const oO = new Float32Array(pO * pO).fill(-1 / 0),
        FO = new Uint8ClampedArray(pO * pO * 4),
        VO = 255 * OO.alphaCutoff;
      for (let XO = 0; XO < CO.length; XO += 3) {
        const [OO, bK, eO] = [CO[XO], CO[XO + 1], CO[XO + 2]], [vK, DO, MO] = [3 * OO, 3 * bK, 3 * eO], [LO, QO, zK, AO, fO, dO] = [aK[vK], aK[vK + 1], aK[DO], aK[DO + 1], aK[MO], aK[MO + 1]], TO = (zK - LO) * (dO - QO) - (fO - LO) * (AO - QO);
        if (Math.abs(TO) < 1e-9) continue;
        const NO = hO[XO / 3],
          [IO, yK, gK, uO, EO, jK] = [lO[2 * OO], lO[2 * OO + 1], lO[2 * bK], lO[2 * bK + 1], lO[2 * eO], lO[2 * eO + 1]],
          YO = Math.max(0, Math.floor(Math.min(LO, zK, fO))),
          wO = Math.min(pO - 1, Math.ceil(Math.max(LO, zK, fO))),
          iK = Math.max(0, Math.floor(Math.min(QO, AO, dO))),
          rK = Math.min(pO - 1, Math.ceil(Math.max(QO, AO, dO)));
        for (let XO = iK; XO <= rK; XO++)
          for (let OO = YO; OO <= wO; OO++) {
            const [bK, eO] = [OO + .5, XO + .5], lO = ((bK - LO) * (dO - QO) - (fO - LO) * (eO - QO)) / TO, CO = ((zK - LO) * (eO - QO) - (bK - LO) * (AO - QO)) / TO, hO = 1 - lO - CO;
            if (hO < 0 || lO < 0 || CO < 0) continue;
            const YO = hO * aK[vK + 2] + lO * aK[DO + 2] + CO * aK[MO + 2],
              wO = XO * pO + OO;
            if (YO <= oO[wO]) continue;
            const iK = Math.max(0, Math.min(KO.width - 1, Math.floor((hO * IO + lO * gK + CO * EO) * KO.width))),
              rK = 4 * (Math.max(0, Math.min(KO.height - 1, Math.floor((hO * yK + lO * uO + CO * jK) * KO.height))) * KO.width + iK);
            KO.pixels[rK + 3] < VO || (oO[wO] = YO, FO[4 * wO] = KO.pixels[rK] * NO, FO[4 * wO + 1] = KO.pixels[rK + 1] * NO, FO[4 * wO + 2] = KO.pixels[rK + 2] * NO, FO[4 * wO + 3] = 255)
          }
      }
      return vK(FO, pO, bK), FO
    }

    function vK(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : KO => 0 !== OO[4 * KO + 3];
      const eO = (OO, pO) => OO < 0 || pO < 0 || OO >= KO || pO >= KO || !XO(pO * KO + OO),
        lO = [];
      for (let bK = 0; bK < KO; bK++)
        for (let OO = 0; OO < KO; OO++)
          if (!eO(OO, bK)) OO: for (let XO = -pO; XO <= pO; XO++) {
            const vK = pO - Math.abs(XO);
            for (let pO = -vK; pO <= vK; pO++)
              if (eO(OO + pO, bK + XO)) {
                lO.push(bK * KO + OO);
                break OO
              }
          }
      for (const vK of lO) OO.set(bK, 4 * vK), OO[4 * vK + 3] = 255
    }
  },
  34981: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    const XO = {
      wait: function(OO) {
        return new Promise((KO => {
          setTimeout(KO, OO)
        }))
      },
      stallMs: 2e4
    };
    class bK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : XO;
        this.url = OO, this.options = KO, this.timing = pO, this.fetched = null, this.scriptUrl = void 0, this.scriptUrl = OO
      }
      ready() {
        return this.fetched ??= this.fetchWithRetries(), this.fetched
      }
      start() {
        return new Worker(this.scriptUrl, this.options)
      }
      async fetchWithRetries() {
        for (let OO = 0;; OO++) {
          const KO = new URL(this.url);
          if (OO > 0 && KO.searchParams.set("cache-bust", `${Date.now()}-${OO}`), await this.fetchWhole(KO)) return void(this.scriptUrl = KO);
          if (OO >= 3) return;
          await this.timing.wait(500 * 2 ** OO)
        }
      }
      async fetchWhole(OO) {
        const KO = new AbortController;
        let pO;
        const XO = () => {
          clearTimeout(pO), pO = setTimeout((() => {
            KO.abort()
          }), this.timing.stallMs)
        };
        XO();
        try {
          var bK;
          const pO = await fetch(OO, {
            signal: KO.signal
          });
          if (!pO.ok) return !1;
          const eO = null === (bK = pO.body) || void 0 === bK ? void 0 : bK.getReader();
          if (!eO) return !1;
          for (;;) {
            const {
              done: OO
            } = await eO.read();
            if (OO) return !0;
            XO()
          }
        } catch {
          return !1
        } finally {
          clearTimeout(pO)
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);