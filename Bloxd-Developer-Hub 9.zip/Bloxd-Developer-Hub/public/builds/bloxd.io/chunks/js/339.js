export const id = 339;
export const ids = [339];
export const modules = {
  59150: (OO, KO, pO) => {
    function XO(OO, KO, pO, XO, bK, eO, lO) {
      const vK = KO,
        CO = XO,
        hO = pO;
      OO[hO + 0] = vK[CO + 0], OO[hO + 1] = vK[CO + 1], OO[hO + 2] = vK[CO + 2], OO[hO + 3] = vK[CO + 3], OO[hO + 4] = vK[CO + 4], OO[hO + 5] = vK[CO + 5], OO[hO + 6] = vK[CO + 6], OO[hO + 7] = vK[CO + 7], OO[hO + 8] = vK[CO + 8], OO[hO + 9] = vK[CO + 9], OO[hO + 10] = vK[CO + 10], OO[hO + 11] = vK[CO + 11], OO[hO + 12] = vK[CO + 12] - bK, OO[hO + 13] = vK[CO + 13] - eO, OO[hO + 14] = vK[CO + 14] - lO, OO[hO + 15] = vK[CO + 15]
    }

    function bK(OO) {
      return (KO, pO, bK, eO) => {
        const lO = OO.camera;
        if (!lO) return void XO(KO, pO, bK, eO, 0, 0, 0);
        const vK = lO.worldMatrix;
        XO(KO, pO, bK, eO, vK[12], vK[13], vK[14])
      }
    }
    pO.r(KO), pO.d(KO, {
      makePackMeshWorld: () => bK,
      packMat4IntoF32WithOffset: () => XO
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);