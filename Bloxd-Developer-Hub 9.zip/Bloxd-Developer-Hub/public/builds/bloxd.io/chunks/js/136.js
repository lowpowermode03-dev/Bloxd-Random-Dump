export const id = 136;
export const ids = [136];
export const modules = {
  7191: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      BloxdMsnAccountSdk: () => MO,
      MsnSdkAdaptor: () => VO,
      msnMockIdentityStorageKey: () => CO
    });
    var XO = pO(1158),
      bK = pO(1044),
      eO = pO(2711),
      lO = pO(533);
    pO(36);
    const vK = "https://assets.msn.com/staticsb/statics/latest/msstart-games-sdk/msstart-v1.0.0-rc.23.min.js",
      CO = "msnMockIdentity";
    let hO = null;

    function DO() {
      return hO ??= async function() {
        await (0, bK.e)(vK, {}, !1);
        for (let OO = 0; OO < 50 && !window.$msstart; OO++) await (0, lO.M)(100)
      }(), hO
    }
    class MO {
      constructor() {}
      static async setup() {
        try {
          await Promise.race([DO(), (0, lO.M)(1e4).then((() => {
            throw new Error("Not loaded after 10000ms")
          }))])
        } catch (OO) {
          return console.error("MSN Play SDK failed to load, so MSN Play accounts are unavailable:", OO), null
        }
        return window.$msstart ? new MO : (console.error("MSN Play SDK script loaded but window.$msstart is missing, so MSN Play accounts are unavailable"), null)
      }
      async getSignedInUser() {
        try {
          return await Promise.race([window.$msstart.getSignedInUserAsync(), (0, lO.M)(1e4).then((() => {
            throw new Error("No answer after 10000ms")
          }))])
        } catch (OO) {
          return "USER_NOT_CONSENTED" !== (null === OO || void 0 === OO ? void 0 : OO.code) && console.error("Failed to get the signed-in MSN Play player:", OO), null
        }
      }
      async signIn() {
        return null !== null ? null : await window.$msstart.signInAsync()
      }
    }
    const aK = 20,
      oO = {
        top: [{
          width: 970,
          height: 250
        }, {
          width: 728,
          height: 90
        }, {
          width: 320,
          height: 50
        }],
        right: [{
          width: 300,
          height: 600
        }, {
          width: 160,
          height: 600
        }, {
          width: 300,
          height: 250
        }, {
          width: 320,
          height: 50
        }],
        left: [{
          width: 300,
          height: 600
        }, {
          width: 160,
          height: 600
        }, {
          width: 300,
          height: 250
        }, {
          width: 320,
          height: 50
        }]
      },
      FO = {
        leaderboard: {
          1: ["right", "left"],
          5: ["top", "left"]
        },
        square: {
          1: []
        },
        skyscraper: {
          2: []
        }
      };
    class VO extends XO.c {
      constructor() {
        super(), this.name = "msn", this.currentlyShowingBannerPlacement = null, this.isCurrentlyClearingAllBanners = !1
      }
      static async setup() {
        return await DO(), new VO
      }
      playVideoAd(OO, KO) {
        this.playVideoOrRewarded("video", OO, OO)
      }
      playRewarded(OO, KO) {
        this.playVideoOrRewarded("rewarded", OO, KO)
      }
      canShowBloxdAd(OO) {
        for (const KO in FO)
          if (OO.adId in FO[KO]) return !1;
        return !0
      }
      async renderBanner(OO) {
        if (null !== this.currentlyShowingBannerPlacement) return void console.log(`AD ${(0,eO.c)(OO)}: msn placement is already showing so not requesting`);
        const KO = FO[OO.adType][OO.adId];
        if ((0, lO.I)(KO)) return void console.warn(`AD ${(0,eO.c)(OO)}: no msn placement is configured for this bloxd placement so not showing any ad`);
        const pO = [];
        for (const XO of KO)
          for (const OO of oO[XO])
            if (OO.width <= window.innerWidth - 40 && OO.height <= window.innerHeight - 40) {
              const KO = {
                placement: XO,
                width: OO.width,
                height: OO.height
              };
              if (!pO.some((OO => QO(KO, OO)))) {
                pO.push(KO);
                break
              }
            } if (pO.length > 0) {
          console.log(`AD ${(0,eO.c)(OO)}: Attempting to show msn units: `, pO);
          const KO = pO.map((OO => `${OO.placement}:${OO.width}x${OO.height}`));
          this.currentlyShowingBannerPlacement = {
            placementId: (0, eO.c)(OO),
            renderPromise: window.$msstart.showDisplayAdsAsync(KO).then((() => {
              console.log(`AD ${(0,eO.c)(OO)}: Successfully request msn banner ad`)
            })).catch((KO => {
              console.log(`AD ${(0,eO.c)(OO)}: Error while requesting msn banner ad`, KO)
            }))
          }
        } else console.warn(`AD ${(0,eO.c)(OO)}: couldn't find an msn unit that fit screen size`)
      }
      async clearBanner(OO) {
        null !== this.currentlyShowingBannerPlacement && (0, eO.c)(OO) === this.currentlyShowingBannerPlacement.placementId && (console.log(`AD ${(0,eO.c)(OO)}: Attempting to clear msn banner ads for banner`, OO), await this.clearAllBannerAds())
      }
      async clearAllBannerAds() {
        try {
          if (this.isCurrentlyClearingAllBanners) return;
          this.isCurrentlyClearingAllBanners = !0, null !== this.currentlyShowingBannerPlacement && await this.currentlyShowingBannerPlacement.renderPromise, await window.$msstart.hideDisplayAdsAsync(), console.log("AD: Successfully cleared all msn banner ads")
        } catch (OO) {
          console.log("AD: Error while clearing all msn banner ads", OO)
        } finally {
          this.currentlyShowingBannerPlacement = null, this.isCurrentlyClearingAllBanners = !1
        }
      }
      playVideoOrRewarded(OO, KO, pO) {
        const XO = KO => {
          console.error(`AD: Error while playing MSN ${OO} ad: `, KO), document.getElementById("GenericVideoWrapper").style.display = "none", window.adCompleteSoResume(), pO()
        };
        if (window.$msstart) {
          console.log(`AD: Attempting to play MSN ${OO} ad`), document.getElementById("GenericVideoWrapper").style.display = "flex";
          const pO = async () => {
            try {
              const pO = await window.$msstart.loadAdsAsync("rewarded" === OO),
                XO = await window.$msstart.showAdsAsync(pO.instanceId);
              this.clearAllBannerAds(), await XO.showAdsCompletedAsync, console.log(`AD: Successfully finished MSN ${OO} ad`), document.getElementById("GenericVideoWrapper").style.display = "none", window.adCompleteSoResume(), KO()
            } catch (pO) {
              XO(pO)
            }
          };
          window.adStartSoPause(null, {
            preventMovement: !0
          }), pO()
        } else XO(`AD: Can't play MSN ${OO} ad because sdk is not loaded`)
      }
    }

    function LO(OO) {
      let KO, pO;
      switch (OO.placement) {
        case "top":
          KO = (window.innerWidth - OO.width) / 2, pO = aK;
          break;
        case "right":
          KO = window.innerWidth - OO.width - aK, pO = window.innerHeight / 2 - OO.height / 2 - 10;
          break;
        case "left":
          KO = aK, pO = window.innerHeight / 2 - OO.height / 2 - 10
      }
      return {
        x1: KO,
        y1: pO,
        x2: KO + OO.width,
        y2: pO + OO.height
      }
    }

    function QO(OO, KO) {
      const pO = LO(OO),
        XO = LO(KO);
      return !(pO.x2 <= XO.x1 || XO.x2 <= pO.x1 || pO.y2 <= XO.y1 || XO.y2 <= pO.y1)
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);